# Finding the Farthest in High Dimensions: Dynamic Diameter and Farthest-Neighbor Search: a Lean 4 formalization

A complete Lean 4 + Mathlib formalization of *Finding the Farthest in High Dimensions: Dynamic Diameter and Farthest-Neighbor Search* by Mohammad Hajiaghayi and Morteza Monemizadeh (`arXiv:2611.17050v1`), produced with UltraLeanifier.

**Status:** VERIFIED · digest `99f273bc871823736d88c3ec`

| | |
| :--- | :--- |
| Results | 23 definitions, 5 cited theorems, 16 lemmas, 18 claims, 2 theorems |
| Lean | 4.27.0 (with Mathlib v4.27.0) |
| Axioms | only `propext`, `Classical.choice`, `Quot.sound` (checked with `#print axioms` on every result) |
| `sorry` | none |

## Main results

- **Theorem 1.1** (`UL.T_thm_1_1 : UL.S_thm_1_1`, statement in `UL/Stmt/thm_1_1.lean`): For every fixed 1 < c < √2, a fully dynamic structure maintains a factor-c diameter pair with worst-case update time n^{2/c^2 − 1} poly_c(d, log(2nt/δ)) and space n^{2/c^2} poly_c(d, log(2nt/δ)). With probability at least 1 − δ, all answers during the first t adaptive updates are correct.

- **Theorem 1.2** (`UL.T_thm_1_2 : UL.S_thm_1_2`, statement in `UL/Stmt/thm_1_2.lean`): A fully dynamic structure maintains a factor-√2 diameter pair with worst-case update time O(D^{19} H^{18}) and space O(nD^{19} H^{18}). With probability at least 1 − δ, every answer during the first t adaptive updates is correct. For rational coordinates of at most B bits, an always-correct variant uses n poly(d, B, log(2n)) space and poly(d, B, log(2n)) expected amortized update time, without a prescribed bound on the number of updates.

## Layout

- `UL/Def/<id>.lean`: the paper's definitions.
- `UL/Stmt/<id>.lean`: each result's statement, as `def S_<id> : Prop`.
- `UL/Proof/<id>.lean`: its proof, `theorem P_<id>`, which takes the statements it uses as hypotheses.
- `UL/Witness/<id>.lean`: a proof that the hypotheses of the statement can all hold (non-vacuity).
- `UL/Final.lean`: every result as `theorem T_<id> : S_<id>`, assembled from the proofs alone.

Open `explorer/index.html` in a browser to explore the results: start from a main theorem, click down to the lemmas it uses, and see each paper statement next to its Lean statement and proof.

## Build

```bash
lake exe cache get   # downloads Mathlib's compiled files
lake build
```

`lean-toolchain` pins Lean 4.27.0, and `lakefile.toml` pins the matching Mathlib release. The proofs were checked with Mathlib v4.27.0 for this Lean version; if the public release differs in a lemma name, a small rename fixes it.

To check the axioms yourself, add `#print axioms UL.T_<id>` at the end of `UL/Final.lean`.

## License

Add the license of your choice before publishing (for example Apache-2.0, like Mathlib).
