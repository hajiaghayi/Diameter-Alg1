import UL.Stmt.clm_7_3_failure_budget
import UL.Stmt.clm_5_1_mc_baseline
import UL.Stmt.lem_C_2
import UL.Stmt.claim_C_2_space_reclaim
import UL.Stmt.clm_7_2_chain_schedule
import UL.Proof.clm_7_3_failure_budget.H1_Events
import UL.Proof.clm_7_3_failure_budget.RaceCG_H1
import UL.Proof.clm_7_3_failure_budget.RaceCG_H2
import UL.Proof.clm_7_3_failure_budget.RaceCG_H3
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_7_3_failure_budget (h_clm_5_1_mc_baseline : S_clm_5_1_mc_baseline) (h_lem_C_2 : S_lem_C_2) (h_claim_C_2_space_reclaim : S_claim_C_2_space_reclaim) (h_clm_7_2_chain_schedule : S_clm_7_2_chain_schedule) : S_clm_7_3_failure_budget := by
  have _ := h_clm_5_1_mc_baseline
  have _ := h_lem_C_2
  have _ := h_claim_C_2_space_reclaim
  have _ := h_clm_7_2_chain_schedule
  exact ⟨UL.Proof_clm_7_3_failure_budget.part1_failure_budget,
   UL.Proof_clm_7_3_failure_budget_cg_H1.fb_conj2,
   UL.Proof_clm_7_3_failure_budget_cg_H2.fb_conj3,
   UL.Proof_clm_7_3_failure_budget_cg_H2.fb_conj4,
   UL.Proof_clm_7_3_failure_budget_cg_H3.fb_conj5⟩

end UL
