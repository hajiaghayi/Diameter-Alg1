import UL.Stmt.thm_1_1
import UL.Stmt.cit_hpj19_thm18
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_chain_contraction
import UL.Stmt.clm_5_1_mc_baseline
import UL.Stmt.lem_5_2
import UL.Stmt.lem_5_3
import UL.Stmt.clm_5_2_config_gap
import UL.Stmt.clm_5_3_matching_invariant
import UL.Stmt.lem_5_4
import UL.Stmt.lem_5_5
import UL.Stmt.clm_5_3_global_factor_c
import UL.Stmt.lem_5_6
import UL.Stmt.clm_5_4_queries_and_caps
import UL.Stmt.lem_6_1
import UL.Stmt.lem_6_2
import UL.Stmt.lem_6_3
import UL.Stmt.clm_6_1_adaptive
import UL.Stmt.clm_6_1_precision
import UL.Stmt.lem_7_1
import UL.Stmt.claim_C_2_scans
import UL.Stmt.lem_C_2
import UL.Stmt.claim_C_2_space_reclaim
import UL.Stmt.clm_7_2_chain_schedule
import UL.Stmt.clm_7_3_global_approx
import UL.Stmt.clm_7_3_failure_budget
import UL.Stmt.lem_9_1
import UL.Stmt.clm_9_1_explicit_tradeoff
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_thm_1_1 (h_cit_hpj19_thm18 : S_cit_hpj19_thm18) (h_lem_5_1 : S_lem_5_1) (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction) (h_clm_5_1_mc_baseline : S_clm_5_1_mc_baseline) (h_lem_5_2 : S_lem_5_2) (h_lem_5_3 : S_lem_5_3) (h_clm_5_2_config_gap : S_clm_5_2_config_gap) (h_clm_5_3_matching_invariant : S_clm_5_3_matching_invariant) (h_lem_5_4 : S_lem_5_4) (h_lem_5_5 : S_lem_5_5) (h_clm_5_3_global_factor_c : S_clm_5_3_global_factor_c) (h_lem_5_6 : S_lem_5_6) (h_clm_5_4_queries_and_caps : S_clm_5_4_queries_and_caps) (h_lem_6_1 : S_lem_6_1) (h_lem_6_2 : S_lem_6_2) (h_lem_6_3 : S_lem_6_3) (h_clm_6_1_adaptive : S_clm_6_1_adaptive) (h_clm_6_1_precision : S_clm_6_1_precision) (h_lem_7_1 : S_lem_7_1) (h_claim_C_2_scans : S_claim_C_2_scans) (h_lem_C_2 : S_lem_C_2) (h_claim_C_2_space_reclaim : S_claim_C_2_space_reclaim) (h_clm_7_2_chain_schedule : S_clm_7_2_chain_schedule) (h_clm_7_3_global_approx : S_clm_7_3_global_approx) (h_clm_7_3_failure_budget : S_clm_7_3_failure_budget) (h_lem_9_1 : S_lem_9_1) (h_clm_9_1_explicit_tradeoff : S_clm_9_1_explicit_tradeoff) : S_thm_1_1 := by
  intro c hc_gt hc_lt
  obtain ⟨_, _, _, h_curve, h_endpoints⟩ := h_clm_9_1_explicit_tradeoff c hc_gt hc_lt
  obtain ⟨h_rho_pos, _, _, hQ_rho, h1_rho, _⟩ := h_endpoints
  obtain ⟨polyTime, polySpace, queryConst, writeFactor, hPolyTime, hPolySpace, hMain⟩ :=
    h_curve (rho_c c) h_rho_pos.le le_rfl
  refine ⟨polyTime, polySpace, queryConst, writeFactor, hPolyTime, hPolySpace, ?_⟩
  intro d n t δ hn ht hδ0 hδ1
  obtain ⟨prog, initOut, hInit, hModel, hMC, hWork, hSpace⟩ := hMain d n t δ hn ht hδ0 hδ1
  rw [hQ_rho] at hWork
  rw [h1_rho] at hSpace
  exact ⟨prog, initOut, hInit, hModel, hMC, hWork, hSpace⟩

end UL
