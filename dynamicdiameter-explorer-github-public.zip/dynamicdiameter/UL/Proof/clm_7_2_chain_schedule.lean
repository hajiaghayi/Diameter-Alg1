import UL.Stmt.clm_7_2_chain_schedule
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_chain_contraction
import UL.Stmt.claim_C_2_scans
import UL.Stmt.lem_C_2
import UL.Stmt.claim_C_2_space_reclaim
import UL.Proof.clm_7_2_chain_schedule.H1_PolyAndSchedule
import UL.Proof.clm_7_2_chain_schedule.H2_Scans_p34
import UL.Proof.clm_7_2_chain_schedule.H3_Alg4Exec_p34
set_option autoImplicit false

namespace UL

open UL.Proof_clm_7_2_chain_schedule

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_7_2_chain_schedule (h_lem_5_1 : S_lem_5_1) (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction) (h_claim_C_2_scans : S_claim_C_2_scans) (h_lem_C_2 : S_lem_C_2) (h_claim_C_2_space_reclaim : S_claim_C_2_space_reclaim) : S_clm_7_2_chain_schedule := by
  unfold S_clm_7_2_chain_schedule
  intro F_C F_K₀ F_L F_loc hF_C hF_K₀ hF_L hF_loc
  rcases extract_reclaim_constants h_claim_C_2_space_reclaim with
    ⟨C_depth₀, C_batch₀, hCd₀, hCb₀, hReclaim3⟩
  set C_depth : ℝ := max 1 C_depth₀
  set C_batch : ℝ := max 1 C_batch₀
  have hCd : 1 ≤ C_depth := le_max_left 1 C_depth₀
  have hCb : 1 ≤ C_batch := le_max_left 1 C_batch₀
  refine ⟨1 / (64 * 4096), 1 / 2, C_depth, C_batch, 256,
    mkPNodes C_depth,
    mkPWorkFactor C_depth 256 F_C F_K₀ F_L F_loc,
    by norm_num, by norm_num, by norm_num, hCd, hCb, by norm_num,
    mkPNodes_isPoly hCd,
    one_le_mkPNodes hCd,
    mkPWorkFactor_isPoly hCd (by norm_num) hF_C hF_K₀ hF_L hF_loc,
    one_le_mkPWorkFactor hCd (by norm_num) F_C F_K₀ F_L F_loc,
    rfl, ?_⟩
  intro d n ι α C K₀ L hn hα_pos hα_lt hC hEq10
  exact ⟨prove_part1 hα_pos hα_lt hEq10,
         prove_part2 hα_pos hα_lt hEq10,
         prove_part3 hα_pos hα_lt hEq10,
         prove_part4,
         prove_part5 hCd₀ hCb₀ hReclaim3 hn hα_pos hα_lt hC hEq10⟩

end UL
