import Mathlib
import UL.Proof.clm_6_1_adaptive.RaceP32_H4a
set_option autoImplicit false

namespace UL.Proof_clm_6_1_adaptive_RaceP32
open UL.Proof_clm_6_1_adaptive_RaceV30

open UL.Proof_lem_6_3 UL.Proof.lem_6_3.RacerV30 UL.Proof_clm_6_1_adaptive

/-! ### 1. Generic cap-scanning loop `scanCapsStmt` (shared by insert and query) -/

/-- Scans all `f < ℓ` and `u < M₀ = w[1, 4]` for copy `r = w[11, 0]`, setting
`w[11, 5] := ((r * ℓ + f) * M₀ + u) * (d + 1)` before running `evalCapStmt` and testing
`passCondE`, storing `(hitList (pass f)).length` into `w[6, f]` and `(hitList (pass f))[idx]`
into `w[6, ℓ + f * M₀ + idx]`. -/
def scanCapsStmt (ℓ : ℕ) (evalCapStmt : ArithRAMStmt) (passCondE : ArithCondExpr) : ArithRAMStmt :=
  let rE := IntExpr.readHeap 11 (.lit 0)
  let fE := IntExpr.readHeap 11 (.lit 1)
  let uE := IntExpr.readHeap 11 (.lit 2)
  let cntE := IntExpr.readHeap 11 (.lit 3)
  let m0E := IntExpr.readHeap 1 (.lit 4)
  let d1E := IntExpr.add .dim (.lit 1)
  let gIdxE := IntExpr.add (.mul (.add (.mul rE (.lit (ℓ : ℤ))) fE) m0E) uE
  let hitAddrE := IntExpr.add (.lit (ℓ : ℤ)) (.add (.mul fE m0E) cntE)
  seqStmts
    [ .writeWordHeap 11 (.lit 1) (.lit 0),
      .repeatN (.lit (ℓ : ℤ))
        (seqStmts
          [ .writeWordHeap 11 (.lit 3) (.lit 0),
            .writeWordHeap 11 (.lit 2) (.lit 0),
            .repeatN m0E
              (seqStmts
                [ .writeWordHeap 11 (.lit 5) (.mul gIdxE d1E),
                  evalCapStmt,
                  .ite passCondE
                    (seqStmts
                      [ .writeWordHeap 6 hitAddrE uE,
                        .writeWordHeap 11 (.lit 3) (.add cntE (.lit 1)) ])
                    .skip,
                  .writeWordHeap 11 (.lit 2) (.add uE (.lit 1)) ]),
            .writeWordHeap 6 fE cntE,
            .writeWordHeap 11 (.lit 1) (.add fE (.lit 1)) ]) ]

set_option maxHeartbeats 800000 in
theorem exec_scanCapsStmt {d R ℓ M₀ Cap_q : ℕ} (inp : ArithRAMInput d)
    (hR : 1 ≤ R) (hM₀ : 1 ≤ M₀) (r : Fin R)
    (pass : Fin ℓ → Fin M₀ → Prop) [∀ f, DecidablePred (pass f)]
    (evalCapStmt : ArithRAMStmt) (passCondE : ArithCondExpr) (C_cap : ℕ)
    {mem₀ : ArithRAMMemory} (hc₀ : CleanMem mem₀)
    (hw_r : wRead mem₀ 11 0 = (r.val : ℤ))
    (hw_M₀ : wRead mem₀ 1 4 = (M₀ : ℤ))
    (hCap : ∀ (f : Fin ℓ) (u : Fin M₀) (m : ArithRAMMemory),
      CleanMem m →
      extraCells (AdaptiveSW R ℓ M₀ Cap_q d) (AdaptiveSR d R ℓ M₀) m =
        extraCells (AdaptiveSW R ℓ M₀ Cap_q d) (AdaptiveSR d R ℓ M₀) mem₀ →
      wRead m 11 0 = (r.val : ℤ) →
      wRead m 11 1 = (f.val : ℤ) →
      wRead m 11 2 = (u.val : ℤ) →
      wRead m 11 5 = ((((r.val * ℓ + f.val) * M₀ + u.val) * (d + 1) : ℕ) : ℤ) →
      (∀ t i, t ≠ 6 → (t ≠ 11 ∨ i ∉ ([1, 2, 3, 5, 6, 7] : List ℤ)) →
        wRead m t i = wRead mem₀ t i) →
      (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) →
        rRead m t i = rRead mem₀ t i) →
      ∃ m' : ArithRAMMemory,
        ExecStmt inp evalCapStmt m m' C_cap ∧
        extraCells (AdaptiveSW R ℓ M₀ Cap_q d) (AdaptiveSR d R ℓ M₀) m' =
          extraCells (AdaptiveSW R ℓ M₀ Cap_q d) (AdaptiveSR d R ℓ M₀) m ∧
        (evalArithCond inp 0 m' passCondE).1 = decide (pass f u) ∧
        (evalArithCond inp 0 m' passCondE).2 ≤ 70 ∧
        (∀ t i, (t ≠ 11 ∨ (i ≠ 6 ∧ i ≠ 7)) → wRead m' t i = wRead m t i) ∧
        (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) → rRead m' t i = rRead m t i)) :
    let SW := AdaptiveSW R ℓ M₀ Cap_q d
    let SR := AdaptiveSR d R ℓ M₀
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp (scanCapsStmt ℓ evalCapStmt passCondE) mem₀ mem₁
        (20 + ℓ * 40 + ℓ * M₀ * (130 + C_cap)) ∧
      extraCells SW SR mem₁ = extraCells SW SR mem₀ ∧
      (∀ f : Fin ℓ, wRead mem₁ 6 (f.val : ℤ) = ((hitList (pass f)).length : ℤ)) ∧
      (∀ (f : Fin ℓ) (idx : ℕ) (hidx : idx < (hitList (pass f)).length),
        wRead mem₁ 6 ((ℓ + f.val * M₀ + idx : ℕ) : ℤ) = (((hitList (pass f))[idx]'hidx).val : ℤ)) ∧
      (∀ t i, t ≠ 6 → (t ≠ 11 ∨ i ∉ ([1, 2, 3, 5, 6, 7] : List ℤ)) →
        wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) →
        rRead mem₁ t i = rRead mem₀ t i) := by
  intro SW SR
  let rE := IntExpr.readHeap 11 (.lit 0)
  let fE := IntExpr.readHeap 11 (.lit 1)
  let uE := IntExpr.readHeap 11 (.lit 2)
  let cntE := IntExpr.readHeap 11 (.lit 3)
  let m0E := IntExpr.readHeap 1 (.lit 4)
  let d1E := IntExpr.add .dim (.lit 1)
  let gIdxE := IntExpr.add (.mul (.add (.mul rE (.lit (ℓ : ℤ))) fE) m0E) uE
  let hitAddrE := IntExpr.add (.lit (ℓ : ℤ)) (.add (.mul fE m0E) cntE)

  rcases exec_wSet_sw SW SR inp hc₀ 11 (.lit 1) 1 (mem_ASW_11 (i := 1) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m1, hs1, hex1, hw1_1, hw1_ne, hr1⟩

  let innerBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 5) (.mul gIdxE d1E),
        evalCapStmt,
        .ite passCondE
          (seqStmts
            [ .writeWordHeap 6 hitAddrE uE,
              .writeWordHeap 11 (.lit 3) (.add cntE (.lit 1)) ])
          .skip,
        .writeWordHeap 11 (.lit 2) (.add uE (.lit 1)) ]

  let outerBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 3) (.lit 0),
        .writeWordHeap 11 (.lit 2) (.lit 0),
        .repeatN m0E innerBody,
        .writeWordHeap 6 fE cntE,
        .writeWordHeap 11 (.lit 1) (.add fE (.lit 1)) ]

  let OuterInv : ℕ → ArithRAMMemory → Prop := fun f m =>
    extraCells SW SR m = extraCells SW SR mem₀ ∧
    wRead m 11 1 = (f : ℤ) ∧
    (∀ f' : Fin ℓ, f'.val < f → wRead m 6 (f'.val : ℤ) = ((hitList (pass f')).length : ℤ)) ∧
    (∀ (f' : Fin ℓ), f'.val < f → ∀ (idx : ℕ) (hidx : idx < (hitList (pass f')).length),
      wRead m 6 ((ℓ + f'.val * M₀ + idx : ℕ) : ℤ) = (((hitList (pass f'))[idx]'hidx).val : ℤ)) ∧
    (∀ t i, t ≠ 6 → (t ≠ 11 ∨ i ∉ ([1, 2, 3, 5, 6, 7] : List ℤ)) →
      wRead m t i = wRead mem₀ t i) ∧
    (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) →
      rRead m t i = rRead mem₀ t i)

  have hOuter₀ : OuterInv 0 m1 := by
    refine ⟨hex1, hw1_1, fun _ h => by omega, fun _ h => by omega, ?_, fun t i _ => hr1 t i⟩
    intro t i ht hi
    exact hw1_ne t i (by
      rcases hi with h11 | hnot
      · exact Or.inl h11
      · exact Or.inr fun h1 => hnot (by simp [h1]))

  rcases exec_repeatN (inp := inp) (.lit (ℓ : ℤ)) outerBody ℓ 3 (40 + M₀ * (130 + C_cap))
    OuterInv hs1.2.1 hOuter₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun f hf_lt mf hcmf ⟨hex_mf, hwf_mf, hcnt_prev, hhit_prev, hwm_mf, hrm_mf⟩ => by
      let fFin : Fin ℓ := ⟨f, hf_lt⟩
      have hℓ_pos : 1 ≤ ℓ := by omega
      -- 1. w[11, 3] := 0
      rcases exec_wSet_sw SW SR inp hcmf 11 (.lit 3) 3 (mem_ASW_11 (i := 3) (by omega))
        (.lit 0) 0 4
        (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
        with ⟨ma1, sa1, hexa1, hwa1_3, hwa1_ne, hra1⟩
      -- 2. w[11, 2] := 0
      rcases exec_wSet_sw SW SR inp sa1.2.1 11 (.lit 2) 2 (mem_ASW_11 (i := 2) (by omega))
        (.lit 0) 0 4
        (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
        with ⟨ma2, sa2, hexa2, hwa2_2, hwa2_ne, hra2⟩

      let InnerInv : ℕ → ArithRAMMemory → Prop := fun u m =>
        extraCells SW SR m = extraCells SW SR mem₀ ∧
        wRead m 11 1 = (f : ℤ) ∧
        wRead m 11 2 = (u : ℤ) ∧
        wRead m 11 3 = ((hitPrefix (pass fFin) u).length : ℤ) ∧
        (∀ (idx : ℕ) (hidx : idx < (hitPrefix (pass fFin) u).length),
          wRead m 6 ((ℓ + f * M₀ + idx : ℕ) : ℤ) =
            (((hitPrefix (pass fFin) u)[idx]'hidx).val : ℤ)) ∧
        (∀ f' : Fin ℓ, f'.val < f → wRead m 6 (f'.val : ℤ) = ((hitList (pass f')).length : ℤ)) ∧
        (∀ (f' : Fin ℓ), f'.val < f → ∀ (idx : ℕ) (hidx : idx < (hitList (pass f')).length),
          wRead m 6 ((ℓ + f'.val * M₀ + idx : ℕ) : ℤ) = (((hitList (pass f'))[idx]'hidx).val : ℤ)) ∧
        (∀ t i, t ≠ 6 → (t ≠ 11 ∨ i ∉ ([1, 2, 3, 5, 6, 7] : List ℤ)) →
          wRead m t i = wRead mem₀ t i) ∧
        (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) →
          rRead m t i = rRead mem₀ t i)

      have hInner₀ : InnerInv 0 ma2 := by
        refine ⟨hexa2.trans (hexa1.trans hex_mf),
          (hwa2_ne 11 1 (Or.inr (by decide))).trans ((hwa1_ne 11 1 (Or.inr (by decide))).trans hwf_mf),
          hwa2_2,
          (hwa2_ne 11 3 (Or.inr (by decide))).trans (by simpa [hitPrefix] using hwa1_3),
          fun _ h => by simp [hitPrefix] at h,
          fun f' hf' => (hwa2_ne 6 _ (Or.inl (by decide))).trans
            ((hwa1_ne 6 _ (Or.inl (by decide))).trans (hcnt_prev f' hf')),
          fun f' hf' idx hidx => (hwa2_ne 6 _ (Or.inl (by decide))).trans
            ((hwa1_ne 6 _ (Or.inl (by decide))).trans (hhit_prev f' hf' idx hidx)),
          ?_,
          fun t i h => (hra2 t i).trans ((hra1 t i).trans (hrm_mf t i h))⟩
        intro t i ht hi
        have hne2 : t ≠ 11 ∨ i ≠ 2 := by
          rcases hi with h11 | hnot
          · exact Or.inl h11
          · exact Or.inr fun h2 => hnot (by simp [h2])
        have hne3 : t ≠ 11 ∨ i ≠ 3 := by
          rcases hi with h11 | hnot
          · exact Or.inl h11
          · exact Or.inr fun h3 => hnot (by simp [h3])
        exact (hwa2_ne t i hne2).trans ((hwa1_ne t i hne3).trans (hwm_mf t i ht hi))

      have hwM0_ma2 : ma2.words.read (.heap 1 4) = (M₀ : ℤ) :=
        (hInner₀.2.2.2.2.2.2.2.1 1 4 (by decide) (Or.inl (by decide))).trans hw_M₀

      rcases exec_repeatN (inp := inp) m0E innerBody M₀ 5 (130 + C_cap)
        InnerInv sa2.2.1 hInner₀
        (by simp [evalIntExpr, m0E, hwM0_ma2])
        (by simp [evalIntExpr, m0E])
        (fun u hu_lt mu hcmu
          ⟨hex_u, hwf_u, hwu_u, hwcnt_u, hhit_u, hcnt_fprev, hhit_fprev, hwm_u, hrm_u⟩ => by
          let uFin : Fin M₀ := ⟨u, hu_lt⟩
          let L_prev := hitPrefix (pass fFin) u
          let cnt_u := L_prev.length
          have hcnt_le_u : cnt_u ≤ u := hitPrefix_length_le (pass fFin) u
          have hwr_u : mu.words.read (.heap 11 0) = (r.val : ℤ) :=
            (hwm_u 11 0 (by decide) (Or.inr (by decide))).trans hw_r
          have hwM0_u : mu.words.read (.heap 1 4) = (M₀ : ℤ) :=
            (hwm_u 1 4 (by decide) (Or.inl (by decide))).trans hw_M₀
          have hwf_u' : mu.words.read (.heap 11 1) = (f : ℤ) := hwf_u
          have hwu_u' : mu.words.read (.heap 11 2) = (u : ℤ) := hwu_u

          -- u1. w[11, 5] := ((r * ℓ + f) * M₀ + u) * (d + 1)
          let baseNat : ℕ := ((r.val * ℓ + f) * M₀ + u) * (d + 1)
          have hbase_eval : (evalIntExpr inp.toWordView 0 mu.words (.mul gIdxE d1E)).1 =
              (baseNat : ℤ) := by
            simp only [evalIntExpr, gIdxE, d1E, rE, fE, uE, m0E, hwr_u, hwf_u', hwu_u', hwM0_u,
              baseNat]
            push_cast
            ring
          rcases exec_wSet_sw SW SR inp hcmu 11 (.lit 5) 5 (mem_ASW_11 (i := 5) (by omega))
            (.mul gIdxE d1E) (baseNat : ℤ) 20
            (by simp [evalIntExpr]) hbase_eval (by simp [evalIntExpr, gIdxE, d1E, rE, fE, uE, m0E])
            with ⟨mu1, su1, hexu1, hwu1_5, hwu1_ne, hru1⟩

          have hwu1_0 : wRead mu1 11 0 = (r.val : ℤ) :=
            (hwu1_ne 11 0 (Or.inr (by decide))).trans hwr_u
          have hwu1_1 : wRead mu1 11 1 = (fFin.val : ℤ) :=
            (hwu1_ne 11 1 (Or.inr (by decide))).trans hwf_u
          have hwu1_2 : wRead mu1 11 2 = (uFin.val : ℤ) :=
            (hwu1_ne 11 2 (Or.inr (by decide))).trans hwu_u
          have hwu1_pres : ∀ t i, t ≠ 6 → (t ≠ 11 ∨ i ∉ ([1, 2, 3, 5, 6, 7] : List ℤ)) →
              wRead mu1 t i = wRead mem₀ t i := by
            intro t i ht hi
            have hne5 : t ≠ 11 ∨ i ≠ 5 := by
              rcases hi with h11 | hnot
              · exact Or.inl h11
              · exact Or.inr fun h5 => hnot (by simp [h5])
            exact (hwu1_ne t i hne5).trans (hwm_u t i ht hi)
          have hru1_pres : ∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) →
              rRead mu1 t i = rRead mem₀ t i :=
            fun t i h => (hru1 t i).trans (hrm_u t i h)

          -- u2. evalCapStmt
          rcases hCap fFin uFin mu1 su1.2.1 (hexu1.trans hex_u)
            hwu1_0 hwu1_1 hwu1_2 hwu1_5 hwu1_pres hru1_pres
            with ⟨mu2, su2, hexu2, hcond_v, hcond_c, hwu2_ne, hru2_ne⟩

          have hwu2_1 : wRead mu2 11 1 = (f : ℤ) :=
            (hwu2_ne 11 1 (Or.inr (by decide))).trans hwu1_1
          have hwu2_2 : wRead mu2 11 2 = (u : ℤ) :=
            (hwu2_ne 11 2 (Or.inr (by decide))).trans hwu1_2
          have hwu2_3 : wRead mu2 11 3 = (cnt_u : ℤ) :=
            (hwu2_ne 11 3 (Or.inr (by decide))).trans
              ((hwu1_ne 11 3 (Or.inr (by decide))).trans hwcnt_u)
          have hwu2_M0 : wRead mu2 1 4 = (M₀ : ℤ) :=
            (hwu2_ne 1 4 (Or.inl (by decide))).trans
              ((hwu1_ne 1 4 (Or.inl (by decide))).trans hwM0_u)
          have hwu2_pres : ∀ t i, t ≠ 6 → (t ≠ 11 ∨ i ∉ ([1, 2, 3, 5, 6, 7] : List ℤ)) →
              wRead mu2 t i = wRead mem₀ t i := by
            intro t i ht hi
            have hne67 : t ≠ 11 ∨ (i ≠ 6 ∧ i ≠ 7) := by
              rcases hi with h11 | hnot
              · exact Or.inl h11
              · exact Or.inr ⟨fun h6 => hnot (by simp [h6]), fun h7 => hnot (by simp [h7])⟩
            exact (hwu2_ne t i hne67).trans (hwu1_pres t i ht hi)
          have hru2_pres : ∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) →
              rRead mu2 t i = rRead mem₀ t i :=
            fun t i h => (hru2_ne t i h).trans (hru1_pres t i h)

          -- u3. .ite passCondE
          let tStmt : ArithRAMStmt :=
            seqStmts
              [ .writeWordHeap 6 hitAddrE uE,
                .writeWordHeap 11 (.lit 3) (.add cntE (.lit 1)) ]
          have su3_all : ∃ mu3 : ArithRAMMemory,
              ExecStmt inp (.ite passCondE tStmt .skip) mu2 mu3 95 ∧
              extraCells SW SR mu3 = extraCells SW SR mem₀ ∧
              wRead mu3 11 1 = (f : ℤ) ∧
              wRead mu3 11 2 = (u : ℤ) ∧
              wRead mu3 11 3 = ((hitPrefix (pass fFin) (u + 1)).length : ℤ) ∧
              (∀ (idx : ℕ) (hidx : idx < (hitPrefix (pass fFin) (u + 1)).length),
                wRead mu3 6 ((ℓ + f * M₀ + idx : ℕ) : ℤ) =
                  (((hitPrefix (pass fFin) (u + 1))[idx]'hidx).val : ℤ)) ∧
              (∀ f' : Fin ℓ, f'.val < f → wRead mu3 6 (f'.val : ℤ) = ((hitList (pass f')).length : ℤ)) ∧
              (∀ (f' : Fin ℓ), f'.val < f → ∀ (idx : ℕ) (hidx : idx < (hitList (pass f')).length),
                wRead mu3 6 ((ℓ + f'.val * M₀ + idx : ℕ) : ℤ) = (((hitList (pass f'))[idx]'hidx).val : ℤ)) ∧
              (∀ t i, t ≠ 6 → (t ≠ 11 ∨ i ∉ ([1, 2, 3, 5, 6, 7] : List ℤ)) →
                wRead mu3 t i = wRead mem₀ t i) ∧
              (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) →
                rRead mu3 t i = rRead mem₀ t i) := by
            by_cases hpass : pass fFin uFin
            · have hcond_t : (evalArithCond inp 0 mu2 passCondE).1 = true := by
                rw [hcond_v, decide_eq_true_eq]; exact hpass
              let addrNat : ℕ := ℓ + f * M₀ + cnt_u
              have haddr_lt : addrNat < 2 * R * ℓ * M₀ + 1 := by
                dsimp [addrNat]
                have hfM : f * M₀ + cnt_u < ℓ * M₀ := by
                  calc f * M₀ + cnt_u < f * M₀ + M₀ := by omega
                    _ = (f + 1) * M₀ := by ring
                    _ ≤ ℓ * M₀ := Nat.mul_le_mul_right M₀ (by omega)
                have hℓM : ℓ ≤ ℓ * M₀ := Nat.le_mul_of_pos_right ℓ hM₀
                have h1R : 1 * (ℓ * M₀) ≤ R * (ℓ * M₀) := Nat.mul_le_mul_right _ hR
                nlinarith
              have hwu2_1' : mu2.words.read (.heap 11 1) = (f : ℤ) := hwu2_1
              have hwu2_2' : mu2.words.read (.heap 11 2) = (u : ℤ) := hwu2_2
              have hwu2_3' : mu2.words.read (.heap 11 3) = (cnt_u : ℤ) := hwu2_3
              have hwu2_M0' : mu2.words.read (.heap 1 4) = (M₀ : ℤ) := hwu2_M0
              rcases exec_wSet_sw SW SR inp su2.2.1 6 hitAddrE (addrNat : ℤ)
                (mem_ASW_6 haddr_lt) uE (u : ℤ) 15
                (by simp only [evalIntExpr, hitAddrE, fE, m0E, cntE, hwu2_1', hwu2_M0', hwu2_3', addrNat]; push_cast; ring)
                (by simp [evalIntExpr, uE, hwu2_2'])
                (by simp [evalIntExpr, hitAddrE, fE, m0E, cntE, uE])
                with ⟨mt1, st1, hext1, hwt1_6, hwt1_ne, hrt1⟩
              have hwt1_3 : mt1.words.read (.heap 11 3) = (cnt_u : ℤ) :=
                (hwt1_ne 11 3 (Or.inl (by decide))).trans hwu2_3
              rcases exec_wSet_sw SW SR inp st1.2.1 11 (.lit 3) 3 (mem_ASW_11 (i := 3) (by omega))
                (.add cntE (.lit 1)) (((cnt_u + 1 : ℕ) : ℤ)) 10
                (by simp [evalIntExpr])
                (by simp [evalIntExpr, cntE, hwt1_3])
                (by simp [evalIntExpr, cntE])
                with ⟨mt2, st2, hext2, hwt2_3, hwt2_ne, hrt2⟩
              have st_seq : ExecStmt inp tStmt mu2 mt2 25 := by
                unfold tStmt seqStmts
                exact ExecStmt.seq st1 st2
              cases hevc : evalArithCond inp 0 mu2 passCondE with
              | mk bv uc =>
                rw [hevc] at hcond_t hcond_c
                dsimp at hcond_t hcond_c
                subst bv
                have site := (ExecStmt.ite_true (fB := .skip) hevc le_rfl st_seq).mono_cost (by omega : uc + 25 ≤ 95)
                have hpref_next : hitPrefix (pass fFin) (u + 1) = L_prev ++ [uFin] := by
                  simp [hitPrefix, hu_lt, hpass, L_prev, uFin]
                refine ⟨mt2, site, hext2.trans (hext1.trans (hexu2.trans (hexu1.trans hex_u))),
                  (hwt2_ne 11 1 (Or.inr (by decide))).trans ((hwt1_ne 11 1 (Or.inl (by decide))).trans hwu2_1),
                  (hwt2_ne 11 2 (Or.inr (by decide))).trans ((hwt1_ne 11 2 (Or.inl (by decide))).trans hwu2_2),
                  by rw [hpref_next, List.length_append, List.length_singleton]; exact hwt2_3,
                  ?_, ?_, ?_, ?_,
                  fun t i h => (hrt2 t i).trans ((hrt1 t i).trans (hru2_pres t i h))⟩
                · intro idx hidx
                  have hget_congr : ∀ (xs ys : List (Fin M₀)) (heq : xs = ys) (h1 : idx < xs.length),
                      xs[idx]'h1 = ys[idx]'(heq ▸ h1) := by
                    intro xs ys heq h1; subst heq; rfl
                  rw [hget_congr _ _ hpref_next hidx]
                  have hidx' : idx < (L_prev ++ [uFin]).length := hpref_next ▸ hidx
                  have hidx_len : idx < L_prev.length + 1 := by
                    simpa [List.length_append, List.length_singleton] using hidx'
                  rw [hwt2_ne 6 _ (Or.inl (by decide))]
                  rcases Nat.lt_succ_iff_lt_or_eq.mp hidx_len with hlt | rfl
                  · rw [List.getElem_append_left hlt]
                    have hne_addr : ((ℓ + f * M₀ + idx : ℕ) : ℤ) ≠ (addrNat : ℤ) := by
                      dsimp [addrNat]; omega
                    rw [hwt1_ne 6 _ (Or.inr hne_addr), hwu2_ne 6 _ (Or.inl (by decide)),
                        hwu1_ne 6 _ (Or.inl (by decide))]
                    exact hhit_u idx hlt
                  · have hge : L_prev.length ≤ cnt_u := le_rfl
                    rw [List.getElem_append_right hge]
                    simp only [List.getElem_singleton]
                    exact hwt1_6
                · intro f' hf'
                  have hne_addr : (f'.val : ℤ) ≠ (addrNat : ℤ) := by
                    have : f'.val < ℓ := f'.isLt
                    dsimp [addrNat]; omega
                  rw [hwt2_ne 6 _ (Or.inl (by decide)), hwt1_ne 6 _ (Or.inr hne_addr),
                      hwu2_ne 6 _ (Or.inl (by decide)), hwu1_ne 6 _ (Or.inl (by decide))]
                  exact hcnt_fprev f' hf'
                · intro f' hf' idx hidx
                  have hidx_le : idx < M₀ := lt_of_lt_of_le hidx (hitList_length_le (pass f'))
                  have hlt_addr : f'.val * M₀ + idx < f * M₀ + cnt_u := by
                    calc f'.val * M₀ + idx < f'.val * M₀ + M₀ := by omega
                      _ = (f'.val + 1) * M₀ := by ring
                      _ ≤ f * M₀ := Nat.mul_le_mul_right M₀ (by omega)
                      _ ≤ f * M₀ + cnt_u := Nat.le_add_right _ _
                  have hne_addr : ((ℓ + f'.val * M₀ + idx : ℕ) : ℤ) ≠ (addrNat : ℤ) := by
                    dsimp [addrNat]; omega
                  rw [hwt2_ne 6 _ (Or.inl (by decide)), hwt1_ne 6 _ (Or.inr hne_addr),
                      hwu2_ne 6 _ (Or.inl (by decide)), hwu1_ne 6 _ (Or.inl (by decide))]
                  exact hhit_fprev f' hf' idx hidx
                · intro t i ht hi
                  have hne3 : t ≠ 11 ∨ i ≠ 3 := by
                    rcases hi with h11 | hnot
                    · exact Or.inl h11
                    · exact Or.inr fun h3 => hnot (by simp [h3])
                  exact (hwt2_ne t i hne3).trans ((hwt1_ne t i (Or.inl ht)).trans (hwu2_pres t i ht hi))
            · have hcond_f : (evalArithCond inp 0 mu2 passCondE).1 = false := by
                rw [hcond_v, decide_eq_false_iff_not]; exact hpass
              cases hevc : evalArithCond inp 0 mu2 passCondE with
              | mk bv uc =>
                rw [hevc] at hcond_f hcond_c
                dsimp at hcond_f hcond_c
                subst bv
                have site := (ExecStmt.ite_false (tB := tStmt) hevc le_rfl (ExecStmt.skip inp su2.2.1)).mono_cost (by omega : uc + 1 ≤ 95)
                have hpref_next : hitPrefix (pass fFin) (u + 1) = L_prev := by
                  simp [hitPrefix, hu_lt, hpass, L_prev, uFin]
                refine ⟨mu2, site, hexu2.trans (hexu1.trans hex_u), hwu2_1, hwu2_2,
                  by rw [hpref_next]; exact hwu2_3,
                  fun idx hidx => by
                    have hget_congr : ∀ (xs ys : List (Fin M₀)) (heq : xs = ys) (h1 : idx < xs.length),
                        xs[idx]'h1 = ys[idx]'(heq ▸ h1) := by
                      intro xs ys heq h1; subst heq; rfl
                    rw [hget_congr _ _ hpref_next hidx]
                    rw [hwu2_ne 6 _ (Or.inl (by decide)), hwu1_ne 6 _ (Or.inl (by decide))]
                    exact hhit_u idx (by simpa [hpref_next, L_prev] using hidx),
                  fun f' hf' => by
                    rw [hwu2_ne 6 _ (Or.inl (by decide)), hwu1_ne 6 _ (Or.inl (by decide))]
                    exact hcnt_fprev f' hf',
                  fun f' hf' idx hidx => by
                    rw [hwu2_ne 6 _ (Or.inl (by decide)), hwu1_ne 6 _ (Or.inl (by decide))]
                    exact hhit_fprev f' hf' idx hidx,
                  hwu2_pres, hru2_pres⟩

          rcases su3_all with
            ⟨mu3, su3, hex_u3, hwf_u3, hwu_u3, hwcnt_u3, hhit_u3, hcnt_fp3, hhit_fp3, hwm_u3, hrm_u3⟩

          -- u4. w[11, 2] := u + 1
          have hwu_u3' : mu3.words.read (.heap 11 2) = (u : ℤ) := hwu_u3
          rcases exec_wSet_sw SW SR inp su3.2.1 11 (.lit 2) 2 (mem_ASW_11 (i := 2) (by omega))
            (.add uE (.lit 1)) (((u + 1 : ℕ) : ℤ)) 10
            (by simp [evalIntExpr]) (by simp [evalIntExpr, uE, hwu_u3']) (by simp [evalIntExpr, uE])
            with ⟨mu4, su4, hex_u4, hwu_u4, hwu4_ne, hru4⟩

          have sInnerStep : ExecStmt inp innerBody mu mu4 (130 + C_cap) := by
            unfold innerBody seqStmts
            exact (ExecStmt.seq su1 (ExecStmt.seq su2 (ExecStmt.seq su3 su4))).mono_cost (by omega)

          refine ⟨mu4, sInnerStep, hex_u4.trans hex_u3,
            (hwu4_ne 11 1 (Or.inr (by decide))).trans hwf_u3,
            hwu_u4,
            (hwu4_ne 11 3 (Or.inr (by decide))).trans hwcnt_u3,
            fun idx hidx => (hwu4_ne 6 _ (Or.inl (by decide))).trans (hhit_u3 idx hidx),
            fun f' hf' => (hwu4_ne 6 _ (Or.inl (by decide))).trans (hcnt_fp3 f' hf'),
            fun f' hf' idx hidx => (hwu4_ne 6 _ (Or.inl (by decide))).trans (hhit_fp3 f' hf' idx hidx),
            ?_,
            fun t i h => (hru4 t i).trans (hrm_u3 t i h)⟩
          intro t i ht hi
          have hne2 : t ≠ 11 ∨ i ≠ 2 := by
            rcases hi with h11 | hnot
            · exact Or.inl h11
            · exact Or.inr fun h2 => hnot (by simp [h2])
          exact (hwu4_ne t i hne2).trans (hwm_u3 t i ht hi))
        with ⟨ma3, ⟨hex_a3, hwf_a3, _, hwcnt_a3, hhit_a3, hcnt_fp_a3, hhit_fp_a3, hwm_a3, hrm_a3⟩, sInnerLoop⟩

      -- 4. w[6, f] := w[11, 3]
      have hf6_lt : f < 2 * R * ℓ * M₀ + 1 := by
        have hℓM : ℓ ≤ ℓ * M₀ := Nat.le_mul_of_pos_right ℓ hM₀
        have h1R : 1 * (ℓ * M₀) ≤ R * (ℓ * M₀) := Nat.mul_le_mul_right _ hR
        nlinarith
      have hwf_a3' : ma3.words.read (.heap 11 1) = (f : ℤ) := hwf_a3
      have hwcnt_a3' : ma3.words.read (.heap 11 3) = ((hitList (pass fFin)).length : ℤ) := hwcnt_a3
      rcases exec_wSet_sw SW SR inp sInnerLoop.2.1 6 fE (f : ℤ) (mem_ASW_6 hf6_lt)
        cntE ((hitList (pass fFin)).length : ℤ) 10
        (by simp [evalIntExpr, fE, hwf_a3'])
        (by simp [evalIntExpr, cntE, hwcnt_a3'])
        (by simp [evalIntExpr, fE, cntE])
        with ⟨ma4, sa4, hex_a4, hwa4_6, hwa4_ne, hra4⟩

      -- 5. w[11, 1] := f + 1
      have hwf_a4' : ma4.words.read (.heap 11 1) = (f : ℤ) :=
        (hwa4_ne 11 1 (Or.inl (by decide))).trans hwf_a3
      rcases exec_wSet_sw SW SR inp sa4.2.1 11 (.lit 1) 1 (mem_ASW_11 (i := 1) (by omega))
        (.add fE (.lit 1)) (((f + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, fE, hwf_a4']) (by simp [evalIntExpr, fE])
        with ⟨ma5, sa5, hex_a5, hwa5_1, hwa5_ne, hra5⟩

      have sOuterStep : ExecStmt inp outerBody mf ma5 (40 + M₀ * (130 + C_cap)) := by
        unfold outerBody seqStmts
        exact (ExecStmt.seq sa1 (ExecStmt.seq sa2 (ExecStmt.seq sInnerLoop (ExecStmt.seq sa4 sa5)))).mono_cost (by omega)

      refine ⟨ma5, sOuterStep, hex_a5.trans (hex_a4.trans hex_a3), hwa5_1, ?_, ?_, ?_,
        fun t i h => (hra5 t i).trans ((hra4 t i).trans (hrm_a3 t i h))⟩
      · intro f' hf'
        rw [hwa5_ne 6 _ (Or.inl (by decide))]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hf' with hlt | heq
        · rw [hwa4_ne 6 _ (Or.inr (by omega))]
          exact hcnt_fp_a3 f' hlt
        · have hf'_eq : f' = fFin := Fin.ext heq
          subst hf'_eq
          exact hwa4_6
      · intro f' hf' idx hidx
        have hne_f : ((ℓ + f'.val * M₀ + idx : ℕ) : ℤ) ≠ (f : ℤ) := by omega
        rw [hwa5_ne 6 _ (Or.inl (by decide)), hwa4_ne 6 _ (Or.inr hne_f)]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hf' with hlt | heq
        · exact hhit_fp_a3 f' hlt idx hidx
        · have hf'_eq : f' = fFin := Fin.ext heq
          subst hf'_eq
          exact hhit_a3 idx hidx
      · intro t i ht hi
        have hne1 : t ≠ 11 ∨ i ≠ 1 := by
          rcases hi with h11 | hnot
          · exact Or.inl h11
          · exact Or.inr fun h1 => hnot (by simp [h1])
        exact (hwa5_ne t i hne1).trans ((hwa4_ne t i (Or.inl ht)).trans (hwm_a3 t i ht hi)))
    with ⟨mem₁, ⟨hex₁, _, hcnt₁, hhit₁, hwm₁, hrm₁⟩, sOuterLoop⟩

  have sTot : ExecStmt inp (scanCapsStmt ℓ evalCapStmt passCondE) mem₀ mem₁
      (20 + ℓ * 40 + ℓ * M₀ * (130 + C_cap)) := by
    unfold scanCapsStmt seqStmts
    have h_exp : ℓ * (40 + M₀ * (130 + C_cap)) = ℓ * 40 + ℓ * M₀ * (130 + C_cap) := by ring
    exact (ExecStmt.seq hs1 sOuterLoop).mono_cost (by omega)
  exact ⟨mem₁, sTot, hex₁, fun f => hcnt₁ f f.isLt, fun f idx hidx => hhit₁ f f.isLt idx hidx,
    hwm₁, hrm₁⟩

/-! ### 2. `insertBirthPtProg` and `exec_insertBirthPtProg` -/

def dataEvalCapStmt : ArithRAMStmt :=
  let cE := IntExpr.readHeap 11 (.lit 6)
  let baseE := IntExpr.readHeap 11 (.lit 5)
  seqStmts
    [ .writeWordHeap 11 (.lit 6) (.lit 0),
      .writeRealHeap 17 (.lit 11) (.ofInt (.lit 0)),
      .repeatN (.add .dim (.lit 1))
        (seqStmts
          [ .writeRealHeap 17 (.lit 11)
              (.add (.readRealHeap 17 (.lit 11))
                (.mul (.readRealHeap 2 (.add baseE cE))
                      (.readRealHeap 3 cE))),
            .writeWordHeap 11 (.lit 6) (.add cE (.lit 1)) ]) ]

def dataPassCondE : ArithCondExpr :=
  .realLe (.readRealHeap 1 (.lit 1)) (.readRealHeap 17 (.lit 11))

def insertBirthPtProg (ℓ : ℕ) : ArithRAMStmt :=
  let jE := IntExpr.readHeap 11 (.lit 20)
  let cE := IntExpr.readHeap 11 (.lit 6)
  let rE := IntExpr.readHeap 11 (.lit 0)
  let mE := IntExpr.readHeap 1 (.lit 1)
  let rCntE := IntExpr.readHeap 1 (.lit 2)
  let m0PowE := IntExpr.readHeap 1 (.lit 5)
  let sCntE := IntExpr.readHeap 11 (.lit 8)
  let sE := IntExpr.readHeap 11 (.lit 16)
  let pairE := IntExpr.readHeap 11 (.lit 22)
  seqStmts
    [ -- 1. Read `j := intParam 0` and build `padData (u_pts (dec j))` in `r[3, 0..d]`
      .writeWordHeap 11 (.lit 20) (.intParam (.lit 0)),
      .writeWordHeap 11 (.lit 6) (.lit 0),
      .repeatN .dim
        (seqStmts
          [ .writeRealHeap 3 cE
              (.mul (.readRealHeap 1 (.lit 2)) (.activePtCoord jE cE)),
            .writeWordHeap 11 (.lit 6) (.add cE (.lit 1)) ]),
      .writeRealHeap 3 .dim (.readRealHeap 1 (.lit 3)),
      -- 2. Loop over copies `r = 0 .. R - 1`
      .writeWordHeap 11 (.lit 0) (.lit 0),
      .repeatN rCntE
        (seqStmts
          [ scanCapsStmt ℓ dataEvalCapStmt dataPassCondE,
            computeCappedProdStmt ℓ 3,
            .writeWordHeap 11 (.lit 22) (.add (.mul rE mE) jE),
            .writeWordHeap 21 pairE sCntE,
            .writeWordHeap 11 (.lit 16) (.lit 0),
            .repeatN sCntE
              (seqStmts
                [ .writeWordHeap 11 (.lit 4) sE,
                  decodeTupleCodeStmt ℓ,
                  .writeWordHeap 11 (.lit 18) (.add (.mul rE m0PowE) (.readHeap 11 (.lit 11))),
                  bucketAppendStepStmt,
                  .writeWordHeap 11 (.lit 16) (.add sE (.lit 1)) ]),
            .writeWordHeap 11 (.lit 0) (.add rE (.lit 1)) ]) ]

theorem padData_coord_castSucc {d : ℕ} (A B : ℚ) (u : EuclideanSpace ℝ (Fin d)) (c : Fin d) :
    euclideanCoord (WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u)) (B : ℝ))) c.castSucc =
      (A : ℝ) * euclideanCoord u c := by
  simp [euclideanCoord, WithLp.equiv_apply, Fin.snoc_castSucc]

theorem padData_coord_last {d : ℕ} (A B : ℚ) (u : EuclideanSpace ℝ (Fin d)) :
    euclideanCoord (WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u)) (B : ℝ))) (Fin.last d) =
      (B : ℝ) := by
  simp [euclideanCoord, WithLp.equiv_apply, Fin.snoc_last]

open Classical in
theorem exec_dataEvalCapStmt {d R ℓ M₀ Cap_q : ℕ} (inp : ArithRAMInput d)
    (r : Fin R) (f : Fin ℓ) (u : Fin M₀) (t_val : ℝ)
    (G p : EuclideanSpace ℝ (Fin (d + 1)))
    {m : ArithRAMMemory} (hcm : CleanMem m)
    (hw5 : wRead m 11 5 = ((((r.val * ℓ + f.val) * M₀ + u.val) * (d + 1) : ℕ) : ℤ))
    (hr_t : rRead m 1 1 = t_val)
    (hr_G : ∀ coord : Fin (d + 1),
      rRead m 2 (((r.val * (ℓ * M₀) + (capIdx f u).val) * (d + 1) + coord.val : ℕ) : ℤ) =
        euclideanCoord G coord)
    (hr_p : ∀ coord : Fin (d + 1), rRead m 3 (coord.val : ℤ) = euclideanCoord p coord) :
    let SW := AdaptiveSW R ℓ M₀ Cap_q d
    let SR := AdaptiveSR d R ℓ M₀
    ∃ m' : ArithRAMMemory,
      ExecStmt inp dataEvalCapStmt m m' (20 + (d + 1) * 30) ∧
      extraCells SW SR m' = extraCells SW SR m ∧
      (evalArithCond inp 0 m' dataPassCondE).1 = decide (gaussianDataTest t_val G p) ∧
      (evalArithCond inp 0 m' dataPassCondE).2 ≤ 70 ∧
      (∀ t i, (t ≠ 11 ∨ (i ≠ 6 ∧ i ≠ 7)) → wRead m' t i = wRead m t i) ∧
      (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) → rRead m' t i = rRead m t i) := by
  classical
  intro SW SR
  let cE := IntExpr.readHeap 11 (.lit 6)
  let baseE := IntExpr.readHeap 11 (.lit 5)
  let baseNat : ℕ := ((r.val * ℓ + f.val) * M₀ + u.val) * (d + 1)
  have hbase_eq : baseNat = (r.val * (ℓ * M₀) + (capIdx f u).val) * (d + 1) := by
    dsimp [baseNat, capIdx]; ring

  rcases exec_wSet_sw SW SR inp hcm 11 (.lit 6) 6 (mem_ASW_11 (i := 6) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m1, s1, hex1, hw1_6, hw1_ne, hr1⟩
  rcases exec_rSet_sr SW SR inp s1.2.1 17 (.lit 11) 11 (mem_ASR_17 (i := 11) (by omega))
    (.ofInt (.lit 0)) 0 6
    (by simp [evalIntExpr]) (by simp [evalRealExpr, evalIntExpr]) (by simp [evalRealExpr, evalIntExpr])
    with ⟨m2, s2, hex2, hr2_11, hw2, hr2_ne⟩

  let fG : ℕ → ℝ := fun c => if hc : c < d + 1 then euclideanCoord G ⟨c, hc⟩ else 0
  let fp : ℕ → ℝ := fun c => if hc : c < d + 1 then euclideanCoord p ⟨c, hc⟩ else 0
  let body : ArithRAMStmt :=
    seqStmts
      [ .writeRealHeap 17 (.lit 11)
          (.add (.readRealHeap 17 (.lit 11))
            (.mul (.readRealHeap 2 (.add baseE cE)) (.readRealHeap 3 cE))),
        .writeWordHeap 11 (.lit 6) (.add cE (.lit 1)) ]

  let Inv : ℕ → ArithRAMMemory → Prop := fun c mc =>
    extraCells SW SR mc = extraCells SW SR m ∧
    wRead mc 11 6 = (c : ℤ) ∧
    rRead mc 17 11 = dotSum fG fp c ∧
    (∀ t i, (t ≠ 11 ∨ (i ≠ 6 ∧ i ≠ 7)) → wRead mc t i = wRead m t i) ∧
    (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) → rRead mc t i = rRead m t i)

  have hInv₀ : Inv 0 m2 := by
    refine ⟨hex2.trans hex1, (hw2 11 6).trans hw1_6, by simpa [dotSum] using hr2_11, ?_, ?_⟩
    · intro t i h
      have hne6 : t ≠ 11 ∨ i ≠ 6 := by
        rcases h with h11 | ⟨h6, _⟩
        · exact Or.inl h11
        · exact Or.inr h6
      exact (hw2 t i).trans (hw1_ne t i hne6)
    · intro t i h
      have hne11 : t ≠ 17 ∨ i ≠ 11 := by
        rcases h with h17 | hnot
        · exact Or.inl h17
        · exact Or.inr fun h11 => hnot (by simp [h11])
      exact (hr2_ne t i hne11).trans (hr1 t i)

  rcases exec_repeatN (inp := inp) (.add .dim (.lit 1)) body (d + 1) 5 30 Inv s2.2.1 hInv₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun c hc_lt mc hcmc ⟨hex_c, hwc_c, hr11_c, hwm_c, hrm_c⟩ => by
      have hw5_c : mc.words.read (.heap 11 5) = (baseNat : ℤ) :=
        (hwm_c 11 5 (Or.inr (by decide))).trans hw5
      have hwc_c' : mc.words.read (.heap 11 6) = (c : ℤ) := hwc_c
      have hr11_c' : mc.reals.read (.heap 17 11) = dotSum fG fp c := hr11_c
      have haddr_c : (baseNat : ℤ) + (c : ℤ) =
          (((r.val * (ℓ * M₀) + (capIdx f u).val) * (d + 1) + c : ℕ) : ℤ) := by
        rw [hbase_eq]; push_cast; ring
      have hrG_c : mc.reals.read (.heap 2 ((baseNat : ℤ) + (c : ℤ))) = euclideanCoord G ⟨c, hc_lt⟩ := by
        rw [haddr_c]
        exact (hrm_c 2 _ (Or.inl (by decide))).trans (hr_G ⟨c, hc_lt⟩)
      have hrp_c : mc.reals.read (.heap 3 (c : ℤ)) = euclideanCoord p ⟨c, hc_lt⟩ :=
        (hrm_c 3 _ (Or.inl (by decide))).trans (hr_p ⟨c, hc_lt⟩)
      rcases exec_rSet_sr SW SR inp hcmc 17 (.lit 11) 11 (mem_ASR_17 (i := 11) (by omega))
        (.add (.readRealHeap 17 (.lit 11))
          (.mul (.readRealHeap 2 (.add baseE cE)) (.readRealHeap 3 cE)))
        (dotSum fG fp (c + 1)) 20
        (by simp [evalIntExpr])
        (by simp only [evalRealExpr, evalIntExpr, baseE, cE, hw5_c, hwc_c', hr11_c', hrG_c, hrp_c,
              dotSum, fG, fp, hc_lt, ↓reduceDIte])
        (by simp [evalRealExpr, evalIntExpr, baseE, cE])
        with ⟨ma, sa, hexa, hra_11, hwa, hra_ne⟩
      have hwc_a : ma.words.read (.heap 11 6) = (c : ℤ) := (hwa 11 6).trans hwc_c
      rcases exec_wSet_sw SW SR inp sa.2.1 11 (.lit 6) 6 (mem_ASW_11 (i := 6) (by omega))
        (.add cE (.lit 1)) (((c + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, cE, hwc_a]) (by simp [evalIntExpr, cE])
        with ⟨mb, sb, hexb, hwb_6, hwb_ne, hrb⟩
      refine ⟨mb, ExecStmt.seq sa sb, hexb.trans (hexa.trans hex_c), hwb_6,
        (hrb 17 11).trans hra_11, ?_, ?_⟩
      · intro t i h
        have hne6 : t ≠ 11 ∨ i ≠ 6 := by
          rcases h with h11 | ⟨h6, _⟩
          · exact Or.inl h11
          · exact Or.inr h6
        exact (hwb_ne t i hne6).trans ((hwa t i).trans (hwm_c t i h))
      · intro t i h
        have hne11 : t ≠ 17 ∨ i ≠ 11 := by
          rcases h with h17 | hnot
          · exact Or.inl h17
          · exact Or.inr fun h11 => hnot (by simp [h11])
        exact (hrb t i).trans ((hra_ne t i hne11).trans (hrm_c t i h)))
    with ⟨m', ⟨hex', _, hr11', hwm', hrm'⟩, sLoop⟩

  rw [dotSum_eq_inner G p] at hr11'
  have hrt' : m'.reals.read (.heap 1 1) = t_val :=
    (hrm' 1 1 (Or.inl (by decide))).trans hr_t
  have hr11'' : m'.reals.read (.heap 17 11) = inner ℝ G p := hr11'
  have sTot : ExecStmt inp dataEvalCapStmt m m' (20 + (d + 1) * 30) := by
    unfold dataEvalCapStmt seqStmts
    exact (ExecStmt.seq s1 (ExecStmt.seq s2 sLoop)).mono_cost (by omega)
  refine ⟨m', sTot, hex', ?_, ?_, hwm', hrm'⟩
  · simp [dataPassCondE, evalArithCond, evalRealExpr, evalIntExpr, hrt', hr11'', gaussianDataTest]
  · simp [dataPassCondE, evalArithCond, evalRealExpr, evalIntExpr]

set_option maxHeartbeats 1200000 in
theorem exec_insertBirthPtProg {d ℓ M₀ R m : ℕ}
    (hR : 1 ≤ R) (hM₀ : 1 ≤ M₀) (hm : 1 ≤ m)
    {Cap_u Cap_q : ℕ} (hCap_u : 1 ≤ Cap_u)
    {A B η : ℚ} {x t : ℝ}
    (ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (u_pts_dec : Fin m → EuclideanSpace ℝ (Fin d))
    (j : Fin m)
    {Inserted Active : Finset (Fin m)} (hj_not_ins : j ∉ Inserted)
    {extraBnd : ℕ} {mem₀ : ArithRAMMemory}
    (hinv : DataStructInv hm Cap_u Cap_q A B η x t ω
      (fun j' => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u_pts_dec j')) (B : ℝ)))
      Inserted Active extraBnd mem₀)
    (inp : ArithRAMInput d)
    (hinp_p : inp.intParams = [(j.val : ℤ)])
    (hinp_h : j.val ∈ inp.activeHandles)
    (hinp_c : inp.activeCoords j.val = u_pts_dec j) :
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp (insertBirthPtProg ℓ) mem₀ mem₁
        (60 + d * 35 + R * (100 + ℓ * 80 + ℓ * M₀ * (150 + (d + 1) * 30) + Cap_u * (160 + ℓ * 60))) ∧
      DataStructInv hm Cap_u Cap_q A B η x t ω
        (fun j' => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u_pts_dec j')) (B : ℝ)))
        (insert j Inserted) (insert j Active) (extraBnd + R * (5 * Cap_u + 1)) mem₁ := by
  classical
  let SW := AdaptiveSW R ℓ M₀ Cap_q d
  let SR := AdaptiveSR d R ℓ M₀
  let ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1)) :=
    fun j' => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u_pts_dec j')) (B : ℝ))
  have hj_not_act : j ∉ Active := fun ha => hj_not_ins (hinv.sub_act ha)

  let jE := IntExpr.readHeap 11 (.lit 20)
  let cE := IntExpr.readHeap 11 (.lit 6)
  let rE := IntExpr.readHeap 11 (.lit 0)
  let mE := IntExpr.readHeap 1 (.lit 1)
  let rCntE := IntExpr.readHeap 1 (.lit 2)
  let m0PowE := IntExpr.readHeap 1 (.lit 5)
  let sCntE := IntExpr.readHeap 11 (.lit 8)
  let sE := IntExpr.readHeap 11 (.lit 16)
  let pairE := IntExpr.readHeap 11 (.lit 22)

  -- Step 1: w[11, 20] := j.val, w[11, 6] := 0, fill r[3, 0..d] = ptsK j
  rcases exec_wSet_sw SW SR inp hinv.clean 11 (.lit 20) 20 (mem_ASW_11 (i := 20) (by omega))
    (.intParam (.lit 0)) (j.val : ℤ) 6
    (by simp [evalIntExpr]) (by simp [evalIntExpr, hinp_p, listGetIntD]) (by simp [evalIntExpr])
    with ⟨m1, s1, hex1, hw1_20, hw1_ne, hr1⟩
  rcases exec_wSet_sw SW SR inp s1.2.1 11 (.lit 6) 6 (mem_ASW_11 (i := 6) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m2, s2, hex2, hw2_6, hw2_ne, hr2⟩

  let copyBody : ArithRAMStmt :=
    seqStmts
      [ .writeRealHeap 3 cE (.mul (.readRealHeap 1 (.lit 2)) (.activePtCoord jE cE)),
        .writeWordHeap 11 (.lit 6) (.add cE (.lit 1)) ]
  let CopyInv : ℕ → ArithRAMMemory → Prop := fun c mc =>
    extraCells SW SR mc = extraCells SW SR mem₀ ∧
    wRead mc 11 6 = (c : ℤ) ∧
    wRead mc 11 20 = (j.val : ℤ) ∧
    (∀ c' : Fin d, c'.val < c → rRead mc 3 (c'.val : ℤ) = euclideanCoord (ptsK j) c'.castSucc) ∧
    (∀ t i, (t ≠ 11 ∨ (i ≠ 6 ∧ i ≠ 20)) → wRead mc t i = wRead mem₀ t i) ∧
    (∀ t i, t ≠ 3 → rRead mc t i = rRead mem₀ t i)

  have hCopy₀ : CopyInv 0 m2 := by
    refine ⟨hex2.trans hex1, hw2_6, (hw2_ne 11 20 (Or.inr (by decide))).trans hw1_20,
      fun _ h => by omega, ?_, fun t i _ => (hr2 t i).trans (hr1 t i)⟩
    intro t i h
    rcases h with h11 | ⟨h6, h20⟩
    · exact (hw2_ne t i (Or.inl h11)).trans (hw1_ne t i (Or.inl h11))
    · exact (hw2_ne t i (Or.inr h6)).trans (hw1_ne t i (Or.inr h20))

  rcases exec_repeatN (inp := inp) .dim copyBody d 3 35 CopyInv s2.2.1 hCopy₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun c hc_lt mc hcmc ⟨hex_c, hwc_c, hwj_c, hr3_prev, hwm_c, hrm_c⟩ => by
      let cFin : Fin d := ⟨c, hc_lt⟩
      have hwc_c' : mc.words.read (.heap 11 6) = (c : ℤ) := hwc_c
      have hwj_c' : mc.words.read (.heap 11 20) = (j.val : ℤ) := hwj_c
      have hrA_c : mc.reals.read (.heap 1 2) = (A : ℝ) :=
        (hrm_c 1 2 (by decide)).trans hinv.hdr_A
      have hact_ev := evalRealExpr_activePtCoord inp mc jE cE j.val cFin
        (by simp [evalIntExpr, jE, hwj_c'])
        (by simp [cFin, evalIntExpr, cE, hwc_c'])
        hinp_h
      rw [hinp_c] at hact_ev
      have hval_c : (evalRealExpr inp 0 mc (.mul (.readRealHeap 1 (.lit 2)) (.activePtCoord jE cE))).1 =
          euclideanCoord (ptsK j) cFin.castSucc := by
        change (evalRealExpr inp 0 mc (.readRealHeap 1 (.lit 2))).1 *
            (evalRealExpr inp 0 mc (.activePtCoord jE cE)).1 =
          euclideanCoord (WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u_pts_dec j)) (B : ℝ))) cFin.castSucc
        rw [padData_coord_castSucc, hact_ev]
        simp [evalRealExpr, evalIntExpr, hrA_c]
      rcases exec_rSet_sr SW SR inp hcmc 3 cE (c : ℤ) (mem_ASR_3 (i := c) (by omega))
        (.mul (.readRealHeap 1 (.lit 2)) (.activePtCoord jE cE))
        (euclideanCoord (ptsK j) cFin.castSucc) 25
        (by simp [evalIntExpr, cE, hwc_c']) hval_c
        (by simp [evalRealExpr, evalIntExpr, jE, cE])
        with ⟨ma, sa, hexa, hra_3, hwa, hra_ne⟩
      have hwc_a : ma.words.read (.heap 11 6) = (c : ℤ) := (hwa 11 6).trans hwc_c
      rcases exec_wSet_sw SW SR inp sa.2.1 11 (.lit 6) 6 (mem_ASW_11 (i := 6) (by omega))
        (.add cE (.lit 1)) (((c + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, cE, hwc_a]) (by simp [evalIntExpr, cE])
        with ⟨mb, sb, hexb, hwb_6, hwb_ne, hrb⟩
      refine ⟨mb, ExecStmt.seq sa sb, hexb.trans (hexa.trans hex_c), hwb_6,
        (hwb_ne 11 20 (Or.inr (by decide))).trans ((hwa 11 20).trans hwj_c), ?_, ?_, ?_⟩
      · intro c' hc'
        rw [hrb 3 _]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hc' with hlt | heq
        · rw [hra_ne 3 _ (Or.inr (by omega))]
          exact hr3_prev c' hlt
        · have hc'_eq : c' = cFin := Fin.ext heq
          subst hc'_eq
          exact hra_3
      · intro t i h
        have hne6 : t ≠ 11 ∨ i ≠ 6 := by
          rcases h with h11 | ⟨h6, _⟩
          · exact Or.inl h11
          · exact Or.inr h6
        exact (hwb_ne t i hne6).trans ((hwa t i).trans (hwm_c t i h))
      · intro t i ht
        exact (hrb t i).trans ((hra_ne t i (Or.inl ht)).trans (hrm_c t i ht)))
    with ⟨m3, ⟨hex3, _, hw3_20, hr3_cast, hwm3, hrm3⟩, sCopyLoop⟩

  -- Write r[3, d] := B
  have hrB_3 : m3.reals.read (.heap 1 3) = (B : ℝ) := (hrm3 1 3 (by decide)).trans hinv.hdr_B
  rcases exec_rSet_sr SW SR inp sCopyLoop.2.1 3 .dim (d : ℤ) (mem_ASR_3 (i := d) (by omega))
    (.readRealHeap 1 (.lit 3)) (B : ℝ) 10
    (by simp [evalIntExpr]) (by simp [evalRealExpr, evalIntExpr, hrB_3])
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m4, s4, hex4, hr4_d, hw4, hr4_ne⟩

  have hr4_ptsK : ∀ coord : Fin (d + 1), rRead m4 3 (coord.val : ℤ) = euclideanCoord (ptsK j) coord := by
    intro coord
    exact Fin.lastCases (motive := fun k => rRead m4 3 (k.val : ℤ) = euclideanCoord (ptsK j) k)
      (by
        change _ = euclideanCoord (WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u_pts_dec j)) (B : ℝ))) (Fin.last d)
        rw [padData_coord_last]
        exact hr4_d)
      (fun c => by
        dsimp only
        rw [hr4_ne 3 _ (Or.inr (by exact_mod_cast (ne_of_lt c.isLt)))]
        exact hr3_cast c c.isLt)
      coord

  -- w[11, 0] := 0
  rcases exec_wSet_sw SW SR inp s4.2.1 11 (.lit 0) 0 (mem_ASW_11 (i := 0) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m5, s5, hex5, hw5_0, hw5_ne, hr5⟩

  -- Step 2: Loop over copies `r = 0 .. R - 1`
  let copyStepCost : ℕ :=
    100 + ℓ * 80 + ℓ * M₀ * (150 + (d + 1) * 30) + Cap_u * (160 + ℓ * 60)
  let sBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 4) sE,
        decodeTupleCodeStmt ℓ,
        .writeWordHeap 11 (.lit 18) (.add (.mul rE m0PowE) (.readHeap 11 (.lit 11))),
        bucketAppendStepStmt,
        .writeWordHeap 11 (.lit 16) (.add sE (.lit 1)) ]
  let rBody : ArithRAMStmt :=
    seqStmts
      [ scanCapsStmt ℓ dataEvalCapStmt dataPassCondE,
        computeCappedProdStmt ℓ 3,
        .writeWordHeap 11 (.lit 22) (.add (.mul rE mE) jE),
        .writeWordHeap 21 pairE sCntE,
        .writeWordHeap 11 (.lit 16) (.lit 0),
        .repeatN sCntE sBody,
        .writeWordHeap 11 (.lit 0) (.add rE (.lit 1)) ]

  let pairsBefore : ℕ → Finset (Fin (R * m) × ℕ) := fun r_lim =>
    activePairsOf Cap_u t ω ptsK Finset.univ Active ∪
      ((Finset.univ.filter (fun r' : Fin R => r'.val < r_lim)).biUnion (fun r' =>
        (Finset.range (dataSlotBound Cap_u t (ω r') (ptsK j))).image (fun s => (pairIdx r' j, s))))

  let RLoopInv : ℕ → ArithRAMMemory → Prop := fun r_idx mr =>
    extraCells SW SR mr ≤ extraBnd + r_idx * (5 * Cap_u + 1) ∧
    wRead mr 11 0 = (r_idx : ℤ) ∧
    wRead mr 11 20 = (j.val : ℤ) ∧
    (∀ coord : Fin (d + 1), rRead mr 3 (coord.val : ℤ) = euclideanCoord (ptsK j) coord) ∧
    (∀ t_tbl i, t_tbl ∉ ([6, 11, 21, 22, 23, 24, 25, 26] : List ℕ) →
      wRead mr t_tbl i = wRead mem₀ t_tbl i) ∧
    (∀ t_tbl i, t_tbl ≠ 3 → t_tbl ≠ 17 → rRead mr t_tbl i = rRead mem₀ t_tbl i) ∧
    (∀ (r' : Fin R) (j' : Fin m), j' ∈ Inserted →
      wRead mr 21 ((pairIdx r' j').val : ℤ) = (dataSlotBound Cap_u t (ω r') (ptsK j') : ℤ)) ∧
    (∀ (r' : Fin R), r'.val < r_idx →
      wRead mr 21 ((pairIdx r' j).val : ℤ) = (dataSlotBound Cap_u t (ω r') (ptsK j) : ℤ)) ∧
    BucketInv Cap_u (globalDataBkt hm t ω ptsK) (pairsBefore r_idx) mr

  have hRLoop₀ : RLoopInv 0 m5 := by
    have hex_m5 : extraCells SW SR m5 = extraCells SW SR mem₀ :=
      hex5.trans (hex4.trans hex3)
    have hpairs0 : pairsBefore 0 = activePairsOf Cap_u t ω ptsK Finset.univ Active := by
      ext p; simp [pairsBefore]
    have hw_pres5 : ∀ t_tbl i, t_tbl ≠ 11 → wRead m5 t_tbl i = wRead mem₀ t_tbl i := by
      intro t_tbl i ht
      exact (hw5_ne t_tbl i (Or.inl ht)).trans ((hw4 t_tbl i).trans (hwm3 t_tbl i (Or.inl ht)))
    refine ⟨by linarith [hinv.extra_le], hw5_0,
      (hw5_ne 11 20 (Or.inr (by decide))).trans ((hw4 11 20).trans hw3_20),
      fun coord => (hr5 3 _).trans (hr4_ptsK coord),
      fun t_tbl i ht => hw_pres5 t_tbl i (fun h => ht (by simp [h])),
      fun t_tbl i ht3 _ => (hr5 t_tbl i).trans ((hr4_ne t_tbl i (Or.inl ht3)).trans (hrm3 t_tbl i ht3)),
      fun r' j' hj' => (hw_pres5 21 _ (by decide)).trans (hinv.slot_cnt r' j' hj'),
      fun _ hr' => by omega,
      by
        rw [hpairs0]
        exact bucketInv_congr hinv.buckets (fun t_tbl idx _ _ => hw_pres5 t_tbl idx (by omega))⟩

  have hwR_m5 : m5.words.read (.heap 1 2) = (R : ℤ) :=
    (hRLoop₀.2.2.2.2.1 1 2 (by decide)).trans hinv.hdr_R

  rcases exec_repeatN (inp := inp) rCntE rBody R 5 copyStepCost RLoopInv s5.2.1 hRLoop₀
    (by simp [evalIntExpr, rCntE, hwR_m5])
    (by simp [evalIntExpr, rCntE])
    (fun r_idx hr_lt mr hcmr
      ⟨hex_r, hwr_0, hwr_20, hrr_3, hwr_hdr, hrr_hdr, hslot_old, hslot_prev, hbkt_r⟩ => by
      let rFin : Fin R := ⟨r_idx, hr_lt⟩
      let pass_r := dataPassPred t (ω rFin) (ptsK j)
      have hwM0_r : wRead mr 1 4 = (M₀ : ℤ) := (hwr_hdr 1 4 (by decide)).trans hinv.hdr_M0

      -- r1. scanCapsStmt
      rcases exec_scanCapsStmt (Cap_q := Cap_q) inp hR hM₀ rFin pass_r
        dataEvalCapStmt dataPassCondE (20 + (d + 1) * 30) hcmr hwr_0 hwM0_r
        (fun f u m hcm hex_m _ _ _ hw5_m _ hrm_m =>
          exec_dataEvalCapStmt inp rFin f u t (ω rFin (capIdx f u)) (ptsK j) hcm hw5_m
            ((hrm_m 1 1 (Or.inl (by decide))).trans ((hrr_hdr 1 1 (by decide) (by decide)).trans hinv.hdr_t))
            (fun coord => (hrm_m 2 _ (Or.inl (by decide))).trans
              ((hrr_hdr 2 _ (by decide) (by decide)).trans (hinv.gauss rFin (capIdx f u) coord)))
            (fun coord => (hrm_m 3 _ (Or.inl (by decide))).trans (hrr_3 coord)))
        with ⟨mr1, sr1, hex_r1, hcnt_r1, hhit_r1, hwr1_ne, hrr1_ne⟩

      -- r2. computeCappedProdStmt ℓ 3
      let cnt_fn : ℕ → ℕ := fun f => if hf : f < ℓ then (hitList (pass_r ⟨f, hf⟩)).length else 1
      have hwCapu_r1 : wRead mr1 1 3 = (Cap_u : ℤ) :=
        (hwr1_ne 1 3 (by decide) (Or.inl (by decide))).trans ((hwr_hdr 1 3 (by decide)).trans hinv.hdr_Capu)
      rcases exec_computeCappedProdStmt inp ℓ 3 hCap_u cnt_fn mr1 sr1.2.1 hwCapu_r1
        (fun f hf => by simp only [cnt_fn, hf, ↓reduceDIte]; exact hcnt_r1 ⟨f, hf⟩)
        with ⟨mr2, sr2, hwr2_8, hwr2_ne, hwr2_11, hrr2_eq, hlive_w2, hlive_r2⟩
      have hex_r2 : extraCells SW SR mr2 ≤ extraCells SW SR mr1 := extraCells_le_of_subset (SW := SW) (SR := SR) hlive_w2 (rangeHeap_11_sub_ASW (by omega))
          (hlive_r2.trans Finset.subset_union_left) (Finset.empty_subset SR)
      let S_cnt : ℕ := dataSlotBound Cap_u t (ω rFin) (ptsK j)
      have hS_cnt_eq : min Cap_u (prefixProd cnt_fn ℓ) = S_cnt := rfl
      rw [hS_cnt_eq] at hwr2_8
      have hS_le_Capu : S_cnt ≤ Cap_u := Nat.min_le_left _ _

      -- r3. w[11, 22] := r * m + j = (pairIdx rFin j).val
      have hwr2_0 : mr2.words.read (.heap 11 0) = (r_idx : ℤ) :=
        (hwr2_11 0 (by decide) (by decide)).trans
          ((hwr1_ne 11 0 (by decide) (Or.inr (by decide))).trans hwr_0)
      have hwr2_20 : mr2.words.read (.heap 11 20) = (j.val : ℤ) :=
        (hwr2_11 20 (by decide) (by decide)).trans
          ((hwr1_ne 11 20 (by decide) (Or.inr (by decide))).trans hwr_20)
      have hwr2_m : mr2.words.read (.heap 1 1) = (m : ℤ) :=
        (hwr2_ne 1 1 (by decide)).trans
          ((hwr1_ne 1 1 (by decide) (Or.inl (by decide))).trans
            ((hwr_hdr 1 1 (by decide)).trans hinv.hdr_m))
      rcases exec_wSet_sw SW SR inp sr2.2.1 11 (.lit 22) 22 (mem_ASW_11 (i := 22) (by omega))
        (.add (.mul rE mE) jE) (((pairIdx rFin j).val : ℕ) : ℤ) 15
        (by simp [evalIntExpr])
        (by simp only [evalIntExpr, rE, mE, jE, hwr2_0, hwr2_m, hwr2_20, pairIdx, rFin]; push_cast; ring)
        (by simp [evalIntExpr, rE, mE, jE])
        with ⟨mr3, sr3, hex_r3, hwr3_22, hwr3_ne, hrr3_eq⟩

      -- r4. w[21, pairE] := sCntE (+1 extraCell!)
      have hwr3_22' : mr3.words.read (.heap 11 22) = (((pairIdx rFin j).val : ℕ) : ℤ) := hwr3_22
      have hwr3_8 : mr3.words.read (.heap 11 8) = (S_cnt : ℤ) :=
        (hwr3_ne 11 8 (Or.inr (by decide))).trans hwr2_8
      rcases exec_wSet_any SW SR inp sr3.2.1 21 pairE (((pairIdx rFin j).val : ℕ) : ℤ)
        sCntE (S_cnt : ℤ) 10
        (by simp [evalIntExpr, pairE, hwr3_22'])
        (by simp [evalIntExpr, sCntE, hwr3_8])
        (by simp [evalIntExpr, pairE, sCntE])
        with ⟨mr4, sr4, hex_r4, hwr4_21, hwr4_ne, hrr4_eq⟩

      -- r5. w[11, 16] := 0
      rcases exec_wSet_sw SW SR inp sr4.2.1 11 (.lit 16) 16 (mem_ASW_11 (i := 16) (by omega))
        (.lit 0) 0 4
        (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
        with ⟨mr5, sr5, hex_r5, hwr5_16, hwr5_ne, hrr5_eq⟩

      -- r6. Inner slot loop `s = 0 .. S_cnt - 1`
      let pairsSlot : ℕ → Finset (Fin (R * m) × ℕ) := fun s_lim =>
        pairsBefore r_idx ∪ (Finset.range s_lim).image (fun s => (pairIdx rFin j, s))

      let SLoopInv : ℕ → ArithRAMMemory → Prop := fun s_idx ms =>
        extraCells SW SR ms ≤ extraBnd + r_idx * (5 * Cap_u + 1) + 1 + 5 * s_idx ∧
        wRead ms 11 0 = (r_idx : ℤ) ∧
        wRead ms 11 8 = (S_cnt : ℤ) ∧
        wRead ms 11 16 = (s_idx : ℤ) ∧
        wRead ms 11 20 = (j.val : ℤ) ∧
        wRead ms 11 22 = (((pairIdx rFin j).val : ℕ) : ℤ) ∧
        (∀ f : Fin ℓ, wRead ms 6 (f.val : ℤ) = ((hitList (pass_r f)).length : ℤ)) ∧
        (∀ (f : Fin ℓ) (idx : ℕ) (hidx : idx < (hitList (pass_r f)).length),
          wRead ms 6 ((ℓ + f.val * M₀ + idx : ℕ) : ℤ) = (((hitList (pass_r f))[idx]'hidx).val : ℤ)) ∧
        (∀ t_tbl i, t_tbl ∉ ([6, 11, 21, 22, 23, 24, 25, 26] : List ℕ) →
          wRead ms t_tbl i = wRead mem₀ t_tbl i) ∧
        (∀ i, wRead ms 21 i = wRead mr4 21 i) ∧
        (∀ coord : Fin (d + 1), rRead ms 3 (coord.val : ℤ) = euclideanCoord (ptsK j) coord) ∧
        (∀ t_tbl i, t_tbl ≠ 3 → t_tbl ≠ 17 → rRead ms t_tbl i = rRead mem₀ t_tbl i) ∧
        BucketInv Cap_u (globalDataBkt hm t ω ptsK) (pairsSlot s_idx) ms

      have hmr5_pres_non11_21 : ∀ t_tbl i, t_tbl ≠ 6 → t_tbl ≠ 11 → t_tbl ≠ 21 →
          wRead mr5 t_tbl i = wRead mr t_tbl i := by
        intro t_tbl i h6 h11 h21
        exact (hwr5_ne t_tbl i (Or.inl h11)).trans
          ((hwr4_ne t_tbl i (Or.inl h21)).trans
            ((hwr3_ne t_tbl i (Or.inl h11)).trans
              ((hwr2_ne t_tbl i h11).trans (hwr1_ne t_tbl i h6 (Or.inl h11)))))

      have hSLoop₀ : SLoopInv 0 mr5 := by
        have hpairs_s0 : pairsSlot 0 = pairsBefore r_idx := by
          ext p; simp [pairsSlot]
        refine ⟨by linarith [hex_r5, hex_r4, hex_r3, hex_r2, hex_r1, hex_r],
          (hwr5_ne 11 0 (Or.inr (by decide))).trans
            ((hwr4_ne 11 0 (Or.inl (by decide))).trans
              ((hwr3_ne 11 0 (Or.inr (by decide))).trans hwr2_0)),
          (hwr5_ne 11 8 (Or.inr (by decide))).trans
            ((hwr4_ne 11 8 (Or.inl (by decide))).trans hwr3_8),
          hwr5_16,
          (hwr5_ne 11 20 (Or.inr (by decide))).trans
            ((hwr4_ne 11 20 (Or.inl (by decide))).trans
              ((hwr3_ne 11 20 (Or.inr (by decide))).trans hwr2_20)),
          (hwr5_ne 11 22 (Or.inr (by decide))).trans
            ((hwr4_ne 11 22 (Or.inl (by decide))).trans hwr3_22),
          fun f => (hwr5_ne 6 _ (Or.inl (by decide))).trans
            ((hwr4_ne 6 _ (Or.inl (by decide))).trans
              ((hwr3_ne 6 _ (Or.inl (by decide))).trans
                ((hwr2_ne 6 _ (by decide)).trans (hcnt_r1 f)))),
          fun f idx hidx => (hwr5_ne 6 _ (Or.inl (by decide))).trans
            ((hwr4_ne 6 _ (Or.inl (by decide))).trans
              ((hwr3_ne 6 _ (Or.inl (by decide))).trans
                ((hwr2_ne 6 _ (by decide)).trans (hhit_r1 f idx hidx)))),
          fun t_tbl i ht => (hmr5_pres_non11_21 t_tbl i
            (fun h => ht (by simp [h])) (fun h => ht (by simp [h])) (fun h => ht (by simp [h]))).trans
              (hwr_hdr t_tbl i ht),
          fun i => hwr5_ne 21 i (Or.inl (by decide)),
          fun coord => (hrr5_eq 3 _).trans ((hrr4_eq 3 _).trans ((hrr3_eq 3 _).trans
            ((hrr2_eq 3 _).trans ((hrr1_ne 3 _ (Or.inl (by decide))).trans (hrr_3 coord))))),
          fun t_tbl i ht3 ht17 => (hrr5_eq t_tbl i).trans ((hrr4_eq t_tbl i).trans
            ((hrr3_eq t_tbl i).trans ((hrr2_eq t_tbl i).trans
              ((hrr1_ne t_tbl i (Or.inl ht17)).trans (hrr_hdr t_tbl i ht3 ht17))))),
          by
            rw [hpairs_s0]
            exact bucketInv_congr hbkt_r (fun t_tbl idx h22 _ =>
              hmr5_pres_non11_21 t_tbl idx (by omega) (by omega) (by omega))⟩

      have hwr5_8' : mr5.words.read (.heap 11 8) = (S_cnt : ℤ) := hSLoop₀.2.2.1
      rcases exec_repeatN (inp := inp) sCntE sBody S_cnt 5 (160 + ℓ * 60) SLoopInv sr5.2.1 hSLoop₀
        (by simp [evalIntExpr, sCntE, hwr5_8'])
        (by simp [evalIntExpr, sCntE])
        (fun s_idx hs_lt ms hcms
          ⟨hex_s, hws_0, hws_8, hws_16, hws_20, hws_22, hcnt_s, hhit_s, hws_hdr, hws_21,
           hrs_3, hrs_hdr, hbkt_s⟩ => by
          have hs_lt_prod : s_idx < prefixProd cnt_fn ℓ := slot_lt_prod_of_lt_bound hs_lt
          have hs_lt_Capu : s_idx < Cap_u := lt_of_lt_of_le hs_lt hS_le_Capu
          have hws_16' : ms.words.read (.heap 11 16) = (s_idx : ℤ) := hws_16

          -- s1. w[11, 4] := s_idx
          rcases exec_wSet_sw SW SR inp hcms 11 (.lit 4) 4 (mem_ASW_11 (i := 4) (by omega))
            sE (s_idx : ℤ) 10
            (by simp [evalIntExpr]) (by simp [evalIntExpr, sE, hws_16']) (by simp [evalIntExpr, sE])
            with ⟨ms1, ss1, hexs1, hws1_4, hws1_ne, hrs1⟩

          -- s2. decodeTupleCodeStmt ℓ
          have hwM0_s1 : wRead ms1 1 4 = (M₀ : ℤ) :=
            (hws1_ne 1 4 (Or.inl (by decide))).trans ((hws_hdr 1 4 (by decide)).trans hinv.hdr_M0)
          rcases exec_decodeTupleCodeStmt inp pass_r s_idx hs_lt_prod ms1 ss1.2.1 hwM0_s1 hws1_4
            (fun f => (hws1_ne 6 _ (Or.inl (by decide))).trans (hcnt_s f))
            (fun f idx hidx => (hws1_ne 6 _ (Or.inl (by decide))).trans (hhit_s f idx hidx))
            with ⟨ms2, ss2, hws2_11, hws2_ne, hws2_11pres, hrs2, hlive_ws2, hlive_rs2⟩
          have hexs2 : extraCells SW SR ms2 ≤ extraCells SW SR ms1 := extraCells_le_of_subset (SW := SW) (SR := SR) hlive_ws2 (rangeHeap_11_sub_ASW (by omega))
              (hlive_rs2.trans Finset.subset_union_left) (Finset.empty_subset SR)
          have hlocal_eq : encodeTuple (enumTuple pass_r s_idx hs_lt_prod) =
              localDataBkt t (ω rFin) (ptsK j) s_idx := by
            unfold localDataBkt
            rw [dif_pos hs_lt_prod]
          rw [hlocal_eq] at hws2_11

          -- s3. w[11, 18] := r * M₀^ℓ + w[11, 11] = globalDataBkt hm t ω ptsK (pairIdx rFin j) s_idx
          have hws2_0 : ms2.words.read (.heap 11 0) = (r_idx : ℤ) :=
            (hws2_11pres 0 (Or.inl (by decide))).trans ((hws1_ne 11 0 (Or.inr (by decide))).trans hws_0)
          have hws2_M0p : ms2.words.read (.heap 1 5) = ((M₀ ^ ℓ : ℕ) : ℤ) :=
            (hws2_ne 1 5 (by decide)).trans
              ((hws1_ne 1 5 (Or.inl (by decide))).trans ((hws_hdr 1 5 (by decide)).trans hinv.hdr_M0pow))
          have hws2_11' : ms2.words.read (.heap 11 11) =
              ((localDataBkt t (ω rFin) (ptsK j) s_idx : ℕ) : ℤ) := hws2_11
          let gBkt : ℕ := globalDataBkt hm t ω ptsK (pairIdx rFin j) s_idx
          have hgBkt_eq : gBkt = r_idx * (M₀ ^ ℓ) + localDataBkt t (ω rFin) (ptsK j) s_idx :=
            globalDataBkt_pairIdx hm t ω ptsK rFin j s_idx
          rcases exec_wSet_sw SW SR inp ss2.2.1 11 (.lit 18) 18 (mem_ASW_11 (i := 18) (by omega))
            (.add (.mul rE m0PowE) (.readHeap 11 (.lit 11))) ((gBkt : ℕ) : ℤ) 15
            (by simp [evalIntExpr])
            (by simp only [evalIntExpr, rE, m0PowE, hws2_0, hws2_M0p, hws2_11', hgBkt_eq]; push_cast; ring)
            (by simp [evalIntExpr, rE, m0PowE])
            with ⟨ms3, ss3, hexs3, hws3_18, hws3_ne, hrs3⟩

          -- s4. bucketAppendStepStmt
          have hbkt_ms3 : BucketInv Cap_u (globalDataBkt hm t ω ptsK) (pairsSlot s_idx) ms3 :=
            bucketInv_congr hbkt_s (fun t_tbl idx h22 _ =>
              (hws3_ne t_tbl idx (Or.inl (by omega))).trans
                ((hws2_ne t_tbl idx (by omega)).trans (hws1_ne t_tbl idx (Or.inl (by omega)))))

          have hmem_pairsSlot : ∀ {p : Fin (R * m)} {sv : ℕ},
              (p, sv) ∈ insert (pairIdx rFin j, s_idx) (pairsSlot s_idx) →
              ∃ (r' : Fin R) (j' : Fin m), p = pairIdx r' j' ∧ sv < dataSlotBound Cap_u t (ω r') (ptsK j') := by
            intro p sv hp
            rcases Finset.mem_insert.mp hp with h_eq | h_old
            · cases h_eq
              exact ⟨rFin, j, rfl, hs_lt⟩
            · rcases Finset.mem_union.mp h_old with h_bef | h_cur
              · rcases Finset.mem_union.mp h_bef with h_act | h_prevr
                · rcases mem_activePairsOf_iff.mp h_act with ⟨r', _, j', _, rfl, hsv⟩
                  exact ⟨r', j', rfl, hsv⟩
                · simp only [Finset.mem_biUnion, Finset.mem_filter, Finset.mem_univ, true_and,
                    Finset.mem_image, Finset.mem_range, Prod.mk.injEq] at h_prevr
                  rcases h_prevr with ⟨r', _, sv', hsv', rfl, rfl⟩
                  exact ⟨r', j, rfl, hsv'⟩
              · simp only [Finset.mem_image, Finset.mem_range, Prod.mk.injEq] at h_cur
                rcases h_cur with ⟨sv', hsv', rfl, rfl⟩
                exact ⟨rFin, j, rfl, lt_trans hsv' hs_lt⟩

          have hbkt_inj_s : ∀ {k' : Fin (R * m)} {s₁ s₂ : ℕ},
              (k', s₁) ∈ insert (pairIdx rFin j, s_idx) (pairsSlot s_idx) →
              (k', s₂) ∈ insert (pairIdx rFin j, s_idx) (pairsSlot s_idx) →
              globalDataBkt hm t ω ptsK k' s₁ = globalDataBkt hm t ω ptsK k' s₂ → s₁ = s₂ := by
            intro k' s₁ s₂ h1 h2 heq
            rcases hmem_pairsSlot h1 with ⟨r1, j1, rfl, hs1_b⟩
            rcases pairIdx_div_mod r1 j1 with ⟨hd1, hm1⟩
            have hs1_p := slot_lt_prod_of_lt_bound hs1_b
            rcases hmem_pairsSlot h2 with ⟨r2, j2, hp_eq, hs2_b⟩
            rcases pairIdx_inj hp_eq with ⟨rfl, rfl⟩
            have hs2_p := slot_lt_prod_of_lt_bound hs2_b
            exact globalDataBkt_inj_of_lt hm (Cap_u := Cap_u)
              (by simpa [hd1, hm1] using hs1_p)
              (by simpa [hd1, hm1] using hs2_p)
              heq

          have hnot_mem_s : (pairIdx rFin j, s_idx) ∉ pairsSlot s_idx := by
            intro hmem
            rcases Finset.mem_union.mp hmem with h_bef | h_cur
            · rcases Finset.mem_union.mp h_bef with h_act | h_prevr
              · rcases mem_activePairsOf_iff.mp h_act with ⟨r', _, j', hj'_act, hp_eq, _⟩
                rcases pairIdx_inj hp_eq with ⟨_, rfl⟩
                exact hj_not_act hj'_act
              · simp only [Finset.mem_biUnion, Finset.mem_filter, Finset.mem_univ, true_and,
                  Finset.mem_image, Finset.mem_range, Prod.mk.injEq] at h_prevr
                rcases h_prevr with ⟨r', hr'_lt, _, _, hp_eq, _⟩
                rcases pairIdx_inj hp_eq with ⟨rfl, _⟩
                exact Nat.lt_irrefl _ hr'_lt
            · simp only [Finset.mem_image, Finset.mem_range, Prod.mk.injEq] at h_cur
              rcases h_cur with ⟨sv, hsv, _, rfl⟩
              exact Nat.lt_irrefl _ hsv

          have hws3_Rm : wRead ms3 1 0 = ((R * m : ℕ) : ℤ) :=
            (hws3_ne 1 0 (Or.inl (by decide))).trans
              ((hws2_ne 1 0 (by decide)).trans
                ((hws1_ne 1 0 (Or.inl (by decide))).trans ((hws_hdr 1 0 (by decide)).trans hinv.hdr_Rm)))
          have hws3_Capu : wRead ms3 1 3 = (Cap_u : ℤ) :=
            (hws3_ne 1 3 (Or.inl (by decide))).trans
              ((hws2_ne 1 3 (by decide)).trans
                ((hws1_ne 1 3 (Or.inl (by decide))).trans ((hws_hdr 1 3 (by decide)).trans hinv.hdr_Capu)))
          have hws3_22 : wRead ms3 11 22 = (((pairIdx rFin j).val : ℕ) : ℤ) :=
            (hws3_ne 11 22 (Or.inr (by decide))).trans
              ((hws2_11pres 22 (Or.inr (by decide))).trans ((hws1_ne 11 22 (Or.inr (by decide))).trans hws_22))
          have hws3_16 : wRead ms3 11 16 = (s_idx : ℤ) :=
            (hws3_ne 11 16 (Or.inr (by decide))).trans
              ((hws2_11pres 16 (Or.inr (by decide))).trans ((hws1_ne 11 16 (Or.inr (by decide))).trans hws_16))

          rcases exec_bucketAppendStep (ℓ := 2 * R * ℓ) (M₀ := M₀) (Cap_u := Cap_u) (Cap_q := Cap_q + d)
            (m := R * m) inp hbkt_inj_s hs_lt_Capu hnot_mem_s ss3.2.1 hbkt_ms3
            hws3_Rm hws3_Capu hws3_22 hws3_16 hws3_18
            with ⟨ms4, ss4, hexs4, hbkt_ms4, hws4_ne, hrs4⟩

          -- s5. w[11, 16] := s_idx + 1
          have hws4_16 : ms4.words.read (.heap 11 16) = (s_idx : ℤ) :=
            (hws4_ne 11 16 (by decide) (Or.inr (by decide))).trans hws3_16
          rcases exec_wSet_sw SW SR inp ss4.2.1 11 (.lit 16) 16 (mem_ASW_11 (i := 16) (by omega))
            (.add sE (.lit 1)) (((s_idx + 1 : ℕ) : ℤ)) 10
            (by simp [evalIntExpr]) (by simp [evalIntExpr, sE, hws4_16]) (by simp [evalIntExpr, sE])
            with ⟨ms5, ss5, hexs5, hws5_16, hws5_ne, hrs5⟩

          have sSlotStep : ExecStmt inp sBody ms ms5 (160 + ℓ * 60) := by
            unfold sBody seqStmts
            exact (ExecStmt.seq ss1 (ExecStmt.seq ss2 (ExecStmt.seq ss3 (ExecStmt.seq ss4 ss5)))).mono_cost (by omega)

          have hpairs_succ : insert (pairIdx rFin j, s_idx) (pairsSlot s_idx) = pairsSlot (s_idx + 1) := by
            ext p
            simp only [pairsSlot, Finset.mem_insert, Finset.mem_union, Finset.mem_image,
              Finset.mem_range]
            constructor
            · rintro (rfl | h_bef | ⟨sv, hsv, rfl⟩)
              · exact Or.inr ⟨s_idx, Nat.lt_succ_self _, rfl⟩
              · exact Or.inl h_bef
              · exact Or.inr ⟨sv, Nat.lt_succ_of_lt hsv, rfl⟩
            · rintro (h_bef | ⟨sv, hsv, rfl⟩)
              · exact Or.inr (Or.inl h_bef)
              · rcases Nat.lt_succ_iff_lt_or_eq.mp hsv with hlt | rfl
                · exact Or.inr (Or.inr ⟨sv, hlt, rfl⟩)
                · exact Or.inl rfl

          have hbkt_ms5 : BucketInv Cap_u (globalDataBkt hm t ω ptsK) (pairsSlot (s_idx + 1)) ms5 := by
            rw [← hpairs_succ]
            exact bucketInv_congr hbkt_ms4 (fun t_tbl idx h22 _ => hws5_ne t_tbl idx (Or.inl (by omega)))

          refine ⟨ms5, sSlotStep, by linarith [hexs5, hexs4, hexs3, hexs2, hexs1, hex_s],
            (hws5_ne 11 0 (Or.inr (by decide))).trans
              ((hws4_ne 11 0 (by decide) (Or.inr (by decide))).trans
                ((hws3_ne 11 0 (Or.inr (by decide))).trans hws2_0)),
            (hws5_ne 11 8 (Or.inr (by decide))).trans
              ((hws4_ne 11 8 (by decide) (Or.inr (by decide))).trans
                ((hws3_ne 11 8 (Or.inr (by decide))).trans
                  ((hws2_11pres 8 (Or.inl (by decide))).trans
                    ((hws1_ne 11 8 (Or.inr (by decide))).trans hws_8)))),
            hws5_16,
            (hws5_ne 11 20 (Or.inr (by decide))).trans
              ((hws4_ne 11 20 (by decide) (Or.inr (by decide))).trans
                ((hws3_ne 11 20 (Or.inr (by decide))).trans
                  ((hws2_11pres 20 (Or.inr (by decide))).trans
                    ((hws1_ne 11 20 (Or.inr (by decide))).trans hws_20)))),
            (hws5_ne 11 22 (Or.inr (by decide))).trans
              ((hws4_ne 11 22 (by decide) (Or.inr (by decide))).trans hws3_22),
            fun f => (hws5_ne 6 _ (Or.inl (by decide))).trans
              ((hws4_ne 6 _ (by decide) (Or.inl (by decide))).trans
                ((hws3_ne 6 _ (Or.inl (by decide))).trans
                  ((hws2_ne 6 _ (by decide)).trans
                    ((hws1_ne 6 _ (Or.inl (by decide))).trans (hcnt_s f))))),
            fun f idx hidx => (hws5_ne 6 _ (Or.inl (by decide))).trans
              ((hws4_ne 6 _ (by decide) (Or.inl (by decide))).trans
                ((hws3_ne 6 _ (Or.inl (by decide))).trans
                  ((hws2_ne 6 _ (by decide)).trans
                    ((hws1_ne 6 _ (Or.inl (by decide))).trans (hhit_s f idx hidx))))),
            fun t_tbl i ht => (hws5_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans
              ((hws4_ne t_tbl i (fun h => ht (by simp at h ⊢; omega)) (Or.inl (fun h => ht (by simp [h])))).trans
                ((hws3_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans
                  ((hws2_ne t_tbl i (fun h => ht (by simp [h]))).trans
                    ((hws1_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans (hws_hdr t_tbl i ht))))),
            fun i => (hws5_ne 21 i (Or.inl (by decide))).trans
              ((hws4_ne 21 i (by decide) (Or.inl (by decide))).trans
                ((hws3_ne 21 i (Or.inl (by decide))).trans
                  ((hws2_ne 21 i (by decide)).trans
                    ((hws1_ne 21 i (Or.inl (by decide))).trans (hws_21 i))))),
            fun coord => (hrs5 3 _).trans ((hrs4 3 _).trans ((hrs3 3 _).trans ((hrs2 3 _).trans ((hrs1 3 _).trans (hrs_3 coord))))),
            fun t_tbl i ht3 ht17 => (hrs5 t_tbl i).trans ((hrs4 t_tbl i).trans ((hrs3 t_tbl i).trans
              ((hrs2 t_tbl i).trans ((hrs1 t_tbl i).trans (hrs_hdr t_tbl i ht3 ht17))))),
            hbkt_ms5⟩)
        with ⟨mr6, ⟨hex_r6, hwr6_0, _, _, hwr6_20, _, _, _, hwr6_hdr, hwr6_21,
               hrr6_3, hrr6_hdr, hbkt_r6⟩, sSLoop⟩

      -- r7. w[11, 0] := r_idx + 1
      have hwr6_0' : mr6.words.read (.heap 11 0) = (r_idx : ℤ) := hwr6_0
      rcases exec_wSet_sw SW SR inp sSLoop.2.1 11 (.lit 0) 0 (mem_ASW_11 (i := 0) (by omega))
        (.add rE (.lit 1)) (((r_idx + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, rE, hwr6_0']) (by simp [evalIntExpr, rE])
        with ⟨mr7, sr7, hex_r7, hwr7_0, hwr7_ne, hrr7⟩

      have hcost_r : (20 + ℓ * 40 + ℓ * M₀ * (130 + (20 + (d + 1) * 30))) +
          ((15 + ℓ * 40) + (15 + (10 + (4 + ((5 + S_cnt * (160 + ℓ * 60)) + 10))))) ≤ copyStepCost := by
        dsimp [copyStepCost]
        have hS_mul : S_cnt * (160 + ℓ * 60) ≤ Cap_u * (160 + ℓ * 60) :=
          Nat.mul_le_mul_right _ hS_le_Capu
        have hM_eq : ℓ * M₀ * (130 + (20 + (d + 1) * 30)) = ℓ * M₀ * (150 + (d + 1) * 30) := by ring
        omega
      have sRStep : ExecStmt inp rBody mr mr7 copyStepCost := by
        unfold rBody seqStmts
        exact (ExecStmt.seq sr1 (ExecStmt.seq sr2 (ExecStmt.seq sr3
          (ExecStmt.seq sr4 (ExecStmt.seq sr5 (ExecStmt.seq sSLoop sr7)))))).mono_cost hcost_r

      have hpairs_r_succ : pairsSlot S_cnt = pairsBefore (r_idx + 1) := by
        ext p
        simp only [pairsSlot, pairsBefore, Finset.mem_union, Finset.mem_biUnion, Finset.mem_filter,
          Finset.mem_univ, true_and, Finset.mem_image, Finset.mem_range]
        constructor
        · rintro ((h_act | ⟨r', hr'_lt, sv, hsv, rfl⟩) | ⟨sv, hsv, rfl⟩)
          · exact Or.inl h_act
          · exact Or.inr ⟨r', Nat.lt_succ_of_lt hr'_lt, sv, hsv, rfl⟩
          · exact Or.inr ⟨rFin, Nat.lt_succ_self _, sv, hsv, rfl⟩
        · rintro (h_act | ⟨r', hr'_lt, sv, hsv, rfl⟩)
          · exact Or.inl (Or.inl h_act)
          · rcases Nat.lt_succ_iff_lt_or_eq.mp hr'_lt with hlt | heq
            · exact Or.inl (Or.inr ⟨r', hlt, sv, hsv, rfl⟩)
            · have hr'_eq : r' = rFin := Fin.ext heq
              subst hr'_eq
              exact Or.inr ⟨sv, hsv, rfl⟩

      refine ⟨mr7, sRStep,
        by
          have : 5 * S_cnt ≤ 5 * Cap_u := Nat.mul_le_mul_left 5 hS_le_Capu
          linarith [hex_r7, hex_r6],
        hwr7_0,
        (hwr7_ne 11 20 (Or.inr (by decide))).trans hwr6_20,
        fun coord => (hrr7 3 _).trans (hrr6_3 coord),
        fun t_tbl i ht => (hwr7_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans (hwr6_hdr t_tbl i ht),
        fun t_tbl i ht3 ht17 => (hrr7 t_tbl i).trans (hrr6_hdr t_tbl i ht3 ht17),
        ?_, ?_,
        by
          rw [← hpairs_r_succ]
          exact bucketInv_congr hbkt_r6 (fun t_tbl idx h22 _ => hwr7_ne t_tbl idx (Or.inl (by omega)))⟩
      · intro r' j' hj'
        have hne_pair : ((pairIdx r' j').val : ℤ) ≠ (((pairIdx rFin j).val : ℕ) : ℤ) := by
          intro heq
          have hv : pairIdx r' j' = pairIdx rFin j := Fin.ext (by exact_mod_cast heq)
          rcases pairIdx_inj hv with ⟨_, rfl⟩
          exact hj_not_ins hj'
        rw [hwr7_ne 21 _ (Or.inl (by decide)), hwr6_21, hwr4_ne 21 _ (Or.inr hne_pair),
            hwr3_ne 21 _ (Or.inl (by decide)), hwr2_ne 21 _ (by decide),
            hwr1_ne 21 _ (by decide) (Or.inl (by decide))]
        exact hslot_old r' j' hj'
      · intro r' hr'
        rw [hwr7_ne 21 _ (Or.inl (by decide)), hwr6_21]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hr' with hlt | heq
        · have hne_pair : ((pairIdx r' j).val : ℤ) ≠ (((pairIdx rFin j).val : ℕ) : ℤ) := by
            intro heqp
            have hv : pairIdx r' j = pairIdx rFin j := Fin.ext (by exact_mod_cast heqp)
            rcases pairIdx_inj hv with ⟨rfl, _⟩
            exact Nat.lt_irrefl _ hlt
          rw [hwr4_ne 21 _ (Or.inr hne_pair),
              hwr3_ne 21 _ (Or.inl (by decide)), hwr2_ne 21 _ (by decide),
              hwr1_ne 21 _ (by decide) (Or.inl (by decide))]
          exact hslot_prev r' hlt
        · have hr'_eq : r' = rFin := Fin.ext heq
          subst hr'_eq
          exact hwr4_21)
    with ⟨mem₁, ⟨hex₁, _, _, _, hw₁_hdr, hr₁_hdr, hslot₁_old, hslot₁_j, hbkt₁⟩, sRLoop⟩

  have hpairs_R : pairsBefore R = activePairsOf Cap_u t ω ptsK Finset.univ (insert j Active) := by
    ext ⟨p, sv⟩
    simp only [pairsBefore, Finset.mem_union, mem_activePairsOf_iff, Finset.mem_univ, true_and,
      Finset.mem_biUnion, Finset.mem_filter, Finset.mem_image, Finset.mem_range, Prod.mk.injEq,
      Finset.mem_insert]
    constructor
    · rintro (⟨r', j', hj', rfl, hsv⟩ | ⟨r', _, sv', hsv', rfl, rfl⟩)
      · exact ⟨r', j', Or.inr hj', rfl, hsv⟩
      · exact ⟨r', j, Or.inl rfl, rfl, hsv'⟩
    · rintro ⟨r', j', rfl | hj', rfl, hsv⟩
      · exact Or.inr ⟨r', r'.isLt, sv, hsv, rfl, rfl⟩
      · exact Or.inl ⟨r', j', hj', rfl, hsv⟩

  have sTot : ExecStmt inp (insertBirthPtProg ℓ) mem₀ mem₁
      (60 + d * 35 + R * copyStepCost) := by
    unfold insertBirthPtProg seqStmts
    exact (ExecStmt.seq s1 (ExecStmt.seq s2 (ExecStmt.seq sCopyLoop
      (ExecStmt.seq s4 (ExecStmt.seq s5 sRLoop))))).mono_cost (by omega)

  refine ⟨mem₁, sTot,
    { clean := sRLoop.2.1
      sub_act := Finset.insert_subset_insert j hinv.sub_act
      extra_le := hex₁
      hdr_Rm := (hw₁_hdr 1 0 (by decide)).trans hinv.hdr_Rm
      hdr_m := (hw₁_hdr 1 1 (by decide)).trans hinv.hdr_m
      hdr_R := (hw₁_hdr 1 2 (by decide)).trans hinv.hdr_R
      hdr_Capu := (hw₁_hdr 1 3 (by decide)).trans hinv.hdr_Capu
      hdr_M0 := (hw₁_hdr 1 4 (by decide)).trans hinv.hdr_M0
      hdr_M0pow := (hw₁_hdr 1 5 (by decide)).trans hinv.hdr_M0pow
      hdr_Capq := (hw₁_hdr 1 6 (by decide)).trans hinv.hdr_Capq
      hdr_etaN := (hw₁_hdr 1 7 (by decide)).trans hinv.hdr_etaN
      hdr_etaD := (hw₁_hdr 1 8 (by decide)).trans hinv.hdr_etaD
      hdr_xt := (hr₁_hdr 1 0 (by decide) (by decide)).trans hinv.hdr_xt
      hdr_t := (hr₁_hdr 1 1 (by decide) (by decide)).trans hinv.hdr_t
      hdr_A := (hr₁_hdr 1 2 (by decide) (by decide)).trans hinv.hdr_A
      hdr_B := (hr₁_hdr 1 3 (by decide) (by decide)).trans hinv.hdr_B
      gauss := fun r g coord => (hr₁_hdr 2 _ (by decide) (by decide)).trans (hinv.gauss r g coord)
      slot_cnt := fun r' j' hj' => by
        rcases Finset.mem_insert.mp hj' with rfl | hold
        · exact hslot₁_j r' r'.isLt
        · exact hslot₁_old r' j' hold
      buckets := by rw [← hpairs_R]; exact hbkt₁ }⟩

/-! ### 3. `deletePtProg` and `exec_deletePtProg` -/

def deletePtProg : ArithRAMStmt :=
  let jE := IntExpr.readHeap 11 (.lit 20)
  let rE := IntExpr.readHeap 11 (.lit 0)
  let mE := IntExpr.readHeap 1 (.lit 1)
  let rCntE := IntExpr.readHeap 1 (.lit 2)
  let sCntE := IntExpr.readHeap 11 (.lit 8)
  let sE := IntExpr.readHeap 11 (.lit 16)
  let pairE := IntExpr.readHeap 11 (.lit 22)
  seqStmts
    [ .writeWordHeap 11 (.lit 20) (.intParam (.lit 0)),
      .writeWordHeap 11 (.lit 0) (.lit 0),
      .repeatN rCntE
        (seqStmts
          [ .writeWordHeap 11 (.lit 22) (.add (.mul rE mE) jE),
            .writeWordHeap 11 (.lit 8) (.readHeap 21 pairE),
            .writeWordHeap 11 (.lit 16) (.lit 0),
            .repeatN sCntE
              (seqStmts
                [ bucketRemoveStepStmt,
                  .writeWordHeap 11 (.lit 16) (.add sE (.lit 1)) ]),
            .writeWordHeap 11 (.lit 0) (.add rE (.lit 1)) ]) ]

set_option maxHeartbeats 800000 in
theorem exec_deletePtProg {d ℓ M₀ R m : ℕ}
    (hm : 1 ≤ m)
    {Cap_u Cap_q : ℕ}
    {A B η : ℚ} {x t : ℝ}
    (ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1)))
    (j : Fin m)
    {Inserted Active : Finset (Fin m)} (hj_act : j ∈ Active)
    {extraBnd : ℕ} {mem₀ : ArithRAMMemory}
    (hinv : DataStructInv hm Cap_u Cap_q A B η x t ω ptsK Inserted Active extraBnd mem₀)
    (inp : ArithRAMInput d)
    (hinp_p : inp.intParams = [(j.val : ℤ)]) :
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp deletePtProg mem₀ mem₁ (20 + R * (45 + Cap_u * 165)) ∧
      DataStructInv hm Cap_u Cap_q A B η x t ω ptsK
        Inserted (Active.erase j) (extraBnd + 4 * R * Cap_u) mem₁ := by
  classical
  let SW := AdaptiveSW R ℓ M₀ Cap_q d
  let SR := AdaptiveSR d R ℓ M₀
  have hj_ins : j ∈ Inserted := hinv.sub_act hj_act

  let jE := IntExpr.readHeap 11 (.lit 20)
  let rE := IntExpr.readHeap 11 (.lit 0)
  let mE := IntExpr.readHeap 1 (.lit 1)
  let rCntE := IntExpr.readHeap 1 (.lit 2)
  let sCntE := IntExpr.readHeap 11 (.lit 8)
  let sE := IntExpr.readHeap 11 (.lit 16)
  let pairE := IntExpr.readHeap 11 (.lit 22)

  have hbkt_inj_all : ∀ {S : Finset (Fin (R * m) × ℕ)},
      S ⊆ activePairsOf Cap_u t ω ptsK Finset.univ Active →
      ∀ {k' : Fin (R * m)} {s₁ s₂ : ℕ},
        (k', s₁) ∈ S → (k', s₂) ∈ S →
        globalDataBkt hm t ω ptsK k' s₁ = globalDataBkt hm t ω ptsK k' s₂ → s₁ = s₂ := by
    intro S hsub k' s₁ s₂ h1 h2 heq
    rcases mem_activePairsOf_iff.mp (hsub h1) with ⟨r1, _, j1, _, rfl, hs1_b⟩
    rcases pairIdx_div_mod r1 j1 with ⟨hd1, hm1⟩
    rcases mem_activePairsOf_iff.mp (hsub h2) with ⟨r2, _, j2, _, hp_eq, hs2_b⟩
    rcases pairIdx_inj hp_eq with ⟨rfl, rfl⟩
    exact globalDataBkt_inj_of_lt hm (Cap_u := Cap_u)
      (by simpa [hd1, hm1] using slot_lt_prod_of_lt_bound hs1_b)
      (by simpa [hd1, hm1] using slot_lt_prod_of_lt_bound hs2_b)
      heq

  rcases exec_wSet_sw SW SR inp hinv.clean 11 (.lit 20) 20 (mem_ASW_11 (i := 20) (by omega))
    (.intParam (.lit 0)) (j.val : ℤ) 6
    (by simp [evalIntExpr]) (by simp [evalIntExpr, hinp_p, listGetIntD]) (by simp [evalIntExpr])
    with ⟨m1, s1, hex1, hw1_20, hw1_ne, hr1⟩
  rcases exec_wSet_sw SW SR inp s1.2.1 11 (.lit 0) 0 (mem_ASW_11 (i := 0) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m2, s2, hex2, hw2_0, hw2_ne, hr2⟩

  let pairsRem : ℕ → ℕ → Finset (Fin (R * m) × ℕ) := fun r_lim s_lim =>
    (activePairsOf Cap_u t ω ptsK Finset.univ Active).filter (fun p =>
      ¬ (∃ r' : Fin R, (r'.val < r_lim ∧ p.1 = pairIdx r' j) ∨
                       (r'.val = r_lim ∧ p.1 = pairIdx r' j ∧ p.2 < s_lim)))

  have hpairsRem_sub : ∀ r_lim s_lim,
      pairsRem r_lim s_lim ⊆ activePairsOf Cap_u t ω ptsK Finset.univ Active :=
    fun _ _ => Finset.filter_subset _ _

  let sRemBody : ArithRAMStmt :=
    seqStmts
      [ bucketRemoveStepStmt,
        .writeWordHeap 11 (.lit 16) (.add sE (.lit 1)) ]
  let rRemBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 22) (.add (.mul rE mE) jE),
        .writeWordHeap 11 (.lit 8) (.readHeap 21 pairE),
        .writeWordHeap 11 (.lit 16) (.lit 0),
        .repeatN sCntE sRemBody,
        .writeWordHeap 11 (.lit 0) (.add rE (.lit 1)) ]

  let RRemInv : ℕ → ArithRAMMemory → Prop := fun r_idx mr =>
    extraCells SW SR mr ≤ extraBnd + r_idx * (4 * Cap_u) ∧
    wRead mr 11 0 = (r_idx : ℤ) ∧
    wRead mr 11 20 = (j.val : ℤ) ∧
    (∀ t_tbl i, t_tbl ∉ ([11, 23, 24, 25, 26] : List ℕ) → wRead mr t_tbl i = wRead mem₀ t_tbl i) ∧
    (∀ t_tbl i, rRead mr t_tbl i = rRead mem₀ t_tbl i) ∧
    BucketInv Cap_u (globalDataBkt hm t ω ptsK) (pairsRem r_idx 0) mr

  have hRRem₀ : RRemInv 0 m2 := by
    have hp0 : pairsRem 0 0 = activePairsOf Cap_u t ω ptsK Finset.univ Active := by
      ext p; simp [pairsRem]
    have hwp : ∀ t_tbl i, t_tbl ≠ 11 → wRead m2 t_tbl i = wRead mem₀ t_tbl i :=
      fun t_tbl i ht => (hw2_ne t_tbl i (Or.inl ht)).trans (hw1_ne t_tbl i (Or.inl ht))
    refine ⟨by linarith [hex2, hex1, hinv.extra_le], hw2_0,
      (hw2_ne 11 20 (Or.inr (by decide))).trans hw1_20,
      fun t_tbl i ht => hwp t_tbl i (fun h => ht (by simp [h])),
      fun t_tbl i => (hr2 t_tbl i).trans (hr1 t_tbl i),
      by
        rw [hp0]
        exact bucketInv_congr hinv.buckets (fun t_tbl idx _ _ => hwp t_tbl idx (by omega))⟩

  have hwR_m2 : m2.words.read (.heap 1 2) = (R : ℤ) :=
    (hRRem₀.2.2.2.1 1 2 (by decide)).trans hinv.hdr_R

  rcases exec_repeatN (inp := inp) rCntE rRemBody R 5 (45 + Cap_u * 165) RRemInv s2.2.1 hRRem₀
    (by simp [evalIntExpr, rCntE, hwR_m2])
    (by simp [evalIntExpr, rCntE])
    (fun r_idx hr_lt mr hcmr ⟨hex_r, hwr_0, hwr_20, hwr_pres, hrr_pres, hbkt_r⟩ => by
      let rFin : Fin R := ⟨r_idx, hr_lt⟩
      let S_cnt : ℕ := dataSlotBound Cap_u t (ω rFin) (ptsK j)
      have hS_le_Capu : S_cnt ≤ Cap_u := Nat.min_le_left _ _

      have hwr_0' : mr.words.read (.heap 11 0) = (r_idx : ℤ) := hwr_0
      have hwr_20' : mr.words.read (.heap 11 20) = (j.val : ℤ) := hwr_20
      have hwr_m' : mr.words.read (.heap 1 1) = (m : ℤ) :=
        (hwr_pres 1 1 (by decide)).trans hinv.hdr_m

      -- 1. w[11, 22] := r * m + j
      rcases exec_wSet_sw SW SR inp hcmr 11 (.lit 22) 22 (mem_ASW_11 (i := 22) (by omega))
        (.add (.mul rE mE) jE) (((pairIdx rFin j).val : ℕ) : ℤ) 15
        (by simp [evalIntExpr])
        (by simp only [evalIntExpr, rE, mE, jE, hwr_0', hwr_m', hwr_20', pairIdx, rFin]; push_cast; ring)
        (by simp [evalIntExpr, rE, mE, jE])
        with ⟨mr1, sr1, hex_r1, hwr1_22, hwr1_ne, hrr1⟩

      -- 2. w[11, 8] := w[21, pairE] = S_cnt
      have hwr1_22' : mr1.words.read (.heap 11 22) = (((pairIdx rFin j).val : ℕ) : ℤ) := hwr1_22
      have hwr1_21 : mr1.words.read (.heap 21 (((pairIdx rFin j).val : ℕ) : ℤ)) = (S_cnt : ℤ) :=
        (hwr1_ne 21 _ (Or.inl (by decide))).trans
          ((hwr_pres 21 _ (by decide)).trans (hinv.slot_cnt rFin j hj_ins))
      rcases exec_wSet_sw SW SR inp sr1.2.1 11 (.lit 8) 8 (mem_ASW_11 (i := 8) (by omega))
        (.readHeap 21 pairE) (S_cnt : ℤ) 10
        (by simp [evalIntExpr])
        (by simp [evalIntExpr, pairE, hwr1_22', hwr1_21])
        (by simp [evalIntExpr, pairE])
        with ⟨mr2, sr2, hex_r2, hwr2_8, hwr2_ne, hrr2⟩

      -- 3. w[11, 16] := 0
      rcases exec_wSet_sw SW SR inp sr2.2.1 11 (.lit 16) 16 (mem_ASW_11 (i := 16) (by omega))
        (.lit 0) 0 4
        (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
        with ⟨mr3, sr3, hex_r3, hwr3_16, hwr3_ne, hrr3⟩

      let SRemInv : ℕ → ArithRAMMemory → Prop := fun s_idx ms =>
        extraCells SW SR ms ≤ extraBnd + r_idx * (4 * Cap_u) + 4 * s_idx ∧
        wRead ms 11 0 = (r_idx : ℤ) ∧
        wRead ms 11 8 = (S_cnt : ℤ) ∧
        wRead ms 11 16 = (s_idx : ℤ) ∧
        wRead ms 11 20 = (j.val : ℤ) ∧
        wRead ms 11 22 = (((pairIdx rFin j).val : ℕ) : ℤ) ∧
        (∀ t_tbl i, t_tbl ∉ ([11, 23, 24, 25, 26] : List ℕ) → wRead ms t_tbl i = wRead mem₀ t_tbl i) ∧
        (∀ t_tbl i, rRead ms t_tbl i = rRead mem₀ t_tbl i) ∧
        BucketInv Cap_u (globalDataBkt hm t ω ptsK) (pairsRem r_idx s_idx) ms

      have hSRem₀ : SRemInv 0 mr3 := by
        have hwp3 : ∀ t_tbl i, t_tbl ≠ 11 → wRead mr3 t_tbl i = wRead mr t_tbl i :=
          fun t_tbl i ht => (hwr3_ne t_tbl i (Or.inl ht)).trans
            ((hwr2_ne t_tbl i (Or.inl ht)).trans (hwr1_ne t_tbl i (Or.inl ht)))
        refine ⟨by linarith [hex_r3, hex_r2, hex_r1, hex_r],
          (hwr3_ne 11 0 (Or.inr (by decide))).trans
            ((hwr2_ne 11 0 (Or.inr (by decide))).trans ((hwr1_ne 11 0 (Or.inr (by decide))).trans hwr_0)),
          (hwr3_ne 11 8 (Or.inr (by decide))).trans hwr2_8,
          hwr3_16,
          (hwr3_ne 11 20 (Or.inr (by decide))).trans
            ((hwr2_ne 11 20 (Or.inr (by decide))).trans ((hwr1_ne 11 20 (Or.inr (by decide))).trans hwr_20)),
          (hwr3_ne 11 22 (Or.inr (by decide))).trans
            ((hwr2_ne 11 22 (Or.inr (by decide))).trans hwr1_22),
          fun t_tbl i ht => (hwp3 t_tbl i (fun h => ht (by simp [h]))).trans (hwr_pres t_tbl i ht),
          fun t_tbl i => (hrr3 t_tbl i).trans ((hrr2 t_tbl i).trans ((hrr1 t_tbl i).trans (hrr_pres t_tbl i))),
          bucketInv_congr hbkt_r (fun t_tbl idx _ _ => hwp3 t_tbl idx (by omega))⟩

      have hwr3_8' : mr3.words.read (.heap 11 8) = (S_cnt : ℤ) := hSRem₀.2.2.1
      rcases exec_repeatN (inp := inp) sCntE sRemBody S_cnt 5 165 SRemInv sr3.2.1 hSRem₀
        (by simp [evalIntExpr, sCntE, hwr3_8'])
        (by simp [evalIntExpr, sCntE])
        (fun s_idx hs_lt ms hcms
          ⟨hex_s, hws_0, hws_8, hws_16, hws_20, hws_22, hws_pres, hrs_pres, hbkt_s⟩ => by
          have hmem_ks : (pairIdx rFin j, s_idx) ∈ pairsRem r_idx s_idx := by
            simp only [pairsRem, Finset.mem_filter]
            refine ⟨mem_activePairsOf_iff.mpr ⟨rFin, Finset.mem_univ _, j, hj_act, rfl, hs_lt⟩, ?_⟩
            rintro ⟨r', ⟨hr'_lt, hp_eq⟩ | ⟨hr'_eq, _, hsv⟩⟩
            · rcases pairIdx_inj hp_eq with ⟨rfl, _⟩
              exact Nat.lt_irrefl _ hr'_lt
            · exact Nat.lt_irrefl _ hsv

          have hws_Rm : wRead ms 1 0 = ((R * m : ℕ) : ℤ) :=
            (hws_pres 1 0 (by decide)).trans hinv.hdr_Rm
          have hws_Capu : wRead ms 1 3 = (Cap_u : ℤ) :=
            (hws_pres 1 3 (by decide)).trans hinv.hdr_Capu

          rcases exec_bucketRemoveStep (ℓ := 2 * R * ℓ) (M₀ := M₀) (Cap_u := Cap_u) (Cap_q := Cap_q + d)
            (m := R * m) inp (hbkt_inj_all (hpairsRem_sub r_idx s_idx)) hmem_ks
            hcms hbkt_s hws_Rm hws_Capu hws_22 hws_16
            with ⟨ms1, ss1, hexs1, hbkt_ms1, hws1_ne, hrs1⟩

          have hws1_16 : ms1.words.read (.heap 11 16) = (s_idx : ℤ) :=
            (hws1_ne 11 16 (by decide) (Or.inr (by decide))).trans hws_16
          rcases exec_wSet_sw SW SR inp ss1.2.1 11 (.lit 16) 16 (mem_ASW_11 (i := 16) (by omega))
            (.add sE (.lit 1)) (((s_idx + 1 : ℕ) : ℤ)) 10
            (by simp [evalIntExpr]) (by simp [evalIntExpr, sE, hws1_16]) (by simp [evalIntExpr, sE])
            with ⟨ms2, ss2, hexs2, hws2_16, hws2_ne, hrs2⟩

          have hpairs_erase : (pairsRem r_idx s_idx).erase (pairIdx rFin j, s_idx) =
              pairsRem r_idx (s_idx + 1) := by
            ext ⟨p, sv⟩
            simp only [pairsRem, Finset.mem_erase, Finset.mem_filter]
            constructor
            · rintro ⟨hne, hmem, hnot⟩
              refine ⟨hmem, ?_⟩
              rintro ⟨r', ⟨hr'_lt, hp_eq⟩ | ⟨hr'_eq, hp_eq, hsv⟩⟩
              · exact hnot ⟨r', Or.inl ⟨hr'_lt, hp_eq⟩⟩
              · have hr'_fin : r' = rFin := Fin.ext hr'_eq
                subst hr'_fin
                rcases Nat.lt_succ_iff_lt_or_eq.mp hsv with hlt | rfl
                · exact hnot ⟨rFin, Or.inr ⟨rfl, hp_eq, hlt⟩⟩
                · exact hne (Prod.ext hp_eq rfl)
            · rintro ⟨hmem, hnot⟩
              refine ⟨?_, hmem, ?_⟩
              · rintro ⟨rfl, rfl⟩
                exact hnot ⟨rFin, Or.inr ⟨rfl, rfl, Nat.lt_succ_self _⟩⟩
              · rintro ⟨r', ⟨hr'_lt, hp_eq⟩ | ⟨hr'_eq, hp_eq, hsv⟩⟩
                · exact hnot ⟨r', Or.inl ⟨hr'_lt, hp_eq⟩⟩
                · exact hnot ⟨r', Or.inr ⟨hr'_eq, hp_eq, Nat.lt_succ_of_lt hsv⟩⟩

          refine ⟨ms2, (ExecStmt.seq ss1 ss2).mono_cost (by omega),
            by linarith [hexs2, hexs1, hex_s],
            (hws2_ne 11 0 (Or.inr (by decide))).trans
              ((hws1_ne 11 0 (by decide) (Or.inr (by decide))).trans hws_0),
            (hws2_ne 11 8 (Or.inr (by decide))).trans
              ((hws1_ne 11 8 (by decide) (Or.inr (by decide))).trans hws_8),
            hws2_16,
            (hws2_ne 11 20 (Or.inr (by decide))).trans
              ((hws1_ne 11 20 (by decide) (Or.inr (by decide))).trans hws_20),
            (hws2_ne 11 22 (Or.inr (by decide))).trans
              ((hws1_ne 11 22 (by decide) (Or.inr (by decide))).trans hws_22),
            fun t_tbl i ht => (hws2_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans
              ((hws1_ne t_tbl i (fun h => ht (List.mem_cons_of_mem 11 h))
                (Or.inl (fun h => ht (by simp [h])))).trans (hws_pres t_tbl i ht)),
            fun t_tbl i => (hrs2 t_tbl i).trans ((hrs1 t_tbl i).trans (hrs_pres t_tbl i)),
            by
              rw [← hpairs_erase]
              exact bucketInv_congr hbkt_ms1 (fun t_tbl idx h22 _ => hws2_ne t_tbl idx (Or.inl (by omega)))⟩)
        with ⟨mr4, ⟨hex_r4, hwr4_0, _, _, hwr4_20, _, hwr4_pres, hrr4_pres, hbkt_r4⟩, sSRemLoop⟩

      -- 5. w[11, 0] := r_idx + 1
      have hwr4_0' : mr4.words.read (.heap 11 0) = (r_idx : ℤ) := hwr4_0
      rcases exec_wSet_sw SW SR inp sSRemLoop.2.1 11 (.lit 0) 0 (mem_ASW_11 (i := 0) (by omega))
        (.add rE (.lit 1)) (((r_idx + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, rE, hwr4_0']) (by simp [evalIntExpr, rE])
        with ⟨mr5, sr5, hex_r5, hwr5_0, hwr5_ne, hrr5⟩

      have hpairs_next_r : pairsRem r_idx S_cnt = pairsRem (r_idx + 1) 0 := by
        ext ⟨p, sv⟩
        simp only [pairsRem, Finset.mem_filter]
        constructor
        · rintro ⟨hmem, hnot⟩
          refine ⟨hmem, ?_⟩
          rintro ⟨r', ⟨hr'_lt, hp_eq⟩ | ⟨_, _, hsv⟩⟩
          · rcases Nat.lt_succ_iff_lt_or_eq.mp hr'_lt with hlt | heq
            · exact hnot ⟨r', Or.inl ⟨hlt, hp_eq⟩⟩
            · have hr'_fin : r' = rFin := Fin.ext heq
              subst hr'_fin
              rcases mem_activePairsOf_iff.mp hmem with ⟨r2, _, j2, _, hp2, hsv_b⟩
              rcases pairIdx_inj (hp_eq.symm.trans hp2) with ⟨rfl, rfl⟩
              exact hnot ⟨rFin, Or.inr ⟨rfl, hp_eq, hsv_b⟩⟩
          · omega
        · rintro ⟨hmem, hnot⟩
          refine ⟨hmem, ?_⟩
          rintro ⟨r', ⟨hr'_lt, hp_eq⟩ | ⟨hr'_eq, hp_eq, _⟩⟩
          · exact hnot ⟨r', Or.inl ⟨Nat.lt_succ_of_lt hr'_lt, hp_eq⟩⟩
          · exact hnot ⟨r', Or.inl ⟨by omega, hp_eq⟩⟩

      have hcost_rem : 15 + (10 + (4 + ((5 + S_cnt * 165) + 10))) ≤ 45 + Cap_u * 165 := by
        have : S_cnt * 165 ≤ Cap_u * 165 := Nat.mul_le_mul_right 165 hS_le_Capu
        omega
      refine ⟨mr5,
        (ExecStmt.seq sr1 (ExecStmt.seq sr2 (ExecStmt.seq sr3 (ExecStmt.seq sSRemLoop sr5)))).mono_cost hcost_rem,
        by
          have : 4 * S_cnt ≤ 4 * Cap_u := Nat.mul_le_mul_left 4 hS_le_Capu
          linarith [hex_r5, hex_r4],
        hwr5_0,
        (hwr5_ne 11 20 (Or.inr (by decide))).trans hwr4_20,
        fun t_tbl i ht => (hwr5_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans (hwr4_pres t_tbl i ht),
        fun t_tbl i => (hrr5 t_tbl i).trans (hrr4_pres t_tbl i),
        by
          rw [← hpairs_next_r]
          exact bucketInv_congr hbkt_r4 (fun t_tbl idx h22 _ => hwr5_ne t_tbl idx (Or.inl (by omega)))⟩)
    with ⟨mem₁, ⟨hex₁, _, _, hw₁_pres, hr₁_pres, hbkt₁⟩, sRRemLoop⟩

  have hpairsRem_R : pairsRem R 0 = activePairsOf Cap_u t ω ptsK Finset.univ (Active.erase j) := by
    ext ⟨p, sv⟩
    simp only [pairsRem, Finset.mem_filter, mem_activePairsOf_iff, Finset.mem_univ, true_and,
      Finset.mem_erase]
    constructor
    · rintro ⟨⟨r', j', hj', rfl, hsv⟩, hnot⟩
      refine ⟨r', j', ⟨?_, hj'⟩, rfl, hsv⟩
      rintro rfl
      exact hnot ⟨r', Or.inl ⟨r'.isLt, rfl⟩⟩
    · rintro ⟨r', j', ⟨hne, hj'⟩, rfl, hsv⟩
      refine ⟨⟨r', j', hj', rfl, hsv⟩, ?_⟩
      rintro ⟨r2, ⟨_, hp_eq⟩ | ⟨_, _, hsv0⟩⟩
      · rcases pairIdx_inj hp_eq with ⟨_, rfl⟩
        exact hne rfl
      · omega

  refine ⟨mem₁,
    (ExecStmt.seq s1 (ExecStmt.seq s2 sRRemLoop)).mono_cost (by omega),
    { clean := sRRemLoop.2.1
      sub_act := (Finset.erase_subset j Active).trans hinv.sub_act
      extra_le := by linarith [hex₁]
      hdr_Rm := (hw₁_pres 1 0 (by decide)).trans hinv.hdr_Rm
      hdr_m := (hw₁_pres 1 1 (by decide)).trans hinv.hdr_m
      hdr_R := (hw₁_pres 1 2 (by decide)).trans hinv.hdr_R
      hdr_Capu := (hw₁_pres 1 3 (by decide)).trans hinv.hdr_Capu
      hdr_M0 := (hw₁_pres 1 4 (by decide)).trans hinv.hdr_M0
      hdr_M0pow := (hw₁_pres 1 5 (by decide)).trans hinv.hdr_M0pow
      hdr_Capq := (hw₁_pres 1 6 (by decide)).trans hinv.hdr_Capq
      hdr_etaN := (hw₁_pres 1 7 (by decide)).trans hinv.hdr_etaN
      hdr_etaD := (hw₁_pres 1 8 (by decide)).trans hinv.hdr_etaD
      hdr_xt := (hr₁_pres 1 0).trans hinv.hdr_xt
      hdr_t := (hr₁_pres 1 1).trans hinv.hdr_t
      hdr_A := (hr₁_pres 1 2).trans hinv.hdr_A
      hdr_B := (hr₁_pres 1 3).trans hinv.hdr_B
      gauss := fun r g coord => (hr₁_pres 2 _).trans (hinv.gauss r g coord)
      slot_cnt := fun r' j' hj' => (hw₁_pres 21 _ (by decide)).trans (hinv.slot_cnt r' j' hj')
      buckets := by rw [← hpairsRem_R]; exact hbkt₁ }⟩

end UL.Proof_clm_6_1_adaptive_RaceP32
