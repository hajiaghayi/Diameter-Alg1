import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
import UL.Def.def_6_search_exponents
import UL.Def.def_6_1_gaussian_filter
import UL.Stmt.lem_6_2
import UL.Proof.lem_6_2
import UL.Proof.lem_6_3.H1_RAM
import UL.Proof.lem_6_3.H5_Prob
import UL.Proof.clm_6_1_adaptive.H1a_Net
import UL.Proof.clm_6_1_adaptive.H1b_Lift
set_option autoImplicit false

open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Real

namespace UL.Proof_clm_6_1_adaptive_RaceV30

open UL.Proof_lem_6_3 UL.Proof_clm_6_1_adaptive

/-! ### 1. Rational power approximation `(1 + z / N)^N` and search exponent bounds -/

noncomputable def polyExp (N : ℕ) (z : ℝ) : ℝ :=
  (1 + z / (N : ℝ)) ^ N

theorem polyExp_ge_one_and_le_exp {z : ℝ} {N : ℕ} (hz : 0 ≤ z) (hN : 1 ≤ N) :
    1 ≤ polyExp N z ∧ polyExp N z ≤ Real.exp z := by
  unfold polyExp
  have hN_pos : (0 : ℝ) < (N : ℝ) := by exact_mod_cast hN
  have hbase : 1 ≤ 1 + z / (N : ℝ) := by
    have : 0 ≤ z / (N : ℝ) := div_nonneg hz hN_pos.le
    linarith
  refine ⟨one_le_pow₀ hbase, ?_⟩
  calc (1 + z / (N : ℝ)) ^ N
      ≤ (Real.exp (z / (N : ℝ))) ^ N := by
        refine pow_le_pow_left₀ (by linarith) ?_ N
        linarith [Real.add_one_le_exp (z / (N : ℝ))]
    _ = Real.exp ((N : ℝ) * (z / (N : ℝ))) := (Real.exp_nat_mul _ N).symm
    _ = Real.exp z := by congr 1; field_simp [hN_pos.ne']

theorem one_plus_div_pow_approx {z : ℝ} {N : ℕ} (hz : 0 ≤ z) (hN : 3 * z ^ 2 + 1 ≤ (N : ℝ)) :
    1 ≤ polyExp N z ∧
    polyExp N z ≤ Real.exp z ∧
    Real.exp z ≤ 2 * polyExp N z := by
  have hN1_r : (1 : ℝ) ≤ (N : ℝ) := by nlinarith
  have hN1 : 1 ≤ N := by exact_mod_cast hN1_r
  rcases polyExp_ge_one_and_le_exp hz hN1 with ⟨h1, h2⟩
  unfold polyExp at *
  have hN_pos : (0 : ℝ) < (N : ℝ) := by exact_mod_cast hN1
  have hN_ne : (N : ℝ) ≠ 0 := hN_pos.ne'
  have hz_lt_N : z < (N : ℝ) := by
    have : 0 < 3 * (z - 1 / 6) ^ 2 + 11 / 12 := by positivity
    nlinarith
  have hNmz_pos : 0 < (N : ℝ) - z := by linarith
  have h1m_pos : 0 < 1 - z / (N : ℝ) := by
    rw [sub_pos, div_lt_one hN_pos]; exact hz_lt_N
  have h1m_pow : (1 - z / (N : ℝ)) ^ N ≤ Real.exp (-z) := by
    calc (1 - z / (N : ℝ)) ^ N
        ≤ (Real.exp (-(z / (N : ℝ)))) ^ N := by
          refine pow_le_pow_left₀ h1m_pos.le ?_ N
          linarith [Real.add_one_le_exp (-(z / (N : ℝ)))]
      _ = Real.exp ((N : ℝ) * (-(z / (N : ℝ)))) := (Real.exp_nat_mul _ N).symm
      _ = Real.exp (-z) := by congr 1; field_simp
  have hexp_le_inv : Real.exp z ≤ ((N : ℝ) / ((N : ℝ) - z)) ^ N := by
    have hprod_le : Real.exp z * (1 - z / (N : ℝ)) ^ N ≤ 1 := by
      calc Real.exp z * (1 - z / (N : ℝ)) ^ N
          ≤ Real.exp z * Real.exp (-z) :=
            mul_le_mul_of_nonneg_left h1m_pow (Real.exp_pos z).le
        _ = 1 := by rw [← Real.exp_add]; simp
    have hrew : (1 - z / (N : ℝ)) = ((N : ℝ) - z) / (N : ℝ) := by field_simp
    rw [hrew, div_pow] at hprod_le
    rw [div_pow, le_div_iff₀ (pow_pos hNmz_pos N)]
    have hmul := mul_le_mul_of_nonneg_right hprod_le (pow_nonneg hN_pos.le N)
    calc Real.exp z * ((N : ℝ) - z) ^ N
        = Real.exp z * (((N : ℝ) - z) ^ N / (N : ℝ) ^ N) * (N : ℝ) ^ N := by
          field_simp [pow_ne_zero N hN_ne]
      _ ≤ 1 * (N : ℝ) ^ N := hmul
      _ = (N : ℝ) ^ N := one_mul _
  have hN2mz2_pos : 0 < (N : ℝ) ^ 2 - z ^ 2 := by nlinarith
  have hfrac_le : z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2) ≤ 1 / (2 * (N : ℝ)) := by
    rw [div_le_div_iff₀ hN2mz2_pos (by positivity)]
    have : (3 * z ^ 2 + 1) * (N : ℝ) ≤ (N : ℝ) ^ 2 := by nlinarith
    nlinarith
  have hcorr_pow : (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) ^ N ≤ 2 := by
    calc (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) ^ N
        ≤ (1 + 1 / (2 * (N : ℝ))) ^ N :=
          pow_le_pow_left₀ (by positivity) (by linarith) N
      _ ≤ (Real.exp (1 / (2 * (N : ℝ)))) ^ N := by
          refine pow_le_pow_left₀ (by positivity) ?_ N
          linarith [Real.add_one_le_exp (1 / (2 * (N : ℝ)))]
      _ = Real.exp ((N : ℝ) * (1 / (2 * (N : ℝ)))) := (Real.exp_nat_mul _ N).symm
      _ = Real.exp (1 / 2 : ℝ) := by congr 1; field_simp
      _ ≤ 2 := exp_half_le_two
  have hdecomp : (N : ℝ) / ((N : ℝ) - z) =
      (1 + z / (N : ℝ)) * (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) := by
    field_simp [hNmz_pos.ne', hN2mz2_pos.ne']
    ring
  refine ⟨h1, h2, ?_⟩
  calc Real.exp z ≤ ((N : ℝ) / ((N : ℝ) - z)) ^ N := hexp_le_inv
    _ = (1 + z / (N : ℝ)) ^ N * (1 + z ^ 2 / ((N : ℝ) ^ 2 - z ^ 2)) ^ N := by
        rw [hdecomp, mul_pow]
    _ ≤ (1 + z / (N : ℝ)) ^ N * 2 :=
        mul_le_mul_of_nonneg_left hcorr_pow (by positivity)
    _ = 2 * (1 + z / (N : ℝ)) ^ N := mul_comm _ _

theorem I_h_bounds {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1) :
    1 ≤ I_h h x ∧ I_h h x ≤ 2 ∧
    0 ≤ u_search h x ∧ u_search h x ≤ 1 ∧
    0 ≤ q_search h x ∧ q_search h x ≤ 2 ∧
    1 + u_search h x = I_h h x := by
  have h1mh2 : 0 < 1 - h ^ 2 := by nlinarith
  have hu_eq : u_search h x = (x - h) ^ 2 / (1 - h ^ 2) := by
    unfold u_search I_h; field_simp; ring
  have hu0 : 0 ≤ u_search h x := by rw [hu_eq]; positivity
  have hI_ge : 1 ≤ I_h h x := by unfold u_search at hu0; linarith
  have h2mI : 0 ≤ 2 - I_h h x := by
    have hrew : 2 - I_h h x = ((1 - x ^ 2) + 2 * h * (x - h)) / (1 - h ^ 2) := by
      unfold I_h; field_simp; ring
    rw [hrew]
    exact div_nonneg (by nlinarith) h1mh2.le
  have hI_le : I_h h x ≤ 2 := by linarith
  have hu_le : u_search h x ≤ 1 := by unfold u_search; linarith
  have hq_eq : q_search h x = (1 - h * x) ^ 2 / (1 - h ^ 2) := by
    unfold q_search I_h; field_simp; ring
  have hq0 : 0 ≤ q_search h x := by rw [hq_eq]; positivity
  have hq_le : q_search h x ≤ 2 := by unfold q_search; nlinarith
  exact ⟨hI_ge, hI_le, hu0, hu_le, hq0, hq_le, by unfold u_search; ring⟩

/-! ### 2. Pure Lean threshold, base-cap count, and doubling cap definitions -/

def L_m (m : ℕ) : ℕ :=
  natBitLength m

theorem L_m_bounds {m : ℕ} (hm : 1 ≤ m) :
    1 ≤ L_m m ∧
    2 ^ (L_m m - 1) ≤ m ∧
    m < 2 ^ (L_m m) ∧
    (∀ j < L_m m - 1, 2 ^ (j + 1) ≤ m) ∧
    (1 / 2 : ℝ) ≤ Real.log (2 * (m : ℝ)) ∧
    (L_m m : ℝ) ≤ 2 * Real.log (2 * (m : ℝ)) := by
  unfold L_m natBitLength
  set k := Nat.log 2 m
  have hk_le : 2 ^ k ≤ m := Nat.pow_log_le_self 2 (by omega)
  have hm_lt : m < 2 ^ (k + 1) := Nat.lt_pow_succ_log_self (by decide) m
  have hsub : k + 1 - 1 = k := by omega
  have hj_le : ∀ j < k + 1 - 1, 2 ^ (j + 1) ≤ m := by
    intro j hj
    exact (Nat.pow_le_pow_right (by decide) (by omega : j + 1 ≤ k)).trans hk_le
  have h2m_ge : (2 : ℝ) ≤ 2 * (m : ℝ) := by
    have : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
    linarith
  have hlog_half : (1 / 2 : ℝ) ≤ Real.log (2 * (m : ℝ)) := by
    have hexp_le : Real.exp (1 / 2 : ℝ) ≤ 2 * (m : ℝ) := exp_half_le_two.trans h2m_ge
    calc (1 / 2 : ℝ) = Real.log (Real.exp (1 / 2 : ℝ)) := (Real.log_exp _).symm
      _ ≤ Real.log (2 * (m : ℝ)) := Real.log_le_log (Real.exp_pos _) hexp_le
  have hpow_2m : 2 ^ (k + 1) ≤ 2 * m := by
    rw [pow_succ']
    omega
  have hpow_r : (2 : ℝ) ^ (k + 1) ≤ 2 * (m : ℝ) := by exact_mod_cast hpow_2m
  have hexp_k1 : Real.exp (((k + 1 : ℕ) : ℝ) / 2) ≤ 2 * (m : ℝ) := by
    calc Real.exp (((k + 1 : ℕ) : ℝ) / 2)
        = Real.exp ((k + 1 : ℕ) * (1 / 2 : ℝ)) := by ring_nf
      _ = (Real.exp (1 / 2 : ℝ)) ^ (k + 1) := Real.exp_nat_mul _ (k + 1)
      _ ≤ (2 : ℝ) ^ (k + 1) := pow_le_pow_left₀ (Real.exp_pos _).le exp_half_le_two (k + 1)
      _ ≤ 2 * (m : ℝ) := hpow_r
  have hk1_log : ((k + 1 : ℕ) : ℝ) ≤ 2 * Real.log (2 * (m : ℝ)) := by
    have h1 : ((k + 1 : ℕ) : ℝ) / 2 ≤ Real.log (2 * (m : ℝ)) := by
      rw [← Real.log_exp (((k + 1 : ℕ) : ℝ) / 2)]
      exact Real.log_le_log (Real.exp_pos _) hexp_k1
    linarith
  exact ⟨by omega, by simpa [hsub] using hk_le, hm_lt, hj_le, hlog_half, hk1_log⟩

def N_pow (ℓ m : ℕ) : ℕ :=
  1000 * ℓ ^ 2 * (L_m m) ^ 4 + 1

noncomputable def tStep (ℓ L k : ℕ) : ℝ :=
  1 + (k : ℝ) / ((ℓ * L : ℕ) : ℝ)

noncomputable def zStep (ℓ L k : ℕ) : ℝ :=
  (ℓ : ℝ) * (tStep ℓ L k) ^ 2 / 2

theorem exists_k_step {ℓ m : ℕ} (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) :
    ∃ k : ℕ, 2 * (m : ℝ) ≤ polyExp (N_pow ℓ m) (zStep ℓ (L_m m) k) := by
  rcases L_m_bounds hm with ⟨hL1, _, hm_lt, _, _, _⟩
  let L := L_m m
  let K_hi := ℓ * L * (L + 2)
  refine ⟨K_hi, ?_⟩
  have hℓL_pos : (0 : ℝ) < ((ℓ * L : ℕ) : ℝ) := by
    have : 1 ≤ ℓ * L := Nat.mul_pos hℓ hL1
    exact_mod_cast this
  have ht_eq : tStep ℓ L K_hi = (L : ℝ) + 3 := by
    unfold tStep
    dsimp [K_hi]
    push_cast
    have hℓ0 : (ℓ : ℝ) ≠ 0 := by positivity
    have hL0 : (L : ℝ) ≠ 0 := by positivity
    field_simp [hℓ0, hL0]; ring
  have hL_r : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast hL1
  have hℓ_r : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
  have hz_ge : (L : ℝ) + 2 ≤ zStep ℓ L K_hi := by
    unfold zStep
    rw [ht_eq]
    have hsq : 2 * ((L : ℝ) + 2) ≤ ((L : ℝ) + 3) ^ 2 := by nlinarith
    have h1 : 2 * ((L : ℝ) + 2) ≤ (ℓ : ℝ) * ((L : ℝ) + 3) ^ 2 := by nlinarith
    linarith
  have hz_le : zStep ℓ L K_hi ≤ 8 * (ℓ : ℝ) * (L : ℝ) ^ 2 := by
    unfold zStep
    rw [ht_eq]
    have ht4 : (L : ℝ) + 3 ≤ 4 * (L : ℝ) := by linarith
    have hsq : ((L : ℝ) + 3) ^ 2 ≤ 16 * (L : ℝ) ^ 2 := by nlinarith
    nlinarith
  have hz_nn : 0 ≤ zStep ℓ L K_hi := by linarith
  have hN_cond : 3 * (zStep ℓ L K_hi) ^ 2 + 1 ≤ (N_pow ℓ m : ℝ) := by
    have hsq : (zStep ℓ L K_hi) ^ 2 ≤ 64 * (ℓ : ℝ) ^ 2 * (L : ℝ) ^ 4 := by nlinarith
    unfold N_pow
    change 3 * (zStep ℓ L K_hi) ^ 2 + 1 ≤ ((1000 * ℓ ^ 2 * L ^ 4 + 1 : ℕ) : ℝ)
    push_cast
    nlinarith
  rcases one_plus_div_pow_approx hz_nn hN_cond with ⟨_, _, hexp_le⟩
  have hexp2_ge4 : (4 : ℝ) ≤ Real.exp 2 := by
    have h2e : (2 : ℝ) ≤ Real.exp 1 := two_le_exp_one
    have hrew : Real.exp 2 = Real.exp 1 * Real.exp 1 := by rw [← Real.exp_add]; norm_num
    rw [hrew]; nlinarith
  have hexpL_ge : (m : ℝ) ≤ Real.exp (L : ℝ) := by
    have hm_le_pow : (m : ℝ) ≤ (2 : ℝ) ^ L := by exact_mod_cast hm_lt.le
    have hpow_le_exp : (2 : ℝ) ^ L ≤ Real.exp (L : ℝ) := by
      rw [show (L : ℝ) = (L : ℕ) * (1 : ℝ) by ring, Real.exp_nat_mul]
      exact pow_le_pow_left₀ (by norm_num) two_le_exp_one L
    exact hm_le_pow.trans hpow_le_exp
  have hexp_z : 4 * (m : ℝ) ≤ Real.exp (zStep ℓ L K_hi) := by
    calc 4 * (m : ℝ)
        ≤ Real.exp 2 * Real.exp (L : ℝ) :=
          mul_le_mul hexp2_ge4 hexpL_ge (by positivity) (Real.exp_pos 2).le
      _ = Real.exp ((L : ℝ) + 2) := by rw [← Real.exp_add]; ring_nf
      _ ≤ Real.exp (zStep ℓ L K_hi) := Real.exp_le_exp.mpr hz_ge
  linarith

noncomputable def kStar (ℓ m : ℕ) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) : ℕ :=
  open Classical in Nat.find (exists_k_step hℓ hm)

noncomputable def tParam (ℓ m : ℕ) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) : ℝ :=
  tStep ℓ (L_m m) (kStar ℓ m hℓ hm)

noncomputable def cExpBound (ℓ : ℕ) : ℝ :=
  max (Real.exp ((ℓ : ℝ) / 2)) (4 * Real.exp 4)

set_option maxHeartbeats 800000 in
theorem tParam_bounds {ℓ m : ℕ} (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) :
    let L := L_m m
    let k := kStar ℓ m hℓ hm
    let t := tParam ℓ m hℓ hm
    let z_u := (ℓ : ℝ) * t ^ 2 / 2
    k ≤ ℓ * L * (L + 2) ∧
    (∀ j < k, polyExp (N_pow ℓ m) (zStep ℓ L j) < 2 * (m : ℝ)) ∧
    2 * (m : ℝ) ≤ polyExp (N_pow ℓ m) z_u ∧
    1 ≤ t ∧
    t ≤ 4 * (L : ℝ) ∧
    3 * (2 * z_u) ^ 2 + 1 ≤ (N_pow ℓ m : ℝ) ∧
    (m : ℝ) ≤ Real.exp z_u ∧
    Real.exp z_u ≤ cExpBound ℓ * (m : ℝ) := by
  classical
  dsimp only
  rcases L_m_bounds hm with ⟨hL1, _, _, _, _, _⟩
  let L := L_m m
  let k := kStar ℓ m hℓ hm
  let t := tParam ℓ m hℓ hm
  let z_u := (ℓ : ℝ) * t ^ 2 / 2
  have hk_spec : 2 * (m : ℝ) ≤ polyExp (N_pow ℓ m) (zStep ℓ L k) :=
    Nat.find_spec (exists_k_step hℓ hm)
  have hk_min : ∀ j < k, polyExp (N_pow ℓ m) (zStep ℓ L j) < 2 * (m : ℝ) :=
    fun j hj => not_le.mp (Nat.find_min (exists_k_step hℓ hm) hj)
  have hk_ub : k ≤ ℓ * L * (L + 2) := by
    by_contra hgt
    have hlt : ℓ * L * (L + 2) < k := by omega
    -- Re-prove witness property at `K_hi = ℓ * L * (L + 2)` via `exists_k_step` proof:
    -- even cleaner: `zStep ℓ L` is monotone in `k`, so let's check `zStep` monotonicity!
    have hmono : ∀ a b : ℕ, a ≤ b →
        polyExp (N_pow ℓ m) (zStep ℓ L a) ≤ polyExp (N_pow ℓ m) (zStep ℓ L b) := by
      intro a b hab
      unfold polyExp zStep tStep
      have hab_r : (a : ℝ) ≤ (b : ℝ) := by exact_mod_cast hab
      have hden_nn : (0 : ℝ) ≤ ((ℓ * L : ℕ) : ℝ) := by positivity
      have ht_le : 1 + (a : ℝ) / ((ℓ * L : ℕ) : ℝ) ≤ 1 + (b : ℝ) / ((ℓ * L : ℕ) : ℝ) := by
        linarith [div_le_div_of_nonneg_right hab_r hden_nn]
      have hsq_le : (1 + (a : ℝ) / ((ℓ * L : ℕ) : ℝ)) ^ 2 ≤
          (1 + (b : ℝ) / ((ℓ * L : ℕ) : ℝ)) ^ 2 :=
        pow_le_pow_left₀ (by positivity) ht_le 2
      have hz_le : (ℓ : ℝ) * (1 + (a : ℝ) / ((ℓ * L : ℕ) : ℝ)) ^ 2 / 2 ≤
          (ℓ : ℝ) * (1 + (b : ℝ) / ((ℓ * L : ℕ) : ℝ)) ^ 2 / 2 := by
        have := mul_le_mul_of_nonneg_left hsq_le (by positivity : (0 : ℝ) ≤ (ℓ : ℝ))
        linarith
      refine pow_le_pow_left₀ (by positivity) ?_ (N_pow ℓ m)
      linarith [div_le_div_of_nonneg_right hz_le (by positivity : (0 : ℝ) ≤ (N_pow ℓ m : ℝ))]
    -- Check `K_hi = ℓ * L * (L + 2)` directly:
    have hℓL_pos : (0 : ℝ) < ((ℓ * L : ℕ) : ℝ) := by
      exact_mod_cast (Nat.mul_pos hℓ hL1)
    have ht_hi : tStep ℓ L (ℓ * L * (L + 2)) = (L : ℝ) + 3 := by
      unfold tStep; push_cast
      have hℓ0 : (ℓ : ℝ) ≠ 0 := by positivity
      have hL0 : (L : ℝ) ≠ 0 := by positivity
      field_simp [hℓ0, hL0]; ring
    have hL_r : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast hL1
    have hℓ_r : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
    have hz_ge : (L : ℝ) + 2 ≤ zStep ℓ L (ℓ * L * (L + 2)) := by
      unfold zStep; rw [ht_hi]; nlinarith
    have hz_le : zStep ℓ L (ℓ * L * (L + 2)) ≤ 8 * (ℓ : ℝ) * (L : ℝ) ^ 2 := by
      unfold zStep; rw [ht_hi]
      have : ((L : ℝ) + 3) ^ 2 ≤ 16 * (L : ℝ) ^ 2 := by nlinarith
      nlinarith
    have hN_c : 3 * (zStep ℓ L (ℓ * L * (L + 2))) ^ 2 + 1 ≤ (N_pow ℓ m : ℝ) := by
      have : (zStep ℓ L (ℓ * L * (L + 2))) ^ 2 ≤ 64 * (ℓ : ℝ) ^ 2 * (L : ℝ) ^ 4 := by nlinarith
      unfold N_pow
      change 3 * (zStep ℓ L (ℓ * L * (L + 2))) ^ 2 + 1 ≤ ((1000 * ℓ ^ 2 * L ^ 4 + 1 : ℕ) : ℝ)
      push_cast; nlinarith
    rcases one_plus_div_pow_approx (by linarith) hN_c with ⟨_, _, hexp_le⟩
    have hexp2_ge4 : (4 : ℝ) ≤ Real.exp 2 := by
      have hrew : Real.exp 2 = Real.exp 1 * Real.exp 1 := by rw [← Real.exp_add]; norm_num
      rw [hrew]; nlinarith [two_le_exp_one]
    have hm_lt := (L_m_bounds hm).2.2.1
    have hexpL_ge : (m : ℝ) ≤ Real.exp (L : ℝ) := by
      have hm_le_pow : (m : ℝ) ≤ (2 : ℝ) ^ L := by exact_mod_cast hm_lt.le
      have hpow_le_exp : (2 : ℝ) ^ L ≤ Real.exp (L : ℝ) := by
        rw [show (L : ℝ) = (L : ℕ) * (1 : ℝ) by ring, Real.exp_nat_mul]
        exact pow_le_pow_left₀ (by norm_num) two_le_exp_one L
      exact hm_le_pow.trans hpow_le_exp
    have hexp_z : 4 * (m : ℝ) ≤ Real.exp (zStep ℓ L (ℓ * L * (L + 2))) := by
      calc 4 * (m : ℝ) ≤ Real.exp 2 * Real.exp (L : ℝ) :=
            mul_le_mul hexp2_ge4 hexpL_ge (by positivity) (Real.exp_pos 2).le
        _ = Real.exp ((L : ℝ) + 2) := by rw [← Real.exp_add]; ring_nf
        _ ≤ Real.exp (zStep ℓ L (ℓ * L * (L + 2))) := Real.exp_le_exp.mpr hz_ge
    linarith [hk_min (ℓ * L * (L + 2)) hlt]

  have hzu_eq : z_u = zStep ℓ L k := rfl
  have ht_ge1 : 1 ≤ t := by
    dsimp only [t]; unfold tParam tStep
    have : (0 : ℝ) ≤ (kStar ℓ m hℓ hm : ℝ) / ((ℓ * L_m m : ℕ) : ℝ) := by positivity
    linarith
  have hℓL_pos : (0 : ℝ) < ((ℓ * L : ℕ) : ℝ) := by exact_mod_cast (Nat.mul_pos hℓ hL1)
  have hL_r : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast hL1
  have ht_le4L : t ≤ 4 * (L : ℝ) := by
    dsimp only [t]; unfold tParam tStep
    have hk_r : (k : ℝ) ≤ ((ℓ * L * (L + 2) : ℕ) : ℝ) := by exact_mod_cast hk_ub
    have hdiv : (k : ℝ) / ((ℓ * L : ℕ) : ℝ) ≤ (L : ℝ) + 2 := by
      rw [div_le_iff₀ hℓL_pos]
      push_cast at hk_r ⊢
      linarith
    linarith
  have hzu_le : z_u ≤ 8 * (ℓ : ℝ) * (L : ℝ) ^ 2 := by
    dsimp [z_u]
    have hsq : t ^ 2 ≤ 16 * (L : ℝ) ^ 2 := by nlinarith
    nlinarith [show (0 : ℝ) ≤ (ℓ : ℝ) by positivity]
  have hN_2zu : 3 * (2 * z_u) ^ 2 + 1 ≤ (N_pow ℓ m : ℝ) := by
    have h2zu_le : 2 * z_u ≤ 16 * (ℓ : ℝ) * (L : ℝ) ^ 2 := by linarith
    have h2zu_nn : 0 ≤ 2 * z_u := by dsimp [z_u]; positivity
    have hsq : (2 * z_u) ^ 2 ≤ 256 * (ℓ : ℝ) ^ 2 * (L : ℝ) ^ 4 := by
      calc (2 * z_u) ^ 2 ≤ (16 * (ℓ : ℝ) * (L : ℝ) ^ 2) ^ 2 := pow_le_pow_left₀ h2zu_nn h2zu_le 2
        _ = 256 * (ℓ : ℝ) ^ 2 * (L : ℝ) ^ 4 := by ring
    unfold N_pow
    change 3 * (2 * z_u) ^ 2 + 1 ≤ ((1000 * ℓ ^ 2 * L ^ 4 + 1 : ℕ) : ℝ)
    push_cast
    nlinarith
  have hm_r1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
  have hN1 : 1 ≤ N_pow ℓ m := by unfold N_pow; omega
  have hm_le_exp : (m : ℝ) ≤ Real.exp z_u := by
    have hp_le := (polyExp_ge_one_and_le_exp (by dsimp [z_u]; positivity : 0 ≤ z_u) hN1).2
    have hk_spec' : 2 * (m : ℝ) ≤ polyExp (N_pow ℓ m) z_u := by simpa [hzu_eq] using hk_spec
    linarith
  have hexp_ub : Real.exp z_u ≤ cExpBound ℓ * (m : ℝ) := by
    by_cases hk0 : k = 0
    · have ht1 : t = 1 := by change tStep ℓ L k = 1; unfold tStep; simp [hk0]
      have hzu_0 : z_u = (ℓ : ℝ) / 2 := by dsimp [z_u]; rw [ht1]; ring
      rw [hzu_0]
      calc Real.exp ((ℓ : ℝ) / 2)
          ≤ cExpBound ℓ := le_max_left _ _
        _ = cExpBound ℓ * 1 := by ring
        _ ≤ cExpBound ℓ * (m : ℝ) :=
            mul_le_mul_of_nonneg_left hm_r1 (le_trans (Real.exp_pos _).le (le_max_left _ _))
    · have hk_pos : 1 ≤ k := by omega
      let j := k - 1
      have hj_lt : j < k := by omega
      have hj_poly : polyExp (N_pow ℓ m) (zStep ℓ L j) < 2 * (m : ℝ) := hk_min j hj_lt
      have ht_prev_le : tStep ℓ L j ≤ t := by
        change tStep ℓ L j ≤ tStep ℓ L k
        unfold tStep
        have : (j : ℝ) ≤ (k : ℝ) := by exact_mod_cast hj_lt.le
        exact add_le_add_right (div_le_div_of_nonneg_right this hℓL_pos.le) 1
      have hz_prev_le : zStep ℓ L j ≤ z_u := by
        unfold zStep
        dsimp [z_u]
        have hsq : (tStep ℓ L j) ^ 2 ≤ t ^ 2 :=
          pow_le_pow_left₀ (by unfold tStep; positivity) ht_prev_le 2
        have := mul_le_mul_of_nonneg_left hsq (by positivity : (0 : ℝ) ≤ (ℓ : ℝ))
        linarith
      have hN_prev : 3 * (zStep ℓ L j) ^ 2 + 1 ≤ (N_pow ℓ m : ℝ) := by
        have h1 : (zStep ℓ L j) ^ 2 ≤ (2 * z_u) ^ 2 :=
          pow_le_pow_left₀ (by unfold zStep; positivity) (by linarith [ show 0 ≤ z_u by positivity ]) 2
        nlinarith
      have hexp_prev : Real.exp (zStep ℓ L j) ≤ 4 * (m : ℝ) := by
        have h := (one_plus_div_pow_approx (by unfold zStep; positivity) hN_prev).2.2
        linarith
      have hdiff_t : t - tStep ℓ L j = 1 / ((ℓ * L : ℕ) : ℝ) := by
        dsimp only [t]; unfold tParam tStep
        have hkj : (k : ℝ) = (j : ℝ) + 1 := by
          have : k = j + 1 := by omega
          rw [this]; push_cast; ring
        rw [hkj]; ring
      have hdiff_z : z_u - zStep ℓ L j ≤ 4 := by
        have hsum_t : t + tStep ℓ L j ≤ 8 * (L : ℝ) := by linarith
        have hrew : z_u - zStep ℓ L j =
            ((ℓ : ℝ) / 2) * (t - tStep ℓ L j) * (t + tStep ℓ L j) := by
          dsimp [z_u]; unfold zStep; ring
        rw [hrew, hdiff_t]
        have h1 : ((ℓ : ℝ) / 2) * (1 / ((ℓ * L : ℕ) : ℝ)) * (t + tStep ℓ L j) ≤
            ((ℓ : ℝ) / 2) * (1 / ((ℓ * L : ℕ) : ℝ)) * (8 * (L : ℝ)) :=
          mul_le_mul_of_nonneg_left hsum_t (by positivity)
        have h2 : ((ℓ : ℝ) / 2) * (1 / ((ℓ * L : ℕ) : ℝ)) * (8 * (L : ℝ)) = 4 := by
          push_cast
          have hℓ0 : (ℓ : ℝ) ≠ 0 := by positivity
          have hL0 : (L : ℝ) ≠ 0 := by positivity
          field_simp [hℓ0, hL0]; ring
        linarith
      have hexp_diff : Real.exp (z_u - zStep ℓ L j) ≤ Real.exp 4 :=
        Real.exp_le_exp.mpr hdiff_z
      calc Real.exp z_u
          = Real.exp (z_u - zStep ℓ L j) * Real.exp (zStep ℓ L j) := by
              rw [← Real.exp_add]; ring_nf
        _ ≤ Real.exp 4 * (4 * (m : ℝ)) :=
            mul_le_mul hexp_diff hexp_prev (Real.exp_pos _).le (Real.exp_pos _).le
        _ = (4 * Real.exp 4) * (m : ℝ) := by ring
        _ ≤ cExpBound ℓ * (m : ℝ) :=
            mul_le_mul_of_nonneg_right (le_max_right _ _) (by positivity)
  exact ⟨hk_ub, hk_min, hk_spec, ht_ge1, ht_le4L, hN_2zu, hm_le_exp, hexp_ub⟩

/-! ### 3. Doubling helper `doubleUntil` and its `ArithRAM` subroutine -/

theorem exists_pow2_ge (target : ℝ) : ∃ j : ℕ, target ≤ ((2 ^ j : ℕ) : ℝ) := by
  let n := Nat.ceil (max 0 target) + 1
  refine ⟨n, ?_⟩
  have h1 : target ≤ (n : ℝ) := by
    dsimp [n]; push_cast
    linarith [le_max_right 0 target, Nat.le_ceil (max 0 target)]
  exact h1.trans (by simpa using nat_cast_le_two_pow n)

noncomputable def doubleSteps (target : ℝ) : ℕ :=
  open Classical in Nat.find (exists_pow2_ge target)

noncomputable def doubleUntil (target : ℝ) : ℕ :=
  2 ^ (doubleSteps target)

theorem doubleUntil_props {target B : ℝ} (hB1 : 1 ≤ B) (hB : target ≤ B) :
    1 ≤ doubleUntil target ∧
    target ≤ (doubleUntil target : ℝ) ∧
    (doubleUntil target : ℝ) ≤ 2 * B ∧
    (doubleSteps target : ℝ) ≤ 2 * Real.log B + 2 ∧
    (∀ j < doubleSteps target, ((2 ^ j : ℕ) : ℝ) < target) := by
  classical
  let K := doubleSteps target
  have hspec : target ≤ ((2 ^ K : ℕ) : ℝ) := Nat.find_spec (exists_pow2_ge target)
  have hmin : ∀ j < K, ((2 ^ j : ℕ) : ℝ) < target :=
    fun j hj => not_le.mp (Nat.find_min (exists_pow2_ge target) hj)
  have hpos : 1 ≤ doubleUntil target := Nat.one_le_two_pow
  by_cases hK0 : K = 0
  · refine ⟨hpos, hspec, ?_, ?_, hmin⟩
    · unfold doubleUntil; rw [show doubleSteps target = 0 from hK0]; norm_num; linarith
    · rw [show doubleSteps target = 0 from hK0]
      have : 0 ≤ Real.log B := Real.log_nonneg hB1
      push_cast; linarith
  · have hK1 : 1 ≤ K := by omega
    have hprev : ((2 ^ (K - 1) : ℕ) : ℝ) < B := (hmin (K - 1) (by omega)).trans_le hB
    have hdu_ub : (doubleUntil target : ℝ) ≤ 2 * B := by
      unfold doubleUntil
      have hsub : K = (K - 1) + 1 := by omega
      change ((2 ^ K : ℕ) : ℝ) ≤ 2 * B
      rw [hsub, pow_succ']
      push_cast at hprev ⊢
      linarith
    have hexp_km1 : Real.exp (((K - 1 : ℕ) : ℝ) / 2) ≤ B := by
      calc Real.exp (((K - 1 : ℕ) : ℝ) / 2)
          = Real.exp ((K - 1 : ℕ) * (1 / 2 : ℝ)) := by ring_nf
        _ = (Real.exp (1 / 2 : ℝ)) ^ (K - 1) := Real.exp_nat_mul _ (K - 1)
        _ ≤ (2 : ℝ) ^ (K - 1) := pow_le_pow_left₀ (Real.exp_pos _).le exp_half_le_two (K - 1)
        _ ≤ B := by push_cast at hprev; exact hprev.le
    have hlog_km1 : ((K - 1 : ℕ) : ℝ) / 2 ≤ Real.log B := by
      rw [← Real.log_exp (((K - 1 : ℕ) : ℝ) / 2)]
      exact Real.log_le_log (Real.exp_pos _) hexp_km1
    have hK_cast : ((K - 1 : ℕ) : ℝ) = (K : ℝ) - 1 := by
      rw [Nat.cast_sub hK1]; simp
    rw [hK_cast] at hlog_km1
    exact ⟨hpos, hspec, hdu_ub, by change (K : ℝ) ≤ _; linarith, hmin⟩

/-- `doubleUntilStmt wTbl wIdx rTbl targetIdx`: sets `w[wTbl, wIdx] := doubleUntil (r[rTbl, targetIdx])`. -/
def doubleUntilStmt (wTbl : ℕ) (wIdx : ℤ) (rTbl : ℕ) (targetIdx : ℤ) : ArithRAMStmt :=
  let wE := IntExpr.readHeap wTbl (.lit wIdx)
  let tR := RealExpr.readRealHeap rTbl (.lit targetIdx)
  .seq
    (.writeWordHeap wTbl (.lit wIdx) (.lit 1))
    (.whileLoop (.realLt (.ofInt wE) tR)
      (.writeWordHeap wTbl (.lit wIdx) (.mul (.lit 2) wE)))

theorem exec_doubleUntilStmt {d : ℕ} (inp : ArithRAMInput d)
    (wTbl : ℕ) (wIdx : ℤ) (rTbl : ℕ) (targetIdx : ℤ)
    (mem₀ : ArithRAMMemory) (hc₀ : CleanMem mem₀)
    {target : ℝ} (htarget : rRead mem₀ rTbl targetIdx = target) :
    let K := doubleSteps target
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp (doubleUntilStmt wTbl wIdx rTbl targetIdx) mem₀ mem₁ (15 + K * 20) ∧
      wRead mem₁ wTbl wIdx = (doubleUntil target : ℤ) ∧
      (∀ t i, (t ≠ wTbl ∨ i ≠ wIdx) → wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ t i, rRead mem₁ t i = rRead mem₀ t i) ∧
      mem₁.words.live ⊆ insert (.heap wTbl wIdx) mem₀.words.live ∧
      mem₁.reals.live ⊆ mem₀.reals.live := by
  dsimp only
  let K := doubleSteps target
  have hspec : target ≤ ((2 ^ K : ℕ) : ℝ) := Nat.find_spec (exists_pow2_ge target)
  have hmin : ∀ j < K, ((2 ^ j : ℕ) : ℝ) < target :=
    fun j hj => not_le.mp (Nat.find_min (exists_pow2_ge target) hj)
  let m0 := wWrite mem₀ wTbl wIdx 1
  have s0 : ExecStmt inp (.writeWordHeap wTbl (.lit wIdx) (.lit 1)) mem₀ m0 5 :=
    exec_wSet_lit inp hc₀ wTbl wIdx (.lit 1) 5 (by simp [evalIntExpr])
  let wE := IntExpr.readHeap wTbl (.lit wIdx)
  let tR := RealExpr.readRealHeap rTbl (.lit targetIdx)
  let Inv : ℕ → ArithRAMMemory → Prop := fun j m =>
    wRead m wTbl wIdx = ((2 ^ j : ℕ) : ℤ) ∧
    (∀ t i, (t ≠ wTbl ∨ i ≠ wIdx) → wRead m t i = wRead mem₀ t i) ∧
    (∀ t i, rRead m t i = rRead mem₀ t i) ∧
    m.words.live ⊆ insert (.heap wTbl wIdx) mem₀.words.live ∧
    m.reals.live ⊆ mem₀.reals.live
  have hInv0 : Inv 0 m0 := ⟨by simp [m0],
    fun t i hne => wRead_wWrite_of_ne mem₀ 1 hne,
    fun _ _ => rfl,
    wWrite_words_live (Finset.subset_insert _ _) 1 (Finset.mem_insert_self _ _),
    Finset.Subset.refl _⟩
  rcases ExecStmt.whileLoop_nat (cond := .realLt (.ofInt wE) tR) K 10 10 Inv s0.2.1 hInv0
    (fun j hj m hcm ⟨hw, hpres_w, hpres_r, hlive_w, hlive_r⟩ => by
      have hlt : (2 : ℝ) ^ j < target := by simpa using hmin j hj
      have hw' : m.words.read (.heap wTbl wIdx) = ((2 ^ j : ℕ) : ℤ) := hw
      have hr' : m.reals.read (.heap rTbl targetIdx) = target :=
        (hpres_r rTbl targetIdx).trans htarget
      refine ⟨evalCond_true inp m (.realLt (.ofInt wE) tR) 10
        (by simp [evalArithCond, evalRealExpr, evalIntExpr, wE, tR, hw', hr', hlt])
        (by simp only [evalArithCond, evalRealExpr, evalIntExpr, wE, tR]; omega), ?_⟩
      let m' := wWrite m wTbl wIdx ((2 ^ (j + 1) : ℕ) : ℤ)
      have sb : ExecStmt inp (.writeWordHeap wTbl (.lit wIdx) (.mul (.lit 2) wE)) m m' 10 := by
        have hs := exec_wSet_lit inp hcm wTbl wIdx (.mul (.lit 2) wE) 10 (by simp [evalIntExpr, wE])
        have hv : (evalIntExpr inp.toWordView 0 m.words (.mul (.lit 2) wE)).1 =
            ((2 ^ (j + 1) : ℕ) : ℤ) := by
          simp [evalIntExpr, wE, hw', pow_succ']; try ring
        simpa [m', hv] using hs
      exact ⟨m', sb, wRead_wWrite_self _ _ _ _,
        fun t i hne => (wRead_wWrite_of_ne m _ hne).trans (hpres_w t i hne),
        fun t i => hpres_r t i,
        wWrite_words_live hlive_w _ (Finset.mem_insert_self _ _),
        hlive_r⟩)
    (fun m _ ⟨hw, _, hpres_r, _, _⟩ => by
      have hw' : m.words.read (.heap wTbl wIdx) = ((2 ^ K : ℕ) : ℤ) := hw
      have hr' : m.reals.read (.heap rTbl targetIdx) = target :=
        (hpres_r rTbl targetIdx).trans htarget
      exact evalCond_false inp m (.realLt (.ofInt wE) tR) 10
        (by simp [evalArithCond, evalRealExpr, evalIntExpr, wE, tR, hw', hr']; push_cast at hspec; linarith)
        (by simp only [evalArithCond, evalRealExpr, evalIntExpr, wE, tR]; omega))
    with ⟨mem₁, ⟨hw1, hpw1, hpr1, hlw1, hlr1⟩, sLoop⟩
  exact ⟨mem₁, (ExecStmt.seq s0 sLoop).mono_cost (by omega), hw1, hpw1, hpr1, hlw1, hlr1⟩

/-- `powPolyStmt wTbl nIdx rTbl zIdx outIdx`: sets `r[rTbl, outIdx] := polyExp N (r[rTbl, zIdx])`
where `N = w[wTbl, nIdx]`. -/
def powPolyStmt (wTbl : ℕ) (nIdx : ℤ) (rTbl : ℕ) (zIdx outIdx : ℤ) : ArithRAMStmt :=
  let nE := IntExpr.readHeap wTbl (.lit nIdx)
  let zR := RealExpr.readRealHeap rTbl (.lit zIdx)
  let accR := RealExpr.readRealHeap rTbl (.lit outIdx)
  .seq
    (.writeRealHeap rTbl (.lit outIdx) (.ofInt (.lit 1)))
    (.repeatN nE
      (.writeRealHeap rTbl (.lit outIdx)
        (.mul accR (.add (.ofInt (.lit 1)) (.div zR (.ofInt nE))))))

theorem exec_powPolyStmt {d : ℕ} (inp : ArithRAMInput d)
    (wTbl : ℕ) (nIdx : ℤ) (rTbl : ℕ) (zIdx outIdx : ℤ) (hne_idx : zIdx ≠ outIdx)
    (mem₀ : ArithRAMMemory) (hc₀ : CleanMem mem₀)
    {N : ℕ} (hN : wRead mem₀ wTbl nIdx = (N : ℤ))
    {z : ℝ} (hz : rRead mem₀ rTbl zIdx = z) :
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp (powPolyStmt wTbl nIdx rTbl zIdx outIdx) mem₀ mem₁ (10 + N * 20) ∧
      rRead mem₁ rTbl outIdx = polyExp N z ∧
      (∀ t i, wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ t i, (t ≠ rTbl ∨ i ≠ outIdx) → rRead mem₁ t i = rRead mem₀ t i) ∧
      mem₁.words.live ⊆ mem₀.words.live ∧
      mem₁.reals.live ⊆ insert (.heap rTbl outIdx) mem₀.reals.live := by
  let m0 := rWrite mem₀ rTbl outIdx 1
  have s0 : ExecStmt inp (.writeRealHeap rTbl (.lit outIdx) (.ofInt (.lit 1))) mem₀ m0 5 := by
    simpa [m0, evalRealExpr, evalIntExpr] using
      exec_rSet_lit inp hc₀ rTbl outIdx (.ofInt (.lit 1)) 5 (by simp [evalRealExpr, evalIntExpr])
  let nE := IntExpr.readHeap wTbl (.lit nIdx)
  let zR := RealExpr.readRealHeap rTbl (.lit zIdx)
  let accR := RealExpr.readRealHeap rTbl (.lit outIdx)
  let Inv : ℕ → ArithRAMMemory → Prop := fun j m =>
    rRead m rTbl outIdx = (1 + z / (N : ℝ)) ^ j ∧
    (∀ t i, wRead m t i = wRead mem₀ t i) ∧
    (∀ t i, (t ≠ rTbl ∨ i ≠ outIdx) → rRead m t i = rRead mem₀ t i) ∧
    m.words.live ⊆ mem₀.words.live ∧
    m.reals.live ⊆ insert (.heap rTbl outIdx) mem₀.reals.live
  have hInv0 : Inv 0 m0 := ⟨by simp [m0],
    fun _ _ => rfl,
    fun t i hne => rRead_rWrite_of_ne mem₀ 1 hne,
    Finset.Subset.refl _,
    rWrite_reals_live (Finset.subset_insert _ _) 1 (Finset.mem_insert_self _ _)⟩
  have hcnt : evalIntExpr inp.toWordView 0 m0.words nE =
      ((N : ℤ), 2, (evalIntExpr inp.toWordView 0 m0.words nE).2.2) := by
    have hn0 : m0.words.read (.heap wTbl nIdx) = (N : ℤ) := hN
    simp [evalIntExpr, nE, hn0]
  rcases ExecStmt.repeatN_nat N 5 20 Inv s0.2.1 hInv0 hcnt (by omega)
    (fun j _ m hcm ⟨hacc, hpw, hpr, hlw, hlr⟩ => by
      have hn' : m.words.read (.heap wTbl nIdx) = (N : ℤ) := (hpw wTbl nIdx).trans hN
      have hz' : m.reals.read (.heap rTbl zIdx) = z :=
        (hpr rTbl zIdx (Or.inr hne_idx)).trans hz
      have hacc' : m.reals.read (.heap rTbl outIdx) = (1 + z / (N : ℝ)) ^ j := hacc
      let stepE : RealExpr := .mul accR (.add (.ofInt (.lit 1)) (.div zR (.ofInt nE)))
      have hs := exec_rSet_lit inp hcm rTbl outIdx stepE 20
        (by simp [stepE, accR, zR, nE, evalRealExpr, evalIntExpr])
      let m' := rWrite m rTbl outIdx ((1 + z / (N : ℝ)) ^ (j + 1))
      have hm' : rWrite m rTbl outIdx (evalRealExpr inp 0 m stepE).1 = m' := by
        congr 1
        simp only [stepE, accR, zR, nE, evalRealExpr, evalIntExpr, hacc', hz', hn']
        push_cast
        rw [pow_succ]
      rw [hm'] at hs
      exact ⟨m', hs, rRead_rWrite_self _ _ _ _,
        fun t i => hpw t i,
        fun t i hne => (rRead_rWrite_of_ne m _ hne).trans (hpr t i hne),
        hlw,
        rWrite_reals_live hlr _ (Finset.mem_insert_self _ _)⟩)
    with ⟨mem₁, ⟨hout, hpw1, hpr1, hlw1, hlr1⟩, sLoop⟩
  exact ⟨mem₁, (ExecStmt.seq s0 sLoop).mono_cost (by omega), hout, hpw1, hpr1, hlw1, hlr1⟩

/-! ### 4. Full parameter definitions `M0Param`, `capUParam`, `capQParam`, `RParam` and exponent bounds -/

noncomputable def M0Param (c_h : ℝ) (ℓ m : ℕ) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (h x : ℝ) : ℕ :=
  Nat.ceil ((Real.log (100 * (ℓ : ℝ)) / c_h) * (tParam ℓ m hℓ hm) ^ 2 *
    Real.exp (I_h h x * (tParam ℓ m hℓ hm) ^ 2 / 2)) + 1

noncomputable def targetUVal (c_h : ℝ) (ℓ m : ℕ) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (h x : ℝ) : ℝ :=
  let M₀ := M0Param c_h ℓ m hℓ hm h x
  let t := tParam ℓ m hℓ hm
  let z_u := (ℓ : ℝ) * t ^ 2 / 2
  100 * (((M₀ ^ ℓ : ℕ) : ℝ) / polyExp (N_pow ℓ m) z_u + 1)

noncomputable def targetQ1Val (c_h : ℝ) (ℓ m : ℕ) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (h x : ℝ) : ℝ :=
  let M₀ := M0Param c_h ℓ m hℓ hm h x
  let t := tParam ℓ m hℓ hm
  let z_q := (ℓ : ℝ) * x ^ 2 * t ^ 2 / 2
  100 * (((M₀ ^ ℓ : ℕ) : ℝ) / polyExp (N_pow ℓ m) z_q + 1)

noncomputable def targetQ2Val (c_h : ℝ) (ℓ m : ℕ) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (h x : ℝ) : ℝ :=
  let M₀ := M0Param c_h ℓ m hℓ hm h x
  let t := tParam ℓ m hℓ hm
  let z_bad := (ℓ : ℝ) * (1 + x ^ 2) * t ^ 2 / 2
  100 * ((m : ℝ) * ((M₀ ^ ℓ : ℕ) : ℝ) / polyExp (N_pow ℓ m) z_bad + 1)

noncomputable def capUParam (c_h : ℝ) (ℓ m : ℕ) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (h x : ℝ) : ℕ :=
  doubleUntil (targetUVal c_h ℓ m hℓ hm h x)

noncomputable def capQParam (c_h : ℝ) (ℓ m : ℕ) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (h x : ℝ) : ℕ :=
  doubleUntil (max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x))

noncomputable def RParam (d m : ℕ) (η : ℚ) (ε₀ : ℝ) : ℕ :=
  Nat.ceil (Real.log ((m : ℝ) / ε₀) + 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) + 1

/-- Constant factor depending only on `(c_h, ℓ)` bounding `M0Param`, `capUParam`, and `capQParam`. -/
noncomputable def cParamConst (c_h : ℝ) (ℓ : ℕ) : ℝ :=
  let c0 : ℝ := Real.log (100 * (ℓ : ℝ)) / c_h + 2
  let cE : ℝ := max 1 (cExpBound ℓ)
  800 * (c0 * 64) ^ ℓ * cE ^ 2 + 800

theorem cParam_tail_bounds {ℓ : ℕ} (hℓ : 1 ≤ ℓ)
    {c0 cE Llog m_r I_div u_exp q_exp : ℝ}
    (hc0 : 2 ≤ c0) (hcE : 1 ≤ cE) (hL_half : 1 / 2 ≤ Llog)
    (hm1 : 1 ≤ m_r) (hu1 : u_exp ≤ 1) (hq2 : q_exp ≤ 2)
    (hI0 : 0 ≤ m_r ^ I_div) (hu0 : 0 ≤ m_r ^ u_exp) (hq0 : 0 ≤ m_r ^ q_exp)
    {M0_r CapU_r CapQ_r StepsU_r StepsQ_r : ℝ}
    (hM0_ub : M0_r ≤ (c0 * 64 * cE ^ 2) * Llog ^ 2 * m_r ^ I_div)
    (hCapU_ub : CapU_r ≤ 2 * ((200 * (c0 * 64) ^ ℓ * cE ^ 2 + 100 * (c0 * 64) ^ ℓ * cE ^ 2) *
      Llog ^ (2 * ℓ) * m_r ^ u_exp))
    (hCapQ_ub : CapQ_r ≤ 2 * ((300 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog ^ (2 * ℓ) * m_r ^ q_exp))
    (hBu1 : 1 ≤ (200 * (c0 * 64) ^ ℓ * cE ^ 2 + 100 * (c0 * 64) ^ ℓ * cE ^ 2) *
      Llog ^ (2 * ℓ) * m_r ^ u_exp)
    (hBq1 : 1 ≤ (300 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog ^ (2 * ℓ) * m_r ^ q_exp)
    (hStepsU_ub : StepsU_r ≤ 2 * Real.log
      ((200 * (c0 * 64) ^ ℓ * cE ^ 2 + 100 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog ^ (2 * ℓ) * m_r ^ u_exp) + 2)
    (hStepsQ_ub : StepsQ_r ≤ 2 * Real.log
      ((300 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog ^ (2 * ℓ) * m_r ^ q_exp) + 2)
    (hL_eq : Llog = Real.log (2 * m_r)) :
    let C := 800 * (c0 * 64) ^ ℓ * cE ^ 2 + 800
    M0_r ≤ C * Llog ^ 2 * m_r ^ I_div ∧
    CapU_r ≤ C * Llog ^ (2 * ℓ) * m_r ^ u_exp ∧
    CapQ_r ≤ C * Llog ^ (2 * ℓ) * m_r ^ q_exp ∧
    StepsU_r ≤ C * (Llog + 1) ∧
    StepsQ_r ≤ C * (Llog + 1) := by
  intro C
  have hC_ge : 800 * (c0 * 64) ^ ℓ * cE ^ 2 + 800 ≤ C := le_rfl
  have hc0_pos : 0 < c0 := by linarith
  have hcE_pos : 0 < cE := by linarith
  have hcE2_ge1 : 1 ≤ cE ^ 2 := one_le_pow₀ hcE
  have hpow_pos : 0 < (c0 * 64) ^ ℓ * cE ^ 2 := by positivity
  have hlog_sub_self : ∀ y : ℝ, 0 < y → Real.log y ≤ y := fun y hy => by
    linarith [Real.log_le_sub_one_of_pos hy]
  have hL_le_2m : Llog ≤ 2 * m_r := by rw [hL_eq]; exact hlog_sub_self (2 * m_r) (by linarith)
  have hL_nn : 0 ≤ Llog := by linarith
  have h2m_nn : 0 ≤ 2 * m_r := by linarith

  have hStepsU_bound : StepsU_r ≤ C * (Llog + 1) := by
    set Bu := (200 * (c0 * 64) ^ ℓ * cE ^ 2 + 100 * (c0 * 64) ^ ℓ * cE ^ 2) *
      Llog ^ (2 * ℓ) * m_r ^ u_exp
    have hBu_pos : 0 < Bu := by linarith [hBu1]
    have hmu_le_2m : m_r ^ u_exp ≤ 2 * m_r := by
      calc m_r ^ u_exp ≤ m_r ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le hm1 hu1
        _ = m_r := Real.rpow_one _
        _ ≤ 2 * m_r := by linarith
    have hBu_coarse : Bu ≤ (300 * (c0 * 64) ^ ℓ * cE ^ 2) * (2 * m_r) ^ (2 * ℓ + 1) := by
      have h1 : Llog ^ (2 * ℓ) ≤ (2 * m_r) ^ (2 * ℓ) := pow_le_pow_left₀ hL_nn hL_le_2m (2 * ℓ)
      calc Bu = (300 * (c0 * 64) ^ ℓ * cE ^ 2) * (Llog ^ (2 * ℓ) * m_r ^ u_exp) := by dsimp [Bu]; ring
        _ ≤ (300 * (c0 * 64) ^ ℓ * cE ^ 2) * ((2 * m_r) ^ (2 * ℓ) * (2 * m_r)) :=
            mul_le_mul_of_nonneg_left (mul_le_mul h1 hmu_le_2m hu0 (by positivity)) (by positivity)
        _ = (300 * (c0 * 64) ^ ℓ * cE ^ 2) * (2 * m_r) ^ (2 * ℓ + 1) := by rw [pow_succ]; ring
    have hlogBu : Real.log Bu ≤ (300 * (c0 * 64) ^ ℓ * cE ^ 2) + ((2 * ℓ + 1 : ℕ) : ℝ) * Llog := by
      calc Real.log Bu
          ≤ Real.log ((300 * (c0 * 64) ^ ℓ * cE ^ 2) * (2 * m_r) ^ (2 * ℓ + 1)) :=
            Real.log_le_log hBu_pos hBu_coarse
        _ = Real.log (300 * (c0 * 64) ^ ℓ * cE ^ 2) + Real.log ((2 * m_r) ^ (2 * ℓ + 1)) :=
            Real.log_mul (by positivity) (pow_ne_zero _ (by linarith))
        _ ≤ (300 * (c0 * 64) ^ ℓ * cE ^ 2) + ((2 * ℓ + 1 : ℕ) : ℝ) * Llog := by
            rw [Real.log_pow, ← hL_eq]
            linarith [hlog_sub_self (300 * (c0 * 64) ^ ℓ * cE ^ 2) (by positivity)]
    have h2l1_le : ((2 * ℓ + 1 : ℕ) : ℝ) ≤ 4 * (c0 * 64) ^ ℓ * cE ^ 2 := by
      have h_ind : ((2 * ℓ + 1 : ℕ) : ℝ) ≤ 4 * (2 : ℝ) ^ ℓ := by
        have : 2 * ℓ + 1 ≤ 4 * 2 ^ ℓ := by have := Nat.lt_two_pow_self (n := ℓ); omega
        exact_mod_cast this
      have h2_c0 : (2 : ℝ) ^ ℓ ≤ (c0 * 64) ^ ℓ := pow_le_pow_left₀ (by norm_num) (by linarith) ℓ
      have h3 : (c0 * 64) ^ ℓ ≤ (c0 * 64) ^ ℓ * cE ^ 2 :=
        le_mul_of_one_le_right (by positivity) hcE2_ge1
      linarith
    have hmul_le : ((2 * ℓ + 1 : ℕ) : ℝ) * Llog ≤ (4 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog :=
      mul_le_mul_of_nonneg_right h2l1_le hL_nn
    have h2 : 8 * (c0 * 64) ^ ℓ * cE ^ 2 ≤ C := by linarith [hC_ge, hpow_pos]
    have h3 : (8 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog ≤ C * Llog :=
      mul_le_mul_of_nonneg_right h2 hL_nn
    have hCL : C * (Llog + 1) = C * Llog + C := by ring
    linarith [hStepsU_ub, hlogBu, hmul_le, h3, hC_ge, hpow_pos, hCL]

  have hStepsQ_bound : StepsQ_r ≤ C * (Llog + 1) := by
    set Bq := (300 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog ^ (2 * ℓ) * m_r ^ q_exp
    have hBq_pos : 0 < Bq := by linarith [hBq1]
    have hmq_le_2m2 : m_r ^ q_exp ≤ (2 * m_r) ^ 2 := by
      calc m_r ^ q_exp ≤ m_r ^ (2 : ℝ) := Real.rpow_le_rpow_of_exponent_le hm1 hq2
        _ = m_r ^ 2 := Real.rpow_natCast m_r 2
        _ ≤ (2 * m_r) ^ 2 := pow_le_pow_left₀ (by linarith) (by linarith) 2
    have hBq_coarse : Bq ≤ (300 * (c0 * 64) ^ ℓ * cE ^ 2) * (2 * m_r) ^ (2 * ℓ + 2) := by
      have h1 : Llog ^ (2 * ℓ) ≤ (2 * m_r) ^ (2 * ℓ) := pow_le_pow_left₀ hL_nn hL_le_2m (2 * ℓ)
      calc Bq = (300 * (c0 * 64) ^ ℓ * cE ^ 2) * (Llog ^ (2 * ℓ) * m_r ^ q_exp) := by dsimp [Bq]; ring
        _ ≤ (300 * (c0 * 64) ^ ℓ * cE ^ 2) * ((2 * m_r) ^ (2 * ℓ) * (2 * m_r) ^ 2) :=
            mul_le_mul_of_nonneg_left (mul_le_mul h1 hmq_le_2m2 hq0 (by positivity)) (by positivity)
        _ = (300 * (c0 * 64) ^ ℓ * cE ^ 2) * (2 * m_r) ^ (2 * ℓ + 2) := by rw [pow_add]
    have hlogBq : Real.log Bq ≤ (300 * (c0 * 64) ^ ℓ * cE ^ 2) + ((2 * ℓ + 2 : ℕ) : ℝ) * Llog := by
      calc Real.log Bq
          ≤ Real.log ((300 * (c0 * 64) ^ ℓ * cE ^ 2) * (2 * m_r) ^ (2 * ℓ + 2)) :=
            Real.log_le_log hBq_pos hBq_coarse
        _ = Real.log (300 * (c0 * 64) ^ ℓ * cE ^ 2) + Real.log ((2 * m_r) ^ (2 * ℓ + 2)) :=
            Real.log_mul (by positivity) (pow_ne_zero _ (by linarith))
        _ ≤ (300 * (c0 * 64) ^ ℓ * cE ^ 2) + ((2 * ℓ + 2 : ℕ) : ℝ) * Llog := by
            rw [Real.log_pow, ← hL_eq]
            linarith [hlog_sub_self (300 * (c0 * 64) ^ ℓ * cE ^ 2) (by positivity)]
    have h2l2_le : ((2 * ℓ + 2 : ℕ) : ℝ) ≤ 4 * (c0 * 64) ^ ℓ * cE ^ 2 := by
      have h_ind : ((2 * ℓ + 2 : ℕ) : ℝ) ≤ 4 * (2 : ℝ) ^ ℓ := by
        have : 2 * ℓ + 2 ≤ 4 * 2 ^ ℓ := by have := Nat.lt_two_pow_self (n := ℓ); omega
        exact_mod_cast this
      have h2_c0 : (2 : ℝ) ^ ℓ ≤ (c0 * 64) ^ ℓ := pow_le_pow_left₀ (by norm_num) (by linarith) ℓ
      have h3 : (c0 * 64) ^ ℓ ≤ (c0 * 64) ^ ℓ * cE ^ 2 :=
        le_mul_of_one_le_right (by positivity) hcE2_ge1
      linarith
    have hmul_le : ((2 * ℓ + 2 : ℕ) : ℝ) * Llog ≤ (4 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog :=
      mul_le_mul_of_nonneg_right h2l2_le hL_nn
    have h2 : 8 * (c0 * 64) ^ ℓ * cE ^ 2 ≤ C := by linarith [hC_ge, hpow_pos]
    have h3 : (8 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog ≤ C * Llog :=
      mul_le_mul_of_nonneg_right h2 hL_nn
    have hCL : C * (Llog + 1) = C * Llog + C := by ring
    linarith [hStepsQ_ub, hlogBq, hmul_le, h3, hC_ge, hpow_pos, hCL]

  have hc0_le_pow : c0 * 64 ≤ (c0 * 64) ^ ℓ := by
    simpa using pow_le_pow_right₀ (by linarith : 1 ≤ c0 * 64) hℓ
  have hM0_C : M0_r ≤ C * Llog ^ 2 * m_r ^ I_div := by
    refine hM0_ub.trans ?_
    refine mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right ?_ (sq_nonneg _)) hI0
    have h1 : c0 * 64 * cE ^ 2 ≤ (c0 * 64) ^ ℓ * cE ^ 2 :=
      mul_le_mul_of_nonneg_right hc0_le_pow (sq_nonneg _)
    linarith [hC_ge, hpow_pos]
  have hCapU_C : CapU_r ≤ C * Llog ^ (2 * ℓ) * m_r ^ u_exp := by
    refine hCapU_ub.trans ?_
    have h1 : 2 * (200 * (c0 * 64) ^ ℓ * cE ^ 2 + 100 * (c0 * 64) ^ ℓ * cE ^ 2) ≤ C := by
      linarith [hC_ge, hpow_pos]
    calc 2 * ((200 * (c0 * 64) ^ ℓ * cE ^ 2 + 100 * (c0 * 64) ^ ℓ * cE ^ 2) *
            Llog ^ (2 * ℓ) * m_r ^ u_exp)
        = (2 * (200 * (c0 * 64) ^ ℓ * cE ^ 2 + 100 * (c0 * 64) ^ ℓ * cE ^ 2)) *
            (Llog ^ (2 * ℓ) * m_r ^ u_exp) := by ring
      _ ≤ C * (Llog ^ (2 * ℓ) * m_r ^ u_exp) :=
          mul_le_mul_of_nonneg_right h1 (mul_nonneg (pow_nonneg hL_nn _) hu0)
      _ = C * Llog ^ (2 * ℓ) * m_r ^ u_exp := by ring
  have hCapQ_C : CapQ_r ≤ C * Llog ^ (2 * ℓ) * m_r ^ q_exp := by
    refine hCapQ_ub.trans ?_
    have h1 : 2 * (300 * (c0 * 64) ^ ℓ * cE ^ 2) ≤ C := by linarith [hC_ge, hpow_pos]
    calc 2 * (300 * (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) * m_r ^ q_exp)
        = (2 * (300 * (c0 * 64) ^ ℓ * cE ^ 2)) * (Llog ^ (2 * ℓ) * m_r ^ q_exp) := by ring
      _ ≤ C * (Llog ^ (2 * ℓ) * m_r ^ q_exp) :=
          mul_le_mul_of_nonneg_right h1 (mul_nonneg (pow_nonneg hL_nn _) hq0)
      _ = C * Llog ^ (2 * ℓ) * m_r ^ q_exp := by ring
  exact ⟨hM0_C, hCapU_C, hCapQ_C, hStepsU_bound, hStepsQ_bound⟩

set_option maxHeartbeats 2500000 in
theorem param_all_bounds {c_h : ℝ} (hc_h : 0 < c_h)
    {ℓ m : ℕ} (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m)
    {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1) :
    let M₀ := M0Param c_h ℓ m hℓ hm h x
    let Cap_u := capUParam c_h ℓ m hℓ hm h x
    let Cap_q := capQParam c_h ℓ m hℓ hm h x
    let t := tParam ℓ m hℓ hm
    let Llog := Real.log (2 * (m : ℝ))
    let C := cParamConst c_h ℓ
    1 ≤ M₀ ∧
    1 ≤ Cap_u ∧
    1 ≤ Cap_q ∧
    Real.log (100 * (ℓ : ℝ)) ≤
      (c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2))) * (M₀ : ℝ) ∧
    100 * ((M₀ : ℝ) ^ ℓ * (Real.exp (-(t ^ 2 / 2))) ^ ℓ + 1) ≤ (Cap_u : ℝ) ∧
    100 * ((M₀ : ℝ) ^ ℓ * (Real.exp (-(x ^ 2 * t ^ 2 / 2))) ^ ℓ + 1) ≤ (Cap_q : ℝ) ∧
    100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * (Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))) ^ ℓ + 1) ≤ (Cap_q : ℝ) ∧
    (M₀ : ℝ) ≤ C * Llog ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) ∧
    (Cap_u : ℝ) ≤ C * Llog ^ (2 * ℓ) * (m : ℝ) ^ (u_search h x) ∧
    (Cap_q : ℝ) ≤ C * Llog ^ (2 * ℓ) * (m : ℝ) ^ (q_search h x) ∧
    (doubleSteps (targetUVal c_h ℓ m hℓ hm h x) : ℝ) ≤ C * (Llog + 1) ∧
    (doubleSteps (max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x)) : ℝ) ≤
      C * (Llog + 1) := by
  dsimp only
  rcases L_m_bounds hm with ⟨hL1, _, _, _, hLlog_half, hL_ub⟩
  rcases tParam_bounds hℓ hm with ⟨_, _, _, ht_ge1, ht_le4L, hN_2zu, hm_le_exp, hexp_ub⟩
  rcases I_h_bounds hh0 hh1 hx0 hx1 with ⟨hI1, hI2, hu0, hu1, hq0, hq2, _⟩
  set M₀ := M0Param c_h ℓ m hℓ hm h x
  set Cap_u := capUParam c_h ℓ m hℓ hm h x
  set Cap_q := capQParam c_h ℓ m hℓ hm h x
  set t := tParam ℓ m hℓ hm
  set Llog := Real.log (2 * (m : ℝ))
  set z_u := (ℓ : ℝ) * t ^ 2 / 2
  have hm_r1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
  have hℓ_r1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
  have hN1 : 1 ≤ N_pow ℓ m := by unfold N_pow; omega
  have hx_nn : 0 ≤ x := hh0.le.trans hx0
  have ht_pos : 0 < t := by linarith
  have ht_ub : t ≤ 8 * Llog := by linarith

  -- 1. `M₀` lower bound for `p₁`
  have hM0_pos : 1 ≤ M₀ := by dsimp [M₀, M0Param]; omega
  have hlog100_pos : 0 < Real.log (100 * (ℓ : ℝ)) := by
    refine Real.log_pos ?_; linarith
  have hM0_ge : (Real.log (100 * (ℓ : ℝ)) / c_h) * t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) ≤ (M₀ : ℝ) := by
    dsimp [M₀, M0Param]
    push_cast
    linarith [Nat.le_ceil ((Real.log (100 * (ℓ : ℝ)) / c_h) * t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2))]
  have hp1_M0 : Real.log (100 * (ℓ : ℝ)) ≤
      (c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2))) * (M₀ : ℝ) := by
    have ht2_pos : 0 < t ^ 2 := by positivity
    have hexp_pos : 0 < Real.exp (I_h h x * t ^ 2 / 2) := Real.exp_pos _
    have hrew : (c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2))) *
        ((Real.log (100 * (ℓ : ℝ)) / c_h) * t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2)) =
        Real.log (100 * (ℓ : ℝ)) := by
      rw [zpow_neg, zpow_two, Real.exp_neg]
      field_simp [hc_h.ne', ht_pos.ne', hexp_pos.ne']
    rw [← hrew]
    exact mul_le_mul_of_nonneg_left hM0_ge (by positivity)

  -- 2. Upper bound on `M₀` and `M₀ ^ ℓ`
  let c0 : ℝ := Real.log (100 * (ℓ : ℝ)) / c_h + 2
  have hc0_div_nn : 0 ≤ Real.log (100 * (ℓ : ℝ)) / c_h := div_nonneg hlog100_pos.le hc_h.le
  have hc0_pos : 2 ≤ c0 := by dsimp [c0]; linarith
  have hM0_raw : (M₀ : ℝ) ≤ c0 * t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) := by
    have hceil : (Nat.ceil ((Real.log (100 * (ℓ : ℝ)) / c_h) * t ^ 2 *
        Real.exp (I_h h x * t ^ 2 / 2)) : ℝ) <
        (Real.log (100 * (ℓ : ℝ)) / c_h) * t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) + 1 :=
      Nat.ceil_lt_add_one (by positivity)
    have h1_le : 1 ≤ t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) := by
      have h1 : 1 ≤ t ^ 2 := by nlinarith
      have h2 : 1 ≤ Real.exp (I_h h x * t ^ 2 / 2) := Real.one_le_exp (by positivity)
      exact one_le_mul_of_one_le_of_one_le h1 h2
    have hM0_eq : (M₀ : ℝ) = (Nat.ceil ((Real.log (100 * (ℓ : ℝ)) / c_h) * t ^ 2 *
        Real.exp (I_h h x * t ^ 2 / 2)) : ℝ) + 1 := by dsimp [M₀, M0Param]; push_cast; ring
    have hc0_mul : c0 * t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) =
        (Real.log (100 * (ℓ : ℝ)) / c_h) * t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) +
        2 * (t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2)) := by dsimp [c0]; ring
    linarith

  let cE : ℝ := max 1 (cExpBound ℓ)
  have hcE1 : 1 ≤ cE := le_max_left _ _
  have hexp_cE : Real.exp z_u ≤ cE * (m : ℝ) :=
    hexp_ub.trans (mul_le_mul_of_nonneg_right (le_max_right _ _) (by positivity))
  have hexp_rpow : ∀ α : ℝ, 0 ≤ α → α ≤ 2 →
      Real.exp (α * z_u) ≤ cE ^ 2 * (m : ℝ) ^ α := by
    intro α hα0 hα2
    have h1 : Real.exp (α * z_u) = (Real.exp z_u) ^ α := by
      rw [mul_comm, Real.exp_mul]
    rw [h1]
    calc (Real.exp z_u) ^ α
        ≤ (cE * (m : ℝ)) ^ α := Real.rpow_le_rpow (Real.exp_pos _).le hexp_cE hα0
      _ = cE ^ α * (m : ℝ) ^ α := Real.mul_rpow (by positivity) (by positivity)
      _ ≤ cE ^ (2 : ℝ) * (m : ℝ) ^ α :=
          mul_le_mul_of_nonneg_right (Real.rpow_le_rpow_of_exponent_le hcE1 hα2) (by positivity)
      _ = cE ^ 2 * (m : ℝ) ^ α := by norm_num

  have hI_div_0 : 0 ≤ I_h h x / (ℓ : ℝ) := by positivity
  have hI_div_2 : I_h h x / (ℓ : ℝ) ≤ 2 := by
    rw [div_le_iff₀ (by positivity)]; nlinarith
  have hexp_I_div : Real.exp (I_h h x * t ^ 2 / 2) ≤ cE ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
    have hrew : I_h h x * t ^ 2 / 2 = (I_h h x / (ℓ : ℝ)) * z_u := by
      dsimp [z_u]; field_simp [show (ℓ : ℝ) ≠ 0 by positivity]
    rw [hrew]
    exact hexp_rpow _ hI_div_0 hI_div_2

  have ht2_ub : t ^ 2 ≤ 64 * Llog ^ 2 := by nlinarith
  have hM0_ub_neat : (M₀ : ℝ) ≤ (c0 * 64 * cE ^ 2) * Llog ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by
    calc (M₀ : ℝ)
        ≤ c0 * t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) := hM0_raw
      _ ≤ c0 * (64 * Llog ^ 2) * (cE ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ))) := by
          refine mul_le_mul (mul_le_mul_of_nonneg_left ht2_ub (by positivity))
            hexp_I_div (by positivity) (by positivity)
      _ = (c0 * 64 * cE ^ 2) * Llog ^ 2 * (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) := by ring

  have hM0_pow : (M₀ : ℝ) ^ ℓ ≤
      (c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * Real.exp (I_h h x * z_u) := by
    have hbase : (M₀ : ℝ) ≤ (c0 * 64) * Llog ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) := by
      calc (M₀ : ℝ) ≤ c0 * t ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) := hM0_raw
        _ ≤ c0 * (64 * Llog ^ 2) * Real.exp (I_h h x * t ^ 2 / 2) :=
            mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left ht2_ub (by positivity)) (by positivity)
        _ = (c0 * 64) * Llog ^ 2 * Real.exp (I_h h x * t ^ 2 / 2) := by ring
    calc (M₀ : ℝ) ^ ℓ
        ≤ ((c0 * 64) * Llog ^ 2 * Real.exp (I_h h x * t ^ 2 / 2)) ^ ℓ :=
          pow_le_pow_left₀ (by positivity) hbase ℓ
      _ = (c0 * 64) ^ ℓ * (Llog ^ 2) ^ ℓ * (Real.exp (I_h h x * t ^ 2 / 2)) ^ ℓ := by
          rw [mul_pow, mul_pow]
      _ = (c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * Real.exp (I_h h x * z_u) := by
          rw [← pow_mul, ← Real.exp_nat_mul]
          congr 1
          dsimp [z_u]; ring

  -- 3. `targetUVal`, `targetQ1Val`, `targetQ2Val` lower and upper bounds
  let z_q := (ℓ : ℝ) * x ^ 2 * t ^ 2 / 2
  let z_bad := (ℓ : ℝ) * (1 + x ^ 2) * t ^ 2 / 2
  have hzq_nn : 0 ≤ z_q := by positivity
  have hzbad_nn : 0 ≤ z_bad := by positivity
  have hx2_le1 : x ^ 2 ≤ 1 := by
    have hx_nn : 0 ≤ x := by linarith
    calc x ^ 2 = x * x := sq x
      _ ≤ 1 * 1 := mul_le_mul hx1 hx1 hx_nn (by norm_num)
      _ = 1 := by norm_num
  have hzq_le : z_q ≤ 2 * z_u := by
    dsimp [z_q, z_u]
    have h1 : (ℓ : ℝ) * x ^ 2 ≤ (ℓ : ℝ) * 2 :=
      mul_le_mul_of_nonneg_left (by linarith) (by positivity)
    have h2 : (ℓ : ℝ) * x ^ 2 * t ^ 2 ≤ ((ℓ : ℝ) * 2) * t ^ 2 :=
      mul_le_mul_of_nonneg_right h1 (by positivity)
    linarith
  have hzbad_le : z_bad ≤ 2 * z_u := by
    dsimp [z_bad, z_u]
    have h1 : (ℓ : ℝ) * (1 + x ^ 2) ≤ (ℓ : ℝ) * 2 :=
      mul_le_mul_of_nonneg_left (by linarith) (by positivity)
    have h2 : (ℓ : ℝ) * (1 + x ^ 2) * t ^ 2 ≤ ((ℓ : ℝ) * 2) * t ^ 2 :=
      mul_le_mul_of_nonneg_right h1 (by positivity)
    linarith

  have hN_zu : 3 * z_u ^ 2 + 1 ≤ (N_pow ℓ m : ℝ) := by
    have hzu_nn : 0 ≤ z_u := by dsimp [z_u]; positivity
    have : z_u ^ 2 ≤ (2 * z_u) ^ 2 := pow_le_pow_left₀ hzu_nn (by linarith) 2
    linarith
  have hN_zq : 3 * z_q ^ 2 + 1 ≤ (N_pow ℓ m : ℝ) := by
    have : z_q ^ 2 ≤ (2 * z_u) ^ 2 := pow_le_pow_left₀ hzq_nn hzq_le 2
    linarith
  have hN_zbad : 3 * z_bad ^ 2 + 1 ≤ (N_pow ℓ m : ℝ) := by
    have : z_bad ^ 2 ≤ (2 * z_u) ^ 2 := pow_le_pow_left₀ hzbad_nn hzbad_le 2
    linarith

  rcases one_plus_div_pow_approx (by positivity) hN_zu with ⟨hp_u1, hp_u2, hp_u3⟩
  rcases one_plus_div_pow_approx hzq_nn hN_zq with ⟨hp_q1, hp_q2, hp_q3⟩
  rcases one_plus_div_pow_approx hzbad_nn hN_zbad with ⟨hp_b1, hp_b2, hp_b3⟩

  -- Lower bounds: `100 * (M₀^ℓ * exp(-...) + 1) ≤ target...`
  have htu_lo : 100 * ((M₀ : ℝ) ^ ℓ * (Real.exp (-(t ^ 2 / 2))) ^ ℓ + 1) ≤
      targetUVal c_h ℓ m hℓ hm h x := by
    unfold targetUVal
    change 100 * ((M₀ : ℝ) ^ ℓ * (Real.exp (-(t ^ 2 / 2))) ^ ℓ + 1) ≤
      100 * (((M₀ ^ ℓ : ℕ) : ℝ) / polyExp (N_pow ℓ m) z_u + 1)
    push_cast
    have h1 : (Real.exp (-(t ^ 2 / 2))) ^ ℓ ≤ 1 / polyExp (N_pow ℓ m) z_u := by
      rw [← Real.exp_nat_mul, show (ℓ : ℝ) * -(t ^ 2 / 2) = -z_u by dsimp [z_u]; ring,
        Real.exp_neg, ← one_div]
      exact one_div_le_one_div_of_le (by linarith) hp_u2
    have h2 := mul_le_mul_of_nonneg_left h1 (by positivity : 0 ≤ (M₀ : ℝ) ^ ℓ)
    rw [mul_one_div] at h2
    linarith

  have htq1_lo : 100 * ((M₀ : ℝ) ^ ℓ * (Real.exp (-(x ^ 2 * t ^ 2 / 2))) ^ ℓ + 1) ≤
      targetQ1Val c_h ℓ m hℓ hm h x := by
    unfold targetQ1Val
    change 100 * ((M₀ : ℝ) ^ ℓ * (Real.exp (-(x ^ 2 * t ^ 2 / 2))) ^ ℓ + 1) ≤
      100 * (((M₀ ^ ℓ : ℕ) : ℝ) / polyExp (N_pow ℓ m) z_q + 1)
    push_cast
    have h1 : (Real.exp (-(x ^ 2 * t ^ 2 / 2))) ^ ℓ ≤ 1 / polyExp (N_pow ℓ m) z_q := by
      rw [← Real.exp_nat_mul, show (ℓ : ℝ) * -(x ^ 2 * t ^ 2 / 2) = -z_q by dsimp [z_q]; ring,
        Real.exp_neg, ← one_div]
      exact one_div_le_one_div_of_le (by linarith) hp_q2
    have h2 := mul_le_mul_of_nonneg_left h1 (by positivity : 0 ≤ (M₀ : ℝ) ^ ℓ)
    rw [mul_one_div] at h2
    linarith

  have htq2_lo : 100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * (Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))) ^ ℓ + 1) ≤
      targetQ2Val c_h ℓ m hℓ hm h x := by
    unfold targetQ2Val
    change 100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * (Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))) ^ ℓ + 1) ≤
      100 * ((m : ℝ) * ((M₀ ^ ℓ : ℕ) : ℝ) / polyExp (N_pow ℓ m) z_bad + 1)
    push_cast
    have h1 : (Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))) ^ ℓ ≤ 1 / polyExp (N_pow ℓ m) z_bad := by
      rw [← Real.exp_nat_mul, show (ℓ : ℝ) * -((1 + x ^ 2) * t ^ 2 / 2) = -z_bad by dsimp [z_bad]; ring,
        Real.exp_neg, ← one_div]
      exact one_div_le_one_div_of_le (by linarith) hp_b2
    have h2 := mul_le_mul_of_nonneg_left h1 (by positivity : 0 ≤ (m : ℝ) * (M₀ : ℝ) ^ ℓ)
    rw [mul_one_div] at h2
    linarith

  -- Upper bounds on `targetUVal` and `max targetQ1Val targetQ2Val`
  have h1_le_2ℓLlog : 1 ≤ (2 ^ (2 * ℓ) : ℝ) * Llog ^ (2 * ℓ) := by
    have h2L : 1 ≤ 2 * Llog := by linarith
    calc (1 : ℝ) ≤ (2 * Llog) ^ (2 * ℓ) := one_le_pow₀ h2L
      _ = (2 ^ (2 * ℓ) : ℝ) * Llog ^ (2 * ℓ) := mul_pow _ _ _
  have h2pow_le_c0 : (2 ^ (2 * ℓ) : ℝ) ≤ (c0 * 64) ^ ℓ := by
    rw [pow_mul]
    exact pow_le_pow_left₀ (by norm_num) (by norm_num; linarith) ℓ
  have h1_le_base : 1 ≤ (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) := by
    have h1 : 1 ≤ (c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) :=
      h1_le_2ℓLlog.trans (mul_le_mul_of_nonneg_right h2pow_le_c0 (by positivity))
    calc (1 : ℝ) ≤ ((c0 * 64) ^ ℓ * Llog ^ (2 * ℓ)) * 1 := by linarith
      _ ≤ ((c0 * 64) ^ ℓ * Llog ^ (2 * ℓ)) * cE ^ 2 :=
          mul_le_mul_of_nonneg_left (by nlinarith) (by positivity)
      _ = (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) := by ring

  let Bu : ℝ := (200 * (c0 * 64) ^ ℓ * cE ^ 2 + 100 * (c0 * 64) ^ ℓ * cE ^ 2) *
    Llog ^ (2 * ℓ) * (m : ℝ) ^ (u_search h x)
  have hBu1 : 1 ≤ Bu := by
    have hmu1 : 1 ≤ (m : ℝ) ^ (u_search h x) := Real.one_le_rpow hm_r1 hu0
    calc (1 : ℝ) ≤ 1 * 1 := by norm_num
      _ ≤ (300 * ((c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ))) * (m : ℝ) ^ (u_search h x) :=
          mul_le_mul (by linarith) hmu1 (by norm_num) (by positivity)
      _ = Bu := by dsimp [Bu]; ring

  have htu_hi : targetUVal c_h ℓ m hℓ hm h x ≤ Bu := by
    unfold targetUVal
    change 100 * (((M₀ ^ ℓ : ℕ) : ℝ) / polyExp (N_pow ℓ m) z_u + 1) ≤ Bu
    push_cast
    have hdiv : (M₀ : ℝ) ^ ℓ / polyExp (N_pow ℓ m) z_u ≤
        2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_u) := by
      rw [div_le_iff₀ (by linarith)]
      have h1 : Real.exp (-z_u) * Real.exp z_u = 1 := by rw [← Real.exp_add]; simp
      calc (M₀ : ℝ) ^ ℓ = (M₀ : ℝ) ^ ℓ * (Real.exp (-z_u) * Real.exp z_u) := by rw [h1, mul_one]
        _ = ((M₀ : ℝ) ^ ℓ * Real.exp (-z_u)) * Real.exp z_u := by ring
        _ ≤ ((M₀ : ℝ) ^ ℓ * Real.exp (-z_u)) * (2 * polyExp (N_pow ℓ m) z_u) :=
            mul_le_mul_of_nonneg_left hp_u3 (by positivity)
        _ = 2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_u) * polyExp (N_pow ℓ m) z_u := by ring
    have hexp_u : Real.exp (I_h h x * z_u) * Real.exp (-z_u) ≤
        cE ^ 2 * (m : ℝ) ^ (u_search h x) := by
      rw [← Real.exp_add, show I_h h x * z_u + -z_u = u_search h x * z_u by unfold u_search; ring]
      exact hexp_rpow _ hu0 (by linarith)
    have hterm : 2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_u) ≤
        2 * (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) * (m : ℝ) ^ (u_search h x) := by
      calc 2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_u)
          ≤ 2 * ((c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * Real.exp (I_h h x * z_u)) * Real.exp (-z_u) := by
            gcongr
        _ = 2 * (c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * (Real.exp (I_h h x * z_u) * Real.exp (-z_u)) := by ring
        _ ≤ 2 * (c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * (cE ^ 2 * (m : ℝ) ^ (u_search h x)) :=
            mul_le_mul_of_nonneg_left hexp_u (by positivity)
        _ = 2 * (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) * (m : ℝ) ^ (u_search h x) := by ring
    have hmu1 : 1 ≤ (m : ℝ) ^ (u_search h x) := Real.one_le_rpow hm_r1 hu0
    have hconst1 : 1 ≤ (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) * (m : ℝ) ^ (u_search h x) :=
      (by norm_num : (1 : ℝ) ≤ 1 * 1).trans (mul_le_mul h1_le_base hmu1 (by norm_num) (by positivity))
    dsimp [Bu]
    linarith

  let Bq : ℝ := (300 * (c0 * 64) ^ ℓ * cE ^ 2) * Llog ^ (2 * ℓ) * (m : ℝ) ^ (q_search h x)
  have hBq1 : 1 ≤ Bq := by
    have hmq1 : 1 ≤ (m : ℝ) ^ (q_search h x) := Real.one_le_rpow hm_r1 hq0
    calc (1 : ℝ) ≤ 1 * 1 := by norm_num
      _ ≤ (300 * ((c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ))) * (m : ℝ) ^ (q_search h x) :=
          mul_le_mul (by linarith) hmq1 (by norm_num) (by positivity)
      _ = Bq := by dsimp [Bq]; ring

  have hexp_q : Real.exp (I_h h x * z_u) * Real.exp (-z_q) ≤
      cE ^ 2 * (m : ℝ) ^ (q_search h x) := by
    rw [← Real.exp_add, show I_h h x * z_u + -z_q = q_search h x * z_u by
      unfold q_search; dsimp [z_u, z_q]; ring]
    exact hexp_rpow _ hq0 hq2

  have hmq1 : 1 ≤ (m : ℝ) ^ (q_search h x) := Real.one_le_rpow hm_r1 hq0
  have hconst_q : 1 ≤ (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) * (m : ℝ) ^ (q_search h x) :=
    (by norm_num : (1 : ℝ) ≤ 1 * 1).trans (mul_le_mul h1_le_base hmq1 (by norm_num) (by positivity))

  have htq1_hi : targetQ1Val c_h ℓ m hℓ hm h x ≤ Bq := by
    unfold targetQ1Val
    change 100 * (((M₀ ^ ℓ : ℕ) : ℝ) / polyExp (N_pow ℓ m) z_q + 1) ≤ Bq
    push_cast
    have hdiv : (M₀ : ℝ) ^ ℓ / polyExp (N_pow ℓ m) z_q ≤
        2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_q) := by
      rw [div_le_iff₀ (by linarith)]
      have h1 : Real.exp (-z_q) * Real.exp z_q = 1 := by rw [← Real.exp_add]; simp
      calc (M₀ : ℝ) ^ ℓ = (M₀ : ℝ) ^ ℓ * (Real.exp (-z_q) * Real.exp z_q) := by rw [h1, mul_one]
        _ = ((M₀ : ℝ) ^ ℓ * Real.exp (-z_q)) * Real.exp z_q := by ring
        _ ≤ ((M₀ : ℝ) ^ ℓ * Real.exp (-z_q)) * (2 * polyExp (N_pow ℓ m) z_q) :=
            mul_le_mul_of_nonneg_left hp_q3 (by positivity)
        _ = 2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_q) * polyExp (N_pow ℓ m) z_q := by ring
    have hterm : 2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_q) ≤
        2 * (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) * (m : ℝ) ^ (q_search h x) := by
      calc 2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_q)
          ≤ 2 * ((c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * Real.exp (I_h h x * z_u)) * Real.exp (-z_q) := by
            gcongr
        _ = 2 * (c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * (Real.exp (I_h h x * z_u) * Real.exp (-z_q)) := by ring
        _ ≤ 2 * (c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * (cE ^ 2 * (m : ℝ) ^ (q_search h x)) :=
            mul_le_mul_of_nonneg_left hexp_q (by positivity)
        _ = 2 * (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) * (m : ℝ) ^ (q_search h x) := by ring
    dsimp [Bq]
    linarith

  have htq2_hi : targetQ2Val c_h ℓ m hℓ hm h x ≤ Bq := by
    unfold targetQ2Val
    change 100 * ((m : ℝ) * ((M₀ ^ ℓ : ℕ) : ℝ) / polyExp (N_pow ℓ m) z_bad + 1) ≤ Bq
    push_cast
    have hdiv : (m : ℝ) * (M₀ : ℝ) ^ ℓ / polyExp (N_pow ℓ m) z_bad ≤
        2 * (m : ℝ) * (M₀ : ℝ) ^ ℓ * Real.exp (-z_bad) := by
      rw [div_le_iff₀ (by linarith)]
      have h1 : Real.exp (-z_bad) * Real.exp z_bad = 1 := by rw [← Real.exp_add]; simp
      calc (m : ℝ) * (M₀ : ℝ) ^ ℓ
          = (m : ℝ) * (M₀ : ℝ) ^ ℓ * (Real.exp (-z_bad) * Real.exp z_bad) := by rw [h1, mul_one]
        _ = ((m : ℝ) * (M₀ : ℝ) ^ ℓ * Real.exp (-z_bad)) * Real.exp z_bad := by ring
        _ ≤ ((m : ℝ) * (M₀ : ℝ) ^ ℓ * Real.exp (-z_bad)) * (2 * polyExp (N_pow ℓ m) z_bad) :=
            mul_le_mul_of_nonneg_left hp_b3 (by positivity)
        _ = 2 * (m : ℝ) * (M₀ : ℝ) ^ ℓ * Real.exp (-z_bad) * polyExp (N_pow ℓ m) z_bad := by ring
    have hm_zu : (m : ℝ) * Real.exp (-z_u) ≤ 1 := by
      rw [Real.exp_neg]
      calc (m : ℝ) * (Real.exp z_u)⁻¹
          ≤ Real.exp z_u * (Real.exp z_u)⁻¹ :=
            mul_le_mul_of_nonneg_right hm_le_exp (by positivity)
        _ = 1 := mul_inv_cancel₀ (Real.exp_pos _).ne'
    have hzbad_split : Real.exp (-z_bad) = Real.exp (-z_u) * Real.exp (-z_q) := by
      rw [← Real.exp_add]
      congr 1
      dsimp [z_bad, z_u, z_q]; ring
    have hterm : 2 * (m : ℝ) * (M₀ : ℝ) ^ ℓ * Real.exp (-z_bad) ≤
        2 * (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) * (m : ℝ) ^ (q_search h x) := by
      rw [hzbad_split]
      calc 2 * (m : ℝ) * (M₀ : ℝ) ^ ℓ * (Real.exp (-z_u) * Real.exp (-z_q))
          = ((m : ℝ) * Real.exp (-z_u)) * (2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_q)) := by ring
        _ ≤ 1 * (2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_q)) :=
            mul_le_mul_of_nonneg_right hm_zu (by positivity)
        _ = 2 * (M₀ : ℝ) ^ ℓ * Real.exp (-z_q) := one_mul _
        _ ≤ 2 * ((c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * Real.exp (I_h h x * z_u)) * Real.exp (-z_q) := by
            gcongr
        _ = 2 * (c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * (Real.exp (I_h h x * z_u) * Real.exp (-z_q)) := by ring
        _ ≤ 2 * (c0 * 64) ^ ℓ * Llog ^ (2 * ℓ) * (cE ^ 2 * (m : ℝ) ^ (q_search h x)) :=
            mul_le_mul_of_nonneg_left hexp_q (by positivity)
        _ = 2 * (c0 * 64) ^ ℓ * cE ^ 2 * Llog ^ (2 * ℓ) * (m : ℝ) ^ (q_search h x) := by ring
    dsimp [Bq]
    linarith

  rcases doubleUntil_props hBu1 htu_hi with ⟨hCapU_pos, hCapU_ge, hCapU_ub, hStepsU_ub, _⟩
  rcases doubleUntil_props hBq1 (max_le htq1_hi htq2_hi) with
    ⟨hCapQ_pos, hCapQ_ge, hCapQ_ub, hStepsQ_ub, _⟩

  rcases cParam_tail_bounds hℓ hc0_pos hcE1 hLlog_half hm_r1 hu1 hq2
      (by positivity) (by positivity) (by positivity)
      hM0_ub_neat hCapU_ub hCapQ_ub hBu1 hBq1 hStepsU_ub hStepsQ_ub rfl with
    ⟨hM0_C, hCapU_C, hCapQ_C, hStepsU_bound, hStepsQ_bound⟩

  exact ⟨hM0_pos, hCapU_pos, hCapQ_pos, hp1_M0,
    htu_lo.trans hCapU_ge,
    htq1_lo.trans ((le_max_left _ _).trans hCapQ_ge),
    htq2_lo.trans ((le_max_right _ _).trans hCapQ_ge),
    hM0_C, hCapU_C, hCapQ_C, hStepsU_bound, hStepsQ_bound⟩

/-! ### 5. Guarded single-copy good event and `R`-copy union bound -/

/-- Guarded single-copy good event on `CopySeed = Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))`. -/
noncomputable def goodSingleSet {ι : Type} {d ℓ M₀ m : ℕ}
    (h x t : ℝ) (Cap_u Cap_q : ℕ)
    (P₀ : Finset ι) (dec : Fin m → ι)
    (padPts : ι → EuclideanSpace ℝ (Fin (d + 1)))
    (padQuery : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)))
    (z_hat : EuclideanSpace ℝ (Fin d)) (i_star : ι) :
    Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))) :=
  open Classical in
  if h ≤ inner ℝ (padPts i_star) (padQuery z_hat) ∧ i_star ∈ P₀ ∧ IsUnitVec z_hat then
    {ω | (∃ τ : Fin ℓ → Fin M₀, IsSharedTuple x t ω (padPts i_star) (padQuery z_hat) τ) ∧
         dataTupleCard t ω (padPts i_star) ≤ Cap_u ∧
         queryTupleCard x t ω (padQuery z_hat) ≤ Cap_q ∧
         badSharedCard x t (fun k : Fin m => padPts (dec k)) (padQuery z_hat) ω ≤ Cap_q}
  else
    Set.univ

set_option maxHeartbeats 800000 in
theorem goodSingle_and_amplification
    {d ℓ m : ℕ} (hd : 1 ≤ d) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m)
    {η : ℚ} (hη0 : 0 < η) (hη16 : (η : ℝ) ≤ 1 / 16)
    {h_min h_max h x ε₀ c_h : ℝ}
    (_hh_min : 0 < h_min) (_hh_max : h_max < 1)
    (hc_h : 0 < c_h)
    (h_probs_gen : ∀ (d' : ℕ), 1 ≤ d' → ∀ (h' x' t' : ℝ),
      h_min ≤ h' → h' ≤ h_max → h' ≤ x' → x' ≤ 1 → 1 ≤ t' →
      ∃ p_u p_q p₁ p₂ : ℝ,
        IsGaussianFilterProbs d' h' x' t' p_u p_q p₁ p₂ ∧
        p_u ≤ Real.exp (-(t' ^ 2 / 2)) ∧
        p_q ≤ Real.exp (-(x' ^ 2 * t' ^ 2 / 2)) ∧
        c_h * t' ^ (-2 : ℤ) * Real.exp (-(I_h h' x' * t' ^ 2 / 2)) ≤ p₁ ∧
        p₂ ≤ Real.exp (-((1 + x' ^ 2) * t' ^ 2 / 2)))
    (hh_lo : h_min ≤ h) (hh_hi : h ≤ h_max) (hx_lo : h ≤ x) (hx_hi : x ≤ 1)
    (hε0 : 0 < ε₀) (hε_half : ε₀ < 1 / 2)
    {net : Finset (EuclideanSpace ℝ (Fin d))}
    (hnet_unit : ∀ z_hat ∈ net, IsUnitVec z_hat)
    (hnet_log : Real.log (net.card : ℝ) ≤ 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)))
    {ι : Type} [DecidableEq ι] (P₀ : Finset ι) (hP₀_card : P₀.card = m)
    (dec : Fin m → ι) (hdec_mem : ∀ j : Fin m, dec j ∈ P₀)
    (padPts : ι → EuclideanSpace ℝ (Fin (d + 1)))
    (hpadPts_unit : ∀ i ∈ P₀, IsUnitVec (padPts i))
    (padQuery : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)))
    (hpadQuery_unit : ∀ z_hat, IsUnitVec z_hat → IsUnitVec (padQuery z_hat)) :
    let M₀ := M0Param c_h ℓ m hℓ hm h x
    let Cap_u := capUParam c_h ℓ m hℓ hm h x
    let Cap_q := capQParam c_h ℓ m hℓ hm h x
    let t := tParam ℓ m hℓ hm
    let R := RParam d m η ε₀
    let copyMeasure := Measure.pi (fun _ : Fin (ℓ * M₀) => stdGaussianMeasure (d + 1))
    let seedMeasure := Measure.pi (fun _ : Fin R => copyMeasure)
    let gs := goodSingleSet h x t Cap_u Cap_q P₀ dec padPts padQuery
    let E : Set (Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))) :=
      {ω | ∀ z_hat ∈ net, ∀ i_star ∈ P₀, ∃ r : Fin R, ω r ∈ gs z_hat i_star}
    1 ≤ R ∧
    (R : ℝ) ≤ 5 * (Real.log ((m : ℝ) / ε₀) + (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) ∧
    4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ≤ (R : ℝ) ∧
    (∀ z_hat ∈ net, ∀ i_star ∈ P₀,
      MeasurableSet (gs z_hat i_star) ∧ (9 / 10 : ℝ) ≤ copyMeasure.real (gs z_hat i_star)) ∧
    MeasurableSet E ∧
    1 - ε₀ ≤ seedMeasure.real E := by
  classical
  dsimp only
  have hh0 : 0 < h := lt_of_lt_of_le _hh_min hh_lo
  have hh1 : h < 1 := lt_of_le_of_lt hh_hi _hh_max
  rcases param_all_bounds hc_h hℓ hm hh0 hh1 hx_lo hx_hi with
    ⟨hM0_pos, hCapU_pos, hCapQ_pos, hp1_M0, hCapU_lo, hCapQ1_lo, hCapQ2_lo, _, _, _, _, _⟩
  rcases tParam_bounds hℓ hm with ⟨_, _, _, ht_ge1, _, _, _, _⟩
  rcases h_probs_gen (d + 1) (by omega) h x (tParam ℓ m hℓ hm) hh_lo hh_hi hx_lo hx_hi ht_ge1 with
    ⟨p_u, p_q, p₁, p₂, hprobs, hpu_ub, hpq_ub, hp1_lb, hp2_ub⟩

  set M₀ := M0Param c_h ℓ m hℓ hm h x
  set Cap_u := capUParam c_h ℓ m hℓ hm h x
  set Cap_q := capQParam c_h ℓ m hℓ hm h x
  set t := tParam ℓ m hℓ hm
  set R := RParam d m η ε₀
  set copyMeasure := Measure.pi (fun _ : Fin (ℓ * M₀) => stdGaussianMeasure (d + 1))
  set seedMeasure := Measure.pi (fun _ : Fin R => copyMeasure)
  set gs := goodSingleSet h x t Cap_u Cap_q P₀ dec padPts padQuery

  -- 1. Bounds on `R`
  have hR1 : 1 ≤ R := by dsimp [R, RParam]; omega
  have hm_r1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
  have hm_eps_gt2 : 2 < (m : ℝ) / ε₀ := by
    rw [lt_div_iff₀ hε0]; linarith
  have hlog_meps_pos : 0 < Real.log ((m : ℝ) / ε₀) := Real.log_pos (by linarith)
  have hη_r : (0 : ℝ) < (η : ℝ) := by exact_mod_cast hη0
  have hd_r : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  have hlog_d_eta : 2 ≤ Real.log ((d : ℝ) / (η : ℝ)) := by
    have hq16 : 16 ≤ (d : ℝ) / (η : ℝ) := by rw [le_div_iff₀ hη_r]; linarith
    have hexp2 : Real.exp 2 ≤ 16 := by
      have h1 : Real.exp 2 = Real.exp 1 * Real.exp 1 := by rw [← Real.exp_add]; norm_num
      rw [h1]
      exact (mul_le_mul exp_one_le_four exp_one_le_four (Real.exp_pos 1).le (by norm_num)).trans (by norm_num)
    calc (2 : ℝ) = Real.log (Real.exp 2) := (Real.log_exp 2).symm
      _ ≤ Real.log ((d : ℝ) / (η : ℝ)) := Real.log_le_log (Real.exp_pos 2) (hexp2.trans hq16)
  have hdlog_ge2 : 2 ≤ (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) := by
    calc (2 : ℝ) = 1 * 2 := by ring
      _ ≤ (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) :=
          mul_le_mul hd_r hlog_d_eta (by norm_num) (by positivity)
  have hR_ge_sum : Real.log ((m : ℝ) / ε₀) + 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ≤ (R : ℝ) := by
    dsimp [R, RParam]; push_cast
    linarith [Nat.le_ceil (Real.log ((m : ℝ) / ε₀) + 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)))]
  have hR_ge_4dlog : 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ≤ (R : ℝ) := by linarith
  have hR_ub : (R : ℝ) ≤ 5 * (Real.log ((m : ℝ) / ε₀) + (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) := by
    have hceil_lt := Nat.ceil_lt_add_one (a := Real.log ((m : ℝ) / ε₀) +
      4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) (by positivity)
    dsimp [R, RParam]; push_cast at hceil_lt ⊢
    linarith

  -- 2. Single-copy probability `≥ 9 / 10` for all `(z_hat, i_star) ∈ net × P₀`
  rcases hprobs with ⟨hdom, hmarg_u, hmarg_q, hjoint_lo, hjoint_hi⟩
  have hprobs' : IsGaussianFilterProbs (d + 1) h x t p_u p_q p₁ p₂ :=
    ⟨hdom, hmarg_u, hmarg_q, hjoint_lo, hjoint_hi⟩
  have hp1_pos : 0 < p₁ := lt_of_lt_of_le (by positivity) hp1_lb
  have hp1_M0' : Real.log (100 * (ℓ : ℝ)) ≤ p₁ * (M₀ : ℝ) :=
    hp1_M0.trans (mul_le_mul_of_nonneg_right hp1_lb (by positivity))
  have hpu_nn : 0 ≤ p_u := by
    let u0 : EuclideanSpace ℝ (Fin (d + 1)) := EuclideanSpace.single ⟨0, by omega⟩ 1
    have hu0_unit : IsUnitVec u0 := by simp [IsUnitVec, u0]
    rw [← hmarg_u u0 hu0_unit]; exact MeasureTheory.measureReal_nonneg
  have hpq_nn : 0 ≤ p_q := by
    let u0 : EuclideanSpace ℝ (Fin (d + 1)) := EuclideanSpace.single ⟨0, by omega⟩ 1
    have hu0_unit : IsUnitVec u0 := by simp [IsUnitVec, u0]
    rw [← hmarg_q u0 hu0_unit]; exact MeasureTheory.measureReal_nonneg
  have hp2_nn : 0 ≤ p₂ := by
    let u0 : EuclideanSpace ℝ (Fin (d + 1)) := EuclideanSpace.single ⟨0, by omega⟩ 1
    have hu0_unit : IsUnitVec u0 := by simp [IsUnitVec, u0]
    have hneg_unit : IsUnitVec (-u0) := by unfold IsUnitVec at hu0_unit ⊢; simpa using hu0_unit
    have hle0 : inner ℝ (-u0) u0 ≤ 0 := by
      rw [inner_neg_left, real_inner_self_eq_norm_sq]; linarith [sq_nonneg ‖u0‖]
    exact MeasureTheory.measureReal_nonneg.trans (hjoint_hi (-u0) u0 hneg_unit hu0_unit hle0)

  have hCapU_p : 100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1) ≤ (Cap_u : ℝ) := by
    have := pow_le_pow_left₀ hpu_nn hpu_ub ℓ
    have := mul_le_mul_of_nonneg_left this (by positivity : 0 ≤ (M₀ : ℝ) ^ ℓ)
    linarith
  have hCapQ_p : 100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1) ≤ (Cap_q : ℝ) := by
    have := pow_le_pow_left₀ hpq_nn hpq_ub ℓ
    have := mul_le_mul_of_nonneg_left this (by positivity : 0 ≤ (M₀ : ℝ) ^ ℓ)
    linarith
  have hCapBad_p : 100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1) ≤ (Cap_q : ℝ) := by
    have := pow_le_pow_left₀ hp2_nn hp2_ub ℓ
    have := mul_le_mul_of_nonneg_left this (by positivity : 0 ≤ (m : ℝ) * (M₀ : ℝ) ^ ℓ)
    linarith

  have hunit_ptsK : ∀ k : Fin m, IsUnitVec (padPts (dec k)) :=
    fun k => hpadPts_unit (dec k) (hdec_mem k)

  have hgs_all : ∀ z_hat ∈ net, ∀ i_star ∈ P₀,
      MeasurableSet (gs z_hat i_star) ∧ (9 / 10 : ℝ) ≤ copyMeasure.real (gs z_hat i_star) := by
    intro z_hat hzh i_star his
    dsimp only [gs, goodSingleSet]
    split_ifs with hcond
    · exact goodEvent_prob_ge hℓ hM0_pos hprobs' hp1_pos hp1_M0' hCapU_pos hCapQ_pos
        hCapU_p hCapQ_p hCapBad_p (fun k => padPts (dec k)) hunit_ptsK
        (hpadPts_unit i_star his) (hpadQuery_unit z_hat (hnet_unit z_hat hzh)) hcond.1
    · refine ⟨MeasurableSet.univ, ?_⟩
      simp only [MeasureTheory.measureReal_def, measure_univ, ENNReal.toReal_one]
      norm_num

  -- 3. `R`-copy union bound over `S_pairs = net ×ˢ P₀`
  let S_pairs : Finset (EuclideanSpace ℝ (Fin d) × ι) := net ×ˢ P₀
  let Fail : (EuclideanSpace ℝ (Fin d) × ι) → Set (Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))) :=
    fun zi => {ω | ∀ r : Fin R, ω r ∈ (gs zi.1 zi.2)ᶜ}
  have hFail_meas : ∀ zi ∈ S_pairs, MeasurableSet (Fail zi) := by
    intro zi hzi
    rcases Finset.mem_product.mp hzi with ⟨hzh, his⟩
    have h1 : Fail zi = ⋂ r : Fin R, {ω | ω r ∈ (gs zi.1 zi.2)ᶜ} := by ext ω; simp [Fail]
    rw [h1]
    exact MeasurableSet.iInter fun r => (hgs_all zi.1 hzh zi.2 his).1.compl.preimage (measurable_pi_apply r)

  have hFail_prob : ∀ zi ∈ S_pairs, seedMeasure.real (Fail zi) ≤ Real.exp (-(R : ℝ)) := by
    intro zi hzi
    rcases Finset.mem_product.mp hzi with ⟨hzh, his⟩
    rcases hgs_all zi.1 hzh zi.2 his with ⟨hm_gs, hp_gs⟩
    have hpi_set : Fail zi = Set.univ.pi (fun _ : Fin R => (gs zi.1 zi.2)ᶜ) := by
      ext ω; simp [Fail]
    rw [hpi_set, MeasureTheory.measureReal_def, Measure.pi_pi, ENNReal.toReal_prod]
    simp only [Finset.prod_const, Finset.card_univ, Fintype.card_fin]
    have hcompl_prob : (copyMeasure (gs zi.1 zi.2)ᶜ).toReal ≤ 1 / 10 := by
      have hc := probReal_compl_eq copyMeasure hm_gs
      simp only [MeasureTheory.measureReal_def] at hc hp_gs
      linarith
    have h10_exp : (1 / 10 : ℝ) ≤ Real.exp (-1) := by
      rw [Real.exp_neg, ← one_div]
      exact one_div_le_one_div_of_le (Real.exp_pos 1) (exp_one_le_four.trans (by norm_num))
    calc ((copyMeasure (gs zi.1 zi.2)ᶜ).toReal) ^ R
        ≤ (1 / 10 : ℝ) ^ R := pow_le_pow_left₀ ENNReal.toReal_nonneg hcompl_prob R
      _ ≤ (Real.exp (-1)) ^ R := pow_le_pow_left₀ (by norm_num) h10_exp R
      _ = Real.exp (-(R : ℝ)) := by rw [← Real.exp_nat_mul]; ring_nf

  let B_union := ⋃ zi ∈ S_pairs, Fail zi
  have hB_meas : MeasurableSet B_union := Finset.measurableSet_biUnion S_pairs hFail_meas
  let E : Set (Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))) :=
    {ω | ∀ z_hat ∈ net, ∀ i_star ∈ P₀, ∃ r : Fin R, ω r ∈ gs z_hat i_star}
  have hE_compl : E = B_unionᶜ := by
    ext ω
    simp only [E, B_union, S_pairs, Fail, Finset.mem_product, Set.mem_iUnion, exists_prop,
      Set.mem_setOf_eq, Set.mem_compl_iff, Prod.exists]
    constructor
    · intro h ⟨zh, is, ⟨hzh, his⟩, hall⟩
      rcases h zh hzh is his with ⟨r, hr⟩
      exact hall r hr
    · intro hno zh hzh is his
      by_contra hnone
      push_neg at hnone
      exact hno ⟨zh, is, ⟨hzh, his⟩, hnone⟩

  have hE_meas : MeasurableSet E := by rw [hE_compl]; exact hB_meas.compl
  have hB_prob : seedMeasure.real B_union ≤ ε₀ := by
    by_cases hnet_emp : net.card = 0
    · have hS_emp : S_pairs = ∅ := by
        rw [← Finset.card_eq_zero, Finset.card_product, hnet_emp, zero_mul]
      simp only [B_union, hS_emp, Finset.notMem_empty, Set.iUnion_of_empty, Set.iUnion_empty,
        MeasureTheory.measureReal_empty]
      exact hε0.le
    · have hnet_pos : (0 : ℝ) < (net.card : ℝ) := by exact_mod_cast (Nat.pos_of_ne_zero hnet_emp)
      have hnet_exp : (net.card : ℝ) ≤ Real.exp (4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) := by
        rw [← Real.exp_log hnet_pos]
        exact Real.exp_le_exp.mpr hnet_log
      have hexp_R : Real.exp (-(R : ℝ)) ≤
          (ε₀ / (m : ℝ)) * Real.exp (-(4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)))) := by
        calc Real.exp (-(R : ℝ))
            ≤ Real.exp (-(Real.log ((m : ℝ) / ε₀) + 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)))) :=
              Real.exp_le_exp.mpr (neg_le_neg hR_ge_sum)
          _ = Real.exp (-Real.log ((m : ℝ) / ε₀)) *
                Real.exp (-(4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)))) := by
              rw [neg_add, Real.exp_add]
          _ = (ε₀ / (m : ℝ)) * Real.exp (-(4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)))) := by
              rw [Real.exp_neg, Real.exp_log (div_pos (by positivity) hε0), inv_div]
      calc seedMeasure.real B_union
          ≤ ∑ zi ∈ S_pairs, seedMeasure.real (Fail zi) :=
            measureReal_biUnion_finset_le_sum seedMeasure S_pairs Fail
        _ ≤ ∑ _zi ∈ S_pairs, Real.exp (-(R : ℝ)) :=
            Finset.sum_le_sum hFail_prob
        _ = (net.card : ℝ) * (m : ℝ) * Real.exp (-(R : ℝ)) := by
            simp [S_pairs, Finset.card_product, hP₀_card, mul_assoc]
        _ ≤ Real.exp (4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) * (m : ℝ) *
            ((ε₀ / (m : ℝ)) * Real.exp (-(4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))))) := by
            refine mul_le_mul (mul_le_mul_of_nonneg_right hnet_exp (by positivity))
              hexp_R ?_ (by positivity)
            all_goals positivity
        _ = ε₀ := by
            have hm_ne : (m : ℝ) ≠ 0 := by positivity
            have hexp_prod : Real.exp (4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) *
                Real.exp (-(4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)))) = 1 := by
              rw [← Real.exp_add]; simp
            calc Real.exp (4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) * (m : ℝ) *
                  ((ε₀ / (m : ℝ)) * Real.exp (-(4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)))))
                = (Real.exp (4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))) *
                    Real.exp (-(4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ))))) *
                    ((m : ℝ) * (ε₀ / (m : ℝ))) := by ring
              _ = 1 * ((m : ℝ) * (ε₀ / (m : ℝ))) := by rw [hexp_prod]
              _ = ε₀ := by field_simp [hm_ne]

  refine ⟨hR1, hR_ub, hR_ge_4dlog, hgs_all, hE_meas, ?_⟩
  change 1 - ε₀ ≤ seedMeasure.real E
  rw [hE_compl, probReal_compl_eq seedMeasure hB_meas]
  linarith

end UL.Proof_clm_6_1_adaptive_RaceV30
