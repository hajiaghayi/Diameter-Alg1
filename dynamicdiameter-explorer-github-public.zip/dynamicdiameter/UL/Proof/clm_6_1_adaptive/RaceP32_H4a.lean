import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
import UL.Def.def_6_1_gaussian_filter
import UL.Proof.lem_6_3.H1_RAM
import UL.Proof.lem_6_3.H5_Prob
import UL.Proof.lem_6_3.RacerV30_H3
import UL.Proof.lem_6_3.RacerV30_H4
import UL.Proof.clm_6_1_adaptive.H1a_Net
import UL.Proof.clm_6_1_adaptive.H1b_Lift
import UL.Proof.clm_6_1_adaptive.RaceP32_H2
import UL.Proof.clm_6_1_adaptive.RaceP32_H3
set_option autoImplicit false

namespace UL.Proof_clm_6_1_adaptive_RaceP32
open UL.Proof_clm_6_1_adaptive_RaceV30

open UL.Proof_lem_6_3 UL.Proof.lem_6_3.RacerV30 UL.Proof_clm_6_1_adaptive

/-! ### 1. Reusable scratch footprint `(AdaptiveSW, AdaptiveSR)` and `extraCells` lemmas -/

abbrev AdaptiveSW (R ℓ M₀ Cap_q d : ℕ) : Finset RAMCellLoc :=
  scratchWords (2 * R * ℓ) M₀ (Cap_q + d)

abbrev AdaptiveSR (d R ℓ M₀ : ℕ) : Finset RAMCellLoc :=
  scratchReals d (2 * R * ℓ) M₀

theorem extraCells_empty (SW SR : Finset RAMCellLoc) :
    extraCells SW SR ArithRAMMemory.empty = 0 := by
  simp [extraCells, ArithRAMMemory.empty, WordStore.empty, RealStore.empty]

theorem extraCells_le_of_subset {SW SR : Finset RAMCellLoc}
    {mem₀ mem₁ : ArithRAMMemory} {W R_set : Finset RAMCellLoc}
    (hw_sub : mem₁.words.live ⊆ mem₀.words.live ∪ W)
    (hW : W ⊆ SW)
    (hr_sub : mem₁.reals.live ⊆ mem₀.reals.live ∪ R_set)
    (hR : R_set ⊆ SR) :
    extraCells SW SR mem₁ ≤ extraCells SW SR mem₀ := by
  unfold extraCells
  have hw : mem₁.words.live \ SW ⊆ mem₀.words.live \ SW := by
    intro x hx
    rw [Finset.mem_sdiff] at hx ⊢
    rcases Finset.mem_union.mp (hw_sub hx.1) with h0 | hw'
    · exact ⟨h0, hx.2⟩
    · exact absurd (hW hw') hx.2
  have hr : mem₁.reals.live \ SR ⊆ mem₀.reals.live \ SR := by
    intro x hx
    rw [Finset.mem_sdiff] at hx ⊢
    rcases Finset.mem_union.mp (hr_sub hx.1) with h0 | hr'
    · exact ⟨h0, hx.2⟩
    · exact absurd (hR hr') hx.2
  exact Nat.add_le_add (Finset.card_le_card hw) (Finset.card_le_card hr)

theorem heapRange_subset_rangeHeap {t a b : ℕ} (hab : a ≤ b) :
    heapRange t a ⊆ rangeHeap t b := by
  intro loc hloc
  unfold heapRange at hloc
  rcases Finset.mem_image.mp hloc with ⟨i, hi, rfl⟩
  exact mem_rangeHeap (lt_of_lt_of_le (Finset.mem_range.mp hi) hab)

theorem rangeHeap_0_sub_ASW {R ℓ M₀ Cap_q d n : ℕ} (hn : n ≤ Cap_q + d + 3) :
    heapRange 0 n ⊆ AdaptiveSW R ℓ M₀ Cap_q d :=
  (heapRange_subset_rangeHeap hn).trans
    (Finset.subset_union_left.trans (Finset.subset_union_left.trans
      (Finset.subset_union_left.trans Finset.subset_union_left)))

theorem rangeHeap_1_sub_ASW {R ℓ M₀ Cap_q d n : ℕ} (hn : n ≤ 10) :
    heapRange 1 n ⊆ AdaptiveSW R ℓ M₀ Cap_q d :=
  (heapRange_subset_rangeHeap hn).trans
    (Finset.subset_union_right.trans (Finset.subset_union_left.trans
      (Finset.subset_union_left.trans Finset.subset_union_left)))

theorem rangeHeap_5_sub_ASW {R ℓ M₀ Cap_q d n : ℕ} (hn : n ≤ 2 * R * ℓ + 1) :
    heapRange 5 n ⊆ AdaptiveSW R ℓ M₀ Cap_q d :=
  (heapRange_subset_rangeHeap hn).trans
    (Finset.subset_union_right.trans (Finset.subset_union_left.trans Finset.subset_union_left))

theorem rangeHeap_6_sub_ASW {R ℓ M₀ Cap_q d n : ℕ} (hn : n ≤ 2 * R * ℓ * M₀ + 1) :
    heapRange 6 n ⊆ AdaptiveSW R ℓ M₀ Cap_q d :=
  (heapRange_subset_rangeHeap hn).trans
    (Finset.subset_union_right.trans Finset.subset_union_left)

theorem rangeHeap_11_sub_ASW {R ℓ M₀ Cap_q d n : ℕ} (hn : n ≤ 32) :
    heapRange 11 n ⊆ AdaptiveSW R ℓ M₀ Cap_q d :=
  (heapRange_subset_rangeHeap hn).trans Finset.subset_union_right

theorem rangeHeap_1_sub_ASR {d R ℓ M₀ n : ℕ} (hn : n ≤ 5) :
    heapRange 1 n ⊆ AdaptiveSR d R ℓ M₀ :=
  (heapRange_subset_rangeHeap hn).trans
    (Finset.subset_union_left.trans (Finset.subset_union_left.trans Finset.subset_union_left))

theorem rangeHeap_2_sub_ASR {d R ℓ M₀ n : ℕ} (hn : n ≤ 2 * R * ℓ * M₀ * d + 1) :
    heapRange 2 n ⊆ AdaptiveSR d R ℓ M₀ :=
  (heapRange_subset_rangeHeap hn).trans
    (Finset.subset_union_right.trans (Finset.subset_union_left.trans Finset.subset_union_left))

theorem rangeHeap_3_sub_ASR {d R ℓ M₀ n : ℕ} (hn : n ≤ d + 1) :
    heapRange 3 n ⊆ AdaptiveSR d R ℓ M₀ :=
  (heapRange_subset_rangeHeap hn).trans
    (Finset.subset_union_right.trans Finset.subset_union_left)

theorem rangeHeap_17_sub_ASR {d R ℓ M₀ n : ℕ} (hn : n ≤ 16) :
    heapRange 17 n ⊆ AdaptiveSR d R ℓ M₀ :=
  (heapRange_subset_rangeHeap hn).trans Finset.subset_union_right

theorem mem_ASW_0 {R ℓ M₀ Cap_q d : ℕ} {i : ℕ} (hi : i < Cap_q + d + 3) :
    RAMCellLoc.heap 0 (i : ℤ) ∈ AdaptiveSW R ℓ M₀ Cap_q d :=
  mem_scratchWords_0 hi

theorem mem_ASW_1 {R ℓ M₀ Cap_q d : ℕ} {i : ℕ} (hi : i < 10) :
    RAMCellLoc.heap 1 (i : ℤ) ∈ AdaptiveSW R ℓ M₀ Cap_q d :=
  rangeHeap_1_sub_ASW le_rfl (mem_heapRange (by omega) (by exact_mod_cast hi))

theorem mem_ASW_5 {R ℓ M₀ Cap_q d : ℕ} {i : ℕ} (hi : i < 2 * R * ℓ + 1) :
    RAMCellLoc.heap 5 (i : ℤ) ∈ AdaptiveSW R ℓ M₀ Cap_q d :=
  mem_scratchWords_5 hi

theorem mem_ASW_6 {R ℓ M₀ Cap_q d : ℕ} {i : ℕ} (hi : i < 2 * R * ℓ * M₀ + 1) :
    RAMCellLoc.heap 6 (i : ℤ) ∈ AdaptiveSW R ℓ M₀ Cap_q d :=
  mem_scratchWords_6 hi

theorem mem_ASW_11 {R ℓ M₀ Cap_q d : ℕ} {i : ℕ} (hi : i < 32) :
    RAMCellLoc.heap 11 (i : ℤ) ∈ AdaptiveSW R ℓ M₀ Cap_q d :=
  mem_scratchWords_11 hi

theorem mem_ASR_1 {d R ℓ M₀ : ℕ} {i : ℕ} (hi : i < 5) :
    RAMCellLoc.heap 1 (i : ℤ) ∈ AdaptiveSR d R ℓ M₀ :=
  rangeHeap_1_sub_ASR le_rfl (mem_heapRange (by omega) (by exact_mod_cast hi))

theorem mem_ASR_2 {d R ℓ M₀ : ℕ} {i : ℕ} (hi : i < 2 * R * ℓ * M₀ * d + 1) :
    RAMCellLoc.heap 2 (i : ℤ) ∈ AdaptiveSR d R ℓ M₀ :=
  mem_scratchReals_2 hi

theorem mem_ASR_3 {d R ℓ M₀ : ℕ} {i : ℕ} (hi : i < d + 1) :
    RAMCellLoc.heap 3 (i : ℤ) ∈ AdaptiveSR d R ℓ M₀ :=
  mem_scratchReals_3 hi

theorem mem_ASR_17 {d R ℓ M₀ : ℕ} {i : ℕ} (hi : i < 16) :
    RAMCellLoc.heap 17 (i : ℤ) ∈ AdaptiveSR d R ℓ M₀ :=
  mem_scratchReals_17 hi

/-! ### 2. `R`-copy bucket indexing and `DataStructInv` -/

def pairIdx {R m : ℕ} (r : Fin R) (j : Fin m) : Fin (R * m) :=
  ⟨r.val * m + j.val, by
    calc r.val * m + j.val < r.val * m + m := Nat.add_lt_add_left j.isLt _
      _ = (r.val + 1) * m := by ring
      _ ≤ R * m := Nat.mul_le_mul_right m (Nat.succ_le_of_lt r.isLt)⟩

theorem pairIdx_div_mod {R m : ℕ} (r : Fin R) (j : Fin m) :
    (pairIdx r j).val / m = r.val ∧ (pairIdx r j).val % m = j.val := by
  have hm : 0 < m := Nat.zero_lt_of_lt j.isLt
  dsimp [pairIdx]
  constructor
  · rw [Nat.mul_comm, Nat.mul_add_div hm, Nat.div_eq_of_lt j.isLt, Nat.add_zero]
  · rw [Nat.add_comm, Nat.mul_comm r.val m, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt j.isLt]

theorem pairIdx_inj {R m : ℕ} {r₁ r₂ : Fin R} {j₁ j₂ : Fin m}
    (h : pairIdx r₁ j₁ = pairIdx r₂ j₂) : r₁ = r₂ ∧ j₁ = j₂ := by
  have hv := congrArg Fin.val h
  dsimp [pairIdx] at hv
  rcases pair_addr_inj j₁.isLt j₂.isLt hv with ⟨hr, hj⟩
  exact ⟨Fin.ext hr, Fin.ext hj⟩

noncomputable def dataPassPred {d ℓ M₀ : ℕ} (t : ℝ)
    (ω_r : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (p : EuclideanSpace ℝ (Fin (d + 1))) (f : Fin ℓ) (u : Fin M₀) : Prop :=
  gaussianDataTest t (ω_r (capIdx f u)) p

noncomputable def dataSlotBound {d ℓ M₀ : ℕ} (Cap_u : ℕ) (t : ℝ)
    (ω_r : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (p : EuclideanSpace ℝ (Fin (d + 1))) : ℕ :=
  open Classical in
  min Cap_u (prefixProd (fun f =>
    if hf : f < ℓ then (hitList (dataPassPred t ω_r p ⟨f, hf⟩)).length else 1) ℓ)

theorem dataProd_eq_dataTupleCard {d ℓ M₀ : ℕ} (t : ℝ)
    (ω_r : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (p : EuclideanSpace ℝ (Fin (d + 1))) :
    (open Classical in
      prefixProd (fun f =>
        if hf : f < ℓ then (hitList (dataPassPred t ω_r p ⟨f, hf⟩)).length else 1) ℓ) =
      dataTupleCard t ω_r p := by
  classical
  rw [prefixProd_eq_tuple_card (dataPassPred t ω_r p)]
  unfold dataTupleCard IsDataTuple dataPassPred
  congr 1
  ext τ
  simp

noncomputable def localDataBkt {d ℓ M₀ : ℕ} (t : ℝ)
    (ω_r : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (p : EuclideanSpace ℝ (Fin (d + 1))) (s : ℕ) : ℕ :=
  open Classical in
  if hs : s < prefixProd (fun f =>
      if hf : f < ℓ then (hitList (dataPassPred t ω_r p ⟨f, hf⟩)).length else 1) ℓ then
    encodeTuple (enumTuple (dataPassPred t ω_r p) s hs)
  else
    s

noncomputable def globalDataBkt {d ℓ M₀ R m : ℕ} (hm : 1 ≤ m) (t : ℝ)
    (ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1)))
    (p : Fin (R * m)) (s : ℕ) : ℕ :=
  have hr : p.val / m < R := Nat.div_lt_of_lt_mul (by linarith [p.isLt, Nat.mul_comm R m])
  have hj : p.val % m < m := Nat.mod_lt _ (by omega)
  (p.val / m) * (M₀ ^ ℓ) + localDataBkt t (ω ⟨p.val / m, hr⟩) (ptsK ⟨p.val % m, hj⟩) s

theorem globalDataBkt_pairIdx {d ℓ M₀ R m : ℕ} (hm : 1 ≤ m) (t : ℝ)
    (ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1)))
    (r : Fin R) (j : Fin m) (s : ℕ) :
    globalDataBkt hm t ω ptsK (pairIdx r j) s =
      r.val * (M₀ ^ ℓ) + localDataBkt t (ω r) (ptsK j) s := by
  unfold globalDataBkt
  rcases pairIdx_div_mod r j with ⟨hd_eq, hm_eq⟩
  simp [hd_eq, hm_eq]

noncomputable def activePairsOf {d ℓ M₀ R m : ℕ} (Cap_u : ℕ) (t : ℝ)
    (ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1)))
    (Copies : Finset (Fin R)) (Active : Finset (Fin m)) : Finset (Fin (R * m) × ℕ) :=
  Copies.biUnion (fun r =>
    Active.biUnion (fun j =>
      (Finset.range (dataSlotBound Cap_u t (ω r) (ptsK j))).image (fun s => (pairIdx r j, s))))

theorem mem_activePairsOf_iff {d ℓ M₀ R m : ℕ} {Cap_u : ℕ} {t : ℝ}
    {ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))}
    {ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1))}
    {Copies : Finset (Fin R)} {Active : Finset (Fin m)} {p : Fin (R * m)} {s : ℕ} :
    (p, s) ∈ activePairsOf Cap_u t ω ptsK Copies Active ↔
      ∃ r ∈ Copies, ∃ j ∈ Active, p = pairIdx r j ∧ s < dataSlotBound Cap_u t (ω r) (ptsK j) := by
  simp only [activePairsOf, Finset.mem_biUnion, Finset.mem_image, Finset.mem_range, Prod.mk.injEq]
  constructor
  · rintro ⟨r, hr, j, hj, s', hs', rfl, rfl⟩
    exact ⟨r, hr, j, hj, rfl, hs'⟩
  · rintro ⟨r, hr, j, hj, rfl, hs⟩
    exact ⟨r, hr, j, hj, s, hs, rfl, rfl⟩

theorem globalDataBkt_inj_of_lt {d ℓ M₀ R m : ℕ} (hm : 1 ≤ m) {Cap_u : ℕ} {t : ℝ}
    {ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))}
    {ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1))}
    {p : Fin (R * m)} {s₁ s₂ : ℕ}
    (hs₁ : s₁ < (open Classical in prefixProd (fun f =>
      if hf : f < ℓ then (hitList (dataPassPred t
        (ω ⟨p.val / m, Nat.div_lt_of_lt_mul (by linarith [p.isLt, Nat.mul_comm R m])⟩)
        (ptsK ⟨p.val % m, Nat.mod_lt _ (by omega)⟩) ⟨f, hf⟩)).length else 1) ℓ))
    (hs₂ : s₂ < (open Classical in prefixProd (fun f =>
      if hf : f < ℓ then (hitList (dataPassPred t
        (ω ⟨p.val / m, Nat.div_lt_of_lt_mul (by linarith [p.isLt, Nat.mul_comm R m])⟩)
        (ptsK ⟨p.val % m, Nat.mod_lt _ (by omega)⟩) ⟨f, hf⟩)).length else 1) ℓ))
    (heq : globalDataBkt hm t ω ptsK p s₁ = globalDataBkt hm t ω ptsK p s₂) :
    s₁ = s₂ := by
  classical
  let _ := Cap_u
  dsimp only [globalDataBkt, localDataBkt] at heq
  rw [dif_pos hs₁, dif_pos hs₂] at heq
  have hloc : encodeTuple (enumTuple _ s₁ hs₁) = encodeTuple (enumTuple _ s₂ hs₂) :=
    Nat.add_left_cancel heq
  by_cases hM₀ : 1 ≤ M₀
  · exact enumTuple_injective _ hs₁ hs₂ (encodeTuple_injective hM₀ hloc)
  · have hM0_eq : M₀ = 0 := by omega
    subst hM0_eq
    by_cases hℓ0 : ℓ = 0
    · subst hℓ0
      dsimp [prefixProd] at hs₁ hs₂
      omega
    · have h0_lt : 0 < ℓ := by omega
      have hempty : IsEmpty (Fin ℓ → Fin 0) := ⟨fun τ => Fin.elim0 (τ ⟨0, h0_lt⟩)⟩
      have hp_eq := prefixProd_eq_tuple_card (dataPassPred t
        (ω ⟨p.val / m, Nat.div_lt_of_lt_mul (by linarith [p.isLt, Nat.mul_comm R m])⟩)
        (ptsK ⟨p.val % m, Nat.mod_lt _ (by omega)⟩))
      dsimp only at hp_eq
      rw [hp_eq] at hs₁
      have hcard0 : (Finset.univ.filter (fun τ : Fin ℓ → Fin 0 =>
          ∀ f, dataPassPred t
            (ω ⟨p.val / m, Nat.div_lt_of_lt_mul (by linarith [p.isLt, Nat.mul_comm R m])⟩)
            (ptsK ⟨p.val % m, Nat.mod_lt _ (by omega)⟩) f (τ f))).card = 0 := by
        rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
        intro τ _
        exact (hempty.false τ).elim
      omega

theorem slot_lt_prod_of_lt_bound {d ℓ M₀ : ℕ} {Cap_u : ℕ} {t : ℝ}
    {ω_r : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))}
    {v : EuclideanSpace ℝ (Fin (d + 1))} {s : ℕ}
    (hs : s < dataSlotBound Cap_u t ω_r v) :
    s < (open Classical in prefixProd (fun f =>
      if hf : f < ℓ then (hitList (dataPassPred t ω_r v ⟨f, hf⟩)).length else 1) ℓ) := by
  classical
  unfold dataSlotBound at hs
  exact lt_of_lt_of_le hs (Nat.min_le_right _ _)

/-- Persistent invariant of the `R`-copy data structure memory across build, deletions, and queries. -/
structure DataStructInv {d ℓ M₀ R m : ℕ} (hm : 1 ≤ m)
    (Cap_u Cap_q : ℕ) (A B η : ℚ) (x t : ℝ)
    (ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1)))
    (Inserted : Finset (Fin m)) (Active : Finset (Fin m)) (extraBnd : ℕ)
    (mem : ArithRAMMemory) : Prop where
  clean : CleanMem mem
  sub_act : Active ⊆ Inserted
  extra_le : extraCells (AdaptiveSW R ℓ M₀ Cap_q d) (AdaptiveSR d R ℓ M₀) mem ≤ extraBnd
  hdr_Rm : wRead mem 1 0 = ((R * m : ℕ) : ℤ)
  hdr_m : wRead mem 1 1 = (m : ℤ)
  hdr_R : wRead mem 1 2 = (R : ℤ)
  hdr_Capu : wRead mem 1 3 = (Cap_u : ℤ)
  hdr_M0 : wRead mem 1 4 = (M₀ : ℤ)
  hdr_M0pow : wRead mem 1 5 = ((M₀ ^ ℓ : ℕ) : ℤ)
  hdr_Capq : wRead mem 1 6 = (Cap_q : ℤ)
  hdr_etaN : wRead mem 1 7 = η.num
  hdr_etaD : wRead mem 1 8 = (η.den : ℤ)
  hdr_xt : rRead mem 1 0 = x * t
  hdr_t : rRead mem 1 1 = t
  hdr_A : rRead mem 1 2 = (A : ℝ)
  hdr_B : rRead mem 1 3 = (B : ℝ)
  gauss : ∀ (r : Fin R) (g : Fin (ℓ * M₀)) (coord : Fin (d + 1)),
    rRead mem 2 (((r.val * (ℓ * M₀) + g.val) * (d + 1) + coord.val : ℕ) : ℤ) =
      euclideanCoord (ω r g) coord
  slot_cnt : ∀ (r : Fin R) (j : Fin m), j ∈ Inserted →
    wRead mem 21 ((pairIdx r j).val : ℤ) = (dataSlotBound Cap_u t (ω r) (ptsK j) : ℤ)
  buckets : BucketInv Cap_u (globalDataBkt hm t ω ptsK)
    (activePairsOf Cap_u t ω ptsK Finset.univ Active) mem

/-! ### 3. `inp_seed` Gaussian extraction and `initSeedProg` -/

theorem inp_seed_extraReals_gauss {d R N_caps : ℕ} (g_val x_val : ℝ)
    (ω : Fin R → Fin N_caps → EuclideanSpace ℝ (Fin (d + 1)))
    (r : Fin R) (c : Fin N_caps) (coord : Fin (d + 1)) :
    listGetIntD
      ([g_val, x_val] ++
        (List.finRange R).flatMap (fun r' =>
          (List.finRange N_caps).flatMap (fun c' =>
            List.ofFn (fun coord' : Fin (d + 1) => euclideanCoord (ω r' c') coord'))))
      ((2 + ((r.val * N_caps + c.val) * (d + 1) + coord.val) : ℕ) : ℤ) 0 =
      euclideanCoord (ω r c) coord := by
  simp only [listGetIntD, Nat.cast_nonneg, ↓reduceIte, Int.toNat_natCast]
  have hsh : 2 + ((r.val * N_caps + c.val) * (d + 1) + coord.val) =
      [g_val, x_val].length + ((r.val * N_caps + c.val) * (d + 1) + coord.val) := rfl
  rw [hsh, list_getD_append_right]
  have hflat :
      (List.finRange R).flatMap (fun r' =>
        (List.finRange N_caps).flatMap (fun c' =>
          List.ofFn (fun coord' : Fin (d + 1) => euclideanCoord (ω r' c') coord'))) =
      ((List.finRange R).flatMap (fun r' =>
        (List.finRange N_caps).map (fun c' => (r', c')))).flatMap
        (fun rc => List.ofFn (fun coord' : Fin (d + 1) => euclideanCoord (ω rc.1 rc.2) coord')) := by
    simp [List.flatMap_assoc, List.flatMap_map]
  rw [hflat]
  let pairs := (List.finRange R).flatMap (fun r' => (List.finRange N_caps).map (fun c' => (r', c')))
  have hpairs_len : pairs.length = R * N_caps := by
    dsimp [pairs]
    rw [List.length_flatMap]
    simp [List.map_const']
  have hidx_lt : r.val * N_caps + c.val < pairs.length := by
    rw [hpairs_len]
    calc r.val * N_caps + c.val < r.val * N_caps + N_caps := Nat.add_lt_add_left c.isLt _
      _ = (r.val + 1) * N_caps := by ring
      _ ≤ R * N_caps := Nat.mul_le_mul_right N_caps (Nat.succ_le_of_lt r.isLt)
  rw [list_flatMap_ofFn_getD
    (fun rc : Fin R × Fin N_caps => fun coord' : Fin (d + 1) => euclideanCoord (ω rc.1 rc.2) coord')
    pairs (r.val * N_caps + c.val) hidx_lt coord 0]
  have hpairs_get : pairs[r.val * N_caps + c.val]'hidx_lt = (r, c) := by
    have hgetD := list_getD_eq_getElem pairs (r.val * N_caps + c.val) hidx_lt (r, c)
    have hofFn_eq : pairs = (List.finRange R).flatMap (fun r' =>
        List.ofFn (fun c' : Fin N_caps => (r', c'))) := by
      dsimp [pairs]
      congr 1
      funext r'
      rw [List.ofFn_eq_map]
    have hgetD2 : pairs.getD (r.val * N_caps + c.val) (r, c) = (r, c) := by
      rw [hofFn_eq]
      simpa using list_flatMap_ofFn_getD (fun r' : Fin R => fun c' : Fin N_caps => (r', c'))
        (List.finRange R) r.val (by simp) c (r, c)
    exact hgetD.symm.trans hgetD2
  rw [hpairs_get]

def computeM0PowStmt (ℓ : ℕ) : ArithRAMStmt :=
  .seq
    (.writeWordHeap 1 (.lit 5) (.lit 1))
    (.repeatN (.lit (ℓ : ℤ))
      (.writeWordHeap 1 (.lit 5) (.mul (.readHeap 1 (.lit 5)) (.readHeap 1 (.lit 4)))))

def computeLmStmt : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 11 (.lit 2) (.lit 1),
      .writeWordHeap 11 (.lit 3) (.lit 2),
      .whileLoop (.intLe (.readHeap 11 (.lit 3)) (.readHeap 1 (.lit 1)))
        (.seq
          (.writeWordHeap 11 (.lit 3) (.mul (.lit 2) (.readHeap 11 (.lit 3))))
          (.writeWordHeap 11 (.lit 2) (.add (.readHeap 11 (.lit 2)) (.lit 1)))) ]

def tStepRealExpr (ℓ : ℕ) : RealExpr :=
  .add (.ofInt (.lit 1))
    (.div (.ofInt (.readHeap 11 (.lit 5)))
      (.ofInt (.mul (.lit (ℓ : ℤ)) (.readHeap 11 (.lit 2)))))

def zStepRealExpr (ℓ : ℕ) : RealExpr :=
  .div (.mul (.ofInt (.lit (ℓ : ℤ))) (.mul (tStepRealExpr ℓ) (tStepRealExpr ℓ)))
    (.ofInt (.lit 2))

def computeTStmt (ℓ : ℕ) : ArithRAMStmt :=
  seqStmts
    [ .writeWordHeap 11 (.lit 5) (.lit 0),
      .writeRealHeap 17 (.lit 0) (zStepRealExpr ℓ),
      powPolyStmt 11 4 17 0 1,
      .whileLoop (.realLt (.readRealHeap 17 (.lit 1))
          (.mul (.ofInt (.lit 2)) (.ofInt (.readHeap 1 (.lit 1)))))
        (seqStmts
          [ .writeWordHeap 11 (.lit 5) (.add (.readHeap 11 (.lit 5)) (.lit 1)),
            .writeRealHeap 17 (.lit 0) (zStepRealExpr ℓ),
            powPolyStmt 11 4 17 0 1 ]) ]

def initSeedProg (ℓ : ℕ) : ArithRAMStmt :=
  let lE := IntExpr.readHeap 11 (.lit 2)
  let l2E := IntExpr.mul lE lE
  let l4E := IntExpr.mul l2E l2E
  let m0PowR := RealExpr.ofInt (.readHeap 1 (.lit 5))
  let mR := RealExpr.ofInt (.readHeap 1 (.lit 1))
  let xtR := RealExpr.readRealHeap 1 (.lit 0)
  let tR := RealExpr.readRealHeap 1 (.lit 1)
  let polyR := RealExpr.readRealHeap 17 (.lit 1)
  let totalGE := IntExpr.mul (.mul (.readHeap 1 (.lit 2)) (.intParam (.lit 3))) (.add .dim (.lit 1))
  let idxE := IntExpr.readHeap 11 (.lit 6)
  seqStmts
    [ -- Header words `w[1, 1], w[1, 2], w[1, 0], w[1, 4], w[1, 7], w[1, 8], w[1, 5]`
      .writeWordHeap 1 (.lit 1) (.intParam (.lit 0)),
      .writeWordHeap 1 (.lit 2) (.intParam (.lit 2)),
      .writeWordHeap 1 (.lit 0) (.mul (.readHeap 1 (.lit 2)) (.readHeap 1 (.lit 1))),
      .writeWordHeap 1 (.lit 4) (.div (.intParam (.lit 3)) (.lit (ℓ : ℤ))),
      .writeWordHeap 1 (.lit 7) (.intParam (.lit 8)),
      .writeWordHeap 1 (.lit 8) (.intParam (.lit 9)),
      computeM0PowStmt ℓ,
      -- `L_m m` in `w[11, 2]` and `N_pow ℓ m` in `w[11, 4]`
      computeLmStmt,
      .writeWordHeap 11 (.lit 4) (.add (.mul (.lit ((1000 * ℓ ^ 2 : ℕ) : ℤ)) l4E) (.lit 1)),
      -- `kStar` in `w[11, 5]`, `polyExp N z_u` in `r[17, 1]`, `t` in `r[1, 1]`, `x * t` in `r[1, 0]`
      computeTStmt ℓ,
      .writeRealHeap 1 (.lit 1) (tStepRealExpr ℓ),
      .writeRealHeap 1 (.lit 0) (.mul (.extraReal (.lit 1)) (.readRealHeap 1 (.lit 1))),
      -- `Cap_u` in `w[1, 3]`
      .writeRealHeap 17 (.lit 2)
        (.mul (.ofInt (.lit 100)) (.add (.div m0PowR polyR) (.ofInt (.lit 1)))),
      doubleUntilStmt 1 3 17 2,
      -- `Cap_q` in `w[1, 6]`
      .writeRealHeap 17 (.lit 0)
        (.div (.mul (.ofInt (.lit (ℓ : ℤ))) (.mul xtR xtR)) (.ofInt (.lit 2))),
      powPolyStmt 11 4 17 0 1,
      .writeRealHeap 17 (.lit 2)
        (.mul (.ofInt (.lit 100)) (.add (.div m0PowR polyR) (.ofInt (.lit 1)))),
      .writeRealHeap 17 (.lit 0)
        (.div (.mul (.ofInt (.lit (ℓ : ℤ))) (.add (.mul tR tR) (.mul xtR xtR))) (.ofInt (.lit 2))),
      powPolyStmt 11 4 17 0 1,
      .writeRealHeap 17 (.lit 3)
        (.mul (.ofInt (.lit 100)) (.add (.div (.mul mR m0PowR) polyR) (.ofInt (.lit 1)))),
      .ite (.realLe (.readRealHeap 17 (.lit 2)) (.readRealHeap 17 (.lit 3)))
        (.writeRealHeap 17 (.lit 4) (.readRealHeap 17 (.lit 3)))
        (.writeRealHeap 17 (.lit 4) (.readRealHeap 17 (.lit 2))),
      doubleUntilStmt 1 6 17 4,
      -- `(A, B)` via `bisectABStmt` into `r[17, 2], r[17, 3]`, then copy into `r[1, 2], r[1, 3]`
      bisectABStmt (.intParam (.lit 6)) (.intParam (.lit 7))
        (.intParam (.lit 8)) (.intParam (.lit 9)) 11 17,
      .writeRealHeap 1 (.lit 2) (.readRealHeap 17 (.lit 2)),
      .writeRealHeap 1 (.lit 3) (.readRealHeap 17 (.lit 3)),
      -- Copy all `R * N_caps * (d + 1)` Gaussians into `r[2, 0 .. totalG - 1]`
      .writeWordHeap 11 (.lit 6) (.lit 0),
      .repeatN totalGE
        (.seq
          (.writeRealHeap 2 idxE (.extraReal (.add (.lit 2) idxE)))
          (.writeWordHeap 11 (.lit 6) (.add idxE (.lit 1)))) ]

theorem exec_computeM0PowStmt {d : ℕ} (inp : ArithRAMInput d) (ℓ M₀ : ℕ)
    (SW SR : Finset RAMCellLoc) (h1_5 : RAMCellLoc.heap 1 5 ∈ SW)
    (mem₀ : ArithRAMMemory) (hc₀ : CleanMem mem₀)
    (hw4 : wRead mem₀ 1 4 = (M₀ : ℤ)) :
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp (computeM0PowStmt ℓ) mem₀ mem₁ (10 + ℓ * 12) ∧
      extraCells SW SR mem₁ ≤ extraCells SW SR mem₀ ∧
      wRead mem₁ 1 5 = ((M₀ ^ ℓ : ℕ) : ℤ) ∧
      (∀ t i, (t ≠ 1 ∨ i ≠ 5) → wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ t i, rRead mem₁ t i = rRead mem₀ t i) := by
  rcases exec_wSet_sw SW SR inp hc₀ 1 (.lit 5) 5 h1_5 (.lit 1) 1 5
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m0, s0, hex0, hw0_5, hw0_ne, hr0⟩
  let Inv : ℕ → ArithRAMMemory → Prop := fun j m =>
    extraCells SW SR m ≤ extraCells SW SR mem₀ ∧
    wRead m 1 5 = ((M₀ ^ j : ℕ) : ℤ) ∧
    (∀ t i, (t ≠ 1 ∨ i ≠ 5) → wRead m t i = wRead mem₀ t i) ∧
    (∀ t i, rRead m t i = rRead mem₀ t i)
  have hInv0 : Inv 0 m0 := ⟨by omega, by simpa using hw0_5, hw0_ne, hr0⟩
  have hcnt : evalIntExpr inp.toWordView 0 m0.words (.lit (ℓ : ℤ)) =
      ((ℓ : ℤ), 1, intBitLength (ℓ : ℤ)) := rfl
  rcases ExecStmt.repeatN_nat ℓ 5 12 Inv s0.2.1 hInv0 hcnt (by omega)
    (fun j _ m hcm ⟨hex, hw5, hw_ne, hr_eq⟩ => by
      have hw4' : m.words.read (.heap 1 4) = (M₀ : ℤ) :=
        (hw_ne 1 4 (Or.inr (by decide))).trans hw4
      have hw5' : m.words.read (.heap 1 5) = ((M₀ ^ j : ℕ) : ℤ) := hw5
      rcases exec_wSet_sw SW SR inp hcm 1 (.lit 5) 5 h1_5
        (.mul (.readHeap 1 (.lit 5)) (.readHeap 1 (.lit 4))) ((M₀ ^ (j + 1) : ℕ) : ℤ) 12
        (by simp [evalIntExpr])
        (by simp [evalIntExpr, hw5', hw4', pow_succ])
        (by simp [evalIntExpr])
        with ⟨m', sb, hex', hw5'', hw_ne', hr'⟩
      exact ⟨m', sb, by omega, hw5'',
        fun t i hne => (hw_ne' t i hne).trans (hw_ne t i hne),
        fun t i => (hr' t i).trans (hr_eq t i)⟩)
    with ⟨mem₁, ⟨hex1, hw5_1, hw_ne1, hr1⟩, sLoop⟩
  exact ⟨mem₁, (ExecStmt.seq s0 sLoop).mono_cost (by omega), hex1, hw5_1, hw_ne1, hr1⟩

theorem exec_computeLmStmt {d : ℕ} (inp : ArithRAMInput d) {m : ℕ} (hm : 1 ≤ m)
    (SW SR : Finset RAMCellLoc)
    (h11_2 : RAMCellLoc.heap 11 2 ∈ SW) (h11_3 : RAMCellLoc.heap 11 3 ∈ SW)
    (mem₀ : ArithRAMMemory) (hc₀ : CleanMem mem₀)
    (hw_m : wRead mem₀ 1 1 = (m : ℤ)) :
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp computeLmStmt mem₀ mem₁ (35 * L_m m + 25) ∧
      extraCells SW SR mem₁ ≤ extraCells SW SR mem₀ ∧
      wRead mem₁ 11 2 = (L_m m : ℤ) ∧
      (∀ t i, t ≠ 11 → wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ t i, rRead mem₁ t i = rRead mem₀ t i) := by
  rcases L_m_bounds hm with ⟨hL1, _, hm_lt, hmin, _, _⟩
  rcases exec_wSet_sw SW SR inp hc₀ 11 (.lit 2) 2 h11_2 (.lit 1) 1 5
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m1, s1, hex1, hw1_2, hw1_ne, hr1⟩
  rcases exec_wSet_sw SW SR inp s1.2.1 11 (.lit 3) 3 h11_3 (.lit 2) 2 5
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m2, s2, hex2, hw2_3, hw2_ne, hr2⟩
  let K := L_m m - 1
  let Inv : ℕ → ArithRAMMemory → Prop := fun j mem =>
    extraCells SW SR mem ≤ extraCells SW SR mem₀ ∧
    wRead mem 11 2 = ((j + 1 : ℕ) : ℤ) ∧
    wRead mem 11 3 = ((2 ^ (j + 1) : ℕ) : ℤ) ∧
    (∀ t i, t ≠ 11 → wRead mem t i = wRead mem₀ t i) ∧
    (∀ t i, rRead mem t i = rRead mem₀ t i)
  have hInv0 : Inv 0 m2 := ⟨by omega,
    (hw2_ne 11 2 (Or.inr (by decide))).trans hw1_2,
    by simpa using hw2_3,
    fun t i ht => (hw2_ne t i (Or.inl ht)).trans (hw1_ne t i (Or.inl ht)),
    fun t i => (hr2 t i).trans (hr1 t i)⟩
  rcases ExecStmt.whileLoop_nat (cond := .intLe (.readHeap 11 (.lit 3)) (.readHeap 1 (.lit 1)))
    K 10 25 Inv s2.2.1 hInv0
    (fun j hj mem hcm ⟨hex, hw2, hw3, hw_ne, hr_eq⟩ => by
      have hle_j : 2 ^ (j + 1) ≤ m := hmin j hj
      have hw3_r : mem.words.read (.heap 11 3) = ((2 ^ (j + 1) : ℕ) : ℤ) := hw3
      have hwm_r : mem.words.read (.heap 1 1) = (m : ℤ) :=
        (hw_ne 1 1 (by decide)).trans hw_m
      refine ⟨evalCond_true inp mem (.intLe (.readHeap 11 (.lit 3)) (.readHeap 1 (.lit 1))) 10
        (by simp [evalArithCond, evalIntExpr, hw3_r, hwm_r]; exact_mod_cast hle_j)
        (by simp [evalArithCond, evalIntExpr]), ?_⟩
      rcases exec_wSet_sw SW SR inp hcm 11 (.lit 3) 3 h11_3
        (.mul (.lit 2) (.readHeap 11 (.lit 3))) ((2 ^ (j + 2) : ℕ) : ℤ) 12
        (by simp [evalIntExpr])
        (by simp [evalIntExpr, hw3_r, pow_succ'])
        (by simp [evalIntExpr])
        with ⟨ma, sa, hexa, hwa3, hwa_ne, hra⟩
      have hw2_a : ma.words.read (.heap 11 2) = ((j + 1 : ℕ) : ℤ) :=
        (hwa_ne 11 2 (Or.inr (by decide))).trans hw2
      rcases exec_wSet_sw SW SR inp sa.2.1 11 (.lit 2) 2 h11_2
        (.add (.readHeap 11 (.lit 2)) (.lit 1)) ((j + 2 : ℕ) : ℤ) 12
        (by simp [evalIntExpr])
        (by simp [evalIntExpr, hw2_a]; ring)
        (by simp [evalIntExpr])
        with ⟨mb, sb, hexb, hwb2, hwb_ne, hrb⟩
      exact ⟨mb, (ExecStmt.seq sa sb).mono_cost (by omega), by omega, hwb2,
        (hwb_ne 11 3 (Or.inr (by decide))).trans hwa3,
        fun t i ht => (hwb_ne t i (Or.inl ht)).trans ((hwa_ne t i (Or.inl ht)).trans (hw_ne t i ht)),
        fun t i => (hrb t i).trans ((hra t i).trans (hr_eq t i))⟩)
    (fun mem _ ⟨_, _, hw3, hw_ne, _⟩ => by
      have hK1 : K + 1 = L_m m := by omega
      have hw3_r : mem.words.read (.heap 11 3) = ((2 ^ (L_m m) : ℕ) : ℤ) := by
        rw [← hK1]; exact hw3
      have hwm_r : mem.words.read (.heap 1 1) = (m : ℤ) :=
        (hw_ne 1 1 (by decide)).trans hw_m
      exact evalCond_false inp mem (.intLe (.readHeap 11 (.lit 3)) (.readHeap 1 (.lit 1))) 10
        (by simp [evalArithCond, evalIntExpr, hw3_r, hwm_r]; exact_mod_cast hm_lt)
        (by simp [evalArithCond, evalIntExpr]))
    with ⟨mem₁, ⟨hex_f, hw2_f, _, hw_ne_f, hr_f⟩, sLoop⟩
  have hK1 : (K + 1 : ℕ) = L_m m := by omega
  rw [hK1] at hw2_f
  refine ⟨mem₁, ?_, hex_f, hw2_f, hw_ne_f, hr_f⟩
  unfold computeLmStmt seqStmts
  exact (ExecStmt.seq s1 (ExecStmt.seq s2 sLoop)).mono_cost (by omega)

theorem exec_computeTStmt {d : ℕ} (inp : ArithRAMInput d)
    {ℓ m : ℕ} (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m)
    (SW SR : Finset RAMCellLoc)
    (h11_5 : RAMCellLoc.heap 11 5 ∈ SW)
    (h17_0 : RAMCellLoc.heap 17 0 ∈ SR) (h17_1 : RAMCellLoc.heap 17 1 ∈ SR)
    (mem₀ : ArithRAMMemory) (hc₀ : CleanMem mem₀)
    (hw_m : wRead mem₀ 1 1 = (m : ℤ))
    (hw_L : wRead mem₀ 11 2 = (L_m m : ℤ))
    (hw_N : wRead mem₀ 11 4 = (N_pow ℓ m : ℤ)) :
    let k := kStar ℓ m hℓ hm
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp (computeTStmt ℓ) mem₀ mem₁ ((k + 3) * (70 + N_pow ℓ m * 20)) ∧
      extraCells SW SR mem₁ ≤ extraCells SW SR mem₀ ∧
      wRead mem₁ 11 5 = (k : ℤ) ∧
      wRead mem₁ 11 2 = (L_m m : ℤ) ∧
      wRead mem₁ 11 4 = (N_pow ℓ m : ℤ) ∧
      rRead mem₁ 17 1 = polyExp (N_pow ℓ m) ((ℓ : ℝ) * (tParam ℓ m hℓ hm) ^ 2 / 2) ∧
      (∀ t i, (t ≠ 11 ∨ i ≠ 5) → wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ t i, t ≠ 17 → rRead mem₁ t i = rRead mem₀ t i) := by
  dsimp only
  rcases tParam_bounds hℓ hm with ⟨_, hk_min, hk_spec, _, _, _, _, _⟩
  let L := L_m m
  let N := N_pow ℓ m
  let k := kStar ℓ m hℓ hm
  have h17_1_sub : ({RAMCellLoc.heap 17 1} : Finset RAMCellLoc) ⊆ SR :=
    Finset.singleton_subset_iff.mpr h17_1
  -- Initial `j = 0`
  rcases exec_wSet_sw SW SR inp hc₀ 11 (.lit 5) 5 h11_5 (.lit 0) 0 5
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m1, s1, hex1, hw1_5, hw1_ne, hr1⟩
  have hwL_1 : m1.words.read (.heap 11 2) = (L : ℤ) :=
    (hw1_ne 11 2 (Or.inr (by decide))).trans hw_L
  have hw5_1 : m1.words.read (.heap 11 5) = (0 : ℤ) := hw1_5
  rcases exec_rSet_sr SW SR inp s1.2.1 17 (.lit 0) 0 h17_0 (zStepRealExpr ℓ) (zStep ℓ L 0) 35
    (by simp [evalIntExpr])
    (by simp [zStepRealExpr, tStepRealExpr, evalRealExpr, evalIntExpr, hw5_1, hwL_1,
          zStep, tStep])
    (by simp [zStepRealExpr, tStepRealExpr, evalRealExpr, evalIntExpr])
    with ⟨m2, s2, hex2, hr2_0, hw2_eq, hr2_ne⟩
  have hwN_2 : wRead m2 11 4 = (N : ℤ) :=
    (hw2_eq 11 4).trans ((hw1_ne 11 4 (Or.inr (by decide))).trans hw_N)
  rcases exec_powPolyStmt inp 11 4 17 0 1 (by decide) m2 s2.2.1 hwN_2 hr2_0
    with ⟨m3, s3, hr3_1, hw3_eq, hr3_ne, hlw3, hlr3⟩
  have hex3 : extraCells SW SR m3 ≤ extraCells SW SR mem₀ := by
    have hsub : m3.reals.live ⊆ m2.reals.live ∪ {RAMCellLoc.heap 17 1} := by
      intro x hx
      rcases Finset.mem_insert.mp (hlr3 hx) with rfl | hx2
      · exact Finset.mem_union_right _ (Finset.mem_singleton_self _)
      · exact Finset.mem_union_left _ hx2
    have hle := extraCells_le_of_subset (SW := SW) (SR := SR)
      (hlw3.trans Finset.subset_union_left) (Finset.empty_subset SW) hsub h17_1_sub
    omega
  let Inv : ℕ → ArithRAMMemory → Prop := fun j mem =>
    extraCells SW SR mem ≤ extraCells SW SR mem₀ ∧
    wRead mem 11 5 = (j : ℤ) ∧
    rRead mem 17 1 = polyExp N (zStep ℓ L j) ∧
    (∀ t i, (t ≠ 11 ∨ i ≠ 5) → wRead mem t i = wRead mem₀ t i) ∧
    (∀ t i, t ≠ 17 → rRead mem t i = rRead mem₀ t i)
  have hInv0 : Inv 0 m3 := ⟨hex3,
    (hw3_eq 11 5).trans ((hw2_eq 11 5).trans hw1_5),
    hr3_1,
    fun t i hne => (hw3_eq t i).trans ((hw2_eq t i).trans (hw1_ne t i hne)),
    fun t i ht => (hr3_ne t i (Or.inl ht)).trans ((hr2_ne t i (Or.inl ht)).trans (hr1 t i))⟩
  let cond := ArithCondExpr.realLt (.readRealHeap 17 (.lit 1))
    (.mul (.ofInt (.lit 2)) (.ofInt (.readHeap 1 (.lit 1))))
  rcases ExecStmt.whileLoop_nat (cond := cond) k 15 (55 + N * 20) Inv s3.2.1 hInv0
    (fun j hj mem hcm ⟨hex, hw5, hr1_j, hw_ne, hr_ne⟩ => by
      have hlt_j : polyExp N (zStep ℓ L j) < 2 * (m : ℝ) := hk_min j hj
      have hwm_r : mem.words.read (.heap 1 1) = (m : ℤ) :=
        (hw_ne 1 1 (Or.inl (by decide))).trans hw_m
      have hr1_r : mem.reals.read (.heap 17 1) = polyExp N (zStep ℓ L j) := hr1_j
      refine ⟨evalCond_true inp mem cond 15
        (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr, hr1_r, hwm_r, hlt_j])
        (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr]), ?_⟩
      have hw5_r : mem.words.read (.heap 11 5) = (j : ℤ) := hw5
      rcases exec_wSet_sw SW SR inp hcm 11 (.lit 5) 5 h11_5
        (.add (.readHeap 11 (.lit 5)) (.lit 1)) ((j + 1 : ℕ) : ℤ) 10
        (by simp [evalIntExpr])
        (by simp [evalIntExpr, hw5_r])
        (by simp [evalIntExpr])
        with ⟨ma, sa, hexa, hwa5, hwa_ne, hra⟩
      have hwL_a : ma.words.read (.heap 11 2) = (L : ℤ) :=
        (hwa_ne 11 2 (Or.inr (by decide))).trans ((hw_ne 11 2 (Or.inr (by decide))).trans hw_L)
      have hw5_a : ma.words.read (.heap 11 5) = ((j + 1 : ℕ) : ℤ) := hwa5
      rcases exec_rSet_sr SW SR inp sa.2.1 17 (.lit 0) 0 h17_0
        (zStepRealExpr ℓ) (zStep ℓ L (j + 1)) 35
        (by simp [evalIntExpr])
        (by simp only [zStepRealExpr, tStepRealExpr, evalRealExpr, evalIntExpr, hw5_a, hwL_a,
              zStep, tStep]; push_cast; ring)
        (by simp [zStepRealExpr, tStepRealExpr, evalRealExpr, evalIntExpr])
        with ⟨mb, sb, hexb, hrb0, hwb_eq, hrb_ne⟩
      have hwN_b : wRead mb 11 4 = (N : ℤ) :=
        (hwb_eq 11 4).trans ((hwa_ne 11 4 (Or.inr (by decide))).trans
          ((hw_ne 11 4 (Or.inr (by decide))).trans hw_N))
      rcases exec_powPolyStmt inp 11 4 17 0 1 (by decide) mb sb.2.1 hwN_b hrb0
        with ⟨mc, sc, hrc1, hwc_eq, hrc_ne, hlwc, hlrc⟩
      have hexc : extraCells SW SR mc ≤ extraCells SW SR mem₀ := by
        have hsub : mc.reals.live ⊆ mb.reals.live ∪ {RAMCellLoc.heap 17 1} := by
          intro x hx
          rcases Finset.mem_insert.mp (hlrc hx) with rfl | hxb
          · exact Finset.mem_union_right _ (Finset.mem_singleton_self _)
          · exact Finset.mem_union_left _ hxb
        have hle := extraCells_le_of_subset (SW := SW) (SR := SR)
          (hlwc.trans Finset.subset_union_left) (Finset.empty_subset SW) hsub h17_1_sub
        omega
      have sBody : ExecStmt inp
          (seqStmts
            [ .writeWordHeap 11 (.lit 5) (.add (.readHeap 11 (.lit 5)) (.lit 1)),
              .writeRealHeap 17 (.lit 0) (zStepRealExpr ℓ),
              powPolyStmt 11 4 17 0 1 ]) mem mc (55 + N * 20) := by
        dsimp [seqStmts]
        exact (ExecStmt.seq sa (ExecStmt.seq sb sc)).mono_cost (by omega)
      exact ⟨mc, sBody, hexc,
        (hwc_eq 11 5).trans ((hwb_eq 11 5).trans hwa5),
        hrc1,
        fun t i hne => (hwc_eq t i).trans ((hwb_eq t i).trans ((hwa_ne t i hne).trans (hw_ne t i hne))),
        fun t i ht => (hrc_ne t i (Or.inl ht)).trans
          ((hrb_ne t i (Or.inl ht)).trans ((hra t i).trans (hr_ne t i ht)))⟩)
    (fun mem _ ⟨_, _, hr1_k, hw_ne, _⟩ => by
      have hwm_r : mem.words.read (.heap 1 1) = (m : ℤ) :=
        (hw_ne 1 1 (Or.inl (by decide))).trans hw_m
      have hr1_r : mem.reals.read (.heap 17 1) = polyExp N (zStep ℓ L k) := hr1_k
      have hk_spec' : 2 * (m : ℝ) ≤ polyExp N (zStep ℓ L k) := hk_spec
      exact evalCond_false inp mem cond 15
        (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr, hr1_r, hwm_r]; linarith [hk_spec'])
        (by simp [cond, evalArithCond, evalRealExpr, evalIntExpr]))
    with ⟨mem₁, ⟨hex_f, hw5_f, hr1_f, hw_ne_f, hr_ne_f⟩, sLoop⟩
  refine ⟨mem₁, ?_, hex_f, hw5_f,
    (hw_ne_f 11 2 (Or.inr (by decide))).trans hw_L,
    (hw_ne_f 11 4 (Or.inr (by decide))).trans hw_N,
    by simpa [zStep, tParam] using hr1_f, hw_ne_f, hr_ne_f⟩
  unfold computeTStmt seqStmts
  have hcost : 5 + (35 + ((10 + N * 20) + ((k + 1) * 15 + k * (55 + N * 20)))) ≤
      (k + 3) * (70 + N * 20) := by nlinarith
  exact (ExecStmt.seq s1 (ExecStmt.seq s2 (ExecStmt.seq s3 sLoop))).mono_cost hcost

set_option maxHeartbeats 1200000 in
theorem exec_initSeedProg
    {d ℓ m R M₀ : ℕ} (hd : 1 ≤ d) (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (hR : 1 ≤ R) (hM₀ : 1 ≤ M₀)
    {a b η : ℚ} (hη0 : 0 < η) (hη16 : (η : ℝ) ≤ 1 / 16)
    {g x c_h : ℝ} (hc_h : 0 < c_h)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hx0 : h ≤ x) (hx1 : x ≤ 1)
    (hM0_eq : M₀ = M0Param c_h ℓ m hℓ hm h x)
    (ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1))) :
    let N_caps := ℓ * M₀
    let Cap_u := capUParam c_h ℓ m hℓ hm h x
    let Cap_q := capQParam c_h ℓ m hℓ hm h x
    let t := tParam ℓ m hℓ hm
    let A := (chooseAB b η).1
    let B := (chooseAB b η).2
    let inp : ArithRAMInput d :=
      { intParams :=
          [(m : ℤ), (ℓ : ℤ), (R : ℤ), (N_caps : ℤ),
           a.num, (a.den : ℤ), b.num, (b.den : ℤ), η.num, (η.den : ℤ)]
        activeHandles := ∅
        activeCoords := fun _ => 0
        extraReals :=
          [g, x] ++
            (List.finRange R).flatMap (fun r =>
              (List.finRange N_caps).flatMap (fun c =>
                List.ofFn (fun coord : Fin (d + 1) => euclideanCoord (ω r c) coord))) }
    ∃ (mem_out : ArithRAMMemory) (C_init : ℕ),
      ExecStmt inp (initSeedProg ℓ) ArithRAMMemory.empty mem_out C_init ∧
      DataStructInv hm Cap_u Cap_q A B η x t ω ptsK ∅ ∅ 0 mem_out ∧
      (C_init : ℝ) ≤
        2000 + 40 * (L_m m : ℝ) +
        (((kStar ℓ m hℓ hm + 6 : ℕ) : ℝ) * (70 + 20 * (N_pow ℓ m : ℝ))) +
        25 * (doubleSteps (targetUVal c_h ℓ m hℓ hm h x) : ℝ) +
        25 * (doubleSteps (max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x)) : ℝ) +
        900 * Real.log ((d : ℝ) / (η : ℝ)) +
        30 * ((R * N_caps * (d + 1) : ℕ) : ℝ) := by
  dsimp only
  let N_caps := ℓ * M₀
  set Cap_u := capUParam c_h ℓ m hℓ hm h x
  set Cap_q := capQParam c_h ℓ m hℓ hm h x
  set t := tParam ℓ m hℓ hm
  set A := (chooseAB b η).1
  set B := (chooseAB b η).2
  set SW := AdaptiveSW R ℓ M₀ Cap_q d
  set SR := AdaptiveSR d R ℓ M₀
  let inp : ArithRAMInput d :=
    { intParams :=
        [(m : ℤ), (ℓ : ℤ), (R : ℤ), (N_caps : ℤ),
         a.num, (a.den : ℤ), b.num, (b.den : ℤ), η.num, (η.den : ℤ)]
      activeHandles := ∅
      activeCoords := fun _ => 0
      extraReals :=
        [g, x] ++
          (List.finRange R).flatMap (fun r =>
            (List.finRange N_caps).flatMap (fun c =>
              List.ofFn (fun coord : Fin (d + 1) => euclideanCoord (ω r c) coord))) }
  have hex_emp : extraCells SW SR ArithRAMMemory.empty = 0 := extraCells_empty SW SR
  have h17_1_sub : ({RAMCellLoc.heap 17 1} : Finset RAMCellLoc) ⊆ SR :=
    Finset.singleton_subset_iff.mpr (mem_ASR_17 (by decide))

  -- 1..6: Header word writes
  rcases exec_wSet_sw SW SR inp cleanMem_empty 1 (.lit 1) 1 (mem_ASW_1 (by decide))
    (.intParam (.lit 0)) (m : ℤ) 6
    (by simp [evalIntExpr]) (by simp [inp, evalIntExpr, listGetIntD]) (by simp [evalIntExpr])
    with ⟨m1, s1, hex1, hw1_1, hw1_ne, hr1⟩
  rcases exec_wSet_sw SW SR inp s1.2.1 1 (.lit 2) 2 (mem_ASW_1 (by decide))
    (.intParam (.lit 2)) (R : ℤ) 6
    (by simp [evalIntExpr]) (by simp [inp, evalIntExpr, listGetIntD]) (by simp [evalIntExpr])
    with ⟨m2, s2, hex2, hw2_2, hw2_ne, hr2⟩
  have hwm_2 : m2.words.read (.heap 1 1) = (m : ℤ) := (hw2_ne 1 1 (Or.inr (by decide))).trans hw1_1
  have hwR_2 : m2.words.read (.heap 1 2) = (R : ℤ) := hw2_2
  rcases exec_wSet_sw SW SR inp s2.2.1 1 (.lit 0) 0 (mem_ASW_1 (by decide))
    (.mul (.readHeap 1 (.lit 2)) (.readHeap 1 (.lit 1))) ((R * m : ℕ) : ℤ) 10
    (by simp [evalIntExpr]) (by simp [evalIntExpr, hwR_2, hwm_2]) (by simp [evalIntExpr])
    with ⟨m3, s3, hex3, hw3_0, hw3_ne, hr3⟩
  have hℓ_ne : (ℓ : ℤ) ≠ 0 := by omega
  have hdiv_M0 : (ℓ : ℤ) * (M₀ : ℤ) / (ℓ : ℤ) = (M₀ : ℤ) := Int.mul_ediv_cancel_left (M₀ : ℤ) hℓ_ne
  rcases exec_wSet_sw SW SR inp s3.2.1 1 (.lit 4) 4 (mem_ASW_1 (by decide))
    (.div (.intParam (.lit 3)) (.lit (ℓ : ℤ))) (M₀ : ℤ) 10
    (by simp [evalIntExpr])
    (by simp [inp, N_caps, evalIntExpr, listGetIntD, hdiv_M0])
    (by simp [evalIntExpr])
    with ⟨m4, s4, hex4, hw4_4, hw4_ne, hr4⟩
  rcases exec_wSet_sw SW SR inp s4.2.1 1 (.lit 7) 7 (mem_ASW_1 (by decide))
    (.intParam (.lit 8)) η.num 6
    (by simp [evalIntExpr]) (by simp [inp, evalIntExpr, listGetIntD]) (by simp [evalIntExpr])
    with ⟨m5, s5, hex5, hw5_7, hw5_ne, hr5⟩
  rcases exec_wSet_sw SW SR inp s5.2.1 1 (.lit 8) 8 (mem_ASW_1 (by decide))
    (.intParam (.lit 9)) (η.den : ℤ) 6
    (by simp [evalIntExpr]) (by simp [inp, evalIntExpr, listGetIntD]) (by simp [evalIntExpr])
    with ⟨m6, s6, hex6, hw6_8, hw6_ne, hr6⟩

  have hw4_6 : wRead m6 1 4 = (M₀ : ℤ) :=
    (hw6_ne 1 4 (Or.inr (by decide))).trans ((hw5_ne 1 4 (Or.inr (by decide))).trans hw4_4)
  rcases exec_computeM0PowStmt inp ℓ M₀ SW SR (mem_ASW_1 (by decide)) m6 s6.2.1 hw4_6
    with ⟨m7, s7, hex7, hw7_5, hw7_ne, hr7⟩

  -- Helper to extract header words of `m7`
  have hm7_hdr :
      wRead m7 1 0 = ((R * m : ℕ) : ℤ) ∧
      wRead m7 1 1 = (m : ℤ) ∧
      wRead m7 1 2 = (R : ℤ) ∧
      wRead m7 1 4 = (M₀ : ℤ) ∧
      wRead m7 1 5 = ((M₀ ^ ℓ : ℕ) : ℤ) ∧
      wRead m7 1 7 = η.num ∧
      wRead m7 1 8 = (η.den : ℤ) ∧
      (∀ t_idx i, t_idx ≠ 1 → wRead m7 t_idx i = 0) := by
    refine ⟨?_, ?_, ?_, (hw7_ne 1 4 (Or.inr (by decide))).trans hw4_6, hw7_5,
      (hw7_ne 1 7 (Or.inr (by decide))).trans ((hw6_ne 1 7 (Or.inr (by decide))).trans hw5_7),
      (hw7_ne 1 8 (Or.inr (by decide))).trans hw6_8, ?_⟩
    · exact (hw7_ne 1 0 (Or.inr (by decide))).trans ((hw6_ne 1 0 (Or.inr (by decide))).trans
        ((hw5_ne 1 0 (Or.inr (by decide))).trans ((hw4_ne 1 0 (Or.inr (by decide))).trans hw3_0)))
    · exact (hw7_ne 1 1 (Or.inr (by decide))).trans ((hw6_ne 1 1 (Or.inr (by decide))).trans
        ((hw5_ne 1 1 (Or.inr (by decide))).trans ((hw4_ne 1 1 (Or.inr (by decide))).trans
          ((hw3_ne 1 1 (Or.inr (by decide))).trans hwm_2))))
    · exact (hw7_ne 1 2 (Or.inr (by decide))).trans ((hw6_ne 1 2 (Or.inr (by decide))).trans
        ((hw5_ne 1 2 (Or.inr (by decide))).trans ((hw4_ne 1 2 (Or.inr (by decide))).trans
          ((hw3_ne 1 2 (Or.inr (by decide))).trans hw2_2))))
    · intro t_idx i ht
      rw [hw7_ne t_idx i (Or.inl ht), hw6_ne t_idx i (Or.inl ht), hw5_ne t_idx i (Or.inl ht),
          hw4_ne t_idx i (Or.inl ht), hw3_ne t_idx i (Or.inl ht), hw2_ne t_idx i (Or.inl ht),
          hw1_ne t_idx i (Or.inl ht), wRead_empty]

  -- 8..9: `computeLmStmt` and `N_pow ℓ m`
  rcases exec_computeLmStmt inp hm SW SR (mem_ASW_11 (by decide)) (mem_ASW_11 (by decide))
    m7 s7.2.1 hm7_hdr.2.1 with ⟨m8, s8, hex8, hw8_L, hw8_ne, hr8⟩
  let lE := IntExpr.readHeap 11 (.lit 2)
  let l2E := IntExpr.mul lE lE
  let l4E := IntExpr.mul l2E l2E
  have hw8_L' : m8.words.read (.heap 11 2) = (L_m m : ℤ) := hw8_L
  rcases exec_wSet_sw SW SR inp s8.2.1 11 (.lit 4) 4 (mem_ASW_11 (by decide))
    (.add (.mul (.lit ((1000 * ℓ ^ 2 : ℕ) : ℤ)) l4E) (.lit 1)) (N_pow ℓ m : ℤ) 20
    (by simp [evalIntExpr])
    (by simp only [l4E, l2E, lE, evalIntExpr, hw8_L', N_pow]; push_cast; ring)
    (by simp [l4E, l2E, lE, evalIntExpr])
    with ⟨m9, s9, hex9, hw9_N, hw9_ne, hr9⟩

  -- 10..12: `computeTStmt`, `r[1, 1] := t`, `r[1, 0] := x * t`
  have hwm_9 : wRead m9 1 1 = (m : ℤ) :=
    (hw9_ne 1 1 (Or.inl (by decide))).trans ((hw8_ne 1 1 (by decide)).trans hm7_hdr.2.1)
  have hwL_9 : wRead m9 11 2 = (L_m m : ℤ) :=
    (hw9_ne 11 2 (Or.inr (by decide))).trans hw8_L
  rcases exec_computeTStmt inp hℓ hm SW SR
    (mem_ASW_11 (by decide)) (mem_ASR_17 (by decide)) (mem_ASR_17 (by decide))
    m9 s9.2.1 hwm_9 hwL_9 hw9_N
    with ⟨m10, s10, hex10, hw10_k, hw10_L, hw10_N, hr10_poly, hw10_ne, hr10_ne⟩
  have hwk_10 : m10.words.read (.heap 11 5) = (kStar ℓ m hℓ hm : ℤ) := hw10_k
  have hwL_10 : m10.words.read (.heap 11 2) = (L_m m : ℤ) := hw10_L
  rcases exec_rSet_sr SW SR inp s10.2.1 1 (.lit 1) 1 (mem_ASR_1 (by decide))
    (tStepRealExpr ℓ) t 15
    (by simp [evalIntExpr])
    (by simp [tStepRealExpr, evalRealExpr, evalIntExpr, hwk_10, hwL_10, t, tParam, tStep])
    (by simp [tStepRealExpr, evalRealExpr, evalIntExpr])
    with ⟨m11, s11, hex11, hr11_t, hw11_eq, hr11_ne⟩
  have hrt_11 : m11.reals.read (.heap 1 1) = t := hr11_t
  rcases exec_rSet_sr SW SR inp s11.2.1 1 (.lit 0) 0 (mem_ASR_1 (by decide))
    (.mul (.extraReal (.lit 1)) (.readRealHeap 1 (.lit 1))) (x * t) 10
    (by simp [evalIntExpr])
    (by simp [inp, evalRealExpr, evalIntExpr, listGetIntD, hrt_11])
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m12, s12, hex12, hr12_xt, hw12_eq, hr12_ne⟩

  -- 13..14: `Cap_u` (`w[1, 3]`)
  have hm0Pow_12 : m12.words.read (.heap 1 5) = ((M₀ ^ ℓ : ℕ) : ℤ) := by
    change wRead m12 1 5 = _
    rw [hw12_eq, hw11_eq, hw10_ne 1 5 (Or.inl (by decide)),
        hw9_ne 1 5 (Or.inl (by decide)), hw8_ne 1 5 (by decide)]
    exact hm7_hdr.2.2.2.2.1
  have hrpoly_12 : m12.reals.read (.heap 17 1) = polyExp (N_pow ℓ m) ((ℓ : ℝ) * t ^ 2 / 2) :=
    (hr12_ne 17 1 (Or.inl (by decide))).trans ((hr11_ne 17 1 (Or.inl (by decide))).trans hr10_poly)
  rcases exec_rSet_sr SW SR inp s12.2.1 17 (.lit 2) 2 (mem_ASR_17 (by decide))
    (.mul (.ofInt (.lit 100))
      (.add (.div (.ofInt (.readHeap 1 (.lit 5))) (.readRealHeap 17 (.lit 1))) (.ofInt (.lit 1))))
    (targetUVal c_h ℓ m hℓ hm h x) 15
    (by simp [evalIntExpr])
    (by simp [evalRealExpr, evalIntExpr, hm0Pow_12, hrpoly_12, targetUVal, hM0_eq, t])
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m13, s13, hex13, hr13_tu, hw13_eq, hr13_ne⟩
  rcases exec_doubleUntilStmt inp 1 3 17 2 m13 s13.2.1 hr13_tu
    with ⟨m14, s14, hw14_Capu, hw14_ne, hr14_eq, hlw14, hlr14⟩
  have hex14 : extraCells SW SR m14 ≤ 0 := by
    have hsub : m14.words.live ⊆ m13.words.live ∪ {RAMCellLoc.heap 1 3} := by
      intro loc hloc
      rcases Finset.mem_insert.mp (hlw14 hloc) with rfl | h13
      · exact Finset.mem_union_right _ (Finset.mem_singleton_self _)
      · exact Finset.mem_union_left _ h13
    have hle := extraCells_le_of_subset (SW := SW) (SR := SR) hsub
      (Finset.singleton_subset_iff.mpr (mem_ASW_1 (by decide)))
      (hlr14.trans Finset.subset_union_left) (Finset.empty_subset SR)
    omega

  -- 15..22: `Cap_q` (`w[1, 6]`)
  have hrxt_14 : m14.reals.read (.heap 1 0) = x * t :=
    (hr14_eq 1 0).trans ((hr13_ne 1 0 (Or.inl (by decide))).trans hr12_xt)
  rcases exec_rSet_sr SW SR inp s14.2.1 17 (.lit 0) 0 (mem_ASR_17 (by decide))
    (.div (.mul (.ofInt (.lit (ℓ : ℤ))) (.mul (.readRealHeap 1 (.lit 0)) (.readRealHeap 1 (.lit 0))))
      (.ofInt (.lit 2)))
    ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2) 15
    (by simp [evalIntExpr])
    (by simp [evalRealExpr, evalIntExpr, hrxt_14]; ring)
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m15, s15, hex15, hr15_zq, hw15_eq, hr15_ne⟩
  have hwN_15 : wRead m15 11 4 = (N_pow ℓ m : ℤ) := by
    rw [hw15_eq, hw14_ne 11 4 (Or.inl (by decide)), hw13_eq, hw12_eq, hw11_eq]
    exact hw10_N
  rcases exec_powPolyStmt inp 11 4 17 0 1 (by decide) m15 s15.2.1 hwN_15 hr15_zq
    with ⟨m16, s16, hr16_pq, hw16_eq, hr16_ne, hlw16, hlr16⟩
  have hex16 : extraCells SW SR m16 ≤ 0 := by
    have hsub : m16.reals.live ⊆ m15.reals.live ∪ {RAMCellLoc.heap 17 1} := by
      intro loc hloc
      rcases Finset.mem_insert.mp (hlr16 hloc) with rfl | h15
      · exact Finset.mem_union_right _ (Finset.mem_singleton_self _)
      · exact Finset.mem_union_left _ h15
    have hle := extraCells_le_of_subset (SW := SW) (SR := SR)
      (hlw16.trans Finset.subset_union_left) (Finset.empty_subset SW) hsub h17_1_sub
    omega
  have hm0Pow_16 : m16.words.read (.heap 1 5) = ((M₀ ^ ℓ : ℕ) : ℤ) := by
    change wRead m16 1 5 = _
    rw [hw16_eq, hw15_eq, hw14_ne 1 5 (Or.inr (by decide)), hw13_eq]
    exact hm0Pow_12
  have hrpq_16 : m16.reals.read (.heap 17 1) = polyExp (N_pow ℓ m) ((ℓ : ℝ) * x ^ 2 * t ^ 2 / 2) :=
    hr16_pq
  rcases exec_rSet_sr SW SR inp s16.2.1 17 (.lit 2) 2 (mem_ASR_17 (by decide))
    (.mul (.ofInt (.lit 100))
      (.add (.div (.ofInt (.readHeap 1 (.lit 5))) (.readRealHeap 17 (.lit 1))) (.ofInt (.lit 1))))
    (targetQ1Val c_h ℓ m hℓ hm h x) 15
    (by simp [evalIntExpr])
    (by simp [evalRealExpr, evalIntExpr, hm0Pow_16, hrpq_16, targetQ1Val, hM0_eq, t])
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m17, s17, hex17, hr17_tq1, hw17_eq, hr17_ne⟩

  have hrt_17 : m17.reals.read (.heap 1 1) = t := by
    change rRead m17 1 1 = t
    rw [hr17_ne 1 1 (Or.inl (by decide)), hr16_ne 1 1 (Or.inl (by decide)),
        hr15_ne 1 1 (Or.inl (by decide)), hr14_eq, hr13_ne 1 1 (Or.inl (by decide)),
        hr12_ne 1 1 (Or.inr (by decide))]
    exact hr11_t
  have hrxt_17 : m17.reals.read (.heap 1 0) = x * t := by
    change rRead m17 1 0 = x * t
    rw [hr17_ne 1 0 (Or.inl (by decide)), hr16_ne 1 0 (Or.inl (by decide)),
        hr15_ne 1 0 (Or.inl (by decide))]
    exact hrxt_14
  rcases exec_rSet_sr SW SR inp s17.2.1 17 (.lit 0) 0 (mem_ASR_17 (by decide))
    (.div (.mul (.ofInt (.lit (ℓ : ℤ)))
      (.add (.mul (.readRealHeap 1 (.lit 1)) (.readRealHeap 1 (.lit 1)))
            (.mul (.readRealHeap 1 (.lit 0)) (.readRealHeap 1 (.lit 0)))))
      (.ofInt (.lit 2)))
    ((ℓ : ℝ) * (1 + x ^ 2) * t ^ 2 / 2) 20
    (by simp [evalIntExpr])
    (by simp [evalRealExpr, evalIntExpr, hrt_17, hrxt_17]; ring)
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m18, s18, hex18, hr18_zbad, hw18_eq, hr18_ne⟩
  have hwN_18 : wRead m18 11 4 = (N_pow ℓ m : ℤ) := by
    rw [hw18_eq, hw17_eq, hw16_eq]
    exact hwN_15
  rcases exec_powPolyStmt inp 11 4 17 0 1 (by decide) m18 s18.2.1 hwN_18 hr18_zbad
    with ⟨m19, s19, hr19_pb, hw19_eq, hr19_ne, hlw19, hlr19⟩
  have hex19 : extraCells SW SR m19 ≤ 0 := by
    have hsub : m19.reals.live ⊆ m18.reals.live ∪ {RAMCellLoc.heap 17 1} := by
      intro loc hloc
      rcases Finset.mem_insert.mp (hlr19 hloc) with rfl | h18
      · exact Finset.mem_union_right _ (Finset.mem_singleton_self _)
      · exact Finset.mem_union_left _ h18
    have hle := extraCells_le_of_subset (SW := SW) (SR := SR)
      (hlw19.trans Finset.subset_union_left) (Finset.empty_subset SW) hsub h17_1_sub
    omega
  have hwm_19 : m19.words.read (.heap 1 1) = (m : ℤ) := by
    change wRead m19 1 1 = (m : ℤ)
    rw [hw19_eq, hw18_eq, hw17_eq, hw16_eq, hw15_eq, hw14_ne 1 1 (Or.inr (by decide)),
        hw13_eq, hw12_eq, hw11_eq, hw10_ne 1 1 (Or.inl (by decide))]
    exact hwm_9
  have hm0Pow_19 : m19.words.read (.heap 1 5) = ((M₀ ^ ℓ : ℕ) : ℤ) := by
    change wRead m19 1 5 = _
    rw [hw19_eq, hw18_eq, hw17_eq]
    exact hm0Pow_16
  have hrpb_19 : m19.reals.read (.heap 17 1) =
      polyExp (N_pow ℓ m) ((ℓ : ℝ) * (1 + x ^ 2) * t ^ 2 / 2) := hr19_pb
  rcases exec_rSet_sr SW SR inp s19.2.1 17 (.lit 3) 3 (mem_ASR_17 (by decide))
    (.mul (.ofInt (.lit 100))
      (.add (.div (.mul (.ofInt (.readHeap 1 (.lit 1))) (.ofInt (.readHeap 1 (.lit 5))))
        (.readRealHeap 17 (.lit 1))) (.ofInt (.lit 1))))
    (targetQ2Val c_h ℓ m hℓ hm h x) 20
    (by simp [evalIntExpr])
    (by simp [evalRealExpr, evalIntExpr, hwm_19, hm0Pow_19, hrpb_19, targetQ2Val, hM0_eq, t])
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m20, s20, hex20, hr20_tq2, hw20_eq, hr20_ne⟩

  -- `max(targetQ1Val, targetQ2Val)` in `r[17, 4]`
  have hrtq1_20 : m20.reals.read (.heap 17 2) = targetQ1Val c_h ℓ m hℓ hm h x := by
    change rRead m20 17 2 = _
    rw [hr20_ne 17 2 (Or.inr (by decide)), hr19_ne 17 2 (Or.inr (by decide)),
        hr18_ne 17 2 (Or.inr (by decide))]
    exact hr17_tq1
  have hrtq2_20 : m20.reals.read (.heap 17 3) = targetQ2Val c_h ℓ m hℓ hm h x := hr20_tq2
  have s21_ex : ∃ m21 : ArithRAMMemory,
      ExecStmt inp
        (.ite (.realLe (.readRealHeap 17 (.lit 2)) (.readRealHeap 17 (.lit 3)))
          (.writeRealHeap 17 (.lit 4) (.readRealHeap 17 (.lit 3)))
          (.writeRealHeap 17 (.lit 4) (.readRealHeap 17 (.lit 2))))
        m20 m21 20 ∧
      extraCells SW SR m21 ≤ 0 ∧
      rRead m21 17 4 = max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x) ∧
      (∀ t_idx i, wRead m21 t_idx i = wRead m20 t_idx i) ∧
      (∀ t_idx i, t_idx ≠ 17 → rRead m21 t_idx i = rRead m20 t_idx i) := by
    by_cases hle_q : targetQ1Val c_h ℓ m hℓ hm h x ≤ targetQ2Val c_h ℓ m hℓ hm h x
    · rcases evalCond_true inp m20
        (.realLe (.readRealHeap 17 (.lit 2)) (.readRealHeap 17 (.lit 3))) 10
        (by simp [evalArithCond, evalRealExpr, evalIntExpr, hrtq1_20, hrtq2_20, hle_q])
        (by simp [evalArithCond, evalRealExpr, evalIntExpr])
        with ⟨uc, hce, huc⟩
      rcases exec_rSet_sr SW SR inp s20.2.1 17 (.lit 4) 4 (mem_ASR_17 (by decide))
        (.readRealHeap 17 (.lit 3)) (max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x)) 10
        (by simp [evalIntExpr])
        (by simp [evalRealExpr, evalIntExpr, hrtq2_20, max_eq_right hle_q])
        (by simp [evalRealExpr, evalIntExpr])
        with ⟨m21, sb, hex21, hr21, hw21, hr21_ne⟩
      exact ⟨m21, (ExecStmt.ite_true hce huc sb).mono_cost (by omega), by omega, hr21, hw21,
        fun t_idx i ht => hr21_ne t_idx i (Or.inl ht)⟩
    · have hgt_q : targetQ2Val c_h ℓ m hℓ hm h x ≤ targetQ1Val c_h ℓ m hℓ hm h x := le_of_not_ge hle_q
      rcases evalCond_false inp m20
        (.realLe (.readRealHeap 17 (.lit 2)) (.readRealHeap 17 (.lit 3))) 10
        (by simp [evalArithCond, evalRealExpr, evalIntExpr, hrtq1_20, hrtq2_20, hle_q])
        (by simp [evalArithCond, evalRealExpr, evalIntExpr])
        with ⟨uc, hce, huc⟩
      rcases exec_rSet_sr SW SR inp s20.2.1 17 (.lit 4) 4 (mem_ASR_17 (by decide))
        (.readRealHeap 17 (.lit 2)) (max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x)) 10
        (by simp [evalIntExpr])
        (by simp [evalRealExpr, evalIntExpr, hrtq1_20, max_eq_left hgt_q])
        (by simp [evalRealExpr, evalIntExpr])
        with ⟨m21, sb, hex21, hr21, hw21, hr21_ne⟩
      exact ⟨m21, (ExecStmt.ite_false hce huc sb).mono_cost (by omega), by omega, hr21, hw21,
        fun t_idx i ht => hr21_ne t_idx i (Or.inl ht)⟩
  rcases s21_ex with ⟨m21, s21, hex21, hr21_max, hw21_eq, hr21_ne⟩

  rcases exec_doubleUntilStmt inp 1 6 17 4 m21 s21.2.1 hr21_max
    with ⟨m22, s22, hw22_Capq, hw22_ne, hr22_eq, hlw22, hlr22⟩
  have hex22 : extraCells SW SR m22 ≤ 0 := by
    have hsub : m22.words.live ⊆ m21.words.live ∪ {RAMCellLoc.heap 1 6} := by
      intro loc hloc
      rcases Finset.mem_insert.mp (hlw22 hloc) with rfl | h21
      · exact Finset.mem_union_right _ (Finset.mem_singleton_self _)
      · exact Finset.mem_union_left _ h21
    have hle := extraCells_le_of_subset (SW := SW) (SR := SR) hsub
      (Finset.singleton_subset_iff.mpr (mem_ASW_1 (by decide)))
      (hlr22.trans Finset.subset_union_left) (Finset.empty_subset SR)
    omega

  -- 23..25: `bisectABStmt` and copying `(A, B)` to `r[1, 2], r[1, 3]`
  rcases exec_bisectABStmt hd (b := b) hη0 hη16 inp
    (.intParam (.lit 6)) (.intParam (.lit 7)) (.intParam (.lit 8)) (.intParam (.lit 9))
    11 17 m22 s22.2.1
    (fun ws _ =>
      let e6 := evalIntExpr inp.toWordView 0 ws (.intParam (.lit 6))
      let e7 := evalIntExpr inp.toWordView 0 ws (.intParam (.lit 7))
      let e8 := evalIntExpr inp.toWordView 0 ws (.intParam (.lit 8))
      let e9 := evalIntExpr inp.toWordView 0 ws (.intParam (.lit 9))
      ⟨⟨e6.2.1, e6.2.2, Prod.ext (by simp [inp, ArithRAMInput.toWordView, evalIntExpr, listGetIntD]) rfl,
          by simp [e6, evalIntExpr]⟩,
       ⟨e7.2.1, e7.2.2, Prod.ext (by simp [inp, ArithRAMInput.toWordView, evalIntExpr, listGetIntD]) rfl,
          by simp [e7, evalIntExpr]⟩,
       ⟨e8.2.1, e8.2.2, Prod.ext (by simp [inp, ArithRAMInput.toWordView, evalIntExpr, listGetIntD]) rfl,
          by simp [e8, evalIntExpr]⟩,
       ⟨e9.2.1, e9.2.2, Prod.ext (by simp [inp, ArithRAMInput.toWordView, evalIntExpr, listGetIntD]) rfl,
          by simp [e9, evalIntExpr]⟩⟩)
    with ⟨m23, C_ab, s23, hCab_ub, hr23_A, hr23_B, hw23_ne, _, hr23_ne, _, hlw23, hlr23⟩
  have hex23 : extraCells SW SR m23 ≤ 0 := by
    have hle := extraCells_le_of_subset (SW := SW) (SR := SR) hlw23 (rangeHeap_11_sub_ASW (by decide))
      hlr23 (rangeHeap_17_sub_ASR (by decide))
    omega
  have hr23_A' : m23.reals.read (.heap 17 2) = (A : ℝ) := hr23_A
  rcases exec_rSet_sr SW SR inp s23.2.1 1 (.lit 2) 2 (mem_ASR_1 (by decide))
    (.readRealHeap 17 (.lit 2)) (A : ℝ) 10
    (by simp [evalIntExpr]) (by simp [evalRealExpr, evalIntExpr, hr23_A'])
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m24, s24, hex24, hr24_A, hw24_eq, hr24_ne⟩
  have hr24_B' : m24.reals.read (.heap 17 3) = (B : ℝ) :=
    (hr24_ne 17 3 (Or.inl (by decide))).trans hr23_B
  rcases exec_rSet_sr SW SR inp s24.2.1 1 (.lit 3) 3 (mem_ASR_1 (by decide))
    (.readRealHeap 17 (.lit 3)) (B : ℝ) 10
    (by simp [evalIntExpr]) (by simp [evalRealExpr, evalIntExpr, hr24_B'])
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m25, s25, hex25, hr25_B, hw25_eq, hr25_ne⟩

  -- Consolidate header of `m25` before Gaussian copy loop!
  have hm25_w1 : ∀ i, i ≠ 3 → i ≠ 6 → wRead m25 1 i = wRead m7 1 i := by
    intro i hi3 hi6
    rw [hw25_eq, hw24_eq, hw23_ne 1 i (by decide), hw22_ne 1 i (Or.inr hi6), hw21_eq,
        hw20_eq, hw19_eq, hw18_eq, hw17_eq, hw16_eq, hw15_eq, hw14_ne 1 i (Or.inr hi3),
        hw13_eq, hw12_eq, hw11_eq, hw10_ne 1 i (Or.inl (by decide)),
        hw9_ne 1 i (Or.inl (by decide)), hw8_ne 1 i (by decide)]
  have hm25_w24 : ∀ b_idx : ℕ, wRead m25 24 (b_idx : ℤ) = 0 := by
    intro b_idx
    rw [hw25_eq, hw24_eq, hw23_ne 24 _ (by decide), hw22_ne 24 _ (Or.inl (by decide)),
        hw21_eq, hw20_eq, hw19_eq, hw18_eq, hw17_eq, hw16_eq, hw15_eq,
        hw14_ne 24 _ (Or.inl (by decide)), hw13_eq, hw12_eq, hw11_eq,
        hw10_ne 24 _ (Or.inl (by decide)), hw9_ne 24 _ (Or.inl (by decide)),
        hw8_ne 24 _ (by decide)]
    exact hm7_hdr.2.2.2.2.2.2.2 24 _ (by decide)
  have hm25_Capu : wRead m25 1 3 = (Cap_u : ℤ) := by
    rw [hw25_eq, hw24_eq, hw23_ne 1 3 (by decide), hw22_ne 1 3 (Or.inr (by decide)),
        hw21_eq, hw20_eq, hw19_eq, hw18_eq, hw17_eq, hw16_eq, hw15_eq]
    exact hw14_Capu
  have hm25_Capq : wRead m25 1 6 = (Cap_q : ℤ) := by
    rw [hw25_eq, hw24_eq, hw23_ne 1 6 (by decide)]
    exact hw22_Capq
  have hm25_xt : rRead m25 1 0 = x * t := by
    rw [hr25_ne 1 0 (Or.inr (by decide)), hr24_ne 1 0 (Or.inr (by decide)),
        hr23_ne 1 0 (by decide), hr22_eq, hr21_ne 1 0 (by decide),
        hr20_ne 1 0 (Or.inl (by decide)), hr19_ne 1 0 (Or.inl (by decide)),
        hr18_ne 1 0 (Or.inl (by decide))]
    exact hrxt_17
  have hm25_t : rRead m25 1 1 = t := by
    rw [hr25_ne 1 1 (Or.inr (by decide)), hr24_ne 1 1 (Or.inr (by decide)),
        hr23_ne 1 1 (by decide), hr22_eq, hr21_ne 1 1 (by decide),
        hr20_ne 1 1 (Or.inl (by decide)), hr19_ne 1 1 (Or.inl (by decide)),
        hr18_ne 1 1 (Or.inl (by decide))]
    exact hrt_17
  have hm25_A : rRead m25 1 2 = (A : ℝ) :=
    (hr25_ne 1 2 (Or.inr (by decide))).trans hr24_A

  -- 26..27: Copy `totalG = R * N_caps * (d + 1)` Gaussians into `r[2, 0 .. totalG - 1]`
  rcases exec_wSet_sw SW SR inp s25.2.1 11 (.lit 6) 6 (mem_ASW_11 (by decide))
    (.lit 0) 0 5
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m26, s26, hex26, hw26_6, hw26_ne, hr26_eq⟩
  let totalG := R * N_caps * (d + 1)
  let totalGE := IntExpr.mul (.mul (.readHeap 1 (.lit 2)) (.intParam (.lit 3))) (.add .dim (.lit 1))
  let idxE := IntExpr.readHeap 11 (.lit 6)
  have hwR_26 : m26.words.read (.heap 1 2) = (R : ℤ) := by
    change wRead m26 1 2 = (R : ℤ)
    rw [hw26_ne 1 2 (Or.inl (by decide)), hm25_w1 2 (by decide) (by decide)]
    exact hm7_hdr.2.2.1
  have hcnt_G : evalIntExpr inp.toWordView 0 m26.words totalGE =
      ((totalG : ℤ), (evalIntExpr inp.toWordView 0 m26.words totalGE).2.1,
       (evalIntExpr inp.toWordView 0 m26.words totalGE).2.2) := by
    apply Prod.ext
    · simp [totalGE, totalG, inp, evalIntExpr, listGetIntD, hwR_26]
    · rfl
  let InvG : ℕ → ArithRAMMemory → Prop := fun j mem =>
    extraCells SW SR mem ≤ 0 ∧
    wRead mem 11 6 = (j : ℤ) ∧
    (∀ q < j, rRead mem 2 (q : ℤ) = listGetIntD inp.extraReals ((2 + q : ℕ) : ℤ) 0) ∧
    (∀ t_idx i, t_idx ≠ 11 → wRead mem t_idx i = wRead m25 t_idx i) ∧
    (∀ t_idx i, t_idx ≠ 2 → rRead mem t_idx i = rRead m25 t_idx i)
  have hInvG0 : InvG 0 m26 := ⟨by omega, hw26_6, fun _ hq => by omega,
    fun t_idx i ht => hw26_ne t_idx i (Or.inl ht), fun t_idx i _ => hr26_eq t_idx i⟩
  rcases ExecStmt.repeatN_nat totalG 15 25 InvG s26.2.1 hInvG0 hcnt_G
    (by simp [totalGE, evalIntExpr])
    (fun j hj mem hcm ⟨hex, hw6, hg_prev, hw_ne, hr_ne⟩ => by
      have hj_asr : j < 2 * R * ℓ * M₀ * d + 1 := by
        have hd2 : d + 1 ≤ 2 * d := by omega
        have h1 : R * N_caps * (d + 1) ≤ R * (ℓ * M₀) * (2 * d) :=
          Nat.mul_le_mul_left _ hd2
        have h2 : R * (ℓ * M₀) * (2 * d) = 2 * R * ℓ * M₀ * d := by ring
        omega
      have hw6_r : mem.words.read (.heap 11 6) = (j : ℤ) := hw6
      rcases exec_rSet_sr SW SR inp hcm 2 idxE (j : ℤ) (mem_ASR_2 hj_asr)
        (.extraReal (.add (.lit 2) idxE)) (listGetIntD inp.extraReals ((2 + j : ℕ) : ℤ) 0) 15
        (by simp [idxE, evalIntExpr, hw6_r])
        (by simp [idxE, evalRealExpr, evalIntExpr, hw6_r])
        (by simp [idxE, evalRealExpr, evalIntExpr])
        with ⟨ma, sa, hexa, hra2, hwa_eq, hra_ne⟩
      have hw6_a : ma.words.read (.heap 11 6) = (j : ℤ) := (hwa_eq 11 6).trans hw6
      rcases exec_wSet_sw SW SR inp sa.2.1 11 (.lit 6) 6 (mem_ASW_11 (by decide))
        (.add idxE (.lit 1)) ((j + 1 : ℕ) : ℤ) 10
        (by simp [evalIntExpr])
        (by simp [idxE, evalIntExpr, hw6_a])
        (by simp [idxE, evalIntExpr])
        with ⟨mb, sb, hexb, hwb6, hwb_ne, hrb_eq⟩
      refine ⟨mb, (ExecStmt.seq sa sb).mono_cost (by omega), by omega, hwb6, ?_,
        fun t_idx i ht => (hwb_ne t_idx i (Or.inl ht)).trans ((hwa_eq t_idx i).trans (hw_ne t_idx i ht)),
        fun t_idx i ht => (hrb_eq t_idx i).trans ((hra_ne t_idx i (Or.inl ht)).trans (hr_ne t_idx i ht))⟩
      intro q hq
      rcases Nat.lt_succ_iff_lt_or_eq.mp hq with hq_lt | rfl
      · exact (hrb_eq 2 (q : ℤ)).trans
          ((hra_ne 2 (q : ℤ) (Or.inr (by omega))).trans (hg_prev q hq_lt))
      · exact (hrb_eq 2 (q : ℤ)).trans hra2)
    with ⟨mem_out, ⟨hex_out, _, hg_all, hw_out_ne, hr_out_ne⟩, sLoopG⟩

  -- Assemble `ExecStmt`, `DataStructInv`, and total cost bound
  have sTot := ExecStmt.seq s1 (ExecStmt.seq s2 (ExecStmt.seq s3 (ExecStmt.seq s4
    (ExecStmt.seq s5 (ExecStmt.seq s6 (ExecStmt.seq s7 (ExecStmt.seq s8
    (ExecStmt.seq s9 (ExecStmt.seq s10 (ExecStmt.seq s11 (ExecStmt.seq s12
    (ExecStmt.seq s13 (ExecStmt.seq s14 (ExecStmt.seq s15 (ExecStmt.seq s16
    (ExecStmt.seq s17 (ExecStmt.seq s18 (ExecStmt.seq s19 (ExecStmt.seq s20
    (ExecStmt.seq s21 (ExecStmt.seq s22 (ExecStmt.seq s23 (ExecStmt.seq s24
    (ExecStmt.seq s25 (ExecStmt.seq s26 sLoopG)))))))))))))))))))))))))
  refine ⟨mem_out, _, (by unfold initSeedProg seqStmts; exact sTot), ?_, ?_⟩
  · refine
      { clean := sLoopG.2.1
        sub_act := Finset.Subset.refl _
        extra_le := hex_out
        hdr_Rm := (hw_out_ne 1 0 (by decide)).trans
          ((hm25_w1 0 (by decide) (by decide)).trans hm7_hdr.1)
        hdr_m := (hw_out_ne 1 1 (by decide)).trans
          ((hm25_w1 1 (by decide) (by decide)).trans hm7_hdr.2.1)
        hdr_R := (hw_out_ne 1 2 (by decide)).trans
          ((hm25_w1 2 (by decide) (by decide)).trans hm7_hdr.2.2.1)
        hdr_Capu := (hw_out_ne 1 3 (by decide)).trans hm25_Capu
        hdr_M0 := (hw_out_ne 1 4 (by decide)).trans
          ((hm25_w1 4 (by decide) (by decide)).trans hm7_hdr.2.2.2.1)
        hdr_M0pow := (hw_out_ne 1 5 (by decide)).trans
          ((hm25_w1 5 (by decide) (by decide)).trans hm7_hdr.2.2.2.2.1)
        hdr_Capq := (hw_out_ne 1 6 (by decide)).trans hm25_Capq
        hdr_etaN := (hw_out_ne 1 7 (by decide)).trans
          ((hm25_w1 7 (by decide) (by decide)).trans hm7_hdr.2.2.2.2.2.1)
        hdr_etaD := (hw_out_ne 1 8 (by decide)).trans
          ((hm25_w1 8 (by decide) (by decide)).trans hm7_hdr.2.2.2.2.2.2.1)
        hdr_xt := (hr_out_ne 1 0 (by decide)).trans hm25_xt
        hdr_t := (hr_out_ne 1 1 (by decide)).trans hm25_t
        hdr_A := (hr_out_ne 1 2 (by decide)).trans hm25_A
        hdr_B := (hr_out_ne 1 3 (by decide)).trans hr25_B
        gauss := fun r c coord => by
          have hq_lt : (r.val * N_caps + c.val) * (d + 1) + coord.val < totalG := by
            dsimp [totalG]
            have hrc : r.val * N_caps + c.val < R * N_caps := by
              calc r.val * N_caps + c.val < r.val * N_caps + N_caps := Nat.add_lt_add_left c.isLt _
                _ = (r.val + 1) * N_caps := by ring
                _ ≤ R * N_caps := Nat.mul_le_mul_right _ (Nat.succ_le_of_lt r.isLt)
            calc (r.val * N_caps + c.val) * (d + 1) + coord.val
                < (r.val * N_caps + c.val) * (d + 1) + (d + 1) := Nat.add_lt_add_left coord.isLt _
              _ = (r.val * N_caps + c.val + 1) * (d + 1) := by ring
              _ ≤ (R * N_caps) * (d + 1) := Nat.mul_le_mul_right _ (Nat.succ_le_of_lt hrc)
          exact (hg_all _ hq_lt).trans (inp_seed_extraReals_gauss g x ω r c coord)
        slot_cnt := fun _ _ hj => by simp at hj
        buckets := by
          have hemp : activePairsOf Cap_u t ω ptsK Finset.univ (∅ : Finset (Fin m)) = ∅ := by
            apply Finset.eq_empty_of_forall_notMem
            rintro ⟨_, _⟩ hmem
            rcases mem_activePairsOf_iff.mp hmem with ⟨_, _, _, hj, _⟩
            exact Finset.notMem_empty _ hj
          rw [hemp]
          exact bucketInv_empty Cap_u _ (fun b_idx =>
            (hw_out_ne 24 _ (by decide)).trans (hm25_w24 b_idx)) }
  · -- Arithmetic bound on `C_init`
    have hℓ_N : (ℓ : ℝ) ≤ (N_pow ℓ m : ℝ) := by
      rcases L_m_bounds hm with ⟨hL1, _, _, _, _, _⟩
      have h1 : ℓ ≤ N_pow ℓ m := by
        unfold N_pow
        have h2 : ℓ ≤ ℓ * ℓ := Nat.le_mul_of_pos_right ℓ hℓ
        have h3 : ℓ * ℓ ≤ 1000 * (ℓ * ℓ) := Nat.le_mul_of_pos_left _ (by decide)
        have h4 : 1000 * (ℓ * ℓ) ≤ 1000 * ℓ ^ 2 * (L_m m) ^ 4 := by
          rw [show ℓ ^ 2 = ℓ * ℓ by ring]
          exact Nat.le_mul_of_pos_right _ (Nat.pow_pos hL1)
        omega
      exact_mod_cast h1
    have hN_nonneg : (0 : ℝ) ≤ (N_pow ℓ m : ℝ) := Nat.cast_nonneg _
    have h_kn_id :
        ((kStar ℓ m hℓ hm : ℝ) + 6) * (70 + 20 * (N_pow ℓ m : ℝ)) -
          (((kStar ℓ m hℓ hm : ℝ) + 3) * (70 + (N_pow ℓ m : ℝ) * 20) +
            (N_pow ℓ m : ℝ) * 20 + (N_pow ℓ m : ℝ) * 20) =
        210 + 20 * (N_pow ℓ m : ℝ) := by ring
    have h_du : (0 : ℝ) ≤ (doubleSteps (targetUVal c_h ℓ m hℓ hm h x) : ℝ) := Nat.cast_nonneg _
    have h_dq : (0 : ℝ) ≤ (doubleSteps (max (targetQ1Val c_h ℓ m hℓ hm h x) (targetQ2Val c_h ℓ m hℓ hm h x)) : ℝ) := Nat.cast_nonneg _
    have h_L0 : (0 : ℝ) ≤ (L_m m : ℝ) := Nat.cast_nonneg _
    have h_G0 : (0 : ℝ) ≤ (R : ℝ) * ((ℓ : ℝ) * (M₀ : ℝ)) * ((d : ℝ) + 1) := by positivity
    dsimp only [totalG, N_caps]
    push_cast
    linarith only [hCab_ub, hℓ_N, hN_nonneg, h_kn_id, h_du, h_dq, h_L0, h_G0]

end UL.Proof_clm_6_1_adaptive_RaceP32
