import Mathlib
import UL.Def.def_computation_model
import UL.Proof.lem_6_3.H1_RAM
import UL.Proof.lem_6_3.H5_Prob
import UL.Proof.clm_6_1_adaptive.H1a_Net
set_option autoImplicit false

namespace UL.Proof_clm_6_1_adaptive_RaceV30

open UL.Proof_lem_6_3 UL.Proof_clm_6_1_adaptive

/-! ### 1. Base-`M₀` Horner encoding of `ℓ`-tuples -/

/-- Prefix Horner encoding of `τ : Fin ℓ → Fin M₀` over the first `f` coordinates. -/
def encodePrefix (ℓ M₀ : ℕ) (τ : Fin ℓ → Fin M₀) : ℕ → ℕ
  | 0 => 0
  | f + 1 =>
      if hf : f < ℓ then
        encodePrefix ℓ M₀ τ f * M₀ + (τ ⟨f, hf⟩).val
      else
        encodePrefix ℓ M₀ τ f

/-- Full base-`M₀` bucket index `0 ≤ encodeTuple τ < M₀ ^ ℓ`. -/
def encodeTuple {ℓ M₀ : ℕ} (τ : Fin ℓ → Fin M₀) : ℕ :=
  encodePrefix ℓ M₀ τ ℓ

theorem encodePrefix_lt {ℓ M₀ : ℕ} (hM₀ : 1 ≤ M₀) (τ : Fin ℓ → Fin M₀) :
    ∀ f : ℕ, f ≤ ℓ → encodePrefix ℓ M₀ τ f < M₀ ^ f
  | 0, _ => by simp [encodePrefix]
  | f + 1, hf => by
      have hflt : f < ℓ := by omega
      have ih := encodePrefix_lt hM₀ τ f (by omega)
      have hdlt : (τ ⟨f, hflt⟩).val < M₀ := (τ ⟨f, hflt⟩).isLt
      simp only [encodePrefix, dif_pos hflt, pow_succ]
      have hle1 : encodePrefix ℓ M₀ τ f + 1 ≤ M₀ ^ f := ih
      calc encodePrefix ℓ M₀ τ f * M₀ + (τ ⟨f, hflt⟩).val
          < encodePrefix ℓ M₀ τ f * M₀ + M₀ := Nat.add_lt_add_left hdlt _
        _ = (encodePrefix ℓ M₀ τ f + 1) * M₀ := by ring
        _ ≤ M₀ ^ f * M₀ := Nat.mul_le_mul_right M₀ hle1

theorem encodeTuple_lt {ℓ M₀ : ℕ} (hM₀ : 1 ≤ M₀) (τ : Fin ℓ → Fin M₀) :
    encodeTuple τ < M₀ ^ ℓ :=
  encodePrefix_lt hM₀ τ ℓ le_rfl

theorem encodePrefix_inj {ℓ M₀ : ℕ} (hM₀ : 1 ≤ M₀) {τ₁ τ₂ : Fin ℓ → Fin M₀} :
    ∀ f : ℕ, f ≤ ℓ → encodePrefix ℓ M₀ τ₁ f = encodePrefix ℓ M₀ τ₂ f →
      ∀ i : ℕ, i < f → ∀ hi : i < ℓ, τ₁ ⟨i, hi⟩ = τ₂ ⟨i, hi⟩
  | 0, _, _, i, hi, _ => absurd hi (Nat.not_lt_zero _)
  | f + 1, hf, heq, i, hi_lt, hi_ℓ => by
      have hflt : f < ℓ := by omega
      simp only [encodePrefix, dif_pos hflt] at heq
      have hd₁ : (τ₁ ⟨f, hflt⟩).val < M₀ := (τ₁ ⟨f, hflt⟩).isLt
      have hd₂ : (τ₂ ⟨f, hflt⟩).val < M₀ := (τ₂ ⟨f, hflt⟩).isLt
      have hmod : (τ₁ ⟨f, hflt⟩).val = (τ₂ ⟨f, hflt⟩).val := by
        have hm := congrArg (· % M₀) heq
        dsimp only at hm
        rw [Nat.mul_comm _ M₀, Nat.mul_add_mod, Nat.mod_eq_of_lt hd₁,
            Nat.mul_comm _ M₀, Nat.mul_add_mod, Nat.mod_eq_of_lt hd₂] at hm
        exact hm
      have hdiv : encodePrefix ℓ M₀ τ₁ f = encodePrefix ℓ M₀ τ₂ f := by
        have hq := congrArg (· / M₀) heq
        dsimp only at hq
        rw [Nat.mul_comm _ M₀, Nat.mul_add_div hM₀, Nat.div_eq_of_lt hd₁, Nat.add_zero,
            Nat.mul_comm _ M₀, Nat.mul_add_div hM₀, Nat.div_eq_of_lt hd₂, Nat.add_zero] at hq
        exact hq
      by_cases hif : i = f
      · subst hif
        exact Fin.ext hmod
      · exact encodePrefix_inj hM₀ f (by omega) hdiv i (by omega) hi_ℓ

theorem encodeTuple_injective {ℓ M₀ : ℕ} (hM₀ : 1 ≤ M₀) :
    Function.Injective (@encodeTuple ℓ M₀) := by
  intro τ₁ τ₂ heq
  funext c
  exact encodePrefix_inj hM₀ ℓ le_rfl heq c.val c.isLt c.isLt

/-! ### 2. Sorted hit lists, mixed-radix enumeration, and capped product -/

/-- Strictly increasing list of indices `< min n M₀` satisfying `P : Fin M₀ → Prop`. -/
def hitPrefix {M₀ : ℕ} (P : Fin M₀ → Prop) [DecidablePred P] : ℕ → List (Fin M₀)
  | 0 => []
  | s + 1 =>
      if hs : s < M₀ then
        if P ⟨s, hs⟩ then hitPrefix P s ++ [⟨s, hs⟩] else hitPrefix P s
      else
        hitPrefix P s

/-- Full list of passing indices in `Fin M₀` in increasing order. -/
def hitList {M₀ : ℕ} (P : Fin M₀ → Prop) [DecidablePred P] : List (Fin M₀) :=
  hitPrefix P M₀

theorem mem_hitPrefix {M₀ : ℕ} (P : Fin M₀ → Prop) [DecidablePred P] :
    ∀ (n : ℕ) (x : Fin M₀), x ∈ hitPrefix P n ↔ x.val < n ∧ P x
  | 0, x => by simp [hitPrefix]
  | s + 1, x => by
      by_cases hs : s < M₀
      · by_cases hp : P ⟨s, hs⟩
        · simp only [hitPrefix, dif_pos hs, if_pos hp, List.mem_append, List.mem_singleton]
          rw [mem_hitPrefix P s x]
          constructor
          · rintro (⟨hlt, hpx⟩ | rfl)
            · exact ⟨by omega, hpx⟩
            · exact ⟨Nat.lt_succ_self s, hp⟩
          · rintro ⟨hlt, hpx⟩
            by_cases heq : x.val = s
            · exact Or.inr (Fin.ext heq)
            · exact Or.inl ⟨by omega, hpx⟩
        · simp only [hitPrefix, dif_pos hs, if_neg hp]
          rw [mem_hitPrefix P s x]
          constructor
          · rintro ⟨hlt, hpx⟩; exact ⟨by omega, hpx⟩
          · rintro ⟨hlt, hpx⟩
            have hne : x.val ≠ s := fun heq => hp ((Fin.ext heq : x = ⟨s, hs⟩) ▸ hpx)
            exact ⟨by omega, hpx⟩
      · simp only [hitPrefix, dif_neg hs]
        rw [mem_hitPrefix P s x]
        have hxs : x.val < s := by have := x.isLt; omega
        exact ⟨fun ⟨_, hp⟩ => ⟨ by omega, hp⟩, fun ⟨_, hp⟩ => ⟨hxs, hp⟩⟩

theorem mem_hitList {M₀ : ℕ} (P : Fin M₀ → Prop) [DecidablePred P] (x : Fin M₀) :
    x ∈ hitList P ↔ P x := by
  unfold hitList
  rw [mem_hitPrefix]
  exact ⟨fun h => h.2, fun hp => ⟨x.isLt, hp⟩⟩

theorem hitPrefix_nodup {M₀ : ℕ} (P : Fin M₀ → Prop) [DecidablePred P] :
    ∀ n : ℕ, (hitPrefix P n).Nodup
  | 0 => List.nodup_nil
  | s + 1 => by
      by_cases hs : s < M₀
      · by_cases hp : P ⟨s, hs⟩
        · simp only [hitPrefix, dif_pos hs, if_pos hp]
          rw [List.nodup_append]
          refine ⟨hitPrefix_nodup P s, List.nodup_singleton _, fun x hx y hy => ?_⟩
          rw [List.mem_singleton] at hy
          subst hy
          have hxlt := (mem_hitPrefix P s x).mp hx
          intro heq
          rw [heq] at hxlt
          exact Nat.lt_irrefl s hxlt.1
        · simp only [hitPrefix, dif_pos hs, if_neg hp]
          exact hitPrefix_nodup P s
      · simp only [hitPrefix, dif_neg hs]
        exact hitPrefix_nodup P s

theorem hitList_nodup {M₀ : ℕ} (P : Fin M₀ → Prop) [DecidablePred P] :
    (hitList P).Nodup :=
  hitPrefix_nodup P M₀

theorem hitPrefix_length_le {M₀ : ℕ} (P : Fin M₀ → Prop) [DecidablePred P] :
    ∀ n : ℕ, (hitPrefix P n).length ≤ n
  | 0 => by simp [hitPrefix]
  | s + 1 => by
      have ih := hitPrefix_length_le P s
      by_cases hs : s < M₀
      · by_cases hp : P ⟨s, hs⟩
        · simp [hitPrefix, dif_pos hs, if_pos hp]; omega
        · simp [hitPrefix, dif_pos hs, if_neg hp]; omega
      · simp [hitPrefix, dif_neg hs]; omega

theorem hitList_length_le {M₀ : ℕ} (P : Fin M₀ → Prop) [DecidablePred P] :
    (hitList P).length ≤ M₀ :=
  hitPrefix_length_le P M₀

theorem hitList_length_eq_card {M₀ : ℕ} (P : Fin M₀ → Prop) [DecidablePred P] :
    (hitList P).length = (Finset.univ.filter P).card := by
  have hto : (hitList P).toFinset = Finset.univ.filter P := by
    ext x
    simp [mem_hitList]
  rw [← hto, List.toFinset_card_of_nodup (hitList_nodup P)]

/-- Prefix product `∏_{i < f} cnt i`. -/
def prefixProd (cnt : ℕ → ℕ) : ℕ → ℕ
  | 0 => 1
  | f + 1 => prefixProd cnt f * cnt f

/-- Capped prefix product accumulated via `p := min Cap (p * cnt f)` starting from `1`. -/
def cappedPrefixProd (Cap : ℕ) (cnt : ℕ → ℕ) : ℕ → ℕ
  | 0 => 1
  | f + 1 => min Cap (cappedPrefixProd Cap cnt f * cnt f)

theorem min_mul_eq_min {Cap A B : ℕ} :
    min Cap (min Cap A * B) = min Cap (A * B) := by
  by_cases hB : B = 0
  · subst hB; simp
  · have hB1 : 1 ≤ B := Nat.pos_of_ne_zero hB
    by_cases hA : A ≤ Cap
    · rw [Nat.min_eq_right hA]
    · push_neg at hA
      rw [Nat.min_eq_left hA.le]
      have h1 : Cap ≤ Cap * B := Nat.le_mul_of_pos_right Cap hB1
      have h2 : Cap ≤ A * B := le_trans h1 (Nat.mul_le_mul_right B hA.le)
      rw [Nat.min_eq_left h1, Nat.min_eq_left h2]

theorem cappedPrefixProd_eq {Cap : ℕ} (hCap : 1 ≤ Cap) (cnt : ℕ → ℕ) :
    ∀ n : ℕ, cappedPrefixProd Cap cnt n = min Cap (prefixProd cnt n)
  | 0 => by simp [cappedPrefixProd, prefixProd, Nat.min_eq_right hCap]
  | f + 1 => by
      simp only [cappedPrefixProd, prefixProd, cappedPrefixProd_eq hCap cnt f]
      exact min_mul_eq_min

theorem prefixProd_eq_prod {ℓ : ℕ} (cnt : ℕ → ℕ) :
    prefixProd cnt ℓ = ∏ f : Fin ℓ, cnt f.val := by
  induction ℓ with
  | zero => simp [prefixProd]
  | succ n ih =>
      rw [prefixProd, ih, Fin.prod_univ_castSucc]
      rfl

theorem prefixProd_eq_tuple_card {ℓ M₀ : ℕ} (pass : Fin ℓ → Fin M₀ → Prop)
    [∀ f, DecidablePred (pass f)] :
    let cnt : ℕ → ℕ := fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1
    prefixProd cnt ℓ = (Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ => ∀ f, pass f (τ f))).card := by
  dsimp only
  let cnt : ℕ → ℕ := fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1
  rw [prefixProd_eq_prod]
  have hpi : Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ => ∀ f, pass f (τ f)) =
      Fintype.piFinset (fun f : Fin ℓ => Finset.univ.filter (pass f)) := by
    ext τ
    simp [Fintype.mem_piFinset]
  rw [hpi, Fintype.card_piFinset]
  refine Finset.prod_congr rfl fun f _ => ?_
  dsimp [cnt]
  rw [if_pos f.isLt, hitList_length_eq_card]

/-- Mixed-radix quotient sequence `rem_0 = k`, `rem_{f+1} = rem_f / cnt f`. -/
def remSeq (cnt : ℕ → ℕ) (k : ℕ) : ℕ → ℕ
  | 0 => k
  | f + 1 => remSeq cnt k f / cnt f

/-- Mixed-radix `f`-th digit `rem_f % cnt f`. -/
def digitAt (cnt : ℕ → ℕ) (k f : ℕ) : ℕ :=
  remSeq cnt k f % cnt f

theorem remSeq_eq_div (cnt : ℕ → ℕ) (k : ℕ) :
    ∀ n : ℕ, remSeq cnt k n = k / prefixProd cnt n
  | 0 => by simp [remSeq, prefixProd]
  | f + 1 => by
      rw [remSeq, remSeq_eq_div cnt k f, prefixProd, Nat.div_div_eq_div_mul]

theorem mixed_radix_decomp (cnt : ℕ → ℕ) (k : ℕ) :
    ∀ n : ℕ, (∑ f ∈ Finset.range n, digitAt cnt k f * prefixProd cnt f) +
      remSeq cnt k n * prefixProd cnt n = k
  | 0 => by simp [remSeq, prefixProd]
  | f + 1 => by
      have ih := mixed_radix_decomp cnt k f
      rw [Finset.sum_range_succ]
      have hdiv : remSeq cnt k f = digitAt cnt k f + cnt f * remSeq cnt k (f + 1) := by
        dsimp [digitAt, remSeq]
        exact (Nat.mod_add_div (remSeq cnt k f) (cnt f)).symm
      have hstep : digitAt cnt k f * prefixProd cnt f +
          remSeq cnt k (f + 1) * prefixProd cnt (f + 1) =
            remSeq cnt k f * prefixProd cnt f := by
        dsimp only [prefixProd]
        calc digitAt cnt k f * prefixProd cnt f + remSeq cnt k (f + 1) * (prefixProd cnt f * cnt f)
            = (digitAt cnt k f + cnt f * remSeq cnt k (f + 1)) * prefixProd cnt f := by ring
          _ = remSeq cnt k f * prefixProd cnt f := by rw [← hdiv]
      linarith

theorem prefixProd_pos_of_lt {cnt : ℕ → ℕ} {k ℓ : ℕ} (hk : k < prefixProd cnt ℓ) :
    ∀ f < ℓ, 0 < cnt f := by
  intro f hf
  by_contra hc0
  have h0 : cnt f = 0 := by omega
  have hprod0 : prefixProd cnt ℓ = 0 := by
    rw [prefixProd_eq_prod]
    exact Finset.prod_eq_zero (Finset.mem_univ (⟨f, hf⟩ : Fin ℓ)) h0
  omega

theorem digitAt_lt {cnt : ℕ → ℕ} {k ℓ : ℕ} (hk : k < prefixProd cnt ℓ) {f : ℕ} (hf : f < ℓ) :
    digitAt cnt k f < cnt f :=
  Nat.mod_lt _ (prefixProd_pos_of_lt hk f hf)

theorem digitAt_inj_of_lt {cnt : ℕ → ℕ} {k₁ k₂ ℓ : ℕ}
    (hk₁ : k₁ < prefixProd cnt ℓ) (hk₂ : k₂ < prefixProd cnt ℓ)
    (heq : ∀ f < ℓ, digitAt cnt k₁ f = digitAt cnt k₂ f) :
    k₁ = k₂ := by
  have hd₁ := mixed_radix_decomp cnt k₁ ℓ
  have hd₂ := mixed_radix_decomp cnt k₂ ℓ
  have hr₁ : remSeq cnt k₁ ℓ = 0 := by rw [remSeq_eq_div, Nat.div_eq_of_lt hk₁]
  have hr₂ : remSeq cnt k₂ ℓ = 0 := by rw [remSeq_eq_div, Nat.div_eq_of_lt hk₂]
  rw [hr₁, zero_mul, add_zero] at hd₁
  rw [hr₂, zero_mul, add_zero] at hd₂
  rw [← hd₁, ← hd₂]
  refine Finset.sum_congr rfl fun f hf => ?_
  rw [heq f (Finset.mem_range.mp hf)]

theorem mixed_radix_encode_lt (cnt d : ℕ → ℕ) :
    ∀ n : ℕ, (∀ f < n, d f < cnt f) →
      ∑ f ∈ Finset.range n, d f * prefixProd cnt f < prefixProd cnt n
  | 0, _ => by simp [prefixProd]
  | n + 1, hd => by
      have ih := mixed_radix_encode_lt cnt d n (fun f hf => hd f (by omega))
      have hdn : d n + 1 ≤ cnt n := hd n (by omega)
      rw [Finset.sum_range_succ, prefixProd]
      calc (∑ f ∈ Finset.range n, d f * prefixProd cnt f) + d n * prefixProd cnt n
          < prefixProd cnt n + d n * prefixProd cnt n := Nat.add_lt_add_right ih _
        _ = prefixProd cnt n * (d n + 1) := by ring
        _ ≤ prefixProd cnt n * cnt n := Nat.mul_le_mul_left _ hdn

theorem mixed_radix_surj {cnt : ℕ → ℕ} {ℓ : ℕ} (d : ℕ → ℕ)
    (hd : ∀ f < ℓ, d f < cnt f) :
    let k := ∑ f ∈ Finset.range ℓ, d f * prefixProd cnt f
    k < prefixProd cnt ℓ ∧ ∀ f < ℓ, digitAt cnt k f = d f := by
  dsimp only
  let k := ∑ f ∈ Finset.range ℓ, d f * prefixProd cnt f
  have hk_lt : k < prefixProd cnt ℓ := mixed_radix_encode_lt cnt d ℓ hd
  refine ⟨hk_lt, fun f₀ hf₀ => ?_⟩
  -- Split `Finset.range ℓ` at `f₀` and `f₀ + 1`:
  -- Prove by backward/prefix decomposition: for every `n` with `f₀ < n ≤ ℓ`,
  -- `∑_{f < n} d f * prefixProd cnt f = low + prefixProd cnt f₀ * (d f₀ + cnt f₀ * high)`
  have hsplit : ∀ n : ℕ, f₀ < n → n ≤ ℓ →
      ∃ high : ℕ,
        ∑ f ∈ Finset.range n, d f * prefixProd cnt f =
          (∑ f ∈ Finset.range f₀, d f * prefixProd cnt f) +
            prefixProd cnt f₀ * (d f₀ + cnt f₀ * high) := by
    intro n hfn hnℓ
    induction n with
    | zero => omega
    | succ m ih =>
        by_cases hfm : f₀ = m
        · subst hfm
          refine ⟨0, ?_⟩
          rw [Finset.sum_range_succ]; ring
        · rcases ih (by omega) (by omega) with ⟨high, hhigh⟩
          have hp_div : ∃ q : ℕ, prefixProd cnt m = prefixProd cnt (f₀ + 1) * q := by
            have hle : f₀ + 1 ≤ m := by omega
            clear hhigh ih hnℓ hfm hfn
            induction m, hle using Nat.le_induction with
            | base => exact ⟨1, by simp⟩
            | succ r _ ihr =>
                rcases ihr with ⟨q, hq⟩
                exact ⟨q * cnt r, by rw [prefixProd, hq, mul_assoc]⟩
          rcases hp_div with ⟨q, hq⟩
          refine ⟨high + d m * q, ?_⟩
          rw [Finset.sum_range_succ, hhigh, hq, prefixProd]
          ring
  rcases hsplit ℓ hf₀ le_rfl with ⟨high, hk_eq⟩
  have hlow_lt : ∑ f ∈ Finset.range f₀, d f * prefixProd cnt f < prefixProd cnt f₀ :=
    mixed_radix_encode_lt cnt d f₀ (fun i hi => hd i (by omega))
  have hp_pos : 0 < prefixProd cnt f₀ := Nat.zero_lt_of_lt hlow_lt
  have hrem_eq : remSeq cnt k f₀ = d f₀ + cnt f₀ * high := by
    rw [remSeq_eq_div]
    change (∑ f ∈ Finset.range ℓ, d f * prefixProd cnt f) / prefixProd cnt f₀ = _
    rw [hk_eq, add_comm _ (prefixProd cnt f₀ * _),
        Nat.mul_add_div hp_pos, Nat.div_eq_of_lt hlow_lt, Nat.add_zero]
  dsimp [digitAt]
  rw [hrem_eq, add_comm, Nat.mul_add_mod, Nat.mod_eq_of_lt (hd f₀ hf₀)]

/-- `k`-th passing tuple `Fin ℓ → Fin M₀` decoded from the `hitList`s of `pass`. -/
def enumTuple {ℓ M₀ : ℕ} (pass : Fin ℓ → Fin M₀ → Prop) [∀ f, DecidablePred (pass f)]
    (k : ℕ)
    (hk : k < prefixProd (fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1) ℓ) :
    Fin ℓ → Fin M₀ :=
  let cnt : ℕ → ℕ := fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1
  fun f =>
    have hlt : digitAt cnt k f.val < (hitList (pass f)).length := by
      have h := digitAt_lt hk f.isLt
      simpa [cnt, dif_pos f.isLt] using h
    (hitList (pass f))[digitAt cnt k f.val]'hlt

theorem enumTuple_valid {ℓ M₀ : ℕ} (pass : Fin ℓ → Fin M₀ → Prop) [∀ f, DecidablePred (pass f)]
    (k : ℕ)
    (hk : k < prefixProd (fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1) ℓ) :
    ∀ f : Fin ℓ, pass f (enumTuple pass k hk f) := by
  intro f
  unfold enumTuple
  exact (mem_hitList (pass f) _).mp (List.getElem_mem _)

theorem enumTuple_injective {ℓ M₀ : ℕ} (pass : Fin ℓ → Fin M₀ → Prop) [∀ f, DecidablePred (pass f)]
    {k₁ k₂ : ℕ}
    (hk₁ : k₁ < prefixProd (fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1) ℓ)
    (hk₂ : k₂ < prefixProd (fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1) ℓ)
    (heq : enumTuple pass k₁ hk₁ = enumTuple pass k₂ hk₂) :
    k₁ = k₂ := by
  refine digitAt_inj_of_lt hk₁ hk₂ fun f hf => ?_
  let ff : Fin ℓ := ⟨f, hf⟩
  have hget := congrFun heq ff
  unfold enumTuple at hget
  exact (List.Nodup.getElem_inj_iff (hitList_nodup (pass ff))).mp hget

theorem enumTuple_surjective {ℓ M₀ : ℕ} (pass : Fin ℓ → Fin M₀ → Prop) [∀ f, DecidablePred (pass f)]
    (τ : Fin ℓ → Fin M₀) (hτ : ∀ f : Fin ℓ, pass f (τ f)) :
    ∃ (k : ℕ) (hk : k < prefixProd (fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1) ℓ),
      enumTuple pass k hk = τ := by
  let cnt : ℕ → ℕ := fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1
  have hmem : ∀ f : Fin ℓ, τ f ∈ hitList (pass f) := fun f => (mem_hitList (pass f) (τ f)).mpr (hτ f)
  let d : ℕ → ℕ := fun f =>
    if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).idxOf (τ ⟨f, hf⟩) else 0
  have hd_lt : ∀ f < ℓ, d f < cnt f := by
    intro f hf
    dsimp [d, cnt]
    rw [dif_pos hf, dif_pos hf]
    exact List.idxOf_lt_length_of_mem (hmem ⟨f, hf⟩)
  rcases mixed_radix_surj d hd_lt with ⟨hk_lt, hdig⟩
  refine ⟨_, hk_lt, ?_⟩
  funext f
  have hdf : digitAt (fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1)
      (∑ i ∈ Finset.range ℓ, d i * prefixProd cnt i) f.val =
      (hitList (pass f)).idxOf (τ f) := by
    simpa [d, cnt, dif_pos f.isLt] using hdig f.val f.isLt
  dsimp only [enumTuple]
  simp only [hdf, List.getElem_idxOf]

/-! ### 3. RAM subroutines for `computeCappedProdStmt` and `decodeTupleCodeStmt` -/

/-- Computes `w[11, 8] := min Cap (∏_{f < ℓ} w[6, f])` using `w[11, 9]` as loop index,
reading `Cap = w[1, capHdrIdx]`. -/
def computeCappedProdStmt (ℓ : ℕ) (capHdrIdx : ℤ) : ArithRAMStmt :=
  let capE := IntExpr.readHeap 1 (.lit capHdrIdx)
  let pE := IntExpr.readHeap 11 (.lit 8)
  let fE := IntExpr.readHeap 11 (.lit 9)
  let prodE := IntExpr.mul pE (.readHeap 6 fE)
  seqStmts
    [ .writeWordHeap 11 (.lit 8) (.lit 1),
      .writeWordHeap 11 (.lit 9) (.lit 0),
      .repeatN (.lit (ℓ : ℤ))
        (.seq
          (.ite (.intLt capE prodE)
            (.writeWordHeap 11 (.lit 8) capE)
            (.writeWordHeap 11 (.lit 8) prodE))
          (.writeWordHeap 11 (.lit 9) (.add fE (.lit 1)))) ]

theorem exec_computeCappedProdStmt {d : ℕ} (inp : ArithRAMInput d)
    (ℓ : ℕ) (capHdrIdx : ℤ) {Cap : ℕ} (hCap : 1 ≤ Cap)
    (cnt : ℕ → ℕ)
    (mem₀ : ArithRAMMemory) (hc₀ : CleanMem mem₀)
    (hCap_read : wRead mem₀ 1 capHdrIdx = (Cap : ℤ))
    (hCnt_read : ∀ f < ℓ, wRead mem₀ 6 (f : ℤ) = (cnt f : ℤ)) :
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp (computeCappedProdStmt ℓ capHdrIdx) mem₀ mem₁ (15 + ℓ * 40) ∧
      wRead mem₁ 11 8 = ((min Cap (prefixProd cnt ℓ) : ℕ) : ℤ) ∧
      (∀ t i, t ≠ 11 → wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ i, i ≠ 8 → i ≠ 9 → wRead mem₁ 11 i = wRead mem₀ 11 i) ∧
      (∀ t i, rRead mem₁ t i = rRead mem₀ t i) ∧
      mem₁.words.live ⊆ mem₀.words.live ∪ heapRange 11 20 ∧
      mem₁.reals.live ⊆ mem₀.reals.live := by
  let W_foot := mem₀.words.live ∪ heapRange 11 20
  let Pres (m : ArithRAMMemory) : Prop :=
    (∀ t i, t ≠ 11 → wRead m t i = wRead mem₀ t i) ∧
    (∀ i, i ≠ 8 → i ≠ 9 → wRead m 11 i = wRead mem₀ 11 i) ∧
    (∀ t i, rRead m t i = rRead mem₀ t i) ∧
    m.words.live ⊆ W_foot ∧
    m.reals.live ⊆ mem₀.reals.live
  have hPres₀ : Pres mem₀ := ⟨fun _ _ _ => rfl, fun _ _ _ => rfl, fun _ _ => rfl,
    Finset.subset_union_left, Finset.Subset.refl _⟩
  have hPres8 : ∀ {m} (hp : Pres m) (v : ℤ), Pres (wWrite m 11 8 v) := fun hp v =>
    ⟨fun t i ht => (wRead_wWrite_of_ne _ v (Or.inl ht)).trans (hp.1 t i ht),
     fun i h8 h9 => (wRead_wWrite_of_ne _ v (Or.inr h8)).trans (hp.2.1 i h8 h9),
     hp.2.2.1,
     wWrite_words_live hp.2.2.2.1 v (Finset.mem_union_right _ (mem_heapRange (by omega) (by omega))),
     hp.2.2.2.2⟩
  have hPres9 : ∀ {m} (hp : Pres m) (v : ℤ), Pres (wWrite m 11 9 v) := fun hp v =>
    ⟨fun t i ht => (wRead_wWrite_of_ne _ v (Or.inl ht)).trans (hp.1 t i ht),
     fun i h8 h9 => (wRead_wWrite_of_ne _ v (Or.inr h9)).trans (hp.2.1 i h8 h9),
     hp.2.2.1,
     wWrite_words_live hp.2.2.2.1 v (Finset.mem_union_right _ (mem_heapRange (by omega) (by omega))),
     hp.2.2.2.2⟩

  let m1 := wWrite mem₀ 11 8 1
  have s1 := exec_wSet_lit inp hc₀ 11 8 (.lit 1) 5 (by simp [evalIntExpr])
  let m2 := wWrite m1 11 9 0
  have s2 := exec_wSet_lit inp s1.2.1 11 9 (.lit 0) 5 (by simp [evalIntExpr])
  have hPres2 : Pres m2 := hPres9 (hPres8 hPres₀ 1) 0

  let capE := IntExpr.readHeap 1 (.lit capHdrIdx)
  let pE := IntExpr.readHeap 11 (.lit 8)
  let fE := IntExpr.readHeap 11 (.lit 9)
  let prodE := IntExpr.mul pE (.readHeap 6 fE)

  let Inv : ℕ → ArithRAMMemory → Prop := fun f m =>
    Pres m ∧
    wRead m 11 8 = ((cappedPrefixProd Cap cnt f : ℕ) : ℤ) ∧
    wRead m 11 9 = (f : ℤ)
  have hInv0 : Inv 0 m2 := ⟨hPres2,
    (wRead_wWrite_of_ne m1 _ (Or.inr (by decide))).trans (by simp [m1, cappedPrefixProd]),
    wRead_wWrite_self _ _ _ _⟩
  have hcnt_ℓ : evalIntExpr inp.toWordView 0 m2.words (.lit (ℓ : ℤ)) =
      ((ℓ : ℤ), 1, intBitLength (ℓ : ℤ)) := rfl

  rcases ExecStmt.repeatN_nat ℓ 5 40 Inv s2.2.1 hInv0 hcnt_ℓ (by omega)
    (fun f hf m hcm ⟨hpm, hwp, hwf⟩ => by
      let curP := cappedPrefixProd Cap cnt f
      have hwp' : m.words.read (.heap 11 8) = (curP : ℤ) := hwp
      have hwf' : m.words.read (.heap 11 9) = (f : ℤ) := hwf
      have hcap' : m.words.read (.heap 1 capHdrIdx) = (Cap : ℤ) :=
        (hpm.1 1 capHdrIdx (by decide)).trans hCap_read
      have hcntf' : m.words.read (.heap 6 (f : ℤ)) = (cnt f : ℤ) :=
        (hpm.1 6 (f : ℤ) (by decide)).trans (hCnt_read f hf)
      let nextP := cappedPrefixProd Cap cnt (f + 1)
      by_cases hlt : Cap < curP * cnt f
      · have hlt_z : (Cap : ℤ) < (curP : ℤ) * (cnt f : ℤ) := by exact_mod_cast hlt
        rcases evalCond_true inp m (.intLt capE prodE) 15
          (by simp [evalArithCond, evalIntExpr, capE, prodE, pE, fE, hcap', hwp', hwf', hcntf', hlt_z])
          (by simp only [evalArithCond, evalIntExpr, capE, prodE, pE, fE]; omega)
          with ⟨uc, hce, huc⟩
        have sbr : ExecStmt inp (.writeWordHeap 11 (.lit 8) capE) m (wWrite m 11 8 (nextP : ℤ)) 10 := by
          have hs := exec_wSet_lit inp hcm 11 8 capE 10 (by simp [evalIntExpr, capE])
          have hv : (evalIntExpr inp.toWordView 0 m.words capE).1 = (nextP : ℤ) := by
            have hn : nextP = Cap := by dsimp [nextP, cappedPrefixProd, curP]; exact Nat.min_eq_left hlt.le
            simp [evalIntExpr, capE, hcap', hn]
          rw [hv] at hs; exact hs
        have site := ExecStmt.ite_true (fB := .writeWordHeap 11 (.lit 8) prodE) hce huc sbr
        let ma := wWrite m 11 8 (nextP : ℤ)
        have hwf_a : ma.words.read (.heap 11 9) = (f : ℤ) :=
          (wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hwf
        have s_inc : ExecStmt inp (.writeWordHeap 11 (.lit 9) (.add fE (.lit 1))) ma
            (wWrite ma 11 9 ((f + 1 : ℕ) : ℤ)) 10 := by
          have hs := exec_wSet_lit inp site.2.1 11 9 (.add fE (.lit 1)) 10 (by simp [evalIntExpr, fE])
          have hv : (evalIntExpr inp.toWordView 0 ma.words (.add fE (.lit 1))).1 = ((f + 1 : ℕ) : ℤ) := by
            simp [evalIntExpr, fE, hwf_a]
          rw [hv] at hs; exact hs
        let mb := wWrite ma 11 9 ((f + 1 : ℕ) : ℤ)
        exact ⟨mb, (ExecStmt.seq site s_inc).mono_cost (by omega),
          hPres9 (hPres8 hpm _) _,
          (wRead_wWrite_of_ne ma _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _),
          wRead_wWrite_self _ _ _ _⟩
      · have hge : curP * cnt f ≤ Cap := not_lt.mp hlt
        rcases evalCond_false inp m (.intLt capE prodE) 15
          (by simp [evalArithCond, evalIntExpr, capE, prodE, pE, fE, hcap', hwp', hwf', hcntf']; exact_mod_cast hge)
          (by simp only [evalArithCond, evalIntExpr, capE, prodE, pE, fE]; omega)
          with ⟨uc, hce, huc⟩
        have sbr : ExecStmt inp (.writeWordHeap 11 (.lit 8) prodE) m (wWrite m 11 8 (nextP : ℤ)) 15 := by
          have hs := exec_wSet_lit inp hcm 11 8 prodE 15 (by simp [evalIntExpr, prodE, pE, fE])
          have hv : (evalIntExpr inp.toWordView 0 m.words prodE).1 = (nextP : ℤ) := by
            have hn : nextP = curP * cnt f := by dsimp [nextP, cappedPrefixProd, curP]; exact Nat.min_eq_right hge
            simp [evalIntExpr, prodE, pE, fE, hwp', hwf', hcntf', hn]
          rw [hv] at hs; exact hs
        have site := ExecStmt.ite_false (tB := .writeWordHeap 11 (.lit 8) capE) hce huc sbr
        let ma := wWrite m 11 8 (nextP : ℤ)
        have hwf_a : ma.words.read (.heap 11 9) = (f : ℤ) :=
          (wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hwf
        have s_inc : ExecStmt inp (.writeWordHeap 11 (.lit 9) (.add fE (.lit 1))) ma
            (wWrite ma 11 9 ((f + 1 : ℕ) : ℤ)) 10 := by
          have hs := exec_wSet_lit inp site.2.1 11 9 (.add fE (.lit 1)) 10 (by simp [evalIntExpr, fE])
          have hv : (evalIntExpr inp.toWordView 0 ma.words (.add fE (.lit 1))).1 = ((f + 1 : ℕ) : ℤ) := by
            simp [evalIntExpr, fE, hwf_a]
          rw [hv] at hs; exact hs
        let mb := wWrite ma 11 9 ((f + 1 : ℕ) : ℤ)
        exact ⟨mb, (ExecStmt.seq site s_inc).mono_cost (by omega),
          hPres9 (hPres8 hpm _) _,
          (wRead_wWrite_of_ne ma _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _),
          wRead_wWrite_self _ _ _ _⟩)
    with ⟨mem₁, ⟨hPres1, hw8, _⟩, sLoop⟩

  rw [cappedPrefixProd_eq hCap cnt ℓ] at hw8
  refine ⟨mem₁, ?_, hw8, hPres1.1, hPres1.2.1, hPres1.2.2.1, hPres1.2.2.2.1, hPres1.2.2.2.2⟩
  unfold computeCappedProdStmt
  dsimp [seqStmts]
  exact (ExecStmt.seq s1 (ExecStmt.seq s2 sLoop)).mono_cost (by omega)

/-- Decodes `k = w[11, 4]` into `w[11, 11] := encodeTuple (enumTuple pass k hk)` using `M₀ = w[1, 4]`
and hit lists in Word Table `9`, scratching only `w[11, 10..13]`. -/
def decodeTupleCodeStmt (ℓ : ℕ) : ArithRAMStmt :=
  let m0E := IntExpr.readHeap 1 (.lit 4)
  let kE := IntExpr.readHeap 11 (.lit 4)
  let remE := IntExpr.readHeap 11 (.lit 10)
  let codeE := IntExpr.readHeap 11 (.lit 11)
  let fE := IntExpr.readHeap 11 (.lit 12)
  let dE := IntExpr.readHeap 11 (.lit 13)
  let cntFE := IntExpr.readHeap 6 fE
  let hitAddrE := IntExpr.add (.lit (ℓ : ℤ)) (.add (.mul fE m0E) dE)
  seqStmts
    [ .writeWordHeap 11 (.lit 10) kE,
      .writeWordHeap 11 (.lit 11) (.lit 0),
      .writeWordHeap 11 (.lit 12) (.lit 0),
      .repeatN (.lit (ℓ : ℤ))
        (seqStmts
          [ .writeWordHeap 11 (.lit 13) (.mod remE cntFE),
            .writeWordHeap 11 (.lit 10) (.div remE cntFE),
            .writeWordHeap 11 (.lit 11) (.add (.mul codeE m0E) (.readHeap 6 hitAddrE)),
            .writeWordHeap 11 (.lit 12) (.add fE (.lit 1)) ]) ]

theorem exec_decodeTupleCodeStmt {d : ℕ} (inp : ArithRAMInput d)
    {ℓ M₀ : ℕ} (pass : Fin ℓ → Fin M₀ → Prop) [∀ f, DecidablePred (pass f)]
    (k : ℕ)
    (hk : k < prefixProd (fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1) ℓ)
    (mem₀ : ArithRAMMemory) (hc₀ : CleanMem mem₀)
    (hM0_read : wRead mem₀ 1 4 = (M₀ : ℤ))
    (hk_read : wRead mem₀ 11 4 = (k : ℤ))
    (hCnt_read : ∀ f : Fin ℓ, wRead mem₀ 6 (f.val : ℤ) = ((hitList (pass f)).length : ℤ))
    (hHit_read : ∀ (f : Fin ℓ) (idx : ℕ) (hidx : idx < (hitList (pass f)).length),
      wRead mem₀ 6 ((ℓ + f.val * M₀ + idx : ℕ) : ℤ) = (((hitList (pass f))[idx]'hidx).val : ℤ)) :
    ∃ mem₁ : ArithRAMMemory,
      ExecStmt inp (decodeTupleCodeStmt ℓ) mem₀ mem₁ (25 + ℓ * 60) ∧
      wRead mem₁ 11 11 = (encodeTuple (enumTuple pass k hk) : ℤ) ∧
      (∀ t i, t ≠ 11 → wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ i, (i < 10 ∨ 13 < i) → wRead mem₁ 11 i = wRead mem₀ 11 i) ∧
      (∀ t i, rRead mem₁ t i = rRead mem₀ t i) ∧
      mem₁.words.live ⊆ mem₀.words.live ∪ heapRange 11 20 ∧
      mem₁.reals.live ⊆ mem₀.reals.live := by
  let cnt : ℕ → ℕ := fun f => if hf : f < ℓ then (hitList (pass ⟨f, hf⟩)).length else 1
  let τ := enumTuple pass k hk
  let W_foot := mem₀.words.live ∪ heapRange 11 20
  let Pres (m : ArithRAMMemory) : Prop :=
    (∀ t i, t ≠ 11 → wRead m t i = wRead mem₀ t i) ∧
    (∀ i, (i < 10 ∨ 13 < i) → wRead m 11 i = wRead mem₀ 11 i) ∧
    (∀ t i, rRead m t i = rRead mem₀ t i) ∧
    m.words.live ⊆ W_foot ∧
    m.reals.live ⊆ mem₀.reals.live
  have hPres₀ : Pres mem₀ := ⟨fun _ _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl,
    Finset.subset_union_left, Finset.Subset.refl _⟩
  have hPres10 : ∀ {m} (hp : Pres m) (idx : ℤ), (10 ≤ idx ∧ idx ≤ 13) → ∀ v, Pres (wWrite m 11 idx v) := by
    intro m hp idx hidx v
    refine ⟨fun t i ht => (wRead_wWrite_of_ne m v (Or.inl ht)).trans (hp.1 t i ht),
      fun i hi => (wRead_wWrite_of_ne m v (Or.inr (by omega))).trans (hp.2.1 i hi),
      hp.2.2.1,
      wWrite_words_live hp.2.2.2.1 v (Finset.mem_union_right _ (mem_heapRange (by omega) (by omega))),
      hp.2.2.2.2⟩

  let kE := IntExpr.readHeap 11 (.lit 4)
  have hk0 : mem₀.words.read (.heap 11 4) = (k : ℤ) := hk_read
  let m1 := wWrite mem₀ 11 10 (k : ℤ)
  have s1 : ExecStmt inp (.writeWordHeap 11 (.lit 10) kE) mem₀ m1 5 := by
    have hs := exec_wSet_lit inp hc₀ 11 10 kE 5 (by simp [evalIntExpr, kE])
    have hv : (evalIntExpr inp.toWordView 0 mem₀.words kE).1 = (k : ℤ) := by simp [evalIntExpr, kE, hk0]
    rw [hv] at hs; exact hs
  let m2 := wWrite m1 11 11 0
  have s2 := exec_wSet_lit inp s1.2.1 11 11 (.lit 0) 5 (by simp [evalIntExpr])
  let m3 := wWrite m2 11 12 0
  have s3 := exec_wSet_lit inp s2.2.1 11 12 (.lit 0) 5 (by simp [evalIntExpr])
  have hPres3 : Pres m3 :=
    hPres10 (hPres10 (hPres10 hPres₀ 10 ⟨by omega, by omega⟩ (k : ℤ)) 11 ⟨by omega, by omega⟩ 0)
      12 ⟨by omega, by omega⟩ 0

  let m0E := IntExpr.readHeap 1 (.lit 4)
  let remE := IntExpr.readHeap 11 (.lit 10)
  let codeE := IntExpr.readHeap 11 (.lit 11)
  let fE := IntExpr.readHeap 11 (.lit 12)
  let dE := IntExpr.readHeap 11 (.lit 13)
  let cntFE := IntExpr.readHeap 6 fE
  let hitAddrE := IntExpr.add (.lit (ℓ : ℤ)) (.add (.mul fE m0E) dE)

  let Inv : ℕ → ArithRAMMemory → Prop := fun f m =>
    Pres m ∧
    wRead m 11 10 = (remSeq cnt k f : ℤ) ∧
    wRead m 11 11 = (encodePrefix ℓ M₀ τ f : ℤ) ∧
    wRead m 11 12 = (f : ℤ)
  have hInv0 : Inv 0 m3 := ⟨hPres3,
    (wRead_wWrite_of_ne m2 _ (Or.inr (by decide))).trans
      ((wRead_wWrite_of_ne m1 _ (Or.inr (by decide))).trans (by simp [m1, remSeq])),
    (wRead_wWrite_of_ne m2 _ (Or.inr (by decide))).trans (by simp [m2, encodePrefix]),
    wRead_wWrite_self _ _ _ _⟩
  have hcnt_ℓ : evalIntExpr inp.toWordView 0 m3.words (.lit (ℓ : ℤ)) =
      ((ℓ : ℤ), 1, intBitLength (ℓ : ℤ)) := rfl

  rcases ExecStmt.repeatN_nat ℓ 5 60 Inv s3.2.1 hInv0 hcnt_ℓ (by omega)
    (fun f hf m hcm ⟨hpm, hw10, hw11, hw12⟩ => by
      let ff : Fin ℓ := ⟨f, hf⟩
      have hw10' : m.words.read (.heap 11 10) = (remSeq cnt k f : ℤ) := hw10
      have hw11' : m.words.read (.heap 11 11) = (encodePrefix ℓ M₀ τ f : ℤ) := hw11
      have hw12' : m.words.read (.heap 11 12) = (f : ℤ) := hw12
      have hcnt_f_eq : cnt f = (hitList (pass ff)).length := dif_pos hf
      have hcnt9' : m.words.read (.heap 6 (f : ℤ)) = (cnt f : ℤ) := by
        rw [hcnt_f_eq]
        exact (hpm.1 6 (f : ℤ) (by decide)).trans (hCnt_read ff)
      let dig := digitAt cnt k f
      have hdig_lt : dig < (hitList (pass ff)).length := by
        rw [← hcnt_f_eq]; exact digitAt_lt hk hf

      -- 1. `w[11, 13] := rem % cnt f`
      let ma := wWrite m 11 13 (dig : ℤ)
      have sa : ExecStmt inp (.writeWordHeap 11 (.lit 13) (.mod remE cntFE)) m ma 15 := by
        have hs := exec_wSet_lit inp hcm 11 13 (.mod remE cntFE) 15
          (by simp [evalIntExpr, remE, cntFE, fE])
        have hv : (evalIntExpr inp.toWordView 0 m.words (.mod remE cntFE)).1 = (dig : ℤ) := by
          simp only [evalIntExpr, remE, cntFE, fE, hw10', hw12', hcnt9', dig, digitAt]
          exact Int.natCast_mod (remSeq cnt k f) (cnt f)
        rw [hv] at hs; exact hs

      -- 2. `w[11, 10] := rem / cnt f`
      have hw10_a : ma.words.read (.heap 11 10) = (remSeq cnt k f : ℤ) :=
        (wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hw10
      have hw12_a : ma.words.read (.heap 11 12) = (f : ℤ) :=
        (wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hw12
      have hcnt9_a : ma.words.read (.heap 6 (f : ℤ)) = (cnt f : ℤ) :=
        (wRead_wWrite_of_ne m _ (Or.inl (by decide))).trans hcnt9'
      let mb := wWrite ma 11 10 (remSeq cnt k (f + 1) : ℤ)
      have sb : ExecStmt inp (.writeWordHeap 11 (.lit 10) (.div remE cntFE)) ma mb 15 := by
        have hs := exec_wSet_lit inp sa.2.1 11 10 (.div remE cntFE) 15
          (by simp [evalIntExpr, remE, cntFE, fE])
        have hv : (evalIntExpr inp.toWordView 0 ma.words (.div remE cntFE)).1 =
            (remSeq cnt k (f + 1) : ℤ) := by
          simp only [evalIntExpr, remE, cntFE, fE, hw10_a, hw12_a, hcnt9_a, remSeq]
          exact Int.natCast_div (remSeq cnt k f) (cnt f)
        rw [hv] at hs; exact hs

      -- 3. `w[11, 11] := code * M₀ + w[6, ℓ + f * M₀ + dig]`
      have hw11_b : mb.words.read (.heap 11 11) = (encodePrefix ℓ M₀ τ f : ℤ) :=
        (wRead_wWrite_of_ne ma _ (Or.inr (by decide))).trans
          ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hw11)
      have hw12_b : mb.words.read (.heap 11 12) = (f : ℤ) :=
        (wRead_wWrite_of_ne ma _ (Or.inr (by decide))).trans hw12_a
      have hw13_b : mb.words.read (.heap 11 13) = (dig : ℤ) :=
        (wRead_wWrite_of_ne ma _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _)
      have hm0_b : mb.words.read (.heap 1 4) = (M₀ : ℤ) :=
        (wRead_wWrite_of_ne ma _ (Or.inl (by decide))).trans
          ((wRead_wWrite_of_ne m _ (Or.inl (by decide))).trans
            ((hpm.1 1 4 (by decide)).trans hM0_read))
      have hhit_b : mb.words.read (.heap 6 ((ℓ : ℤ) + ((f : ℤ) * (M₀ : ℤ) + (dig : ℤ)))) =
          ((τ ff).val : ℤ) := by
        have haddr : ((ℓ : ℤ) + ((f : ℤ) * (M₀ : ℤ) + (dig : ℤ))) =
            ((ℓ + f * M₀ + dig : ℕ) : ℤ) := by push_cast; ring
        rw [haddr]
        have hr9 : mb.words.read (.heap 6 ((ℓ + f * M₀ + dig : ℕ) : ℤ)) = ((τ ff).val : ℤ) :=
          (wRead_wWrite_of_ne ma (t₁ := 6) (i₁ := ((ℓ + f * M₀ + dig : ℕ) : ℤ)) _ (Or.inl (by decide))).trans
            ((wRead_wWrite_of_ne m (t₁ := 6) (i₁ := ((ℓ + f * M₀ + dig : ℕ) : ℤ)) _ (Or.inl (by decide))).trans
              ((hpm.1 6 _ (by decide)).trans (hHit_read ff dig hdig_lt)))
        exact hr9
      let mc := wWrite mb 11 11 (encodePrefix ℓ M₀ τ (f + 1) : ℤ)
      have sc : ExecStmt inp
          (.writeWordHeap 11 (.lit 11) (.add (.mul codeE m0E) (.readHeap 6 hitAddrE))) mb mc 20 := by
        have hs := exec_wSet_lit inp sb.2.1 11 11
          (.add (.mul codeE m0E) (.readHeap 6 hitAddrE)) 20
          (by simp [evalIntExpr, codeE, m0E, hitAddrE, fE, dE])
        have hv : (evalIntExpr inp.toWordView 0 mb.words
            (.add (.mul codeE m0E) (.readHeap 6 hitAddrE))).1 =
              (encodePrefix ℓ M₀ τ (f + 1) : ℤ) := by
          simp only [evalIntExpr, codeE, m0E, hitAddrE, fE, dE,
            hw11_b, hw12_b, hw13_b, hm0_b, hhit_b, encodePrefix, dif_pos hf]
          push_cast; ring
        rw [hv] at hs; exact hs

      -- 4. `w[11, 12] := f + 1`
      have hw12_c : mc.words.read (.heap 11 12) = (f : ℤ) :=
        (wRead_wWrite_of_ne mb _ (Or.inr (by decide))).trans hw12_b
      let md := wWrite mc 11 12 ((f + 1 : ℕ) : ℤ)
      have sd : ExecStmt inp (.writeWordHeap 11 (.lit 12) (.add fE (.lit 1))) mc md 10 := by
        have hs := exec_wSet_lit inp sc.2.1 11 12 (.add fE (.lit 1)) 10 (by simp [evalIntExpr, fE])
        have hv : (evalIntExpr inp.toWordView 0 mc.words (.add fE (.lit 1))).1 =
            ((f + 1 : ℕ) : ℤ) := by
          simp [evalIntExpr, fE, hw12_c]
        rw [hv] at hs; exact hs

      have hPres_d : Pres md :=
        hPres10 (hPres10 (hPres10 (hPres10 hpm 13 ⟨by omega, by omega⟩ _)
          10 ⟨by omega, by omega⟩ _) 11 ⟨by omega, by omega⟩ _) 12 ⟨by omega, by omega⟩ _
      have sStep : ExecStmt inp
          (seqStmts
            [ .writeWordHeap 11 (.lit 13) (.mod remE cntFE),
              .writeWordHeap 11 (.lit 10) (.div remE cntFE),
              .writeWordHeap 11 (.lit 11) (.add (.mul codeE m0E) (.readHeap 6 hitAddrE)),
              .writeWordHeap 11 (.lit 12) (.add fE (.lit 1)) ]) m md 60 := by
        dsimp [seqStmts]
        exact (ExecStmt.seq sa (ExecStmt.seq sb (ExecStmt.seq sc sd))).mono_cost (by omega)
      exact ⟨md, sStep, hPres_d,
        (wRead_wWrite_of_ne mc _ (Or.inr (by decide))).trans
          ((wRead_wWrite_of_ne mb _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _)),
        (wRead_wWrite_of_ne mc _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _),
        wRead_wWrite_self _ _ _ _⟩)
    with ⟨mem₁, ⟨hPres1, _, hw11_end, _⟩, sLoop⟩

  refine ⟨mem₁, ?_, hw11_end, hPres1.1, hPres1.2.1, hPres1.2.2.1, hPres1.2.2.2.1, hPres1.2.2.2.2⟩
  unfold decodeTupleCodeStmt
  dsimp [seqStmts]
  exact (ExecStmt.seq s1 (ExecStmt.seq s2 (ExecStmt.seq s3 sLoop))).mono_cost (by omega)


end UL.Proof_clm_6_1_adaptive_RaceV30
