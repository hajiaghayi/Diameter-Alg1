import Mathlib
import UL.Proof.clm_6_1_adaptive.RaceP32_H4b
set_option autoImplicit false

namespace UL.Proof_clm_6_1_adaptive_RaceP32
open UL.Proof_clm_6_1_adaptive_RaceV30

open UL.Proof_lem_6_3 UL.Proof.lem_6_3.RacerV30 UL.Proof_clm_6_1_adaptive

/-! ### 1. Query cap predicate, `queryEvalCapStmt`, and `queryProg` -/

noncomputable def queryPassPred {d ℓ M₀ : ℕ} (x t : ℝ)
    (ω_r : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (padQ : EuclideanSpace ℝ (Fin (d + 1))) (f : Fin ℓ) (u : Fin M₀) : Prop :=
  gaussianQueryTest x t (ω_r (capIdx f u)) padQ

theorem queryProd_eq_queryTupleCard {d ℓ M₀ : ℕ} (x t : ℝ)
    (ω_r : Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    (padQ : EuclideanSpace ℝ (Fin (d + 1))) :
    (open Classical in
      prefixProd (fun f =>
        if hf : f < ℓ then (hitList (queryPassPred x t ω_r padQ ⟨f, hf⟩)).length else 1) ℓ) =
      queryTupleCard x t ω_r padQ := by
  classical
  rw [prefixProd_eq_tuple_card (queryPassPred x t ω_r padQ)]
  unfold queryTupleCard IsQueryTuple queryPassPred
  congr 1
  ext τ
  simp

def queryEvalCapStmt : ArithRAMStmt :=
  let cE := IntExpr.readHeap 11 (.lit 6)
  let baseE := IntExpr.readHeap 11 (.lit 5)
  seqStmts
    [ .writeWordHeap 11 (.lit 6) (.lit 0),
      .writeRealHeap 17 (.lit 11) (.ofInt (.lit 0)),
      .repeatN .dim
        (seqStmts
          [ .writeRealHeap 17 (.lit 11)
              (.add (.readRealHeap 17 (.lit 11))
                (.mul (.readRealHeap 2 (.add baseE cE))
                      (.readRealHeap 3 cE))),
            .writeWordHeap 11 (.lit 6) (.add cE (.lit 1)) ]),
      .writeRealHeap 17 (.lit 12)
        (.mul (.readRealHeap 1 (.lit 2)) (.readRealHeap 17 (.lit 11))),
      .writeRealHeap 17 (.lit 13)
        (.add (.readRealHeap 1 (.lit 0))
          (.mul (.readRealHeap 1 (.lit 3)) (.readRealHeap 2 (.add baseE .dim)))) ]

def queryPassCondE : ArithCondExpr :=
  let L := RealExpr.readRealHeap 17 (.lit 12)
  let Rv := RealExpr.readRealHeap 17 (.lit 13)
  let Ssq := RealExpr.readRealHeap 17 (.lit 10)
  let zeroR := RealExpr.ofInt (.lit 0)
  let L2 := RealExpr.mul L L
  let R2S := RealExpr.mul (.mul Rv Rv) Ssq
  .or
    (.and (.realLe Rv zeroR) (.or (.realLe zeroR L) (.realLe L2 R2S)))
    (.and (.not (.realLe Rv zeroR)) (.and (.realLe zeroR L) (.realLe R2S L2)))

def queryProg (ℓ : ℕ) : ArithRAMStmt :=
  let cE := IntExpr.readHeap 11 (.lit 6)
  let rE := IntExpr.readHeap 11 (.lit 0)
  let rCntE := IntExpr.readHeap 1 (.lit 2)
  let RmE := IntExpr.readHeap 1 (.lit 0)
  let mE := IntExpr.readHeap 1 (.lit 1)
  let m0PowE := IntExpr.readHeap 1 (.lit 5)
  let capqE := IntExpr.readHeap 1 (.lit 6)
  let qCntE := IntExpr.readHeap 11 (.lit 8)
  let stepsE := IntExpr.readHeap 11 (.lit 14)
  let qIdxE := IntExpr.readHeap 11 (.lit 15)
  let posE := IntExpr.readHeap 11 (.lit 16)
  let bktE := IntExpr.readHeap 11 (.lit 18)
  let lenE := IntExpr.readHeap 11 (.lit 19)
  let remE := IntExpr.readHeap 11 (.lit 20)
  let takeE := IntExpr.readHeap 11 (.lit 21)
  let pValE := IntExpr.readHeap 11 (.lit 22)
  let jValE := IntExpr.readHeap 11 (.lit 23)
  seqStmts
    [ -- 1. Lattice round `z` into `w[0, 0..d-1]`
      roundSubroutine (.readHeap 1 (.lit 7)) (.readHeap 1 (.lit 8)) 0 11 17,
      -- 2. Copy `(k c : ℝ)` into `r[3, 0..d-1]` and `S_sq := ∑ (k c)^2` into `r[17, 10]`
      .writeWordHeap 11 (.lit 6) (.lit 0),
      .writeRealHeap 17 (.lit 10) (.ofInt (.lit 0)),
      .repeatN .dim
        (seqStmts
          [ .writeRealHeap 3 cE (.ofInt (.readHeap 0 cE)),
            .writeRealHeap 17 (.lit 10)
              (.add (.readRealHeap 17 (.lit 10))
                (.mul (.readRealHeap 3 cE) (.readRealHeap 3 cE))),
            .writeWordHeap 11 (.lit 6) (.add cE (.lit 1)) ]),
      -- 3. Default `rawAns := -1` in `w[0, 0]`, copy counter `r := 0` in `w[11, 0]`
      .writeWordHeap 0 (.lit 0) (.lit (-1)),
      .writeWordHeap 11 (.lit 0) (.lit 0),
      -- 4. Scan all `R` copies
      .repeatN rCntE
        (seqStmts
          [ scanCapsStmt ℓ queryEvalCapStmt queryPassCondE,
            computeCappedProdStmt ℓ 6,
            .writeWordHeap 11 (.lit 14) (.lit 0),
            .writeWordHeap 11 (.lit 15) (.lit 0),
            .repeatN qCntE
              (seqStmts
                [ .writeWordHeap 11 (.lit 4) qIdxE,
                  decodeTupleCodeStmt ℓ,
                  .writeWordHeap 11 (.lit 18) (.add (.mul rE m0PowE) (.readHeap 11 (.lit 11))),
                  .writeWordHeap 11 (.lit 19) (.readHeap 24 bktE),
                  .writeWordHeap 11 (.lit 20) (.sub (.add capqE (.lit 1)) stepsE),
                  .ite (.intLe lenE remE)
                    (.writeWordHeap 11 (.lit 21) lenE)
                    (.writeWordHeap 11 (.lit 21) remE),
                  .writeWordHeap 11 (.lit 16) (.lit 0),
                  .repeatN takeE
                    (seqStmts
                      [ .writeWordHeap 11 (.lit 22)
                          (.readHeap 25 (.add (.mul bktE (.add RmE (.lit 1))) posE)),
                        .writeWordHeap 11 (.lit 23) (.mod pValE mE),
                        .ite (.intEq (.intParam jValE) (.lit 1))
                          (.writeWordHeap 0 (.lit 0) jValE)
                          .skip,
                        .writeWordHeap 11 (.lit 14) (.add stepsE (.lit 1)),
                        .writeWordHeap 11 (.lit 16) (.add posE (.lit 1)) ]),
                  .writeWordHeap 11 (.lit 15) (.add qIdxE (.lit 1)) ]),
            .writeWordHeap 11 (.lit 0) (.add rE (.lit 1)) ]) ]

/-! ### 2. `exec_queryEvalCapStmt` -/

set_option maxHeartbeats 800000 in
open Classical in
theorem exec_queryEvalCapStmt {d R ℓ M₀ Cap_q : ℕ} (hd : 1 ≤ d) (inp : ArithRAMInput d)
    {A B η : ℚ} (hη0 : 0 < η)
    {k : Fin d → ℤ} (hk_ne : k ≠ 0)
    (r : Fin R) (f : Fin ℓ) (u : Fin M₀) (x t_val : ℝ)
    (G : EuclideanSpace ℝ (Fin (d + 1)))
    {m : ArithRAMMemory} (hcm : CleanMem m)
    (hw5 : wRead m 11 5 = ((((r.val * ℓ + f.val) * M₀ + u.val) * (d + 1) : ℕ) : ℤ))
    (hr_xt : rRead m 1 0 = x * t_val)
    (hr_A : rRead m 1 2 = (A : ℝ))
    (hr_B : rRead m 1 3 = (B : ℝ))
    (hr_Ssq : rRead m 17 10 = ∑ c : Fin d, ((k c : ℝ)) ^ 2)
    (hr_G : ∀ coord : Fin (d + 1),
      rRead m 2 (((r.val * (ℓ * M₀) + (capIdx f u).val) * (d + 1) + coord.val : ℕ) : ℤ) =
        euclideanCoord G coord)
    (hr_k : ∀ c : Fin d, rRead m 3 (c.val : ℤ) = (k c : ℝ)) :
    let v : EuclideanSpace ℝ (Fin d) := ratPointToEuclidean (fun c => (k c : ℚ) * meshRat d η)
    let z_hat : EuclideanSpace ℝ (Fin d) := ‖v‖⁻¹ • v
    let padQ : EuclideanSpace ℝ (Fin (d + 1)) :=
      WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • z_hat)) (-(B : ℝ)))
    let SW := AdaptiveSW R ℓ M₀ Cap_q d
    let SR := AdaptiveSR d R ℓ M₀
    ∃ m' : ArithRAMMemory,
      ExecStmt inp queryEvalCapStmt m m' (50 + d * 30) ∧
      extraCells SW SR m' = extraCells SW SR m ∧
      (evalArithCond inp 0 m' queryPassCondE).1 = decide (gaussianQueryTest x t_val G padQ) ∧
      (evalArithCond inp 0 m' queryPassCondE).2 ≤ 70 ∧
      (∀ t i, (t ≠ 11 ∨ (i ≠ 6 ∧ i ≠ 7)) → wRead m' t i = wRead m t i) ∧
      (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) → rRead m' t i = rRead m t i) := by
  classical
  intro v z_hat padQ SW SR
  let cE := IntExpr.readHeap 11 (.lit 6)
  let baseE := IntExpr.readHeap 11 (.lit 5)
  let baseNat : ℕ := ((r.val * ℓ + f.val) * M₀ + u.val) * (d + 1)
  have hbase_eq : baseNat = (r.val * (ℓ * M₀) + (capIdx f u).val) * (d + 1) := by
    dsimp [baseNat, capIdx]; ring

  rcases exec_wSet_sw SW SR inp hcm 11 (.lit 6) 6 (mem_ASW_11 (i := 6) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨m1, s1, hex1, hw1_6, hw1_ne, hr1⟩
  rcases exec_rSet_sr SW SR inp s1.2.1 17 (.lit 11) 11 (mem_ASR_17 (i := 11) (by omega))
    (.ofInt (.lit 0)) 0 6
    (by simp [evalIntExpr]) (by simp [evalRealExpr, evalIntExpr]) (by simp [evalRealExpr, evalIntExpr])
    with ⟨m2, s2, hex2, hr2_11, hw2, hr2_ne⟩

  let fG : ℕ → ℝ := fun c => if hc : c < d then euclideanCoord G (⟨c, hc⟩ : Fin d).castSucc else 0
  let fk : ℕ → ℝ := fun c => if hc : c < d then (k ⟨c, hc⟩ : ℝ) else 0
  let body : ArithRAMStmt :=
    seqStmts
      [ .writeRealHeap 17 (.lit 11)
          (.add (.readRealHeap 17 (.lit 11))
            (.mul (.readRealHeap 2 (.add baseE cE)) (.readRealHeap 3 cE))),
        .writeWordHeap 11 (.lit 6) (.add cE (.lit 1)) ]

  let Inv : ℕ → ArithRAMMemory → Prop := fun c mc =>
    extraCells SW SR mc = extraCells SW SR m ∧
    wRead mc 11 6 = (c : ℤ) ∧
    rRead mc 17 11 = dotSum fG fk c ∧
    (∀ t i, (t ≠ 11 ∨ (i ≠ 6 ∧ i ≠ 7)) → wRead mc t i = wRead m t i) ∧
    (∀ t i, (t ≠ 17 ∨ i ∉ ([11, 12, 13] : List ℤ)) → rRead mc t i = rRead m t i)

  have hInv₀ : Inv 0 m2 := by
    refine ⟨hex2.trans hex1, (hw2 11 6).trans hw1_6, by simpa [dotSum] using hr2_11, ?_, ?_⟩
    · intro t i h
      have hne6 : t ≠ 11 ∨ i ≠ 6 := by
        rcases h with h11 | ⟨h6, _⟩
        · exact Or.inl h11
        · exact Or.inr h6
      exact (hw2 t i).trans (hw1_ne t i hne6)
    · intro t i h
      have hne11 : t ≠ 17 ∨ i ≠ 11 := by
        rcases h with h17 | hnot
        · exact Or.inl h17
        · exact Or.inr fun h11 => hnot (by simp [h11])
      exact (hr2_ne t i hne11).trans (hr1 t i)

  rcases exec_repeatN (inp := inp) .dim body d 3 30 Inv s2.2.1 hInv₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun c hc_lt mc hcmc ⟨hex_c, hwc_c, hr11_c, hwm_c, hrm_c⟩ => by
      let cFin : Fin d := ⟨c, hc_lt⟩
      have hw5_c : mc.words.read (.heap 11 5) = (baseNat : ℤ) :=
        (hwm_c 11 5 (Or.inr (by decide))).trans hw5
      have hwc_c' : mc.words.read (.heap 11 6) = (c : ℤ) := hwc_c
      have hr11_c' : mc.reals.read (.heap 17 11) = dotSum fG fk c := hr11_c
      have haddr_c : (baseNat : ℤ) + (c : ℤ) =
          (((r.val * (ℓ * M₀) + (capIdx f u).val) * (d + 1) + cFin.castSucc.val : ℕ) : ℤ) := by
        rw [hbase_eq]; dsimp [cFin]
      have hrG_c : mc.reals.read (.heap 2 ((baseNat : ℤ) + (c : ℤ))) =
          euclideanCoord G cFin.castSucc := by
        rw [haddr_c]
        exact (hrm_c 2 _ (Or.inl (by decide))).trans (hr_G cFin.castSucc)
      have hrk_c : mc.reals.read (.heap 3 (c : ℤ)) = (k cFin : ℝ) :=
        (hrm_c 3 _ (Or.inl (by decide))).trans (hr_k cFin)
      rcases exec_rSet_sr SW SR inp hcmc 17 (.lit 11) 11 (mem_ASR_17 (i := 11) (by omega))
        (.add (.readRealHeap 17 (.lit 11))
          (.mul (.readRealHeap 2 (.add baseE cE)) (.readRealHeap 3 cE)))
        (dotSum fG fk (c + 1)) 20
        (by simp [evalIntExpr])
        (by simp only [evalRealExpr, evalIntExpr, baseE, cE, hw5_c, hwc_c', hr11_c', hrG_c, hrk_c,
              dotSum, fG, fk, hc_lt, ↓reduceDIte, cFin])
        (by simp [evalRealExpr, evalIntExpr, baseE, cE])
        with ⟨ma, sa, hexa, hra_11, hwa, hra_ne⟩
      have hwc_a : ma.words.read (.heap 11 6) = (c : ℤ) := (hwa 11 6).trans hwc_c
      rcases exec_wSet_sw SW SR inp sa.2.1 11 (.lit 6) 6 (mem_ASW_11 (i := 6) (by omega))
        (.add cE (.lit 1)) (((c + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, cE, hwc_a]) (by simp [evalIntExpr, cE])
        with ⟨mb, sb, hexb, hwb_6, hwb_ne, hrb⟩
      refine ⟨mb, ExecStmt.seq sa sb, hexb.trans (hexa.trans hex_c), hwb_6,
        (hrb 17 11).trans hra_11, ?_, ?_⟩
      · intro t i h
        have hne6 : t ≠ 11 ∨ i ≠ 6 := by
          rcases h with h11 | ⟨h6, _⟩
          · exact Or.inl h11
          · exact Or.inr h6
        exact (hwb_ne t i hne6).trans ((hwa t i).trans (hwm_c t i h))
      · intro t i h
        have hne11 : t ≠ 17 ∨ i ≠ 11 := by
          rcases h with h17 | hnot
          · exact Or.inl h17
          · exact Or.inr fun h11 => hnot (by simp [h11])
        exact (hrb t i).trans ((hra_ne t i hne11).trans (hrm_c t i h)))
    with ⟨m3, ⟨hex3, _, hr3_11, hwm3, hrm3⟩, sLoop⟩

  have hdot_eq : dotSum fG fk d = ∑ c : Fin d, euclideanCoord G c.castSucc * (k c : ℝ) := by
    rw [dotSum_eq_sum_range, ← Fin.sum_univ_eq_sum_range]
    refine Finset.sum_congr rfl fun c _ => ?_
    simp only [fG, fk, c.isLt, ↓reduceDIte, Fin.eta]
  rw [hdot_eq] at hr3_11

  -- Compute `L_val` in `r[17, 12]`
  let L_val : ℝ := (A : ℝ) * ∑ c : Fin d, euclideanCoord G c.castSucc * (k c : ℝ)
  have hrA_3 : m3.reals.read (.heap 1 2) = (A : ℝ) :=
    (hrm3 1 2 (Or.inl (by decide))).trans hr_A
  have hr11_3 : m3.reals.read (.heap 17 11) = ∑ c : Fin d, euclideanCoord G c.castSucc * (k c : ℝ) :=
    hr3_11
  rcases exec_rSet_sr SW SR inp sLoop.2.1 17 (.lit 12) 12 (mem_ASR_17 (i := 12) (by omega))
    (.mul (.readRealHeap 1 (.lit 2)) (.readRealHeap 17 (.lit 11))) L_val 15
    (by simp [evalIntExpr])
    (by simp [evalRealExpr, evalIntExpr, hrA_3, hr11_3, L_val])
    (by simp [evalRealExpr, evalIntExpr])
    with ⟨m4, s4, hex4, hr4_12, hw4, hr4_ne⟩

  -- Compute `R_val` in `r[17, 13]`
  let R_val : ℝ := x * t_val + (B : ℝ) * euclideanCoord G (Fin.last d)
  have hw5_4 : m4.words.read (.heap 11 5) = (baseNat : ℤ) :=
    (hw4 11 5).trans ((hwm3 11 5 (Or.inr (by decide))).trans hw5)
  have hrxt_4 : m4.reals.read (.heap 1 0) = x * t_val :=
    (hr4_ne 1 0 (Or.inl (by decide))).trans ((hrm3 1 0 (Or.inl (by decide))).trans hr_xt)
  have hrB_4 : m4.reals.read (.heap 1 3) = (B : ℝ) :=
    (hr4_ne 1 3 (Or.inl (by decide))).trans ((hrm3 1 3 (Or.inl (by decide))).trans hr_B)
  have haddr_last : (baseNat : ℤ) + (d : ℤ) =
      (((r.val * (ℓ * M₀) + (capIdx f u).val) * (d + 1) + (Fin.last d).val : ℕ) : ℤ) := by
    rw [hbase_eq]; dsimp
  have hrGd_4 : m4.reals.read (.heap 2 ((baseNat : ℤ) + (d : ℤ))) = euclideanCoord G (Fin.last d) := by
    rw [haddr_last]
    exact (hr4_ne 2 _ (Or.inl (by decide))).trans
      ((hrm3 2 _ (Or.inl (by decide))).trans (hr_G (Fin.last d)))
  rcases exec_rSet_sr SW SR inp s4.2.1 17 (.lit 13) 13 (mem_ASR_17 (i := 13) (by omega))
    (.add (.readRealHeap 1 (.lit 0))
      (.mul (.readRealHeap 1 (.lit 3)) (.readRealHeap 2 (.add baseE .dim)))) R_val 20
    (by simp [evalIntExpr])
    (by simp [evalRealExpr, evalIntExpr, baseE, hw5_4, hrxt_4, hrB_4, hrGd_4, R_val])
    (by simp [evalRealExpr, evalIntExpr, baseE])
    with ⟨m5, s5, hex5, hr5_13, hw5_eq, hr5_ne⟩

  let S_sq : ℝ := ∑ c : Fin d, ((k c : ℝ)) ^ 2
  have hr5_12 : m5.reals.read (.heap 17 12) = L_val :=
    (hr5_ne 17 12 (Or.inr (by decide))).trans hr4_12
  have hr5_13' : m5.reals.read (.heap 17 13) = R_val := hr5_13
  have hr5_10 : m5.reals.read (.heap 17 10) = S_sq :=
    (hr5_ne 17 10 (Or.inr (by decide))).trans
      ((hr4_ne 17 10 (Or.inr (by decide))).trans
        ((hrm3 17 10 (Or.inr (by decide))).trans hr_Ssq))

  rcases meshRat_bounds hd hη0 with ⟨_, hmesh_pos, _, _, _⟩
  have hη_pos : (0 : ℝ) < (η : ℝ) := by exact_mod_cast hη0
  have hliff := query_cap_test_lattice_iff (A := A) (B := B) hη_pos hk_ne
    (meshRat d η) hmesh_pos (x * t_val) G
  have hgqt_eq : gaussianQueryTest (x * t_val) 1 G padQ ↔ gaussianQueryTest x t_val G padQ := by
    simp [gaussianQueryTest]

  have sTot : ExecStmt inp queryEvalCapStmt m m5 (50 + d * 30) := by
    unfold queryEvalCapStmt seqStmts
    exact (ExecStmt.seq s1 (ExecStmt.seq s2 (ExecStmt.seq sLoop (ExecStmt.seq s4 s5)))).mono_cost (by omega)

  refine ⟨m5, sTot, hex5.trans (hex4.trans hex3), ?_, ?_,
    fun t i h => (hw5_eq t i).trans ((hw4 t i).trans (hwm3 t i h)), ?_⟩
  · simp only [queryPassCondE, evalArithCond, evalRealExpr, evalIntExpr,
      hr5_12, hr5_13', hr5_10, Int.cast_zero]
    rw [Bool.eq_iff_iff]
    simp only [Bool.or_eq_true, Bool.and_eq_true, Bool.not_eq_true',
      decide_eq_false_iff_not, decide_eq_true_eq, ← sq]
    exact hliff.symm.trans hgqt_eq
  · simp [queryPassCondE, evalArithCond, evalRealExpr, evalIntExpr]
  · intro t i h
    have hne13 : t ≠ 17 ∨ i ≠ 13 := by
      rcases h with h17 | hnot
      · exact Or.inl h17
      · exact Or.inr fun h13 => hnot (by simp [h13])
    have hne12 : t ≠ 17 ∨ i ≠ 12 := by
      rcases h with h17 | hnot
      · exact Or.inl h17
      · exact Or.inr fun h12 => hnot (by simp [h12])
    exact (hr5_ne t i hne13).trans ((hr4_ne t i hne12).trans (hrm3 t i h))

/-! ### 3. Full execution and search correctness of `queryProg` -/

set_option maxHeartbeats 1600000 in
theorem exec_queryProg {d ℓ M₀ R m : ℕ}
    (hd : 1 ≤ d) (hR : 1 ≤ R) (hM₀ : 1 ≤ M₀) (hm : 1 ≤ m)
    {Cap_u Cap_q : ℕ} (hCap_q : 1 ≤ Cap_q)
    {a b g : ℝ} {A B η : ℚ}
    (hη0 : 0 < η) (hη16 : (η : ℝ) ≤ 1 / 16)
    {h x t : ℝ} (hh_pos : 0 < h)
    {ι : Type} [DecidableEq ι]
    (P₀ : Finset ι)
    (dec : Fin m → ι) (hdec_mem : ∀ j : Fin m, dec j ∈ P₀) (hdec_inj : Function.Injective dec)
    (u_pts : ι → EuclideanSpace ℝ (Fin d)) (hu_unit : ∀ i ∈ P₀, IsUnitVec (u_pts i))
    (hAB_props : ∀ u z z_hat : EuclideanSpace ℝ (Fin d),
      IsUnitVec u → IsUnitVec z → IsUnitVec z_hat → ‖z_hat - z‖ ≤ (η : ℝ) / 8 →
        (a ≤ inner ℝ z u →
          h ≤ inner ℝ
            (WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • z_hat)) (-(B : ℝ))) : EuclideanSpace ℝ (Fin (d + 1)))
            (WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u)) (B : ℝ)) : EuclideanSpace ℝ (Fin (d + 1)))) ∧
        (inner ℝ z u ≤ b →
          inner ℝ
            (WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • z_hat)) (-(B : ℝ))) : EuclideanSpace ℝ (Fin (d + 1)))
            (WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u)) (B : ℝ)) : EuclideanSpace ℝ (Fin (d + 1))) < 0))
    (ω : Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1)))
    {Inserted Active : Finset (Fin m)} {extraBnd : ℕ} {mem₀ : ArithRAMMemory}
    (hinv : DataStructInv hm Cap_u Cap_q A B η x t ω
      (fun j' => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u_pts (dec j'))) (B : ℝ)))
      Inserted Active extraBnd mem₀)
    (z : EuclideanSpace ℝ (Fin d)) (hz : IsUnitVec z)
    (accept : ι → Prop)
    (inp : ArithRAMInput d)
    (hinp_p : ∀ j : Fin m, listGetIntD inp.intParams (j.val : ℤ) 0 =
      (open Classical in if accept (dec j) then (1 : ℤ) else 0))
    (hinp_z : ∀ c : Fin d, listGetIntD inp.extraReals (c.val : ℤ) 0 = euclideanCoord z c) :
    let padData : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
      fun u => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u)) (B : ℝ))
    let padQuery : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
      fun z_hat => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • z_hat)) (-(B : ℝ)))
    let padPts : ι → EuclideanSpace ℝ (Fin (d + 1)) := fun i => padData (u_pts i)
    let ptsK : Fin m → EuclideanSpace ℝ (Fin (d + 1)) := fun j' => padPts (dec j')
    let P : Finset ι := Active.image dec
    let z_hat : EuclideanSpace ℝ (Fin d) := roundDirFn d η z
    let gs := goodSingleSet h x t Cap_u Cap_q P₀ dec padPts padQuery
    let E : Set (Fin R → Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))) :=
      {ω' | ∀ zh ∈ dirNet d η, ∀ i_star ∈ P₀, ∃ r : Fin R, ω' r ∈ gs zh i_star}
    ∃ (mem₁ : ArithRAMMemory) (C_q : ℕ),
      ExecStmt inp (queryProg ℓ) mem₀ mem₁ C_q ∧
      (C_q : ℝ) ≤ 600 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) + 80 + 40 * (d : ℝ) +
        (R : ℝ) * (200 + 80 * (ℓ : ℝ) + (ℓ : ℝ) * (M₀ : ℝ) * (180 + 30 * (d : ℝ)) +
          (Cap_q : ℝ) * (165 + 60 * (ℓ : ℝ))) ∧
      DataStructInv hm Cap_u Cap_q A B η x t ω ptsK Inserted Active extraBnd mem₁ ∧
      (let rawAns : ℤ := mem₁.words.read (.heap 0 0)
       let ans : Option ι :=
         if h_ans : 0 ≤ rawAns ∧ rawAns.toNat < m then
           some (dec ⟨rawAns.toNat, h_ans.2⟩)
         else
           none
       IsValidSearchAnswer P accept ans ∧
       (ω ∈ E →
         IsCompatibleTest padPts P (padQuery z_hat) accept →
         IsCorrectSearchAnswer padPts P h (padQuery z_hat) accept ans) ∧
       (ω ∈ E →
         (∀ i ∈ P, ¬ accept i → inner ℝ z (u_pts i) ≤ b) →
         ans = none →
         ∀ i ∈ P, inner ℝ z (u_pts i) < a)) := by
  classical
  intro padData padQuery padPts ptsK P z_hat gs E
  let SW := AdaptiveSW R ℓ M₀ Cap_q d
  let SR := AdaptiveSR d R ℓ M₀
  rcases roundDirFn_props hd hη0 hη16 with ⟨_, _, _, hround_z⟩
  rcases hround_z z hz with ⟨hk_ne, hz_hat_net, hz_hat_unit, hdist_z⟩
  let k := roundLatFn d η z
  let padQ := padQuery z_hat

  -- Step 1: `roundSubroutine`
  rcases exec_roundSubroutine hd hη0 hη16 hz inp hinp_z
    (.readHeap 1 (.lit 7)) (.readHeap 1 (.lit 8)) 0 11 17 (by decide) mem₀ hinv.clean
    (fun _ _ _ => trivial)
    (fun ws hws => by
      have hw := (hws 1 7 (by decide) (by decide)).trans hinv.hdr_etaN
      let ev := evalIntExpr inp.toWordView 0 ws (.readHeap 1 (.lit 7))
      exact ⟨2, ev.2.2, Prod.ext (by simp [ev, evalIntExpr, hw]) (Prod.ext (by simp [ev, evalIntExpr]) rfl), by omega⟩)
    (fun ws hws => by
      have hw := (hws 1 8 (by decide) (by decide)).trans hinv.hdr_etaD
      let ev := evalIntExpr inp.toWordView 0 ws (.readHeap 1 (.lit 8))
      exact ⟨2, ev.2.2, Prod.ext (by simp [ev, evalIntExpr, hw]) (Prod.ext (by simp [ev, evalIntExpr]) rfl), by omega⟩)
    with ⟨mq1, C_rnd, sq1, hCrnd_ub, hwq1_0, hwq1_ne, _, _, hrq1_ne, _, hlive_wq1, hlive_rq1⟩

  have hex_q1 : extraCells SW SR mq1 ≤ extraCells SW SR mem₀ := by
    have hw_sub : mq1.words.live ⊆ mem₀.words.live ∪ (heapRange 0 d ∪ heapRange 11 6) := by
      simpa [Finset.union_assoc] using hlive_wq1
    exact extraCells_le_of_subset hw_sub
      (Finset.union_subset (rangeHeap_0_sub_ASW (by omega)) (rangeHeap_11_sub_ASW (by omega)))
      hlive_rq1 (rangeHeap_17_sub_ASR (by omega))

  -- Step 2: Copy `(k c : ℝ)` into `r[3, 0..d-1]` and `S_sq` into `r[17, 10]`
  let cE := IntExpr.readHeap 11 (.lit 6)
  rcases exec_wSet_sw SW SR inp sq1.2.1 11 (.lit 6) 6 (mem_ASW_11 (i := 6) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨mq2, sq2, hex_q2, hwq2_6, hwq2_ne, hrq2⟩
  rcases exec_rSet_sr SW SR inp sq2.2.1 17 (.lit 10) 10 (mem_ASR_17 (i := 10) (by omega))
    (.ofInt (.lit 0)) 0 6
    (by simp [evalIntExpr]) (by simp [evalRealExpr, evalIntExpr]) (by simp [evalRealExpr, evalIntExpr])
    with ⟨mq3, sq3, hex_q3, hrq3_10, hwq3, hrq3_ne⟩

  let fk : ℕ → ℝ := fun c => if hc : c < d then (k ⟨c, hc⟩ : ℝ) else 0
  let kCopyBody : ArithRAMStmt :=
    seqStmts
      [ .writeRealHeap 3 cE (.ofInt (.readHeap 0 cE)),
        .writeRealHeap 17 (.lit 10)
          (.add (.readRealHeap 17 (.lit 10))
            (.mul (.readRealHeap 3 cE) (.readRealHeap 3 cE))),
        .writeWordHeap 11 (.lit 6) (.add cE (.lit 1)) ]

  let KCopyInv : ℕ → ArithRAMMemory → Prop := fun c mc =>
    extraCells SW SR mc ≤ extraCells SW SR mem₀ ∧
    wRead mc 11 6 = (c : ℤ) ∧
    rRead mc 17 10 = dotSum fk fk c ∧
    (∀ c' : Fin d, c'.val < c → rRead mc 3 (c'.val : ℤ) = (k c' : ℝ)) ∧
    (∀ c' : Fin d, wRead mc 0 (c'.val : ℤ) = k c') ∧
    (∀ t_tbl i, t_tbl ≠ 0 → t_tbl ≠ 11 → wRead mc t_tbl i = wRead mem₀ t_tbl i) ∧
    (∀ t_tbl i, t_tbl ≠ 3 → t_tbl ≠ 17 → rRead mc t_tbl i = rRead mem₀ t_tbl i)

  have hKCopy₀ : KCopyInv 0 mq3 := by
    refine ⟨by linarith [hex_q3, hex_q2, hex_q1], (hwq3 11 6).trans hwq2_6,
      by simpa [dotSum] using hrq3_10, fun _ h => by omega,
      fun c' => (hwq3 0 _).trans ((hwq2_ne 0 _ (Or.inl (by decide))).trans (hwq1_0 c')),
      fun t_tbl i ht0 ht11 => (hwq3 t_tbl i).trans ((hwq2_ne t_tbl i (Or.inl ht11)).trans (hwq1_ne t_tbl i ht0 ht11)),
      fun t_tbl i _ ht17 => (hrq3_ne t_tbl i (Or.inl ht17)).trans ((hrq2 t_tbl i).trans (hrq1_ne t_tbl i ht17))⟩

  rcases exec_repeatN (inp := inp) .dim kCopyBody d 3 40 KCopyInv sq3.2.1 hKCopy₀
    (by simp [evalIntExpr]) (by simp [evalIntExpr])
    (fun c hc_lt mc hcmc ⟨hex_c, hwc_c, hr10_c, hr3_prev, hw0_c, hwm_c, hrm_c⟩ => by
      let cFin : Fin d := ⟨c, hc_lt⟩
      have hwc_c' : mc.words.read (.heap 11 6) = (c : ℤ) := hwc_c
      have hw0_c' : mc.words.read (.heap 0 (c : ℤ)) = k cFin := hw0_c cFin
      rcases exec_rSet_sr SW SR inp hcmc 3 cE (c : ℤ) (mem_ASR_3 (i := c) (by omega))
        (.ofInt (.readHeap 0 cE)) (k cFin : ℝ) 12
        (by simp [evalIntExpr, cE, hwc_c'])
        (by simp [evalRealExpr, evalIntExpr, cE, hwc_c', hw0_c'])
        (by simp [evalRealExpr, evalIntExpr, cE])
        with ⟨ma, sa, hexa, hra_3, hwa, hra_ne⟩
      have hwc_a : ma.words.read (.heap 11 6) = (c : ℤ) := (hwa 11 6).trans hwc_c
      have hra_3' : ma.reals.read (.heap 3 (c : ℤ)) = (k cFin : ℝ) := hra_3
      have hra_10 : ma.reals.read (.heap 17 10) = dotSum fk fk c :=
        (hra_ne 17 10 (Or.inl (by decide))).trans hr10_c
      rcases exec_rSet_sr SW SR inp sa.2.1 17 (.lit 10) 10 (mem_ASR_17 (i := 10) (by omega))
        (.add (.readRealHeap 17 (.lit 10)) (.mul (.readRealHeap 3 cE) (.readRealHeap 3 cE)))
        (dotSum fk fk (c + 1)) 18
        (by simp [evalIntExpr])
        (by simp only [evalRealExpr, evalIntExpr, cE, hwc_a, hra_3', hra_10,
              dotSum, fk, hc_lt, ↓reduceDIte, cFin])
        (by simp [evalRealExpr, evalIntExpr, cE])
        with ⟨mb, sb, hexb, hrb_10, hwb, hrb_ne⟩
      have hwc_b : mb.words.read (.heap 11 6) = (c : ℤ) := (hwb 11 6).trans hwc_a
      rcases exec_wSet_sw SW SR inp sb.2.1 11 (.lit 6) 6 (mem_ASW_11 (i := 6) (by omega))
        (.add cE (.lit 1)) (((c + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, cE, hwc_b]) (by simp [evalIntExpr, cE])
        with ⟨mc', sc, hexc, hwc'_6, hwc'_ne, hrc'⟩
      refine ⟨mc', (ExecStmt.seq sa (ExecStmt.seq sb sc)).mono_cost (by omega),
        by linarith [hexc, hexb, hexa, hex_c], hwc'_6, (hrc' 17 10).trans hrb_10, ?_,
        fun c' => (hwc'_ne 0 _ (Or.inl (by decide))).trans ((hwb 0 _).trans ((hwa 0 _).trans (hw0_c c'))),
        fun t_tbl i ht0 ht11 => (hwc'_ne t_tbl i (Or.inl ht11)).trans ((hwb t_tbl i).trans ((hwa t_tbl i).trans (hwm_c t_tbl i ht0 ht11))),
        fun t_tbl i ht3 ht17 => (hrc' t_tbl i).trans ((hrb_ne t_tbl i (Or.inl ht17)).trans ((hra_ne t_tbl i (Or.inl ht3)).trans (hrm_c t_tbl i ht3 ht17)))⟩
      intro c' hc'
      rw [hrc' 3 _, hrb_ne 3 _ (Or.inl (by decide))]
      rcases Nat.lt_succ_iff_lt_or_eq.mp hc' with hlt | heq
      · rw [hra_ne 3 _ (Or.inr (by omega))]
        exact hr3_prev c' hlt
      · have hc'_eq : c' = cFin := Fin.ext heq
        subst hc'_eq
        exact hra_3)
    with ⟨mq4, ⟨hex_q4, _, hrq4_10, hrq4_3, _, hwq4_ne, hrq4_ne⟩, sKCopyLoop⟩

  let S_sq : ℝ := ∑ c : Fin d, ((k c : ℝ)) ^ 2
  have hSsq_eq : dotSum fk fk d = S_sq := by
    rw [dotSum_eq_sum_range, ← Fin.sum_univ_eq_sum_range]
    refine Finset.sum_congr rfl fun c _ => ?_
    simp [fk, c.isLt, sq]
  rw [hSsq_eq] at hrq4_10

  -- Step 3: `w[0, 0] := -1`, `w[11, 0] := 0`
  rcases exec_wSet_sw SW SR inp sKCopyLoop.2.1 0 (.lit 0) 0 (mem_ASW_0 (i := 0) (by omega))
    (.lit (-1)) (-1) 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨mq5, sq5, hex_q5, hwq5_00, hwq5_ne, hrq5⟩
  rcases exec_wSet_sw SW SR inp sq5.2.1 11 (.lit 0) 0 (mem_ASW_11 (i := 0) (by omega))
    (.lit 0) 0 4
    (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
    with ⟨mq6, sq6, hex_q6, hwq6_0, hwq6_ne, hrq6⟩

  -- Step 4: Loop over `r = 0 .. R - 1`
  let rE := IntExpr.readHeap 11 (.lit 0)
  let rCntE := IntExpr.readHeap 1 (.lit 2)
  let RmE := IntExpr.readHeap 1 (.lit 0)
  let mE := IntExpr.readHeap 1 (.lit 1)
  let m0PowE := IntExpr.readHeap 1 (.lit 5)
  let capqE := IntExpr.readHeap 1 (.lit 6)
  let qCntE := IntExpr.readHeap 11 (.lit 8)
  let stepsE := IntExpr.readHeap 11 (.lit 14)
  let qIdxE := IntExpr.readHeap 11 (.lit 15)
  let posE := IntExpr.readHeap 11 (.lit 16)
  let bktE := IntExpr.readHeap 11 (.lit 18)
  let lenE := IntExpr.readHeap 11 (.lit 19)
  let remE := IntExpr.readHeap 11 (.lit 20)
  let takeE := IntExpr.readHeap 11 (.lit 21)
  let pValE := IntExpr.readHeap 11 (.lit 22)
  let jValE := IntExpr.readHeap 11 (.lit 23)

  let posBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 22)
          (.readHeap 25 (.add (.mul bktE (.add RmE (.lit 1))) posE)),
        .writeWordHeap 11 (.lit 23) (.mod pValE mE),
        .ite (.intEq (.intParam jValE) (.lit 1))
          (.writeWordHeap 0 (.lit 0) jValE)
          .skip,
        .writeWordHeap 11 (.lit 14) (.add stepsE (.lit 1)),
        .writeWordHeap 11 (.lit 16) (.add posE (.lit 1)) ]

  let qIdxBody : ArithRAMStmt :=
    seqStmts
      [ .writeWordHeap 11 (.lit 4) qIdxE,
        decodeTupleCodeStmt ℓ,
        .writeWordHeap 11 (.lit 18) (.add (.mul rE m0PowE) (.readHeap 11 (.lit 11))),
        .writeWordHeap 11 (.lit 19) (.readHeap 24 bktE),
        .writeWordHeap 11 (.lit 20) (.sub (.add capqE (.lit 1)) stepsE),
        .ite (.intLe lenE remE)
          (.writeWordHeap 11 (.lit 21) lenE)
          (.writeWordHeap 11 (.lit 21) remE),
        .writeWordHeap 11 (.lit 16) (.lit 0),
        .repeatN takeE posBody,
        .writeWordHeap 11 (.lit 15) (.add qIdxE (.lit 1)) ]

  let rQueryBody : ArithRAMStmt :=
    seqStmts
      [ scanCapsStmt ℓ queryEvalCapStmt queryPassCondE,
        computeCappedProdStmt ℓ 6,
        .writeWordHeap 11 (.lit 14) (.lit 0),
        .writeWordHeap 11 (.lit 15) (.lit 0),
        .repeatN qCntE qIdxBody,
        .writeWordHeap 11 (.lit 0) (.add rE (.lit 1)) ]

  let rQueryCost : ℕ :=
    200 + ℓ * 80 + ℓ * M₀ * (180 + d * 30) + Cap_q * (165 + ℓ * 60)

  let AnsValid (raw : ℤ) : Prop :=
    raw = -1 ∨ (∃ j : Fin m, raw = (j.val : ℤ) ∧ j ∈ Active ∧ accept (dec j))

  -- Helper: injectivity of `globalDataBkt` on `activePairsOf`
  have hbkt_inj_act : ∀ {k' : Fin (R * m)} {s₁ s₂ : ℕ},
      (k', s₁) ∈ activePairsOf Cap_u t ω ptsK Finset.univ Active →
      (k', s₂) ∈ activePairsOf Cap_u t ω ptsK Finset.univ Active →
      globalDataBkt hm t ω ptsK k' s₁ = globalDataBkt hm t ω ptsK k' s₂ → s₁ = s₂ := by
    intro k' s₁ s₂ h1 h2 heq
    rcases mem_activePairsOf_iff.mp h1 with ⟨r1, _, j1, _, rfl, hs1_b⟩
    rcases pairIdx_div_mod r1 j1 with ⟨hd1, hm1⟩
    rcases mem_activePairsOf_iff.mp h2 with ⟨r2, _, j2, _, hp_eq, hs2_b⟩
    rcases pairIdx_inj hp_eq with ⟨rfl, rfl⟩
    exact globalDataBkt_inj_of_lt hm (Cap_u := Cap_u)
      (by simpa [hd1, hm1] using slot_lt_prod_of_lt_bound hs1_b)
      (by simpa [hd1, hm1] using slot_lt_prod_of_lt_bound hs2_b)
      heq

  -- What it means for copy `r'` to have been exhaustively searched when `wRead m 0 0 = -1`
  let CopyComplete (r' : Fin R) : Prop :=
    ∀ j_star : Fin m,
      j_star ∈ Active →
      dataTupleCard t (ω r') (ptsK j_star) ≤ Cap_u →
      queryTupleCard x t (ω r') padQ ≤ Cap_q →
      badSharedCard x t ptsK padQ (ω r') ≤ Cap_q →
      IsCompatibleTest padPts P padQ accept →
      (∃ τ : Fin ℓ → Fin M₀, IsSharedTuple x t (ω r') (ptsK j_star) padQ τ) →
      inner ℝ (ptsK j_star) padQ ≤ 0

  let RQueryInv : ℕ → ArithRAMMemory → Prop := fun r_idx mr =>
    extraCells SW SR mr ≤ extraCells SW SR mem₀ ∧
    wRead mr 11 0 = (r_idx : ℤ) ∧
    AnsValid (wRead mr 0 0) ∧
    (wRead mr 0 0 = -1 → ∀ r' : Fin R, r'.val < r_idx → CopyComplete r') ∧
    rRead mr 17 10 = S_sq ∧
    (∀ c : Fin d, rRead mr 3 (c.val : ℤ) = (k c : ℝ)) ∧
    (∀ t_tbl i, t_tbl ∉ ([0, 6, 11] : List ℕ) → wRead mr t_tbl i = wRead mem₀ t_tbl i) ∧
    (∀ t_tbl i, t_tbl ≠ 3 → t_tbl ≠ 17 → rRead mr t_tbl i = rRead mem₀ t_tbl i)

  have hRQuery₀ : RQueryInv 0 mq6 := by
    refine ⟨by linarith [hex_q6, hex_q5, hex_q4], hwq6_0,
      Or.inl ((hwq6_ne 0 0 (Or.inl (by decide))).trans hwq5_00),
      fun _ _ hr' => by omega,
      (hrq6 17 10).trans ((hrq5 17 10).trans hrq4_10),
      fun c => (hrq6 3 _).trans ((hrq5 3 _).trans (hrq4_3 c c.isLt)),
      fun t_tbl i ht => (hwq6_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans
        ((hwq5_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans
          (hwq4_ne t_tbl i (fun h => ht (by simp [h])) (fun h => ht (by simp [h])))),
      fun t_tbl i ht3 ht17 => (hrq6 t_tbl i).trans ((hrq5 t_tbl i).trans (hrq4_ne t_tbl i ht3 ht17))⟩

  have hwR_q6 : mq6.words.read (.heap 1 2) = (R : ℤ) :=
    (hRQuery₀.2.2.2.2.2.2.1 1 2 (by decide)).trans hinv.hdr_R

  rcases exec_repeatN (inp := inp) rCntE rQueryBody R 5 rQueryCost RQueryInv sq6.2.1 hRQuery₀
    (by simp [evalIntExpr, rCntE, hwR_q6])
    (by simp [evalIntExpr, rCntE])
    (fun r_idx hr_lt mr hcmr
      ⟨hex_r, hwr_0, hans_r, hcomp_prev, hrr_10, hrr_3, hwr_pres, hrr_pres⟩ => by
      let rFin : Fin R := ⟨r_idx, hr_lt⟩
      let qpass := queryPassPred x t (ω rFin) padQ
      have hwM0_r : wRead mr 1 4 = (M₀ : ℤ) := (hwr_pres 1 4 (by decide)).trans hinv.hdr_M0

      -- r1. scanCapsStmt
      rcases exec_scanCapsStmt (Cap_q := Cap_q) inp hR hM₀ rFin qpass
        queryEvalCapStmt queryPassCondE (50 + d * 30) hcmr hwr_0 hwM0_r
        (fun f u m hcm _ _ _ _ hw5_m _ hrm_m =>
          exec_queryEvalCapStmt hd inp hη0 hk_ne rFin f u x t (ω rFin (capIdx f u)) hcm hw5_m
            ((hrm_m 1 0 (Or.inl (by decide))).trans ((hrr_pres 1 0 (by decide) (by decide)).trans hinv.hdr_xt))
            ((hrm_m 1 2 (Or.inl (by decide))).trans ((hrr_pres 1 2 (by decide) (by decide)).trans hinv.hdr_A))
            ((hrm_m 1 3 (Or.inl (by decide))).trans ((hrr_pres 1 3 (by decide) (by decide)).trans hinv.hdr_B))
            ((hrm_m 17 10 (Or.inr (by decide))).trans hrr_10)
            (fun coord => (hrm_m 2 _ (Or.inl (by decide))).trans
              ((hrr_pres 2 _ (by decide) (by decide)).trans (hinv.gauss rFin (capIdx f u) coord)))
            (fun c => (hrm_m 3 _ (Or.inl (by decide))).trans (hrr_3 c)))
        with ⟨mr1, sr1, hex_r1, hcnt_r1, hhit_r1, hwr1_ne, hrr1_ne⟩

      -- r2. computeCappedProdStmt ℓ 6 (`Cap_q` in `w[1, 6]`)
      let qcnt_fn : ℕ → ℕ := fun f => if hf : f < ℓ then (hitList (qpass ⟨f, hf⟩)).length else 1
      have hwCapq_r1 : wRead mr1 1 6 = (Cap_q : ℤ) :=
        (hwr1_ne 1 6 (by decide) (Or.inl (by decide))).trans ((hwr_pres 1 6 (by decide)).trans hinv.hdr_Capq)
      rcases exec_computeCappedProdStmt inp ℓ 6 hCap_q qcnt_fn mr1 sr1.2.1 hwCapq_r1
        (fun f hf => by simp only [qcnt_fn, hf, ↓reduceDIte]; exact hcnt_r1 ⟨f, hf⟩)
        with ⟨mr2, sr2, hwr2_8, hwr2_ne, hwr2_11, hrr2_eq, hlive_w2, hlive_r2⟩
      have hex_r2 : extraCells SW SR mr2 ≤ extraCells SW SR mr1 := extraCells_le_of_subset (SW := SW) (SR := SR) hlive_w2 (rangeHeap_11_sub_ASW (by omega))
          (hlive_r2.trans Finset.subset_union_left) (Finset.empty_subset SR)
      let Q : ℕ := min Cap_q (prefixProd qcnt_fn ℓ)
      have hQ_le_Capq : Q ≤ Cap_q := Nat.min_le_left _ _
      have hQ_le_prod : Q ≤ prefixProd qcnt_fn ℓ := Nat.min_le_right _ _

      -- r3. w[11, 14] := 0, w[11, 15] := 0
      rcases exec_wSet_sw SW SR inp sr2.2.1 11 (.lit 14) 14 (mem_ASW_11 (i := 14) (by omega))
        (.lit 0) 0 4
        (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
        with ⟨mr3, sr3, hex_r3, hwr3_14, hwr3_ne, hrr3_eq⟩
      rcases exec_wSet_sw SW SR inp sr3.2.1 11 (.lit 15) 15 (mem_ASW_11 (i := 15) (by omega))
        (.lit 0) 0 4
        (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
        with ⟨mr4, sr4, hex_r4, hwr4_15, hwr4_ne, hrr4_eq⟩

      -- Define `lenOf qIdx` for telescoping cost `qStepCount Cap_q lenOf`
      let AllPairs := activePairsOf Cap_u t ω ptsK Finset.univ Active
      let bktFor : (q : ℕ) → q < Q → ℕ := fun q hq =>
        r_idx * (M₀ ^ ℓ) + encodeTuple (enumTuple qpass q (lt_of_lt_of_le hq hQ_le_prod))
      let lenOf : ℕ → ℕ := fun q =>
        if hq : q < Q then
          (AllPairs.filter (fun p => globalDataBkt hm t ω ptsK p.1 p.2 = bktFor q hq)).card
        else 0

      let QLoopInv' : ℕ → ArithRAMMemory → Prop := fun q_idx mq =>
        extraCells SW SR mq ≤ extraCells SW SR mem₀ ∧
        wRead mq 11 0 = (r_idx : ℤ) ∧
        wRead mq 11 8 = (Q : ℤ) ∧
        wRead mq 11 14 = (qStepCount Cap_q lenOf q_idx : ℤ) ∧
        wRead mq 11 15 = (q_idx : ℤ) ∧
        AnsValid (wRead mq 0 0) ∧
        (wRead mq 0 0 = -1 → wRead mr 0 0 = -1 ∧
          (∀ (q' : ℕ) (_hq' : q' < q_idx) (hq'_lt : q' < Q) (pos' : ℕ),
            pos' < min (lenOf q') (Cap_q + 1 - qStepCount Cap_q lenOf q') →
            ∀ j' : Fin m,
              wRead mem₀ 25 (((bktFor q' hq'_lt * (R * m + 1) + pos' : ℕ)) : ℤ) = ((pairIdx rFin j').val : ℤ) →
              ¬ accept (dec j')) ∧
          ∃ Vis : Finset (Fin m × (Fin ℓ → Fin M₀)),
            Vis.card = qStepCount Cap_q lenOf q_idx ∧
            ∀ jt ∈ Vis,
              jt.1 ∈ Active ∧
              ¬ accept (dec jt.1) ∧
              IsSharedTuple x t (ω rFin) (ptsK jt.1) padQ jt.2 ∧
              ∃ (q' : ℕ) (hq' : q' < prefixProd qcnt_fn ℓ),
                q' < q_idx ∧ jt.2 = enumTuple qpass q' hq') ∧
        (∀ f : Fin ℓ, wRead mq 6 (f.val : ℤ) = ((hitList (qpass f)).length : ℤ)) ∧
        (∀ (f : Fin ℓ) (idx : ℕ) (hidx : idx < (hitList (qpass f)).length),
          wRead mq 6 ((ℓ + f.val * M₀ + idx : ℕ) : ℤ) = (((hitList (qpass f))[idx]'hidx).val : ℤ)) ∧
        (∀ t_tbl i, t_tbl ∉ ([0, 6, 11] : List ℕ) → wRead mq t_tbl i = wRead mem₀ t_tbl i) ∧
        rRead mq 17 10 = S_sq ∧
        (∀ c : Fin d, rRead mq 3 (c.val : ℤ) = (k c : ℝ)) ∧
        (∀ t_tbl i, t_tbl ≠ 3 → t_tbl ≠ 17 → rRead mq t_tbl i = rRead mem₀ t_tbl i)

      have hmr4_non6_11 : ∀ t_tbl i, t_tbl ≠ 6 → t_tbl ≠ 11 → wRead mr4 t_tbl i = wRead mr t_tbl i :=
        fun t_tbl i h6 h11 =>
          (hwr4_ne t_tbl i (Or.inl h11)).trans
            ((hwr3_ne t_tbl i (Or.inl h11)).trans
              ((hwr2_ne t_tbl i h11).trans (hwr1_ne t_tbl i h6 (Or.inl h11))))

      have hQLoop₀ : QLoopInv' 0 mr4 := by
        have hw00_mr4 : wRead mr4 0 0 = wRead mr 0 0 := hmr4_non6_11 0 0 (by decide) (by decide)
        refine ⟨by linarith [hex_r4, hex_r3, hex_r2, hex_r1, hex_r],
          (hwr4_ne 11 0 (Or.inr (by decide))).trans
            ((hwr3_ne 11 0 (Or.inr (by decide))).trans
              ((hwr2_11 0 (by decide) (by decide)).trans
                ((hwr1_ne 11 0 (by decide) (Or.inr (by decide))).trans hwr_0))),
          (hwr4_ne 11 8 (Or.inr (by decide))).trans
            ((hwr3_ne 11 8 (Or.inr (by decide))).trans hwr2_8),
          (hwr4_ne 11 14 (Or.inr (by decide))).trans (by simpa [qStepCount] using hwr3_14),
          hwr4_15,
          by rw [hw00_mr4]; exact hans_r,
          fun hneg => ⟨by rwa [← hw00_mr4], fun _ hq' => by omega, ∅, by simp [qStepCount], fun _ h => by simp at h⟩,
          fun f => (hwr4_ne 6 _ (Or.inl (by decide))).trans
            ((hwr3_ne 6 _ (Or.inl (by decide))).trans ((hwr2_ne 6 _ (by decide)).trans (hcnt_r1 f))),
          fun f idx hidx => (hwr4_ne 6 _ (Or.inl (by decide))).trans
            ((hwr3_ne 6 _ (Or.inl (by decide))).trans ((hwr2_ne 6 _ (by decide)).trans (hhit_r1 f idx hidx))),
          fun t_tbl i ht => (hmr4_non6_11 t_tbl i (fun h => ht (by simp [h])) (fun h => ht (by simp [h]))).trans
            (hwr_pres t_tbl i ht),
          (hrr4_eq 17 10).trans ((hrr3_eq 17 10).trans ((hrr2_eq 17 10).trans
            ((hrr1_ne 17 10 (Or.inr (by decide))).trans hrr_10))),
          fun c => (hrr4_eq 3 _).trans ((hrr3_eq 3 _).trans ((hrr2_eq 3 _).trans
            ((hrr1_ne 3 _ (Or.inl (by decide))).trans (hrr_3 c)))),
          fun t_tbl i ht3 ht17 => (hrr4_eq t_tbl i).trans ((hrr3_eq t_tbl i).trans ((hrr2_eq t_tbl i).trans
            ((hrr1_ne t_tbl i (Or.inl ht17)).trans (hrr_pres t_tbl i ht3 ht17))))⟩

      have hwr4_8' : mr4.words.read (.heap 11 8) = (Q : ℤ) := hQLoop₀.2.2.1
      rcases ExecStmt.repeatN_telescope (inp := inp) qCntE qIdxBody Q 5 (105 + ℓ * 60) 60
        (qStepCount Cap_q lenOf) (fun i _ => qStepCount_mono Cap_q lenOf i)
        QLoopInv' sr4.2.1 hQLoop₀
        (by simp [evalIntExpr, qCntE, hwr4_8'])
        (by simp [evalIntExpr, qCntE])
        (fun q_idx hq_lt mq hcmq
          ⟨hex_q, hwq_0, hwq_8, hwq_14, hwq_15, hans_q, hvis_q, hcnt_q, hhit_q, hwq_pres,
           hrq_10, hrq_3, hrq_pres⟩ => by
          have hq_prod : q_idx < prefixProd qcnt_fn ℓ := lt_of_lt_of_le hq_lt hQ_le_prod
          let τ_q := enumTuple qpass q_idx hq_prod
          have hτ_q_valid : IsQueryTuple x t (ω rFin) padQ τ_q := enumTuple_valid qpass q_idx hq_prod
          let b_q : ℕ := bktFor q_idx hq_lt
          let len_b : ℕ := lenOf q_idx
          have hlen_b_eq : len_b =
              (AllPairs.filter (fun p => globalDataBkt hm t ω ptsK p.1 p.2 = b_q)).card := by
            simp [len_b, lenOf, hq_lt, b_q]
          let prevSteps := qStepCount Cap_q lenOf q_idx
          have hprev_le : prevSteps ≤ Cap_q + 1 := qStepCount_le_cap Cap_q lenOf q_idx
          let remCap : ℕ := Cap_q + 1 - prevSteps
          let take_b : ℕ := min len_b remCap
          have htake_diff : take_b = qStepCount Cap_q lenOf (q_idx + 1) - prevSteps :=
            qStepCount_diff Cap_q lenOf q_idx
          have htake_le_len : take_b ≤ len_b := Nat.min_le_left _ _

          have hbkt_mq : BucketInv Cap_u (globalDataBkt hm t ω ptsK) AllPairs mq :=
            bucketInv_congr hinv.buckets (fun t_tbl idx h22 _ =>
              hwq_pres t_tbl idx (by simp; omega))

          -- q1. w[11, 4] := q_idx
          have hwq_15' : mq.words.read (.heap 11 15) = (q_idx : ℤ) := hwq_15
          rcases exec_wSet_sw SW SR inp hcmq 11 (.lit 4) 4 (mem_ASW_11 (i := 4) (by omega))
            qIdxE (q_idx : ℤ) 6
            (by simp [evalIntExpr]) (by simp [evalIntExpr, qIdxE, hwq_15']) (by simp [evalIntExpr, qIdxE])
            with ⟨mqa1, sqa1, hexqa1, hwqa1_4, hwqa1_ne, hrqa1⟩

          -- q2. decodeTupleCodeStmt ℓ
          have hwM0_qa1 : wRead mqa1 1 4 = (M₀ : ℤ) :=
            (hwqa1_ne 1 4 (Or.inl (by decide))).trans ((hwq_pres 1 4 (by decide)).trans hinv.hdr_M0)
          rcases exec_decodeTupleCodeStmt inp qpass q_idx hq_prod mqa1 sqa1.2.1 hwM0_qa1 hwqa1_4
            (fun f => (hwqa1_ne 6 _ (Or.inl (by decide))).trans (hcnt_q f))
            (fun f idx hidx => (hwqa1_ne 6 _ (Or.inl (by decide))).trans (hhit_q f idx hidx))
            with ⟨mqa2, sqa2, hwqa2_11, hwqa2_ne, hwqa2_11pres, hrqa2, hlive_wqa2, hlive_rqa2⟩
          have hexqa2 : extraCells SW SR mqa2 ≤ extraCells SW SR mqa1 := extraCells_le_of_subset (SW := SW) (SR := SR) hlive_wqa2 (rangeHeap_11_sub_ASW (by omega))
              (hlive_rqa2.trans Finset.subset_union_left) (Finset.empty_subset SR)

          -- q3. w[11, 18] := b_q
          have hwqa2_0 : mqa2.words.read (.heap 11 0) = (r_idx : ℤ) :=
            (hwqa2_11pres 0 (Or.inl (by decide))).trans ((hwqa1_ne 11 0 (Or.inr (by decide))).trans hwq_0)
          have hwqa2_M0p : mqa2.words.read (.heap 1 5) = ((M₀ ^ ℓ : ℕ) : ℤ) :=
            (hwqa2_ne 1 5 (by decide)).trans
              ((hwqa1_ne 1 5 (Or.inl (by decide))).trans ((hwq_pres 1 5 (by decide)).trans hinv.hdr_M0pow))
          have hwqa2_11' : mqa2.words.read (.heap 11 11) = (encodeTuple τ_q : ℤ) := hwqa2_11
          rcases exec_wSet_sw SW SR inp sqa2.2.1 11 (.lit 18) 18 (mem_ASW_11 (i := 18) (by omega))
            (.add (.mul rE m0PowE) (.readHeap 11 (.lit 11))) (b_q : ℤ) 12
            (by simp [evalIntExpr])
            (by simp only [evalIntExpr, rE, m0PowE, hwqa2_0, hwqa2_M0p, hwqa2_11', b_q, bktFor, τ_q]; push_cast; ring)
            (by simp [evalIntExpr, rE, m0PowE])
            with ⟨mqa3, sqa3, hexqa3, hwqa3_18, hwqa3_ne, hrqa3⟩

          -- q4. w[11, 19] := w[24, b_q] = len_b
          have hwqa3_18' : mqa3.words.read (.heap 11 18) = (b_q : ℤ) := hwqa3_18
          have hwqa3_24 : mqa3.words.read (.heap 24 (b_q : ℤ)) = (len_b : ℤ) := by
            have h1 : wRead mqa3 24 (b_q : ℤ) = wRead mq 24 (b_q : ℤ) :=
              (hwqa3_ne 24 _ (Or.inl (by decide))).trans
                ((hwqa2_ne 24 _ (by decide)).trans (hwqa1_ne 24 _ (Or.inl (by decide))))
            rw [words_read_heap, h1, hbkt_mq.bkt_len b_q, hlen_b_eq]
          rcases exec_wSet_sw SW SR inp sqa3.2.1 11 (.lit 19) 19 (mem_ASW_11 (i := 19) (by omega))
            (.readHeap 24 bktE) (len_b : ℤ) 10
            (by simp [evalIntExpr])
            (by simp [evalIntExpr, bktE, hwqa3_18', hwqa3_24])
            (by simp [evalIntExpr, bktE])
            with ⟨mqa4, sqa4, hexqa4, hwqa4_19, hwqa4_ne, hrqa4⟩

          -- q5. w[11, 20] := (Cap_q + 1) - prevSteps = remCap
          have hwqa4_Capq : mqa4.words.read (.heap 1 6) = (Cap_q : ℤ) :=
            (hwqa4_ne 1 6 (Or.inl (by decide))).trans
              ((hwqa3_ne 1 6 (Or.inl (by decide))).trans
                ((hwqa2_ne 1 6 (by decide)).trans
                  ((hwqa1_ne 1 6 (Or.inl (by decide))).trans ((hwq_pres 1 6 (by decide)).trans hinv.hdr_Capq))))
          have hwqa4_14 : mqa4.words.read (.heap 11 14) = (prevSteps : ℤ) :=
            (hwqa4_ne 11 14 (Or.inr (by decide))).trans
              ((hwqa3_ne 11 14 (Or.inr (by decide))).trans
                ((hwqa2_11pres 14 (Or.inr (by decide))).trans
                  ((hwqa1_ne 11 14 (Or.inr (by decide))).trans hwq_14)))
          rcases exec_wSet_sw SW SR inp sqa4.2.1 11 (.lit 20) 20 (mem_ASW_11 (i := 20) (by omega))
            (.sub (.add capqE (.lit 1)) stepsE) (remCap : ℤ) 12
            (by simp [evalIntExpr])
            (by simp only [evalIntExpr, capqE, stepsE, hwqa4_Capq, hwqa4_14, remCap]; omega)
            (by simp [evalIntExpr, capqE, stepsE])
            with ⟨mqa5, sqa5, hexqa5, hwqa5_20, hwqa5_ne, hrqa5⟩

          -- q6. w[11, 21] := take_b = min len_b remCap
          have hwqa5_19 : mqa5.words.read (.heap 11 19) = (len_b : ℤ) :=
            (hwqa5_ne 11 19 (Or.inr (by decide))).trans hwqa4_19
          have hwqa5_20' : mqa5.words.read (.heap 11 20) = (remCap : ℤ) := hwqa5_20
          have sqa6_all : ∃ mqa6 : ArithRAMMemory,
              ExecStmt inp (.ite (.intLe lenE remE)
                (.writeWordHeap 11 (.lit 21) lenE) (.writeWordHeap 11 (.lit 21) remE)) mqa5 mqa6 15 ∧
              extraCells SW SR mqa6 = extraCells SW SR mqa5 ∧
              wRead mqa6 11 21 = (take_b : ℤ) ∧
              (∀ t_tbl i, (t_tbl ≠ 11 ∨ i ≠ 21) → wRead mqa6 t_tbl i = wRead mqa5 t_tbl i) ∧
              (∀ t_tbl i, rRead mqa6 t_tbl i = rRead mqa5 t_tbl i) := by
            by_cases hle : len_b ≤ remCap
            · rcases exec_wSet_sw SW SR inp sqa5.2.1 11 (.lit 21) 21 (mem_ASW_11 (i := 21) (by omega))
                lenE (len_b : ℤ) 8
                (by simp [evalIntExpr]) (by simp [evalIntExpr, lenE, hwqa5_19]) (by simp [evalIntExpr, lenE])
                with ⟨mt, st, hext, hwt_21, hwt_ne, hrt⟩
              have hc_ev : evalArithCond inp 0 mqa5 (.intLe lenE remE) = (true, 5) := by
                simp [evalArithCond, evalIntExpr, lenE, remE, hwqa5_19, hwqa5_20', hle]
              have hmin : take_b = len_b := Nat.min_eq_left hle
              exact ⟨mt, (ExecStmt.ite_true hc_ev le_rfl st).mono_cost (by omega), hext,
                by rw [hmin]; exact hwt_21, hwt_ne, hrt⟩
            · have hgt : ¬ ((len_b : ℤ) ≤ (remCap : ℤ)) := by omega
              rcases exec_wSet_sw SW SR inp sqa5.2.1 11 (.lit 21) 21 (mem_ASW_11 (i := 21) (by omega))
                remE (remCap : ℤ) 8
                (by simp [evalIntExpr]) (by simp [evalIntExpr, remE, hwqa5_20']) (by simp [evalIntExpr, remE])
                with ⟨mf, sf, hexf, hwf_21, hwf_ne, hrf⟩
              have hc_ev : evalArithCond inp 0 mqa5 (.intLe lenE remE) = (false, 5) := by
                simp [evalArithCond, evalIntExpr, lenE, remE, hwqa5_19, hwqa5_20', hgt]
              have hmin : take_b = remCap := Nat.min_eq_right (by omega)
              exact ⟨mf, (ExecStmt.ite_false hc_ev le_rfl sf).mono_cost (by omega), hexf,
                by rw [hmin]; exact hwf_21, hwf_ne, hrf⟩
          rcases sqa6_all with ⟨mqa6, sqa6, hexqa6, hwqa6_21, hwqa6_ne, hrqa6⟩

          -- q7. w[11, 16] := 0
          rcases exec_wSet_sw SW SR inp sqa6.2.1 11 (.lit 16) 16 (mem_ASW_11 (i := 16) (by omega))
            (.lit 0) 0 4
            (by simp [evalIntExpr]) (by simp [evalIntExpr]) (by simp [evalIntExpr])
            with ⟨mqa7, sqa7, hexqa7, hwqa7_16, hwqa7_ne, hrqa7⟩

          have hmqa7_non11 : ∀ t_tbl i, t_tbl ≠ 11 → wRead mqa7 t_tbl i = wRead mq t_tbl i :=
            fun t_tbl i h11 =>
              (hwqa7_ne t_tbl i (Or.inl h11)).trans
                ((hwqa6_ne t_tbl i (Or.inl h11)).trans
                  ((hwqa5_ne t_tbl i (Or.inl h11)).trans
                    ((hwqa4_ne t_tbl i (Or.inl h11)).trans
                      ((hwqa3_ne t_tbl i (Or.inl h11)).trans
                        ((hwqa2_ne t_tbl i h11).trans (hwqa1_ne t_tbl i (Or.inl h11)))))))

          -- q8. Inner bucket scan `pos = 0 .. take_b - 1`
          let PosInv : ℕ → ArithRAMMemory → Prop := fun pos mp =>
            extraCells SW SR mp ≤ extraCells SW SR mem₀ ∧
            wRead mp 11 0 = (r_idx : ℤ) ∧
            wRead mp 11 8 = (Q : ℤ) ∧
            wRead mp 11 14 = ((prevSteps + pos : ℕ) : ℤ) ∧
            wRead mp 11 15 = (q_idx : ℤ) ∧
            wRead mp 11 16 = (pos : ℤ) ∧
            wRead mp 11 18 = (b_q : ℤ) ∧
            AnsValid (wRead mp 0 0) ∧
            (wRead mp 0 0 = -1 → wRead mq 0 0 = -1 ∧
              (∀ p' < pos, ∀ j' : Fin m,
                wRead mem₀ 25 (((b_q * (R * m + 1) + p' : ℕ)) : ℤ) = ((pairIdx rFin j').val : ℤ) →
                ¬ accept (dec j')) ∧
              ∃ VisCur : Finset (Fin m × (Fin ℓ → Fin M₀)),
                VisCur.card = pos ∧
                ∀ jt ∈ VisCur,
                  jt.1 ∈ Active ∧
                  ¬ accept (dec jt.1) ∧
                  IsSharedTuple x t (ω rFin) (ptsK jt.1) padQ τ_q ∧
                  jt.2 = τ_q ∧
                  ∃ p' < pos,
                    wRead mem₀ 25 (((b_q * (R * m + 1) + p' : ℕ)) : ℤ) = ((pairIdx rFin jt.1).val : ℤ)) ∧
            (∀ f : Fin ℓ, wRead mp 6 (f.val : ℤ) = ((hitList (qpass f)).length : ℤ)) ∧
            (∀ (f : Fin ℓ) (idx : ℕ) (hidx : idx < (hitList (qpass f)).length),
              wRead mp 6 ((ℓ + f.val * M₀ + idx : ℕ) : ℤ) = (((hitList (qpass f))[idx]'hidx).val : ℤ)) ∧
            (∀ t_tbl i, t_tbl ∉ ([0, 6, 11] : List ℕ) → wRead mp t_tbl i = wRead mem₀ t_tbl i) ∧
            rRead mp 17 10 = S_sq ∧
            (∀ c : Fin d, rRead mp 3 (c.val : ℤ) = (k c : ℝ)) ∧
            (∀ t_tbl i, t_tbl ≠ 3 → t_tbl ≠ 17 → rRead mp t_tbl i = rRead mem₀ t_tbl i)

          have hPos₀ : PosInv 0 mqa7 := by
            have hw00_7 : wRead mqa7 0 0 = wRead mq 0 0 := hmqa7_non11 0 0 (by decide)
            refine ⟨by linarith [hexqa7, hexqa6, hexqa5, hexqa4, hexqa3, hexqa2, hexqa1, hex_q],
              (hwqa7_ne 11 0 (Or.inr (by decide))).trans
                ((hwqa6_ne 11 0 (Or.inr (by decide))).trans
                  ((hwqa5_ne 11 0 (Or.inr (by decide))).trans
                    ((hwqa4_ne 11 0 (Or.inr (by decide))).trans
                      ((hwqa3_ne 11 0 (Or.inr (by decide))).trans hwqa2_0)))),
              (hwqa7_ne 11 8 (Or.inr (by decide))).trans
                ((hwqa6_ne 11 8 (Or.inr (by decide))).trans
                  ((hwqa5_ne 11 8 (Or.inr (by decide))).trans
                    ((hwqa4_ne 11 8 (Or.inr (by decide))).trans
                      ((hwqa3_ne 11 8 (Or.inr (by decide))).trans
                        ((hwqa2_11pres 8 (Or.inl (by decide))).trans
                          ((hwqa1_ne 11 8 (Or.inr (by decide))).trans hwq_8)))))),
              (hwqa7_ne 11 14 (Or.inr (by decide))).trans
                ((hwqa6_ne 11 14 (Or.inr (by decide))).trans
                  ((hwqa5_ne 11 14 (Or.inr (by decide))).trans (by simpa using hwqa4_14))),
              (hwqa7_ne 11 15 (Or.inr (by decide))).trans
                ((hwqa6_ne 11 15 (Or.inr (by decide))).trans
                  ((hwqa5_ne 11 15 (Or.inr (by decide))).trans
                    ((hwqa4_ne 11 15 (Or.inr (by decide))).trans
                      ((hwqa3_ne 11 15 (Or.inr (by decide))).trans
                        ((hwqa2_11pres 15 (Or.inr (by decide))).trans
                          ((hwqa1_ne 11 15 (Or.inr (by decide))).trans hwq_15)))))),
              hwqa7_16,
              (hwqa7_ne 11 18 (Or.inr (by decide))).trans
                ((hwqa6_ne 11 18 (Or.inr (by decide))).trans
                  ((hwqa5_ne 11 18 (Or.inr (by decide))).trans
                    ((hwqa4_ne 11 18 (Or.inr (by decide))).trans hwqa3_18))),
              by rw [hw00_7]; exact hans_q,
              fun hneg => ⟨by rwa [← hw00_7], fun _ hp' => by omega, ∅, by simp, fun _ h => by simp at h⟩,
              fun f => (hmqa7_non11 6 _ (by decide)).trans (hcnt_q f),
              fun f idx hidx => (hmqa7_non11 6 _ (by decide)).trans (hhit_q f idx hidx),
              fun t_tbl i ht => (hmqa7_non11 t_tbl i (fun h => ht (by simp [h]))).trans (hwq_pres t_tbl i ht),
              (hrqa7 17 10).trans ((hrqa6 17 10).trans ((hrqa5 17 10).trans
                ((hrqa4 17 10).trans ((hrqa3 17 10).trans ((hrqa2 17 10).trans ((hrqa1 17 10).trans hrq_10)))))),
              fun c => (hrqa7 3 _).trans ((hrqa6 3 _).trans ((hrqa5 3 _).trans
                ((hrqa4 3 _).trans ((hrqa3 3 _).trans ((hrqa2 3 _).trans ((hrqa1 3 _).trans (hrq_3 c))))))),
              fun t_tbl i ht3 ht17 => (hrqa7 t_tbl i).trans ((hrqa6 t_tbl i).trans ((hrqa5 t_tbl i).trans
                ((hrqa4 t_tbl i).trans ((hrqa3 t_tbl i).trans ((hrqa2 t_tbl i).trans
                  ((hrqa1 t_tbl i).trans (hrq_pres t_tbl i ht3 ht17)))))))⟩

          have hwqa7_21 : mqa7.words.read (.heap 11 21) = (take_b : ℤ) :=
            (hwqa7_ne 11 21 (Or.inr (by decide))).trans hwqa6_21

          rcases exec_repeatN (inp := inp) takeE posBody take_b 5 60 PosInv sqa7.2.1 hPos₀
            (by simp [evalIntExpr, takeE, hwqa7_21])
            (by simp [evalIntExpr, takeE])
            (fun pos hpos_take mp hcmp
              ⟨hex_p, hwp_0, hwp_8, hwp_14, hwp_15, hwp_16, hwp_18, hans_p, hvis_p,
               hcnt_p, hhit_p, hwp_pres, hrp_10, hrp_3, hrp_pres⟩ => by
              have hpos_len : pos < (AllPairs.filter (fun p => globalDataBkt hm t ω ptsK p.1 p.2 = b_q)).card := by
                rw [← hlen_b_eq]; exact lt_of_lt_of_le hpos_take htake_le_len
              rcases hinv.buckets.bwd b_q pos hpos_len with
                ⟨pair_p, slot_p, hmem_pair, hbkt_pair, h25_pair, _, h23_pair⟩
              rcases mem_activePairsOf_iff.mp hmem_pair with ⟨r_p, _, j_p, hj_p_act, rfl, hslot_p_b⟩

              -- Prove `r_p = rFin` and `IsDataTuple t (ω rFin) (ptsK j_p) τ_q`!
              have hslot_prod := slot_lt_prod_of_lt_bound hslot_p_b
              have hloc_eq : localDataBkt t (ω r_p) (ptsK j_p) slot_p =
                  encodeTuple (enumTuple (dataPassPred t (ω r_p) (ptsK j_p)) slot_p hslot_prod) := by
                unfold localDataBkt; rw [dif_pos hslot_prod]
              have hloc_lt : localDataBkt t (ω r_p) (ptsK j_p) slot_p < M₀ ^ ℓ := by
                rw [hloc_eq]; exact encodeTuple_lt hM₀ _
              have hτq_lt : encodeTuple τ_q < M₀ ^ ℓ := encodeTuple_lt hM₀ τ_q
              have hg_split : r_p.val * (M₀ ^ ℓ) + localDataBkt t (ω r_p) (ptsK j_p) slot_p =
                  r_idx * (M₀ ^ ℓ) + encodeTuple τ_q := by
                rw [← globalDataBkt_pairIdx hm t ω ptsK r_p j_p slot_p]
                exact hbkt_pair
              rcases pair_addr_inj hloc_lt hτq_lt hg_split with ⟨hr_p_eq, hcode_eq⟩
              have hr_p_fin : r_p = rFin := Fin.ext hr_p_eq
              subst hr_p_fin
              rw [hloc_eq] at hcode_eq
              have henum_eq : enumTuple (dataPassPred t (ω rFin) (ptsK j_p)) slot_p hslot_prod = τ_q :=
                encodeTuple_injective hM₀ hcode_eq
              have hdata_jp : IsDataTuple t (ω rFin) (ptsK j_p) τ_q := by
                rw [← henum_eq]
                exact enumTuple_valid (dataPassPred t (ω rFin) (ptsK j_p)) slot_p hslot_prod
              have hshared_jp : IsSharedTuple x t (ω rFin) (ptsK j_p) padQ τ_q :=
                ⟨hdata_jp, hτ_q_valid⟩

              -- p1. w[11, 22] := w[25, b_q * (R * m + 1) + pos] = (pairIdx rFin j_p).val
              have hwp_18' : mp.words.read (.heap 11 18) = (b_q : ℤ) := hwp_18
              have hwp_16' : mp.words.read (.heap 11 16) = (pos : ℤ) := hwp_16
              have hwp_Rm : mp.words.read (.heap 1 0) = ((R * m : ℕ) : ℤ) :=
                (hwp_pres 1 0 (by decide)).trans hinv.hdr_Rm
              have haddr25 : (b_q : ℤ) * (((R * m : ℕ) : ℤ) + 1) + (pos : ℤ) =
                  (((b_q * (R * m + 1) + pos : ℕ)) : ℤ) := by push_cast; ring
              have hwp_25 : mp.words.read (.heap 25 (((b_q * (R * m + 1) + pos : ℕ)) : ℤ)) =
                  (((pairIdx rFin j_p).val : ℕ) : ℤ) :=
                (hwp_pres 25 _ (by decide)).trans h25_pair
              rcases exec_wSet_sw SW SR inp hcmp 11 (.lit 22) 22 (mem_ASW_11 (i := 22) (by omega))
                (.readHeap 25 (.add (.mul bktE (.add RmE (.lit 1))) posE))
                (((pairIdx rFin j_p).val : ℕ) : ℤ) 15
                (by simp [evalIntExpr])
                (by simp only [evalIntExpr, bktE, RmE, posE, hwp_18', hwp_Rm, hwp_16', haddr25, hwp_25])
                (by simp [evalIntExpr, bktE, RmE, posE])
                with ⟨mp1, sp1, hexp1, hwp1_22, hwp1_ne, hrp1⟩

              -- p2. w[11, 23] := pVal % m = j_p.val
              have hwp1_22' : mp1.words.read (.heap 11 22) = (((pairIdx rFin j_p).val : ℕ) : ℤ) := hwp1_22
              have hwp1_m : mp1.words.read (.heap 1 1) = (m : ℤ) :=
                (hwp1_ne 1 1 (Or.inl (by decide))).trans ((hwp_pres 1 1 (by decide)).trans hinv.hdr_m)
              have hmod_jp : (((pairIdx rFin j_p).val : ℕ) : ℤ) % (m : ℤ) = (j_p.val : ℤ) := by
                exact_mod_cast (pairIdx_div_mod rFin j_p).2
              rcases exec_wSet_sw SW SR inp sp1.2.1 11 (.lit 23) 23 (mem_ASW_11 (i := 23) (by omega))
                (.mod pValE mE) (j_p.val : ℤ) 12
                (by simp [evalIntExpr])
                (by simp [evalIntExpr, pValE, mE, hwp1_22', hwp1_m, hmod_jp])
                (by simp [evalIntExpr, pValE, mE])
                with ⟨mp2, sp2, hexp2, hwp2_23, hwp2_ne, hrp2⟩

              -- p3. .ite (.intEq (.intParam jValE) (.lit 1)) (w[0, 0] := jValE) .skip
              have hwp2_23' : mp2.words.read (.heap 11 23) = (j_p.val : ℤ) := hwp2_23
              have hparam_jp := hinp_p j_p
              have sp3_all : ∃ mp3 : ArithRAMMemory,
                  ExecStmt inp (.ite (.intEq (.intParam jValE) (.lit 1))
                    (.writeWordHeap 0 (.lit 0) jValE) .skip) mp2 mp3 15 ∧
                  extraCells SW SR mp3 = extraCells SW SR mp2 ∧
                  AnsValid (wRead mp3 0 0) ∧
                  (wRead mp3 0 0 = -1 → wRead mp 0 0 = -1 ∧ ¬ accept (dec j_p)) ∧
                  (∀ t_tbl i, (t_tbl ≠ 0 ∨ i ≠ 0) → wRead mp3 t_tbl i = wRead mp2 t_tbl i) ∧
                  (∀ t_tbl i, rRead mp3 t_tbl i = rRead mp2 t_tbl i) := by
                by_cases hacc : accept (dec j_p)
                · simp only [hacc, ↓reduceIte] at hparam_jp
                  rcases exec_wSet_sw SW SR inp sp2.2.1 0 (.lit 0) 0 (mem_ASW_0 (i := 0) (by omega))
                    jValE (j_p.val : ℤ) 8
                    (by simp [evalIntExpr]) (by simp [evalIntExpr, jValE, hwp2_23']) (by simp [evalIntExpr, jValE])
                    with ⟨mt, st, hext, hwt_00, hwt_ne, hrt⟩
                  have hc_ev : evalArithCond inp 0 mp2 (.intEq (.intParam jValE) (.lit 1)) = (true, 5) := by
                    simp [evalArithCond, evalIntExpr, jValE, hwp2_23', hparam_jp]
                  refine ⟨mt, (ExecStmt.ite_true hc_ev le_rfl st).mono_cost (by omega), hext,
                    Or.inr ⟨j_p, hwt_00, hj_p_act, hacc⟩,
                    fun hneg => by rw [hwt_00] at hneg; omega,
                    hwt_ne, hrt⟩
                · simp only [hacc, ↓reduceIte] at hparam_jp
                  have hc_ev : evalArithCond inp 0 mp2 (.intEq (.intParam jValE) (.lit 1)) = (false, 5) := by
                    simp [evalArithCond, evalIntExpr, jValE, hwp2_23', hparam_jp]
                  have hw00_mp2 : wRead mp2 0 0 = wRead mp 0 0 :=
                    (hwp2_ne 0 0 (Or.inl (by decide))).trans (hwp1_ne 0 0 (Or.inl (by decide)))
                  refine ⟨mp2, (ExecStmt.ite_false hc_ev le_rfl (ExecStmt.skip inp sp2.2.1)).mono_cost (by omega), rfl,
                    by rw [hw00_mp2]; exact hans_p,
                    fun hneg => ⟨by rwa [← hw00_mp2], hacc⟩,
                    fun _ _ _ => rfl, fun _ _ => rfl⟩
              rcases sp3_all with ⟨mp3, sp3, hexp3, hans_p3, hneg_p3, hwp3_ne, hrp3⟩

              -- p4. w[11, 14] := prevSteps + pos + 1
              have hwp3_14 : mp3.words.read (.heap 11 14) = ((prevSteps + pos : ℕ) : ℤ) :=
                (hwp3_ne 11 14 (Or.inl (by decide))).trans
                  ((hwp2_ne 11 14 (Or.inr (by decide))).trans
                    ((hwp1_ne 11 14 (Or.inr (by decide))).trans hwp_14))
              rcases exec_wSet_sw SW SR inp sp3.2.1 11 (.lit 14) 14 (mem_ASW_11 (i := 14) (by omega))
                (.add stepsE (.lit 1)) (((prevSteps + (pos + 1) : ℕ) : ℤ)) 8
                (by simp [evalIntExpr])
                (by simp only [evalIntExpr, stepsE, hwp3_14]; push_cast; ring)
                (by simp [evalIntExpr, stepsE])
                with ⟨mp4, sp4, hexp4, hwp4_14, hwp4_ne, hrp4⟩

              -- p5. w[11, 16] := pos + 1
              have hwp4_16 : mp4.words.read (.heap 11 16) = (pos : ℤ) :=
                (hwp4_ne 11 16 (Or.inr (by decide))).trans
                  ((hwp3_ne 11 16 (Or.inl (by decide))).trans
                    ((hwp2_ne 11 16 (Or.inr (by decide))).trans
                      ((hwp1_ne 11 16 (Or.inr (by decide))).trans hwp_16)))
              rcases exec_wSet_sw SW SR inp sp4.2.1 11 (.lit 16) 16 (mem_ASW_11 (i := 16) (by omega))
                (.add posE (.lit 1)) (((pos + 1 : ℕ) : ℤ)) 8
                (by simp [evalIntExpr])
                (by simp [evalIntExpr, posE, hwp4_16])
                (by simp [evalIntExpr, posE])
                with ⟨mp5, sp5, hexp5, hwp5_16, hwp5_ne, hrp5⟩

              have hw00_mp5 : wRead mp5 0 0 = wRead mp3 0 0 :=
                (hwp5_ne 0 0 (Or.inl (by decide))).trans (hwp4_ne 0 0 (Or.inl (by decide)))

              have hmp5_non0_11 : ∀ t_tbl i, t_tbl ≠ 0 → t_tbl ≠ 11 → wRead mp5 t_tbl i = wRead mp t_tbl i :=
                fun t_tbl i h0 h11 =>
                  (hwp5_ne t_tbl i (Or.inl h11)).trans
                    ((hwp4_ne t_tbl i (Or.inl h11)).trans
                      ((hwp3_ne t_tbl i (Or.inl h0)).trans
                        ((hwp2_ne t_tbl i (Or.inl h11)).trans (hwp1_ne t_tbl i (Or.inl h11)))))

              refine ⟨mp5,
                (ExecStmt.seq sp1 (ExecStmt.seq sp2 (ExecStmt.seq sp3 (ExecStmt.seq sp4 sp5)))).mono_cost (by omega),
                by linarith [hexp5, hexp4, hexp3, hexp2, hexp1, hex_p],
                (hwp5_ne 11 0 (Or.inr (by decide))).trans
                  ((hwp4_ne 11 0 (Or.inr (by decide))).trans
                    ((hwp3_ne 11 0 (Or.inl (by decide))).trans
                      ((hwp2_ne 11 0 (Or.inr (by decide))).trans ((hwp1_ne 11 0 (Or.inr (by decide))).trans hwp_0)))),
                (hwp5_ne 11 8 (Or.inr (by decide))).trans
                  ((hwp4_ne 11 8 (Or.inr (by decide))).trans
                    ((hwp3_ne 11 8 (Or.inl (by decide))).trans
                      ((hwp2_ne 11 8 (Or.inr (by decide))).trans ((hwp1_ne 11 8 (Or.inr (by decide))).trans hwp_8)))),
                (hwp5_ne 11 14 (Or.inr (by decide))).trans hwp4_14,
                (hwp5_ne 11 15 (Or.inr (by decide))).trans
                  ((hwp4_ne 11 15 (Or.inr (by decide))).trans
                    ((hwp3_ne 11 15 (Or.inl (by decide))).trans
                      ((hwp2_ne 11 15 (Or.inr (by decide))).trans ((hwp1_ne 11 15 (Or.inr (by decide))).trans hwp_15)))),
                hwp5_16,
                (hwp5_ne 11 18 (Or.inr (by decide))).trans
                  ((hwp4_ne 11 18 (Or.inr (by decide))).trans
                    ((hwp3_ne 11 18 (Or.inl (by decide))).trans
                      ((hwp2_ne 11 18 (Or.inr (by decide))).trans ((hwp1_ne 11 18 (Or.inr (by decide))).trans hwp_18)))),
                by rw [hw00_mp5]; exact hans_p3,
                ?_,
                fun f => (hmp5_non0_11 6 _ (by decide) (by decide)).trans (hcnt_p f),
                fun f idx hidx => (hmp5_non0_11 6 _ (by decide) (by decide)).trans (hhit_p f idx hidx),
                fun t_tbl i ht => (hmp5_non0_11 t_tbl i (fun h => ht (by simp [h])) (fun h => ht (by simp [h]))).trans
                  (hwp_pres t_tbl i ht),
                (hrp5 17 10).trans ((hrp4 17 10).trans ((hrp3 17 10).trans ((hrp2 17 10).trans ((hrp1 17 10).trans hrp_10)))),
                fun c => (hrp5 3 _).trans ((hrp4 3 _).trans ((hrp3 3 _).trans ((hrp2 3 _).trans ((hrp1 3 _).trans (hrp_3 c))))),
                fun t_tbl i ht3 ht17 => (hrp5 t_tbl i).trans ((hrp4 t_tbl i).trans ((hrp3 t_tbl i).trans
                  ((hrp2 t_tbl i).trans ((hrp1 t_tbl i).trans (hrp_pres t_tbl i ht3 ht17)))))⟩
              -- Update `VisCur` with `(j_p, τ_q)`
              intro hneg5
              rw [hw00_mp5] at hneg5
              rcases hneg_p3 hneg5 with ⟨hneg_mp, hnacc_jp⟩
              rcases hvis_p hneg_mp with ⟨hw00_mq, hrej_cur, VisCur, hcard_cur, hmem_cur⟩
              have hrej_next : ∀ p' < pos + 1, ∀ j' : Fin m,
                  wRead mem₀ 25 (((b_q * (R * m + 1) + p' : ℕ)) : ℤ) = ((pairIdx rFin j').val : ℤ) →
                  ¬ accept (dec j') := by
                intro p' hp' j' h25_j'
                rcases Nat.lt_succ_iff_lt_or_eq.mp hp' with hlt | rfl
                · exact hrej_cur p' hlt j' h25_j'
                · have hp_val : (((pairIdx rFin j_p).val : ℕ) : ℤ) = (((pairIdx rFin j').val : ℕ) : ℤ) :=
                    h25_pair.symm.trans h25_j'
                  have hp_eq : pairIdx rFin j_p = pairIdx rFin j' := Fin.ext (by exact_mod_cast hp_val)
                  rcases pairIdx_inj hp_eq with ⟨_, rfl⟩
                  exact hnacc_jp
              have hnot_in : (j_p, τ_q) ∉ VisCur := by
                intro hin
                rcases hmem_cur _ hin with ⟨_, _, _, _, p', hp'_lt, h25_p'⟩
                have hp'_len : p' < (AllPairs.filter (fun p => globalDataBkt hm t ω ptsK p.1 p.2 = b_q)).card :=
                  lt_trans hp'_lt hpos_len
                rcases hinv.buckets.bwd b_q p' hp'_len with
                  ⟨pair_p', slot_p', hmem_p', hbkt_p', h25_bwd, _, h23_p'⟩
                have hp_eq_val : ((pair_p'.val : ℕ) : ℤ) = (((pairIdx rFin j_p).val : ℕ) : ℤ) :=
                  h25_bwd.symm.trans h25_p'
                have hp_eq : pair_p' = pairIdx rFin j_p := Fin.ext (by exact_mod_cast hp_eq_val)
                subst hp_eq
                have hs_eq : slot_p' = slot_p :=
                  hbkt_inj_act hmem_p' hmem_pair (hbkt_p'.trans hbkt_pair.symm)
                subst hs_eq
                have hpos_eq : (p' : ℤ) = (pos : ℤ) := h23_p'.symm.trans h23_pair
                omega
              refine ⟨hw00_mq, hrej_next, insert (j_p, τ_q) VisCur,
                by rw [Finset.card_insert_of_notMem hnot_in, hcard_cur], ?_⟩
              intro jt hjt
              rcases Finset.mem_insert.mp hjt with rfl | hold
              · exact ⟨hj_p_act, hnacc_jp, hshared_jp, rfl, pos, Nat.lt_succ_self pos, h25_pair⟩
              · rcases hmem_cur jt hold with ⟨h1, h2, h3, h4, p', hp', h25_p'⟩
                exact ⟨h1, h2, h3, h4, p', Nat.lt_succ_of_lt hp', h25_p'⟩)
            with ⟨mqa8, ⟨hexqa8, hwqa8_0, hwqa8_8, hwqa8_14, hwqa8_15, _, _, hans_qa8, hvis_qa8,
                   hcnt_qa8, hhit_qa8, hwqa8_pres, hrqa8_10, hrqa8_3, hrqa8_pres⟩, sPosLoop⟩

          -- q9. w[11, 15] := q_idx + 1
          have hwqa8_15' : mqa8.words.read (.heap 11 15) = (q_idx : ℤ) := hwqa8_15
          rcases exec_wSet_sw SW SR inp sPosLoop.2.1 11 (.lit 15) 15 (mem_ASW_11 (i := 15) (by omega))
            (.add qIdxE (.lit 1)) (((q_idx + 1 : ℕ) : ℤ)) 10
            (by simp [evalIntExpr]) (by simp [evalIntExpr, qIdxE, hwqa8_15']) (by simp [evalIntExpr, qIdxE])
            with ⟨mqa9, sqa9, hexqa9, hwqa9_15, hwqa9_ne, hrqa9⟩

          have hsteps_next : prevSteps + take_b = qStepCount Cap_q lenOf (q_idx + 1) := by
            dsimp only [prevSteps]
            rw [htake_diff]
            exact Nat.add_sub_of_le (qStepCount_mono Cap_q lenOf q_idx)

          have sqIdxStep : ExecStmt inp qIdxBody mq mqa9
              ((105 + ℓ * 60) + 60 * (qStepCount Cap_q lenOf (q_idx + 1) - qStepCount Cap_q lenOf q_idx)) := by
            unfold qIdxBody seqStmts
            have hcost_q : 6 + ((25 + ℓ * 60) + (12 + (10 + (12 + (15 + (4 + ((5 + take_b * 60) + 10))))))) ≤
                (105 + ℓ * 60) + 60 * (qStepCount Cap_q lenOf (q_idx + 1) - qStepCount Cap_q lenOf q_idx) := by
              rw [← htake_diff]; omega
            exact (ExecStmt.seq sqa1 (ExecStmt.seq sqa2 (ExecStmt.seq sqa3
              (ExecStmt.seq sqa4 (ExecStmt.seq sqa5 (ExecStmt.seq sqa6
                (ExecStmt.seq sqa7 (ExecStmt.seq sPosLoop sqa9)))))))).mono_cost hcost_q

          have hw00_9 : wRead mqa9 0 0 = wRead mqa8 0 0 := hwqa9_ne 0 0 (Or.inl (by decide))
          refine ⟨mqa9, sqIdxStep, by linarith [hexqa9, hexqa8],
            (hwqa9_ne 11 0 (Or.inr (by decide))).trans hwqa8_0,
            (hwqa9_ne 11 8 (Or.inr (by decide))).trans hwqa8_8,
            (hwqa9_ne 11 14 (Or.inr (by decide))).trans (by rw [← hsteps_next]; exact hwqa8_14),
            hwqa9_15,
            by rw [hw00_9]; exact hans_qa8,
            ?_,
            fun f => (hwqa9_ne 6 _ (Or.inl (by decide))).trans (hcnt_qa8 f),
            fun f idx hidx => (hwqa9_ne 6 _ (Or.inl (by decide))).trans (hhit_qa8 f idx hidx),
            fun t_tbl i ht => (hwqa9_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans (hwqa8_pres t_tbl i ht),
            (hrqa9 17 10).trans hrqa8_10,
            fun c => (hrqa9 3 _).trans (hrqa8_3 c),
            fun t_tbl i ht3 ht17 => (hrqa9 t_tbl i).trans (hrqa8_pres t_tbl i ht3 ht17)⟩
          -- Merge `Vis` (for `< q_idx`) and `VisCur` (at `q_idx`)!
          intro hneg9
          rw [hw00_9] at hneg9
          rcases hvis_qa8 hneg9 with ⟨hneg_mq, hrej_cur, VisCur, hcard_cur, hmem_cur⟩
          rcases hvis_q hneg_mq with ⟨hw00_mr, hrej_prev, VisPrev, hcard_prev, hmem_prev⟩
          have hrej_all : ∀ (q' : ℕ) (_hq' : q' < q_idx + 1) (hq'_lt : q' < Q) (pos' : ℕ),
              pos' < min (lenOf q') (Cap_q + 1 - qStepCount Cap_q lenOf q') →
              ∀ j' : Fin m,
                wRead mem₀ 25 (((bktFor q' hq'_lt * (R * m + 1) + pos' : ℕ)) : ℤ) = ((pairIdx rFin j').val : ℤ) →
                ¬ accept (dec j') := by
            intro q' hq' hq'_lt pos' hpos' j' h25_j'
            rcases Nat.lt_succ_iff_lt_or_eq.mp hq' with hlt | rfl
            · exact hrej_prev q' hlt hq'_lt pos' hpos' j' h25_j'
            · exact hrej_cur pos' hpos' j' h25_j'
          have hdisj : Disjoint VisPrev VisCur := by
            rw [Finset.disjoint_left]
            intro jt hprev hcur
            rcases hmem_prev jt hprev with ⟨_, _, _, q', hq'_p, hq'_lt, hjt2_prev⟩
            rcases hmem_cur jt hcur with ⟨_, _, _, hjt2_cur, _⟩
            have henum_eq : enumTuple qpass q' hq'_p = enumTuple qpass q_idx hq_prod :=
              hjt2_prev.symm.trans hjt2_cur
            have hq_eq : q' = q_idx := enumTuple_injective qpass hq'_p hq_prod henum_eq
            omega
          refine ⟨hw00_mr, hrej_all, VisPrev ∪ VisCur, ?_, ?_⟩
          · rw [Finset.card_union_of_disjoint hdisj, hcard_prev, hcard_cur, hsteps_next]
          · intro jt hjt
            rcases Finset.mem_union.mp hjt with hp | hc
            · rcases hmem_prev jt hp with ⟨h1, h2, h3, q', hq'_p, hq'_lt, h4⟩
              exact ⟨h1, h2, h3, q', hq'_p, Nat.lt_succ_of_lt hq'_lt, h4⟩
            · rcases hmem_cur jt hc with ⟨h1, h2, h3, h4, _⟩
              exact ⟨h1, h2, by rw [h4]; exact h3, q_idx, hq_prod, Nat.lt_succ_self q_idx, h4⟩)
        with ⟨mr5, ⟨hex_r5, hwr5_0, _, _, _, hans_r5, hvis_r5, _, _, hwr5_pres,
               hrr5_10, hrr5_3, hrr5_pres⟩, sQLoop⟩

      -- r6. w[11, 0] := r_idx + 1
      have hwr5_0' : mr5.words.read (.heap 11 0) = (r_idx : ℤ) := hwr5_0
      rcases exec_wSet_sw SW SR inp sQLoop.2.1 11 (.lit 0) 0 (mem_ASW_11 (i := 0) (by omega))
        (.add rE (.lit 1)) (((r_idx + 1 : ℕ) : ℤ)) 10
        (by simp [evalIntExpr]) (by simp [evalIntExpr, rE, hwr5_0']) (by simp [evalIntExpr, rE])
        with ⟨mr6, sr6, hex_r6, hwr6_0, hwr6_ne, hrr6⟩

      have hcost_rq : (20 + ℓ * 40 + ℓ * M₀ * (130 + (50 + d * 30))) +
          ((15 + ℓ * 40) + (4 + (4 + ((5 + Q * (105 + ℓ * 60) +
            60 * (qStepCount Cap_q lenOf Q - qStepCount Cap_q lenOf 0)) + 10)))) ≤
          rQueryCost := by
        dsimp [rQueryCost]
        have h1 : Q * (105 + ℓ * 60) ≤ Cap_q * (105 + ℓ * 60) := Nat.mul_le_mul_right _ hQ_le_Capq
        have h2 : qStepCount Cap_q lenOf Q ≤ Cap_q + 1 := qStepCount_le_cap Cap_q lenOf Q
        have h3 : ℓ * M₀ * (130 + (50 + d * 30)) = ℓ * M₀ * (180 + d * 30) := by ring
        have h4 : Cap_q * (165 + ℓ * 60) = Cap_q * (105 + ℓ * 60) + Cap_q * 60 := by ring
        omega

      have sRQueryStep : ExecStmt inp rQueryBody mr mr6 rQueryCost := by
        unfold rQueryBody seqStmts
        exact (ExecStmt.seq sr1 (ExecStmt.seq sr2 (ExecStmt.seq sr3
          (ExecStmt.seq sr4 (ExecStmt.seq sQLoop sr6))))).mono_cost hcost_rq

      have hw00_mr6 : wRead mr6 0 0 = wRead mr5 0 0 := hwr6_ne 0 0 (Or.inl (by decide))

      refine ⟨mr6, sRQueryStep, by linarith [hex_r6, hex_r5], hwr6_0,
        by rw [hw00_mr6]; exact hans_r5,
        ?_,
        (hrr6 17 10).trans hrr5_10,
        fun c => (hrr6 3 _).trans (hrr5_3 c),
        fun t_tbl i ht => (hwr6_ne t_tbl i (Or.inl (fun h => ht (by simp [h])))).trans (hwr5_pres t_tbl i ht),
        fun t_tbl i ht3 ht17 => (hrr6 t_tbl i).trans (hrr5_pres t_tbl i ht3 ht17)⟩

      -- Prove `CopyComplete` for `< r_idx + 1` when `wRead mr6 0 0 = -1`!
      intro hneg6 r' hr'_lt
      rw [hw00_mr6] at hneg6
      rcases hvis_r5 hneg6 with ⟨hneg_mr, hrej_Q, Vis, hVis_card, hVis_mem⟩
      rcases Nat.lt_succ_iff_lt_or_eq.mp hr'_lt with hlt | heq
      · exact hcomp_prev hneg_mr r' hlt
      · have hr'_eq : r' = rFin := Fin.ext heq
        subst hr'_eq
        intro j_star hj_star_act hdata_le hquery_le hbad_le hcompat ⟨τ_star, hdata_star, hquery_star⟩
        let BadSet := Finset.univ.filter (fun kt : Fin m × (Fin ℓ → Fin M₀) =>
          inner ℝ (ptsK kt.1) padQ ≤ 0 ∧ IsSharedTuple x t (ω rFin) (ptsK kt.1) padQ kt.2)
        have hVis_sub : Vis ⊆ BadSet := by
          intro kt hkt
          rcases hVis_mem kt hkt with ⟨hkt_act, hnacc_kt, hsh_kt, _⟩
          have hdec_in_P : dec kt.1 ∈ P := Finset.mem_image_of_mem dec hkt_act
          have hinner_le0 : inner ℝ (ptsK kt.1) padQ ≤ 0 := hcompat (dec kt.1) hdec_in_P hnacc_kt
          exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hinner_le0, hsh_kt⟩
        have hsteps_lt_cap1 : qStepCount Cap_q lenOf Q < Cap_q + 1 := by
          have hcard_le : Vis.card ≤ BadSet.card := Finset.card_le_card hVis_sub
          have hBad_eq : BadSet.card = badSharedCard x t ptsK padQ (ω rFin) := rfl
          omega
        have hqprod_eq : prefixProd qcnt_fn ℓ = queryTupleCard x t (ω rFin) padQ :=
          queryProd_eq_queryTupleCard x t (ω rFin) padQ
        rcases enumTuple_surjective qpass τ_star hquery_star with ⟨q_star, hq_star_prod, hτ_star_eq⟩
        have hQ_eq : Q = prefixProd qcnt_fn ℓ := by
          dsimp [Q]; rw [hqprod_eq]; exact Nat.min_eq_right hquery_le
        have hq_star_lt : q_star < Q := by rwa [hQ_eq]
        let dpass_star := dataPassPred t (ω rFin) (ptsK j_star)
        let dcnt_star : ℕ → ℕ := fun f => if hf : f < ℓ then (hitList (dpass_star ⟨f, hf⟩)).length else 1
        have hdprod_eq : prefixProd dcnt_star ℓ = dataTupleCard t (ω rFin) (ptsK j_star) :=
          dataProd_eq_dataTupleCard t (ω rFin) (ptsK j_star)
        rcases enumTuple_surjective dpass_star τ_star hdata_star with ⟨s_star, hs_star_prod, hs_star_eq⟩
        have hs_star_bound : s_star < dataSlotBound Cap_u t (ω rFin) (ptsK j_star) := by
          unfold dataSlotBound
          rw [Nat.lt_min]
          exact ⟨lt_of_lt_of_le (by rwa [← hdprod_eq]) hdata_le, hs_star_prod⟩
        have hmem_star : (pairIdx rFin j_star, s_star) ∈ AllPairs :=
          mem_activePairsOf_iff.mpr ⟨rFin, Finset.mem_univ _, j_star, hj_star_act, rfl, hs_star_bound⟩
        have hbkt_star : globalDataBkt hm t ω ptsK (pairIdx rFin j_star) s_star =
            bktFor q_star hq_star_lt := by
          rw [globalDataBkt_pairIdx]
          dsimp [bktFor]
          congr 1
          unfold localDataBkt
          rw [dif_pos hs_star_prod, hs_star_eq, hτ_star_eq]
        rcases hinv.buckets.fwd (pairIdx rFin j_star) s_star hmem_star with
          ⟨_, pos_star, hpos_star_lt, _, h25_star, _⟩
        rw [hbkt_star] at hpos_star_lt h25_star
        have hlen_qstar : (AllPairs.filter (fun p =>
            globalDataBkt hm t ω ptsK p.1 p.2 = bktFor q_star hq_star_lt)).card = lenOf q_star := by
          simp [lenOf, hq_star_lt]
        have hstep_qstar : qStepCount Cap_q lenOf (q_star + 1) ≤ qStepCount Cap_q lenOf Q :=
          qStepCount_mono_le Cap_q lenOf (Nat.succ_le_of_lt hq_star_lt)
        have hstep_succ_eq : qStepCount Cap_q lenOf (q_star + 1) =
            min (Cap_q + 1) (qStepCount Cap_q lenOf q_star + lenOf q_star) := rfl
        have hpos_star_take : pos_star < min (lenOf q_star) (Cap_q + 1 - qStepCount Cap_q lenOf q_star) := by
          rw [hlen_qstar] at hpos_star_lt
          rw [Nat.lt_min]
          exact ⟨hpos_star_lt, by omega⟩
        have hnacc_star : ¬ accept (dec j_star) :=
          hrej_Q q_star hq_star_lt hq_star_lt pos_star hpos_star_take j_star h25_star
        exact hcompat (dec j_star) (Finset.mem_image_of_mem dec hj_star_act) hnacc_star)
    with ⟨mem₁, ⟨hex_out, _, hans_out, hcomp_out, _, _, hwr_out, hrr_out⟩, sRLoop⟩

  -- Assemble full `ExecStmt`, cost bound, `DataStructInv`, and search answer properties!
  have sTot := ExecStmt.seq sq1 (ExecStmt.seq sq2 (ExecStmt.seq sq3
    (ExecStmt.seq sKCopyLoop (ExecStmt.seq sq5 (ExecStmt.seq sq6 sRLoop)))))
  refine ⟨mem₁, _, (by unfold queryProg seqStmts; exact sTot), ?_, ?_, ?_⟩
  · dsimp [rQueryCost]
    push_cast
    linarith [hCrnd_ub]
  · refine
      { clean := sRLoop.2.1
        sub_act := hinv.sub_act
        extra_le := hex_out.trans hinv.extra_le
        hdr_Rm := (hwr_out 1 0 (by decide)).trans hinv.hdr_Rm
        hdr_m := (hwr_out 1 1 (by decide)).trans hinv.hdr_m
        hdr_R := (hwr_out 1 2 (by decide)).trans hinv.hdr_R
        hdr_Capu := (hwr_out 1 3 (by decide)).trans hinv.hdr_Capu
        hdr_M0 := (hwr_out 1 4 (by decide)).trans hinv.hdr_M0
        hdr_M0pow := (hwr_out 1 5 (by decide)).trans hinv.hdr_M0pow
        hdr_Capq := (hwr_out 1 6 (by decide)).trans hinv.hdr_Capq
        hdr_etaN := (hwr_out 1 7 (by decide)).trans hinv.hdr_etaN
        hdr_etaD := (hwr_out 1 8 (by decide)).trans hinv.hdr_etaD
        hdr_xt := (hrr_out 1 0 (by decide) (by decide)).trans hinv.hdr_xt
        hdr_t := (hrr_out 1 1 (by decide) (by decide)).trans hinv.hdr_t
        hdr_A := (hrr_out 1 2 (by decide) (by decide)).trans hinv.hdr_A
        hdr_B := (hrr_out 1 3 (by decide) (by decide)).trans hinv.hdr_B
        gauss := fun r c coord =>
          (hrr_out 2 _ (by decide) (by decide)).trans (hinv.gauss r c coord)
        slot_cnt := fun r j hj =>
          (hwr_out 21 _ (by decide)).trans (hinv.slot_cnt r j hj)
        buckets := bucketInv_congr hinv.buckets (fun t_tbl idx h22 _ =>
          hwr_out t_tbl idx (by simp; omega)) }
  · intro rawAns ans
    have hvalid_and_none : IsValidSearchAnswer P accept ans ∧ (ans = none → rawAns = -1) := by
      rcases hans_out with hneg | ⟨j_ans, hj_eq, hj_act, hj_acc⟩
      · have hn : ¬ (0 ≤ rawAns ∧ rawAns.toNat < m) := by
          have : rawAns = -1 := hneg
          omega
        have hans_eq : ans = none := dif_neg hn
        exact ⟨by rw [hans_eq]; trivial, fun _ => hneg⟩
      · have hp : 0 ≤ rawAns ∧ rawAns.toNat < m := by
          have : rawAns = (j_ans.val : ℤ) := hj_eq
          have := j_ans.isLt
          omega
        have hfin_eq : (⟨rawAns.toNat, hp.2⟩ : Fin m) = j_ans := by
          have hraw_eq : rawAns = (j_ans.val : ℤ) := hj_eq
          apply Fin.ext
          change rawAns.toNat = j_ans.val
          rw [hraw_eq]
          exact Int.toNat_natCast j_ans.val
        have hans_eq : ans = some (dec j_ans) := by
          dsimp [ans]
          rw [dif_pos hp, hfin_eq]
        refine ⟨?_, fun hnone => by rw [hans_eq] at hnone; cases hnone⟩
        rw [hans_eq]
        exact ⟨Finset.mem_image_of_mem dec hj_act, hj_acc⟩
    have hcorr_fn : ω ∈ E → IsCompatibleTest padPts P padQ accept →
        IsCorrectSearchAnswer padPts P h padQ accept ans := by
      intro hωE hcompat
      refine ⟨hvalid_and_none.1, ?_⟩
      intro hans_none ⟨i_star, hi_star_P, hh_le_inner⟩
      have hraw_neg1 : rawAns = -1 := hvalid_and_none.2 hans_none
      rcases Finset.mem_image.mp hi_star_P with ⟨j_star, hj_star_act, rfl⟩
      have hj_star_P0 : dec j_star ∈ P₀ := hdec_mem j_star
      rcases hωE z_hat hz_hat_net (dec j_star) hj_star_P0 with ⟨r_star, hr_gs⟩
      dsimp [gs, goodSingleSet] at hr_gs
      have hcond : h ≤ inner ℝ (padPts (dec j_star)) (padQuery z_hat) ∧
          dec j_star ∈ P₀ ∧ IsUnitVec z_hat :=
        ⟨hh_le_inner, hj_star_P0, hz_hat_unit⟩
      rw [if_pos hcond] at hr_gs
      rcases hr_gs with ⟨hsh_star, hdu_star, hqu_star, hbad_star⟩
      have hle0 : inner ℝ (ptsK j_star) padQ ≤ 0 :=
        hcomp_out hraw_neg1 r_star r_star.isLt j_star hj_star_act hdu_star hqu_star hbad_star hcompat hsh_star
      dsimp [ptsK, padQ] at hle0
      linarith
    refine ⟨hvalid_and_none.1, hcorr_fn, ?_⟩
    intro hωE hrej_orig hans_none i hi_P
    have hcompat : IsCompatibleTest padPts P padQ accept := by
      intro i' hi'_P hnacc_i'
      rcases Finset.mem_image.mp hi'_P with ⟨j', _, rfl⟩
      have hu_i' : IsUnitVec (u_pts (dec j')) := hu_unit (dec j') (hdec_mem j')
      have h_le_b : inner ℝ z (u_pts (dec j')) ≤ b := hrej_orig (dec j') hi'_P hnacc_i'
      have hlt0 := (hAB_props (u_pts (dec j')) z z_hat hu_i' hz hz_hat_unit hdist_z).2 h_le_b
      rw [real_inner_comm]
      exact le_of_lt hlt0
    have hno_tgt : ¬ HasSearchTarget padPts P h padQ := (hcorr_fn hωE hcompat).2 hans_none
    by_contra hnot_lt
    have ha_le : a ≤ inner ℝ z (u_pts i) := le_of_not_gt hnot_lt
    rcases Finset.mem_image.mp hi_P with ⟨j_i, _, rfl⟩
    have hu_i : IsUnitVec (u_pts (dec j_i)) := hu_unit (dec j_i) (hdec_mem j_i)
    have hh_le := (hAB_props (u_pts (dec j_i)) z z_hat hu_i hz hz_hat_unit hdist_z).1 ha_le
    have hh_le' : h ≤ inner ℝ (padPts (dec j_i)) padQ := by
      dsimp [padPts, padData, padQ, padQuery]
      rwa [real_inner_comm]
    exact hno_tgt ⟨dec j_i, hi_P, hh_le'⟩

end UL.Proof_clm_6_1_adaptive_RaceP32
