import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_6_search_interface
import UL.Def.def_6_1_gaussian_filter
import UL.Proof.lem_6_3.H1_RAM
import UL.Proof.clm_6_1_adaptive.H1a_Net
set_option autoImplicit false

namespace UL.Proof_clm_6_1_adaptive

open UL.Proof_lem_6_3

/-! ### 1. Dyadic bisection for Lemma 5.6 rational lift `(A, B)` -/

/-- Rational ratio `B(v)^2 / A(v)^2 = 4 v^2 / (1 - v^2)^2`. -/
def fRatioRat (v : ℚ) : ℚ :=
  4 * v ^ 2 / (1 - v ^ 2) ^ 2

/-- Real ratio `4 v^2 / (1 - v^2)^2`. -/
noncomputable def fRatioReal (v : ℝ) : ℝ :=
  4 * v ^ 2 / (1 - v ^ 2) ^ 2

theorem fRatioRat_cast (v : ℚ) : (fRatioRat v : ℝ) = fRatioReal (v : ℝ) := by
  unfold fRatioRat fRatioReal
  push_cast
  rfl

theorem fRatioReal_lip {u w : ℝ} (hu0 : 0 ≤ u) (huw : u ≤ w) (hw : w ≤ 1 / 2) :
    0 ≤ fRatioReal w - fRatioReal u ∧ fRatioReal w - fRatioReal u ≤ 16 * (w - u) := by
  unfold fRatioReal
  have hu2 : u ^ 2 ≤ 1 / 4 := by nlinarith
  have hw2 : w ^ 2 ≤ 1 / 4 := by nlinarith
  have h1u : 3 / 4 ≤ 1 - u ^ 2 := by linarith
  have h1w : 3 / 4 ≤ 1 - w ^ 2 := by linarith
  have h1u_pos : 0 < (1 - u ^ 2) ^ 2 := by positivity
  have h1w_pos : 0 < (1 - w ^ 2) ^ 2 := by positivity
  have hden_pos : 0 < (1 - w ^ 2) ^ 2 * (1 - u ^ 2) ^ 2 := mul_pos h1w_pos h1u_pos
  have hdiff :
      4 * w ^ 2 / (1 - w ^ 2) ^ 2 - 4 * u ^ 2 / (1 - u ^ 2) ^ 2 =
        (4 * (w - u) * (w + u) * (1 - u ^ 2 * w ^ 2)) /
          ((1 - w ^ 2) ^ 2 * (1 - u ^ 2) ^ 2) := by
    field_simp [h1w_pos.ne', h1u_pos.ne']
    ring
  rw [hdiff]
  have hwu_nn : 0 ≤ w - u := by linarith
  have hsum_le : w + u ≤ 1 := by linarith
  have hsum_nn : 0 ≤ w + u := by linarith
  have hprod_le : u ^ 2 * w ^ 2 ≤ 1 / 16 := by nlinarith [sq_nonneg u, sq_nonneg w]
  have hprod_nn : 0 ≤ 1 - u ^ 2 * w ^ 2 := by linarith
  have hprod_ub : 1 - u ^ 2 * w ^ 2 ≤ 1 := by nlinarith [sq_nonneg u, sq_nonneg w]
  have hnum_nn : 0 ≤ 4 * (w - u) * (w + u) * (1 - u ^ 2 * w ^ 2) := by positivity
  have hnum_ub : 4 * (w - u) * (w + u) * (1 - u ^ 2 * w ^ 2) ≤ 4 * (w - u) := by
    have h1 : (w + u) * (1 - u ^ 2 * w ^ 2) ≤ 1 * 1 :=
      mul_le_mul hsum_le hprod_ub hprod_nn (by norm_num)
    nlinarith
  have hden_lb : (1 / 4 : ℝ) ≤ (1 - w ^ 2) ^ 2 * (1 - u ^ 2) ^ 2 := by
    have h1 : (9 / 16 : ℝ) ≤ (1 - w ^ 2) ^ 2 := by nlinarith
    have h2 : (9 / 16 : ℝ) ≤ (1 - u ^ 2) ^ 2 := by nlinarith
    have h3 : (9 / 16 : ℝ) * (9 / 16) ≤ (1 - w ^ 2) ^ 2 * (1 - u ^ 2) ^ 2 :=
      mul_le_mul h1 h2 (by norm_num) (by positivity)
    linarith
  refine ⟨div_nonneg hnum_nn hden_pos.le, ?_⟩
  rw [div_le_iff₀ hden_pos]
  nlinarith

/-- One rational bisection step on `(lo, hi)`. -/
def bisectABStep (target : ℚ) (lh : ℚ × ℚ) : ℚ × ℚ :=
  let mid : ℚ := (lh.1 + lh.2) / 2
  if fRatioRat mid ≤ target then (mid, lh.2) else (lh.1, mid)

/-- `k` steps of rational bisection starting at `(0, 1/2)`. -/
def bisectABIter (target : ℚ) : ℕ → ℚ × ℚ
  | 0 => (0, 1 / 2)
  | k + 1 => bisectABStep target (bisectABIter target k)

theorem bisectABIter_props {target : ℚ}
    (ht0 : (0 : ℝ) ≤ (target : ℝ)) (ht1 : (target : ℝ) ≤ 16 / 9) (k : ℕ) :
    let lh := bisectABIter target k
    0 ≤ (lh.1 : ℝ) ∧
    (lh.1 : ℝ) ≤ (lh.2 : ℝ) ∧
    (lh.2 : ℝ) ≤ 1 / 2 ∧
    (lh.2 : ℝ) - (lh.1 : ℝ) = 1 / (2 * (2 : ℝ) ^ k) ∧
    fRatioReal (lh.1 : ℝ) ≤ (target : ℝ) ∧
    (target : ℝ) ≤ fRatioReal (lh.2 : ℝ) := by
  induction k with
  | zero =>
      simp only [bisectABIter, Rat.cast_zero, Rat.cast_div, Rat.cast_one, Rat.cast_ofNat, pow_zero]
      have hf0 : fRatioReal 0 = 0 := by unfold fRatioReal; norm_num
      have hfhalf : fRatioReal (1 / 2) = 16 / 9 := by unfold fRatioReal; norm_num
      refine ⟨by norm_num, by norm_num, by norm_num, by norm_num, ?_, ?_⟩
      · linarith
      · linarith
  | succ k ih =>
      rcases ih with ⟨hlo0, hlohi, hhi_half, hlen, hflo, hfhi⟩
      dsimp only [bisectABIter, bisectABStep]
      set lh := bisectABIter target k
      let mid : ℚ := (lh.1 + lh.2) / 2
      have hmid_r : (mid : ℝ) = ((lh.1 : ℝ) + (lh.2 : ℝ)) / 2 := by dsimp [mid]; push_cast; ring
      split_ifs with hcond
      · have hcond_r : fRatioReal (mid : ℝ) ≤ (target : ℝ) := by
          rw [← fRatioRat_cast]
          exact_mod_cast hcond
        refine ⟨?_, ?_, hhi_half, ?_, hcond_r, hfhi⟩
        · rw [hmid_r]; linarith
        · rw [hmid_r]; linarith
        · rw [hmid_r, pow_succ']
          calc (lh.2 : ℝ) - ((lh.1 : ℝ) + (lh.2 : ℝ)) / 2
              = ((lh.2 : ℝ) - (lh.1 : ℝ)) / 2 := by ring
            _ = (1 / (2 * (2 : ℝ) ^ k)) / 2 := by rw [hlen]
            _ = 1 / (2 * (2 * (2 : ℝ) ^ k)) := by ring
      · have hcond_r : (target : ℝ) ≤ fRatioReal (mid : ℝ) := by
          have hgt : target < fRatioRat mid := lt_of_not_ge hcond
          have hgt_r : (target : ℝ) < (fRatioRat mid : ℝ) := by exact_mod_cast hgt
          rw [fRatioRat_cast] at hgt_r
          exact hgt_r.le
        refine ⟨hlo0, ?_, ?_, ?_, hflo, hcond_r⟩
        · rw [hmid_r]; linarith
        · rw [hmid_r]; linarith
        · rw [hmid_r, pow_succ']
          calc ((lh.1 : ℝ) + (lh.2 : ℝ)) / 2 - (lh.1 : ℝ)
              = ((lh.2 : ℝ) - (lh.1 : ℝ)) / 2 := by ring
            _ = (1 / (2 * (2 : ℝ) ^ k)) / 2 := by rw [hlen]
            _ = 1 / (2 * (2 * (2 : ℝ) ^ k)) := by ring

theorem exists_bisectCount {η : ℚ} (h : 0 < η) :
    ∃ j : ℕ, 32 ≤ ((2 ^ (j + 1) : ℕ) : ℝ) * (η : ℝ) := by
  have hη_r : (0 : ℝ) < (η : ℝ) := by exact_mod_cast h
  let N := Nat.ceil (32 / (η : ℝ))
  refine ⟨N, ?_⟩
  have h1 : 32 / (η : ℝ) ≤ (N : ℝ) := Nat.le_ceil _
  have h2 : (N : ℝ) ≤ ((2 ^ (N + 1) : ℕ) : ℝ) := by
    have := nat_cast_le_two_pow (N + 1)
    push_cast at this ⊢
    linarith
  have h3 : 32 / (η : ℝ) ≤ ((2 ^ (N + 1) : ℕ) : ℝ) := h1.trans h2
  exact (div_le_iff₀ hη_r).mp h3

/-- Number of doublings from `P = 2` (`K = 1`) until `(2^K : ℝ) * (η : ℝ) ≥ 32`. -/
noncomputable def bisectCount (η : ℚ) : ℕ :=
  open Classical in
  if h : 0 < η then Nat.find (exists_bisectCount h) + 1 else 1

/-- Rational `(A, B)` pair selected by `bisectCount η` dyadic bisection steps. -/
noncomputable def chooseAB (b η : ℚ) : ℚ × ℚ :=
  let K := bisectCount η
  let target : ℚ := b + (9 / 2) * η
  let v : ℚ := (bisectABIter target K).2
  ((1 - v ^ 2) / (1 + v ^ 2), (2 * v) / (1 + v ^ 2))

theorem bisectCount_props {d : ℕ} (hd : 1 ≤ d) {η : ℚ}
    (hη0 : 0 < η) (hη16 : (η : ℝ) ≤ 1 / 16) :
    let K := bisectCount η
    1 ≤ K ∧
    32 ≤ ((2 ^ K : ℕ) : ℝ) * (η : ℝ) ∧
    (∀ j : ℕ, 1 ≤ j → j < K → ((2 ^ j : ℕ) : ℝ) * (η : ℝ) < 32) ∧
    (K : ℝ) ≤ 8 * Real.log ((d : ℝ) / (η : ℝ)) := by
  classical
  dsimp only
  have hK_eq : bisectCount η = Nat.find (exists_bisectCount hη0) + 1 := by
    unfold bisectCount; rw [dif_pos hη0]
  rw [hK_eq]
  set j₀ := Nat.find (exists_bisectCount hη0)
  have hj₀_spec : 32 ≤ ((2 ^ (j₀ + 1) : ℕ) : ℝ) * (η : ℝ) := Nat.find_spec (exists_bisectCount hη0)
  have hj₀_min : ∀ i < j₀, ((2 ^ (i + 1) : ℕ) : ℝ) * (η : ℝ) < 32 :=
    fun i hi => not_le.mp (Nat.find_min (exists_bisectCount hη0) hi)
  have hη_r : (0 : ℝ) < (η : ℝ) := by exact_mod_cast hη0
  have hd_r : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  have hquot16 : 16 ≤ (d : ℝ) / (η : ℝ) := by rw [le_div_iff₀ hη_r]; linarith
  have hlog2 : 2 ≤ Real.log ((d : ℝ) / (η : ℝ)) := by
    have hexp2 : Real.exp 2 ≤ 16 := by
      have h1 : Real.exp 2 = Real.exp 1 * Real.exp 1 := by rw [← Real.exp_add]; norm_num
      have he4 := exp_one_le_four; have he0 := (Real.exp_pos 1).le
      rw [h1]; nlinarith
    calc (2 : ℝ) = Real.log (Real.exp 2) := (Real.log_exp 2).symm
      _ ≤ Real.log ((d : ℝ) / (η : ℝ)) := Real.log_le_log (Real.exp_pos 2) (hexp2.trans hquot16)
  have hj₀_pos : 1 ≤ j₀ := by
    by_contra hj0
    have h0 : j₀ = 0 := by omega
    rw [h0] at hj₀_spec
    norm_num at hj₀_spec
    linarith
  have hK_ub : ((j₀ + 1 : ℕ) : ℝ) ≤ 8 * Real.log ((d : ℝ) / (η : ℝ)) := by
    have hprev := hj₀_min (j₀ - 1) (by omega)
    have hsub : j₀ - 1 + 1 = j₀ := by omega
    rw [hsub] at hprev
    have hpow_le : (2 : ℝ) ^ j₀ ≤ 32 * ((d : ℝ) / (η : ℝ)) := by
      have h1 : (2 : ℝ) ^ j₀ ≤ 32 / (η : ℝ) := by
        rw [le_div_iff₀ hη_r]
        push_cast at hprev
        exact hprev.le
      have h2 : 32 / (η : ℝ) ≤ 32 * ((d : ℝ) / (η : ℝ)) := by
        rw [← mul_div_assoc]
        exact div_le_div_of_nonneg_right (by linarith) hη_r.le
      exact h1.trans h2
    have hexp_half : Real.exp ((j₀ : ℝ) / 2) ≤ (2 : ℝ) ^ j₀ := by
      calc Real.exp ((j₀ : ℝ) / 2) = Real.exp ((j₀ : ℕ) * (1 / 2 : ℝ)) := by ring_nf
        _ = (Real.exp (1 / 2 : ℝ)) ^ j₀ := Real.exp_nat_mul _ j₀
        _ ≤ (2 : ℝ) ^ j₀ := pow_le_pow_left₀ (Real.exp_pos _).le exp_half_le_two j₀
    have h32_exp5 : (32 : ℝ) ≤ Real.exp 5 := by
      have h2e : (2 : ℝ) ≤ Real.exp 1 := two_le_exp_one
      have : Real.exp 5 = (Real.exp 1) ^ 5 := by simpa using Real.exp_nat_mul 1 5
      rw [this]
      calc (32 : ℝ) = 2 ^ 5 := by norm_num
        _ ≤ (Real.exp 1) ^ 5 := pow_le_pow_left₀ (by norm_num) h2e 5
    have hexp_bound : Real.exp ((j₀ : ℝ) / 2) ≤ Real.exp (5 + Real.log ((d : ℝ) / (η : ℝ))) := by
      rw [Real.exp_add, Real.exp_log (by positivity)]
      exact (hexp_half.trans hpow_le).trans
        (mul_le_mul_of_nonneg_right h32_exp5 (by positivity))
    have hj_le : (j₀ : ℝ) / 2 ≤ 5 + Real.log ((d : ℝ) / (η : ℝ)) :=
      Real.exp_le_exp.mp hexp_bound
    push_cast
    linarith
  refine ⟨by omega, hj₀_spec, fun j hj1 hjlt => ?_, hK_ub⟩
  have hpred := hj₀_min (j - 1) (by omega)
  have hsub : j - 1 + 1 = j := by omega
  rw [hsub] at hpred
  exact hpred

/-! ### 2. Padding properties of `chooseAB b η` -/

theorem inner_lifted_eq {d : ℕ} (u v : EuclideanSpace ℝ (Fin d)) (s t : ℝ) :
    inner ℝ (WithLp.toLp 2 (@Fin.snoc d (fun _ => ℝ) (WithLp.ofLp u) s) : EuclideanSpace ℝ (Fin (d + 1)))
            (WithLp.toLp 2 (@Fin.snoc d (fun _ => ℝ) (WithLp.ofLp v) t) : EuclideanSpace ℝ (Fin (d + 1))) =
      inner ℝ u v + s * t := by
  rw [PiLp.inner_apply, Fin.sum_univ_castSucc, PiLp.inner_apply]
  simp [mul_comm]

theorem lifted_unit_and_inner {d : ℕ} (A B : ℝ) (hAB : A ^ 2 + B ^ 2 = 1)
    (u z z_hat : EuclideanSpace ℝ (Fin d)) (hu : IsUnitVec u) (hzh : IsUnitVec z_hat) :
    let pd : EuclideanSpace ℝ (Fin (d + 1)) :=
      WithLp.toLp 2 (@Fin.snoc d (fun _ => ℝ) (WithLp.ofLp (A • u)) B)
    let pq : EuclideanSpace ℝ (Fin (d + 1)) :=
      WithLp.toLp 2 (@Fin.snoc d (fun _ => ℝ) (WithLp.ofLp (A • z_hat)) (-B))
    IsUnitVec pd ∧ IsUnitVec pq ∧
    inner ℝ pq pd = A ^ 2 * inner ℝ z u - B ^ 2 + A ^ 2 * inner ℝ (z_hat - z) u := by
  intro pd pq
  have hpd : IsUnitVec pd := by
    unfold IsUnitVec at hu ⊢
    have hsq : ‖pd‖ ^ 2 = 1 := by
      rw [← real_inner_self_eq_norm_sq, inner_lifted_eq, real_inner_self_eq_norm_sq,
        norm_smul, Real.norm_eq_abs, hu, mul_one, sq_abs]
      linarith
    have hnn := norm_nonneg pd
    nlinarith
  have hpq : IsUnitVec pq := by
    unfold IsUnitVec at hzh ⊢
    have hsq : ‖pq‖ ^ 2 = 1 := by
      rw [← real_inner_self_eq_norm_sq, inner_lifted_eq, real_inner_self_eq_norm_sq,
        norm_smul, Real.norm_eq_abs, hzh, mul_one, sq_abs]
      linarith
    have hnn := norm_nonneg pq
    nlinarith
  refine ⟨hpd, hpq, ?_⟩
  rw [show pq = WithLp.toLp 2 (@Fin.snoc d (fun _ => ℝ) (WithLp.ofLp (A • z_hat)) (-B)) from rfl,
      show pd = WithLp.toLp 2 (@Fin.snoc d (fun _ => ℝ) (WithLp.ofLp (A • u)) B) from rfl,
      inner_lifted_eq, inner_smul_left, inner_smul_right]
  have hsub : inner ℝ z_hat u = inner ℝ z u + inner ℝ (z_hat - z) u := by
    rw [inner_sub_left]; ring
  simp only [RCLike.conj_to_real]
  rw [hsub]
  ring

set_option maxHeartbeats 800000 in
theorem chooseAB_padding_props {d : ℕ} (hd : 1 ≤ d)
    {a b : ℚ} {g : ℝ} {η : ℚ}
    (hb0 : (0 : ℝ) ≤ (b : ℝ)) (hba : (b : ℝ) < (a : ℝ)) (ha1 : (a : ℝ) ≤ 1)
    (hg0 : 0 < g) (hgap : g ≤ (a : ℝ) - (1 + g) * (b : ℝ))
    (hη0 : 0 < η) (hηg : (η : ℝ) ≤ g / 16) :
    let A : ℚ := (chooseAB b η).1
    let B : ℚ := (chooseAB b η).2
    let h : ℝ := g - 11 * (η : ℝ)
    let padData : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
      fun u => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • u)) (B : ℝ))
    let padQuery : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin (d + 1)) :=
      fun z_hat => WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • z_hat)) (-(B : ℝ)))
    0 < A ∧ 0 ≤ B ∧ A ^ 2 + B ^ 2 = 1 ∧
    (∀ u z z_hat : EuclideanSpace ℝ (Fin d),
      IsUnitVec u → IsUnitVec z → IsUnitVec z_hat →
      ‖z_hat - z‖ ≤ (η : ℝ) / 8 →
        IsUnitVec (padData u) ∧
        IsUnitVec (padQuery z_hat) ∧
        ((a : ℝ) ≤ inner ℝ z u → h ≤ inner ℝ (padQuery z_hat) (padData u)) ∧
        (inner ℝ z u ≤ (b : ℝ) → inner ℝ (padQuery z_hat) (padData u) < 0)) := by
  intro A B h padData padQuery
  have hη_r : (0 : ℝ) < (η : ℝ) := by exact_mod_cast hη0
  have hgb_nn : 0 ≤ g * (b : ℝ) := mul_nonneg hg0.le hb0
  have hb_le : (b : ℝ) ≤ 1 - g := by linarith
  have hg1 : g ≤ 1 := by linarith
  have hη16 : (η : ℝ) ≤ 1 / 16 := by linarith

  let K := bisectCount η
  let target : ℚ := b + (9 / 2) * η
  let lh := bisectABIter target K
  let v : ℚ := lh.2
  have hA_def : A = (1 - v ^ 2) / (1 + v ^ 2) := rfl
  have hB_def : B = (2 * v) / (1 + v ^ 2) := rfl

  have htarget_r : (target : ℝ) = (b : ℝ) + (9 / 2) * (η : ℝ) := by dsimp [target]; push_cast; ring
  have ht0 : (0 : ℝ) ≤ (target : ℝ) := by rw [htarget_r]; positivity
  have ht1 : (target : ℝ) ≤ 16 / 9 := by rw [htarget_r]; linarith
  rcases bisectABIter_props ht0 ht1 K with ⟨hlo0, hlohi, hhi_half, hlen, hflo, hfhi⟩
  rcases bisectCount_props hd hη0 hη16 with ⟨_, h2K_ge, _, _⟩

  have hv0_r : (0 : ℝ) ≤ (v : ℝ) := by linarith
  have hv_half_r : (v : ℝ) ≤ ((1 / 2 : ℚ) : ℝ) := by push_cast; linarith
  have hv0 : 0 ≤ v := by exact_mod_cast hv0_r
  have hv_half : v ≤ 1 / 2 := by exact_mod_cast hv_half_r
  have hv2_lt : v ^ 2 ≤ 1 / 4 := by nlinarith
  have h1pv2_pos : 0 < 1 + v ^ 2 := by positivity
  have h1mv2_pos : 0 < 1 - v ^ 2 := by linarith
  have hA_pos : 0 < A := by rw [hA_def]; exact div_pos h1mv2_pos h1pv2_pos
  have hB_nn : 0 ≤ B := by rw [hB_def]; exact div_nonneg (by positivity) h1pv2_pos.le
  have hAB_sq : A ^ 2 + B ^ 2 = 1 := by
    rw [hA_def, hB_def]
    field_simp [h1pv2_pos.ne']
    ring

  -- Bound `fRatioReal (v : ℝ) ∈ [b + 4η, b + 5η]`
  have hlen_le : (lh.2 : ℝ) - (lh.1 : ℝ) ≤ (η : ℝ) / 64 := by
    rw [hlen]
    have hpos_2K : (0 : ℝ) < 2 * (2 : ℝ) ^ K := by positivity
    rw [div_le_div_iff₀ hpos_2K (by norm_num)]
    push_cast at h2K_ge
    linarith
  have hflip := (fRatioReal_lip hlo0 hlohi hhi_half).2
  have hfv_lo : (b : ℝ) + 4 * (η : ℝ) ≤ fRatioReal (v : ℝ) := by
    have : (b : ℝ) + (9 / 2) * (η : ℝ) ≤ fRatioReal (v : ℝ) := by
      simpa [htarget_r] using hfhi
    linarith
  have hfv_hi : fRatioReal (v : ℝ) ≤ (b : ℝ) + 5 * (η : ℝ) := by
    have : fRatioReal (lh.1 : ℝ) ≤ (b : ℝ) + (9 / 2) * (η : ℝ) := by
      simpa [htarget_r] using hflo
    linarith

  refine ⟨hA_pos, hB_nn, hAB_sq, ?_⟩
  intro u z z_hat hu hz hzh hdist
  have hAB_r : (A : ℝ) ^ 2 + (B : ℝ) ^ 2 = 1 := by exact_mod_cast hAB_sq
  rcases lifted_unit_and_inner (A : ℝ) (B : ℝ) hAB_r u z z_hat hu hzh with
    ⟨hpd_unit, hpq_unit, hinner_pad⟩

  have herr_abs : |(A : ℝ) ^ 2 * inner ℝ (z_hat - z) u| ≤ (η : ℝ) / 8 := by
    have hcs : |inner ℝ (z_hat - z) u| ≤ ‖z_hat - z‖ * ‖u‖ := abs_real_inner_le_norm _ _
    rw [hu, mul_one] at hcs
    have hA2_le1 : (A : ℝ) ^ 2 ≤ 1 := by nlinarith
    have hA2_nn : 0 ≤ (A : ℝ) ^ 2 := sq_nonneg _
    rw [abs_mul, abs_of_nonneg hA2_nn]
    calc (A : ℝ) ^ 2 * |inner ℝ (z_hat - z) u|
        ≤ 1 * ((η : ℝ) / 8) := mul_le_mul hA2_le1 (hcs.trans hdist) (abs_nonneg _) zero_le_one
      _ = (η : ℝ) / 8 := one_mul _

  set t_ratio : ℝ := fRatioReal (v : ℝ)
  set Δ : ℝ := t_ratio - (b : ℝ)
  have hΔ_lo : 4 * (η : ℝ) ≤ Δ := by dsimp [Δ]; linarith
  have hΔ_hi : Δ ≤ 5 * (η : ℝ) := by dsimp [Δ]; linarith
  have hB2_eq : (B : ℝ) ^ 2 = t_ratio * (A : ℝ) ^ 2 := by
    have h1mv2_r : 1 - (v : ℝ) ^ 2 ≠ 0 := by exact_mod_cast h1mv2_pos.ne'
    have h1pv2_r : 1 + (v : ℝ) ^ 2 ≠ 0 := by exact_mod_cast h1pv2_pos.ne'
    dsimp [t_ratio, fRatioReal]
    rw [hA_def, hB_def]
    push_cast
    field_simp [h1mv2_r, h1pv2_r]
    ring
  have h1pt_pos : 1 ≤ 1 + t_ratio := by
    have : 0 ≤ t_ratio := by linarith
    linarith
  have h1pt_lt2 : 1 + t_ratio ≤ 2 := by
    have : t_ratio ≤ (b : ℝ) + 5 * (η : ℝ) := hfv_hi
    linarith
  have hA2_eq : (A : ℝ) ^ 2 = 1 / (1 + t_ratio) := by
    have : (1 + t_ratio) * (A : ℝ) ^ 2 = 1 := by linarith
    exact eq_div_of_mul_eq (by linarith) (by linarith)

  refine ⟨hpd_unit, hpq_unit, ?_, ?_⟩
  · intro ha_le
    have hmain : g - 10 * (η : ℝ) ≤ (A : ℝ) ^ 2 * inner ℝ z u - (B : ℝ) ^ 2 := by
      rw [hB2_eq, hA2_eq]
      have hnum : g * (1 + t_ratio) - (1 + g) * Δ ≤ inner ℝ z u - t_ratio := by
        have ht_def : t_ratio = (b : ℝ) + Δ := by dsimp [Δ]; ring
        rw [ht_def]
        linarith
      have h1 : (g * (1 + t_ratio) - (1 + g) * Δ) / (1 + t_ratio) ≤
          (inner ℝ z u - t_ratio) / (1 + t_ratio) :=
        div_le_div_of_nonneg_right hnum (by linarith)
      have h2 : (g * (1 + t_ratio) - (1 + g) * Δ) / (1 + t_ratio) =
          g - (1 + g) * Δ / (1 + t_ratio) := by
        field_simp [(by linarith : 1 + t_ratio ≠ 0)]
      have h3 : (1 + g) * Δ / (1 + t_ratio) ≤ 10 * (η : ℝ) := by
        rw [div_le_iff₀ (by linarith)]
        nlinarith
      have hrew : (1 / (1 + t_ratio)) * inner ℝ z u - t_ratio * (1 / (1 + t_ratio)) =
          (inner ℝ z u - t_ratio) / (1 + t_ratio) := by ring
      rw [hrew]
      linarith
    have herr_lo := (abs_le.mp herr_abs).1
    rw [hinner_pad]
    dsimp [h]
    linarith
  · intro hb_le
    have hmain : (A : ℝ) ^ 2 * inner ℝ z u - (B : ℝ) ^ 2 ≤ -2 * (η : ℝ) := by
      rw [hB2_eq, hA2_eq]
      have hrew : (1 / (1 + t_ratio)) * inner ℝ z u - t_ratio * (1 / (1 + t_ratio)) =
          (inner ℝ z u - t_ratio) / (1 + t_ratio) := by ring
      rw [hrew, div_le_iff₀ (by linarith)]
      have ht_def : t_ratio = (b : ℝ) + Δ := by dsimp [Δ]; ring
      nlinarith
    have herr_hi := (abs_le.mp herr_abs).2
    rw [hinner_pad]
    linarith

/-! ### 3. Sign-and-squares query cap test (eliminating `sqrt`) -/

theorem real_sign_sq_equiv {R L s : ℝ} (hs : 0 < s) :
    R * s ≤ L ↔
      (R ≤ 0 ∧ (0 ≤ L ∨ L ^ 2 ≤ R ^ 2 * s ^ 2)) ∨
      (¬ (R ≤ 0) ∧ 0 ≤ L ∧ R ^ 2 * s ^ 2 ≤ L ^ 2) := by
  by_cases hR : R ≤ 0
  · simp only [hR, true_and, not_true_eq_false, false_and, or_false]
    by_cases hL : 0 ≤ L
    · simp only [hL, true_or, iff_true]
      nlinarith
    · simp only [hL, false_or]
      push_neg at hL
      constructor
      · intro hle
        have h1 : -L ≤ -(R * s) := by linarith
        have h2 : (-L) ^ 2 ≤ (-(R * s)) ^ 2 := pow_le_pow_left₀ (by linarith) h1 2
        nlinarith
      · intro hsq
        have h1 : (-L) ^ 2 ≤ (-R * s) ^ 2 := by nlinarith
        have hRS_nn : 0 ≤ -R * s := by nlinarith
        nlinarith [sq_nonneg (-L - (-R * s))]
  · simp only [hR, false_and, not_false_eq_true, true_and, false_or]
    push_neg at hR
    constructor
    · intro hle
      have hL0 : 0 ≤ L := by nlinarith
      have hsq : (R * s) ^ 2 ≤ L ^ 2 := pow_le_pow_left₀ (by positivity) hle 2
      exact ⟨hL0, by nlinarith⟩
    · rintro ⟨hL0, hsq⟩
      nlinarith

theorem query_cap_test_lattice_iff {d : ℕ} {A B η : ℚ} (hmesh : 0 < (η : ℝ))
    {k : Fin d → ℤ} (hk : k ≠ 0)
    (mesh : ℚ) (hmesh_pos : 0 < (mesh : ℝ))
    (xt : ℝ) (G : EuclideanSpace ℝ (Fin (d + 1))) :
    let v : EuclideanSpace ℝ (Fin d) := ratPointToEuclidean (fun c => (k c : ℚ) * mesh)
    let z_hat : EuclideanSpace ℝ (Fin d) := ‖v‖⁻¹ • v
    let padQ : EuclideanSpace ℝ (Fin (d + 1)) :=
      WithLp.toLp 2 (Fin.snoc (WithLp.ofLp ((A : ℝ) • z_hat)) (-(B : ℝ)))
    let L_val : ℝ := (A : ℝ) * ∑ c : Fin d, euclideanCoord G c.castSucc * (k c : ℝ)
    let R_val : ℝ := xt + (B : ℝ) * euclideanCoord G (Fin.last d)
    let S_sq : ℝ := ∑ c : Fin d, ((k c : ℝ)) ^ 2
    gaussianQueryTest xt 1 G padQ ↔
      ((R_val ≤ 0 ∧ (0 ≤ L_val ∨ L_val ^ 2 ≤ R_val ^ 2 * S_sq)) ∨
       (¬ (R_val ≤ 0) ∧ 0 ≤ L_val ∧ R_val ^ 2 * S_sq ≤ L_val ^ 2)) := by
  let _ := hmesh
  intro v z_hat padQ L_val R_val S_sq
  let w : EuclideanSpace ℝ (Fin d) := ratPointToEuclidean (fun c => (k c : ℚ))
  have hw_ne : w ≠ 0 := by
    intro hw0
    apply hk
    funext c
    have hc := congrArg (fun u : EuclideanSpace ℝ (Fin d) => euclideanCoord u c) hw0
    have hc0 : ((k c : ℚ) : ℝ) = 0 := by
      simpa [w, ratPointToEuclidean, euclideanCoord, WithLp.equiv_apply, WithLp.equiv_symm_apply] using hc
    have hk0 : k c = 0 := by exact_mod_cast hc0
    exact hk0
  have hw_pos : 0 < ‖w‖ := norm_pos_iff.mpr hw_ne
  have hv_eq : v = (mesh : ℝ) • w := by
    ext c
    simp [v, w, ratPointToEuclidean, mul_comm]
  have hz_hat_eq : z_hat = ‖w‖⁻¹ • w := by
    dsimp [z_hat]
    rw [hv_eq, norm_smul, Real.norm_eq_abs, abs_of_pos hmesh_pos, mul_inv, smul_smul]
    congr 1
    field_simp [hmesh_pos.ne']
  have hw_norm_sq : ‖w‖ ^ 2 = S_sq := by
    rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
    dsimp [S_sq, w, ratPointToEuclidean]
    refine Finset.sum_congr rfl fun c _ => ?_
    simp [sq]
  have hlast : padQ.ofLp (Fin.last d) = -(B : ℝ) := by simp [padQ]
  have hinit : ∀ c : Fin d, padQ.ofLp c.castSucc = (A : ℝ) * (‖w‖⁻¹ * (k c : ℝ)) := by
    intro c; simp [padQ, hz_hat_eq, w, ratPointToEuclidean, mul_assoc]
  have hG_last : G.ofLp (Fin.last d) = euclideanCoord G (Fin.last d) := rfl
  have hG_init : ∀ c : Fin d, G.ofLp c.castSucc = euclideanCoord G c.castSucc := fun _ => rfl
  have hinner_eq : inner ℝ G padQ = ‖w‖⁻¹ * L_val - (B : ℝ) * euclideanCoord G (Fin.last d) := by
    rw [PiLp.inner_apply, Fin.sum_univ_castSucc]
    simp only [hlast, hinit, hG_last, hG_init, RCLike.inner_apply, RCLike.conj_to_real]
    dsimp [L_val]
    rw [Finset.mul_sum, Finset.mul_sum, sub_eq_add_neg]
    congr 1
    · refine Finset.sum_congr rfl fun c _ => by ring
    · ring
  unfold gaussianQueryTest
  rw [mul_one, hinner_eq]
  have hmul_iff :
      xt ≤ ‖w‖⁻¹ * L_val - (B : ℝ) * euclideanCoord G (Fin.last d) ↔
        R_val * ‖w‖ ≤ L_val := by
    dsimp [R_val]
    constructor
    · intro hle
      have h1 : R_val ≤ ‖w‖⁻¹ * L_val := by dsimp [R_val]; linarith
      have h2 := mul_le_mul_of_nonneg_right h1 hw_pos.le
      have h3 : ‖w‖⁻¹ * L_val * ‖w‖ = L_val := by field_simp [hw_pos.ne']
      linarith
    · intro hle
      have h1 : R_val * ‖w‖ * ‖w‖⁻¹ ≤ L_val * ‖w‖⁻¹ :=
        mul_le_mul_of_nonneg_right hle (inv_nonneg.mpr hw_pos.le)
      have h2 : R_val * ‖w‖ * ‖w‖⁻¹ = R_val := by field_simp [hw_pos.ne']
      dsimp [R_val] at h1 h2
      linarith
  rw [hmul_iff, real_sign_sq_equiv hw_pos, hw_norm_sq]

/-! ### 4. `bisectABStmt` in `ArithRAM` -/

/-- `ArithRAMStmt` computing `(chooseAB b η).1` into `.heap rTbl 2` and `(chooseAB b η).2`
into `.heap rTbl 3`, using scratch words `wTbl` (`0..1`) and scratch reals `rTbl` (`4..8`). -/
def bisectABStmt (bNumE bDenE etaNumE etaDenE : IntExpr) (wTbl rTbl : ℕ) : ArithRAMStmt :=
  let pE := IntExpr.readHeap wTbl (.lit 0)
  let kE := IntExpr.readHeap wTbl (.lit 1)
  let etaExpr : RealExpr := .div (.ofInt etaNumE) (.ofInt etaDenE)
  let bExpr : RealExpr := .div (.ofInt bNumE) (.ofInt bDenE)
  let targetExpr : RealExpr :=
    .add bExpr (.mul (.div (.ofInt (.lit 9)) (.ofInt (.lit 2))) (.readRealHeap rTbl (.lit 4)))
  let loR := RealExpr.readRealHeap rTbl (.lit 6)
  let hiR := RealExpr.readRealHeap rTbl (.lit 7)
  let midExpr : RealExpr := .div (.add loR hiR) (.ofInt (.lit 2))
  let midR := RealExpr.readRealHeap rTbl (.lit 8)
  let v2Expr := RealExpr.mul midR midR
  let omExpr := RealExpr.sub (.ofInt (.lit 1)) v2Expr
  let fMidExpr : RealExpr := .div (.mul (.ofInt (.lit 4)) v2Expr) (.mul omExpr omExpr)
  let hiSq := RealExpr.mul hiR hiR
  let aOutExpr : RealExpr :=
    .div (.sub (.ofInt (.lit 1)) hiSq) (.add (.ofInt (.lit 1)) hiSq)
  let bOutExpr : RealExpr :=
    .div (.mul (.ofInt (.lit 2)) hiR) (.add (.ofInt (.lit 1)) hiSq)
  seqStmts
    [ .writeRealHeap rTbl (.lit 4) etaExpr,
      .writeRealHeap rTbl (.lit 5) targetExpr,
      .writeWordHeap wTbl (.lit 0) (.lit 2),
      .writeWordHeap wTbl (.lit 1) (.lit 1),
      .whileLoop (.realLt (.mul (.ofInt pE) (.readRealHeap rTbl (.lit 4))) (.ofInt (.lit 32)))
        (.seq
          (.writeWordHeap wTbl (.lit 0) (.mul (.lit 2) pE))
          (.writeWordHeap wTbl (.lit 1) (.add kE (.lit 1)))),
      .writeRealHeap rTbl (.lit 6) (.ofInt (.lit 0)),
      .writeRealHeap rTbl (.lit 7) (.div (.ofInt (.lit 1)) (.ofInt (.lit 2))),
      .repeatN kE
        (.seq
          (.writeRealHeap rTbl (.lit 8) midExpr)
          (.ite (.realLe fMidExpr (.readRealHeap rTbl (.lit 5)))
            (.writeRealHeap rTbl (.lit 6) midR)
            (.writeRealHeap rTbl (.lit 7) midR))),
      .writeRealHeap rTbl (.lit 2) aOutExpr,
      .writeRealHeap rTbl (.lit 3) bOutExpr ]

set_option maxHeartbeats 800000 in
theorem exec_bisectABStmt {d : ℕ} (hd : 1 ≤ d)
    {b η : ℚ} (hη0 : 0 < η) (hη16 : (η : ℝ) ≤ 1 / 16)
    (inp : ArithRAMInput d)
    (bNumE bDenE etaNumE etaDenE : IntExpr) (wTbl rTbl : ℕ)
    (mem₀ : ArithRAMMemory) (hc₀ : CleanMem mem₀)
    (hEval : ∀ ws : WordStore,
      (∀ t i, t ≠ wTbl → ws.read (.heap t i) = mem₀.words.read (.heap t i)) →
      (∃ u bn, evalIntExpr inp.toWordView 0 ws bNumE = (b.num, u, bn) ∧ u ≤ 5) ∧
      (∃ u bd, evalIntExpr inp.toWordView 0 ws bDenE = ((b.den : ℤ), u, bd) ∧ u ≤ 5) ∧
      (∃ u en, evalIntExpr inp.toWordView 0 ws etaNumE = (η.num, u, en) ∧ u ≤ 5) ∧
      (∃ u ed, evalIntExpr inp.toWordView 0 ws etaDenE = ((η.den : ℤ), u, ed) ∧ u ≤ 5)) :
    ∃ (mem₁ : ArithRAMMemory) (C_cost : ℕ),
      ExecStmt inp (bisectABStmt bNumE bDenE etaNumE etaDenE wTbl rTbl) mem₀ mem₁ C_cost ∧
      (C_cost : ℝ) ≤ 900 * Real.log ((d : ℝ) / (η : ℝ)) ∧
      rRead mem₁ rTbl 2 = ((chooseAB b η).1 : ℝ) ∧
      rRead mem₁ rTbl 3 = ((chooseAB b η).2 : ℝ) ∧
      (∀ t i, t ≠ wTbl → wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ i, (i < 0 ∨ 2 ≤ i) → wRead mem₁ wTbl i = wRead mem₀ wTbl i) ∧
      (∀ t i, t ≠ rTbl → rRead mem₁ t i = rRead mem₀ t i) ∧
      (∀ i, (i < 2 ∨ 9 ≤ i) → rRead mem₁ rTbl i = rRead mem₀ rTbl i) ∧
      mem₁.words.live ⊆ mem₀.words.live ∪ heapRange wTbl 2 ∧
      mem₁.reals.live ⊆ mem₀.reals.live ∪ heapRange rTbl 9 := by
  rcases bisectCount_props hd hη0 hη16 with ⟨hK1, h2K_ge, h2K_lt, hK_ub⟩
  let K := bisectCount η
  have hη_r : (0 : ℝ) < (η : ℝ) := by exact_mod_cast hη0
  have hd_r : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  have hlog2 : 2 ≤ Real.log ((d : ℝ) / (η : ℝ)) := by
    have hq16 : 16 ≤ (d : ℝ) / (η : ℝ) := by rw [le_div_iff₀ hη_r]; linarith
    have hexp2 : Real.exp 2 ≤ 16 := by
      have h1 : Real.exp 2 = Real.exp 1 * Real.exp 1 := by rw [← Real.exp_add]; norm_num
      have he4 := exp_one_le_four; have he0 := (Real.exp_pos 1).le
      rw [h1]; nlinarith
    calc (2 : ℝ) = Real.log (Real.exp 2) := (Real.log_exp 2).symm
      _ ≤ Real.log ((d : ℝ) / (η : ℝ)) := Real.log_le_log (Real.exp_pos 2) (hexp2.trans hq16)

  let W_foot := mem₀.words.live ∪ heapRange wTbl 2
  let R_foot := mem₀.reals.live ∪ heapRange rTbl 9
  let Pres (m : ArithRAMMemory) : Prop :=
    (∀ t i, t ≠ wTbl → wRead m t i = wRead mem₀ t i) ∧
    (∀ i, (i < 0 ∨ 2 ≤ i) → wRead m wTbl i = wRead mem₀ wTbl i) ∧
    (∀ t i, t ≠ rTbl → rRead m t i = rRead mem₀ t i) ∧
    (∀ i, (i < 2 ∨ 9 ≤ i) → rRead m rTbl i = rRead mem₀ rTbl i) ∧
    m.words.live ⊆ W_foot ∧
    m.reals.live ⊆ R_foot

  have hPres₀ : Pres mem₀ := ⟨fun _ _ _ => rfl, fun _ _ => rfl, fun _ _ _ => rfl, fun _ _ => rfl,
    Finset.subset_union_left, Finset.subset_union_left⟩
  have hPres_w : ∀ {m} (hp : Pres m) (idx : ℤ), (0 ≤ idx ∧ idx < 2) → ∀ v, Pres (wWrite m wTbl idx v) := by
    intro m hp idx hidx v
    refine ⟨fun t i ht => (wRead_wWrite_of_ne m v (Or.inl ht)).trans (hp.1 t i ht),
      fun i hi => (wRead_wWrite_of_ne m v (Or.inr (by omega))).trans (hp.2.1 i hi),
      fun t i ht => hp.2.2.1 t i ht,
      fun i hi => hp.2.2.2.1 i hi,
      wWrite_words_live hp.2.2.2.2.1 v (Finset.mem_union_right _ (mem_heapRange hidx.1 hidx.2)),
      hp.2.2.2.2.2⟩
  have hPres_r : ∀ {m} (hp : Pres m) (idx : ℤ), (2 ≤ idx ∧ idx < 9) → ∀ v, Pres (rWrite m rTbl idx v) := by
    intro m hp idx hidx v
    refine ⟨fun t i ht => hp.1 t i ht,
      fun i hi => hp.2.1 i hi,
      fun t i ht => (rRead_rWrite_of_ne m v (Or.inl ht)).trans (hp.2.2.1 t i ht),
      fun i hi => (rRead_rWrite_of_ne m v (Or.inr (by omega))).trans (hp.2.2.2.1 i hi),
      hp.2.2.2.2.1,
      rWrite_reals_live hp.2.2.2.2.2 v (Finset.mem_union_right _ (mem_heapRange (by omega) hidx.2))⟩

  -- Step 1: `r[4] := (η : ℝ)`
  rcases hEval mem₀.words (fun _ _ _ => rfl) with
    ⟨⟨ubn, bbn, hbn0, hubn⟩, ⟨ubd, bbd, hbd0, hubd⟩,
     ⟨uen, ben, hen0, huen⟩, ⟨ued, bed, hed0, hued⟩⟩
  let etaExpr : RealExpr := .div (.ofInt etaNumE) (.ofInt etaDenE)
  have s1 := exec_rSet_lit inp hc₀ rTbl 4 etaExpr 20
    (by simp [etaExpr, evalRealExpr, evalIntExpr, hen0, hed0]; omega)
  let m1 := rWrite mem₀ rTbl 4 (η : ℝ)
  have hm1_eq : rWrite mem₀ rTbl 4 (evalRealExpr inp 0 mem₀ etaExpr).1 = m1 := by
    congr 1
    simp only [etaExpr, evalRealExpr, evalIntExpr, hen0, hed0]
    exact_mod_cast Rat.num_div_den η
  rw [hm1_eq] at s1
  have hPres_1 := hPres_r hPres₀ 4 ⟨by omega, by omega⟩ (η : ℝ)

  -- Step 2: `r[5] := (target : ℝ)`
  let target : ℚ := b + (9 / 2) * η
  rcases hEval m1.words hPres_1.1 with ⟨⟨ubn1, bbn1, hbn1, hubn1⟩, ⟨ubd1, bbd1, hbd1, hubd1⟩, _, _⟩
  let bExpr : RealExpr := .div (.ofInt bNumE) (.ofInt bDenE)
  let targetExpr : RealExpr :=
    .add bExpr (.mul (.div (.ofInt (.lit 9)) (.ofInt (.lit 2))) (.readRealHeap rTbl (.lit 4)))
  have s2 := exec_rSet_lit inp s1.2.1 rTbl 5 targetExpr 30
    (by simp [targetExpr, bExpr, evalRealExpr, evalIntExpr, hbn1, hbd1]; omega)
  let m2 := rWrite m1 rTbl 5 (target : ℝ)
  have hm2_eq : rWrite m1 rTbl 5 (evalRealExpr inp 0 m1 targetExpr).1 = m2 := by
    congr 1
    have hr4 : m1.reals.read (.heap rTbl 4) = (η : ℝ) := rRead_rWrite_self _ _ _ _
    have hb_eq : (b.num : ℝ) / (b.den : ℝ) = (b : ℝ) := by exact_mod_cast Rat.num_div_den b
    simp only [targetExpr, bExpr, evalRealExpr, evalIntExpr, hbn1, hbd1, hr4, target]
    push_cast
    rw [hb_eq]
  rw [hm2_eq] at s2
  have hPres_2 := hPres_r hPres_1 5 ⟨by omega, by omega⟩ (target : ℝ)

  -- Step 3 & 4: `w[0] := 2`, `w[1] := 1`
  let m3 := wWrite m2 wTbl 0 2
  have s3 := exec_wSet_lit inp s2.2.1 wTbl 0 (.lit 2) 5 (by simp [evalIntExpr])
  let m4 := wWrite m3 wTbl 1 1
  have s4 := exec_wSet_lit inp s3.2.1 wTbl 1 (.lit 1) 5 (by simp [evalIntExpr])
  have hPres_4 := hPres_w (hPres_w hPres_2 0 ⟨by omega, by omega⟩ 2) 1 ⟨by omega, by omega⟩ 1

  -- Step 5: doubling loop (`K - 1` iterations)
  let pE := IntExpr.readHeap wTbl (.lit 0)
  let kE := IntExpr.readHeap wTbl (.lit 1)
  let InvD : ℕ → ArithRAMMemory → Prop := fun j m =>
    Pres m ∧
    wRead m wTbl 0 = ((2 ^ (j + 1) : ℕ) : ℤ) ∧
    wRead m wTbl 1 = ((j + 1 : ℕ) : ℤ) ∧
    rRead m rTbl 4 = (η : ℝ) ∧
    rRead m rTbl 5 = (target : ℝ)
  have hInvD_0 : InvD 0 m4 := by
    refine ⟨hPres_4,
      (wRead_wWrite_of_ne m3 _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _),
      wRead_wWrite_self _ _ _ _,
      by simp [m4, m3, m2, m1, rRead_rWrite_of_ne],
      by simp [m4, m3, m2]⟩

  rcases ExecStmt.whileLoop_nat (cond := .realLt (.mul (.ofInt pE) (.readRealHeap rTbl (.lit 4))) (.ofInt (.lit 32))) (K - 1) 15 20 InvD s4.2.1 hInvD_0
    (fun j hj m hcm ⟨hpm, hwp, hwk, hr4, hr5⟩ => by
      have hlt_j : ((((2 ^ (j + 1) : ℕ) : ℤ) : ℝ) * (η : ℝ) < 32) := by
        simpa using h2K_lt (j + 1) (by omega) (by omega)
      have hwp' : m.words.read (.heap wTbl 0) = ((2 ^ (j + 1) : ℕ) : ℤ) := hwp
      have hr4' : m.reals.read (.heap rTbl 4) = (η : ℝ) := hr4
      refine ⟨evalCond_true inp m (.realLt (.mul (.ofInt pE) (.readRealHeap rTbl (.lit 4))) (.ofInt (.lit 32))) 15
        (by simp [evalArithCond, evalRealExpr, evalIntExpr, pE, hwp', hr4']; have htmp := h2K_lt (j + 1) (by omega) (by omega); push_cast at htmp; exact htmp)
        (by simp only [evalArithCond, evalRealExpr, evalIntExpr, pE]; omega), ?_⟩
      · let ma := wWrite m wTbl 0 ((2 ^ (j + 2) : ℕ) : ℤ)
        let mb := wWrite ma wTbl 1 ((j + 2 : ℕ) : ℤ)
        have sa : ExecStmt inp (.writeWordHeap wTbl (.lit 0) (.mul (.lit 2) pE)) m ma 10 := by
          have hs := exec_wSet_lit inp hcm wTbl 0 (.mul (.lit 2) pE) 10 (by simp [evalIntExpr, pE])
          have hv : (evalIntExpr inp.toWordView 0 m.words (.mul (.lit 2) pE)).1 =
              ((2 ^ (j + 2) : ℕ) : ℤ) := by
            simp [evalIntExpr, pE, hwp', pow_succ']
          simpa [ma, hv] using hs
        have hwk_a : ma.words.read (.heap wTbl 1) = ((j + 1 : ℕ) : ℤ) :=
          (wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hwk
        have sb : ExecStmt inp (.writeWordHeap wTbl (.lit 1) (.add kE (.lit 1))) ma mb 10 := by
          have hs := exec_wSet_lit inp sa.2.1 wTbl 1 (.add kE (.lit 1)) 10 (by simp [evalIntExpr, kE])
          have hv : (evalIntExpr inp.toWordView 0 ma.words (.add kE (.lit 1))).1 =
              ((j + 2 : ℕ) : ℤ) := by
            simp [evalIntExpr, kE, hwk_a]; try omega
          simpa [mb, hv] using hs
        refine ⟨mb, ExecStmt.seq sa sb,
          hPres_w (hPres_w hpm 0 ⟨by omega, by omega⟩ _) 1 ⟨by omega, by omega⟩ _,
          (wRead_wWrite_of_ne ma _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _),
          wRead_wWrite_self _ _ _ _,
          by simp [mb, ma, hr4],
          by simp [mb, ma, hr5]⟩)
    (fun m _ ⟨_, hwp, _, hr4, _⟩ => by
      have hsub : K - 1 + 1 = K := by omega
      rw [hsub] at hwp
      have hwp' : m.words.read (.heap wTbl 0) = ((2 ^ K : ℕ) : ℤ) := hwp
      have hr4' : m.reals.read (.heap rTbl 4) = (η : ℝ) := hr4
      exact evalCond_false inp m (.realLt (.mul (.ofInt pE) (.readRealHeap rTbl (.lit 4))) (.ofInt (.lit 32))) 15
        (by simp [evalArithCond, evalRealExpr, evalIntExpr, pE, hwp', hr4']; dsimp [K]; push_cast at h2K_ge; exact h2K_ge)
        (by simp only [evalArithCond, evalRealExpr, evalIntExpr, pE]; omega))
    with ⟨m5, ⟨hPres_5, _, hwk_5, _, hr5_5⟩, s5⟩

  have hsubK : K - 1 + 1 = K := by omega
  rw [hsubK] at hwk_5

  -- Step 6 & 7: `r[6] := 0`, `r[7] := 1 / 2`
  let m6 := rWrite m5 rTbl 6 0
  have s6 : ExecStmt inp (.writeRealHeap rTbl (.lit 6) (.ofInt (.lit 0))) m5 m6 10 := by
    simpa [m6, evalRealExpr, evalIntExpr] using
      exec_rSet_lit inp s5.2.1 rTbl 6 (.ofInt (.lit 0)) 10 (by simp [evalRealExpr, evalIntExpr])
  let m7 := rWrite m6 rTbl 7 (1 / 2)
  have s7 : ExecStmt inp (.writeRealHeap rTbl (.lit 7) (.div (.ofInt (.lit 1)) (.ofInt (.lit 2))))
      m6 m7 10 := by
    simpa [m7, evalRealExpr, evalIntExpr] using
      exec_rSet_lit inp s6.2.1 rTbl 7 (.div (.ofInt (.lit 1)) (.ofInt (.lit 2))) 10
        (by simp [evalRealExpr, evalIntExpr])
  have hPres_7 := hPres_r (hPres_r hPres_5 6 ⟨by omega, by omega⟩ 0) 7 ⟨by omega, by omega⟩ (1 / 2)

  -- Step 8: `repeatN K` bisection
  let loR := RealExpr.readRealHeap rTbl (.lit 6)
  let hiR := RealExpr.readRealHeap rTbl (.lit 7)
  let midExpr : RealExpr := .div (.add loR hiR) (.ofInt (.lit 2))
  let midR := RealExpr.readRealHeap rTbl (.lit 8)
  let v2Expr := RealExpr.mul midR midR
  let omExpr := RealExpr.sub (.ofInt (.lit 1)) v2Expr
  let fMidExpr : RealExpr := .div (.mul (.ofInt (.lit 4)) v2Expr) (.mul omExpr omExpr)

  let InvB : ℕ → ArithRAMMemory → Prop := fun j m =>
    Pres m ∧
    rRead m rTbl 5 = (target : ℝ) ∧
    rRead m rTbl 6 = ((bisectABIter target j).1 : ℝ) ∧
    rRead m rTbl 7 = ((bisectABIter target j).2 : ℝ)
  have hInvB_0 : InvB 0 m7 := by
    refine ⟨hPres_7,
      by simp [m7, m6, rRead_rWrite_of_ne, hr5_5],
      (rRead_rWrite_of_ne m6 _ (Or.inr (by decide))).trans (by simp [m6, bisectABIter]),
      by simp [m7, bisectABIter]⟩

  have hwk_7 : m7.words.read (.heap wTbl 1) = (K : ℤ) := hwk_5
  have hcnt_K : evalIntExpr inp.toWordView 0 m7.words kE =
      ((K : ℤ), 2, (evalIntExpr inp.toWordView 0 m7.words kE).2.2) := by
    simp [evalIntExpr, kE, hwk_7]

  rcases ExecStmt.repeatN_nat K 5 60 InvB s7.2.1 hInvB_0 hcnt_K (by omega)
    (fun j _ m hcm ⟨hpm, hr5, hr6, hr7⟩ => by
      let lh := bisectABIter target j
      let midQ : ℚ := (lh.1 + lh.2) / 2
      have hr6' : m.reals.read (.heap rTbl 6) = (lh.1 : ℝ) := hr6
      have hr7' : m.reals.read (.heap rTbl 7) = (lh.2 : ℝ) := hr7
      have smid := exec_rSet_lit inp hcm rTbl 8 midExpr 15
        (by simp [midExpr, loR, hiR, evalRealExpr, evalIntExpr])
      let ma := rWrite m rTbl 8 (midQ : ℝ)
      have hma : rWrite m rTbl 8 (evalRealExpr inp 0 m midExpr).1 = ma := by
        congr 1
        simp [midExpr, loR, hiR, evalRealExpr, evalIntExpr, hr6', hr7', midQ]
      rw [hma] at smid
      have hPres_a := hPres_r hpm 8 ⟨by omega, by omega⟩ (midQ : ℝ)
      have hr5_a : ma.reals.read (.heap rTbl 5) = (target : ℝ) :=
        (rRead_rWrite_of_ne m _ (Or.inr (by decide))).trans hr5
      have hr8_a : ma.reals.read (.heap rTbl 8) = (midQ : ℝ) := rRead_rWrite_self _ _ _ _
      have hfmid_val : (evalRealExpr inp 0 ma fMidExpr).1 = (fRatioRat midQ : ℝ) := by
        rw [fRatioRat_cast]
        simp only [fMidExpr, omExpr, v2Expr, midR, evalRealExpr, evalIntExpr, hr8_a, fRatioReal]
        ring
      have hfmid_cost : (evalRealExpr inp 0 ma fMidExpr).2 ≤ 30 := by
        simp [fMidExpr, omExpr, v2Expr, midR, evalRealExpr, evalIntExpr]
      by_cases hcond : fRatioRat midQ ≤ target
      · have hcond_r : (fRatioRat midQ : ℝ) ≤ (target : ℝ) := by exact_mod_cast hcond
        rcases evalCond_true inp ma (.realLe fMidExpr (.readRealHeap rTbl (.lit 5))) 35
          (by simp only [evalArithCond, hfmid_val]; simp [evalRealExpr, evalIntExpr, hr5_a, hcond_r])
          (by simp only [evalArithCond]; have : (evalRealExpr inp 0 ma (.readRealHeap rTbl (.lit 5))).2 = 2 := rfl; omega)
          with ⟨uc, hce, huc⟩
        have sbr : ExecStmt inp (.writeRealHeap rTbl (.lit 6) midR) ma (rWrite ma rTbl 6 (midQ : ℝ)) 10 := by
          have hs := exec_rSet_lit inp smid.2.1 rTbl 6 midR 10 (by simp [midR, evalRealExpr, evalIntExpr])
          simpa [midR, evalRealExpr, evalIntExpr, hr8_a] using hs
        have site := ExecStmt.ite_true (fB := .writeRealHeap rTbl (.lit 7) midR) hce huc sbr
        let mb := rWrite ma rTbl 6 (midQ : ℝ)
        refine ⟨mb, (ExecStmt.seq smid site).mono_cost (by omega),
          hPres_r hPres_a 6 ⟨by omega, by omega⟩ _,
          (rRead_rWrite_of_ne ma _ (Or.inr (by decide))).trans hr5_a,
          ?_, ?_⟩
        · simp [mb, bisectABIter, bisectABStep, lh, midQ, hcond]
        · simp [mb, ma, rRead_rWrite_of_ne, bisectABIter, bisectABStep, lh, midQ, hcond, hr7]
      · have hcond_r : ¬ ((fRatioRat midQ : ℝ) ≤ (target : ℝ)) := by exact_mod_cast hcond
        rcases evalCond_false inp ma (.realLe fMidExpr (.readRealHeap rTbl (.lit 5))) 35
          (by simp only [evalArithCond, hfmid_val]; simp [evalRealExpr, evalIntExpr, hr5_a]; linarith)
          (by simp only [evalArithCond]; have : (evalRealExpr inp 0 ma (.readRealHeap rTbl (.lit 5))).2 = 2 := rfl; omega)
          with ⟨uc, hce, huc⟩
        have sbr : ExecStmt inp (.writeRealHeap rTbl (.lit 7) midR) ma (rWrite ma rTbl 7 (midQ : ℝ)) 10 := by
          have hs := exec_rSet_lit inp smid.2.1 rTbl 7 midR 10 (by simp [midR, evalRealExpr, evalIntExpr])
          simpa [midR, evalRealExpr, evalIntExpr, hr8_a] using hs
        have site := ExecStmt.ite_false (tB := .writeRealHeap rTbl (.lit 6) midR) hce huc sbr
        let mb := rWrite ma rTbl 7 (midQ : ℝ)
        refine ⟨mb, (ExecStmt.seq smid site).mono_cost (by omega),
          hPres_r hPres_a 7 ⟨by omega, by omega⟩ _,
          (rRead_rWrite_of_ne ma _ (Or.inr (by decide))).trans hr5_a,
          ?_, ?_⟩
        · simp [mb, ma, rRead_rWrite_of_ne, bisectABIter, bisectABStep, lh, midQ, hcond, hr6]
        · simp [mb, bisectABIter, bisectABStep, lh, midQ, hcond])
    with ⟨m8, ⟨hPres_8, _, _, hr7_8⟩, s8⟩

  -- Step 9 & 10: write `A` to `r[2]` and `B` to `r[3]`
  let hiSq := RealExpr.mul hiR hiR
  let aOutExpr : RealExpr := .div (.sub (.ofInt (.lit 1)) hiSq) (.add (.ofInt (.lit 1)) hiSq)
  let bOutExpr : RealExpr := .div (.mul (.ofInt (.lit 2)) hiR) (.add (.ofInt (.lit 1)) hiSq)
  have hr7_8' : m8.reals.read (.heap rTbl 7) = ((bisectABIter target K).2 : ℝ) := hr7_8

  have s9 := exec_rSet_lit inp s8.2.1 rTbl 2 aOutExpr 25
    (by simp [aOutExpr, hiSq, hiR, evalRealExpr, evalIntExpr])
  let m9 := rWrite m8 rTbl 2 ((chooseAB b η).1 : ℝ)
  have hm9 : rWrite m8 rTbl 2 (evalRealExpr inp 0 m8 aOutExpr).1 = m9 := by
    congr 1
    simp only [aOutExpr, hiSq, hiR, evalRealExpr, evalIntExpr, hr7_8', chooseAB, K, target]
    push_cast; ring
  rw [hm9] at s9
  have hPres_9 : Pres m9 := hPres_r hPres_8 2 ⟨by omega, by omega⟩ _

  have hr7_9' : m9.reals.read (.heap rTbl 7) = ((bisectABIter target K).2 : ℝ) :=
    (rRead_rWrite_of_ne m8 _ (Or.inr (by decide))).trans hr7_8
  have s10 := exec_rSet_lit inp s9.2.1 rTbl 3 bOutExpr 25
    (by simp [bOutExpr, hiSq, hiR, evalRealExpr, evalIntExpr])
  let m10 := rWrite m9 rTbl 3 ((chooseAB b η).2 : ℝ)
  have hm10 : rWrite m9 rTbl 3 (evalRealExpr inp 0 m9 bOutExpr).1 = m10 := by
    congr 1
    simp only [bOutExpr, hiSq, hiR, evalRealExpr, evalIntExpr, hr7_9', chooseAB, K, target]
    push_cast; ring
  rw [hm10] at s10
  have hPres_10 : Pres m10 := hPres_r hPres_9 3 ⟨by omega, by omega⟩ _

  let totalCost : ℕ :=
    20 + 30 + 5 + 5 + ((K - 1 + 1) * 15 + (K - 1) * 20) + 10 + 10 + (5 + K * 60) + 25 + 25
  have sTot : ExecStmt inp (bisectABStmt bNumE bDenE etaNumE etaDenE wTbl rTbl) mem₀ m10 totalCost := by
    unfold bisectABStmt
    dsimp [seqStmts]
    exact (ExecStmt.seq s1 (ExecStmt.seq s2 (ExecStmt.seq s3 (ExecStmt.seq s4
      (ExecStmt.seq s5 (ExecStmt.seq s6 (ExecStmt.seq s7
        (ExecStmt.seq s8 (ExecStmt.seq s9 s10))))))))).mono_cost (by omega)

  have hCost_ub : (totalCost : ℝ) ≤ 900 * Real.log ((d : ℝ) / (η : ℝ)) := by
    have hKm1_le : ((K - 1 : ℕ) : ℝ) ≤ (K : ℝ) := by
      have : K - 1 ≤ K := by omega
      exact_mod_cast this
    have htot_r : (totalCost : ℝ) ≤ 150 + 95 * (K : ℝ) := by
      dsimp [totalCost]
      push_cast
      linarith
    dsimp [K] at htot_r
    linarith [hK_ub, hlog2]

  exact ⟨m10, totalCost, sTot, hCost_ub,
    (rRead_rWrite_of_ne m9 _ (Or.inr (by decide))).trans (rRead_rWrite_self _ _ _ _),
    rRead_rWrite_self _ _ _ _,
    hPres_10.1, hPres_10.2.1, hPres_10.2.2.1, hPres_10.2.2.2.1, hPres_10.2.2.2.2.1, hPres_10.2.2.2.2.2⟩

end UL.Proof_clm_6_1_adaptive
