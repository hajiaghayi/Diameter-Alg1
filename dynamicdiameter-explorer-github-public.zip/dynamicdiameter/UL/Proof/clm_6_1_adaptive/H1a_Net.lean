import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_6_search_interface
import UL.Proof.lem_6_3.H1_RAM
set_option autoImplicit false

namespace UL.Proof_clm_6_1_adaptive

open UL.Proof_lem_6_3

/-! ### 0. Elementary exponential and assignment helpers -/

theorem exp_half_le_two : Real.exp (1 / 2 : ℝ) ≤ 2 := by
  have h1 : (1 / 2 : ℝ) ≤ Real.exp (-(1 / 2 : ℝ)) := by
    linarith [Real.add_one_le_exp (-(1 / 2 : ℝ))]
  have hprod : Real.exp (1 / 2 : ℝ) * Real.exp (-(1 / 2 : ℝ)) = 1 := by
    rw [← Real.exp_add]; simp
  have hpos : 0 < Real.exp (1 / 2 : ℝ) := Real.exp_pos _
  nlinarith

theorem exp_one_le_four : Real.exp 1 ≤ 4 := by
  have hsq : Real.exp 1 = Real.exp (1 / 2 : ℝ) * Real.exp (1 / 2 : ℝ) := by
    rw [← Real.exp_add]; norm_num
  have hpos : 0 ≤ Real.exp (1 / 2 : ℝ) := (Real.exp_pos _).le
  rw [hsq]
  nlinarith [exp_half_le_two]

theorem two_le_exp_one : (2 : ℝ) ≤ Real.exp 1 := by
  linarith [Real.add_one_le_exp 1]

theorem nat_cast_le_two_pow (n : ℕ) : (n : ℝ) ≤ (2 : ℝ) ^ n := by
  exact_mod_cast (Nat.lt_two_pow_self (n := n)).le

theorem exec_wSet {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (t : ℕ) (idxE valE : IntExpr) (C : ℕ)
    (hC : (evalIntExpr inp.toWordView 0 mem.words idxE).2.1 +
          (evalIntExpr inp.toWordView 0 mem.words valE).2.1 + 1 ≤ C) :
    ExecStmt inp (.writeWordHeap t idxE valE) mem
      (wWrite mem t (evalIntExpr inp.toWordView 0 mem.words idxE).1
        (evalIntExpr inp.toWordView 0 mem.words valE).1) C := by
  rcases h1 : evalIntExpr inp.toWordView 0 mem.words idxE with ⟨idx, u₁, b₁⟩
  rcases h2 : evalIntExpr inp.toWordView 0 mem.words valE with ⟨val, u₂, b₂⟩
  exact ExecStmt.writeWordHeap inp hc t idxE valE h1 h2 (by simpa [h1, h2] using hC)

theorem exec_rSet {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (t : ℕ) (idxE : IntExpr) (valE : RealExpr) (C : ℕ)
    (hC : (evalIntExpr inp.toWordView 0 mem.words idxE).2.1 +
          (evalRealExpr inp 0 mem valE).2 + 1 ≤ C) :
    ExecStmt inp (.writeRealHeap t idxE valE) mem
      (rWrite mem t (evalIntExpr inp.toWordView 0 mem.words idxE).1
        (evalRealExpr inp 0 mem valE).1) C := by
  rcases h1 : evalIntExpr inp.toWordView 0 mem.words idxE with ⟨idx, u₁, b₁⟩
  rcases h2 : evalRealExpr inp 0 mem valE with ⟨val, u₂⟩
  exact ExecStmt.writeRealHeap inp hc t idxE valE h1 h2 (by simpa [h1, h2] using hC)

theorem exec_wSet_lit {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (t : ℕ) (idx : ℤ) (valE : IntExpr) (C : ℕ)
    (hC : (evalIntExpr inp.toWordView 0 mem.words valE).2.1 + 2 ≤ C) :
    ExecStmt inp (.writeWordHeap t (.lit idx) valE) mem
      (wWrite mem t idx (evalIntExpr inp.toWordView 0 mem.words valE).1) C := by
  exact exec_wSet inp hc t (.lit idx) valE C (by simp only [evalIntExpr]; omega)

theorem exec_rSet_lit {d : ℕ} (inp : ArithRAMInput d) {mem : ArithRAMMemory}
    (hc : CleanMem mem) (t : ℕ) (idx : ℤ) (valE : RealExpr) (C : ℕ)
    (hC : (evalRealExpr inp 0 mem valE).2 + 2 ≤ C) :
    ExecStmt inp (.writeRealHeap t (.lit idx) valE) mem
      (rWrite mem t idx (evalRealExpr inp 0 mem valE).1) C := by
  exact exec_rSet inp hc t (.lit idx) valE C (by simp only [evalIntExpr]; omega)

theorem evalCond_true {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (cond : ArithCondExpr) (C : ℕ)
    (hb : (evalArithCond inp 0 m cond).1 = true)
    (hu : (evalArithCond inp 0 m cond).2 ≤ C) :
    ∃ u_c, evalArithCond inp 0 m cond = (true, u_c) ∧ u_c ≤ C := by
  rcases h : evalArithCond inp 0 m cond with ⟨b, u⟩
  simp only [h] at hb hu
  subst hb
  exact ⟨u, rfl, hu⟩

theorem evalCond_false {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (cond : ArithCondExpr) (C : ℕ)
    (hb : (evalArithCond inp 0 m cond).1 = false)
    (hu : (evalArithCond inp 0 m cond).2 ≤ C) :
    ∃ u_c, evalArithCond inp 0 m cond = (false, u_c) ∧ u_c ≤ C := by
  rcases h : evalArithCond inp 0 m cond with ⟨b, u⟩
  simp only [h] at hb hu
  subst hb
  exact ⟨u, rfl, hu⟩

/-- Heap cells `.heap tbl 0 .. .heap tbl (n - 1)`. -/
def heapRange (tbl n : ℕ) : Finset RAMCellLoc :=
  (Finset.range n).image (fun (i : ℕ) => RAMCellLoc.heap tbl (i : ℤ))

/-- Shifted heap cells `.heap tbl lo .. .heap tbl (lo + n - 1)`. -/
def heapSlice (tbl : ℕ) (lo : ℤ) (n : ℕ) : Finset RAMCellLoc :=
  (Finset.range n).image (fun (i : ℕ) => RAMCellLoc.heap tbl (lo + (i : ℤ)))

theorem mem_heapRange {tbl n : ℕ} {i : ℤ} (h0 : 0 ≤ i) (hn : i < (n : ℤ)) :
    RAMCellLoc.heap tbl i ∈ heapRange tbl n := by
  unfold heapRange
  rw [Finset.mem_image]
  refine ⟨i.toNat, Finset.mem_range.mpr (by omega), ?_⟩
  congr 1; omega

theorem mem_heapSlice {tbl : ℕ} {lo : ℤ} {n : ℕ} {i : ℤ}
    (h0 : lo ≤ i) (hn : i < lo + (n : ℤ)) :
    RAMCellLoc.heap tbl i ∈ heapSlice tbl lo n := by
  unfold heapSlice
  rw [Finset.mem_image]
  refine ⟨(i - lo).toNat, Finset.mem_range.mpr (by omega), ?_⟩
  congr 1; omega

theorem card_heapRange_le (tbl n : ℕ) : (heapRange tbl n).card ≤ n :=
  Finset.card_image_le.trans (by simp)

theorem card_heapSlice_le (tbl : ℕ) (lo : ℤ) (n : ℕ) : (heapSlice tbl lo n).card ≤ n :=
  Finset.card_image_le.trans (by simp)

theorem wWrite_words_live {m : ArithRAMMemory} {W : Finset RAMCellLoc}
    (h : m.words.live ⊆ W) {t : ℕ} {i : ℤ} (v : ℤ) (hmem : RAMCellLoc.heap t i ∈ W) :
    (wWrite m t i v).words.live ⊆ W := by
  unfold wWrite WordStore.write
  exact Finset.insert_subset hmem h

theorem rWrite_reals_live {m : ArithRAMMemory} {R : Finset RAMCellLoc}
    (h : m.reals.live ⊆ R) {t : ℕ} {i : ℤ} (v : ℝ) (hmem : RAMCellLoc.heap t i ∈ R) :
    (rWrite m t i v).reals.live ⊆ R := by
  unfold rWrite RealStore.write
  exact Finset.insert_subset hmem h

/-! ### 1. Standing parameter inequalities and `ceilSqrt` -/

theorem param_basic_bounds {d : ℕ} (hd : 1 ≤ d)
    {a b : ℚ} {g : ℝ} {η : ℚ}
    (hb0 : (0 : ℝ) ≤ (b : ℝ)) (_hba : (b : ℝ) < (a : ℝ)) (ha1 : (a : ℝ) ≤ 1)
    (hg0 : 0 < g) (hgap : g ≤ (a : ℝ) - (1 + g) * (b : ℝ))
    (hη0 : 0 < η) (hηg : (η : ℝ) ≤ g / 16) :
    g ≤ 1 ∧
    (b : ℝ) ≤ 1 - g ∧
    0 < (η : ℝ) ∧
    (η : ℝ) ≤ 1 / 16 ∧
    16 ≤ (d : ℝ) / (η : ℝ) ∧
    2 ≤ Real.log ((d : ℝ) / (η : ℝ)) := by
  have hηr0 : (0 : ℝ) < (η : ℝ) := by exact_mod_cast hη0
  have hgb_nonneg : 0 ≤ g * (b : ℝ) := mul_nonneg hg0.le hb0
  have hb_le : (b : ℝ) ≤ 1 - g := by linarith
  have hg1 : g ≤ 1 := by linarith
  have hη16 : (η : ℝ) ≤ 1 / 16 := by linarith
  have hd1 : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  have hquot16 : 16 ≤ (d : ℝ) / (η : ℝ) := by
    rw [le_div_iff₀ hηr0]
    linarith
  have hexp2 : Real.exp 2 ≤ 16 := by
    have h1 : Real.exp 2 = Real.exp 1 * Real.exp 1 := by
      rw [← Real.exp_add]; norm_num
    have he4 : Real.exp 1 ≤ 4 := exp_one_le_four
    have he0 : 0 ≤ Real.exp 1 := (Real.exp_pos 1).le
    rw [h1]
    nlinarith
  have hlog2 : 2 ≤ Real.log ((d : ℝ) / (η : ℝ)) := by
    have hexp_le : Real.exp 2 ≤ (d : ℝ) / (η : ℝ) := hexp2.trans hquot16
    calc (2 : ℝ) = Real.log (Real.exp 2) := (Real.log_exp 2).symm
      _ ≤ Real.log ((d : ℝ) / (η : ℝ)) := Real.log_le_log (Real.exp_pos 2) hexp_le
  exact ⟨hg1, hb_le, hηr0, hη16, hquot16, hlog2⟩

/-- Integer ceiling `⌈√d⌉` of `√d`. -/
noncomputable def ceilSqrt (d : ℕ) : ℕ :=
  Nat.ceil (Real.sqrt (d : ℝ))

theorem ceilSqrt_props {d : ℕ} (hd : 1 ≤ d) :
    1 ≤ ceilSqrt d ∧
    ceilSqrt d ≤ d ∧
    d ≤ (ceilSqrt d) ^ 2 ∧
    (ceilSqrt d - 1) ^ 2 < d := by
  unfold ceilSqrt
  have hd_r : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  have hsq_pos : 0 < Real.sqrt (d : ℝ) := Real.sqrt_pos.mpr (by positivity)
  have h1 : 1 ≤ Nat.ceil (Real.sqrt (d : ℝ)) := Nat.ceil_pos.mpr hsq_pos
  have hsq_le_d : Real.sqrt (d : ℝ) ≤ (d : ℝ) := by
    have hdd : (d : ℝ) ≤ (d : ℝ) ^ 2 := by nlinarith
    calc Real.sqrt (d : ℝ) ≤ Real.sqrt ((d : ℝ) ^ 2) := Real.sqrt_le_sqrt hdd
      _ = (d : ℝ) := Real.sqrt_sq (by positivity)
  have h2 : Nat.ceil (Real.sqrt (d : ℝ)) ≤ d := Nat.ceil_le.mpr hsq_le_d
  have hle_ceil : Real.sqrt (d : ℝ) ≤ (Nat.ceil (Real.sqrt (d : ℝ)) : ℝ) :=
    Nat.le_ceil (Real.sqrt (d : ℝ))
  have h3_r : (d : ℝ) ≤ (Nat.ceil (Real.sqrt (d : ℝ)) : ℝ) ^ 2 := by
    calc (d : ℝ) = (Real.sqrt (d : ℝ)) ^ 2 := (Real.sq_sqrt (by positivity)).symm
      _ ≤ (Nat.ceil (Real.sqrt (d : ℝ)) : ℝ) ^ 2 :=
          pow_le_pow_left₀ (Real.sqrt_nonneg _) hle_ceil 2
  have h3 : d ≤ (Nat.ceil (Real.sqrt (d : ℝ))) ^ 2 := by exact_mod_cast h3_r
  have h4 : (Nat.ceil (Real.sqrt (d : ℝ)) - 1) ^ 2 < d := by
    set S := Nat.ceil (Real.sqrt (d : ℝ))
    have hlt_sq : ((S - 1 : ℕ) : ℝ) < Real.sqrt (d : ℝ) := by
      by_cases hS1 : S = 1
      · simp [hS1, hsq_pos]
      · have hS2 : 1 < S := by omega
        have hlt : ((S - 1 : ℕ) : ℝ) < Real.sqrt (d : ℝ) := by
          by_contra hge
          push_neg at hge
          have hle_S : S ≤ S - 1 := Nat.ceil_le.mpr hge
          omega
        exact hlt
    have h4_r : ((S - 1 : ℕ) : ℝ) ^ 2 < (d : ℝ) := by
      calc ((S - 1 : ℕ) : ℝ) ^ 2 < (Real.sqrt (d : ℝ)) ^ 2 :=
            pow_lt_pow_left₀ hlt_sq (by positivity) (by decide)
        _ = (d : ℝ) := Real.sq_sqrt (by positivity)
    exact_mod_cast h4_r
  exact ⟨h1, h2, h3, h4⟩

/-! ### 2. Lattice rounding and net cardinality -/

/-- Rational mesh `η / (8 * ⌈√d⌉)`. -/
noncomputable def meshRat (d : ℕ) (η : ℚ) : ℚ :=
  η / (8 * (Nat.ceil (Real.sqrt (d : ℝ)) : ℚ))

/-- Nearest-integer lattice coordinate `⌊z_c / mesh + 1/2⌋`. -/
noncomputable def roundLatFn (d : ℕ) (η : ℚ) (z : EuclideanSpace ℝ (Fin d)) (c : Fin d) : ℤ :=
  Int.floor (euclideanCoord z c / (meshRat d η : ℝ) + 1 / 2)

/-- Rounded unnormalized vector on `mesh * ℤ^d`. -/
noncomputable def roundVecFn (d : ℕ) (η : ℚ) (z : EuclideanSpace ℝ (Fin d)) :
    EuclideanSpace ℝ (Fin d) :=
  ratPointToEuclidean (fun c => (roundLatFn d η z c : ℚ) * meshRat d η)

/-- Normalized rounded direction on `S^{d-1}`. -/
noncomputable def roundDirFn (d : ℕ) (η : ℚ) (z : EuclideanSpace ℝ (Fin d)) :
    EuclideanSpace ℝ (Fin d) :=
  ‖roundVecFn d η z‖⁻¹ • roundVecFn d η z

/-- Finite normalized lattice direction net in `ℝ^d`. -/
noncomputable def dirNet (d : ℕ) (η : ℚ) : Finset (EuclideanSpace ℝ (Fin d)) :=
  open Classical in
  let M : ℕ := Nat.ceil (1 / (meshRat d η : ℝ)) + 1
  let I : Finset ℤ := Finset.Icc (-(M : ℤ)) (M : ℤ)
  let Box : Finset (Fin d → ℤ) := (Fintype.piFinset (fun _ : Fin d => I)).filter (fun k => k ≠ 0)
  Box.image (fun k =>
    let v := ratPointToEuclidean (fun c => (k c : ℚ) * meshRat d η)
    ‖v‖⁻¹ • v)

theorem meshRat_bounds {d : ℕ} (hd : 1 ≤ d) {η : ℚ} (hη0 : 0 < η) :
    0 < meshRat d η ∧
    0 < (meshRat d η : ℝ) ∧
    1 / (meshRat d η : ℝ) =
      (8 * (ceilSqrt d : ℝ) * (η.den : ℝ)) / (η.num : ℝ) ∧
    8 / (η : ℝ) ≤ 1 / (meshRat d η : ℝ) ∧
    1 / (meshRat d η : ℝ) ≤ 8 * (d : ℝ) / (η : ℝ) := by
  rcases ceilSqrt_props hd with ⟨hS1, hSd, _, _⟩
  have hS_q : (0 : ℚ) < (ceilSqrt d : ℚ) := by exact_mod_cast hS1
  have hmesh_q : 0 < meshRat d η := by
    unfold meshRat ceilSqrt at *
    positivity
  have hmesh_r : (0 : ℝ) < (meshRat d η : ℝ) := by exact_mod_cast hmesh_q
  have hη_r : (0 : ℝ) < (η : ℝ) := by exact_mod_cast hη0
  have hS_r1 : (1 : ℝ) ≤ (ceilSqrt d : ℝ) := by exact_mod_cast hS1
  have hS_rd : (ceilSqrt d : ℝ) ≤ (d : ℝ) := by exact_mod_cast hSd
  have hmesh_cast : (meshRat d η : ℝ) = (η : ℝ) / (8 * (ceilSqrt d : ℝ)) := by
    unfold meshRat ceilSqrt
    push_cast
    rfl
  have hinv_eq : 1 / (meshRat d η : ℝ) = 8 * (ceilSqrt d : ℝ) / (η : ℝ) := by
    rw [hmesh_cast]
    field_simp [hη_r.ne']
  have hη_num_den : (η : ℝ) = (η.num : ℝ) / (η.den : ℝ) := by
    exact_mod_cast (Rat.num_div_den η).symm
  have hden_pos : (0 : ℝ) < (η.den : ℝ) := by exact_mod_cast η.den_pos
  have hnum_pos : (0 : ℝ) < (η.num : ℝ) := by exact_mod_cast (Rat.num_pos.mpr hη0)
  have hinv_rat : 1 / (meshRat d η : ℝ) =
      (8 * (ceilSqrt d : ℝ) * (η.den : ℝ)) / (η.num : ℝ) := by
    rw [hinv_eq, hη_num_den]
    field_simp [hden_pos.ne', hnum_pos.ne']
  have hlo : 8 / (η : ℝ) ≤ 1 / (meshRat d η : ℝ) := by
    rw [hinv_eq]
    exact div_le_div_of_nonneg_right (by linarith) hη_r.le
  have hhi : 1 / (meshRat d η : ℝ) ≤ 8 * (d : ℝ) / (η : ℝ) := by
    rw [hinv_eq]
    exact div_le_div_of_nonneg_right (by linarith) hη_r.le
  exact ⟨hmesh_q, hmesh_r, hinv_rat, hlo, hhi⟩

theorem unitVec_coord_abs_le_one {d : ℕ} {z : EuclideanSpace ℝ (Fin d)}
    (hz : IsUnitVec z) (c : Fin d) :
    |euclideanCoord z c| ≤ 1 := by
  unfold IsUnitVec at hz
  have hsum : ∑ j : Fin d, (euclideanCoord z j) ^ 2 = 1 := by
    have h1 : ‖z‖ ^ 2 = 1 := by rw [hz]; norm_num
    rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply] at h1
    simpa [euclideanCoord, sq] using h1
  have hle : (euclideanCoord z c) ^ 2 ≤ 1 := by
    rw [← hsum]
    exact Finset.single_le_sum (fun j _ => sq_nonneg (euclideanCoord z j)) (Finset.mem_univ c)
  exact abs_le.mpr ⟨by nlinarith, by nlinarith⟩

theorem roundDirFn_props {d : ℕ} (hd : 1 ≤ d) {η : ℚ}
    (hη0 : 0 < η) (hη16 : (η : ℝ) ≤ 1 / 16) :
    (dirNet d η).Nonempty ∧
    (∀ z_hat ∈ dirNet d η, IsUnitVec z_hat ∧
      ∃ k : Fin d → ℤ, k ≠ 0 ∧
        let v := ratPointToEuclidean (fun c => (k c : ℚ) * meshRat d η)
        z_hat = ‖v‖⁻¹ • v) ∧
    Real.log ((dirNet d η).card : ℝ) ≤ 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ∧
    (∀ z : EuclideanSpace ℝ (Fin d), IsUnitVec z →
      roundLatFn d η z ≠ 0 ∧
      roundDirFn d η z ∈ dirNet d η ∧
      IsUnitVec (roundDirFn d η z) ∧
      ‖roundDirFn d η z - z‖ ≤ (η : ℝ) / 8) := by
  classical
  rcases ceilSqrt_props hd with ⟨hS1, hSd, hd_le_S2, _⟩
  rcases meshRat_bounds hd hη0 with ⟨hmesh_q, hmesh_r, _, hinv_lo, hinv_hi⟩
  have hη_r : (0 : ℝ) < (η : ℝ) := by exact_mod_cast hη0
  have hd_r : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  let M : ℕ := Nat.ceil (1 / (meshRat d η : ℝ)) + 1
  let I : Finset ℤ := Finset.Icc (-(M : ℤ)) (M : ℤ)
  let Box : Finset (Fin d → ℤ) := (Fintype.piFinset (fun _ : Fin d => I)).filter (fun k => k ≠ 0)

  have hround_z : ∀ z : EuclideanSpace ℝ (Fin d), IsUnitVec z →
      roundLatFn d η z ≠ 0 ∧
      roundDirFn d η z ∈ dirNet d η ∧
      IsUnitVec (roundDirFn d η z) ∧
      ‖roundDirFn d η z - z‖ ≤ (η : ℝ) / 8 := by
    intro z hz
    have hcoord_err : ∀ c : Fin d,
        |((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c| ≤
          (meshRat d η : ℝ) / 2 := by
      intro c
      set y := euclideanCoord z c / (meshRat d η : ℝ)
      have hfl1 : (roundLatFn d η z c : ℝ) ≤ y + 1 / 2 := Int.floor_le (y + 1 / 2)
      have hfl2 : y + 1 / 2 < (roundLatFn d η z c : ℝ) + 1 := Int.lt_floor_add_one (y + 1 / 2)
      have hdiff1 : |(roundLatFn d η z c : ℝ) - y| ≤ 1 / 2 :=
        abs_le.mpr ⟨by linarith, by linarith⟩
      have hmul := mul_le_mul_of_nonneg_right hdiff1 hmesh_r.le
      have hrew : ((roundLatFn d η z c : ℝ) - y) * (meshRat d η : ℝ) =
          ((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c := by
        dsimp [y]
        push_cast
        field_simp [hmesh_r.ne']
      calc |((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c|
          = |((roundLatFn d η z c : ℝ) - y) * (meshRat d η : ℝ)| := by rw [hrew]
        _ = |(roundLatFn d η z c : ℝ) - y| * (meshRat d η : ℝ) := by
            rw [abs_mul, abs_of_pos hmesh_r]
        _ ≤ (1 / 2) * (meshRat d η : ℝ) := hmul
        _ = (meshRat d η : ℝ) / 2 := by ring

    have hvz_sq : ‖roundVecFn d η z - z‖ ^ 2 ≤ ((η : ℝ) / 16) ^ 2 := by
      have hnorm_sum : ‖roundVecFn d η z - z‖ ^ 2 =
          ∑ c : Fin d, (((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c) ^ 2 := by
        rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
        refine Finset.sum_congr rfl fun c _ => ?_
        simp [roundVecFn, ratPointToEuclidean, euclideanCoord, sq]
      rw [hnorm_sum]
      have hterm : ∀ c : Fin d,
          (((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c) ^ 2 ≤
            ((meshRat d η : ℝ) / 2) ^ 2 := by
        intro c
        have hc := hcoord_err c
        have hsq_abs :
            (((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c) ^ 2 =
              |((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c| ^ 2 :=
          (sq_abs _).symm
        rw [hsq_abs]
        exact pow_le_pow_left₀ (abs_nonneg _) hc 2
      have hsum_le :
          ∑ c : Fin d, (((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c) ^ 2 ≤
            (d : ℝ) * ((meshRat d η : ℝ) / 2) ^ 2 := by
        calc ∑ c : Fin d, (((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c) ^ 2
            ≤ ∑ _c : Fin d, ((meshRat d η : ℝ) / 2) ^ 2 := Finset.sum_le_sum fun c _ => hterm c
          _ = (d : ℝ) * ((meshRat d η : ℝ) / 2) ^ 2 := by simp
      have hmesh_cast : (meshRat d η : ℝ) = (η : ℝ) / (8 * (ceilSqrt d : ℝ)) := by
        unfold meshRat ceilSqrt; push_cast; rfl
      have hd_S2_r : (d : ℝ) ≤ (ceilSqrt d : ℝ) ^ 2 := by exact_mod_cast hd_le_S2
      have hS_pos_r : (0 : ℝ) < (ceilSqrt d : ℝ) := by exact_mod_cast hS1
      calc ∑ c : Fin d, (((roundLatFn d η z c : ℚ) * meshRat d η : ℝ) - euclideanCoord z c) ^ 2
          ≤ (d : ℝ) * ((meshRat d η : ℝ) / 2) ^ 2 := hsum_le
        _ = (d : ℝ) * ((η : ℝ) ^ 2 / (256 * (ceilSqrt d : ℝ) ^ 2)) := by
            rw [hmesh_cast]; ring
        _ ≤ (ceilSqrt d : ℝ) ^ 2 * ((η : ℝ) ^ 2 / (256 * (ceilSqrt d : ℝ) ^ 2)) :=
            mul_le_mul_of_nonneg_right hd_S2_r (by positivity)
        _ = ((η : ℝ) / 16) ^ 2 := by field_simp [hS_pos_r.ne']; ring

    have hvz : ‖roundVecFn d η z - z‖ ≤ (η : ℝ) / 16 := by
      have hnn : 0 ≤ ‖roundVecFn d η z - z‖ := norm_nonneg _
      nlinarith
    have hv_pos : 0 < ‖roundVecFn d η z‖ := by
      have htri : ‖z‖ ≤ ‖roundVecFn d η z‖ + ‖roundVecFn d η z - z‖ :=
        norm_le_insert (roundVecFn d η z) z
      rw [hz] at htri
      linarith
    have hv_ne : roundVecFn d η z ≠ 0 := norm_pos_iff.mp hv_pos
    have hlat_ne : roundLatFn d η z ≠ 0 := by
      intro h0
      apply hv_ne
      ext c
      simp [roundVecFn, ratPointToEuclidean, h0]
    have hrd_unit : IsUnitVec (roundDirFn d η z) := by
      unfold IsUnitVec roundDirFn
      rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hv_pos.ne']
    have hrd_dist : ‖roundDirFn d η z - z‖ ≤ (η : ℝ) / 8 := by
      set v := roundVecFn d η z
      have h1 : ‖‖v‖⁻¹ • v - v‖ = |1 - ‖v‖| := by
        have hsub : ‖v‖⁻¹ • v - v = (‖v‖⁻¹ - 1) • v := by rw [sub_smul, one_smul]
        rw [hsub, norm_smul, Real.norm_eq_abs]
        calc |(‖v‖⁻¹ - 1)| * ‖v‖ = |(‖v‖⁻¹ - 1)| * |‖v‖| := by rw [abs_of_pos hv_pos]
          _ = |(‖v‖⁻¹ - 1) * ‖v‖| := (abs_mul _ _).symm
          _ = |1 - ‖v‖| := by congr 1; field_simp [hv_pos.ne']
      have h2 : |1 - ‖v‖| ≤ ‖v - z‖ := by
        rw [← hz, abs_sub_comm]
        exact abs_norm_sub_norm_le v z
      have htri2 : ‖‖v‖⁻¹ • v - z‖ ≤ ‖‖v‖⁻¹ • v - v‖ + ‖v - z‖ :=
        norm_sub_le_norm_sub_add_norm_sub _ v _
      unfold roundDirFn
      linarith
    have hk_in_box : roundLatFn d η z ∈ Box := by
      refine Finset.mem_filter.mpr ⟨Fintype.mem_piFinset.mpr fun c => ?_, hlat_ne⟩
      have hzc := abs_le.mp (unitVec_coord_abs_le_one hz c)
      have hinv_pos : 0 < 1 / (meshRat d η : ℝ) := by positivity
      have hy_lo : -(1 / (meshRat d η : ℝ)) ≤ euclideanCoord z c / (meshRat d η : ℝ) := by
        rw [← neg_div, div_le_div_iff_of_pos_right hmesh_r]
        linarith [hzc.1]
      have hy_hi : euclideanCoord z c / (meshRat d η : ℝ) ≤ 1 / (meshRat d η : ℝ) := by
        rw [div_le_div_iff_of_pos_right hmesh_r]
        linarith [hzc.2]
      have hM_ge : 1 / (meshRat d η : ℝ) + 1 ≤ (M : ℝ) := by
        dsimp [M]; push_cast; linarith [Nat.le_ceil (1 / (meshRat d η : ℝ))]
      have hfl_lo : -(M : ℤ) ≤ roundLatFn d η z c := by
        have hlt : (-(M : ℤ) - 1 : ℝ) < euclideanCoord z c / (meshRat d η : ℝ) + 1 / 2 := by
          push_cast; linarith
        have := Int.lt_floor_add_one (-(M : ℤ) - 1 : ℝ)
        exact Int.le_floor.mpr (by push_cast; linarith)
      have hfl_hi : roundLatFn d η z c ≤ (M : ℤ) := by
        have hle : euclideanCoord z c / (meshRat d η : ℝ) + 1 / 2 ≤ (M : ℝ) := by linarith
        exact Int.floor_le_iff.mpr (by push_cast; linarith)
      exact Finset.mem_Icc.mpr ⟨hfl_lo, hfl_hi⟩
    have hrd_mem : roundDirFn d η z ∈ dirNet d η := by
      unfold dirNet roundDirFn roundVecFn
      exact Finset.mem_image_of_mem _ hk_in_box
    exact ⟨hlat_ne, hrd_mem, hrd_unit, hrd_dist⟩

  let z0 : EuclideanSpace ℝ (Fin d) := EuclideanSpace.single (⟨0, by omega⟩ : Fin d) (1 : ℝ)
  have hz0_unit : IsUnitVec z0 := by unfold IsUnitVec z0; simp
  have hnet_ne : (dirNet d η).Nonempty := ⟨roundDirFn d η z0, (hround_z z0 hz0_unit).2.1⟩

  have hnet_elems : ∀ z_hat ∈ dirNet d η, IsUnitVec z_hat ∧
      ∃ k : Fin d → ℤ, k ≠ 0 ∧
        let v := ratPointToEuclidean (fun c => (k c : ℚ) * meshRat d η)
        z_hat = ‖v‖⁻¹ • v := by
    intro z_hat hzh
    unfold dirNet at hzh
    rcases Finset.mem_image.mp hzh with ⟨k, hkBox, rfl⟩
    have hk_ne : k ≠ 0 := (Finset.mem_filter.mp hkBox).2
    set v := ratPointToEuclidean (fun c => (k c : ℚ) * meshRat d η)
    have hv_ne : v ≠ 0 := by
      intro hv0
      apply hk_ne
      funext c
      have hc := congrArg (fun u : EuclideanSpace ℝ (Fin d) => euclideanCoord u c) hv0
      have hc0 : ((k c : ℝ) * (meshRat d η : ℝ)) = 0 := by
        simpa [v, ratPointToEuclidean, euclideanCoord, Rat.cast_mul] using hc
      rcases mul_eq_zero.mp hc0 with hkc | hmc
      · exact_mod_cast hkc
      · exact absurd hmc hmesh_r.ne'
    have hunit : IsUnitVec (‖v‖⁻¹ • v) := by
      unfold IsUnitVec
      rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm,
        inv_mul_cancel₀ (norm_ne_zero_iff.mpr hv_ne)]
    exact ⟨hunit, k, hk_ne, rfl⟩

  have hnet_card_log :
      Real.log ((dirNet d η).card : ℝ) ≤ 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) := by
    set X := (d : ℝ) / (η : ℝ)
    have hX16 : 16 ≤ X := by rw [le_div_iff₀ hη_r]; linarith
    have hI_card : I.card = 2 * M + 1 := by
      simp only [I, Int.card_Icc]; omega
    have hcard_nat : (dirNet d η).card ≤ (2 * M + 1) ^ d := by
      unfold dirNet
      calc (Box.image _).card ≤ Box.card := Finset.card_image_le
        _ ≤ (Fintype.piFinset (fun _ : Fin d => I)).card := Finset.card_filter_le _ _
        _ = ∏ _c : Fin d, I.card := Fintype.card_piFinset _
        _ = (2 * M + 1) ^ d := by simp [hI_card]
    have hM_le : (M : ℝ) ≤ 8 * X + 2 := by
      have hceil_lt : (Nat.ceil (1 / (meshRat d η : ℝ)) : ℝ) < 1 / (meshRat d η : ℝ) + 1 :=
        Nat.ceil_lt_add_one (by positivity)
      have hinv_X : 1 / (meshRat d η : ℝ) ≤ 8 * X := by
        dsimp [X]
        calc 1 / (meshRat d η : ℝ) ≤ 8 * (d : ℝ) / (η : ℝ) := hinv_hi
          _ = 8 * ((d : ℝ) / (η : ℝ)) := mul_div_assoc _ _ _
      dsimp [M]
      push_cast
      linarith
    have h2M1_le : ((2 * M + 1 : ℕ) : ℝ) ≤ X ^ 4 := by
      have h1 : ((2 * M + 1 : ℕ) : ℝ) ≤ 16 * X + 5 := by push_cast; linarith
      have hX2 : 256 ≤ X ^ 2 := by nlinarith
      have hX4 : 256 * X ≤ X ^ 4 := by nlinarith
      linarith
    have hcard_pos : (0 : ℝ) < ((dirNet d η).card : ℝ) := by exact_mod_cast hnet_ne.card_pos
    have hcard_pow : ((dirNet d η).card : ℝ) ≤ (X ^ 4) ^ d := by
      have h1 : ((dirNet d η).card : ℝ) ≤ ((2 * M + 1 : ℕ) : ℝ) ^ d := by exact_mod_cast hcard_nat
      exact h1.trans (pow_le_pow_left₀ (by positivity) h2M1_le d)
    calc Real.log ((dirNet d η).card : ℝ)
        ≤ Real.log ((X ^ 4) ^ d) := Real.log_le_log hcard_pos hcard_pow
      _ = (d : ℝ) * Real.log (X ^ 4) := Real.log_pow _ _
      _ = (d : ℝ) * ((4 : ℕ) * Real.log X) := by rw [Real.log_pow]
      _ = 4 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) := by push_cast; ring

  exact ⟨hnet_ne, hnet_elems, hnet_card_log, hround_z⟩

/-! ### 3. `roundSubroutine` in `ArithRAM` and its `ExecStmt` specification -/

/-- Generic `ArithRAMStmt` computing `roundLatFn d η z c` into `.heap outTbl (c : ℤ)` for all
`c : Fin d`, using scratch word table `wTbl` (`0..5`) and scratch real table `rTbl` (`0..2`),
reading `η.num, η.den` from `etaNumE, etaDenE` and `z_c` from `.extraReal c`. -/
def roundSubroutine (etaNumE etaDenE : IntExpr) (outTbl wTbl rTbl : ℕ) : ArithRAMStmt :=
  let sE := IntExpr.readHeap wTbl (.lit 0)
  let pE := IntExpr.readHeap wTbl (.lit 1)
  let kE := IntExpr.readHeap wTbl (.lit 2)
  let cE := IntExpr.readHeap wTbl (.lit 3)
  let loE := IntExpr.readHeap wTbl (.lit 4)
  let stepE := IntExpr.readHeap wTbl (.lit 5)
  let invMeshExpr : RealExpr :=
    .div
      (.mul (.mul (.ofInt (.lit 8)) (.ofInt sE)) (.ofInt etaDenE))
      (.ofInt etaNumE)
  let yExpr : RealExpr :=
    .add
      (.mul (.extraReal cE) (.readRealHeap rTbl (.lit 0)))
      (.div (.ofInt (.lit 1)) (.ofInt (.lit 2)))
  let midE := IntExpr.add loE stepE
  seqStmts
    [ -- Step R1: `w[0] := ceilSqrt d`
      .writeWordHeap wTbl (.lit 0) (.lit 1),
      .whileLoop (.intLt (.mul sE sE) .dim)
        (.writeWordHeap wTbl (.lit 0) (.add sE (.lit 1))),
      -- Step R2: `r[0] := invMesh`, `r[1] := invMesh + 2`
      .writeRealHeap rTbl (.lit 0) invMeshExpr,
      .writeRealHeap rTbl (.lit 1) (.add (.readRealHeap rTbl (.lit 0)) (.ofInt (.lit 2))),
      -- Step R3: double `w[1] = 2^K` until `(w[1] : ℝ) > invMesh + 2`, tracking `K` in `w[2]`
      .writeWordHeap wTbl (.lit 1) (.lit 1),
      .writeWordHeap wTbl (.lit 2) (.lit 0),
      .whileLoop (.realLe (.ofInt pE) (.readRealHeap rTbl (.lit 1)))
        (.seq
          (.writeWordHeap wTbl (.lit 1) (.mul (.lit 2) pE))
          (.writeWordHeap wTbl (.lit 2) (.add kE (.lit 1)))),
      -- Step R4: coordinate loop `c = 0 .. d - 1`
      .writeWordHeap wTbl (.lit 3) (.lit 0),
      .repeatN .dim
        (seqStmts
          [ .writeRealHeap rTbl (.lit 2) yExpr,
            .writeWordHeap wTbl (.lit 4) (.neg pE),
            .writeWordHeap wTbl (.lit 5) pE,
            .repeatN (.add kE (.lit 1))
              (.seq
                (.ite (.realLe (.ofInt midE) (.readRealHeap rTbl (.lit 2)))
                  (.writeWordHeap wTbl (.lit 4) midE)
                  .skip)
                (.writeWordHeap wTbl (.lit 5) (.div stepE (.lit 2)))),
            .writeWordHeap outTbl cE loE,
            .writeWordHeap wTbl (.lit 3) (.add cE (.lit 1)) ]) ]

set_option maxHeartbeats 800000 in
theorem exec_roundSubroutine {d : ℕ} (hd : 1 ≤ d)
    {η : ℚ} (hη0 : 0 < η) (hη16 : (η : ℝ) ≤ 1 / 16)
    {z : EuclideanSpace ℝ (Fin d)} (hz : IsUnitVec z)
    (inp : ArithRAMInput d)
    (hExtra : ∀ c : Fin d, listGetIntD inp.extraReals (c.val : ℤ) 0 = euclideanCoord z c)
    (etaNumE etaDenE : IntExpr) (outTbl wTbl rTbl : ℕ)
    (hout_ne : outTbl ≠ wTbl)
    (mem₀ : ArithRAMMemory) (hc₀ : CleanMem mem₀)
    (hNum : ∀ m : ArithRAMMemory,
      (∀ idx, wRead m outTbl idx = wRead mem₀ outTbl idx) →
      (∀ idx, wRead m wTbl idx = wRead mem₀ wTbl idx) →
      -- even simpler: `etaNumE` and `etaDenE` don't read `outTbl` or `wTbl`:
      True)
    (hNumEval : ∀ ws : WordStore,
      (∀ t i, t ≠ outTbl → t ≠ wTbl → ws.read (.heap t i) = mem₀.words.read (.heap t i)) →
      ∃ u b, evalIntExpr inp.toWordView 0 ws etaNumE = (η.num, u, b) ∧ u ≤ 5)
    (hDenEval : ∀ ws : WordStore,
      (∀ t i, t ≠ outTbl → t ≠ wTbl → ws.read (.heap t i) = mem₀.words.read (.heap t i)) →
      ∃ u b, evalIntExpr inp.toWordView 0 ws etaDenE = ((η.den : ℤ), u, b) ∧ u ≤ 5) :
    ∃ (mem₁ : ArithRAMMemory) (C_cost : ℕ),
      ExecStmt inp (roundSubroutine etaNumE etaDenE outTbl wTbl rTbl) mem₀ mem₁ C_cost ∧
      (C_cost : ℝ) ≤ 600 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) ∧
      (∀ c : Fin d, wRead mem₁ outTbl (c.val : ℤ) = roundLatFn d η z c) ∧
      (∀ t i, t ≠ outTbl → t ≠ wTbl → wRead mem₁ t i = wRead mem₀ t i) ∧
      (∀ i, (i < 0 ∨ (d : ℤ) ≤ i) → wRead mem₁ outTbl i = wRead mem₀ outTbl i) ∧
      (∀ i, (i < 0 ∨ 6 ≤ i) → wRead mem₁ wTbl i = wRead mem₀ wTbl i) ∧
      (∀ t i, t ≠ rTbl → rRead mem₁ t i = rRead mem₀ t i) ∧
      (∀ i, (i < 0 ∨ 3 ≤ i) → rRead mem₁ rTbl i = rRead mem₀ rTbl i) ∧
      mem₁.words.live ⊆ mem₀.words.live ∪ heapRange outTbl d ∪ heapRange wTbl 6 ∧
      mem₁.reals.live ⊆ mem₀.reals.live ∪ heapRange rTbl 3 := by
  let _ := hNum
  rcases ceilSqrt_props hd with ⟨hS1, hSd, hd_le_S2, hSm1_lt⟩
  rcases meshRat_bounds hd hη0 with ⟨_, hmesh_r, hinv_rat, hinv_lo, hinv_hi⟩
  have hη_r : (0 : ℝ) < (η : ℝ) := by exact_mod_cast hη0
  have hd_r : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  have hη16_div : 16 ≤ (d : ℝ) / (η : ℝ) := by rw [le_div_iff₀ hη_r]; linarith
  have hlog2 : 2 ≤ Real.log ((d : ℝ) / (η : ℝ)) := by
    have hexp2 : Real.exp 2 ≤ 16 := by
      have h1 : Real.exp 2 = Real.exp 1 * Real.exp 1 := by rw [← Real.exp_add]; norm_num
      have he4 := exp_one_le_four; have he0 := (Real.exp_pos 1).le
      rw [h1]; nlinarith
    calc (2 : ℝ) = Real.log (Real.exp 2) := (Real.log_exp 2).symm
      _ ≤ Real.log ((d : ℝ) / (η : ℝ)) := Real.log_le_log (Real.exp_pos 2) (hexp2.trans hη16_div)

  -- Footprint preservation predicate relative to `mem₀`
  let W_foot := mem₀.words.live ∪ heapRange outTbl d ∪ heapRange wTbl 6
  let R_foot := mem₀.reals.live ∪ heapRange rTbl 3
  let Pres (m : ArithRAMMemory) : Prop :=
    (∀ t i, t ≠ outTbl → t ≠ wTbl → wRead m t i = wRead mem₀ t i) ∧
    (∀ i, (i < 0 ∨ (d : ℤ) ≤ i) → wRead m outTbl i = wRead mem₀ outTbl i) ∧
    (∀ i, (i < 0 ∨ 6 ≤ i) → wRead m wTbl i = wRead mem₀ wTbl i) ∧
    (∀ t i, t ≠ rTbl → rRead m t i = rRead mem₀ t i) ∧
    (∀ i, (i < 0 ∨ 3 ≤ i) → rRead m rTbl i = rRead mem₀ rTbl i) ∧
    m.words.live ⊆ W_foot ∧
    m.reals.live ⊆ R_foot

  have hPres₀ : Pres mem₀ := ⟨fun _ _ _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl,
    fun _ _ _ => rfl, fun _ _ => rfl,
    Finset.subset_union_left.trans Finset.subset_union_left,
    Finset.subset_union_left⟩

  have hPres_wTbl : ∀ {m : ArithRAMMemory} (hp : Pres m) (idx : ℤ) (hidx : 0 ≤ idx ∧ idx < 6) (v : ℤ),
      Pres (wWrite m wTbl idx v) := by
    intro m hp idx hidx v
    refine ⟨fun t i ht1 ht2 => (wRead_wWrite_of_ne m v (Or.inl ht2)).trans (hp.1 t i ht1 ht2),
      fun i hi => (wRead_wWrite_of_ne m v (Or.inl hout_ne)).trans (hp.2.1 i hi),
      fun i hi => (wRead_wWrite_of_ne m v (Or.inr (by omega))).trans (hp.2.2.1 i hi),
      fun t i ht => hp.2.2.2.1 t i ht,
      fun i hi => hp.2.2.2.2.1 i hi,
      wWrite_words_live hp.2.2.2.2.2.1 v (Finset.mem_union_right _ (mem_heapRange hidx.1 hidx.2)),
      hp.2.2.2.2.2.2⟩

  have hPres_outTbl : ∀ {m : ArithRAMMemory} (hp : Pres m) (idx : ℤ) (hidx : 0 ≤ idx ∧ idx < (d : ℤ)) (v : ℤ),
      Pres (wWrite m outTbl idx v) := by
    intro m hp idx hidx v
    refine ⟨fun t i ht1 ht2 => (wRead_wWrite_of_ne m v (Or.inl ht1)).trans (hp.1 t i ht1 ht2),
      fun i hi => (wRead_wWrite_of_ne m v (Or.inr (by omega))).trans (hp.2.1 i hi),
      fun i hi => (wRead_wWrite_of_ne m v (Or.inl hout_ne.symm)).trans (hp.2.2.1 i hi),
      fun t i ht => hp.2.2.2.1 t i ht,
      fun i hi => hp.2.2.2.2.1 i hi,
      wWrite_words_live hp.2.2.2.2.2.1 v
        (Finset.mem_union_left _ (Finset.mem_union_right _ (mem_heapRange hidx.1 hidx.2))),
      hp.2.2.2.2.2.2⟩

  have hPres_rTbl : ∀ {m : ArithRAMMemory} (hp : Pres m) (idx : ℤ) (hidx : 0 ≤ idx ∧ idx < 3) (v : ℝ),
      Pres (rWrite m rTbl idx v) := by
    intro m hp idx hidx v
    refine ⟨fun t i ht1 ht2 => hp.1 t i ht1 ht2,
      fun i hi => hp.2.1 i hi,
      fun i hi => hp.2.2.1 i hi,
      fun t i ht => (rRead_rWrite_of_ne m v (Or.inl ht)).trans (hp.2.2.2.1 t i ht),
      fun i hi => (rRead_rWrite_of_ne m v (Or.inr (by omega))).trans (hp.2.2.2.2.1 i hi),
      hp.2.2.2.2.2.1,
      rWrite_reals_live hp.2.2.2.2.2.2 v (Finset.mem_union_right _ (mem_heapRange hidx.1 hidx.2))⟩

  -- Step R1: `w[0] := 1`, then `ceilSqrt d - 1` iterations of incrementing `w[0]`
  set S := ceilSqrt d
  let m1_0 := wWrite mem₀ wTbl 0 1
  have sR1_init : ExecStmt inp (.writeWordHeap wTbl (.lit 0) (.lit 1)) mem₀ m1_0 5 :=
    exec_wSet_lit inp hc₀ wTbl 0 (.lit 1) 5 (by simp [evalIntExpr])
  have hPres_1_0 : Pres m1_0 := hPres_wTbl hPres₀ 0 ⟨by omega, by omega⟩ 1

  let sE := IntExpr.readHeap wTbl (.lit 0)
  let InvR1 : ℕ → ArithRAMMemory → Prop := fun j m =>
    Pres m ∧ wRead m wTbl 0 = ((j + 1 : ℕ) : ℤ)
  have hInvR1_0 : InvR1 0 m1_0 := ⟨hPres_1_0, by simp [m1_0]⟩
  rcases ExecStmt.whileLoop_nat (cond := .intLt (.mul sE sE) .dim) (S - 1) 10 10 InvR1 sR1_init.2.1 hInvR1_0
    (fun j hj m hcm ⟨hpm, hw0⟩ => by
      have hj_sq : (j + 1) ^ 2 < d := by
        have hle : j + 1 ≤ S - 1 := by omega
        calc (j + 1) ^ 2 ≤ (S - 1) ^ 2 := Nat.pow_le_pow_left hle 2
          _ < d := hSm1_lt
      have hj_sq_z : (((j + 1 : ℕ) : ℤ) * ((j + 1 : ℕ) : ℤ) < (d : ℤ)) := by
        have : (((j + 1) ^ 2 : ℕ) : ℤ) < (d : ℤ) := by exact_mod_cast hj_sq
        simpa [sq] using this
      have hw0' : m.words.read (.heap wTbl 0) = ((j + 1 : ℕ) : ℤ) := hw0
      refine ⟨evalCond_true inp m (.intLt (.mul sE sE) .dim) 10
        (by simp [evalArithCond, evalIntExpr, sE, hw0']; exact hj_sq_z)
        (by simp only [evalArithCond, evalIntExpr, sE]; omega),
        ⟨wWrite m wTbl 0 ((j + 2 : ℕ) : ℤ), ?_, ?_⟩⟩
      · have hstep := exec_wSet_lit inp hcm wTbl 0 (.add sE (.lit 1)) 10
          (by simp [evalIntExpr, sE])
        have hval : (evalIntExpr inp.toWordView 0 m.words (.add sE (.lit 1))).1 = ((j + 2 : ℕ) : ℤ) := by
          simp [evalIntExpr, sE, hw0']; try omega
        simpa [hval] using hstep
      · exact ⟨hPres_wTbl hpm 0 ⟨by omega, by omega⟩ _, wRead_wWrite_self _ _ _ _⟩)
    (fun m _ ⟨_, hw0⟩ => by
      have hS_eq : S - 1 + 1 = S := by omega
      rw [hS_eq] at hw0
      have hnot_lt : ¬ ((S : ℤ) * (S : ℤ) < (d : ℤ)) := by
        have : (d : ℤ) ≤ ((S ^ 2 : ℕ) : ℤ) := by exact_mod_cast hd_le_S2
        push_cast at this
        linarith
      have hw0' : m.words.read (.heap wTbl 0) = (S : ℤ) := hw0
      exact evalCond_false inp m (.intLt (.mul sE sE) .dim) 10
        (by simp [evalArithCond, evalIntExpr, sE, hw0']; exact not_lt.mp hnot_lt)
        (by simp only [evalArithCond, evalIntExpr, sE]; omega))
    with ⟨m1, ⟨hPres_1, hwS_1⟩, sR1_loop⟩

  -- Step R2: `r[0] := invMesh`, `r[1] := invMesh + 2`
  let invMesh := 1 / (meshRat d η : ℝ)
  let invMeshExpr : RealExpr :=
    .div (.mul (.mul (.ofInt (.lit 8)) (.ofInt sE)) (.ofInt etaDenE)) (.ofInt etaNumE)
  rcases hNumEval m1.words hPres_1.1 with ⟨uNum1, bNum1, hNum1, huNum1⟩
  rcases hDenEval m1.words hPres_1.1 with ⟨uDen1, bDen1, hDen1, huDen1⟩
  have hwS_1' : m1.words.read (.heap wTbl 0) = (S : ℤ) := by simpa [Nat.sub_add_cancel hS1] using hwS_1
  have sR2_1 := exec_rSet_lit inp sR1_loop.2.1 rTbl 0 invMeshExpr 25
    (by simp [invMeshExpr, sE, evalRealExpr, evalIntExpr, hNum1, hDen1]; omega)
  let m2_0 := rWrite m1 rTbl 0 invMesh
  have hm2_0_eq : rWrite m1 rTbl 0 (evalRealExpr inp 0 m1 invMeshExpr).1 = m2_0 := by
    congr 1
    simp only [invMeshExpr, sE, evalRealExpr, evalIntExpr, hwS_1', hNum1, hDen1, invMesh]
    rw [hinv_rat]; push_cast; rfl
  rw [hm2_0_eq] at sR2_1
  have hPres_2_0 : Pres m2_0 := hPres_rTbl hPres_1 0 ⟨by omega, by omega⟩ invMesh

  have sR2_2 := exec_rSet_lit inp sR2_1.2.1 rTbl 1
    (.add (.readRealHeap rTbl (.lit 0)) (.ofInt (.lit 2))) 10
    (by simp [evalRealExpr, evalIntExpr])
  let m2 := rWrite m2_0 rTbl 1 (invMesh + 2)
  have hm2_eq : rWrite m2_0 rTbl 1
      (evalRealExpr inp 0 m2_0 (.add (.readRealHeap rTbl (.lit 0)) (.ofInt (.lit 2)))).1 = m2 := by
    congr 1
    have hr0 : m2_0.reals.read (.heap rTbl 0) = invMesh := rRead_rWrite_self _ _ _ _
    simp [evalRealExpr, evalIntExpr, hr0]
  rw [hm2_eq] at sR2_2
  have hPres_2 : Pres m2 := hPres_rTbl hPres_2_0 1 ⟨by omega, by omega⟩ (invMesh + 2)
  have hr0_2 : rRead m2 rTbl 0 = invMesh :=
    (rRead_rWrite_of_ne m2_0 _ (Or.inr (by decide))).trans (rRead_rWrite_self _ _ _ _)
  have hr1_2 : rRead m2 rTbl 1 = invMesh + 2 := rRead_rWrite_self _ _ _ _

  -- Step R3: Find smallest `K : ℕ` with `invMesh + 2 < (2 : ℝ) ^ K`
  have hex_K : ∃ K : ℕ, invMesh + 2 < (2 : ℝ) ^ K := by
    refine ⟨Nat.ceil (invMesh + 2) + 1, ?_⟩
    have h1 : invMesh + 2 < (Nat.ceil (invMesh + 2) + 1 : ℝ) := by
      linarith [Nat.le_ceil (invMesh + 2)]
    have h2 : ((Nat.ceil (invMesh + 2) + 1 : ℕ) : ℝ) ≤ (2 : ℝ) ^ (Nat.ceil (invMesh + 2) + 1) :=
      nat_cast_le_two_pow _
    push_cast at h2
    linarith
  let K : ℕ := Nat.find hex_K
  have hK_gt : invMesh + 2 < (2 : ℝ) ^ K := Nat.find_spec hex_K
  have hK_min : ∀ j < K, (2 : ℝ) ^ j ≤ invMesh + 2 := fun j hj => not_lt.mp (Nat.find_min hex_K hj)
  have hinv_ge8 : 8 ≤ invMesh := by
    have : 8 / (1 : ℝ) ≤ 8 / (η : ℝ) :=
      div_le_div_of_nonneg_left (by norm_num) hη_r (by linarith)
    linarith
  have hK_pos : 1 ≤ K := by
    by_contra hK0
    have h0 : K = 0 := by omega
    rw [h0, pow_zero] at hK_gt
    linarith
  have hK_ub : (K : ℝ) ≤ 7 * Real.log ((d : ℝ) / (η : ℝ)) := by
    have hprev : (2 : ℝ) ^ (K - 1) ≤ invMesh + 2 := hK_min (K - 1) (by omega)
    have hub_9 : invMesh + 2 ≤ 9 * ((d : ℝ) / (η : ℝ)) := by
      have : invMesh ≤ 8 * ((d : ℝ) / (η : ℝ)) := by dsimp [invMesh]; linarith [hinv_hi.trans_eq (mul_div_assoc 8 (d : ℝ) (η : ℝ))]
      linarith
    have hexp_half : Real.exp (((K - 1 : ℕ) : ℝ) / 2) ≤ (2 : ℝ) ^ (K - 1) := by
      calc Real.exp (((K - 1 : ℕ) : ℝ) / 2)
          = Real.exp ((K - 1 : ℕ) * (1 / 2 : ℝ)) := by ring_nf
        _ = (Real.exp (1 / 2 : ℝ)) ^ (K - 1) := Real.exp_nat_mul _ (K - 1)
        _ ≤ (2 : ℝ) ^ (K - 1) := pow_le_pow_left₀ (Real.exp_pos _).le exp_half_le_two (K - 1)
    have h9_le_exp4 : (9 : ℝ) ≤ Real.exp 4 := by
      have h2e : (2 : ℝ) ≤ Real.exp 1 := two_le_exp_one
      have h16 : (16 : ℝ) ≤ Real.exp 4 := by
        have : Real.exp 4 = (Real.exp 1) ^ 4 := by simpa using Real.exp_nat_mul 1 4
        rw [this]
        calc (16 : ℝ) = 2 ^ 4 := by norm_num
          _ ≤ (Real.exp 1) ^ 4 := pow_le_pow_left₀ (by norm_num) h2e 4
      linarith
    have hexp_bound : Real.exp (((K - 1 : ℕ) : ℝ) / 2) ≤
        Real.exp (4 + Real.log ((d : ℝ) / (η : ℝ))) := by
      rw [Real.exp_add, Real.exp_log (by positivity)]
      calc Real.exp (((K - 1 : ℕ) : ℝ) / 2) ≤ invMesh + 2 := hexp_half.trans hprev
        _ ≤ 9 * ((d : ℝ) / (η : ℝ)) := hub_9
        _ ≤ Real.exp 4 * ((d : ℝ) / (η : ℝ)) :=
            mul_le_mul_of_nonneg_right h9_le_exp4 (by positivity)
    have hkm1 : ((K - 1 : ℕ) : ℝ) / 2 ≤ 4 + Real.log ((d : ℝ) / (η : ℝ)) :=
      Real.exp_le_exp.mp hexp_bound
    have hK_cast : ((K - 1 : ℕ) : ℝ) = (K : ℝ) - 1 := by
      rw [Nat.cast_sub hK_pos]; simp
    rw [hK_cast] at hkm1
    linarith

  let m3_0 := wWrite (wWrite m2 wTbl 1 1) wTbl 2 0
  have sR3_1 : ExecStmt inp (.writeWordHeap wTbl (.lit 1) (.lit 1)) m2 (wWrite m2 wTbl 1 1) 5 :=
    exec_wSet_lit inp sR2_2.2.1 wTbl 1 (.lit 1) 5 (by simp [evalIntExpr])
  have sR3_2 : ExecStmt inp (.writeWordHeap wTbl (.lit 2) (.lit 0)) (wWrite m2 wTbl 1 1) m3_0 5 :=
    exec_wSet_lit inp sR3_1.2.1 wTbl 2 (.lit 0) 5 (by simp [evalIntExpr])
  have hPres_3_0 : Pres m3_0 :=
    hPres_wTbl (hPres_wTbl hPres_2 1 ⟨by omega, by omega⟩ 1) 2 ⟨by omega, by omega⟩ 0

  let pE := IntExpr.readHeap wTbl (.lit 1)
  let kE := IntExpr.readHeap wTbl (.lit 2)
  let InvR3 : ℕ → ArithRAMMemory → Prop := fun j m =>
    Pres m ∧
    wRead m wTbl 1 = ((2 ^ j : ℕ) : ℤ) ∧
    wRead m wTbl 2 = (j : ℤ) ∧
    rRead m rTbl 0 = invMesh ∧
    rRead m rTbl 1 = invMesh + 2
  have hInvR3_0 : InvR3 0 m3_0 := by
    refine ⟨hPres_3_0, ?_, ?_, ?_, ?_⟩
    · simp [m3_0, wRead_wWrite_of_ne]
    · simp [m3_0]
    · simp [m3_0, hr0_2]
    · simp [m3_0, hr1_2]

  rcases ExecStmt.whileLoop_nat (cond := .realLe (.ofInt pE) (.readRealHeap rTbl (.lit 1))) K 10 20 InvR3 sR3_2.2.1 hInvR3_0
    (fun j hj m hcm ⟨hpm, hwp, hwk, hrr0, hrr1⟩ => by
      have hle_j : ((((2 ^ j : ℕ) : ℤ) : ℝ) ≤ invMesh + 2) := by
        push_cast; exact hK_min j hj
      have hwp' : m.words.read (.heap wTbl 1) = ((2 ^ j : ℕ) : ℤ) := hwp
      have hwk' : m.words.read (.heap wTbl 2) = (j : ℤ) := hwk
      have hrr1' : m.reals.read (.heap rTbl 1) = invMesh + 2 := hrr1
      refine ⟨evalCond_true inp m (.realLe (.ofInt pE) (.readRealHeap rTbl (.lit 1))) 10
        (by simp [evalArithCond, evalRealExpr, evalIntExpr, pE, hwp', hrr1']; exact hK_min j hj)
        (by simp only [evalArithCond, evalRealExpr, evalIntExpr, pE]; omega), ?_⟩
      · let ma := wWrite m wTbl 1 ((2 ^ (j + 1) : ℕ) : ℤ)
        let mb := wWrite ma wTbl 2 ((j + 1 : ℕ) : ℤ)
        have sa : ExecStmt inp (.writeWordHeap wTbl (.lit 1) (.mul (.lit 2) pE)) m ma 10 := by
          have hs := exec_wSet_lit inp hcm wTbl 1 (.mul (.lit 2) pE) 10 (by simp [evalIntExpr, pE])
          have hv : (evalIntExpr inp.toWordView 0 m.words (.mul (.lit 2) pE)).1 =
              ((2 ^ (j + 1) : ℕ) : ℤ) := by
            simp [evalIntExpr, pE, hwp', pow_succ']
          simpa [ma, hv] using hs
        have hwk_a : ma.words.read (.heap wTbl 2) = (j : ℤ) :=
          (wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hwk
        have sb : ExecStmt inp (.writeWordHeap wTbl (.lit 2) (.add kE (.lit 1))) ma mb 10 := by
          have hs := exec_wSet_lit inp sa.2.1 wTbl 2 (.add kE (.lit 1)) 10 (by simp [evalIntExpr, kE])
          have hv : (evalIntExpr inp.toWordView 0 ma.words (.add kE (.lit 1))).1 =
              ((j + 1 : ℕ) : ℤ) := by
            simp [evalIntExpr, kE, hwk_a]
          simpa [mb, hv] using hs
        refine ⟨mb, ExecStmt.seq sa sb,
          hPres_wTbl (hPres_wTbl hpm 1 ⟨by omega, by omega⟩ _) 2 ⟨by omega, by omega⟩ _,
          (wRead_wWrite_of_ne ma _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _),
          wRead_wWrite_self _ _ _ _,
          by simp [mb, ma, hrr0],
          by simp [mb, ma, hrr1]⟩)
    (fun m _ ⟨_, hwp, _, _, hrr1⟩ => by
      have hnot_le : ¬ ((((2 ^ K : ℕ) : ℤ) : ℝ) ≤ invMesh + 2) := by
        push_cast; linarith
      have hwp' : m.words.read (.heap wTbl 1) = ((2 ^ K : ℕ) : ℤ) := hwp
      have hrr1' : m.reals.read (.heap rTbl 1) = invMesh + 2 := hrr1
      exact evalCond_false inp m (.realLe (.ofInt pE) (.readRealHeap rTbl (.lit 1))) 10
        (by simp [evalArithCond, evalRealExpr, evalIntExpr, pE, hwp', hrr1']; exact hK_gt)
        (by simp only [evalArithCond, evalRealExpr, evalIntExpr, pE]; omega))
    with ⟨m3, ⟨hPres_3, hwp_3, hwk_3, hrr0_3, _⟩, sR3_loop⟩

  -- Step R4: coordinate loop `c = 0 .. d - 1`
  let m4_0 := wWrite m3 wTbl 3 0
  have sR4_init : ExecStmt inp (.writeWordHeap wTbl (.lit 3) (.lit 0)) m3 m4_0 5 :=
    exec_wSet_lit inp sR3_loop.2.1 wTbl 3 (.lit 0) 5 (by simp [evalIntExpr])
  have hPres_4_0 : Pres m4_0 := hPres_wTbl hPres_3 3 ⟨by omega, by omega⟩ 0

  let cE := IntExpr.readHeap wTbl (.lit 3)
  let loE := IntExpr.readHeap wTbl (.lit 4)
  let stepE := IntExpr.readHeap wTbl (.lit 5)
  let yExpr : RealExpr :=
    .add (.mul (.extraReal cE) (.readRealHeap rTbl (.lit 0)))
         (.div (.ofInt (.lit 1)) (.ofInt (.lit 2)))
  let midE := IntExpr.add loE stepE
  let coordBody : ArithRAMStmt :=
    seqStmts
      [ .writeRealHeap rTbl (.lit 2) yExpr,
        .writeWordHeap wTbl (.lit 4) (.neg pE),
        .writeWordHeap wTbl (.lit 5) pE,
        .repeatN (.add kE (.lit 1))
          (.seq
            (.ite (.realLe (.ofInt midE) (.readRealHeap rTbl (.lit 2)))
              (.writeWordHeap wTbl (.lit 4) midE)
              .skip)
            (.writeWordHeap wTbl (.lit 5) (.div stepE (.lit 2)))),
        .writeWordHeap outTbl cE loE,
        .writeWordHeap wTbl (.lit 3) (.add cE (.lit 1)) ]

  let InvR4 : ℕ → ArithRAMMemory → Prop := fun c m =>
    Pres m ∧
    wRead m wTbl 1 = ((2 ^ K : ℕ) : ℤ) ∧
    wRead m wTbl 2 = (K : ℤ) ∧
    wRead m wTbl 3 = (c : ℤ) ∧
    rRead m rTbl 0 = invMesh ∧
    (∀ idx : ℕ, idx < c → ∀ hlt : idx < d,
      wRead m outTbl (idx : ℤ) = roundLatFn d η z ⟨idx, hlt⟩)

  have hInvR4_0 : InvR4 0 m4_0 := by
    refine ⟨hPres_4_0,
      (wRead_wWrite_of_ne m3 _ (Or.inr (by decide))).trans hwp_3,
      (wRead_wWrite_of_ne m3 _ (Or.inr (by decide))).trans hwk_3,
      wRead_wWrite_self _ _ _ _,
      by simp [m4_0, hrr0_3],
      fun _ h => absurd h (Nat.not_lt_zero _)⟩

  have hdim_eval : evalIntExpr inp.toWordView 0 m4_0.words .dim =
      ((d : ℤ), 1, intBitLength (d : ℤ)) := rfl

  rcases ExecStmt.repeatN_nat d 5 (65 + (K + 1) * 30) InvR4 sR4_init.2.1 hInvR4_0 hdim_eval (by omega)
    (fun c hc m hcm ⟨hpm, hwp, hwk, hwc, hrr0, hout_prev⟩ => by
      let cf : Fin d := ⟨c, hc⟩
      let Y : ℝ := euclideanCoord z cf * invMesh + 1 / 2
      have hzc_abs := abs_le.mp (unitVec_coord_abs_le_one hz cf)
      have hinv_nn : 0 ≤ invMesh := by positivity
      have hY_lo : -(((2 ^ K : ℕ) : ℤ) : ℝ) ≤ Y := by
        have h1 : -invMesh ≤ euclideanCoord z cf * invMesh := by
          have := mul_le_mul_of_nonneg_right hzc_abs.1 hinv_nn
          linarith
        dsimp [Y]; push_cast; linarith [hK_gt]
      have hY_hi : Y < (((2 ^ K : ℕ) : ℤ) : ℝ) := by
        have h1 : euclideanCoord z cf * invMesh ≤ invMesh := by
          have := mul_le_mul_of_nonneg_right hzc_abs.2 hinv_nn
          linarith
        dsimp [Y]; push_cast; linarith [hK_gt]

      have hwc' : m.words.read (.heap wTbl 3) = (c : ℤ) := hwc
      have hrr0' : m.reals.read (.heap rTbl 0) = invMesh := hrr0
      have hExtra_c : listGetIntD inp.extraReals (c : ℤ) 0 = euclideanCoord z cf := hExtra cf
      have sB1 := exec_rSet_lit inp hcm rTbl 2 yExpr 15
        (by simp [yExpr, cE, evalRealExpr, evalIntExpr])
      let mb1 := rWrite m rTbl 2 Y
      have hmb1 : rWrite m rTbl 2 (evalRealExpr inp 0 m yExpr).1 = mb1 := by
        congr 1
        simp [yExpr, cE, evalRealExpr, evalIntExpr, hwc', hrr0', hExtra_c, Y]
      rw [hmb1] at sB1
      have hPres_b1 := hPres_rTbl hpm 2 ⟨by omega, by omega⟩ Y

      have hwp_b1 : mb1.words.read (.heap wTbl 1) = ((2 ^ K : ℕ) : ℤ) := hwp
      have sB2 := exec_wSet_lit inp sB1.2.1 wTbl 4 (.neg pE) 10 (by simp [evalIntExpr, pE])
      let mb2 := wWrite mb1 wTbl 4 (-((2 ^ K : ℕ) : ℤ))
      have hmb2 : wWrite mb1 wTbl 4 (evalIntExpr inp.toWordView 0 mb1.words (.neg pE)).1 = mb2 := by
        simp [mb2, evalIntExpr, pE, hwp_b1]
      rw [hmb2] at sB2
      have hPres_b2 : Pres mb2 := hPres_wTbl hPres_b1 4 ⟨by omega, by omega⟩ _

      have hwp_b2 : mb2.words.read (.heap wTbl 1) = ((2 ^ K : ℕ) : ℤ) :=
        (wRead_wWrite_of_ne mb1 _ (Or.inr (by decide))).trans hwp
      have sB3 := exec_wSet_lit inp sB2.2.1 wTbl 5 pE 10 (by simp [evalIntExpr, pE])
      let mb3 := wWrite mb2 wTbl 5 ((2 ^ K : ℕ) : ℤ)
      have hmb3 : wWrite mb2 wTbl 5 (evalIntExpr inp.toWordView 0 mb2.words pE).1 = mb3 := by
        simp [mb3, evalIntExpr, pE, hwp_b2]
      rw [hmb3] at sB3
      have hPres_b3 : Pres mb3 := hPres_wTbl hPres_b2 5 ⟨by omega, by omega⟩ _

      have hwk_b3 : mb3.words.read (.heap wTbl 2) = (K : ℤ) :=
        (wRead_wWrite_of_ne mb2 _ (Or.inr (by decide))).trans
          ((wRead_wWrite_of_ne mb1 _ (Or.inr (by decide))).trans hwk)

      let InvBS : ℕ → ArithRAMMemory → Prop := fun j ms =>
        Pres ms ∧
        wRead ms wTbl 1 = ((2 ^ K : ℕ) : ℤ) ∧
        wRead ms wTbl 2 = (K : ℤ) ∧
        wRead ms wTbl 3 = (c : ℤ) ∧
        rRead ms rTbl 0 = invMesh ∧
        rRead ms rTbl 2 = Y ∧
        (∀ idx : ℕ, idx < c → ∀ hlt : idx < d,
          wRead ms outTbl (idx : ℤ) = roundLatFn d η z ⟨idx, hlt⟩) ∧
        (j ≤ K → wRead ms wTbl 5 = ((2 ^ (K - j) : ℕ) : ℤ)) ∧
        ((wRead ms wTbl 4 : ℝ) ≤ Y ∧ Y < (wRead ms wTbl 4 : ℝ) + ((2 ^ (K + 1 - j) : ℕ) : ℝ))

      have hInvBS_0 : InvBS 0 mb3 := by
        refine ⟨hPres_b3,
          (wRead_wWrite_of_ne mb2 _ (Or.inr (by decide))).trans hwp_b2,
          hwk_b3,
          (wRead_wWrite_of_ne mb2 _ (Or.inr (by decide))).trans
            ((wRead_wWrite_of_ne mb1 _ (Or.inr (by decide))).trans hwc),
          by simp [mb3, mb2, mb1, rRead_rWrite_of_ne, hrr0],
          by simp [mb3, mb2, mb1],
          fun idx hidx hlt => by
            simp only [mb3, mb2, mb1]
            rw [wRead_wWrite_of_ne _ _ (Or.inl hout_ne), wRead_wWrite_of_ne _ _ (Or.inl hout_ne)]
            exact hout_prev idx hidx hlt,
          fun _ => by simp [mb3],
          ?_⟩
        have hw4 : wRead mb3 wTbl 4 = -((2 ^ K : ℕ) : ℤ) :=
          (wRead_wWrite_of_ne mb2 _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _)
        rw [hw4]
        refine ⟨by simpa using hY_lo, ?_⟩
        have hpow_succ : ((2 ^ (K + 1) : ℕ) : ℝ) = 2 * ((2 ^ K : ℕ) : ℝ) := by
          rw [pow_succ']; push_cast; ring
        simp only [Nat.sub_zero, hpow_succ]
        push_cast at hY_hi ⊢
        linarith

      have hcnt_bs : evalIntExpr inp.toWordView 0 mb3.words (.add kE (.lit 1)) =
          (((K + 1 : ℕ) : ℤ), 4, (evalIntExpr inp.toWordView 0 mb3.words (.add kE (.lit 1))).2.2) := by
        simp [evalIntExpr, kE, hwk_b3]

      rcases ExecStmt.repeatN_nat (K + 1) 10 30 InvBS sB3.2.1 hInvBS_0 hcnt_bs (by omega)
        (fun j hj ms hcms ⟨hpms, hwp_s, hwk_s, hwc_s, hrr0_s, hrr2_s, hout_s, hw5_s, hlo_s, hhi_s⟩ => by
          have hjK : j ≤ K := by omega
          let stepN : ℕ := 2 ^ (K - j)
          have hw5_eq : ms.words.read (.heap wTbl 5) = (stepN : ℤ) := hw5_s hjK
          let loVal : ℤ := ms.words.read (.heap wTbl 4)
          have hlo_eq : ms.words.read (.heap wTbl 4) = loVal := rfl
          have hrr2_eq : ms.reals.read (.heap rTbl 2) = Y := hrr2_s
          have h2step : ((2 ^ (K + 1 - j) : ℕ) : ℝ) = 2 * (stepN : ℝ) := by
            have hsub : K + 1 - j = (K - j) + 1 := by omega
            dsimp [stepN]; rw [hsub, pow_succ']; push_cast; ring
          have hnext_step : ((2 ^ (K + 1 - (j + 1)) : ℕ) : ℝ) = (stepN : ℝ) := by
            have hsub : K + 1 - (j + 1) = K - j := by omega
            rw [hsub]

          by_cases hcond : ((loVal + (stepN : ℤ) : ℤ) : ℝ) ≤ Y
          · -- True branch: `w[4] := loVal + stepN`
            rcases evalCond_true inp ms (.realLe (.ofInt midE) (.readRealHeap rTbl (.lit 2))) 10
              (by simp [evalArithCond, evalRealExpr, evalIntExpr, midE, loE, stepE, hlo_eq, hw5_eq, hrr2_eq]; push_cast at hcond; linarith)
              (by simp only [evalArithCond, evalRealExpr, evalIntExpr, midE, loE, stepE]; omega)
              with ⟨uc_t, hceval, huc_t⟩
            have st_br : ExecStmt inp (.writeWordHeap wTbl (.lit 4) midE) ms
                (wWrite ms wTbl 4 (loVal + (stepN : ℤ))) 10 := by
              have hs := exec_wSet_lit inp hcms wTbl 4 midE 10
                (by simp [evalIntExpr, midE, loE, stepE])
              have hv : (evalIntExpr inp.toWordView 0 ms.words midE).1 = loVal + (stepN : ℤ) := by
                simp [evalIntExpr, midE, loE, stepE, hlo_eq, hw5_eq]
              simpa [hv] using hs
            have site := ExecStmt.ite_true (fB := .skip) hceval huc_t st_br
            let msa := wWrite ms wTbl 4 (loVal + (stepN : ℤ))
            have hw5_msa : msa.words.read (.heap wTbl 5) = (stepN : ℤ) :=
              (wRead_wWrite_of_ne ms _ (Or.inr (by decide))).trans hw5_eq
            have sdiv : ExecStmt inp (.writeWordHeap wTbl (.lit 5) (.div stepE (.lit 2))) msa
                (wWrite msa wTbl 5 ((stepN : ℤ) / 2)) 10 := by
              have hs := exec_wSet_lit inp site.2.1 wTbl 5 (.div stepE (.lit 2)) 10
                (by simp [evalIntExpr, stepE])
              have hv : (evalIntExpr inp.toWordView 0 msa.words (.div stepE (.lit 2))).1 =
                  (stepN : ℤ) / 2 := by
                simp [evalIntExpr, stepE, hw5_msa]
              rw [hv] at hs
              exact hs
            let msb := wWrite msa wTbl 5 ((stepN : ℤ) / 2)
            refine ⟨msb, (ExecStmt.seq site sdiv).mono_cost (by omega),
              hPres_wTbl (hPres_wTbl hpms 4 ⟨by omega, by omega⟩ _) 5 ⟨by omega, by omega⟩ _,
              by simp [msb, msa, wRead_wWrite_of_ne, hwp_s],
              by simp [msb, msa, wRead_wWrite_of_ne, hwk_s],
              by simp [msb, msa, wRead_wWrite_of_ne, hwc_s],
              by simp [msb, msa, hrr0_s],
              by simp [msb, msa, hrr2_s],
              fun idx hidx hlt => by
                simp only [msb, msa]
                rw [wRead_wWrite_of_ne _ _ (Or.inl hout_ne), wRead_wWrite_of_ne _ _ (Or.inl hout_ne)]
                exact hout_s idx hidx hlt,
              fun hj1 => ?_,
              ?_⟩
            · rw [wRead_wWrite_self]
              have hsub : K - j = (K - (j + 1)) + 1 := by omega
              have hstep_div : (stepN : ℤ) / 2 = ((2 ^ (K - (j + 1)) : ℕ) : ℤ) := by
                dsimp [stepN]; rw [hsub, pow_succ']; push_cast; omega
              exact hstep_div
            · have hw4_msb : wRead msb wTbl 4 = loVal + (stepN : ℤ) :=
                (wRead_wWrite_of_ne msa _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _)
              rw [hw4_msb, hnext_step]
              refine ⟨hcond, ?_⟩
              have hhi_s' : Y < (loVal : ℝ) + 2 * (stepN : ℝ) := by rw [← h2step]; exact hhi_s
              push_cast at hhi_s' ⊢
              linarith
          · -- False branch: `skip`
            rcases evalCond_false inp ms (.realLe (.ofInt midE) (.readRealHeap rTbl (.lit 2))) 10
              (by simp [evalArithCond, evalRealExpr, evalIntExpr, midE, loE, stepE, hlo_eq, hw5_eq, hrr2_eq]; push_cast at hcond; linarith)
              (by simp only [evalArithCond, evalRealExpr, evalIntExpr, midE, loE, stepE]; omega)
              with ⟨uc_f, hceval, huc_f⟩
            have site := ExecStmt.ite_false (tB := .writeWordHeap wTbl (.lit 4) midE) hceval huc_f (ExecStmt.skip inp hcms)
            have sdiv : ExecStmt inp (.writeWordHeap wTbl (.lit 5) (.div stepE (.lit 2))) ms
                (wWrite ms wTbl 5 ((stepN : ℤ) / 2)) 10 := by
              have hs := exec_wSet_lit inp site.2.1 wTbl 5 (.div stepE (.lit 2)) 10
                (by simp [evalIntExpr, stepE])
              have hv : (evalIntExpr inp.toWordView 0 ms.words (.div stepE (.lit 2))).1 =
                  (stepN : ℤ) / 2 := by
                simp [evalIntExpr, stepE, hw5_eq]
              simpa [hv] using hs
            let msb := wWrite ms wTbl 5 ((stepN : ℤ) / 2)
            refine ⟨msb, (ExecStmt.seq site sdiv).mono_cost (by omega),
              hPres_wTbl hpms 5 ⟨by omega, by omega⟩ _,
              by simp [msb, wRead_wWrite_of_ne, hwp_s],
              by simp [msb, wRead_wWrite_of_ne, hwk_s],
              by simp [msb, wRead_wWrite_of_ne, hwc_s],
              by simp [msb, hrr0_s],
              by simp [msb, hrr2_s],
              fun idx hidx hlt => by
                simp only [msb]
                rw [wRead_wWrite_of_ne _ _ (Or.inl hout_ne)]
                exact hout_s idx hidx hlt,
              fun hj1 => ?_,
              ?_⟩
            · rw [wRead_wWrite_self]
              have hsub : K - j = (K - (j + 1)) + 1 := by omega
              dsimp [stepN]; rw [hsub, pow_succ']; push_cast; omega
            · have hw4_msb : wRead msb wTbl 4 = loVal :=
                wRead_wWrite_of_ne ms _ (Or.inr (by decide))
              rw [hw4_msb, hnext_step]
              refine ⟨hlo_s, ?_⟩
              have hlt_y : Y < ((loVal + (stepN : ℤ) : ℤ) : ℝ) := lt_of_not_ge hcond
              push_cast at hlt_y
              exact hlt_y)
        with ⟨mb4, ⟨hPres_b4, hwp_b4, hwk_b4, hwc_b4, hrr0_b4, _, hout_b4, _, hlo_b4, hhi_b4⟩, sB4⟩

      -- At `j = K + 1`, `2 ^ (K + 1 - (K + 1)) = 1`, so `wRead mb4 wTbl 4 = Int.floor Y = roundLatFn d η z cf`
      have hfl_eq : wRead mb4 wTbl 4 = roundLatFn d η z cf := by
        simp only [Nat.sub_self, pow_zero, Nat.cast_one] at hhi_b4
        have hY_def : Y = euclideanCoord z cf / (meshRat d η : ℝ) + 1 / 2 := by
          dsimp [Y, invMesh]; ring
        unfold roundLatFn
        rw [← hY_def]
        exact (Int.floor_eq_iff.mpr ⟨hlo_b4, hhi_b4⟩).symm

      have hwc_b4' : mb4.words.read (.heap wTbl 3) = (c : ℤ) := hwc_b4
      have hw4_b4' : mb4.words.read (.heap wTbl 4) = roundLatFn d η z cf := hfl_eq
      have sB5 : ExecStmt inp (.writeWordHeap outTbl cE loE) mb4
          (wWrite mb4 outTbl (c : ℤ) (roundLatFn d η z cf)) 10 := by
        have hs := exec_wSet inp sB4.2.1 outTbl cE loE 10 (by simp [evalIntExpr, cE, loE])
        simpa [evalIntExpr, cE, loE, hwc_b4', hw4_b4'] using hs
      let mb5 := wWrite mb4 outTbl (c : ℤ) (roundLatFn d η z cf)
      have hPres_b5 : Pres mb5 := hPres_outTbl hPres_b4 (c : ℤ) ⟨by omega, by omega⟩ _

      have hwc_b5' : mb5.words.read (.heap wTbl 3) = (c : ℤ) :=
        (wRead_wWrite_of_ne mb4 _ (Or.inl hout_ne.symm)).trans hwc_b4
      have sB6 : ExecStmt inp (.writeWordHeap wTbl (.lit 3) (.add cE (.lit 1))) mb5
          (wWrite mb5 wTbl 3 ((c + 1 : ℕ) : ℤ)) 10 := by
        have hs := exec_wSet_lit inp sB5.2.1 wTbl 3 (.add cE (.lit 1)) 10 (by simp [evalIntExpr, cE])
        have hv : (evalIntExpr inp.toWordView 0 mb5.words (.add cE (.lit 1))).1 = ((c + 1 : ℕ) : ℤ) := by
          simp [evalIntExpr, cE, hwc_b5']
        rw [hv] at hs
        exact hs
      let mb6 := wWrite mb5 wTbl 3 ((c + 1 : ℕ) : ℤ)
      have hPres_b6 : Pres mb6 := hPres_wTbl hPres_b5 3 ⟨by omega, by omega⟩ _

      have sBody : ExecStmt inp coordBody m mb6 (65 + (K + 1) * 30) := by
        dsimp [coordBody, seqStmts]
        exact (ExecStmt.seq sB1 (ExecStmt.seq sB2 (ExecStmt.seq sB3
          (ExecStmt.seq sB4 (ExecStmt.seq sB5 sB6))))).mono_cost (by omega)

      have hw1_b6 : wRead mb6 wTbl 1 = ((2 ^ K : ℕ) : ℤ) := by
        dsimp [mb6, mb5]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inl hout_ne.symm)]
        exact hwp_b4
      have hw2_b6 : wRead mb6 wTbl 2 = (K : ℤ) := by
        dsimp [mb6, mb5]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inl hout_ne.symm)]
        exact hwk_b4
      have hw3_b6 : wRead mb6 wTbl 3 = ((c + 1 : ℕ) : ℤ) :=
        wRead_wWrite_self mb5 wTbl 3 ((c + 1 : ℕ) : ℤ)
      have hr0_b6 : rRead mb6 rTbl 0 = invMesh := hrr0_b4
      have hout_b6 : ∀ idx : ℕ, idx < c + 1 → ∀ hlt : idx < d,
          wRead mb6 outTbl (idx : ℤ) = roundLatFn d η z ⟨idx, hlt⟩ := by
        intro idx hidx hlt
        dsimp [mb6, mb5]
        rw [wRead_wWrite_of_ne _ _ (Or.inl hout_ne)]
        by_cases heqc : idx = c
        · subst heqc
          exact wRead_wWrite_self mb4 outTbl (idx : ℤ) (roundLatFn d η z cf)
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          exact hout_b4 idx (by omega) hlt
      exact ⟨mb6, sBody, hPres_b6, hw1_b6, hw2_b6, hw3_b6, hr0_b6, hout_b6⟩)
    with ⟨m4, ⟨hPres_4, _, _, _, _, hout_4⟩, sR4_loop⟩

  let totalCost : ℕ :=
    5 + ((S - 1 + 1) * 10 + (S - 1) * 10) + 25 + 10 + 5 + 5 +
      ((K + 1) * 10 + K * 20) + 5 + (5 + d * (65 + (K + 1) * 30))
  have sTot : ExecStmt inp (roundSubroutine etaNumE etaDenE outTbl wTbl rTbl) mem₀ m4 totalCost := by
    unfold roundSubroutine
    dsimp [seqStmts]
    exact (ExecStmt.seq sR1_init (ExecStmt.seq sR1_loop (ExecStmt.seq sR2_1
      (ExecStmt.seq sR2_2 (ExecStmt.seq sR3_1 (ExecStmt.seq sR3_2
        (ExecStmt.seq sR3_loop (ExecStmt.seq sR4_init sR4_loop)))))))).mono_cost (by omega)

  have hCost_ub : (totalCost : ℝ) ≤ 600 * (d : ℝ) * Real.log ((d : ℝ) / (η : ℝ)) := by
    let Llog := Real.log ((d : ℝ) / (η : ℝ))
    have hL2 : 2 ≤ Llog := hlog2
    have hSm1_le : ((S - 1 : ℕ) : ℝ) ≤ (d : ℝ) := by
      have : S - 1 ≤ d := by omega
      exact_mod_cast this
    have htot_eq : (totalCost : ℝ) =
        80 + 20 * ((S - 1 : ℕ) : ℝ) + 30 * (K : ℝ) + 95 * (d : ℝ) + 30 * ((d : ℝ) * (K : ℝ)) := by
      dsimp [totalCost]
      push_cast
      ring
    have hdL : 2 * (d : ℝ) ≤ (d : ℝ) * Llog := by
      have := mul_le_mul_of_nonneg_left hL2 (by positivity : (0 : ℝ) ≤ (d : ℝ))
      linarith
    have h1_dL : 2 ≤ (d : ℝ) * Llog := by linarith [hd_r, hdL]
    have hK_dL : (K : ℝ) ≤ 7 * ((d : ℝ) * Llog) := by
      have h1 : Llog ≤ (d : ℝ) * Llog := by
        simpa using mul_le_mul_of_nonneg_right hd_r (by linarith : (0 : ℝ) ≤ Llog)
      linarith [hK_ub, h1]
    have hdK_dL : (d : ℝ) * (K : ℝ) ≤ 7 * ((d : ℝ) * Llog) := by
      have := mul_le_mul_of_nonneg_left hK_ub (by positivity : (0 : ℝ) ≤ (d : ℝ))
      linarith
    dsimp [Llog] at *
    linarith [htot_eq, hSm1_le, hdL, h1_dL, hK_dL, hdK_dL]

  exact ⟨m4, totalCost, sTot, hCost_ub,
    fun c => hout_4 c.val c.isLt c.isLt,
    hPres_4.1, hPres_4.2.1, hPres_4.2.2.1, hPres_4.2.2.2.1, hPres_4.2.2.2.2.1, hPres_4.2.2.2.2.2.1, hPres_4.2.2.2.2.2.2⟩

end UL.Proof_clm_6_1_adaptive
