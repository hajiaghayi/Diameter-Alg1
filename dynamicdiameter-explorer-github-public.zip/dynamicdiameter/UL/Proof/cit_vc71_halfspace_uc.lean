import UL.Stmt.cit_vc71_halfspace_uc
import UL.Proof.cit_vc71_halfspace_uc_v30.Defs
import UL.Proof.cit_vc71_halfspace_uc_v30.H1
import UL.Proof.cit_vc71_halfspace_uc_v30.H2
import UL.Proof.cit_vc71_halfspace_uc_v30.H3_backup
import UL.Proof.cit_vc71_halfspace_uc_v30.H4
set_option autoImplicit false

namespace UL

open UL.Proof_cit_vc71_v30

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_cit_vc71_halfspace_uc : S_cit_vc71_halfspace_uc := by
  unfold S_cit_vc71_halfspace_uc
  refine ⟨2048, by norm_num, ?_⟩
  intro D hD ι _ _ _ _ P r s hr hs φ hφ0 hφ1 hN
  dsimp only
  classical
  let N : ℕ := r * s
  let ε : ℝ := 1 / (2 * (s : ℝ))
  have hN_pos : 1 ≤ N := Nat.mul_pos hr hs
  have hε_pos : 0 < ε := by positivity
  obtain ⟨hNε, h_tail⟩ := vc_sample_complexity_arith hD hr hs hφ0 hφ1 hN
  have h_sym := symmetrization_card_le (P := P) hN_pos hε_pos hNε
  have h_trace : ∀ z : Fin N ⊕ Fin N → EuclideanSpace ℝ (Fin D),
      (halfspaceTraceFamily z).card ≤ ∑ k ∈ Finset.Iic (D + 1), (2 * N).choose k := by
    intro z
    have hcard : Fintype.card (Fin N ⊕ Fin N) = 2 * N := by
      simp [two_mul]
    simpa [hcard] using card_halfspaceTraceFamily_le z
  have h_rad := doubleBad_card_le_of_trace (P := P) hN_pos hε_pos h_trace
  have h_bad_le :
      ((badSampleFinset P ε : Finset (Fin N → ι)).card : ℝ) /
        (Fintype.card (Fin N → ι) : ℝ) ≤ φ / 2 := by
    have h_cast : ((∑ k ∈ Finset.Iic (D + 1), (2 * N).choose k : ℕ) : ℝ) =
        ∑ k ∈ Finset.Iic (D + 1), ((2 * N).choose k : ℝ) := by push_cast; rfl
    rw [h_cast] at h_rad
    have h2 :
        2 * (((doubleBadFinset P ε : Finset ((Fin N → ι) × (Fin N → ι))).card : ℝ) /
          (Fintype.card ((Fin N → ι) × (Fin N → ι)) : ℝ)) ≤
        4 * (∑ k ∈ Finset.Iic (D + 1), ((2 * N).choose k : ℝ)) *
          Real.exp (-((N : ℝ) * ε ^ 2 / 8)) := by
      linarith
    exact h_sym.trans (h2.trans h_tail)
  let μ : Set (EuclideanSpace ℝ (Fin D)) → ℝ :=
    fun H => (pointCount P H : ℝ) / (Fintype.card ι : ℝ)
  let μ_hat : (Fin N → ι) → Set (EuclideanSpace ℝ (Fin D)) → ℝ :=
    fun ω H => (pointCount (fun t : Fin N => P (ω t)) H : ℝ) / ((r : ℝ) * (s : ℝ))
  let GoodSet : Set (Fin N → ι) :=
    {ω : Fin N → ι |
      (⨆ H : {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H},
        |μ_hat ω H.1 - μ H.1|) ≤ ε}
  change 1 - φ / 2 ≤
    (MeasureTheory.Measure.pi
      (fun _ : Fin N => (PMF.uniformOfFintype ι).toMeasure)).real GoodSet
  rw [pi_uniform_real_eq_card_div N ι GoodSet]
  haveI : Nonempty {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H} :=
    exists_closedHalfspace_of_pos hD
  have h_emp_eq : ∀ (ω : Fin N → ι) (H : Set (EuclideanSpace ℝ (Fin D))),
      μ_hat ω H = empFreq P ω H := by
    intro ω H
    simp [μ_hat, empFreq, N, Nat.cast_mul]
  have h_pop_eq : ∀ H : Set (EuclideanSpace ℝ (Fin D)), μ H = popFreq P H :=
    fun _ => rfl
  have h_bdd : ∀ ω : Fin N → ι,
      BddAbove (Set.range (fun H : {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H} =>
        |μ_hat ω H.1 - μ H.1|)) := by
    intro ω
    refine ⟨1, ?_⟩
    rintro _ ⟨H, rfl⟩
    dsimp only
    rw [h_emp_eq, h_pop_eq]
    obtain ⟨he0, he1⟩ := empFreq_mem_Icc hN_pos P ω H.1
    obtain ⟨hp0, hp1⟩ := popFreq_mem_Icc P H.1
    exact abs_le.mpr ⟨by linarith, by linarith⟩
  have h_good_iff : ∀ ω : Fin N → ι,
      ω ∈ GoodSet ↔ ω ∉ (badSampleFinset P ε : Finset (Fin N → ι)) := by
    intro ω
    simp only [GoodSet, Set.mem_setOf_eq, badSampleFinset, Finset.mem_filter, Finset.mem_univ,
      true_and]
    rw [ciSup_le_iff (h_bdd ω)]
    simp only [Subtype.forall, h_emp_eq, h_pop_eq, not_exists, not_and, not_lt]
  have h_filter_eq :
      Finset.univ.filter (fun ω : Fin N → ι => ω ∈ GoodSet) =
        Finset.univ \ (badSampleFinset P ε : Finset (Fin N → ι)) := by
    ext ω
    simp [h_good_iff ω]
  rw [h_filter_eq]
  have h_sub : (badSampleFinset P ε : Finset (Fin N → ι)) ⊆ Finset.univ :=
    Finset.subset_univ _
  have h_card_sdiff :
      ((Finset.univ \ (badSampleFinset P ε : Finset (Fin N → ι))).card : ℝ) =
        (Fintype.card (Fin N → ι) : ℝ) -
          ((badSampleFinset P ε : Finset (Fin N → ι)).card : ℝ) := by
    have h_nat :
        (Finset.univ \ (badSampleFinset P ε : Finset (Fin N → ι))).card +
          (badSampleFinset P ε : Finset (Fin N → ι)).card =
          Fintype.card (Fin N → ι) := by
      rw [Finset.card_sdiff_add_card_eq_card h_sub, Finset.card_univ]
    have h_real :
        ((Finset.univ \ (badSampleFinset P ε : Finset (Fin N → ι))).card : ℝ) +
          ((badSampleFinset P ε : Finset (Fin N → ι)).card : ℝ) =
          (Fintype.card (Fin N → ι) : ℝ) := by
      exact_mod_cast h_nat
    linarith
  have h_card_pos : (0 : ℝ) < (Fintype.card (Fin N → ι) : ℝ) := by
    exact_mod_cast Fintype.card_pos (α := Fin N → ι)
  rw [h_card_sdiff, sub_div, div_self h_card_pos.ne']
  linarith

end UL
