import UL.Stmt.clm_5_3_global_factor_c
import UL.Stmt.lem_5_2
import UL.Stmt.clm_5_3_matching_invariant
import UL.Stmt.lem_5_5
import UL.Proof.clm_5_3_global_factor_c.H1_Chain
import UL.Proof.clm_5_3_global_factor_c.H2_Ops
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_5_3_global_factor_c (h_lem_5_2 : S_lem_5_2) (h_clm_5_3_matching_invariant : S_clm_5_3_matching_invariant) (h_lem_5_5 : S_lem_5_5) : S_clm_5_3_global_factor_c := by
  unfold S_clm_5_3_global_factor_c
  exact ⟨UL.Proof_clm_5_3_global_factor_c.prove_conjunct_1 h_lem_5_5,
    UL.Proof_clm_5_3_global_factor_c.prove_conjunct_2⟩

end UL
