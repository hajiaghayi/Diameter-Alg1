import UL.Stmt.lem_5_3
set_option autoImplicit false

namespace UL

namespace Proof_lem_5_3

private lemma nodeMaxRadius_nonneg {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (S : Finset ι) :
    0 ≤ nodeMaxRadius pts o S := by
  unfold nodeMaxRadius
  split_ifs with hS
  · obtain ⟨x, hx⟩ := hS
    exact (norm_nonneg _).trans (Finset.le_sup' (fun z => ‖pts z - o‖) hx)
  · exact le_rfl

private lemma nodeCoreInputDiam_nonneg {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) :
    0 ≤ nodeCoreInputDiam pts o V S := by
  unfold nodeCoreInputDiam indexedCoreInputDiam
  split_ifs with hCS
  · obtain ⟨x, hx⟩ := hCS.1
    obtain ⟨y, hy⟩ := hCS.2
    have hmem : (x, y) ∈ nodeCore pts o V S ×ˢ S := Finset.mem_product.mpr ⟨hx, hy⟩
    exact (norm_nonneg _).trans
      (Finset.le_sup' (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) hmem)
  · exact le_rfl

open Classical in
private lemma nodeCoreInputDiam_le {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) :
    nodeCoreInputDiam pts o V S ≤ Real.sqrt V + nodeMaxRadius pts o S := by
  unfold nodeCoreInputDiam indexedCoreInputDiam
  split_ifs with hCS
  · refine Finset.sup'_le (hCS.1.product hCS.2) (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) ?_
    intro xy hxy
    rcases xy with ⟨x, y⟩
    rcases Finset.mem_product.mp hxy with ⟨hxC, hyS⟩
    have hx_ball : pts x ∈ coreBall o V := by
      unfold nodeCore at hxC
      exact (Finset.mem_filter.mp hxC).2
    have hx_norm : ‖pts x - o‖ ≤ Real.sqrt V := by
      unfold coreBall at hx_ball
      simpa [Metric.mem_closedBall, dist_eq_norm] using hx_ball
    have hy_norm : ‖pts y - o‖ ≤ nodeMaxRadius pts o S := by
      unfold nodeMaxRadius
      rw [dif_pos hCS.2]
      exact Finset.le_sup' (fun z => ‖pts z - o‖) hyS
    have htri : ‖pts x - pts y‖ ≤ ‖pts x - o‖ + ‖pts y - o‖ := by
      have hsub : pts x - pts y = (pts x - o) - (pts y - o) := by abel
      rw [hsub]
      exact norm_sub_le (pts x - o) (pts y - o)
    exact htri.trans (add_le_add hx_norm hy_norm)
  · exact add_nonneg (Real.sqrt_nonneg V) (nodeMaxRadius_nonneg pts o S)

end Proof_lem_5_3

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_5_3 : S_lem_5_3 := by
  unfold S_lem_5_3
  intro d ι pts o V S L c K hV hL hc_gt _hc_lt hK h_range
  have hD_nonneg := Proof_lem_5_3.nodeCoreInputDiam_nonneg pts o V S
  have hD_le := Proof_lem_5_3.nodeCoreInputDiam_le pts o V S
  have hR_nonneg := Proof_lem_5_3.nodeMaxRadius_nonneg pts o S
  unfold SatisfiesBaselineLengthCond at hL
  split_ifs at hL with hS
  · rcases hL with ⟨hL_nonneg, hL_sq⟩
    by_cases hL0 : L = 0
    · right
      have hV0 : V = 0 := by nlinarith [sq_nonneg (nodeMaxRadius pts o S)]
      have hR_sq : nodeMaxRadius pts o S ^ 2 = 0 := by nlinarith
      have hR0 : nodeMaxRadius pts o S = 0 := sq_eq_zero_iff.mp hR_sq
      have hsqrt0 : Real.sqrt V = 0 := by rw [hV0, Real.sqrt_zero]
      have hD0 : nodeCoreInputDiam pts o V S = 0 := by linarith
      exact ⟨hD0, hL0⟩
    · left
      have hL_pos : 0 < L := lt_of_le_of_ne hL_nonneg (Ne.symm hL0)
      have hR_le_L : nodeMaxRadius pts o S ≤ L := by nlinarith
      by_cases hV0 : V = 0
      · have hsqrt0 : Real.sqrt V = 0 := by rw [hV0, Real.sqrt_zero]
        nlinarith
      · have hV_pos : 0 < V := lt_of_le_of_ne hV (Ne.symm hV0)
        have hsqrtV_pos : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV_pos
        rcases h_range with hV_eq | hR_gt
        · exact absurd hV_eq hV0
        · have hc1_pos : 0 < c - 1 := by linarith
          have hK_mul : 2 ≤ (K : ℝ) * (c - 1) := (div_le_iff₀ hc1_pos).mp hK
          have h1 : 2 * Real.sqrt V ≤ (K : ℝ) * (c - 1) * Real.sqrt V :=
            mul_le_mul_of_nonneg_right hK_mul (le_of_lt hsqrtV_pos)
          have h2 : (c - 1) * ((K : ℝ) * Real.sqrt V) < (c - 1) * nodeMaxRadius pts o S :=
            mul_lt_mul_of_pos_left hR_gt hc1_pos
          have h3 : Real.sqrt V + nodeMaxRadius pts o S < c * nodeMaxRadius pts o S := by
            linarith
          have h4 : c * nodeMaxRadius pts o S ≤ c * L := by nlinarith
          linarith
  · right
    have hCS : ¬ ((nodeCore pts o V S).Nonempty ∧ S.Nonempty) := fun h => hS h.2
    have hD0 : nodeCoreInputDiam pts o V S = 0 := by
      unfold nodeCoreInputDiam indexedCoreInputDiam
      rw [dif_neg hCS]
    exact ⟨hD0, hL⟩

end UL
