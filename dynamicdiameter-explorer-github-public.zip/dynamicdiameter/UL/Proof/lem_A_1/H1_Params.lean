import Mathlib
import UL.Def.def_computation_model
set_option autoImplicit false

namespace UL.Proof_lem_A_1

/-- Block sample size `s(K, D, k) = 64 K^2 (D + 1)^3 (k + 1)`. -/
def sVal (K D k : ℕ) : ℕ :=
  64 * K ^ 2 * (D + 1) ^ 3 * (k + 1)

/-- Number of blocks `r(K, D, k) = 2 K (D + 1) s^2 (k + 1)`. -/
def rVal (K D k : ℕ) : ℕ :=
  2 * K * (D + 1) * (sVal K D k) ^ 2 * (k + 1)

/-- Total sample size `M(K, D, k) = r(K, D, k) * s(K, D, k)`. -/
def mVal (K D k : ℕ) : ℕ :=
  rVal K D k * sVal K D k

/-- Centerpoint depth fraction `α(K, D, φ) = 1 / (2 s)`. -/
noncomputable def alphaVal (K D : ℕ) (φ : ℝ) : ℝ :=
  1 / (2 * (sVal K D (Nat.ceil (Real.logb 2 (1 / φ))) : ℝ))

theorem sVal_pos {K D k : ℕ} (hK : 1 ≤ K) : 1 ≤ sVal K D k := by
  unfold sVal
  have hK0 : 0 < K := by omega
  have hpos : 0 < 64 * K ^ 2 * (D + 1) ^ 3 * (k + 1) := by positivity
  omega

theorem rVal_pos {K D k : ℕ} (hK : 1 ≤ K) : 1 ≤ rVal K D k := by
  unfold rVal
  have hK0 : 0 < K := by omega
  have hs0 : 0 < sVal K D k := sVal_pos hK
  have hpos : 0 < 2 * K * (D + 1) * (sVal K D k) ^ 2 * (k + 1) := by positivity
  omega

theorem mVal_pos {K D k : ℕ} (hK : 1 ≤ K) : 1 ≤ mVal K D k := by
  unfold mVal
  exact Nat.mul_pos (rVal_pos hK) (sVal_pos hK)

theorem log_le_self_of_pos {x : ℝ} (hx : 0 < x) : Real.log x ≤ x :=
  (Real.log_le_sub_one_of_pos hx).trans (by linarith)

theorem log_le_div_add {x A : ℝ} (hx : 0 < x) (hA : 0 < A) :
    Real.log x ≤ x / A + A := by
  have hsplit : Real.log x = Real.log (x / A) + Real.log A := by
    conv_lhs => rw [show x = (x / A) * A from (div_mul_cancel₀ x hA.ne').symm]
    exact Real.log_mul (div_pos hx hA).ne' hA.ne'
  rw [hsplit]
  linarith [log_le_self_of_pos (div_pos hx hA), log_le_self_of_pos hA]

theorem half_le_log_two : (1 / 2 : ℝ) ≤ Real.log 2 := by
  have h1 : (1 / 2 : ℝ) ≤ Real.exp (-(1 / 2 : ℝ)) := by
    have := Real.add_one_le_exp (-(1 / 2 : ℝ))
    linarith
  have h2 : Real.exp (1 / 2 : ℝ) ≤ 2 := by
    have hmul : (1 / 2 : ℝ) * (2 * Real.exp (1 / 2 : ℝ)) ≤
        Real.exp (-(1 / 2 : ℝ)) * (2 * Real.exp (1 / 2 : ℝ)) :=
      mul_le_mul_of_nonneg_right h1 (by positivity)
    have hprod : Real.exp (-(1 / 2 : ℝ)) * Real.exp (1 / 2 : ℝ) = 1 := by
      rw [← Real.exp_add]
      norm_num
    linarith
  rw [Real.le_log_iff_exp_le (by norm_num)]
  exact h2

theorem log_two_le_one : Real.log 2 ≤ 1 := by
  have := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)
  linarith

private theorem ceil_logb_bounds_aux {φ : ℝ} {k : ℕ}
    (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2) (hk_eq : k = Nat.ceil (Real.logb 2 (1 / φ))) :
    1 ≤ k ∧
    0 < Real.log (1 / φ) ∧
    Real.log (1 / φ) ≤ (k : ℝ) ∧
    ((k : ℝ) + 1) ≤ 2 * (Real.log (1 / φ) + 1) := by
  have h_two_lt : (2 : ℝ) < 1 / φ := by
    rw [lt_div_iff₀ hφ0]
    linarith
  have h_one_lt : (1 : ℝ) < 1 / φ := by linarith
  have h_log_pos : 0 < Real.log (1 / φ) := Real.log_pos h_one_lt
  have h_log2_pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have h_logb_eq : Real.logb 2 (1 / φ) = Real.log (1 / φ) / Real.log 2 := rfl
  have h_logb_pos : 0 < Real.logb 2 (1 / φ) := by
    rw [h_logb_eq]
    exact div_pos h_log_pos h_log2_pos
  have hk_pos : 1 ≤ k := by
    rw [hk_eq]
    exact Nat.one_le_iff_ne_zero.mpr (Nat.ceil_pos.mpr h_logb_pos).ne'
  have h_le_k : Real.log (1 / φ) / Real.log 2 ≤ (k : ℝ) := by
    rw [hk_eq, ← h_logb_eq]
    exact Nat.le_ceil _
  have h_log_le_k : Real.log (1 / φ) ≤ (k : ℝ) := by
    have h1 : Real.log (1 / φ) ≤ (k : ℝ) * Real.log 2 := (div_le_iff₀ h_log2_pos).mp h_le_k
    have h2 : (k : ℝ) * Real.log 2 ≤ (k : ℝ) * 1 :=
      mul_le_mul_of_nonneg_left log_two_le_one (Nat.cast_nonneg k)
    linarith
  have hk_lt : (k : ℝ) < Real.log (1 / φ) / Real.log 2 + 1 := by
    rw [hk_eq, ← h_logb_eq]
    exact Nat.ceil_lt_add_one h_logb_pos.le
  have h_div_le_two : Real.log (1 / φ) / Real.log 2 ≤ 2 * Real.log (1 / φ) := by
    rw [div_le_iff₀ h_log2_pos]
    have := mul_le_mul_of_nonneg_left half_le_log_two h_log_pos.le
    linarith
  exact ⟨hk_pos, h_log_pos, h_log_le_k, by linarith⟩

theorem ceil_logb_bounds {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2) :
    let k : ℕ := Nat.ceil (Real.logb 2 (1 / φ))
    1 ≤ k ∧
    0 < Real.log (1 / φ) ∧
    Real.log (1 / φ) ≤ (k : ℝ) ∧
    ((k : ℝ) + 1) ≤ 2 * (Real.log (1 / φ) + 1) :=
  ceil_logb_bounds_aux hφ0 hφ1 rfl

private theorem poly_s_half_bound {x y z : ℝ} (hx : 1 ≤ x) (hy : 1 ≤ y) (hz : 1 ≤ z) :
    x * y * (y * (2 * y) + (8 * x + y + 2 * z)) + 8 * x ^ 2 * y ^ 2 ≤
      32 * (x ^ 2 * y ^ 3 * z) := by
  have hx0 : 0 ≤ x := by linarith
  have hy0 : 0 ≤ y := by linarith
  have hz0 : 0 ≤ z := by linarith
  have hx2 : x ≤ x ^ 2 := by nlinarith
  have hy2 : y ≤ y ^ 2 := by nlinarith
  have hy3 : y ^ 2 ≤ y ^ 3 := by
    calc
      y ^ 2 = y ^ 2 * 1 := (mul_one _).symm
      _ ≤ y ^ 2 * y := mul_le_mul_of_nonneg_left hy (sq_nonneg y)
      _ = y ^ 3 := by ring
  have hy13 : y ≤ y ^ 3 := hy2.trans hy3
  have hxy3 : 0 ≤ x ^ 2 * y ^ 3 := by positivity
  have h1 : x * y ^ 3 ≤ x ^ 2 * y ^ 3 * z :=
    (mul_le_mul_of_nonneg_right hx2 (pow_nonneg hy0 3)).trans
      (le_mul_of_one_le_right hxy3 hz)
  have h2 : x ^ 2 * y ≤ x ^ 2 * y ^ 3 * z :=
    (mul_le_mul_of_nonneg_left hy13 (sq_nonneg x)).trans
      (le_mul_of_one_le_right hxy3 hz)
  have h3 : x * y ^ 2 ≤ x ^ 2 * y ^ 3 * z :=
    (mul_le_mul hx2 hy3 (sq_nonneg y) (sq_nonneg x)).trans
      (le_mul_of_one_le_right hxy3 hz)
  have h4 : x * y * z ≤ x ^ 2 * y ^ 3 * z := by
    have hxy : x * y ≤ x ^ 2 * y ^ 3 := mul_le_mul hx2 hy13 hy0 (sq_nonneg x)
    exact mul_le_mul_of_nonneg_right hxy hz0
  have h5 : x ^ 2 * y ^ 2 ≤ x ^ 2 * y ^ 3 * z :=
    (mul_le_mul_of_nonneg_left hy3 (sq_nonneg x)).trans
      (le_mul_of_one_le_right hxy3 hz)
  have hlhs :
      x * y * (y * (2 * y) + (8 * x + y + 2 * z)) + 8 * x ^ 2 * y ^ 2 =
        2 * (x * y ^ 3) + 8 * (x ^ 2 * y) + (x * y ^ 2) + 2 * (x * y * z) + 8 * (x ^ 2 * y ^ 2) := by
    ring
  rw [hlhs]
  have hM : 0 ≤ x ^ 2 * y ^ 3 * z := mul_nonneg hxy3 hz0
  linarith

theorem alphaVal_props {K : ℕ} (hK : 1 ≤ K) {D : ℕ} (_hD : 1 ≤ D)
    {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2) :
    0 < alphaVal K D φ ∧
    alphaVal K D φ ≤ 1 ∧
    (alphaVal K D φ)⁻¹ ≤
      (256 * (K : ℝ) ^ 2) * ((D : ℝ) + 1) ^ 3 * (Real.log (1 / φ) + 1) ^ 3 := by
  unfold alphaVal
  generalize hk_eq : Nat.ceil (Real.logb 2 (1 / φ)) = k
  obtain ⟨_, hlog_pos, _, hk_upper⟩ := ceil_logb_bounds_aux hφ0 hφ1 hk_eq.symm
  have hs_pos_nat : 1 ≤ sVal K D k := sVal_pos hK
  have hs_pos : (0 : ℝ) < (sVal K D k : ℝ) := by exact_mod_cast hs_pos_nat
  refine ⟨by positivity, ?_, ?_⟩
  · rw [div_le_one (by positivity)]
    have : (1 : ℝ) ≤ (sVal K D k : ℝ) := by exact_mod_cast hs_pos_nat
    linarith
  · rw [one_div, inv_inv]
    have hs_eq : (sVal K D k : ℝ) =
        64 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3 * ((k : ℝ) + 1) := by
      unfold sVal
      push_cast
      ring
    rw [hs_eq]
    have hL1 : (1 : ℝ) ≤ Real.log (1 / φ) + 1 := by linarith
    have hk_pow : (k : ℝ) + 1 ≤ 2 * (Real.log (1 / φ) + 1) ^ 3 := by
      have hsq : 1 ≤ (Real.log (1 / φ) + 1) ^ 2 := one_le_pow₀ hL1
      have hpow : Real.log (1 / φ) + 1 ≤ (Real.log (1 / φ) + 1) ^ 3 := by
        calc
          Real.log (1 / φ) + 1 = (Real.log (1 / φ) + 1) * 1 := (mul_one _).symm
          _ ≤ (Real.log (1 / φ) + 1) * (Real.log (1 / φ) + 1) ^ 2 :=
              mul_le_mul_of_nonneg_left hsq (by positivity)
          _ = (Real.log (1 / φ) + 1) ^ 3 := by ring
      linarith
    have hfac : (0 : ℝ) ≤ 128 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3 := by positivity
    calc
      2 * (64 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3 * ((k : ℝ) + 1))
          = (128 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3) * ((k : ℝ) + 1) := by ring
      _ ≤ (128 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3) * (2 * (Real.log (1 / φ) + 1) ^ 3) :=
          mul_le_mul_of_nonneg_left hk_pow hfac
      _ = (256 * (K : ℝ) ^ 2) * ((D : ℝ) + 1) ^ 3 * (Real.log (1 / φ) + 1) ^ 3 := by ring

private theorem hw87_log_2delta_le {K D k s r : ℕ} {φ : ℝ}
    (hK : 1 ≤ K) (hD : 1 ≤ D) (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2)
    (hk_pos : 1 ≤ k) (hlog_le_k : Real.log (1 / φ) ≤ (k : ℝ))
    (hs_nat : 1 ≤ s) (hr_eq : r = 2 * K * (D + 1) * s ^ 2 * (k + 1)) :
    0 < Real.log (2 / (φ / (2 * (r : ℝ)))) ∧
    Real.log (2 / (φ / (2 * (r : ℝ)))) ≤
      8 * (K : ℝ) + ((D : ℝ) + 1) + 2 * ((k : ℝ) + 1) + 2 * Real.log (s : ℝ) := by
  have hK_real : (1 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  have hD_real : (1 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD
  have hk_real : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk_pos
  have hs_real : (1 : ℝ) ≤ (s : ℝ) := by exact_mod_cast hs_nat
  have hD1_pos : (0 : ℝ) < (D : ℝ) + 1 := by linarith
  have hr_cast : (r : ℝ) = 2 * (K : ℝ) * ((D : ℝ) + 1) * (s : ℝ) ^ 2 * ((k : ℝ) + 1) := by
    rw [hr_eq]
    push_cast
    ring
  set B0 : ℝ := 8 * (K : ℝ) * ((D : ℝ) + 1) * ((k : ℝ) + 1) with hB0_def
  have hB0_pos : 0 < B0 := by positivity
  have h2δ : 2 / (φ / (2 * (r : ℝ))) = B0 * (1 / φ) * ((s : ℝ) ^ 2) := by
    rw [hr_cast, hB0_def]
    field_simp [hφ0.ne']
    ring
  rw [h2δ]
  have h_prod_gt1 : 1 < B0 * (1 / φ) * ((s : ℝ) ^ 2) := by
    have h1φ : 2 < 1 / φ := by rw [lt_div_iff₀ hφ0]; linarith
    have hB0_ge1 : 1 ≤ B0 := by
      rw [hB0_def]
      have h1 : (1 : ℝ) ≤ 8 * (K : ℝ) := by linarith
      have h2 : (1 : ℝ) ≤ ((D : ℝ) + 1) * ((k : ℝ) + 1) := by nlinarith
      nlinarith
    have hs2_ge1 : 1 ≤ (s : ℝ) ^ 2 := one_le_pow₀ hs_real
    nlinarith
  refine ⟨Real.log_pos h_prod_gt1, ?_⟩
  have hB0_split :
      Real.log B0 = Real.log (8 * (K : ℝ)) + Real.log ((D : ℝ) + 1) + Real.log ((k : ℝ) + 1) := by
    rw [hB0_def, Real.log_mul (by positivity) (by positivity),
      Real.log_mul (by positivity) (by positivity)]
  rw [Real.log_mul (by positivity) (by positivity),
    Real.log_mul hB0_pos.ne' (by positivity), hB0_split, Real.log_pow]
  have h1 := log_le_self_of_pos (by positivity : (0 : ℝ) < 8 * (K : ℝ))
  have h2 := log_le_self_of_pos hD1_pos
  have h3 := log_le_self_of_pos (by positivity : (0 : ℝ) < (k : ℝ) + 1)
  have hpow2 : ((2 : ℕ) : ℝ) = 2 := by norm_num
  rw [hpow2]
  linarith

private theorem hw87_s_bound_aux {K D k s r : ℕ} {C_HW φ : ℝ}
    (hK : 1 ≤ K) (hCHW : C_HW ≤ (K : ℝ)) (hD : 1 ≤ D)
    (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2)
    (hk_pos : 1 ≤ k) (hlog_le_k : Real.log (1 / φ) ≤ (k : ℝ))
    (hs_eq : s = sVal K D k) (hr_eq : r = rVal K D k) :
    Nat.ceil (C_HW * (1 / ((D : ℝ) + 1))⁻¹ *
      (((D : ℝ) + 1) * Real.log (2 / (1 / ((D : ℝ) + 1))) +
        Real.log (2 / (φ / (2 * (r : ℝ)))))) ≤ s := by
  rw [Nat.ceil_le]
  have hK_real : (1 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  have hD_real : (1 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD
  have hk_real : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk_pos
  have hs_nat : 1 ≤ s := hs_eq ▸ sVal_pos hK
  have hs_real : (1 : ℝ) ≤ (s : ℝ) := by exact_mod_cast hs_nat
  have hD1_pos : (0 : ℝ) < (D : ℝ) + 1 := by linarith
  have hK_pos : (0 : ℝ) < (K : ℝ) := by linarith
  have hr_eq' : r = 2 * K * (D + 1) * s ^ 2 * (k + 1) := by rw [hr_eq, rVal, ← hs_eq]
  obtain ⟨h_log2δ_pos, h_log2δ_le⟩ :=
    hw87_log_2delta_le hK hD hφ0 hφ1 hk_pos hlog_le_k hs_nat hr_eq'
  have hα_inv : (1 / ((D : ℝ) + 1))⁻¹ = (D : ℝ) + 1 := by rw [one_div, inv_inv]
  have h2α : 2 / (1 / ((D : ℝ) + 1)) = 2 * ((D : ℝ) + 1) := by field_simp [hD1_pos.ne']
  rw [hα_inv, h2α]
  have h_term1_pos : 0 < Real.log (2 * ((D : ℝ) + 1)) := Real.log_pos (by linarith)
  have h_term1_le : Real.log (2 * ((D : ℝ) + 1)) ≤ 2 * ((D : ℝ) + 1) :=
    log_le_self_of_pos (by linarith)
  have h_brack_pos :
      0 < ((D : ℝ) + 1) * Real.log (2 * ((D : ℝ) + 1)) +
        Real.log (2 / (φ / (2 * (r : ℝ)))) := by positivity
  have h_step_C :
      C_HW * ((D : ℝ) + 1) *
          (((D : ℝ) + 1) * Real.log (2 * ((D : ℝ) + 1)) +
            Real.log (2 / (φ / (2 * (r : ℝ))))) ≤
        (K : ℝ) * ((D : ℝ) + 1) *
          (((D : ℝ) + 1) * Real.log (2 * ((D : ℝ) + 1)) +
            Real.log (2 / (φ / (2 * (r : ℝ))))) := by
    refine mul_le_mul_of_nonneg_right ?_ h_brack_pos.le
    exact mul_le_mul_of_nonneg_right hCHW hD1_pos.le
  have h_s_term :
      (K : ℝ) * ((D : ℝ) + 1) * (2 * Real.log (s : ℝ)) ≤
        (s : ℝ) / 2 + 8 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 2 := by
    have h_log_s := log_le_div_add (by positivity : (0 : ℝ) < (s : ℝ))
      (by positivity : (0 : ℝ) < 4 * (K : ℝ) * ((D : ℝ) + 1))
    have hmul :
        (K : ℝ) * ((D : ℝ) + 1) * (2 * Real.log (s : ℝ)) ≤
          (K : ℝ) * ((D : ℝ) + 1) *
            (2 * ((s : ℝ) / (4 * (K : ℝ) * ((D : ℝ) + 1)) + 4 * (K : ℝ) * ((D : ℝ) + 1))) := by
      refine mul_le_mul_of_nonneg_left ?_ (by positivity)
      linarith
    have hrhs :
        (K : ℝ) * ((D : ℝ) + 1) *
          (2 * ((s : ℝ) / (4 * (K : ℝ) * ((D : ℝ) + 1)) + 4 * (K : ℝ) * ((D : ℝ) + 1))) =
          (s : ℝ) / 2 + 8 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 2 := by
      field_simp [hK_pos.ne', hD1_pos.ne']
      ring
    linarith
  have hs_cast : (s : ℝ) = 64 * ((K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3 * ((k : ℝ) + 1)) := by
    rw [hs_eq, sVal]
    push_cast
    ring
  have hp := poly_s_half_bound hK_real (by linarith : (1 : ℝ) ≤ (D : ℝ) + 1)
    (by linarith : (1 : ℝ) ≤ (k : ℝ) + 1)
  have h_d1_mul :
      ((D : ℝ) + 1) * Real.log (2 * ((D : ℝ) + 1)) ≤ ((D : ℝ) + 1) * (2 * ((D : ℝ) + 1)) :=
    mul_le_mul_of_nonneg_left h_term1_le hD1_pos.le
  have h_inner :
      ((D : ℝ) + 1) * Real.log (2 * ((D : ℝ) + 1)) + Real.log (2 / (φ / (2 * (r : ℝ)))) ≤
      ((D : ℝ) + 1) * (2 * ((D : ℝ) + 1)) +
        (8 * (K : ℝ) + ((D : ℝ) + 1) + 2 * ((k : ℝ) + 1)) + 2 * Real.log (s : ℝ) := by
    linarith
  have h_mul := mul_le_mul_of_nonneg_left h_inner (by positivity : (0 : ℝ) ≤ (K : ℝ) * ((D : ℝ) + 1))
  exact h_step_C.trans (by linarith)

theorem hw87_s_bound {K : ℕ} (hK : 1 ≤ K) {C_HW : ℝ} (_hCHW0 : 0 < C_HW) (hCHW : C_HW ≤ (K : ℝ))
    {D : ℕ} (hD : 1 ≤ D) {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2) :
    let k : ℕ := Nat.ceil (Real.logb 2 (1 / φ))
    let s : ℕ := sVal K D k
    let r : ℕ := rVal K D k
    let α_net : ℝ := 1 / ((D : ℝ) + 1)
    let δ : ℝ := φ / (2 * (r : ℝ))
    Nat.ceil (C_HW * α_net⁻¹ * (((D : ℝ) + 1) * Real.log (2 / α_net) + Real.log (2 / δ))) ≤ s := by
  obtain ⟨hk_pos, _, hlog_le_k, _⟩ := ceil_logb_bounds_aux hφ0 hφ1 rfl
  exact hw87_s_bound_aux hK hCHW hD hφ0 hφ1 hk_pos hlog_le_k rfl rfl

private theorem vc71_rs_bound_aux {K D k s r : ℕ} {C₀ φ : ℝ}
    (hK : 1 ≤ K) (hC0 : C₀ ≤ (K : ℝ)) (hD : 1 ≤ D)
    (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2)
    (hk_pos : 1 ≤ k) (hlog_le_k : Real.log (1 / φ) ≤ (k : ℝ))
    (hs_eq : s = sVal K D k) (hr_eq : r = rVal K D k) :
    C₀ * (s : ℝ) ^ 2 * (((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ)) ≤
      (r : ℝ) * (s : ℝ) := by
  have hs_nat : 1 ≤ s := hs_eq ▸ sVal_pos hK
  have hs_real : (1 : ℝ) ≤ (s : ℝ) := by exact_mod_cast hs_nat
  have hD_real : (1 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD
  have hk_real : (1 : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk_pos
  have h_logs1_pos : 0 < Real.log ((s : ℝ) + 1) := Real.log_pos (by linarith)
  have h_logs1_le : Real.log ((s : ℝ) + 1) ≤ (s : ℝ) := by
    have := Real.log_le_sub_one_of_pos (by positivity : (0 : ℝ) < (s : ℝ) + 1)
    linarith
  have h2φ_gt1 : 1 < 2 / φ := by rw [lt_div_iff₀ hφ0]; linarith
  have h_log2φ_pos : 0 < Real.log (2 / φ) := Real.log_pos h2φ_gt1
  have h_log2φ_le : Real.log (2 / φ) ≤ (k : ℝ) + 1 := by
    have hsplit : 2 / φ = 2 * (1 / φ) := by ring
    rw [hsplit, Real.log_mul (by norm_num) (by positivity)]
    linarith [log_two_le_one]
  have h_brack_pos :
      0 < ((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ) := by positivity
  have h_step1 :
      C₀ * (s : ℝ) ^ 2 * (((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ)) ≤
        (K : ℝ) * (s : ℝ) ^ 2 * (((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ)) := by
    refine mul_le_mul_of_nonneg_right ?_ h_brack_pos.le
    exact mul_le_mul_of_nonneg_right hC0 (sq_nonneg _)
  have h_brack_le :
      ((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ) ≤
        2 * ((D : ℝ) + 1) * (s : ℝ) * ((k : ℝ) + 1) := by
    have hd_mul : ((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) ≤ ((D : ℝ) + 1) * (s : ℝ) :=
      mul_le_mul_of_nonneg_left h_logs1_le (by positivity)
    have h1 : ((D : ℝ) + 1) * (s : ℝ) ≤ ((D : ℝ) + 1) * (s : ℝ) * ((k : ℝ) + 1) :=
      le_mul_of_one_le_right (by positivity) (by linarith)
    have h2 : (k : ℝ) + 1 ≤ ((D : ℝ) + 1) * (s : ℝ) * ((k : ℝ) + 1) := by
      have hDs : (1 : ℝ) ≤ ((D : ℝ) + 1) * (s : ℝ) := by nlinarith
      exact le_mul_of_one_le_left (by positivity) hDs
    linarith
  have h_step2 :
      (K : ℝ) * (s : ℝ) ^ 2 * (((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ)) ≤
        (K : ℝ) * (s : ℝ) ^ 2 * (2 * ((D : ℝ) + 1) * (s : ℝ) * ((k : ℝ) + 1)) :=
    mul_le_mul_of_nonneg_left h_brack_le (by positivity)
  have hr_cast :
      (K : ℝ) * (s : ℝ) ^ 2 * (2 * ((D : ℝ) + 1) * (s : ℝ) * ((k : ℝ) + 1)) =
        (r : ℝ) * (s : ℝ) := by
    rw [hr_eq, rVal, ← hs_eq]
    push_cast
    ring
  exact h_step1.trans (h_step2.trans_eq hr_cast)

theorem vc71_rs_bound {K : ℕ} (hK : 1 ≤ K) {C₀ : ℝ} (hC0 : C₀ ≤ (K : ℝ))
    {D : ℕ} (hD : 1 ≤ D) {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2) :
    let k : ℕ := Nat.ceil (Real.logb 2 (1 / φ))
    let s : ℕ := sVal K D k
    let r : ℕ := rVal K D k
    C₀ * (s : ℝ) ^ 2 * (((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ)) ≤
      (r : ℝ) * (s : ℝ) := by
  obtain ⟨hk_pos, _, hlog_le_k, _⟩ := ceil_logb_bounds_aux hφ0 hφ1 rfl
  exact vc71_rs_bound_aux hK hC0 hD hφ0 hφ1 hk_pos hlog_le_k rfl rfl

/-! ### Elementary bit-length bounds -/

theorem natBitLength_pos (m : ℕ) : 1 ≤ natBitLength m := by
  unfold natBitLength
  omega

theorem natBitLength_le (m : ℕ) : natBitLength m ≤ m + 1 := by
  unfold natBitLength
  have := Nat.log_le_self 2 m
  omega

theorem natBitLength_mono {a b : ℕ} (h : a ≤ b) : natBitLength a ≤ natBitLength b := by
  unfold natBitLength
  have := Nat.log_mono_right (b := 2) h
  omega

theorem natBitLength_add_ten (t : ℕ) : natBitLength (t + 10) ≤ natBitLength t + 4 := by
  unfold natBitLength
  have hlt : t < 2 ^ (Nat.log 2 t + 1) := Nat.lt_pow_succ_log_self (by norm_num) t
  have hge1 : 1 ≤ 2 ^ Nat.log 2 t := Nat.one_le_pow _ 2 (by norm_num)
  have hbound : t + 10 < 2 ^ (Nat.log 2 t + 5) := by
    have hpow1 : 2 ^ (Nat.log 2 t + 1) = 2 * 2 ^ Nat.log 2 t := by ring
    have hpow5 : 2 ^ (Nat.log 2 t + 5) = 32 * 2 ^ Nat.log 2 t := by ring
    omega
  have hlog : Nat.log 2 (t + 10) < Nat.log 2 t + 5 :=
    (Nat.log_lt_iff_lt_pow (by norm_num) (by omega)).mpr hbound
  omega

theorem intBitLength_pos (z : ℤ) : 1 ≤ intBitLength z := by
  unfold intBitLength
  split_ifs <;> omega

theorem intBitLength_le_natAbs (z : ℤ) : intBitLength z ≤ z.natAbs + 2 := by
  unfold intBitLength
  split_ifs
  · omega
  · have := natBitLength_le z.natAbs
    omega

theorem intBitLength_mono_natAbs {a b : ℤ} (h : a.natAbs ≤ b.natAbs) :
    intBitLength a ≤ intBitLength b + 1 := by
  by_cases ha : a = 0
  · subst ha
    have := intBitLength_pos b
    have : intBitLength 0 = 1 := rfl
    omega
  · by_cases hb : b = 0
    · subst hb
      simp only [Int.natAbs_zero, Nat.le_zero, Int.natAbs_eq_zero] at h
      exact False.elim (ha h)
    · simp only [intBitLength, ha, hb, ↓reduceIte]
      have := natBitLength_mono h
      omega

theorem intBitLength_num_le_of_bdd {B : ℕ} {q : ℚ} (hq : RatCoordBitBounded B q) :
    intBitLength q.num ≤ B + 1 := by
  unfold intBitLength
  split_ifs
  · omega
  · have := hq.1
    omega

theorem intBitLength_den_le_of_bdd {B : ℕ} {q : ℚ} (hq : RatCoordBitBounded B q) :
    intBitLength (q.den : ℤ) ≤ B + 1 := by
  unfold intBitLength
  split_ifs with hz
  · omega
  · have h2 := hq.2
    simp only [Int.natAbs_natCast]
    omega

theorem intBitLength_den_sub_one_le_of_bdd {B : ℕ} {q : ℚ} (hq : RatCoordBitBounded B q) :
    intBitLength ((q.den : ℤ) - 1) ≤ B + 1 := by
  unfold intBitLength
  split_ifs with hz
  · omega
  · have hden_pos : 0 < q.den := q.pos
    have habs : ((q.den : ℤ) - 1).natAbs ≤ q.den := by omega
    have hm := natBitLength_mono habs
    have h2 := hq.2
    omega

theorem ratBitLength_le_of_bdd {B : ℕ} {q : ℚ} (hq : RatCoordBitBounded B q) :
    ratBitLength q ≤ 2 * B + 1 := by
  unfold ratBitLength
  have h1 := intBitLength_num_le_of_bdd hq
  have h2 := hq.2
  omega

end UL.Proof_lem_A_1
