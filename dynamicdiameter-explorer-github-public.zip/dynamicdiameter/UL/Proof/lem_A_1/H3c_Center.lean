import Mathlib
import UL.Def.def_computation_model
import UL.Def.def_A_convex_hull_cert
import UL.Proof.lem_A_1.H1_Params
import UL.Proof.lem_A_1.H2_GeomProb
import UL.Proof.lem_A_1.H3a_Sim
import UL.Proof.lem_A_1.H3b_Stage
set_option autoImplicit false

namespace UL.Proof_lem_A_1

/-! ### 1. Phase 3 output copy loop and `centerProg` -/

def outLoopWS (ws₂ : WordStore) (numAt denAt : ℕ → ℤ) : ℕ → WordStore
  | 0 => ws₂
  | n + 1 =>
      ((outLoopWS ws₂ numAt denAt n).write (.heap 1 (2 * (n : ℤ))) (numAt n)).write
        (.heap 1 (2 * (n : ℤ) + 1)) (denAt n)

theorem read_heap11_outLoopWS (ws₂ : WordStore) (numAt denAt : ℕ → ℤ) :
    ∀ (n : ℕ) (idx : ℤ),
      (outLoopWS ws₂ numAt denAt n).read (.heap 11 idx) = ws₂.read (.heap 11 idx)
  | 0, _ => rfl
  | n + 1, idx => by
      simp only [outLoopWS]
      rw [wordStore_read_write_of_ne _ (by simp),
        wordStore_read_write_of_ne _ (by simp)]
      exact read_heap11_outLoopWS ws₂ numAt denAt n idx

theorem read_heap1_outLoopWS (ws₂ : WordStore) (numAt denAt : ℕ → ℤ) :
    ∀ (n c : ℕ), c < n →
      (outLoopWS ws₂ numAt denAt n).read (.heap 1 (2 * (c : ℤ))) = numAt c ∧
      (outLoopWS ws₂ numAt denAt n).read (.heap 1 (2 * (c : ℤ) + 1)) = denAt c
  | 0, _, hc => by omega
  | n + 1, c, hc => by
      simp only [outLoopWS]
      by_cases heq : c = n
      · subst heq
        constructor
        · rw [wordStore_read_write_of_ne _ (by intro h; simp only [RAMCellLoc.heap.injEq] at h; omega),
            wordStore_read_write_self]
        · rw [wordStore_read_write_self]
      · have hlt : c < n := by omega
        obtain ⟨ihN, ihD⟩ := read_heap1_outLoopWS ws₂ numAt denAt n c hlt
        constructor
        · rw [wordStore_read_write_of_ne _ (by intro h; simp only [RAMCellLoc.heap.injEq] at h; omega),
            wordStore_read_write_of_ne _ (by intro h; simp only [RAMCellLoc.heap.injEq] at h; omega), ihN]
        · rw [wordStore_read_write_of_ne _ (by intro h; simp only [RAMCellLoc.heap.injEq] at h; omega),
            wordStore_read_write_of_ne _ (by intro h; simp only [RAMCellLoc.heap.injEq] at h; omega), ihD]

theorem cellCount_outLoopWS_le (ws₂ : WordStore) (numAt denAt : ℕ → ℤ) :
    ∀ n : ℕ, (outLoopWS ws₂ numAt denAt n).cellCount ≤ ws₂.cellCount + 2 * n
  | 0 => by simp [outLoopWS]
  | n + 1 => by
      simp only [outLoopWS]
      have ih := cellCount_outLoopWS_le ws₂ numAt denAt n
      have c1 := wordStore_cellCount_write_le (outLoopWS ws₂ numAt denAt n)
        (.heap 1 (2 * (n : ℤ))) (numAt n)
      have c2 := wordStore_cellCount_write_le
        ((outLoopWS ws₂ numAt denAt n).write (.heap 1 (2 * (n : ℤ))) (numAt n))
        (.heap 1 (2 * (n : ℤ) + 1)) (denAt n)
      omega

theorem bitSize_outLoopWS_le (ws₂ : WordStore) {numAt denAt : ℕ → ℤ} {W : ℕ} :
    ∀ n : ℕ, 2 * n + 1 ≤ W →
      (∀ c < n, intBitLength (numAt c) ≤ W + 5 ∧ intBitLength (denAt c) ≤ W + 5) →
      (outLoopWS ws₂ numAt denAt n).bitSize ≤ ws₂.bitSize + 6 * (W + 5) * n
  | 0, _, _ => by simp [outLoopWS]
  | n + 1, hnW, hbl => by
      simp only [outLoopWS]
      have ih := bitSize_outLoopWS_le ws₂ n (by omega) (fun c hc => hbl c (by omega))
      obtain ⟨hnum, hden⟩ := hbl n (by omega)
      have b1 := wordStore_bitSize_write_le (outLoopWS ws₂ numAt denAt n)
        (.heap 1 (2 * (n : ℤ))) (numAt n)
      have b2 := wordStore_bitSize_write_le
        ((outLoopWS ws₂ numAt denAt n).write (.heap 1 (2 * (n : ℤ))) (numAt n))
        (.heap 1 (2 * (n : ℤ) + 1)) (denAt n)
      have hb2n : intBitLength (2 * (n : ℤ)) ≤ W + 5 := by
        have h := intBitLength_le_natAbs (2 * (n : ℤ))
        have habs : (2 * (n : ℤ)).natAbs = 2 * n := by omega
        rw [habs] at h; omega
      have hb2n1 : intBitLength (2 * (n : ℤ) + 1) ≤ W + 5 := by
        have h := intBitLength_le_natAbs (2 * (n : ℤ) + 1)
        have habs : (2 * (n : ℤ) + 1).natAbs = 2 * n + 1 := by omega
        rw [habs] at h; omega
      have l1 : (RAMCellLoc.heap 1 (2 * (n : ℤ))).bitLength ≤ W + 6 := by
        simp only [RAMCellLoc.bitLength]
        have : natBitLength 1 = 1 := rfl
        omega
      have l2 : (RAMCellLoc.heap 1 (2 * (n : ℤ) + 1)).bitLength ≤ W + 6 := by
        simp only [RAMCellLoc.bitLength]
        have : natBitLength 1 = 1 := rfl
        omega
      have hmul : 6 * (W + 5) * (n + 1) = 6 * (W + 5) * n + 6 * (W + 5) := by ring
      rw [hmul]
      omega

def mkCopyBody (valNumE valDenE : IntExpr) : BitRAMStmt :=
  let cE : IntExpr := .readLocal 0 (.lit 0)
  let idxNumE : IntExpr := .mul (.lit 2) cE
  let idxDenE : IntExpr := .add (.mul (.lit 2) cE) (.lit 1)
  .seq (.writeHeap 1 idxNumE valNumE)
    (.seq (.writeHeap 1 idxDenE valDenE)
      (.writeLocal 0 (.lit 0) (.add cE (.lit 1))))

def copySuccessBody : BitRAMStmt :=
  let cE : IntExpr := .readLocal 0 (.lit 0)
  mkCopyBody (.readHeap 11 (.mul (.lit 2) cE))
    (.readHeap 11 (.add (.mul (.lit 2) cE) (.lit 1)))

def copyFallbackBody : BitRAMStmt :=
  mkCopyBody (.lit 0) (.lit 1)

def phase3Stmt : BitRAMStmt :=
  .ite (.intEq (.readHeap 10 (.lit 0)) (.lit 1))
    (.localScope (.seq (.writeLocal 0 (.lit 0) (.lit 0)) (.repeatN .dim copySuccessBody)))
    (.localScope (.seq (.writeLocal 0 (.lit 0) (.lit 0)) (.repeatN .dim copyFallbackBody)))

def centerProg (K : ℕ) (progHull : BitRAMStmt) : BitRAMStmt :=
  .seq (phase1Stmt K) (.seq (trStmt progHull) phase3Stmt)

private theorem mkCopyBody_runsTo {D W : ℕ} (inp : BitRAMInput D)
    (ws₂ : WordStore) (valNumE valDenE : IntExpr) (numAt denAt : ℕ → ℤ)
    (h2DW : 2 * D + 1 ≤ W)
    (hbl : ∀ c < D, intBitLength (numAt c) ≤ W + 5 ∧ intBitLength (denAt c) ≤ W + 5)
    (hevalNum : ∀ (c : ℕ) (_ : c < D) (ws : WordStore),
      ws.read (.localFrame 1 0 0) = (c : ℤ) →
      (∀ idx, ws.read (.heap 11 idx) = ws₂.read (.heap 11 idx)) →
      let (v, u, b) := evalIntExpr inp 1 ws valNumE
      v = numAt c ∧ u ≤ 10 ∧ b ≤ 10 * (W + 5))
    (hevalDen : ∀ (c : ℕ) (_ : c < D) (ws : WordStore),
      ws.read (.localFrame 1 0 0) = (c : ℤ) →
      (∀ idx, ws.read (.heap 11 idx) = ws₂.read (.heap 11 idx)) →
      let (v, u, b) := evalIntExpr inp 1 ws valDenE
      v = denAt c ∧ u ≤ 10 ∧ b ≤ 10 * (W + 5)) :
    ∀ (rem c : ℕ), c + rem = D →
      ∀ (st : BitRAMExecState),
        st.frameDepth = 1 →
        st.remainingBits = [] →
        st.words = (outLoopWS ws₂ numAt denAt c).write (.localFrame 1 0 0) (c : ℤ) →
        ∃ stEnd : BitRAMExecState,
          RunsTo inp [.repeatLoop rem (mkCopyBody valNumE valDenE)] st stEnd ∧
          stEnd.frameDepth = 1 ∧
          stEnd.remainingBits = [] ∧
          stEnd.words = (outLoopWS ws₂ numAt denAt D).write (.localFrame 1 0 0) (D : ℤ) ∧
          stEnd.unitCost ≤ st.unitCost + 40 * rem ∧
          stEnd.bitCost ≤ st.bitCost + 40 * (W + 5) * rem ∧
          stEnd.peakCellSpace ≤ max st.peakCellSpace (inp.inputCellSpace + ws₂.cellCount + 2 * D + 2) ∧
          stEnd.peakBitSpace ≤ max st.peakBitSpace (inp.inputBitSpace + ws₂.bitSize + 8 * (W + 5) ^ 2)
  | 0, c, hsum, st, hfd, hbits, hws => by
      have hcD : c = D := by omega
      subst hcD
      exact ⟨st, RunsTo.repeatLoop_zero _ st, hfd, hbits, hws,
        by omega, by omega, le_max_left _ _, le_max_left _ _⟩
  | rem + 1, c, hsum, st, hfd, hbits, hws => by
      have hc : c < D := by omega
      obtain ⟨hnum_bl, hden_bl⟩ := hbl c hc
      have hbc : intBitLength (c : ℤ) ≤ W + 5 := by
        have := intBitLength_le_natAbs (c : ℤ); simp only [Int.natAbs_natCast] at this; omega
      have hbc1 : intBitLength ((c + 1 : ℕ) : ℤ) ≤ W + 5 := by
        have := intBitLength_le_natAbs ((c + 1 : ℕ) : ℤ); simp only [Int.natAbs_natCast] at this; omega
      have hb2c : intBitLength (2 * (c : ℤ)) ≤ W + 5 := by
        have h := intBitLength_le_natAbs (2 * (c : ℤ))
        have habs : (2 * (c : ℤ)).natAbs = 2 * c := by omega
        rw [habs] at h; omega
      have hb2c1 : intBitLength (2 * (c : ℤ) + 1) ≤ W + 5 := by
        have h := intBitLength_le_natAbs (2 * (c : ℤ) + 1)
        have habs : (2 * (c : ℤ) + 1).natAbs = 2 * c + 1 := by omega
        rw [habs] at h; omega
      have he_2c : ∀ ws : WordStore,
          evalIntExpr inp 1 (ws.write (.localFrame 1 0 0) (c : ℤ)) (.mul (.lit 2) (.readLocal 0 (.lit 0))) =
            (2 * (c : ℤ), 4, 3 + (3 + intBitLength (c : ℤ)) + 3 * intBitLength (c : ℤ)) := by
        intro ws
        simp only [evalIntExpr, wordStore_read_write_self]
        have h0 : intBitLength 0 = 1 := rfl
        have hn0 : natBitLength 0 = 1 := rfl
        have h2 : intBitLength 2 = 3 := by decide
        rw [h0, hn0, h2]
      have he_2c1 : ∀ ws : WordStore,
          evalIntExpr inp 1 (ws.write (.localFrame 1 0 0) (c : ℤ))
            (.add (.mul (.lit 2) (.readLocal 0 (.lit 0))) (.lit 1)) =
            (2 * (c : ℤ) + 1, 6,
              (3 + (3 + intBitLength (c : ℤ)) + 3 * intBitLength (c : ℤ)) + 2 +
              intBitLength (2 * (c : ℤ)) + 2) := by
        intro ws
        simp only [evalIntExpr, wordStore_read_write_self]
        have h0 : intBitLength 0 = 1 := rfl
        have hn0 : natBitLength 0 = 1 := rfl
        have h2 : intBitLength 2 = 3 := by decide
        have h1 : intBitLength 1 = 2 := by decide
        rw [h0, hn0, h2, h1]
      -- Step 1: writeHeap 1 (2*c) valNumE
      let ws0 := outLoopWS ws₂ numAt denAt c
      have hs1 := RunsTo.writeHeap inp 1 (.mul (.lit 2) (.readLocal 0 (.lit 0))) valNumE st
      have hi1 : evalIntExpr inp st.frameDepth st.words (.mul (.lit 2) (.readLocal 0 (.lit 0))) =
          (2 * (c : ℤ), 4, 3 + (3 + intBitLength (c : ℤ)) + 3 * intBitLength (c : ℤ)) := by
        rw [hfd, hws]; exact he_2c ws0
      have hv1_prop := hevalNum c hc st.words
        (by rw [hws, wordStore_read_write_self])
        (fun idx => by rw [hws, wordStore_read_write_of_ne _ (by simp), read_heap11_outLoopWS])
      rcases eqv1 : evalIntExpr inp 1 st.words valNumE with ⟨v1, u1, b1⟩
      simp only [eqv1] at hv1_prop
      rcases hv1_prop with ⟨rfl, hu1, hb1⟩
      have eqv1' : evalIntExpr inp st.frameDepth st.words valNumE = (numAt c, u1, b1) := by
        rwa [hfd]
      dsimp only at hs1
      rw [hi1, eqv1'] at hs1
      dsimp only at hs1
      set st1 : BitRAMExecState :=
        { st with
          words := st.words.write (.heap 1 (2 * (c : ℤ))) (numAt c)
          unitCost := st.unitCost + 4 + u1 + 1
          bitCost := st.bitCost + (3 + (3 + intBitLength (c : ℤ)) + 3 * intBitLength (c : ℤ)) +
            b1 + (RAMCellLoc.heap 1 (2 * (c : ℤ))).bitLength + intBitLength (numAt c)
          peakCellSpace := max st.peakCellSpace
            (inp.inputCellSpace + (st.words.write (.heap 1 (2 * (c : ℤ))) (numAt c)).cellCount)
          peakBitSpace := max st.peakBitSpace
            (inp.inputBitSpace + (st.words.write (.heap 1 (2 * (c : ℤ))) (numAt c)).bitSize) }
      have hws1 : st1.words = (ws0.write (.heap 1 (2 * (c : ℤ))) (numAt c)).write (.localFrame 1 0 0) (c : ℤ) := by
        dsimp [st1]; rw [hws, wordStore_write_comm _ (by simp)]
      -- Step 2: writeHeap 1 (2*c + 1) valDenE
      have hs2 := RunsTo.writeHeap inp 1 (.add (.mul (.lit 2) (.readLocal 0 (.lit 0))) (.lit 1)) valDenE st1
      have hi2 : evalIntExpr inp st1.frameDepth st1.words
          (.add (.mul (.lit 2) (.readLocal 0 (.lit 0))) (.lit 1)) =
          (2 * (c : ℤ) + 1, 6,
            (3 + (3 + intBitLength (c : ℤ)) + 3 * intBitLength (c : ℤ)) + 2 +
              intBitLength (2 * (c : ℤ)) + 2) := by
        change evalIntExpr inp st.frameDepth st1.words _ = _
        rw [hfd, hws1]; exact he_2c1 _
      have hv2_prop := hevalDen c hc st1.words
        (by rw [hws1, wordStore_read_write_self])
        (fun idx => by
          rw [hws1, wordStore_read_write_of_ne _ (by simp),
            wordStore_read_write_of_ne _ (by simp), read_heap11_outLoopWS])
      rcases eqv2 : evalIntExpr inp 1 st1.words valDenE with ⟨v2, u2, b2⟩
      simp only [eqv2] at hv2_prop
      rcases hv2_prop with ⟨rfl, hu2, hb2⟩
      have eqv2' : evalIntExpr inp st1.frameDepth st1.words valDenE = (denAt c, u2, b2) := by
        change evalIntExpr inp st.frameDepth st1.words valDenE = _
        rwa [hfd]
      dsimp only at hs2
      rw [hi2, eqv2'] at hs2
      dsimp only at hs2
      set st2 : BitRAMExecState :=
        { st1 with
          words := st1.words.write (.heap 1 (2 * (c : ℤ) + 1)) (denAt c)
          unitCost := st1.unitCost + 6 + u2 + 1
          bitCost := st1.bitCost +
            ((3 + (3 + intBitLength (c : ℤ)) + 3 * intBitLength (c : ℤ)) + 2 +
              intBitLength (2 * (c : ℤ)) + 2) +
            b2 + (RAMCellLoc.heap 1 (2 * (c : ℤ) + 1)).bitLength + intBitLength (denAt c)
          peakCellSpace := max st1.peakCellSpace
            (inp.inputCellSpace + (st1.words.write (.heap 1 (2 * (c : ℤ) + 1)) (denAt c)).cellCount)
          peakBitSpace := max st1.peakBitSpace
            (inp.inputBitSpace + (st1.words.write (.heap 1 (2 * (c : ℤ) + 1)) (denAt c)).bitSize) }
      have hws2 : st2.words = (outLoopWS ws₂ numAt denAt (c + 1)).write (.localFrame 1 0 0) (c : ℤ) := by
        dsimp [st2, outLoopWS, ws0]
        rw [hws1, wordStore_write_comm _ (by simp)]
      -- Step 3: writeLocal 0 (.lit 0) (.add cE (.lit 1))
      have hs3 := RunsTo.writeLocal inp 0 (.lit 0) (.add (.readLocal 0 (.lit 0)) (.lit 1)) st2
      have he_0 : evalIntExpr inp st2.frameDepth st2.words (.lit 0) = (0, 1, 1) := rfl
      have he_inc : evalIntExpr inp st2.frameDepth st2.words (.add (.readLocal 0 (.lit 0)) (.lit 1)) =
          (((c + 1 : ℕ) : ℤ), 4, (3 + intBitLength (c : ℤ)) + 2 + intBitLength (c : ℤ) + 2) := by
        change evalIntExpr inp st.frameDepth st2.words _ = _
        rw [hfd, hws2]
        simp only [evalIntExpr, wordStore_read_write_self]
        have h0 : intBitLength 0 = 1 := rfl
        have hn0 : natBitLength 0 = 1 := rfl
        have h1 : intBitLength 1 = 2 := by decide
        rw [h0, hn0, h1]
        push_cast
        rfl
      dsimp only at hs3
      rw [he_0, he_inc] at hs3
      dsimp only at hs3
      have hstep := RunsTo.seq hs1 (RunsTo.seq hs2 hs3)
      set st3 : BitRAMExecState :=
        { st2 with
          words := st2.words.write (.localFrame st2.frameDepth 0 0) ((c + 1 : ℕ) : ℤ)
          unitCost := st2.unitCost + 1 + 4 + 1
          bitCost := st2.bitCost + 1 + ((3 + intBitLength (c : ℤ)) + 2 + intBitLength (c : ℤ) + 2) +
            (RAMCellLoc.localFrame st2.frameDepth 0 0).bitLength + intBitLength ((c + 1 : ℕ) : ℤ)
          peakCellSpace := max st2.peakCellSpace
            (inp.inputCellSpace + (st2.words.write (.localFrame st2.frameDepth 0 0) ((c + 1 : ℕ) : ℤ)).cellCount)
          peakBitSpace := max st2.peakBitSpace
            (inp.inputBitSpace + (st2.words.write (.localFrame st2.frameDepth 0 0) ((c + 1 : ℕ) : ℤ)).bitSize) }
      have hfd3 : st3.frameDepth = 1 := hfd
      have hws3 : st3.words = (outLoopWS ws₂ numAt denAt (c + 1)).write (.localFrame 1 0 0) ((c + 1 : ℕ) : ℤ) := by
        dsimp [st3]
        have hfd2 : st2.frameDepth = 1 := hfd
        rw [hfd2, hws2, wordStore_write_overwrite]
      obtain ⟨stEnd, hrem, hfdE, hbitsE, hwsE, huE, hbE, hpcE, hpbE⟩ :=
        mkCopyBody_runsTo inp ws₂ valNumE valDenE numAt denAt h2DW hbl hevalNum hevalDen
          rem (c + 1) (by omega) st3 hfd3 hbits hws3
      have hl1 : (RAMCellLoc.heap 1 (2 * (c : ℤ))).bitLength ≤ W + 6 := by
        simp only [RAMCellLoc.bitLength]; have : natBitLength 1 = 1 := rfl; omega
      have hl2 : (RAMCellLoc.heap 1 (2 * (c : ℤ) + 1)).bitLength ≤ W + 6 := by
        simp only [RAMCellLoc.bitLength]; have : natBitLength 1 = 1 := rfl; omega
      have hll1 : (RAMCellLoc.localFrame 1 0 0).bitLength = 3 := rfl
      have hll : (RAMCellLoc.localFrame st2.frameDepth 0 0).bitLength = 3 := by
        change (RAMCellLoc.localFrame st.frameDepth 0 0).bitLength = 3
        rw [hfd]; rfl
      refine ⟨stEnd, RunsTo.repeatLoop_succ hstep hrem, hfdE, hbitsE, hwsE, ?_, ?_, ?_, ?_⟩
      · dsimp only [st3, st2, st1] at huE; omega
      · dsimp only [st3, st2, st1] at hbE
        rw [hll] at hbE
        have hmul : 40 * (W + 5) * (rem + 1) = 40 * (W + 5) * rem + 40 * (W + 5) := by ring
        rw [hmul]; omega
      · have hc0 := cellCount_outLoopWS_le ws₂ numAt denAt c
        have hc01 := cellCount_outLoopWS_le ws₂ numAt denAt (c + 1)
        have a1 : st1.words.cellCount ≤ ws₂.cellCount + 2 * D + 2 := by
          rw [hws1]
          have p1 := wordStore_cellCount_write_le (ws0.write (.heap 1 (2 * (c : ℤ))) (numAt c)) (.localFrame 1 0 0) (c : ℤ)
          have p2 := wordStore_cellCount_write_le ws0 (.heap 1 (2 * (c : ℤ))) (numAt c)
          dsimp only [ws0] at p1 p2 ⊢; omega
        have a2 : st2.words.cellCount ≤ ws₂.cellCount + 2 * D + 2 := by
          rw [hws2]
          have p1 := wordStore_cellCount_write_le (outLoopWS ws₂ numAt denAt (c + 1)) (.localFrame 1 0 0) (c : ℤ)
          omega
        have a3 : st3.words.cellCount ≤ ws₂.cellCount + 2 * D + 2 := by
          rw [hws3]
          have p1 := wordStore_cellCount_write_le (outLoopWS ws₂ numAt denAt (c + 1)) (.localFrame 1 0 0) ((c + 1 : ℕ) : ℤ)
          omega
        dsimp only [st3, st2, st1] at a1 a2 a3 hpcE
        omega
      · have hsq_bound : 6 * (W + 5) * (c + 1) + 4 * (W + 5) ≤ 8 * (W + 5) ^ 2 := by
          have hc1_le : c + 1 ≤ W + 5 := by omega
          have hm1 : 6 * (W + 5) * (c + 1) ≤ 6 * (W + 5) * (W + 5) :=
            Nat.mul_le_mul_left _ hc1_le
          have hm2 : 4 * (W + 5) ≤ 2 * ((W + 5) * (W + 5)) := by
            have h4 : 4 * (W + 5) ≤ (W + 5) * (W + 5) := Nat.mul_le_mul_right (W + 5) (by omega)
            omega
          have hr : 6 * (W + 5) * (W + 5) + 2 * ((W + 5) * (W + 5)) = 8 * (W + 5) ^ 2 := by ring
          omega
        have hb0 := bitSize_outLoopWS_le ws₂ (W := W) c (by omega) (fun i hi => hbl i (by omega))
        have hb01 := bitSize_outLoopWS_le ws₂ (W := W) (c + 1) (by omega) (fun i hi => hbl i (by omega))
        have b1_le : st1.words.bitSize ≤ ws₂.bitSize + 8 * (W + 5) ^ 2 := by
          rw [hws1]
          have p1 := wordStore_bitSize_write_le (ws0.write (.heap 1 (2 * (c : ℤ))) (numAt c)) (.localFrame 1 0 0) (c : ℤ)
          have p2 := wordStore_bitSize_write_le ws0 (.heap 1 (2 * (c : ℤ))) (numAt c)
          dsimp only [ws0] at p1 p2 ⊢
          rw [hll1] at p1
          have hm : 6 * (W + 5) * c ≤ 6 * (W + 5) * (c + 1) := Nat.mul_le_mul_left _ (by omega)
          omega
        have b2_le : st2.words.bitSize ≤ ws₂.bitSize + 8 * (W + 5) ^ 2 := by
          rw [hws2]
          have p1 := wordStore_bitSize_write_le (outLoopWS ws₂ numAt denAt (c + 1)) (.localFrame 1 0 0) (c : ℤ)
          rw [hll1] at p1; omega
        have b3_le : st3.words.bitSize ≤ ws₂.bitSize + 8 * (W + 5) ^ 2 := by
          rw [hws3]
          have p1 := wordStore_bitSize_write_le (outLoopWS ws₂ numAt denAt (c + 1)) (.localFrame 1 0 0) ((c + 1 : ℕ) : ℤ)
          rw [hll1] at p1; omega
        dsimp only [st3, st2, st1] at b1_le b2_le b3_le hpbE
        omega

private theorem phase3_branch_runsTo {D W : ℕ} (inp : BitRAMInput D)
    (stPre : BitRAMExecState) (valNumE valDenE : IntExpr) (numAt denAt : ℕ → ℤ)
    (hfdPre : stPre.frameDepth = 0) (hbitsPre : stPre.remainingBits = [])
    (h2DW : 2 * D + 1 ≤ W)
    (hbl : ∀ c < D, intBitLength (numAt c) ≤ W + 5 ∧ intBitLength (denAt c) ≤ W + 5)
    (hevalNum : ∀ (c : ℕ) (_ : c < D) (ws : WordStore),
      ws.read (.localFrame 1 0 0) = (c : ℤ) →
      (∀ idx, ws.read (.heap 11 idx) = (stPre.words.popDepth 0).read (.heap 11 idx)) →
      let (v, u, b) := evalIntExpr inp 1 ws valNumE
      v = numAt c ∧ u ≤ 10 ∧ b ≤ 10 * (W + 5))
    (hevalDen : ∀ (c : ℕ) (_ : c < D) (ws : WordStore),
      ws.read (.localFrame 1 0 0) = (c : ℤ) →
      (∀ idx, ws.read (.heap 11 idx) = (stPre.words.popDepth 0).read (.heap 11 idx)) →
      let (v, u, b) := evalIntExpr inp 1 ws valDenE
      v = denAt c ∧ u ≤ 10 ∧ b ≤ 10 * (W + 5)) :
    ∃ stEnd : BitRAMExecState,
      RunsTo inp [.stmt (.localScope (.seq (.writeLocal 0 (.lit 0) (.lit 0))
        (.repeatN .dim (mkCopyBody valNumE valDenE))))] stPre stEnd ∧
      stEnd.remainingBits = [] ∧
      (∀ c : Fin D,
        (stEnd.words.popDepth 0).read (.heap 1 (2 * (c.val : ℤ))) = numAt c.val ∧
        (stEnd.words.popDepth 0).read (.heap 1 (2 * (c.val : ℤ) + 1)) = denAt c.val) ∧
      stEnd.unitCost ≤ stPre.unitCost + 50 * (W + 5) ∧
      stEnd.bitCost ≤ stPre.bitCost + 50 * (W + 5) ^ 2 ∧
      stEnd.peakCellSpace ≤ max stPre.peakCellSpace (inp.inputCellSpace + stPre.words.cellCount + 2 * D + 2) ∧
      stEnd.peakBitSpace ≤ max stPre.peakBitSpace (inp.inputBitSpace + stPre.words.bitSize + 9 * (W + 5) ^ 2) := by
  let ws₂ := stPre.words.popDepth 0
  let stSc0 : BitRAMExecState :=
    { stPre with words := stPre.words.popDepth stPre.frameDepth, frameDepth := stPre.frameDepth + 1 }
  have hSc_fd : stSc0.frameDepth = 1 := by dsimp [stSc0]; omega
  have hSc_ws : stSc0.words = ws₂ := by dsimp [stSc0, ws₂]; rw [hfdPre]
  have hw0 := RunsTo.writeLocal inp 0 (.lit 0) (.lit 0) stSc0
  have he0 : ∀ fd ws, evalIntExpr inp fd ws (.lit 0) = (0, 1, 1) := fun _ _ => rfl
  dsimp only at hw0
  rw [he0] at hw0
  dsimp only at hw0
  set stL0 : BitRAMExecState :=
    { stSc0 with
      words := stSc0.words.write (.localFrame stSc0.frameDepth 0 0) 0
      unitCost := stPre.unitCost + 1 + 1 + 1
      bitCost := stPre.bitCost + 1 + 1 + (RAMCellLoc.localFrame stSc0.frameDepth 0 0).bitLength + 1
      peakCellSpace := max stPre.peakCellSpace
        (inp.inputCellSpace + (stSc0.words.write (.localFrame stSc0.frameDepth 0 0) 0).cellCount)
      peakBitSpace := max stPre.peakBitSpace
        (inp.inputBitSpace + (stSc0.words.write (.localFrame stSc0.frameDepth 0 0) 0).bitSize) }
  have hL0_ws : stL0.words = (outLoopWS ws₂ numAt denAt 0).write (.localFrame 1 0 0) 0 := by
    dsimp [stL0, outLoopWS]; rw [hSc_fd, hSc_ws]
  let stLS : BitRAMExecState :=
    { stL0 with
      unitCost := stL0.unitCost + 1
      bitCost := stL0.bitCost + intBitLength (D : ℤ) }
  obtain ⟨stLE, hloop, _, hbitsE, hwsE, huE, hbE, hpcE, hpbE⟩ :=
    mkCopyBody_runsTo inp ws₂ valNumE valDenE numAt denAt h2DW hbl hevalNum hevalDen
      D 0 (Nat.zero_add D) stLS hSc_fd hbitsPre hL0_ws
  have hrep : RunsTo inp [.stmt (.repeatN .dim (mkCopyBody valNumE valDenE))] stL0 stLE := by
    refine RunsTo.repeatN _ _ ?_
    dsimp only [evalIntExpr]
    have hD_nn : (0 : ℤ) ≤ (D : ℤ) := Nat.cast_nonneg D
    simp only [hD_nn, ↓reduceIte, Int.toNat_natCast]
    exact hloop
  have hsc := RunsTo.localScope (RunsTo.seq hw0 hrep)
  refine ⟨_, hsc, hbitsE, ?_, ?_, ?_, ?_, ?_⟩
  · intro c
    dsimp only
    rw [wordStore_popDepth_read_heap, wordStore_popDepth_read_heap,
      wordStore_popDepth_read_heap, wordStore_popDepth_read_heap, hwsE,
      wordStore_read_write_of_ne _ (by simp),
      wordStore_read_write_of_ne _ (by simp)]
    exact read_heap1_outLoopWS ws₂ numAt denAt D c.val c.isLt
  · dsimp only [stLS, stL0, stSc0] at huE ⊢
    omega
  · dsimp only [stLS, stL0] at hbE ⊢
    have hll : (RAMCellLoc.localFrame stSc0.frameDepth 0 0).bitLength = 3 := by
      rw [hSc_fd]; rfl
    have hbD : intBitLength (D : ℤ) ≤ W + 5 := by
      have := intBitLength_le_natAbs (D : ℤ); simp only [Int.natAbs_natCast] at this; omega
    have hmul : 40 * (W + 5) * D ≤ 40 * (W + 5) ^ 2 := by
      calc
        40 * (W + 5) * D ≤ 40 * (W + 5) * (W + 5) := Nat.mul_le_mul_left _ (by omega)
        _ = 40 * (W + 5) ^ 2 := by ring
    have hlin : W + 5 ≤ (W + 5) ^ 2 := Nat.le_self_pow (by omega) _
    rw [hll] at hbE
    omega
  · dsimp only [stLS, stL0] at hpcE ⊢
    have hc_pop : ws₂.cellCount ≤ stPre.words.cellCount := cellCount_popDepth_le _ 0
    have hc_0 : (stSc0.words.write (.localFrame stSc0.frameDepth 0 0) 0).cellCount ≤
        stPre.words.cellCount + 1 := by
      rw [hSc_ws]
      have := wordStore_cellCount_write_le ws₂ (.localFrame stSc0.frameDepth 0 0) 0
      omega
    omega
  · dsimp only [stLS, stL0] at hpbE ⊢
    have hb_pop : ws₂.bitSize ≤ stPre.words.bitSize := bitSize_popDepth_le _ 0
    have hll : (RAMCellLoc.localFrame stSc0.frameDepth 0 0).bitLength = 3 := by
      rw [hSc_fd]; rfl
    have hb_0 : (stSc0.words.write (.localFrame stSc0.frameDepth 0 0) 0).bitSize ≤
        stPre.words.bitSize + 5 := by
      rw [hSc_ws]
      have a := wordStore_bitSize_write_le ws₂ (.localFrame stSc0.frameDepth 0 0) 0
      have b0 : intBitLength 0 = 1 := rfl
      rw [hll, b0] at a
      omega
    have hlin : 5 ≤ (W + 5) ^ 2 := by
      have : W + 5 ≤ (W + 5) ^ 2 := Nat.le_self_pow (by omega) _
      omega
    omega

/-! ### 2. Input space bounds and combined `centerProg_spec` -/

theorem sampleInp_space_bounds {D B k M W : ℕ} (hD : 1 ≤ D)
    (hkW : k ≤ W) (hMW : M * D + B + 10 ≤ W)
    {ι : Type*} (P : ι → Fin D → ℚ) (hP : ∀ i, RatPointBitBounded B (P i))
    (ω : Fin M → ι) (inp : BitRAMInput D)
    (hIntP : inp.intParams = [(B : ℤ), (k : ℤ), (M : ℤ)])
    (hActH : inp.activeHandles = Finset.range M)
    (hActC : inp.activeRatCoords = fun j => if hj : j < M then P (ω ⟨j, hj⟩) else fun _ => 0)
    (hExt : inp.extraRats = []) :
    inp.inputCellSpace ≤ 3 * (W + 5) ∧
    inp.inputBitSpace ≤ 5 * (W + 5) ^ 2 := by
  have hMD : M ≤ M * D := Nat.le_mul_of_pos_right M hD
  have hMW' : M ≤ W := by omega
  constructor
  · unfold BitRAMInput.inputCellSpace
    rw [hIntP, hActH, hExt, Finset.card_range]
    simp only [List.length_cons, List.length_nil]
    have hmul : M * (2 * D + 1) = 2 * (M * D) + M := by ring
    rw [hmul]
    omega
  · unfold BitRAMInput.inputBitSpace
    rw [hIntP, hActH, hExt]
    simp only [List.map, List.sum_cons, List.sum_nil]
    have hbB := intBitLength_le_natAbs (B : ℤ)
    have hbk := intBitLength_le_natAbs (k : ℤ)
    have hbM := intBitLength_le_natAbs (M : ℤ)
    simp only [Int.natAbs_natCast] at hbB hbk hbM
    have hsum_act :
        (∑ h ∈ Finset.range M, (natBitLength h + ∑ c : Fin D, ratBitLength (inp.activeRatCoords h c))) ≤
          M * ((W + 5) + D * (2 * B + 1)) := by
      calc
        ∑ h ∈ Finset.range M, (natBitLength h + ∑ c : Fin D, ratBitLength (inp.activeRatCoords h c))
            ≤ ∑ _h ∈ Finset.range M, ((W + 5) + D * (2 * B + 1)) := by
              refine Finset.sum_le_sum fun h hh => ?_
              have hlt : h < M := Finset.mem_range.mp hh
              have hnh : natBitLength h ≤ W + 5 := by
                have := natBitLength_le h; omega
              have hcs : ∑ c : Fin D, ratBitLength (inp.activeRatCoords h c) ≤ D * (2 * B + 1) := by
                calc
                  ∑ c : Fin D, ratBitLength (inp.activeRatCoords h c)
                      ≤ ∑ _c : Fin D, (2 * B + 1) := by
                        refine Finset.sum_le_sum fun c _ => ?_
                        rw [hActC]
                        simp only [hlt, ↓reduceDIte]
                        exact ratBitLength_le_of_bdd (hP _ c)
                  _ = D * (2 * B + 1) := by simp
              omega
        _ = M * ((W + 5) + D * (2 * B + 1)) := by simp
    have hquad : M * ((W + 5) + D * (2 * B + 1)) ≤ 3 * (W + 5) ^ 2 := by
      have h1 : M * (W + 5) ≤ (W + 5) * (W + 5) := Nat.mul_le_mul_right _ (by omega)
      have h2 : M * (D * (2 * B + 1)) = (M * D) * (2 * B + 1) := by ring
      have h3 : (M * D) * (2 * B + 1) ≤ (W + 5) * (2 * (W + 5)) :=
        Nat.mul_le_mul (by omega) (by omega)
      have hr : (W + 5) * (W + 5) + (W + 5) * (2 * (W + 5)) = 3 * (W + 5) ^ 2 := by ring
      have hdistr : M * ((W + 5) + D * (2 * B + 1)) = M * (W + 5) + M * (D * (2 * B + 1)) := by ring
      omega
    have hlin : W + 5 ≤ (W + 5) ^ 2 := Nat.le_self_pow (by omega) _
    omega

theorem centerProg_spec {K D B k : ℕ} (hK : 1 ≤ K) (hD : 1 ≤ D) (hB : 1 ≤ B)
    {s r M boundLP W : ℕ}
    (hs_eq : s = sVal K D k) (hr_eq : r = rVal K D k) (hM_eq : M = mVal K D k)
    (hW_ge : M * D + B + boundLP + 2 * D + 10 ≤ W)
    {ι : Type*} (P : ι → Fin D → ℚ) (hP : ∀ i, RatPointBitBounded B (P i))
    (ω : Fin M → ι) (inp : BitRAMInput D)
    (hIntP : inp.intParams = [(B : ℤ), (k : ℤ), (M : ℤ)])
    (hActH : inp.activeHandles = Finset.range M)
    (hActC : inp.activeRatCoords = fun j => if hj : j < M then P (ω ⟨j, hj⟩) else fun _ => 0)
    (hExt : inp.extraRats = [])
    (progHull : BitRAMStmt) (outHull : BitRAMExecOutcome)
    (hrsM : r * s = M)
    (hHullRun :
      let ω' : Fin (r * s) → ι := fun t => ω ⟨t.val, hrsM ▸ t.isLt⟩
      let pts : Fin r → Fin s → Fin D → ℚ := fun i j => P (ω' (blockIdx i j))
      let flatPts : List ℚ :=
        (List.finRange r).flatMap (fun i =>
          (List.finRange s).flatMap (fun j => List.ofFn (pts i j)))
      let inpHull : BitRAMInput 0 :=
        { intParams := [(D : ℤ), (r : ℤ), (s : ℤ)]
          activeHandles := ∅
          activeRatCoords := fun _ c => Fin.elim0 c
          extraRats := flatPts }
      runBitRAMWithBits progHull inpHull WordStore.empty [] = some outHull)
    (huH : outHull.unitCost ≤ boundLP)
    (hbH : outHull.bitCost ≤ boundLP)
    (hpcH : outHull.peakCellSpace ≤ boundLP)
    (hpbH : outHull.peakBitSpace ≤ boundLP)
    (hflag01 : outHull.words.read (.heap 0 0) = 0 ∨ outHull.words.read (.heap 0 0) = 1)
    (hflag_iff :
      let ω' : Fin (r * s) → ι := fun t => ω ⟨t.val, hrsM ▸ t.isLt⟩
      let pts : Fin r → Fin s → Fin D → ℚ := fun i j => P (ω' (blockIdx i j))
      outHull.words.read (.heap 0 0) = 1 ↔
        ∃ z : EuclideanSpace ℝ (Fin D),
          ∀ i : Fin r, HasConvexHullCert (fun j : Fin s => ratPointToEuclidean (pts i j)) z)
    (hflag_sol :
      let ω' : Fin (r * s) → ι := fun t => ω ⟨t.val, hrsM ▸ t.isLt⟩
      let pts : Fin r → Fin s → Fin D → ℚ := fun i j => P (ω' (blockIdx i j))
      outHull.words.read (.heap 0 0) = 1 →
        let zNum : Fin D → ℤ := fun c => outHull.words.read (.heap 1 (2 * (c.val : ℤ)))
        let zDen : Fin D → ℤ := fun c => outHull.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
        let zRat : Fin D → ℚ := fun c => (zNum c : ℚ) / (zDen c : ℚ)
        (∀ c : Fin D,
          0 < zDen c ∧
          intBitLength (zNum c) ≤ boundLP ∧
          intBitLength (zDen c) ≤ boundLP ∧
          ratBitLength (zRat c) ≤ boundLP) ∧
        (∀ i : Fin r,
          HasConvexHullCert (fun j : Fin s => ratPointToEuclidean (pts i j))
            (ratPointToEuclidean zRat))) :
    ∃ (out : BitRAMExecOutcome) (zRat : Fin D → ℚ),
      runBitRAMWithBits (centerProg K progHull) inp WordStore.empty [] = some out ∧
      out.unitCost ≤ 1000 * (W + 5) ^ 3 ∧
      out.bitCost ≤ 1000 * (W + 5) ^ 3 ∧
      out.peakCellSpace ≤ 1000 * (W + 5) ^ 3 ∧
      out.peakBitSpace ≤ 1000 * (W + 5) ^ 3 ∧
      (∀ c : Fin D,
        let zNum := out.words.read (.heap 1 (2 * (c.val : ℤ)))
        let zDen := out.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
        0 < zDen ∧
        zRat c = (zNum : ℚ) / (zDen : ℚ) ∧
        intBitLength zNum ≤ 1000 * (W + 5) ^ 3 ∧
        intBitLength zDen ≤ 1000 * (W + 5) ^ 3 ∧
        ratBitLength (zRat c) ≤ 1000 * (W + 5) ^ 3) ∧
      (∑ c : Fin D, ratBitLength (zRat c)) ≤ 1000 * (W + 5) ^ 3 ∧
      ((∃ z : EuclideanSpace ℝ (Fin D),
          ∀ i : Fin r,
            HasConvexHullCert
              (fun j : Fin s =>
                ratPointToEuclidean (P (ω ⟨(blockIdx i j).val, hrsM ▸ (blockIdx i j).isLt⟩))) z) →
        ∀ i : Fin r,
          HasConvexHullCert
            (fun j : Fin s =>
              ratPointToEuclidean (P (ω ⟨(blockIdx i j).val, hrsM ▸ (blockIdx i j).isLt⟩)))
            (ratPointToEuclidean zRat)) := by
  have hs_pos : 1 ≤ s := hs_eq ▸ sVal_pos hK
  have hsub := subterms_le_mVal (D := D) (k := k) hK
  dsimp only at hsub
  rw [← hM_eq, ← hr_eq, ← hs_eq] at hsub
  have hkM : k ≤ M := hsub.2.2.1
  have hMD : M ≤ M * D := Nat.le_mul_of_pos_right M hD
  have hkW : k ≤ W := by omega
  obtain ⟨hicW, hibW⟩ :=
    sampleInp_space_bounds hD hkW (by omega) P hP ω inp hIntP hActH hActC hExt
  let qAt : ℕ → ℚ := fun t =>
    if ht : t < M * D then
      P (ω ⟨t / D, (Nat.div_lt_iff_lt_mul hD).mpr ht⟩) ⟨t % D, Nat.mod_lt t hD⟩
    else 0
  have hqAt : ∀ t (ht : t < M * D),
      qAt t = P (ω ⟨t / D, (Nat.div_lt_iff_lt_mul hD).mpr ht⟩) ⟨t % D, Nat.mod_lt t hD⟩ := by
    intro t ht; simp [qAt, ht]
  have hq0 : ∀ t, ¬ (t < M * D) → qAt t = 0 := by
    intro t ht; simp [qAt, ht]
  have hqB : ∀ t, RatCoordBitBounded B (qAt t) := by
    intro t
    by_cases ht : t < M * D
    · rw [hqAt t ht]; exact hP _ _
    · rw [hq0 t ht]; exact ⟨by simp [natBitLength]; omega, by simp [natBitLength]; omega⟩
  obtain ⟨st₁, hrun1, hws1, hfd1, hbits1, hu1, hb1, hpc1, hpb1⟩ :=
    phase1_spec hK hD hB hs_eq hr_eq hM_eq (W := W) (by omega) P hP ω inp
      hIntP hActH hActC qAt hqAt hq0
  let wsBase := stageLoopWS (wsInit5 D r s) qAt (M * D)
  have hws1_eq : st₁.words = wsBase := hws1
  let ω' : Fin (r * s) → ι := fun t => ω ⟨t.val, hrsM ▸ t.isLt⟩
  let pts : Fin r → Fin s → Fin D → ℚ := fun i j => P (ω' (blockIdx i j))
  let flatPts : List ℚ :=
    (List.finRange r).flatMap (fun i =>
      (List.finRange s).flatMap (fun j => List.ofFn (pts i j)))
  let inpHull : BitRAMInput 0 :=
    { intParams := [(D : ℤ), (r : ℤ), (s : ℤ)]
      activeHandles := ∅
      activeRatCoords := fun _ c => Fin.elim0 c
      extraRats := flatPts }
  have hstage : StagingMatches wsBase inpHull := by
    have hqAt' : ∀ t (ht : t < r * s * D),
        qAt t = P (ω' ⟨t / D, (Nat.div_lt_iff_lt_mul hD).mpr ht⟩) ⟨t % D, Nat.mod_lt t hD⟩ := by
      intro t ht
      have htM : t < M * D := by rwa [← hrsM]
      rw [hqAt t htM]
    have hst := stagingMatches_stageLoopWS hD hs_pos P ω' qAt hqAt'
    dsimp only at hst
    simpa [wsBase, hrsM, inpHull, flatPts, pts, ω'] using hst
  dsimp only at hHullRun
  change runBitRAMWithBits progHull inpHull WordStore.empty [] = some outHull at hHullRun
  obtain ⟨fuelH, hfuelH⟩ := (runBitRAMWithBits_eq_some_iff _ _ _ _ _).mp hHullRun
  have hpop_emp : WordStore.empty.popDepth 0 = WordStore.empty :=
    popDepth_zero_of_isBaseStore isBaseStore_empty
  obtain ⟨wsHullEnd, st₂, hrun2, hwfH, hpopH, hws2, hfd2, hbits2, hccH, hbsH, hu2, hb2, hpc2, hpb2⟩ :=
    simulate_trStack inp hstage fuelH [.stmt progHull]
      { words := WordStore.empty.popDepth 0
        frameDepth := 0
        remainingBits := []
        unitCost := 0
        bitCost := 0
        peakCellSpace := inpHull.inputCellSpace + (WordStore.empty.popDepth 0).cellCount
        peakBitSpace := inpHull.inputBitSpace + (WordStore.empty.popDepth 0).bitSize }
      st₁ outHull
      (by rw [hpop_emp]; exact wellFormedWS_empty)
      rfl
      (by rw [hpop_emp, hws1_eq, mergeStore_empty hstage.1])
      hfd1
      hbits1
      le_rfl
      le_rfl
      hfuelH
  dsimp only [List.map, trCont, endDepth] at hrun2 hfd2 hu2 hb2
  have hread_shift10 : ∀ (t : ℕ) (idx : ℤ),
      st₂.words.read (.heap (t + 10) idx) = outHull.words.read (.heap t idx) := by
    intro t idx
    have hr := mergeStore_read_shift hstage.1 hwfH (.heap t idx)
    simp only [shiftLoc] at hr
    rw [hws2, hr, ← hpopH, wordStore_popDepth_read_heap]
  have hflag_st2 : st₂.words.read (.heap 10 0) = outHull.words.read (.heap 0 0) :=
    hread_shift10 0 0
  have hheap11_st2 : ∀ idx : ℤ,
      (st₂.words.popDepth 0).read (.heap 11 idx) = outHull.words.read (.heap 1 idx) := by
    intro idx
    rw [wordStore_popDepth_read_heap]
    exact hread_shift10 1 idx
  have hwsBase_cc : wsBase.cellCount ≤ 2 * (W + 5) := by
    have := cellCount_stageLoopWS_le D r s qAt (M * D)
    dsimp only [wsBase]; omega
  have hwsBase_bs : wsBase.bitSize ≤ 6 * (W + 5) ^ 2 := by
    have hb := bitSize_stageLoopWS_le (D := D) (r := r) (s := s) (B := B) (W := W)
      (by omega) (by omega) (by omega) (by omega) hqB (M * D) (by omega)
    have hm : 6 * (W + 5) * (M * D + 1) ≤ 6 * (W + 5) * (W + 5) :=
      Nat.mul_le_mul_left _ (by omega)
    have hr : 6 * (W + 5) * (W + 5) = 6 * (W + 5) ^ 2 := by ring
    dsimp only [wsBase]; omega
  have hst2_cc : st₂.words.cellCount ≤ 3 * (W + 5) := by
    rw [hws2]
    have := mergeStore_cellCount_le (wsBase := wsBase) (wsHull := wsHullEnd)
    omega
  have hlin_sq : W + 5 ≤ (W + 5) ^ 2 := Nat.le_self_pow (by omega) _
  have hsq_cu : (W + 5) ^ 2 ≤ (W + 5) ^ 3 := by
    calc
      (W + 5) ^ 2 = (W + 5) ^ 2 * 1 := (Nat.mul_one _).symm
      _ ≤ (W + 5) ^ 2 * (W + 5) := Nat.mul_le_mul_left _ (by omega)
      _ = (W + 5) ^ 3 := by ring
  have hlin_cu : W + 5 ≤ (W + 5) ^ 3 := hlin_sq.trans hsq_cu
  have hst2_bs : st₂.words.bitSize ≤ 11 * (W + 5) ^ 2 := by
    rw [hws2]
    have hm := mergeStore_bitSize_le (wsHull := wsHullEnd) hstage.1
    have h5 : 5 * outHull.peakBitSpace ≤ 5 * (W + 5) ^ 2 := by
      have : outHull.peakBitSpace ≤ W + 5 := by omega
      have : 5 * outHull.peakBitSpace ≤ 5 * (W + 5) := Nat.mul_le_mul_left 5 this
      have : 5 * (W + 5) ≤ 5 * (W + 5) ^ 2 := Nat.mul_le_mul_left 5 hlin_sq
      omega
    omega
  -- Summarize st₂ numeric bounds and clear all heavy WordStore / flatPts definitions
  generalize wsBase = wb at hwsBase_cc hwsBase_bs hpc2 hpb2 hws1_eq hstage hws2
  clear hHullRun hstage fuelH hfuelH wsHullEnd hwfH hpopH hws2 hccH hbsH hread_shift10 hws1_eq hws1
    inpHull flatPts wsBase hqAt hq0 hqB qAt hsub
  have hu2_clean : st₂.unitCost ≤ 500 + 45 * (W + 5) := by omega
  have hb2_clean : st₂.bitCost ≤ 500 * (W + 5) ^ 3 + 12 * (W + 5) := by omega
  have hpc2_clean : st₂.peakCellSpace ≤ 9 * (W + 5) := by omega
  have hpb2_clean : st₂.peakBitSpace ≤ 30 * (W + 5) ^ 2 := by omega
  clear hu1 hb1 hpc1 hpb1 hu2 hb2 hpc2 hpb2 hwsBase_cc hwsBase_bs wb
  set flag := outHull.words.read (.heap 0 0) with hflag_def
  have hb_flag : intBitLength flag ≤ 2 := by
    rcases hflag01 with h0 | h1
    · rw [h0]; decide
    · rw [h1]; decide
  have he_cond :
      evalBitCond inp st₂.frameDepth st₂.words (.intEq (.readHeap 10 (.lit 0)) (.lit 1)) =
        (decide (flag = 1), 4,
          (1 + natBitLength 10 + 1 + intBitLength flag) + 2 + intBitLength flag + 2) := by
    simp only [evalBitCond, evalIntExpr, hflag_st2, ← hflag_def]
    have h0 : intBitLength 0 = 1 := rfl
    have h1 : intBitLength 1 = 2 := by decide
    rw [h0, h1]
  let stPre : BitRAMExecState :=
    { st₂ with
      unitCost := st₂.unitCost + 4
      bitCost := st₂.bitCost + ((1 + natBitLength 10 + 1 + intBitLength flag) + 2 + intBitLength flag + 2) }
  have hn10 : natBitLength 10 = 4 := by decide
  have h500_cu : 500 ≤ 400 * (W + 5) ^ 3 := by
    have : 5 ≤ W + 5 := by omega
    have : 125 ≤ (W + 5) ^ 3 := Nat.pow_le_pow_left this 3
    omega
  rcases eq_or_ne flag 1 with hfl1 | hfl_ne1
  · -- Success branch: flag = 1
    obtain ⟨hsol_coords, hsol_cert⟩ := hflag_sol (hflag_def ▸ hfl1)
    let numAt : ℕ → ℤ := fun c => outHull.words.read (.heap 1 (2 * (c : ℤ)))
    let denAt : ℕ → ℤ := fun c => outHull.words.read (.heap 1 (2 * (c : ℤ) + 1))
    have hbl_succ : ∀ c < D, intBitLength (numAt c) ≤ W + 5 ∧ intBitLength (denAt c) ≤ W + 5 := by
      intro c hc
      have hsc := hsol_coords ⟨c, hc⟩
      dsimp only [numAt, denAt] at hsc ⊢
      exact ⟨hsc.2.1.trans (by omega), hsc.2.2.1.trans (by omega)⟩
    obtain ⟨stEnd, hbr, hbitsE, hreadE, huE, hbE, hpcE, hpbE⟩ :=
      phase3_branch_runsTo (W := W) inp stPre
        (.readHeap 11 (.mul (.lit 2) (.readLocal 0 (.lit 0))))
        (.readHeap 11 (.add (.mul (.lit 2) (.readLocal 0 (.lit 0))) (.lit 1)))
        numAt denAt hfd2 hbits2 (by omega) hbl_succ
        (by
          intro c hc ws hloc h11
          simp only [evalIntExpr, stPre, hloc, h11, hheap11_st2]
          have h0 : intBitLength 0 = 1 := rfl
          have hn0 : natBitLength 0 = 1 := rfl
          have h2 : intBitLength 2 = 3 := by decide
          have hn11 : natBitLength 11 = 4 := by decide
          have hbc : intBitLength (c : ℤ) ≤ W + 5 := by
            have := intBitLength_le_natAbs (c : ℤ); simp only [Int.natAbs_natCast] at this; omega
          have hb2c : intBitLength (2 * (c : ℤ)) ≤ W + 5 := by
            have h := intBitLength_le_natAbs (2 * (c : ℤ))
            have habs : (2 * (c : ℤ)).natAbs = 2 * c := by omega
            rw [habs] at h; omega
          have hbn := (hbl_succ c hc).1
          dsimp only [numAt] at hbn
          rw [h0, hn0, h2, hn11]
          exact ⟨rfl, by omega, by omega⟩)
        (by
          intro c hc ws hloc h11
          simp only [evalIntExpr, stPre, hloc, h11, hheap11_st2]
          have h0 : intBitLength 0 = 1 := rfl
          have hn0 : natBitLength 0 = 1 := rfl
          have h2 : intBitLength 2 = 3 := by decide
          have h1 : intBitLength 1 = 2 := by decide
          have hn11 : natBitLength 11 = 4 := by decide
          have hbc : intBitLength (c : ℤ) ≤ W + 5 := by
            have := intBitLength_le_natAbs (c : ℤ); simp only [Int.natAbs_natCast] at this; omega
          have hb2c : intBitLength (2 * (c : ℤ)) ≤ W + 5 := by
            have h := intBitLength_le_natAbs (2 * (c : ℤ))
            have habs : (2 * (c : ℤ)).natAbs = 2 * c := by omega
            rw [habs] at h; omega
          have hb2c1 : intBitLength (2 * (c : ℤ) + 1) ≤ W + 5 := by
            have h := intBitLength_le_natAbs (2 * (c : ℤ) + 1)
            have habs : (2 * (c : ℤ) + 1).natAbs = 2 * c + 1 := by omega
            rw [habs] at h; omega
          have hbd := (hbl_succ c hc).2
          dsimp only [denAt] at hbd
          rw [h0, hn0, h2, h1, hn11]
          exact ⟨rfl, by omega, by omega⟩)
    have hdec_true : decide (flag = 1) = true := decide_eq_true hfl1
    have hrun3 : RunsTo inp [.stmt phase3Stmt] st₂ stEnd := by
      refine RunsTo.ite _ _ _ ?_
      change (let p := evalBitCond inp st₂.frameDepth st₂.words (.intEq (.readHeap 10 (.lit 0)) (.lit 1))
        RunsTo inp [.stmt (if p.1 then _ else _)]
          { st₂ with unitCost := st₂.unitCost + p.2.1, bitCost := st₂.bitCost + p.2.2 } stEnd)
      rw [he_cond]
      dsimp only
      rw [hdec_true, if_pos rfl]
      exact hbr
    have hfull := RunsTo.seq hrun1 (RunsTo.seq hrun2 hrun3)
    have hout := RunsTo.toRunBitRAMWithBits (prog := centerProg K progHull)
      (inp := inp) (initWords := WordStore.empty) (bs := []) hfull hbitsE
    clear hrun1 hrun2 hrun3 hfull hbr
    let zRat : Fin D → ℚ := fun c => (numAt c.val : ℚ) / (denAt c.val : ℚ)
    refine ⟨_, zRat, hout, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · change stEnd.unitCost ≤ 1000 * (W + 5) ^ 3
      dsimp only [stPre] at huE; omega
    · change stEnd.bitCost ≤ 1000 * (W + 5) ^ 3
      dsimp only [stPre] at hbE; rw [hn10] at hbE; omega
    · change stEnd.peakCellSpace ≤ 1000 * (W + 5) ^ 3
      dsimp only [stPre] at hpcE; omega
    · change stEnd.peakBitSpace ≤ 1000 * (W + 5) ^ 3
      dsimp only [stPre] at hpbE; omega
    · intro c
      obtain ⟨hrn, hrd⟩ := hreadE c
      have hsc := hsol_coords c
      dsimp only [zRat, numAt, denAt] at hrn hrd hsc ⊢
      rw [hrn, hrd]
      exact ⟨hsc.1, rfl, hsc.2.1.trans (by omega), hsc.2.2.1.trans (by omega), hsc.2.2.2.trans (by omega)⟩
    · have hsum_le : ∑ c : Fin D, ratBitLength (zRat c) ≤ D * (W + 5) := by
        calc
          ∑ c : Fin D, ratBitLength (zRat c) ≤ ∑ _c : Fin D, (W + 5) := by
            refine Finset.sum_le_sum fun c _ => ?_
            have hsc := (hsol_coords c).2.2.2
            dsimp only [zRat, numAt, denAt] at hsc ⊢
            omega
          _ = D * (W + 5) := by simp
      have hDW_sq : D * (W + 5) ≤ (W + 5) ^ 2 := by
        calc
          D * (W + 5) ≤ (W + 5) * (W + 5) := Nat.mul_le_mul_right _ (by omega)
          _ = (W + 5) ^ 2 := (sq (W + 5)).symm
      omega
    · intro _ i
      exact hsol_cert i
  · -- Fallback branch: flag ≠ 1
    let numAt : ℕ → ℤ := fun _ => 0
    let denAt : ℕ → ℤ := fun _ => 1
    have hbl_fb : ∀ c < D, intBitLength (numAt c) ≤ W + 5 ∧ intBitLength (denAt c) ≤ W + 5 := by
      intro _ _
      have h0 : intBitLength 0 = 1 := rfl
      have h1 : intBitLength 1 = 2 := by decide
      dsimp only [numAt, denAt]; omega
    obtain ⟨stEnd, hbr, hbitsE, hreadE, huE, hbE, hpcE, hpbE⟩ :=
      phase3_branch_runsTo (W := W) inp stPre (.lit 0) (.lit 1)
        numAt denAt hfd2 hbits2 (by omega) hbl_fb
        (fun _ _ _ _ _ => by simp only [evalIntExpr]; have : intBitLength 0 = 1 := rfl; exact ⟨rfl, by omega, by omega⟩)
        (fun _ _ _ _ _ => by simp only [evalIntExpr]; have : intBitLength 1 = 2 := (by decide); exact ⟨rfl, by omega, by omega⟩)
    have hdec_false : decide (flag = 1) = false := decide_eq_false hfl_ne1
    have hrun3 : RunsTo inp [.stmt phase3Stmt] st₂ stEnd := by
      refine RunsTo.ite _ _ _ ?_
      change (let p := evalBitCond inp st₂.frameDepth st₂.words (.intEq (.readHeap 10 (.lit 0)) (.lit 1))
        RunsTo inp [.stmt (if p.1 then _ else _)]
          { st₂ with unitCost := st₂.unitCost + p.2.1, bitCost := st₂.bitCost + p.2.2 } stEnd)
      rw [he_cond]
      dsimp only
      rw [hdec_false, if_neg Bool.false_ne_true]
      exact hbr
    have hfull := RunsTo.seq hrun1 (RunsTo.seq hrun2 hrun3)
    have hout := RunsTo.toRunBitRAMWithBits (prog := centerProg K progHull)
      (inp := inp) (initWords := WordStore.empty) (bs := []) hfull hbitsE
    clear hrun1 hrun2 hrun3 hfull hbr
    let zRat : Fin D → ℚ := fun _ => 0
    refine ⟨_, zRat, hout, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · change stEnd.unitCost ≤ 1000 * (W + 5) ^ 3
      dsimp only [stPre] at huE; omega
    · change stEnd.bitCost ≤ 1000 * (W + 5) ^ 3
      dsimp only [stPre] at hbE; rw [hn10] at hbE; omega
    · change stEnd.peakCellSpace ≤ 1000 * (W + 5) ^ 3
      dsimp only [stPre] at hpcE; omega
    · change stEnd.peakBitSpace ≤ 1000 * (W + 5) ^ 3
      dsimp only [stPre] at hpbE; omega
    · intro c
      obtain ⟨hrn, hrd⟩ := hreadE c
      dsimp only [numAt, denAt] at hrn hrd
      dsimp only
      rw [hrn, hrd]
      have h0 : intBitLength 0 = 1 := rfl
      have h1 : intBitLength 1 = 2 := by decide
      have hr0 : ratBitLength 0 = 2 := by decide
      exact ⟨by omega, by simp [zRat], by omega, by omega, by dsimp [zRat]; omega⟩
    · have hr0 : ratBitLength (0 : ℚ) = 2 := by decide
      have hsum : (∑ _c : Fin D, ratBitLength (0 : ℚ)) = 2 * D := by
        rw [hr0]; simp; ring
      dsimp only [zRat]
      rw [hsum]
      omega
    · intro hex
      exfalso
      dsimp only at hflag_iff
      exact hfl_ne1 (hflag_iff.mpr hex)

end UL.Proof_lem_A_1
