import Mathlib
import UL.Def.def_computation_model
import UL.Proof.lem_A_1.H1_Params
set_option autoImplicit false

namespace UL.Proof_lem_A_1

/-! ### 1. Monotonicity and compositional operational lemmas (`RunsTo`) for `BitRAM` -/

theorem runBitRAMFuel_mono {d : ℕ} {inp : BitRAMInput d} :
    ∀ {fuel fuel' : ℕ} {stack : List BitRAMCont} {st : BitRAMExecState} {out : BitRAMExecOutcome},
      runBitRAMFuel inp fuel stack st = .halted out →
      fuel ≤ fuel' →
      runBitRAMFuel inp fuel' stack st = .halted out
  | _, _, [], st, out, h, _ => by
      unfold runBitRAMFuel at h ⊢
      exact h
  | 0, _, _ :: _, _, _, h, _ => by
      simp [runBitRAMFuel] at h
  | fuel + 1, 0, _ :: _, _, _, _, hle => by
      omega
  | fuel + 1, fuel' + 1, item :: rest, st, out, h, hle => by
      have hle' : fuel ≤ fuel' := by omega
      cases item with
      | popScope prev =>
          simp only [runBitRAMFuel] at h ⊢
          exact runBitRAMFuel_mono h hle'
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | succ rem' =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
      | stmt s =>
          cases s with
          | skip =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | writeHeap table idxE valE =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | writeLocal var idxE valE =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | freeHeap table idxE =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | freeLocal var idxE =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | randBitHeap table idxE =>
              simp only [runBitRAMFuel] at h ⊢
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons b bs =>
                  simp only [hbits] at h ⊢
                  exact runBitRAMFuel_mono h hle'
          | randBitLocal var idxE =>
              simp only [runBitRAMFuel] at h ⊢
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons b bs =>
                  simp only [hbits] at h ⊢
                  exact runBitRAMFuel_mono h hle'
          | seq s₁ s₂ =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | ite cond tB fB =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | whileLoop cond body =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | repeatN countE body =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'
          | localScope body =>
              simp only [runBitRAMFuel] at h ⊢
              exact runBitRAMFuel_mono h hle'

theorem runBitRAMFuel_cost_mono {d : ℕ} {inp : BitRAMInput d} :
    ∀ (fuel : ℕ) (stack : List BitRAMCont) (st : BitRAMExecState) (out : BitRAMExecOutcome),
      runBitRAMFuel inp fuel stack st = .halted out →
      st.unitCost ≤ out.unitCost ∧
      st.bitCost ≤ out.bitCost ∧
      st.peakCellSpace ≤ out.peakCellSpace ∧
      st.peakBitSpace ≤ out.peakBitSpace
  | _, [], st, out, h => by
      simp only [runBitRAMFuel] at h
      split_ifs at h with hemp
      cases h
      exact ⟨le_rfl, le_rfl, le_rfl, le_rfl⟩
  | 0, _ :: _, _, _, h => by
      simp [runBitRAMFuel] at h
  | fuel + 1, item :: rest, st, out, h => by
      cases item with
      | popScope prev =>
          simp only [runBitRAMFuel] at h
          obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel rest _ out h
          exact ⟨h1, h2, h3, h4⟩
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runBitRAMFuel] at h
              exact runBitRAMFuel_cost_mono fuel rest st out h
          | succ rem' =>
              simp only [runBitRAMFuel] at h
              exact runBitRAMFuel_cost_mono fuel _ st out h
      | stmt s =>
          cases s with
          | skip =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel rest _ out h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | writeHeap table idxE valE =>
              rcases e1 : evalIntExpr inp st.frameDepth st.words idxE with ⟨idx, u₁, b₁⟩
              rcases e2 : evalIntExpr inp st.frameDepth st.words valE with ⟨val, u₂, b₂⟩
              simp only [runBitRAMFuel, e1, e2] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel rest _ out h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, (le_max_left _ _).trans h3, (le_max_left _ _).trans h4⟩
          | writeLocal var idxE valE =>
              rcases e1 : evalIntExpr inp st.frameDepth st.words idxE with ⟨idx, u₁, b₁⟩
              rcases e2 : evalIntExpr inp st.frameDepth st.words valE with ⟨val, u₂, b₂⟩
              simp only [runBitRAMFuel, e1, e2] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel rest _ out h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, (le_max_left _ _).trans h3, (le_max_left _ _).trans h4⟩
          | freeHeap table idxE =>
              rcases e1 : evalIntExpr inp st.frameDepth st.words idxE with ⟨idx, u₁, b₁⟩
              simp only [runBitRAMFuel, e1] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel rest _ out h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | freeLocal var idxE =>
              rcases e1 : evalIntExpr inp st.frameDepth st.words idxE with ⟨idx, u₁, b₁⟩
              simp only [runBitRAMFuel, e1] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel rest _ out h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | randBitHeap table idxE =>
              simp only [runBitRAMFuel] at h
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons b bs =>
                  rcases e1 : evalIntExpr inp st.frameDepth st.words idxE with ⟨idx, u₁, b₁⟩
                  simp only [hbits, e1] at h
                  obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel rest _ out h
                  dsimp only at h1 h2 h3 h4
                  exact ⟨by omega, by omega, (le_max_left _ _).trans h3, (le_max_left _ _).trans h4⟩
          | randBitLocal var idxE =>
              simp only [runBitRAMFuel] at h
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons b bs =>
                  rcases e1 : evalIntExpr inp st.frameDepth st.words idxE with ⟨idx, u₁, b₁⟩
                  simp only [hbits, e1] at h
                  obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel rest _ out h
                  dsimp only at h1 h2 h3 h4
                  exact ⟨by omega, by omega, (le_max_left _ _).trans h3, (le_max_left _ _).trans h4⟩
          | seq s₁ s₂ =>
              simp only [runBitRAMFuel] at h
              exact runBitRAMFuel_cost_mono fuel _ st out h
          | ite cond tB fB =>
              rcases ec : evalBitCond inp st.frameDepth st.words cond with ⟨flag, u, b⟩
              simp only [runBitRAMFuel, ec] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel _ _ out h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | whileLoop cond body =>
              rcases ec : evalBitCond inp st.frameDepth st.words cond with ⟨flag, u, b⟩
              simp only [runBitRAMFuel, ec] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel _ _ out h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | repeatN countE body =>
              rcases e1 : evalIntExpr inp st.frameDepth st.words countE with ⟨cnt, u, b⟩
              simp only [runBitRAMFuel, e1] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel _ _ out h
              dsimp only at h1 h2 h3 h4
              exact ⟨by omega, by omega, h3, h4⟩
          | localScope body =>
              simp only [runBitRAMFuel] at h
              obtain ⟨h1, h2, h3, h4⟩ := runBitRAMFuel_cost_mono fuel _ _ out h
              exact ⟨h1, h2, h3, h4⟩

theorem runBitRAMWithBits_eq_some_iff {d : ℕ} (prog : BitRAMStmt) (inp : BitRAMInput d)
    (initWords : WordStore) (bs : List Bool) (out : BitRAMExecOutcome) :
    runBitRAMWithBits prog inp initWords bs = some out ↔
      ∃ fuel : ℕ,
        runBitRAMFuel inp fuel [.stmt prog]
          { words := initWords.popDepth 0
            frameDepth := 0
            remainingBits := bs
            unitCost := 0
            bitCost := 0
            peakCellSpace := inp.inputCellSpace + (initWords.popDepth 0).cellCount
            peakBitSpace := inp.inputBitSpace + (initWords.popDepth 0).bitSize } = .halted out := by
  classical
  unfold runBitRAMWithBits
  dsimp only
  set initSt : BitRAMExecState :=
    { words := initWords.popDepth 0
      frameDepth := 0
      remainingBits := bs
      unitCost := 0
      bitCost := 0
      peakCellSpace := inp.inputCellSpace + (initWords.popDepth 0).cellCount
      peakBitSpace := inp.inputBitSpace + (initWords.popDepth 0).bitSize }
  constructor
  · intro h
    split_ifs at h with hex
    rcases Nat.find_spec hex with ⟨out₀, hfind⟩
    rw [hfind] at h
    cases h
    exact ⟨Nat.find hex, hfind⟩
  · rintro ⟨fuel, hfuel⟩
    have hex : ∃ f : ℕ, ∃ o : BitRAMExecOutcome,
        runBitRAMFuel inp f [.stmt prog] initSt = .halted o := ⟨fuel, out, hfuel⟩
    rw [dif_pos hex]
    rcases Nat.find_spec hex with ⟨out₀, hfind⟩
    have hm1 := runBitRAMFuel_mono hfind (Nat.le_max_left (Nat.find hex) fuel)
    have hm2 := runBitRAMFuel_mono hfuel (Nat.le_max_right (Nat.find hex) fuel)
    rw [hm1] at hm2
    cases hm2
    rw [hfind]

def RunsTo {d : ℕ} (inp : BitRAMInput d) (items : List BitRAMCont)
    (st₁ st₂ : BitRAMExecState) : Prop :=
  ∃ fuel : ℕ, ∀ (rest : List BitRAMCont) (k : ℕ),
    runBitRAMFuel inp (fuel + k) (items ++ rest) st₁ =
      runBitRAMFuel inp k rest st₂

theorem RunsTo.nil {d : ℕ} {inp : BitRAMInput d} (st : BitRAMExecState) :
    RunsTo inp [] st st :=
  ⟨0, fun _ _ => by simp⟩

theorem RunsTo.trans {d : ℕ} {inp : BitRAMInput d} {xs ys : List BitRAMCont}
    {st₁ st₂ st₃ : BitRAMExecState}
    (h₁ : RunsTo inp xs st₁ st₂) (h₂ : RunsTo inp ys st₂ st₃) :
    RunsTo inp (xs ++ ys) st₁ st₃ := by
  rcases h₁ with ⟨f₁, hf₁⟩
  rcases h₂ with ⟨f₂, hf₂⟩
  refine ⟨f₁ + f₂, fun rest k => ?_⟩
  rw [Nat.add_assoc, List.append_assoc, hf₁ (ys ++ rest) (f₂ + k), hf₂ rest k]

theorem RunsTo.seq {d : ℕ} {inp : BitRAMInput d} {s₁ s₂ : BitRAMStmt}
    {st₁ st₂ st₃ : BitRAMExecState}
    (h₁ : RunsTo inp [.stmt s₁] st₁ st₂) (h₂ : RunsTo inp [.stmt s₂] st₂ st₃) :
    RunsTo inp [.stmt (.seq s₁ s₂)] st₁ st₃ := by
  have h12 : RunsTo inp [.stmt s₁, .stmt s₂] st₁ st₃ := RunsTo.trans h₁ h₂
  rcases h12 with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel] using hf rest k

theorem RunsTo.writeHeap {d : ℕ} (inp : BitRAMInput d) (table : ℕ) (idxE valE : IntExpr)
    (st : BitRAMExecState) :
    let (idx, u₁, b₁) := evalIntExpr inp st.frameDepth st.words idxE
    let (val, u₂, b₂) := evalIntExpr inp st.frameDepth st.words valE
    let loc := RAMCellLoc.heap table idx
    let ws' := st.words.write loc val
    RunsTo inp [.stmt (.writeHeap table idxE valE)] st
      { st with
        words := ws'
        unitCost := st.unitCost + u₁ + u₂ + 1
        bitCost := st.bitCost + b₁ + b₂ + loc.bitLength + intBitLength val
        peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + ws'.cellCount)
        peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + ws'.bitSize) } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.writeLocal {d : ℕ} (inp : BitRAMInput d) (var : ℕ) (idxE valE : IntExpr)
    (st : BitRAMExecState) :
    let (idx, u₁, b₁) := evalIntExpr inp st.frameDepth st.words idxE
    let (val, u₂, b₂) := evalIntExpr inp st.frameDepth st.words valE
    let loc := RAMCellLoc.localFrame st.frameDepth var idx
    let ws' := st.words.write loc val
    RunsTo inp [.stmt (.writeLocal var idxE valE)] st
      { st with
        words := ws'
        unitCost := st.unitCost + u₁ + u₂ + 1
        bitCost := st.bitCost + b₁ + b₂ + loc.bitLength + intBitLength val
        peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + ws'.cellCount)
        peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + ws'.bitSize) } := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.ite {d : ℕ} {inp : BitRAMInput d} (cond : BitCondExpr) (tB fB : BitRAMStmt)
    {st st' : BitRAMExecState}
    (hbranch :
      let (flag, u, b) := evalBitCond inp st.frameDepth st.words cond
      RunsTo inp [.stmt (if flag then tB else fB)]
        { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } st') :
    RunsTo inp [.stmt (.ite cond tB fB)] st st' := by
  dsimp only at hbranch
  rcases hbranch with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel] using hf rest k

theorem RunsTo.localScope {d : ℕ} {inp : BitRAMInput d} {body : BitRAMStmt}
    {st stBody : BitRAMExecState}
    (hbody : RunsTo inp [.stmt body]
      { st with words := st.words.popDepth st.frameDepth, frameDepth := st.frameDepth + 1 }
      stBody) :
    RunsTo inp [.stmt (.localScope body)] st
      { stBody with words := stBody.words.popDepth st.frameDepth, frameDepth := st.frameDepth } := by
  rcases hbody with ⟨fb, hfb⟩
  refine ⟨1 + fb + 1, fun rest k => ?_⟩
  have h1 : 1 + fb + 1 + k = (fb + (1 + k)) + 1 := by omega
  rw [h1]
  simp only [List.singleton_append, runBitRAMFuel]
  have h2 := hfb (.popScope st.frameDepth :: rest) (1 + k)
  simp only [List.singleton_append] at h2
  rw [h2, show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.repeatLoop_zero {d : ℕ} {inp : BitRAMInput d} (body : BitRAMStmt)
    (st : BitRAMExecState) :
    RunsTo inp [.repeatLoop 0 body] st st := by
  refine ⟨1, fun rest k => ?_⟩
  rw [show 1 + k = k + 1 by omega]
  rfl

theorem RunsTo.repeatLoop_succ {d : ℕ} {inp : BitRAMInput d} {rem : ℕ} {body : BitRAMStmt}
    {st₁ st₂ st₃ : BitRAMExecState}
    (hbody : RunsTo inp [.stmt body] st₁ st₂)
    (hrem : RunsTo inp [.repeatLoop rem body] st₂ st₃) :
    RunsTo inp [.repeatLoop (rem + 1) body] st₁ st₃ := by
  have hcomb : RunsTo inp [.stmt body, .repeatLoop rem body] st₁ st₃ := RunsTo.trans hbody hrem
  rcases hcomb with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel] using hf rest k

theorem RunsTo.repeatN {d : ℕ} {inp : BitRAMInput d} (countE : IntExpr) (body : BitRAMStmt)
    {st st' : BitRAMExecState}
    (hloop :
      let (cnt, u, b) := evalIntExpr inp st.frameDepth st.words countE
      let nIter := if 0 ≤ cnt then cnt.toNat else 0
      RunsTo inp [.repeatLoop nIter body]
        { st with unitCost := st.unitCost + u, bitCost := st.bitCost + b } st') :
    RunsTo inp [.stmt (.repeatN countE body)] st st' := by
  dsimp only at hloop
  rcases hloop with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  simpa [runBitRAMFuel] using hf rest k

theorem RunsTo.toRunBitRAMWithBits {d : ℕ} {prog : BitRAMStmt} {inp : BitRAMInput d}
    {initWords : WordStore} {bs : List Bool} {stEnd : BitRAMExecState}
    (hrun : RunsTo inp [.stmt prog]
      { words := initWords.popDepth 0
        frameDepth := 0
        remainingBits := bs
        unitCost := 0
        bitCost := 0
        peakCellSpace := inp.inputCellSpace + (initWords.popDepth 0).cellCount
        peakBitSpace := inp.inputBitSpace + (initWords.popDepth 0).bitSize } stEnd)
    (hbits : stEnd.remainingBits = []) :
    runBitRAMWithBits prog inp initWords bs = some
      { words := stEnd.words.popDepth 0
        unitCost := stEnd.unitCost
        bitCost := stEnd.bitCost
        peakCellSpace := stEnd.peakCellSpace
        peakBitSpace := stEnd.peakBitSpace } := by
  rw [runBitRAMWithBits_eq_some_iff]
  rcases hrun with ⟨fuel, hfuel⟩
  refine ⟨fuel, ?_⟩
  have h0 := hfuel [] 0
  simp only [Nat.add_zero, List.append_nil] at h0
  rw [h0]
  simp [runBitRAMFuel, hbits]

/-! ### 2. `WordStore` invariants and `mergeStore` for shifted subroutine simulation -/

def WellFormedWS (ws : WordStore) : Prop :=
  ∀ loc : RAMCellLoc, loc ∉ ws.live → ws.vals loc = 0

theorem wellFormedWS_empty : WellFormedWS WordStore.empty :=
  fun _ _ => rfl

theorem wellFormedWS_write {ws : WordStore} (h : WellFormedWS ws) (loc : RAMCellLoc) (v : ℤ) :
    WellFormedWS (ws.write loc v) := by
  intro l hl
  simp only [WordStore.write, Finset.mem_insert, not_or] at hl ⊢
  rw [Function.update_of_ne hl.1]
  exact h l hl.2

theorem wellFormedWS_free {ws : WordStore} (h : WellFormedWS ws) (loc : RAMCellLoc) :
    WellFormedWS (ws.free loc) := by
  intro l hl
  simp only [WordStore.free, Finset.mem_erase, not_and_or, not_ne_iff] at hl ⊢
  rcases hl with rfl | hnot
  · simp
  · by_cases heq : l = loc
    · subst heq; simp
    · rw [Function.update_of_ne heq]
      exact h l hnot

theorem wellFormedWS_popDepth {ws : WordStore} (h : WellFormedWS ws) (keep : ℕ) :
    WellFormedWS (ws.popDepth keep) := by
  intro l hl
  unfold WordStore.popDepth at hl ⊢
  dsimp only at hl ⊢
  by_cases hk : l.keepAtDepth keep = true
  · rw [if_pos hk]
    apply h l
    intro hmem
    exact hl (Finset.mem_filter.mpr ⟨hmem, hk⟩)
  · rw [if_neg hk]

theorem wordStore_read_eq_vals {ws : WordStore} (h : WellFormedWS ws) (loc : RAMCellLoc) :
    ws.read loc = ws.vals loc := by
  unfold WordStore.read
  split_ifs with hmem
  · rfl
  · exact (h loc hmem).symm

theorem wordStore_popDepth_read_heap (ws : WordStore) (keep t : ℕ) (idx : ℤ) :
    (ws.popDepth keep).read (.heap t idx) = ws.read (.heap t idx) := by
  simp [WordStore.popDepth, WordStore.read, RAMCellLoc.keepAtDepth]

theorem cellCount_free_le (ws : WordStore) (loc : RAMCellLoc) :
    (ws.free loc).cellCount ≤ ws.cellCount :=
  Finset.card_le_card (Finset.erase_subset loc ws.live)

theorem bitSize_free_le (ws : WordStore) (loc : RAMCellLoc) :
    (ws.free loc).bitSize ≤ ws.bitSize := by
  unfold WordStore.bitSize WordStore.free
  calc
    ∑ l ∈ ws.live.erase loc, (l.bitLength + intBitLength (Function.update ws.vals loc 0 l))
        = ∑ l ∈ ws.live.erase loc, (l.bitLength + intBitLength (ws.vals l)) := by
          refine Finset.sum_congr rfl fun l hl => ?_
          rw [Function.update_of_ne (Finset.ne_of_mem_erase hl)]
    _ ≤ ∑ l ∈ ws.live, (l.bitLength + intBitLength (ws.vals l)) :=
        Finset.sum_le_sum_of_subset (Finset.erase_subset loc ws.live)

theorem cellCount_popDepth_le (ws : WordStore) (keep : ℕ) :
    (ws.popDepth keep).cellCount ≤ ws.cellCount :=
  Finset.card_filter_le _ _

theorem bitSize_popDepth_le (ws : WordStore) (keep : ℕ) :
    (ws.popDepth keep).bitSize ≤ ws.bitSize := by
  unfold WordStore.bitSize WordStore.popDepth
  calc
    ∑ l ∈ ws.live.filter (fun l => l.keepAtDepth keep = true),
        (l.bitLength + intBitLength (if l.keepAtDepth keep then ws.vals l else 0))
        = ∑ l ∈ ws.live.filter (fun l => l.keepAtDepth keep = true),
            (l.bitLength + intBitLength (ws.vals l)) := by
          refine Finset.sum_congr rfl fun l hl => ?_
          simp [(Finset.mem_filter.mp hl).2]
    _ ≤ ∑ l ∈ ws.live, (l.bitLength + intBitLength (ws.vals l)) :=
        Finset.sum_le_sum_of_subset (Finset.filter_subset _ _)

def IsBaseStore (wsBase : WordStore) : Prop :=
  WellFormedWS wsBase ∧
  ∀ loc ∈ wsBase.live, ∃ (t : ℕ) (idx : ℤ), t < 10 ∧ loc = .heap t idx

def shiftLoc : RAMCellLoc → RAMCellLoc
  | .heap t idx => .heap (t + 10) idx
  | .localFrame d v idx => .localFrame d v idx

theorem shiftLoc_injective : Function.Injective shiftLoc := by
  intro a b h
  cases a <;> cases b <;> simp [shiftLoc] at h ⊢
  · exact ⟨by omega, h.2⟩
  · exact h

def shiftEmb : RAMCellLoc ↪ RAMCellLoc :=
  ⟨shiftLoc, shiftLoc_injective⟩

theorem shiftLoc_not_mem_base {wsBase : WordStore} (hbase : IsBaseStore wsBase)
    (loc : RAMCellLoc) :
    shiftLoc loc ∉ wsBase.live := by
  intro hmem
  rcases hbase.2 _ hmem with ⟨t, idx, ht10, heq⟩
  cases loc with
  | heap t' idx' =>
      simp [shiftLoc] at heq
      omega
  | localFrame d v idx' =>
      simp [shiftLoc] at heq

def mergeStore (wsBase wsHull : WordStore) : WordStore where
  live := wsBase.live ∪ wsHull.live.map shiftEmb
  vals := fun loc =>
    match loc with
    | .heap t idx =>
        if t < 10 then wsBase.vals (.heap t idx) else wsHull.vals (.heap (t - 10) idx)
    | .localFrame d v idx => wsHull.vals (.localFrame d v idx)

theorem wellFormedWS_mergeStore {wsBase wsHull : WordStore}
    (hbase : IsBaseStore wsBase) (hhull : WellFormedWS wsHull) :
    WellFormedWS (mergeStore wsBase wsHull) := by
  intro loc hnot
  simp only [mergeStore, Finset.mem_union, Finset.mem_map, not_or, not_exists, not_and] at hnot
  cases loc with
  | heap t idx =>
      dsimp only [mergeStore]
      split_ifs with ht
      · exact hbase.1 _ hnot.1
      · apply hhull
        intro hm
        apply hnot.2 (.heap (t - 10) idx) hm
        simp [shiftEmb, shiftLoc]
        omega
  | localFrame d v idx =>
      dsimp only [mergeStore]
      apply hhull
      intro hm
      exact hnot.2 (.localFrame d v idx) hm rfl

theorem mergeStore_empty {wsBase : WordStore} (hbase : IsBaseStore wsBase) :
    mergeStore wsBase WordStore.empty = wsBase := by
  cases wsBase with
  | mk live vals =>
    unfold mergeStore WordStore.empty
    congr 1
    · simp
    · funext loc
      cases loc with
      | heap t idx =>
          dsimp only
          split_ifs with ht
          · rfl
          · symm
            apply hbase.1 (.heap t idx)
            intro hmem
            rcases hbase.2 _ hmem with ⟨t', idx', ht', heq⟩
            cases heq
            omega
      | localFrame d v idx =>
          dsimp only
          symm
          apply hbase.1 (.localFrame d v idx)
          intro hmem
          rcases hbase.2 _ hmem with ⟨t', idx', _, heq⟩
          cases heq

theorem mergeStore_read_base {wsBase wsHull : WordStore}
    (hbase : IsBaseStore wsBase) (hhull : WellFormedWS wsHull)
    {t : ℕ} (ht : t < 10) (idx : ℤ) :
    (mergeStore wsBase wsHull).read (.heap t idx) = wsBase.read (.heap t idx) := by
  rw [wordStore_read_eq_vals (wellFormedWS_mergeStore hbase hhull),
    wordStore_read_eq_vals hbase.1]
  simp [mergeStore, ht]

theorem mergeStore_read_shift {wsBase wsHull : WordStore}
    (hbase : IsBaseStore wsBase) (hhull : WellFormedWS wsHull)
    (loc : RAMCellLoc) :
    (mergeStore wsBase wsHull).read (shiftLoc loc) = wsHull.read loc := by
  rw [wordStore_read_eq_vals (wellFormedWS_mergeStore hbase hhull),
    wordStore_read_eq_vals hhull]
  cases loc with
  | heap t idx =>
      have hnot : ¬ (t + 10 < 10) := by omega
      have hsub : t + 10 - 10 = t := by omega
      simp [shiftLoc, mergeStore, hnot, hsub]
  | localFrame d v idx =>
      simp [shiftLoc, mergeStore]

theorem mergeStore_write_shift {wsBase wsHull : WordStore} (loc : RAMCellLoc) (val : ℤ) :
    (mergeStore wsBase wsHull).write (shiftLoc loc) val =
      mergeStore wsBase (wsHull.write loc val) := by
  unfold WordStore.write mergeStore
  congr 1
  · ext l
    simp only [Finset.mem_insert, Finset.mem_union, Finset.mem_map, shiftEmb,
      Function.Embedding.coeFn_mk]
    constructor
    · rintro (rfl | hl | ⟨u, hu, rfl⟩)
      · exact Or.inr ⟨loc, Or.inl rfl, rfl⟩
      · exact Or.inl hl
      · exact Or.inr ⟨u, Or.inr hu, rfl⟩
    · rintro (hl | ⟨u, rfl | hu, rfl⟩)
      · exact Or.inr (Or.inl hl)
      · exact Or.inl rfl
      · exact Or.inr (Or.inr ⟨u, hu, rfl⟩)
  · funext l
    cases l with
    | heap t idx =>
        by_cases heq : RAMCellLoc.heap t idx = shiftLoc loc
        · rw [heq, Function.update_self]
          cases loc with
          | heap t' idx' =>
              have hnot : ¬ (t' + 10 < 10) := by omega
              have hsub : t' + 10 - 10 = t' := by omega
              simp only [shiftLoc, hnot, ↓reduceIte]
              rw [hsub, Function.update_self]
          | localFrame _ _ _ => simp [shiftLoc] at heq
        · rw [Function.update_of_ne heq]
          dsimp only
          split_ifs with ht
          · rfl
          · have hne : RAMCellLoc.heap (t - 10) idx ≠ loc := by
              intro hcontr
              subst hcontr
              apply heq
              simp [shiftLoc]
              omega
            rw [Function.update_of_ne hne]
    | localFrame d v idx =>
        by_cases heq : RAMCellLoc.localFrame d v idx = shiftLoc loc
        · rw [heq, Function.update_self]
          cases loc with
          | heap _ _ => simp [shiftLoc] at heq
          | localFrame d' v' idx' =>
              simp [shiftLoc]
        · rw [Function.update_of_ne heq]
          dsimp only
          have hne : RAMCellLoc.localFrame d v idx ≠ loc := by
            intro hcontr
            subst hcontr
            exact heq rfl
          rw [Function.update_of_ne hne]

theorem mergeStore_free_shift {wsBase wsHull : WordStore}
    (hbase : IsBaseStore wsBase) (loc : RAMCellLoc) :
    (mergeStore wsBase wsHull).free (shiftLoc loc) =
      mergeStore wsBase (wsHull.free loc) := by
  unfold WordStore.free mergeStore
  congr 1
  · ext l
    simp only [Finset.mem_erase, Finset.mem_union, Finset.mem_map, shiftEmb,
      Function.Embedding.coeFn_mk]
    constructor
    · rintro ⟨hne, hl | ⟨u, hu, rfl⟩⟩
      · exact Or.inl hl
      · refine Or.inr ⟨u, ⟨?_, hu⟩, rfl⟩
        intro heq
        subst heq
        exact hne rfl
    · rintro (hl | ⟨u, ⟨hne, hu⟩, rfl⟩)
      · refine ⟨?_, Or.inl hl⟩
        intro heq
        subst heq
        exact shiftLoc_not_mem_base hbase loc hl
      · refine ⟨?_, Or.inr ⟨u, hu, rfl⟩⟩
        intro heq
        exact hne (shiftLoc_injective heq)
  · funext l
    cases l with
    | heap t idx =>
        by_cases heq : RAMCellLoc.heap t idx = shiftLoc loc
        · rw [heq, Function.update_self]
          cases loc with
          | heap t' idx' =>
              have hnot : ¬ (t' + 10 < 10) := by omega
              have hsub : t' + 10 - 10 = t' := by omega
              simp only [shiftLoc, hnot, ↓reduceIte]
              rw [hsub, Function.update_self]
          | localFrame _ _ _ => simp [shiftLoc] at heq
        · rw [Function.update_of_ne heq]
          dsimp only
          split_ifs with ht
          · rfl
          · have hne : RAMCellLoc.heap (t - 10) idx ≠ loc := by
              intro hcontr
              subst hcontr
              apply heq
              simp [shiftLoc]
              omega
            rw [Function.update_of_ne hne]
    | localFrame d v idx =>
        by_cases heq : RAMCellLoc.localFrame d v idx = shiftLoc loc
        · rw [heq, Function.update_self]
          cases loc with
          | heap _ _ => simp [shiftLoc] at heq
          | localFrame d' v' idx' =>
              simp [shiftLoc]
        · rw [Function.update_of_ne heq]
          dsimp only
          have hne : RAMCellLoc.localFrame d v idx ≠ loc := by
            intro hcontr
            subst hcontr
            exact heq rfl
          rw [Function.update_of_ne hne]

theorem mergeStore_popDepth {wsBase wsHull : WordStore}
    (hbase : IsBaseStore wsBase) (keep : ℕ) :
    (mergeStore wsBase wsHull).popDepth keep =
      mergeStore wsBase (wsHull.popDepth keep) := by
  have hkeep_shift : ∀ u : RAMCellLoc, (shiftLoc u).keepAtDepth keep = u.keepAtDepth keep := by
    intro u
    cases u <;> rfl
  unfold WordStore.popDepth mergeStore
  congr 1
  · ext l
    simp only [Finset.mem_filter, Finset.mem_union, Finset.mem_map, shiftEmb,
      Function.Embedding.coeFn_mk]
    constructor
    · rintro ⟨hl | ⟨u, hu, rfl⟩, hk⟩
      · exact Or.inl hl
      · rw [hkeep_shift u] at hk
        exact Or.inr ⟨u, ⟨hu, hk⟩, rfl⟩
    · rintro (hl | ⟨u, ⟨hu, hk⟩, rfl⟩)
      · refine ⟨Or.inl hl, ?_⟩
        rcases hbase.2 l hl with ⟨t, idx, _, rfl⟩
        rfl
      · rw [← hkeep_shift u] at hk
        exact ⟨Or.inr ⟨u, hu, rfl⟩, hk⟩
  · funext l
    cases l with
    | heap t idx =>
        simp [RAMCellLoc.keepAtDepth]
    | localFrame d v idx =>
        simp [RAMCellLoc.keepAtDepth]

theorem shiftLoc_bitLength_le (loc : RAMCellLoc) :
    (shiftLoc loc).bitLength ≤ loc.bitLength + 4 := by
  cases loc with
  | heap t idx =>
      simp only [shiftLoc, RAMCellLoc.bitLength]
      have := natBitLength_add_ten t
      omega
  | localFrame d v idx =>
      simp [shiftLoc]

theorem ramCellLoc_bitLength_pos (loc : RAMCellLoc) : 1 ≤ loc.bitLength := by
  cases loc with
  | heap t idx =>
      simp only [RAMCellLoc.bitLength]
      have := natBitLength_pos t
      omega
  | localFrame d v idx =>
      simp only [RAMCellLoc.bitLength]
      have := natBitLength_pos d
      omega

theorem mergeStore_cellCount_le {wsBase wsHull : WordStore} :
    (mergeStore wsBase wsHull).cellCount ≤ wsBase.cellCount + wsHull.cellCount := by
  unfold WordStore.cellCount mergeStore
  calc
    (wsBase.live ∪ wsHull.live.map shiftEmb).card
        ≤ wsBase.live.card + (wsHull.live.map shiftEmb).card := Finset.card_union_le _ _
    _ = wsBase.live.card + wsHull.live.card := by rw [Finset.card_map]

theorem mergeStore_bitSize_le {wsBase wsHull : WordStore} (hbase : IsBaseStore wsBase) :
    (mergeStore wsBase wsHull).bitSize ≤ wsBase.bitSize + 5 * wsHull.bitSize := by
  unfold WordStore.bitSize mergeStore
  have hdisj : Disjoint wsBase.live (wsHull.live.map shiftEmb) := by
    rw [Finset.disjoint_left]
    intro l hl hmap
    rcases Finset.mem_map.mp hmap with ⟨u, _, rfl⟩
    exact shiftLoc_not_mem_base hbase u hl
  rw [Finset.sum_union hdisj]
  have hbase_sum :
      (∑ loc ∈ wsBase.live,
        (loc.bitLength +
          intBitLength
            (match loc with
            | .heap t idx =>
                if t < 10 then wsBase.vals (.heap t idx) else wsHull.vals (.heap (t - 10) idx)
            | .localFrame d v idx => wsHull.vals (.localFrame d v idx)))) =
      wsBase.bitSize := by
    unfold WordStore.bitSize
    refine Finset.sum_congr rfl fun loc hloc => ?_
    rcases hbase.2 loc hloc with ⟨t, idx, ht10, rfl⟩
    simp [ht10]
  rw [hbase_sum, Finset.sum_map, Finset.mul_sum]
  refine Nat.add_le_add_left (Finset.sum_le_sum fun u _ => ?_) _
  have hval :
      (match shiftLoc u with
      | .heap t idx =>
          if t < 10 then wsBase.vals (.heap t idx) else wsHull.vals (.heap (t - 10) idx)
      | .localFrame d v idx => wsHull.vals (.localFrame d v idx)) = wsHull.vals u := by
    cases u with
    | heap t idx =>
        have hnot : ¬ (t + 10 < 10) := by omega
        have hsub : t + 10 - 10 = t := by omega
        simp [shiftLoc, hnot, hsub]
    | localFrame d v idx => rfl
  simp only [shiftEmb, Function.Embedding.coeFn_mk, hval]
  have hb1 := shiftLoc_bitLength_le u
  have hb2 := ramCellLoc_bitLength_pos u
  omega

/-! ### 3. Syntax translation of `BitRAMInput 0` programs to shifted heap tables -/

def trExpr : IntExpr → IntExpr
  | .lit c => .lit c
  | .dim => .lit 0
  | .intParam idxE => .readHeap 5 (trExpr idxE)
  | .readHeap table idxE => .readHeap (table + 10) (trExpr idxE)
  | .readLocal var idxE => .readLocal var (trExpr idxE)
  | .activeRatNum _ _ => .lit 0
  | .activeRatDen _ _ => .lit 1
  | .extraRatNum idxE => .readHeap 6 (trExpr idxE)
  | .extraRatDen idxE => .add (.readHeap 7 (trExpr idxE)) (.lit 1)
  | .neg e => .neg (trExpr e)
  | .add e₁ e₂ => .add (trExpr e₁) (trExpr e₂)
  | .sub e₁ e₂ => .sub (trExpr e₁) (trExpr e₂)
  | .mul e₁ e₂ => .mul (trExpr e₁) (trExpr e₂)
  | .div e₁ e₂ => .div (trExpr e₁) (trExpr e₂)
  | .mod e₁ e₂ => .mod (trExpr e₁) (trExpr e₂)

def trCond : BitCondExpr → BitCondExpr
  | .intEq e₁ e₂ => .intEq (trExpr e₁) (trExpr e₂)
  | .intLt e₁ e₂ => .intLt (trExpr e₁) (trExpr e₂)
  | .intLe e₁ e₂ => .intLe (trExpr e₁) (trExpr e₂)
  | .not c => .not (trCond c)
  | .and c₁ c₂ => .and (trCond c₁) (trCond c₂)
  | .or c₁ c₂ => .or (trCond c₁) (trCond c₂)

def trStmt : BitRAMStmt → BitRAMStmt
  | .skip => .skip
  | .writeHeap table idxE valE => .writeHeap (table + 10) (trExpr idxE) (trExpr valE)
  | .writeLocal var idxE valE => .writeLocal var (trExpr idxE) (trExpr valE)
  | .freeHeap table idxE => .freeHeap (table + 10) (trExpr idxE)
  | .freeLocal var idxE => .freeLocal var (trExpr idxE)
  | .randBitHeap table idxE => .randBitHeap (table + 10) (trExpr idxE)
  | .randBitLocal var idxE => .randBitLocal var (trExpr idxE)
  | .seq s₁ s₂ => .seq (trStmt s₁) (trStmt s₂)
  | .ite cond tB fB => .ite (trCond cond) (trStmt tB) (trStmt fB)
  | .whileLoop cond body => .whileLoop (trCond cond) (trStmt body)
  | .repeatN countE body => .repeatN (trExpr countE) (trStmt body)
  | .localScope body => .localScope (trStmt body)

def trCont : BitRAMCont → BitRAMCont
  | .stmt s => .stmt (trStmt s)
  | .repeatLoop rem body => .repeatLoop rem (trStmt body)
  | .popScope prev => .popScope prev

def endDepth : List BitRAMCont → ℕ → ℕ
  | [], fd => fd
  | .stmt _ :: rest, fd => endDepth rest fd
  | .repeatLoop _ _ :: rest, fd => endDepth rest fd
  | .popScope prev :: rest, _ => endDepth rest prev

def StagingMatches (wsBase : WordStore) (inpHull : BitRAMInput 0) : Prop :=
  IsBaseStore wsBase ∧
  inpHull.activeHandles = ∅ ∧
  (∀ idx : ℤ, wsBase.read (.heap 5 idx) = listGetIntD inpHull.intParams idx 0) ∧
  (∀ idx : ℤ, wsBase.read (.heap 6 idx) = (listGetIntD inpHull.extraRats idx 0).num) ∧
  (∀ idx : ℤ, wsBase.read (.heap 7 idx) + 1 = ((listGetIntD inpHull.extraRats idx 0).den : ℤ))

theorem evalIntExpr_trExpr {d : ℕ} (inpSim : BitRAMInput d)
    {wsBase wsHull : WordStore} {inpHull : BitRAMInput 0}
    (hstage : StagingMatches wsBase inpHull) (hhull : WellFormedWS wsHull)
    (frameDepth : ℕ) (e : IntExpr) :
    let (v, u, b) := evalIntExpr inpHull frameDepth wsHull e
    let (v', u', b') := evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e)
    v' = v ∧ u' ≤ 3 * u ∧ b' ≤ 12 * b := by
  induction e with
  | lit c =>
      simp [trExpr, evalIntExpr]
      omega
  | dim =>
      simp [trExpr, evalIntExpr]
      omega
  | intParam idxE ih =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr idxE) with
        ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at ih
      rcases ih with ⟨heq, hu, hb⟩
      rw [heq] at h2
      simp only [trExpr, evalIntExpr, h1, h2,
        mergeStore_read_base hstage.1 hhull (by omega : 5 < 10), hstage.2.2.1]
      have hb_idx : 1 ≤ intBitLength idx := intBitLength_pos idx
      have hn5 : natBitLength 5 = 3 := by decide
      rw [hn5]
      refine ⟨by simp, by omega, by omega⟩
  | readHeap table idxE ih =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr idxE) with
        ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at ih
      rcases ih with ⟨heq, hu, hb⟩
      rw [heq] at h2
      have hread := mergeStore_read_shift hstage.1 hhull (.heap table idx)
      simp only [shiftLoc] at hread
      simp only [trExpr, evalIntExpr, h1, h2, hread]
      have ht10 := natBitLength_add_ten table
      have ht1 := natBitLength_pos table
      refine ⟨by simp, by omega, by omega⟩
  | readLocal var idxE ih =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr idxE) with
        ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at ih
      rcases ih with ⟨heq, hu, hb⟩
      rw [heq] at h2
      have hread := mergeStore_read_shift hstage.1 hhull (.localFrame frameDepth var idx)
      simp only [shiftLoc] at hread
      simp only [trExpr, evalIntExpr, h1, h2, hread]
      refine ⟨by simp, by omega, by omega⟩
  | activeRatNum hE cE _ _ =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull hE with ⟨h, u₁, b₁⟩
      rcases h2 : evalIntExpr inpHull frameDepth wsHull cE with ⟨c, u₂, b₂⟩
      simp only [trExpr, evalIntExpr, h1, h2, hstage.2.1, Finset.notMem_empty, and_false,
        ↓reduceDIte]
      have hb0 : intBitLength 0 = 1 := rfl
      rw [hb0]
      refine ⟨by simp, by omega, by omega⟩
  | activeRatDen hE cE _ _ =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull hE with ⟨h, u₁, b₁⟩
      rcases h2 : evalIntExpr inpHull frameDepth wsHull cE with ⟨c, u₂, b₂⟩
      simp only [trExpr, evalIntExpr, h1, h2, hstage.2.1, Finset.notMem_empty, and_false,
        ↓reduceDIte]
      refine ⟨by simp, by omega, by omega⟩
  | extraRatNum idxE ih =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr idxE) with
        ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at ih
      rcases ih with ⟨heq, hu, hb⟩
      rw [heq] at h2
      simp only [trExpr, evalIntExpr, h1, h2,
        mergeStore_read_base hstage.1 hhull (by omega : 6 < 10), hstage.2.2.2.1]
      have hb_idx : 1 ≤ intBitLength idx := intBitLength_pos idx
      have hn6 : natBitLength 6 = 3 := by decide
      rw [hn6]
      refine ⟨by simp, by omega, by omega⟩
  | extraRatDen idxE ih =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull idxE with ⟨idx, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr idxE) with
        ⟨idx', u'₀, b'₀⟩
      simp only [h1, h2] at ih
      rcases ih with ⟨heq, hu, hb⟩
      rw [heq] at h2
      let q := listGetIntD inpHull.extraRats idx 0
      have hv_pos : (1 : ℤ) ≤ (q.den : ℤ) := by exact_mod_cast q.pos
      have hread7 : (mergeStore wsBase wsHull).read (.heap 7 idx) = (q.den : ℤ) - 1 := by
        rw [mergeStore_read_base hstage.1 hhull (by omega : 7 < 10)]
        have := hstage.2.2.2.2 idx
        dsimp only [q]
        omega
      simp only [trExpr, evalIntExpr, h1, h2, hread7]
      have hv_eq : (q.den : ℤ) - 1 + 1 = (q.den : ℤ) := by omega
      have habs : ((q.den : ℤ) - 1).natAbs ≤ ((q.den : ℤ)).natAbs := by omega
      have hbl_sub : intBitLength ((q.den : ℤ) - 1) ≤ intBitLength (q.den : ℤ) + 1 :=
        intBitLength_mono_natAbs habs
      have hb_idx : 1 ≤ intBitLength idx := intBitLength_pos idx
      have hb_den : 1 ≤ intBitLength (q.den : ℤ) := intBitLength_pos _
      have hn7 : natBitLength 7 = 3 := by decide
      have hb1 : intBitLength 1 = 2 := by decide
      dsimp only [q] at hv_eq hbl_sub hb_den ⊢
      rw [hv_eq, hn7, hb1]
      refine ⟨by simp, by omega, by omega⟩
  | neg e ih =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull e with ⟨v, u₀, b₀⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e) with
        ⟨v', u'₀, b'₀⟩
      simp only [h1, h2] at ih
      rcases ih with ⟨heq, hu, hb⟩
      rw [heq] at h2
      simp only [trExpr, evalIntExpr, h1, h2]
      refine ⟨by simp, by omega, by omega⟩
  | add e₁ e₂ ih₁ ih₂ =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₁) with
        ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpHull frameDepth wsHull e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₂) with
        ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trExpr, evalIntExpr, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩
  | sub e₁ e₂ ih₁ ih₂ =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₁) with
        ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpHull frameDepth wsHull e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₂) with
        ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trExpr, evalIntExpr, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩
  | mul e₁ e₂ ih₁ ih₂ =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₁) with
        ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpHull frameDepth wsHull e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₂) with
        ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trExpr, evalIntExpr, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩
  | div e₁ e₂ ih₁ ih₂ =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₁) with
        ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpHull frameDepth wsHull e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₂) with
        ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trExpr, evalIntExpr, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩
  | mod e₁ e₂ ih₁ ih₂ =>
      rcases h1 : evalIntExpr inpHull frameDepth wsHull e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₁) with
        ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpHull frameDepth wsHull e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₂) with
        ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trExpr, evalIntExpr, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩

theorem evalBitCond_trCond {d : ℕ} (inpSim : BitRAMInput d)
    {wsBase wsHull : WordStore} {inpHull : BitRAMInput 0}
    (hstage : StagingMatches wsBase inpHull) (hhull : WellFormedWS wsHull)
    (frameDepth : ℕ) (c : BitCondExpr) :
    let (res, u, b) := evalBitCond inpHull frameDepth wsHull c
    let (res', u', b') := evalBitCond inpSim frameDepth (mergeStore wsBase wsHull) (trCond c)
    res' = res ∧ u' ≤ 3 * u ∧ b' ≤ 12 * b := by
  induction c with
  | intEq e₁ e₂ =>
      have ih₁ := evalIntExpr_trExpr inpSim hstage hhull frameDepth e₁
      have ih₂ := evalIntExpr_trExpr inpSim hstage hhull frameDepth e₂
      rcases h1 : evalIntExpr inpHull frameDepth wsHull e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₁) with
        ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpHull frameDepth wsHull e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₂) with
        ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trCond, evalBitCond, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩
  | intLt e₁ e₂ =>
      have ih₁ := evalIntExpr_trExpr inpSim hstage hhull frameDepth e₁
      have ih₂ := evalIntExpr_trExpr inpSim hstage hhull frameDepth e₂
      rcases h1 : evalIntExpr inpHull frameDepth wsHull e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₁) with
        ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpHull frameDepth wsHull e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₂) with
        ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trCond, evalBitCond, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩
  | intLe e₁ e₂ =>
      have ih₁ := evalIntExpr_trExpr inpSim hstage hhull frameDepth e₁
      have ih₂ := evalIntExpr_trExpr inpSim hstage hhull frameDepth e₂
      rcases h1 : evalIntExpr inpHull frameDepth wsHull e₁ with ⟨v₁, u₁, b₁⟩
      rcases h2 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₁) with
        ⟨v'₁, u'₁, b'₁⟩
      rcases h3 : evalIntExpr inpHull frameDepth wsHull e₂ with ⟨v₂, u₂, b₂⟩
      rcases h4 : evalIntExpr inpSim frameDepth (mergeStore wsBase wsHull) (trExpr e₂) with
        ⟨v'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trCond, evalBitCond, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩
  | not c₀ ih =>
      rcases h1 : evalBitCond inpHull frameDepth wsHull c₀ with ⟨r₀, u₀, b₀⟩
      rcases h2 : evalBitCond inpSim frameDepth (mergeStore wsBase wsHull) (trCond c₀) with
        ⟨r'₀, u'₀, b'₀⟩
      simp only [h1, h2] at ih
      rcases ih with ⟨heq, hu, hb⟩
      rw [heq] at h2
      simp only [trCond, evalBitCond, h1, h2]
      refine ⟨by simp, by omega, by omega⟩
  | and c₁ c₂ ih₁ ih₂ =>
      rcases h1 : evalBitCond inpHull frameDepth wsHull c₁ with ⟨r₁, u₁, b₁⟩
      rcases h2 : evalBitCond inpSim frameDepth (mergeStore wsBase wsHull) (trCond c₁) with
        ⟨r'₁, u'₁, b'₁⟩
      rcases h3 : evalBitCond inpHull frameDepth wsHull c₂ with ⟨r₂, u₂, b₂⟩
      rcases h4 : evalBitCond inpSim frameDepth (mergeStore wsBase wsHull) (trCond c₂) with
        ⟨r'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trCond, evalBitCond, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩
  | or c₁ c₂ ih₁ ih₂ =>
      rcases h1 : evalBitCond inpHull frameDepth wsHull c₁ with ⟨r₁, u₁, b₁⟩
      rcases h2 : evalBitCond inpSim frameDepth (mergeStore wsBase wsHull) (trCond c₁) with
        ⟨r'₁, u'₁, b'₁⟩
      rcases h3 : evalBitCond inpHull frameDepth wsHull c₂ with ⟨r₂, u₂, b₂⟩
      rcases h4 : evalBitCond inpSim frameDepth (mergeStore wsBase wsHull) (trCond c₂) with
        ⟨r'₂, u'₂, b'₂⟩
      simp only [h1, h2] at ih₁
      simp only [h3, h4] at ih₂
      rcases ih₁ with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
      rcases ih₂ with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
      simp only [trCond, evalBitCond, h1, h2, h3, h4]
      refine ⟨by simp, by omega, by omega⟩

private theorem step_RunsTo {d : ℕ} {inp : BitRAMInput d}
    {item : BitRAMCont} {restItems nextStack : List BitRAMCont} {st st' stEnd : BitRAMExecState}
    (hstep : ∀ (rest : List BitRAMCont) (k : ℕ),
      runBitRAMFuel inp (k + 1) (item :: restItems ++ rest) st =
        runBitRAMFuel inp k (nextStack ++ rest) st')
    (hruns : RunsTo inp nextStack st' stEnd) :
    RunsTo inp (item :: restItems) st stEnd := by
  rcases hruns with ⟨f, hf⟩
  refine ⟨1 + f, fun rest k => ?_⟩
  rw [Nat.add_assoc, show 1 + (f + k) = (f + k) + 1 by omega]
  rw [hstep rest (f + k)]
  exact hf rest k

theorem simulate_trStack {d : ℕ} (inpSim : BitRAMInput d)
    {wsBase : WordStore} {inpHull : BitRAMInput 0}
    (hstage : StagingMatches wsBase inpHull) :
    ∀ (fuel : ℕ) (stack : List BitRAMCont) (stHull stSim : BitRAMExecState)
      (outHull : BitRAMExecOutcome),
      WellFormedWS stHull.words →
      stHull.remainingBits = [] →
      stSim.words = mergeStore wsBase stHull.words →
      stSim.frameDepth = stHull.frameDepth →
      stSim.remainingBits = [] →
      inpHull.inputCellSpace + stHull.words.cellCount ≤ stHull.peakCellSpace →
      inpHull.inputBitSpace + stHull.words.bitSize ≤ stHull.peakBitSpace →
      runBitRAMFuel inpHull fuel stack stHull = .halted outHull →
      ∃ (wsHullEnd : WordStore) (stSimEnd : BitRAMExecState),
        RunsTo inpSim (stack.map trCont) stSim stSimEnd ∧
        WellFormedWS wsHullEnd ∧
        wsHullEnd.popDepth 0 = outHull.words ∧
        stSimEnd.words = mergeStore wsBase wsHullEnd ∧
        stSimEnd.frameDepth = endDepth stack stHull.frameDepth ∧
        stSimEnd.remainingBits = [] ∧
        wsHullEnd.cellCount ≤ outHull.peakCellSpace ∧
        wsHullEnd.bitSize ≤ outHull.peakBitSpace ∧
        stSimEnd.unitCost ≤ stSim.unitCost + 3 * (outHull.unitCost - stHull.unitCost) ∧
        stSimEnd.bitCost ≤ stSim.bitCost + 12 * (outHull.bitCost - stHull.bitCost) ∧
        stSimEnd.peakCellSpace ≤
          max stSim.peakCellSpace
            (inpSim.inputCellSpace + wsBase.cellCount + outHull.peakCellSpace) ∧
        stSimEnd.peakBitSpace ≤
          max stSim.peakBitSpace
            (inpSim.inputBitSpace + wsBase.bitSize + 5 * outHull.peakBitSpace) := by
  intro fuel
  induction fuel with
  | zero =>
      intro stack stHull stSim outHull hwf hbitsH hws hfd hbitsS hpcH hpbH hrun
      cases stack with
      | nil =>
          simp only [runBitRAMFuel, hbitsH, List.isEmpty_nil, ↓reduceIte,
            BitRAMRunStatus.halted.injEq] at hrun
          subst hrun
          dsimp only
          refine ⟨stHull.words, stSim, RunsTo.nil stSim, hwf, rfl, hws, hfd, hbitsS,
            by omega, by omega, by omega, by omega, le_max_left _ _, le_max_left _ _⟩
      | cons _ _ =>
          simp [runBitRAMFuel] at hrun
  | succ fuel ih =>
      intro stack stHull stSim outHull hwf hbitsH hws hfd hbitsS hpcH hpbH hrun
      cases stack with
      | nil =>
          simp only [runBitRAMFuel, hbitsH, List.isEmpty_nil, ↓reduceIte,
            BitRAMRunStatus.halted.injEq] at hrun
          subst hrun
          dsimp only
          refine ⟨stHull.words, stSim, RunsTo.nil stSim, hwf, rfl, hws, hfd, hbitsS,
            by omega, by omega, by omega, by omega, le_max_left _ _, le_max_left _ _⟩
      | cons item rest =>
          cases item with
          | popScope prev =>
              simp only [runBitRAMFuel] at hrun
              let stHull' : BitRAMExecState :=
                { stHull with words := stHull.words.popDepth prev, frameDepth := prev }
              let stSim' : BitRAMExecState :=
                { stSim with words := stSim.words.popDepth prev, frameDepth := prev }
              have hwf' : WellFormedWS stHull'.words := wellFormedWS_popDepth hwf prev
              have hws' : stSim'.words = mergeStore wsBase stHull'.words := by
                dsimp [stSim', stHull']
                rw [hws, mergeStore_popDepth hstage.1 prev]
              have hpcH' : inpHull.inputCellSpace + stHull'.words.cellCount ≤ stHull'.peakCellSpace := by
                have := cellCount_popDepth_le stHull.words prev
                dsimp [stHull']
                omega
              have hpbH' : inpHull.inputBitSpace + stHull'.words.bitSize ≤ stHull'.peakBitSpace := by
                have := bitSize_popDepth_le stHull.words prev
                dsimp [stHull']
                omega
              obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                ih rest stHull' stSim' outHull hwf' hbitsH hws' rfl hbitsS hpcH' hpbH' hrun
              refine ⟨wsEnd, stEnd,
                step_RunsTo (fun r k => rfl) hruns,
                hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                huEnd, hbEnd, hpcEnd, hpbEnd⟩
          | repeatLoop rem body =>
              cases rem with
              | zero =>
                  simp only [runBitRAMFuel] at hrun
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih rest stHull stSim outHull hwf hbitsH hws hfd hbitsS hpcH hpbH hrun
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩
              | succ rem' =>
                  simp only [runBitRAMFuel] at hrun
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih (.stmt body :: .repeatLoop rem' body :: rest) stHull stSim outHull
                      hwf hbitsH hws hfd hbitsS hpcH hpbH hrun
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩
          | stmt s =>
              cases s with
              | skip =>
                  simp only [runBitRAMFuel] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono fuel _ _ outHull hrun
                  let stHull' : BitRAMExecState :=
                    { stHull with unitCost := stHull.unitCost + 1, bitCost := stHull.bitCost + 1 }
                  let stSim' : BitRAMExecState :=
                    { stSim with unitCost := stSim.unitCost + 1, bitCost := stSim.bitCost + 1 }
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih rest stHull' stSim' outHull hwf hbitsH hws hfd hbitsS hpcH hpbH hrun
                  dsimp only [stHull', stSim'] at hmu hmb huEnd hbEnd hpcEnd hpbEnd
                  refine ⟨wsEnd, stEnd, step_RunsTo (fun r k => rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    by omega, by omega, hpcEnd, hpbEnd⟩
              | writeHeap table idxE valE =>
                  have e1 := evalIntExpr_trExpr inpSim hstage hwf stHull.frameDepth idxE
                  have e2 := evalIntExpr_trExpr inpSim hstage hwf stHull.frameDepth valE
                  rcases h1 : evalIntExpr inpHull stHull.frameDepth stHull.words idxE with ⟨idx, u₁, b₁⟩
                  rcases h2 : evalIntExpr inpSim stSim.frameDepth stSim.words (trExpr idxE) with
                    ⟨idx', u'₁, b'₁⟩
                  rcases h3 : evalIntExpr inpHull stHull.frameDepth stHull.words valE with ⟨val, u₂, b₂⟩
                  rcases h4 : evalIntExpr inpSim stSim.frameDepth stSim.words (trExpr valE) with
                    ⟨val', u'₂, b'₂⟩
                  have h2m : evalIntExpr inpSim stHull.frameDepth (mergeStore wsBase stHull.words) (trExpr idxE) = (idx', u'₁, b'₁) := by
                    rwa [← hws, ← hfd]
                  have h4m : evalIntExpr inpSim stHull.frameDepth (mergeStore wsBase stHull.words) (trExpr valE) = (val', u'₂, b'₂) := by
                    rwa [← hws, ← hfd]
                  simp only [h1, h2m] at e1
                  simp only [h3, h4m] at e2
                  rcases e1 with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
                  rcases e2 with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
                  simp only [runBitRAMFuel, h1, h3] at hrun
                  obtain ⟨hmu, hmb, hmpc, hmpb⟩ := runBitRAMFuel_cost_mono fuel _ _ outHull hrun
                  dsimp only at hmu hmb hmpc hmpb
                  let locH := RAMCellLoc.heap table idx
                  let locS := RAMCellLoc.heap (table + 10) idx
                  have hloc_eq : locS = shiftLoc locH := rfl
                  let wsH' := stHull.words.write locH val
                  let wsS' := stSim.words.write locS val
                  have hws' : wsS' = mergeStore wsBase wsH' := by
                    dsimp [wsS', wsH']
                    rw [hws, hloc_eq, mergeStore_write_shift]
                  have hwf' : WellFormedWS wsH' := wellFormedWS_write hwf locH val
                  let stHull' : BitRAMExecState :=
                    { stHull with
                      words := wsH'
                      unitCost := stHull.unitCost + u₁ + u₂ + 1
                      bitCost := stHull.bitCost + b₁ + b₂ + locH.bitLength + intBitLength val
                      peakCellSpace := max stHull.peakCellSpace (inpHull.inputCellSpace + wsH'.cellCount)
                      peakBitSpace := max stHull.peakBitSpace (inpHull.inputBitSpace + wsH'.bitSize) }
                  let stSim' : BitRAMExecState :=
                    { stSim with
                      words := wsS'
                      unitCost := stSim.unitCost + u'₁ + u'₂ + 1
                      bitCost := stSim.bitCost + b'₁ + b'₂ + locS.bitLength + intBitLength val
                      peakCellSpace := max stSim.peakCellSpace (inpSim.inputCellSpace + wsS'.cellCount)
                      peakBitSpace := max stSim.peakBitSpace (inpSim.inputBitSpace + wsS'.bitSize) }
                  have hpcH' : inpHull.inputCellSpace + stHull'.words.cellCount ≤ stHull'.peakCellSpace :=
                    le_max_right _ _
                  have hpbH' : inpHull.inputBitSpace + stHull'.words.bitSize ≤ stHull'.peakBitSpace :=
                    le_max_right _ _
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih rest stHull' stSim' outHull hwf' hbitsH hws' hfd hbitsS hpcH' hpbH' hrun
                  have hloc_bl : locS.bitLength ≤ locH.bitLength + 4 := shiftLoc_bitLength_le locH
                  have hloc_pos : 1 ≤ locH.bitLength := ramCellLoc_bitLength_pos locH
                  have hcc_le : wsS'.cellCount ≤ wsBase.cellCount + wsH'.cellCount := by
                    rw [hws']; exact mergeStore_cellCount_le
                  have hbs_le : wsS'.bitSize ≤ wsBase.bitSize + 5 * wsH'.bitSize := by
                    rw [hws']; exact mergeStore_bitSize_le hstage.1
                  have hwsH_cc : wsH'.cellCount ≤ outHull.peakCellSpace := by
                    have : inpHull.inputCellSpace + wsH'.cellCount ≤ outHull.peakCellSpace :=
                      (le_max_right _ _).trans hmpc
                    omega
                  have hwsH_bs : wsH'.bitSize ≤ outHull.peakBitSpace := by
                    have : inpHull.inputBitSpace + wsH'.bitSize ≤ outHull.peakBitSpace :=
                      (le_max_right _ _).trans hmpb
                    omega
                  dsimp only [stHull', stSim', locH, locS] at huEnd hbEnd hpcEnd hpbEnd hloc_bl hloc_pos
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => by simp only [List.map, List.cons_append, trCont, trStmt, runBitRAMFuel, h2, h4]; rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    by omega, by omega, ?_, ?_⟩
                  · refine hpcEnd.trans (max_le (max_le (le_max_left _ _) ?_) (le_max_right _ _))
                    exact (by omega : inpSim.inputCellSpace + wsS'.cellCount ≤
                      inpSim.inputCellSpace + wsBase.cellCount + outHull.peakCellSpace).trans (le_max_right _ _)
                  · refine hpbEnd.trans (max_le (max_le (le_max_left _ _) ?_) (le_max_right _ _))
                    exact (by omega : inpSim.inputBitSpace + wsS'.bitSize ≤
                      inpSim.inputBitSpace + wsBase.bitSize + 5 * outHull.peakBitSpace).trans (le_max_right _ _)
              | writeLocal var idxE valE =>
                  have e1 := evalIntExpr_trExpr inpSim hstage hwf stHull.frameDepth idxE
                  have e2 := evalIntExpr_trExpr inpSim hstage hwf stHull.frameDepth valE
                  rcases h1 : evalIntExpr inpHull stHull.frameDepth stHull.words idxE with ⟨idx, u₁, b₁⟩
                  rcases h2 : evalIntExpr inpSim stSim.frameDepth stSim.words (trExpr idxE) with
                    ⟨idx', u'₁, b'₁⟩
                  rcases h3 : evalIntExpr inpHull stHull.frameDepth stHull.words valE with ⟨val, u₂, b₂⟩
                  rcases h4 : evalIntExpr inpSim stSim.frameDepth stSim.words (trExpr valE) with
                    ⟨val', u'₂, b'₂⟩
                  have h2m : evalIntExpr inpSim stHull.frameDepth (mergeStore wsBase stHull.words) (trExpr idxE) = (idx', u'₁, b'₁) := by
                    rwa [← hws, ← hfd]
                  have h4m : evalIntExpr inpSim stHull.frameDepth (mergeStore wsBase stHull.words) (trExpr valE) = (val', u'₂, b'₂) := by
                    rwa [← hws, ← hfd]
                  simp only [h1, h2m] at e1
                  simp only [h3, h4m] at e2
                  rcases e1 with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
                  rcases e2 with ⟨heq₂, hu₂, hb₂⟩; rw [heq₂] at h4
                  simp only [runBitRAMFuel, h1, h3] at hrun
                  obtain ⟨hmu, hmb, hmpc, hmpb⟩ := runBitRAMFuel_cost_mono fuel _ _ outHull hrun
                  dsimp only at hmu hmb hmpc hmpb
                  let locH := RAMCellLoc.localFrame stHull.frameDepth var idx
                  let locS := RAMCellLoc.localFrame stSim.frameDepth var idx
                  have hloc_eq : locS = shiftLoc locH := by simp [locS, locH, shiftLoc, hfd]
                  let wsH' := stHull.words.write locH val
                  let wsS' := stSim.words.write locS val
                  have hws' : wsS' = mergeStore wsBase wsH' := by
                    dsimp [wsS', wsH']
                    rw [hws, hloc_eq, mergeStore_write_shift]
                  have hwf' : WellFormedWS wsH' := wellFormedWS_write hwf locH val
                  let stHull' : BitRAMExecState :=
                    { stHull with
                      words := wsH'
                      unitCost := stHull.unitCost + u₁ + u₂ + 1
                      bitCost := stHull.bitCost + b₁ + b₂ + locH.bitLength + intBitLength val
                      peakCellSpace := max stHull.peakCellSpace (inpHull.inputCellSpace + wsH'.cellCount)
                      peakBitSpace := max stHull.peakBitSpace (inpHull.inputBitSpace + wsH'.bitSize) }
                  let stSim' : BitRAMExecState :=
                    { stSim with
                      words := wsS'
                      unitCost := stSim.unitCost + u'₁ + u'₂ + 1
                      bitCost := stSim.bitCost + b'₁ + b'₂ + locS.bitLength + intBitLength val
                      peakCellSpace := max stSim.peakCellSpace (inpSim.inputCellSpace + wsS'.cellCount)
                      peakBitSpace := max stSim.peakBitSpace (inpSim.inputBitSpace + wsS'.bitSize) }
                  have hpcH' : inpHull.inputCellSpace + stHull'.words.cellCount ≤ stHull'.peakCellSpace :=
                    le_max_right _ _
                  have hpbH' : inpHull.inputBitSpace + stHull'.words.bitSize ≤ stHull'.peakBitSpace :=
                    le_max_right _ _
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih rest stHull' stSim' outHull hwf' hbitsH hws' hfd hbitsS hpcH' hpbH' hrun
                  have hloc_bl : locS.bitLength = locH.bitLength := by simp [locS, locH, hfd]
                  have hcc_le : wsS'.cellCount ≤ wsBase.cellCount + wsH'.cellCount := by
                    rw [hws']; exact mergeStore_cellCount_le
                  have hbs_le : wsS'.bitSize ≤ wsBase.bitSize + 5 * wsH'.bitSize := by
                    rw [hws']; exact mergeStore_bitSize_le hstage.1
                  have hwsH_cc : wsH'.cellCount ≤ outHull.peakCellSpace := by
                    have : inpHull.inputCellSpace + wsH'.cellCount ≤ outHull.peakCellSpace :=
                      (le_max_right _ _).trans hmpc
                    omega
                  have hwsH_bs : wsH'.bitSize ≤ outHull.peakBitSpace := by
                    have : inpHull.inputBitSpace + wsH'.bitSize ≤ outHull.peakBitSpace :=
                      (le_max_right _ _).trans hmpb
                    omega
                  dsimp only [stHull', stSim', locH, locS] at huEnd hbEnd hpcEnd hpbEnd hloc_bl
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => by simp only [List.map, List.cons_append, trCont, trStmt, runBitRAMFuel, h2, h4]; rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    by omega, by omega, ?_, ?_⟩
                  · refine hpcEnd.trans (max_le (max_le (le_max_left _ _) ?_) (le_max_right _ _))
                    exact (by omega : inpSim.inputCellSpace + wsS'.cellCount ≤
                      inpSim.inputCellSpace + wsBase.cellCount + outHull.peakCellSpace).trans (le_max_right _ _)
                  · refine hpbEnd.trans (max_le (max_le (le_max_left _ _) ?_) (le_max_right _ _))
                    exact (by omega : inpSim.inputBitSpace + wsS'.bitSize ≤
                      inpSim.inputBitSpace + wsBase.bitSize + 5 * outHull.peakBitSpace).trans (le_max_right _ _)
              | freeHeap table idxE =>
                  have e1 := evalIntExpr_trExpr inpSim hstage hwf stHull.frameDepth idxE
                  rcases h1 : evalIntExpr inpHull stHull.frameDepth stHull.words idxE with ⟨idx, u₁, b₁⟩
                  rcases h2 : evalIntExpr inpSim stSim.frameDepth stSim.words (trExpr idxE) with
                    ⟨idx', u'₁, b'₁⟩
                  have h2m : evalIntExpr inpSim stHull.frameDepth (mergeStore wsBase stHull.words) (trExpr idxE) = (idx', u'₁, b'₁) := by
                    rwa [← hws, ← hfd]
                  simp only [h1, h2m] at e1
                  rcases e1 with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
                  simp only [runBitRAMFuel, h1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono fuel _ _ outHull hrun
                  dsimp only at hmu hmb
                  let locH := RAMCellLoc.heap table idx
                  let locS := RAMCellLoc.heap (table + 10) idx
                  have hloc_eq : locS = shiftLoc locH := rfl
                  let wsH' := stHull.words.free locH
                  let wsS' := stSim.words.free locS
                  have hws' : wsS' = mergeStore wsBase wsH' := by
                    dsimp [wsS', wsH']
                    rw [hws, hloc_eq, mergeStore_free_shift hstage.1]
                  have hwf' : WellFormedWS wsH' := wellFormedWS_free hwf locH
                  let stHull' : BitRAMExecState :=
                    { stHull with
                      words := wsH'
                      unitCost := stHull.unitCost + u₁ + 1
                      bitCost := stHull.bitCost + b₁ + locH.bitLength }
                  let stSim' : BitRAMExecState :=
                    { stSim with
                      words := wsS'
                      unitCost := stSim.unitCost + u'₁ + 1
                      bitCost := stSim.bitCost + b'₁ + locS.bitLength }
                  have hpcH' : inpHull.inputCellSpace + stHull'.words.cellCount ≤ stHull'.peakCellSpace := by
                    have := cellCount_free_le stHull.words locH
                    dsimp [stHull', wsH']
                    omega
                  have hpbH' : inpHull.inputBitSpace + stHull'.words.bitSize ≤ stHull'.peakBitSpace := by
                    have := bitSize_free_le stHull.words locH
                    dsimp [stHull', wsH']
                    omega
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih rest stHull' stSim' outHull hwf' hbitsH hws' hfd hbitsS hpcH' hpbH' hrun
                  have hloc_bl : locS.bitLength ≤ locH.bitLength + 4 := shiftLoc_bitLength_le locH
                  have hloc_pos : 1 ≤ locH.bitLength := ramCellLoc_bitLength_pos locH
                  dsimp only [stHull', stSim', locH, locS] at huEnd hbEnd hpcEnd hpbEnd hloc_bl hloc_pos
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => by simp only [List.map, List.cons_append, trCont, trStmt, runBitRAMFuel, h2]; rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    by omega, by omega, hpcEnd, hpbEnd⟩
              | freeLocal var idxE =>
                  have e1 := evalIntExpr_trExpr inpSim hstage hwf stHull.frameDepth idxE
                  rcases h1 : evalIntExpr inpHull stHull.frameDepth stHull.words idxE with ⟨idx, u₁, b₁⟩
                  rcases h2 : evalIntExpr inpSim stSim.frameDepth stSim.words (trExpr idxE) with
                    ⟨idx', u'₁, b'₁⟩
                  have h2m : evalIntExpr inpSim stHull.frameDepth (mergeStore wsBase stHull.words) (trExpr idxE) = (idx', u'₁, b'₁) := by
                    rwa [← hws, ← hfd]
                  simp only [h1, h2m] at e1
                  rcases e1 with ⟨heq₁, hu₁, hb₁⟩; rw [heq₁] at h2
                  simp only [runBitRAMFuel, h1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono fuel _ _ outHull hrun
                  dsimp only at hmu hmb
                  let locH := RAMCellLoc.localFrame stHull.frameDepth var idx
                  let locS := RAMCellLoc.localFrame stSim.frameDepth var idx
                  have hloc_eq : locS = shiftLoc locH := by simp [locS, locH, shiftLoc, hfd]
                  let wsH' := stHull.words.free locH
                  let wsS' := stSim.words.free locS
                  have hws' : wsS' = mergeStore wsBase wsH' := by
                    dsimp [wsS', wsH']
                    rw [hws, hloc_eq, mergeStore_free_shift hstage.1]
                  have hwf' : WellFormedWS wsH' := wellFormedWS_free hwf locH
                  let stHull' : BitRAMExecState :=
                    { stHull with
                      words := wsH'
                      unitCost := stHull.unitCost + u₁ + 1
                      bitCost := stHull.bitCost + b₁ + locH.bitLength }
                  let stSim' : BitRAMExecState :=
                    { stSim with
                      words := wsS'
                      unitCost := stSim.unitCost + u'₁ + 1
                      bitCost := stSim.bitCost + b'₁ + locS.bitLength }
                  have hpcH' : inpHull.inputCellSpace + stHull'.words.cellCount ≤ stHull'.peakCellSpace := by
                    have := cellCount_free_le stHull.words locH
                    dsimp [stHull', wsH']
                    omega
                  have hpbH' : inpHull.inputBitSpace + stHull'.words.bitSize ≤ stHull'.peakBitSpace := by
                    have := bitSize_free_le stHull.words locH
                    dsimp [stHull', wsH']
                    omega
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih rest stHull' stSim' outHull hwf' hbitsH hws' hfd hbitsS hpcH' hpbH' hrun
                  have hloc_bl : locS.bitLength = locH.bitLength := by simp [locS, locH, hfd]
                  dsimp only [stHull', stSim', locH, locS] at huEnd hbEnd hpcEnd hpbEnd hloc_bl
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => by simp only [List.map, List.cons_append, trCont, trStmt, runBitRAMFuel, h2]; rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    by omega, by omega, hpcEnd, hpbEnd⟩
              | randBitHeap _ _ =>
                  simp [runBitRAMFuel, hbitsH] at hrun
              | randBitLocal _ _ =>
                  simp [runBitRAMFuel, hbitsH] at hrun
              | seq s₁ s₂ =>
                  simp only [runBitRAMFuel] at hrun
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih (.stmt s₁ :: .stmt s₂ :: rest) stHull stSim outHull
                      hwf hbitsH hws hfd hbitsS hpcH hpbH hrun
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩
              | ite cond tB fB =>
                  have ec := evalBitCond_trCond inpSim hstage hwf stHull.frameDepth cond
                  rcases h1 : evalBitCond inpHull stHull.frameDepth stHull.words cond with ⟨flag, u, b⟩
                  rcases h2 : evalBitCond inpSim stSim.frameDepth stSim.words (trCond cond) with
                    ⟨flag', u', b'⟩
                  have h2m : evalBitCond inpSim stHull.frameDepth (mergeStore wsBase stHull.words) (trCond cond) = (flag', u', b') := by
                    rwa [← hws, ← hfd]
                  simp only [h1, h2m] at ec
                  rcases ec with ⟨heq₁, hu, hb⟩; rw [heq₁] at h2
                  simp only [runBitRAMFuel, h1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono fuel _ _ outHull hrun
                  dsimp only at hmu hmb
                  let stHull' := { stHull with unitCost := stHull.unitCost + u, bitCost := stHull.bitCost + b }
                  let stSim' := { stSim with unitCost := stSim.unitCost + u', bitCost := stSim.bitCost + b' }
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih (.stmt (if flag then tB else fB) :: rest) stHull' stSim' outHull
                      hwf hbitsH hws hfd hbitsS hpcH hpbH hrun
                  dsimp only [stHull', stSim'] at huEnd hbEnd hpcEnd hpbEnd
                  have hif_tr : trStmt (if flag then tB else fB) = if flag then trStmt tB else trStmt fB := by
                    cases flag <;> rfl
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => by simp only [List.map, List.cons_append, trCont, trStmt, runBitRAMFuel, h2, hif_tr]; rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    by omega, by omega, hpcEnd, hpbEnd⟩
              | whileLoop cond body =>
                  have ec := evalBitCond_trCond inpSim hstage hwf stHull.frameDepth cond
                  rcases h1 : evalBitCond inpHull stHull.frameDepth stHull.words cond with ⟨flag, u, b⟩
                  rcases h2 : evalBitCond inpSim stSim.frameDepth stSim.words (trCond cond) with
                    ⟨flag', u', b'⟩
                  have h2m : evalBitCond inpSim stHull.frameDepth (mergeStore wsBase stHull.words) (trCond cond) = (flag', u', b') := by
                    rwa [← hws, ← hfd]
                  simp only [h1, h2m] at ec
                  rcases ec with ⟨heq₁, hu, hb⟩; rw [heq₁] at h2
                  simp only [runBitRAMFuel, h1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono fuel _ _ outHull hrun
                  dsimp only at hmu hmb
                  let nextH := if flag then .stmt body :: .stmt (.whileLoop cond body) :: rest else rest
                  let stHull' := { stHull with unitCost := stHull.unitCost + u, bitCost := stHull.bitCost + b }
                  let stSim' := { stSim with unitCost := stSim.unitCost + u', bitCost := stSim.bitCost + b' }
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih nextH stHull' stSim' outHull hwf hbitsH hws hfd hbitsS hpcH hpbH hrun
                  dsimp only [stHull', stSim'] at huEnd hbEnd hpcEnd hpbEnd
                  have hend_eq : endDepth nextH stHull.frameDepth = endDepth (.stmt (.whileLoop cond body) :: rest) stHull.frameDepth := by
                    dsimp [nextH]; cases flag <;> rfl
                  rw [hend_eq] at hfdEnd
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => by
                      cases flag <;> (simp only [nextH, List.map, List.cons_append, trCont, trStmt, runBitRAMFuel, h2]; rfl)) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    by omega, by omega, hpcEnd, hpbEnd⟩
              | repeatN countE body =>
                  have e1 := evalIntExpr_trExpr inpSim hstage hwf stHull.frameDepth countE
                  rcases h1 : evalIntExpr inpHull stHull.frameDepth stHull.words countE with ⟨cnt, u, b⟩
                  rcases h2 : evalIntExpr inpSim stSim.frameDepth stSim.words (trExpr countE) with
                    ⟨cnt', u', b'⟩
                  have h2m : evalIntExpr inpSim stHull.frameDepth (mergeStore wsBase stHull.words) (trExpr countE) = (cnt', u', b') := by
                    rwa [← hws, ← hfd]
                  simp only [h1, h2m] at e1
                  rcases e1 with ⟨heq₁, hu, hb⟩; rw [heq₁] at h2
                  simp only [runBitRAMFuel, h1] at hrun
                  obtain ⟨hmu, hmb, _, _⟩ := runBitRAMFuel_cost_mono fuel _ _ outHull hrun
                  dsimp only at hmu hmb
                  let nIter := if 0 ≤ cnt then cnt.toNat else 0
                  let stHull' := { stHull with unitCost := stHull.unitCost + u, bitCost := stHull.bitCost + b }
                  let stSim' := { stSim with unitCost := stSim.unitCost + u', bitCost := stSim.bitCost + b' }
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih (.repeatLoop nIter body :: rest) stHull' stSim' outHull
                      hwf hbitsH hws hfd hbitsS hpcH hpbH hrun
                  dsimp only [stHull', stSim'] at huEnd hbEnd hpcEnd hpbEnd
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => by simp only [List.map, List.cons_append, trCont, trStmt, runBitRAMFuel, h2]; rfl) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    by omega, by omega, hpcEnd, hpbEnd⟩
              | localScope body =>
                  simp only [runBitRAMFuel] at hrun
                  let prev := stHull.frameDepth
                  let stHull' : BitRAMExecState :=
                    { stHull with words := stHull.words.popDepth prev, frameDepth := prev + 1 }
                  let stSim' : BitRAMExecState :=
                    { stSim with words := stSim.words.popDepth stSim.frameDepth, frameDepth := stSim.frameDepth + 1 }
                  have hwf' : WellFormedWS stHull'.words := wellFormedWS_popDepth hwf prev
                  have hws' : stSim'.words = mergeStore wsBase stHull'.words := by
                    dsimp [stSim', stHull', prev]
                    rw [hfd, hws, mergeStore_popDepth hstage.1]
                  have hfd' : stSim'.frameDepth = stHull'.frameDepth := by
                    dsimp [stSim', stHull', prev]; rw [hfd]
                  have hpcH' : inpHull.inputCellSpace + stHull'.words.cellCount ≤ stHull'.peakCellSpace := by
                    have := cellCount_popDepth_le stHull.words prev
                    dsimp [stHull']
                    omega
                  have hpbH' : inpHull.inputBitSpace + stHull'.words.bitSize ≤ stHull'.peakBitSpace := by
                    have := bitSize_popDepth_le stHull.words prev
                    dsimp [stHull']
                    omega
                  obtain ⟨wsEnd, stEnd, hruns, hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩ :=
                    ih (.stmt body :: .popScope prev :: rest) stHull' stSim' outHull
                      hwf' hbitsH hws' hfd' hbitsS hpcH' hpbH' hrun
                  refine ⟨wsEnd, stEnd,
                    step_RunsTo (fun r k => by simp only [List.map, List.cons_append, trCont, trStmt, runBitRAMFuel]; dsimp only [stSim', prev]; rw [← hfd]) hruns,
                    hwfEnd, hpop, hwsEnd, hfdEnd, hbitsEnd, hccEnd, hbsEnd,
                    huEnd, hbEnd, hpcEnd, hpbEnd⟩

end UL.Proof_lem_A_1
