import Mathlib
import UL.Def.def_computation_model
import UL.Proof.lem_A_1.H1_Params
import UL.Proof.lem_A_1.H2_GeomProb
import UL.Proof.lem_A_1.H3a_Sim
set_option autoImplicit false

namespace UL.Proof_lem_A_1

/-! ### 1. `WordStore` write/read/size algebra -/

theorem wordStore_read_write_self (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) :
    (ws.write loc v).read loc = v := by
  simp [WordStore.write, WordStore.read]

theorem wordStore_read_write_of_ne (ws : WordStore) {loc₁ loc₂ : RAMCellLoc}
    (hne : loc₁ ≠ loc₂) (v : ℤ) :
    (ws.write loc₂ v).read loc₁ = ws.read loc₁ := by
  simp [WordStore.write, WordStore.read, hne]

theorem wordStore_write_comm (ws : WordStore) {loc₁ loc₂ : RAMCellLoc}
    (hne : loc₁ ≠ loc₂) (v₁ v₂ : ℤ) :
    (ws.write loc₁ v₁).write loc₂ v₂ = (ws.write loc₂ v₂).write loc₁ v₁ := by
  unfold WordStore.write
  congr 1
  · ext l
    simp [or_left_comm]
  · exact Function.update_comm hne v₁ v₂ ws.vals

theorem wordStore_write_overwrite (ws : WordStore) (loc : RAMCellLoc) (v₁ v₂ : ℤ) :
    (ws.write loc v₁).write loc v₂ = ws.write loc v₂ := by
  unfold WordStore.write
  congr 1
  · simp
  · funext l
    by_cases h : l = loc <;> simp [Function.update, h]

theorem wordStore_cellCount_write_le (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) :
    (ws.write loc v).cellCount ≤ ws.cellCount + 1 :=
  Finset.card_insert_le loc ws.live

theorem wordStore_bitSize_write_le (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) :
    (ws.write loc v).bitSize ≤ ws.bitSize + loc.bitLength + intBitLength v := by
  unfold WordStore.bitSize WordStore.write
  by_cases hmem : loc ∈ ws.live
  · have hins : insert loc ws.live = ws.live := Finset.insert_eq_of_mem hmem
    rw [hins, ← Finset.insert_erase hmem,
      Finset.sum_insert (Finset.notMem_erase loc ws.live),
      Finset.sum_insert (Finset.notMem_erase loc ws.live)]
    simp only [Function.update_self]
    have hrest :
        ∑ x ∈ ws.live.erase loc, (x.bitLength + intBitLength (Function.update ws.vals loc v x)) =
          ∑ x ∈ ws.live.erase loc, (x.bitLength + intBitLength (ws.vals x)) := by
      refine Finset.sum_congr rfl fun x hx => ?_
      rw [Function.update_of_ne (Finset.ne_of_mem_erase hx)]
    rw [hrest]
    omega
  · rw [Finset.sum_insert hmem]
    simp only [Function.update_self]
    have hrest :
        ∑ x ∈ ws.live, (x.bitLength + intBitLength (Function.update ws.vals loc v x)) =
          ∑ x ∈ ws.live, (x.bitLength + intBitLength (ws.vals x)) := by
      refine Finset.sum_congr rfl fun x hx => ?_
      have hne : x ≠ loc := fun heq => hmem (heq ▸ hx)
      rw [Function.update_of_ne hne]
    rw [hrest]
    omega

theorem isBaseStore_empty : IsBaseStore WordStore.empty :=
  ⟨wellFormedWS_empty, fun _ h => by simp [WordStore.empty] at h⟩

theorem isBaseStore_write {ws : WordStore} (h : IsBaseStore ws)
    {t : ℕ} (ht : t < 10) (idx v : ℤ) :
    IsBaseStore (ws.write (.heap t idx) v) := by
  refine ⟨wellFormedWS_write h.1 _ v, fun l hl => ?_⟩
  rcases Finset.mem_insert.mp hl with rfl | hmem
  · exact ⟨t, idx, ht, rfl⟩
  · exact h.2 l hmem

theorem popDepth_zero_of_isBaseStore {ws : WordStore} (h : IsBaseStore ws) :
    ws.popDepth 0 = ws := by
  cases ws with
  | mk live vals =>
    unfold WordStore.popDepth
    congr 1
    · ext l
      simp only [Finset.mem_filter, and_iff_left_iff_imp]
      intro hl
      rcases h.2 l hl with ⟨t, idx, _, rfl⟩
      rfl
    · funext l
      cases l with
      | heap t idx => simp [RAMCellLoc.keepAtDepth]
      | localFrame d v idx =>
          dsimp only
          split_ifs with hk
          · rfl
          · symm
            apply h.1 (.localFrame d v idx)
            intro hmem
            rcases h.2 _ hmem with ⟨t, i, _, heq⟩
            cases heq

theorem popDepth_zero_write_local1_of_isBaseStore {ws : WordStore} (h : IsBaseStore ws)
    (var : ℕ) (idx v : ℤ) :
    (ws.write (.localFrame 1 var idx) v).popDepth 0 = ws := by
  have hkeep_false : (RAMCellLoc.localFrame 1 var idx).keepAtDepth 0 = false := rfl
  cases ws with
  | mk live vals =>
    unfold WordStore.write WordStore.popDepth
    congr 1
    · ext l
      simp only [Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨rfl | hl, hk⟩
        · rw [hkeep_false] at hk; cases hk
        · exact hl
      · intro hl
        rcases h.2 l hl with ⟨t, i, _, rfl⟩
        exact ⟨Or.inr hl, rfl⟩
    · funext l
      by_cases heq : l = .localFrame 1 var idx
      · subst heq
        simp only [hkeep_false, Bool.false_eq_true, ↓reduceIte]
        symm
        apply h.1 (.localFrame 1 var idx)
        intro hmem
        rcases h.2 _ hmem with ⟨t, i, _, hc⟩
        cases hc
      · simp only [Function.update_of_ne heq]
        cases l with
        | heap t i => simp [RAMCellLoc.keepAtDepth]
        | localFrame d u i =>
            split_ifs with hk
            · rfl
            · symm
              apply h.1 (.localFrame d u i)
              intro hmem
              rcases h.2 _ hmem with ⟨t, i', _, hc⟩
              cases hc

/-! ### 2. Polynomial integer expressions (`sExpr`, `rExpr`, `mExpr`) and `sizeProg` -/

def EvalNonnegBounded {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (e : IntExpr) (val U L : ℕ) : Prop :=
  let (v, u, b) := evalIntExpr inp fd ws e
  v = (val : ℤ) ∧ u ≤ U ∧ b ≤ L

theorem EvalNonnegBounded.mono {d : ℕ} {inp : BitRAMInput d} {fd : ℕ} {ws : WordStore}
    {e e' : IntExpr} {val val' U U' L L' : ℕ}
    (h : EvalNonnegBounded inp fd ws e val U L)
    (he : e = e') (hv : val = val') (hU : U ≤ U') (hL : L ≤ L') :
    EvalNonnegBounded inp fd ws e' val' U' L' := by
  subst he hv
  rcases eq : evalIntExpr inp fd ws e with ⟨v, u, b⟩
  simp only [EvalNonnegBounded, eq] at h ⊢
  exact ⟨h.1, h.2.1.trans hU, h.2.2.trans hL⟩

theorem EvalNonnegBounded.lit {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    (n M : ℕ) (hn : n ≤ M) :
    EvalNonnegBounded inp fd ws (.lit (n : ℤ)) n 1 ((M + 2) ^ 2) := by
  simp only [EvalNonnegBounded, evalIntExpr]
  have hb := intBitLength_le_natAbs (n : ℤ)
  simp only [Int.natAbs_natCast] at hb
  have hsq : M + 2 ≤ (M + 2) ^ 2 := Nat.le_self_pow (by omega) _
  exact ⟨by simp, by simp, by omega⟩

theorem EvalNonnegBounded.add_le {d : ℕ} {inp : BitRAMInput d} {fd : ℕ} {ws : WordStore}
    {e₁ e₂ : IntExpr} {n₁ n₂ U₁ U₂ L₁ L₂ M : ℕ}
    (h₁ : EvalNonnegBounded inp fd ws e₁ n₁ U₁ L₁)
    (h₂ : EvalNonnegBounded inp fd ws e₂ n₂ U₂ L₂)
    (hn₁ : n₁ ≤ M) (hn₂ : n₂ ≤ M) :
    EvalNonnegBounded inp fd ws (.add e₁ e₂) (n₁ + n₂) (U₁ + U₂ + 1)
      (L₁ + L₂ + 2 * (M + 2) ^ 2) := by
  rcases eq1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
  rcases eq2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
  simp only [EvalNonnegBounded, eq1] at h₁
  simp only [EvalNonnegBounded, eq2] at h₂
  rcases h₁ with ⟨rfl, hu₁, hb₁⟩
  rcases h₂ with ⟨rfl, hu₂, hb₂⟩
  simp only [EvalNonnegBounded, evalIntExpr, eq1, eq2]
  have hbl₁ := intBitLength_le_natAbs (n₁ : ℤ)
  have hbl₂ := intBitLength_le_natAbs (n₂ : ℤ)
  simp only [Int.natAbs_natCast] at hbl₁ hbl₂
  have hsq : M + 2 ≤ (M + 2) ^ 2 := Nat.le_self_pow (by omega) _
  refine ⟨by push_cast; ring, by omega, by omega⟩

theorem EvalNonnegBounded.mul_le {d : ℕ} {inp : BitRAMInput d} {fd : ℕ} {ws : WordStore}
    {e₁ e₂ : IntExpr} {n₁ n₂ U₁ U₂ L₁ L₂ M : ℕ}
    (h₁ : EvalNonnegBounded inp fd ws e₁ n₁ U₁ L₁)
    (h₂ : EvalNonnegBounded inp fd ws e₂ n₂ U₂ L₂)
    (hn₁ : n₁ ≤ M) (hn₂ : n₂ ≤ M) :
    EvalNonnegBounded inp fd ws (.mul e₁ e₂) (n₁ * n₂) (U₁ + U₂ + 1)
      (L₁ + L₂ + (M + 2) ^ 2) := by
  rcases eq1 : evalIntExpr inp fd ws e₁ with ⟨v₁, u₁, b₁⟩
  rcases eq2 : evalIntExpr inp fd ws e₂ with ⟨v₂, u₂, b₂⟩
  simp only [EvalNonnegBounded, eq1] at h₁
  simp only [EvalNonnegBounded, eq2] at h₂
  rcases h₁ with ⟨rfl, hu₁, hb₁⟩
  rcases h₂ with ⟨rfl, hu₂, hb₂⟩
  simp only [EvalNonnegBounded, evalIntExpr, eq1, eq2]
  have hbl₁ : intBitLength (n₁ : ℤ) ≤ M + 2 := by
    have := intBitLength_le_natAbs (n₁ : ℤ)
    simp only [Int.natAbs_natCast] at this
    omega
  have hbl₂ : intBitLength (n₂ : ℤ) ≤ M + 2 := by
    have := intBitLength_le_natAbs (n₂ : ℤ)
    simp only [Int.natAbs_natCast] at this
    omega
  have hmul : intBitLength (n₁ : ℤ) * intBitLength (n₂ : ℤ) ≤ (M + 2) ^ 2 := by
    calc
      intBitLength (n₁ : ℤ) * intBitLength (n₂ : ℤ) ≤ (M + 2) * (M + 2) := Nat.mul_le_mul hbl₁ hbl₂
      _ = (M + 2) ^ 2 := (sq (M + 2)).symm
  refine ⟨by push_cast; ring, by omega, by omega⟩

def dPlus1E (dE : IntExpr) : IntExpr := .add dE (.lit 1)
def kPlus1E (kE : IntExpr) : IntExpr := .add kE (.lit 1)

def sExpr (K : ℕ) (dE kE : IntExpr) : IntExpr :=
  .mul (.mul (.lit ((64 * K ^ 2 : ℕ) : ℤ))
    (.mul (.mul (dPlus1E dE) (dPlus1E dE)) (dPlus1E dE)))
    (kPlus1E kE)

def rExpr (K : ℕ) (dE kE : IntExpr) : IntExpr :=
  let sE := sExpr K dE kE
  .mul (.mul (.mul (.lit ((2 * K : ℕ) : ℤ)) (dPlus1E dE)) (.mul sE sE)) (kPlus1E kE)

def mExpr (K : ℕ) (dE kE : IntExpr) : IntExpr :=
  .mul (rExpr K dE kE) (sExpr K dE kE)

theorem subterms_le_mVal {K D k : ℕ} (hK : 1 ≤ K) :
    let s := sVal K D k
    let r := rVal K D k
    let M := mVal K D k
    1 ≤ M ∧ D ≤ M ∧ k ≤ M ∧ D + 1 ≤ M ∧ k + 1 ≤ M ∧
    (D + 1) ^ 2 ≤ M ∧ (D + 1) ^ 3 ≤ M ∧
    64 * K ^ 2 ≤ M ∧ 64 * K ^ 2 * (D + 1) ^ 3 ≤ M ∧
    s ≤ M ∧ r ≤ M ∧ 2 * K ≤ M ∧ 2 * K * (D + 1) ≤ M ∧
    s ^ 2 ≤ M ∧ 2 * K * (D + 1) * s ^ 2 ≤ M := by
  intro s r M
  have hs_pos : 1 ≤ s := sVal_pos hK
  have hr_pos : 1 ≤ r := rVal_pos hK
  have hs_le_M : s ≤ M := Nat.le_mul_of_pos_left s hr_pos
  have hr_le_M : r ≤ M := Nat.le_mul_of_pos_right r hs_pos
  have hK2 : 1 ≤ K ^ 2 := Nat.one_le_pow 2 K hK
  have hD1 : 1 ≤ D + 1 := by omega
  have hk1 : 1 ≤ k + 1 := by omega
  have hD3 : 1 ≤ (D + 1) ^ 3 := Nat.one_le_pow 3 (D + 1) hD1
  have h64K_s : 64 * K ^ 2 * (D + 1) ^ 3 ≤ s := Nat.le_mul_of_pos_right _ hk1
  have h64K : 64 * K ^ 2 ≤ 64 * K ^ 2 * (D + 1) ^ 3 := Nat.le_mul_of_pos_right _ hD3
  have hD3_s : (D + 1) ^ 3 ≤ 64 * K ^ 2 * (D + 1) ^ 3 :=
    Nat.le_mul_of_pos_left _ (by positivity)
  have hD2_D3 : (D + 1) ^ 2 ≤ (D + 1) ^ 3 := by
    calc
      (D + 1) ^ 2 = (D + 1) ^ 2 * 1 := (Nat.mul_one _).symm
      _ ≤ (D + 1) ^ 2 * (D + 1) := Nat.mul_le_mul_left _ hD1
      _ = (D + 1) ^ 3 := by ring
  have hD1_D2 : D + 1 ≤ (D + 1) ^ 2 := Nat.le_self_pow (by omega) _
  have hk1_s : k + 1 ≤ s :=
    Nat.le_mul_of_pos_left _ (by positivity : 0 < 64 * K ^ 2 * (D + 1) ^ 3)
  have h2KDs2_r : 2 * K * (D + 1) * s ^ 2 ≤ r := Nat.le_mul_of_pos_right _ hk1
  have hs2_r : s ^ 2 ≤ 2 * K * (D + 1) * s ^ 2 :=
    Nat.le_mul_of_pos_left _ (by positivity)
  have h2KD_r : 2 * K * (D + 1) ≤ 2 * K * (D + 1) * s ^ 2 :=
    Nat.le_mul_of_pos_right _ (Nat.one_le_pow 2 s hs_pos)
  have h2K_2KD : 2 * K ≤ 2 * K * (D + 1) := Nat.le_mul_of_pos_right _ hD1
  refine ⟨mVal_pos hK, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hs_le_M, hr_le_M, ?_, ?_, ?_, ?_⟩
  · exact (Nat.le_succ D).trans (hD1_D2.trans (hD2_D3.trans (hD3_s.trans (h64K_s.trans hs_le_M))))
  · exact (Nat.le_succ k).trans (hk1_s.trans hs_le_M)
  · exact hD1_D2.trans (hD2_D3.trans (hD3_s.trans (h64K_s.trans hs_le_M)))
  · exact hk1_s.trans hs_le_M
  · exact hD2_D3.trans (hD3_s.trans (h64K_s.trans hs_le_M))
  · exact hD3_s.trans (h64K_s.trans hs_le_M)
  · exact h64K.trans (h64K_s.trans hs_le_M)
  · exact h64K_s.trans hs_le_M
  · exact h2K_2KD.trans (h2KD_r.trans (h2KDs2_r.trans hr_le_M))
  · exact h2KD_r.trans (h2KDs2_r.trans hr_le_M)
  · exact hs2_r.trans (h2KDs2_r.trans hr_le_M)
  · exact h2KDs2_r.trans hr_le_M

theorem eval_srmExpr {d : ℕ} (inp : BitRAMInput d) (fd : ℕ) (ws : WordStore)
    {K D k : ℕ} (hK : 1 ≤ K) {dE kE : IntExpr}
    (hdE : EvalNonnegBounded inp fd ws dE D 3 (2 * (mVal K D k + 2) ^ 2))
    (hkE : EvalNonnegBounded inp fd ws kE k 3 (2 * (mVal K D k + 2) ^ 2)) :
    let M := mVal K D k
    EvalNonnegBounded inp fd ws (sExpr K dE kE) (sVal K D k) 50 (50 * (M + 2) ^ 2) ∧
    EvalNonnegBounded inp fd ws (rExpr K dE kE) (rVal K D k) 150 (150 * (M + 2) ^ 2) ∧
    EvalNonnegBounded inp fd ws (mExpr K dE kE) M 250 (250 * (M + 2) ^ 2) := by
  generalize hM_eq : mVal K D k = M at hdE hkE ⊢
  have hsub := subterms_le_mVal (D := D) (k := k) hK
  dsimp only at hsub
  rw [hM_eq] at hsub
  rcases hsub with ⟨h1M, hDM, hkM, hD1M, hk1M, hD2M, hD3M, h64KM, h64KDM,
    hsM, hrM, h2KM, h2KDM, hs2M, h2KDs2M⟩
  have hd1 := EvalNonnegBounded.add_le hdE (EvalNonnegBounded.lit inp fd ws 1 M h1M) hDM h1M
  have hk1 := EvalNonnegBounded.add_le hkE (EvalNonnegBounded.lit inp fd ws 1 M h1M) hkM h1M
  have hd2 := EvalNonnegBounded.mul_le hd1 hd1 hD1M hD1M
  rw [← sq] at hd2
  have hd3 := EvalNonnegBounded.mul_le hd2 hd1 hD2M hD1M
  have hpow3 : (D + 1) ^ 2 * (D + 1) = (D + 1) ^ 3 := by ring
  rw [hpow3] at hd3
  have hc64 := EvalNonnegBounded.lit inp fd ws (64 * K ^ 2) M h64KM
  have hs_part := EvalNonnegBounded.mul_le hc64 hd3 h64KM hD3M
  have hs_raw := EvalNonnegBounded.mul_le hs_part hk1 h64KDM hk1M
  have hs_bdd : EvalNonnegBounded inp fd ws (sExpr K dE kE) (sVal K D k) 50 (50 * (M + 2) ^ 2) :=
    hs_raw.mono rfl rfl (by omega) (by omega)
  have hs_sq := EvalNonnegBounded.mul_le hs_bdd hs_bdd hsM hsM
  rw [← sq] at hs_sq
  have hc2K := EvalNonnegBounded.lit inp fd ws (2 * K) M h2KM
  have hr_p1 := EvalNonnegBounded.mul_le hc2K hd1 h2KM hD1M
  have hr_p2 := EvalNonnegBounded.mul_le hr_p1 hs_sq h2KDM hs2M
  have hr_raw := EvalNonnegBounded.mul_le hr_p2 hk1 h2KDs2M hk1M
  have hr_bdd : EvalNonnegBounded inp fd ws (rExpr K dE kE) (rVal K D k) 150 (150 * (M + 2) ^ 2) :=
    hr_raw.mono rfl rfl (by omega) (by omega)
  have hm_raw := EvalNonnegBounded.mul_le hr_bdd hs_bdd hrM hsM
  have hm_bdd : EvalNonnegBounded inp fd ws (mExpr K dE kE) M 250 (250 * (M + 2) ^ 2) :=
    hm_raw.mono rfl hM_eq (by omega) (by omega)
  exact ⟨hs_bdd, hr_bdd, hm_bdd⟩

def sizeProg (K : ℕ) : BitRAMStmt :=
  .writeHeap 0 (.lit 0) (mExpr K (.intParam (.lit 0)) (.intParam (.lit 2)))

theorem sizeProg_spec {K D B k : ℕ} (hK : 1 ≤ K) :
    let M := mVal K D k
    ∃ sizeOut : BitRAMExecOutcome,
      runBitRAMWithBits (sizeProg K)
        (BitRAMInput.ofIntParams [(D : ℤ), (B : ℤ), (k : ℤ)])
        WordStore.empty [] = some sizeOut ∧
      sizeOut.words.read (.heap 0 0) = (M : ℤ) ∧
      sizeOut.unitCost ≤ 300 ∧
      sizeOut.bitCost ≤ 300 * (M + B + 10) ^ 2 ∧
      sizeOut.peakCellSpace ≤ 300 ∧
      sizeOut.peakBitSpace ≤ 300 * (M + B + 10) ^ 2 := by
  dsimp only
  generalize hM_eq : mVal K D k = M
  set inp := BitRAMInput.ofIntParams [(D : ℤ), (B : ℤ), (k : ℤ)] with hinp_def
  have hsub := subterms_le_mVal (D := D) (k := k) hK
  dsimp only at hsub
  rw [hM_eq] at hsub
  have h1M : 1 ≤ M := hsub.1
  have hDM : D ≤ M := hsub.2.1
  have hkM : k ≤ M := hsub.2.2.1
  have h3sqM : 3 * (M + 2) ≤ (M + 2) ^ 2 := by
    calc
      3 * (M + 2) ≤ (M + 2) * (M + 2) := Nat.mul_le_mul_right _ (by omega)
      _ = (M + 2) ^ 2 := (sq (M + 2)).symm
  have hdE : EvalNonnegBounded inp 0 WordStore.empty (.intParam (.lit 0)) D 3 (2 * (M + 2) ^ 2) := by
    simp only [EvalNonnegBounded, evalIntExpr, hinp_def, BitRAMInput.ofIntParams, listGetIntD]
    have hbD := intBitLength_le_natAbs (D : ℤ)
    simp only [Int.natAbs_natCast] at hbD
    have hb0 : intBitLength 0 = 1 := rfl
    simp only [le_refl, ↓reduceIte, Int.toNat_zero, List.getD_cons_zero, hb0]
    exact ⟨by simp, by omega, by omega⟩
  have hkE : EvalNonnegBounded inp 0 WordStore.empty (.intParam (.lit 2)) k 3 (2 * (M + 2) ^ 2) := by
    simp only [EvalNonnegBounded, evalIntExpr, hinp_def, BitRAMInput.ofIntParams, listGetIntD]
    have hbk := intBitLength_le_natAbs (k : ℤ)
    simp only [Int.natAbs_natCast] at hbk
    have hb2 : intBitLength 2 = 3 := by decide
    have h2ge : (0 : ℤ) ≤ 2 := by omega
    have hget2 : [(D : ℤ), (B : ℤ), (k : ℤ)].getD (2 : ℤ).toNat 0 = (k : ℤ) := rfl
    simp only [h2ge, ↓reduceIte, hb2, hget2]
    exact ⟨by simp, by omega, by omega⟩
  have hmE : EvalNonnegBounded inp 0 WordStore.empty
      (mExpr K (.intParam (.lit 0)) (.intParam (.lit 2))) M 250 (250 * (M + 2) ^ 2) := by
    rw [← hM_eq] at hdE hkE ⊢
    exact (eval_srmExpr inp 0 WordStore.empty hK hdE hkE).2.2
  have hpop0 : WordStore.empty.popDepth 0 = WordStore.empty := popDepth_zero_of_isBaseStore isBaseStore_empty
  let initSt : BitRAMExecState :=
    { words := WordStore.empty.popDepth 0
      frameDepth := 0
      remainingBits := []
      unitCost := 0
      bitCost := 0
      peakCellSpace := inp.inputCellSpace + (WordStore.empty.popDepth 0).cellCount
      peakBitSpace := inp.inputBitSpace + (WordStore.empty.popDepth 0).bitSize }
  have hstep := RunsTo.writeHeap inp 0 (.lit 0)
    (mExpr K (.intParam (.lit 0)) (.intParam (.lit 2))) initSt
  dsimp only [initSt] at hstep
  rcases eqm : evalIntExpr inp 0 WordStore.empty
    (mExpr K (.intParam (.lit 0)) (.intParam (.lit 2))) with ⟨vm, um, bm⟩
  simp only [EvalNonnegBounded, eqm] at hmE
  rcases hmE with ⟨rfl, hum, hbm⟩
  have eqm' : evalIntExpr inp 0 (WordStore.empty.popDepth 0)
      (mExpr K (.intParam (.lit 0)) (.intParam (.lit 2))) = ((M : ℤ), um, bm) := by
    rwa [hpop0]
  have he0 : evalIntExpr inp 0 (WordStore.empty.popDepth 0) (.lit 0) = (0, 1, 1) := rfl
  rw [he0, eqm'] at hstep
  have hout := RunsTo.toRunBitRAMWithBits (prog := sizeProg K) (inp := inp)
    (initWords := WordStore.empty) (bs := []) hstep rfl
  refine ⟨_, hout, ?_, ?_, ?_, ?_, ?_⟩
  · change (((WordStore.empty.popDepth 0).write (.heap 0 0) (M : ℤ)).popDepth 0).read (.heap 0 0) = (M : ℤ)
    rw [hpop0]
    have hbase1 : IsBaseStore (WordStore.empty.write (.heap 0 0) (M : ℤ)) :=
      isBaseStore_write isBaseStore_empty (by omega) 0 (M : ℤ)
    rw [popDepth_zero_of_isBaseStore hbase1, wordStore_read_write_self]
  · change 0 + 1 + um + 1 ≤ 300
    omega
  · change 0 + 1 + bm + (RAMCellLoc.heap 0 0).bitLength + intBitLength (M : ℤ) ≤ 300 * (M + B + 10) ^ 2
    have hloc : (RAMCellLoc.heap 0 0).bitLength = 2 := rfl
    have hbM := intBitLength_le_natAbs (M : ℤ)
    simp only [Int.natAbs_natCast] at hbM
    have hMB : (M + 2) ^ 2 ≤ (M + B + 10) ^ 2 := Nat.pow_le_pow_left (by omega) 2
    have hMB1 : M + B + 10 ≤ (M + B + 10) ^ 2 := Nat.le_self_pow (by omega) _
    rw [hloc]
    omega
  · change max (inp.inputCellSpace + (WordStore.empty.popDepth 0).cellCount)
      (inp.inputCellSpace + ((WordStore.empty.popDepth 0).write (.heap 0 0) (M : ℤ)).cellCount) ≤ 300
    have hcc_emp : WordStore.empty.cellCount = 0 := rfl
    have hcc1 := wordStore_cellCount_write_le WordStore.empty (.heap 0 0) (M : ℤ)
    have hic : inp.inputCellSpace = 3 := by
      simp [hinp_def, BitRAMInput.ofIntParams, BitRAMInput.inputCellSpace]
    rw [hpop0, hic, hcc_emp] at *
    omega
  · change max (inp.inputBitSpace + (WordStore.empty.popDepth 0).bitSize)
      (inp.inputBitSpace + ((WordStore.empty.popDepth 0).write (.heap 0 0) (M : ℤ)).bitSize) ≤
        300 * (M + B + 10) ^ 2
    have hbs_emp : WordStore.empty.bitSize = 0 := by simp [WordStore.bitSize, WordStore.empty]
    have hbs1 := wordStore_bitSize_write_le WordStore.empty (.heap 0 0) (M : ℤ)
    have hloc : (RAMCellLoc.heap 0 0).bitLength = 2 := rfl
    have hbD := intBitLength_le_natAbs (D : ℤ)
    have hbB := intBitLength_le_natAbs (B : ℤ)
    have hbk := intBitLength_le_natAbs (k : ℤ)
    have hbM := intBitLength_le_natAbs (M : ℤ)
    simp only [Int.natAbs_natCast] at hbD hbB hbk hbM
    have hib : inp.inputBitSpace ≤ D + B + k + 6 := by
      simp only [hinp_def, BitRAMInput.ofIntParams, BitRAMInput.inputBitSpace, List.map, List.sum_cons,
        List.sum_nil, Finset.sum_empty]
      omega
    have hMB1 : M + B + 10 ≤ (M + B + 10) ^ 2 := Nat.le_self_pow (by omega) _
    rw [hpop0]; rw [hbs_emp, hloc] at hbs1
    omega

/-! ### 3. `flatPts` flat indexing identity -/

private theorem flatMap_fixed_len {β α : Type*} (k : ℕ) (hk : 1 ≤ k) (f : β → List α) :
    ∀ (xs : List β),
      (∀ x ∈ xs, (f x).length = k) →
      (xs.flatMap f).length = xs.length * k ∧
      ∀ (t : ℕ) (ht : t < xs.length * k),
        (xs.flatMap f)[t]? =
          (f (xs[t / k]'((Nat.div_lt_iff_lt_mul hk).mpr ht)))[t % k]?
  | [], _ => ⟨by simp, fun _ ht => by simp at ht⟩
  | x :: xs, hlen => by
      have hx : (f x).length = k := hlen x (List.mem_cons_self ..)
      obtain ⟨ih_len, ih_get⟩ :=
        flatMap_fixed_len k hk f xs (fun y hy => hlen y (List.mem_cons_of_mem x hy))
      refine ⟨by simp [List.flatMap_cons, hx, ih_len]; ring, fun t ht => ?_⟩
      simp only [List.flatMap_cons]
      by_cases htk : t < k
      · rw [List.getElem?_append_left (by omega)]
        have hdiv : t / k = 0 := Nat.div_eq_of_lt htk
        have hmod : t % k = t := Nat.mod_eq_of_lt htk
        simp [hdiv, hmod]
      · rw [List.getElem?_append_right (by omega)]
        rw [hx]
        have hu : t - k < xs.length * k := by
          simp only [List.length_cons] at ht
          have : xs.length * k + k = (xs.length + 1) * k := by ring
          omega
        rw [ih_get (t - k) hu]
        have ht_eq : t = (t - k) + k * 1 := by omega
        have hdiv : t / k = (t - k) / k + 1 := by
          conv_lhs => rw [ht_eq]
          exact Nat.add_mul_div_left (t - k) 1 hk
        have hmod : t % k = (t - k) % k := by
          conv_lhs => rw [ht_eq]
          exact Nat.add_mul_mod_self_left (t - k) k 1
        simp [hdiv, hmod]

theorem flatPts_listGetIntD {D r s : ℕ} (hD : 1 ≤ D) (hs : 1 ≤ s)
    {ι : Type*} (P : ι → Fin D → ℚ) (ω : Fin (r * s) → ι) (idx : ℤ) :
    let pts : Fin r → Fin s → Fin D → ℚ := fun i j => P (ω (blockIdx i j))
    let flatPts : List ℚ :=
      (List.finRange r).flatMap (fun i =>
        (List.finRange s).flatMap (fun j => List.ofFn (pts i j)))
    listGetIntD flatPts idx 0 =
      if h : 0 ≤ idx ∧ idx.toNat < r * s * D then
        P (ω ⟨idx.toNat / D, (Nat.div_lt_iff_lt_mul hD).mpr h.2⟩)
          ⟨idx.toNat % D, Nat.mod_lt idx.toNat hD⟩
      else
        0 := by
  intro pts flatPts
  have hsD : 1 ≤ s * D := Nat.mul_pos hs hD
  have hinner : ∀ i : Fin r,
      ((List.finRange s).flatMap (fun j => List.ofFn (pts i j))).length = s * D ∧
      ∀ (u : ℕ) (hu : u < s * D),
        ((List.finRange s).flatMap (fun j => List.ofFn (pts i j)))[u]? =
          some (pts i ⟨u / D, (Nat.div_lt_iff_lt_mul hD).mpr hu⟩ ⟨u % D, Nat.mod_lt u hD⟩) := by
    intro i
    obtain ⟨hlen, hget⟩ := flatMap_fixed_len D hD (fun j : Fin s => List.ofFn (pts i j))
      (List.finRange s) (fun j _ => List.length_ofFn)
    refine ⟨by simpa [List.length_finRange] using hlen, fun u hu => ?_⟩
    rw [hget u (by simpa [List.length_finRange] using hu)]
    simp only [List.getElem_finRange, Fin.cast_mk, List.getElem?_ofFn, dif_pos (Nat.mod_lt u hD)]
  obtain ⟨hout_len, hout_get⟩ :=
    flatMap_fixed_len (s * D) hsD (fun i : Fin r => (List.finRange s).flatMap (fun j => List.ofFn (pts i j)))
      (List.finRange r) (fun i _ => (hinner i).1)
  have hlen_eq : flatPts.length = r * s * D := by
    dsimp [flatPts]
    rw [hout_len, List.length_finRange]
    ring
  unfold listGetIntD
  by_cases h0 : 0 ≤ idx
  · by_cases hlt : idx.toNat < r * s * D
    · have hh : 0 ≤ idx ∧ idx.toNat < r * s * D := ⟨h0, hlt⟩
      rw [if_pos h0, dif_pos hh]
      set t := idx.toNat
      have ht_outer : t < r * (s * D) := by linarith
      have hget_some : flatPts[t]? =
          some (P (ω ⟨t / D, (Nat.div_lt_iff_lt_mul hD).mpr hlt⟩)
            ⟨t % D, Nat.mod_lt t hD⟩) := by
        dsimp [flatPts]
        rw [hout_get t (by simpa [List.length_finRange] using ht_outer)]
        simp only [List.getElem_finRange, Fin.cast_mk]
        rw [(hinner ⟨t / (s * D), (Nat.div_lt_iff_lt_mul hsD).mpr ht_outer⟩).2
          (t % (s * D)) (Nat.mod_lt t hsD)]
        dsimp only [pts, blockIdx]
        have hdecomp : t = (t % (s * D)) + D * (s * (t / (s * D))) := by
          have := Nat.div_add_mod t (s * D)
          linarith
        have hidx1 : (⟨(t / (s * D)) * s + (t % (s * D)) / D,
            blockIdx._proof_1 ⟨t / (s * D), (Nat.div_lt_iff_lt_mul hsD).mpr ht_outer⟩
              ⟨(t % (s * D)) / D, (Nat.div_lt_iff_lt_mul hD).mpr (Nat.mod_lt t hsD)⟩⟩ : Fin (r * s)) =
            ⟨t / D, (Nat.div_lt_iff_lt_mul hD).mpr hlt⟩ := by
          ext
          dsimp only
          conv_rhs => rw [hdecomp]
          rw [Nat.add_mul_div_left _ _ hD]
          ring
        have hidx2 : (⟨(t % (s * D)) % D, Nat.mod_lt (t % (s * D)) hD⟩ : Fin D) =
            ⟨t % D, Nat.mod_lt t hD⟩ := by
          ext
          dsimp only
          conv_rhs => rw [hdecomp]
          rw [Nat.add_mul_mod_self_left]
        rw [hidx1, hidx2]
      rw [List.getD_eq_getElem?_getD, hget_some]
      rfl
    · have hh : ¬ (0 ≤ idx ∧ idx.toNat < r * s * D) := fun h => hlt h.2
      rw [if_pos h0, dif_neg hh, List.getD_eq_getElem?_getD, List.getElem?_eq_none (by omega)]
      rfl
  · have hh : ¬ (0 ≤ idx ∧ idx.toNat < r * s * D) := fun h => h0 h.1
    rw [if_neg h0, dif_neg hh]

/-! ### 4. Phase 1 staging program (`phase1Stmt`) and `StagingMatches` proof -/

def wsInit5 (D r s : ℕ) : WordStore :=
  ((WordStore.empty.write (.heap 5 0) (D : ℤ)).write (.heap 5 1) (r : ℤ)).write (.heap 5 2) (s : ℤ)

def stageLoopWS (ws₀ : WordStore) (qAt : ℕ → ℚ) : ℕ → WordStore
  | 0 => ws₀
  | n + 1 =>
      ((stageLoopWS ws₀ qAt n).write (.heap 6 (n : ℤ)) (qAt n).num).write
        (.heap 7 (n : ℤ)) (((qAt n).den : ℤ) - 1)

theorem isBaseStore_wsInit5 (D r s : ℕ) : IsBaseStore (wsInit5 D r s) :=
  isBaseStore_write
    (isBaseStore_write (isBaseStore_write isBaseStore_empty (by omega) 0 _) (by omega) 1 _)
    (by omega) 2 _

theorem isBaseStore_stageLoopWS (D r s : ℕ) (qAt : ℕ → ℚ) :
    ∀ n : ℕ, IsBaseStore (stageLoopWS (wsInit5 D r s) qAt n)
  | 0 => isBaseStore_wsInit5 D r s
  | n + 1 =>
      isBaseStore_write
        (isBaseStore_write (isBaseStore_stageLoopWS D r s qAt n) (by omega) _ _)
        (by omega) _ _

theorem read_heap5_stageLoopWS (D r s : ℕ) (qAt : ℕ → ℚ) :
    ∀ (n : ℕ) (idx : ℤ),
      (stageLoopWS (wsInit5 D r s) qAt n).read (.heap 5 idx) =
        listGetIntD [(D : ℤ), (r : ℤ), (s : ℤ)] idx 0
  | 0, idx => by
      unfold stageLoopWS wsInit5
      by_cases h2 : idx = 2
      · subst h2
        rw [wordStore_read_write_self]
        rfl
      · rw [wordStore_read_write_of_ne _ (by intro h; cases h; exact h2 rfl)]
        by_cases h1 : idx = 1
        · subst h1
          rw [wordStore_read_write_self]
          rfl
        · rw [wordStore_read_write_of_ne _ (by intro h; cases h; exact h1 rfl)]
          by_cases h0 : idx = 0
          · subst h0
            rw [wordStore_read_write_self]
            rfl
          · rw [wordStore_read_write_of_ne _ (by intro h; cases h; exact h0 rfl)]
            have hemp : WordStore.empty.read (.heap 5 idx) = 0 := rfl
            rw [hemp]
            unfold listGetIntD
            by_cases hge0 : 0 ≤ idx
            · rw [if_pos hge0]
              rw [List.getD_eq_getElem?_getD, List.getElem?_eq_none (by simp; omega)]
              rfl
            · rw [if_neg hge0]
  | n + 1, idx => by
      simp only [stageLoopWS]
      rw [wordStore_read_write_of_ne _ (by simp),
        wordStore_read_write_of_ne _ (by simp)]
      exact read_heap5_stageLoopWS D r s qAt n idx

theorem read_heap67_stageLoopWS (D r s : ℕ) (qAt : ℕ → ℚ) :
    ∀ (n : ℕ) (idx : ℤ),
      (stageLoopWS (wsInit5 D r s) qAt n).read (.heap 6 idx) =
        (if 0 ≤ idx ∧ idx < (n : ℤ) then (qAt idx.toNat).num else 0) ∧
      (stageLoopWS (wsInit5 D r s) qAt n).read (.heap 7 idx) =
        (if 0 ≤ idx ∧ idx < (n : ℤ) then ((qAt idx.toNat).den : ℤ) - 1 else 0)
  | 0, idx => by
      have hcond : ¬ (0 ≤ idx ∧ idx < (0 : ℤ)) := by omega
      simp only [Nat.cast_zero, hcond, ↓reduceIte, stageLoopWS, wsInit5]
      constructor
      · rw [wordStore_read_write_of_ne _ (by simp),
          wordStore_read_write_of_ne _ (by simp),
          wordStore_read_write_of_ne _ (by simp)]
        rfl
      · rw [wordStore_read_write_of_ne _ (by simp),
          wordStore_read_write_of_ne _ (by simp),
          wordStore_read_write_of_ne _ (by simp)]
        rfl
  | n + 1, idx => by
      obtain ⟨ih6, ih7⟩ := read_heap67_stageLoopWS D r s qAt n idx
      simp only [stageLoopWS]
      by_cases heq : idx = (n : ℤ)
      · subst heq
        have hcond : 0 ≤ (n : ℤ) ∧ (n : ℤ) < ((n + 1 : ℕ) : ℤ) := by omega
        simp only [hcond, and_self, ↓reduceIte, Int.toNat_natCast]
        constructor
        · rw [wordStore_read_write_of_ne _ (by simp), wordStore_read_write_self]
        · rw [wordStore_read_write_self]
      · have hiff : (0 ≤ idx ∧ idx < ((n + 1 : ℕ) : ℤ)) ↔ (0 ≤ idx ∧ idx < (n : ℤ)) := by omega
        simp only [hiff]
        constructor
        · rw [wordStore_read_write_of_ne _ (by simp),
            wordStore_read_write_of_ne _ (by intro h; cases h; exact heq rfl), ih6]
        · rw [wordStore_read_write_of_ne _ (by intro h; cases h; exact heq rfl),
            wordStore_read_write_of_ne _ (by simp), ih7]

theorem stagingMatches_stageLoopWS {D r s : ℕ} (hD : 1 ≤ D) (hs : 1 ≤ s)
    {ι : Type*} (P : ι → Fin D → ℚ) (ω : Fin (r * s) → ι)
    (qAt : ℕ → ℚ)
    (hqAt : ∀ t (ht : t < r * s * D),
      qAt t = P (ω ⟨t / D, (Nat.div_lt_iff_lt_mul hD).mpr ht⟩) ⟨t % D, Nat.mod_lt t hD⟩) :
    let pts : Fin r → Fin s → Fin D → ℚ := fun i j => P (ω (blockIdx i j))
    let flatPts : List ℚ :=
      (List.finRange r).flatMap (fun i =>
        (List.finRange s).flatMap (fun j => List.ofFn (pts i j)))
    let inpHull : BitRAMInput 0 :=
      { intParams := [(D : ℤ), (r : ℤ), (s : ℤ)]
        activeHandles := ∅
        activeRatCoords := fun _ k => Fin.elim0 k
        extraRats := flatPts }
    StagingMatches (stageLoopWS (wsInit5 D r s) qAt (r * s * D)) inpHull := by
  intro pts flatPts inpHull
  refine ⟨isBaseStore_stageLoopWS D r s qAt (r * s * D), rfl,
    read_heap5_stageLoopWS D r s qAt (r * s * D), ?_, ?_⟩
  · intro idx
    rw [(read_heap67_stageLoopWS D r s qAt (r * s * D) idx).1]
    have hfl := flatPts_listGetIntD hD hs P ω idx
    dsimp only at hfl
    change _ = (listGetIntD flatPts idx 0).num
    rw [hfl]
    by_cases h : 0 ≤ idx ∧ idx < ((r * s * D : ℕ) : ℤ)
    · have h' : 0 ≤ idx ∧ idx.toNat < r * s * D := by omega
      rw [if_pos h, dif_pos h', hqAt idx.toNat h'.2]
    · have h' : ¬ (0 ≤ idx ∧ idx.toNat < r * s * D) := by omega
      rw [if_neg h, dif_neg h']
      rfl
  · intro idx
    rw [(read_heap67_stageLoopWS D r s qAt (r * s * D) idx).2]
    have hfl := flatPts_listGetIntD hD hs P ω idx
    dsimp only at hfl
    change _ + 1 = ((listGetIntD flatPts idx 0).den : ℤ)
    rw [hfl]
    by_cases h : 0 ≤ idx ∧ idx < ((r * s * D : ℕ) : ℤ)
    · have h' : 0 ≤ idx ∧ idx.toNat < r * s * D := by omega
      rw [if_pos h, dif_pos h', hqAt idx.toNat h'.2]
      omega
    · have h' : ¬ (0 ≤ idx ∧ idx.toNat < r * s * D) := by omega
      rw [if_neg h, dif_neg h']
      rfl

theorem cellCount_stageLoopWS_le (D r s : ℕ) (qAt : ℕ → ℚ) :
    ∀ n : ℕ, (stageLoopWS (wsInit5 D r s) qAt n).cellCount ≤ 2 * n + 3
  | 0 => by
      unfold stageLoopWS wsInit5
      have c0 : WordStore.empty.cellCount = 0 := rfl
      have c1 := wordStore_cellCount_write_le WordStore.empty (.heap 5 0) (D : ℤ)
      have c2 := wordStore_cellCount_write_le (WordStore.empty.write (.heap 5 0) (D : ℤ)) (.heap 5 1) (r : ℤ)
      have c3 := wordStore_cellCount_write_le
        ((WordStore.empty.write (.heap 5 0) (D : ℤ)).write (.heap 5 1) (r : ℤ)) (.heap 5 2) (s : ℤ)
      omega
  | n + 1 => by
      simp only [stageLoopWS]
      have ih := cellCount_stageLoopWS_le D r s qAt n
      have c1 := wordStore_cellCount_write_le (stageLoopWS (wsInit5 D r s) qAt n) (.heap 6 (n : ℤ)) (qAt n).num
      have c2 := wordStore_cellCount_write_le
        ((stageLoopWS (wsInit5 D r s) qAt n).write (.heap 6 (n : ℤ)) (qAt n).num)
        (.heap 7 (n : ℤ)) (((qAt n).den : ℤ) - 1)
      omega

theorem bitSize_stageLoopWS_le {D r s B W : ℕ} {qAt : ℕ → ℚ}
    (hDW : D ≤ W) (hrW : r ≤ W) (hsW : s ≤ W) (hBW : B ≤ W)
    (hqB : ∀ t : ℕ, RatCoordBitBounded B (qAt t)) :
    ∀ n : ℕ, n ≤ W →
      (stageLoopWS (wsInit5 D r s) qAt n).bitSize ≤ 6 * (W + 5) * (n + 1)
  | 0, _ => by
      unfold stageLoopWS wsInit5
      have b0 : WordStore.empty.bitSize = 0 := by simp [WordStore.bitSize, WordStore.empty]
      have b1 := wordStore_bitSize_write_le WordStore.empty (.heap 5 0) (D : ℤ)
      have b2 := wordStore_bitSize_write_le (WordStore.empty.write (.heap 5 0) (D : ℤ)) (.heap 5 1) (r : ℤ)
      have b3 := wordStore_bitSize_write_le
        ((WordStore.empty.write (.heap 5 0) (D : ℤ)).write (.heap 5 1) (r : ℤ)) (.heap 5 2) (s : ℤ)
      have l0 : (RAMCellLoc.heap 5 0).bitLength = 4 := by decide
      have l1 : (RAMCellLoc.heap 5 1).bitLength = 5 := by decide
      have l2 : (RAMCellLoc.heap 5 2).bitLength = 6 := by decide
      have vD := intBitLength_le_natAbs (D : ℤ)
      have vr := intBitLength_le_natAbs (r : ℤ)
      have vs := intBitLength_le_natAbs (s : ℤ)
      simp only [Int.natAbs_natCast] at vD vr vs
      simp only [Nat.zero_add, Nat.mul_one]
      rw [b0, l0] at b1
      rw [l1] at b2
      rw [l2] at b3
      omega
  | n + 1, hn1 => by
      simp only [stageLoopWS]
      have ih := bitSize_stageLoopWS_le hDW hrW hsW hBW hqB n (by omega)
      have b1 := wordStore_bitSize_write_le (stageLoopWS (wsInit5 D r s) qAt n)
        (.heap 6 (n : ℤ)) (qAt n).num
      have b2 := wordStore_bitSize_write_le
        ((stageLoopWS (wsInit5 D r s) qAt n).write (.heap 6 (n : ℤ)) (qAt n).num)
        (.heap 7 (n : ℤ)) (((qAt n).den : ℤ) - 1)
      have hn_bl := intBitLength_le_natAbs (n : ℤ)
      simp only [Int.natAbs_natCast] at hn_bl
      have l6 : (RAMCellLoc.heap 6 (n : ℤ)).bitLength ≤ W + 5 := by
        simp only [RAMCellLoc.bitLength]
        have : natBitLength 6 = 3 := by decide
        omega
      have l7 : (RAMCellLoc.heap 7 (n : ℤ)).bitLength ≤ W + 5 := by
        simp only [RAMCellLoc.bitLength]
        have : natBitLength 7 = 3 := by decide
        omega
      have vnum := intBitLength_num_le_of_bdd (hqB n)
      have vden := intBitLength_den_sub_one_le_of_bdd (hqB n)
      have hmul : 6 * (W + 5) * (n + 1 + 1) = 6 * (W + 5) * (n + 1) + 6 * (W + 5) := by ring
      rw [hmul]
      omega

def stageLoopBody : BitRAMStmt :=
  let idxE : IntExpr := .readLocal 0 (.lit 0)
  let hE : IntExpr := .div idxE .dim
  let cE : IntExpr := .mod idxE .dim
  .seq (.writeHeap 6 idxE (.activeRatNum hE cE))
    (.seq (.writeHeap 7 idxE (.sub (.activeRatDen hE cE) (.lit 1)))
      (.writeLocal 0 (.lit 0) (.add idxE (.lit 1))))

def phase1Stmt (K : ℕ) : BitRAMStmt :=
  .seq (.writeHeap 5 (.lit 0) .dim)
    (.seq (.writeHeap 5 (.lit 1) (rExpr K .dim (.intParam (.lit 1))))
      (.seq (.writeHeap 5 (.lit 2) (sExpr K .dim (.intParam (.lit 1))))
        (.localScope
          (.seq (.writeLocal 0 (.lit 0) (.lit 0))
            (.repeatN (.mul (.intParam (.lit 2)) .dim) stageLoopBody)))))

private theorem stageLoopBody_step {D r s B M W : ℕ} (hD : 1 ≤ D)
    (hDW : D ≤ W) (hrW : r ≤ W) (hsW : s ≤ W) (hBW : B ≤ W) (hMDW : M * D ≤ W)
    {ι : Type*} (P : ι → Fin D → ℚ)
    (ω : Fin M → ι) (inp : BitRAMInput D)
    (hActH : inp.activeHandles = Finset.range M)
    (hActC : inp.activeRatCoords = fun j => if hj : j < M then P (ω ⟨j, hj⟩) else fun _ => 0)
    (qAt : ℕ → ℚ)
    (hqAt : ∀ t (ht : t < M * D),
      qAt t = P (ω ⟨t / D, (Nat.div_lt_iff_lt_mul hD).mpr ht⟩) ⟨t % D, Nat.mod_lt t hD⟩)
    (hqB : ∀ t, RatCoordBitBounded B (qAt t))
    {n : ℕ} (hn : n < M * D) (st : BitRAMExecState)
    (hfd : st.frameDepth = 1) (hbits : st.remainingBits = [])
    (hws : st.words = (stageLoopWS (wsInit5 D r s) qAt n).write (.localFrame 1 0 0) (n : ℤ)) :
    ∃ st' : BitRAMExecState,
      RunsTo inp [.stmt stageLoopBody] st st' ∧
      st'.frameDepth = 1 ∧
      st'.remainingBits = [] ∧
      st'.words = (stageLoopWS (wsInit5 D r s) qAt (n + 1)).write (.localFrame 1 0 0) ((n + 1 : ℕ) : ℤ) ∧
      st'.unitCost ≤ st.unitCost + 40 ∧
      st'.bitCost ≤ st.bitCost + 40 * (W + 5) ^ 2 ∧
      st'.peakCellSpace ≤ max st.peakCellSpace (inp.inputCellSpace + 2 * (M * D) + 5) ∧
      st'.peakBitSpace ≤ max st.peakBitSpace (inp.inputBitSpace + 9 * (W + 5) ^ 2) := by
  have hm_lt : n / D < M := (Nat.div_lt_iff_lt_mul hD).mpr hn
  have hc_lt : n % D < D := Nat.mod_lt n hD
  have hread_loc : ∀ ws : WordStore,
      evalIntExpr inp 1 (ws.write (.localFrame 1 0 0) (n : ℤ)) (.readLocal 0 (.lit 0)) =
        ((n : ℤ), 2, 3 + intBitLength (n : ℤ)) := by
    intro ws
    simp only [evalIntExpr, wordStore_read_write_self]
    have h0 : intBitLength 0 = 1 := rfl
    have hn0 : natBitLength 0 = 1 := rfl
    rw [h0, hn0]
  have hdiv_eq : ((n : ℕ) : ℤ) / ((D : ℕ) : ℤ) = ((n / D : ℕ) : ℤ) := rfl
  have hmod_eq : ((n : ℕ) : ℤ) % ((D : ℕ) : ℤ) = ((n % D : ℕ) : ℤ) := rfl
  have hm_cond : 0 ≤ ((n / D : ℕ) : ℤ) ∧ ((n / D : ℕ) : ℤ).toNat ∈ inp.activeHandles := by
    rw [hActH]
    exact ⟨Nat.cast_nonneg _, Finset.mem_range.mpr (by simpa using hm_lt)⟩
  have hc_cond : 0 ≤ ((n % D : ℕ) : ℤ) ∧ ((n % D : ℕ) : ℤ).toNat < D :=
    ⟨Nat.cast_nonneg _, by simpa using hc_lt⟩
  have hq_eq : inp.activeRatCoords ((n / D : ℕ) : ℤ).toNat ⟨((n % D : ℕ) : ℤ).toNat, hc_cond.2⟩ = qAt n := by
    simp only [Int.toNat_natCast, hActC, hm_lt, ↓reduceDIte]
    exact (hqAt n hn).symm
  let ws0 := stageLoopWS (wsInit5 D r s) qAt n
  have hs1 := RunsTo.writeHeap inp 6 (.readLocal 0 (.lit 0))
    (.activeRatNum (.div (.readLocal 0 (.lit 0)) .dim) (.mod (.readLocal 0 (.lit 0)) .dim)) st
  have he_idx1 : evalIntExpr inp st.frameDepth st.words (.readLocal 0 (.lit 0)) =
      ((n : ℤ), 2, 3 + intBitLength (n : ℤ)) := by
    rw [hfd, hws]; exact hread_loc ws0
  have he_num : evalIntExpr inp st.frameDepth st.words
      (.activeRatNum (.div (.readLocal 0 (.lit 0)) .dim) (.mod (.readLocal 0 (.lit 0)) .dim)) =
      ((qAt n).num, 9,
        (3 + intBitLength (n : ℤ) + intBitLength (D : ℤ) + intBitLength (n : ℤ) * intBitLength (D : ℤ)) +
        (3 + intBitLength (n : ℤ) + intBitLength (D : ℤ) + intBitLength (n : ℤ) * intBitLength (D : ℤ)) +
        intBitLength ((n / D : ℕ) : ℤ) + intBitLength ((n % D : ℕ) : ℤ) + intBitLength (qAt n).num) := by
    rw [hfd, hws]
    simp only [evalIntExpr, wordStore_read_write_self, hdiv_eq, hmod_eq, hm_cond, and_self,
      hc_cond, ↓reduceDIte, hq_eq]
    have h0 : intBitLength 0 = 1 := rfl
    have hn0 : natBitLength 0 = 1 := rfl
    rw [h0, hn0]
  dsimp only at hs1
  rw [he_idx1, he_num] at hs1
  dsimp only at hs1
  set st1 : BitRAMExecState :=
    { st with
      words := st.words.write (.heap 6 (n : ℤ)) (qAt n).num
      unitCost := st.unitCost + 2 + 9 + 1
      bitCost := st.bitCost + (3 + intBitLength (n : ℤ)) +
        ((3 + intBitLength (n : ℤ) + intBitLength (D : ℤ) + intBitLength (n : ℤ) * intBitLength (D : ℤ)) +
        (3 + intBitLength (n : ℤ) + intBitLength (D : ℤ) + intBitLength (n : ℤ) * intBitLength (D : ℤ)) +
        intBitLength ((n / D : ℕ) : ℤ) + intBitLength ((n % D : ℕ) : ℤ) + intBitLength (qAt n).num) +
        (RAMCellLoc.heap 6 (n : ℤ)).bitLength + intBitLength (qAt n).num
      peakCellSpace := max st.peakCellSpace (inp.inputCellSpace + (st.words.write (.heap 6 (n : ℤ)) (qAt n).num).cellCount)
      peakBitSpace := max st.peakBitSpace (inp.inputBitSpace + (st.words.write (.heap 6 (n : ℤ)) (qAt n).num).bitSize) }
  have hws1 : st1.words = (ws0.write (.heap 6 (n : ℤ)) (qAt n).num).write (.localFrame 1 0 0) (n : ℤ) := by
    dsimp [st1]
    rw [hws, wordStore_write_comm _ (by simp)]
  have hs2 := RunsTo.writeHeap inp 7 (.readLocal 0 (.lit 0))
    (.sub (.activeRatDen (.div (.readLocal 0 (.lit 0)) .dim) (.mod (.readLocal 0 (.lit 0)) .dim)) (.lit 1)) st1
  have he_idx2 : evalIntExpr inp st1.frameDepth st1.words (.readLocal 0 (.lit 0)) =
      ((n : ℤ), 2, 3 + intBitLength (n : ℤ)) := by
    change evalIntExpr inp st.frameDepth st1.words _ = _
    rw [hfd, hws1]; exact hread_loc _
  have he_den : evalIntExpr inp st1.frameDepth st1.words
      (.sub (.activeRatDen (.div (.readLocal 0 (.lit 0)) .dim) (.mod (.readLocal 0 (.lit 0)) .dim)) (.lit 1)) =
      (((qAt n).den : ℤ) - 1, 11,
        ((3 + intBitLength (n : ℤ) + intBitLength (D : ℤ) + intBitLength (n : ℤ) * intBitLength (D : ℤ)) +
        (3 + intBitLength (n : ℤ) + intBitLength (D : ℤ) + intBitLength (n : ℤ) * intBitLength (D : ℤ)) +
        intBitLength ((n / D : ℕ) : ℤ) + intBitLength ((n % D : ℕ) : ℤ) + intBitLength ((qAt n).den : ℤ)) +
        2 + intBitLength ((qAt n).den : ℤ) + 2) := by
    change evalIntExpr inp st.frameDepth st1.words _ = _
    rw [hfd, hws1]
    simp only [evalIntExpr, wordStore_read_write_self, hdiv_eq, hmod_eq, hm_cond, and_self,
      hc_cond, ↓reduceDIte, hq_eq]
    have h0 : intBitLength 0 = 1 := rfl
    have hn0 : natBitLength 0 = 1 := rfl
    have h1 : intBitLength 1 = 2 := by decide
    rw [h0, hn0, h1]
  dsimp only at hs2
  rw [he_idx2, he_den] at hs2
  dsimp only at hs2
  set st2 : BitRAMExecState :=
    { st1 with
      words := st1.words.write (.heap 7 (n : ℤ)) (((qAt n).den : ℤ) - 1)
      unitCost := st1.unitCost + 2 + 11 + 1
      bitCost := st1.bitCost + (3 + intBitLength (n : ℤ)) +
        (((3 + intBitLength (n : ℤ) + intBitLength (D : ℤ) + intBitLength (n : ℤ) * intBitLength (D : ℤ)) +
        (3 + intBitLength (n : ℤ) + intBitLength (D : ℤ) + intBitLength (n : ℤ) * intBitLength (D : ℤ)) +
        intBitLength ((n / D : ℕ) : ℤ) + intBitLength ((n % D : ℕ) : ℤ) + intBitLength ((qAt n).den : ℤ)) +
        2 + intBitLength ((qAt n).den : ℤ) + 2) +
        (RAMCellLoc.heap 7 (n : ℤ)).bitLength + intBitLength (((qAt n).den : ℤ) - 1)
      peakCellSpace := max st1.peakCellSpace (inp.inputCellSpace + (st1.words.write (.heap 7 (n : ℤ)) (((qAt n).den : ℤ) - 1)).cellCount)
      peakBitSpace := max st1.peakBitSpace (inp.inputBitSpace + (st1.words.write (.heap 7 (n : ℤ)) (((qAt n).den : ℤ) - 1)).bitSize) }
  have hws2 : st2.words = (stageLoopWS (wsInit5 D r s) qAt (n + 1)).write (.localFrame 1 0 0) (n : ℤ) := by
    dsimp [st2, stageLoopWS, ws0]
    rw [hws1, wordStore_write_comm _ (by simp)]
  have hs3 := RunsTo.writeLocal inp 0 (.lit 0) (.add (.readLocal 0 (.lit 0)) (.lit 1)) st2
  have he_0 : evalIntExpr inp st2.frameDepth st2.words (.lit 0) = (0, 1, 1) := rfl
  have he_inc : evalIntExpr inp st2.frameDepth st2.words (.add (.readLocal 0 (.lit 0)) (.lit 1)) =
      (((n + 1 : ℕ) : ℤ), 4, (3 + intBitLength (n : ℤ)) + 2 + intBitLength (n : ℤ) + 2) := by
    change evalIntExpr inp st.frameDepth st2.words _ = _
    rw [hfd, hws2]
    simp only [evalIntExpr, wordStore_read_write_self]
    have h0 : intBitLength 0 = 1 := rfl
    have hn0 : natBitLength 0 = 1 := rfl
    have h1 : intBitLength 1 = 2 := by decide
    rw [h0, hn0, h1]
    push_cast
    rfl
  dsimp only at hs3
  rw [he_0, he_inc] at hs3
  dsimp only at hs3
  have hcomb := RunsTo.seq hs1 (RunsTo.seq hs2 hs3)
  have hbn : intBitLength (n : ℤ) ≤ W + 5 := by
    have := intBitLength_le_natAbs (n : ℤ); simp only [Int.natAbs_natCast] at this; omega
  have hbn1 : intBitLength ((n + 1 : ℕ) : ℤ) ≤ W + 5 := by
    have := intBitLength_le_natAbs ((n + 1 : ℕ) : ℤ); simp only [Int.natAbs_natCast] at this; omega
  have hbD : intBitLength (D : ℤ) ≤ W + 5 := by
    have := intBitLength_le_natAbs (D : ℤ); simp only [Int.natAbs_natCast] at this; omega
  have hbdiv : intBitLength ((n / D : ℕ) : ℤ) ≤ W + 5 := by
    have hle : n / D ≤ n := Nat.div_le_self n D
    have := intBitLength_le_natAbs ((n / D : ℕ) : ℤ); simp only [Int.natAbs_natCast] at this; omega
  have hbmod : intBitLength ((n % D : ℕ) : ℤ) ≤ W + 5 := by
    have := intBitLength_le_natAbs ((n % D : ℕ) : ℤ); simp only [Int.natAbs_natCast] at this; omega
  have hbnum : intBitLength (qAt n).num ≤ W + 5 := by
    have := intBitLength_num_le_of_bdd (hqB n); omega
  have hbden : intBitLength ((qAt n).den : ℤ) ≤ W + 5 := by
    have := intBitLength_den_le_of_bdd (hqB n); omega
  have hbdensub : intBitLength (((qAt n).den : ℤ) - 1) ≤ W + 5 := by
    have := intBitLength_den_sub_one_le_of_bdd (hqB n); omega
  have hl6 : (RAMCellLoc.heap 6 (n : ℤ)).bitLength ≤ W + 8 := by
    simp only [RAMCellLoc.bitLength]
    have h6 : natBitLength 6 = 3 := by decide
    omega
  have hl7 : (RAMCellLoc.heap 7 (n : ℤ)).bitLength ≤ W + 8 := by
    simp only [RAMCellLoc.bitLength]
    have h7 : natBitLength 7 = 3 := by decide
    omega
  have hll1 : (RAMCellLoc.localFrame 1 0 0).bitLength = 3 := rfl
  have hll : (RAMCellLoc.localFrame st2.frameDepth 0 0).bitLength = 3 := by
    change (RAMCellLoc.localFrame st.frameDepth 0 0).bitLength = 3
    rw [hfd]; rfl
  have hmul : intBitLength (n : ℤ) * intBitLength (D : ℤ) ≤ (W + 5) ^ 2 := by
    calc
      intBitLength (n : ℤ) * intBitLength (D : ℤ) ≤ (W + 5) * (W + 5) := Nat.mul_le_mul hbn hbD
      _ = (W + 5) ^ 2 := (sq (W + 5)).symm
  have hlin_sq : W + 5 ≤ (W + 5) ^ 2 := Nat.le_self_pow (by omega) _
  refine ⟨_, hcomb, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · exact hfd
  · exact hbits
  · change (st2.words.write (.localFrame st2.frameDepth 0 0) ((n + 1 : ℕ) : ℤ)) = _
    have hfd2 : st2.frameDepth = 1 := hfd
    rw [hfd2, hws2, wordStore_write_overwrite]
  · dsimp only [st2, st1]; omega
  · dsimp only [st2, st1]
    rw [hll]
    omega
  · -- peakCellSpace
    have hc0 := cellCount_stageLoopWS_le D r s qAt n
    have hc1 : st1.words.cellCount ≤ 2 * (M * D) + 5 := by
      rw [hws1]
      have a := wordStore_cellCount_write_le (ws0.write (.heap 6 (n : ℤ)) (qAt n).num) (.localFrame 1 0 0) (n : ℤ)
      have b := wordStore_cellCount_write_le ws0 (.heap 6 (n : ℤ)) (qAt n).num
      dsimp only [ws0] at a b ⊢
      omega
    have hc2 : st2.words.cellCount ≤ 2 * (M * D) + 5 := by
      rw [hws2]
      have a := wordStore_cellCount_write_le (stageLoopWS (wsInit5 D r s) qAt (n + 1)) (.localFrame 1 0 0) (n : ℤ)
      have b := cellCount_stageLoopWS_le D r s qAt (n + 1)
      omega
    have hc3 : (st2.words.write (.localFrame st2.frameDepth 0 0) ((n + 1 : ℕ) : ℤ)).cellCount ≤ 2 * (M * D) + 5 := by
      have hfd2 : st2.frameDepth = 1 := hfd
      rw [hfd2, hws2, wordStore_write_overwrite]
      have a := wordStore_cellCount_write_le (stageLoopWS (wsInit5 D r s) qAt (n + 1)) (.localFrame 1 0 0) ((n + 1 : ℕ) : ℤ)
      have b := cellCount_stageLoopWS_le D r s qAt (n + 1)
      omega
    dsimp only [st2, st1] at hc1 hc2 hc3 ⊢
    omega
  · -- peakBitSpace
    have hsq_bound : 6 * (W + 5) * (n + 2) + 3 * (W + 5) ≤ 9 * (W + 5) ^ 2 := by
      have hn2 : n + 2 ≤ W + 5 := by omega
      have hm1 : 6 * (W + 5) * (n + 2) ≤ 6 * (W + 5) * (W + 5) :=
        Nat.mul_le_mul_left _ hn2
      have hm2 : 3 * (W + 5) ≤ 3 * ((W + 5) * (W + 5)) :=
        Nat.mul_le_mul_left 3 (by simpa [sq] using hlin_sq)
      have hring : 6 * (W + 5) * (W + 5) + 3 * ((W + 5) * (W + 5)) = 9 * (W + 5) ^ 2 := by ring
      omega
    have hbs0 := bitSize_stageLoopWS_le hDW hrW hsW hBW hqB n (by omega)
    have hbs0_1 := bitSize_stageLoopWS_le hDW hrW hsW hBW hqB (n + 1) (by omega)
    have hn11_eq : n + 1 + 1 = n + 2 := rfl
    rw [hn11_eq] at hbs0_1
    have hb1_le : st1.words.bitSize ≤ 9 * (W + 5) ^ 2 := by
      rw [hws1]
      have a := wordStore_bitSize_write_le (ws0.write (.heap 6 (n : ℤ)) (qAt n).num) (.localFrame 1 0 0) (n : ℤ)
      have b := wordStore_bitSize_write_le ws0 (.heap 6 (n : ℤ)) (qAt n).num
      dsimp only [ws0] at a b ⊢
      rw [hll1] at a
      have hmuln : 6 * (W + 5) * (n + 2) = 6 * (W + 5) * (n + 1) + 6 * (W + 5) := by ring
      omega
    have hb2_le : st2.words.bitSize ≤ 9 * (W + 5) ^ 2 := by
      rw [hws2]
      have a := wordStore_bitSize_write_le (stageLoopWS (wsInit5 D r s) qAt (n + 1)) (.localFrame 1 0 0) (n : ℤ)
      rw [hll1] at a
      omega
    have hb3_le : (st2.words.write (.localFrame st2.frameDepth 0 0) ((n + 1 : ℕ) : ℤ)).bitSize ≤ 9 * (W + 5) ^ 2 := by
      have hfd2 : st2.frameDepth = 1 := hfd
      rw [hfd2, hws2, wordStore_write_overwrite]
      have a := wordStore_bitSize_write_le (stageLoopWS (wsInit5 D r s) qAt (n + 1)) (.localFrame 1 0 0) ((n + 1 : ℕ) : ℤ)
      rw [hll1] at a
      omega
    dsimp only [st2, st1] at hb1_le hb2_le hb3_le ⊢
    omega

private theorem stageLoop_runsTo {D r s B M W : ℕ} (hD : 1 ≤ D)
    (hDW : D ≤ W) (hrW : r ≤ W) (hsW : s ≤ W) (hBW : B ≤ W) (hMDW : M * D ≤ W)
    {ι : Type*} (P : ι → Fin D → ℚ)
    (ω : Fin M → ι) (inp : BitRAMInput D)
    (hActH : inp.activeHandles = Finset.range M)
    (hActC : inp.activeRatCoords = fun j => if hj : j < M then P (ω ⟨j, hj⟩) else fun _ => 0)
    (qAt : ℕ → ℚ)
    (hqAt : ∀ t (ht : t < M * D),
      qAt t = P (ω ⟨t / D, (Nat.div_lt_iff_lt_mul hD).mpr ht⟩) ⟨t % D, Nat.mod_lt t hD⟩)
    (hqB : ∀ t, RatCoordBitBounded B (qAt t)) :
    ∀ (rem n : ℕ), n + rem = M * D →
      ∀ (st : BitRAMExecState),
        st.frameDepth = 1 →
        st.remainingBits = [] →
        st.words = (stageLoopWS (wsInit5 D r s) qAt n).write (.localFrame 1 0 0) (n : ℤ) →
        ∃ stEnd : BitRAMExecState,
          RunsTo inp [.repeatLoop rem stageLoopBody] st stEnd ∧
          stEnd.frameDepth = 1 ∧
          stEnd.remainingBits = [] ∧
          stEnd.words =
            (stageLoopWS (wsInit5 D r s) qAt (M * D)).write (.localFrame 1 0 0) ((M * D : ℕ) : ℤ) ∧
          stEnd.unitCost ≤ st.unitCost + 40 * rem ∧
          stEnd.bitCost ≤ st.bitCost + 40 * (W + 5) ^ 2 * rem ∧
          stEnd.peakCellSpace ≤ max st.peakCellSpace (inp.inputCellSpace + 2 * (M * D) + 5) ∧
          stEnd.peakBitSpace ≤ max st.peakBitSpace (inp.inputBitSpace + 9 * (W + 5) ^ 2)
  | 0, n, hsum, st, hfd, hbits, hws => by
      have hn_eq : n = M * D := by omega
      subst hn_eq
      exact ⟨st, RunsTo.repeatLoop_zero _ st, hfd, hbits, hws,
        by omega, by omega, le_max_left _ _, le_max_left _ _⟩
  | rem + 1, n, hsum, st, hfd, hbits, hws => by
      have hn : n < M * D := by omega
      obtain ⟨st', hstep, hfd', hbits', hws', hu', hb', hpc', hpb'⟩ :=
        stageLoopBody_step hD hDW hrW hsW hBW hMDW P ω inp hActH hActC qAt hqAt hqB hn
          st hfd hbits hws
      obtain ⟨stEnd, hrem, hfdE, hbitsE, hwsE, huE, hbE, hpcE, hpbE⟩ :=
        stageLoop_runsTo hD hDW hrW hsW hBW hMDW P ω inp hActH hActC qAt hqAt hqB
          rem (n + 1) (by omega) st' hfd' hbits' hws'
      refine ⟨stEnd, RunsTo.repeatLoop_succ hstep hrem, hfdE, hbitsE, hwsE, ?_, ?_, ?_, ?_⟩
      · omega
      · have hmul : 40 * (W + 5) ^ 2 * (rem + 1) = 40 * (W + 5) ^ 2 * rem + 40 * (W + 5) ^ 2 := by ring
        rw [hmul]; omega
      · omega
      · omega

theorem phase1_spec {K D B k : ℕ} (hK : 1 ≤ K) (hD : 1 ≤ D) (hB : 1 ≤ B)
    {s r M W : ℕ}
    (hs_eq : s = sVal K D k) (hr_eq : r = rVal K D k) (hM_eq : M = mVal K D k)
    (hMW : M * D + B + 10 ≤ W)
    {ι : Type*} (P : ι → Fin D → ℚ) (hP : ∀ i, RatPointBitBounded B (P i))
    (ω : Fin M → ι) (inp : BitRAMInput D)
    (hIntP : inp.intParams = [(B : ℤ), (k : ℤ), (M : ℤ)])
    (hActH : inp.activeHandles = Finset.range M)
    (hActC : inp.activeRatCoords = fun j => if hj : j < M then P (ω ⟨j, hj⟩) else fun _ => 0)
    (qAt : ℕ → ℚ)
    (hqAt : ∀ t (ht : t < M * D),
      qAt t = P (ω ⟨t / D, (Nat.div_lt_iff_lt_mul hD).mpr ht⟩) ⟨t % D, Nat.mod_lt t hD⟩)
    (hq0 : ∀ t, ¬ (t < M * D) → qAt t = 0) :
    let initSt : BitRAMExecState :=
      { words := WordStore.empty.popDepth 0
        frameDepth := 0
        remainingBits := []
        unitCost := 0
        bitCost := 0
        peakCellSpace := inp.inputCellSpace + (WordStore.empty.popDepth 0).cellCount
        peakBitSpace := inp.inputBitSpace + (WordStore.empty.popDepth 0).bitSize }
    ∃ st₁ : BitRAMExecState,
      RunsTo inp [.stmt (phase1Stmt K)] initSt st₁ ∧
      st₁.words = stageLoopWS (wsInit5 D r s) qAt (M * D) ∧
      st₁.frameDepth = 0 ∧
      st₁.remainingBits = [] ∧
      st₁.unitCost ≤ 500 + 40 * (W + 5) ∧
      st₁.bitCost ≤ 500 * (W + 5) ^ 3 ∧
      st₁.peakCellSpace ≤ inp.inputCellSpace + 2 * (W + 5) + 5 ∧
      st₁.peakBitSpace ≤ inp.inputBitSpace + 10 * (W + 5) ^ 2 := by
  intro initSt
  have hsub := subterms_le_mVal (D := D) (k := k) hK
  dsimp only at hsub
  rw [← hM_eq, ← hr_eq, ← hs_eq] at hsub
  have h1M : 1 ≤ M := hsub.1
  have hDM : D ≤ M := hsub.2.1
  have hkM : k ≤ M := hsub.2.2.1
  have hsM : s ≤ M := hsub.2.2.2.2.2.2.2.2.2.1
  have hrM : r ≤ M := hsub.2.2.2.2.2.2.2.2.2.2.1
  have hMW_self : M ≤ M * D := Nat.le_mul_of_pos_right M hD
  have hDW : D ≤ W := by omega
  have hrW : r ≤ W := by omega
  have hsW : s ≤ W := by omega
  have hBW : B ≤ W := by omega
  have hMDW : M * D ≤ W := by omega
  have hqB : ∀ t, RatCoordBitBounded B (qAt t) := by
    intro t
    by_cases ht : t < M * D
    · rw [hqAt t ht]
      exact hP _ _
    · rw [hq0 t ht]
      exact ⟨by simp [natBitLength]; omega, by simp [natBitLength]; omega⟩
  have hpop0 : WordStore.empty.popDepth 0 = WordStore.empty := popDepth_zero_of_isBaseStore isBaseStore_empty
  have h3sqM : 3 * (M + 2) ≤ (M + 2) ^ 2 := by
    calc
      3 * (M + 2) ≤ (M + 2) * (M + 2) := Nat.mul_le_mul_right _ (by omega)
      _ = (M + 2) ^ 2 := (sq (M + 2)).symm
  have hdE_for : ∀ ws : WordStore, EvalNonnegBounded inp 0 ws .dim D 3 (2 * (mVal K D k + 2) ^ 2) := by
    intro ws
    rw [← hM_eq]
    simp only [EvalNonnegBounded, evalIntExpr]
    have hbD := intBitLength_le_natAbs (D : ℤ)
    simp only [Int.natAbs_natCast] at hbD
    exact ⟨by simp, by omega, by omega⟩
  have hkE_for : ∀ ws : WordStore, EvalNonnegBounded inp 0 ws (.intParam (.lit 1)) k 3 (2 * (mVal K D k + 2) ^ 2) := by
    intro ws
    rw [← hM_eq]
    simp only [EvalNonnegBounded, evalIntExpr, hIntP, listGetIntD]
    have hbk := intBitLength_le_natAbs (k : ℤ)
    simp only [Int.natAbs_natCast] at hbk
    have hb1 : intBitLength 1 = 2 := by decide
    have h1ge : (0 : ℤ) ≤ 1 := by omega
    have hget1 : [(B : ℤ), (k : ℤ), (M : ℤ)].getD (1 : ℤ).toNat 0 = (k : ℤ) := rfl
    simp only [h1ge, ↓reduceIte, hb1, hget1]
    exact ⟨by simp, by omega, by omega⟩
  -- Header write 1: .heap 5 0 := D
  have hw1_raw := RunsTo.writeHeap inp 5 (.lit 0) .dim initSt
  dsimp only [initSt] at hw1_raw
  have he_lit0 : ∀ fd ws, evalIntExpr inp fd ws (.lit 0) = (0, 1, 1) := fun _ _ => rfl
  have he_dim0 : evalIntExpr inp 0 (WordStore.empty.popDepth 0) .dim = ((D : ℤ), 1, intBitLength (D : ℤ)) := rfl
  rw [he_lit0, he_dim0] at hw1_raw
  set stA : BitRAMExecState :=
    { initSt with
      words := WordStore.empty.write (.heap 5 0) (D : ℤ)
      unitCost := 0 + 1 + 1 + 1
      bitCost := 0 + 1 + intBitLength (D : ℤ) + (RAMCellLoc.heap 5 0).bitLength + intBitLength (D : ℤ)
      peakCellSpace := max initSt.peakCellSpace (inp.inputCellSpace + (WordStore.empty.write (.heap 5 0) (D : ℤ)).cellCount)
      peakBitSpace := max initSt.peakBitSpace (inp.inputBitSpace + (WordStore.empty.write (.heap 5 0) (D : ℤ)).bitSize) }
  have hw1 : RunsTo inp [.stmt (.writeHeap 5 (.lit 0) .dim)] initSt stA := by
    convert hw1_raw using 2
    dsimp [stA, initSt]
    rw [hpop0]
  -- Header write 2: .heap 5 1 := r
  have hr_eval := (eval_srmExpr inp 0 stA.words hK (hdE_for stA.words) (hkE_for stA.words)).2.1
  rw [← hr_eq, ← hM_eq] at hr_eval
  have hw2 := RunsTo.writeHeap inp 5 (.lit 1) (rExpr K .dim (.intParam (.lit 1))) stA
  dsimp only at hw2
  rcases eqr : evalIntExpr inp 0 stA.words (rExpr K .dim (.intParam (.lit 1))) with ⟨vr, ur, br⟩
  simp only [EvalNonnegBounded, eqr] at hr_eval
  rcases hr_eval with ⟨rfl, hur, hbr⟩
  have he_lit1 : evalIntExpr inp 0 stA.words (.lit 1) = (1, 1, 2) := rfl
  change RunsTo inp _ stA _ at hw2
  simp only [ (show stA.frameDepth = 0 from rfl), he_lit1, eqr ] at hw2
  set stB : BitRAMExecState :=
    { stA with
      words := stA.words.write (.heap 5 1) (r : ℤ)
      unitCost := stA.unitCost + 1 + ur + 1
      bitCost := stA.bitCost + 2 + br + (RAMCellLoc.heap 5 1).bitLength + intBitLength (r : ℤ)
      peakCellSpace := max stA.peakCellSpace (inp.inputCellSpace + (stA.words.write (.heap 5 1) (r : ℤ)).cellCount)
      peakBitSpace := max stA.peakBitSpace (inp.inputBitSpace + (stA.words.write (.heap 5 1) (r : ℤ)).bitSize) }
  -- Header write 3: .heap 5 2 := s
  have hs_eval := (eval_srmExpr inp 0 stB.words hK (hdE_for stB.words) (hkE_for stB.words)).1
  rw [← hs_eq, ← hM_eq] at hs_eval
  have hw3 := RunsTo.writeHeap inp 5 (.lit 2) (sExpr K .dim (.intParam (.lit 1))) stB
  dsimp only at hw3
  rcases eqs : evalIntExpr inp 0 stB.words (sExpr K .dim (.intParam (.lit 1))) with ⟨vs, us, bs⟩
  simp only [EvalNonnegBounded, eqs] at hs_eval
  rcases hs_eval with ⟨rfl, hus, hbs⟩
  have he_lit2 : evalIntExpr inp 0 stB.words (.lit 2) = (2, 1, 3) := rfl
  simp only [ (show stB.frameDepth = 0 from rfl), he_lit2, eqs ] at hw3
  set stC : BitRAMExecState :=
    { stB with
      words := wsInit5 D r s
      unitCost := stB.unitCost + 1 + us + 1
      bitCost := stB.bitCost + 3 + bs + (RAMCellLoc.heap 5 2).bitLength + intBitLength (s : ℤ)
      peakCellSpace := max stB.peakCellSpace (inp.inputCellSpace + (wsInit5 D r s).cellCount)
      peakBitSpace := max stB.peakBitSpace (inp.inputBitSpace + (wsInit5 D r s).bitSize) }
  -- Inside localScope: stC enters depth 1
  have hpopC : (wsInit5 D r s).popDepth 0 = wsInit5 D r s :=
    popDepth_zero_of_isBaseStore (isBaseStore_wsInit5 D r s)
  let stScope0 : BitRAMExecState :=
    { stC with words := stC.words.popDepth stC.frameDepth, frameDepth := stC.frameDepth + 1 }
  have hwLoc0_raw := RunsTo.writeLocal inp 0 (.lit 0) (.lit 0) stScope0
  dsimp only [stScope0] at hwLoc0_raw
  rw [he_lit0] at hwLoc0_raw
  dsimp only at hwLoc0_raw
  set stLoop0 : BitRAMExecState :=
    { stC with
      words := (wsInit5 D r s).write (.localFrame 1 0 0) 0
      frameDepth := 1
      unitCost := stC.unitCost + 1 + 1 + 1
      bitCost := stC.bitCost + 1 + 1 + (RAMCellLoc.localFrame 1 0 0).bitLength + 1
      peakCellSpace := max stC.peakCellSpace (inp.inputCellSpace + ((wsInit5 D r s).write (.localFrame 1 0 0) 0).cellCount)
      peakBitSpace := max stC.peakBitSpace (inp.inputBitSpace + ((wsInit5 D r s).write (.localFrame 1 0 0) 0).bitSize) }
  have hwLoc0 : RunsTo inp [.stmt (.writeLocal 0 (.lit 0) (.lit 0))] stScope0 stLoop0 := by
    convert hwLoc0_raw using 2
    dsimp only [stLoop0, stC, stB, stA, initSt]
    rw [hpopC]
  -- Evaluate repeatN count: .mul (.intParam (.lit 2)) .dim = M * D
  have he_cnt : evalIntExpr inp 1 stLoop0.words (.mul (.intParam (.lit 2)) .dim) =
      (((M * D : ℕ) : ℤ), 4,
        (3 + 3 + intBitLength (M : ℤ)) + intBitLength (D : ℤ) + intBitLength (M : ℤ) * intBitLength (D : ℤ)) := by
    simp only [evalIntExpr, hIntP, listGetIntD]
    have hb2 : intBitLength 2 = 3 := by decide
    have h2ge : (0 : ℤ) ≤ 2 := by omega
    have hget2 : [(B : ℤ), (k : ℤ), (M : ℤ)].getD (2 : ℤ).toNat 0 = (M : ℤ) := rfl
    simp only [h2ge, ↓reduceIte, hb2, hget2]
    push_cast
    rfl
  let stLoopStart : BitRAMExecState :=
    { stLoop0 with
      unitCost := stLoop0.unitCost + 4
      bitCost := stLoop0.bitCost +
        ((3 + 3 + intBitLength (M : ℤ)) + intBitLength (D : ℤ) + intBitLength (M : ℤ) * intBitLength (D : ℤ)) }
  obtain ⟨stLoopEnd, hloop, hfdE, hbitsE, hwsE, huE, hbE, hpcE, hpbE⟩ :=
    stageLoop_runsTo hD hDW hrW hsW hBW hMDW P ω inp hActH hActC qAt hqAt hqB
      (M * D) 0 (Nat.zero_add _) stLoopStart rfl rfl rfl
  have hrep : RunsTo inp [.stmt (.repeatN (.mul (.intParam (.lit 2)) .dim) stageLoopBody)] stLoop0 stLoopEnd := by
    refine RunsTo.repeatN _ _ ?_
    change (let p := evalIntExpr inp 1 stLoop0.words (.mul (.intParam (.lit 2)) .dim)
      RunsTo inp [.repeatLoop (if 0 ≤ p.1 then p.1.toNat else 0) stageLoopBody]
        { stLoop0 with unitCost := stLoop0.unitCost + p.2.1, bitCost := stLoop0.bitCost + p.2.2 } stLoopEnd)
    rw [he_cnt]
    dsimp only
    rw [if_pos (Nat.cast_nonneg _), Int.toNat_natCast]
    exact hloop
  have hscope := RunsTo.localScope (RunsTo.seq hwLoc0 hrep)
  have hfull := RunsTo.seq hw1 (RunsTo.seq hw2 (RunsTo.seq hw3 hscope))
  refine ⟨_, hfull, ?_, rfl, hbitsE, ?_, ?_, ?_, ?_⟩
  · dsimp only
    rw [hwsE]
    exact popDepth_zero_write_local1_of_isBaseStore (isBaseStore_stageLoopWS D r s qAt (M * D)) 0 0 _
  · dsimp only [stLoopStart, stLoop0, stC, stB, stA, initSt] at huE ⊢
    omega
  · -- bitCost <= 500 * (W + 5) ^ 3
    dsimp only [stLoopStart, stLoop0, stC, stB, stA, initSt] at hbE ⊢
    have hbD : intBitLength (D : ℤ) ≤ W + 5 := by
      have := intBitLength_le_natAbs (D : ℤ); simp only [Int.natAbs_natCast] at this; omega
    have hbr_bl : intBitLength (r : ℤ) ≤ W + 5 := by
      have := intBitLength_le_natAbs (r : ℤ); simp only [Int.natAbs_natCast] at this; omega
    have hbs_bl : intBitLength (s : ℤ) ≤ W + 5 := by
      have := intBitLength_le_natAbs (s : ℤ); simp only [Int.natAbs_natCast] at this; omega
    have hbM_bl : intBitLength (M : ℤ) ≤ W + 5 := by
      have := intBitLength_le_natAbs (M : ℤ); simp only [Int.natAbs_natCast] at this; omega
    have hM2_le : (M + 2) ^ 2 ≤ (W + 5) ^ 2 := Nat.pow_le_pow_left (by omega) 2
    have hMD_sq : intBitLength (M : ℤ) * intBitLength (D : ℤ) ≤ (W + 5) ^ 2 := by
      calc
        intBitLength (M : ℤ) * intBitLength (D : ℤ) ≤ (W + 5) * (W + 5) := Nat.mul_le_mul hbM_bl hbD
        _ = (W + 5) ^ 2 := (sq (W + 5)).symm
    have hloop_cu : 40 * (W + 5) ^ 2 * (M * D) ≤ 40 * (W + 5) ^ 3 := by
      calc
        40 * (W + 5) ^ 2 * (M * D) ≤ 40 * (W + 5) ^ 2 * (W + 5) :=
          Nat.mul_le_mul_left _ (by omega)
        _ = 40 * (W + 5) ^ 3 := by ring
    have hsq_cu : (W + 5) ^ 2 ≤ (W + 5) ^ 3 := by
      calc
        (W + 5) ^ 2 = (W + 5) ^ 2 * 1 := (Nat.mul_one _).symm
        _ ≤ (W + 5) ^ 2 * (W + 5) := Nat.mul_le_mul_left _ (by omega)
        _ = (W + 5) ^ 3 := by ring
    have hlin_sq : W + 5 ≤ (W + 5) ^ 2 := Nat.le_self_pow (by omega) _
    have l0 : (RAMCellLoc.heap 5 0).bitLength = 4 := by decide
    have l1 : (RAMCellLoc.heap 5 1).bitLength = 5 := by decide
    have l2 : (RAMCellLoc.heap 5 2).bitLength = 6 := by decide
    have ll : (RAMCellLoc.localFrame 1 0 0).bitLength = 3 := rfl
    rw [l0, l1, l2, ll] at hbE
    omega
  · -- peakCellSpace
    dsimp only [stLoopStart, stLoop0, stC, stB, stA, initSt] at hpcE ⊢
    rw [hpop0] at hpcE
    have c0 : WordStore.empty.cellCount = 0 := rfl
    have c1 := wordStore_cellCount_write_le WordStore.empty (.heap 5 0) (D : ℤ)
    have c2 := wordStore_cellCount_write_le (WordStore.empty.write (.heap 5 0) (D : ℤ)) (.heap 5 1) (r : ℤ)
    have c3 := cellCount_stageLoopWS_le D r s qAt 0
    have c4 := wordStore_cellCount_write_le (wsInit5 D r s) (.localFrame 1 0 0) 0
    dsimp only [stageLoopWS] at c3
    omega
  · -- peakBitSpace
    dsimp only [stLoopStart, stLoop0, stC, stB, stA, initSt] at hpbE ⊢
    rw [hpop0] at hpbE
    have b0 : WordStore.empty.bitSize = 0 := by simp [WordStore.bitSize, WordStore.empty]
    have b1 := wordStore_bitSize_write_le WordStore.empty (.heap 5 0) (D : ℤ)
    have b2 := wordStore_bitSize_write_le (WordStore.empty.write (.heap 5 0) (D : ℤ)) (.heap 5 1) (r : ℤ)
    have b3 := bitSize_stageLoopWS_le hDW hrW hsW hBW hqB 0 (by omega)
    have b4 := wordStore_bitSize_write_le (wsInit5 D r s) (.localFrame 1 0 0) 0
    simp only [stageLoopWS, Nat.zero_add, Nat.mul_one] at b3
    have vD := intBitLength_le_natAbs (D : ℤ)
    have vr := intBitLength_le_natAbs (r : ℤ)
    simp only [Int.natAbs_natCast] at vD vr
    have l0 : (RAMCellLoc.heap 5 0).bitLength = 4 := by decide
    have l1 : (RAMCellLoc.heap 5 1).bitLength = 5 := by decide
    have ll : (RAMCellLoc.localFrame 1 0 0).bitLength = 3 := rfl
    have hlin_sq : W + 5 ≤ (W + 5) ^ 2 := Nat.le_self_pow (by omega) _
    rw [b0] at b1 hpbE
    rw [l0] at b1
    rw [l1] at b2
    have v0 : intBitLength 0 = 1 := rfl
    rw [ll, v0] at b4
    omega

end UL.Proof_lem_A_1
