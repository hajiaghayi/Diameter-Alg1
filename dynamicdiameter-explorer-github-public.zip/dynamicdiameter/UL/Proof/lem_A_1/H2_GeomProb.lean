import Mathlib
import UL.Stmt.cit_centerpoint_thm
import UL.Stmt.cit_hw87_halfspace_net
import UL.Stmt.cit_vc71_halfspace_uc
import UL.Def.def_A_convex_hull_cert
import UL.Proof.cit_vc71_halfspace_uc.H1
import UL.Proof.cit_vc71_halfspace_uc.H2
import UL.Proof.lem_A_1.H1_Params
set_option autoImplicit false

namespace UL.Proof_lem_A_1

attribute [local instance 5] Classical.propDecidable

/-- Flat sample index `i * s + j < r * s` for block `i : Fin r` and element `j : Fin s`. -/
def blockIdx {r s : ℕ} (i : Fin r) (j : Fin s) : Fin (r * s) :=
  ⟨i.val * s + j.val, by nlinarith [i.isLt, j.isLt]⟩

/-- Bijection `(Fin (r * s) → ι) ≃ (Fin r → Fin s → ι)` for `1 ≤ s`. -/
def blockEquiv (r s : ℕ) (hs : 1 ≤ s) (ι : Type*) :
    (Fin (r * s) → ι) ≃ (Fin r → Fin s → ι) where
  toFun ω i j := ω (blockIdx i j)
  invFun b t :=
    b ⟨t.val / s, (Nat.div_lt_iff_lt_mul (by omega)).mpr t.isLt⟩
      ⟨t.val % s, Nat.mod_lt t.val (by omega)⟩
  left_inv ω := by
    funext t
    refine congrArg ω (Fin.ext ?_)
    dsimp [blockIdx]
    have h := Nat.div_add_mod t.val s
    linarith
  right_inv b := by
    funext i j
    have hdiv : (i.val * s + j.val) / s = i.val := by
      have h1 : i.val * s + j.val = j.val + s * i.val := by ring
      rw [h1, Nat.add_mul_div_left j.val i.val (by omega), Nat.div_eq_of_lt j.isLt, zero_add]
    have hmod : (i.val * s + j.val) % s = j.val := by
      have h1 : i.val * s + j.val = j.val + s * i.val := by ring
      rw [h1, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt j.isLt]
    have hi : (⟨(i.val * s + j.val) / s,
        (Nat.div_lt_iff_lt_mul (by omega)).mpr (blockIdx i j).isLt⟩ : Fin r) = i :=
      Fin.ext hdiv
    have hj : (⟨(i.val * s + j.val) % s,
        Nat.mod_lt (i.val * s + j.val) (by omega)⟩ : Fin s) = j :=
      Fin.ext hmod
    dsimp [blockIdx]
    rw [hi, hj]

theorem blockEquiv_apply (r s : ℕ) (hs : 1 ≤ s) (ι : Type*)
    (ω : Fin (r * s) → ι) (i : Fin r) :
    blockEquiv r s hs ι ω i = fun j : Fin s => ω (blockIdx i j) :=
  rfl

/-- Membership in `convexHull ℝ (Set.range f)` yields `HasConvexHullCert f z`. -/
theorem mem_convexHull_range_imp_hasConvexHullCert {D : ℕ} {κ : Type*} [Fintype κ]
    (f : κ → EuclideanSpace ℝ (Fin D)) {z : EuclideanSpace ℝ (Fin D)}
    (hz : z ∈ convexHull ℝ (Set.range f)) :
    HasConvexHullCert f z := by
  classical
  let K : Set (EuclideanSpace ℝ (Fin D)) := {x | HasConvexHullCert f x}
  have h_sub : Set.range f ⊆ K := by
    rintro _ ⟨j₀, rfl⟩
    refine ⟨fun j => if j = j₀ then 1 else 0, ?_, ?_, ?_⟩
    · intro j
      dsimp only
      split_ifs <;> norm_num
    · simp
    · simp
  have h_conv : Convex ℝ K := by
    rintro x ⟨wx, hwx0, hwx1, hwx_sum⟩ y ⟨wy, hwy0, hwy1, hwy_sum⟩ a b ha hb hab
    refine ⟨fun j => a * wx j + b * wy j, ?_, ?_, ?_⟩
    · intro j
      dsimp only
      have := hwx0 j
      have := hwy0 j
      positivity
    · simp_rw [Finset.sum_add_distrib, ← Finset.mul_sum, hwx1, hwy1, mul_one]
      exact hab
    · calc
        ∑ j : κ, (a * wx j + b * wy j) • f j
            = ∑ j : κ, (a • (wx j • f j) + b • (wy j • f j)) := by
              refine Finset.sum_congr rfl fun j _ => ?_
              rw [add_smul, mul_smul, mul_smul]
        _ = a • (∑ j : κ, wx j • f j) + b • (∑ j : κ, wy j • f j) := by
              rw [Finset.sum_add_distrib, Finset.smul_sum, Finset.smul_sum]
        _ = a • x + b • y := by rw [hwx_sum, hwy_sum]
  exact convexHull_min h_sub h_conv hz

/-- If every block of `ω` is an indexed `1 / (D + 1)`-halfspace net of `Q`, then the centerpoint
`z_star` has a convex-hull certificate on every block. -/
theorem indexedNets_imp_exists_convexHullCert
    (h_cp : S_cit_centerpoint_thm) {D r s : ℕ} (hD : 1 ≤ D)
    {ι : Type} [Fintype ι] [Nonempty ι]
    (Q : ι → EuclideanSpace ℝ (Fin D)) (ω : Fin (r * s) → ι)
    (hnets : ∀ i : Fin r,
      IsIndexedHalfspaceNet (1 / ((D : ℝ) + 1)) Q (fun j : Fin s => ω (blockIdx i j))) :
    ∃ z : EuclideanSpace ℝ (Fin D),
      ∀ i : Fin r, HasConvexHullCert (fun j : Fin s => Q (ω (blockIdx i j))) z := by
  classical
  obtain ⟨z_star, _, hz_net⟩ := h_cp D hD ι Q
  refine ⟨z_star, fun i => ?_⟩
  let S_i : Finset ι := Finset.univ.image (fun j : Fin s => ω (blockIdx i j))
  have hS_net : IsHalfspaceNet (1 / ((D : ℝ) + 1)) Q S_i := by
    intro H hH hcnt
    obtain ⟨j, hjH⟩ := hnets i H hH hcnt
    exact ⟨ω (blockIdx i j), Finset.mem_image.mpr ⟨j, Finset.mem_univ j, rfl⟩, hjH⟩
  have hz_mem : z_star ∈ convexHull ℝ (Q '' (S_i : Set ι)) := hz_net S_i hS_net
  have h_img_eq : Q '' (S_i : Set ι) = Set.range (fun j : Fin s => Q (ω (blockIdx i j))) := by
    ext x
    simp [S_i]
  rw [h_img_eq] at hz_mem
  exact mem_convexHull_range_imp_hasConvexHullCert _ hz_mem

/-- Every closed halfspace containing a convex combination of `pts` contains at least one `pts j`. -/
theorem exists_mem_halfspace_of_hasConvexHullCert {D : ℕ} {κ : Type*} [Fintype κ]
    {pts : κ → EuclideanSpace ℝ (Fin D)} {z : EuclideanSpace ℝ (Fin D)}
    (hcert : HasConvexHullCert pts z)
    {H : Set (EuclideanSpace ℝ (Fin D))} (hH : IsClosedHalfspace H) (hzH : z ∈ H) :
    ∃ j : κ, pts j ∈ H := by
  rcases hH with ⟨v, _, β, rfl⟩
  rcases hcert with ⟨w, hw0, hw1, hw_pts⟩
  by_contra! h_none
  simp only [Set.mem_setOf_eq, not_le] at hzH h_none
  have hex_pos : ∃ j₀ : κ, 0 < w j₀ := by
    by_contra! hall_le
    have hzero : ∀ j : κ, w j = 0 := fun j => le_antisymm (hall_le j) (hw0 j)
    have : ∑ j : κ, w j = 0 := Finset.sum_eq_zero (fun j _ => hzero j)
    linarith
  obtain ⟨j₀, hj₀⟩ := hex_pos
  have h_lt_sum :
      ∑ j : κ, w j * β < ∑ j : κ, w j * inner ℝ v (pts j) := by
    refine Finset.sum_lt_sum (fun j _ => mul_le_mul_of_nonneg_left (h_none j).le (hw0 j)) ?_
    exact ⟨j₀, Finset.mem_univ j₀, mul_lt_mul_of_pos_left (h_none j₀) hj₀⟩
  have h_lhs : ∑ j : κ, w j * β = β := by
    rw [← Finset.sum_mul, hw1, one_mul]
  have h_rhs : ∑ j : κ, w j * inner ℝ v (pts j) = inner ℝ v z := by
    rw [← hw_pts, inner_sum]
    refine Finset.sum_congr rfl fun j _ => ?_
    rw [real_inner_smul_right]
  linarith

/-- If `z` has a convex-hull certificate on each of the `r` blocks and `ω` satisfies uniform
convergence within `1 / (2 s)`, then `z` is a `(1 / (2 s))`-centerpoint of `Q`. -/
theorem certs_and_uc_imp_isCenterpoint {D r s : ℕ} (hD : 1 ≤ D) (hr : 1 ≤ r) (hs : 1 ≤ s)
    {ι : Type} [Fintype ι] [Nonempty ι]
    (Q : ι → EuclideanSpace ℝ (Fin D)) (ω : Fin (r * s) → ι)
    (huc : ∀ H : Set (EuclideanSpace ℝ (Fin D)), IsClosedHalfspace H →
      |(pointCount (fun t : Fin (r * s) => Q (ω t)) H : ℝ) / ((r : ℝ) * (s : ℝ)) -
        (pointCount Q H : ℝ) / (Fintype.card ι : ℝ)| ≤ 1 / (2 * (s : ℝ)))
    {z : EuclideanSpace ℝ (Fin D)}
    (hcerts : ∀ i : Fin r, HasConvexHullCert (fun j : Fin s => Q (ω (blockIdx i j))) z) :
    IsCenterpoint (1 / (2 * (s : ℝ))) Q z := by
  classical
  have h_for_H : ∀ H : Set (EuclideanSpace ℝ (Fin D)), IsClosedHalfspace H → z ∈ H →
      (1 / (2 * (s : ℝ))) * (Fintype.card ι : ℝ) ≤ (pointCount Q H : ℝ) := by
    intro H hH hzH
    have hex : ∀ i : Fin r, ∃ j : Fin s, Q (ω (blockIdx i j)) ∈ H :=
      fun i => exists_mem_halfspace_of_hasConvexHullCert (hcerts i) hH hzH
    let jFn : Fin r → Fin s := fun i => Classical.choose (hex i)
    have hjFn : ∀ i : Fin r, Q (ω (blockIdx i (jFn i))) ∈ H :=
      fun i => Classical.choose_spec (hex i)
    let emb : Fin r ↪ Fin (r * s) :=
      ⟨fun i => blockIdx i (jFn i), by
        intro i₁ i₂ heq
        have hval : i₁.val * s + (jFn i₁).val = i₂.val * s + (jFn i₂).val :=
          congrArg Fin.val heq
        have hj1 : (jFn i₁).val < s := (jFn i₁).isLt
        have hj2 : (jFn i₂).val < s := (jFn i₂).isLt
        exact Fin.ext (by nlinarith)⟩
    have hsub : (Finset.univ : Finset (Fin r)).map emb ⊆
        Finset.univ.filter (fun t : Fin (r * s) => Q (ω t) ∈ H) := by
      intro t ht
      rcases Finset.mem_map.mp ht with ⟨i, _, rfl⟩
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hjFn i⟩
    have hcard_le : r ≤ pointCount (fun t : Fin (r * s) => Q (ω t)) H := by
      unfold pointCount
      calc
        r = ((Finset.univ : Finset (Fin r)).map emb).card := by simp
        _ ≤ (Finset.univ.filter (fun t : Fin (r * s) => Q (ω t) ∈ H)).card :=
            Finset.card_le_card hsub
    have hr_pos : (0 : ℝ) < (r : ℝ) := by exact_mod_cast hr
    have hs_pos : (0 : ℝ) < (s : ℝ) := by exact_mod_cast hs
    have hrs_pos : (0 : ℝ) < (r : ℝ) * (s : ℝ) := mul_pos hr_pos hs_pos
    have hemp_ge : 1 / (s : ℝ) ≤
        (pointCount (fun t : Fin (r * s) => Q (ω t)) H : ℝ) / ((r : ℝ) * (s : ℝ)) := by
      have hr_le : (r : ℝ) ≤ (pointCount (fun t : Fin (r * s) => Q (ω t)) H : ℝ) := by
        exact_mod_cast hcard_le
      have hdiv := div_le_div_of_nonneg_right hr_le hrs_pos.le
      have hcancel : (r : ℝ) / ((r : ℝ) * (s : ℝ)) = 1 / (s : ℝ) := by
        field_simp [hr_pos.ne']
      rwa [hcancel] at hdiv
    have hdiff := (abs_le.mp (huc H hH)).2
    have hhalf : 1 / (s : ℝ) - 1 / (2 * (s : ℝ)) = 1 / (2 * (s : ℝ)) := by ring
    have hpop_ge : 1 / (2 * (s : ℝ)) ≤ (pointCount Q H : ℝ) / (Fintype.card ι : ℝ) := by
      linarith
    have hcard_pos : (0 : ℝ) < (Fintype.card ι : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
    exact (le_div_iff₀ hcard_pos).mp hpop_ge
  let i₀ : Fin D := ⟨0, by omega⟩
  let v₀ : EuclideanSpace ℝ (Fin D) := EuclideanSpace.single i₀ (1 : ℝ)
  have hv₀ : v₀ ≠ 0 := by
    intro h
    have h1 : v₀ i₀ = 1 := by simp [v₀]
    have h0 : v₀ i₀ = 0 := by simp [h]
    linarith
  let H₀ : Set (EuclideanSpace ℝ (Fin D)) := {x | inner ℝ v₀ x ≤ inner ℝ v₀ z}
  have hH₀ : IsClosedHalfspace H₀ := ⟨v₀, hv₀, inner ℝ v₀ z, rfl⟩
  have hzH₀ : z ∈ H₀ := Set.mem_setOf.mpr le_rfl
  let A : Set ℕ := {n : ℕ | ∃ H : Set (EuclideanSpace ℝ (Fin D)),
    IsClosedHalfspace H ∧ z ∈ H ∧ n = pointCount Q H}
  have hA_ne : A.Nonempty := ⟨pointCount Q H₀, H₀, hH₀, hzH₀, rfl⟩
  have hsInf_mem : halfspaceDepth Q z ∈ A := Nat.sInf_mem hA_ne
  rcases hsInf_mem with ⟨H₁, hH₁, hzH₁, heq⟩
  unfold IsCenterpoint
  rw [heq]
  exact h_for_H H₁ hH₁ hzH₁

/-- Good sample predicate on `ω : Fin (r * s) → ι`:
(1) common convex-hull intersection is nonempty, and
(2) every common convex-hull point is a `(1 / (2 s))`-centerpoint of `Q`. -/
def IsGoodCenterSample {D r s : ℕ} {ι : Type} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin D)) (ω : Fin (r * s) → ι) : Prop :=
  (∃ z : EuclideanSpace ℝ (Fin D),
    ∀ i : Fin r, HasConvexHullCert (fun j : Fin s => Q (ω (blockIdx i j))) z) ∧
  (∀ z : EuclideanSpace ℝ (Fin D),
    (∀ i : Fin r, HasConvexHullCert (fun j : Fin s => Q (ω (blockIdx i j))) z) →
    IsCenterpoint (1 / (2 * (s : ℝ))) Q z)

/-- Coordinate marginal union bound on `(Fin r → β)` using a predicate `Q_bad : β → Prop`
(avoiding `DecidableEq β` completely). -/
private theorem pi_exists_bad_card_div_le {r : ℕ} {β : Type*} [Fintype β] [Nonempty β]
    (Q_bad : β → Prop) [DecidablePred Q_bad] {δ : ℝ}
    (hBad : ((Finset.univ.filter Q_bad).card : ℝ) / (Fintype.card β : ℝ) ≤ δ) :
    ((Finset.univ.filter (fun b : Fin r → β => ∃ i : Fin r, Q_bad (b i))).card : ℝ) /
      (Fintype.card (Fin r → β) : ℝ) ≤ (r : ℝ) * δ := by
  have hcoord : ∀ i₀ : Fin r,
      ((Finset.univ.filter (fun b : Fin r → β => Q_bad (b i₀))).card : ℝ) /
        (Fintype.card (Fin r → β) : ℝ) ≤ δ := by
    intro i₀
    let Rest := {i : Fin r // i ≠ i₀} → β
    let e : (Fin r → β) ≃ β × Rest := Equiv.piSplitAt i₀ (fun _ : Fin r => β)
    have hcard_filt :
        (Finset.univ.filter (fun b : Fin r → β => Q_bad (b i₀))).card =
          (Finset.univ.filter Q_bad).card * Fintype.card Rest := by
      rw [← Finset.card_univ (α := Rest), ← Finset.card_product]
      refine Finset.card_bij (fun b _ => e b) ?_ ?_ ?_
      · intro b hb
        exact Finset.mem_product.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp hb).2⟩, Finset.mem_univ _⟩
      · intro b₁ _ b₂ _ heq
        exact e.injective heq
      · rintro ⟨x, g⟩ hxg
        have hx : Q_bad x := (Finset.mem_filter.mp (Finset.mem_product.mp hxg).1).2
        refine ⟨e.symm (x, g), Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, e.apply_symm_apply (x, g)⟩
        have hfst : e.symm (x, g) i₀ = x := by
          change (e (e.symm (x, g))).1 = x
          simp
        rwa [hfst]
    have hcard_tot : Fintype.card (Fin r → β) = Fintype.card β * Fintype.card Rest := by
      rw [Fintype.card_congr e, Fintype.card_prod]
    have hR_pos : (0 : ℝ) < (Fintype.card Rest : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
    rw [hcard_filt, hcard_tot]
    push_cast
    rw [mul_div_mul_right _ _ hR_pos.ne']
    exact hBad
  have hsub :
      Finset.univ.filter (fun b : Fin r → β => ∃ i : Fin r, Q_bad (b i)) ⊆
        (Finset.univ : Finset (Fin r)).biUnion (fun i =>
          Finset.univ.filter (fun b : Fin r → β => Q_bad (b i))) := by
    intro b hb
    rcases (Finset.mem_filter.mp hb).2 with ⟨i, hi⟩
    exact Finset.mem_biUnion.mpr ⟨i, Finset.mem_univ i, Finset.mem_filter.mpr ⟨Finset.mem_univ b, hi⟩⟩
  have hcard_le :
      (Finset.univ.filter (fun b : Fin r → β => ∃ i : Fin r, Q_bad (b i))).card ≤
        ∑ i : Fin r, (Finset.univ.filter (fun b : Fin r → β => Q_bad (b i))).card :=
    (Finset.card_le_card hsub).trans Finset.card_biUnion_le
  have htot_pos : (0 : ℝ) < (Fintype.card (Fin r → β) : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have hdiv_le :
      ((Finset.univ.filter (fun b : Fin r → β => ∃ i : Fin r, Q_bad (b i))).card : ℝ) /
        (Fintype.card (Fin r → β) : ℝ) ≤
      (∑ i : Fin r, ((Finset.univ.filter (fun b : Fin r → β => Q_bad (b i))).card : ℝ)) /
        (Fintype.card (Fin r → β) : ℝ) := by
    refine div_le_div_of_nonneg_right ?_ htot_pos.le
    exact_mod_cast hcard_le
  rw [Finset.sum_div] at hdiv_le
  calc
    ((Finset.univ.filter (fun b : Fin r → β => ∃ i : Fin r, Q_bad (b i))).card : ℝ) /
        (Fintype.card (Fin r → β) : ℝ)
        ≤ ∑ i : Fin r,
            ((Finset.univ.filter (fun b : Fin r → β => Q_bad (b i))).card : ℝ) /
              (Fintype.card (Fin r → β) : ℝ) := hdiv_le
    _ ≤ ∑ _i : Fin r, δ := Finset.sum_le_sum (fun i _ => hcoord i)
    _ = (r : ℝ) * δ := by simp

private theorem bad1_prob_le_generic
    {r s : ℕ} {φ : ℝ} {ι : Type} [Fintype ι] [Nonempty ι]
    (P_block : (Fin s → ι) → Prop) [DecidablePred P_block]
    (hr : 1 ≤ r) (hs : 1 ≤ s)
    (h_net_one :
      1 - φ / (2 * (r : ℝ)) ≤
        ((Finset.univ.filter P_block).card : ℝ) /
          (Fintype.card (Fin s → ι) : ℝ)) :
    ((Finset.univ.filter (fun ω : Fin (r * s) → ι =>
        ∃ i : Fin r, ¬ P_block (fun j : Fin s => ω (blockIdx i j)))).card : ℝ) /
      (Fintype.card (Fin (r * s) → ι) : ℝ) ≤ φ / 2 := by
  have hr_pos : (0 : ℝ) < (r : ℝ) := by exact_mod_cast hr
  have hBadBlock :
      ((Finset.univ.filter (fun sample : Fin s → ι => ¬ P_block sample)).card : ℝ) /
        (Fintype.card (Fin s → ι) : ℝ) ≤ φ / (2 * (r : ℝ)) := by
    have hsum_nat :
        (Finset.univ.filter P_block).card +
          (Finset.univ.filter (fun sample : Fin s → ι => ¬ P_block sample)).card =
          Fintype.card (Fin s → ι) := by
      rw [← Finset.card_univ]
      exact Finset.card_filter_add_card_filter_not _
    have hN_pos : (0 : ℝ) < (Fintype.card (Fin s → ι) : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
    have hsum_real :
        ((Finset.univ.filter P_block).card : ℝ) / (Fintype.card (Fin s → ι) : ℝ) +
          ((Finset.univ.filter (fun sample : Fin s → ι => ¬ P_block sample)).card : ℝ) /
            (Fintype.card (Fin s → ι) : ℝ) = 1 := by
      rw [← add_div, ← Nat.cast_add, hsum_nat, div_self hN_pos.ne']
    linarith
  have hcard_eq :
      (Finset.univ.filter (fun ω : Fin (r * s) → ι =>
        ∃ i : Fin r, ¬ P_block (fun j : Fin s => ω (blockIdx i j)))).card =
      (Finset.univ.filter (fun b : Fin r → Fin s → ι =>
        ∃ i : Fin r, ¬ P_block (b i))).card := by
    refine Finset.card_bij (fun ω _ => blockEquiv r s hs ι ω) ?_ ?_ ?_
    · intro ω hω
      rcases (Finset.mem_filter.mp hω).2 with ⟨i, hi⟩
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ⟨i, ?_⟩⟩
      dsimp only
      rwa [blockEquiv_apply]
    · intro ω₁ _ ω₂ _ heq
      exact (blockEquiv r s hs ι).injective heq
    · intro b hb
      rcases (Finset.mem_filter.mp hb).2 with ⟨i, hi⟩
      refine ⟨(blockEquiv r s hs ι).symm b, ?_, (blockEquiv r s hs ι).apply_symm_apply b⟩
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ⟨i, ?_⟩⟩
      rw [← blockEquiv_apply r s hs ι ((blockEquiv r s hs ι).symm b) i]
      have hbi : blockEquiv r s hs ι ((blockEquiv r s hs ι).symm b) i = b i :=
        congrFun ((blockEquiv r s hs ι).apply_symm_apply b) i
      rwa [hbi]
  have hcard_tot : Fintype.card (Fin (r * s) → ι) = Fintype.card (Fin r → Fin s → ι) :=
    Fintype.card_congr (blockEquiv r s hs ι)
  rw [hcard_eq, hcard_tot]
  have hrδ : (r : ℝ) * (φ / (2 * (r : ℝ))) = φ / 2 := by
    field_simp [hr_pos.ne']
  exact (pi_exists_bad_card_div_le (r := r) (fun sample => ¬ P_block sample) hBadBlock).trans_eq hrδ

private theorem union_goodCenterSample_prob_aux
    (h_cp : S_cit_centerpoint_thm)
    {D r s : ℕ} (hD : 1 ≤ D) (hr : 1 ≤ r) (hs : 1 ≤ s)
    {φ : ℝ} {ι : Type} [Fintype ι] [Nonempty ι]
    (Q : ι → EuclideanSpace ℝ (Fin D))
    (hBad1_le :
      ((Finset.univ.filter (fun ω : Fin (r * s) → ι =>
          ∃ i : Fin r,
            ¬ IsIndexedHalfspaceNet (1 / ((D : ℝ) + 1)) Q (fun j : Fin s => ω (blockIdx i j)))).card : ℝ) /
        (Fintype.card (Fin (r * s) → ι) : ℝ) ≤ φ / 2)
    (h_vc_card :
      1 - φ / 2 ≤
        ((Finset.univ.filter (fun ω : Fin (r * s) → ι =>
            (⨆ H : {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H},
              |(pointCount (fun t : Fin (r * s) => Q (ω t)) H.1 : ℝ) / ((r : ℝ) * (s : ℝ)) -
                (pointCount Q H.1 : ℝ) / (Fintype.card ι : ℝ)|) ≤ 1 / (2 * (s : ℝ)))).card : ℝ) /
          (Fintype.card (Fin (r * s) → ι) : ℝ)) :
    1 - φ ≤
      ((Finset.univ.filter (fun ω : Fin (r * s) → ι =>
          IsGoodCenterSample Q ω)).card : ℝ) /
        (Fintype.card (Fin (r * s) → ι) : ℝ) := by
  let μ : Set (EuclideanSpace ℝ (Fin D)) → ℝ :=
    fun H => (pointCount Q H : ℝ) / (Fintype.card ι : ℝ)
  let μ_hat : (Fin (r * s) → ι) → Set (EuclideanSpace ℝ (Fin D)) → ℝ :=
    fun ω H => (pointCount (fun t : Fin (r * s) => Q (ω t)) H : ℝ) / ((r : ℝ) * (s : ℝ))
  let GoodUC : (Fin (r * s) → ι) → Prop := fun ω =>
    (⨆ H : {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H},
      |μ_hat ω H.1 - μ H.1|) ≤ 1 / (2 * (s : ℝ))
  let Bad1 : Finset (Fin (r * s) → ι) :=
    Finset.univ.filter (fun ω : Fin (r * s) → ι =>
      ∃ i : Fin r, ¬ IsIndexedHalfspaceNet (1 / ((D : ℝ) + 1)) Q (fun j : Fin s => ω (blockIdx i j)))
  let Bad2 : Finset (Fin (r * s) → ι) :=
    Finset.univ.filter (fun ω : Fin (r * s) → ι => ¬ GoodUC ω)
  have hN_pos : (0 : ℝ) < (Fintype.card (Fin (r * s) → ι) : ℝ) :=
    Nat.cast_pos.mpr Fintype.card_pos
  have hBad2_le : (Bad2.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) ≤ φ / 2 := by
    let Good2 := Finset.univ.filter (fun ω : Fin (r * s) → ι => GoodUC ω)
    have hsum_nat : Good2.card + Bad2.card = Fintype.card (Fin (r * s) → ι) := by
      rw [← Finset.card_univ]
      exact Finset.card_filter_add_card_filter_not _
    have hsum_real :
        (Good2.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) +
          (Bad2.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) = 1 := by
      rw [← add_div, ← Nat.cast_add, hsum_nat, div_self hN_pos.ne']
    have hvc' : 1 - φ / 2 ≤ (Good2.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) := by
      exact h_vc_card
    linarith
  let BadTot : Finset (Fin (r * s) → ι) :=
    Finset.univ.filter (fun ω : Fin (r * s) → ι => ¬ IsGoodCenterSample Q ω)
  have hBadTot_sub : BadTot ⊆ Bad1 ∪ Bad2 := by
    intro ω hω
    have hnot : ¬ IsGoodCenterSample Q ω := (Finset.mem_filter.mp hω).2
    by_contra h_neither
    rw [Finset.mem_union, not_or] at h_neither
    rcases h_neither with ⟨hnot1, hnot2⟩
    have hn1 : ∀ i : Fin r,
        IsIndexedHalfspaceNet (1 / ((D : ℝ) + 1)) Q (fun j : Fin s => ω (blockIdx i j)) := by
      by_contra hex
      push_neg at hex
      exact hnot1 (Finset.mem_filter.mpr ⟨Finset.mem_univ ω, hex⟩)
    have hn2 : GoodUC ω := by
      by_contra hnm
      exact hnot2 (Finset.mem_filter.mpr ⟨Finset.mem_univ ω, hnm⟩)
    have h_bdd : BddAbove (Set.range
        (fun H : {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H} =>
          |μ_hat ω H.1 - μ H.1|)) := by
      refine ⟨1, ?_⟩
      rintro _ ⟨H, rfl⟩
      have hN_ge1 : 1 ≤ r * s := Nat.mul_pos hr hs
      have hemp_eq : μ_hat ω H.1 = UL.Proof_cit_vc71_halfspace_uc.empFreq Q ω H.1 := by
        simp [μ_hat, UL.Proof_cit_vc71_halfspace_uc.empFreq, Nat.cast_mul]
      have hpop_eq : μ H.1 = UL.Proof_cit_vc71_halfspace_uc.popFreq Q H.1 := rfl
      dsimp only
      rw [hemp_eq, hpop_eq]
      obtain ⟨he0, he1⟩ := UL.Proof_cit_vc71_halfspace_uc.empFreq_mem_Icc hN_ge1 Q ω H.1
      obtain ⟨hp0, hp1⟩ := UL.Proof_cit_vc71_halfspace_uc.popFreq_mem_Icc Q H.1
      exact abs_le.mpr ⟨by linarith, by linarith⟩
    have huc_forall : ∀ H : Set (EuclideanSpace ℝ (Fin D)), IsClosedHalfspace H →
        |μ_hat ω H - μ H| ≤ 1 / (2 * (s : ℝ)) :=
      fun H hH => (le_ciSup h_bdd ⟨H, hH⟩).trans hn2
    exact hnot ⟨indexedNets_imp_exists_convexHullCert h_cp hD Q ω hn1,
      fun z hcerts => certs_and_uc_imp_isCenterpoint hD hr hs Q ω huc_forall hcerts⟩
  have hBadTot_card : BadTot.card ≤ Bad1.card + Bad2.card :=
    (Finset.card_le_card hBadTot_sub).trans (Finset.card_union_le Bad1 Bad2)
  have hBadTot_div :
      (BadTot.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) ≤ φ := by
    have h1 : (BadTot.card : ℝ) ≤ (Bad1.card : ℝ) + (Bad2.card : ℝ) := by
      exact_mod_cast hBadTot_card
    have h2 : (BadTot.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) ≤
        (Bad1.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) +
          (Bad2.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) := by
      rw [← add_div]
      exact div_le_div_of_nonneg_right h1 hN_pos.le
    have hb1 : (Bad1.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) ≤ φ / 2 := hBad1_le
    linarith
  let GoodTot := Finset.univ.filter (fun ω : Fin (r * s) → ι => IsGoodCenterSample Q ω)
  have hsum_nat : GoodTot.card + BadTot.card = Fintype.card (Fin (r * s) → ι) := by
    rw [← Finset.card_univ]
    exact Finset.card_filter_add_card_filter_not _
  have hsum_real :
      (GoodTot.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) +
        (BadTot.card : ℝ) / (Fintype.card (Fin (r * s) → ι) : ℝ) = 1 := by
    rw [← add_div, ← Nat.cast_add, hsum_nat, div_self hN_pos.ne']
  linarith

theorem goodCenterSample_prob_ge
    (h_cp : S_cit_centerpoint_thm)
    {C_HW : ℝ} (hCHW0 : 0 < C_HW)
    (h_hw : ∀ (D : ℕ), 1 ≤ D →
      ∀ (ι : Type) [Fintype ι] [Nonempty ι] (P : ι → EuclideanSpace ℝ (Fin D)),
      ∀ (α : ℝ), 0 < α → α ≤ 1 →
      ∀ (δ : ℝ), 0 < δ → δ < 1 →
      ∀ (s : ℕ),
        Nat.ceil (C_HW * α⁻¹ * (((D : ℝ) + 1) * Real.log (2 / α) + Real.log (2 / δ))) ≤ s →
        (1 - δ ≤ ((Finset.univ.filter (fun sample : Fin s → ι =>
            IsIndexedHalfspaceNet α P sample)).card : ℝ) /
          (Fintype.card (Fin s → ι) : ℝ)) ∧
        (s ≤ Fintype.card ι →
          1 - δ ≤ ((((Finset.univ : Finset ι).powersetCard s).filter (fun S : Finset ι =>
              IsHalfspaceNet α P S)).card : ℝ) /
            (((Finset.univ : Finset ι).powersetCard s).card : ℝ)))
    {C₀ : ℝ}
    (h_vc : ∀ (D : ℕ), 1 ≤ D →
      ∀ (ι : Type) [Fintype ι] [Nonempty ι] [MeasurableSpace ι] [DiscreteMeasurableSpace ι]
        (P : ι → EuclideanSpace ℝ (Fin D)),
      ∀ (r s : ℕ), 1 ≤ r → 1 ≤ s →
      ∀ (φ : ℝ), 0 < φ → φ < 1 →
        C₀ * (s : ℝ) ^ 2 * (((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ)) ≤
          (r : ℝ) * (s : ℝ) →
        let μ : Set (EuclideanSpace ℝ (Fin D)) → ℝ :=
          fun H => (pointCount P H : ℝ) / (Fintype.card ι : ℝ)
        let μ_hat : (Fin (r * s) → ι) → Set (EuclideanSpace ℝ (Fin D)) → ℝ :=
          fun ω H => (pointCount (fun t : Fin (r * s) => P (ω t)) H : ℝ) / ((r : ℝ) * (s : ℝ))
        1 - φ / 2 ≤
          (MeasureTheory.Measure.pi
            (fun _ : Fin (r * s) => (PMF.uniformOfFintype ι).toMeasure)).real
            {ω : Fin (r * s) → ι |
              (⨆ H : {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H},
                |μ_hat ω H.1 - μ H.1|) ≤ 1 / (2 * (s : ℝ))})
    {K : ℕ} (hK : 1 ≤ K) (hCHW : C_HW ≤ (K : ℝ)) (hC0 : C₀ ≤ (K : ℝ))
    {D : ℕ} (hD : 1 ≤ D) {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2)
    {ι : Type} [Fintype ι] [Nonempty ι]
    (Q : ι → EuclideanSpace ℝ (Fin D)) :
    let k : ℕ := Nat.ceil (Real.logb 2 (1 / φ))
    let s : ℕ := sVal K D k
    let r : ℕ := rVal K D k
    1 - φ ≤
      ((Finset.univ.filter (fun ω : Fin (r * s) → ι =>
          IsGoodCenterSample Q ω)).card : ℝ) /
        (Fintype.card (Fin (r * s) → ι) : ℝ) := by
  have hs_ceil := hw87_s_bound hK hCHW0 hCHW hD hφ0 hφ1
  have hrs_vc := vc71_rs_bound hK hC0 hD hφ0 hφ1
  dsimp only at hs_ceil hrs_vc ⊢
  generalize hs_eq : sVal K D (Nat.ceil (Real.logb 2 (1 / φ))) = s at hs_ceil hrs_vc ⊢
  generalize hr_eq : rVal K D (Nat.ceil (Real.logb 2 (1 / φ))) = r at hs_ceil hrs_vc ⊢
  have hs : 1 ≤ s := hs_eq ▸ sVal_pos hK
  have hr : 1 ≤ r := hr_eq ▸ rVal_pos hK
  have hα0 : (0 : ℝ) < 1 / ((D : ℝ) + 1) := by positivity
  have hα1 : (1 : ℝ) / ((D : ℝ) + 1) ≤ 1 := by
    rw [div_le_one (by positivity)]
    linarith
  have hδ0 : 0 < φ / (2 * (r : ℝ)) := by positivity
  have hδ1 : φ / (2 * (r : ℝ)) < 1 := by
    rw [div_lt_one (by positivity)]
    have : (1 : ℝ) ≤ (r : ℝ) := by exact_mod_cast hr
    linarith
  have h_net_one := (h_hw D hD ι Q _ hα0 hα1 _ hδ0 hδ1 s hs_ceil).1
  have hBad1 := bad1_prob_le_generic (IsIndexedHalfspaceNet (1 / ((D : ℝ) + 1)) Q) hr hs h_net_one
  letI : MeasurableSpace ι := ⊤
  haveI : DiscreteMeasurableSpace ι := ⟨fun _ => trivial⟩
  have h_vc_prob := h_vc D hD ι Q r s hr hs φ hφ0 (by linarith) hrs_vc
  dsimp only at h_vc_prob
  rw [UL.Proof_cit_vc71_halfspace_uc.pi_uniform_real_eq_card_div (r * s) ι _] at h_vc_prob
  exact union_goodCenterSample_prob_aux h_cp hD hr hs Q hBad1 h_vc_prob

end UL.Proof_lem_A_1
