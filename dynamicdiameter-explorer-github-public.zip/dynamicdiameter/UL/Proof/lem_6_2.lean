import UL.Stmt.lem_6_2
import UL.Proof.lem_6_2.H1
import UL.Proof.lem_6_2.H2
import UL.Proof.lem_6_2.H3
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_6_2 : S_lem_6_2 := by
  unfold S_lem_6_2
  intro h_min h_max hh_min hh_le hh_max
  refine ⟨Real.exp (-3) / (2 * Real.pi), by positivity, ?_⟩
  intro d hd h x t hh_lo hh_hi hx_lo hx_hi ht
  have hh0 : 0 < h := lt_of_lt_of_le hh_min hh_lo
  have hh1 : h < 1 := lt_of_le_of_lt hh_hi hh_max
  have hx0 : 0 < x := lt_of_lt_of_le hh0 hx_lo
  have ht0 : 0 < t := by linarith
  let p_u : ℝ := Proof_lem_6_2.stdNormal.real (Set.Ici t)
  let p_q : ℝ := Proof_lem_6_2.stdNormal.real (Set.Ici (x * t))
  let p₁ : ℝ := (Real.exp (-3) / (2 * Real.pi)) * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2))
  let p₂ : ℝ := Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))
  refine ⟨p_u, p_q, p₁, p₂, ?_, ?_, ?_, le_rfl, le_rfl⟩
  · refine ⟨⟨hd, hh0, hh1, hx_lo, hx_hi, ht⟩, ?_, ?_, ?_, ?_⟩
    · intro p hp
      exact Proof_lem_6_2.gaussianDataProb_eq t p hp
    · intro z hz
      exact Proof_lem_6_2.gaussianQueryProb_eq x t z hz
    · intro p z hp hz hpz
      rw [Proof_lem_6_2.gaussianJointProb_eq_wedge x t p z hp hz]
      exact Proof_lem_6_2.gaussianWedge_ge_of_ge hh0 hh1 hx_lo hx_hi ht hpz
    · intro p z hp hz hpz
      rw [Proof_lem_6_2.gaussianJointProb_eq_wedge x t p z hp hz]
      exact Proof_lem_6_2.gaussianWedge_le_of_nonpos hpz hx0 ht0
  · exact Proof_lem_6_2.stdGaussian_tail_le ht0.le
  · refine (Proof_lem_6_2.stdGaussian_tail_le (mul_pos hx0 ht0).le).trans_eq ?_
    congr 1
    ring

end UL
