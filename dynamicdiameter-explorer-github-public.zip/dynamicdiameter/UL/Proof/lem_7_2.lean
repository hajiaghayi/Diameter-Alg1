import UL.Stmt.lem_7_2
import UL.Stmt.cit_hpj19_thm18
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_chain_contraction
import UL.Stmt.clm_5_1_mc_baseline
import UL.Stmt.lem_5_2
import UL.Stmt.claim_C_2_scans
import UL.Stmt.lem_C_2
import UL.Stmt.claim_C_2_space_reclaim
import UL.Stmt.clm_7_2_chain_schedule
import UL.Stmt.clm_7_3_failure_budget
import UL.Proof.lem_7_2.CG01_NodeSpec0
import UL.Proof.lem_7_2.CG03_JobTickA3c3
import UL.Proof.lem_7_2.CG14_MidTickA1
import UL.Proof.lem_7_2.CG18_JobTickA2

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Syntactic `preservesPoolWords` Lemmas for Active-Uncut Single-Node Subroutines -/

@[simp] lemma cg01_preservesPoolWords_boxWriteW_eval (M_box t : ℕ) (idxE valE : IntExpr) :
    preservesPoolWords (boxWriteW M_box t idxE valE) =
      (!decide (t = 0) && !decide (t = 2) && !decide (t = 3) &&
       !(decide (t = 1) && !isLitGe3 idxE)) := by
  simp [preservesPoolWords, boxWriteW, writesWordTag, writesWord1Low]

@[simp] lemma cg01_preservesPoolWords_updLeafSegSlotStmt (K M_box : ℕ) :
    preservesPoolWords (updLeafSegSlotStmt K M_box) = true := by
  unfold updLeafSegSlotStmt updParentStepStmt combineSegChildrenStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_updSegZeroStmt (K M_box : ℕ) :
    preservesPoolWords (updSegZeroStmt K M_box) = true := by
  unfold updSegZeroStmt
  simp

@[simp] lemma cg01_preservesPoolWords_updSegCenterStmt (d K M_box rTag : ℕ) :
    preservesPoolWords (updSegCenterStmt d K M_box rTag) = true := by
  unfold updSegCenterStmt loadHeapCoordsToLocalStmt distSqLocalStmt
  simp

@[simp] lemma cg01_preservesPoolWords_updJobLevelFourSlotsStmt (d K M_box : ℕ) :
    preservesPoolWords (updJobLevelFourSlotsStmt d K M_box) = true := by
  unfold updJobLevelFourSlotsStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_propagateAllJobLevelsStmt (d D₀ K M_box : ℕ) :
    preservesPoolWords (propagateAllJobLevelsStmt d D₀ K M_box) = true := by
  unfold propagateAllJobLevelsStmt propagateOneJobLevelIterStmt propagateJobLevelStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_selectByRankSegStmt (K : ℕ) :
    preservesPoolWords (selectByRankSegStmt K) = true := by
  unfold selectByRankSegStmt selectRankStepStmt
  simp

@[simp] lemma cg01_preservesPoolWords_readSlotPtToLocalStmt (d n : ℕ) (off : ℤ) :
    preservesPoolWords (readSlotPtToLocalStmt d n off) = true := by
  unfold readSlotPtToLocalStmt loadHeapCoordsToLocalStmt
  simp

@[simp] lemma cg01_preservesPoolWords_resetSegSlotStmt (M_box : ℕ) (sE : IntExpr) :
    preservesPoolWords (resetSegSlotStmt M_box sE) = true := by
  unfold resetSegSlotStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_stepBuildJobLevelStmt (d n D K K_batch M_box : ℕ) :
    preservesPoolWords (stepBuildJobLevelStmt d n D K K_batch M_box) = true := by
  unfold stepBuildJobLevelStmt phase0OneIterStmt phase0FinishStmt
    phase1OneIterStmt phase1SelectScopeStmt phase1FinishStmt findSuccSegStmt countLtStepStmt
    distSqLocalStmt loadHeapCoordsToLocalStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_propAndBuildActiveJobStmt {d n M_box : ℕ} (p : P46Params d n) :
    preservesPoolWords (propAndBuildActiveJobStmt d n M_box p) = true := by
  unfold propAndBuildActiveJobStmt stepBuildAndNormLastStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_freshAllocFourSlotsStmt (D₀ NumSlots M_box : ℕ) :
    preservesPoolWords (freshAllocFourSlotsStmt D₀ NumSlots M_box) = true := by
  unfold freshAllocFourSlotsStmt gcSlotInUseStmt gcMarkJobLevelStmt allocMarkAndResetSlotStmt allocFreeSlotStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_freshAllocFiveSlotsStmt (D₀ NumSlots M_box : ℕ) :
    preservesPoolWords (freshAllocFiveSlotsStmt D₀ NumSlots M_box) = true := by
  unfold freshAllocFiveSlotsStmt allocMarkAndResetSlotStmt allocFreeSlotStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_freezeSlot26_1Stmt (M_box : ℕ) :
    preservesPoolWords (freezeSlot26_1Stmt M_box) = true := by
  unfold freezeSlot26_1Stmt freezeSlotStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_readSlotCardTo24Stmt (K M_box : ℕ) (sE : IntExpr) :
    preservesPoolWords (readSlotCardTo24Stmt K M_box sE) = true := by
  unfold readSlotCardTo24Stmt cardAndMaxSegSlotStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_hpjFreezeRunInitStmt {d n M_box : ℕ} (p : P46Params d n) :
    preservesPoolWords (hpjFreezeRunInitStmt d n M_box p) = true := by
  unfold hpjFreezeRunInitStmt provisionalFromHPJStmt initJobLevelStmt
    loadHeapCoordsToLocalStmt storeLocalCoordsToHeapStmt distSqLocalStmt
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_idleAffectedNodeStmt {d n M_box : ℕ} (p : P46Params d n) :
    preservesPoolWords (idleAffectedNodeStmt d n M_box defaultChainHdrCfg p) = true := by
  unfold idleAffectedNodeStmt launchPendingJobAtRStmt defaultChainHdrCfg HdrField.writeW
  simp [isLitGe3]

@[simp] lemma cg01_preservesPoolWords_cg01EndActionJobStmt {d n M_box : ℕ} (p : P46Params d n) :
    preservesPoolWords (cg01EndActionJobStmt d n M_box defaultChainHdrCfg p) = true := by
  unfold cg01EndActionJobStmt cg01OpenNewLevelAtRStmt cg01OpenLevelPrepStmt
    defaultChainHdrCfg HdrField.writeW
  simp [isLitGe3]

/-! ### 2. Full Active-Uncut Single-Node Statement & `ActiveUncutNodeSpec` Instance -/

def cg01ActiveUncutNodeStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  let cfg := defaultChainHdrCfg
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let dummyHpj : ArithRAMStmt := seqList [
    boxWriteW M_box 26 (.lit 0) (.lit 0),
    runHPJOnSlotStmt d n M_box p
  ]
  .ite (.intEq (cfg.snAffected.readE rE) (.lit 0))
    dummyHpj
    (.ite (.intEq (.readHeap 16 rE) (.lit 0))
      (idleAffectedNodeStmt d n M_box cfg p)
      (seqList [
        propAndBuildActiveJobStmt d n M_box p,
        cg01EndActionJobStmt d n M_box cfg p,
        activeJobDeadlineStmt d p.D₀ M_box cfg
      ]))

noncomputable def cg01ActiveUncutNodeCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  let cfg := defaultChainHdrCfg
  30 + max (hpjCallCost d n p + 25)
    (20 + max (idleAffectedNodeCost d n cfg p)
      (propAndBuildActiveJobCost p + cg01EndActionJobCost d n p +
       activeJobDeadlineCost d p.D₀))

theorem boxSafe_cg01ActiveUncutNodeStmt {d n M_box : ℕ} (p : P46Params d n) :
    BoxSafeOuter 28 M_box (cg01ActiveUncutNodeStmt d n M_box p) := by
  have hV : defaultChainHdrCfg.Valid 28 := valid_defaultChainHdrCfg le_rfl
  unfold cg01ActiveUncutNodeStmt
  refine .ite _ (.seq (.boxW (by omega) _ _) (boxSafe_runHPJOnSlotStmt le_rfl p)) ?_
  refine .ite _ (boxSafe_idleAffectedNodeStmt hV p) ?_
  exact .seq (boxSafe_propAndBuildActiveJobStmt le_rfl p)
    (.seq (boxSafe_cg01EndActionJobStmt hV p)
      (boxSafe_activeJobDeadlineStmt hV d p.D₀))

theorem preservesPoolWords_cg01ActiveUncutNodeStmt {d n M_box : ℕ} (p : P46Params d n) :
    preservesPoolWords (cg01ActiveUncutNodeStmt d n M_box p) = true := by
  unfold cg01ActiveUncutNodeStmt
  simp [preservesPoolWords_activeJobDeadlineStmt]

theorem cg01ActiveUncutNodeCost_le {d n : ℕ} (p : P46Params d n) :
    cg01ActiveUncutNodeCost d n p ≤ 2 * cg01MaxSingleNodeCost d n p := by
  unfold cg01ActiveUncutNodeCost cg01MaxSingleNodeCost
    idleAffectedNodeCost propAndBuildActiveJobCost
    cg01EndActionJobCost cg01OpenNewLevelCost activeJobDeadlineCost
    freshAllocFiveCost hpjFreezeRunInitCost
  dsimp only
  omega

/-- Branch 3 full execution: `propAndBuildActiveJobStmt ; cg01EndActionJobStmt ; activeJobDeadlineStmt`. -/
theorem exec_cg01ActiveJobBranch
    (h_lem_5_1 : S_lem_5_1) (h_lem_C_2 : S_lem_C_2)
    (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    (hcfg : ctx.cfg = defaultChainHdrCfg)
    {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k)
    {g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩)}
    {m : ArithRAMMemory}
    (hpop : m.popDepth 0 = m)
    (hw13 : wRead m 26 13 = (ctx.opH : ℤ))
    (hw14 : wRead m 26 14 = (if ctx.ins then 1 else 0))
    (hw15 : wRead m 26 15 = (i : ℤ))
    (hU : MidLoopUncut ctx gFlag i m)
    (haff : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = true)
    (hsome : ctx.st₀.ownedJob ⟨i, hi⟩ = some g₀) :
    RandExecBad inp
      (seqList [
        propAndBuildActiveJobStmt ctx.d ctx.n ctx.M_box ctx.p,
        cg01EndActionJobStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p,
        activeJobDeadlineStmt ctx.d ctx.p.D₀ ctx.M_box ctx.cfg
      ])
      ctx.p.B_hpj m
      (fun m' =>
        wRead m' 0 0 = wRead m 0 0 ∧
        wRead m' 26 13 = wRead m 26 13 ∧
        wRead m' 26 14 = wRead m 26 14 ∧
        wRead m' 26 15 = (i : ℤ) ∧
        wRead m' 26 28 = wRead m 26 28 ∧
        (MidLoopUncut ctx false (i + 1) m' ∨ MidLoopCut ctx false m'))
      (fun m' =>
        gFlag = true → (MidLoopUncut ctx true (i + 1) m' ∨ MidLoopCut ctx true m'))
      (2 * ctx.p.φ_ev)
      (propAndBuildActiveJobCost ctx.p + cg01EndActionJobCost ctx.d ctx.n ctx.p +
       activeJobDeadlineCost ctx.d ctx.p.D₀) := by
  classical
  rcases exec_propAndBuildActiveJobStmt ctx inp hi hw13 hw14 hw15 hU haff hsome
    with ⟨m₁, hd_pb, e0_1, e13_1, e14_1, e15_1, e28_1, pb⟩
  have hEnd := exec_cg01EndActionJobStmt h_lem_5_1 ctx inp hi e15_1 pb haff hsome
  have hEndDead : RandExecBad inp
      (.seq (cg01EndActionJobStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p)
            (activeJobDeadlineStmt ctx.d ctx.p.D₀ ctx.M_box ctx.cfg))
      ctx.p.B_hpj m₁
      (fun m' =>
        wRead m' 0 0 = wRead m 0 0 ∧
        wRead m' 26 13 = wRead m 26 13 ∧
        wRead m' 26 14 = wRead m 26 14 ∧
        wRead m' 26 15 = (i : ℤ) ∧
        wRead m' 26 28 = wRead m 26 28 ∧
        (MidLoopUncut ctx false (i + 1) m' ∨ MidLoopCut ctx false m'))
      (fun m' =>
        gFlag = true → (MidLoopUncut ctx true (i + 1) m' ∨ MidLoopCut ctx true m'))
      (2 * ctx.p.φ_ev)
      (cg01EndActionJobCost ctx.d ctx.n ctx.p + activeJobDeadlineCost ctx.d ctx.p.D₀) := by
    refine RandExecBad.seq_det_right pb.hpop hEnd ?_
    intro m₂ hpop₂ ⟨e0_2, e13_2, e14_2, e15_2, e28_2, ⟨g_f, hSt_f⟩⟩
    by_cases hG2 : gFlag = true ∧ ∃ g_t, PostEndActionJobState ctx true i hi m₂ g_t
    · rcases hG2 with ⟨hgF, g_t, hSt_t⟩
      rcases exec_activeJobDeadlineStmt h_lem_C_2 ctx inp hcfg hi hpop₂ e15_2 hSt_t
        with ⟨m', hd_dl, hpop', d0, d13, d14, d15, d28, hor_f, hor_t⟩
      exact ⟨m', hd_dl, hpop',
        ⟨d0.trans (e0_2.trans e0_1),
         d13.trans (e13_2.trans (e13_1.trans hw13.symm)),
         d14.trans (e14_2.trans (e14_1.trans hw14.symm)),
         d15,
         d28.trans (e28_2.trans e28_1),
         hor_f⟩,
        fun _ _ => hor_t rfl⟩
    · rcases exec_activeJobDeadlineStmt h_lem_C_2 ctx inp hcfg hi hpop₂ e15_2 hSt_f
        with ⟨m', hd_dl, hpop', d0, d13, d14, d15, d28, hor_f, _⟩
      exact ⟨m', hd_dl, hpop',
        ⟨d0.trans (e0_2.trans e0_1),
         d13.trans (e13_2.trans (e13_1.trans hw13.symm)),
         d14.trans (e14_2.trans (e14_1.trans hw14.symm)),
         d15,
         d28.trans (e28_2.trans e28_1),
         hor_f⟩,
        fun hg_imp hgF => False.elim (hG2 ⟨hgF, hg_imp hgF⟩)⟩
  exact (RandExecBad.seq_det_left hpop pb.hpop hd_pb hEndDead).mono
    (fun _ h => h) (fun _ _ h => h) le_rfl (by omega)

/-- Concrete instantiation of `ActiveUncutNodeSpec`! -/
noncomputable def cg01BuildActiveUncutNodeSpec
    (h_lem_5_1 : S_lem_5_1) (h_lem_C_2 : S_lem_C_2)
    (d n : ℕ) (p : P46Params d n) :
    ActiveUncutNodeSpec d n (p46BoxSize d n p) p where
  nodeStmt := cg01ActiveUncutNodeStmt d n (p46BoxSize d n p) p
  C_node := cg01ActiveUncutNodeCost d n p
  hBoxSafe := boxSafe_cg01ActiveUncutNodeStmt p
  hPresPool := preservesPoolWords_cg01ActiveUncutNodeStmt p
  hExecNode := by
    intro ctx inp gFlag i hi m _ hM hcfg hd hn _ hp_heq hpop hw13 hw14 hw15 _ hU
    subst hd; subst hn
    cases hp_heq
    rw [← hM]
    let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
    let cfg := defaultChainHdrCfg
    let rE : IntExpr := .readHeap 26 (.lit 15)
    let dummyHpj : ArithRAMStmt := seqList [
      boxWriteW ctx.M_box 26 (.lit 0) (.lit 0),
      runHPJOnSlotStmt ctx.d ctx.n ctx.M_box ctx.p
    ]
    have hTodo_i := (hU.2.2.2.2.2.2.2.2.choose_spec.2.2.2.2.2.2.2 r_fin le_rfl)
    have hw_aff_i : wRead m cfg.snAffected.tag (cfg.snAffected.idx i : ℤ) =
        (if ctx.aff r_fin.castSucc then 1 else 0) := by
      simpa [cfg, hcfg] using hTodo_i.1
    let cAff : ArithCondExpr := .intEq (cfg.snAffected.readE rE) (.lit 0)
    have hcAff_ops : condExprOps cAff ≤ 30 := by
      simp [cAff, cfg, defaultChainHdrCfg, HdrField.readE, HdrField.idxE, rE, condExprOps, intExprOps]
    have hAff_eval : iValAt 0 inp m (cfg.snAffected.readE rE) =
        (if ctx.aff r_fin.castSucc then 1 else 0) := by
      simp only [cfg, defaultChainHdrCfg, HdrField.readE, HdrField.idxE, rE,
        iValAt_add, iValAt_mul, iValAt_readHeap, iValAt_lit, hw15]
      simpa [cfg, defaultChainHdrCfg, HdrField.idx] using hw_aff_i
    cases haff_b : ctx.aff r_fin.castSucc
    · -- Branch 1: aff = false (unaffected serving node)
      have hcAff_true : cValAt 0 inp m cAff = true := by
        simp only [cAff, cValAt, evalArithCond]
        change decide (iValAt 0 inp m (cfg.snAffected.readE rE) = 0) = true
        rw [hAff_eval, haff_b]; rfl
      have hDum := exec_dummyHPJStmt (M_box := ctx.M_box) ctx.p inp m hpop (by have := ctx.hBox30; omega) (le_of_lt ctx.hφ0)
      refine (RandExecBad.ite_true
        (fB := .ite (.intEq (.readHeap 16 rE) (.lit 0))
          (idleAffectedNodeStmt ctx.d ctx.n ctx.M_box cfg ctx.p)
          (seqList [
            propAndBuildActiveJobStmt ctx.d ctx.n ctx.M_box ctx.p,
            cg01EndActionJobStmt ctx.d ctx.n ctx.M_box cfg ctx.p,
            activeJobDeadlineStmt ctx.d ctx.p.D₀ ctx.M_box cfg
          ]))
        hcAff_true hcAff_ops hDum).mono ?_ ?_ le_rfl
          (Nat.add_le_add_left (le_max_left _ _) 30)
      · intro m' hm'; subst hm'
        have hStep := midLoopUncut_step_unaffected hi hU.to_false haff_b
        exact ⟨by simp, by simp, by simp,
          (by simp : wRead (wWrite m 26 0 0) 26 15 = wRead m 26 15).trans hw15,
          by simp,
          Or.inl (hStep.congr_scratch (by simp) (fun _ hne _ => by simp [hne]) (fun _ _ => by simp))⟩
      · intro m' hm' _ hgF; subst hm'; subst hgF
        have hStep := midLoopUncut_step_unaffected hi hU haff_b
        exact Or.inl (hStep.congr_scratch (by simp) (fun _ hne _ => by simp [hne]) (fun _ _ => by simp))
    · -- Affected serving node (aff = true)
      have hcAff_false : cValAt 0 inp m cAff = false := by
        simp only [cAff, cValAt, evalArithCond]
        change decide (iValAt 0 inp m (cfg.snAffected.readE rE) = 0) = false
        rw [hAff_eval, haff_b]; rfl
      let cIdle : ArithCondExpr := .intEq (.readHeap 16 rE) (.lit 0)
      have hcIdle_ops : condExprOps cIdle ≤ 20 := by
        simp [cIdle, rE, condExprOps, intExprOps]
      have hTd_i := hTodo_i.2.2.2
      unfold EncTodoJobAt at hTd_i
      have hAffSub : RandExecBad inp
          (.ite cIdle
            (idleAffectedNodeStmt ctx.d ctx.n ctx.M_box cfg ctx.p)
            (seqList [
              propAndBuildActiveJobStmt ctx.d ctx.n ctx.M_box ctx.p,
              cg01EndActionJobStmt ctx.d ctx.n ctx.M_box cfg ctx.p,
              activeJobDeadlineStmt ctx.d ctx.p.D₀ ctx.M_box cfg
            ]))
          ctx.p.B_hpj m
          (fun m' =>
            wRead m' 0 0 = wRead m 0 0 ∧
            wRead m' 26 13 = wRead m 26 13 ∧
            wRead m' 26 14 = wRead m 26 14 ∧
            wRead m' 26 15 = (i : ℤ) ∧
            wRead m' 26 28 = wRead m 26 28 ∧
            (MidLoopUncut ctx false (i + 1) m' ∨ MidLoopCut ctx false m'))
          (fun m' =>
            gFlag = true → (MidLoopUncut ctx true (i + 1) m' ∨ MidLoopCut ctx true m'))
          (2 * ctx.p.φ_ev)
          (20 + max (idleAffectedNodeCost ctx.d ctx.n cfg ctx.p)
            (propAndBuildActiveJobCost ctx.p + cg01EndActionJobCost ctx.d ctx.n ctx.p +
             activeJobDeadlineCost ctx.d ctx.p.D₀)) := by
        cases hoj : ctx.st₀.ownedJob r_fin with
        | none =>
            -- Branch 2: aff = true, idle serving node (16[i] == 0)
            rw [hoj] at hTd_i
            change wRead m 16 (i : ℤ) = 0 at hTd_i
            have hcIdle_true : cValAt 0 inp m cIdle = true := by
              simp only [cIdle, cValAt, evalArithCond]
              change decide (wRead m 16 (wRead m 26 15) = 0) = true
              rw [hw15, hTd_i]; rfl
            have hIdle := hcfg ▸ exec_idleAffectedNodeStmt h_lem_5_1 ctx inp hi hpop hw15 hU haff_b hoj
            exact (RandExecBad.ite_true
              (fB := seqList [
                propAndBuildActiveJobStmt ctx.d ctx.n ctx.M_box ctx.p,
                cg01EndActionJobStmt ctx.d ctx.n ctx.M_box cfg ctx.p,
                activeJobDeadlineStmt ctx.d ctx.p.D₀ ctx.M_box cfg
              ])
              hcIdle_true hcIdle_ops hIdle).mono (fun _ h => h) (fun _ _ h => h) le_rfl
                (Nat.add_le_add_left (le_max_left _ _) 20)
        | some g₀ =>
            -- Branch 3: aff = true, active background job (16[i] == 1)
            rw [hoj] at hTd_i
            have hw16_1 : wRead m 16 (i : ℤ) = 1 := hTd_i.1
            have hcIdle_false : cValAt 0 inp m cIdle = false := by
              simp only [cIdle, cValAt, evalArithCond]
              change decide (wRead m 16 (wRead m 26 15) = 0) = false
              rw [hw15, hw16_1]; rfl
            have hAct := hcfg ▸ exec_cg01ActiveJobBranch h_lem_5_1 h_lem_C_2 ctx inp hcfg hi
              hpop hw13 hw14 hw15 hU haff_b hoj
            exact (RandExecBad.ite_false
              (tB := idleAffectedNodeStmt ctx.d ctx.n ctx.M_box cfg ctx.p)
              hcIdle_false hcIdle_ops hAct).mono (fun _ h => h) (fun _ _ h => h) le_rfl
                (Nat.add_le_add_left (le_max_right _ _) 20)
      exact (RandExecBad.ite_false (tB := dummyHpj) hcAff_false hcAff_ops hAffSub).mono
        (fun _ h => h) (fun _ _ h => h) le_rfl (Nat.add_le_add_left (le_max_right _ _) 30)

/-- Complete complete proof of `S_lem_7_2`! -/
theorem cg01_prove_S_lem_7_2
    (h_lem_5_1 : S_lem_5_1)
    (h_lem_5_2 : S_lem_5_2)
    (h_lem_C_2 : S_lem_C_2)
    (h_fb : S_clm_7_3_failure_budget)
    (h_mc : S_clm_5_1_mc_baseline) :
    S_lem_7_2 := by
  rcases exists_cHpj with ⟨cHpj, _, hcHpj⟩
  refine prove_S_lem_7_2_of_activeUncutNodeSpec h_lem_5_1 h_lem_5_2 h_fb h_mc hcHpj 1 2 ?_
  intro d n _ _ _ _ _ _ _ _ _ _ p _
  exact ⟨cg01BuildActiveUncutNodeSpec h_lem_5_1 h_lem_C_2 d n p, cg01ActiveUncutNodeCost_le p⟩

end UL.Proof_lem_7_2_RacerP46

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_7_2 (h_cit_hpj19_thm18 : S_cit_hpj19_thm18) (h_lem_5_1 : S_lem_5_1) (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction) (h_clm_5_1_mc_baseline : S_clm_5_1_mc_baseline) (h_lem_5_2 : S_lem_5_2) (h_claim_C_2_scans : S_claim_C_2_scans) (h_lem_C_2 : S_lem_C_2) (h_claim_C_2_space_reclaim : S_claim_C_2_space_reclaim) (h_clm_7_2_chain_schedule : S_clm_7_2_chain_schedule) (h_clm_7_3_failure_budget : S_clm_7_3_failure_budget) : S_lem_7_2 := by
  have _ : S_cit_hpj19_thm18 ∧ S_clm_5_1_chain_contraction ∧ S_claim_C_2_scans ∧
      S_claim_C_2_space_reclaim ∧ S_clm_7_2_chain_schedule :=
    ⟨h_cit_hpj19_thm18, h_clm_5_1_chain_contraction, h_claim_C_2_scans,
     h_claim_C_2_space_reclaim, h_clm_7_2_chain_schedule⟩
  exact UL.Proof_lem_7_2_RacerP46.cg01_prove_S_lem_7_2
    h_lem_5_1 h_lem_5_2 h_lem_C_2 h_clm_7_3_failure_budget h_clm_5_1_mc_baseline

end UL
