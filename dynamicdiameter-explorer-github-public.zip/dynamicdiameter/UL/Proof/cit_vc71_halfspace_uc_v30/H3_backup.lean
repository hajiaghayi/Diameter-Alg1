import Mathlib
import UL.Def.def_halfspace_depth
import UL.Proof.cit_vc71_halfspace_uc_v30.Defs
set_option autoImplicit false

namespace UL.Proof_cit_vc71_v30

private theorem exp_add_exp_neg_le_nonneg {u : ℝ} (hu : 0 ≤ u) :
    Real.exp u + Real.exp (-u) ≤ 2 * Real.exp (u ^ 2 / 2) := by
  let g : ℝ → ℝ := fun x => (Real.exp x - Real.exp (-x)) - x * (Real.exp x + Real.exp (-x))
  have hdg : ∀ x : ℝ, HasDerivAt g (-x * (Real.exp x - Real.exp (-x))) x := by
    intro x
    have he1 : HasDerivAt Real.exp (Real.exp x) x := Real.hasDerivAt_exp x
    have he2 : HasDerivAt (fun y : ℝ => Real.exp (-y)) (-Real.exp (-x)) x := by
      convert (Real.hasDerivAt_exp (-x)).comp x (hasDerivAt_neg x) using 1
      ring
    have hsub : HasDerivAt (fun y : ℝ => Real.exp y - Real.exp (-y))
        (Real.exp x + Real.exp (-x)) x := by
      convert he1.sub he2 using 1
      ring
    have hadd : HasDerivAt (fun y : ℝ => Real.exp y + Real.exp (-y))
        (Real.exp x - Real.exp (-x)) x := by
      simpa [sub_eq_add_neg] using he1.add he2
    have hmul : HasDerivAt (fun y : ℝ => y * (Real.exp y + Real.exp (-y)))
        (1 * (Real.exp x + Real.exp (-x)) + x * (Real.exp x - Real.exp (-x))) x :=
      (hasDerivAt_id x).mul hadd
    convert hsub.sub hmul using 1
    ring
  have hg_diff : Differentiable ℝ g := fun x => (hdg x).differentiableAt
  have hg_anti : AntitoneOn g (Set.Ici 0) := by
    refine antitoneOn_of_deriv_nonpos (convex_Ici 0) hg_diff.continuous.continuousOn
      hg_diff.differentiableOn ?_
    intro x hx
    have hx0 : 0 ≤ x := interior_subset hx
    rw [(hdg x).deriv]
    have hexp : Real.exp (-x) ≤ Real.exp x := Real.exp_le_exp.mpr (by linarith)
    nlinarith
  have hg_nonpos : ∀ x : ℝ, 0 ≤ x → g x ≤ 0 := by
    intro x hx
    have h0 : g 0 = 0 := by simp [g]
    exact (hg_anti (Set.self_mem_Ici) hx hx).trans_eq h0
  let h : ℝ → ℝ := fun x => Real.exp (-(x ^ 2 / 2)) * (Real.exp x + Real.exp (-x))
  have hdh : ∀ x : ℝ, HasDerivAt h (Real.exp (-(x ^ 2 / 2)) * g x) x := by
    intro x
    have hpow : HasDerivAt (fun y : ℝ => y ^ 2) (2 * x) x := by
      simpa using hasDerivAt_pow 2 x
    have hquad : HasDerivAt (fun y : ℝ => -(y ^ 2 / 2)) (-x) x := by
      convert (hpow.div_const 2).neg using 1
      ring
    have hexpq : HasDerivAt (fun y : ℝ => Real.exp (-(y ^ 2 / 2)))
        (Real.exp (-(x ^ 2 / 2)) * (-x)) x :=
      (Real.hasDerivAt_exp _).comp x hquad
    have he1 : HasDerivAt Real.exp (Real.exp x) x := Real.hasDerivAt_exp x
    have he2 : HasDerivAt (fun y : ℝ => Real.exp (-y)) (-Real.exp (-x)) x := by
      convert (Real.hasDerivAt_exp (-x)).comp x (hasDerivAt_neg x) using 1
      ring
    have hadd : HasDerivAt (fun y : ℝ => Real.exp y + Real.exp (-y))
        (Real.exp x - Real.exp (-x)) x := by
      simpa [sub_eq_add_neg] using he1.add he2
    convert hexpq.mul hadd using 1
    dsimp [g]
    ring
  have hh_diff : Differentiable ℝ h := fun x => (hdh x).differentiableAt
  have hh_anti : AntitoneOn h (Set.Ici 0) := by
    refine antitoneOn_of_deriv_nonpos (convex_Ici 0) hh_diff.continuous.continuousOn
      hh_diff.differentiableOn ?_
    intro x hx
    have hx0 : 0 ≤ x := interior_subset hx
    rw [(hdh x).deriv]
    exact mul_nonpos_of_nonneg_of_nonpos (Real.exp_pos _).le (hg_nonpos x hx0)
  have hhu : h u ≤ 2 := by
    have hh0 : h 0 = 2 := by norm_num [h]
    exact (hh_anti (Set.self_mem_Ici) hu hu).trans_eq hh0
  have hmul := mul_le_mul_of_nonneg_left hhu (Real.exp_pos (u ^ 2 / 2)).le
  have hcancel : Real.exp (u ^ 2 / 2) * Real.exp (-(u ^ 2 / 2)) = 1 := by
    rw [← Real.exp_add]
    norm_num
  calc
    Real.exp u + Real.exp (-u)
      = (Real.exp (u ^ 2 / 2) * Real.exp (-(u ^ 2 / 2))) * (Real.exp u + Real.exp (-u)) := by
          rw [hcancel, one_mul]
    _ = Real.exp (u ^ 2 / 2) * h u := by
          dsimp [h]
          ring
    _ ≤ Real.exp (u ^ 2 / 2) * 2 := hmul
    _ = 2 * Real.exp (u ^ 2 / 2) := mul_comm _ _

private theorem exp_add_exp_neg_le (u : ℝ) :
    Real.exp u + Real.exp (-u) ≤ 2 * Real.exp (u ^ 2 / 2) := by
  rcases le_total 0 u with hu | hu
  · exact exp_add_exp_neg_le_nonneg hu
  · have h := exp_add_exp_neg_le_nonneg (neg_nonneg.mpr hu)
    simpa [neg_neg, add_comm, neg_sq] using h

private def radSign (b : Bool) : ℝ :=
  if b then -1 else 1

private theorem rademacher_mgf_le :
    ∀ (n : ℕ) (δ : Fin n → ℝ), (∀ t, |δ t| ≤ 1) → ∀ η : ℝ,
      (∑ σ : Fin n → Bool, Real.exp (η * ∑ t : Fin n, radSign (σ t) * δ t)) ≤
        (2 : ℝ) ^ n * Real.exp ((n : ℝ) * η ^ 2 / 2)
  | 0, δ, _, η => by
      simp
  | n + 1, δ, hδ, η => by
      have h_equiv :
          (∑ σ : Fin (n + 1) → Bool, Real.exp (η * ∑ t : Fin (n + 1), radSign (σ t) * δ t)) =
            ∑ p : Bool × (Fin n → Bool),
              Real.exp (η * ∑ t : Fin (n + 1),
                radSign (@Fin.cons n (fun _ => Bool) p.1 p.2 t) * δ t) := by
        symm
        refine Fintype.sum_equiv (Fin.consEquiv (fun _ : Fin (n + 1) => Bool)) _ _ ?_
        intro p
        rfl
      rw [h_equiv, Fintype.sum_prod_type]
      have h_factor :
          (∑ b : Bool, ∑ τ : Fin n → Bool,
              Real.exp (η * ∑ t : Fin (n + 1), radSign (@Fin.cons n (fun _ => Bool) b τ t) * δ t)) =
            (∑ b : Bool, Real.exp (η * (radSign b * δ 0))) *
              (∑ τ : Fin n → Bool,
                Real.exp (η * ∑ t : Fin n, radSign (τ t) * δ (Fin.succ t))) := by
        rw [Finset.sum_mul]
        refine Finset.sum_congr rfl (fun b _ => ?_)
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl (fun τ _ => ?_)
        rw [Fin.sum_univ_succ, mul_add, Real.exp_add]
        simp
      rw [h_factor]
      have h_head :
          (∑ b : Bool, Real.exp (η * (radSign b * δ 0))) ≤ 2 * Real.exp (η ^ 2 / 2) := by
        rw [Fintype.sum_bool]
        have h_rw :
            Real.exp (η * (radSign true * δ 0)) + Real.exp (η * (radSign false * δ 0)) =
              Real.exp (η * δ 0) + Real.exp (-(η * δ 0)) := by
          dsimp [radSign]
          ring_nf
        rw [h_rw]
        have h1 := exp_add_exp_neg_le (η * δ 0)
        have h_sq : (δ 0) ^ 2 ≤ 1 := by obtain ⟨hl, hu⟩ := abs_le.mp (hδ 0); nlinarith
        have h2 : (η * δ 0) ^ 2 / 2 ≤ η ^ 2 / 2 := by
          have : (η * δ 0) ^ 2 = η ^ 2 * (δ 0) ^ 2 := by ring
          rw [this]
          nlinarith [sq_nonneg η]
        exact h1.trans (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr h2) (by norm_num))
      have h_tail :=
        rademacher_mgf_le n (fun t => δ (Fin.succ t)) (fun t => hδ (Fin.succ t)) η
      have h_tail_nn :
          0 ≤ ∑ τ : Fin n → Bool, Real.exp (η * ∑ t : Fin n, radSign (τ t) * δ (Fin.succ t)) :=
        Finset.sum_nonneg (fun _ _ => (Real.exp_pos _).le)
      calc
        (∑ b : Bool, Real.exp (η * (radSign b * δ 0))) *
            (∑ τ : Fin n → Bool, Real.exp (η * ∑ t : Fin n, radSign (τ t) * δ (Fin.succ t)))
          ≤ (2 * Real.exp (η ^ 2 / 2)) * ((2 : ℝ) ^ n * Real.exp ((n : ℝ) * η ^ 2 / 2)) :=
            mul_le_mul h_head h_tail h_tail_nn (by positivity)
        _ = (2 : ℝ) ^ (n + 1) * (Real.exp (η ^ 2 / 2) * Real.exp ((n : ℝ) * η ^ 2 / 2)) := by
            ring
        _ = (2 : ℝ) ^ (n + 1) * Real.exp (((n + 1 : ℕ) : ℝ) * η ^ 2 / 2) := by
            rw [← Real.exp_add]
            congr 2
            push_cast
            ring

private theorem rademacher_tail_pos {N : ℕ} (hN : 1 ≤ N) (δ : Fin N → ℝ)
    (hδ : ∀ t, |δ t| ≤ 1) {θ : ℝ} (hθ : 0 < θ) :
    ((Finset.univ.filter (fun σ : Fin N → Bool =>
        θ < ∑ t : Fin N, radSign (σ t) * δ t)).card : ℝ) ≤
      (2 : ℝ) ^ N * Real.exp (-(θ ^ 2 / (2 * (N : ℝ)))) := by
  have hN_pos : (0 : ℝ) < (N : ℝ) := by positivity
  let η : ℝ := θ / (N : ℝ)
  have hη : 0 < η := div_pos hθ hN_pos
  let S := Finset.univ.filter (fun σ : Fin N → Bool => θ < ∑ t : Fin N, radSign (σ t) * δ t)
  have h_markov :
      (S.card : ℝ) * Real.exp (η * θ) ≤
        ∑ σ : Fin N → Bool, Real.exp (η * ∑ t : Fin N, radSign (σ t) * δ t) := by
    calc
      (S.card : ℝ) * Real.exp (η * θ)
        = ∑ _σ ∈ S, Real.exp (η * θ) := by simp
      _ ≤ ∑ σ ∈ S, Real.exp (η * ∑ t : Fin N, radSign (σ t) * δ t) := by
          refine Finset.sum_le_sum (fun σ hσ => ?_)
          exact Real.exp_le_exp.mpr
            (mul_le_mul_of_nonneg_left (Finset.mem_filter.mp hσ).2.le hη.le)
      _ ≤ ∑ σ : Fin N → Bool, Real.exp (η * ∑ t : Fin N, radSign (σ t) * δ t) := by
          refine Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ S) (fun _ _ _ => ?_)
          exact (Real.exp_pos _).le
  have h_prod := h_markov.trans (rademacher_mgf_le N δ hδ η)
  have h_mul := mul_le_mul_of_nonneg_right h_prod (Real.exp_pos (-(η * θ))).le
  have h_lhs : (S.card : ℝ) * Real.exp (η * θ) * Real.exp (-(η * θ)) = (S.card : ℝ) := by
    rw [mul_assoc, ← Real.exp_add]
    simp
  have h_rhs :
      (2 : ℝ) ^ N * Real.exp ((N : ℝ) * η ^ 2 / 2) * Real.exp (-(η * θ)) =
        (2 : ℝ) ^ N * Real.exp (-(θ ^ 2 / (2 * (N : ℝ)))) := by
    rw [mul_assoc, ← Real.exp_add]
    congr 2
    dsimp [η]
    field_simp
    ring
  rw [h_lhs, h_rhs] at h_mul
  exact h_mul

private theorem rademacher_tail_abs {N : ℕ} (hN : 1 ≤ N) (δ : Fin N → ℝ)
    (hδ : ∀ t, |δ t| ≤ 1) {θ : ℝ} (hθ : 0 < θ) :
    ((Finset.univ.filter (fun σ : Fin N → Bool =>
        θ < |∑ t : Fin N, radSign (σ t) * δ t|)).card : ℝ) ≤
      2 * (2 : ℝ) ^ N * Real.exp (-(θ ^ 2 / (2 * (N : ℝ)))) := by
  let S_abs := Finset.univ.filter (fun σ : Fin N → Bool =>
    θ < |∑ t : Fin N, radSign (σ t) * δ t|)
  let S_pos := Finset.univ.filter (fun σ : Fin N → Bool =>
    θ < ∑ t : Fin N, radSign (σ t) * δ t)
  let S_neg := Finset.univ.filter (fun σ : Fin N → Bool =>
    θ < ∑ t : Fin N, radSign (σ t) * (-δ t))
  have h_sub : S_abs ⊆ S_pos ∪ S_neg := by
    intro σ hσ
    have hlt : θ < |∑ t : Fin N, radSign (σ t) * δ t| := (Finset.mem_filter.mp hσ).2
    rw [Finset.mem_union]
    rcases lt_abs.mp hlt with h1 | h2
    · exact Or.inl (Finset.mem_filter.mpr ⟨Finset.mem_univ _, h1⟩)
    · refine Or.inr (Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩)
      have h_eq : -(∑ t : Fin N, radSign (σ t) * δ t) =
          ∑ t : Fin N, radSign (σ t) * (-δ t) := by
        rw [← Finset.sum_neg_distrib]
        refine Finset.sum_congr rfl (fun t _ => by ring)
      rwa [← h_eq]
  have h_card_nat : S_abs.card ≤ S_pos.card + S_neg.card :=
    (Finset.card_le_card h_sub).trans (Finset.card_union_le S_pos S_neg)
  have h_card_real : (S_abs.card : ℝ) ≤ (S_pos.card : ℝ) + (S_neg.card : ℝ) := by
    exact_mod_cast h_card_nat
  have h1 := rademacher_tail_pos hN δ hδ hθ
  have h2 := rademacher_tail_pos hN (fun t => -δ t) (fun t => by simpa using hδ t) hθ
  linarith

private def swapPair {N : ℕ} {ι : Type*} (σ : Fin N → Bool)
    (p : (Fin N → ι) × (Fin N → ι)) : (Fin N → ι) × (Fin N → ι) :=
  ((fun t => if σ t then p.2 t else p.1 t), (fun t => if σ t then p.1 t else p.2 t))

private theorem swapPair_involutive {N : ℕ} {ι : Type*} (σ : Fin N → Bool)
    (p : (Fin N → ι) × (Fin N → ι)) :
    swapPair σ (swapPair σ p) = p := by
  cases p with
  | mk ω ω' =>
    refine Prod.ext (funext fun t => ?_) (funext fun t => ?_) <;>
      · dsimp [swapPair]; cases σ t <;> rfl

theorem doubleBad_card_le_of_trace {D N K : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) {ε : ℝ}
    (hN : 1 ≤ N) (hε : 0 < ε)
    (h_trace : ∀ z : Fin N ⊕ Fin N → EuclideanSpace ℝ (Fin D),
      (halfspaceTraceFamily z).card ≤ K) :
    ((doubleBadFinset P ε : Finset ((Fin N → ι) × (Fin N → ι))).card : ℝ) /
        (Fintype.card ((Fin N → ι) × (Fin N → ι)) : ℝ) ≤
      2 * (K : ℝ) * Real.exp (-((N : ℝ) * ε ^ 2 / 8)) := by
  classical
  have hN_pos : (0 : ℝ) < (N : ℝ) := by positivity
  let θ : ℝ := (N : ℝ) * ε / 2
  have hθ_pos : 0 < θ := by positivity
  have h_exp_eq : -(θ ^ 2 / (2 * (N : ℝ))) = -((N : ℝ) * ε ^ 2 / 8) := by
    dsimp [θ]
    field_simp
    ring
  have h_swap_card : ∀ σ : Fin N → Bool,
      (Finset.univ.filter (fun p : (Fin N → ι) × (Fin N → ι) =>
        swapPair σ p ∈ doubleBadFinset P ε)).card =
        (doubleBadFinset P ε : Finset ((Fin N → ι) × (Fin N → ι))).card := by
    intro σ
    refine Finset.card_bij (fun p _ => swapPair σ p) ?_ ?_ ?_
    · intro p hp
      exact (Finset.mem_filter.mp hp).2
    · intro p₁ _ p₂ _ h_eq
      have := congrArg (swapPair σ) h_eq
      rwa [swapPair_involutive, swapPair_involutive] at this
    · intro q hq
      refine ⟨swapPair σ q, ?_, swapPair_involutive σ q⟩
      rw [Finset.mem_filter]
      exact ⟨Finset.mem_univ _, by rwa [swapPair_involutive]⟩
  have h_double_sum :
      (2 : ℝ) ^ N * ((doubleBadFinset P ε : Finset ((Fin N → ι) × (Fin N → ι))).card : ℝ) =
        ∑ p : (Fin N → ι) × (Fin N → ι),
          ((Finset.univ.filter (fun σ : Fin N → Bool =>
            swapPair σ p ∈ doubleBadFinset P ε)).card : ℝ) := by
    have h_card_bool : (Fintype.card (Fin N → Bool) : ℝ) = (2 : ℝ) ^ N := by simp
    calc
      (2 : ℝ) ^ N * ((doubleBadFinset P ε : Finset ((Fin N → ι) × (Fin N → ι))).card : ℝ)
        = ∑ σ : Fin N → Bool,
            ((Finset.univ.filter (fun p : (Fin N → ι) × (Fin N → ι) =>
              swapPair σ p ∈ doubleBadFinset P ε)).card : ℝ) := by
            simp [h_swap_card]
      _ = ∑ σ : Fin N → Bool, ∑ p : (Fin N → ι) × (Fin N → ι),
            (if swapPair σ p ∈ doubleBadFinset P ε then (1 : ℝ) else 0) := by
            refine Finset.sum_congr rfl (fun σ _ => ?_)
            simp [Finset.sum_boole]
      _ = ∑ p : (Fin N → ι) × (Fin N → ι), ∑ σ : Fin N → Bool,
            (if swapPair σ p ∈ doubleBadFinset P ε then (1 : ℝ) else 0) :=
            Finset.sum_comm
      _ = ∑ p : (Fin N → ι) × (Fin N → ι),
            ((Finset.univ.filter (fun σ : Fin N → Bool =>
              swapPair σ p ∈ doubleBadFinset P ε)).card : ℝ) := by
            refine Finset.sum_congr rfl (fun p _ => ?_)
            simp [Finset.sum_boole]
  have h_per_p : ∀ p : (Fin N → ι) × (Fin N → ι),
      ((Finset.univ.filter (fun σ : Fin N → Bool =>
        swapPair σ p ∈ doubleBadFinset P ε)).card : ℝ) ≤
        2 * (K : ℝ) * (2 : ℝ) ^ N * Real.exp (-((N : ℝ) * ε ^ 2 / 8)) := by
    intro p
    let z : Fin N ⊕ Fin N → EuclideanSpace ℝ (Fin D) :=
      Sum.elim (fun t => P (p.1 t)) (fun t => P (p.2 t))
    let δOf : Finset (Fin N ⊕ Fin N) → Fin N → ℝ := fun A t =>
      (if Sum.inl t ∈ A then (1 : ℝ) else 0) - (if Sum.inr t ∈ A then (1 : ℝ) else 0)
    have hδ_bdd : ∀ A t, |δOf A t| ≤ 1 := by
      intro A t
      by_cases h1 : Sum.inl t ∈ A <;> by_cases h2 : Sum.inr t ∈ A <;>
        simp [δOf, h1, h2]
    let BadSigma := Finset.univ.filter (fun σ : Fin N → Bool =>
      swapPair σ p ∈ doubleBadFinset P ε)
    let TailOf : Finset (Fin N ⊕ Fin N) → Finset (Fin N → Bool) := fun A =>
      Finset.univ.filter (fun σ : Fin N → Bool =>
        θ < |∑ t : Fin N, radSign (σ t) * δOf A t|)
    have h_sub : BadSigma ⊆ (halfspaceTraceFamily z).biUnion TailOf := by
      intro σ hσ
      have hmem : swapPair σ p ∈ doubleBadFinset P ε := (Finset.mem_filter.mp hσ).2
      obtain ⟨H, hH, h_diff⟩ := (Finset.mem_filter.mp hmem).2
      let A : Finset (Fin N ⊕ Fin N) := Finset.univ.filter (fun u => z u ∈ H)
      have hA_mem : A ∈ halfspaceTraceFamily z :=
        Finset.mem_filter.mpr ⟨Finset.mem_univ _, H, hH, rfl⟩
      refine Finset.mem_biUnion.mpr ⟨A, hA_mem, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩⟩
      have h_pc : ∀ q : Fin N → ι,
          (N : ℝ) * empFreq P q H = ∑ t : Fin N, (if P (q t) ∈ H then (1 : ℝ) else 0) := by
        intro q
        have h1 : (N : ℝ) * empFreq P q H = (pointCount (fun t => P (q t)) H : ℝ) := by
          dsimp [empFreq]
          exact mul_div_cancel₀ _ hN_pos.ne'
        rw [h1]
        unfold pointCount
        simp [Finset.sum_boole]
      have h_sum_eq :
          (N : ℝ) * (empFreq P (swapPair σ p).1 H - empFreq P (swapPair σ p).2 H) =
            ∑ t : Fin N, radSign (σ t) * δOf A t := by
        rw [mul_sub, h_pc, h_pc, ← Finset.sum_sub_distrib]
        refine Finset.sum_congr rfl (fun t _ => ?_)
        cases h_b : σ t <;>
          simp [swapPair, radSign, δOf, A, z, h_b]
      have h_mul_lt :
          (N : ℝ) * (ε / 2) <
            (N : ℝ) * |empFreq P (swapPair σ p).1 H - empFreq P (swapPair σ p).2 H| :=
        mul_lt_mul_of_pos_left h_diff hN_pos
      have h_abs_mul :
          (N : ℝ) * |empFreq P (swapPair σ p).1 H - empFreq P (swapPair σ p).2 H| =
            |(N : ℝ) * (empFreq P (swapPair σ p).1 H - empFreq P (swapPair σ p).2 H)| := by
        rw [abs_mul, abs_of_pos hN_pos]
      have hθ_eq : (N : ℝ) * (ε / 2) = θ := by dsimp [θ]; ring
      rw [h_abs_mul, h_sum_eq, hθ_eq] at h_mul_lt
      exact h_mul_lt
    have h_card_nat :
        BadSigma.card ≤ ∑ A ∈ halfspaceTraceFamily z, (TailOf A).card :=
      (Finset.card_le_card h_sub).trans Finset.card_biUnion_le
    have h_card_real :
        (BadSigma.card : ℝ) ≤ ∑ A ∈ halfspaceTraceFamily z, ((TailOf A).card : ℝ) := by
      exact_mod_cast h_card_nat
    have h_each : ∀ A ∈ halfspaceTraceFamily z,
        ((TailOf A).card : ℝ) ≤ 2 * (2 : ℝ) ^ N * Real.exp (-((N : ℝ) * ε ^ 2 / 8)) := by
      intro A _
      have h := rademacher_tail_abs hN (δOf A) (hδ_bdd A) hθ_pos
      rwa [h_exp_eq] at h
    have h_trace_real : ((halfspaceTraceFamily z).card : ℝ) ≤ (K : ℝ) := by
      exact_mod_cast h_trace z
    calc
      (BadSigma.card : ℝ)
        ≤ ∑ A ∈ halfspaceTraceFamily z, ((TailOf A).card : ℝ) := h_card_real
      _ ≤ ∑ _A ∈ halfspaceTraceFamily z,
            (2 * (2 : ℝ) ^ N * Real.exp (-((N : ℝ) * ε ^ 2 / 8))) :=
          Finset.sum_le_sum h_each
      _ = ((halfspaceTraceFamily z).card : ℝ) *
            (2 * (2 : ℝ) ^ N * Real.exp (-((N : ℝ) * ε ^ 2 / 8))) := by simp
      _ ≤ (K : ℝ) * (2 * (2 : ℝ) ^ N * Real.exp (-((N : ℝ) * ε ^ 2 / 8))) :=
          mul_le_mul_of_nonneg_right h_trace_real (by positivity)
      _ = 2 * (K : ℝ) * (2 : ℝ) ^ N * Real.exp (-((N : ℝ) * ε ^ 2 / 8)) := by ring
  have h_sum_le :
      (2 : ℝ) ^ N * ((doubleBadFinset P ε : Finset ((Fin N → ι) × (Fin N → ι))).card : ℝ) ≤
        (Fintype.card ((Fin N → ι) × (Fin N → ι)) : ℝ) *
          (2 * (K : ℝ) * (2 : ℝ) ^ N * Real.exp (-((N : ℝ) * ε ^ 2 / 8))) := by
    rw [h_double_sum]
    calc
      ∑ p : (Fin N → ι) × (Fin N → ι),
          ((Finset.univ.filter (fun σ : Fin N → Bool =>
            swapPair σ p ∈ doubleBadFinset P ε)).card : ℝ)
        ≤ ∑ _p : (Fin N → ι) × (Fin N → ι),
            (2 * (K : ℝ) * (2 : ℝ) ^ N * Real.exp (-((N : ℝ) * ε ^ 2 / 8))) :=
          Finset.sum_le_sum (fun p _ => h_per_p p)
      _ = (Fintype.card ((Fin N → ι) × (Fin N → ι)) : ℝ) *
            (2 * (K : ℝ) * (2 : ℝ) ^ N * Real.exp (-((N : ℝ) * ε ^ 2 / 8))) := by simp
  have h_card_pos : (0 : ℝ) < (Fintype.card ((Fin N → ι) × (Fin N → ι)) : ℝ) := by
    exact_mod_cast Fintype.card_pos (α := (Fin N → ι) × (Fin N → ι))
  have h2N_pos : (0 : ℝ) < (2 : ℝ) ^ N := by positivity
  rw [div_le_iff₀ h_card_pos]
  nlinarith

end UL.Proof_cit_vc71_v30
