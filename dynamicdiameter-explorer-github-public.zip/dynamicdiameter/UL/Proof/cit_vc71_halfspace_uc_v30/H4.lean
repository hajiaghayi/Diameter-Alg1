import Mathlib
set_option autoImplicit false

namespace UL.Proof_cit_vc71_v30

theorem sum_choose_le_exp {M d : ℕ} (hd : 1 ≤ d) (hdM : d ≤ M) :
    (∑ k ∈ Finset.Iic d, (M.choose k : ℝ)) ≤
      Real.exp ((d : ℝ) + (d : ℝ) * Real.log ((M : ℝ) / (d : ℝ))) := by
  have hd_pos : (0 : ℝ) < (d : ℝ) := by positivity
  have hM_ge1 : 1 ≤ M := hd.trans hdM
  have hM_pos : (0 : ℝ) < (M : ℝ) := by positivity
  have ht_pos : 0 < (d : ℝ) / (M : ℝ) := div_pos hd_pos hM_pos
  have ht_le_one : (d : ℝ) / (M : ℝ) ≤ 1 := (div_le_one hM_pos).mpr (by exact_mod_cast hdM)
  have h_step1 :
      ((d : ℝ) / (M : ℝ)) ^ d * (∑ k ∈ Finset.Iic d, (M.choose k : ℝ)) ≤
        ∑ k ∈ Finset.Iic d, (M.choose k : ℝ) * ((d : ℝ) / (M : ℝ)) ^ k := by
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum (fun k hk => ?_)
    have hkd : k ≤ d := Finset.mem_Iic.mp hk
    have hpow : ((d : ℝ) / (M : ℝ)) ^ d ≤ ((d : ℝ) / (M : ℝ)) ^ k :=
      pow_le_pow_of_le_one ht_pos.le ht_le_one hkd
    have hch : (0 : ℝ) ≤ (M.choose k : ℝ) := by positivity
    exact (mul_comm _ _).trans_le (mul_le_mul_of_nonneg_left hpow hch)
  have h_sub : Finset.Iic d ⊆ Finset.range (M + 1) := by
    intro k hk
    exact Finset.mem_range.mpr (Nat.lt_succ_of_le ((Finset.mem_Iic.mp hk).trans hdM))
  have h_step2 :
      (∑ k ∈ Finset.Iic d, (M.choose k : ℝ) * ((d : ℝ) / (M : ℝ)) ^ k) ≤
        ∑ k ∈ Finset.range (M + 1), (M.choose k : ℝ) * ((d : ℝ) / (M : ℝ)) ^ k := by
    refine Finset.sum_le_sum_of_subset_of_nonneg h_sub (fun k _ _ => ?_)
    positivity
  have h_binom :
      (∑ k ∈ Finset.range (M + 1), (M.choose k : ℝ) * ((d : ℝ) / (M : ℝ)) ^ k) =
        ((d : ℝ) / (M : ℝ) + 1) ^ M := by
    rw [add_pow ((d : ℝ) / (M : ℝ)) 1 M]
    refine Finset.sum_congr rfl (fun k _ => ?_)
    simp [mul_comm]
  have h_exp : ((d : ℝ) / (M : ℝ) + 1) ^ M ≤ Real.exp (d : ℝ) := by
    have h1 : (d : ℝ) / (M : ℝ) + 1 ≤ Real.exp ((d : ℝ) / (M : ℝ)) :=
      Real.add_one_le_exp ((d : ℝ) / (M : ℝ))
    have h2 : ((d : ℝ) / (M : ℝ) + 1) ^ M ≤ (Real.exp ((d : ℝ) / (M : ℝ))) ^ M :=
      pow_le_pow_left₀ (by positivity) h1 M
    have h3 : (Real.exp ((d : ℝ) / (M : ℝ))) ^ M = Real.exp ((M : ℝ) * ((d : ℝ) / (M : ℝ))) :=
      (Real.exp_nat_mul ((d : ℝ) / (M : ℝ)) M).symm
    have h4 : (M : ℝ) * ((d : ℝ) / (M : ℝ)) = (d : ℝ) := mul_div_cancel₀ (d : ℝ) hM_pos.ne'
    rw [h3, h4] at h2
    exact h2
  have h_prod_le :
      ((d : ℝ) / (M : ℝ)) ^ d * (∑ k ∈ Finset.Iic d, (M.choose k : ℝ)) ≤ Real.exp (d : ℝ) :=
    (h_step1.trans h_step2).trans (h_binom.trans_le h_exp)
  have h_inv_pos : 0 < (M : ℝ) / (d : ℝ) := div_pos hM_pos hd_pos
  have h_rhs_eq :
      Real.exp ((d : ℝ) + (d : ℝ) * Real.log ((M : ℝ) / (d : ℝ))) =
        ((M : ℝ) / (d : ℝ)) ^ d * Real.exp (d : ℝ) := by
    rw [Real.exp_add, Real.exp_nat_mul, Real.exp_log h_inv_pos, mul_comm]
  rw [h_rhs_eq]
  have h_cancel : ((M : ℝ) / (d : ℝ)) ^ d * ((d : ℝ) / (M : ℝ)) ^ d = 1 := by
    rw [← mul_pow]
    have : ((M : ℝ) / (d : ℝ)) * ((d : ℝ) / (M : ℝ)) = 1 := by field_simp
    rw [this, one_pow]
  have h_nonneg : 0 ≤ ((M : ℝ) / (d : ℝ)) ^ d := by positivity
  calc
    (∑ k ∈ Finset.Iic d, (M.choose k : ℝ))
      = (((M : ℝ) / (d : ℝ)) ^ d * ((d : ℝ) / (M : ℝ)) ^ d) *
          (∑ k ∈ Finset.Iic d, (M.choose k : ℝ)) := by
          rw [h_cancel, one_mul]
    _ = ((M : ℝ) / (d : ℝ)) ^ d *
          (((d : ℝ) / (M : ℝ)) ^ d * (∑ k ∈ Finset.Iic d, (M.choose k : ℝ))) := by
          ring
    _ ≤ ((M : ℝ) / (d : ℝ)) ^ d * Real.exp (d : ℝ) :=
          mul_le_mul_of_nonneg_left h_prod_le h_nonneg

private theorem half_le_log_two : (1 : ℝ) / 2 ≤ Real.log 2 := by
  rw [Real.le_log_iff_exp_le (by norm_num : (0 : ℝ) < 2)]
  have h1 : (1 : ℝ) / 2 ≤ Real.exp (-(1 / 2 : ℝ)) := by
    linarith [Real.add_one_le_exp (-(1 / 2 : ℝ))]
  have h2 : Real.exp (1 / 2 : ℝ) * Real.exp (-(1 / 2 : ℝ)) = 1 := by
    rw [← Real.exp_add]
    norm_num
  have h3 : 0 < Real.exp (1 / 2 : ℝ) := Real.exp_pos _
  nlinarith

private theorem four_le_exp_two : (4 : ℝ) ≤ Real.exp 2 := by
  have h1 : (2 : ℝ) ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
  have h2 : Real.exp 2 = Real.exp 1 * Real.exp 1 := by
    rw [← Real.exp_add]
    norm_num
  nlinarith

private theorem log_le_sub_one {x : ℝ} (hx : 0 < x) : Real.log x ≤ x - 1 := by
  have h := Real.add_one_le_exp (Real.log x)
  rw [Real.exp_log hx] at h
  linarith

private theorem vc_real_bound {N_r d_r s_r L_s L_p : ℝ}
    (hd2 : 2 ≤ d_r) (hs1 : 1 ≤ s_r) (hLs : 1 / 2 ≤ L_s) (hLp : 1 / 2 ≤ L_p)
    (hN : 2048 * s_r ^ 2 * (d_r * L_s + L_p) ≤ N_r)
    (h128 : Real.log (128 * s_r ^ 2) ≤ 9 * L_s) :
    (3072 * s_r ^ 2 ≤ N_r) ∧
    (1024 * d_r ≤ N_r) ∧
    (2 + d_r + d_r * Real.log (2 * N_r / d_r) - N_r * (1 / (2 * s_r)) ^ 2 / 8 ≤ -L_p) := by
  have hd_pos : 0 < d_r := by linarith
  have hs_pos : 0 < s_r := by linarith
  have hs2_ge1 : 1 ≤ s_r ^ 2 := by nlinarith
  have hs2_pos : 0 < s_r ^ 2 := by positivity
  have h_inner : 3 / 2 ≤ d_r * L_s + L_p := by nlinarith
  have h3072 : 3072 * s_r ^ 2 ≤ N_r := by nlinarith
  have h1024 : 1024 * d_r ≤ N_r := by
    have h_dLs : (1 / 2) * d_r ≤ d_r * L_s + L_p := by nlinarith
    nlinarith
  refine ⟨h3072, h1024, ?_⟩
  have hN_pos : 0 < N_r := by linarith
  have hX_pos : 0 < N_r / (64 * d_r * s_r ^ 2) := by positivity
  have h_ratio : 2 * N_r / d_r = (N_r / (64 * d_r * s_r ^ 2)) * (128 * s_r ^ 2) := by
    field_simp
    ring
  have h_log_split :
      Real.log (2 * N_r / d_r) =
        Real.log (N_r / (64 * d_r * s_r ^ 2)) + Real.log (128 * s_r ^ 2) := by
    rw [h_ratio, Real.log_mul hX_pos.ne' (by positivity)]
  have h_logX : Real.log (N_r / (64 * d_r * s_r ^ 2)) ≤ N_r / (64 * d_r * s_r ^ 2) - 1 :=
    log_le_sub_one hX_pos
  have hdX : d_r * (N_r / (64 * d_r * s_r ^ 2) - 1) = N_r / (64 * s_r ^ 2) - d_r := by
    field_simp
  have h_dlog :
      d_r * Real.log (2 * N_r / d_r) ≤ N_r / (64 * s_r ^ 2) - d_r + 9 * d_r * L_s := by
    rw [h_log_split, mul_add]
    have h1 : d_r * Real.log (N_r / (64 * d_r * s_r ^ 2)) ≤
        d_r * (N_r / (64 * d_r * s_r ^ 2) - 1) :=
      mul_le_mul_of_nonneg_left h_logX hd_pos.le
    have h2 : d_r * Real.log (128 * s_r ^ 2) ≤ d_r * (9 * L_s) :=
      mul_le_mul_of_nonneg_left h128 hd_pos.le
    linarith
  have hN64 : 32 * (d_r * L_s + L_p) ≤ N_r / (64 * s_r ^ 2) := by
    rw [le_div_iff₀ (by positivity)]
    linarith
  have h_arg : N_r * (1 / (2 * s_r)) ^ 2 / 8 = 2 * (N_r / (64 * s_r ^ 2)) := by
    field_simp
    ring
  have h_two : 2 ≤ 2 * d_r * L_s := by nlinarith
  linarith

theorem vc_sample_complexity_arith {D r s : ℕ} {φ : ℝ}
    (hD : 1 ≤ D) (hr : 1 ≤ r) (hs : 1 ≤ s) (hφ0 : 0 < φ) (hφ1 : φ < 1)
    (hN : (2048 : ℝ) * (s : ℝ) ^ 2 *
        (((D : ℝ) + 1) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ)) ≤
      (r : ℝ) * (s : ℝ)) :
    (8 ≤ ((r * s : ℕ) : ℝ) * (1 / (2 * (s : ℝ))) ^ 2) ∧
    (4 * (∑ k ∈ Finset.Iic (D + 1), ((2 * (r * s)).choose k : ℝ)) *
        Real.exp (-(((r * s : ℕ) : ℝ) * (1 / (2 * (s : ℝ))) ^ 2 / 8)) ≤
      φ / 2) := by
  have hs1 : (1 : ℝ) ≤ (s : ℝ) := by exact_mod_cast hs
  have hs_pos : (0 : ℝ) < (s : ℝ) := by positivity
  have hd2_nat : 2 ≤ D + 1 := by omega
  have hd1_nat : 1 ≤ D + 1 := by omega
  have hd2 : (2 : ℝ) ≤ ((D + 1 : ℕ) : ℝ) := by exact_mod_cast hd2_nat
  have hLs : (1 : ℝ) / 2 ≤ Real.log ((s : ℝ) + 1) :=
    half_le_log_two.trans (Real.log_le_log (by norm_num) (by linarith))
  have hLp : (1 : ℝ) / 2 ≤ Real.log (2 / φ) := by
    refine half_le_log_two.trans (Real.log_le_log (by norm_num) ?_)
    rw [le_div_iff₀ hφ0]
    linarith
  have h128_pow : 128 * (s : ℝ) ^ 2 ≤ ((s : ℝ) + 1) ^ 9 := by
    have h7 : (128 : ℝ) ≤ ((s : ℝ) + 1) ^ 7 := by
      have h27 : (128 : ℝ) = (2 : ℝ) ^ 7 := by norm_num
      rw [h27]
      exact pow_le_pow_left₀ (by norm_num) (by linarith) 7
    have h2 : (s : ℝ) ^ 2 ≤ ((s : ℝ) + 1) ^ 2 :=
      pow_le_pow_left₀ (by positivity) (by linarith) 2
    have h7_nn : (0 : ℝ) ≤ ((s : ℝ) + 1) ^ 7 := by positivity
    calc
      128 * (s : ℝ) ^ 2 ≤ ((s : ℝ) + 1) ^ 7 * ((s : ℝ) + 1) ^ 2 :=
        mul_le_mul h7 h2 (by positivity) h7_nn
      _ = ((s : ℝ) + 1) ^ 9 := by ring
  have h128_log : Real.log (128 * (s : ℝ) ^ 2) ≤ 9 * Real.log ((s : ℝ) + 1) := by
    have h1 := Real.log_le_log (by positivity) h128_pow
    rw [Real.log_pow] at h1
    exact (by push_cast at h1; exact h1)
  have hN_cast : ((r * s : ℕ) : ℝ) = (r : ℝ) * (s : ℝ) := Nat.cast_mul r s
  have hd_cast : ((D + 1 : ℕ) : ℝ) = (D : ℝ) + 1 := by push_cast; ring
  have hN' :
      2048 * (s : ℝ) ^ 2 *
        (((D + 1 : ℕ) : ℝ) * Real.log ((s : ℝ) + 1) + Real.log (2 / φ)) ≤
        ((r * s : ℕ) : ℝ) := by
    rw [hN_cast, hd_cast]
    exact hN
  obtain ⟨h3072, h1024, h_exp_ineq0⟩ :=
    vc_real_bound hd2 hs1 hLs hLp hN' h128_log
  refine ⟨?_, ?_⟩
  · have h_eq :
        ((r * s : ℕ) : ℝ) * (1 / (2 * (s : ℝ))) ^ 2 =
          ((r * s : ℕ) : ℝ) / (4 * (s : ℝ) ^ 2) := by
      field_simp
      ring
    rw [h_eq, le_div_iff₀ (by positivity)]
    linarith
  · have hd_le_2N : D + 1 ≤ 2 * (r * s) := by
      have h_real : ((D + 1 : ℕ) : ℝ) ≤ ((2 * (r * s) : ℕ) : ℝ) := by
        rw [Nat.cast_mul, Nat.cast_ofNat]
        linarith
      exact_mod_cast h_real
    have h_sum_le := sum_choose_le_exp hd1_nat hd_le_2N
    have h_2N_cast : ((2 * (r * s) : ℕ) : ℝ) = 2 * ((r * s : ℕ) : ℝ) := by
      rw [Nat.cast_mul, Nat.cast_ofNat]
    have h_exp_ineq :
        2 + ((D + 1 : ℕ) : ℝ) +
            ((D + 1 : ℕ) : ℝ) * Real.log (((2 * (r * s) : ℕ) : ℝ) / ((D + 1 : ℕ) : ℝ)) -
          ((r * s : ℕ) : ℝ) * (1 / (2 * (s : ℝ))) ^ 2 / 8 ≤ -Real.log (2 / φ) := by
      rw [h_2N_cast]
      exact h_exp_ineq0
    have h_phi_eq : Real.exp (-Real.log (2 / φ)) = φ / 2 := by
      rw [Real.exp_neg, Real.exp_log (div_pos (by norm_num) hφ0), inv_div]
    calc
      4 * (∑ k ∈ Finset.Iic (D + 1), ((2 * (r * s)).choose k : ℝ)) *
          Real.exp (-(((r * s : ℕ) : ℝ) * (1 / (2 * (s : ℝ))) ^ 2 / 8))
        ≤ Real.exp 2 *
            Real.exp (((D + 1 : ℕ) : ℝ) +
              ((D + 1 : ℕ) : ℝ) * Real.log (((2 * (r * s) : ℕ) : ℝ) / ((D + 1 : ℕ) : ℝ))) *
            Real.exp (-(((r * s : ℕ) : ℝ) * (1 / (2 * (s : ℝ))) ^ 2 / 8)) := by
            have h_sum_nn : 0 ≤ ∑ k ∈ Finset.Iic (D + 1), ((2 * (r * s)).choose k : ℝ) := by
              positivity
            have h_prod1 := mul_le_mul four_le_exp_two h_sum_le h_sum_nn (Real.exp_pos 2).le
            exact mul_le_mul_of_nonneg_right h_prod1 (Real.exp_pos _).le
      _ = Real.exp (2 + ((D + 1 : ℕ) : ℝ) +
            ((D + 1 : ℕ) : ℝ) * Real.log (((2 * (r * s) : ℕ) : ℝ) / ((D + 1 : ℕ) : ℝ)) -
            ((r * s : ℕ) : ℝ) * (1 / (2 * (s : ℝ))) ^ 2 / 8) := by
            rw [← Real.exp_add, ← Real.exp_add]
            congr 1
            ring
      _ ≤ Real.exp (-Real.log (2 / φ)) := Real.exp_le_exp.mpr h_exp_ineq
      _ = φ / 2 := h_phi_eq

end UL.Proof_cit_vc71_v30
