import Mathlib
import UL.Def.def_halfspace_depth
import UL.Proof.cit_vc71_halfspace_uc_v30.Defs
set_option autoImplicit false

namespace UL.Proof_cit_vc71_v30

theorem exists_closedHalfspace_of_pos {D : ℕ} (hD : 1 ≤ D) :
    Nonempty {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H} := by
  let i₀ : Fin D := ⟨0, by omega⟩
  let v₀ : EuclideanSpace ℝ (Fin D) := EuclideanSpace.single i₀ (1 : ℝ)
  have hv₀ : v₀ ≠ 0 := by simp [v₀]
  exact ⟨⟨{x | inner ℝ v₀ x ≤ 0}, v₀, hv₀, 0, rfl⟩⟩

private lemma convex_closedHalfspace {D : ℕ} {H : Set (EuclideanSpace ℝ (Fin D))}
    (hH : IsClosedHalfspace H) : Convex ℝ H := by
  obtain ⟨v, _, β, rfl⟩ := hH
  intro x hx y hy a b ha hb hab
  simp only [Set.mem_setOf_eq] at hx hy ⊢
  rw [inner_add_right, inner_smul_right, inner_smul_right]
  calc a * inner ℝ v x + b * inner ℝ v y
      ≤ a * β + b * β :=
        add_le_add (mul_le_mul_of_nonneg_left hx ha) (mul_le_mul_of_nonneg_left hy hb)
    _ = (a + b) * β := by ring
    _ = β := by rw [hab, one_mul]

private lemma convex_compl_closedHalfspace {D : ℕ} {H : Set (EuclideanSpace ℝ (Fin D))}
    (hH : IsClosedHalfspace H) : Convex ℝ Hᶜ := by
  obtain ⟨v, _, β, rfl⟩ := hH
  intro x hx y hy a b ha hb hab
  simp only [Set.mem_compl_iff, Set.mem_setOf_eq, not_le] at hx hy ⊢
  rw [inner_add_right, inner_smul_right, inner_smul_right]
  rcases ha.eq_or_lt with rfl | ha'
  · have hb1 : b = 1 := by linarith
    simpa [hb1] using hy
  · calc β = (a + b) * β := by rw [hab, one_mul]
      _ = a * β + b * β := by ring
      _ < a * inner ℝ v x + b * inner ℝ v y :=
        add_lt_add_of_lt_of_le (mul_lt_mul_of_pos_left hx ha')
          (mul_le_mul_of_nonneg_left hy.le hb)

theorem card_halfspaceTraceFamily_le {D : ℕ} {κ : Type*} [Fintype κ]
    (z : κ → EuclideanSpace ℝ (Fin D)) :
    (halfspaceTraceFamily z).card ≤ ∑ k ∈ Finset.Iic (D + 1), (Fintype.card κ).choose k := by
  classical
  let 𝒜 : Finset (Finset κ) := halfspaceTraceFamily z
  have hshat : ∀ J : Finset κ, 𝒜.Shatters J → J.card ≤ D + 1 := by
    intro J hJ
    by_contra! hgt
    let f : J → EuclideanSpace ℝ (Fin D) := fun j => z j.1
    have hnot_aff : ¬ AffineIndependent ℝ f := by
      intro haff
      have h1 : Fintype.card J ≤ Module.finrank ℝ (vectorSpan ℝ (Set.range f)) + 1 :=
        haff.card_le_finrank_succ
      have h2 : Module.finrank ℝ (vectorSpan ℝ (Set.range f)) ≤
          Module.finrank ℝ (EuclideanSpace ℝ (Fin D)) :=
        Submodule.finrank_le _
      rw [Fintype.card_coe] at h1
      rw [finrank_euclideanSpace_fin] at h2
      omega
    obtain ⟨I, p, hpI, hpIc⟩ := Convex.radon_partition hnot_aff
    let T : Finset κ :=
      (Finset.univ.filter (fun j : J => j ∈ I)).map ⟨Subtype.val, Subtype.val_injective⟩
    have hTJ : T ⊆ J := by
      intro u hu
      rcases Finset.mem_map.mp hu with ⟨j, _, rfl⟩
      exact j.2
    have hjT : ∀ j : J, j.1 ∈ T ↔ j ∈ I := by
      intro j
      simp only [T, Finset.mem_map, Finset.mem_filter, Finset.mem_univ, true_and]
      exact ⟨fun ⟨a, ha, h⟩ => Subtype.ext h ▸ ha, fun hj => ⟨j, hj, rfl⟩⟩
    obtain ⟨A, hA, hJA⟩ := hJ hTJ
    simp only [𝒜, halfspaceTraceFamily, Finset.mem_filter, Finset.mem_univ, true_and] at hA
    obtain ⟨H, hH, rfl⟩ := hA
    have hjH : ∀ j : J, f j ∈ H ↔ j ∈ I := by
      intro j
      rw [← hjT j, ← hJA, Finset.mem_inter, Finset.mem_filter]
      exact ⟨fun h => ⟨j.2, Finset.mem_univ _, h⟩, fun ⟨_, _, h⟩ => h⟩
    have hp_in_H : p ∈ H :=
      convexHull_min (by rintro _ ⟨j, hj, rfl⟩; exact (hjH j).mpr hj)
        (convex_closedHalfspace hH) hpI
    have hp_in_Hc : p ∈ Hᶜ :=
      convexHull_min (by rintro _ ⟨j, hj, rfl⟩; exact fun h => hj ((hjH j).mp h))
        (convex_compl_closedHalfspace hH) hpIc
    exact hp_in_Hc hp_in_H
  have hvc : 𝒜.vcDim ≤ D + 1 :=
    Finset.sup_le fun J hJ => hshat J (Finset.mem_shatterer.mp hJ)
  calc 𝒜.card
      ≤ 𝒜.shatterer.card := Finset.card_le_card_shatterer 𝒜
    _ ≤ ∑ k ∈ Finset.Iic 𝒜.vcDim, (Fintype.card κ).choose k := Finset.card_shatterer_le_sum_vcDim
    _ ≤ ∑ k ∈ Finset.Iic (D + 1), (Fintype.card κ).choose k :=
        Finset.sum_le_sum_of_subset_of_nonneg (Finset.Iic_subset_Iic.mpr hvc)
          (fun _ _ _ => Nat.zero_le _)

end UL.Proof_cit_vc71_v30
