import Mathlib
import UL.Def.def_halfspace_depth
set_option autoImplicit false

namespace UL.Proof_cit_vc71_v30

open Classical in
noncomputable def halfspaceTraceFamily {D : ℕ} {κ : Type*} [Fintype κ]
    (z : κ → EuclideanSpace ℝ (Fin D)) : Finset (Finset κ) :=
  Finset.univ.filter (fun A : Finset κ =>
    ∃ H : Set (EuclideanSpace ℝ (Fin D)), IsClosedHalfspace H ∧
      A = Finset.univ.filter (fun u : κ => z u ∈ H))

noncomputable def popFreq {D : ℕ} {ι : Type*} [Fintype ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) (H : Set (EuclideanSpace ℝ (Fin D))) : ℝ :=
  (pointCount P H : ℝ) / (Fintype.card ι : ℝ)

noncomputable def empFreq {D N : ℕ} {ι : Type*}
    (P : ι → EuclideanSpace ℝ (Fin D)) (ω : Fin N → ι)
    (H : Set (EuclideanSpace ℝ (Fin D))) : ℝ :=
  (pointCount (fun t : Fin N => P (ω t)) H : ℝ) / (N : ℝ)

open Classical in
noncomputable def badSampleFinset {D N : ℕ} {ι : Type*} [Fintype ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) (ε : ℝ) : Finset (Fin N → ι) :=
  Finset.univ.filter (fun ω : Fin N → ι =>
    ∃ H : Set (EuclideanSpace ℝ (Fin D)), IsClosedHalfspace H ∧
      ε < |empFreq P ω H - popFreq P H|)

open Classical in
noncomputable def doubleBadFinset {D N : ℕ} {ι : Type*} [Fintype ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) (ε : ℝ) : Finset ((Fin N → ι) × (Fin N → ι)) :=
  Finset.univ.filter (fun p : (Fin N → ι) × (Fin N → ι) =>
    ∃ H : Set (EuclideanSpace ℝ (Fin D)), IsClosedHalfspace H ∧
      ε / 2 < |empFreq P p.1 H - empFreq P p.2 H|)

end UL.Proof_cit_vc71_v30
