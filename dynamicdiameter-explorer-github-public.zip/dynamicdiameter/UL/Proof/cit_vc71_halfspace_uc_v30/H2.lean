import Mathlib
import UL.Def.def_halfspace_depth
import UL.Proof.cit_vc71_halfspace_uc_v30.Defs
set_option autoImplicit false

namespace UL.Proof_cit_vc71_v30

theorem popFreq_mem_Icc {D : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) (H : Set (EuclideanSpace ℝ (Fin D))) :
    0 ≤ popFreq P H ∧ popFreq P H ≤ 1 := by
  unfold popFreq UL.pointCount
  have hpos : (0 : ℝ) < (Fintype.card ι : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  refine ⟨div_nonneg (Nat.cast_nonneg _) hpos.le, (div_le_one hpos).mpr ?_⟩
  exact_mod_cast Finset.card_le_univ _

theorem empFreq_mem_Icc {D N : ℕ} {ι : Type*} (hN : 1 ≤ N)
    (P : ι → EuclideanSpace ℝ (Fin D)) (ω : Fin N → ι)
    (H : Set (EuclideanSpace ℝ (Fin D))) :
    0 ≤ empFreq P ω H ∧ empFreq P ω H ≤ 1 := by
  unfold empFreq
  have hpos : (0 : ℝ) < (N : ℝ) := by exact_mod_cast (Nat.lt_of_lt_of_le Nat.zero_lt_one hN)
  refine ⟨div_nonneg (Nat.cast_nonneg _) hpos.le, (div_le_one hpos).mpr ?_⟩
  have hle : pointCount (fun t : Fin N => P (ω t)) H ≤ N := by
    unfold UL.pointCount
    exact (Finset.card_le_univ _).trans_eq (Fintype.card_fin N)
  exact_mod_cast hle

open Classical in
theorem pi_uniform_real_eq_card_div (N : ℕ) (ι : Type*)
    [Fintype ι] [Nonempty ι] [MeasurableSpace ι] [DiscreteMeasurableSpace ι]
    (E : Set (Fin N → ι)) :
    (MeasureTheory.Measure.pi
      (fun _ : Fin N => (PMF.uniformOfFintype ι).toMeasure)).real E =
      ((Finset.univ.filter (fun ω : Fin N → ι => ω ∈ E)).card : ℝ) /
        (Fintype.card (Fin N → ι) : ℝ) := by
  let μ₀ : MeasureTheory.Measure ι := (PMF.uniformOfFintype ι).toMeasure
  let ℙ : MeasureTheory.Measure (Fin N → ι) := MeasureTheory.Measure.pi (fun _ : Fin N => μ₀)
  have hsing_eq : ∀ ω : Fin N → ι,
      ({ω} : Set (Fin N → ι)) = Set.univ.pi (fun t : Fin N => ({ω t} : Set ι)) := by
    intro ω
    ext ω'
    simp [Set.mem_pi, funext_iff]
  have hsing_meas : ∀ ω : Fin N → ι, MeasurableSet ({ω} : Set (Fin N → ι)) := by
    intro ω
    rw [hsing_eq ω]
    exact MeasurableSet.univ_pi (fun t => MeasurableSet.of_discrete)
  have hsing_prob : ∀ ω : Fin N → ι,
      ℙ ({ω} : Set (Fin N → ι)) = ((Fintype.card (Fin N → ι) : ENNReal))⁻¹ := by
    intro ω
    rw [hsing_eq ω, MeasureTheory.Measure.pi_pi]
    have hterm : ∀ t : Fin N, μ₀ ({ω t} : Set ι) = (Fintype.card ι : ENNReal)⁻¹ := by
      intro t
      change (PMF.uniformOfFintype ι).toMeasure ({ω t} : Set ι) = _
      rw [PMF.toMeasure_apply_singleton _ _ MeasurableSet.of_discrete, PMF.uniformOfFintype_apply]
    simp_rw [hterm]
    rw [Finset.prod_const, Finset.card_univ, Fintype.card_fin, ← ENNReal.inv_pow]
    congr 1
    have hcard : Fintype.card (Fin N → ι) = Fintype.card ι ^ N := by
      rw [Fintype.card_fun, Fintype.card_fin]
    exact_mod_cast hcard.symm
  let S : Finset (Fin N → ι) := Finset.univ.filter (fun ω : Fin N → ι => ω ∈ E)
  have hE : E = ⋃ ω ∈ S, ({ω} : Set (Fin N → ι)) := by
    ext ω
    simp [S]
  have hdisj : (S : Set (Fin N → ι)).PairwiseDisjoint
      (fun ω : Fin N → ι => ({ω} : Set (Fin N → ι))) := by
    intro ω₁ _ ω₂ _ hne
    exact Set.disjoint_singleton.mpr hne
  have hmeasE : ℙ E = (S.card : ENNReal) * ((Fintype.card (Fin N → ι) : ENNReal))⁻¹ := by
    rw [hE, MeasureTheory.measure_biUnion_finset hdisj (fun ω _ => hsing_meas ω)]
    simp [hsing_prob]
  change (ℙ E).toReal = (S.card : ℝ) / (Fintype.card (Fin N → ι) : ℝ)
  rw [hmeasE, ENNReal.toReal_mul, ENNReal.toReal_natCast, ENNReal.toReal_inv,
    ENNReal.toReal_natCast, ← div_eq_mul_inv]

private lemma centered_sum_sq_le {ι : Type*} [Fintype ι] (a : ι → ℝ)
    (ha0 : ∑ i : ι, a i = 0) (ha1 : ∀ i : ι, |a i| ≤ 1) :
    ∀ N : ℕ, ∑ ω : Fin N → ι, (∑ t : Fin N, a (ω t)) ^ 2 ≤
      (N : ℝ) * (Fintype.card (Fin N → ι) : ℝ)
  | 0 => by simp
  | n + 1 => by
    let e : ι × (Fin n → ι) ≃ (Fin (n + 1) → ι) := Fin.consEquiv (fun _ : Fin (n + 1) => ι)
    rw [← Equiv.sum_comp e (fun ω => (∑ t : Fin (n + 1), a (ω t)) ^ 2), Fintype.sum_prod_type]
    have hexp : ∀ (i : ι) (ω' : Fin n → ι),
        (∑ t : Fin (n + 1), a (e (i, ω') t)) ^ 2 =
          (a i) ^ 2 + 2 * a i * (∑ t : Fin n, a (ω' t)) + (∑ t : Fin n, a (ω' t)) ^ 2 := by
      intro i ω'
      have hcons : ∑ t : Fin (n + 1), a (e (i, ω') t) = a i + ∑ t : Fin n, a (ω' t) := by
        simp [e, Fin.sum_univ_succ]
      rw [hcons]
      ring
    simp_rw [hexp, Finset.sum_add_distrib]
    have h1 : ∑ x : ι, ∑ _y : Fin n → ι, (a x) ^ 2 ≤
        (Fintype.card ι : ℝ) * (Fintype.card (Fin n → ι) : ℝ) := by
      calc ∑ x : ι, ∑ _y : Fin n → ι, (a x) ^ 2
          ≤ ∑ _x : ι, ∑ _y : Fin n → ι, (1 : ℝ) := by
            refine Finset.sum_le_sum (fun x _ => Finset.sum_le_sum (fun _ _ => ?_))
            have hax := abs_le.mp (ha1 x)
            nlinarith
        _ = (Fintype.card ι : ℝ) * (Fintype.card (Fin n → ι) : ℝ) := by simp
    have h2 : ∑ x : ι, ∑ y : Fin n → ι, 2 * a x * (∑ t : Fin n, a (y t)) = 0 := by
      rw [Finset.sum_comm]
      refine Finset.sum_eq_zero (fun y _ => ?_)
      have : (∑ x : ι, 2 * a x * (∑ t : Fin n, a (y t))) =
          (∑ x : ι, a x) * (2 * (∑ t : Fin n, a (y t))) := by
        rw [Finset.sum_mul]
        refine Finset.sum_congr rfl (fun x _ => by ring)
      rw [this, ha0, zero_mul]
    have h3 : ∑ _x : ι, ∑ y : Fin n → ι, (∑ t : Fin n, a (y t)) ^ 2 ≤
        (Fintype.card ι : ℝ) * ((n : ℝ) * (Fintype.card (Fin n → ι) : ℝ)) := by
      rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
      exact mul_le_mul_of_nonneg_left (centered_sum_sq_le a ha0 ha1 n) (Nat.cast_nonneg _)
    have hcard : (Fintype.card (Fin (n + 1) → ι) : ℝ) =
        (Fintype.card ι : ℝ) * (Fintype.card (Fin n → ι) : ℝ) := by
      have hc : Fintype.card (Fin (n + 1) → ι) = Fintype.card ι * Fintype.card (Fin n → ι) := by
        rw [← Fintype.card_congr e, Fintype.card_prod]
      exact_mod_cast hc
    rw [h2, add_zero, hcard, Nat.cast_add, Nat.cast_one]
    linarith

open Classical in
private lemma goodGhost_card_ge {D N : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) (H : Set (EuclideanSpace ℝ (Fin D))) {ε : ℝ}
    (hN : 1 ≤ N) (hε : 0 < ε) (hNε : 8 ≤ (N : ℝ) * ε ^ 2) :
    (Fintype.card (Fin N → ι) : ℝ) ≤
      2 * ((Finset.univ.filter (fun ω' : Fin N → ι =>
        |empFreq P ω' H - popFreq P H| ≤ ε / 2)).card : ℝ) := by
  let a : ι → ℝ := fun i => (if P i ∈ H then (1 : ℝ) else 0) - popFreq P H
  have hcard_pos : (0 : ℝ) < (Fintype.card ι : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have hN_pos : (0 : ℝ) < (N : ℝ) := by exact_mod_cast (Nat.lt_of_lt_of_le Nat.zero_lt_one hN)
  have ha0 : ∑ i : ι, a i = 0 := by
    simp only [a, Finset.sum_sub_distrib, Finset.sum_boole, Finset.sum_const, Finset.card_univ,
      nsmul_eq_mul]
    have hpc : ((Finset.univ.filter (fun i : ι => P i ∈ H)).card : ℝ) = (pointCount P H : ℝ) := by
      rfl
    rw [hpc, popFreq, mul_div_cancel₀ _ hcard_pos.ne', sub_self]
  have ha1 : ∀ i : ι, |a i| ≤ 1 := by
    intro i
    have hp := popFreq_mem_Icc P H
    dsimp only [a]
    split_ifs <;> exact abs_le.mpr ⟨by linarith, by linarith⟩
  have hsum_ω : ∀ ω' : Fin N → ι,
      ∑ t : Fin N, a (ω' t) = (N : ℝ) * (empFreq P ω' H - popFreq P H) := by
    intro ω'
    simp only [a, Finset.sum_sub_distrib, Finset.sum_boole, Finset.sum_const, Finset.card_univ,
      Fintype.card_fin, nsmul_eq_mul]
    have hpc : ((Finset.univ.filter (fun t : Fin N => P (ω' t) ∈ H)).card : ℝ) =
        (pointCount (fun t : Fin N => P (ω' t)) H : ℝ) := by
      rfl
    rw [hpc, mul_sub, empFreq, mul_div_cancel₀ _ hN_pos.ne']
  have hvarN : (N : ℝ) * (∑ ω' : Fin N → ι, (empFreq P ω' H - popFreq P H) ^ 2) ≤
      (Fintype.card (Fin N → ι) : ℝ) := by
    have hsq := centered_sum_sq_le a ha0 ha1 N
    simp_rw [hsum_ω, mul_pow] at hsq
    rw [← Finset.mul_sum] at hsq
    have hsq' : (N : ℝ) * ((N : ℝ) * ∑ ω' : Fin N → ι, (empFreq P ω' H - popFreq P H) ^ 2) ≤
        (N : ℝ) * (Fintype.card (Fin N → ι) : ℝ) := by
      linarith
    exact le_of_mul_le_mul_left hsq' hN_pos
  let goodG := Finset.univ.filter (fun ω' : Fin N → ι => |empFreq P ω' H - popFreq P H| ≤ ε / 2)
  let badG := Finset.univ.filter (fun ω' : Fin N → ι => ¬(|empFreq P ω' H - popFreq P H| ≤ ε / 2))
  have hpart : (goodG.card : ℝ) + (badG.card : ℝ) = (Fintype.card (Fin N → ι) : ℝ) := by
    have hc := Finset.card_filter_add_card_filter_not
      (fun ω' : Fin N → ι => |empFreq P ω' H - popFreq P H| ≤ ε / 2) (s := Finset.univ)
    rw [Finset.card_univ] at hc
    exact_mod_cast hc
  have hcheb : (badG.card : ℝ) * (ε ^ 2 / 4) ≤
      ∑ ω' : Fin N → ι, (empFreq P ω' H - popFreq P H) ^ 2 := by
    calc (badG.card : ℝ) * (ε ^ 2 / 4)
        = ∑ _ω' ∈ badG, (ε ^ 2 / 4) := by simp
      _ ≤ ∑ ω' ∈ badG, (empFreq P ω' H - popFreq P H) ^ 2 := by
          refine Finset.sum_le_sum (fun ω' hω' => ?_)
          have hlt : ε / 2 < |empFreq P ω' H - popFreq P H| :=
            lt_of_not_ge (Finset.mem_filter.mp hω').2
          have hsqle : (ε / 2) ^ 2 ≤ |empFreq P ω' H - popFreq P H| ^ 2 :=
            sq_le_sq' (by linarith) hlt.le
          rw [sq_abs] at hsqle
          linarith
      _ ≤ ∑ ω' ∈ Finset.univ, (empFreq P ω' H - popFreq P H) ^ 2 := by
          exact Finset.sum_le_univ_sum_of_nonneg (fun _ => sq_nonneg _)
  have hbad_mul : (badG.card : ℝ) * ((N : ℝ) * ε ^ 2) ≤ 4 * (Fintype.card (Fin N → ι) : ℝ) := by
    have h1 : 4 * ((N : ℝ) * ((badG.card : ℝ) * (ε ^ 2 / 4))) ≤
        4 * ((N : ℝ) * ∑ ω' : Fin N → ι, (empFreq P ω' H - popFreq P H) ^ 2) := by
      exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left hcheb hN_pos.le) (by norm_num)
    linarith
  have hbad_8 : 8 * (badG.card : ℝ) ≤ (badG.card : ℝ) * ((N : ℝ) * ε ^ 2) := by
    have hbn : (0 : ℝ) ≤ (badG.card : ℝ) := Nat.cast_nonneg _
    nlinarith
  linarith

theorem symmetrization_card_le {D N : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) {ε : ℝ}
    (hN : 1 ≤ N) (hε : 0 < ε) (hNε : 8 ≤ (N : ℝ) * ε ^ 2) :
    ((badSampleFinset P ε : Finset (Fin N → ι)).card : ℝ) /
        (Fintype.card (Fin N → ι) : ℝ) ≤
      2 * (((doubleBadFinset P ε : Finset ((Fin N → ι) × (Fin N → ι))).card : ℝ) /
        (Fintype.card ((Fin N → ι) × (Fin N → ι)) : ℝ)) := by
  classical
  let B : Finset (Fin N → ι) := badSampleFinset P ε
  let D2 : Finset ((Fin N → ι) × (Fin N → ι)) := doubleBadFinset P ε
  let goodGhost : Set (EuclideanSpace ℝ (Fin D)) → Finset (Fin N → ι) := fun H =>
    Finset.univ.filter (fun ω' : Fin N → ι => |empFreq P ω' H - popFreq P H| ≤ ε / 2)
  let H_of : (Fin N → ι) → Set (EuclideanSpace ℝ (Fin D)) := fun ω =>
    if h : ∃ H : Set (EuclideanSpace ℝ (Fin D)), IsClosedHalfspace H ∧
        ε < |empFreq P ω H - popFreq P H|
    then Classical.choose h else ∅
  let fiber : (Fin N → ι) → Finset ((Fin N → ι) × (Fin N → ι)) := fun ω =>
    ({ω} : Finset (Fin N → ι)) ×ˢ goodGhost (H_of ω)
  have hdisj : (B : Set (Fin N → ι)).PairwiseDisjoint fiber := by
    intro ω₁ _ ω₂ _ hne
    refine Finset.disjoint_left.mpr (fun p hp1 hp2 => ?_)
    have h1 : p.1 = ω₁ := Finset.mem_singleton.mp (Finset.mem_product.mp hp1).1
    have h2 : p.1 = ω₂ := Finset.mem_singleton.mp (Finset.mem_product.mp hp2).1
    exact hne (h1.symm.trans h2)
  have hsub : B.biUnion fiber ⊆ D2 := by
    intro p hp
    rcases Finset.mem_biUnion.mp hp with ⟨ω, hω, hp_fib⟩
    have hp1 : p.1 = ω := Finset.mem_singleton.mp (Finset.mem_product.mp hp_fib).1
    have hp2 : |empFreq P p.2 (H_of ω) - popFreq P (H_of ω)| ≤ ε / 2 :=
      (Finset.mem_filter.mp (Finset.mem_product.mp hp_fib).2).2
    have hex : ∃ H : Set (EuclideanSpace ℝ (Fin D)), IsClosedHalfspace H ∧
        ε < |empFreq P ω H - popFreq P H| := by
      change ω ∈ badSampleFinset P ε at hω
      unfold badSampleFinset at hω
      exact (Finset.mem_filter.mp hω).2
    have hH_eq : H_of ω = Classical.choose hex := dif_pos hex
    rcases Classical.choose_spec hex with ⟨hH_closed, hH_bad⟩
    rw [← hH_eq] at hH_closed hH_bad
    have htri := abs_sub_le (empFreq P ω (H_of ω)) (empFreq P p.2 (H_of ω)) (popFreq P (H_of ω))
    have hdiff : ε / 2 < |empFreq P p.1 (H_of ω) - empFreq P p.2 (H_of ω)| := by
      rw [hp1]
      linarith
    change p ∈ doubleBadFinset P ε
    unfold doubleBadFinset
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ p, ⟨H_of ω, hH_closed, hdiff⟩⟩
  have hsum_card : ∑ ω ∈ B, (goodGhost (H_of ω)).card ≤ D2.card := by
    calc ∑ ω ∈ B, (goodGhost (H_of ω)).card
        = ∑ ω ∈ B, (fiber ω).card := by
          refine Finset.sum_congr rfl (fun ω _ => ?_)
          simp [fiber]
      _ = (B.biUnion fiber).card := (Finset.card_biUnion hdisj).symm
      _ ≤ D2.card := Finset.card_le_card hsub
  let M : ℝ := (Fintype.card (Fin N → ι) : ℝ)
  have hM_pos : 0 < M := Nat.cast_pos.mpr Fintype.card_pos
  have hBM : (B.card : ℝ) * M ≤ 2 * (D2.card : ℝ) := by
    calc (B.card : ℝ) * M
        = ∑ _ω ∈ B, M := by simp
      _ ≤ ∑ ω ∈ B, 2 * ((goodGhost (H_of ω)).card : ℝ) := by
          refine Finset.sum_le_sum (fun ω _ => ?_)
          exact goodGhost_card_ge P (H_of ω) hN hε hNε
      _ = 2 * ∑ ω ∈ B, ((goodGhost (H_of ω)).card : ℝ) := by
          rw [← Finset.mul_sum]
      _ ≤ 2 * (D2.card : ℝ) := by
          have hcast : ∑ ω ∈ B, ((goodGhost (H_of ω)).card : ℝ) ≤ (D2.card : ℝ) := by
            exact_mod_cast hsum_card
          linarith
  have hprod_card : (Fintype.card ((Fin N → ι) × (Fin N → ι)) : ℝ) = M * M := by
    simp [M, Fintype.card_prod]
  change (B.card : ℝ) / M ≤ 2 * ((D2.card : ℝ) / (Fintype.card ((Fin N → ι) × (Fin N → ι)) : ℝ))
  rw [hprod_card]
  calc (B.card : ℝ) / M
      = ((B.card : ℝ) * M) / (M * M) := (mul_div_mul_right _ _ hM_pos.ne').symm
    _ ≤ (2 * (D2.card : ℝ)) / (M * M) :=
        div_le_div_of_nonneg_right hBM (mul_nonneg hM_pos.le hM_pos.le)
    _ = 2 * ((D2.card : ℝ) / (M * M)) := mul_div_assoc _ _ _

end UL.Proof_cit_vc71_v30
