import UL.Stmt.lem_5_5
import UL.Stmt.lem_5_3
import UL.Stmt.clm_5_3_matching_invariant
import UL.Stmt.lem_5_4
import UL.Proof.lem_5_5.H1
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_5_5 (h_lem_5_3 : S_lem_5_3) (h_clm_5_3_matching_invariant : S_clm_5_3_matching_invariant) (h_lem_5_4 : S_lem_5_4) : S_lem_5_5 := by
  let _ := h_clm_5_3_matching_invariant
  unfold S_lem_5_5
  unfold S_lem_5_3 at h_lem_5_3
  unfold S_lem_5_4 at h_lem_5_4
  intro d ι pts o V S params basePair M stored hV h_base h_match
  classical
  let L := baselinePairLength pts basePair
  obtain ⟨hL0, hL_cond, hL_diam⟩ := Proof_lem_5_5.baseline_props pts o V S basePair h_base
  have hL_le_W : L ≤ params.nodeRetainedEstimate pts V L stored :=
    Proof_lem_5_5.baseline_le_retainedEstimate params pts V L stored
  have hW_ub : params.nodeRetainedEstimate pts V L stored ≤ indexedEuclideanDiam S pts :=
    Proof_lem_5_5.retainedEstimate_le_diam params pts o V L S M stored hL_diam h_match
  refine ⟨?_, hW_ub⟩
  let D_C := nodeCoreInputDiam pts o V S
  change D_C / params.c ≤ params.nodeRetainedEstimate pts V L stored
  have hc_pos : 0 < params.c := Proof_lem_5_5.params_c_pos params
  by_cases hDC_le : D_C ≤ params.c * L
  · have h1 : D_C / params.c ≤ L := (div_le_iff₀ hc_pos).mpr (by linarith only [hDC_le])
    exact le_trans h1 hL_le_W
  have hDC_gt : params.c * L < D_C := lt_of_not_ge hDC_le
  have hV_pos : 0 < V := by
    by_contra hV_not
    have hV_eq : V = 0 := le_antisymm (not_lt.mp hV_not) hV
    rcases h_lem_5_3 d ι pts o V S L params.c params.K hV hL_cond
        params.one_lt_c params.c_lt_sqrt_two params.K_ge (Or.inl hV_eq) with hlt | ⟨h01, h02⟩
    · change D_C < params.c * L at hlt; linarith only [hlt, hDC_gt]
    · change D_C = 0 at h01; change L = 0 at h02
      rw [h01, h02, mul_zero] at hDC_gt
      exact lt_irrefl 0 hDC_gt
  have hRS_le : nodeMaxRadius pts o S ≤ (params.K : ℝ) * Real.sqrt V := by
    by_contra hRS_not
    have hRS_gt : nodeMaxRadius pts o S > (params.K : ℝ) * Real.sqrt V := lt_of_not_ge hRS_not
    rcases h_lem_5_3 d ι pts o V S L params.c params.K hV hL_cond
        params.one_lt_c params.c_lt_sqrt_two params.K_ge (Or.inr hRS_gt) with hlt | ⟨h01, h02⟩
    · change D_C < params.c * L at hlt; linarith only [hlt, hDC_gt]
    · change D_C = 0 at h01; change L = 0 at h02
      rw [h01, h02, mul_zero] at hDC_gt
      exact lt_irrefl 0 hDC_gt
  have hDC_pos : 0 < D_C := lt_of_le_of_lt (mul_nonneg hc_pos.le hL0) hDC_gt
  have hCS_ne : (nodeCore pts o V S).Nonempty ∧ S.Nonempty := by
    by_contra hnot
    have h0 : D_C = 0 := by simp [D_C, nodeCoreInputDiam, indexedCoreInputDiam, hnot]
    linarith only [hDC_pos, h0]
  have hDC_eq_sup : D_C = ((nodeCore pts o V S) ×ˢ S).sup' (hCS_ne.1.product hCS_ne.2)
      (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) := by
    unfold D_C nodeCoreInputDiam indexedCoreInputDiam
    rw [dif_pos hCS_ne]
  obtain ⟨xy, hxy_mem, hsup_eq⟩ := Finset.exists_mem_eq_sup' (hCS_ne.1.product hCS_ne.2)
      (fun ab : ι × ι => ‖pts ab.1 - pts ab.2‖)
  rcases xy with ⟨x, y⟩
  rcases Finset.mem_product.mp hxy_mem with ⟨hx_core, hy_S⟩
  have hxy_dist : ‖pts x - pts y‖ = D_C := by
    rw [hDC_eq_sup, hsup_eq]
  have hx_ball : ‖pts x - o‖ ≤ Real.sqrt V := by
    have hcb : pts x ∈ coreBall o V := by
      unfold nodeCore at hx_core
      exact (Finset.mem_filter.mp hx_core).2
    simpa [coreBall, Metric.mem_closedBall, dist_eq_norm] using hcb
  have hy_R : ‖pts y - o‖ ≤ nodeMaxRadius pts o S := by
    unfold nodeMaxRadius
    rw [dif_pos hCS_ne.2]
    exact Finset.le_sup' (f := fun i : ι => ‖pts i - o‖) hy_S
  have hy_elig_norm : ‖pts y - o‖ ≤ (params.K : ℝ) * Real.sqrt V := le_trans hy_R hRS_le
  have hy_elig : y ∈ nodeEligible pts o V params.K S := by
    unfold nodeEligible IsEligiblePoint
    exact Finset.mem_filter.mpr ⟨hy_S, hy_elig_norm⟩
  have hL_sq : V + (nodeMaxRadius pts o S) ^ 2 ≤ L ^ 2 := by
    have hLc : 0 ≤ L ∧ L ^ 2 ≥ V + (nodeMaxRadius pts o S) ^ 2 := by
      simpa [SatisfiesBaselineLengthCond, hCS_ne.2] using hL_cond
    exact hLc.2
  have hVL : V ≤ L ^ 2 := by
    have hsq0 : 0 ≤ (nodeMaxRadius pts o S) ^ 2 := sq_nonneg _
    linarith only [hL_sq, hsq0]
  have hsqrt_le_L : Real.sqrt V ≤ L := (Real.sqrt_le_iff).mpr ⟨hL0, hVL⟩
  have hRS_le_L : nodeMaxRadius pts o S ≤ L := by
    by_contra hlt
    have hgt : L < nodeMaxRadius pts o S := lt_of_not_ge hlt
    have hsq_lt : L ^ 2 < (nodeMaxRadius pts o S) ^ 2 := by
      rw [sq, sq]
      exact mul_self_lt_mul_self hL0 hgt
    linarith only [hL_sq, hV, hsq_lt]
  have hDC_ub : D_C ≤ ((params.K : ℝ) + 1) * Real.sqrt V := by
    have heq : pts x - pts y = (pts x - o) - (pts y - o) := by abel
    have htri : ‖pts x - pts y‖ ≤ ‖pts x - o‖ + ‖pts y - o‖ := by
      rw [heq]; exact norm_sub_le _ _
    have hsum : ‖pts x - o‖ + ‖pts y - o‖ ≤ ((params.K : ℝ) + 1) * Real.sqrt V := by
      have hk1 : Real.sqrt V + (params.K : ℝ) * Real.sqrt V = ((params.K : ℝ) + 1) * Real.sqrt V := by
        ring
      linarith only [hx_ball, hy_elig_norm, hk1]
    linarith only [hxy_dist, htri, hsum]
  have hγ1 : (1 : ℝ) < (params.γ : ℝ) := by exact_mod_cast params.one_lt_γ
  have he0 : (0 : ℝ) < (params.e : ℝ) := by exact_mod_cast params.e_pos
  have hlam1 : (1 : ℝ) < (params.lam : ℝ) := by exact_mod_cast params.one_lt_lam
  have hκ_eq : (params.κ : ℝ) = (params.γ : ℝ) + 2 * (params.e : ℝ) := by
    simp [LocalScaleParams.κ, localScaleKappa]
  have hκ_pos : 0 < (params.κ : ℝ) := by linarith only [hγ1, he0, hκ_eq]
  have hlam_pos : 0 < (params.lam : ℝ) := by linarith only [hlam1]
  have hsqrt_pos : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV_pos
  have hL_lt_DC_c : L < D_C / params.c := (lt_div_iff₀ hc_pos).mpr (by linarith only [hDC_gt])
  have hDC_c_lt_κ : D_C / params.c < D_C / (params.κ : ℝ) :=
    div_lt_div_of_pos_left hDC_pos hκ_pos params.κ_lt_c
  have hR0_lt : distScale params.lam V 0 < D_C / (params.κ : ℝ) := by
    have hR0 : distScale params.lam V 0 = Real.sqrt V / 2 := by simp [distScale]
    linarith only [hR0, hsqrt_pos, hsqrt_le_L, hL_lt_DC_c, hDC_c_lt_κ]
  obtain ⟨ℓ, hℓ_le_J, hRℓ_lt_κ, hRℓ_ge_κlam⟩ :=
    Proof_lem_5_5.exists_scale_index params V D_C hV_pos hDC_pos hR0_lt hDC_ub
  let R_ℓ := distScale params.lam V ℓ
  change R_ℓ < D_C / (params.κ : ℝ) at hRℓ_lt_κ
  change D_C / ((params.κ : ℝ) * (params.lam : ℝ)) ≤ R_ℓ at hRℓ_ge_κlam
  have hDC_c_lt_Rℓ : D_C / params.c < R_ℓ :=
    lt_of_lt_of_le (div_lt_div_of_pos_left hDC_pos (mul_pos hκ_pos hlam_pos) params.κ_mul_lam_lt_c)
      hRℓ_ge_κlam
  have hL_lt_Rℓ : L < R_ℓ := lt_trans hL_lt_DC_c hDC_c_lt_Rℓ
  have hsqrt_lt_Rℓ : Real.sqrt V < R_ℓ := lt_of_le_of_lt hsqrt_le_L hL_lt_Rℓ
  have hRℓ_pos : 0 < R_ℓ := lt_trans hsqrt_pos hsqrt_lt_Rℓ
  have hm0_pos : 0 < params.m0 := Proof_lem_5_5.params_m0_pos params
  have hm0_inv_le_e : 1 / (params.m0 : ℝ) ≤ (params.e : ℝ) := Proof_lem_5_5.one_div_m0_le_e params
  have hsqrt_div_m0 : Real.sqrt V / (params.m0 : ℝ) ≤ (params.e : ℝ) * Real.sqrt V := by
    have h1 : Real.sqrt V / (params.m0 : ℝ) = (1 / (params.m0 : ℝ)) * Real.sqrt V := by ring
    rw [h1]
    exact mul_le_mul_of_nonneg_right hm0_inv_le_e hsqrt_pos.le
  let j := shellIndex params.m0 o V (pts x)
  let k := shellIndex params.m0 o V (pts y)
  let rj := shellRadius params.m0 V j
  let rk := shellRadius params.m0 V k
  let x_tilde := inwardRound params.m0 o V (pts x)
  let y_tilde := inwardRound params.m0 o V (pts y)
  obtain ⟨hrj0, hrj_le, hx_tilde_norm, _, hx_err_m0⟩ :=
    Proof_lem_5_5.inwardRound_props params.m0 hm0_pos o (pts x) V hV_pos
  obtain ⟨hrk0, hrk_le, hy_tilde_norm, _, hy_err_m0⟩ :=
    Proof_lem_5_5.inwardRound_props params.m0 hm0_pos o (pts y) V hV_pos
  change 0 ≤ rj at hrj0
  change rj ≤ ‖pts x - o‖ at hrj_le
  change ‖x_tilde - o‖ = rj at hx_tilde_norm
  change ‖pts x - x_tilde‖ < Real.sqrt V / (params.m0 : ℝ) at hx_err_m0
  change 0 ≤ rk at hrk0
  change rk ≤ ‖pts y - o‖ at hrk_le
  change ‖y_tilde - o‖ = rk at hy_tilde_norm
  change ‖pts y - y_tilde‖ < Real.sqrt V / (params.m0 : ℝ) at hy_err_m0
  have hx_err : ‖pts x - x_tilde‖ < (params.e : ℝ) * R_ℓ := by
    have he_lt : (params.e : ℝ) * Real.sqrt V < (params.e : ℝ) * R_ℓ :=
      mul_lt_mul_of_pos_left hsqrt_lt_Rℓ he0
    linarith only [hx_err_m0, hsqrt_div_m0, he_lt]
  have hy_err : ‖pts y - y_tilde‖ < (params.e : ℝ) * R_ℓ := by
    have he_lt : (params.e : ℝ) * Real.sqrt V < (params.e : ℝ) * R_ℓ :=
      mul_lt_mul_of_pos_left hsqrt_lt_Rℓ he0
    linarith only [hy_err_m0, hsqrt_div_m0, he_lt]
  have htri_round : D_C ≤ ‖pts x - x_tilde‖ + ‖x_tilde - y_tilde‖ + ‖pts y - y_tilde‖ := by
    have heq : pts x - pts y = (pts x - x_tilde) + ((x_tilde - y_tilde) + (y_tilde - pts y)) := by
      abel
    have h1 : ‖pts x - pts y‖ ≤ ‖pts x - x_tilde‖ + ‖(x_tilde - y_tilde) + (y_tilde - pts y)‖ := by
      rw [heq]; exact norm_add_le _ _
    have h2 : ‖(x_tilde - y_tilde) + (y_tilde - pts y)‖ ≤ ‖x_tilde - y_tilde‖ + ‖y_tilde - pts y‖ :=
      norm_add_le _ _
    have h3 : ‖y_tilde - pts y‖ = ‖pts y - y_tilde‖ := norm_sub_rev _ _
    linarith only [hxy_dist, h1, h2, h3]
  have hκ_Rℓ_lt : (params.κ : ℝ) * R_ℓ < D_C := by
    have h1 : R_ℓ * (params.κ : ℝ) < D_C := (lt_div_iff₀ hκ_pos).mp hRℓ_lt_κ
    have hcomm : (params.κ : ℝ) * R_ℓ = R_ℓ * (params.κ : ℝ) := mul_comm _ _
    linarith only [h1, hcomm]
  have hstrong_ineq : (params.γ : ℝ) * R_ℓ < ‖x_tilde - y_tilde‖ := by
    have hκ_expand : (params.κ : ℝ) * R_ℓ = (params.γ : ℝ) * R_ℓ + 2 * ((params.e : ℝ) * R_ℓ) := by
      rw [hκ_eq]; ring
    linarith only [hκ_expand, hκ_Rℓ_lt, htri_round, hx_err, hy_err]
  have htilde_le_sum : ‖x_tilde - y_tilde‖ ≤ rj + rk := by
    have heq : x_tilde - y_tilde = (x_tilde - o) - (y_tilde - o) := by abel
    calc ‖x_tilde - y_tilde‖ = ‖(x_tilde - o) - (y_tilde - o)‖ := by rw [heq]
      _ ≤ ‖x_tilde - o‖ + ‖y_tilde - o‖ := norm_sub_le _ _
      _ = rj + rk := by rw [hx_tilde_norm, hy_tilde_norm]
  have hRℓ_lt_γRℓ : R_ℓ < (params.γ : ℝ) * R_ℓ := lt_mul_of_one_lt_left hRℓ_pos hγ1
  have hrj_lt_Rℓ : rj < R_ℓ := lt_of_le_of_lt (le_trans hrj_le hx_ball) hsqrt_lt_Rℓ
  have hrk_lt_Rℓ : rk < R_ℓ := lt_of_le_of_lt (le_trans hrk_le (le_trans hy_R hRS_le_L)) hL_lt_Rℓ
  have hj1 : 1 ≤ j := by
    by_contra hj0
    have hj_eq : j = 0 := by omega
    have hrj_eq : rj = 0 := by simp [rj, hj_eq, shellRadius]
    linarith only [hRℓ_lt_γRℓ, hstrong_ineq, htilde_le_sum, hrk_lt_Rℓ, hrj_eq]
  have hk1 : 1 ≤ k := by
    by_contra hk0
    have hk_eq : k = 0 := by omega
    have hrk_eq : rk = 0 := by simp [rk, hk_eq, shellRadius]
    linarith only [hRℓ_lt_γRℓ, hstrong_ineq, htilde_le_sum, hrj_lt_Rℓ, hrk_eq]
  have hj2 : j ≤ params.m0 := by
    have h1 : j ≤ 1 * params.m0 :=
      Proof_lem_5_5.shellIndex_le_mul params.m0 1 o (pts x) V hV_pos (by simpa using hx_ball)
    omega
  have hK_pos : 0 < params.K := Proof_lem_5_5.params_K_pos params
  have hk2 : k ≤ maxShellIndex params.m0 params.K := by
    unfold maxShellIndex
    have hK_cast : ((params.K.toNat : ℕ) : ℝ) = (params.K : ℝ) := by
      have h1 : (params.K.toNat : ℤ) = params.K := Int.toNat_of_nonneg hK_pos.le
      exact_mod_cast h1
    apply Proof_lem_5_5.shellIndex_le_mul params.m0 params.K.toNat o (pts y) V hV_pos
    simpa [hK_cast] using hy_elig_norm
  have hret : SatisfiesRetentionCond params.m0 params.γ params.lam V j k ℓ := by
    refine ⟨?_, le_of_lt (lt_of_lt_of_le hstrong_ineq htilde_le_sum)⟩
    change rj ^ 2 + rk ^ 2 ≤ R_ℓ ^ 2
    have hrj_sq : rj ^ 2 ≤ V := by
      have h1 : rj ≤ Real.sqrt V := le_trans hrj_le hx_ball
      have h2 : rj ^ 2 ≤ (Real.sqrt V) ^ 2 := by
        rw [sq, sq]
        exact mul_self_le_mul_self hrj0 h1
      rwa [Real.sq_sqrt hV_pos.le] at h2
    have hrk_sq : rk ^ 2 ≤ (nodeMaxRadius pts o S) ^ 2 := by
      have h1 : rk ≤ nodeMaxRadius pts o S := le_trans hrk_le hy_R
      rw [sq, sq]
      exact mul_self_le_mul_self hrk0 h1
    have hL_sq_le : L ^ 2 ≤ R_ℓ ^ 2 := by
      rw [sq, sq]
      exact mul_self_le_mul_self hL0 hL_lt_Rℓ.le
    linarith only [hrj_sq, hrk_sq, hL_sq, hL_sq_le]
  let cfg : ShellConfig := ⟨j, k, ℓ⟩
  have hcfg_mem : cfg ∈ params.retainedConfigs V :=
    Proof_lem_5_5.mem_retainedConfigs_mk params V j k ℓ hj1 hj2 hk1 hk2 hℓ_le_J hret
  have hx_VL : x ∈ configLeftVertices pts params.m0 o V S j := by
    unfold configLeftVertices shellSubset
    exact Finset.mem_filter.mpr ⟨hx_core, rfl⟩
  have hy_VR : y ∈ configRightVertices pts params.m0 o V params.K S k := by
    unfold configRightVertices shellSubset
    exact Finset.mem_filter.mpr ⟨hy_elig, rfl⟩
  have hxy_strong : (x, y) ∈ configStrongEdges pts params.m0 params.γ params.lam o V params.K S j k ℓ := by
    unfold configStrongEdges strongEdgesOn
    exact Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hx_VL, hy_VR⟩, hstrong_ineq⟩
  have hm_cfg := h_match hV_pos cfg hcfg_mem
  have hM_ne : (M cfg).Nonempty := by
    apply Finset.nonempty_iff_ne_empty.mpr
    intro hM_empty
    have hdisj := hm_cfg.1.2.2
    change Disjoint (configStrongEdges pts params.m0 params.γ params.lam o V params.K S j k ℓ)
      (unmatchedLeft (configLeftVertices pts params.m0 o V S j) (M cfg) ×ˢ
       unmatchedRight (configRightVertices pts params.m0 o V params.K S k) (M cfg)) at hdisj
    have hx_unm : x ∈ unmatchedLeft (configLeftVertices pts params.m0 o V S j) (M cfg) := by
      unfold unmatchedLeft
      refine Finset.mem_filter.mpr ⟨hx_VL, ?_⟩
      intro z hz
      rw [hM_empty] at hz
      exact Finset.notMem_empty _ hz
    have hy_unm : y ∈ unmatchedRight (configRightVertices pts params.m0 o V params.K S k) (M cfg) := by
      unfold unmatchedRight
      refine Finset.mem_filter.mpr ⟨hy_VR, ?_⟩
      intro z hz
      rw [hM_empty] at hz
      exact Finset.notMem_empty _ hz
    exact (Finset.disjoint_left.mp hdisj hxy_strong) (Finset.mem_product.mpr ⟨hx_unm, hy_unm⟩)
  have h_lem54_match : ∀ c' ∈ retainedConfigs params.e params.γ params.lam params.K V,
      M c' ⊆ configWeakEdges pts (shellSubdiv params.e) params.lam o V params.K S c'.j c'.k c'.ℓ ∧
      IsBipartiteMatching
        (configLeftVertices pts (shellSubdiv params.e) o V S c'.j)
        (configRightVertices pts (shellSubdiv params.e) o V params.K S c'.k)
        (M c') ∧
      IsStoredMatchingEdge (M c') (stored c') := by
    intro c' hc'
    have hm' := h_match hV_pos c' hc'
    exact ⟨hm'.1.1, hm'.1.2.1, hm'.2⟩
  have hRℓ_lt_W : R_ℓ < params.nodeRetainedEstimate pts V L stored :=
    (h_lem_5_4 d ι pts o V params.e S L hV_pos params.e_pos hL_cond).2
      params.γ params.lam params.K params.one_lt_γ params.one_lt_lam hK_pos
      M stored h_lem54_match cfg hcfg_mem hM_ne
  exact le_of_lt (lt_trans hDC_c_lt_Rℓ hRℓ_lt_W)

end UL
