import UL.Stmt.clm_7_3_las_vegas_endpoint
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_chain_contraction
import UL.Stmt.clm_5_1_block_witness
import UL.Stmt.lem_5_2
import UL.Stmt.lem_A_1
import UL.Stmt.lem_A_2
import UL.Stmt.claim_A_2_deletion_witness
import UL.Stmt.claim_C_3_sync_suffix
import UL.Stmt.clm_7_2_chain_schedule
import UL.Stmt.lem_7_2
import UL.Proof.clm_7_3_las_vegas_endpoint.CG11_AssembleB
import UL.Proof.clm_7_3_las_vegas_endpoint.CG02_StepC2
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_7_3_las_vegas_endpoint (h_lem_5_1 : S_lem_5_1) (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction) (h_clm_5_1_block_witness : S_clm_5_1_block_witness) (h_lem_5_2 : S_lem_5_2) (h_lem_A_1 : S_lem_A_1) (h_lem_A_2 : S_lem_A_2) (h_claim_A_2_deletion_witness : S_claim_A_2_deletion_witness) (h_claim_C_3_sync_suffix : S_claim_C_3_sync_suffix) (h_clm_7_2_chain_schedule : S_clm_7_2_chain_schedule) (h_lem_7_2 : S_lem_7_2) : S_clm_7_3_las_vegas_endpoint := by
  exact UL.C12LVE.prove_clm_7_3_of_stepC2
    UL.CG02StepC2.cg02_stepC2Provider
    h_lem_5_1
    h_clm_5_1_chain_contraction
    h_clm_5_1_block_witness
    h_lem_5_2
    h_lem_A_1
    h_lem_A_2
    h_claim_A_2_deletion_witness
    h_claim_C_3_sync_suffix
    h_clm_7_2_chain_schedule
    h_lem_7_2

end UL
