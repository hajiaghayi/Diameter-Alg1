import Mathlib
import UL.Def.def_explicit_tradeoff_curve
import UL.Def.def_6_search_exponents
set_option autoImplicit false

namespace UL.Proof_lem_9_1

noncomputable def C_q_val (c C_h : ℝ) : ℝ :=
  2 + 2 * (2 / Real.sqrt (1 - (g_c c) ^ 2) + 1) * C_h

theorem exists_filter_param
    (c : ℝ) (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2)
    (L : ℕ) (hL_ge1 : 1 ≤ L)
    (C_h : ℝ) (hCh_nonneg : 0 ≤ C_h)
    (h : ℚ) (hh_pos : 0 < (h : ℝ)) (hh_le_g : (h : ℝ) ≤ g_c c)
    (hg_sub_h : g_c c - (h : ℝ) ≤ C_h / (L : ℝ))
    (σ : ℝ) (hσ_lo : 0 ≤ σ) (hσ_hi : σ ≤ rho_c c) :
    ∃ (x : ℚ),
      (h : ℝ) ≤ (x : ℝ) ∧
      (x : ℝ) ≤ 1 ∧
      u_search (h : ℝ) (x : ℝ) ≤ σ ∧
      q_search (h : ℝ) (x : ℝ) ≤ Q_c c σ + C_q_val c C_h / (L : ℝ) := by
  let _ := hCh_nonneg
  let g : ℝ := g_c c
  let hr : ℝ := (h : ℝ)
  have hL_pos : (0 : ℝ) < (L : ℝ) := by exact_mod_cast hL_ge1
  have hc_sq_lt_two : c ^ 2 < 2 := by
    have hsq : c ^ 2 < (Real.sqrt 2) ^ 2 :=
      sq_lt_sq' (by linarith [Real.sqrt_nonneg 2]) hc_lt
    rwa [Real.sq_sqrt (by norm_num)] at hsq
  have hc_sq_gt_one : 1 < c ^ 2 := by
    have : 1 ^ 2 < c ^ 2 := pow_lt_pow_left₀ hc_gt zero_le_one (by norm_num)
    linarith
  have hg_pos : 0 < g := by dsimp [g, g_c]; linarith
  have hg_lt_one : g < 1 := by dsimp [g, g_c]; linarith
  have hhr_lt_one : hr < 1 := lt_of_le_of_lt hh_le_g hg_lt_one
  have hg_sq_lt_one : g ^ 2 < 1 := by
    have : g ^ 2 < 1 ^ 2 := pow_lt_pow_left₀ hg_lt_one hg_pos.le (by norm_num)
    linarith
  have hhr_sq_lt_one : hr ^ 2 < 1 := by
    have : hr ^ 2 < 1 ^ 2 := pow_lt_pow_left₀ hhr_lt_one hh_pos.le (by norm_num)
    linarith
  have h1mg2_pos : 0 < 1 - g ^ 2 := by linarith
  have h1mh2_pos : 0 < 1 - hr ^ 2 := by linarith

  have hrho_c_eq : rho_c c = (1 - g) / (1 + g) := by
    dsimp [rho_c, g, g_c]
    have hc2_ne : c ^ 2 ≠ 0 := by linarith
    field_simp
    ring

  have hσ_le_one : σ ≤ 1 := by
    have h1 : (1 - g) / (1 + g) ≤ 1 := by
      rw [div_le_one (by linarith)]
      linarith
    linarith [hσ_hi, hrho_c_eq]

  have hσ_le_rhoh : σ ≤ (1 - hr) / (1 + hr) := by
    have hmono : (1 - g) / (1 + g) ≤ (1 - hr) / (1 + hr) := by
      rw [div_le_div_iff₀ (by linarith) (by linarith)]
      have : (1 - g) * (1 + hr) - (1 - hr) * (1 + g) = 2 * (hr - g) := by ring
      linarith
    linarith [hσ_hi, hrho_c_eq]

  let sh : ℝ := Real.sqrt (1 - hr ^ 2)
  let sg : ℝ := Real.sqrt (1 - g ^ 2)
  have hsh_pos : 0 < sh := Real.sqrt_pos.mpr h1mh2_pos
  have hsg_pos : 0 < sg := Real.sqrt_pos.mpr h1mg2_pos
  have hsh_sq : sh ^ 2 = 1 - hr ^ 2 := Real.sq_sqrt h1mh2_pos.le
  have hsg_sq : sg ^ 2 = 1 - g ^ 2 := Real.sq_sqrt h1mg2_pos.le

  let x_star : ℝ := hr + Real.sqrt σ * sh

  have hx_star_le_one : x_star ≤ 1 := by
    have hmul1 : σ * (1 + hr) ≤ 1 - hr := (le_div_iff₀ (by linarith)).mp hσ_le_rhoh
    have hmul2 : σ * (1 - hr ^ 2) ≤ (1 - hr) ^ 2 := by
      calc σ * (1 - hr ^ 2) = (σ * (1 + hr)) * (1 - hr) := by ring
        _ ≤ (1 - hr) * (1 - hr) := mul_le_mul_of_nonneg_right hmul1 (by linarith)
        _ = (1 - hr) ^ 2 := by ring
    have hsqrt_le : Real.sqrt σ * sh ≤ 1 - hr := by
      calc Real.sqrt σ * sh
          = Real.sqrt (σ * (1 - hr ^ 2)) := (Real.sqrt_mul hσ_lo (1 - hr ^ 2)).symm
        _ ≤ Real.sqrt ((1 - hr) ^ 2) := Real.sqrt_le_sqrt hmul2
        _ = 1 - hr := Real.sqrt_sq (by linarith)
    dsimp [x_star]
    linarith

  have hx_exists : ∃ (x : ℚ),
      hr ≤ (x : ℝ) ∧ (x : ℝ) ≤ x_star ∧ x_star - (x : ℝ) ≤ 1 / (L : ℝ) := by
    rcases eq_or_lt_of_le hσ_lo with rfl | hσ_pos
    · refine ⟨h, le_rfl, ?_, ?_⟩
      · dsimp [x_star, hr]; simp
      · dsimp [x_star, hr]; simp
    · have hlt1 : hr < x_star := by
        dsimp [x_star]
        have : 0 < Real.sqrt σ * sh := mul_pos (Real.sqrt_pos.mpr hσ_pos) hsh_pos
        linarith
      have hlt2 : x_star - 1 / (L : ℝ) < x_star := by
        have : 0 < 1 / (L : ℝ) := one_div_pos.mpr hL_pos
        linarith
      rcases exists_rat_btwn (max_lt hlt1 hlt2) with ⟨x, hx_gt, hx_lt⟩
      rcases max_lt_iff.mp hx_gt with ⟨hx_gt1, hx_gt2⟩
      exact ⟨x, hx_gt1.le, hx_lt.le, by linarith⟩

  rcases hx_exists with ⟨x, hx_lo, hx_le_star, hstar_sub⟩
  have hx_hi : (x : ℝ) ≤ 1 := hx_le_star.trans hx_star_le_one

  have hu_le : u_search hr (x : ℝ) ≤ σ := by
    have hu_eq : u_search hr (x : ℝ) = ((x : ℝ) - hr) ^ 2 / (1 - hr ^ 2) := by
      unfold u_search I_h
      field_simp [h1mh2_pos.ne']
      ring
    rw [hu_eq, div_le_iff₀ h1mh2_pos]
    have hdiff_nonneg : 0 ≤ (x : ℝ) - hr := by linarith
    have hdiff_le : (x : ℝ) - hr ≤ Real.sqrt σ * sh := by dsimp [x_star] at hx_le_star; linarith
    calc ((x : ℝ) - hr) ^ 2
        ≤ (Real.sqrt σ * sh) ^ 2 := pow_le_pow_left₀ hdiff_nonneg hdiff_le 2
      _ = (Real.sqrt σ) ^ 2 * sh ^ 2 := by ring
      _ = σ * (1 - hr ^ 2) := by rw [Real.sq_sqrt hσ_lo, hsh_sq]

  have hq_formula : ∀ y : ℝ, q_search hr y = (1 - hr * y) ^ 2 / (1 - hr ^ 2) := by
    intro y
    unfold q_search I_h
    field_simp [h1mh2_pos.ne']
    ring

  have hq_diff_star : q_search hr (x : ℝ) - q_search hr x_star ≤ 2 / (L : ℝ) := by
    rw [hq_formula (x : ℝ), hq_formula x_star]
    have hnum_eq :
        ((1 - hr * (x : ℝ)) ^ 2 - (1 - hr * x_star) ^ 2) / (1 - hr ^ 2) =
          hr * (x_star - (x : ℝ)) * (((1 - hr * (x : ℝ)) + (1 - hr * x_star)) / (1 - hr ^ 2)) := by
      field_simp [h1mh2_pos.ne']
      ring
    rw [← sub_div, hnum_eq]
    have h1x : 1 - hr * (x : ℝ) ≤ 1 - hr ^ 2 := by
      have : hr ^ 2 ≤ hr * (x : ℝ) := by
        rw [sq]
        exact mul_le_mul_of_nonneg_left hx_lo hh_pos.le
      linarith
    have h1s : 1 - hr * x_star ≤ 1 - hr ^ 2 := by
      have : hr ^ 2 ≤ hr * x_star := by
        rw [sq]
        exact mul_le_mul_of_nonneg_left (hx_lo.trans hx_le_star) hh_pos.le
      linarith
    have hfrac_le : ((1 - hr * (x : ℝ)) + (1 - hr * x_star)) / (1 - hr ^ 2) ≤ 2 := by
      rw [div_le_iff₀ h1mh2_pos]
      linarith
    have hsub_nonneg : 0 ≤ x_star - (x : ℝ) := by linarith
    have hfac_nonneg : 0 ≤ hr * (x_star - (x : ℝ)) :=
      mul_nonneg hh_pos.le hsub_nonneg
    have hprod_le : hr * (x_star - (x : ℝ)) ≤ 1 * (1 / (L : ℝ)) :=
      mul_le_mul hhr_lt_one.le hstar_sub hsub_nonneg zero_le_one
    calc hr * (x_star - (x : ℝ)) * (((1 - hr * (x : ℝ)) + (1 - hr * x_star)) / (1 - hr ^ 2))
        ≤ hr * (x_star - (x : ℝ)) * 2 := mul_le_mul_of_nonneg_left hfrac_le hfac_nonneg
      _ ≤ (1 * (1 / (L : ℝ))) * 2 := mul_le_mul_of_nonneg_right hprod_le (by norm_num)
      _ = 2 / (L : ℝ) := by ring

  let Fh : ℝ := sh - hr * Real.sqrt σ
  let Fg : ℝ := sg - g * Real.sqrt σ

  have hq_star_eq : q_search hr x_star = Fh ^ 2 := by
    rw [hq_formula x_star]
    have h1m : 1 - hr * x_star = sh * Fh := by
      dsimp [x_star, Fh]
      calc 1 - hr * (hr + Real.sqrt σ * sh)
          = (1 - hr ^ 2) - hr * Real.sqrt σ * sh := by ring
        _ = sh ^ 2 - hr * Real.sqrt σ * sh := by rw [← hsh_sq]
        _ = sh * (sh - hr * Real.sqrt σ) := by ring
    rw [h1m, ← hsh_sq]
    field_simp [hsh_pos.ne']

  have hQc_eq : Q_c c σ = Fg ^ 2 := rfl

  have hFg_nonneg : 0 ≤ Fg := by
    dsimp [Fg]
    have hmul1 : σ * (1 + g) ≤ 1 - g := by
      have : σ ≤ (1 - g) / (1 + g) := by rwa [← hrho_c_eq]
      exact (le_div_iff₀ (by linarith)).mp this
    have hg2σ_le : g ^ 2 * σ ≤ 1 - g ^ 2 := by
      have h1 : g ^ 2 ≤ (1 + g) ^ 2 := pow_le_pow_left₀ hg_pos.le (by linarith) 2
      calc g ^ 2 * σ ≤ (1 + g) ^ 2 * σ := mul_le_mul_of_nonneg_right h1 hσ_lo
        _ = (1 + g) * (σ * (1 + g)) := by ring
        _ ≤ (1 + g) * (1 - g) := mul_le_mul_of_nonneg_left hmul1 (by linarith)
        _ = 1 - g ^ 2 := by ring
    have hle : g * Real.sqrt σ ≤ sg := by
      calc g * Real.sqrt σ
          = Real.sqrt ((g * Real.sqrt σ) ^ 2) := (Real.sqrt_sq (by positivity)).symm
        _ = Real.sqrt (g ^ 2 * σ) := by
            congr 1
            rw [mul_pow, Real.sq_sqrt hσ_lo]
        _ ≤ Real.sqrt (1 - g ^ 2) := Real.sqrt_le_sqrt hg2σ_le
    linarith

  have hsg_le_sh : sg ≤ sh := by
    refine Real.sqrt_le_sqrt ?_
    have : hr ^ 2 ≤ g ^ 2 := pow_le_pow_left₀ hh_pos.le hh_le_g 2
    linarith

  have hFg_le_Fh : Fg ≤ Fh := by
    dsimp [Fg, Fh]
    have h2 : hr * Real.sqrt σ ≤ g * Real.sqrt σ :=
      mul_le_mul_of_nonneg_right hh_le_g (Real.sqrt_nonneg σ)
    linarith

  have hFh_le_one : Fh ≤ 1 := by
    dsimp [Fh]
    have hsh_le1 : sh ≤ 1 := by
      have hhr2_nn : 0 ≤ hr ^ 2 := sq_nonneg hr
      calc sh = Real.sqrt (1 - hr ^ 2) := rfl
        _ ≤ Real.sqrt 1 := Real.sqrt_le_sqrt (by linarith)
        _ = 1 := Real.sqrt_one
    have : 0 ≤ hr * Real.sqrt σ := by positivity
    linarith

  have hF_sq_diff : Fh ^ 2 - Fg ^ 2 ≤ 2 * (Fh - Fg) := by
    have hsum_le : Fh + Fg ≤ 2 := by linarith
    have hdiff_nonneg : 0 ≤ Fh - Fg := by linarith
    calc Fh ^ 2 - Fg ^ 2 = (Fh - Fg) * (Fh + Fg) := by ring
      _ ≤ (Fh - Fg) * 2 := mul_le_mul_of_nonneg_left hsum_le hdiff_nonneg
      _ = 2 * (Fh - Fg) := by ring

  have hF_diff_bound : Fh - Fg ≤ (2 / sg + 1) * (g - hr) := by
    have hrew : Fh - Fg = (sh - sg) + (g - hr) * Real.sqrt σ := by
      dsimp [Fh, Fg]; ring
    rw [hrew]
    have hsh_ge_sg : 0 ≤ sh - sg := by linarith
    have hsqrt_diff : sh - sg ≤ (2 / sg) * (g - hr) := by
      rw [div_mul_eq_mul_div, le_div_iff₀ hsg_pos]
      calc (sh - sg) * sg
          ≤ (sh - sg) * (sh + sg) := mul_le_mul_of_nonneg_left (by linarith) hsh_ge_sg
        _ = sh ^ 2 - sg ^ 2 := by ring
        _ = (1 - hr ^ 2) - (1 - g ^ 2) := by rw [hsh_sq, hsg_sq]
        _ = (g - hr) * (g + hr) := by ring
        _ ≤ (g - hr) * 2 := mul_le_mul_of_nonneg_left (by linarith) (by linarith)
        _ = 2 * (g - hr) := by ring
    have hsqrtσ_le1 : Real.sqrt σ ≤ 1 := by
      calc Real.sqrt σ ≤ Real.sqrt 1 := Real.sqrt_le_sqrt hσ_le_one
        _ = 1 := Real.sqrt_one
    have hsec : (g - hr) * Real.sqrt σ ≤ g - hr := by
      calc (g - hr) * Real.sqrt σ ≤ (g - hr) * 1 :=
            mul_le_mul_of_nonneg_left hsqrtσ_le1 (by linarith)
        _ = g - hr := mul_one _
    calc (sh - sg) + (g - hr) * Real.sqrt σ
        ≤ (2 / sg) * (g - hr) + (g - hr) := add_le_add hsqrt_diff hsec
      _ = (2 / sg + 1) * (g - hr) := by ring

  have hq_le : q_search hr (x : ℝ) ≤ Q_c c σ + C_q_val c C_h / (L : ℝ) := by
    have hcoef_nonneg : 0 ≤ 2 / sg + 1 := by positivity
    have h1 : Fh - Fg ≤ (2 / sg + 1) * (C_h / (L : ℝ)) :=
      hF_diff_bound.trans (mul_le_mul_of_nonneg_left hg_sub_h hcoef_nonneg)
    have h2 : q_search hr x_star - Q_c c σ ≤ 2 * ((2 / sg + 1) * (C_h / (L : ℝ))) := by
      rw [hq_star_eq, hQc_eq]
      linarith
    calc q_search hr (x : ℝ)
        = (q_search hr (x : ℝ) - q_search hr x_star) + (q_search hr x_star - Q_c c σ) + Q_c c σ := by
          ring
      _ ≤ 2 / (L : ℝ) + 2 * ((2 / sg + 1) * (C_h / (L : ℝ))) + Q_c c σ := by linarith
      _ = Q_c c σ + C_q_val c C_h / (L : ℝ) := by
          dsimp [C_q_val, sg, g]
          ring

  exact ⟨x, hx_lo, hx_hi, hu_le, hq_le⟩

end UL.Proof_lem_9_1
