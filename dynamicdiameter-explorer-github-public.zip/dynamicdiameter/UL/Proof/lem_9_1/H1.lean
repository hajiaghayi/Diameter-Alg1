import Mathlib
import UL.Def.def_explicit_tradeoff_curve
import UL.Def.def_paraboloid_lift_variance
import UL.Def.def_local_scale_params
import UL.Def.def_shells_configurations
import UL.Def.def_9_parameters
import UL.Stmt.clm_5_2_config_gap
import UL.Stmt.lem_5_6
set_option autoImplicit false

namespace UL.Proof_lem_9_1

noncomputable def C0_nat (c : ℝ) : ℕ :=
  Nat.ceil (32 / (c - 1)) + 1024

noncomputable def K_nat (c : ℝ) : ℕ :=
  Nat.ceil (2 / (c - 1))

noncomputable def C_shell_val (c : ℝ) : ℝ :=
  ((16 * (K_nat c + 1) * C0_nat c + 1 : ℕ) : ℝ)

noncomputable def C_cfg_val (c : ℝ) : ℝ :=
  (C_shell_val c) ^ 3

def C_h_val : ℝ := 27

noncomputable def h_min_val (c : ℝ) : ℝ :=
  45 * (c - 1) / 32

lemma one_add_mul_le_pow {d : ℝ} (hd : 0 ≤ d) (m : ℕ) :
    1 + (m : ℝ) * d ≤ (1 + d) ^ m := by
  induction m with
  | zero => simp
  | succ m ih =>
    have hpos : 0 ≤ (m : ℝ) * d ^ 2 := by positivity
    calc 1 + ((m + 1 : ℕ) : ℝ) * d
        = (1 + (m : ℝ) * d) + d := by push_cast; ring
      _ ≤ (1 + (m : ℝ) * d) + d + (m : ℝ) * d ^ 2 := by linarith
      _ = (1 + (m : ℝ) * d) * (1 + d) := by ring
      _ ≤ (1 + d) ^ m * (1 + d) := mul_le_mul_of_nonneg_right ih (by linarith)
      _ = (1 + d) ^ (m + 1) := by ring

lemma one_le_L_n {n : ℕ} (hn : 2 ≤ n) : 1 ≤ L_n n := by
  unfold L_n
  have h4 : 2 ≤ Nat.clog 2 4 := by decide
  have hmono : Nat.clog 2 4 ≤ Nat.clog 2 (2 * n) :=
    Nat.clog_mono_right 2 (by omega)
  omega

lemma retained_of_mem_retainedConfigs (params : LocalScaleParams) (V : ℝ)
    (hK_nonneg : 0 ≤ params.K) {cfg : ShellConfig}
    (hcfg : cfg ∈ params.retainedConfigs V) :
    IsRetainedConfig params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ := by
  classical
  unfold LocalScaleParams.retainedConfigs retainedConfigs at hcfg
  rw [Finset.mem_filter] at hcfg
  rcases hcfg with ⟨hvalid, hret⟩
  unfold allShellConfigs allShellConfigTriples at hvalid
  rw [Finset.mem_map] at hvalid
  rcases hvalid with ⟨⟨j0, k0, ℓ0⟩, hmem, heq⟩
  simp only [Function.Embedding.coeFn_mk] at heq
  subst heq
  rw [Finset.mem_product, Finset.mem_product, Finset.mem_Icc, Finset.mem_Icc, Finset.mem_Icc] at hmem
  rcases hmem with ⟨⟨hj1, hj2⟩, ⟨hk1, hk2⟩, ⟨_, hℓ2⟩⟩
  refine ⟨⟨hj1, hj2, hk1, ?_, hℓ2⟩, hret⟩
  unfold maxShellIndex at hk2
  have hk_int : (k0 : ℤ) ≤ (params.K.toNat : ℤ) * (params.m0 : ℤ) := by exact_mod_cast hk2
  rwa [Int.toNat_of_nonneg hK_nonneg] at hk_int

theorem exists_geom_params
    (h_clm_5_2_config_gap : S_clm_5_2_config_gap)
    (h_lem_5_6 : S_lem_5_6)
    (c : ℝ) (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2)
    (n : ℕ) (hn : 2 ≤ n) :
    let L : ℕ := L_n n
    ∃ (params : LocalScaleParams) (h : ℚ),
      params.c = c ∧
      (params.m0 : ℝ) ≤ C_shell_val c * (L : ℝ) ∧
      (params.maxShellIndex : ℝ) ≤ C_shell_val c * (L : ℝ) ∧
      ((params.J + 1 : ℕ) : ℝ) ≤ C_shell_val c * (L : ℝ) ∧
      ((allShellConfigs params.m0 params.K params.J).card : ℝ) ≤ C_cfg_val c * (L : ℝ) ^ 3 ∧
      (∀ V : ℝ, ((params.retainedConfigs V).card : ℝ) ≤ C_cfg_val c * (L : ℝ) ^ 3) ∧
      (params.e : ℝ) ≤ ((params.γ : ℝ) ^ 2 - 1) / 16 ∧
      (h : ℝ) = ((params.γ : ℝ) ^ 2 - 1) - 11 * (params.e : ℝ) ∧
      h_min_val c ≤ (h : ℝ) ∧
      (h : ℝ) ≤ g_c c ∧
      g_c c - (h : ℝ) ≤ C_h_val / (L : ℝ) ∧
      (∀ (V : ℝ), 0 < V →
        ∀ cfg ∈ params.retainedConfigs V,
          ∃ (A B : ℚ),
            0 < A ∧
            0 ≤ B ∧
            A ^ 2 + B ^ 2 = 1 ∧
            ∀ (d : ℕ) (u z z_bar : EuclideanSpace ℝ (Fin d)),
              ‖u‖ = 1 →
              ‖z‖ = 1 →
              ‖z_bar‖ = 1 →
              ‖z_bar - z‖ ≤ (params.e : ℝ) / 8 →
              (params.thresholdA V cfg.j cfg.k cfg.ℓ ≤ inner ℝ z u →
                (h : ℝ) ≤ inner ℝ
                  (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ)))
                  (liftedPoint ((A : ℝ) • u) (B : ℝ))) ∧
              (inner ℝ z u ≤ params.thresholdB V cfg.j cfg.k cfg.ℓ →
                inner ℝ
                  (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ)))
                  (liftedPoint ((A : ℝ) • u) (B : ℝ)) < 0)) := by
  intro L
  have hL_ge1 : 1 ≤ L := one_le_L_n hn
  have hL_pos : (0 : ℝ) < (L : ℝ) := by exact_mod_cast hL_ge1
  have hL_ge1_real : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast hL_ge1
  have hc_sub_pos : 0 < c - 1 := by linarith
  have hc_sq_lt_two : c ^ 2 < 2 := by
    have hsq : c ^ 2 < (Real.sqrt 2) ^ 2 :=
      sq_lt_sq' (by linarith [Real.sqrt_nonneg 2]) hc_lt
    rwa [Real.sq_sqrt (by norm_num)] at hsq
  have hc_lt_two : c < 2 := by
    have hmul : c * 1 < c * c := mul_lt_mul_of_pos_left hc_gt (by linarith)
    have hcc : c * c = c ^ 2 := by ring
    linarith

  let C0 : ℕ := C0_nat c
  let Kn : ℕ := K_nat c
  have hC0_ge1 : 1 ≤ C0 := by unfold C0 C0_nat; omega
  let N_e : ℕ := C0 * L
  have hNe_pos_nat : 0 < N_e := Nat.mul_pos hC0_ge1 hL_ge1
  have hNe_pos : (0 : ℝ) < (N_e : ℝ) := by exact_mod_cast hNe_pos_nat

  let e : ℚ := 1 / (N_e : ℚ)
  have he_pos : 0 < e := by
    dsimp [e]
    exact one_div_pos.mpr (by exact_mod_cast hNe_pos_nat)
  have he_real : (e : ℝ) = 1 / (N_e : ℝ) := by
    dsimp [e]; push_cast; rfl
  have he_pos_real : 0 < (e : ℝ) := by exact_mod_cast he_pos

  have hNe_ge_c : 32 / (c - 1) ≤ (N_e : ℝ) := by
    have hceil : 32 / (c - 1) ≤ (Nat.ceil (32 / (c - 1)) : ℝ) := Nat.le_ceil _
    have hC0_le : (Nat.ceil (32 / (c - 1)) : ℝ) ≤ (C0 : ℝ) := by
      dsimp [C0, C0_nat]; push_cast; linarith
    have hmul : (C0 : ℝ) * 1 ≤ (C0 : ℝ) * (L : ℝ) :=
      mul_le_mul_of_nonneg_left hL_ge1_real (by positivity)
    have hNe_eq : (N_e : ℝ) = (C0 : ℝ) * (L : ℝ) := by dsimp [N_e]; push_cast; rfl
    linarith

  have he_le_c32 : (e : ℝ) ≤ (c - 1) / 32 := by
    rw [he_real, div_le_div_iff₀ hNe_pos (by norm_num)]
    have := (div_le_iff₀ hc_sub_pos).mp hNe_ge_c
    linarith

  have he_le_invL : (e : ℝ) ≤ 1 / (L : ℝ) := by
    rw [he_real]
    refine one_div_le_one_div_of_le hL_pos ?_
    have hC0_real : (1 : ℝ) ≤ (C0 : ℝ) := by exact_mod_cast hC0_ge1
    have hNe_eq : (N_e : ℝ) = (C0 : ℝ) * (L : ℝ) := by dsimp [N_e]; push_cast; rfl
    rw [hNe_eq]
    calc (L : ℝ) = 1 * (L : ℝ) := (one_mul _).symm
      _ ≤ (C0 : ℝ) * (L : ℝ) := mul_le_mul_of_nonneg_right hC0_real hL_pos.le

  have h_interval : c - 4 * (e : ℝ) < c - 3 * (e : ℝ) := by linarith
  rcases exists_rat_btwn h_interval with ⟨γ, hγ_gt, hγ_lt⟩

  have hγ_gt_one_real : (1 : ℝ) < (γ : ℝ) := by linarith
  have hγ_gt_one : 1 < γ := by exact_mod_cast hγ_gt_one_real

  let κ : ℚ := localScaleKappa e γ
  have hκ_real : (κ : ℝ) = (γ : ℝ) + 2 * (e : ℝ) := by
    dsimp [κ, localScaleKappa]; push_cast; ring
  have hκ_lt_c : (κ : ℝ) < c := by linarith
  have hκ_gt_one : (1 : ℝ) < (κ : ℝ) := by linarith
  have hκ_pos_rat : 0 < κ := by
    have : (0 : ℝ) < (κ : ℝ) := by linarith
    exact_mod_cast this

  let lam : ℚ := 1 + e / (4 * κ)
  have hlam_gt_one : 1 < lam := by
    dsimp [lam]
    have : 0 < e / (4 * κ) := div_pos he_pos (by linarith)
    linarith
  have hκ_mul_lam_lt_c : (κ : ℝ) * (lam : ℝ) < c := by
    have hκ_ne : (κ : ℝ) ≠ 0 := by linarith
    have hlam_real : (lam : ℝ) = 1 + (e : ℝ) / (4 * (κ : ℝ)) := by
      dsimp [lam]; push_cast; rfl
    have hprod : (κ : ℝ) * (lam : ℝ) = (κ : ℝ) + (e : ℝ) / 4 := by
      rw [hlam_real]; field_simp
    linarith

  let K : ℤ := (Kn : ℤ)
  have hK_ge : 2 / (c - 1) ≤ (K : ℝ) := by
    have hceil : 2 / (c - 1) ≤ (Kn : ℝ) := Nat.le_ceil _
    simpa [K] using hceil

  let params : LocalScaleParams :=
    { c := c
      e := e
      γ := γ
      lam := lam
      K := K
      one_lt_c := hc_gt
      c_lt_sqrt_two := hc_lt
      e_pos := he_pos
      one_lt_γ := hγ_gt_one
      one_lt_lam := hlam_gt_one
      κ_lt_c := hκ_lt_c
      κ_mul_lam_lt_c := hκ_mul_lam_lt_c
      K_ge := hK_ge }

  have hm0_eq : params.m0 = N_e := by
    change Nat.ceil (1 / (1 / (N_e : ℚ))) = N_e
    rw [one_div_one_div, Nat.ceil_natCast]

  have hm0_bound : (params.m0 : ℝ) ≤ C_shell_val c * (L : ℝ) := by
    rw [hm0_eq]
    have hnat : C0 * L ≤ (16 * (Kn + 1) * C0 + 1) * L := by
      refine Nat.mul_le_mul_right L ?_
      calc C0 = 1 * C0 := (Nat.one_mul C0).symm
        _ ≤ 16 * (Kn + 1) * C0 := Nat.mul_le_mul_right C0 (by omega)
        _ ≤ 16 * (Kn + 1) * C0 + 1 := Nat.le_succ _
    have hreal : ((C0 * L : ℕ) : ℝ) ≤ (((16 * (Kn + 1) * C0 + 1) * L : ℕ) : ℝ) := by
      exact_mod_cast hnat
    simpa [N_e, C_shell_val, Kn, C0, Nat.cast_mul] using hreal

  have hmaxShell_eq : params.maxShellIndex = Kn * N_e := by
    change K.toNat * params.m0 = Kn * N_e
    rw [hm0_eq]
    simp [K]

  have hmaxShell_bound : (params.maxShellIndex : ℝ) ≤ C_shell_val c * (L : ℝ) := by
    rw [hmaxShell_eq]
    have hnat : Kn * (C0 * L) ≤ (16 * (Kn + 1) * C0 + 1) * L := by
      have h1 : Kn * C0 ≤ 16 * (Kn + 1) * C0 + 1 := by
        calc Kn * C0 ≤ 16 * (Kn + 1) * C0 := Nat.mul_le_mul_right C0 (by omega)
          _ ≤ 16 * (Kn + 1) * C0 + 1 := Nat.le_succ _
      calc Kn * (C0 * L) = (Kn * C0) * L := (Nat.mul_assoc _ _ _).symm
        _ ≤ (16 * (Kn + 1) * C0 + 1) * L := Nat.mul_le_mul_right L h1
    have hreal : ((Kn * (C0 * L) : ℕ) : ℝ) ≤ (((16 * (Kn + 1) * C0 + 1) * L : ℕ) : ℝ) := by
      exact_mod_cast hnat
    simpa [N_e, C_shell_val, Kn, C0, Nat.cast_mul] using hreal

  have hJ_le : params.J ≤ 16 * (Kn + 1) * C0 * L := by
    change sInf {ℓ : ℕ | (K : ℝ) + 1 ≤ (lam : ℝ) ^ ℓ / 2} ≤ 16 * (Kn + 1) * C0 * L
    refine Nat.sInf_le ?_
    simp only [Set.mem_setOf_eq]
    let ℓ0 : ℕ := 16 * (Kn + 1) * C0 * L
    let d : ℝ := (e : ℝ) / (4 * (κ : ℝ))
    have hd_nonneg : 0 ≤ d := by
      dsimp [d]
      exact div_nonneg he_pos_real.le (by linarith)
    have hlam_eq : (lam : ℝ) = 1 + d := by
      dsimp [lam, d]; push_cast; rfl
    have hd_ge : (e : ℝ) / 8 ≤ d := by
      dsimp [d]
      exact div_le_div_of_nonneg_left he_pos_real.le (by linarith) (by linarith)
    have hbern : 1 + (ℓ0 : ℝ) * d ≤ (lam : ℝ) ^ ℓ0 := by
      rw [hlam_eq]
      exact one_add_mul_le_pow hd_nonneg ℓ0
    have hmul_ge : (ℓ0 : ℝ) * ((e : ℝ) / 8) ≤ (ℓ0 : ℝ) * d :=
      mul_le_mul_of_nonneg_left hd_ge (by positivity)
    have hℓ0_val : (ℓ0 : ℝ) * ((e : ℝ) / 8) = 2 * ((K : ℝ) + 1) := by
      have hℓ0_eq : (ℓ0 : ℝ) = 16 * ((Kn : ℝ) + 1) * (N_e : ℝ) := by
        dsimp [ℓ0, N_e]; push_cast; ring
      have hK_eq : (K : ℝ) = (Kn : ℝ) := by simp [K]
      rw [hℓ0_eq, he_real, hK_eq]
      field_simp [hNe_pos.ne']
      ring
    linarith

  have hJ1_bound : ((params.J + 1 : ℕ) : ℝ) ≤ C_shell_val c * (L : ℝ) := by
    have hnat : params.J + 1 ≤ (16 * (Kn + 1) * C0 + 1) * L := by
      calc params.J + 1
          ≤ 16 * (Kn + 1) * C0 * L + 1 := Nat.add_le_add_right hJ_le 1
        _ ≤ 16 * (Kn + 1) * C0 * L + L := Nat.add_le_add_left hL_ge1 _
        _ = (16 * (Kn + 1) * C0 + 1) * L := by ring
    have hreal : ((params.J + 1 : ℕ) : ℝ) ≤ (((16 * (Kn + 1) * C0 + 1) * L : ℕ) : ℝ) := by
      exact_mod_cast hnat
    simpa [C_shell_val, Kn, C0, Nat.cast_mul] using hreal

  have hCshell_nn : 0 ≤ C_shell_val c := by unfold C_shell_val; positivity
  have hCL_nn : 0 ≤ C_shell_val c * (L : ℝ) := mul_nonneg hCshell_nn hL_pos.le

  have hall_card :
      ((allShellConfigs params.m0 params.K params.J).card : ℝ) ≤ C_cfg_val c * (L : ℝ) ^ 3 := by
    have hcard_eq :
        (allShellConfigs params.m0 params.K params.J).card =
          params.m0 * params.maxShellIndex * (params.J + 1) := by
      unfold allShellConfigs allShellConfigTriples LocalScaleParams.maxShellIndex
      rw [Finset.card_map, Finset.card_product, Finset.card_product]
      simp [Nat.card_Icc, Nat.mul_assoc]
    rw [hcard_eq]
    push_cast
    have h1 := hm0_bound
    have h2 := hmaxShell_bound
    have h3 : (params.J : ℝ) + 1 ≤ C_shell_val c * (L : ℝ) := by exact_mod_cast hJ1_bound
    have h12 : (params.m0 : ℝ) * (params.maxShellIndex : ℝ) ≤
        (C_shell_val c * (L : ℝ)) * (C_shell_val c * (L : ℝ)) :=
      mul_le_mul h1 h2 (by positivity) hCL_nn
    have h123 : (params.m0 : ℝ) * (params.maxShellIndex : ℝ) * ((params.J : ℝ) + 1) ≤
        (C_shell_val c * (L : ℝ)) * (C_shell_val c * (L : ℝ)) * (C_shell_val c * (L : ℝ)) :=
      mul_le_mul h12 h3 (by positivity) (mul_nonneg hCL_nn hCL_nn)
    calc (params.m0 : ℝ) * (params.maxShellIndex : ℝ) * ((params.J : ℝ) + 1)
        ≤ (C_shell_val c * (L : ℝ)) * (C_shell_val c * (L : ℝ)) * (C_shell_val c * (L : ℝ)) := h123
      _ = C_cfg_val c * (L : ℝ) ^ 3 := by unfold C_cfg_val; ring

  have hret_card : ∀ V : ℝ, ((params.retainedConfigs V).card : ℝ) ≤ C_cfg_val c * (L : ℝ) ^ 3 := by
    intro V
    classical
    have hsub : (params.retainedConfigs V).card ≤
        (allShellConfigs params.m0 params.K params.J).card :=
      Finset.card_filter_le _ _
    have hsub_real : ((params.retainedConfigs V).card : ℝ) ≤
        ((allShellConfigs params.m0 params.K params.J).card : ℝ) := by exact_mod_cast hsub
    exact hsub_real.trans hall_card

  let h : ℚ := (γ ^ 2 - 1) - 11 * e
  have hh_eq : (h : ℝ) = ((params.γ : ℝ) ^ 2 - 1) - 11 * (params.e : ℝ) := by
    dsimp [h, params]; push_cast; ring

  have hγ_lb : 1 + 7 * (c - 1) / 8 ≤ (γ : ℝ) := by linarith
  have hγ2_lb : 7 * (c - 1) / 4 ≤ (γ : ℝ) ^ 2 - 1 := by
    have hp : (1 + 7 * (c - 1) / 8) ^ 2 ≤ (γ : ℝ) ^ 2 :=
      pow_le_pow_left₀ (by linarith) hγ_lb 2
    have hexp : (1 + 7 * (c - 1) / 8) ^ 2 - 1 = 7 * (c - 1) / 4 + 49 * (c - 1) ^ 2 / 64 := by
      ring
    have hsq : 0 ≤ (c - 1) ^ 2 := sq_nonneg (c - 1)
    linarith

  have he_le_g16 : (params.e : ℝ) ≤ ((params.γ : ℝ) ^ 2 - 1) / 16 := by
    dsimp [params]; linarith

  have hh_ge_min : h_min_val c ≤ (h : ℝ) := by
    rw [hh_eq]; dsimp [params, h_min_val]; linarith

  have hh_le_gc : (h : ℝ) ≤ g_c c := by
    rw [hh_eq]; dsimp [params, g_c]
    have hγ_lt_c : (γ : ℝ) < c := by linarith
    have hγ2_lt_c2 : (γ : ℝ) ^ 2 < c ^ 2 :=
      pow_lt_pow_left₀ hγ_lt_c (by linarith) (by norm_num)
    linarith

  have hgc_sub_h : g_c c - (h : ℝ) ≤ C_h_val / (L : ℝ) := by
    rw [hh_eq]; dsimp [params, g_c, C_h_val]
    have hdiff_cγ : c ^ 2 - (γ : ℝ) ^ 2 ≤ 16 * (e : ℝ) := by
      calc c ^ 2 - (γ : ℝ) ^ 2 = (c - (γ : ℝ)) * (c + (γ : ℝ)) := by ring
        _ ≤ (4 * (e : ℝ)) * 4 := mul_le_mul (by linarith) (by linarith) (by linarith) (by positivity)
        _ = 16 * (e : ℝ) := by ring
    have h27e : (c ^ 2 - 1) - (((γ : ℝ) ^ 2 - 1) - 11 * (e : ℝ)) ≤ 27 * (e : ℝ) := by linarith
    have h27L : 27 * (e : ℝ) ≤ 27 / (L : ℝ) := by
      calc 27 * (e : ℝ) ≤ 27 * (1 / (L : ℝ)) := mul_le_mul_of_nonneg_left he_le_invL (by norm_num)
        _ = 27 / (L : ℝ) := by ring
    linarith

  refine ⟨params, h, rfl, hm0_bound, hmaxShell_bound, hJ1_bound, hall_card, hret_card,
    he_le_g16, hh_eq, hh_ge_min, hh_le_gc, hgc_sub_h, ?_⟩

  intro V hV cfg hcfg
  have hK_nonneg : 0 ≤ params.K := by simp [params, K]
  have hret_cfg : IsRetainedConfig params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ :=
    retained_of_mem_retainedConfigs params V hK_nonneg hcfg

  have hgap := h_clm_5_2_config_gap params.e params.γ params.lam params.K V
    cfg.j cfg.k cfg.ℓ params.e_pos params.one_lt_γ params.one_lt_lam hV hret_cfg
  rcases hgap with ⟨_, _, ⟨a_rat, b_rat, ha_eq, hb_eq, _⟩, hb_nonneg, hb_lt_a, ha_le_one,
    hab_gap_eq, hg_le_rhs⟩

  have hb_rat_nonneg : 0 ≤ b_rat := by
    have : (0 : ℝ) ≤ (b_rat : ℝ) := by rwa [← hb_eq]
    exact_mod_cast this
  have hb_rat_lt_a : b_rat < a_rat := by
    have : (b_rat : ℝ) < (a_rat : ℝ) := by rwa [← hb_eq, ← ha_eq]
    exact_mod_cast this
  have ha_rat_le_one : a_rat ≤ 1 := by
    have : (a_rat : ℝ) ≤ (1 : ℝ) := by rwa [← ha_eq]
    exact_mod_cast this

  let g_γ : ℝ := (params.γ : ℝ) ^ 2 - 1
  have hg_γ_pos : 0 < g_γ := by dsimp [g_γ, params]; linarith
  have hg_γ_gap : g_γ ≤ (a_rat : ℝ) - (1 + g_γ) * (b_rat : ℝ) := by
    rw [← ha_eq, ← hb_eq]
    linarith

  rcases h_lem_5_6 with ⟨progBit, progArith, C_ram, deg_ram, h56⟩
  have h56_inst := h56 a_rat b_rat g_γ params.e
    hb_rat_nonneg hb_rat_lt_a ha_rat_le_one hg_γ_pos hg_γ_gap params.e_pos he_le_g16
  rcases h56_inst with ⟨outBit, outArith, _, _, _, _, _, _, _, _,
    _, _, _, _, _, _, _, _, _, _, _, _, hA_pos, hB_nonneg, hAB_sq, hcorr⟩

  let A_num : ℤ := outBit.words.read (.heap 0 0)
  let A_den : ℤ := outBit.words.read (.heap 0 1)
  let B_num : ℤ := outBit.words.read (.heap 0 2)
  let B_den : ℤ := outBit.words.read (.heap 0 3)
  let A : ℚ := (A_num : ℚ) / (A_den : ℚ)
  let B : ℚ := (B_num : ℚ) / (B_den : ℚ)

  refine ⟨A, B, hA_pos, hB_nonneg, hAB_sq, ?_⟩
  intro d u z z_bar hu hz hz_bar hdist
  have hcorr_inst := hcorr d u z z_bar hu hz hz_bar hdist
  rcases hcorr_inst with ⟨_, _, hstrong, hweak⟩
  have hthreshA : params.thresholdA V cfg.j cfg.k cfg.ℓ = (a_rat : ℝ) := ha_eq
  have hthreshB : params.thresholdB V cfg.j cfg.k cfg.ℓ = (b_rat : ℝ) := hb_eq
  refine ⟨?_, ?_⟩
  · intro hzu
    rw [hthreshA] at hzu
    rw [hh_eq]
    exact hstrong hzu
  · intro hzu
    rw [hthreshB] at hzu
    exact hweak hzu

end UL.Proof_lem_9_1
