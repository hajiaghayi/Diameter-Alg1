import UL.Stmt.claim_C_2_space_reclaim
import UL.Stmt.lem_7_1
import UL.Stmt.claim_C_2_scans
import UL.Stmt.lem_C_2
import UL.Proof.claim_C_2_space_reclaim.H1_Reclaim
import UL.Proof.claim_C_2_space_reclaim.RacerP44_H3b1
import UL.Proof.claim_C_2_space_reclaim.RacerP44_H3b2
set_option autoImplicit false

namespace UL

open UL.Proof.claim_C_2_space_reclaim
open UL.Proof.claim_C_2_space_reclaim.RacerP44

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_claim_C_2_space_reclaim (h_lem_7_1 : S_lem_7_1) (h_claim_C_2_scans : S_claim_C_2_scans) (h_lem_C_2 : S_lem_C_2) : S_claim_C_2_space_reclaim := by
  have _ : S_lem_7_1 ∧ S_claim_C_2_scans ∧ S_lem_C_2 := ⟨h_lem_7_1, h_claim_C_2_scans, h_lem_C_2⟩
  intro P_α P_cfg P_int hP_α hP_cfg hP_int
  refine ⟨cDepthVal, cLeafVal, cBatchVal, cEndSpaceVal,
    mkPCard P_α P_cfg P_int, mkPSpaceTot P_α P_cfg P_int,
    by unfold cDepthVal; norm_num,
    by unfold cLeafVal; norm_num,
    by unfold cBatchVal; norm_num,
    by unfold cEndSpaceVal; norm_num,
    mkPCard_poly2 hP_α hP_cfg hP_int,
    mkPCard_one_le P_α P_cfg P_int,
    mkPSpaceTot_poly2 hP_α hP_cfg hP_int,
    mkPSpaceTot_one_le P_α P_cfg P_int,
    power_space_ineq_all,
    reclaimOneRecord_spec,
    alg4Line11PerformRetirementWork_spec,
    retirement_trajectory_bound,
    conjunct2_step_invariants,
    ?_⟩
  intro d n ι mode α C σ P_space K₀ L reclaimMult D_out B_alloc T
    h2n hα_pos hα_le hC hL hσ hP_space hreclaim hD_out
  dsimp only
  rcases d0_and_llog_bounds h2n hα_pos hα_le with ⟨hD0_pos, _, hD0_ub, _, _⟩
  refine ⟨hD0_pos, hD0_ub, ?_, ?_⟩
  · intro upd baseChoices
    exact exists_greedy_eq11_trajectory hα_pos hα_le hL upd baseChoices
  · intro st ans upd choices hst0 hsteps
    have hreach_all : ∀ s : Fin (T + 1), ReachableAlg4Inv n mode α L D_out (st s) :=
      reachableAlg4Inv_trajectory hα_pos hα_le hL hD_out st ans upd choices hst0 hsteps
    intro s
    have hinv_s := hreach_all s
    rcases reachableState_chain_bounds h2n hα_pos hα_le hL hinv_s with
      ⟨hages_s, hserv_len_s, hown_cnt_s, hpfx_len_s, hcards_le_s, hcards_sum_s, _, _⟩
    refine ⟨hinv_s.1, hages_s, hserv_len_s, hown_cnt_s, hpfx_len_s, hcards_le_s, hcards_sum_s,
      ?_, ?_, ?_⟩
    · intro hbal
      set D₀ : ℕ := ⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊
      set B_liveSnap : ℕ := 1 + D₀ * (2 + 2 * D₀)
      have hq0 : (st 0).retirementQueue = [] := by rw [hst0]; rfl
      have hlive_all : ∀ s' : Fin (T + 1), (st s').liveSnapRecords ≤ B_liveSnap :=
        fun s' => (reachableState_chain_bounds h2n hα_pos hα_le hL (hreach_all s')).2.2.2.2.2.2.2
      have hret_steps : ∀ t : Fin T,
          (choices t).stepAllocatedRecords ≤ B_alloc ∧
          (∀ r ∈ alg4StepNewRetired mode α L (st t.castSucc) (upd t) (choices t),
            r.HasBoundedOutdegree D_out) ∧
          (st t.succ).liveSnapRecords +
            retirementQueueRecordCount
              (alg4StepNewRetired mode α L (st t.castSucc) (upd t) (choices t)) ≤
            (st t.castSucc).liveSnapRecords + (choices t).stepAllocatedRecords ∧
          (st t.succ).retirementQueue =
            (alg4Line11PerformRetirementWork reclaimMult (choices t).stepAllocatedRecords
              (st t.castSucc).retirementQueue
              (alg4StepNewRetired mode α L (st t.castSucc) (upd t) (choices t))).1 := by
        intro t
        rcases hsteps t with ⟨hupd_t, _, hextra_t, hstep_t⟩
        rcases alg4StepNewRetired_bounded_and_queue_eq (reclaimMult := reclaimMult)
            hα_pos hα_le hL hD_out (hreach_all t.castSucc).1 hupd_t hextra_t with
          ⟨hnew_b, hq_eq⟩
        have hfst : (alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t)).1 =
            st t.succ := congrArg Prod.fst hstep_t
        rw [hfst] at hq_eq
        exact ⟨(hbal t).2, hnew_b, (hbal t).1, hq_eq⟩
      have hrt := (retirement_trajectory_bound ι D_out reclaimMult B_liveSnap B_alloc T
        (fun s' => (st s').liveSnapRecords)
        (fun t => (choices t).stepAllocatedRecords)
        (fun t => alg4StepNewRetired mode α L (st t.castSucc) (upd t) (choices t))
        (fun s' => (st s').retirementQueue)
        hreclaim hq0 hlive_all hret_steps).1 s
      exact ⟨hrt.2, by omega⟩
    · intro _ hq_bound
      exact endpoint_space_bound_of_reachable h2n hα_pos hα_le hC hL hinv_s hq_bound
    · intro numIntervalLevels localGenCards hPα hPcfg hPint hlocal
      exact general_cards_and_space_of_reachable P_α P_cfg P_int
        h2n hα_pos hα_le hL hσ hP_space hinv_s
        numIntervalLevels localGenCards hPα hPcfg hPint hlocal

end UL
