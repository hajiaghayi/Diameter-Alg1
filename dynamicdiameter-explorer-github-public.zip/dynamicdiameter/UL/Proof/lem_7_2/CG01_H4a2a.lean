import UL.Proof.lem_7_2.RacerP46_H4a_SlotGCAndPureHist

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 2. Pure Coordinate Congruence, `prefixResidual` Step Lemmas, and Schedule Arithmetic -/

lemma nodeCore_congr_on {d : ℕ} {ι : Type}
    (B : ChainNode d) {pts pts' : ι → EuclideanSpace ℝ (Fin d)} {S : Finset ι}
    (h_on : ∀ x ∈ S, pts' x = pts x) :
    B.core pts' S = B.core pts S := by
  ext x
  simp only [mem_nodeCore_iff_distSq_le]
  exact ⟨fun ⟨hx, hle⟩ => ⟨hx, by rwa [← h_on x hx]⟩,
         fun ⟨hx, hle⟩ => ⟨hx, by rwa [h_on x hx]⟩⟩

lemma nodeResidual_subset {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (B : ChainNode d) (S : Finset ι) :
    B.residual pts S ⊆ S :=
  fun _ hx => ((mem_nodeResidual_iff_distSq_gt pts B S _).mp hx).1

lemma passesBirthCoreCheck_congr_on {d : ℕ} {ι : Type}
    (α : ℝ) (B : ChainNode d) {pts pts' : ι → EuclideanSpace ℝ (Fin d)} {S : Finset ι}
    (h_on : ∀ x ∈ S, pts' x = pts x) :
    PassesBirthCoreCheck α pts' B S ↔ PassesBirthCoreCheck α pts B S := by
  unfold PassesBirthCoreCheck
  rw [nodeCore_congr_on B h_on]

lemma isCenterpoint_paraboloid_congr_on {d : ℕ} {ι : Type}
    (β : ℝ) {pts pts' : ι → EuclideanSpace ℝ (Fin d)} {S : Finset ι}
    (z : EuclideanSpace ℝ (Fin (d + 1)))
    (h_on : ∀ x ∈ S, pts' x = pts x) :
    IsCenterpoint β (paraboloidLiftSet (fun i : ↥S => pts' i.1)) z ↔
      IsCenterpoint β (paraboloidLiftSet (fun i : ↥S => pts i.1)) z := by
  have hfun : (fun i : ↥S => pts' i.1) = (fun i : ↥S => pts i.1) := by
    funext i; exact h_on i.1 i.2
  rw [hfun]

lemma prefixResidual_nil {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) :
    prefixResidual pts [] S = S := by
  unfold prefixResidual
  exact List.foldl_nil

lemma prefixResidual_cons {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (lv : OpenedJobLevel d ι) (tl : List (OpenedJobLevel d ι)) (S : Finset ι) :
    prefixResidual pts (lv :: tl) S = prefixResidual pts tl (lv.ball.residual pts S) := by
  unfold prefixResidual
  exact List.foldl_cons

lemma prefixResidual_subset {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (lvs : List (OpenedJobLevel d ι)) (S : Finset ι) :
    prefixResidual pts lvs S ⊆ S := by
  induction lvs generalizing S with
  | nil =>
      rw [prefixResidual_nil]
  | cons lv tl ih =>
      rw [prefixResidual_cons]
      exact (ih (lv.ball.residual pts S)).trans (nodeResidual_subset pts lv.ball S)

lemma prefixResidual_congr_on {d : ℕ} {ι : Type}
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    (lvs : List (OpenedJobLevel d ι)) {S : Finset ι}
    (h_on : ∀ x ∈ S, pts' x = pts x) :
    prefixResidual pts' lvs S = prefixResidual pts lvs S := by
  induction lvs generalizing S with
  | nil =>
      rw [prefixResidual_nil, prefixResidual_nil]
  | cons lv tl ih =>
      rw [prefixResidual_cons, prefixResidual_cons, nodeResidual_congr_on lv.ball S h_on]
      exact @ih (lv.ball.residual pts S) (fun x hx => h_on x (nodeResidual_subset pts lv.ball S hx))

lemma prefixResidual_append_singleton {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (lvs : List (OpenedJobLevel d ι)) (lv : OpenedJobLevel d ι) (S : Finset ι) :
    prefixResidual pts (lvs ++ [lv]) S =
      lv.ball.residual pts (prefixResidual pts lvs S) := by
  induction lvs generalizing S with
  | nil =>
      rw [List.nil_append, prefixResidual_cons, prefixResidual_nil, prefixResidual_nil]
  | cons hd tl ih =>
      rw [List.cons_append, prefixResidual_cons, prefixResidual_cons]
      exact ih (hd.ball.residual pts S)

lemma prefixResidual_eq_chainInput {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (lvs : List (OpenedJobLevel d ι)) (S : Finset ι)
    (j : ℕ) (hj : j ≤ lvs.length) :
    prefixResidual pts (lvs.take j) S =
      chainInput pts (fun i : Fin lvs.length => (lvs[i.val]'i.isLt).ball) S
        ⟨j, Nat.lt_succ_of_le hj⟩ := by
  induction j with
  | zero =>
      rw [List.take_zero, prefixResidual_nil]
      rfl
  | succ j ih =>
      have hj_lt : j < lvs.length := Nat.lt_of_succ_le hj
      have htake : lvs.take (j + 1) = lvs.take j ++ [lvs[j]'hj_lt] := List.take_succ_eq_append_getElem hj_lt
      rw [htake, prefixResidual_append_singleton, ih (Nat.le_of_succ_le hj)]
      rfl

lemma prefixResidual_set_ball_eq {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (lvs : List (OpenedJobLevel d ι)) (idx : ℕ) (lv' : OpenedJobLevel d ι)
    (hidx : idx < lvs.length)
    (hball : lv'.ball = (lvs[idx]'hidx).ball) (S : Finset ι) :
    prefixResidual pts (lvs.set idx lv') S = prefixResidual pts lvs S := by
  induction lvs generalizing idx S with
  | nil => cases hidx
  | cons hd tl ih =>
      cases idx with
      | zero =>
          simp only [List.getElem_cons_zero] at hball
          rw [List.set_cons_zero, prefixResidual_cons, prefixResidual_cons, hball]
      | succ k =>
          rw [List.set_cons_succ, prefixResidual_cons, prefixResidual_cons]
          exact ih k (Nat.lt_of_succ_lt_succ hidx) hball (hd.ball.residual pts S)

lemma prefixResidual_inputChange_step {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (lvs : List (OpenedJobLevel d ι)) {S S' : Finset ι}
    (hchg : IsInputChange S S') :
    prefixResidual pts lvs S' = prefixResidual pts lvs S ∨
      IsInputChange (prefixResidual pts lvs S) (prefixResidual pts lvs S') := by
  classical
  induction lvs generalizing S S' with
  | nil =>
      rw [prefixResidual_nil, prefixResidual_nil]
      exact Or.inr hchg
  | cons lv tl ih =>
      rw [prefixResidual_cons, prefixResidual_cons]
      rcases hchg with ⟨x, hx_not, rfl⟩ | ⟨x, hx_in, rfl⟩
      · rw [nodeResidual_insert]
        split_ifs with hle
        · exact Or.inl rfl
        · have hx_not' : x ∉ lv.ball.residual pts S :=
            fun hmem => hx_not (nodeResidual_subset pts lv.ball S hmem)
          exact @ih (lv.ball.residual pts S) (insert x (lv.ball.residual pts S))
            (Or.inl ⟨x, hx_not', rfl⟩)
      · rw [nodeResidual_erase_uncond]
        by_cases hmem : x ∈ lv.ball.residual pts S
        · exact @ih (lv.ball.residual pts S) ((lv.ball.residual pts S).erase x)
            (Or.inr ⟨x, hmem, rfl⟩)
        · rw [Finset.erase_eq_of_notMem hmem]
          exact Or.inl rfl

lemma hasNodeAge_prefixResidual_step {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (lvs : List (OpenedJobLevel d ι)) {P₀ S S' : Finset ι} {a : ℕ}
    (hage : HasNodeAge P₀ (prefixResidual pts lvs S) a)
    (hchg : IsInputChange S S') :
    ∃ a' ≤ a + 1, HasNodeAge P₀ (prefixResidual pts lvs S') a' := by
  rcases prefixResidual_inputChange_step pts lvs hchg with heq | hchg_res
  · exact ⟨a, Nat.le_succ a, heq ▸ hage⟩
  · exact ⟨a + 1, le_rfl, hasNodeAge_step hage hchg_res⟩

lemma isProvisionalCenter_of_provisionalCenter {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) {S_birth : Finset ι} {b : ι}
    (hb : b ∈ S_birth) (res : SampledCenterResult d) :
    IsProvisionalCenter pts S_birth res (provisionalCenter pts b res) := by
  cases res with
  | infeasible => exact ⟨b, hb, rfl⟩
  | candidate o V =>
      unfold IsProvisionalCenter provisionalCenter
      dsimp only
      split_ifs with hV
      · rfl
      · exact ⟨b, hb, rfl⟩

lemma isValidOpenedLevelBall_selectOpenedLevelBall {d : ℕ} {ι : Type}
    (α : ℝ) (pts : ι → EuclideanSpace ℝ (Fin d)) {S_birth : Finset ι} {b : ι}
    (hb : b ∈ S_birth) (res : SampledCenterResult d) :
    IsValidOpenedLevelBall α pts S_birth res (selectOpenedLevelBall α pts S_birth b res) :=
  ⟨provisionalCenter pts b res, isProvisionalCenter_of_provisionalCenter pts hb res, rfl⟩

lemma isValidOpenedLevelBall_congr_on {d : ℕ} {ι : Type}
    (α : ℝ) {pts pts' : ι → EuclideanSpace ℝ (Fin d)} {S_birth : Finset ι}
    (res : SampledCenterResult d) (ball : ChainNode d)
    (h_on : ∀ x ∈ S_birth, pts' x = pts x)
    (h : IsValidOpenedLevelBall α pts S_birth res ball) :
    IsValidOpenedLevelBall α pts' S_birth res ball := by
  classical
  rcases h with ⟨prov, hprov, rfl⟩
  refine ⟨prov, ?_, ?_⟩
  · cases res with
    | infeasible =>
        rcases hprov with ⟨b, hb, rfl⟩
        exact ⟨b, hb, by rw [h_on b hb]⟩
    | candidate o V =>
        unfold IsProvisionalCenter at hprov ⊢
        dsimp only at hprov ⊢
        split_ifs at hprov ⊢ with hV
        · exact hprov
        · rcases hprov with ⟨b, hb, rfl⟩
          exact ⟨b, hb, by rw [h_on b hb]⟩
  · unfold applyBirthCoreFallback
    rw [passesBirthCoreCheck_congr_on α prov h_on]
    split_ifs with hp
    · rfl
    · unfold maxBirthRadiusBall nodeMaxRadius
      congr 2
      by_cases hne : S_birth.Nonempty
      · simp only [dif_pos hne]
        refine Finset.sup'_congr hne rfl (fun x hx => ?_)
        rw [h_on x hx]
      · simp only [dif_neg hne]

lemma jobGateStep_congr_on {d : ℕ} {ι : Type}
    (α : ℝ) (L : ℕ) {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    {j j' : PendingReplacementJob d ι}
    (h_on : ∀ x ∈ j.currentResidual, pts' x = pts x)
    (h : JobGateStep α L pts j j') :
    JobGateStep α L pts' j j' ∧ j'.currentResidual ⊆ j.currentResidual := by
  rcases h with ⟨hcl, hrdy, hcan, (⟨hleaf, rfl⟩ | ⟨hlarge, res, ball, mode, hval, rfl⟩)⟩
  · exact ⟨⟨hcl, hrdy, hcan, Or.inl ⟨hleaf, rfl⟩⟩, Finset.Subset.refl _⟩
  · have hres_eq : ball.residual pts' j.currentResidual = ball.residual pts j.currentResidual :=
      nodeResidual_congr_on ball j.currentResidual h_on
    have hopen_eq : openLargeLevelInJob pts' j ball mode = openLargeLevelInJob pts j ball mode := by
      unfold openLargeLevelInJob; rw [hres_eq]
    refine ⟨⟨hcl, hrdy, hcan, Or.inr ⟨hlarge, res, ball, mode,
      isValidOpenedLevelBall_congr_on α res ball h_on hval, hopen_eq.symm⟩⟩, ?_⟩
    dsimp [openLargeLevelInJob]
    exact nodeResidual_subset pts ball j.currentResidual

lemma jobWithinTickChain_congr_on {d : ℕ} {ι : Type}
    (α : ℝ) (L : ℕ) {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    {j₁ j₂ : PendingReplacementJob d ι}
    (hchain : JobWithinTickChain α L pts j₁ j₂)
    (h_on : ∀ x ∈ j₁.currentResidual, pts' x = pts x) :
    JobWithinTickChain α L pts' j₁ j₂ := by
  induction hchain with
  | refl j => exact .refl j
  | markReady hm _ ih =>
      exact .markReady hm (ih (fun x hx => h_on x (hm.2.2.1 ▸ hx)))
  | gate hg _ ih =>
      rcases jobGateStep_congr_on α L h_on hg with ⟨hg', hsub⟩
      exact .gate hg' (ih (fun x hx => h_on x (hsub hx)))

lemma scheduleTickPass_congr_on {d : ℕ} {ι : Type}
    (α : ℝ) (L : ℕ) {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    {j₁ j₂ : PendingReplacementJob d ι}
    (hpass : ScheduleTickPass α L pts j₁ j₂)
    (h_on : ∀ x ∈ j₁.currentResidual, pts' x = pts x) :
    ScheduleTickPass α L pts' j₁ j₂ :=
  ⟨jobWithinTickChain_congr_on α L hpass.1 h_on, hpass.2⟩

/-- Schedule arithmetic helper 1: before job start (`age ≤ jobStartAge α M`), `age ≤ α M / 16`. -/
lemma age_le_alpha_sixteen_of_le_start {D M age : ℕ} (hD : 3 ≤ D)
    (hle : age ≤ jobStartAge (1 / (4 * (D : ℝ) ^ 2)) M) :
    (age : ℝ) ≤ (1 / (4 * (D : ℝ) ^ 2)) * (M : ℝ) / 16 := by
  have h1 : (age : ℝ) ≤ (jobStartAge (1 / (4 * (D : ℝ) ^ 2)) M : ℝ) := by exact_mod_cast hle
  have h2 : (jobStartAge (1 / (4 * (D : ℝ) ^ 2)) M : ℝ) ≤
      (1 / (4 * (D : ℝ) ^ 2)) * (M : ℝ) / 64 := by
    unfold jobStartAge
    exact Nat.floor_le (by positivity)
  have hpos : 0 ≤ (1 / (4 * (D : ℝ) ^ 2)) * (M : ℝ) := by positivity
  have _ := hD
  linarith

/-- Schedule arithmetic helper 2: when a job starts at `startAge = M / (256 D^2)` on `m₀ ≤ M + startAge`,
its deadline `H_job = jobDeadlineTicks α m₀` satisfies `H_job ≤ M / (8192 D^2)`, and for all
`t_cur ≤ H_job`, `(startAge + t_cur : ℝ) ≤ α M / 16`! -/
lemma job_deadline_and_serving_age_le {D M m₀ : ℕ} (hD : 3 ≤ D)
    (hm0_le : m₀ ≤ M + jobStartAge (1 / (4 * (D : ℝ) ^ 2)) M) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    jobDeadlineTicks α m₀ ≤ M / (8192 * D ^ 2) ∧
    ∀ t_cur ≤ M / (8192 * D ^ 2),
      ((jobStartAge α M + t_cur : ℕ) : ℝ) ≤ α * (M : ℝ) / 16 := by
  intro α
  have hst := jobStartAge_eq_nat D hD M
  have hdl := jobDeadlineTicks_eq_nat D hD m₀
  have hD2_pos : 0 < D ^ 2 := by positivity
  have hst_le_M : M / (256 * D ^ 2) ≤ M := Nat.div_le_self M _
  have hm0_2M : m₀ ≤ 2 * M := by rw [hst] at hm0_le; omega
  have hdl_le : jobDeadlineTicks α m₀ ≤ M / (8192 * D ^ 2) := by
    rw [hdl]
    calc m₀ / (16384 * D ^ 2)
        ≤ (2 * M) / (16384 * D ^ 2) := Nat.div_le_div_right hm0_2M
      _ = (2 * M) / (2 * (8192 * D ^ 2)) := by congr 1; ring
      _ = M / (8192 * D ^ 2) := Nat.mul_div_mul_left M (8192 * D ^ 2) (by omega)
  refine ⟨hdl_le, fun t_cur ht => ?_⟩
  rw [hst]
  have h8192_pos : (0 : ℝ) < 8192 * (D : ℝ) ^ 2 := by positivity
  have h1 : (((M / (256 * D ^ 2) + t_cur : ℕ) : ℝ)) * (8192 * (D : ℝ) ^ 2) ≤ 128 * (M : ℝ) := by
    have ha : (M / (256 * D ^ 2)) * (256 * D ^ 2) ≤ M := Nat.div_mul_le_self M (256 * D ^ 2)
    have hb : t_cur * (8192 * D ^ 2) ≤ M :=
      (Nat.mul_le_mul_right _ ht).trans (Nat.div_mul_le_self M (8192 * D ^ 2))
    have hnat : (M / (256 * D ^ 2) + t_cur) * (8192 * D ^ 2) ≤ 128 * M := by
      have heq : (M / (256 * D ^ 2) + t_cur) * (8192 * D ^ 2) =
          32 * ((M / (256 * D ^ 2)) * (256 * D ^ 2)) + t_cur * (8192 * D ^ 2) := by ring
      rw [heq]
      omega
    exact_mod_cast hnat
  have h2 : ((M / (256 * D ^ 2) + t_cur : ℕ) : ℝ) ≤ (128 * (M : ℝ)) / (8192 * (D : ℝ) ^ 2) :=
    (le_div_iff₀ h8192_pos).mpr h1
  have hrhs : (128 * (M : ℝ)) / (8192 * (D : ℝ) ^ 2) = α * (M : ℝ) / 16 := by
    dsimp [α]; ring
  exact hrhs ▸ h2

/-- Schedule arithmetic helper 3: when `4 * L < m₀` (`L ≥ 68719476736 * D^4`), `1 ≤ jobDeadlineTicks α m₀`
and `CanOpenResidualLevel α (jobDeadlineTicks α m₀) m₀` holds. -/
lemma job_start_open_props {D L m₀ : ℕ} (hD : 3 ≤ D)
    (hL : 68719476736 * D ^ 4 ≤ L) (hm₀ : 4 * L < m₀) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    1 ≤ jobDeadlineTicks α m₀ ∧
    CanOpenResidualLevel α (jobDeadlineTicks α m₀) m₀ ∧
    IsLargeResidualLevel L m₀ := by
  intro α
  have hdl := jobDeadlineTicks_eq_nat D hD m₀
  have hD4_ge1 : 1 ≤ D ^ 4 := Nat.one_le_pow 4 D (by omega)
  have hL_ge1 : 1 ≤ L := by omega
  have h16_le_m0 : 16384 * D ^ 2 ≤ m₀ := by
    have hD2_le_D4 : D ^ 2 ≤ D ^ 4 := Nat.pow_le_pow_right (by omega) (by norm_num)
    have : 16384 * D ^ 2 ≤ 68719476736 * D ^ 4 :=
      le_trans (Nat.mul_le_mul_right _ (by norm_num : 16384 ≤ 68719476736))
        (Nat.mul_le_mul_left _ hD2_le_D4)
    omega
  have hpos_dl : 1 ≤ jobDeadlineTicks α m₀ := by
    rw [hdl]
    exact (Nat.le_div_iff_mul_le (by positivity : 0 < 16384 * D ^ 2)).mpr (by simpa using h16_le_m0)
  have hcan : CanOpenResidualLevel α (jobDeadlineTicks α m₀) m₀ := by
    rw [canOpenResidualLevel_iff_nat D hD, hdl, mul_comm]
    exact Nat.div_mul_le_self m₀ (16384 * D ^ 2)
  exact ⟨hpos_dl, hcan, by unfold IsLargeResidualLevel; omega⟩

/-- Schedule arithmetic helper 4: any opened level with `CanOpenResidualLevel α rem m` and `2 * L + 1 < m`
satisfies `rem < jobStartAge α m` and `(rem : ℝ) ≤ α * m / 16`. -/
lemma openRem_lt_jobStartAge {D L rem m : ℕ} (hD : 3 ≤ D)
    (hL : 68719476736 * D ^ 4 ≤ L) (hm : 2 * L + 1 < m)
    (hcan : CanOpenResidualLevel (1 / (4 * (D : ℝ) ^ 2)) rem m) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    rem < jobStartAge α m ∧
    (rem : ℝ) ≤ α * (m : ℝ) / 16 := by
  intro α
  have hcan_nat := (canOpenResidualLevel_iff_nat D hD rem m).mp hcan
  have hst := jobStartAge_eq_nat D hD m
  have h256_pos : 0 < 256 * D ^ 2 := by positivity
  have hm_big : 256 * D ^ 2 * (rem + 1) ≤ m := by
    by_cases hr0 : rem = 0
    · subst hr0
      have hD2_le_D4 : D ^ 2 ≤ D ^ 4 := Nat.pow_le_pow_right (by omega) (by norm_num)
      have : 256 * D ^ 2 ≤ 68719476736 * D ^ 4 :=
        le_trans (Nat.mul_le_mul_right _ (by norm_num : 256 ≤ 68719476736))
          (Nat.mul_le_mul_left _ hD2_le_D4)
      omega
    · have h1 : rem + 1 ≤ 2 * rem := by omega
      calc 256 * D ^ 2 * (rem + 1)
          ≤ 256 * D ^ 2 * (2 * rem) := Nat.mul_le_mul_left _ h1
        _ = 512 * (D ^ 2 * rem) := by ring
        _ ≤ 16384 * (D ^ 2 * rem) := Nat.mul_le_mul_right _ (by norm_num)
        _ = 16384 * D ^ 2 * rem := by ring
        _ ≤ m := hcan_nat
  have hlt : rem < jobStartAge α m := by
    rw [hst]
    have hle_div : rem + 1 ≤ m / (256 * D ^ 2) :=
      (Nat.le_div_iff_mul_le h256_pos).mpr (by rw [mul_comm]; exact hm_big)
    omega
  exact ⟨hlt, age_le_alpha_sixteen_of_le_start hD (le_of_lt hlt)⟩

end UL.Proof_lem_7_2_RacerP46
