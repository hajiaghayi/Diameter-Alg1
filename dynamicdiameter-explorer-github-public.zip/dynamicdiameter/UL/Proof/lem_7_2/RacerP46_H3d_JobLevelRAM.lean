import Mathlib
import UL.Proof.lem_7_2.RacerP46_H3c_BuildAndSplit

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Pure Set, Age, Bij, and Two-Phase Scan Helpers -/

lemma nodeResidual_erase_uncond {d : ℕ} {ι : Type} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d)) (B : ChainNode d) (S : Finset ι) (x : ι) :
    B.residual pts (S.erase x) = (B.residual pts S).erase x := by
  ext y
  simp only [mem_nodeResidual_iff_distSq_gt, Finset.mem_erase]
  constructor
  · rintro ⟨⟨hne, hy⟩, hgt⟩
    exact ⟨hne, hy, hgt⟩
  · rintro ⟨hne, hy, hgt⟩
    exact ⟨⟨hne, hy⟩, hgt⟩

lemma nodeResidual_congr_on {d : ℕ} {ι : Type}
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)} (B : ChainNode d) (S : Finset ι)
    (h : ∀ y ∈ S, pts' y = pts y) :
    B.residual pts' S = B.residual pts S := by
  ext y
  simp only [mem_nodeResidual_iff_distSq_gt]
  constructor
  · rintro ⟨hy, hgt⟩
    rw [h y hy] at hgt
    exact ⟨hy, hgt⟩
  · rintro ⟨hy, hgt⟩
    rw [← h y hy] at hgt
    exact ⟨hy, hgt⟩

lemma nodeResidual_erase_congr {d : ℕ} {ι : Type} [DecidableEq ι]
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)} (B : ChainNode d) (S : Finset ι) (x : ι)
    (h : ∀ y ∈ S, y ≠ x → pts' y = pts y) :
    B.residual pts' (S.erase x) = (B.residual pts S).erase x := by
  rw [nodeResidual_congr_on B (S.erase x) (fun y hy => by
    rcases Finset.mem_erase.mp hy with ⟨hne, hyS⟩
    exact h y hyS hne)]
  exact nodeResidual_erase_uncond pts B S x

lemma hasNodeAge_residual {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (B : ChainNode d)
    {P₀ S : Finset ι} {a : ℕ} :
    HasNodeAge P₀ S a →
      ∃ a' ≤ a, HasNodeAge (B.residual pts P₀) (B.residual pts S) a' := by
  classical
  induction a generalizing S with
  | zero =>
      rintro ⟨seq, h0, hlast, _⟩
      have heq : P₀ = S := h0.symm.trans hlast
      subst heq
      exact ⟨0, le_rfl, hasNodeAge_zero _⟩
  | succ a ih =>
      rintro ⟨seq, h0, hlast, hstep⟩
      let S_prev := seq (Fin.last a).castSucc
      have hprev : HasNodeAge P₀ S_prev a := by
        refine ⟨fun i => seq i.castSucc, h0, rfl, fun i => ?_⟩
        dsimp only
        rw [Fin.castSucc_succ]
        exact hstep i.castSucc
      rcases ih hprev with ⟨a', ha', hage'⟩
      have hchg : IsInputChange S_prev S := by
        have h1 := hstep (Fin.last a)
        have hsucc : (Fin.last a).succ = Fin.last (a + 1) := rfl
        rwa [hsucc, hlast] at h1
      rcases hchg with ⟨x, hx, rfl⟩ | ⟨x, hx, rfl⟩
      · rw [nodeResidual_insert]
        split_ifs with hle
        · exact ⟨a', by omega, hage'⟩
        · have hx_not : x ∉ B.residual pts S_prev := fun hm => hx (mem_nodeResidual_iff_distSq_gt _ _ _ _ |>.mp hm).1
          exact ⟨a' + 1, by omega, hasNodeAge_step hage' (Or.inl ⟨x, hx_not, rfl⟩)⟩
      · rw [nodeResidual_erase]
        split_ifs with hle
        · exact ⟨a', by omega, hage'⟩
        · have hx_in : x ∈ B.residual pts S_prev := (mem_nodeResidual_iff_distSq_gt _ _ _ _).mpr ⟨hx, hle⟩
          exact ⟨a' + 1, by omega, hasNodeAge_step hage' (Or.inr ⟨x, hx_in, rfl⟩)⟩

lemma hasNodeAge_trans {ι : Type} {A B C : Finset ι} {a₁ a₂ : ℕ}
    (h1 : HasNodeAge A B a₁) (h2 : HasNodeAge B C a₂) :
    HasNodeAge A C (a₁ + a₂) := by
  induction a₂ generalizing C with
  | zero =>
      rcases h2 with ⟨seq, h0, hlast, _⟩
      have heq : B = C := h0.symm.trans hlast
      subst heq
      simpa using h1
  | succ a₂ ih =>
      rcases h2 with ⟨seq, h0, hlast, hstep⟩
      let C_prev := seq (Fin.last a₂).castSucc
      have hprev : HasNodeAge B C_prev a₂ := by
        refine ⟨fun i => seq i.castSucc, h0, rfl, fun i => ?_⟩
        dsimp only
        rw [Fin.castSucc_succ]
        exact hstep i.castSucc
      have hchg : IsInputChange C_prev C := by
        have h := hstep (Fin.last a₂)
        have hsucc : (Fin.last a₂).succ = Fin.last (a₂ + 1) := rfl
        rwa [hsucc, hlast] at h
      rw [← Nat.add_assoc]
      exact hasNodeAge_step (ih hprev) hchg

lemma applyBirthCoreFallback_bij {d : ℕ}
    (α : ℝ)
    (snapPts : ℕ → EuclideanSpace ℝ (Fin d))
    (ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S_h S_uid : Finset ℕ)
    (f g : ℕ → ℕ)
    (hf : ∀ h ∈ S_h, f h ∈ S_uid ∧ ghostCoords (f h) = snapPts h ∧ g (f h) = h)
    (hg : ∀ u ∈ S_uid, g u ∈ S_h ∧ f (g u) = u)
    (prov : ChainNode d) :
    applyBirthCoreFallback α snapPts S_h prov =
      applyBirthCoreFallback α ghostCoords S_uid prov := by
  have hcard_eq : S_h.card = S_uid.card := by
    refine Finset.card_bij (fun h _ => f h) (fun h hh => (hf h hh).1) ?_ ?_
    · intro x hx y hy heq
      have := congrArg g heq
      rwa [(hf x hx).2.2, (hf y hy).2.2] at this
    · intro u hu; exact ⟨g u, (hg u hu).1, (hg u hu).2⟩
  have hcore_card :
      (prov.core snapPts S_h).card = (prov.core ghostCoords S_uid).card := by
    refine Finset.card_bij (fun h _ => f h) ?_ ?_ ?_
    · intro h hh
      rw [mem_nodeCore_iff_distSq_le] at hh ⊢
      exact ⟨(hf h hh.1).1, by rw [(hf h hh.1).2.1]; exact hh.2⟩
    · intro x hx y hy heq
      rw [mem_nodeCore_iff_distSq_le] at hx hy
      have := congrArg g heq
      rwa [(hf x hx.1).2.2, (hf y hy.1).2.2] at this
    · intro u hu
      rw [mem_nodeCore_iff_distSq_le] at hu
      have hgu := (hg u hu.1).1
      refine ⟨g u, ?_, (hg u hu.1).2⟩
      rw [mem_nodeCore_iff_distSq_le]
      have hpt : snapPts (g u) = ghostCoords u := by
        have h1 := (hf (g u) hgu).2.1
        rw [(hg u hu.1).2] at h1
        exact h1.symm
      exact ⟨hgu, by rw [hpt]; exact hu.2⟩
  have hpass_iff :
      PassesBirthCoreCheck α snapPts prov S_h ↔
        PassesBirthCoreCheck α ghostCoords prov S_uid := by
    unfold PassesBirthCoreCheck
    rw [hcard_eq, hcore_card]
  have hmax_eq :
      nodeMaxRadius snapPts prov.o S_h = nodeMaxRadius ghostCoords prov.o S_uid :=
    nodeMaxRadius_bij snapPts ghostCoords prov.o S_h S_uid f g
      (fun h hh => ⟨(hf h hh).1, (hf h hh).2.1⟩) hg
  unfold applyBirthCoreFallback
  by_cases hp : PassesBirthCoreCheck α snapPts prov S_h
  · simp [hp, hpass_iff.mp hp]
  · have hp2 : ¬ PassesBirthCoreCheck α ghostCoords prov S_uid := fun h => hp (hpass_iff.mpr h)
    simp [hp, hp2, maxBirthRadiusBall, hmax_eq]

lemma filter_lt_insert (S : Finset ℕ) (h cur : ℕ) :
    (insert h S).filter (· < cur) =
      if h < cur then insert h (S.filter (· < cur)) else S.filter (· < cur) := by
  ext x
  split_ifs with hlt
  · simp only [Finset.mem_filter, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hx, hxc⟩
      · exact Or.inl rfl
      · exact Or.inr ⟨hx, hxc⟩
    · rintro (rfl | ⟨hx, hxc⟩)
      · exact ⟨Or.inl rfl, hlt⟩
      · exact ⟨Or.inr hx, hxc⟩
  · simp only [Finset.mem_filter, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hx, hxc⟩
      · exact False.elim (hlt hxc)
      · exact ⟨hx, hxc⟩
    · rintro ⟨hx, hxc⟩
      exact ⟨Or.inr hx, hxc⟩

lemma filter_lt_erase (S : Finset ℕ) (h cur : ℕ) :
    (S.erase h).filter (· < cur) = (S.filter (· < cur)).erase h := by
  ext x
  simp only [Finset.mem_filter, Finset.mem_erase]
  constructor
  · rintro ⟨⟨hne, hx⟩, hxc⟩
    exact ⟨hne, hx, hxc⟩
  · rintro ⟨hne, hx, hxc⟩
    exact ⟨⟨hne, hx⟩, hxc⟩

lemma filter_lt_succ_of_min {S : Finset ℕ} {cur y : ℕ}
    (hy_in : y ∈ S) (hcur_le : cur ≤ y) (hmin : ∀ x ∈ S, cur ≤ x → y ≤ x) :
    S.filter (· < y + 1) = insert y (S.filter (· < cur)) := by
  ext x
  simp only [Finset.mem_filter, Finset.mem_insert]
  constructor
  · rintro ⟨hx, hlt⟩
    by_cases hxc : x < cur
    · exact Or.inr ⟨hx, hxc⟩
    · have hge : cur ≤ x := by omega
      have hyle : y ≤ x := hmin x hx hge
      exact Or.inl (by omega)
  · rintro (rfl | ⟨hx, hxc⟩)
    · exact ⟨hy_in, by omega⟩
    · exact ⟨hx, by omega⟩

lemma filter_lt_eq_of_forall_lt {S : Finset ℕ} {cur M : ℕ}
    (hcur : cur ≤ M) (hall : ∀ x ∈ S, x < cur) :
    S.filter (· < M) = S.filter (· < cur) := by
  ext x
  simp only [Finset.mem_filter]
  constructor
  · rintro ⟨hx, _⟩
    exact ⟨hx, hall x hx⟩
  · rintro ⟨hx, hxc⟩
    exact ⟨hx, lt_of_lt_of_le hxc hcur⟩

lemma filter_lt_eq_self_of_bound {S : Finset ℕ} {M : ℕ}
    (hall : ∀ x ∈ S, x < M) :
    S.filter (· < M) = S := by
  ext x
  simp only [Finset.mem_filter]
  exact ⟨fun h => h.1, fun hx => ⟨hx, hall x hx⟩⟩

lemma card_filter_ge_succ_of_min {S : Finset ℕ} {cur y : ℕ}
    (hy_in : y ∈ S) (hcur_le : cur ≤ y) (hmin : ∀ x ∈ S, cur ≤ x → y ≤ x) :
    (S.filter (fun x => y + 1 ≤ x)).card + 1 = (S.filter (fun x => cur ≤ x)).card := by
  have heq : S.filter (fun x => y + 1 ≤ x) = (S.filter (fun x => cur ≤ x)).erase y := by
    ext x
    simp only [Finset.mem_filter, Finset.mem_erase]
    constructor
    · rintro ⟨hx, hge⟩
      exact ⟨by omega, hx, by omega⟩
    · rintro ⟨hne, hx, hge⟩
      have hyle : y ≤ x := hmin x hx hge
      exact ⟨hx, by omega⟩
  rw [heq]
  have hy_mem : y ∈ S.filter (fun x => cur ≤ x) := Finset.mem_filter.mpr ⟨hy_in, hcur_le⟩
  exact Finset.card_erase_add_one hy_mem

lemma card_filter_ge_insert_le (S : Finset ℕ) (h cur : ℕ) :
    ((insert h S).filter (fun x => cur ≤ x)).card ≤ (S.filter (fun x => cur ≤ x)).card + 1 := by
  calc ((insert h S).filter (fun x => cur ≤ x)).card
      ≤ (insert h (S.filter (fun x => cur ≤ x))).card := by
        apply Finset.card_le_card
        intro x hx
        simp only [Finset.mem_filter, Finset.mem_insert] at hx ⊢
        rcases hx with ⟨rfl | hxS, hge⟩
        · exact Or.inl rfl
        · exact Or.inr ⟨hxS, hge⟩
    _ ≤ (S.filter (fun x => cur ≤ x)).card + 1 := Finset.card_insert_le _ _

lemma card_filter_ge_erase_le (S : Finset ℕ) (h cur : ℕ) :
    ((S.erase h).filter (fun x => cur ≤ x)).card ≤ (S.filter (fun x => cur ≤ x)).card := by
  apply Finset.card_le_card
  intro x hx
  simp only [Finset.mem_filter, Finset.mem_erase] at hx ⊢
  exact ⟨hx.1.2, hx.2⟩

/-! ### 2. Background Job Level Encoding (`EncJobLevel`) -/

def EncJobLevel (d n D K NumSlots : ℕ) (mem : ArithRAMMemory)
    (activeH : Finset ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d))
    (idx : ℕ) (S_birth : Finset ℕ) (snapPts : ℕ → EuclideanSpace ℝ (Fin d))
    (prov : ChainNode d) (S_parent : Finset ℕ) (spareResLive : Bool) : Prop :=
  let ball := applyBirthCoreFallback (1 / (4 * (D : ℝ) ^ 2)) snapPts S_birth prov
  ∃ (bS dS spDS rS spRS : ℕ),
    bS < NumSlots ∧ dS < NumSlots ∧ spDS < NumSlots ∧ rS < NumSlots ∧ spRS < NumSlots ∧
    bS ≠ dS ∧ bS ≠ spDS ∧ bS ≠ rS ∧ bS ≠ spRS ∧
    dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧
    spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS ∧
    wRead mem 23 (((8 * idx + 2 : ℕ) : ℤ)) = (bS : ℤ) ∧
    wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ)) = (dS : ℤ) ∧
    wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ)) = (spDS : ℤ) ∧
    wRead mem 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ) ∧
    wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ) ∧
    1 ≤ wRead mem 6 (bS : ℤ) ∧
    wRead mem 6 (dS : ℤ) = 0 ∧
    wRead mem 6 (spDS : ℤ) = 0 ∧
    wRead mem 6 (rS : ℤ) = 0 ∧
    (wRead mem 6 (spRS : ℤ) = 0 ↔ spareResLive = true) ∧
    0 < S_birth.card ∧
    wRead mem 23 (((8 * idx + 0 : ℕ) : ℤ)) = (S_birth.card : ℤ) ∧
    EncSegSlot K mem bS S_birth (fun _ => 0) ∧
    EncSlotCoords d n mem activeH livePts bS S_birth snapPts ∧
    (∀ c : Fin d, rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord prov.o c) ∧
    ((∃ cur : ℕ,
        cur ≤ S_birth.card ∧
        wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 ∧
        wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ) ∧
        wRead mem 23 (((8 * idx + 1 : ℕ) : ℤ)) =
          ((prov.core snapPts (rankPrefixSet S_birth cur)).card : ℤ) ∧
        rRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = prov.V ∧
        (∀ hne : (rankPrefixSet S_birth cur).Nonempty,
          rRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) =
            (rankPrefixSet S_birth cur).sup' hne (fun x => euclideanDistSq (snapPts x) prov.o)) ∧
        spareResLive = true) ∨
     (∃ cur : ℕ,
        cur ≤ 2 ^ K ∧
        wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 1 ∧
        wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ) ∧
        rRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V ∧
        EncSegSlot K mem dS (S_parent.filter (· < cur)) (fun x => euclideanDistSq (livePts x) ball.o) ∧
        EncSegSlot K mem spDS (S_parent.filter (· < cur)) (fun _ => 0) ∧
        EncSegSlot K mem rS (ball.residual livePts (S_parent.filter (· < cur))) (fun _ => 0) ∧
        spareResLive = true ∧
        EncSegSlot K mem spRS (ball.residual livePts (S_parent.filter (· < cur))) (fun _ => 0)) ∨
     (wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2 ∧
      rRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V ∧
      EncSegSlot K mem dS S_parent (fun x => euclideanDistSq (livePts x) ball.o) ∧
      EncSegSlot K mem spDS S_parent (fun _ => 0) ∧
      EncSegSlot K mem rS (ball.residual livePts S_parent) (fun _ => 0) ∧
      (spareResLive = true →
        EncSegSlot K mem spRS (ball.residual livePts S_parent) (fun _ => 0))))

def jobLevelSlotSet (mem : ArithRAMMemory) (idx : ℕ) : Finset ℕ :=
  { (wRead mem 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat,
    (wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ))).toNat,
    (wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ))).toNat,
    (wRead mem 23 (((8 * idx + 5 : ℕ) : ℤ))).toNat,
    (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat }

lemma jobLevelSlotSet_card_le (mem : ArithRAMMemory) (idx : ℕ) :
    (jobLevelSlotSet mem idx).card ≤ 5 := by
  unfold jobLevelSlotSet
  exact le_trans (Finset.card_insert_le _ _)
    (Nat.add_le_add_right (le_trans (Finset.card_insert_le _ _)
      (Nat.add_le_add_right (le_trans (Finset.card_insert_le _ _)
        (Nat.add_le_add_right (le_trans (Finset.card_insert_le _ _) (by simp)) 1)) 1)) 1)

theorem EncJobLevel.frame {d n D K NumSlots : ℕ} {mem mem' : ArithRAMMemory}
    {activeH activeH' : Finset ℕ} {livePts livePts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {idx : ℕ} {S_birth : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d} {S_parent : Finset ℕ} {spareResLive : Bool}
    (hEnc : EncJobLevel d n D K NumSlots mem activeH livePts idx S_birth snapPts prov S_parent spareResLive)
    (hlive_on : ∀ x ∈ S_parent, livePts' x = livePts x)
    (hseg_pres : ∀ s ∈ jobLevelSlotSet mem idx, s < NumSlots →
      (spareResLive = false → s = (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat → True) →
      ∀ S₁ fSq₁,
        (spareResLive = false → s ≠ (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat) →
        EncSegSlot K mem s S₁ fSq₁ → EncSegSlot K mem' s S₁ fSq₁)
    (hsave_pres : ∀ s ∈ jobLevelSlotSet mem idx,
      wRead mem' 6 (s : ℤ) = wRead mem 6 (s : ℤ))
    (hsnap_pres : ∀ bS < NumSlots, 1 ≤ wRead mem 6 (bS : ℤ) →
      EncSlotCoords d n mem activeH livePts bS S_birth snapPts →
      EncSlotCoords d n mem' activeH' livePts' bS S_birth snapPts)
    (hw23 : ∀ r < 8, wRead mem' 23 (((8 * idx + r : ℕ) : ℤ)) = wRead mem 23 (((8 * idx + r : ℕ) : ℤ)))
    (hw24 : ∀ r < 2, wRead mem' 24 (((2 * idx + r : ℕ) : ℤ)) = wRead mem 24 (((2 * idx + r : ℕ) : ℤ)))
    (hr23 : ∀ c : Fin d, rRead mem' 23 (((idx * d + c.val : ℕ) : ℤ)) = rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)))
    (hr24 : ∀ r < 2, rRead mem' 24 (((2 * idx + r : ℕ) : ℤ)) = rRead mem 24 (((2 * idx + r : ℕ) : ℤ))) :
    EncJobLevel d n D K NumSlots mem' activeH' livePts' idx S_birth snapPts prov S_parent spareResLive := by
  rcases hEnc with ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
    hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
    hw_bS, hw_dS, hw_spDS, hw_rS, hw_spRS,
    h6_bS, h6_dS, h6_spDS, h6_rS, h6_spRS,
    hb_pos, hw_bCard, hSeg_bS, hSlot_bS, hr_o, hPhases⟩
  let ball := applyBirthCoreFallback (1 / (4 * (D : ℝ) ^ 2)) snapPts S_birth prov
  have hspRS_toNat : (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat = spRS := by
    rw [hw_spRS]; omega
  have hmem_bS : bS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_bS]; simp
  have hmem_dS : dS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_dS]; simp
  have hmem_spDS : spDS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_spDS]; simp
  have hmem_rS : rS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_rS]; simp
  have hmem_spRS : spRS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_spRS]; simp
  refine ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
    hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
    by rw [hw23 2 (by omega), hw_bS],
    by rw [hw23 3 (by omega), hw_dS],
    by rw [hw23 4 (by omega), hw_spDS],
    by rw [hw23 5 (by omega), hw_rS],
    by rw [hw23 6 (by omega), hw_spRS],
    by rw [hsave_pres bS hmem_bS]; exact h6_bS,
    by rw [hsave_pres dS hmem_dS]; exact h6_dS,
    by rw [hsave_pres spDS hmem_spDS]; exact h6_spDS,
    by rw [hsave_pres rS hmem_rS]; exact h6_rS,
    by rw [hsave_pres spRS hmem_spRS]; exact h6_spRS,
    hb_pos,
    by rw [hw23 0 (by omega), hw_bCard],
    hseg_pres bS hmem_bS hbS (fun _ _ => trivial) _ _ (fun _ => by rw [hspRS_toNat]; exact hbspR) hSeg_bS,
    hsnap_pres bS hbS h6_bS hSlot_bS,
    fun c => by rw [hr23 c, hr_o c],
    ?_⟩
  rcases hPhases with ⟨cur, hcur, hph, hwcur, hwcore, hrV, hrmax, hlive⟩ |
                      ⟨cur, hcur, hph, hwcur, hrV, hEd, hEspD, hEr, hlive, hEspR⟩ |
                      ⟨hph, hrV, hEd, hEspD, hEr, hEspR⟩
  · left
    exact ⟨cur, hcur,
      by rw [hw24 0 (by omega), hph],
      by rw [hw24 1 (by omega), hwcur],
      by rw [hw23 1 (by omega), hwcore],
      by rw [hr24 0 (by omega), hrV],
      fun hne => by rw [hr24 1 (by omega), hrmax hne],
      hlive⟩
  · right; left
    have hres_eq : ball.residual livePts' (S_parent.filter (· < cur)) =
        ball.residual livePts (S_parent.filter (· < cur)) :=
      nodeResidual_congr_on ball _ (fun y hy => hlive_on y (Finset.mem_filter.mp hy).1)
    have hd_pres := hseg_pres dS hmem_dS hdS (fun _ _ => trivial) _ _
      (fun _ => by rw [hspRS_toNat]; exact hdspR) hEd
    refine ⟨cur, hcur,
      by rw [hw24 0 (by omega), hph],
      by rw [hw24 1 (by omega), hwcur],
      by rw [hr24 0 (by omega), hrV],
      hd_pres.congr_mem_fSq rfl (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl)
        (fun y hy => by rw [hlive_on y (Finset.mem_filter.mp hy).1]),
      hseg_pres spDS hmem_spDS hspDS (fun _ _ => trivial) _ _
        (fun _ => by rw [hspRS_toNat]; exact hspDspR) hEspD,
      by rw [hres_eq]; exact hseg_pres rS hmem_rS hrS (fun _ _ => trivial) _ _
          (fun _ => by rw [hspRS_toNat]; exact hrspR) hEr,
      hlive,
      by rw [hres_eq]; exact hseg_pres spRS hmem_spRS hspRS (fun _ _ => trivial) _ _
          (fun hf => by rw [hlive] at hf; cases hf) hEspR⟩
  · right; right
    have hres_eq : ball.residual livePts' S_parent = ball.residual livePts S_parent :=
      nodeResidual_congr_on ball S_parent hlive_on
    have hd_pres := hseg_pres dS hmem_dS hdS (fun _ _ => trivial) _ _
      (fun _ => by rw [hspRS_toNat]; exact hdspR) hEd
    refine ⟨by rw [hw24 0 (by omega), hph],
      by rw [hr24 0 (by omega), hrV],
      hd_pres.congr_mem_fSq rfl (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl)
        (fun y hy => by rw [hlive_on y hy]),
      hseg_pres spDS hmem_spDS hspDS (fun _ _ => trivial) _ _
        (fun _ => by rw [hspRS_toNat]; exact hspDspR) hEspD,
      by rw [hres_eq]; exact hseg_pres rS hmem_rS hrS (fun _ _ => trivial) _ _
          (fun _ => by rw [hspRS_toNat]; exact hrspR) hEr,
      fun hlive => by
        rw [hres_eq]
        exact hseg_pres spRS hmem_spRS hspRS (fun _ _ => trivial) _ _
          (fun hf => by rw [hlive] at hf; cases hf) (hEspR hlive)⟩

/-! ### 3. Shared 4-Slot Update Helper (`updJobLevelFourSlotsStmt`) -/

/-- Update the live slots `(dS, spDS, rS, spRS)` of job level `idx = wRead mem 26 7` for handle
`h = wRead mem 26 4` with flag `ins = (wRead mem 26 5 == 1)`.
Sets `wRead mem 26 8 := 0` if `ins == true ∧ dSq ≤ lvVar[idx]`, else `1`. -/
def updJobLevelFourSlotsStmt (d K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 26 (.lit 6) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ))),
    boxWriteW M_box 26 (.lit 3)
      (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 3))),
    updSegCenterStmt d K M_box 23,
    boxWriteW M_box 26 (.lit 3)
      (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 4))),
    updSegZeroStmt K M_box,
    .ite (.and (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
               (.realLe (.readRealHeap 26 (.lit 0))
                        (.readRealHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7))))))
      (boxWriteW M_box 26 (.lit 8) (.lit 0))
      (seqList [
        boxWriteW M_box 26 (.lit 8) (.lit 1),
        boxWriteW M_box 26 (.lit 3)
          (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 5))),
        updSegZeroStmt K M_box,
        .ite (.intEq (.readHeap 6
                (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 6)))) (.lit 0))
          (seqList [
            boxWriteW M_box 26 (.lit 3)
              (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 6))),
            updSegZeroStmt K M_box
          ])
          .skip
      ]),
    .localScope .skip
  ]

theorem boxSafe_updJobLevelFourSlotsStmt {T_max M_box : ℕ} (hT : 28 ≤ T_max) (d K : ℕ) :
    BoxSafeOuter T_max M_box (updJobLevelFourSlotsStmt d K M_box) := by
  unfold updJobLevelFourSlotsStmt
  apply boxSafeOuter_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact boxSafe_updSegCenterStmt (by omega) d K 23
  · exact .boxW (by omega) _ _
  · exact boxSafe_updSegZeroStmt (by omega) K
  · refine .ite _ (.boxW (by omega) _ _) (boxSafeOuter_seqList ?_)
    intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl | rfl
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact boxSafe_updSegZeroStmt (by omega) K
    · refine .ite _ (boxSafeOuter_seqList ?_) .skip
      intro s' hs'; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
      rcases hs' with rfl | rfl
      · exact .boxW (by omega) _ _
      · exact boxSafe_updSegZeroStmt (by omega) K
  · exact .localScope .skip

theorem exec_updJobLevelFourSlotsStmt {d n K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx h dS spDS rS spRS : ℕ} {ins : Bool}
    {ball : ChainNode d}
    {activeH : Finset ℕ} {livePts livePts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {T : Finset ℕ}
    (hdS : dS < NumSlots) (hspDS : spDS < NumSlots)
    (hrS : rS < NumSlots) (hspRS : spRS < NumSlots)
    (hdist : dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧ spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS)
    (hh : h < 2 ^ K)
    (hBox26 : 30 ≤ M_box) (hMs : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (hw_dS : wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ)) = (dS : ℤ))
    (hw_spDS : wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ)) = (spDS : ℤ))
    (hw_rS : wRead mem 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ))
    (hw_spRS : wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ))
    (hr_o : ∀ c : Fin d, rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord ball.o c)
    (hr_V : rRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V)
    (hh_reg : wRead mem 26 4 = (h : ℤ))
    (hins_reg : wRead mem 26 5 = (if ins then 1 else 0))
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hLive' : EncLiveCoords d n mem activeH livePts')
    (hh_act : ins = true → h ∈ activeH)
    (hnot_in : ins = true → h ∉ T)
    (hlive_other : ∀ x ∈ T, x ≠ h → livePts' x = livePts x)
    (hgen : SegGenBound K NumSlots mem)
    (hEd : EncSegSlot K mem dS T (fun x => euclideanDistSq (livePts x) ball.o))
    (hEspD : EncSegSlot K mem spDS T (fun _ => 0))
    (hEr : EncSegSlot K mem rS (ball.residual livePts T) (fun _ => 0))
    (hEspR : wRead mem 6 (spRS : ℤ) = 0 →
      EncSegSlot K mem spRS (ball.residual livePts T) (fun _ => 0)) :
    let T' : Finset ℕ := if ins then insert h T else T.erase h
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (updJobLevelFourSlotsStmt d K M_box) mem m'
        (1000 * (K + 1) + 150 * (d + 1) + 600) ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      EncSegSlot K m' dS T' (fun x => euclideanDistSq (livePts' x) ball.o) ∧
      EncSegSlot K m' spDS T' (fun _ => 0) ∧
      EncSegSlot K m' rS (ball.residual livePts' T') (fun _ => 0) ∧
      (wRead mem 6 (spRS : ℤ) = 0 →
        EncSegSlot K m' spRS (ball.residual livePts' T') (fun _ => 0)) ∧
      (ins = true →
        wRead m' 26 8 = (if euclideanDistSq (livePts' h) ball.o ≤ ball.V then 0 else 1)) ∧
      (ins = false → wRead m' 26 8 = 1) ∧
      (∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS →
        (wRead mem 6 (spRS : ℤ) = 0 → s' ≠ spRS) →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 3 → i ≠ 6 → i ≠ 8 → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t, t ≠ 8 → t ≠ 26 → ∀ i, rRead m' t i = rRead mem t i) := by
  intro T'
  rcases hdist with ⟨hd_spD, hd_r, hd_spR, hspD_r, hspD_spR, hr_spR⟩
  -- 1. Set 26[6] := idx * d, 26[3] := dS, and call updSegCenterStmt
  let m1 := wWrite mem 26 6 (((idx * d : ℕ) : ℤ))
  let m2 := wWrite m1 26 3 (dS : ℤ)
  have hs1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 6) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ))))
      mem m1 18 := by
    refine exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
    simp only [iValAt_mul, iValAt_readHeap, iValAt_lit, hidx_reg]; push_cast; rfl
  have hs2 : DetExecAt 0 inp
      (boxWriteW M_box 26 (.lit 3) (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 3))))
      m1 m2 24 := by
    refine exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
    have hm1_7 : wRead m1 26 7 = (idx : ℤ) := by simp [m1, hidx_reg]
    simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, hm1_7]
    have hidx3 : (8 : ℤ) * (idx : ℤ) + 3 = ((8 * idx + 3 : ℕ) : ℤ) := by push_cast; ring
    rw [hidx3]
    dsimp only [m1]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
    exact hw_dS
  have hgen_2 : SegGenBound K NumSlots m2 :=
    ⟨by simp [m2, m1]; exact hgen.1,
     fun s hs => by simp [m2, m1]; exact hgen.2.1 s hs,
     fun s hs u hu => by simp [m2, m1]; exact hgen.2.2 s hs u hu⟩
  have hEd_2 : EncSegSlot K m2 dS T (fun x => euclideanDistSq (livePts x) ball.o) :=
    hEd.congr_mem_fSq (by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
      (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
      (fun _ _ => by simp [m2, m1]) (fun _ _ => rfl)
  have hLive_2 : EncLiveCoords d n m2 activeH livePts' :=
    ⟨hLive'.1, fun x hx c => by simp only [m2, m1, rRead_wWrite]; exact hLive'.2 x hx c⟩
  rcases exec_updSegCenterStmt inp m2 (rTag := 23) (oBase := idx * d) (ins := ins) (o := ball.o)
      hdS hh (by omega) hMs ⟨by decide, by decide⟩
      (by simp [m2]) (by simp [m2, m1, hh_reg]) (by simp [m2, m1, hins_reg]) (by simp [m2, m1])
      (fun c => by simp only [m2, m1, rRead_wWrite]; exact hr_o c)
      hLive_2 hh_act hlive_other hgen_2 hEd_2
    with ⟨m3, hs3, _, hgen_3, hEd_3, hrSq_3, hOther_3, hw_3, hr_3o, _⟩
  -- 2. Set 26[3] := spDS and call updSegZeroStmt
  let m4 := wWrite m3 26 3 (spDS : ℤ)
  have hs4 : DetExecAt 0 inp
      (boxWriteW M_box 26 (.lit 3) (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 4))))
      m3 m4 24 := by
    refine exec_boxWriteW inp m3 _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
    simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit,
      hw_3 26 (by decide) (by decide) (by decide), hw_3 23 (by decide) (by decide) (by decide)]
    have hm2_7 : wRead m2 26 7 = (idx : ℤ) := by simp [m2, m1, hidx_reg]
    rw [hm2_7]
    have hidx4 : (8 : ℤ) * (idx : ℤ) + 4 = ((8 * idx + 4 : ℕ) : ℤ) := by push_cast; ring
    rw [hidx4]
    dsimp only [m2, m1]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
    exact hw_spDS
  have hgen_4 : SegGenBound K NumSlots m4 :=
    ⟨by simp [m4]; exact hgen_3.1,
     fun s hs => by simp [m4]; exact hgen_3.2.1 s hs,
     fun s hs u hu => by simp [m4]; exact hgen_3.2.2 s hs u hu⟩
  have hEspD_2 : EncSegSlot K m2 spDS T (fun _ => 0) :=
    hEspD.congr_mem_fSq (by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
      (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
      (fun _ _ => by simp [m2, m1]) (fun _ _ => rfl)
  have hEspD_3 := hOther_3 spDS hspDS hd_spD.symm _ _ hEspD_2
  have hEspD_4 : EncSegSlot K m4 spDS T (fun _ => 0) :=
    hEspD_3.congr_mem_fSq (by simp [m4]) (fun _ _ => by simp [m4])
      (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => rfl)
  rcases exec_updSegZeroStmt inp m4 (ins := ins) hspDS hh hMs
      (by simp [m4])
      (by simp [m4, hw_3 26 (by decide) (by decide) (by decide), m2, m1, hh_reg])
      (by simp [m4, hw_3 26 (by decide) (by decide) (by decide), m2, m1, hins_reg])
      hgen_4 hEspD_4
    with ⟨m5, hs5, _, hgen_5, hEspD_5, hOther_5, hw_5, hr_5⟩
  have hEd_4 : EncSegSlot K m4 dS T' (fun x => euclideanDistSq (livePts' x) ball.o) :=
    hEd_3.congr_mem_fSq (by simp [m4]) (fun _ _ => by simp [m4])
      (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => rfl)
  have hEd_5 := hOther_5 dS hdS hd_spD _ _ hEd_4
  have hEr_2 : EncSegSlot K m2 rS (ball.residual livePts T) (fun _ => 0) :=
    hEr.congr_mem_fSq (by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
      (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
      (fun _ _ => by simp [m2, m1]) (fun _ _ => rfl)
  have hEr_3 := hOther_3 rS hrS hd_r.symm _ _ hEr_2
  have hEr_4 : EncSegSlot K m4 rS (ball.residual livePts T) (fun _ => 0) :=
    hEr_3.congr_mem_fSq (by simp [m4]) (fun _ _ => by simp [m4])
      (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => rfl)
  have hEr_5 := hOther_5 rS hrS hspD_r.symm _ _ hEr_4
  -- Useful read preservations at m5
  have hw26_m5 : ∀ i, i ≠ 3 → i ≠ 6 → wRead m5 26 i = wRead mem 26 i := by
    intro i h3 h6
    simp [hw_5 26 (by decide) (by decide) (by decide), m4, h3,
      hw_3 26 (by decide) (by decide) (by decide), m2, m1, h6]
  have hw_m5_o : ∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ i, wRead m5 t i = wRead mem t i := by
    intro t h8 h9 h10 h26 i
    simp [hw_5 t h8 h9 h10, m4, h26, hw_3 t h8 h9 h10, m2, m1]
  have hr24_m5 : rRead m5 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V := by
    simp only [hr_5 24 (by decide), m4, rRead_wWrite, hr_3o 24 (by decide) (by decide), m2, m1, hr_V]
  -- 3. Conditional residual update
  let condCore : ArithCondExpr :=
    .and (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
         (.realLe (.readRealHeap 26 (.lit 0))
                  (.readRealHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))))
  by_cases hskip_res : ins = true ∧ euclideanDistSq (livePts' h) ball.o ≤ ball.V
  · rcases hskip_res with ⟨hins_t, hle_V⟩
    have hcond_t : cValAt 0 inp m5 condCore = true := by
      have hv5 : wRead m5 26 5 = 1 := by rw [hw26_m5 5 (by decide) (by decide), hins_reg, hins_t]; rfl
      have hv7 : rRead m5 24 (2 * wRead m5 26 7) = ball.V := by
        rw [hw26_m5 7 (by decide) (by decide), hidx_reg]
        have h2idx : (2 : ℤ) * (idx : ℤ) = ((2 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
        rw [h2idx, hr24_m5]
      have hv0 : rRead m5 26 0 = euclideanDistSq (livePts' h) ball.o := by
        rw [hr_5 26 (by decide)]; simp [m4, hrSq_3 hins_t]
      simp [condCore, hv5, hv7, hv0, hle_V]
    have hres_eq : ball.residual livePts' T' = ball.residual livePts T := by
      dsimp only [T']
      rw [if_pos hins_t, nodeResidual_insert, if_pos hle_V]
      exact nodeResidual_congr_on ball T (fun x hx =>
        hlive_other x hx (fun heq => hnot_in hins_t (heq ▸ hx)))
    let m6 := wWrite m5 26 8 0
    have hs6 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 8) (.lit 0)) m5 m6 14 :=
      exec_boxWriteW inp m5 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
    have hclean : DetExecAt 0 inp (.localScope .skip) m6 ((m6.popDepth 0).popDepth 0) 2 :=
      (DetExecAt.localScope (DetExecAt.skip 1 inp (m6.popDepth 0))).mono_cost (by omega)
    rw [popDepth_zero_idem] at hclean
    refine ⟨m6.popDepth 0,
      (hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq
        ((DetExecAt.ite_true hcond_t (C_c := 24) (by simp [condCore, condExprOps, realExprOps, intExprOps]) hs6).seq
          hclean)))))).mono_cost (by omega),
      popDepth_zero_idem m6,
      ⟨by simp [m6]; exact hgen_5.1,
       fun s hs => by simp [m6]; exact hgen_5.2.1 s hs,
       fun s hs u hu => by simp [m6]; exact hgen_5.2.2 s hs u hu⟩,
      hEd_5.congr_mem_fSq (by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6])
        (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => rfl),
      hEspD_5.congr_mem_fSq (by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6])
        (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => rfl),
      by rw [hres_eq]; exact hEr_5.congr_mem_fSq (by simp [m6]) (fun _ _ => by simp [m6])
          (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => rfl),
      fun hlive0 => by
        rw [hres_eq]
        have h1 : EncSegSlot K m2 spRS (ball.residual livePts T) (fun _ => 0) :=
          (hEspR hlive0).congr_mem_fSq (by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
            (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => rfl)
        have h2 := hOther_3 spRS hspRS hd_spR.symm _ _ h1
        have h3 : EncSegSlot K m4 spRS (ball.residual livePts T) (fun _ => 0) :=
          h2.congr_mem_fSq (by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4])
            (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => rfl)
        have h4 := hOther_5 spRS hspRS hspD_spR.symm _ _ h3
        exact h4.congr_mem_fSq (by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6])
          (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => rfl),
      fun _ => by simp [m6, hle_V],
      fun hf => False.elim (Bool.false_ne_true (hf.symm.trans hins_t)),
      fun s' hs' h1 h2 _ _ S₁ fSq₁ h0 => by
        have a1 : EncSegSlot K m2 s' S₁ fSq₁ :=
          h0.congr_mem_fSq (by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
            (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => rfl)
        have a2 := hOther_3 s' hs' h1 _ _ a1
        have a3 : EncSegSlot K m4 s' S₁ fSq₁ :=
          a2.congr_mem_fSq (by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4])
            (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => rfl)
        have a4 := hOther_5 s' hs' h2 _ _ a3
        exact a4.congr_mem_fSq (by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6])
          (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => rfl),
      fun t h8 h9 h10 h26 i => by simp [m6, h26, hw_m5_o t h8 h9 h10 h26],
      fun i h3 h6 h8 => by simp [m6, h8, hw26_m5 i h3 h6],
      fun t h8 h26 i => by simp [m6, hr_5 t h8, m4, hr_3o t h8 h26, m2, m1]⟩
  · -- Residual IS updated (`if ins then insert h R else R.erase h`)!
    have hcond_f : cValAt 0 inp m5 condCore = false := by
      have hv5 : wRead m5 26 5 = (if ins then 1 else 0) := by
        rw [hw26_m5 5 (by decide) (by decide), hins_reg]
      have hv7 : rRead m5 24 (2 * wRead m5 26 7) = ball.V := by
        rw [hw26_m5 7 (by decide) (by decide), hidx_reg]
        have h2idx : (2 : ℤ) * (idx : ℤ) = ((2 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
        rw [h2idx, hr24_m5]
      cases ins with
      | false => simp [condCore, hv5]
      | true =>
          have hnot_le : ¬ (euclideanDistSq (livePts' h) ball.o ≤ ball.V) :=
            fun hle => hskip_res ⟨rfl, hle⟩
          have hv0 : rRead m5 26 0 = euclideanDistSq (livePts' h) ball.o := by
            rw [hr_5 26 (by decide)]; simp [m4, hrSq_3 rfl]
          simp [condCore, hv5, hv7, hv0, hnot_le]
    have hres_upd : ball.residual livePts' T' =
        if ins then insert h (ball.residual livePts T) else (ball.residual livePts T).erase h := by
      cases ins with
      | false =>
          dsimp only [T']
          simp only [Bool.false_eq_true, ↓reduceIte]
          exact nodeResidual_erase_congr ball T h hlive_other
      | true =>
          have hnot_le : ¬ (euclideanDistSq (livePts' h) ball.o ≤ ball.V) :=
            fun hle => hskip_res ⟨rfl, hle⟩
          dsimp only [T']
          simp only [↓reduceIte]
          rw [nodeResidual_insert, if_neg hnot_le]
          congr 1
          exact nodeResidual_congr_on ball T (fun x hx =>
            hlive_other x hx (fun heq => hnot_in rfl (heq ▸ hx)))
    let m6 := wWrite m5 26 8 1
    let m7 := wWrite m6 26 3 (rS : ℤ)
    have hs6 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 8) (.lit 1)) m5 m6 14 :=
      exec_boxWriteW inp m5 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
    have hs7 : DetExecAt 0 inp
        (boxWriteW M_box 26 (.lit 3) (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 5))))
        m6 m7 24 := by
      refine exec_boxWriteW inp m6 _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
      simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit]
      have hm6_7 : wRead m6 26 7 = (idx : ℤ) := by
        simp [m6, hw26_m5 7 (by decide) (by decide), hidx_reg]
      rw [hm6_7]
      have hidx5 : (8 : ℤ) * (idx : ℤ) + 5 = ((8 * idx + 5 : ℕ) : ℤ) := by push_cast; ring
      rw [hidx5]
      dsimp only [m6]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
          hw_m5_o 23 (by decide) (by decide) (by decide) (by decide)]
      exact hw_rS
    have hgen_7 : SegGenBound K NumSlots m7 :=
      ⟨by simp [m7, m6]; exact hgen_5.1,
       fun s hs => by simp [m7, m6]; exact hgen_5.2.1 s hs,
       fun s hs u hu => by simp [m7, m6]; exact hgen_5.2.2 s hs u hu⟩
    have hEr_7 : EncSegSlot K m7 rS (ball.residual livePts T) (fun _ => 0) :=
      hEr_5.congr_mem_fSq (by simp [m7, m6]) (fun _ _ => by simp [m7, m6])
        (fun _ _ => by simp [m7, m6]) (fun _ _ => by simp [m7, m6])
        (fun _ _ => by simp [m7, m6]) (fun _ _ => rfl)
    rcases exec_updSegZeroStmt inp m7 (ins := ins) hrS hh hMs
        (by simp [m7])
        (by simp [m7, m6, hw26_m5 4 (by decide) (by decide), hh_reg])
        (by simp [m7, m6, hw26_m5 5 (by decide) (by decide), hins_reg])
        hgen_7 hEr_7
      with ⟨m8, hs8, _, hgen_8, hEr_8, hOther_8, hw_8, hr_8⟩
    have hEr_8' : EncSegSlot K m8 rS (ball.residual livePts' T') (fun _ => 0) := by
      rw [hres_upd]; exact hEr_8
    have hEd_7 : EncSegSlot K m7 dS T' (fun x => euclideanDistSq (livePts' x) ball.o) :=
      hEd_5.congr_mem_fSq (by simp [m7, m6]) (fun _ _ => by simp [m7, m6])
        (fun _ _ => by simp [m7, m6]) (fun _ _ => by simp [m7, m6])
        (fun _ _ => by simp [m7, m6]) (fun _ _ => rfl)
    have hEd_8 := hOther_8 dS hdS hd_r _ _ hEd_7
    have hEspD_7 : EncSegSlot K m7 spDS T' (fun _ => 0) :=
      hEspD_5.congr_mem_fSq (by simp [m7, m6]) (fun _ _ => by simp [m7, m6])
        (fun _ _ => by simp [m7, m6]) (fun _ _ => by simp [m7, m6])
        (fun _ _ => by simp [m7, m6]) (fun _ _ => rfl)
    have hEspD_8 := hOther_8 spDS hspDS hspD_r _ _ hEspD_7
    have hw_m8_o : ∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ i, wRead m8 t i = wRead mem t i := by
      intro t h8 h9 h10 h26 i
      simp [hw_8 t h8 h9 h10, m7, m6, h26, hw_m5_o t h8 h9 h10 h26]
    have hw26_m8 : ∀ i, i ≠ 3 → i ≠ 6 → i ≠ 8 → wRead m8 26 i = wRead mem 26 i := by
      intro i h3 h6 h8
      simp [hw_8 26 (by decide) (by decide) (by decide), m7, m6, h3, h8, hw26_m5 i h3 h6]
    have hw26_8_m8 : wRead m8 26 8 = 1 := by
      simp [hw_8 26 (by decide) (by decide) (by decide), m7, m6]
    -- Now check whether spRS is live (`wRead mem 6 spRS == 0`)
    let condSpR : ArithCondExpr :=
      .intEq (.readHeap 6 (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 6)))) (.lit 0)
    by_cases hsp_live : wRead mem 6 (spRS : ℤ) = 0
    · have hsp6_val : wRead m8 6 (wRead m8 23 (8 * wRead m8 26 7 + 6)) = wRead mem 6 (spRS : ℤ) := by
        rw [hw26_m8 7 (by decide) (by decide) (by decide), hidx_reg]
        have hidx6 : (8 : ℤ) * (idx : ℤ) + 6 = ((8 * idx + 6 : ℕ) : ℤ) := by push_cast; ring
        rw [hidx6, hw_m8_o 23 (by decide) (by decide) (by decide) (by decide), hw_spRS,
            hw_m8_o 6 (by decide) (by decide) (by decide) (by decide)]
      have hcond_sp : cValAt 0 inp m8 condSpR = true := by
        simp [condSpR, hsp6_val, hsp_live]
      let m9 := wWrite m8 26 3 (spRS : ℤ)
      have hs9 : DetExecAt 0 inp
          (boxWriteW M_box 26 (.lit 3) (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 7))) (.lit 6))))
          m8 m9 24 := by
        refine exec_boxWriteW inp m8 _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
        simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit]
        rw [hw26_m8 7 (by decide) (by decide) (by decide), hidx_reg]
        have hidx6 : (8 : ℤ) * (idx : ℤ) + 6 = ((8 * idx + 6 : ℕ) : ℤ) := by push_cast; ring
        rw [hidx6, hw_m8_o 23 (by decide) (by decide) (by decide) (by decide), hw_spRS]
      have hgen_9 : SegGenBound K NumSlots m9 :=
        ⟨by simp [m9]; exact hgen_8.1,
         fun s hs => by simp [m9]; exact hgen_8.2.1 s hs,
         fun s hs u hu => by simp [m9]; exact hgen_8.2.2 s hs u hu⟩
      have hEspR_2 : EncSegSlot K m2 spRS (ball.residual livePts T) (fun _ => 0) :=
        (hEspR hsp_live).congr_mem_fSq (by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
          (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => rfl)
      have hEspR_3 := hOther_3 spRS hspRS hd_spR.symm _ _ hEspR_2
      have hEspR_4 : EncSegSlot K m4 spRS (ball.residual livePts T) (fun _ => 0) :=
        hEspR_3.congr_mem_fSq (by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4])
          (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => rfl)
      have hEspR_5 := hOther_5 spRS hspRS hspD_spR.symm _ _ hEspR_4
      have hEspR_7 : EncSegSlot K m7 spRS (ball.residual livePts T) (fun _ => 0) :=
        hEspR_5.congr_mem_fSq (by simp [m7, m6]) (fun _ _ => by simp [m7, m6]) (fun _ _ => by simp [m7, m6])
          (fun _ _ => by simp [m7, m6]) (fun _ _ => by simp [m7, m6]) (fun _ _ => rfl)
      have hEspR_8 := hOther_8 spRS hspRS hr_spR.symm _ _ hEspR_7
      have hEspR_9 : EncSegSlot K m9 spRS (ball.residual livePts T) (fun _ => 0) :=
        hEspR_8.congr_mem_fSq (by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9])
          (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => rfl)
      rcases exec_updSegZeroStmt inp m9 (ins := ins) hspRS hh hMs
          (by simp [m9])
          (by simp [m9, hw26_m8 4 (by decide) (by decide) (by decide), hh_reg])
          (by simp [m9, hw26_m8 5 (by decide) (by decide) (by decide), hins_reg])
          hgen_9 hEspR_9
        with ⟨m10, hs10, _, hgen_10, hEspR_10, hOther_10, hw_10, hr_10⟩
      have hEspR_10' : EncSegSlot K m10 spRS (ball.residual livePts' T') (fun _ => 0) := by
        rw [hres_upd]; exact hEspR_10
      have hEd_9 : EncSegSlot K m9 dS T' (fun x => euclideanDistSq (livePts' x) ball.o) :=
        hEd_8.congr_mem_fSq (by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9])
          (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => rfl)
      have hEspD_9 : EncSegSlot K m9 spDS T' (fun _ => 0) :=
        hEspD_8.congr_mem_fSq (by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9])
          (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => rfl)
      have hEr_9 : EncSegSlot K m9 rS (ball.residual livePts' T') (fun _ => 0) :=
        hEr_8'.congr_mem_fSq (by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9])
          (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => rfl)
      have hclean : DetExecAt 0 inp (.localScope .skip) m10 ((m10.popDepth 0).popDepth 0) 2 :=
        (DetExecAt.localScope (DetExecAt.skip 1 inp (m10.popDepth 0))).mono_cost (by omega)
      rw [popDepth_zero_idem] at hclean
      refine ⟨m10.popDepth 0,
        (hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq
          ((DetExecAt.ite_false hcond_f (C_c := 24) (by simp [condCore, condExprOps, realExprOps, intExprOps])
            (hs6.seq (hs7.seq (hs8.seq
              (DetExecAt.ite_true hcond_sp (C_c := 24) (by simp [condSpR, condExprOps, intExprOps])
                (hs9.seq hs10)))))).seq hclean)))))).mono_cost (by omega),
        popDepth_zero_idem m10,
        ⟨by simp; exact hgen_10.1,
         fun s hs => by simp; exact hgen_10.2.1 s hs,
         fun s hs u hu => by simp; exact hgen_10.2.2 s hs u hu⟩,
        (hOther_10 dS hdS hd_spR _ _ hEd_9).congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
        (hOther_10 spDS hspDS hspD_spR _ _ hEspD_9).congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
        (hOther_10 rS hrS hr_spR _ _ hEr_9).congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
        fun _ => hEspR_10'.congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
        fun hins_t => by
          have hnot_le : ¬ (euclideanDistSq (livePts' h) ball.o ≤ ball.V) := fun hle => hskip_res ⟨hins_t, hle⟩
          simp [hw_10 26 (by decide) (by decide) (by decide), m9, hw26_8_m8, hnot_le],
        fun _ => by simp [hw_10 26 (by decide) (by decide) (by decide), m9, hw26_8_m8],
        fun s' hs' h1 h2 h3 h4f S₁ fSq₁ h0 => by
          have h4 := h4f hsp_live
          have a1 : EncSegSlot K m2 s' S₁ fSq₁ :=
            h0.congr_mem_fSq (by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
              (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => rfl)
          have a2 := hOther_3 s' hs' h1 _ _ a1
          have a3 : EncSegSlot K m4 s' S₁ fSq₁ :=
            a2.congr_mem_fSq (by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4])
              (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => rfl)
          have a4 := hOther_5 s' hs' h2 _ _ a3
          have a5 : EncSegSlot K m7 s' S₁ fSq₁ :=
            a4.congr_mem_fSq (by simp [m7, m6]) (fun _ _ => by simp [m7, m6]) (fun _ _ => by simp [m7, m6])
              (fun _ _ => by simp [m7, m6]) (fun _ _ => by simp [m7, m6]) (fun _ _ => rfl)
          have a6 := hOther_8 s' hs' h3 _ _ a5
          have a7 : EncSegSlot K m9 s' S₁ fSq₁ :=
            a6.congr_mem_fSq (by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9])
              (fun _ _ => by simp [m9]) (fun _ _ => by simp [m9]) (fun _ _ => rfl)
          exact (hOther_10 s' hs' h4 _ _ a7).congr_mem_fSq (by simp) (fun _ _ => by simp)
            (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
        fun t h8 h9 h10 h26 i => by simp [hw_10 t h8 h9 h10, m9, h26, hw_m8_o t h8 h9 h10 h26],
        fun i h3 h6 h8 => by simp [hw_10 26 (by decide) (by decide) (by decide), m9, h3, hw26_m8 i h3 h6 h8],
        fun t h8 h26 i => by simp [hr_10 t h8, m9, hr_8 t h8, m7, m6, hr_5 t h8, m4, hr_3o t h8 h26, m2, m1]⟩
    · have hsp6_val : wRead m8 6 (wRead m8 23 (8 * wRead m8 26 7 + 6)) = wRead mem 6 (spRS : ℤ) := by
        rw [hw26_m8 7 (by decide) (by decide) (by decide), hidx_reg]
        have hidx6 : (8 : ℤ) * (idx : ℤ) + 6 = ((8 * idx + 6 : ℕ) : ℤ) := by push_cast; ring
        rw [hidx6, hw_m8_o 23 (by decide) (by decide) (by decide) (by decide), hw_spRS,
            hw_m8_o 6 (by decide) (by decide) (by decide) (by decide)]
      have hcond_sp : cValAt 0 inp m8 condSpR = false := by
        simp [condSpR, hsp6_val, hsp_live]
      have hclean : DetExecAt 0 inp (.localScope .skip) m8 ((m8.popDepth 0).popDepth 0) 2 :=
        (DetExecAt.localScope (DetExecAt.skip 1 inp (m8.popDepth 0))).mono_cost (by omega)
      rw [popDepth_zero_idem] at hclean
      refine ⟨m8.popDepth 0,
        (hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq
          ((DetExecAt.ite_false hcond_f (C_c := 24) (by simp [condCore, condExprOps, realExprOps, intExprOps])
            (hs6.seq (hs7.seq (hs8.seq
              (DetExecAt.ite_false hcond_sp (C_c := 24) (by simp [condSpR, condExprOps, intExprOps])
                (DetExecAt.skip 0 inp m8)))))).seq hclean)))))).mono_cost (by omega),
        popDepth_zero_idem m8,
        ⟨by simp; exact hgen_8.1,
         fun s hs => by simp; exact hgen_8.2.1 s hs,
         fun s hs u hu => by simp; exact hgen_8.2.2 s hs u hu⟩,
        hEd_8.congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
        hEspD_8.congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
        hEr_8'.congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
        fun h0 => False.elim (hsp_live h0),
        fun hins_t => by
          have hnot_le : ¬ (euclideanDistSq (livePts' h) ball.o ≤ ball.V) := fun hle => hskip_res ⟨hins_t, hle⟩
          simp [hw26_8_m8, hnot_le],
        fun _ => by simp [hw26_8_m8],
        fun s' hs' h1 h2 h3 _ S₁ fSq₁ h0 => by
          have a1 : EncSegSlot K m2 s' S₁ fSq₁ :=
            h0.congr_mem_fSq (by simp [m2, m1]) (fun _ _ => by simp [m2, m1])
              (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => by simp [m2, m1]) (fun _ _ => rfl)
          have a2 := hOther_3 s' hs' h1 _ _ a1
          have a3 : EncSegSlot K m4 s' S₁ fSq₁ :=
            a2.congr_mem_fSq (by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4])
              (fun _ _ => by simp [m4]) (fun _ _ => by simp [m4]) (fun _ _ => rfl)
          have a4 := hOther_5 s' hs' h2 _ _ a3
          have a5 : EncSegSlot K m7 s' S₁ fSq₁ :=
            a4.congr_mem_fSq (by simp [m7, m6]) (fun _ _ => by simp [m7, m6]) (fun _ _ => by simp [m7, m6])
              (fun _ _ => by simp [m7, m6]) (fun _ _ => by simp [m7, m6]) (fun _ _ => rfl)
          exact (hOther_8 s' hs' h3 _ _ a5).congr_mem_fSq (by simp) (fun _ _ => by simp)
            (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
        fun t h8 h9 h10 h26 i => by simp [hw_m8_o t h8 h9 h10 h26],
        fun i h3 h6 h8 => by simp [hw26_m8 i h3 h6 h8],
        fun t h8 h26 i => by simp [hr_8 t h8, m7, m6, hr_5 t h8, m4, hr_3o t h8 h26, m2, m1]⟩

lemma EncSlotCoords.congr_mem {d n : ℕ} {m m' : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {s : ℕ} {S : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    (h0 : EncSlotCoords d n m activeH livePts s S snapPts)
    (hw6 : wRead m' 6 (s : ℤ) = wRead m 6 (s : ℤ))
    (hw11 : ∀ i, wRead m' 11 i = wRead m 11 i)
    (hr11 : ∀ i, rRead m' 11 i = rRead m 11 i) :
    EncSlotCoords d n m' activeH livePts s S snapPts := by
  rcases h0 with ⟨hlt, ⟨hz, hsub, heq⟩ | ⟨hge1, hall⟩⟩
  · exact ⟨hlt, Or.inl ⟨by rw [hw6, hz], hsub, heq⟩⟩
  · refine ⟨hlt, Or.inr ⟨by rw [hw6]; exact hge1, fun h hh => ?_⟩⟩
    rcases hall h hh with ⟨hsav, hliv⟩
    simp only [hw11, hw6, hr11]
    exact ⟨hsav, hliv⟩

/-! ### 4. Initialize Newly Opened Job Level (`initJobLevelStmt`) -/

def initJobLevelStmt (d M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    boxWriteW M_box 6 (.readHeap 26 (.lit 20)) (.lit 0),
    boxWriteW M_box 6 (.readHeap 26 (.lit 21)) (.lit 0),
    boxWriteW M_box 6 (.readHeap 26 (.lit 22)) (.lit 0),
    boxWriteW M_box 6 (.readHeap 26 (.lit 23)) (.lit 0),
    .writeWordLocal 29 (.lit 19) (.mul (.lit 8) (.readHeap 26 (.lit 7))),
    boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 0)) (.readHeap 26 (.lit 24)),
    boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 1)) (.lit 0),
    boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 2)) (.readHeap 26 (.lit 1)),
    boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 3)) (.readHeap 26 (.lit 20)),
    boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 4)) (.readHeap 26 (.lit 21)),
    boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 5)) (.readHeap 26 (.lit 22)),
    boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 6)) (.readHeap 26 (.lit 23)),
    boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 7)) (.readHeap 26 (.lit 25)),
    .writeWordLocal 29 (.lit 19) (.mul (.lit 2) (.readHeap 26 (.lit 7))),
    boxWriteW M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 0)) (.lit 0),
    boxWriteW M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 1)) (.lit 0),
    boxWriteR M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 0)) (.readRealHeap 27 (.lit (d : ℤ))),
    boxWriteR M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 1)) (.ofInt (.lit 0)),
    .writeWordLocal 29 (.lit 18) (.lit 0),
    loadHeapCoordsToLocalStmt d 27 18 0,
    .writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ))),
    storeLocalCoordsToHeapStmt d M_box 23 18 0
  ])

theorem boxSafe_initJobLevelStmt {T_max M_box : ℕ} (hT : 25 ≤ T_max) (d : ℕ) :
    BoxSafeOuter T_max M_box (initJobLevelStmt d M_box) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro st hst
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
                  rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .writeWordLocal _ _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .writeWordLocal _ _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxR (by omega) _ _
  · exact .boxR (by omega) _ _
  · exact .writeWordLocal _ _ _
  · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
  · exact .writeWordLocal _ _ _
  · exact boxSafe_storeLocalCoordsToHeapStmt _ _ (by omega) _ _

theorem exec_initJobLevelStmt {d n D K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx bS dS spDS rS spRS openRem : ℕ}
    {S_birth S_parent : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d}
    (hbS : bS < NumSlots) (hdS : dS < NumSlots)
    (hspDS : spDS < NumSlots) (hrS : rS < NumSlots) (hspRS : spRS < NumSlots)
    (hdist : bS ≠ dS ∧ bS ≠ spDS ∧ bS ≠ rS ∧ bS ≠ spRS ∧
             dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧
             spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS)
    (hb_pos : 0 < S_birth.card)
    (hBox_slots : NumSlots ≤ M_box)
    (hBox_w23 : 8 * idx + 8 ≤ M_box)
    (hBox_r23 : idx * d + d ≤ M_box)
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hbS_reg : wRead mem 26 1 = (bS : ℤ))
    (hdS_reg : wRead mem 26 20 = (dS : ℤ))
    (hspDS_reg : wRead mem 26 21 = (spDS : ℤ))
    (hrS_reg : wRead mem 26 22 = (rS : ℤ))
    (hspRS_reg : wRead mem 26 23 = (spRS : ℤ))
    (hbCard_reg : wRead mem 26 24 = (S_birth.card : ℤ))
    (hrem_reg : wRead mem 26 25 = (openRem : ℤ))
    (hprov_o : ∀ c : Fin d, rRead mem 27 (c.val : ℤ) = euclideanCoord prov.o c)
    (hprov_V : rRead mem 27 (d : ℤ) = prov.V)
    (h6_bS : 1 ≤ wRead mem 6 (bS : ℤ))
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem)
    (hSeg_bS : EncSegSlot K mem bS S_birth (fun _ => 0))
    (hSlot_bS : EncSlotCoords d n mem activeH livePts bS S_birth snapPts) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (initJobLevelStmt d M_box) mem m' (120 * (d + 1) + 400) ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      SaveGenBound n NumSlots m' ∧
      EncJobLevel d n D K NumSlots m' activeH livePts idx S_birth snapPts prov S_parent true ∧
      wRead m' 23 (((8 * idx + 7 : ℕ) : ℤ)) = (openRem : ℤ) ∧
      wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 ∧
      wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = 0 ∧
      (∀ s' < NumSlots, ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
        ∀ S₁ sp₁, EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
          EncSlotCoords d n m' activeH livePts s' S₁ sp₁) ∧
      (∀ t, t ≠ 6 → t ≠ 23 → t ≠ 24 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ s' : ℤ, s' ≠ (dS : ℤ) → s' ≠ (spDS : ℤ) → s' ≠ (rS : ℤ) → s' ≠ (spRS : ℤ) →
        wRead m' 6 s' = wRead mem 6 s') ∧
      (∀ i : ℤ, (i < ((8 * idx : ℕ) : ℤ) ∨ ((8 * idx + 8 : ℕ) : ℤ) ≤ i) →
        wRead m' 23 i = wRead mem 23 i) ∧
      (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
        wRead m' 24 i = wRead mem 24 i) ∧
      (∀ t, t ≠ 23 → t ≠ 24 → ∀ i, rRead m' t i = rRead mem t i) ∧
      (∀ i : ℤ, (i < ((idx * d : ℕ) : ℤ) ∨ ((idx * d + d : ℕ) : ℤ) ≤ i) →
        rRead m' 23 i = rRead mem 23 i) ∧
      (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
        rRead m' 24 i = rRead mem 24 i) := by
  rcases hdist with ⟨hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR⟩
  let m0 := mem.popDepth 0
  let m1 := wWrite m0 6 (dS : ℤ) 0
  let m2 := wWrite m1 6 (spDS : ℤ) 0
  let m3 := wWrite m2 6 (rS : ℤ) 0
  let m4 := wWrite m3 6 (spRS : ℤ) 0
  have hs1 : DetExecAt 1 inp (boxWriteW M_box 6 (.readHeap 26 (.lit 20)) (.lit 0)) m0 m1 16 :=
    exec_boxWriteW inp m0 _ _ (by simp [m0, hdS_reg]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hs2 : DetExecAt 1 inp (boxWriteW M_box 6 (.readHeap 26 (.lit 21)) (.lit 0)) m1 m2 16 :=
    exec_boxWriteW inp m1 _ _ (by simp [m1, m0, hspDS_reg]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hs3 : DetExecAt 1 inp (boxWriteW M_box 6 (.readHeap 26 (.lit 22)) (.lit 0)) m2 m3 16 :=
    exec_boxWriteW inp m2 _ _ (by simp [m2, m1, m0, hrS_reg]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hs4 : DetExecAt 1 inp (boxWriteW M_box 6 (.readHeap 26 (.lit 23)) (.lit 0)) m3 m4 16 :=
    exec_boxWriteW inp m3 _ _ (by simp [m3, m2, m1, m0, hspRS_reg]) (by omega) (by omega) rfl (by simp [intExprOps])
  let m5 := wWriteL 1 m4 29 19 (((8 * idx : ℕ) : ℤ))
  have hs5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 19) (.mul (.lit 8) (.readHeap 26 (.lit 7)))) m4 m5 8 := by
    refine DetExecAt.writeWordLocal 1 inp m4 29 _ _ rfl ?_ (by simp [intExprOps])
    have hm4_7 : wRead m4 26 7 = (idx : ℤ) := by simp [m4, m3, m2, m1, m0, hidx_reg]
    simp only [iValAt_mul, iValAt_lit, iValAt_readHeap, hm4_7]
    push_cast; rfl
  let a0 := wWrite m5 23 (((8 * idx + 0 : ℕ) : ℤ)) (S_birth.card : ℤ)
  let a1 := wWrite a0 23 (((8 * idx + 1 : ℕ) : ℤ)) 0
  let a2 := wWrite a1 23 (((8 * idx + 2 : ℕ) : ℤ)) (bS : ℤ)
  let a3 := wWrite a2 23 (((8 * idx + 3 : ℕ) : ℤ)) (dS : ℤ)
  let a4 := wWrite a3 23 (((8 * idx + 4 : ℕ) : ℤ)) (spDS : ℤ)
  let a5 := wWrite a4 23 (((8 * idx + 5 : ℕ) : ℤ)) (rS : ℤ)
  let a6 := wWrite a5 23 (((8 * idx + 6 : ℕ) : ℤ)) (spRS : ℤ)
  let a7 := wWrite a6 23 (((8 * idx + 7 : ℕ) : ℤ)) (openRem : ℤ)
  have ha0 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 0)) (.readHeap 26 (.lit 24))) m5 a0 20 :=
    exec_boxWriteW inp m5 _ _ (by simp [m5]) (by omega) (by omega)
      (by simp [m5, m4, m3, m2, m1, m0, hbCard_reg]) (by simp [intExprOps])
  have ha1 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 1)) (.lit 0)) a0 a1 25 :=
    exec_boxWriteW inp a0 _ _ (by simp [a0, m5]) (by omega) (by omega) rfl (by simp [intExprOps])
  have ha2 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 2)) (.readHeap 26 (.lit 1))) a1 a2 20 :=
    exec_boxWriteW inp a1 _ _ (by simp [a1, a0, m5]) (by omega) (by omega)
      (by simp [a1, a0, m5, m4, m3, m2, m1, m0, hbS_reg]) (by simp [intExprOps])
  have ha3 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 3)) (.readHeap 26 (.lit 20))) a2 a3 20 :=
    exec_boxWriteW inp a2 _ _ (by simp [a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a2, a1, a0, m5, m4, m3, m2, m1, m0, hdS_reg]) (by simp [intExprOps])
  have ha4 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 4)) (.readHeap 26 (.lit 21))) a3 a4 20 :=
    exec_boxWriteW inp a3 _ _ (by simp [a3, a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a3, a2, a1, a0, m5, m4, m3, m2, m1, m0, hspDS_reg]) (by simp [intExprOps])
  have ha5 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 5)) (.readHeap 26 (.lit 22))) a4 a5 20 :=
    exec_boxWriteW inp a4 _ _ (by simp [a4, a3, a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0, hrS_reg]) (by simp [intExprOps])
  have ha6 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 6)) (.readHeap 26 (.lit 23))) a5 a6 20 :=
    exec_boxWriteW inp a5 _ _ (by simp [a5, a4, a3, a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0, hspRS_reg]) (by simp [intExprOps])
  have ha7 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 7)) (.readHeap 26 (.lit 25))) a6 a7 20 :=
    exec_boxWriteW inp a6 _ _ (by simp [a6, a5, a4, a3, a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0, hrem_reg]) (by simp [intExprOps])
  let b0 := wWriteL 1 a7 29 19 (((2 * idx : ℕ) : ℤ))
  have hb0 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 19) (.mul (.lit 2) (.readHeap 26 (.lit 7)))) a7 b0 8 := by
    refine DetExecAt.writeWordLocal 1 inp a7 29 _ _ rfl ?_ (by simp [intExprOps])
    have ha7_7 : wRead a7 26 7 = (idx : ℤ) := by simp [a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0, hidx_reg]
    simp only [iValAt_mul, iValAt_lit, iValAt_readHeap, ha7_7]
    push_cast; rfl
  let b1 := wWrite b0 24 (((2 * idx + 0 : ℕ) : ℤ)) 0
  let b2 := wWrite b1 24 (((2 * idx + 1 : ℕ) : ℤ)) 0
  let b3 := rWrite b2 24 (((2 * idx + 0 : ℕ) : ℤ)) prov.V
  let b4 := rWrite b3 24 (((2 * idx + 1 : ℕ) : ℤ)) 0
  have hb1 : DetExecAt 1 inp (boxWriteW M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 0)) (.lit 0)) b0 b1 25 :=
    exec_boxWriteW inp b0 _ _ (by simp [b0]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hb2 : DetExecAt 1 inp (boxWriteW M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 1)) (.lit 0)) b1 b2 25 :=
    exec_boxWriteW inp b1 _ _ (by simp [b1, b0]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hb3 : DetExecAt 1 inp (boxWriteR M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 0)) (.readRealHeap 27 (.lit (d : ℤ)))) b2 b3 20 :=
    exec_boxWriteR inp b2 _ _ (by simp [b2, b1, b0]) (by omega) (by omega)
      (by simp [b2, b1, b0, a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0, hprov_V])
      (by simp [intExprOps, realExprOps])
  have hb4 : DetExecAt 1 inp (boxWriteR M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 1)) (.ofInt (.lit 0))) b3 b4 25 :=
    exec_boxWriteR inp b3 _ _ (by simp [b3, b2, b1, b0]) (by omega) (by omega)
      (by simp) (by simp [intExprOps, realExprOps])
  let c0 := wWriteL 1 b4 29 18 0
  have hc0 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.lit 0)) b4 c0 4 :=
    DetExecAt.writeWordLocal 1 inp b4 29 _ _ rfl rfl (by simp [intExprOps])
  rcases exec_loadHeapCoordsToLocalStmt inp c0 (rTag := 27) (idxBase := 18) (destOff := 0)
      (base := 0) (pt := prov.o) (by decide) (by simp [c0])
      (fun c => by
        simp only [c0, b4, b3, b2, b1, b0, a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0,
          Nat.zero_add, rRead_wWriteL, rRead_rWrite_eq, (by decide : (27 : ℕ) ≠ 24), false_and, ↓reduceIte,
          rRead_wWrite, rRead_popDepth]
        exact hprov_o c)
    with ⟨c1, hc1, hloc_c1, hw_c1, hr_c1, _, _, _, _⟩
  let c2 := wWriteL 1 c1 29 18 (((idx * d : ℕ) : ℤ))
  have hc2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ)))) c1 c2 8 := by
    refine DetExecAt.writeWordLocal 1 inp c1 29 _ _ rfl ?_ (by simp [intExprOps])
    have hc1_7 : wRead c1 26 7 = (idx : ℤ) := by
      simp [hw_c1, c0, b4, b3, b2, b1, b0, a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0, hidx_reg]
    simp only [iValAt_mul, iValAt_readHeap, iValAt_lit, hc1_7]
    push_cast; rfl
  rcases exec_storeLocalCoordsToHeapStmt inp c2 (M_box := M_box) (rTag := 23) (idxBase := 18) (srcOff := 0)
      (base := idx * d) (pt := prov.o) (by decide) (by simp [c2]) hBox_r23
      (fun c => by simpa [c2] using hloc_c1 c)
    with ⟨c3, hc3, hro_c3, hr23_out, hr_c3o, hw_c3, _, _, _, _⟩
  have hw_c3_b4 : ∀ t i, wRead c3 t i = wRead b4 t i := by
    intro t i; simp [hw_c3, c2, hw_c1, c0]
  have hw_o : ∀ t, t ≠ 6 → t ≠ 23 → t ≠ 24 → ∀ i, wRead c3 t i = wRead mem t i := by
    intro t h6 h23 h24 i
    rw [hw_c3_b4]
    simp [b4, b3, b2, b1, h24, b0, a7, a6, a5, a4, a3, a2, a1, a0, h23, m5, m4, m3, m2, m1, h6, m0]
  have hw_6 : ∀ s' : ℤ, s' ≠ (dS : ℤ) → s' ≠ (spDS : ℤ) → s' ≠ (rS : ℤ) → s' ≠ (spRS : ℤ) →
      wRead c3 6 s' = wRead mem 6 s' := by
    intro s' h1 h2 h3 h4
    rw [hw_c3_b4]
    simp [b4, b3, b2, b1, b0, a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, h4, m3, h3, m2, h2, m1, h1, m0]
  have hw_c3_a7_23 : ∀ i, wRead c3 23 i = wRead a7 23 i := by
    intro i; rw [hw_c3_b4]; simp [b4, b3, b2, b1, b0]
  have hw_23_in :
      wRead c3 23 (((8 * idx + 0 : ℕ) : ℤ)) = (S_birth.card : ℤ) ∧
      wRead c3 23 (((8 * idx + 1 : ℕ) : ℤ)) = 0 ∧
      wRead c3 23 (((8 * idx + 2 : ℕ) : ℤ)) = (bS : ℤ) ∧
      wRead c3 23 (((8 * idx + 3 : ℕ) : ℤ)) = (dS : ℤ) ∧
      wRead c3 23 (((8 * idx + 4 : ℕ) : ℤ)) = (spDS : ℤ) ∧
      wRead c3 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ) ∧
      wRead c3 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ) ∧
      wRead c3 23 (((8 * idx + 7 : ℕ) : ℤ)) = (openRem : ℤ) := by
    simp only [hw_c3_a7_23]
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · dsimp only [a7, a6, a5, a4, a3, a2, a1, a0]
      repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact wRead_wWrite_self _ _ _ _
    · dsimp only [a7, a6, a5, a4, a3, a2, a1]
      repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact wRead_wWrite_self _ _ _ _
    · dsimp only [a7, a6, a5, a4, a3, a2]
      repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact wRead_wWrite_self _ _ _ _
    · dsimp only [a7, a6, a5, a4, a3]
      repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact wRead_wWrite_self _ _ _ _
    · dsimp only [a7, a6, a5, a4]
      repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact wRead_wWrite_self _ _ _ _
    · dsimp only [a7, a6, a5]
      repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact wRead_wWrite_self _ _ _ _
    · dsimp only [a7, a6]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact wRead_wWrite_self _ _ _ _
    · exact wRead_wWrite_self _ _ _ _
  have hw_23_out : ∀ i : ℤ, (i < ((8 * idx : ℕ) : ℤ) ∨ ((8 * idx + 8 : ℕ) : ℤ) ≤ i) →
      wRead c3 23 i = wRead mem 23 i := by
    intro i hi
    rw [hw_c3_a7_23]
    dsimp only [a7, a6, a5, a4, a3, a2, a1, a0]
    repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    simp [m5, m4, m3, m2, m1, m0]
  have hw_24_in :
      wRead c3 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 ∧
      wRead c3 24 (((2 * idx + 1 : ℕ) : ℤ)) = 0 := by
    rw [hw_c3_b4, hw_c3_b4]
    refine ⟨?_, ?_⟩
    · simp only [b4, b3, wRead_rWrite]; dsimp only [b2, b1]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact wRead_wWrite_self _ _ _ _
    · simp [b4, b3, b2]
  have hw_24_out : ∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
      wRead c3 24 i = wRead mem 24 i := by
    intro i hi
    rw [hw_c3_b4]
    simp only [b4, b3, wRead_rWrite]; dsimp only [b2, b1]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    simp [b0, a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0]
  have hr_o_tab : ∀ t, t ≠ 23 → t ≠ 24 → ∀ i, rRead c3 t i = rRead mem t i := by
    intro t h23 h24 i
    rw [hr_c3o t h23]
    simp [c2, hr_c1, c0, b4, b3, h24, b2, b1, b0, a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0]
  have hr_24_in :
      rRead c3 24 (((2 * idx + 0 : ℕ) : ℤ)) = prov.V ∧
      rRead c3 24 (((2 * idx + 1 : ℕ) : ℤ)) = 0 := by
    rw [hr_c3o 24 (by decide), hr_c3o 24 (by decide)]
    refine ⟨?_, ?_⟩
    · simp only [c2, rRead_wWriteL, hr_c1, c0, b4, b3, rRead_rWrite_eq, true_and]
      split_ifs with h1 <;> [omega; rfl]
    · simp [c2, hr_c1, c0, b4]
  have hr_24_out : ∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
      rRead c3 24 i = rRead mem 24 i := by
    intro i hi
    rw [hr_c3o 24 (by decide)]
    simp only [c2, rRead_wWriteL, hr_c1, c0, b4, b3, rRead_rWrite_eq, true_and]
    split_ifs <;> try omega
    simp [b2, b1, b0, a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0]
  have hr_23_out' : ∀ i : ℤ, (i < ((idx * d : ℕ) : ℤ) ∨ ((idx * d + d : ℕ) : ℤ) ≤ i) →
      rRead c3 23 i = rRead mem 23 i := by
    intro i hi
    rw [hr23_out i hi]
    simp [c2, hr_c1, c0, b4, b3, b2, b1, b0, a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0]
  have hw_c3_m4_6 : ∀ i, wRead c3 6 i = wRead m4 6 i := by
    intro i; rw [hw_c3_b4]
    simp [b4, b3, b2, b1, b0, a7, a6, a5, a4, a3, a2, a1, a0, m5]
  have h6_new :
      wRead c3 6 (dS : ℤ) = 0 ∧ wRead c3 6 (spDS : ℤ) = 0 ∧
      wRead c3 6 (rS : ℤ) = 0 ∧ wRead c3 6 (spRS : ℤ) = 0 := by
    simp only [hw_c3_m4_6]
    refine ⟨?_, ?_, ?_, ?_⟩
    · simp [m4, m3, m2, m1,
        (by exact_mod_cast hdspR : (dS : ℤ) ≠ (spRS : ℤ)),
        (by exact_mod_cast hdr : (dS : ℤ) ≠ (rS : ℤ)),
        (by exact_mod_cast hdspD : (dS : ℤ) ≠ (spDS : ℤ))]
    · simp [m4, m3, m2,
        (by exact_mod_cast hspDspR : (spDS : ℤ) ≠ (spRS : ℤ)),
        (by exact_mod_cast hspDr : (spDS : ℤ) ≠ (rS : ℤ))]
    · simp [m4, m3, (by exact_mod_cast hrspR : (rS : ℤ) ≠ (spRS : ℤ))]
    · simp [m4]
  have hsave' : SaveGenBound n NumSlots (c3.popDepth 0) := by
    refine ⟨by simp [hw_o 1 (by decide) (by decide) (by decide)]; exact hsave.1,
      fun s hs => ?_,
      fun s hs h hh => by
        simp [hw_o 11 (by decide) (by decide) (by decide), hw_o 1 (by decide) (by decide) (by decide)]
        exact hsave.2.2 s hs h hh⟩
    rw [wRead_popDepth, wRead_popDepth, hw_o 1 (by decide) (by decide) (by decide)]
    by_cases he1 : s = dS
    · subst he1; rw [h6_new.1]; exact lt_of_lt_of_le (by omega) hsave.1
    · by_cases he2 : s = spDS
      · subst he2; rw [h6_new.2.1]; exact lt_of_lt_of_le (by omega) hsave.1
      · by_cases he3 : s = rS
        · subst he3; rw [h6_new.2.2.1]; exact lt_of_lt_of_le (by omega) hsave.1
        · by_cases he4 : s = spRS
          · subst he4; rw [h6_new.2.2.2]; exact lt_of_lt_of_le (by omega) hsave.1
          · rw [hw_6 (s : ℤ) (by exact_mod_cast he1) (by exact_mod_cast he2)
                  (by exact_mod_cast he3) (by exact_mod_cast he4)]
            exact hsave.2.1 s hs
  have hseg_all : ∀ s' < NumSlots, ∀ S₁ fSq₁,
      EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K (c3.popDepth 0) s' S₁ fSq₁ := by
    intro s' _ S₁ fSq₁ h0
    exact h0.congr_mem_fSq
      (by simp [hw_o 5 (by decide) (by decide) (by decide)])
      (fun _ _ => by simp [hw_o 8 (by decide) (by decide) (by decide)])
      (fun _ _ => by simp [hw_o 9 (by decide) (by decide) (by decide)])
      (fun _ _ => by simp [hw_o 10 (by decide) (by decide) (by decide)])
      (fun _ _ => by simp [hr_o_tab 8 (by decide) (by decide)])
      (fun _ _ => rfl)
  have hsnap_all : ∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
      ∀ S₁ sp₁, EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
        EncSlotCoords d n (c3.popDepth 0) activeH livePts s' S₁ sp₁ := by
    intro s' _ h1 h2 h3 h4 S₁ sp₁ h0
    exact h0.congr_mem
      (by rw [wRead_popDepth]; exact hw_6 (s' : ℤ) (by exact_mod_cast h1) (by exact_mod_cast h2)
            (by exact_mod_cast h3) (by exact_mod_cast h4))
      (fun i => by simp [hw_o 11 (by decide) (by decide) (by decide)])
      (fun i => by simp [hr_o_tab 11 (by decide) (by decide)])
  refine ⟨c3.popDepth 0,
    DetExecAt.localScope
      ((hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq
        (ha0.seq (ha1.seq (ha2.seq (ha3.seq (ha4.seq (ha5.seq (ha6.seq (ha7.seq
          (hb0.seq (hb1.seq (hb2.seq (hb3.seq (hb4.seq
            (hc0.seq (hc1.seq (hc2.seq hc3))))))))))))))))))))).mono_cost (by omega)),
    popDepth_zero_idem c3,
    ⟨by simp [hw_o 1 (by decide) (by decide) (by decide)]; exact hseg.1,
     fun s hs => by simp [hw_o 5 (by decide) (by decide) (by decide), hw_o 1 (by decide) (by decide) (by decide)]; exact hseg.2.1 s hs,
     fun s hs u hu => by simp [hw_o 8 (by decide) (by decide) (by decide), hw_o 1 (by decide) (by decide) (by decide)]; exact hseg.2.2 s hs u hu⟩,
    hsave',
    ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
      hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
      by rw [wRead_popDepth]; exact hw_23_in.2.2.1,
      by rw [wRead_popDepth]; exact hw_23_in.2.2.2.1,
      by rw [wRead_popDepth]; exact hw_23_in.2.2.2.2.1,
      by rw [wRead_popDepth]; exact hw_23_in.2.2.2.2.2.1,
      by rw [wRead_popDepth]; exact hw_23_in.2.2.2.2.2.2.1,
      by rw [wRead_popDepth, hw_6 (bS : ℤ) (by exact_mod_cast hbd) (by exact_mod_cast hbspD)
              (by exact_mod_cast hbr) (by exact_mod_cast hbspR)]; exact h6_bS,
      by rw [wRead_popDepth]; exact h6_new.1,
      by rw [wRead_popDepth]; exact h6_new.2.1,
      by rw [wRead_popDepth]; exact h6_new.2.2.1,
      by rw [wRead_popDepth, h6_new.2.2.2]; simp,
      hb_pos,
      by rw [wRead_popDepth]; exact hw_23_in.1,
      hseg_all bS hbS _ _ hSeg_bS,
      hsnap_all bS hbS hbd hbspD hbr hbspR _ _ hSlot_bS,
      fun c => by rw [rRead_popDepth]; exact hro_c3 c,
      Or.inl ⟨0, Nat.zero_le _,
        by rw [wRead_popDepth]; exact hw_24_in.1,
        by rw [wRead_popDepth]; exact hw_24_in.2,
        by rw [wRead_popDepth, hw_23_in.2.1]; simp [rankPrefixSet_zero, ChainNode.core, nodeCore],
        by rw [rRead_popDepth]; exact hr_24_in.1,
        fun hne => by rw [rankPrefixSet_zero] at hne; exact False.elim (Finset.not_nonempty_empty hne),
        rfl⟩⟩,
    by rw [wRead_popDepth]; exact hw_23_in.2.2.2.2.2.2.2,
    by rw [wRead_popDepth]; exact hw_24_in.1,
    by rw [wRead_popDepth]; exact hw_24_in.2,
    hseg_all,
    hsnap_all,
    fun t h6 h23 h24 i => by simp [hw_o t h6 h23 h24 i],
    fun s' h1 h2 h3 h4 => by simp [hw_6 s' h1 h2 h3 h4],
    fun i hi => by simp [hw_23_out i hi],
    fun i hi => by simp [hw_24_out i hi],
    fun t h23 h24 i => by simp [hr_o_tab t h23 h24 i],
    fun i hi => by simp [hr_23_out' i hi],
    fun i hi => by simp [hr_24_out i hi]⟩

/-! ### 5. Propagate External Update Through One Job Level (`propagateJobLevelStmt`) -/

def propagateJobLevelStmt (d K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .ite (.intEq (.readHeap 26 (.lit 8)) (.lit 1))
      (.ite (.intEq (.readHeap 26 (.lit 5)) (.lit 0))
        (.ite (.intLe (.lit 1) (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))))
          (updJobLevelFourSlotsStmt d K M_box)
          .skip)
        (.ite (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 2))
          (updJobLevelFourSlotsStmt d K M_box)
          (seqList [
            .ite (.and (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 1))
                       (.intLt (.readHeap 26 (.lit 4))
                               (.readHeap 24 (.add (.mul (.lit 2) (.readHeap 26 (.lit 7))) (.lit 1)))))
              (updJobLevelFourSlotsStmt d K M_box)
              .skip,
            boxWriteW M_box 26 (.lit 8) (.lit 0)
          ])))
      .skip,
    .localScope .skip
  ]

theorem boxSafe_propagateJobLevelStmt {T_max M_box : ℕ} (hT : 28 ≤ T_max) (d K : ℕ) :
    BoxSafeOuter T_max M_box (propagateJobLevelStmt d K M_box) := by
  unfold propagateJobLevelStmt
  apply boxSafeOuter_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · refine .ite _ (.ite _ (.ite _ (boxSafe_updJobLevelFourSlotsStmt hT d K) .skip)
        (.ite _ (boxSafe_updJobLevelFourSlotsStmt hT d K) (boxSafeOuter_seqList ?_))) .skip
    intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl
    · exact .ite _ (boxSafe_updJobLevelFourSlotsStmt hT d K) .skip
    · exact .boxW (by omega) _ _
  · exact .localScope .skip

theorem exec_propagateJobLevelStmt {d n D K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx h : ℕ} {ins passFlag : Bool}
    {S_birth S_parent : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d} {spareResLive : Bool}
    {activeH activeH' : Finset ℕ} {livePts livePts' : ℕ → EuclideanSpace ℝ (Fin d)}
    (hh : h < 2 ^ K)
    (hBox26 : 30 ≤ M_box) (hMs : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (hh_reg : wRead mem 26 4 = (h : ℤ))
    (hins_reg : wRead mem 26 5 = (if ins then 1 else 0))
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hpass_reg : wRead mem 26 8 = (if passFlag then 1 else 0))
    (hins_pass_f : ins = false → passFlag = true)
    (hLive' : EncLiveCoords d n mem activeH' livePts')
    (hh_act : ins = true → h ∈ activeH')
    (hnot_in : ins = true → h ∉ S_parent)
    (hlive_other : ∀ x ∈ S_parent, x ≠ h → livePts' x = livePts x)
    (hSlot_post : ∀ bS < NumSlots, 1 ≤ wRead mem 6 (bS : ℤ) →
      EncSlotCoords d n mem activeH livePts bS S_birth snapPts →
      EncSlotCoords d n mem activeH' livePts' bS S_birth snapPts)
    (hgen : SegGenBound K NumSlots mem)
    (hEnc : EncJobLevel d n D K NumSlots mem activeH livePts idx S_birth snapPts prov S_parent spareResLive) :
    let ball := applyBirthCoreFallback (1 / (4 * (D : ℝ) ^ 2)) snapPts S_birth prov
    let S_parent' : Finset ℕ :=
      if passFlag then (if ins then insert h S_parent else S_parent.erase h) else S_parent
    ∃ (m' : ArithRAMMemory) (passOut : Bool),
      DetExecAt 0 inp (propagateJobLevelStmt d K M_box) mem m'
        (1100 * (K + 1) + 150 * (d + 1) + 800) ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      EncJobLevel d n D K NumSlots m' activeH' livePts' idx S_birth snapPts prov S_parent' spareResLive ∧
      wRead m' 26 8 = (if passOut then 1 else 0) ∧
      (ins = false → passOut = true) ∧
      (ins = true → wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2 →
        ball.residual livePts' S_parent' =
          if passOut then insert h (ball.residual livePts S_parent)
          else ball.residual livePts S_parent) ∧
      (∀ s' < NumSlots, s' ∉ jobLevelSlotSet mem idx →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (spareResLive = false →
        ∀ S₁ fSq₁,
          EncSegSlot K mem ((wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat) S₁ fSq₁ →
          EncSegSlot K m' ((wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat) S₁ fSq₁) ∧
      (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 3 → i ≠ 6 → i ≠ 8 → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t, t ≠ 8 → t ≠ 26 → ∀ i, rRead m' t i = rRead mem t i) := by
  intro ball S_parent'
  have hEnc0 := hEnc
  rcases hEnc with ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
    hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
    hw_bS, hw_dS, hw_spDS, hw_rS, hw_spRS,
    h6_bS, h6_dS, h6_spDS, h6_rS, h6_spRS_iff,
    hb_pos, hw_bCard, hSeg_bS, hSlot_bS, hr_o, hPhases⟩
  have hSlot_bS' := hSlot_post bS hbS h6_bS hSlot_bS
  have hbo : ball.o = prov.o := by
    dsimp [ball]; unfold applyBirthCoreFallback; split_ifs <;> rfl
  have hr_bo : ∀ c : Fin d, rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord ball.o c := by
    rw [hbo]; exact hr_o
  have hspRS_toNat : (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat = spRS := by
    rw [hw_spRS]; omega
  have hslot_not : ∀ s', s' ∉ jobLevelSlotSet mem idx →
      s' ≠ dS ∧ s' ≠ spDS ∧ s' ≠ rS ∧ s' ≠ spRS := by
    intro s' hnot
    unfold jobLevelSlotSet at hnot
    rw [hw_bS, hw_dS, hw_spDS, hw_rS, hw_spRS] at hnot
    simp only [Int.toNat_natCast, Finset.mem_insert, Finset.mem_singleton, not_or] at hnot
    exact ⟨hnot.2.1, hnot.2.2.1, hnot.2.2.2.1, hnot.2.2.2.2⟩
  have hdist4 : dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧ spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS :=
    ⟨hdspD, hdr, hdspR, hspDr, hspDspR, hrspR⟩
  have hclean_mem : DetExecAt 0 inp (.localScope .skip) mem ((mem.popDepth 0).popDepth 0) 2 :=
    (DetExecAt.localScope (DetExecAt.skip 1 inp (mem.popDepth 0))).mono_cost (by omega)
  rw [popDepth_zero_idem] at hclean_mem
  have h2i_eq : (2 : ℤ) * (idx : ℤ) = ((2 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
  have h2i1_eq : (2 : ℤ) * (idx : ℤ) + 1 = ((2 * idx + 1 : ℕ) : ℤ) := by push_cast; ring
  cases passFlag with
  | false =>
      have hins_t : ins = true := by
        cases ins with
        | false => exact False.elim (Bool.false_ne_true (hins_pass_f rfl))
        | true => rfl
      have hlive_all : ∀ x ∈ S_parent, livePts' x = livePts x :=
        fun x hx => hlive_other x hx (fun heq => hnot_in hins_t (heq ▸ hx))
      have hcond8 : cValAt 0 inp mem (.intEq (.readHeap 26 (.lit 8)) (.lit 1)) = false := by
        simp [hpass_reg]
      have hs_all : DetExecAt 0 inp (propagateJobLevelStmt d K M_box) mem (mem.popDepth 0) 30 := by
        unfold propagateJobLevelStmt
        exact ((DetExecAt.ite_false hcond8 (C_c := 10) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp mem)).seq hclean_mem).mono_cost (by omega)
      have hEnc_p0 : EncJobLevel d n D K NumSlots (mem.popDepth 0) activeH' livePts' idx
          S_birth snapPts prov S_parent spareResLive :=
        hEnc0.frame hlive_all
          (fun _ _ _ _ _ _ _ h0 => h0.congr_mem_fSq (by simp) (fun _ _ => by simp)
            (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl))
          (fun _ _ => by simp)
          (fun bS' hbS' hg1 h0 =>
            (hSlot_post bS' hbS' hg1 h0).congr_mem (by simp) (fun _ => by simp) (fun _ => by simp))
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ => by simp) (fun _ _ => by simp)
      refine ⟨mem.popDepth 0, false, hs_all.mono_cost (by omega), popDepth_zero_idem mem,
        ⟨by simp; exact hgen.1,
         fun s hs => by simp; exact hgen.2.1 s hs,
         fun s hs u hu => by simp; exact hgen.2.2 s hs u hu⟩,
        by simpa [S_parent'] using hEnc_p0,
        by simp [hpass_reg],
        (fun hf => False.elim (Bool.false_ne_true (hf.symm.trans hins_t))),
        (fun _ _ => by
          dsimp only [S_parent']
          simp only [Bool.false_eq_true, ↓reduceIte]
          exact nodeResidual_congr_on ball S_parent hlive_all),
        (fun _ _ _ _ _ h0 => h0.congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl)),
        (fun _ _ _ h0 => h0.congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl)),
        (fun _ _ _ _ _ _ => by simp),
        (fun _ _ _ _ => by simp),
        (fun _ _ _ _ => by simp)⟩
  | true =>
      have hcond8 : cValAt 0 inp mem (.intEq (.readHeap 26 (.lit 8)) (.lit 1)) = true := by
        simp [hpass_reg]
      cases ins with
      | false =>
          have hcond5 : cValAt 0 inp mem (.intEq (.readHeap 26 (.lit 5)) (.lit 0)) = true := by
            simp [hins_reg]
          rcases hPhases with ⟨cur, hcur, hph, hwcur, hwcore, hrV, hrmax, hlive⟩ |
                              ⟨cur, hcur, hph, hwcur, hrV, hEd, hEspD, hEr, hlive, hEspR⟩ |
                              ⟨hph, hrV, hEd, hEspD, hEr, hEspR⟩
          · -- Phase 0 on deletion:
            have hcond_ph : cValAt 0 inp mem
                (.intLe (.lit 1) (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7))))) = false := by
              simp only [cValAt_intLe, iValAt_lit, iValAt_readHeap, iValAt_mul, hidx_reg, h2i_eq, hph]
              decide
            have hs_br : DetExecAt 0 inp (propagateJobLevelStmt d K M_box) mem (mem.popDepth 0) 60 := by
              unfold propagateJobLevelStmt
              exact ((DetExecAt.ite_true hcond8 (C_c := 10) (by simp [condExprOps, intExprOps])
                (DetExecAt.ite_true hcond5 (C_c := 10) (by simp [condExprOps, intExprOps])
                  (DetExecAt.ite_false hcond_ph (C_c := 16) (by simp [condExprOps, intExprOps])
                    (DetExecAt.skip 0 inp mem)))).seq hclean_mem).mono_cost (by omega)
            refine ⟨mem.popDepth 0, true, hs_br.mono_cost (by omega), popDepth_zero_idem mem,
              ⟨by simp; exact hgen.1,
               fun s hs => by simp; exact hgen.2.1 s hs,
               fun s hs u hu => by simp; exact hgen.2.2 s hs u hu⟩,
              ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
               hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
               by rw [wRead_popDepth]; exact hw_bS,
               by rw [wRead_popDepth]; exact hw_dS,
               by rw [wRead_popDepth]; exact hw_spDS,
               by rw [wRead_popDepth]; exact hw_rS,
               by rw [wRead_popDepth]; exact hw_spRS,
               by rw [wRead_popDepth]; exact h6_bS,
               by rw [wRead_popDepth]; exact h6_dS,
               by rw [wRead_popDepth]; exact h6_spDS,
               by rw [wRead_popDepth]; exact h6_rS,
               by rw [wRead_popDepth]; exact h6_spRS_iff,
               hb_pos,
               by rw [wRead_popDepth]; exact hw_bCard,
               hSeg_bS.congr_mem_fSq (by simp) (fun _ _ => by simp) (fun _ _ => by simp)
                 (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
               hSlot_bS'.congr_mem (by simp) (fun _ => by simp) (fun _ => by simp),
               fun c => by rw [rRead_popDepth]; exact hr_o c,
               Or.inl ⟨cur, hcur,
                 by rw [wRead_popDepth]; exact hph,
                 by rw [wRead_popDepth]; exact hwcur,
                 by rw [wRead_popDepth]; exact hwcore,
                 by rw [rRead_popDepth]; exact hrV,
                 fun hne => by rw [rRead_popDepth]; exact hrmax hne, hlive⟩⟩,
              by simp [hpass_reg],
              (fun _ => rfl),
              (fun ht => by cases ht),
              (fun _ _ _ _ _ h0 => h0.congr_mem_fSq (by simp) (fun _ _ => by simp)
                (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl)),
              (fun _ _ _ h0 => h0.congr_mem_fSq (by simp) (fun _ _ => by simp)
                (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl)),
              (fun _ _ _ _ _ _ => by simp),
              (fun _ _ _ _ => by simp),
              (fun _ _ _ _ => by simp)⟩
          · -- Phase 1 on deletion:
            have hcond_ph : cValAt 0 inp mem
                (.intLe (.lit 1) (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7))))) = true := by
              simp only [cValAt_intLe, iValAt_lit, iValAt_readHeap, iValAt_mul, hidx_reg, h2i_eq, hph]
              decide
            rcases exec_updJobLevelFourSlotsStmt inp mem (ins := false) (T := S_parent.filter (· < cur))
                hdS hspDS hrS hspRS hdist4 hh hBox26 hMs hw_dS hw_spDS hw_rS hw_spRS hr_bo hrV
                hh_reg hins_reg hidx_reg hLive' (fun ht => by cases ht) (fun ht => by cases ht)
                (fun x hx hne => hlive_other x (Finset.mem_filter.mp hx).1 hne)
                hgen hEd hEspD hEr (fun _ => hEspR)
              with ⟨m1, hd1, hp1, hgen1, hEd1, hEspD1, hEr1, hEspR1, _, hw26_8_1, hOther1, hw1_o, hw1_26, hr1_o⟩
            have hflt : (S_parent.filter (· < cur)).erase h = (S_parent.erase h).filter (· < cur) :=
              (filter_lt_erase S_parent h cur).symm
            simp only [Bool.false_eq_true, ↓reduceIte] at hEd1 hEspD1 hEr1 hEspR1
            rw [hflt] at hEd1 hEspD1 hEr1 hEspR1
            have hclean1 : DetExecAt 0 inp (.localScope .skip) m1 m1 2 := by
              have hc : DetExecAt 0 inp (.localScope .skip) m1 ((m1.popDepth 0).popDepth 0) 2 :=
                (DetExecAt.localScope (DetExecAt.skip 1 inp (m1.popDepth 0))).mono_cost (by omega)
              rwa [popDepth_zero_idem, hp1] at hc
            have hs_br : DetExecAt 0 inp (propagateJobLevelStmt d K M_box) mem m1
                (1100 * (K + 1) + 150 * (d + 1) + 800) := by
              unfold propagateJobLevelStmt
              exact ((DetExecAt.ite_true hcond8 (C_c := 10) (by simp [condExprOps, intExprOps])
                (DetExecAt.ite_true hcond5 (C_c := 10) (by simp [condExprOps, intExprOps])
                  (DetExecAt.ite_true hcond_ph (C_c := 16) (by simp [condExprOps, intExprOps]) hd1))).seq hclean1).mono_cost (by omega)
            refine ⟨m1, true, hs_br, hp1, hgen1,
              ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
               hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_bS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_dS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_spDS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_rS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_spRS],
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_bS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_dS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_spDS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_rS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_spRS_iff,
               hb_pos,
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_bCard],
               hOther1 bS hbS hbd hbspD hbr (fun _ => hbspR) _ _ hSeg_bS,
               hSlot_bS'.congr_mem (hw1_o 6 (by decide) (by decide) (by decide) (by decide) _)
                 (hw1_o 11 (by decide) (by decide) (by decide) (by decide))
                 (hr1_o 11 (by decide) (by decide)),
               fun c => by rw [hr1_o 23 (by decide) (by decide), hr_o c],
               Or.inr (Or.inl ⟨cur, hcur,
                 by rw [hw1_o 24 (by decide) (by decide) (by decide) (by decide), hph],
                 by rw [hw1_o 24 (by decide) (by decide) (by decide) (by decide), hwcur],
                 by rw [hr1_o 24 (by decide) (by decide), hrV],
                 hEd1, hEspD1, hEr1, hlive, hEspR1 (h6_spRS_iff.mpr hlive)⟩)⟩,
              hw26_8_1 rfl,
              (fun _ => rfl),
              (fun ht => by cases ht),
              (fun s' hs' hnot S₁ fSq₁ h0 => by
                rcases hslot_not s' hnot with ⟨h1, h2, h3, h4⟩
                exact hOther1 s' hs' h1 h2 h3 (fun _ => h4) S₁ fSq₁ h0),
              (fun hf => by rw [hlive] at hf; cases hf),
              hw1_o, hw1_26, hr1_o⟩
          · -- Phase 2 on deletion:
            have hcond_ph : cValAt 0 inp mem
                (.intLe (.lit 1) (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7))))) = true := by
              simp only [cValAt_intLe, iValAt_lit, iValAt_readHeap, iValAt_mul, hidx_reg, h2i_eq, hph]
              decide
            rcases exec_updJobLevelFourSlotsStmt inp mem (ins := false) (T := S_parent)
                hdS hspDS hrS hspRS hdist4 hh hBox26 hMs hw_dS hw_spDS hw_rS hw_spRS hr_bo hrV
                hh_reg hins_reg hidx_reg hLive' (fun ht => by cases ht) (fun ht => by cases ht)
                hlive_other hgen hEd hEspD hEr (fun h0 => hEspR (h6_spRS_iff.mp h0))
              with ⟨m1, hd1, hp1, hgen1, hEd1, hEspD1, hEr1, hEspR1, _, hw26_8_1, hOther1, hw1_o, hw1_26, hr1_o⟩
            simp only [Bool.false_eq_true, ↓reduceIte] at hEd1 hEspD1 hEr1 hEspR1
            have hclean1 : DetExecAt 0 inp (.localScope .skip) m1 m1 2 := by
              have hc : DetExecAt 0 inp (.localScope .skip) m1 ((m1.popDepth 0).popDepth 0) 2 :=
                (DetExecAt.localScope (DetExecAt.skip 1 inp (m1.popDepth 0))).mono_cost (by omega)
              rwa [popDepth_zero_idem, hp1] at hc
            have hs_br : DetExecAt 0 inp (propagateJobLevelStmt d K M_box) mem m1
                (1100 * (K + 1) + 150 * (d + 1) + 800) := by
              unfold propagateJobLevelStmt
              exact ((DetExecAt.ite_true hcond8 (C_c := 10) (by simp [condExprOps, intExprOps])
                (DetExecAt.ite_true hcond5 (C_c := 10) (by simp [condExprOps, intExprOps])
                  (DetExecAt.ite_true hcond_ph (C_c := 16) (by simp [condExprOps, intExprOps]) hd1))).seq hclean1).mono_cost (by omega)
            refine ⟨m1, true, hs_br, hp1, hgen1,
              ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
               hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_bS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_dS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_spDS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_rS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_spRS],
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_bS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_dS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_spDS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_rS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_spRS_iff,
               hb_pos,
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_bCard],
               hOther1 bS hbS hbd hbspD hbr (fun _ => hbspR) _ _ hSeg_bS,
               hSlot_bS'.congr_mem (hw1_o 6 (by decide) (by decide) (by decide) (by decide) _)
                 (hw1_o 11 (by decide) (by decide) (by decide) (by decide))
                 (hr1_o 11 (by decide) (by decide)),
               fun c => by rw [hr1_o 23 (by decide) (by decide), hr_o c],
               Or.inr (Or.inr ⟨by rw [hw1_o 24 (by decide) (by decide) (by decide) (by decide), hph],
                 by rw [hr1_o 24 (by decide) (by decide), hrV],
                 hEd1, hEspD1, hEr1, fun hl => hEspR1 (h6_spRS_iff.mpr hl)⟩)⟩,
              hw26_8_1 rfl,
              (fun _ => rfl),
              (fun ht => by cases ht),
              (fun s' hs' hnot S₁ fSq₁ h0 => by
                rcases hslot_not s' hnot with ⟨h1, h2, h3, h4⟩
                exact hOther1 s' hs' h1 h2 h3 (fun _ => h4) S₁ fSq₁ h0),
              (fun hf S₁ fSq₁ h0 => by
                rw [hspRS_toNat] at h0 ⊢
                exact hOther1 spRS hspRS hdspR.symm hspDspR.symm hrspR.symm
                  (fun h0_6 => False.elim (Bool.false_ne_true (hf.symm.trans (h6_spRS_iff.mp h0_6))))
                  S₁ fSq₁ h0),
              hw1_o, hw1_26, hr1_o⟩
      | true =>
          have hcond5 : cValAt 0 inp mem (.intEq (.readHeap 26 (.lit 5)) (.lit 0)) = false := by
            simp [hins_reg]
          have hlive_all : ∀ x ∈ S_parent, livePts' x = livePts x :=
            fun x hx => hlive_other x hx (fun heq => hnot_in rfl (heq ▸ hx))
          rcases hPhases with ⟨cur, hcur, hph, hwcur, hwcore, hrV, hrmax, hlive⟩ |
                              ⟨cur, hcur, hph, hwcur, hrV, hEd, hEspD, hEr, hlive, hEspR⟩ |
                              ⟨hph, hrV, hEd, hEspD, hEr, hEspR⟩
          · -- Phase 0 on insertion:
            have hcond_2 : cValAt 0 inp mem
                (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 2)) = false := by
              simp only [cValAt_intEq, iValAt_readHeap, iValAt_mul, iValAt_lit, hidx_reg, h2i_eq, hph]
              decide
            have hcond_1 : cValAt 0 inp mem
                (.and (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 1))
                      (.intLt (.readHeap 26 (.lit 4))
                              (.readHeap 24 (.add (.mul (.lit 2) (.readHeap 26 (.lit 7))) (.lit 1))))) = false := by
              have hv_ph : wRead mem 24 (2 * wRead mem 26 7) = 0 := by rw [hidx_reg, h2i_eq, hph]
              simp [hv_ph]
            let m1 := wWrite mem 26 8 0
            have hw8 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 8) (.lit 0)) mem m1 14 :=
              exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
            have hclean1 : DetExecAt 0 inp (.localScope .skip) m1 ((m1.popDepth 0).popDepth 0) 2 :=
              (DetExecAt.localScope (DetExecAt.skip 1 inp (m1.popDepth 0))).mono_cost (by omega)
            rw [popDepth_zero_idem] at hclean1
            have hs_br : DetExecAt 0 inp (propagateJobLevelStmt d K M_box) mem (m1.popDepth 0) 120 := by
              unfold propagateJobLevelStmt
              exact ((DetExecAt.ite_true hcond8 (C_c := 10) (by simp [condExprOps, intExprOps])
                (DetExecAt.ite_false hcond5 (C_c := 10) (by simp [condExprOps, intExprOps])
                  (DetExecAt.ite_false hcond_2 (C_c := 16) (by simp [condExprOps, intExprOps])
                    ((DetExecAt.ite_false hcond_1 (C_c := 36) (by simp [condExprOps, intExprOps])
                      (DetExecAt.skip 0 inp mem)).seq hw8)))).seq hclean1).mono_cost (by omega)
            have hw_m1_23 : ∀ i, wRead (m1.popDepth 0) 23 i = wRead mem 23 i := fun _ => by simp [m1]
            have hw_m1_24 : ∀ i, wRead (m1.popDepth 0) 24 i = wRead mem 24 i := fun _ => by simp [m1]
            have hw_m1_6 : ∀ i, wRead (m1.popDepth 0) 6 i = wRead mem 6 i := fun _ => by simp [m1]
            refine ⟨m1.popDepth 0, false, hs_br.mono_cost (by omega), popDepth_zero_idem m1,
              ⟨by simp [m1]; exact hgen.1,
               fun s hs => by simp [m1]; exact hgen.2.1 s hs,
               fun s hs u hu => by simp [m1]; exact hgen.2.2 s hs u hu⟩,
              ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
               hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
               by rw [hw_m1_23, hw_bS], by rw [hw_m1_23, hw_dS], by rw [hw_m1_23, hw_spDS],
               by rw [hw_m1_23, hw_rS], by rw [hw_m1_23, hw_spRS],
               by rw [hw_m1_6]; exact h6_bS, by rw [hw_m1_6]; exact h6_dS,
               by rw [hw_m1_6]; exact h6_spDS, by rw [hw_m1_6]; exact h6_rS,
               by rw [hw_m1_6]; exact h6_spRS_iff,
               hb_pos, by rw [hw_m1_23, hw_bCard],
               hSeg_bS.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1])
                 (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl),
               hSlot_bS'.congr_mem (by simp [m1]) (fun _ => by simp [m1]) (fun _ => by simp [m1]),
               fun c => by simp only [rRead_popDepth, m1, rRead_wWrite]; exact hr_o c,
               Or.inl ⟨cur, hcur, by rw [hw_m1_24, hph], by rw [hw_m1_24, hwcur], by rw [hw_m1_23, hwcore],
                 by simp only [rRead_popDepth, m1, rRead_wWrite]; exact hrV,
                 fun hne => by simp only [rRead_popDepth, m1, rRead_wWrite]; exact hrmax hne, hlive⟩⟩,
              by simp [m1],
              (fun hf => by cases hf),
              (fun _ h2 => by rw [hph] at h2; cases h2),
              (fun _ _ _ _ _ h0 => h0.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1])
                (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl)),
              (fun _ _ _ h0 => h0.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1])
                (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl)),
              (fun _ _ _ _ h26 _ => by simp [m1, h26]),
              (fun _ _ _ h8 => by simp [m1, h8]),
              (fun _ _ _ _ => by simp [m1])⟩
          · -- Phase 1 on insertion:
            have hcond_2 : cValAt 0 inp mem
                (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 2)) = false := by
              simp only [cValAt_intEq, iValAt_readHeap, iValAt_mul, iValAt_lit, hidx_reg, h2i_eq, hph]
              decide
            have hv_ph1 : wRead mem 24 (2 * wRead mem 26 7) = 1 := by rw [hidx_reg, h2i_eq, hph]
            have hv_cur1 : wRead mem 24 (2 * wRead mem 26 7 + 1) = (cur : ℤ) := by rw [hidx_reg, h2i1_eq, hwcur]
            by_cases hlt_cur : h < cur
            · have hcond_1 : cValAt 0 inp mem
                  (.and (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 1))
                        (.intLt (.readHeap 26 (.lit 4))
                                (.readHeap 24 (.add (.mul (.lit 2) (.readHeap 26 (.lit 7))) (.lit 1))))) = true := by
                simp [hv_ph1, hv_cur1, hh_reg, hlt_cur]
              rcases exec_updJobLevelFourSlotsStmt inp mem (ins := true) (T := S_parent.filter (· < cur))
                  hdS hspDS hrS hspRS hdist4 hh hBox26 hMs hw_dS hw_spDS hw_rS hw_spRS hr_bo hrV
                  hh_reg hins_reg hidx_reg hLive' hh_act
                  (fun _ hm => hnot_in rfl (Finset.mem_filter.mp hm).1)
                  (fun x hx hne => hlive_other x (Finset.mem_filter.mp hx).1 hne)
                  hgen hEd hEspD hEr (fun _ => hEspR)
                with ⟨m1, hd1, _, hgen1, hEd1, hEspD1, hEr1, hEspR1, _, _, hOther1, hw1_o, hw1_26, hr1_o⟩
              have hflt : insert h (S_parent.filter (· < cur)) = (insert h S_parent).filter (· < cur) := by
                rw [filter_lt_insert, if_pos hlt_cur]
              simp only [↓reduceIte] at hEd1 hEspD1 hEr1 hEspR1
              rw [hflt] at hEd1 hEspD1 hEr1 hEspR1
              let m2 := wWrite m1 26 8 0
              have hw8 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 8) (.lit 0)) m1 m2 14 :=
                exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
              have hclean2 : DetExecAt 0 inp (.localScope .skip) m2 ((m2.popDepth 0).popDepth 0) 2 :=
                (DetExecAt.localScope (DetExecAt.skip 1 inp (m2.popDepth 0))).mono_cost (by omega)
              rw [popDepth_zero_idem] at hclean2
              have hs_br : DetExecAt 0 inp (propagateJobLevelStmt d K M_box) mem (m2.popDepth 0)
                  (1100 * (K + 1) + 150 * (d + 1) + 800) := by
                unfold propagateJobLevelStmt
                exact ((DetExecAt.ite_true hcond8 (C_c := 10) (by simp [condExprOps, intExprOps])
                  (DetExecAt.ite_false hcond5 (C_c := 10) (by simp [condExprOps, intExprOps])
                    (DetExecAt.ite_false hcond_2 (C_c := 16) (by simp [condExprOps, intExprOps])
                      ((DetExecAt.ite_true hcond_1 (C_c := 36) (by simp [condExprOps, intExprOps]) hd1).seq hw8)))).seq hclean2).mono_cost (by omega)
              have hw_m2_23 : ∀ i, wRead (m2.popDepth 0) 23 i = wRead mem 23 i :=
                fun i => by simp [m2, hw1_o 23 (by decide) (by decide) (by decide) (by decide) i]
              have hw_m2_24 : ∀ i, wRead (m2.popDepth 0) 24 i = wRead mem 24 i :=
                fun i => by simp [m2, hw1_o 24 (by decide) (by decide) (by decide) (by decide) i]
              have hw_m2_6 : ∀ i, wRead (m2.popDepth 0) 6 i = wRead mem 6 i :=
                fun i => by simp [m2, hw1_o 6 (by decide) (by decide) (by decide) (by decide) i]
              refine ⟨m2.popDepth 0, false, hs_br, popDepth_zero_idem m2,
                ⟨by simp [m2]; exact hgen1.1,
                 fun s hs => by simp [m2]; exact hgen1.2.1 s hs,
                 fun s hs u hu => by simp [m2]; exact hgen1.2.2 s hs u hu⟩,
                ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
                 hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
                 by rw [hw_m2_23, hw_bS], by rw [hw_m2_23, hw_dS], by rw [hw_m2_23, hw_spDS],
                 by rw [hw_m2_23, hw_rS], by rw [hw_m2_23, hw_spRS],
                 by rw [hw_m2_6]; exact h6_bS, by rw [hw_m2_6]; exact h6_dS,
                 by rw [hw_m2_6]; exact h6_spDS, by rw [hw_m2_6]; exact h6_rS,
                 by rw [hw_m2_6]; exact h6_spRS_iff,
                 hb_pos, by rw [hw_m2_23, hw_bCard],
                 (hOther1 bS hbS hbd hbspD hbr (fun _ => hbspR) _ _ hSeg_bS).congr_mem_fSq
                   (by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2])
                   (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => rfl),
                 hSlot_bS'.congr_mem (hw_m2_6 _)
                   (fun _ => by simp [m2, hw1_o 11 (by decide) (by decide) (by decide) (by decide)])
                   (fun _ => by simp [m2, hr1_o 11 (by decide) (by decide)]),
                 fun c => by simp only [rRead_popDepth, m2, rRead_wWrite, hr1_o 23 (by decide) (by decide)]; exact hr_o c,
                 Or.inr (Or.inl ⟨cur, hcur,
                   by rw [hw_m2_24, hph], by rw [hw_m2_24, hwcur],
                   by simp only [rRead_popDepth, m2, rRead_wWrite, hr1_o 24 (by decide) (by decide)]; exact hrV,
                   hEd1.congr_mem_fSq (by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2])
                     (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => rfl),
                   hEspD1.congr_mem_fSq (by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2])
                     (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => rfl),
                   hEr1.congr_mem_fSq (by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2])
                     (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => rfl),
                   hlive,
                   (hEspR1 (h6_spRS_iff.mpr hlive)).congr_mem_fSq (by simp [m2]) (fun _ _ => by simp [m2])
                     (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => rfl)⟩)⟩,
                by simp [m2],
                (fun hf => by cases hf),
                (fun _ h2 => by rw [hph] at h2; cases h2),
                (fun s' hs' hnot S₁ fSq₁ h0 => by
                  rcases hslot_not s' hnot with ⟨h1, h2, h3, h4⟩
                  exact (hOther1 s' hs' h1 h2 h3 (fun _ => h4) S₁ fSq₁ h0).congr_mem_fSq
                    (by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2])
                    (fun _ _ => by simp [m2]) (fun _ _ => by simp [m2]) (fun _ _ => rfl)),
                (fun hf => by rw [hlive] at hf; cases hf),
                (fun t h8 h9 h10 h26 i => by simp [m2, h26, hw1_o t h8 h9 h10 h26 i]),
                (fun i h3 h6 h8 => by simp [m2, h8, hw1_26 i h3 h6 h8]),
                (fun t h8 h26 i => by simp [m2, hr1_o t h8 h26 i])⟩
            · -- Phase 1 on insertion with `cur ≤ h`:
              have hcond_1 : cValAt 0 inp mem
                  (.and (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 1))
                        (.intLt (.readHeap 26 (.lit 4))
                                (.readHeap 24 (.add (.mul (.lit 2) (.readHeap 26 (.lit 7))) (.lit 1))))) = false := by
                simp [hv_ph1, hv_cur1, hh_reg, hlt_cur]
              have hflt : (insert h S_parent).filter (· < cur) = S_parent.filter (· < cur) := by
                rw [filter_lt_insert, if_neg hlt_cur]
              have hres_eq : ball.residual livePts' (S_parent.filter (· < cur)) =
                  ball.residual livePts (S_parent.filter (· < cur)) :=
                nodeResidual_congr_on ball _ (fun x hx => hlive_all x (Finset.mem_filter.mp hx).1)
              let m1 := wWrite mem 26 8 0
              have hw8 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 8) (.lit 0)) mem m1 14 :=
                exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
              have hclean1 : DetExecAt 0 inp (.localScope .skip) m1 ((m1.popDepth 0).popDepth 0) 2 :=
                (DetExecAt.localScope (DetExecAt.skip 1 inp (m1.popDepth 0))).mono_cost (by omega)
              rw [popDepth_zero_idem] at hclean1
              have hs_br : DetExecAt 0 inp (propagateJobLevelStmt d K M_box) mem (m1.popDepth 0) 120 := by
                unfold propagateJobLevelStmt
                exact ((DetExecAt.ite_true hcond8 (C_c := 10) (by simp [condExprOps, intExprOps])
                  (DetExecAt.ite_false hcond5 (C_c := 10) (by simp [condExprOps, intExprOps])
                    (DetExecAt.ite_false hcond_2 (C_c := 16) (by simp [condExprOps, intExprOps])
                      ((DetExecAt.ite_false hcond_1 (C_c := 36) (by simp [condExprOps, intExprOps])
                        (DetExecAt.skip 0 inp mem)).seq hw8)))).seq hclean1).mono_cost (by omega)
              have hw_m1_23 : ∀ i, wRead (m1.popDepth 0) 23 i = wRead mem 23 i := fun _ => by simp [m1]
              have hw_m1_24 : ∀ i, wRead (m1.popDepth 0) 24 i = wRead mem 24 i := fun _ => by simp [m1]
              have hw_m1_6 : ∀ i, wRead (m1.popDepth 0) 6 i = wRead mem 6 i := fun _ => by simp [m1]
              refine ⟨m1.popDepth 0, false, hs_br.mono_cost (by omega), popDepth_zero_idem m1,
                ⟨by simp [m1]; exact hgen.1,
                 fun s hs => by simp [m1]; exact hgen.2.1 s hs,
                 fun s hs u hu => by simp [m1]; exact hgen.2.2 s hs u hu⟩,
                ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
                 hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
                 by rw [hw_m1_23, hw_bS], by rw [hw_m1_23, hw_dS], by rw [hw_m1_23, hw_spDS],
                 by rw [hw_m1_23, hw_rS], by rw [hw_m1_23, hw_spRS],
                 by rw [hw_m1_6]; exact h6_bS, by rw [hw_m1_6]; exact h6_dS,
                 by rw [hw_m1_6]; exact h6_spDS, by rw [hw_m1_6]; exact h6_rS,
                 by rw [hw_m1_6]; exact h6_spRS_iff,
                 hb_pos, by rw [hw_m1_23, hw_bCard],
                 hSeg_bS.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1])
                   (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl),
                 hSlot_bS'.congr_mem (by simp [m1]) (fun _ => by simp [m1]) (fun _ => by simp [m1]),
                 fun c => by simp only [rRead_popDepth, m1, rRead_wWrite]; exact hr_o c,
                 Or.inr (Or.inl ⟨cur, hcur, by rw [hw_m1_24, hph], by rw [hw_m1_24, hwcur],
                   by simp only [rRead_popDepth, m1, rRead_wWrite]; exact hrV,
                   by dsimp only [S_parent']; simp only [↓reduceIte, hflt]
                      exact hEd.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1])
                        (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1])
                        (fun x hx => by rw [hlive_all x (Finset.mem_filter.mp hx).1]),
                   by dsimp only [S_parent']; simp only [↓reduceIte, hflt]
                      exact hEspD.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1])
                        (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl),
                   by dsimp only [S_parent']; simp only [↓reduceIte, hflt]; rw [hres_eq]
                      exact hEr.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1])
                        (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl),
                   hlive,
                   by dsimp only [S_parent']; simp only [↓reduceIte, hflt]; rw [hres_eq]
                      exact hEspR.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1])
                        (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl)⟩)⟩,
                by simp [m1],
                (fun hf => by cases hf),
                (fun _ h2 => by rw [hph] at h2; cases h2),
                (fun _ _ _ _ _ h0 => h0.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1])
                  (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl)),
                (fun _ _ _ h0 => h0.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1])
                  (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl)),
                (fun _ _ _ _ h26 _ => by simp [m1, h26]),
                (fun _ _ _ h8 => by simp [m1, h8]),
                (fun _ _ _ _ => by simp [m1])⟩
          · -- Phase 2 on insertion:
            have hcond_2 : cValAt 0 inp mem
                (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 2)) = true := by
              simp only [cValAt_intEq, iValAt_readHeap, iValAt_mul, iValAt_lit, hidx_reg, h2i_eq, hph]
              decide
            rcases exec_updJobLevelFourSlotsStmt inp mem (ins := true) (T := S_parent)
                hdS hspDS hrS hspRS hdist4 hh hBox26 hMs hw_dS hw_spDS hw_rS hw_spRS hr_bo hrV
                hh_reg hins_reg hidx_reg hLive' hh_act hnot_in hlive_other
                hgen hEd hEspD hEr (fun h0 => hEspR (h6_spRS_iff.mp h0))
              with ⟨m1, hd1, hp1, hgen1, hEd1, hEspD1, hEr1, hEspR1, hw26_8_t, _, hOther1, hw1_o, hw1_26, hr1_o⟩
            let passOut : Bool := !decide (euclideanDistSq (livePts' h) ball.o ≤ ball.V)
            have hclean1 : DetExecAt 0 inp (.localScope .skip) m1 m1 2 := by
              have hc : DetExecAt 0 inp (.localScope .skip) m1 ((m1.popDepth 0).popDepth 0) 2 :=
                (DetExecAt.localScope (DetExecAt.skip 1 inp (m1.popDepth 0))).mono_cost (by omega)
              rwa [popDepth_zero_idem, hp1] at hc
            have hs_br : DetExecAt 0 inp (propagateJobLevelStmt d K M_box) mem m1
                (1100 * (K + 1) + 150 * (d + 1) + 800) := by
              unfold propagateJobLevelStmt
              exact ((DetExecAt.ite_true hcond8 (C_c := 10) (by simp [condExprOps, intExprOps])
                (DetExecAt.ite_false hcond5 (C_c := 10) (by simp [condExprOps, intExprOps])
                  (DetExecAt.ite_true hcond_2 (C_c := 16) (by simp [condExprOps, intExprOps]) hd1))).seq hclean1).mono_cost (by omega)
            refine ⟨m1, passOut, hs_br, hp1, hgen1,
              ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
               hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_bS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_dS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_spDS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_rS],
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_spRS],
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_bS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_dS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_spDS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_rS,
               by rw [hw1_o 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_spRS_iff,
               hb_pos,
               by rw [hw1_o 23 (by decide) (by decide) (by decide) (by decide), hw_bCard],
               hOther1 bS hbS hbd hbspD hbr (fun _ => hbspR) _ _ hSeg_bS,
               hSlot_bS'.congr_mem (hw1_o 6 (by decide) (by decide) (by decide) (by decide) _)
                 (hw1_o 11 (by decide) (by decide) (by decide) (by decide))
                 (hr1_o 11 (by decide) (by decide)),
               fun c => by rw [hr1_o 23 (by decide) (by decide), hr_o c],
               Or.inr (Or.inr ⟨by rw [hw1_o 24 (by decide) (by decide) (by decide) (by decide), hph],
                 by rw [hr1_o 24 (by decide) (by decide), hrV],
                 hEd1, hEspD1, hEr1, fun hl => hEspR1 (h6_spRS_iff.mpr hl)⟩)⟩,
              by
                rw [hw26_8_t rfl]
                dsimp [passOut]
                by_cases hle : euclideanDistSq (livePts' h) ball.o ≤ ball.V <;> simp [hle],
              (fun hf => by cases hf),
              (fun _ _ => by
                dsimp only [S_parent', passOut]
                simp only [↓reduceIte]
                rw [nodeResidual_insert, nodeResidual_congr_on ball S_parent hlive_all]
                by_cases hle : euclideanDistSq (livePts' h) ball.o ≤ ball.V <;> simp [hle]),
              (fun s' hs' hnot S₁ fSq₁ h0 => by
                rcases hslot_not s' hnot with ⟨h1, h2, h3, h4⟩
                exact hOther1 s' hs' h1 h2 h3 (fun _ => h4) S₁ fSq₁ h0),
              (fun hf S₁ fSq₁ h0 => by
                rw [hspRS_toNat] at h0 ⊢
                exact hOther1 spRS hspRS hdspR.symm hspDspR.symm hrspR.symm
                  (fun h0_6 => False.elim (Bool.false_ne_true (hf.symm.trans (h6_spRS_iff.mp h0_6))))
                  S₁ fSq₁ h0),
              hw1_o, hw1_26, hr1_o⟩

end UL.Proof_lem_7_2_RacerP46
