import UL.Proof.lem_7_2.RacerP46_H2a_BoxAndFrame

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33

@[simp] theorem wReadL_wWriteL_eq (fd : ℕ) (mem : ArithRAMMemory) (v₁ v₂ : ℕ) (i₁ i₂ val : ℤ) :
    wReadL fd (wWriteL fd mem v₂ i₂ val) v₁ i₁ =
      if v₁ = v₂ ∧ i₁ = i₂ then val else wReadL fd mem v₁ i₁ := by
  by_cases h : v₁ = v₂ ∧ i₁ = i₂
  · rcases h with ⟨rfl, rfl⟩; simp
  · rw [if_neg h]; exact wReadL_wWriteL_of_ne fd mem val (by omega)

@[simp] theorem rReadL_rWriteL_eq (fd : ℕ) (mem : ArithRAMMemory) (v₁ v₂ : ℕ) (i₁ i₂ : ℤ) (val : ℝ) :
    rReadL fd (rWriteL fd mem v₂ i₂ val) v₁ i₁ =
      if v₁ = v₂ ∧ i₁ = i₂ then val else rReadL fd mem v₁ i₁ := by
  by_cases h : v₁ = v₂ ∧ i₁ = i₂
  · rcases h with ⟨rfl, rfl⟩; simp
  · rw [if_neg h]; exact rReadL_rWriteL_of_ne fd mem val (by omega)

@[simp] theorem wRead_wWrite_eq (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ val : ℤ) :
    wRead (wWrite mem t₂ i₂ val) t₁ i₁ =
      if t₁ = t₂ ∧ i₁ = i₂ then val else wRead mem t₁ i₁ := by
  by_cases h : t₁ = t₂ ∧ i₁ = i₂
  · rcases h with ⟨rfl, rfl⟩; simp
  · rw [if_neg h]; exact wRead_wWrite_of_ne mem val (by omega)

@[simp] theorem rRead_rWrite_eq (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) (val : ℝ) :
    rRead (rWrite mem t₂ i₂ val) t₁ i₁ =
      if t₁ = t₂ ∧ i₁ = i₂ then val else rRead mem t₁ i₁ := by
  by_cases h : t₁ = t₂ ∧ i₁ = i₂
  · rcases h with ⟨rfl, rfl⟩; simp
  · rw [if_neg h]; exact rRead_rWrite_of_ne mem val (by omega)

/-! ### 1. Pure Dyadic Segment-Tree Subsets, Rank Selection & Successor Lemmas -/

/-- Dyadic interval slice `S ∩ [off * 2^r, (off + 1) * 2^r)` of handle set `S`. -/
def segSubSet (S : Finset ℕ) (r off : ℕ) : Finset ℕ :=
  S ∩ Finset.Ico (off * 2 ^ r) ((off + 1) * 2 ^ r)

theorem mem_segSubSet {S : Finset ℕ} {r off x : ℕ} :
    x ∈ segSubSet S r off ↔ x ∈ S ∧ off * 2 ^ r ≤ x ∧ x < (off + 1) * 2 ^ r := by
  simp [segSubSet, Finset.mem_inter, Finset.mem_Ico]

theorem segSubSet_zero (S : Finset ℕ) (h : ℕ) :
    segSubSet S 0 h = if h ∈ S then {h} else ∅ := by
  ext x
  simp only [mem_segSubSet, pow_zero, mul_one]
  by_cases hh : h ∈ S
  · simp only [hh, ↓reduceIte, Finset.mem_singleton]
    exact ⟨fun ⟨_, h1, h2⟩ => by omega, fun heq => by subst heq; exact ⟨hh, le_rfl, by omega⟩⟩
  · simp only [hh, Bool.false_eq_true, ↓reduceIte, Finset.notMem_empty, iff_false]
    rintro ⟨hxS, h1, h2⟩
    have : x = h := by omega
    subst this; exact hh hxS

theorem segSubSet_root {K : ℕ} {S : Finset ℕ} (hS : ∀ x ∈ S, x < 2 ^ K) :
    segSubSet S K 0 = S := by
  ext x
  simp only [mem_segSubSet, zero_mul, zero_add, one_mul, Nat.zero_le, true_and,
    and_iff_left_iff_imp]
  exact fun hx => hS x hx

theorem segSubSet_succ_disjoint (S : Finset ℕ) (r off : ℕ) :
    Disjoint (segSubSet S r (2 * off)) (segSubSet S r (2 * off + 1)) := by
  rw [Finset.disjoint_left]
  intro x hxL hxR
  rw [mem_segSubSet] at hxL hxR
  omega

theorem segSubSet_succ_union (S : Finset ℕ) (r off : ℕ) :
    segSubSet S (r + 1) off = segSubSet S r (2 * off) ∪ segSubSet S r (2 * off + 1) := by
  ext x
  simp only [Finset.mem_union, mem_segSubSet]
  have h1 : (2 * off) * 2 ^ r = off * 2 ^ (r + 1) := by rw [pow_succ]; ring
  have hmid : (2 * off + 1) * 2 ^ r = off * 2 ^ (r + 1) + 2 ^ r := by rw [pow_succ]; ring
  have h2 : (2 * off + 1 + 1) * 2 ^ r = off * 2 ^ (r + 1) + 2 ^ r + 2 ^ r := by rw [pow_succ]; ring
  have h3 : (off + 1) * 2 ^ (r + 1) = off * 2 ^ (r + 1) + 2 ^ r + 2 ^ r := by rw [pow_succ]; ring
  rw [h1, hmid, h2, h3]
  generalize off * 2 ^ (r + 1) = A, 2 ^ r = B
  by_cases hxS : x ∈ S <;> simp [hxS] <;> omega

theorem segSubSet_succ_card (S : Finset ℕ) (r off : ℕ) :
    (segSubSet S (r + 1) off).card =
      (segSubSet S r (2 * off)).card + (segSubSet S r (2 * off + 1)).card := by
  rw [segSubSet_succ_union, Finset.card_union_of_disjoint (segSubSet_succ_disjoint S r off)]

theorem segSubSet_insert_of_not_in_range {S : Finset ℕ} {r off h : ℕ}
    (hout : ¬ (off * 2 ^ r ≤ h ∧ h < (off + 1) * 2 ^ r)) :
    segSubSet (insert h S) r off = segSubSet S r off := by
  ext x
  simp only [mem_segSubSet, Finset.mem_insert]
  constructor
  · rintro ⟨rfl | hxS, h1, h2⟩
    · exact False.elim (hout ⟨h1, h2⟩)
    · exact ⟨hxS, h1, h2⟩
  · rintro ⟨hxS, h1, h2⟩
    exact ⟨Or.inr hxS, h1, h2⟩

theorem segSubSet_erase_of_not_in_range {S : Finset ℕ} {r off h : ℕ}
    (hout : ¬ (off * 2 ^ r ≤ h ∧ h < (off + 1) * 2 ^ r)) :
    segSubSet (S.erase h) r off = segSubSet S r off := by
  ext x
  simp only [mem_segSubSet, Finset.mem_erase]
  constructor
  · rintro ⟨⟨_, hxS⟩, h1, h2⟩
    exact ⟨hxS, h1, h2⟩
  · rintro ⟨hxS, h1, h2⟩
    refine ⟨⟨?_, hxS⟩, h1, h2⟩
    rintro rfl
    exact hout ⟨h1, h2⟩

theorem filter_lt_split_card (S : Finset ℕ) (r off : ℕ) :
    (S.filter (· < (2 * off + 1) * 2 ^ r)).card =
      (S.filter (· < off * 2 ^ (r + 1))).card + (segSubSet S r (2 * off)).card := by
  have h1 : (2 * off) * 2 ^ r = off * 2 ^ (r + 1) := by rw [pow_succ]; ring
  have hmid : (2 * off + 1) * 2 ^ r = off * 2 ^ (r + 1) + 2 ^ r := by rw [pow_succ]; ring
  have hunion : S.filter (· < (2 * off + 1) * 2 ^ r) =
      S.filter (· < off * 2 ^ (r + 1)) ∪ segSubSet S r (2 * off) := by
    ext x
    simp only [Finset.mem_union, Finset.mem_filter, mem_segSubSet]
    rw [h1, hmid]
    generalize off * 2 ^ (r + 1) = A, 2 ^ r = B
    by_cases hxS : x ∈ S <;> simp [hxS] <;> omega
  have hdisj : Disjoint (S.filter (· < off * 2 ^ (r + 1))) (segSubSet S r (2 * off)) := by
    rw [Finset.disjoint_left]
    intro x hx1 hx2
    simp only [Finset.mem_filter] at hx1
    rw [mem_segSubSet, h1, hmid] at hx2
    generalize off * 2 ^ (r + 1) = A, 2 ^ r = B at *
    omega
  rw [hunion, Finset.card_union_of_disjoint hdisj]

/-- Unique characterization of `S.orderEmbOfFin rfl ⟨rk, hrk⟩` via `card (S.filter (· < y)) = rk`. -/
theorem card_filter_lt_orderEmbOfFin {S : Finset ℕ} (j : Fin S.card) :
    (S.filter (· < S.orderEmbOfFin rfl j)).card = j.val := by
  let f := S.orderEmbOfFin rfl
  have hmap : Finset.univ.map f.toEmbedding = S :=
    Finset.eq_of_subset_of_card_le
      (fun z hz => by
        rcases Finset.mem_map.mp hz with ⟨k, _, rfl⟩
        exact Finset.orderEmbOfFin_mem S rfl k)
      (by simp)
  have hfilt_eq : S.filter (· < f j) = (Finset.univ.filter (· < j)).map f.toEmbedding := by
    ext z
    simp only [Finset.mem_filter, Finset.mem_map, Finset.mem_univ, true_and]
    constructor
    · rintro ⟨hzS, hlt⟩
      rw [← hmap, Finset.mem_map] at hzS
      rcases hzS with ⟨k, _, rfl⟩
      exact ⟨k, f.lt_iff_lt.mp (by simpa using hlt), rfl⟩
    · rintro ⟨k, hkj, rfl⟩
      exact ⟨Finset.orderEmbOfFin_mem S rfl k, f.strictMono hkj⟩
  change (S.filter (· < f j)).card = j.val
  rw [hfilt_eq, Finset.card_map, ← Finset.card_range j.val]
  refine Finset.card_bij (fun (k : Fin S.card) _ => k.val) ?_ ?_ ?_
  · intro k hk
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hk
    exact Finset.mem_range.mpr hk
  · intro k₁ _ k₂ _ heq; exact Fin.ext heq
  · intro m hm
    rw [Finset.mem_range] at hm
    exact ⟨⟨m, lt_trans hm j.isLt⟩, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hm⟩, rfl⟩

theorem eq_orderEmbOfFin_of_card_filter_lt {S : Finset ℕ} {y rk : ℕ}
    (hy : y ∈ S) (hrk : rk < S.card) (hcard : (S.filter (· < y)).card = rk) :
    S.orderEmbOfFin rfl ⟨rk, hrk⟩ = y := by
  let f := S.orderEmbOfFin rfl
  have hmap : Finset.univ.map f.toEmbedding = S :=
    Finset.eq_of_subset_of_card_le
      (fun z hz => by
        rcases Finset.mem_map.mp hz with ⟨k, _, rfl⟩
        exact Finset.orderEmbOfFin_mem S rfl k)
      (by simp)
  have hy_map : y ∈ Finset.univ.map f.toEmbedding := hmap.symm ▸ hy
  rcases Finset.mem_map.mp hy_map with ⟨i, _, hfi⟩
  have hfi' : f i = y := by simpa using hfi
  have hi_val : i.val = rk := by
    rw [← card_filter_lt_orderEmbOfFin i]
    change (S.filter (· < f i)).card = rk
    rw [hfi', hcard]
  have hi_eq : i = ⟨rk, hrk⟩ := Fin.ext hi_val
  change f ⟨rk, hrk⟩ = y
  rw [← hi_eq]
  exact hfi'

/-- Successor characterization from `c = (S.filter (· < q)).card < S.card` and
`(S.filter (· < y)).card = c` with `y ∈ S`. -/
theorem succ_of_card_filter_lt_eq {S : Finset ℕ} {q y : ℕ}
    (hy : y ∈ S)
    (heq : (S.filter (· < y)).card = (S.filter (· < q)).card) :
    q ≤ y ∧ ∀ x ∈ S, q ≤ x → y ≤ x := by
  constructor
  · by_contra hlt
    push_neg at hlt
    have hsub : insert y (S.filter (· < y)) ⊆ S.filter (· < q) := by
      intro z hz
      simp only [Finset.mem_insert, Finset.mem_filter] at hz ⊢
      rcases hz with rfl | ⟨hzS, hzy⟩
      · exact ⟨hy, hlt⟩
      · exact ⟨hzS, lt_trans hzy hlt⟩
    have hy_not : y ∉ S.filter (· < y) := by simp
    have hcard_ins := Finset.card_le_card hsub
    rw [Finset.card_insert_of_notMem hy_not] at hcard_ins
    omega
  · intro x hxS hqx
    by_contra hxy
    push_neg at hxy
    have hsub : insert x (S.filter (· < q)) ⊆ S.filter (· < y) := by
      intro z hz
      simp only [Finset.mem_insert, Finset.mem_filter] at hz ⊢
      rcases hz with rfl | ⟨hzS, hzq⟩
      · exact ⟨hxS, hxy⟩
      · exact ⟨hzS, lt_of_lt_of_le hzq (le_of_lt (lt_of_le_of_lt hqx hxy))⟩
    have hx_not : x ∉ S.filter (· < q) := by simp; omega
    have hcard_ins := Finset.card_le_card hsub
    rw [Finset.card_insert_of_notMem hx_not] at hcard_ins
    omega

theorem all_lt_of_card_filter_lt_eq_card {S : Finset ℕ} {q : ℕ}
    (heq : (S.filter (· < q)).card = S.card) :
    ∀ x ∈ S, x < q := by
  have hS_eq : S.filter (· < q) = S :=
    Finset.eq_of_subset_of_card_le (Finset.filter_subset _ _) (by omega)
  intro x hx
  rw [← hS_eq, Finset.mem_filter] at hx
  exact hx.2

/-! ### 2. RAM Segment-Tree Slot Representation (`EncSegSlot` & `SegGenBound`) -/

def effSegCnt (K : ℕ) (mem : ArithRAMMemory) (s u : ℕ) : ℤ :=
  let base : ℤ := ((s * 2 ^ (K + 1) + u : ℕ) : ℤ)
  if wRead mem 8 base = wRead mem 5 (s : ℤ) then wRead mem 9 base else 0

def EncSegNode (K : ℕ) (mem : ArithRAMMemory) (s r off : ℕ)
    (S : Finset ℕ) (fSq : ℕ → ℝ) : Prop :=
  let u := 2 ^ (K - r) + off
  let base : ℤ := ((s * 2 ^ (K + 1) + u : ℕ) : ℤ)
  let Sn := segSubSet S r off
  effSegCnt K mem s u = (Sn.card : ℤ) ∧
  (Sn.Nonempty →
    wRead mem 8 base = wRead mem 5 (s : ℤ) ∧
    ∃ mh : ℕ, mh ∈ Sn ∧
      wRead mem 10 base = (mh : ℤ) ∧
      rRead mem 8 base = fSq mh ∧
      ∀ x ∈ Sn, fSq x ≤ fSq mh)

def EncSegSlot (K : ℕ) (mem : ArithRAMMemory) (s : ℕ)
    (S : Finset ℕ) (fSq : ℕ → ℝ) : Prop :=
  1 ≤ wRead mem 5 (s : ℤ) ∧
  (∀ x ∈ S, x < 2 ^ K) ∧
  ∀ r ≤ K, ∀ off < 2 ^ (K - r), EncSegNode K mem s r off S fSq

def SegGenBound (K NumSlots : ℕ) (mem : ArithRAMMemory) : Prop :=
  1 ≤ wRead mem 1 3 ∧
  (∀ s < NumSlots, wRead mem 5 (s : ℤ) < wRead mem 1 3) ∧
  (∀ s < NumSlots, ∀ u < 2 ^ (K + 1),
    wRead mem 8 ((s * 2 ^ (K + 1) + u : ℕ) : ℤ) < wRead mem 1 3)

theorem seg_node_lt_width {K r off : ℕ} (hr : r ≤ K) (hoff : off < 2 ^ (K - r)) :
    2 ^ (K - r) + off < 2 ^ (K + 1) := by
  have h1 : 2 ^ (K - r) + off < 2 * 2 ^ (K - r) := by omega
  have h2 : 2 * 2 ^ (K - r) = 2 ^ (K - r + 1) := by rw [pow_succ']
  have h3 : 2 ^ (K - r + 1) ≤ 2 ^ (K + 1) := Nat.pow_le_pow_right (by decide) (by omega)
  omega

theorem seg_base_ne_of_slot_ne {K s₁ s₂ u₁ u₂ : ℕ} (hs : s₁ ≠ s₂)
    (hu₁ : u₁ < 2 ^ (K + 1)) (hu₂ : u₂ < 2 ^ (K + 1)) :
    ((s₁ * 2 ^ (K + 1) + u₁ : ℕ) : ℤ) ≠ ((s₂ * 2 ^ (K + 1) + u₂ : ℕ) : ℤ) := by
  intro heq
  have hnat : s₁ * 2 ^ (K + 1) + u₁ = s₂ * 2 ^ (K + 1) + u₂ := Int.ofNat.inj heq
  rcases lt_trichotomy s₁ s₂ with hlt | rfl | hgt
  · have hle : (s₁ + 1) * 2 ^ (K + 1) ≤ s₂ * 2 ^ (K + 1) :=
      Nat.mul_le_mul_right _ hlt
    have : s₁ * 2 ^ (K + 1) + u₁ < (s₁ + 1) * 2 ^ (K + 1) := by rw [add_mul, one_mul]; omega
    omega
  · exact hs rfl
  · have hle : (s₂ + 1) * 2 ^ (K + 1) ≤ s₁ * 2 ^ (K + 1) :=
      Nat.mul_le_mul_right _ hgt
    have : s₂ * 2 ^ (K + 1) + u₂ < (s₂ + 1) * 2 ^ (K + 1) := by rw [add_mul, one_mul]; omega
    omega

theorem EncSegSlot.congr_mem_fSq {K : ℕ} {m₁ m₂ : ArithRAMMemory} {s : ℕ}
    {S : Finset ℕ} {f₁ f₂ : ℕ → ℝ}
    (h : EncSegSlot K m₁ s S f₁)
    (hg : wRead m₂ 5 (s : ℤ) = wRead m₁ 5 (s : ℤ))
    (hw8 : ∀ u < 2 ^ (K + 1), wRead m₂ 8 ((s * 2 ^ (K + 1) + u : ℕ) : ℤ) =
             wRead m₁ 8 ((s * 2 ^ (K + 1) + u : ℕ) : ℤ))
    (hw9 : ∀ u < 2 ^ (K + 1), wRead m₂ 9 ((s * 2 ^ (K + 1) + u : ℕ) : ℤ) =
             wRead m₁ 9 ((s * 2 ^ (K + 1) + u : ℕ) : ℤ))
    (hw10 : ∀ u < 2 ^ (K + 1), wRead m₂ 10 ((s * 2 ^ (K + 1) + u : ℕ) : ℤ) =
              wRead m₁ 10 ((s * 2 ^ (K + 1) + u : ℕ) : ℤ))
    (hr8 : ∀ u < 2 ^ (K + 1), rRead m₂ 8 ((s * 2 ^ (K + 1) + u : ℕ) : ℤ) =
             rRead m₁ 8 ((s * 2 ^ (K + 1) + u : ℕ) : ℤ))
    (hf : ∀ x ∈ S, f₂ x = f₁ x) :
    EncSegSlot K m₂ s S f₂ := by
  refine ⟨hg ▸ h.1, h.2.1, fun r hr off hoff => ?_⟩
  have hu : 2 ^ (K - r) + off < 2 ^ (K + 1) := seg_node_lt_width hr hoff
  have hn := h.2.2 r hr off hoff
  dsimp only [EncSegNode] at hn ⊢
  have heff : effSegCnt K m₂ s (2 ^ (K - r) + off) = effSegCnt K m₁ s (2 ^ (K - r) + off) := by
    simp only [effSegCnt, hw8 _ hu, hg, hw9 _ hu]
  refine ⟨heff.trans hn.1, fun hne => ?_⟩
  rcases hn.2 hne with ⟨hv, mh, hmh, hm10, hmr8, hmax⟩
  have hmh_S : mh ∈ S := (mem_segSubSet.mp hmh).1
  refine ⟨by rw [hw8 _ hu, hg]; exact hv, mh, hmh, by rw [hw10 _ hu]; exact hm10,
    by rw [hr8 _ hu, hf mh hmh_S]; exact hmr8, fun x hx => ?_⟩
  have hx_S : x ∈ S := (mem_segSubSet.mp hx).1
  rw [hf x hx_S, hf mh hmh_S]
  exact hmax x hx

/-! ### 3. O(1) Slot Reset, Root Summary (`card`/`max`), and Leaf Membership Lookup -/

/-- Reset segment-tree slot `s` in `O(1)` time by bumping `nextGen` (`heap 1 3`). -/
def resetSegSlotStmt (M_box : ℕ) (sE : IntExpr) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 28 (.lit 0) sE,
    .writeWordLocal 28 (.lit 1) (.readHeap 1 (.lit 3)),
    boxWriteW M_box 5 (.readLocal 28 (.lit 0)) (.readLocal 28 (.lit 1)),
    boxWriteW M_box 1 (.lit 3) (.add (.readLocal 28 (.lit 1)) (.lit 1))
  ]

theorem boxSafe_resetSegSlotStmt {T_max M_box : ℕ} (hT : 6 ≤ T_max) (sE : IntExpr) :
    BoxSafeInner T_max M_box (resetSegSlotStmt M_box sE) := by
  unfold resetSegSlotStmt
  apply boxSafeInner_seqList
  intro st hst
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _

theorem exec_resetSegSlotStmt {d K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (sE : IntExpr) {s : ℕ} (hs : s < NumSlots)
    (hsE : iValAt 1 inp mem sE = (s : ℤ))
    (hM1 : 4 ≤ M_box) (hMs : NumSlots ≤ M_box)
    (hgen : SegGenBound K NumSlots mem) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (resetSegSlotStmt M_box sE) mem mem' (intExprOps sE + 40) ∧
      SegGenBound K NumSlots mem' ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K mem' s ∅ fSq) ∧
      (∀ s' < NumSlots, s' ≠ s → ∀ S' fSq',
        EncSegSlot K mem s' S' fSq' → EncSegSlot K mem' s' S' fSq') ∧
      (∀ t : ℕ, t ≠ 1 → t ≠ 5 → ∀ idx : ℤ, wRead mem' t idx = wRead mem t idx) ∧
      (∀ idx : ℤ, idx ≠ 3 → wRead mem' 1 idx = wRead mem 1 idx) ∧
      (∀ t : ℕ, ∀ idx : ℤ, rRead mem' t idx = rRead mem t idx) ∧
      (∀ v : ℕ, v ≠ 28 → ∀ idx : ℤ, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v : ℕ, ∀ idx : ℤ, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  set g := wRead mem 1 3
  let m1 := wWriteL 1 mem 28 0 (s : ℤ)
  let m2 := wWriteL 1 m1 28 1 g
  let m3 := wWrite m2 5 (s : ℤ) g
  let m4 := wWrite m3 1 3 (g + 1)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 0) sE) mem m1 (intExprOps sE + 2) :=
    DetExecAt.writeWordLocal 1 inp mem 28 (.lit 0) sE rfl hsE (by dsimp [intExprOps]; omega)
  have hs2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 1) (.readHeap 1 (.lit 3))) m1 m2 5 :=
    DetExecAt.writeWordLocal 1 inp m1 28 (.lit 1) (.readHeap 1 (.lit 3)) rfl
      (by simp [m1, g]) (by simp [intExprOps, realExprOps, condExprOps])
  have hs3 : DetExecAt 1 inp (boxWriteW M_box 5 (.readLocal 28 (.lit 0)) (.readLocal 28 (.lit 1)))
      m2 m3 14 :=
    exec_boxWriteW inp m2 (.readLocal 28 (.lit 0)) (.readLocal 28 (.lit 1))
      (by simp [m2, m1]) (by omega) (by omega) (by simp [m2]) (by simp [intExprOps, realExprOps, condExprOps])
  have hs4 : DetExecAt 1 inp (boxWriteW M_box 1 (.lit 3) (.add (.readLocal 28 (.lit 1)) (.lit 1)))
      m3 m4 14 :=
    exec_boxWriteW inp m3 (.lit 3) (.add (.readLocal 28 (.lit 1)) (.lit 1))
      rfl (by omega) (by omega) (by simp [m3, m2]) (by simp [intExprOps, realExprOps, condExprOps])
  have hexec : DetExecAt 1 inp (resetSegSlotStmt M_box sE) mem m4 (intExprOps sE + 40) :=
    (hs1.seq (hs2.seq (hs3.seq hs4))).mono_cost (by omega)
  refine ⟨m4, hexec, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · refine ⟨?_, ?_, ?_⟩
    · have hg1 := hgen.1
      simp only [m4, m3, m2, m1, wRead_wWrite_self]; omega
    · intro s' hs'
      simp only [m4, wRead_wWrite_of_ne _ _ (Or.inl (by decide : (5 : ℕ) ≠ 1)),
        wRead_wWrite_self]
      by_cases heq : s' = s
      · subst heq; simp [m3]
      · have hne_z : (s' : ℤ) ≠ (s : ℤ) := by omega
        have := hgen.2.1 s' hs'
        simp only [m3, m2, m1, wRead_wWrite_of_ne _ _ (Or.inr hne_z), wRead_wWriteL]
        omega
    · intro s' hs' u hu
      have := hgen.2.2 s' hs' u hu
      simp only [m4, m3, m2, m1, wRead_wWrite_self,
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 1)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 5)), wRead_wWriteL]
      omega
  · intro fSq
    refine ⟨?_, fun x hx => by simp at hx, fun r hr off hoff => ?_⟩
    · have hg1 := hgen.1
      simp only [m4, m3, m2, m1, wRead_wWrite_of_ne _ _ (Or.inl (by decide : (5 : ℕ) ≠ 1)),
        wRead_wWrite_self]
      exact hg1
    · have hu := seg_node_lt_width hr hoff
      have hlt_g := hgen.2.2 s hs (2 ^ (K - r) + off) hu
      dsimp only [EncSegNode]
      have hemp : segSubSet ∅ r off = ∅ := by simp [segSubSet]
      rw [hemp]
      refine ⟨?_, fun hne => by simp at hne⟩
      have hne_g : wRead mem 8 ((s * 2 ^ (K + 1) + (2 ^ (K - r) + off) : ℕ) : ℤ) ≠ g := by omega
      dsimp only [effSegCnt]
      simp only [m4, m3, m2, m1, wRead_wWrite_eq, wRead_wWriteL, Finset.card_empty, Nat.cast_zero]
      exact if_neg (by simpa using hne_g)
  · intro s' _ hne S' fSq' hEnc
    have hne_z : (s' : ℤ) ≠ (s : ℤ) := by omega
    refine hEnc.congr_mem_fSq ?_ ?_ ?_ ?_ ?_ (fun _ _ => rfl)
    · simp [m4, m3, m2, m1, wRead_wWrite_of_ne _ _ (Or.inl (by decide : (5 : ℕ) ≠ 1)),
        wRead_wWrite_of_ne _ _ (Or.inr hne_z)]
    · intro u _; simp [m4, m3, m2, m1,
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 1)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 5))]
    · intro u _; simp [m4, m3, m2, m1,
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (9 : ℕ) ≠ 1)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (9 : ℕ) ≠ 5))]
    · intro u _; simp [m4, m3, m2, m1,
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (10 : ℕ) ≠ 1)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (10 : ℕ) ≠ 5))]
    · intro u _; simp [m4, m3, m2, m1, rRead, wWrite, wWriteL]
  · intro t ht1 ht5 idx
    simp [m4, m3, m2, m1, wRead_wWrite_of_ne _ _ (Or.inl ht1), wRead_wWrite_of_ne _ _ (Or.inl ht5)]
  · intro idx hidx
    simp [m4, m3, m2, m1, wRead_wWrite_of_ne _ _ (Or.inr hidx),
      wRead_wWrite_of_ne _ _ (Or.inl (by decide : (1 : ℕ) ≠ 5))]
  · intro t idx; simp [m4, m3, m2, m1, rRead, wWrite, wWriteL]
  · intro v hv idx
    simp [m4, m3, m2, m1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv)]
  · intro v idx; simp [m4, m3, m2, m1, rReadL, wWrite, wWriteL]

/-- Read `(S.card, bestH, bestSq)` from root `u = 1` of slot `s` into local var `28`:
`wReadL 1 mem' 28 0 = S.card`, `wReadL 1 mem' 28 1 = bestH`, `rReadL 1 mem' 28 0 = bestSq`. -/
def cardAndMaxSegSlotStmt (K : ℕ) (sE : IntExpr) : ArithRAMStmt :=
  let W_lit : IntExpr := .lit ((2 ^ (K + 1) : ℕ) : ℤ)
  seqList [
    .writeWordLocal 28 (.lit 2) sE,
    .writeWordLocal 28 (.lit 3) (.add (.mul (.readLocal 28 (.lit 2)) W_lit) (.lit 1)),
    .ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 3))) (.readHeap 5 (.readLocal 28 (.lit 2))))
      (seqList [
        .writeWordLocal 28 (.lit 0) (.readHeap 9 (.readLocal 28 (.lit 3))),
        .writeWordLocal 28 (.lit 1) (.readHeap 10 (.readLocal 28 (.lit 3))),
        .writeRealLocal 28 (.lit 0) (.readRealHeap 8 (.readLocal 28 (.lit 3)))
      ])
      (seqList [
        .writeWordLocal 28 (.lit 0) (.lit 0),
        .writeWordLocal 28 (.lit 1) (.lit 0),
        .writeRealLocal 28 (.lit 0) (.ofInt (.lit 0))
      ])
  ]

theorem boxSafe_cardAndMaxSegSlotStmt {T_max M_box : ℕ} (K : ℕ) (sE : IntExpr) :
    BoxSafeInner T_max M_box (cardAndMaxSegSlotStmt K sE) := by
  unfold cardAndMaxSegSlotStmt
  apply boxSafeInner_seqList
  intro st hst
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_)
    · intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact .writeWordLocal _ _ _
      · exact .writeRealLocal _ _ _
    · intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact .writeWordLocal _ _ _
      · exact .writeRealLocal _ _ _

theorem exec_cardAndMaxSegSlotStmt {d K : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (sE : IntExpr) {s : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    (hsE : iValAt 1 inp mem sE = (s : ℤ))
    (hEnc : EncSegSlot K mem s S fSq) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (cardAndMaxSegSlotStmt K sE) mem mem' (intExprOps sE + 45) ∧
      wReadL 1 mem' 28 0 = (S.card : ℤ) ∧
      (S.Nonempty →
        ∃ mh ∈ S,
          wReadL 1 mem' 28 1 = (mh : ℤ) ∧
          rReadL 1 mem' 28 0 = fSq mh ∧
          ∀ x ∈ S, fSq x ≤ fSq mh) ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ v, v ≠ 28 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v, v ≠ 28 → ∀ idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  have hroot := hEnc.2.2 K le_rfl 0 (by simp)
  dsimp only [EncSegNode] at hroot
  rw [Nat.sub_self, pow_zero, add_zero, segSubSet_root hEnc.2.1] at hroot
  let rootIdx : ℤ := ((s * 2 ^ (K + 1) + 1 : ℕ) : ℤ)
  let m1 := wWriteL 1 mem 28 2 (s : ℤ)
  let m2 := wWriteL 1 m1 28 3 rootIdx
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 2) sE) mem m1 (intExprOps sE + 2) :=
    DetExecAt.writeWordLocal 1 inp mem 28 (.lit 2) sE rfl hsE (by dsimp [intExprOps]; omega)
  have hs2 : DetExecAt 1 inp
      (.writeWordLocal 28 (.lit 3) (.add (.mul (.readLocal 28 (.lit 2)) (.lit ((2 ^ (K + 1) : ℕ) : ℤ))) (.lit 1)))
      m1 m2 8 :=
    DetExecAt.writeWordLocal 1 inp m1 28 (.lit 3) _ rfl
      (by simp [m1, rootIdx]) (by simp [intExprOps, realExprOps, condExprOps])
  by_cases hv : wRead mem 8 rootIdx = wRead mem 5 (s : ℤ)
  · have hc_t : cValAt 1 inp m2
        (.intEq (.readHeap 8 (.readLocal 28 (.lit 3))) (.readHeap 5 (.readLocal 28 (.lit 2)))) = true := by
      simp [m2, m1, hv]
    let m3 := wWriteL 1 m2 28 0 (wRead mem 9 rootIdx)
    let m4 := wWriteL 1 m3 28 1 (wRead mem 10 rootIdx)
    let m5 := rWriteL 1 m4 28 0 (rRead mem 8 rootIdx)
    have hb1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 0) (.readHeap 9 (.readLocal 28 (.lit 3)))) m2 m3 6 :=
      DetExecAt.writeWordLocal 1 inp m2 28 (.lit 0) _ rfl (by simp [m2, m1]) (by simp [intExprOps, realExprOps, condExprOps])
    have hb2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 1) (.readHeap 10 (.readLocal 28 (.lit 3)))) m3 m4 6 :=
      DetExecAt.writeWordLocal 1 inp m3 28 (.lit 1) _ rfl (by simp [m3, m2, m1]) (by simp [intExprOps, realExprOps, condExprOps])
    have hb3 : DetExecAt 1 inp (.writeRealLocal 28 (.lit 0) (.readRealHeap 8 (.readLocal 28 (.lit 3)))) m4 m5 6 :=
      DetExecAt.writeRealLocal 1 inp m4 28 (.lit 0) _ rfl (by simp [m4, m3, m2, m1, rRead_wWriteL]) (by simp [intExprOps, realExprOps, condExprOps])
    refine ⟨m5, (hs1.seq (hs2.seq (DetExecAt.ite_true hc_t (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) (hb1.seq (hb2.seq hb3))))).mono_cost (by omega), ?_, ?_, ?_, ?_, ?_, ?_⟩
    · have heff := hroot.1
      simp only [effSegCnt, rootIdx, hv, ↓reduceIte] at heff
      simp only [m5, m4, m3, wReadL_rWriteL, wReadL_wWriteL_eq]
      exact heff
    · intro hne
      rcases hroot.2 hne with ⟨_, mh, hmh, hm10, hmr8, hmax⟩
      refine ⟨mh, hmh, ?_, ?_, hmax⟩
      · simp only [m5, m4, wReadL_rWriteL, wReadL_wWriteL_eq]; exact hm10
      · simp only [m5, rReadL_rWriteL_self]; exact hmr8
    · intro t idx; simp [m5, m4, m3, m2, m1, wRead_rWriteL]
    · intro t idx; simp [m5, m4, m3, m2, m1, rRead_rWriteL]
    · intro v hv' idx; simp [m5, m4, m3, m2, m1, wReadL_rWriteL, hv']
    · intro v hv' idx; simp [m5, m4, m3, m2, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inl hv')]
  · have hc_f : cValAt 1 inp m2
        (.intEq (.readHeap 8 (.readLocal 28 (.lit 3))) (.readHeap 5 (.readLocal 28 (.lit 2)))) = false := by
      simp [m2, m1, hv]
    let m3 := wWriteL 1 m2 28 0 0
    let m4 := wWriteL 1 m3 28 1 0
    let m5 := rWriteL 1 m4 28 0 0
    have hb1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 0) (.lit 0)) m2 m3 4 :=
      DetExecAt.writeWordLocal 1 inp m2 28 (.lit 0) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
    have hb2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 1) (.lit 0)) m3 m4 4 :=
      DetExecAt.writeWordLocal 1 inp m3 28 (.lit 1) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
    have hb3 : DetExecAt 1 inp (.writeRealLocal 28 (.lit 0) (.ofInt (.lit 0))) m4 m5 5 :=
      DetExecAt.writeRealLocal 1 inp m4 28 (.lit 0) _ rfl (by simp) (by simp [intExprOps, realExprOps, condExprOps])
    refine ⟨m5, (hs1.seq (hs2.seq (DetExecAt.ite_false hc_f (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) (hb1.seq (hb2.seq hb3))))).mono_cost (by omega), ?_, ?_, ?_, ?_, ?_, ?_⟩
    · have heff := hroot.1
      simp only [effSegCnt, rootIdx, hv, ↓reduceIte] at heff
      simp [m5, m4, m3, wReadL_rWriteL, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (0 : ℤ) ≠ 1)), ← heff]
    · intro hne
      exact False.elim (hv (hroot.2 hne).1)
    · intro t idx; simp [m5, m4, m3, m2, m1, wRead_rWriteL]
    · intro t idx; simp [m5, m4, m3, m2, m1, rRead_rWriteL]
    · intro v hv' idx; simp [m5, m4, m3, m2, m1, wReadL_rWriteL, hv']
    · intro v hv' idx; simp [m5, m4, m3, m2, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inl hv')]

/-- O(1) leaf membership lookup `h ∈ S` via leaf `u = 2^K + h`.
Reads `s` from `local 28[20]` and `h` from `local 28[21]`; writes `if h ∈ S then 1 else 0` to `local 28[0]`. -/
def lookupSegSlotStmt (K : ℕ) : ArithRAMStmt :=
  let W_lit : IntExpr := .lit ((2 ^ (K + 1) : ℕ) : ℤ)
  let leafBase : IntExpr := .lit ((2 ^ K : ℕ) : ℤ)
  seqList [
    .writeWordLocal 28 (.lit 4)
      (.add (.mul (.readLocal 28 (.lit 20)) W_lit) (.add leafBase (.readLocal 28 (.lit 21)))),
    .ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 4))) (.readHeap 5 (.readLocal 28 (.lit 20))))
      (.writeWordLocal 28 (.lit 0) (.readHeap 9 (.readLocal 28 (.lit 4))))
      (.writeWordLocal 28 (.lit 0) (.lit 0))
  ]

theorem boxSafe_lookupSegSlotStmt {T_max M_box : ℕ} (K : ℕ) :
    BoxSafeInner T_max M_box (lookupSegSlotStmt K) := by
  unfold lookupSegSlotStmt
  apply boxSafeInner_seqList
  intro st hst
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .ite _ (.writeWordLocal _ _ _) (.writeWordLocal _ _ _)

theorem exec_lookupSegSlotStmt {d K : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s h : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    (hh : h < 2 ^ K)
    (hs : wReadL 1 mem 28 20 = (s : ℤ))
    (hh_reg : wReadL 1 mem 28 21 = (h : ℤ))
    (hEnc : EncSegSlot K mem s S fSq) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (lookupSegSlotStmt K) mem mem' 30 ∧
      wReadL 1 mem' 28 0 = (if h ∈ S then 1 else 0) ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ v, v ≠ 28 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  have hleaf := (hEnc.2.2 0 (Nat.zero_le K) h (by simpa using hh)).1
  rw [Nat.sub_zero, segSubSet_zero] at hleaf
  let leafIdx : ℤ := ((s * 2 ^ (K + 1) + (2 ^ K + h) : ℕ) : ℤ)
  let m1 := wWriteL 1 mem 28 4 leafIdx
  have hs1 : DetExecAt 1 inp
      (.writeWordLocal 28 (.lit 4)
        (.add (.mul (.readLocal 28 (.lit 20)) (.lit ((2 ^ (K + 1) : ℕ) : ℤ)))
              (.add (.lit ((2 ^ K : ℕ) : ℤ)) (.readLocal 28 (.lit 21)))))
      mem m1 12 :=
    DetExecAt.writeWordLocal 1 inp mem 28 (.lit 4) _ rfl
      (by simp [hs, hh_reg, leafIdx]) (by simp [intExprOps, realExprOps, condExprOps])
  by_cases hv : wRead mem 8 leafIdx = wRead mem 5 (s : ℤ)
  · have hc_t : cValAt 1 inp m1
        (.intEq (.readHeap 8 (.readLocal 28 (.lit 4))) (.readHeap 5 (.readLocal 28 (.lit 20)))) = true := by
      simp [m1, hs, hv, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 4))]
    let m2 := wWriteL 1 m1 28 0 (wRead mem 9 leafIdx)
    have hb : DetExecAt 1 inp (.writeWordLocal 28 (.lit 0) (.readHeap 9 (.readLocal 28 (.lit 4)))) m1 m2 6 :=
      DetExecAt.writeWordLocal 1 inp m1 28 (.lit 0) _ rfl (by simp [m1]) (by simp [intExprOps, realExprOps, condExprOps])
    refine ⟨m2, (hs1.seq (DetExecAt.ite_true hc_t (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) hb)).mono_cost (by omega), ?_, ?_, ?_, ?_, ?_⟩
    · simp only [effSegCnt, leafIdx, hv, ↓reduceIte] at hleaf
      dsimp [m2]; rw [wReadL_wWriteL_self, hleaf]
      split_ifs <;> simp
    · intro t idx; simp [m2, m1]
    · intro t idx; simp [m2, m1]
    · intro v hv' idx; simp [m2, m1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv')]
    · intro v idx; simp [m2, m1]
  · have hc_f : cValAt 1 inp m1
        (.intEq (.readHeap 8 (.readLocal 28 (.lit 4))) (.readHeap 5 (.readLocal 28 (.lit 20)))) = false := by
      simp [m1, hs, hv, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 4))]
    let m2 := wWriteL 1 m1 28 0 0
    have hb : DetExecAt 1 inp (.writeWordLocal 28 (.lit 0) (.lit 0)) m1 m2 4 :=
      DetExecAt.writeWordLocal 1 inp m1 28 (.lit 0) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
    refine ⟨m2, (hs1.seq (DetExecAt.ite_false hc_f (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) hb)).mono_cost (by omega), ?_, ?_, ?_, ?_, ?_⟩
    · simp only [effSegCnt, leafIdx, hv, ↓reduceIte] at hleaf
      dsimp [m2]; rw [wReadL_wWriteL_self]
      by_cases hhS : h ∈ S
      · simp [hhS] at hleaf
      · simp [hhS]
    · intro t idx; simp [m2, m1]
    · intro t idx; simp [m2, m1]
    · intro v hv' idx; simp [m2, m1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv')]
    · intro v idx; simp [m2, m1]

/-! ### 4. Point Insert / Delete (`updLeafSegSlotStmt`) in `O(K)` Operations -/

theorem seg_node_ne_of_height_ne {K r₁ r₂ off₁ off₂ : ℕ}
    (hr₁ : r₁ ≤ K) (hr₂ : r₂ ≤ K) (hr_ne : r₁ ≠ r₂)
    (ho₁ : off₁ < 2 ^ (K - r₁)) (ho₂ : off₂ < 2 ^ (K - r₂)) :
    2 ^ (K - r₁) + off₁ ≠ 2 ^ (K - r₂) + off₂ := by
  rcases lt_trichotomy r₁ r₂ with hlt | rfl | hgt
  · have hle : 2 ^ (K - r₂ + 1) ≤ 2 ^ (K - r₁) :=
      Nat.pow_le_pow_right (by decide) (by omega)
    have hlt2 : 2 ^ (K - r₂) + off₂ < 2 ^ (K - r₂ + 1) := by rw [pow_succ']; omega
    omega
  · exact absurd rfl hr_ne
  · have hle : 2 ^ (K - r₁ + 1) ≤ 2 ^ (K - r₂) :=
      Nat.pow_le_pow_right (by decide) (by omega)
    have hlt1 : 2 ^ (K - r₁) + off₁ < 2 ^ (K - r₁ + 1) := by rw [pow_succ']; omega
    omega

theorem not_in_dyadic_of_div_ne {r off h : ℕ} (hne : off ≠ h / 2 ^ r) :
    ¬ (off * 2 ^ r ≤ h ∧ h < (off + 1) * 2 ^ r) := by
  rintro ⟨h1, h2⟩
  have hpos : 0 < 2 ^ r := Nat.pos_of_ne_zero (by positivity)
  have hle : off ≤ h / 2 ^ r := (Nat.le_div_iff_mul_le hpos).mpr h1
  have hlt : h / 2 ^ r < off + 1 := (Nat.div_lt_iff_lt_mul hpos).mpr h2
  omega

def combineSegChildrenStmt : ArithRAMStmt :=
  seqList [
    .writeWordLocal 28 (.lit 11) (.add (.readLocal 28 (.lit 7)) (.readLocal 28 (.lit 9))),
    .ite (.intEq (.readLocal 28 (.lit 7)) (.lit 0))
      (seqList [
        .writeWordLocal 28 (.lit 12) (.readLocal 28 (.lit 10)),
        .writeRealLocal 28 (.lit 3) (.readRealLocal 28 (.lit 2))
      ])
      (.ite (.intEq (.readLocal 28 (.lit 9)) (.lit 0))
        (seqList [
          .writeWordLocal 28 (.lit 12) (.readLocal 28 (.lit 8)),
          .writeRealLocal 28 (.lit 3) (.readRealLocal 28 (.lit 1))
        ])
        (.ite (.realLt (.readRealLocal 28 (.lit 1)) (.readRealLocal 28 (.lit 2)))
          (seqList [
            .writeWordLocal 28 (.lit 12) (.readLocal 28 (.lit 10)),
            .writeRealLocal 28 (.lit 3) (.readRealLocal 28 (.lit 2))
          ])
          (seqList [
            .writeWordLocal 28 (.lit 12) (.readLocal 28 (.lit 8)),
            .writeRealLocal 28 (.lit 3) (.readRealLocal 28 (.lit 1))
          ])))
  ]

/-- Single bottom-up parent recomputation step in `updLeafSegSlotStmt`:
`28[20] = s`, `28[2] = gen`, `28[3] = u` (child); sets `p := u / 2` in `28[3]`, reads left `2*p`
and right `2*p + 1`, and writes `(gen, cntP, mhP, msqP)` to `s * W + p`. -/
def updParentStepStmt (K M_box : ℕ) : ArithRAMStmt :=
  let W_lit : IntExpr := .lit ((2 ^ (K + 1) : ℕ) : ℤ)
  seqList [
    -- 28[3] := 28[3] / 2 (parent p)
    .writeWordLocal 28 (.lit 3) (.div (.readLocal 28 (.lit 3)) (.lit 2)),
    -- 28[5] := s * W + 2 * p (baseL), 28[6] := baseL + 1 (baseR), 28[4] := s * W + p (baseP)
    .writeWordLocal 28 (.lit 5)
      (.add (.mul (.readLocal 28 (.lit 20)) W_lit) (.mul (.lit 2) (.readLocal 28 (.lit 3)))),
    .writeWordLocal 28 (.lit 6) (.add (.readLocal 28 (.lit 5)) (.lit 1)),
    .writeWordLocal 28 (.lit 4)
      (.add (.mul (.readLocal 28 (.lit 20)) W_lit) (.readLocal 28 (.lit 3))),
    -- Read left child into (28[7]=cntL, 28[8]=mhL, r28[1]=msqL)
    .ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2)))
      (seqList [
        .writeWordLocal 28 (.lit 7) (.readHeap 9 (.readLocal 28 (.lit 5))),
        .writeWordLocal 28 (.lit 8) (.readHeap 10 (.readLocal 28 (.lit 5))),
        .writeRealLocal 28 (.lit 1) (.readRealHeap 8 (.readLocal 28 (.lit 5)))
      ])
      (seqList [
        .writeWordLocal 28 (.lit 7) (.lit 0),
        .writeWordLocal 28 (.lit 8) (.lit 0),
        .writeRealLocal 28 (.lit 1) (.ofInt (.lit 0))
      ]),
    -- Read right child into (28[9]=cntR, 28[10]=mhR, r28[2]=msqR)
    .ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 6))) (.readLocal 28 (.lit 2)))
      (seqList [
        .writeWordLocal 28 (.lit 9) (.readHeap 9 (.readLocal 28 (.lit 6))),
        .writeWordLocal 28 (.lit 10) (.readHeap 10 (.readLocal 28 (.lit 6))),
        .writeRealLocal 28 (.lit 2) (.readRealHeap 8 (.readLocal 28 (.lit 6)))
      ])
      (seqList [
        .writeWordLocal 28 (.lit 9) (.lit 0),
        .writeWordLocal 28 (.lit 10) (.lit 0),
        .writeRealLocal 28 (.lit 2) (.ofInt (.lit 0))
      ]),
    combineSegChildrenStmt,
    -- Write parent to heap tables 8, 9, 10 (word) and 8 (real)
    boxWriteW M_box 8 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 2)),
    boxWriteW M_box 9 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 11)),
    boxWriteW M_box 10 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 12)),
    boxWriteR M_box 8 (.readLocal 28 (.lit 4)) (.readRealLocal 28 (.lit 3))
  ]

/-- Point insert (`28[22] = 1`) or delete (`28[22] = 0`) for handle `h = 28[21] < 2^K` in slot
`s = 28[20]` with leaf squared-radius `rSq = r28[20]`. -/
def updLeafSegSlotStmt (K M_box : ℕ) : ArithRAMStmt :=
  let W_lit : IntExpr := .lit ((2 ^ (K + 1) : ℕ) : ℤ)
  let leafBase : IntExpr := .lit ((2 ^ K : ℕ) : ℤ)
  seqList [
    .writeWordLocal 28 (.lit 2) (.readHeap 5 (.readLocal 28 (.lit 20))),
    .writeWordLocal 28 (.lit 3) (.add leafBase (.readLocal 28 (.lit 21))),
    .writeWordLocal 28 (.lit 4)
      (.add (.mul (.readLocal 28 (.lit 20)) W_lit) (.readLocal 28 (.lit 3))),
    boxWriteW M_box 8 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 2)),
    boxWriteW M_box 9 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 22)),
    boxWriteW M_box 10 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 21)),
    boxWriteR M_box 8 (.readLocal 28 (.lit 4)) (.readRealLocal 28 (.lit 20)),
    .repeatN (.lit (K : ℤ)) (updParentStepStmt K M_box)
  ]

theorem boxSafe_updParentStepStmt {T_max M_box : ℕ} (hT : 11 ≤ T_max) (K : ℕ) :
    BoxSafeInner T_max M_box (updParentStepStmt K M_box) := by
  unfold updParentStepStmt
  apply boxSafeInner_seqList
  intro st hst
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_) <;> {
      intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact .writeWordLocal _ _ _
      · exact .writeRealLocal _ _ _ }
  · refine .ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_) <;> {
      intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact .writeWordLocal _ _ _
      · exact .writeRealLocal _ _ _ }
  · unfold combineSegChildrenStmt
    refine .seq (.writeWordLocal _ _ _) (.ite _ ?_ (.ite _ ?_ (.ite _ ?_ ?_))) <;> {
      apply boxSafeInner_seqList
      intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact .writeRealLocal _ _ _ }
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxR (by omega) _ _

theorem boxSafe_updLeafSegSlotStmt {T_max M_box : ℕ} (hT : 11 ≤ T_max) (K : ℕ) :
    BoxSafeInner T_max M_box (updLeafSegSlotStmt K M_box) := by
  unfold updLeafSegSlotStmt
  apply boxSafeInner_seqList
  intro st hst
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxR (by omega) _ _
  · exact .repeatN _ (boxSafe_updParentStepStmt hT K)

private theorem exec_readSegChildHelper {d K : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (idxBase idxCnt idxMh idxMsq : ℤ)
    {s r off : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    (hDiff : idxBase ≠ idxCnt ∧ idxBase ≠ idxMh ∧ idxMh ≠ idxCnt)
    (hGen : wReadL 1 mem 28 2 = wRead mem 5 (s : ℤ))
    (hBase : wReadL 1 mem 28 idxBase = ((s * 2 ^ (K + 1) + (2 ^ (K - r) + off) : ℕ) : ℤ))
    (hNode : EncSegNode K mem s r off S fSq) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 1 inp
        (.ite (.intEq (.readHeap 8 (.readLocal 28 (.lit idxBase))) (.readLocal 28 (.lit 2)))
          (seqList [
            .writeWordLocal 28 (.lit idxCnt) (.readHeap 9 (.readLocal 28 (.lit idxBase))),
            .writeWordLocal 28 (.lit idxMh) (.readHeap 10 (.readLocal 28 (.lit idxBase))),
            .writeRealLocal 28 (.lit idxMsq) (.readRealHeap 8 (.readLocal 28 (.lit idxBase)))
          ])
          (seqList [
            .writeWordLocal 28 (.lit idxCnt) (.lit 0),
            .writeWordLocal 28 (.lit idxMh) (.lit 0),
            .writeRealLocal 28 (.lit idxMsq) (.ofInt (.lit 0))
          ]))
        mem m' 30 ∧
      wReadL 1 m' 28 idxCnt = ((segSubSet S r off).card : ℤ) ∧
      ((segSubSet S r off).Nonempty →
        ∃ mh ∈ segSubSet S r off,
          wReadL 1 m' 28 idxMh = (mh : ℤ) ∧
          rReadL 1 m' 28 idxMsq = fSq mh ∧
          ∀ x ∈ segSubSet S r off, fSq x ≤ fSq mh) ∧
      (∀ t i, wRead m' t i = wRead mem t i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) ∧
      (∀ i, i ≠ idxCnt → i ≠ idxMh → wReadL 1 m' 28 i = wReadL 1 mem 28 i) ∧
      (∀ i, i ≠ idxMsq → rReadL 1 m' 28 i = rReadL 1 mem 28 i) ∧
      (∀ v, v ≠ 28 → ∀ i, wReadL 1 m' v i = wReadL 1 mem v i) ∧
      (∀ v, v ≠ 28 → ∀ i, rReadL 1 m' v i = rReadL 1 mem v i) := by
  let bIdx : ℤ := ((s * 2 ^ (K + 1) + (2 ^ (K - r) + off) : ℕ) : ℤ)
  rcases hDiff with ⟨hbc, hbm, hmc⟩
  by_cases hv : wRead mem 8 bIdx = wRead mem 5 (s : ℤ)
  · have hc_t : cValAt 1 inp mem
        (.intEq (.readHeap 8 (.readLocal 28 (.lit idxBase))) (.readLocal 28 (.lit 2))) = true := by
      simp only [cValAt_intEq, iValAt_readHeap, iValAt_readLocal, iValAt_lit, hBase, hGen, decide_eq_true_eq]
      exact hv
    let m1 := wWriteL 1 mem 28 idxCnt (wRead mem 9 bIdx)
    let m2 := wWriteL 1 m1 28 idxMh (wRead mem 10 bIdx)
    let m3 := rWriteL 1 m2 28 idxMsq (rRead mem 8 bIdx)
    have hb1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit idxCnt) (.readHeap 9 (.readLocal 28 (.lit idxBase)))) mem m1 6 :=
      DetExecAt.writeWordLocal 1 inp mem 28 (.lit idxCnt) _ rfl (by simp [hBase, bIdx]) (by simp [intExprOps, realExprOps, condExprOps])
    have hb2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit idxMh) (.readHeap 10 (.readLocal 28 (.lit idxBase)))) m1 m2 6 :=
      DetExecAt.writeWordLocal 1 inp m1 28 (.lit idxMh) _ rfl
        (by simp [m1, hBase, bIdx, wReadL_wWriteL_of_ne 1 _ _ (Or.inr hbc)]) (by simp [intExprOps, realExprOps, condExprOps])
    have hb3 : DetExecAt 1 inp (.writeRealLocal 28 (.lit idxMsq) (.readRealHeap 8 (.readLocal 28 (.lit idxBase)))) m2 m3 6 :=
      DetExecAt.writeRealLocal 1 inp m2 28 (.lit idxMsq) _ rfl
        (by simp [m2, m1, hBase, bIdx, rRead_wWriteL,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr hbm), wReadL_wWriteL_of_ne 1 _ _ (Or.inr hbc)]) (by simp [intExprOps, realExprOps, condExprOps])
    refine ⟨m3, (DetExecAt.ite_true hc_t (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) (hb1.seq (hb2.seq hb3))).mono_cost (by omega), ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · have heff := hNode.1
      simp only [effSegCnt, bIdx, hv, ↓reduceIte] at heff
      simp only [m3, m2, m1, wReadL_rWriteL, wReadL_wWriteL_eq]
      rw [if_neg (fun h => hmc h.2.symm)]
      exact heff
    · intro hne
      rcases hNode.2 hne with ⟨_, mh, hmh, hm10, hmr8, hmax⟩
      refine ⟨mh, hmh, ?_, ?_, hmax⟩
      · simp only [m3, m2, wReadL_rWriteL, wReadL_wWriteL_self]; exact hm10
      · simp only [m3, rReadL_rWriteL_self]; exact hmr8
    · intro t i; simp [m3, m2, m1, wRead_rWriteL]
    · intro t i; simp [m3, m2, m1, rRead_rWriteL]
    · intro i hic him; simp [m3, m2, m1, wReadL_rWriteL,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr him), wReadL_wWriteL_of_ne 1 _ _ (Or.inr hic)]
    · intro i hi; simp [m3, m2, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inr hi)]
    · intro v hv' i; simp [m3, m2, m1, wReadL_rWriteL, hv']
    · intro v hv' i; simp [m3, m2, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inl hv')]
  · have hc_f : cValAt 1 inp mem
        (.intEq (.readHeap 8 (.readLocal 28 (.lit idxBase))) (.readLocal 28 (.lit 2))) = false := by
      simp only [cValAt_intEq, iValAt_readHeap, iValAt_readLocal, iValAt_lit, hBase, hGen, decide_eq_false_iff_not]
      exact hv
    let m1 := wWriteL 1 mem 28 idxCnt 0
    let m2 := wWriteL 1 m1 28 idxMh 0
    let m3 := rWriteL 1 m2 28 idxMsq 0
    have hb1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit idxCnt) (.lit 0)) mem m1 4 :=
      DetExecAt.writeWordLocal 1 inp mem 28 (.lit idxCnt) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
    have hb2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit idxMh) (.lit 0)) m1 m2 4 :=
      DetExecAt.writeWordLocal 1 inp m1 28 (.lit idxMh) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
    have hb3 : DetExecAt 1 inp (.writeRealLocal 28 (.lit idxMsq) (.ofInt (.lit 0))) m2 m3 5 :=
      DetExecAt.writeRealLocal 1 inp m2 28 (.lit idxMsq) _ rfl (by simp) (by simp [intExprOps, realExprOps, condExprOps])
    refine ⟨m3, (DetExecAt.ite_false hc_f (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) (hb1.seq (hb2.seq hb3))).mono_cost (by omega), ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · have heff := hNode.1
      simp only [effSegCnt, bIdx, hv, ↓reduceIte] at heff
      simp [m3, m2, m1, wReadL_rWriteL, wReadL_wWriteL_of_ne 1 _ _ (Or.inr hmc.symm), ← heff]
    · intro hne; exact False.elim (hv (hNode.2 hne).1)
    · intro t i; simp [m3, m2, m1, wRead_rWriteL]
    · intro t i; simp [m3, m2, m1, rRead_rWriteL]
    · intro i hic him; simp [m3, m2, m1, wReadL_rWriteL,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr him), wReadL_wWriteL_of_ne 1 _ _ (Or.inr hic)]
    · intro i hi; simp [m3, m2, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inr hi)]
    · intro v hv' i; simp [m3, m2, m1, wReadL_rWriteL, hv']
    · intro v hv' i; simp [m3, m2, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inl hv')]

private theorem exec_combineSegChildrenHelper {d : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {S : Finset ℕ} {fSq : ℕ → ℝ} {r off : ℕ}
    (hcntL : wReadL 1 mem 28 7 = ((segSubSet S r (2 * off)).card : ℤ))
    (hcntR : wReadL 1 mem 28 9 = ((segSubSet S r (2 * off + 1)).card : ℤ))
    (hmaxL : (segSubSet S r (2 * off)).Nonempty →
      ∃ mh ∈ segSubSet S r (2 * off),
        wReadL 1 mem 28 8 = (mh : ℤ) ∧ rReadL 1 mem 28 1 = fSq mh ∧
        ∀ x ∈ segSubSet S r (2 * off), fSq x ≤ fSq mh)
    (hmaxR : (segSubSet S r (2 * off + 1)).Nonempty →
      ∃ mh ∈ segSubSet S r (2 * off + 1),
        wReadL 1 mem 28 10 = (mh : ℤ) ∧ rReadL 1 mem 28 2 = fSq mh ∧
        ∀ x ∈ segSubSet S r (2 * off + 1), fSq x ≤ fSq mh) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 1 inp combineSegChildrenStmt mem m' 55 ∧
      wReadL 1 m' 28 11 = ((segSubSet S (r + 1) off).card : ℤ) ∧
      ((segSubSet S (r + 1) off).Nonempty →
        ∃ mh ∈ segSubSet S (r + 1) off,
          wReadL 1 m' 28 12 = (mh : ℤ) ∧
          rReadL 1 m' 28 3 = fSq mh ∧
          ∀ x ∈ segSubSet S (r + 1) off, fSq x ≤ fSq mh) ∧
      (∀ t i, wRead m' t i = wRead mem t i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) ∧
      (∀ i, i ≠ 11 → i ≠ 12 → wReadL 1 m' 28 i = wReadL 1 mem 28 i) ∧
      (∀ v, v ≠ 28 → ∀ i, wReadL 1 m' v i = wReadL 1 mem v i) ∧
      (∀ v, v ≠ 28 → ∀ i, rReadL 1 m' v i = rReadL 1 mem v i) := by
  classical
  let m1 := wWriteL 1 mem 28 11 (wReadL 1 mem 28 7 + wReadL 1 mem 28 9)
  have hs1 : DetExecAt 1 inp
      (.writeWordLocal 28 (.lit 11) (.add (.readLocal 28 (.lit 7)) (.readLocal 28 (.lit 9)))) mem m1 8 :=
    DetExecAt.writeWordLocal 1 inp mem 28 (.lit 11) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
  have hcardP : wReadL 1 mem 28 7 + wReadL 1 mem 28 9 = ((segSubSet S (r + 1) off).card : ℤ) := by
    rw [hcntL, hcntR, segSubSet_succ_card]; push_cast; rfl
  let takeR : ArithRAMStmt := seqList [
    .writeWordLocal 28 (.lit 12) (.readLocal 28 (.lit 10)),
    .writeRealLocal 28 (.lit 3) (.readRealLocal 28 (.lit 2)) ]
  let takeL : ArithRAMStmt := seqList [
    .writeWordLocal 28 (.lit 12) (.readLocal 28 (.lit 8)),
    .writeRealLocal 28 (.lit 3) (.readRealLocal 28 (.lit 1)) ]
  let mR := rWriteL 1 (wWriteL 1 m1 28 12 (wReadL 1 mem 28 10)) 28 3 (rReadL 1 mem 28 2)
  let mL := rWriteL 1 (wWriteL 1 m1 28 12 (wReadL 1 mem 28 8)) 28 3 (rReadL 1 mem 28 1)
  have hexR : DetExecAt 1 inp takeR m1 mR 12 := by
    have h1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 12) (.readLocal 28 (.lit 10))) m1
        (wWriteL 1 m1 28 12 (wReadL 1 mem 28 10)) 6 :=
      DetExecAt.writeWordLocal 1 inp m1 28 (.lit 12) _ rfl
        (by simp [m1, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (10 : ℤ) ≠ 11))]) (by simp [intExprOps, realExprOps, condExprOps])
    have h2 : DetExecAt 1 inp (.writeRealLocal 28 (.lit 3) (.readRealLocal 28 (.lit 2)))
        (wWriteL 1 m1 28 12 (wReadL 1 mem 28 10)) mR 6 :=
      DetExecAt.writeRealLocal 1 inp _ 28 (.lit 3) _ rfl (by simp [m1]) (by simp [intExprOps, realExprOps, condExprOps])
    exact h1.seq h2
  have hexL : DetExecAt 1 inp takeL m1 mL 12 := by
    have h1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 12) (.readLocal 28 (.lit 8))) m1
        (wWriteL 1 m1 28 12 (wReadL 1 mem 28 8)) 6 :=
      DetExecAt.writeWordLocal 1 inp m1 28 (.lit 12) _ rfl
        (by simp [m1, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (8 : ℤ) ≠ 11))]) (by simp [intExprOps, realExprOps, condExprOps])
    have h2 : DetExecAt 1 inp (.writeRealLocal 28 (.lit 3) (.readRealLocal 28 (.lit 1)))
        (wWriteL 1 m1 28 12 (wReadL 1 mem 28 8)) mL 6 :=
      DetExecAt.writeRealLocal 1 inp _ 28 (.lit 3) _ rfl (by simp [m1]) (by simp [intExprOps, realExprOps, condExprOps])
    exact h1.seq h2
  by_cases hcL0 : (segSubSet S r (2 * off)).card = 0
  · have hc1 : cValAt 1 inp m1 (.intEq (.readLocal 28 (.lit 7)) (.lit 0)) = true := by
      simp [m1, hcntL, hcL0, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 11))]
    refine ⟨mR, (show DetExecAt 1 inp combineSegChildrenStmt mem mR 55 from
      (hs1.seq (DetExecAt.ite_true hc1 (C_c := 8) (by simp [condExprOps, intExprOps]) hexR)).mono_cost (by omega)), ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · simp [mR, m1, wReadL_rWriteL, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (11 : ℤ) ≠ 12)), hcardP]
    · intro hneP
      have hempL : segSubSet S r (2 * off) = ∅ := Finset.card_eq_zero.mp hcL0
      rw [segSubSet_succ_union, hempL, Finset.empty_union] at hneP
      rcases hmaxR hneP with ⟨mh, hmh, hm10, hmr2, hmax⟩
      refine ⟨mh, by rw [segSubSet_succ_union]; exact Finset.mem_union_right _ hmh,
        by simp [mR, wReadL_rWriteL, hm10], by simp [mR, hmr2], ?_⟩
      intro x hx
      rw [segSubSet_succ_union, hempL, Finset.empty_union] at hx
      exact hmax x hx
    · intro t i; simp [mR, m1, wRead_rWriteL]
    · intro t i; simp [mR, m1, rRead_rWriteL]
    · intro i h11 h12; simp [mR, m1, wReadL_rWriteL,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr h12), wReadL_wWriteL_of_ne 1 _ _ (Or.inr h11)]
    · intro v hv i; simp [mR, m1, wReadL_rWriteL, hv]
    · intro v hv i; simp [mR, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inl hv)]
  · have hc1 : cValAt 1 inp m1 (.intEq (.readLocal 28 (.lit 7)) (.lit 0)) = false := by
      simp [m1, hcntL, hcL0, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 11))]
    have hneL : (segSubSet S r (2 * off)).Nonempty := Finset.card_pos.mp (Nat.pos_of_ne_zero hcL0)
    rcases hmaxL hneL with ⟨mhL, hmhL, hm8, hmr1, hleL⟩
    by_cases hcR0 : (segSubSet S r (2 * off + 1)).card = 0
    · have hc2 : cValAt 1 inp m1 (.intEq (.readLocal 28 (.lit 9)) (.lit 0)) = true := by
        simp [m1, hcntR, hcR0, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 11))]
      refine ⟨mL, (show DetExecAt 1 inp combineSegChildrenStmt mem mL 55 from
        (hs1.seq (DetExecAt.ite_false hc1 (C_c := 8) (by simp [condExprOps, intExprOps])
          (DetExecAt.ite_true hc2 (C_c := 8) (by simp [condExprOps, intExprOps]) hexL))).mono_cost (by omega)), ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · simp [mL, m1, wReadL_rWriteL, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (11 : ℤ) ≠ 12)), hcardP]
      · intro _
        have hempR : segSubSet S r (2 * off + 1) = ∅ := Finset.card_eq_zero.mp hcR0
        refine ⟨mhL, by rw [segSubSet_succ_union]; exact Finset.mem_union_left _ hmhL,
          by simp [mL, wReadL_rWriteL, hm8], by simp [mL, hmr1], ?_⟩
        intro x hx
        rw [segSubSet_succ_union, hempR, Finset.union_empty] at hx
        exact hleL x hx
      · intro t i; simp [mL, m1, wRead_rWriteL]
      · intro t i; simp [mL, m1, rRead_rWriteL]
      · intro i h11 h12; simp [mL, m1, wReadL_rWriteL,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr h12), wReadL_wWriteL_of_ne 1 _ _ (Or.inr h11)]
      · intro v hv i; simp [mL, m1, wReadL_rWriteL, hv]
      · intro v hv i; simp [mL, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inl hv)]
    · have hc2 : cValAt 1 inp m1 (.intEq (.readLocal 28 (.lit 9)) (.lit 0)) = false := by
        simp [m1, hcntR, hcR0, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 11))]
      have hneR : (segSubSet S r (2 * off + 1)).Nonempty := Finset.card_pos.mp (Nat.pos_of_ne_zero hcR0)
      rcases hmaxR hneR with ⟨mhR, hmhR, hm10, hmr2, hleR⟩
      by_cases hltSq : fSq mhL < fSq mhR
      · have hc3 : cValAt 1 inp m1 (.realLt (.readRealLocal 28 (.lit 1)) (.readRealLocal 28 (.lit 2))) = true := by
          simp [m1, hmr1, hmr2, hltSq]
        refine ⟨mR, (show DetExecAt 1 inp combineSegChildrenStmt mem mR 55 from
          (hs1.seq (DetExecAt.ite_false hc1 (C_c := 8) (by simp [condExprOps, intExprOps])
            (DetExecAt.ite_false hc2 (C_c := 8) (by simp [condExprOps, intExprOps])
              (DetExecAt.ite_true hc3 (C_c := 10) (by simp [condExprOps, realExprOps, intExprOps]) hexR)))).mono_cost (by omega)), ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
        · simp [mR, m1, wReadL_rWriteL, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (11 : ℤ) ≠ 12)), hcardP]
        · intro _
          refine ⟨mhR, by rw [segSubSet_succ_union]; exact Finset.mem_union_right _ hmhR,
            by simp [mR, wReadL_rWriteL, hm10], by simp [mR, hmr2], ?_⟩
          intro x hx
          rw [segSubSet_succ_union, Finset.mem_union] at hx
          rcases hx with hxL | hxR
          · exact le_trans (hleL x hxL) (le_of_lt hltSq)
          · exact hleR x hxR
        · intro t i; simp [mR, m1, wRead_rWriteL]
        · intro t i; simp [mR, m1, rRead_rWriteL]
        · intro i h11 h12; simp [mR, m1, wReadL_rWriteL,
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr h12), wReadL_wWriteL_of_ne 1 _ _ (Or.inr h11)]
        · intro v hv i; simp [mR, m1, wReadL_rWriteL, hv]
        · intro v hv i; simp [mR, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inl hv)]
      · have hc3 : cValAt 1 inp m1 (.realLt (.readRealLocal 28 (.lit 1)) (.readRealLocal 28 (.lit 2))) = false := by
          simp [m1, hmr1, hmr2, hltSq]
        refine ⟨mL, (show DetExecAt 1 inp combineSegChildrenStmt mem mL 55 from
          (hs1.seq (DetExecAt.ite_false hc1 (C_c := 8) (by simp [condExprOps, intExprOps])
            (DetExecAt.ite_false hc2 (C_c := 8) (by simp [condExprOps, intExprOps])
              (DetExecAt.ite_false hc3 (C_c := 10) (by simp [condExprOps, realExprOps, intExprOps]) hexL)))).mono_cost (by omega)), ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
        · simp [mL, m1, wReadL_rWriteL, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (11 : ℤ) ≠ 12)), hcardP]
        · intro _
          refine ⟨mhL, by rw [segSubSet_succ_union]; exact Finset.mem_union_left _ hmhL,
            by simp [mL, wReadL_rWriteL, hm8], by simp [mL, hmr1], ?_⟩
          intro x hx
          rw [segSubSet_succ_union, Finset.mem_union] at hx
          rcases hx with hxL | hxR
          · exact hleL x hxL
          · exact le_trans (hleR x hxR) (not_lt.mp hltSq)
        · intro t i; simp [mL, m1, wRead_rWriteL]
        · intro t i; simp [mL, m1, rRead_rWriteL]
        · intro i h11 h12; simp [mL, m1, wReadL_rWriteL,
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr h12), wReadL_wWriteL_of_ne 1 _ _ (Or.inr h11)]
        · intro v hv i; simp [mL, m1, wReadL_rWriteL, hv]
        · intro v hv i; simp [mL, m1, rReadL_rWriteL_of_ne 1 _ _ (Or.inl hv)]

private theorem EncSegNode.congr_other_idx {K : ℕ} {m₁ m₂ : ArithRAMMemory}
    {s r off u_wr : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    (h : EncSegNode K m₁ s r off S fSq)
    (hne : 2 ^ (K - r) + off ≠ u_wr)
    (hg : wRead m₂ 5 (s : ℤ) = wRead m₁ 5 (s : ℤ))
    (hw8 : ∀ i : ℤ, i ≠ ((s * 2 ^ (K + 1) + u_wr : ℕ) : ℤ) → wRead m₂ 8 i = wRead m₁ 8 i)
    (hw9 : ∀ i : ℤ, i ≠ ((s * 2 ^ (K + 1) + u_wr : ℕ) : ℤ) → wRead m₂ 9 i = wRead m₁ 9 i)
    (hw10 : ∀ i : ℤ, i ≠ ((s * 2 ^ (K + 1) + u_wr : ℕ) : ℤ) → wRead m₂ 10 i = wRead m₁ 10 i)
    (hr8 : ∀ i : ℤ, i ≠ ((s * 2 ^ (K + 1) + u_wr : ℕ) : ℤ) → rRead m₂ 8 i = rRead m₁ 8 i) :
    EncSegNode K m₂ s r off S fSq := by
  have hne_z : ((s * 2 ^ (K + 1) + (2 ^ (K - r) + off) : ℕ) : ℤ) ≠
      ((s * 2 ^ (K + 1) + u_wr : ℕ) : ℤ) := by omega
  dsimp only [EncSegNode] at h ⊢
  have heff : effSegCnt K m₂ s (2 ^ (K - r) + off) = effSegCnt K m₁ s (2 ^ (K - r) + off) := by
    simp only [effSegCnt, hw8 _ hne_z, hg, hw9 _ hne_z]
  refine ⟨heff.trans h.1, fun hne_S => ?_⟩
  rcases h.2 hne_S with ⟨hv, mh, hmh, hm10, hmr8, hmax⟩
  exact ⟨by rw [hw8 _ hne_z, hg]; exact hv, mh, hmh,
    by rw [hw10 _ hne_z]; exact hm10, by rw [hr8 _ hne_z]; exact hmr8, hmax⟩

theorem exec_updLeafSegSlotStmt {d K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s h : ℕ} {ins : Bool} {rSq : ℝ}
    {S : Finset ℕ} {fSq fSq' : ℕ → ℝ}
    (hs : s < NumSlots) (hh : h < 2 ^ K)
    (hMs : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (hs_reg : wReadL 1 mem 28 20 = (s : ℤ))
    (hh_reg : wReadL 1 mem 28 21 = (h : ℤ))
    (hins_reg : wReadL 1 mem 28 22 = (if ins then 1 else 0))
    (hrSq_reg : rReadL 1 mem 28 20 = rSq)
    (hfSq_h : ins = true → fSq' h = rSq)
    (hfSq_other : ∀ x ∈ S, x ≠ h → fSq' x = fSq x)
    (hgen : SegGenBound K NumSlots mem)
    (hEnc : EncSegSlot K mem s S fSq) :
    let S' : Finset ℕ := if ins then insert h S else S.erase h
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (updLeafSegSlotStmt K M_box) mem mem' (220 * (K + 1)) ∧
      SegGenBound K NumSlots mem' ∧
      EncSegSlot K mem' s S' fSq' ∧
      (∀ s' < NumSlots, s' ≠ s → ∀ S₁ fSq₁,
        EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K mem' s' S₁ fSq₁) ∧
      (∀ t : ℕ, t ≠ 8 → t ≠ 9 → t ≠ 10 → ∀ idx : ℤ, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t : ℕ, t ≠ 8 → ∀ idx : ℤ, rRead mem' t idx = rRead mem t idx) ∧
      (∀ v : ℕ, v ≠ 28 → ∀ idx : ℤ, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v : ℕ, v ≠ 28 → ∀ idx : ℤ, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  intro S'
  set gen := wRead mem 5 (s : ℤ)
  have hgen_lt_next : gen < wRead mem 1 3 := hgen.2.1 s hs
  let u₀ : ℕ := 2 ^ K + h
  have hu₀_lt : u₀ < 2 ^ (K + 1) := by dsimp [u₀]; rw [pow_succ']; omega
  let base₀ : ℤ := ((s * 2 ^ (K + 1) + u₀ : ℕ) : ℤ)
  have hbase₀_lt : base₀ < (M_box : ℤ) := by
    have : s * 2 ^ (K + 1) + u₀ < NumSlots * 2 ^ (K + 1) := by
      calc s * 2 ^ (K + 1) + u₀ < s * 2 ^ (K + 1) + 2 ^ (K + 1) := by omega
        _ = (s + 1) * 2 ^ (K + 1) := by ring
        _ ≤ NumSlots * 2 ^ (K + 1) := Nat.mul_le_mul_right _ hs
    dsimp [base₀]; exact_mod_cast lt_of_lt_of_le this hMs
  -- Unchanged nodes for r, off where h is outside [off * 2^r, (off + 1) * 2^r)
  have hUnch_init : ∀ r ≤ K, ∀ off < 2 ^ (K - r), off ≠ h / 2 ^ r →
      EncSegNode K mem s r off S' fSq' := by
    intro r hr off hoff hne_div
    have hout := not_in_dyadic_of_div_ne hne_div
    have hsub_eq : segSubSet S' r off = segSubSet S r off := by
      dsimp [S']
      cases ins
      · exact segSubSet_erase_of_not_in_range hout
      · exact segSubSet_insert_of_not_in_range hout
    have hn := hEnc.2.2 r hr off hoff
    dsimp only [EncSegNode] at hn ⊢
    rw [hsub_eq]
    refine ⟨hn.1, fun hne_S => ?_⟩
    rcases hn.2 hne_S with ⟨hv, mh, hmh, hm10, hmr8, hmax⟩
    have hmh_ne : mh ≠ h := by
      rintro rfl
      exact hout ⟨(mem_segSubSet.mp hmh).2.1, (mem_segSubSet.mp hmh).2.2⟩
    have hmh_S : mh ∈ S := (mem_segSubSet.mp hmh).1
    refine ⟨hv, mh, hmh, hm10, by rw [hfSq_other mh hmh_S hmh_ne]; exact hmr8, fun x hx => ?_⟩
    have hx_ne : x ≠ h := by
      rintro rfl
      exact hout ⟨(mem_segSubSet.mp hx).2.1, (mem_segSubSet.mp hx).2.2⟩
    rw [hfSq_other x (mem_segSubSet.mp hx).1 hx_ne, hfSq_other mh hmh_S hmh_ne]
    exact hmax x hx
  -- Execute leaf setup before repeatN K
  let m1 := wWriteL 1 mem 28 2 gen
  let m2 := wWriteL 1 m1 28 3 (u₀ : ℤ)
  let m3 := wWriteL 1 m2 28 4 base₀
  let m4 := wWrite m3 8 base₀ gen
  let m5 := wWrite m4 9 base₀ (if ins then 1 else 0)
  let m6 := wWrite m5 10 base₀ (h : ℤ)
  let m7 := rWrite m6 8 base₀ rSq
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 2) (.readHeap 5 (.readLocal 28 (.lit 20)))) mem m1 8 :=
    DetExecAt.writeWordLocal 1 inp mem 28 (.lit 2) _ rfl (by simp [hs_reg, gen]) (by simp [intExprOps, realExprOps, condExprOps])
  have hs2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 3) (.add (.lit ((2 ^ K : ℕ) : ℤ)) (.readLocal 28 (.lit 21)))) m1 m2 8 :=
    DetExecAt.writeWordLocal 1 inp m1 28 (.lit 3) _ rfl
      (by simp [m1, hh_reg, u₀, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 2))])
      (by simp [intExprOps, realExprOps, condExprOps])
  have hs3 : DetExecAt 1 inp
      (.writeWordLocal 28 (.lit 4) (.add (.mul (.readLocal 28 (.lit 20)) (.lit ((2 ^ (K + 1) : ℕ) : ℤ))) (.readLocal 28 (.lit 3))))
      m2 m3 10 :=
    DetExecAt.writeWordLocal 1 inp m2 28 (.lit 4) _ rfl
      (by simp [m2, m1, hs_reg, base₀,
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 2))])
      (by simp [intExprOps, realExprOps, condExprOps])
  have hs4 : DetExecAt 1 inp (boxWriteW M_box 8 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 2))) m3 m4 14 :=
    exec_boxWriteW inp m3 _ _ (by simp [m3]) (by dsimp [base₀]; positivity) hbase₀_lt
      (by simp [m3, m2, m1, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 4)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3))]) (by simp [intExprOps, realExprOps, condExprOps])
  have hs5 : DetExecAt 1 inp (boxWriteW M_box 9 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 22))) m4 m5 14 :=
    exec_boxWriteW inp m4 _ _ (by simp [m4, m3]) (by dsimp [base₀]; positivity) hbase₀_lt
      (by simp [m4, m3, m2, m1, hins_reg,
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (22 : ℤ) ≠ 4)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (22 : ℤ) ≠ 3)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (22 : ℤ) ≠ 2))]) (by simp [intExprOps, realExprOps, condExprOps])
  have hs6 : DetExecAt 1 inp (boxWriteW M_box 10 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 21))) m5 m6 14 :=
    exec_boxWriteW inp m5 _ _ (by simp [m5, m4, m3]) (by dsimp [base₀]; positivity) hbase₀_lt
      (by simp [m5, m4, m3, m2, m1, hh_reg,
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 4)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 3)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 2))]) (by simp [intExprOps, realExprOps, condExprOps])
  have hs7 : DetExecAt 1 inp (boxWriteR M_box 8 (.readLocal 28 (.lit 4)) (.readRealLocal 28 (.lit 20))) m6 m7 14 :=
    exec_boxWriteR inp m6 _ _ (by simp [m6, m5, m4, m3]) (by dsimp [base₀]; positivity) hbase₀_lt
      (by simp [m6, m5, m4, m3, m2, m1, hrSq_reg]) (by simp [intExprOps, realExprOps, condExprOps])
  -- Loop invariant for repeatN K
  let Inv : ℕ → ArithRAMMemory → Prop := fun step m =>
    SegGenBound K NumSlots m ∧
    wReadL 1 m 28 20 = (s : ℤ) ∧
    wReadL 1 m 28 2 = gen ∧
    wReadL 1 m 28 3 = ((2 ^ (K - step) + h / 2 ^ step : ℕ) : ℤ) ∧
    (∀ r ≤ step, ∀ off < 2 ^ (K - r), EncSegNode K m s r off S' fSq') ∧
    (∀ r, step < r → r ≤ K → ∀ off < 2 ^ (K - r), off ≠ h / 2 ^ r → EncSegNode K m s r off S' fSq') ∧
    (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → ∀ idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t, t ≠ 8 → ∀ idx, rRead m t idx = rRead mem t idx) ∧
    (∀ s' < NumSlots, s' ≠ s → ∀ u < 2 ^ (K + 1),
      wRead m 8 ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) = wRead mem 8 ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) ∧
      wRead m 9 ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) = wRead mem 9 ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) ∧
      wRead m 10 ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) = wRead mem 10 ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) ∧
      rRead m 8 ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) = rRead mem 8 ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ)) ∧
    (∀ v, v ≠ 28 → ∀ idx, wReadL 1 m v idx = wReadL 1 mem v idx ∧ rReadL 1 m v idx = rReadL 1 mem v idx)
  have hInv0 : Inv 0 m7 := by
    have hw_other : ∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → ∀ idx, wRead m7 t idx = wRead mem t idx := by
      intro t h8 h9 h10 idx
      simp [m7, m6, m5, m4, m3, m2, m1, wRead_rWrite,
        wRead_wWrite_of_ne _ _ (Or.inl h10), wRead_wWrite_of_ne _ _ (Or.inl h9),
        wRead_wWrite_of_ne _ _ (Or.inl h8)]
    have hw8_other : ∀ idx, idx ≠ base₀ → wRead m7 8 idx = wRead mem 8 idx := by
      intro idx hi
      simp [m7, m6, m5, m4, m3, m2, m1, wRead_rWrite,
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 10)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 9)),
        wRead_wWrite_of_ne _ _ (Or.inr hi)]
    have hw9_other : ∀ idx, idx ≠ base₀ → wRead m7 9 idx = wRead mem 9 idx := by
      intro idx hi
      simp [m7, m6, m5, m4, m3, m2, m1, wRead_rWrite,
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (9 : ℕ) ≠ 10)),
        wRead_wWrite_of_ne _ _ (Or.inr hi),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (9 : ℕ) ≠ 8))]
    have hw10_other : ∀ idx, idx ≠ base₀ → wRead m7 10 idx = wRead mem 10 idx := by
      intro idx hi
      simp [m7, m6, m5, m4, m3, m2, m1, wRead_rWrite,
        wRead_wWrite_of_ne _ _ (Or.inr hi),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (10 : ℕ) ≠ 9)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (10 : ℕ) ≠ 8))]
    have hr8_other : ∀ idx, idx ≠ base₀ → rRead m7 8 idx = rRead mem 8 idx := by
      intro idx hi
      simp [m7, m6, m5, m4, m3, m2, m1, rRead_rWrite_of_ne _ _ (Or.inr hi), rRead_wWrite, rRead_wWriteL]
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, hw_other, ?_, ?_, ?_⟩
    · refine ⟨by rw [hw_other 1 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide)]; exact hgen.1,
        fun s' hs' => by
          rw [hw_other 5 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide), hw_other 1 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide)]
          exact hgen.2.1 s' hs',
        fun s' hs' u hu => ?_⟩
      rw [hw_other 1 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide)]
      by_cases heq_idx : ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) = base₀
      · rw [heq_idx]
        simp [m7, m6, m5, m4, wRead_rWrite,
          wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 10)),
          wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 9)), hgen_lt_next]
      · rw [hw8_other _ heq_idx]; exact hgen.2.2 s' hs' u hu
    · simp [m7, m6, m5, m4, m3, m2, m1, wReadL_rWrite, hs_reg,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 4)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 2))]
    · simp [m7, m6, m5, m4, m3, m2, m1, wReadL_rWrite,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 4)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3))]
    · simp [m7, m6, m5, m4, m3, m2, wReadL_rWrite, u₀,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 4))]
    · intro r hr off hoff
      have hr0 : r = 0 := by omega
      subst hr0
      by_cases hoff_h : off = h
      · subst off
        dsimp only [EncSegNode]
        rw [Nat.sub_zero, segSubSet_zero]
        have hmem_S' : (h ∈ S') ↔ ins = true := by
          dsimp [S']; cases ins <;> simp
        have hw8_self : wRead m7 8 base₀ = gen := by
          simp [m7, m6, m5, m4, wRead_rWrite,
            wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 10)),
            wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 9))]
        have hw5_s : wRead m7 5 (s : ℤ) = gen := hw_other 5 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide) (s : ℤ)
        cases ins with
        | false =>
            have hnot : h ∉ S' := by simp [hmem_S']
            simp only [hnot, ↓reduceIte, Finset.card_empty, Nat.cast_zero]
            refine ⟨?_, fun hne => by simp at hne⟩
            dsimp only [effSegCnt]
            simp only [u₀, base₀, m7, m6, m5, m4, m3, m2, m1, wRead_rWrite, wRead_wWrite_eq, wRead_wWriteL, gen]
            simp
        | true =>
            have hin : h ∈ S' := by simp [hmem_S']
            simp only [hin, ↓reduceIte, Finset.card_singleton, Nat.cast_one]
            refine ⟨?_, fun _ => ⟨by simpa [u₀, base₀, hw5_s, gen] using hw8_self,
              h, Finset.mem_singleton_self h, ?_, ?_, fun x hx => ?_⟩⟩
            · dsimp only [effSegCnt]
              simp only [u₀, base₀, m7, m6, m5, m4, m3, m2, m1, wRead_rWrite, wRead_wWrite_eq, wRead_wWriteL, gen]
              simp
            · simp [u₀, base₀, m7, m6, wRead_rWrite]
            · simp [u₀, base₀, m7, hfSq_h rfl]
            · rw [Finset.mem_singleton.mp hx]
      · have hprev := hUnch_init 0 (Nat.zero_le K) off hoff (by simpa using hoff_h)
        exact hprev.congr_other_idx (by dsimp [u₀]; omega)
          (hw_other 5 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide) (s : ℤ))
          hw8_other hw9_other hw10_other hr8_other
    · intro r hr_pos hr_le off hoff hne_div
      have hne_u : 2 ^ (K - r) + off ≠ u₀ :=
        seg_node_ne_of_height_ne hr_le (Nat.zero_le K) (by omega) hoff (by simpa using hh)
      exact (hUnch_init r hr_le off hoff hne_div).congr_other_idx hne_u
        (hw_other 5 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide) (s : ℤ))
        hw8_other hw9_other hw10_other hr8_other
    · intro t ht8 idx
      simp [m7, m6, m5, m4, m3, m2, m1, rRead_rWrite_of_ne _ _ (Or.inl ht8), rRead_wWrite, rRead_wWriteL]
    · intro s' _ hne_s u hu
      have hne_b : ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) ≠ base₀ :=
        seg_base_ne_of_slot_ne hne_s hu hu₀_lt
      exact ⟨hw8_other _ hne_b, hw9_other _ hne_b, hw10_other _ hne_b, hr8_other _ hne_b⟩
    · intro v hv idx
      simp [m7, m6, m5, m4, m3, m2, m1, wReadL_rWrite, rReadL_rWrite,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv)]
  -- Step proof for repeatN K
  have hStep : ∀ step < K, ∀ m, Inv step m →
      ∃ m', DetExecAt 1 inp (updParentStepStmt K M_box) m m' 210 ∧ Inv (step + 1) m' := by
    intro step hstep_lt m hIm
    rcases hIm with ⟨hSg, hm20, hm2, hm3, hLe, hGt, hwO, hrO, hSlotO, hLocO⟩
    let p_off : ℕ := h / 2 ^ (step + 1)
    have hp_off_lt : p_off < 2 ^ (K - (step + 1)) := by
      dsimp [p_off]
      apply Nat.div_lt_of_lt_mul
      rw [← pow_add, show step + 1 + (K - (step + 1)) = K by omega]
      exact hh
    let p_u : ℕ := 2 ^ (K - (step + 1)) + p_off
    have hp_u_lt : p_u < 2 ^ (K + 1) := seg_node_lt_width (by omega) hp_off_lt
    have hdiv_eq : (2 ^ (K - step) + h / 2 ^ step) / 2 = p_u := by
      have hpow_step : 2 ^ (K - step) = 2 * 2 ^ (K - (step + 1)) := by
        rw [show K - step = K - (step + 1) + 1 by omega, pow_succ']
      have hdiv_h : (h / 2 ^ step) / 2 = p_off := by
        dsimp [p_off]; rw [Nat.div_div_eq_div_mul, pow_succ]
      rw [hpow_step, Nat.mul_add_div (by decide : 0 < 2), hdiv_h]
    have h2p_eq : 2 * p_u = 2 ^ (K - step) + 2 * p_off := by
      dsimp [p_u]
      rw [show K - step = K - (step + 1) + 1 by omega, pow_succ']
      ring
    have h2p1_eq : 2 * p_u + 1 = 2 ^ (K - step) + (2 * p_off + 1) := by omega
    let baseP : ℤ := ((s * 2 ^ (K + 1) + p_u : ℕ) : ℤ)
    let baseL : ℤ := ((s * 2 ^ (K + 1) + (2 ^ (K - step) + 2 * p_off) : ℕ) : ℤ)
    let baseR : ℤ := ((s * 2 ^ (K + 1) + (2 ^ (K - step) + (2 * p_off + 1)) : ℕ) : ℤ)
    have hbaseP_lt : baseP < (M_box : ℤ) := by
      have : s * 2 ^ (K + 1) + p_u < NumSlots * 2 ^ (K + 1) := by
        calc s * 2 ^ (K + 1) + p_u < s * 2 ^ (K + 1) + 2 ^ (K + 1) := by omega
          _ = (s + 1) * 2 ^ (K + 1) := by ring
          _ ≤ NumSlots * 2 ^ (K + 1) := Nat.mul_le_mul_right _ hs
      dsimp [baseP]; exact_mod_cast lt_of_lt_of_le this hMs
    -- First 4 local setup assignments in updParentStepStmt
    let ma1 := wWriteL 1 m 28 3 (p_u : ℤ)
    let ma2 := wWriteL 1 ma1 28 5 baseL
    let ma3 := wWriteL 1 ma2 28 6 baseR
    let ma4 := wWriteL 1 ma3 28 4 baseP
    have ha1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 3) (.div (.readLocal 28 (.lit 3)) (.lit 2))) m ma1 8 := by
      refine DetExecAt.writeWordLocal 1 inp m 28 (.lit 3) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
      simp only [iValAt_div, iValAt_readLocal, iValAt_lit, hm3]
      exact_mod_cast hdiv_eq
    have ha2 : DetExecAt 1 inp
        (.writeWordLocal 28 (.lit 5) (.add (.mul (.readLocal 28 (.lit 20)) (.lit ((2 ^ (K + 1) : ℕ) : ℤ))) (.mul (.lit 2) (.readLocal 28 (.lit 3)))))
        ma1 ma2 12 := by
      refine DetExecAt.writeWordLocal 1 inp ma1 28 (.lit 5) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
      simp only [ma1, iValAt_add, iValAt_mul, iValAt_readLocal, iValAt_lit,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)), hm20, wReadL_wWriteL_self]
      dsimp [baseL]; exact_mod_cast congrArg (s * 2 ^ (K + 1) + ·) h2p_eq
    have ha3 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 6) (.add (.readLocal 28 (.lit 5)) (.lit 1))) ma2 ma3 8 := by
      refine DetExecAt.writeWordLocal 1 inp ma2 28 (.lit 6) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
      simp only [ma2, iValAt_add, iValAt_readLocal, iValAt_lit, wReadL_wWriteL_self]
      dsimp [baseL, baseR]; omega
    have ha4 : DetExecAt 1 inp
        (.writeWordLocal 28 (.lit 4) (.add (.mul (.readLocal 28 (.lit 20)) (.lit ((2 ^ (K + 1) : ℕ) : ℤ))) (.readLocal 28 (.lit 3))))
        ma3 ma4 10 := by
      refine DetExecAt.writeWordLocal 1 inp ma3 28 (.lit 4) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
      simp only [ma3, ma2, ma1, iValAt_add, iValAt_mul, iValAt_readLocal, iValAt_lit,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 6)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 5)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 6)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 5)),
        hm20, wReadL_wWriteL_self]
      dsimp [baseP]
    -- Node invariants at 2 * p_off and 2 * p_off + 1 hold in ma4 (heap unchanged from m)
    have h2poff_lt : 2 * p_off + 1 < 2 ^ (K - step) := by
      rw [show K - step = K - (step + 1) + 1 by omega, pow_succ']; omega
    have hNodeL_ma4 : EncSegNode K ma4 s step (2 * p_off) S' fSq' := by
      simpa [EncSegNode, effSegCnt, ma4, ma3, ma2, ma1, rRead_wWriteL] using
        hLe step le_rfl (2 * p_off) (by omega)
    have hNodeR_raw : EncSegNode K m s step (2 * p_off + 1) S' fSq' :=
      hLe step le_rfl (2 * p_off + 1) h2poff_lt
    have hw5_m : wRead m 5 (s : ℤ) = gen := hwO 5 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide) (s : ℤ)
    -- Read left child
    rcases exec_readSegChildHelper inp ma4 5 7 8 1
        ⟨by decide, by decide, by decide⟩
        (by simp [ma4, ma3, ma2, ma1, hm2, hw5_m,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 4)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 6)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3))])
        (by simp [ma4, ma3, ma2, baseL,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (5 : ℤ) ≠ 4)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (5 : ℤ) ≠ 6))])
        hNodeL_ma4 with ⟨mbL, hex_bL, hcntL, hmaxL, hw_bL, hr_bL, hl28_bL, hrl28_bL, hlv_bL, hrlv_bL⟩
    have hNodeR_mbL : EncSegNode K mbL s step (2 * p_off + 1) S' fSq' := by
      dsimp only [EncSegNode] at hNodeR_raw ⊢
      have heff : effSegCnt K mbL s (2 ^ (K - step) + (2 * p_off + 1)) =
          effSegCnt K m s (2 ^ (K - step) + (2 * p_off + 1)) := by
        simp [effSegCnt, hw_bL, ma4, ma3, ma2, ma1]
      refine ⟨heff.trans hNodeR_raw.1, fun hne => ?_⟩
      rcases hNodeR_raw.2 hne with ⟨hv, mh, hmh, hm10, hmr8, hmax⟩
      refine ⟨?_, mh, hmh, ?_, ?_, hmax⟩
      · rw [hw_bL, hw_bL]; simpa [ma4, ma3, ma2, ma1] using hv
      · rw [hw_bL]; simpa [ma4, ma3, ma2, ma1] using hm10
      · rw [hr_bL]; simpa [ma4, ma3, ma2, ma1, rRead_wWriteL] using hmr8
    -- Read right child
    rcases exec_readSegChildHelper inp mbL 6 9 10 2
        ⟨by decide, by decide, by decide⟩
        (by rw [hl28_bL 2 (by decide) (by simp [intExprOps, realExprOps, condExprOps]), hw_bL 5 (s : ℤ)]
            simp [ma4, ma3, ma2, ma1, hm2, hw5_m,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 4)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 6)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3))])
        (by rw [hl28_bL 6 (by decide) (by simp [intExprOps, realExprOps, condExprOps])]
            simp [ma4, ma3, baseR, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (6 : ℤ) ≠ 4))])
        hNodeR_mbL with ⟨mbR, hex_bR, hcntR, hmaxR, hw_bR, hr_bR, hl28_bR, hrl28_bR, hlv_bR, hrlv_bR⟩
    -- Combine left & right in mbR
    have hcntL_mbR : wReadL 1 mbR 28 7 = ((segSubSet S' step (2 * p_off)).card : ℤ) := by
      rw [hl28_bR 7 (by decide) (by simp [intExprOps, realExprOps, condExprOps])]; exact hcntL
    have hmaxL_mbR : (segSubSet S' step (2 * p_off)).Nonempty →
        ∃ mh ∈ segSubSet S' step (2 * p_off),
          wReadL 1 mbR 28 8 = (mh : ℤ) ∧ rReadL 1 mbR 28 1 = fSq' mh ∧
          ∀ x ∈ segSubSet S' step (2 * p_off), fSq' x ≤ fSq' mh := by
      intro hne
      rcases hmaxL hne with ⟨mh, hmh, h1, h2, h3⟩
      exact ⟨mh, hmh, by rw [hl28_bR 8 (by decide) (by simp [intExprOps, realExprOps, condExprOps])]; exact h1,
        by rw [hrl28_bR 1 (by decide)]; exact h2, h3⟩
    rcases exec_combineSegChildrenHelper inp mbR hcntL_mbR hcntR hmaxL_mbR hmaxR with
      ⟨mc, hex_c, hcntP, hmaxP, hw_c, hr_c, hl28_c, hlv_c, hrlv_c⟩
    -- Write parent to heap tables 8, 9, 10 (word) and 8 (real)
    have hmc_4 : wReadL 1 mc 28 4 = baseP := by
      rw [hl28_c 4 (by decide) (by simp [intExprOps, realExprOps, condExprOps]), hl28_bR 4 (by decide) (by simp [intExprOps, realExprOps, condExprOps]),
          hl28_bL 4 (by decide) (by simp [intExprOps, realExprOps, condExprOps])]
      simp [ma4]
    have hmc_2 : wReadL 1 mc 28 2 = gen := by
      rw [hl28_c 2 (by decide) (by simp [intExprOps, realExprOps, condExprOps]), hl28_bR 2 (by decide) (by simp [intExprOps, realExprOps, condExprOps]),
          hl28_bL 2 (by decide) (by simp [intExprOps, realExprOps, condExprOps])]
      simp [ma4, ma3, ma2, ma1, hm2,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 4)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 6)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3))]
    have hmc_3 : wReadL 1 mc 28 3 = (p_u : ℤ) := by
      rw [hl28_c 3 (by decide) (by simp [intExprOps, realExprOps, condExprOps]), hl28_bR 3 (by decide) (by simp [intExprOps, realExprOps, condExprOps]),
          hl28_bL 3 (by decide) (by simp [intExprOps, realExprOps, condExprOps])]
      simp [ma4, ma3, ma2, ma1,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 4)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 6)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 5))]
    have hmc_20 : wReadL 1 mc 28 20 = (s : ℤ) := by
      rw [hl28_c 20 (by decide) (by simp [intExprOps, realExprOps, condExprOps]), hl28_bR 20 (by decide) (by simp [intExprOps, realExprOps, condExprOps]),
          hl28_bL 20 (by decide) (by simp [intExprOps, realExprOps, condExprOps])]
      simp [ma4, ma3, ma2, ma1, hm20,
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 4)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 6)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 5)),
        wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3))]
    let mw1 := wWrite mc 8 baseP gen
    let mw2 := wWrite mw1 9 baseP (wReadL 1 mc 28 11)
    let mw3 := wWrite mw2 10 baseP (wReadL 1 mc 28 12)
    let mw4 := rWrite mw3 8 baseP (rReadL 1 mc 28 3)
    have hw1 : DetExecAt 1 inp (boxWriteW M_box 8 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 2))) mc mw1 14 :=
      exec_boxWriteW inp mc _ _ (by simp [hmc_4]) (by dsimp [baseP]; positivity) hbaseP_lt
        (by simp [hmc_2]) (by simp [intExprOps, realExprOps, condExprOps])
    have hw2 : DetExecAt 1 inp (boxWriteW M_box 9 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 11))) mw1 mw2 14 :=
      exec_boxWriteW inp mw1 _ _ (by simp [mw1, hmc_4]) (by dsimp [baseP]; positivity) hbaseP_lt
        (by simp [mw1]) (by simp [intExprOps, realExprOps, condExprOps])
    have hw3 : DetExecAt 1 inp (boxWriteW M_box 10 (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 12))) mw2 mw3 14 :=
      exec_boxWriteW inp mw2 _ _ (by simp [mw2, mw1, hmc_4]) (by dsimp [baseP]; positivity) hbaseP_lt
        (by simp [mw2, mw1]) (by simp [intExprOps, realExprOps, condExprOps])
    have hw4 : DetExecAt 1 inp (boxWriteR M_box 8 (.readLocal 28 (.lit 4)) (.readRealLocal 28 (.lit 3))) mw3 mw4 14 :=
      exec_boxWriteR inp mw3 _ _ (by simp [mw3, mw2, mw1, hmc_4]) (by dsimp [baseP]; positivity) hbaseP_lt
        (by simp [mw3, mw2, mw1]) (by simp [intExprOps, realExprOps, condExprOps])
    -- Unpack hex_c (which is a 2-element seqList = .seq) to match updParentStepStmt's flat seqList
    have hbody_exec : DetExecAt 1 inp (updParentStepStmt K M_box) m mw4 210 := by
      unfold updParentStepStmt
      exact (ha1.seq (ha2.seq (ha3.seq (ha4.seq (hex_bL.seq (hex_bR.seq
        (hex_c.seq (hw1.seq (hw2.seq (hw3.seq hw4)))))))))).mono_cost (by omega)
    -- Verify Inv (step + 1) mw4
    have hw_mc_eq : ∀ t i, wRead mc t i = wRead m t i := by
      intro t i; rw [hw_c, hw_bR, hw_bL]; simp [ma4, ma3, ma2, ma1]
    have hr_mc_eq : ∀ t i, rRead mc t i = rRead m t i := by
      intro t i; rw [hr_c, hr_bR, hr_bL]; simp [ma4, ma3, ma2, ma1, rRead_wWriteL]
    have hw_mw4_other_tag : ∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → ∀ idx, wRead mw4 t idx = wRead m t idx := by
      intro t h8 h9 h10 idx
      simp [mw4, mw3, mw2, mw1, wRead_rWrite,
        wRead_wWrite_of_ne _ _ (Or.inl h10), wRead_wWrite_of_ne _ _ (Or.inl h9),
        wRead_wWrite_of_ne _ _ (Or.inl h8), hw_mc_eq]
    have hw8_mw4_ne : ∀ idx, idx ≠ baseP → wRead mw4 8 idx = wRead m 8 idx := by
      intro idx hi
      simp [mw4, mw3, mw2, mw1, wRead_rWrite,
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 10)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 9)),
        wRead_wWrite_of_ne _ _ (Or.inr hi), hw_mc_eq]
    have hw9_mw4_ne : ∀ idx, idx ≠ baseP → wRead mw4 9 idx = wRead m 9 idx := by
      intro idx hi
      simp [mw4, mw3, mw2, mw1, wRead_rWrite,
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (9 : ℕ) ≠ 10)),
        wRead_wWrite_of_ne _ _ (Or.inr hi),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (9 : ℕ) ≠ 8)), hw_mc_eq]
    have hw10_mw4_ne : ∀ idx, idx ≠ baseP → wRead mw4 10 idx = wRead m 10 idx := by
      intro idx hi
      simp [mw4, mw3, mw2, mw1, wRead_rWrite,
        wRead_wWrite_of_ne _ _ (Or.inr hi),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (10 : ℕ) ≠ 9)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide : (10 : ℕ) ≠ 8)), hw_mc_eq]
    have hr8_mw4_ne : ∀ idx, idx ≠ baseP → rRead mw4 8 idx = rRead m 8 idx := by
      intro idx hi
      simp [mw4, mw3, mw2, mw1, rRead_rWrite_of_ne _ _ (Or.inr hi), rRead_wWrite, hr_mc_eq]
    have hw5_mw4 : wRead mw4 5 (s : ℤ) = wRead m 5 (s : ℤ) :=
      hw_mw4_other_tag 5 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide) (s : ℤ)
    refine ⟨mw4, hbody_exec, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · refine ⟨by rw [hw_mw4_other_tag 1 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide)]; exact hSg.1,
        fun s' hs' => by
          rw [hw_mw4_other_tag 5 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide),
              hw_mw4_other_tag 1 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide)]
          exact hSg.2.1 s' hs',
        fun s' hs' u hu => ?_⟩
      rw [hw_mw4_other_tag 1 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide)]
      by_cases heq_idx : ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) = baseP
      · rw [heq_idx, hwO 1 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide)]
        simp [mw4, mw3, mw2, mw1, wRead_rWrite,
          wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 10)),
          wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 9)), hgen_lt_next]
      · rw [hw8_mw4_ne _ heq_idx]; exact hSg.2.2 s' hs' u hu
    · simp [mw4, mw3, mw2, mw1, wReadL_rWrite, hmc_20]
    · simp [mw4, mw3, mw2, mw1, wReadL_rWrite, hmc_2]
    · simp [mw4, mw3, mw2, mw1, wReadL_rWrite, hmc_3, p_u, p_off]
    · intro r hr_le off hoff
      rcases Nat.lt_or_eq_of_le hr_le with hr_lt | rfl
      · have hne_u : 2 ^ (K - r) + off ≠ p_u :=
          seg_node_ne_of_height_ne (by omega) (by omega) (by omega) hoff hp_off_lt
        exact (hLe r (by omega) off hoff).congr_other_idx hne_u hw5_mw4
          hw8_mw4_ne hw9_mw4_ne hw10_mw4_ne hr8_mw4_ne
      · by_cases hoff_eq : off = p_off
        · subst hoff_eq
          dsimp only [EncSegNode]
          have hw8_p : wRead mw4 8 baseP = gen := by
            simp [mw4, mw3, mw2, mw1, wRead_rWrite,
              wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 10)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide : (8 : ℕ) ≠ 9))]
          have hw5_p : wRead mw4 5 (s : ℤ) = gen := by rw [hw5_mw4, hw5_m]
          refine ⟨?_, fun hne_P => ?_⟩
          · simp [-Nat.cast_add, -Nat.cast_mul, -Nat.cast_pow, effSegCnt, p_u, baseP, mw4, mw3, mw2, mw1, wRead_rWrite, hw_mc_eq, hw5_m,
              wRead_wWrite_of_ne _ _ (Or.inl (by decide : (9 : ℕ) ≠ 10)), hcntP]
          · rcases hmaxP hne_P with ⟨mh, hmh, hm12, hmr3, hmax⟩
            refine ⟨by simpa [p_u, baseP, hw5_p] using hw8_p, mh, hmh, ?_, ?_, hmax⟩
            · simp [p_u, baseP, mw4, mw3, wRead_rWrite, hm12]
            · simp [p_u, baseP, mw4, hmr3]
        · have hprev := hGt (step + 1) (by omega) (by omega) off hoff hoff_eq
          exact hprev.congr_other_idx (by dsimp [p_u]; omega) hw5_mw4
            hw8_mw4_ne hw9_mw4_ne hw10_mw4_ne hr8_mw4_ne
    · intro r hr_gt hr_le off hoff hne_div
      have hne_u : 2 ^ (K - r) + off ≠ p_u :=
        seg_node_ne_of_height_ne hr_le (by omega) (by omega) hoff hp_off_lt
      exact (hGt r (by omega) hr_le off hoff hne_div).congr_other_idx hne_u hw5_mw4
        hw8_mw4_ne hw9_mw4_ne hw10_mw4_ne hr8_mw4_ne
    · intro t h8 h9 h10 idx
      rw [hw_mw4_other_tag t h8 h9 h10 idx, hwO t h8 h9 h10 idx]
    · intro t h8 idx
      simp [mw4, mw3, mw2, mw1, rRead_rWrite_of_ne _ _ (Or.inl h8), rRead_wWrite, hr_mc_eq, hrO t h8 idx]
    · intro s' hs' hne_s u hu
      have hne_b : ((s' * 2 ^ (K + 1) + u : ℕ) : ℤ) ≠ baseP :=
        seg_base_ne_of_slot_ne hne_s hu hp_u_lt
      rcases hSlotO s' hs' hne_s u hu with ⟨e1, e2, e3, e4⟩
      exact ⟨(hw8_mw4_ne _ hne_b).trans e1, (hw9_mw4_ne _ hne_b).trans e2,
             (hw10_mw4_ne _ hne_b).trans e3, (hr8_mw4_ne _ hne_b).trans e4⟩
    · intro v hv idx
      simp only [mw4, mw3, mw2, mw1, wReadL_rWrite, rReadL_rWrite, wReadL_wWrite, rReadL_wWrite]
      rw [hlv_c v hv, hrlv_c v hv, hlv_bR v hv, hrlv_bR v hv, hlv_bL v hv, hrlv_bL v hv]
      simp only [ma4, ma3, ma2, ma1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv), rReadL_wWriteL]
      exact hLocO v hv idx
  rcases DetExecAt.repeatN_nat (.lit (K : ℤ)) (updParentStepStmt K M_box) K 1 210
      Inv hInv0 rfl (by simp [intExprOps, realExprOps, condExprOps]) hStep with ⟨mK, hInvK, hrep⟩
  rcases hInvK with ⟨hSgK, _, _, _, hLeK, _, hwOK, hrOK, hSlotOK, hLocOK⟩
  have hex_all : DetExecAt 1 inp (updLeafSegSlotStmt K M_box) mem mK (220 * (K + 1)) := by
    unfold updLeafSegSlotStmt
    exact (hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq (hs6.seq (hs7.seq hrep))))))).mono_cost (by omega)
  refine ⟨mK, hex_all, hSgK, ?_, ?_, hwOK, hrOK,
    fun v hv idx => (hLocOK v hv idx).1, fun v hv idx => (hLocOK v hv idx).2⟩
  · refine ⟨by rw [hwOK 5 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide)]; exact hEnc.1, ?_, hLeK⟩
    intro x hx
    dsimp [S'] at hx
    cases ins with
    | false => exact hEnc.2.1 x (Finset.mem_of_mem_erase hx)
    | true =>
        rcases Finset.mem_insert.mp hx with rfl | hxS
        · exact hh
        · exact hEnc.2.1 x hxS
  · intro s' hs' hne_s S₁ fSq₁ hEnc₁
    refine hEnc₁.congr_mem_fSq
      (hwOK 5 (by decide) (by simp [intExprOps, realExprOps, condExprOps]) (by decide) (s' : ℤ))
      (fun u hu => (hSlotOK s' hs' hne_s u hu).1)
      (fun u hu => (hSlotOK s' hs' hne_s u hu).2.1)
      (fun u hu => (hSlotOK s' hs' hne_s u hu).2.2.1)
      (fun u hu => (hSlotOK s' hs' hne_s u hu).2.2.2)
      (fun _ _ => rfl)

/-! ### 5. Top-Down Rank Selection (`selectByRankSegStmt`) & Successor (`findSuccSegStmt`) -/

def selectRankStepStmt (K : ℕ) : ArithRAMStmt :=
  let W_lit : IntExpr := .lit ((2 ^ (K + 1) : ℕ) : ℤ)
  seqList [
    .writeWordLocal 28 (.lit 5)
      (.add (.mul (.readLocal 28 (.lit 20)) W_lit) (.mul (.lit 2) (.readLocal 28 (.lit 3)))),
    .ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2)))
      (.writeWordLocal 28 (.lit 6) (.readHeap 9 (.readLocal 28 (.lit 5))))
      (.writeWordLocal 28 (.lit 6) (.lit 0)),
    .ite (.intLt (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 6)))
      (.writeWordLocal 28 (.lit 3) (.mul (.lit 2) (.readLocal 28 (.lit 3))))
      (seqList [
        .writeWordLocal 28 (.lit 4) (.sub (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 6))),
        .writeWordLocal 28 (.lit 3) (.add (.mul (.lit 2) (.readLocal 28 (.lit 3))) (.lit 1))
      ])
  ]

/-- Select the `rk`-th handle in ascending order (`rk = 28[21] < S.card`) in slot `s = 28[20]`,
writing `(S.orderEmbOfFin rfl ⟨rk, hrk⟩)` to `28[0]`. Preserves `28[20]`, `28[14]`, `28[15]`. -/
def selectByRankSegStmt (K : ℕ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 28 (.lit 2) (.readHeap 5 (.readLocal 28 (.lit 20))),
    .writeWordLocal 28 (.lit 3) (.lit 1),
    .writeWordLocal 28 (.lit 4) (.readLocal 28 (.lit 21)),
    .repeatN (.lit (K : ℤ)) (selectRankStepStmt K),
    .writeWordLocal 28 (.lit 0) (.sub (.readLocal 28 (.lit 3)) (.lit ((2 ^ K : ℕ) : ℤ)))
  ]

theorem boxSafe_selectByRankSegStmt {T_max M_box : ℕ} (K : ℕ) :
    BoxSafeInner T_max M_box (selectByRankSegStmt K) := by
  unfold selectByRankSegStmt selectRankStepStmt
  apply boxSafeInner_seqList
  intro st hst
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .repeatN _ (boxSafeInner_seqList ?_)
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .ite _ (.writeWordLocal _ _ _) (.writeWordLocal _ _ _)
    · refine .ite _ (.writeWordLocal _ _ _) (boxSafeInner_seqList ?_)
      intro y hy; simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
      rcases hy with rfl | rfl <;> exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _

theorem exec_selectByRankSegStmt {d K : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s rk : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    (hrk : rk < S.card)
    (hs_reg : wReadL 1 mem 28 20 = (s : ℤ))
    (hrk_reg : wReadL 1 mem 28 21 = (rk : ℤ))
    (hEnc : EncSegSlot K mem s S fSq) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (selectByRankSegStmt K) mem mem' (80 * (K + 1)) ∧
      wReadL 1 mem' 28 0 = ((S.orderEmbOfFin rfl ⟨rk, hrk⟩) : ℤ) ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ v, v ≠ 28 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  set gen := wRead mem 5 (s : ℤ)
  let m1 := wWriteL 1 mem 28 2 gen
  let m2 := wWriteL 1 m1 28 3 1
  let m3 := wWriteL 1 m2 28 4 (rk : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 2) (.readHeap 5 (.readLocal 28 (.lit 20)))) mem m1 8 :=
    DetExecAt.writeWordLocal 1 inp mem 28 (.lit 2) _ rfl (by simp [hs_reg, gen]) (by simp [intExprOps, realExprOps, condExprOps])
  have hs2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 3) (.lit 1)) m1 m2 4 :=
    DetExecAt.writeWordLocal 1 inp m1 28 (.lit 3) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
  have hs3 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 4) (.readLocal 28 (.lit 21))) m2 m3 6 :=
    DetExecAt.writeWordLocal 1 inp m2 28 (.lit 4) _ rfl
      (by simp [m2, m1, hrk_reg,
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 3)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 2))]) (by simp [intExprOps, realExprOps, condExprOps])
  let Inv : ℕ → ArithRAMMemory → Prop := fun i m =>
    (∀ t idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t idx, rRead m t idx = rRead mem t idx) ∧
    (∀ v, v ≠ 28 → ∀ idx, wReadL 1 m v idx = wReadL 1 mem v idx) ∧
    (∀ v idx, rReadL 1 m v idx = rReadL 1 mem v idx) ∧
    wReadL 1 m 28 20 = (s : ℤ) ∧
    wReadL 1 m 28 2 = gen ∧
    ∃ off < 2 ^ i, ∃ rem : ℕ,
      wReadL 1 m 28 3 = ((2 ^ i + off : ℕ) : ℤ) ∧
      wReadL 1 m 28 4 = (rem : ℤ) ∧
      rem < (segSubSet S (K - i) off).card ∧
      (S.filter (· < off * 2 ^ (K - i))).card + rem = rk
  have hInv0 : Inv 0 m3 := by
    refine ⟨fun t idx => by simp [m3, m2, m1], fun t idx => by simp [m3, m2, m1],
      fun v hv idx => by simp [m3, m2, m1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv)],
      fun v idx => by simp [m3, m2, m1],
      by simp [m3, m2, m1, hs_reg,
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 4)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 2))],
      by simp [m3, m2, m1,
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 4)),
            wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3))],
      0, by simp, rk, by simp [m3, m2, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 4))],
      by simp [m3], ?_, ?_⟩
    · rw [Nat.sub_zero, segSubSet_root hEnc.2.1]; exact hrk
    · have hemp : S.filter (· < 0 * 2 ^ (K - 0)) = ∅ := by simp
      rw [hemp, Finset.card_empty, zero_add]
  have hStep : ∀ i < K, ∀ m, Inv i m →
      ∃ m', DetExecAt 1 inp (selectRankStepStmt K) m m' 60 ∧ Inv (i + 1) m' := by
    intro i hi_lt m hIm
    rcases hIm with ⟨hw_m, hr_m, hlv_m, hrl_m, hm20, hm2, off, hoff, rem, hm3, hm4, hrem_lt, hacc⟩
    let r' := K - (i + 1)
    have hKi_eq : K - i = r' + 1 := by omega
    have h2u_eq : 2 * (2 ^ i + off) = 2 ^ (i + 1) + 2 * off := by rw [pow_succ']; ring
    have hK_r' : K - r' = i + 1 := by omega
    have hNodeL := (hEnc.2.2 r' (by omega) (2 * off) (by rw [hK_r', pow_succ']; omega)).1
    dsimp only [effSegCnt] at hNodeL
    rw [hK_r'] at hNodeL
    let baseL : ℤ := ((s * 2 ^ (K + 1) + (2 ^ (i + 1) + 2 * off) : ℕ) : ℤ)
    let cntL : ℕ := (segSubSet S r' (2 * off)).card
    let ma1 := wWriteL 1 m 28 5 baseL
    have ha1 : DetExecAt 1 inp
        (.writeWordLocal 28 (.lit 5) (.add (.mul (.readLocal 28 (.lit 20)) (.lit ((2 ^ (K + 1) : ℕ) : ℤ))) (.mul (.lit 2) (.readLocal 28 (.lit 3)))))
        m ma1 12 := by
      refine DetExecAt.writeWordLocal 1 inp m 28 (.lit 5) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
      simp only [iValAt_add, iValAt_mul, iValAt_readLocal, iValAt_lit, hm20, hm3]
      dsimp [baseL]; exact_mod_cast congrArg (s * 2 ^ (K + 1) + ·) h2u_eq
    let ma2 := wWriteL 1 ma1 28 6 (cntL : ℤ)
    have ha2 : DetExecAt 1 inp
        (.ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2)))
          (.writeWordLocal 28 (.lit 6) (.readHeap 9 (.readLocal 28 (.lit 5))))
          (.writeWordLocal 28 (.lit 6) (.lit 0))) ma1 ma2 18 := by
      by_cases hv : wRead mem 8 baseL = gen
      · have hc : cValAt 1 inp ma1 (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2))) = true := by
          simp [ma1, hw_m, hm2, hv, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5))]
        simp only [baseL, gen, hv, ↓reduceIte] at hNodeL
        have hb : DetExecAt 1 inp (.writeWordLocal 28 (.lit 6) (.readHeap 9 (.readLocal 28 (.lit 5)))) ma1 ma2 6 :=
          DetExecAt.writeWordLocal 1 inp ma1 28 (.lit 6) _ rfl
            (by simp only [iValAt_readHeap, iValAt_readLocal, iValAt_lit, ma1, wReadL_wWriteL_eq, wRead_wWriteL, hw_m]; simpa [baseL, cntL] using hNodeL) (by simp [intExprOps, realExprOps, condExprOps])
        exact (DetExecAt.ite_true hc (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) hb).mono_cost (by omega)
      · have hc : cValAt 1 inp ma1 (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2))) = false := by
          simp [ma1, hw_m, hm2, hv, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5))]
        simp only [baseL, gen, hv, ↓reduceIte] at hNodeL
        have hb : DetExecAt 1 inp (.writeWordLocal 28 (.lit 6) (.lit 0)) ma1 ma2 4 :=
          DetExecAt.writeWordLocal 1 inp ma1 28 (.lit 6) _ rfl (by simp [cntL, ← hNodeL]) (by simp [intExprOps, realExprOps, condExprOps])
        exact (DetExecAt.ite_false hc (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) hb).mono_cost (by omega)
    by_cases hlt : rem < cntL
    · have hc_lt : cValAt 1 inp ma2 (.intLt (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 6))) = true := by
        simp [ma2, ma1, hm4, hlt,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 5))]
      let ma3 := wWriteL 1 ma2 28 3 ((2 ^ (i + 1) + 2 * off : ℕ) : ℤ)
      have hb : DetExecAt 1 inp (.writeWordLocal 28 (.lit 3) (.mul (.lit 2) (.readLocal 28 (.lit 3)))) ma2 ma3 8 := by
        refine DetExecAt.writeWordLocal 1 inp ma2 28 (.lit 3) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
        simp only [ma2, ma1, iValAt_mul, iValAt_lit, iValAt_readLocal,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 5)), hm3]
        rw [← h2u_eq]; push_cast; ring
      refine ⟨ma3, (ha1.seq (ha2.seq (DetExecAt.ite_true hc_lt (C_c := 8) (by simp [intExprOps, realExprOps, condExprOps]) hb))).mono_cost (by omega), ?_, ?_, ?_, ?_, ?_, ?_,
        2 * off, by rw [pow_succ']; omega, rem, ?_, ?_, hlt, ?_⟩
      · intro t idx; simp [ma3, ma2, ma1, hw_m]
      · intro t idx; simp [ma3, ma2, ma1, hr_m]
      · intro v hv idx; simp [ma3, ma2, ma1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv), hlv_m v hv]
      · intro v idx; simp [ma3, ma2, ma1, hrl_m]
      · simp [ma3, ma2, ma1, hm20,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 5))]
      · simp [ma3, ma2, ma1, hm2,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5))]
      · simp [ma3]
      · simp [ma3, ma2, ma1, hm4,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 3)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 5))]
      · have heq_mul : (2 * off) * 2 ^ r' = off * 2 ^ (K - i) := by
          rw [hKi_eq, pow_succ]; ring
        rwa [heq_mul]
    · have hge : cntL ≤ rem := not_lt.mp hlt
      have hc_lt : cValAt 1 inp ma2 (.intLt (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 6))) = false := by
        simp [ma2, ma1, hm4, hlt,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 5))]
      let ma3 := wWriteL 1 ma2 28 4 ((rem - cntL : ℕ) : ℤ)
      let ma4 := wWriteL 1 ma3 28 3 ((2 ^ (i + 1) + (2 * off + 1) : ℕ) : ℤ)
      have hb1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 4) (.sub (.readLocal 28 (.lit 4)) (.readLocal 28 (.lit 6)))) ma2 ma3 8 := by
        refine DetExecAt.writeWordLocal 1 inp ma2 28 (.lit 4) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
        simp only [ma2, ma1, iValAt_sub, iValAt_readLocal, iValAt_lit,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 5)), hm4, wReadL_wWriteL_self]
        omega
      have hb2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 3) (.add (.mul (.lit 2) (.readLocal 28 (.lit 3))) (.lit 1))) ma3 ma4 10 := by
        refine DetExecAt.writeWordLocal 1 inp ma3 28 (.lit 3) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
        simp only [ma3, ma2, ma1, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 4)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 5)), hm3]
        omega
      have hparent_card : (segSubSet S (K - i) off).card = cntL + (segSubSet S r' (2 * off + 1)).card := by
        rw [hKi_eq]; exact segSubSet_succ_card S r' off
      refine ⟨ma4, (ha1.seq (ha2.seq (DetExecAt.ite_false hc_lt (C_c := 8) (by simp [intExprOps, realExprOps, condExprOps]) (hb1.seq hb2)))).mono_cost (by omega), ?_, ?_, ?_, ?_, ?_, ?_,
        2 * off + 1, by rw [pow_succ']; omega, rem - cntL, ?_, ?_, Nat.sub_lt_left_of_lt_add hge (by simpa [r', cntL] using hparent_card ▸ hrem_lt), ?_⟩
      · intro t idx; simp [ma4, ma3, ma2, ma1, hw_m]
      · intro t idx; simp [ma4, ma3, ma2, ma1, hr_m]
      · intro v hv idx; simp [ma4, ma3, ma2, ma1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv), hlv_m v hv]
      · intro v idx; simp [ma4, ma3, ma2, ma1, hrl_m]
      · simp [ma4, ma3, ma2, ma1, hm20,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 4)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 5))]
      · simp [ma4, ma3, ma2, ma1, hm2,
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 4)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 6)),
          wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5))]
      · simp [ma4]
      · simp [ma4, ma3, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (4 : ℤ) ≠ 3))]
      · rw [filter_lt_split_card S r' off, ← hKi_eq]
        dsimp [cntL] at hge ⊢
        omega
  rcases DetExecAt.repeatN_nat (.lit (K : ℤ)) (selectRankStepStmt K) K 1 60
      Inv hInv0 rfl (by simp [intExprOps, realExprOps, condExprOps]) hStep with ⟨mK, hInvK, hrep⟩
  rcases hInvK with ⟨hwK, hrK, hlvK, hrlK, _, _, offK, _, remK, hm3K, _, hremK_lt, haccK⟩
  rw [Nat.sub_self, segSubSet_zero] at hremK_lt
  rw [Nat.sub_self, pow_zero, mul_one] at haccK
  have hoff_in : offK ∈ S := by
    by_contra hnot
    simp [hnot] at hremK_lt
  simp only [hoff_in, ↓reduceIte, Finset.card_singleton] at hremK_lt
  have hremK_0 : remK = 0 := by omega
  rw [hremK_0, add_zero] at haccK
  have hoff_eq_ord : offK = (S.orderEmbOfFin rfl ⟨rk, hrk⟩) :=
    (eq_orderEmbOfFin_of_card_filter_lt hoff_in hrk haccK).symm
  let mf := wWriteL 1 mK 28 0 (offK : ℤ)
  have hsf : DetExecAt 1 inp
      (.writeWordLocal 28 (.lit 0) (.sub (.readLocal 28 (.lit 3)) (.lit ((2 ^ K : ℕ) : ℤ)))) mK mf 8 := by
    refine DetExecAt.writeWordLocal 1 inp mK 28 (.lit 0) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
    simp [hm3K]
  refine ⟨mf, (hs1.seq (hs2.seq (hs3.seq (hrep.seq hsf)))).mono_cost (by omega),
    by simp [mf, hoff_eq_ord],
    fun t idx => by simp [mf, hwK],
    fun t idx => by simp [mf, hrK],
    fun v hv idx => by simp [mf, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv), hlvK v hv],
    fun v idx => by simp [mf, hrlK]⟩

def countLtStepStmt (K : ℕ) : ArithRAMStmt :=
  let W_lit : IntExpr := .lit ((2 ^ (K + 1) : ℕ) : ℤ)
  seqList [
    .writeWordLocal 28 (.lit 9) (.div (.readLocal 28 (.lit 8)) (.lit 2)),
    .ite (.intLe (.add (.readLocal 28 (.lit 7)) (.readLocal 28 (.lit 9))) (.readLocal 28 (.lit 21)))
      (seqList [
        .writeWordLocal 28 (.lit 5)
          (.add (.mul (.readLocal 28 (.lit 20)) W_lit) (.mul (.lit 2) (.readLocal 28 (.lit 3)))),
        .ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2)))
          (.writeWordLocal 28 (.lit 6) (.readHeap 9 (.readLocal 28 (.lit 5))))
          (.writeWordLocal 28 (.lit 6) (.lit 0)),
        .writeWordLocal 28 (.lit 14) (.add (.readLocal 28 (.lit 14)) (.readLocal 28 (.lit 6))),
        .writeWordLocal 28 (.lit 3) (.add (.mul (.lit 2) (.readLocal 28 (.lit 3))) (.lit 1)),
        .writeWordLocal 28 (.lit 7) (.add (.readLocal 28 (.lit 7)) (.readLocal 28 (.lit 9))),
        .writeWordLocal 28 (.lit 8) (.readLocal 28 (.lit 9))
      ])
      (seqList [
        .writeWordLocal 28 (.lit 3) (.mul (.lit 2) (.readLocal 28 (.lit 3))),
        .writeWordLocal 28 (.lit 8) (.readLocal 28 (.lit 9))
      ])
  ]

/-- Find successor `min { x ∈ S | q ≤ x }` in slot `s = 28[20]` for query `q = 28[21]` (`0 ≤ q`):
if found, sets `28[1] = 1` and `28[0] = y`; if none exists, sets `28[1] = 0` and `28[0] = 0`. -/
def findSuccSegStmt (K : ℕ) : ArithRAMStmt :=
  let W_lit : IntExpr := .lit ((2 ^ (K + 1) : ℕ) : ℤ)
  let powK : IntExpr := .lit ((2 ^ K : ℕ) : ℤ)
  seqList [
    .writeWordLocal 28 (.lit 2) (.readHeap 5 (.readLocal 28 (.lit 20))),
    .writeWordLocal 28 (.lit 5) (.add (.mul (.readLocal 28 (.lit 20)) W_lit) (.lit 1)),
    .ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2)))
      (.writeWordLocal 28 (.lit 15) (.readHeap 9 (.readLocal 28 (.lit 5))))
      (.writeWordLocal 28 (.lit 15) (.lit 0)),
    .ite (.intLe powK (.readLocal 28 (.lit 21)))
      (.writeWordLocal 28 (.lit 14) (.readLocal 28 (.lit 15)))
      (seqList [
        .writeWordLocal 28 (.lit 3) (.lit 1),
        .writeWordLocal 28 (.lit 7) (.lit 0),
        .writeWordLocal 28 (.lit 8) powK,
        .writeWordLocal 28 (.lit 14) (.lit 0),
        .repeatN (.lit (K : ℤ)) (countLtStepStmt K)
      ]),
    .ite (.intLt (.readLocal 28 (.lit 14)) (.readLocal 28 (.lit 15)))
      (seqList [
        .writeWordLocal 28 (.lit 21) (.readLocal 28 (.lit 14)),
        selectByRankSegStmt K,
        .writeWordLocal 28 (.lit 1) (.lit 1)
      ])
      (seqList [
        .writeWordLocal 28 (.lit 0) (.lit 0),
        .writeWordLocal 28 (.lit 1) (.lit 0)
      ])
  ]

theorem boxSafe_findSuccSegStmt {T_max M_box : ℕ} (K : ℕ) :
    BoxSafeInner T_max M_box (findSuccSegStmt K) := by
  unfold findSuccSegStmt countLtStepStmt
  apply boxSafeInner_seqList
  intro st hst
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .ite _ (.writeWordLocal _ _ _) (.writeWordLocal _ _ _)
  · refine .ite _ (.writeWordLocal _ _ _) (boxSafeInner_seqList ?_)
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · refine .repeatN _ (boxSafeInner_seqList ?_)
      intro y hy; simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
      rcases hy with rfl | rfl
      · exact .writeWordLocal _ _ _
      · refine .ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_)
        · intro z hz; simp only [List.mem_cons, List.not_mem_nil, or_false] at hz
          rcases hz with rfl | rfl | rfl | rfl | rfl | rfl
          · exact .writeWordLocal _ _ _
          · exact .ite _ (.writeWordLocal _ _ _) (.writeWordLocal _ _ _)
          · exact .writeWordLocal _ _ _
          · exact .writeWordLocal _ _ _
          · exact .writeWordLocal _ _ _
          · exact .writeWordLocal _ _ _
        · intro z hz; simp only [List.mem_cons, List.not_mem_nil, or_false] at hz
          rcases hz with rfl | rfl <;> exact .writeWordLocal _ _ _
  · refine .ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_)
    · intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact boxSafe_selectByRankSegStmt K
      · exact .writeWordLocal _ _ _
    · intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl <;> exact .writeWordLocal _ _ _

theorem exec_findSuccSegStmt {d K : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s q : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    (hs_reg : wReadL 1 mem 28 20 = (s : ℤ))
    (hq_reg : wReadL 1 mem 28 21 = (q : ℤ))
    (hEnc : EncSegSlot K mem s S fSq) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (findSuccSegStmt K) mem mem' (250 * (K + 1)) ∧
      ((∃ x ∈ S, q ≤ x) →
        wReadL 1 mem' 28 1 = 1 ∧
        ∃ y ∈ S, wReadL 1 mem' 28 0 = (y : ℤ) ∧ q ≤ y ∧ ∀ x ∈ S, q ≤ x → y ≤ x) ∧
      ((∀ x ∈ S, x < q) → wReadL 1 mem' 28 1 = 0) ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ v, v ≠ 28 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  set gen := wRead mem 5 (s : ℤ)
  have hroot := (hEnc.2.2 K le_rfl 0 (by simp)).1
  rw [Nat.sub_self, pow_zero, add_zero, segSubSet_root hEnc.2.1] at hroot
  dsimp only [effSegCnt] at hroot
  let rootIdx : ℤ := ((s * 2 ^ (K + 1) + 1 : ℕ) : ℤ)
  let m1 := wWriteL 1 mem 28 2 gen
  let m2 := wWriteL 1 m1 28 5 rootIdx
  let m3 := wWriteL 1 m2 28 15 (S.card : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 2) (.readHeap 5 (.readLocal 28 (.lit 20)))) mem m1 8 :=
    DetExecAt.writeWordLocal 1 inp mem 28 (.lit 2) _ rfl (by simp [hs_reg, gen]) (by simp [intExprOps, realExprOps, condExprOps])
  have hs2 : DetExecAt 1 inp
      (.writeWordLocal 28 (.lit 5) (.add (.mul (.readLocal 28 (.lit 20)) (.lit ((2 ^ (K + 1) : ℕ) : ℤ))) (.lit 1)))
      m1 m2 10 :=
    DetExecAt.writeWordLocal 1 inp m1 28 (.lit 5) _ rfl
      (by simp [m1, hs_reg, rootIdx, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 2))])
      (by simp [intExprOps, realExprOps, condExprOps])
  have hs3 : DetExecAt 1 inp
      (.ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2)))
        (.writeWordLocal 28 (.lit 15) (.readHeap 9 (.readLocal 28 (.lit 5))))
        (.writeWordLocal 28 (.lit 15) (.lit 0))) m2 m3 18 := by
    by_cases hv : wRead mem 8 rootIdx = gen
    · have hc : cValAt 1 inp m2 (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2))) = true := by
        simp [m2, m1, hv, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5))]
      simp only [rootIdx, gen, hv, ↓reduceIte] at hroot
      have hb : DetExecAt 1 inp (.writeWordLocal 28 (.lit 15) (.readHeap 9 (.readLocal 28 (.lit 5)))) m2 m3 6 :=
        DetExecAt.writeWordLocal 1 inp m2 28 (.lit 15) _ rfl (by simp only [iValAt_readHeap, iValAt_readLocal, iValAt_lit, m2, m1, wReadL_wWriteL_eq, wRead_wWriteL]; simpa [rootIdx] using hroot) (by simp [intExprOps, realExprOps, condExprOps])
      exact (DetExecAt.ite_true hc (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) hb).mono_cost (by omega)
    · have hc : cValAt 1 inp m2 (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2))) = false := by
        simp [m2, m1, hv, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5))]
      simp only [rootIdx, gen, hv, ↓reduceIte] at hroot
      have hb : DetExecAt 1 inp (.writeWordLocal 28 (.lit 15) (.lit 0)) m2 m3 4 :=
        DetExecAt.writeWordLocal 1 inp m2 28 (.lit 15) _ rfl (by simp [← hroot]) (by simp [intExprOps, realExprOps, condExprOps])
      exact (DetExecAt.ite_false hc (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) hb).mono_cost (by omega)
  -- Phase A: compute c := (S.filter (· < q)).card into 28[14]
  let c_lt : ℕ := (S.filter (· < q)).card
  have hPhaseA : ∃ mA : ArithRAMMemory,
      DetExecAt 1 inp
        (.ite (.intLe (.lit ((2 ^ K : ℕ) : ℤ)) (.readLocal 28 (.lit 21)))
          (.writeWordLocal 28 (.lit 14) (.readLocal 28 (.lit 15)))
          (seqList [
            .writeWordLocal 28 (.lit 3) (.lit 1),
            .writeWordLocal 28 (.lit 7) (.lit 0),
            .writeWordLocal 28 (.lit 8) (.lit ((2 ^ K : ℕ) : ℤ)),
            .writeWordLocal 28 (.lit 14) (.lit 0),
            .repeatN (.lit (K : ℤ)) (countLtStepStmt K)
          ])) m3 mA (100 * (K + 1)) ∧
      (∀ t idx, wRead mA t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mA t idx = rRead mem t idx) ∧
      (∀ v, v ≠ 28 → ∀ idx, wReadL 1 mA v idx = wReadL 1 mem v idx) ∧
      (∀ v idx, rReadL 1 mA v idx = rReadL 1 mem v idx) ∧
      wReadL 1 mA 28 20 = (s : ℤ) ∧
      wReadL 1 mA 28 15 = (S.card : ℤ) ∧
      wReadL 1 mA 28 14 = (c_lt : ℤ) := by
    by_cases hq_ge : 2 ^ K ≤ q
    · have hc : cValAt 1 inp m3 (.intLe (.lit ((2 ^ K : ℕ) : ℤ)) (.readLocal 28 (.lit 21))) = true := by
        simp only [cValAt_intLe, iValAt_lit, iValAt_readLocal, m3, m2, m1, wReadL_wWriteL_eq,
          hq_reg, decide_eq_true_eq]
        simpa using (show ((2 ^ K : ℕ) : ℤ) ≤ (q : ℤ) from by exact_mod_cast hq_ge)
      have hfilt_all : S.filter (· < q) = S :=
        Finset.filter_eq_self.mpr (fun x hx => lt_of_lt_of_le (hEnc.2.1 x hx) hq_ge)
      let mA := wWriteL 1 m3 28 14 (S.card : ℤ)
      have hb : DetExecAt 1 inp (.writeWordLocal 28 (.lit 14) (.readLocal 28 (.lit 15))) m3 mA 6 :=
        DetExecAt.writeWordLocal 1 inp m3 28 (.lit 14) _ rfl (by simp [m3]) (by simp [intExprOps, realExprOps, condExprOps])
      refine ⟨mA, (DetExecAt.ite_true hc (C_c := 8) (by simp [intExprOps, realExprOps, condExprOps]) hb).mono_cost (by omega),
        fun t idx => by simp [mA, m3, m2, m1],
        fun t idx => by simp [mA, m3, m2, m1],
        fun v hv idx => by simp [mA, m3, m2, m1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv)],
        fun v idx => by simp [mA, m3, m2, m1],
        by simp [mA, m3, m2, m1, hs_reg,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 14)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 15)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 5)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 2))],
        by simp [mA, m3, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 14))],
        by simp [mA, c_lt, hfilt_all]⟩
    · have hq_lt : q < 2 ^ K := not_le.mp hq_ge
      have hc : cValAt 1 inp m3 (.intLe (.lit ((2 ^ K : ℕ) : ℤ)) (.readLocal 28 (.lit 21))) = false := by
        simp only [cValAt_intLe, iValAt_lit, iValAt_readLocal, m3, m2, m1, wReadL_wWriteL_eq,
          hq_reg, decide_eq_false_iff_not]
        simpa using (show ¬ (((2 ^ K : ℕ) : ℤ) ≤ (q : ℤ)) from by exact_mod_cast hq_ge)
      let mb1 := wWriteL 1 m3 28 3 1
      let mb2 := wWriteL 1 mb1 28 7 0
      let mb3 := wWriteL 1 mb2 28 8 ((2 ^ K : ℕ) : ℤ)
      let mb4 := wWriteL 1 mb3 28 14 0
      have hb1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 3) (.lit 1)) m3 mb1 4 :=
        DetExecAt.writeWordLocal 1 inp m3 28 (.lit 3) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
      have hb2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 7) (.lit 0)) mb1 mb2 4 :=
        DetExecAt.writeWordLocal 1 inp mb1 28 (.lit 7) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
      have hb3 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 8) (.lit ((2 ^ K : ℕ) : ℤ))) mb2 mb3 4 :=
        DetExecAt.writeWordLocal 1 inp mb2 28 (.lit 8) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
      have hb4 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 14) (.lit 0)) mb3 mb4 4 :=
        DetExecAt.writeWordLocal 1 inp mb3 28 (.lit 14) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
      let InvC : ℕ → ArithRAMMemory → Prop := fun i m =>
        (∀ t idx, wRead m t idx = wRead mem t idx) ∧
        (∀ t idx, rRead m t idx = rRead mem t idx) ∧
        (∀ v, v ≠ 28 → ∀ idx, wReadL 1 m v idx = wReadL 1 mem v idx) ∧
        (∀ v idx, rReadL 1 m v idx = rReadL 1 mem v idx) ∧
        wReadL 1 m 28 20 = (s : ℤ) ∧
        wReadL 1 m 28 21 = (q : ℤ) ∧
        wReadL 1 m 28 2 = gen ∧
        wReadL 1 m 28 15 = (S.card : ℤ) ∧
        ∃ off < 2 ^ i,
          wReadL 1 m 28 3 = ((2 ^ i + off : ℕ) : ℤ) ∧
          wReadL 1 m 28 7 = ((off * 2 ^ (K - i) : ℕ) : ℤ) ∧
          wReadL 1 m 28 8 = ((2 ^ (K - i) : ℕ) : ℤ) ∧
          wReadL 1 m 28 14 = (((S.filter (· < off * 2 ^ (K - i))).card : ℕ) : ℤ) ∧
          off * 2 ^ (K - i) ≤ q ∧ q < (off + 1) * 2 ^ (K - i)
      have hInvC0 : InvC 0 mb4 := by
        refine ⟨fun t idx => by simp [mb4, mb3, mb2, mb1, m3, m2, m1],
          fun t idx => by simp [mb4, mb3, mb2, mb1, m3, m2, m1],
          fun v hv idx => by simp [mb4, mb3, mb2, mb1, m3, m2, m1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv)],
          fun v idx => by simp [mb4, mb3, mb2, mb1, m3, m2, m1],
          by simp [mb4, mb3, mb2, mb1, m3, m2, m1, hs_reg,
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 14)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 8)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 7)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 15)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 5)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 2))],
          by simp [mb4, mb3, mb2, mb1, m3, m2, m1, hq_reg,
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 14)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 8)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 7)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 3)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 15)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 5)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 2))],
          by simp [mb4, mb3, mb2, mb1, m3, m2, m1,
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 14)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 8)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 7)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 15)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5))],
          by simp [mb4, mb3, mb2, mb1, m3,
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 14)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 8)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 7)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 3))],
          0, by simp,
          by simp [mb4, mb3, mb2, mb1,
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 14)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 8)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 7))],
          by simp [mb4, mb3, mb2,
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 14)),
                wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 8))],
          by simp [mb4, mb3, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (8 : ℤ) ≠ 14))],
          by simp [mb4], by simp, by simpa using hq_lt⟩
      have hStepC : ∀ i < K, ∀ m, InvC i m →
          ∃ m', DetExecAt 1 inp (countLtStepStmt K) m m' 85 ∧ InvC (i + 1) m' := by
        intro i hi_lt m hIm
        rcases hIm with ⟨hw_m, hr_m, hlv_m, hrl_m, hm20, hm21, hm2, hm15,
          off, hoff, hm3, hm7, hm8, hm14, hq_lo, hq_hi⟩
        let r' := K - (i + 1)
        have hKi_eq : K - i = r' + 1 := by omega
        have hK_r' : K - r' = i + 1 := by omega
        have hhalf_eq : 2 ^ (K - i) / 2 = 2 ^ r' := by
          rw [hKi_eq, pow_succ', Nat.mul_div_cancel_left _ (by decide : 0 < 2)]
        let mc1 := wWriteL 1 m 28 9 ((2 ^ r' : ℕ) : ℤ)
        have hc1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 9) (.div (.readLocal 28 (.lit 8)) (.lit 2))) m mc1 8 := by
          refine DetExecAt.writeWordLocal 1 inp m 28 (.lit 9) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
          simp only [iValAt_div, iValAt_readLocal, iValAt_lit, hm8]
          exact_mod_cast hhalf_eq
        have hmid_eq : off * 2 ^ (K - i) + 2 ^ r' = (2 * off + 1) * 2 ^ r' := by
          rw [hKi_eq, pow_succ]; ring
        by_cases hmid_le : (2 * off + 1) * 2 ^ r' ≤ q
        · have hcond : cValAt 1 inp mc1
              (.intLe (.add (.readLocal 28 (.lit 7)) (.readLocal 28 (.lit 9))) (.readLocal 28 (.lit 21))) = true := by
            simp only [mc1, cValAt_intLe, iValAt_add, iValAt_readLocal, iValAt_lit,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 9)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 9)),
              hm7, hm21, wReadL_wWriteL_self, decide_eq_true_eq]
            have : off * 2 ^ (K - i) + 2 ^ r' ≤ q := by omega
            exact_mod_cast this
          have h2u_eq : 2 * (2 ^ i + off) = 2 ^ (i + 1) + 2 * off := by rw [pow_succ']; ring
          have hNodeL := (hEnc.2.2 r' (by omega) (2 * off) (by rw [hK_r', pow_succ']; omega)).1
          dsimp only [effSegCnt] at hNodeL
          rw [hK_r'] at hNodeL
          let baseL : ℤ := ((s * 2 ^ (K + 1) + (2 ^ (i + 1) + 2 * off) : ℕ) : ℤ)
          let cntL : ℕ := (segSubSet S r' (2 * off)).card
          let mt1 := wWriteL 1 mc1 28 5 baseL
          let mt2 := wWriteL 1 mt1 28 6 (cntL : ℤ)
          let mt3 := wWriteL 1 mt2 28 14 (((S.filter (· < (2 * off + 1) * 2 ^ r')).card : ℕ) : ℤ)
          let mt4 := wWriteL 1 mt3 28 3 ((2 ^ (i + 1) + (2 * off + 1) : ℕ) : ℤ)
          let mt5 := wWriteL 1 mt4 28 7 (((2 * off + 1) * 2 ^ r' : ℕ) : ℤ)
          let mt6 := wWriteL 1 mt5 28 8 ((2 ^ r' : ℕ) : ℤ)
          have ht1 : DetExecAt 1 inp
              (.writeWordLocal 28 (.lit 5) (.add (.mul (.readLocal 28 (.lit 20)) (.lit ((2 ^ (K + 1) : ℕ) : ℤ))) (.mul (.lit 2) (.readLocal 28 (.lit 3)))))
              mc1 mt1 12 := by
            refine DetExecAt.writeWordLocal 1 inp mc1 28 (.lit 5) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
            simp only [mc1, iValAt_add, iValAt_mul, iValAt_readLocal, iValAt_lit,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 9)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 9)), hm20, hm3]
            dsimp [baseL]; exact_mod_cast congrArg (s * 2 ^ (K + 1) + ·) h2u_eq
          have ht2 : DetExecAt 1 inp
              (.ite (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2)))
                (.writeWordLocal 28 (.lit 6) (.readHeap 9 (.readLocal 28 (.lit 5))))
                (.writeWordLocal 28 (.lit 6) (.lit 0))) mt1 mt2 18 := by
            by_cases hv : wRead mem 8 baseL = gen
            · have hc' : cValAt 1 inp mt1 (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2))) = true := by
                simp [mt1, mc1, hw_m, hm2, hv,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 9))]
              simp only [baseL, gen, hv, ↓reduceIte] at hNodeL
              have hb' : DetExecAt 1 inp (.writeWordLocal 28 (.lit 6) (.readHeap 9 (.readLocal 28 (.lit 5)))) mt1 mt2 6 :=
                DetExecAt.writeWordLocal 1 inp mt1 28 (.lit 6) _ rfl (by simp only [iValAt_readHeap, iValAt_readLocal, iValAt_lit, mt1, mc1, wReadL_wWriteL_eq, wRead_wWriteL, hw_m]; simpa [baseL, cntL] using hNodeL) (by simp [intExprOps, realExprOps, condExprOps])
              exact (DetExecAt.ite_true hc' (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) hb').mono_cost (by omega)
            · have hc' : cValAt 1 inp mt1 (.intEq (.readHeap 8 (.readLocal 28 (.lit 5))) (.readLocal 28 (.lit 2))) = false := by
                simp [mt1, mc1, hw_m, hm2, hv,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 9))]
              simp only [baseL, gen, hv, ↓reduceIte] at hNodeL
              have hb' : DetExecAt 1 inp (.writeWordLocal 28 (.lit 6) (.lit 0)) mt1 mt2 4 :=
                DetExecAt.writeWordLocal 1 inp mt1 28 (.lit 6) _ rfl (by simp [cntL, ← hNodeL]) (by simp [intExprOps, realExprOps, condExprOps])
              exact (DetExecAt.ite_false hc' (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) hb').mono_cost (by omega)
          have ht3 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 14) (.add (.readLocal 28 (.lit 14)) (.readLocal 28 (.lit 6)))) mt2 mt3 8 := by
            refine DetExecAt.writeWordLocal 1 inp mt2 28 (.lit 14) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
            simp only [mt2, mt1, mc1, iValAt_add, iValAt_readLocal, iValAt_lit,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (14 : ℤ) ≠ 6)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (14 : ℤ) ≠ 5)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (14 : ℤ) ≠ 9)), hm14, wReadL_wWriteL_self]
            have hfc := filter_lt_split_card S r' off
            rw [← hKi_eq] at hfc
            dsimp [cntL] at *
            omega
          have ht4 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 3) (.add (.mul (.lit 2) (.readLocal 28 (.lit 3))) (.lit 1))) mt3 mt4 10 := by
            refine DetExecAt.writeWordLocal 1 inp mt3 28 (.lit 3) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
            simp only [mt3, mt2, mt1, mc1, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 14)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 6)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 5)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 9)), hm3]
            omega
          have ht5 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 7) (.add (.readLocal 28 (.lit 7)) (.readLocal 28 (.lit 9)))) mt4 mt5 8 := by
            refine DetExecAt.writeWordLocal 1 inp mt4 28 (.lit 7) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
            simp only [mt4, mt3, mt2, mt1, mc1, iValAt_add, iValAt_readLocal, iValAt_lit,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 3)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 14)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 6)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 5)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 9)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 3)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 14)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 6)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 5)),
              hm7, wReadL_wWriteL_self]
            rw [← hmid_eq]; push_cast; ring
          have ht6 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 8) (.readLocal 28 (.lit 9))) mt5 mt6 6 := by
            refine DetExecAt.writeWordLocal 1 inp mt5 28 (.lit 8) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
            simp [mt5, mt4, mt3, mt2, mt1, mc1,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 7)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 3)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 14)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 6)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 5))]
          refine ⟨mt6, (hc1.seq (DetExecAt.ite_true hcond (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) (ht1.seq (ht2.seq (ht3.seq (ht4.seq (ht5.seq ht6))))))).mono_cost (by omega),
            fun t idx => by simp [mt6, mt5, mt4, mt3, mt2, mt1, mc1, hw_m],
            fun t idx => by simp [mt6, mt5, mt4, mt3, mt2, mt1, mc1, hr_m],
            fun v hv idx => by simp [mt6, mt5, mt4, mt3, mt2, mt1, mc1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv), hlv_m v hv],
            fun v idx => by simp [mt6, mt5, mt4, mt3, mt2, mt1, mc1, hrl_m],
            by simp [mt6, mt5, mt4, mt3, mt2, mt1, mc1, hm20,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 8)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 7)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 14)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 6)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 5)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 9))],
            by simp [mt6, mt5, mt4, mt3, mt2, mt1, mc1, hm21,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 8)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 7)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 3)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 14)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 6)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 5)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 9))],
            by simp [mt6, mt5, mt4, mt3, mt2, mt1, mc1, hm2,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 8)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 7)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 14)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 6)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 5)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 9))],
            by simp [mt6, mt5, mt4, mt3, mt2, mt1, mc1, hm15,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 8)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 7)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 3)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 14)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 6)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 5)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 9))],
            2 * off + 1, by rw [pow_succ']; omega,
            by simp [mt6, mt5, mt4,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 8)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 7))],
            by simp [mt6, mt5, r'],
            by simp [mt6, r'],
            by simp [mt6, mt5, mt4, mt3, r'],
            hmid_le, ?_⟩
          have hhi_eq : (2 * off + 1 + 1) * 2 ^ (K - (i + 1)) = (off + 1) * 2 ^ (K - i) := by
            change (2 * off + 1 + 1) * 2 ^ r' = (off + 1) * 2 ^ (K - i)
            rw [hKi_eq, pow_succ]; ring
          omega
        · have hmid_gt : q < (2 * off + 1) * 2 ^ r' := not_le.mp hmid_le
          have hcond : cValAt 1 inp mc1
              (.intLe (.add (.readLocal 28 (.lit 7)) (.readLocal 28 (.lit 9))) (.readLocal 28 (.lit 21))) = false := by
            simp only [mc1, cValAt_intLe, iValAt_add, iValAt_readLocal, iValAt_lit,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (7 : ℤ) ≠ 9)),
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 9)),
              hm7, hm21, wReadL_wWriteL_self, decide_eq_false_iff_not]
            have : ¬ (off * 2 ^ (K - i) + 2 ^ r' ≤ q) := by omega
            exact_mod_cast this
          have h2u_eq : 2 * (2 ^ i + off) = 2 ^ (i + 1) + 2 * off := by rw [pow_succ']; ring
          have hlo_eq : (2 * off) * 2 ^ r' = off * 2 ^ (K - i) := by
            rw [hKi_eq, pow_succ]; ring
          let mf1 := wWriteL 1 mc1 28 3 ((2 ^ (i + 1) + 2 * off : ℕ) : ℤ)
          let mf2 := wWriteL 1 mf1 28 8 ((2 ^ r' : ℕ) : ℤ)
          have hf1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 3) (.mul (.lit 2) (.readLocal 28 (.lit 3)))) mc1 mf1 8 := by
            refine DetExecAt.writeWordLocal 1 inp mc1 28 (.lit 3) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
            simp only [mc1, iValAt_mul, iValAt_lit, iValAt_readLocal,
              wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 9)), hm3]
            rw [← h2u_eq]; push_cast; ring
          have hf2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 8) (.readLocal 28 (.lit 9))) mf1 mf2 6 := by
            refine DetExecAt.writeWordLocal 1 inp mf1 28 (.lit 8) _ rfl ?_ (by simp [intExprOps, realExprOps, condExprOps])
            simp [mf1, mc1, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (9 : ℤ) ≠ 3))]
          refine ⟨mf2, (hc1.seq (DetExecAt.ite_false hcond (C_c := 10) (by simp [intExprOps, realExprOps, condExprOps]) (hf1.seq hf2))).mono_cost (by omega),
            fun t idx => by simp [mf2, mf1, mc1, hw_m],
            fun t idx => by simp [mf2, mf1, mc1, hr_m],
            fun v hv idx => by simp [mf2, mf1, mc1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv), hlv_m v hv],
            fun v idx => by simp [mf2, mf1, mc1, hrl_m],
            by simp [mf2, mf1, mc1, hm20,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 8)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 3)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 9))],
            by simp [mf2, mf1, mc1, hm21,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 8)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 3)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (21 : ℤ) ≠ 9))],
            by simp [mf2, mf1, mc1, hm2,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 8)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 3)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (2 : ℤ) ≠ 9))],
            by simp [mf2, mf1, mc1, hm15,
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 8)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 3)),
                  wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (15 : ℤ) ≠ 9))],
            2 * off, by rw [pow_succ']; omega,
            by simp [mf2, mf1, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (3 : ℤ) ≠ 8))],
            by dsimp [r'] at hlo_eq; simp only [mf2, mf1, mc1, wReadL_wWriteL_eq]; simp [hm7, hlo_eq],
            by simp [mf2, r'],
            by dsimp [r'] at hlo_eq; simp only [mf2, mf1, mc1, wReadL_wWriteL_eq]; simp [hm14, hlo_eq],
            by rw [hlo_eq]; exact hq_lo, hmid_gt⟩
      rcases DetExecAt.repeatN_nat (.lit (K : ℤ)) (countLtStepStmt K) K 1 85
          InvC hInvC0 rfl (by simp [intExprOps, realExprOps, condExprOps]) hStepC with ⟨mCK, hInvCK, hrepC⟩
      rcases hInvCK with ⟨hwCK, hrCK, hlvCK, hrlCK, hm20K, _, _, hm15K, offK, _, _, _, _, hm14K, hloK, hhiK⟩
      rw [Nat.sub_self, pow_zero, mul_one] at hm14K hloK hhiK
      have hoff_eq_q : offK = q := by omega
      subst hoff_eq_q
      have hbr := hb1.seq (hb2.seq (hb3.seq (hb4.seq hrepC)))
      exact ⟨mCK, (DetExecAt.ite_false hc (C_c := 8) (by simp [intExprOps, realExprOps, condExprOps]) hbr).mono_cost (by omega),
        hwCK, hrCK, hlvCK, hrlCK, hm20K, hm15K, hm14K⟩
  rcases hPhaseA with ⟨mA, hexA, hwA, hrA, hlvA, hrlA, hm20A, hm15A, hm14A⟩
  -- Phase B: compare c_lt against S.card
  by_cases hc_lt_tot : c_lt < S.card
  · have hcondB : cValAt 1 inp mA (.intLt (.readLocal 28 (.lit 14)) (.readLocal 28 (.lit 15))) = true := by
      simp [hm14A, hm15A, hc_lt_tot]
    let mB1 := wWriteL 1 mA 28 21 (c_lt : ℤ)
    have hbB1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readLocal 28 (.lit 14))) mA mB1 6 :=
      DetExecAt.writeWordLocal 1 inp mA 28 (.lit 21) _ rfl (by simp [hm14A]) (by simp [intExprOps, realExprOps, condExprOps])
    have hEnc_mB1 : EncSegSlot K mB1 s S fSq :=
      hEnc.congr_mem_fSq (by simp [mB1, hwA])
        (fun _ _ => by simp [mB1, hwA]) (fun _ _ => by simp [mB1, hwA])
        (fun _ _ => by simp [mB1, hwA]) (fun _ _ => by simp [mB1, hrA])
        (fun _ _ => rfl)
    rcases exec_selectByRankSegStmt inp mB1 hc_lt_tot
        (by simp [mB1, hm20A, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (20 : ℤ) ≠ 21))])
        (by simp [mB1]) hEnc_mB1 with ⟨mB2, hexSel, hm0_B2, hwB2, hrB2, hlvB2, hrlB2⟩
    let mB3 := wWriteL 1 mB2 28 1 1
    have hbB3 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 1) (.lit 1)) mB2 mB3 4 :=
      DetExecAt.writeWordLocal 1 inp mB2 28 (.lit 1) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
    -- hiteB inlined
    let y : ℕ := (S.orderEmbOfFin rfl ⟨c_lt, hc_lt_tot⟩)
    have hy_in : y ∈ S := Finset.orderEmbOfFin_mem S rfl ⟨c_lt, hc_lt_tot⟩
    -- (S.filter (· < y)).card = c_lt
    have hy_card : (S.filter (· < y)).card = c_lt :=
      card_filter_lt_orderEmbOfFin ⟨c_lt, hc_lt_tot⟩
    rcases succ_of_card_filter_lt_eq hy_in hy_card with ⟨hqy, hy_min⟩
    refine ⟨mB3, (hs1.seq (hs2.seq (hs3.seq (hexA.seq (DetExecAt.ite_true hcondB (C_c := 8) (by simp [intExprOps, realExprOps, condExprOps]) (hbB1.seq (hexSel.seq hbB3))))))).mono_cost (by omega),
      fun _ => ⟨by simp [mB3], y, hy_in,
        by simp [mB3, hm0_B2, y, wReadL_wWriteL_of_ne 1 _ _ (Or.inr (by decide : (0 : ℤ) ≠ 1))],
        hqy, hy_min⟩,
      fun hall => ?_,
      fun t idx => by simp [mB3, hwB2, mB1, hwA],
      fun t idx => by simp [mB3, hrB2, mB1, hrA],
      fun v hv idx => by simp [mB3, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv), hlvB2 v hv, mB1, hlvA v hv],
      fun v idx => by simp [mB3, hrlB2, mB1, hrlA]⟩
    exact False.elim (lt_irrefl q (lt_of_le_of_lt hqy (hall y hy_in)))
  · have hc_eq_tot : c_lt = S.card :=
      le_antisymm (Finset.card_filter_le S _) (not_lt.mp hc_lt_tot)
    have hcondB : cValAt 1 inp mA (.intLt (.readLocal 28 (.lit 14)) (.readLocal 28 (.lit 15))) = false := by
      simp [hm14A, hm15A, hc_lt_tot]
    let mB1 := wWriteL 1 mA 28 0 0
    let mB2 := wWriteL 1 mB1 28 1 0
    have hbB1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 0) (.lit 0)) mA mB1 4 :=
      DetExecAt.writeWordLocal 1 inp mA 28 (.lit 0) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
    have hbB2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 1) (.lit 0)) mB1 mB2 4 :=
      DetExecAt.writeWordLocal 1 inp mB1 28 (.lit 1) _ rfl rfl (by simp [intExprOps, realExprOps, condExprOps])
    have hall_lt := all_lt_of_card_filter_lt_eq_card hc_eq_tot
    refine ⟨mB2, (hs1.seq (hs2.seq (hs3.seq (hexA.seq (DetExecAt.ite_false hcondB (C_c := 8) (by simp [intExprOps, realExprOps, condExprOps]) (hbB1.seq hbB2)))))).mono_cost (by omega),
      fun ⟨x, hxS, hqx⟩ => False.elim (not_lt_of_ge hqx (hall_lt x hxS)),
      fun _ => by simp [mB2],
      fun t idx => by simp [mB2, mB1, hwA],
      fun t idx => by simp [mB2, mB1, hrA],
      fun v hv idx => by simp [mB2, mB1, wReadL_wWriteL_of_ne 1 _ _ (Or.inl hv), hlvA v hv],
      fun v idx => by simp [mB2, mB1, hrlA]⟩

end UL.Proof_lem_7_2_RacerP46
