import UL.Proof.lem_7_2.CG18_JobTickA1

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### Stage 3 (`activeJobDeadlineStmt` + `exec_activeJobDeadlineStmt`) -/

def activeJobDeadlineStmt (d D₀ M_box : ℕ) (cfg : ChainHdrCfg) : ArithRAMStmt :=
  let rE : IntExpr := .readHeap 26 (.lit 15)
  .ite (.intEq (cfg.jobRem.readE rE) (.lit 0))
    (seqList [
      deadlineSuffixSwapStmt d D₀ M_box cfg,
      boxWriteW M_box 26 (.lit 27) (.lit 1),
      .localScope .skip
    ])
    .skip

def activeJobDeadlineCost (d D₀ : ℕ) : ℕ :=
  deadlineSuffixSwapCost d D₀ + 80

theorem boxSafe_activeJobDeadlineStmt {T_max M_box : ℕ} {cfg : ChainHdrCfg}
    (hV : cfg.Valid T_max) (d D₀ : ℕ) :
    BoxSafeOuter T_max M_box (activeJobDeadlineStmt d D₀ M_box cfg) := by
  have hT28 := hV.1
  refine .ite _ (boxSafeOuter_seqList ?_) .skip
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl
  · exact boxSafe_deadlineSuffixSwapStmt hV d D₀
  · exact .boxW (by omega) _ _
  · exact .localScope .skip

theorem preservesPoolWords_copyCenterCoordsToSnStmt (d M_box rSnCenterO : ℕ) :
    preservesPoolWords (copyCenterCoordsToSnStmt d M_box rSnCenterO) = true := by
  unfold copyCenterCoordsToSnStmt loadHeapCoordsToLocalStmt storeLocalCoordsToHeapStmt
  simp

@[simp] lemma cg18_preservesPoolWords_1_5 (M_box : ℕ) (v : IntExpr) :
    preservesPoolWords (boxWriteW M_box 1 (.lit 5) v) = true := by
  simp [preservesPoolWords, isLitGe3]

@[simp] lemma cg18_preservesPoolWords_1_6 (M_box : ℕ) (v : IntExpr) :
    preservesPoolWords (boxWriteW M_box 1 (.lit 6) v) = true := by
  simp [preservesPoolWords, isLitGe3]

theorem preservesPoolWords_deadlineSuffixSwapStmt (d D₀ M_box : ℕ) :
    preservesPoolWords (deadlineSuffixSwapStmt d D₀ M_box defaultChainHdrCfg) = true := by
  unfold deadlineSuffixSwapStmt swapOneJobLevelIterStmt defaultChainHdrCfg HdrField.writeW HdrField.writeR
  simp [preservesPoolWords_copyCenterCoordsToSnStmt, cg01_preservesPoolWords_boxWriteW_of_ne]

theorem preservesPoolWords_activeJobDeadlineStmt (d D₀ M_box : ℕ) :
    preservesPoolWords (activeJobDeadlineStmt d D₀ M_box defaultChainHdrCfg) = true := by
  unfold activeJobDeadlineStmt
  simp [preservesPoolWords_deadlineSuffixSwapStmt]

theorem exec_activeJobDeadlineStmt
    (h_lem_C_2 : S_lem_C_2)
    (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    (hcfg : ctx.cfg = defaultChainHdrCfg)
    {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k) {m : ArithRAMMemory}
    {g' : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u ⟨i, hi⟩)}
    (hpop : m.popDepth 0 = m)
    (hw15 : wRead m 26 15 = (i : ℤ))
    (hSt : PostEndActionJobState ctx gFlag i hi m g') :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (activeJobDeadlineStmt ctx.d ctx.p.D₀ ctx.M_box ctx.cfg) m m'
        (activeJobDeadlineCost ctx.d ctx.p.D₀) ∧
      m'.popDepth 0 = m' ∧
      wRead m' 0 0 = wRead m 0 0 ∧
      wRead m' 26 13 = wRead m 26 13 ∧
      wRead m' 26 14 = wRead m 26 14 ∧
      wRead m' 26 15 = (i : ℤ) ∧
      wRead m' 26 28 = wRead m 26 28 ∧
      (MidLoopUncut ctx false (i + 1) m' ∨ MidLoopCut ctx false m') ∧
      (gFlag = true → (MidLoopUncut ctx true (i + 1) m' ∨ MidLoopCut ctx true m')) := by
  classical
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let condE : ArithCondExpr := .intEq (ctx.cfg.jobRem.readE rE) (.lit 0)
  have hcond_ops : condExprOps condE ≤ 25 := by
    dsimp only [condE, rE]
    rw [hcfg]
    simp [defaultChainHdrCfg, HdrField.readE, HdrField.idxE, condExprOps, intExprOps]
  rcases hSt.hOwn_i with ⟨hw16_i, hwRem_i, hwCl_i, hw19_i, lvs_h, hlen_eq, hlv_all⟩
  have hrem_eval : iValAt 0 inp m (ctx.cfg.jobRem.readE rE) = (((g'.H_job - g'.t_cur : ℕ) : ℤ)) := by
    dsimp only [rE]
    simp only [HdrField.readE, HdrField.idxE, iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, hw15]
    have hidx : (((ctx.cfg.jobRem.stride : ℤ) * (i : ℤ) + (ctx.cfg.jobRem.off : ℤ)) : ℤ) =
        ((ctx.cfg.jobRem.idx i : ℕ) : ℤ) := by unfold HdrField.idx; push_cast; rfl
    rw [hidx, hwRem_i]
  by_cases hrem_zero : g'.H_job - g'.t_cur = 0
  · -- Deadline branch (`g'.t_cur = g'.H_job`):
    have hdone : g'.t_cur = g'.H_job := by have := g'.ht_le; omega
    have hc_true : cValAt 0 inp m condE = true := by
      simp only [condE, cValAt, evalArithCond]
      change decide (iValAt 0 inp m (ctx.cfg.jobRem.readE rE) = iValAt 0 inp m (.lit 0)) = true
      rw [hrem_eval, hrem_zero]; rfl
    rcases hSt.deadline_pure h_lem_C_2 hdone
      with ⟨hph2_g', st_mid, hu_eq, hk_eq, hk_lt_D0, hNodesInv, hTerm_le, hGood_mid,
        hPrePure, hSufPure, hTermPure⟩
    let jLen := g'.lvs.length
    have hjLen_pos : 1 ≤ jLen := g'.hlvs_pos
    have hr_add_le : i + jLen ≤ ctx.p.D₀ := by rw [← hk_eq]; exact le_of_lt hk_lt_D0
    have hph2_all : ∀ (j : ℕ) (hj : j < lvs_h.length),
        wRead m 24 (((2 * (i * ctx.p.D₀ + j) + 0 : ℕ) : ℤ)) = 2 := by
      intro j hj
      rcases hlv_all j hj with ⟨_, _, _, _, _, _, _, _, _, _, hpre2, hlast⟩
      by_cases hlt_len : j + 1 < lvs_h.length
      · exact hpre2 hlt_len
      · have heq_len : j + 1 = lvs_h.length := by omega
        rw [(hlast heq_len).1, hph2_g']; rfl
    have hlv_hdr : ∀ (j : ℕ) (hj : j < lvs_h.length),
        let idx := i * ctx.p.D₀ + j
        let ball := (lvs_h[j]'hj).ball (ctx.d + 3)
        wRead m 23 (((8 * idx + 0 : ℕ) : ℤ)) = ((lvs_h[j]'hj).S_birth.card : ℤ) ∧
        wRead m 23 (((8 * idx + 7 : ℕ) : ℤ)) = ((lvs_h[j]'hj).openRem : ℤ) ∧
        rRead m 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V ∧
        (∀ c : Fin ctx.d, rRead m 23 (((idx * ctx.d + c.val : ℕ) : ℤ)) = euclideanCoord ball.o c) := by
      intro j hj idx ball
      rcases hlv_all j hj with ⟨_, hor_eq, _, hEnc_j, hw7_j, _⟩
      have hph2_j := hph2_all j hj
      rcases hEnc_j with ⟨_, _, _, _, _, _, _, _, _, _,
        _, _, _, _, _, _, _, _, _, _,
        _, _, _, _, _, _, _, _, _, _,
        _, hw0_j, _, _, hr_o_j, hPh_j⟩
      have hbo : ball.o = (lvs_h[j]'hj).prov.o := by
        dsimp only [ball, JobLvData.ball]; unfold applyBirthCoreFallback; split_ifs <;> rfl
      have hrV_j : rRead m 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V := by
        rcases hPh_j with ⟨_, _, h0, _⟩ | ⟨_, _, h1, _⟩ | ⟨_, hrV, _⟩
        · omega
        · omega
        · exact hrV
      exact ⟨hw0_j, hor_eq ▸ hw7_j, hrV_j, fun c => hbo ▸ hr_o_j c⟩
    rcases exec_deadlineSuffixSwapStmt ctx.hV inp m lvs_h (ctx.d + 3)
        hlen_eq hjLen_pos hr_add_le ctx.hBox30 ctx.hBox_hdr ctx.hBox_snO hw15 hw19_i hlv_hdr
      with ⟨m_sw, e_sw, hpop_sw, hw1_5_sw, hw1_6_sw, hsuf_sw, hpre_sw, hw_not_sw, hw1_not_sw, hw26_sw, hr_not_sw⟩
    let m1 := wWrite m_sw 26 27 1
    have e_27 : DetExecAt 0 inp (boxWriteW ctx.M_box 26 (.lit 27) (.lit 1)) m_sw m1 16 :=
      exec_boxWriteW inp m_sw _ _ rfl (by omega) (by have := ctx.hBox30; omega) rfl (by simp [intExprOps])
    have e_sc := exec_popScopeZero inp m1
    obtain ⟨m', hm'_def⟩ : ∃ x, x = m1.popDepth 0 := ⟨_, rfl⟩
    have hpop' : m'.popDepth 0 = m' := hm'_def ▸ popDepth_zero_idem m1
    have e_true : DetExecAt 0 inp
        (seqList [deadlineSuffixSwapStmt ctx.d ctx.p.D₀ ctx.M_box ctx.cfg,
          boxWriteW ctx.M_box 26 (.lit 27) (.lit 1), .localScope .skip])
        m m' (deadlineSuffixSwapCost ctx.d ctx.p.D₀ + 20) :=
      hm'_def ▸ (e_sw.seq (e_27.seq e_sc)).mono_cost (by omega)
    have e_full : DetExecAt 0 inp (activeJobDeadlineStmt ctx.d ctx.p.D₀ ctx.M_box ctx.cfg)
        m m' (activeJobDeadlineCost ctx.d ctx.p.D₀) := by
      unfold activeJobDeadlineStmt activeJobDeadlineCost
      exact (DetExecAt.ite_true hc_true hcond_ops e_true).mono_cost (by omega)
    have hw_m'_sw : ∀ t, t ≠ 26 → ∀ idx, wRead m' t idx = wRead m_sw t idx := by
      intro t ht idx; rw [hm'_def]; dsimp only [m1]; rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inl ht)]
    have hr_m'_sw : ∀ t idx, rRead m' t idx = rRead m_sw t idx := by
      intro t idx; rw [hm'_def]; dsimp only [m1]; rw [rRead_popDepth, rRead_wWrite]
    have hw27' : wRead m' 26 27 = 1 := by rw [hm'_def]; dsimp only [m1]; simp
    have hw26_m'_m : ∀ idx : ℤ, idx ≠ 16 → idx ≠ 17 → idx ≠ 18 → idx ≠ 27 →
        wRead m' 26 idx = wRead m 26 idx := by
      intro idx h16 h17 h18 h27
      rw [hm'_def]; dsimp only [m1]
      rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inr h27), hw26_sw idx h16 h17 h18]
    clear hm'_def e_sc e_27 m1 e_sw
    have hw_static : ∀ t ∈ ({0, 5, 6, 8, 9, 10, 11, 17, 18, 19, 23, 24} : Finset ℕ),
        ∀ idx, wRead m' t idx = wRead m t idx := by
      intro t ht idx
      simp only [Finset.mem_insert, Finset.mem_singleton] at ht
      rcases ht with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;> {
        rw [hw_m'_sw _ (by decide)]
        refine hw_not_sw _ (by decide) (by decide) (by decide) (by decide) (by decide) ?_ ?_ ?_ idx
        · rw [hcfg]; decide
        · rw [hcfg]; decide
        · rw [hcfg]; decide
      }
    have hr_static : ∀ t ∈ ({4, 8, 11, 23, 24} : Finset ℕ),
        ∀ idx, rRead m' t idx = rRead m t idx := by
      intro t ht idx
      simp only [Finset.mem_insert, Finset.mem_singleton] at ht
      rcases ht with rfl | rfl | rfl | rfl | rfl <;> {
        rw [hr_m'_sw]
        refine hr_not_sw _ ?_ ?_ idx
        · rw [hcfg]; decide
        · rw [hcfg]; decide
      }
    have hw1_3 : wRead m' 1 3 = wRead m 1 3 := by
      rw [hw_m'_sw 1 (by decide), hw1_not_sw 3 (by decide) (by decide)]
    have hSeg' : SegGenBound ctx.p.K_seg ctx.p.NumSlots m' :=
      ⟨by rw [hw1_3]; exact hSt.hSeg.1,
       fun s hs => by rw [hw_static 5 (by decide), hw1_3]; exact hSt.hSeg.2.1 s hs,
       fun s hs u hu => by rw [hw_static 8 (by decide), hw1_3]; exact hSt.hSeg.2.2 s hs u hu⟩
    have hSave' : SaveGenBound ctx.n ctx.p.NumSlots m' :=
      ⟨by rw [hw1_3]; exact hSt.hSave.1,
       fun s hs => by rw [hw_static 6 (by decide), hw1_3]; exact hSt.hSave.2.1 s hs,
       fun s hs h hh => by rw [hw_static 11 (by decide), hw1_3]; exact hSt.hSave.2.2 s hs h hh⟩
    have hLive' : EncLiveCoords ctx.d ctx.n m' ctx.P'.activeHandles ctx.P'.handleCoords :=
      ⟨hSt.hLive.1, fun h hh c => by rw [hr_static 4 (by decide)]; exact hSt.hLive.2 h hh c⟩
    have hSegPres : ∀ s < ctx.p.NumSlots, ∀ S₁ fSq₁,
        EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁ :=
      fun _ _ _ _ hE => hE.congr_mem_fSq
        (hw_static 5 (by decide) _) (fun _ _ => hw_static 8 (by decide) _)
        (fun _ _ => hw_static 9 (by decide) _) (fun _ _ => hw_static 10 (by decide) _)
        (fun _ _ => hr_static 8 (by decide) _) (fun _ _ => rfl)
    let jLast := jLen - 1
    have hjLast_g : jLast < jLen := Nat.sub_lt hjLen_pos Nat.one_pos
    have hjLast_h : jLast < lvs_h.length := hlen_eq.symm ▸ hjLast_g
    let lastIdx := i * ctx.p.D₀ + jLast
    rcases hlv_all jLast hjLast_h with ⟨_, _, _, hEnc_last, _, _, _, _, hp5_last, _⟩
    have hph2_last := hph2_all jLast hjLast_h
    rcases hEnc_last with ⟨_, _, _, rS_L, _, _, _, _, hrS_L_lt, _,
      _, _, _, _, _, _, _, _, _, _,
      _, _, _, hw_rS_L, _, _, _, _, h6_rS_L, _,
      _, _, _, _, _, hPh_L⟩
    have hrS_L_pos : 0 < rS_L := by rw [hw_rS_L] at hp5_last; simpa using hp5_last
    have hSeg_rS_L_m : EncSegSlot ctx.p.K_seg m rS_L
        (((lvs_h[jLast]'hjLast_h).ball (ctx.d + 3)).residual ctx.P'.handleCoords
          (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) jLast))
        (fun _ => 0) := by
      rcases hPh_L with ⟨_, _, h0, _⟩ | ⟨_, _, h1, _⟩ | ⟨_, _, _, _, hEr, _⟩
      · omega
      · omega
      · exact hEr
    have hTerm_set_eq :
        ((lvs_h[jLast]'hjLast_h).ball (ctx.d + 3)).residual ctx.P'.handleCoords
          (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) jLast) =
        chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles := by
      have h1 := (jobHandleInput_succ (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) hjLast_h).symm
      have hj1 : jLast + 1 = lvs_h.length := by
        change (g'.lvs.length - 1) + 1 = lvs_h.length
        omega
      rw [hj1, hlen_eq] at h1
      have h2 := cg18_jobHandleInput_eq_prefixResidual_take (ctx.d + 3) ctx.P'.handleCoords
        lvs_h g'.lvs (ctx.S_post_h ⟨i, hi⟩) hlen_eq (fun k hk => (hlv_all k hk).1) le_rfl
      rw [hlen_eq, List.take_length] at h2
      exact h1.trans (h2.trans hTermPure.symm)
    have hSegLeaf' : EncSegSlot ctx.p.K_seg m' rS_L
        (chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles) (fun _ => 0) :=
      hTerm_set_eq ▸ hSegPres rS_L hrS_L_lt _ _ hSeg_rS_L_m
    have hw1_5' : wRead m' 1 5 = (st_mid.k : ℤ) := by
      rw [hw_m'_sw 1 (by decide), hw1_5_sw, hk_eq]
    have hw1_6' : wRead m' 1 6 = (rS_L : ℤ) := by
      rw [hw_m'_sw 1 (by decide), hw1_6_sw, hw_rS_L]
    have hsn_suf_sub : ∀ (j : ℕ) (hj : j < jLen),
        let idx := i * ctx.p.D₀ + j
        snSlotSet m' (i + j) ⊆ jobLevelLiveSlots m idx (decide (j + 1 = jLen)) := by
      intro j hj idx s hs
      have hj_h : j < lvs_h.length := hlen_eq.symm ▸ hj
      have hsuf := hsuf_sw j hj_h
      unfold snSlotSet at hs
      rw [hw_m'_sw 14 (by decide), hw_m'_sw 15 (by decide), hsuf.2.2.2.1, hsuf.2.2.2.2.1] at hs
      simp only [Finset.mem_insert, Finset.mem_singleton] at hs
      unfold jobLevelLiveSlots
      dsimp only [idx]
      rcases hs with rfl | rfl <;> (split_ifs <;> simp)
    have hrS_L_in_last : rS_L ∈ jobLevelLiveSlots m lastIdx (decide (jLast + 1 = jLen)) := by
      unfold jobLevelLiveSlots
      rw [hw_rS_L, Int.toNat_natCast]
      split_ifs <;> simp
    have hjLen_toNat : (wRead m 19 (i : ℤ)).toNat = jLen := by
      rw [hw19_i]; exact Int.toNat_natCast jLen
    have hDisj' : GlobalSlotDisj ctx.p.D₀ m' st_mid.k rS_L := by
      rw [hk_eq]
      rcases hSt.hChainRest with ⟨_, _, _, _, _, _, _, hsn0, hsnP, hlv_sn, hlv_lv⟩
      have hsn_pre : ∀ r < i, snSlotSet m' r = snSlotSet m r := fun r hr =>
        snSlotSet_congr_14_15
          (by rw [hw_m'_sw 14 (by decide), (hpre_sw r hr).2.2.2.1])
          (by rw [hw_m'_sw 15 (by decide), (hpre_sw r hr).2.2.2.2.1])
      have h16_pre : ∀ r < i, wRead m' 16 (r : ℤ) = wRead m 16 (r : ℤ) := fun r hr => by
        rw [hw_m'_sw 16 (by decide), (hpre_sw r hr).2.2.2.2.2.1]
      have h16_suf : ∀ j < jLen, wRead m' 16 (((i + j : ℕ) : ℤ)) = 0 := fun j hj => by
        rw [hw_m'_sw 16 (by decide), (hsuf_sw j (hlen_eq.symm ▸ hj)).2.2.2.2.2.1]
      have h19_eq : ∀ r, wRead m' 19 (r : ℤ) = wRead m 19 (r : ℤ) := fun _ => hw_static 19 (by decide) _
      have h23_eq : ∀ idx, wRead m' 23 idx = wRead m 23 idx := fun _ => hw_static 23 (by decide) _
      have hlv_eq : ∀ idx sp, jobLevelLiveSlots m' idx sp = jobLevelLiveSlots m idx sp :=
        fun _ _ => jobLevelLiveSlots_congr_23 (h23_eq _) (h23_eq _) (h23_eq _) (h23_eq _)
      have h16_m'_lt_i : ∀ r < i + jLen, wRead m' 16 (r : ℤ) = 1 → r < i := by
        intro r hr h16
        by_contra hge
        have hj : r - i < jLen := by omega
        have hr_eq : (r : ℤ) = (((i + (r - i) : ℕ) : ℤ)) := by congr 1; omega
        rw [hr_eq, h16_suf (r - i) hj] at h16
        omega
      refine ⟨hrS_L_pos, ?_, ?_, ?_, ?_⟩
      · intro r hr s hs
        by_cases hlt : r < i
        · rw [hsn_pre r hlt] at hs
          have hdisj_last := (hlv_sn i hi hw16_i jLast (hjLen_toNat.symm ▸ hjLast_g)).2 r (lt_trans hlt hi)
          rw [hjLen_toNat] at hdisj_last
          exact ⟨(hsn0 r (lt_trans hlt hi) s hs).1,
            fun heq => Finset.disjoint_right.mp hdisj_last hs (heq ▸ hrS_L_in_last)⟩
        · let j := r - i
          have hj_lt : j < jLen := by dsimp only [j]; omega
          have hr_eq : r = i + j := by dsimp only [j]; omega
          rw [hr_eq] at hs
          have hs_lv := hsn_suf_sub j hj_lt hs
          have hs_ne0 := ((hlv_sn i hi hw16_i j (hjLen_toNat.symm ▸ hj_lt)).1 s
            (by simpa [hjLen_toNat] using hs_lv)).1
          refine ⟨hs_ne0, fun heq => ?_⟩
          by_cases hjj : j = jLast
          · rw [heq, hjj] at hs
            have hsuf_L := hsuf_sw jLast hjLast_h
            unfold snSlotSet at hs
            rw [hw_m'_sw 14 (by decide), hw_m'_sw 15 (by decide),
                hsuf_L.2.2.2.1, hsuf_L.2.2.2.2.1] at hs
            rcases (hlv_all jLast hjLast_h).2.2.2.1 with ⟨bS1, dS1, spDS1, rS1, spRS1,
              _, _, _, _, _, _, _, _, _, _, hdr1, _, hspDr1, _, _,
              _, e3, e4, e5, _, _⟩
            rw [e3, e4] at hs
            have hr_eq1 : rS1 = rS_L := by
              have : (rS1 : ℤ) = (rS_L : ℤ) := e5.symm.trans hw_rS_L
              exact_mod_cast this
            rw [hr_eq1] at hdr1 hspDr1
            simp only [Int.toNat_natCast, Finset.mem_insert, Finset.mem_singleton] at hs
            rcases hs with h1 | h2
            · exact hdr1 h1.symm
            · exact hspDr1 h2.symm
          · have hd_jj := (hlv_lv i hi hw16_i j (hjLen_toNat.symm ▸ hj_lt)
              i hi hw16_i jLast (hjLen_toNat.symm ▸ hjLast_g) (Or.inr hjj)).1
            rw [hjLen_toNat] at hd_jj
            exact Finset.disjoint_left.mp hd_jj (heq ▸ hs_lv) hrS_L_in_last
      · intro r₁ hr₁ r₂ hr₂ hne
        by_cases h1 : r₁ < i <;> by_cases h2 : r₂ < i
        · rw [hsn_pre r₁ h1, hsn_pre r₂ h2]
          exact hsnP r₁ (lt_trans h1 hi) r₂ (lt_trans h2 hi) hne
        · rw [hsn_pre r₁ h1]
          let j₂ := r₂ - i
          have hj₂ : j₂ < jLen := by dsimp only [j₂]; omega
          have hr₂_eq : r₂ = i + j₂ := by dsimp only [j₂]; omega
          rw [hr₂_eq]
          have hd_sn := (hlv_sn i hi hw16_i j₂ (hjLen_toNat.symm ▸ hj₂)).2 r₁ (lt_trans h1 hi)
          rw [hjLen_toNat] at hd_sn
          exact Finset.disjoint_of_subset_right (hsn_suf_sub j₂ hj₂) hd_sn.symm
        · rw [hsn_pre r₂ h2]
          let j₁ := r₁ - i
          have hj₁ : j₁ < jLen := by dsimp only [j₁]; omega
          have hr₁_eq : r₁ = i + j₁ := by dsimp only [j₁]; omega
          rw [hr₁_eq]
          have hd_sn := (hlv_sn i hi hw16_i j₁ (hjLen_toNat.symm ▸ hj₁)).2 r₂ (lt_trans h2 hi)
          rw [hjLen_toNat] at hd_sn
          exact Finset.disjoint_of_subset_left (hsn_suf_sub j₁ hj₁) hd_sn
        · let j₁ := r₁ - i
          let j₂ := r₂ - i
          have hj₁ : j₁ < jLen := by dsimp only [j₁]; omega
          have hj₂ : j₂ < jLen := by dsimp only [j₂]; omega
          have hr₁_eq : r₁ = i + j₁ := by dsimp only [j₁]; omega
          have hr₂_eq : r₂ = i + j₂ := by dsimp only [j₂]; omega
          have hj_ne : j₁ ≠ j₂ := by dsimp only [j₁, j₂]; omega
          rw [hr₁_eq, hr₂_eq]
          have hd_jj := (hlv_lv i hi hw16_i j₁ (hjLen_toNat.symm ▸ hj₁)
            i hi hw16_i j₂ (hjLen_toNat.symm ▸ hj₂) (Or.inr hj_ne)).1
          rw [hjLen_toNat] at hd_jj
          exact Finset.disjoint_of_subset_left (hsn_suf_sub j₁ hj₁)
            (Finset.disjoint_of_subset_right (hsn_suf_sub j₂ hj₂) hd_jj)
      · intro r hr h16 j hj
        have hr_lt_i := h16_m'_lt_i r hr h16
        rw [h16_pre r hr_lt_i] at h16
        dsimp only
        rw [h19_eq r] at hj ⊢; rw [hlv_eq]
        rcases hlv_sn r (lt_trans hr_lt_i hi) h16 j hj with ⟨h0l, hd_sn⟩
        have hne_ri : r ≠ i := by omega
        have hd_last := (hlv_lv r (lt_trans hr_lt_i hi) h16 j hj
          i hi hw16_i jLast (hjLen_toNat.symm ▸ hjLast_g) (Or.inl hne_ri)).1
        rw [hjLen_toNat] at hd_last
        refine ⟨fun s hs => ⟨(h0l s hs).1,
          fun heq => Finset.disjoint_left.mp hd_last hs (heq ▸ hrS_L_in_last)⟩, ?_⟩
        intro r' hr'
        by_cases hr'_lt : r' < i
        · rw [hsn_pre r' hr'_lt]
          exact hd_sn r' (lt_trans hr'_lt hi)
        · let j' := r' - i
          have hj' : j' < jLen := by dsimp only [j']; omega
          have hr'_eq : r' = i + j' := by dsimp only [j']; omega
          rw [hr'_eq]
          have hd_j' := (hlv_lv r (lt_trans hr_lt_i hi) h16 j hj
            i hi hw16_i j' (hjLen_toNat.symm ▸ hj') (Or.inl hne_ri)).1
          rw [hjLen_toNat] at hd_j'
          exact Finset.disjoint_of_subset_right (hsn_suf_sub j' hj') hd_j'
      · intro r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne
        have h1_lt := h16_m'_lt_i r₁ hr₁ h16₁
        have h2_lt := h16_m'_lt_i r₂ hr₂ h16₂
        rw [h16_pre r₁ h1_lt] at h16₁; rw [h16_pre r₂ h2_lt] at h16₂
        rw [h19_eq r₁] at hj₁ ⊢; rw [h19_eq r₂] at hj₂ ⊢
        rw [hlv_eq, hlv_eq, h23_eq, h23_eq]
        exact hlv_lv r₁ (lt_trans h1_lt hi) h16₁ j₁ hj₁ r₂ (lt_trans h2_lt hi) h16₂ j₂ hj₂ hne
    have hFull' : EncFullChainAndJobs ctx.d ctx.n ctx.H ctx.cfg ctx.p m' ctx.P' st_mid := by
      refine ⟨le_of_lt hk_lt_D0, hSeg', hSave', hLive', hw1_5',
        by rw [hw_static 6 (by decide)]; exact hSt.hw6_0,
        hSegPres 0 (by have := ctx.hSlots_cap; omega) _ _ hSt.hSeg0,
        rS_L, hrS_L_pos, hrS_L_lt, hw1_6',
        by rw [hw_static 6 (by decide)]; exact h6_rS_L,
        hSegLeaf', hDisj', ?_⟩
      intro idx
      by_cases hlt : idx.val < i
      · rcases hPrePure idx.val hlt idx.isLt with ⟨_, hHdr_m, hOwn_m⟩
        have hp_pre := hpre_sw idx.val hlt
        have hbc_ne26 : ctx.cfg.snBirthCard.tag ≠ 26 := by rw [hcfg]; decide
        have hage_ne26 : ctx.cfg.snAge.tag ≠ 26 := by rw [hcfg]; decide
        have hrem_eq : ∀ p, wRead m' ctx.cfg.jobRem.tag p = wRead m ctx.cfg.jobRem.tag p := by
          intro p; rw [hcfg]; exact hw_static 17 (by decide) p
        have hcl_eq : ∀ p, wRead m' ctx.cfg.jobClosed.tag p = wRead m ctx.cfg.jobClosed.tag p := by
          intro p; rw [hcfg]; exact hw_static 18 (by decide) p
        refine ⟨hHdr_m.frame_other
            (by rw [hw_m'_sw _ hbc_ne26]; exact hp_pre.1)
            (by rw [hw_m'_sw _ hage_ne26]; exact hp_pre.2.1)
            (by rw [hw_m'_sw 14 (by decide)]; exact hp_pre.2.2.2.1)
            (by rw [hw_m'_sw 15 (by decide)]; exact hp_pre.2.2.2.2.1)
            (fun _ _ => hw_static 6 (by decide) _)
            (fun c => by rw [hr_m'_sw]; exact hp_pre.2.2.2.2.2.2.2 c)
            (by rw [hr_m'_sw]; exact hp_pre.2.2.2.2.2.2.1)
            (fun s _ hlt_s _ _ hE => hSegPres s hlt_s _ _ hE),
          hOwn_m.frame_other
            (fun g _ => by rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2))
            (by rw [hw_m'_sw 16 (by decide)]; exact hp_pre.2.2.2.2.2.1)
            (hrem_eq _)
            (hcl_eq _)
            (hw_static 19 (by decide) _)
            (fun _ _ _ _ => hw_static 23 (by decide) _)
            (fun _ _ _ _ => hw_static 24 (by decide) _)
            (fun _ _ _ => hr_static 23 (by decide) _)
            (fun _ _ _ _ => hr_static 24 (by decide) _)
            (fun _ _ _ _ _ => hw_static 6 (by decide) _)
            (fun _ _ _ s _ hlt_s _ _ _ hE => hSegPres s hlt_s _ _ hE)
            (fun _ => hw_static 11 (by decide) _)
            (fun _ => hr_static 11 (by decide) _)⟩
      · let j := idx.val - i
        have hlt_m : idx.val < i + g'.lvs.length := by rw [← hk_eq]; exact idx.isLt
        have hj_lt : j < jLen := by change idx.val - i < g'.lvs.length; omega
        have hj_h : j < lvs_h.length := hlen_eq.symm ▸ hj_lt
        have hidx_val : idx.val = i + j := by change idx.val = i + (idx.val - i); omega
        have hj_mid : i + j < st_mid.k := hidx_val ▸ idx.isLt
        have hidx_eq : idx = ⟨i + j, hj_mid⟩ := by ext; exact hidx_val
        rcases hSufPure j hj_lt hj_mid with ⟨hnod_j, hbs_j, hsn_j, hoj_j, hcin_j⟩
        have hsuf_j := hsuf_sw j hj_h
        rcases hlv_all j hj_h with ⟨hb_j, hor_j, ⟨f_b, g_b, hf_b, hg_b⟩, hEnc_j, _, _, hp3_j, hp4_j, _⟩
        have hcard_b : (lvs_h[j]'hj_h).S_birth.card = (g'.lvs[j]'hj_lt).birthSnapshot.card :=
          cg18_card_eq_of_bij_on (fun h hh => ⟨(hf_b h hh).1, (hf_b h hh).2.2⟩) hg_b
        have hph2_j := hph2_all j hj_h
        rcases hEnc_j with ⟨_, dS_j, spDS_j, _, _, _, hdS_j, hspDS_j, _, _,
          _, _, _, _, hd_sp_j, _, _, _, _, _,
          _, hw_dS_j, hw_spDS_j, _, _, _, h6_dS_j, h6_spDS_j, _, _,
          _, _, _, _, _, hPh_j⟩
        have hdS_pos : 0 < dS_j := by rw [hw_dS_j] at hp3_j; simpa using hp3_j
        have hspDS_pos : 0 < spDS_j := by rw [hw_spDS_j] at hp4_j; simpa using hp4_j
        rcases (show EncSegSlot ctx.p.K_seg m dS_j
              (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) j)
              (fun x => euclideanDistSq (ctx.P'.handleCoords x) ((lvs_h[j]'hj_h).ball (ctx.d + 3)).o) ∧
            EncSegSlot ctx.p.K_seg m spDS_j
              (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) j)
              (fun _ => 0) from by
          rcases hPh_j with ⟨_, _, h0, _⟩ | ⟨_, _, h1, _⟩ | ⟨_, _, hEd, hEsp, _⟩
          · omega
          · omega
          · exact ⟨hEd, hEsp⟩) with ⟨hEd_j, hEsp_j⟩
        have hSpar_eq : jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) j =
            chainInput ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles idx.castSucc := by
          have h1 := cg18_jobHandleInput_eq_prefixResidual_take (ctx.d + 3) ctx.P'.handleCoords
            lvs_h g'.lvs (ctx.S_post_h ⟨i, hi⟩) hlen_eq (fun k hk => (hlv_all k hk).1) (le_of_lt hj_h)
          rw [hidx_eq, hcin_j]
          exact h1
        have hbc_ne26 : ctx.cfg.snBirthCard.tag ≠ 26 := by rw [hcfg]; decide
        have hage_ne26 : ctx.cfg.snAge.tag ≠ 26 := by rw [hcfg]; decide
        rw [hidx_eq, hnod_j, hbs_j, hsn_j, hoj_j]
        refine ⟨?_, ?_⟩
        · refine ⟨dS_j, spDS_j,
            chainInput ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles (⟨i + j, hj_mid⟩ : Fin st_mid.k).castSucc,
            hdS_pos, hdS_j, hspDS_pos, hspDS_j, hd_sp_j,
            by rw [hw_m'_sw _ hbc_ne26, hsuf_j.1, hcard_b],
            by rw [hw_m'_sw _ hage_ne26, hsuf_j.2.1, hor_j],
            by rw [hw_m'_sw 14 (by decide), hsuf_j.2.2.2.1, hw_dS_j],
            by rw [hw_m'_sw 15 (by decide), hsuf_j.2.2.2.2.1, hw_spDS_j],
            by rw [hw_static 6 (by decide)]; exact h6_dS_j,
            by rw [hw_static 6 (by decide)]; exact h6_spDS_j,
            fun c => by rw [hr_m'_sw, hsuf_j.2.2.2.2.2.2.2 c, hb_j],
            by rw [hr_m'_sw, hsuf_j.2.2.2.2.2.2.1, hb_j],
            by rw [← hidx_eq, ← hSpar_eq, ← hb_j]; exact hSegPres dS_j hdS_j _ _ hEd_j,
            by rw [← hidx_eq, ← hSpar_eq]; exact hSegPres spDS_j hspDS_j _ _ hEsp_j,
            fun _ => rfl⟩
        · change wRead m' 16 (((i + j : ℕ) : ℤ)) = 0
          rw [hw_m'_sw 16 (by decide)]
          exact hsuf_j.2.2.2.2.2.1
    have hCut' : MidLoopCut ctx gFlag m' :=
      ⟨hw27', st_mid, hu_eq, hNodesInv, hTerm_le, hFull', hGood_mid⟩
    exact ⟨m', e_full, hpop',
      hw_static 0 (by decide) 0,
      hw26_m'_m 13 (by decide) (by decide) (by decide) (by decide),
      hw26_m'_m 14 (by decide) (by decide) (by decide) (by decide),
      (hw26_m'_m 15 (by decide) (by decide) (by decide) (by decide)).trans hw15,
      hw26_m'_m 28 (by decide) (by decide) (by decide) (by decide),
      Or.inr hCut'.to_false,
      fun hgF => Or.inr (hgF ▸ hCut')⟩
  · -- Non-deadline branch (`g'.t_cur < g'.H_job`):
    have ht_lt : g'.t_cur < g'.H_job := by omega
    have hc_false : cValAt 0 inp m condE = false := by
      simp only [condE, cValAt, evalArithCond]
      change decide (iValAt 0 inp m (ctx.cfg.jobRem.readE rE) = iValAt 0 inp m (.lit 0)) = false
      rw [hrem_eval, decide_eq_false_iff_not]
      change ¬ (((g'.H_job - g'.t_cur : ℕ) : ℤ) = 0)
      omega
    have e_full : DetExecAt 0 inp (activeJobDeadlineStmt ctx.d ctx.p.D₀ ctx.M_box ctx.cfg)
        m m (activeJobDeadlineCost ctx.d ctx.p.D₀) := by
      unfold activeJobDeadlineStmt activeJobDeadlineCost
      exact (DetExecAt.ite_false hc_false hcond_ops (DetExecAt.skip 0 inp m)).mono_cost (by omega)
    have hUncut' : MidLoopUncut ctx gFlag (i + 1) m := hSt.to_uncut ht_lt
    exact ⟨m, e_full, hpop, rfl, rfl, rfl, hw15, rfl,
      Or.inl hUncut'.to_false,
      fun hgF => Or.inl (hgF ▸ hUncut')⟩

end UL.Proof_lem_7_2_RacerP46
