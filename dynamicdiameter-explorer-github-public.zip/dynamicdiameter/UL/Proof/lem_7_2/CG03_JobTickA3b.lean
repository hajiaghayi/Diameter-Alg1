import UL.Proof.lem_7_2.CG03_JobTickA3a
import UL.Proof.lem_7_2.CG02_LiveRouteB1

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Post-Route Lifting of Frozen Snapshots & Job Levels, plus `GlobalSlotDisj` Projections -/

noncomputable def bridgeHandleCoords {d : ℕ} (P P' : DynamicPointSet d) (h : ℕ) :
    EuclideanSpace ℝ (Fin d) :=
  if h ∈ P.activeHandles then P.handleCoords h else P'.handleCoords h

lemma bridgeHandleCoords_eq_pre {d : ℕ} {P P' : DynamicPointSet d} {h : ℕ}
    (hh : h ∈ P.activeHandles) :
    bridgeHandleCoords P P' h = P.handleCoords h :=
  if_pos hh

lemma bridgeHandleCoords_eq_post {d : ℕ} {P P' : DynamicPointSet d}
    (hcoords_root : ∀ h ∈ P.activeHandles, h ∈ P'.activeHandles → P'.handleCoords h = P.handleCoords h)
    {h : ℕ} (hh' : h ∈ P'.activeHandles) :
    bridgeHandleCoords P P' h = P'.handleCoords h := by
  unfold bridgeHandleCoords
  by_cases hh : h ∈ P.activeHandles
  · rw [if_pos hh, hcoords_root h hh hh']
  · exact if_neg hh

lemma EncSlotCoords.congr_pts_on {d n : ℕ} {mem : ArithRAMMemory}
    {activeH : Finset ℕ} {pts₁ pts₂ : ℕ → EuclideanSpace ℝ (Fin d)}
    {s : ℕ} {S : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    (h : EncSlotCoords d n mem activeH pts₁ s S snapPts)
    (hpts : ∀ h ∈ activeH, pts₂ h = pts₁ h) :
    EncSlotCoords d n mem activeH pts₂ s S snapPts := by
  rcases h with ⟨hlt, ⟨h0, hsub, heq0⟩ | ⟨h1, hsaved⟩⟩
  · exact ⟨hlt, Or.inl ⟨h0, hsub, fun x hx => (heq0 x hx).trans (hpts x (hsub hx)).symm⟩⟩
  · refine ⟨hlt, Or.inr ⟨h1, fun x hx => ?_⟩⟩
    rcases hsaved x hx with ⟨heq, hne⟩
    refine ⟨heq, fun hne' => ?_⟩
    rcases hne hne' with ⟨hx_act, hsp⟩
    exact ⟨hx_act, hsp.trans (hpts x hx_act).symm⟩

lemma jobHandleInput_congr_pts {d : ℕ} (D : ℕ)
    {pts₁ pts₂ : ℕ → EuclideanSpace ℝ (Fin d)}
    (lvs : List (JobLvData d)) (S₀ : Finset ℕ)
    (heq : ∀ x ∈ S₀, pts₁ x = pts₂ x) (j : ℕ) :
    jobHandleInput D pts₁ lvs S₀ j = jobHandleInput D pts₂ lvs S₀ j := by
  induction j generalizing lvs S₀ with
  | zero => simp [jobHandleInput_zero]
  | succ j' ih =>
      cases lvs with
      | nil => rfl
      | cons lv rest =>
          have hres : (lv.ball D).residual pts₁ S₀ = (lv.ball D).residual pts₂ S₀ := by
            ext x
            rw [mem_nodeResidual_iff_distSq_gt, mem_nodeResidual_iff_distSq_gt]
            exact and_congr_right fun hx => by rw [heq x hx]
          change jobHandleInput D pts₁ rest ((lv.ball D).residual pts₁ S₀) j' =
                 jobHandleInput D pts₂ rest ((lv.ball D).residual pts₂ S₀) j'
          rw [hres]
          exact ih rest _ (fun x hx => heq x (nodeResidual_subset_self _ _ _ hx))

theorem slotCoordsBridgeToPost {d n : ℕ}
    {mem : ArithRAMMemory} {P P' : DynamicPointSet d}
    {bS : ℕ} {S_birth : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    (hcoords_root : ∀ h ∈ P.activeHandles, h ∈ P'.activeHandles → P'.handleCoords h = P.handleCoords h)
    (hC : EncSlotCoords d n mem P'.activeHandles (bridgeHandleCoords P P') bS S_birth snapPts) :
    EncSlotCoords d n mem P'.activeHandles P'.handleCoords bS S_birth snapPts :=
  hC.congr_pts_on (fun _ hh => (bridgeHandleCoords_eq_post hcoords_root hh).symm)

theorem liftPreJobLevelAfterRoute {d n D K NumSlots : ℕ}
    {m_pre mem_rt : ArithRAMMemory} {P P' : DynamicPointSet d}
    {idx : ℕ} {S_birth S_parent : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d} {spLive : Bool}
    (hS_sub : S_parent ⊆ P.activeHandles)
    (hEnc_pre : EncJobLevel d n D K NumSlots m_pre P.activeHandles P.handleCoords idx
      S_birth snapPts prov S_parent spLive)
    (hseg_pres : ∀ s ∈ jobLevelSlotSet m_pre idx, s < NumSlots →
      (spLive = false → s ≠ (wRead m_pre 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat) →
      ∀ S₁ fSq₁, EncSegSlot K m_pre s S₁ fSq₁ → EncSegSlot K mem_rt s S₁ fSq₁)
    (hSnap : ∀ s < NumSlots, 1 ≤ wRead m_pre 6 (s : ℤ) → ∀ S sp,
      EncSlotCoords d n m_pre P.activeHandles P.handleCoords s S sp →
      EncSlotCoords d n mem_rt P'.activeHandles P'.handleCoords s S sp)
    (hw6_eq : ∀ s, wRead mem_rt 6 s = wRead m_pre 6 s)
    (hw23_eq : ∀ i, wRead mem_rt 23 i = wRead m_pre 23 i)
    (hw24_eq : ∀ i, wRead mem_rt 24 i = wRead m_pre 24 i)
    (hr23_eq : ∀ i, rRead mem_rt 23 i = rRead m_pre 23 i)
    (hr24_eq : ∀ i, rRead mem_rt 24 i = rRead m_pre 24 i)
    (hcoords_root : ∀ h ∈ P.activeHandles, h ∈ P'.activeHandles → P'.handleCoords h = P.handleCoords h) :
    EncJobLevel d n D K NumSlots mem_rt P'.activeHandles (bridgeHandleCoords P P') idx
      S_birth snapPts prov S_parent spLive :=
  hEnc_pre.frame (fun x hx => bridgeHandleCoords_eq_pre (hS_sub hx))
    (fun s hs hlt _ S₁ fSq₁ hnd hE => hseg_pres s hs hlt hnd S₁ fSq₁ hE)
    (fun _ _ => hw6_eq _)
    (fun bS hbS h6 hC =>
      (hSnap bS hbS h6 S_birth snapPts hC).congr_pts_on
        (fun _ hh => bridgeHandleCoords_eq_post hcoords_root hh))
    (fun _ _ => hw23_eq _)
    (fun _ _ => hw24_eq _)
    (fun _ => hr23_eq _)
    (fun _ _ => hr24_eq _)

lemma encJobLevel_live_and_frozen_slots {d n D K NumSlots : ℕ} {mem : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {idx : ℕ} {S_birth S_parent : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d} {spLive : Bool}
    (hEnc : EncJobLevel d n D K NumSlots mem activeH livePts idx S_birth snapPts prov S_parent spLive) :
    1 ≤ wRead mem 6 (((wRead mem 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat : ℤ)) ∧
    ∀ s ∈ jobLevelLiveSlots mem idx spLive, wRead mem 6 (s : ℤ) = 0 := by
  rcases hEnc with ⟨bS, dS, spDS, rS, spRS, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _,
    hw2, hw3, hw4, hw5, hw6, h6_b, h6_d, h6_sd, h6_r, h6_sr, _⟩
  refine ⟨by rw [hw2]; simpa using h6_b, ?_⟩
  intro s hs
  unfold jobLevelLiveSlots at hs
  rw [hw3, hw4, hw5, hw6] at hs
  simp only [Int.toNat_natCast] at hs
  cases spLive with
  | true =>
      simp only [↓reduceIte, Finset.mem_insert, Finset.mem_singleton] at hs
      rcases hs with rfl | rfl | rfl | rfl
      · exact h6_sr.mpr rfl
      · exact h6_d
      · exact h6_sd
      · exact h6_r
  | false =>
      simp only [Bool.false_eq_true, ↓reduceIte, Finset.mem_insert, Finset.mem_singleton] at hs
      rcases hs with rfl | rfl | rfl
      · exact h6_d
      · exact h6_sd
      · exact h6_r

lemma levelUsedSlots_disj_of_live_and_bS {d n D D₀ K NumSlots : ℕ} {mem : ArithRAMMemory}
    {activeH₁ activeH₂ : Finset ℕ} {livePts₁ livePts₂ : ℕ → EuclideanSpace ℝ (Fin d)}
    {idx₁ idx₂ : ℕ} {Sb₁ Sp₁ Sb₂ Sp₂ : Finset ℕ}
    {sn₁ sn₂ : ℕ → EuclideanSpace ℝ (Fin d)} {pr₁ pr₂ : ChainNode d} {sp₁ sp₂ : Bool}
    (hEnc₁ : EncJobLevel d n D K NumSlots mem activeH₁ livePts₁ idx₁ Sb₁ sn₁ pr₁ Sp₁ sp₁)
    (hEnc₂ : EncJobLevel d n D K NumSlots mem activeH₂ livePts₂ idx₂ Sb₂ sn₂ pr₂ Sp₂ sp₂)
    (hlive_disj : Disjoint (jobLevelLiveSlots mem idx₁ sp₁) (jobLevelLiveSlots mem idx₂ sp₂))
    (hb_ne : (wRead mem 23 (((8 * idx₁ + 2 : ℕ) : ℤ))).toNat ≠
             (wRead mem 23 (((8 * idx₂ + 2 : ℕ) : ℤ))).toNat) :
    let _ := D₀
    ∀ s ∈ LevelUsedSlots mem idx₂ sp₂,
      s ∉ jobLevelSlotSet mem idx₁ ∨
      (sp₁ = false ∧ s = (wRead mem 23 (((8 * idx₁ + 6 : ℕ) : ℤ))).toNat) := by
  intro _ s hs
  rcases encJobLevel_live_and_frozen_slots hEnc₁ with ⟨h6_b1, hlive1⟩
  rcases encJobLevel_live_and_frozen_slots hEnc₂ with ⟨h6_b2, hlive2⟩
  unfold LevelUsedSlots at hs
  simp only [Finset.mem_insert] at hs
  rcases hs with rfl | hs_live2
  · -- s = bS₂, which has 1 ≤ wRead mem 6 s
    by_cases h_in1 : (wRead mem 23 (((8 * idx₂ + 2 : ℕ) : ℤ))).toNat ∈ jobLevelSlotSet mem idx₁
    · unfold jobLevelSlotSet at h_in1
      simp only [Finset.mem_insert, Finset.mem_singleton] at h_in1
      rcases h_in1 with heq2 | heq3 | heq4 | heq5 | heq6
      · exact False.elim (hb_ne heq2.symm)
      · have h0 : wRead mem 6 (((wRead mem 23 (((8 * idx₁ + 3 : ℕ) : ℤ))).toNat : ℤ)) = 0 := by
          apply hlive1; unfold jobLevelLiveSlots
          cases sp₁ <;> simp
        rw [← heq3] at h0; omega
      · have h0 : wRead mem 6 (((wRead mem 23 (((8 * idx₁ + 4 : ℕ) : ℤ))).toNat : ℤ)) = 0 := by
          apply hlive1; unfold jobLevelLiveSlots
          cases sp₁ <;> simp
        rw [← heq4] at h0; omega
      · have h0 : wRead mem 6 (((wRead mem 23 (((8 * idx₁ + 5 : ℕ) : ℤ))).toNat : ℤ)) = 0 := by
          apply hlive1; unfold jobLevelLiveSlots
          cases sp₁ <;> simp
        rw [← heq5] at h0; omega
      · cases hsp1 : sp₁ with
        | false => exact Or.inr ⟨rfl, heq6⟩
        | true =>
            have h0 : wRead mem 6 (((wRead mem 23 (((8 * idx₁ + 6 : ℕ) : ℤ))).toNat : ℤ)) = 0 := by
              apply hlive1; unfold jobLevelLiveSlots; simp [hsp1]
            rw [← heq6] at h0; omega
    · exact Or.inl h_in1
  · -- s ∈ jobLevelLiveSlots mem idx₂ sp₂, so wRead mem 6 s = 0 and s ∉ jobLevelLiveSlots mem idx₁ sp₁
    left
    have hs_not1 : s ∉ jobLevelLiveSlots mem idx₁ sp₁ :=
      Finset.disjoint_right.mp hlive_disj hs_live2
    exact not_mem_jobLevelSlotSet_of_live_disj hEnc₁ (hlive2 s hs_live2) hs_not1

/-! ### 2. Affected Idle Serving Node Step (`idleAffectedNodeStmt`) -/

def launchPendingJobAtRStmt (d n M_box : ℕ) (cfg : ChainHdrCfg) (p : P46Params d n) : ArithRAMStmt :=
  seqList [
    freshAllocFiveSlotsStmt p.D₀ p.NumSlots M_box,
    boxWriteW M_box 26 (.lit 1) (.readHeap 15 (.readHeap 26 (.lit 15))),
    boxWriteW M_box 15 (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 19)),
    freezeSlot26_1Stmt M_box,
    readSlotCardTo24Stmt p.K_seg M_box (.readHeap 26 (.lit 1)),
    boxWriteW M_box 26 (.lit 25)
      (.div (.readHeap 26 (.lit 24)) (.lit (((16384 * p.D ^ 2 : ℕ) : ℤ)))),
    boxWriteW M_box 26 (.lit 7)
      (.mul (.readHeap 26 (.lit 15)) (.lit (p.D₀ : ℤ))),
    hpjFreezeRunInitStmt d n M_box p,
    boxWriteW M_box 16 (.readHeap 26 (.lit 15)) (.lit 1),
    cfg.jobRem.writeW M_box (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 25)),
    cfg.jobClosed.writeW M_box (.readHeap 26 (.lit 15)) (.lit 0),
    boxWriteW M_box 19 (.readHeap 26 (.lit 15)) (.lit 1),
    .localScope .skip
  ]

def idleAffectedNodeStmt (d n M_box : ℕ) (cfg : ChainHdrCfg) (p : P46Params d n) : ArithRAMStmt :=
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let ageE : IntExpr := cfg.snAge.readE rE
  let startAgeE : IntExpr :=
    .div (cfg.snBirthCard.readE rE) (.lit (((256 * p.D ^ 2 : ℕ) : ℤ)))
  .ite (.intLt ageE startAgeE)
    (seqList [
      boxWriteW M_box 26 (.lit 0) (.lit 0),
      runHPJOnSlotStmt d n M_box p
    ])
    (seqList [
      readSlotCardTo24Stmt p.K_seg M_box (.readHeap 14 rE),
      .ite (.intLt (.lit (((4 * p.L : ℕ) : ℤ))) (.readHeap 26 (.lit 24)))
        (launchPendingJobAtRStmt d n M_box cfg p)
        (seqList [
          boxWriteW M_box 1 (.lit 6) (.readHeap 15 rE),
          boxWriteW M_box 1 (.lit 5) rE,
          boxWriteW M_box 26 (.lit 27) (.lit 1),
          boxWriteW M_box 26 (.lit 0) (.lit 0),
          runHPJOnSlotStmt d n M_box p
        ])
    ])

theorem boxSafe_idleAffectedNodeStmt {d n T_max M_box : ℕ} {cfg : ChainHdrCfg}
    (hV : cfg.Valid T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (idleAffectedNodeStmt d n M_box cfg p) := by
  have hT28 := hV.1
  refine .ite _
    (boxSafeOuter_seqList ?_)
    (boxSafeOuter_seqList ?_)
  · intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl
    · exact .boxW (by omega) _ _
    · exact boxSafe_runHPJOnSlotStmt hT28 p
  · intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl
    · exact boxSafe_readSlotCardTo24Stmt (by omega) p.K_seg _
    · refine .ite _ (boxSafeOuter_seqList ?_) (boxSafeOuter_seqList ?_)
      · intro s1 hs1; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs1
        rcases hs1 with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
        · exact boxSafe_freshAllocFiveSlotsStmt (by omega) p.D₀ p.NumSlots
        · exact .boxW (by omega) _ _
        · exact .boxW (by omega) _ _
        · exact boxSafe_freezeSlot26_1Stmt (by omega)
        · exact boxSafe_readSlotCardTo24Stmt (by omega) p.K_seg _
        · exact .boxW (by omega) _ _
        · exact .boxW (by omega) _ _
        · exact boxSafe_hpjFreezeRunInitStmt hT28 p
        · exact .boxW (by omega) _ _
        · exact boxSafe_hdrWriteW hV.2.2.2.2.1.1 _ _
        · exact boxSafe_hdrWriteW hV.2.2.2.2.2.1.1 _ _
        · exact .boxW (by omega) _ _
        · exact .localScope .skip
      · intro s2 hs2; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs2
        rcases hs2 with rfl | rfl | rfl | rfl | rfl
        · exact .boxW (by omega) _ _
        · exact .boxW (by omega) _ _
        · exact .boxW (by omega) _ _
        · exact .boxW (by omega) _ _
        · exact boxSafe_runHPJOnSlotStmt hT28 p

noncomputable def idleAffectedNodeCost (d n : ℕ) (cfg : ChainHdrCfg) (p : P46Params d n) : ℕ :=
  let _ := cfg
  freshAllocFiveCost p.D₀ p.NumSlots + hpjFreezeRunInitCost d n p +
    2 * (p.K_seg + 100) + 600


/-! ### 3. Structured Loop Context (`MidLoopCtx`) & Two-Mode Loop State (`MidLoopState`) -/


def updateIsInsert {d : ℕ} (op : DynamicUpdate d) : Bool :=
  match op with | .insert _ _ _ => true | .delete _ => false

structure MidLoopCtx : Type where
  T_max : ℕ
  M_box : ℕ
  cfg : ChainHdrCfg
  d : ℕ
  n : ℕ
  H : ℕ
  p : P46Params d n
  P : DynamicPointSet d
  P' : DynamicPointSet d
  op : DynamicUpdate d
  opH : ℕ
  uMap' : GhostUidMap d P'
  st₀ : PureServingState d n H p.L p.B_scan P
  trueAge' : Fin st₀.k → ℕ
  hV : cfg.Valid T_max
  hD_eq : p.D = d + 3
  hH5 : 5 ≤ H
  hn2 : n < 2 ^ H
  hn_2K : n ≤ 2 ^ p.K_seg
  hD0_eq : p.D₀ = 24 * (d + 3) ^ 2 * H
  hL_floor : 68719476736 * (d + 3) ^ 4 ≤ p.L
  hL_eq10 : SatisfiesLeafCutoffEq10 d n (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) 0 p.K₀ p.L
  hB_floor : 16777216 * (d + 3) ^ 4 ≤ p.B_scan
  hKbatch : p.K_batch = p.B_scan + 1
  hSlots_cap : 8 * (p.D₀ + 2) ^ 2 ≤ p.NumSlots
  hkφ : p.φ_ev = (1 / 2 : ℝ) ^ p.k_φ
  hφ0 : 0 < p.φ_ev
  hφ1 : p.φ_ev < 1 / 2
  hp_eq : p.P_hpj = hpjParams d p.φ_ev
  hp_props : HPJParamProps d p.φ_ev p.P_hpj
  hbias_hpj : (((2 ^ p.P_hpj.q : ℕ) : ℝ) * (n : ℝ)) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev
  hB_hpj : p.B_hpj = (2 ^ p.P_hpj.q) * p.M_bits + p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q
  hBox30 : 30 ≤ M_box
  hBox_slots : p.NumSlots ≤ M_box
  hBox_samp : (2 ^ p.P_hpj.q) * d ≤ M_box
  hBox_d : d + 1 ≤ M_box
  hBox_w23 : 8 * (p.D₀ * p.D₀) + 8 ≤ M_box
  hBox_r23 : (p.D₀ * p.D₀) * d + d ≤ M_box
  hBox_seg : p.NumSlots * 2 ^ (p.K_seg + 1) ≤ M_box
  hBox_hdr : cfg.maxStride * p.D₀ ≤ M_box
  hBox_snO : p.D₀ * d ≤ M_box
  hwf₀ : st₀.WellFormed
  hP : P.WellFormed n
  hP' : P'.WellFormed n
  hopH_n : opH < n
  hopH_K : opH < 2 ^ p.K_seg
  hle_uid : st₀.uMap.nextUid ≤ uMap'.nextUid
  hag_uid : ∀ u < st₀.uMap.nextUid, uMap'.ghostCoords u = st₀.uMap.ghostCoords u
  hchg_root : IsInputChange P.activeHandles P'.activeHandles
  hcoords_root : ∀ h ∈ P.activeHandles, h ∈ P'.activeHandles → P'.handleCoords h = P.handleCoords h
  hcoords_ne : ∀ h ∈ P.activeHandles, h ≠ opH → h ∈ P'.activeHandles ∧ P'.handleCoords h = P.handleCoords h
  htr_le' : ∀ r : Fin st₀.k,
    trueAge' r ≤ (if chainLevelAffected P P' st₀.nodes (updateIsInsert op) opH r.castSucc
                  then st₀.snAge r + 1 else st₀.snAge r)
  hhas_age' : ∀ r : Fin st₀.k,
    HasNodeAge (st₀.birthSnap r)
      (chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc) (trueAge' r)
  hPerNode : ∀ r : Fin st₀.k,
    let ins : Bool := updateIsInsert op
    let aff := chainLevelAffected P P' st₀.nodes ins opH
    let S_pre_h := chainInput P.handleCoords st₀.nodes P.activeHandles r.castSucc
    let S_post_h := chainInput P'.handleCoords st₀.nodes P'.activeHandles r.castSucc
    let S_pre_u := chainInput st₀.uMap.ghostCoords st₀.nodes st₀.uMap.ActiveUids r.castSucc
    let S_post_u := chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc
    (aff r.castSucc = false → opH ∉ S_pre_h ∧ opH ∉ S_post_h ∧ S_post_h = S_pre_h ∧ S_post_u = S_pre_u) ∧
    (aff r.castSucc = true →
      IsInputChange S_pre_h S_post_h ∧
      IsInputChange S_pre_u S_post_u ∧
      (ins = true → opH ∉ S_pre_h ∧ S_post_h = insert opH S_pre_h) ∧
      (ins = false → opH ∈ S_pre_h ∧ S_post_h = S_pre_h.erase opH) ∧
      ∃ ev_r : PoolUpdateEvent ℕ, ev_r.isClockTick = true ∧ IsValidPoolUpdateEvent S_pre_u S_post_u ev_r)


def MidLoopCtx.ins (ctx : MidLoopCtx) : Bool :=
  updateIsInsert ctx.op

noncomputable def MidLoopCtx.aff (ctx : MidLoopCtx) : Fin (ctx.st₀.k + 1) → Bool :=
  chainLevelAffected ctx.P ctx.P' ctx.st₀.nodes ctx.ins ctx.opH

noncomputable def MidLoopCtx.snAge' (ctx : MidLoopCtx) (r : Fin ctx.st₀.k) : ℕ :=
  if ctx.aff r.castSucc then ctx.st₀.snAge r + 1 else ctx.st₀.snAge r

noncomputable def MidLoopCtx.S_pre_h (ctx : MidLoopCtx) (r : Fin ctx.st₀.k) : Finset ℕ :=
  chainInput ctx.P.handleCoords ctx.st₀.nodes ctx.P.activeHandles r.castSucc

noncomputable def MidLoopCtx.S_post_h (ctx : MidLoopCtx) (r : Fin ctx.st₀.k) : Finset ℕ :=
  chainInput ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles r.castSucc

noncomputable def MidLoopCtx.S_pre_u (ctx : MidLoopCtx) (r : Fin ctx.st₀.k) : Finset ℕ :=
  chainInput ctx.st₀.uMap.ghostCoords ctx.st₀.nodes ctx.st₀.uMap.ActiveUids r.castSucc

noncomputable def MidLoopCtx.S_post_u (ctx : MidLoopCtx) (r : Fin ctx.st₀.k) : Finset ℕ :=
  chainInput ctx.uMap'.ghostCoords ctx.st₀.nodes ctx.uMap'.ActiveUids r.castSucc

lemma MidLoopCtx.opH_mem_post_of_aff_ins (ctx : MidLoopCtx) (r : Fin ctx.st₀.k)
    (haff : ctx.aff r.castSucc = true) (hins : ctx.ins = true) :
    ctx.opH ∈ ctx.P'.activeHandles := by
  have hpost_eq : ctx.S_post_h r = insert ctx.opH (ctx.S_pre_h r) :=
    ((ctx.hPerNode r).2 haff).2.2.1 hins |>.2
  have hmem : ctx.opH ∈ ctx.S_post_h r := by
    rw [hpost_eq]; exact Finset.mem_insert_self _ _
  exact cg01_chainInput_subset ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles r.castSucc hmem

def EncTodoJobAt (ctx : MidLoopCtx) (mem : ArithRAMMemory) (r : Fin ctx.st₀.k) : Prop :=
  match ctx.st₀.ownedJob r with
  | none => wRead mem 16 (r.val : ℤ) = 0
  | some g =>
      wRead mem 16 (r.val : ℤ) = 1 ∧
      wRead mem ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r.val : ℤ) = (((g.H_job - g.t_cur : ℕ) : ℤ)) ∧
      wRead mem ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r.val : ℤ) = (if g.closed then 1 else 0) ∧
      wRead mem 19 (r.val : ℤ) = (g.lvs.length : ℤ) ∧
      ∃ (lvs_h : List (JobLvData ctx.d)),
        ∃ (hlen_eq : lvs_h.length = g.lvs.length),
        ∀ (j : ℕ) (hj : j < lvs_h.length),
          let idx := r.val * ctx.p.D₀ + j
          let hj_g : j < g.lvs.length := hlen_eq ▸ hj
          (lvs_h[j]'hj).ball (ctx.d + 3) = (g.lvs[j]'hj_g).ball ∧
          (lvs_h[j]'hj).openRem = g.openRem j ∧
          (∃ (f_b g_b : ℕ → ℕ),
            (∀ h ∈ (lvs_h[j]'hj).S_birth,
              f_b h ∈ (g.lvs[j]'hj_g).birthSnapshot ∧
              ctx.st₀.uMap.ghostCoords (f_b h) = (lvs_h[j]'hj).snapPts h ∧
              g_b (f_b h) = h) ∧
            (∀ u ∈ (g.lvs[j]'hj_g).birthSnapshot,
              g_b u ∈ (lvs_h[j]'hj).S_birth ∧
              f_b (g_b u) = u)) ∧
          EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots mem
            ctx.P'.activeHandles (bridgeHandleCoords ctx.P ctx.P') idx
            (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
            (jobHandleInput (ctx.d + 3) (bridgeHandleCoords ctx.P ctx.P') lvs_h (ctx.S_pre_h r) j)
            (decide (j + 1 = lvs_h.length)) ∧
          wRead mem 23 (((8 * idx + 7 : ℕ) : ℤ)) = (g.openRem j : ℤ) ∧
          0 < (wRead mem 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat ∧
          0 < (wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ))).toNat ∧
          0 < (wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ))).toNat ∧
          0 < (wRead mem 23 (((8 * idx + 5 : ℕ) : ℤ))).toNat ∧
          0 < (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat ∧
          (j + 1 < lvs_h.length → wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2) ∧
          (j + 1 = lvs_h.length →
            wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = (g.ph_cur : ℤ) ∧
            wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (g.scan_cur : ℤ) ∧
            g.Spar_last_h = jobHandleInput (ctx.d + 3) ctx.P.handleCoords lvs_h (ctx.S_pre_h r) j)

def MidLoopUncut (ctx : MidLoopCtx) (good : Bool) (i : ℕ) (m : ArithRAMMemory) : Prop :=
  wRead m 26 27 = 0 ∧
  (good = true → ∀ r : Fin ctx.st₀.k,
    IsCenterpoint (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2))
      (paraboloidLiftSet (fun u : ↥(ctx.st₀.birthSnap r) => ctx.st₀.uMap.ghostCoords u.1))
      (liftedPoint (ctx.st₀.nodes r).o ((ctx.st₀.nodes r).V + ‖(ctx.st₀.nodes r).o‖ ^ 2))) ∧
  SegGenBound ctx.p.K_seg ctx.p.NumSlots m ∧
  SaveGenBound ctx.n ctx.p.NumSlots m ∧
  EncLiveCoords ctx.d ctx.n m ctx.P'.activeHandles ctx.P'.handleCoords ∧
  wRead m 1 5 = (ctx.st₀.k : ℤ) ∧
  wRead m 6 0 = 0 ∧
  EncSegSlot ctx.p.K_seg m 0 ctx.P'.activeHandles (fun _ => 0) ∧
  ∃ leafS : ℕ,
    0 < leafS ∧ leafS < ctx.p.NumSlots ∧
    wRead m 1 6 = (leafS : ℤ) ∧
    wRead m 6 (leafS : ℤ) = 0 ∧
    EncSegSlot ctx.p.K_seg m leafS
      (chainTerminal ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles) (fun _ => 0) ∧
    GlobalSlotDisj ctx.p.D₀ m ctx.st₀.k leafS ∧
    (∀ (r : Fin ctx.st₀.k), r.val < i →
      ∃ oj : Option (ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
          ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u r)),
        ServingOwnedJobInv (ctx.st₀.birthSnap r) (ctx.snAge' r) oj ∧
        (good = true → ∀ g, oj = some g → JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g.lvs) ∧
        EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' r.val (ctx.st₀.nodes r)
          (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) oj.isNone ∧
        EncOwnedJobAt ctx.cfg ctx.p m ctx.P' ctx.uMap' r.val (ctx.S_post_h r) (ctx.S_post_u r) oj) ∧
    (∀ (r : Fin ctx.st₀.k), i ≤ r.val →
      wRead m ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r.val : ℤ) =
        (if ctx.aff r.castSucc then 1 else 0) ∧
      EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' r.val (ctx.st₀.nodes r)
        (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) (ctx.st₀.ownedJob r).isNone ∧
      (good = true → ∀ g, ctx.st₀.ownedJob r = some g →
        JobLevelsCenterGood (ctx.d + 3) ctx.st₀.uMap.ghostCoords g.lvs) ∧
      EncTodoJobAt ctx m r)

def MidLoopCut (ctx : MidLoopCtx) (good : Bool) (m : ArithRAMMemory) : Prop :=
  wRead m 26 27 = 1 ∧
  ∃ st_mid : PureServingState ctx.d ctx.n ctx.H ctx.p.L ctx.p.B_scan ctx.P',
    st_mid.uMap = ctx.uMap' ∧
    st_mid.NodesInv ∧
    (chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles).card ≤ 4 * ctx.p.L + 2 ∧
    EncFullChainAndJobs ctx.d ctx.n ctx.H ctx.cfg ctx.p m ctx.P' st_mid ∧
    (good = true → st_mid.AllCentersGood)

def MidLoopState (ctx : MidLoopCtx) (retH0 : ℤ) (good : Bool) (i : ℕ) (m : ArithRAMMemory) : Prop :=
  wRead m 0 0 = retH0 ∧
  wRead m 26 13 = (ctx.opH : ℤ) ∧
  wRead m 26 14 = (if ctx.ins then 1 else 0) ∧
  wRead m 26 15 = (i : ℤ) ∧
  wRead m 26 28 = (ctx.st₀.k : ℤ) ∧
  (MidLoopUncut ctx good i m ∨ MidLoopCut ctx good m)

lemma MidLoopCtx.origK_lt_D0 (ctx : MidLoopCtx) : ctx.st₀.k < ctx.p.D₀ := by
  rw [ctx.hD0_eq]
  exact (ctx.st₀.chainLen_and_jobLen_lt ctx.hP ctx.hH5 ctx.hn2 ctx.hwf₀.1).1

lemma MidLoopUncut.gc_hyps {ctx : MidLoopCtx} {good : Bool} {i : ℕ} {m : ArithRAMMemory}
    (hU : MidLoopUncut ctx good i m) :
    ctx.st₀.k ≤ ctx.p.D₀ ∧
    wRead m 1 5 = (ctx.st₀.k : ℤ) ∧
    ∃ leafS < ctx.p.NumSlots,
      wRead m 1 6 = (leafS : ℤ) ∧
      (∀ r < ctx.st₀.k, ∃ (dS spS : ℕ), dS < ctx.p.NumSlots ∧ spS < ctx.p.NumSlots ∧
        wRead m 14 (r : ℤ) = (dS : ℤ) ∧ wRead m 15 (r : ℤ) = (spS : ℤ)) ∧
      (∀ r < ctx.st₀.k, wRead m 16 (r : ℤ) = 1 →
        ∃ jLen ≤ ctx.p.D₀, wRead m 19 (r : ℤ) = (jLen : ℤ) ∧
          ∀ j < jLen, ∃ (s2 s3 s4 s5 s6 : ℕ),
            s2 < ctx.p.NumSlots ∧ s3 < ctx.p.NumSlots ∧ s4 < ctx.p.NumSlots ∧
            s5 < ctx.p.NumSlots ∧ s6 < ctx.p.NumSlots ∧
            wRead m 23 (((8 * (r * ctx.p.D₀ + j) + 2 : ℕ) : ℤ)) = (s2 : ℤ) ∧
            wRead m 23 (((8 * (r * ctx.p.D₀ + j) + 3 : ℕ) : ℤ)) = (s3 : ℤ) ∧
            wRead m 23 (((8 * (r * ctx.p.D₀ + j) + 4 : ℕ) : ℤ)) = (s4 : ℤ) ∧
            wRead m 23 (((8 * (r * ctx.p.D₀ + j) + 5 : ℕ) : ℤ)) = (s5 : ℤ) ∧
            wRead m 23 (((8 * (r * ctx.p.D₀ + j) + 6 : ℕ) : ℤ)) = (s6 : ℤ)) := by
  rcases hU with ⟨_, _, _, _, _, hw15, _, _, leafS, _, hleaf_lt, hw16, _, _, _, hDone, hTodo⟩
  refine ⟨le_of_lt ctx.origK_lt_D0, hw15, leafS, hleaf_lt, hw16, ?_, ?_⟩
  · intro r hr
    by_cases hlt : r < i
    · rcases hDone ⟨r, hr⟩ hlt with ⟨_, _, _, ⟨dS, spS, _, _, hdS, _, hspS, _, _, _, e14, e15, _⟩, _⟩
      exact ⟨dS, spS, hdS, hspS, e14, e15⟩
    · rcases (hTodo ⟨r, hr⟩ (Nat.le_of_not_lt hlt)).2.1 with ⟨dS, spS, _, _, hdS, _, hspS, _, _, _, e14, e15, _⟩
      exact ⟨dS, spS, hdS, hspS, e14, e15⟩
  · intro r hr h16
    by_cases hlt : r < i
    · rcases hDone ⟨r, hr⟩ hlt with ⟨oj, _, _, _, hoj_enc⟩
      cases hoj_c : oj with
      | none => rw [hoj_c] at hoj_enc; change wRead m 16 (r : ℤ) = 0 at hoj_enc; omega
      | some g =>
          rw [hoj_c] at hoj_enc
          rcases hoj_enc with ⟨_, _, _, hw19, lvs_h, hlen_eq, hlv_all⟩
          have hj_le : g.lvs.length ≤ ctx.p.D₀ := by
            rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2)
          refine ⟨g.lvs.length, hj_le, hw19, fun j hj => ?_⟩
          rcases (hlv_all j (hlen_eq ▸ hj)).2.2.2.1 with ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr,
            _, _, _, _, _, _, _, _, _, _, e2, e3, e4, e5, e6, _⟩
          exact ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, e2, e3, e4, e5, e6⟩
    · have htd := (hTodo ⟨r, hr⟩ (Nat.le_of_not_lt hlt)).2.2.2
      unfold EncTodoJobAt at htd
      cases hoj_c : ctx.st₀.ownedJob ⟨r, hr⟩ with
      | none => rw [hoj_c] at htd; change wRead m 16 (r : ℤ) = 0 at htd; omega
      | some g =>
          rw [hoj_c] at htd
          rcases htd with ⟨_, _, _, hw19, lvs_h, hlen_eq, hlv_all⟩
          have hj_le : g.lvs.length ≤ ctx.p.D₀ := by
            rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2)
          refine ⟨g.lvs.length, hj_le, hw19, fun j hj => ?_⟩
          rcases (hlv_all j (hlen_eq ▸ hj)).2.2.2.1 with ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr,
            _, _, _, _, _, _, _, _, _, _, e2, e3, e4, e5, e6, _⟩
          exact ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, e2, e3, e4, e5, e6⟩

end UL.Proof_lem_7_2_RacerP46
