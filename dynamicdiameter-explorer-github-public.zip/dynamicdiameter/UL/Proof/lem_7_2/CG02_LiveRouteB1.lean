import UL.Proof.lem_7_2.CG02_LiveRouteA

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Canonical Per-Level Affectedness Predicate & Pure Dichotomy Lemmas -/

/-- Canonical indicator of whether level `j : Fin (k + 1)` of a serving chain (`0 .. k - 1` serving
nodes and `k` terminal leaf) experiences a genuine single-element pool change (`IsInputChange`)
when routing handle `opH` with insertion flag `ins`. -/
noncomputable def chainLevelAffected {d k : ℕ}
    (P P' : DynamicPointSet d) (nodes : Fin k → ChainNode d)
    (ins : Bool) (opH : ℕ) (j : Fin (k + 1)) : Bool :=
  open Classical in
  if ins then
    decide (opH ∈ chainInput P'.handleCoords nodes P'.activeHandles j)
  else
    decide (opH ∈ chainInput P.handleCoords nodes P.activeHandles j)

lemma cg02_insert_dichotomy_aux {d k : ℕ}
    {P P' : DynamicPointSet d} (nodes : Fin k → ChainNode d) {opH : ℕ}
    (hnot : opH ∉ P.activeHandles)
    (hact : P'.activeHandles = insert opH P.activeHandles)
    (hcoords : ∀ x ∈ P.activeHandles, P'.handleCoords x = P.handleCoords x) :
    ∀ (m : ℕ) (hm : m ≤ k),
      let j : Fin (k + 1) := ⟨m, Nat.lt_succ_of_le hm⟩
      let S_pre := chainInput P.handleCoords nodes P.activeHandles j
      let S_post := chainInput P'.handleCoords nodes P'.activeHandles j
      opH ∉ S_pre ∧
      ((opH ∈ S_post ∧ S_post = insert opH S_pre) ∨
       (opH ∉ S_post ∧ S_post = S_pre))
  | 0, _ => by
      dsimp only
      rw [cg02_chainInput_zero, cg02_chainInput_zero, hact]
      exact ⟨hnot, Or.inl ⟨Finset.mem_insert_self _ _, rfl⟩⟩
  | m + 1, hm => by
      classical
      have hm_lt : m < k := Nat.lt_of_succ_le hm
      have hm_le : m ≤ k := Nat.le_of_succ_le hm
      have ih := cg02_insert_dichotomy_aux nodes hnot hact hcoords m hm_le
      dsimp only at ih ⊢
      have hnot_next : opH ∉ chainInput P.handleCoords nodes P.activeHandles ⟨m + 1, Nat.succ_lt_succ hm_lt⟩ :=
        fun hmem => hnot (cg02_chainInput_subset_aux P.handleCoords nodes P.activeHandles (m + 1) hm hmem)
      have hsub_m : chainInput P.handleCoords nodes P.activeHandles ⟨m, Nat.lt_succ_of_le hm_le⟩ ⊆ P.activeHandles :=
        cg02_chainInput_subset_aux P.handleCoords nodes P.activeHandles m hm_le
      refine ⟨hnot_next, ?_⟩
      rw [cg02_chainInput_succ P'.handleCoords nodes P'.activeHandles m hm_lt,
          cg02_chainInput_succ P.handleCoords nodes P.activeHandles m hm_lt]
      rcases ih.2 with ⟨_, hpost_ins⟩ | ⟨_, hpost_eq⟩
      · rw [hpost_ins, cg02_nodeResidual_insert_step (nodes ⟨m, hm_lt⟩) (fun x hx => hcoords x (hsub_m hx))]
        split_ifs with hle
        · exact Or.inr ⟨hnot_next, rfl⟩
        · exact Or.inl ⟨Finset.mem_insert_self _ _, rfl⟩
      · rw [hpost_eq, nodeResidual_congr_on (nodes ⟨m, hm_lt⟩) _ (fun x hx => hcoords x (hsub_m hx))]
        exact Or.inr ⟨hnot_next, rfl⟩

lemma cg02_aff_zero_of_ins {d k : ℕ}
    {P P' : DynamicPointSet d} (nodes : Fin k → ChainNode d) {opH : ℕ}
    (hact : P'.activeHandles = insert opH P.activeHandles) :
    chainLevelAffected P P' nodes true opH ⟨0, Nat.zero_lt_succ k⟩ = true := by
  unfold chainLevelAffected
  rw [if_pos rfl, cg02_chainInput_zero, hact]
  simp

lemma cg02_aff_spec_of_ins {d k : ℕ}
    {P P' : DynamicPointSet d} (nodes : Fin k → ChainNode d) {opH : ℕ}
    (hnot : opH ∉ P.activeHandles)
    (hact : P'.activeHandles = insert opH P.activeHandles)
    (hcoords : ∀ x ∈ P.activeHandles, P'.handleCoords x = P.handleCoords x)
    (j : Fin (k + 1)) :
    let S_pre := chainInput P.handleCoords nodes P.activeHandles j
    let S_post := chainInput P'.handleCoords nodes P'.activeHandles j
    let aff := chainLevelAffected P P' nodes true opH j
    opH ∉ S_pre ∧
    (aff = true → S_post = insert opH S_pre ∧ IsInputChange S_pre S_post) ∧
    (aff = false → opH ∉ S_post ∧ S_post = S_pre) := by
  classical
  have hd := cg02_insert_dichotomy_aux nodes hnot hact hcoords j.val (Nat.lt_succ_iff.mp j.isLt)
  have hj_eq : (⟨j.val, Nat.lt_succ_of_le (Nat.lt_succ_iff.mp j.isLt)⟩ : Fin (k + 1)) = j :=
    Fin.ext rfl
  dsimp only at hd ⊢
  rw [hj_eq] at hd
  refine ⟨hd.1, ?_, ?_⟩
  · intro haff
    simp only [chainLevelAffected, ↓reduceIte, decide_eq_true_eq] at haff
    rcases hd.2 with ⟨_, heq⟩ | ⟨hnot_post, _⟩
    · exact ⟨heq, Or.inl ⟨opH, hd.1, by ext x; simp [heq]⟩⟩
    · exact absurd haff hnot_post
  · intro haff
    simp only [chainLevelAffected, ↓reduceIte, decide_eq_false_iff_not] at haff
    rcases hd.2 with ⟨hin_post, _⟩ | ⟨hnot_post, heq⟩
    · exact absurd hin_post haff
    · exact ⟨hnot_post, heq⟩

lemma cg02_aff_step_of_ins_true {d k : ℕ}
    {P P' : DynamicPointSet d} (nodes : Fin k → ChainNode d) {opH : ℕ}
    (hnot : opH ∉ P.activeHandles)
    (hact : P'.activeHandles = insert opH P.activeHandles)
    (hcoords : ∀ x ∈ P.activeHandles, P'.handleCoords x = P.handleCoords x)
    (r : Fin k)
    (haff_r : chainLevelAffected P P' nodes true opH r.castSucc = true) :
    chainLevelAffected P P' nodes true opH r.succ =
      if euclideanDistSq (P'.handleCoords opH) (nodes r).o ≤ (nodes r).V then false else true := by
  classical
  have hsp := cg02_aff_spec_of_ins nodes hnot hact hcoords r.castSucc
  have hins_eq : chainInput P'.handleCoords nodes P'.activeHandles r.castSucc =
      insert opH (chainInput P.handleCoords nodes P.activeHandles r.castSucc) :=
    (hsp.2.1 haff_r).1
  have hsub_r : chainInput P.handleCoords nodes P.activeHandles r.castSucc ⊆ P.activeHandles :=
    cg02_chainInput_subset P.handleCoords nodes P.activeHandles r.castSucc
  have hnot_next : opH ∉ chainInput P.handleCoords nodes P.activeHandles r.succ :=
    fun hmem => hnot (cg02_chainInput_subset P.handleCoords nodes P.activeHandles r.succ hmem)
  have hsucc_post : chainInput P'.handleCoords nodes P'.activeHandles r.succ =
      (nodes r).residual P'.handleCoords (chainInput P'.handleCoords nodes P'.activeHandles r.castSucc) :=
    cg02_chainInput_succ P'.handleCoords nodes P'.activeHandles r.val r.isLt
  have hsucc_pre : chainInput P.handleCoords nodes P.activeHandles r.succ =
      (nodes r).residual P.handleCoords (chainInput P.handleCoords nodes P.activeHandles r.castSucc) :=
    cg02_chainInput_succ P.handleCoords nodes P.activeHandles r.val r.isLt
  rw [hins_eq, cg02_nodeResidual_insert_step (nodes r) (fun x hx => hcoords x (hsub_r hx)), ← hsucc_pre] at hsucc_post
  simp only [chainLevelAffected, ↓reduceIte, hsucc_post]
  split_ifs with hle
  · simp [hnot_next]
  · simp

lemma cg02_aff_step_of_ins_false {d k : ℕ}
    {P P' : DynamicPointSet d} (nodes : Fin k → ChainNode d) {opH : ℕ}
    (hnot : opH ∉ P.activeHandles)
    (hact : P'.activeHandles = insert opH P.activeHandles)
    (hcoords : ∀ x ∈ P.activeHandles, P'.handleCoords x = P.handleCoords x)
    (r : Fin k)
    (haff_r : chainLevelAffected P P' nodes true opH r.castSucc = false) :
    chainLevelAffected P P' nodes true opH r.succ = false := by
  classical
  have hsp := cg02_aff_spec_of_ins nodes hnot hact hcoords r.castSucc
  have heq_r : chainInput P'.handleCoords nodes P'.activeHandles r.castSucc =
      chainInput P.handleCoords nodes P.activeHandles r.castSucc :=
    (hsp.2.2 haff_r).2
  have hsub_r : chainInput P.handleCoords nodes P.activeHandles r.castSucc ⊆ P.activeHandles :=
    cg02_chainInput_subset P.handleCoords nodes P.activeHandles r.castSucc
  have hnot_next : opH ∉ chainInput P.handleCoords nodes P.activeHandles r.succ :=
    fun hmem => hnot (cg02_chainInput_subset P.handleCoords nodes P.activeHandles r.succ hmem)
  have h1 : chainInput P'.handleCoords nodes P'.activeHandles r.succ =
      (nodes r).residual P'.handleCoords (chainInput P'.handleCoords nodes P'.activeHandles r.castSucc) :=
    cg02_chainInput_succ P'.handleCoords nodes P'.activeHandles r.val r.isLt
  have h2 : chainInput P.handleCoords nodes P.activeHandles r.succ =
      (nodes r).residual P.handleCoords (chainInput P.handleCoords nodes P.activeHandles r.castSucc) :=
    cg02_chainInput_succ P.handleCoords nodes P.activeHandles r.val r.isLt
  have hsucc_post : chainInput P'.handleCoords nodes P'.activeHandles r.succ =
      chainInput P.handleCoords nodes P.activeHandles r.succ := by
    rw [h1, h2, heq_r]
    exact nodeResidual_congr_on (nodes r) _ (fun x hx => hcoords x (hsub_r hx))
  simp [chainLevelAffected, hsucc_post, hnot_next]

lemma cg02_aff_spec_of_del {d k : ℕ}
    {P P' : DynamicPointSet d} (nodes : Fin k → ChainNode d) {opH : ℕ}
    (hact : P'.activeHandles = P.activeHandles.erase opH)
    (hcoords : ∀ x ∈ P'.activeHandles, P'.handleCoords x = P.handleCoords x)
    (j : Fin (k + 1)) :
    let S_pre := chainInput P.handleCoords nodes P.activeHandles j
    let S_post := chainInput P'.handleCoords nodes P'.activeHandles j
    let aff := chainLevelAffected P P' nodes false opH j
    S_post = S_pre.erase opH ∧
    (aff = true → opH ∈ S_pre ∧ IsInputChange S_pre S_post) ∧
    (aff = false → opH ∉ S_pre ∧ opH ∉ S_post ∧ S_post = S_pre) := by
  classical
  have herase : chainInput P'.handleCoords nodes P'.activeHandles j =
      (chainInput P.handleCoords nodes P.activeHandles j).erase opH := by
    rw [hact]
    exact cg02_chainInput_erase nodes (fun x hx => hcoords x (hact ▸ hx)) j
  refine ⟨herase, ?_, ?_⟩
  · intro haff
    simp only [chainLevelAffected, Bool.false_eq_true, ↓reduceIte, decide_eq_true_eq] at haff
    exact ⟨haff, Or.inr ⟨opH, haff, by ext x; simp [herase]⟩⟩
  · intro haff
    simp only [chainLevelAffected, Bool.false_eq_true, ↓reduceIte, decide_eq_false_iff_not] at haff
    have heq : (chainInput P.handleCoords nodes P.activeHandles j).erase opH =
        chainInput P.handleCoords nodes P.activeHandles j :=
      Finset.erase_eq_of_notMem haff
    refine ⟨haff, ?_, herase.trans heq⟩
    rw [herase, heq]
    exact haff

/-! ### 2. `EncServingNode` Frame Lemma & `fd = 0` Segment-Tree Membership Helper -/

lemma EncServingNode.congr_mem {d K NumSlots : ℕ} {m₁ m₂ : ArithRAMMemory}
    {pts₁ pts₂ : ℕ → EuclideanSpace ℝ (Fin d)}
    {r : ℕ} {N : ChainNode d} {S_r : Finset ℕ} {age_r : ℕ}
    (h : EncServingNode d K NumSlots m₁ pts₁ r N S_r age_r)
    (hw13 : wRead m₂ 13 (r : ℤ) = wRead m₁ 13 (r : ℤ))
    (hw14 : wRead m₂ 14 (r : ℤ) = wRead m₁ 14 (r : ℤ))
    (hw15 : wRead m₂ 15 (r : ℤ) = wRead m₁ 15 (r : ℤ))
    (hw6 : ∀ s ∈ snSlotSet m₁ r, wRead m₂ 6 (s : ℤ) = wRead m₁ 6 (s : ℤ))
    (hr12 : ∀ c : Fin d, rRead m₂ 12 (((r * d + c.val : ℕ) : ℤ)) = rRead m₁ 12 (((r * d + c.val : ℕ) : ℤ)))
    (hr13 : rRead m₂ 13 (r : ℤ) = rRead m₁ 13 (r : ℤ))
    (hseg : ∀ s ∈ snSlotSet m₁ r, ∀ S₁ fSq₁,
      EncSegSlot K m₁ s S₁ fSq₁ → EncSegSlot K m₂ s S₁ fSq₁)
    (hpts : ∀ x ∈ S_r, pts₂ x = pts₁ x) :
    EncServingNode d K NumSlots m₂ pts₂ r N S_r age_r := by
  rcases h with ⟨dS, spS, hd0, hd1, hsp0, hsp1, hne, h_age, h_14, h_15, h6_d, h6_sp, h_o, h_V, hSeg_d, hSeg_sp⟩
  have hset : snSlotSet m₁ r = {dS, spS} := EncServingNode.snSlotSet_eq (d := d) (K := K) (NumSlots := NumSlots)
    (livePts := pts₁) (N := N) (S_r := S_r) (age_r := age_r) h_14 h_15
  have hd_in : dS ∈ snSlotSet m₁ r := by rw [hset]; simp
  have hsp_in : spS ∈ snSlotSet m₁ r := by rw [hset]; simp
  have hSeg_d2 : EncSegSlot K m₂ dS S_r (fun x => euclideanDistSq (pts₁ x) N.o) :=
    hseg dS hd_in S_r _ hSeg_d
  have hSeg_d2' : EncSegSlot K m₂ dS S_r (fun x => euclideanDistSq (pts₂ x) N.o) :=
    hSeg_d2.congr_mem_fSq rfl (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl)
      (fun x hx => by rw [hpts x hx])
  exact ⟨dS, spS, hd0, hd1, hsp0, hsp1, hne,
    by rw [hw13, h_age],
    by rw [hw14, h_14],
    by rw [hw15, h_15],
    by rw [hw6 dS hd_in, h6_d],
    by rw [hw6 spS hsp_in, h6_sp],
    fun c => by rw [hr12 c, h_o c],
    by rw [hr13, h_V],
    hSeg_d2',
    hseg spS hsp_in S_r _ hSeg_sp⟩

/-- Check membership `opH = wRead mem 26 4 ∈ S` in segment-tree slot `slotE` and write `1/0` to
`wRead _ 26 8`. -/
def checkInSegSlotTo26Stmt (K M_box : ℕ) (slotE : IntExpr) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 28 (.lit 20) slotE,
    .writeWordLocal 28 (.lit 21) (.readHeap 26 (.lit 4)),
    lookupSegSlotStmt K,
    boxWriteW M_box 26 (.lit 8) (.readLocal 28 (.lit 0))
  ])

theorem boxSafe_checkInSegSlotTo26Stmt {T_max M_box : ℕ} (hT : 27 ≤ T_max)
    (K : ℕ) (slotE : IntExpr) :
    BoxSafeOuter T_max M_box (checkInSegSlotTo26Stmt K M_box slotE) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact boxSafe_lookupSegSlotStmt K
  · exact .boxW (by omega) _ _

theorem exec_checkInSegSlotTo26Stmt {d K M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (slotE : IntExpr) {s h : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    (hh : h < 2 ^ K)
    (hBox : 9 ≤ M_box)
    (hsE : iValAt 1 inp (mem.popDepth 0) slotE = (s : ℤ))
    (hh_reg : wRead mem 26 4 = (h : ℤ))
    (hEnc : EncSegSlot K mem s S fSq) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (checkInSegSlotTo26Stmt K M_box slotE) mem m' (intExprOps slotE + 70) ∧
      m'.popDepth 0 = m' ∧
      wRead m' 26 8 = (if h ∈ S then 1 else 0) ∧
      (∀ t, t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 8 → wRead m' 26 idx = wRead mem 26 idx) ∧
      (∀ t idx, rRead m' t idx = rRead mem t idx) := by
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 28 20 (s : ℤ)
  let m2 := wWriteL 1 m1 28 21 (h : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) slotE) m0 m1 (intExprOps slotE + 2) :=
    DetExecAt.writeWordLocal 1 inp m0 28 _ _ rfl hsE (by simp [intExprOps]; omega)
  have hs2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readHeap 26 (.lit 4))) m1 m2 6 :=
    DetExecAt.writeWordLocal 1 inp m1 28 _ _ rfl (by simp [m1, m0, hh_reg]) (by simp [intExprOps])
  have hEnc_m2 : EncSegSlot K m2 s S fSq :=
    hEnc.congr_mem_fSq (by simp [m2, m1, m0]) (fun _ _ => by simp [m2, m1, m0])
      (fun _ _ => by simp [m2, m1, m0]) (fun _ _ => by simp [m2, m1, m0])
      (fun _ _ => by simp [m2, m1, m0]) (fun _ _ => rfl)
  rcases exec_lookupSegSlotStmt inp m2 hh (by simp [m2, m1]) (by simp [m2]) hEnc_m2
    with ⟨m3, hs3, hres3, hw3, hr3, _, _⟩
  let m4 := wWrite m3 26 8 (if h ∈ S then 1 else 0)
  have hs4 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 8) (.readLocal 28 (.lit 0))) m3 m4 15 :=
    exec_boxWriteW inp m3 _ _ rfl (by omega) (by omega) (by simp [hres3]) (by simp [intExprOps])
  refine ⟨m4.popDepth 0,
    DetExecAt.localScope ((hs1.seq (hs2.seq (hs3.seq hs4))).mono_cost (by omega)),
    popDepth_zero_idem m4,
    by simp [m4],
    fun t ht idx => by simp [m4, ht, hw3, m2, m1, m0],
    fun idx hne => by simp [m4, hne, hw3, m2, m1, m0],
    fun t idx => by simp [m4, hr3, m2, m1, m0]⟩

/-! ### 3. Step 2 & Step 3 Statements (`routeOneServingNodeStmt`, `routeTerminalLeafStmt`) -/

def routeOneServingNodeCost (d K : ℕ) : ℕ :=
  600 * (K + 1) + 150 * (d + 1) + 400

/-- Route `(opH = wRead mem 26 4, ins = (wRead mem 26 5 == 1))` across serving node `r = wRead mem 26 7`
(if `r < chainLen = wRead mem 1 5`), recording `snAffected[r]` in `wRead _ 20 r`, incrementing
`snAge[r]` in `wRead _ 13 r` when affected, updating `snDictSlot[r]` and `snSpareSlot[r]`, testing
core-ball membership `rSq ≤ V_r` on `.insert`, and advancing `wRead _ 26 7 := r + 1`. -/
def routeOneServingNodeStmt (d K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .ite (.intLt (.readHeap 26 (.lit 7)) (.readHeap 1 (.lit 5)))
      (seqList [
        .ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
          (boxWriteW M_box 26 (.lit 8) (.readHeap 26 (.lit 9)))
          (checkInSegSlotTo26Stmt K M_box (.readHeap 14 (.readHeap 26 (.lit 7)))),
        boxWriteW M_box 20 (.readHeap 26 (.lit 7)) (.readHeap 26 (.lit 8)),
        .ite (.intEq (.readHeap 26 (.lit 8)) (.lit 1))
          (seqList [
            boxWriteW M_box 13 (.readHeap 26 (.lit 7))
              (.add (.readHeap 13 (.readHeap 26 (.lit 7))) (.lit 1)),
            boxWriteW M_box 26 (.lit 3) (.readHeap 14 (.readHeap 26 (.lit 7))),
            boxWriteW M_box 26 (.lit 6) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ))),
            updSegCenterStmt d K M_box 12,
            boxWriteW M_box 26 (.lit 3) (.readHeap 15 (.readHeap 26 (.lit 7))),
            updSegZeroStmt K M_box,
            .ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
              (.ite (.realLe (.readRealHeap 26 (.lit 0))
                             (.readRealHeap 13 (.readHeap 26 (.lit 7))))
                (boxWriteW M_box 26 (.lit 9) (.lit 0))
                (boxWriteW M_box 26 (.lit 9) (.lit 1)))
              .skip
          ])
          .skip
      ])
      .skip,
    boxWriteW M_box 26 (.lit 7) (.add (.readHeap 26 (.lit 7)) (.lit 1))
  ]

theorem boxSafe_routeOneServingNodeStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (d K : ℕ) :
    BoxSafeOuter T_max M_box (routeOneServingNodeStmt d K M_box) := by
  unfold routeOneServingNodeStmt
  apply boxSafeOuter_seqList
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl
  · refine .ite _ (boxSafeOuter_seqList ?_) .skip
    intro s' hs'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl | rfl
    · exact .ite _ (.boxW (by omega) _ _) (boxSafe_checkInSegSlotTo26Stmt hT K _)
    · exact .boxW (by omega) _ _
    · refine .ite _ (boxSafeOuter_seqList ?_) .skip
      intro s2 hs2
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hs2
      rcases hs2 with rfl | rfl | rfl | rfl | rfl | rfl | rfl
      · exact .boxW (by omega) _ _
      · exact .boxW (by omega) _ _
      · exact .boxW (by omega) _ _
      · exact boxSafe_updSegCenterStmt hT d K 12
      · exact .boxW (by omega) _ _
      · exact boxSafe_updSegZeroStmt (by omega) K
      · exact .ite _ (.ite _ (.boxW (by omega) _ _) (.boxW (by omega) _ _)) .skip
  · exact .boxW (by omega) _ _

/-- Route `(opH, ins)` into terminal leaf pool `leafS = wRead mem 1 6` and normalize `popDepth 0`. -/
def routeTerminalLeafStmt (K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
      (boxWriteW M_box 26 (.lit 8) (.readHeap 26 (.lit 9)))
      (checkInSegSlotTo26Stmt K M_box (.readHeap 1 (.lit 6))),
    .ite (.intEq (.readHeap 26 (.lit 8)) (.lit 1))
      (seqList [
        boxWriteW M_box 26 (.lit 3) (.readHeap 1 (.lit 6)),
        updSegZeroStmt K M_box
      ])
      .skip,
    .localScope .skip
  ]

theorem boxSafe_routeTerminalLeafStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (K : ℕ) :
    BoxSafeOuter T_max M_box (routeTerminalLeafStmt K M_box) := by
  unfold routeTerminalLeafStmt
  apply boxSafeOuter_seqList
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl
  · exact .ite _ (.boxW (by omega) _ _) (boxSafe_checkInSegSlotTo26Stmt hT K _)
  · refine .ite _ (boxSafeOuter_seqList ?_) .skip
    intro s' hs'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl
    · exact .boxW (by omega) _ _
    · exact boxSafe_updSegZeroStmt (by omega) K
  · exact .localScope .skip

/-! ### 4. Serving-Chain Loop Context & Invariant (`RouteLoopCtx`, `RouteLoopInv`) -/

/-- Loop-constant hypotheses shared across the `D₀` iterations of `routeOneServingNodeStmt`. -/
structure RouteLoopCtx (d n K D₀ NumSlots M_box k leafS opH : ℕ)
    (P P' : DynamicPointSet d) (nodes : Fin k → ChainNode d) (snAge : Fin k → ℕ)
    (ins : Bool) (mem mA : ArithRAMMemory) : Prop where
  hBox : RouteBoxBounds d n K D₀ NumSlots M_box
  hSlots2 : 2 ≤ NumSlots
  hleaf_lt : leafS < NumSlots
  hopH_K : opH < 2 ^ K
  hw15_A : wRead mA 1 5 = (k : ℤ)
  hw14_A : ∀ idx, wRead mA 14 idx = wRead mem 14 idx
  hw15_tbl_A : ∀ idx, wRead mA 15 idx = wRead mem 15 idx
  hLive_A : EncLiveCoords d n mA P'.activeHandles P'.handleCoords
  hsn : ∀ r : Fin k,
    EncServingNode d K NumSlots mem P.handleCoords r.val (nodes r)
      (chainInput P.handleCoords nodes P.activeHandles r.castSucc) (snAge r)
  hdisj_0leaf : ∀ r : Fin k, ∀ s ∈ snSlotSet mem r.val, s ≠ 0 ∧ s ≠ leafS
  hdisj_sn : ∀ r₁ r₂ : Fin k, r₁ ≠ r₂ → Disjoint (snSlotSet mem r₁.val) (snSlotSet mem r₂.val)
  hh_act_ins : ins = true → opH ∈ P'.activeHandles
  hAffProps : ∀ j : Fin (k + 1),
    let aff := chainLevelAffected P P' nodes ins opH
    let S_pre := chainInput P.handleCoords nodes P.activeHandles
    let S_post := chainInput P'.handleCoords nodes P'.activeHandles
    (aff j = false → opH ∉ S_pre j ∧ opH ∉ S_post j ∧ S_post j = S_pre j) ∧
    (aff j = true →
      IsInputChange (S_pre j) (S_post j) ∧
      (ins = true → opH ∉ S_pre j ∧ S_post j = insert opH (S_pre j)) ∧
      (ins = false → opH ∈ S_pre j ∧ S_post j = (S_pre j).erase opH))
  hCoordsOther : ∀ j : Fin (k + 1),
    ∀ x ∈ chainInput P.handleCoords nodes P.activeHandles j, x ≠ opH →
      P'.handleCoords x = P.handleCoords x
  hCoordsUnchanged : ∀ j : Fin (k + 1),
    chainLevelAffected P P' nodes ins opH j = false →
    ∀ x ∈ chainInput P.handleCoords nodes P.activeHandles j,
      P'.handleCoords x = P.handleCoords x
  hAffInsFalse : ins = true → ∀ r : Fin k,
    chainLevelAffected P P' nodes ins opH r.castSucc = false →
    chainLevelAffected P P' nodes ins opH r.succ = false
  hAffInsTrue : ins = true → ∀ r : Fin k,
    chainLevelAffected P P' nodes ins opH r.castSucc = true →
    chainLevelAffected P P' nodes ins opH r.succ =
      (if euclideanDistSq (P'.handleCoords opH) (nodes r).o ≤ (nodes r).V then false else true)

/-- Loop invariant at iteration `i ≤ D₀` of `routeOneServingNodeStmt`. -/
def RouteLoopInv {d k : ℕ} (K NumSlots leafS opH : ℕ)
    (P P' : DynamicPointSet d) (nodes : Fin k → ChainNode d) (snAge : Fin k → ℕ)
    (ins : Bool) (mem mA : ArithRAMMemory) (i : ℕ) (m : ArithRAMMemory) : Prop :=
  let aff := chainLevelAffected P P' nodes ins opH
  let S_pre := chainInput P.handleCoords nodes P.activeHandles
  let S_post := chainInput P'.handleCoords nodes P'.activeHandles
  SegGenBound K NumSlots m ∧
  wRead m 26 4 = (opH : ℤ) ∧
  wRead m 26 5 = (if ins then 1 else 0) ∧
  wRead m 26 7 = (i : ℤ) ∧
  (ins = true →
    wRead m 26 9 = (if aff ⟨min i k, Nat.lt_succ_of_le (Nat.min_le_right i k)⟩ then 1 else 0)) ∧
  EncSegSlot K m 0 P'.activeHandles (fun _ => 0) ∧
  EncSegSlot K m leafS (S_pre (Fin.last k)) (fun _ => 0) ∧
  (∀ r : Fin k, r.val < i →
    EncServingNode d K NumSlots m P'.handleCoords r.val (nodes r) (S_post r.castSucc)
      (if aff r.castSucc then snAge r + 1 else snAge r) ∧
    wRead m 20 (r.val : ℤ) = (if aff r.castSucc then 1 else 0)) ∧
  (∀ r : Fin k, i ≤ r.val →
    EncServingNode d K NumSlots m P.handleCoords r.val (nodes r) (S_pre r.castSucc) (snAge r)) ∧
  (∀ s' < NumSlots,
    s' ≠ 0 → s' ≠ leafS → (∀ r : Fin k, s' ∉ snSlotSet mem r.val) →
    ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m s' S₁ fSq₁) ∧
  (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 13 → t ≠ 20 → t ≠ 26 →
    ∀ idx, wRead m t idx = wRead mA t idx) ∧
  (∀ idx, (idx < 0 ∨ (min i k : ℤ) ≤ idx) → wRead m 13 idx = wRead mA 13 idx) ∧
  (∀ t, t ≠ 8 → t ≠ 26 → ∀ idx, rRead m t idx = rRead mA t idx)

/-- Inactive padding step `k ≤ i < D₀` of `routeOneServingNodeStmt`. -/
theorem exec_routeOneServingNodeStmt_pad {d n K D₀ NumSlots M_box k leafS opH : ℕ}
    (inp : ArithRAMInput d)
    {P P' : DynamicPointSet d} {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ}
    {ins : Bool} {mem mA : ArithRAMMemory}
    (hCtx : RouteLoopCtx d n K D₀ NumSlots M_box k leafS opH P P' nodes snAge ins mem mA)
    {i : ℕ} (hge_k : k ≤ i) {m : ArithRAMMemory}
    (hm : RouteLoopInv K NumSlots leafS opH P P' nodes snAge ins mem mA i m) :
    ∃ m_next : ArithRAMMemory,
      DetExecAt 0 inp (routeOneServingNodeStmt d K M_box) m m_next (routeOneServingNodeCost d K) ∧
      RouteLoopInv K NumSlots leafS opH P P' nodes snAge ins mem mA (i + 1) m_next := by
  have hBox30 := hCtx.hBox.1
  have hSlots2 := hCtx.hSlots2
  have hleaf_lt := hCtx.hleaf_lt
  rcases hm with ⟨hseg_m, hm26_4, hm26_5, hm26_7, hm26_9, hSeg0_m, hSegL_m,
                  hDone_m, _, hRest_m, hw_m, hw13_m, hr_m⟩
  have hw15_m : wRead m 1 5 = (k : ℤ) := by
    rw [hw_m 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hCtx.hw15_A]
  have hsnSet_eq : ∀ r : Fin k, snSlotSet m r.val = snSlotSet mem r.val := by
    intro r; unfold snSlotSet
    rw [hw_m 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw_m 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hCtx.hw14_A, hCtx.hw15_tbl_A]
  have hmin_i : min i k = k := Nat.min_eq_right hge_k
  have hmin_succ : min (i + 1) k = k := Nat.min_eq_right (Nat.le_succ_of_le hge_k)
  have hcond_lt : cValAt 0 inp m (.intLt (.readHeap 26 (.lit 7)) (.readHeap 1 (.lit 5))) = false := by
    simp only [cValAt_intLt, iValAt_readHeap, iValAt_lit, hm26_7, hw15_m, decide_eq_false_iff_not]
    omega
  let m_next := wWrite m 26 7 ((i + 1 : ℕ) : ℤ)
  have hex_skip : DetExecAt 0 inp
      (.ite (.intLt (.readHeap 26 (.lit 7)) (.readHeap 1 (.lit 5)))
        (seqList [
          .ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
            (boxWriteW M_box 26 (.lit 8) (.readHeap 26 (.lit 9)))
            (checkInSegSlotTo26Stmt K M_box (.readHeap 14 (.readHeap 26 (.lit 7)))),
          boxWriteW M_box 20 (.readHeap 26 (.lit 7)) (.readHeap 26 (.lit 8)),
          .ite (.intEq (.readHeap 26 (.lit 8)) (.lit 1))
            (seqList [
              boxWriteW M_box 13 (.readHeap 26 (.lit 7))
                (.add (.readHeap 13 (.readHeap 26 (.lit 7))) (.lit 1)),
              boxWriteW M_box 26 (.lit 3) (.readHeap 14 (.readHeap 26 (.lit 7))),
              boxWriteW M_box 26 (.lit 6) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ))),
              updSegCenterStmt d K M_box 12,
              boxWriteW M_box 26 (.lit 3) (.readHeap 15 (.readHeap 26 (.lit 7))),
              updSegZeroStmt K M_box,
              .ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
                (.ite (.realLe (.readRealHeap 26 (.lit 0))
                               (.readRealHeap 13 (.readHeap 26 (.lit 7))))
                  (boxWriteW M_box 26 (.lit 9) (.lit 0))
                  (boxWriteW M_box 26 (.lit 9) (.lit 1)))
                .skip
            ]) .skip
        ]) .skip) m m 20 :=
    (DetExecAt.ite_false hcond_lt (C_c := 15) (by simp [condExprOps, intExprOps])
      (DetExecAt.skip 0 inp m)).mono_cost (by omega)
  have hex4 : DetExecAt 0 inp
      (boxWriteW M_box 26 (.lit 7) (.add (.readHeap 26 (.lit 7)) (.lit 1))) m m_next 20 :=
    exec_boxWriteW inp m _ _ rfl (by omega) (by omega)
      (by simp [hm26_7]) (by simp [intExprOps])
  have hex_body : DetExecAt 0 inp (routeOneServingNodeStmt d K M_box) m m_next (routeOneServingNodeCost d K) := by
    unfold routeOneServingNodeStmt seqList
    exact (hex_skip.seq hex4).mono_cost (by unfold routeOneServingNodeCost; omega)
  have liftSeg_pad : ∀ s' < NumSlots, ∀ S₁ fSq₁, EncSegSlot K m s' S₁ fSq₁ → EncSegSlot K m_next s' S₁ fSq₁ := by
    intro s' _ S₁ fSq₁ hE
    exact hE.congr_mem_fSq
      (by simp [m_next]) (fun _ _ => by simp [m_next]) (fun _ _ => by simp [m_next])
      (fun _ _ => by simp [m_next]) (fun _ _ => by simp [m_next]) (fun _ _ => rfl)
  refine ⟨m_next, hex_body,
    ⟨by simp [m_next]; exact hseg_m.1,
     fun s hs => by simp [m_next]; exact hseg_m.2.1 s hs,
     fun s hs u hu => by simp [m_next]; exact hseg_m.2.2 s hs u hu⟩,
    by simp [m_next, hm26_4],
    by simp [m_next, hm26_5],
    by simp [m_next],
    fun hins => by
      have hfin : (⟨min (i + 1) k, Nat.lt_succ_of_le (Nat.min_le_right (i + 1) k)⟩ : Fin (k + 1)) =
          ⟨min i k, Nat.lt_succ_of_le (Nat.min_le_right i k)⟩ :=
        Fin.ext (hmin_succ.trans hmin_i.symm)
      rw [hfin]; simp [m_next, hm26_9 hins],
    liftSeg_pad 0 (by omega) _ _ hSeg0_m,
    liftSeg_pad leafS hleaf_lt _ _ hSegL_m,
    fun r' _ => by
      rcases hDone_m r' (lt_of_lt_of_le r'.isLt hge_k) with ⟨hEN, hw20_r'⟩
      refine ⟨hEN.congr_mem (by simp [m_next]) (by simp [m_next]) (by simp [m_next])
        (fun _ _ => by simp [m_next]) (fun _ => by simp [m_next]) (by simp [m_next])
        (fun s hs_in S₁ fSq₁ hE => by
          rw [hsnSet_eq r'] at hs_in
          rcases hCtx.hsn r' with ⟨d1, s1, _, hd1, _, hs1_lt, _, _, e14, e15, _⟩
          have hset' := EncServingNode.snSlotSet_eq (d := d) (K := K) (NumSlots := NumSlots)
            (livePts := P.handleCoords) (N := nodes r')
            (S_r := chainInput P.handleCoords nodes P.activeHandles r'.castSucc) (age_r := snAge r') e14 e15
          have hslt : s < NumSlots := by rw [hset'] at hs_in; simp at hs_in; rcases hs_in with rfl | rfl <;> assumption
          exact liftSeg_pad s hslt S₁ fSq₁ hE)
        (fun _ _ => rfl),
        by simp [m_next, hw20_r']⟩,
    fun r' hr' => absurd (lt_of_lt_of_le r'.isLt hge_k) (Nat.not_lt_of_ge (Nat.le_of_succ_le hr')),
    fun s' hs' h0 hL hno S₁ fSq₁ hE => liftSeg_pad s' hs' S₁ fSq₁ (hRest_m s' hs' h0 hL hno S₁ fSq₁ hE),
    fun t h8 h9 h10 h13 h20 h26 idx => by simp [m_next, h26, hw_m t h8 h9 h10 h13 h20 h26],
    fun idx hidx => by
      simp [m_next, hw13_m idx (by omega)],
    fun t h8 h26 idx => by simp [m_next, hr_m t h8 h26]⟩

end UL.Proof_lem_7_2_RacerP46
