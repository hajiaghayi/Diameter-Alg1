import UL.Proof.lem_7_2.CG01_NodeSpec0b1

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### Stage 2b2: Pure Post-OpenLevel Builder (`cg01_postEndAction_of_openLevel`) -/

theorem cg01_postEndAction_of_openLevel
    (h_lem_5_1 : S_lem_5_1)
    {ctx : MidLoopCtx} {gFlag b : Bool} {i : ℕ} (hi : i < ctx.st₀.k)
    {g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩)}
    {m₁ m₂ : ArithRAMMemory}
    {lvs_h : List (JobLvData ctx.d)} {hlen_eq : lvs_h.length = g₀.lvs.length}
    {ph' scan' : ℕ}
    {spRS_last dS_n spDS_n rS_n spRS_n : ℕ}
    {o_cand : EuclideanSpace ℝ (Fin ctx.d)} {s_cand : ℝ}
    {prov_new : ChainNode ctx.d}
    (pb : ActivePropBuildState ctx gFlag i hi g₀ m₁)
    (haff : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = true)
    (hsome : ctx.st₀.ownedJob ⟨i, hi⟩ = some g₀)
    (hph'_le : ph' ≤ 2)
    (hlv_all : ∀ (j : ℕ) (hj : j < lvs_h.length),
      let idx := i * ctx.p.D₀ + j
      let hj_g : j < g₀.lvs.length := hlen_eq ▸ hj
      (lvs_h[j]'hj).ball (ctx.d + 3) = (g₀.lvs[j]'hj_g).ball ∧
      (lvs_h[j]'hj).openRem = g₀.openRem j ∧
      (∃ (f_b g_b : ℕ → ℕ),
        (∀ h ∈ (lvs_h[j]'hj).S_birth,
          f_b h ∈ (g₀.lvs[j]'hj_g).birthSnapshot ∧
          ctx.uMap'.ghostCoords (f_b h) = (lvs_h[j]'hj).snapPts h ∧
          g_b (f_b h) = h) ∧
        (∀ u ∈ (g₀.lvs[j]'hj_g).birthSnapshot,
          g_b u ∈ (lvs_h[j]'hj).S_birth ∧
          f_b (g_b u) = u)) ∧
      EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₁
        ctx.P'.activeHandles ctx.P'.handleCoords idx
        (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
        (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) j)
        (decide (j + 1 = lvs_h.length)) ∧
      wRead m₁ 23 (((8 * idx + 7 : ℕ) : ℤ)) = (g₀.openRem j : ℤ) ∧
      0 < (wRead m₁ 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 3 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 4 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 5 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat ∧
      (j + 1 < lvs_h.length → wRead m₁ 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2))
    (hpar_1 :
      let Spar_last_h' := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) (g₀.lvs.length - 1)
      Spar_last_h'.card ≤ g₀.Spar_last_h.card + 1 ∧
      ∀ c : ℕ, (Spar_last_h'.filter (fun x => c ≤ x)).card ≤
               (g₀.Spar_last_h.filter (fun x => c ≤ x)).card + 1)
    (hbuild_1 :
      let Spar_last_h' := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) (g₀.lvs.length - 1)
      let m_last := (g₀.lvs[g₀.lvs.length - 1]'(Nat.sub_lt g₀.hlvs_pos Nat.one_pos)).birthSnapshot.card
      (g₀.ph_cur = 0 →
        (g₀.scan_cur + (ctx.p.B_scan + 1) < m_last → ph' = 0 ∧ scan' = g₀.scan_cur + (ctx.p.B_scan + 1)) ∧
        (m_last ≤ g₀.scan_cur + (ctx.p.B_scan + 1) → ph' = 1 ∧ scan' = 0)) ∧
      (g₀.ph_cur = 1 →
        ph' = 2 ∨
        (ph' = 1 ∧
          (Spar_last_h'.filter (fun x => scan' ≤ x)).card + ctx.p.B_scan ≤
            (g₀.Spar_last_h.filter (fun x => g₀.scan_cur ≤ x)).card)) ∧
      (g₀.ph_cur = 2 → ph' = 2))
    (hcl : g₀.closed = false)
    (hph2 : ph' = 2)
    (hw24_last_m1 : wRead m₁ 24 (((2 * (i * ctx.p.D₀ + (g₀.lvs.length - 1)) + 0 : ℕ) : ℤ)) = 2)
    (hcan : CanOpenResidualLevel (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2))
      (g₀.H_job - (g₀.t_cur + 1))
      (prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u ⟨i, hi⟩)).card)
    (hlarge : 2 * ctx.p.L + 1 <
      (prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u ⟨i, hi⟩)).card)
    (hw_spRS_last : wRead m₁ 23 (((8 * (i * ctx.p.D₀ + (g₀.lvs.length - 1)) + 6 : ℕ) : ℤ)) = (spRS_last : ℤ))
    (hspRS_last_pos : 0 < spRS_last)
    (h6_spRS_m1 : wRead m₁ 6 (spRS_last : ℤ) = 0)
    (hdS_n0 : 0 < dS_n) (hdS_n_notU : dS_n ∉ activeSlotSet m₁ ctx.p.D₀)
    (hspDS_n0 : 0 < spDS_n) (hspDS_n_notU : spDS_n ∉ activeSlotSet m₁ ctx.p.D₀)
    (hrS_n0 : 0 < rS_n) (hrS_n_notU : rS_n ∉ activeSlotSet m₁ ctx.p.D₀)
    (hspRS_n0 : 0 < spRS_n) (hspRS_n_notU : spRS_n ∉ activeSlotSet m₁ ctx.p.D₀)
    (hw27_2 : wRead m₂ 26 27 = 0)
    (hSeg2 : SegGenBound ctx.p.K_seg ctx.p.NumSlots m₂)
    (hSave2 : SaveGenBound ctx.n ctx.p.NumSlots m₂)
    (hLive2 : EncLiveCoords ctx.d ctx.n m₂ ctx.P'.activeHandles ctx.P'.handleCoords)
    (hw1_5_2 : wRead m₂ 1 5 = wRead m₁ 1 5)
    (hw1_6_2 : wRead m₂ 1 6 = wRead m₁ 1 6)
    (hw11_2 : ∀ k, wRead m₂ 11 k = wRead m₁ 11 k)
    (hr11_2 : ∀ k, rRead m₂ 11 k = rRead m₁ 11 k)
    (hw14_2 : ∀ r, wRead m₂ 14 r = wRead m₁ 14 r)
    (hw15_2 : ∀ r, wRead m₂ 15 r = wRead m₁ 15 r)
    (hw16_2 : ∀ r, wRead m₂ 16 r = wRead m₁ 16 r)
    (hw19_i2 : wRead m₂ 19 (i : ℤ) = (((g₀.lvs.length + 1 : ℕ) : ℤ)))
    (hw19_ne2 : ∀ r ≠ i, wRead m₂ 19 (r : ℤ) = wRead m₁ 19 (r : ℤ))
    (hwRem_i2 : wRead m₂ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) =
      (((g₀.H_job - (g₀.t_cur + 1) : ℕ) : ℤ)))
    (hwRem_ne2 : ∀ r ≠ i, wRead m₂ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) =
      wRead m₁ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ))
    (hwCl_i2 : wRead m₂ ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx i : ℤ) = 0)
    (hwCl_ne2 : ∀ r ≠ i, wRead m₂ ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ) =
      wRead m₁ ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ))
    (hw_bc2 : ∀ r, wRead m₂ ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ) =
      wRead m₁ ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ))
    (hw_age2 : ∀ r, wRead m₂ ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ) =
      wRead m₁ ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ))
    (hw_aff2 : ∀ r, wRead m₂ ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ) =
      wRead m₁ ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ))
    (hrO_2 : ∀ k, rRead m₂ ctx.cfg.rSnCenterO k = rRead m₁ ctx.cfg.rSnCenterO k)
    (hrV_2 : ∀ k, rRead m₂ ctx.cfg.rSnCenterV.tag k = rRead m₁ ctx.cfg.rSnCenterV.tag k)
    (h6_spRS_2 : 1 ≤ wRead m₂ 6 (spRS_last : ℤ))
    (hw6_not5 : ∀ s : ℕ, s ≠ spRS_last → s ≠ dS_n → s ≠ spDS_n → s ≠ rS_n → s ≠ spRS_n →
      wRead m₂ 6 (s : ℤ) = wRead m₁ 6 (s : ℤ))
    (hSegPres2 : ∀ s < ctx.p.NumSlots, s ≠ dS_n → s ≠ spDS_n → s ≠ rS_n → s ≠ spRS_n →
      ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m₂ s S₁ fSq₁)
    (hEncLvNew :
      let curRes_h := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) lvs_h.length
      EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₂
        ctx.P'.activeHandles ctx.P'.handleCoords (i * ctx.p.D₀ + g₀.lvs.length)
        curRes_h ctx.P'.handleCoords prov_new curRes_h true)
    (hballNew :
      let curRes_h := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) lvs_h.length
      let curRes_u := prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u ⟨i, hi⟩)
      ∀ (hb_pos : 0 < curRes_h.card),
        let α := 1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)
        let bId := curRes_h.orderEmbOfFin rfl ⟨0, hb_pos⟩
        applyBirthCoreFallback α ctx.P'.handleCoords curRes_h prov_new =
          selectOpenedLevelBall α ctx.uMap'.ghostCoords curRes_u (ctx.uMap'.uidOfH bId)
            (.candidate o_cand (liftVariance o_cand s_cand)))
    (hw23_new :
      let newIdx := i * ctx.p.D₀ + g₀.lvs.length
      wRead m₂ 23 (((8 * newIdx + 2 : ℕ) : ℤ)) = (spRS_last : ℤ) ∧
      wRead m₂ 23 (((8 * newIdx + 3 : ℕ) : ℤ)) = (dS_n : ℤ) ∧
      wRead m₂ 23 (((8 * newIdx + 4 : ℕ) : ℤ)) = (spDS_n : ℤ) ∧
      wRead m₂ 23 (((8 * newIdx + 5 : ℕ) : ℤ)) = (rS_n : ℤ) ∧
      wRead m₂ 23 (((8 * newIdx + 6 : ℕ) : ℤ)) = (spRS_n : ℤ) ∧
      wRead m₂ 23 (((8 * newIdx + 7 : ℕ) : ℤ)) = (((g₀.H_job - (g₀.t_cur + 1) : ℕ) : ℤ)) ∧
      jobLevelLiveSlots m₂ newIdx true = {spRS_n, dS_n, spDS_n, rS_n})
    (hw24_new :
      let newIdx := i * ctx.p.D₀ + g₀.lvs.length
      wRead m₂ 24 (((2 * newIdx + 0 : ℕ) : ℤ)) = 0 ∧
      wRead m₂ 24 (((2 * newIdx + 1 : ℕ) : ℤ)) = 0)
    (hw23_old : ∀ idx ≠ i * ctx.p.D₀ + g₀.lvs.length, ∀ a < 8,
      wRead m₂ 23 (((8 * idx + a : ℕ) : ℤ)) = wRead m₁ 23 (((8 * idx + a : ℕ) : ℤ)))
    (hw24_old : ∀ idx ≠ i * ctx.p.D₀ + g₀.lvs.length, ∀ a < 2,
      wRead m₂ 24 (((2 * idx + a : ℕ) : ℤ)) = wRead m₁ 24 (((2 * idx + a : ℕ) : ℤ)))
    (hr23_old : ∀ idx ≠ i * ctx.p.D₀ + g₀.lvs.length, ∀ c : Fin ctx.d,
      rRead m₂ 23 (((idx * ctx.d + c.val : ℕ) : ℤ)) = rRead m₁ 23 (((idx * ctx.d + c.val : ℕ) : ℤ)))
    (hr24_old : ∀ idx ≠ i * ctx.p.D₀ + g₀.lvs.length, ∀ a < 2,
      rRead m₂ 24 (((2 * idx + a : ℕ) : ℤ)) = rRead m₁ 24 (((2 * idx + a : ℕ) : ℤ)))
    (hb_good : b = true → gFlag = true ∧
      let α := 1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)
      let curRes_h := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) lvs_h.length
      let curRes_u := prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u ⟨i, hi⟩)
      let ball := applyBirthCoreFallback α ctx.P'.handleCoords curRes_h prov_new
      IsCenterpoint α
        (paraboloidLiftSet (fun u : ↥curRes_u => ctx.uMap'.ghostCoords u.1))
        (liftedPoint ball.o (ball.V + ‖ball.o‖ ^ 2))) :
    ∃ g' : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
        ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u ⟨i, hi⟩),
      PostEndActionJobState ctx b i hi m₂ g' := by
  classical
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  let jLen := g₀.lvs.length
  let newIdx := i * ctx.p.D₀ + jLen
  let rem' := g₀.H_job - (g₀.t_cur + 1)
  have hD : 3 ≤ ctx.d + 3 := by omega
  have hjLen_pos : 1 ≤ jLen := g₀.hlvs_pos
  have hjLen_lt_D0 : jLen < ctx.p.D₀ := by
    rw [ctx.hD0_eq]; exact g₀.lvs_length_lt ctx.hH5 ctx.hn2
  rcases ctx.hwf₀.1 r_fin with ⟨_, _, _, _, _, hjob0⟩
  rw [hsome] at hjob0
  rcases hjob0 with ⟨ht_lt, hage0_eq, hm0_le0⟩
  rcases ((ctx.hPerNode r_fin).2 haff).2.2.2.2 with ⟨ev_r, hev_ck, hev_v⟩
  have hsub_post : ctx.S_post_h r_fin ⊆ ctx.P'.activeHandles :=
    cg01_chainInput_subset ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles r_fin.castSucc
  have hmap_eq : ctx.uMap'.mapSet (ctx.S_post_h r_fin) = ctx.S_post_u r_fin :=
    ctx.uMap'.mapSet_chainInput ctx.st₀.nodes r_fin.castSucc
  have hbij_root := ctx.uMap'.mapSet_bij hsub_post
  have hcap_u : (ctx.S_post_u r_fin).card ≤ ctx.n := by
    rw [← hmap_eq, hbij_root.1]
    exact (Finset.card_le_card hsub_post).trans
      ((activeHandles_card_eq_activeIds_card ctx.hP').trans_le ctx.hP'.1)
  have huid_u : ∀ u ∈ ctx.S_post_u r_fin, u < ctx.uMap'.nextUid := hmap_eq ▸ hbij_root.2.1
  rcases cg01_curRes_bij ctx hi lvs_h g₀.lvs hlen_eq (fun j hj => (hlv_all j hj).1)
    with ⟨_, hf_cur, hg_cur, hcard_cur⟩
  let curRes_h := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) lvs_h.length
  let curRes_u := prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u r_fin)
  have hb_pos : 0 < curRes_h.card := by change 0 < _; rw [hcard_cur]; omega
  let bId : ℕ := curRes_h.orderEmbOfFin rfl ⟨0, hb_pos⟩
  have hbId_mem : bId ∈ curRes_h := Finset.orderEmbOfFin_mem _ rfl ⟨0, hb_pos⟩
  have hbUid_mem : ctx.uMap'.uidOfH bId ∈ curRes_u := (hf_cur bId hbId_mem).1
  let res_cand : SampledCenterResult ctx.d := .candidate o_cand (liftVariance o_cand s_cand)
  let act : JobTickEndAction ctx.d (ctx.d + 3) ctx.p.L ctx.uMap'.ghostCoords
      rem' g₀.closed ph' curRes_u :=
    .openLevel hcl hph2 hcan hlarge (ctx.uMap'.uidOfH bId) hbUid_mem res_cand curRes_h hcard_cur
  let g_lift := g₀.liftCoords ctx.hle_uid ctx.hag_uid
  let g' := g_lift.stepTick hD ht_lt ev_r hev_ck hev_v hcap_u huid_u hph'_le hpar_1 hbuild_1 act
  refine ⟨g', ?_⟩
  rcases pb.hChainRest with ⟨leafS, hl0, hllt, hw1_6, hw6_leaf, hSegLeaf, hDisj⟩
  have hdS_np := not_in_activeSlotSet_props pb.hw1_5 hw1_6 hdS_n_notU
  have hspDS_np := not_in_activeSlotSet_props pb.hw1_5 hw1_6 hspDS_n_notU
  have hrS_np := not_in_activeSlotSet_props pb.hw1_5 hw1_6 hrS_n_notU
  have hspRS_np := not_in_activeSlotSet_props pb.hw1_5 hw1_6 hspRS_n_notU
  have h19_i_nat1 : (wRead m₁ 19 (i : ℤ)).toNat = jLen := by rw [pb.hw19_i]; simp [jLen]
  rcases cg01_openLevel_slot_disj hi hlen_eq pb hw1_6 hDisj
      (fun j hj => (hlv_all j hj).2.2.2.1) hw_spRS_last h6_spRS_m1
      hdS_n_notU hspDS_n_notU hrS_n_notU hspRS_n_notU
      hw14_2 hw15_2 hw16_2 hw19_i2 hw19_ne2 hw23_new.1 hw23_new.2.2.2.2.2.2 hw23_old
    with ⟨hDisj2, hsn_ne5, hjob_other_ne5⟩
  have hlast_in_live1 : spRS_last ∈ jobLevelLiveSlots m₁ (i * ctx.p.D₀ + (jLen - 1))
      (decide ((jLen - 1) + 1 = jLen)) := by
    have hd_t : decide ((jLen - 1) + 1 = jLen) = true := by simp; omega
    rw [hd_t]; unfold jobLevelLiveSlots; rw [hw_spRS_last]; simp
  have hleaf_ne5 : leafS ≠ spRS_last ∧ leafS ≠ dS_n ∧ leafS ≠ spDS_n ∧ leafS ≠ rS_n ∧ leafS ≠ spRS_n :=
    ⟨fun heq => ((hDisj.2.2.2.1 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega)).1 spRS_last
      (by rwa [h19_i_nat1])).2 (heq.symm),
     hdS_np.2.1.symm, hspDS_np.2.1.symm, hrS_np.2.1.symm, hspRS_np.2.1.symm⟩
  have h0_ne5 : 0 ≠ spRS_last ∧ 0 ≠ dS_n ∧ 0 ≠ spDS_n ∧ 0 ≠ rS_n ∧ 0 ≠ spRS_n :=
    ⟨by omega, hdS_np.1.symm, hspDS_np.1.symm, hrS_np.1.symm, hspRS_np.1.symm⟩
  refine
    { hw27 := hw27_2
      hGood₀ := fun hb => pb.hGood₀ (hb_good hb).1
      hGood_i := fun hb => by
        have _ := h_lem_5_1
        rcases hb_good hb with ⟨hgF, hcp_ball⟩
        have hgl := cg01_lift_jobLevelsCenterGood g₀ (pb.hGood_i hgF)
        intro j hj_g
        let last_j := jLen - 1
        have hlast_lt_g0 : last_j < g₀.lvs.length := Nat.sub_lt hjLen_pos Nat.one_pos
        let lv_rdy : OpenedJobLevel ctx.d ℕ :=
          { g₀.lvs[last_j]'hlast_lt_g0 with backgroundReady := decide (ph' = 2) }
        let α := 1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)
        let lv_new_u : OpenedJobLevel ctx.d ℕ :=
          { birthSnapshot := curRes_u
            ball := selectOpenedLevelBall α ctx.uMap'.ghostCoords curRes_u (ctx.uMap'.uidOfH bId) res_cand
            indexMode := .radiusDictOnly
            backgroundReady := false }
        have hl_g' : g'.lvs = (g₀.lvs.set last_j lv_rdy) ++ [lv_new_u] := rfl
        have hj_lt_succ : j < jLen + 1 := by
          simpa [hl_g', jLen] using hj_g
        by_cases hj_old : j < jLen
        · have hj_rdy_lt : j < (g₀.lvs.set last_j lv_rdy).length := by rw [List.length_set]; exact hj_old
          have h1 : g'.lvs[j]'hj_g = (g₀.lvs.set last_j lv_rdy)[j]'hj_rdy_lt := by
            simp only [hl_g', List.getElem_append_left hj_rdy_lt]
          have h2 : (g'.lvs[j]'hj_g).ball = (g₀.lvs[j]'hj_old).ball ∧
              (g'.lvs[j]'hj_g).birthSnapshot = (g₀.lvs[j]'hj_old).birthSnapshot := by
            rw [h1]
            by_cases heq_j : j = last_j
            · subst j; simp [lv_rdy]
            · rw [List.getElem_set_ne (Ne.symm heq_j)]; exact ⟨rfl, rfl⟩
          rw [h2.1, h2.2]
          exact hgl j hj_old
        · have hj_eq : j = jLen := by omega
          subst j
          have hlen_s : (g₀.lvs.set last_j lv_rdy).length = jLen := by simp [jLen]
          have hget : g'.lvs[jLen]'hj_g = lv_new_u := by simp [hl_g', hlen_s]
          rw [hget]
          dsimp only [lv_new_u]
          rw [← hballNew hb_pos]
          exact hcp_ball
      hage_eq := by
        change ctx.snAge' r_fin =
          jobStartAge (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.st₀.birthSnap r_fin).card + (g₀.t_cur + 1)
        unfold MidLoopCtx.snAge'
        rw [if_pos haff, hage0_eq, Nat.add_assoc]
      hm0_le := by
        have hS0 : g'.S_root 0 = g₀.S_root 0 := by
          dsimp only [g', g_lift, ActiveJobGhost.stepTick, ActiveJobGhost.liftCoords]
          exact Function.update_of_ne (by omega) _ _
        rwa [hS0]
      hSeg := hSeg2
      hSave := hSave2
      hLive := hLive2
      hw1_5 := hw1_5_2.trans pb.hw1_5
      hw6_0 := (hw6_not5 0 h0_ne5.1 h0_ne5.2.1 h0_ne5.2.2.1 h0_ne5.2.2.2.1 h0_ne5.2.2.2.2).trans pb.hw6_0
      hSeg0 := hSegPres2 0 ctx.zero_lt_NumSlots h0_ne5.2.1 h0_ne5.2.2.1 h0_ne5.2.2.2.1 h0_ne5.2.2.2.2 _ _ pb.hSeg0
      hChainRest := ⟨leafS, hl0, hllt, hw1_6_2.trans hw1_6,
        (hw6_not5 leafS hleaf_ne5.1 hleaf_ne5.2.1 hleaf_ne5.2.2.1 hleaf_ne5.2.2.2.1 hleaf_ne5.2.2.2.2).trans hw6_leaf,
        hSegPres2 leafS hllt hleaf_ne5.2.1 hleaf_ne5.2.2.1 hleaf_ne5.2.2.2.1 hleaf_ne5.2.2.2.2 _ _ hSegLeaf,
        hDisj2⟩
      hHdr_i := pb.hHdr_i.frame_other (hw_bc2 i) (hw_age2 i) (hw14_2 i) (hw15_2 i)
        (fun s hs => by
          have hn := hsn_ne5 i hi s hs
          exact hw6_not5 s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2)
        (fun _ => hrO_2 _) (hrV_2 _)
        (fun s hs hlt _ _ hE => by
          have hn := hsn_ne5 i hi s hs
          exact hSegPres2 s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2 _ _ hE)
      hOwn_i := ?_
      hDone := fun r hr_lt => ?_
      hTodo := fun r hr_ge => ?_ }
  · -- hOwn_i
    let lv_new_h : JobLvData ctx.d :=
      { S_birth := curRes_h
        snapPts := ctx.P'.handleCoords
        prov := prov_new
        openRem := rem' }
    let lvs_h' := lvs_h ++ [lv_new_h]
    have hlvs'_len : g'.lvs.length = jLen + 1 := by
      simp [g', g_lift, ActiveJobGhost.stepTick, ActiveJobGhost.liftCoords,
        act, applyJobTickEndAction, jLen]
    have hlen_eq' : lvs_h'.length = g'.lvs.length := by
      simp [lvs_h', hlen_eq, hlvs'_len, jLen]
    refine ⟨(hw16_2 i).trans pb.hw16_i,
      hwRem_i2,
      hwCl_i2,
      by rw [hlvs'_len]; exact hw19_i2,
      lvs_h', hlen_eq', fun j hj => ?_⟩
    have hj_lt_succ : j < jLen + 1 := by simpa [lvs_h', hlen_eq, jLen] using hj
    have hj_g' : j < g'.lvs.length := hlen_eq' ▸ hj
    let last_j := jLen - 1
    have hlast_lt_g0 : last_j < g₀.lvs.length := Nat.sub_lt hjLen_pos Nat.one_pos
    let lv_rdy : OpenedJobLevel ctx.d ℕ :=
      { g₀.lvs[last_j]'hlast_lt_g0 with backgroundReady := decide (ph' = 2) }
    let α := 1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)
    let lv_new_u : OpenedJobLevel ctx.d ℕ :=
      { birthSnapshot := curRes_u
        ball := selectOpenedLevelBall α ctx.uMap'.ghostCoords curRes_u (ctx.uMap'.uidOfH bId) res_cand
        indexMode := .radiusDictOnly
        backgroundReady := false }
    have hl_g' : g'.lvs = (g₀.lvs.set last_j lv_rdy) ++ [lv_new_u] := rfl
    by_cases hj_old : j < jLen
    · have hj_lh : j < lvs_h.length := hlen_eq ▸ hj_old
      have hget_lh : lvs_h'[j]'hj = lvs_h[j]'hj_lh := List.getElem_append_left hj_lh
      have hop_j_eq : g'.openRem j = g₀.openRem j := by
        change Function.update g₀.openRem (g₀.lvs.set last_j lv_rdy).length rem' j = g₀.openRem j
        rw [List.length_set]
        exact Function.update_of_ne (by dsimp [jLen] at hj_old; omega) _ _
      have hj_rdy_lt : j < (g₀.lvs.set last_j lv_rdy).length := by rw [List.length_set]; exact hj_old
      have hlv_u_eq : (g'.lvs[j]'hj_g').ball = (g₀.lvs[j]'hj_old).ball ∧
          (g'.lvs[j]'hj_g').birthSnapshot = (g₀.lvs[j]'hj_old).birthSnapshot := by
        have h1 : g'.lvs[j]'hj_g' = (g₀.lvs.set last_j lv_rdy)[j]'hj_rdy_lt := by
          simp only [hl_g', List.getElem_append_left hj_rdy_lt]
        rw [h1]
        by_cases heq_j : j = last_j
        · subst j; simp [lv_rdy]
        · rw [List.getElem_set_ne (Ne.symm heq_j)]; exact ⟨rfl, rfl⟩
      have hpar_eq : jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h' (ctx.S_post_h r_fin) j =
          jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) j :=
        jobHandleInput_append_le (ctx.d + 3) ctx.P'.handleCoords lvs_h [lv_new_h] _ (le_of_lt hj_lh)
      have hd_false : decide (j + 1 = lvs_h'.length) = false := by
        simp only [lvs_h', List.length_append, List.length_singleton, hlen_eq, decide_eq_false_iff_not]
        dsimp only [jLen] at hj_old; omega
      have hidx_ne : i * ctx.p.D₀ + j ≠ newIdx := by dsimp only [newIdx]; omega
      rcases hlv_all j hj_lh with ⟨hball_j, hop_j, ⟨f_b, g_b, hfb, hgb⟩, hEnc_j,
        hw23_7, hp2, hp3, hp4, hp5, hp6, hph2_lt⟩
      have hEnc_j2 : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₂
          ctx.P'.activeHandles ctx.P'.handleCoords (i * ctx.p.D₀ + j)
          (lvs_h'[j]'hj).S_birth (lvs_h'[j]'hj).snapPts (lvs_h'[j]'hj).prov
          (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h' (ctx.S_post_h r_fin) j)
          (decide (j + 1 = lvs_h'.length)) := by
        rw [hget_lh, hpar_eq, hd_false]
        by_cases heq_last : j = jLen - 1
        · subst j
          have hd_true : decide ((jLen - 1) + 1 = lvs_h.length) = true := by
            rw [hlen_eq]; simp only [decide_eq_true_eq]; dsimp only [jLen]; omega
          rw [hd_true] at hEnc_j
          exact cg01_encJobLevel_last_to_nonlast hEnc_j hw24_last_m1 hw_spRS_last h6_spRS_2
            (fun s hs hlt _ _ _ hE => hSegPres2 s hlt
              (fun h => hdS_np.2.2.2 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega) (h ▸ hs))
              (fun h => hspDS_np.2.2.2 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega) (h ▸ hs))
              (fun h => hrS_np.2.2.2 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega) (h ▸ hs))
              (fun h => hspRS_np.2.2.2 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega) (h ▸ hs)) _ _ hE)
            (fun s hs hne_sp => hw6_not5 s hne_sp
              (fun h => hdS_np.2.2.2 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega) (h ▸ hs))
              (fun h => hspDS_np.2.2.2 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega) (h ▸ hs))
              (fun h => hrS_np.2.2.2 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega) (h ▸ hs))
              (fun h => hspRS_np.2.2.2 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega) (h ▸ hs)))
            hw11_2 hr11_2
            (hw23_old _ hidx_ne) (hw24_old _ hidx_ne 0 (by decide))
            (hr23_old _ hidx_ne) (hr24_old _ hidx_ne 0 (by decide))
        · have hd_f1 : decide (j + 1 = lvs_h.length) = false := by
            rw [hlen_eq]; simp only [decide_eq_false_iff_not]; dsimp only [jLen] at hj_old heq_last; omega
          rw [hd_f1] at hEnc_j
          exact hEnc_j.frame_slotSet (fun _ _ => rfl) (fun _ _ => rfl)
            (fun s hs hlt _ _ _ hE => by
              have hn := hjob_other_ne5 i hi pb.hw16_i j (by rw [h19_i_nat1]; exact hj_old) (Or.inr heq_last) s hs
              exact hSegPres2 s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2 _ _ hE)
            (fun s hs => by
              have hn := hjob_other_ne5 i hi pb.hw16_i j (by rw [h19_i_nat1]; exact hj_old) (Or.inr heq_last) s hs
              exact hw6_not5 s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2)
            hw11_2 hr11_2
            (hw23_old _ hidx_ne) (hw24_old _ hidx_ne)
            (hr23_old _ hidx_ne) (hr24_old _ hidx_ne)
      refine ⟨by rw [hget_lh]; exact hball_j.trans hlv_u_eq.1.symm,
        by rw [hget_lh, hop_j_eq]; exact hop_j,
        ⟨f_b, g_b,
          fun h hh => by
            rw [hget_lh] at hh ⊢
            exact ⟨hlv_u_eq.2.symm ▸ (hfb h hh).1, (hfb h hh).2⟩,
          fun u hu => by
            rw [hget_lh]
            exact hgb u (hlv_u_eq.2 ▸ hu)⟩,
        hEnc_j2,
        by rw [hop_j_eq, hw23_old _ hidx_ne 7 (by decide)]; exact hw23_7,
        by rw [hw23_old _ hidx_ne 2 (by decide)]; exact hp2,
        by rw [hw23_old _ hidx_ne 3 (by decide)]; exact hp3,
        by rw [hw23_old _ hidx_ne 4 (by decide)]; exact hp4,
        by rw [hw23_old _ hidx_ne 5 (by decide)]; exact hp5,
        by rw [hw23_old _ hidx_ne 6 (by decide)]; exact hp6,
        fun _ => by
          rw [hw24_old _ hidx_ne 0 (by decide)]
          by_cases heq_last : j = jLen - 1
          · subst j; exact hw24_last_m1
          · exact hph2_lt (by rw [hlen_eq]; dsimp only [jLen] at hj_old heq_last; omega),
        fun hcontra => by
          have : j + 1 < lvs_h'.length := by
            simp only [lvs_h', List.length_append, List.length_singleton, hlen_eq]
            dsimp only [jLen] at hj_old; omega
          omega⟩
    · have hj_eq : j = jLen := by omega
      subst j
      have hget_lh : lvs_h'[jLen]'hj = lv_new_h := by
        have hlen_l : lvs_h.length = jLen := hlen_eq
        simp [lvs_h', hlen_l]
      have hget_g' : g'.lvs[jLen]'hj_g' = lv_new_u := by
        have hlen_s : (g₀.lvs.set last_j lv_rdy).length = jLen := by simp [jLen]
        simp [hl_g', hlen_s]
      have hop_new : g'.openRem jLen = rem' := by
        change Function.update g₀.openRem (g₀.lvs.set last_j lv_rdy).length rem' jLen = rem'
        rw [List.length_set]
        exact Function.update_self _ _ _
      have hpar_new : jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h' (ctx.S_post_h r_fin) jLen =
          curRes_h := by
        have h1 := jobHandleInput_append_le (ctx.d + 3) ctx.P'.handleCoords lvs_h [lv_new_h]
          (ctx.S_post_h r_fin) (j := jLen) (by rw [hlen_eq])
        rw [h1]
        dsimp only [curRes_h]; rw [hlen_eq]
      have hd_true : decide (jLen + 1 = lvs_h'.length) = true := by
        simp [lvs_h', hlen_eq, jLen]
      refine ⟨by rw [hget_lh, hget_g']; exact hballNew hb_pos,
        by rw [hget_lh, hop_new],
        ⟨ctx.uMap'.uidOfH, ctx.uMap'.hOfUid,
          fun h hh => by rw [hget_lh] at hh ⊢; rw [hget_g']; exact hf_cur h hh,
          fun u hu => by rw [hget_g'] at hu; rw [hget_lh]; exact hg_cur u hu⟩,
        by rw [hget_lh, hpar_new, hd_true]; exact hEncLvNew,
        by rw [hop_new]; exact hw23_new.2.2.2.2.2.1,
        by rw [hw23_new.1]; simpa using hspRS_last_pos,
        by rw [hw23_new.2.1]; simpa using hdS_n0,
        by rw [hw23_new.2.2.1]; simpa using hspDS_n0,
        by rw [hw23_new.2.2.2.1]; simpa using hrS_n0,
        by rw [hw23_new.2.2.2.2.1]; simpa using hspRS_n0,
        fun hlt => by simp [lvs_h', hlen_eq, jLen] at hlt,
        fun _ => ⟨hw24_new.1, hw24_new.2, hpar_new.symm⟩⟩
  · have hri : r.val ≠ i := by omega
    rcases pb.hDone r hr_lt with ⟨oj, hInv, hGood_r, hHdr, hOwn⟩
    refine ⟨oj, hInv, fun hb g hg => hGood_r (hb_good hb).1 g hg,
      hHdr.frame_other (hw_bc2 _) (hw_age2 _) (hw14_2 _) (hw15_2 _)
        (fun s hs => by
          have hn := hsn_ne5 r.val r.isLt s hs
          exact hw6_not5 s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2)
        (fun _ => hrO_2 _) (hrV_2 _)
        (fun s hs hlt _ _ hE => by
          have hn := hsn_ne5 r.val r.isLt s hs
          exact hSegPres2 s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2 _ _ hE),
      hOwn.frame_other
        (fun g _ => by rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2))
        (hw16_2 _) (hwRem_ne2 r.val hri) (hwCl_ne2 r.val hri) (hw19_ne2 r.val hri)
        (fun j hj a ha => hw23_old _ (jobIdx_ne hj hjLen_lt_D0 (Or.inl hri)) a ha)
        (fun j hj a ha => hw24_old _ (jobIdx_ne hj hjLen_lt_D0 (Or.inl hri)) a ha)
        (fun j hj c => hr23_old _ (jobIdx_ne hj hjLen_lt_D0 (Or.inl hri)) c)
        (fun j hj a ha => hr24_old _ (jobIdx_ne hj hjLen_lt_D0 (Or.inl hri)) a ha)
        (fun j hj h16 s hs => by
          have hn := hjob_other_ne5 r.val r.isLt h16 j hj (Or.inl hri) s hs
          exact hw6_not5 s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2)
        (fun j hj h16 s hs hlt _ _ _ hE => by
          have hn := hjob_other_ne5 r.val r.isLt h16 j hj (Or.inl hri) s hs
          exact hSegPres2 s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2 _ _ hE)
        hw11_2 hr11_2⟩
  · have hri : r.val ≠ i := by omega
    rcases pb.hTodoGt r (by omega) with ⟨haff_w, hHdr, hGood_r, hTd⟩
    refine ⟨(hw_aff2 _).trans haff_w,
      hHdr.frame_other (hw_bc2 _) (hw_age2 _) (hw14_2 _) (hw15_2 _)
        (fun s hs => by
          have hn := hsn_ne5 r.val r.isLt s hs
          exact hw6_not5 s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2)
        (fun _ => hrO_2 _) (hrV_2 _)
        (fun s hs hlt _ _ hE => by
          have hn := hsn_ne5 r.val r.isLt s hs
          exact hSegPres2 s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2 _ _ hE),
      fun hb g hg => hGood_r (hb_good hb).1 g hg,
      hTd.frame_other
        (hw16_2 _) (hwRem_ne2 r.val hri) (hwCl_ne2 r.val hri) (hw19_ne2 r.val hri)
        (fun j hj a ha => hw23_old _ (jobIdx_ne hj hjLen_lt_D0 (Or.inl hri)) a ha)
        (fun j hj a ha => hw24_old _ (jobIdx_ne hj hjLen_lt_D0 (Or.inl hri)) a ha)
        (fun j hj c => hr23_old _ (jobIdx_ne hj hjLen_lt_D0 (Or.inl hri)) c)
        (fun j hj a ha => hr24_old _ (jobIdx_ne hj hjLen_lt_D0 (Or.inl hri)) a ha)
        (fun j hj h16 s hs => by
          have hn := hjob_other_ne5 r.val r.isLt h16 j hj (Or.inl hri) s hs
          exact hw6_not5 s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2)
        (fun j hj h16 s hs hlt _ _ _ hE => by
          have hn := hjob_other_ne5 r.val r.isLt h16 j hj (Or.inl hri) s hs
          exact hSegPres2 s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2 _ _ hE)
        hw11_2 hr11_2⟩

end UL.Proof_lem_7_2_RacerP46
