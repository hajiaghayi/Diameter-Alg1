import UL.Proof.lem_7_2.CG03_JobTickA0

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

theorem RandExecBad.repeatN_nat {d : ℕ} {inp : ArithRAMInput d}
    (countE : IntExpr) (body : ArithRAMStmt) (N B C_cnt C_b : ℕ) {q : ℝ} (hq : 0 ≤ q)
    (SafeInv : ℕ → ArithRAMMemory → Prop)
    (GoodInv : ℕ → ArithRAMMemory → Prop)
    {mem₀ : ArithRAMMemory}
    (hpop₀ : mem₀.popDepth 0 = mem₀)
    (hSafe₀ : SafeInv 0 mem₀)
    (hcnt : iValAt 0 inp mem₀ countE = (N : ℤ))
    (hccnt : intExprOps countE ≤ C_cnt)
    (hstep : ∀ i < N, ∀ m, m.popDepth 0 = m → SafeInv i m →
      RandExecBad inp body B m (SafeInv (i + 1)) (fun m' => GoodInv i m → GoodInv (i + 1) m') q C_b) :
    RandExecBad inp (.repeatN countE body) (N * B) mem₀
      (SafeInv N) (fun m_N => GoodInv 0 mem₀ → GoodInv N m_N)
      ((N : ℝ) * q) (C_cnt + N * C_b) := by
  classical
  have hloop : ∀ k : ℕ, k ≤ N → ∀ m, m.popDepth 0 = m → SafeInv (N - k) m →
      ∃ (Post_k : (Fin (k * B) → Bool) → ArithRAMMemory → Prop)
        (Bad_k : (Fin (k * B) → Bool) → Prop) (_ : DecidablePred Bad_k),
        ((Finset.univ.filter Bad_k).card : ℝ) ≤ ((k : ℝ) * q) * ((2 : ℝ) ^ (k * B)) ∧
        (∀ bits m_N, Post_k bits m_N →
          m_N.popDepth 0 = m_N ∧ SafeInv N m_N ∧
          (¬ Bad_k bits → GoodInv (N - k) m → GoodInv N m_N)) ∧
        (∀ (bs : List Bool), bs.length < k * B → ∀ (u₀ pk₀ : ℕ) (rest : List ArithRAMCont),
          ∃ fuel, ∀ f_rem,
            runArithRAMFuel inp (fuel + f_rem) (.repeatLoop k body :: rest)
              { mem := m, frameDepth := 0, remainingBits := bs,
                unitCost := u₀, peakCellSpace := pk₀ } = .needMoreBits) ∧
        (∀ (bs : List Bool) (hbs : k * B ≤ bs.length) (u₀ pk₀ : ℕ) (rest : List ArithRAMCont),
          ∃ fuel u₁ pk₁ m_N,
            u₁ ≤ u₀ + k * C_b ∧
            Post_k (fun i => bs[i.val]'(lt_of_lt_of_le i.isLt hbs)) m_N ∧
            ∀ f_rem,
              runArithRAMFuel inp (fuel + f_rem) (.repeatLoop k body :: rest)
                { mem := m, frameDepth := 0, remainingBits := bs,
                  unitCost := u₀, peakCellSpace := pk₀ } =
              runArithRAMFuel inp f_rem rest
                { mem := m_N, frameDepth := 0, remainingBits := bs.drop (k * B),
                  unitCost := u₁, peakCellSpace := pk₁ }) := by
    intro k
    induction k with
    | zero =>
        intro _ m hpm hsm
        rw [Nat.sub_zero] at hsm
        refine ⟨(fun _ m' => m' = m), (fun _ => False), inferInstance,
          by simp,
          fun _ m' hm' => by subst hm'; rw [Nat.sub_zero]; exact ⟨hpm, hsm, fun _ hg => hg⟩,
          fun bs hbs => by simp at hbs,
          fun bs _ u₀ pk₀ rest => ⟨1, u₀, pk₀, m, by simp, rfl, fun f_rem => ?_⟩⟩
        have hf : 1 + f_rem = f_rem + 1 := by omega
        rw [hf]; simp [runArithRAMFuel]
    | succ k ih =>
        intro hk m hpm hsm
        have hi_lt : N - (k + 1) < N := by omega
        rcases hstep (N - (k + 1)) hi_lt m hpm hsm with ⟨_, Post₁, Bad₁, _, hR₁, hc₁, hp₁⟩
        rcases RandExecAt.det_mem hpm (fun f m₁ h1 => (hp₁ f m₁ h1).1) hR₁
          with ⟨nextM₁, hnext₁, hR₁_det⟩
        have hidx_succ : N - (k + 1) + 1 = N - k := by omega
        have hex₂ : ∀ b₁ : Fin B → Bool,
            ∃ (P_k : (Fin (k * B) → Bool) → ArithRAMMemory → Prop)
              (Bd_k : (Fin (k * B) → Bool) → Prop),
              ((Finset.univ.filter Bd_k).card : ℝ) ≤ ((k : ℝ) * q) * ((2 : ℝ) ^ (k * B)) ∧
              (∀ b₂ m_N, P_k b₂ m_N →
                m_N.popDepth 0 = m_N ∧ SafeInv N m_N ∧
                (¬ Bd_k b₂ → GoodInv (N - k) (nextM₁ b₁) → GoodInv N m_N)) ∧
              (∀ (bs : List Bool), bs.length < k * B → ∀ (u₀ pk₀ : ℕ) (rest : List ArithRAMCont),
                ∃ fuel, ∀ f_rem,
                  runArithRAMFuel inp (fuel + f_rem) (.repeatLoop k body :: rest)
                    { mem := nextM₁ b₁, frameDepth := 0, remainingBits := bs,
                      unitCost := u₀, peakCellSpace := pk₀ } = .needMoreBits) ∧
              (∀ (bs : List Bool) (hbs : k * B ≤ bs.length) (u₀ pk₀ : ℕ) (rest : List ArithRAMCont),
                ∃ fuel u₁ pk₁ m_N,
                  u₁ ≤ u₀ + k * C_b ∧
                  P_k (fun i => bs[i.val]'(lt_of_lt_of_le i.isLt hbs)) m_N ∧
                  ∀ f_rem,
                    runArithRAMFuel inp (fuel + f_rem) (.repeatLoop k body :: rest)
                      { mem := nextM₁ b₁, frameDepth := 0, remainingBits := bs,
                        unitCost := u₀, peakCellSpace := pk₀ } =
                    runArithRAMFuel inp f_rem rest
                      { mem := m_N, frameDepth := 0, remainingBits := bs.drop (k * B),
                        unitCost := u₁, peakCellSpace := pk₁ }) := by
          intro b₁
          rcases hp₁ b₁ (nextM₁ b₁) (hnext₁ b₁).2 with ⟨hp_n, hs_n, _⟩
          rw [hidx_succ] at hs_n
          rcases ih (by omega) (nextM₁ b₁) hp_n hs_n with ⟨Pk, Bdk, _, hck, hpk, hn1, hn2⟩
          exact ⟨Pk, Bdk, by convert hck, hpk, hn1, hn2⟩
        choose Pk Bdk hck hpk hn1 hn2 using hex₂
        have hB_eq : (k + 1) * B = B + k * B := by ring
        let leftB : (Fin ((k + 1) * B) → Bool) → (Fin B → Bool) :=
          fun bits i => bits ⟨i.val, by omega⟩
        let rightB : (Fin ((k + 1) * B) → Bool) → (Fin (k * B) → Bool) :=
          fun bits j => bits ⟨B + j.val, by omega⟩
        let PostComb : (Fin ((k + 1) * B) → Bool) → ArithRAMMemory → Prop :=
          fun bits m_N => Pk (leftB bits) (rightB bits) m_N
        let BadComb : (Fin ((k + 1) * B) → Bool) → Prop :=
          fun bits => Bad₁ (leftB bits) ∨ Bdk (leftB bits) (rightB bits)
        have hcard_comb :
            ((Finset.univ.filter BadComb).card : ℝ) ≤
              (((k + 1 : ℕ) : ℝ) * q) * ((2 : ℝ) ^ ((k + 1) * B)) := by
          have had := bad_card_seq_adaptive hq (by positivity : 0 ≤ (k : ℝ) * q) Bad₁ Bdk (by convert hc₁) (fun b₁ => by convert hck b₁)
          dsimp only at had
          let castE : Fin ((k + 1) * B) ≃ Fin (B + k * B) := finCongr hB_eq
          have hbij : (Finset.univ.filter BadComb).card =
              (Finset.univ.filter (fun bits : Fin (B + k * B) → Bool =>
                Bad₁ (fun i => bits ⟨i.val, by omega⟩) ∨
                Bdk (fun i => bits ⟨i.val, by omega⟩) (fun j => bits ⟨B + j.val, by omega⟩))).card := by
            refine Finset.card_bij (fun f _ => f ∘ castE.symm) ?_ ?_ ?_
            · intro f hf
              simp only [Finset.mem_filter, Finset.mem_univ, true_and, BadComb, leftB, rightB,
                Function.comp_apply, castE, finCongr_symm, finCongr_apply, Fin.coe_cast] at hf ⊢
              exact hf
            · intro f₁ _ f₂ _ heq
              ext x; have := congrFun heq (castE x)
              simpa [Function.comp_apply] using this
            · intro g hg
              refine ⟨g ∘ castE, ?_, by ext x; simp [Function.comp_apply]⟩
              simp only [Finset.mem_filter, Finset.mem_univ, true_and, BadComb, leftB, rightB,
                Function.comp_apply, castE, finCongr_apply, Fin.coe_cast] at hg ⊢
              exact hg
          rw [hbij]
          calc ((Finset.univ.filter _).card : ℝ)
              ≤ (q + (k : ℝ) * q) * ((2 : ℝ) ^ (B + k * B)) := had
            _ = (((k + 1 : ℕ) : ℝ) * q) * ((2 : ℝ) ^ ((k + 1) * B)) := by
                rw [← hB_eq]; push_cast; ring
        refine ⟨PostComb, BadComb, inferInstance, hcard_comb, ?_, ?_, ?_⟩
        · intro bits m_N hmN
          rcases hpk (leftB bits) (rightB bits) m_N hmN with ⟨hpN, hsN, hgN⟩
          rcases hp₁ (leftB bits) (nextM₁ (leftB bits)) (hnext₁ (leftB bits)).2 with ⟨_, _, hg₁⟩
          refine ⟨hpN, hsN, fun hnb hg0 => ?_⟩
          have hg_mid : GoodInv (N - k) (nextM₁ (leftB bits)) := by
            rw [← hidx_succ]
            exact hg₁ (fun h1 => hnb (Or.inl h1)) hg0
          exact hgN (fun h2 => hnb (Or.inr h2)) hg_mid
        · intro bs hbs u₀ pk₀ rest
          by_cases hb₁ : bs.length < B
          · rcases hR₁_det.1 bs hb₁ u₀ pk₀ (.repeatLoop k body :: rest) with ⟨f₁, hs₁⟩
            refine ⟨1 + f₁, fun f_rem => ?_⟩
            have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
            rw [hf]; dsimp only [runArithRAMFuel]; exact hs₁ f_rem
          · have hge₁ : B ≤ bs.length := by omega
            rcases hR₁_det.2 bs hge₁ u₀ pk₀ (.repeatLoop k body :: rest) with
              ⟨f₁, u₁, pk₁, m₁, _, rfl, hs₁⟩
            have hlt₂ : (bs.drop B).length < k * B := by simp; omega
            rcases hn1 (fun i => bs[i.val]'(lt_of_lt_of_le i.isLt hge₁)) (bs.drop B) hlt₂ u₁ pk₁ rest
              with ⟨f₂, hs₂⟩
            refine ⟨1 + f₁ + f₂, fun f_rem => ?_⟩
            have hf : 1 + f₁ + f₂ + f_rem = ((f₁ + (f₂ + f_rem)) + 1) := by omega
            rw [hf]; dsimp only [runArithRAMFuel]; rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
        · intro bs hbs u₀ pk₀ rest
          have hge₁ : B ≤ bs.length := by omega
          rcases hR₁_det.2 bs hge₁ u₀ pk₀ (.repeatLoop k body :: rest) with
            ⟨f₁, u₁, pk₁, m₁, hu₁, rfl, hs₁⟩
          have hge₂ : k * B ≤ (bs.drop B).length := by simp; omega
          let b₁ : Fin B → Bool := fun i => bs[i.val]'(lt_of_lt_of_le i.isLt hge₁)
          rcases hn2 b₁ (bs.drop B) hge₂ u₁ pk₁ rest with ⟨f₂, u₂, pk₂, m_N, hu₂, hp₂, hs₂⟩
          refine ⟨1 + f₁ + f₂, u₂, pk₂, m_N,
            by calc u₂ ≤ u₁ + k * C_b := hu₂
                 _ ≤ u₀ + C_b + k * C_b := by omega
                 _ = u₀ + (k + 1) * C_b := by ring,
            ?_, fun f_rem => ?_⟩
          · dsimp only [PostComb, leftB, rightB]
            convert hp₂ using 1
            ext j; simp [List.getElem_drop]
          · have hf : 1 + f₁ + f₂ + f_rem = ((f₁ + (f₂ + f_rem)) + 1) := by omega
            rw [hf]; dsimp only [runArithRAMFuel]
            rw [hs₁ (f₂ + f_rem), hs₂ f_rem, List.drop_drop, ← hB_eq]
  rcases hloop N le_rfl mem₀ hpop₀ (by simpa using hSafe₀) with
    ⟨Post_N, Bad_N, _, hcard_N, hpost_N, hneed_N, hrun_N⟩
  refine ⟨by positivity, Post_N, Bad_N, inferInstance, ⟨?_, ?_⟩, hcard_N, ?_⟩
  · intro bs hbs u₀ pk₀ rest
    rcases he : evalIntExpr inp.toWordView 0 mem₀.words countE with ⟨cnt, u_cnt, _⟩
    have hcnt' : cnt = (N : ℤ) := by rw [← hcnt, iValAt, he]
    subst hcnt'
    rcases hneed_N bs hbs (u₀ + u_cnt) pk₀ rest with ⟨f₁, hs₁⟩
    refine ⟨1 + f₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
    rw [hf]; simp only [runArithRAMFuel, he, hnIter]; exact hs₁ f_rem
  · intro bs hbs u₀ pk₀ rest
    rcases he : evalIntExpr inp.toWordView 0 mem₀.words countE with ⟨cnt, u_cnt, _⟩
    have hcnt' : cnt = (N : ℤ) := by rw [← hcnt, iValAt, he]
    have hucnt : u_cnt = intExprOps countE := by
      have := evalIntExpr_ops inp.toWordView 0 mem₀.words countE; rw [he] at this; exact this
    subst hcnt'
    rcases hrun_N bs hbs (u₀ + u_cnt) pk₀ rest with ⟨f₁, u₁, pk₁, m_N, hu₁, hp₁, hs₁⟩
    refine ⟨1 + f₁, u₁, pk₁, m_N, by omega, hp₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
    rw [hf]; simp only [runArithRAMFuel, he, hnIter]; exact hs₁ f_rem
  · intro bits m_N hp
    rcases hpost_N bits m_N hp with ⟨hpopN, hsN, hgN⟩
    exact ⟨hpopN, hsN, fun hnb hg0 => hgN hnb (by simpa using hg0)⟩

end UL.Proof_lem_7_2_RacerP46
