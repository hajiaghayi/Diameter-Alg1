import UL.Proof.lem_7_2.CG02_LiveRouteB1

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 5a. Active Serving-Node Prefix & Unaffected Branch (`aff = false`) -/

/-- Execute the membership/flag prefix (Steps A & B) of `routeOneServingNodeStmt` for an active
serving node `r : Fin k`. -/
theorem exec_routeOneServingNodeStmt_stepAB {d n K D₀ NumSlots M_box k leafS opH : ℕ}
    (inp : ArithRAMInput d)
    {P P' : DynamicPointSet d} {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ}
    {ins : Bool} {mem mA : ArithRAMMemory}
    (hCtx : RouteLoopCtx d n K D₀ NumSlots M_box k leafS opH P P' nodes snAge ins mem mA)
    (r : Fin k) (hi_D0 : r.val < D₀) {m : ArithRAMMemory}
    (hm : RouteLoopInv K NumSlots leafS opH P P' nodes snAge ins mem mA r.val m)
    {dS : ℕ}
    (hw14_r : wRead m 14 (r.val : ℤ) = (dS : ℤ))
    (hSeg_d : EncSegSlot K m dS
      (chainInput P.handleCoords nodes P.activeHandles r.castSucc)
      (fun x => euclideanDistSq (P.handleCoords x) (nodes r).o)) :
    ∃ m2 : ArithRAMMemory,
      (∀ {s3 : ArithRAMStmt} {m_end : ArithRAMMemory} {C3 : ℕ},
        DetExecAt 0 inp s3 m2 m_end C3 →
        DetExecAt 0 inp
          (seqList [
            .ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
              (boxWriteW M_box 26 (.lit 8) (.readHeap 26 (.lit 9)))
              (checkInSegSlotTo26Stmt K M_box (.readHeap 14 (.readHeap 26 (.lit 7)))),
            boxWriteW M_box 20 (.readHeap 26 (.lit 7)) (.readHeap 26 (.lit 8)),
            s3
          ]) m m_end (115 + C3)) ∧
      SegGenBound K NumSlots m2 ∧
      (∀ s' < NumSlots, ∀ S₁ fSq₁, EncSegSlot K m s' S₁ fSq₁ → EncSegSlot K m2 s' S₁ fSq₁) ∧
      wRead m2 26 8 = (if chainLevelAffected P P' nodes ins opH r.castSucc then 1 else 0) ∧
      (∀ idx, idx ≠ 8 → wRead m2 26 idx = wRead m 26 idx) ∧
      wRead m2 20 (r.val : ℤ) = (if chainLevelAffected P P' nodes ins opH r.castSucc then 1 else 0) ∧
      (∀ idx, idx ≠ (r.val : ℤ) → wRead m2 20 idx = wRead m 20 idx) ∧
      (∀ t, t ≠ 20 → t ≠ 26 → ∀ idx, wRead m2 t idx = wRead m t idx) ∧
      (∀ t idx, rRead m2 t idx = rRead m t idx) := by
  have hBox30 := hCtx.hBox.1
  have hBoxD0 := hCtx.hBox.2.1
  have hopH_K := hCtx.hopH_K
  rcases hm with ⟨hseg_m, hm26_4, hm26_5, hm26_7, hm26_9, _, _, _, _, _, _, _, _⟩
  have hmin_i : min r.val k = r.val := Nat.min_eq_left (Nat.le_of_lt r.isLt)
  have hStepA : ∃ m1 : ArithRAMMemory,
      DetExecAt 0 inp
        (.ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
          (boxWriteW M_box 26 (.lit 8) (.readHeap 26 (.lit 9)))
          (checkInSegSlotTo26Stmt K M_box (.readHeap 14 (.readHeap 26 (.lit 7)))))
        m m1 95 ∧
      wRead m1 26 8 = (if chainLevelAffected P P' nodes ins opH r.castSucc then 1 else 0) ∧
      (∀ t, t ≠ 26 → ∀ idx, wRead m1 t idx = wRead m t idx) ∧
      (∀ idx, idx ≠ 8 → wRead m1 26 idx = wRead m 26 idx) ∧
      (∀ t idx, rRead m1 t idx = rRead m t idx) := by
    cases hins_c : ins with
    | true =>
        have hc5 : cValAt 0 inp m (.intEq (.readHeap 26 (.lit 5)) (.lit 1)) = true := by
          simp [hm26_5, hins_c]
        let m1 := wWrite m 26 8 (wRead m 26 9)
        have hb : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 8) (.readHeap 26 (.lit 9))) m m1 18 :=
          exec_boxWriteW inp m _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
        have h9_val : wRead m 26 9 = (if chainLevelAffected P P' nodes true opH r.castSucc then 1 else 0) := by
          have h9 := hm26_9 hins_c
          have hfin : (⟨min r.val k, Nat.lt_succ_of_le (Nat.min_le_right r.val k)⟩ : Fin (k + 1)) = r.castSucc :=
            Fin.ext hmin_i
          rw [hfin, hins_c] at h9
          exact h9
        exact ⟨m1,
          (DetExecAt.ite_true hc5 (C_c := 10) (by simp [condExprOps, intExprOps]) hb).mono_cost (by omega),
          by simp [m1, h9_val],
          fun t ht idx => by simp [m1, ht],
          fun idx hne => by simp [m1, hne],
          fun _ _ => by simp [m1]⟩
    | false =>
        have hc5 : cValAt 0 inp m (.intEq (.readHeap 26 (.lit 5)) (.lit 1)) = false := by
          simp [hm26_5, hins_c]
        rcases exec_checkInSegSlotTo26Stmt inp m (.readHeap 14 (.readHeap 26 (.lit 7)))
            hopH_K (M_box := M_box) (by omega)
            (by simp [hm26_7, hw14_r]) hm26_4 hSeg_d
          with ⟨m1, hb, _, hw26_8, hwt, hw26, hrt⟩
        have hmem_eq :
            (if opH ∈ chainInput P.handleCoords nodes P.activeHandles r.castSucc then (1 : ℤ) else 0) =
            (if chainLevelAffected P P' nodes false opH r.castSucc then 1 else 0) := by
          simp [chainLevelAffected]
        exact ⟨m1,
          (DetExecAt.ite_false hc5 (C_c := 10) (by simp [condExprOps, intExprOps]) hb).mono_cost
            (by simp [intExprOps]),
          hw26_8.trans hmem_eq, hwt, hw26, hrt⟩
  rcases hStepA with ⟨m1, hex1, hm1_8, hw_m1, hw26_m1, hr_m1⟩
  let m2 := wWrite m1 20 (r.val : ℤ) (if chainLevelAffected P P' nodes ins opH r.castSucc then 1 else 0)
  have hex2 : DetExecAt 0 inp (boxWriteW M_box 20 (.readHeap 26 (.lit 7)) (.readHeap 26 (.lit 8))) m1 m2 20 :=
    exec_boxWriteW inp m1 _ _
      (by simp [hw26_m1 7 (by decide), hm26_7])
      (by omega) (by have : r.val < M_box := lt_of_lt_of_le hi_D0 hBoxD0; exact_mod_cast this)
      (by simp [hm1_8]) (by simp [intExprOps])
  have hseg_m2 : SegGenBound K NumSlots m2 :=
    ⟨by simp [m2, hw_m1 1 (by decide)]; exact hseg_m.1,
     fun s hs => by simp [m2, hw_m1 5 (by decide), hw_m1 1 (by decide)]; exact hseg_m.2.1 s hs,
     fun s hs u hu => by simp [m2, hw_m1 8 (by decide), hw_m1 1 (by decide)]; exact hseg_m.2.2 s hs u hu⟩
  have liftSeg_m2 : ∀ s' < NumSlots, ∀ S₁ fSq₁, EncSegSlot K m s' S₁ fSq₁ → EncSegSlot K m2 s' S₁ fSq₁ := by
    intro s' _ S₁ fSq₁ hE
    exact hE.congr_mem_fSq
      (by simp [m2, hw_m1 5 (by decide)])
      (fun _ _ => by simp [m2, hw_m1 8 (by decide)])
      (fun _ _ => by simp [m2, hw_m1 9 (by decide)])
      (fun _ _ => by simp [m2, hw_m1 10 (by decide)])
      (fun _ _ => by simp [m2, hr_m1])
      (fun _ _ => rfl)
  refine ⟨m2,
    fun h3 => by
      unfold seqList
      exact (hex1.seq (hex2.seq h3)).mono_cost (by omega),
    hseg_m2,
    liftSeg_m2,
    by simp [m2, hm1_8],
    fun idx hne => by simp [m2, hw26_m1 idx hne],
    by simp [m2],
    fun idx hne => by simp [m2, hne, hw_m1 20 (by decide)],
    fun t h20 h26 idx => by simp [m2, h20, hw_m1 t h26],
    fun t idx => by simp [m2, hr_m1]⟩

/-- Unaffected active serving-node step (`r : Fin k` and `aff r.castSucc = false`). -/
theorem exec_routeOneServingNodeStmt_unaff {d n K D₀ NumSlots M_box k leafS opH : ℕ}
    (inp : ArithRAMInput d)
    {P P' : DynamicPointSet d} {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ}
    {ins : Bool} {mem mA : ArithRAMMemory}
    (hCtx : RouteLoopCtx d n K D₀ NumSlots M_box k leafS opH P P' nodes snAge ins mem mA)
    (r : Fin k) (hi_D0 : r.val < D₀) {m : ArithRAMMemory}
    (hm : RouteLoopInv K NumSlots leafS opH P P' nodes snAge ins mem mA r.val m)
    (haff_c : chainLevelAffected P P' nodes ins opH r.castSucc = false) :
    ∃ m_next : ArithRAMMemory,
      DetExecAt 0 inp (routeOneServingNodeStmt d K M_box) m m_next (routeOneServingNodeCost d K) ∧
      RouteLoopInv K NumSlots leafS opH P P' nodes snAge ins mem mA (r.val + 1) m_next := by
  have hBox30 := hCtx.hBox.1
  have hSlots2 := hCtx.hSlots2
  have hleaf_lt := hCtx.hleaf_lt
  have hi_lt : r.val < k := r.isLt
  have hm_copy := hm
  rcases hm with ⟨hseg_m, hm26_4, hm26_5, hm26_7, hm26_9, hSeg0_m, hSegL_m,
                  hDone_m, hTodo_m, hRest_m, hw_m, hw13_m, hr_m⟩
  have hw15_m : wRead m 1 5 = (k : ℤ) := by
    rw [hw_m 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hCtx.hw15_A]
  have hsnSet_eq : ∀ r' : Fin k, snSlotSet m r'.val = snSlotSet mem r'.val := by
    intro r'; unfold snSlotSet
    rw [hw_m 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw_m 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hCtx.hw14_A, hCtx.hw15_tbl_A]
  have hmin_i : min r.val k = r.val := Nat.min_eq_left (Nat.le_of_lt hi_lt)
  have hmin_succ : min (r.val + 1) k = r.val + 1 := Nat.min_eq_left (Nat.succ_le_of_lt hi_lt)
  have hcond_lt : cValAt 0 inp m (.intLt (.readHeap 26 (.lit 7)) (.readHeap 1 (.lit 5))) = true := by
    simp only [cValAt_intLt, iValAt_readHeap, iValAt_lit, hm26_7, hw15_m, decide_eq_true_eq]
    exact_mod_cast hi_lt
  rcases hTodo_m r le_rfl with ⟨dS, spS, hd0, hd_lt, hsp0, hsp_lt, hd_ne_sp,
    hw13_r, hw14_r, hw15_r, hw6_d, hw6_sp, hr12_r, hr13_r, hSeg_d, hSeg_sp⟩
  rcases exec_routeOneServingNodeStmt_stepAB inp hCtx r hi_D0 hm_copy hw14_r hSeg_d
    with ⟨m2, hSeqAB, hseg_m2, liftSeg_m2, hm2_8, hw26_m2, hm2_20_i, hm2_20_ne, hw_m2, hr_m2⟩
  have hc8 : cValAt 0 inp m2 (.intEq (.readHeap 26 (.lit 8)) (.lit 1)) = false := by
    simp [hm2_8, haff_c]
  have hex3 : DetExecAt 0 inp
      (.ite (.intEq (.readHeap 26 (.lit 8)) (.lit 1))
        (seqList [
          boxWriteW M_box 13 (.readHeap 26 (.lit 7))
            (.add (.readHeap 13 (.readHeap 26 (.lit 7))) (.lit 1)),
          boxWriteW M_box 26 (.lit 3) (.readHeap 14 (.readHeap 26 (.lit 7))),
          boxWriteW M_box 26 (.lit 6) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ))),
          updSegCenterStmt d K M_box 12,
          boxWriteW M_box 26 (.lit 3) (.readHeap 15 (.readHeap 26 (.lit 7))),
          updSegZeroStmt K M_box,
          .ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
            (.ite (.realLe (.readRealHeap 26 (.lit 0))
                           (.readRealHeap 13 (.readHeap 26 (.lit 7))))
              (boxWriteW M_box 26 (.lit 9) (.lit 0))
              (boxWriteW M_box 26 (.lit 9) (.lit 1)))
            .skip
        ]) .skip) m2 m2 15 :=
    (DetExecAt.ite_false hc8 (C_c := 10) (by simp [condExprOps, intExprOps])
      (DetExecAt.skip 0 inp m2)).mono_cost (by omega)
  let m_next := wWrite m2 26 7 ((r.val + 1 : ℕ) : ℤ)
  have hex4 : DetExecAt 0 inp
      (boxWriteW M_box 26 (.lit 7) (.add (.readHeap 26 (.lit 7)) (.lit 1))) m2 m_next 20 :=
    exec_boxWriteW inp m2 _ _ rfl (by omega) (by omega)
      (by simp [hw26_m2 7 (by decide), hm26_7]) (by simp [intExprOps])
  have hex_body : DetExecAt 0 inp (routeOneServingNodeStmt d K M_box) m m_next (routeOneServingNodeCost d K) := by
    have h123 := hSeqAB hex3
    unfold routeOneServingNodeStmt
    unfold seqList at h123 ⊢
    exact ((DetExecAt.ite_true hcond_lt (C_c := 15) (by simp [condExprOps, intExprOps]) h123).seq hex4).mono_cost
      (by unfold routeOneServingNodeCost; omega)
  have liftSeg_next : ∀ s' < NumSlots, ∀ S₁ fSq₁, EncSegSlot K m s' S₁ fSq₁ → EncSegSlot K m_next s' S₁ fSq₁ := by
    intro s' hs' S₁ fSq₁ hE
    exact (liftSeg_m2 s' hs' S₁ fSq₁ hE).congr_mem_fSq
      (by simp [m_next]) (fun _ _ => by simp [m_next]) (fun _ _ => by simp [m_next])
      (fun _ _ => by simp [m_next]) (fun _ _ => by simp [m_next]) (fun _ _ => rfl)
  refine ⟨m_next, hex_body, ?_⟩
  unfold RouteLoopInv
  dsimp only
  refine ⟨⟨by simp [m_next]; exact hseg_m2.1,
     fun s hs => by simp [m_next]; exact hseg_m2.2.1 s hs,
     fun s hs u hu => by simp [m_next]; exact hseg_m2.2.2 s hs u hu⟩,
    by simp [m_next, hw26_m2 4 (by decide), hm26_4],
    by simp [m_next, hw26_m2 5 (by decide), hm26_5],
    by simp [m_next],
    fun hins => ?_,
    liftSeg_next 0 (by omega) _ _ hSeg0_m,
    liftSeg_next leafS hleaf_lt _ _ hSegL_m,
    fun r' hr' => ?_,
    fun r' hr' => ?_,
    fun s' hs' h0 hL hno S₁ fSq₁ hE => liftSeg_next s' hs' S₁ fSq₁ (hRest_m s' hs' h0 hL hno S₁ fSq₁ hE),
    fun t h8 h9 h10 h13 h20 h26 idx => by
      simp [m_next, h26, hw_m2 t h20 h26, hw_m t h8 h9 h10 h13 h20 h26],
    fun idx hidx => by
      simp [m_next, hw_m2 13 (by decide) (by decide), hw13_m idx (by omega)],
    fun t h8 h26 idx => by simp [m_next, hr_m2, hr_m t h8 h26]⟩
  · have hstay : chainLevelAffected P P' nodes ins opH r.succ = false := hCtx.hAffInsFalse hins r haff_c
    have hfin_i : (⟨min r.val k, Nat.lt_succ_of_le (Nat.min_le_right r.val k)⟩ : Fin (k + 1)) = r.castSucc :=
      Fin.ext hmin_i
    have hfin_s : (⟨min (r.val + 1) k, Nat.lt_succ_of_le (Nat.min_le_right (r.val + 1) k)⟩ : Fin (k + 1)) = r.succ :=
      Fin.ext hmin_succ
    have h9_prev := hm26_9 hins
    rw [hfin_i, haff_c] at h9_prev
    rw [hfin_s, hstay]
    simp [m_next, hw26_m2 9 (by decide), h9_prev]
  · rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hr') with hlt_i | heq_i
    · rcases hDone_m r' hlt_i with ⟨hEN, hw20_r'⟩
      have hne_i : (r'.val : ℤ) ≠ (r.val : ℤ) := by omega
      refine ⟨hEN.congr_mem
        (by simp [m_next, hw_m2 13 (by decide) (by decide)])
        (by simp [m_next, hw_m2 14 (by decide) (by decide)])
        (by simp [m_next, hw_m2 15 (by decide) (by decide)])
        (fun s _ => by simp [m_next, hw_m2 6 (by decide) (by decide)])
        (fun _ => by simp [m_next, hr_m2])
        (by simp [m_next, hr_m2])
        (fun s hs_in S₁ fSq₁ hE => by
          rw [hsnSet_eq r'] at hs_in
          rcases hCtx.hsn r' with ⟨d1, s1, _, hd1, _, hs1_lt, _, _, e14, e15, _⟩
          have hset' := EncServingNode.snSlotSet_eq (d := d) (K := K) (NumSlots := NumSlots)
            (livePts := P.handleCoords) (N := nodes r')
            (S_r := chainInput P.handleCoords nodes P.activeHandles r'.castSucc) (age_r := snAge r') e14 e15
          have hslt : s < NumSlots := by rw [hset'] at hs_in; simp at hs_in; rcases hs_in with rfl | rfl <;> assumption
          exact liftSeg_next s hslt S₁ fSq₁ hE)
        (fun _ _ => rfl),
        by simp [m_next, hm2_20_ne _ hne_i, hw20_r']⟩
    · have hr'_eq : r' = r := Fin.ext heq_i
      subst hr'_eq
      have hpost_eq : chainInput P'.handleCoords nodes P'.activeHandles r'.castSucc =
          chainInput P.handleCoords nodes P.activeHandles r'.castSucc :=
        ((hCtx.hAffProps r'.castSucc).1 haff_c).2.2
      have hpts_eq := hCtx.hCoordsUnchanged r'.castSucc haff_c
      have hSeg_d' : EncSegSlot K m_next dS
          (chainInput P'.handleCoords nodes P'.activeHandles r'.castSucc)
          (fun x => euclideanDistSq (P'.handleCoords x) (nodes r').o) := by
        rw [hpost_eq]
        exact (liftSeg_next dS hd_lt _ _ hSeg_d).congr_mem_fSq
          rfl (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl)
          (fun x hx => by rw [hpts_eq x hx])
      have hSeg_sp' : EncSegSlot K m_next spS
          (chainInput P'.handleCoords nodes P'.activeHandles r'.castSucc) (fun _ => 0) := by
        rw [hpost_eq]; exact liftSeg_next spS hsp_lt _ _ hSeg_sp
      refine ⟨⟨dS, spS, hd0, hd_lt, hsp0, hsp_lt, hd_ne_sp,
        by simp [haff_c, m_next, hw_m2 13 (by decide) (by decide), hw13_r],
        by simp [m_next, hw_m2 14 (by decide) (by decide), hw14_r],
        by simp [m_next, hw_m2 15 (by decide) (by decide), hw15_r],
        by simp [m_next, hw_m2 6 (by decide) (by decide), hw6_d],
        by simp [m_next, hw_m2 6 (by decide) (by decide), hw6_sp],
        fun c => by simp only [m_next, rRead_wWrite, hr_m2]; exact hr12_r c,
        by simp [m_next, hr_m2, hr13_r],
        hSeg_d', hSeg_sp'⟩,
        by simp [m_next, hm2_20_i, haff_c]⟩
  · exact (hTodo_m r' (Nat.le_of_succ_le hr')).congr_mem
      (by simp [m_next, hw_m2 13 (by decide) (by decide)])
      (by simp [m_next, hw_m2 14 (by decide) (by decide)])
      (by simp [m_next, hw_m2 15 (by decide) (by decide)])
      (fun s _ => by simp [m_next, hw_m2 6 (by decide) (by decide)])
      (fun _ => by simp [m_next, hr_m2])
      (by simp [m_next, hr_m2])
      (fun s hs_in S₁ fSq₁ hE => by
        rw [hsnSet_eq r'] at hs_in
        rcases hCtx.hsn r' with ⟨d1, s1, _, hd1, _, hs1_lt, _, _, e14, e15, _⟩
        have hset' := EncServingNode.snSlotSet_eq (d := d) (K := K) (NumSlots := NumSlots)
          (livePts := P.handleCoords) (N := nodes r')
          (S_r := chainInput P.handleCoords nodes P.activeHandles r'.castSucc) (age_r := snAge r') e14 e15
        have hslt : s < NumSlots := by rw [hset'] at hs_in; simp at hs_in; rcases hs_in with rfl | rfl <;> assumption
        exact liftSeg_next s hslt S₁ fSq₁ hE)
      (fun _ _ => rfl)

end UL.Proof_lem_7_2_RacerP46
