import Mathlib
import UL.Stmt.lem_C_2
import UL.Proof.lem_7_2.RacerP46_H3e_StepBuildRAM

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

private lemma or_five_insert {A B p2 p3 p4 p5 p6 : Prop} :
    A ∨ ((p2 ∨ p3 ∨ p4 ∨ p5 ∨ p6) ∨ B) ↔ p6 ∨ p5 ∨ p4 ∨ p3 ∨ p2 ∨ A ∨ B := by tauto

private lemma or_sp_d_union {U pD pSp J : Prop} :
    (pSp ∨ pD ∨ U) ∨ J ↔ (U ∨ pD ∨ pSp) ∨ J := by tauto

private lemma or_sp_d_only {U pD pSp : Prop} :
    pSp ∨ pD ∨ U ↔ U ∨ pD ∨ pSp := by tauto

private lemma or_upref_step {x0 xL pSn pJo B : Prop} :
    x0 ∨ xL ∨ (pSn ∨ pJo) ∨ B ↔ ((x0 ∨ xL ∨ B) ∨ pSn) ∨ pJo := by tauto

/-! ### 1. Active Slot Set & `gcSlotInUseStmt` (`O(D₀²)` exact slot-table recomputation) -/

/-- The 2 serving-node segment-tree slots `(snDictSlot[r], snSpareSlot[r])` for serving index `r`. -/
def snSlotSet (mem : ArithRAMMemory) (r : ℕ) : Finset ℕ :=
  { (wRead mem 14 (r : ℤ)).toNat, (wRead mem 15 (r : ℤ)).toNat }

lemma snSlotSet_card_le (mem : ArithRAMMemory) (r : ℕ) :
    (snSlotSet mem r).card ≤ 2 := by
  unfold snSlotSet
  exact le_trans (Finset.card_insert_le _ _) (by simp)

/-- All job-level slots owned by serving index `r` (empty if `wRead mem 16 r ≠ 1`). -/
def jobOwnedSlotSet (mem : ArithRAMMemory) (D₀ r : ℕ) : Finset ℕ :=
  if wRead mem 16 (r : ℤ) = 1 then
    (Finset.range (wRead mem 19 (r : ℤ)).toNat).biUnion
      (fun j => jobLevelSlotSet mem (r * D₀ + j))
  else ∅

lemma jobOwnedSlotSet_card_le (mem : ArithRAMMemory) (D₀ r : ℕ)
    (hlen : wRead mem 16 (r : ℤ) = 1 → (wRead mem 19 (r : ℤ)).toNat ≤ D₀) :
    (jobOwnedSlotSet mem D₀ r).card ≤ 5 * D₀ := by
  unfold jobOwnedSlotSet
  split_ifs with h16
  · have h1 := Finset.card_biUnion_le (s := Finset.range (wRead mem 19 (r : ℤ)).toNat)
      (t := fun j => jobLevelSlotSet mem (r * D₀ + j))
    have h2 : ∑ j ∈ Finset.range (wRead mem 19 (r : ℤ)).toNat,
        (jobLevelSlotSet mem (r * D₀ + j)).card ≤
        ∑ _j ∈ Finset.range (wRead mem 19 (r : ℤ)).toNat, 5 :=
      Finset.sum_le_sum (fun j _ => jobLevelSlotSet_card_le mem (r * D₀ + j))
    rw [Finset.sum_const, Finset.card_range, smul_eq_mul] at h2
    have h3 : (wRead mem 19 (r : ℤ)).toNat * 5 ≤ 5 * D₀ := by
      have := hlen h16; omega
    exact le_trans h1 (le_trans h2 h3)
  · simp

/-- Complete set of slots in use across `slot 0`, `leafSlot`, all active serving nodes, and all
active pending job levels. -/
def activeSlotSet (mem : ArithRAMMemory) (D₀ : ℕ) : Finset ℕ :=
  insert 0 (insert (wRead mem 1 6).toNat
    ((Finset.range (wRead mem 1 5).toNat).biUnion
      (fun r => snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r)))

lemma activeSlotSet_congr_not7 {m₁ m₂ : ArithRAMMemory} {D₀ : ℕ}
    (hw1 : ∀ i, wRead m₂ 1 i = wRead m₁ 1 i)
    (hw14 : ∀ i, wRead m₂ 14 i = wRead m₁ 14 i)
    (hw15 : ∀ i, wRead m₂ 15 i = wRead m₁ 15 i)
    (hw16 : ∀ i, wRead m₂ 16 i = wRead m₁ 16 i)
    (hw19 : ∀ i, wRead m₂ 19 i = wRead m₁ 19 i)
    (hw23 : ∀ i, wRead m₂ 23 i = wRead m₁ 23 i) :
    activeSlotSet m₂ D₀ = activeSlotSet m₁ D₀ := by
  have hjl : ∀ idx, jobLevelSlotSet m₂ idx = jobLevelSlotSet m₁ idx := by
    intro idx; unfold jobLevelSlotSet; simp [hw23]
  have hsn : ∀ r, snSlotSet m₂ r = snSlotSet m₁ r := by
    intro r; unfold snSlotSet; simp [hw14, hw15]
  have hjo : ∀ r, jobOwnedSlotSet m₂ D₀ r = jobOwnedSlotSet m₁ D₀ r := by
    intro r; unfold jobOwnedSlotSet; simp [hw16, hw19, hjl]
  unfold activeSlotSet
  simp [hw1, hsn, hjo]

lemma activeSlotSet_card_lt {mem : ArithRAMMemory} {D₀ : ℕ}
    (hcL : (wRead mem 1 5).toNat ≤ D₀)
    (hjL : ∀ r < (wRead mem 1 5).toNat,
      wRead mem 16 (r : ℤ) = 1 → (wRead mem 19 (r : ℤ)).toNat ≤ D₀) :
    (activeSlotSet mem D₀).card < 8 * (D₀ + 2) ^ 2 := by
  unfold activeSlotSet
  have hbi : (((Finset.range (wRead mem 1 5).toNat).biUnion
      (fun r => snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r))).card ≤ D₀ * (2 + 5 * D₀) := by
    have h1 := Finset.card_biUnion_le (s := Finset.range (wRead mem 1 5).toNat)
      (t := fun r => snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r)
    have h2 : ∑ r ∈ Finset.range (wRead mem 1 5).toNat,
        (snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r).card ≤
        ∑ _r ∈ Finset.range (wRead mem 1 5).toNat, (2 + 5 * D₀) := by
      refine Finset.sum_le_sum (fun r hr => ?_)
      rw [Finset.mem_range] at hr
      exact le_trans (Finset.card_union_le _ _)
        (Nat.add_le_add (snSlotSet_card_le mem r) (jobOwnedSlotSet_card_le mem D₀ r (hjL r hr)))
    rw [Finset.sum_const, Finset.card_range, smul_eq_mul] at h2
    exact le_trans h1 (le_trans h2 (Nat.mul_le_mul_right _ hcL))
  have hins1 := Finset.card_insert_le (wRead mem 1 6).toNat
    ((Finset.range (wRead mem 1 5).toNat).biUnion
      (fun r => snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r))
  have hins0 := Finset.card_insert_le 0
    (insert (wRead mem 1 6).toNat
      ((Finset.range (wRead mem 1 5).toNat).biUnion
        (fun r => snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r)))
  have hpoly : D₀ * (2 + 5 * D₀) + 2 < 8 * (D₀ + 2) ^ 2 := by
    have hexp : 8 * (D₀ + 2) ^ 2 = D₀ * (2 + 5 * D₀) + (3 * D₀ ^ 2 + 30 * D₀ + 32) := by ring
    rw [hexp]; omega
  omega

/-- Helper inner loop body of `gcSlotInUseStmt` for one `(r, j)` level (`local 29`: `[0]=r, [1]=j, [2]=idx`). -/
def gcMarkJobLevelStmt (D₀ M_box : ℕ) : ArithRAMStmt :=
  .ite (.intLt (.readLocal 29 (.lit 1)) (.readHeap 19 (.readLocal 29 (.lit 0))))
    (seqList [
      .writeWordLocal 29 (.lit 2)
        (.add (.mul (.readLocal 29 (.lit 0)) (.lit (D₀ : ℤ))) (.readLocal 29 (.lit 1))),
      boxWriteW M_box 7 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 2))) (.lit 1),
      boxWriteW M_box 7 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 3))) (.lit 1),
      boxWriteW M_box 7 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 4))) (.lit 1),
      boxWriteW M_box 7 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 5))) (.lit 1),
      boxWriteW M_box 7 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 6))) (.lit 1),
      .writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))
    ])
    (.writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1)))

/-- Recompute `slotInUse[0 .. NumSlots - 1]` (Word Table `7`) from scratch in `O(NumSlots + D₀²)` ops!
Runs inside its own `.localScope` (`fd = 0`). -/
def gcSlotInUseStmt (D₀ NumSlots M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 29 (.lit 0) (.lit 0),
    .repeatN (.lit (NumSlots : ℤ)) (seqList [
      boxWriteW M_box 7 (.readLocal 29 (.lit 0)) (.lit 0),
      .writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))
    ]),
    boxWriteW M_box 7 (.lit 0) (.lit 1),
    boxWriteW M_box 7 (.readHeap 1 (.lit 6)) (.lit 1),
    .writeWordLocal 29 (.lit 0) (.lit 0),
    .repeatN (.lit (D₀ : ℤ))
      (.ite (.intLt (.readLocal 29 (.lit 0)) (.readHeap 1 (.lit 5)))
        (seqList [
          boxWriteW M_box 7 (.readHeap 14 (.readLocal 29 (.lit 0))) (.lit 1),
          boxWriteW M_box 7 (.readHeap 15 (.readLocal 29 (.lit 0))) (.lit 1),
          .ite (.intEq (.readHeap 16 (.readLocal 29 (.lit 0))) (.lit 1))
            (seqList [
              .writeWordLocal 29 (.lit 1) (.lit 0),
              .repeatN (.lit (D₀ : ℤ)) (gcMarkJobLevelStmt D₀ M_box)
            ])
            .skip,
          .writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))
        ])
        (.writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))))
  ])

theorem boxSafe_gcSlotInUseStmt {T_max M_box : ℕ} (hT : 8 ≤ T_max) (D₀ NumSlots : ℕ) :
    BoxSafeOuter T_max M_box (gcSlotInUseStmt D₀ NumSlots M_box) := by
  have h7 : 7 < T_max := by omega
  apply BoxSafeOuter.localScope
  apply boxSafeInner_seqList; simp only [List.mem_cons, List.not_mem_nil, or_false]
  rintro s (rfl | rfl | rfl | rfl | rfl | rfl)
  · exact BoxSafeInner.writeWordLocal _ _ _
  · refine BoxSafeInner.repeatN _ ?_
    apply boxSafeInner_seqList; simp only [List.mem_cons, List.not_mem_nil, or_false]
    rintro s' (rfl | rfl)
    · exact BoxSafeInner.boxW h7 _ _
    · exact BoxSafeInner.writeWordLocal _ _ _
  · exact BoxSafeInner.boxW h7 _ _
  · exact BoxSafeInner.boxW h7 _ _
  · exact BoxSafeInner.writeWordLocal _ _ _
  · refine BoxSafeInner.repeatN _ (BoxSafeInner.ite _ ?_ (BoxSafeInner.writeWordLocal _ _ _))
    apply boxSafeInner_seqList; simp only [List.mem_cons, List.not_mem_nil, or_false]
    rintro s' (rfl | rfl | rfl | rfl)
    · exact BoxSafeInner.boxW h7 _ _
    · exact BoxSafeInner.boxW h7 _ _
    · refine BoxSafeInner.ite _ ?_ BoxSafeInner.skip
      apply boxSafeInner_seqList; simp only [List.mem_cons, List.not_mem_nil, or_false]
      rintro s'' (rfl | rfl)
      · exact BoxSafeInner.writeWordLocal _ _ _
      · refine BoxSafeInner.repeatN _ (BoxSafeInner.ite _ ?_ (BoxSafeInner.writeWordLocal _ _ _))
        apply boxSafeInner_seqList; simp only [List.mem_cons, List.not_mem_nil, or_false]
        rintro s3 (rfl | rfl | rfl | rfl | rfl | rfl | rfl)
        · exact BoxSafeInner.writeWordLocal _ _ _
        · exact BoxSafeInner.boxW h7 _ _
        · exact BoxSafeInner.boxW h7 _ _
        · exact BoxSafeInner.boxW h7 _ _
        · exact BoxSafeInner.boxW h7 _ _
        · exact BoxSafeInner.boxW h7 _ _
        · exact BoxSafeInner.writeWordLocal _ _ _
    · exact BoxSafeInner.writeWordLocal _ _ _

/-- Helper lemma: writing `1` to `wWrite m 7 (s_mark : ℤ) 1` when `0 ≤ s_mark < NumSlots` updates
membership in `U` to `insert s_mark U`. -/
private lemma exec_markSlot7 {d : ℕ} {NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (idxE : IntExpr) (s_mark : ℕ) (U : Finset ℕ)
    (hs_lt : s_mark < NumSlots)
    (hBox_slots : NumSlots ≤ M_box)
    (hidxE : iValAt 1 inp m idxE = (s_mark : ℤ))
    (hmap : ∀ s < NumSlots, wRead m 7 (s : ℤ) = if s ∈ U then 1 else 0) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 1 inp (boxWriteW M_box 7 idxE (.lit 1)) m m' (3 * intExprOps idxE + 10) ∧
      (∀ s < NumSlots, wRead m' 7 (s : ℤ) = if s ∈ insert s_mark U then 1 else 0) ∧
      (∀ t, t ≠ 7 → ∀ i, wRead m' t i = wRead m t i) ∧
      (∀ t i, rRead m' t i = rRead m t i) ∧
      (∀ v i, wReadL 1 m' v i = wReadL 1 m v i) := by
  let m' := wWrite m 7 (s_mark : ℤ) 1
  refine ⟨m', exec_boxWriteW inp m idxE (.lit 1) hidxE (by omega) (by omega) rfl (by dsimp [intExprOps]; omega),
    fun s hs => ?_,
    fun t ht i => by simp [m', ht],
    fun _ _ => by simp [m'],
    fun _ _ => by simp [m']⟩
  by_cases heq : s = s_mark
  · subst heq; simp [m']
  · have hne : (s : ℤ) ≠ (s_mark : ℤ) := by exact_mod_cast heq
    simp only [m', wRead_wWrite_of_ne _ _ (Or.inr hne), Finset.mem_insert, heq, false_or]
    exact hmap s hs

theorem exec_gcSlotInUseStmt {d D₀ NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (hSlots_pos : 1 ≤ NumSlots)
    (hBox_slots : NumSlots ≤ M_box)
    {chainLen leafS : ℕ}
    (hcL_le : chainLen ≤ D₀)
    (hw_cL : wRead mem 1 5 = (chainLen : ℤ))
    (hleaf_lt : leafS < NumSlots)
    (hw_leaf : wRead mem 1 6 = (leafS : ℤ))
    (hsn_lt : ∀ r < chainLen,
      ∃ (dS spS : ℕ), dS < NumSlots ∧ spS < NumSlots ∧
        wRead mem 14 (r : ℤ) = (dS : ℤ) ∧ wRead mem 15 (r : ℤ) = (spS : ℤ))
    (hjob_lt : ∀ r < chainLen, wRead mem 16 (r : ℤ) = 1 →
      ∃ (jLen : ℕ), jLen ≤ D₀ ∧ wRead mem 19 (r : ℤ) = (jLen : ℤ) ∧
        ∀ j < jLen,
          ∃ (s2 s3 s4 s5 s6 : ℕ),
            s2 < NumSlots ∧ s3 < NumSlots ∧ s4 < NumSlots ∧ s5 < NumSlots ∧ s6 < NumSlots ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 2 : ℕ) : ℤ)) = (s2 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 3 : ℕ) : ℤ)) = (s3 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 4 : ℕ) : ℤ)) = (s4 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 5 : ℕ) : ℤ)) = (s5 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 6 : ℕ) : ℤ)) = (s6 : ℤ)) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (gcSlotInUseStmt D₀ NumSlots M_box) mem m'
        (40 * NumSlots + 300 * (D₀ + 1) * (D₀ + 1) + 200) ∧
      m'.popDepth 0 = m' ∧
      (∀ s < NumSlots, wRead m' 7 (s : ℤ) = if s ∈ activeSlotSet mem D₀ then 1 else 0) ∧
      (∀ t, t ≠ 7 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) := by
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 29 0 0
  have hs_z0 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 0) (.lit 0)) m0 m1 4 :=
    DetExecAt.writeWordLocal 1 inp m0 29 _ _ rfl rfl (by simp [intExprOps])
  -- Phase A: zero `slotInUse[0 .. NumSlots - 1]`
  let InvZ : ℕ → ArithRAMMemory → Prop := fun k m =>
    wReadL 1 m 29 0 = (k : ℤ) ∧
    (∀ s < k, wRead m 7 (s : ℤ) = 0) ∧
    (∀ t, t ≠ 7 → ∀ i, wRead m t i = wRead mem t i) ∧
    (∀ t i, rRead m t i = rRead mem t i)
  have hInvZ0 : InvZ 0 m1 :=
    ⟨by simp [m1], fun _ hs => by omega, fun _ _ _ => by simp [m1, m0], fun _ _ => by simp [m1, m0]⟩
  have hStepZ : ∀ k < NumSlots, ∀ m, InvZ k m →
      ∃ m', DetExecAt 1 inp
        (seqList [
          boxWriteW M_box 7 (.readLocal 29 (.lit 0)) (.lit 0),
          .writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))
        ]) m m' 30 ∧ InvZ (k + 1) m' := by
    intro k hk m ⟨hl0, hz, hw_o, hr_o⟩
    let mz1 := wWrite m 7 (k : ℤ) 0
    let mz2 := wWriteL 1 mz1 29 0 (((k + 1 : ℕ) : ℤ))
    have hz1 : DetExecAt 1 inp (boxWriteW M_box 7 (.readLocal 29 (.lit 0)) (.lit 0)) m mz1 18 :=
      exec_boxWriteW inp m _ _ (by simp [hl0]) (by omega) (by omega) rfl (by dsimp [intExprOps]; omega)
    have hz2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))) mz1 mz2 8 :=
      DetExecAt.writeWordLocal 1 inp mz1 29 _ _ rfl (by simp [mz1, hl0]) (by simp [intExprOps])
    refine ⟨mz2, (hz1.seq hz2).mono_cost (by omega), by simp [mz2], fun s hs => ?_,
      fun t ht i => by simp [mz2, mz1, ht, hw_o t ht],
      fun t i => by simp [mz2, mz1, hr_o]⟩
    by_cases heq : s = k
    · subst heq; simp [mz2, mz1]
    · have hne : (s : ℤ) ≠ (k : ℤ) := by exact_mod_cast heq
      simp only [mz2, wRead_wWriteL, mz1, wRead_wWrite_of_ne _ _ (Or.inr hne)]
      exact hz s (by omega)
  rcases DetExecAt.repeatN_nat (.lit (NumSlots : ℤ)) _ NumSlots 1 30 InvZ hInvZ0 rfl
      (by simp [intExprOps]) hStepZ
    with ⟨mZ, ⟨_, hzN, hwZ_o, hrZ⟩, hrepZ⟩
  have hmap_empty : ∀ s < NumSlots, wRead mZ 7 (s : ℤ) = if s ∈ (∅ : Finset ℕ) then 1 else 0 := by
    intro s hs; simp [hzN s hs]
  -- Mark `0` and `leafS`:
  rcases exec_markSlot7 inp mZ (.lit 0) 0 ∅ (by omega) hBox_slots rfl hmap_empty
    with ⟨mA, hm0, hmap_0, hw_m0, hr_m0, _⟩
  rcases exec_markSlot7 inp mA (.readHeap 1 (.lit 6)) leafS (insert 0 ∅) hleaf_lt hBox_slots
      (by simp only [iValAt_readHeap, iValAt_lit]; rw [hw_m0 1 (by decide), hwZ_o 1 (by decide), hw_leaf]) hmap_0
    with ⟨mB, hmL, hmap_L, hw_mL, hr_mL, _⟩
  let mC := wWriteL 1 mB 29 0 0
  have hs_c0 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 0) (.lit 0)) mB mC 4 :=
    DetExecAt.writeWordLocal 1 inp mB 29 _ _ rfl rfl (by simp [intExprOps])
  -- Phase B: outer loop `r = 0 .. D₀ - 1`
  let U_pref : ℕ → Finset ℕ := fun r_lim =>
    insert 0 (insert leafS
      ((Finset.range (min r_lim chainLen)).biUnion
        (fun r => snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r)))
  let InvR : ℕ → ArithRAMMemory → Prop := fun r_lim m =>
    wReadL 1 m 29 0 = (r_lim : ℤ) ∧
    (∀ s < NumSlots, wRead m 7 (s : ℤ) = if s ∈ U_pref r_lim then 1 else 0) ∧
    (∀ t, t ≠ 7 → ∀ i, wRead m t i = wRead mem t i) ∧
    (∀ t i, rRead m t i = rRead mem t i)
  have hInvR0 : InvR 0 mC := by
    refine ⟨by simp [mC], fun s hs => ?_,
      fun t ht i => by simp [mC, hw_mL t ht, hw_m0 t ht, hwZ_o t ht],
      fun t i => by simp [mC, hr_mL, hr_m0, hrZ]⟩
    have hU0 : U_pref 0 = insert leafS (insert 0 ∅) := by
      dsimp [U_pref]; ext x; simp [or_comm]
    rw [hU0]; simpa [mC] using hmap_L s hs
  have hStepR : ∀ r < D₀, ∀ m, InvR r m →
      ∃ m', DetExecAt 1 inp
        (.ite (.intLt (.readLocal 29 (.lit 0)) (.readHeap 1 (.lit 5)))
          (seqList [
            boxWriteW M_box 7 (.readHeap 14 (.readLocal 29 (.lit 0))) (.lit 1),
            boxWriteW M_box 7 (.readHeap 15 (.readLocal 29 (.lit 0))) (.lit 1),
            .ite (.intEq (.readHeap 16 (.readLocal 29 (.lit 0))) (.lit 1))
              (seqList [
                .writeWordLocal 29 (.lit 1) (.lit 0),
                .repeatN (.lit (D₀ : ℤ)) (gcMarkJobLevelStmt D₀ M_box)
              ])
              .skip,
            .writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))
          ])
          (.writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))))
        m m' (260 * (D₀ + 1)) ∧ InvR (r + 1) m' := by
    intro r _ m ⟨hr_loc, hmap_r, hw_ro, hr_ro⟩
    by_cases hr_lt : r < chainLen
    · have hmin_r : min r chainLen = r := Nat.min_eq_left (le_of_lt hr_lt)
      have hmin_r1 : min (r + 1) chainLen = r + 1 := Nat.min_eq_left (Nat.succ_le_of_lt hr_lt)
      have hcond_r : cValAt 1 inp m (.intLt (.readLocal 29 (.lit 0)) (.readHeap 1 (.lit 5))) = true := by
        simp only [cValAt_intLt, iValAt_readLocal, iValAt_readHeap, iValAt_lit,
          hr_loc, hw_ro 1 (by decide), hw_cL, decide_eq_true_eq]
        exact_mod_cast hr_lt
      rcases hsn_lt r hr_lt with ⟨dS, spS, hdS, hspS, hw14_r, hw15_r⟩
      rcases exec_markSlot7 inp m (.readHeap 14 (.readLocal 29 (.lit 0))) dS (U_pref r) hdS hBox_slots
          (by simp only [iValAt_readHeap, iValAt_readLocal, iValAt_lit, hr_loc, hw_ro 14 (by decide), hw14_r])
          hmap_r
        with ⟨md, hd_exec, hmap_d, hw_md, hr_md, hwl_md⟩
      rcases exec_markSlot7 inp md (.readHeap 15 (.readLocal 29 (.lit 0))) spS (insert dS (U_pref r)) hspS hBox_slots
          (by simp only [iValAt_readHeap, iValAt_readLocal, iValAt_lit, hwl_md, hr_loc,
                hw_md 15 (by decide), hw_ro 15 (by decide), hw15_r])
          hmap_d
        with ⟨msp, hsp_exec, hmap_sp, hw_msp, hr_msp, hwl_msp⟩
      have hsn_eq : snSlotSet mem r = {dS, spS} := by
        unfold snSlotSet; rw [hw14_r, hw15_r]; simp
      -- Now handle optional job levels:
      have hjob_branch : ∃ mj : ArithRAMMemory,
          DetExecAt 1 inp
            (.ite (.intEq (.readHeap 16 (.readLocal 29 (.lit 0))) (.lit 1))
              (seqList [
                .writeWordLocal 29 (.lit 1) (.lit 0),
                .repeatN (.lit (D₀ : ℤ)) (gcMarkJobLevelStmt D₀ M_box)
              ])
              .skip) msp mj (240 * D₀ + 50) ∧
          wReadL 1 mj 29 0 = (r : ℤ) ∧
          (∀ s < NumSlots, wRead mj 7 (s : ℤ) =
            if s ∈ U_pref r ∪ snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r then 1 else 0) ∧
          (∀ t, t ≠ 7 → ∀ i, wRead mj t i = wRead mem t i) ∧
          (∀ t i, rRead mj t i = rRead mem t i) := by
        by_cases h16 : wRead mem 16 (r : ℤ) = 1
        · rcases hjob_lt r hr_lt h16 with ⟨jLen, hjLen_le, hw19_r, hj_slots⟩
          have hcond16 : cValAt 1 inp msp (.intEq (.readHeap 16 (.readLocal 29 (.lit 0))) (.lit 1)) = true := by
            simp only [cValAt_intEq, iValAt_readHeap, iValAt_readLocal, iValAt_lit,
              hwl_msp, hwl_md, hr_loc, hw_msp 16 (by decide), hw_md 16 (by decide), hw_ro 16 (by decide),
              h16, decide_true]
          let mj0 := wWriteL 1 msp 29 1 0
          have hj_init : DetExecAt 1 inp (.writeWordLocal 29 (.lit 1) (.lit 0)) msp mj0 4 :=
            DetExecAt.writeWordLocal 1 inp msp 29 _ _ rfl rfl (by simp [intExprOps])
          let UJ : ℕ → Finset ℕ := fun j_lim =>
            insert spS (insert dS (U_pref r)) ∪
              (Finset.range (min j_lim jLen)).biUnion (fun j => jobLevelSlotSet mem (r * D₀ + j))
          let InvJ : ℕ → ArithRAMMemory → Prop := fun j_lim mq =>
            wReadL 1 mq 29 0 = (r : ℤ) ∧
            wReadL 1 mq 29 1 = (j_lim : ℤ) ∧
            (∀ s < NumSlots, wRead mq 7 (s : ℤ) = if s ∈ UJ j_lim then 1 else 0) ∧
            (∀ t, t ≠ 7 → ∀ i, wRead mq t i = wRead mem t i) ∧
            (∀ t i, rRead mq t i = rRead mem t i)
          have hInvJ0 : InvJ 0 mj0 := by
            refine ⟨by simp [mj0, hwl_msp, hwl_md, hr_loc], by simp [mj0], fun s hs => ?_,
              fun t ht i => by simp [mj0, hw_msp t ht, hw_md t ht, hw_ro t ht],
              fun t i => by simp [mj0, hr_msp, hr_md, hr_ro]⟩
            have hUJ0 : UJ 0 = insert spS (insert dS (U_pref r)) := by dsimp [UJ]; simp
            rw [hUJ0]; simpa [mj0] using hmap_sp s hs
          have hStepJ : ∀ j < D₀, ∀ mq, InvJ j mq →
              ∃ mq', DetExecAt 1 inp (gcMarkJobLevelStmt D₀ M_box) mq mq' 230 ∧ InvJ (j + 1) mq' := by
            intro j _ mq ⟨hq0, hq1, hmap_q, hw_qo, hr_qo⟩
            by_cases hj_lt : j < jLen
            · have hmj0 : min j jLen = j := Nat.min_eq_left (le_of_lt hj_lt)
              have hmj1 : min (j + 1) jLen = j + 1 := Nat.min_eq_left (Nat.succ_le_of_lt hj_lt)
              have hcond_j : cValAt 1 inp mq
                  (.intLt (.readLocal 29 (.lit 1)) (.readHeap 19 (.readLocal 29 (.lit 0)))) = true := by
                simp only [cValAt_intLt, iValAt_readLocal, iValAt_readHeap, iValAt_lit,
                  hq1, hq0, hw_qo 19 (by decide), hw19_r, decide_eq_true_eq]
                exact_mod_cast hj_lt
              rcases hj_slots j hj_lt with ⟨s2, s3, s4, s5, s6, hs2, hs3, hs4, hs5, hs6, hw2, hw3, hw4, hw5, hw6⟩
              let idx := r * D₀ + j
              let q1 := wWriteL 1 mq 29 2 (idx : ℤ)
              have hst1 : DetExecAt 1 inp
                  (.writeWordLocal 29 (.lit 2)
                    (.add (.mul (.readLocal 29 (.lit 0)) (.lit (D₀ : ℤ))) (.readLocal 29 (.lit 1)))) mq q1 10 := by
                refine DetExecAt.writeWordLocal 1 inp mq 29 _ _ rfl ?_ (by simp [intExprOps])
                simp only [iValAt_add, iValAt_mul, iValAt_readLocal, iValAt_lit, hq0, hq1, idx, Nat.cast_add, Nat.cast_mul]
              have hmap_q1 : ∀ s < NumSlots, wRead q1 7 (s : ℤ) = if s ∈ UJ j then 1 else 0 :=
                fun s hs => by simp [q1, hmap_q s hs]
              have hq1_2 : wReadL 1 q1 29 2 = (idx : ℤ) := by simp [q1]
              have hw2' : wRead mem 23 (8 * (idx : ℤ) + 2) = (s2 : ℤ) := by simpa [idx] using hw2
              have hw3' : wRead mem 23 (8 * (idx : ℤ) + 3) = (s3 : ℤ) := by simpa [idx] using hw3
              have hw4' : wRead mem 23 (8 * (idx : ℤ) + 4) = (s4 : ℤ) := by simpa [idx] using hw4
              have hw5' : wRead mem 23 (8 * (idx : ℤ) + 5) = (s5 : ℤ) := by simpa [idx] using hw5
              have hw6' : wRead mem 23 (8 * (idx : ℤ) + 6) = (s6 : ℤ) := by simpa [idx] using hw6
              rcases exec_markSlot7 inp q1 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 2)))
                  s2 (UJ j) hs2 hBox_slots
                  (by simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
                        hq1_2, q1, wRead_wWriteL, hw_qo 23 (by decide)]; exact hw2') hmap_q1
                with ⟨q2, ex2, hm2, hw_q2, hr_q2, hwl_q2⟩
              rcases exec_markSlot7 inp q2 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 3)))
                  s3 (insert s2 (UJ j)) hs3 hBox_slots
                  (by simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
                        hwl_q2, hq1_2, hw_q2 23 (by decide)]; simp only [q1, wRead_wWriteL, hw_qo 23 (by decide)]; exact hw3') hm2
                with ⟨q3, ex3, hm3, hw_q3, hr_q3, hwl_q3⟩
              rcases exec_markSlot7 inp q3 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 4)))
                  s4 (insert s3 (insert s2 (UJ j))) hs4 hBox_slots
                  (by simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
                        hwl_q3, hwl_q2, hq1_2, hw_q3 23 (by decide), hw_q2 23 (by decide)]; simp only [q1, wRead_wWriteL, hw_qo 23 (by decide)]; exact hw4') hm3
                with ⟨q4, ex4, hm4, hw_q4, hr_q4, hwl_q4⟩
              rcases exec_markSlot7 inp q4 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 5)))
                  s5 (insert s4 (insert s3 (insert s2 (UJ j)))) hs5 hBox_slots
                  (by simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
                        hwl_q4, hwl_q3, hwl_q2, hq1_2, hw_q4 23 (by decide), hw_q3 23 (by decide),
                        hw_q2 23 (by decide)]; simp only [q1, wRead_wWriteL, hw_qo 23 (by decide)]; exact hw5') hm4
                with ⟨q5, ex5, hm5, hw_q5, hr_q5, hwl_q5⟩
              rcases exec_markSlot7 inp q5 (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 2))) (.lit 6)))
                  s6 (insert s5 (insert s4 (insert s3 (insert s2 (UJ j))))) hs6 hBox_slots
                  (by simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
                        hwl_q5, hwl_q4, hwl_q3, hwl_q2, hq1_2, hw_q5 23 (by decide), hw_q4 23 (by decide),
                        hw_q3 23 (by decide), hw_q2 23 (by decide)]; simp only [q1, wRead_wWriteL, hw_qo 23 (by decide)]; exact hw6') hm5
                with ⟨q6, ex6, hm6, hw_q6, hr_q6, hwl_q6⟩
              let q7 := wWriteL 1 q6 29 1 (((j + 1 : ℕ) : ℤ))
              have hst7 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))) q6 q7 8 := by
                refine DetExecAt.writeWordLocal 1 inp q6 29 _ _ rfl ?_ (by simp [intExprOps])
                simp [hwl_q6, hwl_q5, hwl_q4, hwl_q3, hwl_q2, q1, hq1]
              have hjl_eq : jobLevelSlotSet mem idx = {s2, s3, s4, s5, s6} := by
                unfold jobLevelSlotSet
                rw [hw2, hw3, hw4, hw5, hw6]
                simp
              have hUJ_succ : UJ (j + 1) = insert s6 (insert s5 (insert s4 (insert s3 (insert s2 (UJ j))))) := by
                dsimp only [UJ]
                rw [hmj0, hmj1, Finset.range_add_one, Finset.biUnion_insert, hjl_eq]
                ext x; simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton]
                exact or_five_insert
              refine ⟨q7,
                (DetExecAt.ite_true hcond_j (C_c := 12) (by simp [condExprOps, intExprOps])
                  (hst1.seq (ex2.seq (ex3.seq (ex4.seq (ex5.seq (ex6.seq hst7))))))).mono_cost
                  (by dsimp [intExprOps]; omega),
                by simp [q7, hwl_q6, hwl_q5, hwl_q4, hwl_q3, hwl_q2, q1, hq0],
                by simp [q7],
                fun s hs => by rw [hUJ_succ]; simpa [q7] using hm6 s hs,
                fun t ht i => by simp [q7, hw_q6 t ht, hw_q5 t ht, hw_q4 t ht, hw_q3 t ht, hw_q2 t ht, q1, hw_qo t ht],
                fun t i => by simp [q7, hr_q6, hr_q5, hr_q4, hr_q3, hr_q2, q1, hr_qo]⟩
            · have hmj_eq : min (j + 1) jLen = min j jLen := by omega
              have hcond_j : cValAt 1 inp mq
                  (.intLt (.readLocal 29 (.lit 1)) (.readHeap 19 (.readLocal 29 (.lit 0)))) = false := by
                simp only [cValAt_intLt, iValAt_readLocal, iValAt_readHeap, iValAt_lit,
                  hq1, hq0, hw_qo 19 (by decide), hw19_r, decide_eq_false_iff_not]
                exact_mod_cast hj_lt
              let q1 := wWriteL 1 mq 29 1 (((j + 1 : ℕ) : ℤ))
              have hst1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))) mq q1 8 :=
                DetExecAt.writeWordLocal 1 inp mq 29 _ _ rfl (by simp [hq1]) (by simp [intExprOps])
              refine ⟨q1,
                (DetExecAt.ite_false hcond_j (C_c := 12) (by simp [condExprOps, intExprOps]) hst1).mono_cost (by omega),
                by simp [q1, hq0], by simp [q1],
                fun s hs => by dsimp only [UJ]; rw [hmj_eq]; simpa [q1] using hmap_q s hs,
                fun t ht i => by simp [q1, hw_qo t ht],
                fun t i => by simp [q1, hr_qo]⟩
          rcases DetExecAt.repeatN_nat (.lit (D₀ : ℤ)) _ D₀ 1 230 InvJ hInvJ0 rfl
              (by simp [intExprOps]) hStepJ
            with ⟨mjN, ⟨hqN0, _, hmap_jN, hw_jN, hr_jN⟩, hrepJ⟩
          have hUJD : UJ D₀ = U_pref r ∪ snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r := by
            dsimp only [UJ]
            rw [Nat.min_eq_right hjLen_le, hsn_eq]
            unfold jobOwnedSlotSet
            rw [if_pos h16, hw19_r, Int.toNat_natCast]
            ext x; simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton]
            exact or_sp_d_union
          refine ⟨mjN,
            (DetExecAt.ite_true hcond16 (C_c := 12) (by simp [condExprOps, intExprOps])
              (hj_init.seq hrepJ)).mono_cost (by omega),
            hqN0, fun s hs => by rw [← hUJD]; exact hmap_jN s hs, hw_jN, hr_jN⟩
        · have hcond16 : cValAt 1 inp msp (.intEq (.readHeap 16 (.readLocal 29 (.lit 0))) (.lit 1)) = false := by
            simp only [cValAt_intEq, iValAt_readHeap, iValAt_readLocal, iValAt_lit,
              hwl_msp, hwl_md, hr_loc, hw_msp 16 (by decide), hw_md 16 (by decide), hw_ro 16 (by decide),
              decide_eq_false_iff_not]
            exact h16
          have hset_eq : insert spS (insert dS (U_pref r)) =
              U_pref r ∪ snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r := by
            unfold jobOwnedSlotSet
            rw [if_neg h16, hsn_eq]
            ext x; simp only [Finset.mem_union, Finset.mem_insert, Finset.mem_singleton, Finset.notMem_empty, or_false]
            exact or_sp_d_only
          refine ⟨msp,
            (DetExecAt.ite_false hcond16 (C_c := 12) (by simp [condExprOps, intExprOps])
              (DetExecAt.skip 1 inp msp)).mono_cost (by omega),
            by rw [hwl_msp, hwl_md, hr_loc],
            fun s hs => by rw [← hset_eq]; exact hmap_sp s hs,
            fun t ht i => by rw [hw_msp t ht, hw_md t ht, hw_ro t ht],
            fun t i => by rw [hr_msp, hr_md, hr_ro]⟩
      rcases hjob_branch with ⟨mj, hdj, hj_loc0, hmap_mj, hw_mj, hr_mj⟩
      let mr' := wWriteL 1 mj 29 0 (((r + 1 : ℕ) : ℤ))
      have hinc_r : DetExecAt 1 inp (.writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))) mj mr' 8 :=
        DetExecAt.writeWordLocal 1 inp mj 29 _ _ rfl (by simp [hj_loc0]) (by simp [intExprOps])
      have hUp_succ : U_pref (r + 1) = U_pref r ∪ snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r := by
        dsimp only [U_pref]
        rw [hmin_r, hmin_r1, Finset.range_add_one, Finset.biUnion_insert]
        ext x; simp only [Finset.mem_insert, Finset.mem_union]
        exact or_upref_step
      refine ⟨mr',
        (DetExecAt.ite_true hcond_r (C_c := 12) (by simp [condExprOps, intExprOps])
          (hd_exec.seq (hsp_exec.seq (hdj.seq hinc_r)))).mono_cost (by dsimp [intExprOps]; omega),
        by simp [mr'],
        fun s hs => by rw [hUp_succ]; simpa [mr'] using hmap_mj s hs,
        fun t ht i => by simp [mr', hw_mj t ht],
        fun t i => by simp [mr', hr_mj]⟩
    · have hmin_eq : min (r + 1) chainLen = min r chainLen := by omega
      have hcond_r : cValAt 1 inp m (.intLt (.readLocal 29 (.lit 0)) (.readHeap 1 (.lit 5))) = false := by
        simp only [cValAt_intLt, iValAt_readLocal, iValAt_readHeap, iValAt_lit,
          hr_loc, hw_ro 1 (by decide), hw_cL, decide_eq_false_iff_not]
        exact_mod_cast hr_lt
      let mr' := wWriteL 1 m 29 0 (((r + 1 : ℕ) : ℤ))
      have hinc_r : DetExecAt 1 inp (.writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))) m mr' 8 :=
        DetExecAt.writeWordLocal 1 inp m 29 _ _ rfl (by simp [hr_loc]) (by simp [intExprOps])
      refine ⟨mr',
        (DetExecAt.ite_false hcond_r (C_c := 12) (by simp [condExprOps, intExprOps]) hinc_r).mono_cost (by omega),
        by simp [mr'],
        fun s hs => by dsimp only [U_pref]; rw [hmin_eq]; simpa [mr'] using hmap_r s hs,
        fun t ht i => by simp [mr', hw_ro t ht],
        fun t i => by simp [mr', hr_ro]⟩
  rcases DetExecAt.repeatN_nat (.lit (D₀ : ℤ)) _ D₀ 1 (260 * (D₀ + 1)) InvR hInvR0 rfl
      (by simp [intExprOps]) hStepR
    with ⟨mR, ⟨_, hmap_R, hw_Ro, hr_Ro⟩, hrepR⟩
  have hUD : U_pref D₀ = activeSlotSet mem D₀ := by
    dsimp only [U_pref, activeSlotSet]
    rw [Nat.min_eq_right hcL_le, hw_cL, hw_leaf, Int.toNat_natCast, Int.toNat_natCast]
  refine ⟨mR.popDepth 0,
    DetExecAt.localScope
      ((hs_z0.seq (hrepZ.seq (hm0.seq (hmL.seq (hs_c0.seq hrepR))))).mono_cost
        (by
          dsimp [intExprOps]
          have hexp : 300 * (D₀ + 1) * (D₀ + 1) = D₀ * (260 * (D₀ + 1)) + (40 * D₀ * (D₀ + 1) + 300 * (D₀ + 1)) := by ring
          rw [hexp]; omega)),
    popDepth_zero_idem mR,
    fun s hs => by rw [wRead_popDepth, ← hUD]; exact hmap_R s hs,
    fun t ht i => by rw [wRead_popDepth]; exact hw_Ro t ht i,
    fun t i => by rw [rRead_popDepth]; exact hr_Ro t i⟩

/-- Allocate ONE fresh slot `< NumSlots` disjoint from `used`, mark it in `slotInUse` (Word `7`),
store it into heap scratch register `wRead 26 destReg`, and reset `wRead 6 freeS := 0` + `resetSegSlotStmt`!
Runs at `fd = 0`. -/
def allocMarkAndResetSlotStmt (NumSlots M_box destReg : ℕ) : ArithRAMStmt :=
  seqList [
    .localScope (seqList [
      allocFreeSlotStmt NumSlots,
      boxWriteW M_box 7 (.readLocal 29 (.lit 0)) (.lit 1),
      boxWriteW M_box 26 (.lit (destReg : ℤ)) (.readLocal 29 (.lit 0)),
      boxWriteW M_box 6 (.readLocal 29 (.lit 0)) (.lit 0)
    ]),
    .localScope (resetSegSlotStmt M_box (.readHeap 26 (.lit (destReg : ℤ))))
  ]

theorem boxSafe_allocMarkAndResetSlotStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max)
    (NumSlots destReg : ℕ) :
    BoxSafeOuter T_max M_box (allocMarkAndResetSlotStmt NumSlots M_box destReg) := by
  apply boxSafeOuter_seqList; simp only [List.mem_cons, List.not_mem_nil, or_false]
  rintro s (rfl | rfl)
  · apply BoxSafeOuter.localScope
    apply boxSafeInner_seqList; simp only [List.mem_cons, List.not_mem_nil, or_false]
    rintro s' (rfl | rfl | rfl | rfl)
    · exact boxSafe_allocFreeSlotStmt NumSlots
    · exact BoxSafeInner.boxW (by omega) _ _
    · exact BoxSafeInner.boxW (by omega) _ _
    · exact BoxSafeInner.boxW (by omega) _ _
  · exact BoxSafeOuter.localScope (boxSafe_resetSegSlotStmt (by omega) _)

theorem exec_allocMarkAndResetSlotStmt {d n K NumSlots M_box destReg : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {used : Finset ℕ}
    (hcard : (used.filter (· < NumSlots)).card < NumSlots)
    (hmap : ∀ s < NumSlots, wRead mem 7 (s : ℤ) = if s ∈ used then 1 else 0)
    (hdest_lt : destReg < M_box)
    (hBox1 : 4 ≤ M_box) (hBox_slots : NumSlots ≤ M_box)
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem) :
    ∃ (m' : ArithRAMMemory) (freeS : ℕ),
      DetExecAt 0 inp (allocMarkAndResetSlotStmt NumSlots M_box destReg) mem m'
        (35 * (NumSlots + 1) + 200) ∧
      m'.popDepth 0 = m' ∧
      freeS < NumSlots ∧
      freeS ∉ used ∧
      wRead m' 26 (destReg : ℤ) = (freeS : ℤ) ∧
      wRead m' 6 (freeS : ℤ) = 0 ∧
      (∀ s < NumSlots, wRead m' 7 (s : ℤ) = if s ∈ insert freeS used then 1 else 0) ∧
      SegGenBound K NumSlots m' ∧
      SaveGenBound n NumSlots m' ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' freeS ∅ fSq) ∧
      (∀ s' < NumSlots, s' ≠ freeS → ∀ S₁ fSq₁,
        EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ (activeH : Finset ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d)),
        ∀ s' < NumSlots, s' ≠ freeS → ∀ S₁ sp₁,
          EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
          EncSlotCoords d n m' activeH livePts s' S₁ sp₁) ∧
      (∀ s' : ℤ, s' ≠ (freeS : ℤ) → wRead m' 6 s' = wRead mem 6 s') ∧
      (∀ t, t ≠ 1 → t ≠ 5 → t ≠ 6 → t ≠ 7 → t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 3 → wRead m' 1 i = wRead mem 1 i) ∧
      (∀ i, i ≠ (destReg : ℤ) → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) := by
  let m0 := mem.popDepth 0
  rcases exec_allocFreeSlotStmt inp m0 (used := used) hcard
      (fun s hs => by simp [m0, hmap s hs])
    with ⟨ma, freeS, hda, hf_lt, hf_not, hf_loc, hw_ma, hr_ma, _, _, _, _⟩
  rcases exec_markSlot7 inp ma (.readLocal 29 (.lit 0)) freeS used hf_lt hBox_slots
      (by simp [hf_loc]) (fun s hs => by rw [hw_ma]; simp [m0, hmap s hs])
    with ⟨m1, hdm7, hmap_m1, hw_m1, hr_m1, hwl_m1⟩
  let m2 := wWrite m1 26 (destReg : ℤ) (freeS : ℤ)
  let m3 := wWrite m2 6 (freeS : ℤ) 0
  have hd26 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit (destReg : ℤ)) (.readLocal 29 (.lit 0))) m1 m2 20 :=
    exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) (by simp [hwl_m1, hf_loc]) (by dsimp [intExprOps]; omega)
  have hd6 : DetExecAt 1 inp (boxWriteW M_box 6 (.readLocal 29 (.lit 0)) (.lit 0)) m2 m3 20 :=
    exec_boxWriteW inp m2 _ _ (by simp [m2, hwl_m1, hf_loc]) (by omega) (by omega) rfl (by dsimp [intExprOps]; omega)
  let mid := m3.popDepth 0
  have hd_s1 : DetExecAt 0 inp
      (.localScope (seqList [
        allocFreeSlotStmt NumSlots,
        boxWriteW M_box 7 (.readLocal 29 (.lit 0)) (.lit 1),
        boxWriteW M_box 26 (.lit (destReg : ℤ)) (.readLocal 29 (.lit 0)),
        boxWriteW M_box 6 (.readLocal 29 (.lit 0)) (.lit 0)
      ])) mem mid (30 * (NumSlots + 1) + 70) :=
    DetExecAt.localScope ((hda.seq (hdm7.seq (hd26.seq hd6))).mono_cost (by dsimp [intExprOps]; omega))
  have hw_mid_o : ∀ t, t ≠ 6 → t ≠ 7 → t ≠ 26 → ∀ i, wRead mid t i = wRead mem t i :=
    fun t h6 h7 h26 i => by simp [mid, m3, h6, m2, h26, hw_m1 t h7, hw_ma, m0]
  have hr_mid : ∀ t i, rRead mid t i = rRead mem t i :=
    fun t i => by simp [mid, m3, m2, hr_m1, hr_ma, m0]
  have hseg_mid : SegGenBound K NumSlots mid :=
    ⟨by rw [hw_mid_o 1 (by decide) (by decide) (by decide)]; exact hseg.1,
     fun s hs => by rw [hw_mid_o 5 (by decide) (by decide) (by decide), hw_mid_o 1 (by decide) (by decide) (by decide)]; exact hseg.2.1 s hs,
     fun s hs u hu => by rw [hw_mid_o 8 (by decide) (by decide) (by decide), hw_mid_o 1 (by decide) (by decide) (by decide)]; exact hseg.2.2 s hs u hu⟩
  have hsave_mid : SaveGenBound n NumSlots mid := by
    refine ⟨by rw [hw_mid_o 1 (by decide) (by decide) (by decide)]; exact hsave.1,
      fun s hs => ?_,
      fun s hs u hu => by rw [hw_mid_o 11 (by decide) (by decide) (by decide), hw_mid_o 1 (by decide) (by decide) (by decide)]; exact hsave.2.2 s hs u hu⟩
    rw [hw_mid_o 1 (by decide) (by decide) (by decide)]
    by_cases heq : s = freeS
    · subst heq; have := hsave.1; simp [mid, m3]; omega
    · have hne : (s : ℤ) ≠ (freeS : ℤ) := by exact_mod_cast heq
      simp only [mid, wRead_popDepth, m3, wRead_wWrite_of_ne _ _ (Or.inr hne),
        m2, wRead_wWrite_of_ne _ _ (Or.inl (by decide : (6 : ℕ) ≠ 26)),
        hw_m1 6 (by decide), hw_ma, m0]
      exact hsave.2.1 s hs
  have hdest_mid : wRead mid 26 (destReg : ℤ) = (freeS : ℤ) := by
    simp [mid, m3, m2]
  have hmid_pop : mid.popDepth 0 = mid := popDepth_zero_idem m3
  rcases exec_resetSegSlotStmt_save inp (mid.popDepth 0) (.readHeap 26 (.lit (destReg : ℤ))) hf_lt
      (by simp [hdest_mid]) hBox1 hBox_slots
      (by rw [hmid_pop]; exact hseg_mid) (by rw [hmid_pop]; exact hsave_mid)
    with ⟨mr, hdr, hseg_r, hsave_r, hEmp_r, hOther_r, hw_ro, hw1_r, hr_r, _, _⟩
  have hd_s2 : DetExecAt 0 inp (.localScope (resetSegSlotStmt M_box (.readHeap 26 (.lit (destReg : ℤ)))))
      mid (mr.popDepth 0) 90 :=
    DetExecAt.localScope (hdr.mono_cost (by dsimp [intExprOps]; omega))
  let m' := mr.popDepth 0
  have hw_m'_mid : ∀ t, t ≠ 1 → t ≠ 5 → ∀ i, wRead m' t i = wRead mid t i :=
    fun t h1 h5 i => by simp [m', hw_ro t h1 h5, hmid_pop]
  have hr_m'_mem : ∀ t i, rRead m' t i = rRead mem t i :=
    fun t i => by simp [m', hr_r, hmid_pop, hr_mid]
  refine ⟨m', freeS,
    (hd_s1.seq hd_s2).mono_cost (by omega),
    popDepth_zero_idem mr,
    hf_lt, hf_not,
    by rw [hw_m'_mid 26 (by decide) (by decide), hdest_mid],
    by rw [hw_m'_mid 6 (by decide) (by decide)]; simp [mid, m3],
    fun s hs => by rw [hw_m'_mid 7 (by decide) (by decide)]; simpa [mid, m3, m2] using hmap_m1 s hs,
    ⟨by simp [m']; exact hseg_r.1,
     fun s hs => by simp [m']; exact hseg_r.2.1 s hs,
     fun s hs u hu => by simp [m']; exact hseg_r.2.2 s hs u hu⟩,
    ⟨by simp [m']; exact hsave_r.1,
     fun s hs => by simp [m']; exact hsave_r.2.1 s hs,
     fun s hs u hu => by simp [m']; exact hsave_r.2.2 s hs u hu⟩,
    fun fSq => (hEmp_r fSq).congr_mem_fSq (by simp [m']) (fun _ _ => by simp [m'])
      (fun _ _ => by simp [m']) (fun _ _ => by simp [m']) (fun _ _ => by simp [m']) (fun _ _ => rfl),
    fun s' hs' hne S₁ fSq₁ h0 => by
      have a_mid : EncSegSlot K (mid.popDepth 0) s' S₁ fSq₁ :=
        h0.congr_mem_fSq
          (by rw [wRead_popDepth, hw_mid_o 5 (by decide) (by decide) (by decide)])
          (fun _ _ => by rw [wRead_popDepth, hw_mid_o 8 (by decide) (by decide) (by decide)])
          (fun _ _ => by rw [wRead_popDepth, hw_mid_o 9 (by decide) (by decide) (by decide)])
          (fun _ _ => by rw [wRead_popDepth, hw_mid_o 10 (by decide) (by decide) (by decide)])
          (fun _ _ => by rw [rRead_popDepth, hr_mid]) (fun _ _ => rfl)
      have a_mr := hOther_r s' hs' hne S₁ fSq₁ a_mid
      exact a_mr.congr_mem_fSq (by simp [m']) (fun _ _ => by simp [m'])
        (fun _ _ => by simp [m']) (fun _ _ => by simp [m']) (fun _ _ => by simp [m']) (fun _ _ => rfl),
    fun _ _ s' _ hne S₁ sp₁ h0 => by
      have hne_z : (s' : ℤ) ≠ (freeS : ℤ) := by exact_mod_cast hne
      exact h0.congr_mem
        (by rw [hw_m'_mid 6 (by decide) (by decide)]
            simp only [mid, wRead_popDepth, m3, wRead_wWrite_of_ne _ _ (Or.inr hne_z),
              m2, wRead_wWrite_of_ne _ _ (Or.inl (by decide : (6 : ℕ) ≠ 26)),
              hw_m1 6 (by decide), hw_ma, m0])
        (fun _ => by rw [hw_m'_mid 11 (by decide) (by decide), hw_mid_o 11 (by decide) (by decide) (by decide)])
        (fun _ => hr_m'_mem 11 _),
    fun s' hne => by
      rw [hw_m'_mid 6 (by decide) (by decide)]
      simp only [mid, wRead_popDepth, m3, wRead_wWrite_of_ne _ _ (Or.inr hne),
        m2, wRead_wWrite_of_ne _ _ (Or.inl (by decide : (6 : ℕ) ≠ 26)),
        hw_m1 6 (by decide), hw_ma, m0],
    fun t h1 h5 h6 h7 h26 i => by rw [hw_m'_mid t h1 h5, hw_mid_o t h6 h7 h26],
    fun i hi => by simp [m', hw1_r i hi, hmid_pop, hw_mid_o 1 (by decide) (by decide) (by decide)],
    fun i hi => by
      rw [hw_m'_mid 26 (by decide) (by decide)]
      simp only [mid, wRead_popDepth, m3, wRead_wWrite_of_ne _ _ (Or.inl (by decide : (26 : ℕ) ≠ 6)),
        m2, wRead_wWrite_of_ne _ _ (Or.inr hi), hw_m1 26 (by decide), hw_ma, m0],
    hr_m'_mem⟩


end UL.Proof_lem_7_2_RacerP46
