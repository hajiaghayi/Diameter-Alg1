import UL.Proof.lem_7_2.CG01_MidGlueA
import UL.Proof.lem_7_2.CG03_JobTickA3c2a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. `PostRouteContextRelaxed.toMidLoopCtx` & Memory Congruence Helpers -/

private lemma jobHandleInput_subset_root {d : ℕ} (D : ℕ)
    (livePts : ℕ → EuclideanSpace ℝ (Fin d))
    (lvs : List (JobLvData d)) (S_root : Finset ℕ) (j : ℕ) :
    jobHandleInput D livePts lvs S_root j ⊆ S_root := by
  induction j generalizing lvs S_root with
  | zero =>
      intro x hx
      simpa [jobHandleInput] using hx
  | succ j' ih =>
      cases lvs with
      | nil =>
          intro x hx
          simpa [jobHandleInput] using hx
      | cons lv rest =>
          change jobHandleInput D livePts rest ((lv.ball D).residual livePts S_root) j' ⊆ S_root
          exact (ih rest _).trans (nodeResidual_subset livePts (lv.ball D) S_root)

private lemma globalSlotDisj_congr_tables {D₀ : ℕ} {m m' : ArithRAMMemory} {k leafS : ℕ}
    (h14 : ∀ i, wRead m' 14 i = wRead m 14 i)
    (h15 : ∀ i, wRead m' 15 i = wRead m 15 i)
    (h16 : ∀ i, wRead m' 16 i = wRead m 16 i)
    (h19 : ∀ i, wRead m' 19 i = wRead m 19 i)
    (h23 : ∀ i, wRead m' 23 i = wRead m 23 i)
    (h : GlobalSlotDisj D₀ m k leafS) :
    GlobalSlotDisj D₀ m' k leafS := by
  have hsn : ∀ r, snSlotSet m' r = snSlotSet m r :=
    fun r => snSlotSet_congr_14_15 (h14 (r : ℤ)) (h15 (r : ℤ))
  have hL : ∀ idx sp, jobLevelLiveSlots m' idx sp = jobLevelLiveSlots m idx sp := by
    intro idx sp
    unfold jobLevelLiveSlots
    simp only [h23]
  rcases h with ⟨hl0, hs1, hs2, hj1, hj2⟩
  refine ⟨hl0, ?_, ?_, ?_, ?_⟩
  · intro r hr s hs; rw [hsn] at hs; exact hs1 r hr s hs
  · intro r₁ hr₁ r₂ hr₂ hne; rw [hsn, hsn]; exact hs2 r₁ hr₁ r₂ hr₂ hne
  · intro r hr hw_r j hj
    rw [h16] at hw_r; rw [h19] at hj
    have hp := hj1 r hr hw_r j hj
    dsimp only at hp ⊢
    rw [h19, hL]
    exact ⟨hp.1, fun r' hr' => by rw [hsn]; exact hp.2 r' hr'⟩
  · intro r₁ hr₁ hw_1 j₁ hj₁ r₂ hr₂ hw_2 j₂ hj₂ hne
    rw [h16] at hw_1 hw_2; rw [h19] at hj₁ hj₂
    rw [h19, h19, hL, hL, h23, h23]
    exact hj2 r₁ hr₁ hw_1 j₁ hj₁ r₂ hr₂ hw_2 j₂ hj₂ hne

private lemma encSegSlot_congr_not26 {K : ℕ} {m m' : ArithRAMMemory} {s : ℕ}
    {S : Finset ℕ} {fSq : ℕ → ℝ}
    (hw : ∀ t, t ≠ 26 → ∀ i, wRead m' t i = wRead m t i)
    (hr : ∀ t i, rRead m' t i = rRead m t i)
    (h : EncSegSlot K m s S fSq) :
    EncSegSlot K m' s S fSq :=
  h.congr_mem_fSq
    (hw 5 (by decide) _)
    (fun _ _ => hw 8 (by decide) _)
    (fun _ _ => hw 9 (by decide) _)
    (fun _ _ => hw 10 (by decide) _)
    (fun _ _ => hr 8 _)
    (fun _ _ => rfl)

/-- Canonical `MidLoopCtx` constructed from `P46ParamsValid` and `PostRouteContextRelaxed`
with transparent (`rfl`) data projections! -/
noncomputable def PostRouteContextRelaxed.toMidLoopCtx
    {cHpj cBase d n t T_max M_box : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (hT28 : 28 ≤ T_max)
    (hM : p46BoxSize d n p ≤ M_box)
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    (ctx : PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap') :
    MidLoopCtx where
  T_max := T_max
  M_box := M_box
  cfg := defaultChainHdrCfg
  d := d
  n := n
  H := p.H
  p := p
  P := P
  P' := P'
  op := op
  opH := opH
  uMap' := uMap'
  st₀ := st₀
  trueAge' := Classical.choose ctx.exists_trueAge_post
  hV := valid_defaultChainHdrCfg hT28
  hD_eq := hp.hD_eq
  hH5 := hp.hH5
  hn2 := hp.hn2
  hn_2K := hp.hn_le_2K
  hD0_eq := hp.hD0
  hL_floor := hp.hL_floor
  hL_eq10 := hp.hL_eq10
  hB_floor := le_of_eq hp.hBscan.symm
  hKbatch := hp.hKbatch
  hSlots_cap := le_of_eq hp.hSlots.symm
  hkφ := hp.hφ_eq
  hφ0 := hp.hφ0
  hφ1 := hp.hφ1
  hp_eq := hp.hPhp_eq
  hp_props := hp.hPhp_props
  hbias_hpj := hp.hbias_hpj
  hB_hpj := hp.hBhpj
  hBox30 := (p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM).2.2.2.2.1
  hBox_slots := (p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM).2.2.2.2.2.2.2.2.2.2.1
  hBox_samp := (p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM).2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  hBox_d := (p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM).2.2.2.2.2.2.2.1
  hBox_w23 := ((p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM).2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2 (p.D₀ * p.D₀) le_rfl).1
  hBox_r23 := ((p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM).2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2 (p.D₀ * p.D₀) le_rfl).2
  hBox_seg := (p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM).2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  hBox_hdr := by
    have hms : defaultChainHdrCfg.maxStride = 1 := rfl
    rw [hms, one_mul]
    exact (p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM).2.2.2.2.2.1
  hBox_snO := by
    have hSnd := (p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM).2.2.2.2.2.2.2.2.2.2.2.2.1
    have hD0_Sl : p.D₀ ≤ p.NumSlots := by rw [hp.hSlots]; nlinarith
    have hD0_Sn : p.D₀ ≤ p.NumSlots * n :=
      le_trans hD0_Sl (Nat.le_mul_of_pos_right _ (by omega))
    exact le_trans (Nat.mul_le_mul_right d hD0_Sn) hSnd
  hwf₀ := ctx.hCoupled_pre.2.1
  hP := ctx.hP_wf
  hP' := ctx.hP'_wf
  hopH_n := ctx.hopH_n
  hopH_K := ctx.hopH_K
  hle_uid := ctx.hle_uid
  hag_uid := ctx.hag_uid
  hchg_root := ctx.hchg_root
  hcoords_root := ctx.hcoords_root
  hcoords_ne := ctx.hcoords_ne
  htr_le' := fun r => by
    have h1 := (Classical.choose_spec ctx.exists_trueAge_post).1 r
    cases op <;> exact h1
  hhas_age' := (Classical.choose_spec ctx.exists_trueAge_post).2
  hPerNode := fun r => by
    have hr := ctx.hPerNode r
    cases op <;> exact ⟨hr.2.1, hr.2.2.1⟩

/-! ### 2. Loop Entry Initialization (`midLoopInitStmt`) & Exit Extraction (`MidLoopState` at `p.D₀`) -/

def midLoopInitStmt (M_box : ℕ) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 26 (.lit 13) (.readHeap 26 (.lit 4)),
    boxWriteW M_box 26 (.lit 14) (.readHeap 26 (.lit 5)),
    boxWriteW M_box 26 (.lit 15) (.lit 0),
    boxWriteW M_box 26 (.lit 27) (.lit 0),
    boxWriteW M_box 26 (.lit 28) (.readHeap 1 (.lit 5))
  ]

theorem boxSafe_midLoopInitStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) :
    BoxSafeOuter T_max M_box (midLoopInitStmt M_box) := by
  unfold midLoopInitStmt
  apply boxSafeOuter_seqList
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl <;> exact .boxW (by omega) _ _

theorem preservesPoolWords_midLoopInitStmt (M_box : ℕ) :
    preservesPoolWords (midLoopInitStmt M_box) = true := rfl

lemma preservesPoolWords_seq {s₁ s₂ : ArithRAMStmt}
    (h₁ : preservesPoolWords s₁ = true) (h₂ : preservesPoolWords s₂ = true) :
    preservesPoolWords (.seq s₁ s₂) = true := by
  unfold preservesPoolWords at h₁ h₂ ⊢
  simp only [writesWordTag, writesWord1Low, Bool.and_eq_true, Bool.not_eq_true', Bool.or_eq_false_iff] at h₁ h₂ ⊢
  exact ⟨⟨⟨⟨h₁.1.1.1, h₂.1.1.1⟩, ⟨h₁.1.1.2, h₂.1.1.2⟩⟩, ⟨h₁.1.2, h₂.1.2⟩⟩, ⟨h₁.2, h₂.2⟩⟩

lemma preservesPoolWords_repeatN (c : IntExpr) {b : ArithRAMStmt}
    (hb : preservesPoolWords b = true) :
    preservesPoolWords (.repeatN c b) = true :=
  hb

lemma MidLoopState.to_false {ctx : MidLoopCtx} {retH0 : ℤ} {gFlag : Bool} {i : ℕ} {m : ArithRAMMemory}
    (h : MidLoopState ctx retH0 gFlag i m) :
    MidLoopState ctx retH0 false i m := by
  rcases h with ⟨h0, h13, h14, h15, h28, hU | hC⟩
  · exact ⟨h0, h13, h14, h15, h28, Or.inl hU.to_false⟩
  · exact ⟨h0, h13, h14, h15, h28, Or.inr hC.to_false⟩

theorem exec_midLoopInitStmt
    {cHpj cBase d n t T_max M_box : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (hT28 : 28 ≤ T_max)
    (hM : p46BoxSize d n p ≤ M_box)
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    {P_good₀ : Prop} (hGood₀ : P_good₀ → st₀.AllCentersGood)
    (ctx : PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap') :
    let mctx := ctx.toMidLoopCtx hp hn hT28 hM
    ∃ m₀ : ArithRAMMemory,
      DetExecAt 0 (mkStepInput n P op) (midLoopInitStmt M_box) mem_rt m₀ 120 ∧
      m₀.popDepth 0 = m₀ ∧
      MidLoopState mctx (wRead mem_rt 0 0) false 0 m₀ ∧
      (P_good₀ → MidLoopState mctx (wRead mem_rt 0 0) true 0 m₀) := by
  intro mctx
  let inp := mkStepInput n P op
  have hBox30 : 30 ≤ M_box := mctx.hBox30
  have hChain_rt := ctx.hChain_rt
  dsimp only at hChain_rt
  rcases hChain_rt with ⟨_, _, _, hPool_rt, hseg_rt, hsave_rt, hw15_rt, hw60_rt, hSeg0_rt,
    leafS, hleaf_pos, hleaf_lt, hw16_rt, hw6l_rt, hSegL_rt, hsn_rt, _, _⟩
  let s1 := wWrite mem_rt 26 13 (opH : ℤ)
  have e1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 13) (.readHeap 26 (.lit 4))) mem_rt s1 20 :=
    exec_boxWriteW inp mem_rt _ _ rfl (by omega) (by omega)
      (by simp [ctx.hw26_4]) (by simp [intExprOps])
  let ins_val : ℤ := if mctx.ins then 1 else 0
  have hw26_5_eq : wRead mem_rt 26 5 = ins_val := by
    have h5 := ctx.hw26_5
    dsimp only [ins_val, MidLoopCtx.ins, mctx, PostRouteContextRelaxed.toMidLoopCtx, updateIsInsert]
    cases op <;> exact h5
  let s2 := wWrite s1 26 14 ins_val
  have e2 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 14) (.readHeap 26 (.lit 5))) s1 s2 20 :=
    exec_boxWriteW inp s1 _ _ rfl (by omega) (by omega)
      (by simp [s1, hw26_5_eq]) (by simp [intExprOps])
  let s3 := wWrite s2 26 15 0
  have e3 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 15) (.lit 0)) s2 s3 16 :=
    exec_boxWriteW inp s2 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  let s4 := wWrite s3 26 27 0
  have e4 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 27) (.lit 0)) s3 s4 16 :=
    exec_boxWriteW inp s3 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  let m₀ := wWrite s4 26 28 (st₀.k : ℤ)
  have e5 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 28) (.readHeap 1 (.lit 5))) s4 m₀ 20 :=
    exec_boxWriteW inp s4 _ _ rfl (by omega) (by omega)
      (by simp [s4, s3, s2, s1, hw15_rt]) (by simp [intExprOps])
  have hex : DetExecAt 0 inp (midLoopInitStmt M_box) mem_rt m₀ 120 := by
    unfold midLoopInitStmt seqList
    exact (e1.seq (e2.seq (e3.seq (e4.seq e5)))).mono_cost (by omega)
  have hpop₀ : m₀.popDepth 0 = m₀ :=
    wWrite_popDepth_zero (wWrite_popDepth_zero (wWrite_popDepth_zero
      (wWrite_popDepth_zero (wWrite_popDepth_zero ctx.hpop_rt 26 13 _) 26 14 _) 26 15 _) 26 27 _) 26 28 _
  have hw_not26 : ∀ t, t ≠ 26 → ∀ i, wRead m₀ t i = wRead mem_rt t i := by
    intro t ht i
    dsimp only [m₀, s4, s3, s2, s1]
    simp [ht]
  have hr_all : ∀ t i, rRead m₀ t i = rRead mem_rt t i := by
    intro t i
    dsimp only [m₀, s4, s3, s2, s1]
    simp
  have hw_pre : ∀ t, t ≠ 0 → t ≠ 1 → t ≠ 2 → t ≠ 3 → t ≠ 8 → t ≠ 9 → t ≠ 10 →
      t ≠ 11 → t ≠ 13 → t ≠ 20 → t ≠ 26 → ∀ i, wRead m₀ t i = wRead m_pre t i :=
    fun t h0 h1 h2 h3 h8 h9 h10 h11 h13 h20 h26 i =>
      (hw_not26 t h26 i).trans (ctx.hw_other t h0 h1 h2 h3 h8 h9 h10 h11 h13 h20 h26 i)
  have hr_pre : ∀ t, t ≠ 4 → t ≠ 8 → t ≠ 11 → t ≠ 26 → ∀ i, rRead m₀ t i = rRead m_pre t i :=
    fun t h4 h8 h11 h26 i => (hr_all t i).trans (ctx.hr_other t h4 h8 h11 h26 i)
  -- Shared MidLoopUncut builder for any gFlag satisfying (gFlag = true → st₀.AllCentersGood)
  have hBuildUncut : ∀ (gFlag : Bool), (gFlag = true → st₀.AllCentersGood) →
      MidLoopUncut mctx gFlag 0 m₀ := by
    intro gFlag hg_st
    rcases ctx.hCoupled_pre.2.2.1 with ⟨_, _, _, _, _, _, _, hw60_pre, _,
      leafS_pre, _, _, hw16_pre, hw6l_pre, _, hsn_pre, _, _⟩
    rcases ctx.hCoupled_pre.2.2.2 with ⟨hbc_pre, _, hoj_pre, hDisj_pre⟩
    have hleaf_eq : (wRead m_pre 1 6).toNat = leafS := by
      have h16_eq : wRead mem_rt 1 6 = wRead m_pre 1 6 :=
        ctx.hw1_other 6 (by decide) (by decide) (by decide)
      rw [← h16_eq, hw16_rt]; simp
    rw [hleaf_eq] at hDisj_pre
    have hDisj₀ : GlobalSlotDisj p.D₀ m₀ st₀.k leafS :=
      globalSlotDisj_congr_tables
        (hw_pre 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))
        (hw_pre 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))
        (hw_pre 16 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))
        (hw_pre 19 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))
        (hw_pre 23 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))
        hDisj_pre
    have hseg₀ : SegGenBound p.K_seg p.NumSlots m₀ :=
      ⟨by rw [hw_not26 1 (by decide)]; exact hseg_rt.1,
       fun s hs => by rw [hw_not26 5 (by decide), hw_not26 1 (by decide)]; exact hseg_rt.2.1 s hs,
       fun s hs u hu => by rw [hw_not26 8 (by decide), hw_not26 1 (by decide)]; exact hseg_rt.2.2 s hs u hu⟩
    have hsave₀ : SaveGenBound n p.NumSlots m₀ :=
      ⟨by rw [hw_not26 1 (by decide)]; exact hsave_rt.1,
       fun s hs => by rw [hw_not26 6 (by decide), hw_not26 1 (by decide)]; exact hsave_rt.2.1 s hs,
       fun s hs h hh => by rw [hw_not26 11 (by decide), hw_not26 1 (by decide)]; exact hsave_rt.2.2 s hs h hh⟩
    have hLive₀ : EncLiveCoords d n m₀ P'.activeHandles P'.handleCoords :=
      ⟨hPool_rt.1.1, fun h hh c => by rw [hr_all]; exact hPool_rt.1.2 h hh c⟩
    refine ⟨by dsimp only [m₀, s4]; simp,
      fun hb r => (hg_st hb).1 r,
      hseg₀, hsave₀, hLive₀,
      by rw [hw_not26 1 (by decide)]; exact hw15_rt,
      by rw [hw_not26 6 (by decide)]; exact hw60_rt,
      encSegSlot_congr_not26 hw_not26 hr_all hSeg0_rt,
      leafS, hleaf_pos, hleaf_lt,
      by rw [hw_not26 1 (by decide)]; exact hw16_rt,
      by rw [hw_not26 6 (by decide)]; exact hw6l_rt,
      encSegSlot_congr_not26 hw_not26 hr_all hSegL_rt,
      hDisj₀,
      fun r hr => False.elim (Nat.not_lt_zero _ hr),
      ?_⟩
    intro r _
    refine ⟨?_, ?_, fun hb g hg => (hg_st hb).2 r g hg, ?_⟩
    · -- wRead m₀ 20 r = if aff then 1 else 0
      dsimp only [mctx, PostRouteContextRelaxed.toMidLoopCtx, defaultChainHdrCfg, HdrField.idx]
      simp only [one_mul, add_zero]
      rw [hw_not26 20 (by decide)]
      have hpn := (ctx.hPerNode r).1
      dsimp only [MidLoopCtx.aff, MidLoopCtx.ins, mctx, PostRouteContextRelaxed.toMidLoopCtx, updateIsInsert]
      cases op <;> exact hpn
    · -- EncNodeHeaderAt on m₀
      rcases hsn_rt r with ⟨dS, spS, hd0, hd_lt, hs0, hs_lt, hne,
        hage, h14, h15, h6d, h6s, ho, hV, hSegD, T_sp, hSegSp, hidle⟩
      refine ⟨dS, spS, T_sp, hd0, hd_lt, hs0, hs_lt, hne, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hidle⟩
      · dsimp only [mctx, PostRouteContextRelaxed.toMidLoopCtx, defaultChainHdrCfg, HdrField.idx]
        simp only [one_mul, add_zero]
        rw [hw_pre 12 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
        exact hbc_pre r
      · dsimp only [mctx, PostRouteContextRelaxed.toMidLoopCtx, defaultChainHdrCfg, HdrField.idx]
        simp only [one_mul, add_zero]
        rw [hw_not26 13 (by decide)]
        dsimp only [MidLoopCtx.snAge', MidLoopCtx.aff, MidLoopCtx.ins, mctx, PostRouteContextRelaxed.toMidLoopCtx, updateIsInsert]
        cases op <;> exact hage
      · rw [hw_not26 14 (by decide)]; exact h14
      · rw [hw_not26 15 (by decide)]; exact h15
      · rw [hw_not26 6 (by decide)]; exact h6d
      · rw [hw_not26 6 (by decide)]; exact h6s
      · intro c
        dsimp only [mctx, PostRouteContextRelaxed.toMidLoopCtx, defaultChainHdrCfg]
        rw [hr_all]; exact ho c
      · dsimp only [mctx, PostRouteContextRelaxed.toMidLoopCtx, defaultChainHdrCfg, HdrField.idx]
        simp only [one_mul, add_zero]
        rw [hr_all]; exact hV
      · exact encSegSlot_congr_not26 hw_not26 hr_all hSegD
      · exact encSegSlot_congr_not26 hw_not26 hr_all hSegSp
    · -- EncTodoJobAt mctx m₀ r
      unfold EncTodoJobAt
      dsimp only [mctx, PostRouteContextRelaxed.toMidLoopCtx]
      have hoj_r_enc := hoj_pre r
      cases hoj_eq : st₀.ownedJob r with
      | none =>
          dsimp only
          rw [hoj_eq] at hoj_r_enc
          change wRead m_pre 16 (r.val : ℤ) = 0 at hoj_r_enc
          rw [hw_pre 16 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
          exact hoj_r_enc
      | some g =>
          dsimp only
          rw [hoj_eq] at hoj_r_enc
          rcases hoj_r_enc with ⟨hw16_g, hw17_g, hw18_g, hw19_g, lvs_h, hlen_eq, hlv_all⟩
          refine ⟨?_, ?_, ?_, ?_, lvs_h, hlen_eq, ?_⟩
          · rw [hw_pre 16 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
            exact hw16_g
          · dsimp only [defaultChainHdrCfg, HdrField.idx] at hw17_g ⊢
            simp only [one_mul, add_zero] at hw17_g ⊢
            rw [hw_pre 17 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
            exact hw17_g
          · dsimp only [defaultChainHdrCfg, HdrField.idx] at hw18_g ⊢
            simp only [one_mul, add_zero] at hw18_g ⊢
            rw [hw_pre 18 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
            exact hw18_g
          · rw [hw_pre 19 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
            exact hw19_g
          · intro j hj
            rcases hlv_all j hj with ⟨hball, hopen, hbij_b, hEncLv_pre, hw23_7, hp2, hp3, hp4, hp5, hp6, hlt_ph, heq_ph⟩
            have hw23_eq : ∀ i, wRead m₀ 23 i = wRead m_pre 23 i :=
              hw_pre 23 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
            have hw24_eq : ∀ i, wRead m₀ 24 i = wRead m_pre 24 i :=
              hw_pre 24 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
            have hw6_eq : ∀ i, wRead m₀ 6 i = wRead m_pre 6 i :=
              hw_pre 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
            have hr23_eq : ∀ i, rRead m₀ 23 i = rRead m_pre 23 i :=
              hr_pre 23 (by decide) (by decide) (by decide) (by decide)
            have hr24_eq : ∀ i, rRead m₀ 24 i = rRead m_pre 24 i :=
              hr_pre 24 (by decide) (by decide) (by decide) (by decide)
            have hS_pre_sub : mctx.S_pre_h r ⊆ P.activeHandles :=
              cg01_chainInput_subset P.handleCoords st₀.nodes P.activeHandles r.castSucc
            have hSpar_sub : jobHandleInput (d + 3) P.handleCoords lvs_h (mctx.S_pre_h r) j ⊆ P.activeHandles :=
              (jobHandleInput_subset_root (d + 3) P.handleCoords lvs_h (mctx.S_pre_h r) j).trans hS_pre_sub
            have hj_w19 : j < (wRead m_pre 19 (r.val : ℤ)).toNat := by
              rw [hw19_g]; simpa [hlen_eq] using hj
            have hlen_w19 : (wRead m_pre 19 (r.val : ℤ)).toNat = lvs_h.length := by
              rw [hw19_g, ← hlen_eq]; simp
            have hseg_pres_lv : ∀ s ∈ jobLevelSlotSet m_pre (r.val * p.D₀ + j), s < p.NumSlots →
                (decide (j + 1 = lvs_h.length) = false →
                  s ≠ (wRead m_pre 23 (((8 * (r.val * p.D₀ + j) + 6 : ℕ) : ℤ))).toNat) →
                ∀ S₁ fSq₁, EncSegSlot p.K_seg m_pre s S₁ fSq₁ → EncSegSlot p.K_seg m₀ s S₁ fSq₁ := by
              intro s hs hs_lt hnd S₁ fSq₁ hEs
              have hused := mem_levelUsedSlots_of_enc hs hnd
              unfold LevelUsedSlots at hused
              simp only [Finset.mem_insert] at hused
              have hdisj_s : s ≠ 0 ∧ s ≠ (wRead m_pre 1 6).toNat ∧ ∀ r' : Fin st₀.k, s ∉ snSlotSet m_pre r'.val := by
                rcases hused with rfl | hlive_s
                · have h6_pos := (encJobLevel_live_and_frozen_slots hEncLv_pre).1
                  refine ⟨?_, ?_, ?_⟩
                  · intro h0; rw [h0] at h6_pos; omega
                  · intro hl; rw [hl, hleaf_eq] at h6_pos
                    have h16_eq : wRead mem_rt 1 6 = wRead m_pre 1 6 :=
                      ctx.hw1_other 6 (by decide) (by decide) (by decide)
                    have hl_pre_eq : leafS_pre = leafS := by
                      have : (leafS_pre : ℤ) = (leafS : ℤ) := hw16_pre.symm.trans (h16_eq.symm.trans hw16_rt)
                      exact_mod_cast this
                    rw [← hl_pre_eq] at h6_pos; omega
                  · intro r' h_in_sn
                    rcases hsn_pre r' with ⟨dS', spS', _, _, _, _, _, _, h14', h15', h6d', h6s', _⟩
                    unfold snSlotSet at h_in_sn
                    rw [h14', h15'] at h_in_sn
                    simp only [Int.toNat_natCast, Finset.mem_insert, Finset.mem_singleton] at h_in_sn
                    rcases h_in_sn with heq | heq <;> { rw [heq] at h6_pos; omega }
                · have hsp_eq : decide (j + 1 = (wRead m_pre 19 (r.val : ℤ)).toNat) = decide (j + 1 = lvs_h.length) := by
                    rw [hlen_w19]
                  have hlive_w19 : s ∈ jobLevelLiveSlots m_pre (r.val * p.D₀ + j)
                      (decide (j + 1 = (wRead m_pre 19 (r.val : ℤ)).toNat)) := by
                    rwa [hsp_eq]
                  have hd_rj := ctx.hCoupled_pre.2.2.2.2.2.2.2.2.2.1 r.val r.isLt hw16_g j hj_w19
                  refine ⟨(hd_rj.1 s hlive_w19).1, (hd_rj.1 s hlive_w19).2, ?_⟩
                  intro r'
                  exact Finset.disjoint_left.mp (hd_rj.2 r'.val r'.isLt) hlive_w19
              exact encSegSlot_congr_not26 hw_not26 hr_all
                (ctx.hOtherSeg s hs_lt hdisj_s.1 hdisj_s.2.1 hdisj_s.2.2 S₁ fSq₁ hEs)
            have hSnap_m₀ : ∀ s < p.NumSlots, 1 ≤ wRead m_pre 6 (s : ℤ) → ∀ S sp,
                EncSlotCoords d n m_pre P.activeHandles P.handleCoords s S sp →
                EncSlotCoords d n m₀ P'.activeHandles P'.handleCoords s S sp := by
              intro s hs h6 S sp hC
              exact encSlotCoords_congr_6_11 (ctx.hSnap s hs h6 S sp hC)
                (hw_not26 6 (by decide) _) (hw_not26 11 (by decide)) (hr_all 11)
            have hEncLv₀ := liftPreJobLevelAfterRoute hSpar_sub hEncLv_pre hseg_pres_lv hSnap_m₀
              hw6_eq hw23_eq hw24_eq hr23_eq hr24_eq ctx.hcoords_root
            have hSpar_bridge : jobHandleInput (d + 3) P.handleCoords lvs_h (mctx.S_pre_h r) j =
                jobHandleInput (d + 3) (bridgeHandleCoords P P') lvs_h (mctx.S_pre_h r) j :=
              jobHandleInput_congr_pts (d + 3) lvs_h (mctx.S_pre_h r)
                (fun x hx => (bridgeHandleCoords_eq_pre (hS_pre_sub hx)).symm) j
            rw [hSpar_bridge] at hEncLv₀
            refine ⟨hball, hopen, hbij_b, hEncLv₀,
              by rw [hw23_eq]; exact hw23_7,
              by rw [hw23_eq]; exact hp2,
              by rw [hw23_eq]; exact hp3,
              by rw [hw23_eq]; exact hp4,
              by rw [hw23_eq]; exact hp5,
              by rw [hw23_eq]; exact hp6,
              fun hlt => by rw [hw24_eq]; exact hlt_ph hlt,
              fun heq => by
                rcases heq_ph heq with ⟨hp0, hp1, hSp⟩
                exact ⟨by rw [hw24_eq]; exact hp0, by rw [hw24_eq]; exact hp1, hSp⟩⟩
  have hHdrRegs :
      wRead m₀ 0 0 = wRead mem_rt 0 0 ∧
      wRead m₀ 26 13 = (mctx.opH : ℤ) ∧
      wRead m₀ 26 14 = (if mctx.ins then 1 else 0) ∧
      wRead m₀ 26 15 = 0 ∧
      wRead m₀ 26 28 = (mctx.st₀.k : ℤ) := by
    refine ⟨hw_not26 0 (by decide) 0, ?_, ?_, ?_, ?_⟩
    · dsimp only [m₀, s4, s3, s2, s1]; simp; rfl
    · dsimp only [m₀, s4, s3, s2]; simp [ins_val]
    · dsimp only [m₀, s4, s3]; simp
    · dsimp only [m₀]; simp; rfl
  refine ⟨m₀, hex, hpop₀,
    ⟨hHdrRegs.1, hHdrRegs.2.1, hHdrRegs.2.2.1, hHdrRegs.2.2.2.1, hHdrRegs.2.2.2.2,
      Or.inl (hBuildUncut false (fun h => by cases h))⟩,
    fun hPG => ⟨hHdrRegs.1, hHdrRegs.2.1, hHdrRegs.2.2.1, hHdrRegs.2.2.2.1, hHdrRegs.2.2.2.2,
      Or.inl (hBuildUncut true (fun _ => hGood₀ hPG))⟩⟩

/-- Extracts `EncFullChainAndJobs` + `NodesInv` + leaf bound (+ `AllCentersGood` when `gFlag = true`)
from `MidLoopState ctx retH0 gFlag ctx.p.D₀ m_end`. -/
theorem extract_encFullChainAndJobs_of_midLoopState
    (ctx : MidLoopCtx) {retH0 : ℤ} {gFlag : Bool} {m_end : ArithRAMMemory}
    (hSt : MidLoopState ctx retH0 gFlag ctx.p.D₀ m_end) :
    wRead m_end 0 0 = retH0 ∧
    ∃ st_mid : PureServingState ctx.d ctx.n ctx.H ctx.p.L ctx.p.B_scan ctx.P',
      st_mid.NodesInv ∧
      (chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles).card ≤ 4 * ctx.p.L + 2 ∧
      EncFullChainAndJobs ctx.d ctx.n ctx.H ctx.cfg ctx.p m_end ctx.P' st_mid ∧
      (gFlag = true → st_mid.AllCentersGood) := by
  classical
  rcases hSt with ⟨hw00, _, _, _, _, hU | hC⟩
  · -- Uncut at i = ctx.p.D₀: every r < ctx.st₀.k < ctx.p.D₀ is in hDone!
    rcases hU with ⟨_, hGood_sn, hseg, hsave, hLive, hw15, hw60, hSeg0,
      leafS, hl_pos, hl_lt, hw16, hw6l, hSegL, hDisj, hDone, _⟩
    have hAllDone : ∀ r : Fin ctx.st₀.k,
        ∃ oj : Option (ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
            ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u r)),
          ServingOwnedJobInv (ctx.st₀.birthSnap r) (ctx.snAge' r) oj ∧
          (gFlag = true → ∀ g, oj = some g → JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g.lvs) ∧
          EncNodeHeaderAt ctx.cfg ctx.p m_end ctx.P' r.val (ctx.st₀.nodes r)
            (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) oj.isNone ∧
          EncOwnedJobAt ctx.cfg ctx.p m_end ctx.P' ctx.uMap' r.val (ctx.S_post_h r) (ctx.S_post_u r) oj :=
      fun r => hDone r (lt_trans r.isLt ctx.origK_lt_D0)
    choose oj hInv_oj hGood_oj hHdr_oj hEnc_oj using hAllDone
    let st_mid : PureServingState ctx.d ctx.n ctx.H ctx.p.L ctx.p.B_scan ctx.P' :=
      { uMap := ctx.uMap'
        k := ctx.st₀.k
        nodes := ctx.st₀.nodes
        birthSnap := ctx.st₀.birthSnap
        snAge := ctx.snAge'
        trueAge := ctx.trueAge'
        ownedJob := oj }
    have hNodesInv : st_mid.NodesInv := by
      intro r
      rcases ctx.hwf₀.1 r with ⟨hcard_b, huid_b, hpass_b, _, _, _⟩
      refine ⟨hcard_b,
        fun u hu => lt_of_lt_of_le (huid_b u hu) ctx.hle_uid,
        (passesBirthCoreCheck_congr_on _ (ctx.st₀.nodes r)
          (fun u hu => ctx.hag_uid u (huid_b u hu))).mpr hpass_b,
        ctx.htr_le' r,
        ctx.hhas_age' r,
        hInv_oj r⟩
    have hLeafLe : (chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles).card ≤ 4 * ctx.p.L + 2 := by
      have hcard_pre : (chainTerminal ctx.P.handleCoords ctx.st₀.nodes ctx.P.activeHandles).card ≤ 3 * ctx.p.L + 2 :=
        ctx.hwf₀.2
      have hstep_c := cg01_chainTerminal_card_step_le ctx.st₀.nodes ctx.hchg_root ctx.hcoords_root
      have hL1 : 1 ≤ ctx.p.L := by
        have hfl := ctx.hL_floor
        have hd4 : 1 ≤ (ctx.d + 3) ^ 4 := Nat.one_le_pow 4 (ctx.d + 3) (by omega)
        nlinarith
      change (chainTerminal ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles).card ≤ 4 * ctx.p.L + 2
      omega
    have hFull : EncFullChainAndJobs ctx.d ctx.n ctx.H ctx.cfg ctx.p m_end ctx.P' st_mid :=
      ⟨le_of_lt ctx.origK_lt_D0, hseg, hsave, hLive, hw15, hw60, hSeg0,
        leafS, hl_pos, hl_lt, hw16, hw6l, hSegL, hDisj,
        fun r => ⟨hHdr_oj r, hEnc_oj r⟩⟩
    have hGoodMid : gFlag = true → st_mid.AllCentersGood := by
      intro hgT
      refine ⟨fun r => ?_, fun r g hg => hGood_oj r hgT g hg⟩
      exact (isCenterpoint_paraboloid_congr_on _ _
        (fun u hu => ctx.hag_uid u ((ctx.hwf₀.1 r).2.1 u hu))).mpr (hGood_sn hgT r)
    exact ⟨hw00, st_mid, hNodesInv, hLeafLe, hFull, hGoodMid⟩
  · -- Cut case: already carries st_mid!
    rcases hC with ⟨_, st_mid, _, hinv, hleaf, hFull, hGoodMid⟩
    exact ⟨hw00, st_mid, hinv, hleaf, hFull, hGoodMid⟩

/-! ### 3. Turnkey `mkJobTickStageSpec_of_midLoopBody` & Polynomial Tick Cost Bounds -/

noncomputable def mkJobTickStageSpec_of_midLoopBody
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (loopBodyStmt : ArithRAMStmt)
    (C_iter : ℕ)
    (hBoxBody : BoxSafeOuter 28 (p46BoxSize d n p) loopBodyStmt)
    (hPresBody : preservesPoolWords loopBodyStmt = true)
    (hStepBody :
      ∀ (mctx : MidLoopCtx),
        mctx.T_max = 28 →
        mctx.M_box = p46BoxSize d n p →
        mctx.cfg = defaultChainHdrCfg →
        mctx.d = d →
        mctx.n = n →
        ∀ (retH0 : ℤ) (gFlag : Bool) {i : ℕ},
          i < mctx.p.D₀ →
          ∀ {m : ArithRAMMemory},
            m.popDepth 0 = m →
            MidLoopState mctx retH0 gFlag i m →
            RandExecBad (mkStepInput mctx.n mctx.P mctx.op) loopBodyStmt mctx.p.B_hpj m
              (MidLoopState mctx retH0 false (i + 1))
              (fun m' => gFlag = true → MidLoopState mctx retH0 true (i + 1) m')
              (2 * mctx.p.φ_ev) C_iter) :
    JobTickStageSpec cHpj cBase d n t δ p := by
  let M_box := p46BoxSize d n p
  let tickStmt : ArithRAMStmt :=
    .seq (midLoopInitStmt M_box) (.repeatN (.lit (p.D₀ : ℤ)) loopBodyStmt)
  have hT28 : 28 ≤ 28 := le_rfl
  have hBoxSafe : BoxSafeOuter 28 M_box tickStmt :=
    .seq (boxSafe_midLoopInitStmt (by decide)) (.repeatN _ hBoxBody)
  have hPres : preservesPoolWords tickStmt = true :=
    preservesPoolWords_seq (preservesPoolWords_midLoopInitStmt M_box)
      (preservesPoolWords_repeatN _ hPresBody)
  have hp_tick : (p.D₀ : ℝ) * (2 * p.φ_ev) ≤ (((p.D₀ + 2 : ℕ) : ℝ)) * (2 * p.φ_ev) := by
    have hφ0 := hp.hφ0
    have hle : (p.D₀ : ℝ) ≤ (((p.D₀ + 2 : ℕ) : ℝ)) := by exact_mod_cast (by omega : p.D₀ ≤ p.D₀ + 2)
    exact mul_le_mul_of_nonneg_right hle (by linarith)
  refine mkJobTickStageSpec_of_encFullChainAndJobs
    tickStmt 28 M_box (p.D₀ * p.B_hpj) (130 + p.D₀ * C_iter) ((p.D₀ : ℝ) * (2 * p.φ_ev))
    hT28 le_rfl hBoxSafe hPres hp_tick ?_
  intro P op m_pre st₀ mem_rt P' opH uMap' P_good₀ hGood₀ ctx
  classical
  let mctx := ctx.toMidLoopCtx hp hn hT28 (le_rfl : p46BoxSize d n p ≤ M_box)
  let retH0 := wRead mem_rt 0 0
  rcases exec_midLoopInitStmt hp hn hT28 (le_rfl : p46BoxSize d n p ≤ M_box) hGood₀ ctx
    with ⟨m₀, hd_init, hpop₀, hSt₀_f, hSt₀_t⟩
  let SafeInv : ℕ → ArithRAMMemory → Prop := fun i m => MidLoopState mctx retH0 false i m
  let GoodInv : ℕ → ArithRAMMemory → Prop := fun i m => MidLoopState mctx retH0 true i m
  have hstep : ∀ i < p.D₀, ∀ m, m.popDepth 0 = m → SafeInv i m →
      RandExecBad (mkStepInput n P op) loopBodyStmt p.B_hpj m
        (SafeInv (i + 1)) (fun m' => GoodInv i m → GoodInv (i + 1) m')
        (2 * p.φ_ev) C_iter := by
    intro i hi m hpm hs
    by_cases hGi : GoodInv i m
    · have h1 := hStepBody mctx rfl rfl rfl rfl rfl retH0 true hi hpm hGi
      exact h1.mono (fun _ h => h) (fun _ _ hg _ => hg rfl) le_rfl le_rfl
    · have h1 := hStepBody mctx rfl rfl rfl rfl rfl retH0 false hi hpm hs
      exact h1.mono (fun _ h => h) (fun _ _ _ hg_in => False.elim (hGi hg_in)) le_rfl le_rfl
  have hRep := RandExecBad.repeatN_nat
    (.lit (p.D₀ : ℤ)) loopBodyStmt p.D₀ p.B_hpj 10 C_iter
    (by have := hp.hφ0; linarith) SafeInv GoodInv hpop₀ hSt₀_f rfl (by simp [intExprOps]) hstep
  have hComb := RandExecBad.seq_det_left ctx.hpop_rt hpop₀ hd_init hRep
  refine hComb.mono ?_ ?_ le_rfl (by omega)
  · intro m_end hSafe_end
    rcases extract_encFullChainAndJobs_of_midLoopState mctx hSafe_end
      with ⟨_, st_mid, hinv, hleaf, hFull, _⟩
    exact ⟨st_mid, hinv, hleaf, hFull⟩
  · intro m_end _ hg_imp hPG₀
    have hGood_end := hg_imp (hSt₀_t hPG₀)
    rcases extract_encFullChainAndJobs_of_midLoopState mctx hGood_end
      with ⟨_, st_mid, hinv, hleaf, hFull, hGood_mid⟩
    exact ⟨st_mid, hinv, hleaf, hFull, hGood_mid rfl⟩

/-- Pre-proved `D^19 * H^18` polynomial upper bounds on every `CG03` job-tick cost component! -/
theorem P46ParamsValid.jobTick_component_costs_poly_le
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    let C_hpj0 := cHpj * 21 ^ 3
    let C_mb := 105 + cHpj + 4 * cBase
    let P19 := D ^ 19 * H ^ 18
    1 ≤ P19 ∧
    p.D₀ ≤ 24 * P19 ∧
    p.D₀ * (p.K_seg + d + 5) ≤ 72 * P19 ∧
    p.D₀ * freshAllocFiveCost p.D₀ p.NumSlots ≤
      (2 * 196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * P19 ∧
    p.D₀ * hpjFreezeRunInitCost d n p ≤
      (46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
        16 * (C_hpj0 * (C_mb + 1)) + 500) + 28800) * P19 ∧
    p.D₀ * idleAffectedNodeCost d n defaultChainHdrCfg p ≤
      (2 * 196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500) +
       46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
        16 * (C_hpj0 * (C_mb + 1)) + 500) + 43200) * P19 ∧
    p.D₀ * propagateAllJobLevelsCost d p.D₀ p.K_seg ≤ 2350000 * P19 ∧
    p.D₀ * deadlineSuffixSwapCost d p.D₀ ≤ 290000 * P19 ∧
    p.D₀ * (2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5)) ≤
      (625 * (2400 * 16777218 * 3 + 15000)) * P19 := by
  intro D H C_hpj0 C_mb P19
  rcases hp.all_component_costs_poly_le hn
    with ⟨h1_P0, hDH0, hD2H0, _, _, hHpjTot, _, _, hJobTot, hGCTot⟩
  have h1_P : 1 ≤ P19 := h1_P0
  have hD2H : D ^ 2 * H ≤ P19 := hD2H0
  have hD3 : 3 ≤ D := by have h := hp.hD3; rw [hp.hD_eq] at h; exact h
  have hH5 : 5 ≤ H := by have h := hp.hH5; rw [hp.hH_eq] at h; exact h
  have hD1 : 1 ≤ D := by omega
  have hH1 : 1 ≤ H := by omega
  have hD0_eq : p.D₀ = 24 * D ^ 2 * H := by have h := hp.hD0; rw [hp.hH_eq] at h; exact h
  have hK_le : p.K_seg ≤ H := by have h := hp.hK_le_H; rw [hp.hH_eq] at h; exact h
  have hB_le : p.K_seg + d + 5 ≤ 3 * (D * H) := by
    let DH := D * H
    have hH_DH : H ≤ DH := Nat.le_mul_of_pos_left H hD1
    have hD_DH : d + 3 ≤ DH := Nat.le_mul_of_pos_right D hH1
    have h15 : 15 ≤ DH := Nat.mul_le_mul hD3 hH5
    change p.K_seg + d + 5 ≤ 3 * DH
    omega
  -- 1. p.D₀ ≤ 24 * P19
  have hD0_le : p.D₀ ≤ 24 * P19 := by
    rw [hD0_eq, Nat.mul_assoc]
    exact Nat.mul_le_mul_left 24 hD2H
  -- 2. p.D₀ * (p.K_seg + d + 5) ≤ 72 * P19
  have hD3H2_le : D ^ 3 * H ^ 2 ≤ P19 :=
    pow_mul_pow_le_target hD1 hH1 (by decide : 3 ≤ 19) (by decide : 2 ≤ 18)
  have hD0_B : p.D₀ * (p.K_seg + d + 5) ≤ 72 * P19 := by
    calc p.D₀ * (p.K_seg + d + 5)
        ≤ (24 * D ^ 2 * H) * (3 * (D * H)) := by
          rw [hD0_eq]; exact Nat.mul_le_mul_left _ hB_le
      _ = 72 * (D ^ 3 * H ^ 2) := by ring
      _ ≤ 72 * P19 := Nat.mul_le_mul_left 72 hD3H2_le
  -- 3. p.D₀ * freshAllocFiveCost
  let G1 := 40 * p.NumSlots + 300 * (p.D₀ + 1) * (p.D₀ + 1) + 35 * (p.NumSlots + 1) + 500
  have halloc5_le : freshAllocFiveCost p.D₀ p.NumSlots ≤ 5 * G1 := by
    unfold freshAllocFiveCost freshAllocFourCost; dsimp only [G1]; omega
  have hD0_alloc5 : p.D₀ * freshAllocFiveCost p.D₀ p.NumSlots ≤
      (2 * 196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * P19 := by
    calc p.D₀ * freshAllocFiveCost p.D₀ p.NumSlots
        ≤ p.D₀ * (5 * G1) := Nat.mul_le_mul_left _ halloc5_le
      _ = (5 * p.D₀) * G1 := by ring
      _ ≤ (2 * (4 * p.D₀ + 80 * D ^ 2 + 20)) * G1 :=
          Nat.mul_le_mul_right G1 (by omega)
      _ = 2 * ((4 * p.D₀ + 80 * D ^ 2 + 20) * G1) := by ring
      _ ≤ 2 * ((196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * P19) :=
          Nat.mul_le_mul_left 2 hGCTot
      _ = (2 * 196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * P19 := by ring
  -- 4. p.D₀ * hpjFreezeRunInitCost
  have hfr_extra : (100 * (p.K_seg + 1) + 180 * (d + 1) + 150) + (120 * (d + 1) + 400) + 50 ≤
      400 * (p.K_seg + d + 5) := by omega
  have hD0_hpj : p.D₀ * hpjCallCost d n p ≤
      (46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
        16 * (C_hpj0 * (C_mb + 1)) + 500)) * P19 :=
    le_trans (Nat.mul_le_mul_right _ (by omega : p.D₀ ≤ p.D₀ + 20 * D ^ 2 + 2)) hHpjTot
  have hD0_fr : p.D₀ * hpjFreezeRunInitCost d n p ≤
      (46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
        16 * (C_hpj0 * (C_mb + 1)) + 500) + 28800) * P19 := by
    have h1 : p.D₀ * hpjFreezeRunInitCost d n p ≤
        p.D₀ * hpjCallCost d n p + 400 * (p.D₀ * (p.K_seg + d + 5)) := by
      unfold hpjFreezeRunInitCost
      have hle := Nat.mul_le_mul_left p.D₀ (Nat.add_le_add_left hfr_extra (hpjCallCost d n p))
      have heq1 : (hpjCallCost d n p + (100 * (p.K_seg + 1) + 180 * (d + 1) + 150) +
          (120 * (d + 1) + 400) + 50) =
          hpjCallCost d n p + ((100 * (p.K_seg + 1) + 180 * (d + 1) + 150) +
          (120 * (d + 1) + 400) + 50) := by omega
      rw [heq1]; linarith
    calc p.D₀ * hpjFreezeRunInitCost d n p
        ≤ p.D₀ * hpjCallCost d n p + 400 * (p.D₀ * (p.K_seg + d + 5)) := h1
      _ ≤ (46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
            16 * (C_hpj0 * (C_mb + 1)) + 500)) * P19 + 400 * (72 * P19) :=
          Nat.add_le_add hD0_hpj (Nat.mul_le_mul_left 400 hD0_B)
      _ = (46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
            16 * (C_hpj0 * (C_mb + 1)) + 500) + 28800) * P19 := by ring
  -- 5. p.D₀ * idleAffectedNodeCost
  have hD0_idle : p.D₀ * idleAffectedNodeCost d n defaultChainHdrCfg p ≤
      (2 * 196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500) +
       46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
        16 * (C_hpj0 * (C_mb + 1)) + 500) + 43200) * P19 := by
    have htail : 2 * (p.K_seg + 100) + 600 ≤ 200 * (p.K_seg + d + 5) := by omega
    have h1 : p.D₀ * idleAffectedNodeCost d n defaultChainHdrCfg p ≤
        p.D₀ * freshAllocFiveCost p.D₀ p.NumSlots +
        p.D₀ * hpjFreezeRunInitCost d n p +
        200 * (p.D₀ * (p.K_seg + d + 5)) := by
      unfold idleAffectedNodeCost
      dsimp only
      have := Nat.mul_le_mul_left p.D₀ htail
      linarith
    calc p.D₀ * idleAffectedNodeCost d n defaultChainHdrCfg p
        ≤ p.D₀ * freshAllocFiveCost p.D₀ p.NumSlots +
          p.D₀ * hpjFreezeRunInitCost d n p +
          200 * (p.D₀ * (p.K_seg + d + 5)) := h1
      _ ≤ (2 * 196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * P19 +
          (46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
            16 * (C_hpj0 * (C_mb + 1)) + 500) + 28800) * P19 +
          200 * (72 * P19) :=
          Nat.add_le_add (Nat.add_le_add hD0_alloc5 hD0_fr) (Nat.mul_le_mul_left 200 hD0_B)
      _ = _ := by ring
  -- 6. p.D₀ * propagateAllJobLevelsCost d p.D₀ p.K_seg ≤ 2350000 * P19
  have hD5H3_le : D ^ 5 * H ^ 3 ≤ P19 :=
    pow_mul_pow_le_target hD1 hH1 (by decide : 5 ≤ 19) (by decide : 3 ≤ 18)
  have hprop_inner : (1100 * (p.K_seg + 1) + 150 * (d + 1) + 800) + 100 ≤ 1300 * (p.K_seg + d + 5) := by omega
  have hD0_prop : p.D₀ * propagateAllJobLevelsCost d p.D₀ p.K_seg ≤ 2350000 * P19 := by
    unfold propagateAllJobLevelsCost
    have h1 : p.D₀ * (p.D₀ * ((1100 * (p.K_seg + 1) + 150 * (d + 1) + 800) + 100) + 150) ≤
        1300 * (p.D₀ * (p.D₀ * (p.K_seg + d + 5))) + 150 * p.D₀ := by
      have hm := Nat.mul_le_mul_left p.D₀ (Nat.mul_le_mul_left p.D₀ hprop_inner)
      linarith
    have h2 : p.D₀ * (p.D₀ * (p.K_seg + d + 5)) ≤ 1728 * P19 := by
      calc p.D₀ * (p.D₀ * (p.K_seg + d + 5))
          ≤ (24 * D ^ 2 * H) * ((24 * D ^ 2 * H) * (3 * (D * H))) := by
            rw [hD0_eq]
            exact Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ hB_le)
        _ = 1728 * (D ^ 5 * H ^ 3) := by ring
        _ ≤ 1728 * P19 := Nat.mul_le_mul_left 1728 hD5H3_le
    calc p.D₀ * (p.D₀ * ((1100 * (p.K_seg + 1) + 150 * (d + 1) + 800) + 100) + 150)
        ≤ 1300 * (p.D₀ * (p.D₀ * (p.K_seg + d + 5))) + 150 * p.D₀ := h1
      _ ≤ 1300 * (1728 * P19) + 150 * (24 * P19) :=
          Nat.add_le_add (Nat.mul_le_mul_left 1300 h2) (Nat.mul_le_mul_left 150 hD0_le)
      _ = 2250000 * P19 := by ring
      _ ≤ 2350000 * P19 := Nat.mul_le_mul_right P19 (by omega)
  -- 7. p.D₀ * deadlineSuffixSwapCost d p.D₀ ≤ 290000 * P19
  have hswap_inner : 90 * (d + 1) + 400 ≤ 160 * (p.K_seg + d + 5) := by omega
  have hD0_swap : p.D₀ * deadlineSuffixSwapCost d p.D₀ ≤ 290000 * P19 := by
    unfold deadlineSuffixSwapCost
    have h1 : p.D₀ * (p.D₀ * (90 * (d + 1) + 400) + 200) ≤
        160 * (p.D₀ * (p.D₀ * (p.K_seg + d + 5))) + 200 * p.D₀ := by
      have hm := Nat.mul_le_mul_left p.D₀ (Nat.mul_le_mul_left p.D₀ hswap_inner)
      linarith
    have h2 : p.D₀ * (p.D₀ * (p.K_seg + d + 5)) ≤ 1728 * P19 := by
      calc p.D₀ * (p.D₀ * (p.K_seg + d + 5))
          ≤ (24 * D ^ 2 * H) * ((24 * D ^ 2 * H) * (3 * (D * H))) := by
            rw [hD0_eq]
            exact Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ hB_le)
        _ = 1728 * (D ^ 5 * H ^ 3) := by ring
        _ ≤ 1728 * P19 := Nat.mul_le_mul_left 1728 hD5H3_le
    calc p.D₀ * (p.D₀ * (90 * (d + 1) + 400) + 200)
        ≤ 160 * (p.D₀ * (p.D₀ * (p.K_seg + d + 5))) + 200 * p.D₀ := h1
      _ ≤ 160 * (1728 * P19) + 200 * (24 * P19) :=
          Nat.add_le_add (Nat.mul_le_mul_left 160 h2) (Nat.mul_le_mul_left 200 hD0_le)
      _ = 281280 * P19 := by ring
      _ ≤ 290000 * P19 := Nat.mul_le_mul_right P19 (by omega)
  -- 8. p.D₀ * batch-scan
  let BscanTerm := 2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5)
  have hJobTot' : ((p.D₀ + 2) * (p.D₀ + 2)) * BscanTerm ≤
      (625 * (2400 * 16777218 * 3 + 15000)) * P19 := hJobTot
  have hD0_scan : p.D₀ * BscanTerm ≤
      (625 * (2400 * 16777218 * 3 + 15000)) * P19 := by
    have hle : p.D₀ ≤ (p.D₀ + 2) * (p.D₀ + 2) := le_trans (Nat.le_add_right p.D₀ 2) (Nat.le_mul_self (p.D₀ + 2))
    exact le_trans (Nat.mul_le_mul_right BscanTerm hle) hJobTot'
  exact ⟨h1_P, hD0_le, hD0_B, hD0_alloc5, hD0_fr, hD0_idle, hD0_prop, hD0_swap, hD0_scan⟩

end UL.Proof_lem_7_2_RacerP46
