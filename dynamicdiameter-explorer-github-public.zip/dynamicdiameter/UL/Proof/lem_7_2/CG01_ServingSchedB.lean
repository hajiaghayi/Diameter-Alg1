import UL.Proof.lem_7_2.CG01_ServingSchedA

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 4. Pure Serving-Chain State, Job Start (`⌊αM/64⌋`), Per-Step Tick, Deadline Install, & Sync Split -/

/-- Record-level pool cast of `ActiveJobGhost` across `heq : S₁ = S₂` keeping all data fields
definitionally identical (`rfl`)! -/
def ActiveJobGhost.castPool {d n D L B_scan nextUid : ℕ}
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {S₁ S₂ : Finset ℕ}
    (g : ActiveJobGhost d n D L B_scan nextUid ghostCoords S₁)
    (heq : S₁ = S₂) :
    ActiveJobGhost d n D L B_scan nextUid ghostCoords S₂ :=
  { H_job := g.H_job
    t_cur := g.t_cur
    closed := g.closed
    lvs := g.lvs
    openRem := g.openRem
    ph_cur := g.ph_cur
    scan_cur := g.scan_cur
    Spar_last_h := g.Spar_last_h
    hH_pos := g.hH_pos
    ht_le := g.ht_le
    hlvs_pos := g.hlvs_pos
    hph_le := g.hph_le
    hprev_ready := g.hprev_ready
    hlast_ready := g.hlast_ready
    S_root := g.S_root
    ev := g.ev
    job_hist := g.job_hist
    hS_cap := g.hS_cap
    hS_uid := g.hS_uid
    hS_last := g.hS_last.trans heq
    hm0 := g.hm0
    hH_eq := g.hH_eq
    hev_tick := g.hev_tick
    hev_valid := g.hev_valid
    hinit := g.hinit
    hstep := g.hstep
    hrem_eq := g.hrem_eq
    hcur_job := heq ▸ g.hcur_job
    hlvs_inv := fun j hj => by
      subst heq
      exact g.hlvs_inv j hj }

/-- Pure serving-chain state over `k` serving nodes, `≤ k` background replacement jobs
(`ownedJob r`), monotone ghost UID map `uMap`, and terminal leaf `chainTerminal`. -/
structure PureServingState (d n H L B_scan : ℕ) (P : DynamicPointSet d) : Type where
  uMap : GhostUidMap d P
  k : ℕ
  nodes : Fin k → ChainNode d
  birthSnap : Fin k → Finset ℕ
  snAge : Fin k → ℕ
  trueAge : Fin k → ℕ
  ownedJob : (r : Fin k) → Option
    (ActiveJobGhost d n (d + 3) L B_scan uMap.nextUid uMap.ghostCoords
      (chainInput uMap.ghostCoords nodes uMap.ActiveUids r.castSucc))

/-- Per-node job invariant helper (avoids duplicate `match` auxiliary definitions across lemmas). -/
def ServingOwnedJobInv {d n D L B_scan nextUid : ℕ}
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {S_r : Finset ℕ} (P₀ : Finset ℕ) (age : ℕ) :
    Option (ActiveJobGhost d n D L B_scan nextUid ghostCoords S_r) → Prop
  | none => age < jobStartAge (1 / (4 * (D : ℝ) ^ 2)) P₀.card
  | some g =>
      g.t_cur < g.H_job ∧
      age = jobStartAge (1 / (4 * (D : ℝ) ^ 2)) P₀.card + g.t_cur ∧
      (g.S_root 0).card ≤ P₀.card + jobStartAge (1 / (4 * (D : ℝ) ^ 2)) P₀.card

lemma servingOwnedJobInv_castPool {d n D L B_scan nextUid : ℕ}
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {S₁ S₂ : Finset ℕ} (heq : S₁ = S₂)
    (P₀ : Finset ℕ) (age : ℕ)
    (oj : Option (ActiveJobGhost d n D L B_scan nextUid ghostCoords S₁)) :
    ServingOwnedJobInv P₀ age (oj.map (fun g => g.castPool heq)) ↔
      ServingOwnedJobInv P₀ age oj := by
  cases oj <;> rfl

/-- Per-serving-node structural and late-opening schedule invariants (independent of leaf size). -/
def PureServingState.NodesInv {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P) : Prop :=
  ∀ r : Fin st.k,
    let α : ℝ := 1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)
    2 * L + 1 < (st.birthSnap r).card ∧
    (∀ u ∈ st.birthSnap r, u < st.uMap.nextUid) ∧
    PassesBirthCoreCheck α st.uMap.ghostCoords (st.nodes r) (st.birthSnap r) ∧
    st.trueAge r ≤ st.snAge r ∧
    HasNodeAge (st.birthSnap r)
      (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc) (st.trueAge r) ∧
    ServingOwnedJobInv (st.birthSnap r) (st.snAge r) (st.ownedJob r)

/-- Full unconditional safety invariant: `NodesInv` plus terminal leaf size `≤ 3 * L + 2`. -/
def PureServingState.WellFormed {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P) : Prop :=
  st.NodesInv ∧
  (chainTerminal P.handleCoords st.nodes P.activeHandles).card ≤ 3 * L + 2

/-- Monte Carlo good-event invariant: every serving node AND every opened background job level
was built from a valid `α`-centerpoint of its lifted birth snapshot. -/
def PureServingState.AllCentersGood {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P) : Prop :=
  (∀ r : Fin st.k,
    IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
      (paraboloidLiftSet (fun i : ↥(st.birthSnap r) => st.uMap.ghostCoords i.1))
      (liftedPoint (st.nodes r).o ((st.nodes r).V + ‖(st.nodes r).o‖ ^ 2))) ∧
  (∀ (r : Fin st.k) (g : ActiveJobGhost d n (d + 3) L B_scan st.uMap.nextUid st.uMap.ghostCoords
      (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc)),
    st.ownedJob r = some g →
      JobLevelsCenterGood (d + 3) st.uMap.ghostCoords g.lvs)

/-- Empty initial `PureServingState` on `DynamicPointSet.empty d`. -/
def PureServingState.empty (d n H L B_scan : ℕ) :
    PureServingState d n H L B_scan (DynamicPointSet.empty d) :=
  { uMap := GhostUidMap.empty d
    k := 0
    nodes := Fin.elim0
    birthSnap := Fin.elim0
    snAge := Fin.elim0
    trueAge := Fin.elim0
    ownedJob := fun r => Fin.elim0 r }

lemma PureServingState.empty_wellFormed (d n H L B_scan : ℕ) :
    (PureServingState.empty d n H L B_scan).WellFormed := by
  dsimp [PureServingState.empty, PureServingState.WellFormed, PureServingState.NodesInv]
  refine ⟨fun r => Fin.elim0 r, ?_⟩
  rw [cg01_chainTerminal_eq, cg01_chainInput_zero]
  simp [DynamicPointSet.empty]

lemma PureServingState.empty_allCentersGood (d n H L B_scan : ℕ) :
    (PureServingState.empty d n H L B_scan).AllCentersGood := by
  dsimp [PureServingState.empty, PureServingState.AllCentersGood]
  exact ⟨fun r => Fin.elim0 r, fun r => Fin.elim0 r⟩

/-- Every serving node satisfying `NodesInv` has `(snAge r : ℝ) ≤ α * (birthSnap r).card / 16`
and `(trueAge r : ℝ) ≤ α * (birthSnap r).card / 16`. -/
lemma PureServingState.age_le_alpha_sixteen {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (hinv : st.NodesInv) (r : Fin st.k) :
    let α : ℝ := 1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)
    (st.snAge r : ℝ) ≤ α * ((st.birthSnap r).card : ℝ) / 16 ∧
    (st.trueAge r : ℝ) ≤ α * ((st.birthSnap r).card : ℝ) / 16 := by
  intro α
  have hD : 3 ≤ d + 3 := by omega
  rcases hinv r with ⟨_, _, _, htr_le, _, hjob⟩
  have hsn : (st.snAge r : ℝ) ≤ α * ((st.birthSnap r).card : ℝ) / 16 := by
    cases hj : st.ownedJob r with
    | none =>
        rw [hj] at hjob
        exact age_le_alpha_sixteen_of_le_start hD (le_of_lt hjob)
    | some g =>
        rw [hj] at hjob
        rcases hjob with ⟨ht_lt, hage_eq, hm0_le⟩
        rcases job_deadline_and_serving_age_le hD hm0_le with ⟨hdl_le, hage_bound⟩
        have ht_le_div : g.t_cur ≤ (st.birthSnap r).card / (8192 * (d + 3) ^ 2) := by
          have hHeq := g.hH_eq
          omega
        rw [hage_eq]
        exact hage_bound g.t_cur ht_le_div
  have htr : (st.trueAge r : ℝ) ≤ (st.snAge r : ℝ) := by exact_mod_cast htr_le
  exact ⟨hsn, htr.trans hsn⟩

/-- Every `PureServingState` satisfying `NodesInv` on `P.WellFormed n` (`5 ≤ H`, `n < 2 ^ H`)
automatically has `st.k < 24 * (d + 3) ^ 2 * H = D₀`, and every active background job has
`g.lvs.length < 24 * (d + 3) ^ 2 * H = D₀`! -/
theorem PureServingState.chainLen_and_jobLen_lt {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (hP : P.WellFormed n) (hH : 5 ≤ H) (hn2 : n < 2 ^ H)
    (hinv : st.NodesInv) :
    st.k < 24 * (d + 3) ^ 2 * H ∧
    ∀ (r : Fin st.k) g, st.ownedJob r = some g → g.lvs.length < 24 * (d + 3) ^ 2 * H := by
  have hcap_uid : st.uMap.ActiveUids.card ≤ n := by
    rw [← st.uMap.mapSet_activeHandles, (st.uMap.mapSet_bij (Finset.Subset.refl _)).1,
        activeHandles_card_eq_activeIds_card hP]
    exact hP.1
  refine ⟨?_, fun _ g _ => g.lvs_length_lt hH hn2⟩
  refine unconditional_chain_len_lt hH hn2 st.uMap.ghostCoords st.uMap.ActiveUids hcap_uid
    st.nodes st.birthSnap st.trueAge (fun i => ?_)
  rcases hinv i with ⟨hlarge, _, hpass, _, hage, _⟩
  exact ⟨by omega, hpass, hage, (st.age_le_alpha_sixteen hinv i).2⟩

/-- Post-tick status of a single serving node `r` after routing an external update and advancing
or starting its replacement job. -/
inductive PostTickNodeStatus (d n D L B_scan nextUid' : ℕ)
    (ghostCoords' : ℕ → EuclideanSpace ℝ (Fin d))
    (P₀ S_r' : Finset ℕ) (snAge' : ℕ) : Type
  | keepNone
      (hwait : snAge' < jobStartAge (1 / (4 * (D : ℝ) ^ 2)) P₀.card)
  | keepJob
      (g' : ActiveJobGhost d n D L B_scan nextUid' ghostCoords' S_r')
      (ht_lt : g'.t_cur < g'.H_job)
      (hage_eq : snAge' = jobStartAge (1 / (4 * (D : ℝ) ^ 2)) P₀.card + g'.t_cur)
      (hm0_le : (g'.S_root 0).card ≤ P₀.card + jobStartAge (1 / (4 * (D : ℝ) ^ 2)) P₀.card)
  | truncateSmall
      (hsmall : S_r'.card ≤ 4 * L)
  | installDeadline
      (g' : ActiveJobGhost d n D L B_scan nextUid' ghostCoords' S_r')
      (hdone : g'.t_cur = g'.H_job)

def PostTickNodeStatus.isCutReady {d n D L B_scan nextUid' : ℕ}
    {ghostCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {P₀ S_r' : Finset ℕ} {snAge' : ℕ} :
    PostTickNodeStatus d n D L B_scan nextUid' ghostCoords' P₀ S_r' snAge' → Bool
  | .keepNone _ => false
  | .keepJob _ _ _ _ => false
  | .truncateSmall _ => true
  | .installDeadline _ _ => true

def PostTickNodeStatus.CenterGood {d n D L B_scan nextUid' : ℕ}
    {ghostCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {P₀ S_r' : Finset ℕ} {snAge' : ℕ} :
    PostTickNodeStatus d n D L B_scan nextUid' ghostCoords' P₀ S_r' snAge' → Prop
  | .keepNone _ => True
  | .keepJob g' _ _ _ => JobLevelsCenterGood D ghostCoords' g'.lvs
  | .truncateSmall _ => True
  | .installDeadline g' _ => JobLevelsCenterGood D ghostCoords' g'.lvs

/-- Unaffected serving node (`aff = false`): lifts `ownedJob r` across `uMap → uMap'`. -/
noncomputable def stepOneServingNodeUnaffected {d n H L B_scan : ℕ}
    {P P' : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (hinv : st.NodesInv)
    (uMap' : GhostUidMap d P')
    (hle_uid : st.uMap.nextUid ≤ uMap'.nextUid)
    (hag_uid : ∀ u < st.uMap.nextUid, uMap'.ghostCoords u = st.uMap.ghostCoords u)
    (r : Fin st.k)
    (hS_eq : chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc =
      chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc) :
    PostTickNodeStatus d n (d + 3) L B_scan uMap'.nextUid uMap'.ghostCoords
      (st.birthSnap r)
      (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc)
      (st.snAge r) :=
  match hj : st.ownedJob r with
  | none =>
      have hwait : st.snAge r < jobStartAge (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) (st.birthSnap r).card := by
        have hi := (hinv r).2.2.2.2.2
        rwa [hj] at hi
      .keepNone hwait
  | some g =>
      have hi := (hinv r).2.2.2.2.2
      have hjob : g.t_cur < g.H_job ∧
          st.snAge r = jobStartAge (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) (st.birthSnap r).card + g.t_cur ∧
          (g.S_root 0).card ≤ (st.birthSnap r).card +
            jobStartAge (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) (st.birthSnap r).card := by
        rwa [hj] at hi
      let g_lift := (g.liftCoords hle_uid hag_uid).castPool hS_eq.symm
      .keepJob g_lift hjob.1 hjob.2.1 hjob.2.2

/-- Affected idle serving node (`ownedJob r = none`, `aff = true`, `snAge' = snAge r + 1`):
either keeps waiting, marks `.truncateSmall`, or starts `ActiveJobGhost.start` at `⌊αM/64⌋`! -/
noncomputable def stepOneServingNodeIdleAffected {d n H L B_scan : ℕ}
    {P P' : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (hL_floor : 68719476736 * (d + 3) ^ 4 ≤ L)
    (hP' : P'.WellFormed n)
    (hinv : st.NodesInv)
    (uMap' : GhostUidMap d P')
    (r : Fin st.k)
    (hnone : st.ownedJob r = none)
    (hchg_r : IsInputChange
      (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc)
      (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc))
    (startChoice :
      4 * L < (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc).card →
        (bUid : ℕ) ×' (bUid ∈ chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc) ×'
        SampledCenterResult d ×'
        (Spar_0_h : Finset ℕ) ×'
        (Spar_0_h.card = (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc).card)) :
    PostTickNodeStatus d n (d + 3) L B_scan uMap'.nextUid uMap'.ghostCoords
      (st.birthSnap r)
      (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc)
      (st.snAge r + 1) := by
  have hD : 3 ≤ d + 3 := by omega
  rcases hinv r with ⟨_, _, _, htr_le, hage_old, hjob⟩
  rw [hnone] at hjob
  change st.snAge r < jobStartAge (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) (st.birthSnap r).card at hjob
  by_cases hlt_st : st.snAge r + 1 < jobStartAge (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) (st.birthSnap r).card
  · exact .keepNone hlt_st
  · have heq_st : st.snAge r + 1 = jobStartAge (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) (st.birthSnap r).card := by
      omega
    by_cases hlarge : 4 * L < (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc).card
    · rcases startChoice hlarge with ⟨bUid, hb, res, Spar_0_h, hcard_eq⟩
      have hsub_h : chainInput P'.handleCoords st.nodes P'.activeHandles r.castSucc ⊆ P'.activeHandles :=
        cg01_chainInput_subset P'.handleCoords st.nodes P'.activeHandles r.castSucc
      have hmap_eq : uMap'.mapSet (chainInput P'.handleCoords st.nodes P'.activeHandles r.castSucc) =
          chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc :=
        uMap'.mapSet_chainInput st.nodes r.castSucc
      have hbij := uMap'.mapSet_bij hsub_h
      have hcap' : (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc).card ≤ n := by
        rw [← hmap_eq, hbij.1]
        exact (Finset.card_le_card hsub_h).trans
          ((activeHandles_card_eq_activeIds_card hP').trans_le hP'.1)
      have huid' : ∀ u ∈ chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc,
          u < uMap'.nextUid := hmap_eq ▸ hbij.2.1
      let g₀ := ActiveJobGhost.start (ghostCoords := uMap'.ghostCoords) (B_scan := B_scan)
        res hD hL_floor hcap' huid' hlarge hb hcard_eq
      have hage_new : HasNodeAge (st.birthSnap r)
          (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc) (st.trueAge r + 1) :=
        hasNodeAge_step hage_old hchg_r
      have hm0_le : (g₀.S_root 0).card ≤
          (st.birthSnap r).card + jobStartAge (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) (st.birthSnap r).card := by
        have hS0 : g₀.S_root 0 = chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc := rfl
        rw [hS0]
        have hc := (hasNodeAge_card_bounds hage_new).1
        omega
      have ht0 : g₀.t_cur = 0 := rfl
      exact .keepJob g₀ g₀.hH_pos (by rw [ht0, Nat.add_zero]; exact heq_st) hm0_le
    · exact .truncateSmall (by omega)

/-- Affected active-job serving node (`ownedJob r = some g`, `aff = true`):
lifts `g` to `uMap'` and advances via `ActiveJobGhost.stepTick`, returning `.keepJob` before
deadline and `.installDeadline` at `g'.t_cur = g'.H_job`! -/
noncomputable def stepOneServingNodeJobAffected {d n H L B_scan : ℕ}
    {P P' : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (hP' : P'.WellFormed n)
    (hinv : st.NodesInv)
    (uMap' : GhostUidMap d P')
    (hle_uid : st.uMap.nextUid ≤ uMap'.nextUid)
    (hag_uid : ∀ u < st.uMap.nextUid, uMap'.ghostCoords u = st.uMap.ghostCoords u)
    (r : Fin st.k)
    (g : ActiveJobGhost d n (d + 3) L B_scan st.uMap.nextUid st.uMap.ghostCoords
      (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc))
    (hsome : st.ownedJob r = some g)
    (ev_step : PoolUpdateEvent ℕ)
    (hev_ck : ev_step.isClockTick = true)
    (hev_v : IsValidPoolUpdateEvent
      (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc)
      (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc) ev_step)
    {ph' scan' : ℕ} {Spar_last_h' : Finset ℕ}
    (hph'_le : ph' ≤ 2)
    (hpar_1 : Spar_last_h'.card ≤ g.Spar_last_h.card + 1 ∧
      ∀ c : ℕ, (Spar_last_h'.filter (fun x => c ≤ x)).card ≤
               (g.Spar_last_h.filter (fun x => c ≤ x)).card + 1)
    (hbuild_1 :
      let m_last := (g.lvs[g.lvs.length - 1]'(Nat.sub_lt g.hlvs_pos Nat.one_pos)).birthSnapshot.card
      (g.ph_cur = 0 →
        (g.scan_cur + (B_scan + 1) < m_last → ph' = 0 ∧ scan' = g.scan_cur + (B_scan + 1)) ∧
        (m_last ≤ g.scan_cur + (B_scan + 1) → ph' = 1 ∧ scan' = 0)) ∧
      (g.ph_cur = 1 →
        ph' = 2 ∨
        (ph' = 1 ∧
          (Spar_last_h'.filter (fun x => scan' ≤ x)).card + B_scan ≤
            (g.Spar_last_h.filter (fun x => g.scan_cur ≤ x)).card)) ∧
      (g.ph_cur = 2 → ph' = 2))
    (act : JobTickEndAction d (d + 3) L uMap'.ghostCoords (g.H_job - (g.t_cur + 1)) g.closed ph'
      (prefixResidual uMap'.ghostCoords g.lvs
        (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc))) :
    PostTickNodeStatus d n (d + 3) L B_scan uMap'.nextUid uMap'.ghostCoords
      (st.birthSnap r)
      (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc)
      (st.snAge r + 1) := by
  have hD : 3 ≤ d + 3 := by omega
  rcases hinv r with ⟨_, _, _, _, _, hjob⟩
  rw [hsome] at hjob
  rcases hjob with ⟨ht_lt, hage_eq, hm0_le⟩
  have hsub_h : chainInput P'.handleCoords st.nodes P'.activeHandles r.castSucc ⊆ P'.activeHandles :=
    cg01_chainInput_subset P'.handleCoords st.nodes P'.activeHandles r.castSucc
  have hmap_eq : uMap'.mapSet (chainInput P'.handleCoords st.nodes P'.activeHandles r.castSucc) =
      chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc :=
    uMap'.mapSet_chainInput st.nodes r.castSucc
  have hbij := uMap'.mapSet_bij hsub_h
  have hcap' : (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc).card ≤ n := by
    rw [← hmap_eq, hbij.1]
    exact (Finset.card_le_card hsub_h).trans
      ((activeHandles_card_eq_activeIds_card hP').trans_le hP'.1)
  have huid' : ∀ u ∈ chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc,
      u < uMap'.nextUid := hmap_eq ▸ hbij.2.1
  let g_lift := g.liftCoords hle_uid hag_uid
  let g' := g_lift.stepTick hD ht_lt ev_step hev_ck hev_v hcap' huid' hph'_le hpar_1 hbuild_1 act
  have ht'_eq : g'.t_cur = g.t_cur + 1 := rfl
  have hH'_eq : g'.H_job = g.H_job := rfl
  by_cases hlt_new : g'.t_cur < g'.H_job
  · have hS0_eq : g'.S_root 0 = g.S_root 0 := by
      dsimp only [g', g_lift, ActiveJobGhost.stepTick, ActiveJobGhost.liftCoords]
      exact Function.update_of_ne (by omega) _ _
    exact .keepJob g' hlt_new
      (by rw [ht'_eq, hage_eq]; omega)
      (by rw [hS0_eq]; exact hm0_le)
  · have hdone : g'.t_cur = g'.H_job := by rw [ht'_eq, hH'_eq] at hlt_new ⊢; omega
    exact .installDeadline g' hdone

/-- Deadline install / small-input truncation step: picks the smallest ready index `r_cut` (if any)
and produces `st_mid : PureServingState d n H L B_scan P'` satisfying `st_mid.NodesInv`,
`(chainTerminal ...).card ≤ 4 * L + 2`, and preserving `AllCentersGood`! -/
theorem installOrKeepAfterTick
    (h_lem_C_2 : S_lem_C_2)
    {d n H K₀ L B_scan : ℕ}
    {P P' : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (hwf : st.WellFormed)
    (hL_floor : 68719476736 * (d + 3) ^ 4 ≤ L)
    (hL_eq10 : SatisfiesLeafCutoffEq10 d n (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) 0 K₀ L)
    (hB_floor : 16777216 * (d + 3) ^ 4 ≤ B_scan)
    (uMap' : GhostUidMap d P')
    (hle_uid : st.uMap.nextUid ≤ uMap'.nextUid)
    (hag_uid : ∀ u < st.uMap.nextUid, uMap'.ghostCoords u = st.uMap.ghostCoords u)
    (hchg_root : IsInputChange P.activeHandles P'.activeHandles)
    (hcoords_root : ∀ h : ℕ, h ∈ P.activeHandles → h ∈ P'.activeHandles →
      P'.handleCoords h = P.handleCoords h)
    (snAge' : Fin st.k → ℕ)
    (trueAge' : Fin st.k → ℕ)
    (htr_le' : ∀ r : Fin st.k, trueAge' r ≤ snAge' r)
    (hhas_age' : ∀ r : Fin st.k,
      HasNodeAge (st.birthSnap r)
        (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc) (trueAge' r))
    (status : (r : Fin st.k) →
      PostTickNodeStatus d n (d + 3) L B_scan uMap'.nextUid uMap'.ghostCoords
        (st.birthSnap r)
        (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc)
        (snAge' r)) :
    ∃ st_mid : PureServingState d n H L B_scan P',
      st_mid.uMap = uMap' ∧
      st_mid.NodesInv ∧
      (chainTerminal P'.handleCoords st_mid.nodes P'.activeHandles).card ≤ 4 * L + 2 ∧
      ((∀ r : Fin st.k,
          IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
            (paraboloidLiftSet (fun i : ↥(st.birthSnap r) => st.uMap.ghostCoords i.1))
            (liftedPoint (st.nodes r).o ((st.nodes r).V + ‖(st.nodes r).o‖ ^ 2))) →
       (∀ r : Fin st.k, (status r).CenterGood) →
       st_mid.AllCentersGood) := by
  classical
  have hD : 3 ≤ d + 3 := by omega
  have hD4_pos : 1 ≤ (d + 3) ^ 4 := Nat.one_le_pow 4 (d + 3) (by omega)
  have hL1 : 1 ≤ L := by omega
  rcases hwf with ⟨hinv, hleaf_pre⟩
  have h_not_ready_job : ∀ (i : Fin st.k), (status i).isCutReady = false →
      ∃ oj : Option (ActiveJobGhost d n (d + 3) L B_scan uMap'.nextUid uMap'.ghostCoords
          (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids i.castSucc)),
        ServingOwnedJobInv (st.birthSnap i) (snAge' i) oj ∧
        ((status i).CenterGood →
          ∀ g, oj = some g → JobLevelsCenterGood (d + 3) uMap'.ghostCoords g.lvs) := by
    intro i hnr
    cases hs : status i with
    | keepNone hwait =>
        exact ⟨none, hwait, fun _ _ h => by cases h⟩
    | keepJob g' ht_lt hage_eq hm0_le =>
        refine ⟨some g', ⟨ht_lt, hage_eq, hm0_le⟩, fun hcg g hg => ?_⟩
        injection hg with hgeq; subst hgeq
        exact hcg
    | truncateSmall _ => rw [hs] at hnr; cases hnr
    | installDeadline _ _ => rw [hs] at hnr; cases hnr
  have hbirth_uid_lt : ∀ i : Fin st.k, ∀ u ∈ st.birthSnap i, u < uMap'.nextUid :=
    fun i u hu => lt_of_lt_of_le ((hinv i).2.1 u hu) hle_uid
  have hbirth_pass' : ∀ i : Fin st.k,
      PassesBirthCoreCheck (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
        uMap'.ghostCoords (st.nodes i) (st.birthSnap i) := by
    intro i
    exact (passesBirthCoreCheck_congr_on _ _
      (fun u hu => hag_uid u ((hinv i).2.1 u hu))).mpr (hinv i).2.2.1
  have hbirth_cp' :
      (∀ r : Fin st.k,
        IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
          (paraboloidLiftSet (fun x : ↥(st.birthSnap r) => st.uMap.ghostCoords x.1))
          (liftedPoint (st.nodes r).o ((st.nodes r).V + ‖(st.nodes r).o‖ ^ 2))) →
      ∀ i : Fin st.k,
        IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
          (paraboloidLiftSet (fun x : ↥(st.birthSnap i) => uMap'.ghostCoords x.1))
          (liftedPoint (st.nodes i).o ((st.nodes i).V + ‖(st.nodes i).o‖ ^ 2)) := by
    intro hcp_old i
    exact (isCenterpoint_paraboloid_congr_on _ _
      (fun u hu => hag_uid u ((hinv i).2.1 u hu))).mpr (hcp_old i)
  by_cases hex : ∃ idx : ℕ, ∃ h : idx < st.k, (status ⟨idx, h⟩).isCutReady = true
  · let r_cut := Nat.find hex
    rcases Nat.find_spec hex with ⟨hr_lt, hr_ready⟩
    have hprev_not : ∀ i (hi : i < r_cut),
        (status ⟨i, lt_of_lt_of_le hi (le_of_lt hr_lt)⟩).isCutReady = false := by
      intro i hi
      cases hci : (status ⟨i, lt_of_lt_of_le hi (le_of_lt hr_lt)⟩).isCutReady
      · rfl
      · exact False.elim (Nat.find_min hex hi ⟨lt_of_lt_of_le hi (le_of_lt hr_lt), hci⟩)
    cases hst_cut : status ⟨r_cut, hr_lt⟩ with
    | keepNone _ => rw [hst_cut] at hr_ready; cases hr_ready
    | keepJob _ _ _ _ => rw [hst_cut] at hr_ready; cases hr_ready
    | truncateSmall hsmall =>
        let nodes_mid : Fin r_cut → ChainNode d :=
          fun i => st.nodes ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩
        have hpre_eq : ∀ i : Fin r_cut,
            chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids
              ⟨i.val, Nat.lt_succ_of_lt (lt_of_lt_of_le i.isLt (le_of_lt hr_lt))⟩ =
            chainInput uMap'.ghostCoords nodes_mid uMap'.ActiveUids i.castSucc := by
          intro i
          exact cg01_chainInput_congr_prefix st.nodes nodes_mid (fun _ _ => rfl)
            i.val (le_of_lt (lt_of_lt_of_le i.isLt (le_of_lt hr_lt))) (le_of_lt i.isLt)
            (fun m hm => rfl)
        have hoj_ex : ∀ i : Fin r_cut,
            ∃ oj : Option (ActiveJobGhost d n (d + 3) L B_scan uMap'.nextUid uMap'.ghostCoords
                (chainInput uMap'.ghostCoords nodes_mid uMap'.ActiveUids i.castSucc)),
              ServingOwnedJobInv (st.birthSnap ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩)
                (snAge' ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩) oj ∧
              ((status ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩).CenterGood →
                ∀ g, oj = some g → JobLevelsCenterGood (d + 3) uMap'.ghostCoords g.lvs) := by
          intro i
          let i_old : Fin st.k := ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩
          rcases h_not_ready_job i_old (hprev_not i.val i.isLt) with ⟨oj₀, hoj_inv, hoj_good⟩
          cases oj₀ with
          | none => exact ⟨none, hoj_inv, fun _ _ hg => by cases hg⟩
          | some g₀ =>
              refine ⟨some (ActiveJobGhost.castPool g₀ (hpre_eq i)), hoj_inv, ?_⟩
              intro hcg g hg
              injection hg with hg_eq
              subst hg_eq
              exact hoj_good hcg g₀ rfl
        choose oj_fn hoj_fn using hoj_ex
        let st_mid : PureServingState d n H L B_scan P' :=
          { uMap := uMap'
            k := r_cut
            nodes := nodes_mid
            birthSnap := fun i => st.birthSnap ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩
            snAge := fun i => snAge' ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩
            trueAge := fun i => trueAge' ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩
            ownedJob := oj_fn }
        refine ⟨st_mid, rfl, ?_, ?_, ?_⟩
        · intro i
          let i_old : Fin st.k := ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩
          exact ⟨(hinv i_old).1, hbirth_uid_lt i_old, hbirth_pass' i_old,
            htr_le' i_old, (hpre_eq i) ▸ hhas_age' i_old, (hoj_fn i).1⟩
        · have hterm_uid : chainTerminal uMap'.ghostCoords nodes_mid uMap'.ActiveUids =
              chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids ⟨r_cut, Nat.lt_succ_of_lt hr_lt⟩ := by
            rw [cg01_chainTerminal_eq]
            exact cg01_chainInput_congr_prefix nodes_mid st.nodes (fun _ _ => rfl)
              r_cut le_rfl (le_of_lt hr_lt) (fun _ _ => rfl)
          have hcard_eq : (chainTerminal P'.handleCoords nodes_mid P'.activeHandles).card =
              (chainTerminal uMap'.ghostCoords nodes_mid uMap'.ActiveUids).card := by
            rw [← uMap'.mapSet_chainTerminal nodes_mid]
            exact (uMap'.mapSet_bij (cg01_chainTerminal_subset P'.handleCoords nodes_mid P'.activeHandles)).1.symm
          change (chainTerminal P'.handleCoords nodes_mid P'.activeHandles).card ≤ 4 * L + 2
          rw [hcard_eq, hterm_uid]
          exact le_trans hsmall (by omega)
        · intro hcp_old hcg_all
          exact ⟨fun i => hbirth_cp' hcp_old ⟨i.val, lt_of_lt_of_le i.isLt (le_of_lt hr_lt)⟩,
            fun i g hg => (hoj_fn i).2 (hcg_all _) g hg⟩
    | installDeadline g' hdone =>
        have hfin := g'.finishAtDeadline h_lem_C_2 hD hL_floor hL_eq10 hB_floor hdone
        rcases hfin with ⟨_, _, hres_le, hlvs_props⟩
        let K_new := g'.lvs.length
        let k_mid := r_cut + K_new
        let nodes_mid : Fin k_mid → ChainNode d := fun idx =>
          if hlt : idx.val < r_cut then
            st.nodes ⟨idx.val, lt_of_lt_of_le hlt (le_of_lt hr_lt)⟩
          else
            (g'.lvs[idx.val - r_cut]'(by have := idx.isLt; dsimp [k_mid, K_new] at this; omega)).ball
        have hpre_nodes : ∀ i (hi : i < r_cut),
            nodes_mid ⟨i, lt_of_lt_of_le hi (Nat.le_add_right _ _)⟩ =
              st.nodes ⟨i, lt_of_lt_of_le hi (le_of_lt hr_lt)⟩ :=
          fun _ hi => dif_pos hi
        have hsuf_nodes : ∀ j (hj : j < g'.lvs.length),
            nodes_mid ⟨r_cut + j, Nat.add_lt_add_left hj r_cut⟩ = (g'.lvs[j]'hj).ball := by
          intro j hj
          dsimp [nodes_mid]
          rw [dif_neg (by omega)]
          have hsub : r_cut + j - r_cut = j := by omega
          simp [hsub]
        have hpre_eq : ∀ i (hi : i < r_cut),
            chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids
              ⟨i, Nat.lt_succ_of_lt (lt_of_lt_of_le hi (le_of_lt hr_lt))⟩ =
            chainInput uMap'.ghostCoords nodes_mid uMap'.ActiveUids
              ⟨i, Nat.lt_succ_of_lt (lt_of_lt_of_le hi (Nat.le_add_right _ _))⟩ := by
          intro i hi
          exact cg01_chainInput_congr_prefix st.nodes nodes_mid (fun _ _ => rfl)
            i (le_of_lt (lt_of_lt_of_le hi (le_of_lt hr_lt)))
            (le_of_lt (lt_of_lt_of_le hi (Nat.le_add_right _ _)))
            (fun m hm => (hpre_nodes m (lt_trans hm hi)).symm)
        have hsuf_age : ∀ j (hj : j < K_new),
            ∃ ta : ℕ, ta ≤ g'.openRem j ∧
              HasNodeAge (g'.lvs[j]'hj).birthSnapshot
                (chainInput uMap'.ghostCoords nodes_mid uMap'.ActiveUids
                  ⟨r_cut + j, Nat.lt_succ_of_lt (Nat.add_lt_add_left hj r_cut)⟩) ta := by
          intro j hj
          rcases (hlvs_props j hj).2.2.2.2.2.2 with ⟨ta, hta_le, hta_age⟩
          have hsp := cg01_chainInput_splice_suffix uMap'.ghostCoords st.nodes g'.lvs
            (le_of_lt hr_lt) nodes_mid hpre_nodes hsuf_nodes uMap'.ActiveUids j (le_of_lt hj)
          exact ⟨ta, hta_le, hsp.symm ▸ hta_age⟩
        choose ta_suf hta_suf using hsuf_age
        have hoj_ex : ∀ idx : Fin k_mid,
            ∃ oj : Option (ActiveJobGhost d n (d + 3) L B_scan uMap'.nextUid uMap'.ghostCoords
                (chainInput uMap'.ghostCoords nodes_mid uMap'.ActiveUids idx.castSucc)),
              if hlt : idx.val < r_cut then
                let i_old : Fin st.k := ⟨idx.val, lt_of_lt_of_le hlt (le_of_lt hr_lt)⟩
                ServingOwnedJobInv (st.birthSnap i_old) (snAge' i_old) oj ∧
                ((status i_old).CenterGood →
                  ∀ g, oj = some g → JobLevelsCenterGood (d + 3) uMap'.ghostCoords g.lvs)
              else
                oj = none := by
          intro idx
          by_cases hlt : idx.val < r_cut
          · let i_old : Fin st.k := ⟨idx.val, lt_of_lt_of_le hlt (le_of_lt hr_lt)⟩
            rcases h_not_ready_job i_old (hprev_not idx.val hlt) with ⟨oj₀, hoj_inv, hoj_good⟩
            refine ⟨oj₀.map (fun g => g.castPool (hpre_eq idx.val hlt)), ?_⟩
            rw [dif_pos hlt]
            refine ⟨(servingOwnedJobInv_castPool (hpre_eq idx.val hlt) _ _ oj₀).mpr hoj_inv, ?_⟩
            intro hcg g hg
            cases oj₀ with
            | none => cases hg
            | some g₀ =>
                simp only [Option.map_some, Option.some.injEq] at hg
                subst hg
                exact hoj_good hcg g₀ rfl
          · refine ⟨none, ?_⟩
            rw [dif_neg hlt]
        choose oj_mid hoj_mid using hoj_ex
        let st_mid : PureServingState d n H L B_scan P' :=
          { uMap := uMap'
            k := k_mid
            nodes := nodes_mid
            birthSnap := fun idx =>
              if hlt : idx.val < r_cut then
                st.birthSnap ⟨idx.val, lt_of_lt_of_le hlt (le_of_lt hr_lt)⟩
              else
                (g'.lvs[idx.val - r_cut]'(by have := idx.isLt; dsimp [k_mid, K_new] at this; omega)).birthSnapshot
            snAge := fun idx =>
              if hlt : idx.val < r_cut then
                snAge' ⟨idx.val, lt_of_lt_of_le hlt (le_of_lt hr_lt)⟩
              else
                g'.openRem (idx.val - r_cut)
            trueAge := fun idx =>
              if hlt : idx.val < r_cut then
                trueAge' ⟨idx.val, lt_of_lt_of_le hlt (le_of_lt hr_lt)⟩
              else
                ta_suf (idx.val - r_cut) (by have := idx.isLt; dsimp [k_mid, K_new] at this; omega)
            ownedJob := oj_mid }
        refine ⟨st_mid, rfl, ?_, ?_, ?_⟩
        · intro idx
          have hoj_i := hoj_mid idx
          by_cases hlt : idx.val < r_cut
          · rw [dif_pos hlt] at hoj_i
            let i_old : Fin st.k := ⟨idx.val, lt_of_lt_of_le hlt (le_of_lt hr_lt)⟩
            have hbs : st_mid.birthSnap idx = st.birthSnap i_old := dif_pos hlt
            have hsn_eq : st_mid.snAge idx = snAge' i_old := dif_pos hlt
            have htr_eq : st_mid.trueAge idx = trueAge' i_old := dif_pos hlt
            have hnod_eq : st_mid.nodes idx = st.nodes i_old := dif_pos hlt
            have hoj_eq : st_mid.ownedJob idx = oj_mid idx := rfl
            dsimp only [PureServingState.NodesInv]
            rw [hbs, hsn_eq, htr_eq, hnod_eq, hoj_eq]
            exact ⟨(hinv i_old).1, hbirth_uid_lt i_old, hbirth_pass' i_old,
              htr_le' i_old, (hpre_eq idx.val hlt) ▸ hhas_age' i_old, hoj_i.1⟩
          · rw [dif_neg hlt] at hoj_i
            let j := idx.val - r_cut
            have hj_lt : j < K_new := by
              have hi : idx.val < r_cut + K_new := idx.isLt
              dsimp only [j]
              omega
            have hidx_eq : idx = ⟨r_cut + j, Nat.add_lt_add_left hj_lt r_cut⟩ := by
              ext; dsimp only [j]; omega
            have hbs : st_mid.birthSnap idx = (g'.lvs[j]'hj_lt).birthSnapshot := dif_neg hlt
            have hsn_eq : st_mid.snAge idx = g'.openRem j := dif_neg hlt
            have htr_eq : st_mid.trueAge idx = ta_suf j hj_lt := dif_neg hlt
            have hnod_j : st_mid.nodes idx = (g'.lvs[j]'hj_lt).ball := by
              change nodes_mid idx = _
              rw [hidx_eq]; exact hsuf_nodes j hj_lt
            have hoj_eq : st_mid.ownedJob idx = oj_mid idx := rfl
            have hp_j := hlvs_props j hj_lt
            dsimp only [PureServingState.NodesInv]
            rw [hbs, hsn_eq, htr_eq, hnod_j, hoj_eq, hoj_i]
            refine ⟨hp_j.2.1, hp_j.2.2.1, hp_j.2.2.2.1,
              (hta_suf j hj_lt).1, ?_, hp_j.2.2.2.2.1⟩
            have hage_j := (hta_suf j hj_lt).2
            have hcast_eq : idx.castSucc = ⟨r_cut + j, Nat.lt_succ_of_lt (Nat.add_lt_add_left hj_lt r_cut)⟩ := by
              ext; simp only [Fin.val_castSucc]; dsimp only [j]; omega
            rwa [hcast_eq]
        · have hterm_uid : chainTerminal uMap'.ghostCoords nodes_mid uMap'.ActiveUids =
              prefixResidual uMap'.ghostCoords g'.lvs
                (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids ⟨r_cut, Nat.lt_succ_of_lt hr_lt⟩) :=
            cg01_chainTerminal_splice uMap'.ghostCoords st.nodes g'.lvs (le_of_lt hr_lt)
              nodes_mid hpre_nodes hsuf_nodes uMap'.ActiveUids
          have hcard_eq : (chainTerminal P'.handleCoords nodes_mid P'.activeHandles).card =
              (chainTerminal uMap'.ghostCoords nodes_mid uMap'.ActiveUids).card := by
            rw [← uMap'.mapSet_chainTerminal nodes_mid]
            exact (uMap'.mapSet_bij (cg01_chainTerminal_subset P'.handleCoords nodes_mid P'.activeHandles)).1.symm
          change (chainTerminal P'.handleCoords nodes_mid P'.activeHandles).card ≤ 4 * L + 2
          rw [hcard_eq, hterm_uid]
          exact le_trans hres_le (by omega)
        · intro hcp_old hcg_all
          have hcg_cut : JobLevelsCenterGood (d + 3) uMap'.ghostCoords g'.lvs := by
            have hc := hcg_all ⟨r_cut, hr_lt⟩
            rwa [hst_cut] at hc
          refine ⟨fun idx => ?_, fun idx g hg => ?_⟩
          · by_cases hlt : idx.val < r_cut
            · let i_old : Fin st.k := ⟨idx.val, lt_of_lt_of_le hlt (le_of_lt hr_lt)⟩
              have hbs : st_mid.birthSnap idx = st.birthSnap i_old := dif_pos hlt
              have hnod_eq : st_mid.nodes idx = st.nodes i_old := dif_pos hlt
              rw [hbs, hnod_eq]
              exact hbirth_cp' hcp_old i_old
            · let j := idx.val - r_cut
              have hj_lt : j < K_new := by
                have hi : idx.val < r_cut + K_new := idx.isLt
                dsimp only [j]
                omega
              have hidx_eq : idx = ⟨r_cut + j, Nat.add_lt_add_left hj_lt r_cut⟩ := by
                ext; dsimp only [j]; omega
              have hbs : st_mid.birthSnap idx = (g'.lvs[j]'hj_lt).birthSnapshot := dif_neg hlt
              have hnod_j : st_mid.nodes idx = (g'.lvs[j]'hj_lt).ball := by
                change nodes_mid idx = _
                rw [hidx_eq]; exact hsuf_nodes j hj_lt
              rw [hbs, hnod_j]
              exact hcg_cut j hj_lt
          · have hoj_i := hoj_mid idx
            by_cases hlt : idx.val < r_cut
            · rw [dif_pos hlt] at hoj_i
              exact hoj_i.2 (hcg_all _) g hg
            · rw [dif_neg hlt] at hoj_i
              dsimp only [st_mid] at hg
              rw [hoj_i] at hg; cases hg
  · have hall_nr : ∀ r : Fin st.k, (status r).isCutReady = false := by
      intro r
      cases hcr : (status r).isCutReady
      · rfl
      · exact False.elim (hex ⟨r.val, r.isLt, hcr⟩)
    have hoj_ex : ∀ r : Fin st.k,
        ∃ oj : Option (ActiveJobGhost d n (d + 3) L B_scan uMap'.nextUid uMap'.ghostCoords
            (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc)),
          ServingOwnedJobInv (st.birthSnap r) (snAge' r) oj ∧
          ((status r).CenterGood →
            ∀ g, oj = some g → JobLevelsCenterGood (d + 3) uMap'.ghostCoords g.lvs) :=
      fun r => h_not_ready_job r (hall_nr r)
    choose oj_keep hoj_keep using hoj_ex
    let st_mid : PureServingState d n H L B_scan P' :=
      { uMap := uMap'
        k := st.k
        nodes := st.nodes
        birthSnap := st.birthSnap
        snAge := snAge'
        trueAge := trueAge'
        ownedJob := oj_keep }
    refine ⟨st_mid, rfl, ?_, ?_, ?_⟩
    · intro r
      exact ⟨(hinv r).1, hbirth_uid_lt r, hbirth_pass' r,
        htr_le' r, hhas_age' r, (hoj_keep r).1⟩
    · have hstep_leaf := cg01_chainTerminal_card_step_le st.nodes hchg_root hcoords_root
      change (chainTerminal P'.handleCoords st.nodes P'.activeHandles).card ≤ 4 * L + 2
      omega
    · intro hcp_old hcg_all
      exact ⟨fun r => hbirth_cp' hcp_old r, fun r g hg => (hoj_keep r).2 (hcg_all r) g hg⟩


end UL.Proof_lem_7_2_RacerP46
