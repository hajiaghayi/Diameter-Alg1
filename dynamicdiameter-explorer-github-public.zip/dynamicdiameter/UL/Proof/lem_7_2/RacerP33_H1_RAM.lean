import Mathlib
import UL.Def.def_diameter_pair
import UL.Def.def_dynamic_points_model
import UL.Def.def_adaptive_execution_model
import UL.Def.def_computation_model
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP33

/-! ### 1. Store read/write/free/popDepth helpers and cell-count bounds -/

def wRead (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ℤ :=
  mem.words.read (.heap t i)

def wWrite (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℤ) : ArithRAMMemory :=
  { mem with words := mem.words.write (.heap t i) v }

def wFree (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ArithRAMMemory :=
  { mem with words := mem.words.free (.heap t i) }

def wReadL (fd : ℕ) (mem : ArithRAMMemory) (v : ℕ) (i : ℤ) : ℤ :=
  mem.words.read (.localFrame fd v i)

def wWriteL (fd : ℕ) (mem : ArithRAMMemory) (v : ℕ) (i : ℤ) (val : ℤ) : ArithRAMMemory :=
  { mem with words := mem.words.write (.localFrame fd v i) val }

def wFreeL (fd : ℕ) (mem : ArithRAMMemory) (v : ℕ) (i : ℤ) : ArithRAMMemory :=
  { mem with words := mem.words.free (.localFrame fd v i) }

noncomputable def rRead (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ℝ :=
  mem.reals.read (.heap t i)

noncomputable def rWrite (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℝ) : ArithRAMMemory :=
  { mem with reals := mem.reals.write (.heap t i) v }

noncomputable def rFree (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ArithRAMMemory :=
  { mem with reals := mem.reals.free (.heap t i) }

noncomputable def rReadL (fd : ℕ) (mem : ArithRAMMemory) (v : ℕ) (i : ℤ) : ℝ :=
  mem.reals.read (.localFrame fd v i)

noncomputable def rWriteL (fd : ℕ) (mem : ArithRAMMemory) (v : ℕ) (i : ℤ) (val : ℝ) : ArithRAMMemory :=
  { mem with reals := mem.reals.write (.localFrame fd v i) val }

noncomputable def rFreeL (fd : ℕ) (mem : ArithRAMMemory) (v : ℕ) (i : ℤ) : ArithRAMMemory :=
  { mem with reals := mem.reals.free (.localFrame fd v i) }

@[simp] theorem wRead_empty (t : ℕ) (i : ℤ) : wRead ArithRAMMemory.empty t i = 0 := by
  simp [wRead, ArithRAMMemory.empty, WordStore.empty, WordStore.read]

@[simp] theorem rRead_empty (t : ℕ) (i : ℤ) : rRead ArithRAMMemory.empty t i = 0 := by
  simp [rRead, ArithRAMMemory.empty, RealStore.empty, RealStore.read]

@[simp] theorem cellCount_empty : ArithRAMMemory.empty.cellCount = 0 := by
  simp [ArithRAMMemory.cellCount, ArithRAMMemory.empty, WordStore.cellCount,
    WordStore.empty, RealStore.cellCount, RealStore.empty]

@[simp] theorem wRead_wWrite_self (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℤ) :
    wRead (wWrite mem t i v) t i = v := by
  simp [wRead, wWrite, WordStore.read, WordStore.write]

theorem wRead_wWrite_of_ne (mem : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℤ)
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    wRead (wWrite mem t₂ i₂ v) t₁ i₁ = wRead mem t₁ i₁ := by
  have hloc : (RAMCellLoc.heap t₁ i₁) ≠ (RAMCellLoc.heap t₂ i₂) := by
    intro h; cases h; rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [wRead, wWrite, WordStore.read, WordStore.write, hloc]

@[simp] theorem wRead_wFree_self (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) :
    wRead (wFree mem t i) t i = 0 := by
  simp [wRead, wFree, WordStore.read, WordStore.free]

theorem wRead_wFree_of_ne (mem : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ}
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    wRead (wFree mem t₂ i₂) t₁ i₁ = wRead mem t₁ i₁ := by
  have hloc : (RAMCellLoc.heap t₁ i₁) ≠ (RAMCellLoc.heap t₂ i₂) := by
    intro h; cases h; rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [wRead, wFree, WordStore.read, WordStore.free, hloc]

@[simp] theorem wReadL_wWriteL_self (fd : ℕ) (mem : ArithRAMMemory) (v : ℕ) (i : ℤ) (val : ℤ) :
    wReadL fd (wWriteL fd mem v i val) v i = val := by
  simp [wReadL, wWriteL, WordStore.read, WordStore.write]

theorem wReadL_wWriteL_of_ne (fd : ℕ) (mem : ArithRAMMemory) {v₁ v₂ : ℕ} {i₁ i₂ : ℤ} (val : ℤ)
    (hne : v₁ ≠ v₂ ∨ i₁ ≠ i₂) :
    wReadL fd (wWriteL fd mem v₂ i₂ val) v₁ i₁ = wReadL fd mem v₁ i₁ := by
  have hloc : (RAMCellLoc.localFrame fd v₁ i₁) ≠ (RAMCellLoc.localFrame fd v₂ i₂) := by
    intro h; cases h; rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [wReadL, wWriteL, WordStore.read, WordStore.write, hloc]

@[simp] theorem wRead_wWriteL (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ val : ℤ) :
    wRead (wWriteL fd mem v i₂ val) t i₁ = wRead mem t i₁ := by
  simp [wRead, wWriteL, WordStore.read, WordStore.write]

@[simp] theorem wReadL_wWrite (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ val : ℤ) :
    wReadL fd (wWrite mem t i₂ val) v i₁ = wReadL fd mem v i₁ := by
  simp [wReadL, wWrite, WordStore.read, WordStore.write]

@[simp] theorem wRead_wFreeL (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ : ℤ) :
    wRead (wFreeL fd mem v i₂) t i₁ = wRead mem t i₁ := by
  simp [wRead, wFreeL, WordStore.read, WordStore.free]

@[simp] theorem wReadL_wFree (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ : ℤ) :
    wReadL fd (wFree mem t i₂) v i₁ = wReadL fd mem v i₁ := by
  simp [wReadL, wFree, WordStore.read, WordStore.free]

@[simp] theorem wRead_rWrite (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) (v : ℝ) :
    wRead (rWrite mem t₂ i₂ v) t₁ i₁ = wRead mem t₁ i₁ := rfl

@[simp] theorem wRead_rFree (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) :
    wRead (rFree mem t₂ i₂) t₁ i₁ = wRead mem t₁ i₁ := rfl

@[simp] theorem wRead_rWriteL (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ : ℤ) (val : ℝ) :
    wRead (rWriteL fd mem v i₂ val) t i₁ = wRead mem t i₁ := rfl

@[simp] theorem wReadL_rWrite (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ : ℤ) (val : ℝ) :
    wReadL fd (rWrite mem t i₂ val) v i₁ = wReadL fd mem v i₁ := rfl

@[simp] theorem wReadL_rWriteL (fd₁ fd₂ : ℕ) (mem : ArithRAMMemory) (v₁ v₂ : ℕ) (i₁ i₂ : ℤ) (val : ℝ) :
    wReadL fd₁ (rWriteL fd₂ mem v₂ i₂ val) v₁ i₁ = wReadL fd₁ mem v₁ i₁ := rfl

@[simp] theorem rRead_wWrite (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) (v : ℤ) :
    rRead (wWrite mem t₂ i₂ v) t₁ i₁ = rRead mem t₁ i₁ := rfl

@[simp] theorem rRead_wFree (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) :
    rRead (wFree mem t₂ i₂) t₁ i₁ = rRead mem t₁ i₁ := rfl

@[simp] theorem rRead_wWriteL (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ val : ℤ) :
    rRead (wWriteL fd mem v i₂ val) t i₁ = rRead mem t i₁ := rfl

@[simp] theorem rReadL_wWrite (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ val : ℤ) :
    rReadL fd (wWrite mem t i₂ val) v i₁ = rReadL fd mem v i₁ := rfl

@[simp] theorem rReadL_wWriteL (fd₁ fd₂ : ℕ) (mem : ArithRAMMemory) (v₁ v₂ : ℕ) (i₁ i₂ val : ℤ) :
    rReadL fd₁ (wWriteL fd₂ mem v₂ i₂ val) v₁ i₁ = rReadL fd₁ mem v₁ i₁ := rfl

@[simp] theorem rRead_rWrite_self (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℝ) :
    rRead (rWrite mem t i v) t i = v := by
  simp [rRead, rWrite, RealStore.read, RealStore.write]

theorem rRead_rWrite_of_ne (mem : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℝ)
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    rRead (rWrite mem t₂ i₂ v) t₁ i₁ = rRead mem t₁ i₁ := by
  have hloc : (RAMCellLoc.heap t₁ i₁) ≠ (RAMCellLoc.heap t₂ i₂) := by
    intro h; cases h; rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [rRead, rWrite, RealStore.read, RealStore.write, hloc]

@[simp] theorem rRead_rFree_self (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) :
    rRead (rFree mem t i) t i = 0 := by
  simp [rRead, rFree, RealStore.read, RealStore.free]

theorem rRead_rFree_of_ne (mem : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ}
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    rRead (rFree mem t₂ i₂) t₁ i₁ = rRead mem t₁ i₁ := by
  have hloc : (RAMCellLoc.heap t₁ i₁) ≠ (RAMCellLoc.heap t₂ i₂) := by
    intro h; cases h; rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [rRead, rFree, RealStore.read, RealStore.free, hloc]

@[simp] theorem rReadL_rWriteL_self (fd : ℕ) (mem : ArithRAMMemory) (v : ℕ) (i : ℤ) (val : ℝ) :
    rReadL fd (rWriteL fd mem v i val) v i = val := by
  simp [rReadL, rWriteL, RealStore.read, RealStore.write]

theorem rReadL_rWriteL_of_ne (fd : ℕ) (mem : ArithRAMMemory) {v₁ v₂ : ℕ} {i₁ i₂ : ℤ} (val : ℝ)
    (hne : v₁ ≠ v₂ ∨ i₁ ≠ i₂) :
    rReadL fd (rWriteL fd mem v₂ i₂ val) v₁ i₁ = rReadL fd mem v₁ i₁ := by
  have hloc : (RAMCellLoc.localFrame fd v₁ i₁) ≠ (RAMCellLoc.localFrame fd v₂ i₂) := by
    intro h; cases h; rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [rReadL, rWriteL, RealStore.read, RealStore.write, hloc]

@[simp] theorem rRead_rWriteL (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ : ℤ) (val : ℝ) :
    rRead (rWriteL fd mem v i₂ val) t i₁ = rRead mem t i₁ := by
  simp [rRead, rWriteL, RealStore.read, RealStore.write]

@[simp] theorem rReadL_rWrite (fd : ℕ) (mem : ArithRAMMemory) (t v : ℕ) (i₁ i₂ : ℤ) (val : ℝ) :
    rReadL fd (rWrite mem t i₂ val) v i₁ = rReadL fd mem v i₁ := by
  simp [rReadL, rWrite, RealStore.read, RealStore.write]

@[simp] theorem wRead_popDepth (mem : ArithRAMMemory) (k t : ℕ) (i : ℤ) :
    wRead (mem.popDepth k) t i = wRead mem t i := by
  simp [wRead, ArithRAMMemory.popDepth, WordStore.popDepth, WordStore.read,
    RAMCellLoc.keepAtDepth]

@[simp] theorem rRead_popDepth (mem : ArithRAMMemory) (k t : ℕ) (i : ℤ) :
    rRead (mem.popDepth k) t i = rRead mem t i := by
  simp [rRead, ArithRAMMemory.popDepth, RealStore.popDepth, RealStore.read,
    RAMCellLoc.keepAtDepth]

theorem wReadL_popDepth_gt (mem : ArithRAMMemory) {k fd : ℕ} (hk : k < fd) (v : ℕ) (i : ℤ) :
    wReadL fd (mem.popDepth k) v i = 0 := by
  have hkeep : RAMCellLoc.keepAtDepth k (.localFrame fd v i) = false := by
    simp [RAMCellLoc.keepAtDepth]; omega
  simp [wReadL, ArithRAMMemory.popDepth, WordStore.popDepth, WordStore.read, hkeep]

theorem rReadL_popDepth_gt (mem : ArithRAMMemory) {k fd : ℕ} (hk : k < fd) (v : ℕ) (i : ℤ) :
    rReadL fd (mem.popDepth k) v i = 0 := by
  have hkeep : RAMCellLoc.keepAtDepth k (.localFrame fd v i) = false := by
    simp [RAMCellLoc.keepAtDepth]; omega
  simp [rReadL, ArithRAMMemory.popDepth, RealStore.popDepth, RealStore.read, hkeep]

theorem wReadL_popDepth_le (mem : ArithRAMMemory) {k fd : ℕ} (hk : fd ≤ k) (v : ℕ) (i : ℤ) :
    wReadL fd (mem.popDepth k) v i = wReadL fd mem v i := by
  have hkeep : RAMCellLoc.keepAtDepth k (.localFrame fd v i) = true := by
    simp [RAMCellLoc.keepAtDepth, hk]
  simp [wReadL, ArithRAMMemory.popDepth, WordStore.popDepth, WordStore.read, hkeep]

theorem rReadL_popDepth_le (mem : ArithRAMMemory) {k fd : ℕ} (hk : fd ≤ k) (v : ℕ) (i : ℤ) :
    rReadL fd (mem.popDepth k) v i = rReadL fd mem v i := by
  have hkeep : RAMCellLoc.keepAtDepth k (.localFrame fd v i) = true := by
    simp [RAMCellLoc.keepAtDepth, hk]
  simp [rReadL, ArithRAMMemory.popDepth, RealStore.popDepth, RealStore.read, hkeep]

theorem wordStore_cellCount_write_le (ws : WordStore) (loc : RAMCellLoc) (v : ℤ) :
    (ws.write loc v).cellCount ≤ ws.cellCount + 1 := by
  simpa [WordStore.write, WordStore.cellCount] using Finset.card_insert_le loc ws.live

theorem wordStore_cellCount_free_le (ws : WordStore) (loc : RAMCellLoc) :
    (ws.free loc).cellCount ≤ ws.cellCount := by
  simpa [WordStore.free, WordStore.cellCount] using Finset.card_erase_le

theorem wordStore_cellCount_popDepth_le (ws : WordStore) (k : ℕ) :
    (ws.popDepth k).cellCount ≤ ws.cellCount := by
  simpa [WordStore.popDepth, WordStore.cellCount] using
    Finset.card_filter_le ws.live (fun loc => loc.keepAtDepth k = true)

theorem realStore_cellCount_write_le (rs : RealStore) (loc : RAMCellLoc) (v : ℝ) :
    (rs.write loc v).cellCount ≤ rs.cellCount + 1 := by
  simpa [RealStore.write, RealStore.cellCount] using Finset.card_insert_le loc rs.live

theorem realStore_cellCount_free_le (rs : RealStore) (loc : RAMCellLoc) :
    (rs.free loc).cellCount ≤ rs.cellCount := by
  simpa [RealStore.free, RealStore.cellCount] using Finset.card_erase_le

theorem realStore_cellCount_popDepth_le (rs : RealStore) (k : ℕ) :
    (rs.popDepth k).cellCount ≤ rs.cellCount := by
  simpa [RealStore.popDepth, RealStore.cellCount] using
    Finset.card_filter_le rs.live (fun loc => loc.keepAtDepth k = true)

theorem cellCount_popDepth_le (mem : ArithRAMMemory) (k : ℕ) :
    (mem.popDepth k).cellCount ≤ mem.cellCount :=
  Nat.add_le_add (wordStore_cellCount_popDepth_le mem.words k)
    (realStore_cellCount_popDepth_le mem.reals k)

theorem mem_cellCount_writeWord_le (m : ArithRAMMemory) (loc : RAMCellLoc) (v : ℤ) :
    ({ m with words := m.words.write loc v } : ArithRAMMemory).cellCount ≤ m.cellCount + 1 := by
  have h := wordStore_cellCount_write_le m.words loc v
  unfold ArithRAMMemory.cellCount; dsimp only; omega

theorem mem_cellCount_freeWord_le (m : ArithRAMMemory) (loc : RAMCellLoc) :
    ({ m with words := m.words.free loc } : ArithRAMMemory).cellCount ≤ m.cellCount := by
  have h := wordStore_cellCount_free_le m.words loc
  unfold ArithRAMMemory.cellCount; dsimp only; omega

theorem mem_cellCount_writeReal_le (m : ArithRAMMemory) (loc : RAMCellLoc) (v : ℝ) :
    ({ m with reals := m.reals.write loc v } : ArithRAMMemory).cellCount ≤ m.cellCount + 1 := by
  have h := realStore_cellCount_write_le m.reals loc v
  unfold ArithRAMMemory.cellCount; dsimp only; omega

theorem mem_cellCount_freeReal_le (m : ArithRAMMemory) (loc : RAMCellLoc) :
    ({ m with reals := m.reals.free loc } : ArithRAMMemory).cellCount ≤ m.cellCount := by
  have h := realStore_cellCount_free_le m.reals loc
  unfold ArithRAMMemory.cellCount; dsimp only; omega

/-! ### 2. Expression operations and value projections -/

def intExprOps : IntExpr → ℕ
  | .lit _ | .dim => 1
  | .intParam e | .readHeap _ e | .readLocal _ e | .extraRatNum e | .extraRatDen e | .neg e =>
      intExprOps e + 1
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ | .add e₁ e₂ | .sub e₁ e₂
  | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ =>
      intExprOps e₁ + intExprOps e₂ + 1

def realExprOps : RealExpr → ℕ
  | .ofInt e | .readRealHeap _ e | .readRealLocal _ e | .extraReal e => intExprOps e + 1
  | .activePtCoord e₁ e₂ => intExprOps e₁ + intExprOps e₂ + 1
  | .neg r => realExprOps r + 1
  | .add r₁ r₂ | .sub r₁ r₂ | .mul r₁ r₂ | .div r₁ r₂ => realExprOps r₁ + realExprOps r₂ + 1

def condExprOps : ArithCondExpr → ℕ
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => intExprOps e₁ + intExprOps e₂ + 1
  | .realEq r₁ r₂ | .realLt r₁ r₂ | .realLe r₁ r₂ => realExprOps r₁ + realExprOps r₂ + 1
  | .not c => condExprOps c + 1
  | .and c₁ c₂ | .or c₁ c₂ => condExprOps c₁ + condExprOps c₂ + 1

theorem evalIntExpr_ops {d : ℕ} (bw : BitRAMInput d) (fd : ℕ) (ws : WordStore) :
    ∀ e : IntExpr, (evalIntExpr bw fd ws e).2.1 = intExprOps e
  | .lit _ | .dim => rfl
  | .intParam e | .readHeap _ e | .readLocal _ e | .extraRatNum e | .extraRatDen e | .neg e => by
      simp [evalIntExpr, intExprOps, evalIntExpr_ops bw fd ws e]
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ | .add e₁ e₂ | .sub e₁ e₂
  | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ => by
      simp [evalIntExpr, intExprOps, evalIntExpr_ops bw fd ws e₁, evalIntExpr_ops bw fd ws e₂]

theorem evalRealExpr_ops {d : ℕ} (inp : ArithRAMInput d) (fd : ℕ) (mem : ArithRAMMemory) :
    ∀ r : RealExpr, (evalRealExpr inp fd mem r).2 = realExprOps r
  | .ofInt e | .readRealHeap _ e | .readRealLocal _ e | .extraReal e => by
      simp [evalRealExpr, realExprOps, evalIntExpr_ops]
  | .activePtCoord e₁ e₂ => by
      simp [evalRealExpr, realExprOps, evalIntExpr_ops]
  | .neg r => by
      simp [evalRealExpr, realExprOps, evalRealExpr_ops inp fd mem r]
  | .add r₁ r₂ | .sub r₁ r₂ | .mul r₁ r₂ | .div r₁ r₂ => by
      simp [evalRealExpr, realExprOps, evalRealExpr_ops inp fd mem r₁,
        evalRealExpr_ops inp fd mem r₂]

theorem evalArithCond_ops {d : ℕ} (inp : ArithRAMInput d) (fd : ℕ) (mem : ArithRAMMemory) :
    ∀ c : ArithCondExpr, (evalArithCond inp fd mem c).2 = condExprOps c
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => by
      simp [evalArithCond, condExprOps, evalIntExpr_ops]
  | .realEq r₁ r₂ | .realLt r₁ r₂ | .realLe r₁ r₂ => by
      simp [evalArithCond, condExprOps, evalRealExpr_ops]
  | .not c => by
      simp [evalArithCond, condExprOps, evalArithCond_ops inp fd mem c]
  | .and c₁ c₂ | .or c₁ c₂ => by
      simp [evalArithCond, condExprOps, evalArithCond_ops inp fd mem c₁,
        evalArithCond_ops inp fd mem c₂]

def iValAt {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory) (e : IntExpr) : ℤ :=
  (evalIntExpr inp.toWordView fd mem.words e).1

noncomputable def rValAt {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (r : RealExpr) : ℝ :=
  (evalRealExpr inp fd mem r).1

noncomputable def cValAt {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (c : ArithCondExpr) : Bool :=
  (evalArithCond inp fd mem c).1

abbrev iVal {d : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory) (e : IntExpr) : ℤ :=
  iValAt 0 inp mem e

noncomputable abbrev rVal {d : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory) (r : RealExpr) : ℝ :=
  rValAt 0 inp mem r

noncomputable abbrev cVal {d : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (c : ArithCondExpr) : Bool :=
  cValAt 0 inp mem c

@[simp] theorem iValAt_lit {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory) (c : ℤ) :
    iValAt fd inp mem (.lit c) = c := rfl
@[simp] theorem iValAt_dim {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory) :
    iValAt fd inp mem .dim = (d : ℤ) := rfl
@[simp] theorem iValAt_intParam {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e : IntExpr) :
    iValAt fd inp mem (.intParam e) = listGetIntD inp.intParams (iValAt fd inp mem e) 0 := rfl
@[simp] theorem iValAt_readHeap {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (t : ℕ) (e : IntExpr) :
    iValAt fd inp mem (.readHeap t e) = wRead mem t (iValAt fd inp mem e) := rfl
@[simp] theorem iValAt_readLocal {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (v : ℕ) (e : IntExpr) :
    iValAt fd inp mem (.readLocal v e) = wReadL fd mem v (iValAt fd inp mem e) := rfl
@[simp] theorem iValAt_neg {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e : IntExpr) : iValAt fd inp mem (.neg e) = -iValAt fd inp mem e := rfl
@[simp] theorem iValAt_add {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e₁ e₂ : IntExpr) :
    iValAt fd inp mem (.add e₁ e₂) = iValAt fd inp mem e₁ + iValAt fd inp mem e₂ := rfl
@[simp] theorem iValAt_sub {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e₁ e₂ : IntExpr) :
    iValAt fd inp mem (.sub e₁ e₂) = iValAt fd inp mem e₁ - iValAt fd inp mem e₂ := rfl
@[simp] theorem iValAt_mul {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e₁ e₂ : IntExpr) :
    iValAt fd inp mem (.mul e₁ e₂) = iValAt fd inp mem e₁ * iValAt fd inp mem e₂ := rfl
@[simp] theorem iValAt_div {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e₁ e₂ : IntExpr) :
    iValAt fd inp mem (.div e₁ e₂) = iValAt fd inp mem e₁ / iValAt fd inp mem e₂ := rfl
@[simp] theorem iValAt_mod {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e₁ e₂ : IntExpr) :
    iValAt fd inp mem (.mod e₁ e₂) = iValAt fd inp mem e₁ % iValAt fd inp mem e₂ := rfl

@[simp] theorem rValAt_ofInt {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e : IntExpr) : rValAt fd inp mem (.ofInt e) = (iValAt fd inp mem e : ℝ) := rfl
@[simp] theorem rValAt_readRealHeap {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (t : ℕ) (e : IntExpr) :
    rValAt fd inp mem (.readRealHeap t e) = rRead mem t (iValAt fd inp mem e) := rfl
@[simp] theorem rValAt_readRealLocal {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (v : ℕ) (e : IntExpr) :
    rValAt fd inp mem (.readRealLocal v e) = rReadL fd mem v (iValAt fd inp mem e) := rfl
@[simp] theorem rValAt_extraReal {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e : IntExpr) :
    rValAt fd inp mem (.extraReal e) = listGetIntD inp.extraReals (iValAt fd inp mem e) 0 := rfl
@[simp] theorem rValAt_activePtCoord {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (hE cE : IntExpr) :
    rValAt fd inp mem (.activePtCoord hE cE) =
      (let h := iValAt fd inp mem hE
       let c := iValAt fd inp mem cE
       if _hh : 0 ≤ h ∧ h.toNat ∈ inp.activeHandles then
         if hc : 0 ≤ c ∧ c.toNat < d then
           euclideanCoord (inp.activeCoords h.toNat) ⟨c.toNat, hc.2⟩
         else 0
       else 0) := rfl
@[simp] theorem rValAt_neg {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (r : RealExpr) : rValAt fd inp mem (.neg r) = -rValAt fd inp mem r := rfl
@[simp] theorem rValAt_add {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (r₁ r₂ : RealExpr) :
    rValAt fd inp mem (.add r₁ r₂) = rValAt fd inp mem r₁ + rValAt fd inp mem r₂ := rfl
@[simp] theorem rValAt_sub {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (r₁ r₂ : RealExpr) :
    rValAt fd inp mem (.sub r₁ r₂) = rValAt fd inp mem r₁ - rValAt fd inp mem r₂ := rfl
@[simp] theorem rValAt_mul {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (r₁ r₂ : RealExpr) :
    rValAt fd inp mem (.mul r₁ r₂) = rValAt fd inp mem r₁ * rValAt fd inp mem r₂ := rfl
@[simp] theorem rValAt_div {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (r₁ r₂ : RealExpr) :
    rValAt fd inp mem (.div r₁ r₂) = rValAt fd inp mem r₁ / rValAt fd inp mem r₂ := rfl

@[simp] theorem cValAt_intEq {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e₁ e₂ : IntExpr) :
    cValAt fd inp mem (.intEq e₁ e₂) = decide (iValAt fd inp mem e₁ = iValAt fd inp mem e₂) := rfl
@[simp] theorem cValAt_intLt {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e₁ e₂ : IntExpr) :
    cValAt fd inp mem (.intLt e₁ e₂) = decide (iValAt fd inp mem e₁ < iValAt fd inp mem e₂) := rfl
@[simp] theorem cValAt_intLe {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (e₁ e₂ : IntExpr) :
    cValAt fd inp mem (.intLe e₁ e₂) = decide (iValAt fd inp mem e₁ ≤ iValAt fd inp mem e₂) := rfl
@[simp] theorem cValAt_realEq {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (r₁ r₂ : RealExpr) :
    cValAt fd inp mem (.realEq r₁ r₂) =
      (open Classical in decide (rValAt fd inp mem r₁ = rValAt fd inp mem r₂)) := rfl
@[simp] theorem cValAt_realLt {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (r₁ r₂ : RealExpr) :
    cValAt fd inp mem (.realLt r₁ r₂) =
      (open Classical in decide (rValAt fd inp mem r₁ < rValAt fd inp mem r₂)) := rfl
@[simp] theorem cValAt_realLe {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (r₁ r₂ : RealExpr) :
    cValAt fd inp mem (.realLe r₁ r₂) =
      (open Classical in decide (rValAt fd inp mem r₁ ≤ rValAt fd inp mem r₂)) := rfl
@[simp] theorem cValAt_not {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (c : ArithCondExpr) : cValAt fd inp mem (.not c) = !(cValAt fd inp mem c) := rfl
@[simp] theorem cValAt_and {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (c₁ c₂ : ArithCondExpr) :
    cValAt fd inp mem (.and c₁ c₂) = (cValAt fd inp mem c₁ && cValAt fd inp mem c₂) := rfl
@[simp] theorem cValAt_or {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (c₁ c₂ : ArithCondExpr) :
    cValAt fd inp mem (.or c₁ c₂) = (cValAt fd inp mem c₁ || cValAt fd inp mem c₂) := rfl


/-! ### 3. Universal operational-semantics theorems: fuel, cost, peak space, prefix-freeness -/

theorem runArithRAMFuel_mono {d : ℕ} (inp : ArithRAMInput d) :
    ∀ {fuel₁ fuel₂ : ℕ} {stack : List ArithRAMCont} {st : ArithRAMExecState}
      {res : ArithRAMRunStatus},
      res ≠ .outOfFuel →
      fuel₁ ≤ fuel₂ →
      runArithRAMFuel inp fuel₁ stack st = res →
      runArithRAMFuel inp fuel₂ stack st = res
  | f₁, f₂, [], st, res, _, _, hrun => by
      cases f₁ <;> cases f₂ <;> simpa [runArithRAMFuel] using hrun
  | 0, _, _ :: _, _, res, hne, _, hrun => by
      simp [runArithRAMFuel] at hrun
      exact absurd hrun.symm hne
  | _ + 1, 0, _ :: _, _, _, _, hle, _ => by omega
  | f₁ + 1, f₂ + 1, item :: rest, st, res, hne, hle, hrun => by
      have hle' : f₁ ≤ f₂ := by omega
      cases item with
      | popScope prev =>
          simp only [runArithRAMFuel] at hrun ⊢
          exact runArithRAMFuel_mono inp hne hle' hrun
      | repeatLoop rem body =>
          cases rem <;> {
            simp only [runArithRAMFuel] at hrun ⊢
            exact runArithRAMFuel_mono inp hne hle' hrun
          }
      | stmt s =>
          cases s with
          | skip | writeWordHeap _ _ _ | writeWordLocal _ _ _ | freeWordHeap _ _
          | freeWordLocal _ _ | writeRealHeap _ _ _ | writeRealLocal _ _ _
          | freeRealHeap _ _ | freeRealLocal _ _ | seq _ _ | ite _ _ _
          | whileLoop _ _ | repeatN _ _ | localScope _ =>
              simp only [runArithRAMFuel] at hrun ⊢
              exact runArithRAMFuel_mono inp hne hle' hrun
          | randBitHeap table idxE =>
              cases hbits : st.remainingBits with
              | nil => simpa [runArithRAMFuel, hbits] using hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun ⊢
                  exact runArithRAMFuel_mono inp hne hle' hrun
          | randBitLocal var idxE =>
              cases hbits : st.remainingBits with
              | nil => simpa [runArithRAMFuel, hbits] using hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun ⊢
                  exact runArithRAMFuel_mono inp hne hle' hrun

theorem runArithRAMFuel_unitCost_mono {d : ℕ} (inp : ArithRAMInput d) :
    ∀ {fuel : ℕ} {stack : List ArithRAMCont} {st : ArithRAMExecState}
      {out : ArithRAMExecOutcome},
      runArithRAMFuel inp fuel stack st = .halted out →
      st.unitCost ≤ out.unitCost
  | fuel, [], st, out, hrun => by
      cases fuel <;> {
        cases hrem : st.remainingBits.isEmpty
        · simp [runArithRAMFuel, hrem] at hrun
        · simp [runArithRAMFuel, hrem] at hrun
          subst hrun; exact le_rfl
      }
  | 0, _ :: _, _, _, hrun => by simp [runArithRAMFuel] at hrun
  | fuel + 1, item :: rest, st, out, hrun => by
      cases item with
      | popScope prev =>
          simp only [runArithRAMFuel] at hrun
          simpa using runArithRAMFuel_unitCost_mono inp hrun
      | repeatLoop rem body =>
          cases rem <;> {
            simp only [runArithRAMFuel] at hrun
            simpa using runArithRAMFuel_unitCost_mono inp hrun
          }
      | stmt s =>
          cases s with
          | skip | writeWordHeap _ _ _ | writeWordLocal _ _ _ | freeWordHeap _ _
          | freeWordLocal _ _ | writeRealHeap _ _ _ | writeRealLocal _ _ _
          | freeRealHeap _ _ | freeRealLocal _ _ | ite _ _ _
          | whileLoop _ _ | repeatN _ _ =>
              simp only [runArithRAMFuel] at hrun
              have ih := runArithRAMFuel_unitCost_mono inp hrun
              dsimp only at ih
              omega
          | seq _ _ | localScope _ =>
              simp only [runArithRAMFuel] at hrun
              simpa using runArithRAMFuel_unitCost_mono inp hrun
          | randBitHeap _ _ =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  have ih := runArithRAMFuel_unitCost_mono inp hrun
                  dsimp only at ih; omega
          | randBitLocal _ _ =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  have ih := runArithRAMFuel_unitCost_mono inp hrun
                  dsimp only at ih; omega

theorem runArithRAMFuel_peak_bound {d : ℕ} (inp : ArithRAMInput d) :
    ∀ {fuel : ℕ} {stack : List ArithRAMCont} {st : ArithRAMExecState}
      {out : ArithRAMExecOutcome},
      runArithRAMFuel inp fuel stack st = .halted out →
      out.peakCellSpace ≤
        max st.peakCellSpace (inp.inputCellSpace + st.mem.cellCount) +
          (out.unitCost - st.unitCost)
  | fuel, [], st, out, hrun => by
      cases fuel <;> {
        cases hrem : st.remainingBits.isEmpty
        · simp [runArithRAMFuel, hrem] at hrun
        · simp [runArithRAMFuel, hrem] at hrun
          subst hrun; dsimp only; omega
      }
  | 0, _ :: _, _, _, hrun => by simp [runArithRAMFuel] at hrun
  | fuel + 1, item :: rest, st, out, hrun => by
      cases item with
      | popScope prev =>
          simp only [runArithRAMFuel] at hrun
          have ih := runArithRAMFuel_peak_bound inp hrun
          have hcc := cellCount_popDepth_le st.mem prev
          dsimp only at ih; omega
      | repeatLoop rem body =>
          cases rem <;> {
            simp only [runArithRAMFuel] at hrun
            exact runArithRAMFuel_peak_bound inp hrun
          }
      | stmt s =>
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              dsimp only at hu ih; omega
          | writeWordHeap table idxE valE =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              have hw := mem_cellCount_writeWord_le st.mem
                (.heap table (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
                (evalIntExpr inp.toWordView st.frameDepth st.mem.words valE).1
              dsimp only at hu ih; omega
          | writeWordLocal var idxE valE =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              have hw := mem_cellCount_writeWord_le st.mem
                (.localFrame st.frameDepth var
                  (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
                (evalIntExpr inp.toWordView st.frameDepth st.mem.words valE).1
              dsimp only at hu ih; omega
          | freeWordHeap table idxE =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              have hw := mem_cellCount_freeWord_le st.mem
                (.heap table (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
              dsimp only at hu ih; omega
          | freeWordLocal var idxE =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              have hw := mem_cellCount_freeWord_le st.mem
                (.localFrame st.frameDepth var
                  (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
              dsimp only at hu ih; omega
          | writeRealHeap table idxE valE =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              have hr := mem_cellCount_writeReal_le st.mem
                (.heap table (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
                (evalRealExpr inp st.frameDepth st.mem valE).1
              dsimp only at hu ih; omega
          | writeRealLocal var idxE valE =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              have hr := mem_cellCount_writeReal_le st.mem
                (.localFrame st.frameDepth var
                  (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
                (evalRealExpr inp st.frameDepth st.mem valE).1
              dsimp only at hu ih; omega
          | freeRealHeap table idxE =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              have hr := mem_cellCount_freeReal_le st.mem
                (.heap table (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
              dsimp only at hu ih; omega
          | freeRealLocal var idxE =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              have hr := mem_cellCount_freeReal_le st.mem
                (.localFrame st.frameDepth var
                  (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
              dsimp only at hu ih; omega
          | randBitHeap table idxE =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  have hu := runArithRAMFuel_unitCost_mono inp hrun
                  have ih := runArithRAMFuel_peak_bound inp hrun
                  have hw := mem_cellCount_writeWord_le st.mem
                    (.heap table (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
                    (if bit then 1 else 0)
                  dsimp only at hu ih; omega
          | randBitLocal var idxE =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  have hu := runArithRAMFuel_unitCost_mono inp hrun
                  have ih := runArithRAMFuel_peak_bound inp hrun
                  have hw := mem_cellCount_writeWord_le st.mem
                    (.localFrame st.frameDepth var
                      (evalIntExpr inp.toWordView st.frameDepth st.mem.words idxE).1)
                    (if bit then 1 else 0)
                  dsimp only at hu ih; omega
          | seq _ _ =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_peak_bound inp hrun
          | ite _ _ _ | whileLoop _ _ | repeatN _ _ =>
              simp only [runArithRAMFuel] at hrun
              have hu := runArithRAMFuel_unitCost_mono inp hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              dsimp only at hu ih; omega
          | localScope _ =>
              simp only [runArithRAMFuel] at hrun
              have ih := runArithRAMFuel_peak_bound inp hrun
              have hcc := cellCount_popDepth_le st.mem st.frameDepth
              dsimp only at ih; omega

theorem runArithRAMWithBits_peakCellSpace_le {d : ℕ} {prog : ArithRAMStmt}
    {inp : ArithRAMInput d} {initMem : ArithRAMMemory} {bs : List Bool}
    {out : ArithRAMExecOutcome}
    (h : runArithRAMWithBits prog inp initMem bs = some out) :
    out.peakCellSpace ≤ inp.inputCellSpace + initMem.cellCount + out.unitCost := by
  classical
  unfold runArithRAMWithBits at h
  dsimp only at h
  split_ifs at h with hex
  · generalize hres : runArithRAMFuel inp (Nat.find hex) [.stmt prog] _ = res at h
    cases res with
    | halted o =>
        cases h
        have hpk := runArithRAMFuel_peak_bound inp hres
        have hcc := cellCount_popDepth_le initMem 0
        dsimp only at hpk
        omega
    | needMoreBits | unusedBits | outOfFuel => simp at h

theorem runArithRAMFuel_append_unused {d : ℕ} (inp : ArithRAMInput d) :
    ∀ {fuel : ℕ} {stack : List ArithRAMCont} {st : ArithRAMExecState}
      {out : ArithRAMExecOutcome} {extra : List Bool},
      runArithRAMFuel inp fuel stack st = .halted out →
      extra ≠ [] →
      runArithRAMFuel inp fuel stack { st with remainingBits := st.remainingBits ++ extra } =
        .unusedBits
  | fuel, [], st, out, extra, hrun, hextra => by
      cases fuel <;> {
        cases hrem : st.remainingBits.isEmpty
        · simp [runArithRAMFuel, hrem] at hrun
        · have hnil : st.remainingBits = [] := List.isEmpty_iff.mp hrem
          have hne : (st.remainingBits ++ extra).isEmpty = false := by
            rw [hnil, List.nil_append]
            cases extra with
            | nil => exact absurd rfl hextra
            | cons _ _ => rfl
          simp [runArithRAMFuel, hne]
      }
  | 0, _ :: _, _, _, _, hrun, _ => by simp [runArithRAMFuel] at hrun
  | fuel + 1, item :: rest, st, out, extra, hrun, hextra => by
      cases item with
      | popScope prev =>
          simp only [runArithRAMFuel] at hrun ⊢
          simpa using runArithRAMFuel_append_unused inp hrun hextra
      | repeatLoop rem body =>
          cases rem <;> {
            simp only [runArithRAMFuel] at hrun ⊢
            simpa using runArithRAMFuel_append_unused inp hrun hextra
          }
      | stmt s =>
          cases s with
          | skip | writeWordHeap _ _ _ | writeWordLocal _ _ _ | freeWordHeap _ _
          | freeWordLocal _ _ | writeRealHeap _ _ _ | writeRealLocal _ _ _
          | freeRealHeap _ _ | freeRealLocal _ _ | seq _ _ | ite _ _ _
          | whileLoop _ _ | repeatN _ _ | localScope _ =>
              simp only [runArithRAMFuel] at hrun ⊢
              simpa using runArithRAMFuel_append_unused inp hrun hextra
          | randBitHeap _ _ =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits, List.cons_append] at hrun ⊢
                  simpa using runArithRAMFuel_append_unused inp hrun hextra
          | randBitLocal _ _ =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits, List.cons_append] at hrun ⊢
                  simpa using runArithRAMFuel_append_unused inp hrun hextra

theorem runArithRAMWithBits_eq_some_of_fuel {d : ℕ} (prog : ArithRAMStmt)
    (inp : ArithRAMInput d) (initMem : ArithRAMMemory) (bs : List Bool)
    (fuel : ℕ) (out : ArithRAMExecOutcome)
    (hrun : runArithRAMFuel inp fuel [.stmt prog]
      { mem := initMem.popDepth 0
        frameDepth := 0
        remainingBits := bs
        unitCost := 0
        peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } = .halted out) :
    runArithRAMWithBits prog inp initMem bs = some out := by
  classical
  unfold runArithRAMWithBits
  dsimp only
  have hex : ∃ f : ℕ, ∃ o : ArithRAMExecOutcome,
      runArithRAMFuel inp f [.stmt prog]
        { mem := initMem.popDepth 0, frameDepth := 0, remainingBits := bs,
          unitCost := 0, peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } =
        .halted o := ⟨fuel, out, hrun⟩
  rw [dif_pos hex]
  have hle : Nat.find hex ≤ fuel := Nat.find_min' hex ⟨out, hrun⟩
  rcases Nat.find_spec hex with ⟨o₀, ho₀⟩
  have heq : ArithRAMRunStatus.halted o₀ = .halted out := by
    have hm := runArithRAMFuel_mono inp (by simp) hle ho₀
    rw [hrun] at hm
    exact hm.symm
  cases heq
  simp [ho₀]

theorem runArithRAMWithBits_eq_none_of_status {d : ℕ} (prog : ArithRAMStmt)
    (inp : ArithRAMInput d) (initMem : ArithRAMMemory) (bs : List Bool)
    (fuel : ℕ) (res : ArithRAMRunStatus)
    (hnot_fuel : res ≠ .outOfFuel)
    (hnot_halt : ∀ o, res ≠ .halted o)
    (hrun : runArithRAMFuel inp fuel [.stmt prog]
      { mem := initMem.popDepth 0
        frameDepth := 0
        remainingBits := bs
        unitCost := 0
        peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } = res) :
    runArithRAMWithBits prog inp initMem bs = none := by
  classical
  unfold runArithRAMWithBits
  dsimp only
  split_ifs with hex
  · exfalso
    rcases hex with ⟨f₁, out, hf₁⟩
    have hm₁ := runArithRAMFuel_mono inp (by simp) (Nat.le_max_left f₁ fuel) hf₁
    have hm₂ := runArithRAMFuel_mono inp hnot_fuel (Nat.le_max_right f₁ fuel) hrun
    rw [hm₁] at hm₂
    exact hnot_halt out hm₂.symm
  · rfl

theorem runArithRAMWithBits_prefix_free {d : ℕ} {prog : ArithRAMStmt}
    {inp : ArithRAMInput d} {initMem : ArithRAMMemory}
    {bs₁ bs₂ : List Bool} {out₁ out₂ : ArithRAMExecOutcome}
    (h₁ : runArithRAMWithBits prog inp initMem bs₁ = some out₁)
    (h₂ : runArithRAMWithBits prog inp initMem bs₂ = some out₂)
    (hpref : bs₁ <+: bs₂) :
    bs₁ = bs₂ := by
  classical
  rcases hpref with ⟨extra, rfl⟩
  by_contra hne
  have hextra : extra ≠ [] := by
    intro he; subst he; simp at hne
  unfold runArithRAMWithBits at h₁
  dsimp only at h₁
  split_ifs at h₁ with hex
  · generalize hres : runArithRAMFuel inp (Nat.find hex) [.stmt prog] _ = res at h₁
    cases res with
    | halted o =>
        have hunused := runArithRAMFuel_append_unused inp hres hextra
        have hnone := runArithRAMWithBits_eq_none_of_status prog inp initMem (bs₁ ++ extra)
          (Nat.find hex) .unusedBits (by simp) (by simp) hunused
        rw [hnone] at h₂
        simp at h₂
    | needMoreBits | unusedBits | outOfFuel => simp at h₁

/-- Canonical `DynamicDiameterStructure` induced by `prog : ArithRAMDynamicProgram` and `initOut`,
matching the `let alg := ...` definition in `S_lem_7_2` verbatim. -/
noncomputable def mkArithAlg (d n : ℕ) (prog : ArithRAMDynamicProgram)
    (initOut : ArithRAMExecOutcome) : DynamicDiameterStructure d ArithRAMMemory :=
  { initState := initOut.mem
    initWork := initOut.unitCost
    initSpace := initOut.peakCellSpace
    cachedAnswer := fun mem =>
      let ca := ArithRAMDynamicProgram.readCachedAnswer mem
      { diameterHandles := ca.1, cachedDistSq := ca.2 }
    retrieveIdsAndRefCost := 4
    writeOutputCost := fun L => L + 1
    stepWithBits := fun activeH hCoords mem uop bs =>
      let rawOut :=
        match uop with
        | .insert pt => prog.evalUpdate n activeH hCoords mem true pt 0 bs
        | .delete h => prog.evalUpdate n activeH hCoords mem false 0 h bs
      rawOut.map (fun out =>
        let ca := ArithRAMDynamicProgram.readCachedAnswer out.mem
        { nextState := out.mem
          returnedHandle :=
            match uop with
            | .insert _ => ArithRAMDynamicProgram.readReturnedHandle out.mem
            | .delete _ => none
          storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
          work := out.unitCost
          peakSpace := out.peakCellSpace }) }

theorem mkArithAlg_satisfies_storage_query_model (d n : ℕ)
    (prog : ArithRAMDynamicProgram) (initOut : ArithRAMExecOutcome)
    (hca : ArithRAMDynamicProgram.readCachedAnswer initOut.mem = (none, 0)) :
    SatisfiesDynamicStorageAndQueryModel 4 1 (mkArithAlg d n prog initOut) := by
  refine ⟨?_, ?_, ?_, le_rfl, fun L => by dsimp [mkArithAlg]; omega⟩
  · simp [mkArithAlg, hca]
  · intro activeH hCoords st uop bs out hstep
    simp only [mkArithAlg, Option.map_eq_some_iff] at hstep
    rcases hstep with ⟨raw, _, rfl⟩
    rfl
  · intro activeH hCoords st uop bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
    simp only [mkArithAlg, Option.map_eq_some_iff] at h₁ h₂
    rcases h₁ with ⟨raw₁, hraw₁, _⟩
    rcases h₂ with ⟨raw₂, hraw₂, _⟩
    cases uop with
    | insert pt =>
        exact runArithRAMWithBits_prefix_free hraw₁ hraw₂ hpref
    | delete h =>
        exact runArithRAMWithBits_prefix_free hraw₁ hraw₂ hpref


/-! ### 4. Scoped compositional `DetExecAt` and `RandExecAt` combinators -/

def seqList : List ArithRAMStmt → ArithRAMStmt
  | [] => .skip
  | [s] => s
  | s :: ss => .seq s (seqList ss)

def DetExecAt {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (s : ArithRAMStmt)
    (mem₀ mem₁ : ArithRAMMemory) (costBound : ℕ) : Prop :=
  ∀ (bs : List Bool) (u₀ peak₀ : ℕ) (rest : List ArithRAMCont),
    ∃ (fuel u₁ peak₁ : ℕ),
      u₁ ≤ u₀ + costBound ∧
      ∀ f_rem : ℕ,
        runArithRAMFuel inp (fuel + f_rem) (.stmt s :: rest)
          { mem := mem₀, frameDepth := fd, remainingBits := bs,
            unitCost := u₀, peakCellSpace := peak₀ } =
        runArithRAMFuel inp f_rem rest
          { mem := mem₁, frameDepth := fd, remainingBits := bs,
            unitCost := u₁, peakCellSpace := peak₁ }

abbrev DetExec {d : ℕ} (inp : ArithRAMInput d) (s : ArithRAMStmt)
    (mem₀ mem₁ : ArithRAMMemory) (costBound : ℕ) : Prop :=
  DetExecAt 0 inp s mem₀ mem₁ costBound

theorem DetExecAt.mono_cost {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {mem₀ mem₁ : ArithRAMMemory} {c₁ c₂ : ℕ}
    (h : DetExecAt fd inp s mem₀ mem₁ c₁) (hle : c₁ ≤ c₂) :
    DetExecAt fd inp s mem₀ mem₁ c₂ := by
  intro bs u₀ peak₀ rest
  rcases h bs u₀ peak₀ rest with ⟨fuel, u₁, peak₁, hu₁, hstep⟩
  exact ⟨fuel, u₁, peak₁, by omega, hstep⟩

theorem DetExecAt.eq_mem {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {mem₀ mem₁ mem₂ : ArithRAMMemory} {c : ℕ}
    (h : DetExecAt fd inp s mem₀ mem₁ c) (hm : mem₁ = mem₂) :
    DetExecAt fd inp s mem₀ mem₂ c := hm ▸ h

theorem DetExecAt.skip {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory) :
    DetExecAt fd inp .skip mem mem 1 := by
  intro bs u₀ peak₀ rest
  refine ⟨1, u₀ + 1, peak₀, le_rfl, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  rfl

theorem DetExecAt.writeWordHeap {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (t : ℕ) (idxE valE : IntExpr) {idx val : ℤ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hval : iValAt fd inp mem valE = val)
    (hcost : intExprOps idxE + intExprOps valE + 1 ≤ C) :
    DetExecAt fd inp (.writeWordHeap t idxE valE) mem (wWrite mem t idx val) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, b₁⟩
  rcases he₂ : evalIntExpr inp.toWordView fd mem.words valE with ⟨val', u₂, b₂⟩
  have hi : idx' = idx := by rw [← hidx, iValAt, he₁]
  have hv : val' = val := by rw [← hval, iValAt, he₂]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he₁] at this; exact this
  have hu₂ : u₂ = intExprOps valE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words valE; rw [he₂] at this; exact this
  subst hi; subst hv
  refine ⟨1, u₀ + u₁ + u₂ + 1,
    max peak₀ (inp.inputCellSpace + (wWrite mem t idx' val').cellCount), by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [runArithRAMFuel]
  rw [he₁, he₂]
  rfl

theorem DetExecAt.writeWordLocal {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (v : ℕ) (idxE valE : IntExpr) {idx val : ℤ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hval : iValAt fd inp mem valE = val)
    (hcost : intExprOps idxE + intExprOps valE + 1 ≤ C) :
    DetExecAt fd inp (.writeWordLocal v idxE valE) mem (wWriteL fd mem v idx val) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, b₁⟩
  rcases he₂ : evalIntExpr inp.toWordView fd mem.words valE with ⟨val', u₂, b₂⟩
  have hi : idx' = idx := by rw [← hidx, iValAt, he₁]
  have hv : val' = val := by rw [← hval, iValAt, he₂]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he₁] at this; exact this
  have hu₂ : u₂ = intExprOps valE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words valE; rw [he₂] at this; exact this
  subst hi; subst hv
  refine ⟨1, u₀ + u₁ + u₂ + 1,
    max peak₀ (inp.inputCellSpace + (wWriteL fd mem v idx' val').cellCount),
    by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [runArithRAMFuel]
  rw [he₁, he₂]
  rfl

theorem DetExecAt.freeWordHeap {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (t : ℕ) (idxE : IntExpr) {idx : ℤ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hcost : intExprOps idxE + 1 ≤ C) :
    DetExecAt fd inp (.freeWordHeap t idxE) mem (wFree mem t idx) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, b₁⟩
  have hi : idx' = idx := by rw [← hidx, iValAt, he₁]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he₁] at this; exact this
  subst hi
  refine ⟨1, u₀ + u₁ + 1, peak₀, by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [runArithRAMFuel]
  rw [he₁]
  rfl

theorem DetExecAt.freeWordLocal {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (v : ℕ) (idxE : IntExpr) {idx : ℤ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hcost : intExprOps idxE + 1 ≤ C) :
    DetExecAt fd inp (.freeWordLocal v idxE) mem (wFreeL fd mem v idx) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, b₁⟩
  have hi : idx' = idx := by rw [← hidx, iValAt, he₁]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he₁] at this; exact this
  subst hi
  refine ⟨1, u₀ + u₁ + 1, peak₀, by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [runArithRAMFuel]
  rw [he₁]
  rfl

theorem DetExecAt.writeRealHeap {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (t : ℕ) (idxE : IntExpr) (valE : RealExpr) {idx : ℤ} {val : ℝ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hval : rValAt fd inp mem valE = val)
    (hcost : intExprOps idxE + realExprOps valE + 1 ≤ C) :
    DetExecAt fd inp (.writeRealHeap t idxE valE) mem (rWrite mem t idx val) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, b₁⟩
  rcases he₂ : evalRealExpr inp fd mem valE with ⟨val', u₂⟩
  have hi : idx' = idx := by rw [← hidx, iValAt, he₁]
  have hv : val' = val := by rw [← hval, rValAt, he₂]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he₁] at this; exact this
  have hu₂ : u₂ = realExprOps valE := by
    have := evalRealExpr_ops inp fd mem valE; rw [he₂] at this; exact this
  subst hi; subst hv
  refine ⟨1, u₀ + u₁ + u₂ + 1,
    max peak₀ (inp.inputCellSpace + (rWrite mem t idx' val').cellCount), by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [runArithRAMFuel]
  rw [he₁, he₂]
  rfl

theorem DetExecAt.writeRealLocal {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (v : ℕ) (idxE : IntExpr) (valE : RealExpr) {idx : ℤ} {val : ℝ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hval : rValAt fd inp mem valE = val)
    (hcost : intExprOps idxE + realExprOps valE + 1 ≤ C) :
    DetExecAt fd inp (.writeRealLocal v idxE valE) mem (rWriteL fd mem v idx val) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, b₁⟩
  rcases he₂ : evalRealExpr inp fd mem valE with ⟨val', u₂⟩
  have hi : idx' = idx := by rw [← hidx, iValAt, he₁]
  have hv : val' = val := by rw [← hval, rValAt, he₂]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he₁] at this; exact this
  have hu₂ : u₂ = realExprOps valE := by
    have := evalRealExpr_ops inp fd mem valE; rw [he₂] at this; exact this
  subst hi; subst hv
  refine ⟨1, u₀ + u₁ + u₂ + 1,
    max peak₀ (inp.inputCellSpace + (rWriteL fd mem v idx' val').cellCount),
    by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [runArithRAMFuel]
  rw [he₁, he₂]
  rfl

theorem DetExecAt.freeRealHeap {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (t : ℕ) (idxE : IntExpr) {idx : ℤ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hcost : intExprOps idxE + 1 ≤ C) :
    DetExecAt fd inp (.freeRealHeap t idxE) mem (rFree mem t idx) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, b₁⟩
  have hi : idx' = idx := by rw [← hidx, iValAt, he₁]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he₁] at this; exact this
  subst hi
  refine ⟨1, u₀ + u₁ + 1, peak₀, by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [runArithRAMFuel]
  rw [he₁]
  rfl

theorem DetExecAt.freeRealLocal {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (v : ℕ) (idxE : IntExpr) {idx : ℤ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hcost : intExprOps idxE + 1 ≤ C) :
    DetExecAt fd inp (.freeRealLocal v idxE) mem (rFreeL fd mem v idx) C := by
  intro bs u₀ peak₀ rest
  rcases he₁ : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, b₁⟩
  have hi : idx' = idx := by rw [← hidx, iValAt, he₁]
  have hu₁ : u₁ = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he₁] at this; exact this
  subst hi
  refine ⟨1, u₀ + u₁ + 1, peak₀, by omega, fun f_rem => ?_⟩
  rw [Nat.add_comm 1 f_rem]
  dsimp only [runArithRAMFuel]
  rw [he₁]
  rfl

theorem DetExecAt.seq {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {s₁ s₂ : ArithRAMStmt}
    {mem₀ mem₁ mem₂ : ArithRAMMemory} {C₁ C₂ : ℕ}
    (h₁ : DetExecAt fd inp s₁ mem₀ mem₁ C₁)
    (h₂ : DetExecAt fd inp s₂ mem₁ mem₂ C₂) :
    DetExecAt fd inp (.seq s₁ s₂) mem₀ mem₂ (C₁ + C₂) := by
  intro bs u₀ peak₀ rest
  rcases h₁ bs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  rcases h₂ bs u₁ peak₁ rest with ⟨f₂, u₂, peak₂, hu₂, hs₂⟩
  refine ⟨1 + f₁ + f₂, u₂, peak₂, by omega, fun f_rem => ?_⟩
  have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
  rw [hf]
  dsimp only [runArithRAMFuel]
  rw [hs₁ (f₂ + f_rem), hs₂ f_rem]

theorem DetExecAt.ite_true {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {mem₀ mem₁ : ArithRAMMemory} {C_c C_b : ℕ}
    (hcond : cValAt fd inp mem₀ cond = true)
    (hcc : condExprOps cond ≤ C_c)
    (ht : DetExecAt fd inp tB mem₀ mem₁ C_b) :
    DetExecAt fd inp (.ite cond tB fB) mem₀ mem₁ (C_c + C_b) := by
  intro bs u₀ peak₀ rest
  rcases hc : evalArithCond inp fd mem₀ cond with ⟨flag, u_c⟩
  have hflag : flag = true := by rw [← hcond, cValAt, hc]
  have huc : u_c = condExprOps cond := by
    have := evalArithCond_ops inp fd mem₀ cond; rw [hc] at this; exact this
  subst hflag
  rcases ht bs (u₀ + u_c) peak₀ rest with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  refine ⟨1 + f₁, u₁, peak₁, by omega, fun f_rem => ?_⟩
  have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
  rw [hf]
  simp only [runArithRAMFuel, hc, ↓reduceIte]
  exact hs₁ f_rem

theorem DetExecAt.ite_false {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {mem₀ mem₁ : ArithRAMMemory} {C_c C_b : ℕ}
    (hcond : cValAt fd inp mem₀ cond = false)
    (hcc : condExprOps cond ≤ C_c)
    (hfB : DetExecAt fd inp fB mem₀ mem₁ C_b) :
    DetExecAt fd inp (.ite cond tB fB) mem₀ mem₁ (C_c + C_b) := by
  intro bs u₀ peak₀ rest
  rcases hc : evalArithCond inp fd mem₀ cond with ⟨flag, u_c⟩
  have hflag : flag = false := by rw [← hcond, cValAt, hc]
  have huc : u_c = condExprOps cond := by
    have := evalArithCond_ops inp fd mem₀ cond; rw [hc] at this; exact this
  subst hflag
  rcases hfB bs (u₀ + u_c) peak₀ rest with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  refine ⟨1 + f₁, u₁, peak₁, by omega, fun f_rem => ?_⟩
  have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
  rw [hf]
  simp only [runArithRAMFuel, hc, Bool.false_eq_true, ↓reduceIte]
  exact hs₁ f_rem

theorem DetExecAt.localScope {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {body : ArithRAMStmt}
    {mem₀ mem₁ : ArithRAMMemory} {C : ℕ}
    (hbody : DetExecAt (fd + 1) inp body (mem₀.popDepth fd) mem₁ C) :
    DetExecAt fd inp (.localScope body) mem₀ (mem₁.popDepth fd) C := by
  intro bs u₀ peak₀ rest
  rcases hbody bs u₀ peak₀ (.popScope fd :: rest) with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  refine ⟨f₁ + 2, u₁, peak₁, hu₁, fun f_rem => ?_⟩
  have hf : f₁ + 2 + f_rem = (f₁ + (1 + f_rem)) + 1 := by omega
  rw [hf]
  dsimp only [runArithRAMFuel]
  rw [hs₁ (1 + f_rem)]
  have hf2 : 1 + f_rem = f_rem + 1 := by omega
  rw [hf2]
  rfl


theorem DetExecAt.repeatN_nat {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d}
    (countE : IntExpr) (body : ArithRAMStmt) (N C_cnt C_b : ℕ)
    (Inv : ℕ → ArithRAMMemory → Prop)
    {mem₀ : ArithRAMMemory} (hInv₀ : Inv 0 mem₀)
    (hcnt : iValAt fd inp mem₀ countE = (N : ℤ))
    (hccnt : intExprOps countE ≤ C_cnt)
    (hstep : ∀ i < N, ∀ m, Inv i m → ∃ m', DetExecAt fd inp body m m' C_b ∧ Inv (i + 1) m') :
    ∃ mem_N, Inv N mem_N ∧
      DetExecAt fd inp (.repeatN countE body) mem₀ mem_N (C_cnt + N * C_b) := by
  have hloop : ∀ k : ℕ, k ≤ N → ∀ m, Inv (N - k) m →
      ∃ m_N, Inv N m_N ∧
        ∀ (bs : List Bool) (u₀ peak₀ : ℕ) (rest : List ArithRAMCont),
          ∃ (fuel u₁ peak₁ : ℕ),
            u₁ ≤ u₀ + k * C_b ∧
            ∀ f_rem : ℕ,
              runArithRAMFuel inp (fuel + f_rem) (.repeatLoop k body :: rest)
                { mem := m, frameDepth := fd, remainingBits := bs,
                  unitCost := u₀, peakCellSpace := peak₀ } =
              runArithRAMFuel inp f_rem rest
                { mem := m_N, frameDepth := fd, remainingBits := bs,
                  unitCost := u₁, peakCellSpace := peak₁ } := by
    intro k
    induction k with
    | zero =>
        intro _ m hIm
        rw [Nat.sub_zero] at hIm
        refine ⟨m, hIm, fun bs u₀ peak₀ rest => ⟨1, u₀, peak₀, by simp, fun f_rem => ?_⟩⟩
        rw [Nat.add_comm 1 f_rem]; rfl
    | succ k ih =>
        intro hk m hIm
        have hi_lt : N - (k + 1) < N := by omega
        have hsucc : N - (k + 1) + 1 = N - k := by omega
        rcases hstep (N - (k + 1)) hi_lt m hIm with ⟨m', hbody, hIm'⟩
        rw [hsucc] at hIm'
        rcases ih (by omega) m' hIm' with ⟨m_N, hIm_N, hrest⟩
        refine ⟨m_N, hIm_N, fun bs u₀ peak₀ rest => ?_⟩
        rcases hbody bs u₀ peak₀ (.repeatLoop k body :: rest) with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
        rcases hrest bs u₁ peak₁ rest with ⟨f₂, u₂, peak₂, hu₂, hs₂⟩
        refine ⟨1 + f₁ + f₂, u₂, peak₂, ?_, fun f_rem => ?_⟩
        · have : u₂ ≤ u₀ + C_b + k * C_b := by omega
          calc u₂ ≤ u₀ + C_b + k * C_b := this
            _ = u₀ + (k + 1) * C_b := by ring
        · have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
          rw [hf]; dsimp only [runArithRAMFuel]; rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
  rcases hloop N le_rfl mem₀ (by simpa using hInv₀) with ⟨m_N, hIm_N, hrun⟩
  refine ⟨m_N, hIm_N, fun bs u₀ peak₀ rest => ?_⟩
  rcases he : evalIntExpr inp.toWordView fd mem₀.words countE with ⟨cnt, u_cnt, _⟩
  have hcnt' : cnt = (N : ℤ) := by rw [← hcnt, iValAt, he]
  have hucnt : u_cnt = intExprOps countE := by
    have := evalIntExpr_ops inp.toWordView fd mem₀.words countE; rw [he] at this; exact this
  subst hcnt'
  rcases hrun bs (u₀ + u_cnt) peak₀ rest with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
  refine ⟨1 + f₁, u₁, peak₁, by omega, fun f_rem => ?_⟩
  have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
  rw [hf]
  have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
  simp only [runArithRAMFuel, he, hnIter]
  exact hs₁ f_rem

theorem DetExec.to_spec {d : ℕ} {inp : ArithRAMInput d} {prog : ArithRAMStmt}
    {initMem mem₁ : ArithRAMMemory} {C : ℕ}
    (h : DetExec inp prog (initMem.popDepth 0) mem₁ C) :
    ∃ out : ArithRAMExecOutcome,
      runArithRAMWithBits prog inp initMem [] = some out ∧
      out.unitCost ≤ C ∧
      out.peakCellSpace ≤ inp.inputCellSpace + initMem.cellCount + out.unitCost ∧
      out.mem = mem₁.popDepth 0 := by
  rcases h [] 0 (inp.inputCellSpace + (initMem.popDepth 0).cellCount) [] with
    ⟨f, u₁, pk₁, hu₁, hs⟩
  have hrun : runArithRAMFuel inp (f + 0) [.stmt prog]
      { mem := initMem.popDepth 0, frameDepth := 0, remainingBits := [],
        unitCost := 0, peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } =
      .halted { mem := mem₁.popDepth 0, unitCost := u₁, peakCellSpace := pk₁ } := by
    rw [hs 0]; rfl
  have hsome := runArithRAMWithBits_eq_some_of_fuel prog inp initMem [] (f + 0) _ hrun
  exact ⟨_, hsome, by dsimp only; omega, runArithRAMWithBits_peakCellSpace_le hsome, rfl⟩

def RandExecAt {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (s : ArithRAMStmt) (B : ℕ)
    (mem₀ : ArithRAMMemory) (Post : (Fin B → Bool) → ArithRAMMemory → Prop)
    (costBound : ℕ) : Prop :=
  (∀ (bs : List Bool), bs.length < B → ∀ (u₀ peak₀ : ℕ) (rest : List ArithRAMCont),
    ∃ fuel : ℕ, ∀ f_rem : ℕ,
      runArithRAMFuel inp (fuel + f_rem) (.stmt s :: rest)
        { mem := mem₀, frameDepth := fd, remainingBits := bs,
          unitCost := u₀, peakCellSpace := peak₀ } = .needMoreBits) ∧
  (∀ (bs : List Bool) (hbs : B ≤ bs.length) (u₀ peak₀ : ℕ) (rest : List ArithRAMCont),
    ∃ (fuel u₁ peak₁ : ℕ) (mem₁ : ArithRAMMemory),
      u₁ ≤ u₀ + costBound ∧
      Post (fun i : Fin B => bs[i.val]'(lt_of_lt_of_le i.isLt hbs)) mem₁ ∧
      ∀ f_rem : ℕ,
        runArithRAMFuel inp (fuel + f_rem) (.stmt s :: rest)
          { mem := mem₀, frameDepth := fd, remainingBits := bs,
            unitCost := u₀, peakCellSpace := peak₀ } =
        runArithRAMFuel inp f_rem rest
          { mem := mem₁, frameDepth := fd, remainingBits := bs.drop B,
            unitCost := u₁, peakCellSpace := peak₁ })

abbrev RandExec {d : ℕ} (inp : ArithRAMInput d) (s : ArithRAMStmt) (B : ℕ)
    (mem₀ : ArithRAMMemory) (Post : (Fin B → Bool) → ArithRAMMemory → Prop)
    (costBound : ℕ) : Prop :=
  RandExecAt 0 inp s B mem₀ Post costBound

theorem RandExecAt.mono {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {B : ℕ} {mem₀ : ArithRAMMemory}
    {Post₁ Post₂ : (Fin B → Bool) → ArithRAMMemory → Prop} {C₁ C₂ : ℕ}
    (h : RandExecAt fd inp s B mem₀ Post₁ C₁)
    (hPost : ∀ f m, Post₁ f m → Post₂ f m)
    (hC : C₁ ≤ C₂) :
    RandExecAt fd inp s B mem₀ Post₂ C₂ := by
  refine ⟨h.1, fun bs hbs u₀ peak₀ rest => ?_⟩
  rcases h.2 bs hbs u₀ peak₀ rest with ⟨f, u₁, pk₁, m₁, hu₁, hp₁, hs⟩
  exact ⟨f, u₁, pk₁, m₁, by omega, hPost _ _ hp₁, hs⟩

theorem RandExecAt.congr_bits {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {B₁ B₂ : ℕ} {mem₀ : ArithRAMMemory}
    {Post₁ : (Fin B₁ → Bool) → ArithRAMMemory → Prop}
    {Post₂ : (Fin B₂ → Bool) → ArithRAMMemory → Prop} {C : ℕ}
    (h : RandExecAt fd inp s B₁ mem₀ Post₁ C)
    (heq : B₁ = B₂)
    (hPost : ∀ (f : Fin B₂ → Bool) (m : ArithRAMMemory),
      Post₁ (fun i : Fin B₁ => f ⟨i.val, heq ▸ i.isLt⟩) m → Post₂ f m) :
    RandExecAt fd inp s B₂ mem₀ Post₂ C := by
  subst heq
  exact h.mono hPost le_rfl

theorem RandExecAt.of_det {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {mem₀ mem₁ : ArithRAMMemory} {C : ℕ}
    (h : DetExecAt fd inp s mem₀ mem₁ C) :
    RandExecAt fd inp s 0 mem₀ (fun _ m => m = mem₁) C := by
  refine ⟨fun bs hbs => by omega, fun bs _ u₀ peak₀ rest => ?_⟩
  rcases h bs u₀ peak₀ rest with ⟨f, u₁, pk₁, hu₁, hs⟩
  exact ⟨f, u₁, pk₁, mem₁, hu₁, rfl, fun f_rem => by simpa using hs f_rem⟩

theorem RandExecAt.randBitHeap {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (t : ℕ) (idxE : IntExpr) {idx : ℤ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hcost : intExprOps idxE + 1 ≤ C) :
    RandExecAt fd inp (.randBitHeap t idxE) 1 mem
      (fun f m' => m' = wWrite mem t idx (if f ⟨0, Nat.zero_lt_one⟩ then 1 else 0)) C := by
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ rest
    cases bs with
    | nil => exact ⟨1, fun f_rem => by rw [Nat.add_comm 1 f_rem]; rfl⟩
    | cons _ _ => simp at hbs
  · intro bs hbs u₀ peak₀ rest
    cases bs with
    | nil => simp at hbs
    | cons bit bs' =>
        rcases he : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, _⟩
        have hi : idx' = idx := by rw [← hidx, iValAt, he]
        have hu₁ : u₁ = intExprOps idxE := by
          have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he] at this; exact this
        subst hi
        let m' := wWrite mem t idx' (if bit then 1 else 0)
        refine ⟨1, u₀ + u₁ + 1, max peak₀ (inp.inputCellSpace + m'.cellCount), m',
          by omega, rfl, fun f_rem => ?_⟩
        rw [Nat.add_comm 1 f_rem]
        dsimp only [runArithRAMFuel, List.drop]
        rw [he]
        rfl

theorem RandExecAt.randBitLocal {d : ℕ} (fd : ℕ) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (v : ℕ) (idxE : IntExpr) {idx : ℤ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hcost : intExprOps idxE + 1 ≤ C) :
    RandExecAt fd inp (.randBitLocal v idxE) 1 mem
      (fun f m' => m' = wWriteL fd mem v idx (if f ⟨0, Nat.zero_lt_one⟩ then 1 else 0)) C := by
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ rest
    cases bs with
    | nil => exact ⟨1, fun f_rem => by rw [Nat.add_comm 1 f_rem]; rfl⟩
    | cons _ _ => simp at hbs
  · intro bs hbs u₀ peak₀ rest
    cases bs with
    | nil => simp at hbs
    | cons bit bs' =>
        rcases he : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx', u₁, _⟩
        have hi : idx' = idx := by rw [← hidx, iValAt, he]
        have hu₁ : u₁ = intExprOps idxE := by
          have := evalIntExpr_ops inp.toWordView fd mem.words idxE; rw [he] at this; exact this
        subst hi
        let m' := wWriteL fd mem v idx' (if bit then 1 else 0)
        refine ⟨1, u₀ + u₁ + 1, max peak₀ (inp.inputCellSpace + m'.cellCount), m',
          by omega, rfl, fun f_rem => ?_⟩
        rw [Nat.add_comm 1 f_rem]
        dsimp only [runArithRAMFuel, List.drop]
        rw [he]
        rfl

theorem RandExecAt.seq {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d}
    {s₁ s₂ : ArithRAMStmt} {B₁ B₂ : ℕ} {mem₀ : ArithRAMMemory}
    {Post₁ : (Fin B₁ → Bool) → ArithRAMMemory → Prop}
    {Post₂ : (Fin (B₁ + B₂) → Bool) → ArithRAMMemory → Prop} {C₁ C₂ : ℕ}
    (h₁ : RandExecAt fd inp s₁ B₁ mem₀ Post₁ C₁)
    (h₂ : ∀ f₁ m₁, Post₁ f₁ m₁ →
      RandExecAt fd inp s₂ B₂ m₁
        (fun f₂ m₂ =>
          Post₂ (fun j : Fin (B₁ + B₂) =>
            if hj : j.val < B₁ then f₁ ⟨j.val, hj⟩
            else f₂ ⟨j.val - B₁, by omega⟩) m₂) C₂) :
    RandExecAt fd inp (.seq s₁ s₂) (B₁ + B₂) mem₀ Post₂ (C₁ + C₂) := by
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ rest
    by_cases hb₁ : bs.length < B₁
    · rcases h₁.1 bs hb₁ u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, hs₁⟩
      refine ⟨1 + f₁, fun f_rem => ?_⟩
      have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
      rw [hf]; dsimp only [runArithRAMFuel]; exact hs₁ f_rem
    · have hge₁ : B₁ ≤ bs.length := by omega
      rcases h₁.2 bs hge₁ u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, pk₁, m₁, _, hp₁, hs₁⟩
      have hlt₂ : (bs.drop B₁).length < B₂ := by simp; omega
      rcases (h₂ _ m₁ hp₁).1 (bs.drop B₁) hlt₂ u₁ pk₁ rest with ⟨f₂, hs₂⟩
      refine ⟨1 + f₁ + f₂, fun f_rem => ?_⟩
      have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
      rw [hf]; dsimp only [runArithRAMFuel]; rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
  · intro bs hbs u₀ peak₀ rest
    have hge₁ : B₁ ≤ bs.length := by omega
    rcases h₁.2 bs hge₁ u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, pk₁, m₁, hu₁, hp₁, hs₁⟩
    have hge₂ : B₂ ≤ (bs.drop B₁).length := by simp; omega
    rcases (h₂ _ m₁ hp₁).2 (bs.drop B₁) hge₂ u₁ pk₁ rest with
      ⟨f₂, u₂, pk₂, m₂, hu₂, hp₂, hs₂⟩
    refine ⟨1 + f₁ + f₂, u₂, pk₂, m₂, by omega, ?_, fun f_rem => ?_⟩
    · convert hp₂ using 1
      ext j
      by_cases hj : j.val < B₁
      · simp [hj]
      · simp [hj, List.getElem_drop]
        congr 1; omega
    · have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
      rw [hf]; dsimp only [runArithRAMFuel]
      rw [hs₁ (f₂ + f_rem), hs₂ f_rem, List.drop_drop]

theorem RandExecAt.seq_det_left {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d}
    {s₁ s₂ : ArithRAMStmt} {B : ℕ} {mem₀ mem₁ : ArithRAMMemory}
    {Post : (Fin B → Bool) → ArithRAMMemory → Prop} {C₁ C₂ : ℕ}
    (h₁ : DetExecAt fd inp s₁ mem₀ mem₁ C₁)
    (h₂ : RandExecAt fd inp s₂ B mem₁ Post C₂) :
    RandExecAt fd inp (.seq s₁ s₂) B mem₀ Post (C₁ + C₂) := by
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ rest
    rcases h₁ bs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, peak₁, _, hs₁⟩
    rcases h₂.1 bs hbs u₁ peak₁ rest with ⟨f₂, hs₂⟩
    refine ⟨1 + f₁ + f₂, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
    rw [hf]; dsimp only [runArithRAMFuel]; rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
  · intro bs hbs u₀ peak₀ rest
    rcases h₁ bs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, peak₁, hu₁, hs₁⟩
    rcases h₂.2 bs hbs u₁ peak₁ rest with ⟨f₂, u₂, pk₂, mem₂, hu₂, hp₂, hs₂⟩
    refine ⟨1 + f₁ + f₂, u₂, pk₂, mem₂, by omega, hp₂, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
    rw [hf]; dsimp only [runArithRAMFuel]; rw [hs₁ (f₂ + f_rem), hs₂ f_rem]

theorem RandExecAt.seq_det_right {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d}
    {s₁ s₂ : ArithRAMStmt} {B : ℕ} {mem₀ : ArithRAMMemory}
    {Post₁ Post₂ : (Fin B → Bool) → ArithRAMMemory → Prop} {C₁ C₂ : ℕ}
    (h₁ : RandExecAt fd inp s₁ B mem₀ Post₁ C₁)
    (h₂ : ∀ f m₁, Post₁ f m₁ → ∃ m₂, DetExecAt fd inp s₂ m₁ m₂ C₂ ∧ Post₂ f m₂) :
    RandExecAt fd inp (.seq s₁ s₂) B mem₀ Post₂ (C₁ + C₂) := by
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ rest
    rcases h₁.1 bs hbs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, hs₁⟩
    refine ⟨1 + f₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]; dsimp only [runArithRAMFuel]; exact hs₁ f_rem
  · intro bs hbs u₀ peak₀ rest
    rcases h₁.2 bs hbs u₀ peak₀ (.stmt s₂ :: rest) with ⟨f₁, u₁, pk₁, mem₁, hu₁, hp₁, hs₁⟩
    rcases h₂ _ mem₁ hp₁ with ⟨mem₂, hd₂, hp₂⟩
    rcases hd₂ (bs.drop B) u₁ pk₁ rest with ⟨f₂, u₂, pk₂, hu₂, hs₂⟩
    refine ⟨1 + f₁ + f₂, u₂, pk₂, mem₂, by omega, hp₂, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
    rw [hf]; dsimp only [runArithRAMFuel]; rw [hs₁ (f₂ + f_rem), hs₂ f_rem]

theorem RandExecAt.ite_true {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {B : ℕ} {mem₀ : ArithRAMMemory}
    {Post : (Fin B → Bool) → ArithRAMMemory → Prop} {C_c C_b : ℕ}
    (hcond : cValAt fd inp mem₀ cond = true)
    (hcc : condExprOps cond ≤ C_c)
    (ht : RandExecAt fd inp tB B mem₀ Post C_b) :
    RandExecAt fd inp (.ite cond tB fB) B mem₀ Post (C_c + C_b) := by
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ rest
    rcases hc : evalArithCond inp fd mem₀ cond with ⟨flag, u_c⟩
    have hflag : flag = true := by rw [← hcond, cValAt, hc]
    subst hflag
    rcases ht.1 bs hbs (u₀ + u_c) peak₀ rest with ⟨f₁, hs₁⟩
    refine ⟨1 + f₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]; simp only [runArithRAMFuel, hc, ↓reduceIte]; exact hs₁ f_rem
  · intro bs hbs u₀ peak₀ rest
    rcases hc : evalArithCond inp fd mem₀ cond with ⟨flag, u_c⟩
    have hflag : flag = true := by rw [← hcond, cValAt, hc]
    have huc : u_c = condExprOps cond := by
      have := evalArithCond_ops inp fd mem₀ cond; rw [hc] at this; exact this
    subst hflag
    rcases ht.2 bs hbs (u₀ + u_c) peak₀ rest with ⟨f₁, u₁, pk₁, m₁, hu₁, hp₁, hs₁⟩
    refine ⟨1 + f₁, u₁, pk₁, m₁, by omega, hp₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]; simp only [runArithRAMFuel, hc, ↓reduceIte]; exact hs₁ f_rem

theorem RandExecAt.ite_false {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {B : ℕ} {mem₀ : ArithRAMMemory}
    {Post : (Fin B → Bool) → ArithRAMMemory → Prop} {C_c C_b : ℕ}
    (hcond : cValAt fd inp mem₀ cond = false)
    (hcc : condExprOps cond ≤ C_c)
    (hfB : RandExecAt fd inp fB B mem₀ Post C_b) :
    RandExecAt fd inp (.ite cond tB fB) B mem₀ Post (C_c + C_b) := by
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ rest
    rcases hc : evalArithCond inp fd mem₀ cond with ⟨flag, u_c⟩
    have hflag : flag = false := by rw [← hcond, cValAt, hc]
    subst hflag
    rcases hfB.1 bs hbs (u₀ + u_c) peak₀ rest with ⟨f₁, hs₁⟩
    refine ⟨1 + f₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]; simp only [runArithRAMFuel, hc, Bool.false_eq_true, ↓reduceIte]; exact hs₁ f_rem
  · intro bs hbs u₀ peak₀ rest
    rcases hc : evalArithCond inp fd mem₀ cond with ⟨flag, u_c⟩
    have hflag : flag = false := by rw [← hcond, cValAt, hc]
    have huc : u_c = condExprOps cond := by
      have := evalArithCond_ops inp fd mem₀ cond; rw [hc] at this; exact this
    subst hflag
    rcases hfB.2 bs hbs (u₀ + u_c) peak₀ rest with ⟨f₁, u₁, pk₁, m₁, hu₁, hp₁, hs₁⟩
    refine ⟨1 + f₁, u₁, pk₁, m₁, by omega, hp₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]; simp only [runArithRAMFuel, hc, Bool.false_eq_true, ↓reduceIte]; exact hs₁ f_rem

theorem RandExecAt.localScope {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d} {body : ArithRAMStmt}
    {B : ℕ} {mem₀ : ArithRAMMemory}
    {Post : (Fin B → Bool) → ArithRAMMemory → Prop} {C : ℕ}
    (hbody : RandExecAt (fd + 1) inp body B (mem₀.popDepth fd) Post C) :
    RandExecAt fd inp (.localScope body) B mem₀
      (fun f m' => ∃ m₁, Post f m₁ ∧ m' = m₁.popDepth fd) C := by
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ rest
    rcases hbody.1 bs hbs u₀ peak₀ (.popScope fd :: rest) with ⟨f₁, hs₁⟩
    refine ⟨1 + f₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]; dsimp only [runArithRAMFuel]; exact hs₁ f_rem
  · intro bs hbs u₀ peak₀ rest
    rcases hbody.2 bs hbs u₀ peak₀ (.popScope fd :: rest) with
      ⟨f₁, u₁, pk₁, m₁, hu₁, hp₁, hs₁⟩
    refine ⟨2 + f₁, u₁, pk₁, m₁.popDepth fd, hu₁, ⟨m₁, hp₁, rfl⟩, fun f_rem => ?_⟩
    have hf1 : 2 + f₁ + f_rem = (f₁ + (1 + f_rem)) + 1 := by omega
    have hf2 : 1 + f_rem = f_rem + 1 := by omega
    rw [hf1]; dsimp only [runArithRAMFuel]
    rw [hs₁ (1 + f_rem), hf2]; rfl

theorem RandExecAt.repeatN_nat {d : ℕ} {fd : ℕ} {inp : ArithRAMInput d}
    (countE : IntExpr) (body : ArithRAMStmt) (N B C_cnt C_b : ℕ)
    (Inv : ℕ → (ℕ → Fin B → Bool) → ArithRAMMemory → Prop)
    {chunks₀ : ℕ → Fin B → Bool} {mem₀ : ArithRAMMemory}
    (hInv₀ : Inv 0 chunks₀ mem₀)
    (hcnt : iValAt fd inp mem₀ countE = (N : ℤ))
    (hccnt : intExprOps countE ≤ C_cnt)
    (hstep : ∀ i < N, ∀ (chunks : ℕ → Fin B → Bool) (m : ArithRAMMemory),
      Inv i chunks m →
        RandExecAt fd inp body B m
          (fun b m' => Inv (i + 1) (Function.update chunks i b) m') C_b) :
    RandExecAt fd inp (.repeatN countE body) (N * B) mem₀
      (fun bits m_N =>
        ∃ chunks_N : ℕ → Fin B → Bool,
          Inv N chunks_N m_N ∧
          ∀ r : Fin N, chunks_N r.val = fun j : Fin B =>
            bits ⟨r.val * B + j.val, by
              calc r.val * B + j.val < r.val * B + B := by omega
                _ = (r.val + 1) * B := by ring
                _ ≤ N * B := Nat.mul_le_mul_right B r.isLt⟩)
      (C_cnt + N * C_b) := by
  have hloop : ∀ k : ℕ, k ≤ N → ∀ (chunks : ℕ → Fin B → Bool) (m : ArithRAMMemory),
      Inv (N - k) chunks m →
        (∀ (bs : List Bool), bs.length < k * B → ∀ (u₀ peak₀ : ℕ) (rest : List ArithRAMCont),
          ∃ fuel : ℕ, ∀ f_rem : ℕ,
            runArithRAMFuel inp (fuel + f_rem) (.repeatLoop k body :: rest)
              { mem := m, frameDepth := fd, remainingBits := bs,
                unitCost := u₀, peakCellSpace := peak₀ } = .needMoreBits) ∧
        (∀ (bs : List Bool) (hbs : k * B ≤ bs.length) (u₀ peak₀ : ℕ) (rest : List ArithRAMCont),
          ∃ (fuel u₁ peak₁ : ℕ) (m_N : ArithRAMMemory) (chunks_N : ℕ → Fin B → Bool),
            u₁ ≤ u₀ + k * C_b ∧
            Inv N chunks_N m_N ∧
            (∀ r : Fin N,
              chunks_N r.val =
                if hlt : r.val < N - k then chunks r.val
                else fun j : Fin B => bs[(r.val - (N - k)) * B + j.val]'(by
                  have hr_lt : r.val < N := r.isLt
                  have hj_lt : j.val < B := j.isLt
                  have h1 : r.val - (N - k) + 1 ≤ k := by omega
                  calc (r.val - (N - k)) * B + j.val
                      < (r.val - (N - k)) * B + B := by omega
                    _ = (r.val - (N - k) + 1) * B := by ring
                    _ ≤ k * B := Nat.mul_le_mul_right B h1
                    _ ≤ bs.length := hbs)) ∧
            ∀ f_rem : ℕ,
              runArithRAMFuel inp (fuel + f_rem) (.repeatLoop k body :: rest)
                { mem := m, frameDepth := fd, remainingBits := bs,
                  unitCost := u₀, peakCellSpace := peak₀ } =
              runArithRAMFuel inp f_rem rest
                { mem := m_N, frameDepth := fd, remainingBits := bs.drop (k * B),
                  unitCost := u₁, peakCellSpace := peak₁ }) := by
    intro k
    induction k with
    | zero =>
        intro _ chunks m hIm
        rw [Nat.sub_zero] at hIm
        refine ⟨fun bs hbs => by simp at hbs, fun bs _ u₀ peak₀ rest => ?_⟩
        refine ⟨1, u₀, peak₀, m, chunks, by simp, hIm, ?_, fun f_rem => ?_⟩
        · intro r
          have hr : r.val < N - 0 := by omega
          simp [hr]
        · rw [Nat.add_comm 1 f_rem]; simp [runArithRAMFuel]
    | succ k ih =>
        intro hk chunks m hIm
        have hi_lt : N - (k + 1) < N := by omega
        have hsucc : N - (k + 1) + 1 = N - k := by omega
        have hbody := hstep (N - (k + 1)) hi_lt chunks m hIm
        refine ⟨?_, ?_⟩
        · intro bs hbs u₀ peak₀ rest
          by_cases hb₁ : bs.length < B
          · rcases hbody.1 bs hb₁ u₀ peak₀ (.repeatLoop k body :: rest) with ⟨f₁, hs₁⟩
            refine ⟨1 + f₁, fun f_rem => ?_⟩
            have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
            rw [hf]; dsimp only [runArithRAMFuel]; exact hs₁ f_rem
          · have hge₁ : B ≤ bs.length := by omega
            rcases hbody.2 bs hge₁ u₀ peak₀ (.repeatLoop k body :: rest) with
              ⟨f₁, u₁, pk₁, m₁, _, hp₁, hs₁⟩
            let b₀ : Fin B → Bool := fun j => bs[j.val]'(lt_of_lt_of_le j.isLt hge₁)
            have hp₁' : Inv (N - k) (Function.update chunks (N - (k + 1)) b₀) m₁ := by
              rwa [← hsucc]
            have hrem_lt : (bs.drop B).length < k * B := by
              simp; have : (k + 1) * B = B + k * B := by ring
              omega
            rcases (ih (by omega) _ m₁ hp₁').1 (bs.drop B) hrem_lt u₁ pk₁ rest
              with ⟨f₂, hs₂⟩
            refine ⟨1 + f₁ + f₂, fun f_rem => ?_⟩
            have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
            rw [hf]; dsimp only [runArithRAMFuel]; rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
        · intro bs hbs u₀ peak₀ rest
          have hge₁ : B ≤ bs.length := by
            have : B ≤ (k + 1) * B := Nat.le_mul_of_pos_left B (by omega)
            omega
          rcases hbody.2 bs hge₁ u₀ peak₀ (.repeatLoop k body :: rest) with
            ⟨f₁, u₁, pk₁, m₁, hu₁, hp₁, hs₁⟩
          let b₀ : Fin B → Bool := fun j => bs[j.val]'(lt_of_lt_of_le j.isLt hge₁)
          have hp₁' : Inv (N - k) (Function.update chunks (N - (k + 1)) b₀) m₁ := by
            rwa [← hsucc]
          have hge₂ : k * B ≤ (bs.drop B).length := by
            simp; have : (k + 1) * B = B + k * B := by ring
            omega
          rcases (ih (by omega) _ m₁ hp₁').2 (bs.drop B) hge₂ u₁ pk₁ rest with
            ⟨f₂, u₂, pk₂, m_N, chunks_N, hu₂, hp₂, hch₂, hs₂⟩
          refine ⟨1 + f₁ + f₂, u₂, pk₂, m_N, chunks_N, ?_, hp₂, ?_, fun f_rem => ?_⟩
          · have : u₂ ≤ u₀ + C_b + k * C_b := by omega
            calc u₂ ≤ u₀ + C_b + k * C_b := this
              _ = u₀ + (k + 1) * C_b := by ring
          · intro r
            rw [hch₂ r]
            by_cases hr1 : r.val < N - (k + 1)
            · have hr2 : r.val < N - k := by omega
              have hne : r.val ≠ N - (k + 1) := by omega
              simp [hr1, hr2, Function.update_of_ne hne]
            · by_cases hr2 : r.val < N - k
              · have hreq : r.val = N - (k + 1) := by omega
                rw [dif_pos hr2, dif_neg hr1]
                have hlhs : Function.update chunks (N - (k + 1)) b₀ r.val = b₀ := by
                  rw [hreq, Function.update_self]
                rw [hlhs]
                ext j
                dsimp only [b₀]
                have h0 : r.val - (N - (k + 1)) = 0 := by omega
                simp [h0]
              · simp [hr1, hr2, List.getElem_drop]
                ext j
                congr 1
                have hsub : r.val - (N - (k + 1)) = 1 + (r.val - (N - k)) := by omega
                rw [hsub]; ring
          · have hf : 1 + f₁ + f₂ + f_rem = (f₁ + (f₂ + f_rem)) + 1 := by omega
            rw [hf]; dsimp only [runArithRAMFuel]
            rw [hs₁ (f₂ + f_rem), hs₂ f_rem, List.drop_drop]
            have hmul : B + k * B = (k + 1) * B := by ring
            rw [hmul]
  have hInv₀' : Inv (N - N) chunks₀ mem₀ := by rw [Nat.sub_self]; exact hInv₀
  have hmain := hloop N le_rfl chunks₀ mem₀ hInv₀'
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ rest
    rcases he : evalIntExpr inp.toWordView fd mem₀.words countE with ⟨cnt, u_cnt, _⟩
    have hcnt' : cnt = (N : ℤ) := by rw [← hcnt, iValAt, he]
    subst hcnt'
    rcases hmain.1 bs hbs (u₀ + u_cnt) peak₀ rest with ⟨f₁, hs₁⟩
    refine ⟨1 + f₁, fun f_rem => ?_⟩
    have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
    rw [hf]
    have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
    simp only [runArithRAMFuel, he, hnIter]
    exact hs₁ f_rem
  · intro bs hbs u₀ peak₀ rest
    rcases he : evalIntExpr inp.toWordView fd mem₀.words countE with ⟨cnt, u_cnt, _⟩
    have hcnt' : cnt = (N : ℤ) := by rw [← hcnt, iValAt, he]
    have hucnt : u_cnt = intExprOps countE := by
      have := evalIntExpr_ops inp.toWordView fd mem₀.words countE; rw [he] at this; exact this
    subst hcnt'
    rcases hmain.2 bs hbs (u₀ + u_cnt) peak₀ rest with
      ⟨f₁, u₁, pk₁, m_N, chunks_N, hu₁, hp₁, hch₁, hs₁⟩
    refine ⟨1 + f₁, u₁, pk₁, m_N, by omega, ⟨chunks_N, hp₁, ?_⟩, fun f_rem => ?_⟩
    · intro r
      rw [hch₁ r]
      have hnr : ¬ r.val < N - N := by omega
      simp [hnr]
    · have hf : 1 + f₁ + f_rem = (f₁ + f_rem) + 1 := by omega
      rw [hf]
      have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
      simp only [runArithRAMFuel, he, hnIter]
      exact hs₁ f_rem

theorem RandExec.to_spec {d : ℕ} {inp : ArithRAMInput d} {prog : ArithRAMStmt}
    {B : ℕ} {initMem : ArithRAMMemory}
    {Post : (Fin B → Bool) → ArithRAMMemory → Prop} {C : ℕ}
    (h : RandExec inp prog B (initMem.popDepth 0) Post C) :
    (∀ bs : List Bool, bs.length ≠ B → runArithRAMWithBits prog inp initMem bs = none) ∧
    (∀ bits : Fin B → Bool,
      ∃ out : ArithRAMExecOutcome,
        runArithRAMWithBits prog inp initMem (List.ofFn bits) = some out ∧
        out.unitCost ≤ C ∧
        out.peakCellSpace ≤ inp.inputCellSpace + initMem.cellCount + out.unitCost ∧
        ∃ m₁ : ArithRAMMemory, Post bits m₁ ∧ out.mem = m₁.popDepth 0) := by
  refine ⟨?_, ?_⟩
  · intro bs hne
    by_cases hlt : bs.length < B
    · rcases h.1 bs hlt 0 (inp.inputCellSpace + (initMem.popDepth 0).cellCount) [] with ⟨f, hs⟩
      exact runArithRAMWithBits_eq_none_of_status prog inp initMem bs (f + 0) .needMoreBits
        (by simp) (by simp) (hs 0)
    · have hgt : B < bs.length := by omega
      rcases h.2 bs (by omega) 0 (inp.inputCellSpace + (initMem.popDepth 0).cellCount) [] with
        ⟨f, u₁, pk₁, m₁, _, _, hs⟩
      have hrem_ne : (bs.drop B).isEmpty = false := by
        cases hdrop : bs.drop B with
        | nil =>
            exfalso
            have := congrArg List.length hdrop; simp at this; omega
        | cons _ _ => rfl
      have hunused : runArithRAMFuel inp (f + 0) [.stmt prog]
          { mem := initMem.popDepth 0, frameDepth := 0, remainingBits := bs,
            unitCost := 0, peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } =
          .unusedBits := by
        rw [hs 0]; simp [runArithRAMFuel, hrem_ne]
      exact runArithRAMWithBits_eq_none_of_status prog inp initMem bs (f + 0) .unusedBits
        (by simp) (by simp) hunused
  · intro bits
    let bs := List.ofFn bits
    have hbs : B ≤ bs.length := by simp [bs]
    rcases h.2 bs hbs 0 (inp.inputCellSpace + (initMem.popDepth 0).cellCount) [] with
      ⟨f, u₁, pk₁, m₁, hu₁, hp₁, hs⟩
    have hdrop : bs.drop B = [] := by simp [bs]
    have hrun : runArithRAMFuel inp (f + 0) [.stmt prog]
        { mem := initMem.popDepth 0, frameDepth := 0, remainingBits := bs,
          unitCost := 0, peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } =
        .halted { mem := m₁.popDepth 0, unitCost := u₁, peakCellSpace := pk₁ } := by
      rw [hs 0, hdrop]; rfl
    have hsome := runArithRAMWithBits_eq_some_of_fuel prog inp initMem bs (f + 0) _ hrun
    have hp₁' : Post bits m₁ := by
      convert hp₁ using 1
      ext j; simp [bs]
    exact ⟨_, hsome, by dsimp only; omega, runArithRAMWithBits_peakCellSpace_le hsome, m₁, hp₁', rfl⟩
/-! ### 5. Fixed-bit-length `ENNReal` probability summation lemmas -/

theorem tsum_listBool_of_fixedLength (B : ℕ) (g : List Bool → ENNReal)
    (hzero : ∀ bs : List Bool, bs.length ≠ B → g bs = 0) :
    (∑' bs : List Bool, g bs) = ∑ bits : Fin B → Bool, g (List.ofFn bits) := by
  classical
  let s : Finset (List Bool) := Finset.univ.image (List.ofFn : (Fin B → Bool) → List Bool)
  rw [tsum_eq_sum (s := s)]
  · rw [Finset.sum_image]
    intro f₁ _ f₂ _ heq
    exact List.ofFn_injective heq
  · intro bs hbs
    apply hzero
    intro hlen
    apply hbs
    refine Finset.mem_image.mpr ⟨fun i : Fin B => bs[i.val]'(by omega), Finset.mem_univ _, ?_⟩
    apply List.ext_getElem
    · simp [hlen]
    · intro i h₁ h₂; simp

theorem sum_bitListProb_ofFn (B : ℕ) :
    (∑ bits : Fin B → Bool, bitListProb (List.ofFn bits)) = 1 := by
  have hcard : Fintype.card (Fin B → Bool) = 2 ^ B := by simp
  simp only [bitListProb, List.length_ofFn, Finset.sum_const, Finset.card_univ, hcard, nsmul_eq_mul]
  rw [Nat.cast_pow, Nat.cast_ofNat, ← mul_pow, ENNReal.mul_inv_cancel (by norm_num) (by simp),
    one_pow]

theorem sum_bitListProb_filter_le (B : ℕ) (Bad : (Fin B → Bool) → Prop) [DecidablePred Bad]
    {p : ℝ} (hcard : ((Finset.univ.filter Bad).card : ℝ) ≤ p * (2 : ℝ) ^ B) :
    (∑ bits : Fin B → Bool, if Bad bits then bitListProb (List.ofFn bits) else 0) ≤
      ENNReal.ofReal p := by
  have hsum :
      (∑ bits : Fin B → Bool, if Bad bits then bitListProb (List.ofFn bits) else 0) =
        ((Finset.univ.filter Bad).card : ENNReal) * ((2 : ENNReal)⁻¹) ^ B := by
    rw [← Finset.sum_filter]
    simp [bitListProb, List.length_ofFn, nsmul_eq_mul]
  rw [hsum]
  by_cases hp : p < 0
  · exfalso
    have hpos : (0 : ℝ) < (2 : ℝ) ^ B := by positivity
    have hneg : p * (2 : ℝ) ^ B < 0 := mul_neg_of_neg_of_pos hp hpos
    have hnn : (0 : ℝ) ≤ ((Finset.univ.filter Bad).card : ℝ) := Nat.cast_nonneg _
    linarith
  · push_neg at hp
    have h1 : (((Finset.univ.filter Bad).card : ℝ)) / ((2 : ℝ) ^ B) ≤ p := by
      rw [div_le_iff₀ (by positivity)]
      exact hcard
    have h2 : ENNReal.ofReal ((((Finset.univ.filter Bad).card : ℝ)) / ((2 : ℝ) ^ B)) ≤
        ENNReal.ofReal p := ENNReal.ofReal_le_ofReal h1
    have h3 : ENNReal.ofReal ((((Finset.univ.filter Bad).card : ℝ)) / ((2 : ℝ) ^ B)) =
        ((Finset.univ.filter Bad).card : ENNReal) * ((2 : ENNReal)⁻¹) ^ B := by
      rw [div_eq_mul_inv, ENNReal.ofReal_mul (Nat.cast_nonneg _), ENNReal.ofReal_natCast,
        ← inv_pow, ENNReal.ofReal_pow (by norm_num), ENNReal.ofReal_inv_of_pos (by norm_num)]
      norm_num
    rwa [← h3]



/-! ### 6. Heap-box invariant for bounded persistent cell space -/

def HeapBox (T_max M_max : ℕ) : Finset RAMCellLoc :=
  (Finset.range T_max).biUnion (fun t : ℕ =>
    (Finset.range M_max).image (fun i : ℕ => RAMCellLoc.heap t (i : ℤ)))

theorem card_heapBox_le (T_max M_max : ℕ) :
    (HeapBox T_max M_max).card ≤ T_max * M_max := by
  classical
  unfold HeapBox
  calc ((Finset.range T_max).biUnion (fun t : ℕ =>
          (Finset.range M_max).image (fun i : ℕ => RAMCellLoc.heap t (i : ℤ)))).card
      ≤ ∑ t ∈ Finset.range T_max,
          ((Finset.range M_max).image (fun i : ℕ => RAMCellLoc.heap t (i : ℤ))).card :=
        Finset.card_biUnion_le
    _ ≤ ∑ _t ∈ Finset.range T_max, M_max := by
        apply Finset.sum_le_sum
        intro t _
        exact Finset.card_image_le.trans (by simp)
    _ = T_max * M_max := by simp

def HeapOnlyInBox (T_max M_max : ℕ) (mem : ArithRAMMemory) : Prop :=
  (∀ t idx, RAMCellLoc.heap t idx ∈ mem.words.live → t < T_max ∧ 0 ≤ idx ∧ idx < (M_max : ℤ)) ∧
  (∀ t idx, RAMCellLoc.heap t idx ∈ mem.reals.live → t < T_max ∧ 0 ≤ idx ∧ idx < (M_max : ℤ)) ∧
  (∀ v idx, RAMCellLoc.localFrame 0 v idx ∉ mem.words.live) ∧
  (∀ v idx, RAMCellLoc.localFrame 0 v idx ∉ mem.reals.live)

theorem heapOnlyInBox_empty (T_max M_max : ℕ) :
    HeapOnlyInBox T_max M_max ArithRAMMemory.empty := by
  exact ⟨fun _ _ h => by simp [ArithRAMMemory.empty, WordStore.empty] at h,
    fun _ _ h => by simp [ArithRAMMemory.empty, RealStore.empty] at h,
    fun _ _ h => by simp [ArithRAMMemory.empty, WordStore.empty] at h,
    fun _ _ h => by simp [ArithRAMMemory.empty, RealStore.empty] at h⟩

theorem heapOnlyInBox_popDepth {T_max M_max : ℕ} {mem : ArithRAMMemory} (k : ℕ)
    (h : HeapOnlyInBox T_max M_max mem) :
    HeapOnlyInBox T_max M_max (mem.popDepth k) := by
  refine ⟨fun t idx hw => ?_, fun t idx hr => ?_, fun v idx hw => ?_, fun v idx hr => ?_⟩
  · simp only [ArithRAMMemory.popDepth, WordStore.popDepth, Finset.mem_filter] at hw
    exact h.1 t idx hw.1
  · simp only [ArithRAMMemory.popDepth, RealStore.popDepth, Finset.mem_filter] at hr
    exact h.2.1 t idx hr.1
  · simp only [ArithRAMMemory.popDepth, WordStore.popDepth, Finset.mem_filter] at hw
    exact h.2.2.1 v idx hw.1
  · simp only [ArithRAMMemory.popDepth, RealStore.popDepth, Finset.mem_filter] at hr
    exact h.2.2.2 v idx hr.1

theorem heapOnlyInBox_wWrite {T_max M_max : ℕ} {mem : ArithRAMMemory}
    {t : ℕ} {idx : ℤ} (val : ℤ)
    (h : HeapOnlyInBox T_max M_max mem)
    (ht : t < T_max) (hi0 : 0 ≤ idx) (hi1 : idx < (M_max : ℤ)) :
    HeapOnlyInBox T_max M_max (wWrite mem t idx val) := by
  refine ⟨fun t' idx' hw => ?_, fun t' idx' hr => h.2.1 t' idx' hr,
    fun v idx' hw => ?_, fun v idx' hr => h.2.2.2 v idx' hr⟩
  · simp only [wWrite, WordStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq] at hw
    rcases hw with ⟨rfl, rfl⟩ | hw
    · exact ⟨ht, hi0, hi1⟩
    · exact h.1 t' idx' hw
  · simp only [wWrite, WordStore.write, Finset.mem_insert] at hw
    rcases hw with heq | hw
    · cases heq
    · exact h.2.2.1 v idx' hw

theorem heapOnlyInBox_rWrite {T_max M_max : ℕ} {mem : ArithRAMMemory}
    {t : ℕ} {idx : ℤ} (val : ℝ)
    (h : HeapOnlyInBox T_max M_max mem)
    (ht : t < T_max) (hi0 : 0 ≤ idx) (hi1 : idx < (M_max : ℤ)) :
    HeapOnlyInBox T_max M_max (rWrite mem t idx val) := by
  refine ⟨fun t' idx' hw => h.1 t' idx' hw, fun t' idx' hr => ?_,
    fun v idx' hw => h.2.2.1 v idx' hw, fun v idx' hr => ?_⟩
  · simp only [rWrite, RealStore.write, Finset.mem_insert, RAMCellLoc.heap.injEq] at hr
    rcases hr with ⟨rfl, rfl⟩ | hr
    · exact ⟨ht, hi0, hi1⟩
    · exact h.2.1 t' idx' hr
  · simp only [rWrite, RealStore.write, Finset.mem_insert] at hr
    rcases hr with heq | hr
    · cases heq
    · exact h.2.2.2 v idx' hr

theorem heapOnlyInBox_wWriteL {T_max M_max : ℕ} {fd : ℕ} (hfd : 1 ≤ fd) {mem : ArithRAMMemory}
    (v : ℕ) (idx val : ℤ) (h : HeapOnlyInBox T_max M_max mem) :
    HeapOnlyInBox T_max M_max (wWriteL fd mem v idx val) := by
  refine ⟨fun t' idx' hw => ?_, fun t' idx' hr => h.2.1 t' idx' hr,
    fun v' idx' hw => ?_, fun v' idx' hr => h.2.2.2 v' idx' hr⟩
  · simp only [wWriteL, WordStore.write, Finset.mem_insert] at hw
    rcases hw with heq | hw
    · cases heq
    · exact h.1 t' idx' hw
  · simp only [wWriteL, WordStore.write, Finset.mem_insert, RAMCellLoc.localFrame.injEq] at hw
    rcases hw with ⟨h0, _, _⟩ | hw
    · omega
    · exact h.2.2.1 v' idx' hw

theorem heapOnlyInBox_rWriteL {T_max M_max : ℕ} {fd : ℕ} (hfd : 1 ≤ fd) {mem : ArithRAMMemory}
    (v : ℕ) (idx : ℤ) (val : ℝ) (h : HeapOnlyInBox T_max M_max mem) :
    HeapOnlyInBox T_max M_max (rWriteL fd mem v idx val) := by
  refine ⟨fun t' idx' hw => h.1 t' idx' hw, fun t' idx' hr => ?_,
    fun v' idx' hw => h.2.2.1 v' idx' hw, fun v' idx' hr => ?_⟩
  · simp only [rWriteL, RealStore.write, Finset.mem_insert] at hr
    rcases hr with heq | hr
    · cases heq
    · exact h.2.1 t' idx' hr
  · simp only [rWriteL, RealStore.write, Finset.mem_insert, RAMCellLoc.localFrame.injEq] at hr
    rcases hr with ⟨h0, _, _⟩ | hr
    · omega
    · exact h.2.2.2 v' idx' hr

theorem cellCount_popDepth_zero_le_of_box {T_max M_max : ℕ} {mem : ArithRAMMemory}
    (h : HeapOnlyInBox T_max M_max mem) :
    (mem.popDepth 0).cellCount ≤ 2 * (T_max * M_max) := by
  have hw_sub : (mem.popDepth 0).words.live ⊆ HeapBox T_max M_max := by
    intro loc hloc
    simp only [ArithRAMMemory.popDepth, WordStore.popDepth, Finset.mem_filter] at hloc
    cases loc with
    | heap t idx =>
        rcases h.1 t idx hloc.1 with ⟨ht, h0, hi⟩
        simp only [HeapBox, Finset.mem_biUnion, Finset.mem_range, Finset.mem_image]
        exact ⟨t, ht, idx.toNat, by omega, congrArg (RAMCellLoc.heap t) (Int.toNat_of_nonneg h0)⟩
    | localFrame dep v idx =>
        simp only [RAMCellLoc.keepAtDepth, decide_eq_true_eq, Nat.le_zero] at hloc
        rcases hloc with ⟨hloc1, rfl⟩
        exact False.elim (h.2.2.1 v idx hloc1)
  have hr_sub : (mem.popDepth 0).reals.live ⊆ HeapBox T_max M_max := by
    intro loc hloc
    simp only [ArithRAMMemory.popDepth, RealStore.popDepth, Finset.mem_filter] at hloc
    cases loc with
    | heap t idx =>
        rcases h.2.1 t idx hloc.1 with ⟨ht, h0, hi⟩
        simp only [HeapBox, Finset.mem_biUnion, Finset.mem_range, Finset.mem_image]
        exact ⟨t, ht, idx.toNat, by omega, congrArg (RAMCellLoc.heap t) (Int.toNat_of_nonneg h0)⟩
    | localFrame dep v idx =>
        simp only [RAMCellLoc.keepAtDepth, decide_eq_true_eq, Nat.le_zero] at hloc
        rcases hloc with ⟨hloc1, rfl⟩
        exact False.elim (h.2.2.2 v idx hloc1)
  have hw_card : (mem.popDepth 0).words.cellCount ≤ T_max * M_max :=
    (Finset.card_le_card hw_sub).trans (card_heapBox_le T_max M_max)
  have hr_card : (mem.popDepth 0).reals.cellCount ≤ T_max * M_max :=
    (Finset.card_le_card hr_sub).trans (card_heapBox_le T_max M_max)
  unfold ArithRAMMemory.cellCount
  omega

end UL.Proof_lem_7_2_RacerP33
