import Mathlib
import UL.Stmt.lem_7_2
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_chain_contraction
import UL.Stmt.clm_5_1_mc_baseline
import UL.Stmt.lem_5_2
import UL.Stmt.lem_C_2
import UL.Stmt.clm_7_3_failure_budget
import UL.Proof.cit_hpj19_thm18.H0
import UL.Proof.cit_hpj19_thm18.H1
import UL.Proof.lem_7_2.RacerP33_H1_RAM
import UL.Proof.lem_7_2.RacerP33_H2_LocHPJ
import UL.Proof.lem_7_2.RacerP33_H3_Params
import UL.Proof.lem_7_2.RacerP46_H2a_BoxAndFrame

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Basic Euclidean Distance & Diameter Bijection Helpers -/

lemma euclideanDistSq_eq_sum {d : ℕ} (x y : EuclideanSpace ℝ (Fin d)) :
    euclideanDistSq x y = ∑ i : Fin d, (euclideanCoord x i - euclideanCoord y i) ^ 2 := by
  unfold euclideanDistSq euclideanCoord
  rw [EuclideanSpace.norm_eq, Real.sq_sqrt (Finset.sum_nonneg fun _ _ => sq_nonneg _)]
  refine Finset.sum_congr rfl fun i _ => ?_
  simp [Real.norm_eq_abs, sq_abs]

lemma indexedEuclideanDiam_bij {ι₁ ι₂ : Type} {d : ℕ}
    (I₁ : Finset ι₁) (pts₁ : ι₁ → EuclideanSpace ℝ (Fin d))
    (I₂ : Finset ι₂) (pts₂ : ι₂ → EuclideanSpace ℝ (Fin d))
    (f : ι₁ → ι₂) (g : ι₂ → ι₁)
    (hf : ∀ x ∈ I₁, f x ∈ I₂ ∧ pts₂ (f x) = pts₁ x ∧ g (f x) = x)
    (hg : ∀ y ∈ I₂, g y ∈ I₁ ∧ f (g y) = y) :
    indexedEuclideanDiam I₁ pts₁ = indexedEuclideanDiam I₂ pts₂ := by
  unfold indexedEuclideanDiam
  by_cases h1 : I₁.Nonempty
  · have h2 : I₂.Nonempty := by
      rcases h1 with ⟨x, hx⟩
      exact ⟨f x, (hf x hx).1⟩
    simp only [h1, h2, ↓reduceDIte]
    apply le_antisymm
    · rw [Finset.sup'_le_iff]
      intro ab hab
      rcases Finset.mem_product.mp hab with ⟨ha, hb⟩
      have hmem2 : (f ab.1, f ab.2) ∈ I₂ ×ˢ I₂ :=
        Finset.mem_product.mpr ⟨(hf ab.1 ha).1, (hf ab.2 hb).1⟩
      have hle := Finset.le_sup' (fun xy : ι₂ × ι₂ => ‖pts₂ xy.1 - pts₂ xy.2‖) hmem2
      simpa [(hf ab.1 ha).2.1, (hf ab.2 hb).2.1] using hle
    · rw [Finset.sup'_le_iff]
      intro uv huv
      rcases Finset.mem_product.mp huv with ⟨hu, hv⟩
      have hgu := (hg uv.1 hu).1
      have hgv := (hg uv.2 hv).1
      have hmem1 : (g uv.1, g uv.2) ∈ I₁ ×ˢ I₁ := Finset.mem_product.mpr ⟨hgu, hgv⟩
      have hle := Finset.le_sup' (fun xy : ι₁ × ι₁ => ‖pts₁ xy.1 - pts₁ xy.2‖) hmem1
      have epu : pts₁ (g uv.1) = pts₂ uv.1 := by
        have h := (hf (g uv.1) hgu).2.1
        rw [(hg uv.1 hu).2] at h; exact h.symm
      have epv : pts₁ (g uv.2) = pts₂ uv.2 := by
        have h := (hf (g uv.2) hgv).2.1
        rw [(hg uv.2 hv).2] at h; exact h.symm
      simpa [epu, epv] using hle
  · have h2 : ¬ I₂.Nonempty := fun ⟨y, hy⟩ => h1 ⟨g y, (hg y hy).1⟩
    simp [h1, h2]

lemma handleDiam_eq_pointSet_diam {d n : ℕ} {P : DynamicPointSet d} (hP : P.WellFormed n) :
    indexedEuclideanDiam P.activeHandles P.handleCoords =
      indexedEuclideanDiam P.activeIds P.coords := by
  refine indexedEuclideanDiam_bij P.activeHandles P.handleCoords P.activeIds P.coords
    P.idOfHandle P.handleOfId ?_ ?_
  · intro h hh
    refine ⟨(hP.2.2.1 h hh).1, ?_, (hP.2.2.1 h hh).2⟩
    simp only [DynamicPointSet.handleCoords, if_pos hh]
  · intro id hid
    exact ⟨(hP.2.1 id hid).1, (hP.2.1 id hid).2⟩

lemma activeHandles_card_eq_activeIds_card {d n : ℕ} {P : DynamicPointSet d}
    (hP : P.WellFormed n) : P.activeHandles.card = P.activeIds.card := by
  symm
  refine Finset.card_bij (fun x _ => P.handleOfId x)
    (fun x hx => (hP.2.1 x hx).1)
    (fun x₁ h₁ x₂ h₂ heq => by
      dsimp only at heq
      have e1 := (hP.2.1 x₁ h₁).2
      have e2 := (hP.2.1 x₂ h₂).2
      rw [heq] at e1
      exact e1.symm.trans e2)
    (fun h hh => ⟨P.idOfHandle h, (hP.2.2.1 h hh).1, (hP.2.2.1 h hh).2⟩)

lemma applyDynamicUpdate_wellFormed {d n : ℕ} {P P' : DynamicPointSet d}
    {op : DynamicUpdate d} {rh : Option ℕ}
    (hP : P.WellFormed n) (hleg : IsLegalUpdate n Set.univ P op)
    (happ : applyDynamicUpdate P op rh = some P') :
    P'.WellFormed n := by
  rcases hP with ⟨hcard, hidH, hhId, hlt, hinj⟩
  cases op with
  | insert newId extName pt =>
      cases rh with
      | none => simp [applyDynamicUpdate] at happ
      | some h =>
          simp only [applyDynamicUpdate] at happ
          split_ifs at happ with hcond
          injection happ with hP'
          subst hP'
          rcases hcond with ⟨hid_not, hh_not⟩
          rcases hleg with ⟨_, hcard_le, _⟩
          refine ⟨?_, ?_, ?_, ?_, ?_⟩
          · dsimp only
            rw [Finset.card_insert_of_notMem hid_not]
            exact hcard_le
          · intro x hx
            dsimp only at hx ⊢
            rcases Finset.mem_insert.mp hx with rfl | hx'
            · simp [Function.update]
            · have hx_ne : x ≠ newId := fun heq => hid_not (heq ▸ hx')
              have hxh_ne : P.handleOfId x ≠ h := fun heq => hh_not (heq ▸ (hidH x hx').1)
              rw [Function.update_of_ne hx_ne, Function.update_of_ne hxh_ne]
              exact ⟨Finset.mem_insert_of_mem (hidH x hx').1, (hidH x hx').2⟩
          · intro y hy
            dsimp only at hy ⊢
            rcases Finset.mem_insert.mp hy with rfl | hy'
            · simp [Function.update]
            · have hy_ne : y ≠ h := fun heq => hh_not (heq ▸ hy')
              have hyi_ne : P.idOfHandle y ≠ newId := fun heq => hid_not (heq ▸ (hhId y hy').1)
              rw [Function.update_of_ne hy_ne, Function.update_of_ne hyi_ne]
              exact ⟨Finset.mem_insert_of_mem (hhId y hy').1, (hhId y hy').2⟩
          · intro x hx
            dsimp only at hx ⊢
            rcases Finset.mem_insert.mp hx with rfl | hx'
            · simp [Function.update]
            · have hx_ne : x ≠ newId := fun heq => hid_not (heq ▸ hx')
              simp only [Function.update_of_ne hx_ne]
              exact Nat.lt_succ_of_lt (hlt x hx')
          · intro x₁ hx₁ x₂ hx₂ heq
            dsimp only at hx₁ hx₂ heq
            rcases Finset.mem_insert.mp hx₁ with rfl | hx₁' <;>
            rcases Finset.mem_insert.mp hx₂ with rfl | hx₂'
            · rfl
            · have hx₂_ne : x₂ ≠ x₁ := fun h0 => hid_not (h0 ▸ hx₂')
              rw [Function.update_self, Function.update_of_ne hx₂_ne] at heq
              exact absurd heq (ne_of_gt (hlt x₂ hx₂'))
            · have hx₁_ne : x₁ ≠ x₂ := fun h0 => hid_not (h0 ▸ hx₁')
              rw [Function.update_of_ne hx₁_ne, Function.update_self] at heq
              exact absurd heq (ne_of_lt (hlt x₁ hx₁'))
            · have hx₁_ne : x₁ ≠ newId := fun h0 => hid_not (h0 ▸ hx₁')
              have hx₂_ne : x₂ ≠ newId := fun h0 => hid_not (h0 ▸ hx₂')
              simp only [Function.update_of_ne hx₁_ne, Function.update_of_ne hx₂_ne] at heq
              exact hinj x₁ hx₁' x₂ hx₂' heq
  | delete delId =>
      cases rh with
      | some _ => simp [applyDynamicUpdate] at happ
      | none =>
          simp only [applyDynamicUpdate] at happ
          split_ifs at happ with hid_in
          injection happ with hP'
          subst hP'
          refine ⟨?_, ?_, ?_, ?_, ?_⟩
          · dsimp only
            exact Finset.card_erase_le.trans hcard
          · intro x hx
            dsimp only at hx ⊢
            rcases Finset.mem_erase.mp hx with ⟨hx_ne, hx'⟩
            have hxh_ne : P.handleOfId x ≠ P.handleOfId delId := by
              intro heq; apply hx_ne
              have e1 := (hidH x hx').2
              have e2 := (hidH delId hid_in).2
              rw [heq] at e1; exact e1.symm.trans e2
            rw [Function.update_of_ne hx_ne, Function.update_of_ne hxh_ne]
            exact ⟨Finset.mem_erase.mpr ⟨hxh_ne, (hidH x hx').1⟩, (hidH x hx').2⟩
          · intro y hy
            dsimp only at hy ⊢
            rcases Finset.mem_erase.mp hy with ⟨hy_ne, hy'⟩
            have hyi_ne : P.idOfHandle y ≠ delId := by
              intro heq; apply hy_ne
              have e1 := (hhId y hy').2
              rw [heq] at e1; exact e1.symm
            rw [Function.update_of_ne hy_ne, Function.update_of_ne hyi_ne]
            exact ⟨Finset.mem_erase.mpr ⟨hyi_ne, (hhId y hy').1⟩, (hhId y hy').2⟩
          · intro x hx
            dsimp only at hx ⊢
            rcases Finset.mem_erase.mp hx with ⟨hx_ne, hx'⟩
            simp [Function.update_of_ne hx_ne, hlt x hx']
          · intro x₁ hx₁ x₂ hx₂ heq
            dsimp only at hx₁ hx₂ heq
            rcases Finset.mem_erase.mp hx₁ with ⟨hx₁_ne, hx₁'⟩
            rcases Finset.mem_erase.mp hx₂ with ⟨hx₂_ne, hx₂'⟩
            simp only [Function.update_of_ne hx₁_ne, Function.update_of_ne hx₂_ne] at heq
            exact hinj x₁ hx₁' x₂ hx₂' heq

/-! ### 2. `HasNodeAge`, Unconditional Contraction, and `< D₀` Depth Bounds -/

lemma hasNodeAge_zero {ι : Type} (S : Finset ι) : HasNodeAge S S 0 :=
  ⟨fun _ => S, rfl, rfl, fun r => Fin.elim0 r⟩

lemma hasNodeAge_step {ι : Type} {P₀ S S' : Finset ι} {a : ℕ}
    (ha : HasNodeAge P₀ S a) (hchg : IsInputChange S S') :
    HasNodeAge P₀ S' (a + 1) := by
  rcases ha with ⟨seq, h0, hlast, hstep⟩
  let seq' : Fin (a + 1 + 1) → Finset ι := fun r =>
    if h : r.val ≤ a then seq ⟨r.val, Nat.lt_succ_of_le h⟩ else S'
  refine ⟨seq', ?_, ?_, ?_⟩
  · change (if h : (0 : ℕ) ≤ a then seq ⟨0, Nat.lt_succ_of_le h⟩ else S') = P₀
    rw [dif_pos (Nat.zero_le a)]
    exact h0
  · change (if h : a + 1 ≤ a then seq ⟨a + 1, Nat.lt_succ_of_le h⟩ else S') = S'
    rw [dif_neg (by omega)]
  · intro r
    by_cases hr : r.val < a
    · have h1 : seq' r.castSucc = seq ⟨r.val, Nat.lt_succ_of_lt hr⟩ := by
        change (if h : r.val ≤ a then seq ⟨r.val, Nat.lt_succ_of_le h⟩ else S') = _
        rw [dif_pos (le_of_lt hr)]
      have h2 : seq' r.succ = seq ⟨r.val + 1, Nat.succ_lt_succ hr⟩ := by
        change (if h : r.val + 1 ≤ a then seq ⟨r.val + 1, Nat.lt_succ_of_le h⟩ else S') = _
        rw [dif_pos (Nat.succ_le_of_lt hr)]
      rw [h1, h2]
      exact hstep ⟨r.val, hr⟩
    · have hreq : r.val = a := by have := r.isLt; omega
      have h1 : seq' r.castSucc = S := by
        change (if h : r.val ≤ a then seq ⟨r.val, Nat.lt_succ_of_le h⟩ else S') = S
        rw [dif_pos (by omega)]
        have hfin : (⟨r.val, Nat.lt_succ_of_le (by omega)⟩ : Fin (a + 1)) = Fin.last a := by
          ext; simp [hreq]
        rw [hfin, hlast]
      have h2 : seq' r.succ = S' := by
        change (if h : r.val + 1 ≤ a then seq ⟨r.val + 1, Nat.lt_succ_of_le h⟩ else S') = S'
        rw [dif_neg (by omega)]
      rw [h1, h2]
      exact hchg

lemma hasNodeAge_card_bounds {ι : Type} {P₀ S : Finset ι} {a : ℕ} :
    HasNodeAge P₀ S a →
      S.card ≤ P₀.card + a ∧ P₀.card ≤ S.card + a ∧
        (open Classical in (P₀ \ S).card ≤ a) := by
  classical
  induction a generalizing S with
  | zero =>
      rintro ⟨seq, h0, hlast, _⟩
      have heq : P₀ = S := h0.symm.trans hlast
      subst heq
      simp
  | succ a ih =>
      rintro ⟨seq, h0, hlast, hstep⟩
      let S_prev := seq (Fin.last a).castSucc
      have hprev : HasNodeAge P₀ S_prev a := by
        refine ⟨fun i => seq i.castSucc, h0, rfl, fun i => ?_⟩
        dsimp only
        have hs : (i.succ).castSucc = (i.castSucc).succ := Fin.castSucc_succ i
        rw [hs]
        exact hstep i.castSucc
      rcases ih hprev with ⟨hc1, hc2, hsd⟩
      have hchg : IsInputChange S_prev S := by
        have h1 := hstep (Fin.last a)
        have hsucc : (Fin.last a).succ = Fin.last (a + 1) := rfl
        rwa [hsucc, hlast] at h1
      rcases hchg with ⟨x, hx, rfl⟩ | ⟨x, hx, rfl⟩
      · have hci : (insert x S_prev).card = S_prev.card + 1 := Finset.card_insert_of_notMem hx
        have hsub : P₀ \ insert x S_prev ⊆ P₀ \ S_prev := by
          intro z hz
          rw [Finset.mem_sdiff] at hz ⊢
          exact ⟨hz.1, fun h => hz.2 (Finset.mem_insert_of_mem h)⟩
        have hsd' : (P₀ \ insert x S_prev).card ≤ (P₀ \ S_prev).card := Finset.card_le_card hsub
        omega
      · have hcard_er : (S_prev.erase x).card + 1 = S_prev.card := Finset.card_erase_add_one hx
        have hsub : P₀ \ S_prev.erase x ⊆ insert x (P₀ \ S_prev) := by
          intro z hz
          rw [Finset.mem_sdiff] at hz
          by_cases hzx : z = x
          · subst hzx; exact Finset.mem_insert_self z _
          · exact Finset.mem_insert_of_mem
              (Finset.mem_sdiff.mpr ⟨hz.1, fun h => hz.2 (Finset.mem_erase.mpr ⟨hzx, h⟩)⟩)
        have hsd' : (P₀ \ S_prev.erase x).card ≤ (P₀ \ S_prev).card + 1 :=
          (Finset.card_le_card hsub).trans (Finset.card_insert_le _ _)
        omega

lemma passesBirthCoreCheck_selectOpenedLevelBall {d : ℕ} {ι : Type}
    {α : ℝ} (hα : α ≤ 2) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_birth : Finset ι) {bId : ι} (_hb : bId ∈ S_birth) (res : SampledCenterResult d) :
    PassesBirthCoreCheck α pts (selectOpenedLevelBall α pts S_birth bId res) S_birth := by
  classical
  unfold selectOpenedLevelBall applyBirthCoreFallback
  split_ifs with hpass
  · exact hpass
  · unfold PassesBirthCoreCheck maxBirthRadiusBall
    have hcore_eq : ChainNode.core
        { o := (provisionalCenter pts bId res).o
          V := nodeMaxRadius pts (provisionalCenter pts bId res).o S_birth ^ 2
          V_nonneg := sq_nonneg _ } pts S_birth = S_birth := by
      ext x
      simp only [ChainNode.core, nodeCore, Finset.mem_filter, and_iff_left_iff_imp]
      intro hx
      rw [mem_coreBall_iff_norm_sq_le _ _ (sq_nonneg _)]
      have hNE : S_birth.Nonempty := ⟨x, hx⟩
      have hle : ‖pts x - (provisionalCenter pts bId res).o‖ ≤
          nodeMaxRadius pts (provisionalCenter pts bId res).o S_birth := by
        unfold nodeMaxRadius
        rw [dif_pos hNE]
        exact Finset.le_sup' (fun i => ‖pts i - (provisionalCenter pts bId res).o‖) hx
      exact pow_le_pow_left₀ (norm_nonneg _) hle 2
    rw [hcore_eq]
    have hnn : (0 : ℝ) ≤ (S_birth.card : ℝ) := Nat.cast_nonneg _
    nlinarith

lemma residual_card_contraction {d : ℕ} {ι : Type}
    {α : ℝ} (hα0 : 0 < α) (_hα1 : α ≤ 1 / 2)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (B : ChainNode d) (P₀ S : Finset ι) (a : ℕ)
    (hpass : PassesBirthCoreCheck α pts B P₀)
    (hage : HasNodeAge P₀ S a)
    (ha_le : (a : ℝ) ≤ α * (P₀.card : ℝ) / 16) :
    ((B.residual pts S).card : ℝ) ≤ (1 - α / 4) * (S.card : ℝ) := by
  classical
  rcases hasNodeAge_card_bounds hage with ⟨hS_le, _, hdiff_le⟩
  have hsub : B.core pts P₀ ⊆ B.core pts S ∪ (P₀ \ S) := by
    intro x hx
    simp only [ChainNode.core, nodeCore, Finset.mem_filter] at hx
    by_cases hxS : x ∈ S
    · exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨hxS, hx.2⟩)
    · exact Finset.mem_union_right _ (Finset.mem_sdiff.mpr ⟨hx.1, hxS⟩)
  have hcore_card : (B.core pts P₀).card ≤ (B.core pts S).card + a :=
    (Finset.card_le_card hsub).trans ((Finset.card_union_le _ _).trans (Nat.add_le_add_left hdiff_le _))
  have hres_add : (B.residual pts S).card + (B.core pts S).card = S.card := by
    unfold ChainNode.residual nodeResidual ChainNode.core
    have hsubC : nodeCore pts B.o B.V S ⊆ S := Finset.filter_subset _ _
    exact Finset.card_sdiff_add_card_eq_card hsubC
  have hpass_r : α * (P₀.card : ℝ) / 2 ≤ ((B.core pts P₀).card : ℝ) := hpass
  have hcore_r : ((B.core pts P₀).card : ℝ) ≤ ((B.core pts S).card : ℝ) + (a : ℝ) := by
    exact_mod_cast hcore_card
  have hS_r : (S.card : ℝ) ≤ (P₀.card : ℝ) + (a : ℝ) := by exact_mod_cast hS_le
  have hres_r : ((B.residual pts S).card : ℝ) + ((B.core pts S).card : ℝ) = (S.card : ℝ) := by
    exact_mod_cast hres_add
  have hcoreS_ge : (7 / 16 : ℝ) * α * (P₀.card : ℝ) ≤ ((B.core pts S).card : ℝ) := by linarith
  have hS_le_M : (S.card : ℝ) ≤ (7 / 4 : ℝ) * (P₀.card : ℝ) := by
    have : (a : ℝ) ≤ (3 / 4 : ℝ) * (P₀.card : ℝ) := by
      have hM_nn : (0 : ℝ) ≤ (P₀.card : ℝ) := Nat.cast_nonneg _
      nlinarith
    linarith
  have hcoreS_ge_S : (α / 4) * (S.card : ℝ) ≤ ((B.core pts S).card : ℝ) := by
    nlinarith [mul_le_mul_of_nonneg_left hS_le_M (le_of_lt hα0)]
  linarith

theorem unconditional_chain_len_lt {d n H k : ℕ}
    (hH : 5 ≤ H) (hn2 : n < 2 ^ H)
    {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (P : Finset ι) (hP : P.card ≤ n)
    (nodes : Fin k → ChainNode d)
    (P₀ : Fin k → Finset ι)
    (age : Fin k → ℕ)
    (hvalid : ∀ i : Fin k,
      let α := 1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)
      2 ≤ (P₀ i).card ∧
      PassesBirthCoreCheck α pts (nodes i) (P₀ i) ∧
      HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
      (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) :
    k < 24 * (d + 3) ^ 2 * H := by
  let D := d + 3
  have hD3 : 3 ≤ D := by omega
  have hD2_pos : 1 ≤ (d + 3) ^ 2 := Nat.one_le_pow 2 (d + 3) (by omega)
  obtain ⟨hα0, hα_half, _, _, _⟩ := alpha_pos_and_lt_half D hD3
  let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
  by_cases hk0 : k = 0
  · subst hk0; nlinarith
  · have hk_pos : 1 ≤ k := Nat.pos_of_ne_zero hk0
    have hpow_bound : ∀ (m : ℕ) (hm : m ≤ k),
        ((chainInput pts nodes P ⟨m, Nat.lt_succ_of_le hm⟩).card : ℝ) ≤
          (1 - α / 4) ^ m * (P.card : ℝ) := by
      intro m hm
      induction m with
      | zero =>
          have h0 : chainInput pts nodes P ⟨0, Nat.lt_succ_of_le hm⟩ = P := rfl
          rw [h0, pow_zero, one_mul]
      | succ m ih =>
          have hm_lt : m < k := Nat.lt_of_succ_le hm
          let idx : Fin k := ⟨m, hm_lt⟩
          rcases hvalid idx with ⟨_, hpass, hage, ha_le⟩
          have hstep := residual_card_contraction hα0 hα_half pts (nodes idx) (P₀ idx)
            (chainInput pts nodes P idx.castSucc) (age idx) hpass hage ha_le
          have hci_eq : chainInput pts nodes P ⟨m + 1, Nat.lt_succ_of_le hm⟩ =
              (nodes idx).residual pts (chainInput pts nodes P idx.castSucc) := rfl
          rw [hci_eq]
          have h1_nn : 0 ≤ 1 - α / 4 := by linarith
          calc (((nodes idx).residual pts (chainInput pts nodes P idx.castSucc)).card : ℝ)
              ≤ (1 - α / 4) * ((chainInput pts nodes P idx.castSucc).card : ℝ) := hstep
            _ ≤ (1 - α / 4) * ((1 - α / 4) ^ m * (P.card : ℝ)) :=
                mul_le_mul_of_nonneg_left (ih (Nat.le_of_succ_le hm)) h1_nn
            _ = (1 - α / 4) ^ (m + 1) * (P.card : ℝ) := by ring
    let lastIdx : Fin k := ⟨k - 1, Nat.sub_lt hk_pos Nat.one_pos⟩
    rcases hvalid lastIdx with ⟨hM2, _, hage_last, ha_last⟩
    rcases hasNodeAge_card_bounds hage_last with ⟨_, hM_le_S, _⟩
    have hS_last_ge1 : 1 ≤ (chainInput pts nodes P lastIdx.castSucc).card := by
      have ha_lt_M : age lastIdx < (P₀ lastIdx).card := by
        have hMr : (2 : ℝ) ≤ ((P₀ lastIdx).card : ℝ) := by exact_mod_cast hM2
        have har : (age lastIdx : ℝ) < ((P₀ lastIdx).card : ℝ) := by
          have ha_last' : (age lastIdx : ℝ) ≤ (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) * ((P₀ lastIdx).card : ℝ) / 16 := ha_last
          have hα_eq' : (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) = α := rfl
          rw [hα_eq'] at ha_last'
          nlinarith
        exact_mod_cast har
      omega
    have h1_le_pow : (1 : ℝ) ≤ (1 - α / 4) ^ (k - 1) * (n : ℝ) := by
      have hci := hpow_bound (k - 1) (Nat.sub_le k 1)
      have h1 : (1 : ℝ) ≤ ((chainInput pts nodes P lastIdx.castSucc).card : ℝ) := by
        exact_mod_cast hS_last_ge1
      have hPn : (P.card : ℝ) ≤ (n : ℝ) := by exact_mod_cast hP
      have hbase_nn : 0 ≤ (1 - α / 4) ^ (k - 1) := pow_nonneg (by linarith) _
      exact h1.trans (hci.trans (mul_le_mul_of_nonneg_left hPn hbase_nn))
    have hexp_step : 1 - α / 4 ≤ Real.exp (-(α / 4)) := by
      simpa [sub_eq_add_neg, add_comm] using Real.add_one_le_exp (-(α / 4))
    have hexp_pow : (1 - α / 4) ^ (k - 1) ≤ Real.exp (-((k - 1 : ℕ) : ℝ) * (α / 4)) := by
      calc (1 - α / 4) ^ (k - 1)
          ≤ (Real.exp (-(α / 4))) ^ (k - 1) := pow_le_pow_left₀ (by linarith) hexp_step _
        _ = Real.exp (-((k - 1 : ℕ) : ℝ) * (α / 4)) := by
            rw [← Real.exp_nat_mul]; ring_nf
    have hn_lt_exp : (n : ℝ) < Real.exp (H : ℝ) := by
      have hn_lt_2H : (n : ℝ) < (2 : ℝ) ^ H := by exact_mod_cast hn2
      have h2_le_e : (2 : ℝ) ≤ Real.exp 1 := by
        have := log_two_le_one
        rwa [Real.log_le_iff_le_exp (by norm_num)] at this
      have h2H_le : (2 : ℝ) ^ H ≤ Real.exp (H : ℝ) := by
        calc (2 : ℝ) ^ H ≤ (Real.exp 1) ^ H := pow_le_pow_left₀ (by norm_num) h2_le_e H
          _ = Real.exp (H : ℝ) := by rw [← Real.exp_nat_mul, mul_one]
      exact lt_of_lt_of_le hn_lt_2H h2H_le
    have hprod_lt : (1 : ℝ) < Real.exp ((H : ℝ) - ((k - 1 : ℕ) : ℝ) * (α / 4)) := by
      have hexp_pos : 0 < Real.exp (-((k - 1 : ℕ) : ℝ) * (α / 4)) := Real.exp_pos _
      calc (1 : ℝ)
          ≤ (1 - α / 4) ^ (k - 1) * (n : ℝ) := h1_le_pow
        _ ≤ Real.exp (-((k - 1 : ℕ) : ℝ) * (α / 4)) * (n : ℝ) :=
            mul_le_mul_of_nonneg_right hexp_pow (Nat.cast_nonneg n)
        _ < Real.exp (-((k - 1 : ℕ) : ℝ) * (α / 4)) * Real.exp (H : ℝ) :=
            mul_lt_mul_of_pos_left hn_lt_exp hexp_pos
        _ = Real.exp ((H : ℝ) - ((k - 1 : ℕ) : ℝ) * (α / 4)) := by
            rw [← Real.exp_add]; ring_nf
    have hexp_arg_pos : 0 < (H : ℝ) - ((k - 1 : ℕ) : ℝ) * (α / 4) :=
      Real.exp_lt_exp.mp (by simpa using hprod_lt)
    have hk1_lt : ((k - 1 : ℕ) : ℝ) < 16 * (D : ℝ) ^ 2 * (H : ℝ) := by
      have hdiv_lt : ((k - 1 : ℕ) : ℝ) / (16 * (D : ℝ) ^ 2) < (H : ℝ) := by
        have heq_a : ((k - 1 : ℕ) : ℝ) * (α / 4) = ((k - 1 : ℕ) : ℝ) / (16 * (D : ℝ) ^ 2) := by
          dsimp [α]; ring
        linarith
      have hD_pos : (0 : ℝ) < 16 * (D : ℝ) ^ 2 := by positivity
      have := (div_lt_iff₀ hD_pos).mp hdiv_lt
      linarith
    have hk1_nat : k - 1 < 16 * ((d + 3) ^ 2 * H) := by
      rw [← mul_assoc]; exact_mod_cast hk1_lt
    rw [mul_assoc 24]
    have hpos_prod : 1 ≤ (d + 3) ^ 2 * H := Nat.mul_pos hD2_pos (by omega)
    generalize (d + 3) ^ 2 * H = P_prod at hpos_prod hk1_nat ⊢
    omega

theorem sync_leaf_split_bound {d L : ℕ} (hL1 : 1 ≤ L)
    (m_seq : ℕ → ℕ)
    (hm0 : m_seq 0 ≤ 4 * L + 2)
    (hstep : ∀ r : ℕ, r < 20 * (d + 3) ^ 2 → 2 * L + 1 < m_seq r →
      ∃ c : ℕ, m_seq r ≤ 8 * (d + 3) ^ 2 * c ∧ m_seq (r + 1) + c = m_seq r) :
    m_seq (20 * (d + 3) ^ 2) ≤ 2 * L + 1 ∨
      ∃ r < 20 * (d + 3) ^ 2, m_seq r ≤ 2 * L + 1 := by
  have hD2_ge : 9 ≤ (d + 3) ^ 2 := by
    calc 9 = 3 ^ 2 := by norm_num
      _ ≤ (d + 3) ^ 2 := Nat.pow_le_pow_left (by omega) 2
  generalize hD2_eq : (d + 3) ^ 2 = D2 at hD2_ge hstep ⊢
  by_contra hnot
  push_neg at hnot
  rcases hnot with ⟨hlast_gt, hall_gt⟩
  have hdrop : ∀ r : ℕ, r ≤ 20 * D2 →
      8 * D2 * m_seq r + r * (2 * L + 2) ≤ 8 * D2 * m_seq 0 := by
    intro r hr
    induction r with
    | zero => simp
    | succ r ih =>
        have hr_lt : r < 20 * D2 := Nat.lt_of_succ_le hr
        have hgt_r := hall_gt r hr_lt
        rcases hstep r hr_lt hgt_r with ⟨c, hc_ge, hc_eq⟩
        have h2L : 2 * L + 2 ≤ 8 * D2 * c := by omega
        have ih' := ih (Nat.le_of_succ_le hr)
        have hmul : 8 * D2 * m_seq (r + 1) + 8 * D2 * c = 8 * D2 * m_seq r := by
          rw [← Nat.mul_add, hc_eq]
        nlinarith
  have h20 := hdrop (20 * D2) le_rfl
  have hlast_ge : 2 * L + 2 ≤ m_seq (20 * D2) := by omega
  nlinarith

/-! ### 3. Universal Baseline Constant & Concrete `P46Params` Bundle -/

noncomputable def extractCBaseNat (h_mc : S_clm_5_1_mc_baseline) : ℕ :=
  max 1 (Nat.ceil (Classical.choose h_mc) + 1)

lemma one_le_extractCBaseNat (h_mc : S_clm_5_1_mc_baseline) :
    1 ≤ extractCBaseNat h_mc := le_max_left _ _

lemma exists_cHpj : ∃ cHpj : ℕ, 1 ≤ cHpj ∧ (2 : ℝ) ^ 80 ≤ (cHpj : ℝ) := by
  refine ⟨2 ^ 81, Nat.one_le_pow 81 2 (by decide), ?_⟩
  rw [Nat.cast_pow, Nat.cast_ofNat]
  exact pow_le_pow_right₀ (by norm_num : (1 : ℝ) ≤ 2) (by decide : 80 ≤ 81)

structure P46Params (d n : ℕ) : Type where
  D : ℕ
  H : ℕ
  K_seg : ℕ
  cBase : ℕ
  D₀ : ℕ
  k_φ : ℕ
  φ_ev : ℝ
  K₀ : ℕ
  P_hpj : HPJParams
  M_bits : ℕ
  L : ℕ
  B_scan : ℕ
  K_batch : ℕ
  NumSlots : ℕ
  B_hpj : ℕ
  B_step : ℕ

private lemma mul_div_pow_add_le {A n_r φ : ℝ} {K H : ℕ}
    (hA : 0 ≤ A) (hn : n_r ≤ (2 : ℝ) ^ H)
    (hprob : A * ((1 / 2 : ℝ) ^ K) ≤ φ) :
    A * n_r / ((2 : ℝ) ^ (K + H)) ≤ φ := by
  rw [pow_add]
  have hdiv : A * n_r / ((2 : ℝ) ^ K * (2 : ℝ) ^ H) ≤ A * ((1 / 2 : ℝ) ^ K) := by
    rw [div_le_iff₀ (by positivity)]
    have hcancel : (1 / 2 : ℝ) ^ K * (2 : ℝ) ^ K = 1 := by
      rw [← mul_pow, one_div_mul_cancel (by norm_num : (2 : ℝ) ≠ 0), one_pow]
    calc A * n_r
        ≤ A * (2 : ℝ) ^ H := mul_le_mul_of_nonneg_left hn hA
      _ = A * 1 * (2 : ℝ) ^ H := by ring
      _ = A * ((1 / 2 : ℝ) ^ K * (2 : ℝ) ^ K) * (2 : ℝ) ^ H := by rw [hcancel]
      _ = A * ((1 / 2 : ℝ) ^ K) * ((2 : ℝ) ^ K * (2 : ℝ) ^ H) := by ring
  exact hdiv.trans hprob

theorem build_p46Params
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    {d n t : ℕ} (hn : 2 ≤ n) (ht : 1 ≤ t)
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (D H cBase : ℕ)
    (hD_eq : D = d + 3)
    (hH_eq : H = Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ)))
    (hcB_eq : cBase = extractCBaseNat h_mc) :
    ∃ p : P46Params d n,
      p.D = D ∧
      p.H = H ∧
      p.cBase = cBase ∧
      3 ≤ p.D ∧ 5 ≤ p.H ∧
      n < 2 ^ p.H ∧ t < 2 ^ p.H ∧ p.D < 2 ^ p.H ∧
      1 ≤ p.K_seg ∧ p.K_seg ≤ p.H ∧ n ≤ 2 ^ p.K_seg ∧ 2 ^ p.K_seg < 2 * n ∧
      p.D₀ = 24 * D ^ 2 * H ∧
      p.k_φ = 20 * H ∧
      p.φ_ev = (1 / 2 : ℝ) ^ p.k_φ ∧
      0 < p.φ_ev ∧ p.φ_ev < 1 / 2 ∧
      1 ≤ p.K₀ ∧ p.K₀ ≤ 84 * cBase * D ^ 2 * H ∧
      p.P_hpj = hpjParams d p.φ_ev ∧
      HPJParamProps d p.φ_ev p.P_hpj ∧
      Nat.ceil (hpjOpBound d p.φ_ev) ≤ (cHpj * 21 ^ 3) * D ^ 7 * H ^ 6 ∧
      p.P_hpj.m * D ≤ (cHpj * 21 ^ 3) * D ^ 7 * H ^ 6 ∧
      p.H ≤ p.M_bits ∧
      p.M_bits ≤ (105 + cHpj + 4 * cBase) * H ∧
      ((2 ^ p.P_hpj.q : ℕ) : ℝ) * (n : ℝ) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev ∧
      (p.K₀ : ℝ) * (n : ℝ) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev ∧
      ((2 * p.D₀ + 20 * D ^ 2 + 2 : ℕ) : ℝ) * (2 * p.φ_ev) ≤
        perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ ∧
      p.L = (68719476736 + 8 * (84 * cBase)) * D ^ 4 * H ^ 2 ∧
      68719476736 * D ^ 4 ≤ p.L ∧
      SatisfiesLeafCutoffEq10 d n (1 / (4 * (D : ℝ) ^ 2)) 0 p.K₀ p.L ∧
      p.B_scan = 16777216 * D ^ 4 ∧
      p.K_batch = p.B_scan + 1 ∧
      p.NumSlots = 8 * (p.D₀ + 2) ^ 2 ∧
      p.B_hpj = (2 ^ p.P_hpj.q) * p.M_bits + p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q ∧
      p.B_step = (p.D₀ + 20 * D ^ 2) * p.B_hpj + p.D₀ * p.K₀ * p.M_bits ∧
      (∀ (pts : ℕ → EuclideanSpace ℝ (Fin d))
         (P₀ S : Finset ℕ) (age : ℕ)
         (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
         (y : ℕ) (farthest : (Fin p.K₀ → ℕ) → ℕ),
        1 ≤ P₀.card →
        IsCenterpoint (1 / (4 * (D : ℝ) ^ 2))
          (paraboloidLiftSet (fun i : ↥P₀ => pts i.1)) (liftedPoint o s) →
        HasNodeAge P₀ S age →
        (age : ℝ) ≤ (1 / (4 * (D : ℝ) ^ 2)) * (P₀.card : ℝ) / 16 →
        IsNodeMaxRadiusPoint pts o S y →
        let V := liftVariance o s
        let samples := Fintype.piFinset (fun _ : Fin p.K₀ => S)
        (∀ samp ∈ samples,
          (∃ j : Fin p.K₀, farthest samp = samp j) ∧
          ∀ j : Fin p.K₀, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖) →
        (((open Classical in samples.filter (fun samp =>
            ¬ IsNodeBaselinePair pts o V S y (farthest samp))).card : ℝ) /
          (samples.card : ℝ)) ≤ p.φ_ev) := by
  classical
  have hsb := scale_basic_bounds (d := d) hn ht hδ0 hδ1
  dsimp only at hsb
  rw [← hH_eq, ← hD_eq] at hsb
  obtain ⟨hD3, hH5, _, hn2, ht2, hD2, _⟩ := hsb
  obtain ⟨hα0, hα_half, _, hα_inv, _⟩ := alpha_pos_and_lt_half D hD3
  let K_seg := Nat.clog 2 n
  have hK_ge1 : 1 ≤ K_seg := Nat.clog_pos (by norm_num) (by omega)
  have hn_le_2K : n ≤ 2 ^ K_seg := Nat.le_pow_clog (by norm_num) n
  have hK_le_H : K_seg ≤ H := (Nat.clog_le_iff_le_pow (by norm_num)).mpr (le_of_lt hn2)
  have h2K_lt_2n : 2 ^ K_seg < 2 * n := by
    have hprev : 2 ^ (K_seg - 1) < n :=
      (Nat.lt_clog_iff_pow_lt (by norm_num)).mp (Nat.sub_lt hK_ge1 Nat.one_pos)
    calc 2 ^ K_seg = 2 * 2 ^ (K_seg - 1) := by
          conv_lhs => rw [show K_seg = (K_seg - 1) + 1 by omega, pow_succ']
      _ < 2 * n := by omega
  let k_φ : ℕ := 20 * H
  let φ_ev : ℝ := (1 / 2 : ℝ) ^ k_φ
  have hφ0 : 0 < φ_ev := by positivity
  have hφ_lt_half : φ_ev < 1 / 2 := by
    have hsplit : k_φ = 2 + (20 * H - 2) := by dsimp [k_φ]; omega
    dsimp [φ_ev]
    rw [hsplit, pow_add]
    have hle1 : (1 / 2 : ℝ) ^ (20 * H - 2) ≤ 1 :=
      pow_le_one₀ (by norm_num) (by norm_num)
    have hnn : (0 : ℝ) ≤ (1 / 2 : ℝ) ^ (20 * H - 2) := by positivity
    nlinarith
  have hCmc_spec := Classical.choose_spec h_mc
  let C_mc := Classical.choose h_mc
  rcases hCmc_spec with ⟨_, hmc_all⟩
  rcases hmc_all (1 / (4 * (D : ℝ) ^ 2)) φ_ev hα0 (hα_half.trans (by norm_num))
    hφ0 (hφ_lt_half.trans (by norm_num)) with ⟨K₀, hK0_ge1, hK0_ceil, hmc_inst⟩
  have hlog_1phi : Real.log (1 / φ_ev) ≤ ((20 * H : ℕ) : ℝ) := by
    have h1phi_eq : 1 / φ_ev = (2 : ℝ) ^ (20 * H) := by
      dsimp [φ_ev, k_φ]; rw [one_div, one_div, inv_pow, inv_inv]
    rw [h1phi_eq, Real.log_pow]
    nlinarith [log_two_le_one, (show (0 : ℝ) ≤ ((20 * H : ℕ) : ℝ) by positivity)]
  have hcB_ge : C_mc ≤ (cBase : ℝ) := by
    rw [hcB_eq]; unfold extractCBaseNat
    exact (Nat.le_ceil C_mc).trans (by exact_mod_cast le_trans (Nat.le_succ _) (le_max_right 1 _))
  have hK0_le : K₀ ≤ 4 * cBase * 21 * D ^ 2 * H := by
    have hceil_le : Nat.ceil (C_mc * (1 / (4 * (D : ℝ) ^ 2))⁻¹ * Real.log (1 / φ_ev)) ≤
        4 * cBase * 20 * D ^ 2 * H := by
      refine Nat.ceil_le.mpr ?_
      rw [hα_inv]
      have hlog_nn : 0 ≤ Real.log (1 / φ_ev) :=
        Real.log_nonneg (by rw [one_le_div hφ0]; linarith)
      calc C_mc * (4 * (D : ℝ) ^ 2) * Real.log (1 / φ_ev)
          ≤ (cBase : ℝ) * (4 * (D : ℝ) ^ 2) * ((20 * H : ℕ) : ℝ) := by
            have h1 : C_mc * (4 * (D : ℝ) ^ 2) ≤ (cBase : ℝ) * (4 * (D : ℝ) ^ 2) :=
              mul_le_mul_of_nonneg_right hcB_ge (by positivity)
            exact mul_le_mul h1 hlog_1phi hlog_nn (by positivity)
        _ = ((4 * cBase * 20 * D ^ 2 * H : ℕ) : ℝ) := by generalize (D : ℕ) = Dv; push_cast; ring
    have hmul_le : 4 * cBase * 20 * D ^ 2 * H ≤ 4 * cBase * 21 * D ^ 2 * H := by
      have : 4 * cBase * 20 ≤ 4 * cBase * 21 := by omega
      exact Nat.mul_le_mul_right H (Nat.mul_le_mul_right (D ^ 2) this)
    exact hK0_ceil.trans (hceil_le.trans hmul_le)
  let c81 : ℕ := cHpj
  let D₀ := 24 * D ^ 2 * H
  have hD0_le : D₀ ≤ 8 * 4 * D ^ 2 * H := by
    dsimp [D₀]
    exact Nat.mul_le_mul_right H (Nat.mul_le_mul_right (D ^ 2) (by omega))
  have hfb := failure_budget_bounds (d := d) (n := n) (t := t)
    (cDepthNat := 4) (cHpjNat := c81) (cBaseNat := cBase) (D₀ := D₀) (K₀ := K₀)
    hn ht (by omega) hδ0 hδ1 H hH_eq (hD_eq ▸ hD0_le) (hD_eq ▸ hK0_le)
  dsimp only at hfb
  rw [← hD_eq] at hfb
  rcases hfb with ⟨_, _, hlog_2phi, hN_prob, hK0_prob, hstep_prob⟩
  -- Keep `P_hpj` as an abstract variable with `hP_eq : P_hpj = hpjParams d φ_ev`
  have hexP : ∃ P_hpj : HPJParams, P_hpj = hpjParams d φ_ev ∧ HPJParamProps d φ_ev P_hpj :=
    ⟨hpjParams d φ_ev, rfl, hpjParams_props d hφ0 hφ_lt_half⟩
  rcases hexP with ⟨P_hpj, hP_eq, hP_hpj⟩
  have hlogd2 : Real.log ((d : ℝ) + 2) ≤ (H : ℝ) := log_d_add_two_le_H (hD_eq ▸ hD2)
  have hop_le_real : hpjOpBound d φ_ev ≤ (((c81 * 21 ^ 3 * D ^ 7 * H ^ 6 : ℕ) : ℝ)) := by
    unfold hpjOpBound hpjOpConst
    have hd1 : (d : ℝ) + 1 ≤ (D : ℝ) := by rw [hD_eq]; push_cast; linarith
    have hlogd2_nn : 0 ≤ Real.log ((d : ℝ) + 2) := Real.log_nonneg (by linarith)
    have hlog2p_nn : 0 ≤ Real.log (2 / φ_ev) :=
      Real.log_nonneg (by rw [le_div_iff₀ hφ0]; linarith)
    have hp1 : ((d : ℝ) + 1) ^ 7 ≤ (D : ℝ) ^ 7 := pow_le_pow_left₀ (by positivity) hd1 7
    have hp2 : (Real.log ((d : ℝ) + 2)) ^ 3 ≤ (H : ℝ) ^ 3 := pow_le_pow_left₀ hlogd2_nn hlogd2 3
    have hp3 : (Real.log (2 / φ_ev)) ^ 3 ≤ (((21 * H : ℕ) : ℝ)) ^ 3 :=
      pow_le_pow_left₀ hlog2p_nn hlog_2phi 3
    have hc80 : (2 : ℝ) ^ 80 ≤ (c81 : ℝ) := hcHpj
    have hcast_rhs : (c81 : ℝ) * (D : ℝ) ^ 7 * (H : ℝ) ^ 3 * (((21 * H : ℕ) : ℝ)) ^ 3 =
        (((c81 * 21 ^ 3 * D ^ 7 * H ^ 6 : ℕ) : ℝ)) := by
      generalize (D : ℕ) = Dv
      push_cast; ring
    calc (2 : ℝ) ^ 80 * ((d : ℝ) + 1) ^ 7 * (Real.log ((d : ℝ) + 2)) ^ 3 *
            (Real.log (2 / φ_ev)) ^ 3
        ≤ (c81 : ℝ) * (D : ℝ) ^ 7 * (H : ℝ) ^ 3 * (((21 * H : ℕ) : ℝ)) ^ 3 := by gcongr
      _ = (((c81 * 21 ^ 3 * D ^ 7 * H ^ 6 : ℕ) : ℝ)) := hcast_rhs
  have hop_ceil_le : Nat.ceil (hpjOpBound d φ_ev) ≤ (c81 * 21 ^ 3) * D ^ 7 * H ^ 6 :=
    Nat.ceil_le.mpr hop_le_real
  have hmD_le : P_hpj.m * D ≤ (c81 * 21 ^ 3) * D ^ 7 * H ^ 6 := by
    have hm_op := hP_hpj.2.2.2.2.2.2.2.2.2.2.2.2.2
    have hPD : P_hpj.D = d + 1 := hP_hpj.1
    have hsub : P_hpj.m * D ≤ 100000 * (P_hpj.k_d + P_hpj.k_phi + P_hpj.m * (P_hpj.D + 2) +
        P_hpj.L * ((P_hpj.D + 3) * (P_hpj.q + 1) + (P_hpj.D + 3) ^ 3)) := by
      have hD_eq2 : D = P_hpj.D + 2 := by omega
      rw [hD_eq2]
      exact le_trans (le_trans (Nat.le_add_left _ _) (Nat.le_add_right _ _))
        (Nat.le_mul_of_pos_left _ (by decide : 0 < 100000))
    have hmD_r : ((P_hpj.m * D : ℕ) : ℝ) ≤ (((c81 * 21 ^ 3 * D ^ 7 * H ^ 6 : ℕ) : ℝ)) :=
      (show ((P_hpj.m * D : ℕ) : ℝ) ≤ _ from by exact_mod_cast hsub).trans
        (hm_op.trans hop_le_real)
    exact_mod_cast hmD_r
  obtain ⟨K_rank, hKr_eq⟩ : ∃ K_rank : ℕ, K_rank = (16 + 4) * H + (20 + c81 + 3 * (17 + 4) + 4 * cBase) * H :=
    ⟨_, rfl⟩
  rw [← hKr_eq] at hN_prob hK0_prob
  let M_bits : ℕ := K_rank + H
  have hM_ge_H : H ≤ M_bits := Nat.le_add_left H K_rank
  have hM_le : M_bits ≤ (105 + c81 + 4 * cBase) * H := by
    have heq : (16 + 4) * H + (20 + c81 + 3 * (17 + 4) + 4 * cBase) * H + H =
        (104 + c81 + 4 * cBase) * H := by ring
    dsimp [M_bits]
    rw [hKr_eq, heq]
    exact Nat.mul_le_mul_right H (by omega)
  have hn_lt_r : (n : ℝ) ≤ (2 : ℝ) ^ H := by
    have : n ≤ 2 ^ H := le_of_lt hn2
    exact_mod_cast this
  have h17_4 : (17 + 4 : ℕ) = 21 := rfl
  rw [h17_4] at hN_prob
  have hbias_hpj : ((2 ^ P_hpj.q : ℕ) : ℝ) * (n : ℝ) / ((2 : ℝ) ^ M_bits) ≤ φ_ev := by
    rw [← hP_hpj.2.2.2.2.2.2.2.1]
    have hm_le_N : P_hpj.m ≤ (c81 * 21 ^ 3) * D ^ 7 * H ^ 6 :=
      (Nat.le_mul_of_pos_right P_hpj.m (by omega : 0 < D)).trans hmD_le
    have hm_r : (P_hpj.m : ℝ) ≤ (((c81 * 21 ^ 3 * D ^ 7 * H ^ 6 : ℕ) : ℝ)) := by
      exact_mod_cast hm_le_N
    have hprob_m : (P_hpj.m : ℝ) * ((1 / 2 : ℝ) ^ K_rank) ≤ φ_ev :=
      (mul_le_mul_of_nonneg_right hm_r (by positivity)).trans hN_prob
    exact mul_div_pow_add_le (Nat.cast_nonneg _) hn_lt_r hprob_m
  have hbias_mc : (K₀ : ℝ) * (n : ℝ) / ((2 : ℝ) ^ M_bits) ≤ φ_ev :=
    mul_div_pow_add_le (Nat.cast_nonneg _) hn_lt_r hK0_prob
  let K_coeff := 84 * cBase
  have hK0_coeff : K₀ ≤ K_coeff * D ^ 2 * H := by
    have heq84 : 4 * cBase * 21 = K_coeff := by dsimp [K_coeff]; ring
    rwa [← heq84]
  let L := (68719476736 + 8 * K_coeff) * D ^ 4 * H ^ 2
  have hEq10 : SatisfiesLeafCutoffEq10 d n (1 / (4 * (D : ℝ) ^ 2)) 0 K₀ L := by
    have h := satisfiesLeafCutoffEq10_of_L_cut hn hH5 hn2 (hD_eq ▸ hK0_coeff)
    dsimp only at h
    rwa [← hD_eq] at h
  have hL_ge : 68719476736 * D ^ 4 ≤ L := by
    dsimp [L]
    have hH2 : 1 ≤ H ^ 2 := Nat.one_le_pow 2 H (by omega)
    calc 68719476736 * D ^ 4 = 68719476736 * D ^ 4 * 1 := (Nat.mul_one _).symm
      _ ≤ (68719476736 + 8 * K_coeff) * D ^ 4 * H ^ 2 :=
          Nat.mul_le_mul (Nat.mul_le_mul_right (D ^ 4) (Nat.le_add_right _ _)) hH2
  let B_scan := 16777216 * D ^ 4
  let K_batch := B_scan + 1
  let NumSlots := 8 * (D₀ + 2) ^ 2
  let B_hpj := (2 ^ P_hpj.q) * M_bits + P_hpj.L * (d + 1 + 3) * P_hpj.q
  let B_step := (D₀ + 20 * D ^ 2) * B_hpj + D₀ * K₀ * M_bits
  refine ⟨{ D := D, H := H, K_seg := K_seg, cBase := cBase, D₀ := D₀, k_φ := k_φ, φ_ev := φ_ev,
            K₀ := K₀, P_hpj := P_hpj, M_bits := M_bits, L := L, B_scan := B_scan,
            K_batch := K_batch, NumSlots := NumSlots, B_hpj := B_hpj, B_step := B_step },
    rfl, rfl, rfl, hD3, hH5, hn2, ht2, hD2,
    hK_ge1, hK_le_H, hn_le_2K, h2K_lt_2n,
    rfl, rfl, rfl, hφ0, hφ_lt_half, hK0_ge1, hK0_coeff,
    hP_eq, hP_hpj, hop_ceil_le, hmD_le, hM_ge_H, hM_le,
    hbias_hpj, hbias_mc, hstep_prob, rfl, hL_ge, hEq10,
    rfl, rfl, rfl, rfl, rfl, ?_⟩
  intro pts P₀ S age o s y farthest hP0 hcp hage ha_le hmax V samples hfar
  exact (hmc_inst d ℕ pts Unit (fun _ => P₀) (fun _ => S) (fun _ => age)
    (fun _ => o) (fun _ => s)).2 (fun _ => y) (fun _ => farthest) () hP0 hcp hage ha_le hmax hfar

/-! ### 4. Baseline Witness Bad-Cardinality & Factor-`√2` Answer Lemmas -/

open Classical in
theorem p46_mc_baseline_bad_card_le {d n : ℕ}
    (p : P46Params d n)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (S : Finset ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (y : ℕ)
    (hS_pos : 0 < S.card) (hS_le_n : S.card ≤ n)
    (enum : Fin S.card ≃ ↥S)
    (hmc_prop :
      let V := liftVariance o s
      let samples := Fintype.piFinset (fun _ : Fin p.K₀ => S)
      ∀ farthest : (Fin p.K₀ → ℕ) → ℕ,
        (∀ samp ∈ samples,
          (∃ j : Fin p.K₀, farthest samp = samp j) ∧
          ∀ j : Fin p.K₀, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖) →
        (((samples.filter (fun samp =>
            ¬ IsNodeBaselinePair pts o V S y (farthest samp))).card : ℝ) /
          (samples.card : ℝ)) ≤ p.φ_ev)
    (hφ0 : 0 < p.φ_ev)
    (hbias : (p.K₀ : ℝ) * (n : ℝ) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev)
    (hK0_pos : 1 ≤ p.K₀) :
    let V := liftVariance o s
    ((Finset.univ.filter (fun sampBits : Fin p.K₀ → Fin p.M_bits → Bool =>
        let rk := modSampleTuple hS_pos p.K₀ p.M_bits sampBits
        ∀ j : Fin p.K₀, ¬ IsNodeBaselinePair pts o V S y (enum (rk j)).1)).card : ℝ) ≤
      (2 * p.φ_ev) * ((2 : ℝ) ^ (p.K₀ * p.M_bits)) := by
  classical
  intro V
  let BadRk : (Fin p.K₀ → Fin S.card) → Prop := fun rk =>
    ∀ j : Fin p.K₀, ¬ IsNodeBaselinePair pts o V S y (enum (rk j)).1
  have hk_ne : (Finset.univ : Finset (Fin p.K₀)).Nonempty :=
    ⟨⟨0, hK0_pos⟩, Finset.mem_univ _⟩
  let farthest : (Fin p.K₀ → ℕ) → ℕ := fun samp =>
    samp (Classical.choose (Finset.exists_mem_eq_sup' hk_ne (fun j : Fin p.K₀ => ‖pts (samp j) - pts y‖)))
  have hf_spec : ∀ samp ∈ Fintype.piFinset (fun _ : Fin p.K₀ => S),
      (∃ j : Fin p.K₀, farthest samp = samp j) ∧
      ∀ j : Fin p.K₀, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖ := by
    intro samp _
    let j_max := Classical.choose
      (Finset.exists_mem_eq_sup' hk_ne (fun j : Fin p.K₀ => ‖pts (samp j) - pts y‖))
    have hj_spec := Classical.choose_spec
      (Finset.exists_mem_eq_sup' hk_ne (fun j : Fin p.K₀ => ‖pts (samp j) - pts y‖))
    refine ⟨⟨j_max, rfl⟩, fun j => ?_⟩
    change ‖pts (samp j) - pts y‖ ≤ ‖pts (samp j_max) - pts y‖
    rw [← hj_spec.2]
    exact Finset.le_sup' (fun j : Fin p.K₀ => ‖pts (samp j) - pts y‖) (Finset.mem_univ j)
  have hmc_applied := hmc_prop farthest hf_spec
  let samples := Fintype.piFinset (fun _ : Fin p.K₀ => S)
  have hsamp_card : (samples.card : ℝ) = (S.card : ℝ) ^ p.K₀ := by
    simp [samples, Fintype.card_fin]
  have hBadRk_le : ((Finset.univ.filter BadRk).card : ℝ) ≤ p.φ_ev * ((S.card : ℝ) ^ p.K₀) := by
    have hinj_le : (Finset.univ.filter BadRk).card ≤
        (samples.filter (fun samp => ¬ IsNodeBaselinePair pts o V S y (farthest samp))).card := by
      refine Finset.card_le_card_of_injOn (fun rk => fun j => (enum (rk j)).1) ?_ ?_
      · intro rk hrk
        have hB := (Finset.mem_filter.mp (Finset.mem_coe.mp hrk)).2
        have hmem_s : (fun j => (enum (rk j)).1) ∈ samples :=
          Fintype.mem_piFinset.mpr fun j => (enum (rk j)).2
        rcases (hf_spec _ hmem_s).1 with ⟨j₀, hj₀⟩
        exact Finset.mem_coe.mpr (Finset.mem_filter.mpr ⟨hmem_s, hj₀ ▸ hB j₀⟩)
      · intro rk₁ _ rk₂ _ heq
        funext j
        exact enum.injective (Subtype.ext (congrFun heq j))
    have hinj_r : ((Finset.univ.filter BadRk).card : ℝ) ≤
        ((samples.filter (fun samp => ¬ IsNodeBaselinePair pts o V S y (farthest samp))).card : ℝ) := by
      exact_mod_cast hinj_le
    have hpos_sc : (0 : ℝ) < (samples.card : ℝ) := by
      rw [hsamp_card]; positivity
    have hmul := (div_le_iff₀ hpos_sc).mp hmc_applied
    rw [hsamp_card] at hmul
    exact hinj_r.trans hmul
  have hmod := modSample_bad_card_le hS_pos p.K₀ p.M_bits BadRk (le_of_lt hφ0) hBadRk_le
  rw [← pow_mul, mul_comm p.M_bits p.K₀] at hmod
  have hSn : (p.K₀ : ℝ) * (S.card : ℝ) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev := by
    have h1 : (S.card : ℝ) ≤ (n : ℝ) := by exact_mod_cast hS_le_n
    calc (p.K₀ : ℝ) * (S.card : ℝ) / ((2 : ℝ) ^ p.M_bits)
        ≤ (p.K₀ : ℝ) * (n : ℝ) / ((2 : ℝ) ^ p.M_bits) := by gcongr
      _ ≤ p.φ_ev := hbias
  have hsum_phi : p.φ_ev + (p.K₀ : ℝ) * (S.card : ℝ) / ((2 : ℝ) ^ p.M_bits) ≤ 2 * p.φ_ev := by
    linarith
  exact hmod.trans (mul_le_mul_of_nonneg_right hsum_phi (by positivity))

theorem p46_valid_answer_of_chain_and_leaf
    (h_lem_5_2 : S_lem_5_2)
    {d n k : ℕ} {P : DynamicPointSet d}
    (hP : P.WellFormed n)
    (hcard2 : 2 ≤ P.activeIds.card)
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {ActiveUids : Finset ℕ}
    {uidOfH : ℕ → ℕ} {hOfUid : ℕ → ℕ}
    (hbij_H : ∀ h ∈ P.activeHandles,
      uidOfH h ∈ ActiveUids ∧ ghostCoords (uidOfH h) = P.handleCoords h ∧ hOfUid (uidOfH h) = h)
    (hbij_U : ∀ u ∈ ActiveUids, hOfUid u ∈ P.activeHandles ∧ uidOfH (hOfUid u) = u)
    (nodes : Fin k → ChainNode d)
    (basePairs : Fin k → Option (ℕ × ℕ))
    (leafPair : Option (ℕ × ℕ))
    (h_base : ∀ i : Fin k,
      (nodes i).SatisfiesBaselineCond ghostCoords
        (chainInput ghostCoords nodes ActiveUids i.castSucc) (basePairs i))
    (h_leaf_act : IsActiveNodePair (chainTerminal ghostCoords nodes ActiveUids) leafPair)
    (h_leaf_diam :
      baselinePairLength ghostCoords leafPair =
        indexedEuclideanDiam (chainTerminal ghostCoords nodes ActiveUids) ghostCoords)
    {bestH1 bestH2 : ℕ}
    (hb1 : bestH1 ∈ P.activeHandles) (hb2 : bestH2 ∈ P.activeHandles) (hb_ne : bestH1 ≠ bestH2)
    (hb_base : ∀ i : Fin k, ∀ u v : ℕ,
      basePairs i = some (u, v) → u ≠ v →
        ‖ghostCoords u - ghostCoords v‖ ^ 2 ≤
          euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2))
    (hb_leaf : ∀ u v : ℕ,
      leafPair = some (u, v) → u ≠ v →
        ‖ghostCoords u - ghostCoords v‖ ^ 2 ≤
          euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2)) :
    IsValidFactorCAnswer (Real.sqrt 2) P
      { diameterHandles := some (bestH1, bestH2)
        cachedDistSq := euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2) } := by
  unfold IsValidFactorCAnswer
  have hnot1 : ¬ P.activeIds.card ≤ 1 := by omega
  simp only [hnot1, ↓reduceIte]
  refine ⟨bestH1, bestH2, rfl, hb1, hb2, hb_ne, ?_, ?_⟩
  · simp only [DynamicPointSet.handleCoords, if_pos hb1, if_pos hb2]
  · let id₁ := P.idOfHandle bestH1
    let id₂ := P.idOfHandle bestH2
    have hid1_mem : id₁ ∈ P.activeIds := (hP.2.2.1 bestH1 hb1).1
    have hid2_mem : id₂ ∈ P.activeIds := (hP.2.2.1 bestH2 hb2).1
    have hid_ne : id₁ ≠ id₂ := by
      intro heq; apply hb_ne
      dsimp only [id₁, id₂] at heq
      have e1 := (hP.2.2.1 bestH1 hb1).2
      have e2 := (hP.2.2.1 bestH2 hb2).2
      rw [← e1, ← e2, heq]
    have hpt1 : P.coords id₁ = P.handleCoords bestH1 := by
      simp only [DynamicPointSet.handleCoords, if_pos hb1]; rfl
    have hpt2 : P.coords id₂ = P.handleCoords bestH2 := by
      simp only [DynamicPointSet.handleCoords, if_pos hb2]; rfl
    have hub : ‖P.coords id₁ - P.coords id₂‖ ≤ indexedEuclideanDiam P.activeIds P.coords := by
      unfold indexedEuclideanDiam
      have hNE : P.activeIds.Nonempty := ⟨id₁, hid1_mem⟩
      rw [dif_pos hNE]
      exact Finset.le_sup' (s := P.activeIds ×ˢ P.activeIds)
        (f := fun xy : ℕ × ℕ => ‖P.coords xy.1 - P.coords xy.2‖) (b := (id₁, id₂))
        (Finset.mem_product.mpr ⟨hid1_mem, hid2_mem⟩)
    refine ⟨hid1_mem, hid2_mem, hid_ne, ?_, hub⟩
    have hdiam_eq1 : indexedEuclideanDiam ActiveUids ghostCoords =
        indexedEuclideanDiam P.activeHandles P.handleCoords :=
      (indexedEuclideanDiam_bij P.activeHandles P.handleCoords ActiveUids ghostCoords
        uidOfH hOfUid hbij_H hbij_U).symm
    have hdiam_eq : indexedEuclideanDiam ActiveUids ghostCoords =
        indexedEuclideanDiam P.activeIds P.coords :=
      hdiam_eq1.trans (handleDiam_eq_pointSet_diam hP)
    have h52 := (h_lem_5_2 d ℕ k ghostCoords ActiveUids nodes basePairs leafPair
      h_base h_leaf_act h_leaf_diam).1
    rw [hdiam_eq] at h52
    by_cases hdiam0 : indexedEuclideanDiam P.activeIds P.coords ≤ 0
    · exact (div_nonpos_of_nonpos_of_nonneg hdiam0 (Real.sqrt_nonneg 2)).trans (norm_nonneg _)
    · push_neg at hdiam0
      have hdiv_pos : 0 < indexedEuclideanDiam P.activeIds P.coords / Real.sqrt 2 :=
        div_pos hdiam0 (Real.sqrt_pos.mpr (by norm_num))
      let candFn : Fin (k + 1) → ℝ :=
        Fin.lastCases (baselinePairLength ghostCoords leafPair)
          (fun i => baselinePairLength ghostCoords (basePairs i))
      obtain ⟨j, _, hj_eq⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty candFn
      rw [hj_eq] at h52
      have hcand_pos : 0 < candFn j := lt_of_lt_of_le hdiv_pos h52
      have hcand_le : candFn j ≤ ‖P.handleCoords bestH1 - P.handleCoords bestH2‖ := by
        induction j using Fin.lastCases with
        | last =>
            simp only [candFn, Fin.lastCases_last] at hcand_pos ⊢
            cases hlp : leafPair with
            | none => simp [hlp, baselinePairLength] at hcand_pos
            | some uv =>
                rcases uv with ⟨u, v⟩
                simp only [hlp, baselinePairLength] at hcand_pos ⊢
                have hne : u ≠ v := fun heq => by subst heq; simp at hcand_pos
                have hsq := hb_leaf u v hlp hne
                unfold euclideanDistSq at hsq
                exact (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).mp hsq
        | cast i =>
            simp only [candFn, Fin.lastCases_castSucc] at hcand_pos ⊢
            cases hbp : basePairs i with
            | none => simp [hbp, baselinePairLength] at hcand_pos
            | some uv =>
                rcases uv with ⟨u, v⟩
                simp only [hbp, baselinePairLength] at hcand_pos ⊢
                have hne : u ≠ v := fun heq => by subst heq; simp at hcand_pos
                have hsq := hb_base i u v hbp hne
                unfold euclideanDistSq at hsq
                exact (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).mp hsq
      rw [hpt1, hpt2]
      exact h52.trans hcand_le

/-! ### 5. Master Horizon-`t` Adaptive Bridge Theorem (`p46_horizon_bridge`) -/

noncomputable def mkStepInput {d : ℕ} (n : ℕ) (P : DynamicPointSet d) (op : DynamicUpdate d) :
    ArithRAMInput d :=
  match toInternalUpdate P op with
  | .insert pt =>
      { intParams := [(n : ℤ), 1, 0]
        activeHandles := P.activeHandles
        activeCoords := P.handleCoords
        extraReals := List.ofFn (fun i : Fin d => euclideanCoord pt i) }
  | .delete h =>
      { intParams := [(n : ℤ), 0, (h : ℤ)]
        activeHandles := P.activeHandles
        activeCoords := P.handleCoords
        extraReals := [] }

lemma mkStepInput_space_le {d n : ℕ} {P : DynamicPointSet d}
    (hP : P.WellFormed n) (op : DynamicUpdate d) :
    (mkStepInput n P op).inputCellSpace ≤ 3 + n * (d + 1) + d := by
  have hcard : P.activeHandles.card ≤ n := by
    rw [activeHandles_card_eq_activeIds_card hP]; exact hP.1
  unfold mkStepInput
  cases toInternalUpdate P op with
  | insert pt =>
      simp only [ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil, List.length_ofFn]
      nlinarith
  | delete h =>
      simp only [ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil]
      nlinarith

def readStepRetH {d : ℕ} (op : DynamicUpdate d) (mem : ArithRAMMemory) : Option ℕ :=
  match op with
  | .insert _ _ _ => ArithRAMDynamicProgram.readReturnedHandle mem
  | .delete _ => none

def readStoredAns (mem : ArithRAMMemory) : StoredDiameterAnswer :=
  let ca := ArithRAMDynamicProgram.readCachedAnswer mem
  { diameterHandles := ca.1, cachedDistSq := ca.2 }

private lemma totalEvents_const_one {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) :
    ∀ (l : List (List Bool)) (cur out : AdaptivePrefixState d State),
      runAdaptiveStepsFrom alg adv cur l = some out →
        adaptiveStepsTotalEvents alg adv (fun _ _ _ _ _ => 1) cur l = l.length
  | [], _, _, _ => by simp [adaptiveStepsTotalEvents]
  | b :: tail, cur, out, hrun => by
      simp only [runAdaptiveStepsFrom] at hrun
      simp only [adaptiveStepsTotalEvents]
      cases hs : runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) b with
      | none => rw [hs] at hrun; simp at hrun
      | some res =>
          rcases res with ⟨P', stepOut⟩
          rw [hs] at hrun
          dsimp only at hrun ⊢
          have ih := totalEvents_const_one alg adv tail _ out hrun
          rw [ih, List.length_cons, Nat.add_comm]

private lemma runAdaptiveStepsFrom_append_one {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) :
    ∀ (l₁ : List (List Bool)) (b : List Bool) (cur : AdaptivePrefixState d State),
      runAdaptiveStepsFrom alg adv cur (l₁ ++ [b]) =
        match runAdaptiveStepsFrom alg adv cur l₁ with
        | none => none
        | some mid => runAdaptiveStepsFrom alg adv mid [b]
  | [], b, cur => rfl
  | x :: xs, b, cur => by
      simp only [List.cons_append, runAdaptiveStepsFrom]
      cases runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) x with
      | none => rfl
      | some pair => exact runAdaptiveStepsFrom_append_one alg adv xs b _

theorem p46_horizon_bridge
    (h_fb : S_clm_7_3_failure_budget)
    {d n t : ℕ} (hn : 2 ≤ n) (ht : 1 ≤ t)
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (updateBody : ArithRAMStmt)
    {B_step uBound T_max M_box : ℕ}
    (hBoxSafe : BoxSafeInner T_max M_box updateBody)
    {φ_step stepWorkBound spaceBound : ℝ}
    (SafeInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop)
    (GoodInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop)
    (hφ_le : φ_step ≤ perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ)
    (hu_le : (max 1 uBound : ℝ) ≤ stepWorkBound)
    (hs_le : ((max 1 (3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound) : ℕ) : ℝ) ≤ spaceBound)
    (hSafe₀ : SafeInv 0 (DynamicPointSet.empty d) ArithRAMMemory.empty)
    (hGood₀ : GoodInv 0 (DynamicPointSet.empty d) ArithRAMMemory.empty)
    (hStep : ∀ (k : ℕ) (P : DynamicPointSet d) (mem₀ : ArithRAMMemory) (op : DynamicUpdate d),
      k < t →
      P.WellFormed n →
      mem₀.popDepth 0 = mem₀ →
      HeapOnlyInBox T_max M_box mem₀ →
      SafeInv k P mem₀ →
      IsLegalUpdate n Set.univ P op →
        ∃ (Post : (Fin B_step → Bool) → ArithRAMMemory → Prop)
          (Bad : (Fin B_step → Bool) → Prop) (_ : DecidablePred Bad),
          RandExecAt 1 (mkStepInput n P op) updateBody B_step mem₀ Post uBound ∧
          ((Finset.univ.filter Bad).card : ℝ) ≤ φ_step * ((2 : ℝ) ^ B_step) ∧
          (∀ (bits : Fin B_step → Bool) (m₁ : ArithRAMMemory),
            Post bits m₁ →
              let m_out := m₁.popDepth 0
              ∃ P' : DynamicPointSet d,
                applyDynamicUpdate P op (readStepRetH op m_out) = some P' ∧
                SafeInv (k + 1) P' m_out ∧
                (GoodInv k P mem₀ → ¬ Bad bits →
                  IsValidFactorCAnswer (Real.sqrt 2) P' (readStoredAns m_out) ∧
                  GoodInv (k + 1) P' m_out))) :
    let prog : ArithRAMDynamicProgram := { initStmt := .skip, updateStmt := .localScope updateBody }
    ∃ initOut : ArithRAMExecOutcome,
      prog.evalInit n d = some initOut ∧
      let alg := mkArithAlg d n prog initOut
      SatisfiesDynamicStorageAndQueryModel 4 1 alg ∧
      SatisfiesMonteCarloGuarantee n t δ (Real.sqrt 2) Set.univ alg ∧
      SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg stepWorkBound ∧
      SatisfiesBoundedSpaceBound n t Set.univ alg spaceBound := by
  classical
  intro prog
  have hpop_emp : ArithRAMMemory.empty.popDepth 0 = ArithRAMMemory.empty := by
    simp [ArithRAMMemory.popDepth, ArithRAMMemory.empty, WordStore.popDepth, WordStore.empty,
      RealStore.popDepth, RealStore.empty]
  have hinit_det : DetExec
      ({ intParams := [(n : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [] } :
        ArithRAMInput d)
      .skip (ArithRAMMemory.empty.popDepth 0) (ArithRAMMemory.empty.popDepth 0) 1 :=
    (DetExecAt.skip 0 _ _).mono_cost (by omega)
  rcases DetExec.to_spec hinit_det with ⟨initOut, hinit_some, hinit_u, hinit_pk, hinit_mem⟩
  have hinit_mem_emp : initOut.mem = ArithRAMMemory.empty := by
    rw [hinit_mem, hpop_emp, hpop_emp]
  have hca_emp : ArithRAMDynamicProgram.readCachedAnswer initOut.mem = (none, 0) := by
    rw [hinit_mem_emp]
    simp [ArithRAMDynamicProgram.readCachedAnswer, ArithRAMMemory.empty,
      WordStore.read, WordStore.empty, RealStore.read, RealStore.empty]
  refine ⟨initOut, hinit_some, ?_⟩
  intro alg
  have hSM : SatisfiesDynamicStorageAndQueryModel 4 1 alg :=
    mkArithAlg_satisfies_storage_query_model d n prog initOut hca_emp
  let ReachInv : DynamicPointSet d → ExecutionHistory d → ArithRAMMemory → Prop :=
    fun P hist mem =>
      P.WellFormed n ∧
      mem.popDepth 0 = mem ∧
      HeapOnlyInBox T_max M_box mem ∧
      SafeInv hist.length P mem
  have hReach₀ : ReachInv (DynamicPointSet.empty d) [] alg.initState := by
    dsimp only [ReachInv, alg, mkArithAlg, List.length_nil]
    rw [hinit_mem_emp]
    refine ⟨?_, hpop_emp, heapOnlyInBox_empty T_max M_box, hSafe₀⟩
    exact ⟨Nat.zero_le n, fun _ h => by simp [DynamicPointSet.empty] at h,
      fun _ h => by simp [DynamicPointSet.empty] at h,
      fun _ h => by simp [DynamicPointSet.empty] at h,
      fun _ h => by simp [DynamicPointSet.empty] at h⟩
  have hpop_idem : ∀ m : ArithRAMMemory, (m.popDepth 0).popDepth 0 = m.popDepth 0 := by
    rintro ⟨⟨wl, wv⟩, ⟨rl, rv⟩⟩
    simp only [ArithRAMMemory.popDepth, WordStore.popDepth, RealStore.popDepth,
      ArithRAMMemory.mk.injEq, WordStore.mk.injEq, RealStore.mk.injEq]
    exact ⟨⟨by ext x; simp, funext fun x => by by_cases h : x.keepAtDepth 0 = true <;> simp [h]⟩,
           ⟨by ext x; simp, funext fun x => by by_cases h : x.keepAtDepth 0 = true <;> simp [h]⟩⟩
  have hstep_eq : ∀ (P : DynamicPointSet d) (mem : ArithRAMMemory)
      (op : DynamicUpdate d) (bs : List Bool),
      alg.stepWithBits P.activeHandles P.handleCoords mem (toInternalUpdate P op) bs =
      (runArithRAMWithBits (.localScope updateBody) (mkStepInput n P op) mem bs).map (fun raw =>
        let ca := ArithRAMDynamicProgram.readCachedAnswer raw.mem
        { nextState := raw.mem
          returnedHandle := readStepRetH op raw.mem
          storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
          work := raw.unitCost
          peakSpace := raw.peakCellSpace }) := by
    intro P mem op bs
    cases op with
    | insert id ext pt =>
        simp [alg, mkArithAlg, prog, ArithRAMDynamicProgram.evalUpdate,
          mkStepInput, toInternalUpdate, readStepRetH]
    | delete id =>
        simp [alg, mkArithAlg, prog, ArithRAMDynamicProgram.evalUpdate,
          mkStepInput, toInternalUpdate, readStepRetH]
  have hReach_trace : ∀ (adv : AdaptiveAdversary d),
      IsValidBoundedAdversary n t Set.univ alg adv →
      ∀ (bitTrace : List (List Bool)) (prefSt : AdaptivePrefixState d ArithRAMMemory),
        bitTrace.length ≤ t →
        runAdaptiveSteps alg adv bitTrace = some prefSt →
          prefSt.history.length = bitTrace.length ∧
          ReachInv prefSt.pointSet prefSt.history prefSt.algState := by
    intro adv hadv bitTrace
    induction bitTrace using List.reverseRecOn with
    | nil =>
        intro prefSt _ hrun
        simp only [runAdaptiveSteps, runAdaptiveStepsFrom] at hrun
        injection hrun with heq; subst heq
        exact ⟨rfl, hReach₀⟩
    | append_singleton xs b ih =>
        intro prefSt hlen hrun
        simp only [List.length_append, List.length_singleton] at hlen
        change runAdaptiveStepsFrom alg adv (initAdaptivePrefixState alg) (xs ++ [b]) = some prefSt at hrun
        rw [runAdaptiveStepsFrom_append_one] at hrun
        cases hmid_eq : runAdaptiveStepsFrom alg adv (initAdaptivePrefixState alg) xs with
        | none => rw [hmid_eq] at hrun; simp at hrun
        | some mid =>
            rw [hmid_eq] at hrun
            dsimp only at hrun

            rcases ih mid (by omega) hmid_eq with ⟨hlen_mid, hP_wf, hclean, hbox, hsafe⟩
            have hleg : IsLegalUpdate n Set.univ mid.pointSet (adv mid.history) :=
              hadv xs (by omega) mid hmid_eq
            rcases hStep xs.length mid.pointSet mid.algState (adv mid.history)
              (by omega) hP_wf hclean hbox (hlen_mid ▸ hsafe) hleg with
              ⟨Post, _, _, hRE, _, hPost_imp⟩
            have hRE1_c : RandExecAt 1 (mkStepInput n mid.pointSet (adv mid.history))
                updateBody B_step ((mid.algState.popDepth 0).popDepth 0) Post uBound := by
              rwa [hclean, hclean]
            have hRE' := RandExecAt.localScope hRE1_c
            rcases RandExec.to_spec hRE' with ⟨hnone_ne, hsome_ofFn⟩
            dsimp only [runAdaptiveStepsFrom] at hrun
            cases hs1 : runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) b with
            | none => rw [hs1] at hrun; simp at hrun
            | some pair =>
                rw [hs1] at hrun
                rcases pair with ⟨P', stepOut⟩
                injection hrun with hpref_eq
                subst hpref_eq
                simp only [runSingleAdaptiveStep, hstep_eq] at hs1
                cases hraw : runArithRAMWithBits (.localScope updateBody)
                    (mkStepInput n mid.pointSet (adv mid.history)) mid.algState b with
                | none => rw [hraw] at hs1; simp at hs1
                | some raw =>
                    rw [hraw] at hs1
                    simp only [Option.map_some] at hs1
                    have hb_len : b.length = B_step := by
                      by_contra hne
                      have := hnone_ne b hne
                      rw [hraw] at this; simp at this
                    let bits : Fin B_step → Bool := fun j => b[j.val]'(by omega)
                    have hb_ofFn : List.ofFn bits = b := by
                      apply List.ext_getElem
                      · simp [hb_len]
                      · intro i _ _; simp [bits]
                    rcases hsome_ofFn bits with ⟨raw', hraw', _, _, m_sc, ⟨m₁, hPost_m1, rfl⟩, hm_eq⟩
                    rw [popDepth_zero_idem] at hm_eq
                    rw [hb_ofFn, hraw] at hraw'
                    injection hraw' with hraw_eq; subst hraw_eq
                    have hbox1 : HeapOnlyInBox T_max M_box raw.mem :=
                      (runArithRAMWithBits_localScope_box hBoxSafe hbox hraw).1
                    rcases hPost_imp bits m₁ hPost_m1 with ⟨P'', happ'', hsafe1, _⟩
                    rw [← hm_eq] at happ'' hsafe1
                    rw [happ''] at hs1
                    injection hs1 with hpair_eq
                    rcases Prod.mk.inj hpair_eq with ⟨hp_eq, hout_eq⟩
                    subst hp_eq hout_eq
                    refine ⟨by simp [hlen_mid], ?_, ?_, hbox1, ?_⟩
                    · exact applyDynamicUpdate_wellFormed hP_wf hleg happ''
                    · rw [hm_eq]; exact popDepth_zero_idem m₁
                    · simpa [hlen_mid] using hsafe1
  let S := execFailureScaleBit n t d 0 δ
  let φ := perEventFailureBudget S 1 δ
  have ht_le_S : (t : ℝ) ≤ 1 * ((S : ℝ) ^ 1) := by
    have : t ≤ S := by unfold S execFailureScaleBit; omega
    simpa using (show (t : ℝ) ≤ (S : ℝ) from by exact_mod_cast this)
  have hSφ_le_δ : (1 * ((S : ℝ) ^ 1)) * φ ≤ δ := by
    have hS_ne : (S : ℝ) ≠ 0 := by
      have : 0 < S := by unfold S execFailureScaleBit; omega
      exact_mod_cast (by omega : S ≠ 0)
    dsimp [φ, perEventFailureBudget]
    field_simp
    exact le_rfl
  have hinit_w : (alg.initWork : ℝ) ≤ stepWorkBound := by
    have h1 : (alg.initWork : ℝ) ≤ ((max 1 uBound : ℕ) : ℝ) := by
      dsimp [alg, mkArithAlg]
      exact_mod_cast (hinit_u.trans (le_max_left 1 uBound))
    rw [Nat.cast_max, Nat.cast_one] at h1
    exact h1.trans hu_le
  have hinit_sp : (alg.initSpace : ℝ) ≤ spaceBound := by
    have hpk2 : initOut.peakCellSpace ≤ 2 := by
      have h0 : ({ intParams := [(n : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0,
                   extraReals := [] } : ArithRAMInput d).inputCellSpace +
          ArithRAMMemory.empty.cellCount = 1 := by
        simp [ArithRAMInput.inputCellSpace, ArithRAMMemory.cellCount, ArithRAMMemory.empty,
          WordStore.cellCount, WordStore.empty, RealStore.cellCount, RealStore.empty]
      rw [h0] at hinit_pk
      omega
    have h2_le : 2 ≤ max 1 (3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound) :=
      (by omega : 2 ≤ 3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound).trans (le_max_right 1 _)
    have h1 : (alg.initSpace : ℝ) ≤
        ((max 1 (3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound) : ℕ) : ℝ) := by
      dsimp [alg, mkArithAlg]
      exact_mod_cast (hpk2.trans h2_le)
    exact h1.trans hs_le
  let GoodState : DynamicPointSet d → ExecutionHistory d → ArithRAMMemory → Prop :=
    fun P hist mem =>
      GoodInv hist.length P mem ∧
      (hist ≠ [] → IsValidFactorCAnswer (Real.sqrt 2) P (readStoredAns mem))
  have hGoodState₀ : GoodState (DynamicPointSet.empty d) [] alg.initState := by
    dsimp [GoodState, alg, mkArithAlg]
    rw [hinit_mem_emp]
    exact ⟨hGood₀, fun hne => False.elim (hne rfl)⟩
  have h5 := h_fb.2.2.2.2 d n t 0 δ (Real.sqrt 2) stepWorkBound spaceBound 1 1 1 t
    Set.univ ArithRAMMemory alg GoodState (fun _ _ _ _ _ => 1)
    hn ht hδ0 hδ1 ht_le_S hSφ_le_δ hinit_w hinit_sp hGoodState₀
    (fun adv hadv => by
      refine ⟨?_, ?_⟩
      · intro T trace hT hsome
        rcases Option.isSome_iff_exists.mp hsome with ⟨out, hout⟩
        have htot := totalEvents_const_one alg adv (List.ofFn trace) _ out hout
        simpa [htot] using hT
      · intro bitTrace prefSt hlt hrun
        dsimp only
        rcases hReach_trace adv hadv bitTrace prefSt (le_of_lt hlt) hrun with
          ⟨hlen_hist, hP_wf, hclean, hbox, hsafe⟩
        set op := adv prefSt.history
        have hleg : IsLegalUpdate n Set.univ prefSt.pointSet op := hadv bitTrace hlt prefSt hrun
        rcases hStep bitTrace.length prefSt.pointSet prefSt.algState op
          hlt hP_wf hclean hbox (hlen_hist ▸ hsafe) hleg with
          ⟨Post, Bad, instDecBad, hRE, hBad_card, hPost_imp⟩
        letI : DecidablePred Bad := instDecBad
        have hRE1_c : RandExecAt 1 (mkStepInput n prefSt.pointSet op) updateBody B_step
            ((prefSt.algState.popDepth 0).popDepth 0) Post uBound := by rwa [hclean, hclean]
        have hRE' := RandExecAt.localScope hRE1_c
        rcases RandExec.to_spec hRE' with ⟨hnone_ne, hsome_ofFn⟩
        have hsingle_none : ∀ bs : List Bool, bs.length ≠ B_step →
            runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs = none := by
          intro bs hne
          simp [runSingleAdaptiveStep, hstep_eq, hnone_ne bs hne]
        have hsingle_ofFn : ∀ bits : Fin B_step → Bool,
            ∃ (raw : ArithRAMExecOutcome) (m₁ : ArithRAMMemory) (P' : DynamicPointSet d),
              Post bits m₁ ∧ raw.mem = m₁.popDepth 0 ∧
              raw.unitCost ≤ uBound ∧
              raw.peakCellSpace ≤ (mkStepInput n prefSt.pointSet op).inputCellSpace +
                prefSt.algState.cellCount + raw.unitCost ∧
              applyDynamicUpdate prefSt.pointSet op (readStepRetH op raw.mem) = some P' ∧
              runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op (List.ofFn bits) =
                some (P', { nextState := raw.mem
                            returnedHandle := readStepRetH op raw.mem
                            storedAnswer := readStoredAns raw.mem
                            work := raw.unitCost
                            peakSpace := raw.peakCellSpace }) := by
          intro bits
          rcases hsome_ofFn bits with ⟨raw, hraw, hu, hpk, m_sc, ⟨m₁, hpm1, rfl⟩, hmem_eq⟩
          rw [popDepth_zero_idem] at hmem_eq
          rcases hPost_imp bits m₁ hpm1 with ⟨P', happ, _, _⟩
          rw [← hmem_eq] at happ
          refine ⟨raw, m₁, P', hpm1, hmem_eq, hu, hpk, happ, ?_⟩
          simp [runSingleAdaptiveStep, hstep_eq, hraw, happ, readStoredAns]
        refine ⟨?_, ?_, ?_⟩
        · unfold singleStepValidHaltProb
          rw [tsum_listBool_of_fixedLength B_step _ (fun bs hne => by simp [hsingle_none bs hne])]
          have heq_sum :
              (∑ bits : Fin B_step → Bool,
                if (runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op
                    (List.ofFn bits)).isSome then bitListProb (List.ofFn bits) else 0) =
              ∑ bits : Fin B_step → Bool, bitListProb (List.ofFn bits) := by
            refine Finset.sum_congr rfl fun bits _ => ?_
            rcases hsingle_ofFn bits with ⟨_, _, _, _, _, _, _, _, hs⟩
            simp [hs]
          rw [heq_sum]
          exact sum_bitListProb_ofFn B_step
        · intro bs P' out hs
          have hbs_len : bs.length = B_step := by
            by_contra hne; rw [hsingle_none bs hne] at hs; simp at hs
          let bits : Fin B_step → Bool := fun j => bs[j.val]'(by omega)
          have hbs_eq : List.ofFn bits = bs := by
            apply List.ext_getElem
            · simp [hbs_len]
            · intro i _ _; simp [bits]
          rcases hsingle_ofFn bits with ⟨raw, _, P'', _, _, hu, hpk, _, hs'⟩
          rw [hbs_eq, hs] at hs'
          injection hs' with hpair_eq
          rcases Prod.mk.inj hpair_eq with ⟨hp_eq, hout_eq⟩
          subst hp_eq hout_eq
          refine ⟨?_, ?_⟩
          · have h1 : (raw.unitCost : ℝ) ≤ ((max 1 uBound : ℕ) : ℝ) := by
              exact_mod_cast (hu.trans (le_max_right 1 uBound))
            rw [Nat.cast_max, Nat.cast_one] at h1
            exact h1.trans hu_le
          · have hinp_sp := mkStepInput_space_le hP_wf op
            have hmem_sp : prefSt.algState.cellCount ≤ 2 * (T_max * M_box) := by
              rw [← hclean]
              exact cellCount_popDepth_zero_le_of_box hbox
            have hpk_tot : raw.peakCellSpace ≤
                max 1 (3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound) :=
              (hpk.trans (by omega)).trans (le_max_right 1 _)
            exact (show (raw.peakCellSpace : ℝ) ≤ _ from by exact_mod_cast hpk_tot).trans hs_le
        · intro hGood_cur
          have hGood_cur' : GoodInv bitTrace.length prefSt.pointSet prefSt.algState :=
            hlen_hist ▸ hGood_cur.1
          refine ⟨?_, ?_⟩
          · intro bs P' out hs hGood_next
            have hbs_len : bs.length = B_step := by
              by_contra hne; rw [hsingle_none bs hne] at hs; simp at hs
            let bits : Fin B_step → Bool := fun j => bs[j.val]'(by omega)
            have hbs_eq : List.ofFn bits = bs := by
              apply List.ext_getElem
              · simp [hbs_len]
              · intro i _ _; simp [bits]
            rcases hsingle_ofFn bits with ⟨raw, _, P'', _, _, _, _, _, hs'⟩
            rw [hbs_eq, hs] at hs'
            injection hs' with hpair_eq
            rcases Prod.mk.inj hpair_eq with ⟨hp_eq, hout_eq⟩
            subst hp_eq hout_eq
            exact hGood_next.2 (by simp)
          · dsimp only
            rw [tsum_listBool_of_fixedLength B_step _ (fun bs hne => by
              cases h : runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs with
              | none => rfl
              | some _ => rw [hsingle_none bs hne] at h; simp at h)]
            rw [tsum_listBool_of_fixedLength B_step _ (fun bs hne => by
              rw [hsingle_none bs hne]; simp)]
            refine le_trans
              (b := ∑ bits : Fin B_step → Bool,
                if Bad bits then bitListProb (List.ofFn bits) else 0) ?_ ?_
            · refine Finset.sum_le_sum fun bits _ => ?_
              rcases hsingle_ofFn bits with ⟨raw, m₁, P', hpm1, hmem_eq, _, _, happ_b, hs_b⟩
              rw [hs_b]
              dsimp only
              by_cases hB : Bad bits
              · simp only [hB, ↓reduceIte]
                split_ifs <;> simp
              · simp only [hB, ↓reduceIte]
                rcases hPost_imp bits m₁ hpm1 with ⟨P'', happ'', _, hG_imp⟩
                rw [← hmem_eq, happ_b] at happ''
                injection happ'' with hp_eq; subst hp_eq
                rcases hG_imp hGood_cur' hB with ⟨hans_ok, hG1⟩
                rw [← hmem_eq] at hans_ok hG1
                have hG_true : GoodState P'
                    (prefSt.history ++
                      [{ operation := op, randomBits := List.ofFn bits,
                         returnedHandle := readStepRetH op raw.mem,
                         answer := readStoredAns raw.mem,
                         resolvedIds := resolveAnswerIdentities P' (readStoredAns raw.mem) }])
                    raw.mem := by
                  refine ⟨?_, fun _ => hans_ok⟩
                  simpa [hlen_hist] using hG1
                simp [hG_true]
            · refine ((sum_bitListProb_filter_le B_step Bad hBad_card).trans
                (ENNReal.ofReal_le_ofReal hφ_le)).trans_eq ?_
              symm
              calc _
                  = (∑ bits : Fin B_step → Bool, bitListProb (List.ofFn bits)) *
                      ENNReal.ofReal (perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ) := by
                    rw [Finset.sum_mul]
                    refine Finset.sum_congr rfl fun bits _ => ?_
                    rcases hsingle_ofFn bits with ⟨_, _, _, _, _, _, _, _, hs_b⟩
                    simp [hs_b]
                _ = ENNReal.ofReal (perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ) := by
                    rw [sum_bitListProb_ofFn B_step, one_mul])
  exact ⟨hSM, h5.1, h5.2.1, h5.2.2⟩

end UL.Proof_lem_7_2_RacerP46
