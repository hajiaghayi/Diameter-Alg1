import UL.Proof.lem_7_2.RacerP46_H3a_HPJAndBaseline
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Pure Helpers for `IsNodeMaxRadiusPoint`, Bijections, and `indexedEuclideanDiam` -/

lemma isNodeMaxRadiusPoint_of_max_distSq {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S : Finset ι) {mh : ι} (hmh : mh ∈ S)
    (hmax : ∀ x ∈ S, euclideanDistSq (pts x) o ≤ euclideanDistSq (pts mh) o) :
    IsNodeMaxRadiusPoint pts o S mh := by
  have hne : S.Nonempty := ⟨mh, hmh⟩
  refine ⟨hmh, ?_⟩
  unfold nodeMaxRadius
  simp only [hne, ↓reduceDIte]
  apply le_antisymm
  · exact Finset.le_sup' (fun i : ι => ‖pts i - o‖) hmh
  · rw [Finset.sup'_le_iff]
    intro x hx
    have hsq : ‖pts x - o‖ ^ 2 ≤ ‖pts mh - o‖ ^ 2 := by
      simpa [euclideanDistSq] using hmax x hx
    have h1 : 0 ≤ ‖pts x - o‖ := norm_nonneg _
    have h2 : 0 ≤ ‖pts mh - o‖ := norm_nonneg _
    nlinarith

lemma nodeMaxRadius_bij {d : ℕ} {ι₁ ι₂ : Type}
    (pts₁ : ι₁ → EuclideanSpace ℝ (Fin d)) (pts₂ : ι₂ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d))
    (S₁ : Finset ι₁) (S₂ : Finset ι₂)
    (f : ι₁ → ι₂) (g : ι₂ → ι₁)
    (hf : ∀ x ∈ S₁, f x ∈ S₂ ∧ pts₂ (f x) = pts₁ x)
    (hg : ∀ y ∈ S₂, g y ∈ S₁ ∧ f (g y) = y) :
    nodeMaxRadius pts₁ o S₁ = nodeMaxRadius pts₂ o S₂ := by
  unfold nodeMaxRadius
  by_cases h1 : S₁.Nonempty
  · have h2 : S₂.Nonempty := by rcases h1 with ⟨x, hx⟩; exact ⟨f x, (hf x hx).1⟩
    simp only [h1, h2, ↓reduceDIte]
    apply le_antisymm
    · rw [Finset.sup'_le_iff]
      intro x hx
      have hle := Finset.le_sup' (fun y : ι₂ => ‖pts₂ y - o‖) (hf x hx).1
      simpa [(hf x hx).2] using hle
    · rw [Finset.sup'_le_iff]
      intro y hy
      have hgy := (hg y hy).1
      have hle := Finset.le_sup' (fun x : ι₁ => ‖pts₁ x - o‖) hgy
      have heq : pts₁ (g y) = pts₂ y := by
        have h := (hf (g y) hgy).2
        rw [(hg y hy).2] at h
        exact h.symm
      simpa [heq] using hle
  · have h2 : ¬ S₂.Nonempty := fun ⟨y, hy⟩ => h1 ⟨g y, (hg y hy).1⟩
    simp [h1, h2]

lemma exists_leafPair_uid_of_distinct_bound {d : ℕ}
    (hCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S_h S_uid : Finset ℕ)
    (uidOfH hOfUid : ℕ → ℕ)
    (hf : ∀ h ∈ S_h, uidOfH h ∈ S_uid ∧ ghostCoords (uidOfH h) = hCoords h ∧ hOfUid (uidOfH h) = h)
    (hg : ∀ u ∈ S_uid, hOfUid u ∈ S_h ∧ uidOfH (hOfUid u) = u)
    (bestSq : ℝ)
    (hbound : ∀ a (ha : a < S_h.card) b (hb : b < S_h.card), a ≠ b →
      euclideanDistSq (hCoords (S_h.orderEmbOfFin rfl ⟨a, ha⟩))
                      (hCoords (S_h.orderEmbOfFin rfl ⟨b, hb⟩)) ≤ bestSq) :
    ∃ leafPair : Option (ℕ × ℕ),
      IsActiveNodePair S_uid leafPair ∧
      baselinePairLength ghostCoords leafPair = indexedEuclideanDiam S_uid ghostCoords ∧
      ∀ u v : ℕ, leafPair = some (u, v) → u ≠ v →
        ‖ghostCoords u - ghostCoords v‖ ^ 2 ≤ bestSq := by
  classical
  have hdiam_eq : indexedEuclideanDiam S_h hCoords = indexedEuclideanDiam S_uid ghostCoords :=
    indexedEuclideanDiam_bij S_h hCoords S_uid ghostCoords uidOfH hOfUid hf hg
  by_cases hne : S_h.Nonempty
  · rcases Finset.exists_mem_eq_sup' (hne.product hne)
        (fun xy : ℕ × ℕ => ‖hCoords xy.1 - hCoords xy.2‖) with ⟨⟨h1, h2⟩, hh12, hsup⟩
    rcases Finset.mem_product.mp hh12 with ⟨hh1, hh2⟩
    let u1 := uidOfH h1
    let u2 := uidOfH h2
    refine ⟨some (u1, u2), ⟨(hf h1 hh1).1, (hf h2 hh2).1⟩, ?_, ?_⟩
    · rw [← hdiam_eq]
      unfold baselinePairLength indexedEuclideanDiam
      simp only [hne, ↓reduceDIte, u1, u2, (hf h1 hh1).2.1, (hf h2 hh2).2.1]
      exact hsup.symm
    · intro u v heq huv_ne
      injection heq with hp_eq
      rcases Prod.mk.inj hp_eq with ⟨rfl, rfl⟩
      have hh_ne : h1 ≠ h2 := fun heq_h => huv_ne (congrArg uidOfH heq_h)
      let iso := S_h.orderIsoOfFin rfl
      let fa : Fin S_h.card := iso.symm ⟨h1, hh1⟩
      let fb : Fin S_h.card := iso.symm ⟨h2, hh2⟩
      have ha1 : S_h.orderEmbOfFin rfl fa = h1 := by change (iso fa).1 = h1; simp [fa]
      have hb2 : S_h.orderEmbOfFin rfl fb = h2 := by change (iso fb).1 = h2; simp [fb]
      have hab_ne : fa.val ≠ fb.val := by
        intro hv
        have hf_eq : fa = fb := Fin.ext hv
        rw [← ha1, ← hb2, hf_eq] at hh_ne
        exact hh_ne rfl
      have hle := hbound fa.val fa.isLt fb.val fb.isLt hab_ne
      rw [ha1, hb2] at hle
      simpa [euclideanDistSq, u1, u2, (hf h1 hh1).2.1, (hf h2 hh2).2.1] using hle
  · have hne_u : ¬ S_uid.Nonempty := fun ⟨u, hu⟩ => hne ⟨hOfUid u, (hg u hu).1⟩
    refine ⟨none, Finset.not_nonempty_iff_eq_empty.mp hne_u, ?_, fun _ _ h => by cases h⟩
    unfold baselinePairLength indexedEuclideanDiam
    simp [hne_u]

/-! ### 2. Best Active Candidate Pair Invariant (`BestCandInv`) and Update Helper -/

def BestCandInv {d : ℕ} (P : DynamicPointSet d) (mem : ArithRAMMemory) : Prop :=
  wRead mem 26 10 = 0 ∨
  (wRead mem 26 10 = 1 ∧
    ∃ h1 h2 : ℕ,
      h1 ∈ P.activeHandles ∧ h2 ∈ P.activeHandles ∧ h1 ≠ h2 ∧
      wRead mem 26 11 = (h1 : ℤ) ∧
      wRead mem 26 12 = (h2 : ℤ) ∧
      rRead mem 26 10 = euclideanDistSq (P.handleCoords h1) (P.handleCoords h2))

theorem BestCandInv.congr_mem {d : ℕ} {P : DynamicPointSet d} {m₁ m₂ : ArithRAMMemory}
    (h : BestCandInv P m₁)
    (hw10 : wRead m₂ 26 10 = wRead m₁ 26 10)
    (hw11 : wRead m₂ 26 11 = wRead m₁ 26 11)
    (hw12 : wRead m₂ 26 12 = wRead m₁ 26 12)
    (hr10 : rRead m₂ 26 10 = rRead m₁ 26 10) :
    BestCandInv P m₂ := by
  rcases h with h0 | ⟨h1, u, v, hu, hv, hne, hu_r, hv_r, hsq⟩
  · left; exact hw10.trans h0
  · right; exact ⟨hw10.trans h1, u, v, hu, hv, hne, hw11.trans hu_r, hw12.trans hv_r, hr10.trans hsq⟩

def tryUpdateBestCandInnerStmt (M_box : ℕ) (uIdx vIdx sqIdx : ℤ) : ArithRAMStmt :=
  .ite (.not (.intEq (.readLocal 29 (.lit uIdx)) (.readLocal 29 (.lit vIdx))))
    (.ite (.or (.intEq (.readHeap 26 (.lit 10)) (.lit 0))
               (.realLt (.readRealHeap 26 (.lit 10)) (.readRealLocal 29 (.lit sqIdx))))
      (seqList [
        boxWriteW M_box 26 (.lit 10) (.lit 1),
        boxWriteW M_box 26 (.lit 11) (.readLocal 29 (.lit uIdx)),
        boxWriteW M_box 26 (.lit 12) (.readLocal 29 (.lit vIdx)),
        boxWriteR M_box 26 (.lit 10) (.readRealLocal 29 (.lit sqIdx))
      ])
      .skip)
    .skip

theorem boxSafe_tryUpdateBestCandInnerStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max)
    (uIdx vIdx sqIdx : ℤ) :
    BoxSafeInner T_max M_box (tryUpdateBestCandInnerStmt M_box uIdx vIdx sqIdx) := by
  refine .ite _ (.ite _ (boxSafeInner_seqList ?_) .skip) .skip
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxR (by omega) _ _

theorem exec_tryUpdateBestCandInnerStmt {d M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (uIdx vIdx sqIdx : ℤ)
    {P : DynamicPointSet d} {u v : ℕ}
    (hBox : 13 ≤ M_box)
    (hInv : BestCandInv P mem)
    (hu_act : u ∈ P.activeHandles) (hv_act : v ∈ P.activeHandles)
    (hu_reg : wReadL 1 mem 29 uIdx = (u : ℤ))
    (hv_reg : wReadL 1 mem 29 vIdx = (v : ℤ))
    (hsq_reg : rReadL 1 mem 29 sqIdx = euclideanDistSq (P.handleCoords u) (P.handleCoords v)) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 1 inp (tryUpdateBestCandInnerStmt M_box uIdx vIdx sqIdx) mem m' 100 ∧
      BestCandInv P m' ∧
      (wRead mem 26 10 = 1 → wRead m' 26 10 = 1 ∧ rRead mem 26 10 ≤ rRead m' 26 10) ∧
      (u ≠ v →
        wRead m' 26 10 = 1 ∧
        euclideanDistSq (P.handleCoords u) (P.handleCoords v) ≤ rRead m' 26 10) ∧
      (∀ t, t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 10 → idx ≠ 11 → idx ≠ 12 → wRead m' 26 idx = wRead mem 26 idx) ∧
      (∀ t, t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx) ∧
      (∀ idx, idx ≠ 10 → rRead m' 26 idx = rRead mem 26 idx) ∧
      (∀ lv idx, wReadL 1 m' lv idx = wReadL 1 mem lv idx) ∧
      (∀ lv idx, rReadL 1 m' lv idx = rReadL 1 mem lv idx) := by
  by_cases huv : u = v
  · subst huv
    have hcond1 : cValAt 1 inp mem
        (.not (.intEq (.readLocal 29 (.lit uIdx)) (.readLocal 29 (.lit vIdx)))) = false := by
      simp [hu_reg, hv_reg]
    exact ⟨mem,
      (DetExecAt.ite_false hcond1 (C_c := 10) (by simp [condExprOps, intExprOps])
        (DetExecAt.skip 1 inp mem)).mono_cost (by omega),
      hInv,
      fun h1 => ⟨h1, le_rfl⟩,
      fun hne => absurd rfl hne,
      fun _ _ _ => rfl, fun _ _ _ _ => rfl, fun _ _ _ => rfl, fun _ _ => rfl,
      fun _ _ => rfl, fun _ _ => rfl⟩
  · have hne_z : (u : ℤ) ≠ (v : ℤ) := by omega
    have hcond1 : cValAt 1 inp mem
        (.not (.intEq (.readLocal 29 (.lit uIdx)) (.readLocal 29 (.lit vIdx)))) = true := by
      simp [hu_reg, hv_reg, hne_z]
    let candSq := euclideanDistSq (P.handleCoords u) (P.handleCoords v)
    by_cases hupd : wRead mem 26 10 = 0 ∨ rRead mem 26 10 < candSq
    · have hcond2 : cValAt 1 inp mem
          (.or (.intEq (.readHeap 26 (.lit 10)) (.lit 0))
               (.realLt (.readRealHeap 26 (.lit 10)) (.readRealLocal 29 (.lit sqIdx)))) = true := by
        simp only [cValAt_or, cValAt_intEq, cValAt_realLt, iValAt_readHeap, iValAt_lit,
          rValAt_readRealHeap, rValAt_readRealLocal, hsq_reg, Bool.or_eq_true, decide_eq_true_eq]
        exact hupd
      let m1 := wWrite mem 26 10 1
      let m2 := wWrite m1 26 11 (u : ℤ)
      let m3 := wWrite m2 26 12 (v : ℤ)
      let m4 := rWrite m3 26 10 candSq
      have hs1 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 10) (.lit 1)) mem m1 14 :=
        exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
      have hs2 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 11) (.readLocal 29 (.lit uIdx))) m1 m2 16 :=
        exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) (by simp [m1, hu_reg]) (by simp [intExprOps])
      have hs3 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 12) (.readLocal 29 (.lit vIdx))) m2 m3 16 :=
        exec_boxWriteW inp m2 _ _ rfl (by omega) (by omega) (by simp [m2, m1, hv_reg]) (by simp [intExprOps])
      have hs4 : DetExecAt 1 inp (boxWriteR M_box 26 (.lit 10) (.readRealLocal 29 (.lit sqIdx))) m3 m4 18 :=
        exec_boxWriteR inp m3 _ _ rfl (by omega) (by omega)
          (by simp [m3, m2, m1, hsq_reg, candSq]) (by simp [intExprOps, realExprOps])
      refine ⟨m4,
        (DetExecAt.ite_true hcond1 (C_c := 10) (by simp [condExprOps, intExprOps])
          (DetExecAt.ite_true hcond2 (C_c := 15) (by simp [condExprOps, realExprOps, intExprOps])
            (hs1.seq (hs2.seq (hs3.seq hs4))))).mono_cost (by omega),
        Or.inr ⟨by simp [m4, m3, m2, m1], u, v, hu_act, hv_act, huv,
          by simp [m4, m3, m2], by simp [m4, m3], by simp [m4, candSq]⟩,
        fun h1 => ⟨by simp [m4, m3, m2, m1], by
          rcases hupd with h0 | hlt
          · omega
          · simp only [m4, rRead_rWrite_self]
            exact le_of_lt hlt⟩,
        fun _ => ⟨by simp [m4, m3, m2, m1], by simp [m4, candSq]⟩,
        fun t ht idx => by simp [m4, m3, m2, m1, ht],
        fun idx h10 h11 h12 => by simp [m4, m3, m2, m1, h10, h11, h12],
        fun t ht idx => by simp [m4, m3, m2, m1, ht],
        fun idx h10 => by simp [m4, m3, m2, m1, h10],
        fun lv idx => by simp [m4, m3, m2, m1],
        fun lv idx => by simp [m4, m3, m2, m1]⟩
    · push_neg at hupd
      rcases hupd with ⟨hne0, hle_cur⟩
      have h1_mem : wRead mem 26 10 = 1 := by
        rcases hInv with h0 | ⟨h1, _⟩
        · exact absurd h0 hne0
        · exact h1
      have hcond2 : cValAt 1 inp mem
          (.or (.intEq (.readHeap 26 (.lit 10)) (.lit 0))
               (.realLt (.readRealHeap 26 (.lit 10)) (.readRealLocal 29 (.lit sqIdx)))) = false := by
        simp only [cValAt_or, cValAt_intEq, cValAt_realLt, iValAt_readHeap, iValAt_lit,
          rValAt_readRealHeap, rValAt_readRealLocal, hsq_reg, Bool.or_eq_false_iff,
          decide_eq_false_iff_not, not_lt]
        exact ⟨hne0, hle_cur⟩
      exact ⟨mem,
        (DetExecAt.ite_true hcond1 (C_c := 10) (by simp [condExprOps, intExprOps])
          (DetExecAt.ite_false hcond2 (C_c := 15) (by simp [condExprOps, realExprOps, intExprOps])
            (DetExecAt.skip 1 inp mem))).mono_cost (by omega),
        hInv,
        fun h1 => ⟨h1, le_rfl⟩,
        fun _ => ⟨h1_mem, hle_cur⟩,
        fun _ _ _ => rfl, fun _ _ _ _ => rfl, fun _ _ _ => rfl, fun _ _ => rfl,
        fun _ _ => rfl, fun _ _ => rfl⟩

/-! ### 3. Baseline Witness Monte Carlo Sampling (`runBaselineSlotStmt`) -/

def baselineSampleIterDetStmt (d K : ℕ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 28 (.lit 20) (.readLocal 27 (.lit 0)),
    .writeWordLocal 28 (.lit 21) (.mod (.readLocal 29 (.lit 12)) (.readLocal 27 (.lit 1))),
    selectByRankSegStmt K,
    .writeWordLocal 29 (.lit 18) (.mul (.readLocal 28 (.lit 0)) (.lit (d : ℤ))),
    loadHeapCoordsToLocalStmt d 4 18 (d : ℤ),
    distSqLocalStmt d,
    .ite (.or (.intEq (.readLocal 27 (.lit 4)) (.lit 0))
              (.realLt (.readRealLocal 27 (.lit 0)) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))))
      (seqList [
        .writeWordLocal 27 (.lit 4) (.lit 1),
        .writeWordLocal 27 (.lit 3) (.readLocal 28 (.lit 0)),
        .writeRealLocal 27 (.lit 0) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))
      ])
      .skip
  ]

def baselineActiveScopeStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 27 (.lit 0) (.readHeap 26 (.lit 1)),
    cardAndMaxSegSlotStmt p.K_seg (.readLocal 27 (.lit 0)),
    .writeWordLocal 27 (.lit 1) (.readLocal 28 (.lit 0)),
    .writeWordLocal 27 (.lit 2) (.readLocal 28 (.lit 1)),
    .ite (.intEq (.readLocal 27 (.lit 1)) (.lit 0))
      (.repeatN (.lit (p.K₀ : ℤ)) (readRandNatLocalStmt 29 12 13 p.M_bits))
      (seqList [
        .writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 2)) (.lit (d : ℤ))),
        loadHeapCoordsToLocalStmt d 4 18 0,
        .writeWordLocal 27 (.lit 3) (.readLocal 27 (.lit 2)),
        .writeWordLocal 27 (.lit 4) (.lit 0),
        .writeRealLocal 27 (.lit 0) (.ofInt (.lit 0)),
        .repeatN (.lit (p.K₀ : ℤ))
          (.seq (readRandNatLocalStmt 29 12 13 p.M_bits)
                (baselineSampleIterDetStmt d p.K_seg)),
        .writeWordLocal 29 (.lit 22) (.readLocal 27 (.lit 2)),
        .writeWordLocal 29 (.lit 23) (.readLocal 27 (.lit 3)),
        .writeRealLocal 29 (.lit 22) (.readRealLocal 27 (.lit 0)),
        tryUpdateBestCandInnerStmt M_box 22 23 22
      ])
  ])

def runBaselineSlotStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  .ite (.intEq (.readHeap 26 (.lit 0)) (.lit 1))
    (baselineActiveScopeStmt d n M_box p)
    (randDummyBitsStmt (p.K₀ * p.M_bits))

theorem boxSafe_runBaselineSlotStmt {d n T_max M_box : ℕ} (hT : 27 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (runBaselineSlotStmt d n M_box p) := by
  refine .ite _ (.localScope (boxSafeInner_seqList ?_)) (boxSafe_randDummyBitsStmt _)
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact boxSafe_cardAndMaxSegSlotStmt _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .ite _ (.repeatN _ (boxSafeInner_readRandNatLocalStmt _ _ _ _ _ _)) (boxSafeInner_seqList ?_)
    intro s' hs'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeRealLocal _ _ _
    · refine .repeatN _ (.seq (boxSafeInner_readRandNatLocalStmt _ _ _ _ _ _) (boxSafeInner_seqList ?_))
      intro s'' hs''
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hs''
      rcases hs'' with rfl | rfl | rfl | rfl | rfl | rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact .writeWordLocal _ _ _
      · exact boxSafe_selectByRankSegStmt _
      · exact .writeWordLocal _ _ _
      · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
      · exact boxSafe_distSqLocalStmt _
      · refine .ite _ (boxSafeInner_seqList fun w hw => ?_) .skip
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hw
        rcases hw with rfl | rfl | rfl
        · exact .writeWordLocal _ _ _
        · exact .writeWordLocal _ _ _
        · exact .writeRealLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeRealLocal _ _ _
    · exact boxSafe_tryUpdateBestCandInnerStmt hT _ _ _

def baselineCallCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  250 * (p.K₀ + 1) * (p.M_bits + p.K_seg + d + 5) + 500

theorem exec_runBaselineSlotStmt_inactive {d n M_box : ℕ}
    (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (hinact : wRead mem 26 0 ≠ 1) :
    RandExecAt 0 inp (runBaselineSlotStmt d n M_box p) (p.K₀ * p.M_bits) mem
      (fun _ m' => m' = mem.popDepth 0) (baselineCallCost d n p) := by
  have hcond : cValAt 0 inp mem (.intEq (.readHeap 26 (.lit 0)) (.lit 1)) = false := by
    simp [hinact]
  refine (RandExecAt.ite_false hcond (C_c := 10) (by simp [condExprOps, intExprOps])
    (exec_randDummyBitsStmt inp mem (p.K₀ * p.M_bits))).mono (fun _ _ h => h) ?_
  unfold baselineCallCost
  have h1 : 10 * (p.K₀ * p.M_bits) ≤ 250 * (p.K₀ + 1) * (p.M_bits + p.K_seg + d + 5) := by
    calc 10 * (p.K₀ * p.M_bits) = (10 * p.K₀) * p.M_bits := by ring
      _ ≤ (250 * (p.K₀ + 1)) * (p.M_bits + p.K_seg + d + 5) :=
          Nat.mul_le_mul (by omega) (by omega)
  omega

theorem exec_runBaselineSlotStmt_active {d n M_box : ℕ}
    (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {P : DynamicPointSet d} {s : ℕ} {S : Finset ℕ} {node : ChainNode d}
    (hact : wRead mem 26 0 = 1)
    (hs_reg : wRead mem 26 1 = (s : ℤ))
    (hBox : 13 ≤ M_box)
    (hInv : BestCandInv P mem)
    (hLive : EncLiveCoords d n mem P.activeHandles P.handleCoords)
    (hS_sub : S ⊆ P.activeHandles)
    (hS_le_n : S.card ≤ n)
    (hSeg : EncSegSlot p.K_seg mem s S (fun x => euclideanDistSq (P.handleCoords x) node.o))
    (hK0_pos : 1 ≤ p.K₀)
    (hφ0 : 0 < p.φ_ev)
    (hbias : ((p.K₀ : ℝ) * (n : ℝ)) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev)
    (hmc_gen : ∀ (pts : ℕ → EuclideanSpace ℝ (Fin d))
         (P₀ S₀ : Finset ℕ) (age : ℕ) (o : EuclideanSpace ℝ (Fin d)) (s_lift : ℝ)
         (y : ℕ) (farthest : (Fin p.K₀ → ℕ) → ℕ),
       1 ≤ P₀.card →
       IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
         (paraboloidLiftSet (fun i : ↥P₀ => pts i.1)) (liftedPoint o s_lift) →
       HasNodeAge P₀ S₀ age →
       (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀.card : ℝ) / 16 →
       IsNodeMaxRadiusPoint pts o S₀ y →
       let V := liftVariance o s_lift
       let samples := Fintype.piFinset (fun _ : Fin p.K₀ => S₀)
       (∀ samp ∈ samples,
         (∃ j : Fin p.K₀, farthest samp = samp j) ∧
         ∀ j : Fin p.K₀, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖) →
       (((open Classical in samples.filter (fun samp =>
           ¬ IsNodeBaselinePair pts o V S₀ y (farthest samp))).card : ℝ) /
         (samples.card : ℝ)) ≤ p.φ_ev)
    {P_good : Prop}
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {S_uid : Finset ℕ} {uidOfH hOfUid : ℕ → ℕ}
    (hf_uid : ∀ h ∈ S, uidOfH h ∈ S_uid ∧ ghostCoords (uidOfH h) = P.handleCoords h ∧ hOfUid (uidOfH h) = h)
    (hg_uid : ∀ u ∈ S_uid, hOfUid u ∈ S ∧ uidOfH (hOfUid u) = u)
    (hGoodImp : P_good →
      ∃ (P₀_uid : Finset ℕ) (age : ℕ),
        1 ≤ P₀_uid.card ∧
        IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
          (paraboloidLiftSet (fun i : ↥P₀_uid => ghostCoords i.1))
          (liftedPoint node.o (node.V + ‖node.o‖ ^ 2)) ∧
        HasNodeAge P₀_uid S_uid age ∧
        (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀_uid.card : ℝ) / 16) :
    ∃ (Post : (Fin (p.K₀ * p.M_bits) → Bool) → ArithRAMMemory → Prop)
      (Bad : (Fin (p.K₀ * p.M_bits) → Bool) → Prop) (_ : DecidablePred Bad),
      RandExecAt 0 inp (runBaselineSlotStmt d n M_box p) (p.K₀ * p.M_bits) mem Post
        (baselineCallCost d n p) ∧
      ((Finset.univ.filter Bad).card : ℝ) ≤ (2 * p.φ_ev) * ((2 : ℝ) ^ (p.K₀ * p.M_bits)) ∧
      ∀ (bits : Fin (p.K₀ * p.M_bits) → Bool) (m' : ArithRAMMemory),
        Post bits m' →
          m'.popDepth 0 = m' ∧
          BestCandInv P m' ∧
          (wRead mem 26 10 = 1 → wRead m' 26 10 = 1 ∧ rRead mem 26 10 ≤ rRead m' 26 10) ∧
          (∀ t, t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
          (∀ idx, idx ≠ 10 → idx ≠ 11 → idx ≠ 12 → wRead m' 26 idx = wRead mem 26 idx) ∧
          (∀ t, t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx) ∧
          (∀ idx, idx ≠ 10 → rRead m' 26 idx = rRead mem 26 idx) ∧
          (P_good → ¬ Bad bits →
            ∃ pair : Option (ℕ × ℕ),
              node.SatisfiesBaselineCond ghostCoords S_uid pair ∧
              ∀ u v : ℕ, pair = some (u, v) → u ≠ v →
                wRead m' 26 10 = 1 ∧
                ‖ghostCoords u - ghostCoords v‖ ^ 2 ≤ rRead m' 26 10) := by
  classical
  have hcard_uid : S_uid.card = S.card := by
    symm
    refine Finset.card_bij (fun h _ => uidOfH h) (fun h hh => (hf_uid h hh).1) ?_ ?_
    · intro h1 hh1 h2 hh2 heq
      have := congrArg hOfUid heq
      rwa [(hf_uid h1 hh1).2.2, (hf_uid h2 hh2).2.2] at this
    · intro u hu
      exact ⟨hOfUid u, (hg_uid u hu).1, (hg_uid u hu).2⟩
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 27 0 (s : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 0) (.readHeap 26 (.lit 1))) m0 m1 6 :=
    DetExecAt.writeWordLocal 1 inp m0 27 _ _ rfl (by simp [m0, hs_reg]) (by simp [intExprOps])
  have hSeg_m1 : EncSegSlot p.K_seg m1 s S (fun x => euclideanDistSq (P.handleCoords x) node.o) :=
    hSeg.congr_mem_fSq (by simp [m1, m0]) (fun _ _ => by simp [m1, m0])
      (fun _ _ => by simp [m1, m0]) (fun _ _ => by simp [m1, m0])
      (fun _ _ => by simp [m1, m0]) (fun _ _ => rfl)
  rcases exec_cardAndMaxSegSlotStmt inp m1 (.readLocal 27 (.lit 0)) (by simp [m1]) hSeg_m1
    with ⟨m2, hs2, hm2_card, hm2_max, hw2, hr2, hwl2, hrl2⟩
  let m3 := wWriteL 1 m2 27 1 (S.card : ℤ)
  let m4 := wWriteL 1 m3 27 2 (wReadL 1 m2 28 1)
  have hs3 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 1) (.readLocal 28 (.lit 0))) m2 m3 6 :=
    DetExecAt.writeWordLocal 1 inp m2 27 _ _ rfl (by simp [hm2_card]) (by simp [intExprOps])
  have hs4 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 2) (.readLocal 28 (.lit 1))) m3 m4 6 :=
    DetExecAt.writeWordLocal 1 inp m3 27 _ _ rfl (by simp [m3]) (by simp [intExprOps])
  have hcond_act : cValAt 0 inp mem (.intEq (.readHeap 26 (.lit 0)) (.lit 1)) = true := by
    simp [hact]
  by_cases hS0 : S.card = 0
  · have hS_emp : S = ∅ := Finset.card_eq_zero.mp hS0
    have hSuid_emp : S_uid = ∅ := Finset.card_eq_zero.mp (hcard_uid.trans hS0)
    have hcond_z : cValAt 1 inp m4 (.intEq (.readLocal 27 (.lit 1)) (.lit 0)) = true := by
      simp [m4, m3, hS0]
    let InvZ : ℕ → (ℕ → Fin p.M_bits → Bool) → ArithRAMMemory → Prop :=
      fun _ _ m =>
        (∀ t idx, wRead m t idx = wRead mem t idx) ∧
        (∀ t idx, rRead m t idx = rRead mem t idx)
    have hInvZ0 : InvZ 0 (fun _ _ => false) m4 :=
      ⟨fun t idx => by simp [m4, m3, hw2, m1, m0],
       fun t idx => by simp [m4, m3, hr2, m1, m0]⟩
    have hStepZ : ∀ j < p.K₀, ∀ chunks m, InvZ j chunks m →
        RandExecAt 1 inp (readRandNatLocalStmt 29 12 13 p.M_bits) p.M_bits m
          (fun b m' => InvZ (j + 1) (Function.update chunks j b) m') (10 + 25 * p.M_bits) := by
      intro j _ chunks m ⟨hw_m, hr_m⟩
      refine (exec_readRandNatLocalStmt (by decide) inp 29 12 13 (by decide) p.M_bits m).mono ?_ le_rfl
      rintro b m' ⟨_, _, _, hw', hr', _⟩
      exact ⟨fun t idx => (hw' t idx).trans (hw_m t idx),
             fun t idx => (hr' t idx).trans (hr_m t idx)⟩
    have hrepZ := RandExecAt.repeatN_nat (.lit (p.K₀ : ℤ)) _ p.K₀ p.M_bits 10 (10 + 25 * p.M_bits)
      InvZ (chunks₀ := fun _ _ => false) hInvZ0 rfl (by simp [intExprOps]) hStepZ
    let fB_stmt := seqList [
      .writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 2)) (.lit (d : ℤ))),
      loadHeapCoordsToLocalStmt d 4 18 0,
      .writeWordLocal 27 (.lit 3) (.readLocal 27 (.lit 2)),
      .writeWordLocal 27 (.lit 4) (.lit 0),
      .writeRealLocal 27 (.lit 0) (.ofInt (.lit 0)),
      .repeatN (.lit (p.K₀ : ℤ))
        (.seq (readRandNatLocalStmt 29 12 13 p.M_bits)
              (baselineSampleIterDetStmt d p.K_seg)),
      .writeWordLocal 29 (.lit 22) (.readLocal 27 (.lit 2)),
      .writeWordLocal 29 (.lit 23) (.readLocal 27 (.lit 3)),
      .writeRealLocal 29 (.lit 22) (.readRealLocal 27 (.lit 0)),
      tryUpdateBestCandInnerStmt M_box 22 23 22
    ]
    have hiteZ := RandExecAt.ite_true (fB := fB_stmt) hcond_z (C_c := 10)
      (by simp [condExprOps, intExprOps]) hrepZ
    have hr4 := RandExecAt.seq_det_left hs4 hiteZ
    have hr3 := RandExecAt.seq_det_left hs3 hr4
    have hr2 := RandExecAt.seq_det_left hs2 hr3
    have hr1 := RandExecAt.seq_det_left hs1 hr2
    have hsc := RandExecAt.localScope hr1
    have htop := RandExecAt.ite_true (fB := randDummyBitsStmt (p.K₀ * p.M_bits))
      hcond_act (C_c := 10) (by simp [condExprOps, intExprOps]) hsc
    refine ⟨_, fun _ => False, inferInstance, htop.mono (fun _ _ h => h) ?_, ?_, ?_⟩
    · unfold baselineCallCost
      simp only [intExprOps]
      have hmul : p.K₀ * (10 + 25 * p.M_bits) ≤ 250 * (p.K₀ + 1) * (p.M_bits + p.K_seg + d + 5) := by
        calc p.K₀ * (10 + 25 * p.M_bits) ≤ p.K₀ * (25 * (p.M_bits + p.K_seg + d + 5)) :=
              Nat.mul_le_mul_left _ (by omega)
          _ = (25 * p.K₀) * (p.M_bits + p.K_seg + d + 5) := by ring
          _ ≤ (250 * (p.K₀ + 1)) * (p.M_bits + p.K_seg + d + 5) :=
              Nat.mul_le_mul_right _ (by omega)
      omega
    · simp only [Finset.filter_false, Finset.card_empty, Nat.cast_zero]
      positivity
    · rintro bits m' ⟨m_end, ⟨_, ⟨hw_e, hr_e⟩, _⟩, rfl⟩
      refine ⟨popDepth_zero_idem m_end,
        hInv.congr_mem (by simp [hw_e]) (by simp [hw_e]) (by simp [hw_e]) (by simp [hr_e]),
        fun h1 => ⟨by simp [hw_e, h1], by simp [hr_e]⟩,
        fun t _ idx => by simp [hw_e],
        fun idx _ _ _ => by simp [hw_e],
        fun t _ idx => by simp [hr_e],
        fun idx _ => by simp [hr_e],
        fun _ _ => ⟨none, ?_, fun _ _ h => by cases h⟩⟩
      subst hSuid_emp
      exact ⟨rfl, fun hne => False.elim (Finset.not_nonempty_empty hne)⟩
  · have hS_pos : 0 < S.card := Nat.pos_of_ne_zero hS0
    have hS_ne : S.Nonempty := Finset.card_pos.mp hS_pos
    rcases hm2_max hS_ne with ⟨mh, hmh_in, hmh_reg, _, hmh_max⟩
    have hmh_act : mh ∈ P.activeHandles := hS_sub hmh_in
    have hcond_z : cValAt 1 inp m4 (.intEq (.readLocal 27 (.lit 1)) (.lit 0)) = false := by
      simp [m4, m3, hS0]
    let m5 := wWriteL 1 m4 29 18 (((mh * d : ℕ) : ℤ))
    have hs5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 2)) (.lit (d : ℤ))))
        m4 m5 8 := by
      refine DetExecAt.writeWordLocal 1 inp m4 29 _ _ rfl ?_ (by simp [intExprOps])
      simp [m4, hmh_reg]
    rcases exec_loadHeapCoordsToLocalStmt inp m5 (rTag := 4) (idxBase := 18) (destOff := 0)
        (base := mh * d) (pt := P.handleCoords mh) (by decide) (by simp [m5])
        (fun c => by
          simp only [m5, m4, m3, rRead_wWriteL, hr2, m1, m0, rRead_popDepth]
          exact hLive.2 mh hmh_act c)
      with ⟨m6, hs6, hmh_loc, hw6, hr6, _, _, hlv6, hrlv6⟩
    let m7 := wWriteL 1 m6 27 3 (mh : ℤ)
    let m8 := wWriteL 1 m7 27 4 0
    let m9 := rWriteL 1 m8 27 0 0
    have hs7 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 3) (.readLocal 27 (.lit 2))) m6 m7 6 :=
      DetExecAt.writeWordLocal 1 inp m6 27 _ _ rfl
        (by simp [hlv6 27 (by decide), m5, m4, hmh_reg]) (by simp [intExprOps])
    have hs8 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 4) (.lit 0)) m7 m8 4 :=
      DetExecAt.writeWordLocal 1 inp m7 27 _ _ rfl rfl (by simp [intExprOps])
    have hs9 : DetExecAt 1 inp (.writeRealLocal 27 (.lit 0) (.ofInt (.lit 0))) m8 m9 4 :=
      DetExecAt.writeRealLocal 1 inp m8 27 _ _ rfl (by simp) (by simp [intExprOps, realExprOps])
    let C_iter : ℕ := 180 * (p.M_bits + p.K_seg + d + 5)
    let selAt (b : Fin p.M_bits → Bool) : ℕ :=
      S.orderEmbOfFin rfl ⟨bitsFnToNat p.M_bits b % S.card, Nat.mod_lt _ hS_pos⟩
    let InvB : ℕ → (ℕ → Fin p.M_bits → Bool) → ArithRAMMemory → Prop :=
      fun j chunks m =>
        (∀ t idx, wRead m t idx = wRead mem t idx) ∧
        (∀ t idx, rRead m t idx = rRead mem t idx) ∧
        (∀ c : Fin d, rReadL 1 m 29 (c.val : ℤ) = euclideanCoord (P.handleCoords mh) c) ∧
        wReadL 1 m 27 0 = (s : ℤ) ∧
        wReadL 1 m 27 1 = (S.card : ℤ) ∧
        wReadL 1 m 27 2 = (mh : ℤ) ∧
        (j = 0 → wReadL 1 m 27 4 = 0 ∧ wReadL 1 m 27 3 = (mh : ℤ) ∧ rReadL 1 m 27 0 = 0) ∧
        (1 ≤ j →
          wReadL 1 m 27 4 = 1 ∧
          ∃ fh : ℕ,
            (∃ k < j, fh = selAt (chunks k)) ∧
            wReadL 1 m 27 3 = (fh : ℤ) ∧
            rReadL 1 m 27 0 = euclideanDistSq (P.handleCoords mh) (P.handleCoords fh) ∧
            ∀ k < j,
              euclideanDistSq (P.handleCoords mh) (P.handleCoords (selAt (chunks k))) ≤
                euclideanDistSq (P.handleCoords mh) (P.handleCoords fh))
    have hInvB0 : InvB 0 (fun _ _ => false) m9 := by
      refine ⟨fun t idx => by simp [m9, m8, m7, hw6, m5, m4, m3, hw2, m1, m0],
        fun t idx => by simp [m9, m8, m7, hr6, m5, m4, m3, hr2, m1, m0],
        fun c => by simpa [m9, m8, m7] using hmh_loc c,
        by simp [m9, m8, m7, hlv6 27 (by decide), m5, m4, m3, hwl2 27 (by decide), m1],
        by simp [m9, m8, m7, hlv6 27 (by decide), m5, m4, m3],
        by simp [m9, m8, m7, hlv6 27 (by decide), m5, m4, hmh_reg],
        fun _ => ⟨by simp [m9, m8], by simp [m9, m8, m7], by simp [m9]⟩,
        fun hj => by omega⟩
    have hStepB : ∀ j < p.K₀, ∀ chunks m, InvB j chunks m →
        RandExecAt 1 inp
          (.seq (readRandNatLocalStmt 29 12 13 p.M_bits) (baselineSampleIterDetStmt d p.K_seg))
          p.M_bits m
          (fun b m' => InvB (j + 1) (Function.update chunks j b) m') C_iter := by
      intro j _ chunks m ⟨hw_m, hr_m, hmh_c, hm27_0, hm27_1, hm27_2, hj0_inv, hjpos_inv⟩
      have hrand := exec_readRandNatLocalStmt (by decide : 1 ≤ 1) inp 29 12 13 (by decide) p.M_bits m
      refine (RandExecAt.seq_det_right hrand (C₂ := 80 * (p.K_seg + 1) + 70 * (d + 1) + 100) ?_).mono
        (fun _ _ h => h) (by dsimp [C_iter]; omega)
      intro b mr ⟨hmr12, hmr_wl, hmr_rl, hmr_w, hmr_r, _⟩
      let rk := bitsFnToNat p.M_bits b % S.card
      have hrk_lt : rk < S.card := Nat.mod_lt _ hS_pos
      let xj : ℕ := selAt b
      have hxj_in : xj ∈ S := S.orderEmbOfFin_mem rfl ⟨rk, hrk_lt⟩
      have hxj_act : xj ∈ P.activeHandles := hS_sub hxj_in
      let md1 := wWriteL 1 mr 28 20 (s : ℤ)
      let md2 := wWriteL 1 md1 28 21 (rk : ℤ)
      have hd1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readLocal 27 (.lit 0))) mr md1 6 :=
        DetExecAt.writeWordLocal 1 inp mr 28 _ _ rfl
          (by simp [hmr_wl 27 0 (Or.inl (by decide)), hm27_0]) (by simp [intExprOps])
      have hd2 : DetExecAt 1 inp
          (.writeWordLocal 28 (.lit 21) (.mod (.readLocal 29 (.lit 12)) (.readLocal 27 (.lit 1))))
          md1 md2 8 := by
        refine DetExecAt.writeWordLocal 1 inp md1 28 _ _ rfl ?_ (by simp [intExprOps])
        have h29_ne : (29 : ℕ) ≠ 28 := by decide
        have h27_ne : (27 : ℕ) ≠ 28 := by decide
        simp only [iValAt_mod, iValAt_readLocal, iValAt_lit, md1, wReadL_wWriteL_eq,
          h29_ne, h27_ne, false_and, ↓reduceIte, hmr12, hmr_wl 27 1 (Or.inl (by decide)), hm27_1]
        dsimp [rk]
      have hSeg_md2 : EncSegSlot p.K_seg md2 s S (fun x => euclideanDistSq (P.handleCoords x) node.o) :=
        hSeg.congr_mem_fSq
          (by simp [md2, md1, hmr_w, hw_m])
          (fun _ _ => by simp [md2, md1, hmr_w, hw_m])
          (fun _ _ => by simp [md2, md1, hmr_w, hw_m])
          (fun _ _ => by simp [md2, md1, hmr_w, hw_m])
          (fun _ _ => by simp [md2, md1, hmr_r, hr_m])
          (fun _ _ => rfl)
      rcases exec_selectByRankSegStmt inp md2 hrk_lt (by simp [md2, md1]) (by simp [md2]) hSeg_md2
        with ⟨md3, hd3, hsel_d3, hw_d3, hr_d3, hwl_d3, hrl_d3⟩
      let md4 := wWriteL 1 md3 29 18 (((xj * d : ℕ) : ℤ))
      have hd4 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readLocal 28 (.lit 0)) (.lit (d : ℤ))))
          md3 md4 8 := by
        refine DetExecAt.writeWordLocal 1 inp md3 29 _ _ rfl ?_ (by simp [intExprOps])
        simp [hsel_d3, xj, selAt, rk]
      rcases exec_loadHeapCoordsToLocalStmt inp md4 (rTag := 4) (idxBase := 18) (destOff := (d : ℤ))
          (base := xj * d) (pt := P.handleCoords xj) (by decide) (by simp [md4])
          (fun c => by
            simp only [md4, rRead_wWriteL, hr_d3, md2, md1, hmr_r, hr_m]
            exact hLive.2 xj hxj_act c)
        with ⟨md5, hd5, hxj_loc, hw_d5, hr_d5, _, hrl_d5, hlv_d5, hrlv_d5⟩
      have hmh_md5 : ∀ c : Fin d, rReadL 1 md5 29 (c.val : ℤ) = euclideanCoord (P.handleCoords mh) c := by
        intro c
        rw [hrl_d5 (c.val : ℤ) (Or.inl (by have := c.isLt; omega))]
        simp [md4, hrl_d3, md2, md1, hmr_rl, hmh_c c]
      rcases exec_distSqLocalStmt inp md5 hmh_md5
          (fun c => by simpa [Nat.cast_add] using hxj_loc c)
        with ⟨md6, hd6, hdsq_d6, hw_d6, hr_d6, _, hrl_d6, hlv_d6, hrlv_d6⟩
      have hmh_md6 : ∀ c : Fin d, rReadL 1 md6 29 (c.val : ℤ) = euclideanCoord (P.handleCoords mh) c := by
        intro c
        rw [hrl_d6 (c.val : ℤ) (by have := c.isLt; omega)]
        exact hmh_md5 c
      have hw27_md6 : ∀ idx, wReadL 1 md6 27 idx = wReadL 1 m 27 idx := by
        intro idx
        simp [hlv_d6 27 (by decide), hlv_d5 27 (by decide), md4, hwl_d3 27 (by decide),
          md2, md1, hmr_wl 27 idx (Or.inl (by decide))]
      have hr27_md6 : ∀ idx, rReadL 1 md6 27 idx = rReadL 1 m 27 idx := by
        intro idx
        simp [hrlv_d6 27 (by decide), hrlv_d5 27 (by decide), md4, hrl_d3,
          md2, md1, hmr_rl]
      let curSq := euclideanDistSq (P.handleCoords mh) (P.handleCoords xj)
      by_cases htake : wReadL 1 m 27 4 = 0 ∨ rReadL 1 m 27 0 < curSq
      · have hcond_u : cValAt 1 inp md6
            (.or (.intEq (.readLocal 27 (.lit 4)) (.lit 0))
                 (.realLt (.readRealLocal 27 (.lit 0)) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))) = true := by
          simp only [cValAt_or, cValAt_intEq, cValAt_realLt, iValAt_readLocal, iValAt_lit,
            rValAt_readRealLocal, hw27_md6, hr27_md6, hdsq_d6, Bool.or_eq_true, decide_eq_true_eq]
          exact htake
        let md7 := wWriteL 1 md6 27 4 1
        let md8 := wWriteL 1 md7 27 3 (xj : ℤ)
        let md9 := rWriteL 1 md8 27 0 curSq
        have hd7 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 4) (.lit 1)) md6 md7 4 :=
          DetExecAt.writeWordLocal 1 inp md6 27 _ _ rfl rfl (by simp [intExprOps])
        have hd8 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 3) (.readLocal 28 (.lit 0))) md7 md8 6 := by
          refine DetExecAt.writeWordLocal 1 inp md7 27 _ _ rfl ?_ (by simp [intExprOps])
          simp [md7, hlv_d6 28 (by decide), hlv_d5 28 (by decide), md4, hsel_d3, xj, selAt, rk]
        have hd9 : DetExecAt 1 inp
            (.writeRealLocal 27 (.lit 0) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))) md8 md9 6 :=
          DetExecAt.writeRealLocal 1 inp md8 27 _ _ rfl
            (by simp only [rValAt_readRealLocal, iValAt_lit, md8, md7, rReadL_wWriteL, hdsq_d6, curSq])
            (by simp [intExprOps, realExprOps])
        refine ⟨md9,
          (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq
            (DetExecAt.ite_true hcond_u (C_c := 15) (by simp [condExprOps, realExprOps, intExprOps])
              (hd7.seq (hd8.seq hd9))))))))).mono_cost (by omega),
          fun t idx => by simp [md9, md8, md7, hw_d6, hw_d5, md4, hw_d3, md2, md1, hmr_w, hw_m],
          fun t idx => by simp [md9, md8, md7, hr_d6, hr_d5, md4, hr_d3, md2, md1, hmr_r, hr_m],
          fun c => by simpa [md9, md8, md7] using hmh_md6 c,
          by simp [md9, md8, md7, hw27_md6, hm27_0],
          by simp [md9, md8, md7, hw27_md6, hm27_1],
          by simp [md9, md8, md7, hw27_md6, hm27_2],
          fun h0 => by omega,
          fun _ => ⟨by simp [md9, md8, md7], xj,
            ⟨j, Nat.lt_succ_self j, by simp [Function.update, xj]⟩,
            by simp [md9, md8],
            by simp [md9, curSq],
            fun k hk => ?_⟩⟩
        rcases Nat.lt_succ_iff_lt_or_eq.mp hk with hk_lt | rfl
        · have hne_k : k ≠ j := Nat.ne_of_lt hk_lt
          have hj_pos : 1 ≤ j := by omega
          rcases hjpos_inv hj_pos with ⟨hw4_1, fh, _, _, hr0_fh, hmax_fh⟩
          have hlt_sq : euclideanDistSq (P.handleCoords mh) (P.handleCoords fh) < curSq := by
            rcases htake with h0 | hlt
            · omega
            · rwa [hr0_fh] at hlt
          simp only [Function.update, hne_k, ↓reduceDIte]
          exact (hmax_fh k hk_lt).trans (le_of_lt hlt_sq)
        · simp [Function.update, xj]
      · push_neg at htake
        rcases htake with ⟨hne0_4, hle_cur⟩
        have hj_pos : 1 ≤ j := by
          by_contra hj0
          have hj_eq : j = 0 := by omega
          exact hne0_4 (hj0_inv hj_eq).1
        rcases hjpos_inv hj_pos with ⟨hw4_1, fh, ⟨k0, hk0_lt, hfh_eq⟩, hfh_r, hr0_fh, hmax_fh⟩
        have hcond_u : cValAt 1 inp md6
            (.or (.intEq (.readLocal 27 (.lit 4)) (.lit 0))
                 (.realLt (.readRealLocal 27 (.lit 0)) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))) = false := by
          simp only [cValAt_or, cValAt_intEq, cValAt_realLt, iValAt_readLocal, iValAt_lit,
            rValAt_readRealLocal, hw27_md6, hr27_md6, hdsq_d6, Bool.or_eq_false_iff,
            decide_eq_false_iff_not, not_lt]
          exact ⟨hne0_4, hle_cur⟩
        refine ⟨md6,
          (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq
            (DetExecAt.ite_false hcond_u (C_c := 15) (by simp [condExprOps, realExprOps, intExprOps])
              (DetExecAt.skip 1 inp md6)))))))).mono_cost (by omega),
          fun t idx => by simp [hw_d6, hw_d5, md4, hw_d3, md2, md1, hmr_w, hw_m],
          fun t idx => by simp [hr_d6, hr_d5, md4, hr_d3, md2, md1, hmr_r, hr_m],
          hmh_md6,
          by simp [hw27_md6, hm27_0],
          by simp [hw27_md6, hm27_1],
          by simp [hw27_md6, hm27_2],
          fun h0 => by omega,
          fun _ => ⟨by simp [hw27_md6, hw4_1], fh,
            ⟨k0, Nat.lt_succ_of_lt hk0_lt, by
              have hk0_ne : k0 ≠ j := Nat.ne_of_lt hk0_lt
              simp [Function.update, hk0_ne, hfh_eq]⟩,
            by simp [hw27_md6, hfh_r],
            by simp [hr27_md6, hr0_fh],
            fun k hk => ?_⟩⟩
        rcases Nat.lt_succ_iff_lt_or_eq.mp hk with hk_lt | rfl
        · have hk_ne : k ≠ j := Nat.ne_of_lt hk_lt
          simp only [Function.update, hk_ne, ↓reduceDIte]
          exact hmax_fh k hk_lt
        · simp only [Function.update, ↓reduceDIte]
          rwa [hr0_fh] at hle_cur
    have hrepB := RandExecAt.repeatN_nat (.lit (p.K₀ : ℤ)) _ p.K₀ p.M_bits 10 C_iter
      InvB (chunks₀ := fun _ _ => false) hInvB0 rfl (by simp [intExprOps]) hStepB
    -- Tail after repeatN: copy (mh, fh, farSq) to 29[22, 23, r22] and tryUpdateBestCandInnerStmt
    have hTail : RandExecAt 1 inp
        (seqList [
          .repeatN (.lit (p.K₀ : ℤ))
            (.seq (readRandNatLocalStmt 29 12 13 p.M_bits)
                  (baselineSampleIterDetStmt d p.K_seg)),
          .writeWordLocal 29 (.lit 22) (.readLocal 27 (.lit 2)),
          .writeWordLocal 29 (.lit 23) (.readLocal 27 (.lit 3)),
          .writeRealLocal 29 (.lit 22) (.readRealLocal 27 (.lit 0)),
          tryUpdateBestCandInnerStmt M_box 22 23 22
        ])
        (p.K₀ * p.M_bits) m9
        (fun bits mt =>
          BestCandInv P mt ∧
          (wRead mem 26 10 = 1 → wRead mt 26 10 = 1 ∧ rRead mem 26 10 ≤ rRead mt 26 10) ∧
          (∀ t, t ≠ 26 → ∀ idx, wRead mt t idx = wRead mem t idx) ∧
          (∀ idx, idx ≠ 10 → idx ≠ 11 → idx ≠ 12 → wRead mt 26 idx = wRead mem 26 idx) ∧
          (∀ t, t ≠ 26 → ∀ idx, rRead mt t idx = rRead mem t idx) ∧
          (∀ idx, idx ≠ 10 → rRead mt 26 idx = rRead mem 26 idx) ∧
          ∃ fh : ℕ,
            fh ∈ S ∧
            (fh ≠ mh →
              wRead mt 26 10 = 1 ∧
              euclideanDistSq (P.handleCoords mh) (P.handleCoords fh) ≤ rRead mt 26 10) ∧
            ∀ (j : Fin p.K₀),
              let bj : Fin p.M_bits → Bool := fun b =>
                bits ⟨j.val * p.M_bits + b.val, by
                  calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
                    _ = (j.val + 1) * p.M_bits := by ring
                    _ ≤ p.K₀ * p.M_bits := Nat.mul_le_mul_right _ j.isLt⟩
              euclideanDistSq (P.handleCoords mh) (P.handleCoords (selAt bj)) ≤
                euclideanDistSq (P.handleCoords mh) (P.handleCoords fh))
        ((10 + p.K₀ * C_iter) + 150) := by
      dsimp only [seqList]
      refine RandExecAt.seq_det_right hrepB ?_
      rintro bits mrN ⟨chunks_N, ⟨hwN, hrN, _, _, _, hm27_2N, _, hjposN⟩, hchunksN⟩
      rcases hjposN hK0_pos with ⟨_, fh, ⟨k0, hk0_lt, hfh_sel⟩, hfh_r, hr0_fh, hmax_fh⟩
      have hfh_in : fh ∈ S := by
        rw [hfh_sel]
        exact S.orderEmbOfFin_mem rfl _
      have hfh_act : fh ∈ P.activeHandles := hS_sub hfh_in
      let mt1 := wWriteL 1 mrN 29 22 (mh : ℤ)
      let mt2 := wWriteL 1 mt1 29 23 (fh : ℤ)
      let mt3 := rWriteL 1 mt2 29 22 (euclideanDistSq (P.handleCoords mh) (P.handleCoords fh))
      have ht1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 22) (.readLocal 27 (.lit 2))) mrN mt1 6 :=
        DetExecAt.writeWordLocal 1 inp mrN 29 _ _ rfl (by simp [hm27_2N]) (by simp [intExprOps])
      have ht2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 23) (.readLocal 27 (.lit 3))) mt1 mt2 6 :=
        DetExecAt.writeWordLocal 1 inp mt1 29 _ _ rfl (by simp [mt1, hfh_r]) (by simp [intExprOps])
      have ht3 : DetExecAt 1 inp (.writeRealLocal 29 (.lit 22) (.readRealLocal 27 (.lit 0))) mt2 mt3 6 :=
        DetExecAt.writeRealLocal 1 inp mt2 29 _ _ rfl (by simp [mt2, mt1, hr0_fh])
          (by simp [intExprOps, realExprOps])
      have hInv_mt3 : BestCandInv P mt3 :=
        hInv.congr_mem (by simp [mt3, mt2, mt1, hwN]) (by simp [mt3, mt2, mt1, hwN])
          (by simp [mt3, mt2, mt1, hwN]) (by simp [mt3, mt2, mt1, hrN])
      rcases exec_tryUpdateBestCandInnerStmt inp mt3 22 23 22 hBox hInv_mt3 hmh_act hfh_act
          (by simp [mt3, mt2, mt1]) (by simp [mt3, mt2]) (by simp [mt3])
        with ⟨mt4, ht4, hInv4, hmono4, hdom4, hw4_o, hw4_26, hr4_o, hr4_26, _, _⟩
      refine ⟨mt4, (ht1.seq (ht2.seq (ht3.seq ht4))).mono_cost (by omega),
        hInv4,
        fun h1 => by
          have h1' : wRead mt3 26 10 = 1 := by simp [mt3, mt2, mt1, hwN, h1]
          rcases hmono4 h1' with ⟨ha, hb⟩
          exact ⟨ha, by simpa [mt3, mt2, mt1, hrN] using hb⟩,
        fun t ht idx => by simp [hw4_o t ht, mt3, mt2, mt1, hwN],
        fun idx a b c => by simp [hw4_26 idx a b c, mt3, mt2, mt1, hwN],
        fun t ht idx => by simp [hr4_o t ht, mt3, mt2, mt1, hrN],
        fun idx a => by simp [hr4_26 idx a, mt3, mt2, mt1, hrN],
        fh, hfh_in,
        fun hne => hdom4 (Ne.symm hne),
        fun j => ?_⟩
      have hcj := hchunksN j
      have h1 := hmax_fh j.val j.isLt
      rw [hcj] at h1
      exact h1
    have hp9 := RandExecAt.seq_det_left hs9 hTail
    have hp8 := RandExecAt.seq_det_left hs8 hp9
    have hp7 := RandExecAt.seq_det_left hs7 hp8
    have hp6 := RandExecAt.seq_det_left hs6 hp7
    have hp5 := RandExecAt.seq_det_left hs5 hp6
    have hiteNZ := RandExecAt.ite_false
      (tB := .repeatN (.lit (p.K₀ : ℤ)) (readRandNatLocalStmt 29 12 13 p.M_bits))
      hcond_z (C_c := 10) (by simp [condExprOps, intExprOps]) hp5
    have hq4 := RandExecAt.seq_det_left hs4 hiteNZ
    have hq3 := RandExecAt.seq_det_left hs3 hq4
    have hq2 := RandExecAt.seq_det_left hs2 hq3
    have hq1 := RandExecAt.seq_det_left hs1 hq2
    have hsc := RandExecAt.localScope hq1
    have htop := RandExecAt.ite_true (fB := randDummyBitsStmt (p.K₀ * p.M_bits))
      hcond_act (C_c := 10) (by simp [condExprOps, intExprOps]) hsc
    -- Define Bad set via p46_mc_baseline_bad_card_le when P_good holds (else False)
    have hSuid_pos : 0 < S_uid.card := by omega
    have hSuid_le_n : S_uid.card ≤ n := by omega
    let eHS : ↥S ≃ ↥S_uid :=
      { toFun := fun x => ⟨uidOfH x.1, (hf_uid x.1 x.2).1⟩
        invFun := fun y => ⟨hOfUid y.1, (hg_uid y.1 y.2).1⟩
        left_inv := fun x => Subtype.ext (hf_uid x.1 x.2).2.2
        right_inv := fun y => Subtype.ext (hg_uid y.1 y.2).2 }
    let enumUid : Fin S_uid.card ≃ ↥S_uid :=
      (finCongr hcard_uid).trans ((S.orderIsoOfFin rfl).toEquiv.trans eHS)
    let y_uid := uidOfH mh
    let BadFn : (Fin (p.K₀ * p.M_bits) → Bool) → Prop := fun bits =>
      P_good ∧
      let sampBits : Fin p.K₀ → Fin p.M_bits → Bool := fun j b =>
        bits ⟨j.val * p.M_bits + b.val, by
          calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
            _ = (j.val + 1) * p.M_bits := by ring
            _ ≤ p.K₀ * p.M_bits := Nat.mul_le_mul_right _ j.isLt⟩
      let rk := modSampleTuple hSuid_pos p.K₀ p.M_bits sampBits
      ∀ j : Fin p.K₀,
        ¬ IsNodeBaselinePair ghostCoords node.o node.V S_uid y_uid (enumUid (rk j)).1
    have hBad_card :
        ((Finset.univ.filter BadFn).card : ℝ) ≤ (2 * p.φ_ev) * ((2 : ℝ) ^ (p.K₀ * p.M_bits)) := by
      by_cases hG : P_good
      · rcases hGoodImp hG with ⟨P₀_uid, age, hP0_card, hcp_uid, hage_uid, hage_le⟩
        have hy_max_h : IsNodeMaxRadiusPoint P.handleCoords node.o S mh :=
          isNodeMaxRadiusPoint_of_max_distSq P.handleCoords node.o S hmh_in hmh_max
        have hy_max_uid : IsNodeMaxRadiusPoint ghostCoords node.o S_uid y_uid := by
          refine ⟨(hf_uid mh hmh_in).1, ?_⟩
          rw [(hf_uid mh hmh_in).2.1, hy_max_h.2]
          exact nodeMaxRadius_bij P.handleCoords ghostCoords node.o S S_uid uidOfH hOfUid
            (fun h hh => ⟨(hf_uid h hh).1, (hf_uid h hh).2.1⟩) hg_uid
        have hV_eq : liftVariance node.o (node.V + ‖node.o‖ ^ 2) = node.V := by
          simp [liftVariance]
        have hmc_inst := p46_mc_baseline_bad_card_le p ghostCoords S_uid node.o
          (node.V + ‖node.o‖ ^ 2) y_uid hSuid_pos hSuid_le_n enumUid
          (fun farthest hf => hmc_gen ghostCoords P₀_uid S_uid age node.o (node.V + ‖node.o‖ ^ 2)
            y_uid farthest hP0_card hcp_uid hage_uid hage_le hy_max_uid hf)
          hφ0 hbias hK0_pos
        dsimp only at hmc_inst
        rw [hV_eq] at hmc_inst
        let eCur : (Fin (p.K₀ * p.M_bits) → Bool) ≃ (Fin p.K₀ → Fin p.M_bits → Bool) :=
          { toFun := fun bits j b =>
              bits ⟨j.val * p.M_bits + b.val, by
                calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
                  _ = (j.val + 1) * p.M_bits := by ring
                  _ ≤ p.K₀ * p.M_bits := Nat.mul_le_mul_right _ j.isLt⟩
            invFun := fun f idx =>
              have hM_pos : 0 < p.M_bits := by
                by_contra hM0
                have hM_eq : p.M_bits = 0 := by omega
                have := idx.isLt
                simp [hM_eq] at this
              f ⟨idx.val / p.M_bits, (Nat.div_lt_iff_lt_mul hM_pos).mpr idx.isLt⟩
                ⟨idx.val % p.M_bits, Nat.mod_lt _ hM_pos⟩
            left_inv := fun bits => by
              ext idx
              dsimp only
              apply congrArg bits
              ext
              dsimp only
              have := Nat.div_add_mod idx.val p.M_bits
              linarith
            right_inv := fun f => by
              ext j b
              have hM_pos : 0 < p.M_bits := by have := b.isLt; omega
              have hdiv : (j.val * p.M_bits + b.val) / p.M_bits = j.val := by
                rw [mul_comm, Nat.mul_add_div hM_pos, Nat.div_eq_of_lt b.isLt, add_zero]
              have hmod : (j.val * p.M_bits + b.val) % p.M_bits = b.val := by
                rw [mul_comm, Nat.mul_add_mod, Nat.mod_eq_of_lt b.isLt]
              dsimp only
              have hj_eq : (⟨(j.val * p.M_bits + b.val) / p.M_bits,
                  (Nat.div_lt_iff_lt_mul hM_pos).mpr (by
                    calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
                      _ = (j.val + 1) * p.M_bits := by ring
                      _ ≤ p.K₀ * p.M_bits := Nat.mul_le_mul_right _ j.isLt)⟩ : Fin p.K₀) = j :=
                Fin.ext hdiv
              have hb_eq : (⟨(j.val * p.M_bits + b.val) % p.M_bits,
                  Nat.mod_lt _ hM_pos⟩ : Fin p.M_bits) = b :=
                Fin.ext hmod
              rw [hj_eq, hb_eq] }
        have hbij : (Finset.univ.filter BadFn).card =
            (Finset.univ.filter (fun sampBits : Fin p.K₀ → Fin p.M_bits → Bool =>
              let rk := modSampleTuple hSuid_pos p.K₀ p.M_bits sampBits
              ∀ j : Fin p.K₀, ¬ IsNodeBaselinePair ghostCoords node.o node.V S_uid y_uid
                (enumUid (rk j)).1)).card := by
          refine Finset.card_bij (fun bits _ => eCur bits) ?_ (fun _ _ _ _ h => eCur.injective h) ?_
          · intro bits hbits
            simp only [Finset.mem_filter, Finset.mem_univ, true_and, BadFn, hG] at hbits ⊢
            exact hbits
          · intro f hf
            refine ⟨eCur.symm f, ?_, eCur.apply_symm_apply f⟩
            have happ := eCur.apply_symm_apply f
            simp only [Finset.mem_filter, Finset.mem_univ, true_and, BadFn, hG] at hf ⊢
            change (∀ j : Fin p.K₀, ¬ IsNodeBaselinePair ghostCoords node.o node.V S_uid y_uid
              (enumUid (modSampleTuple hSuid_pos p.K₀ p.M_bits (eCur (eCur.symm f)) j)).1)
            rw [happ]
            exact hf
        rw [hbij]
        exact hmc_inst
      · have hemp : Finset.univ.filter BadFn = ∅ := by
          ext bits
          simp [BadFn, hG]
        rw [hemp, Finset.card_empty, Nat.cast_zero]
        positivity
    refine ⟨_, BadFn, inferInstance, htop.mono (fun _ _ h => h) ?_, hBad_card, ?_⟩
    · unfold baselineCallCost
      simp only [intExprOps, C_iter]
      have hsub1 : p.K₀ * (180 * (p.M_bits + p.K_seg + d + 5)) =
          (180 * p.K₀) * (p.M_bits + p.K_seg + d + 5) := by ring
      have hsub2 : (180 * p.K₀) * (p.M_bits + p.K_seg + d + 5) + 25 * (d + 1) ≤
          250 * (p.K₀ + 1) * (p.M_bits + p.K_seg + d + 5) := by
        have ha : (180 * p.K₀) * (p.M_bits + p.K_seg + d + 5) ≤
            (200 * p.K₀) * (p.M_bits + p.K_seg + d + 5) :=
          Nat.mul_le_mul_right _ (by omega)
        have hb : 25 * (d + 1) ≤ 50 * (p.M_bits + p.K_seg + d + 5) :=
          calc 25 * (d + 1) ≤ 50 * (d + 1) := by omega
            _ ≤ 50 * (p.M_bits + p.K_seg + d + 5) := Nat.mul_le_mul_left _ (by omega)
        have hexp : 250 * (p.K₀ + 1) * (p.M_bits + p.K_seg + d + 5) =
            (200 * p.K₀) * (p.M_bits + p.K_seg + d + 5) +
            (50 * p.K₀) * (p.M_bits + p.K_seg + d + 5) +
            250 * (p.M_bits + p.K_seg + d + 5) := by ring
        omega
      omega
    · rintro bits m' ⟨mt, ⟨hInv_t, hmono_t, hw_to, hw_t26, hr_to, hr_t26, fh, hfh_in, hdom_fh, hmax_fh⟩, rfl⟩
      refine ⟨popDepth_zero_idem mt,
        hInv_t.congr_mem (by simp) (by simp) (by simp) (by simp),
        fun h1 => ⟨by simp [(hmono_t h1).1], by simpa using (hmono_t h1).2⟩,
        fun t ht idx => by simp [hw_to t ht],
        fun idx a b c => by simp [hw_t26 idx a b c],
        fun t ht idx => by simp [hr_to t ht],
        fun idx a => by simp [hr_t26 idx a],
        fun hG hnot_bad => ?_⟩
      -- Extract good sample j* where IsNodeBaselinePair holds
      have hex_j : ∃ j : Fin p.K₀,
          let sampBits : Fin p.K₀ → Fin p.M_bits → Bool := fun j' b =>
            bits ⟨j'.val * p.M_bits + b.val, by
              calc j'.val * p.M_bits + b.val < j'.val * p.M_bits + p.M_bits := by omega
                _ = (j'.val + 1) * p.M_bits := by ring
                _ ≤ p.K₀ * p.M_bits := Nat.mul_le_mul_right _ j'.isLt⟩
          let rk := modSampleTuple hSuid_pos p.K₀ p.M_bits sampBits
          IsNodeBaselinePair ghostCoords node.o node.V S_uid y_uid (enumUid (rk j)).1 := by
        by_contra hall
        push_neg at hall
        exact hnot_bad ⟨hG, hall⟩
      rcases hex_j with ⟨jstar, hjstar⟩
      dsimp only at hjstar
      let bjstar : Fin p.M_bits → Bool := fun b =>
        bits ⟨jstar.val * p.M_bits + b.val, by
          calc jstar.val * p.M_bits + b.val < jstar.val * p.M_bits + p.M_bits := by omega
            _ = (jstar.val + 1) * p.M_bits := by ring
            _ ≤ p.K₀ * p.M_bits := Nat.mul_le_mul_right _ jstar.isLt⟩
      have henum_eq : (enumUid ⟨bitsFnToNat p.M_bits bjstar % S_uid.card, Nat.mod_lt _ hSuid_pos⟩).1 =
          uidOfH (selAt bjstar) := by
        dsimp [enumUid, eHS, selAt]
        apply congrArg uidOfH
        apply congrArg (S.orderEmbOfFin rfl)
        ext
        simp [hcard_uid]
      change IsNodeBaselinePair ghostCoords node.o node.V S_uid y_uid
          (enumUid ⟨bitsFnToNat p.M_bits bjstar % S_uid.card, Nat.mod_lt _ hSuid_pos⟩).1 at hjstar
      rw [henum_eq] at hjstar
      let fh_uid := uidOfH fh
      have hpair_fh : IsNodeBaselinePair ghostCoords node.o node.V S_uid y_uid fh_uid := by
        refine ⟨(hf_uid mh hmh_in).1, (hf_uid fh hfh_in).1, ?_⟩
        have h1 := hjstar.2.2
        have h2 := hmax_fh jstar
        have hsel_in : selAt bjstar ∈ S := S.orderEmbOfFin_mem rfl _
        have hd1 : ‖ghostCoords y_uid - ghostCoords (uidOfH (selAt bjstar))‖ ^ 2 =
            euclideanDistSq (P.handleCoords mh) (P.handleCoords (selAt bjstar)) := by
          simp [y_uid, (hf_uid mh hmh_in).2.1, (hf_uid _ hsel_in).2.1, euclideanDistSq]
        have hd2 : ‖ghostCoords y_uid - ghostCoords fh_uid‖ ^ 2 =
            euclideanDistSq (P.handleCoords mh) (P.handleCoords fh) := by
          simp [y_uid, fh_uid, (hf_uid mh hmh_in).2.1, (hf_uid fh hfh_in).2.1, euclideanDistSq]
        linarith
      refine ⟨some (y_uid, fh_uid),
        ⟨⟨hpair_fh.1, hpair_fh.2.1⟩, fun _ => by simpa [baselinePairLength] using hpair_fh.2.2⟩,
        fun u v heq huv_ne => ?_⟩
      injection heq with hp_eq
      rcases Prod.mk.inj hp_eq with ⟨rfl, rfl⟩
      have hfh_ne_mh : fh ≠ mh := fun heq_h => huv_ne (congrArg uidOfH heq_h.symm)
      rcases hdom_fh hfh_ne_mh with ⟨hw10, hle10⟩
      refine ⟨by simp [hw10], ?_⟩
      have hd2 : ‖ghostCoords y_uid - ghostCoords fh_uid‖ ^ 2 =
          euclideanDistSq (P.handleCoords mh) (P.handleCoords fh) := by
        simp [y_uid, fh_uid, (hf_uid mh hmh_in).2.1, (hf_uid fh hfh_in).2.1, euclideanDistSq]
      rw [hd2, rRead_popDepth]
      exact hle10

/-! ### 4. Exact All-Pairs Small-Leaf Scan (`scanLeafPairsStmt`) -/

def scanLeafInnerIterStmt (d K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .ite (.and (.intLt (.readLocal 27 (.lit 4)) (.readLocal 27 (.lit 1)))
               (.not (.intEq (.readLocal 27 (.lit 2)) (.readLocal 27 (.lit 4)))))
      (seqList [
        .writeWordLocal 28 (.lit 20) (.readLocal 27 (.lit 0)),
        .writeWordLocal 28 (.lit 21) (.readLocal 27 (.lit 4)),
        selectByRankSegStmt K,
        .writeWordLocal 27 (.lit 5) (.readLocal 28 (.lit 0)),
        .writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 5)) (.lit (d : ℤ))),
        loadHeapCoordsToLocalStmt d 4 18 (d : ℤ),
        distSqLocalStmt d,
        .writeWordLocal 29 (.lit 22) (.readLocal 27 (.lit 3)),
        .writeWordLocal 29 (.lit 23) (.readLocal 27 (.lit 5)),
        tryUpdateBestCandInnerStmt M_box 22 23 (((2 * d : ℕ) : ℤ))
      ])
      .skip,
    .writeWordLocal 27 (.lit 4) (.add (.readLocal 27 (.lit 4)) (.lit 1))
  ]

def scanLeafOuterIterStmt (d K M_leaf M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .ite (.intLt (.readLocal 27 (.lit 2)) (.readLocal 27 (.lit 1)))
      (seqList [
        .writeWordLocal 28 (.lit 20) (.readLocal 27 (.lit 0)),
        .writeWordLocal 28 (.lit 21) (.readLocal 27 (.lit 2)),
        selectByRankSegStmt K,
        .writeWordLocal 27 (.lit 3) (.readLocal 28 (.lit 0)),
        .writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 3)) (.lit (d : ℤ))),
        loadHeapCoordsToLocalStmt d 4 18 0,
        .writeWordLocal 27 (.lit 4) (.lit 0),
        .repeatN (.lit (M_leaf : ℤ)) (scanLeafInnerIterStmt d K M_box)
      ])
      .skip,
    .writeWordLocal 27 (.lit 2) (.add (.readLocal 27 (.lit 2)) (.lit 1))
  ]

def scanLeafPairsStmt (d K M_leaf M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 27 (.lit 0) (.readHeap 1 (.lit 6)),
    cardAndMaxSegSlotStmt K (.readLocal 27 (.lit 0)),
    .writeWordLocal 27 (.lit 1) (.readLocal 28 (.lit 0)),
    .writeWordLocal 27 (.lit 2) (.lit 0),
    .repeatN (.lit (M_leaf : ℤ)) (scanLeafOuterIterStmt d K M_leaf M_box)
  ])

theorem boxSafe_scanLeafPairsStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (d K M_leaf : ℕ) :
    BoxSafeOuter T_max M_box (scanLeafPairsStmt d K M_leaf M_box) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact boxSafe_cardAndMaxSegSlotStmt _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .repeatN _ (boxSafeInner_seqList ?_)
    intro s' hs'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl
    · refine .ite _ (boxSafeInner_seqList ?_) .skip
      intro s'' hs''
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hs''
      rcases hs'' with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact .writeWordLocal _ _ _
      · exact boxSafe_selectByRankSegStmt _
      · exact .writeWordLocal _ _ _
      · exact .writeWordLocal _ _ _
      · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
      · exact .writeWordLocal _ _ _
      · refine .repeatN _ (boxSafeInner_seqList ?_)
        intro w hw
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hw
        rcases hw with rfl | rfl
        · refine .ite _ (boxSafeInner_seqList ?_) .skip
          intro z hz
          simp only [List.mem_cons, List.not_mem_nil, or_false] at hz
          rcases hz with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
          · exact .writeWordLocal _ _ _
          · exact .writeWordLocal _ _ _
          · exact boxSafe_selectByRankSegStmt _
          · exact .writeWordLocal _ _ _
          · exact .writeWordLocal _ _ _
          · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
          · exact boxSafe_distSqLocalStmt _
          · exact .writeWordLocal _ _ _
          · exact .writeWordLocal _ _ _
          · exact boxSafe_tryUpdateBestCandInnerStmt hT _ _ _
        · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _

theorem exec_scanLeafPairsStmt {d n K M_leaf M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {P : DynamicPointSet d} {s : ℕ} {S_leaf : Finset ℕ} {fSq : ℕ → ℝ}
    (hs_reg : wRead mem 1 6 = (s : ℤ))
    (hBox : 13 ≤ M_box)
    (hInv : BestCandInv P mem)
    (hLive : EncLiveCoords d n mem P.activeHandles P.handleCoords)
    (hS_sub : S_leaf ⊆ P.activeHandles)
    (hS_le : S_leaf.card ≤ M_leaf)
    (hSeg : EncSegSlot K mem s S_leaf fSq) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (scanLeafPairsStmt d K M_leaf M_box) mem m'
        (350 * (M_leaf + 1) * (M_leaf + 1) * (K + d + 5) + 500) ∧
      m'.popDepth 0 = m' ∧
      BestCandInv P m' ∧
      (wRead mem 26 10 = 1 → wRead m' 26 10 = 1 ∧ rRead mem 26 10 ≤ rRead m' 26 10) ∧
      (∀ t, t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 10 → idx ≠ 11 → idx ≠ 12 → wRead m' 26 idx = wRead mem 26 idx) ∧
      (∀ t, t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx) ∧
      (∀ idx, idx ≠ 10 → rRead m' 26 idx = rRead mem 26 idx) ∧
      (∀ a (ha : a < S_leaf.card) b (hb : b < S_leaf.card), a ≠ b →
        wRead m' 26 10 = 1 ∧
        euclideanDistSq (P.handleCoords (S_leaf.orderEmbOfFin rfl ⟨a, ha⟩))
                        (P.handleCoords (S_leaf.orderEmbOfFin rfl ⟨b, hb⟩)) ≤ rRead m' 26 10) := by
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 27 0 (s : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 0) (.readHeap 1 (.lit 6))) m0 m1 6 :=
    DetExecAt.writeWordLocal 1 inp m0 27 _ _ rfl (by simp [m0, hs_reg]) (by simp [intExprOps])
  have hSeg_m1 : EncSegSlot K m1 s S_leaf fSq :=
    hSeg.congr_mem_fSq (by simp [m1, m0]) (fun _ _ => by simp [m1, m0])
      (fun _ _ => by simp [m1, m0]) (fun _ _ => by simp [m1, m0])
      (fun _ _ => by simp [m1, m0]) (fun _ _ => rfl)
  rcases exec_cardAndMaxSegSlotStmt inp m1 (.readLocal 27 (.lit 0)) (by simp [m1]) hSeg_m1
    with ⟨m2, hs2, hm2_card, _, hw2, hr2, hwl2, _⟩
  let m3 := wWriteL 1 m2 27 1 (S_leaf.card : ℤ)
  let m4 := wWriteL 1 m3 27 2 0
  have hs3 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 1) (.readLocal 28 (.lit 0))) m2 m3 6 :=
    DetExecAt.writeWordLocal 1 inp m2 27 _ _ rfl (by simp [hm2_card]) (by simp [intExprOps])
  have hs4 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 2) (.lit 0)) m3 m4 4 :=
    DetExecAt.writeWordLocal 1 inp m3 27 _ _ rfl rfl (by simp [intExprOps])
  let C_in : ℕ := 260 * (K + d + 5)
  let C_out : ℕ := 320 * (M_leaf + 1) * (K + d + 5)
  let InvOut : ℕ → ArithRAMMemory → Prop := fun a m =>
    BestCandInv P m ∧
    (wRead mem 26 10 = 1 → wRead m 26 10 = 1 ∧ rRead mem 26 10 ≤ rRead m 26 10) ∧
    (∀ t, t ≠ 26 → ∀ idx, wRead m t idx = wRead mem t idx) ∧
    (∀ idx, idx ≠ 10 → idx ≠ 11 → idx ≠ 12 → wRead m 26 idx = wRead mem 26 idx) ∧
    (∀ t, t ≠ 26 → ∀ idx, rRead m t idx = rRead mem t idx) ∧
    (∀ idx, idx ≠ 10 → rRead m 26 idx = rRead mem 26 idx) ∧
    wReadL 1 m 27 0 = (s : ℤ) ∧
    wReadL 1 m 27 1 = (S_leaf.card : ℤ) ∧
    wReadL 1 m 27 2 = (a : ℤ) ∧
    ∀ a' (ha' : a' < S_leaf.card), a' < a →
      ∀ b' (hb' : b' < S_leaf.card), a' ≠ b' →
        wRead m 26 10 = 1 ∧
        euclideanDistSq (P.handleCoords (S_leaf.orderEmbOfFin rfl ⟨a', ha'⟩))
                        (P.handleCoords (S_leaf.orderEmbOfFin rfl ⟨b', hb'⟩)) ≤ rRead m 26 10
  have hInvOut0 : InvOut 0 m4 := by
    refine ⟨hInv.congr_mem (by simp [m4, m3, hw2, m1, m0]) (by simp [m4, m3, hw2, m1, m0])
        (by simp [m4, m3, hw2, m1, m0]) (by simp [m4, m3, hr2, m1, m0]),
      fun h1 => ⟨by simp [m4, m3, hw2, m1, m0, h1], by simp [m4, m3, hr2, m1, m0]⟩,
      fun t _ idx => by simp [m4, m3, hw2, m1, m0],
      fun idx _ _ _ => by simp [m4, m3, hw2, m1, m0],
      fun t _ idx => by simp [m4, m3, hr2, m1, m0],
      fun idx _ => by simp [m4, m3, hr2, m1, m0],
      by simp [m4, m3, hwl2 27 (by decide), m1],
      by simp [m4, m3],
      by simp [m4],
      fun _ _ ha => by omega⟩
  have hStepOut : ∀ a < M_leaf, ∀ m, InvOut a m →
      ∃ m', DetExecAt 1 inp (scanLeafOuterIterStmt d K M_leaf M_box) m m' C_out ∧ InvOut (a + 1) m' := by
    intro a _ m ⟨hInv_m, hmono_m, hw_mo, hw_m26, hr_mo, hr_m26, hm27_0, hm27_1, hm27_2, hprev_a⟩
    by_cases ha_lt : a < S_leaf.card
    · have hcond_a : cValAt 1 inp m (.intLt (.readLocal 27 (.lit 2)) (.readLocal 27 (.lit 1))) = true := by
        simp [hm27_2, hm27_1, ha_lt]
      let ua : ℕ := S_leaf.orderEmbOfFin rfl ⟨a, ha_lt⟩
      have hua_in : ua ∈ S_leaf := S_leaf.orderEmbOfFin_mem rfl ⟨a, ha_lt⟩
      have hua_act : ua ∈ P.activeHandles := hS_sub hua_in
      let ma1 := wWriteL 1 m 28 20 (s : ℤ)
      let ma2 := wWriteL 1 ma1 28 21 (a : ℤ)
      have ha1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readLocal 27 (.lit 0))) m ma1 6 :=
        DetExecAt.writeWordLocal 1 inp m 28 _ _ rfl (by simp [hm27_0]) (by simp [intExprOps])
      have ha2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readLocal 27 (.lit 2))) ma1 ma2 6 :=
        DetExecAt.writeWordLocal 1 inp ma1 28 _ _ rfl (by simp [ma1, hm27_2]) (by simp [intExprOps])
      have hSeg_ma2 : EncSegSlot K ma2 s S_leaf fSq :=
        hSeg.congr_mem_fSq
          (by simp [ma2, ma1, hw_mo 5 (by decide)])
          (fun _ _ => by simp [ma2, ma1, hw_mo 8 (by decide)])
          (fun _ _ => by simp [ma2, ma1, hw_mo 9 (by decide)])
          (fun _ _ => by simp [ma2, ma1, hw_mo 10 (by decide)])
          (fun _ _ => by simp [ma2, ma1, hr_mo 8 (by decide)])
          (fun _ _ => rfl)
      rcases exec_selectByRankSegStmt inp ma2 ha_lt (by simp [ma2, ma1]) (by simp [ma2]) hSeg_ma2
        with ⟨ma3, ha3, hsel_a3, hw_a3, hr_a3, hwl_a3, _⟩
      let ma4 := wWriteL 1 ma3 27 3 (ua : ℤ)
      let ma5 := wWriteL 1 ma4 29 18 (((ua * d : ℕ) : ℤ))
      have ha4 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 3) (.readLocal 28 (.lit 0))) ma3 ma4 6 :=
        DetExecAt.writeWordLocal 1 inp ma3 27 _ _ rfl (by simp [hsel_a3, ua]) (by simp [intExprOps])
      have ha5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 3)) (.lit (d : ℤ))))
          ma4 ma5 8 :=
        DetExecAt.writeWordLocal 1 inp ma4 29 _ _ rfl (by simp [ma4]) (by simp [intExprOps])
      rcases exec_loadHeapCoordsToLocalStmt inp ma5 (rTag := 4) (idxBase := 18) (destOff := 0)
          (base := ua * d) (pt := P.handleCoords ua) (by decide) (by simp [ma5])
          (fun c => by
            simp only [ma5, ma4, rRead_wWriteL, hr_a3, ma2, ma1, hr_mo 4 (by decide)]
            exact hLive.2 ua hua_act c)
        with ⟨ma6, ha6, hua_loc, hw_a6, hr_a6, _, _, hlv_a6, _⟩
      let ma7 := wWriteL 1 ma6 27 4 0
      have ha7 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 4) (.lit 0)) ma6 ma7 4 :=
        DetExecAt.writeWordLocal 1 inp ma6 27 _ _ rfl rfl (by simp [intExprOps])
      -- Inner loop over b < M_leaf
      let InvIn : ℕ → ArithRAMMemory → Prop := fun b mi =>
        BestCandInv P mi ∧
        (wRead m 26 10 = 1 → wRead mi 26 10 = 1 ∧ rRead m 26 10 ≤ rRead mi 26 10) ∧
        (∀ t, t ≠ 26 → ∀ idx, wRead mi t idx = wRead mem t idx) ∧
        (∀ idx, idx ≠ 10 → idx ≠ 11 → idx ≠ 12 → wRead mi 26 idx = wRead mem 26 idx) ∧
        (∀ t, t ≠ 26 → ∀ idx, rRead mi t idx = rRead mem t idx) ∧
        (∀ idx, idx ≠ 10 → rRead mi 26 idx = rRead mem 26 idx) ∧
        (∀ c : Fin d, rReadL 1 mi 29 (c.val : ℤ) = euclideanCoord (P.handleCoords ua) c) ∧
        wReadL 1 mi 27 0 = (s : ℤ) ∧
        wReadL 1 mi 27 1 = (S_leaf.card : ℤ) ∧
        wReadL 1 mi 27 2 = (a : ℤ) ∧
        wReadL 1 mi 27 3 = (ua : ℤ) ∧
        wReadL 1 mi 27 4 = (b : ℤ) ∧
        ∀ b' (hb' : b' < S_leaf.card), b' < b → a ≠ b' →
          wRead mi 26 10 = 1 ∧
          euclideanDistSq (P.handleCoords ua)
                          (P.handleCoords (S_leaf.orderEmbOfFin rfl ⟨b', hb'⟩)) ≤ rRead mi 26 10
      have hInvIn0 : InvIn 0 ma7 := by
        refine ⟨hInv_m.congr_mem (by simp [ma7, hw_a6, ma5, ma4, hw_a3, ma2, ma1])
            (by simp [ma7, hw_a6, ma5, ma4, hw_a3, ma2, ma1])
            (by simp [ma7, hw_a6, ma5, ma4, hw_a3, ma2, ma1])
            (by simp [ma7, hr_a6, ma5, ma4, hr_a3, ma2, ma1]),
          fun h1 => ⟨by simp [ma7, hw_a6, ma5, ma4, hw_a3, ma2, ma1, h1],
                     by simp [ma7, hr_a6, ma5, ma4, hr_a3, ma2, ma1]⟩,
          fun t ht idx => by simp [ma7, hw_a6, ma5, ma4, hw_a3, ma2, ma1, hw_mo t ht],
          fun idx x y z => by simp [ma7, hw_a6, ma5, ma4, hw_a3, ma2, ma1, hw_m26 idx x y z],
          fun t ht idx => by simp [ma7, hr_a6, ma5, ma4, hr_a3, ma2, ma1, hr_mo t ht],
          fun idx x => by simp [ma7, hr_a6, ma5, ma4, hr_a3, ma2, ma1, hr_m26 idx x],
          fun c => by simpa [ma7] using hua_loc c,
          by simp [ma7, hlv_a6 27 (by decide), ma5, ma4, hwl_a3 27 (by decide), ma2, ma1, hm27_0],
          by simp [ma7, hlv_a6 27 (by decide), ma5, ma4, hwl_a3 27 (by decide), ma2, ma1, hm27_1],
          by simp [ma7, hlv_a6 27 (by decide), ma5, ma4, hwl_a3 27 (by decide), ma2, ma1, hm27_2],
          by simp [ma7, hlv_a6 27 (by decide), ma5, ma4],
          by simp [ma7],
          fun _ _ hb => by omega⟩
      have hStepIn : ∀ b < M_leaf, ∀ mi, InvIn b mi →
          ∃ mi', DetExecAt 1 inp (scanLeafInnerIterStmt d K M_box) mi mi' C_in ∧ InvIn (b + 1) mi' := by
        intro b _ mi ⟨hInv_i, hmono_i, hw_io, hw_i26, hr_io, hr_i26, hua_i,
          hi27_0, hi27_1, hi27_2, hi27_3, hi27_4, hprev_b⟩
        by_cases hcond_prop : b < S_leaf.card ∧ a ≠ b
        · rcases hcond_prop with ⟨hb_lt, hab_ne⟩
          have hab_ne_z : (a : ℤ) ≠ (b : ℤ) := by omega
          have hcond_b : cValAt 1 inp mi
              (.and (.intLt (.readLocal 27 (.lit 4)) (.readLocal 27 (.lit 1)))
                    (.not (.intEq (.readLocal 27 (.lit 2)) (.readLocal 27 (.lit 4))))) = true := by
            simp [hi27_4, hi27_1, hi27_2, hb_lt, hab_ne_z]
          let vb : ℕ := S_leaf.orderEmbOfFin rfl ⟨b, hb_lt⟩
          have hvb_in : vb ∈ S_leaf := S_leaf.orderEmbOfFin_mem rfl ⟨b, hb_lt⟩
          have hvb_act : vb ∈ P.activeHandles := hS_sub hvb_in
          have huavb_ne : ua ≠ vb := by
            intro heq
            have hfin := (S_leaf.orderEmbOfFin rfl).injective heq
            exact hab_ne (congrArg Fin.val hfin)
          let mb1 := wWriteL 1 mi 28 20 (s : ℤ)
          let mb2 := wWriteL 1 mb1 28 21 (b : ℤ)
          have hb1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readLocal 27 (.lit 0))) mi mb1 6 :=
            DetExecAt.writeWordLocal 1 inp mi 28 _ _ rfl (by simp [hi27_0]) (by simp [intExprOps])
          have hb2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readLocal 27 (.lit 4))) mb1 mb2 6 :=
            DetExecAt.writeWordLocal 1 inp mb1 28 _ _ rfl (by simp [mb1, hi27_4]) (by simp [intExprOps])
          have hSeg_mb2 : EncSegSlot K mb2 s S_leaf fSq :=
            hSeg.congr_mem_fSq
              (by simp [mb2, mb1, hw_io 5 (by decide)])
              (fun _ _ => by simp [mb2, mb1, hw_io 8 (by decide)])
              (fun _ _ => by simp [mb2, mb1, hw_io 9 (by decide)])
              (fun _ _ => by simp [mb2, mb1, hw_io 10 (by decide)])
              (fun _ _ => by simp [mb2, mb1, hr_io 8 (by decide)])
              (fun _ _ => rfl)
          rcases exec_selectByRankSegStmt inp mb2 hb_lt (by simp [mb2, mb1]) (by simp [mb2]) hSeg_mb2
            with ⟨mb3, hb3, hsel_b3, hw_b3, hr_b3, hwl_b3, hrl_b3⟩
          let mb4 := wWriteL 1 mb3 27 5 (vb : ℤ)
          let mb5 := wWriteL 1 mb4 29 18 (((vb * d : ℕ) : ℤ))
          have hb4 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 5) (.readLocal 28 (.lit 0))) mb3 mb4 6 :=
            DetExecAt.writeWordLocal 1 inp mb3 27 _ _ rfl (by simp [hsel_b3, vb]) (by simp [intExprOps])
          have hb5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 5)) (.lit (d : ℤ))))
              mb4 mb5 8 :=
            DetExecAt.writeWordLocal 1 inp mb4 29 _ _ rfl (by simp [mb4]) (by simp [intExprOps])
          rcases exec_loadHeapCoordsToLocalStmt inp mb5 (rTag := 4) (idxBase := 18) (destOff := (d : ℤ))
              (base := vb * d) (pt := P.handleCoords vb) (by decide) (by simp [mb5])
              (fun c => by
                simp only [mb5, mb4, rRead_wWriteL, hr_b3, mb2, mb1, hr_io 4 (by decide)]
                exact hLive.2 vb hvb_act c)
            with ⟨mb6, hb6, hvb_loc, hw_b6, hr_b6, _, hrl_b6, hlv_b6, _⟩
          have hua_mb6 : ∀ c : Fin d, rReadL 1 mb6 29 (c.val : ℤ) = euclideanCoord (P.handleCoords ua) c := by
            intro c
            rw [hrl_b6 (c.val : ℤ) (Or.inl (by have := c.isLt; omega))]
            simp [mb5, mb4, hrl_b3, mb2, mb1, hua_i c]
          rcases exec_distSqLocalStmt inp mb6 hua_mb6
              (fun c => by simpa [Nat.cast_add] using hvb_loc c)
            with ⟨mb7, hb7, hdsq_b7, hw_b7, hr_b7, _, hrl_b7, hlv_b7, _⟩
          have hua_mb7 : ∀ c : Fin d, rReadL 1 mb7 29 (c.val : ℤ) = euclideanCoord (P.handleCoords ua) c := by
            intro c
            rw [hrl_b7 (c.val : ℤ) (by have := c.isLt; omega)]
            exact hua_mb6 c
          let mb8 := wWriteL 1 mb7 29 22 (ua : ℤ)
          let mb9 := wWriteL 1 mb8 29 23 (vb : ℤ)
          have hw27_mb7 : ∀ idx, idx ≠ 5 → wReadL 1 mb7 27 idx = wReadL 1 mi 27 idx := by
            intro idx hne5
            simp [hlv_b7 27 (by decide), hlv_b6 27 (by decide), mb5, mb4, hne5,
              hwl_b3 27 (by decide), mb2, mb1]
          have hb8 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 22) (.readLocal 27 (.lit 3))) mb7 mb8 6 :=
            DetExecAt.writeWordLocal 1 inp mb7 29 _ _ rfl
              (by simp [hw27_mb7 3 (by decide), hi27_3]) (by simp [intExprOps])
          have hb9 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 23) (.readLocal 27 (.lit 5))) mb8 mb9 6 :=
            DetExecAt.writeWordLocal 1 inp mb8 29 _ _ rfl
              (by simp [mb8, hlv_b7 27 (by decide), hlv_b6 27 (by decide), mb5, mb4]) (by simp [intExprOps])
          have hInv_mb9 : BestCandInv P mb9 :=
            hInv_i.congr_mem
              (by simp [mb9, mb8, hw_b7, hw_b6, mb5, mb4, hw_b3, mb2, mb1])
              (by simp [mb9, mb8, hw_b7, hw_b6, mb5, mb4, hw_b3, mb2, mb1])
              (by simp [mb9, mb8, hw_b7, hw_b6, mb5, mb4, hw_b3, mb2, mb1])
              (by simp [mb9, mb8, hr_b7, hr_b6, mb5, mb4, hr_b3, mb2, mb1])
          rcases exec_tryUpdateBestCandInnerStmt inp mb9 22 23 (((2 * d : ℕ) : ℤ)) hBox hInv_mb9 hua_act hvb_act
              (by simp [mb9, mb8]) (by simp [mb9]) (by simp only [mb9, mb8, rReadL_wWriteL, hdsq_b7])
            with ⟨mb10, hb10, hInv10, hmono10, hdom10, hw10_o, hw10_26, hr10_o, hr10_26, hwl10, hrl10⟩
          let mb11 := wWriteL 1 mb10 27 4 (((b + 1 : ℕ) : ℤ))
          have hb11 : DetExecAt 1 inp
              (.writeWordLocal 27 (.lit 4) (.add (.readLocal 27 (.lit 4)) (.lit 1))) mb10 mb11 8 :=
            DetExecAt.writeWordLocal 1 inp mb10 27 _ _ rfl
              (by simp [hwl10, mb9, mb8, hw27_mb7 4 (by decide), hi27_4]) (by simp [intExprOps])
          have hmono_mi_10 : wRead mi 26 10 = 1 → wRead mb10 26 10 = 1 ∧ rRead mi 26 10 ≤ rRead mb10 26 10 := by
            intro h1
            have h1_9 : wRead mb9 26 10 = 1 := by simp [mb9, mb8, hw_b7, hw_b6, mb5, mb4, hw_b3, mb2, mb1, h1]
            rcases hmono10 h1_9 with ⟨ha_1, hb_le⟩
            exact ⟨ha_1, by simpa [mb9, mb8, hr_b7, hr_b6, mb5, mb4, hr_b3, mb2, mb1] using hb_le⟩
          refine ⟨mb11,
            ((DetExecAt.ite_true hcond_b (C_c := 15) (by simp [condExprOps, intExprOps])
              (hb1.seq (hb2.seq (hb3.seq (hb4.seq (hb5.seq (hb6.seq (hb7.seq (hb8.seq (hb9.seq hb10)))))))))).seq
                hb11).mono_cost (by dsimp [C_in]; omega),
            hInv10.congr_mem (by simp [mb11]) (by simp [mb11]) (by simp [mb11]) (by simp [mb11]),
            fun h1 => by
              rcases hmono_i h1 with ⟨hi1, hile⟩
              rcases hmono_mi_10 hi1 with ⟨h10_1, h10_le⟩
              exact ⟨by simp [mb11, h10_1], by simpa [mb11] using hile.trans h10_le⟩,
            fun t ht idx => by simp [mb11, hw10_o t ht, mb9, mb8, hw_b7, hw_b6, mb5, mb4, hw_b3, mb2, mb1, hw_io t ht],
            fun idx x y z => by simp [mb11, hw10_26 idx x y z, mb9, mb8, hw_b7, hw_b6, mb5, mb4, hw_b3, mb2, mb1, hw_i26 idx x y z],
            fun t ht idx => by simp [mb11, hr10_o t ht, mb9, mb8, hr_b7, hr_b6, mb5, mb4, hr_b3, mb2, mb1, hr_io t ht],
            fun idx x => by simp [mb11, hr10_26 idx x, mb9, mb8, hr_b7, hr_b6, mb5, mb4, hr_b3, mb2, mb1, hr_i26 idx x],
            fun c => by simpa [mb11, hrl10, mb9, mb8] using hua_mb7 c,
            by simp [mb11, hwl10, mb9, mb8, hw27_mb7 0 (by decide), hi27_0],
            by simp [mb11, hwl10, mb9, mb8, hw27_mb7 1 (by decide), hi27_1],
            by simp [mb11, hwl10, mb9, mb8, hw27_mb7 2 (by decide), hi27_2],
            by simp [mb11, hwl10, mb9, mb8, hw27_mb7 3 (by decide), hi27_3],
            by simp [mb11],
            fun b' hb' hb'_lt hab'_ne => ?_⟩
          rcases Nat.lt_succ_iff_lt_or_eq.mp hb'_lt with hlt | rfl
          · rcases hprev_b b' hb' hlt hab'_ne with ⟨hw_prev, hle_prev⟩
            rcases hmono_mi_10 hw_prev with ⟨hw_now, hle_now⟩
            exact ⟨by simp [mb11, hw_now], by simpa [mb11] using hle_prev.trans hle_now⟩
          · rcases hdom10 huavb_ne with ⟨hw_now, hle_now⟩
            exact ⟨by simp [mb11, hw_now], by simpa [mb11, vb] using hle_now⟩
        · have hcond_b : cValAt 1 inp mi
              (.and (.intLt (.readLocal 27 (.lit 4)) (.readLocal 27 (.lit 1)))
                    (.not (.intEq (.readLocal 27 (.lit 2)) (.readLocal 27 (.lit 4))))) = false := by
            simp only [cValAt_and, cValAt_intLt, cValAt_not, cValAt_intEq, iValAt_readLocal, iValAt_lit,
              hi27_4, hi27_1, hi27_2, Bool.and_eq_false_iff, Bool.not_eq_false', decide_eq_false_iff_not,
              decide_eq_true_eq]
            by_cases h1 : b < S_leaf.card
            · right; have : a = b := Classical.not_not.mp (fun hne => hcond_prop ⟨h1, hne⟩)
              omega
            · left; omega
          let mb1 := wWriteL 1 mi 27 4 (((b + 1 : ℕ) : ℤ))
          have hb1 : DetExecAt 1 inp
              (.writeWordLocal 27 (.lit 4) (.add (.readLocal 27 (.lit 4)) (.lit 1))) mi mb1 8 :=
            DetExecAt.writeWordLocal 1 inp mi 27 _ _ rfl (by simp [hi27_4]) (by simp [intExprOps])
          refine ⟨mb1,
            ((DetExecAt.ite_false hcond_b (C_c := 15) (by simp [condExprOps, intExprOps])
              (DetExecAt.skip 1 inp mi)).seq hb1).mono_cost (by dsimp [C_in]; omega),
            hInv_i.congr_mem (by simp [mb1]) (by simp [mb1]) (by simp [mb1]) (by simp [mb1]),
            fun h1 => ⟨by simp [mb1, (hmono_i h1).1], by simpa [mb1] using (hmono_i h1).2⟩,
            fun t ht idx => by simp [mb1, hw_io t ht],
            fun idx x y z => by simp [mb1, hw_i26 idx x y z],
            fun t ht idx => by simp [mb1, hr_io t ht],
            fun idx x => by simp [mb1, hr_i26 idx x],
            fun c => by simpa [mb1] using hua_i c,
            by simp [mb1, hi27_0],
            by simp [mb1, hi27_1],
            by simp [mb1, hi27_2],
            by simp [mb1, hi27_3],
            by simp [mb1],
            fun b' hb' hb'_lt hab'_ne => ?_⟩
          rcases Nat.lt_succ_iff_lt_or_eq.mp hb'_lt with hlt | rfl
          · rcases hprev_b b' hb' hlt hab'_ne with ⟨hw_p, hle_p⟩
            exact ⟨by simp [mb1, hw_p], by simpa [mb1] using hle_p⟩
          · exact False.elim (hcond_prop ⟨hb', hab'_ne⟩)
      rcases DetExecAt.repeatN_nat (.lit (M_leaf : ℤ)) _ M_leaf 4 C_in InvIn hInvIn0 rfl
          (by simp [intExprOps]) hStepIn
        with ⟨miN, ⟨hInv_N, hmono_N, hw_No, hw_N26, hr_No, hr_N26, _,
          hN27_0, hN27_1, hN27_2, _, _, hdom_bN⟩, hrepIn⟩
      let ma8 := wWriteL 1 miN 27 2 (((a + 1 : ℕ) : ℤ))
      have ha8 : DetExecAt 1 inp
          (.writeWordLocal 27 (.lit 2) (.add (.readLocal 27 (.lit 2)) (.lit 1))) miN ma8 8 :=
        DetExecAt.writeWordLocal 1 inp miN 27 _ _ rfl (by simp [hN27_2]) (by simp [intExprOps])
      refine ⟨ma8,
        ((DetExecAt.ite_true hcond_a (C_c := 10) (by simp [condExprOps, intExprOps])
          (ha1.seq (ha2.seq (ha3.seq (ha4.seq (ha5.seq (ha6.seq (ha7.seq hrepIn)))))))).seq ha8).mono_cost
          (by
            dsimp [C_out, C_in]
            have hmul : M_leaf * (260 * (K + d + 5)) ≤ 260 * M_leaf * (K + d + 5) := by ring_nf; exact le_rfl
            have hexp : 320 * (M_leaf + 1) * (K + d + 5) =
                260 * M_leaf * (K + d + 5) + 60 * M_leaf * (K + d + 5) + 320 * (K + d + 5) := by ring
            omega),
        hInv_N.congr_mem (by simp [ma8]) (by simp [ma8]) (by simp [ma8]) (by simp [ma8]),
        fun h1 => by
          rcases hmono_m h1 with ⟨hm1, hmle⟩
          rcases hmono_N hm1 with ⟨hN1, hNle⟩
          exact ⟨by simp [ma8, hN1], by simpa [ma8] using hmle.trans hNle⟩,
        fun t ht idx => by simp [ma8, hw_No t ht],
        fun idx x y z => by simp [ma8, hw_N26 idx x y z],
        fun t ht idx => by simp [ma8, hr_No t ht],
        fun idx x => by simp [ma8, hr_N26 idx x],
        by simp [ma8, hN27_0],
        by simp [ma8, hN27_1],
        by simp [ma8],
        fun a' ha' ha'_lt b' hb' hab'_ne => ?_⟩
      rcases Nat.lt_succ_iff_lt_or_eq.mp ha'_lt with hlt | rfl
      · rcases hprev_a a' ha' hlt b' hb' hab'_ne with ⟨hw_p, hle_p⟩
        rcases hmono_N hw_p with ⟨hw_n, hle_n⟩
        exact ⟨by simp [ma8, hw_n], by simpa [ma8] using hle_p.trans hle_n⟩
      · have hb'_M : b' < M_leaf := lt_of_lt_of_le hb' hS_le
        rcases hdom_bN b' hb' hb'_M hab'_ne with ⟨hw_n, hle_n⟩
        exact ⟨by simp [ma8, hw_n], by simpa [ma8, ua] using hle_n⟩
    · have hcond_a : cValAt 1 inp m (.intLt (.readLocal 27 (.lit 2)) (.readLocal 27 (.lit 1))) = false := by
        simp [hm27_2, hm27_1, ha_lt]
      let ma1 := wWriteL 1 m 27 2 (((a + 1 : ℕ) : ℤ))
      have ha1 : DetExecAt 1 inp
          (.writeWordLocal 27 (.lit 2) (.add (.readLocal 27 (.lit 2)) (.lit 1))) m ma1 8 :=
        DetExecAt.writeWordLocal 1 inp m 27 _ _ rfl (by simp [hm27_2]) (by simp [intExprOps])
      refine ⟨ma1,
        ((DetExecAt.ite_false hcond_a (C_c := 10) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 1 inp m)).seq ha1).mono_cost (by dsimp [C_out]; exact le_trans (by omega : 10 + 1 + 8 ≤ 320 * 1 * 5) (Nat.mul_le_mul (Nat.mul_le_mul_left _ (by omega)) (by omega))),
        hInv_m.congr_mem (by simp [ma1]) (by simp [ma1]) (by simp [ma1]) (by simp [ma1]),
        fun h1 => ⟨by simp [ma1, (hmono_m h1).1], by simpa [ma1] using (hmono_m h1).2⟩,
        fun t ht idx => by simp [ma1, hw_mo t ht],
        fun idx x y z => by simp [ma1, hw_m26 idx x y z],
        fun t ht idx => by simp [ma1, hr_mo t ht],
        fun idx x => by simp [ma1, hr_m26 idx x],
        by simp [ma1, hm27_0],
        by simp [ma1, hm27_1],
        by simp [ma1],
        fun a' ha' ha'_lt b' hb' hab'_ne => ?_⟩
      rcases Nat.lt_succ_iff_lt_or_eq.mp ha'_lt with hlt | rfl
      · rcases hprev_a a' ha' hlt b' hb' hab'_ne with ⟨hw_p, hle_p⟩
        exact ⟨by simp [ma1, hw_p], by simpa [ma1] using hle_p⟩
      · exact False.elim (ha_lt ha')
  rcases DetExecAt.repeatN_nat (.lit (M_leaf : ℤ)) _ M_leaf 4 C_out InvOut hInvOut0 rfl
      (by simp [intExprOps]) hStepOut
    with ⟨mOut, ⟨hInv_end, hmono_end, hw_eo, hw_e26, hr_eo, hr_e26, _, _, _, hdom_end⟩, hrepOut⟩
  refine ⟨mOut.popDepth 0,
    DetExecAt.localScope ((hs1.seq (hs2.seq (hs3.seq (hs4.seq hrepOut)))).mono_cost (by
      simp only [intExprOps, C_out]
      have hmul : M_leaf * (320 * (M_leaf + 1) * (K + d + 5)) =
          320 * M_leaf * (M_leaf + 1) * (K + d + 5) := by ring
      have hexp : 350 * (M_leaf + 1) * (M_leaf + 1) * (K + d + 5) =
          320 * M_leaf * (M_leaf + 1) * (K + d + 5) +
          30 * M_leaf * (M_leaf + 1) * (K + d + 5) +
          350 * (M_leaf + 1) * (K + d + 5) := by ring
      omega)),
    popDepth_zero_idem mOut,
    hInv_end.congr_mem (by simp) (by simp) (by simp) (by simp),
    fun h1 => ⟨by simp [(hmono_end h1).1], by simpa using (hmono_end h1).2⟩,
    fun t ht idx => by simp [hw_eo t ht],
    fun idx x y z => by simp [hw_e26 idx x y z],
    fun t ht idx => by simp [hr_eo t ht],
    fun idx x => by simp [hr_e26 idx x],
    fun a ha b hb hab => ?_⟩
  have ha_M : a < M_leaf := lt_of_lt_of_le ha hS_le
  rcases hdom_end a ha ha_M b hb hab with ⟨hw_e, hle_e⟩
  exact ⟨by simp [hw_e], by simpa using hle_e⟩

/-! ### 5. Fallback Active Pair + Cached Answer Commit (`finalizeStepAnswerStmt`) -/

def finalizeStepAnswerStmt (d K M_box : ℕ) : ArithRAMStmt :=
  .localScope (
    .ite (.intLe (.readHeap 1 (.lit 2)) (.lit 1))
      (seqList [
        boxWriteW M_box 0 (.lit 1) (.lit 0),
        boxWriteW M_box 0 (.lit 2) (.lit 0),
        boxWriteW M_box 0 (.lit 3) (.lit 0),
        boxWriteR M_box 0 (.lit 0) (.ofInt (.lit 0))
      ])
      (seqList [
        .writeWordLocal 28 (.lit 20) (.lit 0),
        .writeWordLocal 28 (.lit 21) (.lit 0),
        selectByRankSegStmt K,
        .writeWordLocal 27 (.lit 0) (.readLocal 28 (.lit 0)),
        .writeWordLocal 28 (.lit 20) (.lit 0),
        .writeWordLocal 28 (.lit 21) (.lit 1),
        selectByRankSegStmt K,
        .writeWordLocal 27 (.lit 1) (.readLocal 28 (.lit 0)),
        .writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 0)) (.lit (d : ℤ))),
        loadHeapCoordsToLocalStmt d 4 18 0,
        .writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 1)) (.lit (d : ℤ))),
        loadHeapCoordsToLocalStmt d 4 18 (d : ℤ),
        distSqLocalStmt d,
        .writeWordLocal 29 (.lit 22) (.readLocal 27 (.lit 0)),
        .writeWordLocal 29 (.lit 23) (.readLocal 27 (.lit 1)),
        tryUpdateBestCandInnerStmt M_box 22 23 (((2 * d : ℕ) : ℤ)),
        boxWriteW M_box 0 (.lit 1) (.lit 1),
        boxWriteW M_box 0 (.lit 2) (.readHeap 26 (.lit 11)),
        boxWriteW M_box 0 (.lit 3) (.readHeap 26 (.lit 12)),
        boxWriteR M_box 0 (.lit 0) (.readRealHeap 26 (.lit 10))
      ])
  )

theorem boxSafe_finalizeStepAnswerStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (d K : ℕ) :
    BoxSafeOuter T_max M_box (finalizeStepAnswerStmt d K M_box) := by
  refine .localScope (.ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_))
  · intro s hs
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl | rfl
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxR (by omega) _ _
  · intro s hs
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
      rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_selectByRankSegStmt _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_selectByRankSegStmt _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
    · exact boxSafe_distSqLocalStmt _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_tryUpdateBestCandInnerStmt hT _ _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxR (by omega) _ _

theorem exec_finalizeStepAnswerStmt {d n K M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {P : DynamicPointSet d} {fSq0 : ℕ → ℝ}
    (hP : P.WellFormed n)
    (hcard_reg : wRead mem 1 2 = (P.activeHandles.card : ℤ))
    (hBox : 13 ≤ M_box)
    (hInv : BestCandInv P mem)
    (hLive : EncLiveCoords d n mem P.activeHandles P.handleCoords)
    (hSeg0 : EncSegSlot K mem 0 P.activeHandles fSq0) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (finalizeStepAnswerStmt d K M_box) mem m'
        (250 * (K + d + 5) + 300) ∧
      m'.popDepth 0 = m' ∧
      wRead m' 0 0 = wRead mem 0 0 ∧
      (∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx) ∧
      (P.activeIds.card ≤ 1 →
        IsValidFactorCAnswer (Real.sqrt 2) P (readStoredAns m')) ∧
      (2 ≤ P.activeIds.card →
        ∃ bestH1 bestH2 : ℕ,
          bestH1 ∈ P.activeHandles ∧
          bestH2 ∈ P.activeHandles ∧
          bestH1 ≠ bestH2 ∧
          readStoredAns m' =
            { diameterHandles := some (bestH1, bestH2)
              cachedDistSq := euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2) } ∧
          (wRead mem 26 10 = 1 →
            rRead mem 26 10 ≤ euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2))) := by
  have hcard_eq := activeHandles_card_eq_activeIds_card hP
  let m0 := mem.popDepth 0
  by_cases hle1 : P.activeHandles.card ≤ 1
  · have hcond : cValAt 1 inp m0 (.intLe (.readHeap 1 (.lit 2)) (.lit 1)) = true := by
      simp [m0, hcard_reg, hle1]
    let m1 := wWrite m0 0 1 0
    let m2 := wWrite m1 0 2 0
    let m3 := wWrite m2 0 3 0
    let m4 := rWrite m3 0 0 0
    have hs1 : DetExecAt 1 inp (boxWriteW M_box 0 (.lit 1) (.lit 0)) m0 m1 14 :=
      exec_boxWriteW inp m0 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
    have hs2 : DetExecAt 1 inp (boxWriteW M_box 0 (.lit 2) (.lit 0)) m1 m2 14 :=
      exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
    have hs3 : DetExecAt 1 inp (boxWriteW M_box 0 (.lit 3) (.lit 0)) m2 m3 14 :=
      exec_boxWriteW inp m2 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
    have hs4 : DetExecAt 1 inp (boxWriteR M_box 0 (.lit 0) (.ofInt (.lit 0))) m3 m4 14 :=
      exec_boxWriteR inp m3 _ _ rfl (by omega) (by omega) (by simp) (by simp [intExprOps, realExprOps])
    refine ⟨m4.popDepth 0,
      DetExecAt.localScope
        ((DetExecAt.ite_true hcond (C_c := 10) (by simp [condExprOps, intExprOps])
          (hs1.seq (hs2.seq (hs3.seq hs4)))).mono_cost (by omega)),
      popDepth_zero_idem m4,
      by simp [m4, m3, m2, m1, m0],
      fun t ht0 _ idx => by simp [m4, m3, m2, m1, m0, ht0],
      fun t ht0 _ idx => by simp [m4, m3, m2, m1, m0, ht0],
      fun hids_le1 => ?_,
      fun hids_ge2 => by omega⟩
    unfold IsValidFactorCAnswer
    simp only [hids_le1, ↓reduceIte]
    have hw01 : (m4.popDepth 0).words.read (.heap 0 1) = 0 := by
      change wRead (m4.popDepth 0) 0 1 = 0
      simp [m4, m3, m2, m1]
    have hr00 : (m4.popDepth 0).reals.read (.heap 0 0) = 0 := by
      change rRead (m4.popDepth 0) 0 0 = 0
      simp [m4]
    simp [readStoredAns, ArithRAMDynamicProgram.readCachedAnswer, hw01, hr00]
  · have hge2 : 2 ≤ P.activeHandles.card := by omega
    have hcond : cValAt 1 inp m0 (.intLe (.readHeap 1 (.lit 2)) (.lit 1)) = false := by
      simp [m0, hcard_reg]; omega
    have h0_lt : 0 < P.activeHandles.card := by omega
    have h1_lt : 1 < P.activeHandles.card := by omega
    let u0 : ℕ := P.activeHandles.orderEmbOfFin rfl ⟨0, h0_lt⟩
    let u1 : ℕ := P.activeHandles.orderEmbOfFin rfl ⟨1, h1_lt⟩
    have hu0_act : u0 ∈ P.activeHandles := P.activeHandles.orderEmbOfFin_mem rfl _
    have hu1_act : u1 ∈ P.activeHandles := P.activeHandles.orderEmbOfFin_mem rfl _
    have hu01_ne : u0 ≠ u1 := by
      intro heq
      have hfin := (P.activeHandles.orderEmbOfFin rfl).injective heq
      have hval : (0 : ℕ) = 1 := congrArg Fin.val hfin
      omega
    let ms1 := wWriteL 1 m0 28 20 0
    let ms2 := wWriteL 1 ms1 28 21 0
    have ha1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.lit 0)) m0 ms1 4 :=
      DetExecAt.writeWordLocal 1 inp m0 28 _ _ rfl rfl (by simp [intExprOps])
    have ha2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.lit 0)) ms1 ms2 4 :=
      DetExecAt.writeWordLocal 1 inp ms1 28 _ _ rfl rfl (by simp [intExprOps])
    have hSeg_ms2 : EncSegSlot K ms2 0 P.activeHandles fSq0 :=
      hSeg0.congr_mem_fSq (by simp [ms2, ms1, m0]) (fun _ _ => by simp [ms2, ms1, m0])
        (fun _ _ => by simp [ms2, ms1, m0]) (fun _ _ => by simp [ms2, ms1, m0])
        (fun _ _ => by simp [ms2, ms1, m0]) (fun _ _ => rfl)
    rcases exec_selectByRankSegStmt inp ms2 h0_lt (by simp [ms2, ms1]) (by simp [ms2]) hSeg_ms2
      with ⟨ms3, ha3, hsel0, hw_s3, hr_s3, _, _⟩
    let ms4 := wWriteL 1 ms3 27 0 (u0 : ℤ)
    let ms5 := wWriteL 1 ms4 28 20 0
    let ms6 := wWriteL 1 ms5 28 21 1
    have ha4 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 0) (.readLocal 28 (.lit 0))) ms3 ms4 6 :=
      DetExecAt.writeWordLocal 1 inp ms3 27 _ _ rfl (by simp [hsel0, u0]) (by simp [intExprOps])
    have ha5 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.lit 0)) ms4 ms5 4 :=
      DetExecAt.writeWordLocal 1 inp ms4 28 _ _ rfl rfl (by simp [intExprOps])
    have ha6 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.lit 1)) ms5 ms6 4 :=
      DetExecAt.writeWordLocal 1 inp ms5 28 _ _ rfl rfl (by simp [intExprOps])
    have hSeg_ms6 : EncSegSlot K ms6 0 P.activeHandles fSq0 :=
      hSeg0.congr_mem_fSq
        (by simp [ms6, ms5, ms4, hw_s3, ms2, ms1, m0])
        (fun _ _ => by simp [ms6, ms5, ms4, hw_s3, ms2, ms1, m0])
        (fun _ _ => by simp [ms6, ms5, ms4, hw_s3, ms2, ms1, m0])
        (fun _ _ => by simp [ms6, ms5, ms4, hw_s3, ms2, ms1, m0])
        (fun _ _ => by simp [ms6, ms5, ms4, hr_s3, ms2, ms1, m0])
        (fun _ _ => rfl)
    rcases exec_selectByRankSegStmt inp ms6 h1_lt (by simp [ms6, ms5]) (by simp [ms6]) hSeg_ms6
      with ⟨ms7, ha7, hsel1, hw_s7, hr_s7, hwl_s7, _⟩
    let ms8 := wWriteL 1 ms7 27 1 (u1 : ℤ)
    let ms9 := wWriteL 1 ms8 29 18 (((u0 * d : ℕ) : ℤ))
    have ha8 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 1) (.readLocal 28 (.lit 0))) ms7 ms8 6 :=
      DetExecAt.writeWordLocal 1 inp ms7 27 _ _ rfl (by simp [hsel1, u1]) (by simp [intExprOps])
    have ha9 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 0)) (.lit (d : ℤ))))
        ms8 ms9 8 :=
      DetExecAt.writeWordLocal 1 inp ms8 29 _ _ rfl
        (by simp [ms8, hwl_s7 27 (by decide), ms6, ms5, ms4]) (by simp [intExprOps])
    rcases exec_loadHeapCoordsToLocalStmt inp ms9 (rTag := 4) (idxBase := 18) (destOff := 0)
        (base := u0 * d) (pt := P.handleCoords u0) (by decide) (by simp [ms9])
        (fun c => by
          simp only [ms9, ms8, rRead_wWriteL, hr_s7, ms6, ms5, ms4, hr_s3, ms2, ms1, m0, rRead_popDepth]
          exact hLive.2 u0 hu0_act c)
      with ⟨ms10, ha10, hu0_loc, hw_s10, hr_s10, _, _, hlv_s10, _⟩
    let ms11 := wWriteL 1 ms10 29 18 (((u1 * d : ℕ) : ℤ))
    have ha11 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readLocal 27 (.lit 1)) (.lit (d : ℤ))))
        ms10 ms11 8 :=
      DetExecAt.writeWordLocal 1 inp ms10 29 _ _ rfl
        (by simp [hlv_s10 27 (by decide), ms9, ms8]) (by simp [intExprOps])
    rcases exec_loadHeapCoordsToLocalStmt inp ms11 (rTag := 4) (idxBase := 18) (destOff := (d : ℤ))
        (base := u1 * d) (pt := P.handleCoords u1) (by decide) (by simp [ms11])
        (fun c => by
          simp only [ms11, rRead_wWriteL, hr_s10, ms9, ms8, hr_s7, ms6, ms5, ms4, hr_s3, ms2, ms1, m0, rRead_popDepth]
          exact hLive.2 u1 hu1_act c)
      with ⟨ms12, ha12, hu1_loc, hw_s12, hr_s12, _, hrl_s12, hlv_s12, _⟩
    have hu0_ms12 : ∀ c : Fin d, rReadL 1 ms12 29 (c.val : ℤ) = euclideanCoord (P.handleCoords u0) c := by
      intro c
      rw [hrl_s12 (c.val : ℤ) (Or.inl (by have := c.isLt; omega))]
      simpa [ms11] using hu0_loc c
    rcases exec_distSqLocalStmt inp ms12 hu0_ms12
        (fun c => by simpa [Nat.cast_add] using hu1_loc c)
      with ⟨ms13, ha13, hdsq_13, hw_s13, hr_s13, _, _, hlv_s13, _⟩
    let ms14 := wWriteL 1 ms13 29 22 (u0 : ℤ)
    let ms15 := wWriteL 1 ms14 29 23 (u1 : ℤ)
    have ha14 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 22) (.readLocal 27 (.lit 0))) ms13 ms14 6 :=
      DetExecAt.writeWordLocal 1 inp ms13 29 _ _ rfl
        (by simp [hlv_s13 27 (by decide), hlv_s12 27 (by decide), ms11, hlv_s10 27 (by decide),
          ms9, ms8, hwl_s7 27 (by decide), ms6, ms5, ms4]) (by simp [intExprOps])
    have ha15 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 23) (.readLocal 27 (.lit 1))) ms14 ms15 6 :=
      DetExecAt.writeWordLocal 1 inp ms14 29 _ _ rfl
        (by simp [ms14, hlv_s13 27 (by decide), hlv_s12 27 (by decide), ms11, hlv_s10 27 (by decide),
          ms9, ms8]) (by simp [intExprOps])
    have hw_ms15 : ∀ t idx, wRead ms15 t idx = wRead mem t idx := by
      intro t idx
      simp [ms15, ms14, hw_s13, hw_s12, ms11, hw_s10, ms9, ms8, hw_s7, ms6, ms5, ms4, hw_s3, ms2, ms1, m0]
    have hr_ms15 : ∀ t idx, rRead ms15 t idx = rRead mem t idx := by
      intro t idx
      simp [ms15, ms14, hr_s13, hr_s12, ms11, hr_s10, ms9, ms8, hr_s7, ms6, ms5, ms4, hr_s3, ms2, ms1, m0]
    have hInv_15 : BestCandInv P ms15 :=
      hInv.congr_mem (hw_ms15 26 10) (hw_ms15 26 11) (hw_ms15 26 12) (hr_ms15 26 10)
    rcases exec_tryUpdateBestCandInnerStmt inp ms15 22 23 (((2 * d : ℕ) : ℤ)) hBox hInv_15 hu0_act hu1_act
        (by simp [ms15, ms14]) (by simp [ms15]) (by simp only [ms15, ms14, rReadL_wWriteL, hdsq_13])
      with ⟨ms16, ha16, hInv16, hmono16, hdom16, hw16_o, _, hr16_o, _, _, _⟩
    rcases hdom16 hu01_ne with ⟨hw16_10, _⟩
    rcases hInv16 with h0_16 | ⟨_, bestH1, bestH2, hb1_act, hb2_act, hb_ne, hb1_reg, hb2_reg, hbsq_reg⟩
    · omega
    let ms17 := wWrite ms16 0 1 1
    let ms18 := wWrite ms17 0 2 (bestH1 : ℤ)
    let ms19 := wWrite ms18 0 3 (bestH2 : ℤ)
    let ms20 := rWrite ms19 0 0 (euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2))
    have ha17 : DetExecAt 1 inp (boxWriteW M_box 0 (.lit 1) (.lit 1)) ms16 ms17 14 :=
      exec_boxWriteW inp ms16 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
    have ha18 : DetExecAt 1 inp (boxWriteW M_box 0 (.lit 2) (.readHeap 26 (.lit 11))) ms17 ms18 16 :=
      exec_boxWriteW inp ms17 _ _ rfl (by omega) (by omega) (by simp [ms17, hb1_reg]) (by simp [intExprOps])
    have ha19 : DetExecAt 1 inp (boxWriteW M_box 0 (.lit 3) (.readHeap 26 (.lit 12))) ms18 ms19 16 :=
      exec_boxWriteW inp ms18 _ _ rfl (by omega) (by omega) (by simp [ms18, ms17, hb2_reg]) (by simp [intExprOps])
    have ha20 : DetExecAt 1 inp (boxWriteR M_box 0 (.lit 0) (.readRealHeap 26 (.lit 10))) ms19 ms20 16 :=
      exec_boxWriteR inp ms19 _ _ rfl (by omega) (by omega)
        (by simp [ms19, ms18, ms17, hbsq_reg]) (by simp [intExprOps, realExprOps])
    refine ⟨ms20.popDepth 0,
      DetExecAt.localScope
        ((DetExecAt.ite_false hcond (C_c := 10) (by simp [condExprOps, intExprOps])
          (ha1.seq (ha2.seq (ha3.seq (ha4.seq (ha5.seq (ha6.seq (ha7.seq (ha8.seq
            (ha9.seq (ha10.seq (ha11.seq (ha12.seq (ha13.seq (ha14.seq (ha15.seq
              (ha16.seq (ha17.seq (ha18.seq (ha19.seq ha20)))))))))))))))))))).mono_cost (by omega)),
      popDepth_zero_idem ms20,
      by simp [ms20, ms19, ms18, ms17, hw16_o 0 (by decide), hw_ms15],
      fun t ht0 ht26 idx => by simp [ms20, ms19, ms18, ms17, ht0, hw16_o t ht26, hw_ms15],
      fun t ht0 ht26 idx => by simp [ms20, ms19, ms18, ms17, ht0, hr16_o t ht26, hr_ms15],
      fun hids_le1 => by omega,
      fun _ => ⟨bestH1, bestH2, hb1_act, hb2_act, hb_ne, ?_, fun h1_mem => ?_⟩⟩
    · have hw01 : (ms20.popDepth 0).words.read (.heap 0 1) = 1 := by
        change wRead (ms20.popDepth 0) 0 1 = 1; simp [ms20, ms19, ms18, ms17]
      have hw02 : (ms20.popDepth 0).words.read (.heap 0 2) = (bestH1 : ℤ) := by
        change wRead (ms20.popDepth 0) 0 2 = (bestH1 : ℤ); simp [ms20, ms19, ms18]
      have hw03 : (ms20.popDepth 0).words.read (.heap 0 3) = (bestH2 : ℤ) := by
        change wRead (ms20.popDepth 0) 0 3 = (bestH2 : ℤ); simp [ms20, ms19]
      have hr00 : (ms20.popDepth 0).reals.read (.heap 0 0) =
          euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2) := by
        change rRead (ms20.popDepth 0) 0 0 = _; simp [ms20]
      simp [readStoredAns, ArithRAMDynamicProgram.readCachedAnswer, hw01, hw02, hw03, hr00]
    · have h1_15 : wRead ms15 26 10 = 1 := by rw [hw_ms15]; exact h1_mem
      rcases hmono16 h1_15 with ⟨_, hle⟩
      rw [hr_ms15, hbsq_reg] at hle
      exact hle

end UL.Proof_lem_7_2_RacerP46
