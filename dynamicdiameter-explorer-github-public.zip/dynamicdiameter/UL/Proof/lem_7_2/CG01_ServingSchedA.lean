import UL.Proof.lem_7_2.CG01_H4a2d

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Pure `chainInput` / `chainTerminal` Prefix, Splice, Append, and Routing Step Lemmas -/

lemma cg01_chainInput_zero {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι) :
    chainInput pts nodes S₀ ⟨0, Nat.zero_lt_succ k⟩ = S₀ :=
  rfl

lemma cg01_chainInput_succ {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι)
    (m : ℕ) (hm : m < k) :
    chainInput pts nodes S₀ ⟨m + 1, Nat.succ_lt_succ hm⟩ =
      (nodes ⟨m, hm⟩).residual pts (chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_lt hm⟩) :=
  rfl

lemma cg01_chainTerminal_eq {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι) :
    chainTerminal pts nodes S₀ = chainInput pts nodes S₀ ⟨k, Nat.lt_succ_self k⟩ :=
  rfl

lemma cg01_chainInput_subset_aux {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι) :
    ∀ (m : ℕ) (hm : m ≤ k),
      chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm⟩ ⊆ S₀
  | 0, _ => Finset.Subset.refl S₀
  | m + 1, hm => by
      have hm_lt : m < k := Nat.lt_of_succ_le hm
      rw [cg01_chainInput_succ pts nodes S₀ m hm_lt]
      exact (nodeResidual_subset pts (nodes ⟨m, hm_lt⟩) _).trans
        (cg01_chainInput_subset_aux pts nodes S₀ m (Nat.le_of_succ_le hm))

lemma cg01_chainInput_subset {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι)
    (j : Fin (k + 1)) :
    chainInput pts nodes S₀ j ⊆ S₀ :=
  cg01_chainInput_subset_aux pts nodes S₀ j.val (Nat.lt_succ_iff.mp j.isLt)

lemma cg01_chainTerminal_subset {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι) :
    chainTerminal pts nodes S₀ ⊆ S₀ :=
  cg01_chainInput_subset pts nodes S₀ (Fin.last k)

/-- Prefix invariance of `chainInput`: if two chains `nodes₁ : Fin k₁ → ChainNode d` and
`nodes₂ : Fin k₂ → ChainNode d` agree on all indices `< m` (`m ≤ k₁`, `m ≤ k₂`), then their
`m`-th input sets coincide. -/
lemma cg01_chainInput_congr_prefix {d k₁ k₂ : ℕ} {ι : Type}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    (nodes₁ : Fin k₁ → ChainNode d) (nodes₂ : Fin k₂ → ChainNode d)
    {S₀ : Finset ι}
    (hpts : ∀ x ∈ S₀, pts₁ x = pts₂ x) :
    ∀ (m : ℕ) (hm₁ : m ≤ k₁) (hm₂ : m ≤ k₂),
      (∀ i (hi : i < m), nodes₁ ⟨i, lt_of_lt_of_le hi hm₁⟩ = nodes₂ ⟨i, lt_of_lt_of_le hi hm₂⟩) →
      chainInput pts₁ nodes₁ S₀ ⟨m, Nat.lt_succ_of_le hm₁⟩ =
        chainInput pts₂ nodes₂ S₀ ⟨m, Nat.lt_succ_of_le hm₂⟩
  | 0, _, _, _ => rfl
  | m + 1, hm₁, hm₂, hnod => by
      have hlt₁ : m < k₁ := Nat.lt_of_succ_le hm₁
      have hlt₂ : m < k₂ := Nat.lt_of_succ_le hm₂
      have hle₁ : m ≤ k₁ := Nat.le_of_succ_le hm₁
      have hle₂ : m ≤ k₂ := Nat.le_of_succ_le hm₂
      have ih := cg01_chainInput_congr_prefix nodes₁ nodes₂ hpts m hle₁ hle₂
        (fun i hi => hnod i (Nat.lt_succ_of_lt hi))
      have hnm : nodes₁ ⟨m, hlt₁⟩ = nodes₂ ⟨m, hlt₂⟩ := hnod m (Nat.lt_succ_self m)
      rw [cg01_chainInput_succ pts₁ nodes₁ S₀ m hlt₁,
          cg01_chainInput_succ pts₂ nodes₂ S₀ m hlt₂, hnm, ih]
      exact nodeResidual_congr_on (nodes₂ ⟨m, hlt₂⟩) _
        (fun x hx => hpts x (cg01_chainInput_subset_aux pts₂ nodes₂ S₀ m hle₂ hx))

/-- Suffix `prefixResidual` identity when splicing `lvs` at serving index `r_cut ≤ k`. -/
lemma cg01_chainInput_splice_suffix {d k r_cut : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (nodes : Fin k → ChainNode d)
    (lvs : List (OpenedJobLevel d ι))
    (hr_le : r_cut ≤ k)
    (nodes' : Fin (r_cut + lvs.length) → ChainNode d)
    (hpre : ∀ i (hi : i < r_cut),
      nodes' ⟨i, lt_of_lt_of_le hi (Nat.le_add_right _ _)⟩ = nodes ⟨i, lt_of_lt_of_le hi hr_le⟩)
    (hsuf : ∀ j (hj : j < lvs.length),
      nodes' ⟨r_cut + j, Nat.add_lt_add_left hj r_cut⟩ = (lvs[j]'hj).ball)
    (S₀ : Finset ι) :
    ∀ (j : ℕ) (hj : j ≤ lvs.length),
      chainInput pts nodes' S₀ ⟨r_cut + j, Nat.lt_succ_of_le (Nat.add_le_add_left hj r_cut)⟩ =
        prefixResidual pts (lvs.take j) (chainInput pts nodes S₀ ⟨r_cut, Nat.lt_succ_of_le hr_le⟩)
  | 0, _ => by
      simp only [Nat.add_zero, List.take_zero]
      rw [prefixResidual_nil]
      exact cg01_chainInput_congr_prefix nodes' nodes (fun _ _ => rfl)
        r_cut (Nat.le_add_right _ _) hr_le hpre
  | j + 1, hj => by
      have hj_lt : j < lvs.length := Nat.lt_of_succ_le hj
      have hj_le : j ≤ lvs.length := Nat.le_of_succ_le hj
      have hidx_lt : r_cut + j < r_cut + lvs.length := Nat.add_lt_add_left hj_lt r_cut
      have hadd_eq : (⟨r_cut + (j + 1), Nat.lt_succ_of_le (Nat.add_le_add_left hj r_cut)⟩ :
          Fin (r_cut + lvs.length + 1)) = ⟨(r_cut + j) + 1, Nat.succ_lt_succ hidx_lt⟩ := by
        ext; dsimp; omega
      rw [hadd_eq, cg01_chainInput_succ pts nodes' S₀ (r_cut + j) hidx_lt,
          hsuf j hj_lt,
          cg01_chainInput_splice_suffix pts nodes lvs hr_le nodes' hpre hsuf S₀ j hj_le,
          List.take_succ_eq_append_getElem hj_lt, prefixResidual_append_singleton]

lemma cg01_chainTerminal_splice {d k r_cut : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (nodes : Fin k → ChainNode d)
    (lvs : List (OpenedJobLevel d ι))
    (hr_le : r_cut ≤ k)
    (nodes' : Fin (r_cut + lvs.length) → ChainNode d)
    (hpre : ∀ i (hi : i < r_cut),
      nodes' ⟨i, lt_of_lt_of_le hi (Nat.le_add_right _ _)⟩ = nodes ⟨i, lt_of_lt_of_le hi hr_le⟩)
    (hsuf : ∀ j (hj : j < lvs.length),
      nodes' ⟨r_cut + j, Nat.add_lt_add_left hj r_cut⟩ = (lvs[j]'hj).ball)
    (S₀ : Finset ι) :
    chainTerminal pts nodes' S₀ =
      prefixResidual pts lvs (chainInput pts nodes S₀ ⟨r_cut, Nat.lt_succ_of_le hr_le⟩) := by
  rw [cg01_chainTerminal_eq]
  have h := cg01_chainInput_splice_suffix pts nodes lvs hr_le nodes' hpre hsuf S₀ lvs.length le_rfl
  rwa [List.take_length] at h

/-- Non-dependent append of a single `ChainNode d` at index `k`. -/
def appendChainNode {d k : ℕ} (nodes : Fin k → ChainNode d) (B : ChainNode d) :
    Fin (k + 1) → ChainNode d :=
  fun i => if h : i.val < k then nodes ⟨i.val, h⟩ else B

lemma appendChainNode_lt {d k : ℕ} (nodes : Fin k → ChainNode d) (B : ChainNode d)
    {m : ℕ} (hm : m < k) :
    appendChainNode nodes B ⟨m, Nat.lt_succ_of_lt hm⟩ = nodes ⟨m, hm⟩ :=
  dif_pos hm

lemma appendChainNode_last {d k : ℕ} (nodes : Fin k → ChainNode d) (B : ChainNode d) :
    appendChainNode nodes B ⟨k, Nat.lt_succ_self k⟩ = B :=
  dif_neg (Nat.lt_irrefl k)

lemma cg01_chainInput_append_lt {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (nodes : Fin k → ChainNode d) (B : ChainNode d) (S₀ : Finset ι)
    (m : ℕ) (hm : m ≤ k) :
    chainInput pts (appendChainNode nodes B) S₀ ⟨m, Nat.lt_succ_of_le (Nat.le_succ_of_le hm)⟩ =
      chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm⟩ :=
  cg01_chainInput_congr_prefix (appendChainNode nodes B) nodes (fun _ _ => rfl)
    m (Nat.le_succ_of_le hm) hm (fun i hi => appendChainNode_lt nodes B (lt_of_lt_of_le hi hm))

lemma cg01_chainTerminal_append {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (nodes : Fin k → ChainNode d) (B : ChainNode d) (S₀ : Finset ι) :
    chainTerminal pts (appendChainNode nodes B) S₀ =
      B.residual pts (chainTerminal pts nodes S₀) := by
  rw [cg01_chainTerminal_eq,
      cg01_chainInput_succ pts (appendChainNode nodes B) S₀ k (Nat.lt_succ_self k),
      appendChainNode_last,
      cg01_chainInput_append_lt pts nodes B S₀ k le_rfl,
      ← cg01_chainTerminal_eq]

/-- Across one single-point insert or delete (`S₀ → S₀'`), `chainInput` either stays unchanged or
undergoes `IsInputChange`. -/
lemma cg01_chainInput_step_change {d k : ℕ} {ι : Type}
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    (nodes : Fin k → ChainNode d)
    {S₀ S₀' : Finset ι}
    (hchg : IsInputChange S₀ S₀')
    (h_on : ∀ x : ι, x ∈ S₀ → x ∈ S₀' → pts' x = pts x) :
    ∀ (m : ℕ) (hm : m ≤ k),
      chainInput pts' nodes S₀' ⟨m, Nat.lt_succ_of_le hm⟩ =
        chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm⟩ ∨
      IsInputChange (chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm⟩)
        (chainInput pts' nodes S₀' ⟨m, Nat.lt_succ_of_le hm⟩)
  | 0, _ => Or.inr hchg
  | m + 1, hm => by
      classical
      have hm_lt : m < k := Nat.lt_of_succ_le hm
      have hm_le : m ≤ k := Nat.le_of_succ_le hm
      have hsub_m : chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm_le⟩ ⊆ S₀ :=
        cg01_chainInput_subset_aux pts nodes S₀ m hm_le
      have hsub_m' : chainInput pts' nodes S₀' ⟨m, Nat.lt_succ_of_le hm_le⟩ ⊆ S₀' :=
        cg01_chainInput_subset_aux pts' nodes S₀' m hm_le
      rw [cg01_chainInput_succ pts' nodes S₀' m hm_lt,
          cg01_chainInput_succ pts nodes S₀ m hm_lt]
      rcases cg01_chainInput_step_change nodes hchg h_on m hm_le with heq | hchg_m
      · left
        rw [heq]
        exact nodeResidual_congr_on (nodes ⟨m, hm_lt⟩) _ (fun x hx => by
          have hx' : x ∈ chainInput pts' nodes S₀' ⟨m, Nat.lt_succ_of_le hm_le⟩ := heq.symm ▸ hx
          exact h_on x (hsub_m hx) (hsub_m' hx'))
      · rcases hchg_m with ⟨x, hx_not, hSm'⟩ | ⟨x, hx_in, hSm'⟩
        · have hon_Sm : ∀ y ∈ chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm_le⟩, pts' y = pts y :=
            fun y hy => h_on y (hsub_m hy) (hsub_m' (by rw [hSm']; exact Finset.mem_insert_of_mem hy))
          rw [hSm', nodeResidual_insert, nodeResidual_congr_on (nodes ⟨m, hm_lt⟩) _ hon_Sm]
          split_ifs with hle
          · exact Or.inl rfl
          · refine Or.inr (Or.inl ⟨x, ?_, rfl⟩)
            exact fun hmem => hx_not (nodeResidual_subset pts (nodes ⟨m, hm_lt⟩) _ hmem)
        · have hon_er : ∀ y ∈ (chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm_le⟩).erase x,
              pts' y = pts y :=
            fun y hy => h_on y (hsub_m (Finset.mem_of_mem_erase hy)) (hsub_m' (by rw [hSm']; exact hy))
          rw [hSm', nodeResidual_congr_on (nodes ⟨m, hm_lt⟩) _ hon_er, nodeResidual_erase_uncond]
          by_cases hmem : x ∈ (nodes ⟨m, hm_lt⟩).residual pts
              (chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm_le⟩)
          · exact Or.inr (Or.inr ⟨x, hmem, rfl⟩)
          · rw [Finset.erase_eq_of_notMem hmem]
            exact Or.inl rfl

lemma cg01_chainTerminal_card_step_le {d k : ℕ} {ι : Type}
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    (nodes : Fin k → ChainNode d)
    {S₀ S₀' : Finset ι}
    (hchg : IsInputChange S₀ S₀')
    (h_on : ∀ x : ι, x ∈ S₀ → x ∈ S₀' → pts' x = pts x) :
    (chainTerminal pts' nodes S₀').card ≤ (chainTerminal pts nodes S₀).card + 1 := by
  classical
  rw [cg01_chainTerminal_eq, cg01_chainTerminal_eq]
  rcases cg01_chainInput_step_change nodes hchg h_on k le_rfl with heq | hchg_k
  · rw [heq]; omega
  · rcases hchg_k with ⟨x, _, heq⟩ | ⟨x, _, heq⟩
    · rw [heq]; exact Finset.card_insert_le _ _
    · rw [heq]; exact (Finset.card_erase_le).trans (Nat.le_succ _)

/-! ### 2. Monotone Ghost UID Map (`GhostUidMap`) Bridging Reusable Handles `< n` to Fresh UIDs -/

/-- Pure bijection between active handles `P.activeHandles` (which may be reused across deletions)
and monotone fresh ghost UIDs `< nextUid` (whose coordinates never mutate once assigned). -/
structure GhostUidMap (d : ℕ) (P : DynamicPointSet d) where
  nextUid : ℕ
  ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)
  ActiveUids : Finset ℕ
  uidOfH : ℕ → ℕ
  hOfUid : ℕ → ℕ
  huid_lt : ∀ u ∈ ActiveUids, u < nextUid
  hbij_H : ∀ h ∈ P.activeHandles,
    uidOfH h ∈ ActiveUids ∧ ghostCoords (uidOfH h) = P.handleCoords h ∧ hOfUid (uidOfH h) = h
  hbij_U : ∀ u ∈ ActiveUids,
    hOfUid u ∈ P.activeHandles ∧ uidOfH (hOfUid u) = u

/-- Initial empty `GhostUidMap` on `DynamicPointSet.empty d`. -/
def GhostUidMap.empty (d : ℕ) : GhostUidMap d (DynamicPointSet.empty d) :=
  { nextUid := 0
    ghostCoords := fun _ => 0
    ActiveUids := ∅
    uidOfH := id
    hOfUid := id
    huid_lt := fun _ hu => by simp at hu
    hbij_H := fun _ hh => by simp [DynamicPointSet.empty] at hh
    hbij_U := fun _ hu => by simp at hu }

/-- Image of a handle subset `S_h ⊆ P.activeHandles` in ghost UID space. -/
def GhostUidMap.mapSet {d : ℕ} {P : DynamicPointSet d}
    (uMap : GhostUidMap d P) (S_h : Finset ℕ) : Finset ℕ :=
  S_h.image uMap.uidOfH

lemma GhostUidMap.mem_mapSet_iff {d : ℕ} {P : DynamicPointSet d}
    (uMap : GhostUidMap d P) {S_h : Finset ℕ} (hsub : S_h ⊆ P.activeHandles) (u : ℕ) :
    u ∈ uMap.mapSet S_h ↔ u ∈ uMap.ActiveUids ∧ uMap.hOfUid u ∈ S_h := by
  unfold GhostUidMap.mapSet
  simp only [Finset.mem_image]
  constructor
  · rintro ⟨h, hh, rfl⟩
    have hb := uMap.hbij_H h (hsub hh)
    exact ⟨hb.1, hb.2.2.symm ▸ hh⟩
  · rintro ⟨hu, hh_in⟩
    exact ⟨uMap.hOfUid u, hh_in, (uMap.hbij_U u hu).2⟩

lemma GhostUidMap.mapSet_activeHandles {d : ℕ} {P : DynamicPointSet d}
    (uMap : GhostUidMap d P) :
    uMap.mapSet P.activeHandles = uMap.ActiveUids := by
  ext u
  rw [uMap.mem_mapSet_iff (Finset.Subset.refl _)]
  exact ⟨fun h => h.1, fun hu => ⟨hu, (uMap.hbij_U u hu).1⟩⟩

lemma GhostUidMap.mapSet_bij {d : ℕ} {P : DynamicPointSet d}
    (uMap : GhostUidMap d P) {S_h : Finset ℕ} (hsub : S_h ⊆ P.activeHandles) :
    (uMap.mapSet S_h).card = S_h.card ∧
    (∀ u ∈ uMap.mapSet S_h, u < uMap.nextUid) ∧
    (∀ h ∈ S_h,
      uMap.uidOfH h ∈ uMap.mapSet S_h ∧
      uMap.ghostCoords (uMap.uidOfH h) = P.handleCoords h ∧
      uMap.hOfUid (uMap.uidOfH h) = h) ∧
    (∀ u ∈ uMap.mapSet S_h,
      uMap.hOfUid u ∈ S_h ∧ uMap.uidOfH (uMap.hOfUid u) = u) := by
  have h1 : ∀ h ∈ S_h,
      uMap.uidOfH h ∈ uMap.mapSet S_h ∧
      uMap.ghostCoords (uMap.uidOfH h) = P.handleCoords h ∧
      uMap.hOfUid (uMap.uidOfH h) = h := by
    intro h hh
    have hb := uMap.hbij_H h (hsub hh)
    exact ⟨Finset.mem_image_of_mem _ hh, hb.2.1, hb.2.2⟩
  have h2 : ∀ u ∈ uMap.mapSet S_h,
      uMap.hOfUid u ∈ S_h ∧ uMap.uidOfH (uMap.hOfUid u) = u := by
    intro u hu
    rcases (uMap.mem_mapSet_iff hsub u).mp hu with ⟨huA, hhS⟩
    exact ⟨hhS, (uMap.hbij_U u huA).2⟩
  have hlt : ∀ u ∈ uMap.mapSet S_h, u < uMap.nextUid := by
    intro u hu
    exact uMap.huid_lt u ((uMap.mem_mapSet_iff hsub u).mp hu).1
  have hcard : (uMap.mapSet S_h).card = S_h.card := by
    symm
    refine Finset.card_bij (fun h _ => uMap.uidOfH h) (fun h hh => (h1 h hh).1) ?_ ?_
    · intro x hx y hy heq
      have := congrArg uMap.hOfUid heq
      rwa [(h1 x hx).2.2, (h1 y hy).2.2] at this
    · intro u hu; exact ⟨uMap.hOfUid u, (h2 u hu).1, (h2 u hu).2⟩
  exact ⟨hcard, hlt, h1, h2⟩

lemma GhostUidMap.mapSet_residual {d : ℕ} {P : DynamicPointSet d}
    (uMap : GhostUidMap d P) {S_h : Finset ℕ} (hsub : S_h ⊆ P.activeHandles)
    (B : ChainNode d) :
    uMap.mapSet (B.residual P.handleCoords S_h) =
      B.residual uMap.ghostCoords (uMap.mapSet S_h) := by
  ext u
  have hsub_res : B.residual P.handleCoords S_h ⊆ P.activeHandles :=
    (nodeResidual_subset P.handleCoords B S_h).trans hsub
  rw [uMap.mem_mapSet_iff hsub_res, mem_nodeResidual_iff_distSq_gt,
      mem_nodeResidual_iff_distSq_gt, uMap.mem_mapSet_iff hsub]
  constructor
  · rintro ⟨huA, hhS, hgt⟩
    rcases uMap.hbij_U u huA with ⟨hhP, hu_eq⟩
    have hc_eq : uMap.ghostCoords u = P.handleCoords (uMap.hOfUid u) := by
      conv_lhs => rw [← hu_eq]
      exact (uMap.hbij_H _ hhP).2.1
    exact ⟨⟨huA, hhS⟩, by rwa [hc_eq]⟩
  · rintro ⟨⟨huA, hhS⟩, hgt⟩
    rcases uMap.hbij_U u huA with ⟨hhP, hu_eq⟩
    have hc_eq : uMap.ghostCoords u = P.handleCoords (uMap.hOfUid u) := by
      conv_lhs => rw [← hu_eq]
      exact (uMap.hbij_H _ hhP).2.1
    exact ⟨huA, hhS, by rwa [← hc_eq]⟩

lemma GhostUidMap.mapSet_chainInput_aux {d k : ℕ} {P : DynamicPointSet d}
    (uMap : GhostUidMap d P) (nodes : Fin k → ChainNode d) :
    ∀ (m : ℕ) (hm : m ≤ k),
      uMap.mapSet (chainInput P.handleCoords nodes P.activeHandles ⟨m, Nat.lt_succ_of_le hm⟩) =
        chainInput uMap.ghostCoords nodes uMap.ActiveUids ⟨m, Nat.lt_succ_of_le hm⟩
  | 0, _ => uMap.mapSet_activeHandles
  | m + 1, hm => by
      have hm_lt : m < k := Nat.lt_of_succ_le hm
      have hm_le : m ≤ k := Nat.le_of_succ_le hm
      rw [cg01_chainInput_succ P.handleCoords nodes P.activeHandles m hm_lt,
          cg01_chainInput_succ uMap.ghostCoords nodes uMap.ActiveUids m hm_lt,
          uMap.mapSet_residual
            (cg01_chainInput_subset_aux P.handleCoords nodes P.activeHandles m hm_le),
          uMap.mapSet_chainInput_aux nodes m hm_le]

lemma GhostUidMap.mapSet_chainInput {d k : ℕ} {P : DynamicPointSet d}
    (uMap : GhostUidMap d P) (nodes : Fin k → ChainNode d) (j : Fin (k + 1)) :
    uMap.mapSet (chainInput P.handleCoords nodes P.activeHandles j) =
      chainInput uMap.ghostCoords nodes uMap.ActiveUids j :=
  uMap.mapSet_chainInput_aux nodes j.val (Nat.lt_succ_iff.mp j.isLt)

lemma GhostUidMap.mapSet_chainTerminal {d k : ℕ} {P : DynamicPointSet d}
    (uMap : GhostUidMap d P) (nodes : Fin k → ChainNode d) :
    uMap.mapSet (chainTerminal P.handleCoords nodes P.activeHandles) =
      chainTerminal uMap.ghostCoords nodes uMap.ActiveUids :=
  uMap.mapSet_chainInput nodes (Fin.last k)

/-- Step `GhostUidMap` across an external insertion assigning handle `opH ∉ P.activeHandles`
with coordinates `pt`. -/
noncomputable def GhostUidMap.stepInsert {d : ℕ} {P P' : DynamicPointSet d}
    (uMap : GhostUidMap d P) {opH : ℕ} {pt : EuclideanSpace ℝ (Fin d)}
    (hnot : opH ∉ P.activeHandles)
    (hact : P'.activeHandles = insert opH P.activeHandles)
    (hpt : P'.handleCoords opH = pt)
    (hpres : ∀ h ∈ P.activeHandles, P'.handleCoords h = P.handleCoords h) :
    GhostUidMap d P' :=
  let u_new := uMap.nextUid
  { nextUid := u_new + 1
    ghostCoords := Function.update uMap.ghostCoords u_new pt
    ActiveUids := insert u_new uMap.ActiveUids
    uidOfH := Function.update uMap.uidOfH opH u_new
    hOfUid := Function.update uMap.hOfUid u_new opH
    huid_lt := fun u hu => by
      rcases Finset.mem_insert.mp hu with rfl | hu0
      · dsimp [u_new]; omega
      · have := uMap.huid_lt u hu0; dsimp [u_new]; omega
    hbij_H := fun h hh => by
      rw [hact] at hh
      rcases Finset.mem_insert.mp hh with rfl | hh0
      · rw [Function.update_self, Function.update_self, Function.update_self]
        exact ⟨Finset.mem_insert_self _ _, hpt.symm, rfl⟩
      · have hne_h : h ≠ opH := fun heq => hnot (heq ▸ hh0)
        rcases uMap.hbij_H h hh0 with ⟨huA, hgc, hhu⟩
        have hlt_u : uMap.uidOfH h < u_new := uMap.huid_lt _ huA
        have hne_u : uMap.uidOfH h ≠ u_new := by omega
        rw [Function.update_of_ne hne_h, Function.update_of_ne hne_u,
            Function.update_of_ne hne_u, hpres h hh0]
        exact ⟨Finset.mem_insert_of_mem huA, hgc, hhu⟩
    hbij_U := fun u hu => by
      rcases Finset.mem_insert.mp hu with rfl | hu0
      · rw [Function.update_self, Function.update_self, hact]
        exact ⟨Finset.mem_insert_self _ _, rfl⟩
      · have hlt_u : u < u_new := uMap.huid_lt u hu0
        have hne_u : u ≠ u_new := by omega
        rcases uMap.hbij_U u hu0 with ⟨hh0, huh⟩
        have hne_h : uMap.hOfUid u ≠ opH := fun heq => hnot (heq ▸ hh0)
        rw [Function.update_of_ne hne_u, Function.update_of_ne hne_h, hact]
        exact ⟨Finset.mem_insert_of_mem hh0, huh⟩ }

/-- Step `GhostUidMap` across an external deletion of handle `opH ∈ P.activeHandles`. -/
def GhostUidMap.stepDelete {d : ℕ} {P P' : DynamicPointSet d}
    (uMap : GhostUidMap d P) {opH : ℕ}
    (hin : opH ∈ P.activeHandles)
    (hact : P'.activeHandles = P.activeHandles.erase opH)
    (hpres : ∀ h ∈ P'.activeHandles, P'.handleCoords h = P.handleCoords h) :
    GhostUidMap d P' :=
  let u_del := uMap.uidOfH opH
  { nextUid := uMap.nextUid
    ghostCoords := uMap.ghostCoords
    ActiveUids := uMap.ActiveUids.erase u_del
    uidOfH := uMap.uidOfH
    hOfUid := uMap.hOfUid
    huid_lt := fun u hu => uMap.huid_lt u (Finset.mem_of_mem_erase hu)
    hbij_H := fun h hh => by
      have hh' := hh
      rw [hact] at hh'
      rcases Finset.mem_erase.mp hh' with ⟨hne_h, hh0⟩
      rcases uMap.hbij_H h hh0 with ⟨huA, hgc, hhu⟩
      have hne_u : uMap.uidOfH h ≠ u_del := by
        intro heq
        apply hne_h
        have := congrArg uMap.hOfUid heq
        rwa [hhu, (uMap.hbij_H opH hin).2.2] at this
      exact ⟨Finset.mem_erase.mpr ⟨hne_u, huA⟩, hgc.trans (hpres h hh).symm, hhu⟩
    hbij_U := fun u hu => by
      rcases Finset.mem_erase.mp hu with ⟨hne_u, hu0⟩
      rcases uMap.hbij_U u hu0 with ⟨hh0, huh⟩
      have hne_h : uMap.hOfUid u ≠ opH := fun heq => hne_u (by dsimp [u_del]; rw [← heq, huh])
      rw [hact]
      exact ⟨Finset.mem_erase.mpr ⟨hne_h, hh0⟩, huh⟩ }

lemma GhostUidMap.stepInsert_props {d : ℕ} {P P' : DynamicPointSet d}
    (uMap : GhostUidMap d P) {opH : ℕ} {pt : EuclideanSpace ℝ (Fin d)}
    (hnot : opH ∉ P.activeHandles)
    (hact : P'.activeHandles = insert opH P.activeHandles)
    (hpt : P'.handleCoords opH = pt)
    (hpres : ∀ h ∈ P.activeHandles, P'.handleCoords h = P.handleCoords h) :
    let uMap' := uMap.stepInsert hnot hact hpt hpres
    uMap.nextUid ≤ uMap'.nextUid ∧
    (∀ u < uMap.nextUid, uMap'.ghostCoords u = uMap.ghostCoords u) ∧
    (∀ S_pre : Finset ℕ, S_pre ⊆ P.activeHandles →
      uMap'.mapSet S_pre = uMap.mapSet S_pre ∧
      IsValidPoolUpdateEvent (uMap.mapSet S_pre) (uMap'.mapSet (insert opH S_pre))
        (.externalInsert uMap.nextUid) ∧
      IsInputChange (uMap.mapSet S_pre) (uMap'.mapSet (insert opH S_pre))) := by
  classical
  intro uMap'
  refine ⟨by dsimp [uMap', GhostUidMap.stepInsert]; omega,
    fun u hu => by
      dsimp [uMap', GhostUidMap.stepInsert]
      exact Function.update_of_ne (by omega) _ _,
    fun S_pre hsub => ?_⟩
  have heq_unch : uMap'.mapSet S_pre = uMap.mapSet S_pre := by
    unfold GhostUidMap.mapSet
    refine Finset.image_congr (fun h hh => ?_)
    have hne : h ≠ opH := fun heq => hnot (heq ▸ hsub hh)
    dsimp [uMap', GhostUidMap.stepInsert]
    exact Function.update_of_ne hne _ _
  have heq_ins : uMap'.mapSet (insert opH S_pre) = insert uMap.nextUid (uMap.mapSet S_pre) := by
    unfold GhostUidMap.mapSet at heq_unch ⊢
    rw [Finset.image_insert, heq_unch]
    dsimp [uMap', GhostUidMap.stepInsert]
    rw [Function.update_self]
  have hnot_uid : uMap.nextUid ∉ uMap.mapSet S_pre := by
    intro hmem
    have hlt := (uMap.mapSet_bij hsub).2.1 _ hmem
    omega
  refine ⟨heq_unch, ?_, ?_⟩
  · unfold IsValidPoolUpdateEvent
    exact ⟨hnot_uid, by rw [heq_ins]; ext; simp⟩
  · unfold IsInputChange
    exact Or.inl ⟨uMap.nextUid, hnot_uid, by rw [heq_ins]; ext; simp⟩

lemma GhostUidMap.stepDelete_props {d : ℕ} {P P' : DynamicPointSet d}
    (uMap : GhostUidMap d P) {opH : ℕ}
    (hin : opH ∈ P.activeHandles)
    (hact : P'.activeHandles = P.activeHandles.erase opH)
    (hpres : ∀ h ∈ P'.activeHandles, P'.handleCoords h = P.handleCoords h) :
    let uMap' := uMap.stepDelete hin hact hpres
    uMap.nextUid ≤ uMap'.nextUid ∧
    (∀ u < uMap.nextUid, uMap'.ghostCoords u = uMap.ghostCoords u) ∧
    (∀ S_pre : Finset ℕ, S_pre ⊆ P.activeHandles →
      (opH ∉ S_pre → uMap'.mapSet S_pre = uMap.mapSet S_pre) ∧
      (opH ∈ S_pre →
        IsValidPoolUpdateEvent (uMap.mapSet S_pre) (uMap'.mapSet (S_pre.erase opH))
          (.externalDelete (uMap.uidOfH opH)) ∧
        IsInputChange (uMap.mapSet S_pre) (uMap'.mapSet (S_pre.erase opH)))) := by
  classical
  intro uMap'
  refine ⟨le_rfl, fun _ _ => rfl, fun S_pre hsub => ⟨fun _ => rfl, fun hop_in => ?_⟩⟩
  have hin_uid : uMap.uidOfH opH ∈ uMap.mapSet S_pre := Finset.mem_image_of_mem _ hop_in
  have heq_del : uMap'.mapSet (S_pre.erase opH) = (uMap.mapSet S_pre).erase (uMap.uidOfH opH) := by
    ext u
    unfold GhostUidMap.mapSet
    simp only [uMap', GhostUidMap.stepDelete, Finset.mem_image, Finset.mem_erase]
    constructor
    · rintro ⟨h, ⟨hne_h, hhS⟩, rfl⟩
      refine ⟨?_, h, hhS, rfl⟩
      intro heq
      apply hne_h
      have := congrArg uMap.hOfUid heq
      rwa [(uMap.hbij_H h (hsub hhS)).2.2, (uMap.hbij_H opH hin).2.2] at this
    · rintro ⟨hne_u, h, hhS, rfl⟩
      exact ⟨h, ⟨fun heq => hne_u (congrArg uMap.uidOfH heq), hhS⟩, rfl⟩
  refine ⟨?_, ?_⟩
  · unfold IsValidPoolUpdateEvent
    exact ⟨hin_uid, by rw [heq_del]; ext; simp⟩
  · unfold IsInputChange
    exact Or.inr ⟨uMap.uidOfH opH, hin_uid, by rw [heq_del]; ext; simp⟩

/-! ### 3. Centerpoint Preservation Through Two-Stage Fallback (`h_lem_5_1`) & `JobLevelsCenterGood` -/

theorem selectOpenedLevelBall_centerpoint_of_hpj
    (h_lem_5_1 : S_lem_5_1)
    {d : ℕ} {ι : Type}
    {α : ℝ} (hα : 0 < α)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {S_birth : Finset ι} (hm : 1 ≤ S_birth.card)
    (bId : ι) (o_cand : EuclideanSpace ℝ (Fin d)) (s_cand : ℝ)
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun i : ↥S_birth => pts i.1))
      (liftedPoint o_cand s_cand)) :
    let V_cand := liftVariance o_cand s_cand
    let node := selectOpenedLevelBall α pts S_birth bId (.candidate o_cand V_cand)
    0 ≤ V_cand ∧
    node.o = o_cand ∧
    node.V = V_cand ∧
    IsCenterpoint α (paraboloidLiftSet (fun i : ↥S_birth => pts i.1))
      (liftedPoint node.o (node.V + ‖node.o‖ ^ 2)) := by
  classical
  intro V_cand node
  have hdepth : α * (S_birth.card : ℝ) ≤
      (halfspaceDepth (paraboloidLiftSet (fun i : ↥S_birth => pts i.1))
        (liftedPoint o_cand s_cand) : ℝ) := by
    have hcard : Fintype.card ↥S_birth = S_birth.card := Fintype.card_coe S_birth
    unfold IsCenterpoint at hcp
    rwa [hcard] at hcp
  have h51 := h_lem_5_1 d ι pts S_birth hm α hα o_cand s_cand hdepth
  rcases h51 with ⟨hcore_cnt, _, hseq⟩
  have hsq_cnt : α * (S_birth.card : ℝ) ≤
      (pointCount (fun i : ↥S_birth => pts i.1) {x | ‖x - o_cand‖ ^ 2 ≤ V_cand} : ℝ) := by
    have h0 := (hseq 0 [] (by simp)).2.2.2.2.1
    simpa only [List.foldl_nil, Nat.cast_zero, sub_zero] using h0
  have hm_pos : (0 : ℝ) < α * (S_birth.card : ℝ) := by
    have : (0 : ℝ) < (S_birth.card : ℝ) := by exact_mod_cast hm
    positivity
  have hV_nn : 0 ≤ V_cand := by
    have hcnt_pos_r : (0 : ℝ) <
        (pointCount (fun i : ↥S_birth => pts i.1) {x | ‖x - o_cand‖ ^ 2 ≤ V_cand} : ℝ) :=
      lt_of_lt_of_le hm_pos hsq_cnt
    have hcnt_pos : 0 < pointCount (fun i : ↥S_birth => pts i.1) {x | ‖x - o_cand‖ ^ 2 ≤ V_cand} := by
      exact_mod_cast hcnt_pos_r
    unfold pointCount at hcnt_pos
    rcases Finset.card_pos.mp hcnt_pos with ⟨i₀, hi₀⟩
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Set.mem_setOf_eq] at hi₀
    exact le_trans (sq_nonneg _) hi₀
  have hprov_eq : provisionalCenter pts bId (.candidate o_cand V_cand) =
      { o := o_cand, V := V_cand, V_nonneg := hV_nn } := by
    unfold provisionalCenter
    exact dif_pos hV_nn
  let prov : ChainNode d := { o := o_cand, V := V_cand, V_nonneg := hV_nn }
  have hcard_core_eq :
      (prov.core pts S_birth).card =
        pointCount (fun i : ↥S_birth => pts i.1) (coreBall o_cand V_cand) := by
    unfold pointCount ChainNode.core nodeCore
    symm
    refine Finset.card_bij (fun (i : ↥S_birth) _ => i.1) ?_ ?_ ?_
    · intro i hi
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hi
      exact Finset.mem_filter.mpr ⟨i.2, hi⟩
    · intro i₁ _ i₂ _ heq; exact Subtype.ext heq
    · intro x hx
      rcases Finset.mem_filter.mp hx with ⟨hxS, hxc⟩
      exact ⟨⟨x, hxS⟩, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hxc⟩, rfl⟩
  have hpass : PassesBirthCoreCheck α pts prov S_birth := by
    unfold PassesBirthCoreCheck
    rw [hcard_core_eq]
    linarith
  have hnode_eq : node = prov := by
    dsimp [node, selectOpenedLevelBall]
    rw [hprov_eq]
    unfold applyBirthCoreFallback
    exact if_pos hpass
  have ho : node.o = o_cand := by rw [hnode_eq]
  have hV : node.V = V_cand := by rw [hnode_eq]
  have hs_back : node.V + ‖node.o‖ ^ 2 = s_cand := by
    rw [ho, hV]
    unfold V_cand liftVariance
    ring
  exact ⟨hV_nn, ho, hV, by rwa [hs_back, ho]⟩

/-- Translates an `α`-centerpoint on a handle-space snapshot `(snapPts, S_h)` directly into an
`α`-centerpoint on the bijective ghost-UID snapshot `(ghostCoords, S_uid)`. -/
lemma centerpoint_paraboloid_bij_uid {d : ℕ}
    {α : ℝ}
    (snapPts ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S_h S_uid : Finset ℕ)
    (f g : ℕ → ℕ)
    (hf : ∀ h ∈ S_h, f h ∈ S_uid ∧ ghostCoords (f h) = snapPts h ∧ g (f h) = h)
    (hg : ∀ u ∈ S_uid, g u ∈ S_h ∧ f (g u) = u)
    (z : EuclideanSpace ℝ (Fin (d + 1)))
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun x : ↥S_h => snapPts x.1)) z) :
    IsCenterpoint α (paraboloidLiftSet (fun u : ↥S_uid => ghostCoords u.1)) z := by
  classical
  let e : ↥S_h ≃ ↥S_uid :=
    { toFun := fun x => ⟨f x.1, (hf x.1 x.2).1⟩
      invFun := fun u => ⟨g u.1, (hg u.1 u.2).1⟩
      left_inv := fun x => Subtype.ext (hf x.1 x.2).2.2
      right_inv := fun u => Subtype.ext (hg u.1 u.2).2 }
  have hcard_eq : Fintype.card ↥S_h = Fintype.card ↥S_uid := Fintype.card_congr e
  have hpc_eq : ∀ H : Set (EuclideanSpace ℝ (Fin (d + 1))),
      pointCount (paraboloidLiftSet (fun x : ↥S_h => snapPts x.1)) H =
        pointCount (paraboloidLiftSet (fun u : ↥S_uid => ghostCoords u.1)) H := by
    intro H
    unfold pointCount
    refine Finset.card_bij (fun (x : ↥S_h) _ => e x) ?_ ?_ ?_
    · intro x hx
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, paraboloidLiftSet] at hx ⊢
      have heq_pt : ghostCoords (e x).1 = snapPts x.1 := (hf x.1 x.2).2.1
      rwa [heq_pt]
    · intro x₁ _ x₂ _ heq; exact e.injective heq
    · intro u hu
      refine ⟨e.symm u, ?_, e.apply_symm_apply u⟩
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, paraboloidLiftSet] at hu ⊢
      have heq_pt : ghostCoords (e (e.symm u)).1 = snapPts (e.symm u).1 :=
        (hf (e.symm u).1 (e.symm u).2).2.1
      rw [e.apply_symm_apply] at heq_pt
      rwa [← heq_pt]
  have hd_eq :
      halfspaceDepth (paraboloidLiftSet (fun x : ↥S_h => snapPts x.1)) z =
        halfspaceDepth (paraboloidLiftSet (fun u : ↥S_uid => ghostCoords u.1)) z := by
    unfold halfspaceDepth
    congr 1
    ext m
    simp only [Set.mem_setOf_eq, hpc_eq]
  unfold IsCenterpoint at hcp ⊢
  rwa [← hcard_eq, ← hd_eq]

/-- Centerpoint good-event predicate across all opened levels of a pending background job. -/
def JobLevelsCenterGood {d : ℕ} (D : ℕ)
    (ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (lvs : List (OpenedJobLevel d ℕ)) : Prop :=
  ∀ (j : ℕ) (hj : j < lvs.length),
    IsCenterpoint (1 / (4 * (D : ℝ) ^ 2))
      (paraboloidLiftSet (fun i : ↥(lvs[j]'hj).birthSnapshot => ghostCoords i.1))
      (liftedPoint (lvs[j]'hj).ball.o ((lvs[j]'hj).ball.V + ‖(lvs[j]'hj).ball.o‖ ^ 2))

lemma JobLevelsCenterGood.start
    (h_lem_5_1 : S_lem_5_1)
    {d n D L B_scan nextUid : ℕ}
    (ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    {S_0_uid Spar_0_h : Finset ℕ}
    {bUid : ℕ} {o_cand : EuclideanSpace ℝ (Fin d)} {s_cand : ℝ}
    (hD : 3 ≤ D) (hL : 68719476736 * D ^ 4 ≤ L)
    (hcap : S_0_uid.card ≤ n)
    (huid : ∀ u ∈ S_0_uid, u < nextUid)
    (hm0 : 4 * L < S_0_uid.card)
    (hb : bUid ∈ S_0_uid)
    (hcard_eq : Spar_0_h.card = S_0_uid.card)
    (hcp : IsCenterpoint (1 / (4 * (D : ℝ) ^ 2))
      (paraboloidLiftSet (fun i : ↥S_0_uid => ghostCoords i.1))
      (liftedPoint o_cand s_cand)) :
    let res := SampledCenterResult.candidate o_cand (liftVariance o_cand s_cand)
    let g := ActiveJobGhost.start (ghostCoords := ghostCoords) (B_scan := B_scan)
      res hD hL hcap huid hm0 hb hcard_eq
    JobLevelsCenterGood D ghostCoords g.lvs := by
  intro res g j hj
  have hj0 : j = 0 := by
    change j < ([_] : List _).length at hj
    simp at hj; exact hj
  subst hj0
  have hα0 : (0 : ℝ) < 1 / (4 * (D : ℝ) ^ 2) := (alpha_pos_and_lt_half D hD).1
  exact (selectOpenedLevelBall_centerpoint_of_hpj h_lem_5_1 hα0 ghostCoords
    (by omega : 1 ≤ S_0_uid.card) bUid o_cand s_cand hcp).2.2.2

lemma JobLevelsCenterGood.liftCoords
    {d n D L B_scan nextUid nextUid' : ℕ}
    {ghostCoords ghostCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {S_cur_uid : Finset ℕ}
    (g : ActiveJobGhost d n D L B_scan nextUid ghostCoords S_cur_uid)
    (hle_uid : nextUid ≤ nextUid')
    (hag : ∀ u < nextUid, ghostCoords' u = ghostCoords u)
    (hgood : JobLevelsCenterGood D ghostCoords g.lvs) :
    JobLevelsCenterGood D ghostCoords' (g.liftCoords hle_uid hag).lvs := by
  intro j hj
  have hj' : j < g.lvs.length := hj
  rcases g.hlvs_inv j hj' with ⟨_, huid_b, _⟩
  exact (isCenterpoint_paraboloid_congr_on _ _ (fun u hu => hag u (huid_b u hu))).mpr (hgood j hj')

lemma JobLevelsCenterGood.stepTick
    (h_lem_5_1 : S_lem_5_1)
    {d n D L B_scan nextUid' : ℕ}
    {ghostCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {S_cur_uid S_cur_uid' : Finset ℕ}
    (g : ActiveJobGhost d n D L B_scan nextUid' ghostCoords' S_cur_uid)
    (hD : 3 ≤ D)
    (ht_lt : g.t_cur < g.H_job)
    (ev_step : PoolUpdateEvent ℕ)
    (hev_ck : ev_step.isClockTick = true)
    (hev_v : IsValidPoolUpdateEvent S_cur_uid S_cur_uid' ev_step)
    (hcap' : S_cur_uid'.card ≤ n)
    (huid' : ∀ u ∈ S_cur_uid', u < nextUid')
    {ph' scan' : ℕ} {Spar_last_h' : Finset ℕ}
    (hph'_le : ph' ≤ 2)
    (hpar_1 : Spar_last_h'.card ≤ g.Spar_last_h.card + 1 ∧
      ∀ c : ℕ, (Spar_last_h'.filter (fun x => c ≤ x)).card ≤
               (g.Spar_last_h.filter (fun x => c ≤ x)).card + 1)
    (hbuild_1 :
      let m_last := (g.lvs[g.lvs.length - 1]'(Nat.sub_lt g.hlvs_pos Nat.one_pos)).birthSnapshot.card
      (g.ph_cur = 0 →
        (g.scan_cur + (B_scan + 1) < m_last → ph' = 0 ∧ scan' = g.scan_cur + (B_scan + 1)) ∧
        (m_last ≤ g.scan_cur + (B_scan + 1) → ph' = 1 ∧ scan' = 0)) ∧
      (g.ph_cur = 1 →
        ph' = 2 ∨
        (ph' = 1 ∧
          (Spar_last_h'.filter (fun x => scan' ≤ x)).card + B_scan ≤
            (g.Spar_last_h.filter (fun x => g.scan_cur ≤ x)).card)) ∧
      (g.ph_cur = 2 → ph' = 2))
    (act : JobTickEndAction d D L ghostCoords' (g.H_job - (g.t_cur + 1)) g.closed ph'
      (prefixResidual ghostCoords' g.lvs S_cur_uid'))
    (hgood : JobLevelsCenterGood D ghostCoords' g.lvs)
    (hopen_good :
      ∀ hcl hph2 hcan hlarge bUid hb res Spar_new_h hcard_new,
        act = .openLevel hcl hph2 hcan hlarge bUid hb res Spar_new_h hcard_new →
        ∃ o_cand s_cand,
          res = .candidate o_cand (liftVariance o_cand s_cand) ∧
          IsCenterpoint (1 / (4 * (D : ℝ) ^ 2))
            (paraboloidLiftSet (fun i : ↥(prefixResidual ghostCoords' g.lvs S_cur_uid') => ghostCoords' i.1))
            (liftedPoint o_cand s_cand)) :
    let g' := g.stepTick hD ht_lt ev_step hev_ck hev_v hcap' huid' hph'_le hpar_1 hbuild_1 act
    JobLevelsCenterGood D ghostCoords' g'.lvs := by
  intro g' j hj
  have hα0 : (0 : ℝ) < 1 / (4 * (D : ℝ) ^ 2) := (alpha_pos_and_lt_half D hD).1
  let lastIdx := g.lvs.length - 1
  have hlast_lt : lastIdx < g.lvs.length := Nat.sub_lt g.hlvs_pos Nat.one_pos
  let lv_last_rdy : OpenedJobLevel d ℕ := { g.lvs[lastIdx]'hlast_lt with backgroundReady := decide (ph' = 2) }
  let lvs_rdy := g.lvs.set lastIdx lv_last_rdy
  have hlvs_eq : g'.lvs = (applyJobTickEndAction lvs_rdy g.openRem scan' Spar_last_h' act).2.1 := rfl
  have hrdy_preserve : ∀ (i : ℕ) (hi : i < lvs_rdy.length),
      IsCenterpoint (1 / (4 * (D : ℝ) ^ 2))
        (paraboloidLiftSet (fun x : ↥(lvs_rdy[i]'hi).birthSnapshot => ghostCoords' x.1))
        (liftedPoint (lvs_rdy[i]'hi).ball.o ((lvs_rdy[i]'hi).ball.V + ‖(lvs_rdy[i]'hi).ball.o‖ ^ 2)) := by
    intro i hi
    have hi_g : i < g.lvs.length := by dsimp [lvs_rdy] at hi; simpa using hi
    by_cases heq : i = lastIdx
    · subst heq
      have hget : lvs_rdy[lastIdx]'hi = lv_last_rdy := by dsimp [lvs_rdy]; simp
      rw [hget]
      exact hgood lastIdx hi_g
    · have hget : lvs_rdy[i]'hi = g.lvs[i]'hi_g := by
        dsimp [lvs_rdy]; rw [List.getElem_set_ne (Ne.symm heq)]
      rw [hget]
      exact hgood i hi_g
  cases hact_eq : act with
  | waitOrBuild hq =>
      have hl : g'.lvs = lvs_rdy := by rw [hlvs_eq, hact_eq]; rfl
      have hj_rdy : j < lvs_rdy.length := hl ▸ hj
      have hlv : g'.lvs[j]'hj = lvs_rdy[j]'hj_rdy := by simp [hl]
      rw [hlv]
      exact hrdy_preserve j hj_rdy
  | closeLeaf hcl hph2 hcan hsmall =>
      have hl : g'.lvs = lvs_rdy := by rw [hlvs_eq, hact_eq]; rfl
      have hj_rdy : j < lvs_rdy.length := hl ▸ hj
      have hlv : g'.lvs[j]'hj = lvs_rdy[j]'hj_rdy := by simp [hl]
      rw [hlv]
      exact hrdy_preserve j hj_rdy
  | openLevel hcl hph2 hcan hlarge bUid hb res Spar_new_h hcard_new =>
      rcases hopen_good hcl hph2 hcan hlarge bUid hb res Spar_new_h hcard_new hact_eq with
        ⟨o_cand, s_cand, hres_eq, hcp_new⟩
      let curRes' := prefixResidual ghostCoords' g.lvs S_cur_uid'
      let lv_new : OpenedJobLevel d ℕ :=
        { birthSnapshot := curRes'
          ball := selectOpenedLevelBall (1 / (4 * (D : ℝ) ^ 2)) ghostCoords' curRes' bUid res
          indexMode := .radiusDictOnly
          backgroundReady := false }
      have hl : g'.lvs = lvs_rdy ++ [lv_new] := by rw [hlvs_eq, hact_eq]; rfl
      by_cases hj_lt_rdy : j < lvs_rdy.length
      · have hlv : g'.lvs[j]'hj = lvs_rdy[j]'hj_lt_rdy := by
          simp only [hl, List.getElem_append_left hj_lt_rdy]
        rw [hlv]
        exact hrdy_preserve j hj_lt_rdy
      · have hj_len : j < lvs_rdy.length + 1 := by simpa [hl] using hj
        have hj_eq : j = lvs_rdy.length := by omega
        have hlv : g'.lvs[j]'hj = lv_new := by
          subst hj_eq
          simp [hl]
        rw [hlv]
        dsimp only [lv_new]
        rw [hres_eq]
        exact (selectOpenedLevelBall_centerpoint_of_hpj h_lem_5_1 hα0 ghostCoords'
          (by dsimp [curRes']; omega : 1 ≤ curRes'.card) bUid o_cand s_cand hcp_new).2.2.2

end UL.Proof_lem_7_2_RacerP46
