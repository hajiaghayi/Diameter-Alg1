import UL.Proof.lem_7_2.CG04_StepB
import UL.Proof.lem_7_2.CG01_ServingSched
import UL.Proof.lem_7_2.CG03_JobTickA3a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. `CG01_EncJobs` Built Directly Over `CG03_JobTickA3a`'s `EncOwnedJobAt` & `GlobalSlotDisj` -/

/-- Job-and-disjointness invariant pairing directly with `EncServingChainRelaxed` (or `EncServingChain`)
using `defaultChainHdrCfg`, and bridging 1-to-1 with `CG03`'s `EncFullChainAndJobs`! -/
def CG01_EncJobs {d n : ℕ} (p : P46Params d n)
    (P : DynamicPointSet d)
    (st : PureServingState d n p.H p.L p.B_scan P)
    (mem : ArithRAMMemory) : Prop :=
  (∀ r : Fin st.k, wRead mem 12 (r.val : ℤ) = ((st.birthSnap r).card : ℤ)) ∧
  (∀ r : Fin st.k, (st.ownedJob r).isNone = true →
    ∃ spS < p.NumSlots,
      wRead mem 15 (r.val : ℤ) = (spS : ℤ) ∧
      EncSegSlot p.K_seg mem spS
        (chainInput P.handleCoords st.nodes P.activeHandles r.castSucc) (fun _ => 0)) ∧
  (∀ r : Fin st.k,
    EncOwnedJobAt defaultChainHdrCfg p mem P st.uMap r.val
      (chainInput P.handleCoords st.nodes P.activeHandles r.castSucc)
      (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc)
      (st.ownedJob r)) ∧
  GlobalSlotDisj p.D₀ mem st.k (wRead mem 1 6).toNat

/-- Relaxed serving-node encoding (definitionally identical (`rfl`) to `CG04_RouteRelA.EncServingNodeRelaxed`). -/
def CG01_EncServingNodeRelaxed (d K NumSlots : ℕ) (mem : ArithRAMMemory)
    (livePts : ℕ → EuclideanSpace ℝ (Fin d))
    (r : ℕ) (N : ChainNode d) (S_r : Finset ℕ) (age_r : ℕ) (idle : Bool) : Prop :=
  ∃ (dS spS : ℕ),
    0 < dS ∧ dS < NumSlots ∧
    0 < spS ∧ spS < NumSlots ∧
    dS ≠ spS ∧
    wRead mem 13 (r : ℤ) = (age_r : ℤ) ∧
    wRead mem 14 (r : ℤ) = (dS : ℤ) ∧
    wRead mem 15 (r : ℤ) = (spS : ℤ) ∧
    wRead mem 6 (dS : ℤ) = 0 ∧
    wRead mem 6 (spS : ℤ) = 0 ∧
    (∀ c : Fin d, rRead mem 12 (((r * d + c.val : ℕ) : ℤ)) = euclideanCoord N.o c) ∧
    rRead mem 13 (r : ℤ) = N.V ∧
    EncSegSlot K mem dS S_r (fun x => euclideanDistSq (livePts x) N.o) ∧
    ∃ T_sp : Finset ℕ, EncSegSlot K mem spS T_sp (fun _ => 0) ∧ (idle = true → T_sp = S_r)

/-- Relaxed serving-chain encoding (definitionally identical (`rfl`) to `CG04_RouteRelA.EncServingChainRelaxed`). -/
def CG01_EncServingChainRelaxed (d n K D₀ NumSlots : ℕ) (mem : ArithRAMMemory)
    (P : DynamicPointSet d) (k : ℕ)
    (nodes : Fin k → ChainNode d) (snAge : Fin k → ℕ) (idle : Fin k → Bool) : Prop :=
  k ≤ D₀ ∧
  n ≤ 2 ^ K ∧
  2 ≤ NumSlots ∧
  EncHandlePool d n mem P ∧
  SegGenBound K NumSlots mem ∧
  SaveGenBound n NumSlots mem ∧
  wRead mem 1 5 = (k : ℤ) ∧
  wRead mem 6 0 = 0 ∧
  EncSegSlot K mem 0 P.activeHandles (fun _ => 0) ∧
  ∃ leafS : ℕ,
    0 < leafS ∧ leafS < NumSlots ∧
    wRead mem 1 6 = (leafS : ℤ) ∧
    wRead mem 6 (leafS : ℤ) = 0 ∧
    EncSegSlot K mem leafS (chainTerminal P.handleCoords nodes P.activeHandles) (fun _ => 0) ∧
    (∀ r : Fin k,
      CG01_EncServingNodeRelaxed d K NumSlots mem P.handleCoords r.val (nodes r)
        (chainInput P.handleCoords nodes P.activeHandles r.castSucc) (snAge r) (idle r)) ∧
    (∀ r : Fin k, ∀ s ∈ snSlotSet mem r.val, s ≠ 0 ∧ s ≠ leafS) ∧
    (∀ r₁ r₂ : Fin k, r₁ ≠ r₂ → Disjoint (snSlotSet mem r₁.val) (snSlotSet mem r₂.val))

/-- Exact equivalence between `(EncHandlePool ∧ n ≤ 2^K ∧ 2 ≤ NumSlots ∧ EncFullChainAndJobs defaultChainHdrCfg)`
and `(CG01_EncServingChainRelaxed ... (fun r => (st.ownedJob r).isNone) ∧ CG01_EncJobs)`! -/
theorem encFullChainAndJobs_iff_relaxed {d n : ℕ} (p : P46Params d n)
    (mem : ArithRAMMemory) (P : DynamicPointSet d)
    (st : PureServingState d n p.H p.L p.B_scan P) :
    (n ≤ 2 ^ p.K_seg ∧ 2 ≤ p.NumSlots ∧ EncHandlePool d n mem P ∧
      EncFullChainAndJobs d n p.H defaultChainHdrCfg p mem P st) ↔
    (CG01_EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots mem P st.k st.nodes st.snAge
        (fun r => (st.ownedJob r).isNone) ∧
      CG01_EncJobs p P st mem) := by
  constructor
  · rintro ⟨hnK, hSl2, hPool, hk_le, hseg, hsave, _, hw15, hw60, hSeg0,
      leafS, hl_pos, hl_lt, hw16, hw6_l, hSegL, hDisj, hnodes⟩
    have hl_nat : (wRead mem 1 6).toNat = leafS := by rw [hw16]; simp
    refine ⟨⟨hk_le, hnK, hSl2, hPool, hseg, hsave, hw15, hw60, hSeg0,
      leafS, hl_pos, hl_lt, hw16, hw6_l, hSegL, ?_, ?_, ?_⟩, ?_, ?_, ?_, ?_⟩
    · intro r
      rcases (hnodes r).1 with ⟨dS, spS, T_sp, hd0, hd_lt, hs0, hs_lt, hne,
        _, hage, h14, h15, h6d, h6s, ho, hV, hSegD, hSegSp, hidle⟩
      exact ⟨dS, spS, hd0, hd_lt, hs0, hs_lt, hne,
        by simpa [defaultChainHdrCfg, HdrField.idx] using hage,
        h14, h15, h6d, h6s, ho,
        by simpa [defaultChainHdrCfg, HdrField.idx] using hV,
        hSegD, T_sp, hSegSp, hidle⟩
    · intro r s hs; exact hDisj.2.1 r.val r.isLt s hs
    · intro r₁ r₂ hne; exact hDisj.2.2.1 r₁.val r₁.isLt r₂.val r₂.isLt (Fin.val_ne_of_ne hne)
    · intro r
      rcases (hnodes r).1 with ⟨_, _, _, _, _, _, _, _, hbc, _⟩
      simpa [defaultChainHdrCfg, HdrField.idx] using hbc
    · intro r hidle
      rcases (hnodes r).1 with ⟨_, spS, T_sp, _, _, _, hs_lt, _, _, _, _, h15, _, _, _, _, _, hSegSp, hT_eq⟩
      rw [hT_eq hidle] at hSegSp
      exact ⟨spS, hs_lt, h15, hSegSp⟩
    · intro r; exact (hnodes r).2
    · rwa [hl_nat]
  · rintro ⟨⟨hk_le, hnK, hSl2, hPool, hseg, hsave, hw15, hw60, hSeg0,
      leafS, hl_pos, hl_lt, hw16, hw6_l, hSegL, hsn_rel, _, _⟩,
      hbc_all, _, hoj_all, hDisj⟩
    have hl_nat : (wRead mem 1 6).toNat = leafS := by rw [hw16]; simp
    rw [hl_nat] at hDisj
    refine ⟨hnK, hSl2, hPool, hk_le, hseg, hsave, hPool.1, hw15, hw60, hSeg0,
      leafS, hl_pos, hl_lt, hw16, hw6_l, hSegL, hDisj, fun r => ⟨?_, hoj_all r⟩⟩
    rcases hsn_rel r with ⟨dS, spS, hd0, hd_lt, hs0, hs_lt, hne,
      hage, h14, h15, h6d, h6s, ho, hV, hSegD, T_sp, hSegSp, hidle⟩
    exact ⟨dS, spS, T_sp, hd0, hd_lt, hs0, hs_lt, hne,
      by simpa [defaultChainHdrCfg, HdrField.idx] using hbc_all r,
      by simpa [defaultChainHdrCfg, HdrField.idx] using hage,
      h14, h15, h6d, h6s, ho,
      by simpa [defaultChainHdrCfg, HdrField.idx] using hV,
      hSegD, hSegSp, hidle⟩

/-! ### 2. Empty Initialization, Answer-Stage Congruence (`≠ 0, 26`), & Pool Cast -/

theorem cg01_encJobs_empty {d n : ℕ} (p : P46Params d n) (m : ArithRAMMemory)
    (_hpop : m.popDepth 0 = m)
    (hChain : EncServingChain d n p.K_seg p.D₀ p.NumSlots m (DynamicPointSet.empty d) 0 Fin.elim0 Fin.elim0)
    (_hw : ∀ tbl, tbl ≠ 1 → tbl ≠ 5 → ∀ idx, wRead m tbl idx = 0)
    (_hr : ∀ tbl idx, rRead m tbl idx = 0) :
    CG01_EncJobs p (DynamicPointSet.empty d) (PureServingState.empty d n p.H p.L p.B_scan) m := by
  rcases hChain with ⟨_, _, _, _, _, _, _, _, _, leafS, hleaf_pos, _, hw16, _⟩
  have hl_eq : (wRead m 1 6).toNat = leafS := by rw [hw16]; simp
  refine ⟨fun r => Fin.elim0 r, fun r => Fin.elim0 r, fun r => Fin.elim0 r, ?_⟩
  rw [hl_eq]
  exact ⟨hleaf_pos,
    fun _ hr => absurd hr (Nat.not_lt_zero _),
    fun _ hr => absurd hr (Nat.not_lt_zero _),
    fun _ hr => absurd hr (Nat.not_lt_zero _),
    fun _ hr => absurd hr (Nat.not_lt_zero _)⟩

lemma encJobLevel_congr_not_0_26 {d n D K NumSlots : ℕ} {m m' : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {idx : ℕ} {S_birth S_parent : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d} {spLive : Bool}
    (hw : ∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ i, wRead m' tbl i = wRead m tbl i)
    (hr : ∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ i, rRead m' tbl i = rRead m tbl i)
    (h : EncJobLevel d n D K NumSlots m activeH livePts idx S_birth snapPts prov S_parent spLive) :
    EncJobLevel d n D K NumSlots m' activeH livePts idx S_birth snapPts prov S_parent spLive := by
  have liftSeg : ∀ s S (fSq : ℕ → ℝ), EncSegSlot K m s S fSq → EncSegSlot K m' s S fSq :=
    fun s S fSq hs => hs.congr_mem_fSq
      (hw 5 (by decide) (by decide) _)
      (fun _ _ => hw 8 (by decide) (by decide) _)
      (fun _ _ => hw 9 (by decide) (by decide) _)
      (fun _ _ => hw 10 (by decide) (by decide) _)
      (fun _ _ => hr 8 (by decide) (by decide) _)
      (fun _ _ => rfl)
  rcases h with ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hrS, hsr,
    n1, n2, n3, n4, n5, n6, n7, n8, n9, n10,
    e2, e3, e4, e5, e6, g_b, g_d, g_sd, g_r, g_sr,
    hb_pos, e0, hSeg_b, hSlot_b, ho_23, hph⟩
  refine ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hrS, hsr,
    n1, n2, n3, n4, n5, n6, n7, n8, n9, n10,
    by rw [hw 23 (by decide) (by decide)]; exact e2,
    by rw [hw 23 (by decide) (by decide)]; exact e3,
    by rw [hw 23 (by decide) (by decide)]; exact e4,
    by rw [hw 23 (by decide) (by decide)]; exact e5,
    by rw [hw 23 (by decide) (by decide)]; exact e6,
    by rw [hw 6 (by decide) (by decide)]; exact g_b,
    by rw [hw 6 (by decide) (by decide)]; exact g_d,
    by rw [hw 6 (by decide) (by decide)]; exact g_sd,
    by rw [hw 6 (by decide) (by decide)]; exact g_r,
    by rw [hw 6 (by decide) (by decide)]; exact g_sr,
    hb_pos,
    by rw [hw 23 (by decide) (by decide)]; exact e0,
    liftSeg _ _ _ hSeg_b,
    hSlot_b.congr_mem3 (hw 6 (by decide) (by decide) _)
      (fun _ => hw 11 (by decide) (by decide) _)
      (fun _ => hr 11 (by decide) (by decide) _),
    fun c => by rw [hr 23 (by decide) (by decide)]; exact ho_23 c,
    ?_⟩
  rcases hph with ⟨cur, hc1, hc2, hc3, hc4, hc5, hc6, hc7⟩ |
      ⟨cur, hc1, hc2, hc3, hc4, s1, s2, s3, hc5, s4⟩ |
      ⟨hc1, hc2, s1, s2, s3, s4⟩
  · left
    exact ⟨cur, hc1,
      by rw [hw 24 (by decide) (by decide)]; exact hc2,
      by rw [hw 24 (by decide) (by decide)]; exact hc3,
      by rw [hw 23 (by decide) (by decide)]; exact hc4,
      by rw [hr 24 (by decide) (by decide)]; exact hc5,
      fun hne => by rw [hr 24 (by decide) (by decide)]; exact hc6 hne,
      hc7⟩
  · right; left
    exact ⟨cur, hc1,
      by rw [hw 24 (by decide) (by decide)]; exact hc2,
      by rw [hw 24 (by decide) (by decide)]; exact hc3,
      by rw [hr 24 (by decide) (by decide)]; exact hc4,
      liftSeg _ _ _ s1, liftSeg _ _ _ s2, liftSeg _ _ _ s3, hc5, liftSeg _ _ _ s4⟩
  · right; right
    exact ⟨by rw [hw 24 (by decide) (by decide)]; exact hc1,
      by rw [hr 24 (by decide) (by decide)]; exact hc2,
      liftSeg _ _ _ s1, liftSeg _ _ _ s2, liftSeg _ _ _ s3,
      fun hsp => liftSeg _ _ _ (s4 hsp)⟩

private lemma cg01_jobLevelLiveSlots_congr_23 {m m' : ArithRAMMemory}
    (hw23 : ∀ i, wRead m' 23 i = wRead m 23 i) (idx : ℕ) (sp : Bool) :
    jobLevelLiveSlots m' idx sp = jobLevelLiveSlots m idx sp := by
  unfold jobLevelLiveSlots
  simp only [hw23]

lemma globalSlotDisj_congr_not_0_26 {D₀ : ℕ} {m m' : ArithRAMMemory} {k leafS : ℕ}
    (hw : ∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, wRead m' tbl idx = wRead m tbl idx)
    (h : GlobalSlotDisj D₀ m k leafS) :
    GlobalSlotDisj D₀ m' k leafS := by
  have hsn : ∀ r, snSlotSet m' r = snSlotSet m r := snSlotSet_congr_not_0_26 hw
  have h16 : ∀ r : ℕ, wRead m' 16 (r : ℤ) = wRead m 16 (r : ℤ) :=
    fun r => hw 16 (by decide) (by decide) (r : ℤ)
  have h19 : ∀ r : ℕ, wRead m' 19 (r : ℤ) = wRead m 19 (r : ℤ) :=
    fun r => hw 19 (by decide) (by decide) (r : ℤ)
  have h23 : ∀ i : ℤ, wRead m' 23 i = wRead m 23 i := hw 23 (by decide) (by decide)
  have hL : ∀ idx sp, jobLevelLiveSlots m' idx sp = jobLevelLiveSlots m idx sp :=
    cg01_jobLevelLiveSlots_congr_23 h23
  rcases h with ⟨hl0, hs1, hs2, hj1, hj2⟩
  refine ⟨hl0, ?_, ?_, ?_, ?_⟩
  · intro r hr s hs; rw [hsn] at hs; exact hs1 r hr s hs
  · intro r₁ hr₁ r₂ hr₂ hne; rw [hsn, hsn]; exact hs2 r₁ hr₁ r₂ hr₂ hne
  · intro r hr hw_r j hj
    rw [h16] at hw_r; rw [h19] at hj
    have hp := hj1 r hr hw_r j hj
    dsimp only at hp ⊢
    rw [h19, hL]
    exact ⟨hp.1, fun r' hr' => by rw [hsn]; exact hp.2 r' hr'⟩
  · intro r₁ hr₁ hw_1 j₁ hj₁ r₂ hr₂ hw_2 j₂ hj₂ hne
    rw [h16] at hw_1 hw_2; rw [h19] at hj₁ hj₂
    rw [h19, h19, hL, hL, h23, h23]
    exact hj2 r₁ hr₁ hw_1 j₁ hj₁ r₂ hr₂ hw_2 j₂ hj₂ hne

theorem encOwnedJobAt_congr_not_0_26 {d n L B_scan : ℕ}
    {cfg : ChainHdrCfg} {T_max : ℕ} (hV : cfg.Valid T_max)
    {p : P46Params d n} {m m' : ArithRAMMemory}
    {P : DynamicPointSet d} {uMap : GhostUidMap d P}
    {r : ℕ} {S_r_h S_r_uid : Finset ℕ}
    {oj : Option (ActiveJobGhost d n (d + 3) L B_scan uMap.nextUid uMap.ghostCoords S_r_uid)}
    (hw : ∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, wRead m' tbl idx = wRead m tbl idx)
    (hr : ∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, rRead m' tbl idx = rRead m tbl idx)
    (h : EncOwnedJobAt cfg p m P uMap r S_r_h S_r_uid oj) :
    EncOwnedJobAt cfg p m' P uMap r S_r_h S_r_uid oj := by
  have hrem_nr := hV.2.2.2.2.2.2.2.2.2.1
  have hcl_nr := hV.2.2.2.2.2.2.2.2.2.2.1
  have hrem_0 : cfg.jobRem.tag ≠ 0 := by
    intro heq; apply hrem_nr; rw [heq]; simp [reservedWordTags]
  have hrem_26 : cfg.jobRem.tag ≠ 26 := by
    intro heq; apply hrem_nr; rw [heq]; simp [reservedWordTags]
  have hcl_0 : cfg.jobClosed.tag ≠ 0 := by
    intro heq; apply hcl_nr; rw [heq]; simp [reservedWordTags]
  have hcl_26 : cfg.jobClosed.tag ≠ 26 := by
    intro heq; apply hcl_nr; rw [heq]; simp [reservedWordTags]
  cases oj with
  | none =>
      dsimp only [EncOwnedJobAt] at h ⊢
      rw [hw 16 (by decide) (by decide)]; exact h
  | some g =>
      rcases h with ⟨h16, h17, h18, h19, lvs_h, hlen_eq, hlv⟩
      refine ⟨by rw [hw 16 (by decide) (by decide)]; exact h16,
              by rw [hw _ hrem_0 hrem_26]; exact h17,
              by rw [hw _ hcl_0 hcl_26]; exact h18,
              by rw [hw 19 (by decide) (by decide)]; exact h19,
              lvs_h, hlen_eq, fun j hj => ?_⟩
      rcases hlv j hj with ⟨hb, ho, hbij, henc, hw7, p2, p3, p4, p5, p6, hpre, hlast⟩
      refine ⟨hb, ho, hbij, encJobLevel_congr_not_0_26 hw hr henc,
        by rw [hw 23 (by decide) (by decide)]; exact hw7,
        by rw [hw 23 (by decide) (by decide)]; exact p2,
        by rw [hw 23 (by decide) (by decide)]; exact p3,
        by rw [hw 23 (by decide) (by decide)]; exact p4,
        by rw [hw 23 (by decide) (by decide)]; exact p5,
        by rw [hw 23 (by decide) (by decide)]; exact p6,
        fun hlt => by rw [hw 24 (by decide) (by decide)]; exact hpre hlt,
        fun heq => ?_⟩
      rcases hlast heq with ⟨hp0, hp1, hsp⟩
      exact ⟨by rw [hw 24 (by decide) (by decide)]; exact hp0,
             by rw [hw 24 (by decide) (by decide)]; exact hp1, hsp⟩

theorem cg01_encJobs_congr_not_0_26 {d n : ℕ} {p : P46Params d n}
    {P : DynamicPointSet d}
    {st : PureServingState d n p.H p.L p.B_scan P} {m m' : ArithRAMMemory}
    (hw : ∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, wRead m' tbl idx = wRead m tbl idx)
    (hr : ∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, rRead m' tbl idx = rRead m tbl idx)
    (h : CG01_EncJobs p P st m) :
    CG01_EncJobs p P st m' := by
  rcases h with ⟨hbc, hsp, hoj, hdisj⟩
  refine ⟨fun r => by rw [hw 12 (by decide) (by decide)]; exact hbc r,
    fun r hidle => ?_,
    fun r => encOwnedJobAt_congr_not_0_26 (valid_defaultChainHdrCfg (le_refl 28)) hw hr (hoj r),
    ?_⟩
  · rcases hsp r hidle with ⟨spS, hlt, hw15, hseg⟩
    exact ⟨spS, hlt, by rw [hw 15 (by decide) (by decide)]; exact hw15,
      hseg.congr_mem_fSq
        (hw 5 (by decide) (by decide) _)
        (fun _ _ => hw 8 (by decide) (by decide) _)
        (fun _ _ => hw 9 (by decide) (by decide) _)
        (fun _ _ => hw 10 (by decide) (by decide) _)
        (fun _ _ => hr 8 (by decide) (by decide) _)
        (fun _ _ => rfl)⟩
  · rw [hw 1 (by decide) (by decide) 6]
    exact globalSlotDisj_congr_not_0_26 hw hdisj

lemma encOwnedJobAt_castPool {d n L B_scan : ℕ}
    (cfg : ChainHdrCfg) (p : P46Params d n) (mem : ArithRAMMemory)
    (P : DynamicPointSet d) (uMap : GhostUidMap d P)
    (r : ℕ) {S_h₁ S_h₂ S_u₁ S_u₂ : Finset ℕ}
    (heq_h : S_h₁ = S_h₂) (heq_u : S_u₁ = S_u₂)
    (oj : Option (ActiveJobGhost d n (d + 3) L B_scan uMap.nextUid uMap.ghostCoords S_u₁)) :
    EncOwnedJobAt cfg p mem P uMap r S_h₂ S_u₂ (oj.map (fun g => g.castPool heq_u)) ↔
      EncOwnedJobAt cfg p mem P uMap r S_h₁ S_u₁ oj := by
  subst heq_h; subst heq_u
  cases oj <;> rfl

lemma cg01_jobLevelLiveSlots_subset_slotSet (mem : ArithRAMMemory) (idx : ℕ) (sp : Bool) :
    jobLevelLiveSlots mem idx sp ⊆ jobLevelSlotSet mem idx := by
  intro s hs
  unfold jobLevelLiveSlots at hs
  unfold jobLevelSlotSet
  cases sp <;> simp only [↓reduceIte, Bool.false_eq_true, Finset.mem_insert, Finset.mem_singleton] at hs ⊢
  · rcases hs with rfl | rfl | rfl <;> tauto
  · rcases hs with rfl | rfl | rfl | rfl <;> tauto

/-! ### 3. Header Appender for Synchronous Leaf-Splitting (`midAppendSplitNodeHdrStmt`) -/

/-- Reads cardinality of slot `wRead 1 6` (`leafS`) into `wRead 26 19`. -/
def midReadLeafCardTo19Stmt (K M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    cardAndMaxSegSlotStmt K (.readHeap 1 (.lit 6)),
    boxWriteW M_box 26 (.lit 19) (.readLocal 28 (.lit 0))
  ])

theorem boxSafe_midReadLeafCardTo19Stmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (K : ℕ) :
    BoxSafeOuter T_max M_box (midReadLeafCardTo19Stmt K M_box) :=
  .localScope (.seq (boxSafe_cardAndMaxSegSlotStmt K (.readHeap 1 (.lit 6))) (.boxW (by omega) _ _))

theorem exec_midReadLeafCardTo19Stmt {d K M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {leafS : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    (hBox26 : 25 ≤ M_box)
    (hw_leaf : wRead mem 1 6 = (leafS : ℤ))
    (hSeg : EncSegSlot K mem leafS S fSq) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (midReadLeafCardTo19Stmt K M_box) mem m' 80 ∧
      m'.popDepth 0 = m' ∧
      wRead m' 26 19 = (S.card : ℤ) ∧
      (∀ t, t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 19 → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) := by
  let m0 := mem.popDepth 0
  have hSeg0 : EncSegSlot K m0 leafS S fSq :=
    hSeg.congr_mem_fSq (by simp [m0]) (fun _ _ => by simp [m0]) (fun _ _ => by simp [m0])
      (fun _ _ => by simp [m0]) (fun _ _ => by simp [m0]) (fun _ _ => rfl)
  have hsE : iValAt 1 inp m0 (.readHeap 1 (.lit 6)) = (leafS : ℤ) := by
    simp [m0, hw_leaf]
  rcases exec_cardAndMaxSegSlotStmt inp m0 (.readHeap 1 (.lit 6)) hsE hSeg0
    with ⟨m1, hs1, hcard1, _, hw1, hr1, _, _⟩
  let m2 := wWrite m1 26 19 (S.card : ℤ)
  have hs2 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 19) (.readLocal 28 (.lit 0))) m1 m2 16 :=
    exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) (by simp [hcard1]) (by simp [intExprOps])
  let m' := m2.popDepth 0
  have hex : DetExecAt 0 inp (midReadLeafCardTo19Stmt K M_box) mem m' 80 :=
    (DetExecAt.localScope (fd := 0) (hs1.seq hs2)).mono_cost (by simp [intExprOps])
  refine ⟨m', hex, popDepth_zero_idem m2,
    by dsimp only [m', m2]; simp,
    fun t ht i => by dsimp only [m', m2]; rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inl ht), hw1]; simp [m0],
    fun i hi => by dsimp only [m', m2]; rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inr hi), hw1]; simp [m0],
    fun t i => by dsimp only [m', m2]; rw [rRead_popDepth, rRead_wWrite, hr1]; simp [m0]⟩

/-- Writes the integer headers (`12..16`) at `k := wRead 1 5` and updates `1[6] := rS` (`26[22]`)
and `1[5] := k + 1` BEFORE `runHPJOnSlotStmt` / `syncCoreAndPartitionStmt`, while preserving
`26[0, 1, 20, 21, 22]` and all segment/coord tables! -/
def midWriteSplitWordHdrsStmt (M_box : ℕ) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 26 (.lit 18) (.readHeap 1 (.lit 5)),
    boxWriteW M_box 12 (.readHeap 26 (.lit 18)) (.readHeap 26 (.lit 19)),
    boxWriteW M_box 13 (.readHeap 26 (.lit 18)) (.lit 0),
    boxWriteW M_box 14 (.readHeap 26 (.lit 18)) (.readHeap 26 (.lit 20)),
    boxWriteW M_box 15 (.readHeap 26 (.lit 18)) (.readHeap 26 (.lit 21)),
    boxWriteW M_box 16 (.readHeap 26 (.lit 18)) (.lit 0),
    boxWriteW M_box 1 (.lit 6) (.readHeap 26 (.lit 22)),
    boxWriteW M_box 1 (.lit 5) (.add (.readHeap 26 (.lit 18)) (.lit 1)),
    .localScope .skip
  ]

theorem boxSafe_midWriteSplitWordHdrsStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) :
    BoxSafeOuter T_max M_box (midWriteSplitWordHdrsStmt M_box) := by
  unfold midWriteSplitWordHdrsStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .localScope .skip

theorem exec_midWriteSplitWordHdrsStmt {d M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {k birthCard dS spDS rS : ℕ}
    (hBox26 : 30 ≤ M_box)
    (hk_box : k < M_box)
    (hw_k : wRead mem 1 5 = (k : ℤ))
    (hw_bc : wRead mem 26 19 = (birthCard : ℤ))
    (hw_dS : wRead mem 26 20 = (dS : ℤ))
    (hw_sp : wRead mem 26 21 = (spDS : ℤ))
    (hw_rS : wRead mem 26 22 = (rS : ℤ)) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (midWriteSplitWordHdrsStmt M_box) mem m' 200 ∧
      m'.popDepth 0 = m' ∧
      wRead m' 1 5 = (((k + 1 : ℕ) : ℤ)) ∧
      wRead m' 1 6 = (rS : ℤ) ∧
      wRead m' 12 (k : ℤ) = (birthCard : ℤ) ∧
      wRead m' 13 (k : ℤ) = 0 ∧
      wRead m' 14 (k : ℤ) = (dS : ℤ) ∧
      wRead m' 15 (k : ℤ) = (spDS : ℤ) ∧
      wRead m' 16 (k : ℤ) = 0 ∧
      (∀ i < k,
        wRead m' 12 (i : ℤ) = wRead mem 12 (i : ℤ) ∧
        wRead m' 13 (i : ℤ) = wRead mem 13 (i : ℤ) ∧
        wRead m' 14 (i : ℤ) = wRead mem 14 (i : ℤ) ∧
        wRead m' 15 (i : ℤ) = wRead mem 15 (i : ℤ) ∧
        wRead m' 16 (i : ℤ) = wRead mem 16 (i : ℤ)) ∧
      (∀ idx, idx ≠ 18 → wRead m' 26 idx = wRead mem 26 idx) ∧
      (∀ t, t ≠ 1 → t ≠ 12 → t ≠ 13 → t ≠ 14 → t ≠ 15 → t ≠ 16 → t ≠ 26 →
        ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 5 → i ≠ 6 → wRead m' 1 i = wRead mem 1 i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) := by
  let s1 := wWrite mem 26 18 (k : ℤ)
  have e1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 18) (.readHeap 1 (.lit 5))) mem s1 16 :=
    exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) (by simp [hw_k]) (by simp [intExprOps])
  let s2 := wWrite s1 12 (k : ℤ) (birthCard : ℤ)
  have e2 : DetExecAt 0 inp
      (boxWriteW M_box 12 (.readHeap 26 (.lit 18)) (.readHeap 26 (.lit 19))) s1 s2 20 :=
    exec_boxWriteW inp s1 _ _ (by simp [s1]) (by omega) (by omega)
      (by simp [s1, hw_bc]) (by simp [intExprOps])
  let s3 := wWrite s2 13 (k : ℤ) 0
  have e3 : DetExecAt 0 inp
      (boxWriteW M_box 13 (.readHeap 26 (.lit 18)) (.lit 0)) s2 s3 18 :=
    exec_boxWriteW inp s2 _ _ (by simp [s2, s1]) (by omega) (by omega)
      rfl (by simp [intExprOps])
  let s4 := wWrite s3 14 (k : ℤ) (dS : ℤ)
  have e4 : DetExecAt 0 inp
      (boxWriteW M_box 14 (.readHeap 26 (.lit 18)) (.readHeap 26 (.lit 20))) s3 s4 20 :=
    exec_boxWriteW inp s3 _ _ (by simp [s3, s2, s1]) (by omega) (by omega)
      (by simp [s3, s2, s1, hw_dS]) (by simp [intExprOps])
  let s5 := wWrite s4 15 (k : ℤ) (spDS : ℤ)
  have e5 : DetExecAt 0 inp
      (boxWriteW M_box 15 (.readHeap 26 (.lit 18)) (.readHeap 26 (.lit 21))) s4 s5 20 :=
    exec_boxWriteW inp s4 _ _ (by simp [s4, s3, s2, s1]) (by omega) (by omega)
      (by simp [s4, s3, s2, s1, hw_sp]) (by simp [intExprOps])
  let s6 := wWrite s5 16 (k : ℤ) 0
  have e6 : DetExecAt 0 inp
      (boxWriteW M_box 16 (.readHeap 26 (.lit 18)) (.lit 0)) s5 s6 18 :=
    exec_boxWriteW inp s5 _ _ (by simp [s5, s4, s3, s2, s1]) (by omega) (by omega)
      rfl (by simp [intExprOps])
  let s7 := wWrite s6 1 6 (rS : ℤ)
  have e7 : DetExecAt 0 inp
      (boxWriteW M_box 1 (.lit 6) (.readHeap 26 (.lit 22))) s6 s7 18 :=
    exec_boxWriteW inp s6 _ _ rfl (by omega) (by omega)
      (by simp [s6, s5, s4, s3, s2, s1, hw_rS]) (by simp [intExprOps])
  let s8 := wWrite s7 1 5 (((k + 1 : ℕ) : ℤ))
  have e8 : DetExecAt 0 inp
      (boxWriteW M_box 1 (.lit 5) (.add (.readHeap 26 (.lit 18)) (.lit 1))) s7 s8 20 :=
    exec_boxWriteW inp s7 _ _ rfl (by omega) (by omega)
      (by simp [s7, s6, s5, s4, s3, s2, s1]) (by simp [intExprOps])
  have e9 := exec_popScopeZero inp s8
  let m' := s8.popDepth 0
  have hex : DetExecAt 0 inp (midWriteSplitWordHdrsStmt M_box) mem m' 200 := by
    unfold midWriteSplitWordHdrsStmt seqList
    exact (e1.seq (e2.seq (e3.seq (e4.seq (e5.seq (e6.seq (e7.seq (e8.seq e9)))))))).mono_cost (by omega)
  refine ⟨m', hex, popDepth_zero_idem s8,
    by simp [m', s8],
    by dsimp [m', s8, s7]; rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; simp,
    by simp [m', s8, s7, s6, s5, s4, s3, s2],
    by simp [m', s8, s7, s6, s5, s4, s3],
    by simp [m', s8, s7, s6, s5, s4],
    by simp [m', s8, s7, s6, s5],
    by simp [m', s8, s7, s6],
    ?_, ?_, ?_, ?_, ?_⟩
  · intro i hi
    have hne : (i : ℤ) ≠ (k : ℤ) := by omega
    refine ⟨?_, ?_, ?_, ?_, ?_⟩ <;> {
      dsimp [m', s8, s7, s6, s5, s4, s3, s2, s1]
      simp [hne]
    }
  · intro idx h18
    dsimp [m', s8, s7, s6, s5, s4, s3, s2, s1]
    simp [h18]
  · intro t h1 h12 h13 h14 h15 h16 h26 i
    dsimp [m', s8, s7, s6, s5, s4, s3, s2, s1]
    simp [h1, h12, h13, h14, h15, h16, h26]
  · intro i h5 h6
    dsimp [m', s8, s7, s6, s5, s4, s3, s2, s1]
    simp [h5, h6]
  · intro t i
    dsimp [m', s8, s7, s6, s5, s4, s3, s2, s1]
    simp

/-- Stores `B.o` (`27[0..d-1]`) to `rRead 12 [k*d..+d]` and `B.V` (`27[d]`) to `rRead 13 [k]`
AFTER `syncCoreAndPartitionStmt`, where `wRead mem 1 5 = k + 1` (`k = (wRead 1 5) - 1`). -/
def midStoreSplitRealCenterStmt (d M_box : ℕ) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 26 (.lit 18) (.sub (.readHeap 1 (.lit 5)) (.lit 1)),
    storeCenter27ToSnStmt d M_box 12,
    boxWriteR M_box 13 (.readHeap 26 (.lit 18)) (.readRealHeap 27 (.lit (d : ℤ))),
    .localScope .skip
  ]

theorem boxSafe_midStoreSplitRealCenterStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (d : ℕ) :
    BoxSafeOuter T_max M_box (midStoreSplitRealCenterStmt d M_box) := by
  unfold midStoreSplitRealCenterStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact boxSafe_storeCenter27ToSnStmt d 12 (by omega)
  · exact .boxR (by omega) _ _
  · exact .localScope .skip

theorem exec_midStoreSplitRealCenterStmt {d M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {k : ℕ} {B : ChainNode d}
    (hBox26 : 30 ≤ M_box)
    (hk_box : k < M_box)
    (hk_snO : k * d + d ≤ M_box)
    (hw_k1 : wRead mem 1 5 = (((k + 1 : ℕ) : ℤ)))
    (hr_o : ∀ c : Fin d, rRead mem 27 (c.val : ℤ) = euclideanCoord B.o c)
    (hr_V : rRead mem 27 (d : ℤ) = B.V) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (midStoreSplitRealCenterStmt d M_box) mem m' (90 * (d + 1) + 100) ∧
      m'.popDepth 0 = m' ∧
      (∀ c : Fin d, rRead m' 12 (((k * d + c.val : ℕ) : ℤ)) = euclideanCoord B.o c) ∧
      rRead m' 13 (k : ℤ) = B.V ∧
      (∀ i < k,
        rRead m' 13 (i : ℤ) = rRead mem 13 (i : ℤ) ∧
        (∀ c : Fin d, rRead m' 12 (((i * d + c.val : ℕ) : ℤ)) = rRead mem 12 (((i * d + c.val : ℕ) : ℤ)))) ∧
      (∀ t, t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ t, t ≠ 12 → t ≠ 13 → ∀ i, rRead m' t i = rRead mem t i) := by
  let s1 := wWrite mem 26 18 (k : ℤ)
  have e1 : DetExecAt 0 inp
      (boxWriteW M_box 26 (.lit 18) (.sub (.readHeap 1 (.lit 5)) (.lit 1))) mem s1 20 :=
    exec_boxWriteW inp mem _ _ rfl (by omega) (by omega)
      (by simp [hw_k1]) (by simp [intExprOps])
  rcases exec_storeCenter27ToSnStmt (rSnCenterO := 12) inp s1 (dst := k) (pt := B.o)
      (by simp [s1]) hk_snO (fun c => by simpa [s1] using hr_o c)
    with ⟨s2, e2, _, hr12_k, hr12_out, hr_not12, hw_s2⟩
  have hs2_18 : wRead s2 26 18 = (k : ℤ) := by rw [hw_s2]; simp [s1]
  have hs2_V : rRead s2 27 (d : ℤ) = B.V := by
    rw [hr_not12 27 (by decide)]; simpa [s1] using hr_V
  let s3 := rWrite s2 13 (k : ℤ) B.V
  have e3 : DetExecAt 0 inp
      (boxWriteR M_box 13 (.readHeap 26 (.lit 18)) (.readRealHeap 27 (.lit (d : ℤ)))) s2 s3 20 :=
    exec_boxWriteR inp s2 _ _ (by simp [hs2_18]) (by omega) (by omega)
      (by simp [hs2_V]) (by simp [intExprOps, realExprOps])
  have e4 := exec_popScopeZero inp s3
  let m' := s3.popDepth 0
  have hex : DetExecAt 0 inp (midStoreSplitRealCenterStmt d M_box) mem m' (90 * (d + 1) + 100) := by
    unfold midStoreSplitRealCenterStmt seqList
    exact (e1.seq (e2.seq (e3.seq e4))).mono_cost (by omega)
  have h12_ne_13 : (12 : ℕ) ≠ 13 := by decide
  refine ⟨m', hex, popDepth_zero_idem s3,
    fun c => by
      dsimp only [m', s3]
      rw [rRead_popDepth, rRead_rWrite_of_ne _ _ (Or.inl h12_ne_13)]
      exact hr12_k c,
    by dsimp only [m', s3]; simp,
    ?_, ?_, ?_⟩
  · intro i hi
    have hne : (i : ℤ) ≠ (k : ℤ) := by omega
    refine ⟨?_, ?_⟩
    · dsimp only [m', s3]
      rw [rRead_popDepth, rRead_rWrite_of_ne _ _ (Or.inr hne), hr_not12 13 (by decide)]
      simp [s1]
    · intro c
      have hlt_kd : (((i * d + c.val : ℕ) : ℤ)) < ((k * d : ℕ) : ℤ) := by
        have : i * d + c.val < k * d := by
          calc i * d + c.val < i * d + d := Nat.add_lt_add_left c.isLt _
            _ = (i + 1) * d := by ring
            _ ≤ k * d := Nat.mul_le_mul_right d hi
        exact_mod_cast this
      dsimp only [m', s3]
      rw [rRead_popDepth, rRead_rWrite_of_ne _ _ (Or.inl h12_ne_13), hr12_out _ (Or.inl hlt_kd)]
      simp [s1]
  · intro t ht i
    dsimp only [m', s3]
    rw [wRead_popDepth, wRead_rWrite, hw_s2]
    simp [s1, ht]
  · intro t h12 h13 i
    dsimp only [m', s3]
    rw [rRead_popDepth, rRead_rWrite_of_ne _ _ (Or.inl h13), hr_not12 t h12]
    simp [s1]

end UL.Proof_lem_7_2_RacerP46
