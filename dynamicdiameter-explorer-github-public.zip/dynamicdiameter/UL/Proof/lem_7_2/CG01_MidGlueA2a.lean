import UL.Proof.lem_7_2.CG01_MidGlueA1
import UL.Proof.lem_7_2.CG04_MidBridge

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Slot-Scoped Frame Helpers & Statements for Synchronous Leaf-Splitting -/

lemma encSlotCoords_congr_6_11 {d n : ℕ} {m m' : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {s : ℕ} {S : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    (h : EncSlotCoords d n m activeH livePts s S snapPts)
    (hw6 : wRead m' 6 (s : ℤ) = wRead m 6 (s : ℤ))
    (hw11 : ∀ i, wRead m' 11 i = wRead m 11 i)
    (hr11 : ∀ i, rRead m' 11 i = rRead m 11 i) :
    EncSlotCoords d n m' activeH livePts s S snapPts := by
  rcases h with ⟨hlt, h0 | ⟨h1, hall⟩⟩
  · exact ⟨hlt, Or.inl ⟨by rw [hw6]; exact h0.1, h0.2⟩⟩
  · refine ⟨hlt, Or.inr ⟨by rw [hw6]; exact h1, fun x hx => ?_⟩⟩
    rcases hall x hx with ⟨heq_c, hne_c⟩
    refine ⟨fun heq => ?_, fun hne => ?_⟩
    · rw [hw11, hw6] at heq
      intro c; rw [hr11]; exact heq_c heq c
    · rw [hw11, hw6] at hne
      exact hne_c hne

lemma encJobLevel_frame_slotSet {d n D K NumSlots : ℕ} {mem mem' : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {idx : ℕ} {S_birth : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d} {S_parent : Finset ℕ} {spareResLive : Bool}
    (hEnc : EncJobLevel d n D K NumSlots mem activeH livePts idx S_birth snapPts prov S_parent spareResLive)
    (hseg_pres : ∀ s ∈ jobLevelSlotSet mem idx, s < NumSlots →
      ∀ S₁ fSq₁, EncSegSlot K mem s S₁ fSq₁ → EncSegSlot K mem' s S₁ fSq₁)
    (hsave_pres : ∀ s ∈ jobLevelSlotSet mem idx,
      wRead mem' 6 (s : ℤ) = wRead mem 6 (s : ℤ))
    (hsnap_pres : ∀ bS ∈ jobLevelSlotSet mem idx, bS < NumSlots →
      EncSlotCoords d n mem activeH livePts bS S_birth snapPts →
      EncSlotCoords d n mem' activeH livePts bS S_birth snapPts)
    (hw23 : ∀ r < 8, wRead mem' 23 (((8 * idx + r : ℕ) : ℤ)) = wRead mem 23 (((8 * idx + r : ℕ) : ℤ)))
    (hw24 : ∀ r < 2, wRead mem' 24 (((2 * idx + r : ℕ) : ℤ)) = wRead mem 24 (((2 * idx + r : ℕ) : ℤ)))
    (hr23 : ∀ c : Fin d, rRead mem' 23 (((idx * d + c.val : ℕ) : ℤ)) = rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)))
    (hr24 : ∀ r < 2, rRead mem' 24 (((2 * idx + r : ℕ) : ℤ)) = rRead mem 24 (((2 * idx + r : ℕ) : ℤ))) :
    EncJobLevel d n D K NumSlots mem' activeH livePts idx S_birth snapPts prov S_parent spareResLive := by
  rcases hEnc with ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
    hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
    hw_bS, hw_dS, hw_spDS, hw_rS, hw_spRS,
    h6_bS, h6_dS, h6_spDS, h6_rS, h6_spRS,
    hb_pos, hw_bCard, hSeg_bS, hSlot_bS, hr_o, hPhases⟩
  have hmem_bS : bS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_bS]; simp
  have hmem_dS : dS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_dS]; simp
  have hmem_spDS : spDS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_spDS]; simp
  have hmem_rS : rS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_rS]; simp
  have hmem_spRS : spRS ∈ jobLevelSlotSet mem idx := by
    unfold jobLevelSlotSet; rw [hw_spRS]; simp
  refine ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
    hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
    by rw [hw23 2 (by omega), hw_bS],
    by rw [hw23 3 (by omega), hw_dS],
    by rw [hw23 4 (by omega), hw_spDS],
    by rw [hw23 5 (by omega), hw_rS],
    by rw [hw23 6 (by omega), hw_spRS],
    by rw [hsave_pres bS hmem_bS]; exact h6_bS,
    by rw [hsave_pres dS hmem_dS]; exact h6_dS,
    by rw [hsave_pres spDS hmem_spDS]; exact h6_spDS,
    by rw [hsave_pres rS hmem_rS]; exact h6_rS,
    by rw [hsave_pres spRS hmem_spRS]; exact h6_spRS,
    hb_pos,
    by rw [hw23 0 (by omega), hw_bCard],
    hseg_pres bS hmem_bS hbS _ _ hSeg_bS,
    hsnap_pres bS hmem_bS hbS hSlot_bS,
    fun c => by rw [hr23 c, hr_o c],
    ?_⟩
  rcases hPhases with ⟨cur, hcur, hph, hwcur, hwcore, hrV, hrmax, hlive⟩ |
                      ⟨cur, hcur, hph, hwcur, hrV, hEd, hEspD, hEr, hlive, hEspR⟩ |
                      ⟨hph, hrV, hEd, hEspD, hEr, hEspR⟩
  · left
    exact ⟨cur, hcur,
      by rw [hw24 0 (by omega), hph],
      by rw [hw24 1 (by omega), hwcur],
      by rw [hw23 1 (by omega), hwcore],
      by rw [hr24 0 (by omega), hrV],
      fun hne => by rw [hr24 1 (by omega), hrmax hne],
      hlive⟩
  · right; left
    exact ⟨cur, hcur,
      by rw [hw24 0 (by omega), hph],
      by rw [hw24 1 (by omega), hwcur],
      by rw [hr24 0 (by omega), hrV],
      hseg_pres dS hmem_dS hdS _ _ hEd,
      hseg_pres spDS hmem_spDS hspDS _ _ hEspD,
      hseg_pres rS hmem_rS hrS _ _ hEr,
      hlive,
      hseg_pres spRS hmem_spRS hspRS _ _ hEspR⟩
  · right; right
    exact ⟨by rw [hw24 0 (by omega), hph],
      by rw [hr24 0 (by omega), hrV],
      hseg_pres dS hmem_dS hdS _ _ hEd,
      hseg_pres spDS hmem_spDS hspDS _ _ hEspD,
      hseg_pres rS hmem_rS hrS _ _ hEr,
      fun hlive => hseg_pres spRS hmem_spRS hspRS _ _ (hEspR hlive)⟩

def syncSplitPreHPJStmt (M_box D₀ NumSlots : ℕ) : ArithRAMStmt :=
  seqList [
    freshAllocFourSlotsStmt D₀ NumSlots M_box,
    boxWriteW M_box 26 (.lit 0) (.lit 1),
    boxWriteW M_box 26 (.lit 1) (.readHeap 1 (.lit 6)),
    midWriteSplitWordHdrsStmt M_box
  ]

def syncSplitPostHPJStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  seqList [
    provisionalFromHPJStmt d n p.K_seg M_box,
    syncCoreAndPartitionStmt d p.D p.K_seg (4 * p.L + 2) M_box,
    midStoreSplitRealCenterStmt d M_box
  ]

def syncSplitOneRoundStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  .seq (midReadLeafCardTo19Stmt p.K_seg M_box)
    (.ite (.intLt (.lit (((2 * p.L + 1 : ℕ) : ℤ))) (.readHeap 26 (.lit 19)))
      (.seq (syncSplitPreHPJStmt M_box p.D₀ p.NumSlots)
        (.seq (runHPJOnSlotStmt d n M_box p)
          (syncSplitPostHPJStmt d n M_box p)))
      (randDummyBitsStmt p.B_hpj))

noncomputable def syncSplitPostHPJCost {n : ℕ} (d : ℕ) (p : P46Params d n) : ℕ :=
  (100 * (p.K_seg + 1) + 180 * (d + 1) + 150) +
  (1200 * (4 * p.L + 3) * (p.K_seg + d + 5) + 600) +
  (90 * (d + 1) + 100)

noncomputable def syncSplitOneRoundCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  80 + 10 +
    (freshAllocFourCost p.D₀ p.NumSlots + 240 +
      hpjCallCost d n p + syncSplitPostHPJCost d p)

theorem boxSafe_syncSplitOneRoundStmt {d n T_max M_box : ℕ}
    (hT : 28 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (syncSplitOneRoundStmt d n M_box p) := by
  have hT27 : 27 ≤ T_max := by omega
  refine .seq (boxSafe_midReadLeafCardTo19Stmt hT27 p.K_seg)
    (.ite _
      (.seq ?_ (.seq (boxSafe_runHPJOnSlotStmt hT p) ?_))
      (boxSafe_randDummyBitsStmt p.B_hpj))
  · unfold syncSplitPreHPJStmt
    apply boxSafeOuter_seqList
    intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl | rfl
    · exact boxSafe_freshAllocFourSlotsStmt hT27 p.D₀ p.NumSlots
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact boxSafe_midWriteSplitWordHdrsStmt hT27
  · unfold syncSplitPostHPJStmt
    apply boxSafeOuter_seqList
    intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl
    · exact boxSafe_provisionalFromHPJStmt hT d n p.K_seg
    · exact boxSafe_syncCoreAndPartitionStmt hT d p.D p.K_seg (4 * p.L + 2)
    · exact boxSafe_midStoreSplitRealCenterStmt hT27 d

/-! ### 2. Post-Split Invariant Assembly (`syncSplit_append_coupled`) -/

theorem syncSplit_append_coupled
    {d n : ℕ} {p : P46Params d n} {P' : DynamicPointSet d}
    (st : PureServingState d n p.H p.L p.B_scan P')
    {m1 m9 : ArithRAMMemory}
    {leafS dS spDS rS spRS : ℕ}
    {o_cand : EuclideanSpace ℝ (Fin d)} {s_cand : ℝ}
    {B_new : ChainNode d}
    (hgt : 2 * p.L + 1 < (chainTerminal P'.handleCoords st.nodes P'.activeHandles).card)
    (hB_new : B_new =
      selectOpenedLevelBall (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) P'.handleCoords
        (chainTerminal P'.handleCoords st.nodes P'.activeHandles)
        ((chainTerminal P'.handleCoords st.nodes P'.activeHandles).orderEmbOfFin rfl
          ⟨0, Nat.lt_of_le_of_lt (Nat.zero_le _) hgt⟩)
        (.candidate o_cand (liftVariance o_cand s_cand)))
    (hk1_le_D0 : st.k + 1 ≤ p.D₀)
    (hChain1 : EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m1 P' st.k st.nodes st.snAge
      (fun r => (st.ownedJob r).isNone))
    (hJobs1 : CG01_EncJobs p P' st m1)
    (hw15_1 : wRead m1 1 5 = (st.k : ℤ))
    (hw16_1 : wRead m1 1 6 = (leafS : ℤ))
    (hdS0 : 0 < dS) (hdS_lt : dS < p.NumSlots) (hdS_notU : dS ∉ activeSlotSet m1 p.D₀)
    (hsp0 : 0 < spDS) (hsp_lt : spDS < p.NumSlots) (hsp_notU : spDS ∉ activeSlotSet m1 p.D₀)
    (hrS0 : 0 < rS) (hrS_lt : rS < p.NumSlots) (hrS_notU : rS ∉ activeSlotSet m1 p.D₀)
    (hspR_notU : spRS ∉ activeSlotSet m1 p.D₀)
    (hd_sp : dS ≠ spDS) (hd_r : dS ≠ rS) (hsp_r : spDS ≠ rS)
    (hPool9 : EncHandlePool d n m9 P')
    (hSegGen9 : SegGenBound p.K_seg p.NumSlots m9)
    (hSaveGen9 : SaveGenBound n p.NumSlots m9)
    (hw15_9 : wRead m9 1 5 = (((st.k + 1 : ℕ) : ℤ)))
    (hw16_9 : wRead m9 1 6 = (rS : ℤ))
    (hw12k_9 : wRead m9 12 (st.k : ℤ) = (((chainTerminal P'.handleCoords st.nodes P'.activeHandles).card : ℤ)))
    (hw13k_9 : wRead m9 13 (st.k : ℤ) = 0)
    (hw14k_9 : wRead m9 14 (st.k : ℤ) = (dS : ℤ))
    (hw15k_9 : wRead m9 15 (st.k : ℤ) = (spDS : ℤ))
    (hw16k_9 : wRead m9 16 (st.k : ℤ) = 0)
    (hw6_dS9 : wRead m9 6 (dS : ℤ) = 0)
    (hw6_sp9 : wRead m9 6 (spDS : ℤ) = 0)
    (hw6_rS9 : wRead m9 6 (rS : ℤ) = 0)
    (hwHdrPre_9 : ∀ r < st.k,
      wRead m9 12 (r : ℤ) = wRead m1 12 (r : ℤ) ∧
      wRead m9 13 (r : ℤ) = wRead m1 13 (r : ℤ) ∧
      wRead m9 14 (r : ℤ) = wRead m1 14 (r : ℤ) ∧
      wRead m9 15 (r : ℤ) = wRead m1 15 (r : ℤ) ∧
      wRead m9 16 (r : ℤ) = wRead m1 16 (r : ℤ))
    (hwJob_9 : ∀ t, t ∈ ({17, 18, 19, 23, 24} : Finset ℕ) → ∀ i, wRead m9 t i = wRead m1 t i)
    (hrJob_9 : ∀ t, t ∈ ({23, 24} : Finset ℕ) → ∀ i, rRead m9 t i = rRead m1 t i)
    (hrHdrPre_9 : ∀ r < st.k,
      rRead m9 13 (r : ℤ) = rRead m1 13 (r : ℤ) ∧
      (∀ c : Fin d, rRead m9 12 (((r * d + c.val : ℕ) : ℤ)) = rRead m1 12 (((r * d + c.val : ℕ) : ℤ))))
    (hSegPres_9 : ∀ s < p.NumSlots, s ≠ dS → s ≠ spDS → s ≠ rS → s ≠ spRS →
      ∀ S₁ fSq₁, EncSegSlot p.K_seg m1 s S₁ fSq₁ → EncSegSlot p.K_seg m9 s S₁ fSq₁)
    (hw6Pres_9 : ∀ s : ℕ, s ≠ dS → s ≠ spDS → s ≠ rS → s ≠ spRS →
      wRead m9 6 (s : ℤ) = wRead m1 6 (s : ℤ))
    (hSlotPres_9 : ∀ s < p.NumSlots, s ≠ dS → s ≠ spDS → s ≠ rS → s ≠ spRS →
      ∀ S₁ sp₁, EncSlotCoords d n m1 P'.activeHandles P'.handleCoords s S₁ sp₁ →
        EncSlotCoords d n m9 P'.activeHandles P'.handleCoords s S₁ sp₁)
    (hr12k_9 : ∀ c : Fin d, rRead m9 12 (((st.k * d + c.val : ℕ) : ℤ)) = euclideanCoord B_new.o c)
    (hr13k_9 : rRead m9 13 (st.k : ℤ) = B_new.V)
    (hSeg_dS9 : EncSegSlot p.K_seg m9 dS
      (chainTerminal P'.handleCoords st.nodes P'.activeHandles)
      (fun x => euclideanDistSq (P'.handleCoords x) B_new.o))
    (hSeg_sp9 : EncSegSlot p.K_seg m9 spDS
      (chainTerminal P'.handleCoords st.nodes P'.activeHandles) (fun _ => 0))
    (hSeg_rS9 : EncSegSlot p.K_seg m9 rS
      (B_new.residual P'.handleCoords
        (chainTerminal P'.handleCoords st.nodes P'.activeHandles)) (fun _ => 0)) :
    let st' := st.syncSplitOne o_cand s_cand
    EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m9 P' st'.k st'.nodes st'.snAge
      (fun r => (st'.ownedJob r).isNone) ∧
    CG01_EncJobs p P' st' m9 := by
  classical
  intro st'
  let S_leaf := chainTerminal P'.handleCoords st.nodes P'.activeHandles
  have hS_sub : S_leaf ⊆ P'.activeHandles :=
    cg01_chainTerminal_subset P'.handleCoords st.nodes P'.activeHandles
  let st_new : PureServingState d n p.H p.L p.B_scan P' :=
    { uMap := st.uMap
      k := st.k + 1
      nodes := appendChainNode st.nodes B_new
      birthSnap := fun i =>
        if h : i.val < st.k then st.birthSnap ⟨i.val, h⟩ else st.uMap.mapSet S_leaf
      snAge := fun i =>
        if h : i.val < st.k then st.snAge ⟨i.val, h⟩ else 0
      trueAge := fun i =>
        if h : i.val < st.k then st.trueAge ⟨i.val, h⟩ else 0
      ownedJob := fun i =>
        if h : i.val < st.k then
          (st.ownedJob ⟨i.val, h⟩).map (fun g =>
            g.castPool (cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new
              st.uMap.ActiveUids i.val (le_of_lt h)).symm)
        else none }
  have hst'_def : st' = st_new := by
    dsimp only [st', st_new, PureServingState.syncSplitOne]
    rw [dif_pos hgt]
    subst hB_new; rfl
  have hU_dS := not_in_activeSlotSet_props hw15_1 hw16_1 hdS_notU
  have hU_sp := not_in_activeSlotSet_props hw15_1 hw16_1 hsp_notU
  have hU_rS := not_in_activeSlotSet_props hw15_1 hw16_1 hrS_notU
  have hU_sr := not_in_activeSlotSet_props hw15_1 hw16_1 hspR_notU
  rcases hChain1 with ⟨_, hnK1, hSlots1, _, _, _, _, hw60_1, hSeg0_1,
    _, _, _, _, _, _, hsn1, hdisj0_1, hdisjPair_1⟩
  have hsnSlot_pre : ∀ r < st.k, snSlotSet m9 r = snSlotSet m1 r := by
    intro r hr; unfold snSlotSet; rw [(hwHdrPre_9 r hr).2.2.1, (hwHdrPre_9 r hr).2.2.2.1]
  have hsnSlot_k : snSlotSet m9 st.k = {dS, spDS} := by
    unfold snSlotSet; rw [hw14k_9, hw15k_9]; simp
  refine ⟨?_, ?_⟩
  · -- EncServingChainRelaxed
    rw [hst'_def]
    refine ⟨hk1_le_D0, hnK1, hSlots1, hPool9, hSegGen9, hSaveGen9,
      hw15_9,
      by simpa using (hw6Pres_9 0 hU_dS.1.symm hU_sp.1.symm hU_rS.1.symm hU_sr.1.symm).trans hw60_1,
      hSegPres_9 0 (by omega) hU_dS.1.symm hU_sp.1.symm hU_rS.1.symm hU_sr.1.symm _ _ hSeg0_1,
      rS, hrS0, hrS_lt, hw16_9, hw6_rS9,
      by change EncSegSlot p.K_seg m9 rS (chainTerminal P'.handleCoords (appendChainNode st.nodes B_new) P'.activeHandles) (fun _ => 0)
         rw [cg01_chainTerminal_append]; exact hSeg_rS9,
      ?_, ?_, ?_⟩
    · intro i; dsimp only
      by_cases hi : i.val < st.k
      · let i_old : Fin st.k := ⟨i.val, hi⟩
        have hnod_eq : st_new.nodes i = st.nodes i_old := appendChainNode_lt st.nodes B_new hi
        have hage_eq : st_new.snAge i = st.snAge i_old := dif_pos hi
        have hoj_eq : st_new.ownedJob i =
            (st.ownedJob i_old).map (fun g =>
              g.castPool (cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new
                st.uMap.ActiveUids i.val (le_of_lt hi)).symm) := dif_pos hi
        have hidle_eq : (st_new.ownedJob i).isNone = (st.ownedJob i_old).isNone := by
          rw [hoj_eq]; cases st.ownedJob i_old <;> rfl
        have hS_eq : chainInput P'.handleCoords st_new.nodes P'.activeHandles i.castSucc =
            chainInput P'.handleCoords st.nodes P'.activeHandles i_old.castSucc :=
          cg01_chainInput_append_lt P'.handleCoords st.nodes B_new P'.activeHandles i.val (le_of_lt hi)
        rw [hnod_eq, hS_eq, hage_eq, hidle_eq]
        rcases hsn1 i_old with ⟨dS_i, spS_i, hd0_i, hd_i, hsp0_i, hsp_i, hne_i,
          e13_i, e14_i, e15_i, e6d_i, e6s_i, er12_i, er13_i, hSegD_i, T_sp, hSegSp_i, hidle_i⟩
        have hd_in : dS_i ∈ snSlotSet m1 i.val := by unfold snSlotSet; rw [e14_i]; simp
        have hsp_in : spS_i ∈ snSlotSet m1 i.val := by unfold snSlotSet; rw [e15_i]; simp
        have hd_ne : dS_i ≠ dS ∧ dS_i ≠ spDS ∧ dS_i ≠ rS ∧ dS_i ≠ spRS :=
          ⟨fun h => hU_dS.2.2.1 i.val hi (h ▸ hd_in),
           fun h => hU_sp.2.2.1 i.val hi (h ▸ hd_in),
           fun h => hU_rS.2.2.1 i.val hi (h ▸ hd_in),
           fun h => hU_sr.2.2.1 i.val hi (h ▸ hd_in)⟩
        have hsp_ne : spS_i ≠ dS ∧ spS_i ≠ spDS ∧ spS_i ≠ rS ∧ spS_i ≠ spRS :=
          ⟨fun h => hU_dS.2.2.1 i.val hi (h ▸ hsp_in),
           fun h => hU_sp.2.2.1 i.val hi (h ▸ hsp_in),
           fun h => hU_rS.2.2.1 i.val hi (h ▸ hsp_in),
           fun h => hU_sr.2.2.1 i.val hi (h ▸ hsp_in)⟩
        rcases hrHdrPre_9 i.val hi with ⟨hr13_pre, hr12_pre⟩
        exact ⟨dS_i, spS_i, hd0_i, hd_i, hsp0_i, hsp_i, hne_i,
          by rw [(hwHdrPre_9 i.val hi).2.1, e13_i],
          by rw [(hwHdrPre_9 i.val hi).2.2.1, e14_i],
          by rw [(hwHdrPre_9 i.val hi).2.2.2.1, e15_i],
          by rw [hw6Pres_9 dS_i hd_ne.1 hd_ne.2.1 hd_ne.2.2.1 hd_ne.2.2.2, e6d_i],
          by rw [hw6Pres_9 spS_i hsp_ne.1 hsp_ne.2.1 hsp_ne.2.2.1 hsp_ne.2.2.2, e6s_i],
          fun c => by rw [hr12_pre c, er12_i c],
          by rw [hr13_pre, er13_i],
          hSegPres_9 dS_i hd_i hd_ne.1 hd_ne.2.1 hd_ne.2.2.1 hd_ne.2.2.2 _ _ hSegD_i,
          T_sp,
          hSegPres_9 spS_i hsp_i hsp_ne.1 hsp_ne.2.1 hsp_ne.2.2.1 hsp_ne.2.2.2 _ _ hSegSp_i,
          hidle_i⟩
      · have hi_eq : i.val = st.k := by have := i.isLt; dsimp [st_new] at this; omega
        have hnod_last : st_new.nodes i = B_new := by
          change appendChainNode st.nodes B_new i = B_new
          have hfin : i = ⟨st.k, Nat.lt_succ_self st.k⟩ := Fin.ext hi_eq
          rw [hfin]; exact appendChainNode_last st.nodes B_new
        have hage_k : st_new.snAge i = 0 := dif_neg hi
        have hoj_k : st_new.ownedJob i = none := dif_neg hi
        have hS_eq : chainInput P'.handleCoords st_new.nodes P'.activeHandles i.castSucc = S_leaf := by
          have hfin : i = ⟨st.k, Nat.lt_succ_self st.k⟩ := Fin.ext hi_eq
          rw [hfin]
          change chainInput P'.handleCoords (appendChainNode st.nodes B_new) P'.activeHandles
            ⟨st.k, Nat.lt_succ_of_le (Nat.le_succ st.k)⟩ = S_leaf
          rw [cg01_chainInput_append_lt P'.handleCoords st.nodes B_new P'.activeHandles st.k le_rfl,
              ← cg01_chainTerminal_eq]
        rw [hnod_last, hS_eq, hage_k, hoj_k, hi_eq]
        exact ⟨dS, spDS, hdS0, hdS_lt, hsp0, hsp_lt, hd_sp,
          hw13k_9, hw14k_9, hw15k_9, hw6_dS9, hw6_sp9,
          hr12k_9, hr13k_9, hSeg_dS9, S_leaf, hSeg_sp9, fun _ => rfl⟩
    · intro r s hs
      by_cases hr : r.val < st.k
      · rw [hsnSlot_pre r.val hr] at hs
        exact ⟨(hdisj0_1 ⟨r.val, hr⟩ s hs).1, fun heq => hU_rS.2.2.1 r.val hr (heq ▸ hs)⟩
      · have hr_eq : r.val = st.k := by have := r.isLt; dsimp [st_new] at this; omega
        rw [hr_eq, hsnSlot_k] at hs
        simp only [Finset.mem_insert, Finset.mem_singleton] at hs
        rcases hs with rfl | rfl
        · exact ⟨by omega, hd_r⟩
        · exact ⟨by omega, hsp_r⟩
    · intro r₁ r₂ hne
      have hne_val : r₁.val ≠ r₂.val := fun h => hne (Fin.ext h)
      by_cases h1 : r₁.val < st.k <;> by_cases h2 : r₂.val < st.k
      · rw [hsnSlot_pre r₁.val h1, hsnSlot_pre r₂.val h2]
        exact hdisjPair_1 ⟨r₁.val, h1⟩ ⟨r₂.val, h2⟩
          (fun h => hne_val (congrArg (Fin.val (n := st.k)) h))
      · have h2_eq : r₂.val = st.k := by have := r₂.isLt; dsimp [st_new] at this; omega
        rw [hsnSlot_pre r₁.val h1, h2_eq, hsnSlot_k, Finset.disjoint_left]
        intro s hs1 hs2
        simp only [Finset.mem_insert, Finset.mem_singleton] at hs2
        rcases hs2 with rfl | rfl
        · exact hU_dS.2.2.1 r₁.val h1 hs1
        · exact hU_sp.2.2.1 r₁.val h1 hs1
      · have h1_eq : r₁.val = st.k := by have := r₁.isLt; dsimp [st_new] at this; omega
        rw [h1_eq, hsnSlot_k, hsnSlot_pre r₂.val h2, Finset.disjoint_left]
        intro s hs1 hs2
        simp only [Finset.mem_insert, Finset.mem_singleton] at hs1
        rcases hs1 with rfl | rfl
        · exact hU_dS.2.2.1 r₂.val h2 hs2
        · exact hU_sp.2.2.1 r₂.val h2 hs2
      · have h1_eq : r₁.val = st.k := by have := r₁.isLt; dsimp [st_new] at this; omega
        have h2_eq : r₂.val = st.k := by have := r₂.isLt; dsimp [st_new] at this; omega
        omega
  · -- CG01_EncJobs
    rcases hJobs1 with ⟨hbc1, hsp_idle1, hoj1, hdisjG1⟩
    have hw16_toNat1 : (wRead m1 1 6).toNat = leafS := by rw [hw16_1]; simp
    rw [hw16_toNat1] at hdisjG1
    rw [hst'_def]; unfold CG01_EncJobs
    have hw16_toNat9 : (wRead m9 1 6).toNat = rS := by rw [hw16_9]; simp
    rw [hw16_toNat9]
    have hw17_eq := hwJob_9 17 (by decide)
    have hw18_eq := hwJob_9 18 (by decide)
    have hw19_eq := hwJob_9 19 (by decide)
    have hw23_eq := hwJob_9 23 (by decide)
    have hw24_eq := hwJob_9 24 (by decide)
    have hr23_eq := hrJob_9 23 (by decide)
    have hr24_eq := hrJob_9 24 (by decide)
    refine ⟨?_, ?_, ?_, ?_⟩
    · intro i
      by_cases hi : i.val < st.k
      · have hbs : st_new.birthSnap i = st.birthSnap ⟨i.val, hi⟩ := dif_pos hi
        rw [hbs, (hwHdrPre_9 i.val hi).1]; exact hbc1 ⟨i.val, hi⟩
      · have hi_eq : i.val = st.k := by have := i.isLt; dsimp [st_new] at this; omega
        have hbs : st_new.birthSnap i = st.uMap.mapSet S_leaf := dif_neg hi
        rw [hbs, hi_eq, hw12k_9]
        exact_mod_cast (st.uMap.mapSet_bij hS_sub).1.symm
    · intro i hidle
      by_cases hi : i.val < st.k
      · let i_old : Fin st.k := ⟨i.val, hi⟩
        have hoj_eq : st_new.ownedJob i =
            (st.ownedJob i_old).map (fun g =>
              g.castPool (cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new
                st.uMap.ActiveUids i.val (le_of_lt hi)).symm) := dif_pos hi
        have hidle_pre : (st.ownedJob i_old).isNone = true := by
          rw [hoj_eq] at hidle
          cases h_oj : st.ownedJob i_old <;> simp [h_oj] at hidle ⊢
        rcases hsp_idle1 i_old hidle_pre with ⟨spS_i, hlt_i, e15_i, hSeg_i⟩
        have hsp_in : spS_i ∈ snSlotSet m1 i.val := by unfold snSlotSet; rw [e15_i]; simp
        have hS_eq : chainInput P'.handleCoords st_new.nodes P'.activeHandles i.castSucc =
            chainInput P'.handleCoords st.nodes P'.activeHandles i_old.castSucc :=
          cg01_chainInput_append_lt P'.handleCoords st.nodes B_new P'.activeHandles i.val (le_of_lt hi)
        rw [hS_eq]
        exact ⟨spS_i, hlt_i, by rw [(hwHdrPre_9 i.val hi).2.2.2.1, e15_i],
          hSegPres_9 spS_i hlt_i
            (fun h => hU_dS.2.2.1 i.val hi (h ▸ hsp_in))
            (fun h => hU_sp.2.2.1 i.val hi (h ▸ hsp_in))
            (fun h => hU_rS.2.2.1 i.val hi (h ▸ hsp_in))
            (fun h => hU_sr.2.2.1 i.val hi (h ▸ hsp_in)) _ _ hSeg_i⟩
      · have hi_eq : i.val = st.k := by have := i.isLt; dsimp [st_new] at this; omega
        have hS_eq : chainInput P'.handleCoords st_new.nodes P'.activeHandles i.castSucc = S_leaf := by
          have hfin : i = ⟨st.k, Nat.lt_succ_self st.k⟩ := Fin.ext hi_eq
          rw [hfin]
          change chainInput P'.handleCoords (appendChainNode st.nodes B_new) P'.activeHandles
            ⟨st.k, Nat.lt_succ_of_le (Nat.le_succ st.k)⟩ = S_leaf
          rw [cg01_chainInput_append_lt P'.handleCoords st.nodes B_new P'.activeHandles st.k le_rfl,
              ← cg01_chainTerminal_eq]
        rw [hS_eq, hi_eq]
        exact ⟨spDS, hsp_lt, hw15k_9, hSeg_sp9⟩
    · intro i
      by_cases hi : i.val < st.k
      · let i_old : Fin st.k := ⟨i.val, hi⟩
        have hoj_eq : st_new.ownedJob i =
            (st.ownedJob i_old).map (fun g =>
              g.castPool (cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new
                st.uMap.ActiveUids i.val (le_of_lt hi)).symm) := dif_pos hi
        rw [hoj_eq]
        have hS_h : chainInput P'.handleCoords st.nodes P'.activeHandles i_old.castSucc =
            chainInput P'.handleCoords st_new.nodes P'.activeHandles i.castSucc :=
          (cg01_chainInput_append_lt P'.handleCoords st.nodes B_new P'.activeHandles i.val (le_of_lt hi)).symm
        have hS_u : chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids i_old.castSucc =
            chainInput st.uMap.ghostCoords st_new.nodes st.uMap.ActiveUids i.castSucc :=
          (cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new st.uMap.ActiveUids i.val (le_of_lt hi)).symm
        refine (encOwnedJobAt_castPool defaultChainHdrCfg p m9 P' st.uMap i.val hS_h hS_u
          (st.ownedJob i_old)).mpr ?_
        have hoj_pre := hoj1 i_old
        cases hoj_c : st.ownedJob i_old with
        | none =>
            rw [hoj_c] at hoj_pre
            dsimp only [EncOwnedJobAt] at hoj_pre ⊢
            rw [(hwHdrPre_9 i.val hi).2.2.2.2]; exact hoj_pre
        | some g =>
            rw [hoj_c] at hoj_pre
            rcases hoj_pre with ⟨e16, e17, e18, e19, lvs_h, hlen_eq, hlv_all⟩
            refine ⟨by rw [(hwHdrPre_9 i.val hi).2.2.2.2]; exact e16,
              by dsimp only [defaultChainHdrCfg] at e17 ⊢; rw [hw17_eq]; exact e17,
              by dsimp only [defaultChainHdrCfg] at e18 ⊢; rw [hw18_eq]; exact e18,
              by rw [hw19_eq]; exact e19,
              lvs_h, hlen_eq, fun j hj => ?_⟩
            rcases hlv_all j hj with ⟨hb, ho, hbij, hEncLv, hw7, p2, p3, p4, p5, p6, hpre, hlast⟩
            have hj_toNat : j < (wRead m1 19 (i.val : ℤ)).toNat := by rw [e19]; omega
            have hs_disj : ∀ s ∈ jobLevelSlotSet m1 (i.val * p.D₀ + j),
                s ≠ dS ∧ s ≠ spDS ∧ s ≠ rS ∧ s ≠ spRS := fun s hs =>
              ⟨fun h => hU_dS.2.2.2 i.val hi e16 j hj_toNat (h ▸ hs),
               fun h => hU_sp.2.2.2 i.val hi e16 j hj_toNat (h ▸ hs),
               fun h => hU_rS.2.2.2 i.val hi e16 j hj_toNat (h ▸ hs),
               fun h => hU_sr.2.2.2 i.val hi e16 j hj_toNat (h ▸ hs)⟩
            refine ⟨hb, ho, hbij,
              encJobLevel_frame_slotSet hEncLv
                (fun s hs hlt _ _ hE =>
                  hSegPres_9 s hlt (hs_disj s hs).1 (hs_disj s hs).2.1
                    (hs_disj s hs).2.2.1 (hs_disj s hs).2.2.2 _ _ hE)
                (fun s hs =>
                  hw6Pres_9 s (hs_disj s hs).1 (hs_disj s hs).2.1
                    (hs_disj s hs).2.2.1 (hs_disj s hs).2.2.2)
                (fun bS hb_mem hlt hC =>
                  hSlotPres_9 bS hlt (hs_disj bS hb_mem).1 (hs_disj bS hb_mem).2.1
                    (hs_disj bS hb_mem).2.2.1 (hs_disj bS hb_mem).2.2.2 _ _ hC)
                (fun _ _ => hw23_eq _) (fun _ _ => hw24_eq _)
                (fun _ => hr23_eq _) (fun _ _ => hr24_eq _),
              by rw [hw23_eq]; exact hw7,
              by rw [hw23_eq]; exact p2,
              by rw [hw23_eq]; exact p3,
              by rw [hw23_eq]; exact p4,
              by rw [hw23_eq]; exact p5,
              by rw [hw23_eq]; exact p6,
              fun hlt => by rw [hw24_eq]; exact hpre hlt,
              fun heq => ⟨by rw [hw24_eq]; exact (hlast heq).1,
                          by rw [hw24_eq]; exact (hlast heq).2.1,
                          (hlast heq).2.2⟩⟩
      · have hi_eq : i.val = st.k := by have := i.isLt; dsimp [st_new] at this; omega
        have hoj_k : st_new.ownedJob i = none := dif_neg hi
        rw [hoj_k]; dsimp only [EncOwnedJobAt]; rw [hi_eq]; exact hw16k_9
    · have hlive_eq : ∀ idx sp, jobLevelLiveSlots m9 idx sp = jobLevelLiveSlots m1 idx sp := by
        intro idx sp; unfold jobLevelLiveSlots; rw [hw23_eq, hw23_eq, hw23_eq, hw23_eq]
      change GlobalSlotDisj p.D₀ m9 (st.k + 1) rS
      refine ⟨hrS0, ?_, ?_, ?_, ?_⟩
      · intro r hr s hs
        by_cases hlt : r < st.k
        · rw [hsnSlot_pre r hlt] at hs
          exact ⟨(hdisjG1.2.1 r hlt s hs).1, fun heq => hU_rS.2.2.1 r hlt (heq ▸ hs)⟩
        · have hr_eq : r = st.k := by omega
          rw [hr_eq, hsnSlot_k] at hs
          simp only [Finset.mem_insert, Finset.mem_singleton] at hs
          rcases hs with rfl | rfl
          · exact ⟨by omega, hd_r⟩
          · exact ⟨by omega, hsp_r⟩
      · intro r₁ hr₁ r₂ hr₂ hne
        by_cases h1 : r₁ < st.k <;> by_cases h2 : r₂ < st.k
        · rw [hsnSlot_pre r₁ h1, hsnSlot_pre r₂ h2]
          exact hdisjG1.2.2.1 r₁ h1 r₂ h2 hne
        · have h2_eq : r₂ = st.k := by omega
          rw [hsnSlot_pre r₁ h1, h2_eq, hsnSlot_k, Finset.disjoint_left]
          intro s hs1 hs2
          simp only [Finset.mem_insert, Finset.mem_singleton] at hs2
          rcases hs2 with rfl | rfl
          · exact hU_dS.2.2.1 r₁ h1 hs1
          · exact hU_sp.2.2.1 r₁ h1 hs1
        · have h1_eq : r₁ = st.k := by omega
          rw [h1_eq, hsnSlot_k, hsnSlot_pre r₂ h2, Finset.disjoint_left]
          intro s hs1 hs2
          simp only [Finset.mem_insert, Finset.mem_singleton] at hs1
          rcases hs1 with rfl | rfl
          · exact hU_dS.2.2.1 r₂ h2 hs2
          · exact hU_sp.2.2.1 r₂ h2 hs2
        · omega
      · intro r hr h16 j hj
        have hlt : r < st.k := by
          by_contra hge; have hr_eq : r = st.k := by omega
          rw [hr_eq, hw16k_9] at h16; omega
        have h16_1 : wRead m1 16 (r : ℤ) = 1 := by rw [← (hwHdrPre_9 r hlt).2.2.2.2]; exact h16
        rw [hw19_eq] at hj ⊢
        rw [hlive_eq]
        have hsub := cg01_jobLevelLiveSlots_subset_slotSet m1 (r * p.D₀ + j)
          (decide (j + 1 = (wRead m1 19 (r : ℤ)).toNat))
        refine ⟨fun s hs =>
          ⟨((hdisjG1.2.2.2.1 r hlt h16_1 j hj).1 s hs).1,
           fun heq => hU_rS.2.2.2 r hlt h16_1 j hj (hsub (heq ▸ hs))⟩, ?_⟩
        intro r' hr'
        by_cases hr'_lt : r' < st.k
        · rw [hsnSlot_pre r' hr'_lt]
          exact (hdisjG1.2.2.2.1 r hlt h16_1 j hj).2 r' hr'_lt
        · have hr'_eq : r' = st.k := by omega
          rw [hr'_eq, hsnSlot_k, Finset.disjoint_left]
          intro s hs1 hs2
          simp only [Finset.mem_insert, Finset.mem_singleton] at hs2
          rcases hs2 with rfl | rfl
          · exact hU_dS.2.2.2 r hlt h16_1 j hj (hsub hs1)
          · exact hU_sp.2.2.2 r hlt h16_1 j hj (hsub hs1)
      · intro r₁ hr₁ h16_1' j₁ hj₁ r₂ hr₂ h16_2' j₂ hj₂ hne
        have hlt₁ : r₁ < st.k := by
          by_contra hge; have : r₁ = st.k := by omega
          rw [this, hw16k_9] at h16_1'; omega
        have hlt₂ : r₂ < st.k := by
          by_contra hge; have : r₂ = st.k := by omega
          rw [this, hw16k_9] at h16_2'; omega
        have h16_1a : wRead m1 16 (r₁ : ℤ) = 1 := by rw [← (hwHdrPre_9 r₁ hlt₁).2.2.2.2]; exact h16_1'
        have h16_2a : wRead m1 16 (r₂ : ℤ) = 1 := by rw [← (hwHdrPre_9 r₂ hlt₂).2.2.2.2]; exact h16_2'
        rw [hw19_eq] at hj₁ hj₂
        rw [hw19_eq, hw19_eq, hlive_eq, hlive_eq, hw23_eq, hw23_eq]
        exact hdisjG1.2.2.2.2 r₁ hlt₁ h16_1a j₁ hj₁ r₂ hlt₂ h16_2a j₂ hj₂ hne

end UL.Proof_lem_7_2_RacerP46
