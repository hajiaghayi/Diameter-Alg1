import UL.Proof.lem_7_2.CG03_JobTickA3c2a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 2a. Tail Header Writes for `launchPendingJobAtRStmt` -/

lemma launchTail_exec (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    (i H_job0 : ℕ) (hi_D0 : i < ctx.p.D₀) (hi_box : i < ctx.M_box)
    (m8 : ArithRAMMemory) (hpop8 : m8.popDepth 0 = m8)
    (hw15_8 : wRead m8 26 15 = (i : ℤ))
    (hw25_8 : wRead m8 26 25 = (H_job0 : ℤ)) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp
        (seqList [
          boxWriteW ctx.M_box 16 (.readHeap 26 (.lit 15)) (.lit 1),
          ctx.cfg.jobRem.writeW ctx.M_box (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 25)),
          ctx.cfg.jobClosed.writeW ctx.M_box (.readHeap 26 (.lit 15)) (.lit 0),
          boxWriteW ctx.M_box 19 (.readHeap 26 (.lit 15)) (.lit 1),
          .localScope .skip
        ]) m8 m' 150 ∧
      m'.popDepth 0 = m' ∧
      (∀ t ∈ reservedWordTags, t ≠ 16 → t ≠ 19 → ∀ idx, wRead m' t idx = wRead m8 t idx) ∧
      (∀ t idx, rRead m' t idx = rRead m8 t idx) ∧
      wRead m' 16 (i : ℤ) = 1 ∧
      (∀ r, r ≠ i → wRead m' 16 (r : ℤ) = wRead m8 16 (r : ℤ)) ∧
      wRead m' 19 (i : ℤ) = 1 ∧
      (∀ r, r ≠ i → wRead m' 19 (r : ℤ) = wRead m8 19 (r : ℤ)) ∧
      wRead m' ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) = (H_job0 : ℤ) ∧
      (∀ r, r ≠ i → wRead m' ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) =
        wRead m8 ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ)) ∧
      wRead m' ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx i : ℤ) = 0 ∧
      (∀ r, r ≠ i → wRead m' ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ) =
        wRead m8 ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ)) ∧
      (∀ f : HdrField, f.WF ctx.T_max → f.tag ∉ reservedWordTags →
        HdrField.Disj f ctx.cfg.jobRem → HdrField.Disj f ctx.cfg.jobClosed →
        ∀ r, wRead m' f.tag (f.idx r : ℤ) = wRead m8 f.tag (f.idx r : ℤ)) := by
  have hidx_box := ChainHdrCfg.idx_lt_box ctx.hV ctx.hBox_hdr hi_D0
  rcases ctx.hV with ⟨_, _, _, _, hWF_rem, hWF_cl,
    _, _, _, hRes_rem, hRes_cl,
    _, _, _, _, _, _, _, _, _, hd_rem_cl,
    _, _, _, _, _⟩
  have hrem_ne26 := tag_ne_of_not_reserved (u := 26) hRes_rem (by decide)
  have hcl_ne26 := tag_ne_of_not_reserved (u := 26) hRes_cl (by decide)
  let s9 := wWrite m8 16 (i : ℤ) 1
  have e9 : DetExecAt 0 inp (boxWriteW ctx.M_box 16 (.readHeap 26 (.lit 15)) (.lit 1)) m8 s9 16 :=
    exec_boxWriteW inp m8 _ _ (by simp [hw15_8]) (by positivity) (by exact_mod_cast hi_box) rfl (by simp [intExprOps])
  let s10 := wWrite s9 ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) (H_job0 : ℤ)
  have e10 : DetExecAt 0 inp (ctx.cfg.jobRem.writeW ctx.M_box (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 25))) s9 s10 35 :=
    exec_hdrWriteW inp s9 ctx.cfg.jobRem _ _
      (by dsimp only [s9]; rw [iValAt_readHeap, iValAt_lit, wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hw15_8])
      hidx_box.2.2.2.1
      (by dsimp only [s9]; rw [iValAt_readHeap, iValAt_lit, wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hw25_8])
      (by simp [intExprOps])
  let s11 := wWrite s10 ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx i : ℤ) 0
  have e11 : DetExecAt 0 inp (ctx.cfg.jobClosed.writeW ctx.M_box (.readHeap 26 (.lit 15)) (.lit 0)) s10 s11 35 :=
    exec_hdrWriteW inp s10 ctx.cfg.jobClosed _ _
      (by dsimp only [s10, s9]; rw [iValAt_readHeap, iValAt_lit, wRead_wWrite_of_ne _ _ (Or.inl hrem_ne26.symm), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hw15_8])
      hidx_box.2.2.2.2.1 rfl (by simp [intExprOps])
  let m' := wWrite s11 19 (i : ℤ) 1
  have e12 : DetExecAt 0 inp (boxWriteW ctx.M_box 19 (.readHeap 26 (.lit 15)) (.lit 1)) s11 m' 16 :=
    exec_boxWriteW inp s11 _ _
      (by dsimp only [s11, s10, s9]; rw [iValAt_readHeap, iValAt_lit, wRead_wWrite_of_ne _ _ (Or.inl hcl_ne26.symm), wRead_wWrite_of_ne _ _ (Or.inl hrem_ne26.symm), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hw15_8])
      (by positivity) (by exact_mod_cast hi_box) rfl (by simp [intExprOps])
  have hpop' : m'.popDepth 0 = m' :=
    wWrite_popDepth_zero (wWrite_popDepth_zero (wWrite_popDepth_zero (wWrite_popDepth_zero hpop8 16 _ _) _ _ _) _ _ _) 19 _ _
  have e13 : DetExecAt 0 inp (.localScope .skip) m' m' 10 := by
    have h0 := exec_popScopeZero inp m'; rw [hpop'] at h0; exact h0.mono_cost (by omega)
  refine ⟨m', (e9.seq (e10.seq (e11.seq (e12.seq e13)))).mono_cost (by omega), hpop',
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro t ht h16 h19 idx; dsimp only [m', s11, s10, s9]
    rw [wRead_wWrite_of_ne _ _ (Or.inl h19),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_cl ht).symm),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_rem ht).symm),
        wRead_wWrite_of_ne _ _ (Or.inl h16)]
  · intro t idx; dsimp only [m', s11, s10, s9]
    rw [rRead_wWrite, rRead_wWrite, rRead_wWrite, rRead_wWrite]
  · dsimp only [m', s11, s10, s9]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 16) hRes_cl (by decide)).symm),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 16) hRes_rem (by decide)).symm),
        wRead_wWrite_self]
  · intro r hne; have hz : (r : ℤ) ≠ (i : ℤ) := fun h => hne (Int.ofNat.inj h)
    dsimp only [m', s11, s10, s9]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 16) hRes_cl (by decide)).symm),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 16) hRes_rem (by decide)).symm),
        wRead_wWrite_of_ne _ _ (Or.inr hz)]
  · dsimp only [m']; rw [wRead_wWrite_self]
  · intro r hne; have hz : (r : ℤ) ≠ (i : ℤ) := fun h => hne (Int.ofNat.inj h)
    dsimp only [m', s11, s10, s9]
    rw [wRead_wWrite_of_ne _ _ (Or.inr hz),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 19) hRes_cl (by decide)).symm),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 19) hRes_rem (by decide)).symm),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
  · dsimp only [m', s11, s10]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 19) hRes_rem (by decide))),
        wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_rem hWF_cl hd_rem_cl i i),
        wRead_wWrite_self]
  · intro r hne; dsimp only [m', s11, s10, s9]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 19) hRes_rem (by decide))),
        wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_rem hWF_cl hd_rem_cl r i),
        wRead_wWrite_of_ne _ _ (Or.inr (HdrField.ne_same_field hWF_rem hne)),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 16) hRes_rem (by decide)))]
  · dsimp only [m', s11]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 19) hRes_cl (by decide))),
        wRead_wWrite_self]
  · intro r hne; dsimp only [m', s11, s10, s9]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 19) hRes_cl (by decide))),
        wRead_wWrite_of_ne _ _ (Or.inr (HdrField.ne_same_field hWF_cl hne)),
        wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_cl hWF_rem hd_rem_cl.symm r i),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 16) hRes_cl (by decide)))]
  · intro f hwf hf hd_rem hd_cl r; dsimp only [m', s11, s10, s9]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 19) hf (by decide))),
        wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf hWF_cl hd_cl r i),
        wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf hWF_rem hd_rem r i),
        wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved (u := 16) hf (by decide)))]

end UL.Proof_lem_7_2_RacerP46
