import UL.Proof.lem_7_2.RacerP46_H3b_BaselineAndLeaf
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Pure Helpers for Residual Propagation & Two-Stage Ball Fallback -/

lemma mem_nodeCore_iff_distSq_le {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (B : ChainNode d) (S : Finset ι) (x : ι) :
    x ∈ B.core pts S ↔ x ∈ S ∧ euclideanDistSq (pts x) B.o ≤ B.V := by
  unfold ChainNode.core nodeCore
  simp only [Finset.mem_filter]
  rw [mem_coreBall_iff_norm_sq_le B.o (pts x) B.V_nonneg]
  simp [euclideanDistSq]

lemma mem_nodeResidual_iff_distSq_gt {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (B : ChainNode d) (S : Finset ι) (x : ι) :
    x ∈ B.residual pts S ↔ x ∈ S ∧ ¬ (euclideanDistSq (pts x) B.o ≤ B.V) := by
  classical
  change x ∈ S \ B.core pts S ↔ _
  simp only [Finset.mem_sdiff, mem_nodeCore_iff_distSq_le]
  constructor
  · rintro ⟨hx, hnot⟩
    exact ⟨hx, fun hle => hnot ⟨hx, hle⟩⟩
  · rintro ⟨hx, hnot⟩
    exact ⟨hx, fun ⟨_, hle⟩ => hnot hle⟩

lemma nodeResidual_insert {d : ℕ} {ι : Type} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d)) (B : ChainNode d) (S : Finset ι) (x : ι) :
    B.residual pts (insert x S) =
      if euclideanDistSq (pts x) B.o ≤ B.V then B.residual pts S
      else insert x (B.residual pts S) := by
  ext y
  split_ifs with hle
  · simp only [mem_nodeResidual_iff_distSq_gt, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hy, hgt⟩
      · exact False.elim (hgt hle)
      · exact ⟨hy, hgt⟩
    · rintro ⟨hy, hgt⟩
      exact ⟨Or.inr hy, hgt⟩
  · simp only [mem_nodeResidual_iff_distSq_gt, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hy, hgt⟩
      · exact Or.inl rfl
      · exact Or.inr ⟨hy, hgt⟩
    · rintro (rfl | ⟨hy, hgt⟩)
      · exact ⟨Or.inl rfl, hle⟩
      · exact ⟨Or.inr hy, hgt⟩

lemma nodeResidual_erase {d : ℕ} {ι : Type} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d)) (B : ChainNode d) (S : Finset ι) (x : ι) :
    B.residual pts (S.erase x) =
      if euclideanDistSq (pts x) B.o ≤ B.V then B.residual pts S
      else (B.residual pts S).erase x := by
  ext y
  split_ifs with hle
  · simp only [mem_nodeResidual_iff_distSq_gt, Finset.mem_erase]
    constructor
    · rintro ⟨⟨_, hy⟩, hgt⟩
      exact ⟨hy, hgt⟩
    · rintro ⟨hy, hgt⟩
      refine ⟨⟨?_, hy⟩, hgt⟩
      intro rfl
      exact hgt hle
  · simp only [mem_nodeResidual_iff_distSq_gt, Finset.mem_erase]
    constructor
    · rintro ⟨⟨hne, hy⟩, hgt⟩
      exact ⟨hne, hy, hgt⟩
    · rintro ⟨hne, hy, hgt⟩
      exact ⟨⟨hne, hy⟩, hgt⟩

lemma nodeMaxRadius_sq_eq_sup_distSq {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {S : Finset ι} (hne : S.Nonempty) :
    (nodeMaxRadius pts o S) ^ 2 = S.sup' hne (fun x => euclideanDistSq (pts x) o) := by
  rcases Finset.exists_mem_eq_sup' hne (fun x => ‖pts x - o‖) with ⟨xm, hxm, hsup_n⟩
  have hmax_r : nodeMaxRadius pts o S = ‖pts xm - o‖ := by
    dsimp [nodeMaxRadius]
    rw [dif_pos hne]
    exact hsup_n
  rw [hmax_r]
  apply le_antisymm
  · have hle := Finset.le_sup' (fun x => euclideanDistSq (pts x) o) hxm
    simpa [euclideanDistSq] using hle
  · rw [Finset.sup'_le_iff]
    intro x hx
    have hnx : ‖pts x - o‖ ≤ ‖pts xm - o‖ := by
      rw [← hsup_n]
      exact Finset.le_sup' (fun y => ‖pts y - o‖) hx
    have h0 : 0 ≤ ‖pts x - o‖ := norm_nonneg _
    have hsq : ‖pts x - o‖ ^ 2 ≤ ‖pts xm - o‖ ^ 2 :=
      pow_le_pow_left₀ h0 hnx 2
    simpa [euclideanDistSq] using hsq

lemma applyBirthCoreFallback_eq_nat {d D : ℕ} (hD : 3 ≤ D)
    {ι : Type} (pts : ι → EuclideanSpace ℝ (Fin d))
    {S_birth : Finset ι} (hne : S_birth.Nonempty)
    (prov : ChainNode d)
    {maxSq : ℝ}
    (hmaxSq : maxSq = S_birth.sup' hne (fun x => euclideanDistSq (pts x) prov.o))
    (_hmaxSq_nn : 0 ≤ maxSq) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    let ball := applyBirthCoreFallback α pts S_birth prov
    ball.o = prov.o ∧
    ball.V = (if S_birth.card ≤ 8 * D ^ 2 * (prov.core pts S_birth).card
              then prov.V else maxSq) := by
  intro α ball
  have hiff := passesBirthCoreCheck_iff_nat D hD pts prov S_birth
  dsimp only [ball, applyBirthCoreFallback]
  by_cases hpass : PassesBirthCoreCheck α pts prov S_birth
  · have hnat : S_birth.card ≤ 8 * D ^ 2 * (prov.core pts S_birth).card := hiff.mp hpass
    simp [hpass, hnat]
  · have hnat : ¬ (S_birth.card ≤ 8 * D ^ 2 * (prov.core pts S_birth).card) :=
      fun h => hpass (hiff.mpr h)
    rw [if_neg hpass, if_neg hnat]
    exact ⟨rfl, (nodeMaxRadius_sq_eq_sup_distSq pts prov.o hne).trans hmaxSq.symm⟩

lemma selectOpenedLevelBall_bij_uid {d : ℕ}
    (α : ℝ)
    (snapPts : ℕ → EuclideanSpace ℝ (Fin d))
    (ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S_h S_uid : Finset ℕ)
    (f g : ℕ → ℕ)
    (hf : ∀ h ∈ S_h, f h ∈ S_uid ∧ ghostCoords (f h) = snapPts h ∧ g (f h) = h)
    (hg : ∀ u ∈ S_uid, g u ∈ S_h ∧ f (g u) = u)
    {bId : ℕ} (hb : bId ∈ S_h)
    (o_cand : EuclideanSpace ℝ (Fin d)) (s_cand : ℝ) :
    selectOpenedLevelBall α snapPts S_h bId (.candidate o_cand (liftVariance o_cand s_cand)) =
      selectOpenedLevelBall α ghostCoords S_uid (f bId)
        (.candidate o_cand (liftVariance o_cand s_cand)) := by
  have hcard_eq : S_h.card = S_uid.card := by
    refine Finset.card_bij (fun h _ => f h) (fun h hh => (hf h hh).1) ?_ ?_
    · intro x hx y hy heq
      have := congrArg g heq
      rwa [(hf x hx).2.2, (hf y hy).2.2] at this
    · intro u hu; exact ⟨g u, (hg u hu).1, (hg u hu).2⟩
  have hprov_eq :
      provisionalCenter snapPts bId (.candidate o_cand (liftVariance o_cand s_cand)) =
        provisionalCenter ghostCoords (f bId) (.candidate o_cand (liftVariance o_cand s_cand)) := by
    unfold provisionalCenter
    by_cases hV : 0 ≤ liftVariance o_cand s_cand
    · simp [hV]
    · simp [hV, (hf bId hb).2.1]
  unfold selectOpenedLevelBall applyBirthCoreFallback
  rw [← hprov_eq]
  set prov := provisionalCenter snapPts bId (.candidate o_cand (liftVariance o_cand s_cand))
  have hcore_card :
      (prov.core snapPts S_h).card = (prov.core ghostCoords S_uid).card := by
    refine Finset.card_bij (fun h _ => f h) ?_ ?_ ?_
    · intro h hh
      rw [mem_nodeCore_iff_distSq_le] at hh ⊢
      exact ⟨(hf h hh.1).1, by rw [(hf h hh.1).2.1]; exact hh.2⟩
    · intro x hx y hy heq
      rw [mem_nodeCore_iff_distSq_le] at hx hy
      have := congrArg g heq
      rwa [(hf x hx.1).2.2, (hf y hy.1).2.2] at this
    · intro u hu
      rw [mem_nodeCore_iff_distSq_le] at hu
      have hgu := (hg u hu.1).1
      refine ⟨g u, ?_, (hg u hu.1).2⟩
      rw [mem_nodeCore_iff_distSq_le]
      have hpt : snapPts (g u) = ghostCoords u := by
        have h1 := (hf (g u) hgu).2.1
        rw [(hg u hu.1).2] at h1
        exact h1.symm
      exact ⟨hgu, by rw [hpt]; exact hu.2⟩
  have hpass_iff :
      PassesBirthCoreCheck α snapPts prov S_h ↔
        PassesBirthCoreCheck α ghostCoords prov S_uid := by
    unfold PassesBirthCoreCheck
    rw [hcard_eq, hcore_card]
  have hmax_eq :
      nodeMaxRadius snapPts prov.o S_h = nodeMaxRadius ghostCoords prov.o S_uid :=
    nodeMaxRadius_bij snapPts ghostCoords prov.o S_h S_uid f g
      (fun h hh => ⟨(hf h hh).1, (hf h hh).2.1⟩) hg
  by_cases hp : PassesBirthCoreCheck α snapPts prov S_h
  · simp [hp, hpass_iff.mp hp]
  · have hp2 : ¬ PassesBirthCoreCheck α ghostCoords prov S_uid := fun h => hp (hpass_iff.mpr h)
    simp [hp, hp2, maxBirthRadiusBall, hmax_eq]

/-! ### 2. `fd = 0` Segment Tree Update Wrappers (`updSegZeroStmt` and `updSegCenterStmt`) -/

/-- Update live segment-tree slot `s = wRead mem 26 3` (`ins = (wRead mem 26 5 == 1)`) at handle
`h = wRead mem 26 4` with constant key `0`. -/
def updSegZeroStmt (K M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 3)),
    .writeWordLocal 28 (.lit 21) (.readHeap 26 (.lit 4)),
    .writeWordLocal 28 (.lit 22) (.readHeap 26 (.lit 5)),
    .writeRealLocal 28 (.lit 20) (.ofInt (.lit 0)),
    updLeafSegSlotStmt K M_box
  ])

theorem boxSafe_updSegZeroStmt {T_max M_box : ℕ} (hT : 11 ≤ T_max) (K : ℕ) :
    BoxSafeOuter T_max M_box (updSegZeroStmt K M_box) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .writeRealLocal _ _ _
  · exact boxSafe_updLeafSegSlotStmt hT _

theorem exec_updSegZeroStmt {d K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s h : ℕ} {ins : Bool} {S : Finset ℕ}
    (hs : s < NumSlots) (hh : h < 2 ^ K)
    (hMs : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (hs_reg : wRead mem 26 3 = (s : ℤ))
    (hh_reg : wRead mem 26 4 = (h : ℤ))
    (hins_reg : wRead mem 26 5 = (if ins then 1 else 0))
    (hgen : SegGenBound K NumSlots mem)
    (hEnc : EncSegSlot K mem s S (fun _ => 0)) :
    let S' : Finset ℕ := if ins then insert h S else S.erase h
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (updSegZeroStmt K M_box) mem m' (220 * (K + 1) + 40) ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      EncSegSlot K m' s S' (fun _ => 0) ∧
      (∀ s' < NumSlots, s' ≠ s → ∀ S₁ fSq₁,
        EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ t, t ≠ 8 → ∀ idx, rRead m' t idx = rRead mem t idx) := by
  intro S'
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 28 20 (s : ℤ)
  let m2 := wWriteL 1 m1 28 21 (h : ℤ)
  let m3 := wWriteL 1 m2 28 22 (if ins then 1 else 0)
  let m4 := rWriteL 1 m3 28 20 0
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 3))) m0 m1 6 :=
    DetExecAt.writeWordLocal 1 inp m0 28 _ _ rfl (by simp [m0, hs_reg]) (by simp [intExprOps])
  have hs2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readHeap 26 (.lit 4))) m1 m2 6 :=
    DetExecAt.writeWordLocal 1 inp m1 28 _ _ rfl (by simp [m1, m0, hh_reg]) (by simp [intExprOps])
  have hs3 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 22) (.readHeap 26 (.lit 5))) m2 m3 6 :=
    DetExecAt.writeWordLocal 1 inp m2 28 _ _ rfl (by simp [m2, m1, m0, hins_reg]) (by simp [intExprOps])
  have hs4 : DetExecAt 1 inp (.writeRealLocal 28 (.lit 20) (.ofInt (.lit 0))) m3 m4 4 :=
    DetExecAt.writeRealLocal 1 inp m3 28 _ _ rfl (by simp) (by simp [intExprOps, realExprOps])
  have hgen_m4 : SegGenBound K NumSlots m4 :=
    ⟨by simp [m4, m3, m2, m1, m0]; exact hgen.1,
     fun s' hs' => by simp [m4, m3, m2, m1, m0]; exact hgen.2.1 s' hs',
     fun s' hs' u hu => by simp [m4, m3, m2, m1, m0]; exact hgen.2.2 s' hs' u hu⟩
  have hEnc_m4 : EncSegSlot K m4 s S (fun _ => 0) :=
    hEnc.congr_mem_fSq (by simp [m4, m3, m2, m1, m0]) (fun _ _ => by simp [m4, m3, m2, m1, m0])
      (fun _ _ => by simp [m4, m3, m2, m1, m0]) (fun _ _ => by simp [m4, m3, m2, m1, m0])
      (fun _ _ => by simp [m4, m3, m2, m1, m0]) (fun _ _ => rfl)
  rcases exec_updLeafSegSlotStmt inp m4 (ins := ins) (rSq := 0) (fSq' := fun _ => 0) hs hh hMs
      (by simp [m4, m3, m2, m1]) (by simp [m4, m3, m2]) (by simp [m4, m3]) (by simp [m4])
      (fun _ => rfl) (fun _ _ _ => rfl) hgen_m4 hEnc_m4
    with ⟨m5, hs5, hgen5, hEnc5, hOther5, hw5, hr5, _, _⟩
  refine ⟨m5.popDepth 0,
    DetExecAt.localScope ((hs1.seq (hs2.seq (hs3.seq (hs4.seq hs5)))).mono_cost (by omega)),
    popDepth_zero_idem m5,
    ⟨by simp; exact hgen5.1,
     fun s' hs' => by simp; exact hgen5.2.1 s' hs',
     fun s' hs' u hu => by simp; exact hgen5.2.2 s' hs' u hu⟩,
    hEnc5.congr_mem_fSq (by simp) (fun _ _ => by simp) (fun _ _ => by simp)
      (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
    fun s' hs' hne S₁ fSq₁ h1 => by
      have h1_m4 : EncSegSlot K m4 s' S₁ fSq₁ :=
        h1.congr_mem_fSq (by simp [m4, m3, m2, m1, m0]) (fun _ _ => by simp [m4, m3, m2, m1, m0])
          (fun _ _ => by simp [m4, m3, m2, m1, m0]) (fun _ _ => by simp [m4, m3, m2, m1, m0])
          (fun _ _ => by simp [m4, m3, m2, m1, m0]) (fun _ _ => rfl)
      exact (hOther5 s' hs' hne S₁ fSq₁ h1_m4).congr_mem_fSq
        (by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp)
        (fun _ _ => by simp) (fun _ _ => rfl),
    fun t h8 h9 h10 idx => by simp [hw5 t h8 h9 h10, m4, m3, m2, m1, m0],
    fun t h8 idx => by simp [hr5 t h8, m4, m3, m2, m1, m0]⟩

/-- Update live segment-tree slot `s = wRead mem 26 3` (`ins = (wRead mem 26 5 == 1)`) at handle
`h = wRead mem 26 4` with squared distance `rSq = euclideanDistSq (livePts h) o` (where `o` is stored
at `rRead mem rTag [oBase .. oBase + d - 1]`, `oBase = wRead mem 26 6`), AND write `rSq` into
`rRead _ 26 0` when `ins = true` (or always when `h ∈ activeH`). -/
def updSegCenterStmt (d K M_box rTag : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
      (seqList [
        .writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 4)) (.lit (d : ℤ))),
        loadHeapCoordsToLocalStmt d 4 18 0,
        .writeWordLocal 29 (.lit 18) (.readHeap 26 (.lit 6)),
        loadHeapCoordsToLocalStmt d rTag 18 (d : ℤ),
        distSqLocalStmt d,
        .writeRealLocal 28 (.lit 20) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))),
        boxWriteR M_box 26 (.lit 0) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))
      ])
      (.writeRealLocal 28 (.lit 20) (.ofInt (.lit 0))),
    .writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 3)),
    .writeWordLocal 28 (.lit 21) (.readHeap 26 (.lit 4)),
    .writeWordLocal 28 (.lit 22) (.readHeap 26 (.lit 5)),
    updLeafSegSlotStmt K M_box
  ])

theorem boxSafe_updSegCenterStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (d K rTag : ℕ) :
    BoxSafeOuter T_max M_box (updSegCenterStmt d K M_box rTag) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl
  · refine .ite _ (boxSafeInner_seqList ?_) (.writeRealLocal _ _ _)
    intro s' hs'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
    · exact boxSafe_distSqLocalStmt _
    · exact .writeRealLocal _ _ _
    · exact .boxR (by omega) _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact boxSafe_updLeafSegSlotStmt (by omega) _

theorem exec_updSegCenterStmt {d n K NumSlots M_box rTag : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s h oBase : ℕ} {ins : Bool} {o : EuclideanSpace ℝ (Fin d)}
    {activeH : Finset ℕ} {livePts livePts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ}
    (hs : s < NumSlots) (hh : h < 2 ^ K)
    (hBox1 : 4 ≤ M_box) (hMs : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (_hrTag_ne : rTag ≠ 8 ∧ rTag ≠ 26)
    (hs_reg : wRead mem 26 3 = (s : ℤ))
    (hh_reg : wRead mem 26 4 = (h : ℤ))
    (hins_reg : wRead mem 26 5 = (if ins then 1 else 0))
    (hoBase_reg : wRead mem 26 6 = (oBase : ℤ))
    (ho_heap : ∀ c : Fin d, rRead mem rTag (((oBase + c.val : ℕ) : ℤ)) = euclideanCoord o c)
    (hLive' : EncLiveCoords d n mem activeH livePts')
    (hh_act : ins = true → h ∈ activeH)
    (hlive_other : ∀ x ∈ S, x ≠ h → livePts' x = livePts x)
    (hgen : SegGenBound K NumSlots mem)
    (hEnc : EncSegSlot K mem s S (fun x => euclideanDistSq (livePts x) o)) :
    let S' : Finset ℕ := if ins then insert h S else S.erase h
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (updSegCenterStmt d K M_box rTag) mem m'
        (220 * (K + 1) + 120 * (d + 1) + 100) ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      EncSegSlot K m' s S' (fun x => euclideanDistSq (livePts' x) o) ∧
      (ins = true → rRead m' 26 0 = euclideanDistSq (livePts' h) o) ∧
      (∀ s' < NumSlots, s' ≠ s → ∀ S₁ fSq₁,
        EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ t, t ≠ 8 → t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx) ∧
      (∀ idx, idx ≠ 0 → rRead m' 26 idx = rRead mem 26 idx) := by
  intro S'
  let m0 := mem.popDepth 0
  let rSqVal : ℝ := if ins then euclideanDistSq (livePts' h) o else 0
  have hPre : ∃ ma : ArithRAMMemory,
      DetExecAt 1 inp
        (.ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
          (seqList [
            .writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 4)) (.lit (d : ℤ))),
            loadHeapCoordsToLocalStmt d 4 18 0,
            .writeWordLocal 29 (.lit 18) (.readHeap 26 (.lit 6)),
            loadHeapCoordsToLocalStmt d rTag 18 (d : ℤ),
            distSqLocalStmt d,
            .writeRealLocal 28 (.lit 20) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))),
            boxWriteR M_box 26 (.lit 0) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))
          ])
          (.writeRealLocal 28 (.lit 20) (.ofInt (.lit 0))))
        m0 ma (100 * (d + 1) + 60) ∧
      rReadL 1 ma 28 20 = rSqVal ∧
      (ins = true → rRead ma 26 0 = euclideanDistSq (livePts' h) o) ∧
      (∀ t idx, wRead ma t idx = wRead mem t idx) ∧
      (∀ t, t ≠ 26 → ∀ idx, rRead ma t idx = rRead mem t idx) ∧
      (∀ idx, idx ≠ 0 → rRead ma 26 idx = rRead mem 26 idx) := by
    cases ins with
    | false =>
        have hcond : cValAt 1 inp m0 (.intEq (.readHeap 26 (.lit 5)) (.lit 1)) = false := by
          simp [m0, hins_reg]
        let ma := rWriteL 1 m0 28 20 0
        have hs1 : DetExecAt 1 inp (.writeRealLocal 28 (.lit 20) (.ofInt (.lit 0))) m0 ma 4 :=
          DetExecAt.writeRealLocal 1 inp m0 28 _ _ rfl (by simp) (by simp [intExprOps, realExprOps])
        exact ⟨ma,
          (DetExecAt.ite_false hcond (C_c := 10) (by simp [condExprOps, intExprOps]) hs1).mono_cost (by omega),
          by simp [ma, rSqVal],
          (fun h => by cases h),
          (fun t idx => by simp [ma, m0]),
          (fun t _ idx => by simp [ma, m0]),
          (fun idx _ => by simp [ma, m0])⟩
    | true =>
        have hcond : cValAt 1 inp m0 (.intEq (.readHeap 26 (.lit 5)) (.lit 1)) = true := by
          simp [m0, hins_reg]
        have hh_in : h ∈ activeH := hh_act rfl
        let ma1 := wWriteL 1 m0 29 18 (((h * d : ℕ) : ℤ))
        have hb1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 4)) (.lit (d : ℤ))))
            m0 ma1 8 := by
          refine DetExecAt.writeWordLocal 1 inp m0 29 _ _ rfl ?_ (by simp [intExprOps])
          simp [m0, hh_reg]
        rcases exec_loadHeapCoordsToLocalStmt inp ma1 (rTag := 4) (idxBase := 18) (destOff := 0)
            (base := h * d) (pt := livePts' h) (by decide) (by simp [ma1])
            (fun c => by simp only [ma1, m0, rRead_wWriteL, rRead_popDepth]; exact hLive'.2 h hh_in c)
          with ⟨ma2, hb2, hh_loc, hw_a2, hr_a2, _, _, _, _⟩
        let ma3 := wWriteL 1 ma2 29 18 (oBase : ℤ)
        have hb3 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.readHeap 26 (.lit 6))) ma2 ma3 6 :=
          DetExecAt.writeWordLocal 1 inp ma2 29 _ _ rfl
            (by simp [hw_a2, ma1, m0, hoBase_reg]) (by simp [intExprOps])
        rcases exec_loadHeapCoordsToLocalStmt inp ma3 (rTag := rTag) (idxBase := 18) (destOff := (d : ℤ))
            (base := oBase) (pt := o) (by decide) (by simp [ma3])
            (fun c => by simp only [ma3, rRead_wWriteL, hr_a2, ma1, m0, rRead_popDepth]; exact ho_heap c)
          with ⟨ma4, hb4, ho_loc, hw_a4, hr_a4, _, hrl_a4, _, _⟩
        have hh_ma4 : ∀ c : Fin d, rReadL 1 ma4 29 (c.val : ℤ) = euclideanCoord (livePts' h) c := by
          intro c
          rw [hrl_a4 (c.val : ℤ) (Or.inl (by have := c.isLt; omega))]
          simpa [ma3] using hh_loc c
        rcases exec_distSqLocalStmt inp ma4 hh_ma4
            (fun c => by simpa [Nat.cast_add] using ho_loc c)
          with ⟨ma5, hb5, hdsq_a5, hw_a5, hr_a5, _, _, _, _⟩
        let dSq := euclideanDistSq (livePts' h) o
        let ma6 := rWriteL 1 ma5 28 20 dSq
        let ma7 := rWrite ma6 26 0 dSq
        have hb6 : DetExecAt 1 inp
            (.writeRealLocal 28 (.lit 20) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))) ma5 ma6 6 :=
          DetExecAt.writeRealLocal 1 inp ma5 28 _ _ rfl
            (by simp only [rValAt_readRealLocal, iValAt_lit, hdsq_a5, dSq])
            (by simp [intExprOps, realExprOps])
        have hb7 : DetExecAt 1 inp
            (boxWriteR M_box 26 (.lit 0) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))) ma6 ma7 18 :=
          exec_boxWriteR inp ma6 _ _ rfl (by omega) (by omega)
            (by simp only [rValAt_readRealLocal, iValAt_lit, ma6, rReadL_rWriteL_eq,
              (by decide : (29 : ℕ) ≠ 28), false_and, ↓reduceIte, hdsq_a5, dSq])
            (by simp [intExprOps, realExprOps])
        exact ⟨ma7,
          (DetExecAt.ite_true hcond (C_c := 10) (by simp [condExprOps, intExprOps])
            (hb1.seq (hb2.seq (hb3.seq (hb4.seq (hb5.seq (hb6.seq hb7))))))).mono_cost (by omega),
          by simp [ma7, ma6, rSqVal, dSq],
          fun _ => by simp [ma7, dSq],
          fun t idx => by simp [ma7, ma6, hw_a5, hw_a4, ma3, hw_a2, ma1, m0],
          fun t ht idx => by simp [ma7, ht, ma6, hr_a5, hr_a4, ma3, hr_a2, ma1, m0],
          fun idx hne => by simp [ma7, hne, ma6, hr_a5, hr_a4, ma3, hr_a2, ma1, m0]⟩
  rcases hPre with ⟨ma, hdPre, hr28_20, hr26_0, hw_a, hr_ao, hr_a26⟩
  let mb1 := wWriteL 1 ma 28 20 (s : ℤ)
  let mb2 := wWriteL 1 mb1 28 21 (h : ℤ)
  let mb3 := wWriteL 1 mb2 28 22 (if ins then 1 else 0)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 3))) ma mb1 6 :=
    DetExecAt.writeWordLocal 1 inp ma 28 _ _ rfl (by simp [hw_a, hs_reg]) (by simp [intExprOps])
  have hs2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readHeap 26 (.lit 4))) mb1 mb2 6 :=
    DetExecAt.writeWordLocal 1 inp mb1 28 _ _ rfl (by simp [mb1, hw_a, hh_reg]) (by simp [intExprOps])
  have hs3 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 22) (.readHeap 26 (.lit 5))) mb2 mb3 6 :=
    DetExecAt.writeWordLocal 1 inp mb2 28 _ _ rfl (by simp [mb2, mb1, hw_a, hins_reg]) (by simp [intExprOps])
  have hgen_mb3 : SegGenBound K NumSlots mb3 :=
    ⟨by simp [mb3, mb2, mb1, hw_a]; exact hgen.1,
     fun s' hs' => by simp [mb3, mb2, mb1, hw_a]; exact hgen.2.1 s' hs',
     fun s' hs' u hu => by simp [mb3, mb2, mb1, hw_a]; exact hgen.2.2 s' hs' u hu⟩
  have hEnc_mb3 : EncSegSlot K mb3 s S (fun x => euclideanDistSq (livePts x) o) :=
    hEnc.congr_mem_fSq (by simp [mb3, mb2, mb1, hw_a]) (fun _ _ => by simp [mb3, mb2, mb1, hw_a])
      (fun _ _ => by simp [mb3, mb2, mb1, hw_a]) (fun _ _ => by simp [mb3, mb2, mb1, hw_a])
      (fun _ _ => by simp [mb3, mb2, mb1, hr_ao 8 (by decide)]) (fun _ _ => rfl)
  rcases exec_updLeafSegSlotStmt inp mb3 (ins := ins) (rSq := rSqVal)
      (fSq' := fun x => euclideanDistSq (livePts' x) o)
      hs hh hMs (by simp [mb3, mb2, mb1]) (by simp [mb3, mb2]) (by simp [mb3])
      (by simp [mb3, mb2, mb1, hr28_20])
      (fun hins_t => by simp [rSqVal, hins_t])
      (fun x hx hne => by dsimp only; rw [hlive_other x hx hne])
      hgen_mb3 hEnc_mb3
    with ⟨mb4, hs4, hgen4, hEnc4, hOther4, hw4, hr4, _, _⟩
  refine ⟨mb4.popDepth 0,
    DetExecAt.localScope ((hdPre.seq (hs1.seq (hs2.seq (hs3.seq hs4)))).mono_cost (by omega)),
    popDepth_zero_idem mb4,
    ⟨by simp; exact hgen4.1,
     fun s' hs' => by simp; exact hgen4.2.1 s' hs',
     fun s' hs' u hu => by simp; exact hgen4.2.2 s' hs' u hu⟩,
    hEnc4.congr_mem_fSq (by simp) (fun _ _ => by simp) (fun _ _ => by simp)
      (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
    fun hins_t => by simp [hr4 26 (by decide), mb3, mb2, mb1, hr26_0 hins_t],
    fun s' hs' hne S₁ fSq₁ h1 => by
      have h1_mb3 : EncSegSlot K mb3 s' S₁ fSq₁ :=
        h1.congr_mem_fSq (by simp [mb3, mb2, mb1, hw_a]) (fun _ _ => by simp [mb3, mb2, mb1, hw_a])
          (fun _ _ => by simp [mb3, mb2, mb1, hw_a]) (fun _ _ => by simp [mb3, mb2, mb1, hw_a])
          (fun _ _ => by simp [mb3, mb2, mb1, hr_ao 8 (by decide)]) (fun _ _ => rfl)
      exact (hOther4 s' hs' hne S₁ fSq₁ h1_mb3).congr_mem_fSq
        (by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp)
        (fun _ _ => by simp) (fun _ _ => rfl),
    fun t h8 h9 h10 idx => by simp [hw4 t h8 h9 h10, mb3, mb2, mb1, hw_a],
    fun t h8 h26 idx => by simp [hr4 t h8, mb3, mb2, mb1, hr_ao t h26],
    fun idx hne => by simp [hr4 26 (by decide), mb3, mb2, mb1, hr_a26 idx hne]⟩

/-! ### 3. Prefix Finset of `orderEmbOfFin` -/

def rankPrefixSet (S : Finset ℕ) (k : ℕ) : Finset ℕ :=
  (Finset.univ : Finset (Fin (min k S.card))).image
    (fun i => S.orderEmbOfFin rfl ⟨i.val, lt_of_lt_of_le i.isLt (Nat.min_le_right k S.card)⟩)

lemma rankPrefixSet_zero (S : Finset ℕ) : rankPrefixSet S 0 = ∅ := by
  ext x
  simp only [rankPrefixSet, Finset.mem_image, Finset.mem_univ, true_and, Finset.notMem_empty, iff_false]
  rintro ⟨i, _⟩
  have hi := i.isLt
  omega

lemma sup'_eq_insert_of_eq {T S' : Finset ℕ} {a : ℕ}
    (hEq : S' = insert a T) (hS' : S'.Nonempty) (hT : T.Nonempty) (f : ℕ → ℝ) :
    S'.sup' hS' f = max (f a) (T.sup' hT f) := by
  subst hEq
  exact Finset.sup'_insert hT f

lemma rankPrefixSet_subset (S : Finset ℕ) (k : ℕ) : rankPrefixSet S k ⊆ S := by
  intro x hx
  rcases Finset.mem_image.mp hx with ⟨i, _, rfl⟩
  exact S.orderEmbOfFin_mem rfl _

lemma not_mem_rankPrefixSet_self {S : Finset ℕ} {k : ℕ} (hk : k < S.card) :
    S.orderEmbOfFin rfl ⟨k, hk⟩ ∉ rankPrefixSet S k := by
  intro hmem
  rcases Finset.mem_image.mp hmem with ⟨i, _, heq⟩
  have hfin := (S.orderEmbOfFin rfl).injective heq
  have hval : i.val = k := congrArg Fin.val hfin
  have hi_lt : i.val < min k S.card := i.isLt
  omega

lemma rankPrefixSet_succ_lt {S : Finset ℕ} {k : ℕ} (hk : k < S.card) :
    rankPrefixSet S (k + 1) = insert (S.orderEmbOfFin rfl ⟨k, hk⟩) (rankPrefixSet S k) := by
  ext x
  simp only [rankPrefixSet, Finset.mem_insert, Finset.mem_image, Finset.mem_univ, true_and]
  have hmin1 : min (k + 1) S.card = k + 1 := Nat.min_eq_left (Nat.succ_le_of_lt hk)
  have hmin0 : min k S.card = k := Nat.min_eq_left (le_of_lt hk)
  constructor
  · rintro ⟨i, rfl⟩
    have hi_le : i.val ≤ k := by have := i.isLt; omega
    rcases Nat.lt_or_eq_of_le hi_le with hlt | heq
    · right
      exact ⟨⟨i.val, by omega⟩, rfl⟩
    · left
      apply congrArg (S.orderEmbOfFin rfl)
      apply Fin.ext
      dsimp
      exact heq
  · rintro (rfl | ⟨i, rfl⟩)
    · exact ⟨⟨k, by omega⟩, rfl⟩
    · exact ⟨⟨i.val, by omega⟩, rfl⟩

lemma rankPrefixSet_succ_ge {S : Finset ℕ} {k : ℕ} (hk : S.card ≤ k) :
    rankPrefixSet S (k + 1) = rankPrefixSet S k := by
  ext x
  simp only [rankPrefixSet, Finset.mem_image, Finset.mem_univ, true_and]
  have hmin1 : min (k + 1) S.card = S.card := Nat.min_eq_right (by omega)
  have hmin0 : min k S.card = S.card := Nat.min_eq_right hk
  constructor
  · rintro ⟨i, rfl⟩
    exact ⟨⟨i.val, by have := i.isLt; omega⟩, rfl⟩
  · rintro ⟨i, rfl⟩
    exact ⟨⟨i.val, by have := i.isLt; omega⟩, rfl⟩

lemma rankPrefixSet_full {S : Finset ℕ} {M : ℕ} (hM : S.card ≤ M) :
    rankPrefixSet S M = S := by
  apply Finset.eq_of_subset_of_card_le (rankPrefixSet_subset S M)
  unfold rankPrefixSet
  rw [Finset.card_image_of_injective]
  · simp [Nat.min_eq_right hM]
  · intro i j heq
    have hfin := (S.orderEmbOfFin rfl).injective heq
    have hval : i.val = j.val := by simpa using congrArg Fin.val hfin
    exact Fin.ext hval

/-! ### 4. Synchronous Two-Stage Core Fallback + Partition (`syncCoreAndPartitionStmt`) -/

def syncCoreScanIterStmt (d K : ℕ) : ArithRAMStmt :=
  seqList [
    .ite (.intLt (.readLocal 27 (.lit 2)) (.readLocal 27 (.lit 1)))
      (seqList [
        .writeWordLocal 28 (.lit 20) (.readLocal 27 (.lit 0)),
        .writeWordLocal 28 (.lit 21) (.readLocal 27 (.lit 2)),
        selectByRankSegStmt K,
        .writeWordLocal 29 (.lit 18) (.mul (.readLocal 28 (.lit 0)) (.lit (d : ℤ))),
        loadHeapCoordsToLocalStmt d 4 18 0,
        distSqLocalStmt d,
        .ite (.realLe (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))) (.readRealHeap 27 (.lit (d : ℤ))))
          (.writeWordLocal 27 (.lit 3) (.add (.readLocal 27 (.lit 3)) (.lit 1)))
          .skip,
        .ite (.or (.intEq (.readLocal 27 (.lit 2)) (.lit 0))
                  (.realLt (.readRealLocal 27 (.lit 0)) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))))
          (.writeRealLocal 27 (.lit 0) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))
          .skip
      ])
      .skip,
    .writeWordLocal 27 (.lit 2) (.add (.readLocal 27 (.lit 2)) (.lit 1))
  ]

def syncCoreFinalizeScopeStmt (d D K M_sync M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 27 (.lit 0) (.readHeap 26 (.lit 1)),
    cardAndMaxSegSlotStmt K (.readLocal 27 (.lit 0)),
    .writeWordLocal 27 (.lit 1) (.readLocal 28 (.lit 0)),
    boxWriteW M_box 26 (.lit 24) (.readLocal 27 (.lit 1)),
    .writeWordLocal 27 (.lit 2) (.lit 0),
    .writeWordLocal 27 (.lit 3) (.lit 0),
    .writeRealLocal 27 (.lit 0) (.ofInt (.lit 0)),
    .writeWordLocal 29 (.lit 18) (.lit 0),
    loadHeapCoordsToLocalStmt d 27 18 (d : ℤ),
    .repeatN (.lit (M_sync : ℤ)) (syncCoreScanIterStmt d K),
    .ite (.intLe (.readLocal 27 (.lit 1))
                 (.mul (.lit (((8 * D ^ 2 : ℕ) : ℤ))) (.readLocal 27 (.lit 3))))
      .skip
      (boxWriteR M_box 27 (.lit (d : ℤ)) (.readRealLocal 27 (.lit 0)))
  ])

def syncPartSelectScopeStmt (K M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 27 (.lit 2) (.readHeap 26 (.lit 23)),
    .ite (.intLt (.readLocal 27 (.lit 2)) (.readHeap 26 (.lit 24)))
      (seqList [
        .writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 1)),
        .writeWordLocal 28 (.lit 21) (.readLocal 27 (.lit 2)),
        selectByRankSegStmt K,
        boxWriteW M_box 26 (.lit 4) (.readLocal 28 (.lit 0)),
        boxWriteW M_box 26 (.lit 5) (.lit 1),
        boxWriteW M_box 26 (.lit 6) (.lit 0),
        boxWriteW M_box 26 (.lit 25) (.lit 1)
      ])
      (boxWriteW M_box 26 (.lit 25) (.lit 0)),
    boxWriteW M_box 26 (.lit 23) (.add (.readLocal 27 (.lit 2)) (.lit 1))
  ])

def syncPartOneElemStmt (d K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    syncPartSelectScopeStmt K M_box,
    .ite (.intEq (.readHeap 26 (.lit 25)) (.lit 1))
      (seqList [
        boxWriteW M_box 26 (.lit 3) (.readHeap 26 (.lit 20)),
        updSegCenterStmt d K M_box 27,
        boxWriteW M_box 26 (.lit 3) (.readHeap 26 (.lit 21)),
        updSegZeroStmt K M_box,
        .ite (.realLe (.readRealHeap 26 (.lit 0)) (.readRealHeap 27 (.lit (d : ℤ))))
          .skip
          (seqList [
            boxWriteW M_box 26 (.lit 3) (.readHeap 26 (.lit 22)),
            updSegZeroStmt K M_box
          ])
      ])
      .skip
  ]

def syncCoreAndPartitionStmt (d D K M_sync M_box : ℕ) : ArithRAMStmt :=
  seqList [
    syncCoreFinalizeScopeStmt d D K M_sync M_box,
    boxWriteW M_box 26 (.lit 23) (.lit 0),
    .repeatN (.lit (M_sync : ℤ)) (syncPartOneElemStmt d K M_box),
    .localScope .skip
  ]

theorem boxSafe_syncCoreAndPartitionStmt {T_max M_box : ℕ} (hT : 28 ≤ T_max)
    (d D K M_sync : ℕ) :
    BoxSafeOuter T_max M_box (syncCoreAndPartitionStmt d D K M_sync M_box) := by
  refine boxSafeOuter_seqList ?_
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · refine .localScope (boxSafeInner_seqList ?_)
    intro s1 hs1
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs1
    rcases hs1 with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact boxSafe_cardAndMaxSegSlotStmt _ _
    · exact .writeWordLocal _ _ _
    · exact .boxW (by omega) _ _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeRealLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
    · refine .repeatN _ (boxSafeInner_seqList ?_)
      intro s2 hs2
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hs2
      rcases hs2 with rfl | rfl
      · refine .ite _ (boxSafeInner_seqList ?_) .skip
        intro s3 hs3
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hs3
        rcases hs3 with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
        · exact .writeWordLocal _ _ _
        · exact .writeWordLocal _ _ _
        · exact boxSafe_selectByRankSegStmt _
        · exact .writeWordLocal _ _ _
        · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
        · exact boxSafe_distSqLocalStmt _
        · exact .ite _ (.writeWordLocal _ _ _) .skip
        · exact .ite _ (.writeRealLocal _ _ _) .skip
      · exact .writeWordLocal _ _ _
    · exact .ite _ .skip (.boxR (by omega) _ _)
  · exact .boxW (by omega) _ _
  · refine .repeatN _ (boxSafeOuter_seqList ?_)
    intro s1 hs1
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs1
    rcases hs1 with rfl | rfl
    · refine .localScope (boxSafeInner_seqList ?_)
      intro s2 hs2
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hs2
      rcases hs2 with rfl | rfl | rfl
      · exact .writeWordLocal _ _ _
      · refine .ite _ (boxSafeInner_seqList ?_) (.boxW (by omega) _ _)
        intro s3 hs3
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hs3
        rcases hs3 with rfl | rfl | rfl | rfl | rfl | rfl | rfl
        · exact .writeWordLocal _ _ _
        · exact .writeWordLocal _ _ _
        · exact boxSafe_selectByRankSegStmt _
        · exact .boxW (by omega) _ _
        · exact .boxW (by omega) _ _
        · exact .boxW (by omega) _ _
        · exact .boxW (by omega) _ _
      · exact .boxW (by omega) _ _
    · refine .ite _ (boxSafeOuter_seqList ?_) .skip
      intro s2 hs2
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hs2
      rcases hs2 with rfl | rfl | rfl | rfl | rfl
      · exact .boxW (by omega) _ _
      · exact boxSafe_updSegCenterStmt (by omega) _ _ _
      · exact .boxW (by omega) _ _
      · exact boxSafe_updSegZeroStmt (by omega) _
      · refine .ite _ .skip (boxSafeOuter_seqList ?_)
        intro s3 hs3
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hs3
        rcases hs3 with rfl | rfl
        · exact .boxW (by omega) _ _
        · exact boxSafe_updSegZeroStmt (by omega) _
  · exact .localScope .skip

theorem exec_syncCoreFinalizeScopeStmt {d n D K M_sync M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s_src : ℕ} {S : Finset ℕ} {fSq_src : ℕ → ℝ}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d}
    (hD : 3 ≤ D)
    (hs_reg : wRead mem 26 1 = (s_src : ℤ))
    (hS_pos : 0 < S.card) (hS_le : S.card ≤ M_sync)
    (hS_sub : S ⊆ activeH)
    (hBox26 : 26 ≤ M_box) (hBox_d : d + 1 ≤ M_box)
    (hSeg_src : EncSegSlot K mem s_src S fSq_src)
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hprov_o : ∀ c : Fin d, rRead mem 27 (c.val : ℤ) = euclideanCoord prov.o c)
    (hprov_V : rRead mem 27 (d : ℤ) = prov.V) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    let ball := applyBirthCoreFallback α livePts S prov
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (syncCoreFinalizeScopeStmt d D K M_sync M_box) mem m'
        (200 * (M_sync + 1) * (K + d + 5) + 300) ∧
      m'.popDepth 0 = m' ∧
      wRead m' 26 24 = (S.card : ℤ) ∧
      (∀ t, t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 24 → wRead m' 26 idx = wRead mem 26 idx) ∧
      (∀ t, t ≠ 27 → ∀ idx, rRead m' t idx = rRead mem t idx) ∧
      (∀ c : Fin d, rRead m' 27 (c.val : ℤ) = euclideanCoord ball.o c) ∧
      rRead m' 27 (d : ℤ) = ball.V := by
  intro α ball
  have hS_ne : S.Nonempty := Finset.card_pos.mp hS_pos
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 27 0 (s_src : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 0) (.readHeap 26 (.lit 1))) m0 m1 6 :=
    DetExecAt.writeWordLocal 1 inp m0 27 _ _ rfl (by simp [m0, hs_reg]) (by simp [intExprOps])
  have hSeg_m1 : EncSegSlot K m1 s_src S fSq_src :=
    hSeg_src.congr_mem_fSq (by simp [m1, m0]) (fun _ _ => by simp [m1, m0])
      (fun _ _ => by simp [m1, m0]) (fun _ _ => by simp [m1, m0])
      (fun _ _ => by simp [m1, m0]) (fun _ _ => rfl)
  rcases exec_cardAndMaxSegSlotStmt inp m1 (.readLocal 27 (.lit 0)) (by simp [m1]) hSeg_m1
    with ⟨m2, hs2, hm2_card, _, hw2, hr2, hwl2, _⟩
  let m3 := wWriteL 1 m2 27 1 (S.card : ℤ)
  let m4 := wWrite m3 26 24 (S.card : ℤ)
  let m5 := wWriteL 1 m4 27 2 0
  let m6 := wWriteL 1 m5 27 3 0
  let m7 := rWriteL 1 m6 27 0 0
  let m8 := wWriteL 1 m7 29 18 0
  have hs3 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 1) (.readLocal 28 (.lit 0))) m2 m3 6 :=
    DetExecAt.writeWordLocal 1 inp m2 27 _ _ rfl (by simp [hm2_card]) (by simp [intExprOps])
  have hs4 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 24) (.readLocal 27 (.lit 1))) m3 m4 16 :=
    exec_boxWriteW inp m3 _ _ rfl (by omega) (by omega) (by simp [m3]) (by simp [intExprOps])
  have hs5 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 2) (.lit 0)) m4 m5 4 :=
    DetExecAt.writeWordLocal 1 inp m4 27 _ _ rfl rfl (by simp [intExprOps])
  have hs6 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 3) (.lit 0)) m5 m6 4 :=
    DetExecAt.writeWordLocal 1 inp m5 27 _ _ rfl rfl (by simp [intExprOps])
  have hs7 : DetExecAt 1 inp (.writeRealLocal 27 (.lit 0) (.ofInt (.lit 0))) m6 m7 4 :=
    DetExecAt.writeRealLocal 1 inp m6 27 _ _ rfl (by simp) (by simp [intExprOps, realExprOps])
  have hs8 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.lit 0)) m7 m8 4 :=
    DetExecAt.writeWordLocal 1 inp m7 29 _ _ rfl rfl (by simp [intExprOps])
  rcases exec_loadHeapCoordsToLocalStmt inp m8 (rTag := 27) (idxBase := 18) (destOff := (d : ℤ))
      (base := 0) (pt := prov.o) (by decide) (by simp [m8])
      (fun c => by
        simp only [m8, m7, m6, m5, m4, m3, rRead_wWriteL, rRead_rWriteL, rRead_wWrite, hr2, m1, m0, rRead_popDepth]
        simpa using hprov_o c)
    with ⟨m9, hs9, hprovo_loc, hw9, hr9, _, _, hlv9, hrlv9⟩
  let C_it : ℕ := 180 * (K + d + 5)
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    (∀ t, t ≠ 26 → ∀ idx, wRead m t idx = wRead mem t idx) ∧
    (∀ idx, idx ≠ 24 → wRead m 26 idx = wRead mem 26 idx) ∧
    wRead m 26 24 = (S.card : ℤ) ∧
    (∀ t idx, rRead m t idx = rRead mem t idx) ∧
    (∀ c : Fin d, rReadL 1 m 29 (((d + c.val : ℕ) : ℤ)) = euclideanCoord prov.o c) ∧
    wReadL 1 m 27 0 = (s_src : ℤ) ∧
    wReadL 1 m 27 1 = (S.card : ℤ) ∧
    wReadL 1 m 27 2 = (k : ℤ) ∧
    wReadL 1 m 27 3 = ((prov.core livePts (rankPrefixSet S k)).card : ℤ) ∧
    (k = 0 → rReadL 1 m 27 0 = 0) ∧
    (∀ hk_ne : (rankPrefixSet S k).Nonempty,
      rReadL 1 m 27 0 = (rankPrefixSet S k).sup' hk_ne (fun x => euclideanDistSq (livePts x) prov.o))
  have hInv0 : Inv 0 m9 := by
    refine ⟨fun t ht idx => by simp [hw9, m8, m7, m6, m5, m4, ht, m3, hw2, m1, m0],
      fun idx h24 => by simp [hw9, m8, m7, m6, m5, m4, h24, m3, hw2, m1, m0],
      by simp [hw9, m8, m7, m6, m5, m4],
      fun t idx => by simp [hr9, m8, m7, m6, m5, m4, m3, hr2, m1, m0],
      fun c => by simpa [Nat.cast_add] using hprovo_loc c,
      by simp [hlv9 27 (by decide), m8, m7, m6, m5, m4, m3, hwl2 27 (by decide), m1],
      by simp [hlv9 27 (by decide), m8, m7, m6, m5, m4, m3],
      by simp [hlv9 27 (by decide), m8, m7, m6, m5],
      by simp [hlv9 27 (by decide), m8, m7, m6, rankPrefixSet_zero, ChainNode.core, nodeCore],
      fun _ => by simp [hrlv9 27 (by decide), m8, m7],
      fun hne => by rw [rankPrefixSet_zero] at hne; exact False.elim (Finset.not_nonempty_empty hne)⟩
  have hStep : ∀ k < M_sync, ∀ m, Inv k m →
      ∃ m', DetExecAt 1 inp (syncCoreScanIterStmt d K) m m' C_it ∧ Inv (k + 1) m' := by
    intro k _ m ⟨hw_o, hw_26, hw_24, hr_m, hpo_m, hm27_0, hm27_1, hm27_2, hm27_3, _, hsup_r⟩
    by_cases hk_lt : k < S.card
    · have hcond_k : cValAt 1 inp m (.intLt (.readLocal 27 (.lit 2)) (.readLocal 27 (.lit 1))) = true := by
        simp [hm27_2, hm27_1, hk_lt]
      let xk : ℕ := S.orderEmbOfFin rfl ⟨k, hk_lt⟩
      have hxk_in : xk ∈ S := S.orderEmbOfFin_mem rfl ⟨k, hk_lt⟩
      have hxk_act : xk ∈ activeH := hS_sub hxk_in
      have hxk_not_pref : xk ∉ rankPrefixSet S k := not_mem_rankPrefixSet_self hk_lt
      have hpref_succ : rankPrefixSet S (k + 1) = insert xk (rankPrefixSet S k) :=
        rankPrefixSet_succ_lt hk_lt
      let ma1 := wWriteL 1 m 28 20 (s_src : ℤ)
      let ma2 := wWriteL 1 ma1 28 21 (k : ℤ)
      have ha1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readLocal 27 (.lit 0))) m ma1 6 :=
        DetExecAt.writeWordLocal 1 inp m 28 _ _ rfl (by simp [hm27_0]) (by simp [intExprOps])
      have ha2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readLocal 27 (.lit 2))) ma1 ma2 6 :=
        DetExecAt.writeWordLocal 1 inp ma1 28 _ _ rfl (by simp [ma1, hm27_2]) (by simp [intExprOps])
      have hSeg_ma2 : EncSegSlot K ma2 s_src S fSq_src :=
        hSeg_src.congr_mem_fSq
          (by simp [ma2, ma1, hw_o 5 (by decide)])
          (fun _ _ => by simp [ma2, ma1, hw_o 8 (by decide)])
          (fun _ _ => by simp [ma2, ma1, hw_o 9 (by decide)])
          (fun _ _ => by simp [ma2, ma1, hw_o 10 (by decide)])
          (fun _ _ => by simp [ma2, ma1, hr_m])
          (fun _ _ => rfl)
      rcases exec_selectByRankSegStmt inp ma2 hk_lt (by simp [ma2, ma1]) (by simp [ma2]) hSeg_ma2
        with ⟨ma3, ha3, hsel_a3, hw_a3, hr_a3, hwl_a3, hrl_a3⟩
      let ma4 := wWriteL 1 ma3 29 18 (((xk * d : ℕ) : ℤ))
      have ha4 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readLocal 28 (.lit 0)) (.lit (d : ℤ))))
          ma3 ma4 8 :=
        DetExecAt.writeWordLocal 1 inp ma3 29 _ _ rfl (by simp [hsel_a3, xk]) (by simp [intExprOps])
      rcases exec_loadHeapCoordsToLocalStmt inp ma4 (rTag := 4) (idxBase := 18) (destOff := 0)
          (base := xk * d) (pt := livePts xk) (by decide) (by simp [ma4])
          (fun c => by simp only [ma4, rRead_wWriteL, hr_a3, ma2, ma1, hr_m]; exact hLive.2 xk hxk_act c)
        with ⟨ma5, ha5, hxk_loc, hw_a5, hr_a5, _, hrl_a5, hlv_a5, hrlv_a5⟩
      have hpo_ma5 : ∀ c : Fin d, rReadL 1 ma5 29 (((d + c.val : ℕ) : ℤ)) = euclideanCoord prov.o c := by
        intro c
        rw [hrl_a5 (((d + c.val : ℕ) : ℤ)) (Or.inr (by omega))]
        simp only [ma4, rReadL_wWriteL, hrl_a3, ma2, ma1]
        exact hpo_m c
      rcases exec_distSqLocalStmt inp ma5 (fun c => by simpa using hxk_loc c) hpo_ma5
        with ⟨ma6, ha6, hdsq_a6, hw_a6, hr_a6, _, hrl_a6, hlv_a6, hrlv_a6⟩
      have hpo_ma6 : ∀ c : Fin d, rReadL 1 ma6 29 (((d + c.val : ℕ) : ℤ)) = euclideanCoord prov.o c := by
        intro c
        rw [hrl_a6 (((d + c.val : ℕ) : ℤ)) (by have := c.isLt; omega)]
        exact hpo_ma5 c
      have hw27_ma6 : ∀ idx, wReadL 1 ma6 27 idx = wReadL 1 m 27 idx := by
        intro idx
        simp [hlv_a6 27 (by decide), hlv_a5 27 (by decide), ma4, hwl_a3 27 (by decide), ma2, ma1]
      have hr27_ma6 : ∀ idx, rReadL 1 ma6 27 idx = rReadL 1 m 27 idx := by
        intro idx
        simp [hrlv_a6 27 (by decide), hrlv_a5 27 (by decide), ma4, hrl_a3, ma2, ma1]
      have hr_ma6 : ∀ t idx, rRead ma6 t idx = rRead mem t idx := by
        intro t idx; simp [hr_a6, hr_a5, ma4, hr_a3, ma2, ma1, hr_m]
      let dSq := euclideanDistSq (livePts xk) prov.o
      have hCoreUpd : ∃ ma7 : ArithRAMMemory,
          DetExecAt 1 inp
            (.ite (.realLe (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))) (.readRealHeap 27 (.lit (d : ℤ))))
              (.writeWordLocal 27 (.lit 3) (.add (.readLocal 27 (.lit 3)) (.lit 1)))
              .skip)
            ma6 ma7 20 ∧
          wReadL 1 ma7 27 3 = ((prov.core livePts (rankPrefixSet S (k + 1))).card : ℤ) ∧
          (∀ idx, idx ≠ 3 → wReadL 1 ma7 27 idx = wReadL 1 ma6 27 idx) ∧
          (∀ v, v ≠ 27 → ∀ idx, wReadL 1 ma7 v idx = wReadL 1 ma6 v idx) ∧
          (∀ v idx, rReadL 1 ma7 v idx = rReadL 1 ma6 v idx) ∧
          (∀ t idx, wRead ma7 t idx = wRead ma6 t idx) ∧
          (∀ t idx, rRead ma7 t idx = rRead ma6 t idx) := by
        by_cases hle : dSq ≤ prov.V
        · have hcond_c : cValAt 1 inp ma6
              (.realLe (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))) (.readRealHeap 27 (.lit (d : ℤ)))) = true := by
            simp only [cValAt_realLe, rValAt_readRealLocal, rValAt_readRealHeap, iValAt_lit,
              hdsq_a6, hr_ma6, hprov_V, decide_eq_true_eq]
            exact hle
          have hcore_ins : prov.core livePts (rankPrefixSet S (k + 1)) =
              insert xk (prov.core livePts (rankPrefixSet S k)) := by
            rw [hpref_succ]
            ext y
            simp only [mem_nodeCore_iff_distSq_le, Finset.mem_insert]
            constructor
            · rintro ⟨rfl | hy, hle_y⟩
              · exact Or.inl rfl
              · exact Or.inr ⟨hy, hle_y⟩
            · rintro (rfl | ⟨hy, hle_y⟩)
              · exact ⟨Or.inl rfl, hle⟩
              · exact ⟨Or.inr hy, hle_y⟩
          have hxk_not_core : xk ∉ prov.core livePts (rankPrefixSet S k) := by
            rw [mem_nodeCore_iff_distSq_le]
            exact fun h => hxk_not_pref h.1
          have hcard_c : (prov.core livePts (rankPrefixSet S (k + 1))).card =
              (prov.core livePts (rankPrefixSet S k)).card + 1 := by
            rw [hcore_ins, Finset.card_insert_of_notMem hxk_not_core]
          let ma7 := wWriteL 1 ma6 27 3 (((prov.core livePts (rankPrefixSet S (k + 1))).card : ℤ))
          have hs_c : DetExecAt 1 inp
              (.writeWordLocal 27 (.lit 3) (.add (.readLocal 27 (.lit 3)) (.lit 1))) ma6 ma7 8 := by
            refine DetExecAt.writeWordLocal 1 inp ma6 27 _ _ rfl ?_ (by simp [intExprOps])
            simp [hw27_ma6, hm27_3, hcard_c]
          exact ⟨ma7,
            (DetExecAt.ite_true hcond_c (C_c := 10) (by simp [condExprOps, realExprOps, intExprOps]) hs_c).mono_cost (by omega),
            by simp [ma7],
            fun idx h3 => by simp [ma7, h3],
            fun v hv idx => by simp [ma7, hv],
            fun _ _ => by simp [ma7],
            fun _ _ => by simp [ma7],
            fun _ _ => by simp [ma7]⟩
        · have hcond_c : cValAt 1 inp ma6
              (.realLe (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))) (.readRealHeap 27 (.lit (d : ℤ)))) = false := by
            simp only [cValAt_realLe, rValAt_readRealLocal, rValAt_readRealHeap, iValAt_lit,
              hdsq_a6, hr_ma6, hprov_V, decide_eq_false_iff_not]
            exact hle
          have hcore_eq : prov.core livePts (rankPrefixSet S (k + 1)) =
              prov.core livePts (rankPrefixSet S k) := by
            rw [hpref_succ]
            ext y
            simp only [mem_nodeCore_iff_distSq_le, Finset.mem_insert]
            constructor
            · rintro ⟨rfl | hy, hle_y⟩
              · exact False.elim (hle hle_y)
              · exact ⟨hy, hle_y⟩
            · rintro ⟨hy, hle_y⟩
              exact ⟨Or.inr hy, hle_y⟩
          exact ⟨ma6,
            (DetExecAt.ite_false hcond_c (C_c := 10) (by simp [condExprOps, realExprOps, intExprOps])
              (DetExecAt.skip 1 inp ma6)).mono_cost (by omega),
            by rw [hcore_eq, hw27_ma6, hm27_3],
            fun _ _ => rfl, fun _ _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl⟩
      rcases hCoreUpd with ⟨ma7, ha7, hm7_3, hwl7_27, _, hrl7, hw7, hr7⟩
      have hMaxUpd : ∃ ma8 : ArithRAMMemory,
          DetExecAt 1 inp
            (.ite (.or (.intEq (.readLocal 27 (.lit 2)) (.lit 0))
                      (.realLt (.readRealLocal 27 (.lit 0)) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))))
              (.writeRealLocal 27 (.lit 0) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))
              .skip)
            ma7 ma8 22 ∧
          (∀ hk_ne : (rankPrefixSet S (k + 1)).Nonempty,
            rReadL 1 ma8 27 0 =
              (rankPrefixSet S (k + 1)).sup' hk_ne (fun x => euclideanDistSq (livePts x) prov.o)) ∧
          (∀ v idx, wReadL 1 ma8 v idx = wReadL 1 ma7 v idx) ∧
          (∀ v, v ≠ 27 → ∀ idx, rReadL 1 ma8 v idx = rReadL 1 ma7 v idx) ∧
          (∀ t idx, wRead ma8 t idx = wRead ma7 t idx) ∧
          (∀ t idx, rRead ma8 t idx = rRead ma7 t idx) := by
        have hw7_2 : wReadL 1 ma7 27 2 = (k : ℤ) := by
          rw [hwl7_27 2 (by decide), hw27_ma6, hm27_2]
        have hr7_0 : rReadL 1 ma7 27 0 = rReadL 1 m 27 0 := by
          rw [hrl7, hr27_ma6]
        have hr7_2d : rReadL 1 ma7 29 (((2 * d : ℕ) : ℤ)) = dSq := by
          rw [hrl7, hdsq_a6]
        by_cases htake : k = 0 ∨ rReadL 1 m 27 0 < dSq
        · have hcond_m : cValAt 1 inp ma7
              (.or (.intEq (.readLocal 27 (.lit 2)) (.lit 0))
                   (.realLt (.readRealLocal 27 (.lit 0)) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))) = true := by
            simp only [cValAt_or, cValAt_intEq, cValAt_realLt, iValAt_readLocal, iValAt_lit,
              rValAt_readRealLocal, hw7_2, hr7_0, hr7_2d, Bool.or_eq_true, decide_eq_true_eq]
            rcases htake with rfl | hlt
            · exact Or.inl rfl
            · exact Or.inr hlt
          let ma8 := rWriteL 1 ma7 27 0 dSq
          have hs_m : DetExecAt 1 inp
              (.writeRealLocal 27 (.lit 0) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))) ma7 ma8 6 :=
            DetExecAt.writeRealLocal 1 inp ma7 27 _ _ rfl
              (by simp only [rValAt_readRealLocal, iValAt_lit, hr7_2d]) (by simp [intExprOps, realExprOps])
          refine ⟨ma8,
            (DetExecAt.ite_true hcond_m (C_c := 15) (by simp [condExprOps, realExprOps, intExprOps]) hs_m).mono_cost (by omega),
            fun hk_ne => ?_,
            fun _ _ => by simp [ma8],
            fun v hv _ => by simp [ma8, hv],
            fun _ _ => by simp [ma8],
            fun _ _ => by simp [ma8]⟩
          simp only [ma8, rReadL_rWriteL_self]
          rcases Nat.eq_zero_or_pos k with rfl | hk_pos
          · have hp1 : rankPrefixSet S 1 = {xk} := by rw [hpref_succ, rankPrefixSet_zero]; simp
            simp [hp1, dSq]
          · have hk_ne_prev : (rankPrefixSet S k).Nonempty := by
              have h0_lt : 0 < min k S.card := Nat.lt_min.mpr ⟨hk_pos, hS_pos⟩
              exact ⟨S.orderEmbOfFin rfl ⟨0, hS_pos⟩,
                Finset.mem_image.mpr ⟨⟨0, h0_lt⟩, Finset.mem_univ _, rfl⟩⟩
            have hlt_prev : (rankPrefixSet S k).sup' hk_ne_prev (fun x => euclideanDistSq (livePts x) prov.o) < dSq := by
              rcases htake with rfl | hlt
              · omega
              · rwa [hsup_r hk_ne_prev] at hlt
            rw [sup'_eq_insert_of_eq hpref_succ hk_ne hk_ne_prev]
            exact (max_eq_left (le_of_lt hlt_prev)).symm
        · push_neg at htake
          rcases htake with ⟨hk_ne0, hle_prev⟩
          have hk_pos : 0 < k := Nat.pos_of_ne_zero hk_ne0
          have hk_ne_prev : (rankPrefixSet S k).Nonempty := by
            have h0_lt : 0 < min k S.card := Nat.lt_min.mpr ⟨hk_pos, hS_pos⟩
            exact ⟨S.orderEmbOfFin rfl ⟨0, hS_pos⟩,
              Finset.mem_image.mpr ⟨⟨0, h0_lt⟩, Finset.mem_univ _, rfl⟩⟩
          have hcond_m : cValAt 1 inp ma7
              (.or (.intEq (.readLocal 27 (.lit 2)) (.lit 0))
                   (.realLt (.readRealLocal 27 (.lit 0)) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))) = false := by
            simp only [cValAt_or, cValAt_intEq, cValAt_realLt, iValAt_readLocal, iValAt_lit,
              rValAt_readRealLocal, hw7_2, hr7_0, hr7_2d, Bool.or_eq_false_iff,
              decide_eq_false_iff_not, not_lt]
            exact ⟨by omega, hle_prev⟩
          refine ⟨ma7,
            (DetExecAt.ite_false hcond_m (C_c := 15) (by simp [condExprOps, realExprOps, intExprOps])
              (DetExecAt.skip 1 inp ma7)).mono_cost (by omega),
            fun hk_ne => ?_,
            fun _ _ => rfl, fun _ _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl⟩
          rw [hr7_0, hsup_r hk_ne_prev, sup'_eq_insert_of_eq hpref_succ hk_ne hk_ne_prev]
          rw [hsup_r hk_ne_prev] at hle_prev
          exact (max_eq_right hle_prev).symm
      rcases hMaxUpd with ⟨ma8, ha8, hsup8, hwl8, hrl8_o, hw8, hr8⟩
      let ma9 := wWriteL 1 ma8 27 2 (((k + 1 : ℕ) : ℤ))
      have ha9 : DetExecAt 1 inp
          (.writeWordLocal 27 (.lit 2) (.add (.readLocal 27 (.lit 2)) (.lit 1))) ma8 ma9 8 := by
        refine DetExecAt.writeWordLocal 1 inp ma8 27 _ _ rfl ?_ (by simp [intExprOps])
        simp only [iValAt_add, iValAt_readLocal, iValAt_lit]
        rw [hwl8, hwl7_27 2 (by decide), hw27_ma6, hm27_2]
        push_cast; ring
      refine ⟨ma9,
        ((DetExecAt.ite_true hcond_k (C_c := 10) (by simp [condExprOps, intExprOps])
          (ha1.seq (ha2.seq (ha3.seq (ha4.seq (ha5.seq (ha6.seq (ha7.seq ha8)))))))).seq ha9).mono_cost
          (by dsimp [C_it]; omega),
        fun t ht idx => by simp [ma9, hw8, hw7, hw_a6, hw_a5, ma4, hw_a3, ma2, ma1, hw_o t ht],
        fun idx h24 => by simp [ma9, hw8, hw7, hw_a6, hw_a5, ma4, hw_a3, ma2, ma1, hw_26 idx h24],
        by simp [ma9, hw8, hw7, hw_a6, hw_a5, ma4, hw_a3, ma2, ma1, hw_24],
        fun t idx => by simp [ma9, hr8, hr7, hr_ma6],
        fun c => by simpa [ma9, hrl8_o 29 (by decide), hrl7] using hpo_ma6 c,
        by simp [ma9, hwl8, hwl7_27 0 (by decide), hw27_ma6, hm27_0],
        by simp [ma9, hwl8, hwl7_27 1 (by decide), hw27_ma6, hm27_1],
        by simp [ma9],
        by simp [ma9, hwl8, hm7_3],
        fun h0 => by omega,
        fun hk_ne => by simpa [ma9] using hsup8 hk_ne⟩
    · have hk_ge : S.card ≤ k := by omega
      have hpref_eq : rankPrefixSet S (k + 1) = rankPrefixSet S k := rankPrefixSet_succ_ge hk_ge
      have hcond_k : cValAt 1 inp m (.intLt (.readLocal 27 (.lit 2)) (.readLocal 27 (.lit 1))) = false := by
        simp [hm27_2, hm27_1, hk_lt]
      let ma1 := wWriteL 1 m 27 2 (((k + 1 : ℕ) : ℤ))
      have ha1 : DetExecAt 1 inp
          (.writeWordLocal 27 (.lit 2) (.add (.readLocal 27 (.lit 2)) (.lit 1))) m ma1 8 :=
        DetExecAt.writeWordLocal 1 inp m 27 _ _ rfl (by simp [hm27_2]) (by simp [intExprOps])
      refine ⟨ma1,
        ((DetExecAt.ite_false hcond_k (C_c := 10) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 1 inp m)).seq ha1).mono_cost
          (by dsimp [C_it]; exact le_trans (by omega : 10 + 1 + 8 ≤ 180 * 5) (Nat.mul_le_mul_left _ (by omega))),
        fun t ht idx => by simp [ma1, hw_o t ht],
        fun idx h24 => by simp [ma1, hw_26 idx h24],
        by simp [ma1, hw_24],
        fun t idx => by simp [ma1, hr_m],
        fun c => by simpa [ma1] using hpo_m c,
        by simp [ma1, hm27_0],
        by simp [ma1, hm27_1],
        by simp [ma1],
        by simp [ma1, hpref_eq, hm27_3],
        fun h0 => by omega,
        fun hk_ne => by
          have hk_ne' : (rankPrefixSet S k).Nonempty := hpref_eq ▸ hk_ne
          simpa [ma1, hpref_eq] using hsup_r hk_ne'⟩
  rcases DetExecAt.repeatN_nat (.lit (M_sync : ℤ)) _ M_sync 4 C_it Inv hInv0 rfl
      (by simp [intExprOps]) hStep
    with ⟨mN, ⟨hwN_o, hwN_26, hwN_24, hrN, _, _, hmN_1, _, hmN_3, _, hsupN⟩, hrep⟩
  have hfull : rankPrefixSet S M_sync = S := rankPrefixSet_full hS_le
  have hS_ne_pref : (rankPrefixSet S M_sync).Nonempty := hfull.symm ▸ hS_ne
  have hmax_eq : rReadL 1 mN 27 0 = S.sup' hS_ne (fun x => euclideanDistSq (livePts x) prov.o) := by
    have h1 := hsupN hS_ne_pref
    simpa [hfull] using h1
  have hmax_nn : 0 ≤ rReadL 1 mN 27 0 := by
    rw [hmax_eq]
    rcases hS_ne with ⟨x0, hx0⟩
    exact le_trans (by unfold euclideanDistSq; positivity)
      (Finset.le_sup' (fun x => euclideanDistSq (livePts x) prov.o) hx0)
  have hball_eq := applyBirthCoreFallback_eq_nat hD livePts hS_ne prov hmax_eq hmax_nn
  dsimp only at hball_eq
  rw [hfull] at hmN_3
  by_cases hnat : S.card ≤ 8 * D ^ 2 * (prov.core livePts S).card
  · have hcond_f : cValAt 1 inp mN
        (.intLe (.readLocal 27 (.lit 1))
                (.mul (.lit (((8 * D ^ 2 : ℕ) : ℤ))) (.readLocal 27 (.lit 3)))) = true := by
      simp only [cValAt_intLe, iValAt_readLocal, iValAt_mul, iValAt_lit, hmN_1, hmN_3,
        decide_eq_true_eq]
      exact_mod_cast hnat
    have hV_eq : ball.V = prov.V := by rw [hball_eq.2, if_pos hnat]
    refine ⟨mN.popDepth 0,
      DetExecAt.localScope
        ((hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq (hs6.seq (hs7.seq (hs8.seq (hs9.seq
          (hrep.seq (DetExecAt.ite_true hcond_f (C_c := 10) (by simp [condExprOps, intExprOps])
            (DetExecAt.skip 1 inp mN)))))))))))).mono_cost (by
              simp only [intExprOps, C_it]
              have hmul : M_sync * (180 * (K + d + 5)) = 180 * M_sync * (K + d + 5) := by ring
              have hexp : 200 * (M_sync + 1) * (K + d + 5) =
                  180 * M_sync * (K + d + 5) + 20 * M_sync * (K + d + 5) + 200 * (K + d + 5) := by ring
              omega)),
      popDepth_zero_idem mN,
      by simp [hwN_24],
      fun t ht idx => by simp [hwN_o t ht],
      fun idx h24 => by simp [hwN_26 idx h24],
      fun t _ idx => by simp [hrN],
      fun c => by rw [rRead_popDepth, hrN, hball_eq.1]; exact hprov_o c,
      by rw [rRead_popDepth, hrN, hV_eq]; exact hprov_V⟩
  · have hcond_f : cValAt 1 inp mN
        (.intLe (.readLocal 27 (.lit 1))
                (.mul (.lit (((8 * D ^ 2 : ℕ) : ℤ))) (.readLocal 27 (.lit 3)))) = false := by
      simp only [cValAt_intLe, iValAt_readLocal, iValAt_mul, iValAt_lit, hmN_1, hmN_3,
        decide_eq_false_iff_not]
      exact_mod_cast hnat
    have hV_eq : ball.V = rReadL 1 mN 27 0 := by rw [hball_eq.2, if_neg hnat]
    let mEnd := rWrite mN 27 (d : ℤ) (rReadL 1 mN 27 0)
    have hs_end : DetExecAt 1 inp
        (boxWriteR M_box 27 (.lit (d : ℤ)) (.readRealLocal 27 (.lit 0))) mN mEnd 18 :=
      exec_boxWriteR inp mN _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps, realExprOps])
    refine ⟨mEnd.popDepth 0,
      DetExecAt.localScope
        ((hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq (hs6.seq (hs7.seq (hs8.seq (hs9.seq
          (hrep.seq (DetExecAt.ite_false hcond_f (C_c := 10) (by simp [condExprOps, intExprOps])
            hs_end))))))))))).mono_cost (by
              simp only [intExprOps, C_it]
              have hmul : M_sync * (180 * (K + d + 5)) = 180 * M_sync * (K + d + 5) := by ring
              have hexp : 200 * (M_sync + 1) * (K + d + 5) =
                  180 * M_sync * (K + d + 5) + 20 * M_sync * (K + d + 5) + 200 * (K + d + 5) := by ring
              omega)),
      popDepth_zero_idem mEnd,
      by simp [mEnd, hwN_24],
      fun t ht idx => by simp [mEnd, hwN_o t ht],
      fun idx h24 => by simp [mEnd, hwN_26 idx h24],
      fun t ht idx => by simp [mEnd, ht, hrN],
      fun c => ?_,
      by rw [rRead_popDepth]; simp only [mEnd, rRead_rWrite_self]; exact hV_eq.symm⟩
    have hne : (c.val : ℤ) ≠ (d : ℤ) := by have := c.isLt; omega
    rw [rRead_popDepth, hball_eq.1]
    simp only [mEnd, rRead_rWrite_eq, true_and, hne, ↓reduceIte, hrN]
    exact hprov_o c

theorem exec_syncCoreAndPartitionStmt {d n D K NumSlots M_sync M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s_src dictS spareS resS : ℕ} {S : Finset ℕ} {fSq_src : ℕ → ℝ}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d}
    (hD : 3 ≤ D)
    (hs_lt : s_src < NumSlots) (hd_lt : dictS < NumSlots)
    (hsp_lt : spareS < NumSlots) (hr_lt : resS < NumSlots)
    (hdist : s_src ≠ dictS ∧ s_src ≠ spareS ∧ s_src ≠ resS ∧
             dictS ≠ spareS ∧ dictS ≠ resS ∧ spareS ≠ resS)
    (hs_reg : wRead mem 26 1 = (s_src : ℤ))
    (hd_reg : wRead mem 26 20 = (dictS : ℤ))
    (hsp_reg : wRead mem 26 21 = (spareS : ℤ))
    (hr_reg : wRead mem 26 22 = (resS : ℤ))
    (hS_pos : 0 < S.card) (hS_le : S.card ≤ M_sync)
    (hS_sub : S ⊆ activeH)
    (hBox26 : 26 ≤ M_box) (hBox_d : d + 1 ≤ M_box)
    (hMs : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (hgen : SegGenBound K NumSlots mem)
    (hSeg_src : EncSegSlot K mem s_src S fSq_src)
    (hSeg_d0 : EncSegSlot K mem dictS ∅ (fun x => euclideanDistSq (livePts x) prov.o))
    (hSeg_sp0 : EncSegSlot K mem spareS ∅ (fun _ => 0))
    (hSeg_r0 : EncSegSlot K mem resS ∅ (fun _ => 0))
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hprov_o : ∀ c : Fin d, rRead mem 27 (c.val : ℤ) = euclideanCoord prov.o c)
    (hprov_V : rRead mem 27 (d : ℤ) = prov.V) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    let ball := applyBirthCoreFallback α livePts S prov
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (syncCoreAndPartitionStmt d D K M_sync M_box) mem m'
        (1200 * (M_sync + 1) * (K + d + 5) + 600) ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      EncSegSlot K m' dictS S (fun x => euclideanDistSq (livePts x) ball.o) ∧
      EncSegSlot K m' spareS S (fun _ => 0) ∧
      EncSegSlot K m' resS (ball.residual livePts S) (fun _ => 0) ∧
      (∀ s' < NumSlots, s' ≠ dictS → s' ≠ spareS → s' ≠ resS →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ t, t ≠ 8 → t ≠ 26 → t ≠ 27 → ∀ idx, rRead m' t idx = rRead mem t idx) ∧
      (∀ c : Fin d, rRead m' 27 (c.val : ℤ) = euclideanCoord ball.o c) ∧
      rRead m' 27 (d : ℤ) = ball.V := by
  classical
  intro α ball
  rcases hdist with ⟨hs_d, hs_sp, hs_r, hd_sp, hd_r, hsp_r⟩
  have hbo : ball.o = prov.o := by
    unfold ball applyBirthCoreFallback
    split_ifs <;> rfl
  rcases exec_syncCoreFinalizeScopeStmt inp mem hD hs_reg hS_pos hS_le hS_sub hBox26 hBox_d
      hSeg_src hLive hprov_o hprov_V
    with ⟨mf, hdf, _, hw24_f, hwf_o, hwf_26, hrf_o, hbo_f, hbV_f⟩
  let mp0 := wWrite mf 26 23 0
  have hdp0 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 23) (.lit 0)) mf mp0 14 :=
    exec_boxWriteW inp mf _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  let C_p : ℕ := 950 * (K + d + 5)
  let InvP : ℕ → ArithRAMMemory → Prop := fun k m =>
    SegGenBound K NumSlots m ∧
    EncSegSlot K m dictS (rankPrefixSet S k) (fun x => euclideanDistSq (livePts x) ball.o) ∧
    EncSegSlot K m spareS (rankPrefixSet S k) (fun _ => 0) ∧
    EncSegSlot K m resS (ball.residual livePts (rankPrefixSet S k)) (fun _ => 0) ∧
    (∀ s' < NumSlots, s' ≠ dictS → s' ≠ spareS → s' ≠ resS →
      ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m s' S₁ fSq₁) ∧
    (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ idx, wRead m t idx = wRead mem t idx) ∧
    wRead m 26 1 = (s_src : ℤ) ∧
    wRead m 26 20 = (dictS : ℤ) ∧
    wRead m 26 21 = (spareS : ℤ) ∧
    wRead m 26 22 = (resS : ℤ) ∧
    wRead m 26 23 = (k : ℤ) ∧
    wRead m 26 24 = (S.card : ℤ) ∧
    (∀ t, t ≠ 8 → t ≠ 26 → t ≠ 27 → ∀ idx, rRead m t idx = rRead mem t idx) ∧
    (∀ c : Fin d, rRead m 27 (c.val : ℤ) = euclideanCoord ball.o c) ∧
    rRead m 27 (d : ℤ) = ball.V
  have hInvP0 : InvP 0 mp0 := by
    have hd_emp : EncSegSlot K mp0 dictS (rankPrefixSet S 0) (fun x => euclideanDistSq (livePts x) ball.o) := by
      rw [rankPrefixSet_zero, hbo]
      exact hSeg_d0.congr_mem_fSq
        (by simp [mp0, hwf_o 5 (by decide)])
        (fun _ _ => by simp [mp0, hwf_o 8 (by decide)])
        (fun _ _ => by simp [mp0, hwf_o 9 (by decide)])
        (fun _ _ => by simp [mp0, hwf_o 10 (by decide)])
        (fun _ _ => by simp [mp0, hrf_o 8 (by decide)])
        (fun _ _ => rfl)
    have hsp_emp : EncSegSlot K mp0 spareS (rankPrefixSet S 0) (fun _ => 0) := by
      rw [rankPrefixSet_zero]
      exact hSeg_sp0.congr_mem_fSq
        (by simp [mp0, hwf_o 5 (by decide)])
        (fun _ _ => by simp [mp0, hwf_o 8 (by decide)])
        (fun _ _ => by simp [mp0, hwf_o 9 (by decide)])
        (fun _ _ => by simp [mp0, hwf_o 10 (by decide)])
        (fun _ _ => by simp [mp0, hrf_o 8 (by decide)])
        (fun _ _ => rfl)
    have hr_emp : EncSegSlot K mp0 resS (ball.residual livePts (rankPrefixSet S 0)) (fun _ => 0) := by
      have hres0 : ball.residual livePts (rankPrefixSet S 0) = ∅ := by
        rw [rankPrefixSet_zero]; rfl
      rw [hres0]
      exact hSeg_r0.congr_mem_fSq
        (by simp [mp0, hwf_o 5 (by decide)])
        (fun _ _ => by simp [mp0, hwf_o 8 (by decide)])
        (fun _ _ => by simp [mp0, hwf_o 9 (by decide)])
        (fun _ _ => by simp [mp0, hwf_o 10 (by decide)])
        (fun _ _ => by simp [mp0, hrf_o 8 (by decide)])
        (fun _ _ => rfl)
    refine ⟨⟨by simp [mp0, hwf_o 1 (by decide)]; exact hgen.1,
       fun s' hs' => by simp [mp0, hwf_o 5 (by decide), hwf_o 1 (by decide)]; exact hgen.2.1 s' hs',
       fun s' hs' u hu => by simp [mp0, hwf_o 8 (by decide), hwf_o 1 (by decide)]; exact hgen.2.2 s' hs' u hu⟩,
      hd_emp, hsp_emp, hr_emp,
      fun s' _ _ _ _ S₁ fSq₁ h1 =>
        h1.congr_mem_fSq (by simp [mp0, hwf_o 5 (by decide)])
          (fun _ _ => by simp [mp0, hwf_o 8 (by decide)])
          (fun _ _ => by simp [mp0, hwf_o 9 (by decide)])
          (fun _ _ => by simp [mp0, hwf_o 10 (by decide)])
          (fun _ _ => by simp [mp0, hrf_o 8 (by decide)]) (fun _ _ => rfl),
      fun t _ _ _ h26 idx => by simp [mp0, h26, hwf_o t h26],
      by simp [mp0, hwf_26 1 (by decide), hs_reg],
      by simp [mp0, hwf_26 20 (by decide), hd_reg],
      by simp [mp0, hwf_26 21 (by decide), hsp_reg],
      by simp [mp0, hwf_26 22 (by decide), hr_reg],
      by simp [mp0],
      by simp [mp0, hw24_f],
      fun t _ _ h27 idx => by simp [mp0, hrf_o t h27],
      fun c => by rw [rRead_wWrite]; exact hbo_f c,
      by rw [rRead_wWrite]; exact hbV_f⟩
  have hStepP : ∀ k < M_sync, ∀ m, InvP k m →
      ∃ m', DetExecAt 0 inp (syncPartOneElemStmt d K M_box) m m' C_p ∧ InvP (k + 1) m' := by
    intro k _ m ⟨hgen_m, hEd, hEsp, hEr, hEo, hw_mo,
      hm26_1, hm26_20, hm26_21, hm26_22, hm26_23, hm26_24, hr_mo, hbo_m, hbV_m⟩
    have hSeg_src_m : EncSegSlot K m s_src S fSq_src :=
      hEo s_src hs_lt hs_d hs_sp hs_r S fSq_src hSeg_src
    have hLive_m : EncLiveCoords d n m activeH livePts :=
      ⟨hLive.1, fun h hh c => by rw [hr_mo 4 (by decide) (by decide) (by decide)]; exact hLive.2 h hh c⟩
    by_cases hk_lt : k < S.card
    · let xk : ℕ := S.orderEmbOfFin rfl ⟨k, hk_lt⟩
      have hxk_in : xk ∈ S := S.orderEmbOfFin_mem rfl ⟨k, hk_lt⟩
      have hxk_act : xk ∈ activeH := hS_sub hxk_in
      have hxk_lt2K : xk < 2 ^ K := hSeg_src.2.1 xk hxk_in
      have hpref_succ : rankPrefixSet S (k + 1) = insert xk (rankPrefixSet S k) :=
        rankPrefixSet_succ_lt hk_lt
      -- 1. Execute syncPartSelectScopeStmt (true branch)
      have hSel : ∃ ms : ArithRAMMemory,
          DetExecAt 0 inp (syncPartSelectScopeStmt K M_box) m ms (80 * (K + 1) + 120) ∧
          (∀ t, t ≠ 26 → ∀ idx, wRead ms t idx = wRead m t idx) ∧
          (∀ t idx, rRead ms t idx = rRead m t idx) ∧
          wRead ms 26 4 = (xk : ℤ) ∧
          wRead ms 26 5 = 1 ∧
          wRead ms 26 6 = 0 ∧
          wRead ms 26 25 = 1 ∧
          wRead ms 26 23 = (((k + 1 : ℕ) : ℤ)) ∧
          (∀ idx, idx ≠ 4 → idx ≠ 5 → idx ≠ 6 → idx ≠ 25 → idx ≠ 23 →
            wRead ms 26 idx = wRead m 26 idx) := by
        let l0 := m.popDepth 0
        let l1 := wWriteL 1 l0 27 2 (k : ℤ)
        have hl1 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 2) (.readHeap 26 (.lit 23))) l0 l1 6 :=
          DetExecAt.writeWordLocal 1 inp l0 27 _ _ rfl (by simp [l0, hm26_23]) (by simp [intExprOps])
        have hcond_s : cValAt 1 inp l1 (.intLt (.readLocal 27 (.lit 2)) (.readHeap 26 (.lit 24))) = true := by
          simp [l1, l0, hm26_24, hk_lt]
        let l2 := wWriteL 1 l1 28 20 (s_src : ℤ)
        let l3 := wWriteL 1 l2 28 21 (k : ℤ)
        have hl2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 1))) l1 l2 6 :=
          DetExecAt.writeWordLocal 1 inp l1 28 _ _ rfl (by simp [l1, l0, hm26_1]) (by simp [intExprOps])
        have hl3 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readLocal 27 (.lit 2))) l2 l3 6 :=
          DetExecAt.writeWordLocal 1 inp l2 28 _ _ rfl (by simp [l2, l1]) (by simp [intExprOps])
        have hSeg_l3 : EncSegSlot K l3 s_src S fSq_src :=
          hSeg_src_m.congr_mem_fSq (by simp [l3, l2, l1, l0]) (fun _ _ => by simp [l3, l2, l1, l0])
            (fun _ _ => by simp [l3, l2, l1, l0]) (fun _ _ => by simp [l3, l2, l1, l0])
            (fun _ _ => by simp [l3, l2, l1, l0]) (fun _ _ => rfl)
        rcases exec_selectByRankSegStmt inp l3 hk_lt (by simp [l3, l2]) (by simp [l3]) hSeg_l3
          with ⟨l4, hl4, hsel_l4, hw_l4, hr_l4, hwl_l4, _⟩
        let l5 := wWrite l4 26 4 (xk : ℤ)
        let l6 := wWrite l5 26 5 1
        let l7 := wWrite l6 26 6 0
        let l8 := wWrite l7 26 25 1
        let l9 := wWrite l8 26 23 (((k + 1 : ℕ) : ℤ))
        have hl5 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 4) (.readLocal 28 (.lit 0))) l4 l5 16 :=
          exec_boxWriteW inp l4 _ _ rfl (by omega) (by omega) (by simp [hsel_l4, xk]) (by simp [intExprOps])
        have hl6 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 5) (.lit 1)) l5 l6 14 :=
          exec_boxWriteW inp l5 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
        have hl7 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 6) (.lit 0)) l6 l7 14 :=
          exec_boxWriteW inp l6 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
        have hl8 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 25) (.lit 1)) l7 l8 14 :=
          exec_boxWriteW inp l7 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
        have hl9 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 23) (.add (.readLocal 27 (.lit 2)) (.lit 1))) l8 l9 18 :=
          exec_boxWriteW inp l8 _ _ rfl (by omega) (by omega)
            (by simp [l8, l7, l6, l5, hwl_l4 27 (by decide), l3, l2, l1]) (by simp [intExprOps])
        refine ⟨l9.popDepth 0,
          DetExecAt.localScope ((hl1.seq
            ((DetExecAt.ite_true hcond_s (C_c := 10) (by simp [condExprOps, intExprOps])
              (hl2.seq (hl3.seq (hl4.seq (hl5.seq (hl6.seq (hl7.seq hl8))))))).seq hl9)).mono_cost (by omega)),
          fun t ht idx => by simp [l9, l8, l7, l6, l5, ht, hw_l4, l3, l2, l1, l0],
          fun t idx => by simp [l9, l8, l7, l6, l5, hr_l4, l3, l2, l1, l0],
          by simp [l9, l8, l7, l6, l5],
          by simp [l9, l8, l7, l6],
          by simp [l9, l8, l7],
          by simp [l9, l8],
          by simp [l9],
          fun idx a b c d e => by simp [l9, l8, l7, l6, l5, a, b, c, d, e, hw_l4, l3, l2, l1, l0]⟩
      rcases hSel with ⟨ms, hds, hws_o, hrs, hs4_r, hs5_r, hs6_r, hs25_r, hs23_r, hws_26⟩
      have hcond_25 : cValAt 0 inp ms (.intEq (.readHeap 26 (.lit 25)) (.lit 1)) = true := by
        simp [hs25_r]
      -- 2. Update dictS via updSegCenterStmt
      let mu1 := wWrite ms 26 3 (dictS : ℤ)
      have hdu1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 3) (.readHeap 26 (.lit 20))) ms mu1 16 :=
        exec_boxWriteW inp ms _ _ rfl (by omega) (by omega)
          (by simp [hws_26 20 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_20])
          (by simp [intExprOps])
      have hgen_u1 : SegGenBound K NumSlots mu1 :=
        ⟨by simp [mu1, hws_o 1 (by decide)]; exact hgen_m.1,
         fun s' hs' => by simp [mu1, hws_o 5 (by decide), hws_o 1 (by decide)]; exact hgen_m.2.1 s' hs',
         fun s' hs' u hu => by simp [mu1, hws_o 8 (by decide), hws_o 1 (by decide)]; exact hgen_m.2.2 s' hs' u hu⟩
      have hEd_u1 : EncSegSlot K mu1 dictS (rankPrefixSet S k) (fun x => euclideanDistSq (livePts x) ball.o) :=
        hEd.congr_mem_fSq (by simp [mu1, hws_o 5 (by decide)])
          (fun _ _ => by simp [mu1, hws_o 8 (by decide)])
          (fun _ _ => by simp [mu1, hws_o 9 (by decide)])
          (fun _ _ => by simp [mu1, hws_o 10 (by decide)])
          (fun _ _ => by simp [mu1, hrs]) (fun _ _ => rfl)
      have hLive_u1 : EncLiveCoords d n mu1 activeH livePts :=
        ⟨hLive_m.1, fun h hh c => by simp only [mu1, rRead_wWrite, hrs]; exact hLive_m.2 h hh c⟩
      rcases exec_updSegCenterStmt inp mu1 (rTag := 27) (oBase := 0) (ins := true) (o := ball.o)
          hd_lt hxk_lt2K (by omega) hMs ⟨by decide, by decide⟩
          (by simp [mu1]) (by simp [mu1, hs4_r]) (by simp [mu1, hs5_r]) (by simp [mu1, hs6_r])
          (fun c => by simpa [mu1, hrs] using hbo_m c) hLive_u1 (fun _ => hxk_act) (fun _ _ _ => rfl)
          hgen_u1 hEd_u1
        with ⟨mu2, hdu2, _, hgen_u2, hEd_u2, hrSq_u2, hOther_u2, hw_u2, hr_u2_o, _⟩
      -- 3. Update spareS via updSegZeroStmt
      let mu3 := wWrite mu2 26 3 (spareS : ℤ)
      have hdu3 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 3) (.readHeap 26 (.lit 21))) mu2 mu3 16 :=
        exec_boxWriteW inp mu2 _ _ rfl (by omega) (by omega)
          (by simp [hw_u2 26 (by decide) (by decide) (by decide), mu1,
            hws_26 21 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_21])
          (by simp [intExprOps])
      have hgen_u3 : SegGenBound K NumSlots mu3 :=
        ⟨by simp [mu3]; exact hgen_u2.1,
         fun s' hs' => by simp [mu3]; exact hgen_u2.2.1 s' hs',
         fun s' hs' u hu => by simp [mu3]; exact hgen_u2.2.2 s' hs' u hu⟩
      have hEsp_u1 : EncSegSlot K mu1 spareS (rankPrefixSet S k) (fun _ => 0) :=
        hEsp.congr_mem_fSq (by simp [mu1, hws_o 5 (by decide)])
          (fun _ _ => by simp [mu1, hws_o 8 (by decide)])
          (fun _ _ => by simp [mu1, hws_o 9 (by decide)])
          (fun _ _ => by simp [mu1, hws_o 10 (by decide)])
          (fun _ _ => by simp [mu1, hrs]) (fun _ _ => rfl)
      have hEsp_u2 := hOther_u2 spareS hsp_lt hd_sp.symm _ _ hEsp_u1
      have hEsp_u3 : EncSegSlot K mu3 spareS (rankPrefixSet S k) (fun _ => 0) :=
        hEsp_u2.congr_mem_fSq (by simp [mu3]) (fun _ _ => by simp [mu3])
          (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => rfl)
      rcases exec_updSegZeroStmt inp mu3 (ins := true) hsp_lt hxk_lt2K hMs
          (by simp [mu3])
          (by simp [mu3, hw_u2 26 (by decide) (by decide) (by decide), mu1, hs4_r])
          (by simp [mu3, hw_u2 26 (by decide) (by decide) (by decide), mu1, hs5_r])
          hgen_u3 hEsp_u3
        with ⟨mu4, hdu4, _, hgen_u4, hEsp_u4, hOther_u4, hw_u4, hr_u4⟩
      -- 4. Conditional update of resS based on rRead 26 0 ≤ rRead 27 d
      have hr26_u4 : rRead mu4 26 0 = euclideanDistSq (livePts xk) ball.o := by
        simp [hr_u4 26 (by decide), mu3, hrSq_u2 rfl]
      have hr27d_u4 : rRead mu4 27 (d : ℤ) = ball.V := by
        simp [hr_u4 27 (by decide), mu3, hr_u2_o 27 (by decide) (by decide), mu1, hrs, hbV_m]
      have hEr_u1 : EncSegSlot K mu1 resS (ball.residual livePts (rankPrefixSet S k)) (fun _ => 0) :=
        hEr.congr_mem_fSq (by simp [mu1, hws_o 5 (by decide)])
          (fun _ _ => by simp [mu1, hws_o 8 (by decide)])
          (fun _ _ => by simp [mu1, hws_o 9 (by decide)])
          (fun _ _ => by simp [mu1, hws_o 10 (by decide)])
          (fun _ _ => by simp [mu1, hrs]) (fun _ _ => rfl)
      have hEr_u2 := hOther_u2 resS hr_lt hd_r.symm _ _ hEr_u1
      have hEr_u3 : EncSegSlot K mu3 resS (ball.residual livePts (rankPrefixSet S k)) (fun _ => 0) :=
        hEr_u2.congr_mem_fSq (by simp [mu3]) (fun _ _ => by simp [mu3])
          (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => rfl)
      have hEr_u4 := hOther_u4 resS hr_lt hsp_r.symm _ _ hEr_u3
      have hEd_u3 : EncSegSlot K mu3 dictS (rankPrefixSet S (k + 1)) (fun x => euclideanDistSq (livePts x) ball.o) := by
        rw [hpref_succ]
        exact hEd_u2.congr_mem_fSq (by simp [mu3]) (fun _ _ => by simp [mu3])
          (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => rfl)
      have hEd_u4 := hOther_u4 dictS hd_lt hd_sp _ _ hEd_u3
      have hEsp_u4' : EncSegSlot K mu4 spareS (rankPrefixSet S (k + 1)) (fun _ => 0) := by
        rw [hpref_succ]; exact hEsp_u4
      have hres_succ := nodeResidual_insert livePts ball (rankPrefixSet S k) xk
      by_cases hle_core : euclideanDistSq (livePts xk) ball.o ≤ ball.V
      · have hcond_r : cValAt 0 inp mu4
            (.realLe (.readRealHeap 26 (.lit 0)) (.readRealHeap 27 (.lit (d : ℤ)))) = true := by
          simp [hr26_u4, hr27d_u4, hle_core]
        have hEr_u4' : EncSegSlot K mu4 resS (ball.residual livePts (rankPrefixSet S (k + 1))) (fun _ => 0) := by
          rw [hpref_succ, hres_succ, if_pos hle_core]
          exact hEr_u4
        refine ⟨mu4,
          (hds.seq (DetExecAt.ite_true hcond_25 (C_c := 10) (by simp [condExprOps, intExprOps])
            (hdu1.seq (hdu2.seq (hdu3.seq (hdu4.seq
              (DetExecAt.ite_true hcond_r (C_c := 10) (by simp [condExprOps, realExprOps, intExprOps])
                (DetExecAt.skip 0 inp mu4)))))))).mono_cost (by dsimp [C_p]; omega),
          hgen_u4, hEd_u4, hEsp_u4', hEr_u4',
          fun s' hs' h1 h2 h3 S₁ fSq₁ h0 => by
            have hm0 := hEo s' hs' h1 h2 h3 S₁ fSq₁ h0
            have hu1_s : EncSegSlot K mu1 s' S₁ fSq₁ :=
              hm0.congr_mem_fSq (by simp [mu1, hws_o 5 (by decide)])
                (fun _ _ => by simp [mu1, hws_o 8 (by decide)])
                (fun _ _ => by simp [mu1, hws_o 9 (by decide)])
                (fun _ _ => by simp [mu1, hws_o 10 (by decide)])
                (fun _ _ => by simp [mu1, hrs]) (fun _ _ => rfl)
            have hu2_s := hOther_u2 s' hs' h1 S₁ fSq₁ hu1_s
            have hu3_s : EncSegSlot K mu3 s' S₁ fSq₁ :=
              hu2_s.congr_mem_fSq (by simp [mu3]) (fun _ _ => by simp [mu3])
                (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => rfl)
            exact hOther_u4 s' hs' h2 S₁ fSq₁ hu3_s,
          fun t h8 h9 h10 h26 idx => by
            simp [hw_u4 t h8 h9 h10, mu3, h26, hw_u2 t h8 h9 h10, mu1, hws_o t h26, hw_mo t h8 h9 h10 h26],
          by simp [hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 1 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_1],
          by simp [hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 20 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_20],
          by simp [hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 21 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_21],
          by simp [hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 22 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_22],
          by simp [hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1, hs23_r],
          by simp [hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 24 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_24],
          fun t h8 h26 h27 idx => by
            simp [hr_u4 t h8, mu3, hr_u2_o t h8 h26, mu1, hrs, hr_mo t h8 h26 h27],
          fun c => by rw [hr_u4 27 (by decide)]; simp only [mu3, rRead_wWrite, hr_u2_o 27 (by decide) (by decide), mu1, hrs]; exact hbo_m c,
          hr27d_u4⟩
      · have hcond_r : cValAt 0 inp mu4
            (.realLe (.readRealHeap 26 (.lit 0)) (.readRealHeap 27 (.lit (d : ℤ)))) = false := by
          simp [hr26_u4, hr27d_u4, hle_core]
        let mu5 := wWrite mu4 26 3 (resS : ℤ)
        have hdu5 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 3) (.readHeap 26 (.lit 22))) mu4 mu5 16 :=
          exec_boxWriteW inp mu4 _ _ rfl (by omega) (by omega)
            (by simp [hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 22 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_22])
            (by simp [intExprOps])
        have hgen_u5 : SegGenBound K NumSlots mu5 :=
          ⟨by simp [mu5]; exact hgen_u4.1,
           fun s' hs' => by simp [mu5]; exact hgen_u4.2.1 s' hs',
           fun s' hs' u hu => by simp [mu5]; exact hgen_u4.2.2 s' hs' u hu⟩
        have hEr_u5 : EncSegSlot K mu5 resS (ball.residual livePts (rankPrefixSet S k)) (fun _ => 0) :=
          hEr_u4.congr_mem_fSq (by simp [mu5]) (fun _ _ => by simp [mu5])
            (fun _ _ => by simp [mu5]) (fun _ _ => by simp [mu5]) (fun _ _ => by simp [mu5]) (fun _ _ => rfl)
        rcases exec_updSegZeroStmt inp mu5 (ins := true) hr_lt hxk_lt2K hMs
            (by simp [mu5])
            (by simp [mu5, hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1, hs4_r])
            (by simp [mu5, hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1, hs5_r])
            hgen_u5 hEr_u5
          with ⟨mu6, hdu6, _, hgen_u6, hEr_u6, hOther_u6, hw_u6, hr_u6⟩
        have hEr_u6' : EncSegSlot K mu6 resS (ball.residual livePts (rankPrefixSet S (k + 1))) (fun _ => 0) := by
          rw [hpref_succ, hres_succ, if_neg hle_core]
          exact hEr_u6
        have hEd_u5 : EncSegSlot K mu5 dictS (rankPrefixSet S (k + 1)) (fun x => euclideanDistSq (livePts x) ball.o) :=
          hEd_u4.congr_mem_fSq (by simp [mu5]) (fun _ _ => by simp [mu5])
            (fun _ _ => by simp [mu5]) (fun _ _ => by simp [mu5]) (fun _ _ => by simp [mu5]) (fun _ _ => rfl)
        have hEsp_u5 : EncSegSlot K mu5 spareS (rankPrefixSet S (k + 1)) (fun _ => 0) :=
          hEsp_u4'.congr_mem_fSq (by simp [mu5]) (fun _ _ => by simp [mu5])
            (fun _ _ => by simp [mu5]) (fun _ _ => by simp [mu5]) (fun _ _ => by simp [mu5]) (fun _ _ => rfl)
        refine ⟨mu6,
          (hds.seq (DetExecAt.ite_true hcond_25 (C_c := 10) (by simp [condExprOps, intExprOps])
            (hdu1.seq (hdu2.seq (hdu3.seq (hdu4.seq
              (DetExecAt.ite_false hcond_r (C_c := 10) (by simp [condExprOps, realExprOps, intExprOps])
                (hdu5.seq hdu6)))))))).mono_cost (by dsimp [C_p]; omega),
          hgen_u6,
          hOther_u6 dictS hd_lt hd_r _ _ hEd_u5,
          hOther_u6 spareS hsp_lt hsp_r _ _ hEsp_u5,
          hEr_u6',
          fun s' hs' h1 h2 h3 S₁ fSq₁ h0 => by
            have hm0 := hEo s' hs' h1 h2 h3 S₁ fSq₁ h0
            have hu1_s : EncSegSlot K mu1 s' S₁ fSq₁ :=
              hm0.congr_mem_fSq (by simp [mu1, hws_o 5 (by decide)])
                (fun _ _ => by simp [mu1, hws_o 8 (by decide)])
                (fun _ _ => by simp [mu1, hws_o 9 (by decide)])
                (fun _ _ => by simp [mu1, hws_o 10 (by decide)])
                (fun _ _ => by simp [mu1, hrs]) (fun _ _ => rfl)
            have hu2_s := hOther_u2 s' hs' h1 S₁ fSq₁ hu1_s
            have hu3_s : EncSegSlot K mu3 s' S₁ fSq₁ :=
              hu2_s.congr_mem_fSq (by simp [mu3]) (fun _ _ => by simp [mu3])
                (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => by simp [mu3]) (fun _ _ => rfl)
            have hu4_s := hOther_u4 s' hs' h2 S₁ fSq₁ hu3_s
            have hu5_s : EncSegSlot K mu5 s' S₁ fSq₁ :=
              hu4_s.congr_mem_fSq (by simp [mu5]) (fun _ _ => by simp [mu5])
                (fun _ _ => by simp [mu5]) (fun _ _ => by simp [mu5]) (fun _ _ => by simp [mu5]) (fun _ _ => rfl)
            exact hOther_u6 s' hs' h3 S₁ fSq₁ hu5_s,
          fun t h8 h9 h10 h26 idx => by
            simp [hw_u6 t h8 h9 h10, mu5, h26, hw_u4 t h8 h9 h10, mu3, hw_u2 t h8 h9 h10, mu1, hws_o t h26, hw_mo t h8 h9 h10 h26],
          by simp [hw_u6 26 (by decide) (by decide) (by decide), mu5,
              hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 1 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_1],
          by simp [hw_u6 26 (by decide) (by decide) (by decide), mu5,
              hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 20 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_20],
          by simp [hw_u6 26 (by decide) (by decide) (by decide), mu5,
              hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 21 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_21],
          by simp [hw_u6 26 (by decide) (by decide) (by decide), mu5,
              hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 22 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_22],
          by simp [hw_u6 26 (by decide) (by decide) (by decide), mu5,
              hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1, hs23_r],
          by simp [hw_u6 26 (by decide) (by decide) (by decide), mu5,
              hw_u4 26 (by decide) (by decide) (by decide), mu3,
              hw_u2 26 (by decide) (by decide) (by decide), mu1,
              hws_26 24 (by decide) (by decide) (by decide) (by decide) (by decide), hm26_24],
          fun t h8 h26 h27 idx => by
            simp [hr_u6 t h8, mu5, hr_u4 t h8, mu3, hr_u2_o t h8 h26, mu1, hrs, hr_mo t h8 h26 h27],
          fun c => by rw [hr_u6 27 (by decide)]; simp only [mu5, rRead_wWrite, hr_u4 27 (by decide), mu3, hr_u2_o 27 (by decide) (by decide), mu1, hrs]; exact hbo_m c,
          by rw [hr_u6 27 (by decide)]; simp only [mu5, rRead_wWrite]; exact hr27d_u4⟩
    · -- S.card ≤ k: syncPartSelectScopeStmt sets 26[25] := 0, and outer ite skips!
      have hk_ge : S.card ≤ k := by omega
      have hpref_eq : rankPrefixSet S (k + 1) = rankPrefixSet S k := rankPrefixSet_succ_ge hk_ge
      let l0 := m.popDepth 0
      let l1 := wWriteL 1 l0 27 2 (k : ℤ)
      have hl1 : DetExecAt 1 inp (.writeWordLocal 27 (.lit 2) (.readHeap 26 (.lit 23))) l0 l1 6 :=
        DetExecAt.writeWordLocal 1 inp l0 27 _ _ rfl (by simp [l0, hm26_23]) (by simp [intExprOps])
      have hcond_s : cValAt 1 inp l1 (.intLt (.readLocal 27 (.lit 2)) (.readHeap 26 (.lit 24))) = false := by
        simp [l1, l0, hm26_24, hk_lt]
      let l2 := wWrite l1 26 25 0
      let l3 := wWrite l2 26 23 (((k + 1 : ℕ) : ℤ))
      have hl2 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 25) (.lit 0)) l1 l2 14 :=
        exec_boxWriteW inp l1 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
      have hl3 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 23) (.add (.readLocal 27 (.lit 2)) (.lit 1))) l2 l3 18 :=
        exec_boxWriteW inp l2 _ _ rfl (by omega) (by omega) (by simp [l2, l1]) (by simp [intExprOps])
      let ms := l3.popDepth 0
      have hds : DetExecAt 0 inp (syncPartSelectScopeStmt K M_box) m ms 60 :=
        DetExecAt.localScope ((hl1.seq
          ((DetExecAt.ite_false hcond_s (C_c := 10) (by simp [condExprOps, intExprOps]) hl2).seq hl3)).mono_cost (by omega))
      have hcond_25 : cValAt 0 inp ms (.intEq (.readHeap 26 (.lit 25)) (.lit 1)) = false := by
        simp [ms, l3, l2]
      refine ⟨ms,
        (hds.seq (DetExecAt.ite_false hcond_25 (C_c := 10) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp ms))).mono_cost
          (by dsimp [C_p]; exact le_trans (by omega : 60 + (10 + 1) ≤ 950 * 5) (Nat.mul_le_mul_left _ (by omega))),
        ⟨by simp [ms, l3, l2, l1, l0]; exact hgen_m.1,
         fun s' hs' => by simp [ms, l3, l2, l1, l0]; exact hgen_m.2.1 s' hs',
         fun s' hs' u hu => by simp [ms, l3, l2, l1, l0]; exact hgen_m.2.2 s' hs' u hu⟩,
        by rw [hpref_eq]; exact hEd.congr_mem_fSq (by simp [ms, l3, l2, l1, l0])
            (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => by simp [ms, l3, l2, l1, l0])
            (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => rfl),
        by rw [hpref_eq]; exact hEsp.congr_mem_fSq (by simp [ms, l3, l2, l1, l0])
            (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => by simp [ms, l3, l2, l1, l0])
            (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => rfl),
        by rw [hpref_eq]; exact hEr.congr_mem_fSq (by simp [ms, l3, l2, l1, l0])
            (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => by simp [ms, l3, l2, l1, l0])
            (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => rfl),
        fun s' hs' h1 h2 h3 S₁ fSq₁ h0 =>
          (hEo s' hs' h1 h2 h3 S₁ fSq₁ h0).congr_mem_fSq (by simp [ms, l3, l2, l1, l0])
            (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => by simp [ms, l3, l2, l1, l0])
            (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => by simp [ms, l3, l2, l1, l0]) (fun _ _ => rfl),
        fun t h8 h9 h10 h26 idx => by simp [ms, l3, l2, h26, l1, l0, hw_mo t h8 h9 h10 h26],
        by simp [ms, l3, l2, l1, l0, hm26_1],
        by simp [ms, l3, l2, l1, l0, hm26_20],
        by simp [ms, l3, l2, l1, l0, hm26_21],
        by simp [ms, l3, l2, l1, l0, hm26_22],
        by simp [ms, l3],
        by simp [ms, l3, l2, l1, l0, hm26_24],
        fun t h8 h26 h27 idx => by simp [ms, l3, l2, l1, l0, hr_mo t h8 h26 h27],
        fun c => by simp only [ms, rRead_popDepth, l3, l2, rRead_wWrite, l1, rRead_wWriteL, l0]; exact hbo_m c,
        by simp only [ms, rRead_popDepth, l3, l2, rRead_wWrite, l1, rRead_wWriteL, l0]; exact hbV_m⟩
  rcases DetExecAt.repeatN_nat (.lit (M_sync : ℤ)) _ M_sync 4 C_p InvP hInvP0 rfl
      (by simp [intExprOps]) hStepP
    with ⟨mpN, ⟨hgenN, hEdN, hEspN, hErN, hEoN, hwNo, _, _, _, _, _, _, hrNo, hboN, hbVN⟩, hrepP⟩
  have hfull : rankPrefixSet S M_sync = S := rankPrefixSet_full hS_le
  rw [hfull] at hEdN hEspN hErN
  have hclean : DetExecAt 0 inp (.localScope .skip) mpN ((mpN.popDepth 0).popDepth 0) 2 :=
    (DetExecAt.localScope (DetExecAt.skip 1 inp (mpN.popDepth 0))).mono_cost (by omega)
  rw [popDepth_zero_idem] at hclean
  refine ⟨mpN.popDepth 0,
    (hdf.seq (hdp0.seq (hrepP.seq hclean))).mono_cost (by
      simp only [C_p]
      have hmul : M_sync * (950 * (K + d + 5)) = 950 * M_sync * (K + d + 5) := by ring
      have hexp : 1200 * (M_sync + 1) * (K + d + 5) =
          200 * (M_sync + 1) * (K + d + 5) + 950 * M_sync * (K + d + 5) +
          50 * M_sync * (K + d + 5) + 1000 * (K + d + 5) := by ring
      omega),
    popDepth_zero_idem mpN,
    ⟨by simp; exact hgenN.1,
     fun s' hs' => by simp; exact hgenN.2.1 s' hs',
     fun s' hs' u hu => by simp; exact hgenN.2.2 s' hs' u hu⟩,
    hEdN.congr_mem_fSq (by simp) (fun _ _ => by simp) (fun _ _ => by simp)
      (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
    hEspN.congr_mem_fSq (by simp) (fun _ _ => by simp) (fun _ _ => by simp)
      (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
    hErN.congr_mem_fSq (by simp) (fun _ _ => by simp) (fun _ _ => by simp)
      (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
    fun s' hs' h1 h2 h3 S₁ fSq₁ h0 =>
      (hEoN s' hs' h1 h2 h3 S₁ fSq₁ h0).congr_mem_fSq (by simp) (fun _ _ => by simp)
        (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl),
    fun t h8 h9 h10 h26 idx => by simp [hwNo t h8 h9 h10 h26],
    fun t h8 h26 h27 idx => by simp [hrNo t h8 h26 h27],
    fun c => by rw [rRead_popDepth]; exact hboN c,
    by rw [rRead_popDepth]; exact hbVN⟩

end UL.Proof_lem_7_2_RacerP46
