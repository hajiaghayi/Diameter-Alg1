import UL.Proof.lem_7_2.CG04_RouteRelB2
import UL.Proof.lem_7_2.CG04_StepB
import UL.Proof.lem_7_2.CG03_JobTickA3a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Answer-Stage Congruence & Readout Extraction for `EncServingChainRelaxed` -/

lemma EncServingNodeRelaxed.congr_not_0_26 {d K NumSlots : ℕ} {mem m' : ArithRAMMemory}
    {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {r : ℕ} {N : ChainNode d} {S_r : Finset ℕ} {age_r : ℕ} {idle : Bool}
    (h : EncServingNodeRelaxed d K NumSlots mem livePts r N S_r age_r idle)
    (hw : ∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx)
    (hr : ∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx) :
    EncServingNodeRelaxed d K NumSlots m' livePts r N S_r age_r idle := by
  rcases h with ⟨dS, spS, hdS0, hdS_lt, hspS0, hspS_lt, hne,
    h13, h14, h15, h6d, h6sp, h12, hr13, hSegD, T_sp, hSegSp, hidle⟩
  refine ⟨dS, spS, hdS0, hdS_lt, hspS0, hspS_lt, hne,
    by rw [hw 13 (by decide) (by decide)]; exact h13,
    by rw [hw 14 (by decide) (by decide)]; exact h14,
    by rw [hw 15 (by decide) (by decide)]; exact h15,
    by rw [hw 6 (by decide) (by decide)]; exact h6d,
    by rw [hw 6 (by decide) (by decide)]; exact h6sp,
    fun c => by rw [hr 12 (by decide) (by decide)]; exact h12 c,
    by rw [hr 13 (by decide) (by decide)]; exact hr13,
    hSegD.congr_mem_fSq
      (hw 5 (by decide) (by decide) _)
      (fun _ _ => hw 8 (by decide) (by decide) _)
      (fun _ _ => hw 9 (by decide) (by decide) _)
      (fun _ _ => hw 10 (by decide) (by decide) _)
      (fun _ _ => hr 8 (by decide) (by decide) _)
      (fun _ _ => rfl),
    T_sp,
    hSegSp.congr_mem_fSq
      (hw 5 (by decide) (by decide) _)
      (fun _ _ => hw 8 (by decide) (by decide) _)
      (fun _ _ => hw 9 (by decide) (by decide) _)
      (fun _ _ => hw 10 (by decide) (by decide) _)
      (fun _ _ => hr 8 (by decide) (by decide) _)
      (fun _ _ => rfl),
    hidle⟩

theorem EncServingChainRelaxed.congr_not_0_26 {d n K D₀ NumSlots : ℕ} {mem m' : ArithRAMMemory}
    {P : DynamicPointSet d} {k : ℕ}
    {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ} {idle : Fin k → Bool}
    (hC : EncServingChainRelaxed d n K D₀ NumSlots mem P k nodes snAge idle)
    (hw : ∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx)
    (hr : ∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx) :
    EncServingChainRelaxed d n K D₀ NumSlots m' P k nodes snAge idle := by
  rcases hC with ⟨hk, hnK, hSlots, hPool, hSegGen, hSaveGen, hw15, hw60, hSeg0,
    leafS, hleaf0, hleaf_lt, hw16, hw6leaf, hSegLeaf, hsn, hdisj0, hdisjPair⟩
  have hLive' : EncLiveCoords d n m' P.activeHandles P.handleCoords := by
    refine ⟨hPool.1.1, fun h hh c => ?_⟩
    rw [hr 4 (by decide) (by decide)]
    exact hPool.1.2 h hh c
  have hPool' : EncHandlePool d n m' P := by
    rcases hPool.2 with ⟨hwm, freeSet, hhwm, hw10, hw11, hw12, hdisj, hunion, hfree1, hfree2, hw2⟩
    refine ⟨hLive', hwm, freeSet, hhwm,
      by rw [hw 1 (by decide) (by decide)]; exact hw10,
      by rw [hw 1 (by decide) (by decide)]; exact hw11,
      by rw [hw 1 (by decide) (by decide)]; exact hw12,
      hdisj, hunion,
      fun i hi => by rw [hw 3 (by decide) (by decide)]; exact hfree1 i hi,
      fun i hi j hj hne => by
        rw [hw 3 (by decide) (by decide), hw 3 (by decide) (by decide)]
        exact hfree2 i hi j hj hne,
      fun h hh => by rw [hw 2 (by decide) (by decide)]; exact hw2 h hh⟩
  have hSegGen' : SegGenBound K NumSlots m' := by
    refine ⟨by rw [hw 1 (by decide) (by decide)]; exact hSegGen.1,
      fun s hs => by
        rw [hw 5 (by decide) (by decide), hw 1 (by decide) (by decide)]
        exact hSegGen.2.1 s hs,
      fun s hs u hu => by
        rw [hw 8 (by decide) (by decide), hw 1 (by decide) (by decide)]
        exact hSegGen.2.2 s hs u hu⟩
  have hSaveGen' : SaveGenBound n NumSlots m' := by
    refine ⟨by rw [hw 1 (by decide) (by decide)]; exact hSaveGen.1,
      fun s hs => by
        rw [hw 6 (by decide) (by decide), hw 1 (by decide) (by decide)]
        exact hSaveGen.2.1 s hs,
      fun s hs h hh => by
        rw [hw 11 (by decide) (by decide), hw 1 (by decide) (by decide)]
        exact hSaveGen.2.2 s hs h hh⟩
  refine ⟨hk, hnK, hSlots, hPool', hSegGen', hSaveGen',
    by rw [hw 1 (by decide) (by decide)]; exact hw15,
    by rw [hw 6 (by decide) (by decide)]; exact hw60,
    hSeg0.congr_mem_fSq
      (hw 5 (by decide) (by decide) _)
      (fun _ _ => hw 8 (by decide) (by decide) _)
      (fun _ _ => hw 9 (by decide) (by decide) _)
      (fun _ _ => hw 10 (by decide) (by decide) _)
      (fun _ _ => hr 8 (by decide) (by decide) _)
      (fun _ _ => rfl),
    leafS, hleaf0, hleaf_lt,
    by rw [hw 1 (by decide) (by decide)]; exact hw16,
    by rw [hw 6 (by decide) (by decide)]; exact hw6leaf,
    hSegLeaf.congr_mem_fSq
      (hw 5 (by decide) (by decide) _)
      (fun _ _ => hw 8 (by decide) (by decide) _)
      (fun _ _ => hw 9 (by decide) (by decide) _)
      (fun _ _ => hw 10 (by decide) (by decide) _)
      (fun _ _ => hr 8 (by decide) (by decide) _)
      (fun _ _ => rfl),
    fun r => (hsn r).congr_not_0_26 hw hr,
    fun r s hs => by rw [snSlotSet_congr_not_0_26 hw r] at hs; exact hdisj0 r s hs,
    fun r₁ r₂ hne => by
      rw [snSlotSet_congr_not_0_26 hw r₁, snSlotSet_congr_not_0_26 hw r₂]
      exact hdisjPair r₁ r₂ hne⟩

lemma EncServingChainRelaxed.answer_hyps {d n K D₀ NumSlots : ℕ} {mem : ArithRAMMemory}
    {P : DynamicPointSet d} {k : ℕ}
    {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ} {idle : Fin k → Bool}
    (hC : EncServingChainRelaxed d n K D₀ NumSlots mem P k nodes snAge idle) :
    k ≤ D₀ ∧
    wRead mem 1 5 = (k : ℤ) ∧
    wRead mem 1 2 = (P.activeHandles.card : ℤ) ∧
    EncLiveCoords d n mem P.activeHandles P.handleCoords ∧
    EncSegSlot K mem 0 P.activeHandles (fun _ => 0) ∧
    ∃ leafS : ℕ,
      wRead mem 1 6 = (leafS : ℤ) ∧
      EncSegSlot K mem leafS (chainTerminal P.handleCoords nodes P.activeHandles) (fun _ => 0) ∧
      (∀ i : Fin k, ∃ dS < NumSlots,
        wRead mem 14 (i.val : ℤ) = (dS : ℤ) ∧
        EncSegSlot K mem dS
          (chainInput P.handleCoords nodes P.activeHandles i.castSucc)
          (fun x => euclideanDistSq (P.handleCoords x) (nodes i).o)) := by
  rcases hC with ⟨hk, _, _, hPool, _, _, hw15, _, hSeg0,
    leafS, _, _, hw16, _, hSegLeaf, hsn, _, _⟩
  rcases hPool with ⟨hLive, _, _, _, _, _, hw12, _, _, _, _, _⟩
  refine ⟨hk, hw15, hw12, hLive, hSeg0, leafS, hw16, hSegLeaf, fun i => ?_⟩
  rcases hsn i with ⟨dS, _, _, hdS_lt, _, _, _, _, h14, _, _, _, _, _, hSegD, _⟩
  exact ⟨dS, hdS_lt, h14, hSegD⟩

/-! ### 2. `CoupledServingStateRelaxed` and `PostRouteContextRelaxed` -/

def CoupledServingStateRelaxed {d n : ℕ} (p : P46Params d n)
    (EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop)
    (P : DynamicPointSet d)
    (st : PureServingState d n p.H p.L p.B_scan P)
    (mem : ArithRAMMemory) : Prop :=
  mem.popDepth 0 = mem ∧
  st.WellFormed ∧
  EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots mem P st.k st.nodes st.snAge
    (fun r => (st.ownedJob r).isNone) ∧
  EncJobs P st mem

structure PostRouteContextRelaxed {d n : ℕ} (p : P46Params d n)
    (EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop)
    (P : DynamicPointSet d) (op : DynamicUpdate d)
    (m_pre : ArithRAMMemory) (st₀ : PureServingState d n p.H p.L p.B_scan P)
    (mem_rt : ArithRAMMemory) (P' : DynamicPointSet d)
    (opH : ℕ) (uMap' : GhostUidMap d P') : Prop where
  hCoupled_pre : CoupledServingStateRelaxed p EncJobs P st₀ m_pre
  hP_wf : P.WellFormed n
  hleg : IsLegalUpdate n Set.univ P op
  hpop_rt : mem_rt.popDepth 0 = mem_rt
  happ : applyDynamicUpdate P op (readStepRetH op mem_rt) = some P'
  hP'_wf : P'.WellFormed n
  hChain_rt :
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    let aff : Fin (st₀.k + 1) → Bool := chainLevelAffected P P' st₀.nodes ins opH
    EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots mem_rt P' st₀.k st₀.nodes
      (fun r => if aff r.castSucc then st₀.snAge r + 1 else st₀.snAge r)
      (fun r => (st₀.ownedJob r).isNone)
  hopH_n : opH < n
  hopH_K : opH < 2 ^ p.K_seg
  hw26_4 : wRead mem_rt 26 4 = (opH : ℤ)
  hw26_5 :
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    wRead mem_rt 26 5 = (if ins then 1 else 0)
  hle_uid : st₀.uMap.nextUid ≤ uMap'.nextUid
  hag_uid : ∀ u < st₀.uMap.nextUid, uMap'.ghostCoords u = st₀.uMap.ghostCoords u
  hchg_root : IsInputChange P.activeHandles P'.activeHandles
  hcoords_root : ∀ h ∈ P.activeHandles, h ∈ P'.activeHandles → P'.handleCoords h = P.handleCoords h
  hcoords_ne : ∀ h ∈ P.activeHandles, h ≠ opH → h ∈ P'.activeHandles ∧ P'.handleCoords h = P.handleCoords h
  hPerNode :
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    let aff : Fin (st₀.k + 1) → Bool := chainLevelAffected P P' st₀.nodes ins opH
    let snAge' : Fin st₀.k → ℕ := fun r => if aff r.castSucc then st₀.snAge r + 1 else st₀.snAge r
    ∀ r : Fin st₀.k,
      let S_pre_h := chainInput P.handleCoords st₀.nodes P.activeHandles r.castSucc
      let S_post_h := chainInput P'.handleCoords st₀.nodes P'.activeHandles r.castSucc
      let S_pre_u := chainInput st₀.uMap.ghostCoords st₀.nodes st₀.uMap.ActiveUids r.castSucc
      let S_post_u := chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc
      wRead mem_rt 20 (r.val : ℤ) = (if aff r.castSucc then 1 else 0) ∧
      (aff r.castSucc = false →
        opH ∉ S_pre_h ∧ opH ∉ S_post_h ∧ S_post_h = S_pre_h ∧ S_post_u = S_pre_u) ∧
      (aff r.castSucc = true →
        IsInputChange S_pre_h S_post_h ∧
        IsInputChange S_pre_u S_post_u ∧
        (ins = true → opH ∉ S_pre_h ∧ S_post_h = insert opH S_pre_h) ∧
        (ins = false → opH ∈ S_pre_h ∧ S_post_h = S_pre_h.erase opH) ∧
        (∃ ev_r : PoolUpdateEvent ℕ,
          ev_r.isClockTick = true ∧
          IsValidPoolUpdateEvent S_pre_u S_post_u ev_r)) ∧
      (∀ (P₀ : Finset ℕ) (trAge : ℕ),
        trAge ≤ st₀.snAge r →
        HasNodeAge P₀ S_pre_u trAge →
        ∃ trAge' ≤ snAge' r, HasNodeAge P₀ S_post_u trAge')
  hSnap : ∀ s < p.NumSlots, 1 ≤ wRead m_pre 6 (s : ℤ) → ∀ S snapPts,
    EncSlotCoords d n m_pre P.activeHandles P.handleCoords s S snapPts →
    EncSlotCoords d n mem_rt P'.activeHandles P'.handleCoords s S snapPts
  hOtherSeg : ∀ s' < p.NumSlots,
    s' ≠ 0 → s' ≠ (wRead m_pre 1 6).toNat → (∀ r : Fin st₀.k, s' ∉ snSlotSet m_pre r.val) →
    ∀ S₁ fSq₁, EncSegSlot p.K_seg m_pre s' S₁ fSq₁ → EncSegSlot p.K_seg mem_rt s' S₁ fSq₁
  hw_other : ∀ tbl, tbl ≠ 0 → tbl ≠ 1 → tbl ≠ 2 → tbl ≠ 3 → tbl ≠ 8 → tbl ≠ 9 → tbl ≠ 10 →
        tbl ≠ 11 → tbl ≠ 13 → tbl ≠ 20 → tbl ≠ 26 →
    ∀ idx, wRead mem_rt tbl idx = wRead m_pre tbl idx
  hw0_other : ∀ idx, idx ≠ 0 → wRead mem_rt 0 idx = wRead m_pre 0 idx
  hw1_other : ∀ idx, idx ≠ 0 → idx ≠ 1 → idx ≠ 2 → wRead mem_rt 1 idx = wRead m_pre 1 idx
  hw13_other : ∀ idx, (idx < 0 ∨ (st₀.k : ℤ) ≤ idx) → wRead mem_rt 13 idx = wRead m_pre 13 idx
  hr_other : ∀ tbl, tbl ≠ 4 → tbl ≠ 8 → tbl ≠ 11 → tbl ≠ 26 →
    ∀ idx, rRead mem_rt tbl idx = rRead m_pre tbl idx

lemma PostRouteContextRelaxed.exists_trueAge_post
    {d n : ℕ} {p : P46Params d n}
    {EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop}
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    (ctx : PostRouteContextRelaxed p EncJobs P op m_pre st₀ mem_rt P' opH uMap') :
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    let aff : Fin (st₀.k + 1) → Bool := chainLevelAffected P P' st₀.nodes ins opH
    let snAge' : Fin st₀.k → ℕ := fun r => if aff r.castSucc then st₀.snAge r + 1 else st₀.snAge r
    ∃ trueAge' : Fin st₀.k → ℕ,
      (∀ r : Fin st₀.k, trueAge' r ≤ snAge' r) ∧
      (∀ r : Fin st₀.k,
        HasNodeAge (st₀.birthSnap r)
          (chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc) (trueAge' r)) := by
  classical
  intro ins aff snAge'
  have hex : ∀ r : Fin st₀.k,
      ∃ trAge' ≤ snAge' r,
        HasNodeAge (st₀.birthSnap r)
          (chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc) trAge' := by
    intro r
    rcases ctx.hCoupled_pre.2.1.1 r with ⟨_, _, _, htr_le, hage_pre, _⟩
    have hp := (ctx.hPerNode r).2.2.2 (st₀.birthSnap r) (st₀.trueAge r) htr_le hage_pre
    cases op <;> exact hp
  choose trueAge' htr_le' hhas_age' using hex
  exact ⟨trueAge', htr_le', hhas_age'⟩

/-! ### 3. `FullPostRouteSpecRelaxed` and `MiddleTickSplitSpecRelaxed` -/

structure FullPostRouteSpecRelaxed (cHpj cBase d n t : ℕ) (δ : ℝ) (p : P46Params d n) where
  EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop
  postRouteStmt : ArithRAMStmt
  T_max : ℕ
  M_box : ℕ
  B_post : ℕ
  C_post : ℕ
  p_post : ℝ
  hT27 : 27 ≤ T_max
  hBox_ge : p46BoxSize d n p ≤ M_box
  hBoxSafe : BoxSafeOuter T_max M_box postRouteStmt
  hp_budget : p_post ≤ perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ
  hEncJobs_empty : ∀ m : ArithRAMMemory,
    m.popDepth 0 = m →
    EncServingChain d n p.K_seg p.D₀ p.NumSlots m (DynamicPointSet.empty d) 0 Fin.elim0 Fin.elim0 →
    (∀ tbl, tbl ≠ 1 → tbl ≠ 5 → ∀ idx, wRead m tbl idx = 0) →
    (∀ tbl idx, rRead m tbl idx = 0) →
    EncJobs (DynamicPointSet.empty d) (PureServingState.empty d n p.H p.L p.B_scan) m
  hExecPostRoute :
    ∀ {P : DynamicPointSet d} {op : DynamicUpdate d}
      {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
      {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
      {opH : ℕ} {uMap' : GhostUidMap d P'}
      {P_good₀ : Prop},
      (P_good₀ → st₀.AllCentersGood) →
      PostRouteContextRelaxed p EncJobs P op m_pre st₀ mem_rt P' opH uMap' →
      RandExecBad (mkStepInput n P op) postRouteStmt B_post mem_rt
        (fun m_out =>
          wRead m_out 0 0 = wRead mem_rt 0 0 ∧
          ∃ st₁, CoupledServingStateRelaxed p EncJobs P' st₁ m_out)
        (fun m_out =>
          P_good₀ →
            IsValidFactorCAnswer (Real.sqrt 2) P' (readStoredAns m_out) ∧
            ∃ st₁, CoupledServingStateRelaxed p EncJobs P' st₁ m_out ∧ st₁.AllCentersGood)
        p_post C_post

def FullPostRouteSpecRelaxed.to_stepSimSpec
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (spec : FullPostRouteSpecRelaxed cHpj cBase d n t δ p) :
    StepSimSpec d n t δ := by
  let SafeInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop := fun k P mem =>
    (k = 0 ∧ P = DynamicPointSet.empty d ∧ mem = ArithRAMMemory.empty) ∨
    ∃ st, CoupledServingStateRelaxed p spec.EncJobs P st mem
  let GoodInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop := fun k P mem =>
    (k = 0 ∧ P = DynamicPointSet.empty d ∧ mem = ArithRAMMemory.empty) ∨
    ∃ st, CoupledServingStateRelaxed p spec.EncJobs P st mem ∧ st.AllCentersGood
  have hBounds := hp.routeBoxBounds hn spec.hBox_ge
  have hRouteBox := hBounds.1
  have h2Slots := hBounds.2.2.1
  have hSlotsBox := hBounds.2.2.2.1
  refine
    { updateStmt0 := .seq (stepBootAndRouteStmt d n spec.M_box p) spec.postRouteStmt
      B_step := spec.B_post
      uBound := stepBootAndRouteCost d p + spec.C_post
      T_max := spec.T_max
      M_box := spec.M_box
      φ_step := spec.p_post
      SafeInv := SafeInv
      GoodInv := GoodInv
      hBoxSafe := .seq (boxSafe_stepBootAndRouteStmt spec.hT27 p) spec.hBoxSafe
      hφ_le := spec.hp_budget
      hSafe₀ := Or.inl ⟨rfl, rfl, rfl⟩
      hGood₀ := Or.inl ⟨rfl, rfl, rfl⟩
      hStep := ?_ }
  intro k P mem₀ op _ hP hpop₀ _ hSafe hleg
  classical
  let inp := mkStepInput n P op
  let P_good₀ : Prop := GoodInv k P mem₀
  have hBoot : ∃ (m_pre : ArithRAMMemory) (st₀ : PureServingState d n p.H p.L p.B_scan P),
      DetExecAt 0 inp (ensureServingChainInitStmt spec.M_box) mem₀ m_pre 250 ∧
      CoupledServingStateRelaxed p spec.EncJobs P st₀ m_pre ∧
      (P_good₀ → st₀.AllCentersGood) := by
    by_cases hG_ex : ∃ st, CoupledServingStateRelaxed p spec.EncJobs P st mem₀ ∧ st.AllCentersGood
    · rcases hG_ex with ⟨st₀, hC₀, hGood_st₀⟩
      have hex_pres := (exec_ensureServingChainInitStmt_pres_relaxed (M_box := spec.M_box)
        inp mem₀ hC₀.2.2.1).mono_cost (by omega : 20 ≤ 250)
      exact ⟨mem₀, st₀, hex_pres, hC₀, fun _ => hGood_st₀⟩
    · by_cases hInit0 : k = 0 ∧ P = DynamicPointSet.empty d ∧ mem₀ = ArithRAMMemory.empty
      · rcases hInit0 with ⟨_, rfl, rfl⟩
        rcases exec_ensureServingChainInitStmt_empty (K := p.K_seg) (D₀ := p.D₀)
          (NumSlots := p.NumSlots) (M_box := spec.M_box) inp
          hp.hn_le_2K h2Slots (by have := hRouteBox.1; omega) hSlotsBox
          with ⟨m_pre, hex_emp, hpop_pre, hChain_emp, hw_emp, hr_emp⟩
        let st_emp := PureServingState.empty d n p.H p.L p.B_scan
        have hJobs_emp : spec.EncJobs (DynamicPointSet.empty d) st_emp m_pre :=
          spec.hEncJobs_empty m_pre hpop_pre hChain_emp hw_emp hr_emp
        refine ⟨m_pre, st_emp, hex_emp,
          ⟨hpop_pre, PureServingState.empty_wellFormed d n p.H p.L p.B_scan,
           hChain_emp.toRelaxed (fun r => (st_emp.ownedJob r).isNone), hJobs_emp⟩,
          fun _ => PureServingState.empty_allCentersGood d n p.H p.L p.B_scan⟩
      · have hExSafe : ∃ st, CoupledServingStateRelaxed p spec.EncJobs P st mem₀ :=
          Or.resolve_left hSafe hInit0
        rcases hExSafe with ⟨st₀, hC₀⟩
        have hex_pres := (exec_ensureServingChainInitStmt_pres_relaxed (M_box := spec.M_box)
          inp mem₀ hC₀.2.2.1).mono_cost (by omega : 20 ≤ 250)
        refine ⟨mem₀, st₀, hex_pres, hC₀, ?_⟩
        intro hg
        exact False.elim (hg.elim hInit0 hG_ex)
  rcases hBoot with ⟨m_pre, st₀, hex_init, hC₀, hGood₀_imp⟩
  rcases exec_routeLiveUpdate_with_uid_relaxed (M_box := spec.M_box)
      P op m_pre st₀.uMap hP hleg hRouteBox hC₀.2.2.1
    with ⟨mem_rt, P', opH, uMap', hex_rt, hpop_rt, happ, hP'_wf, hChain_rt, hopH_n, hopH_K,
          hw26_4, hw26_5, hle_uid, hag_uid, hchg_root, hcoords_root, hcoords_ne,
          hPerNode, hSnap, hOtherSeg, hw_other, hw0_other, hw1_other, hw13_other, hr_other⟩
  have hex_prefix : DetExecAt 0 inp (stepBootAndRouteStmt d n spec.M_box p) mem₀ mem_rt
      (stepBootAndRouteCost d p) :=
    hex_init.seq hex_rt
  have ctx : PostRouteContextRelaxed p spec.EncJobs P op m_pre st₀ mem_rt P' opH uMap' :=
    { hCoupled_pre := hC₀
      hP_wf := hP
      hleg := hleg
      hpop_rt := hpop_rt
      happ := happ
      hP'_wf := hP'_wf
      hChain_rt := by cases op <;> exact hChain_rt
      hopH_n := hopH_n
      hopH_K := hopH_K
      hw26_4 := hw26_4
      hw26_5 := by cases op <;> exact hw26_5
      hle_uid := hle_uid
      hag_uid := hag_uid
      hchg_root := hchg_root
      hcoords_root := hcoords_root
      hcoords_ne := hcoords_ne
      hPerNode := by cases op <;> exact hPerNode
      hSnap := hSnap
      hOtherSeg := hOtherSeg
      hw_other := hw_other
      hw0_other := hw0_other
      hw1_other := hw1_other
      hw13_other := hw13_other
      hr_other := hr_other }
  have hBad_post := spec.hExecPostRoute hGood₀_imp ctx
  have hBad_full := RandExecBad.seq_det_left hpop₀ hpop_rt hex_prefix hBad_post
  rcases hBad_full with ⟨_, Post, Bad, hDec, hR, hcard, hpost⟩
  refine ⟨Post, Bad, hDec, hR, hcard, ?_⟩
  intro bits m₁ hm₁
  rcases hpost bits m₁ hm₁ with ⟨hpop₁, ⟨hw00, hExSafe'⟩, hg₁⟩
  dsimp only
  rw [hpop₁]
  refine ⟨P', ?_, Or.inr hExSafe', ?_⟩
  · rw [readStepRetH_congr op hw00]
    exact happ
  · intro hG₀ hnb
    rcases hg₁ hnb hG₀ with ⟨hAns, hExGood'⟩
    exact ⟨hAns, Or.inr hExGood'⟩

structure MiddleTickSplitSpecRelaxed (cHpj cBase d n t : ℕ) (δ : ℝ) (p : P46Params d n) where
  EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop
  midStmt : ArithRAMStmt
  T_max : ℕ
  M_box : ℕ
  B_mid : ℕ
  C_mid : ℕ
  p_mid : ℝ
  hT27 : 27 ≤ T_max
  hBox_ge : p46BoxSize d n p ≤ M_box
  hBoxSafe : BoxSafeOuter T_max M_box midStmt
  hp_budget : p_mid + (p.D₀ : ℝ) * (2 * p.φ_ev) ≤
    perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ
  hEncJobs_empty : ∀ m : ArithRAMMemory,
    m.popDepth 0 = m →
    EncServingChain d n p.K_seg p.D₀ p.NumSlots m (DynamicPointSet.empty d) 0 Fin.elim0 Fin.elim0 →
    (∀ tbl, tbl ≠ 1 → tbl ≠ 5 → ∀ idx, wRead m tbl idx = 0) →
    (∀ tbl idx, rRead m tbl idx = 0) →
    EncJobs (DynamicPointSet.empty d) (PureServingState.empty d n p.H p.L p.B_scan) m
  hEncJobs_congr_not_0_26 : ∀ {P : DynamicPointSet d}
    {st : PureServingState d n p.H p.L p.B_scan P} {m m' : ArithRAMMemory},
    (∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, wRead m' tbl idx = wRead m tbl idx) →
    (∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, rRead m' tbl idx = rRead m tbl idx) →
    EncJobs P st m → EncJobs P st m'
  hExecMid :
    ∀ {P : DynamicPointSet d} {op : DynamicUpdate d}
      {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
      {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
      {opH : ℕ} {uMap' : GhostUidMap d P'}
      {P_good₀ : Prop},
      (P_good₀ → st₀.AllCentersGood) →
      PostRouteContextRelaxed p EncJobs P op m_pre st₀ mem_rt P' opH uMap' →
      RandExecBad (mkStepInput n P op) midStmt B_mid mem_rt
        (fun m_mid =>
          wRead m_mid 0 0 = wRead mem_rt 0 0 ∧
          ∃ st₁, CoupledServingStateRelaxed p EncJobs P' st₁ m_mid)
        (fun m_mid =>
          P_good₀ →
            ∃ st₁, CoupledServingStateRelaxed p EncJobs P' st₁ m_mid ∧ st₁.AllCentersGood)
        p_mid C_mid

def MiddleTickSplitSpecRelaxed.to_fullPostRouteSpecRelaxed
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (mid : MiddleTickSplitSpecRelaxed cHpj cBase d n t δ p)
    (ans : AnswerStageSpec d n mid.T_max mid.M_box p) :
    FullPostRouteSpecRelaxed cHpj cBase d n t δ p := by
  have hBox16 : 16 ≤ mid.M_box := (hp.routeBoxBounds hn mid.hBox_ge).2.1
  refine
    { EncJobs := mid.EncJobs
      postRouteStmt := .seq mid.midStmt ans.ansStmt
      T_max := mid.T_max
      M_box := mid.M_box
      B_post := mid.B_mid + p.D₀ * p.K₀ * p.M_bits
      C_post := mid.C_mid + p46AnsStageCost d n (3 * p.L + 2) p
      p_post := mid.p_mid + (p.D₀ : ℝ) * (2 * p.φ_ev)
      hT27 := mid.hT27
      hBox_ge := mid.hBox_ge
      hBoxSafe := .seq mid.hBoxSafe ans.hBoxSafe
      hp_budget := mid.hp_budget
      hEncJobs_empty := mid.hEncJobs_empty
      hExecPostRoute := ?_ }
  intro P op m_pre st₀ mem_rt P' opH uMap' P_good₀ hGood₀ ctx
  classical
  let inp := mkStepInput n P op
  refine RandExecBad.seq ctx.hpop_rt (mid.hExecMid hGood₀ ctx) ?_
  intro m_mid hpop_mid hSafe_mid
  rcases hSafe_mid with ⟨hw00_mid, hExSafe_mid⟩
  by_cases hExGood_mid : ∃ st₁, CoupledServingStateRelaxed p mid.EncJobs P' st₁ m_mid ∧ st₁.AllCentersGood
  · rcases hExGood_mid with ⟨st₁, hC₁, hGood_st₁⟩
    rcases hC₁.2.2.1.answer_hyps with ⟨hk_le, hw_cL, hw_card, hLive, hSeg0, leafS, hw_leaf, hSegLeaf, hsn_dict⟩
    rcases st₁.answer_hyps hp hC₁.2.1 with ⟨hleaf_le, hbij_H, hbij_U, hmc_gen, hGoodChain⟩
    have hAns := (ans.hExecAns (P_good := True) inp m_mid st₁.nodes hpop_mid ctx.hP'_wf
      hk_le hw_cL hw_card hw_leaf hleaf_le hBox16 hLive hSeg0 hSegLeaf hsn_dict
      hbij_H hbij_U hp.hK0_ge1 hp.hφ0 hp.hbias_base hmc_gen (fun _ => hGoodChain hGood_st₁)).with_popDepth
    refine hAns.mono ?_ ?_ le_rfl le_rfl
    · intro m_out ⟨hpop_out, hw00_ans, hw_ans, hr_ans⟩
      have hChain_out := hC₁.2.2.1.congr_not_0_26 hw_ans hr_ans
      have hJobs_out := mid.hEncJobs_congr_not_0_26 hw_ans hr_ans hC₁.2.2.2
      exact ⟨hw00_ans.trans hw00_mid, st₁, ⟨hpop_out, hC₁.2.1, hChain_out, hJobs_out⟩⟩
    · intro m_out ⟨hpop_out, _, hw_ans, hr_ans⟩ hAnsValid _ _
      have hChain_out := hC₁.2.2.1.congr_not_0_26 hw_ans hr_ans
      have hJobs_out := mid.hEncJobs_congr_not_0_26 hw_ans hr_ans hC₁.2.2.2
      exact ⟨hAnsValid trivial, st₁, ⟨hpop_out, hC₁.2.1, hChain_out, hJobs_out⟩, hGood_st₁⟩
  · rcases hExSafe_mid with ⟨st₁, hC₁⟩
    rcases hC₁.2.2.1.answer_hyps with ⟨hk_le, hw_cL, hw_card, hLive, hSeg0, leafS, hw_leaf, hSegLeaf, hsn_dict⟩
    rcases st₁.answer_hyps hp hC₁.2.1 with ⟨hleaf_le, hbij_H, hbij_U, hmc_gen, _⟩
    have hAns := (ans.hExecAns (P_good := False) inp m_mid st₁.nodes hpop_mid ctx.hP'_wf
      hk_le hw_cL hw_card hw_leaf hleaf_le hBox16 hLive hSeg0 hSegLeaf hsn_dict
      hbij_H hbij_U hp.hK0_ge1 hp.hφ0 hp.hbias_base hmc_gen (fun hf => False.elim hf)).with_popDepth
    refine hAns.mono ?_ ?_ le_rfl le_rfl
    · intro m_out ⟨hpop_out, hw00_ans, hw_ans, hr_ans⟩
      have hChain_out := hC₁.2.2.1.congr_not_0_26 hw_ans hr_ans
      have hJobs_out := mid.hEncJobs_congr_not_0_26 hw_ans hr_ans hC₁.2.2.2
      exact ⟨hw00_ans.trans hw00_mid, st₁, ⟨hpop_out, hC₁.2.1, hChain_out, hJobs_out⟩⟩
    · intro _ _ _ hImp hPG₀
      exact False.elim (hExGood_mid (hImp hPG₀))

def MiddleTickSplitSpecRelaxed.to_stepSimSpec
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (mid : MiddleTickSplitSpecRelaxed cHpj cBase d n t δ p)
    (ans : AnswerStageSpec d n mid.T_max mid.M_box p) :
    StepSimSpec d n t δ :=
  (mid.to_fullPostRouteSpecRelaxed hp hn ans).to_stepSimSpec hp hn

/-! ### 4. Top-Level Horizon & Polynomial Endpoint Bridges for `MiddleTickSplitSpecRelaxed` -/

theorem prove_S_lem_7_2_of_fullPostRouteSpecRelaxed
    (h_fb : S_clm_7_3_failure_budget)
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    (C_cap C_post_poly C_box_poly : ℕ)
    (hBuild : ∀ (d n t : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        C_cap * (D ^ 4 * H ^ 2) < n →
        ∀ (p : P46Params d n),
          P46ParamsValid cHpj (extractCBaseNat h_mc) d n t δ p →
          ∃ spec : FullPostRouteSpecRelaxed cHpj (extractCBaseNat h_mc) d n t δ p,
            spec.C_post ≤ C_post_poly * (D ^ 19 * H ^ 18) ∧
            spec.T_max * spec.M_box ≤ C_box_poly * n * (D ^ 19 * H ^ 18)) :
    S_lem_7_2 := by
  let Cu_main := 1050250 + C_post_poly
  refine prove_S_lem_7_2_of_conditional_stepSimSpec h_fb C_cap Cu_main C_box_poly ?_
  intro d n t hd1 hn ht δ hδ0 hδ1 D H hcap
  let cBase : ℕ := extractCBaseNat h_mc
  rcases exists_valid_p46Params h_mc hcHpj (rfl : cBase = extractCBaseNat h_mc) hn ht hδ0 hδ1
    with ⟨p, hp⟩
  rcases hBuild d n t hd1 hn ht δ hδ0 hδ1 hcap p hp with ⟨spec, hCpost, hBox⟩
  have hPref : stepBootAndRouteCost d p ≤ 1050250 * (D ^ 19 * H ^ 18) :=
    hp.stepBootAndRouteCost_poly_le hn
  refine ⟨spec.to_stepSimSpec hp hn, ?_, hBox⟩
  change stepBootAndRouteCost d p + spec.C_post ≤ (1050250 + C_post_poly) * (D ^ 19 * H ^ 18)
  calc stepBootAndRouteCost d p + spec.C_post
      ≤ 1050250 * (D ^ 19 * H ^ 18) + C_post_poly * (D ^ 19 * H ^ 18) := Nat.add_le_add hPref hCpost
    _ = (1050250 + C_post_poly) * (D ^ 19 * H ^ 18) := by ring

theorem prove_S_lem_7_2_of_middleTickSplitSpecRelaxed
    (h_fb : S_clm_7_3_failure_budget)
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    (C_cap C_mid_poly C_box_poly : ℕ)
    (hBuild : ∀ (d n t : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        C_cap * (D ^ 4 * H ^ 2) < n →
        ∀ (p : P46Params d n),
          P46ParamsValid cHpj (extractCBaseNat h_mc) d n t δ p →
          ∃ (mid : MiddleTickSplitSpecRelaxed cHpj (extractCBaseNat h_mc) d n t δ p)
            (_ans : AnswerStageSpec d n mid.T_max mid.M_box p),
            mid.C_mid ≤ C_mid_poly * (D ^ 19 * H ^ 18) ∧
            mid.T_max * mid.M_box ≤ C_box_poly * n * (D ^ 19 * H ^ 18)) :
    S_lem_7_2 := by
  let cBase : ℕ := extractCBaseNat h_mc
  let C_ans_poly := p46AnsPolyConst cHpj cBase
  refine prove_S_lem_7_2_of_fullPostRouteSpecRelaxed h_fb h_mc hcHpj C_cap (C_mid_poly + C_ans_poly) C_box_poly ?_
  intro d n t hd1 hn ht δ hδ0 hδ1 D H hcap p hp
  rcases hBuild d n t hd1 hn ht δ hδ0 hδ1 hcap p hp with ⟨mid, ans, hCmid, hBox⟩
  have hCans : p46AnsStageCost d n (3 * p.L + 2) p ≤ C_ans_poly * (D ^ 19 * H ^ 18) :=
    hp.ansStageCost_poly_le hn
  refine ⟨mid.to_fullPostRouteSpecRelaxed hp hn ans, ?_, hBox⟩
  change mid.C_mid + p46AnsStageCost d n (3 * p.L + 2) p ≤ (C_mid_poly + C_ans_poly) * (D ^ 19 * H ^ 18)
  calc mid.C_mid + p46AnsStageCost d n (3 * p.L + 2) p
      ≤ C_mid_poly * (D ^ 19 * H ^ 18) + C_ans_poly * (D ^ 19 * H ^ 18) := Nat.add_le_add hCmid hCans
    _ = (C_mid_poly + C_ans_poly) * (D ^ 19 * H ^ 18) := by ring

theorem prove_S_lem_7_2_of_only_middleTickSplitRelaxed
    (h_lem_5_2 : S_lem_5_2)
    (h_fb : S_clm_7_3_failure_budget)
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    (C_cap C_mid_poly C_box_poly : ℕ)
    (hBuild : ∀ (d n t : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        C_cap * (D ^ 4 * H ^ 2) < n →
        ∀ (p : P46Params d n),
          P46ParamsValid cHpj (extractCBaseNat h_mc) d n t δ p →
          ∃ mid : MiddleTickSplitSpecRelaxed cHpj (extractCBaseNat h_mc) d n t δ p,
            mid.C_mid ≤ C_mid_poly * (D ^ 19 * H ^ 18) ∧
            mid.T_max * mid.M_box ≤ C_box_poly * n * (D ^ 19 * H ^ 18)) :
    S_lem_7_2 := by
  refine prove_S_lem_7_2_of_middleTickSplitSpecRelaxed h_fb h_mc hcHpj C_cap C_mid_poly C_box_poly ?_
  intro d n t hd1 hn ht δ hδ0 hδ1 D H hcap p hp
  rcases hBuild d n t hd1 hn ht δ hδ0 hδ1 hcap p hp with ⟨mid, hCmid, hBox⟩
  exact ⟨mid, buildAnswerStageSpec h_lem_5_2 mid.hT27 p, hCmid, hBox⟩

end UL.Proof_lem_7_2_RacerP46
