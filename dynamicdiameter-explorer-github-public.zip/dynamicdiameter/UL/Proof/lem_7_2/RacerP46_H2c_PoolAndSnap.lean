import UL.Proof.lem_7_2.RacerP46_H1_ParamsAndPure
import UL.Proof.lem_7_2.RacerP46_H2b_SegAndPool

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33

/-! ### 1. Exact Euclidean Squared Distance in Local `29` (`distSqLocalStmt`) -/

theorem euclideanDistSq_eq_sum_fin {d : ℕ} (x y : EuclideanSpace ℝ (Fin d)) :
    euclideanDistSq x y = ∑ i : Fin d, (euclideanCoord x i - euclideanCoord y i) ^ 2 := by
  unfold euclideanDistSq
  rw [PiLp.norm_sq_eq_of_L2]
  refine Finset.sum_congr rfl fun i _ => ?_
  rw [Real.norm_eq_abs, sq_abs]
  rfl

theorem sum_fin_eq_sum_range {d : ℕ} (f : ℕ → ℝ) :
    (∑ i : Fin d, f i.val) = ∑ c ∈ Finset.range d, f c := by
  refine Finset.sum_bij (fun (i : Fin d) _ => i.val) ?_ ?_ ?_ (fun _ _ => rfl)
  · intro i _; exact Finset.mem_range.mpr i.isLt
  · intro i₁ _ i₂ _ heq; exact Fin.ext heq
  · intro c hc; exact ⟨⟨c, Finset.mem_range.mp hc⟩, Finset.mem_univ _, rfl⟩

/-- Compute `∑_{c < d} (r29[c] - r29[d + c])^2` into `r29[2 * d]` using `29[0]` as loop index. -/
def distSqLocalStmt (d : ℕ) : ArithRAMStmt :=
  let d_lit : IntExpr := .lit (d : ℤ)
  let accIdx : IntExpr := .lit ((2 * d : ℕ) : ℤ)
  seqList [
    .writeRealLocal 29 accIdx (.ofInt (.lit 0)),
    .writeWordLocal 29 (.lit 0) (.lit 0),
    .repeatN d_lit (seqList [
      .writeRealLocal 29 (.lit ((2 * d + 1 : ℕ) : ℤ))
        (.sub (.readRealLocal 29 (.readLocal 29 (.lit 0)))
              (.readRealLocal 29 (.add d_lit (.readLocal 29 (.lit 0))))),
      .writeRealLocal 29 accIdx
        (.add (.readRealLocal 29 accIdx)
              (.mul (.readRealLocal 29 (.lit ((2 * d + 1 : ℕ) : ℤ)))
                    (.readRealLocal 29 (.lit ((2 * d + 1 : ℕ) : ℤ))))),
      .writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))
    ])
  ]

theorem boxSafe_distSqLocalStmt {T_max M_box : ℕ} (d : ℕ) :
    BoxSafeInner T_max M_box (distSqLocalStmt d) := by
  unfold distSqLocalStmt
  apply boxSafeInner_seqList
  intro st hst
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl
  · exact .writeRealLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .repeatN _ (boxSafeInner_seqList ?_)
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl
    · exact .writeRealLocal _ _ _
    · exact .writeRealLocal _ _ _
    · exact .writeWordLocal _ _ _

theorem exec_distSqLocalStmt {d : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {x y : EuclideanSpace ℝ (Fin d)}
    (hx : ∀ c : Fin d, rReadL 1 mem 29 (c.val : ℤ) = euclideanCoord x c)
    (hy : ∀ c : Fin d, rReadL 1 mem 29 ((d + c.val : ℕ) : ℤ) = euclideanCoord y c) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (distSqLocalStmt d) mem mem' (40 * (d + 1)) ∧
      rReadL 1 mem' 29 ((2 * d : ℕ) : ℤ) = euclideanDistSq x y ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ idx, idx ≠ 0 → wReadL 1 mem' 29 idx = wReadL 1 mem 29 idx) ∧
      (∀ idx, idx < ((2 * d : ℕ) : ℤ) → rReadL 1 mem' 29 idx = rReadL 1 mem 29 idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  let accIdx : ℤ := ((2 * d : ℕ) : ℤ)
  let tmpIdx : ℤ := ((2 * d + 1 : ℕ) : ℤ)
  let m1 := rWriteL 1 mem 29 accIdx 0
  let m2 := wWriteL 1 m1 29 0 0
  have hs1 : DetExecAt 1 inp (.writeRealLocal 29 (.lit accIdx) (.ofInt (.lit 0))) mem m1 5 :=
    DetExecAt.writeRealLocal 1 inp mem 29 _ _ rfl (by simp) (by simp [intExprOps, realExprOps])
  have hs2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 0) (.lit 0)) m1 m2 4 :=
    DetExecAt.writeWordLocal 1 inp m1 29 _ _ rfl rfl (by simp [intExprOps])
  let termFn : ℕ → ℝ := fun c =>
    if hc : c < d then (euclideanCoord x ⟨c, hc⟩ - euclideanCoord y ⟨c, hc⟩) ^ 2 else 0
  let Inv : ℕ → ArithRAMMemory → Prop := fun c m =>
    (∀ t idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t idx, rRead m t idx = rRead mem t idx) ∧
    wReadL 1 m 29 0 = (c : ℤ) ∧
    (∀ idx, idx ≠ 0 → wReadL 1 m 29 idx = wReadL 1 mem 29 idx) ∧
    (∀ idx, idx < accIdx → rReadL 1 m 29 idx = rReadL 1 mem 29 idx) ∧
    rReadL 1 m 29 accIdx = (∑ k ∈ Finset.range c, termFn k) ∧
    (∀ v, v ≠ 29 → ∀ idx, wReadL 1 m v idx = wReadL 1 mem v idx) ∧
    (∀ v, v ≠ 29 → ∀ idx, rReadL 1 m v idx = rReadL 1 mem v idx)
  have hInv0 : Inv 0 m2 := by
    refine ⟨fun _ _ => by simp [m2, m1, wRead_rWriteL],
      fun _ _ => by simp [m2, m1, rRead_rWriteL],
      by simp [m2],
      fun idx hi => by simp [m2, m1, wReadL_rWriteL, hi],
      fun idx hi => by
        have hne : idx ≠ accIdx := by omega
        simp [m2, m1, rReadL_wWriteL, hne],
      by simp [m2, m1],
      fun v hv idx => by simp [m2, m1, wReadL_rWriteL, hv],
      fun v hv idx => by simp [m2, m1, hv]⟩
  have hStep : ∀ c < d, ∀ m, Inv c m →
      ∃ m', DetExecAt 1 inp
        (seqList [
          .writeRealLocal 29 (.lit tmpIdx)
            (.sub (.readRealLocal 29 (.readLocal 29 (.lit 0)))
                  (.readRealLocal 29 (.add (.lit (d : ℤ)) (.readLocal 29 (.lit 0))))),
          .writeRealLocal 29 (.lit accIdx)
            (.add (.readRealLocal 29 (.lit accIdx))
                  (.mul (.readRealLocal 29 (.lit tmpIdx)) (.readRealLocal 29 (.lit tmpIdx)))),
          .writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))
        ]) m m' 35 ∧ Inv (c + 1) m' := by
    intro c hc m ⟨hw_m, hr_m, hm0, hwl_m, hrl_lt, hacc_m, hlv_m, hrlv_m⟩
    let diff : ℝ := euclideanCoord x ⟨c, hc⟩ - euclideanCoord y ⟨c, hc⟩
    let ms1 := rWriteL 1 m 29 tmpIdx diff
    let ms2 := rWriteL 1 ms1 29 accIdx ((∑ k ∈ Finset.range c, termFn k) + diff * diff)
    let ms3 := wWriteL 1 ms2 29 0 ((c + 1 : ℕ) : ℤ)
    have hxc : rReadL 1 m 29 (c : ℤ) = euclideanCoord x ⟨c, hc⟩ := by
      rw [hrl_lt (c : ℤ) (by dsimp [accIdx]; omega)]; exact hx ⟨c, hc⟩
    have hyc : rReadL 1 m 29 ((d : ℤ) + (c : ℤ)) = euclideanCoord y ⟨c, hc⟩ := by
      have heq_dc : (d : ℤ) + (c : ℤ) = ((d + c : ℕ) : ℤ) := by push_cast; rfl
      rw [heq_dc, hrl_lt ((d + c : ℕ) : ℤ) (by dsimp [accIdx]; omega)]
      exact hy ⟨c, hc⟩
    have hb1 : DetExecAt 1 inp
        (.writeRealLocal 29 (.lit tmpIdx)
          (.sub (.readRealLocal 29 (.readLocal 29 (.lit 0)))
                (.readRealLocal 29 (.add (.lit (d : ℤ)) (.readLocal 29 (.lit 0)))))) m ms1 12 := by
      refine DetExecAt.writeRealLocal 1 inp m 29 _ _ rfl ?_ (by simp [intExprOps, realExprOps])
      simp only [rValAt_sub, rValAt_readRealLocal, iValAt_readLocal, iValAt_add, iValAt_lit, hm0, hxc, hyc]
      rfl
    have htmp_ne_acc : accIdx ≠ tmpIdx := by dsimp [accIdx, tmpIdx]; omega
    have hb2 : DetExecAt 1 inp
        (.writeRealLocal 29 (.lit accIdx)
          (.add (.readRealLocal 29 (.lit accIdx))
                (.mul (.readRealLocal 29 (.lit tmpIdx)) (.readRealLocal 29 (.lit tmpIdx))))) ms1 ms2 12 := by
      refine DetExecAt.writeRealLocal 1 inp ms1 29 _ _ rfl ?_ (by simp [intExprOps, realExprOps])
      simp only [rValAt_add, rValAt_mul, rValAt_readRealLocal, iValAt_lit, ms1, rReadL_rWriteL_eq,
        htmp_ne_acc, hacc_m]
      simp
    have hb3 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 0) (.add (.readLocal 29 (.lit 0)) (.lit 1))) ms2 ms3 8 := by
      refine DetExecAt.writeWordLocal 1 inp ms2 29 _ _ rfl ?_ (by simp [intExprOps])
      simp [ms2, ms1, wReadL_rWriteL, hm0]
    refine ⟨ms3, (hb1.seq (hb2.seq hb3)).mono_cost (by omega),
      fun t idx => by simp [ms3, ms2, ms1, wRead_rWriteL, hw_m],
      fun t idx => by simp [ms3, ms2, ms1, rRead_rWriteL, hr_m],
      by simp [ms3],
      fun idx hi => by simp [ms3, ms2, ms1, wReadL_rWriteL, hi, hwl_m idx hi],
      fun idx hi => by
        have h1 : idx ≠ accIdx := by omega
        have h2 : idx ≠ tmpIdx := by dsimp [accIdx, tmpIdx] at hi ⊢; omega
        simp [ms3, ms2, ms1, h1, h2, hrl_lt idx hi],
      ?_,
      fun v hv idx => by simp [ms3, ms2, ms1, wReadL_rWriteL, hv, hlv_m v hv],
      fun v hv idx => by simp [ms3, ms2, ms1, hv, hrlv_m v hv]⟩
    rw [Finset.sum_range_succ]
    simp only [ms3, ms2, rReadL_wWriteL, rReadL_rWriteL_self, termFn, hc, ↓reduceDIte]
    dsimp [diff]; ring
  rcases DetExecAt.repeatN_nat (.lit (d : ℤ)) _ d 1 35 Inv hInv0 rfl (by simp [intExprOps]) hStep
    with ⟨md, hInvd, hrep⟩
  rcases hInvd with ⟨hwd, hrd, _, hwld, hrld, haccd, hlvd, hrlvd⟩
  refine ⟨md, (hs1.seq (hs2.seq hrep)).mono_cost (by omega), ?_, hwd, hrd, hwld, hrld, hlvd, hrlvd⟩
  rw [haccd, euclideanDistSq_eq_sum_fin]
  symm
  calc (∑ i : Fin d, (euclideanCoord x i - euclideanCoord y i) ^ 2)
      = ∑ i : Fin d, termFn i.val := by
          refine Finset.sum_congr rfl fun i _ => ?_
          simp [termFn, i.isLt]
    _ = ∑ c ∈ Finset.range d, termFn c := sum_fin_eq_sum_range termFn

/-! ### 2. Heap-to-Local Coordinate Load (`loadHeapCoordsToLocalStmt`) -/

/-- Copy `rRead mem rTag (wReadL 1 mem 29 idxBase + c)` for `c < d` into `rReadL 1 mem' 29 (destOff + c)`,
using `29[1]` as loop index (`idxBase ≠ 1`). -/
def loadHeapCoordsToLocalStmt (d rTag : ℕ) (idxBase destOff : ℤ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 29 (.lit 1) (.lit 0),
    .repeatN (.lit (d : ℤ)) (seqList [
      .writeRealLocal 29 (.add (.lit destOff) (.readLocal 29 (.lit 1)))
        (.readRealHeap rTag (.add (.readLocal 29 (.lit idxBase)) (.readLocal 29 (.lit 1)))),
      .writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))
    ])
  ]

theorem boxSafe_loadHeapCoordsToLocalStmt {T_max M_box : ℕ} (d rTag : ℕ) (idxBase destOff : ℤ) :
    BoxSafeInner T_max M_box (loadHeapCoordsToLocalStmt d rTag idxBase destOff) := by
  unfold loadHeapCoordsToLocalStmt
  apply boxSafeInner_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · exact .writeWordLocal _ _ _
  · refine .repeatN _ (boxSafeInner_seqList ?_)
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl
    · exact .writeRealLocal _ _ _
    · exact .writeWordLocal _ _ _

theorem exec_loadHeapCoordsToLocalStmt {d rTag : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idxBase destOff : ℤ} {base : ℕ} {pt : EuclideanSpace ℝ (Fin d)}
    (hBase_ne1 : idxBase ≠ 1)
    (hBase : wReadL 1 mem 29 idxBase = (base : ℤ))
    (hHeap : ∀ c : Fin d, rRead mem rTag ((base + c.val : ℕ) : ℤ) = euclideanCoord pt c) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (loadHeapCoordsToLocalStmt d rTag idxBase destOff) mem mem' (25 * (d + 1)) ∧
      (∀ c : Fin d, rReadL 1 mem' 29 (destOff + (c.val : ℤ)) = euclideanCoord pt c) ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ idx, idx ≠ 1 → wReadL 1 mem' 29 idx = wReadL 1 mem 29 idx) ∧
      (∀ idx, (idx < destOff ∨ destOff + (d : ℤ) ≤ idx) → rReadL 1 mem' 29 idx = rReadL 1 mem 29 idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  let m1 := wWriteL 1 mem 29 1 0
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 1) (.lit 0)) mem m1 4 :=
    DetExecAt.writeWordLocal 1 inp mem 29 _ _ rfl rfl (by simp [intExprOps])
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    (∀ t idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t idx, rRead m t idx = rRead mem t idx) ∧
    wReadL 1 m 29 1 = (k : ℤ) ∧
    (∀ idx, idx ≠ 1 → wReadL 1 m 29 idx = wReadL 1 mem 29 idx) ∧
    (∀ c : Fin d, c.val < k → rReadL 1 m 29 (destOff + (c.val : ℤ)) = euclideanCoord pt c) ∧
    (∀ idx, (idx < destOff ∨ destOff + (k : ℤ) ≤ idx) → rReadL 1 m 29 idx = rReadL 1 mem 29 idx) ∧
    (∀ v, v ≠ 29 → ∀ idx, wReadL 1 m v idx = wReadL 1 mem v idx) ∧
    (∀ v, v ≠ 29 → ∀ idx, rReadL 1 m v idx = rReadL 1 mem v idx)
  have hInv0 : Inv 0 m1 := by
    refine ⟨fun _ _ => by simp [m1], fun _ _ => by simp [m1], by simp [m1],
      fun idx hi => by simp [m1, hi],
      fun c hc => by omega,
      fun idx _ => by simp [m1],
      fun v hv idx => by simp [m1, hv],
      fun v _ idx => by simp [m1]⟩
  have hStep : ∀ k < d, ∀ m, Inv k m →
      ∃ m', DetExecAt 1 inp
        (seqList [
          .writeRealLocal 29 (.add (.lit destOff) (.readLocal 29 (.lit 1)))
            (.readRealHeap rTag (.add (.readLocal 29 (.lit idxBase)) (.readLocal 29 (.lit 1)))),
          .writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))
        ]) m m' 22 ∧ Inv (k + 1) m' := by
    intro k hk m ⟨hw_m, hr_m, hm1, hwl_m, hlo, hhi, hlv_m, hrlv_m⟩
    let ms1 := rWriteL 1 m 29 (destOff + (k : ℤ)) (euclideanCoord pt ⟨k, hk⟩)
    let ms2 := wWriteL 1 ms1 29 1 ((k + 1 : ℕ) : ℤ)
    have hb1 : DetExecAt 1 inp
        (.writeRealLocal 29 (.add (.lit destOff) (.readLocal 29 (.lit 1)))
          (.readRealHeap rTag (.add (.readLocal 29 (.lit idxBase)) (.readLocal 29 (.lit 1))))) m ms1 12 := by
      refine DetExecAt.writeRealLocal 1 inp m 29 _ _ ?_ ?_ (by simp [intExprOps, realExprOps])
      · simp [hm1]
      · simp only [rValAt_readRealHeap, iValAt_add, iValAt_readLocal, iValAt_lit,
          hwl_m idxBase hBase_ne1, hBase, hm1, hr_m]
        have heq_bk : (base : ℤ) + (k : ℤ) = ((base + k : ℕ) : ℤ) := by push_cast; rfl
        rw [heq_bk]
        exact hHeap ⟨k, hk⟩
    have hb2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))) ms1 ms2 8 := by
      refine DetExecAt.writeWordLocal 1 inp ms1 29 _ _ rfl ?_ (by simp [intExprOps])
      simp [ms1, wReadL_rWriteL, hm1]
    refine ⟨ms2, (hb1.seq hb2).mono_cost (by omega),
      fun t idx => by simp [ms2, ms1, wRead_rWriteL, hw_m],
      fun t idx => by simp [ms2, ms1, rRead_rWriteL, hr_m],
      by simp [ms2],
      fun idx hi => by simp [ms2, ms1, wReadL_rWriteL, hi, hwl_m idx hi],
      fun c hc => ?_,
      fun idx hout => ?_,
      fun v hv idx => by simp [ms2, ms1, wReadL_rWriteL, hv, hlv_m v hv],
      fun v hv idx => by simp [ms2, ms1, hv, hrlv_m v hv]⟩
    · rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hc) with hlt | heq
      · have hne_z : destOff + (c.val : ℤ) ≠ destOff + (k : ℤ) := by omega
        simp [ms2, ms1, hne_z, hlo c hlt]
      · have hc_eq : c = ⟨k, hk⟩ := Fin.ext heq
        subst hc_eq
        simp [ms2, ms1]
    · have hne_z : idx ≠ destOff + (k : ℤ) := by omega
      have hprev : idx < destOff ∨ destOff + (k : ℤ) ≤ idx := by omega
      simp [ms2, ms1, hne_z, hhi idx hprev]
  rcases DetExecAt.repeatN_nat (.lit (d : ℤ)) _ d 1 22 Inv hInv0 rfl (by simp [intExprOps]) hStep
    with ⟨md, ⟨hwd, hrd, _, hwld, hlod, hhid, hlvd, hrlvd⟩, hrep⟩
  exact ⟨md, (hs1.seq hrep).mono_cost (by omega),
    fun c => hlod c c.isLt, hwd, hrd, hwld, hhid, hlvd, hrlvd⟩

/-- Copy `rReadL 1 mem 29 (srcOff + c)` for `c < d` into `rRead mem' rTag (base + c)` via `boxWriteR`,
using `29[1]` as loop index (`idxBase ≠ 1`). -/
def storeLocalCoordsToHeapStmt (d M_box rTag : ℕ) (idxBase srcOff : ℤ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 29 (.lit 1) (.lit 0),
    .repeatN (.lit (d : ℤ)) (seqList [
      boxWriteR M_box rTag (.add (.readLocal 29 (.lit idxBase)) (.readLocal 29 (.lit 1)))
        (.readRealLocal 29 (.add (.lit srcOff) (.readLocal 29 (.lit 1)))),
      .writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))
    ])
  ]

theorem boxSafe_storeLocalCoordsToHeapStmt {T_max M_box : ℕ}
    (d rTag : ℕ) (hT : rTag < T_max) (idxBase srcOff : ℤ) :
    BoxSafeInner T_max M_box (storeLocalCoordsToHeapStmt d M_box rTag idxBase srcOff) := by
  unfold storeLocalCoordsToHeapStmt
  apply boxSafeInner_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · exact .writeWordLocal _ _ _
  · refine .repeatN _ (boxSafeInner_seqList ?_)
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl
    · exact .boxR hT _ _
    · exact .writeWordLocal _ _ _

theorem exec_storeLocalCoordsToHeapStmt {d M_box rTag : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idxBase srcOff : ℤ} {base : ℕ} {pt : EuclideanSpace ℝ (Fin d)}
    (hBase_ne1 : idxBase ≠ 1)
    (hBase : wReadL 1 mem 29 idxBase = (base : ℤ))
    (hBox : base + d ≤ M_box)
    (hSrc : ∀ c : Fin d, rReadL 1 mem 29 (srcOff + (c.val : ℤ)) = euclideanCoord pt c) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (storeLocalCoordsToHeapStmt d M_box rTag idxBase srcOff) mem mem' (45 * (d + 1)) ∧
      (∀ c : Fin d, rRead mem' rTag ((base + c.val : ℕ) : ℤ) = euclideanCoord pt c) ∧
      (∀ idx : ℤ, (idx < (base : ℤ) ∨ ((base + d : ℕ) : ℤ) ≤ idx) → rRead mem' rTag idx = rRead mem rTag idx) ∧
      (∀ t, t ≠ rTag → ∀ idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 1 → wReadL 1 mem' 29 idx = wReadL 1 mem 29 idx) ∧
      (∀ idx, rReadL 1 mem' 29 idx = rReadL 1 mem 29 idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  let m1 := wWriteL 1 mem 29 1 0
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 1) (.lit 0)) mem m1 4 :=
    DetExecAt.writeWordLocal 1 inp mem 29 _ _ rfl rfl (by simp [intExprOps])
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    (∀ c : Fin d, c.val < k → rRead m rTag ((base + c.val : ℕ) : ℤ) = euclideanCoord pt c) ∧
    (∀ idx : ℤ, (idx < (base : ℤ) ∨ ((base + k : ℕ) : ℤ) ≤ idx) → rRead m rTag idx = rRead mem rTag idx) ∧
    (∀ t, t ≠ rTag → ∀ idx, rRead m t idx = rRead mem t idx) ∧
    (∀ t idx, wRead m t idx = wRead mem t idx) ∧
    wReadL 1 m 29 1 = (k : ℤ) ∧
    (∀ idx, idx ≠ 1 → wReadL 1 m 29 idx = wReadL 1 mem 29 idx) ∧
    (∀ idx, rReadL 1 m 29 idx = rReadL 1 mem 29 idx) ∧
    (∀ v, v ≠ 29 → ∀ idx, wReadL 1 m v idx = wReadL 1 mem v idx) ∧
    (∀ v, v ≠ 29 → ∀ idx, rReadL 1 m v idx = rReadL 1 mem v idx)
  have hInv0 : Inv 0 m1 := by
    refine ⟨fun _ hc => by omega, fun _ _ => by simp [m1], fun _ _ _ => by simp [m1],
      fun _ _ => by simp [m1], by simp [m1], fun idx hi => by simp [m1, hi],
      fun _ => by simp [m1], fun v hv _ => by simp [m1, hv], fun _ _ _ => by simp [m1]⟩
  have hStep : ∀ k < d, ∀ m, Inv k m →
      ∃ m', DetExecAt 1 inp
        (seqList [
          boxWriteR M_box rTag (.add (.readLocal 29 (.lit idxBase)) (.readLocal 29 (.lit 1)))
            (.readRealLocal 29 (.add (.lit srcOff) (.readLocal 29 (.lit 1)))),
          .writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))
        ]) m m' 40 ∧ Inv (k + 1) m' := by
    intro k hk m ⟨hlo, hhi, hrt_o, hw_m, hm1, hwl_m, hrl_m, hlv_m, hrlv_m⟩
    let bIdx : ℤ := ((base + k : ℕ) : ℤ)
    let ms1 := rWrite m rTag bIdx (euclideanCoord pt ⟨k, hk⟩)
    let ms2 := wWriteL 1 ms1 29 1 ((k + 1 : ℕ) : ℤ)
    have hb1 : DetExecAt 1 inp
        (boxWriteR M_box rTag (.add (.readLocal 29 (.lit idxBase)) (.readLocal 29 (.lit 1)))
          (.readRealLocal 29 (.add (.lit srcOff) (.readLocal 29 (.lit 1))))) m ms1 30 := by
      refine exec_boxWriteR inp m _ _ ?_ (Int.natCast_nonneg _) ?_ ?_ (by simp [intExprOps, realExprOps])
      · simp only [iValAt_add, iValAt_readLocal, iValAt_lit, hwl_m idxBase hBase_ne1, hBase, hm1]
        dsimp [bIdx]
      · dsimp [bIdx]; exact_mod_cast (by omega : base + k < M_box)
      · simp only [rValAt_readRealLocal, iValAt_add, iValAt_lit, iValAt_readLocal, hm1, hrl_m]
        exact hSrc ⟨k, hk⟩
    have hb2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))) ms1 ms2 8 := by
      refine DetExecAt.writeWordLocal 1 inp ms1 29 _ _ rfl ?_ (by simp [intExprOps])
      simp [ms1, wReadL_rWrite, hm1]
    refine ⟨ms2, (hb1.seq hb2).mono_cost (by omega),
      fun c hc => ?_,
      fun idx hout => ?_,
      fun t ht idx => by simp [ms2, ms1, ht, hrt_o t ht idx],
      fun t idx => by simp [ms2, ms1, wRead_rWrite, hw_m],
      by simp [ms2],
      fun idx hi => by simp [ms2, ms1, wReadL_rWrite, hi, hwl_m idx hi],
      fun idx => by simp [ms2, ms1, rReadL_rWrite, hrl_m],
      fun v hv idx => by simp [ms2, ms1, wReadL_rWrite, hv, hlv_m v hv],
      fun v hv idx => by simp [ms2, ms1, rReadL_rWrite, hrlv_m v hv]⟩
    · rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hc) with hlt | heq
      · have hne_z : ((base + c.val : ℕ) : ℤ) ≠ bIdx := by dsimp [bIdx]; omega
        simp only [ms2, ms1, rRead_wWriteL, rRead_rWrite_eq]
        rw [if_neg (fun h => hne_z h.2)]
        exact hlo c hlt
      · have hc_eq : c = ⟨k, hk⟩ := Fin.ext heq
        subst hc_eq
        simp [ms2, ms1, bIdx]
    · have hne_z : idx ≠ bIdx := by dsimp [bIdx]; omega
      have hprev : idx < (base : ℤ) ∨ ((base + k : ℕ) : ℤ) ≤ idx := by omega
      simp only [ms2, ms1, rRead_wWriteL, rRead_rWrite_eq]
      rw [if_neg (fun h => hne_z h.2)]
      exact hhi idx hprev
  rcases DetExecAt.repeatN_nat (.lit (d : ℤ)) _ d 1 40 Inv hInv0 rfl (by simp [intExprOps]) hStep
    with ⟨md, ⟨hlod, hhid, hrtd, hwd, _, hwld, hrld, hlvd, hrlvd⟩, hrep⟩
  exact ⟨md, (hs1.seq hrep).mono_cost (by omega),
    fun c => hlod c c.isLt, hhid, hrtd, hwd, hwld, hrld, hlvd, hrlvd⟩

/-! ### 3. Copy-On-Delete Snapshot Coordinates (`SaveGenBound` & `EncSlotCoords`) -/

def SaveGenBound (n NumSlots : ℕ) (mem : ArithRAMMemory) : Prop :=
  1 ≤ wRead mem 1 3 ∧
  (∀ s < NumSlots, wRead mem 6 (s : ℤ) < wRead mem 1 3) ∧
  (∀ s < NumSlots, ∀ h < n, wRead mem 11 ((s * n + h : ℕ) : ℤ) < wRead mem 1 3)

theorem SegGenBound.bump_nextGen {K NumSlots : ℕ} {mem : ArithRAMMemory}
    (h : SegGenBound K NumSlots mem) :
    SegGenBound K NumSlots (wWrite mem 1 3 (wRead mem 1 3 + 1)) := by
  refine ⟨?_, ?_, ?_⟩
  · have := h.1; simp; omega
  · intro s hs; have := h.2.1 s hs
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]; omega
  · intro s hs u hu; have := h.2.2 s hs u hu
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]; omega

def EncLiveCoords (d n : ℕ) (mem : ArithRAMMemory)
    (activeH : Finset ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d)) : Prop :=
  (∀ h ∈ activeH, h < n) ∧
  ∀ h ∈ activeH, ∀ c : Fin d,
    rRead mem 4 ((h * d + c.val : ℕ) : ℤ) = euclideanCoord (livePts h) c

def EncSlotCoords (d n : ℕ) (mem : ArithRAMMemory)
    (activeH : Finset ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d))
    (s : ℕ) (S : Finset ℕ) (snapPts : ℕ → EuclideanSpace ℝ (Fin d)) : Prop :=
  (∀ h ∈ S, h < n) ∧
  ((wRead mem 6 (s : ℤ) = 0 ∧ S ⊆ activeH ∧ ∀ h ∈ S, snapPts h = livePts h) ∨
   (1 ≤ wRead mem 6 (s : ℤ) ∧
    ∀ h ∈ S,
      (wRead mem 11 ((s * n + h : ℕ) : ℤ) = wRead mem 6 (s : ℤ) →
        ∀ c : Fin d, rRead mem 11 (((s * n + h) * d + c.val : ℕ) : ℤ) = euclideanCoord (snapPts h) c) ∧
      (wRead mem 11 ((s * n + h : ℕ) : ℤ) ≠ wRead mem 6 (s : ℤ) →
        h ∈ activeH ∧ snapPts h = livePts h)))

/-- Freeze a live slot `s < NumSlots` (`wRead mem 6 s = 0`) in `O(1)` time by assigning a fresh
generation `g := nextGen++` in Table `6`. -/
def freezeSlotStmt (M_box : ℕ) (sE : IntExpr) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 29 (.lit 2) sE,
    .writeWordLocal 29 (.lit 3) (.readHeap 1 (.lit 3)),
    boxWriteW M_box 6 (.readLocal 29 (.lit 2)) (.readLocal 29 (.lit 3)),
    boxWriteW M_box 1 (.lit 3) (.add (.readLocal 29 (.lit 3)) (.lit 1))
  ]

theorem boxSafe_freezeSlotStmt {T_max M_box : ℕ} (hT : 7 ≤ T_max) (sE : IntExpr) :
    BoxSafeInner T_max M_box (freezeSlotStmt M_box sE) := by
  unfold freezeSlotStmt
  apply boxSafeInner_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _

theorem exec_freezeSlotStmt {d n K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (sE : IntExpr) {s : ℕ} (hs : s < NumSlots)
    (hsE : iValAt 1 inp mem sE = (s : ℤ))
    (hM1 : 4 ≤ M_box) (hMs : NumSlots ≤ M_box)
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem)
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)} {S : Finset ℕ}
    (hS_sub : S ⊆ activeH)
    (hS_lt : ∀ h ∈ S, h < n) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (freezeSlotStmt M_box sE) mem mem' (intExprOps sE + 40) ∧
      SegGenBound K NumSlots mem' ∧
      SaveGenBound n NumSlots mem' ∧
      1 ≤ wRead mem' 6 (s : ℤ) ∧
      EncSlotCoords d n mem' activeH livePts s S livePts ∧
      (∀ s' < NumSlots, s' ≠ s → ∀ S' snapPts',
        EncSlotCoords d n mem activeH livePts s' S' snapPts' →
        EncSlotCoords d n mem' activeH livePts s' S' snapPts') ∧
      (∀ t, t ≠ 1 → t ≠ 6 → ∀ idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 3 → wRead mem' 1 idx = wRead mem 1 idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  set g := wRead mem 1 3
  let m1 := wWriteL 1 mem 29 2 (s : ℤ)
  let m2 := wWriteL 1 m1 29 3 g
  let m3 := wWrite m2 6 (s : ℤ) g
  let m4 := wWrite m3 1 3 (g + 1)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) sE) mem m1 (intExprOps sE + 2) :=
    DetExecAt.writeWordLocal 1 inp mem 29 _ _ rfl hsE (by dsimp [intExprOps]; omega)
  have hs2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 3) (.readHeap 1 (.lit 3))) m1 m2 5 :=
    DetExecAt.writeWordLocal 1 inp m1 29 _ _ rfl (by simp [m1, g]) (by simp [intExprOps])
  have hs3 : DetExecAt 1 inp (boxWriteW M_box 6 (.readLocal 29 (.lit 2)) (.readLocal 29 (.lit 3))) m2 m3 14 :=
    exec_boxWriteW inp m2 _ _ (by simp [m2, m1]) (by omega) (by omega) (by simp [m2]) (by simp [intExprOps])
  have hs4 : DetExecAt 1 inp (boxWriteW M_box 1 (.lit 3) (.add (.readLocal 29 (.lit 3)) (.lit 1))) m3 m4 14 :=
    exec_boxWriteW inp m3 _ _ rfl (by omega) (by omega) (by simp [m3, m2]) (by simp [intExprOps])
  refine ⟨m4, (hs1.seq (hs2.seq (hs3.seq hs4))).mono_cost (by omega),
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · refine ⟨by have := hseg.1; simp [m4, m3, m2, m1]; omega,
      fun s' hs' => by
        have := hseg.2.1 s' hs'
        have e5 : wRead m4 5 (s' : ℤ) = wRead mem 5 (s' : ℤ) := by simp [m4, m3, m2, m1]
        have e1 : wRead m4 1 3 = g + 1 := by simp [m4]
        rw [e5, e1]; omega,
      fun s' hs' u hu => by
        have := hseg.2.2 s' hs' u hu
        have e8 : ∀ idx, wRead m4 8 idx = wRead mem 8 idx := fun idx => by simp [m4, m3, m2, m1]
        have e1 : wRead m4 1 3 = g + 1 := by simp [m4]
        rw [e8, e1]; omega⟩
  · refine ⟨by have := hsave.1; simp [m4, m3, m2, m1]; omega,
      fun s' hs' => by
        by_cases heq : s' = s
        · subst heq; simp [m4, m3, m2, m1]
        · have hne_z : (s' : ℤ) ≠ (s : ℤ) := by omega
          have := hsave.2.1 s' hs'
          have e6 : wRead m4 6 (s' : ℤ) = wRead mem 6 (s' : ℤ) := by simp [m4, m3, m2, m1, hne_z]
          have e1 : wRead m4 1 3 = g + 1 := by simp [m4]
          rw [e6, e1]; omega,
      fun s' hs' h hh => by
        have := hsave.2.2 s' hs' h hh
        have e11 : ∀ idx, wRead m4 11 idx = wRead mem 11 idx := fun idx => by simp [m4, m3, m2, m1]
        have e1 : wRead m4 1 3 = g + 1 := by simp [m4]
        rw [e11, e1]; omega⟩
  · have := hsave.1; simp [m4, m3, m2, m1]; exact this
  · refine ⟨hS_lt, Or.inr ⟨by simp [m4, m3, m2, m1]; exact hsave.1, fun h hhS => ?_⟩⟩
    have hlt_g := hsave.2.2 s hs h (hS_lt h hhS)
    have h11_eq : wRead m4 11 ((s * n + h : ℕ) : ℤ) = wRead mem 11 ((s * n + h : ℕ) : ℤ) := by
      simp only [m4, m3, m2, m1, wRead_wWrite_eq, wRead_wWriteL]; simp
    have h6_eq : wRead m4 6 (s : ℤ) = g := by simp [m4, m3, m2, m1]
    rw [h11_eq, h6_eq]
    exact ⟨fun heq => by omega, fun _ => ⟨hS_sub hhS, rfl⟩⟩
  · intro s' _ hne S' snapPts' hEnc
    have hne_z : (s' : ℤ) ≠ (s : ℤ) := by omega
    have hw6 : wRead m4 6 (s' : ℤ) = wRead mem 6 (s' : ℤ) := by
      simp only [m4, m3, m2, m1, wRead_wWrite_eq, wRead_wWriteL]; simp [hne_z]
    have hw11 : ∀ idx, wRead m4 11 idx = wRead mem 11 idx := by
      intro idx; simp only [m4, m3, m2, m1, wRead_wWrite_eq, wRead_wWriteL]; simp
    have hr11 : ∀ idx, rRead m4 11 idx = rRead mem 11 idx := by
      intro idx; simp [m4, m3, m2, m1]
    simpa [EncSlotCoords, hw6, hw11, hr11] using hEnc
  · intro t ht1 ht6 idx; simp [m4, m3, m2, m1, ht1, ht6]
  · intro idx hi; simp [m4, m3, m2, m1, hi]
  · intro t idx; simp [m4, m3, m2, m1]
  · intro v hv idx; simp [m4, m3, m2, m1, hv]
  · intro v idx; simp [m4, m3, m2, m1]

/-- Read point coordinates of handle `h = 29[21]` in slot `s = 29[20]` into `r29[destOff .. destOff + d - 1]`. -/
def readSlotPtToLocalStmt (d n : ℕ) (destOff : ℤ) : ArithRAMStmt :=
  let n_lit : IntExpr := .lit (n : ℤ)
  let d_lit : IntExpr := .lit (d : ℤ)
  seqList [
    .writeWordLocal 29 (.lit 4) (.add (.mul (.readLocal 29 (.lit 20)) n_lit) (.readLocal 29 (.lit 21))),
    .ite (.and (.intLe (.lit 1) (.readHeap 6 (.readLocal 29 (.lit 20))))
               (.intEq (.readHeap 11 (.readLocal 29 (.lit 4))) (.readHeap 6 (.readLocal 29 (.lit 20)))))
      (seqList [
        .writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 4)) d_lit),
        loadHeapCoordsToLocalStmt d 11 5 destOff
      ])
      (seqList [
        .writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 21)) d_lit),
        loadHeapCoordsToLocalStmt d 4 5 destOff
      ])
  ]

theorem boxSafe_readSlotPtToLocalStmt {T_max M_box : ℕ} (d n : ℕ) (destOff : ℤ) :
    BoxSafeInner T_max M_box (readSlotPtToLocalStmt d n destOff) := by
  unfold readSlotPtToLocalStmt
  apply boxSafeInner_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · exact .writeWordLocal _ _ _
  · refine .ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_) <;> {
      intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
      rcases hx with rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact boxSafe_loadHeapCoordsToLocalStmt d _ 5 destOff }

theorem exec_readSlotPtToLocalStmt {d n : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {destOff : ℤ} {s h : ℕ}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    (hs_reg : wReadL 1 mem 29 20 = (s : ℤ))
    (hh_reg : wReadL 1 mem 29 21 = (h : ℤ))
    (hh_in : h ∈ S)
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hSlot : EncSlotCoords d n mem activeH livePts s S snapPts) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (readSlotPtToLocalStmt d n destOff) mem mem' (30 * (d + 1) + 40) ∧
      (∀ c : Fin d, rReadL 1 mem' 29 (destOff + (c.val : ℤ)) = euclideanCoord (snapPts h) c) ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ idx, idx ≠ 1 → idx ≠ 4 → idx ≠ 5 → wReadL 1 mem' 29 idx = wReadL 1 mem 29 idx) ∧
      (∀ idx, (idx < destOff ∨ destOff + (d : ℤ) ≤ idx) → rReadL 1 mem' 29 idx = rReadL 1 mem 29 idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  let pairIdx : ℕ := s * n + h
  let m1 := wWriteL 1 mem 29 4 (pairIdx : ℤ)
  have hs1 : DetExecAt 1 inp
      (.writeWordLocal 29 (.lit 4) (.add (.mul (.readLocal 29 (.lit 20)) (.lit (n : ℤ))) (.readLocal 29 (.lit 21))))
      mem m1 12 := by
    refine DetExecAt.writeWordLocal 1 inp mem 29 _ _ rfl ?_ (by simp [intExprOps])
    simp only [iValAt_add, iValAt_mul, iValAt_readLocal, iValAt_lit, hs_reg, hh_reg, pairIdx]
    push_cast; rfl
  by_cases hsaved : 1 ≤ wRead mem 6 (s : ℤ) ∧ wRead mem 11 (pairIdx : ℤ) = wRead mem 6 (s : ℤ)
  · have hcond : cValAt 1 inp m1
        (.and (.intLe (.lit 1) (.readHeap 6 (.readLocal 29 (.lit 20))))
              (.intEq (.readHeap 11 (.readLocal 29 (.lit 4))) (.readHeap 6 (.readLocal 29 (.lit 20))))) = true := by
      simp only [cValAt_and, cValAt_intLe, cValAt_intEq, iValAt_lit, iValAt_readHeap, iValAt_readLocal,
        m1, wRead_wWriteL, wReadL_wWriteL_eq, hs_reg, Bool.and_eq_true, decide_eq_true_eq]
      exact ⟨hsaved.1, by simpa using hsaved.2⟩
    have hcoords11 : ∀ c : Fin d, rRead mem 11 (((pairIdx * d) + c.val : ℕ) : ℤ) = euclideanCoord (snapPts h) c := by
      rcases hSlot.2 with ⟨hw0, _, _⟩ | ⟨_, hall⟩
      · omega
      · exact (hall h hh_in).1 hsaved.2
    let m2 := wWriteL 1 m1 29 5 ((pairIdx * d : ℕ) : ℤ)
    have hb1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 4)) (.lit (d : ℤ)))) m1 m2 8 := by
      refine DetExecAt.writeWordLocal 1 inp m1 29 _ _ rfl ?_ (by simp [intExprOps])
      simp only [iValAt_mul, iValAt_readLocal, iValAt_lit, m1, wReadL_wWriteL_self]
      push_cast; rfl
    rcases exec_loadHeapCoordsToLocalStmt (rTag := 11) inp m2 (idxBase := 5) (destOff := destOff) (base := pairIdx * d) (pt := snapPts h)
        (by decide) (by simp [m2]) (fun c => by simp only [m2, m1, rRead_wWriteL]; exact hcoords11 c)
      with ⟨m3, hexL, hpt, hw3, hr3, hwl3, hrl3, hlv3, hrlv3⟩
    refine ⟨m3, (hs1.seq (DetExecAt.ite_true hcond (C_c := 18) (by simp [condExprOps, intExprOps]) (hb1.seq hexL))).mono_cost (by omega),
      hpt,
      fun t idx => by simp [hw3, m2, m1],
      fun t idx => by simp [hr3, m2, m1],
      fun idx h1 h4 h5 => by rw [hwl3 idx h1]; simp [m2, m1, h4, h5],
      fun idx hout => by rw [hrl3 idx hout]; simp [m2, m1],
      fun v hv idx => by rw [hlv3 v hv idx]; simp [m2, m1, hv],
      fun v hv idx => by rw [hrlv3 v hv idx]; simp [m2, m1]⟩
  · have hcond : cValAt 1 inp m1
        (.and (.intLe (.lit 1) (.readHeap 6 (.readLocal 29 (.lit 20))))
              (.intEq (.readHeap 11 (.readLocal 29 (.lit 4))) (.readHeap 6 (.readLocal 29 (.lit 20))))) = false := by
      simp only [cValAt_and, cValAt_intLe, cValAt_intEq, iValAt_lit, iValAt_readHeap, iValAt_readLocal,
        m1, wRead_wWriteL, wReadL_wWriteL_eq, hs_reg, Bool.and_eq_false_iff, decide_eq_false_iff_not]
      by_cases h1 : 1 ≤ wRead mem 6 (s : ℤ)
      · right; intro heq; exact hsaved ⟨h1, by simpa using heq⟩
      · left; exact h1
    have hact_eq : h ∈ activeH ∧ snapPts h = livePts h := by
      rcases hSlot.2 with ⟨_, hsub, heq⟩ | ⟨hge1, hall⟩
      · exact ⟨hsub hh_in, heq h hh_in⟩
      · have hne11 : wRead mem 11 (pairIdx : ℤ) ≠ wRead mem 6 (s : ℤ) := fun heq => hsaved ⟨hge1, heq⟩
        exact (hall h hh_in).2 hne11
    have hcoords4 : ∀ c : Fin d, rRead mem 4 (((h * d) + c.val : ℕ) : ℤ) = euclideanCoord (snapPts h) c := by
      intro c; rw [hact_eq.2]; exact hLive.2 h hact_eq.1 c
    let m2 := wWriteL 1 m1 29 5 ((h * d : ℕ) : ℤ)
    have hb1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 21)) (.lit (d : ℤ)))) m1 m2 8 := by
      refine DetExecAt.writeWordLocal 1 inp m1 29 _ _ rfl ?_ (by simp [intExprOps])
      simp only [iValAt_mul, iValAt_readLocal, iValAt_lit, m1, wReadL_wWriteL_eq, hh_reg]
      simp
    rcases exec_loadHeapCoordsToLocalStmt (rTag := 4) inp m2 (idxBase := 5) (destOff := destOff) (base := h * d) (pt := snapPts h)
        (by decide) (by simp [m2]) (fun c => by simp only [m2, m1, rRead_wWriteL]; exact hcoords4 c)
      with ⟨m3, hexL, hpt, hw3, hr3, hwl3, hrl3, hlv3, hrlv3⟩
    refine ⟨m3, (hs1.seq (DetExecAt.ite_false hcond (C_c := 18) (by simp [condExprOps, intExprOps]) (hb1.seq hexL))).mono_cost (by omega),
      hpt,
      fun t idx => by simp [hw3, m2, m1],
      fun t idx => by simp [hr3, m2, m1],
      fun idx h1 h4 h5 => by rw [hwl3 idx h1]; simp [m2, m1, h4, h5],
      fun idx hout => by rw [hrl3 idx hout]; simp [m2, m1],
      fun v hv idx => by rw [hlv3 v hv idx]; simp [m2, m1, hv],
      fun v hv idx => by rw [hrlv3 v hv idx]; simp [m2, m1]⟩

/-- Copy-On-Delete before removing `delH = 29[21]` from `activeH`: saves `livePts delH` into
`snapCoords` (Table 11) for every frozen slot `s < NumSlots` not yet saved for `delH`. -/
def copyOnDeleteStepStmt (d n M_box : ℕ) : ArithRAMStmt :=
  let n_lit : IntExpr := .lit (n : ℤ)
  let d_lit : IntExpr := .lit (d : ℤ)
  seqList [
    .writeWordLocal 29 (.lit 4) (.add (.mul (.readLocal 29 (.lit 2)) n_lit) (.readLocal 29 (.lit 21))),
    .ite (.and (.intLe (.lit 1) (.readHeap 6 (.readLocal 29 (.lit 2))))
               (.not (.intEq (.readHeap 11 (.readLocal 29 (.lit 4))) (.readHeap 6 (.readLocal 29 (.lit 2))))))
      (seqList [
        .writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 4)) d_lit),
        storeLocalCoordsToHeapStmt d M_box 11 5 0,
        boxWriteW M_box 11 (.readLocal 29 (.lit 4)) (.readHeap 6 (.readLocal 29 (.lit 2)))
      ])
      .skip,
    .writeWordLocal 29 (.lit 2) (.add (.readLocal 29 (.lit 2)) (.lit 1))
  ]

def copyOnDeleteStmt (d n NumSlots M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 21)) (.lit (d : ℤ))),
    loadHeapCoordsToLocalStmt d 4 5 0,
    .writeWordLocal 29 (.lit 2) (.lit 0),
    .repeatN (.lit (NumSlots : ℤ)) (copyOnDeleteStepStmt d n M_box)
  ]

theorem boxSafe_copyOnDeleteStmt {T_max M_box : ℕ} (hT : 12 ≤ T_max) (d n NumSlots : ℕ) :
    BoxSafeInner T_max M_box (copyOnDeleteStmt d n NumSlots M_box) := by
  unfold copyOnDeleteStmt copyOnDeleteStepStmt
  apply boxSafeInner_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact boxSafe_loadHeapCoordsToLocalStmt d 4 5 0
  · exact .writeWordLocal _ _ _
  · refine .repeatN _ (boxSafeInner_seqList ?_)
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · refine .ite _ (boxSafeInner_seqList ?_) .skip
      intro y hy; simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
      rcases hy with rfl | rfl | rfl
      · exact .writeWordLocal _ _ _
      · exact boxSafe_storeLocalCoordsToHeapStmt d 11 (by omega) 5 0
      · exact .boxW (by omega) _ _
    · exact .writeWordLocal _ _ _

theorem exec_copyOnDeleteStmt {d n NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {delH : ℕ} {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    (hdel_in : delH ∈ activeH) (hdel_lt : delH < n)
    (hh_reg : wReadL 1 mem 29 21 = (delH : ℤ))
    (hBox1 : NumSlots * n ≤ M_box)
    (hBox2 : NumSlots * n * d ≤ M_box)
    (hsave : SaveGenBound n NumSlots mem)
    (hLive : EncLiveCoords d n mem activeH livePts) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (copyOnDeleteStmt d n NumSlots M_box) mem mem'
        (150 * (NumSlots + 1) * (d + 1)) ∧
      SaveGenBound n NumSlots mem' ∧
      (∀ s < NumSlots, 1 ≤ wRead mem 6 (s : ℤ) →
        ∀ S snapPts (livePts' : ℕ → EuclideanSpace ℝ (Fin d)),
          (∀ x ∈ activeH.erase delH, livePts' x = livePts x) →
          EncSlotCoords d n mem activeH livePts s S snapPts →
          EncSlotCoords d n mem' (activeH.erase delH) livePts' s S snapPts) ∧
      (∀ t, t ≠ 11 → ∀ idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t, t ≠ 11 → ∀ idx, rRead mem' t idx = rRead mem t idx) ∧
      wReadL 1 mem' 29 21 = (delH : ℤ) ∧
      (∀ v, v ≠ 29 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  let m1 := wWriteL 1 mem 29 5 ((delH * d : ℕ) : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 21)) (.lit (d : ℤ)))) mem m1 8 := by
    refine DetExecAt.writeWordLocal 1 inp mem 29 _ _ rfl ?_ (by simp [intExprOps])
    simp only [iValAt_mul, iValAt_readLocal, iValAt_lit, hh_reg]; push_cast; rfl
  rcases exec_loadHeapCoordsToLocalStmt (rTag := 4) inp m1 (idxBase := 5) (destOff := 0) (base := delH * d) (pt := livePts delH)
      (by decide) (by simp [m1]) (fun c => by simp only [m1, rRead_wWriteL]; exact hLive.2 delH hdel_in c)
    with ⟨m2, hexL, hpt2, hw2, hr2, hwl2, _, hlv2, hrlv2⟩
  let m3 := wWriteL 1 m2 29 2 0
  have hs3 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) (.lit 0)) m2 m3 4 :=
    DetExecAt.writeWordLocal 1 inp m2 29 _ _ rfl rfl (by simp [intExprOps])
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    SaveGenBound n NumSlots m ∧
    wReadL 1 m 29 2 = (k : ℤ) ∧
    wReadL 1 m 29 21 = (delH : ℤ) ∧
    (∀ c : Fin d, rReadL 1 m 29 (c.val : ℤ) = euclideanCoord (livePts delH) c) ∧
    (∀ t, t ≠ 11 → ∀ idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t, t ≠ 11 → ∀ idx, rRead m t idx = rRead mem t idx) ∧
    -- Slots < k with wRead 6 s ≥ 1 have delH saved (or already saved in mem)
    (∀ s < k, 1 ≤ wRead mem 6 (s : ℤ) →
      wRead m 11 ((s * n + delH : ℕ) : ℤ) = wRead mem 6 (s : ℤ) ∧
      (wRead mem 11 ((s * n + delH : ℕ) : ℤ) = wRead mem 6 (s : ℤ) →
        ∀ c : Fin d, rRead m 11 (((s * n + delH) * d + c.val : ℕ) : ℤ) =
                     rRead mem 11 (((s * n + delH) * d + c.val : ℕ) : ℤ)) ∧
      (wRead mem 11 ((s * n + delH : ℕ) : ℤ) ≠ wRead mem 6 (s : ℤ) →
        ∀ c : Fin d, rRead m 11 (((s * n + delH) * d + c.val : ℕ) : ℤ) =
                     euclideanCoord (livePts delH) c)) ∧
    -- Slots ≥ k or handles h ≠ delH are untouched in Table 11
    (∀ s h : ℕ, h < n → (k ≤ s ∨ h ≠ delH) →
      wRead m 11 ((s * n + h : ℕ) : ℤ) = wRead mem 11 ((s * n + h : ℕ) : ℤ) ∧
      ∀ c : Fin d, rRead m 11 (((s * n + h) * d + c.val : ℕ) : ℤ) =
                   rRead mem 11 (((s * n + h) * d + c.val : ℕ) : ℤ)) ∧
    (∀ v, v ≠ 29 → ∀ idx, wReadL 1 m v idx = wReadL 1 mem v idx) ∧
    (∀ v, v ≠ 29 → ∀ idx, rReadL 1 m v idx = rReadL 1 mem v idx)
  have hInv0 : Inv 0 m3 := by
    refine ⟨by simpa [SaveGenBound, m3, hw2, m1] using hsave,
      by simp [m3],
      by simp only [m3, wReadL_wWriteL_eq]; simp [hwl2 21 (by decide), m1, hh_reg],
      fun c => by simpa [m3] using hpt2 c,
      fun t _ idx => by simp [m3, hw2, m1],
      fun t _ idx => by simp [m3, hr2, m1],
      fun _ hs => by omega,
      fun s h _ _ => ⟨by simp [m3, hw2, m1], fun _ => by simp [m3, hr2, m1]⟩,
      fun v hv idx => by simp [m3, hv, hlv2 v hv idx, m1],
      fun v hv idx => by simp [m3, hrlv2 v hv idx, m1]⟩
  have hStep : ∀ k < NumSlots, ∀ m, Inv k m →
      ∃ m', DetExecAt 1 inp (copyOnDeleteStepStmt d n M_box) m m' (120 * (d + 1)) ∧ Inv (k + 1) m' := by
    intro k hk m ⟨hSg, hm2, hm21, hm_pt, hwO, hrO, hSavedLt, hUnch, hlv_m, hrlv_m⟩
    let pairIdx : ℕ := k * n + delH
    have hpair_lt_box : pairIdx < M_box := by
      have : k * n + delH < NumSlots * n := by
        calc k * n + delH < k * n + n := by omega
          _ = (k + 1) * n := by ring
          _ ≤ NumSlots * n := Nat.mul_le_mul_right _ hk
      omega
    have hcoord_le_box : pairIdx * d + d ≤ M_box := by
      have h1 : pairIdx + 1 ≤ NumSlots * n := by
        dsimp [pairIdx]
        calc k * n + delH + 1 ≤ k * n + n := by omega
          _ = (k + 1) * n := by ring
          _ ≤ NumSlots * n := Nat.mul_le_mul_right _ hk
      calc pairIdx * d + d = (pairIdx + 1) * d := by ring
        _ ≤ (NumSlots * n) * d := Nat.mul_le_mul_right _ h1
        _ ≤ M_box := hBox2
    let ma1 := wWriteL 1 m 29 4 (pairIdx : ℤ)
    have ha1 : DetExecAt 1 inp
        (.writeWordLocal 29 (.lit 4) (.add (.mul (.readLocal 29 (.lit 2)) (.lit (n : ℤ))) (.readLocal 29 (.lit 21))))
        m ma1 12 := by
      refine DetExecAt.writeWordLocal 1 inp m 29 _ _ rfl ?_ (by simp [intExprOps])
      simp only [iValAt_add, iValAt_mul, iValAt_readLocal, iValAt_lit, hm2, hm21, pairIdx]
      push_cast; rfl
    have hw6_k : wRead m 6 (k : ℤ) = wRead mem 6 (k : ℤ) := hwO 6 (by decide) (k : ℤ)
    have hw11_k : wRead m 11 (pairIdx : ℤ) = wRead mem 11 (pairIdx : ℤ) :=
      (hUnch k delH hdel_lt (Or.inl le_rfl)).1
    by_cases hdo : 1 ≤ wRead mem 6 (k : ℤ) ∧ wRead mem 11 (pairIdx : ℤ) ≠ wRead mem 6 (k : ℤ)
    · have hcond : cValAt 1 inp ma1
          (.and (.intLe (.lit 1) (.readHeap 6 (.readLocal 29 (.lit 2))))
                (.not (.intEq (.readHeap 11 (.readLocal 29 (.lit 4))) (.readHeap 6 (.readLocal 29 (.lit 2)))))) = true := by
        have h2_ma1 : wReadL 1 ma1 29 2 = (k : ℤ) := by simp [ma1, hm2]
        have h4_ma1 : wReadL 1 ma1 29 4 = (pairIdx : ℤ) := by simp [ma1]
        simp only [cValAt_and, cValAt_intLe, cValAt_not, cValAt_intEq, iValAt_lit, iValAt_readHeap,
          iValAt_readLocal, h2_ma1, h4_ma1, ma1, wRead_wWriteL, hw6_k, hw11_k,
          Bool.and_eq_true, Bool.not_eq_true', decide_eq_true_eq, decide_eq_false_iff_not]
        exact hdo
      let mb1 := wWriteL 1 ma1 29 5 ((pairIdx * d : ℕ) : ℤ)
      have hb1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 4)) (.lit (d : ℤ)))) ma1 mb1 8 := by
        refine DetExecAt.writeWordLocal 1 inp ma1 29 _ _ rfl ?_ (by simp [intExprOps])
        simp only [iValAt_mul, iValAt_readLocal, iValAt_lit, ma1, wReadL_wWriteL_self]; push_cast; rfl
      rcases exec_storeLocalCoordsToHeapStmt inp mb1 (idxBase := 5) (srcOff := 0)
          (base := pairIdx * d) (pt := livePts delH)
          (by decide) (by simp [mb1]) hcoord_le_box (fun c => by simpa [mb1, ma1] using hm_pt c)
        with ⟨mb2, hexS, hst_c, hst_out, hst_rt, hst_w, hst_wl, hst_rl, hst_lv, hst_rlv⟩
      let mb3 := wWrite mb2 11 (pairIdx : ℤ) (wRead mem 6 (k : ℤ))
      have hb3 : DetExecAt 1 inp (boxWriteW M_box 11 (.readLocal 29 (.lit 4)) (.readHeap 6 (.readLocal 29 (.lit 2)))) mb2 mb3 18 := by
        refine exec_boxWriteW inp mb2 _ _ ?_ (Int.natCast_nonneg _)
          (by dsimp [pairIdx]; exact_mod_cast hpair_lt_box) ?_ (by simp [intExprOps])
        · simp only [iValAt_readLocal, iValAt_lit, hst_wl 4 (by decide), mb1, ma1, wReadL_wWriteL_eq]; simp
        · have h2_mb2 : wReadL 1 mb2 29 2 = (k : ℤ) := by rw [hst_wl 2 (by decide)]; simp [mb1, ma1, hm2]
          simp only [iValAt_readHeap, iValAt_readLocal, iValAt_lit, h2_mb2, hst_w, mb1, ma1, wRead_wWriteL, hw6_k]
      let mb4 := wWriteL 1 mb3 29 2 ((k + 1 : ℕ) : ℤ)
      have hb4 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) (.add (.readLocal 29 (.lit 2)) (.lit 1))) mb3 mb4 8 := by
        refine DetExecAt.writeWordLocal 1 inp mb3 29 _ _ rfl ?_ (by simp [intExprOps])
        simp only [iValAt_add, iValAt_readLocal, iValAt_lit, mb3, wReadL_wWrite, hst_wl 2 (by decide),
          mb1, ma1, wReadL_wWriteL_eq, hm2]; simp
      -- Helper: for (s, h) ≠ (k, delH) with h < n, s * n + h ≠ pairIdx and its [base, base + d) is disjoint!
      have hne_pair : ∀ s h : ℕ, h < n → (s ≠ k ∨ h ≠ delH) → s * n + h ≠ pairIdx := by
        intro s h hh hne heq
        dsimp [pairIdx] at heq
        rcases lt_trichotomy s k with hlt | rfl | hgt
        · have : (s + 1) * n ≤ k * n := Nat.mul_le_mul_right _ hlt
          have : s * n + h < (s + 1) * n := by rw [add_mul, one_mul]; omega
          omega
        · rcases hne with hsk | hhd
          · exact hsk rfl
          · exact hhd (by omega)
        · have : (k + 1) * n ≤ s * n := Nat.mul_le_mul_right _ hgt
          have : k * n + delH < (k + 1) * n := by rw [add_mul, one_mul]; omega
          omega
      have hout_coord : ∀ p₂ : ℕ, p₂ ≠ pairIdx → ∀ c : Fin d,
          (((p₂ * d + c.val : ℕ) : ℤ) < ((pairIdx * d : ℕ) : ℤ) ∨
           ((pairIdx * d + d : ℕ) : ℤ) ≤ ((p₂ * d + c.val : ℕ) : ℤ)) := by
        intro p₂ hp₂ c
        rcases lt_trichotomy p₂ pairIdx with hlt | rfl | hgt
        · left
          have : p₂ * d + c.val < pairIdx * d := by
            calc p₂ * d + c.val < p₂ * d + d := by omega
              _ = (p₂ + 1) * d := by ring
              _ ≤ pairIdx * d := Nat.mul_le_mul_right _ hlt
          exact_mod_cast this
        · exact absurd rfl hp₂
        · right
          have : pairIdx * d + d ≤ p₂ * d + c.val := by
            calc pairIdx * d + d = (pairIdx + 1) * d := by ring
              _ ≤ p₂ * d := Nat.mul_le_mul_right _ hgt
              _ ≤ p₂ * d + c.val := Nat.le_add_right _ _
          exact_mod_cast this
      refine ⟨mb4, (ha1.seq ((DetExecAt.ite_true hcond (C_c := 20) (by simp [condExprOps, intExprOps])
          (hb1.seq (hexS.seq hb3))).seq hb4)).mono_cost (by omega),
        ?_, by simp [mb4], ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · refine ⟨by simp [mb4, mb3, hst_w, mb1, ma1]; exact hSg.1,
          fun s' hs' => by simp [mb4, mb3, hst_w, mb1, ma1]; exact hSg.2.1 s' hs',
          fun s' hs' h hh => ?_⟩
        have hw1_eq : wRead mb4 1 3 = wRead m 1 3 := by simp [mb4, mb3, hst_w, mb1, ma1]
        rw [hw1_eq]
        by_cases heq_idx : ((s' * n + h : ℕ) : ℤ) = (pairIdx : ℤ)
        · rw [heq_idx]; simp only [mb4, mb3, wRead_wWriteL, wRead_wWrite_self, ← hw6_k]
          exact hSg.2.1 k hk
        · simp only [mb4, mb3, wRead_wWriteL, wRead_wWrite_eq]
          rw [if_neg (fun h1 => heq_idx h1.2)]
          simpa [hst_w, mb1, ma1] using hSg.2.2 s' hs' h hh
      · simp only [mb4, mb3, wReadL_wWriteL_eq, wReadL_wWrite, hst_wl 21 (by decide), mb1, ma1]; simp [hm21]
      · intro c; simp [mb4, mb3, rReadL_wWrite, hst_rl, mb1, ma1, hm_pt c]
      · intro t ht idx; simp [mb4, mb3, ht, hst_w, mb1, ma1, hwO t ht idx]
      · intro t ht idx; simp [mb4, mb3, rRead_wWrite, hst_rt t ht idx, mb1, ma1, hrO t ht idx]
      · intro s hs_lt h6_pos
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hs_lt) with hlt | rfl
        · have hnp := hne_pair s delH hdel_lt (Or.inl (ne_of_lt hlt))
          have hnp_z : ((s * n + delH : ℕ) : ℤ) ≠ (pairIdx : ℤ) := by exact_mod_cast hnp
          rcases hSavedLt s hlt h6_pos with ⟨hs_w, hs_eq, hs_ne⟩
          refine ⟨?_, fun heq c => ?_, fun hne c => ?_⟩
          · simp only [mb4, mb3, wRead_wWriteL, wRead_wWrite_eq]
            rw [if_neg (fun h1 => hnp_z h1.2)]
            simpa [hst_w, mb1, ma1] using hs_w
          · simp only [mb4, mb3, rRead_wWriteL, rRead_wWrite, hst_out _ (hout_coord _ hnp c), mb1, ma1, rRead_wWriteL]
            exact hs_eq heq c
          · simp only [mb4, mb3, rRead_wWriteL, rRead_wWrite, hst_out _ (hout_coord _ hnp c), mb1, ma1, rRead_wWriteL]
            exact hs_ne hne c
        · refine ⟨by simp [mb4, mb3, pairIdx], fun heq => absurd heq hdo.2, fun _ c => ?_⟩
          simp only [mb4, mb3, rRead_wWriteL, rRead_wWrite]; exact hst_c c
      · intro s h hh hcond_sh
        have hnp : s * n + h ≠ pairIdx := hne_pair s h hh (hcond_sh.imp (fun h1 => by omega) id)
        have hnp_z : ((s * n + h : ℕ) : ℤ) ≠ (pairIdx : ℤ) := by exact_mod_cast hnp
        have hprev := hUnch s h hh (hcond_sh.imp (fun h1 => by omega) id)
        refine ⟨?_, fun c => ?_⟩
        · simp only [mb4, mb3, wRead_wWriteL, wRead_wWrite_eq]
          rw [if_neg (fun h1 => hnp_z h1.2)]
          simpa [hst_w, mb1, ma1] using hprev.1
        · simp only [mb4, mb3, rRead_wWriteL, rRead_wWrite, hst_out _ (hout_coord _ hnp c), mb1, ma1, rRead_wWriteL]
          exact hprev.2 c
      · intro v hv idx; simp [mb4, mb3, hv, wReadL_wWrite, hst_lv v hv idx, mb1, ma1, hlv_m v hv idx]
      · intro v hv idx; simp [mb4, mb3, rReadL_wWrite, hst_rlv v hv idx, mb1, ma1, hrlv_m v hv idx]
    · have hcond : cValAt 1 inp ma1
          (.and (.intLe (.lit 1) (.readHeap 6 (.readLocal 29 (.lit 2))))
                (.not (.intEq (.readHeap 11 (.readLocal 29 (.lit 4))) (.readHeap 6 (.readLocal 29 (.lit 2)))))) = false := by
        have h2_ma1 : wReadL 1 ma1 29 2 = (k : ℤ) := by simp [ma1, hm2]
        have h4_ma1 : wReadL 1 ma1 29 4 = (pairIdx : ℤ) := by simp [ma1]
        simp only [cValAt_and, cValAt_intLe, cValAt_not, cValAt_intEq, iValAt_lit, iValAt_readHeap,
          iValAt_readLocal, h2_ma1, h4_ma1, ma1, wRead_wWriteL, hw6_k, hw11_k,
          Bool.and_eq_false_iff, Bool.not_eq_false', decide_eq_false_iff_not, decide_eq_true_eq]
        by_cases h1 : 1 ≤ wRead mem 6 (k : ℤ)
        · right; by_contra hne; exact hdo ⟨h1, hne⟩
        · left; exact h1
      let mb1 := wWriteL 1 ma1 29 2 ((k + 1 : ℕ) : ℤ)
      have hb1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) (.add (.readLocal 29 (.lit 2)) (.lit 1))) ma1 mb1 8 := by
        refine DetExecAt.writeWordLocal 1 inp ma1 29 _ _ rfl ?_ (by simp [intExprOps])
        simp [ma1, hm2]
      have hw_mb1 : ∀ t idx, wRead mb1 t idx = wRead m t idx := fun _ _ => by simp [mb1, ma1]
      have hr_mb1 : ∀ t idx, rRead mb1 t idx = rRead m t idx := fun _ _ => by simp [mb1, ma1]
      refine ⟨mb1, (ha1.seq ((DetExecAt.ite_false hcond (C_c := 20) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 1 inp ma1)).seq hb1)).mono_cost (by omega),
        by simpa only [SaveGenBound, hw_mb1] using hSg,
        by simp [mb1],
        by simp [mb1, ma1, hm21],
        fun c => by simpa [mb1, ma1] using hm_pt c,
        fun t ht idx => by rw [hw_mb1]; exact hwO t ht idx,
        fun t ht idx => by rw [hr_mb1]; exact hrO t ht idx,
        ?_,
        fun s h hh hcond_sh => by
          have hp := hUnch s h hh (hcond_sh.imp (fun h1 => by omega) id)
          exact ⟨(hw_mb1 _ _).trans hp.1, fun c => (hr_mb1 _ _).trans (hp.2 c)⟩,
        fun v hv idx => by simp [mb1, ma1, hv, hlv_m v hv idx],
        fun v hv idx => by simp [mb1, ma1, hrlv_m v hv idx]⟩
      intro s hs_lt h6_pos
      rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hs_lt) with hlt | rfl
      · rcases hSavedLt s hlt h6_pos with ⟨h1, h2, h3⟩
        exact ⟨(hw_mb1 _ _).trans h1, fun e c => (hr_mb1 _ _).trans (h2 e c), fun e c => (hr_mb1 _ _).trans (h3 e c)⟩
      · have halready : wRead mem 11 (pairIdx : ℤ) = wRead mem 6 (s : ℤ) := by
          by_contra hne; exact hdo ⟨h6_pos, hne⟩
        have hp := hUnch s delH hdel_lt (Or.inl le_rfl)
        exact ⟨(hw_mb1 _ _).trans (hp.1.trans halready),
          fun _ c => (hr_mb1 _ _).trans (hp.2 c),
          fun hne => absurd halready hne⟩
  rcases DetExecAt.repeatN_nat (.lit (NumSlots : ℤ)) _ NumSlots 1 (120 * (d + 1)) Inv hInv0 rfl
      (by simp [intExprOps]) hStep with ⟨mN, hInvN, hrep⟩
  rcases hInvN with ⟨hSgN, _, hm21N, _, hwON, hrON, hSavedN, hUnchN, hlvN, hrlvN⟩
  refine ⟨mN, (hs1.seq (hexL.seq (hs3.seq hrep))).mono_cost (by
    have h1 : 8 + (25 * (d + 1) + (4 + (1 + NumSlots * (120 * (d + 1))))) =
        13 + 25 * (d + 1) + (120 * NumSlots) * (d + 1) := by ring
    have h2 : 13 ≤ 13 * (d + 1) := by omega
    have h3 : (38 + 120 * NumSlots) * (d + 1) ≤ (150 * (NumSlots + 1)) * (d + 1) :=
      Nat.mul_le_mul_right (d + 1) (by omega)
    rw [h1]; calc 13 + 25 * (d + 1) + (120 * NumSlots) * (d + 1)
        ≤ 13 * (d + 1) + 25 * (d + 1) + (120 * NumSlots) * (d + 1) := by omega
      _ = (38 + 120 * NumSlots) * (d + 1) := by ring
      _ ≤ 150 * (NumSlots + 1) * (d + 1) := h3),
    hSgN, ?_, hwON, hrON, hm21N, hlvN, hrlvN⟩
  intro s hs h6_pos S snapPts livePts' hlive_eq hSlot
  refine ⟨hSlot.1, Or.inr ⟨by rw [hwON 6 (by decide)]; exact h6_pos, fun h hhS => ?_⟩⟩
  have hh_lt : h < n := hSlot.1 h hhS
  rcases hSlot.2 with ⟨hw0, _, _⟩ | ⟨_, hall⟩
  · omega
  · rcases hall h hhS with ⟨h_if_eq, h_if_ne⟩
    rw [hwON 6 (by decide)]
    by_cases hh_del : h = delH
    · subst hh_del
      rcases hSavedN s hs h6_pos with ⟨hw11_now, hr_was_eq, hr_was_ne⟩
      refine ⟨fun _ c => ?_, fun hne => absurd hw11_now hne⟩
      by_cases hwas : wRead mem 11 ((s * n + h : ℕ) : ℤ) = wRead mem 6 (s : ℤ)
      · rw [hr_was_eq hwas c]; exact h_if_eq hwas c
      · rw [hr_was_ne hwas c, (h_if_ne hwas).2]
    · rcases hUnchN s h hh_lt (Or.inr hh_del) with ⟨hw11_eq, hr11_eq⟩
      rw [hw11_eq]
      refine ⟨fun heq c => by rw [hr11_eq c]; exact h_if_eq heq c, fun hne => ?_⟩
      rcases h_if_ne hne with ⟨hh_act, hsnap_eq⟩
      have hh_er : h ∈ activeH.erase delH := Finset.mem_erase.mpr ⟨hh_del, hh_act⟩
      exact ⟨hh_er, hsnap_eq.trans (hlive_eq h hh_er).symm⟩

/-! ### 4. HandlePool (`EncHandlePool` & `poolStepStmt`) and Pigeonhole Slot Allocator -/

def EncHandlePool (d n : ℕ) (mem : ArithRAMMemory) (P : DynamicPointSet d) : Prop :=
  EncLiveCoords d n mem P.activeHandles P.handleCoords ∧
  ∃ (hwm : ℕ) (freeSet : Finset ℕ),
    hwm ≤ n ∧
    wRead mem 1 0 = (hwm : ℤ) ∧
    wRead mem 1 1 = (freeSet.card : ℤ) ∧
    wRead mem 1 2 = (P.activeHandles.card : ℤ) ∧
    Disjoint P.activeHandles freeSet ∧
    P.activeHandles ∪ freeSet = Finset.range hwm ∧
    (∀ i < freeSet.card, ∃ fh ∈ freeSet, wRead mem 3 (i : ℤ) = (fh : ℤ)) ∧
    (∀ i < freeSet.card, ∀ j < freeSet.card, i ≠ j → wRead mem 3 (i : ℤ) ≠ wRead mem 3 (j : ℤ)) ∧
    (∀ h < n, wRead mem 2 (h : ℤ) = if h ∈ P.activeHandles then 1 else 0)

theorem encHandlePool_empty_init {d n : ℕ} {mem : ArithRAMMemory}
    (hw10 : wRead mem 1 0 = 0) (hw11 : wRead mem 1 1 = 0) (hw12 : wRead mem 1 2 = 0)
    (hw2 : ∀ h < n, wRead mem 2 (h : ℤ) = 0) :
    EncHandlePool d n mem (DynamicPointSet.empty d) := by
  refine ⟨⟨fun _ hh => by simp [DynamicPointSet.empty] at hh,
           fun _ hh => by simp [DynamicPointSet.empty] at hh⟩,
    0, ∅, Nat.zero_le n, hw10, by simpa using hw11,
    by simpa [DynamicPointSet.empty] using hw12,
    by simp, by simp [DynamicPointSet.empty],
    fun _ hi => by simp at hi,
    fun _ hi => by simp at hi,
    fun h hh => by simp [DynamicPointSet.empty, hw2 h hh]⟩

def loadExtraRealsToLocalStmt (d : ℕ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 29 (.lit 1) (.lit 0),
    .repeatN (.lit (d : ℤ)) (seqList [
      .writeRealLocal 29 (.readLocal 29 (.lit 1)) (.extraReal (.readLocal 29 (.lit 1))),
      .writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))
    ])
  ]

theorem boxSafe_loadExtraRealsToLocalStmt {T_max M_box : ℕ} (d : ℕ) :
    BoxSafeInner T_max M_box (loadExtraRealsToLocalStmt d) := by
  unfold loadExtraRealsToLocalStmt
  apply boxSafeInner_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · exact .writeWordLocal _ _ _
  · refine .repeatN _ (boxSafeInner_seqList ?_)
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl
    · exact .writeRealLocal _ _ _
    · exact .writeWordLocal _ _ _

theorem exec_loadExtraRealsToLocalStmt {d : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {pt : EuclideanSpace ℝ (Fin d)}
    (hextra : inp.extraReals = List.ofFn (fun i : Fin d => euclideanCoord pt i)) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (loadExtraRealsToLocalStmt d) mem mem' (20 * (d + 1)) ∧
      (∀ c : Fin d, rReadL 1 mem' 29 (c.val : ℤ) = euclideanCoord pt c) ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ idx, idx ≠ 1 → wReadL 1 mem' 29 idx = wReadL 1 mem 29 idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  let m1 := wWriteL 1 mem 29 1 0
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 1) (.lit 0)) mem m1 4 :=
    DetExecAt.writeWordLocal 1 inp mem 29 _ _ rfl rfl (by simp [intExprOps])
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    (∀ t idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t idx, rRead m t idx = rRead mem t idx) ∧
    wReadL 1 m 29 1 = (k : ℤ) ∧
    (∀ idx, idx ≠ 1 → wReadL 1 m 29 idx = wReadL 1 mem 29 idx) ∧
    (∀ c : Fin d, c.val < k → rReadL 1 m 29 (c.val : ℤ) = euclideanCoord pt c) ∧
    (∀ v, v ≠ 29 → ∀ idx, wReadL 1 m v idx = wReadL 1 mem v idx) ∧
    (∀ v, v ≠ 29 → ∀ idx, rReadL 1 m v idx = rReadL 1 mem v idx)
  have hInv0 : Inv 0 m1 := by
    refine ⟨fun _ _ => by simp [m1], fun _ _ => by simp [m1], by simp [m1],
      fun idx hi => by simp [m1, hi], fun _ hc => by omega,
      fun v hv _ => by simp [m1, hv], fun _ _ _ => by simp [m1]⟩
  have hStep : ∀ k < d, ∀ m, Inv k m →
      ∃ m', DetExecAt 1 inp
        (seqList [
          .writeRealLocal 29 (.readLocal 29 (.lit 1)) (.extraReal (.readLocal 29 (.lit 1))),
          .writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))
        ]) m m' 18 ∧ Inv (k + 1) m' := by
    intro k hk m ⟨hw_m, hr_m, hm1, hwl_m, hlo, hlv_m, hrlv_m⟩
    let ms1 := rWriteL 1 m 29 (k : ℤ) (euclideanCoord pt ⟨k, hk⟩)
    let ms2 := wWriteL 1 ms1 29 1 ((k + 1 : ℕ) : ℤ)
    have hb1 : DetExecAt 1 inp (.writeRealLocal 29 (.readLocal 29 (.lit 1)) (.extraReal (.readLocal 29 (.lit 1)))) m ms1 10 := by
      refine DetExecAt.writeRealLocal 1 inp m 29 _ _ (by simp [hm1]) ?_ (by simp [intExprOps, realExprOps])
      simp only [rValAt_extraReal, iValAt_readLocal, iValAt_lit, hm1, hextra]
      simp [listGetIntD, hk]
    have hb2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 1) (.add (.readLocal 29 (.lit 1)) (.lit 1))) ms1 ms2 8 := by
      refine DetExecAt.writeWordLocal 1 inp ms1 29 _ _ rfl ?_ (by simp [intExprOps])
      simp [ms1, wReadL_rWriteL, hm1]
    refine ⟨ms2, (hb1.seq hb2).mono_cost (by omega),
      fun _ _ => by simp [ms2, ms1, wRead_rWriteL, hw_m],
      fun _ _ => by simp [ms2, ms1, rRead_rWriteL, hr_m],
      by simp [ms2],
      fun idx hi => by simp [ms2, ms1, wReadL_rWriteL, hi, hwl_m idx hi],
      fun c hc => ?_,
      fun v hv _ => by simp [ms2, ms1, wReadL_rWriteL, hv, hlv_m v hv],
      fun v hv _ => by simp [ms2, ms1, hv, hrlv_m v hv]⟩
    rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hc) with hlt | heq
    · have hne_z : (c.val : ℤ) ≠ (k : ℤ) := by omega
      simp [ms2, ms1, hne_z, hlo c hlt]
    · have hc_eq : c = ⟨k, hk⟩ := Fin.ext heq
      subst hc_eq; simp [ms2, ms1]
  rcases DetExecAt.repeatN_nat (.lit (d : ℤ)) _ d 1 18 Inv hInv0 rfl (by simp [intExprOps]) hStep
    with ⟨md, ⟨hwd, hrd, _, hwld, hlod, hlvd, hrlvd⟩, hrep⟩
  exact ⟨md, (hs1.seq hrep).mono_cost (by omega), fun c => hlod c c.isLt, hwd, hrd, hwld, hlvd, hrlvd⟩

def poolStepStmt (d n NumSlots M_box : ℕ) : ArithRAMStmt :=
  .ite (.intEq (.intParam (.lit 1)) (.lit 1))
    -- Insert branch
    (seqList [
      .writeWordLocal 29 (.lit 6) (.readHeap 1 (.lit 1)),
      .writeWordLocal 29 (.lit 7) (.readHeap 1 (.lit 0)),
      .writeWordLocal 29 (.lit 8) (.readHeap 1 (.lit 2)),
      .ite (.intLe (.lit 1) (.readLocal 29 (.lit 6)))
        (seqList [
          .writeWordLocal 29 (.lit 6) (.sub (.readLocal 29 (.lit 6)) (.lit 1)),
          .writeWordLocal 29 (.lit 11) (.readHeap 3 (.readLocal 29 (.lit 6))),
          boxWriteW M_box 1 (.lit 1) (.readLocal 29 (.lit 6))
        ])
        (seqList [
          .writeWordLocal 29 (.lit 11) (.readLocal 29 (.lit 7)),
          boxWriteW M_box 1 (.lit 0) (.add (.readLocal 29 (.lit 7)) (.lit 1))
        ]),
      boxWriteW M_box 2 (.readLocal 29 (.lit 11)) (.lit 1),
      boxWriteW M_box 1 (.lit 2) (.add (.readLocal 29 (.lit 8)) (.lit 1)),
      boxWriteW M_box 0 (.lit 0) (.readLocal 29 (.lit 11)),
      loadExtraRealsToLocalStmt d,
      .writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 11)) (.lit (d : ℤ))),
      storeLocalCoordsToHeapStmt d M_box 4 5 0,
      .writeWordLocal 29 (.lit 10) (.lit 1)
    ])
    -- Delete branch
    (seqList [
      .writeWordLocal 29 (.lit 21) (.intParam (.lit 2)),
      copyOnDeleteStmt d n NumSlots M_box,
      .writeWordLocal 29 (.lit 11) (.readLocal 29 (.lit 21)),
      .writeWordLocal 29 (.lit 6) (.readHeap 1 (.lit 1)),
      .writeWordLocal 29 (.lit 8) (.readHeap 1 (.lit 2)),
      boxWriteW M_box 2 (.readLocal 29 (.lit 11)) (.lit 0),
      boxWriteW M_box 3 (.readLocal 29 (.lit 6)) (.readLocal 29 (.lit 11)),
      boxWriteW M_box 1 (.lit 1) (.add (.readLocal 29 (.lit 6)) (.lit 1)),
      boxWriteW M_box 1 (.lit 2) (.sub (.readLocal 29 (.lit 8)) (.lit 1)),
      .writeWordLocal 29 (.lit 10) (.lit 0)
    ])

theorem boxSafe_poolStepStmt {T_max M_box : ℕ} (hT : 12 ≤ T_max) (d n NumSlots : ℕ) :
    BoxSafeInner T_max M_box (poolStepStmt d n NumSlots M_box) := by
  unfold poolStepStmt
  refine .ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_)
  · intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · refine .ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_)
      · intro y hy; simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
        rcases hy with rfl | rfl | rfl
        · exact .writeWordLocal _ _ _
        · exact .writeWordLocal _ _ _
        · exact .boxW (by omega) _ _
      · intro y hy; simp only [List.mem_cons, List.not_mem_nil, or_false] at hy
        rcases hy with rfl | rfl
        · exact .writeWordLocal _ _ _
        · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact boxSafe_loadExtraRealsToLocalStmt d
    · exact .writeWordLocal _ _ _
    · exact boxSafe_storeLocalCoordsToHeapStmt d 4 (by omega) 5 0
    · exact .writeWordLocal _ _ _
  · intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact boxSafe_copyOnDeleteStmt hT d n NumSlots
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .writeWordLocal _ _ _

theorem exec_poolStepStmt {d n K NumSlots M_box : ℕ}
    (P : DynamicPointSet d) (op : DynamicUpdate d) (mem : ArithRAMMemory)
    (hP : P.WellFormed n)
    (hleg : IsLegalUpdate n Set.univ P op)
    (hPool : EncHandlePool d n mem P)
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem)
    (hBox1 : 4 ≤ M_box) (hBox_n : n ≤ M_box) (hBox_nd : n * d ≤ M_box)
    (hBox_sn : NumSlots * n ≤ M_box) (hBox_snd : NumSlots * n * d ≤ M_box) :
    let inp := mkStepInput n P op
    ∃ (mem' : ArithRAMMemory) (P' : DynamicPointSet d) (opH : ℕ),
      DetExecAt 1 inp (poolStepStmt d n NumSlots M_box) mem mem'
        (200 * (NumSlots + 1) * (d + 1) + 300) ∧
      applyDynamicUpdate P op (readStepRetH op mem') = some P' ∧
      P'.WellFormed n ∧
      EncHandlePool d n mem' P' ∧
      SegGenBound K NumSlots mem' ∧
      SaveGenBound n NumSlots mem' ∧
      opH < n ∧
      wReadL 1 mem' 29 11 = (opH : ℤ) ∧
      (match op with
       | .insert _ _ pt =>
           wReadL 1 mem' 29 10 = 1 ∧
           wRead mem' 0 0 = (opH : ℤ) ∧
           opH ∉ P.activeHandles ∧
           P'.activeHandles = insert opH P.activeHandles ∧
           P'.handleCoords opH = pt ∧
           (∀ h ∈ P.activeHandles, P'.handleCoords h = P.handleCoords h)
       | .delete id =>
           wReadL 1 mem' 29 10 = 0 ∧
           opH = P.handleOfId id ∧
           opH ∈ P.activeHandles ∧
           P'.activeHandles = P.activeHandles.erase opH ∧
           (∀ h ∈ P'.activeHandles, P'.handleCoords h = P.handleCoords h)) ∧
      (∀ s < NumSlots, 1 ≤ wRead mem 6 (s : ℤ) → ∀ S snapPts,
        EncSlotCoords d n mem P.activeHandles P.handleCoords s S snapPts →
        EncSlotCoords d n mem' P'.activeHandles P'.handleCoords s S snapPts) ∧
      (∀ t, t ≠ 0 → t ≠ 1 → t ≠ 2 → t ≠ 3 → t ≠ 11 → ∀ idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 0 → wRead mem' 0 idx = wRead mem 0 idx) ∧
      (∀ idx, idx ≠ 0 → idx ≠ 1 → idx ≠ 2 → wRead mem' 1 idx = wRead mem 1 idx) ∧
      (∀ t, t ≠ 4 → t ≠ 11 → ∀ idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  intro inp
  rcases hPool with ⟨hLive, hwm, freeSet, hhwm_le, hw10, hw11, hw12, hdisj, hunion, hstack_mem, hstack_inj, hw2_map⟩
  have hcard_eq : P.activeHandles.card = P.activeIds.card := activeHandles_card_eq_activeIds_card hP
  cases op with
  | insert newId extName pt =>
      rcases hleg with ⟨hid_not, hcard_ins, _⟩
      have hcond_top : cValAt 1 inp mem (.intEq (.intParam (.lit 1)) (.lit 1)) = true := by
        simp [inp, mkStepInput, toInternalUpdate, listGetIntD]
      have hextra_inp : inp.extraReals = List.ofFn (fun i : Fin d => euclideanCoord pt i) := by
        simp [inp, mkStepInput, toInternalUpdate]
      let m1 := wWriteL 1 mem 29 6 (freeSet.card : ℤ)
      let m2 := wWriteL 1 m1 29 7 (hwm : ℤ)
      let m3 := wWriteL 1 m2 29 8 (P.activeHandles.card : ℤ)
      have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 6) (.readHeap 1 (.lit 1))) mem m1 6 :=
        DetExecAt.writeWordLocal 1 inp mem 29 _ _ rfl (by simp [hw11]) (by simp [intExprOps])
      have hs2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 7) (.readHeap 1 (.lit 0))) m1 m2 6 :=
        DetExecAt.writeWordLocal 1 inp m1 29 _ _ rfl (by simp [m1, hw10]) (by simp [intExprOps])
      have hs3 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 8) (.readHeap 1 (.lit 2))) m2 m3 6 :=
        DetExecAt.writeWordLocal 1 inp m2 29 _ _ rfl (by simp [m2, m1, hw12]) (by simp [intExprOps])
      have hAlloc : ∃ (ma : ArithRAMMemory) (newH hwm' : ℕ) (freeSet' : Finset ℕ),
          DetExecAt 1 inp
            (.ite (.intLe (.lit 1) (.readLocal 29 (.lit 6)))
              (seqList [
                .writeWordLocal 29 (.lit 6) (.sub (.readLocal 29 (.lit 6)) (.lit 1)),
                .writeWordLocal 29 (.lit 11) (.readHeap 3 (.readLocal 29 (.lit 6))),
                boxWriteW M_box 1 (.lit 1) (.readLocal 29 (.lit 6))
              ])
              (seqList [
                .writeWordLocal 29 (.lit 11) (.readLocal 29 (.lit 7)),
                boxWriteW M_box 1 (.lit 0) (.add (.readLocal 29 (.lit 7)) (.lit 1))
              ])) m3 ma 45 ∧
          hwm' ≤ n ∧ newH < hwm' ∧ newH ∉ P.activeHandles ∧
          Disjoint (insert newH P.activeHandles) freeSet' ∧
          insert newH P.activeHandles ∪ freeSet' = Finset.range hwm' ∧
          wRead ma 1 0 = (hwm' : ℤ) ∧
          wRead ma 1 1 = (freeSet'.card : ℤ) ∧
          (∀ idx, idx ≠ 0 → idx ≠ 1 → wRead ma 1 idx = wRead mem 1 idx) ∧
          (∀ t, t ≠ 1 → ∀ idx, wRead ma t idx = wRead mem t idx) ∧
          (∀ t idx, rRead ma t idx = rRead mem t idx) ∧
          (∀ i < freeSet'.card, ∃ fh ∈ freeSet', wRead ma 3 (i : ℤ) = (fh : ℤ)) ∧
          (∀ i < freeSet'.card, ∀ j < freeSet'.card, i ≠ j → wRead ma 3 (i : ℤ) ≠ wRead ma 3 (j : ℤ)) ∧
          wReadL 1 ma 29 11 = (newH : ℤ) ∧
          wReadL 1 ma 29 8 = (P.activeHandles.card : ℤ) ∧
          (∀ v, v ≠ 29 → ∀ idx, wReadL 1 ma v idx = wReadL 1 mem v idx) ∧
          (∀ v, v ≠ 29 → ∀ idx, rReadL 1 ma v idx = rReadL 1 mem v idx) := by
        by_cases hfl_pos : 1 ≤ freeSet.card
        · have hc : cValAt 1 inp m3 (.intLe (.lit 1) (.readLocal 29 (.lit 6))) = true := by
            simp only [cValAt_intLe, iValAt_lit, iValAt_readLocal, m3, m2, m1, wReadL_wWriteL_eq, decide_eq_true_eq]
            simpa using (show (1 : ℤ) ≤ (freeSet.card : ℤ) from by exact_mod_cast hfl_pos)
          let topIdx := freeSet.card - 1
          rcases hstack_mem topIdx (by omega) with ⟨newH, hnew_in_free, hnew_val⟩
          have hnew_lt_hwm : newH < hwm := by
            have : newH ∈ P.activeHandles ∪ freeSet := Finset.mem_union_right _ hnew_in_free
            rw [hunion] at this; exact Finset.mem_range.mp this
          have hnew_not_act : newH ∉ P.activeHandles := Finset.disjoint_right.mp hdisj hnew_in_free
          let ma1 := wWriteL 1 m3 29 6 (topIdx : ℤ)
          let ma2 := wWriteL 1 ma1 29 11 (newH : ℤ)
          let ma3 := wWrite ma2 1 1 (topIdx : ℤ)
          have hb1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 6) (.sub (.readLocal 29 (.lit 6)) (.lit 1))) m3 ma1 8 := by
            refine DetExecAt.writeWordLocal 1 inp m3 29 _ _ rfl ?_ (by simp [intExprOps])
            simp only [iValAt_sub, iValAt_readLocal, iValAt_lit, m3, m2, m1, wReadL_wWriteL_eq]; simp; omega
          have hb2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 11) (.readHeap 3 (.readLocal 29 (.lit 6)))) ma1 ma2 8 := by
            refine DetExecAt.writeWordLocal 1 inp ma1 29 _ _ rfl ?_ (by simp [intExprOps])
            simp [ma1, m3, m2, m1, hnew_val]
          have hb3 : DetExecAt 1 inp (boxWriteW M_box 1 (.lit 1) (.readLocal 29 (.lit 6))) ma2 ma3 14 :=
            exec_boxWriteW inp ma2 _ _ rfl (by omega) (by omega) (by simp [ma2, ma1]) (by simp [intExprOps])
          let freeSet' := freeSet.erase newH
          have hcard_free' : freeSet'.card = topIdx := Finset.card_erase_of_mem hnew_in_free
          refine ⟨ma3, newH, hwm, freeSet',
            (DetExecAt.ite_true hc (C_c := 8) (by simp [condExprOps, intExprOps]) (hb1.seq (hb2.seq hb3))).mono_cost (by omega),
            hhwm_le, hnew_lt_hwm, hnew_not_act, ?_, ?_,
            by simp [ma3, ma2, ma1, m3, m2, m1, hw10],
            by simp [ma3, hcard_free'],
            fun idx _ h1 => by simp [ma3, ma2, ma1, m3, m2, m1, h1],
            fun t ht idx => by simp [ma3, ma2, ma1, m3, m2, m1, ht],
            fun _ _ => by simp [ma3, ma2, ma1, m3, m2, m1],
            ?_, ?_,
            by simp [ma3, ma2],
            by simp [ma3, ma2, ma1, m3],
            fun v hv _ => by simp [ma3, ma2, ma1, m3, m2, m1, hv],
            fun _ _ _ => by simp [ma3, ma2, ma1, m3, m2, m1]⟩
          · rw [Finset.disjoint_left]
            intro x hx hxF
            rcases Finset.mem_insert.mp hx with rfl | hxA
            · exact (Finset.mem_erase.mp hxF).1 rfl
            · exact Finset.disjoint_left.mp hdisj hxA (Finset.mem_of_mem_erase hxF)
          · ext x; simp only [Finset.mem_union, Finset.mem_insert, freeSet', Finset.mem_erase, ← hunion]
            by_cases hxn : x = newH
            · subst hxn; simp [hnew_in_free]
            · simp [hxn]
          · intro i hi
            rw [hcard_free'] at hi
            rcases hstack_mem i (by omega) with ⟨fh, hfh, hfh_val⟩
            have hfh_ne : fh ≠ newH := by
              rintro rfl
              exact hstack_inj i (by omega) topIdx (by omega) (by omega) (hfh_val.trans hnew_val.symm)
            exact ⟨fh, Finset.mem_erase.mpr ⟨hfh_ne, hfh⟩, by simp [ma3, ma2, ma1, m3, m2, m1, hfh_val]⟩
          · intro i hi j hj hij
            rw [hcard_free'] at hi hj
            simp only [ma3, ma2, ma1, m3, m2, m1, wRead_wWrite_eq, wRead_wWriteL]; simp
            exact hstack_inj i (by omega) j (by omega) hij
        · have hfl_0 : freeSet.card = 0 := by omega
          have hfree_emp : freeSet = ∅ := Finset.card_eq_zero.mp hfl_0
          have hc : cValAt 1 inp m3 (.intLe (.lit 1) (.readLocal 29 (.lit 6))) = false := by
            simp only [cValAt_intLe, iValAt_lit, iValAt_readLocal, m3, m2, m1, wReadL_wWriteL_eq, hfl_0, decide_eq_false_iff_not]
            simp
          have hact_eq_range : P.activeHandles = Finset.range hwm := by
            simpa [hfree_emp] using hunion
          have hhwm_eq_card : hwm = P.activeHandles.card := by
            rw [hact_eq_range, Finset.card_range]
          have hhwm_lt_n : hwm < n := by rw [hhwm_eq_card, hcard_eq]; omega
          let ma1 := wWriteL 1 m3 29 11 (hwm : ℤ)
          let ma2 := wWrite ma1 1 0 ((hwm + 1 : ℕ) : ℤ)
          have hb1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 11) (.readLocal 29 (.lit 7))) m3 ma1 6 :=
            DetExecAt.writeWordLocal 1 inp m3 29 _ _ rfl (by simp [m3, m2]) (by simp [intExprOps])
          have hb2 : DetExecAt 1 inp (boxWriteW M_box 1 (.lit 0) (.add (.readLocal 29 (.lit 7)) (.lit 1))) ma1 ma2 14 :=
            exec_boxWriteW inp ma1 _ _ rfl (by omega) (by omega) (by simp [ma1, m3, m2]) (by simp [intExprOps])
          refine ⟨ma2, hwm, hwm + 1, ∅,
            (DetExecAt.ite_false hc (C_c := 8) (by simp [condExprOps, intExprOps]) (hb1.seq hb2)).mono_cost (by omega),
            by omega, by omega, by rw [hact_eq_range]; simp,
            by simp,
            by rw [hact_eq_range, Finset.union_empty, Finset.range_add_one],
            by simp [ma2],
            by simp [ma2, ma1, m3, m2, m1, hw11, hfree_emp],
            fun idx h0 _ => by simp [ma2, ma1, m3, m2, m1, h0],
            fun t ht idx => by simp [ma2, ma1, m3, m2, m1, ht],
            fun _ _ => by simp [ma2, ma1, m3, m2, m1],
            fun _ hi => by simp at hi,
            fun _ hi => by simp at hi,
            by simp [ma2, ma1],
            by simp [ma2, ma1, m3],
            fun v hv _ => by simp [ma2, ma1, m3, m2, m1, hv],
            fun _ _ _ => by simp [ma2, ma1, m3, m2, m1]⟩
      rcases hAlloc with ⟨ma, newH, hwm', freeSet', hexA, hhwm'_le, hnew_lt_hwm', hnew_not_act,
        hdisj', hunion', hma10, hma11, hma1_o, hma_t, hma_r, hst_m', hst_i', hma_l11, hma_l8, hma_lv, hma_rlv⟩
      have hnew_lt_n : newH < n := lt_of_lt_of_le hnew_lt_hwm' hhwm'_le
      let mb1 := wWrite ma 2 (newH : ℤ) 1
      let mb2 := wWrite mb1 1 2 ((P.activeHandles.card + 1 : ℕ) : ℤ)
      let mb3 := wWrite mb2 0 0 (newH : ℤ)
      have hw_b1 : DetExecAt 1 inp (boxWriteW M_box 2 (.readLocal 29 (.lit 11)) (.lit 1)) ma mb1 14 :=
        exec_boxWriteW inp ma _ _ (by simp [hma_l11]) (by omega) (by omega) rfl (by simp [intExprOps])
      have hw_b2 : DetExecAt 1 inp (boxWriteW M_box 1 (.lit 2) (.add (.readLocal 29 (.lit 8)) (.lit 1))) mb1 mb2 14 :=
        exec_boxWriteW inp mb1 _ _ rfl (by omega) (by omega)
          (by simp [mb1, hma_l8]) (by simp [intExprOps])
      have hw_b3 : DetExecAt 1 inp (boxWriteW M_box 0 (.lit 0) (.readLocal 29 (.lit 11))) mb2 mb3 14 :=
        exec_boxWriteW inp mb2 _ _ rfl (by omega) (by omega) (by simp [mb2, mb1, hma_l11]) (by simp [intExprOps])
      rcases exec_loadExtraRealsToLocalStmt inp mb3 hextra_inp
        with ⟨mb4, hexEx, hpt_loc, hw_b4, hr_b4, hwl_b4, hlv_b4, hrlv_b4⟩
      let mb5 := wWriteL 1 mb4 29 5 ((newH * d : ℕ) : ℤ)
      have hw_b5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 5) (.mul (.readLocal 29 (.lit 11)) (.lit (d : ℤ)))) mb4 mb5 8 := by
        refine DetExecAt.writeWordLocal 1 inp mb4 29 _ _ rfl ?_ (by simp [intExprOps])
        simp only [iValAt_mul, iValAt_readLocal, iValAt_lit, hwl_b4 11 (by decide), mb3, mb2, mb1, wReadL_wWrite, hma_l11]
        push_cast; rfl
      have hnd_box : newH * d + d ≤ M_box := by
        calc newH * d + d = (newH + 1) * d := by ring
          _ ≤ n * d := Nat.mul_le_mul_right _ hnew_lt_n
          _ ≤ M_box := hBox_nd
      rcases exec_storeLocalCoordsToHeapStmt inp mb5 (rTag := 4) (idxBase := 5) (srcOff := 0) (base := newH * d) (pt := pt)
          (by decide) (by simp [mb5]) hnd_box (fun c => by simpa [mb5] using hpt_loc c)
        with ⟨mb6, hexSt, hst_c, hst_out, hst_rt, hst_w, hst_wl, _, hst_lv, hst_rlv⟩
      let mb7 := wWriteL 1 mb6 29 10 1
      have hw_b7 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 10) (.lit 1)) mb6 mb7 4 :=
        DetExecAt.writeWordLocal 1 inp mb6 29 _ _ rfl rfl (by simp [intExprOps])
      have hret_eq : readStepRetH (.insert newId extName pt) mb7 = some newH := by
        have hw00 : wRead mb7 0 0 = (newH : ℤ) := by
          simp [mb7, hst_w, mb5, hw_b4, mb3]
        simp [readStepRetH, ArithRAMDynamicProgram.readReturnedHandle, wRead] at hw00 ⊢
        rw [hw00]; simp
      let P' : DynamicPointSet d :=
        { activeIds := insert newId P.activeIds
          coords := Function.update P.coords newId pt
          activeHandles := insert newH P.activeHandles
          handleOfId := Function.update P.handleOfId newId newH
          idOfHandle := Function.update P.idOfHandle newH newId
          nextLifetime := P.nextLifetime + 1
          lifetimeOfId := Function.update P.lifetimeOfId newId P.nextLifetime }
      have happ : applyDynamicUpdate P (.insert newId extName pt)
          (readStepRetH (.insert newId extName pt) mb7) = some P' := by
        rw [hret_eq]
        simp [applyDynamicUpdate, hid_not, hnew_not_act, P']
      have hleg_ins : IsLegalUpdate n Set.univ P (.insert newId extName pt) := ⟨hid_not, hcard_ins, Set.mem_univ pt⟩
      have hP'_wf : P'.WellFormed n := applyDynamicUpdate_wellFormed hP hleg_ins happ
      have hhc_new : P'.handleCoords newH = pt := by
        simp [DynamicPointSet.handleCoords, P', Function.update]
      have hhc_old : ∀ h ∈ P.activeHandles, P'.handleCoords h = P.handleCoords h := by
        intro h hh
        have hne : h ≠ newH := fun heq => hnew_not_act (heq ▸ hh)
        have hid_ne : P.idOfHandle h ≠ newId := fun heq => hid_not (heq ▸ (hP.2.2.1 h hh).1)
        simp [DynamicPointSet.handleCoords, P', hh, hne, hid_ne]
      have hout_newH : ∀ h : ℕ, h ≠ newH → ∀ c : Fin d,
          (((h * d + c.val : ℕ) : ℤ) < ((newH * d : ℕ) : ℤ) ∨
           ((newH * d + d : ℕ) : ℤ) ≤ ((h * d + c.val : ℕ) : ℤ)) := by
        intro h hne c
        rcases lt_trichotomy h newH with hlt | rfl | hgt
        · left
          have : h * d + c.val < newH * d := by
            calc h * d + c.val < h * d + d := by omega
              _ = (h + 1) * d := by ring
              _ ≤ newH * d := Nat.mul_le_mul_right _ hlt
          exact_mod_cast this
        · exact absurd rfl hne
        · right
          have : newH * d + d ≤ h * d + c.val := by
            calc newH * d + d = (newH + 1) * d := by ring
              _ ≤ h * d := Nat.mul_le_mul_right _ hgt
              _ ≤ h * d + c.val := Nat.le_add_right _ _
          exact_mod_cast this
      have hw13_mb7 : wRead mb7 1 3 = wRead mem 1 3 := by
        simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hma1_o 3 (by decide) (by decide)]
      refine ⟨mb7, P', newH,
        (DetExecAt.ite_true hcond_top (C_c := 8) (by simp [condExprOps, intExprOps])
          (hs1.seq (hs2.seq (hs3.seq (hexA.seq (hw_b1.seq (hw_b2.seq (hw_b3.seq
            (hexEx.seq (hw_b5.seq (hexSt.seq hw_b7))))))))))).mono_cost (by
              have h1 : 65 * (d + 1) ≤ (200 * (NumSlots + 1)) * (d + 1) :=
                Nat.mul_le_mul_right (d + 1) (by omega)
              have h2 : 20 * (d + 1) + 45 * (d + 1) = 65 * (d + 1) := by ring
              omega),
        happ, hP'_wf, ?_, ?_, ?_, hnew_lt_n, ?_,
        ⟨by simp [mb7], by simp [mb7, hst_w, mb5, hw_b4, mb3], hnew_not_act, rfl, hhc_new, hhc_old⟩,
        ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · refine ⟨⟨fun h hh => ?_, fun h hh c => ?_⟩,
          hwm', freeSet', hhwm'_le,
          by simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hma10],
          by simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hma11],
          by simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, P', Finset.card_insert_of_notMem hnew_not_act],
          hdisj', hunion',
          fun i hi => by
            rcases hst_m' i hi with ⟨fh, hfh, hval⟩
            exact ⟨fh, hfh, by simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hval]⟩,
          fun i hi j hj hij => by
            simp only [mb7, wRead_wWriteL, hst_w, mb5, hw_b4, mb3, mb2, mb1, wRead_wWrite_eq]; simp
            exact hst_i' i hi j hj hij,
          fun h hh => ?_⟩
        · rcases Finset.mem_insert.mp hh with rfl | hh_old
          · exact hnew_lt_n
          · exact hLive.1 h hh_old
        · rcases Finset.mem_insert.mp hh with rfl | hh_old
          · rw [hhc_new]; simp only [mb7, rRead_wWriteL]; exact hst_c c
          · have hne : h ≠ newH := fun heq => hnew_not_act (heq ▸ hh_old)
            rw [hhc_old h hh_old]
            simp only [mb7, rRead_wWriteL, hst_out _ (hout_newH h hne c), mb5, hr_b4, mb3, mb2, mb1, rRead_wWrite, hma_r]
            exact hLive.2 h hh_old c
        · by_cases heq : h = newH
          · subst heq; simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, P']
          · have hne_z : (h : ℤ) ≠ (newH : ℤ) := by omega
            simp only [mb7, wRead_wWriteL, hst_w, mb5, hw_b4, mb3, mb2, mb1, wRead_wWrite_eq]
            simp [hne_z, hma_t 2 (by decide), hw2_map h hh, P', heq]
      · have hw5_all : ∀ idx, wRead mb7 5 idx = wRead mem 5 idx := by
          intro idx; simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hma_t 5 (by decide)]
        have hw8_all : ∀ idx, wRead mb7 8 idx = wRead mem 8 idx := by
          intro idx; simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hma_t 8 (by decide)]
        simpa [SegGenBound, hw13_mb7, hw5_all, hw8_all] using hseg
      · have hw6_all : ∀ idx, wRead mb7 6 idx = wRead mem 6 idx := by
          intro idx; simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hma_t 6 (by decide)]
        have hw11_all : ∀ idx, wRead mb7 11 idx = wRead mem 11 idx := by
          intro idx; simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hma_t 11 (by decide)]
        simpa [SaveGenBound, hw13_mb7, hw6_all, hw11_all] using hsave
      · simp only [mb7, wReadL_wWriteL_eq, hst_wl 11 (by decide), mb5, hwl_b4 11 (by decide),
          mb3, mb2, mb1, wReadL_wWrite, hma_l11]; simp
      · intro s _ h6_pos S snapPts hSlot
        have hw6_s : wRead mb7 6 (s : ℤ) = wRead mem 6 (s : ℤ) := by
          simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hma_t 6 (by decide)]
        have hw11_all : ∀ idx, wRead mb7 11 idx = wRead mem 11 idx := by
          intro idx; simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hma_t 11 (by decide)]
        have hr11_all : ∀ idx, rRead mb7 11 idx = rRead mem 11 idx := by
          intro idx; simp [mb7, hst_rt 11 (by decide), mb5, hr_b4, mb3, mb2, mb1, hma_r]
        refine ⟨hSlot.1, Or.inr ⟨by rw [hw6_s]; exact h6_pos, fun h hhS => ?_⟩⟩
        rcases hSlot.2 with ⟨hw0, _, _⟩ | ⟨_, hall⟩
        · omega
        · rcases hall h hhS with ⟨heq_c, hne_c⟩
          rw [hw6_s, hw11_all]
          refine ⟨fun heq c => by rw [hr11_all]; exact heq_c heq c, fun hne => ?_⟩
          rcases hne_c hne with ⟨hh_act, hsnap⟩
          exact ⟨Finset.mem_insert_of_mem hh_act, hsnap.trans (hhc_old h hh_act).symm⟩
      · intro t ht0 ht1 ht2 _ _ idx
        simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, ht0, ht1, ht2, hma_t t ht1 idx]
      · intro idx hi; simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, hi, hma_t 0 (by decide) idx]
      · intro idx h0 h1 h2
        simp [mb7, hst_w, mb5, hw_b4, mb3, mb2, mb1, h2, hma1_o idx h0 h1]
      · intro t ht4 _ idx
        simp [mb7, hst_rt t ht4 idx, mb5, hr_b4, mb3, mb2, mb1, hma_r]
      · intro v hv idx
        simp [mb7, hv, hst_lv v hv idx, mb5, hlv_b4 v hv idx, mb3, mb2, mb1, hma_lv v hv idx]
      · intro v hv idx
        simp [mb7, hst_rlv v hv idx, mb5, hrlv_b4 v hv idx, mb3, mb2, mb1, hma_rlv v hv idx]
  | delete id =>
      have hid_in : id ∈ P.activeIds := hleg
      let delH := P.handleOfId id
      have hdel_in : delH ∈ P.activeHandles := (hP.2.1 id hid_in).1
      have hdel_lt : delH < n := hLive.1 delH hdel_in
      have hdel_lt_hwm : delH < hwm := by
        have : delH ∈ P.activeHandles ∪ freeSet := Finset.mem_union_left _ hdel_in
        rw [hunion] at this; exact Finset.mem_range.mp this
      have hdel_not_free : delH ∉ freeSet := Finset.disjoint_left.mp hdisj hdel_in
      have hcard_pos : 1 ≤ P.activeHandles.card := Finset.card_pos.mpr ⟨delH, hdel_in⟩
      have hfl_lt_n : freeSet.card < n := by
        have hsub : freeSet ⊆ (Finset.range hwm).erase delH := by
          intro fh hfh
          exact Finset.mem_erase.mpr ⟨fun heq => hdel_not_free (heq ▸ hfh),
            hunion ▸ Finset.mem_union_right _ hfh⟩
        have hle := Finset.card_le_card hsub
        rw [Finset.card_erase_of_mem (Finset.mem_range.mpr hdel_lt_hwm), Finset.card_range] at hle
        omega
      have hcond_top : cValAt 1 inp mem (.intEq (.intParam (.lit 1)) (.lit 1)) = false := by
        simp [inp, mkStepInput, toInternalUpdate, listGetIntD]
      let m1 := wWriteL 1 mem 29 21 (delH : ℤ)
      have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 21) (.intParam (.lit 2))) mem m1 6 := by
        refine DetExecAt.writeWordLocal 1 inp mem 29 _ _ rfl ?_ (by simp [intExprOps])
        simp [inp, mkStepInput, toInternalUpdate, listGetIntD, delH]
      have hsave_m1 : SaveGenBound n NumSlots m1 := by simpa [SaveGenBound, m1] using hsave
      have hLive_m1 : EncLiveCoords d n m1 P.activeHandles P.handleCoords := by
        simpa [EncLiveCoords, m1] using hLive
      rcases exec_copyOnDeleteStmt inp m1 hdel_in hdel_lt (by simp [m1]) hBox_sn hBox_snd hsave_m1 hLive_m1
        with ⟨m2, hexCopy, hsave2, hSlot2, hw2, hr2, hm21_2, hlv2, hrlv2⟩
      let m3 := wWriteL 1 m2 29 11 (delH : ℤ)
      let m4 := wWriteL 1 m3 29 6 (freeSet.card : ℤ)
      let m5 := wWriteL 1 m4 29 8 (P.activeHandles.card : ℤ)
      let m6 := wWrite m5 2 (delH : ℤ) 0
      let m7 := wWrite m6 3 (freeSet.card : ℤ) (delH : ℤ)
      let m8 := wWrite m7 1 1 ((freeSet.card + 1 : ℕ) : ℤ)
      let m9 := wWrite m8 1 2 (((P.activeHandles.card - 1 : ℕ)) : ℤ)
      let m10 := wWriteL 1 m9 29 10 0
      have hs3 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 11) (.readLocal 29 (.lit 21))) m2 m3 6 :=
        DetExecAt.writeWordLocal 1 inp m2 29 _ _ rfl (by simp [hm21_2]) (by simp [intExprOps])
      have hs4 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 6) (.readHeap 1 (.lit 1))) m3 m4 6 :=
        DetExecAt.writeWordLocal 1 inp m3 29 _ _ rfl
          (by simp [m3, hw2 1 (by decide), m1, hw11]) (by simp [intExprOps])
      have hs5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 8) (.readHeap 1 (.lit 2))) m4 m5 6 :=
        DetExecAt.writeWordLocal 1 inp m4 29 _ _ rfl
          (by simp [m4, m3, hw2 1 (by decide), m1, hw12]) (by simp [intExprOps])
      have hs6 : DetExecAt 1 inp (boxWriteW M_box 2 (.readLocal 29 (.lit 11)) (.lit 0)) m5 m6 14 :=
        exec_boxWriteW inp m5 _ _ (by simp [m5, m4, m3]) (by omega) (by omega) rfl (by simp [intExprOps])
      have hs7 : DetExecAt 1 inp (boxWriteW M_box 3 (.readLocal 29 (.lit 6)) (.readLocal 29 (.lit 11))) m6 m7 14 :=
        exec_boxWriteW inp m6 _ _ (by simp [m6, m5, m4]) (by omega) (by omega)
          (by simp [m6, m5, m4, m3]) (by simp [intExprOps])
      have hs8 : DetExecAt 1 inp (boxWriteW M_box 1 (.lit 1) (.add (.readLocal 29 (.lit 6)) (.lit 1))) m7 m8 14 :=
        exec_boxWriteW inp m7 _ _ rfl (by omega) (by omega) (by simp [m7, m6, m5, m4]) (by simp [intExprOps])
      have hs9 : DetExecAt 1 inp (boxWriteW M_box 1 (.lit 2) (.sub (.readLocal 29 (.lit 8)) (.lit 1))) m8 m9 14 := by
        refine exec_boxWriteW inp m8 _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
        simp only [iValAt_sub, iValAt_readLocal, iValAt_lit, m8, m7, m6, m5,
          wReadL_wWrite, wReadL_wWriteL_self]
        omega
      have hs10 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 10) (.lit 0)) m9 m10 4 :=
        DetExecAt.writeWordLocal 1 inp m9 29 _ _ rfl rfl (by simp [intExprOps])
      let P' : DynamicPointSet d :=
        { activeIds := P.activeIds.erase id
          coords := Function.update P.coords id 0
          activeHandles := P.activeHandles.erase delH
          handleOfId := Function.update P.handleOfId id 0
          idOfHandle := Function.update P.idOfHandle delH 0
          nextLifetime := P.nextLifetime
          lifetimeOfId := Function.update P.lifetimeOfId id 0 }
      have happ : applyDynamicUpdate P (.delete id) (readStepRetH (d := d) (.delete id) m10) = some P' := by
        simp [readStepRetH, applyDynamicUpdate, hid_in, P', delH]
      have hP'_wf : P'.WellFormed n := applyDynamicUpdate_wellFormed hP hleg happ
      have hhc_er : ∀ h ∈ P.activeHandles.erase delH, P'.handleCoords h = P.handleCoords h := by
        intro h hh
        rcases Finset.mem_erase.mp hh with ⟨hne, hh_old⟩
        have hid_ne : P.idOfHandle h ≠ id := by
          intro heq
          have := congrArg P.handleOfId heq
          rw [(hP.2.2.1 h hh_old).2] at this
          exact hne this
        simp [DynamicPointSet.handleCoords, P', hh_old, hne, hid_ne]
      let freeSet' := insert delH freeSet
      have hcard_free' : freeSet'.card = freeSet.card + 1 :=
        Finset.card_insert_of_notMem hdel_not_free
      refine ⟨m10, P', delH,
        (DetExecAt.ite_false hcond_top (C_c := 8) (by simp [condExprOps, intExprOps])
          (hs1.seq (hexCopy.seq (hs3.seq (hs4.seq (hs5.seq (hs6.seq (hs7.seq (hs8.seq (hs9.seq hs10)))))))))).mono_cost (by
              have h1 : (150 * (NumSlots + 1)) * (d + 1) ≤ (200 * (NumSlots + 1)) * (d + 1) :=
                Nat.mul_le_mul_right (d + 1) (by omega)
              omega),
        happ, hP'_wf, ?_, ?_, ?_, hdel_lt,
        by simp [m10, m9, m8, m7, m6, m5, m4, m3],
        ⟨by simp [m10], rfl, hdel_in, rfl, hhc_er⟩,
        ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · -- EncHandlePool d n m10 P'
        refine ⟨⟨fun h hh => hLive.1 h (Finset.mem_of_mem_erase hh),
          fun h hh c => by
            rw [hhc_er h hh]
            simp only [m10, m9, m8, m7, m6, m5, m4, m3, rRead_wWriteL, rRead_wWrite, hr2 4 (by decide), m1]
            exact hLive.2 h (Finset.mem_of_mem_erase hh) c⟩,
          hwm, freeSet', hhwm_le,
          by simp [m10, m9, m8, m7, m6, m5, m4, m3, hw2 1 (by decide), m1, hw10],
          by simp [m10, m9, m8, hcard_free'],
          by simp [m10, m9, P', Finset.card_erase_of_mem hdel_in],
          ?_, ?_, ?_, ?_, ?_⟩
        · rw [Finset.disjoint_left]
          intro x hxA hxF
          rcases Finset.mem_erase.mp hxA with ⟨hne, hx_old⟩
          rcases Finset.mem_insert.mp hxF with rfl | hx_f
          · exact hne rfl
          · exact Finset.disjoint_left.mp hdisj hx_old hx_f
        · ext x; simp only [P', freeSet', Finset.mem_union, Finset.mem_erase, Finset.mem_insert, ← hunion]
          by_cases hxd : x = delH
          · subst hxd; simp [hdel_in]
          · simp [hxd]
        · intro i hi
          rw [hcard_free'] at hi
          rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hi) with hlt | rfl
          · rcases hstack_mem i hlt with ⟨fh, hfh, hval⟩
            have hne_z : (i : ℤ) ≠ (freeSet.card : ℤ) := by omega
            exact ⟨fh, Finset.mem_insert_of_mem hfh,
              by simp only [m10, m9, m8, m7, m6, m5, m4, m3, wRead_wWriteL, wRead_wWrite_eq];
                 simp [hne_z, hw2 3 (by decide), m1, hval]⟩
          · exact ⟨delH, Finset.mem_insert_self _ _,
              by simp [m10, m9, m8, m7]⟩
        · intro i hi j hj hij
          rw [hcard_free'] at hi hj
          simp only [m10, m9, m8, m7, m6, m5, m4, m3, wRead_wWriteL, wRead_wWrite_eq]
          by_cases hi_top : i = freeSet.card
          · subst hi_top
            have hj_lt : j < freeSet.card := by omega
            have hj_ne : (j : ℤ) ≠ (freeSet.card : ℤ) := by omega
            rcases hstack_mem j hj_lt with ⟨fh, hfh, hval⟩
            have hfh_ne : (delH : ℤ) ≠ (fh : ℤ) := by
              intro heq; exact hdel_not_free ((Int.ofNat.inj heq) ▸ hfh)
            simp [hj_ne, hw2 3 (by decide), m1, hval, hfh_ne]
          · have hi_lt : i < freeSet.card := by omega
            have hi_ne : (i : ℤ) ≠ (freeSet.card : ℤ) := by omega
            by_cases hj_top : j = freeSet.card
            · subst hj_top
              rcases hstack_mem i hi_lt with ⟨fh, hfh, hval⟩
              have hfh_ne : (fh : ℤ) ≠ (delH : ℤ) := by
                intro heq; exact hdel_not_free ((Int.ofNat.inj heq).symm ▸ hfh)
              simp [hi_ne, hw2 3 (by decide), m1, hval, hfh_ne]
            · have hj_lt : j < freeSet.card := by omega
              have hj_ne : (j : ℤ) ≠ (freeSet.card : ℤ) := by omega
              simp [hi_ne, hj_ne, hw2 3 (by decide), m1]
              exact hstack_inj i hi_lt j hj_lt hij
        · intro h hh
          by_cases heq : h = delH
          · subst heq; simp [m10, m9, m8, m7, m6, P']
          · have hne_z : (h : ℤ) ≠ (delH : ℤ) := by omega
            simp only [m10, m9, m8, m7, m6, m5, m4, m3, wRead_wWriteL, wRead_wWrite_eq]
            simp [hne_z, hw2 2 (by decide), m1, hw2_map h hh, P', heq]
      · -- SegGenBound
        have hw13 : wRead m10 1 3 = wRead mem 1 3 := by
          simp [m10, m9, m8, m7, m6, m5, m4, m3, hw2 1 (by decide), m1]
        have hw5_all : ∀ idx, wRead m10 5 idx = wRead mem 5 idx := by
          intro idx; simp [m10, m9, m8, m7, m6, m5, m4, m3, hw2 5 (by decide), m1]
        have hw8_all : ∀ idx, wRead m10 8 idx = wRead mem 8 idx := by
          intro idx; simp [m10, m9, m8, m7, m6, m5, m4, m3, hw2 8 (by decide), m1]
        simpa [SegGenBound, hw13, hw5_all, hw8_all] using hseg
      · -- SaveGenBound
        have hw13 : wRead m10 1 3 = wRead m2 1 3 := by simp [m10, m9, m8, m7, m6, m5, m4, m3]
        have hw6_all : ∀ idx, wRead m10 6 idx = wRead m2 6 idx := by intro idx; simp [m10, m9, m8, m7, m6, m5, m4, m3]
        have hw11_all : ∀ idx, wRead m10 11 idx = wRead m2 11 idx := by intro idx; simp [m10, m9, m8, m7, m6, m5, m4, m3]
        simpa [SaveGenBound, hw13, hw6_all, hw11_all] using hsave2
      · -- Frozen EncSlotCoords preserved on delete
        intro s hs h6_pos S snapPts hSlot
        have hSlot_m1 : EncSlotCoords d n m1 P.activeHandles P.handleCoords s S snapPts := by
          simpa [EncSlotCoords, m1] using hSlot
        have hSlot_m2 := hSlot2 s hs (by simpa [m1] using h6_pos) S snapPts P'.handleCoords hhc_er hSlot_m1
        have hw6_eq : wRead m10 6 (s : ℤ) = wRead m2 6 (s : ℤ) := by simp [m10, m9, m8, m7, m6, m5, m4, m3]
        have hw11_eq : ∀ idx, wRead m10 11 idx = wRead m2 11 idx := by intro idx; simp [m10, m9, m8, m7, m6, m5, m4, m3]
        have hr11_eq : ∀ idx, rRead m10 11 idx = rRead m2 11 idx := by intro idx; simp [m10, m9, m8, m7, m6, m5, m4, m3]
        simpa [EncSlotCoords, P', hw6_eq, hw11_eq, hr11_eq] using hSlot_m2
      · intro t ht0 ht1 ht2 ht3 ht11 idx
        simp [m10, m9, m8, m7, m6, m5, m4, m3, ht1, ht2, ht3, hw2 t ht11 idx, m1]
      · intro idx _; simp [m10, m9, m8, m7, m6, m5, m4, m3, hw2 0 (by decide) idx, m1]
      · intro idx _ h1 h2
        simp [m10, m9, m8, m7, m6, m5, m4, m3, h1, h2, hw2 1 (by decide) idx, m1]
      · intro t _ ht11 idx
        simp [m10, m9, m8, m7, m6, m5, m4, m3, hr2 t ht11 idx, m1]
      · intro v hv idx
        simp [m10, m9, m8, m7, m6, m5, m4, m3, hv, hlv2 v hv idx, m1]
      · intro v hv idx
        simp [m10, m9, m8, m7, m6, m5, m4, m3, hrlv2 v hv idx, m1]

/-! ### 5. Pigeonhole Free-Slot Allocator (`allocFreeSlotStmt`) -/

/-- Scan `s = 0 .. NumSlots - 1` (`wRead mem 7 s == 0`) and return a free slot in `29[0]`. -/
def allocFreeSlotStmt (NumSlots : ℕ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 29 (.lit 0) (.lit 0),
    .writeWordLocal 29 (.lit 2) (.lit 0),
    .repeatN (.lit (NumSlots : ℤ)) (seqList [
      .ite (.intEq (.readHeap 7 (.readLocal 29 (.lit 2))) (.lit 0))
        (.writeWordLocal 29 (.lit 0) (.readLocal 29 (.lit 2)))
        .skip,
      .writeWordLocal 29 (.lit 2) (.add (.readLocal 29 (.lit 2)) (.lit 1))
    ])
  ]

theorem boxSafe_allocFreeSlotStmt {T_max M_box : ℕ} (NumSlots : ℕ) :
    BoxSafeInner T_max M_box (allocFreeSlotStmt NumSlots) := by
  unfold allocFreeSlotStmt
  apply boxSafeInner_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .repeatN _ (boxSafeInner_seqList ?_)
    intro x hx; simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
    rcases hx with rfl | rfl
    · exact .ite _ (.writeWordLocal _ _ _) .skip
    · exact .writeWordLocal _ _ _

theorem exec_allocFreeSlotStmt {d NumSlots : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {used : Finset ℕ}
    (hcard : (used.filter (· < NumSlots)).card < NumSlots)
    (hmap : ∀ s < NumSlots, wRead mem 7 (s : ℤ) = if s ∈ used then 1 else 0) :
    ∃ (mem' : ArithRAMMemory) (freeS : ℕ),
      DetExecAt 1 inp (allocFreeSlotStmt NumSlots) mem mem' (30 * (NumSlots + 1)) ∧
      freeS < NumSlots ∧
      freeS ∉ used ∧
      wReadL 1 mem' 29 0 = (freeS : ℤ) ∧
      (∀ t idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ t idx, rRead mem' t idx = rRead mem t idx) ∧
      (∀ idx, idx ≠ 0 → idx ≠ 2 → wReadL 1 mem' 29 idx = wReadL 1 mem 29 idx) ∧
      (∀ idx, rReadL 1 mem' 29 idx = rReadL 1 mem 29 idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v, v ≠ 29 → ∀ idx, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  let m1 := wWriteL 1 mem 29 0 0
  let m2 := wWriteL 1 m1 29 2 0
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 0) (.lit 0)) mem m1 4 :=
    DetExecAt.writeWordLocal 1 inp mem 29 _ _ rfl rfl (by simp [intExprOps])
  have hs2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) (.lit 0)) m1 m2 4 :=
    DetExecAt.writeWordLocal 1 inp m1 29 _ _ rfl rfl (by simp [intExprOps])
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    (∀ t idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t idx, rRead m t idx = rRead mem t idx) ∧
    wReadL 1 m 29 2 = (k : ℤ) ∧
    (∀ idx, idx ≠ 0 → idx ≠ 2 → wReadL 1 m 29 idx = wReadL 1 mem 29 idx) ∧
    (∀ idx, rReadL 1 m 29 idx = rReadL 1 mem 29 idx) ∧
    (∀ v, v ≠ 29 → ∀ idx, wReadL 1 m v idx = wReadL 1 mem v idx) ∧
    (∀ v, v ≠ 29 → ∀ idx, rReadL 1 m v idx = rReadL 1 mem v idx) ∧
    ((∃ s < k, s ∉ used) → ∃ r < k, r ∉ used ∧ wReadL 1 m 29 0 = (r : ℤ))
  have hInv0 : Inv 0 m2 := by
    refine ⟨fun _ _ => by simp [m2, m1], fun _ _ => by simp [m2, m1], by simp [m2],
      fun idx h0 h2 => by simp [m2, m1, h0, h2], fun _ => by simp [m2, m1],
      fun v hv _ => by simp [m2, m1, hv], fun _ _ _ => by simp [m2, m1],
      fun ⟨_, hs, _⟩ => by omega⟩
  have hStep : ∀ k < NumSlots, ∀ m, Inv k m →
      ∃ m', DetExecAt 1 inp
        (seqList [
          .ite (.intEq (.readHeap 7 (.readLocal 29 (.lit 2))) (.lit 0))
            (.writeWordLocal 29 (.lit 0) (.readLocal 29 (.lit 2)))
            .skip,
          .writeWordLocal 29 (.lit 2) (.add (.readLocal 29 (.lit 2)) (.lit 1))
        ]) m m' 25 ∧ Inv (k + 1) m' := by
    intro k hk m ⟨hw_m, hr_m, hm2, hwl_m, hrl_m, hlv_m, hrlv_m, hfound⟩
    by_cases hk_in : k ∈ used
    · have hc : cValAt 1 inp m (.intEq (.readHeap 7 (.readLocal 29 (.lit 2))) (.lit 0)) = false := by
        simp only [cValAt_intEq, iValAt_readHeap, iValAt_readLocal, iValAt_lit, hm2, hw_m,
          hmap k hk, hk_in, ↓reduceIte, decide_eq_false_iff_not]
        omega
      let ms1 := wWriteL 1 m 29 2 ((k + 1 : ℕ) : ℤ)
      have hb2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) (.add (.readLocal 29 (.lit 2)) (.lit 1))) m ms1 8 := by
        refine DetExecAt.writeWordLocal 1 inp m 29 _ _ rfl ?_ (by simp [intExprOps])
        simp [hm2]
      refine ⟨ms1, ((DetExecAt.ite_false hc (C_c := 10) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 1 inp m)).seq hb2).mono_cost (by omega),
        fun _ _ => by simp [ms1, hw_m], fun _ _ => by simp [ms1, hr_m], by simp [ms1],
        fun idx h0 h2 => by simp [ms1, h2, hwl_m idx h0 h2],
        fun _ => by simp [ms1, hrl_m],
        fun v hv _ => by simp [ms1, hv, hlv_m v hv],
        fun v hv _ => by simp [ms1, hrlv_m v hv],
        fun ⟨s, hs_lt, hs_not⟩ => ?_⟩
      have hs_lt_k : s < k := by
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hs_lt) with hlt | rfl
        · exact hlt
        · exact absurd hk_in hs_not
      rcases hfound ⟨s, hs_lt_k, hs_not⟩ with ⟨r, hr_lt, hr_not, hr_val⟩
      exact ⟨r, by omega, hr_not, by simp [ms1, hr_val]⟩
    · have hc : cValAt 1 inp m (.intEq (.readHeap 7 (.readLocal 29 (.lit 2))) (.lit 0)) = true := by
        simp [hm2, hw_m, hmap k hk, hk_in]
      let ms1 := wWriteL 1 m 29 0 (k : ℤ)
      let ms2 := wWriteL 1 ms1 29 2 ((k + 1 : ℕ) : ℤ)
      have hb1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 0) (.readLocal 29 (.lit 2))) m ms1 6 :=
        DetExecAt.writeWordLocal 1 inp m 29 _ _ rfl (by simp [hm2]) (by simp [intExprOps])
      have hb2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) (.add (.readLocal 29 (.lit 2)) (.lit 1))) ms1 ms2 8 := by
        refine DetExecAt.writeWordLocal 1 inp ms1 29 _ _ rfl ?_ (by simp [intExprOps])
        simp [ms1, hm2]
      refine ⟨ms2, ((DetExecAt.ite_true hc (C_c := 10) (by simp [condExprOps, intExprOps]) hb1).seq hb2).mono_cost (by omega),
        fun _ _ => by simp [ms2, ms1, hw_m], fun _ _ => by simp [ms2, ms1, hr_m], by simp [ms2],
        fun idx h0 h2 => by simp [ms2, ms1, h0, h2, hwl_m idx h0 h2],
        fun _ => by simp [ms2, ms1, hrl_m],
        fun v hv _ => by simp [ms2, ms1, hv, hlv_m v hv],
        fun v hv _ => by simp [ms2, ms1, hrlv_m v hv],
        fun _ => ⟨k, by omega, hk_in, by simp [ms2, ms1]⟩⟩
  rcases DetExecAt.repeatN_nat (.lit (NumSlots : ℤ)) _ NumSlots 1 25 Inv hInv0 rfl
      (by simp [intExprOps]) hStep with ⟨mN, ⟨hwN, hrN, _, hwlN, hrlN, hlvN, hrlvN, hfoundN⟩, hrep⟩
  have hex_free : ∃ s < NumSlots, s ∉ used := by
    have hlt_range : (used.filter (· < NumSlots)).card < (Finset.range NumSlots).card := by
      simpa using hcard
    rcases Finset.exists_mem_notMem_of_card_lt_card hlt_range with ⟨s, hs_r, hs_nf⟩
    rw [Finset.mem_range] at hs_r
    exact ⟨s, hs_r, fun hs_in => hs_nf (Finset.mem_filter.mpr ⟨hs_in, hs_r⟩)⟩
  rcases hfoundN hex_free with ⟨freeS, hf_lt, hf_not, hf_val⟩
  exact ⟨mN, freeS, (hs1.seq (hs2.seq hrep)).mono_cost (by omega),
    hf_lt, hf_not, hf_val, hwN, hrN, hwlN, hrlN, hlvN, hrlvN⟩

end UL.Proof_lem_7_2_RacerP46
