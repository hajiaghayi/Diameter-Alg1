import UL.Proof.lem_7_2.CG01_MidGlueA2

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Syntactic Pool-Cell Frame Checker (`preservesPoolCells`) for `RandExecBad` -/

def isLitGe3 : IntExpr → Bool
  | .lit z => decide (3 ≤ z)
  | _ => false

def writesWord1Low : ArithRAMStmt → Bool
  | .skip => false
  | .writeWordHeap t idxE _ => decide (t = 1) && !(isLitGe3 idxE)
  | .writeWordLocal _ _ _ => false
  | .freeWordHeap t idxE => decide (t = 1) && !(isLitGe3 idxE)
  | .freeWordLocal _ _ => false
  | .writeRealHeap _ _ _ | .writeRealLocal _ _ _ | .freeRealHeap _ _ | .freeRealLocal _ _ => false
  | .randBitHeap t idxE => decide (t = 1) && !(isLitGe3 idxE)
  | .randBitLocal _ _ => false
  | .seq s₁ s₂ => writesWord1Low s₁ || writesWord1Low s₂
  | .ite _ tB fB => writesWord1Low tB || writesWord1Low fB
  | .whileLoop _ b => writesWord1Low b
  | .repeatN _ b => writesWord1Low b
  | .localScope b => writesWord1Low b

def writesWord1LowCont : ArithRAMCont → Bool
  | .stmt s => writesWord1Low s
  | .repeatLoop _ b => writesWord1Low b
  | .popScope _ => false

@[simp] theorem writesWord1Low_boxWriteW (M_box t : ℕ) (idxE valE : IntExpr) :
    writesWord1Low (boxWriteW M_box t idxE valE) = (decide (t = 1) && !(isLitGe3 idxE)) := by
  simp [boxWriteW, writesWord1Low]

@[simp] theorem writesWord1Low_boxWriteR (M_box t : ℕ) (idxE : IntExpr) (valE : RealExpr) :
    writesWord1Low (boxWriteR M_box t idxE valE) = false := by
  simp [boxWriteR, writesWord1Low]

@[simp] theorem writesWord1Low_seqList : ∀ (ss : List ArithRAMStmt),
    writesWord1Low (seqList ss) = ss.any writesWord1Low
  | [] => rfl
  | [s] => by simp [seqList]
  | s :: s' :: ss => by
      simp only [seqList, writesWord1Low, List.any_cons]
      rw [writesWord1Low_seqList (s' :: ss), List.any_cons]

private lemma eval_ne_of_not_writes1Low {d : ℕ} (inp : ArithRAMInput d)
    (fd : ℕ) (ws : WordStore) {t : ℕ} {idxE : IntExpr} {idx : ℤ}
    (hlow : (decide (t = 1) && !(isLitGe3 idxE)) = false) (hidx : idx < 3) :
    1 ≠ t ∨ idx ≠ (evalIntExpr inp.toWordView fd ws idxE).1 := by
  by_cases ht : t = 1
  · subst ht
    right
    simp only [decide_true, Bool.true_and, Bool.not_eq_false'] at hlow
    cases idxE with
    | lit z =>
        simp only [isLitGe3, decide_eq_true_eq] at hlow
        simp only [evalIntExpr]
        omega
    | _ => simp [isLitGe3] at hlow
  · exact Or.inl (Ne.symm ht)

theorem runArithRAMFuel_preserves_w1Low {d : ℕ} (inp : ArithRAMInput d) :
    ∀ (fuel : ℕ) (stk : List ArithRAMCont) (st : ArithRAMExecState) (out : ArithRAMExecOutcome),
      (∀ c ∈ stk, writesWord1LowCont c = false) →
      runArithRAMFuel inp fuel stk st = .halted out →
      ∀ idx : ℤ, idx < 3 → wRead out.mem 1 idx = wRead st.mem 1 idx
  | 0, [], st, out, _, hrun, idx, _ => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; simp
  | 0, _ :: _, _, _, _, hrun, _, _ => by simp [runArithRAMFuel] at hrun
  | fuel + 1, [], st, out, _, hrun, idx, _ => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; simp
  | fuel + 1, item :: rest, st, out, hstk, hrun, idx, hidx => by
      have hitem : writesWord1LowCont item = false := hstk item List.mem_cons_self
      have hrest : ∀ c ∈ rest, writesWord1LowCont c = false :=
        fun c hc => hstk c (List.mem_cons_of_mem _ hc)
      cases item with
      | popScope prev =>
          simp only [runArithRAMFuel] at hrun
          rw [runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx]
          simp
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt body :: .repeatLoop r body :: rest),
                  writesWord1LowCont c = false := by
                intro c hc; simp only [List.mem_cons] at hc
                rcases hc with rfl | rfl | hc
                · exact hitem
                · exact hitem
                · exact hrest c hc
              exact runArithRAMFuel_preserves_w1Low inp fuel _ _ out hstk' hrun idx hidx
      | stmt s =>
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx
          | writeWordHeap t' idxE valE =>
              simp only [writesWord1LowCont, writesWord1Low] at hitem
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx]
              exact wRead_wWrite_of_ne st.mem _
                (eval_ne_of_not_writes1Low inp st.frameDepth st.mem.words hitem hidx)
          | writeWordLocal _ _ _ =>
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx]
              simp [wRead, WordStore.read, WordStore.write]
          | freeWordHeap t' idxE =>
              simp only [writesWord1LowCont, writesWord1Low] at hitem
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx]
              exact wRead_wFree_of_ne st.mem
                (eval_ne_of_not_writes1Low inp st.frameDepth st.mem.words hitem hidx)
          | freeWordLocal _ _ =>
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx]
              simp [wRead, WordStore.read, WordStore.free]
          | writeRealHeap _ _ _ | writeRealLocal _ _ _ | freeRealHeap _ _ | freeRealLocal _ _ =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx
          | randBitHeap t' idxE =>
              simp only [writesWord1LowCont, writesWord1Low] at hitem
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  rw [runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx]
                  exact wRead_wWrite_of_ne st.mem _
                    (eval_ne_of_not_writes1Low inp st.frameDepth st.mem.words hitem hidx)
          | randBitLocal _ _ =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  rw [runArithRAMFuel_preserves_w1Low inp fuel rest _ out hrest hrun idx hidx]
                  simp [wRead, WordStore.read, WordStore.write]
          | seq s₁ s₂ =>
              simp only [writesWord1LowCont, writesWord1Low, Bool.or_eq_false_iff] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt s₁ :: .stmt s₂ :: rest),
                  writesWord1LowCont c = false := by
                intro c hc; simp only [List.mem_cons] at hc
                rcases hc with rfl | rfl | hc
                · exact hitem.1
                · exact hitem.2
                · exact hrest c hc
              exact runArithRAMFuel_preserves_w1Low inp fuel _ _ out hstk' hrun idx hidx
          | ite c tB fB =>
              simp only [writesWord1LowCont, writesWord1Low, Bool.or_eq_false_iff] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (.stmt (if (evalArithCond inp st.frameDepth st.mem c).1 then tB else fB) :: rest),
                  writesWord1LowCont item' = false := by
                intro item' hi; simp only [List.mem_cons] at hi
                rcases hi with rfl | hi
                · split_ifs <;> [exact hitem.1; exact hitem.2]
                · exact hrest item' hi
              exact runArithRAMFuel_preserves_w1Low inp fuel _ _ out hstk' hrun idx hidx
          | whileLoop c body =>
              simp only [writesWord1LowCont, writesWord1Low] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (if (evalArithCond inp st.frameDepth st.mem c).1
                  then .stmt body :: .stmt (.whileLoop c body) :: rest else rest),
                  writesWord1LowCont item' = false := by
                split_ifs
                · intro item' hi; simp only [List.mem_cons] at hi
                  rcases hi with rfl | rfl | hi
                  · exact hitem
                  · exact hitem
                  · exact hrest item' hi
                · exact hrest
              exact runArithRAMFuel_preserves_w1Low inp fuel _ _ out hstk' hrun idx hidx
          | repeatN cntE body =>
              simp only [writesWord1LowCont, writesWord1Low] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (ArithRAMCont.repeatLoop
                  (if 0 ≤ (evalIntExpr inp.toWordView st.frameDepth st.mem.words cntE).1
                   then (evalIntExpr inp.toWordView st.frameDepth st.mem.words cntE).1.toNat else 0)
                  body :: rest),
                  writesWord1LowCont item' = false := by
                intro item' hi; simp only [List.mem_cons] at hi
                rcases hi with rfl | hi
                · exact hitem
                · exact hrest item' hi
              exact runArithRAMFuel_preserves_w1Low inp fuel _ _ out hstk' hrun idx hidx
          | localScope body =>
              simp only [writesWord1LowCont, writesWord1Low] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (.stmt body :: .popScope st.frameDepth :: rest),
                  writesWord1LowCont item' = false := by
                intro item' hi; simp only [List.mem_cons] at hi
                rcases hi with rfl | rfl | hi
                · exact hitem
                · rfl
                · exact hrest item' hi
              rw [runArithRAMFuel_preserves_w1Low inp fuel _ _ out hstk' hrun idx hidx]
              simp

def preservesPoolWords (s : ArithRAMStmt) : Bool :=
  !(writesWordTag 0 s) && !(writesWordTag 2 s) && !(writesWordTag 3 s) && !(writesWord1Low s)

def PoolWordsEq (m₀ m₁ : ArithRAMMemory) : Prop :=
  (∀ idx, wRead m₁ 0 idx = wRead m₀ 0 idx) ∧
  (∀ idx, wRead m₁ 2 idx = wRead m₀ 2 idx) ∧
  (∀ idx, wRead m₁ 3 idx = wRead m₀ 3 idx) ∧
  (∀ idx : ℤ, idx < 3 → wRead m₁ 1 idx = wRead m₀ 1 idx)

lemma encHandlePool_of_poolWordsEq_and_live {d n : ℕ} {P : DynamicPointSet d}
    {m₀ m₁ : ArithRAMMemory}
    (hPool₀ : EncHandlePool d n m₀ P)
    (hEq : PoolWordsEq m₀ m₁)
    (hLive₁ : EncLiveCoords d n m₁ P.activeHandles P.handleCoords) :
    EncHandlePool d n m₁ P := by
  rcases hPool₀.2 with ⟨hwm, freeSet, hhwm, e10, e11, e12, hdisj, hunion, hf1, hf2, hw2⟩
  exact ⟨hLive₁, hwm, freeSet, hhwm,
    by rw [hEq.2.2.2 0 (by decide)]; exact e10,
    by rw [hEq.2.2.2 1 (by decide)]; exact e11,
    by rw [hEq.2.2.2 2 (by decide)]; exact e12,
    hdisj, hunion,
    fun i hi => by rw [hEq.2.2.1]; exact hf1 i hi,
    fun i hi j hj hne => by rw [hEq.2.2.1, hEq.2.2.1]; exact hf2 i hi j hj hne,
    fun h hh => by rw [hEq.2.1]; exact hw2 h hh⟩

theorem RandExecBad.with_poolWordsEq {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt} {B : ℕ}
    {mem₀ : ArithRAMMemory} {SafePost GoodPost : ArithRAMMemory → Prop} {p_bad : ℝ} {C : ℕ}
    (hpop₀ : mem₀.popDepth 0 = mem₀)
    (hpres : preservesPoolWords s = true)
    (h : RandExecBad inp s B mem₀ SafePost GoodPost p_bad C) :
    RandExecBad inp s B mem₀ (fun m => SafePost m ∧ PoolWordsEq mem₀ m) GoodPost p_bad C := by
  classical
  simp only [preservesPoolWords, Bool.and_eq_true, Bool.not_eq_true'] at hpres
  rcases hpres with ⟨⟨⟨hw0, hw2⟩, hw3⟩, hw1low⟩
  rcases h with ⟨hp_bad, Post, Bad, _, hR, hcard, hpost⟩
  rcases RandExecAt.det_mem hpop₀ (fun f m hp => (hpost f m hp).1) hR
    with ⟨nextM, hnext, hR_det⟩
  have hEq_all : ∀ f : Fin B → Bool, PoolWordsEq mem₀ (nextM f) := by
    intro f
    rcases hR_det.2 (List.ofFn f) (by simp) 0 0 [] with ⟨fuel, u₁, pk₁, m₁, _, hm₁_eq, hs_run⟩
    have hfn_eq : (fun i : Fin B => (List.ofFn f)[i.val]'(lt_of_lt_of_le i.isLt (by simp))) = f := by
      ext i; simp
    rw [hfn_eq] at hm₁_eq
    subst hm₁_eq
    have hdrop : (List.ofFn f).drop B = [] := List.drop_eq_nil_of_le (by simp)
    have hrun1 : runArithRAMFuel inp (fuel + 1) [.stmt s]
        { mem := mem₀, frameDepth := 0, remainingBits := List.ofFn f,
          unitCost := 0, peakCellSpace := 0 } =
        .halted { mem := nextM f, unitCost := u₁, peakCellSpace := pk₁ } := by
      have h1 := hs_run 1
      rw [hdrop] at h1
      have hrhs : runArithRAMFuel inp 1 []
          { mem := nextM f, frameDepth := 0, remainingBits := [],
            unitCost := u₁, peakCellSpace := pk₁ } =
          .halted { mem := nextM f, unitCost := u₁, peakCellSpace := pk₁ } := by
        simp [runArithRAMFuel, (hnext f).1]
      rw [hrhs] at h1
      exact h1
    refine ⟨?_, ?_, ?_, ?_⟩
    · intro idx
      exact runArithRAMFuel_preserves_wTag inp 0 (fuel + 1) [.stmt s] _ _
        (fun c hc => by simp only [List.mem_singleton] at hc; subst hc; exact hw0) hrun1 idx
    · intro idx
      exact runArithRAMFuel_preserves_wTag inp 2 (fuel + 1) [.stmt s] _ _
        (fun c hc => by simp only [List.mem_singleton] at hc; subst hc; exact hw2) hrun1 idx
    · intro idx
      exact runArithRAMFuel_preserves_wTag inp 3 (fuel + 1) [.stmt s] _ _
        (fun c hc => by simp only [List.mem_singleton] at hc; subst hc; exact hw3) hrun1 idx
    · intro idx hlt
      exact runArithRAMFuel_preserves_w1Low inp (fuel + 1) [.stmt s] _ _
        (fun c hc => by simp only [List.mem_singleton] at hc; subst hc; exact hw1low) hrun1 idx hlt
  refine ⟨hp_bad, (fun f m => m = nextM f), Bad, inferInstance, hR_det, hcard, ?_⟩
  intro f m hm; subst hm
  rcases hpost f (nextM f) (hnext f).2 with ⟨hpop, hs, hg⟩
  exact ⟨hpop, ⟨hs, hEq_all f⟩, hg⟩

/-! ### 2. Polynomial Cost Bound for `syncSplitAllRoundsCost` -/

def p46SyncSplitPolyConst (cHpj cBase : ℕ) : ℕ :=
  let C_hpj0 := cHpj * 21 ^ 3
  let C_mb := 105 + cHpj + 4 * cBase
  let C_L := 68719476736 + 8 * (84 * cBase)
  10 +
    196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500) +
    46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
      16 * (C_hpj0 * (C_mb + 1)) + 500) +
    165000 * (4 * C_L + 3)

private lemma mul_sum4_P19 (a b c e P : ℕ) :
    a * P + b * P + c * P + e * P = (a + b + c + e) * P := by
  ring

theorem syncSplitAllRoundsCost_poly_le
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    syncSplitAllRoundsCost d n p ≤ p46SyncSplitPolyConst cHpj cBase * (D ^ 19 * H ^ 18) := by
  intro D H
  let P19 := D ^ 19 * H ^ 18
  rcases hp.all_component_costs_poly_le hn
    with ⟨h1_P19, _, _, _, _, hHpjTot, _, _, _, hGCTot⟩
  have hD3 : 3 ≤ D := by have h := hp.hD3; rw [hp.hD_eq] at h; exact h
  have hH5 : 5 ≤ H := by have h := hp.hH5; rw [hp.hH_eq] at h; exact h
  have hD1 : 1 ≤ D := by omega
  have hH1 : 1 ≤ H := by omega
  -- 1. HPJ term
  have h_hpj :=
    le_trans (Nat.mul_le_mul_right _ (by omega : 20 * D ^ 2 ≤ p.D₀ + 20 * D ^ 2 + 2)) hHpjTot
  -- 2. Slot allocation term
  let G1 := 40 * p.NumSlots + 300 * (p.D₀ + 1) * (p.D₀ + 1) + 35 * (p.NumSlots + 1) + 500
  have halloc_le : freshAllocFourCost p.D₀ p.NumSlots ≤ 4 * G1 := by
    unfold freshAllocFourCost; dsimp only [G1]; omega
  have h_alloc :=
    le_trans
      (le_trans (Nat.mul_le_mul_left (20 * D ^ 2) halloc_le)
        (by have hmul : (20 * D ^ 2) * (4 * G1) = (80 * D ^ 2) * G1 := by ring
            rw [hmul]
            exact Nat.mul_le_mul_right G1 (by omega : 80 * D ^ 2 ≤ 4 * p.D₀ + 80 * D ^ 2 + 20)))
      hGCTot
  -- 3. Post-HPJ core/partition term
  let A := 4 * p.L + 3
  let B := p.K_seg + d + 5
  have hpost_le : 330 + syncSplitPostHPJCost d p ≤ 2750 * A * B := by
    have hlin : 330 + syncSplitPostHPJCost d p ≤ 1550 * B + 1200 * (A * B) := by
      unfold syncSplitPostHPJCost; dsimp only [A, B]
      have hmul_assoc : 1200 * (4 * p.L + 3) * (p.K_seg + d + 5) =
          1200 * ((4 * p.L + 3) * (p.K_seg + d + 5)) := Nat.mul_assoc _ _ _
      rw [hmul_assoc]; omega
    have hB_le_AB : B ≤ A * B := Nat.le_mul_of_pos_left B (by dsimp [A]; omega)
    calc 330 + syncSplitPostHPJCost d p
        ≤ 1550 * B + 1200 * (A * B) := hlin
      _ ≤ 1550 * (A * B) + 1200 * (A * B) :=
          Nat.add_le_add_right (Nat.mul_le_mul_left 1550 hB_le_AB) _
      _ = 2750 * A * B := by ring
  set C_L : ℕ := 68719476736 + 8 * (84 * cBase) with hCL_def
  have hL_eq : p.L = C_L * D ^ 4 * H ^ 2 := by
    have h := hp.hL_eq; rw [hp.hH_eq, ← hCL_def] at h; exact h
  have hD4H2_pos : 1 ≤ D ^ 4 * H ^ 2 :=
    Nat.mul_pos (Nat.pos_of_ne_zero (by positivity)) (Nat.pos_of_ne_zero (by positivity))
  have hA_le : A ≤ (4 * C_L + 3) * (D ^ 4 * H ^ 2) := by
    dsimp only [A]; rw [hL_eq]
    have h3 : 3 ≤ 3 * (D ^ 4 * H ^ 2) := Nat.le_mul_of_pos_right 3 hD4H2_pos
    have h4eq : 4 * (C_L * D ^ 4 * H ^ 2) = 4 * C_L * (D ^ 4 * H ^ 2) := by ring
    rw [h4eq]
    calc 4 * C_L * (D ^ 4 * H ^ 2) + 3
        ≤ 4 * C_L * (D ^ 4 * H ^ 2) + 3 * (D ^ 4 * H ^ 2) := Nat.add_le_add_left h3 _
      _ = (4 * C_L + 3) * (D ^ 4 * H ^ 2) := (Nat.add_mul _ _ _).symm
  have hK_le : p.K_seg ≤ H := by have h := hp.hK_le_H; rw [hp.hH_eq] at h; exact h
  have hB_le : B ≤ 3 * (D * H) := by
    let DH := D * H
    have hH_DH : H ≤ DH := Nat.le_mul_of_pos_left H hD1
    have hD_DH : d + 3 ≤ DH := Nat.le_mul_of_pos_right D hH1
    have h15 : 15 ≤ DH := Nat.mul_le_mul hD3 hH5
    change p.K_seg + d + 5 ≤ 3 * DH
    omega
  have hD7H3_le : D ^ 7 * H ^ 3 ≤ P19 :=
    pow_mul_pow_le_target hD1 hH1 (by decide : 7 ≤ 19) (by decide : 3 ≤ 18)
  have h_poly_id : ∀ M : ℕ,
      (20 * D ^ 2) * (2750 * (M * (D ^ 4 * H ^ 2)) * (3 * (D * H))) =
      (165000 * M) * (D ^ 7 * H ^ 3) := fun M => by ring
  have h_post : (20 * D ^ 2) * (330 + syncSplitPostHPJCost d p) ≤
      (165000 * (4 * C_L + 3)) * P19 := by
    calc (20 * D ^ 2) * (330 + syncSplitPostHPJCost d p)
        ≤ (20 * D ^ 2) * (2750 * A * B) := Nat.mul_le_mul_left _ hpost_le
      _ ≤ (20 * D ^ 2) * (2750 * ((4 * C_L + 3) * (D ^ 4 * H ^ 2)) * (3 * (D * H))) :=
          Nat.mul_le_mul_left _ (Nat.mul_le_mul (Nat.mul_le_mul_left 2750 hA_le) hB_le)
      _ = (165000 * (4 * C_L + 3)) * (D ^ 7 * H ^ 3) := h_poly_id (4 * C_L + 3)
      _ ≤ (165000 * (4 * C_L + 3)) * P19 := Nat.mul_le_mul_left _ hD7H3_le
  have h_expand : syncSplitAllRoundsCost d n p =
      10 + (20 * D ^ 2) * freshAllocFourCost p.D₀ p.NumSlots +
      (20 * D ^ 2) * hpjCallCost d n p +
      (20 * D ^ 2) * (330 + syncSplitPostHPJCost d p) := by
    unfold syncSplitAllRoundsCost syncSplitOneRoundCost
    dsimp only [D]
    ring
  have h10 : 10 ≤ 10 * P19 := Nat.le_mul_of_pos_right 10 h1_P19
  rw [h_expand]
  have hsum := Nat.add_le_add (Nat.add_le_add (Nat.add_le_add h10 h_alloc) h_hpj) h_post
  rw [mul_sum4_P19] at hsum
  exact hsum

/-! ### 3. Parametric `JobTickStageSpec` & Constructor `mkMiddleTickSplitSpecRelaxed` -/

structure JobTickStageSpec (cHpj cBase d n t : ℕ) (δ : ℝ) (p : P46Params d n) where
  tickStmt : ArithRAMStmt
  T_max : ℕ
  M_box : ℕ
  B_tick : ℕ
  C_tick : ℕ
  p_tick : ℝ
  hT28 : 28 ≤ T_max
  hBox_ge : p46BoxSize d n p ≤ M_box
  hBoxSafe : BoxSafeOuter T_max M_box tickStmt
  hp_tick : p_tick ≤ (((p.D₀ + 2 : ℕ) : ℝ)) * (2 * p.φ_ev)
  hExecTick :
    ∀ {P : DynamicPointSet d} {op : DynamicUpdate d}
      {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
      {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
      {opH : ℕ} {uMap' : GhostUidMap d P'}
      {P_good₀ : Prop},
      (P_good₀ → st₀.AllCentersGood) →
      PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap' →
      RandExecBad (mkStepInput n P op) tickStmt B_tick mem_rt
        (fun m_tick =>
          wRead m_tick 0 0 = wRead mem_rt 0 0 ∧
          ∃ st_mid : PureServingState d n p.H p.L p.B_scan P',
            st_mid.NodesInv ∧
            (chainTerminal P'.handleCoords st_mid.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
            EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m_tick P'
              st_mid.k st_mid.nodes st_mid.snAge (fun r => (st_mid.ownedJob r).isNone) ∧
            CG01_EncJobs p P' st_mid m_tick)
        (fun m_tick =>
          P_good₀ →
            ∃ st_mid : PureServingState d n p.H p.L p.B_scan P',
              st_mid.NodesInv ∧
              (chainTerminal P'.handleCoords st_mid.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
              EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m_tick P'
                st_mid.k st_mid.nodes st_mid.snAge (fun r => (st_mid.ownedJob r).isNone) ∧
              CG01_EncJobs p P' st_mid m_tick ∧
              st_mid.AllCentersGood)
        p_tick C_tick

/-- Convenience constructor building `JobTickStageSpec` directly from `CG03`'s `EncFullChainAndJobs`
output + syntactic `preservesPoolWords tickStmt = true` (auto-recovering `wRead 0 0` and `EncHandlePool`). -/
def mkJobTickStageSpec_of_encFullChainAndJobs
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (tickStmt : ArithRAMStmt)
    (T_max M_box B_tick C_tick : ℕ) (p_tick : ℝ)
    (hT28 : 28 ≤ T_max)
    (hBox_ge : p46BoxSize d n p ≤ M_box)
    (hBoxSafe : BoxSafeOuter T_max M_box tickStmt)
    (hPresPool : preservesPoolWords tickStmt = true)
    (hp_tick : p_tick ≤ (((p.D₀ + 2 : ℕ) : ℝ)) * (2 * p.φ_ev))
    (hExec :
      ∀ {P : DynamicPointSet d} {op : DynamicUpdate d}
        {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
        {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
        {opH : ℕ} {uMap' : GhostUidMap d P'}
        {P_good₀ : Prop},
        (P_good₀ → st₀.AllCentersGood) →
        PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap' →
        RandExecBad (mkStepInput n P op) tickStmt B_tick mem_rt
          (fun m_tick =>
            ∃ st_mid : PureServingState d n p.H p.L p.B_scan P',
              st_mid.NodesInv ∧
              (chainTerminal P'.handleCoords st_mid.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
              EncFullChainAndJobs d n p.H defaultChainHdrCfg p m_tick P' st_mid)
          (fun m_tick =>
            P_good₀ →
              ∃ st_mid : PureServingState d n p.H p.L p.B_scan P',
                st_mid.NodesInv ∧
                (chainTerminal P'.handleCoords st_mid.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
                EncFullChainAndJobs d n p.H defaultChainHdrCfg p m_tick P' st_mid ∧
                st_mid.AllCentersGood)
          p_tick C_tick) :
    JobTickStageSpec cHpj cBase d n t δ p where
  tickStmt := tickStmt
  T_max := T_max
  M_box := M_box
  B_tick := B_tick
  C_tick := C_tick
  p_tick := p_tick
  hT28 := hT28
  hBox_ge := hBox_ge
  hBoxSafe := hBoxSafe
  hp_tick := hp_tick
  hExecTick := by
    intro P op m_pre st₀ mem_rt P' opH uMap' P_good₀ hGood₀ ctx
    have hChain_rt := ctx.hChain_rt
    dsimp only at hChain_rt
    rcases hChain_rt with ⟨_, hnK, hSlots2, hPool_rt, _⟩
    have h1 := RandExecBad.with_poolWordsEq ctx.hpop_rt hPresPool (hExec hGood₀ ctx)
    refine h1.mono ?_ ?_ le_rfl le_rfl
    · rintro m_tick ⟨⟨st_mid, hinv, hleaf, hFull⟩, hEq⟩
      have hPool_tick := encHandlePool_of_poolWordsEq_and_live hPool_rt hEq hFull.2.2.2.1
      have hRel := (encFullChainAndJobs_iff_relaxed p m_tick P' st_mid).mp
        ⟨hnK, hSlots2, hPool_tick, hFull⟩
      exact ⟨hEq.1 0, st_mid, hinv, hleaf, hRel.1, hRel.2⟩
    · rintro m_tick ⟨_, hEq⟩ hg_imp hPG₀
      rcases hg_imp hPG₀ with ⟨st_mid, hinv, hleaf, hFull, hGood_mid⟩
      have hPool_tick := encHandlePool_of_poolWordsEq_and_live hPool_rt hEq hFull.2.2.2.1
      have hRel := (encFullChainAndJobs_iff_relaxed p m_tick P' st_mid).mp
        ⟨hnK, hSlots2, hPool_tick, hFull⟩
      exact ⟨st_mid, hinv, hleaf, hRel.1, hRel.2, hGood_mid⟩

/-- Parametric constructor combining `JobTickStageSpec` with `syncSplitAllRoundsStmt` to form a
complete `MiddleTickSplitSpecRelaxed`! -/
noncomputable def mkMiddleTickSplitSpecRelaxed
    (h_lem_5_1 : S_lem_5_1)
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (tick : JobTickStageSpec cHpj cBase d n t δ p) :
    MiddleTickSplitSpecRelaxed cHpj cBase d n t δ p where
  EncJobs := CG01_EncJobs p
  midStmt := .seq tick.tickStmt (syncSplitAllRoundsStmt d n tick.M_box p)
  T_max := tick.T_max
  M_box := tick.M_box
  B_mid := tick.B_tick + (20 * (d + 3) ^ 2) * p.B_hpj
  C_mid := tick.C_tick + syncSplitAllRoundsCost d n p
  p_mid := tick.p_tick + (((20 * (d + 3) ^ 2 : ℕ) : ℝ)) * (2 * p.φ_ev)
  hT27 := by have := tick.hT28; omega
  hBox_ge := tick.hBox_ge
  hBoxSafe := .seq tick.hBoxSafe (boxSafe_syncSplitAllRoundsStmt tick.hT28 p)
  hp_budget := by
    have h1 := tick.hp_tick
    have h2 := hp.hfb_le
    have hcast : (((p.D₀ + 2 : ℕ) : ℝ)) * (2 * p.φ_ev) +
        (((20 * (d + 3) ^ 2 : ℕ) : ℝ)) * (2 * p.φ_ev) +
        (p.D₀ : ℝ) * (2 * p.φ_ev) =
        (((2 * p.D₀ + 20 * (d + 3) ^ 2 + 2 : ℕ) : ℝ)) * (2 * p.φ_ev) := by
      push_cast; ring
    linarith
  hEncJobs_empty := cg01_encJobs_empty p
  hEncJobs_congr_not_0_26 := cg01_encJobs_congr_not_0_26
  hExecMid := by
    intro P op m_pre st₀ mem_rt P' opH uMap' P_good₀ hGood₀ ctx
    classical
    let inp := mkStepInput n P op
    refine RandExecBad.seq ctx.hpop_rt (tick.hExecTick hGood₀ ctx) ?_
    intro m_tick hpop_tick ⟨hw00_tick, hExSafe_tick⟩
    by_cases hExGood_tick :
        ∃ st_mid : PureServingState d n p.H p.L p.B_scan P',
          st_mid.NodesInv ∧
          (chainTerminal P'.handleCoords st_mid.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
          EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m_tick P'
            st_mid.k st_mid.nodes st_mid.snAge (fun r => (st_mid.ownedJob r).isNone) ∧
          CG01_EncJobs p P' st_mid m_tick ∧
          st_mid.AllCentersGood
    · rcases hExGood_tick with ⟨st_mid, hinv, hleaf, hCh, hJb, hGood_mid⟩
      have hSplit := exec_syncSplitAllRoundsStmt h_lem_5_1 hp hn tick.hBox_ge inp
        ctx.hP'_wf st_mid hinv hleaf hpop_tick hCh hJb
      refine hSplit.mono ?_ ?_ le_rfl le_rfl
      · rintro m_mid ⟨hw00_sp, hC₁⟩
        exact ⟨hw00_sp.trans hw00_tick, hC₁⟩
      · intro m_mid _ hg_sp _ _
        exact hg_sp hGood_mid
    · rcases hExSafe_tick with ⟨st_mid, hinv, hleaf, hCh, hJb⟩
      have hSplit := exec_syncSplitAllRoundsStmt h_lem_5_1 hp hn tick.hBox_ge inp
        ctx.hP'_wf st_mid hinv hleaf hpop_tick hCh hJb
      refine hSplit.mono ?_ ?_ le_rfl le_rfl
      · rintro m_mid ⟨hw00_sp, hC₁⟩
        exact ⟨hw00_sp.trans hw00_tick, hC₁⟩
      · intro _ _ _ hImp hPG₀
        exact False.elim (hExGood_tick (hImp hPG₀))

/-- Top-level reduction of `S_lem_7_2` to `JobTickStageSpec` + its polynomial cost bound! -/
theorem prove_S_lem_7_2_of_jobTickStageSpec
    (h_lem_5_1 : S_lem_5_1)
    (h_lem_5_2 : S_lem_5_2)
    (h_fb : S_clm_7_3_failure_budget)
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    (C_cap C_tick_poly : ℕ)
    (hBuildTick : ∀ (d n t : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        C_cap * (D ^ 4 * H ^ 2) < n →
        ∀ (p : P46Params d n),
          P46ParamsValid cHpj (extractCBaseNat h_mc) d n t δ p →
          ∃ tick : JobTickStageSpec cHpj (extractCBaseNat h_mc) d n t δ p,
            tick.T_max = 28 ∧
            tick.M_box = p46BoxSize d n p ∧
            tick.C_tick ≤ C_tick_poly * (D ^ 19 * H ^ 18)) :
    S_lem_7_2 := by
  let cBase : ℕ := extractCBaseNat h_mc
  let C_mid_poly := C_tick_poly + p46SyncSplitPolyConst cHpj cBase
  let C_box_poly := p46BoxPolyConst cHpj
  refine prove_S_lem_7_2_of_only_middleTickSplitRelaxed h_lem_5_2 h_fb h_mc hcHpj
    C_cap C_mid_poly C_box_poly ?_
  intro d n t hd1 hn ht δ hδ0 hδ1 D H hcap p hp
  rcases hBuildTick d n t hd1 hn ht δ hδ0 hδ1 hcap p hp with ⟨tick, hT, hM, hCtick⟩
  let mid := mkMiddleTickSplitSpecRelaxed h_lem_5_1 hp hn tick
  have hCsp : syncSplitAllRoundsCost d n p ≤ p46SyncSplitPolyConst cHpj cBase * (D ^ 19 * H ^ 18) :=
    syncSplitAllRoundsCost_poly_le hp hn
  have hBox : 28 * p46BoxSize d n p ≤ p46BoxPolyConst cHpj * n * (D ^ 19 * H ^ 18) :=
    hp.box_poly_le hn
  refine ⟨mid, ?_, ?_⟩
  · change tick.C_tick + syncSplitAllRoundsCost d n p ≤
      (C_tick_poly + p46SyncSplitPolyConst cHpj cBase) * (D ^ 19 * H ^ 18)
    calc tick.C_tick + syncSplitAllRoundsCost d n p
        ≤ C_tick_poly * (D ^ 19 * H ^ 18) +
            p46SyncSplitPolyConst cHpj cBase * (D ^ 19 * H ^ 18) := Nat.add_le_add hCtick hCsp
      _ = (C_tick_poly + p46SyncSplitPolyConst cHpj cBase) * (D ^ 19 * H ^ 18) := by ring
  · change tick.T_max * tick.M_box ≤ p46BoxPolyConst cHpj * n * (D ^ 19 * H ^ 18)
    rw [hT, hM]
    exact hBox

end UL.Proof_lem_7_2_RacerP46
