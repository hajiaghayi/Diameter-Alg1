import UL.Proof.lem_7_2.CG01_NodeSpec0b

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### Stage 2c1: Congruence & Deterministic Prefix of `cg01OpenNewLevelAtRStmt` -/

lemma cg01_activeSlotSet_congr {m₁ m₂ : ArithRAMMemory} {D₀ : ℕ}
    (h1 : ∀ k, wRead m₁ 1 k = wRead m₂ 1 k)
    (h14 : ∀ k, wRead m₁ 14 k = wRead m₂ 14 k)
    (h15 : ∀ k, wRead m₁ 15 k = wRead m₂ 15 k)
    (h16 : ∀ k, wRead m₁ 16 k = wRead m₂ 16 k)
    (h19 : ∀ k, wRead m₁ 19 k = wRead m₂ 19 k)
    (h23 : ∀ k, wRead m₁ 23 k = wRead m₂ 23 k) :
    activeSlotSet m₁ D₀ = activeSlotSet m₂ D₀ := by
  have hsn : ∀ r, snSlotSet m₁ r = snSlotSet m₂ r :=
    fun r => snSlotSet_congr_14_15 (h14 _) (h15 _)
  have hjl : ∀ idx, jobLevelSlotSet m₁ idx = jobLevelSlotSet m₂ idx := by
    intro idx; unfold jobLevelSlotSet
    rw [h23, h23, h23, h23, h23]
  have hjo : ∀ r, jobOwnedSlotSet m₁ D₀ r = jobOwnedSlotSet m₂ D₀ r := by
    intro r; unfold jobOwnedSlotSet
    rw [h16, h19]
    split_ifs
    · exact Finset.biUnion_congr rfl (fun j _ => hjl _)
    · rfl
  unfold activeSlotSet
  rw [h1 5, h1 6]
  congr 2
  exact Finset.biUnion_congr rfl (fun r _ => by rw [hsn r, hjo r])

def cg01OpenLevelPrepStmt (d n M_box : ℕ) (cfg : ChainHdrCfg) (p : P46Params d n) : ArithRAMStmt :=
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let jLenE : IntExpr := .readHeap 19 rE
  let lastIdxE : IntExpr := .add (.mul rE (.lit (p.D₀ : ℤ))) (.sub jLenE (.lit 1))
  seqList [
    freshAllocFourSlotsStmt p.D₀ p.NumSlots M_box,
    boxWriteW M_box 26 (.lit 1) (.readHeap 23 (.add (.mul (.lit 8) lastIdxE) (.lit 6))),
    freezeSlot26_1Stmt M_box,
    boxWriteW M_box 26 (.lit 7) (.add (.mul rE (.lit (p.D₀ : ℤ))) jLenE),
    boxWriteW M_box 26 (.lit 25) (cfg.jobRem.readE rE)
  ]

theorem boxSafe_cg01OpenLevelPrepStmt {d n T_max M_box : ℕ} {cfg : ChainHdrCfg}
    (hT : 27 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (cg01OpenLevelPrepStmt d n M_box cfg p) := by
  unfold cg01OpenLevelPrepStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl
  · exact boxSafe_freshAllocFourSlotsStmt hT p.D₀ p.NumSlots
  · exact .boxW (by omega) _ _
  · exact boxSafe_freezeSlot26_1Stmt (by omega)
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _

theorem exec_cg01OpenLevelPrepStmt
    (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k)
    {g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩)}
    {m₁ m_c : ArithRAMMemory}
    {lvs_h : List (JobLvData ctx.d)} (hlen_eq : lvs_h.length = g₀.lvs.length)
    (pb : ActivePropBuildState ctx gFlag i hi g₀ m₁)
    (hlv_all : ∀ (j : ℕ) (hj : j < lvs_h.length),
      let idx := i * ctx.p.D₀ + j
      let hj_g : j < g₀.lvs.length := hlen_eq ▸ hj
      (lvs_h[j]'hj).ball (ctx.d + 3) = (g₀.lvs[j]'hj_g).ball ∧
      EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₁
        ctx.P'.activeHandles ctx.P'.handleCoords idx
        (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
        (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) j)
        (decide (j + 1 = lvs_h.length)) ∧
      0 < (wRead m₁ 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat)
    (hw24_last_m1 : wRead m₁ 24 (((2 * (i * ctx.p.D₀ + (g₀.lvs.length - 1)) + 0 : ℕ) : ℤ)) = 2)
    (hpop_c : m_c.popDepth 0 = m_c)
    (hw15_c : wRead m_c 26 15 = (i : ℤ))
    (hw24_c : wRead m_c 26 24 =
      ((jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) lvs_h.length).card : ℤ))
    (hwRem_ic : wRead m_c ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) =
      (((g₀.H_job - (g₀.t_cur + 1) : ℕ) : ℤ)))
    (hw_mc_not : ∀ t, t ≠ 26 → t ≠ ctx.cfg.jobRem.tag → ∀ k, wRead m_c t k = wRead m₁ t k)
    (hr_mc : ∀ t k, rRead m_c t k = rRead m₁ t k) :
    let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
    let jLen := g₀.lvs.length
    let lastIdx := i * ctx.p.D₀ + (jLen - 1)
    let newIdx := i * ctx.p.D₀ + jLen
    let rem' := g₀.H_job - (g₀.t_cur + 1)
    let curRes_h := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) lvs_h.length
    ∃ (m_25 : ArithRAMMemory) (spRS_last dS_n spDS_n rS_n spRS_n : ℕ),
      DetExecAt 0 inp (cg01OpenLevelPrepStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p) m_c m_25
        (freshAllocFourCost ctx.p.D₀ ctx.p.NumSlots + 160) ∧
      m_25.popDepth 0 = m_25 ∧
      0 < spRS_last ∧ spRS_last < ctx.p.NumSlots ∧
      wRead m₁ 23 (((8 * lastIdx + 6 : ℕ) : ℤ)) = (spRS_last : ℤ) ∧
      wRead m₁ 6 (spRS_last : ℤ) = 0 ∧
      0 < dS_n ∧ dS_n < ctx.p.NumSlots ∧ dS_n ∉ activeSlotSet m₁ ctx.p.D₀ ∧
      0 < spDS_n ∧ spDS_n < ctx.p.NumSlots ∧ spDS_n ∉ activeSlotSet m₁ ctx.p.D₀ ∧
      0 < rS_n ∧ rS_n < ctx.p.NumSlots ∧ rS_n ∉ activeSlotSet m₁ ctx.p.D₀ ∧
      0 < spRS_n ∧ spRS_n < ctx.p.NumSlots ∧ spRS_n ∉ activeSlotSet m₁ ctx.p.D₀ ∧
      (spRS_last ≠ dS_n ∧ spRS_last ≠ spDS_n ∧ spRS_last ≠ rS_n ∧ spRS_last ≠ spRS_n ∧
       dS_n ≠ spDS_n ∧ dS_n ≠ rS_n ∧ dS_n ≠ spRS_n ∧
       spDS_n ≠ rS_n ∧ spDS_n ≠ spRS_n ∧ rS_n ≠ spRS_n) ∧
      wRead m_25 26 7 = (newIdx : ℤ) ∧
      wRead m_25 26 1 = (spRS_last : ℤ) ∧
      wRead m_25 26 20 = (dS_n : ℤ) ∧
      wRead m_25 26 21 = (spDS_n : ℤ) ∧
      wRead m_25 26 22 = (rS_n : ℤ) ∧
      wRead m_25 26 23 = (spRS_n : ℤ) ∧
      wRead m_25 26 24 = (curRes_h.card : ℤ) ∧
      wRead m_25 26 25 = (rem' : ℤ) ∧
      1 ≤ wRead m_25 6 (spRS_last : ℤ) ∧
      SegGenBound ctx.p.K_seg ctx.p.NumSlots m_25 ∧
      SaveGenBound ctx.n ctx.p.NumSlots m_25 ∧
      EncLiveCoords ctx.d ctx.n m_25 ctx.P'.activeHandles ctx.P'.handleCoords ∧
      EncSegSlot ctx.p.K_seg m_25 spRS_last curRes_h (fun _ => 0) ∧
      EncSlotCoords ctx.d ctx.n m_25 ctx.P'.activeHandles ctx.P'.handleCoords
        spRS_last curRes_h ctx.P'.handleCoords ∧
      (∀ s < ctx.p.NumSlots, s ≠ dS_n → s ≠ spDS_n → s ≠ rS_n → s ≠ spRS_n →
        ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m_25 s S₁ fSq₁) ∧
      (∀ s : ℕ, s ≠ spRS_last → s ≠ dS_n → s ≠ spDS_n → s ≠ rS_n → s ≠ spRS_n →
        wRead m_25 6 (s : ℤ) = wRead m₁ 6 (s : ℤ)) ∧
      (∀ k, k ≠ 3 → k ≠ 4 → wRead m_25 1 k = wRead m_c 1 k) ∧
      (∀ t, t ≠ 1 → t ≠ 5 → t ≠ 6 → t ≠ 7 → t ≠ 26 → ∀ k, wRead m_25 t k = wRead m_c t k) ∧
      (∀ k, k ≠ 1 → k ≠ 7 → k ≠ 20 → k ≠ 21 → k ≠ 22 → k ≠ 23 → k ≠ 25 →
        wRead m_25 26 k = wRead m_c 26 k) ∧
      (∀ t k, rRead m_25 t k = rRead m_c t k) := by
  classical
  intro r_fin jLen lastIdx newIdx rem' curRes_h
  have hjLen_pos : 1 ≤ jLen := g₀.hlvs_pos
  have hRes_rem := ctx.hV.2.2.2.2.2.2.2.2.2.1
  have hw_mc_res : ∀ t ∈ reservedWordTags, t ≠ 26 → ∀ k, wRead m_c t k = wRead m₁ t k :=
    fun t ht hne26 k => hw_mc_not t hne26 (Ne.symm (tag_ne_of_not_reserved hRes_rem ht)) k
  have hlast_lh : jLen - 1 < lvs_h.length := by rw [hlen_eq]; omega
  have hd_last_t : decide ((jLen - 1) + 1 = lvs_h.length) = true := by
    rw [hlen_eq]; simp only [decide_eq_true_eq]; dsimp only [jLen]; omega
  have hEnc_last_m1 := (hlv_all (jLen - 1) hlast_lh).2.1
  rw [hd_last_t] at hEnc_last_m1
  rcases encJobLevel_phase2_resSlots hEnc_last_m1 hw24_last_m1
    with ⟨_, spRS_last, _, hspRS_last_lt, _, _, hw_spRS_last, _, h6_spRS_iff, _, hSeg_spRS_fn⟩
  have h6_spRS_m1 : wRead m₁ 6 (spRS_last : ℤ) = 0 := h6_spRS_iff.mpr rfl
  have hSeg_spRS_m1 : EncSegSlot ctx.p.K_seg m₁ spRS_last curRes_h (fun _ => 0) := by
    have hE := hSeg_spRS_fn rfl
    have hres_eq : ((lvs_h[jLen - 1]'hlast_lh).ball (ctx.d + 3)).residual ctx.P'.handleCoords
        (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) (jLen - 1)) = curRes_h := by
      have hs := (jobHandleInput_succ (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) hlast_lh).symm
      have heq_len : (jLen - 1) + 1 = lvs_h.length := by rw [hlen_eq]; dsimp only [jLen]; omega
      rwa [heq_len] at hs
    rwa [hres_eq] at hE
  have hspRS_last_pos : 0 < spRS_last := by
    have hp6 : 0 < (wRead m₁ 23 (((8 * lastIdx + 6 : ℕ) : ℤ))).toNat := (hlv_all (jLen - 1) hlast_lh).2.2
    rw [hw_spRS_last] at hp6; simpa using hp6
  have hU_eq : activeSlotSet m_c ctx.p.D₀ = activeSlotSet m₁ ctx.p.D₀ :=
    cg01_activeSlotSet_congr
      (hw_mc_res 1 (by decide) (by decide))
      (hw_mc_res 14 (by decide) (by decide))
      (hw_mc_res 15 (by decide) (by decide))
      (hw_mc_res 16 (by decide) (by decide))
      (hw_mc_res 19 (by decide) (by decide))
      (hw_mc_res 23 (by decide) (by decide))
  rcases pb.hChainRest with ⟨leafS, _, hleaf_lt, hw1_6_m1, _, _, _⟩
  rcases cg01_activePropBuild_gc_hyps pb with ⟨hk_le_D0, hw1_5_m1, hsn_lt_m1, hjob_lt_m1⟩
  have hSeg_c : SegGenBound ctx.p.K_seg ctx.p.NumSlots m_c :=
    ⟨by rw [hw_mc_res 1 (by decide) (by decide)]; exact pb.hSeg.1,
     fun s hs => by rw [hw_mc_res 5 (by decide) (by decide), hw_mc_res 1 (by decide) (by decide)]; exact pb.hSeg.2.1 s hs,
     fun s hs u hu => by rw [hw_mc_res 8 (by decide) (by decide), hw_mc_res 1 (by decide) (by decide)]; exact pb.hSeg.2.2 s hs u hu⟩
  have hSave_c : SaveGenBound ctx.n ctx.p.NumSlots m_c :=
    ⟨by rw [hw_mc_res 1 (by decide) (by decide)]; exact pb.hSave.1,
     fun s hs => by rw [hw_mc_res 6 (by decide) (by decide), hw_mc_res 1 (by decide) (by decide)]; exact pb.hSave.2.1 s hs,
     fun s hs h hh => by rw [hw_mc_res 11 (by decide) (by decide), hw_mc_res 1 (by decide) (by decide)]; exact pb.hSave.2.2 s hs h hh⟩
  rcases exec_freshAllocFourSlotsStmt inp m_c ctx.hSlots_cap ctx.hBox30 ctx.hBox_slots
      hk_le_D0 ((hw_mc_res 1 (by decide) (by decide) 5).trans hw1_5_m1)
      hleaf_lt ((hw_mc_res 1 (by decide) (by decide) 6).trans hw1_6_m1)
      (fun r hr => by
        rcases hsn_lt_m1 r hr with ⟨dS, spS, hd, hsp, e14, e15⟩
        exact ⟨dS, spS, hd, hsp,
          (hw_mc_res 14 (by decide) (by decide) _).trans e14,
          (hw_mc_res 15 (by decide) (by decide) _).trans e15⟩)
      (fun r hr h16 => by
        rw [hw_mc_res 16 (by decide) (by decide)] at h16
        rcases hjob_lt_m1 r hr h16 with ⟨jL, hjL, e19, hsub⟩
        refine ⟨jL, hjL, (hw_mc_res 19 (by decide) (by decide) _).trans e19, fun j hj => ?_⟩
        rcases hsub j hj with ⟨s2, s3, s4, s5, s6, h2, h3, h4, h5, h6, e2, e3, e4, e5, e6⟩
        have hw23_mc := hw_mc_res 23 (by decide) (by decide)
        exact ⟨s2, s3, s4, s5, s6, h2, h3, h4, h5, h6,
          (hw23_mc _).trans e2, (hw23_mc _).trans e3, (hw23_mc _).trans e4,
          (hw23_mc _).trans e5, (hw23_mc _).trans e6⟩)
      hSeg_c hSave_c
    with ⟨m_al, dS_n, spDS_n, rS_n, spRS_n, hd_al, hpop_al,
      hdS_n0, hdS_n_lt, hdS_n_notUc,
      hspDS_n0, hspDS_n_lt, hspDS_n_notUc,
      hrS_n0, hrS_n_lt, hrS_n_notUc,
      hspRS_n0, hspRS_n_lt, hspRS_n_notUc,
      hne_01, hne_02, hne_03, hne_12, hne_13, hne_23,
      hw20_al, hw21_al, hw22_al, hw23_al,
      _, _, _, _, _, hSeg_al, hSave_al, _, _, _, _,
      hSegPres_al, _, hw6_al, hw_oth_al, hw1_al, hw26_al, hr_al⟩
  have hdS_n_notU : dS_n ∉ activeSlotSet m₁ ctx.p.D₀ := hU_eq ▸ hdS_n_notUc
  have hspDS_n_notU : spDS_n ∉ activeSlotSet m₁ ctx.p.D₀ := hU_eq ▸ hspDS_n_notUc
  have hrS_n_notU : rS_n ∉ activeSlotSet m₁ ctx.p.D₀ := hU_eq ▸ hrS_n_notUc
  have hspRS_n_notU : spRS_n ∉ activeSlotSet m₁ ctx.p.D₀ := hU_eq ▸ hspRS_n_notUc
  have hspRS_last_in_U1 : spRS_last ∈ activeSlotSet m₁ ctx.p.D₀ := by
    have hk_nat : (wRead m₁ 1 5).toNat = ctx.st₀.k := by rw [pb.hw1_5]; simp
    have h19_nat : (wRead m₁ 19 (i : ℤ)).toNat = jLen := by rw [pb.hw19_i]; simp [jLen]
    unfold activeSlotSet
    rw [hk_nat]
    apply Finset.mem_insert_of_mem (Finset.mem_insert_of_mem _)
    refine Finset.mem_biUnion.mpr ⟨i, Finset.mem_range.mpr hi, Finset.mem_union_right _ ?_⟩
    unfold jobOwnedSlotSet
    rw [if_pos pb.hw16_i, h19_nat]
    refine Finset.mem_biUnion.mpr ⟨jLen - 1, Finset.mem_range.mpr (by omega), ?_⟩
    unfold jobLevelSlotSet; rw [hw_spRS_last]; simp
  have hspRS_ne4 : spRS_last ≠ dS_n ∧ spRS_last ≠ spDS_n ∧ spRS_last ≠ rS_n ∧ spRS_last ≠ spRS_n :=
    ⟨fun h => hdS_n_notU (h ▸ hspRS_last_in_U1),
     fun h => hspDS_n_notU (h ▸ hspRS_last_in_U1),
     fun h => hrS_n_notU (h ▸ hspRS_last_in_U1),
     fun h => hspRS_n_notU (h ▸ hspRS_last_in_U1)⟩
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let jLenE : IntExpr := .readHeap 19 rE
  let lastIdxE : IntExpr := .add (.mul rE (.lit (ctx.p.D₀ : ℤ))) (.sub jLenE (.lit 1))
  have hw26_15_al : wRead m_al 26 15 = (i : ℤ) :=
    (hw26_al 15 (by decide) (by decide) (by decide) (by decide)).trans hw15_c
  have hw19_i_al : wRead m_al 19 (i : ℤ) = (jLen : ℤ) :=
    (hw_oth_al 19 (by decide) (by decide) (by decide) (by decide) (by decide) _).trans
      ((hw_mc_res 19 (by decide) (by decide) _).trans pb.hw19_i)
  have hw23_spRS_al : wRead m_al 23 (((8 * lastIdx + 6 : ℕ) : ℤ)) = (spRS_last : ℤ) :=
    (hw_oth_al 23 (by decide) (by decide) (by decide) (by decide) (by decide) _).trans
      ((hw_mc_res 23 (by decide) (by decide) _).trans hw_spRS_last)
  have hlastIdx_eval_al : iValAt 0 inp m_al lastIdxE = (lastIdx : ℤ) := by
    simp only [lastIdxE, jLenE, rE, iValAt_add, iValAt_sub, iValAt_mul, iValAt_readHeap, iValAt_lit, hw26_15_al, hw19_i_al]
    dsimp only [lastIdx, jLen]; omega
  let m_b := wWrite m_al 26 1 (spRS_last : ℤ)
  have hpop_b : m_b.popDepth 0 = m_b := wWrite_popDepth_zero hpop_al 26 1 _
  have hd_b : DetExecAt 0 inp
      (boxWriteW ctx.M_box 26 (.lit 1) (.readHeap 23 (.add (.mul (.lit 8) lastIdxE) (.lit 6))))
      m_al m_b 35 :=
    exec_boxWriteW inp m_al _ _ rfl (by omega) (by have := ctx.hBox30; omega)
      (by
        change wRead m_al 23 (8 * iValAt 0 inp m_al lastIdxE + 6) = (spRS_last : ℤ)
        rw [hlastIdx_eval_al]
        have heq_idx : (8 * (lastIdx : ℤ) + 6) = (((8 * lastIdx + 6 : ℕ) : ℤ)) := by push_cast; ring
        rw [heq_idx, hw23_spRS_al])
      (by simp [lastIdxE, jLenE, rE, intExprOps])
  have hsub_cur := (cg01_curRes_bij ctx hi lvs_h g₀.lvs hlen_eq (fun j hj => (hlv_all j hj).1)).1
  have hlt_cur : ∀ h ∈ curRes_h, h < ctx.n := fun h hh => pb.hLive.1 h (hsub_cur hh)
  have hSeg_b : SegGenBound ctx.p.K_seg ctx.p.NumSlots m_b :=
    ⟨by simp [m_b]; exact hSeg_al.1,
     fun s hs => by simp [m_b]; exact hSeg_al.2.1 s hs,
     fun s hs u hu => by simp [m_b]; exact hSeg_al.2.2 s hs u hu⟩
  have hSave_b : SaveGenBound ctx.n ctx.p.NumSlots m_b :=
    ⟨by simp [m_b]; exact hSave_al.1,
     fun s hs => by simp [m_b]; exact hSave_al.2.1 s hs,
     fun s hs h hh => by simp [m_b]; exact hSave_al.2.2 s hs h hh⟩
  rcases exec_freezeSlot26_1Stmt inp m_b (activeH := ctx.P'.activeHandles) (livePts := ctx.P'.handleCoords)
      (S := curRes_h) hspRS_last_lt (by simp [m_b])
      (by have := ctx.hBox30; omega) ctx.hBox_slots hSeg_b hSave_b hsub_cur hlt_cur
    with ⟨m_frz, hd_frz, hpop_frz, hSeg_frz, hSave_frz, h6_spRS_frz, hSlot_spRS_frz, _,
      hw6_frz, hw_oth_frz, hw1_frz, hr_frz⟩
  have hw26_15_frz : wRead m_frz 26 15 = (i : ℤ) := by
    rw [hw_oth_frz 26 (by decide) (by decide)]; simp [m_b, hw26_15_al]
  have hw19_i_frz : wRead m_frz 19 (i : ℤ) = (jLen : ℤ) := by
    rw [hw_oth_frz 19 (by decide) (by decide)]; simp [m_b, hw19_i_al]
  let m_7 := wWrite m_frz 26 7 (newIdx : ℤ)
  have hpop_7 : m_7.popDepth 0 = m_7 := wWrite_popDepth_zero hpop_frz 26 7 _
  have hd_7 : DetExecAt 0 inp
      (boxWriteW ctx.M_box 26 (.lit 7) (.add (.mul rE (.lit (ctx.p.D₀ : ℤ))) jLenE))
      m_frz m_7 25 :=
    exec_boxWriteW inp m_frz _ _ rfl (by omega) (by have := ctx.hBox30; omega)
      (by simp only [jLenE, rE, iValAt_add, iValAt_mul, iValAt_readHeap, iValAt_lit, hw26_15_frz, hw19_i_frz]; dsimp only [newIdx]; push_cast; ring)
      (by simp [jLenE, rE, intExprOps])
  have hwRem_i_7 : wRead m_7 ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) = (rem' : ℤ) := by
    have htag_rem_ne : ∀ u ∈ reservedWordTags, ctx.cfg.jobRem.tag ≠ u :=
      fun u hu => tag_ne_of_not_reserved hRes_rem hu
    dsimp only [m_7]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (htag_rem_ne 26 (by decide))),
        hw_oth_frz _ (htag_rem_ne 1 (by decide)) (htag_rem_ne 6 (by decide))]
    dsimp only [m_b]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (htag_rem_ne 26 (by decide))),
        hw_oth_al _ (htag_rem_ne 1 (by decide)) (htag_rem_ne 5 (by decide))
          (htag_rem_ne 6 (by decide)) (htag_rem_ne 7 (by decide)) (htag_rem_ne 26 (by decide)),
        hwRem_ic]
  have hw26_15_7 : wRead m_7 26 15 = (i : ℤ) := by
    dsimp only [m_7]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw26_15_frz]
  let m_25 := wWrite m_7 26 25 (rem' : ℤ)
  have hpop_25 : m_25.popDepth 0 = m_25 := wWrite_popDepth_zero hpop_7 26 25 _
  have hd_25 : DetExecAt 0 inp
      (boxWriteW ctx.M_box 26 (.lit 25) (ctx.cfg.jobRem.readE rE))
      m_7 m_25 25 :=
    exec_boxWriteW inp m_7 _ _ rfl (by omega) (by have := ctx.hBox30; omega)
      (by
        simp only [HdrField.readE, HdrField.idxE, rE, iValAt_add, iValAt_mul, iValAt_readHeap, iValAt_lit, hw26_15_7]
        have hidx_eq : ((ctx.cfg.jobRem.stride : ℤ) * (i : ℤ) + (ctx.cfg.jobRem.off : ℤ)) =
            (ctx.cfg.jobRem.idx i : ℤ) := by unfold HdrField.idx; push_cast; ring
        rw [hidx_eq, hwRem_i_7])
      (by simp [HdrField.readE, HdrField.idxE, rE, intExprOps])
  have hw25_not26 : ∀ t, t ≠ 26 → ∀ k, wRead m_25 t k = wRead m_frz t k := by
    intro t ht k; dsimp only [m_25, m_7]
    rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
  have hr25_c : ∀ t k, rRead m_25 t k = rRead m_c t k := by
    intro t k; dsimp only [m_25, m_7]
    rw [rRead_wWrite, rRead_wWrite, hr_frz]; dsimp only [m_b]; rw [rRead_wWrite, hr_al]
  have hw25_26_prev : ∀ k, k ≠ 1 → k ≠ 7 → k ≠ 25 → wRead m_25 26 k = wRead m_al 26 k := by
    intro k h1 h7 h25; dsimp only [m_25, m_7]
    rw [wRead_wWrite_of_ne _ _ (Or.inr h25), wRead_wWrite_of_ne _ _ (Or.inr h7),
        hw_oth_frz 26 (by decide) (by decide)]
    dsimp only [m_b]; rw [wRead_wWrite_of_ne _ _ (Or.inr h1)]
  have hSegPres_m1_25 : ∀ s < ctx.p.NumSlots, s ≠ dS_n → s ≠ spDS_n → s ≠ rS_n → s ≠ spRS_n →
      ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m_25 s S₁ fSq₁ := by
    intro s hs n0 n1 n2 n3 S₁ fSq₁ hEm1
    have hEc : EncSegSlot ctx.p.K_seg m_c s S₁ fSq₁ :=
      hEm1.congr_mem_fSq (hw_mc_res 5 (by decide) (by decide) _)
        (fun _ _ => hw_mc_res 8 (by decide) (by decide) _)
        (fun _ _ => hw_mc_res 9 (by decide) (by decide) _)
        (fun _ _ => hw_mc_res 10 (by decide) (by decide) _)
        (fun _ _ => hr_mc 8 _) (fun _ _ => rfl)
    exact (hSegPres_al s hs n0 n1 n2 n3 S₁ fSq₁ hEc).congr_mem_fSq
      (by rw [hw25_not26 5 (by decide), hw_oth_frz 5 (by decide) (by decide)]; simp [m_b])
      (fun _ _ => by rw [hw25_not26 8 (by decide), hw_oth_frz 8 (by decide) (by decide)]; simp [m_b])
      (fun _ _ => by rw [hw25_not26 9 (by decide), hw_oth_frz 9 (by decide) (by decide)]; simp [m_b])
      (fun _ _ => by rw [hw25_not26 10 (by decide), hw_oth_frz 10 (by decide) (by decide)]; simp [m_b])
      (fun _ _ => by dsimp only [m_25, m_7]; rw [rRead_wWrite, rRead_wWrite, hr_frz]; simp [m_b])
      (fun _ _ => rfl)
  refine ⟨m_25, spRS_last, dS_n, spDS_n, rS_n, spRS_n,
    (hd_al.seq (hd_b.seq (hd_frz.seq (hd_7.seq hd_25)))).mono_cost (by omega),
    hpop_25, hspRS_last_pos, hspRS_last_lt, hw_spRS_last, h6_spRS_m1,
    hdS_n0, hdS_n_lt, hdS_n_notU, hspDS_n0, hspDS_n_lt, hspDS_n_notU,
    hrS_n0, hrS_n_lt, hrS_n_notU, hspRS_n0, hspRS_n_lt, hspRS_n_notU,
    ⟨hspRS_ne4.1, hspRS_ne4.2.1, hspRS_ne4.2.2.1, hspRS_ne4.2.2.2,
     hne_01, hne_02, hne_03, hne_12, hne_13, hne_23⟩,
    by dsimp only [m_25, m_7]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
    by dsimp only [m_25, m_7]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
         wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw_oth_frz 26 (by decide) (by decide)]; simp [m_b],
    (hw25_26_prev 20 (by decide) (by decide) (by decide)).trans hw20_al,
    (hw25_26_prev 21 (by decide) (by decide) (by decide)).trans hw21_al,
    (hw25_26_prev 22 (by decide) (by decide) (by decide)).trans hw22_al,
    (hw25_26_prev 23 (by decide) (by decide) (by decide)).trans hw23_al,
    (hw25_26_prev 24 (by decide) (by decide) (by decide)).trans
      ((hw26_al 24 (by decide) (by decide) (by decide) (by decide)).trans hw24_c),
    by dsimp only [m_25]; rw [wRead_wWrite_self],
    by rw [hw25_not26 6 (by decide)]; exact h6_spRS_frz,
    ⟨by rw [hw25_not26 1 (by decide)]; exact hSeg_frz.1,
     fun s hs => by rw [hw25_not26 5 (by decide), hw25_not26 1 (by decide)]; exact hSeg_frz.2.1 s hs,
     fun s hs u hu => by rw [hw25_not26 8 (by decide), hw25_not26 1 (by decide)]; exact hSeg_frz.2.2 s hs u hu⟩,
    ⟨by rw [hw25_not26 1 (by decide)]; exact hSave_frz.1,
     fun s hs => by rw [hw25_not26 6 (by decide), hw25_not26 1 (by decide)]; exact hSave_frz.2.1 s hs,
     fun s hs h hh => by rw [hw25_not26 11 (by decide), hw25_not26 1 (by decide)]; exact hSave_frz.2.2 s hs h hh⟩,
    ⟨pb.hLive.1, fun h hh c => by rw [hr25_c, hr_mc]; exact pb.hLive.2 h hh c⟩,
    hSegPres_m1_25 spRS_last hspRS_last_lt hspRS_ne4.1 hspRS_ne4.2.1 hspRS_ne4.2.2.1 hspRS_ne4.2.2.2 _ _ hSeg_spRS_m1,
    hSlot_spRS_frz.congr_mem3 (hw25_not26 6 (by decide) _) (fun _ => hw25_not26 11 (by decide) _)
      (fun _ => by dsimp only [m_25, m_7]; rw [rRead_wWrite, rRead_wWrite]),
    hSegPres_m1_25,
    fun s nsp n0 n1 n2 n3 => by
      rw [hw25_not26 6 (by decide), hw6_frz _ (fun h => nsp (Nat.cast_inj.mp h))]
      dsimp only [m_b]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
          hw6_al _ (fun h => n0 (Nat.cast_inj.mp h)) (fun h => n1 (Nat.cast_inj.mp h))
                   (fun h => n2 (Nat.cast_inj.mp h)) (fun h => n3 (Nat.cast_inj.mp h)),
          hw_mc_res 6 (by decide) (by decide)],
    fun k h3 _ => by
      rw [hw25_not26 1 (by decide), hw1_frz k h3]; dsimp only [m_b]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hw1_al k h3],
    fun t h1 h5 h6 h7 h26 k => by
      rw [hw25_not26 t h26, hw_oth_frz t h1 h6]; dsimp only [m_b]
      rw [wRead_wWrite_of_ne _ _ (Or.inl h26), hw_oth_al t h1 h5 h6 h7 h26],
    fun k h1 h7 h20 h21 h22 h23 h25 =>
      (hw25_26_prev k h1 h7 h25).trans (hw26_al k h20 h21 h22 h23),
    hr25_c⟩

end UL.Proof_lem_7_2_RacerP46
