import UL.Proof.lem_7_2.CG01_MidGlueB1

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 4. Outer `p.D₀`-Step Loop Wrapper & `ActiveUncutNodeSpec → JobTickStageSpec` -/

/-- Interface for the active-uncut single-node body (`26[27] == 0 ∧ i < st₀.k`), matching `CG03_JobTickA3c3`! -/
structure ActiveUncutNodeSpec (d n M_box : ℕ) (p : P46Params d n) where
  nodeStmt : ArithRAMStmt
  C_node : ℕ
  hBoxSafe : BoxSafeOuter 28 M_box nodeStmt
  hPresPool : preservesPoolWords nodeStmt = true
  hExecNode :
    ∀ (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
      {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k) {m : ArithRAMMemory},
      ctx.T_max = 28 →
      ctx.M_box = M_box →
      ctx.cfg = defaultChainHdrCfg →
      ctx.d = d →
      ctx.n = n →
      ctx.H = p.H →
      HEq ctx.p p →
      m.popDepth 0 = m →
      wRead m 26 13 = (ctx.opH : ℤ) →
      wRead m 26 14 = (if ctx.ins then 1 else 0) →
      wRead m 26 15 = (i : ℤ) →
      wRead m 26 28 = (ctx.st₀.k : ℤ) →
      MidLoopUncut ctx gFlag i m →
      RandExecBad inp nodeStmt ctx.p.B_hpj m
        (fun m' =>
          wRead m' 0 0 = wRead m 0 0 ∧
          wRead m' 26 13 = wRead m 26 13 ∧
          wRead m' 26 14 = wRead m 26 14 ∧
          wRead m' 26 15 = (i : ℤ) ∧
          wRead m' 26 28 = wRead m 26 28 ∧
          (MidLoopUncut ctx false (i + 1) m' ∨ MidLoopCut ctx false m'))
        (fun m' =>
          gFlag = true → (MidLoopUncut ctx true (i + 1) m' ∨ MidLoopCut ctx true m'))
        (2 * ctx.p.φ_ev) C_node

def cg01MidLoopIterStmt (d n M_box : ℕ) (p : P46Params d n) (nodeStmt : ArithRAMStmt) : ArithRAMStmt :=
  .seq
    (.ite (.and (.intEq (.readHeap 26 (.lit 27)) (.lit 0))
                (.intLt (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 28))))
      nodeStmt
      (seqList [boxWriteW M_box 26 (.lit 0) (.lit 0), runHPJOnSlotStmt d n M_box p]))
    (boxWriteW M_box 26 (.lit 15) (.add (.readHeap 26 (.lit 15)) (.lit 1)))

def cg01MidLoopFullTickStmt (d n M_box : ℕ) (p : P46Params d n) (nodeStmt : ArithRAMStmt) : ArithRAMStmt :=
  .seq (cg01MidLoopInitStmt M_box)
    (.repeatN (.lit (p.D₀ : ℤ)) (cg01MidLoopIterStmt d n M_box p nodeStmt))

noncomputable def cg01MidLoopIterCost (d n : ℕ) (p : P46Params d n) (C_node : ℕ) : ℕ :=
  20 + max C_node (hpjCallCost d n p + 25) + 20

noncomputable def cg01MidLoopFullTickCost (d n : ℕ) (p : P46Params d n) (C_node : ℕ) : ℕ :=
  120 + (10 + p.D₀ * cg01MidLoopIterCost d n p C_node)

theorem boxSafe_cg01MidLoopFullTickStmt {d n T_max M_box : ℕ}
    (hT : 28 ≤ T_max) (p : P46Params d n) {nodeStmt : ArithRAMStmt}
    (hNode : BoxSafeOuter T_max M_box nodeStmt) :
    BoxSafeOuter T_max M_box (cg01MidLoopFullTickStmt d n M_box p nodeStmt) := by
  refine .seq (boxSafe_cg01MidLoopInitStmt (by omega))
    (.repeatN _ (.seq (.ite _ hNode ?_) (.boxW (by omega) _ _)))
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl
  · exact .boxW (by omega) _ _
  · exact boxSafe_runHPJOnSlotStmt hT p

theorem preservesPoolWords_cg01MidLoopFullTickStmt {d n M_box : ℕ}
    (p : P46Params d n) {nodeStmt : ArithRAMStmt}
    (hNode : preservesPoolWords nodeStmt = true) :
    preservesPoolWords (cg01MidLoopFullTickStmt d n M_box p nodeStmt) = true := by
  unfold cg01MidLoopFullTickStmt cg01MidLoopIterStmt
  simp [hNode]

private lemma midLoopUncut_congr_26_not27 {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ}
    {m m' : ArithRAMMemory} (hU : MidLoopUncut ctx gFlag i m)
    (hw27 : wRead m' 26 27 = wRead m 26 27)
    (hw_other : ∀ tb, tb ≠ 26 → ∀ idx, wRead m' tb idx = wRead m tb idx)
    (hr_other : ∀ tb idx, rRead m' tb idx = rRead m tb idx) :
    MidLoopUncut ctx gFlag i m' := by
  rcases hU with ⟨h27, hGood₀, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, hDone, hTodo⟩
  have hV := ctx.hV
  have hbc_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.1 (by decide)
  have hage_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.1 (by decide)
  have haff_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.1 (by decide)
  have hrem_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.1 (by decide)
  have hcl_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.2.1 (by decide)
  have hSegPres : ∀ s < ctx.p.NumSlots, ∀ S₁ fSq₁,
      EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁ :=
    fun _ _ _ _ hE => hE.congr_mem_fSq
      (hw_other 5 (by decide) _) (fun _ _ => hw_other 8 (by decide) _)
      (fun _ _ => hw_other 9 (by decide) _) (fun _ _ => hw_other 10 (by decide) _)
      (fun _ _ => hr_other 8 _) (fun _ _ => rfl)
  have hDisj' : GlobalSlotDisj ctx.p.D₀ m' ctx.st₀.k leafS :=
    globalSlotDisj_congr_not_0_26 (fun tb _ h26 idx => hw_other tb h26 idx) hDisj
  refine ⟨by rw [hw27]; exact h27, hGood₀,
    ⟨by rw [hw_other 1 (by decide)]; exact hSeg.1,
     fun s hs => by rw [hw_other 5 (by decide), hw_other 1 (by decide)]; exact hSeg.2.1 s hs,
     fun s hs u hu => by rw [hw_other 8 (by decide), hw_other 1 (by decide)]; exact hSeg.2.2 s hs u hu⟩,
    ⟨by rw [hw_other 1 (by decide)]; exact hSave.1,
     fun s hs => by rw [hw_other 6 (by decide), hw_other 1 (by decide)]; exact hSave.2.1 s hs,
     fun s hs h hh => by rw [hw_other 11 (by decide), hw_other 1 (by decide)]; exact hSave.2.2 s hs h hh⟩,
    ⟨hLive.1, fun h hh c => by rw [hr_other 4]; exact hLive.2 h hh c⟩,
    by rw [hw_other 1 (by decide)]; exact h15,
    by rw [hw_other 6 (by decide)]; exact h60,
    hSegPres 0 (by have := ctx.hSlots_cap; omega) _ _ hSeg0,
    leafS, hl0, hllt,
    by rw [hw_other 1 (by decide)]; exact h16l,
    by rw [hw_other 6 (by decide)]; exact h6l,
    hSegPres leafS hllt _ _ hSegL,
    hDisj',
    fun r hr => ?_,
    fun r hr => ?_⟩
  · rcases hDone r hr with ⟨oj, hInv, hGood_r, hHdr, hOwn⟩
    exact ⟨oj, hInv, hGood_r,
      hHdr.frame_other (hw_other _ hbc_ne26 _) (hw_other _ hage_ne26 _)
        (hw_other 14 (by decide) _) (hw_other 15 (by decide) _)
        (fun _ _ => hw_other 6 (by decide) _) (fun _ => hr_other _ _) (hr_other _ _)
        (fun s _ hlt S₁ fSq₁ hE => hSegPres s hlt S₁ fSq₁ hE),
      hOwn.frame_other
        (fun g _ => by rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2))
        (hw_other 16 (by decide) _) (hw_other _ hrem_ne26 _) (hw_other _ hcl_ne26 _)
        (hw_other 19 (by decide) _)
        (fun _ _ _ _ => hw_other 23 (by decide) _) (fun _ _ _ _ => hw_other 24 (by decide) _)
        (fun _ _ _ => hr_other 23 _) (fun _ _ _ _ => hr_other 24 _)
        (fun _ _ _ _ _ => hw_other 6 (by decide) _)
        (fun _ _ _ s _ hlt _ S₁ fSq₁ hE => hSegPres s hlt S₁ fSq₁ hE)
        (fun _ => hw_other 11 (by decide) _) (fun _ => hr_other 11 _)⟩
  · rcases hTodo r hr with ⟨hAff_r, hHdr, hGood_r, hTd⟩
    exact ⟨by rw [hw_other _ haff_ne26]; exact hAff_r,
      hHdr.frame_other (hw_other _ hbc_ne26 _) (hw_other _ hage_ne26 _)
        (hw_other 14 (by decide) _) (hw_other 15 (by decide) _)
        (fun _ _ => hw_other 6 (by decide) _) (fun _ => hr_other _ _) (hr_other _ _)
        (fun s _ hlt S₁ fSq₁ hE => hSegPres s hlt S₁ fSq₁ hE),
      hGood_r,
      hTd.frame_other
        (hw_other 16 (by decide) _) (hw_other _ hrem_ne26 _) (hw_other _ hcl_ne26 _)
        (hw_other 19 (by decide) _)
        (fun _ _ _ _ => hw_other 23 (by decide) _) (fun _ _ _ _ => hw_other 24 (by decide) _)
        (fun _ _ _ => hr_other 23 _) (fun _ _ _ _ => hr_other 24 _)
        (fun _ _ _ _ _ => hw_other 6 (by decide) _)
        (fun _ _ _ s _ hlt _ S₁ fSq₁ hE => hSegPres s hlt S₁ fSq₁ hE)
        (fun _ => hw_other 11 (by decide) _) (fun _ => hr_other 11 _)⟩

private lemma midLoopCut_congr_26_not27 {ctx : MidLoopCtx} {gFlag : Bool}
    {m m' : ArithRAMMemory} (hC : MidLoopCut ctx gFlag m)
    (hw27 : wRead m' 26 27 = wRead m 26 27)
    (hw_other : ∀ tb, tb ≠ 26 → ∀ idx, wRead m' tb idx = wRead m tb idx)
    (hr_other : ∀ tb idx, rRead m' tb idx = rRead m tb idx) :
    MidLoopCut ctx gFlag m' := by
  rcases hC with ⟨h27, st_mid, hu, hInv, hTerm, hEnc, hGood⟩
  rcases hEnc with ⟨hk_le, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, hNodes⟩
  have hV := ctx.hV
  have hbc_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.1 (by decide)
  have hage_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.1 (by decide)
  have hrem_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.1 (by decide)
  have hcl_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.2.1 (by decide)
  have hSegPres : ∀ s < ctx.p.NumSlots, ∀ S₁ fSq₁,
      EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁ :=
    fun _ _ _ _ hE => hE.congr_mem_fSq
      (hw_other 5 (by decide) _) (fun _ _ => hw_other 8 (by decide) _)
      (fun _ _ => hw_other 9 (by decide) _) (fun _ _ => hw_other 10 (by decide) _)
      (fun _ _ => hr_other 8 _) (fun _ _ => rfl)
  have hDisj' : GlobalSlotDisj ctx.p.D₀ m' st_mid.k leafS :=
    globalSlotDisj_congr_not_0_26 (fun tb _ h26 idx => hw_other tb h26 idx) hDisj
  refine ⟨by rw [hw27]; exact h27, st_mid, hu, hInv, hTerm,
    ⟨hk_le,
     ⟨by rw [hw_other 1 (by decide)]; exact hSeg.1,
      fun s hs => by rw [hw_other 5 (by decide), hw_other 1 (by decide)]; exact hSeg.2.1 s hs,
      fun s hs u hu => by rw [hw_other 8 (by decide), hw_other 1 (by decide)]; exact hSeg.2.2 s hs u hu⟩,
     ⟨by rw [hw_other 1 (by decide)]; exact hSave.1,
      fun s hs => by rw [hw_other 6 (by decide), hw_other 1 (by decide)]; exact hSave.2.1 s hs,
      fun s hs h hh => by rw [hw_other 11 (by decide), hw_other 1 (by decide)]; exact hSave.2.2 s hs h hh⟩,
     ⟨hLive.1, fun h hh c => by rw [hr_other 4]; exact hLive.2 h hh c⟩,
     by rw [hw_other 1 (by decide)]; exact h15,
     by rw [hw_other 6 (by decide)]; exact h60,
     hSegPres 0 (by have := ctx.hSlots_cap; omega) _ _ hSeg0,
     leafS, hl0, hllt,
     by rw [hw_other 1 (by decide)]; exact h16l,
     by rw [hw_other 6 (by decide)]; exact h6l,
     hSegPres leafS hllt _ _ hSegL,
     hDisj',
     fun r => ⟨(hNodes r).1.frame_other (hw_other _ hbc_ne26 _) (hw_other _ hage_ne26 _)
                 (hw_other 14 (by decide) _) (hw_other 15 (by decide) _)
                 (fun _ _ => hw_other 6 (by decide) _) (fun _ => hr_other _ _) (hr_other _ _)
                 (fun s _ hlt S₁ fSq₁ hE => hSegPres s hlt S₁ fSq₁ hE),
               (hNodes r).2.frame_other
                 (fun g hg => by
                   rw [ctx.hD0_eq]
                   exact le_of_lt ((st_mid.chainLen_and_jobLen_lt ctx.hP' ctx.hH5 ctx.hn2 hInv).2 r g hg))
                 (hw_other 16 (by decide) _) (hw_other _ hrem_ne26 _) (hw_other _ hcl_ne26 _)
                 (hw_other 19 (by decide) _)
                 (fun _ _ _ _ => hw_other 23 (by decide) _) (fun _ _ _ _ => hw_other 24 (by decide) _)
                 (fun _ _ _ => hr_other 23 _) (fun _ _ _ _ => hr_other 24 _)
                 (fun _ _ _ _ _ => hw_other 6 (by decide) _)
                 (fun _ _ _ s _ hlt _ S₁ fSq₁ hE => hSegPres s hlt S₁ fSq₁ hE)
                 (fun _ => hw_other 11 (by decide) _) (fun _ => hr_other 11 _)⟩⟩,
    hGood⟩

private lemma midLoopUncut_step_past_k {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ}
    (hle : ctx.st₀.k ≤ i) {m : ArithRAMMemory} (hU : MidLoopUncut ctx gFlag i m) :
    MidLoopUncut ctx gFlag (i + 1) m := by
  rcases hU with ⟨h27, hGood₀, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, hDone, _⟩
  exact ⟨h27, hGood₀, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj,
    fun r _ => hDone r (lt_of_lt_of_le r.isLt hle),
    fun r hr => absurd (lt_of_lt_of_le r.isLt hle) (by omega)⟩

noncomputable def mkJobTickStageSpec_of_activeUncutNode
    {cHpj cBase d n t M_box : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (hM : p46BoxSize d n p ≤ M_box)
    (nodeSpec : ActiveUncutNodeSpec d n M_box p) :
    JobTickStageSpec cHpj cBase d n t δ p := by
  refine mkJobTickStageSpec_of_encFullChainAndJobs
    (cg01MidLoopFullTickStmt d n M_box p nodeSpec.nodeStmt)
    28 M_box (p.D₀ * p.B_hpj) (cg01MidLoopFullTickCost d n p nodeSpec.C_node)
    ((p.D₀ : ℝ) * (2 * p.φ_ev))
    (le_refl 28) hM
    (boxSafe_cg01MidLoopFullTickStmt (le_refl 28) p nodeSpec.hBoxSafe)
    (preservesPoolWords_cg01MidLoopFullTickStmt p nodeSpec.hPresPool)
    (by
      have hφ_nn : 0 ≤ 2 * p.φ_ev := by have := hp.hφ0; linarith
      have hD0_le : (p.D₀ : ℝ) ≤ (((p.D₀ + 2 : ℕ) : ℝ)) := by exact_mod_cast Nat.le_add_right p.D₀ 2
      exact mul_le_mul_of_nonneg_right hD0_le hφ_nn)
    ?_
  intro P op m_pre st₀ mem_rt P' opH uMap' P_good₀ hGood₀ ctx
  classical
  let inp := mkStepInput n P op
  let loopCtx := cg01_mkMidLoopCtx hp hn hM ctx
  let retH0 := wRead mem_rt 0 0
  rcases exec_cg01MidLoopInitStmt hp hn hM ctx with ⟨m_init, e_init, hpop_init, hSt0_f, hSt0_t⟩
  let SafeInv : ℕ → ArithRAMMemory → Prop := fun i m => MidLoopState loopCtx retH0 false i m
  let GoodInv : ℕ → ArithRAMMemory → Prop := fun i m => MidLoopState loopCtx retH0 true i m
  have hstep : ∀ i < p.D₀, ∀ m, m.popDepth 0 = m → SafeInv i m →
      RandExecBad inp (cg01MidLoopIterStmt d n M_box p nodeSpec.nodeStmt) p.B_hpj m
        (SafeInv (i + 1)) (fun m'' => GoodInv i m → GoodInv (i + 1) m'')
        (2 * p.φ_ev) (cg01MidLoopIterCost d n p nodeSpec.C_node) := by
    have hBox30 : 30 ≤ M_box := loopCtx.hBox30
    intro i _ m hpop_m hs
    rcases hs with ⟨hw00, hw13, hw14, hw15_i, hw28_k, hor_s⟩
    change wRead m 26 28 = (st₀.k : ℤ) at hw28_k
    let condE : ArithCondExpr :=
      .and (.intEq (.readHeap 26 (.lit 27)) (.lit 0))
           (.intLt (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 28)))
    have hcond_ops : condExprOps condE ≤ 20 := by simp [condE, condExprOps, intExprOps]
    let C_br := max nodeSpec.C_node (hpjCallCost d n p + 25)
    let PreIncSafe : ArithRAMMemory → Prop := fun m' =>
      wRead m' 0 0 = retH0 ∧
      wRead m' 26 13 = (opH : ℤ) ∧
      wRead m' 26 14 = (if loopCtx.ins then 1 else 0) ∧
      wRead m' 26 15 = (i : ℤ) ∧
      wRead m' 26 28 = (st₀.k : ℤ) ∧
      (MidLoopUncut loopCtx false (i + 1) m' ∨ MidLoopCut loopCtx false m')
    let PreIncGood : ArithRAMMemory → Prop := fun m' =>
      GoodInv i m → (MidLoopUncut loopCtx true (i + 1) m' ∨ MidLoopCut loopCtx true m')
    have hIteBranch : RandExecBad inp
        (.ite condE nodeSpec.nodeStmt
          (seqList [boxWriteW M_box 26 (.lit 0) (.lit 0), runHPJOnSlotStmt d n M_box p]))
        p.B_hpj m PreIncSafe PreIncGood (2 * p.φ_ev) (20 + C_br) := by
      rcases hor_s with hU_f | hC_f
      · by_cases hi_k : i < st₀.k
        · -- Active uncut branch: 26[27] == 0 ∧ i < st₀.k
          have hc_true : cValAt 0 inp m condE = true := by
            simp only [condE, cValAt, evalArithCond, evalIntExpr]
            change (decide (wRead m 26 27 = 0) && decide (wRead m 26 15 < wRead m 26 28)) = true
            rw [hU_f.1, hw15_i, hw28_k]
            simp [hi_k]
          by_cases hG_m : GoodInv i m
          · have hU_t : MidLoopUncut loopCtx true i m := by
              rcases hG_m.2.2.2.2.2 with hUt | hCt
              · exact hUt
              · have h0 := hU_f.1; have h1 := hCt.1; omega
            have hNode := nodeSpec.hExecNode loopCtx inp hi_k rfl rfl rfl rfl rfl rfl HEq.rfl
              hpop_m hw13 hw14 hw15_i hw28_k hU_t
            have hNode' := RandExecBad.ite_true
              (fB := seqList [boxWriteW M_box 26 (.lit 0) (.lit 0), runHPJOnSlotStmt d n M_box p])
              hc_true hcond_ops hNode
            refine hNode'.mono ?_ ?_ le_rfl (Nat.add_le_add_left (le_max_left _ _) 20)
            · rintro m' ⟨e0, e13, e14, e15, e28, hor'⟩
              exact ⟨e0.trans hw00, e13.trans hw13, e14.trans hw14, e15, e28.trans hw28_k, hor'⟩
            · intro m' _ hg' _; exact hg' rfl
          · have hNode := nodeSpec.hExecNode loopCtx inp hi_k rfl rfl rfl rfl rfl rfl HEq.rfl
              hpop_m hw13 hw14 hw15_i hw28_k hU_f
            have hNode' := RandExecBad.ite_true
              (fB := seqList [boxWriteW M_box 26 (.lit 0) (.lit 0), runHPJOnSlotStmt d n M_box p])
              hc_true hcond_ops hNode
            refine hNode'.mono ?_ ?_ le_rfl (Nat.add_le_add_left (le_max_left _ _) 20)
            · rintro m' ⟨e0, e13, e14, e15, e28, hor'⟩
              exact ⟨e0.trans hw00, e13.trans hw13, e14.trans hw14, e15, e28.trans hw28_k, hor'⟩
            · intro _ _ _ hg_in; exact False.elim (hG_m hg_in)
        · -- Uncut but i ≥ st₀.k: false branch (dummy HPJ)
          have hk_le_i : st₀.k ≤ i := by omega
          have hc_false : cValAt 0 inp m condE = false := by
            simp only [condE, cValAt, evalArithCond, evalIntExpr]
            change (decide (wRead m 26 27 = 0) && decide (wRead m 26 15 < wRead m 26 28)) = false
            rw [hw15_i, hw28_k]
            simp [hi_k]
          have hDum := exec_dummyHPJStmt (M_box := M_box) p inp m hpop_m (by omega) (le_of_lt hp.hφ0)
          have hIte := RandExecBad.ite_false (tB := nodeSpec.nodeStmt) hc_false hcond_ops hDum
          refine hIte.mono ?_ ?_ le_rfl (Nat.add_le_add_left (le_max_right _ _) 20)
          · intro m' hm'; subst hm'
            refine ⟨(by simp : wRead (wWrite m 26 0 0) 0 0 = wRead m 0 0).trans hw00,
              (by simp : wRead (wWrite m 26 0 0) 26 13 = wRead m 26 13).trans hw13,
              (by simp : wRead (wWrite m 26 0 0) 26 14 = wRead m 26 14).trans hw14,
              (by simp : wRead (wWrite m 26 0 0) 26 15 = wRead m 26 15).trans hw15_i,
              (by simp : wRead (wWrite m 26 0 0) 26 28 = wRead m 26 28).trans hw28_k,
              Or.inl (midLoopUncut_congr_26_not27 (midLoopUncut_step_past_k hk_le_i hU_f)
                (by simp) (fun tb hne _ => by simp [hne]) (fun _ _ => by simp))⟩
          · intro m' hm' _ hG_in; subst hm'
            rcases hG_in.2.2.2.2.2 with hUt | hCt
            · exact Or.inl (midLoopUncut_congr_26_not27 (midLoopUncut_step_past_k hk_le_i hUt)
                (by simp) (fun tb hne _ => by simp [hne]) (fun _ _ => by simp))
            · exact Or.inr (midLoopCut_congr_26_not27 hCt
                (by simp) (fun tb hne _ => by simp [hne]) (fun _ _ => by simp))
      · -- Already cut (wRead m 26 27 = 1): false branch (dummy HPJ)
        have hc_false : cValAt 0 inp m condE = false := by
          simp only [condE, cValAt, evalArithCond, evalIntExpr]
          change (decide (wRead m 26 27 = 0) && decide (wRead m 26 15 < wRead m 26 28)) = false
          rw [hC_f.1]; simp
        have hDum := exec_dummyHPJStmt (M_box := M_box) p inp m hpop_m (by omega) (le_of_lt hp.hφ0)
        have hIte := RandExecBad.ite_false (tB := nodeSpec.nodeStmt) hc_false hcond_ops hDum
        refine hIte.mono ?_ ?_ le_rfl (Nat.add_le_add_left (le_max_right _ _) 20)
        · intro m' hm'; subst hm'
          exact ⟨(by simp : wRead (wWrite m 26 0 0) 0 0 = wRead m 0 0).trans hw00,
            (by simp : wRead (wWrite m 26 0 0) 26 13 = wRead m 26 13).trans hw13,
            (by simp : wRead (wWrite m 26 0 0) 26 14 = wRead m 26 14).trans hw14,
            (by simp : wRead (wWrite m 26 0 0) 26 15 = wRead m 26 15).trans hw15_i,
            (by simp : wRead (wWrite m 26 0 0) 26 28 = wRead m 26 28).trans hw28_k,
            Or.inr (midLoopCut_congr_26_not27 hC_f
              (by simp) (fun tb hne _ => by simp [hne]) (fun _ _ => by simp))⟩
        · intro m' hm' _ hG_in; subst hm'
          rcases hG_in.2.2.2.2.2 with hUt | hCt
          · have h0 := hUt.1; have h1 := hC_f.1; omega
          · exact Or.inr (midLoopCut_congr_26_not27 hCt
              (by simp) (fun tb hne _ => by simp [hne]) (fun _ _ => by simp))
    -- Increment 26[15] := i + 1
    refine (RandExecBad.seq_det_right hpop_m hIteBranch ?_).mono
      (fun _ hs => hs) (fun _ _ hg => hg) le_rfl le_rfl
    intro m' hpop_m' ⟨e0, e13, e14, e15, e28, hor'⟩
    let m'' := wWrite m' 26 15 (((i + 1 : ℕ) : ℤ))
    have e_inc : DetExecAt 0 inp
        (boxWriteW M_box 26 (.lit 15) (.add (.readHeap 26 (.lit 15)) (.lit 1))) m' m'' 20 :=
      exec_boxWriteW inp m' _ _ rfl (by omega) (by omega)
        (by simp [e15]) (by simp [intExprOps])
    have hpop_m'' : m''.popDepth 0 = m'' := wWrite_popDepth_zero hpop_m' 26 15 _
    have liftOr : ∀ {gF : Bool},
        (MidLoopUncut loopCtx gF (i + 1) m' ∨ MidLoopCut loopCtx gF m') →
        (MidLoopUncut loopCtx gF (i + 1) m'' ∨ MidLoopCut loopCtx gF m'') := by
      rintro gF (hU | hC)
      · exact Or.inl (midLoopUncut_congr_26_not27 hU
          (by simp [m'']) (fun tb hne _ => by simp [m'', hne]) (fun _ _ => by simp [m'']))
      · exact Or.inr (midLoopCut_congr_26_not27 hC
          (by simp [m'']) (fun tb hne _ => by simp [m'', hne]) (fun _ _ => by simp [m'']))
    have hw0_m'' : wRead m'' 0 0 = retH0 := (by simp [m''] : wRead m'' 0 0 = wRead m' 0 0).trans e0
    have hw13_m'' : wRead m'' 26 13 = (loopCtx.opH : ℤ) := (by simp [m''] : wRead m'' 26 13 = wRead m' 26 13).trans e13
    have hw14_m'' : wRead m'' 26 14 = (if loopCtx.ins then 1 else 0) := (by simp [m''] : wRead m'' 26 14 = wRead m' 26 14).trans e14
    have hw15_m'' : wRead m'' 26 15 = (((i + 1 : ℕ) : ℤ)) := by simp [m'']
    have hw28_m'' : wRead m'' 26 28 = (loopCtx.st₀.k : ℤ) := (by simp [m''] : wRead m'' 26 28 = wRead m' 26 28).trans e28
    exact ⟨m'', e_inc, hpop_m'',
      ⟨hw0_m'', hw13_m'', hw14_m'', hw15_m'', hw28_m'', liftOr hor'⟩,
      fun hg_imp hG_in =>
        ⟨hw0_m'', hw13_m'', hw14_m'', hw15_m'', hw28_m'', liftOr (hg_imp hG_in)⟩⟩
  have hRep := RandExecBad.repeatN_nat
    (.lit (p.D₀ : ℤ)) (cg01MidLoopIterStmt d n M_box p nodeSpec.nodeStmt)
    p.D₀ p.B_hpj 10 (cg01MidLoopIterCost d n p nodeSpec.C_node)
    (by have := hp.hφ0; linarith) SafeInv GoodInv hpop_init hSt0_f rfl (by simp [intExprOps]) hstep
  have hFull := RandExecBad.seq_det_left ctx.hpop_rt hpop_init e_init hRep
  refine hFull.mono ?_ ?_ le_rfl le_rfl
  · intro m_end hs_end
    rcases cg01_extract_st_mid_of_end loopCtx hs_end.2.2.2.2.2 with ⟨st_mid, _, hInv, hLeaf, hEnc, _⟩
    exact ⟨st_mid, hInv, hLeaf, hEnc⟩
  · intro m_end _ hg_end hPG₀
    have hG_init : GoodInv 0 m_init := hSt0_t (hGood₀ hPG₀)
    rcases cg01_extract_st_mid_of_end loopCtx (hg_end hG_init).2.2.2.2.2
      with ⟨st_mid, _, hInv, hLeaf, hEnc, hGood_mid⟩
    exact ⟨st_mid, hInv, hLeaf, hEnc, hGood_mid rfl⟩

/-! ### 5. Universal Polynomial Cost Bound for `cg01MidLoopFullTickCost` & Top-Level Bridge -/

noncomputable def cg01MaxSingleNodeCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  freshAllocFiveCost p.D₀ p.NumSlots +
  hpjFreezeRunInitCost d n p +
  propagateAllJobLevelsCost d p.D₀ p.K_seg +
  deadlineSuffixSwapCost d p.D₀ +
  2400 * (p.K_batch + 1) * (p.K_seg + d + 5) +
  5000 * (p.K_seg + d + 5) +
  10000

def cg01JobTickPolyConst (cHpj cBase K_mult : ℕ) : ℕ :=
  let C_hpj0 := cHpj * 21 ^ 3
  let C_mb := 105 + cHpj + 4 * cBase
  130 +
    (K_mult + 1) * (
      2 * (196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) +
      46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
        16 * (C_hpj0 * (C_mb + 1)) + 500) +
      4 * (625 * (2400 * 16777218 * 3 + 15000))
    )

private lemma cg01_mul_sum3_P19 (a b c P : ℕ) :
    a * P + b * P + c * P = (a + b + c) * P := by
  ring

theorem cg01MidLoopFullTickCost_poly_le
    {cHpj cBase d n t C_node K_mult : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (hC_le : C_node ≤ K_mult * cg01MaxSingleNodeCost d n p) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    cg01MidLoopFullTickCost d n p C_node ≤
      cg01JobTickPolyConst cHpj cBase K_mult * (D ^ 19 * H ^ 18) := by
  intro D H
  let P19 := D ^ 19 * H ^ 18
  rcases hp.all_component_costs_poly_le hn
    with ⟨h1_P19, _, _, _, _, hHpjTot, _, _, hJobTot, hGCTot⟩
  set K_gc : ℕ := 196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500) with hKgc_def
  set K_hpj : ℕ := 46 * (250 * (cHpj * 21 ^ 3 + 1) * (105 + cHpj + 4 * cBase + 4) +
      600 + 8 * (cHpj * 21 ^ 3) +
      16 * ((cHpj * 21 ^ 3) * (105 + cHpj + 4 * cBase + 1)) + 500) with hKhpj_def
  set K_job : ℕ := 625 * (2400 * 16777218 * 3 + 15000) with hKjob_def
  try rw [← hKgc_def] at hGCTot
  try rw [← hKhpj_def] at hHpjTot
  try rw [← hKjob_def] at hJobTot
  let G1 := 40 * p.NumSlots + 300 * (p.D₀ + 1) * (p.D₀ + 1) + 35 * (p.NumSlots + 1) + 500
  let J1 := 2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5)
  have halloc5 : freshAllocFiveCost p.D₀ p.NumSlots ≤ 5 * G1 := by
    unfold freshAllocFiveCost freshAllocFourCost; dsimp only [G1]; omega
  have h_gc : p.D₀ * freshAllocFiveCost p.D₀ p.NumSlots ≤ (2 * K_gc) * P19 := by
    calc p.D₀ * freshAllocFiveCost p.D₀ p.NumSlots
        ≤ p.D₀ * (5 * G1) := Nat.mul_le_mul_left _ halloc5
      _ = (5 * p.D₀) * G1 := by ring
      _ ≤ (2 * (4 * p.D₀ + 80 * D ^ 2 + 20)) * G1 := Nat.mul_le_mul_right G1 (by omega)
      _ = 2 * ((4 * p.D₀ + 80 * D ^ 2 + 20) * G1) := by ring
      _ ≤ 2 * (K_gc * P19) := Nat.mul_le_mul_left 2 hGCTot
      _ = (2 * K_gc) * P19 := (Nat.mul_assoc _ _ _).symm
  have h_hpj : p.D₀ * hpjCallCost d n p ≤ K_hpj * P19 :=
    le_trans (Nat.mul_le_mul_right _ (by omega : p.D₀ ≤ p.D₀ + 20 * D ^ 2 + 2)) hHpjTot
  have h_prop : propagateAllJobLevelsCost d p.D₀ p.K_seg ≤ (p.D₀ + 2) * J1 := by
    unfold propagateAllJobLevelsCost
    have h1 : (1100 * (p.K_seg + 1) + 150 * (d + 1) + 800) + 100 ≤ J1 := by dsimp only [J1]; omega
    have h2 : 150 ≤ 2 * J1 := by dsimp only [J1]; omega
    calc p.D₀ * ((1100 * (p.K_seg + 1) + 150 * (d + 1) + 800) + 100) + 150
        ≤ p.D₀ * J1 + 2 * J1 := Nat.add_le_add (Nat.mul_le_mul_left _ h1) h2
      _ = (p.D₀ + 2) * J1 := by ring
  have h_swap : deadlineSuffixSwapCost d p.D₀ ≤ (p.D₀ + 2) * J1 := by
    unfold deadlineSuffixSwapCost
    have h1 : 90 * (d + 1) + 400 ≤ J1 := by dsimp only [J1]; omega
    have h2 : 200 ≤ 2 * J1 := by dsimp only [J1]; omega
    calc p.D₀ * (90 * (d + 1) + 400) + 200
        ≤ p.D₀ * J1 + 2 * J1 := Nat.add_le_add (Nat.mul_le_mul_left _ h1) h2
      _ = (p.D₀ + 2) * J1 := by ring
  have h_rest1 : (100 * (p.K_seg + 1) + 180 * (d + 1) + 150) + (120 * (d + 1) + 400) + 50 +
      2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5) + 10065 ≤ 2 * (p.D₀ + 2) * J1 := by
    have hsum : (100 * (p.K_seg + 1) + 180 * (d + 1) + 150) + (120 * (d + 1) + 400) + 50 +
        2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5) + 10065 ≤ 4 * J1 := by
      dsimp only [J1]; omega
    calc _ ≤ 4 * J1 := hsum
      _ ≤ (2 * (p.D₀ + 2)) * J1 := Nat.mul_le_mul_right J1 (by omega)
  have h_max_plus : p.D₀ * (cg01MaxSingleNodeCost d n p + 65) ≤
      (2 * K_gc + K_hpj + 4 * K_job) * P19 := by
    have hexp : cg01MaxSingleNodeCost d n p + 65 =
        freshAllocFiveCost p.D₀ p.NumSlots + hpjCallCost d n p +
        (propagateAllJobLevelsCost d p.D₀ p.K_seg + deadlineSuffixSwapCost d p.D₀ +
          ((100 * (p.K_seg + 1) + 180 * (d + 1) + 150) + (120 * (d + 1) + 400) + 50 +
           2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5) + 10065)) := by
      unfold cg01MaxSingleNodeCost hpjFreezeRunInitCost; omega
    have h_job4 : p.D₀ * (propagateAllJobLevelsCost d p.D₀ p.K_seg + deadlineSuffixSwapCost d p.D₀ +
          ((100 * (p.K_seg + 1) + 180 * (d + 1) + 150) + (120 * (d + 1) + 400) + 50 +
           2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5) + 10065)) ≤
        (4 * K_job) * P19 := by
      have h3sum := Nat.add_le_add (Nat.add_le_add h_prop h_swap) h_rest1
      have h3eq : (p.D₀ + 2) * J1 + (p.D₀ + 2) * J1 + 2 * (p.D₀ + 2) * J1 = 4 * ((p.D₀ + 2) * J1) := by ring
      rw [h3eq] at h3sum
      calc p.D₀ * _ ≤ p.D₀ * (4 * ((p.D₀ + 2) * J1)) := Nat.mul_le_mul_left _ h3sum
        _ ≤ (p.D₀ + 2) * (4 * ((p.D₀ + 2) * J1)) := Nat.mul_le_mul_right _ (by omega)
        _ = 4 * ((p.D₀ + 2) * (p.D₀ + 2) * J1) := by ring
        _ ≤ 4 * (K_job * P19) := Nat.mul_le_mul_left 4 hJobTot
        _ = (4 * K_job) * P19 := (Nat.mul_assoc _ _ _).symm
    rw [hexp, Nat.mul_add, Nat.mul_add]
    have htot := Nat.add_le_add (Nat.add_le_add h_gc h_hpj) h_job4
    rwa [cg01_mul_sum3_P19] at htot
  have hiter_le : cg01MidLoopIterCost d n p C_node ≤
      (K_mult + 1) * (cg01MaxSingleNodeCost d n p + 65) := by
    unfold cg01MidLoopIterCost
    have hhpj_le : hpjCallCost d n p + 25 ≤ cg01MaxSingleNodeCost d n p + 25 := by
      unfold cg01MaxSingleNodeCost hpjFreezeRunInitCost; omega
    have hmax_le : max C_node (hpjCallCost d n p + 25) ≤
        K_mult * cg01MaxSingleNodeCost d n p + (cg01MaxSingleNodeCost d n p + 25) :=
      max_le (le_trans hC_le (Nat.le_add_right _ _)) (le_trans hhpj_le (Nat.le_add_left _ _))
    calc 20 + max C_node (hpjCallCost d n p + 25) + 20
        ≤ 20 + (K_mult * cg01MaxSingleNodeCost d n p + (cg01MaxSingleNodeCost d n p + 25)) + 20 := by omega
      _ ≤ (K_mult + 1) * (cg01MaxSingleNodeCost d n p + 65) := by
          have : K_mult * cg01MaxSingleNodeCost d n p ≤ K_mult * (cg01MaxSingleNodeCost d n p + 65) :=
            Nat.mul_le_mul_left K_mult (Nat.le_add_right _ 65)
          rw [Nat.succ_mul]; omega
  unfold cg01MidLoopFullTickCost cg01JobTickPolyConst
  dsimp only
  simp only [← hKgc_def, ← hKhpj_def, ← hKjob_def]
  have h130 : 130 ≤ 130 * P19 := Nat.le_mul_of_pos_right 130 h1_P19
  have hloop_cost : p.D₀ * cg01MidLoopIterCost d n p C_node ≤
      ((K_mult + 1) * (2 * K_gc + K_hpj + 4 * K_job)) * P19 := by
    calc p.D₀ * cg01MidLoopIterCost d n p C_node
        ≤ p.D₀ * ((K_mult + 1) * (cg01MaxSingleNodeCost d n p + 65)) := Nat.mul_le_mul_left _ hiter_le
      _ = (K_mult + 1) * (p.D₀ * (cg01MaxSingleNodeCost d n p + 65)) := by ring
      _ ≤ (K_mult + 1) * ((2 * K_gc + K_hpj + 4 * K_job) * P19) := Nat.mul_le_mul_left _ h_max_plus
      _ = _ := (Nat.mul_assoc _ _ _).symm
  have heq130 : 120 + (10 + p.D₀ * cg01MidLoopIterCost d n p C_node) =
      130 + p.D₀ * cg01MidLoopIterCost d n p C_node := by omega
  rw [heq130, Nat.add_mul]
  exact Nat.add_le_add h130 hloop_cost

/-- One-call closer for `S_lem_7_2` directly from `ActiveUncutNodeSpec`! -/
theorem prove_S_lem_7_2_of_activeUncutNodeSpec
    (h_lem_5_1 : S_lem_5_1)
    (h_lem_5_2 : S_lem_5_2)
    (h_fb : S_clm_7_3_failure_budget)
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    (C_cap K_mult : ℕ)
    (hBuildNode : ∀ (d n t : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        C_cap * (D ^ 4 * H ^ 2) < n →
        ∀ (p : P46Params d n),
          P46ParamsValid cHpj (extractCBaseNat h_mc) d n t δ p →
          ∃ nodeSpec : ActiveUncutNodeSpec d n (p46BoxSize d n p) p,
            nodeSpec.C_node ≤ K_mult * cg01MaxSingleNodeCost d n p) :
    S_lem_7_2 := by
  let cBase : ℕ := extractCBaseNat h_mc
  refine prove_S_lem_7_2_of_jobTickStageSpec h_lem_5_1 h_lem_5_2 h_fb h_mc hcHpj
    C_cap (cg01JobTickPolyConst cHpj cBase K_mult) ?_
  intro d n t hd1 hn ht δ hδ0 hδ1 D H hcap p hp
  rcases hBuildNode d n t hd1 hn ht δ hδ0 hδ1 hcap p hp with ⟨nodeSpec, hC_le⟩
  exact ⟨mkJobTickStageSpec_of_activeUncutNode hp hn le_rfl nodeSpec,
    rfl, rfl, cg01MidLoopFullTickCost_poly_le hp hn hC_le⟩

end UL.Proof_lem_7_2_RacerP46
