import UL.Proof.lem_7_2.CG14_MidTickA1b

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 2. Active Affected Job Phase 1b: `exec_propAndBuildActiveJobStmt` -/

theorem exec_propAndBuildActiveJobStmt
    (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k)
    {g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩)}
    {m : ArithRAMMemory}
    (hw13_reg : wRead m 26 13 = (ctx.opH : ℤ))
    (hw14_reg : wRead m 26 14 = (if ctx.ins then 1 else 0))
    (hw15_reg : wRead m 26 15 = (i : ℤ))
    (hU : MidLoopUncut ctx gFlag i m)
    (haff : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = true)
    (hsome : ctx.st₀.ownedJob ⟨i, hi⟩ = some g₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExecAt 0 inp (propAndBuildActiveJobStmt ctx.d ctx.n ctx.M_box ctx.p) m m₁
        (propAndBuildActiveJobCost ctx.p) ∧
      wRead m₁ 0 0 = wRead m 0 0 ∧
      wRead m₁ 26 13 = (ctx.opH : ℤ) ∧
      wRead m₁ 26 14 = (if ctx.ins then 1 else 0) ∧
      wRead m₁ 26 15 = (i : ℤ) ∧
      wRead m₁ 26 28 = wRead m 26 28 ∧
      ActivePropBuildState ctx gFlag i hi g₀ m₁ := by
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  let jLen := g₀.lvs.length
  have hjLen_pos : 1 ≤ jLen := g₀.hlvs_pos
  have hjLen_lt_D0 : jLen < ctx.p.D₀ := by
    rw [ctx.hD0_eq]; exact g₀.lvs_length_lt ctx.hH5 ctx.hn2
  have hjLen_le_D0 : jLen ≤ ctx.p.D₀ := le_of_lt hjLen_lt_D0
  have hlast_lt_jLen : jLen - 1 < jLen := Nat.sub_lt hjLen_pos Nat.one_pos
  have hlast_sub_lt : jLen - 1 < ctx.p.D₀ := lt_trans hlast_lt_jLen hjLen_lt_D0
  have hU0 := hU
  rcases hU with ⟨h27, hGood₀, hSeg, hSave, hLive, hw1_5, hw6_0, hSeg0,
    leafS, hl0, hllt, hw1_6, hw6_l, hSegL, hDisj, hDone, hTodo⟩
  rcases hTodo r_fin le_rfl with ⟨_, hHdr_i0, hGood_r0, hTd_i⟩
  unfold EncTodoJobAt at hTd_i
  rw [hsome] at hHdr_i0 hTd_i
  have hGood_i : gFlag = true → JobLevelsCenterGood (ctx.d + 3) ctx.st₀.uMap.ghostCoords g₀.lvs :=
    fun hgF => hGood_r0 hgF g₀ hsome
  rcases hTd_i with ⟨hw16_i, hwRem_i, hwCl_i, hw19_i, lvs_h, hlen_eq, hlv_i⟩
  have hlen_jLen : lvs_h.length = jLen := hlen_eq
  have h19_i_nat : (wRead m 19 (i : ℤ)).toNat = jLen := by rw [hw19_i]; simp [jLen]
  have hsub_pre : ctx.S_pre_h r_fin ⊆ ctx.P.activeHandles :=
    cg01_chainInput_subset ctx.P.handleCoords ctx.st₀.nodes ctx.P.activeHandles r_fin.castSucc
  rcases (ctx.hPerNode r_fin).2 haff with ⟨_, _, hchg_ins_r, hchg_del_r, _⟩
  have hlive_other : ∀ x ∈ ctx.S_pre_h r_fin, x ≠ ctx.opH →
      ctx.P'.handleCoords x = bridgeHandleCoords ctx.P ctx.P' x := by
    intro x hx hne
    rw [bridgeHandleCoords_eq_pre (hsub_pre hx)]
    exact (ctx.hcoords_ne x (hsub_pre hx) hne).2
  have hlv_disj_i : ∀ i₁ < jLen, ∀ i₂ < jLen, i₁ ≠ i₂ →
      ∀ s ∈ LevelUsedSlots m (i * ctx.p.D₀ + i₂) (decide (i₂ + 1 = lvs_h.length)),
        s ∉ jobLevelSlotSet m (i * ctx.p.D₀ + i₁) ∨
        (decide (i₁ + 1 = lvs_h.length) = false ∧
          s = (wRead m 23 (((8 * (i * ctx.p.D₀ + i₁) + 6 : ℕ) : ℤ))).toNat) := by
    intro i₁ hi₁ i₂ hi₂ hne
    have hE1 := (hlv_i i₁ (hlen_eq ▸ hi₁)).2.2.2.1
    have hE2 := (hlv_i i₂ (hlen_eq ▸ hi₂)).2.2.2.1
    have hd12 := hDisj.2.2.2.2 i hi hw16_i i₁ (h19_i_nat ▸ hi₁) i hi hw16_i i₂ (h19_i_nat ▸ hi₂) (Or.inr hne)
    rw [h19_i_nat, ← hlen_jLen] at hd12
    exact levelUsedSlots_disj_of_live_and_bS (D₀ := ctx.p.D₀) hE1 hE2 hd12.1 hd12.2
  rcases exec_propagateAllJobLevelsStmt (D := ctx.d + 3) (NumSlots := ctx.p.NumSlots)
      (M_box := ctx.M_box) inp m lvs_h (fun j => decide (j + 1 = lvs_h.length))
      hlen_eq hjLen_pos hjLen_le_D0 ctx.hopH_K ctx.hBox30 ctx.hBox_seg
      hw15_reg hw13_reg hw14_reg hw19_i hLive
      (ctx.opH_mem_post_of_aff_ins r_fin haff)
      hchg_ins_r (fun hf => (hchg_del_r hf).2)
      hlive_other
      (fun _ _ _ _ _ hC => slotCoordsBridgeToPost ctx.hcoords_root hC)
      hSeg
      (fun j hj => (hlv_i j hj).2.2.2.1)
      (fun j hj => (hlv_i j (by omega)).2.2.2.2.2.2.2.2.2.2.1 (by omega))
      hlv_disj_i
    with ⟨mp, hd_prop, _, hseg_mp, hEnc_mp, hpar_raw, hSegFr_mp, hwo_mp, hw26_mp, hro_mp⟩
  have hlast_lt_lh : jLen - 1 < lvs_h.length := by omega
  have hSpar_old_eq : jobHandleInput (ctx.d + 3) (bridgeHandleCoords ctx.P ctx.P') lvs_h
      (ctx.S_pre_h r_fin) (jLen - 1) = g₀.Spar_last_h := by
    have h1 := ((hlv_i (jLen - 1) hlast_lt_lh).2.2.2.2.2.2.2.2.2.2.2 (by omega)).2.2
    rw [h1]
    exact jobHandleInput_congr_pts (ctx.d + 3) lvs_h (ctx.S_pre_h r_fin)
      (fun x hx => bridgeHandleCoords_eq_pre (hsub_pre hx)) (jLen - 1)
  let lastIdx := i * ctx.p.D₀ + (jLen - 1)
  let Spar_last_h' := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) (jLen - 1)
  have hpar_1 :
      Spar_last_h'.card ≤ g₀.Spar_last_h.card + 1 ∧
      ∀ c : ℕ, (Spar_last_h'.filter (fun x => c ≤ x)).card ≤
               (g₀.Spar_last_h.filter (fun x => c ≤ x)).card + 1 := by
    have hraw :
        Spar_last_h'.card ≤
          (jobHandleInput (ctx.d + 3) (bridgeHandleCoords ctx.P ctx.P') lvs_h
            (ctx.S_pre_h r_fin) (jLen - 1)).card + 1 ∧
        ∀ c : ℕ,
          (Spar_last_h'.filter (fun x => c ≤ x)).card ≤
            ((jobHandleInput (ctx.d + 3) (bridgeHandleCoords ctx.P ctx.P') lvs_h
              (ctx.S_pre_h r_fin) (jLen - 1)).filter (fun x => c ≤ x)).card + 1 := hpar_raw
    rwa [hSpar_old_eq] at hraw
  have hslot_mp_eq : ∀ idx, jobLevelSlotSet mp idx = jobLevelSlotSet m idx := fun idx => by
    unfold jobLevelSlotSet
    simp [hwo_mp 23 (by decide) (by decide) (by decide) (by decide)]
  have hlive_disj_to_slot : ∀ s : ℕ, wRead m 6 (s : ℤ) = 0 →
      (∀ j < jLen, s ∉ jobLevelLiveSlots m (i * ctx.p.D₀ + j) (decide (j + 1 = lvs_h.length))) →
      (∀ j < jLen, s ∉ jobLevelSlotSet m (i * ctx.p.D₀ + j) ∨
        (decide (j + 1 = lvs_h.length) = false ∧
          s = (wRead m 23 (((8 * (i * ctx.p.D₀ + j) + 6 : ℕ) : ℤ))).toNat)) ∧
      s ∉ jobLevelSlotSet m lastIdx := by
    intro s hs6 hnot_live
    refine ⟨fun j hj => Or.inl (not_mem_jobLevelSlotSet_of_live_disj (hlv_i j (hlen_eq ▸ hj)).2.2.2.1 hs6 (hnot_live j hj)),
      not_mem_jobLevelSlotSet_of_live_disj (hlv_i (jLen - 1) hlast_lt_lh).2.2.2.1 hs6 (hnot_live (jLen - 1) (by omega))⟩
  -- Pick `pS` for `exec_stepBuildAndNormLastStmt`:
  have h_pS_ex : ∃ (pS : ℕ) (fSq_p : ℕ → ℝ),
      pS < ctx.p.NumSlots ∧
      pS ∉ jobLevelSlotSet mp lastIdx ∧
      ((jLen = 1 → wRead mp 14 (i : ℤ) = (pS : ℤ)) ∧
       (jLen ≠ 1 → wRead mp 23 (((8 * (i * ctx.p.D₀ + (jLen - 2)) + 5 : ℕ) : ℤ)) = (pS : ℤ))) ∧
      EncSegSlot ctx.p.K_seg mp pS Spar_last_h' fSq_p := by
    by_cases hj1 : jLen = 1
    · rcases hHdr_i0 with ⟨dS_i, _, _, _, hdS_lt, _, _, _, _, _, hw14_i, _, h6_dS_i, _, _, _, hSegD_i, _⟩
      have hdS_in_sn : dS_i ∈ snSlotSet m i := by unfold snSlotSet; rw [hw14_i]; simp
      have hdS_not_live : ∀ j < jLen, dS_i ∉ jobLevelLiveSlots m (i * ctx.p.D₀ + j) (decide (j + 1 = lvs_h.length)) := by
        intro j hj
        have hd := (hDisj.2.2.2.1 i hi hw16_i j (h19_i_nat ▸ hj)).2 i hi
        rw [h19_i_nat, ← hlen_jLen] at hd
        exact Finset.disjoint_right.mp hd hdS_in_sn
      rcases hlive_disj_to_slot dS_i h6_dS_i hdS_not_live with ⟨hdS_mp_ok, hdS_not_last⟩
      have hSeg_dS_mp := hSegFr_mp dS_i hdS_lt hdS_mp_ok _ _ hSegD_i
      have hSpar0 : Spar_last_h' = ctx.S_post_h r_fin := by dsimp [Spar_last_h']; rw [hj1]; simp
      exact ⟨dS_i, _, hdS_lt, by rwa [hslot_mp_eq],
        ⟨fun _ => by rw [hwo_mp 14 (by decide) (by decide) (by decide) (by decide), hw14_i],
         fun hne => False.elim (hne hj1)⟩,
        hSpar0 ▸ hSeg_dS_mp⟩
    · rcases cg14_prev_idx_props hjLen_pos hj1 hlen_jLen with ⟨hprev_lt, hprev_succ_lt, hsucc_eq, hprev_ne_last⟩
      let prevJ := jLen - 2
      let prevIdx := i * ctx.p.D₀ + prevJ
      have hph2_prev_mp : wRead mp 24 (((2 * prevIdx + 0 : ℕ) : ℤ)) = 2 := by
        rw [hwo_mp 24 (by decide) (by decide) (by decide) (by decide)]
        exact (hlv_i prevJ hprev_lt).2.2.2.2.2.2.2.2.2.2.1 hprev_succ_lt
      rcases encJobLevel_phase2_resSlots (hEnc_mp prevJ hprev_lt) hph2_prev_mp
        with ⟨rS_prev, _, hrS_lt, _, _, hw_rS_mp, _, h6_rS_mp, _, hEr, _⟩
      have hSp_eq : Spar_last_h' =
          ((lvs_h[prevJ]'hprev_lt).ball (ctx.d + 3)).residual ctx.P'.handleCoords
            (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) prevJ) := by
        dsimp only [Spar_last_h']; rw [hsucc_eq]
        exact jobHandleInput_succ (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) hprev_lt
      have hEr_prev_mp : EncSegSlot ctx.p.K_seg mp rS_prev Spar_last_h' (fun _ => 0) :=
        hSp_eq ▸ hEr
      have hw_rS_m : wRead m 23 (((8 * prevIdx + 5 : ℕ) : ℤ)) = (rS_prev : ℤ) := by
        rw [← hwo_mp 23 (by decide) (by decide) (by decide) (by decide)]; exact hw_rS_mp
      have h6_rS_m : wRead m 6 (rS_prev : ℤ) = 0 := by
        rw [← hwo_mp 6 (by decide) (by decide) (by decide) (by decide)]; exact h6_rS_mp
      have hrS_in_prev : rS_prev ∈ jobLevelLiveSlots m prevIdx (decide (prevJ + 1 = lvs_h.length)) := by
        unfold jobLevelLiveSlots; rw [hw_rS_m]; cases decide (prevJ + 1 = lvs_h.length) <;> simp
      have h19_lh : (wRead m 19 (i : ℤ)).toNat = lvs_h.length := h19_i_nat.trans hlen_jLen.symm
      have hprev_19 : prevJ < (wRead m 19 (i : ℤ)).toNat := by rw [h19_lh]; exact hprev_lt
      have hlast_19 : jLen - 1 < (wRead m 19 (i : ℤ)).toNat := by rw [h19_lh]; exact hlast_lt_lh
      have hrS_not_last_live : rS_prev ∉ jobLevelLiveSlots m lastIdx (decide ((jLen - 1) + 1 = lvs_h.length)) := by
        have hd := (hDisj.2.2.2.2 i hi hw16_i prevJ hprev_19 i hi hw16_i (jLen - 1) hlast_19 (Or.inr hprev_ne_last)).1
        rw [h19_lh] at hd
        exact Finset.disjoint_left.mp hd hrS_in_prev
      have hrS_not_last_slot : rS_prev ∉ jobLevelSlotSet m lastIdx :=
        not_mem_jobLevelSlotSet_of_live_disj (hlv_i (jLen - 1) hlast_lt_lh).2.2.2.1 h6_rS_m hrS_not_last_live
      exact ⟨rS_prev, _, hrS_lt, by rwa [hslot_mp_eq],
        ⟨fun heq => False.elim (hj1 heq), fun _ => hw_rS_mp⟩, hEr_prev_mp⟩
  rcases h_pS_ex with ⟨pS, fSq_p, hpS_lt, hpS_disj_mp, hpS_br, hSeg_p_mp⟩
  rcases cg14_last_eq_len hjLen_pos hlen_jLen with ⟨hsp_last_true, hlast_succ_eq⟩
  rcases (hlv_i (jLen - 1) hlast_lt_lh).2.2.2.2.2.2.2.2.2.2.2 hlast_succ_eq with ⟨hw_ph_m, hw_sc_m, _⟩
  rcases (hlv_i (jLen - 1) hlast_lt_lh).2.2.1 with ⟨f_b0, g_b0, hf_b0, hg_b0⟩
  have hm_last_eq : (lvs_h[jLen - 1]'hlast_lt_lh).S_birth.card =
      (g₀.lvs[g₀.lvs.length - 1]'(Nat.sub_lt g₀.hlvs_pos Nat.one_pos)).birthSnapshot.card :=
    cg14_card_eq_of_bij (fun h hh => ⟨(hf_b0 h hh).1, (hf_b0 h hh).2.2⟩) hg_b0
  have hsave_mp : SaveGenBound ctx.n ctx.p.NumSlots mp :=
    ⟨by rw [hwo_mp 1 (by decide) (by decide) (by decide) (by decide)]; exact hSave.1,
     fun s hs => by rw [hwo_mp 6 (by decide) (by decide) (by decide) (by decide),
                        hwo_mp 1 (by decide) (by decide) (by decide) (by decide)]; exact hSave.2.1 s hs,
     fun s hs h hh => by rw [hwo_mp 11 (by decide) (by decide) (by decide) (by decide),
                             hwo_mp 1 (by decide) (by decide) (by decide) (by decide)]; exact hSave.2.2 s hs h hh⟩
  have hLive_mp : EncLiveCoords ctx.d ctx.n mp ctx.P'.activeHandles ctx.P'.handleCoords :=
    ⟨hLive.1, fun h hh c => by rw [hro_mp 4 (by decide) (by decide)]; exact hLive.2 h hh c⟩
  rcases exec_stepBuildAndNormLastStmt ctx inp hi hlen_eq hjLen_pos hjLen_lt_D0 hm_last_eq
      (by rw [hw26_mp 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hw15_reg])
      (by rw [hwo_mp 19 (by decide) (by decide) (by decide) (by decide), hw19_i])
      hpS_lt hpS_disj_mp hpS_br hSeg_p_mp hLive_mp hseg_mp hsave_mp
      (by have hE := hEnc_mp (jLen - 1) hlast_lt_lh; rwa [hsp_last_true] at hE)
      (by rw [hwo_mp 24 (by decide) (by decide) (by decide) (by decide), hw_ph_m])
      (by rw [hwo_mp 24 (by decide) (by decide) (by decide) (by decide), hw_sc_m])
      (hpar_1.2 g₀.scan_cur)
    with ⟨m₁, ph', scan', hd_sbn, hpop_m1, hseg_m1, hsave_m1, hph'_le, hw24_ph, hw24_sc,
          hEnc_last_m1, hbuild_1, hSegFr_m1, hSnapFr_m1,
          hwo_sbn, hw1_sbn, hw23_sbn, hw24_sbn, hw26_sbn, hro_sbn, hr24_sbn⟩
  have hex_full : DetExecAt 0 inp (propAndBuildActiveJobStmt ctx.d ctx.n ctx.M_box ctx.p) m m₁
      (propAndBuildActiveJobCost ctx.p) :=
    hd_prop.seq hd_sbn
  have hw_m1_other : ∀ t, t ≠ 1 → t ≠ 5 → t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 23 → t ≠ 24 → t ≠ 26 →
      ∀ idx, wRead m₁ t idx = wRead m t idx := fun t h1 h5 h8 h9 h10 h23 h24 h26 idx => by
    rw [hwo_sbn t h1 h5 h8 h9 h10 h23 h24 h26, hwo_mp t h8 h9 h10 h26]
  have hw_m1_1 : ∀ idx, idx ≠ 3 → wRead m₁ 1 idx = wRead m 1 idx := fun idx h3 => by
    rw [hw1_sbn idx h3, hwo_mp 1 (by decide) (by decide) (by decide) (by decide)]
  have hw_m1_26_keep : ∀ idx : ℤ,
      idx ≠ 3 → idx ≠ 4 → idx ≠ 5 → idx ≠ 6 → idx ≠ 7 → idx ≠ 8 → idx ≠ 9 → idx ≠ 16 → idx ≠ 25 →
      wRead m₁ 26 idx = wRead m 26 idx := fun idx h3 h4 h5 h6 h7 h8 h9 h16 h25 => by
    rw [hw26_sbn idx h3 h4 h5 h6 h7 h8 h9 h25, hw26_mp idx h3 h4 h5 h6 h7 h8 h16]
  have hw_m1_23_slot : ∀ idx a, (a = 0 ∨ (2 ≤ a ∧ a < 8)) →
      wRead m₁ 23 (((8 * idx + a : ℕ) : ℤ)) = wRead m 23 (((8 * idx + a : ℕ) : ℤ)) := fun idx a ha => by
    rw [hw23_sbn _ (by omega), hwo_mp 23 (by decide) (by decide) (by decide) (by decide)]
  have hw_m1_23_disj : ∀ idx ≠ lastIdx, ∀ a < 8,
      wRead m₁ 23 (((8 * idx + a : ℕ) : ℤ)) = wRead m 23 (((8 * idx + a : ℕ) : ℤ)) := fun idx hne a ha8 => by
    rw [hw23_sbn _ (by have := jobIdx_disj_w23 hne ha8; omega),
        hwo_mp 23 (by decide) (by decide) (by decide) (by decide)]
  have hw_m1_24_disj : ∀ idx ≠ lastIdx, ∀ a < 2,
      wRead m₁ 24 (((2 * idx + a : ℕ) : ℤ)) = wRead m 24 (((2 * idx + a : ℕ) : ℤ)) := fun idx hne a ha2 => by
    rw [hw24_sbn _ (jobIdx_disj_w24 hne ha2),
        hwo_mp 24 (by decide) (by decide) (by decide) (by decide)]
  have hr_m1_other : ∀ t, t ≠ 8 → t ≠ 24 → t ≠ 26 → ∀ idx, rRead m₁ t idx = rRead m t idx :=
    fun t h8 h24 h26 idx => by rw [hro_sbn t h8 h24 h26, hro_mp t h8 h26]
  have hr_m1_24_disj : ∀ idx ≠ lastIdx, ∀ a < 2,
      rRead m₁ 24 (((2 * idx + a : ℕ) : ℤ)) = rRead m 24 (((2 * idx + a : ℕ) : ℤ)) := fun idx hne a ha2 => by
    rw [hr24_sbn _ (jobIdx_disj_w24 hne ha2), hro_mp 24 (by decide) (by decide)]
  have hSeg_mp_to_m1 : ∀ s < ctx.p.NumSlots, s ∉ jobLevelSlotSet m lastIdx →
      ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg mp s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁ := by
    intro s hs_lt hs_not S₁ fSq₁ hE_mp
    exact hSegFr_m1 s hs_lt (by rwa [hslot_mp_eq]) S₁ fSq₁ hE_mp
  have hSeg_m_to_m1_live : ∀ s < ctx.p.NumSlots, wRead m 6 (s : ℤ) = 0 →
      (∀ j < jLen, s ∉ jobLevelLiveSlots m (i * ctx.p.D₀ + j) (decide (j + 1 = lvs_h.length))) →
      ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁ := by
    intro s hs_lt hs6 hnot_live S₁ fSq₁ hE_m
    rcases hlive_disj_to_slot s hs6 hnot_live with ⟨hmp_ok, hnot_last⟩
    exact hSeg_mp_to_m1 s hs_lt hnot_last S₁ fSq₁ (hSegFr_mp s hs_lt hmp_ok S₁ fSq₁ hE_m)
  have hSeg0_m1 : EncSegSlot ctx.p.K_seg m₁ 0 ctx.P'.activeHandles (fun _ => 0) := by
    refine hSeg_m_to_m1_live 0 ctx.zero_lt_NumSlots hw6_0 (fun j hj hmem => ?_) _ _ hSeg0
    have hd := (hDisj.2.2.2.1 i hi hw16_i j (h19_i_nat ▸ hj)).1
    rw [h19_i_nat, ← hlen_jLen] at hd
    exact (hd 0 hmem).1 rfl
  have hSegL_m1 : EncSegSlot ctx.p.K_seg m₁ leafS
      (chainTerminal ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles) (fun _ => 0) := by
    refine hSeg_m_to_m1_live leafS hllt hw6_l (fun j hj hmem => ?_) _ _ hSegL
    have hd := (hDisj.2.2.2.1 i hi hw16_i j (h19_i_nat ▸ hj)).1
    rw [h19_i_nat, ← hlen_jLen] at hd
    exact (hd leafS hmem).2 rfl
  have hV := ctx.hV
  have hbc_ne := fun u (hu : u ∈ reservedWordTags) => tag_ne_of_not_reserved hV.2.2.2.2.2.2.1 hu
  have hage_ne := fun u (hu : u ∈ reservedWordTags) => tag_ne_of_not_reserved hV.2.2.2.2.2.2.2.1 hu
  have haff_ne := fun u (hu : u ∈ reservedWordTags) => tag_ne_of_not_reserved hV.2.2.2.2.2.2.2.2.1 hu
  have hrem_ne := fun u (hu : u ∈ reservedWordTags) => tag_ne_of_not_reserved hV.2.2.2.2.2.2.2.2.2.1 hu
  have hcl_ne := fun u (hu : u ∈ reservedWordTags) => tag_ne_of_not_reserved hV.2.2.2.2.2.2.2.2.2.2.1 hu
  have hrO_ne := fun u (hu : u ∈ reservedRealTags) => rtag_ne_of_not_reserved hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1 hu
  have hrV_ne := fun u (hu : u ∈ reservedRealTags) => rtag_ne_of_not_reserved hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2 hu
  have hHdr_frame : ∀ (r : Fin ctx.st₀.k) {idle : Bool},
      EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' r.val (ctx.st₀.nodes r)
        (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) idle →
      EncNodeHeaderAt ctx.cfg ctx.p m₁ ctx.P' r.val (ctx.st₀.nodes r)
        (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) idle := by
    intro r idle hH
    have h6_sn : ∀ s ∈ snSlotSet m r.val, wRead m 6 (s : ℤ) = 0 := by
      rcases hH with ⟨dS_r, spS_r, _, _, _, _, _, _, _, _, e14, e15, g6d, g6s, _⟩
      intro s hs; unfold snSlotSet at hs; rw [e14, e15] at hs
      simp only [Int.toNat_natCast, Finset.mem_insert, Finset.mem_singleton] at hs
      rcases hs with rfl | rfl <;> assumption
    exact hH.frame_other
      (hw_m1_other _ (hbc_ne 1 (by decide)) (hbc_ne 5 (by decide)) (hbc_ne 8 (by decide))
        (hbc_ne 9 (by decide)) (hbc_ne 10 (by decide)) (hbc_ne 23 (by decide))
        (hbc_ne 24 (by decide)) (hbc_ne 26 (by decide)) _)
      (hw_m1_other _ (hage_ne 1 (by decide)) (hage_ne 5 (by decide)) (hage_ne 8 (by decide))
        (hage_ne 9 (by decide)) (hage_ne 10 (by decide)) (hage_ne 23 (by decide))
        (hage_ne 24 (by decide)) (hage_ne 26 (by decide)) _)
      (hw_m1_other 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
      (hw_m1_other 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
      (fun _ _ => hw_m1_other 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
      (fun _ => hr_m1_other _ (hrO_ne 8 (by decide)) (hrO_ne 24 (by decide)) (hrO_ne 26 (by decide)) _)
      (hr_m1_other _ (hrV_ne 8 (by decide)) (hrV_ne 24 (by decide)) (hrV_ne 26 (by decide)) _)
      (fun s hs hlt S₁ fSq₁ hE =>
        hSeg_m_to_m1_live s hlt (h6_sn s hs)
          (fun j hj => by
            have hd := (hDisj.2.2.2.1 i hi hw16_i j (h19_i_nat ▸ hj)).2 r.val r.isLt
            rw [h19_i_nat, ← hlen_jLen] at hd
            exact Finset.disjoint_right.mp hd hs) S₁ fSq₁ hE)
  have hOtherJob_seg : ∀ (r : Fin ctx.st₀.k), r.val ≠ i →
      ∀ j' < (wRead m 19 (r.val : ℤ)).toNat, wRead m 16 (r.val : ℤ) = 1 →
        let sp' := decide (j' + 1 = (wRead m 19 (r.val : ℤ)).toNat)
        ∀ s ∈ jobLevelSlotSet m (r.val * ctx.p.D₀ + j'), s < ctx.p.NumSlots →
          (sp' = false → s ≠ (wRead m 23 (((8 * (r.val * ctx.p.D₀ + j') + 6 : ℕ) : ℤ))).toNat) →
          ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁ := by
    intro r hr_ne j' hj' h16_r sp' s hs_in hs_lt hnd S₁ fSq₁ hE_m
    have hs_used : s ∈ LevelUsedSlots m (r.val * ctx.p.D₀ + j') sp' :=
      mem_levelUsedSlots_of_enc hs_in hnd
    rcases hU0.encJobLevel_at_active r.val j' r.isLt h16_r hj'
      with ⟨_, _, _, _, _, _, _, hEnc_rj⟩
    have hdisj_all : ∀ j < jLen,
        s ∉ jobLevelSlotSet m (i * ctx.p.D₀ + j) ∨
        (decide (j + 1 = lvs_h.length) = false ∧
          s = (wRead m 23 (((8 * (i * ctx.p.D₀ + j) + 6 : ℕ) : ℤ))).toNat) := by
      intro j hj
      have hd := hDisj.2.2.2.2 i hi hw16_i j (h19_i_nat ▸ hj) r.val r.isLt h16_r j' hj' (Or.inl hr_ne.symm)
      rw [h19_i_nat, ← hlen_jLen] at hd
      exact levelUsedSlots_disj_of_live_and_bS (D₀ := ctx.p.D₀) (hlv_i j (hlen_eq ▸ hj)).2.2.2.1
        hEnc_rj hd.1 hd.2 s hs_used
    have hs_not_last : s ∉ jobLevelSlotSet m lastIdx := by
      rcases hdisj_all (jLen - 1) hlast_lt_jLen with hnot | ⟨hf, _⟩
      · exact hnot
      · rw [hsp_last_true] at hf; cases hf
    exact hSeg_mp_to_m1 s hs_lt hs_not_last S₁ fSq₁ (hSegFr_mp s hs_lt hdisj_all S₁ fSq₁ hE_m)
  have hDisj_m1 : GlobalSlotDisj ctx.p.D₀ m₁ ctx.st₀.k leafS := by
    rcases hDisj with ⟨hlp, hsn0, hsnP, hlv_sn, hlv_lv⟩
    have hsn_eq : ∀ r, snSlotSet m₁ r = snSlotSet m r := fun r =>
      snSlotSet_congr_14_15
        (hw_m1_other 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
        (hw_m1_other 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
    have h16_eq : ∀ r, wRead m₁ 16 (r : ℤ) = wRead m 16 (r : ℤ) := fun _ =>
      hw_m1_other 16 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _
    have h19_eq : ∀ r, wRead m₁ 19 (r : ℤ) = wRead m 19 (r : ℤ) := fun _ =>
      hw_m1_other 19 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _
    have hlv_eq : ∀ idx sp, jobLevelLiveSlots m₁ idx sp = jobLevelLiveSlots m idx sp := fun idx sp =>
      jobLevelLiveSlots_congr_23
        (hw_m1_23_slot idx 3 (Or.inr ⟨by decide, by decide⟩))
        (hw_m1_23_slot idx 4 (Or.inr ⟨by decide, by decide⟩))
        (hw_m1_23_slot idx 5 (Or.inr ⟨by decide, by decide⟩))
        (hw_m1_23_slot idx 6 (Or.inr ⟨by decide, by decide⟩))
    refine ⟨hlp,
      fun r hr s hs => by rw [hsn_eq] at hs; exact hsn0 r hr s hs,
      fun r₁ hr₁ r₂ hr₂ hne => by rw [hsn_eq, hsn_eq]; exact hsnP r₁ hr₁ r₂ hr₂ hne,
      fun r hr h16 j hj => ?_,
      fun r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne => ?_⟩
    · dsimp only
      rw [h16_eq r] at h16; rw [h19_eq r] at hj ⊢; rw [hlv_eq]
      rcases hlv_sn r hr h16 j hj with ⟨h0l, hd_sn⟩
      exact ⟨h0l, fun r' hr' => by rw [hsn_eq]; exact hd_sn r' hr'⟩
    · rw [h16_eq r₁] at h16₁; rw [h16_eq r₂] at h16₂
      rw [h19_eq r₁] at hj₁ ⊢; rw [h19_eq r₂] at hj₂ ⊢
      rw [hlv_eq, hlv_eq,
          hw_m1_23_slot _ 2 (Or.inr ⟨by decide, by decide⟩),
          hw_m1_23_slot _ 2 (Or.inr ⟨by decide, by decide⟩)]
      exact hlv_lv r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne
  refine ⟨m₁, hex_full,
    hw_m1_other 0 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) 0,
    (hw_m1_26_keep 13 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)).trans hw13_reg,
    (hw_m1_26_keep 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)).trans hw14_reg,
    (hw_m1_26_keep 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)).trans hw15_reg,
    hw_m1_26_keep 28 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
    { hpop := hpop_m1
      hw27 := (hw_m1_26_keep 27 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)).trans h27
      hGood₀ := hGood₀
      hSeg := hseg_m1
      hSave := hsave_m1
      hLive := ⟨hLive.1, fun h hh c => by rw [hr_m1_other 4 (by decide) (by decide) (by decide)]; exact hLive.2 h hh c⟩
      hw1_5 := (hw_m1_1 5 (by decide)).trans hw1_5
      hw6_0 := (hw_m1_other 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) 0).trans hw6_0
      hSeg0 := hSeg0_m1
      hChainRest := ⟨leafS, hl0, hllt, (hw_m1_1 6 (by decide)).trans hw1_6,
        (hw_m1_other 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _).trans hw6_l,
        hSegL_m1, hDisj_m1⟩
      hDone := fun r hr => by
        rcases hDone r hr with ⟨oj, hInv, hGood_r, hHdr_r, hOwn_r⟩
        have hr_ne : r.val ≠ i := ne_of_lt hr
        exact ⟨oj, hInv, hGood_r, hHdr_frame r hHdr_r,
          hOwn_r.frame_other
            (fun g _ => by rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2))
            (hw_m1_other 16 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
            (hw_m1_other _ (hrem_ne 1 (by decide)) (hrem_ne 5 (by decide)) (hrem_ne 8 (by decide))
              (hrem_ne 9 (by decide)) (hrem_ne 10 (by decide)) (hrem_ne 23 (by decide))
              (hrem_ne 24 (by decide)) (hrem_ne 26 (by decide)) _)
            (hw_m1_other _ (hcl_ne 1 (by decide)) (hcl_ne 5 (by decide)) (hcl_ne 8 (by decide))
              (hcl_ne 9 (by decide)) (hcl_ne 10 (by decide)) (hcl_ne 23 (by decide))
              (hcl_ne 24 (by decide)) (hcl_ne 26 (by decide)) _)
            (hw_m1_other 19 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
            (fun j hj a ha => hw_m1_23_disj _ (jobIdx_ne hj hlast_sub_lt (Or.inl hr_ne)) a ha)
            (fun j hj a ha => hw_m1_24_disj _ (jobIdx_ne hj hlast_sub_lt (Or.inl hr_ne)) a ha)
            (fun _ _ _ => hr_m1_other 23 (by decide) (by decide) (by decide) _)
            (fun j hj a ha => hr_m1_24_disj _ (jobIdx_ne hj hlast_sub_lt (Or.inl hr_ne)) a ha)
            (fun _ _ _ _ _ => hw_m1_other 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
            (hOtherJob_seg r hr_ne)
            (hw_m1_other 11 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))
            (hr_m1_other 11 (by decide) (by decide) (by decide))⟩
      hTodoGt := fun r hr => by
        rcases hTodo r (le_of_lt hr) with ⟨haff_w, hHdr_r, hGood_r, hTd_r⟩
        have hr_ne : r.val ≠ i := ne_of_gt hr
        exact ⟨(hw_m1_other _ (haff_ne 1 (by decide)) (haff_ne 5 (by decide)) (haff_ne 8 (by decide))
                  (haff_ne 9 (by decide)) (haff_ne 10 (by decide)) (haff_ne 23 (by decide))
                  (haff_ne 24 (by decide)) (haff_ne 26 (by decide)) _).trans haff_w,
          hHdr_frame r hHdr_r, hGood_r,
          hTd_r.frame_other
            (hw_m1_other 16 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
            (hw_m1_other _ (hrem_ne 1 (by decide)) (hrem_ne 5 (by decide)) (hrem_ne 8 (by decide))
              (hrem_ne 9 (by decide)) (hrem_ne 10 (by decide)) (hrem_ne 23 (by decide))
              (hrem_ne 24 (by decide)) (hrem_ne 26 (by decide)) _)
            (hw_m1_other _ (hcl_ne 1 (by decide)) (hcl_ne 5 (by decide)) (hcl_ne 8 (by decide))
              (hcl_ne 9 (by decide)) (hcl_ne 10 (by decide)) (hcl_ne 23 (by decide))
              (hcl_ne 24 (by decide)) (hcl_ne 26 (by decide)) _)
            (hw_m1_other 19 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
            (fun j hj a ha => hw_m1_23_disj _ (jobIdx_ne hj hlast_sub_lt (Or.inl hr_ne)) a ha)
            (fun j hj a ha => hw_m1_24_disj _ (jobIdx_ne hj hlast_sub_lt (Or.inl hr_ne)) a ha)
            (fun _ _ _ => hr_m1_other 23 (by decide) (by decide) (by decide) _)
            (fun j hj a ha => hr_m1_24_disj _ (jobIdx_ne hj hlast_sub_lt (Or.inl hr_ne)) a ha)
            (fun _ _ _ _ _ => hw_m1_other 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
            (hOtherJob_seg r hr_ne)
            (hw_m1_other 11 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))
            (hr_m1_other 11 (by decide) (by decide) (by decide))⟩
      hHdr_i := hHdr_frame r_fin hHdr_i0
      hGood_i := hGood_i
      hw16_i := (hw_m1_other 16 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _).trans hw16_i
      hwRem_i := (hw_m1_other _ (hrem_ne 1 (by decide)) (hrem_ne 5 (by decide)) (hrem_ne 8 (by decide))
                    (hrem_ne 9 (by decide)) (hrem_ne 10 (by decide)) (hrem_ne 23 (by decide))
                    (hrem_ne 24 (by decide)) (hrem_ne 26 (by decide)) _).trans hwRem_i
      hwCl_i := (hw_m1_other _ (hcl_ne 1 (by decide)) (hcl_ne 5 (by decide)) (hcl_ne 8 (by decide))
                   (hcl_ne 9 (by decide)) (hcl_ne 10 (by decide)) (hcl_ne 23 (by decide))
                   (hcl_ne 24 (by decide)) (hcl_ne 26 (by decide)) _).trans hwCl_i
      hw19_i := (hw_m1_other 19 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _).trans hw19_i
      hJob_i := ⟨lvs_h, hlen_eq, ph', scan', hph'_le, hw24_ph, hw24_sc, ?_, hpar_1, hbuild_1⟩ }⟩
  intro j hj
  let hj_g : j < g₀.lvs.length := hlen_eq ▸ hj
  rcases hlv_i j hj with ⟨hb_eq, hor_eq, ⟨f_b, g_b, hf_b, hg_b⟩, _, hw7, hp2, hp3, hp4, hp5, hp6, hpre2, _⟩
  have hbij_u' : ∃ (f_b g_b : ℕ → ℕ),
      (∀ h ∈ (lvs_h[j]'hj).S_birth,
        f_b h ∈ (g₀.lvs[j]'hj_g).birthSnapshot ∧
        ctx.uMap'.ghostCoords (f_b h) = (lvs_h[j]'hj).snapPts h ∧
        g_b (f_b h) = h) ∧
      (∀ u ∈ (g₀.lvs[j]'hj_g).birthSnapshot,
        g_b u ∈ (lvs_h[j]'hj).S_birth ∧ f_b (g_b u) = u) :=
    ⟨f_b, g_b,
      fun h hh => ⟨(hf_b h hh).1,
        (ctx.hag_uid (f_b h) ((g₀.hlvs_inv j hj_g).2.1 _ (hf_b h hh).1)).trans (hf_b h hh).2.1,
        (hf_b h hh).2.2⟩,
      hg_b⟩
  let idx_j := i * ctx.p.D₀ + j
  refine ⟨hb_eq, hor_eq, hbij_u', ?_,
    (hw_m1_23_slot idx_j 7 (Or.inr ⟨by decide, by decide⟩)).trans hw7,
    by rw [hw_m1_23_slot idx_j 2 (Or.inr ⟨by decide, by decide⟩)]; exact hp2,
    by rw [hw_m1_23_slot idx_j 3 (Or.inr ⟨by decide, by decide⟩)]; exact hp3,
    by rw [hw_m1_23_slot idx_j 4 (Or.inr ⟨by decide, by decide⟩)]; exact hp4,
    by rw [hw_m1_23_slot idx_j 5 (Or.inr ⟨by decide, by decide⟩)]; exact hp5,
    by rw [hw_m1_23_slot idx_j 6 (Or.inr ⟨by decide, by decide⟩)]; exact hp6,
    fun hlt_j => ?_⟩
  · by_cases hj_last : j = jLen - 1
    · subst hj_last
      simpa [idx_j, lastIdx, hsp_last_true] using hEnc_last_m1
    · have hj_lt_D0 : j < ctx.p.D₀ := lt_of_lt_of_le hj_g hjLen_le_D0
      have hne_idx : idx_j ≠ lastIdx := jobIdx_ne hj_lt_D0 hlast_sub_lt (Or.inr hj_last)
      have h6_mp : wRead mp 23 (((8 * idx_j + 6 : ℕ) : ℤ)) = wRead m 23 (((8 * idx_j + 6 : ℕ) : ℤ)) :=
        hwo_mp 23 (by decide) (by decide) (by decide) (by decide) _
      exact (hEnc_mp j hj).frame (fun _ _ => rfl)
        (fun s hs_mp hs_lt _ S₁ fSq₁ hnd hE_mp => by
          rw [hslot_mp_eq] at hs_mp; rw [h6_mp] at hnd
          have hs_used := mem_levelUsedSlots_of_enc hs_mp hnd
          have hnot_last : s ∉ jobLevelSlotSet m lastIdx := by
            rcases hlv_disj_i (jLen - 1) hlast_lt_jLen j hj_g (Ne.symm hj_last) s hs_used with hnot | ⟨hf, _⟩
            · exact hnot
            · rw [hsp_last_true] at hf; cases hf
          exact hSeg_mp_to_m1 s hs_lt hnot_last S₁ fSq₁ hE_mp)
        (fun _ _ => by rw [hw_m1_other 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
                           hwo_mp 6 (by decide) (by decide) (by decide) (by decide)])
        (fun bS hbS _ hC => hSnapFr_m1 bS hbS _ _ hC)
        (fun a ha => by
          rw [hw_m1_23_disj idx_j hne_idx a ha,
              hwo_mp 23 (by decide) (by decide) (by decide) (by decide)])
        (fun a ha => by
          rw [hw_m1_24_disj idx_j hne_idx a ha,
              hwo_mp 24 (by decide) (by decide) (by decide) (by decide)])
        (fun c => by
          rw [hr_m1_other 23 (by decide) (by decide) (by decide),
              hro_mp 23 (by decide) (by decide)])
        (fun a ha => by
          rw [hr_m1_24_disj idx_j hne_idx a ha,
              hro_mp 24 (by decide) (by decide)])
  · have hj_lt_D0 : j < ctx.p.D₀ := lt_of_lt_of_le hj_g hjLen_le_D0
    have hne_idx : idx_j ≠ lastIdx :=
      jobIdx_ne hj_lt_D0 hlast_sub_lt (Or.inr (cg14_ne_pred_of_succ_lt hlt_j hlen_jLen))
    exact (hw_m1_24_disj idx_j hne_idx 0 (by decide)).trans (hpre2 hlt_j)

end UL.Proof_lem_7_2_RacerP46
