import UL.Proof.lem_7_2.RacerP46_H2c_PoolAndSnap
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Outer `fd = 0` Box-Safety, Horizon Bridge, and Dummy Bit Consumer -/

@[simp] theorem wReadL_popDepth_zero_one (m : ArithRAMMemory) (v : ℕ) (idx : ℤ) :
    wReadL 1 (m.popDepth 0) v idx = 0 :=
  wReadL_popDepth_gt m (by decide : 0 < 1) v idx

@[simp] theorem rReadL_popDepth_zero_one (m : ArithRAMMemory) (v : ℕ) (idx : ℤ) :
    rReadL 1 (m.popDepth 0) v idx = 0 :=
  rReadL_popDepth_gt m (by decide : 0 < 1) v idx

/-- Statements safe to execute at `frameDepth = 0`: never touch `localFrame 0` directly,
only perform boxed heap writes or enter `.localScope` blocks whose bodies are `BoxSafeInner`. -/
inductive BoxSafeOuter (T_max M_box : ℕ) : ArithRAMStmt → Prop
  | skip : BoxSafeOuter T_max M_box .skip
  | boxW {t : ℕ} (ht : t < T_max) (idxE valE : IntExpr) :
      BoxSafeOuter T_max M_box (boxWriteW M_box t idxE valE)
  | boxR {t : ℕ} (ht : t < T_max) (idxE : IntExpr) (valE : RealExpr) :
      BoxSafeOuter T_max M_box (boxWriteR M_box t idxE valE)
  | localScope {b : ArithRAMStmt} :
      BoxSafeInner T_max M_box b →
      BoxSafeOuter T_max M_box (.localScope b)
  | seq {s₁ s₂ : ArithRAMStmt} :
      BoxSafeOuter T_max M_box s₁ → BoxSafeOuter T_max M_box s₂ →
      BoxSafeOuter T_max M_box (.seq s₁ s₂)
  | ite (c : ArithCondExpr) {s₁ s₂ : ArithRAMStmt} :
      BoxSafeOuter T_max M_box s₁ → BoxSafeOuter T_max M_box s₂ →
      BoxSafeOuter T_max M_box (.ite c s₁ s₂)
  | repeatN (cnt : IntExpr) {b : ArithRAMStmt} :
      BoxSafeOuter T_max M_box b →
      BoxSafeOuter T_max M_box (.repeatN cnt b)

theorem boxSafeOuter_seqList {T_max M_box : ℕ} :
    ∀ {ss : List ArithRAMStmt},
      (∀ s ∈ ss, BoxSafeOuter T_max M_box s) → BoxSafeOuter T_max M_box (seqList ss)
  | [], _ => .skip
  | [s], h => h s List.mem_cons_self
  | s₁ :: _ :: _, h =>
      .seq (h s₁ List.mem_cons_self)
        (boxSafeOuter_seqList (fun s hs => h s (List.mem_cons_of_mem _ hs)))

inductive SafeContOuter (T_max M_box : ℕ) : ℕ → List ArithRAMCont → Prop
  | nil_zero : SafeContOuter T_max M_box 0 []
  | stmt_zero {s : ArithRAMStmt} {rest : List ArithRAMCont} :
      BoxSafeOuter T_max M_box s →
      SafeContOuter T_max M_box 0 rest →
      SafeContOuter T_max M_box 0 (.stmt s :: rest)
  | repeat_zero {rem : ℕ} {b : ArithRAMStmt} {rest : List ArithRAMCont} :
      BoxSafeOuter T_max M_box b →
      SafeContOuter T_max M_box 0 rest →
      SafeContOuter T_max M_box 0 (.repeatLoop rem b :: rest)
  | pop_succ {fd : ℕ} {rest : List ArithRAMCont} :
      SafeContOuter T_max M_box fd rest →
      SafeContOuter T_max M_box (fd + 1) (.popScope fd :: rest)
  | stmt_pos {fd : ℕ} {s : ArithRAMStmt} {rest : List ArithRAMCont} :
      1 ≤ fd → BoxSafeInner T_max M_box s →
      SafeContOuter T_max M_box fd rest →
      SafeContOuter T_max M_box fd (.stmt s :: rest)
  | repeat_pos {fd rem : ℕ} {b : ArithRAMStmt} {rest : List ArithRAMCont} :
      1 ≤ fd → BoxSafeInner T_max M_box b →
      SafeContOuter T_max M_box fd rest →
      SafeContOuter T_max M_box fd (.repeatLoop rem b :: rest)

theorem runArithRAMFuel_preserves_box_outer {d T_max M_box : ℕ} (inp : ArithRAMInput d) :
    ∀ (fuel : ℕ) (stk : List ArithRAMCont) (st : ArithRAMExecState) (out : ArithRAMExecOutcome),
      SafeContOuter T_max M_box st.frameDepth stk →
      HeapOnlyInBox T_max M_box st.mem →
      runArithRAMFuel inp fuel stk st = .halted out →
      HeapOnlyInBox T_max M_box out.mem
  | 0, [], st, out, _, hbox, hrun => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; exact heapOnlyInBox_popDepth 0 hbox
  | 0, _ :: _, _, _, _, _, hrun => by simp [runArithRAMFuel] at hrun
  | fuel + 1, [], st, out, _, hbox, hrun => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; exact heapOnlyInBox_popDepth 0 hbox
  | fuel + 1, item :: rest, ⟨mem, fd, remBits, uCost, pk⟩, out, hsafe, hbox, hrun => by
      dsimp only at hsafe hbox hrun
      let st : ArithRAMExecState := ⟨mem, fd, remBits, uCost, pk⟩
      change runArithRAMFuel inp (fuel + 1) (item :: rest) st = .halted out at hrun
      cases hsafe with
      | @pop_succ prev rest' hrest =>
          simp only [st, runArithRAMFuel] at hrun
          exact runArithRAMFuel_preserves_box_outer inp fuel rest _ out hrest
            (heapOnlyInBox_popDepth prev hbox) hrun
      | @repeat_zero rem b rest' hb hrest =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel rest _ out hrest hbox hrun
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.stmt_zero hb (.repeat_zero hb hrest)) hbox hrun
      | @repeat_pos fd' rem b rest' hfd hb hrest =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel rest _ out hrest hbox hrun
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.stmt_pos hfd hb (.repeat_pos hfd hb hrest)) hbox hrun
      | stmt_zero hs hrest =>
          cases hs with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel rest _ out hrest hbox hrun
          | @boxW t ht idxE valE =>
              simp only [boxWriteW, runArithRAMFuel] at hrun
              rcases hc : evalArithCond inp st.frameDepth st.mem
                (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) with ⟨flag, u_c⟩
              rw [hc] at hrun; dsimp only at hrun
              cases flag with
              | false =>
                  simp only [Bool.false_eq_true, ↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                    (.stmt_zero .skip hrest) hbox hrun
              | true =>
                  simp only [↓reduceIte] at hrun
                  cases fuel with
                  | zero => simp [runArithRAMFuel] at hrun
                  | succ fuel' =>
                      simp only [runArithRAMFuel] at hrun
                      have hcond_t : cValAt st.frameDepth inp st.mem
                          (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) = true := by
                        rw [cValAt, hc]
                      simp only [cValAt_and, cValAt_intLe, cValAt_intLt,
                        Bool.and_eq_true, decide_eq_true_eq, iValAt] at hcond_t
                      exact runArithRAMFuel_preserves_box_outer inp fuel' rest _ out hrest
                        (heapOnlyInBox_wWrite _ hbox ht hcond_t.1 hcond_t.2) hrun
          | @boxR t ht idxE valE =>
              simp only [boxWriteR, runArithRAMFuel] at hrun
              rcases hc : evalArithCond inp st.frameDepth st.mem
                (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) with ⟨flag, u_c⟩
              rw [hc] at hrun; dsimp only at hrun
              cases flag with
              | false =>
                  simp only [Bool.false_eq_true, ↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                    (.stmt_zero .skip hrest) hbox hrun
              | true =>
                  simp only [↓reduceIte] at hrun
                  cases fuel with
                  | zero => simp [runArithRAMFuel] at hrun
                  | succ fuel' =>
                      simp only [runArithRAMFuel] at hrun
                      have hcond_t : cValAt st.frameDepth inp st.mem
                          (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) = true := by
                        rw [cValAt, hc]
                      simp only [cValAt_and, cValAt_intLe, cValAt_intLt,
                        Bool.and_eq_true, decide_eq_true_eq, iValAt] at hcond_t
                      exact runArithRAMFuel_preserves_box_outer inp fuel' rest _ out hrest
                        (heapOnlyInBox_rWrite _ hbox ht hcond_t.1 hcond_t.2) hrun
          | localScope hb =>
              simp only [st, runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.stmt_pos (by simp) hb (.pop_succ hrest)) (heapOnlyInBox_popDepth 0 hbox) hrun
          | seq h₁ h₂ =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.stmt_zero h₁ (.stmt_zero h₂ hrest)) hbox hrun
          | @ite c tB fB h₁ h₂ =>
              simp only [runArithRAMFuel] at hrun
              have hbr : BoxSafeOuter T_max M_box
                  (if (evalArithCond inp st.frameDepth st.mem c).1 then tB else fB) := by
                split_ifs <;> assumption
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.stmt_zero hbr hrest) hbox hrun
          | repeatN cntE hb =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.repeat_zero hb hrest) hbox hrun
      | stmt_pos hfd hs hrest =>
          cases hs with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel rest _ out hrest hbox hrun
          | writeWordLocal v idxE valE =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel rest _ out hrest
                (heapOnlyInBox_wWriteL hfd v _ _ hbox) hrun
          | writeRealLocal v idxE valE =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel rest _ out hrest
                (heapOnlyInBox_rWriteL hfd v _ _ hbox) hrun
          | randBitLocal v idxE =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  exact runArithRAMFuel_preserves_box_outer inp fuel rest _ out hrest
                    (heapOnlyInBox_wWriteL hfd v _ _ hbox) hrun
          | @boxW t ht idxE valE =>
              simp only [boxWriteW, runArithRAMFuel] at hrun
              rcases hc : evalArithCond inp st.frameDepth st.mem
                (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) with ⟨flag, u_c⟩
              rw [hc] at hrun; dsimp only at hrun
              cases flag with
              | false =>
                  simp only [Bool.false_eq_true, ↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                    (.stmt_pos hfd .skip hrest) hbox hrun
              | true =>
                  simp only [↓reduceIte] at hrun
                  cases fuel with
                  | zero => simp [runArithRAMFuel] at hrun
                  | succ fuel' =>
                      simp only [runArithRAMFuel] at hrun
                      have hcond_t : cValAt st.frameDepth inp st.mem
                          (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) = true := by
                        rw [cValAt, hc]
                      simp only [cValAt_and, cValAt_intLe, cValAt_intLt,
                        Bool.and_eq_true, decide_eq_true_eq, iValAt] at hcond_t
                      exact runArithRAMFuel_preserves_box_outer inp fuel' rest _ out hrest
                        (heapOnlyInBox_wWrite _ hbox ht hcond_t.1 hcond_t.2) hrun
          | @boxR t ht idxE valE =>
              simp only [boxWriteR, runArithRAMFuel] at hrun
              rcases hc : evalArithCond inp st.frameDepth st.mem
                (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) with ⟨flag, u_c⟩
              rw [hc] at hrun; dsimp only at hrun
              cases flag with
              | false =>
                  simp only [Bool.false_eq_true, ↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                    (.stmt_pos hfd .skip hrest) hbox hrun
              | true =>
                  simp only [↓reduceIte] at hrun
                  cases fuel with
                  | zero => simp [runArithRAMFuel] at hrun
                  | succ fuel' =>
                      simp only [runArithRAMFuel] at hrun
                      have hcond_t : cValAt st.frameDepth inp st.mem
                          (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) = true := by
                        rw [cValAt, hc]
                      simp only [cValAt_and, cValAt_intLe, cValAt_intLt,
                        Bool.and_eq_true, decide_eq_true_eq, iValAt] at hcond_t
                      exact runArithRAMFuel_preserves_box_outer inp fuel' rest _ out hrest
                        (heapOnlyInBox_rWrite _ hbox ht hcond_t.1 hcond_t.2) hrun
          | seq h₁ h₂ =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.stmt_pos hfd h₁ (.stmt_pos hfd h₂ hrest)) hbox hrun
          | @ite c tB fB h₁ h₂ =>
              simp only [runArithRAMFuel] at hrun
              have hbr : BoxSafeInner T_max M_box
                  (if (evalArithCond inp st.frameDepth st.mem c).1 then tB else fB) := by
                split_ifs <;> assumption
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.stmt_pos hfd hbr hrest) hbox hrun
          | whileLoop c hb =>
              simp only [runArithRAMFuel] at hrun
              rcases hc : evalArithCond inp st.frameDepth st.mem c with ⟨flag, u_c⟩
              rw [hc] at hrun; dsimp only at hrun
              cases flag with
              | false =>
                  simp only [Bool.false_eq_true, ↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_outer inp fuel rest _ out hrest hbox hrun
              | true =>
                  simp only [↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                    (.stmt_pos hfd hb (.stmt_pos hfd (.whileLoop c hb) hrest)) hbox hrun
          | repeatN cntE hb =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.repeat_pos hfd hb hrest) hbox hrun
          | localScope hb =>
              simp only [st, runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_outer inp fuel _ _ out
                (.stmt_pos (by simp) hb (.pop_succ hrest)) (heapOnlyInBox_popDepth fd hbox) hrun

theorem runArithRAMWithBits_outer_box {d T_max M_box : ℕ}
    {stmt : ArithRAMStmt} (hstmt : BoxSafeOuter T_max M_box stmt)
    {inp : ArithRAMInput d} {mem₀ : ArithRAMMemory} {bs : List Bool} {out : ArithRAMExecOutcome}
    (hbox₀ : HeapOnlyInBox T_max M_box mem₀)
    (hrun : runArithRAMWithBits stmt inp mem₀ bs = some out) :
    HeapOnlyInBox T_max M_box out.mem ∧ out.mem.popDepth 0 = out.mem := by
  classical
  unfold runArithRAMWithBits at hrun
  dsimp only at hrun
  split_ifs at hrun with hex
  generalize hr : runArithRAMFuel inp (Nat.find hex) [.stmt stmt] _ = res at hrun
  cases res with
  | needMoreBits | unusedBits | outOfFuel => simp at hrun
  | halted o =>
      have hout_eq : o = out := Option.some.inj hrun
      subst hout_eq
      exact ⟨runArithRAMFuel_preserves_box_outer inp (Nat.find hex) [.stmt stmt] _ o
               (.stmt_zero hstmt .nil_zero) (heapOnlyInBox_popDepth 0 hbox₀) hr,
             runArithRAMFuel_out_popDepth_zero inp (Nat.find hex) [.stmt stmt] _ o hr⟩

private lemma totalEvents_const_one_outer {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) :
    ∀ (l : List (List Bool)) (cur out : AdaptivePrefixState d State),
      runAdaptiveStepsFrom alg adv cur l = some out →
        adaptiveStepsTotalEvents alg adv (fun _ _ _ _ _ => 1) cur l = l.length
  | [], _, _, _ => by simp [adaptiveStepsTotalEvents]
  | b :: tail, cur, out, hrun => by
      simp only [runAdaptiveStepsFrom] at hrun
      simp only [adaptiveStepsTotalEvents]
      cases hs : runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) b with
      | none => rw [hs] at hrun; simp at hrun
      | some res =>
          rcases res with ⟨P', stepOut⟩
          rw [hs] at hrun
          have ih := totalEvents_const_one_outer alg adv tail _ out hrun
          dsimp only [List.length_cons]
          rw [ih]; omega

private lemma runAdaptiveStepsFrom_append_one_outer {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) :
    ∀ (xs : List (List Bool)) (b : List Bool) (cur : AdaptivePrefixState d State),
      runAdaptiveStepsFrom alg adv cur (xs ++ [b]) =
        match runAdaptiveStepsFrom alg adv cur xs with
        | none => none
        | some mid => runAdaptiveStepsFrom alg adv mid [b]
  | [], _, _ => rfl
  | x :: xs, b, cur => by
      simp only [List.cons_append, runAdaptiveStepsFrom]
      cases runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) x with
      | none => rfl
      | some res => exact runAdaptiveStepsFrom_append_one_outer alg adv xs b _

/-- Outer `fd = 0` horizon bridge for `prog := { initStmt := .skip, updateStmt := updateStmt0 }`. -/
theorem p46_horizon_bridge_outer
    (h_fb : S_clm_7_3_failure_budget)
    {d n t : ℕ} (hn : 2 ≤ n) (ht : 1 ≤ t)
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (updateStmt0 : ArithRAMStmt)
    {B_step uBound T_max M_box : ℕ}
    (hBoxSafe : BoxSafeOuter T_max M_box updateStmt0)
    {φ_step stepWorkBound spaceBound : ℝ}
    (SafeInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop)
    (GoodInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop)
    (hφ_le : φ_step ≤ perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ)
    (hu_le : (max 1 uBound : ℝ) ≤ stepWorkBound)
    (hs_le : ((max 1 (3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound) : ℕ) : ℝ) ≤ spaceBound)
    (hSafe₀ : SafeInv 0 (DynamicPointSet.empty d) ArithRAMMemory.empty)
    (hGood₀ : GoodInv 0 (DynamicPointSet.empty d) ArithRAMMemory.empty)
    (hStep : ∀ (k : ℕ) (P : DynamicPointSet d) (mem₀ : ArithRAMMemory) (op : DynamicUpdate d),
      k < t →
      P.WellFormed n →
      mem₀.popDepth 0 = mem₀ →
      HeapOnlyInBox T_max M_box mem₀ →
      SafeInv k P mem₀ →
      IsLegalUpdate n Set.univ P op →
        ∃ (Post : (Fin B_step → Bool) → ArithRAMMemory → Prop)
          (Bad : (Fin B_step → Bool) → Prop) (_ : DecidablePred Bad),
          RandExecAt 0 (mkStepInput n P op) updateStmt0 B_step mem₀ Post uBound ∧
          ((Finset.univ.filter Bad).card : ℝ) ≤ φ_step * ((2 : ℝ) ^ B_step) ∧
          (∀ (bits : Fin B_step → Bool) (m₁ : ArithRAMMemory),
            Post bits m₁ →
              let m_out := m₁.popDepth 0
              ∃ P' : DynamicPointSet d,
                applyDynamicUpdate P op (readStepRetH op m_out) = some P' ∧
                SafeInv (k + 1) P' m_out ∧
                (GoodInv k P mem₀ → ¬ Bad bits →
                  IsValidFactorCAnswer (Real.sqrt 2) P' (readStoredAns m_out) ∧
                  GoodInv (k + 1) P' m_out))) :
    let prog : ArithRAMDynamicProgram := { initStmt := .skip, updateStmt := updateStmt0 }
    ∃ initOut : ArithRAMExecOutcome,
      prog.evalInit n d = some initOut ∧
      let alg := mkArithAlg d n prog initOut
      SatisfiesDynamicStorageAndQueryModel 4 1 alg ∧
      SatisfiesMonteCarloGuarantee n t δ (Real.sqrt 2) Set.univ alg ∧
      SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg stepWorkBound ∧
      SatisfiesBoundedSpaceBound n t Set.univ alg spaceBound := by
  classical
  intro prog
  have hpop_emp : ArithRAMMemory.empty.popDepth 0 = ArithRAMMemory.empty := by
    simp [ArithRAMMemory.popDepth, ArithRAMMemory.empty, WordStore.popDepth, WordStore.empty,
      RealStore.popDepth, RealStore.empty]
  have hinit_det : DetExec
      ({ intParams := [(n : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0, extraReals := [] } :
        ArithRAMInput d)
      .skip (ArithRAMMemory.empty.popDepth 0) (ArithRAMMemory.empty.popDepth 0) 1 :=
    (DetExecAt.skip 0 _ _).mono_cost (by omega)
  rcases DetExec.to_spec hinit_det with ⟨initOut, hinit_some, hinit_u, hinit_pk, hinit_mem⟩
  have hinit_mem_emp : initOut.mem = ArithRAMMemory.empty := by
    rw [hinit_mem, hpop_emp, hpop_emp]
  have hca_emp : ArithRAMDynamicProgram.readCachedAnswer initOut.mem = (none, 0) := by
    rw [hinit_mem_emp]
    simp [ArithRAMDynamicProgram.readCachedAnswer, ArithRAMMemory.empty,
      WordStore.read, WordStore.empty, RealStore.read, RealStore.empty]
  refine ⟨initOut, hinit_some, ?_⟩
  intro alg
  have hSM : SatisfiesDynamicStorageAndQueryModel 4 1 alg :=
    mkArithAlg_satisfies_storage_query_model d n prog initOut hca_emp
  let ReachInv : DynamicPointSet d → ExecutionHistory d → ArithRAMMemory → Prop :=
    fun P hist mem =>
      P.WellFormed n ∧
      mem.popDepth 0 = mem ∧
      HeapOnlyInBox T_max M_box mem ∧
      SafeInv hist.length P mem
  have hReach₀ : ReachInv (DynamicPointSet.empty d) [] alg.initState := by
    dsimp only [ReachInv, alg, mkArithAlg, List.length_nil]
    rw [hinit_mem_emp]
    refine ⟨?_, hpop_emp, heapOnlyInBox_empty T_max M_box, hSafe₀⟩
    exact ⟨Nat.zero_le n, fun _ h => by simp [DynamicPointSet.empty] at h,
      fun _ h => by simp [DynamicPointSet.empty] at h,
      fun _ h => by simp [DynamicPointSet.empty] at h,
      fun _ h => by simp [DynamicPointSet.empty] at h⟩
  have hstep_eq : ∀ (P : DynamicPointSet d) (mem : ArithRAMMemory)
      (op : DynamicUpdate d) (bs : List Bool),
      alg.stepWithBits P.activeHandles P.handleCoords mem (toInternalUpdate P op) bs =
      (runArithRAMWithBits updateStmt0 (mkStepInput n P op) mem bs).map (fun raw =>
        let ca := ArithRAMDynamicProgram.readCachedAnswer raw.mem
        { nextState := raw.mem
          returnedHandle := readStepRetH op raw.mem
          storedAnswer := { diameterHandles := ca.1, cachedDistSq := ca.2 }
          work := raw.unitCost
          peakSpace := raw.peakCellSpace }) := by
    intro P mem op bs
    cases op with
    | insert id ext pt =>
        simp [alg, mkArithAlg, prog, ArithRAMDynamicProgram.evalUpdate,
          mkStepInput, toInternalUpdate, readStepRetH]
    | delete id =>
        simp [alg, mkArithAlg, prog, ArithRAMDynamicProgram.evalUpdate,
          mkStepInput, toInternalUpdate, readStepRetH]
  have hReach_trace : ∀ (adv : AdaptiveAdversary d),
      IsValidBoundedAdversary n t Set.univ alg adv →
      ∀ (bitTrace : List (List Bool)) (prefSt : AdaptivePrefixState d ArithRAMMemory),
        bitTrace.length ≤ t →
        runAdaptiveSteps alg adv bitTrace = some prefSt →
          prefSt.history.length = bitTrace.length ∧
          ReachInv prefSt.pointSet prefSt.history prefSt.algState := by
    intro adv hadv bitTrace
    induction bitTrace using List.reverseRecOn with
    | nil =>
        intro prefSt _ hrun
        simp only [runAdaptiveSteps, runAdaptiveStepsFrom] at hrun
        injection hrun with heq; subst heq
        exact ⟨rfl, hReach₀⟩
    | append_singleton xs b ih =>
        intro prefSt hlen hrun
        simp only [List.length_append, List.length_singleton] at hlen
        change runAdaptiveStepsFrom alg adv (initAdaptivePrefixState alg) (xs ++ [b]) = some prefSt at hrun
        rw [runAdaptiveStepsFrom_append_one_outer] at hrun
        cases hmid_eq : runAdaptiveStepsFrom alg adv (initAdaptivePrefixState alg) xs with
        | none => rw [hmid_eq] at hrun; simp at hrun
        | some mid =>
            rw [hmid_eq] at hrun
            dsimp only at hrun
            rcases ih mid (by omega) hmid_eq with ⟨hlen_mid, hP_wf, hclean, hbox, hsafe⟩
            have hleg : IsLegalUpdate n Set.univ mid.pointSet (adv mid.history) :=
              hadv xs (by omega) mid hmid_eq
            rcases hStep xs.length mid.pointSet mid.algState (adv mid.history)
              (by omega) hP_wf hclean hbox (hlen_mid ▸ hsafe) hleg with
              ⟨Post, _, _, hRE, _, hPost_imp⟩
            have hRE0 : RandExec (mkStepInput n mid.pointSet (adv mid.history))
                updateStmt0 B_step (mid.algState.popDepth 0) Post uBound := by
              rwa [hclean]
            rcases RandExec.to_spec hRE0 with ⟨hnone_ne, hsome_ofFn⟩
            dsimp only [runAdaptiveStepsFrom] at hrun
            cases hs1 : runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) b with
            | none => rw [hs1] at hrun; simp at hrun
            | some pair =>
                rw [hs1] at hrun
                rcases pair with ⟨P', stepOut⟩
                injection hrun with hpref_eq
                subst hpref_eq
                simp only [runSingleAdaptiveStep, hstep_eq] at hs1
                cases hraw : runArithRAMWithBits updateStmt0
                    (mkStepInput n mid.pointSet (adv mid.history)) mid.algState b with
                | none => rw [hraw] at hs1; simp at hs1
                | some raw =>
                    rw [hraw] at hs1
                    simp only [Option.map_some] at hs1
                    have hb_len : b.length = B_step := by
                      by_contra hne
                      have := hnone_ne b hne
                      rw [hraw] at this; simp at this
                    let bits : Fin B_step → Bool := fun j => b[j.val]'(by omega)
                    have hb_ofFn : List.ofFn bits = b := by
                      apply List.ext_getElem
                      · simp [hb_len]
                      · intro i _ _; simp [bits]
                    rcases hsome_ofFn bits with ⟨raw', hraw', _, _, m₁, hPost_m1, hm_eq⟩
                    rw [hb_ofFn, hraw] at hraw'
                    injection hraw' with hraw_eq; subst hraw_eq
                    have hbox1 : HeapOnlyInBox T_max M_box raw.mem :=
                      (runArithRAMWithBits_outer_box hBoxSafe hbox hraw).1
                    rcases hPost_imp bits m₁ hPost_m1 with ⟨P'', happ'', hsafe1, _⟩
                    rw [← hm_eq] at happ'' hsafe1
                    rw [happ''] at hs1
                    injection hs1 with hpair_eq
                    rcases Prod.mk.inj hpair_eq with ⟨hp_eq, hout_eq⟩
                    subst hp_eq hout_eq
                    refine ⟨by simp [hlen_mid], ?_, ?_, hbox1, ?_⟩
                    · exact applyDynamicUpdate_wellFormed hP_wf hleg happ''
                    · rw [hm_eq]; exact popDepth_zero_idem m₁
                    · simpa [hlen_mid] using hsafe1
  let S := execFailureScaleBit n t d 0 δ
  let φ := perEventFailureBudget S 1 δ
  have ht_le_S : (t : ℝ) ≤ 1 * ((S : ℝ) ^ 1) := by
    have : t ≤ S := by unfold S execFailureScaleBit; omega
    simpa using (show (t : ℝ) ≤ (S : ℝ) from by exact_mod_cast this)
  have hSφ_le_δ : (1 * ((S : ℝ) ^ 1)) * φ ≤ δ := by
    have hS_ne : (S : ℝ) ≠ 0 := by
      have : 0 < S := by unfold S execFailureScaleBit; omega
      exact_mod_cast (by omega : S ≠ 0)
    dsimp [φ, perEventFailureBudget]
    field_simp
    exact le_rfl
  have hinit_w : (alg.initWork : ℝ) ≤ stepWorkBound := by
    have h1 : (alg.initWork : ℝ) ≤ ((max 1 uBound : ℕ) : ℝ) := by
      dsimp [alg, mkArithAlg]
      exact_mod_cast (hinit_u.trans (le_max_left 1 uBound))
    rw [Nat.cast_max, Nat.cast_one] at h1
    exact h1.trans hu_le
  have hinit_sp : (alg.initSpace : ℝ) ≤ spaceBound := by
    have hpk2 : initOut.peakCellSpace ≤ 2 := by
      have h0 : ({ intParams := [(n : ℤ)], activeHandles := ∅, activeCoords := fun _ => 0,
                   extraReals := [] } : ArithRAMInput d).inputCellSpace +
          ArithRAMMemory.empty.cellCount = 1 := by
        simp [ArithRAMInput.inputCellSpace, ArithRAMMemory.cellCount, ArithRAMMemory.empty,
          WordStore.cellCount, WordStore.empty, RealStore.cellCount, RealStore.empty]
      rw [h0] at hinit_pk
      omega
    have h2_le : 2 ≤ max 1 (3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound) :=
      (by omega : 2 ≤ 3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound).trans (le_max_right 1 _)
    have h1 : (alg.initSpace : ℝ) ≤
        ((max 1 (3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound) : ℕ) : ℝ) := by
      dsimp [alg, mkArithAlg]
      exact_mod_cast (hpk2.trans h2_le)
    exact h1.trans hs_le
  let GoodState : DynamicPointSet d → ExecutionHistory d → ArithRAMMemory → Prop :=
    fun P hist mem =>
      GoodInv hist.length P mem ∧
      (hist ≠ [] → IsValidFactorCAnswer (Real.sqrt 2) P (readStoredAns mem))
  have hGoodState₀ : GoodState (DynamicPointSet.empty d) [] alg.initState := by
    dsimp [GoodState, alg, mkArithAlg]
    rw [hinit_mem_emp]
    exact ⟨hGood₀, fun hne => False.elim (hne rfl)⟩
  have h5 := h_fb.2.2.2.2 d n t 0 δ (Real.sqrt 2) stepWorkBound spaceBound 1 1 1 t
    Set.univ ArithRAMMemory alg GoodState (fun _ _ _ _ _ => 1)
    hn ht hδ0 hδ1 ht_le_S hSφ_le_δ hinit_w hinit_sp hGoodState₀
    (fun adv hadv => by
      refine ⟨?_, ?_⟩
      · intro T trace hT hsome
        rcases Option.isSome_iff_exists.mp hsome with ⟨out, hout⟩
        have htot := totalEvents_const_one_outer alg adv (List.ofFn trace) _ out hout
        simpa [htot] using hT
      · intro bitTrace prefSt hlt hrun
        dsimp only
        rcases hReach_trace adv hadv bitTrace prefSt (le_of_lt hlt) hrun with
          ⟨hlen_hist, hP_wf, hclean, hbox, hsafe⟩
        set op := adv prefSt.history
        have hleg : IsLegalUpdate n Set.univ prefSt.pointSet op := hadv bitTrace hlt prefSt hrun
        rcases hStep bitTrace.length prefSt.pointSet prefSt.algState op
          hlt hP_wf hclean hbox (hlen_hist ▸ hsafe) hleg with
          ⟨Post, Bad, instDecBad, hRE, hBad_card, hPost_imp⟩
        letI : DecidablePred Bad := instDecBad
        have hRE0 : RandExec (mkStepInput n prefSt.pointSet op) updateStmt0 B_step
            (prefSt.algState.popDepth 0) Post uBound := by rwa [hclean]
        rcases RandExec.to_spec hRE0 with ⟨hnone_ne, hsome_ofFn⟩
        have hsingle_none : ∀ bs : List Bool, bs.length ≠ B_step →
            runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs = none := by
          intro bs hne
          simp [runSingleAdaptiveStep, hstep_eq, hnone_ne bs hne]
        have hsingle_ofFn : ∀ bits : Fin B_step → Bool,
            ∃ (raw : ArithRAMExecOutcome) (m₁ : ArithRAMMemory) (P' : DynamicPointSet d),
              Post bits m₁ ∧ raw.mem = m₁.popDepth 0 ∧
              raw.unitCost ≤ uBound ∧
              raw.peakCellSpace ≤ (mkStepInput n prefSt.pointSet op).inputCellSpace +
                prefSt.algState.cellCount + raw.unitCost ∧
              applyDynamicUpdate prefSt.pointSet op (readStepRetH op raw.mem) = some P' ∧
              runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op (List.ofFn bits) =
                some (P', { nextState := raw.mem
                            returnedHandle := readStepRetH op raw.mem
                            storedAnswer := readStoredAns raw.mem
                            work := raw.unitCost
                            peakSpace := raw.peakCellSpace }) := by
          intro bits
          rcases hsome_ofFn bits with ⟨raw, hraw, hu, hpk, m₁, hpm1, hmem_eq⟩
          rcases hPost_imp bits m₁ hpm1 with ⟨P', happ, _, _⟩
          rw [← hmem_eq] at happ
          refine ⟨raw, m₁, P', hpm1, hmem_eq, hu, hpk, happ, ?_⟩
          simp [runSingleAdaptiveStep, hstep_eq, hraw, happ, readStoredAns]
        refine ⟨?_, ?_, ?_⟩
        · unfold singleStepValidHaltProb
          rw [tsum_listBool_of_fixedLength B_step _ (fun bs hne => by simp [hsingle_none bs hne])]
          have heq_sum :
              (∑ bits : Fin B_step → Bool,
                if (runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op
                    (List.ofFn bits)).isSome then bitListProb (List.ofFn bits) else 0) =
              ∑ bits : Fin B_step → Bool, bitListProb (List.ofFn bits) := by
            refine Finset.sum_congr rfl fun bits _ => ?_
            rcases hsingle_ofFn bits with ⟨_, _, _, _, _, _, _, _, hs⟩
            simp [hs]
          rw [heq_sum]
          exact sum_bitListProb_ofFn B_step
        · intro bs P' out hs
          have hbs_len : bs.length = B_step := by
            by_contra hne; rw [hsingle_none bs hne] at hs; simp at hs
          let bits : Fin B_step → Bool := fun j => bs[j.val]'(by omega)
          have hbs_eq : List.ofFn bits = bs := by
            apply List.ext_getElem
            · simp [hbs_len]
            · intro i _ _; simp [bits]
          rcases hsingle_ofFn bits with ⟨raw, _, P'', _, _, hu, hpk, _, hs'⟩
          rw [hbs_eq, hs] at hs'
          injection hs' with hpair_eq
          rcases Prod.mk.inj hpair_eq with ⟨hp_eq, hout_eq⟩
          subst hp_eq hout_eq
          refine ⟨?_, ?_⟩
          · have h1 : (raw.unitCost : ℝ) ≤ ((max 1 uBound : ℕ) : ℝ) := by
              exact_mod_cast (hu.trans (le_max_right 1 uBound))
            rw [Nat.cast_max, Nat.cast_one] at h1
            exact h1.trans hu_le
          · have hinp_sp := mkStepInput_space_le hP_wf op
            have hmem_sp : prefSt.algState.cellCount ≤ 2 * (T_max * M_box) := by
              rw [← hclean]
              exact cellCount_popDepth_zero_le_of_box hbox
            have hpk_tot : raw.peakCellSpace ≤
                max 1 (3 + n * (d + 1) + d + 2 * (T_max * M_box) + uBound) :=
              (hpk.trans (by omega)).trans (le_max_right 1 _)
            exact (show (raw.peakCellSpace : ℝ) ≤ _ from by exact_mod_cast hpk_tot).trans hs_le
        · intro hGood_cur
          have hGood_cur' : GoodInv bitTrace.length prefSt.pointSet prefSt.algState :=
            hlen_hist ▸ hGood_cur.1
          refine ⟨?_, ?_⟩
          · intro bs P' out hs hGood_next
            have hbs_len : bs.length = B_step := by
              by_contra hne; rw [hsingle_none bs hne] at hs; simp at hs
            let bits : Fin B_step → Bool := fun j => bs[j.val]'(by omega)
            have hbs_eq : List.ofFn bits = bs := by
              apply List.ext_getElem
              · simp [hbs_len]
              · intro i _ _; simp [bits]
            rcases hsingle_ofFn bits with ⟨raw, _, P'', _, _, _, _, _, hs'⟩
            rw [hbs_eq, hs] at hs'
            injection hs' with hpair_eq
            rcases Prod.mk.inj hpair_eq with ⟨hp_eq, hout_eq⟩
            subst hp_eq hout_eq
            exact hGood_next.2 (by simp)
          · dsimp only
            rw [tsum_listBool_of_fixedLength B_step _ (fun bs hne => by
              cases h : runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs with
              | none => rfl
              | some _ => rw [hsingle_none bs hne] at h; simp at h)]
            rw [tsum_listBool_of_fixedLength B_step _ (fun bs hne => by
              rw [hsingle_none bs hne]; simp)]
            refine le_trans
              (b := ∑ bits : Fin B_step → Bool,
                if Bad bits then bitListProb (List.ofFn bits) else 0) ?_ ?_
            · refine Finset.sum_le_sum fun bits _ => ?_
              rcases hsingle_ofFn bits with ⟨raw, m₁, P', hpm1, hmem_eq, _, _, happ_b, hs_b⟩
              rw [hs_b]
              dsimp only
              by_cases hB : Bad bits
              · simp only [hB, ↓reduceIte]
                split_ifs <;> simp
              · simp only [hB, ↓reduceIte]
                rcases hPost_imp bits m₁ hpm1 with ⟨P'', happ'', _, hG_imp⟩
                rw [← hmem_eq, happ_b] at happ''
                injection happ'' with hp_eq; subst hp_eq
                rcases hG_imp hGood_cur' hB with ⟨hans_ok, hG1⟩
                rw [← hmem_eq] at hans_ok hG1
                have hG_true : GoodState P'
                    (prefSt.history ++
                      [{ operation := op, randomBits := List.ofFn bits,
                         returnedHandle := readStepRetH op raw.mem,
                         answer := readStoredAns raw.mem,
                         resolvedIds := resolveAnswerIdentities P' (readStoredAns raw.mem) }])
                    raw.mem := by
                  refine ⟨?_, fun _ => hans_ok⟩
                  simpa [hlen_hist] using hG1
                simp [hG_true]
            · refine ((sum_bitListProb_filter_le B_step Bad hBad_card).trans
                (ENNReal.ofReal_le_ofReal hφ_le)).trans_eq ?_
              symm
              calc _
                  = (∑ bits : Fin B_step → Bool, bitListProb (List.ofFn bits)) *
                      ENNReal.ofReal (perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ) := by
                    rw [Finset.sum_mul]
                    refine Finset.sum_congr rfl fun bits _ => ?_
                    rcases hsingle_ofFn bits with ⟨_, _, _, _, _, _, _, _, hs_b⟩
                    simp [hs_b]
                _ = ENNReal.ofReal (perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ) := by
                    rw [sum_bitListProb_ofFn B_step, one_mul])
  exact ⟨hSM, h5.1, h5.2.1, h5.2.2⟩

/-- Consume exactly `B` dummy random bits inside a `.localScope`, leaving all heap state unchanged. -/
def randDummyBitsStmt (B : ℕ) : ArithRAMStmt :=
  .localScope (.repeatN (.lit (B : ℤ)) (.randBitLocal 29 (.lit 0)))

theorem boxSafe_randDummyBitsStmt {T_max M_box : ℕ} (B : ℕ) :
    BoxSafeOuter T_max M_box (randDummyBitsStmt B) :=
  .localScope (.repeatN _ (.randBitLocal _ _))

theorem exec_randDummyBitsStmt {d : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory) (B : ℕ) :
    RandExecAt 0 inp (randDummyBitsStmt B) B mem
      (fun _ m' => m' = mem.popDepth 0) (10 + 10 * B) := by
  let Inv : ℕ → (ℕ → Fin 1 → Bool) → ArithRAMMemory → Prop :=
    fun _ _ m => m.popDepth 0 = mem.popDepth 0
  have hInv0 : Inv 0 (fun _ _ => false) (mem.popDepth 0) := popDepth_zero_idem mem
  have hstep : ∀ i < B, ∀ chunks m, Inv i chunks m →
      RandExecAt 1 inp (.randBitLocal 29 (.lit 0)) 1 m
        (fun b m' => Inv (i + 1) (Function.update chunks i b) m') 10 := by
    intro i _ chunks m hm
    refine (RandExecAt.randBitLocal (C := 10) 1 inp m 29 (.lit 0) rfl (by simp [intExprOps])).mono ?_ le_rfl
    intro b m' hm'
    subst hm'
    exact (popDepth_zero_wWriteL_one m 29 0 _).trans hm
  have hrep := RandExecAt.repeatN_nat (.lit (B : ℤ)) (.randBitLocal 29 (.lit 0)) B 1 10 10
    Inv (chunks₀ := fun _ _ => false) hInv0 rfl (by simp [intExprOps]) hstep
  have hrep' : RandExecAt 1 inp (.repeatN (.lit (B : ℤ)) (.randBitLocal 29 (.lit 0))) B
      (mem.popDepth 0) (fun _ m_B => m_B.popDepth 0 = mem.popDepth 0) (10 + 10 * B) := by
    refine (hrep.congr_bits (Nat.mul_one B) ?_).mono (fun _ _ h => h) (by ring_nf; omega)
    rintro _ m_B ⟨_, hmB, _⟩
    exact hmB
  refine (RandExecAt.localScope hrep').mono ?_ le_rfl
  rintro _ m' ⟨m₁, hm₁, rfl⟩
  exact hm₁

/-! ### 2. `fd = 0` HPJ Centerpoint Call (`runHPJOnSlotStmt`) and Provisional Ball Helper -/

lemma liftedPoint_liftedBase_last {d : ℕ} (z : EuclideanSpace ℝ (Fin (d + 1))) :
    liftedPoint (liftedBase z) (z (Fin.last d)) = z := by
  ext i
  cases i using Fin.lastCases <;> simp [liftedPoint, liftedBase, Fin.init]

lemma hpjAlpha_eq_p46 {d D : ℕ} (hD : D = d + 3) :
    hpjAlpha d = 1 / (4 * ((D : ℝ) ^ 2)) := by
  subst hD
  unfold hpjAlpha
  push_cast
  ring

/-- Scope 1 of active `runHPJOnSlotStmt`: draw `2 ^ p.P_hpj.q` `p.M_bits`-bit rank samples from
slot `s = wRead mem 26 1`, read their snapshot coordinates, and store all `(2 ^ p.P_hpj.q) * d`
coordinates into Real Heap Table `27`. -/
def hpjSampleIterDetStmt (d n K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 28 (.lit 20) (.readLocal 29 (.lit 20)),
    .writeWordLocal 28 (.lit 21) (.mod (.readLocal 29 (.lit 12)) (.readLocal 29 (.lit 10))),
    selectByRankSegStmt K,
    .writeWordLocal 29 (.lit 21) (.readLocal 28 (.lit 0)),
    readSlotPtToLocalStmt d n 0,
    .writeWordLocal 29 (.lit 14) (.mul (.readLocal 29 (.lit 11)) (.lit (d : ℤ))),
    storeLocalCoordsToHeapStmt d M_box 27 14 0,
    .writeWordLocal 29 (.lit 11) (.add (.readLocal 29 (.lit 11)) (.lit 1))
  ]

def hpjSampleScopeStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  let N_samp := 2 ^ p.P_hpj.q
  .localScope (seqList [
    .writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 1)),
    .writeWordLocal 29 (.lit 20) (.readHeap 26 (.lit 1)),
    cardAndMaxSegSlotStmt p.K_seg (.readLocal 28 (.lit 20)),
    .writeWordLocal 29 (.lit 10) (.readLocal 28 (.lit 0)),
    .writeWordLocal 29 (.lit 11) (.lit 0),
    .repeatN (.lit (N_samp : ℤ))
      (.seq (readRandNatLocalStmt 29 12 13 p.M_bits)
            (hpjSampleIterDetStmt d n p.K_seg M_box))
  ])

theorem boxSafe_hpjSampleScopeStmt {d n T_max M_box : ℕ} (hT : 28 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (hpjSampleScopeStmt d n M_box p) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact boxSafe_cardAndMaxSegSlotStmt _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .repeatN _ (.seq (boxSafeInner_readRandNatLocalStmt _ _ _ _ _ _) ?_)
    refine boxSafeInner_seqList ?_
    intro s' hs'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_selectByRankSegStmt _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_readSlotPtToLocalStmt _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_storeLocalCoordsToHeapStmt _ _ (by omega) _ _
    · exact .writeWordLocal _ _ _

/-- Scope 2 of active `runHPJOnSlotStmt`: starting from wiped `localFrame 1`, set up `100`, `101`,
and `102` from Real Heap Table `27` using loop index `103[0]`, execute `locStmt N_samp hpjProg`,
and copy `(o_0 .. o_{d-1}, s_val)` from `rReadL 1 _ 0` into Real Heap Table `27[0 .. d]`. -/
def hpjWalkSetupStmt (d N_samp k_φ : ℕ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 103 (.lit 0) (.lit 0),
    .repeatN (.lit (N_samp : ℤ)) (seqList [
      .writeWordLocal 100 (.readLocal 103 (.lit 0)) (.readLocal 103 (.lit 0)),
      .writeWordLocal 103 (.lit 0) (.add (.readLocal 103 (.lit 0)) (.lit 1))
    ]),
    .writeRealLocal 101 (.lit 0) (.ofInt (.lit 1)),
    .repeatN (.lit (k_φ : ℤ))
      (.writeRealLocal 101 (.lit 0)
        (.mul (.readRealLocal 101 (.lit 0)) (.div (.ofInt (.lit 1)) (.ofInt (.lit 2))))),
    .writeWordLocal 103 (.lit 0) (.lit 0),
    .repeatN (.lit (((N_samp * d : ℕ) : ℤ))) (seqList [
      .writeRealLocal 102 (.readLocal 103 (.lit 0))
        (.readRealHeap 27 (.readLocal 103 (.lit 0))),
      .writeWordLocal 103 (.lit 0) (.add (.readLocal 103 (.lit 0)) (.lit 1))
    ])
  ]

def hpjWalkCopyOutStmt (d M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .writeWordLocal 103 (.lit 0) (.lit 0),
    .repeatN (.lit (d : ℤ)) (seqList [
      boxWriteR M_box 27 (.readLocal 103 (.lit 0)) (.readRealLocal 0 (.readLocal 103 (.lit 0))),
      .writeWordLocal 103 (.lit 0) (.add (.readLocal 103 (.lit 0)) (.lit 1))
    ]),
    boxWriteR M_box 27 (.lit (d : ℤ)) (.readRealLocal 0 (.lit (d : ℤ)))
  ]

def hpjWalkScopeStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  let N_samp := 2 ^ p.P_hpj.q
  .localScope
    (.seq (hpjWalkSetupStmt d N_samp p.k_φ)
          (.seq (locStmt N_samp hpjProg) (hpjWalkCopyOutStmt d M_box)))

theorem boxSafe_hpjWalkScopeStmt {d n T_max M_box : ℕ} (hT : 28 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (hpjWalkScopeStmt d n M_box p) := by
  refine .localScope (.seq ?_ (.seq (boxSafeInner_locStmt _ _ _ localizable_hpjProg) ?_))
  · refine boxSafeInner_seqList ?_
    intro s hs
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .repeatN _ (boxSafeInner_seqList fun s' hs' => by
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
        rcases hs' with rfl | rfl <;> exact .writeWordLocal _ _ _)
    · exact .writeRealLocal _ _ _
    · exact .repeatN _ (.writeRealLocal _ _ _)
    · exact .writeWordLocal _ _ _
    · exact .repeatN _ (boxSafeInner_seqList fun s' hs' => by
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
        rcases hs' with rfl | rfl
        · exact .writeRealLocal _ _ _
        · exact .writeWordLocal _ _ _)
  · refine boxSafeInner_seqList ?_
    intro s hs
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .repeatN _ (boxSafeInner_seqList fun s' hs' => by
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
        rcases hs' with rfl | rfl
        · exact .boxR (by omega) _ _
        · exact .writeWordLocal _ _ _)
    · exact .boxR (by omega) _ _

/-- Conditional `fd = 0` HPJ call consuming `p.B_hpj` bits: active when `wRead mem 26 0 == 1` on
slot `s = wRead mem 26 1`, otherwise consumes `p.B_hpj` dummy bits. -/
def runHPJOnSlotStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  .ite (.intEq (.readHeap 26 (.lit 0)) (.lit 1))
    (.seq (hpjSampleScopeStmt d n M_box p) (hpjWalkScopeStmt d n M_box p))
    (randDummyBitsStmt p.B_hpj)

theorem boxSafe_runHPJOnSlotStmt {d n T_max M_box : ℕ} (hT : 28 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (runHPJOnSlotStmt d n M_box p) :=
  .ite _ (.seq (boxSafe_hpjSampleScopeStmt hT p) (boxSafe_hpjWalkScopeStmt hT p))
    (boxSafe_randDummyBitsStmt _)

noncomputable def hpjCallCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  250 * (2 ^ p.P_hpj.q + 1) * (p.M_bits + p.K_seg + d + 5) +
    30 * p.k_φ + 8 * Nat.ceil (hpjOpBound d p.φ_ev) + 16 * p.B_hpj + 500

theorem exec_hpjSampleScopeStmt {d n M_box : ℕ}
    (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    {activeH : Finset ℕ} {livePts snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    (hs_reg : wRead mem 26 1 = (s : ℤ))
    (hS_pos : 0 < S.card)
    (hBox_samp : (2 ^ p.P_hpj.q) * d ≤ M_box)
    (hSeg : EncSegSlot p.K_seg mem s S fSq)
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hSlot : EncSlotCoords d n mem activeH livePts s S snapPts) :
    let N_samp := 2 ^ p.P_hpj.q
    let B_samp := N_samp * p.M_bits
    RandExecAt 0 inp (hpjSampleScopeStmt d n M_box p) B_samp mem
      (fun sampBits m₁ =>
        m₁.popDepth 0 = m₁ ∧
        (∀ t idx, wRead m₁ t idx = wRead mem t idx) ∧
        (∀ t, t ≠ 27 → ∀ idx, rRead m₁ t idx = rRead mem t idx) ∧
        let fChunks : Fin N_samp → Fin p.M_bits → Bool := fun j b =>
          sampBits ⟨j.val * p.M_bits + b.val, by
            calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
              _ = (j.val + 1) * p.M_bits := by ring
              _ ≤ N_samp * p.M_bits := Nat.mul_le_mul_right _ j.isLt⟩
        let rk := modSampleTuple hS_pos N_samp p.M_bits fChunks
        ∀ (j : Fin N_samp) (c : Fin d),
          rRead m₁ 27 (((j.val * d + c.val : ℕ) : ℤ)) =
            euclideanCoord (snapPts (S.orderEmbOfFin rfl (rk j))) c)
      (200 * (2 ^ p.P_hpj.q + 1) * (p.M_bits + p.K_seg + d + 5)) := by
  intro N_samp B_samp
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 28 20 (s : ℤ)
  let m2 := wWriteL 1 m1 29 20 (s : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 1))) m0 m1 6 :=
    DetExecAt.writeWordLocal 1 inp m0 28 _ _ rfl (by simp [m0, hs_reg]) (by simp [intExprOps])
  have hs2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 20) (.readHeap 26 (.lit 1))) m1 m2 6 :=
    DetExecAt.writeWordLocal 1 inp m1 29 _ _ rfl (by simp [m1, m0, hs_reg]) (by simp [intExprOps])
  have hSeg_m2 : EncSegSlot p.K_seg m2 s S fSq :=
    hSeg.congr_mem_fSq (by simp [m2, m1, m0]) (fun _ _ => by simp [m2, m1, m0])
      (fun _ _ => by simp [m2, m1, m0]) (fun _ _ => by simp [m2, m1, m0])
      (fun _ _ => by simp [m2, m1, m0]) (fun _ _ => rfl)
  rcases exec_cardAndMaxSegSlotStmt inp m2 (.readLocal 28 (.lit 20)) (by simp [m2, m1]) hSeg_m2
    with ⟨m3, hs3, hm3_card, _, hw3, hr3, hwl3, hrl3⟩
  let m4 := wWriteL 1 m3 29 10 (S.card : ℤ)
  let m5 := wWriteL 1 m4 29 11 0
  have hs4 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 10) (.readLocal 28 (.lit 0))) m3 m4 6 :=
    DetExecAt.writeWordLocal 1 inp m3 29 _ _ rfl (by simp [hm3_card]) (by simp [intExprOps])
  have hs5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 11) (.lit 0)) m4 m5 4 :=
    DetExecAt.writeWordLocal 1 inp m4 29 _ _ rfl rfl (by simp [intExprOps])
  let C_iter : ℕ := 180 * (p.M_bits + p.K_seg + d + 5)
  let Inv : ℕ → (ℕ → Fin p.M_bits → Bool) → ArithRAMMemory → Prop :=
    fun j chunks m =>
      (∀ t idx, wRead m t idx = wRead mem t idx) ∧
      (∀ t, t ≠ 27 → ∀ idx, rRead m t idx = rRead mem t idx) ∧
      wReadL 1 m 29 20 = (s : ℤ) ∧
      wReadL 1 m 29 10 = (S.card : ℤ) ∧
      wReadL 1 m 29 11 = (j : ℤ) ∧
      ∀ (k : ℕ), k < j → ∀ c : Fin d,
        rRead m 27 (((k * d + c.val : ℕ) : ℤ)) =
          euclideanCoord
            (snapPts (S.orderEmbOfFin rfl ⟨bitsFnToNat p.M_bits (chunks k) % S.card, Nat.mod_lt _ hS_pos⟩)) c
  have hInv0 : Inv 0 (fun _ _ => false) m5 := by
    refine ⟨fun t idx => by simp [m5, m4, hw3, m2, m1, m0],
      fun t _ idx => by simp [m5, m4, hr3, m2, m1, m0],
      by simp [m5, m4, hwl3 29 (by decide), m2],
      by simp [m5, m4], by simp [m5], fun _ hk => by omega⟩
  have hStep : ∀ j < N_samp, ∀ (chunks : ℕ → Fin p.M_bits → Bool) (m : ArithRAMMemory),
      Inv j chunks m →
        RandExecAt 1 inp
          (.seq (readRandNatLocalStmt 29 12 13 p.M_bits) (hpjSampleIterDetStmt d n p.K_seg M_box))
          p.M_bits m
          (fun b m' => Inv (j + 1) (Function.update chunks j b) m') C_iter := by
    intro j hj chunks m ⟨hw_m, hr_m, hm20, hm10, hm11, hprev⟩
    have hrand := exec_readRandNatLocalStmt (by decide : 1 ≤ 1) inp 29 12 13 (by decide) p.M_bits m
    refine (RandExecAt.seq_det_right hrand (C₂ := 80 * (p.K_seg + 1) + 80 * (d + 1) + 100) ?_).mono
      (fun _ _ h => h) (by dsimp [C_iter]; omega)
    intro b mr ⟨hmr12, hmr_wl, hmr_rl, hmr_w, hmr_r, _⟩
    let rawNat := bitsFnToNat p.M_bits b
    let rk : ℕ := rawNat % S.card
    have hrk_lt : rk < S.card := Nat.mod_lt _ hS_pos
    let md1 := wWriteL 1 mr 28 20 (s : ℤ)
    let md2 := wWriteL 1 md1 28 21 (rk : ℤ)
    have hd1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readLocal 29 (.lit 20))) mr md1 6 := by
      refine DetExecAt.writeWordLocal 1 inp mr 28 _ _ rfl ?_ (by simp [intExprOps])
      simp [hmr_wl 29 20 (Or.inr ⟨by decide, by decide⟩), hm20]
    have hd2 : DetExecAt 1 inp
        (.writeWordLocal 28 (.lit 21) (.mod (.readLocal 29 (.lit 12)) (.readLocal 29 (.lit 10))))
        md1 md2 8 := by
      refine DetExecAt.writeWordLocal 1 inp md1 28 _ _ rfl ?_ (by simp [intExprOps])
      have h29_ne : (29 : ℕ) ≠ 28 := by decide
      simp only [iValAt_mod, iValAt_readLocal, iValAt_lit, md1, wReadL_wWriteL_eq,
        h29_ne, false_and, ↓reduceIte,
        hmr12, hmr_wl 29 10 (Or.inr ⟨by decide, by decide⟩), hm10]
      dsimp [rk]
    have hSeg_md2 : EncSegSlot p.K_seg md2 s S fSq :=
      hSeg.congr_mem_fSq
        (by simp [md2, md1, hmr_w, hw_m])
        (fun _ _ => by simp [md2, md1, hmr_w, hw_m])
        (fun _ _ => by simp [md2, md1, hmr_w, hw_m])
        (fun _ _ => by simp [md2, md1, hmr_w, hw_m])
        (fun _ _ => by simp [md2, md1, hmr_r, hr_m 8 (by decide)])
        (fun _ _ => rfl)
    rcases exec_selectByRankSegStmt inp md2 hrk_lt (by simp [md2, md1]) (by simp [md2]) hSeg_md2
      with ⟨md3, hd3, hmd3_sel, hw_d3, hr_d3, hwl_d3, _⟩
    let selH : ℕ := S.orderEmbOfFin rfl ⟨rk, hrk_lt⟩
    have hselH_in : selH ∈ S := S.orderEmbOfFin_mem rfl ⟨rk, hrk_lt⟩
    let md4 := wWriteL 1 md3 29 21 (selH : ℤ)
    have hd4 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 21) (.readLocal 28 (.lit 0))) md3 md4 6 :=
      DetExecAt.writeWordLocal 1 inp md3 29 _ _ rfl (by simp [hmd3_sel, selH]) (by simp [intExprOps])
    have hLive_md4 : EncLiveCoords d n md4 activeH livePts :=
      ⟨hLive.1, fun h hh c => by
        simp only [md4, rRead_wWriteL, hr_d3, md2, md1, hmr_r, hr_m 4 (by decide)]
        exact hLive.2 h hh c⟩
    have hSlot_md4 : EncSlotCoords d n md4 activeH livePts s S snapPts := by
      refine ⟨hSlot.1, ?_⟩
      rcases hSlot.2 with ⟨hg0, hsub, heq⟩ | ⟨hg1, hmap⟩
      · left; exact ⟨by simp [md4, hw_d3, md2, md1, hmr_w, hw_m, hg0], hsub, heq⟩
      · right
        refine ⟨by simp [md4, hw_d3, md2, md1, hmr_w, hw_m]; exact hg1, fun h hh => ?_⟩
        rcases hmap h hh with ⟨h1, h2⟩
        refine ⟨fun heq => fun c => ?_, fun hne => h2 ?_⟩
        · simp only [md4, rRead_wWriteL, hr_d3, md2, md1, hmr_r, hr_m 11 (by decide)]
          exact h1 (by simpa [md4, hw_d3, md2, md1, hmr_w, hw_m] using heq) c
        · simpa [md4, hw_d3, md2, md1, hmr_w, hw_m] using hne
    rcases exec_readSlotPtToLocalStmt inp md4 (destOff := 0) (s := s) (h := selH)
        (by simp [md4, hwl_d3 29 (by decide), md2, md1,
          hmr_wl 29 20 (Or.inr ⟨by decide, by decide⟩), hm20])
        (by simp [md4]) hselH_in hLive_md4 hSlot_md4
      with ⟨md5, hd5, hpt_d5, hw_d5, hr_d5, hwl_d5, _, _, _⟩
    let md6 := wWriteL 1 md5 29 14 (((j * d : ℕ) : ℤ))
    have hd6 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 14) (.mul (.readLocal 29 (.lit 11)) (.lit (d : ℤ))))
        md5 md6 8 := by
      refine DetExecAt.writeWordLocal 1 inp md5 29 _ _ rfl ?_ (by simp [intExprOps])
      have h11 : wReadL 1 md5 29 11 = (j : ℤ) := by
        rw [hwl_d5 11 (by decide) (by decide) (by decide)]
        simp [md4, hwl_d3 29 (by decide), md2, md1,
          hmr_wl 29 11 (Or.inr ⟨by decide, by decide⟩), hm11]
      simp [h11]
    have hjd_box : j * d + d ≤ M_box := by
      calc j * d + d = (j + 1) * d := by ring
        _ ≤ N_samp * d := Nat.mul_le_mul_right d hj
        _ ≤ M_box := hBox_samp
    rcases exec_storeLocalCoordsToHeapStmt inp md6 (M_box := M_box) (rTag := 27)
        (idxBase := 14) (srcOff := 0) (base := j * d) (pt := snapPts selH)
        (by decide) (by simp [md6]) hjd_box
        (fun c => by simpa [md6] using hpt_d5 c)
      with ⟨md7, hd7, hst_c, hst_out, hst_rt, hst_w, hst_wl, _, _, _⟩
    let md8 := wWriteL 1 md7 29 11 (((j + 1 : ℕ) : ℤ))
    have hd8 : DetExecAt 1 inp
        (.writeWordLocal 29 (.lit 11) (.add (.readLocal 29 (.lit 11)) (.lit 1))) md7 md8 8 := by
      refine DetExecAt.writeWordLocal 1 inp md7 29 _ _ rfl ?_ (by simp [intExprOps])
      have h11 : wReadL 1 md7 29 11 = (j : ℤ) := by
        rw [hst_wl 11 (by decide)]
        simp [md6]
        rw [hwl_d5 11 (by decide) (by decide) (by decide)]
        simp [md4, hwl_d3 29 (by decide), md2, md1,
          hmr_wl 29 11 (Or.inr ⟨by decide, by decide⟩), hm11]
      simp [h11]
    refine ⟨md8,
      (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq hd8))))))).mono_cost (by omega),
      fun t idx => by simp [md8, hst_w, md6, hw_d5, md4, hw_d3, md2, md1, hmr_w, hw_m],
      fun t ht idx => by simp [md8, hst_rt t ht, md6, hr_d5, md4, hr_d3, md2, md1, hmr_r, hr_m t ht],
      by
        simp [md8]
        rw [hst_wl 20 (by decide)]
        simp [md6]
        rw [hwl_d5 20 (by decide) (by decide) (by decide)]
        simp [md4, hwl_d3 29 (by decide), md2, md1,
          hmr_wl 29 20 (Or.inr ⟨by decide, by decide⟩), hm20],
      by
        simp [md8]
        rw [hst_wl 10 (by decide)]
        simp [md6]
        rw [hwl_d5 10 (by decide) (by decide) (by decide)]
        simp [md4, hwl_d3 29 (by decide), md2, md1,
          hmr_wl 29 10 (Or.inr ⟨by decide, by decide⟩), hm10],
      by simp [md8],
      ?_⟩
    intro k hk c
    rcases Nat.lt_succ_iff_lt_or_eq.mp hk with hk_lt | rfl
    · have hne : k ≠ j := Nat.ne_of_lt hk_lt
      have hout_k : (((k * d + c.val : ℕ) : ℤ)) < (((j * d : ℕ) : ℤ)) ∨
          (((j * d + d : ℕ) : ℤ)) ≤ (((k * d + c.val : ℕ) : ℤ)) := by
        left
        have hlt_nat : k * d + c.val < j * d := by
          calc k * d + c.val < k * d + d := by omega
            _ = (k + 1) * d := by ring
            _ ≤ j * d := Nat.mul_le_mul_right d hk_lt
        exact_mod_cast hlt_nat
      simp only [Function.update, hne, ↓reduceDIte, md8, rRead_wWriteL, hst_out _ hout_k,
        md6, hr_d5, md4, hr_d3, md2, md1, hmr_r]
      exact hprev k hk_lt c
    · simp only [Function.update, ↓reduceDIte, md8, rRead_wWriteL]
      exact hst_c c
  have hrep := RandExecAt.repeatN_nat (.lit (N_samp : ℤ)) _ N_samp p.M_bits 10 C_iter
    Inv hInv0 rfl (by simp [intExprOps]) hStep
  have hpre : DetExecAt 1 inp
      (.seq (.writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 1)))
        (.seq (.writeWordLocal 29 (.lit 20) (.readHeap 26 (.lit 1)))
          (.seq (cardAndMaxSegSlotStmt p.K_seg (.readLocal 28 (.lit 20)))
            (.seq (.writeWordLocal 29 (.lit 10) (.readLocal 28 (.lit 0)))
                  (.writeWordLocal 29 (.lit 11) (.lit 0))))))
      m0 m5 (45 * (p.K_seg + 1) + 40) :=
    (hs1.seq (hs2.seq (hs3.seq (hs4.seq hs5)))).mono_cost (by simp [intExprOps]; omega)
  -- Reassociate seqList in hpjSampleScopeStmt
  have hbody : RandExecAt 1 inp
      (seqList [
        .writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 1)),
        .writeWordLocal 29 (.lit 20) (.readHeap 26 (.lit 1)),
        cardAndMaxSegSlotStmt p.K_seg (.readLocal 28 (.lit 20)),
        .writeWordLocal 29 (.lit 10) (.readLocal 28 (.lit 0)),
        .writeWordLocal 29 (.lit 11) (.lit 0),
        .repeatN (.lit (N_samp : ℤ))
          (.seq (readRandNatLocalStmt 29 12 13 p.M_bits)
                (hpjSampleIterDetStmt d n p.K_seg M_box))
      ])
      B_samp m0
      (fun sampBits m_end =>
        (∀ t idx, wRead m_end t idx = wRead mem t idx) ∧
        (∀ t, t ≠ 27 → ∀ idx, rRead m_end t idx = rRead mem t idx) ∧
        let fChunks : Fin N_samp → Fin p.M_bits → Bool := fun j b =>
          sampBits ⟨j.val * p.M_bits + b.val, by
            calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
              _ = (j.val + 1) * p.M_bits := by ring
              _ ≤ N_samp * p.M_bits := Nat.mul_le_mul_right _ j.isLt⟩
        let rk := modSampleTuple hS_pos N_samp p.M_bits fChunks
        ∀ (j : Fin N_samp) (c : Fin d),
          rRead m_end 27 (((j.val * d + c.val : ℕ) : ℤ)) =
            euclideanCoord (snapPts (S.orderEmbOfFin rfl (rk j))) c)
      (200 * (N_samp + 1) * (p.M_bits + p.K_seg + d + 5)) := by
    dsimp only [seqList]
    -- Use RandExecAt.seq_det_left step-by-step
    have hr5 := RandExecAt.seq_det_left hs5 hrep
    have hr4 := RandExecAt.seq_det_left hs4 hr5
    have hr3 := RandExecAt.seq_det_left hs3 hr4
    have hr2 := RandExecAt.seq_det_left hs2 hr3
    have hr1 := RandExecAt.seq_det_left hs1 hr2
    refine hr1.mono ?_ ?_
    · rintro sampBits m_end ⟨chunks_N, ⟨hw_end, hr_end, _, _, _, hcoord_end⟩, hchunks_eq⟩
      refine ⟨hw_end, hr_end, fun j c => ?_⟩
      have hcj := hchunks_eq j
      have h1 := hcoord_end j.val j.isLt c
      rw [hcj] at h1
      exact h1
    · simp only [intExprOps, C_iter]
      have hmul : N_samp * (180 * (p.M_bits + p.K_seg + d + 5)) =
          180 * N_samp * (p.M_bits + p.K_seg + d + 5) := by ring
      have hsub1 : 180 * N_samp * (p.M_bits + p.K_seg + d + 5) ≤
          200 * N_samp * (p.M_bits + p.K_seg + d + 5) :=
        Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (by omega))
      have hsub2 : 200 * (1 * (p.M_bits + p.K_seg + d + 5)) ≥ 1000 := by omega
      have hexp : 200 * (N_samp + 1) * (p.M_bits + p.K_seg + d + 5) =
          200 * N_samp * (p.M_bits + p.K_seg + d + 5) +
          200 * (1 * (p.M_bits + p.K_seg + d + 5)) := by ring
      omega
  refine (RandExecAt.localScope hbody).mono ?_ le_rfl
  rintro sampBits m₁ ⟨m_end, ⟨hw_e, hr_e, hcoord_e⟩, rfl⟩
  exact ⟨popDepth_zero_idem m_end,
    fun t idx => by simp [hw_e],
    fun t ht idx => by simp [hr_e t ht],
    fun j c => by simp only [rRead_popDepth]; exact hcoord_e j c⟩

theorem exec_hpjWalkScopeStmt {d n M_box : ℕ}
    (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (ptsM : Fin (2 ^ p.P_hpj.q) → EuclideanSpace ℝ (Fin d))
    (hkφ : p.φ_ev = (1 / 2 : ℝ) ^ p.k_φ)
    (hφ0 : 0 < p.φ_ev) (hφ1 : p.φ_ev < 1 / 2)
    (hp_eq : p.P_hpj = hpjParams d p.φ_ev)
    (hp_props : HPJParamProps d p.φ_ev p.P_hpj)
    (hBox_d : d + 1 ≤ M_box)
    (hptsM : ∀ (k : Fin (2 ^ p.P_hpj.q)) (c : Fin d),
      rRead mem 27 (((k.val * d + c.val : ℕ) : ℤ)) = euclideanCoord (ptsM k) c) :
    let N_samp := 2 ^ p.P_hpj.q
    let B_walk := p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q
    RandExecAt 0 inp (hpjWalkScopeStmt d n M_box p) B_walk mem
      (fun walkBits m₂ =>
        m₂.popDepth 0 = m₂ ∧
        (∀ t idx, wRead m₂ t idx = wRead mem t idx) ∧
        (∀ t, t ≠ 27 → ∀ idx, rRead m₂ t idx = rRead mem t idx) ∧
        let z := radonWalkOutput (d + 1) p.P_hpj.q p.P_hpj.L (fun j => paraboloidLift (ptsM j)) walkBits
        (∀ c : Fin d, rRead m₂ 27 (c.val : ℤ) = euclideanCoord (liftedBase z) c) ∧
        rRead m₂ 27 (d : ℤ) = z (Fin.last d))
      (50 * (N_samp + 1) * (d + 2) + 30 * p.k_φ + 8 * Nat.ceil (hpjOpBound d p.φ_ev) + 200) := by
  intro N_samp B_walk
  let loc0 := mem.popDepth 0
  -- Part A: deterministic setup of 100, 101, 102 from `loc0`
  have hSetup : ∃ locS : ArithRAMMemory,
      DetExecAt 1 inp (hpjWalkSetupStmt d N_samp p.k_φ) loc0 locS
        (25 * N_samp + 20 * p.k_φ + 25 * (N_samp * d) + 50) ∧
      locS.popDepth 0 = loc0 ∧
      HPJMemRel N_samp ptsM p.φ_ev (ArithRAMMemory.empty.popDepth 0) locS := by
    let la0 := wWriteL 1 loc0 103 0 0
    have ha0 : DetExecAt 1 inp (.writeWordLocal 103 (.lit 0) (.lit 0)) loc0 la0 4 :=
      DetExecAt.writeWordLocal 1 inp loc0 103 _ _ rfl rfl (by simp [intExprOps])
    let InvA : ℕ → ArithRAMMemory → Prop := fun k m =>
      m.popDepth 0 = loc0 ∧
      (∀ t < 100, ∀ idx, wReadL 1 m t idx = 0) ∧
      (∀ v idx, rReadL 1 m v idx = 0) ∧
      wReadL 1 m 103 0 = (k : ℤ) ∧
      ∀ idx : ℤ, wReadL 1 m 100 idx = if 0 ≤ idx ∧ idx < (k : ℤ) then idx else 0
    have hInvA0 : InvA 0 la0 := by
      refine ⟨(popDepth_zero_wWriteL_one loc0 103 0 0).trans (popDepth_zero_idem mem),
        fun t ht idx => by simp [la0, loc0, show t ≠ 103 by omega],
        fun v idx => by simp [la0, loc0],
        by simp [la0],
        fun idx => by
          have hnot : ¬ (0 ≤ idx ∧ idx < (0 : ℤ)) := by omega
          simp [la0, loc0, hnot]⟩
    have hStepA : ∀ k < N_samp, ∀ m, InvA k m →
        ∃ m', DetExecAt 1 inp
          (seqList [
            .writeWordLocal 100 (.readLocal 103 (.lit 0)) (.readLocal 103 (.lit 0)),
            .writeWordLocal 103 (.lit 0) (.add (.readLocal 103 (.lit 0)) (.lit 1))
          ]) m m' 20 ∧ InvA (k + 1) m' := by
      intro k _ m ⟨hpop, ht0, hr0, hm103, h100⟩
      let ms1 := wWriteL 1 m 100 (k : ℤ) (k : ℤ)
      let ms2 := wWriteL 1 ms1 103 0 (((k + 1 : ℕ) : ℤ))
      have hb1 : DetExecAt 1 inp
          (.writeWordLocal 100 (.readLocal 103 (.lit 0)) (.readLocal 103 (.lit 0))) m ms1 8 :=
        DetExecAt.writeWordLocal 1 inp m 100 _ _ (by simp [hm103]) (by simp [hm103]) (by simp [intExprOps])
      have hb2 : DetExecAt 1 inp
          (.writeWordLocal 103 (.lit 0) (.add (.readLocal 103 (.lit 0)) (.lit 1))) ms1 ms2 8 :=
        DetExecAt.writeWordLocal 1 inp ms1 103 _ _ rfl (by simp [ms1, hm103]) (by simp [intExprOps])
      refine ⟨ms2, (hb1.seq hb2).mono_cost (by omega),
        (popDepth_zero_wWriteL_one ms1 103 0 _).trans ((popDepth_zero_wWriteL_one m 100 _ _).trans hpop),
        fun t ht idx => by simp [ms2, ms1, show t ≠ 103 by omega, show t ≠ 100 by omega, ht0 t ht idx],
        fun v idx => by simp [ms2, ms1, hr0 v idx],
        by simp [ms2],
        fun idx => ?_⟩
      have h100_ne : (100 : ℕ) ≠ 103 := by decide
      simp only [ms2, ms1, wReadL_wWriteL_eq, h100_ne, false_and, ↓reduceIte,
        true_and, h100 idx]
      by_cases heq : idx = (k : ℤ)
      · subst heq; simp [show (0 : ℤ) ≤ (k : ℤ) by omega, show (k : ℤ) < (((k + 1 : ℕ) : ℤ)) by omega]
      · simp only [heq, ↓reduceIte]
        have hiff : (0 ≤ idx ∧ idx < (k : ℤ)) ↔ (0 ≤ idx ∧ idx < (((k + 1 : ℕ) : ℤ))) := by omega
        by_cases hcond : 0 ≤ idx ∧ idx < (k : ℤ)
        · rw [if_pos hcond, if_pos (hiff.mp hcond)]
        · rw [if_neg hcond, if_neg (fun h => hcond (hiff.mpr h))]
    rcases DetExecAt.repeatN_nat (.lit (N_samp : ℤ)) _ N_samp 4 20 InvA hInvA0 rfl (by simp [intExprOps]) hStepA
      with ⟨laN, ⟨hpopA, ht0A, hr0A, _, h100A⟩, hrepA⟩
    -- Setup 101
    let lb0 := rWriteL 1 laN 101 0 1
    have hb0 : DetExecAt 1 inp (.writeRealLocal 101 (.lit 0) (.ofInt (.lit 1))) laN lb0 6 :=
      DetExecAt.writeRealLocal 1 inp laN 101 _ _ rfl (by simp) (by simp [intExprOps, realExprOps])
    let InvB : ℕ → ArithRAMMemory → Prop := fun k m =>
      m.popDepth 0 = loc0 ∧
      (∀ t < 100, ∀ idx, wReadL 1 m t idx = 0) ∧
      (∀ t < 100, ∀ idx, rReadL 1 m t idx = 0) ∧
      (∀ idx : ℤ, wReadL 1 m 100 idx = if 0 ≤ idx ∧ idx < (N_samp : ℤ) then idx else 0) ∧
      (∀ idx : ℤ, rReadL 1 m 101 idx = if idx = 0 then (1 / 2 : ℝ) ^ k else 0)
    have hInvB0 : InvB 0 lb0 := by
      refine ⟨(popDepth_zero_rWriteL_one laN 101 0 1).trans hpopA,
        fun t ht idx => by simp [lb0, ht0A t ht idx],
        fun t ht idx => by simp [lb0, show t ≠ 101 by omega, hr0A t idx],
        fun idx => by simp [lb0, h100A idx],
        fun idx => by by_cases h : idx = 0 <;> simp [lb0, h, hr0A 101 idx]⟩
    have hStepB : ∀ k < p.k_φ, ∀ m, InvB k m →
        ∃ m', DetExecAt 1 inp
          (.writeRealLocal 101 (.lit 0)
            (.mul (.readRealLocal 101 (.lit 0)) (.div (.ofInt (.lit 1)) (.ofInt (.lit 2)))))
          m m' 16 ∧ InvB (k + 1) m' := by
      intro k _ m ⟨hpop, ht0, hr0, h100, h101⟩
      let ms1 := rWriteL 1 m 101 0 ((1 / 2 : ℝ) ^ (k + 1))
      have hb1 : DetExecAt 1 inp
          (.writeRealLocal 101 (.lit 0)
            (.mul (.readRealLocal 101 (.lit 0)) (.div (.ofInt (.lit 1)) (.ofInt (.lit 2)))))
          m ms1 16 := by
        refine DetExecAt.writeRealLocal 1 inp m 101 _ _ rfl ?_ (by simp [intExprOps, realExprOps])
        simp [h101 0, pow_succ]
      refine ⟨ms1, hb1, (popDepth_zero_rWriteL_one m 101 0 _).trans hpop,
        fun t ht idx => by simp [ms1, ht0 t ht idx],
        fun t ht idx => by simp [ms1, show t ≠ 101 by omega, hr0 t ht idx],
        fun idx => by simp [ms1, h100 idx],
        fun idx => by by_cases h : idx = 0 <;> simp [ms1, h, h101 idx]⟩
    rcases DetExecAt.repeatN_nat (.lit (p.k_φ : ℤ)) _ p.k_φ 4 16 InvB hInvB0 rfl (by simp [intExprOps]) hStepB
      with ⟨lbN, ⟨hpopB, ht0B, hr0B, h100B, h101B⟩, hrepB⟩
    -- Setup 102
    let lc0 := wWriteL 1 lbN 103 0 0
    have hc0 : DetExecAt 1 inp (.writeWordLocal 103 (.lit 0) (.lit 0)) lbN lc0 4 :=
      DetExecAt.writeWordLocal 1 inp lbN 103 _ _ rfl rfl (by simp [intExprOps])
    let InvC : ℕ → ArithRAMMemory → Prop := fun k m =>
      m.popDepth 0 = loc0 ∧
      (∀ t < 100, ∀ idx, wReadL 1 m t idx = 0) ∧
      (∀ t < 100, ∀ idx, rReadL 1 m t idx = 0) ∧
      (∀ idx : ℤ, wReadL 1 m 100 idx = if 0 ≤ idx ∧ idx < (N_samp : ℤ) then idx else 0) ∧
      (∀ idx : ℤ, rReadL 1 m 101 idx = if idx = 0 then p.φ_ev else 0) ∧
      wReadL 1 m 103 0 = (k : ℤ) ∧
      (∀ i < k, rReadL 1 m 102 (i : ℤ) = rRead mem 27 (i : ℤ))
    have hInvC0 : InvC 0 lc0 := by
      refine ⟨(popDepth_zero_wWriteL_one lbN 103 0 0).trans hpopB,
        fun t ht idx => by simp [lc0, show t ≠ 103 by omega, ht0B t ht idx],
        fun t ht idx => by simp [lc0, hr0B t ht idx],
        fun idx => by simp [lc0, show (100 : ℕ) ≠ 103 by decide, h100B idx],
        fun idx => by simp [lc0, h101B idx, hkφ],
        by simp [lc0],
        fun _ hi => by omega⟩
    have hStepC : ∀ k < N_samp * d, ∀ m, InvC k m →
        ∃ m', DetExecAt 1 inp
          (seqList [
            .writeRealLocal 102 (.readLocal 103 (.lit 0))
              (.readRealHeap 27 (.readLocal 103 (.lit 0))),
            .writeWordLocal 103 (.lit 0) (.add (.readLocal 103 (.lit 0)) (.lit 1))
          ]) m m' 20 ∧ InvC (k + 1) m' := by
      intro k _ m ⟨hpop, ht0, hr0, h100, h101, hm103, h102⟩
      have hr27_m : rRead m 27 (k : ℤ) = rRead mem 27 (k : ℤ) := by
        exact rRead_eq_of_popDepth_zero hpop 27 (k : ℤ)
      let ms1 := rWriteL 1 m 102 (k : ℤ) (rRead mem 27 (k : ℤ))
      let ms2 := wWriteL 1 ms1 103 0 (((k + 1 : ℕ) : ℤ))
      have hd1 : DetExecAt 1 inp
          (.writeRealLocal 102 (.readLocal 103 (.lit 0)) (.readRealHeap 27 (.readLocal 103 (.lit 0))))
          m ms1 10 :=
        DetExecAt.writeRealLocal 1 inp m 102 _ _ (by simp [hm103])
          (by simp [hm103, hr27_m]) (by simp [intExprOps, realExprOps])
      have hd2 : DetExecAt 1 inp
          (.writeWordLocal 103 (.lit 0) (.add (.readLocal 103 (.lit 0)) (.lit 1))) ms1 ms2 8 :=
        DetExecAt.writeWordLocal 1 inp ms1 103 _ _ rfl (by simp [ms1, hm103]) (by simp [intExprOps])
      refine ⟨ms2, (hd1.seq hd2).mono_cost (by omega),
        (popDepth_zero_wWriteL_one ms1 103 0 _).trans ((popDepth_zero_rWriteL_one m 102 _ _).trans hpop),
        fun t ht idx => by simp [ms2, ms1, show t ≠ 103 by omega, ht0 t ht idx],
        fun t ht idx => by simp [ms2, ms1, show t ≠ 102 by omega, hr0 t ht idx],
        fun idx => by simp [ms2, ms1, show (100 : ℕ) ≠ 103 by decide, h100 idx],
        fun idx => by simp [ms2, ms1, show (101 : ℕ) ≠ 102 by decide, h101 idx],
        by simp [ms2],
        fun i hi => ?_⟩
      rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
      · have hne : (i : ℤ) ≠ (k : ℤ) := by omega
        simp [ms2, ms1, hne, h102 i hlt]
      · simp [ms2, ms1]
    rcases DetExecAt.repeatN_nat (.lit (((N_samp * d : ℕ) : ℤ))) _ (N_samp * d) 4 20 InvC hInvC0 rfl
        (by simp [intExprOps]) hStepC
      with ⟨locS, ⟨hpopC, ht0C, hr0C, h100C, h101C, _, h102C⟩, hrepC⟩
    refine ⟨locS,
      (ha0.seq (hrepA.seq (hb0.seq (hrepB.seq (hc0.seq hrepC))))).mono_cost (by omega),
      hpopC,
      hpjMemRel_of_setup N_samp ptsM p.φ_ev locS ht0C hr0C h100C h101C (fun k c => ?_)⟩
    have hlt : k.val * d + c.val < N_samp * d := by
      calc k.val * d + c.val < k.val * d + d := by omega
        _ = (k.val + 1) * d := by ring
        _ ≤ N_samp * d := Nat.mul_le_mul_right d k.isLt
    have hcast : (k.val : ℤ) * (d : ℤ) + (c.val : ℤ) = (((k.val * d + c.val : ℕ) : ℤ)) := by
      push_cast; ring
    rw [hcast, h102C (k.val * d + c.val) hlt, hptsM k c]
  rcases hSetup with ⟨locS, hdSetup, hpopS, hrelS⟩
  have hWalk := sim_locStmt_hpjProg inp hφ0 hφ1 p.P_hpj hp_eq hp_props ptsM locS hrelS
  -- Combine with copy-out via RandExecAt.seq_det_right
  have hWalkAndCopy : RandExecAt 1 inp
      (.seq (locStmt N_samp hpjProg) (hpjWalkCopyOutStmt d M_box))
      B_walk locS
      (fun walkBits m_end =>
        (∀ t idx, wRead m_end t idx = wRead mem t idx) ∧
        (∀ t, t ≠ 27 → ∀ idx, rRead m_end t idx = rRead mem t idx) ∧
        let z := radonWalkOutput (d + 1) p.P_hpj.q p.P_hpj.L (fun j => paraboloidLift (ptsM j)) walkBits
        (∀ c : Fin d, rRead m_end 27 (c.val : ℤ) = euclideanCoord (liftedBase z) c) ∧
        rRead m_end 27 (d : ℤ) = z (Fin.last d))
      (8 * Nat.ceil (hpjOpBound d p.φ_ev) + (40 * d + 60)) := by
    refine RandExecAt.seq_det_right hWalk ?_
    rintro walkBits loc1 ⟨hpop1, hz_base, hz_last⟩
    let z := radonWalkOutput (d + 1) p.P_hpj.q p.P_hpj.L (fun j => paraboloidLift (ptsM j)) walkBits
    have hpop1_mem : loc1.popDepth 0 = loc0 := hpop1.trans hpopS
    let mc0 := wWriteL 1 loc1 103 0 0
    have hc0 : DetExecAt 1 inp (.writeWordLocal 103 (.lit 0) (.lit 0)) loc1 mc0 4 :=
      DetExecAt.writeWordLocal 1 inp loc1 103 _ _ rfl rfl (by simp [intExprOps])
    let InvO : ℕ → ArithRAMMemory → Prop := fun k m =>
      (∀ t idx, wRead m t idx = wRead mem t idx) ∧
      (∀ t, t ≠ 27 → ∀ idx, rRead m t idx = rRead mem t idx) ∧
      wReadL 1 m 103 0 = (k : ℤ) ∧
      (∀ idx, rReadL 1 m 0 idx = rReadL 1 loc1 0 idx) ∧
      (∀ c : Fin d, c.val < k → rRead m 27 (c.val : ℤ) = euclideanCoord (liftedBase z) c)
    have hInvO0 : InvO 0 mc0 := by
      refine ⟨fun t idx => by
          simp only [mc0, wRead_wWriteL]
          exact wRead_eq_of_popDepth_zero hpop1_mem t idx,
        fun t _ idx => by
          simp only [mc0, rRead_wWriteL]
          exact rRead_eq_of_popDepth_zero hpop1_mem t idx,
        by simp [mc0],
        fun idx => by simp [mc0],
        fun _ hc => by omega⟩
    have hStepO : ∀ k < d, ∀ m, InvO k m →
        ∃ m', DetExecAt 1 inp
          (seqList [
            boxWriteR M_box 27 (.readLocal 103 (.lit 0)) (.readRealLocal 0 (.readLocal 103 (.lit 0))),
            .writeWordLocal 103 (.lit 0) (.add (.readLocal 103 (.lit 0)) (.lit 1))
          ]) m m' 36 ∧ InvO (k + 1) m' := by
      intro k hk m ⟨hw_m, hr_m, hm103, hr0_m, hlo⟩
      let ms1 := rWrite m 27 (k : ℤ) (euclideanCoord (liftedBase z) ⟨k, hk⟩)
      let ms2 := wWriteL 1 ms1 103 0 (((k + 1 : ℕ) : ℤ))
      have hd1 : DetExecAt 1 inp
          (boxWriteR M_box 27 (.readLocal 103 (.lit 0)) (.readRealLocal 0 (.readLocal 103 (.lit 0))))
          m ms1 26 := by
        refine exec_boxWriteR inp m _ _ (by simp [hm103]) (by omega) (by omega) ?_
          (by simp [intExprOps, realExprOps])
        simp [hm103, hr0_m, hz_base ⟨k, hk⟩, z]
      have hd2 : DetExecAt 1 inp
          (.writeWordLocal 103 (.lit 0) (.add (.readLocal 103 (.lit 0)) (.lit 1))) ms1 ms2 8 :=
        DetExecAt.writeWordLocal 1 inp ms1 103 _ _ rfl (by simp [ms1, hm103]) (by simp [intExprOps])
      refine ⟨ms2, (hd1.seq hd2).mono_cost (by omega),
        fun t idx => by simp [ms2, ms1, hw_m],
        fun t ht idx => by simp [ms2, ms1, ht, hr_m t ht],
        by simp [ms2],
        fun idx => by simp [ms2, ms1, hr0_m],
        fun c hc => ?_⟩
      rcases Nat.lt_succ_iff_lt_or_eq.mp hc with hlt | heq
      · have hne : (c.val : ℤ) ≠ (k : ℤ) := by omega
        simp [ms2, ms1, hne, hlo c hlt]
      · have hc_eq : c = ⟨k, hk⟩ := Fin.ext heq
        subst hc_eq
        simp [ms2, ms1]
    rcases DetExecAt.repeatN_nat (.lit (d : ℤ)) _ d 4 36 InvO hInvO0 rfl (by simp [intExprOps]) hStepO
      with ⟨mcd, ⟨hw_cd, hr_cd, _, hr0_cd, hlo_cd⟩, hrepO⟩
    let m_end := rWrite mcd 27 (d : ℤ) (z (Fin.last d))
    have hlast : DetExecAt 1 inp
        (boxWriteR M_box 27 (.lit (d : ℤ)) (.readRealLocal 0 (.lit (d : ℤ)))) mcd m_end 20 := by
      refine exec_boxWriteR inp mcd _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps, realExprOps])
      simp [hr0_cd, hz_last, z]
    refine ⟨m_end, (hc0.seq (hrepO.seq hlast)).mono_cost (by omega),
      fun t idx => by simp [m_end, hw_cd],
      fun t ht idx => by simp [m_end, ht, hr_cd t ht],
      fun c => ?_,
      by simp [m_end, z]⟩
    have hne : (c.val : ℤ) ≠ (d : ℤ) := by have := c.isLt; omega
    simpa [m_end, hne, z] using hlo_cd c c.isLt
  have hBody := RandExecAt.seq_det_left hdSetup hWalkAndCopy
  refine (RandExecAt.localScope hBody).mono ?_ ?_
  · rintro walkBits m₂ ⟨m_end, ⟨hw_e, hr_e, hz_b, hz_l⟩, rfl⟩
    exact ⟨popDepth_zero_idem m_end,
      fun t idx => by simp [hw_e],
      fun t ht idx => by simp [hr_e t ht],
      fun c => by simp [hz_b c],
      by simp [hz_l]⟩
  · have h25 : 25 * (N_samp * d) ≤ 50 * (N_samp * d) := Nat.mul_le_mul_right _ (by omega)
    have hexp : 50 * (N_samp + 1) * (d + 2) =
        50 * (N_samp * d) + 100 * N_samp + 50 * d + 100 := by ring
    omega

/-- Full specification of `runHPJOnSlotStmt`:
- Inactive (`wRead mem 26 0 ≠ 1`): leaves all heap cells unchanged (`Bad = False`).
- Active (`wRead mem 26 0 = 1`): leaves all word heap cells and all real heap cells outside Table `27`
  unchanged, and outside a `Bad` set of cardinality `≤ (2 * p.φ_ev) * 2 ^ p.B_hpj`, produces a valid
  `(1 / (4 * D^2))`-centerpoint `(o_out, s_out)` of `S^+` in Real Table `27[0 .. d]`. -/
theorem exec_runHPJOnSlotStmt_inactive {d n M_box : ℕ}
    (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (hinact : wRead mem 26 0 ≠ 1) :
    RandExecAt 0 inp (runHPJOnSlotStmt d n M_box p) p.B_hpj mem
      (fun _ m' => m' = mem.popDepth 0) (hpjCallCost d n p) := by
  have hcond : cValAt 0 inp mem (.intEq (.readHeap 26 (.lit 0)) (.lit 1)) = false := by
    simp [hinact]
  exact (RandExecAt.ite_false hcond (C_c := 10) (by simp [condExprOps, intExprOps])
    (exec_randDummyBitsStmt inp mem p.B_hpj)).mono (fun _ _ h => h)
    (by unfold hpjCallCost; omega)

theorem exec_runHPJOnSlotStmt_active {d n M_box : ℕ}
    (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    {activeH : Finset ℕ} {livePts snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    (hact : wRead mem 26 0 = 1)
    (hs_reg : wRead mem 26 1 = (s : ℤ))
    (hS_pos : 0 < S.card) (hS_le_n : S.card ≤ n)
    (hD_eq : p.D = d + 3)
    (hkφ : p.φ_ev = (1 / 2 : ℝ) ^ p.k_φ)
    (hφ0 : 0 < p.φ_ev) (hφ1 : p.φ_ev < 1 / 2)
    (hp_eq : p.P_hpj = hpjParams d p.φ_ev)
    (hp_props : HPJParamProps d p.φ_ev p.P_hpj)
    (hbias_hpj : (((2 ^ p.P_hpj.q : ℕ) : ℝ) * (n : ℝ)) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev)
    (hB_hpj : p.B_hpj = (2 ^ p.P_hpj.q) * p.M_bits + p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q)
    (hBox_samp : (2 ^ p.P_hpj.q) * d ≤ M_box)
    (hBox_d : d + 1 ≤ M_box)
    (hSeg : EncSegSlot p.K_seg mem s S fSq)
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hSlot : EncSlotCoords d n mem activeH livePts s S snapPts) :
    ∃ (Post : (Fin p.B_hpj → Bool) → ArithRAMMemory → Prop)
      (Bad : (Fin p.B_hpj → Bool) → Prop) (_ : DecidablePred Bad),
      RandExecAt 0 inp (runHPJOnSlotStmt d n M_box p) p.B_hpj mem Post (hpjCallCost d n p) ∧
      ((Finset.univ.filter Bad).card : ℝ) ≤ (2 * p.φ_ev) * ((2 : ℝ) ^ p.B_hpj) ∧
      ∀ (bits : Fin p.B_hpj → Bool) (m' : ArithRAMMemory),
        Post bits m' →
          m'.popDepth 0 = m' ∧
          (∀ t idx, wRead m' t idx = wRead mem t idx) ∧
          (∀ t, t ≠ 27 → ∀ idx, rRead m' t idx = rRead mem t idx) ∧
          (¬ Bad bits →
            let o_out : EuclideanSpace ℝ (Fin d) :=
              WithLp.toLp 2 (fun c : Fin d => rRead m' 27 (c.val : ℤ))
            let s_out : ℝ := rRead m' 27 (d : ℤ)
            IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
              (paraboloidLiftSet (fun x : ↥S => snapPts x.1)) (liftedPoint o_out s_out)) := by
  classical
  let K := 2 ^ p.P_hpj.q
  let B_samp := K * p.M_bits
  let B_walk := p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q
  let B_tot := B_samp + B_walk
  let enumS : Fin S.card ≃ ↥S := (S.orderIsoOfFin rfl).toEquiv
  have henum_val : ∀ r : Fin S.card, (enumS r).1 = S.orderEmbOfFin rfl r := fun _ => rfl
  let BadTot : (Fin B_tot → Bool) → Prop := fun allBits =>
    let sampBits : Fin K → Fin p.M_bits → Bool := fun j b =>
      allBits ⟨j.val * p.M_bits + b.val, by
        calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
          _ = (j.val + 1) * p.M_bits := by ring
          _ ≤ K * p.M_bits := Nat.mul_le_mul_right p.M_bits j.isLt
          _ ≤ B_tot := Nat.le_add_right _ _⟩
    let walkBits : Fin B_walk → Bool := fun w =>
      allBits ⟨K * p.M_bits + w.val, Nat.add_lt_add_left w.isLt _⟩
    let rk := modSampleTuple hS_pos K p.M_bits sampBits
    let z := radonWalkOutput (d + 1) p.P_hpj.q p.P_hpj.L
      (fun j : Fin K => paraboloidLift (snapPts (enumS (rk j)).1)) walkBits
    ¬ IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun x : ↥S => snapPts x.1)) z
  have hcard_tot := hpj_combined_bad_card_le hφ0 hφ1 p.P_hpj hp_props snapPts S hS_pos enumS p.M_bits
  dsimp only at hcard_tot
  have hbias_S : ((K : ℝ) * (S.card : ℝ)) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev := by
    have hSle : (S.card : ℝ) ≤ (n : ℝ) := by exact_mod_cast hS_le_n
    have hK0 : (0 : ℝ) ≤ (K : ℝ) := Nat.cast_nonneg K
    have h2pos : (0 : ℝ) < (2 : ℝ) ^ p.M_bits := by positivity
    calc ((K : ℝ) * (S.card : ℝ)) / ((2 : ℝ) ^ p.M_bits)
        ≤ ((K : ℝ) * (n : ℝ)) / ((2 : ℝ) ^ p.M_bits) :=
          div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hSle hK0) (le_of_lt h2pos)
      _ ≤ p.φ_ev := hbias_hpj
  have hcard_tot2 : ((Finset.univ.filter BadTot).card : ℝ) ≤ (2 * p.φ_ev) * ((2 : ℝ) ^ B_tot) := by
    refine hcard_tot.trans ?_
    have h2pos : (0 : ℝ) ≤ (2 : ℝ) ^ B_tot := by positivity
    exact mul_le_mul_of_nonneg_right (by linarith) h2pos
  -- Execute Scope 1 followed by Scope 2
  have hS1 := exec_hpjSampleScopeStmt p inp mem hs_reg hS_pos hBox_samp hSeg hLive hSlot
  let PostTot : (Fin B_tot → Bool) → ArithRAMMemory → Prop := fun allBits m₂ =>
    m₂.popDepth 0 = m₂ ∧
    (∀ t idx, wRead m₂ t idx = wRead mem t idx) ∧
    (∀ t, t ≠ 27 → ∀ idx, rRead m₂ t idx = rRead mem t idx) ∧
    (¬ BadTot allBits →
      let o_out : EuclideanSpace ℝ (Fin d) :=
        WithLp.toLp 2 (fun c : Fin d => rRead m₂ 27 (c.val : ℤ))
      let s_out : ℝ := rRead m₂ 27 (d : ℤ)
      IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
        (paraboloidLiftSet (fun x : ↥S => snapPts x.1)) (liftedPoint o_out s_out))
  have hSeq : RandExecAt 0 inp (.seq (hpjSampleScopeStmt d n M_box p) (hpjWalkScopeStmt d n M_box p))
      B_tot mem PostTot
      (200 * (K + 1) * (p.M_bits + p.K_seg + d + 5) +
        (50 * (K + 1) * (d + 2) + 30 * p.k_φ + 8 * Nat.ceil (hpjOpBound d p.φ_ev) + 200)) := by
    refine RandExecAt.seq hS1 ?_
    rintro f₁ m₁ ⟨_, hw1, hr1, hpts1⟩
    let rk := modSampleTuple hS_pos K p.M_bits (fun j b =>
      f₁ ⟨j.val * p.M_bits + b.val, by
        calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
          _ = (j.val + 1) * p.M_bits := by ring
          _ ≤ K * p.M_bits := Nat.mul_le_mul_right _ j.isLt⟩)
    let ptsM : Fin K → EuclideanSpace ℝ (Fin d) := fun j => snapPts (enumS (rk j)).1
    have hS2 := exec_hpjWalkScopeStmt p inp m₁ ptsM hkφ hφ0 hφ1 hp_eq hp_props hBox_d
      (fun j c => by simpa [ptsM, henum_val] using hpts1 j c)
    refine hS2.mono ?_ le_rfl
    rintro f₂ m₂ ⟨hpop2, hw2, hr2, hz_base, hz_last⟩
    refine ⟨hpop2, fun t idx => (hw2 t idx).trans (hw1 t idx),
      fun t ht idx => (hr2 t ht idx).trans (hr1 t ht idx), ?_⟩
    intro hgood
    let combBits : Fin B_tot → Bool := fun j =>
      if hj : j.val < B_samp then f₁ ⟨j.val, hj⟩ else f₂ ⟨j.val - B_samp, by omega⟩
    have hf1_eq : (fun j : Fin K => fun b : Fin p.M_bits =>
        combBits ⟨j.val * p.M_bits + b.val, by
          calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
            _ = (j.val + 1) * p.M_bits := by ring
            _ ≤ K * p.M_bits := Nat.mul_le_mul_right _ j.isLt
            _ ≤ B_tot := Nat.le_add_right _ _⟩) =
        (fun j b => f₁ ⟨j.val * p.M_bits + b.val, by
          calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
            _ = (j.val + 1) * p.M_bits := by ring
            _ ≤ K * p.M_bits := Nat.mul_le_mul_right _ j.isLt⟩) := by
      ext j b
      have hlt : j.val * p.M_bits + b.val < B_samp := by
        calc j.val * p.M_bits + b.val < j.val * p.M_bits + p.M_bits := by omega
          _ = (j.val + 1) * p.M_bits := by ring
          _ ≤ K * p.M_bits := Nat.mul_le_mul_right _ j.isLt
      simp [combBits, hlt]
    have hf2_eq : (fun w : Fin B_walk =>
        combBits ⟨B_samp + w.val, Nat.add_lt_add_left w.isLt _⟩) = f₂ := by
      ext w
      have hnot : ¬ (B_samp + w.val < B_samp) := by omega
      simp [combBits, hnot]
    have hcp : IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun x : ↥S => snapPts x.1))
        (radonWalkOutput (d + 1) p.P_hpj.q p.P_hpj.L (fun j => paraboloidLift (ptsM j)) f₂) := by
      have hnot_bad : ¬ BadTot combBits := hgood
      unfold BadTot at hnot_bad
      rw [not_not] at hnot_bad
      simpa [B_samp, ptsM, hf1_eq, hf2_eq] using hnot_bad
    let z := radonWalkOutput (d + 1) p.P_hpj.q p.P_hpj.L (fun j => paraboloidLift (ptsM j)) f₂
    have ho_eq : (WithLp.toLp 2 (fun c : Fin d => rRead m₂ 27 (c.val : ℤ)) : EuclideanSpace ℝ (Fin d)) =
        liftedBase z := by
      ext c
      exact hz_base c
    dsimp only
    rw [ho_eq, hz_last]
    change IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
      (paraboloidLiftSet (fun x : ↥S => snapPts x.1))
      (liftedPoint (liftedBase z) (z (Fin.last d)))
    rw [liftedPoint_liftedBase_last, ← hpjAlpha_eq_p46 hD_eq]
    exact hcp
  have hcond : cValAt 0 inp mem (.intEq (.readHeap 26 (.lit 0)) (.lit 1)) = true := by
    simp [hact]
  have hIte := RandExecAt.ite_true (fB := randDummyBitsStmt p.B_hpj)
    hcond (C_c := 10) (by simp [condExprOps, intExprOps]) hSeq
  have hIte' : RandExecAt 0 inp (runHPJOnSlotStmt d n M_box p) p.B_hpj mem
      (fun bits m₂ => PostTot (fun i => bits ⟨i.val, hB_hpj ▸ i.isLt⟩) m₂) (hpjCallCost d n p) := by
    refine (hIte.congr_bits hB_hpj.symm (fun _ _ h => h)).mono (fun _ _ h => h) ?_
    unfold hpjCallCost
    dsimp only [K] at *
    have h2 : d + 2 ≤ p.M_bits + p.K_seg + d + 5 := by omega
    have h3 : 50 * (2 ^ p.P_hpj.q + 1) * (d + 2) ≤ 50 * (2 ^ p.P_hpj.q + 1) * (p.M_bits + p.K_seg + d + 5) :=
      Nat.mul_le_mul_left _ h2
    have h4 : 200 * (2 ^ p.P_hpj.q + 1) * (p.M_bits + p.K_seg + d + 5) +
        50 * (2 ^ p.P_hpj.q + 1) * (p.M_bits + p.K_seg + d + 5) =
        250 * (2 ^ p.P_hpj.q + 1) * (p.M_bits + p.K_seg + d + 5) := by ring
    omega
  let eBits : (Fin p.B_hpj → Bool) ≃ (Fin B_tot → Bool) :=
    Equiv.arrowCongr (finCongr hB_hpj) (Equiv.refl Bool)
  let BadOut : (Fin p.B_hpj → Bool) → Prop := fun bits => BadTot (eBits bits)
  have hcard_out : ((Finset.univ.filter BadOut).card : ℝ) ≤ (2 * p.φ_ev) * ((2 : ℝ) ^ p.B_hpj) := by
    have hbij : (Finset.univ.filter BadOut).card = (Finset.univ.filter BadTot).card := by
      refine Finset.card_bij (fun f _ => eBits f) ?_ (fun _ _ _ _ h => eBits.injective h) ?_
      · intro f hf; simp only [Finset.mem_filter, Finset.mem_univ, true_and, BadOut] at hf ⊢; exact hf
      · intro g hg; refine ⟨eBits.symm g, ?_, eBits.apply_symm_apply g⟩
        simp only [Finset.mem_filter, Finset.mem_univ, true_and, BadOut, eBits.apply_symm_apply] at hg ⊢
        exact hg
    rw [hbij, hB_hpj]
    exact hcard_tot2
  refine ⟨_, BadOut, inferInstance, hIte', hcard_out, fun bits m' hp => ?_⟩
  have heq_ebits : (fun i : Fin B_tot => bits ⟨i.val, hB_hpj ▸ i.isLt⟩) = eBits bits := by
    ext i; rfl
  rw [heq_ebits] at hp
  exact hp

/-- Deterministic Stage-1 provisional ball computation (`fd = 0`) after `runHPJOnSlotStmt`:
reads `(o_cand, s_cand)` from Real Table `27[0 .. d]`, computes `V_cand := s_cand - ‖o_cand‖^2`,
and writes `(prov.o, prov.V)` (`prov = provisionalCenter snapPts bId (.candidate o_cand V_cand)`)
back into Real Table `27[0 .. d]`. -/
def provisionalFromHPJStmt (d n K M_box : ℕ) : ArithRAMStmt :=
  let vIdx : IntExpr := .lit (((2 * d + 2 : ℕ) : ℤ))
  .localScope (seqList [
    .writeWordLocal 29 (.lit 2) (.lit 0),
    loadHeapCoordsToLocalStmt d 27 2 0,
    distSqLocalStmt d,
    .writeRealLocal 29 vIdx
      (.sub (.readRealHeap 27 (.lit (d : ℤ))) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))),
    .ite (.realLe (.ofInt (.lit 0)) (.readRealLocal 29 vIdx))
      (boxWriteR M_box 27 (.lit (d : ℤ)) (.readRealLocal 29 vIdx))
      (seqList [
        .writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 1)),
        .writeWordLocal 28 (.lit 21) (.lit 0),
        selectByRankSegStmt K,
        .writeWordLocal 29 (.lit 20) (.readHeap 26 (.lit 1)),
        .writeWordLocal 29 (.lit 21) (.readLocal 28 (.lit 0)),
        readSlotPtToLocalStmt d n 0,
        .writeWordLocal 29 (.lit 2) (.lit 0),
        storeLocalCoordsToHeapStmt d M_box 27 2 0,
        boxWriteR M_box 27 (.lit (d : ℤ)) (.ofInt (.lit 0))
      ])
  ])

theorem boxSafe_provisionalFromHPJStmt {T_max M_box : ℕ} (hT : 28 ≤ T_max) (d n K : ℕ) :
    BoxSafeOuter T_max M_box (provisionalFromHPJStmt d n K M_box) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact boxSafe_loadHeapCoordsToLocalStmt _ _ _ _
  · exact boxSafe_distSqLocalStmt _
  · exact .writeRealLocal _ _ _
  · refine .ite _ (.boxR (by omega) _ _) (boxSafeInner_seqList ?_)
    intro s' hs'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_selectByRankSegStmt _
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_readSlotPtToLocalStmt _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_storeLocalCoordsToHeapStmt _ _ (by omega) _ _
    · exact .boxR (by omega) _ _

theorem exec_provisionalFromHPJStmt {d n K M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    {activeH : Finset ℕ} {livePts snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    (hs_reg : wRead mem 26 1 = (s : ℤ))
    (hS_pos : 0 < S.card)
    (hBox_d : d + 1 ≤ M_box)
    (hSeg : EncSegSlot K mem s S fSq)
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hSlot : EncSlotCoords d n mem activeH livePts s S snapPts) :
    let o_cand : EuclideanSpace ℝ (Fin d) :=
      WithLp.toLp 2 (fun c : Fin d => rRead mem 27 (c.val : ℤ))
    let s_cand : ℝ := rRead mem 27 (d : ℤ)
    let bId : ℕ := S.orderEmbOfFin rfl ⟨0, hS_pos⟩
    let prov : ChainNode d := provisionalCenter snapPts bId (.candidate o_cand (liftVariance o_cand s_cand))
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (provisionalFromHPJStmt d n K M_box) mem m'
        (100 * (K + 1) + 180 * (d + 1) + 150) ∧
      m'.popDepth 0 = m' ∧
      (∀ t idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ t, t ≠ 27 → ∀ idx, rRead m' t idx = rRead mem t idx) ∧
      (∀ c : Fin d, rRead m' 27 (c.val : ℤ) = euclideanCoord prov.o c) ∧
      rRead m' 27 (d : ℤ) = prov.V := by
  intro o_cand s_cand bId prov
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 29 2 0
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) (.lit 0)) m0 m1 4 :=
    DetExecAt.writeWordLocal 1 inp m0 29 _ _ rfl rfl (by simp [intExprOps])
  rcases exec_loadHeapCoordsToLocalStmt inp m1 (rTag := 27) (idxBase := 2) (destOff := 0)
      (base := 0) (pt := o_cand) (by decide) (by simp [m1])
      (fun c => by simp [m1, m0, o_cand, euclideanCoord])
    with ⟨m2, hs2, hlo_m2, hw_m2, hr_m2, _, hhi_m2, _, _⟩
  have hzero_m2 : ∀ c : Fin d, rReadL 1 m2 29 (((d + c.val : ℕ) : ℤ)) =
      euclideanCoord (0 : EuclideanSpace ℝ (Fin d)) c := by
    intro c
    rw [hhi_m2 _ (Or.inr (by omega))]
    simp [m1, m0, euclideanCoord]
  rcases exec_distSqLocalStmt inp m2 (fun c => by simpa using hlo_m2 c) hzero_m2
    with ⟨m3, hs3, hdsq_m3, hw_m3, hr_m3, _, _, _, _⟩
  have hdsq_norm : euclideanDistSq o_cand 0 = ‖o_cand‖ ^ 2 := by
    simp [euclideanDistSq]
  let V_cand := liftVariance o_cand s_cand
  let vIdx : ℤ := (((2 * d + 2 : ℕ) : ℤ))
  let m4 := rWriteL 1 m3 29 vIdx V_cand
  have hs4 : DetExecAt 1 inp
      (.writeRealLocal 29 (.lit vIdx)
        (.sub (.readRealHeap 27 (.lit (d : ℤ))) (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))))
      m3 m4 12 := by
    refine DetExecAt.writeRealLocal 1 inp m3 29 _ _ rfl ?_ (by simp [intExprOps, realExprOps])
    simp only [rValAt_sub, rValAt_readRealHeap, rValAt_readRealLocal, iValAt_lit,
      hr_m3, hr_m2, m1, m0, rRead_wWriteL, rRead_popDepth]
    rw [hdsq_m3, hdsq_norm]
    rfl
  by_cases hV : 0 ≤ V_cand
  · have hcond : cValAt 1 inp m4 (.realLe (.ofInt (.lit 0)) (.readRealLocal 29 (.lit vIdx))) = true := by
      simp [m4, hV]
    let m5 := rWrite m4 27 (d : ℤ) V_cand
    have hs5 : DetExecAt 1 inp (boxWriteR M_box 27 (.lit (d : ℤ)) (.readRealLocal 29 (.lit vIdx)))
        m4 m5 20 :=
      exec_boxWriteR inp m4 _ _ rfl (by omega) (by omega) (by simp [m4]) (by simp [intExprOps, realExprOps])
    have hprov_eq : prov = { o := o_cand, V := V_cand, V_nonneg := hV } := by
      dsimp [prov, provisionalCenter]
      exact dif_pos hV
    refine ⟨m5.popDepth 0,
      DetExecAt.localScope ((hs1.seq (hs2.seq (hs3.seq (hs4.seq
        (DetExecAt.ite_true hcond (C_c := 10) (by simp [condExprOps, realExprOps, intExprOps]) hs5))))).mono_cost
        (by omega)),
      popDepth_zero_idem m5,
      fun t idx => by simp [m5, m4, hw_m3, hw_m2, m1, m0],
      fun t ht idx => by simp [m5, ht, m4, hr_m3, hr_m2, m1, m0],
      fun c => ?_,
      by simp [m5, hprov_eq]⟩
    have hne : (c.val : ℤ) ≠ (d : ℤ) := by have := c.isLt; omega
    simp [m5, hne, m4, hr_m3, hr_m2, m1, m0, hprov_eq, o_cand, euclideanCoord]
  · have hcond : cValAt 1 inp m4 (.realLe (.ofInt (.lit 0)) (.readRealLocal 29 (.lit vIdx))) = false := by
      simp [m4, hV]
    have hprov_eq : prov = { o := snapPts bId, V := 0, V_nonneg := le_rfl } := by
      dsimp [prov, provisionalCenter]
      exact dif_neg hV
    let mf1 := wWriteL 1 m4 28 20 (s : ℤ)
    let mf2 := wWriteL 1 mf1 28 21 0
    have hf1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 1))) m4 mf1 6 :=
      DetExecAt.writeWordLocal 1 inp m4 28 _ _ rfl
        (by simp [m4, hw_m3, hw_m2, m1, m0, hs_reg]) (by simp [intExprOps])
    have hf2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.lit 0)) mf1 mf2 4 :=
      DetExecAt.writeWordLocal 1 inp mf1 28 _ _ rfl rfl (by simp [intExprOps])
    have hSeg_mf2 : EncSegSlot K mf2 s S fSq :=
      hSeg.congr_mem_fSq
        (by simp [mf2, mf1, m4, hw_m3, hw_m2, m1, m0])
        (fun _ _ => by simp [mf2, mf1, m4, hw_m3, hw_m2, m1, m0])
        (fun _ _ => by simp [mf2, mf1, m4, hw_m3, hw_m2, m1, m0])
        (fun _ _ => by simp [mf2, mf1, m4, hw_m3, hw_m2, m1, m0])
        (fun _ _ => by simp [mf2, mf1, m4, hr_m3, hr_m2, m1, m0])
        (fun _ _ => rfl)
    rcases exec_selectByRankSegStmt inp mf2 hS_pos (by simp [mf2, mf1]) (by simp [mf2]) hSeg_mf2
      with ⟨mf3, hf3, hsel_mf3, hw_mf3, hr_mf3, _, _⟩
    let mf4 := wWriteL 1 mf3 29 20 (s : ℤ)
    let mf5 := wWriteL 1 mf4 29 21 (bId : ℤ)
    have hf4 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 20) (.readHeap 26 (.lit 1))) mf3 mf4 6 :=
      DetExecAt.writeWordLocal 1 inp mf3 29 _ _ rfl
        (by simp [hw_mf3, mf2, mf1, m4, hw_m3, hw_m2, m1, m0, hs_reg]) (by simp [intExprOps])
    have hf5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 21) (.readLocal 28 (.lit 0))) mf4 mf5 6 :=
      DetExecAt.writeWordLocal 1 inp mf4 29 _ _ rfl (by simp [mf4, hsel_mf3, bId]) (by simp [intExprOps])
    have hbId_in : bId ∈ S := S.orderEmbOfFin_mem rfl ⟨0, hS_pos⟩
    have hLive_mf5 : EncLiveCoords d n mf5 activeH livePts :=
      ⟨hLive.1, fun h hh c => by
        simp only [mf5, mf4, rRead_wWriteL, hr_mf3, mf2, mf1, m4, rRead_rWriteL,
          hr_m3, hr_m2, m1, m0, rRead_popDepth]
        exact hLive.2 h hh c⟩
    have hSlot_mf5 : EncSlotCoords d n mf5 activeH livePts s S snapPts := by
      refine ⟨hSlot.1, ?_⟩
      rcases hSlot.2 with ⟨hg0, hsub, heq⟩ | ⟨hg1, hmap⟩
      · left; exact ⟨by simp [mf5, mf4, hw_mf3, mf2, mf1, m4, hw_m3, hw_m2, m1, m0, hg0], hsub, heq⟩
      · right
        refine ⟨by simp [mf5, mf4, hw_mf3, mf2, mf1, m4, hw_m3, hw_m2, m1, m0]; exact hg1, fun h hh => ?_⟩
        rcases hmap h hh with ⟨h1, h2⟩
        refine ⟨fun heq => fun c => ?_, fun hne => h2 ?_⟩
        · simp only [mf5, mf4, rRead_wWriteL, hr_mf3, mf2, mf1, m4, rRead_rWriteL,
            hr_m3, hr_m2, m1, m0, rRead_popDepth]
          exact h1 (by simpa [mf5, mf4, hw_mf3, mf2, mf1, m4, hw_m3, hw_m2, m1, m0] using heq) c
        · simpa [mf5, mf4, hw_mf3, mf2, mf1, m4, hw_m3, hw_m2, m1, m0] using hne
    rcases exec_readSlotPtToLocalStmt inp mf5 (destOff := 0) (s := s) (h := bId)
        (by simp [mf5, mf4]) (by simp [mf5]) hbId_in hLive_mf5 hSlot_mf5
      with ⟨mf6, hf6, hpt_mf6, hw_mf6, hr_mf6, _, _, _, _⟩
    let mf7 := wWriteL 1 mf6 29 2 0
    have hf7 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) (.lit 0)) mf6 mf7 4 :=
      DetExecAt.writeWordLocal 1 inp mf6 29 _ _ rfl rfl (by simp [intExprOps])
    rcases exec_storeLocalCoordsToHeapStmt inp mf7 (M_box := M_box) (rTag := 27)
        (idxBase := 2) (srcOff := 0) (base := 0) (pt := snapPts bId)
        (by decide) (by simp [mf7]) (by omega)
        (fun c => by simpa [mf7] using hpt_mf6 c)
      with ⟨mf8, hf8, hst_c, _, hst_rt, hst_w, _, _, _, _⟩
    let mf9 := rWrite mf8 27 (d : ℤ) 0
    have hf9 : DetExecAt 1 inp (boxWriteR M_box 27 (.lit (d : ℤ)) (.ofInt (.lit 0))) mf8 mf9 20 :=
      exec_boxWriteR inp mf8 _ _ rfl (by omega) (by omega) (by simp) (by simp [intExprOps, realExprOps])
    refine ⟨mf9.popDepth 0,
      DetExecAt.localScope ((hs1.seq (hs2.seq (hs3.seq (hs4.seq
        (DetExecAt.ite_false hcond (C_c := 10) (by simp [condExprOps, realExprOps, intExprOps])
          (hf1.seq (hf2.seq (hf3.seq (hf4.seq (hf5.seq (hf6.seq (hf7.seq (hf8.seq hf9))))))))))))).mono_cost
        (by omega)),
      popDepth_zero_idem mf9,
      fun t idx => by simp [mf9, hst_w, mf7, hw_mf6, mf5, mf4, hw_mf3, mf2, mf1, m4, hw_m3, hw_m2, m1, m0],
      fun t ht idx => by simp [mf9, ht, hst_rt t ht, mf7, hr_mf6, mf5, mf4, hr_mf3, mf2, mf1, m4, hr_m3, hr_m2, m1, m0],
      fun c => ?_,
      by simp [mf9, hprov_eq]⟩
    have hne : (c.val : ℤ) ≠ (d : ℤ) := by have := c.isLt; omega
    simpa [mf9, hne, hprov_eq] using hst_c c

end UL.Proof_lem_7_2_RacerP46
