import Mathlib
import UL.Stmt.lem_7_2
import UL.Stmt.clm_7_3_failure_budget
import UL.Proof.lem_7_2.CG02_LiveRouteA
import UL.Proof.lem_7_2.CG04_Bridge
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. General Handle-Return & `d = 0` / Pairwise-Scan Diameter Helpers -/

lemma readStepRetH_congr {d : ℕ} (op : DynamicUpdate d) {m₁ m₂ : ArithRAMMemory}
    (h : wRead m₁ 0 0 = wRead m₂ 0 0) :
    readStepRetH op m₁ = readStepRetH op m₂ := by
  cases op with
  | insert _ _ _ =>
      change ArithRAMDynamicProgram.readReturnedHandle m₁ =
        ArithRAMDynamicProgram.readReturnedHandle m₂
      unfold ArithRAMDynamicProgram.readReturnedHandle
      have hw : m₁.words.read (.heap 0 0) = m₂.words.read (.heap 0 0) := h
      rw [hw]
  | delete _ => rfl

lemma indexedEuclideanDiam_zero_dim {ι : Type} (I : Finset ι)
    (pts : ι → EuclideanSpace ℝ (Fin 0)) :
    indexedEuclideanDiam I pts = 0 := by
  unfold indexedEuclideanDiam
  split_ifs with hNE
  · apply le_antisymm
    · rw [Finset.sup'_le_iff]
      intro ab _
      have hsub : pts ab.1 = pts ab.2 := Subsingleton.elim _ _
      simp [hsub]
    · rcases hNE with ⟨x, hx⟩
      have hmem : (x, x) ∈ I ×ˢ I := Finset.mem_product.mpr ⟨hx, hx⟩
      have hle := Finset.le_sup' (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) hmem
      simpa using hle
  · rfl

lemma valid_answer_of_zero_dim {n : ℕ} {P : DynamicPointSet 0}
    (hP : P.WellFormed n) (hcard2 : 2 ≤ P.activeIds.card)
    {bestH1 bestH2 : ℕ}
    (hb1 : bestH1 ∈ P.activeHandles) (hb2 : bestH2 ∈ P.activeHandles) (hb_ne : bestH1 ≠ bestH2) :
    IsValidFactorCAnswer (Real.sqrt 2) P
      { diameterHandles := some (bestH1, bestH2)
        cachedDistSq := euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2) } := by
  unfold IsValidFactorCAnswer
  have hnot1 : ¬ P.activeIds.card ≤ 1 := by omega
  simp only [hnot1, ↓reduceIte]
  refine ⟨bestH1, bestH2, rfl, hb1, hb2, hb_ne, ?_, ?_⟩
  · simp only [DynamicPointSet.handleCoords, if_pos hb1, if_pos hb2]
  · let id₁ := P.idOfHandle bestH1
    let id₂ := P.idOfHandle bestH2
    have hid1 : id₁ ∈ P.activeIds := (hP.2.2.1 bestH1 hb1).1
    have hid2 : id₂ ∈ P.activeIds := (hP.2.2.1 bestH2 hb2).1
    have hid_ne : id₁ ≠ id₂ := by
      intro heq; apply hb_ne
      have e1 := (hP.2.2.1 bestH1 hb1).2
      have e2 := (hP.2.2.1 bestH2 hb2).2
      dsimp only [id₁, id₂] at heq
      rw [← e1, ← e2, heq]
    have hdiam0 : indexedEuclideanDiam P.activeIds P.coords = 0 :=
      indexedEuclideanDiam_zero_dim P.activeIds P.coords
    have hvec0 : ‖P.coords (P.idOfHandle bestH1) - P.coords (P.idOfHandle bestH2)‖ = 0 := by
      have hsub : P.coords (P.idOfHandle bestH1) = P.coords (P.idOfHandle bestH2) := Subsingleton.elim _ _
      simp [hsub]
    refine ⟨hid1, hid2, hid_ne, ?_, ?_⟩
    · rw [hdiam0, hvec0]; norm_num
    · rw [hdiam0, hvec0]

lemma valid_answer_of_all_active_pairs_scanned {d n : ℕ} {P : DynamicPointSet d}
    (hP : P.WellFormed n) (hcard2 : 2 ≤ P.activeIds.card)
    {bestH1 bestH2 : ℕ}
    (hb1 : bestH1 ∈ P.activeHandles) (hb2 : bestH2 ∈ P.activeHandles) (hb_ne : bestH1 ≠ bestH2)
    (hall : ∀ a (ha : a < P.activeHandles.card) b (hb : b < P.activeHandles.card), a ≠ b →
      euclideanDistSq (P.handleCoords (P.activeHandles.orderEmbOfFin rfl ⟨a, ha⟩))
                      (P.handleCoords (P.activeHandles.orderEmbOfFin rfl ⟨b, hb⟩)) ≤
        euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2)) :
    IsValidFactorCAnswer (Real.sqrt 2) P
      { diameterHandles := some (bestH1, bestH2)
        cachedDistSq := euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2) } := by
  unfold IsValidFactorCAnswer
  have hnot1 : ¬ P.activeIds.card ≤ 1 := by omega
  simp only [hnot1, ↓reduceIte]
  refine ⟨bestH1, bestH2, rfl, hb1, hb2, hb_ne, ?_, ?_⟩
  · simp only [DynamicPointSet.handleCoords, if_pos hb1, if_pos hb2]
  · let id₁ := P.idOfHandle bestH1
    let id₂ := P.idOfHandle bestH2
    have hid1 : id₁ ∈ P.activeIds := (hP.2.2.1 bestH1 hb1).1
    have hid2 : id₂ ∈ P.activeIds := (hP.2.2.1 bestH2 hb2).1
    have hid_ne : id₁ ≠ id₂ := by
      intro heq; apply hb_ne
      have e1 := (hP.2.2.1 bestH1 hb1).2
      have e2 := (hP.2.2.1 bestH2 hb2).2
      dsimp only [id₁, id₂] at heq
      rw [← e1, ← e2, heq]
    have hpt1 : P.coords id₁ = P.handleCoords bestH1 := by
      simp only [DynamicPointSet.handleCoords, if_pos hb1]; rfl
    have hpt2 : P.coords id₂ = P.handleCoords bestH2 := by
      simp only [DynamicPointSet.handleCoords, if_pos hb2]; rfl
    have hub : ‖P.coords id₁ - P.coords id₂‖ ≤ indexedEuclideanDiam P.activeIds P.coords := by
      unfold indexedEuclideanDiam
      have hNE : P.activeIds.Nonempty := ⟨id₁, hid1⟩
      rw [dif_pos hNE]
      exact Finset.le_sup' (s := P.activeIds ×ˢ P.activeIds)
        (f := fun xy : ℕ × ℕ => ‖P.coords xy.1 - P.coords xy.2‖) (b := (id₁, id₂))
        (Finset.mem_product.mpr ⟨hid1, hid2⟩)
    have hdiam_le : indexedEuclideanDiam P.activeHandles P.handleCoords ≤
        ‖P.handleCoords bestH1 - P.handleCoords bestH2‖ := by
      unfold indexedEuclideanDiam
      split_ifs with hNE
      · rw [Finset.sup'_le_iff]
        intro uv huv
        rcases Finset.mem_product.mp huv with ⟨hu, hv⟩
        by_cases huv_eq : uv.1 = uv.2
        · rw [huv_eq, sub_self, norm_zero]
          exact norm_nonneg _
        · let iso := P.activeHandles.orderIsoOfFin rfl
          let fa : Fin P.activeHandles.card := iso.symm ⟨uv.1, hu⟩
          let fb : Fin P.activeHandles.card := iso.symm ⟨uv.2, hv⟩
          have hfa_eq : P.activeHandles.orderEmbOfFin rfl fa = uv.1 := by
            change (iso fa).1 = uv.1
            simp [fa]
          have hfb_eq : P.activeHandles.orderEmbOfFin rfl fb = uv.2 := by
            change (iso fb).1 = uv.2
            simp [fb]
          have hfab_ne : fa.val ≠ fb.val := by
            intro hval
            have hfin : fa = fb := Fin.ext hval
            apply huv_eq
            rw [← hfa_eq, ← hfb_eq, hfin]
          have hsq := hall fa.val fa.isLt fb.val fb.isLt hfab_ne
          rw [hfa_eq, hfb_eq] at hsq
          unfold euclideanDistSq at hsq
          exact (sq_le_sq₀ (norm_nonneg _) (norm_nonneg _)).mp hsq
      · exact norm_nonneg _
    have hdiam_ids : indexedEuclideanDiam P.activeIds P.coords ≤
        ‖P.coords id₁ - P.coords id₂‖ := by
      rw [← handleDiam_eq_pointSet_diam hP, hpt1, hpt2]
      exact hdiam_le
    have hdiv_le : indexedEuclideanDiam P.activeIds P.coords / Real.sqrt 2 ≤
        indexedEuclideanDiam P.activeIds P.coords := by
      have hdn : 0 ≤ indexedEuclideanDiam P.activeIds P.coords :=
        le_trans (norm_nonneg _) hub
      have hsqrt1 : (1 : ℝ) ≤ Real.sqrt 2 := by
        rw [← Real.sqrt_one]
        exact Real.sqrt_le_sqrt (by norm_num)
      exact div_le_self hdn hsqrt1
    exact ⟨hid1, hid2, hid_ne, hdiv_le.trans hdiam_ids, hub⟩

/-! ### 2. Deterministic Small-Capacity / `d = 0` RAM Simulation (`CG04_SmallCap`) -/

def smallCapK (n : ℕ) : ℕ := Nat.log 2 n + 1

def smallCapBox (d n : ℕ) : ℕ :=
  32 + 3 * n * (d + 1) + 2 * 2 ^ (smallCapK n + 1)

def smallCapUBound (d K cap : ℕ) : ℕ :=
  600 * (d + 1) + 220 * (K + 1) +
    350 * (cap + 1) * (cap + 1) * (K + d + 5) +
    250 * (K + d + 5) + 1600

def SmallCapReady (d n K : ℕ) (P : DynamicPointSet d) (mem : ArithRAMMemory) : Prop :=
  EncHandlePool d n mem P ∧
  SegGenBound K 2 mem ∧
  SaveGenBound n 2 mem ∧
  EncSegSlot K mem 0 P.activeHandles (fun _ => 0)

lemma SmallCapReady.congr_mem {d n K : ℕ} {P : DynamicPointSet d} {m₁ m₂ : ArithRAMMemory}
    (h : SmallCapReady d n K P m₁)
    (hw1_0 : wRead m₂ 1 0 = wRead m₁ 1 0)
    (hw1_1 : wRead m₂ 1 1 = wRead m₁ 1 1)
    (hw1_2 : wRead m₂ 1 2 = wRead m₁ 1 2)
    (hw1_3 : wRead m₂ 1 3 = wRead m₁ 1 3)
    (hw2 : ∀ idx, wRead m₂ 2 idx = wRead m₁ 2 idx)
    (hw3 : ∀ idx, wRead m₂ 3 idx = wRead m₁ 3 idx)
    (hw5 : ∀ idx, wRead m₂ 5 idx = wRead m₁ 5 idx)
    (hw6 : ∀ idx, wRead m₂ 6 idx = wRead m₁ 6 idx)
    (hw8 : ∀ idx, wRead m₂ 8 idx = wRead m₁ 8 idx)
    (hw9 : ∀ idx, wRead m₂ 9 idx = wRead m₁ 9 idx)
    (hw10 : ∀ idx, wRead m₂ 10 idx = wRead m₁ 10 idx)
    (hw11 : ∀ idx, wRead m₂ 11 idx = wRead m₁ 11 idx)
    (hr4 : ∀ idx, rRead m₂ 4 idx = rRead m₁ 4 idx)
    (hr8 : ∀ idx, rRead m₂ 8 idx = rRead m₁ 8 idx) :
    SmallCapReady d n K P m₂ := by
  rcases h with ⟨⟨⟨hLive_lt, hLive_c⟩, hwm, freeSet, hhwm, hp10, hp11, hp12, hdisj, hunion, hfree1, hfree2, hmap⟩,
    ⟨hseg1, hseg5, hseg8⟩, ⟨hsave1, hsave6, hsave11⟩, hSeg0⟩
  refine ⟨⟨⟨hLive_lt, fun x hx c => (hr4 _).trans (hLive_c x hx c)⟩,
    hwm, freeSet, hhwm,
    hw1_0.trans hp10, hw1_1.trans hp11, hw1_2.trans hp12, hdisj, hunion,
    fun i hi => by rcases hfree1 i hi with ⟨fh, hfh, hr⟩; exact ⟨fh, hfh, (hw3 _).trans hr⟩,
    fun i hi j hj hij => by rw [hw3, hw3]; exact hfree2 i hi j hj hij,
    fun x hx => (hw2 _).trans (hmap x hx)⟩,
    ⟨hw1_3 ▸ hseg1,
     fun s hs => by rw [hw5, hw1_3]; exact hseg5 s hs,
     fun s hs u hu => by rw [hw8, hw1_3]; exact hseg8 s hs u hu⟩,
    ⟨hw1_3 ▸ hsave1,
     fun s hs => by rw [hw6, hw1_3]; exact hsave6 s hs,
     fun s hs x hx => by rw [hw11, hw1_3]; exact hsave11 s hs x hx⟩,
    hSeg0.congr_mem_fSq (hw5 _) (fun _ _ => hw8 _) (fun _ _ => hw9 _)
      (fun _ _ => hw10 _) (fun _ _ => hr8 _) (fun _ _ => rfl)⟩

def smallCapUpdateStmt (d n K cap M_box : ℕ) : ArithRAMStmt :=
  seqList [
    ensureServingChainInitStmt M_box,
    routePoolAndSlot0Stmt d n K 2 M_box,
    boxWriteW M_box 1 (.lit 6) (.lit 0),
    boxWriteW M_box 26 (.lit 10) (.lit 0),
    .ite (.intEq (.lit (d : ℤ)) (.lit 0)) .skip (scanLeafPairsStmt d K cap M_box),
    finalizeStepAnswerStmt d K M_box
  ]

theorem boxSafe_smallCapUpdateStmt {T_max M_box : ℕ} (hT : 28 ≤ T_max) (d n K cap : ℕ) :
    BoxSafeOuter T_max M_box (smallCapUpdateStmt d n K cap M_box) := by
  unfold smallCapUpdateStmt
  apply boxSafeOuter_seqList
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl | rfl
  · exact boxSafe_ensureServingChainInitStmt (by omega)
  · exact boxSafe_routePoolAndSlot0Stmt (by omega) d n K 2
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .ite _ .skip (boxSafe_scanLeafPairsStmt (by omega) d K cap)
  · exact boxSafe_finalizeStepAnswerStmt (by omega) d K

/-- Deterministic (`B_step = 0, φ_step = 0`) `StepSimSpec` valid whenever `d = 0 ∨ n ≤ cap`. -/
noncomputable def buildSmallCapStepSimSpec
    (d n t cap : ℕ) (δ : ℝ)
    (hn : 2 ≤ n) (hδ0 : 0 < δ)
    (hsmall : d = 0 ∨ n ≤ cap) :
    StepSimSpec d n t δ := by
  let K := smallCapK n
  let M_box := smallCapBox d n
  have hn_lt_2K : n < 2 ^ K := Nat.lt_pow_succ_log_self (by decide : 1 < 2) n
  have hnK : n ≤ 2 ^ K := le_of_lt hn_lt_2K
  have hBox30 : 30 ≤ M_box := by unfold M_box smallCapBox; omega
  have hBox_n : n ≤ M_box := by
    have : n ≤ 3 * n * (d + 1) := by
      calc n = 1 * n * 1 := by omega
        _ ≤ 3 * n * (d + 1) := Nat.mul_le_mul (Nat.mul_le_mul_right n (by decide)) (by omega)
    unfold M_box smallCapBox; omega
  have hBox_nd : n * d ≤ M_box := by
    have : n * d ≤ 3 * n * (d + 1) := by
      calc n * d ≤ 3 * n * d := Nat.mul_le_mul_right d (Nat.le_mul_of_pos_left n (by decide))
        _ ≤ 3 * n * (d + 1) := Nat.mul_le_mul_left _ (by omega)
    unfold M_box smallCapBox; omega
  have hBox_sn : 2 * n ≤ M_box := by
    have : 2 * n ≤ 3 * n * (d + 1) := by
      calc 2 * n = 2 * n * 1 := by omega
        _ ≤ 3 * n * (d + 1) := Nat.mul_le_mul (Nat.mul_le_mul_right n (by decide)) (by omega)
    unfold M_box smallCapBox; omega
  have hBox_snd : 2 * n * d ≤ M_box := by
    have : 2 * n * d ≤ 3 * n * (d + 1) :=
      Nat.mul_le_mul (Nat.mul_le_mul_right n (by decide)) (by omega)
    unfold M_box smallCapBox; omega
  have hBox_seg : 2 * 2 ^ (K + 1) ≤ M_box := by dsimp only [M_box, K, smallCapBox]; omega
  let SafeInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop := fun k P mem =>
    (k = 0 ∧ P = DynamicPointSet.empty d ∧ mem = ArithRAMMemory.empty) ∨
      SmallCapReady d n K P mem
  refine
    { updateStmt0 := smallCapUpdateStmt d n K cap M_box
      B_step := 0
      uBound := smallCapUBound d K cap
      T_max := 28
      M_box := M_box
      φ_step := 0
      SafeInv := SafeInv
      GoodInv := fun _ _ _ => True
      hBoxSafe := boxSafe_smallCapUpdateStmt le_rfl d n K cap
      hφ_le := by
        unfold perEventFailureBudget
        positivity
      hSafe₀ := Or.inl ⟨rfl, rfl, rfl⟩
      hGood₀ := trivial
      hStep := ?_ }
  intro k P mem₀ op _ hP _ _ hSafe hleg
  let inp := mkStepInput n P op
  -- Step 1: bootstrap or skip `ensureServingChainInitStmt`
  have hStep1 : ∃ m1 : ArithRAMMemory,
      DetExecAt 0 inp (ensureServingChainInitStmt M_box) mem₀ m1 250 ∧
      SmallCapReady d n K P m1 := by
    rcases hSafe with ⟨_, rfl, rfl⟩ | hRdy
    · rcases exec_ensureServingChainInitStmt_empty (K := K) (D₀ := 0) (NumSlots := 2) (M_box := M_box) inp
          hnK (by decide) (by omega) (by omega)
        with ⟨m1, hex1, _, hChain1, _, _⟩
      rcases hChain1 with ⟨_, _, _, hPool1, hseg1, hsave1, _, _, hSeg0_1, _⟩
      exact ⟨m1, hex1, hPool1, hseg1, hsave1, hSeg0_1⟩
    · have h13_pos : 1 ≤ wRead mem₀ 1 3 := hRdy.2.1.1
      have hcond : cValAt 0 inp mem₀ (.intEq (.readHeap 1 (.lit 3)) (.lit 0)) = false := by
        simp only [cValAt_intEq, iValAt_readHeap, iValAt_lit, decide_eq_false_iff_not]
        omega
      exact ⟨mem₀,
        (DetExecAt.ite_false hcond (C_c := 15) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp mem₀)).mono_cost (by omega),
        hRdy⟩
  rcases hStep1 with ⟨m1, hex1, hPool1, hseg1, hsave1, hSeg0_1⟩
  -- Step 2: `routePoolAndSlot0Stmt`
  rcases exec_routePoolAndSlot0Stmt P op m1 hP hleg hnK (by decide : 1 ≤ 2)
      hBox30 hBox_n hBox_nd hBox_sn hBox_snd hBox_seg hPool1 hseg1 hsave1 hSeg0_1
    with ⟨m2, P', opH, hex2, _, happ2, hWF2, hPool2, hseg2, hsave2, hSeg0_2,
          _, _, _, _, _, _, _, _, _, _, _, _⟩
  have hRdy2 : SmallCapReady d n K P' m2 := ⟨hPool2, hseg2, hsave2, hSeg0_2⟩
  -- Step 3 & 4: `1[6] := 0` and `26[10] := 0`
  let m3 := wWrite m2 1 6 0
  let m4 := wWrite m3 26 10 0
  have hex3 : DetExecAt 0 inp (boxWriteW M_box 1 (.lit 6) (.lit 0)) m2 m3 20 :=
    exec_boxWriteW inp m2 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hex4 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 10) (.lit 0)) m3 m4 20 :=
    exec_boxWriteW inp m3 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hRdy4 : SmallCapReady d n K P' m4 :=
    hRdy2.congr_mem
      (by simp [m4, m3]) (by simp [m4, m3]) (by simp [m4, m3]) (by simp [m4, m3])
      (fun _ => by simp [m4, m3]) (fun _ => by simp [m4, m3]) (fun _ => by simp [m4, m3])
      (fun _ => by simp [m4, m3]) (fun _ => by simp [m4, m3]) (fun _ => by simp [m4, m3])
      (fun _ => by simp [m4, m3]) (fun _ => by simp [m4, m3])
      (fun _ => by simp [m4, m3]) (fun _ => by simp [m4, m3])
  have hw4_16 : wRead m4 1 6 = (0 : ℤ) := by simp [m4, m3]
  have hw4_00 : wRead m4 0 0 = wRead m2 0 0 := by simp [m4, m3]
  have hBest4 : BestCandInv P' m4 := Or.inl (by simp [m4])
  -- Step 5: branch on `d == 0`, else `scanLeafPairsStmt d K cap M_box`
  have hStep5 : ∃ m5 : ArithRAMMemory,
      DetExecAt 0 inp (.ite (.intEq (.lit (d : ℤ)) (.lit 0)) .skip (scanLeafPairsStmt d K cap M_box)) m4 m5
        (350 * (cap + 1) * (cap + 1) * (K + d + 5) + 520) ∧
      SmallCapReady d n K P' m5 ∧
      BestCandInv P' m5 ∧
      wRead m5 0 0 = wRead m2 0 0 ∧
      (d ≠ 0 →
        ∀ a (ha : a < P'.activeHandles.card) b (hb : b < P'.activeHandles.card), a ≠ b →
          wRead m5 26 10 = 1 ∧
          euclideanDistSq (P'.handleCoords (P'.activeHandles.orderEmbOfFin rfl ⟨a, ha⟩))
                          (P'.handleCoords (P'.activeHandles.orderEmbOfFin rfl ⟨b, hb⟩)) ≤
            rRead m5 26 10) := by
    by_cases hd0 : d = 0
    · have hcond : cValAt 0 inp m4 (.intEq (.lit (d : ℤ)) (.lit 0)) = true := by simp [hd0]
      exact ⟨m4,
        (DetExecAt.ite_true hcond (C_c := 10) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp m4)).mono_cost (by omega),
        hRdy4, hBest4, hw4_00, fun hne => absurd hd0 hne⟩
    · have hn_le_cap : n ≤ cap := by
        rcases hsmall with hd | hle
        · exact absurd hd hd0
        · exact hle
      have hcard_cap : P'.activeHandles.card ≤ cap := by
        rw [activeHandles_card_eq_activeIds_card hWF2]
        exact hWF2.1.trans hn_le_cap
      have hcond : cValAt 0 inp m4 (.intEq (.lit (d : ℤ)) (.lit 0)) = false := by
        simp only [cValAt_intEq, iValAt_lit, decide_eq_false_iff_not]
        omega
      rcases exec_scanLeafPairsStmt (K := K) (M_leaf := cap) (M_box := M_box) inp m4
          (s := 0) (by simpa using hw4_16) (by omega) hBest4 hRdy4.1.1
          (Finset.Subset.refl _) hcard_cap hRdy4.2.2.2
        with ⟨m5, hex5, _, hBest5, _, hw5_o, _, hr5_o, _, hdom5⟩
      have hRdy5 : SmallCapReady d n K P' m5 :=
        hRdy4.congr_mem
          (hw5_o 1 (by decide) 0) (hw5_o 1 (by decide) 1)
          (hw5_o 1 (by decide) 2) (hw5_o 1 (by decide) 3)
          (hw5_o 2 (by decide)) (hw5_o 3 (by decide)) (hw5_o 5 (by decide))
          (hw5_o 6 (by decide)) (hw5_o 8 (by decide)) (hw5_o 9 (by decide))
          (hw5_o 10 (by decide)) (hw5_o 11 (by decide))
          (hr5_o 4 (by decide)) (hr5_o 8 (by decide))
      exact ⟨m5,
        (DetExecAt.ite_false hcond (C_c := 10) (by simp [condExprOps, intExprOps]) hex5).mono_cost (by omega),
        hRdy5, hBest5, (hw5_o 0 (by decide) 0).trans hw4_00, fun _ => hdom5⟩
  rcases hStep5 with ⟨m5, hex5, hRdy5, hBest5, hw5_00, hdom5⟩
  -- Step 6: `finalizeStepAnswerStmt d K M_box`
  have hw5_card : wRead m5 1 2 = (P'.activeHandles.card : ℤ) := by
    rcases hRdy5.1.2 with ⟨_, _, _, _, _, hp12, _⟩
    exact hp12
  rcases exec_finalizeStepAnswerStmt (K := K) (M_box := M_box) inp m5 hWF2 hw5_card (by omega) hBest5 hRdy5.1.1 hRdy5.2.2.2
    with ⟨m6, hex6, hm6_pop, hw6_00, hw6_o, hr6_o, hans_le1, hans_ge2⟩
  have hRdy6 : SmallCapReady d n K P' m6 :=
    hRdy5.congr_mem
      (hw6_o 1 (by decide) (by decide) 0) (hw6_o 1 (by decide) (by decide) 1)
      (hw6_o 1 (by decide) (by decide) 2) (hw6_o 1 (by decide) (by decide) 3)
      (hw6_o 2 (by decide) (by decide)) (hw6_o 3 (by decide) (by decide))
      (hw6_o 5 (by decide) (by decide)) (hw6_o 6 (by decide) (by decide))
      (hw6_o 8 (by decide) (by decide)) (hw6_o 9 (by decide) (by decide))
      (hw6_o 10 (by decide) (by decide)) (hw6_o 11 (by decide) (by decide))
      (hr6_o 4 (by decide) (by decide)) (hr6_o 8 (by decide) (by decide))
  have hex_tot : DetExecAt 0 inp (smallCapUpdateStmt d n K cap M_box) mem₀ m6 (smallCapUBound d K cap) := by
    unfold smallCapUpdateStmt seqList
    refine (hex1.seq (hex2.seq (hex3.seq (hex4.seq (hex5.seq hex6))))).mono_cost ?_
    unfold smallCapUBound
    omega
  have hans6 : IsValidFactorCAnswer (Real.sqrt 2) P' (readStoredAns m6) := by
    by_cases hle1 : P'.activeIds.card ≤ 1
    · exact hans_le1 hle1
    · have hge2 : 2 ≤ P'.activeIds.card := by omega
      rcases hans_ge2 hge2 with ⟨bestH1, bestH2, hb1, hb2, hb_ne, hans_eq, hmono6⟩
      rw [hans_eq]
      by_cases hd0 : d = 0
      · subst hd0
        exact valid_answer_of_zero_dim hWF2 hge2 hb1 hb2 hb_ne
      · refine valid_answer_of_all_active_pairs_scanned hWF2 hge2 hb1 hb2 hb_ne ?_
        intro a ha b hb hab
        rcases hdom5 hd0 a ha b hb hab with ⟨hw10_1, hle_r5⟩
        exact hle_r5.trans (hmono6 hw10_1)
  refine ⟨fun _ m => m = m6, fun _ => False, inferInstance,
    RandExecAt.of_det hex_tot,
    by simp,
    ?_⟩
  intro _ m₁ hm₁
  subst hm₁
  dsimp only
  rw [hm6_pop]
  refine ⟨P', ?_, Or.inr hRdy6, fun _ _ => ⟨hans6, trivial⟩⟩
  rw [readStepRetH_congr op (hw6_00.trans hw5_00)]
  exact happ2

/-! ### 3. Polynomial Cost/Space Bounds for `buildSmallCapStepSimSpec` & Conditional Endpoint -/

theorem smallCap_poly_bounds
    {d n t cap C_cap : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (hcap : cap ≤ C_cap * ((d + 3) ^ 4 *
      (Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))) ^ 2)) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    smallCapUBound d (smallCapK n) cap ≤ (1050 * (C_cap + 1) ^ 2 + 3400) * (D ^ 19 * H ^ 18) ∧
    28 * smallCapBox d n ≤ 756 * n * (D ^ 19 * H ^ 18) := by
  intro D H
  have hsb := scale_basic_bounds (d := d) hn ht hδ0 hδ1
  obtain ⟨hD3_raw, hH5_raw, _, hn2, _, _, _⟩ := hsb
  have hD3 : 3 ≤ D := hD3_raw
  have hH5 : 5 ≤ H := hH5_raw
  have hD1 : 1 ≤ D := by omega
  have hH1 : 1 ≤ H := by omega
  let P19 : ℕ := D ^ 19 * H ^ 18
  have hKH : smallCapK n ≤ H := by
    unfold smallCapK
    have hlog_lt : Nat.log 2 n < H :=
      (Nat.log_lt_iff_lt_pow (by decide : 1 < 2) (by omega : n ≠ 0)).mpr hn2
    omega
  have h2K_le : 2 ^ smallCapK n ≤ 2 * n := by
    unfold smallCapK
    rw [pow_succ']
    exact Nat.mul_le_mul_left 2 (Nat.pow_log_le_self 2 (by omega : n ≠ 0))
  have h2K1_le : 2 ^ (smallCapK n + 1) ≤ 4 * n := by
    rw [pow_succ']
    omega
  have hu : smallCapUBound d (smallCapK n) cap ≤ (1050 * (C_cap + 1) ^ 2 + 3400) * P19 := by
    unfold smallCapUBound
    have hD4H2_1 : 1 ≤ D ^ 4 * H ^ 2 :=
      Nat.mul_pos (Nat.pow_pos hD1) (Nat.pow_pos hH1)
    have hcap1 : cap + 1 ≤ (C_cap + 1) * (D ^ 4 * H ^ 2) := by
      have hc : cap ≤ C_cap * (D ^ 4 * H ^ 2) := hcap
      calc cap + 1 ≤ C_cap * (D ^ 4 * H ^ 2) + 1 * (D ^ 4 * H ^ 2) := by omega
        _ = (C_cap + 1) * (D ^ 4 * H ^ 2) := by ring
    have hKd5 : smallCapK n + d + 5 ≤ 3 * (D * H) := by
      have hH_DH : H ≤ D * H := by
        calc H = 1 * H := by ring
          _ ≤ D * H := Nat.mul_le_mul_right H hD1
      have hD_DH : D ≤ D * H := by
        calc D = D * 1 := by ring
          _ ≤ D * H := Nat.mul_le_mul_left D hH1
      have h2_DH : 2 ≤ D * H := by nlinarith
      have hd_D : d + 3 = D := rfl
      omega
    have hscan :
        350 * (cap + 1) * (cap + 1) * (smallCapK n + d + 5) ≤
          (1050 * (C_cap + 1) ^ 2) * P19 := by
      calc 350 * (cap + 1) * (cap + 1) * (smallCapK n + d + 5)
          ≤ 350 * ((C_cap + 1) * (D ^ 4 * H ^ 2)) * ((C_cap + 1) * (D ^ 4 * H ^ 2)) * (3 * (D * H)) :=
            Nat.mul_le_mul
              (Nat.mul_le_mul (Nat.mul_le_mul_left 350 hcap1) hcap1) hKd5
        _ = (1050 * (C_cap + 1) ^ 2) * (D ^ 9 * H ^ 5) := by ring
        _ ≤ (1050 * (C_cap + 1) ^ 2) * P19 :=
            Nat.mul_le_mul_left _ (pow_mul_pow_le_target hD1 hH1 (by decide) (by decide))
    have hrest :
        600 * (d + 1) + 220 * (smallCapK n + 1) + 250 * (smallCapK n + d + 5) + 1600 ≤
          3400 * P19 := by
      have hd1_DH : d + 1 ≤ D * H := by
        calc d + 1 ≤ D := by dsimp [D]; omega
          _ = D * 1 := by ring
          _ ≤ D * H := Nat.mul_le_mul_left D hH1
      have hK1_DH : smallCapK n + 1 ≤ 2 * (D * H) := by
        have hH_DH : H ≤ D * H := by
          calc H = 1 * H := by ring
            _ ≤ D * H := Nat.mul_le_mul_right H hD1
        have h1_DH : 1 ≤ D * H := Nat.mul_pos hD1 hH1
        omega
      have h1_DH : 1 ≤ D * H := Nat.mul_pos hD1 hH1
      have hDH_le :
          600 * (d + 1) + 220 * (smallCapK n + 1) + 250 * (smallCapK n + d + 5) + 1600 ≤
            3400 * (D * H) := by omega
      have hDH_P : D * H ≤ P19 := by
        simpa using pow_mul_pow_le_target hD1 hH1 (by decide : 1 ≤ 19) (by decide : 1 ≤ 18)
      exact hDH_le.trans (Nat.mul_le_mul_left 3400 hDH_P)
    calc 600 * (d + 1) + 220 * (smallCapK n + 1) +
          350 * (cap + 1) * (cap + 1) * (smallCapK n + d + 5) +
          250 * (smallCapK n + d + 5) + 1600
        ≤ (1050 * (C_cap + 1) ^ 2) * P19 + 3400 * P19 := by omega
      _ = (1050 * (C_cap + 1) ^ 2 + 3400) * P19 := by ring
  have hbox : 28 * smallCapBox d n ≤ 756 * n * P19 := by
    have hbox_nD : smallCapBox d n ≤ 27 * (n * D) := by
      unfold smallCapBox
      have h32 : 32 ≤ 16 * (n * D) := by
        have : 2 ≤ n * D := by nlinarith
        omega
      have h3nd : 3 * n * (d + 1) ≤ 3 * (n * D) := by
        have hd1 : d + 1 ≤ D := by dsimp [D]; omega
        calc 3 * n * (d + 1) = 3 * (n * (d + 1)) := by ring
          _ ≤ 3 * (n * D) := Nat.mul_le_mul_left 3 (Nat.mul_le_mul_left n hd1)
      have hseg : 2 * 2 ^ (smallCapK n + 1) ≤ 8 * (n * D) := by
        calc 2 * 2 ^ (smallCapK n + 1) ≤ 2 * (4 * n) := Nat.mul_le_mul_left 2 h2K1_le
          _ = 8 * (n * 1) := by ring
          _ ≤ 8 * (n * D) := Nat.mul_le_mul_left 8 (Nat.mul_le_mul_left n hD1)
      omega
    have hD_P : D ≤ P19 := by
      simpa using pow_mul_pow_le_target hD1 hH1 (by decide : 1 ≤ 19) (Nat.zero_le 18)
    calc 28 * smallCapBox d n
        ≤ 28 * (27 * (n * D)) := Nat.mul_le_mul_left 28 hbox_nD
      _ = (756 * n) * D := by ring
      _ ≤ (756 * n) * P19 := Nat.mul_le_mul_left (756 * n) hD_P
  exact ⟨hu, hbox⟩

/-- Conditional reduction of `S_lem_7_2`: handles `d = 0 ∨ n ≤ C_cap * D^4 * H^2` via
`buildSmallCapStepSimSpec` and delegates only `1 ≤ d ∧ C_cap * D^4 * H^2 < n` to `hMain`. -/
theorem prove_S_lem_7_2_of_conditional_stepSimSpec
    (h_fb : S_clm_7_3_failure_budget)
    (C_cap C_u C_box : ℕ)
    (hMain : ∀ (d n t : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        C_cap * (D ^ 4 * H ^ 2) < n →
          ∃ spec : StepSimSpec d n t δ,
            spec.uBound ≤ C_u * (D ^ 19 * H ^ 18) ∧
            spec.T_max * spec.M_box ≤ C_box * n * (D ^ 19 * H ^ 18)) :
    S_lem_7_2 := by
  let Cu_small := 1050 * (C_cap + 1) ^ 2 + 3400
  let Cu_tot := max C_u Cu_small
  let Cbox_tot := max C_box 756
  refine prove_S_lem_7_2_of_all_stepSimSpec h_fb Cu_tot Cbox_tot ?_
  intro d n t hn ht δ hδ0 hδ1
  let D : ℕ := d + 3
  let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
  let cap : ℕ := C_cap * (D ^ 4 * H ^ 2)
  by_cases hcond : 1 ≤ d ∧ cap < n
  · rcases hMain d n t hcond.1 hn ht δ hδ0 hδ1 hcond.2 with ⟨spec, hu, hbox⟩
    refine ⟨spec, ?_, ?_⟩
    · exact hu.trans (Nat.mul_le_mul_right _
        ((le_max_left C_u Cu_small).trans (le_max_right 1 Cu_tot)))
    · exact hbox.trans (Nat.mul_le_mul_right _
        (Nat.mul_le_mul_right n (le_max_left C_box 756)))
  · have hsmall : d = 0 ∨ n ≤ cap := by
      by_cases hd0 : d = 0
      · exact Or.inl hd0
      · right
        have hd1 : 1 ≤ d := by omega
        have hnot : ¬ cap < n := fun hlt => hcond ⟨hd1, hlt⟩
        omega
    let spec := buildSmallCapStepSimSpec d n t cap δ hn hδ0 hsmall
    rcases smallCap_poly_bounds (C_cap := C_cap) hn ht hδ0 hδ1 (le_rfl : cap ≤ cap)
      with ⟨hu_s, hbox_s⟩
    refine ⟨spec, ?_, ?_⟩
    · exact hu_s.trans (Nat.mul_le_mul_right _
        ((le_max_right C_u Cu_small).trans (le_max_right 1 Cu_tot)))
    · exact hbox_s.trans (Nat.mul_le_mul_right _
        (Nat.mul_le_mul_right n (le_max_right C_box 756)))

end UL.Proof_lem_7_2_RacerP46
