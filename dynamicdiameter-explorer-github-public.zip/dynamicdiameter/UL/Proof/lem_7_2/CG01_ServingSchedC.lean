import UL.Proof.lem_7_2.CG01_ServingSchedB

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 5. Synchronous Leaf-Splitting Trajectory, Full Pure Step, & Factor-`√2` Answer Validity -/

/-- One synchronous leaf-splitting round: if `2 * L + 1 < S_leaf.card`, opens one serving node
from HPJ candidate `(o_cand, s_cand)` on `S_leaf`; otherwise leaves `st` unchanged. -/
noncomputable def PureServingState.syncSplitOne {d n H L B_scan : ℕ}
    {P : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (o_cand : EuclideanSpace ℝ (Fin d)) (s_cand : ℝ) :
    PureServingState d n H L B_scan P :=
  let S_leaf_h := chainTerminal P.handleCoords st.nodes P.activeHandles
  if hgt : 2 * L + 1 < S_leaf_h.card then
    let α : ℝ := 1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)
    let bId_h : ℕ := S_leaf_h.orderEmbOfFin rfl ⟨0, by omega⟩
    let B_new : ChainNode d :=
      selectOpenedLevelBall α P.handleCoords S_leaf_h bId_h
        (.candidate o_cand (liftVariance o_cand s_cand))
    let nodes' := appendChainNode st.nodes B_new
    { uMap := st.uMap
      k := st.k + 1
      nodes := nodes'
      birthSnap := fun i =>
        if h : i.val < st.k then st.birthSnap ⟨i.val, h⟩ else st.uMap.mapSet S_leaf_h
      snAge := fun i =>
        if h : i.val < st.k then st.snAge ⟨i.val, h⟩ else 0
      trueAge := fun i =>
        if h : i.val < st.k then st.trueAge ⟨i.val, h⟩ else 0
      ownedJob := fun i =>
        if h : i.val < st.k then
          (st.ownedJob ⟨i.val, h⟩).map (fun g =>
            g.castPool (cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new
              st.uMap.ActiveUids i.val (le_of_lt h)).symm)
        else
          none }
  else
    st

lemma PureServingState.syncSplitOne_spec
    (h_lem_5_1 : S_lem_5_1)
    {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (hL_floor : 68719476736 * (d + 3) ^ 4 ≤ L)
    (hinv : st.NodesInv)
    (o_cand : EuclideanSpace ℝ (Fin d)) (s_cand : ℝ) :
    (st.syncSplitOne o_cand s_cand).uMap = st.uMap ∧
    (st.syncSplitOne o_cand s_cand).NodesInv ∧
    ((chainTerminal P.handleCoords st.nodes P.activeHandles).card ≤ 2 * L + 1 →
      (chainTerminal P.handleCoords (st.syncSplitOne o_cand s_cand).nodes P.activeHandles).card =
        (chainTerminal P.handleCoords st.nodes P.activeHandles).card) ∧
    (2 * L + 1 < (chainTerminal P.handleCoords st.nodes P.activeHandles).card →
      ∃ c : ℕ,
        (chainTerminal P.handleCoords st.nodes P.activeHandles).card ≤ 8 * (d + 3) ^ 2 * c ∧
        (chainTerminal P.handleCoords (st.syncSplitOne o_cand s_cand).nodes P.activeHandles).card + c =
          (chainTerminal P.handleCoords st.nodes P.activeHandles).card) ∧
    (st.AllCentersGood →
      (2 * L + 1 < (chainTerminal P.handleCoords st.nodes P.activeHandles).card →
        IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
          (paraboloidLiftSet (fun x : ↥(chainTerminal P.handleCoords st.nodes P.activeHandles) => P.handleCoords x.1))
          (liftedPoint o_cand s_cand)) →
      (st.syncSplitOne o_cand s_cand).AllCentersGood) := by
  have hD : 3 ≤ d + 3 := by omega
  let α : ℝ := 1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)
  obtain ⟨hα0, hα_half, _, _, _⟩ := alpha_pos_and_lt_half (d + 3) hD
  have hα2 : α ≤ 2 := by linarith
  let S_leaf_h := chainTerminal P.handleCoords st.nodes P.activeHandles
  by_cases hgt : 2 * L + 1 < S_leaf_h.card
  · let bId_h : ℕ := S_leaf_h.orderEmbOfFin rfl ⟨0, by omega⟩
    have hb_in : bId_h ∈ S_leaf_h := S_leaf_h.orderEmbOfFin_mem rfl ⟨0, by omega⟩
    let B_new : ChainNode d :=
      selectOpenedLevelBall α P.handleCoords S_leaf_h bId_h
        (.candidate o_cand (liftVariance o_cand s_cand))
    let st_new : PureServingState d n H L B_scan P :=
      { uMap := st.uMap
        k := st.k + 1
        nodes := appendChainNode st.nodes B_new
        birthSnap := fun i =>
          if h : i.val < st.k then st.birthSnap ⟨i.val, h⟩ else st.uMap.mapSet S_leaf_h
        snAge := fun i =>
          if h : i.val < st.k then st.snAge ⟨i.val, h⟩ else 0
        trueAge := fun i =>
          if h : i.val < st.k then st.trueAge ⟨i.val, h⟩ else 0
        ownedJob := fun i =>
          if h : i.val < st.k then
            (st.ownedJob ⟨i.val, h⟩).map (fun g =>
              g.castPool (cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new
                st.uMap.ActiveUids i.val (le_of_lt h)).symm)
          else
            none }
    have hst_eq : st.syncSplitOne o_cand s_cand = st_new := dif_pos hgt
    rw [hst_eq]
    have hsub_leaf : S_leaf_h ⊆ P.activeHandles :=
      cg01_chainTerminal_subset P.handleCoords st.nodes P.activeHandles
    have hbij_leaf := st.uMap.mapSet_bij hsub_leaf
    have hB_uid_eq : B_new =
        selectOpenedLevelBall α st.uMap.ghostCoords (st.uMap.mapSet S_leaf_h)
          (st.uMap.uidOfH bId_h) (.candidate o_cand (liftVariance o_cand s_cand)) :=
      selectOpenedLevelBall_bij_uid α P.handleCoords st.uMap.ghostCoords
        S_leaf_h (st.uMap.mapSet S_leaf_h) st.uMap.uidOfH st.uMap.hOfUid
        hbij_leaf.2.2.1 hbij_leaf.2.2.2 hb_in o_cand s_cand
    have hpass_h : PassesBirthCoreCheck α P.handleCoords B_new S_leaf_h :=
      passesBirthCoreCheck_selectOpenedLevelBall hα2 P.handleCoords S_leaf_h hb_in _
    have hpass_uid : PassesBirthCoreCheck α st.uMap.ghostCoords B_new (st.uMap.mapSet S_leaf_h) := by
      rw [hB_uid_eq]
      exact passesBirthCoreCheck_selectOpenedLevelBall hα2 st.uMap.ghostCoords
        (st.uMap.mapSet S_leaf_h) (Finset.mem_image_of_mem _ hb_in) _
    have hstart_pos : 0 < jobStartAge α (st.uMap.mapSet S_leaf_h).card := by
      rw [jobStartAge_eq_nat (d + 3) hD, hbij_leaf.1]
      have hD2_le_D4 : (d + 3) ^ 2 ≤ (d + 3) ^ 4 := Nat.pow_le_pow_right (by omega) (by norm_num)
      have h256 : 256 * (d + 3) ^ 2 ≤ S_leaf_h.card := by
        have : 256 * (d + 3) ^ 2 ≤ 68719476736 * (d + 3) ^ 4 :=
          le_trans (Nat.mul_le_mul_right _ (by norm_num : 256 ≤ 68719476736))
            (Nat.mul_le_mul_left _ hD2_le_D4)
        omega
      exact Nat.div_pos h256 (by positivity)
    refine ⟨rfl, ?_, fun hle => by dsimp [S_leaf_h] at hgt; omega, ?_, ?_⟩
    · intro i
      by_cases hlt : i.val < st.k
      · let i_old : Fin st.k := ⟨i.val, hlt⟩
        have hbs : st_new.birthSnap i = st.birthSnap i_old := dif_pos hlt
        have hsn_eq : st_new.snAge i = st.snAge i_old := dif_pos hlt
        have htr_eq : st_new.trueAge i = st.trueAge i_old := dif_pos hlt
        have hnod_eq : st_new.nodes i = st.nodes i_old := appendChainNode_lt st.nodes B_new hlt
        have hoj_eq : st_new.ownedJob i =
            (st.ownedJob i_old).map (fun g =>
              g.castPool (cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new
                st.uMap.ActiveUids i.val (le_of_lt hlt)).symm) := dif_pos hlt
        have hinp_eq : chainInput st.uMap.ghostCoords (appendChainNode st.nodes B_new)
            st.uMap.ActiveUids i.castSucc =
            chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids i_old.castSucc :=
          cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new st.uMap.ActiveUids
            i.val (le_of_lt hlt)
        rcases hinv i_old with ⟨hlarge_i, huid_i, hpass_i, htr_i, hage_i, hjob_i⟩
        dsimp only [PureServingState.NodesInv]
        rw [hbs, hsn_eq, htr_eq, hnod_eq, hoj_eq]
        exact ⟨hlarge_i, huid_i, hpass_i, htr_i, hinp_eq ▸ hage_i,
          (servingOwnedJobInv_castPool _ _ _ _).mpr hjob_i⟩
      · have hi_eq : i.val = st.k := by have := i.isLt; dsimp [st_new] at this; omega
        have hbs : st_new.birthSnap i = st.uMap.mapSet S_leaf_h := dif_neg hlt
        have hsn_eq : st_new.snAge i = 0 := dif_neg hlt
        have htr_eq : st_new.trueAge i = 0 := dif_neg hlt
        have hoj_eq : st_new.ownedJob i = none := dif_neg hlt
        have hnod_last : st_new.nodes i = B_new := by
          change appendChainNode st.nodes B_new i = B_new
          have hfin : i = ⟨st.k, Nat.lt_succ_self st.k⟩ := Fin.ext hi_eq
          rw [hfin]; exact appendChainNode_last st.nodes B_new
        have hinp_last : chainInput st.uMap.ghostCoords st_new.nodes
            st.uMap.ActiveUids i.castSucc = st.uMap.mapSet S_leaf_h := by
          have hcast : i.castSucc = ⟨st.k, Nat.lt_succ_of_lt (Nat.lt_succ_self st.k)⟩ :=
            Fin.ext hi_eq
          rw [hcast, cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new
              st.uMap.ActiveUids st.k le_rfl,
              ← cg01_chainTerminal_eq, ← st.uMap.mapSet_chainTerminal st.nodes]
        dsimp only [PureServingState.NodesInv]
        rw [hbs, hsn_eq, htr_eq, hoj_eq, hnod_last, hinp_last]
        exact ⟨by rw [hbij_leaf.1]; exact hgt,
          hbij_leaf.2.1,
          hpass_uid,
          le_rfl,
          hasNodeAge_zero _,
          hstart_pos⟩
    · intro _
      let c := (B_new.core P.handleCoords S_leaf_h).card
      have hc_ge : S_leaf_h.card ≤ 8 * (d + 3) ^ 2 * c :=
        (passesBirthCoreCheck_iff_nat (d + 3) hD P.handleCoords B_new S_leaf_h).mp hpass_h
      have hterm_next : chainTerminal P.handleCoords st_new.nodes P.activeHandles =
          B_new.residual P.handleCoords S_leaf_h :=
        cg01_chainTerminal_append P.handleCoords st.nodes B_new P.activeHandles
      have hsum : (chainTerminal P.handleCoords st_new.nodes P.activeHandles).card + c = S_leaf_h.card := by
        rw [hterm_next]
        dsimp only [c]
        unfold ChainNode.residual nodeResidual ChainNode.core
        have hsubC : nodeCore P.handleCoords B_new.o B_new.V S_leaf_h ⊆ S_leaf_h := by
          intro x hx; unfold nodeCore at hx; exact (@Finset.mem_filter _ _ (Classical.decPred _) S_leaf_h x).mp hx |>.1
        exact @Finset.card_sdiff_add_card_eq_card _ (Classical.typeDecidableEq _) _ _ hsubC
      exact ⟨c, hc_ge, hsum⟩
    · intro hgood hcp_h
      have hcp_uid : IsCenterpoint α
          (paraboloidLiftSet (fun u : ↥(st.uMap.mapSet S_leaf_h) => st.uMap.ghostCoords u.1))
          (liftedPoint o_cand s_cand) :=
        centerpoint_paraboloid_bij_uid P.handleCoords st.uMap.ghostCoords
          S_leaf_h (st.uMap.mapSet S_leaf_h) st.uMap.uidOfH st.uMap.hOfUid
          hbij_leaf.2.2.1 hbij_leaf.2.2.2 _ (hcp_h hgt)
      have hB_good : IsCenterpoint α
          (paraboloidLiftSet (fun u : ↥(st.uMap.mapSet S_leaf_h) => st.uMap.ghostCoords u.1))
          (liftedPoint B_new.o (B_new.V + ‖B_new.o‖ ^ 2)) := by
        rw [hB_uid_eq]
        exact (selectOpenedLevelBall_centerpoint_of_hpj h_lem_5_1 hα0 st.uMap.ghostCoords
          (by rw [hbij_leaf.1]; omega) (st.uMap.uidOfH bId_h) o_cand s_cand hcp_uid).2.2.2
      refine ⟨fun i => ?_, fun i g hg => ?_⟩
      · by_cases hlt : i.val < st.k
        · have hbs : st_new.birthSnap i = st.birthSnap ⟨i.val, hlt⟩ := dif_pos hlt
          have hnod_eq : st_new.nodes i = st.nodes ⟨i.val, hlt⟩ :=
            appendChainNode_lt st.nodes B_new hlt
          rw [hbs, hnod_eq]
          exact hgood.1 ⟨i.val, hlt⟩
        · have hi_eq : i.val = st.k := by have := i.isLt; dsimp [st_new] at this; omega
          have hbs : st_new.birthSnap i = st.uMap.mapSet S_leaf_h := dif_neg hlt
          have hnod_last : st_new.nodes i = B_new := by
            change appendChainNode st.nodes B_new i = B_new
            have hfin : i = ⟨st.k, Nat.lt_succ_self st.k⟩ := Fin.ext hi_eq
            rw [hfin]; exact appendChainNode_last st.nodes B_new
          rw [hbs, hnod_last]
          exact hB_good
      · by_cases hlt : i.val < st.k
        · have hoj_eq : st_new.ownedJob i =
              (st.ownedJob ⟨i.val, hlt⟩).map (fun g =>
                g.castPool (cg01_chainInput_append_lt st.uMap.ghostCoords st.nodes B_new
                  st.uMap.ActiveUids i.val (le_of_lt hlt)).symm) := dif_pos hlt
          rw [hoj_eq] at hg
          cases hj : st.ownedJob ⟨i.val, hlt⟩ with
          | none => rw [hj] at hg; cases hg
          | some g₀ =>
              rw [hj, Option.map_some, Option.some.injEq] at hg
              subst hg
              exact hgood.2 ⟨i.val, hlt⟩ g₀ hj
        · have hoj_eq : st_new.ownedJob i = none := dif_neg hlt
          rw [hoj_eq] at hg
          cases hg
  · have hst_eq : st.syncSplitOne o_cand s_cand = st := dif_neg hgt
    rw [hst_eq]
    exact ⟨rfl, hinv, fun _ => rfl, fun h => by dsimp [S_leaf_h] at hgt; omega, fun hg _ => hg⟩

/-- `r`-round synchronous leaf-splitting trajectory starting from `st₀`. -/
noncomputable def syncSplitTraj {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st₀ : PureServingState d n H L B_scan P)
    (cands : ℕ → EuclideanSpace ℝ (Fin d) × ℝ) :
    ℕ → PureServingState d n H L B_scan P
  | 0 => st₀
  | r + 1 => (syncSplitTraj st₀ cands r).syncSplitOne (cands r).1 (cands r).2

/-- Full `20 * (d + 3)^2`-round synchronous leaf-splitting theorem: starting from `st_mid.NodesInv`
and leaf size `≤ 4 * L + 2`, produces `st_final : PureServingState d n H L B_scan P` with
`st_final.WellFormed` (leaf size `≤ 2 * L + 1` and `st_final.k < D₀`) and `st_final.AllCentersGood`! -/
theorem syncSplitTraj_wellFormed
    (h_lem_5_1 : S_lem_5_1)
    {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st_mid : PureServingState d n H L B_scan P)
    (hL_floor : 68719476736 * (d + 3) ^ 4 ≤ L)
    (hinv_mid : st_mid.NodesInv)
    (hleaf_mid : (chainTerminal P.handleCoords st_mid.nodes P.activeHandles).card ≤ 4 * L + 2)
    (cands : ℕ → EuclideanSpace ℝ (Fin d) × ℝ) :
    let R := 20 * (d + 3) ^ 2
    let st_final := syncSplitTraj st_mid cands R
    st_final.uMap = st_mid.uMap ∧
    st_final.WellFormed ∧
    (chainTerminal P.handleCoords st_final.nodes P.activeHandles).card ≤ 2 * L + 1 ∧
    (st_mid.AllCentersGood →
      (∀ r < R,
        let S_r := chainTerminal P.handleCoords (syncSplitTraj st_mid cands r).nodes P.activeHandles
        2 * L + 1 < S_r.card →
          IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
            (paraboloidLiftSet (fun x : ↥S_r => P.handleCoords x.1))
            (liftedPoint (cands r).1 (cands r).2)) →
      st_final.AllCentersGood) := by
  intro R st_final
  have hD4_pos : 1 ≤ (d + 3) ^ 4 := Nat.one_le_pow 4 (d + 3) (by omega)
  have hL1 : 1 ≤ L := by omega
  have htraj_inv : ∀ r : ℕ,
      (syncSplitTraj st_mid cands r).uMap = st_mid.uMap ∧
      (syncSplitTraj st_mid cands r).NodesInv := by
    intro r
    induction r with
    | zero => exact ⟨rfl, hinv_mid⟩
    | succ r ih =>
        have hsp := (syncSplitTraj st_mid cands r).syncSplitOne_spec h_lem_5_1 hL_floor
          ih.2 (cands r).1 (cands r).2
        exact ⟨hsp.1.trans ih.1, hsp.2.1⟩
  let m_seq : ℕ → ℕ := fun r =>
    (chainTerminal P.handleCoords (syncSplitTraj st_mid cands r).nodes P.activeHandles).card
  have hm_freeze : ∀ r : ℕ, m_seq r ≤ 2 * L + 1 → m_seq (r + 1) ≤ 2 * L + 1 := by
    intro r hle
    have hsp := (syncSplitTraj st_mid cands r).syncSplitOne_spec h_lem_5_1 hL_floor
      (htraj_inv r).2 (cands r).1 (cands r).2
    have heq : m_seq (r + 1) = m_seq r := hsp.2.2.1 hle
    rw [heq]
    exact hle
  have hm_step : ∀ r < R, 2 * L + 1 < m_seq r →
      ∃ c : ℕ, m_seq r ≤ 8 * (d + 3) ^ 2 * c ∧ m_seq (r + 1) + c = m_seq r := by
    intro r _ hgt
    have hsp := (syncSplitTraj st_mid cands r).syncSplitOne_spec h_lem_5_1 hL_floor
      (htraj_inv r).2 (cands r).1 (cands r).2
    exact hsp.2.2.2.1 hgt
  have hm_R : (chainTerminal P.handleCoords st_final.nodes P.activeHandles).card ≤ 2 * L + 1 := by
    change m_seq R ≤ 2 * L + 1
    rcases sync_leaf_split_bound hL1 m_seq hleaf_mid hm_step with hdone | ⟨r₀, hr₀_lt, hr₀_le⟩
    · exact hdone
    · have hstay : ∀ k : ℕ, m_seq (r₀ + k) ≤ 2 * L + 1 := by
        intro k
        induction k with
        | zero => simpa using hr₀_le
        | succ k ih => simpa [Nat.add_assoc] using hm_freeze (r₀ + k) ih
      have hR_eq : R = r₀ + (R - r₀) := by dsimp [R] at hr₀_lt ⊢; omega
      rw [hR_eq]
      exact hstay (R - r₀)
  refine ⟨(htraj_inv R).1, ⟨(htraj_inv R).2, by omega⟩, hm_R, ?_⟩
  intro hgood₀ hall_cp
  have hgood_traj : ∀ r ≤ R, (syncSplitTraj st_mid cands r).AllCentersGood := by
    intro r hr
    induction r with
    | zero => exact hgood₀
    | succ r ih =>
        have hsp := (syncSplitTraj st_mid cands r).syncSplitOne_spec h_lem_5_1 hL_floor
          (htraj_inv r).2 (cands r).1 (cands r).2
        exact hsp.2.2.2.2 (ih (Nat.le_of_succ_le hr)) (hall_cp r (Nat.lt_of_succ_le hr))
  exact hgood_traj R le_rfl

/-- Combined single-step pure schedule transition: takes post-tick per-node statuses `status` after
routing an external update `(P ↦ P', uMap ↦ uMap')`, applies `installOrKeepAfterTick`, and runs
`20 * (d + 3)^2` synchronous leaf-splitting rounds to restore `WellFormed` (leaf `≤ 2 * L + 1 ≤ 3 * L + 2`
and `k < D₀`) and `AllCentersGood`! -/
theorem PureServingState.fullPureStep
    (h_lem_5_1 : S_lem_5_1)
    (h_lem_C_2 : S_lem_C_2)
    {d n H K₀ L B_scan : ℕ}
    {P P' : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (hwf : st.WellFormed)
    (hL_floor : 68719476736 * (d + 3) ^ 4 ≤ L)
    (hL_eq10 : SatisfiesLeafCutoffEq10 d n (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) 0 K₀ L)
    (hB_floor : 16777216 * (d + 3) ^ 4 ≤ B_scan)
    (uMap' : GhostUidMap d P')
    (hle_uid : st.uMap.nextUid ≤ uMap'.nextUid)
    (hag_uid : ∀ u < st.uMap.nextUid, uMap'.ghostCoords u = st.uMap.ghostCoords u)
    (hchg_root : IsInputChange P.activeHandles P'.activeHandles)
    (hcoords_root : ∀ h : ℕ, h ∈ P.activeHandles → h ∈ P'.activeHandles →
      P'.handleCoords h = P.handleCoords h)
    (snAge' trueAge' : Fin st.k → ℕ)
    (htr_le' : ∀ r : Fin st.k, trueAge' r ≤ snAge' r)
    (hhas_age' : ∀ r : Fin st.k,
      HasNodeAge (st.birthSnap r)
        (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc) (trueAge' r))
    (status : (r : Fin st.k) → PostTickNodeStatus d n (d + 3) L B_scan
      uMap'.nextUid uMap'.ghostCoords (st.birthSnap r)
      (chainInput uMap'.ghostCoords st.nodes uMap'.ActiveUids r.castSucc) (snAge' r))
    (cands : ℕ → EuclideanSpace ℝ (Fin d) × ℝ) :
    ∃ st_mid : PureServingState d n H L B_scan P',
      st_mid.uMap = uMap' ∧
      st_mid.NodesInv ∧
      (chainTerminal P'.handleCoords st_mid.nodes P'.activeHandles).card ≤ 4 * L + 2 ∧
      let R := 20 * (d + 3) ^ 2
      let st_final := syncSplitTraj st_mid cands R
      st_final.uMap = uMap' ∧
      st_final.WellFormed ∧
      (chainTerminal P'.handleCoords st_final.nodes P'.activeHandles).card ≤ 2 * L + 1 ∧
      (st.AllCentersGood →
        (∀ r : Fin st.k, (status r).CenterGood) →
        (∀ j < R,
          let S_j := chainTerminal P'.handleCoords (syncSplitTraj st_mid cands j).nodes P'.activeHandles
          2 * L + 1 < S_j.card →
            IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
              (paraboloidLiftSet (fun x : ↥S_j => P'.handleCoords x.1))
              (liftedPoint (cands j).1 (cands j).2)) →
        st_final.AllCentersGood) := by
  rcases installOrKeepAfterTick h_lem_C_2 st hwf hL_floor hL_eq10 hB_floor uMap'
      hle_uid hag_uid hchg_root hcoords_root snAge' trueAge' htr_le' hhas_age' status
    with ⟨st_mid, hu_mid, hinv_mid, hleaf_mid, hgood_mid⟩
  have hsp := syncSplitTraj_wellFormed h_lem_5_1 st_mid hL_floor hinv_mid hleaf_mid cands
  dsimp only at hsp
  refine ⟨st_mid, hu_mid, hinv_mid, hleaf_mid, hsp.1.trans hu_mid, hsp.2.1, hsp.2.2.1, ?_⟩
  intro hgood₀ hcg_tick hall_cp
  exact hsp.2.2.2 (hgood_mid hgood₀.1 hcg_tick) hall_cp

/-- Extracts the exact Monte Carlo centerpoint & node-age hypothesis required by
`exec_runBaselineSlotStmt_active` (`hGoodImp`) for serving node `r : Fin st.k`! -/
theorem PureServingState.baselineGoodHyp
    {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st : PureServingState d n H L B_scan P)
    (hinv : st.NodesInv) (hgood : st.AllCentersGood)
    (r : Fin st.k) :
    ∃ (P₀_uid : Finset ℕ) (age : ℕ),
      1 ≤ P₀_uid.card ∧
      IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
        (paraboloidLiftSet (fun i : ↥P₀_uid => st.uMap.ghostCoords i.1))
        (liftedPoint (st.nodes r).o ((st.nodes r).V + ‖(st.nodes r).o‖ ^ 2)) ∧
      HasNodeAge P₀_uid
        (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc) age ∧
      (age : ℝ) ≤ (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) * (P₀_uid.card : ℝ) / 16 := by
  rcases hinv r with ⟨hlarge, _, _, _, hage, _⟩
  exact ⟨st.birthSnap r, st.trueAge r, by omega, hgood.1 r, hage,
    (st.age_le_alpha_sixteen hinv r).2⟩

/-- Parameterized wrapper of `PureServingState.baselineGoodHyp` rewriting `d + 3` to `D`
(e.g. `p.D` with `hp.hD_eq : p.D = d + 3`) for direct drop-in use with `exec_runBaselineSlotStmt_active`. -/
theorem PureServingState.baselineGoodHyp_param
    {d n H L B_scan D : ℕ} {P : DynamicPointSet d}
    (hD_eq : D = d + 3)
    (st : PureServingState d n H L B_scan P)
    (hinv : st.NodesInv) (hgood : st.AllCentersGood)
    (r : Fin st.k) :
    ∃ (P₀_uid : Finset ℕ) (age : ℕ),
      1 ≤ P₀_uid.card ∧
      IsCenterpoint (1 / (4 * ((D : ℝ) ^ 2)))
        (paraboloidLiftSet (fun i : ↥P₀_uid => st.uMap.ghostCoords i.1))
        (liftedPoint (st.nodes r).o ((st.nodes r).V + ‖(st.nodes r).o‖ ^ 2)) ∧
      HasNodeAge P₀_uid
        (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc) age ∧
      (age : ℝ) ≤ (1 / (4 * ((D : ℝ) ^ 2))) * (P₀_uid.card : ℝ) / 16 := by
  subst hD_eq
  exact st.baselineGoodHyp hinv hgood r

/-- Pure factor-`√2` diameter query answer validity from per-level baseline conditions and
all-distinct leaf-pair distance bounds on `PureServingState`. -/
theorem PureServingState.valid_answer_of_chain_and_leaf_scan
    (h_lem_5_2 : S_lem_5_2)
    {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (hP : P.WellFormed n)
    (st : PureServingState d n H L B_scan P)
    (hcard2 : 2 ≤ P.activeIds.card)
    {bestH1 bestH2 : ℕ}
    (hb1 : bestH1 ∈ P.activeHandles) (hb2 : bestH2 ∈ P.activeHandles) (hb_ne : bestH1 ≠ bestH2)
    (hbase : ∀ r : Fin st.k,
      ∃ pair : Option (ℕ × ℕ),
        (st.nodes r).SatisfiesBaselineCond st.uMap.ghostCoords
          (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc) pair ∧
        ∀ u v : ℕ, pair = some (u, v) → u ≠ v →
          ‖st.uMap.ghostCoords u - st.uMap.ghostCoords v‖ ^ 2 ≤
            euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2))
    (hleaf :
      let S_leaf_h := chainTerminal P.handleCoords st.nodes P.activeHandles
      ∀ a (ha : a < S_leaf_h.card) b (hb : b < S_leaf_h.card), a ≠ b →
        euclideanDistSq (P.handleCoords (S_leaf_h.orderEmbOfFin rfl ⟨a, ha⟩))
                        (P.handleCoords (S_leaf_h.orderEmbOfFin rfl ⟨b, hb⟩)) ≤
          euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2)) :
    IsValidFactorCAnswer (Real.sqrt 2) P
      { diameterHandles := some (bestH1, bestH2)
        cachedDistSq := euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2) } := by
  classical
  choose basePairs hbp using hbase
  let S_leaf_h := chainTerminal P.handleCoords st.nodes P.activeHandles
  let S_leaf_u := chainTerminal st.uMap.ghostCoords st.nodes st.uMap.ActiveUids
  have hsub_leaf : S_leaf_h ⊆ P.activeHandles :=
    cg01_chainTerminal_subset P.handleCoords st.nodes P.activeHandles
  have hmap_leaf : st.uMap.mapSet S_leaf_h = S_leaf_u :=
    st.uMap.mapSet_chainTerminal st.nodes
  have hbij_leaf := st.uMap.mapSet_bij hsub_leaf
  rw [hmap_leaf] at hbij_leaf
  rcases exists_leafPair_uid_of_distinct_bound P.handleCoords st.uMap.ghostCoords
      S_leaf_h S_leaf_u st.uMap.uidOfH st.uMap.hOfUid
      hbij_leaf.2.2.1 hbij_leaf.2.2.2
      (euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2)) hleaf
    with ⟨leafPair, hleaf_act, hleaf_diam, hleaf_bd⟩
  have hbij_root := st.uMap.mapSet_bij (Finset.Subset.refl P.activeHandles)
  rw [st.uMap.mapSet_activeHandles] at hbij_root
  exact p46_valid_answer_of_chain_and_leaf h_lem_5_2 hP hcard2
    hbij_root.2.2.1 hbij_root.2.2.2 st.nodes basePairs leafPair
    (fun r => (hbp r).1) hleaf_act hleaf_diam hb1 hb2 hb_ne
    (fun r => (hbp r).2) hleaf_bd

/-- Direct RAM-postcondition wrapper combining baseline candidate bounds (`m_cand` before finalize),
leaf-pair scan bounds (`m_cand` before finalize), and `exec_finalizeStepAnswerStmt`'s postcondition
on `m_out` into `IsValidFactorCAnswer (Real.sqrt 2) P (readStoredAns m_out)` for ALL `P.activeIds.card`! -/
theorem PureServingState.valid_answer_of_finalize
    (h_lem_5_2 : S_lem_5_2)
    {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (hP : P.WellFormed n)
    (st : PureServingState d n H L B_scan P)
    (m_cand m_out : ArithRAMMemory)
    (hfin_le1 : P.activeIds.card ≤ 1 →
      IsValidFactorCAnswer (Real.sqrt 2) P (readStoredAns m_out))
    (hfin_ge2 : 2 ≤ P.activeIds.card →
      ∃ bestH1 bestH2 : ℕ,
        bestH1 ∈ P.activeHandles ∧
        bestH2 ∈ P.activeHandles ∧
        bestH1 ≠ bestH2 ∧
        readStoredAns m_out =
          { diameterHandles := some (bestH1, bestH2)
            cachedDistSq := euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2) } ∧
        (wRead m_cand 26 10 = 1 →
          rRead m_cand 26 10 ≤ euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2)))
    (hbase_cand : ∀ r : Fin st.k,
      ∃ pair : Option (ℕ × ℕ),
        (st.nodes r).SatisfiesBaselineCond st.uMap.ghostCoords
          (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc) pair ∧
        ∀ u v : ℕ, pair = some (u, v) → u ≠ v →
          wRead m_cand 26 10 = 1 ∧
          ‖st.uMap.ghostCoords u - st.uMap.ghostCoords v‖ ^ 2 ≤ rRead m_cand 26 10)
    (hleaf_cand :
      let S_leaf_h := chainTerminal P.handleCoords st.nodes P.activeHandles
      ∀ a (ha : a < S_leaf_h.card) b (hb : b < S_leaf_h.card), a ≠ b →
        wRead m_cand 26 10 = 1 ∧
        euclideanDistSq (P.handleCoords (S_leaf_h.orderEmbOfFin rfl ⟨a, ha⟩))
                        (P.handleCoords (S_leaf_h.orderEmbOfFin rfl ⟨b, hb⟩)) ≤
          rRead m_cand 26 10) :
    IsValidFactorCAnswer (Real.sqrt 2) P (readStoredAns m_out) := by
  by_cases hle1 : P.activeIds.card ≤ 1
  · exact hfin_le1 hle1
  · have hge2 : 2 ≤ P.activeIds.card := by omega
    rcases hfin_ge2 hge2 with ⟨bestH1, bestH2, hb1, hb2, hb_ne, hans_eq, hcand_le⟩
    rw [hans_eq]
    refine st.valid_answer_of_chain_and_leaf_scan h_lem_5_2 hP hge2 hb1 hb2 hb_ne
      (fun r => ?_) (fun a ha b hb hne => ?_)
    · rcases hbase_cand r with ⟨pair, hcond, hbd⟩
      refine ⟨pair, hcond, fun u v hp huv => ?_⟩
      rcases hbd u v hp huv with ⟨hw1, hsq⟩
      exact hsq.trans (hcand_le hw1)
    · rcases hleaf_cand a ha b hb hne with ⟨hw1, hsq⟩
      exact hsq.trans (hcand_le hw1)

end UL.Proof_lem_7_2_RacerP46
