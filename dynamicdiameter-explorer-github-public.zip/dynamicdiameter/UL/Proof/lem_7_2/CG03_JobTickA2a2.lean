import UL.Proof.lem_7_2.CG03_JobTickA2a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 3. Randomized HPJ + Provisional Center + Job Level Init (`hpjFreezeRunInitStmt`) -/

def hpjFreezeRunInitStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 26 (.lit 0) (.lit 1),
    runHPJOnSlotStmt d n M_box p,
    provisionalFromHPJStmt d n p.K_seg M_box,
    initJobLevelStmt d M_box
  ]

theorem boxSafe_hpjFreezeRunInitStmt {d n T_max M_box : ℕ}
    (hT : 28 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (hpjFreezeRunInitStmt d n M_box p) := by
  unfold hpjFreezeRunInitStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact boxSafe_runHPJOnSlotStmt hT p
  · exact boxSafe_provisionalFromHPJStmt hT d n p.K_seg
  · exact boxSafe_initJobLevelStmt (by omega) d

noncomputable def hpjFreezeRunInitCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  hpjCallCost d n p + (100 * (p.K_seg + 1) + 180 * (d + 1) + 150) + (120 * (d + 1) + 400) + 50

theorem exec_hpjFreezeRunInitStmt
    (h_lem_5_1 : S_lem_5_1)
    {d n M_box : ℕ} (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx bS dS spDS rS spRS openRem : ℕ}
    {S_birth S_parent S_uid : Finset ℕ}
    {activeH : Finset ℕ} {livePts snapPts ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {uidOfH hOfUid : ℕ → ℕ}
    (hpop₀ : mem.popDepth 0 = mem)
    (hD_eq : p.D = d + 3)
    (hkφ : p.φ_ev = (1 / 2 : ℝ) ^ p.k_φ)
    (hφ0 : 0 < p.φ_ev) (hφ1 : p.φ_ev < 1 / 2)
    (hp_eq : p.P_hpj = hpjParams d p.φ_ev)
    (hp_props : HPJParamProps d p.φ_ev p.P_hpj)
    (hbias_hpj : (((2 ^ p.P_hpj.q : ℕ) : ℝ) * (n : ℝ)) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev)
    (hB_hpj : p.B_hpj = (2 ^ p.P_hpj.q) * p.M_bits + p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q)
    (hbS : bS < p.NumSlots) (hdS : dS < p.NumSlots)
    (hspDS : spDS < p.NumSlots) (hrS : rS < p.NumSlots) (hspRS : spRS < p.NumSlots)
    (hdist : bS ≠ dS ∧ bS ≠ spDS ∧ bS ≠ rS ∧ bS ≠ spRS ∧
             dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧
             spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS)
    (hb_pos : 0 < S_birth.card) (hb_le_n : S_birth.card ≤ n)
    (hBox26 : 30 ≤ M_box)
    (hBox_slots : p.NumSlots ≤ M_box)
    (hBox_samp : (2 ^ p.P_hpj.q) * d ≤ M_box)
    (hBox_d : d + 1 ≤ M_box)
    (hBox_w23 : 8 * idx + 8 ≤ M_box)
    (hBox_r23 : idx * d + d ≤ M_box)
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hbS_reg : wRead mem 26 1 = (bS : ℤ))
    (hdS_reg : wRead mem 26 20 = (dS : ℤ))
    (hspDS_reg : wRead mem 26 21 = (spDS : ℤ))
    (hrS_reg : wRead mem 26 22 = (rS : ℤ))
    (hspRS_reg : wRead mem 26 23 = (spRS : ℤ))
    (hbCard_reg : wRead mem 26 24 = (S_birth.card : ℤ))
    (hrem_reg : wRead mem 26 25 = (openRem : ℤ))
    (h6_bS : 1 ≤ wRead mem 6 (bS : ℤ))
    (hseg : SegGenBound p.K_seg p.NumSlots mem)
    (hsave : SaveGenBound n p.NumSlots mem)
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hSeg_bS : EncSegSlot p.K_seg mem bS S_birth (fun _ => 0))
    (hSlot_bS : EncSlotCoords d n mem activeH livePts bS S_birth snapPts)
    (hf_uid : ∀ h ∈ S_birth, uidOfH h ∈ S_uid ∧ ghostCoords (uidOfH h) = snapPts h ∧ hOfUid (uidOfH h) = h)
    (hg_uid : ∀ u ∈ S_uid, hOfUid u ∈ S_birth ∧ uidOfH (hOfUid u) = u) :
    let α : ℝ := 1 / (4 * ((p.D : ℝ) ^ 2))
    let bId : ℕ := S_birth.orderEmbOfFin rfl ⟨0, hb_pos⟩
    RandExecBad inp (hpjFreezeRunInitStmt d n M_box p) p.B_hpj mem
      (fun m' =>
        let prov := provAtIdx d m' idx
        let ball := applyBirthCoreFallback α snapPts S_birth prov
        SegGenBound p.K_seg p.NumSlots m' ∧
        SaveGenBound n p.NumSlots m' ∧
        EncJobLevel d n p.D p.K_seg p.NumSlots m' activeH livePts idx S_birth snapPts prov S_parent true ∧
        (∃ (o_cand : EuclideanSpace ℝ (Fin d)) (s_cand : ℝ),
          prov = provisionalCenter snapPts bId (.candidate o_cand (liftVariance o_cand s_cand)) ∧
          ball = selectOpenedLevelBall α ghostCoords S_uid (uidOfH bId)
            (.candidate o_cand (liftVariance o_cand s_cand))) ∧
        wRead m' 23 (((8 * idx + 0 : ℕ) : ℤ)) = (S_birth.card : ℤ) ∧
        wRead m' 23 (((8 * idx + 2 : ℕ) : ℤ)) = (bS : ℤ) ∧
        wRead m' 23 (((8 * idx + 3 : ℕ) : ℤ)) = (dS : ℤ) ∧
        wRead m' 23 (((8 * idx + 4 : ℕ) : ℤ)) = (spDS : ℤ) ∧
        wRead m' 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ) ∧
        wRead m' 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ) ∧
        wRead m' 23 (((8 * idx + 7 : ℕ) : ℤ)) = (openRem : ℤ) ∧
        jobLevelSlotSet m' idx = {bS, dS, spDS, rS, spRS} ∧
        jobLevelLiveSlots m' idx true = {spRS, dS, spDS, rS} ∧
        wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 ∧
        wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = 0 ∧
        wRead m' 6 (dS : ℤ) = 0 ∧
        wRead m' 6 (spDS : ℤ) = 0 ∧
        wRead m' 6 (rS : ℤ) = 0 ∧
        wRead m' 6 (spRS : ℤ) = 0 ∧
        (∀ s' < p.NumSlots, ∀ S₁ fSq₁, EncSegSlot p.K_seg mem s' S₁ fSq₁ → EncSegSlot p.K_seg m' s' S₁ fSq₁) ∧
        (∀ s' < p.NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
          ∀ S₁ sp₁, EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
            EncSlotCoords d n m' activeH livePts s' S₁ sp₁) ∧
        (∀ t, t ≠ 6 → t ≠ 23 → t ≠ 24 → t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
        (∀ i, i ≠ 0 → wRead m' 26 i = wRead mem 26 i) ∧
        (∀ s' : ℤ, s' ≠ (dS : ℤ) → s' ≠ (spDS : ℤ) → s' ≠ (rS : ℤ) → s' ≠ (spRS : ℤ) →
          wRead m' 6 s' = wRead mem 6 s') ∧
        (∀ i : ℤ, (i < ((8 * idx : ℕ) : ℤ) ∨ ((8 * idx + 8 : ℕ) : ℤ) ≤ i) →
          wRead m' 23 i = wRead mem 23 i) ∧
        (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
          wRead m' 24 i = wRead mem 24 i) ∧
        (∀ t, t ≠ 23 → t ≠ 24 → t ≠ 27 → ∀ i, rRead m' t i = rRead mem t i) ∧
        (∀ i : ℤ, (i < ((idx * d : ℕ) : ℤ) ∨ ((idx * d + d : ℕ) : ℤ) ≤ i) →
          rRead m' 23 i = rRead mem 23 i) ∧
        (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
          rRead m' 24 i = rRead mem 24 i))
      (fun m' =>
        let ball := applyBirthCoreFallback α snapPts S_birth (provAtIdx d m' idx)
        IsCenterpoint α (paraboloidLiftSet (fun u : ↥S_uid => ghostCoords u.1))
          (liftedPoint ball.o (ball.V + ‖ball.o‖ ^ 2)))
      (2 * p.φ_ev)
      (hpjFreezeRunInitCost d n p) := by
  intro α bId
  have hbId_mem : bId ∈ S_birth := S_birth.orderEmbOfFin_mem rfl ⟨0, hb_pos⟩
  let m1 := wWrite mem 26 0 1
  have hp1 : m1.popDepth 0 = m1 := mem_writeWord_popDepth 1 hpop₀ rfl
  have hd1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 0) (.lit 1)) mem m1 14 :=
    exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hLive1 : EncLiveCoords d n m1 activeH livePts :=
    ⟨hLive.1, fun h hh c => by simp [m1]; exact hLive.2 h hh c⟩
  have hSeg1 : EncSegSlot p.K_seg m1 bS S_birth (fun _ => 0) :=
    hSeg_bS.congr_mem_fSq (by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1])
      (fun _ _ => by simp [m1]) (fun _ _ => by simp [m1]) (fun _ _ => rfl)
  have hSlot1 : EncSlotCoords d n m1 activeH livePts bS S_birth snapPts :=
    hSlot_bS.congr_mem3 (by simp [m1]) (fun _ => by simp [m1]) (fun _ => by simp [m1])
  rcases exec_runHPJOnSlotStmt_active (M_box := M_box) p inp m1
      (by simp [m1]) (by simp [m1, hbS_reg]) hb_pos hb_le_n
      hD_eq hkφ hφ0 hφ1 hp_eq hp_props hbias_hpj hB_hpj hBox_samp hBox_d
      hSeg1 hLive1 hSlot1
    with ⟨PostH, BadH, _, hRH, hcardH, hpostH⟩
  have hBadH : RandExecBad inp (runHPJOnSlotStmt d n M_box p) p.B_hpj m1
      (fun m2 =>
        (∀ t idx, wRead m2 t idx = wRead m1 t idx) ∧
        (∀ t, t ≠ 27 → ∀ idx, rRead m2 t idx = rRead m1 t idx))
      (fun m2 =>
        let o_out : EuclideanSpace ℝ (Fin d) :=
          WithLp.toLp 2 (fun c : Fin d => rRead m2 27 (c.val : ℤ))
        let s_out : ℝ := rRead m2 27 (d : ℤ)
        IsCenterpoint α (paraboloidLiftSet (fun x : ↥S_birth => snapPts x.1))
          (liftedPoint o_out s_out))
      (2 * p.φ_ev) (hpjCallCost d n p) := by
    refine ⟨by positivity, PostH, BadH, inferInstance, hRH, hcardH, fun bits m2 hp => ?_⟩
    rcases hpostH bits m2 hp with ⟨hp2, hw2, hr2, hg2⟩
    exact ⟨hp2, ⟨hw2, hr2⟩, hg2⟩
  have hStepTail : RandExecBad inp
      (.seq (runHPJOnSlotStmt d n M_box p)
        (.seq (provisionalFromHPJStmt d n p.K_seg M_box) (initJobLevelStmt d M_box)))
      p.B_hpj m1
      (fun m' =>
        let prov := provAtIdx d m' idx
        let ball := applyBirthCoreFallback α snapPts S_birth prov
        SegGenBound p.K_seg p.NumSlots m' ∧
        SaveGenBound n p.NumSlots m' ∧
        EncJobLevel d n p.D p.K_seg p.NumSlots m' activeH livePts idx S_birth snapPts prov S_parent true ∧
        (∃ (o_cand : EuclideanSpace ℝ (Fin d)) (s_cand : ℝ),
          prov = provisionalCenter snapPts bId (.candidate o_cand (liftVariance o_cand s_cand)) ∧
          ball = selectOpenedLevelBall α ghostCoords S_uid (uidOfH bId)
            (.candidate o_cand (liftVariance o_cand s_cand))) ∧
        wRead m' 23 (((8 * idx + 0 : ℕ) : ℤ)) = (S_birth.card : ℤ) ∧
        wRead m' 23 (((8 * idx + 2 : ℕ) : ℤ)) = (bS : ℤ) ∧
        wRead m' 23 (((8 * idx + 3 : ℕ) : ℤ)) = (dS : ℤ) ∧
        wRead m' 23 (((8 * idx + 4 : ℕ) : ℤ)) = (spDS : ℤ) ∧
        wRead m' 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ) ∧
        wRead m' 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ) ∧
        wRead m' 23 (((8 * idx + 7 : ℕ) : ℤ)) = (openRem : ℤ) ∧
        jobLevelSlotSet m' idx = {bS, dS, spDS, rS, spRS} ∧
        jobLevelLiveSlots m' idx true = {spRS, dS, spDS, rS} ∧
        wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 ∧
        wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = 0 ∧
        wRead m' 6 (dS : ℤ) = 0 ∧
        wRead m' 6 (spDS : ℤ) = 0 ∧
        wRead m' 6 (rS : ℤ) = 0 ∧
        wRead m' 6 (spRS : ℤ) = 0 ∧
        (∀ s' < p.NumSlots, ∀ S₁ fSq₁, EncSegSlot p.K_seg mem s' S₁ fSq₁ → EncSegSlot p.K_seg m' s' S₁ fSq₁) ∧
        (∀ s' < p.NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
          ∀ S₁ sp₁, EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
            EncSlotCoords d n m' activeH livePts s' S₁ sp₁) ∧
        (∀ t, t ≠ 6 → t ≠ 23 → t ≠ 24 → t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
        (∀ i, i ≠ 0 → wRead m' 26 i = wRead mem 26 i) ∧
        (∀ s' : ℤ, s' ≠ (dS : ℤ) → s' ≠ (spDS : ℤ) → s' ≠ (rS : ℤ) → s' ≠ (spRS : ℤ) →
          wRead m' 6 s' = wRead mem 6 s') ∧
        (∀ i : ℤ, (i < ((8 * idx : ℕ) : ℤ) ∨ ((8 * idx + 8 : ℕ) : ℤ) ≤ i) →
          wRead m' 23 i = wRead mem 23 i) ∧
        (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
          wRead m' 24 i = wRead mem 24 i) ∧
        (∀ t, t ≠ 23 → t ≠ 24 → t ≠ 27 → ∀ i, rRead m' t i = rRead mem t i) ∧
        (∀ i : ℤ, (i < ((idx * d : ℕ) : ℤ) ∨ ((idx * d + d : ℕ) : ℤ) ≤ i) →
          rRead m' 23 i = rRead mem 23 i) ∧
        (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
          rRead m' 24 i = rRead mem 24 i))
      (fun m' =>
        let ball := applyBirthCoreFallback α snapPts S_birth (provAtIdx d m' idx)
        IsCenterpoint α (paraboloidLiftSet (fun u : ↥S_uid => ghostCoords u.1))
          (liftedPoint ball.o (ball.V + ‖ball.o‖ ^ 2)))
      (2 * p.φ_ev)
      (hpjCallCost d n p + ((100 * (p.K_seg + 1) + 180 * (d + 1) + 150) + (120 * (d + 1) + 400))) := by
    refine RandExecBad.seq_det_right hp1 hBadH ?_
    intro m2 _ ⟨hw2, hr2⟩
    let o_cand : EuclideanSpace ℝ (Fin d) :=
      WithLp.toLp 2 (fun c : Fin d => rRead m2 27 (c.val : ℤ))
    let s_cand : ℝ := rRead m2 27 (d : ℤ)
    let prov : ChainNode d :=
      provisionalCenter snapPts bId (.candidate o_cand (liftVariance o_cand s_cand))
    have hSeg2 : EncSegSlot p.K_seg m2 bS S_birth (fun _ => 0) :=
      hSeg1.congr_mem_fSq (hw2 5 _) (fun _ _ => hw2 8 _) (fun _ _ => hw2 9 _)
        (fun _ _ => hw2 10 _) (fun _ _ => hr2 8 (by decide) _) (fun _ _ => rfl)
    have hLive2 : EncLiveCoords d n m2 activeH livePts :=
      ⟨hLive1.1, fun h hh c => by rw [hr2 4 (by decide)]; exact hLive1.2 h hh c⟩
    have hSlot2 : EncSlotCoords d n m2 activeH livePts bS S_birth snapPts :=
      hSlot1.congr_mem3 (hw2 6 _) (hw2 11) (hr2 11 (by decide))
    rcases exec_provisionalFromHPJStmt (M_box := M_box) inp m2
        (by rw [hw2]; simp [m1, hbS_reg]) hb_pos hBox_d hSeg2 hLive2 hSlot2
      with ⟨m3, hd_prov, _, hw3, hr3, hpo3, hpV3⟩
    have hseg3 : SegGenBound p.K_seg p.NumSlots m3 :=
      ⟨by rw [hw3, hw2]; simpa [m1] using hseg.1,
       fun s hs => by rw [hw3, hw2, hw3, hw2]; simpa [m1] using hseg.2.1 s hs,
       fun s hs u hu => by rw [hw3, hw2, hw3, hw2]; simpa [m1] using hseg.2.2 s hs u hu⟩
    have hsave3 : SaveGenBound n p.NumSlots m3 :=
      ⟨by rw [hw3, hw2]; simpa [m1] using hsave.1,
       fun s hs => by rw [hw3, hw2, hw3, hw2]; simpa [m1] using hsave.2.1 s hs,
       fun s hs h hh => by rw [hw3, hw2, hw3, hw2]; simpa [m1] using hsave.2.2 s hs h hh⟩
    have hSeg3 : EncSegSlot p.K_seg m3 bS S_birth (fun _ => 0) :=
      hSeg2.congr_mem_fSq (hw3 5 _) (fun _ _ => hw3 8 _) (fun _ _ => hw3 9 _)
        (fun _ _ => hw3 10 _) (fun _ _ => hr3 8 (by decide) _) (fun _ _ => rfl)
    have hSlot3 : EncSlotCoords d n m3 activeH livePts bS S_birth snapPts :=
      hSlot2.congr_mem3 (hw3 6 _) (hw3 11) (hr3 11 (by decide))
    rcases exec_initJobLevelExact (D := p.D) (openRem := openRem) (S_parent := S_parent) (M_box := M_box)
        inp m3 hbS hdS hspDS hrS hspRS hdist hb_pos hBox_slots hBox_w23 hBox_r23
        (by rw [hw3, hw2]; simp [m1, hidx_reg])
        (by rw [hw3, hw2]; simp [m1, hbS_reg])
        (by rw [hw3, hw2]; simp [m1, hdS_reg])
        (by rw [hw3, hw2]; simp [m1, hspDS_reg])
        (by rw [hw3, hw2]; simp [m1, hrS_reg])
        (by rw [hw3, hw2]; simp [m1, hspRS_reg])
        (by rw [hw3, hw2]; simp [m1, hbCard_reg])
        (by rw [hw3, hw2]; simp [m1, hrem_reg])
        hpo3 hpV3 (by rw [hw3, hw2]; simpa [m1] using h6_bS)
        hseg3 hsave3 hSeg3 hSlot3
      with ⟨m4, hd_init, hp4, hseg4, hsave4, hEnc4, hprov4,
            hw0_4, hw2_4, hw3_4, hw4_4, hw5_4, hw6_4, hw7_4,
            hslot4, hlive4, hw24_0_4, hw24_1_4,
            hw6_dS_4, hw6_spDS_4, hw6_rS_4, hw6_spRS_4,
            hSegFr4, hSlotFr4, hwo4, hw6Fr4, hw23Fr4, hw24Fr4, hro4, hr23Fr4, hr24Fr4⟩
    have hball_eq := selectOpenedLevelBall_bij_uid α snapPts ghostCoords S_birth S_uid
      uidOfH hOfUid hf_uid hg_uid hbId_mem o_cand s_cand
    refine ⟨m4, hd_prov.seq hd_init, hp4, ?_, ?_⟩
    · dsimp only
      rw [hprov4]
      refine ⟨hseg4, hsave4, hEnc4, ⟨o_cand, s_cand, rfl, hball_eq⟩,
        hw0_4, hw2_4, hw3_4, hw4_4, hw5_4, hw6_4, hw7_4,
        hslot4, hlive4, hw24_0_4, hw24_1_4,
        hw6_dS_4, hw6_spDS_4, hw6_rS_4, hw6_spRS_4,
        ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · intro s' hs' S₁ fSq₁ hE
        have hE3 : EncSegSlot p.K_seg m3 s' S₁ fSq₁ :=
          hE.congr_mem_fSq (by rw [hw3, hw2]; simp [m1])
            (fun _ _ => by rw [hw3, hw2]; simp [m1])
            (fun _ _ => by rw [hw3, hw2]; simp [m1])
            (fun _ _ => by rw [hw3, hw2]; simp [m1])
            (fun _ _ => by rw [hr3 8 (by decide), hr2 8 (by decide)]; simp [m1]) (fun _ _ => rfl)
        exact hSegFr4 s' hs' S₁ fSq₁ hE3
      · intro s' hs' n1 n2 n3 n4 S₁ sp₁ hC
        have hC3 : EncSlotCoords d n m3 activeH livePts s' S₁ sp₁ :=
          hC.congr_mem3 (by rw [hw3, hw2]; simp [m1])
            (fun i => by rw [hw3, hw2]; simp [m1])
            (fun i => by rw [hr3 11 (by decide), hr2 11 (by decide)]; simp [m1])
        exact hSlotFr4 s' hs' n1 n2 n3 n4 S₁ sp₁ hC3
      · intro t h6 h23 h24 h26 i
        rw [hwo4 t h6 h23 h24, hw3, hw2]; simp [m1, h26]
      · intro i hi
        rw [hwo4 26 (by decide) (by decide) (by decide), hw3, hw2]; simp [m1, hi]
      · intro s' n1 n2 n3 n4
        rw [hw6Fr4 s' n1 n2 n3 n4, hw3, hw2]; simp [m1]
      · intro i hi; rw [hw23Fr4 i hi, hw3, hw2]; simp [m1]
      · intro i hi; rw [hw24Fr4 i hi, hw3, hw2]; simp [m1]
      · intro t h23 h24 h27 i
        rw [hro4 t h23 h24, hr3 t h27, hr2 t h27]; simp [m1]
      · intro i hi; rw [hr23Fr4 i hi, hr3 23 (by decide), hr2 23 (by decide)]; simp [m1]
      · intro i hi; rw [hr24Fr4 i hi, hr3 24 (by decide), hr2 24 (by decide)]; simp [m1]
    · intro hcp_m2
      dsimp only
      rw [hprov4]
      exact (hpj_good_ball_centerpoint h_lem_5_1 (by omega : 3 ≤ p.D) snapPts ghostCoords
        S_birth S_uid hb_pos uidOfH hOfUid hf_uid hg_uid hbId_mem o_cand s_cand hcp_m2).2
  exact (RandExecBad.seq_det_left hpop₀ hp1 hd1 hStepTail).mono
    (fun _ h => h) (fun _ _ h => h) le_rfl (by unfold hpjFreezeRunInitCost; omega)

end UL.Proof_lem_7_2_RacerP46
