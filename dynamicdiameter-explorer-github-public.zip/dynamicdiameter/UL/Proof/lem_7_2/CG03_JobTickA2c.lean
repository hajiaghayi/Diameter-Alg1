import UL.Proof.lem_7_2.CG03_JobTickA2b

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Deadline Suffix Swap Subroutine (`deadlineSuffixSwapStmt`) -/

def copyCenterCoordsToSnStmt (d M_box rSnCenterO : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 17)) (.lit (d : ℤ))),
    loadHeapCoordsToLocalStmt d 23 18 0,
    .writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 18)) (.lit (d : ℤ))),
    storeLocalCoordsToHeapStmt d M_box rSnCenterO 18 0
  ])

theorem boxSafe_copyCenterCoordsToSnStmt {T_max M_box : ℕ}
    (d rSnCenterO : ℕ) (hO : rSnCenterO < T_max) :
    BoxSafeOuter T_max M_box (copyCenterCoordsToSnStmt d M_box rSnCenterO) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact boxSafe_loadHeapCoordsToLocalStmt d 23 18 0
  · exact .writeWordLocal _ _ _
  · exact boxSafe_storeLocalCoordsToHeapStmt d rSnCenterO hO 18 0

theorem exec_copyCenterCoordsToSnStmt {d M_box rSnCenterO : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx dst : ℕ} {pt : EuclideanSpace ℝ (Fin d)}
    (hrO_ne23 : rSnCenterO ≠ 23)
    (hidx_reg : wRead mem 26 17 = (idx : ℤ))
    (hdst_reg : wRead mem 26 18 = (dst : ℤ))
    (hBox_dst : dst * d + d ≤ M_box)
    (hsrc : ∀ c : Fin d, rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord pt c) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (copyCenterCoordsToSnStmt d M_box rSnCenterO) mem m' (90 * (d + 1) + 40) ∧
      m'.popDepth 0 = m' ∧
      (∀ c : Fin d, rRead m' rSnCenterO (((dst * d + c.val : ℕ) : ℤ)) = euclideanCoord pt c) ∧
      (∀ i : ℤ, (i < ((dst * d : ℕ) : ℤ) ∨ ((dst * d + d : ℕ) : ℤ) ≤ i) →
        rRead m' rSnCenterO i = rRead mem rSnCenterO i) ∧
      (∀ t, t ≠ rSnCenterO → ∀ i, rRead m' t i = rRead mem t i) ∧
      (∀ t i, wRead m' t i = wRead mem t i) := by
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 29 18 (((idx * d : ℕ) : ℤ))
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 17)) (.lit (d : ℤ)))) m0 m1 8 := by
    refine DetExecAt.writeWordLocal 1 inp m0 29 _ _ rfl ?_ (by simp [intExprOps])
    simp only [iValAt_mul, iValAt_readHeap, iValAt_lit, m0, wRead_popDepth, hidx_reg]; push_cast; rfl
  rcases exec_loadHeapCoordsToLocalStmt inp m1 (rTag := 23) (idxBase := 18) (destOff := 0)
      (base := idx * d) (pt := pt) (by decide) (by simp [m1])
      (fun c => by simpa [m1, m0] using hsrc c)
    with ⟨m2, hs2, hloc2, hw2, hr2, _, _, _, _⟩
  let m3 := wWriteL 1 m2 29 18 (((dst * d : ℕ) : ℤ))
  have hs3 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 18)) (.lit (d : ℤ)))) m2 m3 8 := by
    refine DetExecAt.writeWordLocal 1 inp m2 29 _ _ rfl ?_ (by simp [intExprOps])
    simp only [iValAt_mul, iValAt_readHeap, iValAt_lit, hw2, m1, m0, wRead_wWriteL, wRead_popDepth, hdst_reg]
    push_cast; rfl
  rcases exec_storeLocalCoordsToHeapStmt inp m3 (M_box := M_box) (rTag := rSnCenterO) (idxBase := 18) (srcOff := 0)
      (base := dst * d) (pt := pt) (by decide) (by simp [m3]) hBox_dst
      (fun c => by simp [m3, Nat.zero_add]; simpa using hloc2 c)
    with ⟨m4, hs4, hr_dst4, hr_out4, hr_oth4, hw4, _, _, _, _⟩
  let m' := m4.popDepth 0
  have hex : DetExecAt 0 inp (copyCenterCoordsToSnStmt d M_box rSnCenterO) mem m' (90 * (d + 1) + 40) :=
    (DetExecAt.localScope (fd := 0) (hs1.seq (hs2.seq (hs3.seq hs4)))).mono_cost (by omega)
  have _ := hrO_ne23
  refine ⟨m', hex, popDepth_zero_idem m4,
    fun c => by simpa [m'] using hr_dst4 c,
    fun i hi => by simp [m', hr_out4 i hi, m3, hr2, m1, m0],
    fun t ht i => by simp [m', hr_oth4 t ht, m3, hr2, m1, m0],
    fun t i => by simp [m', hw4, m3, hw2, m1, m0]⟩

def swapOneJobLevelIterStmt (d D₀ M_box : ℕ) (cfg : ChainHdrCfg) : ArithRAMStmt :=
  seqList [
    .ite (.intLt (.readHeap 26 (.lit 16)) (.readHeap 19 (.readHeap 26 (.lit 15))))
      (seqList [
        boxWriteW M_box 26 (.lit 17)
          (.add (.mul (.readHeap 26 (.lit 15)) (.lit (D₀ : ℤ))) (.readHeap 26 (.lit 16))),
        boxWriteW M_box 26 (.lit 18)
          (.add (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 16))),
        cfg.snBirthCard.writeW M_box (.readHeap 26 (.lit 18))
          (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 0))),
        cfg.snAge.writeW M_box (.readHeap 26 (.lit 18))
          (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 7))),
        cfg.snAffected.writeW M_box (.readHeap 26 (.lit 18)) (.lit 0),
        boxWriteW M_box 14 (.readHeap 26 (.lit 18))
          (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 3))),
        boxWriteW M_box 15 (.readHeap 26 (.lit 18))
          (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 4))),
        boxWriteW M_box 16 (.readHeap 26 (.lit 18)) (.lit 0),
        cfg.rSnCenterV.writeR M_box (.readHeap 26 (.lit 18))
          (.readRealHeap 24 (.add (.mul (.lit 2) (.readHeap 26 (.lit 17))) (.lit 0))),
        copyCenterCoordsToSnStmt d M_box cfg.rSnCenterO
      ])
      .skip,
    boxWriteW M_box 26 (.lit 16) (.add (.readHeap 26 (.lit 16)) (.lit 1))
  ]

def deadlineSuffixSwapStmt (d D₀ M_box : ℕ) (cfg : ChainHdrCfg) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 26 (.lit 16) (.lit 0),
    .repeatN (.lit (D₀ : ℤ)) (swapOneJobLevelIterStmt d D₀ M_box cfg),
    boxWriteW M_box 26 (.lit 17)
      (.add (.mul (.readHeap 26 (.lit 15)) (.lit (D₀ : ℤ)))
            (.sub (.readHeap 19 (.readHeap 26 (.lit 15))) (.lit 1))),
    boxWriteW M_box 1 (.lit 6)
      (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 5))),
    boxWriteW M_box 1 (.lit 5)
      (.add (.readHeap 26 (.lit 15)) (.readHeap 19 (.readHeap 26 (.lit 15)))),
    .localScope .skip
  ]

theorem boxSafe_deadlineSuffixSwapStmt {T_max M_box : ℕ} {cfg : ChainHdrCfg}
    (hV : cfg.Valid T_max) (d D₀ : ℕ) :
    BoxSafeOuter T_max M_box (deadlineSuffixSwapStmt d D₀ M_box cfg) := by
  have hT28 := hV.1
  unfold deadlineSuffixSwapStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · refine .repeatN _ (boxSafeOuter_seqList ?_)
    intro s1 hs1; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs1
    rcases hs1 with rfl | rfl
    · refine .ite _ (boxSafeOuter_seqList ?_) .skip
      intro s2 hs2; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs2
      rcases hs2 with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
      · exact .boxW (by omega) _ _
      · exact .boxW (by omega) _ _
      · exact boxSafe_hdrWriteW hV.2.1.1 _ _
      · exact boxSafe_hdrWriteW hV.2.2.1.1 _ _
      · exact boxSafe_hdrWriteW hV.2.2.2.1.1 _ _
      · exact .boxW (by omega) _ _
      · exact .boxW (by omega) _ _
      · exact .boxW (by omega) _ _
      · exact boxSafe_hdrWriteR hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1.1 _ _
      · exact boxSafe_copyCenterCoordsToSnStmt d cfg.rSnCenterO
          hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
    · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .localScope .skip

def deadlineSuffixSwapCost (d D₀ : ℕ) : ℕ :=
  D₀ * (90 * (d + 1) + 400) + 200

private lemma not_reserved_word_ne {t : ℕ} (h : t ∉ reservedWordTags) :
    t ≠ 0 ∧ t ≠ 1 ∧ t ≠ 2 ∧ t ≠ 3 ∧ t ≠ 5 ∧ t ≠ 6 ∧ t ≠ 7 ∧ t ≠ 8 ∧ t ≠ 9 ∧
    t ≠ 10 ∧ t ≠ 11 ∧ t ≠ 14 ∧ t ≠ 15 ∧ t ≠ 16 ∧ t ≠ 19 ∧ t ≠ 23 ∧ t ≠ 24 ∧ t ≠ 26 := by
  unfold reservedWordTags at h
  simp only [Finset.mem_insert, Finset.mem_singleton, not_or] at h
  exact h

private lemma not_reserved_real_ne {t : ℕ} (h : t ∉ reservedRealTags) :
    t ≠ 0 ∧ t ≠ 4 ∧ t ≠ 8 ∧ t ≠ 11 ∧ t ≠ 23 ∧ t ≠ 24 ∧ t ≠ 26 ∧ t ≠ 27 := by
  unfold reservedRealTags at h
  simp only [Finset.mem_insert, Finset.mem_singleton, not_or] at h
  exact h

theorem exec_deadlineSuffixSwapStmt {d D₀ T_max M_box : ℕ} {cfg : ChainHdrCfg}
    (hV : cfg.Valid T_max)
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {r jLen : ℕ}
    (lvs : List (JobLvData d)) (D : ℕ)
    (hjLen_eq : lvs.length = jLen)
    (hjLen_pos : 1 ≤ jLen)
    (hr_add_le : r + jLen ≤ D₀)
    (hBox26 : 30 ≤ M_box)
    (hBox_hdr : cfg.maxStride * D₀ ≤ M_box)
    (hBox_snO : D₀ * d ≤ M_box)
    (hr_reg : wRead mem 26 15 = (r : ℤ))
    (hjLen_reg : wRead mem 19 (r : ℤ) = (jLen : ℤ))
    (hlv_hdr : ∀ (j : ℕ) (hj : j < lvs.length),
      let idx := r * D₀ + j
      let ball := (lvs[j]'hj).ball D
      wRead mem 23 (((8 * idx + 0 : ℕ) : ℤ)) = ((lvs[j]'hj).S_birth.card : ℤ) ∧
      wRead mem 23 (((8 * idx + 7 : ℕ) : ℤ)) = ((lvs[j]'hj).openRem : ℤ) ∧
      rRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V ∧
      (∀ c : Fin d, rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord ball.o c)) :
    let lastIdx := r * D₀ + (jLen - 1)
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (deadlineSuffixSwapStmt d D₀ M_box cfg) mem m'
        (deadlineSuffixSwapCost d D₀) ∧
      m'.popDepth 0 = m' ∧
      wRead m' 1 5 = (((r + jLen : ℕ) : ℤ)) ∧
      wRead m' 1 6 = wRead mem 23 (((8 * lastIdx + 5 : ℕ) : ℤ)) ∧
      (∀ (j : ℕ) (hj : j < lvs.length),
        let idx := r * D₀ + j
        let dst := r + j
        let ball := (lvs[j]'hj).ball D
        wRead m' cfg.snBirthCard.tag (cfg.snBirthCard.idx dst : ℤ) = ((lvs[j]'hj).S_birth.card : ℤ) ∧
        wRead m' cfg.snAge.tag (cfg.snAge.idx dst : ℤ) = ((lvs[j]'hj).openRem : ℤ) ∧
        wRead m' cfg.snAffected.tag (cfg.snAffected.idx dst : ℤ) = 0 ∧
        wRead m' 14 (dst : ℤ) = wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ)) ∧
        wRead m' 15 (dst : ℤ) = wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ)) ∧
        wRead m' 16 (dst : ℤ) = 0 ∧
        rRead m' cfg.rSnCenterV.tag (cfg.rSnCenterV.idx dst : ℤ) = ball.V ∧
        (∀ c : Fin d, rRead m' cfg.rSnCenterO (((dst * d + c.val : ℕ) : ℤ)) = euclideanCoord ball.o c)) ∧
      (∀ i < r,
        wRead m' cfg.snBirthCard.tag (cfg.snBirthCard.idx i : ℤ) =
          wRead mem cfg.snBirthCard.tag (cfg.snBirthCard.idx i : ℤ) ∧
        wRead m' cfg.snAge.tag (cfg.snAge.idx i : ℤ) =
          wRead mem cfg.snAge.tag (cfg.snAge.idx i : ℤ) ∧
        wRead m' cfg.snAffected.tag (cfg.snAffected.idx i : ℤ) =
          wRead mem cfg.snAffected.tag (cfg.snAffected.idx i : ℤ) ∧
        wRead m' 14 (i : ℤ) = wRead mem 14 (i : ℤ) ∧
        wRead m' 15 (i : ℤ) = wRead mem 15 (i : ℤ) ∧
        wRead m' 16 (i : ℤ) = wRead mem 16 (i : ℤ) ∧
        rRead m' cfg.rSnCenterV.tag (cfg.rSnCenterV.idx i : ℤ) =
          rRead mem cfg.rSnCenterV.tag (cfg.rSnCenterV.idx i : ℤ) ∧
        (∀ c : Fin d,
          rRead m' cfg.rSnCenterO (((i * d + c.val : ℕ) : ℤ)) =
            rRead mem cfg.rSnCenterO (((i * d + c.val : ℕ) : ℤ)))) ∧
      (∀ t, t ≠ 1 → t ≠ 14 → t ≠ 15 → t ≠ 16 → t ≠ 26 →
            t ≠ cfg.snBirthCard.tag → t ≠ cfg.snAge.tag → t ≠ cfg.snAffected.tag →
        ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 5 → i ≠ 6 → wRead m' 1 i = wRead mem 1 i) ∧
      (∀ i, i ≠ 16 → i ≠ 17 → i ≠ 18 → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t, t ≠ cfg.rSnCenterO → t ≠ cfg.rSnCenterV.tag →
        ∀ i, rRead m' t i = rRead mem t i) := by
  intro lastIdx
  rcases hV with ⟨_, hwf_bc, hwf_age, hwf_aff, _, _,
    hnr_bc, hnr_age, hnr_aff, _, _,
    hd_bc_age, hd_bc_aff, _, _, hd_age_aff, _, _, _, _, _,
    _, hwf_rV, hne_O_V, hnr_O, hnr_V⟩
  have hbc_ne := not_reserved_word_ne hnr_bc
  have hage_ne := not_reserved_word_ne hnr_age
  have haff_ne := not_reserved_word_ne hnr_aff
  have hrO_ne := not_reserved_real_ne hnr_O
  have hrV_ne := not_reserved_real_ne hnr_V
  have hbc_1 := hbc_ne.2.1; have hbc_14 := hbc_ne.2.2.2.2.2.2.2.2.2.2.2.1
  have hbc_15 := hbc_ne.2.2.2.2.2.2.2.2.2.2.2.2.1; have hbc_16 := hbc_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hbc_19 := hbc_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1; have hbc_23 := hbc_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hbc_26 := hbc_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2
  have hage_1 := hage_ne.2.1; have hage_14 := hage_ne.2.2.2.2.2.2.2.2.2.2.2.1
  have hage_15 := hage_ne.2.2.2.2.2.2.2.2.2.2.2.2.1; have hage_16 := hage_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hage_19 := hage_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1; have hage_23 := hage_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hage_26 := hage_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2
  have haff_1 := haff_ne.2.1; have haff_14 := haff_ne.2.2.2.2.2.2.2.2.2.2.2.1
  have haff_15 := haff_ne.2.2.2.2.2.2.2.2.2.2.2.2.1; have haff_16 := haff_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have haff_19 := haff_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1; have haff_23 := haff_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have haff_26 := haff_ne.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2
  have h_hdr_lt : ∀ dst < D₀,
      cfg.snBirthCard.idx dst < M_box ∧ cfg.snAge.idx dst < M_box ∧
      cfg.snAffected.idx dst < M_box ∧ cfg.rSnCenterV.idx dst < M_box := by
    intro dst hdst
    have hle_m : ∀ (f : HdrField), f.WF T_max → f.stride ≤ cfg.maxStride → f.idx dst < M_box := by
      intro f hwf hst
      unfold HdrField.idx
      calc f.stride * dst + f.off < f.stride * dst + f.stride := Nat.add_lt_add_left hwf.2.2 _
        _ = f.stride * (dst + 1) := by ring
        _ ≤ cfg.maxStride * D₀ := Nat.mul_le_mul hst (Nat.succ_le_of_lt hdst)
        _ ≤ M_box := hBox_hdr
    have s1 : cfg.snBirthCard.stride ≤ cfg.maxStride := le_max_left _ _
    have s2 : cfg.snAge.stride ≤ cfg.maxStride := le_trans (le_max_left _ _) (le_max_right _ _)
    have s3 : cfg.snAffected.stride ≤ cfg.maxStride :=
      le_trans (le_max_left _ _) (le_trans (le_max_right _ _) (le_max_right _ _))
    have s6 : cfg.rSnCenterV.stride ≤ cfg.maxStride :=
      le_trans (le_max_right _ _) (le_trans (le_max_right _ _)
        (le_trans (le_max_right _ _) (le_trans (le_max_right _ _) (le_max_right _ _))))
    exact ⟨hle_m _ hwf_bc s1, hle_m _ hwf_age s2, hle_m _ hwf_aff s3, hle_m _ hwf_rV s6⟩
  let m0 := wWrite mem 26 16 0
  have hd0 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 16) (.lit 0)) mem m0 14 :=
    exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    wRead m 26 16 = (k : ℤ) ∧
    (∀ (j : ℕ) (hj : j < lvs.length), j < k →
      let idx := r * D₀ + j
      let dst := r + j
      let ball := (lvs[j]'hj).ball D
      wRead m cfg.snBirthCard.tag (cfg.snBirthCard.idx dst : ℤ) = ((lvs[j]'hj).S_birth.card : ℤ) ∧
      wRead m cfg.snAge.tag (cfg.snAge.idx dst : ℤ) = ((lvs[j]'hj).openRem : ℤ) ∧
      wRead m cfg.snAffected.tag (cfg.snAffected.idx dst : ℤ) = 0 ∧
      wRead m 14 (dst : ℤ) = wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ)) ∧
      wRead m 15 (dst : ℤ) = wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ)) ∧
      wRead m 16 (dst : ℤ) = 0 ∧
      rRead m cfg.rSnCenterV.tag (cfg.rSnCenterV.idx dst : ℤ) = ball.V ∧
      (∀ c : Fin d, rRead m cfg.rSnCenterO (((dst * d + c.val : ℕ) : ℤ)) = euclideanCoord ball.o c)) ∧
    (∀ i < r,
      wRead m cfg.snBirthCard.tag (cfg.snBirthCard.idx i : ℤ) =
        wRead mem cfg.snBirthCard.tag (cfg.snBirthCard.idx i : ℤ) ∧
      wRead m cfg.snAge.tag (cfg.snAge.idx i : ℤ) =
        wRead mem cfg.snAge.tag (cfg.snAge.idx i : ℤ) ∧
      wRead m cfg.snAffected.tag (cfg.snAffected.idx i : ℤ) =
        wRead mem cfg.snAffected.tag (cfg.snAffected.idx i : ℤ) ∧
      wRead m 14 (i : ℤ) = wRead mem 14 (i : ℤ) ∧
      wRead m 15 (i : ℤ) = wRead mem 15 (i : ℤ) ∧
      wRead m 16 (i : ℤ) = wRead mem 16 (i : ℤ) ∧
      rRead m cfg.rSnCenterV.tag (cfg.rSnCenterV.idx i : ℤ) =
        rRead mem cfg.rSnCenterV.tag (cfg.rSnCenterV.idx i : ℤ) ∧
      (∀ c : Fin d,
        rRead m cfg.rSnCenterO (((i * d + c.val : ℕ) : ℤ)) =
          rRead mem cfg.rSnCenterO (((i * d + c.val : ℕ) : ℤ)))) ∧
    (∀ t, t ≠ 14 → t ≠ 15 → t ≠ 16 → t ≠ 26 →
          t ≠ cfg.snBirthCard.tag → t ≠ cfg.snAge.tag → t ≠ cfg.snAffected.tag →
      ∀ i, wRead m t i = wRead mem t i) ∧
    (∀ i, i ≠ 16 → i ≠ 17 → i ≠ 18 → wRead m 26 i = wRead mem 26 i) ∧
    (∀ t, t ≠ cfg.rSnCenterO → t ≠ cfg.rSnCenterV.tag →
      ∀ i, rRead m t i = rRead mem t i)
  have hInv0 : Inv 0 m0 := by
    refine ⟨by simp [m0], fun _ _ h => by omega, ?_, ?_, ?_, ?_⟩
    · intro i _
      refine ⟨by simp [m0, hbc_26],
              by simp [m0, hage_26],
              by simp [m0, haff_26],
              by simp [m0], by simp [m0], by simp [m0], by simp [m0], fun _ => by simp [m0]⟩
    · intro t _ _ _ h26 _ _ _ i; simp [m0, h26]
    · intro i h16 _ _; simp [m0, h16]
    · intro _ _ _ _; simp [m0]
  have hStep : ∀ k < D₀, ∀ m, Inv k m →
      ∃ m', DetExecAt 0 inp (swapOneJobLevelIterStmt d D₀ M_box cfg) m m'
        (90 * (d + 1) + 400) ∧ Inv (k + 1) m' := by
    intro k _ m ⟨hw16_m, hDone_m, hPre_m, hwo_m, hw26_m, hro_m⟩
    have hw15_m : wRead m 26 15 = (r : ℤ) := by
      rw [hw26_m 15 (by decide) (by decide) (by decide), hr_reg]
    have hw19_m : wRead m 19 (r : ℤ) = (jLen : ℤ) := by
      rw [hwo_m 19 (by decide) (by decide) (by decide) (by decide)
          hbc_19.symm
          hage_19.symm
          haff_19.symm, hjLen_reg]
    have hw23_eq : ∀ s : ArithRAMMemory, (∀ t, t ≠ 14 → t ≠ 15 → t ≠ 16 → t ≠ 26 →
        t ≠ cfg.snBirthCard.tag → t ≠ cfg.snAge.tag → t ≠ cfg.snAffected.tag → ∀ i, wRead s t i = wRead mem t i) →
        ∀ i, wRead s 23 i = wRead mem 23 i := by
      intro s hs i
      exact hs 23 (by decide) (by decide) (by decide) (by decide)
        hbc_23.symm
        hage_23.symm
        haff_23.symm i
    by_cases hk_lt : k < jLen
    · have hk_len : k < lvs.length := hjLen_eq ▸ hk_lt
      have hcond : cValAt 0 inp m (.intLt (.readHeap 26 (.lit 16)) (.readHeap 19 (.readHeap 26 (.lit 15)))) = true := by
        simp [hw16_m, hw15_m, hw19_m, hk_lt]
      let idx := r * D₀ + k
      let dst := r + k
      have hdst_D0 : dst < D₀ := by dsimp [dst]; omega
      rcases h_hdr_lt dst hdst_D0 with ⟨hbc_box, hage_box, haff_box, hrV_box⟩
      rcases hlv_hdr k hk_len with ⟨hlv_0, hlv_7, hlv_V, hlv_o⟩
      let s1 := wWrite m 26 17 (idx : ℤ)
      let s2 := wWrite s1 26 18 (dst : ℤ)
      have e1 : DetExecAt 0 inp
          (boxWriteW M_box 26 (.lit 17)
            (.add (.mul (.readHeap 26 (.lit 15)) (.lit (D₀ : ℤ))) (.readHeap 26 (.lit 16)))) m s1 24 := by
        refine exec_boxWriteW inp m _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
        simp only [iValAt_add, iValAt_mul, iValAt_readHeap, iValAt_lit, hw15_m, hw16_m, idx]; push_cast; rfl
      have e2 : DetExecAt 0 inp
          (boxWriteW M_box 26 (.lit 18) (.add (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 16)))) s1 s2 20 := by
        refine exec_boxWriteW inp s1 _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
        simp only [iValAt_add, iValAt_readHeap, iValAt_lit]
        dsimp only [s1, dst]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw15_m, hw16_m]
        push_cast; rfl
      have hs2_17 : wRead s2 26 17 = (idx : ℤ) := by simp [s2, s1]
      have hs2_18 : wRead s2 26 18 = (dst : ℤ) := by simp [s2]
      have hs2_23 : ∀ i, wRead s2 23 i = wRead mem 23 i := fun i => by
        dsimp only [s2, s1]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        exact hw23_eq m hwo_m i
      let s3 := wWrite s2 cfg.snBirthCard.tag (cfg.snBirthCard.idx dst : ℤ) ((lvs[k]'hk_len).S_birth.card : ℤ)
      have e3 : DetExecAt 0 inp
          (cfg.snBirthCard.writeW M_box (.readHeap 26 (.lit 18))
            (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 0)))) s2 s3 45 := by
        refine exec_hdrWriteW inp s2 cfg.snBirthCard _ _ (by simp [hs2_18]) hbc_box ?_ (by simp [intExprOps])
        simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, hs2_17]
        have h8 : (8 : ℤ) * (idx : ℤ) + 0 = ((8 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
        rw [h8, hs2_23]; exact hlv_0
      let s4 := wWrite s3 cfg.snAge.tag (cfg.snAge.idx dst : ℤ) ((lvs[k]'hk_len).openRem : ℤ)
      have e4 : DetExecAt 0 inp
          (cfg.snAge.writeW M_box (.readHeap 26 (.lit 18))
            (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 7)))) s3 s4 45 := by
        refine exec_hdrWriteW inp s3 cfg.snAge _ _
          (by rw [iValAt_readHeap, iValAt_lit]; dsimp only [s3]; rw [wRead_wWrite_of_ne _ _ (Or.inl hbc_26.symm), hs2_18])
          hage_box ?_ (by simp [intExprOps])
        have h17 : wRead s3 26 17 = (idx : ℤ) := by
          dsimp only [s3]; rw [wRead_wWrite_of_ne _ _ (Or.inl hbc_26.symm), hs2_17]
        simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, h17]
        have h8 : (8 : ℤ) * (idx : ℤ) + 7 = ((8 * idx + 7 : ℕ) : ℤ) := by push_cast; ring
        rw [h8]; dsimp only [s3]
        rw [wRead_wWrite_of_ne _ _ (Or.inl hbc_23.symm), hs2_23]; exact hlv_7
      let s5 := wWrite s4 cfg.snAffected.tag (cfg.snAffected.idx dst : ℤ) 0
      have e5 : DetExecAt 0 inp (cfg.snAffected.writeW M_box (.readHeap 26 (.lit 18)) (.lit 0)) s4 s5 35 := by
        refine exec_hdrWriteW inp s4 cfg.snAffected _ _ ?_ haff_box rfl (by simp [intExprOps])
        rw [iValAt_readHeap, iValAt_lit]; dsimp only [s4, s3]
        rw [wRead_wWrite_of_ne _ _ (Or.inl hage_26.symm),
            wRead_wWrite_of_ne _ _ (Or.inl hbc_26.symm), hs2_18]
      have hs5_26 : ∀ i, wRead s5 26 i = wRead s2 26 i := fun i => by
        dsimp only [s5, s4, s3]
        rw [wRead_wWrite_of_ne _ _ (Or.inl haff_26.symm),
            wRead_wWrite_of_ne _ _ (Or.inl hage_26.symm),
            wRead_wWrite_of_ne _ _ (Or.inl hbc_26.symm)]
      have hs5_23 : ∀ i, wRead s5 23 i = wRead mem 23 i := fun i => by
        dsimp only [s5, s4, s3]
        rw [wRead_wWrite_of_ne _ _ (Or.inl haff_23.symm),
            wRead_wWrite_of_ne _ _ (Or.inl hage_23.symm),
            wRead_wWrite_of_ne _ _ (Or.inl hbc_23.symm)]
        exact hs2_23 i
      let s6 := wWrite s5 14 (dst : ℤ) (wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ)))
      let s7 := wWrite s6 15 (dst : ℤ) (wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ)))
      let s8 := wWrite s7 16 (dst : ℤ) 0
      have hdst_box : (dst : ℤ) < (M_box : ℤ) := by
        have h1 : 1 ≤ cfg.snBirthCard.stride := hwf_bc.2.1
        have h2 : cfg.snBirthCard.stride ≤ cfg.maxStride := le_max_left _ _
        have : dst < M_box := lt_of_lt_of_le hdst_D0 (by nlinarith)
        exact_mod_cast this
      have e6 : DetExecAt 0 inp
          (boxWriteW M_box 14 (.readHeap 26 (.lit 18))
            (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 3)))) s5 s6 30 := by
        refine exec_boxWriteW inp s5 _ _ (by simp [hs5_26, s2]) (by omega) hdst_box ?_ (by simp [intExprOps])
        simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, hs5_26, hs2_17, hs5_23]
        have h8 : (8 : ℤ) * (idx : ℤ) + 3 = ((8 * idx + 3 : ℕ) : ℤ) := by push_cast; ring
        rw [h8]
      have e7 : DetExecAt 0 inp
          (boxWriteW M_box 15 (.readHeap 26 (.lit 18))
            (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 4)))) s6 s7 30 := by
        refine exec_boxWriteW inp s6 _ _
          (by rw [iValAt_readHeap, iValAt_lit]; dsimp only [s6]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hs5_26, hs2_18])
          (by omega) hdst_box ?_ (by simp [intExprOps])
        have hs6_17 : wRead s6 26 17 = (idx : ℤ) := by
          dsimp only [s6]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hs5_26, hs2_17]
        simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, hs6_17]
        dsimp only [s6]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hs5_23]
        have h8 : (8 : ℤ) * (idx : ℤ) + 4 = ((8 * idx + 4 : ℕ) : ℤ) := by push_cast; ring
        rw [h8]
      have e8 : DetExecAt 0 inp (boxWriteW M_box 16 (.readHeap 26 (.lit 18)) (.lit 0)) s7 s8 20 := by
        refine exec_boxWriteW inp s7 _ _ ?_ (by omega) hdst_box rfl (by simp [intExprOps])
        dsimp only [s7, s6]
        simp [hs5_26, s2]
      have hs8_26 : ∀ i, wRead s8 26 i = wRead s2 26 i := fun i => by
        dsimp only [s8, s7, s6]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        exact hs5_26 i
      have hs8_r : ∀ t i, rRead s8 t i = rRead m t i := fun t i => by
        dsimp only [s8, s7, s6, s5, s4, s3, s2, s1]
        repeat rw [rRead_wWrite]
      let ball_k := (lvs[k]'hk_len).ball D
      let s9 := rWrite s8 cfg.rSnCenterV.tag (cfg.rSnCenterV.idx dst : ℤ) ball_k.V
      have e9 : DetExecAt 0 inp
          (cfg.rSnCenterV.writeR M_box (.readHeap 26 (.lit 18))
            (.readRealHeap 24 (.add (.mul (.lit 2) (.readHeap 26 (.lit 17))) (.lit 0)))) s8 s9 40 := by
        refine exec_hdrWriteR inp s8 cfg.rSnCenterV _ _
          (by rw [iValAt_readHeap, iValAt_lit, hs8_26]; simp [s2]) hrV_box ?_ (by simp [intExprOps, realExprOps])
        simp only [rValAt_readRealHeap, iValAt_add, iValAt_mul, iValAt_readHeap, iValAt_lit,
          hs8_26, hs2_17, hs8_r, hro_m 24 hrO_ne.2.2.2.2.2.1.symm hrV_ne.2.2.2.2.2.1.symm]
        have h2 : (2 : ℤ) * (idx : ℤ) + 0 = ((2 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
        rw [h2]; exact hlv_V
      have hBox_dst_d : dst * d + d ≤ M_box := by
        calc dst * d + d = (dst + 1) * d := by ring
          _ ≤ D₀ * d := Nat.mul_le_mul_right d hdst_D0
          _ ≤ M_box := hBox_snO
      rcases exec_copyCenterCoordsToSnStmt (M_box := M_box) (idx := idx) (dst := dst) inp s9 hrO_ne.2.2.2.2.1
          (by dsimp only [s9]; rw [wRead_rWrite, hs8_26, hs2_17])
          (by dsimp only [s9]; rw [wRead_rWrite, hs8_26, hs2_18])
          hBox_dst_d
          (fun c => by
            dsimp only [s9]
            rw [rRead_rWrite_of_ne _ _ (Or.inl hrV_ne.2.2.2.2.1.symm), hs8_r,
                hro_m 23 hrO_ne.2.2.2.2.1.symm hrV_ne.2.2.2.2.1.symm]
            exact hlv_o c)
        with ⟨s10, e10, _, hrO_dst10, hrO_out10, hr_oth10, hw_10⟩
      let s11 := wWrite s10 26 16 (((k + 1 : ℕ) : ℤ))
      have e11 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 16) (.add (.readHeap 26 (.lit 16)) (.lit 1))) s10 s11 20 := by
        refine exec_boxWriteW inp s10 _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
        have h16 : wRead s10 26 16 = (k : ℤ) := by
          rw [hw_10]; dsimp only [s9]; rw [wRead_rWrite, hs8_26]; dsimp only [s2, s1]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw16_m]
        simp [h16]
      have hd_iter : DetExecAt 0 inp (swapOneJobLevelIterStmt d D₀ M_box cfg) m s11 (90 * (d + 1) + 400) := by
        unfold swapOneJobLevelIterStmt seqList
        exact ((DetExecAt.ite_true hcond (C_c := 15) (by simp [condExprOps, intExprOps])
          (e1.seq (e2.seq (e3.seq (e4.seq (e5.seq (e6.seq (e7.seq (e8.seq (e9.seq e10)))))))))).seq e11).mono_cost
          (by omega)
      -- Helper to read word table ≠ 26 from s11 -> s8
      have hw_s11_s8 : ∀ t, t ≠ 26 → ∀ i, wRead s11 t i = wRead s8 t i := fun t ht i => by
        dsimp only [s11]; rw [wRead_wWrite_of_ne _ _ (Or.inl ht), hw_10]; simp [s9]
      have hs8_s5 : ∀ t, t ≠ 14 → t ≠ 15 → t ≠ 16 → ∀ i, wRead s8 t i = wRead s5 t i := fun t h14 h15 h16 i => by
        dsimp only [s8, s7, s6]
        rw [wRead_wWrite_of_ne _ _ (Or.inl h16), wRead_wWrite_of_ne _ _ (Or.inl h15),
            wRead_wWrite_of_ne _ _ (Or.inl h14)]
      have h_pres_lt : ∀ u < dst,
          wRead s11 cfg.snBirthCard.tag (cfg.snBirthCard.idx u : ℤ) =
            wRead m cfg.snBirthCard.tag (cfg.snBirthCard.idx u : ℤ) ∧
          wRead s11 cfg.snAge.tag (cfg.snAge.idx u : ℤ) =
            wRead m cfg.snAge.tag (cfg.snAge.idx u : ℤ) ∧
          wRead s11 cfg.snAffected.tag (cfg.snAffected.idx u : ℤ) =
            wRead m cfg.snAffected.tag (cfg.snAffected.idx u : ℤ) ∧
          wRead s11 14 (u : ℤ) = wRead m 14 (u : ℤ) ∧
          wRead s11 15 (u : ℤ) = wRead m 15 (u : ℤ) ∧
          wRead s11 16 (u : ℤ) = wRead m 16 (u : ℤ) ∧
          rRead s11 cfg.rSnCenterV.tag (cfg.rSnCenterV.idx u : ℤ) =
            rRead m cfg.rSnCenterV.tag (cfg.rSnCenterV.idx u : ℤ) ∧
          (∀ c : Fin d,
            rRead s11 cfg.rSnCenterO (((u * d + c.val : ℕ) : ℤ)) =
              rRead m cfg.rSnCenterO (((u * d + c.val : ℕ) : ℤ))) := by
        intro u hu_lt
        have hu_ne : u ≠ dst := by omega
        refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
        · rw [hw_s11_s8 _ hbc_26, hs8_s5 _ hbc_14 hbc_15 hbc_16]; dsimp only [s5, s4, s3, s2, s1]
          rw [wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf_bc hwf_aff hd_bc_aff u dst),
              wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf_bc hwf_age hd_bc_age u dst),
              wRead_wWrite_of_ne _ _ (Or.inr (HdrField.ne_same_field hwf_bc hu_ne)),
              wRead_wWrite_of_ne _ _ (Or.inl hbc_26), wRead_wWrite_of_ne _ _ (Or.inl hbc_26)]
        · rw [hw_s11_s8 _ hage_26, hs8_s5 _ hage_14 hage_15 hage_16]; dsimp only [s5, s4, s3, s2, s1]
          rw [wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf_age hwf_aff hd_age_aff u dst),
              wRead_wWrite_of_ne _ _ (Or.inr (HdrField.ne_same_field hwf_age hu_ne)),
              wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf_age hwf_bc hd_bc_age.symm u dst),
              wRead_wWrite_of_ne _ _ (Or.inl hage_26), wRead_wWrite_of_ne _ _ (Or.inl hage_26)]
        · rw [hw_s11_s8 _ haff_26, hs8_s5 _ haff_14 haff_15 haff_16]; dsimp only [s5, s4, s3, s2, s1]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (HdrField.ne_same_field hwf_aff hu_ne)),
              wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf_aff hwf_age hd_age_aff.symm u dst),
              wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf_aff hwf_bc hd_bc_aff.symm u dst),
              wRead_wWrite_of_ne _ _ (Or.inl haff_26), wRead_wWrite_of_ne _ _ (Or.inl haff_26)]
        · rw [hw_s11_s8 14 (by decide)]; dsimp only [s8, s7, s6, s5, s4, s3, s2, s1]
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hu_ne)),
              wRead_wWrite_of_ne _ _ (Or.inl haff_14.symm), wRead_wWrite_of_ne _ _ (Or.inl hage_14.symm),
              wRead_wWrite_of_ne _ _ (Or.inl hbc_14.symm),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        · rw [hw_s11_s8 15 (by decide)]; dsimp only [s8, s7, s6, s5, s4, s3, s2, s1]
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hu_ne)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inl haff_15.symm), wRead_wWrite_of_ne _ _ (Or.inl hage_15.symm),
              wRead_wWrite_of_ne _ _ (Or.inl hbc_15.symm),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        · rw [hw_s11_s8 16 (by decide)]; dsimp only [s8, s7, s6, s5, s4, s3, s2, s1]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hu_ne)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inl haff_16.symm), wRead_wWrite_of_ne _ _ (Or.inl hage_16.symm),
              wRead_wWrite_of_ne _ _ (Or.inl hbc_16.symm),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        · dsimp only [s11]; rw [rRead_wWrite, hr_oth10 _ hne_O_V.symm]
          dsimp only [s9]; rw [rRead_rWrite_of_ne _ _ (Or.inr (HdrField.ne_same_field hwf_rV hu_ne)), hs8_r]
        · intro c; dsimp only [s11]; rw [rRead_wWrite, hrO_out10]
          · dsimp only [s9]; rw [rRead_rWrite_of_ne _ _ (Or.inl hne_O_V), hs8_r]
          · left
            have hle : u * d + c.val < dst * d := by
              calc u * d + c.val < u * d + d := Nat.add_lt_add_left c.isLt _
                _ = (u + 1) * d := by ring
                _ ≤ dst * d := Nat.mul_le_mul_right d hu_lt
            exact_mod_cast hle
      refine ⟨s11, hd_iter, by simp [s11], ?_, ?_, ?_, ?_, ?_⟩
      · intro j hj hj_lt_k1
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hj_lt_k1) with hj_lt_k | rfl
        · rcases hDone_m j hj hj_lt_k with ⟨hb_j, ha_j, hf_j, h14_j, h15_j, h16_j, hV_j, ho_j⟩
          rcases h_pres_lt (r + j) (by dsimp [dst]; omega) with ⟨e1, e2, e3, e4, e5, e6, e7, e8⟩
          exact ⟨e1.trans hb_j, e2.trans ha_j, e3.trans hf_j, e4.trans h14_j, e5.trans h15_j,
            e6.trans h16_j, e7.trans hV_j, fun c => (e8 c).trans (ho_j c)⟩
        · -- Case j = k
          refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
          · rw [hw_s11_s8 _ hbc_26,
                hs8_s5 _ hbc_14 hbc_15 hbc_16]
            dsimp only [s5, s4, s3]
            rw [wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf_bc hwf_aff hd_bc_aff dst dst),
                wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf_bc hwf_age hd_bc_age dst dst)]
            exact wRead_wWrite_self _ _ _ _
          · rw [hw_s11_s8 _ hage_26,
                hs8_s5 _ hage_14 hage_15 hage_16]
            dsimp only [s5, s4]
            rw [wRead_wWrite_of_ne _ _ (HdrField.ne_cell hwf_age hwf_aff hd_age_aff dst dst)]
            exact wRead_wWrite_self _ _ _ _
          · rw [hw_s11_s8 _ haff_26,
                hs8_s5 _ haff_14 haff_15 haff_16]
            exact wRead_wWrite_self _ _ _ _
          · rw [hw_s11_s8 14 (by decide)]; dsimp only [s8, s7, s6]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
            exact wRead_wWrite_self _ _ _ _
          · rw [hw_s11_s8 15 (by decide)]; dsimp only [s8, s7]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
            exact wRead_wWrite_self _ _ _ _
          · rw [hw_s11_s8 16 (by decide)]; exact wRead_wWrite_self _ _ _ _
          · dsimp only [s11]; rw [rRead_wWrite, hr_oth10 _ hne_O_V.symm]; exact rRead_rWrite_self _ _ _ _
          · intro c; dsimp only [s11]; rw [rRead_wWrite]; exact hrO_dst10 c
      · intro i hi_lt_r
        rcases hPre_m i hi_lt_r with ⟨hb_i, ha_i, hf_i, h14_i, h15_i, h16_i, hV_i, ho_i⟩
        rcases h_pres_lt i (by dsimp [dst]; omega) with ⟨e1, e2, e3, e4, e5, e6, e7, e8⟩
        exact ⟨e1.trans hb_i, e2.trans ha_i, e3.trans hf_i, e4.trans h14_i, e5.trans h15_i,
          e6.trans h16_i, e7.trans hV_i, fun c => (e8 c).trans (ho_i c)⟩
      · intro t h14 h15 h16 h26 hbc hage haff i
        rw [hw_s11_s8 t h26, hs8_s5 t h14 h15 h16]; dsimp only [s5, s4, s3, s2, s1]
        rw [wRead_wWrite_of_ne _ _ (Or.inl haff),
            wRead_wWrite_of_ne _ _ (Or.inl hage),
            wRead_wWrite_of_ne _ _ (Or.inl hbc),
            wRead_wWrite_of_ne _ _ (Or.inl h26),
            wRead_wWrite_of_ne _ _ (Or.inl h26)]
        exact hwo_m t h14 h15 h16 h26 hbc hage haff i
      · intro i h16 h17 h18
        dsimp only [s11]
        rw [wRead_wWrite_of_ne _ _ (Or.inr h16), hw_10]; dsimp only [s9]
        rw [wRead_rWrite, hs8_26]; dsimp only [s2, s1]
        rw [wRead_wWrite_of_ne _ _ (Or.inr h18), wRead_wWrite_of_ne _ _ (Or.inr h17)]
        exact hw26_m i h16 h17 h18
      · intro t hO hVt i
        dsimp only [s11]; rw [rRead_wWrite, hr_oth10 t hO]; dsimp only [s9]
        rw [rRead_rWrite_of_ne _ _ (Or.inl hVt), hs8_r]
        exact hro_m t hO hVt i
    · have hcond : cValAt 0 inp m (.intLt (.readHeap 26 (.lit 16)) (.readHeap 19 (.readHeap 26 (.lit 15)))) = false := by
        simp [hw16_m, hw15_m, hw19_m]; omega
      let s11 := wWrite m 26 16 (((k + 1 : ℕ) : ℤ))
      have e11 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 16) (.add (.readHeap 26 (.lit 16)) (.lit 1))) m s11 20 :=
        exec_boxWriteW inp m _ _ rfl (by omega) (by omega) (by simp [hw16_m]) (by simp [intExprOps])
      have hd_iter : DetExecAt 0 inp (swapOneJobLevelIterStmt d D₀ M_box cfg) m s11 (90 * (d + 1) + 400) := by
        unfold swapOneJobLevelIterStmt seqList
        exact ((DetExecAt.ite_false hcond (C_c := 15) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp m)).seq e11).mono_cost (by omega)
      refine ⟨s11, hd_iter, by simp [s11], ?_, ?_,
        fun t h14 h15 h16 h26 hbc hage haff i => by simp [s11, h26, hwo_m t h14 h15 h16 h26 hbc hage haff i],
        fun i h16 h17 h18 => by simp [s11, h16, hw26_m i h16 h17 h18],
        fun t hO hVt i => by simp [s11, hro_m t hO hVt i]⟩
      · intro j hj _
        have hlt_k : j < k := lt_of_lt_of_le (hjLen_eq ▸ hj) (by omega)
        rcases hDone_m j hj hlt_k with ⟨hb_j, ha_j, hf_j, h14_j, h15_j, h16_j, hV_j, ho_j⟩
        refine ⟨by simp [s11, hbc_26, hb_j],
                by simp [s11, hage_26, ha_j],
                by simp [s11, haff_26, hf_j],
                by simpa [s11] using h14_j, by simpa [s11] using h15_j, by simpa [s11] using h16_j,
                by simpa [s11] using hV_j, fun c => by simpa [s11] using ho_j c⟩
      · intro i hi
        rcases hPre_m i hi with ⟨hb_i, ha_i, hf_i, h14_i, h15_i, h16_i, hV_i, ho_i⟩
        refine ⟨by simp [s11, hbc_26, hb_i],
                by simp [s11, hage_26, ha_i],
                by simp [s11, haff_26, hf_i],
                by simpa [s11] using h14_i, by simpa [s11] using h15_i, by simpa [s11] using h16_i,
                by simpa [s11] using hV_i, fun c => by simpa [s11] using ho_i c⟩
  rcases DetExecAt.repeatN_nat (.lit (D₀ : ℤ)) _ D₀ 1 (90 * (d + 1) + 400) Inv hInv0
      rfl (by simp [intExprOps]) hStep
    with ⟨mD, ⟨_, hDone_D, hPre_D, hwo_D, hw26_D, hro_D⟩, hrep⟩
  have hmD_15 : wRead mD 26 15 = (r : ℤ) := by
    rw [hw26_D 15 (by decide) (by decide) (by decide), hr_reg]
  have hmD_19 : wRead mD 19 (r : ℤ) = (jLen : ℤ) := by
    rw [hwo_D 19 (by decide) (by decide) (by decide) (by decide)
      hbc_19.symm
      hage_19.symm
      haff_19.symm, hjLen_reg]
  let f1 := wWrite mD 26 17 (lastIdx : ℤ)
  have hf1 : DetExecAt 0 inp
      (boxWriteW M_box 26 (.lit 17)
        (.add (.mul (.readHeap 26 (.lit 15)) (.lit (D₀ : ℤ)))
              (.sub (.readHeap 19 (.readHeap 26 (.lit 15))) (.lit 1)))) mD f1 35 := by
    refine exec_boxWriteW inp mD _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
    simp only [iValAt_add, iValAt_mul, iValAt_sub, iValAt_readHeap, iValAt_lit, hmD_15, hmD_19, lastIdx]
    omega
  let f2 := wWrite f1 1 6 (wRead mem 23 (((8 * lastIdx + 5 : ℕ) : ℤ)))
  have hf2 : DetExecAt 0 inp
      (boxWriteW M_box 1 (.lit 6)
        (.readHeap 23 (.add (.mul (.lit 8) (.readHeap 26 (.lit 17))) (.lit 5)))) f1 f2 30 := by
    refine exec_boxWriteW inp f1 _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
    have hf1_17 : wRead f1 26 17 = (lastIdx : ℤ) := by simp [f1]
    have hf1_23 : ∀ i, wRead f1 23 i = wRead mem 23 i := fun i => by
      dsimp only [f1]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
      exact hwo_D 23 (by decide) (by decide) (by decide) (by decide)
        hbc_23.symm
        hage_23.symm
        haff_23.symm i
    simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, hf1_17, hf1_23]
    have h8 : (8 : ℤ) * (lastIdx : ℤ) + 5 = ((8 * lastIdx + 5 : ℕ) : ℤ) := by push_cast; ring
    rw [h8]
  let f3 := wWrite f2 1 5 (((r + jLen : ℕ) : ℤ))
  have hf3 : DetExecAt 0 inp
      (boxWriteW M_box 1 (.lit 5)
        (.add (.readHeap 26 (.lit 15)) (.readHeap 19 (.readHeap 26 (.lit 15))))) f2 f3 30 := by
    refine exec_boxWriteW inp f2 _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
    have hf2_15 : wRead f2 26 15 = (r : ℤ) := by
      dsimp only [f2, f1]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hmD_15]
    have hf2_19 : wRead f2 19 (r : ℤ) = (jLen : ℤ) := by
      dsimp only [f2, f1]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hmD_19]
    simp only [iValAt_add, iValAt_readHeap, iValAt_lit, hf2_15, hf2_19]
    push_cast; rfl
  have hpop := exec_popScopeZero inp f3
  let m' := f3.popDepth 0
  have hex_all : DetExecAt 0 inp (deadlineSuffixSwapStmt d D₀ M_box cfg) mem m'
      (deadlineSuffixSwapCost d D₀) := by
    unfold deadlineSuffixSwapStmt seqList
    exact (hd0.seq (hrep.seq (hf1.seq (hf2.seq (hf3.seq hpop))))).mono_cost
      (by unfold deadlineSuffixSwapCost; omega)
  have hm'_w : ∀ t, t ≠ 1 → t ≠ 26 → ∀ i, wRead m' t i = wRead mD t i := fun t h1 h26 i => by
    dsimp only [m', f3, f2, f1]
    rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inl h1),
        wRead_wWrite_of_ne _ _ (Or.inl h1), wRead_wWrite_of_ne _ _ (Or.inl h26)]
  have hm'_r : ∀ t i, rRead m' t i = rRead mD t i := fun t i => by
    dsimp only [m', f3, f2, f1]; simp
  refine ⟨m', hex_all, popDepth_zero_idem f3,
    by dsimp only [m', f3]; simp,
    by dsimp only [m', f3, f2]; rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; simp,
    ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro j hj
    have hj_D0 : j < D₀ := lt_of_lt_of_le (hjLen_eq ▸ hj) (by omega)
    rcases hDone_D j hj hj_D0 with ⟨hb_j, ha_j, hf_j, h14_j, h15_j, h16_j, hV_j, ho_j⟩
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · rw [hm'_w _ hbc_1 hbc_26]; exact hb_j
    · rw [hm'_w _ hage_1 hage_26]; exact ha_j
    · rw [hm'_w _ haff_1 haff_26]; exact hf_j
    · rw [hm'_w 14 (by decide) (by decide)]; exact h14_j
    · rw [hm'_w 15 (by decide) (by decide)]; exact h15_j
    · rw [hm'_w 16 (by decide) (by decide)]; exact h16_j
    · rw [hm'_r]; exact hV_j
    · intro c; rw [hm'_r]; exact ho_j c
  · intro i hi
    rcases hPre_D i hi with ⟨hb_i, ha_i, hf_i, h14_i, h15_i, h16_i, hV_i, ho_i⟩
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · rw [hm'_w _ hbc_1 hbc_26]; exact hb_i
    · rw [hm'_w _ hage_1 hage_26]; exact ha_i
    · rw [hm'_w _ haff_1 haff_26]; exact hf_i
    · rw [hm'_w 14 (by decide) (by decide)]; exact h14_i
    · rw [hm'_w 15 (by decide) (by decide)]; exact h15_i
    · rw [hm'_w 16 (by decide) (by decide)]; exact h16_i
    · rw [hm'_r]; exact hV_i
    · intro c; rw [hm'_r]; exact ho_i c
  · intro t h1 h14 h15 h16 h26 hbc hage haff i
    rw [hm'_w t h1 h26]; exact hwo_D t h14 h15 h16 h26 hbc hage haff i
  · intro i h5 h6
    dsimp only [m', f3, f2, f1]
    rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inr h5),
        wRead_wWrite_of_ne _ _ (Or.inr h6), wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
    exact hwo_D 1 (by decide) (by decide) (by decide) (by decide)
      hbc_1.symm hage_1.symm haff_1.symm i
  · intro i h16 h17 h18
    dsimp only [m', f3, f2, f1]
    rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr h17)]
    exact hw26_D i h16 h17 h18
  · intro t hO hVt i
    rw [hm'_r]; exact hro_D t hO hVt i

end UL.Proof_lem_7_2_RacerP46
