import UL.Proof.lem_7_2.CG03_JobTickA2c
import UL.Proof.lem_7_2.CG01_ServingSchedC

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Outer Slot-Cardinality Reader, Slot Freezer on `26[1]`, & Center Store from `27` -/

def readSlotCardTo24Stmt (K M_box : ℕ) (sE : IntExpr) : ArithRAMStmt :=
  .localScope (seqList [
    cardAndMaxSegSlotStmt K sE,
    boxWriteW M_box 26 (.lit 24) (.readLocal 28 (.lit 0))
  ])

theorem boxSafe_readSlotCardTo24Stmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (K : ℕ) (sE : IntExpr) :
    BoxSafeOuter T_max M_box (readSlotCardTo24Stmt K M_box sE) :=
  .localScope (.seq (boxSafe_cardAndMaxSegSlotStmt K sE) (.boxW (by omega) _ _))

theorem exec_readSlotCardTo24Stmt {d K M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (sE : IntExpr) {s : ℕ} {S : Finset ℕ} {fSq : ℕ → ℝ}
    (hBox26 : 25 ≤ M_box)
    (hsE : iValAt 1 inp (mem.popDepth 0) sE = (s : ℤ))
    (hSeg : EncSegSlot K mem s S fSq) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (readSlotCardTo24Stmt K M_box sE) mem m' (intExprOps sE + 70) ∧
      m'.popDepth 0 = m' ∧
      wRead m' 26 24 = (S.card : ℤ) ∧
      (∀ t, t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 24 → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) := by
  let m0 := mem.popDepth 0
  have hSeg0 : EncSegSlot K m0 s S fSq :=
    hSeg.congr_mem_fSq (by simp [m0]) (fun _ _ => by simp [m0]) (fun _ _ => by simp [m0])
      (fun _ _ => by simp [m0]) (fun _ _ => by simp [m0]) (fun _ _ => rfl)
  rcases exec_cardAndMaxSegSlotStmt inp m0 sE hsE hSeg0
    with ⟨m1, hs1, hcard1, _, hw1, hr1, _, _⟩
  let m2 := wWrite m1 26 24 (S.card : ℤ)
  have hs2 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 24) (.readLocal 28 (.lit 0))) m1 m2 16 :=
    exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) (by simp [hcard1]) (by simp [intExprOps])
  let m' := m2.popDepth 0
  have hex : DetExecAt 0 inp (readSlotCardTo24Stmt K M_box sE) mem m' (intExprOps sE + 70) :=
    (DetExecAt.localScope (fd := 0) (hs1.seq hs2)).mono_cost (by omega)
  refine ⟨m', hex, popDepth_zero_idem m2,
    by dsimp only [m', m2]; simp,
    fun t ht i => by dsimp only [m', m2]; rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inl ht), hw1]; simp [m0],
    fun i hi => by dsimp only [m', m2]; rw [wRead_popDepth, wRead_wWrite_of_ne _ _ (Or.inr hi), hw1]; simp [m0],
    fun t i => by dsimp only [m', m2]; rw [rRead_popDepth, rRead_wWrite, hr1]; simp [m0]⟩

def freezeSlot26_1Stmt (M_box : ℕ) : ArithRAMStmt :=
  .localScope (freezeSlotStmt M_box (.readHeap 26 (.lit 1)))

theorem boxSafe_freezeSlot26_1Stmt {T_max M_box : ℕ} (hT : 7 ≤ T_max) :
    BoxSafeOuter T_max M_box (freezeSlot26_1Stmt M_box) :=
  .localScope (boxSafe_freezeSlotStmt hT (.readHeap 26 (.lit 1)))

theorem exec_freezeSlot26_1Stmt {d n K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {s : ℕ} {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)} {S : Finset ℕ}
    (hs : s < NumSlots)
    (hs_reg : wRead mem 26 1 = (s : ℤ))
    (hBox1 : 4 ≤ M_box) (hBox_slots : NumSlots ≤ M_box)
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem)
    (hS_sub : S ⊆ activeH)
    (hS_lt : ∀ h ∈ S, h < n) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (freezeSlot26_1Stmt M_box) mem m' 50 ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      SaveGenBound n NumSlots m' ∧
      1 ≤ wRead m' 6 (s : ℤ) ∧
      EncSlotCoords d n m' activeH livePts s S livePts ∧
      (∀ s' < NumSlots, s' ≠ s → ∀ S' sp',
        EncSlotCoords d n mem activeH livePts s' S' sp' →
        EncSlotCoords d n m' activeH livePts s' S' sp') ∧
      (∀ s' : ℤ, s' ≠ (s : ℤ) → wRead m' 6 s' = wRead mem 6 s') ∧
      (∀ t, t ≠ 1 → t ≠ 6 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 3 → wRead m' 1 i = wRead mem 1 i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) := by
  let m0 := mem.popDepth 0
  have hseg0 : SegGenBound K NumSlots m0 :=
    ⟨by simp [m0]; exact hseg.1,
     fun x hx => by simp [m0]; exact hseg.2.1 x hx,
     fun x hx u hu => by simp [m0]; exact hseg.2.2 x hx u hu⟩
  have hsave0 : SaveGenBound n NumSlots m0 :=
    ⟨by simp [m0]; exact hsave.1,
     fun x hx => by simp [m0]; exact hsave.2.1 x hx,
     fun x hx h hh => by simp [m0]; exact hsave.2.2 x hx h hh⟩
  -- Need wRead m' 6 s' = wRead mem 6 s' for s' ≠ s: check freezeSlotStmt body or use unique_mem!
  rcases exec_freezeSlotStmt inp m0 (.readHeap 26 (.lit 1)) hs
      (by simp [m0, hs_reg]) hBox1 hBox_slots hseg0 hsave0 hS_sub hS_lt
    with ⟨m1, hd1, hseg1, hsave1, hw6_1, hSlot1, hSlotFr1, hw_1, hw1_1, hr_1, _, _⟩
  -- Identify wRead m1 6 s' for s' ≠ s via explicit 4-step trace of freezeSlotStmt
  set g := wRead m0 1 3
  let a1 := wWriteL 1 m0 29 2 (s : ℤ)
  let a2 := wWriteL 1 a1 29 3 g
  let a3 := wWrite a2 6 (s : ℤ) g
  let a4 := wWrite a3 1 3 (g + 1)
  have e1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 2) (.readHeap 26 (.lit 1))) m0 a1 5 :=
    DetExecAt.writeWordLocal 1 inp m0 29 _ _ rfl (by simp [m0, hs_reg]) (by simp [intExprOps])
  have e2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 3) (.readHeap 1 (.lit 3))) a1 a2 5 :=
    DetExecAt.writeWordLocal 1 inp a1 29 _ _ rfl (by simp [a1, g]) (by simp [intExprOps])
  have e3 : DetExecAt 1 inp (boxWriteW M_box 6 (.readLocal 29 (.lit 2)) (.readLocal 29 (.lit 3))) a2 a3 14 :=
    exec_boxWriteW inp a2 _ _ (by simp [a2, a1]) (by omega) (by omega) (by simp [a2]) (by simp [intExprOps])
  have e4 : DetExecAt 1 inp (boxWriteW M_box 1 (.lit 3) (.add (.readLocal 29 (.lit 3)) (.lit 1))) a3 a4 14 :=
    exec_boxWriteW inp a3 _ _ rfl (by omega) (by omega) (by simp [a3, a2]) (by simp [intExprOps])
  let m' := m1.popDepth 0
  have hex : DetExecAt 0 inp (freezeSlot26_1Stmt M_box) mem m' 50 :=
    (DetExecAt.localScope (fd := 0) hd1).mono_cost (by simp [intExprOps])
  have hex_alt := DetExecAt.localScope (fd := 0) (e1.seq (e2.seq (e3.seq e4)))
  have hm_eq : m' = a4.popDepth 0 :=
    DetExecAt.unique_mem hex hex_alt (popDepth_zero_idem m1) (popDepth_zero_idem a4)
  refine ⟨m', hex, popDepth_zero_idem m1,
    ⟨by simp [m']; exact hseg1.1,
     fun x hx => by simp [m']; exact hseg1.2.1 x hx,
     fun x hx u hu => by simp [m']; exact hseg1.2.2 x hx u hu⟩,
    ⟨by simp [m']; exact hsave1.1,
     fun x hx => by simp [m']; exact hsave1.2.1 x hx,
     fun x hx h hh => by simp [m']; exact hsave1.2.2 x hx h hh⟩,
    by simpa [m'] using hw6_1,
    hSlot1.congr_mem3 (by simp [m']) (fun _ => by simp [m']) (fun _ => by simp [m']),
    fun s' hs' hne S' sp' hC =>
      (hSlotFr1 s' hs' hne S' sp'
        (hC.congr_mem3 (by simp [m0]) (fun _ => by simp [m0]) (fun _ => by simp [m0]))).congr_mem3
          (by simp [m']) (fun _ => by simp [m']) (fun _ => by simp [m']),
    ?_,
    fun t h1 h6 i => by simp [m', hw_1 t h1 h6, m0],
    fun i hi => by simp [m', hw1_1 i hi, m0],
    fun t i => by simp [m', hr_1, m0]⟩
  · intro s' hne
    rw [hm_eq, wRead_popDepth]
    dsimp only [a4, a3, a2, a1, m0]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr hne),
        wRead_wWriteL, wRead_wWriteL, wRead_popDepth]

def storeCenter27ToSnStmt (d M_box rSnCenterO : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 29 (.lit 18) (.lit 0),
    loadHeapCoordsToLocalStmt d 27 18 0,
    .writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 18)) (.lit (d : ℤ))),
    storeLocalCoordsToHeapStmt d M_box rSnCenterO 18 0
  ])

theorem boxSafe_storeCenter27ToSnStmt {T_max M_box : ℕ}
    (d rSnCenterO : ℕ) (hO : rSnCenterO < T_max) :
    BoxSafeOuter T_max M_box (storeCenter27ToSnStmt d M_box rSnCenterO) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact boxSafe_loadHeapCoordsToLocalStmt d 27 18 0
  · exact .writeWordLocal _ _ _
  · exact boxSafe_storeLocalCoordsToHeapStmt d rSnCenterO hO 18 0

theorem exec_storeCenter27ToSnStmt {d M_box rSnCenterO : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {dst : ℕ} {pt : EuclideanSpace ℝ (Fin d)}
    (hdst_reg : wRead mem 26 18 = (dst : ℤ))
    (hBox_dst : dst * d + d ≤ M_box)
    (hsrc : ∀ c : Fin d, rRead mem 27 (c.val : ℤ) = euclideanCoord pt c) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (storeCenter27ToSnStmt d M_box rSnCenterO) mem m' (90 * (d + 1) + 40) ∧
      m'.popDepth 0 = m' ∧
      (∀ c : Fin d, rRead m' rSnCenterO (((dst * d + c.val : ℕ) : ℤ)) = euclideanCoord pt c) ∧
      (∀ i : ℤ, (i < ((dst * d : ℕ) : ℤ) ∨ ((dst * d + d : ℕ) : ℤ) ≤ i) →
        rRead m' rSnCenterO i = rRead mem rSnCenterO i) ∧
      (∀ t, t ≠ rSnCenterO → ∀ i, rRead m' t i = rRead mem t i) ∧
      (∀ t i, wRead m' t i = wRead mem t i) := by
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 29 18 0
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.lit 0)) m0 m1 4 :=
    DetExecAt.writeWordLocal 1 inp m0 29 _ _ rfl rfl (by simp [intExprOps])
  rcases exec_loadHeapCoordsToLocalStmt inp m1 (rTag := 27) (idxBase := 18) (destOff := 0)
      (base := 0) (pt := pt) (by decide) (by simp [m1])
      (fun c => by simpa [m1, m0] using hsrc c)
    with ⟨m2, hs2, hloc2, hw2, hr2, _, _, _, _⟩
  let m3 := wWriteL 1 m2 29 18 (((dst * d : ℕ) : ℤ))
  have hs3 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 18)) (.lit (d : ℤ)))) m2 m3 8 := by
    refine DetExecAt.writeWordLocal 1 inp m2 29 _ _ rfl ?_ (by simp [intExprOps])
    simp only [iValAt_mul, iValAt_readHeap, iValAt_lit, hw2, m1, m0, wRead_wWriteL, wRead_popDepth, hdst_reg]
    push_cast; rfl
  rcases exec_storeLocalCoordsToHeapStmt inp m3 (M_box := M_box) (rTag := rSnCenterO) (idxBase := 18) (srcOff := 0)
      (base := dst * d) (pt := pt) (by decide) (by simp [m3]) hBox_dst
      (fun c => by simp [m3, Nat.zero_add]; simpa using hloc2 c)
    with ⟨m4, hs4, hr_dst4, hr_out4, hr_oth4, hw4, _, _, _, _⟩
  let m' := m4.popDepth 0
  have hex : DetExecAt 0 inp (storeCenter27ToSnStmt d M_box rSnCenterO) mem m' (90 * (d + 1) + 40) :=
    (DetExecAt.localScope (fd := 0) (hs1.seq (hs2.seq (hs3.seq hs4)))).mono_cost (by omega)
  refine ⟨m', hex, popDepth_zero_idem m4,
    fun c => by simpa [m'] using hr_dst4 c,
    fun i hi => by simp [m', hr_out4 i hi, m3, hr2, m1, m0],
    fun t ht i => by simp [m', hr_oth4 t ht, m3, hr2, m1, m0],
    fun t i => by simp [m', hw4, m3, hw2, m1, m0]⟩

/-! ### 2. Full Chain + Active Jobs RAM Encoding (`EncOwnedJobAt`, `EncFullChainAndJobs`) -/

def EncOwnedJobAt {d n L B_scan : ℕ}
    (cfg : ChainHdrCfg) (p : P46Params d n) (mem : ArithRAMMemory)
    (P : DynamicPointSet d) (uMap : GhostUidMap d P)
    (r : ℕ) (S_r_h S_r_uid : Finset ℕ) :
    Option (ActiveJobGhost d n (d + 3) L B_scan uMap.nextUid uMap.ghostCoords S_r_uid) → Prop
  | none => wRead mem 16 (r : ℤ) = 0
  | some g =>
      wRead mem 16 (r : ℤ) = 1 ∧
      wRead mem cfg.jobRem.tag (cfg.jobRem.idx r : ℤ) = (((g.H_job - g.t_cur : ℕ) : ℤ)) ∧
      wRead mem cfg.jobClosed.tag (cfg.jobClosed.idx r : ℤ) = (if g.closed then 1 else 0) ∧
      wRead mem 19 (r : ℤ) = (g.lvs.length : ℤ) ∧
      ∃ (lvs_h : List (JobLvData d)),
        ∃ (hlen_eq : lvs_h.length = g.lvs.length),
        ∀ (j : ℕ) (hj : j < lvs_h.length),
          let idx := r * p.D₀ + j
          let hj_g : j < g.lvs.length := hlen_eq ▸ hj
          (lvs_h[j]'hj).ball (d + 3) = (g.lvs[j]'hj_g).ball ∧
          (lvs_h[j]'hj).openRem = g.openRem j ∧
          (∃ (f_b g_b : ℕ → ℕ),
            (∀ h ∈ (lvs_h[j]'hj).S_birth,
              f_b h ∈ (g.lvs[j]'hj_g).birthSnapshot ∧
              uMap.ghostCoords (f_b h) = (lvs_h[j]'hj).snapPts h ∧
              g_b (f_b h) = h) ∧
            (∀ u ∈ (g.lvs[j]'hj_g).birthSnapshot,
              g_b u ∈ (lvs_h[j]'hj).S_birth ∧
              f_b (g_b u) = u)) ∧
          EncJobLevel d n (d + 3) p.K_seg p.NumSlots mem P.activeHandles P.handleCoords idx
            (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
            (jobHandleInput (d + 3) P.handleCoords lvs_h S_r_h j)
            (decide (j + 1 = lvs_h.length)) ∧
          wRead mem 23 (((8 * idx + 7 : ℕ) : ℤ)) = (g.openRem j : ℤ) ∧
          0 < (wRead mem 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat ∧
          0 < (wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ))).toNat ∧
          0 < (wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ))).toNat ∧
          0 < (wRead mem 23 (((8 * idx + 5 : ℕ) : ℤ))).toNat ∧
          0 < (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat ∧
          (j + 1 < lvs_h.length → wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2) ∧
          (j + 1 = lvs_h.length →
            wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = (g.ph_cur : ℤ) ∧
            wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (g.scan_cur : ℤ) ∧
            g.Spar_last_h = jobHandleInput (d + 3) P.handleCoords lvs_h S_r_h j)

def EncNodeHeaderAt {d n : ℕ}
    (cfg : ChainHdrCfg) (p : P46Params d n) (mem : ArithRAMMemory)
    (P : DynamicPointSet d) (r : ℕ) (node : ChainNode d)
    (birthCard snAge : ℕ) (S_r : Finset ℕ) (idle : Bool) : Prop :=
  ∃ (dS spS : ℕ) (T_sp : Finset ℕ),
    0 < dS ∧ dS < p.NumSlots ∧
    0 < spS ∧ spS < p.NumSlots ∧
    dS ≠ spS ∧
    wRead mem cfg.snBirthCard.tag (cfg.snBirthCard.idx r : ℤ) = (birthCard : ℤ) ∧
    wRead mem cfg.snAge.tag (cfg.snAge.idx r : ℤ) = (snAge : ℤ) ∧
    wRead mem 14 (r : ℤ) = (dS : ℤ) ∧
    wRead mem 15 (r : ℤ) = (spS : ℤ) ∧
    wRead mem 6 (dS : ℤ) = 0 ∧
    wRead mem 6 (spS : ℤ) = 0 ∧
    (∀ c : Fin d, rRead mem cfg.rSnCenterO (((r * d + c.val : ℕ) : ℤ)) = euclideanCoord node.o c) ∧
    rRead mem cfg.rSnCenterV.tag (cfg.rSnCenterV.idx r : ℤ) = node.V ∧
    EncSegSlot p.K_seg mem dS S_r (fun x => euclideanDistSq (P.handleCoords x) node.o) ∧
    EncSegSlot p.K_seg mem spS T_sp (fun _ => 0) ∧
    (idle = true → T_sp = S_r)

def GlobalSlotDisj (D₀ : ℕ) (mem : ArithRAMMemory) (k leafS : ℕ) : Prop :=
  0 < leafS ∧
  (∀ r < k, ∀ s ∈ snSlotSet mem r, s ≠ 0 ∧ s ≠ leafS) ∧
  (∀ r₁ < k, ∀ r₂ < k, r₁ ≠ r₂ → Disjoint (snSlotSet mem r₁) (snSlotSet mem r₂)) ∧
  (∀ r < k, wRead mem 16 (r : ℤ) = 1 →
    ∀ j < (wRead mem 19 (r : ℤ)).toNat,
      let L_rj := jobLevelLiveSlots mem (r * D₀ + j) (decide (j + 1 = (wRead mem 19 (r : ℤ)).toNat))
      (∀ s ∈ L_rj, s ≠ 0 ∧ s ≠ leafS) ∧
      (∀ r' < k, Disjoint L_rj (snSlotSet mem r'))) ∧
  (∀ r₁ < k, wRead mem 16 (r₁ : ℤ) = 1 → ∀ j₁ < (wRead mem 19 (r₁ : ℤ)).toNat,
   ∀ r₂ < k, wRead mem 16 (r₂ : ℤ) = 1 → ∀ j₂ < (wRead mem 19 (r₂ : ℤ)).toNat,
    (r₁ ≠ r₂ ∨ j₁ ≠ j₂) →
      Disjoint
        (jobLevelLiveSlots mem (r₁ * D₀ + j₁) (decide (j₁ + 1 = (wRead mem 19 (r₁ : ℤ)).toNat)))
        (jobLevelLiveSlots mem (r₂ * D₀ + j₂) (decide (j₂ + 1 = (wRead mem 19 (r₂ : ℤ)).toNat))) ∧
      (wRead mem 23 (((8 * (r₁ * D₀ + j₁) + 2 : ℕ) : ℤ))).toNat ≠
        (wRead mem 23 (((8 * (r₂ * D₀ + j₂) + 2 : ℕ) : ℤ))).toNat)

def EncFullChainAndJobs (d n H : ℕ) (cfg : ChainHdrCfg) (p : P46Params d n)
    (mem : ArithRAMMemory) (P : DynamicPointSet d)
    (st : PureServingState d n H p.L p.B_scan P) : Prop :=
  st.k ≤ p.D₀ ∧
  SegGenBound p.K_seg p.NumSlots mem ∧
  SaveGenBound n p.NumSlots mem ∧
  EncLiveCoords d n mem P.activeHandles P.handleCoords ∧
  wRead mem 1 5 = (st.k : ℤ) ∧
  wRead mem 6 0 = 0 ∧
  EncSegSlot p.K_seg mem 0 P.activeHandles (fun _ => 0) ∧
  ∃ leafS : ℕ,
    0 < leafS ∧ leafS < p.NumSlots ∧
    wRead mem 1 6 = (leafS : ℤ) ∧
    wRead mem 6 (leafS : ℤ) = 0 ∧
    EncSegSlot p.K_seg mem leafS (chainTerminal P.handleCoords st.nodes P.activeHandles) (fun _ => 0) ∧
    GlobalSlotDisj p.D₀ mem st.k leafS ∧
    (∀ r : Fin st.k,
      EncNodeHeaderAt cfg p mem P r.val (st.nodes r) (st.birthSnap r).card (st.snAge r)
        (chainInput P.handleCoords st.nodes P.activeHandles r.castSucc) (st.ownedJob r).isNone ∧
      EncOwnedJobAt cfg p mem P st.uMap r.val
        (chainInput P.handleCoords st.nodes P.activeHandles r.castSucc)
        (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids r.castSucc)
        (st.ownedJob r))

lemma not_in_activeSlotSet_props {mem : ArithRAMMemory} {D₀ k leafS s : ℕ}
    (hw_k : wRead mem 1 5 = (k : ℤ))
    (hw_leaf : wRead mem 1 6 = (leafS : ℤ))
    (hnot : s ∉ activeSlotSet mem D₀) :
    s ≠ 0 ∧ s ≠ leafS ∧
    (∀ r < k, s ∉ snSlotSet mem r) ∧
    (∀ r < k, wRead mem 16 (r : ℤ) = 1 →
      ∀ j < (wRead mem 19 (r : ℤ)).toNat, s ∉ jobLevelSlotSet mem (r * D₀ + j)) := by
  have hk_nat : (wRead mem 1 5).toNat = k := by rw [hw_k]; simp
  have hl_nat : (wRead mem 1 6).toNat = leafS := by rw [hw_leaf]; simp
  unfold activeSlotSet at hnot
  rw [hk_nat, hl_nat] at hnot
  simp only [Finset.mem_insert, Finset.mem_biUnion, Finset.mem_range, Finset.mem_union, not_or, not_exists, not_and] at hnot
  refine ⟨hnot.1, hnot.2.1, fun r hr hs => (hnot.2.2 r hr).1 hs, fun r hr h16 j hj hs => ?_⟩
  apply (hnot.2.2 r hr).2
  unfold jobOwnedSlotSet
  rw [if_pos h16]
  exact Finset.mem_biUnion.mpr ⟨j, Finset.mem_range.mpr hj, hs⟩

lemma EncFullChainAndJobs.gc_hyps {d n H : ℕ} {cfg : ChainHdrCfg} {p : P46Params d n}
    {mem : ArithRAMMemory} {P : DynamicPointSet d} {st : PureServingState d n H p.L p.B_scan P}
    (hH_le : ∀ (r : Fin st.k) g, st.ownedJob r = some g → g.lvs.length ≤ p.D₀)
    (hF : EncFullChainAndJobs d n H cfg p mem P st) :
    st.k ≤ p.D₀ ∧
    wRead mem 1 5 = (st.k : ℤ) ∧
    ∃ leafS < p.NumSlots,
      wRead mem 1 6 = (leafS : ℤ) ∧
      (∀ r < st.k, ∃ (dS spS : ℕ), dS < p.NumSlots ∧ spS < p.NumSlots ∧
        wRead mem 14 (r : ℤ) = (dS : ℤ) ∧ wRead mem 15 (r : ℤ) = (spS : ℤ)) ∧
      (∀ r < st.k, wRead mem 16 (r : ℤ) = 1 →
        ∃ jLen ≤ p.D₀, wRead mem 19 (r : ℤ) = (jLen : ℤ) ∧
          ∀ j < jLen, ∃ (s2 s3 s4 s5 s6 : ℕ),
            s2 < p.NumSlots ∧ s3 < p.NumSlots ∧ s4 < p.NumSlots ∧ s5 < p.NumSlots ∧ s6 < p.NumSlots ∧
            wRead mem 23 (((8 * (r * p.D₀ + j) + 2 : ℕ) : ℤ)) = (s2 : ℤ) ∧
            wRead mem 23 (((8 * (r * p.D₀ + j) + 3 : ℕ) : ℤ)) = (s3 : ℤ) ∧
            wRead mem 23 (((8 * (r * p.D₀ + j) + 4 : ℕ) : ℤ)) = (s4 : ℤ) ∧
            wRead mem 23 (((8 * (r * p.D₀ + j) + 5 : ℕ) : ℤ)) = (s5 : ℤ) ∧
            wRead mem 23 (((8 * (r * p.D₀ + j) + 6 : ℕ) : ℤ)) = (s6 : ℤ)) := by
  rcases hF with ⟨hk_le, _, _, _, hw15, _, _, leafS, _, hleaf_lt, hw16, _, _, _, hnodes⟩
  refine ⟨hk_le, hw15, leafS, hleaf_lt, hw16, ?_, ?_⟩
  · intro r hr
    rcases (hnodes ⟨r, hr⟩).1 with ⟨dS, spS, _, _, hdS, _, hspS, _, _, _, hw14, hw15_r, _⟩
    exact ⟨dS, spS, hdS, hspS, hw14, hw15_r⟩
  · intro r hr h16
    have hj_enc := (hnodes ⟨r, hr⟩).2
    cases hoj : st.ownedJob ⟨r, hr⟩ with
    | none =>
        rw [hoj] at hj_enc; change wRead mem 16 (r : ℤ) = 0 at hj_enc; omega
    | some g =>
        rw [hoj] at hj_enc
        rcases hj_enc with ⟨_, _, _, hw19, lvs_h, hlen_eq, hlv_all⟩
        refine ⟨g.lvs.length, hH_le ⟨r, hr⟩ g hoj, hw19, fun j hj => ?_⟩
        have hj_lh : j < lvs_h.length := hlen_eq ▸ hj
        rcases (hlv_all j hj_lh).2.2.2.1 with ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr,
          _, _, _, _, _, _, _, _, _, _, e2, e3, e4, e5, e6, _⟩
        exact ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, e2, e3, e4, e5, e6⟩

end UL.Proof_lem_7_2_RacerP46
