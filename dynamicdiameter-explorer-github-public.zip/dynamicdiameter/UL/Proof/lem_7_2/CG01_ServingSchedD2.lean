import UL.Proof.lem_7_2.CG01_ServingSchedD1

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 7. Bit-Splitting Helpers & Adaptive Sequential Bad-Bit Union Bound -/

def splitLeftBits {B₁ B₂ : ℕ} (bits : Fin (B₁ + B₂) → Bool) : Fin B₁ → Bool :=
  fun i => bits ⟨i.val, Nat.lt_of_lt_of_le i.isLt (Nat.le_add_right B₁ B₂)⟩

def splitRightBits {B₁ B₂ : ℕ} (bits : Fin (B₁ + B₂) → Bool) : Fin B₂ → Bool :=
  fun i => bits ⟨B₁ + i.val, Nat.add_lt_add_left i.isLt B₁⟩

def mergeBits {B₁ B₂ : ℕ} (f₁ : Fin B₁ → Bool) (f₂ : Fin B₂ → Bool) : Fin (B₁ + B₂) → Bool :=
  fun j => if hj : j.val < B₁ then f₁ ⟨j.val, hj⟩ else f₂ ⟨j.val - B₁, by omega⟩

@[simp] lemma splitLeftBits_mergeBits {B₁ B₂ : ℕ}
    (f₁ : Fin B₁ → Bool) (f₂ : Fin B₂ → Bool) :
    splitLeftBits (mergeBits f₁ f₂) = f₁ := by
  ext i
  dsimp only [splitLeftBits, mergeBits]
  rw [dif_pos i.isLt]

@[simp] lemma splitRightBits_mergeBits {B₁ B₂ : ℕ}
    (f₁ : Fin B₁ → Bool) (f₂ : Fin B₂ → Bool) :
    splitRightBits (mergeBits f₁ f₂) = f₂ := by
  ext i
  dsimp only [splitRightBits, mergeBits]
  have hnot : ¬ (B₁ + i.val < B₁) := by omega
  rw [dif_neg hnot]
  congr 1; ext; dsimp only; omega

@[simp] lemma mergeBits_split {B₁ B₂ : ℕ} (bits : Fin (B₁ + B₂) → Bool) :
    mergeBits (splitLeftBits bits) (splitRightBits bits) = bits := by
  ext j
  dsimp only [mergeBits, splitLeftBits, splitRightBits]
  by_cases hj : j.val < B₁
  · rw [dif_pos hj]
  · rw [dif_neg hj]; congr 1; ext; dsimp only; omega

lemma fin_bool_univ_card (B : ℕ) :
    (Finset.univ : Finset (Fin B → Bool)).card = 2 ^ B := by
  simp

/-- Adaptive two-stage bad-bit union bound: if `Bad₁` fails on at most `φ₁ * 2 ^ B₁` prefixes and,
for every good prefix `¬ Bad₁ f₁`, `Bad₂ f₁` fails on at most `φ₂ * 2 ^ B₂` suffixes (`0 ≤ φ₂`),
then `Bad₁ (splitLeftBits bits) ∨ Bad₂ (splitLeftBits bits) (splitRightBits bits)` fails on at most
`(φ₁ + φ₂) * 2 ^ (B₁ + B₂)` bit-functions! -/
theorem bad_card_adaptive_seq {B₁ B₂ : ℕ} {φ₁ φ₂ : ℝ}
    (Bad₁ : (Fin B₁ → Bool) → Prop) [DecidablePred Bad₁]
    (Bad₂ : (Fin B₁ → Bool) → (Fin B₂ → Bool) → Prop) [∀ f₁, DecidablePred (Bad₂ f₁)]
    (hφ₂ : 0 ≤ φ₂)
    (h₁ : ((Finset.univ.filter Bad₁).card : ℝ) ≤ φ₁ * ((2 : ℝ) ^ B₁))
    (h₂ : ∀ f₁ : Fin B₁ → Bool, ¬ Bad₁ f₁ →
      ((Finset.univ.filter (Bad₂ f₁)).card : ℝ) ≤ φ₂ * ((2 : ℝ) ^ B₂)) :
    ((Finset.univ.filter (fun bits : Fin (B₁ + B₂) → Bool =>
        Bad₁ (splitLeftBits bits) ∨ Bad₂ (splitLeftBits bits) (splitRightBits bits))).card : ℝ) ≤
      (φ₁ + φ₂) * ((2 : ℝ) ^ (B₁ + B₂)) := by
  let U₁ : Finset (Fin B₁ → Bool) := Finset.univ
  let U₂ : Finset (Fin B₂ → Bool) := Finset.univ
  let S_bad := Finset.univ.filter (fun bits : Fin (B₁ + B₂) → Bool =>
    Bad₁ (splitLeftBits bits) ∨ Bad₂ (splitLeftBits bits) (splitRightBits bits))
  let P_bad := (U₁ ×ˢ U₂).filter (fun p => Bad₁ p.1 ∨ Bad₂ p.1 p.2)
  have hcard_bij : S_bad.card = P_bad.card := by
    refine Finset.card_bij (fun bits _ => (splitLeftBits bits, splitRightBits bits)) ?_ ?_ ?_
    · intro bits hbits
      have hb := (Finset.mem_filter.mp hbits).2
      exact Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨Finset.mem_univ _, Finset.mem_univ _⟩, hb⟩
    · intro b₁ _ b₂ _ heq
      have hL : splitLeftBits b₁ = splitLeftBits b₂ := congrArg Prod.fst heq
      have hR : splitRightBits b₁ = splitRightBits b₂ := congrArg Prod.snd heq
      rw [← mergeBits_split b₁, ← mergeBits_split b₂, hL, hR]
    · intro p hp
      have hb := (Finset.mem_filter.mp hp).2
      refine ⟨mergeBits p.1 p.2, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, ?_⟩
      · simpa only [splitLeftBits_mergeBits, splitRightBits_mergeBits] using hb
      · ext <;> simp
  let A := (U₁.filter Bad₁) ×ˢ U₂
  let G₁ := U₁.filter (fun f₁ => ¬ Bad₁ f₁)
  let F : (Fin B₁ → Bool) → Finset ((Fin B₁ → Bool) × (Fin B₂ → Bool)) :=
    fun f₁ => (U₂.filter (Bad₂ f₁)).image (fun f₂ => (f₁, f₂))
  let B_set := G₁.biUnion F
  have hsub : P_bad ⊆ A ∪ B_set := by
    intro p hp
    rcases p with ⟨f₁, f₂⟩
    have hb := (Finset.mem_filter.mp hp).2
    by_cases hb₁ : Bad₁ f₁
    · exact Finset.mem_union_left _
        (Finset.mem_product.mpr ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, hb₁⟩, Finset.mem_univ _⟩)
    · have hb₂ : Bad₂ f₁ f₂ := hb.resolve_left hb₁
      refine Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨f₁, ?_, ?_⟩)
      · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hb₁⟩
      · exact Finset.mem_image.mpr ⟨f₂, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hb₂⟩, rfl⟩
  have hnat_le : S_bad.card ≤ A.card + B_set.card := by
    rw [hcard_bij]
    exact (Finset.card_le_card hsub).trans (Finset.card_union_le A B_set)
  have hA_real : (A.card : ℝ) ≤ φ₁ * ((2 : ℝ) ^ (B₁ + B₂)) := by
    have hA_eq : A.card = (U₁.filter Bad₁).card * 2 ^ B₂ := by
      rw [Finset.card_product, fin_bool_univ_card]
    rw [hA_eq, Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat, pow_add, ← mul_assoc]
    exact mul_le_mul_of_nonneg_right h₁ (by positivity)
  have hB_real : (B_set.card : ℝ) ≤ φ₂ * ((2 : ℝ) ^ (B₁ + B₂)) := by
    have hbi_nat : B_set.card ≤ ∑ f₁ ∈ G₁, (F f₁).card := Finset.card_biUnion_le
    have hbi_real : (B_set.card : ℝ) ≤ ∑ f₁ ∈ G₁, ((F f₁).card : ℝ) := by exact_mod_cast hbi_nat
    have hterm : ∀ f₁ ∈ G₁, ((F f₁).card : ℝ) ≤ φ₂ * ((2 : ℝ) ^ B₂) := by
      intro f₁ hf₁
      have hnot : ¬ Bad₁ f₁ := (Finset.mem_filter.mp hf₁).2
      have himg : ((F f₁).card : ℝ) ≤ ((U₂.filter (Bad₂ f₁)).card : ℝ) := by
        exact_mod_cast Finset.card_image_le
      exact himg.trans (h₂ f₁ hnot)
    have hsum_le : ∑ f₁ ∈ G₁, ((F f₁).card : ℝ) ≤ (G₁.card : ℝ) * (φ₂ * ((2 : ℝ) ^ B₂)) := by
      simpa [nsmul_eq_mul] using Finset.sum_le_card_nsmul G₁ _ (φ₂ * ((2 : ℝ) ^ B₂)) hterm
    have hG_le : (G₁.card : ℝ) ≤ (2 : ℝ) ^ B₁ := by
      have hGn : G₁.card ≤ 2 ^ B₁ := by
        rw [← fin_bool_univ_card B₁]
        exact Finset.card_le_card (Finset.filter_subset _ _)
      exact_mod_cast hGn
    have hprod_le : (G₁.card : ℝ) * (φ₂ * ((2 : ℝ) ^ B₂)) ≤ φ₂ * ((2 : ℝ) ^ (B₁ + B₂)) := by
      calc (G₁.card : ℝ) * (φ₂ * ((2 : ℝ) ^ B₂))
          ≤ ((2 : ℝ) ^ B₁) * (φ₂ * ((2 : ℝ) ^ B₂)) :=
            mul_le_mul_of_nonneg_right hG_le (mul_nonneg hφ₂ (by positivity))
        _ = φ₂ * (((2 : ℝ) ^ B₁) * ((2 : ℝ) ^ B₂)) := by ring
        _ = φ₂ * ((2 : ℝ) ^ (B₁ + B₂)) := by rw [pow_add]
    exact hbi_real.trans (hsum_le.trans hprod_le)
  have htot : (S_bad.card : ℝ) ≤ (A.card : ℝ) + (B_set.card : ℝ) := by exact_mod_cast hnat_le
  calc (S_bad.card : ℝ)
      ≤ (A.card : ℝ) + (B_set.card : ℝ) := htot
    _ ≤ φ₁ * ((2 : ℝ) ^ (B₁ + B₂)) + φ₂ * ((2 : ℝ) ^ (B₁ + B₂)) := add_le_add hA_real hB_real
    _ = (φ₁ + φ₂) * ((2 : ℝ) ^ (B₁ + B₂)) := by ring

/-! ### 8. `RandExecWithBad`: Compositional Outer `fd = 0` Randomized Execution + Failure Budget -/

/-- Bundled `fd = 0` randomized execution predicate matching `p46_horizon_bridge_outer` (`hStep`),
`exec_runHPJOnSlotStmt_active`, and `exec_runBaselineSlotStmt_active`. -/
def RandExecWithBad {d : ℕ} (inp : ArithRAMInput d) (s : ArithRAMStmt)
    (B : ℕ) (mem₀ : ArithRAMMemory) (φ : ℝ)
    (SafePost : ArithRAMMemory → Prop)
    (GoodPre : Prop) (GoodPost : ArithRAMMemory → Prop)
    (costBound : ℕ) : Prop :=
  ∃ (Post : (Fin B → Bool) → ArithRAMMemory → Prop)
    (Bad : (Fin B → Bool) → Prop) (_ : DecidablePred Bad),
    RandExecAt 0 inp s B mem₀ Post costBound ∧
    ((Finset.univ.filter Bad).card : ℝ) ≤ φ * ((2 : ℝ) ^ B) ∧
    ∀ (bits : Fin B → Bool) (m₁ : ArithRAMMemory),
      Post bits m₁ →
        m₁.popDepth 0 = m₁ ∧ SafePost m₁ ∧ (GoodPre → ¬ Bad bits → GoodPost m₁)

theorem RandExecWithBad.mono {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {B : ℕ} {mem₀ : ArithRAMMemory} {φ₁ φ₂ : ℝ}
    {Safe₁ Safe₂ : ArithRAMMemory → Prop}
    {GoodPre₁ GoodPre₂ : Prop}
    {Good₁ Good₂ : ArithRAMMemory → Prop}
    {C₁ C₂ : ℕ}
    (h : RandExecWithBad inp s B mem₀ φ₁ Safe₁ GoodPre₁ Good₁ C₁)
    (hφ : φ₁ ≤ φ₂)
    (hC : C₁ ≤ C₂)
    (hSafe : ∀ m, m.popDepth 0 = m → Safe₁ m → Safe₂ m)
    (hPre : GoodPre₂ → GoodPre₁)
    (hGood : ∀ m, m.popDepth 0 = m → Safe₁ m → GoodPre₂ → Good₁ m → Good₂ m) :
    RandExecWithBad inp s B mem₀ φ₂ Safe₂ GoodPre₂ Good₂ C₂ := by
  rcases h with ⟨Post, Bad, hdec, hex, hcard, hpost⟩
  refine ⟨Post, Bad, hdec, hex.mono (fun _ _ hp => hp) hC,
    hcard.trans (mul_le_mul_of_nonneg_right hφ (by positivity)), ?_⟩
  intro bits m₁ hp
  rcases hpost bits m₁ hp with ⟨hpop, hs₁, hg₁⟩
  exact ⟨hpop, hSafe m₁ hpop hs₁, fun hpre₂ hnb =>
    hGood m₁ hpop hs₁ hpre₂ (hg₁ (hPre hpre₂) hnb)⟩

theorem RandExecWithBad.congr_bits {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {B₁ B₂ : ℕ} {mem₀ : ArithRAMMemory} {φ₁ φ₂ : ℝ}
    {SafePost : ArithRAMMemory → Prop}
    {GoodPre : Prop} {GoodPost : ArithRAMMemory → Prop}
    {C₁ C₂ : ℕ}
    (h : RandExecWithBad inp s B₁ mem₀ φ₁ SafePost GoodPre GoodPost C₁)
    (hB : B₁ = B₂) (hφ : φ₁ ≤ φ₂) (hC : C₁ ≤ C₂) :
    RandExecWithBad inp s B₂ mem₀ φ₂ SafePost GoodPre GoodPost C₂ := by
  subst hB
  exact h.mono hφ hC (fun _ _ hs => hs) id (fun _ _ _ _ hg => hg)

theorem RandExecWithBad.of_det {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {mem₀ mem₁ : ArithRAMMemory} {C : ℕ}
    {SafePost : ArithRAMMemory → Prop}
    {GoodPre : Prop} {GoodPost : ArithRAMMemory → Prop}
    (hdet : DetExecAt 0 inp s mem₀ mem₁ C)
    (hpop : mem₁.popDepth 0 = mem₁)
    (hSafe : SafePost mem₁)
    (hGood : GoodPre → GoodPost mem₁) :
    RandExecWithBad inp s 0 mem₀ 0 SafePost GoodPre GoodPost C := by
  refine ⟨fun _ m => m = mem₁, fun _ => False, inferInstance,
    RandExecAt.of_det hdet, by simp, ?_⟩
  intro _ m₁ hm
  subst hm
  exact ⟨hpop, hSafe, fun hg _ => hGood hg⟩

/-- Lifts a zero-bad-event `B`-bit execution (such as `exec_runHPJOnSlotStmt_inactive`,
`exec_runBaselineSlotStmt_inactive`, or `exec_randDummyBitsStmt`) into `RandExecWithBad`
for any `0 ≤ φ`. -/
theorem RandExecWithBad.of_pad {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {B C : ℕ} {mem₀ : ArithRAMMemory} {φ : ℝ}
    {Post : (Fin B → Bool) → ArithRAMMemory → Prop}
    {SafePost : ArithRAMMemory → Prop}
    {GoodPre : Prop} {GoodPost : ArithRAMMemory → Prop}
    (hφ : 0 ≤ φ)
    (hex : RandExecAt 0 inp s B mem₀ Post C)
    (hpost : ∀ bits m₁, Post bits m₁ →
      m₁.popDepth 0 = m₁ ∧ SafePost m₁ ∧ (GoodPre → GoodPost m₁)) :
    RandExecWithBad inp s B mem₀ φ SafePost GoodPre GoodPost C := by
  refine ⟨Post, fun _ => False, inferInstance, hex, ?_, ?_⟩
  · simp only [Finset.filter_false, Finset.card_empty, Nat.cast_zero]
    exact mul_nonneg hφ (by positivity)
  · intro bits m₁ hp
    rcases hpost bits m₁ hp with ⟨hpop, hs, hg⟩
    exact ⟨hpop, hs, fun hpre _ => hg hpre⟩

theorem RandExecWithBad.ite {d : ℕ} {inp : ArithRAMInput d}
    {cond : ArithCondExpr} {tB fB : ArithRAMStmt}
    {B C_c C : ℕ} {mem₀ : ArithRAMMemory} {φ : ℝ}
    {SafePost : ArithRAMMemory → Prop}
    {GoodPre : Prop} {GoodPost : ArithRAMMemory → Prop}
    (hcost_c : condExprOps cond ≤ C_c)
    (ht : cValAt 0 inp mem₀ cond = true →
      RandExecWithBad inp tB B mem₀ φ SafePost GoodPre GoodPost C)
    (hf : cValAt 0 inp mem₀ cond = false →
      RandExecWithBad inp fB B mem₀ φ SafePost GoodPre GoodPost C) :
    RandExecWithBad inp (.ite cond tB fB) B mem₀ φ SafePost GoodPre GoodPost (C_c + C) := by
  cases hc : cValAt 0 inp mem₀ cond with
  | true =>
      rcases ht hc with ⟨Post, Bad, hdec, hex, hcard, hpost⟩
      exact ⟨Post, Bad, hdec, RandExecAt.ite_true hc hcost_c hex, hcard, hpost⟩
  | false =>
      rcases hf hc with ⟨Post, Bad, hdec, hex, hcard, hpost⟩
      exact ⟨Post, Bad, hdec, RandExecAt.ite_false hc hcost_c hex, hcard, hpost⟩

theorem RandExecWithBad.seq_det_left {d : ℕ} {inp : ArithRAMInput d}
    {s₁ s₂ : ArithRAMStmt} {B C₁ C₂ : ℕ} {mem₀ mem₁ : ArithRAMMemory} {φ : ℝ}
    {SafePost : ArithRAMMemory → Prop}
    {GoodPre : Prop} {GoodPost : ArithRAMMemory → Prop}
    (h₁ : DetExecAt 0 inp s₁ mem₀ mem₁ C₁)
    (h₂ : RandExecWithBad inp s₂ B mem₁ φ SafePost GoodPre GoodPost C₂) :
    RandExecWithBad inp (.seq s₁ s₂) B mem₀ φ SafePost GoodPre GoodPost (C₁ + C₂) := by
  rcases h₂ with ⟨Post, Bad, hdec, hex₂, hcard, hpost⟩
  exact ⟨Post, Bad, hdec, RandExecAt.seq_det_left h₁ hex₂, hcard, hpost⟩

theorem RandExecWithBad.seq_det_right {d : ℕ} {inp : ArithRAMInput d}
    {s₁ s₂ : ArithRAMStmt} {B C₁ C₂ : ℕ} {mem₀ : ArithRAMMemory} {φ : ℝ}
    {SafeMid SafePost : ArithRAMMemory → Prop}
    {GoodPre : Prop} {GoodMid GoodPost : ArithRAMMemory → Prop}
    (h₁ : RandExecWithBad inp s₁ B mem₀ φ SafeMid GoodPre GoodMid C₁)
    (h₂ : ∀ m₁, m₁.popDepth 0 = m₁ → SafeMid m₁ →
      ∃ m₂, DetExecAt 0 inp s₂ m₁ m₂ C₂ ∧
        m₂.popDepth 0 = m₂ ∧ SafePost m₂ ∧
        (GoodPre → GoodMid m₁ → GoodPost m₂)) :
    RandExecWithBad inp (.seq s₁ s₂) B mem₀ φ SafePost GoodPre GoodPost (C₁ + C₂) := by
  rcases h₁ with ⟨Post₁, Bad₁, hdec₁, hex₁, hcard₁, hpost₁⟩
  let Post₂ : (Fin B → Bool) → ArithRAMMemory → Prop := fun f m₂ =>
    ∃ m₁, Post₁ f m₁ ∧
      m₂.popDepth 0 = m₂ ∧ SafePost m₂ ∧ (GoodPre → GoodMid m₁ → GoodPost m₂)
  refine ⟨Post₂, Bad₁, hdec₁, RandExecAt.seq_det_right hex₁ ?_, hcard₁, ?_⟩
  · intro f m₁ hp₁
    rcases hpost₁ f m₁ hp₁ with ⟨hpop₁, hs₁, _⟩
    rcases h₂ m₁ hpop₁ hs₁ with ⟨m₂, hd₂, hpop₂, hs₂, hg₂⟩
    exact ⟨m₂, hd₂, ⟨m₁, hp₁, hpop₂, hs₂, hg₂⟩⟩
  · rintro bits m₂ ⟨m₁, hp₁, hpop₂, hs₂, hg₂⟩
    rcases hpost₁ bits m₁ hp₁ with ⟨_, _, hg₁⟩
    exact ⟨hpop₂, hs₂, fun hpre hnb => hg₂ hpre (hg₁ hpre hnb)⟩

/-- Adaptive sequential composition of two `RandExecWithBad` blocks: adds bit counts `B₁ + B₂`,
adds failure budgets `φ₁ + φ₂`, and adds work bounds `C₁ + C₂`! -/
theorem RandExecWithBad.seq {d T_max M_box : ℕ} {inp : ArithRAMInput d}
    {s₁ s₂ : ArithRAMStmt} {B₁ B₂ C₁ C₂ : ℕ} {mem₀ : ArithRAMMemory} {φ₁ φ₂ : ℝ}
    {SafeMid SafePost : ArithRAMMemory → Prop}
    {GoodPre : Prop} {GoodMid GoodPost : ArithRAMMemory → Prop}
    (hs₁ : BoxSafeOuter T_max M_box s₁)
    (hmem₀ : mem₀.popDepth 0 = mem₀)
    (hφ₂ : 0 ≤ φ₂)
    (h₁ : RandExecWithBad inp s₁ B₁ mem₀ φ₁ SafeMid GoodPre GoodMid C₁)
    (h₂ : ∀ m₁, m₁.popDepth 0 = m₁ → SafeMid m₁ →
      RandExecWithBad inp s₂ B₂ m₁ φ₂ SafePost (GoodPre ∧ GoodMid m₁) GoodPost C₂) :
    RandExecWithBad inp (.seq s₁ s₂) (B₁ + B₂) mem₀ (φ₁ + φ₂)
      SafePost GoodPre GoodPost (C₁ + C₂) := by
  classical
  rcases h₁ with ⟨Post₁, Bad₁, _, hex₁, hcard₁, hpost₁⟩
  rcases RandExecAt.tighten_outer hs₁.to_outerClean hmem₀ hex₁
      (fun f m hm => (hpost₁ f m hm).1)
    with ⟨fn₁, hfn₁_ok, hex₁'⟩
  have hex₂_all : ∀ f₁ : Fin B₁ → Bool,
      ∃ (Post₂ : (Fin B₂ → Bool) → ArithRAMMemory → Prop)
        (Bad₂ : (Fin B₂ → Bool) → Prop),
        RandExecAt 0 inp s₂ B₂ (fn₁ f₁) Post₂ C₂ ∧
        ((Finset.univ.filter Bad₂).card : ℝ) ≤ φ₂ * ((2 : ℝ) ^ B₂) ∧
        ∀ (f₂ : Fin B₂ → Bool) (m₂ : ArithRAMMemory),
          Post₂ f₂ m₂ →
            m₂.popDepth 0 = m₂ ∧ SafePost m₂ ∧
            ((GoodPre ∧ GoodMid (fn₁ f₁)) → ¬ Bad₂ f₂ → GoodPost m₂) := by
    intro f₁
    have hp₁ := (hfn₁_ok f₁).2
    rcases hpost₁ f₁ (fn₁ f₁) hp₁ with ⟨hpop₁, hs_mid₁, _⟩
    rcases h₂ (fn₁ f₁) hpop₁ hs_mid₁ with ⟨P₂, B₂_pred, _, hx₂, hc₂, hp₂⟩
    exact ⟨P₂, B₂_pred, hx₂, by rwa [Finset.filter_congr_decidable], hp₂⟩
  choose Post₂ Bad₂ hspec₂ using hex₂_all
  let PostSeq : (Fin (B₁ + B₂) → Bool) → ArithRAMMemory → Prop :=
    fun bits m₂ => Post₂ (splitLeftBits bits) (splitRightBits bits) m₂
  let BadSeq : (Fin (B₁ + B₂) → Bool) → Prop :=
    fun bits => Bad₁ (splitLeftBits bits) ∨ Bad₂ (splitLeftBits bits) (splitRightBits bits)
  have hex_seq : RandExecAt 0 inp (.seq s₁ s₂) (B₁ + B₂) mem₀ PostSeq (C₁ + C₂) := by
    refine RandExecAt.seq hex₁' ?_
    rintro f₁ m₁ ⟨rfl, _⟩
    refine (hspec₂ f₁).1.mono ?_ le_rfl
    intro f₂ m₂ hp₂
    change PostSeq (mergeBits f₁ f₂) m₂
    dsimp only [PostSeq]
    rw [splitLeftBits_mergeBits, splitRightBits_mergeBits]
    exact hp₂
  have hcard_seq :
      ((Finset.univ.filter BadSeq).card : ℝ) ≤ (φ₁ + φ₂) * ((2 : ℝ) ^ (B₁ + B₂)) :=
    bad_card_adaptive_seq Bad₁ Bad₂ hφ₂ hcard₁ (fun f₁ _ => (hspec₂ f₁).2.1)
  refine ⟨PostSeq, BadSeq, inferInstance, hex_seq, hcard_seq, ?_⟩
  intro bits m₂ hp_seq
  rcases (hspec₂ (splitLeftBits bits)).2.2 (splitRightBits bits) m₂ hp_seq
    with ⟨hpop₂, hs₂, hg₂⟩
  refine ⟨hpop₂, hs₂, fun hpre hnb => ?_⟩
  have hnb₁ : ¬ Bad₁ (splitLeftBits bits) := fun hb₁ => hnb (Or.inl hb₁)
  have hnb₂ : ¬ Bad₂ (splitLeftBits bits) (splitRightBits bits) := fun hb₂ => hnb (Or.inr hb₂)
  have hgm₁ : GoodMid (fn₁ (splitLeftBits bits)) :=
    (hpost₁ (splitLeftBits bits) _ (hfn₁_ok (splitLeftBits bits)).2).2.2 hpre hnb₁
  exact hg₂ ⟨hpre, hgm₁⟩ hnb₂

private noncomputable def iterStepFn {B : ℕ}
    (mem₀ : ArithRAMMemory)
    (stepFn : ℕ → ArithRAMMemory → (Fin B → Bool) → ArithRAMMemory) :
    ℕ → (ℕ → Fin B → Bool) → ArithRAMMemory
  | 0, _ => mem₀
  | k + 1, chunks => stepFn k (iterStepFn mem₀ stepFn k chunks) (chunks k)

/-- Adaptive `N`-iteration `.repeatN` loop combinator for `RandExecWithBad`: executes `N` adaptive
rounds of `body` (each using `B` bits, `φ_one` failure budget, and `C_b` work), producing `N * B`
bits, `(N : ℝ) * φ_one` failure budget, and `C_cnt + N * C_b` work! -/
theorem RandExecWithBad.repeatN_nat {d T_max M_box : ℕ} {inp : ArithRAMInput d}
    (countE : IntExpr) (body : ArithRAMStmt) (N B C_cnt C_b : ℕ)
    {mem₀ : ArithRAMMemory} {φ_one : ℝ}
    (SafeInv : ℕ → ArithRAMMemory → Prop)
    (GoodInv : ℕ → ArithRAMMemory → Prop)
    (hbody : BoxSafeOuter T_max M_box body)
    (hmem₀ : mem₀.popDepth 0 = mem₀)
    (hφ : 0 ≤ φ_one)
    (hSafe₀ : SafeInv 0 mem₀)
    (hcnt : iValAt 0 inp mem₀ countE = (N : ℤ))
    (hccnt : intExprOps countE ≤ C_cnt)
    (hstep : ∀ i < N, ∀ m, m.popDepth 0 = m → SafeInv i m →
      RandExecWithBad inp body B m φ_one (SafeInv (i + 1)) (GoodInv i m) (GoodInv (i + 1)) C_b) :
    RandExecWithBad inp (.repeatN countE body) (N * B) mem₀ ((N : ℝ) * φ_one)
      (SafeInv N) (GoodInv 0 mem₀) (GoodInv N) (C_cnt + N * C_b) := by
  classical
  have hex_step : ∀ (i : ℕ) (m : ArithRAMMemory),
      (i < N ∧ m.popDepth 0 = m ∧ SafeInv i m) →
      ∃ (fn : (Fin B → Bool) → ArithRAMMemory)
        (Bad : (Fin B → Bool) → Prop),
        RandExecAt 0 inp body B m (fun b m' => m' = fn b) C_b ∧
        ((Finset.univ.filter Bad).card : ℝ) ≤ φ_one * ((2 : ℝ) ^ B) ∧
        ∀ b : Fin B → Bool,
          (fn b).popDepth 0 = fn b ∧
          SafeInv (i + 1) (fn b) ∧
          (GoodInv i m → ¬ Bad b → GoodInv (i + 1) (fn b)) := by
    rintro i m ⟨hi, hpop, hsi⟩
    rcases hstep i hi m hpop hsi with ⟨P_i, B_i, _, hx_i, hc_i, hp_i⟩
    rcases RandExecAt.tighten_outer hbody.to_outerClean hpop hx_i
        (fun b m' hm' => (hp_i b m' hm').1)
      with ⟨fn_i, hfn_ok, hx_i'⟩
    refine ⟨fn_i, B_i, hx_i'.mono (fun _ _ h => h.1) le_rfl, by rwa [Finset.filter_congr_decidable], fun b => ?_⟩
    exact hp_i b (fn_i b) (hfn_ok b).2
  let stepFn : ℕ → ArithRAMMemory → (Fin B → Bool) → ArithRAMMemory :=
    fun i m =>
      if h : i < N ∧ m.popDepth 0 = m ∧ SafeInv i m then (hex_step i m h).choose
      else fun _ => m
  let stepBad : ℕ → ArithRAMMemory → (Fin B → Bool) → Prop :=
    fun i m =>
      if h : i < N ∧ m.popDepth 0 = m ∧ SafeInv i m then (hex_step i m h).choose_spec.choose
      else fun _ => False
  have hstep_props : ∀ (i : ℕ) (m : ArithRAMMemory)
      (h : i < N ∧ m.popDepth 0 = m ∧ SafeInv i m),
      RandExecAt 0 inp body B m (fun b m' => m' = stepFn i m b) C_b ∧
      ((Finset.univ.filter (stepBad i m)).card : ℝ) ≤ φ_one * ((2 : ℝ) ^ B) ∧
      ∀ b : Fin B → Bool,
        (stepFn i m b).popDepth 0 = stepFn i m b ∧
        SafeInv (i + 1) (stepFn i m b) ∧
        (GoodInv i m → ¬ stepBad i m b → GoodInv (i + 1) (stepFn i m b)) := by
    intro i m h
    dsimp only [stepFn, stepBad]
    rw [dif_pos h, dif_pos h]
    exact (hex_step i m h).choose_spec.choose_spec
  have htraj_congr : ∀ (k : ℕ) (c₁ c₂ : ℕ → Fin B → Bool),
      (∀ j < k, c₁ j = c₂ j) → iterStepFn mem₀ stepFn k c₁ = iterStepFn mem₀ stepFn k c₂ := by
    intro k
    induction k with
    | zero => intros; rfl
    | succ k ih =>
        intro c₁ c₂ heq
        dsimp only [iterStepFn]
        rw [ih c₁ c₂ (fun j hj => heq j (Nat.lt_succ_of_lt hj)), heq k (Nat.lt_succ_self k)]
  have htraj_safe : ∀ (k : ℕ), k ≤ N → ∀ chunks,
      (iterStepFn mem₀ stepFn k chunks).popDepth 0 = iterStepFn mem₀ stepFn k chunks ∧ SafeInv k (iterStepFn mem₀ stepFn k chunks) := by
    intro k hk chunks
    induction k with
    | zero => exact ⟨hmem₀, hSafe₀⟩
    | succ k ih =>
        have hk_lt : k < N := Nat.lt_of_succ_le hk
        rcases ih (le_of_lt hk_lt) with ⟨hp_k, hs_k⟩
        have hsp := (hstep_props k (iterStepFn mem₀ stepFn k chunks) ⟨hk_lt, hp_k, hs_k⟩).2.2 (chunks k)
        exact ⟨hsp.1, hsp.2.1⟩
  let Inv : ℕ → (ℕ → Fin B → Bool) → ArithRAMMemory → Prop :=
    fun k chunks m => m = iterStepFn mem₀ stepFn k chunks
  have hrep := RandExecAt.repeatN_nat countE body N B C_cnt C_b Inv
    (chunks₀ := fun _ _ => false) rfl hcnt hccnt
    (fun i hi chunks m hm => by
      subst hm
      rcases htraj_safe i (le_of_lt hi) chunks with ⟨hp_i, hs_i⟩
      refine ((hstep_props i (iterStepFn mem₀ stepFn i chunks) ⟨hi, hp_i, hs_i⟩).1).mono ?_ le_rfl
      intro b m' hm'
      dsimp only [Inv, iterStepFn]
      rw [htraj_congr i (Function.update chunks i b) chunks
          (fun j hj => Function.update_of_ne (by omega) _ _),
        Function.update_self]
      exact hm')
  let chunksOf : ∀ k : ℕ, (Fin (k * B) → Bool) → (ℕ → Fin B → Bool) :=
    fun k bits r j =>
      if hr : r < k then
        bits ⟨r * B + j.val, by
          calc r * B + j.val < r * B + B := by omega
            _ = (r + 1) * B := by ring
            _ ≤ k * B := Nat.mul_le_mul_right B hr⟩
      else false
  let prefixBad : ∀ k : ℕ, (Fin (k * B) → Bool) → Prop :=
    fun k bits => ∃ r : Fin k,
      stepBad r.val (iterStepFn mem₀ stepFn r.val (chunksOf k bits)) (chunksOf k bits r.val)
  have hcard_k : ∀ k ≤ N,
      ((Finset.univ.filter (prefixBad k)).card : ℝ) ≤ ((k : ℝ) * φ_one) * ((2 : ℝ) ^ (k * B)) := by
    intro k hk
    induction k with
    | zero =>
        have hempty : Finset.univ.filter (prefixBad 0) = ∅ := by
          ext bits; simp [prefixBad]
        rw [hempty]; simp
    | succ k ih =>
        have hk_lt : k < N := Nat.lt_of_succ_le hk
        let Bad₂_k : (Fin (k * B) → Bool) → (Fin B → Bool) → Prop :=
          fun f₁ f₂ => stepBad k (iterStepFn mem₀ stepFn k (chunksOf k f₁)) f₂
        have h₂_card : ∀ f₁ : Fin (k * B) → Bool, ¬ prefixBad k f₁ →
            ((Finset.univ.filter (Bad₂_k f₁)).card : ℝ) ≤ φ_one * ((2 : ℝ) ^ B) := by
          intro f₁ _
          rcases htraj_safe k (le_of_lt hk_lt) (chunksOf k f₁) with ⟨hp_k, hs_k⟩
          exact (hstep_props k (iterStepFn mem₀ stepFn k (chunksOf k f₁)) ⟨hk_lt, hp_k, hs_k⟩).2.1
        have hseq_k := bad_card_adaptive_seq (prefixBad k) Bad₂_k hφ (ih (le_of_lt hk_lt)) h₂_card
        have heq_len : (k + 1) * B = k * B + B := by ring
        let castBits : (Fin ((k + 1) * B) → Bool) → (Fin (k * B + B) → Bool) :=
          fun bits i => bits ⟨i.val, by have := i.isLt; omega⟩
        have hbij_cast :
            (Finset.univ.filter (prefixBad (k + 1))).card =
            (Finset.univ.filter (fun bits' : Fin (k * B + B) → Bool =>
              prefixBad k (splitLeftBits bits') ∨ Bad₂_k (splitLeftBits bits') (splitRightBits bits'))).card := by
          refine Finset.card_bij (fun bits _ => castBits bits) ?_ ?_ ?_
          · intro bits hbits
            have hp : prefixBad (k + 1) bits := (Finset.mem_filter.mp hbits).2
            refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
            rcases hp with ⟨r, hr_bad⟩
            have hch_pre : ∀ j < k + 1, j < k →
                chunksOf (k + 1) bits j = chunksOf k (splitLeftBits (castBits bits)) j := by
              intro j hj₁ hj₂
              ext b
              dsimp only [chunksOf, splitLeftBits, castBits]
              rw [dif_pos hj₁, dif_pos hj₂]
            by_cases hr_lt : r.val < k
            · left
              refine ⟨⟨r.val, hr_lt⟩, ?_⟩
              have htr_eq : iterStepFn mem₀ stepFn r.val (chunksOf (k + 1) bits) =
                  iterStepFn mem₀ stepFn r.val (chunksOf k (splitLeftBits (castBits bits))) :=
                htraj_congr r.val _ _ (fun j hj => hch_pre j (by omega) (by omega))
              have hchunk_eq := hch_pre r.val r.isLt hr_lt
              simpa only [htr_eq, hchunk_eq] using hr_bad
            · right
              have hr_eq : r.val = k := by omega
              have htr_eq : iterStepFn mem₀ stepFn k (chunksOf (k + 1) bits) =
                  iterStepFn mem₀ stepFn k (chunksOf k (splitLeftBits (castBits bits))) :=
                htraj_congr k _ _ (fun j hj => hch_pre j (by omega) hj)
              have hchunk_k : chunksOf (k + 1) bits k = splitRightBits (castBits bits) := by
                ext b
                dsimp only [chunksOf, splitRightBits, castBits]
                rw [dif_pos (Nat.lt_succ_self k)]
              rw [hr_eq, htr_eq, hchunk_k] at hr_bad
              exact hr_bad
          · intro b₁ _ b₂ _ heq
            ext i
            exact congrFun heq ⟨i.val, by have := i.isLt; omega⟩
          · intro bits' hbits'
            let uncast : Fin ((k + 1) * B) → Bool := fun i => bits' ⟨i.val, by have := i.isLt; omega⟩
            have hcast_uncast : castBits uncast = bits' := by ext i; rfl
            refine ⟨uncast, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, hcast_uncast⟩
            have hch_pre : ∀ j < k,
                chunksOf (k + 1) uncast j = chunksOf k (splitLeftBits bits') j := by
              intro j hj
              ext b
              dsimp only [chunksOf, uncast, splitLeftBits]
              rw [dif_pos (Nat.lt_succ_of_lt hj), dif_pos hj]
            rcases (Finset.mem_filter.mp hbits').2 with ⟨r, hr_bad⟩ | hr_k
            · refine ⟨⟨r.val, Nat.lt_succ_of_lt r.isLt⟩, ?_⟩
              have htr_eq : iterStepFn mem₀ stepFn r.val (chunksOf (k + 1) uncast) =
                  iterStepFn mem₀ stepFn r.val (chunksOf k (splitLeftBits bits')) :=
                htraj_congr r.val _ _ (fun j hj => hch_pre j (lt_trans hj r.isLt))
              simpa only [htr_eq, hch_pre r.val r.isLt] using hr_bad
            · refine ⟨⟨k, Nat.lt_succ_self k⟩, ?_⟩
              have htr_eq : iterStepFn mem₀ stepFn k (chunksOf (k + 1) uncast) =
                  iterStepFn mem₀ stepFn k (chunksOf k (splitLeftBits bits')) :=
                htraj_congr k _ _ hch_pre
              have hchunk_k : chunksOf (k + 1) uncast k = splitRightBits bits' := by
                ext b
                dsimp only [chunksOf, uncast, splitRightBits]
                rw [dif_pos (Nat.lt_succ_self k)]
              dsimp only [Bad₂_k] at hr_k
              simpa only [htr_eq, hchunk_k] using hr_k
        rw [hbij_cast]
        calc ((Finset.univ.filter (fun bits' : Fin (k * B + B) → Bool =>
                prefixBad k (splitLeftBits bits') ∨
                  Bad₂_k (splitLeftBits bits') (splitRightBits bits'))).card : ℝ)
            ≤ ((k : ℝ) * φ_one + φ_one) * ((2 : ℝ) ^ (k * B + B)) := hseq_k
          _ = (((k + 1 : ℕ) : ℝ) * φ_one) * ((2 : ℝ) ^ ((k + 1) * B)) := by
              rw [heq_len]; push_cast; ring
  refine ⟨_, prefixBad N, inferInstance, hrep, hcard_k N le_rfl, ?_⟩
  rintro bits m_N ⟨chunks_N, hm_eq, hchunks_eq⟩
  have htr_eq_N : ∀ k ≤ N, iterStepFn mem₀ stepFn k chunks_N = iterStepFn mem₀ stepFn k (chunksOf N bits) := by
    intro k hk
    refine htraj_congr k chunks_N (chunksOf N bits) (fun j hj => ?_)
    have hjN : j < N := lt_of_lt_of_le hj hk
    rw [hchunks_eq ⟨j, hjN⟩]
    ext b
    dsimp only [chunksOf]
    rw [dif_pos hjN]
  rw [hm_eq, htr_eq_N N le_rfl]
  rcases htraj_safe N le_rfl (chunksOf N bits) with ⟨hpop_N, hsafe_N⟩
  refine ⟨hpop_N, hsafe_N, fun hgood₀ hnb => ?_⟩
  have hgood_all : ∀ k ≤ N, GoodInv k (iterStepFn mem₀ stepFn k (chunksOf N bits)) := by
    intro k hk
    induction k with
    | zero => exact hgood₀
    | succ k ih =>
        have hk_lt : k < N := Nat.lt_of_succ_le hk
        rcases htraj_safe k (le_of_lt hk_lt) (chunksOf N bits) with ⟨hp_k, hs_k⟩
        have hnb_k : ¬ stepBad k (iterStepFn mem₀ stepFn k (chunksOf N bits)) (chunksOf N bits k) :=
          fun hb => hnb ⟨⟨k, hk_lt⟩, hb⟩
        exact ((hstep_props k (iterStepFn mem₀ stepFn k (chunksOf N bits)) ⟨hk_lt, hp_k, hs_k⟩).2.2
          (chunksOf N bits k)).2.2 (ih (le_of_lt hk_lt)) hnb_k
  exact hgood_all N le_rfl

/-- Per-step bit-count and failure-budget alignment for `P46Params`: combines
`p.D₀` job HPJ calls (`p.B_hpj` bits, `2 * p.φ_ev` each),
`20 * (d + 3)^2` sync-split HPJ calls (`p.B_hpj` bits, `2 * p.φ_ev` each), and
`p.D₀` baseline calls (`p.K₀ * p.M_bits` bits, `2 * p.φ_ev` each)
into `p.B_step` bits and `((2 * p.D₀ + 20 * (d + 3)^2 + 2 : ℕ) : ℝ) * (2 * p.φ_ev)`
(bounded by `perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ`)! -/
theorem p46_step_bits_and_budget {d n t : ℕ} {δ : ℝ} (p : P46Params d n)
    (hφ0 : 0 ≤ p.φ_ev)
    (hBstep : p.B_step = (p.D₀ + 20 * (d + 3) ^ 2) * p.B_hpj + p.D₀ * p.K₀ * p.M_bits)
    (hfb : ((2 * p.D₀ + 20 * (d + 3) ^ 2 + 2 : ℕ) : ℝ) * (2 * p.φ_ev) ≤
      perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ) :
    (p.D₀ * p.B_hpj + 20 * (d + 3) ^ 2 * p.B_hpj) + p.D₀ * (p.K₀ * p.M_bits) = p.B_step ∧
    (((p.D₀ : ℝ) * (2 * p.φ_ev) + ((20 * (d + 3) ^ 2 : ℕ) : ℝ) * (2 * p.φ_ev)) +
      (p.D₀ : ℝ) * (2 * p.φ_ev)) ≤
      ((2 * p.D₀ + 20 * (d + 3) ^ 2 + 2 : ℕ) : ℝ) * (2 * p.φ_ev) ∧
    (((p.D₀ : ℝ) * (2 * p.φ_ev) + ((20 * (d + 3) ^ 2 : ℕ) : ℝ) * (2 * p.φ_ev)) +
      (p.D₀ : ℝ) * (2 * p.φ_ev)) ≤
      perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ := by
  have hbits : (p.D₀ * p.B_hpj + 20 * (d + 3) ^ 2 * p.B_hpj) + p.D₀ * (p.K₀ * p.M_bits) = p.B_step := by
    rw [hBstep]; ring
  have hbud :
      (((p.D₀ : ℝ) * (2 * p.φ_ev) + ((20 * (d + 3) ^ 2 : ℕ) : ℝ) * (2 * p.φ_ev)) +
        (p.D₀ : ℝ) * (2 * p.φ_ev)) ≤
      ((2 * p.D₀ + 20 * (d + 3) ^ 2 + 2 : ℕ) : ℝ) * (2 * p.φ_ev) := by
    have h1 :
        (((p.D₀ : ℝ) * (2 * p.φ_ev) + ((20 * (d + 3) ^ 2 : ℕ) : ℝ) * (2 * p.φ_ev)) +
          (p.D₀ : ℝ) * (2 * p.φ_ev)) =
        ((2 * p.D₀ + 20 * (d + 3) ^ 2 : ℕ) : ℝ) * (2 * p.φ_ev) := by
      push_cast; ring
    rw [h1]
    have hle_nat :
        ((2 * p.D₀ + 20 * (d + 3) ^ 2 : ℕ) : ℝ) ≤
        ((2 * p.D₀ + 20 * (d + 3) ^ 2 + 2 : ℕ) : ℝ) := by
      exact_mod_cast Nat.le_add_right _ 2
    exact mul_le_mul_of_nonneg_right hle_nat (by linarith)
  exact ⟨hbits, hbud, hbud.trans hfb⟩

end UL.Proof_lem_7_2_RacerP46
