import Mathlib
import UL.Stmt.lem_C_2
import UL.Proof.lem_7_2.RacerP46_H4a_SlotGCAndPureHist

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Pure Serving-Chain Routing Lemmas (`chainInput` & `chainTerminal` across Insert / Delete) -/

lemma cg02_chainInput_zero {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι) :
    chainInput pts nodes S₀ ⟨0, Nat.zero_lt_succ k⟩ = S₀ :=
  rfl

lemma cg02_chainInput_succ {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι)
    (r : ℕ) (hr : r < k) :
    chainInput pts nodes S₀ ⟨r + 1, Nat.succ_lt_succ hr⟩ =
      (nodes ⟨r, hr⟩).residual pts (chainInput pts nodes S₀ ⟨r, Nat.lt_succ_of_lt hr⟩) :=
  rfl

lemma cg02_chainTerminal_eq {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι) :
    chainTerminal pts nodes S₀ = chainInput pts nodes S₀ ⟨k, Nat.lt_succ_self k⟩ :=
  rfl

lemma cg02_chainInput_subset_aux {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι) :
    ∀ (m : ℕ) (hm : m ≤ k),
      chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm⟩ ⊆ S₀
  | 0, _ => Finset.Subset.refl S₀
  | m + 1, hm => by
      classical
      rw [cg02_chainInput_succ pts nodes S₀ m (Nat.lt_of_succ_le hm)]
      exact Finset.sdiff_subset.trans (cg02_chainInput_subset_aux pts nodes S₀ m (Nat.le_of_succ_le hm))

lemma cg02_chainInput_subset {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι)
    (j : Fin (k + 1)) :
    chainInput pts nodes S₀ j ⊆ S₀ :=
  cg02_chainInput_subset_aux pts nodes S₀ j.val (Nat.lt_succ_iff.mp j.isLt)

lemma cg02_chainTerminal_subset {d k : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (S₀ : Finset ι) :
    chainTerminal pts nodes S₀ ⊆ S₀ :=
  cg02_chainInput_subset pts nodes S₀ (Fin.last k)

lemma cg02_chainInput_congr_aux {d k : ℕ} {ι : Type} [DecidableEq ι]
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    (nodes : Fin k → ChainNode d) {S₀ : Finset ι}
    (h_on : ∀ x ∈ S₀, pts' x = pts x) :
    ∀ (m : ℕ) (hm : m ≤ k),
      chainInput pts' nodes S₀ ⟨m, Nat.lt_succ_of_le hm⟩ =
        chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm⟩
  | 0, _ => rfl
  | m + 1, hm => by
      have hm_lt : m < k := Nat.lt_of_succ_le hm
      have hm_le : m ≤ k := Nat.le_of_succ_le hm
      rw [cg02_chainInput_succ pts' nodes S₀ m hm_lt,
          cg02_chainInput_succ pts nodes S₀ m hm_lt,
          cg02_chainInput_congr_aux nodes h_on m hm_le]
      exact nodeResidual_congr_on (nodes ⟨m, hm_lt⟩) _
        (fun x hx => h_on x (cg02_chainInput_subset_aux pts nodes S₀ m hm_le hx))

lemma cg02_chainInput_congr_on {d k : ℕ} {ι : Type} [DecidableEq ι]
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    (nodes : Fin k → ChainNode d) {S₀ : Finset ι}
    (h_on : ∀ x ∈ S₀, pts' x = pts x) (j : Fin (k + 1)) :
    chainInput pts' nodes S₀ j = chainInput pts nodes S₀ j :=
  cg02_chainInput_congr_aux nodes h_on j.val (Nat.lt_succ_iff.mp j.isLt)

/-- Unconditional deletion identity along a serving chain: erasing `h` from `S₀` (while preserving
coordinates on `S₀.erase h`) erases `h` from every intermediate input `chainInput _ _ _ j`. -/
lemma cg02_chainInput_erase_aux {d k : ℕ} {ι : Type} [DecidableEq ι]
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    (nodes : Fin k → ChainNode d) {S₀ : Finset ι} {h : ι}
    (h_on : ∀ x ∈ S₀.erase h, pts' x = pts x) :
    ∀ (m : ℕ) (hm : m ≤ k),
      chainInput pts' nodes (S₀.erase h) ⟨m, Nat.lt_succ_of_le hm⟩ =
        (chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm⟩).erase h
  | 0, _ => rfl
  | m + 1, hm => by
      have hm_lt : m < k := Nat.lt_of_succ_le hm
      have hm_le : m ≤ k := Nat.le_of_succ_le hm
      rw [cg02_chainInput_succ pts' nodes (S₀.erase h) m hm_lt,
          cg02_chainInput_succ pts nodes S₀ m hm_lt,
          cg02_chainInput_erase_aux nodes h_on m hm_le]
      have hsub : (chainInput pts nodes S₀ ⟨m, Nat.lt_succ_of_le hm_le⟩).erase h ⊆ S₀.erase h :=
        Finset.erase_subset_erase h (cg02_chainInput_subset_aux pts nodes S₀ m hm_le)
      rw [nodeResidual_congr_on (nodes ⟨m, hm_lt⟩) _ (fun x hx => h_on x (hsub hx)),
          nodeResidual_erase_uncond]

lemma cg02_chainInput_erase {d k : ℕ} {ι : Type} [DecidableEq ι]
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    (nodes : Fin k → ChainNode d) {S₀ : Finset ι} {h : ι}
    (h_on : ∀ x ∈ S₀.erase h, pts' x = pts x) (j : Fin (k + 1)) :
    chainInput pts' nodes (S₀.erase h) j = (chainInput pts nodes S₀ j).erase h :=
  cg02_chainInput_erase_aux nodes h_on j.val (Nat.lt_succ_iff.mp j.isLt)

/-- One-step insertion propagation across a serving node `N`: inserting `h ∉ S` (while preserving
coordinates on `S`) either absorbs `h` into `N.core` when `‖pts' h - N.o‖^2 ≤ N.V` (leaving the
residual equal to `N.residual pts S`), or passes `insert h (N.residual pts S)` downstream. -/
lemma cg02_nodeResidual_insert_step {d : ℕ} {ι : Type} [DecidableEq ι]
    {pts pts' : ι → EuclideanSpace ℝ (Fin d)}
    (N : ChainNode d) {S : Finset ι} {h : ι}
    (h_on : ∀ x ∈ S, pts' x = pts x) :
    N.residual pts' (insert h S) =
      if euclideanDistSq (pts' h) N.o ≤ N.V then N.residual pts S
      else insert h (N.residual pts S) := by
  rw [nodeResidual_insert pts' N S h, nodeResidual_congr_on N S h_on]

lemma cg02_hasNodeAge_opt_step {ι : Type} {P₀ S S' : Finset ι} {a : ℕ} {aff : Bool}
    (hage : HasNodeAge P₀ S a)
    (h0 : aff = false → S' = S)
    (h1 : aff = true → IsInputChange S S') :
    ∃ a' ≤ (if aff then a + 1 else a), HasNodeAge P₀ S' a' := by
  cases aff with
  | false =>
      rw [h0 rfl]
      exact ⟨a, le_rfl, hage⟩
  | true =>
      exact ⟨a + 1, le_rfl, hasNodeAge_step hage (h1 rfl)⟩

/-! ### 2. RAM Memory Layout for Serving Nodes & `EncServingChain` -/

/-- Box-footprint conditions sufficient for `routeLiveUpdateStmt` at heap bound `M_box`. -/
def RouteBoxBounds (d n K D₀ NumSlots M_box : ℕ) : Prop :=
  30 ≤ M_box ∧
  D₀ ≤ M_box ∧
  n ≤ M_box ∧
  n * d ≤ M_box ∧
  NumSlots * n ≤ M_box ∧
  NumSlots * n * d ≤ M_box ∧
  NumSlots * 2 ^ (K + 1) ≤ M_box

/-- Canonical minimal box size `M_box` covering all heap offsets accessed by `routeLiveUpdateStmt`. -/
def routeMinBox (d n K D₀ NumSlots : ℕ) : ℕ :=
  max 30 (max D₀ (max ((NumSlots + 1) * n * (d + 1)) (NumSlots * 2 ^ (K + 1))))

lemma routeBoxBounds_of_ge {d n K D₀ NumSlots M_box : ℕ}
    (hge : routeMinBox d n K D₀ NumSlots ≤ M_box) :
    RouteBoxBounds d n K D₀ NumSlots M_box := by
  unfold routeMinBox at hge
  have h30 : 30 ≤ M_box := le_trans (le_max_left _ _) hge
  have hm1 : max D₀ (max ((NumSlots + 1) * n * (d + 1)) (NumSlots * 2 ^ (K + 1))) ≤ M_box :=
    le_trans (le_max_right _ _) hge
  have hD0 : D₀ ≤ M_box := le_trans (le_max_left _ _) hm1
  have hm2 : max ((NumSlots + 1) * n * (d + 1)) (NumSlots * 2 ^ (K + 1)) ≤ M_box :=
    le_trans (le_max_right _ _) hm1
  have hprod : (NumSlots + 1) * n * (d + 1) ≤ M_box := le_trans (le_max_left _ _) hm2
  have hseg : NumSlots * 2 ^ (K + 1) ≤ M_box := le_trans (le_max_right _ _) hm2
  have hn : n ≤ (NumSlots + 1) * n * (d + 1) := by
    calc n = 1 * n * 1 := by ring
      _ ≤ (NumSlots + 1) * n * (d + 1) :=
          Nat.mul_le_mul (Nat.mul_le_mul_right n (Nat.succ_pos _)) (Nat.succ_pos _)
  have hnd : n * d ≤ (NumSlots + 1) * n * (d + 1) := by
    calc n * d ≤ (1 * n) * (d + 1) :=
          Nat.mul_le_mul (by omega) (Nat.le_succ d)
      _ ≤ ((NumSlots + 1) * n) * (d + 1) :=
          Nat.mul_le_mul_right (d + 1) (Nat.mul_le_mul_right n (Nat.succ_pos _))
  have hsn : NumSlots * n ≤ (NumSlots + 1) * n * (d + 1) := by
    calc NumSlots * n = (NumSlots * n) * 1 := by ring
      _ ≤ ((NumSlots + 1) * n) * (d + 1) :=
          Nat.mul_le_mul (Nat.mul_le_mul_right n (Nat.le_succ _)) (Nat.succ_pos _)
  have hsnd : NumSlots * n * d ≤ (NumSlots + 1) * n * (d + 1) := by
    exact Nat.mul_le_mul (Nat.mul_le_mul_right n (Nat.le_succ _)) (Nat.le_succ _)
  exact ⟨h30, hD0, le_trans hn hprod, le_trans hnd hprod,
    le_trans hsn hprod, le_trans hsnd hprod, hseg⟩

/-- Encoding of a single serving node `r` on live input pool `S_r ⊆ activeH`:
- `wRead mem 13 r = age_r` (integer input-change counter)
- `wRead mem 14 r = dS` (live radius-keyed segment-tree slot `EncSegSlot` wrt `N.o`)
- `wRead mem 15 r = spS` (live zero-keyed spare pool segment-tree slot `EncSegSlot`)
- `rRead mem 12 [r * d .. r * d + d - 1] = N.o` (node center coordinates)
- `rRead mem 13 r = N.V` (node variance / squared core radius). -/
def EncServingNode (d K NumSlots : ℕ) (mem : ArithRAMMemory)
    (livePts : ℕ → EuclideanSpace ℝ (Fin d))
    (r : ℕ) (N : ChainNode d) (S_r : Finset ℕ) (age_r : ℕ) : Prop :=
  ∃ (dS spS : ℕ),
    0 < dS ∧ dS < NumSlots ∧
    0 < spS ∧ spS < NumSlots ∧
    dS ≠ spS ∧
    wRead mem 13 (r : ℤ) = (age_r : ℤ) ∧
    wRead mem 14 (r : ℤ) = (dS : ℤ) ∧
    wRead mem 15 (r : ℤ) = (spS : ℤ) ∧
    wRead mem 6 (dS : ℤ) = 0 ∧
    wRead mem 6 (spS : ℤ) = 0 ∧
    (∀ c : Fin d, rRead mem 12 (((r * d + c.val : ℕ) : ℤ)) = euclideanCoord N.o c) ∧
    rRead mem 13 (r : ℤ) = N.V ∧
    EncSegSlot K mem dS S_r (fun x => euclideanDistSq (livePts x) N.o) ∧
    EncSegSlot K mem spS S_r (fun _ => 0)

lemma EncServingNode.snSlotSet_eq {d K NumSlots : ℕ} {mem : ArithRAMMemory}
    {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {r : ℕ} {N : ChainNode d} {S_r : Finset ℕ} {age_r dS spS : ℕ}
    (h14 : wRead mem 14 (r : ℤ) = (dS : ℤ))
    (h15 : wRead mem 15 (r : ℤ) = (spS : ℤ)) :
    snSlotSet mem r = {dS, spS} := by
  unfold snSlotSet
  rw [h14, h15]
  simp

/-- Full RAM representation of the active handle pool (`< n ≤ 2^K`), live coordinate table,
global active-handle segment tree (`slot 0`), serving chain of `k ≤ D₀` nodes (`nodes : Fin k → ChainNode d`),
and terminal leaf pool (`leafS = wRead mem 1 6`). -/
def EncServingChain (d n K D₀ NumSlots : ℕ) (mem : ArithRAMMemory)
    (P : DynamicPointSet d) (k : ℕ)
    (nodes : Fin k → ChainNode d) (snAge : Fin k → ℕ) : Prop :=
  k ≤ D₀ ∧
  n ≤ 2 ^ K ∧
  2 ≤ NumSlots ∧
  EncHandlePool d n mem P ∧
  SegGenBound K NumSlots mem ∧
  SaveGenBound n NumSlots mem ∧
  wRead mem 1 5 = (k : ℤ) ∧
  wRead mem 6 0 = 0 ∧
  EncSegSlot K mem 0 P.activeHandles (fun _ => 0) ∧
  ∃ leafS : ℕ,
    0 < leafS ∧ leafS < NumSlots ∧
    wRead mem 1 6 = (leafS : ℤ) ∧
    wRead mem 6 (leafS : ℤ) = 0 ∧
    EncSegSlot K mem leafS (chainTerminal P.handleCoords nodes P.activeHandles) (fun _ => 0) ∧
    (∀ r : Fin k,
      EncServingNode d K NumSlots mem P.handleCoords r.val (nodes r)
        (chainInput P.handleCoords nodes P.activeHandles r.castSucc) (snAge r)) ∧
    (∀ r : Fin k, ∀ s ∈ snSlotSet mem r.val, s ≠ 0 ∧ s ≠ leafS) ∧
    (∀ r₁ r₂ : Fin k, r₁ ≠ r₂ → Disjoint (snSlotSet mem r₁.val) (snSlotSet mem r₂.val))

/-- `EncServingChain` directly discharges the chain-length, leaf-slot, and serving-slot bounds
required by `exec_gcSlotInUseStmt` in `RacerP46_H4a_SlotGCAndPureHist`. -/
lemma EncServingChain.gc_hyps {d n K D₀ NumSlots : ℕ} {mem : ArithRAMMemory}
    {P : DynamicPointSet d} {k : ℕ} {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ}
    (hC : EncServingChain d n K D₀ NumSlots mem P k nodes snAge) :
    1 ≤ NumSlots ∧
    k ≤ D₀ ∧
    wRead mem 1 5 = (k : ℤ) ∧
    ∃ leafS : ℕ,
      leafS < NumSlots ∧
      wRead mem 1 6 = (leafS : ℤ) ∧
      (∀ r < k, ∃ (dS spS : ℕ), dS < NumSlots ∧ spS < NumSlots ∧
        wRead mem 14 (r : ℤ) = (dS : ℤ) ∧ wRead mem 15 (r : ℤ) = (spS : ℤ)) := by
  rcases hC with ⟨hk, _, hns, _, _, _, hw15, _, _, leafS, _, hleaf_lt, hw16, _, _, hsn, _, _⟩
  refine ⟨by omega, hk, hw15, leafS, hleaf_lt, hw16, fun r hr => ?_⟩
  rcases hsn ⟨r, hr⟩ with ⟨dS, spS, _, hdS_lt, _, hspS_lt, _, _, hw14, hw15_r, _⟩
  exact ⟨dS, spS, hdS_lt, hspS_lt, hw14, hw15_r⟩

/-! ### 3. `O(1)` Empty-Memory Bootstrap (`bootstrapServingChainStmt` & `ensureServingChainInitStmt`) -/

/-- Initialize `nextGen := 1`, `chainLen := 0`, `leafSlot := 1`, and reset `slot 0` and `slot 1`
starting from `ArithRAMMemory.empty` (used on step `0` when `initStmt = .skip`). -/
theorem exec_popScopeZeroStmt {d : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory) :
    DetExecAt 0 inp (.localScope .skip) mem (mem.popDepth 0) 1 := by
  have h := DetExecAt.localScope (fd := 0) (DetExecAt.skip 1 inp (mem.popDepth 0))
  rwa [popDepth_zero_idem] at h

def bootstrapServingChainStmt (M_box : ℕ) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 1 (.lit 3) (.lit 1),
    boxWriteW M_box 1 (.lit 5) (.lit 0),
    boxWriteW M_box 1 (.lit 6) (.lit 1),
    .localScope (seqList [
      resetSegSlotStmt M_box (.lit 0),
      resetSegSlotStmt M_box (.lit 1)
    ])
  ]

/-- Idempotent `O(1)` guard: bootstraps `ArithRAMMemory.empty` when `wRead mem 1 3 == 0` and
otherwise acts as `.skip`. -/
def ensureServingChainInitStmt (M_box : ℕ) : ArithRAMStmt :=
  .ite (.intEq (.readHeap 1 (.lit 3)) (.lit 0))
    (bootstrapServingChainStmt M_box)
    .skip

theorem boxSafe_bootstrapServingChainStmt {T_max M_box : ℕ} (hT : 6 ≤ T_max) :
    BoxSafeOuter T_max M_box (bootstrapServingChainStmt M_box) := by
  unfold bootstrapServingChainStmt
  apply boxSafeOuter_seqList
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · refine .localScope (boxSafeInner_seqList ?_)
    intro s' hs'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl
    · exact boxSafe_resetSegSlotStmt hT _
    · exact boxSafe_resetSegSlotStmt hT _

theorem boxSafe_ensureServingChainInitStmt {T_max M_box : ℕ} (hT : 6 ≤ T_max) :
    BoxSafeOuter T_max M_box (ensureServingChainInitStmt M_box) :=
  .ite _ (boxSafe_bootstrapServingChainStmt hT) .skip

private lemma wRead_empty (t : ℕ) (idx : ℤ) : wRead ArithRAMMemory.empty t idx = 0 := by
  simp [wRead, ArithRAMMemory.empty, WordStore.read, WordStore.empty]

private lemma rRead_empty (t : ℕ) (idx : ℤ) : rRead ArithRAMMemory.empty t idx = 0 := by
  simp [rRead, ArithRAMMemory.empty, RealStore.read, RealStore.empty]

theorem exec_ensureServingChainInitStmt_empty {d n K D₀ NumSlots M_box : ℕ}
    (inp : ArithRAMInput d)
    (hnK : n ≤ 2 ^ K)
    (hSlots : 2 ≤ NumSlots)
    (hBox1 : 7 ≤ M_box)
    (hBoxS : NumSlots ≤ M_box) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (ensureServingChainInitStmt M_box) ArithRAMMemory.empty m' 250 ∧
      m'.popDepth 0 = m' ∧
      EncServingChain d n K D₀ NumSlots m' (DynamicPointSet.empty d) 0 Fin.elim0 Fin.elim0 ∧
      (∀ t, t ≠ 1 → t ≠ 5 → ∀ idx, wRead m' t idx = 0) ∧
      (∀ t idx, rRead m' t idx = 0) := by
  have hcond : cValAt 0 inp ArithRAMMemory.empty (.intEq (.readHeap 1 (.lit 3)) (.lit 0)) = true := by
    simp [wRead_empty]
  let m1 := wWrite ArithRAMMemory.empty 1 3 1
  let m2 := wWrite m1 1 5 0
  let m3 := wWrite m2 1 6 1
  have hs1 : DetExecAt 0 inp (boxWriteW M_box 1 (.lit 3) (.lit 1)) ArithRAMMemory.empty m1 12 :=
    exec_boxWriteW inp ArithRAMMemory.empty _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hs2 : DetExecAt 0 inp (boxWriteW M_box 1 (.lit 5) (.lit 0)) m1 m2 12 :=
    exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hs3 : DetExecAt 0 inp (boxWriteW M_box 1 (.lit 6) (.lit 1)) m2 m3 12 :=
    exec_boxWriteW inp m2 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hseg_m3 : SegGenBound K NumSlots (m3.popDepth 0) := by
    refine ⟨?_, ?_, ?_⟩
    · simp [m3, m2, m1]
    · intro s _; simp [m3, m2, m1, wRead_empty]
    · intro s _ u _; simp [m3, m2, m1, wRead_empty]
  rcases exec_resetSegSlotStmt inp (m3.popDepth 0) (.lit 0) (K := K) (NumSlots := NumSlots)
      (M_box := M_box) (s := 0) (by omega) rfl (by omega) hBoxS hseg_m3
    with ⟨m4, hs4, hseg4, hEnc0_4, _, hw4, hw4_1, hr4, _, _⟩
  rcases exec_resetSegSlotStmt inp m4 (.lit 1) (K := K) (NumSlots := NumSlots)
      (M_box := M_box) (s := 1) (by omega) rfl (by omega) hBoxS hseg4
    with ⟨m5, hs5, hseg5, hEnc1_5, hOther5, hw5, hw5_1, hr5, _, _⟩
  let m6 := m5.popDepth 0
  have hs_loc : DetExecAt 0 inp
      (.localScope (seqList [resetSegSlotStmt M_box (.lit 0), resetSegSlotStmt M_box (.lit 1)]))
      m3 m6 90 :=
    DetExecAt.localScope ((hs4.seq hs5).mono_cost (by simp [intExprOps]))
  have hex_boot : DetExecAt 0 inp (bootstrapServingChainStmt M_box) ArithRAMMemory.empty m6 140 := by
    unfold bootstrapServingChainStmt seqList
    exact (hs1.seq (hs2.seq (hs3.seq hs_loc))).mono_cost (by omega)
  have hex_all : DetExecAt 0 inp (ensureServingChainInitStmt M_box) ArithRAMMemory.empty m6 250 :=
    (DetExecAt.ite_true hcond (C_c := 15) (by simp [condExprOps, intExprOps]) hex_boot).mono_cost (by omega)
  have hw_not15 : ∀ t, t ≠ 1 → t ≠ 5 → ∀ idx, wRead m6 t idx = 0 := by
    intro t ht1 ht5 idx
    simp only [m6, wRead_popDepth, hw5 t ht1 ht5 idx, hw4 t ht1 ht5 idx, m3, m2, m1,
      wRead_wWrite_of_ne _ _ (Or.inl ht1), wRead_empty]
  have hr_all : ∀ t idx, rRead m6 t idx = 0 := by
    intro t idx
    simp only [m6, rRead_popDepth, hr5, hr4, m3, m2, m1, rRead_wWrite, rRead_empty]
  have hw1_not3 : ∀ idx, idx ≠ 3 → wRead m6 1 idx = wRead m3 1 idx := by
    intro idx hne
    simp only [m6, wRead_popDepth, hw5_1 idx hne, hw4_1 idx hne]
  have hEnc0_5 : EncSegSlot K m5 0 ∅ (fun _ => 0) :=
    hOther5 0 (by omega) (by decide) ∅ (fun _ => 0) (hEnc0_4 (fun _ => 0))
  have hEnc0_6 : EncSegSlot K m6 0 (DynamicPointSet.empty d).activeHandles (fun _ => 0) := by
    have hact_emp : (DynamicPointSet.empty d).activeHandles = ∅ := rfl
    rw [hact_emp]
    exact hEnc0_5.congr_mem_fSq (by simp [m6]) (fun _ _ => by simp [m6])
      (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => rfl)
  have hEnc1_6 : EncSegSlot K m6 1
      (chainTerminal (DynamicPointSet.empty d).handleCoords Fin.elim0 (DynamicPointSet.empty d).activeHandles)
      (fun _ => 0) := by
    have hterm_emp :
        chainTerminal (DynamicPointSet.empty d).handleCoords Fin.elim0 (DynamicPointSet.empty d).activeHandles = ∅ := rfl
    rw [hterm_emp]
    exact (hEnc1_5 (fun _ => 0)).congr_mem_fSq (by simp [m6]) (fun _ _ => by simp [m6])
      (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => by simp [m6]) (fun _ _ => rfl)
  have hseg6 : SegGenBound K NumSlots m6 :=
    ⟨by simp [m6]; exact hseg5.1,
     fun s hs => by simp [m6]; exact hseg5.2.1 s hs,
     fun s hs u hu => by simp [m6]; exact hseg5.2.2 s hs u hu⟩
  have hsave6 : SaveGenBound n NumSlots m6 := by
    refine ⟨hseg6.1, ?_, ?_⟩
    · intro s _; rw [hw_not15 6 (by decide) (by decide)]; exact lt_of_lt_of_le (by decide : (0 : ℤ) < 1) hseg6.1
    · intro s _ h _; rw [hw_not15 11 (by decide) (by decide)]; exact lt_of_lt_of_le (by decide : (0 : ℤ) < 1) hseg6.1
  have hPool6 : EncHandlePool d n m6 (DynamicPointSet.empty d) := by
    refine encHandlePool_empty_init ?_ ?_ ?_ ?_
    · rw [hw1_not3 0 (by decide)]; simp [m3, m2, m1, wRead_empty]
    · rw [hw1_not3 1 (by decide)]; simp [m3, m2, m1, wRead_empty]
    · rw [hw1_not3 2 (by decide)]; simp [m3, m2, m1, wRead_empty]
    · intro h _; exact hw_not15 2 (by decide) (by decide) (h : ℤ)
  refine ⟨m6, hex_all, popDepth_zero_idem _, ?_, hw_not15, hr_all⟩
  refine ⟨Nat.zero_le D₀, hnK, hSlots, hPool6, hseg6, hsave6, ?_, ?_, hEnc0_6,
    1, Nat.one_pos, hSlots, ?_, ?_, hEnc1_6,
    (fun r => Fin.elim0 r), (fun r => Fin.elim0 r), (fun r => Fin.elim0 r)⟩
  · rw [hw1_not3 5 (by decide)]; simp [m3, m2]
  · exact hw_not15 6 (by decide) (by decide) 0
  · rw [hw1_not3 6 (by decide)]; simp [m3]
  · exact hw_not15 6 (by decide) (by decide) 1

theorem exec_ensureServingChainInitStmt_pres {d n K D₀ NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {P : DynamicPointSet d} {k : ℕ} {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ}
    (hC : EncServingChain d n K D₀ NumSlots mem P k nodes snAge) :
    DetExecAt 0 inp (ensureServingChainInitStmt M_box) mem mem 20 := by
  have h13 : 1 ≤ wRead mem 1 3 := hC.2.2.2.2.1.1
  have hcond : cValAt 0 inp mem (.intEq (.readHeap 1 (.lit 3)) (.lit 0)) = false := by
    simp only [cValAt_intEq, iValAt_readHeap, iValAt_lit, decide_eq_false_iff_not]
    omega
  exact (DetExecAt.ite_false hcond (C_c := 15) (by simp [condExprOps, intExprOps])
    (DetExecAt.skip 0 inp mem)).mono_cost (by omega)

/-! ### 4. Step 1 of Live Update Routing: Active Handle Pool + Global Slot `0` (`routePoolAndSlot0Stmt`) -/

/-- Execute `poolStepStmt` (allocating/freeing `opH`, writing live coordinates on `.insert`, running
`copyOnDeleteStmt` on `.delete`), latch `(opH, insFlag, reach := 1)` into Heap Table `26`, and
update global active-handle segment tree `slot 0`! -/
def routePoolAndSlot0Stmt (d n K NumSlots M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .localScope (seqList [
      poolStepStmt d n NumSlots M_box,
      boxWriteW M_box 26 (.lit 4) (.readLocal 29 (.lit 11)),
      boxWriteW M_box 26 (.lit 5) (.readLocal 29 (.lit 10)),
      boxWriteW M_box 26 (.lit 9) (.lit 1),
      boxWriteW M_box 26 (.lit 3) (.lit 0)
    ]),
    updSegZeroStmt K M_box
  ]

theorem boxSafe_routePoolAndSlot0Stmt {T_max M_box : ℕ} (hT : 27 ≤ T_max)
    (d n K NumSlots : ℕ) :
    BoxSafeOuter T_max M_box (routePoolAndSlot0Stmt d n K NumSlots M_box) := by
  unfold routePoolAndSlot0Stmt
  apply boxSafeOuter_seqList
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl
  · refine .localScope (boxSafeInner_seqList ?_)
    intro s' hs'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl | rfl | rfl | rfl
    · exact boxSafe_poolStepStmt (by omega) d n NumSlots
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _
  · exact boxSafe_updSegZeroStmt (by omega) K

theorem exec_routePoolAndSlot0Stmt {d n K NumSlots M_box : ℕ}
    (P : DynamicPointSet d) (op : DynamicUpdate d) (mem : ArithRAMMemory)
    (hP : P.WellFormed n)
    (hleg : IsLegalUpdate n Set.univ P op)
    (hnK : n ≤ 2 ^ K)
    (hSlots : 1 ≤ NumSlots)
    (hBox30 : 30 ≤ M_box)
    (hBox_n : n ≤ M_box) (hBox_nd : n * d ≤ M_box)
    (hBox_sn : NumSlots * n ≤ M_box) (hBox_snd : NumSlots * n * d ≤ M_box)
    (hBox_seg : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (hPool : EncHandlePool d n mem P)
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem)
    (hSeg0 : EncSegSlot K mem 0 P.activeHandles (fun _ => 0)) :
    let inp := mkStepInput n P op
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    ∃ (m' : ArithRAMMemory) (P' : DynamicPointSet d) (opH : ℕ),
      DetExecAt 0 inp (routePoolAndSlot0Stmt d n K NumSlots M_box) mem m'
        (200 * (NumSlots + 1) * (d + 1) + 220 * (K + 1) + 450) ∧
      m'.popDepth 0 = m' ∧
      applyDynamicUpdate P op (readStepRetH op m') = some P' ∧
      P'.WellFormed n ∧
      EncHandlePool d n m' P' ∧
      SegGenBound K NumSlots m' ∧
      SaveGenBound n NumSlots m' ∧
      EncSegSlot K m' 0 P'.activeHandles (fun _ => 0) ∧
      opH < n ∧ opH < 2 ^ K ∧
      wRead m' 26 4 = (opH : ℤ) ∧
      wRead m' 26 5 = (if ins then 1 else 0) ∧
      wRead m' 26 9 = 1 ∧
      (match op with
       | .insert _ _ pt =>
           wRead m' 0 0 = (opH : ℤ) ∧
           opH ∉ P.activeHandles ∧
           P'.activeHandles = insert opH P.activeHandles ∧
           P'.handleCoords opH = pt ∧
           (∀ h ∈ P.activeHandles, P'.handleCoords h = P.handleCoords h)
       | .delete id =>
           opH = P.handleOfId id ∧
           opH ∈ P.activeHandles ∧
           P'.activeHandles = P.activeHandles.erase opH ∧
           (∀ h ∈ P'.activeHandles, P'.handleCoords h = P.handleCoords h)) ∧
      (∀ s < NumSlots, 1 ≤ wRead mem 6 (s : ℤ) → ∀ S snapPts,
        EncSlotCoords d n mem P.activeHandles P.handleCoords s S snapPts →
        EncSlotCoords d n m' P'.activeHandles P'.handleCoords s S snapPts) ∧
      (∀ s' < NumSlots, s' ≠ 0 → ∀ S₁ fSq₁,
        EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ t, t ≠ 0 → t ≠ 1 → t ≠ 2 → t ≠ 3 → t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 11 → t ≠ 26 →
        ∀ idx, wRead m' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 0 → wRead m' 0 idx = wRead mem 0 idx) ∧
      (∀ idx, idx ≠ 0 → idx ≠ 1 → idx ≠ 2 → wRead m' 1 idx = wRead mem 1 idx) ∧
      (∀ t, t ≠ 4 → t ≠ 8 → t ≠ 11 → ∀ idx, rRead m' t idx = rRead mem t idx) := by
  intro inp ins
  let m0 := mem.popDepth 0
  have hPool0 : EncHandlePool d n m0 P := by
    rcases hPool with ⟨⟨h1, h2⟩, hwm, freeSet, hhwm, hw10, hw11, hw12, hdisj, hun, hst1, hst2, hw2⟩
    refine ⟨⟨h1, fun h hh c => by simp [m0]; exact h2 h hh c⟩,
      hwm, freeSet, hhwm, by simp [m0, hw10], by simp [m0, hw11], by simp [m0, hw12],
      hdisj, hun,
      fun i hi => by simpa [m0] using hst1 i hi,
      fun i hi j hj hne => by simpa [m0] using hst2 i hi j hj hne,
      fun h hh => by simpa [m0] using hw2 h hh⟩
  have hseg0 : SegGenBound K NumSlots m0 :=
    ⟨by simp [m0]; exact hseg.1,
     fun s hs => by simp [m0]; exact hseg.2.1 s hs,
     fun s hs u hu => by simp [m0]; exact hseg.2.2 s hs u hu⟩
  have hsave0 : SaveGenBound n NumSlots m0 :=
    ⟨by simp [m0]; exact hsave.1,
     fun s hs => by simp [m0]; exact hsave.2.1 s hs,
     fun s hs h hh => by simp [m0]; exact hsave.2.2 s hs h hh⟩
  rcases exec_poolStepStmt P op m0 hP hleg hPool0 hseg0 hsave0
      (by omega) hBox_n hBox_nd hBox_sn hBox_snd
    with ⟨mp, P', opH, hex_p, happ_p, hWF_p, hPool_p, hseg_p, hsave_p,
          hopH_n, hloc11, hmatch_p, hSlot_p, hw_p, hw0_p, hw1_p, hr_p, _, _⟩
  have hopH_K : opH < 2 ^ K := lt_of_lt_of_le hopH_n hnK
  have hloc10 : wReadL 1 mp 29 10 = (if ins then 1 else 0) := by
    cases op with
    | insert _ _ _ => exact hmatch_p.1
    | delete _ => exact hmatch_p.1
  let mb1 := wWrite mp 26 4 (opH : ℤ)
  let mb2 := wWrite mb1 26 5 (if ins then 1 else 0)
  let mb3 := wWrite mb2 26 9 1
  let mb4 := wWrite mb3 26 3 0
  have hb1 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 4) (.readLocal 29 (.lit 11))) mp mb1 15 :=
    exec_boxWriteW inp mp _ _ rfl (by omega) (by omega) (by simp [hloc11]) (by simp [intExprOps])
  have hb2 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 5) (.readLocal 29 (.lit 10))) mb1 mb2 15 :=
    exec_boxWriteW inp mb1 _ _ rfl (by omega) (by omega) (by simp [mb1, hloc10]) (by simp [intExprOps])
  have hb3 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 9) (.lit 1)) mb2 mb3 15 :=
    exec_boxWriteW inp mb2 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hb4 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 3) (.lit 0)) mb3 mb4 15 :=
    exec_boxWriteW inp mb3 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  let ma := mb4.popDepth 0
  have hex_scope : DetExecAt 0 inp
      (.localScope (seqList [
        poolStepStmt d n NumSlots M_box,
        boxWriteW M_box 26 (.lit 4) (.readLocal 29 (.lit 11)),
        boxWriteW M_box 26 (.lit 5) (.readLocal 29 (.lit 10)),
        boxWriteW M_box 26 (.lit 9) (.lit 1),
        boxWriteW M_box 26 (.lit 3) (.lit 0)
      ])) mem ma (200 * (NumSlots + 1) * (d + 1) + 370) :=
    DetExecAt.localScope ((hex_p.seq (hb1.seq (hb2.seq (hb3.seq hb4)))).mono_cost (by omega))
  have hw_ma_not26 : ∀ t, t ≠ 26 → ∀ idx, wRead ma t idx = wRead mp t idx := by
    intro t ht idx; simp [ma, mb4, mb3, mb2, mb1, ht]
  have hr_ma : ∀ t idx, rRead ma t idx = rRead mp t idx := by
    intro t idx; simp [ma, mb4, mb3, mb2, mb1]
  have hseg_ma : SegGenBound K NumSlots ma :=
    ⟨by rw [hw_ma_not26 1 (by decide)]; exact hseg_p.1,
     fun s hs => by rw [hw_ma_not26 5 (by decide), hw_ma_not26 1 (by decide)]; exact hseg_p.2.1 s hs,
     fun s hs u hu => by rw [hw_ma_not26 8 (by decide), hw_ma_not26 1 (by decide)]; exact hseg_p.2.2 s hs u hu⟩
  have liftSeg_ma : ∀ s' < NumSlots, ∀ S₁ fSq₁,
      EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K ma s' S₁ fSq₁ := by
    intro s' _ S₁ fSq₁ hE
    refine hE.congr_mem_fSq ?_ (fun _ _ => ?_) (fun _ _ => ?_) (fun _ _ => ?_) (fun _ _ => ?_) (fun _ _ => rfl)
    · rw [hw_ma_not26 5 (by decide), hw_p 5 (by decide) (by decide) (by decide) (by decide) (by decide)]; simp [m0]
    · rw [hw_ma_not26 8 (by decide), hw_p 8 (by decide) (by decide) (by decide) (by decide) (by decide)]; simp [m0]
    · rw [hw_ma_not26 9 (by decide), hw_p 9 (by decide) (by decide) (by decide) (by decide) (by decide)]; simp [m0]
    · rw [hw_ma_not26 10 (by decide), hw_p 10 (by decide) (by decide) (by decide) (by decide) (by decide)]; simp [m0]
    · rw [hr_ma, hr_p 8 (by decide) (by decide)]; simp [m0]
  have hSeg0_ma : EncSegSlot K ma 0 P.activeHandles (fun _ => 0) :=
    liftSeg_ma 0 hSlots P.activeHandles (fun _ => 0) hSeg0
  rcases exec_updSegZeroStmt inp ma (NumSlots := NumSlots) (M_box := M_box)
      (s := 0) (h := opH) (ins := ins) (S := P.activeHandles)
      hSlots hopH_K hBox_seg
      (by simp [ma, mb4])
      (by simp [ma, mb4, mb3, mb2, mb1])
      (by simp [ma, mb4, mb3, mb2])
      hseg_ma hSeg0_ma
    with ⟨m', hex_u0, hpop', hseg', hSeg0_raw, hOther', hw_u0, hr_u0⟩
  have hact_eq : (if ins then insert opH P.activeHandles else P.activeHandles.erase opH) = P'.activeHandles := by
    cases op with
    | insert _ _ _ => exact hmatch_p.2.2.2.1.symm
    | delete _ => exact hmatch_p.2.2.2.1.symm
  have hSeg0' : EncSegSlot K m' 0 P'.activeHandles (fun _ => 0) := hact_eq ▸ hSeg0_raw
  have hw_m'_not8910 : ∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → ∀ idx, wRead m' t idx = wRead ma t idx := hw_u0
  have hr_m'_not8 : ∀ t, t ≠ 8 → ∀ idx, rRead m' t idx = rRead ma t idx := hr_u0
  have hret_eq : readStepRetH op m' = readStepRetH op mp := by
    cases op with
    | insert _ _ _ =>
        have h00 : m'.words.read (.heap 0 0) = mp.words.read (.heap 0 0) := by
          change wRead m' 0 0 = wRead mp 0 0
          rw [hw_m'_not8910 0 (by decide) (by decide) (by decide), hw_ma_not26 0 (by decide)]
        simp only [readStepRetH, ArithRAMDynamicProgram.readReturnedHandle, h00]
    | delete _ => rfl
  have hPool' : EncHandlePool d n m' P' := by
    rcases hPool_p with ⟨⟨hl1, hl2⟩, hwm, freeSet, hhwm, hw10, hw11, hw12, hdisj, hun, hst1, hst2, hw2⟩
    refine ⟨⟨hl1, fun h hh c => ?_⟩, hwm, freeSet, hhwm, ?_, ?_, ?_, hdisj, hun, ?_, ?_, ?_⟩
    · rw [hr_m'_not8 4 (by decide), hr_ma]; exact hl2 h hh c
    · rw [hw_m'_not8910 1 (by decide) (by decide) (by decide), hw_ma_not26 1 (by decide)]; exact hw10
    · rw [hw_m'_not8910 1 (by decide) (by decide) (by decide), hw_ma_not26 1 (by decide)]; exact hw11
    · rw [hw_m'_not8910 1 (by decide) (by decide) (by decide), hw_ma_not26 1 (by decide)]; exact hw12
    · intro i hi
      rw [hw_m'_not8910 3 (by decide) (by decide) (by decide), hw_ma_not26 3 (by decide)]
      exact hst1 i hi
    · intro i hi j hj hne
      rw [hw_m'_not8910 3 (by decide) (by decide) (by decide), hw_ma_not26 3 (by decide),
          hw_m'_not8910 3 (by decide) (by decide) (by decide), hw_ma_not26 3 (by decide)]
      exact hst2 i hi j hj hne
    · intro h hh
      rw [hw_m'_not8910 2 (by decide) (by decide) (by decide), hw_ma_not26 2 (by decide)]
      exact hw2 h hh
  have hsave' : SaveGenBound n NumSlots m' := by
    refine ⟨hseg'.1, ?_, ?_⟩
    · intro s hs
      rw [hw_m'_not8910 6 (by decide) (by decide) (by decide), hw_ma_not26 6 (by decide),
          hw_m'_not8910 1 (by decide) (by decide) (by decide), hw_ma_not26 1 (by decide)]
      exact hsave_p.2.1 s hs
    · intro s hs h hh
      rw [hw_m'_not8910 11 (by decide) (by decide) (by decide), hw_ma_not26 11 (by decide),
          hw_m'_not8910 1 (by decide) (by decide) (by decide), hw_ma_not26 1 (by decide)]
      exact hsave_p.2.2 s hs h hh
  refine ⟨m', P', opH,
    (hex_scope.seq hex_u0).mono_cost (by omega),
    hpop',
    by rwa [hret_eq],
    hWF_p, hPool', hseg', hsave', hSeg0', hopH_n, hopH_K,
    by rw [hw_m'_not8910 26 (by decide) (by decide) (by decide)]; simp [ma, mb4, mb3, mb2, mb1],
    by rw [hw_m'_not8910 26 (by decide) (by decide) (by decide)]; simp [ma, mb4, mb3, mb2],
    by rw [hw_m'_not8910 26 (by decide) (by decide) (by decide)]; simp [ma, mb4, mb3],
    ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · cases op with
    | insert _ _ _ =>
        refine ⟨?_, hmatch_p.2.2.1, hmatch_p.2.2.2.1, hmatch_p.2.2.2.2.1, hmatch_p.2.2.2.2.2⟩
        rw [hw_m'_not8910 0 (by decide) (by decide) (by decide), hw_ma_not26 0 (by decide)]
        exact hmatch_p.2.1
    | delete _ =>
        exact hmatch_p.2
  · intro s hs hw6 S snapPts hSC
    have hw6_0 : 1 ≤ wRead m0 6 (s : ℤ) := by simpa [m0] using hw6
    have hSC_0 : EncSlotCoords d n m0 P.activeHandles P.handleCoords s S snapPts := by
      rcases hSC with ⟨h1, Left | Right⟩
      · exact ⟨h1, Or.inl ⟨by simpa [m0] using Left.1, Left.2.1, Left.2.2⟩⟩
      · refine ⟨h1, Or.inr ⟨by simpa [m0] using Right.1, fun h hh => ⟨?_, ?_⟩⟩⟩
        · intro heq c
          have heq' : wRead mem 11 ((s * n + h : ℕ) : ℤ) = wRead mem 6 (s : ℤ) := by simpa [m0] using heq
          simpa [m0] using (Right.2 h hh).1 heq' c
        · intro hne
          have hne' : wRead mem 11 ((s * n + h : ℕ) : ℤ) ≠ wRead mem 6 (s : ℤ) := by simpa [m0] using hne
          exact (Right.2 h hh).2 hne'
    have hSC_mp := hSlot_p s hs hw6_0 S snapPts hSC_0
    rcases hSC_mp with ⟨h1, Left | Right⟩
    · refine ⟨h1, Or.inl ⟨?_, Left.2.1, Left.2.2⟩⟩
      rw [hw_m'_not8910 6 (by decide) (by decide) (by decide), hw_ma_not26 6 (by decide)]; exact Left.1
    · refine ⟨h1, Or.inr ⟨?_, fun h hh => ⟨?_, ?_⟩⟩⟩
      · rw [hw_m'_not8910 6 (by decide) (by decide) (by decide), hw_ma_not26 6 (by decide)]; exact Right.1
      · intro heq c
        rw [hw_m'_not8910 11 (by decide) (by decide) (by decide), hw_ma_not26 11 (by decide),
            hw_m'_not8910 6 (by decide) (by decide) (by decide), hw_ma_not26 6 (by decide)] at heq
        rw [hr_m'_not8 11 (by decide), hr_ma]
        exact (Right.2 h hh).1 heq c
      · intro hne
        rw [hw_m'_not8910 11 (by decide) (by decide) (by decide), hw_ma_not26 11 (by decide),
            hw_m'_not8910 6 (by decide) (by decide) (by decide), hw_ma_not26 6 (by decide)] at hne
        exact (Right.2 h hh).2 hne
  · intro s' hs' hne0 S₁ fSq₁ hE
    exact hOther' s' hs' hne0 S₁ fSq₁ (liftSeg_ma s' hs' S₁ fSq₁ hE)
  · intro t ht0 ht1 ht2 ht3 ht8 ht9 ht10 ht11 ht26 idx
    rw [hw_m'_not8910 t ht8 ht9 ht10, hw_ma_not26 t ht26, hw_p t ht0 ht1 ht2 ht3 ht11]
    simp [m0]
  · intro idx hne0
    rw [hw_m'_not8910 0 (by decide) (by decide) (by decide), hw_ma_not26 0 (by decide), hw0_p idx hne0]
    simp [m0]
  · intro idx h0 h1 h2
    rw [hw_m'_not8910 1 (by decide) (by decide) (by decide), hw_ma_not26 1 (by decide), hw1_p idx h0 h1 h2]
    simp [m0]
  · intro t ht4 ht8 ht11 idx
    rw [hr_m'_not8 t ht8, hr_ma, hr_p t ht4 ht11]
    simp [m0]

end UL.Proof_lem_7_2_RacerP46
