import Mathlib
import UL.Proof.lem_7_2.RacerP46_H3d_JobLevelRAM

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Phase-0 Background Birth-Core Scan Step (`phase0OneIterStmt` & `phase0FinishStmt`) -/

def phase0OneIterStmt (d n K M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 29 (.lit 19) (.readHeap 26 (.lit 7)),
    .writeWordLocal 29 (.lit 16)
      (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))),
    .writeWordLocal 29 (.lit 17)
      (.readHeap 23 (.mul (.lit 8) (.readLocal 29 (.lit 19)))),
    .ite (.intLt (.readLocal 29 (.lit 16)) (.readLocal 29 (.lit 17)))
      (seqList [
        .writeWordLocal 28 (.lit 20)
          (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 2))),
        .writeWordLocal 28 (.lit 21) (.readLocal 29 (.lit 16)),
        selectByRankSegStmt K,
        .writeWordLocal 29 (.lit 20)
          (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 2))),
        .writeWordLocal 29 (.lit 21) (.readLocal 28 (.lit 0)),
        readSlotPtToLocalStmt d n 0,
        .writeWordLocal 29 (.lit 18) (.mul (.readLocal 29 (.lit 19)) (.lit (d : ℤ))),
        loadHeapCoordsToLocalStmt d 23 18 (d : ℤ),
        distSqLocalStmt d,
        .ite (.realLe (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))
                      (.readRealHeap 24 (.mul (.lit 2) (.readLocal 29 (.lit 19)))))
          (boxWriteW M_box 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1))
            (.add (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1))) (.lit 1)))
          .skip,
        .ite (.or (.intEq (.readLocal 29 (.lit 16)) (.lit 0))
                  (.realLt (.readRealHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))
                           (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))))
          (boxWriteR M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
            (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))
          .skip,
        boxWriteW M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
          (.add (.readLocal 29 (.lit 16)) (.lit 1))
      ])
      .skip
  ])

theorem boxSafe_phase0OneIterStmt {T_max M_box : ℕ} (hT : 25 ≤ T_max) (d n K : ℕ) :
    BoxSafeOuter T_max M_box (phase0OneIterStmt d n K M_box) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .ite _ (boxSafeInner_seqList ?_) .skip
    intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_selectByRankSegStmt K
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_readSlotPtToLocalStmt d n 0
    · exact .writeWordLocal _ _ _
    · exact boxSafe_loadHeapCoordsToLocalStmt d 23 18 (d : ℤ)
    · exact boxSafe_distSqLocalStmt d
    · exact .ite _ (.boxW (by omega) _ _) .skip
    · exact .ite _ (.boxR (by omega) _ _) .skip
    · exact .boxW (by omega) _ _

def phase0FinishStmt (D M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 29 (.lit 19) (.readHeap 26 (.lit 7)),
    .ite (.intEq (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))
                 (.readHeap 23 (.mul (.lit 8) (.readLocal 29 (.lit 19)))))
      (seqList [
        .ite (.intLe (.readHeap 23 (.mul (.lit 8) (.readLocal 29 (.lit 19))))
                     (.mul (.lit (((8 * D ^ 2 : ℕ) : ℤ)))
                           (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1)))))
          .skip
          (boxWriteR M_box 24 (.mul (.lit 2) (.readLocal 29 (.lit 19)))
            (.readRealHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))),
        resetSegSlotStmt M_box (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 3))),
        resetSegSlotStmt M_box (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 4))),
        resetSegSlotStmt M_box (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 5))),
        resetSegSlotStmt M_box (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 6))),
        boxWriteW M_box 24 (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1),
        boxWriteW M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)) (.lit 0)
      ])
      .skip
  ])

theorem boxSafe_phase0FinishStmt {T_max M_box : ℕ} (hT : 25 ≤ T_max) (D : ℕ) :
    BoxSafeOuter T_max M_box (phase0FinishStmt D M_box) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · exact .writeWordLocal _ _ _
  · refine .ite _ (boxSafeInner_seqList ?_) .skip
    intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · exact .ite _ .skip (.boxR (by omega) _ _)
    · exact boxSafe_resetSegSlotStmt (by omega) _
    · exact boxSafe_resetSegSlotStmt (by omega) _
    · exact boxSafe_resetSegSlotStmt (by omega) _
    · exact boxSafe_resetSegSlotStmt (by omega) _
    · exact .boxW (by omega) _ _
    · exact .boxW (by omega) _ _

/-! ### 2. Phase-1 Background Live-Parent Cursor Scan (`phase1OneIterStmt` & `phase1FinishStmt`) -/

def phase1SelectScopeStmt (K M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 29 (.lit 19) (.readHeap 26 (.lit 7)),
    .writeWordLocal 29 (.lit 16)
      (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))),
    .ite (.intLt (.readLocal 29 (.lit 16)) (.lit (((2 ^ K : ℕ) : ℤ))))
      (seqList [
        .writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 9)),
        .writeWordLocal 28 (.lit 21) (.readLocal 29 (.lit 16)),
        findSuccSegStmt K,
        .ite (.intEq (.readLocal 28 (.lit 1)) (.lit 1))
          (seqList [
            boxWriteW M_box 26 (.lit 4) (.readLocal 28 (.lit 0)),
            boxWriteW M_box 26 (.lit 5) (.lit 1),
            boxWriteW M_box 26 (.lit 25) (.lit 1),
            boxWriteW M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
              (.add (.readLocal 28 (.lit 0)) (.lit 1))
          ])
          (seqList [
            boxWriteW M_box 26 (.lit 25) (.lit 0),
            boxWriteW M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
              (.lit (((2 ^ K : ℕ) : ℤ)))
          ])
      ])
      (boxWriteW M_box 26 (.lit 25) (.lit 0))
  ])

theorem boxSafe_phase1SelectScopeStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (K : ℕ) :
    BoxSafeOuter T_max M_box (phase1SelectScopeStmt K M_box) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .writeWordLocal _ _ _
  · refine .ite _ (boxSafeInner_seqList ?_) (.boxW (by omega) _ _)
    intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
    rcases hs with rfl | rfl | rfl | rfl
    · exact .writeWordLocal _ _ _
    · exact .writeWordLocal _ _ _
    · exact boxSafe_findSuccSegStmt K
    · refine .ite _ (boxSafeInner_seqList ?_) (boxSafeInner_seqList ?_)
      · intro a ha; simp only [List.mem_cons, List.not_mem_nil, or_false] at ha
        rcases ha with rfl | rfl | rfl | rfl <;> exact .boxW (by omega) _ _
      · intro a ha; simp only [List.mem_cons, List.not_mem_nil, or_false] at ha
        rcases ha with rfl | rfl <;> exact .boxW (by omega) _ _

def phase1OneIterStmt (d K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    phase1SelectScopeStmt K M_box,
    .ite (.intEq (.readHeap 26 (.lit 25)) (.lit 1))
      (updJobLevelFourSlotsStmt d K M_box)
      .skip
  ]

theorem boxSafe_phase1OneIterStmt {T_max M_box : ℕ} (hT : 28 ≤ T_max) (d K : ℕ) :
    BoxSafeOuter T_max M_box (phase1OneIterStmt d K M_box) := by
  unfold phase1OneIterStmt
  apply boxSafeOuter_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · exact boxSafe_phase1SelectScopeStmt (by omega) K
  · exact .ite _ (boxSafe_updJobLevelFourSlotsStmt hT d K) .skip

def phase1FinishStmt (K M_box : ℕ) : ArithRAMStmt :=
  .localScope (seqList [
    .writeWordLocal 29 (.lit 19) (.readHeap 26 (.lit 7)),
    .ite (.intLe (.lit (((2 ^ K : ℕ) : ℤ)))
                 (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))))
      (boxWriteW M_box 24 (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 2))
      .skip
  ])

theorem boxSafe_phase1FinishStmt {T_max M_box : ℕ} (hT : 25 ≤ T_max) (K : ℕ) :
    BoxSafeOuter T_max M_box (phase1FinishStmt K M_box) := by
  refine .localScope (boxSafeInner_seqList ?_)
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · exact .writeWordLocal _ _ _
  · exact .ite _ (.boxW (by omega) _ _) .skip

/-- Perform one clock-tick batch (`K_batch` steps) of background building on job level
`idx = wRead mem 26 7` with live parent slot `parentSlot = wRead mem 26 9`. -/
def stepBuildJobLevelStmt (d n D K K_batch M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .ite (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 0))
      (seqList [
        .repeatN (.lit (K_batch : ℤ)) (phase0OneIterStmt d n K M_box),
        phase0FinishStmt D M_box
      ])
      (.ite (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 1))
        (seqList [
          .repeatN (.lit (K_batch : ℤ)) (phase1OneIterStmt d K M_box),
          phase1FinishStmt K M_box
        ])
        .skip),
    .localScope .skip
  ]

theorem boxSafe_stepBuildJobLevelStmt {T_max M_box : ℕ} (hT : 28 ≤ T_max)
    (d n D K K_batch : ℕ) :
    BoxSafeOuter T_max M_box (stepBuildJobLevelStmt d n D K K_batch M_box) := by
  unfold stepBuildJobLevelStmt
  apply boxSafeOuter_seqList
  intro st hst; simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl
  · refine .ite _ (boxSafeOuter_seqList ?_) (.ite _ (boxSafeOuter_seqList ?_) .skip)
    · intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
      rcases hs with rfl | rfl
      · exact .repeatN _ (boxSafe_phase0OneIterStmt (by omega) d n K)
      · exact boxSafe_phase0FinishStmt (by omega) D
    · intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
      rcases hs with rfl | rfl
      · exact .repeatN _ (boxSafe_phase1OneIterStmt hT d K)
      · exact boxSafe_phase1FinishStmt (by omega) K
  · exact .localScope .skip

theorem exec_resetSegSlotStmt_save {d n K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (sE : IntExpr) {s : ℕ} (hs : s < NumSlots)
    (hsE : iValAt 1 inp mem sE = (s : ℤ))
    (hM1 : 4 ≤ M_box) (hMs : NumSlots ≤ M_box)
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem) :
    ∃ mem' : ArithRAMMemory,
      DetExecAt 1 inp (resetSegSlotStmt M_box sE) mem mem' (intExprOps sE + 40) ∧
      SegGenBound K NumSlots mem' ∧
      SaveGenBound n NumSlots mem' ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K mem' s ∅ fSq) ∧
      (∀ s' < NumSlots, s' ≠ s → ∀ S' fSq',
        EncSegSlot K mem s' S' fSq' → EncSegSlot K mem' s' S' fSq') ∧
      (∀ t : ℕ, t ≠ 1 → t ≠ 5 → ∀ idx : ℤ, wRead mem' t idx = wRead mem t idx) ∧
      (∀ idx : ℤ, idx ≠ 3 → wRead mem' 1 idx = wRead mem 1 idx) ∧
      (∀ t : ℕ, ∀ idx : ℤ, rRead mem' t idx = rRead mem t idx) ∧
      (∀ v : ℕ, v ≠ 28 → ∀ idx : ℤ, wReadL 1 mem' v idx = wReadL 1 mem v idx) ∧
      (∀ v : ℕ, ∀ idx : ℤ, rReadL 1 mem' v idx = rReadL 1 mem v idx) := by
  set g := wRead mem 1 3
  let m1 := wWriteL 1 mem 28 0 (s : ℤ)
  let m2 := wWriteL 1 m1 28 1 g
  let m3 := wWrite m2 5 (s : ℤ) g
  let m4 := wWrite m3 1 3 (g + 1)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 0) sE) mem m1 (intExprOps sE + 2) :=
    DetExecAt.writeWordLocal 1 inp mem 28 (.lit 0) sE rfl hsE (by dsimp [intExprOps]; omega)
  have hs2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 1) (.readHeap 1 (.lit 3))) m1 m2 5 :=
    DetExecAt.writeWordLocal 1 inp m1 28 (.lit 1) (.readHeap 1 (.lit 3)) rfl
      (by simp [m1, g]) (by simp [intExprOps])
  have hs3 : DetExecAt 1 inp (boxWriteW M_box 5 (.readLocal 28 (.lit 0)) (.readLocal 28 (.lit 1)))
      m2 m3 14 :=
    exec_boxWriteW inp m2 (.readLocal 28 (.lit 0)) (.readLocal 28 (.lit 1))
      (by simp [m2, m1]) (by omega) (by omega) (by simp [m2]) (by simp [intExprOps])
  have hs4 : DetExecAt 1 inp (boxWriteW M_box 1 (.lit 3) (.add (.readLocal 28 (.lit 1)) (.lit 1)))
      m3 m4 14 :=
    exec_boxWriteW inp m3 (.lit 3) (.add (.readLocal 28 (.lit 1)) (.lit 1))
      rfl (by omega) (by omega) (by simp [m3, m2]) (by simp [intExprOps])
  have hexec : DetExecAt 1 inp (resetSegSlotStmt M_box sE) mem m4 (intExprOps sE + 40) :=
    (hs1.seq (hs2.seq (hs3.seq hs4))).mono_cost (by omega)
  have hseg' : SegGenBound K NumSlots m4 := by
    refine ⟨by have := hseg.1; simp only [m4, wRead_wWrite_self]; omega,
      fun s' hs' => ?_,
      fun s' hs' u hu => ?_⟩
    · dsimp only [m4, m3]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]
      simp only [wRead_wWrite_eq, true_and, m2, m1, wRead_wWriteL]
      split_ifs with heq
      · omega
      · have := hseg.2.1 s' hs'; omega
    · dsimp only [m4, m3]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]
      simp only [m2, m1, wRead_wWriteL]
      have := hseg.2.2 s' hs' u hu; omega
  have hsave' : SaveGenBound n NumSlots m4 := by
    refine ⟨by have := hsave.1; simp only [m4, wRead_wWrite_self]; omega,
      fun s' hs' => ?_,
      fun s' hs' u hu => ?_⟩
    · dsimp only [m4, m3]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]
      simp only [m2, m1, wRead_wWriteL]
      have := hsave.2.1 s' hs'; omega
    · dsimp only [m4, m3]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]
      simp only [m2, m1, wRead_wWriteL]
      have := hsave.2.2 s' hs' u hu; omega
  have hempty : ∀ fSq : ℕ → ℝ, EncSegSlot K m4 s ∅ fSq := by
    intro fSq
    refine ⟨by have := hseg.1; dsimp only [m4, m3]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]; omega,
      fun x hx => False.elim (Finset.notMem_empty x hx),
      fun lvl hlvl j hj => ?_⟩
    have hj_lt : 2 ^ (K - lvl) + j < 2 ^ (K + 1) := by
      have hsub : K - lvl ≤ K := Nat.sub_le K lvl
      have hp : 2 ^ (K - lvl) ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) hsub
      have hj' : j < 2 ^ K := lt_of_lt_of_le hj hp
      have h2K : 2 ^ (K + 1) = 2 ^ K + 2 ^ K := by rw [pow_succ, Nat.mul_two]
      omega
    have hlt_g : wRead mem 8 (((s * 2 ^ (K + 1) + (2 ^ (K - lvl) + j) : ℕ) : ℤ)) < g :=
      hseg.2.2 s hs _ hj_lt
    have hw8_m4 : wRead m4 8 (((s * 2 ^ (K + 1) + (2 ^ (K - lvl) + j) : ℕ) : ℤ)) =
        wRead mem 8 (((s * 2 ^ (K + 1) + (2 ^ (K - lvl) + j) : ℕ) : ℤ)) := by
      simp [m4, m3, m2, m1]
    have hw5_m4 : wRead m4 5 (s : ℤ) = g := by simp [m4, m3]
    have hne_g : wRead m4 8 (((s * 2 ^ (K + 1) + (2 ^ (K - lvl) + j) : ℕ) : ℤ)) ≠ wRead m4 5 (s : ℤ) := by
      rw [hw8_m4, hw5_m4]; omega
    refine ⟨?_, fun hne_sub => False.elim (Finset.not_nonempty_empty
      (Finset.Nonempty.mono (Finset.filter_subset _ ∅) hne_sub))⟩
    dsimp [effSegCnt]
    push_cast at hne_g
    rw [if_neg hne_g]
    have hsub0 : segSubSet ∅ lvl j = ∅ := Finset.filter_false_of_mem (fun x hx => False.elim (Finset.notMem_empty x hx))
    simp [hsub0]
  refine ⟨m4, hexec, hseg', hsave', hempty,
    fun s' _ hne S' fSq' h0 =>
      h0.congr_mem_fSq
        (by simp [m4, m3, m2, m1, (by exact_mod_cast hne : (s' : ℤ) ≠ (s : ℤ))])
        (fun _ _ => by simp [m4, m3, m2, m1])
        (fun _ _ => by simp [m4, m3, m2, m1])
        (fun _ _ => by simp [m4, m3, m2, m1])
        (fun _ _ => by simp [m4, m3, m2, m1])
        (fun _ _ => rfl),
    (fun t h1 h5 i => by simp [m4, m3, m2, m1, h1, h5]),
    (fun i hi => by simp [m4, m3, m2, m1, hi]),
    (fun _ _ => by simp [m4, m3, m2, m1]),
    (fun v hv _ => by simp [m4, m3, m2, m1, hv]),
    (fun _ _ => by simp [m4, m3, m2, m1])⟩

/-! ### 3. Execution Specs for Phase 0 (`exec_phase0OneIterStmt` & `exec_phase0FinishStmt`) -/

theorem exec_phase0OneIterStmt {d n K M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx bS cur : ℕ} {S_birth : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d}
    (hb_pos : 0 < S_birth.card)
    (hcur_le : cur ≤ S_birth.card)
    (hBox_w23 : 8 * idx + 8 ≤ M_box)
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hw_bCard : wRead mem 23 (((8 * idx + 0 : ℕ) : ℤ)) = (S_birth.card : ℤ))
    (hw_core : wRead mem 23 (((8 * idx + 1 : ℕ) : ℤ)) =
      ((prov.core snapPts (rankPrefixSet S_birth cur)).card : ℤ))
    (hw_bS : wRead mem 23 (((8 * idx + 2 : ℕ) : ℤ)) = (bS : ℤ))
    (hw_cur : wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ))
    (hr_o : ∀ c : Fin d, rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord prov.o c)
    (hr_V : rRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = prov.V)
    (hr_max : ∀ hne : (rankPrefixSet S_birth cur).Nonempty,
      rRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) =
        (rankPrefixSet S_birth cur).sup' hne (fun x => euclideanDistSq (snapPts x) prov.o))
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hSeg_bS : EncSegSlot K mem bS S_birth (fun _ => 0))
    (hSlot_bS : EncSlotCoords d n mem activeH livePts bS S_birth snapPts) :
    let cur' := min (cur + 1) S_birth.card
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (phase0OneIterStmt d n K M_box) mem m' (220 * (K + d + 5)) ∧
      m'.popDepth 0 = m' ∧
      wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur' : ℤ) ∧
      wRead m' 23 (((8 * idx + 1 : ℕ) : ℤ)) =
        ((prov.core snapPts (rankPrefixSet S_birth cur')).card : ℤ) ∧
      (∀ hne : (rankPrefixSet S_birth cur').Nonempty,
        rRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) =
          (rankPrefixSet S_birth cur').sup' hne (fun x => euclideanDistSq (snapPts x) prov.o)) ∧
      (∀ t, t ≠ 23 → t ≠ 24 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ ((8 * idx + 1 : ℕ) : ℤ) → wRead m' 23 i = wRead mem 23 i) ∧
      (∀ i, i ≠ ((2 * idx + 1 : ℕ) : ℤ) → wRead m' 24 i = wRead mem 24 i) ∧
      (∀ t, t ≠ 24 → ∀ i, rRead m' t i = rRead mem t i) ∧
      (∀ i, i ≠ ((2 * idx + 1 : ℕ) : ℤ) → rRead m' 24 i = rRead mem 24 i) := by
  intro cur'
  have h8i0 : (8 : ℤ) * (idx : ℤ) = ((8 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
  have h8i1 : (8 : ℤ) * (idx : ℤ) + 1 = ((8 * idx + 1 : ℕ) : ℤ) := by push_cast; ring
  have h8i2 : (8 : ℤ) * (idx : ℤ) + 2 = ((8 * idx + 2 : ℕ) : ℤ) := by push_cast; ring
  have h2i0 : (2 : ℤ) * (idx : ℤ) = ((2 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
  have h2i1 : (2 : ℤ) * (idx : ℤ) + 1 = ((2 * idx + 1 : ℕ) : ℤ) := by push_cast; ring
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 29 19 (idx : ℤ)
  let m2 := wWriteL 1 m1 29 16 (cur : ℤ)
  let m3 := wWriteL 1 m2 29 17 (S_birth.card : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 19) (.readHeap 26 (.lit 7))) m0 m1 6 :=
    DetExecAt.writeWordLocal 1 inp m0 29 _ _ rfl (by simp [m0, hidx_reg]) (by simp [intExprOps])
  have hs2 : DetExecAt 1 inp
      (.writeWordLocal 29 (.lit 16) (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))))
      m1 m2 12 := by
    refine DetExecAt.writeWordLocal 1 inp m1 29 _ _ rfl ?_ (by simp [intExprOps])
    simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
      m1, wReadL_wWriteL_self, wRead_wWriteL, m0, wRead_popDepth, h2i1, hw_cur]
  have hs3 : DetExecAt 1 inp
      (.writeWordLocal 29 (.lit 17) (.readHeap 23 (.mul (.lit 8) (.readLocal 29 (.lit 19)))))
      m2 m3 10 := by
    refine DetExecAt.writeWordLocal 1 inp m2 29 _ _ rfl ?_ (by simp [intExprOps])
    have hm2_19 : wReadL 1 m2 29 19 = (idx : ℤ) := by simp [m2, m1]
    simp only [iValAt_readHeap, iValAt_mul, iValAt_lit, iValAt_readLocal, hm2_19,
      m2, m1, wRead_wWriteL, m0, wRead_popDepth, h8i0, hw_bCard]
  by_cases hk_lt : cur < S_birth.card
  · have hcur'_eq : cur' = cur + 1 := Nat.min_eq_left (Nat.succ_le_of_lt hk_lt)
    have hcond_lt : cValAt 1 inp m3 (.intLt (.readLocal 29 (.lit 16)) (.readLocal 29 (.lit 17))) = true := by
      have hm3_16 : wReadL 1 m3 29 16 = (cur : ℤ) := by simp [m3, m2]
      have hm3_17 : wReadL 1 m3 29 17 = (S_birth.card : ℤ) := by simp [m3]
      simp [hm3_16, hm3_17, hk_lt]
    let xk : ℕ := S_birth.orderEmbOfFin rfl ⟨cur, hk_lt⟩
    have hxk_in : xk ∈ S_birth := S_birth.orderEmbOfFin_mem rfl ⟨cur, hk_lt⟩
    have hxk_not : xk ∉ rankPrefixSet S_birth cur := not_mem_rankPrefixSet_self hk_lt
    have hpref_succ : rankPrefixSet S_birth (cur + 1) = insert xk (rankPrefixSet S_birth cur) :=
      rankPrefixSet_succ_lt hk_lt
    let a1 := wWriteL 1 m3 28 20 (bS : ℤ)
    let a2 := wWriteL 1 a1 28 21 (cur : ℤ)
    have ha1 : DetExecAt 1 inp
        (.writeWordLocal 28 (.lit 20) (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 2))))
        m3 a1 12 := by
      refine DetExecAt.writeWordLocal 1 inp m3 28 _ _ rfl ?_ (by simp [intExprOps])
      have hm3_19 : wReadL 1 m3 29 19 = (idx : ℤ) := by simp [m3, m2, m1]
      simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal, hm3_19,
        m3, m2, m1, wRead_wWriteL, m0, wRead_popDepth, h8i2, hw_bS]
    have ha2 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readLocal 29 (.lit 16))) a1 a2 6 := by
      refine DetExecAt.writeWordLocal 1 inp a1 28 _ _ rfl ?_ (by simp [intExprOps])
      simp [a1, m3, m2]
    have hSeg_a2 : EncSegSlot K a2 bS S_birth (fun _ => 0) :=
      hSeg_bS.congr_mem_fSq (by simp [a2, a1, m3, m2, m1, m0])
        (fun _ _ => by simp [a2, a1, m3, m2, m1, m0]) (fun _ _ => by simp [a2, a1, m3, m2, m1, m0])
        (fun _ _ => by simp [a2, a1, m3, m2, m1, m0]) (fun _ _ => by simp [a2, a1, m3, m2, m1, m0])
        (fun _ _ => rfl)
    rcases exec_selectByRankSegStmt inp a2 hk_lt (by simp [a2, a1]) (by simp [a2]) hSeg_a2
      with ⟨a3, ha3, hsel_a3, hw_a3, hr_a3, hwl_a3, _⟩
    let a4 := wWriteL 1 a3 29 20 (bS : ℤ)
    let a5 := wWriteL 1 a4 29 21 (xk : ℤ)
    have ha4 : DetExecAt 1 inp
        (.writeWordLocal 29 (.lit 20) (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 2))))
        a3 a4 12 := by
      refine DetExecAt.writeWordLocal 1 inp a3 29 _ _ rfl ?_ (by simp [intExprOps])
      have ha3_19 : wReadL 1 a3 29 19 = (idx : ℤ) := by simp [hwl_a3 29 (by decide), a2, a1, m3, m2, m1]
      simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal, ha3_19,
        hw_a3, a2, a1, m3, m2, m1, wRead_wWriteL, m0, wRead_popDepth, h8i2, hw_bS]
    have ha5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 21) (.readLocal 28 (.lit 0))) a4 a5 6 := by
      refine DetExecAt.writeWordLocal 1 inp a4 29 _ _ rfl ?_ (by simp [intExprOps])
      simp [a4, hsel_a3, xk]
    have hLive_a5 : EncLiveCoords d n a5 activeH livePts :=
      ⟨hLive.1, fun h hh c => by simp only [a5, a4, rRead_wWriteL, hr_a3, a2, a1, m3, m2, m1, m0, rRead_popDepth]; exact hLive.2 h hh c⟩
    have hSlot_a5 : EncSlotCoords d n a5 activeH livePts bS S_birth snapPts :=
      hSlot_bS.congr_mem (by simp [a5, a4, hw_a3, a2, a1, m3, m2, m1, m0])
        (fun _ => by simp [a5, a4, hw_a3, a2, a1, m3, m2, m1, m0])
        (fun _ => by simp [a5, a4, hr_a3, a2, a1, m3, m2, m1, m0])
    rcases exec_readSlotPtToLocalStmt inp a5 (destOff := 0) (by simp [a5, a4]) (by simp [a5])
        hxk_in hLive_a5 hSlot_a5
      with ⟨a6, ha6, hpt_a6, hw_a6, hr_a6, hwl_a6_29, _, _, _⟩
    let a7 := wWriteL 1 a6 29 18 (((idx * d : ℕ) : ℤ))
    have ha6_19 : wReadL 1 a6 29 19 = (idx : ℤ) := by
      rw [hwl_a6_29 19 (by decide) (by decide) (by decide)]
      simp [a5, a4, hwl_a3 29 (by decide), a2, a1, m3, m2, m1]
    have ha6_16 : wReadL 1 a6 29 16 = (cur : ℤ) := by
      rw [hwl_a6_29 16 (by decide) (by decide) (by decide)]
      simp [a5, a4, hwl_a3 29 (by decide), a2, a1, m3, m2]
    have ha7 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readLocal 29 (.lit 19)) (.lit (d : ℤ))))
        a6 a7 8 := by
      refine DetExecAt.writeWordLocal 1 inp a6 29 _ _ rfl ?_ (by simp [intExprOps])
      simp only [iValAt_mul, iValAt_readLocal, iValAt_lit, ha6_19]; push_cast; rfl
    rcases exec_loadHeapCoordsToLocalStmt inp a7 (rTag := 23) (idxBase := 18) (destOff := (d : ℤ))
        (base := idx * d) (pt := prov.o) (by decide) (by simp [a7])
        (fun c => by
          simp only [a7, rRead_wWriteL, hr_a6, a5, a4, hr_a3, a2, a1, m3, m2, m1, m0, rRead_popDepth]
          exact hr_o c)
      with ⟨a8, ha8, ho_a8, hw_a8, hr_a8, hwl_a8_29, hrl_a8_29, _, _⟩
    have hpt_a8 : ∀ c : Fin d, rReadL 1 a8 29 (c.val : ℤ) = euclideanCoord (snapPts xk) c := by
      intro c
      rw [hrl_a8_29 (c.val : ℤ) (Or.inl (by have := c.isLt; omega))]
      simpa [a7] using hpt_a6 c
    rcases exec_distSqLocalStmt inp a8 hpt_a8 (fun c => by simpa [Nat.cast_add] using ho_a8 c)
      with ⟨a9, ha9, hdsq_a9, hw_a9, hr_a9, hwl_a9_29, _, _, _⟩
    have ha9_19 : wReadL 1 a9 29 19 = (idx : ℤ) := by
      rw [hwl_a9_29 19 (by decide), hwl_a8_29 19 (by decide)]
      simp [a7, ha6_19]
    have ha9_16 : wReadL 1 a9 29 16 = (cur : ℤ) := by
      rw [hwl_a9_29 16 (by decide), hwl_a8_29 16 (by decide)]
      simp [a7, ha6_16]
    have hw_a9_m : ∀ t i, wRead a9 t i = wRead mem t i :=
      fun t i => by simp [hw_a9, hw_a8, a7, hw_a6, a5, a4, hw_a3, a2, a1, m3, m2, m1, m0]
    have hr_a9_m : ∀ t i, rRead a9 t i = rRead mem t i :=
      fun t i => by simp [hr_a9, hr_a8, a7, hr_a6, a5, a4, hr_a3, a2, a1, m3, m2, m1, m0]
    let dSq := euclideanDistSq (snapPts xk) prov.o
    have hcore_upd : ∃ a10 : ArithRAMMemory,
        DetExecAt 1 inp
          (.ite (.realLe (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))
                        (.readRealHeap 24 (.mul (.lit 2) (.readLocal 29 (.lit 19)))))
            (boxWriteW M_box 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1))
              (.add (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1))) (.lit 1)))
            .skip) a9 a10 60 ∧
        wRead a10 23 (((8 * idx + 1 : ℕ) : ℤ)) =
          ((prov.core snapPts (rankPrefixSet S_birth (cur + 1))).card : ℤ) ∧
        (∀ t, t ≠ 23 → ∀ i, wRead a10 t i = wRead a9 t i) ∧
        (∀ i, i ≠ ((8 * idx + 1 : ℕ) : ℤ) → wRead a10 23 i = wRead a9 23 i) ∧
        (∀ t i, rRead a10 t i = rRead a9 t i) ∧
        (∀ v i, wReadL 1 a10 v i = wReadL 1 a9 v i) ∧
        (∀ v i, rReadL 1 a10 v i = rReadL 1 a9 v i) := by
      have hrV_a9 : rRead a9 24 (2 * wReadL 1 a9 29 19) = prov.V := by
        rw [ha9_19, h2i0, hr_a9_m, hr_V]
      by_cases hle_c : dSq ≤ prov.V
      · have hcond_c : cValAt 1 inp a9
            (.realLe (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))
                     (.readRealHeap 24 (.mul (.lit 2) (.readLocal 29 (.lit 19))))) = true := by
          simp only [cValAt_realLe, rValAt_readRealLocal, rValAt_readRealHeap, iValAt_lit,
            iValAt_mul, iValAt_readLocal, hdsq_a9, hrV_a9, decide_eq_true_eq]
          exact hle_c
        have hcore_eq : prov.core snapPts (rankPrefixSet S_birth (cur + 1)) =
            insert xk (prov.core snapPts (rankPrefixSet S_birth cur)) := by
          ext y
          simp only [hpref_succ, mem_nodeCore_iff_distSq_le, Finset.mem_insert]
          constructor
          · rintro ⟨rfl | hy, hle⟩
            · exact Or.inl rfl
            · exact Or.inr ⟨hy, hle⟩
          · rintro (rfl | ⟨hy, hle⟩)
            · exact ⟨Or.inl rfl, hle_c⟩
            · exact ⟨Or.inr hy, hle⟩
        have hnot_c : xk ∉ prov.core snapPts (rankPrefixSet S_birth cur) :=
          fun hm => hxk_not (mem_nodeCore_iff_distSq_le _ _ _ _ |>.mp hm).1
        have hcard_c : (prov.core snapPts (rankPrefixSet S_birth (cur + 1))).card =
            (prov.core snapPts (rankPrefixSet S_birth cur)).card + 1 := by
          rw [hcore_eq, Finset.card_insert_of_notMem hnot_c]
        let a10 := wWrite a9 23 (((8 * idx + 1 : ℕ) : ℤ))
          (((prov.core snapPts (rankPrefixSet S_birth (cur + 1))).card : ℤ))
        have hw10 : DetExecAt 1 inp
            (boxWriteW M_box 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1))
              (.add (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1))) (.lit 1)))
            a9 a10 40 := by
          refine exec_boxWriteW inp a9 _ _
            (by simp only [iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal, ha9_19, h8i1])
            (by omega) (by omega) ?_ (by dsimp [intExprOps]; omega)
          simp only [iValAt_add, iValAt_readHeap, iValAt_mul, iValAt_lit, iValAt_readLocal,
            ha9_19, h8i1, hw_a9_m, hw_core, hcard_c]
          push_cast; ring
        exact ⟨a10,
          (DetExecAt.ite_true hcond_c (C_c := 16) (by simp [condExprOps, realExprOps, intExprOps]) hw10).mono_cost (by omega),
          by simp [a10],
          (fun t ht i => by simp [a10, ht]),
          (fun i hi => by simp only [a10]; rw [wRead_wWrite_of_ne _ _ (Or.inr hi)]),
          (fun _ _ => by simp [a10]),
          (fun _ _ => by simp [a10]),
          (fun _ _ => by simp [a10])⟩
      · have hcond_c : cValAt 1 inp a9
            (.realLe (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))
                     (.readRealHeap 24 (.mul (.lit 2) (.readLocal 29 (.lit 19))))) = false := by
          simp only [cValAt_realLe, rValAt_readRealLocal, rValAt_readRealHeap, iValAt_lit,
            iValAt_mul, iValAt_readLocal, hdsq_a9, hrV_a9, decide_eq_false_iff_not]
          exact hle_c
        have hcore_eq : prov.core snapPts (rankPrefixSet S_birth (cur + 1)) =
            prov.core snapPts (rankPrefixSet S_birth cur) := by
          ext y
          simp only [hpref_succ, mem_nodeCore_iff_distSq_le, Finset.mem_insert]
          constructor
          · rintro ⟨rfl | hy, hle⟩
            · exact False.elim (hle_c hle)
            · exact ⟨hy, hle⟩
          · rintro ⟨hy, hle⟩
            exact ⟨Or.inr hy, hle⟩
        refine ⟨a9,
          (DetExecAt.ite_false hcond_c (C_c := 16) (by simp [condExprOps, realExprOps, intExprOps])
            (DetExecAt.skip 1 inp a9)).mono_cost (by omega),
          by rw [hcore_eq, hw_a9_m, hw_core],
          (fun _ _ _ => rfl), (fun _ _ => rfl), (fun _ _ => rfl), (fun _ _ => rfl), (fun _ _ => rfl)⟩
    rcases hcore_upd with ⟨a10, ha10, hw_core10, hw10_o, hw10_23, hr10, hwl10, hrl10⟩
    have ha10_19 : wReadL 1 a10 29 19 = (idx : ℤ) := by rw [hwl10, ha9_19]
    have ha10_16 : wReadL 1 a10 29 16 = (cur : ℤ) := by rw [hwl10, ha9_16]
    have hdsq_a10 : rReadL 1 a10 29 (((2 * d : ℕ) : ℤ)) = dSq := by rw [hrl10]; exact hdsq_a9
    have hrmax_a10 : rRead a10 24 (2 * wReadL 1 a10 29 19 + 1) = rRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) := by
      rw [ha10_19, h2i1, hr10, hr_a9_m]
    have hmax_upd : ∃ a11 : ArithRAMMemory,
        DetExecAt 1 inp
          (.ite (.or (.intEq (.readLocal 29 (.lit 16)) (.lit 0))
                     (.realLt (.readRealHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))
                              (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))))
            (boxWriteR M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
              (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))
            .skip) a10 a11 60 ∧
        (∀ hne : (rankPrefixSet S_birth (cur + 1)).Nonempty,
          rRead a11 24 (((2 * idx + 1 : ℕ) : ℤ)) =
            (rankPrefixSet S_birth (cur + 1)).sup' hne (fun x => euclideanDistSq (snapPts x) prov.o)) ∧
        (∀ t i, wRead a11 t i = wRead a10 t i) ∧
        (∀ t, t ≠ 24 → ∀ i, rRead a11 t i = rRead a10 t i) ∧
        (∀ i, i ≠ ((2 * idx + 1 : ℕ) : ℤ) → rRead a11 24 i = rRead a10 24 i) ∧
        (∀ v i, wReadL 1 a11 v i = wReadL 1 a10 v i) := by
      by_cases htake : cur = 0 ∨ rRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) < dSq
      · have hcond_m : cValAt 1 inp a10
            (.or (.intEq (.readLocal 29 (.lit 16)) (.lit 0))
                 (.realLt (.readRealHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))
                          (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))) = true := by
          simp only [cValAt_or, cValAt_intEq, cValAt_realLt, iValAt_readLocal, iValAt_lit,
            rValAt_readRealHeap, iValAt_add, iValAt_mul, rValAt_readRealLocal,
            ha10_16, hrmax_a10, hdsq_a10, Bool.or_eq_true, decide_eq_true_eq]
          rcases htake with rfl | hlt
          · exact Or.inl rfl
          · exact Or.inr hlt
        let a11 := rWrite a10 24 (((2 * idx + 1 : ℕ) : ℤ)) dSq
        have hr11 : DetExecAt 1 inp
            (boxWriteR M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
              (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ))))) a10 a11 35 :=
          exec_boxWriteR inp a10 _ _
            (by simp only [iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal, ha10_19, h2i1])
            (by omega) (by omega) (by rw [rValAt_readRealLocal, iValAt_lit, hdsq_a10])
            (by dsimp [intExprOps, realExprOps]; omega)
        refine ⟨a11,
          (DetExecAt.ite_true hcond_m (C_c := 20) (by simp [condExprOps, realExprOps, intExprOps]) hr11).mono_cost (by omega),
          fun hne => ?_,
          (fun _ _ => by simp [a11]),
          (fun t ht _ => by simp [a11, ht]),
          (fun i hi => by simp only [a11]; rw [rRead_rWrite_of_ne _ _ (Or.inr hi)]),
          (fun _ _ => by simp [a11])⟩
        simp only [a11, rRead_rWrite_self]
        rcases Nat.eq_zero_or_pos cur with rfl | hpos
        · have hp1 : rankPrefixSet S_birth 1 = {xk} := by rw [hpref_succ, rankPrefixSet_zero]; simp
          simp [hp1, dSq]
        · have hne_prev : (rankPrefixSet S_birth cur).Nonempty := by
            have h0_lt : 0 < min cur S_birth.card := Nat.lt_min.mpr ⟨hpos, hb_pos⟩
            exact ⟨S_birth.orderEmbOfFin rfl ⟨0, hb_pos⟩,
              Finset.mem_image.mpr ⟨⟨0, h0_lt⟩, Finset.mem_univ _, rfl⟩⟩
          have hlt_prev : (rankPrefixSet S_birth cur).sup' hne_prev
              (fun x => euclideanDistSq (snapPts x) prov.o) < dSq := by
            rcases htake with rfl | hlt
            · omega
            · rwa [hr_max hne_prev] at hlt
          rw [sup'_eq_insert_of_eq hpref_succ hne hne_prev]
          exact (max_eq_left (le_of_lt hlt_prev)).symm
      · push_neg at htake
        rcases htake with ⟨hcur_ne0, hle_prev⟩
        have hpos : 0 < cur := Nat.pos_of_ne_zero hcur_ne0
        have hne_prev : (rankPrefixSet S_birth cur).Nonempty := by
          have h0_lt : 0 < min cur S_birth.card := Nat.lt_min.mpr ⟨hpos, hb_pos⟩
          exact ⟨S_birth.orderEmbOfFin rfl ⟨0, hb_pos⟩,
            Finset.mem_image.mpr ⟨⟨0, h0_lt⟩, Finset.mem_univ _, rfl⟩⟩
        have hcond_m : cValAt 1 inp a10
            (.or (.intEq (.readLocal 29 (.lit 16)) (.lit 0))
                 (.realLt (.readRealHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))
                          (.readRealLocal 29 (.lit (((2 * d : ℕ) : ℤ)))))) = false := by
          simp only [cValAt_or, cValAt_intEq, cValAt_realLt, iValAt_readLocal, iValAt_lit,
            rValAt_readRealHeap, iValAt_add, iValAt_mul, rValAt_readRealLocal,
            ha10_16, hrmax_a10, hdsq_a10, Bool.or_eq_false_iff, decide_eq_false_iff_not, not_lt]
          exact ⟨by omega, hle_prev⟩
        refine ⟨a10,
          (DetExecAt.ite_false hcond_m (C_c := 20) (by simp [condExprOps, realExprOps, intExprOps])
            (DetExecAt.skip 1 inp a10)).mono_cost (by omega),
          fun hne => ?_,
          (fun _ _ => rfl), (fun _ _ _ => rfl), (fun _ _ => rfl), (fun _ _ => rfl)⟩
        rw [hr10, hr_a9_m, hr_max hne_prev, sup'_eq_insert_of_eq hpref_succ hne hne_prev]
        rw [hr_max hne_prev] at hle_prev
        exact (max_eq_right hle_prev).symm
    rcases hmax_upd with ⟨a11, ha11, hsup11, hw11, hr11_o, hr11_24, hwl11⟩
    let a12 := wWrite a11 24 (((2 * idx + 1 : ℕ) : ℤ)) (((cur + 1 : ℕ) : ℤ))
    have ha12 : DetExecAt 1 inp
        (boxWriteW M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
          (.add (.readLocal 29 (.lit 16)) (.lit 1))) a11 a12 35 := by
      refine exec_boxWriteW inp a11 _ _
        (by simp only [iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal, hwl11, ha10_19, h2i1])
        (by omega) (by omega)
        (by simp only [iValAt_add, iValAt_readLocal, iValAt_lit, hwl11, ha10_16]; push_cast; ring)
        (by dsimp [intExprOps]; omega)
    refine ⟨a12.popDepth 0,
      DetExecAt.localScope
        ((hs1.seq (hs2.seq (hs3.seq
          (DetExecAt.ite_true hcond_lt (C_c := 10) (by simp [condExprOps, intExprOps])
            (ha1.seq (ha2.seq (ha3.seq (ha4.seq (ha5.seq (ha6.seq
              (ha7.seq (ha8.seq (ha9.seq (ha10.seq (ha11.seq ha12))))))))))))))).mono_cost (by omega)),
      popDepth_zero_idem a12,
      by rw [wRead_popDepth, hcur'_eq]; simp [a12],
      by rw [wRead_popDepth, hcur'_eq, show wRead a12 23 (((8 * idx + 1 : ℕ) : ℤ)) = wRead a10 23 (((8 * idx + 1 : ℕ) : ℤ)) by simp [a12, hw11], hw_core10],
      (fun hne => by
        rw [rRead_popDepth]
        simp only [a12, rRead_wWrite]
        have hne' : (rankPrefixSet S_birth (cur + 1)).Nonempty := hcur'_eq ▸ hne
        simpa [hcur'_eq] using hsup11 hne'),
      (fun t h23 h24 i => by simp [a12, h24, hw11, hw10_o t h23, hw_a9_m]),
      (fun i hi => by simp [a12, hw11, hw10_23 i hi, hw_a9_m]),
      (fun i hi => by
        rw [wRead_popDepth]
        simp only [a12]
        rw [wRead_wWrite_of_ne _ _ (Or.inr hi), hw11, hw10_o 24 (by decide), hw_a9_m]),
      (fun t h24 i => by simp [a12, hr11_o t h24, hr10, hr_a9_m]),
      (fun i hi => by simp [a12, hr11_24 i hi, hr10, hr_a9_m])⟩
  · have hcur_eq : cur = S_birth.card := by omega
    have hcur'_eq : cur' = cur := by dsimp [cur']; omega
    have hcond_lt : cValAt 1 inp m3 (.intLt (.readLocal 29 (.lit 16)) (.readLocal 29 (.lit 17))) = false := by
      have hm3_16 : wReadL 1 m3 29 16 = (cur : ℤ) := by simp [m3, m2]
      have hm3_17 : wReadL 1 m3 29 17 = (S_birth.card : ℤ) := by simp [m3]
      simp [hm3_16, hm3_17, hk_lt]
    refine ⟨m3.popDepth 0,
      DetExecAt.localScope
        ((hs1.seq (hs2.seq (hs3.seq
          (DetExecAt.ite_false hcond_lt (C_c := 10) (by simp [condExprOps, intExprOps])
            (DetExecAt.skip 1 inp m3))))).mono_cost (by omega)),
      popDepth_zero_idem m3,
      by rw [hcur'_eq, wRead_popDepth]; simp only [m3, m2, m1, wRead_wWriteL, m0, wRead_popDepth]; exact hw_cur,
      by rw [hcur'_eq, wRead_popDepth]; simp only [m3, m2, m1, wRead_wWriteL, m0, wRead_popDepth]; exact hw_core,
      (fun hne => by
        rw [rRead_popDepth]
        simp only [m3, m2, m1, rRead_wWriteL, m0, rRead_popDepth]
        have hne' : (rankPrefixSet S_birth cur).Nonempty := hcur'_eq ▸ hne
        simpa [hcur'_eq] using hr_max hne'),
      (fun _ _ _ _ => by simp [m3, m2, m1, m0]),
      (fun _ _ => by simp [m3, m2, m1, m0]),
      (fun _ _ => by simp [m3, m2, m1, m0]),
      (fun _ _ _ => by simp [m3, m2, m1, m0]),
      (fun _ _ => by simp [m3, m2, m1, m0])⟩

theorem exec_phase0FinishStmt {d n D K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx bS dS spDS rS spRS cur : ℕ}
    {S_birth S_parent : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d}
    (hD : 3 ≤ D)
    (hbS : bS < NumSlots) (hdS : dS < NumSlots)
    (hspDS : spDS < NumSlots) (hrS : rS < NumSlots) (hspRS : spRS < NumSlots)
    (hdist : bS ≠ dS ∧ bS ≠ spDS ∧ bS ≠ rS ∧ bS ≠ spRS ∧
             dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧
             spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS)
    (hb_pos : 0 < S_birth.card)
    (hcur_le : cur ≤ S_birth.card)
    (hBox_slots : NumSlots ≤ M_box)
    (hBox_w23 : 8 * idx + 8 ≤ M_box)
    (hBox26 : 4 ≤ M_box)
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hw_bCard : wRead mem 23 (((8 * idx + 0 : ℕ) : ℤ)) = (S_birth.card : ℤ))
    (hw_core : wRead mem 23 (((8 * idx + 1 : ℕ) : ℤ)) =
      ((prov.core snapPts (rankPrefixSet S_birth cur)).card : ℤ))
    (hw_bS : wRead mem 23 (((8 * idx + 2 : ℕ) : ℤ)) = (bS : ℤ))
    (hw_dS : wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ)) = (dS : ℤ))
    (hw_spDS : wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ)) = (spDS : ℤ))
    (hw_rS : wRead mem 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ))
    (hw_spRS : wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ))
    (h6_bS : 1 ≤ wRead mem 6 (bS : ℤ))
    (h6_dS : wRead mem 6 (dS : ℤ) = 0)
    (h6_spDS : wRead mem 6 (spDS : ℤ) = 0)
    (h6_rS : wRead mem 6 (rS : ℤ) = 0)
    (h6_spRS : wRead mem 6 (spRS : ℤ) = 0)
    (hw_ph : wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0)
    (hw_cur : wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ))
    (hr_o : ∀ c : Fin d, rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord prov.o c)
    (hr_V : rRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = prov.V)
    (hr_max : ∀ hne : (rankPrefixSet S_birth cur).Nonempty,
      rRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) =
        (rankPrefixSet S_birth cur).sup' hne (fun x => euclideanDistSq (snapPts x) prov.o))
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem)
    (hSeg_bS : EncSegSlot K mem bS S_birth (fun _ => 0))
    (hSlot_bS : EncSlotCoords d n mem activeH livePts bS S_birth snapPts) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (phase0FinishStmt D M_box) mem m' 800 ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      SaveGenBound n NumSlots m' ∧
      EncJobLevel d n D K NumSlots m' activeH livePts idx S_birth snapPts prov S_parent true ∧
      (cur < S_birth.card →
        wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 ∧
        wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ)) ∧
      (cur = S_birth.card →
        wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 1 ∧
        wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = 0) ∧
      (∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ s' < NumSlots, ∀ S₁ sp₁,
        EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
        EncSlotCoords d n m' activeH livePts s' S₁ sp₁) ∧
      (∀ t, t ≠ 1 → t ≠ 5 → t ≠ 24 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 3 → wRead m' 1 i = wRead mem 1 i) ∧
      (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
        wRead m' 24 i = wRead mem 24 i) ∧
      (∀ t, t ≠ 24 → ∀ i, rRead m' t i = rRead mem t i) ∧
      (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
        rRead m' 24 i = rRead mem 24 i) := by
  rcases hdist with ⟨hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR⟩
  let ball := applyBirthCoreFallback (1 / (4 * (D : ℝ) ^ 2)) snapPts S_birth prov
  have h8i0 : (8 : ℤ) * (idx : ℤ) = ((8 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
  have h8i1 : (8 : ℤ) * (idx : ℤ) + 1 = ((8 * idx + 1 : ℕ) : ℤ) := by push_cast; ring
  have h8i3 : (8 : ℤ) * (idx : ℤ) + 3 = ((8 * idx + 3 : ℕ) : ℤ) := by push_cast; ring
  have h8i4 : (8 : ℤ) * (idx : ℤ) + 4 = ((8 * idx + 4 : ℕ) : ℤ) := by push_cast; ring
  have h8i5 : (8 : ℤ) * (idx : ℤ) + 5 = ((8 * idx + 5 : ℕ) : ℤ) := by push_cast; ring
  have h8i6 : (8 : ℤ) * (idx : ℤ) + 6 = ((8 * idx + 6 : ℕ) : ℤ) := by push_cast; ring
  have h2i0 : (2 : ℤ) * (idx : ℤ) = ((2 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
  have h2i1 : (2 : ℤ) * (idx : ℤ) + 1 = ((2 * idx + 1 : ℕ) : ℤ) := by push_cast; ring
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 29 19 (idx : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 19) (.readHeap 26 (.lit 7))) m0 m1 6 :=
    DetExecAt.writeWordLocal 1 inp m0 29 _ _ rfl (by simp [m0, hidx_reg]) (by simp [intExprOps])
  by_cases hdone : cur = S_birth.card
  · subst hdone
    have hfull : rankPrefixSet S_birth S_birth.card = S_birth := rankPrefixSet_full le_rfl
    have hne_full : (rankPrefixSet S_birth S_birth.card).Nonempty := by
      rw [hfull]; exact Finset.card_pos.mp hb_pos
    have hne_S : S_birth.Nonempty := Finset.card_pos.mp hb_pos
    have hrmax_S : rRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) =
        S_birth.sup' hne_S (fun x => euclideanDistSq (snapPts x) prov.o) := by
      have h1 := hr_max hne_full
      simpa [hfull] using h1
    have hball_eq := applyBirthCoreFallback_eq_nat hD snapPts hne_S prov hrmax_S
      (by
        rcases hne_S with ⟨x0, hx0⟩
        rw [hrmax_S]
        exact le_trans (by unfold euclideanDistSq; positivity)
          (Finset.le_sup' (fun x => euclideanDistSq (snapPts x) prov.o) hx0))
    have hcond_eq : cValAt 1 inp m1
        (.intEq (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))
                (.readHeap 23 (.mul (.lit 8) (.readLocal 29 (.lit 19))))) = true := by
      simp only [cValAt_intEq, iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
        m1, wReadL_wWriteL_self, wRead_wWriteL, m0, wRead_popDepth, h2i1, h8i0, hw_cur, hw_bCard, decide_true]
    have hV_step : ∃ m2 : ArithRAMMemory,
        DetExecAt 1 inp
          (.ite (.intLe (.readHeap 23 (.mul (.lit 8) (.readLocal 29 (.lit 19))))
                        (.mul (.lit (((8 * D ^ 2 : ℕ) : ℤ)))
                              (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1)))))
            .skip
            (boxWriteR M_box 24 (.mul (.lit 2) (.readLocal 29 (.lit 19)))
              (.readRealHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))))
          m1 m2 50 ∧
        rRead m2 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V ∧
        (∀ t i, wRead m2 t i = wRead m1 t i) ∧
        (∀ t, t ≠ 24 → ∀ i, rRead m2 t i = rRead m1 t i) ∧
        (∀ i, i ≠ ((2 * idx + 0 : ℕ) : ℤ) → rRead m2 24 i = rRead m1 24 i) ∧
        (∀ v i, wReadL 1 m2 v i = wReadL 1 m1 v i) := by
      have hw_core_S : wRead m1 23 (8 * wReadL 1 m1 29 19 + 1) = ((prov.core snapPts S_birth).card : ℤ) := by
        simp only [m1, wReadL_wWriteL_self, wRead_wWriteL, m0, wRead_popDepth, h8i1, hw_core, hfull]
      have hw_bC_m1 : wRead m1 23 (8 * wReadL 1 m1 29 19) = (S_birth.card : ℤ) := by
        simp only [m1, wReadL_wWriteL_self, wRead_wWriteL, m0, wRead_popDepth, h8i0, hw_bCard]
      by_cases hpass_nat : S_birth.card ≤ 8 * D ^ 2 * (prov.core snapPts S_birth).card
      · have hcond_fb : cValAt 1 inp m1
            (.intLe (.readHeap 23 (.mul (.lit 8) (.readLocal 29 (.lit 19))))
                    (.mul (.lit (((8 * D ^ 2 : ℕ) : ℤ)))
                          (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1))))) = true := by
          simp only [cValAt_intLe, iValAt_readHeap, iValAt_mul, iValAt_add, iValAt_lit, iValAt_readLocal,
            hw_bC_m1, hw_core_S, decide_eq_true_eq]
          exact_mod_cast hpass_nat
        refine ⟨m1,
          (DetExecAt.ite_true hcond_fb (C_c := 22) (by simp [condExprOps, intExprOps])
            (DetExecAt.skip 1 inp m1)).mono_cost (by omega),
          by rw [hball_eq.2, if_pos hpass_nat]; simp only [m1, rRead_wWriteL, m0, rRead_popDepth]; exact hr_V,
          (fun _ _ => rfl), (fun _ _ _ => rfl), (fun _ _ => rfl), (fun _ _ => rfl)⟩
      · have hcond_fb : cValAt 1 inp m1
            (.intLe (.readHeap 23 (.mul (.lit 8) (.readLocal 29 (.lit 19))))
                    (.mul (.lit (((8 * D ^ 2 : ℕ) : ℤ)))
                          (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 1))))) = false := by
          simp only [cValAt_intLe, iValAt_readHeap, iValAt_mul, iValAt_add, iValAt_lit, iValAt_readLocal,
            hw_bC_m1, hw_core_S, decide_eq_false_iff_not]
          exact_mod_cast hpass_nat
        let m2 := rWrite m1 24 (((2 * idx + 0 : ℕ) : ℤ)) (rRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)))
        have hr2 : DetExecAt 1 inp
            (boxWriteR M_box 24 (.mul (.lit 2) (.readLocal 29 (.lit 19)))
              (.readRealHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))) m1 m2 26 :=
          exec_boxWriteR inp m1 _ _
            (by simp only [iValAt_mul, iValAt_lit, iValAt_readLocal, m1, wReadL_wWriteL_self, h2i0])
            (by omega) (by omega)
            (by simp only [rValAt_readRealHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
                  m1, wReadL_wWriteL_self, rRead_wWriteL, m0, rRead_popDepth, h2i1])
            (by simp [intExprOps, realExprOps])
        refine ⟨m2,
          (DetExecAt.ite_false hcond_fb (C_c := 22) (by simp [condExprOps, intExprOps]) hr2).mono_cost (by omega),
          by rw [hball_eq.2, if_neg hpass_nat]; simp only [m2, rRead_rWrite_self],
          (fun _ _ => by simp [m2]),
          (fun t ht _ => by simp [m2, ht]),
          (fun i hi => by simp only [m2]; rw [rRead_rWrite_of_ne _ _ (Or.inr hi)]),
          (fun _ _ => by simp [m2])⟩
    rcases hV_step with ⟨m2, hs2, hrV_2, hw_2, hr_2o, hr_2_24, hwl_2⟩
    have hm2_19 : wReadL 1 m2 29 19 = (idx : ℤ) := by simp [hwl_2, m1]
    have hseg_2 : SegGenBound K NumSlots m2 :=
      ⟨by simp [hw_2, m1, m0]; exact hseg.1,
       fun s hs => by simp [hw_2, m1, m0]; exact hseg.2.1 s hs,
       fun s hs u hu => by simp [hw_2, m1, m0]; exact hseg.2.2 s hs u hu⟩
    have hsave_2 : SaveGenBound n NumSlots m2 :=
      ⟨by simp [hw_2, m1, m0]; exact hsave.1,
       fun s hs => by simp [hw_2, m1, m0]; exact hsave.2.1 s hs,
       fun s hs u hu => by simp [hw_2, m1, m0]; exact hsave.2.2 s hs u hu⟩
    rcases exec_resetSegSlotStmt_save inp m2
        (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 3))) hdS
        (by simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
              hm2_19, hw_2, m1, wRead_wWriteL, m0, wRead_popDepth, h8i3, hw_dS])
        hBox26 hBox_slots hseg_2 hsave_2
      with ⟨r1, hrst1, hseg_r1, hsave_r1, hEd_r1, hO1, hw_r1, hw1_r1, hr_r1, hwl_r1, _⟩
    have hr1_19 : wReadL 1 r1 29 19 = (idx : ℤ) := by rw [hwl_r1 29 (by decide), hm2_19]
    rcases exec_resetSegSlotStmt_save inp r1
        (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 4))) hspDS
        (by simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
              hr1_19, hw_r1 23 (by decide) (by decide), hw_2, m1, wRead_wWriteL, m0, wRead_popDepth, h8i4, hw_spDS])
        hBox26 hBox_slots hseg_r1 hsave_r1
      with ⟨r2, hrst2, hseg_r2, hsave_r2, hEspD_r2, hO2, hw_r2, hw1_r2, hr_r2, hwl_r2, _⟩
    have hr2_19 : wReadL 1 r2 29 19 = (idx : ℤ) := by rw [hwl_r2 29 (by decide), hr1_19]
    rcases exec_resetSegSlotStmt_save inp r2
        (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 5))) hrS
        (by simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
              hr2_19, hw_r2 23 (by decide) (by decide), hw_r1 23 (by decide) (by decide),
              hw_2, m1, wRead_wWriteL, m0, wRead_popDepth, h8i5, hw_rS])
        hBox26 hBox_slots hseg_r2 hsave_r2
      with ⟨r3, hrst3, hseg_r3, hsave_r3, hEr_r3, hO3, hw_r3, hw1_r3, hr_r3, hwl_r3, _⟩
    have hr3_19 : wReadL 1 r3 29 19 = (idx : ℤ) := by rw [hwl_r3 29 (by decide), hr2_19]
    rcases exec_resetSegSlotStmt_save inp r3
        (.readHeap 23 (.add (.mul (.lit 8) (.readLocal 29 (.lit 19))) (.lit 6))) hspRS
        (by simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
              hr3_19, hw_r3 23 (by decide) (by decide), hw_r2 23 (by decide) (by decide),
              hw_r1 23 (by decide) (by decide), hw_2, m1, wRead_wWriteL, m0, wRead_popDepth, h8i6, hw_spRS])
        hBox26 hBox_slots hseg_r3 hsave_r3
      with ⟨r4, hrst4, hseg_r4, hsave_r4, hEspR_r4, hO4, hw_r4, hw1_r4, hr_r4, hwl_r4, _⟩
    have hr4_19 : wReadL 1 r4 29 19 = (idx : ℤ) := by rw [hwl_r4 29 (by decide), hr3_19]
    let r5 := wWrite r4 24 (((2 * idx + 0 : ℕ) : ℤ)) 1
    let r6 := wWrite r5 24 (((2 * idx + 1 : ℕ) : ℤ)) 0
    have hrst5 : DetExecAt 1 inp (boxWriteW M_box 24 (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
        r4 r5 30 :=
      exec_boxWriteW inp r4 _ _
        (by simp only [iValAt_mul, iValAt_lit, iValAt_readLocal, hr4_19, h2i0])
        (by omega) (by omega) rfl (by dsimp [intExprOps]; omega)
    have hrst6 : DetExecAt 1 inp (boxWriteW M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)) (.lit 0))
        r5 r6 30 :=
      exec_boxWriteW inp r5 _ _
        (by simp only [iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal, r5, wReadL_wWrite, hr4_19, h2i1])
        (by omega) (by omega) rfl (by dsimp [intExprOps]; omega)
    have hEd_r4 := hO4 dS hdS hdspR _ _ (hO3 dS hdS hdr _ _ (hO2 dS hdS hdspD _ _
      (hEd_r1 (fun x => euclideanDistSq (livePts x) ball.o))))
    have hEspD_r4 := hO4 spDS hspDS hspDspR _ _ (hO3 spDS hspDS hspDr _ _ (hEspD_r2 (fun _ => 0)))
    have hEr_r4 := hO4 rS hrS hrspR _ _ (hEr_r3 (fun _ => 0))
    have hEspR_r4' := hEspR_r4 (fun _ => 0)
    have hflt0 : S_parent.filter (· < 0) = ∅ := by ext x; simp
    have hres0 : ball.residual livePts (S_parent.filter (· < 0)) = ∅ := by rw [hflt0]; rfl
    have hw_r4_o : ∀ t, t ≠ 1 → t ≠ 5 → ∀ i, wRead r4 t i = wRead mem t i := by
      intro t h1 h5 i
      simp [hw_r4 t h1 h5, hw_r3 t h1 h5, hw_r2 t h1 h5, hw_r1 t h1 h5, hw_2, m1, m0]
    have hr_r4_all : ∀ t i, rRead r4 t i = rRead m2 t i := by
      intro t i; simp [hr_r4, hr_r3, hr_r2, hr_r1]
    have hother_all : ∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K (r6.popDepth 0) s' S₁ fSq₁ := by
      intro s' hs' h1 h2 h3 h4 S₁ fSq₁ h0
      have a0 : EncSegSlot K m2 s' S₁ fSq₁ :=
        h0.congr_mem_fSq (by simp [hw_2, m1, m0]) (fun _ _ => by simp [hw_2, m1, m0])
          (fun _ _ => by simp [hw_2, m1, m0]) (fun _ _ => by simp [hw_2, m1, m0])
          (fun _ _ => by simp [hr_2o 8 (by decide), m1, m0]) (fun _ _ => rfl)
      have a1 := hO4 s' hs' h4 _ _ (hO3 s' hs' h3 _ _ (hO2 s' hs' h2 _ _ (hO1 s' hs' h1 _ _ a0)))
      exact a1.congr_mem_fSq (by simp [r6, r5]) (fun _ _ => by simp [r6, r5])
        (fun _ _ => by simp [r6, r5]) (fun _ _ => by simp [r6, r5])
        (fun _ _ => by simp [r6, r5]) (fun _ _ => rfl)
    have hsnap_all : ∀ s' < NumSlots, ∀ S₁ sp₁,
        EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
        EncSlotCoords d n (r6.popDepth 0) activeH livePts s' S₁ sp₁ := by
      intro s' _ S₁ sp₁ h0
      exact h0.congr_mem
        (by simp [r6, r5, hw_r4_o 6 (by decide) (by decide)])
        (fun _ => by simp [r6, r5, hw_r4_o 11 (by decide) (by decide)])
        (fun _ => by simp [r6, r5, hr_r4_all, hr_2o 11 (by decide), m1, m0])
    have hw_r6_23 : ∀ i, wRead (r6.popDepth 0) 23 i = wRead mem 23 i :=
      fun i => by simp [r6, r5, hw_r4_o 23 (by decide) (by decide) i]
    have hw_r6_6 : ∀ i, wRead (r6.popDepth 0) 6 i = wRead mem 6 i :=
      fun i => by simp [r6, r5, hw_r4_o 6 (by decide) (by decide) i]
    have hw_ph_r6 : wRead (r6.popDepth 0) 24 (((2 * idx + 0 : ℕ) : ℤ)) = 1 := by
      rw [wRead_popDepth]
      simp only [r6, r5, wRead_wWrite_eq, true_and]
      split_ifs <;> omega
    have hw_cur_r6 : wRead (r6.popDepth 0) 24 (((2 * idx + 1 : ℕ) : ℤ)) = 0 := by
      simp [r6]
    have hw_r6_r4 : ∀ t, t ≠ 24 → ∀ i, wRead (r6.popDepth 0) t i = wRead r4 t i :=
      fun t ht i => by simp [r6, r5, ht]
    have hr_r6_r4 : ∀ t i, rRead (r6.popDepth 0) t i = rRead r4 t i :=
      fun t i => by simp [r6, r5]
    refine ⟨r6.popDepth 0,
      DetExecAt.localScope
        ((hs1.seq (DetExecAt.ite_true hcond_eq (C_c := 20) (by simp [condExprOps, intExprOps])
          (hs2.seq (hrst1.seq (hrst2.seq (hrst3.seq (hrst4.seq (hrst5.seq hrst6)))))))).mono_cost
          (by dsimp [intExprOps]; omega)),
      popDepth_zero_idem r6,
      ⟨by simp [r6, r5]; exact hseg_r4.1,
       fun s hs => by simp [r6, r5]; exact hseg_r4.2.1 s hs,
       fun s hs u hu => by simp [r6, r5]; exact hseg_r4.2.2 s hs u hu⟩,
      ⟨by simp [r6, r5]; exact hsave_r4.1,
       fun s hs => by simp [r6, r5]; exact hsave_r4.2.1 s hs,
       fun s hs u hu => by simp [r6, r5]; exact hsave_r4.2.2 s hs u hu⟩,
      ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
       hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
       by rw [hw_r6_23, hw_bS], by rw [hw_r6_23, hw_dS], by rw [hw_r6_23, hw_spDS],
       by rw [hw_r6_23, hw_rS], by rw [hw_r6_23, hw_spRS],
       by rw [hw_r6_6]; exact h6_bS, by rw [hw_r6_6]; exact h6_dS,
       by rw [hw_r6_6]; exact h6_spDS, by rw [hw_r6_6]; exact h6_rS,
       by rw [hw_r6_6, h6_spRS]; simp,
       hb_pos, by rw [hw_r6_23, hw_bCard],
       hother_all bS hbS hbd hbspD hbr hbspR _ _ hSeg_bS,
       hsnap_all bS hbS _ _ hSlot_bS,
       fun c => by simp only [rRead_popDepth, r6, r5, rRead_wWrite, hr_r4_all, hr_2o 23 (by decide), m1, rRead_wWriteL, m0]; exact hr_o c,
       Or.inr (Or.inl ⟨0, Nat.zero_le _, hw_ph_r6, hw_cur_r6,
         by simp only [rRead_popDepth, r6, r5, rRead_wWrite, hr_r4_all]; exact hrV_2,
         by rw [hflt0]; exact hEd_r4.congr_mem_fSq (hw_r6_r4 5 (by decide) _)
             (fun _ _ => hw_r6_r4 8 (by decide) _) (fun _ _ => hw_r6_r4 9 (by decide) _)
             (fun _ _ => hw_r6_r4 10 (by decide) _) (fun _ _ => hr_r6_r4 8 _) (fun _ _ => rfl),
         by rw [hflt0]; exact hEspD_r4.congr_mem_fSq (hw_r6_r4 5 (by decide) _)
             (fun _ _ => hw_r6_r4 8 (by decide) _) (fun _ _ => hw_r6_r4 9 (by decide) _)
             (fun _ _ => hw_r6_r4 10 (by decide) _) (fun _ _ => hr_r6_r4 8 _) (fun _ _ => rfl),
         by rw [hres0]; exact hEr_r4.congr_mem_fSq (hw_r6_r4 5 (by decide) _)
             (fun _ _ => hw_r6_r4 8 (by decide) _) (fun _ _ => hw_r6_r4 9 (by decide) _)
             (fun _ _ => hw_r6_r4 10 (by decide) _) (fun _ _ => hr_r6_r4 8 _) (fun _ _ => rfl),
         rfl,
         by rw [hres0]; exact hEspR_r4'.congr_mem_fSq (hw_r6_r4 5 (by decide) _)
             (fun _ _ => hw_r6_r4 8 (by decide) _) (fun _ _ => hw_r6_r4 9 (by decide) _)
             (fun _ _ => hw_r6_r4 10 (by decide) _) (fun _ _ => hr_r6_r4 8 _) (fun _ _ => rfl)⟩)⟩,
      (fun hlt => by omega),
      (fun _ => ⟨hw_ph_r6, hw_cur_r6⟩),
      hother_all,
      hsnap_all,
      (fun t h1 h5 h24 i => by simp [r6, r5, h24, hw_r4_o t h1 h5]),
      (fun i hi => by simp [r6, r5, hw1_r4 i hi, hw1_r3 i hi, hw1_r2 i hi, hw1_r1 i hi, hw_2, m1, m0]),
      (fun i hi => by
        rw [wRead_popDepth]
        simp only [r6, r5, wRead_wWrite_eq, true_and]
        split_ifs <;> try omega
        exact hw_r4_o 24 (by decide) (by decide) i),
      (fun t h24 i => by simp [r6, r5, hr_r4_all, hr_2o t h24, m1, m0]),
      (fun i hi => by
        rw [rRead_popDepth]
        simp only [r6, r5, rRead_wWrite, hr_r4_all]
        rw [hr_2_24 i (by omega)]
        simp [m1, m0])⟩
  · -- `cur < S_birth.card`: `phase0FinishStmt` skips!
    have hlt_cur : cur < S_birth.card := by omega
    have hcond_eq : cValAt 1 inp m1
        (.intEq (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))
                (.readHeap 23 (.mul (.lit 8) (.readLocal 29 (.lit 19))))) = false := by
      simp only [cValAt_intEq, iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
        m1, wReadL_wWriteL_self, wRead_wWriteL, m0, wRead_popDepth, h2i1, h8i0, hw_cur, hw_bCard,
        decide_eq_false_iff_not]
      exact_mod_cast hdone
    have hw_m1 : ∀ t i, wRead (m1.popDepth 0) t i = wRead mem t i := fun _ _ => by simp [m1, m0]
    have hr_m1 : ∀ t i, rRead (m1.popDepth 0) t i = rRead mem t i := fun _ _ => by simp [m1, m0]
    refine ⟨m1.popDepth 0,
      DetExecAt.localScope
        ((hs1.seq (DetExecAt.ite_false hcond_eq (C_c := 20) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 1 inp m1))).mono_cost (by omega)),
      popDepth_zero_idem m1,
      ⟨by rw [hw_m1]; exact hseg.1,
       fun s hs => by rw [hw_m1, hw_m1]; exact hseg.2.1 s hs,
       fun s hs u hu => by rw [hw_m1, hw_m1]; exact hseg.2.2 s hs u hu⟩,
      ⟨by rw [hw_m1]; exact hsave.1,
       fun s hs => by rw [hw_m1, hw_m1]; exact hsave.2.1 s hs,
       fun s hs u hu => by rw [hw_m1, hw_m1]; exact hsave.2.2 s hs u hu⟩,
      ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
       hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
       by rw [hw_m1, hw_bS], by rw [hw_m1, hw_dS], by rw [hw_m1, hw_spDS],
       by rw [hw_m1, hw_rS], by rw [hw_m1, hw_spRS],
       by rw [hw_m1]; exact h6_bS, by rw [hw_m1]; exact h6_dS,
       by rw [hw_m1]; exact h6_spDS, by rw [hw_m1]; exact h6_rS,
       by rw [hw_m1, h6_spRS]; simp,
       hb_pos, by rw [hw_m1, hw_bCard],
       hSeg_bS.congr_mem_fSq (by rw [hw_m1]) (fun _ _ => by rw [hw_m1]) (fun _ _ => by rw [hw_m1])
         (fun _ _ => by rw [hw_m1]) (fun _ _ => by rw [hr_m1]) (fun _ _ => rfl),
       hSlot_bS.congr_mem (by rw [hw_m1]) (fun _ => by rw [hw_m1]) (fun _ => by rw [hr_m1]),
       fun c => by rw [hr_m1, hr_o c],
       Or.inl ⟨cur, hcur_le, by rw [hw_m1, hw_ph], by rw [hw_m1, hw_cur], by rw [hw_m1, hw_core],
         by rw [hr_m1, hr_V], fun hne => by rw [hr_m1, hr_max hne], rfl⟩⟩,
      (fun _ => ⟨by rw [hw_m1, hw_ph], by rw [hw_m1, hw_cur]⟩),
      (fun heq => False.elim (hdone heq)),
      (fun _ _ _ _ _ _ _ _ h0 => h0.congr_mem_fSq (by rw [hw_m1]) (fun _ _ => by rw [hw_m1])
        (fun _ _ => by rw [hw_m1]) (fun _ _ => by rw [hw_m1]) (fun _ _ => by rw [hr_m1]) (fun _ _ => rfl)),
      (fun _ _ _ _ h0 => h0.congr_mem (by rw [hw_m1]) (fun _ => by rw [hw_m1]) (fun _ => by rw [hr_m1])),
      (fun _ _ _ _ _ => by rw [hw_m1]),
      (fun _ _ => by rw [hw_m1]),
      (fun _ _ => by rw [hw_m1]),
      (fun _ _ _ => by rw [hr_m1]),
      (fun _ _ => by rw [hr_m1])⟩

/-! ### 4. Execution Specs for Phase 1 (`exec_phase1OneIterStmt` & `exec_phase1FinishStmt`) -/

theorem exec_phase1OneIterStmt {d n K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx pS dS spDS rS spRS cur : ℕ}
    {ball : ChainNode d}
    {S_parent : Finset ℕ} {fSq_p : ℕ → ℝ}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    (hdS : dS < NumSlots) (hspDS : spDS < NumSlots)
    (hrS : rS < NumSlots) (hspRS : spRS < NumSlots)
    (hdist4 : dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧ spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS)
    (_hpS_ne : pS ≠ dS ∧ pS ≠ spDS ∧ pS ≠ rS ∧ pS ≠ spRS)
    (hcur_le : cur ≤ 2 ^ K)
    (hS_sub : S_parent ⊆ activeH)
    (hBox_w23 : 8 * idx + 8 ≤ M_box)
    (hBox26 : 30 ≤ M_box)
    (hMs : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hpS_reg : wRead mem 26 9 = (pS : ℤ))
    (hw_dS : wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ)) = (dS : ℤ))
    (hw_spDS : wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ)) = (spDS : ℤ))
    (hw_rS : wRead mem 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ))
    (hw_spRS : wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ))
    (h6_spRS : wRead mem 6 (spRS : ℤ) = 0)
    (hw_cur : wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ))
    (hr_bo : ∀ c : Fin d, rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord ball.o c)
    (hr_V : rRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V)
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hgen : SegGenBound K NumSlots mem)
    (hSeg_p : EncSegSlot K mem pS S_parent fSq_p)
    (hEd : EncSegSlot K mem dS (S_parent.filter (· < cur)) (fun x => euclideanDistSq (livePts x) ball.o))
    (hEspD : EncSegSlot K mem spDS (S_parent.filter (· < cur)) (fun _ => 0))
    (hEr : EncSegSlot K mem rS (ball.residual livePts (S_parent.filter (· < cur))) (fun _ => 0))
    (hEspR : EncSegSlot K mem spRS (ball.residual livePts (S_parent.filter (· < cur))) (fun _ => 0)) :
    ∃ (m' : ArithRAMMemory) (cur' : ℕ),
      DetExecAt 0 inp (phase1OneIterStmt d K M_box) mem m' (1350 * (K + 1) + 150 * (d + 1) + 800) ∧
      m'.popDepth 0 = m' ∧
      cur' ≤ 2 ^ K ∧
      wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur' : ℤ) ∧
      (cur' = 2 ^ K ∨
        (S_parent.filter (fun x => cur' ≤ x)).card + 1 = (S_parent.filter (fun x => cur ≤ x)).card) ∧
      SegGenBound K NumSlots m' ∧
      EncSegSlot K m' dS (S_parent.filter (· < cur')) (fun x => euclideanDistSq (livePts x) ball.o) ∧
      EncSegSlot K m' spDS (S_parent.filter (· < cur')) (fun _ => 0) ∧
      EncSegSlot K m' rS (ball.residual livePts (S_parent.filter (· < cur'))) (fun _ => 0) ∧
      EncSegSlot K m' spRS (ball.residual livePts (S_parent.filter (· < cur'))) (fun _ => 0) ∧
      (∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 24 → t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ ((2 * idx + 1 : ℕ) : ℤ) → wRead m' 24 i = wRead mem 24 i) ∧
      (∀ i, i ≠ 3 → i ≠ 4 → i ≠ 5 → i ≠ 6 → i ≠ 8 → i ≠ 25 → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t, t ≠ 8 → t ≠ 26 → ∀ i, rRead m' t i = rRead mem t i) := by
  have h2i1 : (2 : ℤ) * (idx : ℤ) + 1 = ((2 * idx + 1 : ℕ) : ℤ) := by push_cast; ring
  let l0 := mem.popDepth 0
  let l1 := wWriteL 1 l0 29 19 (idx : ℤ)
  let l2 := wWriteL 1 l1 29 16 (cur : ℤ)
  have hl1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 19) (.readHeap 26 (.lit 7))) l0 l1 6 :=
    DetExecAt.writeWordLocal 1 inp l0 29 _ _ rfl (by simp [l0, hidx_reg]) (by simp [intExprOps])
  have hl2 : DetExecAt 1 inp
      (.writeWordLocal 29 (.lit 16) (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))))
      l1 l2 12 := by
    refine DetExecAt.writeWordLocal 1 inp l1 29 _ _ rfl ?_ (by simp [intExprOps])
    simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal,
      l1, wReadL_wWriteL_self, wRead_wWriteL, l0, wRead_popDepth, h2i1, hw_cur]
  by_cases hcur_lt : cur < 2 ^ K
  · have hcond_lt : cValAt 1 inp l2 (.intLt (.readLocal 29 (.lit 16)) (.lit (((2 ^ K : ℕ) : ℤ)))) = true := by
      have hl2_16 : wReadL 1 l2 29 16 = (cur : ℤ) := by simp [l2]
      simp only [cValAt_intLt, iValAt_readLocal, iValAt_lit, hl2_16, decide_eq_true_eq]
      exact_mod_cast hcur_lt
    let l3 := wWriteL 1 l2 28 20 (pS : ℤ)
    let l4 := wWriteL 1 l3 28 21 (cur : ℤ)
    have hl3 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 20) (.readHeap 26 (.lit 9))) l2 l3 6 :=
      DetExecAt.writeWordLocal 1 inp l2 28 _ _ rfl (by simp [l2, l1, l0, hpS_reg]) (by simp [intExprOps])
    have hl4 : DetExecAt 1 inp (.writeWordLocal 28 (.lit 21) (.readLocal 29 (.lit 16))) l3 l4 6 :=
      DetExecAt.writeWordLocal 1 inp l3 28 _ _ rfl (by simp [l3, l2]) (by simp [intExprOps])
    have hSeg_p4 : EncSegSlot K l4 pS S_parent fSq_p :=
      hSeg_p.congr_mem_fSq (by simp [l4, l3, l2, l1, l0])
        (fun _ _ => by simp [l4, l3, l2, l1, l0]) (fun _ _ => by simp [l4, l3, l2, l1, l0])
        (fun _ _ => by simp [l4, l3, l2, l1, l0]) (fun _ _ => by simp [l4, l3, l2, l1, l0])
        (fun _ _ => rfl)
    rcases exec_findSuccSegStmt inp l4 (s := pS) (q := cur) (by simp [l4, l3]) (by simp [l4]) hSeg_p4
      with ⟨l5, hl5, hfound_5, hnot_5, hw_l5, hr_l5, hwl_l5, _⟩
    have hl5_19 : wReadL 1 l5 29 19 = (idx : ℤ) := by simp [hwl_l5 29 (by decide), l4, l3, l2, l1]
    by_cases hex : ∃ x ∈ S_parent, cur ≤ x
    · rcases hfound_5 hex with ⟨hw28_1, y, hy_in, hw28_0, hcur_y, hy_min⟩
      have hy_2K : y < 2 ^ K := hSeg_p.2.1 y hy_in
      have hy_act : y ∈ activeH := hS_sub hy_in
      have hy_not_flt : y ∉ S_parent.filter (· < cur) := by
        simp only [Finset.mem_filter]; omega
      have hflt_succ : S_parent.filter (· < y + 1) = insert y (S_parent.filter (· < cur)) :=
        filter_lt_succ_of_min hy_in hcur_y hy_min
      have hrem_succ : (S_parent.filter (fun x => y + 1 ≤ x)).card + 1 =
          (S_parent.filter (fun x => cur ≤ x)).card :=
        card_filter_ge_succ_of_min hy_in hcur_y hy_min
      have hcond_f : cValAt 1 inp l5 (.intEq (.readLocal 28 (.lit 1)) (.lit 1)) = true := by
        simp [hw28_1]
      let l6 := wWrite l5 26 4 (y : ℤ)
      let l7 := wWrite l6 26 5 1
      let l8 := wWrite l7 26 25 1
      let l9 := wWrite l8 24 (((2 * idx + 1 : ℕ) : ℤ)) (((y + 1 : ℕ) : ℤ))
      have hl6 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 4) (.readLocal 28 (.lit 0))) l5 l6 16 :=
        exec_boxWriteW inp l5 _ _ rfl (by omega) (by omega) (by simp [hw28_0]) (by simp [intExprOps])
      have hl7 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 5) (.lit 1)) l6 l7 14 :=
        exec_boxWriteW inp l6 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
      have hl8 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 25) (.lit 1)) l7 l8 14 :=
        exec_boxWriteW inp l7 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
      have hl9 : DetExecAt 1 inp
          (boxWriteW M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
            (.add (.readLocal 28 (.lit 0)) (.lit 1))) l8 l9 35 :=
        exec_boxWriteW inp l8 _ _
          (by simp only [iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal, l8, l7, l6, wReadL_wWrite, hl5_19, h2i1])
          (by omega) (by omega)
          (by simp only [iValAt_add, iValAt_readLocal, iValAt_lit, l8, l7, l6, wReadL_wWrite, hw28_0]; push_cast; ring)
          (by dsimp [intExprOps]; omega)
      let ms := l9.popDepth 0
      have hds : DetExecAt 0 inp (phase1SelectScopeStmt K M_box) mem ms (250 * (K + 1) + 150) :=
        DetExecAt.localScope
          ((hl1.seq (hl2.seq
            (DetExecAt.ite_true hcond_lt (C_c := 10) (by simp [condExprOps, intExprOps])
              (hl3.seq (hl4.seq (hl5.seq
                (DetExecAt.ite_true hcond_f (C_c := 10) (by simp [condExprOps, intExprOps])
                  (hl6.seq (hl7.seq (hl8.seq hl9)))))))))).mono_cost (by omega))
      have hw_ms_o : ∀ t, t ≠ 24 → t ≠ 26 → ∀ i, wRead ms t i = wRead mem t i :=
        fun t h24 h26 i => by simp [ms, l9, h24, l8, l7, l6, h26, hw_l5, l4, l3, l2, l1, l0]
      have hr_ms : ∀ t i, rRead ms t i = rRead mem t i :=
        fun t i => by simp [ms, l9, l8, l7, l6, hr_l5, l4, l3, l2, l1, l0]
      have hcond_25 : cValAt 0 inp ms (.intEq (.readHeap 26 (.lit 25)) (.lit 1)) = true := by
        simp [ms, l9, l8]
      have hgen_ms : SegGenBound K NumSlots ms :=
        ⟨by rw [hw_ms_o 1 (by decide) (by decide)]; exact hgen.1,
         fun s hs => by rw [hw_ms_o 5 (by decide) (by decide), hw_ms_o 1 (by decide) (by decide)]; exact hgen.2.1 s hs,
         fun s hs u hu => by rw [hw_ms_o 8 (by decide) (by decide), hw_ms_o 1 (by decide) (by decide)]; exact hgen.2.2 s hs u hu⟩
      have hLive_ms : EncLiveCoords d n ms activeH livePts :=
        ⟨hLive.1, fun h hh c => by rw [hr_ms]; exact hLive.2 h hh c⟩
      have hseg_ms : ∀ s', ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K ms s' S₁ fSq₁ :=
        fun s' S₁ fSq₁ h0 =>
          h0.congr_mem_fSq (by rw [hw_ms_o 5 (by decide) (by decide)])
            (fun _ _ => by rw [hw_ms_o 8 (by decide) (by decide)])
            (fun _ _ => by rw [hw_ms_o 9 (by decide) (by decide)])
            (fun _ _ => by rw [hw_ms_o 10 (by decide) (by decide)])
            (fun _ _ => by rw [hr_ms]) (fun _ _ => rfl)
      have hw6_ms : wRead ms 6 (spRS : ℤ) = 0 := by
        rw [hw_ms_o 6 (by decide) (by decide), h6_spRS]
      rcases exec_updJobLevelFourSlotsStmt inp ms (ins := true) (T := S_parent.filter (· < cur))
          hdS hspDS hrS hspRS hdist4 hy_2K hBox26 hMs
          (by rw [hw_ms_o 23 (by decide) (by decide), hw_dS])
          (by rw [hw_ms_o 23 (by decide) (by decide), hw_spDS])
          (by rw [hw_ms_o 23 (by decide) (by decide), hw_rS])
          (by rw [hw_ms_o 23 (by decide) (by decide), hw_spRS])
          (fun c => by rw [hr_ms]; exact hr_bo c)
          (by rw [hr_ms]; exact hr_V)
          (by simp [ms, l9, l8, l7, l6])
          (by simp [ms, l9, l8, l7])
          (by simp [ms, l9, l8, l7, l6, hw_l5, l4, l3, l2, l1, l0, hidx_reg])
          hLive_ms (fun _ => hy_act) (fun _ => hy_not_flt) (fun _ _ _ => rfl)
          hgen_ms (hseg_ms _ _ _ hEd) (hseg_ms _ _ _ hEspD) (hseg_ms _ _ _ hEr)
          (fun _ => hseg_ms _ _ _ hEspR)
        with ⟨mu, hdu, hpu, hgen_u, hEd_u, hEspD_u, hEr_u, hEspR_u, _, _, hOther_u, hwu_o, hwu_26, hru_o⟩
      simp only [↓reduceIte] at hEd_u hEspD_u hEr_u hEspR_u
      rw [← hflt_succ] at hEd_u hEspD_u hEr_u hEspR_u
      refine ⟨mu, y + 1,
        (hds.seq (DetExecAt.ite_true hcond_25 (C_c := 10) (by simp [condExprOps, intExprOps]) hdu)).mono_cost (by omega),
        hpu, by omega,
        by rw [hwu_o 24 (by decide) (by decide) (by decide) (by decide)]; simp [ms, l9],
        Or.inr hrem_succ,
        hgen_u, hEd_u, hEspD_u, hEr_u, hEspR_u hw6_ms,
        (fun s' hs' h1 h2 h3 h4 S₁ fSq₁ h0 =>
          hOther_u s' hs' h1 h2 h3 (fun _ => h4) S₁ fSq₁ (hseg_ms s' S₁ fSq₁ h0)),
        (fun t h8 h9 h10 h24 h26 i => by rw [hwu_o t h8 h9 h10 h26, hw_ms_o t h24 h26]),
        (fun i hi => by
          rw [hwu_o 24 (by decide) (by decide) (by decide) (by decide)]
          simp only [ms, wRead_popDepth, l9]
          rw [wRead_wWrite_of_ne _ _ (Or.inr hi)]
          simp [l8, l7, l6, hw_l5, l4, l3, l2, l1, l0]),
        (fun i h3 h4 h5 h6 h8 h25 => by
          rw [hwu_26 i h3 h6 h8]
          simp [ms, l9, l8, h25, l7, h5, l6, h4, hw_l5, l4, l3, l2, l1, l0]),
        (fun t h8 h26 i => by rw [hru_o t h8 h26, hr_ms])⟩
    · -- No element `≥ cur` in `S_parent`!
      have hall_lt : ∀ x ∈ S_parent, x < cur := by
        intro x hx; by_contra hge; exact hex ⟨x, hx, by omega⟩
      have hw28_1 : wReadL 1 l5 28 1 = 0 := hnot_5 hall_lt
      have hcond_f : cValAt 1 inp l5 (.intEq (.readLocal 28 (.lit 1)) (.lit 1)) = false := by
        simp [hw28_1]
      let l6 := wWrite l5 26 25 0
      let l7 := wWrite l6 24 (((2 * idx + 1 : ℕ) : ℤ)) (((2 ^ K : ℕ) : ℤ))
      have hl6 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 25) (.lit 0)) l5 l6 14 :=
        exec_boxWriteW inp l5 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
      have hl7 : DetExecAt 1 inp
          (boxWriteW M_box 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1))
            (.lit (((2 ^ K : ℕ) : ℤ)))) l6 l7 35 :=
        exec_boxWriteW inp l6 _ _
          (by simp only [iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal, l6, wReadL_wWrite, hl5_19, h2i1])
          (by omega) (by omega) rfl (by dsimp [intExprOps]; omega)
      let ms := l7.popDepth 0
      have hds : DetExecAt 0 inp (phase1SelectScopeStmt K M_box) mem ms (250 * (K + 1) + 150) :=
        DetExecAt.localScope
          ((hl1.seq (hl2.seq
            (DetExecAt.ite_true hcond_lt (C_c := 10) (by simp [condExprOps, intExprOps])
              (hl3.seq (hl4.seq (hl5.seq
                (DetExecAt.ite_false hcond_f (C_c := 10) (by simp [condExprOps, intExprOps])
                  (hl6.seq hl7)))))))).mono_cost (by omega))
      have hcond_25 : cValAt 0 inp ms (.intEq (.readHeap 26 (.lit 25)) (.lit 1)) = false := by
        simp [ms, l7, l6]
      have hflt_2K : S_parent.filter (· < 2 ^ K) = S_parent.filter (· < cur) :=
        filter_lt_eq_of_forall_lt hcur_le hall_lt
      have hw_ms_o : ∀ t, t ≠ 24 → t ≠ 26 → ∀ i, wRead ms t i = wRead mem t i :=
        fun t h24 h26 i => by simp [ms, l7, h24, l6, h26, hw_l5, l4, l3, l2, l1, l0]
      have hr_ms : ∀ t i, rRead ms t i = rRead mem t i :=
        fun t i => by simp [ms, l7, l6, hr_l5, l4, l3, l2, l1, l0]
      have hseg_ms : ∀ s', ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K ms s' S₁ fSq₁ :=
        fun s' S₁ fSq₁ h0 =>
          h0.congr_mem_fSq (by rw [hw_ms_o 5 (by decide) (by decide)])
            (fun _ _ => by rw [hw_ms_o 8 (by decide) (by decide)])
            (fun _ _ => by rw [hw_ms_o 9 (by decide) (by decide)])
            (fun _ _ => by rw [hw_ms_o 10 (by decide) (by decide)])
            (fun _ _ => by rw [hr_ms]) (fun _ _ => rfl)
      refine ⟨ms, 2 ^ K,
        (hds.seq (DetExecAt.ite_false hcond_25 (C_c := 10) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp ms))).mono_cost (by omega),
        popDepth_zero_idem l7, le_rfl,
        by simp [ms, l7],
        Or.inl rfl,
        ⟨by rw [hw_ms_o 1 (by decide) (by decide)]; exact hgen.1,
         fun s hs => by rw [hw_ms_o 5 (by decide) (by decide), hw_ms_o 1 (by decide) (by decide)]; exact hgen.2.1 s hs,
         fun s hs u hu => by rw [hw_ms_o 8 (by decide) (by decide), hw_ms_o 1 (by decide) (by decide)]; exact hgen.2.2 s hs u hu⟩,
        by rw [hflt_2K]; exact hseg_ms _ _ _ hEd,
        by rw [hflt_2K]; exact hseg_ms _ _ _ hEspD,
        by rw [hflt_2K]; exact hseg_ms _ _ _ hEr,
        by rw [hflt_2K]; exact hseg_ms _ _ _ hEspR,
        (fun s' _ _ _ _ _ S₁ fSq₁ h0 => hseg_ms s' S₁ fSq₁ h0),
        (fun t _ _ _ h24 h26 i => hw_ms_o t h24 h26 i),
        (fun i hi => by
          simp only [ms, wRead_popDepth, l7]
          rw [wRead_wWrite_of_ne _ _ (Or.inr hi)]
          simp [l6, hw_l5, l4, l3, l2, l1, l0]),
        (fun i _ _ _ _ _ h25 => by simp [ms, l7, l6, h25, hw_l5, l4, l3, l2, l1, l0]),
        (fun t _ _ i => hr_ms t i)⟩
  · -- `cur = 2 ^ K` already:
    have hcur_eq : cur = 2 ^ K := by omega
    subst hcur_eq
    have hcond_lt : cValAt 1 inp l2 (.intLt (.readLocal 29 (.lit 16)) (.lit (((2 ^ K : ℕ) : ℤ)))) = false := by
      have hl2_16 : wReadL 1 l2 29 16 = (((2 ^ K : ℕ) : ℤ)) := by simp [l2]
      simp [hl2_16]
    let l3 := wWrite l2 26 25 0
    have hl3 : DetExecAt 1 inp (boxWriteW M_box 26 (.lit 25) (.lit 0)) l2 l3 14 :=
      exec_boxWriteW inp l2 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
    let ms := l3.popDepth 0
    have hds : DetExecAt 0 inp (phase1SelectScopeStmt K M_box) mem ms 60 :=
      DetExecAt.localScope
        ((hl1.seq (hl2.seq
          (DetExecAt.ite_false hcond_lt (C_c := 10) (by simp [condExprOps, intExprOps]) hl3))).mono_cost (by omega))
    have hcond_25 : cValAt 0 inp ms (.intEq (.readHeap 26 (.lit 25)) (.lit 1)) = false := by
      simp [ms, l3]
    have hw_ms_o : ∀ t, t ≠ 26 → ∀ i, wRead ms t i = wRead mem t i :=
      fun t h26 i => by simp [ms, l3, h26, l2, l1, l0]
    have hr_ms : ∀ t i, rRead ms t i = rRead mem t i :=
      fun t i => by simp [ms, l3, l2, l1, l0]
    have hseg_ms : ∀ s', ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K ms s' S₁ fSq₁ :=
      fun s' S₁ fSq₁ h0 =>
        h0.congr_mem_fSq (by rw [hw_ms_o 5 (by decide)])
          (fun _ _ => by rw [hw_ms_o 8 (by decide)])
          (fun _ _ => by rw [hw_ms_o 9 (by decide)])
          (fun _ _ => by rw [hw_ms_o 10 (by decide)])
          (fun _ _ => by rw [hr_ms]) (fun _ _ => rfl)
    refine ⟨ms, 2 ^ K,
      (hds.seq (DetExecAt.ite_false hcond_25 (C_c := 10) (by simp [condExprOps, intExprOps])
        (DetExecAt.skip 0 inp ms))).mono_cost (by omega),
      popDepth_zero_idem l3, le_rfl,
      by rw [hw_ms_o 24 (by decide), hw_cur],
      Or.inl rfl,
      ⟨by rw [hw_ms_o 1 (by decide)]; exact hgen.1,
       fun s hs => by rw [hw_ms_o 5 (by decide), hw_ms_o 1 (by decide)]; exact hgen.2.1 s hs,
       fun s hs u hu => by rw [hw_ms_o 8 (by decide), hw_ms_o 1 (by decide)]; exact hgen.2.2 s hs u hu⟩,
      hseg_ms _ _ _ hEd,
      hseg_ms _ _ _ hEspD,
      hseg_ms _ _ _ hEr,
      hseg_ms _ _ _ hEspR,
      (fun s' _ _ _ _ _ S₁ fSq₁ h0 => hseg_ms s' S₁ fSq₁ h0),
      (fun t _ _ _ _ h26 i => hw_ms_o t h26 i),
      (fun i _ => hw_ms_o 24 (by decide) i),
      (fun i _ _ _ _ _ h25 => by simp [ms, l3, h25, l2, l1, l0]),
      (fun t _ _ i => hr_ms t i)⟩

theorem exec_phase1FinishStmt {d K M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx cur : ℕ}
    (hcur_le : cur ≤ 2 ^ K)
    (hBox_w23 : 8 * idx + 8 ≤ M_box)
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hw_ph : wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 1)
    (hw_cur : wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ)) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (phase1FinishStmt K M_box) mem m' 60 ∧
      m'.popDepth 0 = m' ∧
      (cur = 2 ^ K → wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2) ∧
      (cur < 2 ^ K →
        wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 1 ∧
        wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ)) ∧
      (∀ t, t ≠ 24 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ ((2 * idx + 0 : ℕ) : ℤ) → wRead m' 24 i = wRead mem 24 i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) := by
  have h2i0 : (2 : ℤ) * (idx : ℤ) = ((2 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
  have h2i1 : (2 : ℤ) * (idx : ℤ) + 1 = ((2 * idx + 1 : ℕ) : ℤ) := by push_cast; ring
  let m0 := mem.popDepth 0
  let m1 := wWriteL 1 m0 29 19 (idx : ℤ)
  have hs1 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 19) (.readHeap 26 (.lit 7))) m0 m1 6 :=
    DetExecAt.writeWordLocal 1 inp m0 29 _ _ rfl (by simp [m0, hidx_reg]) (by simp [intExprOps])
  have hv_cur : wRead m1 24 (2 * wReadL 1 m1 29 19 + 1) = (cur : ℤ) := by
    simp only [m1, wReadL_wWriteL_self, wRead_wWriteL, m0, wRead_popDepth, h2i1, hw_cur]
  by_cases hdone : cur = 2 ^ K
  · have hcond_t : cValAt 1 inp m1
        (.intLe (.lit (((2 ^ K : ℕ) : ℤ)))
                (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))) = true := by
      simp [hv_cur, hdone]
    let m2 := wWrite m1 24 (((2 * idx + 0 : ℕ) : ℤ)) 2
    have hs2 : DetExecAt 1 inp (boxWriteW M_box 24 (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 2)) m1 m2 20 :=
      exec_boxWriteW inp m1 _ _
        (by simp only [iValAt_mul, iValAt_lit, iValAt_readLocal, m1, wReadL_wWriteL_self, h2i0])
        (by omega) (by omega) rfl (by simp [intExprOps])
    refine ⟨m2.popDepth 0,
      DetExecAt.localScope
        ((hs1.seq (DetExecAt.ite_true hcond_t (C_c := 18) (by simp [condExprOps, intExprOps]) hs2)).mono_cost (by omega)),
      popDepth_zero_idem m2,
      (fun _ => by simp [m2]),
      (fun hlt => by omega),
      (fun t ht i => by simp [m2, ht, m1, m0]),
      (fun i hi => by
        rw [wRead_popDepth]
        simp only [m2]
        rw [wRead_wWrite_of_ne _ _ (Or.inr hi)]
        simp [m1, m0]),
      (fun _ _ => by simp [m2, m1, m0])⟩
  · have hlt : cur < 2 ^ K := by omega
    have hnot_le : ¬ ((2 ^ K : ℕ) ≤ cur) := by omega
    have hcond_f : cValAt 1 inp m1
        (.intLe (.lit (((2 ^ K : ℕ) : ℤ)))
                (.readHeap 24 (.add (.mul (.lit 2) (.readLocal 29 (.lit 19))) (.lit 1)))) = false := by
      simp only [cValAt_intLe, iValAt_lit, iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_readLocal,
        hv_cur, decide_eq_false_iff_not]
      exact_mod_cast hnot_le
    refine ⟨m1.popDepth 0,
      DetExecAt.localScope
        ((hs1.seq (DetExecAt.ite_false hcond_f (C_c := 18) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 1 inp m1))).mono_cost (by omega)),
      popDepth_zero_idem m1,
      (fun heq => False.elim (hdone heq)),
      (fun _ => ⟨by rw [wRead_popDepth]; simp only [m1, wRead_wWriteL, m0, wRead_popDepth]; exact hw_ph,
                 by rw [wRead_popDepth]; simp only [m1, wRead_wWriteL, m0, wRead_popDepth]; exact hw_cur⟩),
      (fun _ _ _ => by simp [m1, m0]),
      (fun _ _ => by simp [m1, m0]),
      (fun _ _ => by simp [m1, m0])⟩

/-! ### 5. Top-Level `exec_stepBuildJobLevelStmt` and Two-Phase Tick Bound -/

theorem exec_stepBuildJobLevelStmt {d n D K NumSlots K_batch M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx pS : ℕ} {S_birth S_parent : Finset ℕ} {fSq_p : ℕ → ℝ}
    {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d} {spareResLive : Bool}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    (hD : 3 ≤ D) (hn_2K : n ≤ 2 ^ K)
    (_hpS : pS < NumSlots)
    (hpS_disj : pS ∉ jobLevelSlotSet mem idx)
    (hS_sub : S_parent ⊆ activeH)
    (hBox_slots : NumSlots ≤ M_box)
    (hBox_w23 : 8 * idx + 8 ≤ M_box)
    (hBox26 : 30 ≤ M_box)
    (hMs : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hpS_reg : wRead mem 26 9 = (pS : ℤ))
    (hLive : EncLiveCoords d n mem activeH livePts)
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem)
    (hSeg_p : EncSegSlot K mem pS S_parent fSq_p)
    (hEnc : EncJobLevel d n D K NumSlots mem activeH livePts idx S_birth snapPts prov S_parent spareResLive) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (stepBuildJobLevelStmt d n D K K_batch M_box) mem m'
        (2400 * (K_batch + 1) * (K + d + 5)) ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      SaveGenBound n NumSlots m' ∧
      EncJobLevel d n D K NumSlots m' activeH livePts idx S_birth snapPts prov S_parent spareResLive ∧
      (∀ cur₀ : ℕ,
        wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 →
        wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur₀ : ℤ) →
          (cur₀ + K_batch < S_birth.card →
            wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 ∧
            wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = (((cur₀ + K_batch : ℕ) : ℤ))) ∧
          (S_birth.card ≤ cur₀ + K_batch →
            wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 1 ∧
            wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = 0)) ∧
      (∀ cur₀ : ℕ,
        wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 1 →
        wRead mem 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur₀ : ℤ) →
          wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2 ∨
          ∃ (cur' : ℕ), cur' ≤ 2 ^ K ∧
            wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 1 ∧
            wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur' : ℤ) ∧
            (S_parent.filter (fun x => cur' ≤ x)).card + K_batch ≤
              (S_parent.filter (fun x => cur₀ ≤ x)).card) ∧
      (wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2 →
        wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2) ∧
      (∀ s' < NumSlots, s' ∉ jobLevelSlotSet mem idx →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (spareResLive = false →
        ∀ S₁ fSq₁,
          EncSegSlot K mem ((wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat) S₁ fSq₁ →
          EncSegSlot K m' ((wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat) S₁ fSq₁) ∧
      (∀ s' < NumSlots, ∀ S₁ sp₁,
        EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
        EncSlotCoords d n m' activeH livePts s' S₁ sp₁) ∧
      (∀ t, t ≠ 1 → t ≠ 5 → t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 23 → t ≠ 24 → t ≠ 26 →
        ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 3 → wRead m' 1 i = wRead mem 1 i) ∧
      (∀ i, i ≠ ((8 * idx + 1 : ℕ) : ℤ) → wRead m' 23 i = wRead mem 23 i) ∧
      (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
        wRead m' 24 i = wRead mem 24 i) ∧
      (∀ i, i ≠ 3 → i ≠ 4 → i ≠ 5 → i ≠ 6 → i ≠ 8 → i ≠ 25 → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t, t ≠ 8 → t ≠ 24 → t ≠ 26 → ∀ i, rRead m' t i = rRead mem t i) ∧
      (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
        rRead m' 24 i = rRead mem 24 i) := by
  have hEnc0 := hEnc
  rcases hEnc with ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
    hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
    hw_bS, hw_dS, hw_spDS, hw_rS, hw_spRS,
    h6_bS, h6_dS, h6_spDS, h6_rS, h6_spRS_iff,
    hb_pos, hw_bCard, hSeg_bS, hSlot_bS, hr_o, hPhases⟩
  let ball := applyBirthCoreFallback (1 / (4 * (D : ℝ) ^ 2)) snapPts S_birth prov
  have hbo : ball.o = prov.o := by
    dsimp [ball]; unfold applyBirthCoreFallback; split_ifs <;> rfl
  have hr_bo : ∀ c : Fin d, rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord ball.o c := by
    rw [hbo]; exact hr_o
  have hdist : bS ≠ dS ∧ bS ≠ spDS ∧ bS ≠ rS ∧ bS ≠ spRS ∧
               dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧
               spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS :=
    ⟨hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR⟩
  have hdist4 : dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧ spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS :=
    ⟨hdspD, hdr, hdspR, hspDr, hspDspR, hrspR⟩
  have hslot_not : ∀ s', s' ∉ jobLevelSlotSet mem idx →
      s' ≠ dS ∧ s' ≠ spDS ∧ s' ≠ rS ∧ s' ≠ spRS := by
    intro s' hnot
    unfold jobLevelSlotSet at hnot
    rw [hw_bS, hw_dS, hw_spDS, hw_rS, hw_spRS] at hnot
    simp only [Int.toNat_natCast, Finset.mem_insert, Finset.mem_singleton, not_or] at hnot
    exact ⟨hnot.2.1, hnot.2.2.1, hnot.2.2.2.1, hnot.2.2.2.2⟩
  have hpS_ne := hslot_not pS hpS_disj
  have h2i0 : (2 : ℤ) * (idx : ℤ) = ((2 * idx + 0 : ℕ) : ℤ) := by push_cast; ring
  rcases hPhases with ⟨cur₀, hcur₀, hph0, hwcur0, hwcore0, hrV0, hrmax0, hlive⟩ |
                      ⟨cur₀, hcur₀, hph1, hwcur1, hrV1, hEd0, hEspD0, hEr0, hlive, hEspR0⟩ |
                      ⟨hph2, hrV2, hEd2, hEspD2, hEr2, hEspR2⟩
  · -- CASE 1: `buildPhase == 0`
    subst hlive
    have h6_spRS : wRead mem 6 (spRS : ℤ) = 0 := h6_spRS_iff.mpr rfl
    have hv_ph : wRead mem 24 (2 * wRead mem 26 7) = 0 := by rw [hidx_reg, h2i0, hph0]
    have hcond0 : cValAt 0 inp mem
        (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 0)) = true := by
      simp [hv_ph]
    let C_p0 : ℕ := 220 * (K + d + 5)
    let Inv0 : ℕ → ArithRAMMemory → Prop := fun k m =>
      let cur_k := min (cur₀ + k) S_birth.card
      wRead m 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur_k : ℤ) ∧
      wRead m 23 (((8 * idx + 1 : ℕ) : ℤ)) =
        ((prov.core snapPts (rankPrefixSet S_birth cur_k)).card : ℤ) ∧
      (∀ hne : (rankPrefixSet S_birth cur_k).Nonempty,
        rRead m 24 (((2 * idx + 1 : ℕ) : ℤ)) =
          (rankPrefixSet S_birth cur_k).sup' hne (fun x => euclideanDistSq (snapPts x) prov.o)) ∧
      (∀ t, t ≠ 23 → t ≠ 24 → ∀ i, wRead m t i = wRead mem t i) ∧
      (∀ i, i ≠ ((8 * idx + 1 : ℕ) : ℤ) → wRead m 23 i = wRead mem 23 i) ∧
      (∀ i, i ≠ ((2 * idx + 1 : ℕ) : ℤ) → wRead m 24 i = wRead mem 24 i) ∧
      (∀ t, t ≠ 24 → ∀ i, rRead m t i = rRead mem t i) ∧
      (∀ i, i ≠ ((2 * idx + 1 : ℕ) : ℤ) → rRead m 24 i = rRead mem 24 i)
    have hInv0_init : Inv0 0 mem := by
      have hmin0 : min (cur₀ + 0) S_birth.card = cur₀ := Nat.min_eq_left hcur₀
      dsimp only [Inv0]
      rw [hmin0]
      exact ⟨hwcur0, hwcore0, hrmax0,
        (fun _ _ _ _ => rfl), (fun _ _ => rfl), (fun _ _ => rfl),
        (fun _ _ _ => rfl), (fun _ _ => rfl)⟩
    have hStep0 : ∀ k < K_batch, ∀ m, Inv0 k m →
        ∃ m', DetExecAt 0 inp (phase0OneIterStmt d n K M_box) m m' C_p0 ∧ Inv0 (k + 1) m' := by
      intro k _ m ⟨hw_cur_m, hw_core_m, hr_max_m, hw_mo, hw_m23, hw_m24, hr_mo, hr_m24⟩
      let cur_k := min (cur₀ + k) S_birth.card
      have hcur_k_le : cur_k ≤ S_birth.card := Nat.min_le_right _ _
      have hmin_succ : min (cur_k + 1) S_birth.card = min (cur₀ + (k + 1)) S_birth.card := by
        dsimp only [cur_k]; omega
      have hLive_m : EncLiveCoords d n m activeH livePts :=
        ⟨hLive.1, fun h hh c => by rw [hr_mo 4 (by decide)]; exact hLive.2 h hh c⟩
      have hSeg_bS_m : EncSegSlot K m bS S_birth (fun _ => 0) :=
        hSeg_bS.congr_mem_fSq (by rw [hw_mo 5 (by decide) (by decide)])
          (fun _ _ => by rw [hw_mo 8 (by decide) (by decide)])
          (fun _ _ => by rw [hw_mo 9 (by decide) (by decide)])
          (fun _ _ => by rw [hw_mo 10 (by decide) (by decide)])
          (fun _ _ => by rw [hr_mo 8 (by decide)]) (fun _ _ => rfl)
      have hSlot_bS_m : EncSlotCoords d n m activeH livePts bS S_birth snapPts :=
        hSlot_bS.congr_mem (by rw [hw_mo 6 (by decide) (by decide)])
          (fun _ => by rw [hw_mo 11 (by decide) (by decide)])
          (fun _ => by rw [hr_mo 11 (by decide)])
      rcases exec_phase0OneIterStmt inp m hb_pos hcur_k_le hBox_w23
          (by rw [hw_mo 26 (by decide) (by decide), hidx_reg])
          (by rw [hw_m23 _ (by omega), hw_bCard])
          hw_core_m
          (by rw [hw_m23 _ (by omega), hw_bS])
          hw_cur_m
          (fun c => by rw [hr_mo 23 (by decide), hr_o c])
          (by rw [hr_m24 _ (by omega), hrV0])
          hr_max_m hLive_m hSeg_bS_m hSlot_bS_m
        with ⟨m', hd', _, hw_cur', hw_core', hr_max', hw'_o, hw'_23, hw'_24, hr'_o, hr'_24⟩
      refine ⟨m', hd', ?_⟩
      dsimp only [Inv0]
      rw [← hmin_succ]
      exact ⟨hw_cur', hw_core', hr_max',
        (fun t h23 h24 i => by rw [hw'_o t h23 h24, hw_mo t h23 h24]),
        (fun i hi => by rw [hw'_23 i hi, hw_m23 i hi]),
        (fun i hi => by rw [hw'_24 i hi, hw_m24 i hi]),
        (fun t h24 i => by rw [hr'_o t h24, hr_mo t h24]),
        (fun i hi => by rw [hr'_24 i hi, hr_m24 i hi])⟩
    rcases DetExecAt.repeatN_nat (.lit (K_batch : ℤ)) _ K_batch 4 C_p0 Inv0 hInv0_init rfl
        (by simp [intExprOps]) hStep0
      with ⟨mN, ⟨hw_curN, hw_coreN, hr_maxN, hwN_o, hwN_23, hwN_24, hrN_o, hrN_24⟩, hrep0⟩
    let curN := min (cur₀ + K_batch) S_birth.card
    have hcurN_le : curN ≤ S_birth.card := Nat.min_le_right _ _
    have hseg_N : SegGenBound K NumSlots mN :=
      ⟨by rw [hwN_o 1 (by decide) (by decide)]; exact hseg.1,
       fun s hs => by rw [hwN_o 5 (by decide) (by decide), hwN_o 1 (by decide) (by decide)]; exact hseg.2.1 s hs,
       fun s hs u hu => by rw [hwN_o 8 (by decide) (by decide), hwN_o 1 (by decide) (by decide)]; exact hseg.2.2 s hs u hu⟩
    have hsave_N : SaveGenBound n NumSlots mN :=
      ⟨by rw [hwN_o 1 (by decide) (by decide)]; exact hsave.1,
       fun s hs => by rw [hwN_o 6 (by decide) (by decide), hwN_o 1 (by decide) (by decide)]; exact hsave.2.1 s hs,
       fun s hs u hu => by rw [hwN_o 11 (by decide) (by decide), hwN_o 1 (by decide) (by decide)]; exact hsave.2.2 s hs u hu⟩
    have hSeg_bS_N : EncSegSlot K mN bS S_birth (fun _ => 0) :=
      hSeg_bS.congr_mem_fSq (by rw [hwN_o 5 (by decide) (by decide)])
        (fun _ _ => by rw [hwN_o 8 (by decide) (by decide)])
        (fun _ _ => by rw [hwN_o 9 (by decide) (by decide)])
        (fun _ _ => by rw [hwN_o 10 (by decide) (by decide)])
        (fun _ _ => by rw [hrN_o 8 (by decide)]) (fun _ _ => rfl)
    have hSlot_bS_N : EncSlotCoords d n mN activeH livePts bS S_birth snapPts :=
      hSlot_bS.congr_mem (by rw [hwN_o 6 (by decide) (by decide)])
        (fun _ => by rw [hwN_o 11 (by decide) (by decide)])
        (fun _ => by rw [hrN_o 11 (by decide)])
    rcases exec_phase0FinishStmt inp mN (S_parent := S_parent) hD
        hbS hdS hspDS hrS hspRS hdist hb_pos hcurN_le hBox_slots hBox_w23 (by omega)
        (by rw [hwN_o 26 (by decide) (by decide), hidx_reg])
        (by rw [hwN_23 _ (by omega), hw_bCard])
        hw_coreN
        (by rw [hwN_23 _ (by omega), hw_bS])
        (by rw [hwN_23 _ (by omega), hw_dS])
        (by rw [hwN_23 _ (by omega), hw_spDS])
        (by rw [hwN_23 _ (by omega), hw_rS])
        (by rw [hwN_23 _ (by omega), hw_spRS])
        (by rw [hwN_o 6 (by decide) (by decide)]; exact h6_bS)
        (by rw [hwN_o 6 (by decide) (by decide)]; exact h6_dS)
        (by rw [hwN_o 6 (by decide) (by decide)]; exact h6_spDS)
        (by rw [hwN_o 6 (by decide) (by decide)]; exact h6_rS)
        (by rw [hwN_o 6 (by decide) (by decide)]; exact h6_spRS)
        (by rw [hwN_24 _ (by omega), hph0])
        hw_curN
        (fun c => by rw [hrN_o 23 (by decide), hr_o c])
        (by rw [hrN_24 _ (by omega), hrV0])
        hr_maxN hseg_N hsave_N hSeg_bS_N hSlot_bS_N
      with ⟨mF, hdF, hpF, hsegF, hsaveF, hEncF, hstay0, hgo1, hOtherF, hSnapF, hwF_o, hwF_1, hwF_24, hrF_o, hrF_24⟩
    have hcleanF : DetExecAt 0 inp (.localScope .skip) mF mF 2 := by
      have hc : DetExecAt 0 inp (.localScope .skip) mF ((mF.popDepth 0).popDepth 0) 2 :=
        (DetExecAt.localScope (DetExecAt.skip 1 inp (mF.popDepth 0))).mono_cost (by omega)
      rwa [popDepth_zero_idem, hpF] at hc
    refine ⟨mF,
      (((DetExecAt.ite_true hcond0 (C_c := 16) (by simp [condExprOps, intExprOps])
        (hrep0.seq hdF)).seq hcleanF).mono_cost (by
          dsimp only [C_p0]
          have hmul : K_batch * (220 * (K + d + 5)) = 220 * K_batch * (K + d + 5) := by ring
          have hexp : 2400 * (K_batch + 1) * (K + d + 5) =
              220 * K_batch * (K + d + 5) + 2180 * K_batch * (K + d + 5) + 2400 * (K + d + 5) := by ring
          rw [hmul, hexp]; omega)),
      hpF, hsegF, hsaveF, hEncF,
      (fun c0 _ hc0 => by
        have hc0_eq : c0 = cur₀ := by exact_mod_cast (hc0.symm.trans hwcur0)
        subst hc0_eq
        refine ⟨fun hlt => ?_, fun hge => ?_⟩
        · have hmin_lt : curN = c0 + K_batch := Nat.min_eq_left (le_of_lt hlt)
          have hstay := hstay0 (by rw [hmin_lt]; exact hlt)
          rw [hmin_lt] at hstay
          exact hstay
        · exact hgo1 (Nat.min_eq_right hge)),
      (fun _ h1 => by rw [hph0] at h1; cases h1),
      (fun h2 => by rw [hph0] at h2; cases h2),
      (fun s' hs' hnot S₁ fSq₁ h0 => by
        rcases hslot_not s' hnot with ⟨h1, h2, h3, h4⟩
        have aN : EncSegSlot K mN s' S₁ fSq₁ :=
          h0.congr_mem_fSq (by rw [hwN_o 5 (by decide) (by decide)])
            (fun _ _ => by rw [hwN_o 8 (by decide) (by decide)])
            (fun _ _ => by rw [hwN_o 9 (by decide) (by decide)])
            (fun _ _ => by rw [hwN_o 10 (by decide) (by decide)])
            (fun _ _ => by rw [hrN_o 8 (by decide)]) (fun _ _ => rfl)
        exact hOtherF s' hs' h1 h2 h3 h4 S₁ fSq₁ aN),
      (fun hf => by cases hf),
      (fun s' hs' S₁ sp₁ h0 =>
        hSnapF s' hs' S₁ sp₁
          (h0.congr_mem (by rw [hwN_o 6 (by decide) (by decide)])
            (fun _ => by rw [hwN_o 11 (by decide) (by decide)])
            (fun _ => by rw [hrN_o 11 (by decide)]))),
      (fun t h1 h5 _ _ _ h23 h24 _ i => by rw [hwF_o t h1 h5 h24, hwN_o t h23 h24]),
      (fun i hi => by rw [hwF_1 i hi, hwN_o 1 (by decide) (by decide)]),
      (fun i hi => by rw [hwF_o 23 (by decide) (by decide) (by decide), hwN_23 i hi]),
      (fun i hi => by rw [hwF_24 i hi, hwN_24 i (by omega)]),
      (fun i _ _ _ _ _ _ => by rw [hwF_o 26 (by decide) (by decide) (by decide), hwN_o 26 (by decide) (by decide)]),
      (fun t _ h24 _ i => by rw [hrF_o t h24, hrN_o t h24]),
      (fun i hi => by rw [hrF_24 i hi, hrN_24 i (by omega)])⟩
  · -- CASE 2: `buildPhase == 1`
    subst hlive
    have h6_spRS : wRead mem 6 (spRS : ℤ) = 0 := h6_spRS_iff.mpr rfl
    have hv_ph : wRead mem 24 (2 * wRead mem 26 7) = 1 := by rw [hidx_reg, h2i0, hph1]
    have hcond0 : cValAt 0 inp mem
        (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 0)) = false := by
      simp [hv_ph]
    have hcond1 : cValAt 0 inp mem
        (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 1)) = true := by
      simp [hv_ph]
    let C_p1 : ℕ := 1350 * (K + 1) + 150 * (d + 1) + 800
    let Inv1 : ℕ → ArithRAMMemory → Prop := fun k m =>
      ∃ (cur_k : ℕ), cur_k ≤ 2 ^ K ∧
        wRead m 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur_k : ℤ) ∧
        (cur_k = 2 ^ K ∨
          (S_parent.filter (fun x => cur_k ≤ x)).card + k =
            (S_parent.filter (fun x => cur₀ ≤ x)).card) ∧
        SegGenBound K NumSlots m ∧
        EncSegSlot K m dS (S_parent.filter (· < cur_k)) (fun x => euclideanDistSq (livePts x) ball.o) ∧
        EncSegSlot K m spDS (S_parent.filter (· < cur_k)) (fun _ => 0) ∧
        EncSegSlot K m rS (ball.residual livePts (S_parent.filter (· < cur_k))) (fun _ => 0) ∧
        EncSegSlot K m spRS (ball.residual livePts (S_parent.filter (· < cur_k))) (fun _ => 0) ∧
        (∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
          ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m s' S₁ fSq₁) ∧
        (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 24 → t ≠ 26 → ∀ i, wRead m t i = wRead mem t i) ∧
        (∀ i, i ≠ ((2 * idx + 1 : ℕ) : ℤ) → wRead m 24 i = wRead mem 24 i) ∧
        (∀ i, i ≠ 3 → i ≠ 4 → i ≠ 5 → i ≠ 6 → i ≠ 8 → i ≠ 25 → wRead m 26 i = wRead mem 26 i) ∧
        (∀ t, t ≠ 8 → t ≠ 26 → ∀ i, rRead m t i = rRead mem t i)
    have hInv1_init : Inv1 0 mem :=
      ⟨cur₀, hcur₀, hwcur1, Or.inr (by simp), hseg, hEd0, hEspD0, hEr0, hEspR0,
       (fun _ _ _ _ _ _ _ _ h0 => h0), (fun _ _ _ _ _ _ _ => rfl),
       (fun _ _ => rfl), (fun _ _ _ _ _ _ _ => rfl), (fun _ _ _ _ => rfl)⟩
    have hStep1 : ∀ k < K_batch, ∀ m, Inv1 k m →
        ∃ m', DetExecAt 0 inp (phase1OneIterStmt d K M_box) m m' C_p1 ∧ Inv1 (k + 1) m' := by
      intro k _ m ⟨cur_k, hcur_k, hw_cur_m, hprog_k, hgen_m, hEd_m, hEspD_m, hEr_m, hEspR_m,
        hOther_m, hw_mo, hw_m24, hw_m26, hr_mo⟩
      have hLive_m : EncLiveCoords d n m activeH livePts :=
        ⟨hLive.1, fun h hh c => by rw [hr_mo 4 (by decide) (by decide)]; exact hLive.2 h hh c⟩
      have hSeg_p_m : EncSegSlot K m pS S_parent fSq_p :=
        hOther_m pS _hpS hpS_ne.1 hpS_ne.2.1 hpS_ne.2.2.1 hpS_ne.2.2.2 _ _ hSeg_p
      rcases exec_phase1OneIterStmt inp m hdS hspDS hrS hspRS hdist4 hpS_ne hcur_k hS_sub
          hBox_w23 hBox26 hMs
          (by rw [hw_m26 7 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hidx_reg])
          (by rw [hw_m26 9 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hpS_reg])
          (by rw [hw_mo 23 (by decide) (by decide) (by decide) (by decide) (by decide), hw_dS])
          (by rw [hw_mo 23 (by decide) (by decide) (by decide) (by decide) (by decide), hw_spDS])
          (by rw [hw_mo 23 (by decide) (by decide) (by decide) (by decide) (by decide), hw_rS])
          (by rw [hw_mo 23 (by decide) (by decide) (by decide) (by decide) (by decide), hw_spRS])
          (by rw [hw_mo 6 (by decide) (by decide) (by decide) (by decide) (by decide), h6_spRS])
          hw_cur_m
          (fun c => by rw [hr_mo 23 (by decide) (by decide), hr_bo c])
          (by rw [hr_mo 24 (by decide) (by decide), hrV1])
          hLive_m hgen_m hSeg_p_m hEd_m hEspD_m hEr_m hEspR_m
        with ⟨m', cur', hd', _, hcur'_le, hw_cur', hstep_prog, hgen', hEd', hEspD', hEr', hEspR',
          hOther', hw'_o, hw'_24, hw'_26, hr'_o⟩
      have hprog_next : cur' = 2 ^ K ∨
          (S_parent.filter (fun x => cur' ≤ x)).card + (k + 1) =
            (S_parent.filter (fun x => cur₀ ≤ x)).card := by
        rcases hstep_prog with rfl | hrem1
        · exact Or.inl rfl
        · rcases hprog_k with h2k | hremk
          · subst h2k
            have hlt_all : ∀ x ∈ S_parent, x < 2 ^ K := fun x hx => hSeg_p.2.1 x hx
            have h0_card : (S_parent.filter (fun x => 2 ^ K ≤ x)).card = 0 := by
              rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
              intro x hx; have := hlt_all x hx; omega
            omega
          · exact Or.inr (by omega)
      refine ⟨m', hd', cur', hcur'_le, hw_cur', hprog_next, hgen', hEd', hEspD', hEr', hEspR',
        (fun s' hs' h1 h2 h3 h4 S₁ fSq₁ h0 =>
          hOther' s' hs' h1 h2 h3 h4 S₁ fSq₁ (hOther_m s' hs' h1 h2 h3 h4 S₁ fSq₁ h0)),
        (fun t h8 h9 h10 h24 h26 i => by rw [hw'_o t h8 h9 h10 h24 h26, hw_mo t h8 h9 h10 h24 h26]),
        (fun i hi => by rw [hw'_24 i hi, hw_m24 i hi]),
        (fun i h3 h4 h5 h6 h8 h25 => by rw [hw'_26 i h3 h4 h5 h6 h8 h25, hw_m26 i h3 h4 h5 h6 h8 h25]),
        (fun t h8 h26 i => by rw [hr'_o t h8 h26, hr_mo t h8 h26])⟩
    rcases DetExecAt.repeatN_nat (.lit (K_batch : ℤ)) _ K_batch 4 C_p1 Inv1 hInv1_init rfl
        (by simp [intExprOps]) hStep1
      with ⟨mN, ⟨curN, hcurN, hw_curN, hprogN, hgenN, hEdN, hEspDN, hErN, hEspRN,
        hOtherN, hwN_o, hwN_24, hwN_26, hrN_o⟩, hrep1⟩
    rcases exec_phase1FinishStmt inp mN hcurN hBox_w23
        (by rw [hwN_26 7 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hidx_reg])
        (by rw [hwN_24 _ (by omega), hph1])
        hw_curN
      with ⟨mF, hdF, hpF, hgo2, hstay1, hwF_o, hwF_24, hrF_all⟩
    have hcleanF : DetExecAt 0 inp (.localScope .skip) mF mF 2 := by
      have hc : DetExecAt 0 inp (.localScope .skip) mF ((mF.popDepth 0).popDepth 0) 2 :=
        (DetExecAt.localScope (DetExecAt.skip 1 inp (mF.popDepth 0))).mono_cost (by omega)
      rwa [popDepth_zero_idem, hpF] at hc
    have hsaveF : SaveGenBound n NumSlots mF :=
      ⟨by rw [hwF_o 1 (by decide), hwN_o 1 (by decide) (by decide) (by decide) (by decide) (by decide)]; exact hsave.1,
       fun s hs => by
         rw [hwF_o 6 (by decide), hwN_o 6 (by decide) (by decide) (by decide) (by decide) (by decide),
             hwF_o 1 (by decide), hwN_o 1 (by decide) (by decide) (by decide) (by decide) (by decide)]
         exact hsave.2.1 s hs,
       fun s hs u hu => by
         rw [hwF_o 11 (by decide), hwN_o 11 (by decide) (by decide) (by decide) (by decide) (by decide),
             hwF_o 1 (by decide), hwN_o 1 (by decide) (by decide) (by decide) (by decide) (by decide)]
         exact hsave.2.2 s hs u hu⟩
    have hseg_N_to_F : ∀ s', ∀ S₁ fSq₁, EncSegSlot K mN s' S₁ fSq₁ → EncSegSlot K mF s' S₁ fSq₁ :=
      fun s' S₁ fSq₁ h0 =>
        h0.congr_mem_fSq (by rw [hwF_o 5 (by decide)])
          (fun _ _ => by rw [hwF_o 8 (by decide)])
          (fun _ _ => by rw [hwF_o 9 (by decide)])
          (fun _ _ => by rw [hwF_o 10 (by decide)])
          (fun _ _ => by rw [hrF_all]) (fun _ _ => rfl)
    have hsnapF : ∀ s' < NumSlots, ∀ S₁ sp₁,
        EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
        EncSlotCoords d n mF activeH livePts s' S₁ sp₁ :=
      fun s' _ S₁ sp₁ h0 =>
        h0.congr_mem
          (by rw [hwF_o 6 (by decide), hwN_o 6 (by decide) (by decide) (by decide) (by decide) (by decide)])
          (fun _ => by rw [hwF_o 11 (by decide), hwN_o 11 (by decide) (by decide) (by decide) (by decide) (by decide)])
          (fun _ => by rw [hrF_all, hrN_o 11 (by decide) (by decide)])
    have hPhasesF :
        (∃ cur : ℕ, cur ≤ S_birth.card ∧
          wRead mF 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 ∧
          wRead mF 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ) ∧
          wRead mF 23 (((8 * idx + 1 : ℕ) : ℤ)) =
            ((prov.core snapPts (rankPrefixSet S_birth cur)).card : ℤ) ∧
          rRead mF 24 (((2 * idx + 0 : ℕ) : ℤ)) = prov.V ∧
          (∀ hne : (rankPrefixSet S_birth cur).Nonempty,
            rRead mF 24 (((2 * idx + 1 : ℕ) : ℤ)) =
              (rankPrefixSet S_birth cur).sup' hne (fun x => euclideanDistSq (snapPts x) prov.o)) ∧
          true = true) ∨
        (∃ cur : ℕ, cur ≤ 2 ^ K ∧
          wRead mF 24 (((2 * idx + 0 : ℕ) : ℤ)) = 1 ∧
          wRead mF 24 (((2 * idx + 1 : ℕ) : ℤ)) = (cur : ℤ) ∧
          rRead mF 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V ∧
          EncSegSlot K mF dS (S_parent.filter (· < cur)) (fun x => euclideanDistSq (livePts x) ball.o) ∧
          EncSegSlot K mF spDS (S_parent.filter (· < cur)) (fun _ => 0) ∧
          EncSegSlot K mF rS (ball.residual livePts (S_parent.filter (· < cur))) (fun _ => 0) ∧
          true = true ∧
          EncSegSlot K mF spRS (ball.residual livePts (S_parent.filter (· < cur))) (fun _ => 0)) ∨
        (wRead mF 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2 ∧
          rRead mF 24 (((2 * idx + 0 : ℕ) : ℤ)) = ball.V ∧
          EncSegSlot K mF dS S_parent (fun x => euclideanDistSq (livePts x) ball.o) ∧
          EncSegSlot K mF spDS S_parent (fun _ => 0) ∧
          EncSegSlot K mF rS (ball.residual livePts S_parent) (fun _ => 0) ∧
          (true = true → EncSegSlot K mF spRS (ball.residual livePts S_parent) (fun _ => 0))) := by
      by_cases hdone1 : curN = 2 ^ K
      · right; right
        have hflt_full : S_parent.filter (· < curN) = S_parent := by
          rw [hdone1]
          exact filter_lt_eq_self_of_bound (fun x hx => lt_of_lt_of_le (hLive.1 x (hS_sub hx)) hn_2K)
        rw [hflt_full] at hEdN hEspDN hErN hEspRN
        exact ⟨hgo2 hdone1,
          by rw [hrF_all, hrN_o 24 (by decide) (by decide), hrV1],
          hseg_N_to_F _ _ _ hEdN,
          hseg_N_to_F _ _ _ hEspDN,
          hseg_N_to_F _ _ _ hErN,
          fun _ => hseg_N_to_F _ _ _ hEspRN⟩
      · right; left
        have hlt1 : curN < 2 ^ K := by omega
        rcases hstay1 hlt1 with ⟨hph_stay, hcur_stay⟩
        exact ⟨curN, hcurN, hph_stay, hcur_stay,
          by rw [hrF_all, hrN_o 24 (by decide) (by decide), hrV1],
          hseg_N_to_F _ _ _ hEdN,
          hseg_N_to_F _ _ _ hEspDN,
          hseg_N_to_F _ _ _ hErN,
          rfl,
          hseg_N_to_F _ _ _ hEspRN⟩
    have hwF_23_all : ∀ i, wRead mF 23 i = wRead mem 23 i :=
      fun i => by rw [hwF_o 23 (by decide), hwN_o 23 (by decide) (by decide) (by decide) (by decide) (by decide)]
    have hwF_6_all : ∀ i, wRead mF 6 i = wRead mem 6 i :=
      fun i => by rw [hwF_o 6 (by decide), hwN_o 6 (by decide) (by decide) (by decide) (by decide) (by decide)]
    refine ⟨mF,
      (((DetExecAt.ite_false hcond0 (C_c := 16) (by simp [condExprOps, intExprOps])
        (DetExecAt.ite_true hcond1 (C_c := 16) (by simp [condExprOps, intExprOps])
          (hrep1.seq hdF))).seq hcleanF).mono_cost (by
            dsimp only [C_p1]
            have hexp1 : K_batch * (1350 * (K + 1) + 150 * (d + 1) + 800) ≤
                K_batch * (2300 * (K + d + 5)) :=
              Nat.mul_le_mul_left _ (by omega)
            have hexp2 : K_batch * (2300 * (K + d + 5)) = 2300 * K_batch * (K + d + 5) := by ring
            have hexp3 : 2400 * (K_batch + 1) * (K + d + 5) =
                2300 * K_batch * (K + d + 5) + 100 * K_batch * (K + d + 5) + 2400 * (K + d + 5) := by ring
            rw [hexp2] at hexp1; rw [hexp3]; omega)),
      hpF,
      ⟨by rw [hwF_o 1 (by decide)]; exact hgenN.1,
       fun s hs => by rw [hwF_o 5 (by decide), hwF_o 1 (by decide)]; exact hgenN.2.1 s hs,
       fun s hs u hu => by rw [hwF_o 8 (by decide), hwF_o 1 (by decide)]; exact hgenN.2.2 s hs u hu⟩,
      hsaveF,
      ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
       hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
       by rw [hwF_23_all, hw_bS], by rw [hwF_23_all, hw_dS], by rw [hwF_23_all, hw_spDS],
       by rw [hwF_23_all, hw_rS], by rw [hwF_23_all, hw_spRS],
       by rw [hwF_6_all]; exact h6_bS, by rw [hwF_6_all]; exact h6_dS,
       by rw [hwF_6_all]; exact h6_spDS, by rw [hwF_6_all]; exact h6_rS,
       by rw [hwF_6_all, h6_spRS]; simp,
       hb_pos, by rw [hwF_23_all, hw_bCard],
       hseg_N_to_F bS _ _ (hOtherN bS hbS hbd hbspD hbr hbspR _ _ hSeg_bS),
       hsnapF bS hbS _ _ hSlot_bS,
       fun c => by rw [hrF_all, hrN_o 23 (by decide) (by decide), hr_o c],
       hPhasesF⟩,
      (fun _ h0 => by rw [hph1] at h0; cases h0),
      (fun c0 _ hc0 => by
        have hc0_eq : c0 = cur₀ := by exact_mod_cast (hc0.symm.trans hwcur1)
        subst hc0_eq
        by_cases hdone1 : curN = 2 ^ K
        · exact Or.inl (hgo2 hdone1)
        · have hlt1 : curN < 2 ^ K := by omega
          rcases hprogN with h2k | hremN
          · exact False.elim (hdone1 h2k)
          · rcases hstay1 hlt1 with ⟨hph_s, hcur_s⟩
            exact Or.inr ⟨curN, hcurN, hph_s, hcur_s, le_of_eq hremN⟩),
      (fun h2 => by rw [hph1] at h2; cases h2),
      (fun s' hs' hnot S₁ fSq₁ h0 => by
        rcases hslot_not s' hnot with ⟨h1, h2, h3, h4⟩
        exact hseg_N_to_F s' S₁ fSq₁ (hOtherN s' hs' h1 h2 h3 h4 S₁ fSq₁ h0)),
      (fun hf => by cases hf),
      hsnapF,
      (fun t _ _ h8 h9 h10 _ h24 h26 i => by rw [hwF_o t h24, hwN_o t h8 h9 h10 h24 h26]),
      (fun i _ => by rw [hwF_o 1 (by decide), hwN_o 1 (by decide) (by decide) (by decide) (by decide) (by decide)]),
      (fun i _ => hwF_23_all i),
      (fun i hi => by rw [hwF_24 i (by omega), hwN_24 i (by omega)]),
      (fun i h3 h4 h5 h6 h8 h25 => by rw [hwF_o 26 (by decide), hwN_26 i h3 h4 h5 h6 h8 h25]),
      (fun t h8 _ h26 i => by rw [hrF_all, hrN_o t h8 h26]),
      (fun i _ => by rw [hrF_all, hrN_o 24 (by decide) (by decide)])⟩
  · -- CASE 3: `buildPhase == 2` (already ready — no-op!)
    have hv_ph : wRead mem 24 (2 * wRead mem 26 7) = 2 := by rw [hidx_reg, h2i0, hph2]
    have hcond0 : cValAt 0 inp mem
        (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 0)) = false := by
      simp [hv_ph]
    have hcond1 : cValAt 0 inp mem
        (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 1)) = false := by
      simp [hv_ph]
    have hclean_mem : DetExecAt 0 inp (.localScope .skip) mem ((mem.popDepth 0).popDepth 0) 2 :=
      (DetExecAt.localScope (DetExecAt.skip 1 inp (mem.popDepth 0))).mono_cost (by omega)
    rw [popDepth_zero_idem] at hclean_mem
    have hEnc_p0 : EncJobLevel d n D K NumSlots (mem.popDepth 0) activeH livePts idx
        S_birth snapPts prov S_parent spareResLive :=
      hEnc0.frame (fun _ _ => rfl)
        (fun _ _ _ _ _ _ _ h0 => h0.congr_mem_fSq (by simp) (fun _ _ => by simp)
          (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl))
        (fun _ _ => by simp)
        (fun _ _ _ h0 => h0.congr_mem (by simp) (fun _ => by simp) (fun _ => by simp))
        (fun _ _ => by simp) (fun _ _ => by simp) (fun _ => by simp) (fun _ _ => by simp)
    refine ⟨mem.popDepth 0,
      (((DetExecAt.ite_false hcond0 (C_c := 16) (by simp [condExprOps, intExprOps])
        (DetExecAt.ite_false hcond1 (C_c := 16) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp mem))).seq hclean_mem).mono_cost (by
            have : 60 ≤ 2400 * 1 * 5 := by omega
            exact le_trans (by omega)
              (Nat.mul_le_mul (Nat.mul_le_mul_left 2400 (by omega : 1 ≤ K_batch + 1)) (by omega : 5 ≤ K + d + 5)))),
      popDepth_zero_idem mem,
      ⟨by simp; exact hseg.1,
       fun s hs => by simp; exact hseg.2.1 s hs,
       fun s hs u hu => by simp; exact hseg.2.2 s hs u hu⟩,
      ⟨by simp; exact hsave.1,
       fun s hs => by simp; exact hsave.2.1 s hs,
       fun s hs u hu => by simp; exact hsave.2.2 s hs u hu⟩,
      hEnc_p0,
      (fun _ h0 => by rw [hph2] at h0; cases h0),
      (fun _ h1 => by rw [hph2] at h1; cases h1),
      (fun _ => by rw [wRead_popDepth, hph2]),
      (fun _ _ _ _ _ h0 => h0.congr_mem_fSq (by simp) (fun _ _ => by simp)
        (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl)),
      (fun _ _ _ h0 => h0.congr_mem_fSq (by simp) (fun _ _ => by simp)
        (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => by simp) (fun _ _ => rfl)),
      (fun _ _ _ _ h0 => h0.congr_mem (by simp) (fun _ => by simp) (fun _ => by simp)),
      (fun _ _ _ _ _ _ _ _ _ _ => by simp),
      (fun _ _ => by simp),
      (fun _ _ => by simp),
      (fun _ _ => by simp),
      (fun _ _ _ _ _ _ _ => by simp),
      (fun _ _ _ _ _ => by simp),
      (fun _ _ => by simp)⟩

/-- Pure two-phase scan completion lemma matching `h_build` in `S_lem_C_2`:
given sequences `(ph τ, cur τ, S_par τ)` indexed by elapsed clock ticks `τ ≥ 0` since level opening,
where `ph 0 = 0, cur 0 = 0, (S_par 0).card = m > 2 * L + 1`, each tick changes `S_par` by at most 1
insertion and runs `K_batch = B_scan + 1` scan steps, `ph τ = 2` holds for all
`τ ≥ maxLevelBuildTicks α m`! -/
theorem two_phase_job_build_ready {D L m B_scan : ℕ}
    (hD : 3 ≤ D)
    (hL : 68719476736 * D ^ 4 ≤ L)
    (hm : 2 * L + 1 < m)
    (hB : 16777216 * D ^ 4 ≤ B_scan)
    (ph cur : ℕ → ℕ)
    (S_par : ℕ → Finset ℕ)
    (hph0 : ph 0 = 0)
    (hcur0 : cur 0 = 0)
    (hcard0 : (S_par 0).card = m)
    (hpar_step : ∀ τ : ℕ,
      (S_par (τ + 1)).card ≤ (S_par τ).card + 1 ∧
      ∀ c : ℕ, ((S_par (τ + 1)).filter (fun x => c ≤ x)).card ≤
               ((S_par τ).filter (fun x => c ≤ x)).card + 1)
    (hph_step : ∀ τ : ℕ,
      (ph τ = 0 →
        (cur τ + (B_scan + 1) < m → ph (τ + 1) = 0 ∧ cur (τ + 1) = cur τ + (B_scan + 1)) ∧
        (m ≤ cur τ + (B_scan + 1) → ph (τ + 1) = 1 ∧ cur (τ + 1) = 0)) ∧
      (ph τ = 1 →
        ph (τ + 1) = 2 ∨
        (ph (τ + 1) = 1 ∧
          ((S_par (τ + 1)).filter (fun x => cur (τ + 1) ≤ x)).card + B_scan ≤
            ((S_par τ).filter (fun x => cur τ ≤ x)).card)) ∧
      (ph τ = 2 → ph (τ + 1) = 2)) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    let b : ℕ := maxLevelBuildTicks α m
    (b : ℝ) ≤ α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ)) ∧
    ∀ τ : ℕ, b ≤ τ → ph τ = 2 := by
  classical
  intro α b
  have hb_real : (b : ℝ) ≤ α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ)) := by
    unfold b maxLevelBuildTicks
    exact Nat.floor_le (by dsimp [α, scheduleCStar]; positivity)
  refine ⟨hb_real, ?_⟩
  have hB_pos : 0 < B_scan := by
    have : 1 ≤ D ^ 4 := Nat.one_le_pow 4 D (by omega)
    omega
  -- 1. Phase 0 must finish by `T1 := m / B_scan + 1`:
  let T1 : ℕ := m / B_scan + 1
  have hex_ph1 : ∃ τ : ℕ, τ ≤ T1 ∧ 1 ≤ ph τ := by
    by_contra hnone
    push_neg at hnone
    have hall0 : ∀ τ ≤ T1, ph τ = 0 := fun τ hτ => Nat.lt_one_iff.mp (hnone τ hτ)
    have hcur_eq : ∀ τ ≤ m / B_scan, cur τ = τ * (B_scan + 1) := by
      intro τ hτ
      induction τ with
      | zero => simp [hcur0]
      | succ τ ih =>
          have h0_prev : ph τ = 0 := hall0 τ (by dsimp [T1]; omega)
          have h0_next : ph (τ + 1) = 0 := hall0 (τ + 1) (by dsimp [T1]; omega)
          have hprev_cur := ih (by omega)
          by_cases hlt : cur τ + (B_scan + 1) < m
          · have hst := ((hph_step τ).1 h0_prev).1 hlt
            rw [hst.2, hprev_cur]; ring
          · have hst := ((hph_step τ).1 h0_prev).2 (by omega)
            rw [h0_next] at hst; exact False.elim (by omega)
    have hq_cur := hcur_eq (m / B_scan) le_rfl
    have hm_le : m ≤ cur (m / B_scan) + (B_scan + 1) := by
      rw [hq_cur]
      have hdiv := Nat.div_add_mod m B_scan
      have hmod := Nat.mod_lt m hB_pos
      have h1 : B_scan * (m / B_scan) + B_scan ≤ (m / B_scan) * (B_scan + 1) + (B_scan + 1) := by
        have heq : (m / B_scan) * (B_scan + 1) + (B_scan + 1) =
            B_scan * (m / B_scan) + B_scan + (m / B_scan + 1) := by ring
        rw [heq]
        exact Nat.le_add_right _ _
      exact le_trans (by omega : m ≤ B_scan * (m / B_scan) + B_scan) h1
    have hst := ((hph_step (m / B_scan)).1 (hall0 _ (by dsimp [T1]; omega))).2 hm_le
    have hT1_0 := hall0 T1 le_rfl
    dsimp [T1] at hT1_0
    omega
  -- Pick minimal `τ₁` with `1 ≤ ph τ₁`:
  have hex_unb : ∃ τ : ℕ, 1 ≤ ph τ := by
    rcases hex_ph1 with ⟨τ, _, h⟩; exact ⟨τ, h⟩
  let τ₁ := Nat.find hex_unb
  have hτ₁_ge1 : 1 ≤ ph τ₁ := Nat.find_spec hex_unb
  have hτ₁_le : τ₁ ≤ m / B_scan + 1 := by
    rcases hex_ph1 with ⟨τ, hle, h1⟩
    exact le_trans (Nat.find_min' hex_unb h1) hle
  have hτ₁_pos : 0 < τ₁ := by
    by_contra hz
    have h0 : τ₁ = 0 := by omega
    rw [h0, hph0] at hτ₁_ge1
    omega
  have hprev0 : ph (τ₁ - 1) = 0 := by
    have hlt : ¬ 1 ≤ ph (τ₁ - 1) := Nat.find_min hex_unb (Nat.sub_lt hτ₁_pos Nat.one_pos)
    omega
  have hτ₁_state : ph τ₁ = 1 ∧ cur τ₁ = 0 := by
    have hsucc : τ₁ - 1 + 1 = τ₁ := Nat.sub_add_cancel hτ₁_pos
    by_cases hlt : cur (τ₁ - 1) + (B_scan + 1) < m
    · have hst := ((hph_step (τ₁ - 1)).1 hprev0).1 hlt
      rw [hsucc] at hst; omega
    · have hst := ((hph_step (τ₁ - 1)).1 hprev0).2 (by omega)
      rwa [hsucc] at hst
  -- 2. Bound `m_mid := (S_par τ₁).card ≤ m + τ₁`:
  have hcard_bound : ∀ τ : ℕ, (S_par τ).card ≤ m + τ := by
    intro τ
    induction τ with
    | zero => simp [hcard0]
    | succ τ ih =>
        have h := (hpar_step τ).1
        omega
  let m_mid := (S_par τ₁).card
  have hmid_le : m_mid ≤ m + τ₁ := hcard_bound τ₁
  -- 3. Phase 1 must finish in `k ≤ m_mid / B_scan + 1` steps after `τ₁`:
  let T2 : ℕ := m_mid / B_scan + 1
  have hex_ph2 : ∃ k : ℕ, k ≤ T2 ∧ ph (τ₁ + k) = 2 := by
    by_contra hnone2
    push_neg at hnone2
    -- Note that from `ph τ₁ = 1`, `ph (τ₁ + k)` is always `1` or `2`; since `≠ 2` for `k ≤ T2`, it's `1`!
    have hall1 : ∀ k ≤ T2, ph (τ₁ + k) = 1 := by
      intro k hk
      induction k with
      | zero => simpa using hτ₁_state.1
      | succ k ih =>
          have hk1 := ih (by omega)
          have hne2 := hnone2 (k + 1) hk
          rcases (hph_step (τ₁ + k)).2.1 hk1 with h2 | ⟨h1, _⟩
          · rw [← Nat.add_assoc] at hne2; exact False.elim (hne2 h2)
          · rwa [← Nat.add_assoc]
    have hrem_drop : ∀ k ≤ m_mid / B_scan,
        ((S_par (τ₁ + k)).filter (fun x => cur (τ₁ + k) ≤ x)).card + k * B_scan ≤ m_mid := by
      intro k hk
      induction k with
      | zero =>
          simp only [Nat.add_zero, Nat.zero_mul, hτ₁_state.2]
          exact Finset.card_filter_le _ _
      | succ k ih =>
          have hk_prev := ih (by omega)
          have hph_k := hall1 k (by dsimp [T2]; omega)
          have hne2 := hnone2 (k + 1) (by dsimp [T2]; omega)
          rcases (hph_step (τ₁ + k)).2.1 hph_k with h2 | ⟨_, hrem_step⟩
          · rw [← Nat.add_assoc] at hne2; exact False.elim (hne2 h2)
          · rw [← Nat.add_assoc]
            have hmul : (k + 1) * B_scan = k * B_scan + B_scan := by ring
            rw [hmul]; omega
    have hq_rem := hrem_drop (m_mid / B_scan) le_rfl
    have hph_q := hall1 (m_mid / B_scan) (by dsimp [T2]; omega)
    have hne2_T2 := hnone2 T2 le_rfl
    rcases (hph_step (τ₁ + m_mid / B_scan)).2.1 hph_q with h2 | ⟨_, hrem_last⟩
    · dsimp [T2] at hne2_T2; rw [← Nat.add_assoc] at hne2_T2; exact False.elim (hne2_T2 h2)
    · have hdiv := Nat.div_add_mod m_mid B_scan
      have hmod := Nat.mod_lt m_mid hB_pos
      have hgt : m_mid < (m_mid / B_scan) * B_scan + B_scan := by
        rw [Nat.mul_comm (m_mid / B_scan) B_scan]
        omega
      omega
  rcases hex_ph2 with ⟨k₂, hk₂_le, hph_done⟩
  have hsum_lt : τ₁ + k₂ < b :=
    two_phase_scan_ticks_bound hD hL hm hB hτ₁_le hmid_le hk₂_le
  -- 4. Monotonicity of `ph = 2`:
  have hmono2 : ∀ d_step : ℕ, ph (τ₁ + k₂ + d_step) = 2 := by
    intro d_step
    induction d_step with
    | zero => simpa using hph_done
    | succ d_step ih =>
        rw [← Nat.add_assoc]
        exact (hph_step (τ₁ + k₂ + d_step)).2.2 ih
  intro τ hτ
  have hge : τ₁ + k₂ ≤ τ := by omega
  have heq : τ = τ₁ + k₂ + (τ - (τ₁ + k₂)) := by omega
  rw [heq]
  exact hmono2 _

end UL.Proof_lem_7_2_RacerP46
