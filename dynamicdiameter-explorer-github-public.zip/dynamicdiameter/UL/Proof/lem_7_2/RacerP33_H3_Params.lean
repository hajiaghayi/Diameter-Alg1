import Mathlib
import UL.Def.def_C_2_schedule
import UL.Def.def_alg_4
import UL.Stmt.lem_5_1
import UL.Stmt.clm_7_2_chain_schedule
import UL.Stmt.clm_7_3_failure_budget

set_option autoImplicit false

namespace UL.Proof.lem_7_2.RaceV30

lemma isPolyInAlphaInvDimLogs_zero :
    IsPolyInAlphaInvDimLogs (fun _ _ _ => 0) :=
  ⟨0, 0, le_rfl, fun _ _ _ _ _ => by simp⟩

lemma log_two_le_one : Real.log 2 ≤ 1 := by
  have h := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)
  linarith

/-- Core scale inequalities for `D = d + 3` and `H = ⌈log₂(2 D n t / δ)⌉`. -/
lemma scale_basic_bounds {d n t : ℕ} (hn : 2 ≤ n) (ht : 1 ≤ t) {δ : ℝ}
    (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    3 ≤ D ∧
    5 ≤ H ∧
    (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ ≤ (2 : ℝ) ^ H ∧
    n < 2 ^ H ∧
    t < 2 ^ H ∧
    D < 2 ^ H ∧
    2 / δ < (2 : ℝ) ^ H := by
  intro D H
  have hD3 : 3 ≤ D := by omega
  have hDr : (3 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD3
  have hnr : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have htr : (1 : ℝ) ≤ (t : ℝ) := by exact_mod_cast ht
  have hDn : (6 : ℝ) ≤ (D : ℝ) * (n : ℝ) := by nlinarith
  have hDnt : (6 : ℝ) ≤ (D : ℝ) * (n : ℝ) * (t : ℝ) := by nlinarith
  have hnum : (12 : ℝ) ≤ 2 * (D : ℝ) * (n : ℝ) * (t : ℝ) := by linarith
  have hquot_gt : (24 : ℝ) < (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ := by
    rw [lt_div_iff₀ hδ0]
    nlinarith
  have hquot_pos : 0 < (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ := by linarith
  have hlog_gt : 4 < Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ) := by
    rw [Real.lt_logb_iff_rpow_lt (by norm_num : (1 : ℝ) < 2) hquot_pos]
    norm_num
    linarith
  have hH5 : 5 ≤ H := by
    have h4 : 4 < H := Nat.lt_ceil.mpr (by exact_mod_cast hlog_gt)
    omega
  have hpow : (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ ≤ (2 : ℝ) ^ H := by
    have hle : Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ) ≤ (H : ℝ) :=
      Nat.le_ceil _
    have hrw : (2 : ℝ) ^ (H : ℝ) = (2 : ℝ) ^ H := Real.rpow_natCast 2 H
    rw [← hrw]
    exact (Real.logb_le_iff_le_rpow (by norm_num : (1 : ℝ) < 2) hquot_pos).mp hle
  have h_inv_δ : (2 : ℝ) < 1 / δ := by
    rw [lt_div_iff₀ hδ0]
    linarith
  have h_prod_lt : 4 * (D : ℝ) * (n : ℝ) * (t : ℝ) <
      (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ := by
    have hp : 0 < 2 * (D : ℝ) * (n : ℝ) * (t : ℝ) := by linarith
    calc 4 * (D : ℝ) * (n : ℝ) * (t : ℝ)
        = (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) * 2 := by ring
      _ < (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) * (1 / δ) := by nlinarith
      _ = (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ := by ring
  have hn_lt_r : (n : ℝ) < (2 : ℝ) ^ H := by
    have hDt : (3 : ℝ) ≤ (D : ℝ) * (t : ℝ) := by nlinarith
    have hle : (n : ℝ) ≤ 4 * ((D : ℝ) * (t : ℝ)) * (n : ℝ) := by nlinarith
    have heq : 4 * ((D : ℝ) * (t : ℝ)) * (n : ℝ) = 4 * (D : ℝ) * (n : ℝ) * (t : ℝ) := by ring
    linarith
  have ht_lt_r : (t : ℝ) < (2 : ℝ) ^ H := by
    have hle : (t : ℝ) ≤ 4 * ((D : ℝ) * (n : ℝ)) * (t : ℝ) := by nlinarith
    have heq : 4 * ((D : ℝ) * (n : ℝ)) * (t : ℝ) = 4 * (D : ℝ) * (n : ℝ) * (t : ℝ) := by ring
    linarith
  have hD_lt_r : (D : ℝ) < (2 : ℝ) ^ H := by
    have hnt : (2 : ℝ) ≤ (n : ℝ) * (t : ℝ) := by nlinarith
    have hle : (D : ℝ) ≤ 4 * (D : ℝ) * ((n : ℝ) * (t : ℝ)) := by nlinarith
    have heq : 4 * (D : ℝ) * ((n : ℝ) * (t : ℝ)) = 4 * (D : ℝ) * (n : ℝ) * (t : ℝ) := by ring
    linarith
  have h2d_lt : 2 / δ < (2 : ℝ) ^ H := by
    have h1 : 2 < 2 * (D : ℝ) * (n : ℝ) * (t : ℝ) := by linarith
    have h2 : 2 / δ < (2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ :=
      div_lt_div_of_pos_right h1 hδ0
    linarith
  refine ⟨hD3, hH5, hpow, ?_, ?_, ?_, h2d_lt⟩
  · exact_mod_cast hn_lt_r
  · exact_mod_cast ht_lt_r
  · exact_mod_cast hD_lt_r

lemma log_two_mul_n_le_two_H {n H : ℕ} (hH : 5 ≤ H) (hn : 2 ≤ n) (hn2 : n < 2 ^ H) :
    Real.log (2 * (n : ℝ)) ≤ 2 * (H : ℝ) := by
  have hHr : (5 : ℝ) ≤ (H : ℝ) := by exact_mod_cast hH
  have hn_pos : (0 : ℝ) < 2 * (n : ℝ) := by
    have : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
    linarith
  have hle : 2 * (n : ℝ) ≤ (2 : ℝ) ^ (H + 1) := by
    have hnr : (n : ℝ) ≤ (2 : ℝ) ^ H := by exact_mod_cast (le_of_lt hn2)
    calc 2 * (n : ℝ) ≤ 2 * (2 : ℝ) ^ H := by linarith
      _ = (2 : ℝ) ^ (H + 1) := by ring
  calc Real.log (2 * (n : ℝ))
      ≤ Real.log ((2 : ℝ) ^ (H + 1)) := Real.log_le_log hn_pos hle
    _ = ((H + 1 : ℕ) : ℝ) * Real.log 2 := Real.log_pow 2 (H + 1)
    _ ≤ ((H + 1 : ℕ) : ℝ) * 1 := by gcongr; exact log_two_le_one
    _ ≤ 2 * (H : ℝ) := by push_cast; linarith

lemma log_d_add_two_le_H {d H : ℕ} (hD : d + 3 < 2 ^ H) :
    Real.log ((d : ℝ) + 2) ≤ (H : ℝ) := by
  have hpos : (0 : ℝ) < (d : ℝ) + 2 := by positivity
  have hle : (d : ℝ) + 2 ≤ (2 : ℝ) ^ H := by
    have : d + 2 ≤ 2 ^ H := by omega
    exact_mod_cast this
  calc Real.log ((d : ℝ) + 2)
      ≤ Real.log ((2 : ℝ) ^ H) := Real.log_le_log hpos hle
    _ = (H : ℝ) * Real.log 2 := Real.log_pow 2 H
    _ ≤ (H : ℝ) * 1 := by gcongr; exact log_two_le_one
    _ = (H : ℝ) := mul_one _

lemma execFailureScaleBit_zero_le {d n t : ℕ} (hn : 2 ≤ n) (ht : 1 ≤ t) {δ : ℝ}
    (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    execFailureScaleBit n t d 0 δ ≤ 5 * 2 ^ H := by
  intro D H
  obtain ⟨_, hH5, _, hn2, ht2, hD2, h2d⟩ := scale_basic_bounds (d := d) hn ht hδ0 hδ1
  have hlog : Real.log (2 / δ) ≤ ((2 ^ H : ℕ) : ℝ) := by
    have hpos : 0 < 2 / δ := by positivity
    have h1 := Real.log_le_sub_one_of_pos hpos
    have h2 : (2 : ℝ) ^ H = ((2 ^ H : ℕ) : ℝ) := by norm_cast
    linarith
  have hceil : Nat.ceil (Real.log (2 / δ)) ≤ 2 ^ H := Nat.ceil_le.mpr hlog
  have hn_le : n ≤ 2 ^ H := le_of_lt hn2
  have ht_le : t ≤ 2 ^ H := le_of_lt ht2
  have hd2_le : d + 2 ≤ 2 ^ H := by
    have : d + 3 < 2 ^ H := hD2
    omega
  unfold execFailureScaleBit
  calc n + t + d + 0 + Nat.ceil (Real.log (2 / δ)) + 2
      = n + t + (d + 2) + Nat.ceil (Real.log (2 / δ)) := by omega
    _ ≤ 2 ^ H + 2 ^ H + 2 ^ H + 2 ^ H :=
        Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hn_le ht_le) hd2_le) hceil
    _ ≤ 5 * 2 ^ H := by ring_nf; exact Nat.mul_le_mul_left (2 ^ H) (by omega : 4 ≤ 5)

/-- Exact integer characterizations of the Section C.2 schedule predicates at `α = 1 / (4 D^2)`. -/
lemma alpha_pos_and_lt_half (D : ℕ) (hD : 3 ≤ D) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    0 < α ∧ α ≤ 1 / 2 ∧ α < 1 ∧ α⁻¹ = 4 * (D : ℝ) ^ 2 ∧ (α ^ 2)⁻¹ = 16 * (D : ℝ) ^ 4 := by
  intro α
  have hDr : (3 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD
  have hDpos : (0 : ℝ) < 4 * (D : ℝ) ^ 2 := by positivity
  refine ⟨by positivity, ?_, ?_, ?_, ?_⟩
  · dsimp [α]; rw [div_le_div_iff₀ hDpos (by norm_num : (0 : ℝ) < 2)]; nlinarith
  · dsimp [α]; rw [div_lt_iff₀ hDpos]; nlinarith
  · dsimp [α]; rw [one_div, inv_inv]
  · dsimp [α]; field_simp; ring

lemma nat_floor_div_eq (m q : ℕ) (hq : 0 < q) :
    ⌊(m : ℝ) / (q : ℝ)⌋₊ = m / q := by
  have hqr : (0 : ℝ) < (q : ℝ) := by exact_mod_cast hq
  rw [Nat.floor_eq_iff (by positivity)]
  constructor
  · rw [le_div_iff₀ hqr]
    exact_mod_cast Nat.div_mul_le_self m q
  · rw [div_lt_iff₀ hqr]
    have hlt : m < (m / q + 1) * q := by
      have := Nat.div_add_mod m q
      have := Nat.mod_lt m hq
      nlinarith
    exact_mod_cast hlt

lemma canOpenResidualLevel_iff_nat (D : ℕ) (hD : 3 ≤ D) (r m : ℕ) :
    CanOpenResidualLevel (1 / (4 * (D : ℝ) ^ 2)) r m ↔ 16384 * D ^ 2 * r ≤ m := by
  unfold CanOpenResidualLevel scheduleCStar
  simp only [Nat.cast_ofNat]
  have hpos : (0 : ℝ) < 16384 * (D : ℝ) ^ 2 := by
    have : (3 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD
    positivity
  have hrw : (1 / (4 * (D : ℝ) ^ 2)) * (m : ℝ) / (4096 : ℝ) =
      (m : ℝ) / (16384 * (D : ℝ) ^ 2) := by ring
  rw [hrw, le_div_iff₀ hpos]
  have hcast : ((16384 * D ^ 2 * r : ℕ) : ℝ) = (r : ℝ) * (16384 * (D : ℝ) ^ 2) := by
    push_cast; ring
  rw [← hcast]
  exact_mod_cast Iff.rfl

lemma jobStartAge_eq_nat (D : ℕ) (hD : 3 ≤ D) (M : ℕ) :
    jobStartAge (1 / (4 * (D : ℝ) ^ 2)) M = M / (256 * D ^ 2) := by
  unfold jobStartAge
  have hrw : (1 / (4 * (D : ℝ) ^ 2)) * (M : ℝ) / 64 = (M : ℝ) / ((256 * D ^ 2 : ℕ) : ℝ) := by
    push_cast; ring
  rw [hrw]
  have hq : 0 < 256 * D ^ 2 := by positivity
  exact nat_floor_div_eq M (256 * D ^ 2) hq

lemma jobDeadlineTicks_eq_nat (D : ℕ) (hD : 3 ≤ D) (m : ℕ) :
    jobDeadlineTicks (1 / (4 * (D : ℝ) ^ 2)) m = m / (16384 * D ^ 2) := by
  unfold jobDeadlineTicks scheduleCStar
  simp only [Nat.cast_ofNat]
  have hrw : (1 / (4 * (D : ℝ) ^ 2)) * (m : ℝ) / 4096 =
      (m : ℝ) / ((16384 * D ^ 2 : ℕ) : ℝ) := by
    push_cast; ring
  rw [hrw]
  have hq : 0 < 16384 * D ^ 2 := by positivity
  exact nat_floor_div_eq m (16384 * D ^ 2) hq

lemma maxLevelBuildTicks_eq_nat (D : ℕ) (hD : 3 ≤ D) (m : ℕ) :
    maxLevelBuildTicks (1 / (4 * (D : ℝ) ^ 2)) m = m / (4194304 * D ^ 4) := by
  unfold maxLevelBuildTicks scheduleCStar
  simp only [Nat.cast_ofNat]
  have hrw : (1 / (4 * (D : ℝ) ^ 2)) ^ 2 * (m : ℝ) / (64 * 4096) =
      (m : ℝ) / ((4194304 * D ^ 4 : ℕ) : ℝ) := by
    push_cast; ring
  rw [hrw]
  have hq : 0 < 4194304 * D ^ 4 := by positivity
  exact nat_floor_div_eq m (4194304 * D ^ 4) hq

lemma passesBirthCoreCheck_iff_nat {d : ℕ} {ι : Type} (D : ℕ) (hD : 3 ≤ D)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (N : ChainNode d) (S_birth : Finset ι) :
    PassesBirthCoreCheck (1 / (4 * (D : ℝ) ^ 2)) pts N S_birth ↔
      S_birth.card ≤ 8 * D ^ 2 * (N.core pts S_birth).card := by
  unfold PassesBirthCoreCheck
  have hpos : (0 : ℝ) < 8 * (D : ℝ) ^ 2 := by
    have : (3 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD
    positivity
  have hrw : (1 / (4 * (D : ℝ) ^ 2)) * (S_birth.card : ℝ) / 2 =
      (S_birth.card : ℝ) / (8 * (D : ℝ) ^ 2) := by ring
  rw [hrw, div_le_iff₀ hpos]
  have hcast : ((8 * D ^ 2 * (N.core pts S_birth).card : ℕ) : ℝ) =
      ((N.core pts S_birth).card : ℝ) * (8 * (D : ℝ) ^ 2) := by
    push_cast; ring
  rw [← hcast]
  exact_mod_cast Iff.rfl

/-- From Lemma 5.1, any `α`-centerpoint on `paraboloidLiftSet P₀` (`1 ≤ |P₀|`) has `0 ≤ V` and
passes `PassesBirthCoreCheck α`, so `selectOpenedLevelBall` keeps `(o, V)` unchanged. -/
lemma centerpoint_selectOpenedLevelBall_eq
    (h_lem_5_1 : S_lem_5_1)
    {d : ℕ} {ι : Type} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_birth : Finset ι)
    (hm : 1 ≤ S_birth.card) {α : ℝ} (hα : 0 < α) (bId : ι)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun i : S_birth => pts i.1)) (liftedPoint o s)) :
    let V := liftVariance o s
    0 ≤ V ∧
    (selectOpenedLevelBall α pts S_birth bId (.candidate o V)).o = o ∧
    (selectOpenedLevelBall α pts S_birth bId (.candidate o V)).V = V := by
  classical
  intro V
  have hdepth : α * (S_birth.card : ℝ) ≤
      (halfspaceDepth (paraboloidLiftSet (fun i : S_birth => pts i.1)) (liftedPoint o s) : ℝ) := by
    have hcard : Fintype.card S_birth = S_birth.card := Fintype.card_coe S_birth
    simpa [IsCenterpoint, hcard] using hcp
  have h51 := (h_lem_5_1 d ι pts S_birth hm α hα o s hdepth).2.2 0 [] (by simp)
  have hcnt_pos : (0 : ℝ) < α * (S_birth.card : ℝ) - (0 : ℝ) := by
    have : (1 : ℝ) ≤ (S_birth.card : ℝ) := by exact_mod_cast hm
    nlinarith
  have hpc : α * (S_birth.card : ℝ) - (0 : ℝ) ≤
      (pointCount (fun i : ↥S_birth => pts i.1) {x | ‖x - o‖ ^ 2 ≤ V} : ℝ) := by
    simpa using h51.2.2.2.2.1
  have hV0 : 0 ≤ V := by
    have hcard_pos : 0 < pointCount (fun i : ↥S_birth => pts i.1) {x | ‖x - o‖ ^ 2 ≤ V} := by
      have : (0 : ℝ) < (pointCount (fun i : ↥S_birth => pts i.1) {x | ‖x - o‖ ^ 2 ≤ V} : ℝ) :=
        lt_of_lt_of_le hcnt_pos hpc
      exact_mod_cast this
    unfold pointCount at hcard_pos
    obtain ⟨i, hi⟩ := Finset.card_pos.mp hcard_pos
    simp only [Finset.mem_univ, Finset.mem_filter, Set.mem_setOf_eq, true_and] at hi
    exact le_trans (sq_nonneg _) hi
  let prov : ChainNode d := { o := o, V := V, V_nonneg := hV0 }
  have hcore_eq : pointCount (fun i : ↥S_birth => pts i.1) (coreBall o V) =
      (prov.core pts S_birth).card := by
    unfold pointCount ChainNode.core nodeCore
    refine Finset.card_bij (fun (a : ↥S_birth) _ => a.1) ?_ ?_ ?_
    · intro a ha
      simp only [Finset.mem_univ, Finset.mem_filter, true_and] at ha
      exact Finset.mem_filter.mpr ⟨a.2, ha⟩
    · intro a₁ _ a₂ _ h
      exact Subtype.ext h
    · intro b hb
      rcases Finset.mem_filter.mp hb with ⟨hbS, hbC⟩
      exact ⟨⟨b, hbS⟩, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hbC⟩, rfl⟩
  have hcore_ge : α * (S_birth.card : ℝ) ≤ ((prov.core pts S_birth).card : ℝ) := by
    have hpc1 : α * (S_birth.card : ℝ) - (0 : ℝ) ≤
        (pointCount (fun i : ↥S_birth => pts i.1) (coreBall o V) : ℝ) := by
      simpa using h51.2.2.2.1
    rw [hcore_eq] at hpc1
    linarith
  have hpass : PassesBirthCoreCheck α pts prov S_birth := by
    unfold PassesBirthCoreCheck
    have : (0 : ℝ) ≤ α * (S_birth.card : ℝ) := by positivity
    linarith
  have hprov : provisionalCenter pts bId (.candidate o V) = prov := by
    simp [provisionalCenter, hV0, prov]
  have hsel : selectOpenedLevelBall α pts S_birth bId (.candidate o V) = prov := by
    simp [selectOpenedLevelBall, hprov, applyBirthCoreFallback, hpass]
  exact ⟨hV0, by simp [hsel, prov], by simp [hsel, prov]⟩

/-- Two-phase background scan completion within `maxLevelBuildTicks` at `α = 1 / (4 D^2)`. -/
lemma two_phase_scan_ticks_bound {D L m B_scan t₁ t₂ m_mid : ℕ}
    (hD : 3 ≤ D)
    (hL : 68719476736 * D ^ 4 ≤ L)
    (hm : 2 * L + 1 < m)
    (hB : 16777216 * D ^ 4 ≤ B_scan)
    (ht1 : t₁ ≤ m / B_scan + 1)
    (hmid : m_mid ≤ m + t₁)
    (ht2 : t₂ ≤ m_mid / B_scan + 1) :
    t₁ + t₂ < maxLevelBuildTicks (1 / (4 * (D : ℝ) ^ 2)) m := by
  rw [maxLevelBuildTicks_eq_nat D hD m]
  have hd4_pos_raw : 1 ≤ D ^ 4 := Nat.one_le_pow 4 D (by omega)
  generalize hd4_eq : D ^ 4 = d4 at hL hB hd4_pos_raw ⊢
  have hq_pos : 0 < 4194304 * d4 := by omega
  generalize hq_eq : 4194304 * d4 = q at hq_pos ⊢
  have hB4 : 4 * q ≤ B_scan := by omega
  have hm_big : 32768 * q ≤ m := by omega
  have hb_ge : 32768 ≤ m / q := (Nat.le_div_iff_mul_le hq_pos).mpr hm_big
  have hdiv1 : m / B_scan ≤ (m / q) / 4 := by
    calc m / B_scan ≤ m / (4 * q) := Nat.div_le_div_left hB4 (by omega)
      _ = (m / q) / 4 := by rw [Nat.mul_comm 4 q, ← Nat.div_div_eq_div_mul]
  have ht1_le : t₁ ≤ (m / q) / 4 + 1 := le_trans ht1 (Nat.add_le_add_right hdiv1 1)
  have hmid_le : m_mid ≤ 2 * m := by
    have ht1_m : t₁ ≤ m := by
      have hsub : (m / q) / 4 + 1 ≤ m / q := by
        generalize m / q = Q at hb_ge ⊢
        omega
      exact le_trans ht1_le (le_trans hsub (Nat.div_le_self m q))
    omega
  have h2m_lt : (2 * m) / q < 2 * (m / q) + 2 := by
    rw [Nat.div_lt_iff_lt_mul hq_pos]
    have h1 := Nat.div_add_mod m q
    have h2 := Nat.mod_lt m hq_pos
    nlinarith
  have hdiv2 : m_mid / B_scan ≤ ((2 * m) / q) / 4 := by
    calc m_mid / B_scan ≤ (2 * m) / B_scan := Nat.div_le_div_right hmid_le
      _ ≤ (2 * m) / (4 * q) := Nat.div_le_div_left hB4 (by omega)
      _ = ((2 * m) / q) / 4 := by rw [Nat.mul_comm 4 q, ← Nat.div_div_eq_div_mul]
  have ht2_le : t₂ ≤ ((2 * m) / q) / 4 + 1 := le_trans ht2 (Nat.add_le_add_right hdiv2 1)
  generalize m / q = Q at hb_ge ht1_le h2m_lt ⊢
  generalize (2 * m) / q = R at h2m_lt ht2_le
  omega

lemma mem_coreBall_iff_norm_sq_le {d : ℕ} (o x : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 ≤ V) :
    x ∈ coreBall o V ↔ ‖x - o‖ ^ 2 ≤ V := by
  rw [coreBall, Metric.mem_closedBall, dist_eq_norm]
  constructor
  · intro h
    calc ‖x - o‖ ^ 2 ≤ (Real.sqrt V) ^ 2 := pow_le_pow_left₀ (norm_nonneg _) h 2
      _ = V := Real.sq_sqrt hV
  · intro h
    rw [← Real.sqrt_sq (norm_nonneg _)]
    exact Real.sqrt_le_sqrt h

/-- `rebuildOversizedLeafAux` at `α = 1 / (4 D^2)` stabilizes in `20 * D^2 + 1` steps from any
set `S` of size `≤ 6 * L + 1` (`L ≥ 20 * D^2`), so fuel `S.card` equals fuel `20 * D^2 + 1`. -/
lemma rebuildOversizedLeafAux_fuel_eq {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (D L : ℕ) (hD : 3 ≤ D) (hL : 20 * D ^ 2 ≤ L)
    (S : Finset ι) (hS : S.card ≤ 6 * L + 1)
    (choices : List (LeafRebuildLevelChoices d ι)) :
    ∀ (f₁ f₂ : ℕ), 20 * D ^ 2 + 1 ≤ f₁ → 20 * D ^ 2 + 1 ≤ f₂ →
      rebuildOversizedLeafAux pts mode (1 / (4 * (D : ℝ) ^ 2)) L f₁ S choices =
      rebuildOversizedLeafAux pts mode (1 / (4 * (D : ℝ) ^ 2)) L f₂ S choices := by
  classical
  intro f₁ f₂ hf₁ hf₂
  set d2 := D ^ 2 with hd2_def
  have hd2_pos : 9 ≤ d2 := by dsimp [d2]; nlinarith
  have hstep_drop : ∀ (S_cur : Finset ι) (ch : LeafRebuildLevelChoices d ι),
      ¬ IsResidualLeafSize L S_cur.card →
      ∀ hNE : S_cur.Nonempty,
        let bId := chooseBirthPointIn S_cur hNE ch.fallbackBirthId
        let ball := selectOpenedLevelBall (1 / (4 * (D : ℝ) ^ 2)) pts S_cur bId ch.sampledCenter
        (ball.residual pts S_cur).card + (L / (4 * d2)) ≤ S_cur.card := by
    intro S_cur ch hnot hNE bId ball
    unfold IsResidualLeafSize at hnot
    have hm_gt : 2 * L + 1 < S_cur.card := by omega
    have hpass : PassesBirthCoreCheck (1 / (4 * (D : ℝ) ^ 2)) pts ball S_cur := by
      dsimp only [ball, selectOpenedLevelBall, applyBirthCoreFallback]
      split_ifs with hp
      · exact hp
      · set pCenter := (provisionalCenter pts bId ch.sampledCenter).o
        set mRadSq := (nodeMaxRadius pts pCenter S_cur) ^ 2
        change PassesBirthCoreCheck (1 / (4 * (D : ℝ) ^ 2)) pts
          (maxBirthRadiusBall pts pCenter S_cur) S_cur
        unfold PassesBirthCoreCheck maxBirthRadiusBall ChainNode.core nodeCore
        dsimp only
        have hmRad0 : 0 ≤ mRadSq := sq_nonneg _
        have hsub : S_cur ⊆ S_cur.filter (fun i => pts i ∈ coreBall pCenter mRadSq) := by
          intro x hx
          rw [Finset.mem_filter]
          refine ⟨hx, (mem_coreBall_iff_norm_sq_le pCenter (pts x) hmRad0).mpr ?_⟩
          have hle : ‖pts x - pCenter‖ ≤ nodeMaxRadius pts pCenter S_cur := by
            unfold nodeMaxRadius
            simp only [hNE, ↓reduceDIte]
            exact Finset.le_sup' (fun j => ‖pts j - pCenter‖) hx
          exact pow_le_pow_left₀ (norm_nonneg _) hle 2
        have hcard_eq : (S_cur.filter (fun i => pts i ∈ coreBall pCenter mRadSq)).card = S_cur.card :=
          le_antisymm (Finset.card_filter_le _ _) (Finset.card_le_card hsub)
        rw [hcard_eq]
        have hα := alpha_pos_and_lt_half D hD
        nlinarith [hα.1, hα.2.1]
    rw [passesBirthCoreCheck_iff_nat D hD, ← hd2_def] at hpass
    have hpart : (ball.residual pts S_cur).card + (ball.core pts S_cur).card = S_cur.card := by
      unfold ChainNode.residual nodeResidual ChainNode.core
      exact Finset.card_sdiff_add_card_eq_card (Finset.filter_subset _ S_cur)
    have hcore_lb : L / (4 * d2) ≤ (ball.core pts S_cur).card := by
      have h1 : (L / (4 * d2)) * (8 * d2) ≤ 2 * L := by
        have := Nat.div_mul_le_self L (4 * d2)
        nlinarith
      nlinarith
    exact le_trans (Nat.add_le_add_left hcore_lb _) (le_of_eq hpart)
  have haux : ∀ (k : ℕ) (S_cur : Finset ι) (chs : List (LeafRebuildLevelChoices d ι))
      (f₁' f₂' : ℕ),
      S_cur.card ≤ (2 * L + 1) + k * (L / (4 * d2)) →
      k + 1 ≤ f₁' → k + 1 ≤ f₂' →
      rebuildOversizedLeafAux pts mode (1 / (4 * (D : ℝ) ^ 2)) L f₁' S_cur chs =
      rebuildOversizedLeafAux pts mode (1 / (4 * (D : ℝ) ^ 2)) L f₂' S_cur chs := by
    intro k
    induction k with
    | zero =>
        intro S_cur chs f₁' f₂' hcard hf1 hf2
        obtain ⟨a, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : f₁' ≠ 0)
        obtain ⟨b, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : f₂' ≠ 0)
        have hleaf : IsResidualLeafSize L S_cur.card := by
          unfold IsResidualLeafSize; omega
        simp [rebuildOversizedLeafAux, hleaf]
    | succ k ih =>
        intro S_cur chs f₁' f₂' hcard hf1 hf2
        obtain ⟨a, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : f₁' ≠ 0)
        obtain ⟨b, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : f₂' ≠ 0)
        by_cases hleaf : IsResidualLeafSize L S_cur.card
        · simp [rebuildOversizedLeafAux, hleaf]
        · have hNE : S_cur.Nonempty := by
            unfold IsResidualLeafSize at hleaf
            exact Finset.card_pos.mp (by omega)
          let ch := chs.head?.getD
            { sampledCenter := .infeasible, fallbackBirthId := none,
              radiusMaxHint := none, pointInsertOrder := [] }
          have hdrop := hstep_drop S_cur ch hleaf hNE
          have hnext_card :
              ((selectOpenedLevelBall (1 / (4 * (D : ℝ) ^ 2)) pts S_cur
                (chooseBirthPointIn S_cur hNE ch.fallbackBirthId) ch.sampledCenter).residual
                pts S_cur).card ≤ (2 * L + 1) + k * (L / (4 * d2)) := by
            have : (k + 1) * (L / (4 * d2)) = k * (L / (4 * d2)) + (L / (4 * d2)) := by ring
            omega
          simp only [rebuildOversizedLeafAux, hleaf, ↓reduceIte, hNE, ↓reduceDIte]
          rw [ih _ (chs.drop 1) a b hnext_card (by omega) (by omega)]
  have hS_bound : S.card ≤ (2 * L + 1) + (20 * d2) * (L / (4 * d2)) := by
    have hL' : 20 * d2 ≤ L := hL
    have hq : 0 < 4 * d2 := by nlinarith
    have hrem : (4 * d2) * (L / (4 * d2)) + L % (4 * d2) = L := Nat.div_add_mod L (4 * d2)
    have hmod : L % (4 * d2) < 4 * d2 := Nat.mod_lt L hq
    have h5 : (20 * d2) * (L / (4 * d2)) + 5 * (L % (4 * d2)) = 5 * L := by
      calc (20 * d2) * (L / (4 * d2)) + 5 * (L % (4 * d2))
          = 5 * ((4 * d2) * (L / (4 * d2)) + L % (4 * d2)) := by ring
        _ = 5 * L := by rw [hrem]
    generalize (20 * d2) * (L / (4 * d2)) = P at h5 ⊢
    generalize L % (4 * d2) = v at h5 hmod
    generalize hd2_g : d2 = w at hL' hd2_pos hmod
    omega
  exact haux (20 * d2) S choices f₁ f₂ hS_bound hf₁ hf₂

/-- Equation (10) leaf cutoff holds for `L_cut = (68719476736 + 8 * K_coeff) * D^4 * H^2` when
`K₀ ≤ K_coeff * D^2 * H`. -/
lemma satisfiesLeafCutoffEq10_of_L_cut {d n H K₀ K_coeff : ℕ}
    (hn : 2 ≤ n) (hH : 5 ≤ H) (hn2 : n < 2 ^ H)
    (hK₀ : K₀ ≤ K_coeff * (d + 3) ^ 2 * H) :
    let D := d + 3
    let L_cut := (68719476736 + 8 * K_coeff) * D ^ 4 * H ^ 2
    SatisfiesLeafCutoffEq10 d n (1 / (4 * (D : ℝ) ^ 2)) 0 K₀ L_cut := by
  intro D L_cut
  unfold SatisfiesLeafCutoffEq10 SatisfiesLeafCutoffReal scheduleCStar
  simp only [Nat.cast_ofNat]
  have hD3 : 3 ≤ D := by omega
  obtain ⟨_, _, _, hinv, hinv2⟩ := alpha_pos_and_lt_half D hD3
  rw [hinv, hinv2]
  constructor
  · have h1 : (2 : ℝ) ^ 20 * 4096 * (16 * (D : ℝ) ^ 4) = 68719476736 * (D : ℝ) ^ 4 := by ring
    rw [h1]
    have hH2 : 1 ≤ H ^ 2 := Nat.one_le_pow 2 H (by omega)
    have hnat : 68719476736 * D ^ 4 ≤ L_cut := by
      dsimp [L_cut]
      calc 68719476736 * D ^ 4
          = 68719476736 * D ^ 4 * 1 := (Nat.mul_one _).symm
        _ ≤ (68719476736 + 8 * K_coeff) * D ^ 4 * 1 :=
            Nat.mul_le_mul_right 1 (Nat.mul_le_mul_right (D ^ 4) (by omega))
        _ ≤ (68719476736 + 8 * K_coeff) * D ^ 4 * H ^ 2 := Nat.mul_le_mul_left _ hH2
    exact_mod_cast hnat
  · have hlogn : Real.log (n : ℝ) ≤ (H : ℝ) := by
      have hpos : (0 : ℝ) < (n : ℝ) := by positivity
      have hle : (n : ℝ) ≤ (2 : ℝ) ^ H := by exact_mod_cast (le_of_lt hn2)
      calc Real.log (n : ℝ)
          ≤ Real.log ((2 : ℝ) ^ H) := Real.log_le_log hpos hle
        _ = (H : ℝ) * Real.log 2 := Real.log_pow 2 H
        _ ≤ (H : ℝ) * 1 := by gcongr; exact log_two_le_one
        _ = (H : ℝ) := mul_one _
    have hdH : (d : ℝ) + Real.log (n : ℝ) ≤ (D : ℝ) + (H : ℝ) := by
      have : (d : ℝ) ≤ (D : ℝ) := by dsimp [D]; push_cast; linarith
      linarith
    have hKr : (K₀ : ℝ) ≤ (K_coeff : ℝ) * (D : ℝ) ^ 2 * (H : ℝ) := by exact_mod_cast hK₀
    have hDr : (3 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD3
    have hHr : (5 : ℝ) ≤ (H : ℝ) := by exact_mod_cast hH
    have hD_le_D2H : (D : ℝ) + (H : ℝ) ≤ 2 * (D : ℝ) * (H : ℝ) := by nlinarith
    have hprod : ((d : ℝ) + Real.log (n : ℝ)) * (K₀ : ℝ) ≤
        2 * (K_coeff : ℝ) * (D : ℝ) ^ 3 * (H : ℝ) ^ 2 := by
      calc ((d : ℝ) + Real.log (n : ℝ)) * (K₀ : ℝ)
          ≤ (2 * (D : ℝ) * (H : ℝ)) * ((K_coeff : ℝ) * (D : ℝ) ^ 2 * (H : ℝ)) := by
            gcongr; exact le_trans hdH hD_le_D2H
        _ = 2 * (K_coeff : ℝ) * (D : ℝ) ^ 3 * (H : ℝ) ^ 2 := by ring
    have h64 : 64 * (4 * (D : ℝ) ^ 2) ≤ 256 * (D : ℝ) ^ 4 * (H : ℝ) ^ 2 := by
      have : (1 : ℝ) ≤ (D : ℝ) ^ 2 * (H : ℝ) ^ 2 := by nlinarith
      nlinarith
    have hterm1 : 2 * (K_coeff : ℝ) * (D : ℝ) ^ 3 * (H : ℝ) ^ 2 ≤
        8 * (K_coeff : ℝ) * (D : ℝ) ^ 4 * (H : ℝ) ^ 2 := by
      have h1 : (D : ℝ) ^ 3 ≤ (D : ℝ) ^ 4 :=
        pow_le_pow_right₀ (by linarith : (1 : ℝ) ≤ (D : ℝ)) (by omega : 3 ≤ 4)
      have h2 : 0 ≤ (K_coeff : ℝ) * (H : ℝ) ^ 2 := by positivity
      nlinarith
    have hDH_pos : 0 ≤ (D : ℝ) ^ 4 * (H : ℝ) ^ 2 := by positivity
    have hLcast : (L_cut : ℝ) =
        68719476736 * ((D : ℝ) ^ 4 * (H : ℝ) ^ 2) +
        8 * (K_coeff : ℝ) * (D : ℝ) ^ 4 * (H : ℝ) ^ 2 := by
      dsimp [L_cut]; push_cast; ring
    have h64' : 64 * (4 * (D : ℝ) ^ 2) ≤ 256 * ((D : ℝ) ^ 4 * (H : ℝ) ^ 2) := by linarith
    rw [hLcast]
    linarith

lemma nat_le_two_pow_mul_H (c H : ℕ) (hH : 1 ≤ H) : c ≤ 2 ^ (c * H) := by
  calc c ≤ 2 ^ c := le_of_lt c.lt_two_pow_self
    _ ≤ 2 ^ (c * H) := Nat.pow_le_pow_right (by omega) (Nat.le_mul_of_pos_right c hH)

/-- Per-step failure budget and per-sampler fallback error bounds. -/
lemma failure_budget_bounds
    {d n t cDepthNat cHpjNat cBaseNat D₀ K₀ : ℕ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hcD : 1 ≤ cDepthNat)
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (H : ℕ)
    (hH_eq : H = Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ)))
    (hD₀ : D₀ ≤ 8 * cDepthNat * (d + 3) ^ 2 * H)
    (hK₀ : K₀ ≤ 4 * cBaseNat * (17 + cDepthNat) * (d + 3) ^ 2 * H) :
    let D : ℕ := d + 3
    let k_φ : ℕ := (16 + cDepthNat) * H
    let φ_ev : ℝ := (1 / 2 : ℝ) ^ k_φ
    let N_hpj : ℕ := cHpjNat * (17 + cDepthNat) ^ 3 * D ^ 7 * H ^ 6
    let K_rank : ℕ := k_φ + (20 + cHpjNat + 3 * (17 + cDepthNat) + 4 * cBaseNat) * H
    0 < φ_ev ∧ φ_ev < 1 / 2 ∧
    Real.log (2 / φ_ev) ≤ (((17 + cDepthNat) * H : ℕ) : ℝ) ∧
    (N_hpj : ℝ) * ((1 / 2 : ℝ) ^ K_rank) ≤ φ_ev ∧
    (K₀ : ℝ) * ((1 / 2 : ℝ) ^ K_rank) ≤ φ_ev ∧
    ((2 * D₀ + 20 * D ^ 2 + 2 : ℕ) : ℝ) * (2 * φ_ev) ≤
      perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ := by
  intro D k_φ φ_ev N_hpj K_rank
  have hsb := scale_basic_bounds (d := d) hn ht hδ0 hδ1
  dsimp only at hsb
  rw [← hH_eq] at hsb
  obtain ⟨hD3, hH5, _, hn2, ht2, hD2, h2d⟩ := hsb
  have hS_le_raw : execFailureScaleBit n t d 0 δ ≤ 5 * 2 ^ H := by
    have h := execFailureScaleBit_zero_le (d := d) hn ht hδ0 hδ1
    dsimp only at h
    rwa [← hH_eq] at h
  have hS_pos_raw : 0 < execFailureScaleBit n t d 0 δ := by
    unfold execFailureScaleBit; omega
  generalize hS_eq : execFailureScaleBit n t d 0 δ = S at hS_le_raw hS_pos_raw ⊢
  clear hH_eq hS_eq
  -- Also abstract `D = d + 3` so tactics treat `D` as an atomic `ℕ`
  change 0 < φ_ev ∧ _
  have hH1 : 1 ≤ H := by omega
  have hk_gt1 : 1 < k_φ := by
    change 1 < (16 + cDepthNat) * H
    calc 1 < 16 * 5 := by omega
      _ ≤ (16 + cDepthNat) * H := Nat.mul_le_mul (by omega) hH5
  have hφ_pos : 0 < φ_ev := by
    change 0 < (1 / 2 : ℝ) ^ k_φ
    positivity
  have hφ_lt : φ_ev < 1 / 2 := by
    change (1 / 2 : ℝ) ^ k_φ < 1 / 2
    calc (1 / 2 : ℝ) ^ k_φ ≤ (1 / 2 : ℝ) ^ 2 :=
          pow_le_pow_of_le_one (by norm_num) (by norm_num) (Nat.succ_le_of_lt hk_gt1)
      _ < 1 / 2 := by norm_num
  have hlog_φ : Real.log (2 / φ_ev) ≤ (((17 + cDepthNat) * H : ℕ) : ℝ) := by
    have heq : 2 / φ_ev = (2 : ℝ) ^ (k_φ + 1) := by
      change 2 / ((1 / 2 : ℝ) ^ k_φ) = (2 : ℝ) ^ (k_φ + 1)
      rw [one_div, inv_pow, div_inv_eq_mul, mul_comm]
      ring
    rw [heq, Real.log_pow]
    calc ((k_φ + 1 : ℕ) : ℝ) * Real.log 2
        ≤ ((k_φ + 1 : ℕ) : ℝ) * 1 := by gcongr; exact log_two_le_one
      _ ≤ (((17 + cDepthNat) * H : ℕ) : ℝ) := by
          have hk_le : k_φ + 1 ≤ (17 + cDepthNat) * H := by
            calc (16 + cDepthNat) * H + 1
                ≤ (16 + cDepthNat) * H + H := Nat.add_le_add_left hH1 _
              _ = (17 + cDepthNat) * H := by ring
          have : ((k_φ + 1 : ℕ) : ℝ) ≤ (((17 + cDepthNat) * H : ℕ) : ℝ) := by exact_mod_cast hk_le
          linarith
  have hH_pow : H ≤ 2 ^ H := le_of_lt H.lt_two_pow_self
  have hD_pow : D ≤ 2 ^ H := le_of_lt hD2
  let M_extra : ℕ := (20 + cHpjNat + 3 * (17 + cDepthNat) + 4 * cBaseNat) * H
  have hN_nat : N_hpj ≤ 2 ^ M_extra := by
    have h1 : cHpjNat ≤ 2 ^ (cHpjNat * H) := nat_le_two_pow_mul_H cHpjNat H hH1
    have h2 : (17 + cDepthNat) ^ 3 ≤ 2 ^ (3 * (17 + cDepthNat) * H) := by
      calc (17 + cDepthNat) ^ 3
          ≤ (2 ^ ((17 + cDepthNat) * H)) ^ 3 :=
            Nat.pow_le_pow_left (nat_le_two_pow_mul_H _ H hH1) 3
        _ = 2 ^ (3 * (17 + cDepthNat) * H) := by rw [← Nat.pow_mul]; ring_nf
    have h3 : D ^ 7 ≤ 2 ^ (7 * H) := by
      calc D ^ 7 ≤ (2 ^ H) ^ 7 := Nat.pow_le_pow_left hD_pow 7
        _ = 2 ^ (7 * H) := by rw [← Nat.pow_mul]; ring_nf
    have h4 : H ^ 6 ≤ 2 ^ (6 * H) := by
      calc H ^ 6 ≤ (2 ^ H) ^ 6 := Nat.pow_le_pow_left hH_pow 6
        _ = 2 ^ (6 * H) := by rw [← Nat.pow_mul]; ring_nf
    have hexp : cHpjNat * H + 3 * (17 + cDepthNat) * H + 7 * H + 6 * H ≤ M_extra := by
      calc cHpjNat * H + 3 * (17 + cDepthNat) * H + 7 * H + 6 * H
          = (13 + cHpjNat + 3 * (17 + cDepthNat)) * H := by ring
        _ ≤ (20 + cHpjNat + 3 * (17 + cDepthNat) + 4 * cBaseNat) * H :=
            Nat.mul_le_mul_right H (by omega)
    calc N_hpj
        = cHpjNat * (17 + cDepthNat) ^ 3 * D ^ 7 * H ^ 6 := rfl
      _ ≤ 2 ^ (cHpjNat * H) * 2 ^ (3 * (17 + cDepthNat) * H) * 2 ^ (7 * H) * 2 ^ (6 * H) :=
          Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul h1 h2) h3) h4
      _ = 2 ^ (cHpjNat * H + 3 * (17 + cDepthNat) * H + 7 * H + 6 * H) := by
          simp only [← pow_add]
      _ ≤ 2 ^ M_extra := Nat.pow_le_pow_right (by omega : 0 < 2) hexp
  have hK0_nat : K₀ ≤ 2 ^ M_extra := by
    have h0 : 4 ≤ 2 ^ (4 * H) := nat_le_two_pow_mul_H 4 H hH1
    have h1 : cBaseNat ≤ 2 ^ (cBaseNat * H) := nat_le_two_pow_mul_H cBaseNat H hH1
    have h2 : 17 + cDepthNat ≤ 2 ^ ((17 + cDepthNat) * H) :=
      nat_le_two_pow_mul_H (17 + cDepthNat) H hH1
    have h3 : D ^ 2 ≤ 2 ^ (2 * H) := by
      calc D ^ 2 ≤ (2 ^ H) ^ 2 := Nat.pow_le_pow_left hD_pow 2
        _ = 2 ^ (2 * H) := by rw [← Nat.pow_mul]; ring_nf
    have hexp : 4 * H + cBaseNat * H + (17 + cDepthNat) * H + 2 * H + H ≤ M_extra := by
      calc 4 * H + cBaseNat * H + (17 + cDepthNat) * H + 2 * H + H
          = (7 + cBaseNat + (17 + cDepthNat)) * H := by ring
        _ ≤ (20 + cHpjNat + 3 * (17 + cDepthNat) + 4 * cBaseNat) * H :=
            Nat.mul_le_mul_right H (by omega)
    calc K₀
        ≤ 4 * cBaseNat * (17 + cDepthNat) * D ^ 2 * H := hK₀
      _ ≤ 2 ^ (4 * H) * 2 ^ (cBaseNat * H) * 2 ^ ((17 + cDepthNat) * H) * 2 ^ (2 * H) * 2 ^ H :=
          Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul h0 h1) h2) h3) hH_pow
      _ = 2 ^ (4 * H + cBaseNat * H + (17 + cDepthNat) * H + 2 * H + H) := by
          simp only [← pow_add]
      _ ≤ 2 ^ M_extra := Nat.pow_le_pow_right (by omega : 0 < 2) hexp
  have hN_prob : (N_hpj : ℝ) * ((1 / 2 : ℝ) ^ K_rank) ≤ φ_ev := by
    have hNr : (N_hpj : ℝ) ≤ (2 : ℝ) ^ M_extra := by exact_mod_cast hN_nat
    have hsplit : (1 / 2 : ℝ) ^ K_rank = (1 / 2 : ℝ) ^ M_extra * φ_ev := by
      change (1 / 2 : ℝ) ^ (k_φ + M_extra) = (1 / 2 : ℝ) ^ M_extra * (1 / 2 : ℝ) ^ k_φ
      rw [pow_add, mul_comm]
    rw [hsplit, ← mul_assoc]
    calc (N_hpj : ℝ) * (1 / 2 : ℝ) ^ M_extra * φ_ev
        ≤ (2 : ℝ) ^ M_extra * (1 / 2 : ℝ) ^ M_extra * φ_ev := by gcongr
      _ = 1 * φ_ev := by rw [← mul_pow]; norm_num
      _ = φ_ev := one_mul _
  have hK0_prob : (K₀ : ℝ) * ((1 / 2 : ℝ) ^ K_rank) ≤ φ_ev := by
    have hKr : (K₀ : ℝ) ≤ (2 : ℝ) ^ M_extra := by exact_mod_cast hK0_nat
    have hsplit : (1 / 2 : ℝ) ^ K_rank = (1 / 2 : ℝ) ^ M_extra * φ_ev := by
      change (1 / 2 : ℝ) ^ (k_φ + M_extra) = (1 / 2 : ℝ) ^ M_extra * (1 / 2 : ℝ) ^ k_φ
      rw [pow_add, mul_comm]
    rw [hsplit, ← mul_assoc]
    calc (K₀ : ℝ) * (1 / 2 : ℝ) ^ M_extra * φ_ev
        ≤ (2 : ℝ) ^ M_extra * (1 / 2 : ℝ) ^ M_extra * φ_ev := by gcongr
      _ = 1 * φ_ev := by rw [← mul_pow]; norm_num
      _ = φ_ev := one_mul _
  have hstep_prob :
      ((2 * D₀ + 20 * D ^ 2 + 2 : ℕ) : ℝ) * (2 * φ_ev) ≤
        perEventFailureBudget S 1 δ := by
    have hS_pos : (0 : ℝ) < (S : ℝ) := by exact_mod_cast hS_pos_raw
    unfold perEventFailureBudget
    rw [pow_one, le_div_iff₀ hS_pos]
    have h1_div_δ : 1 / δ ≤ (2 : ℝ) ^ H := by
      have : 1 / δ ≤ 2 / δ := div_le_div_of_nonneg_right (by norm_num) (le_of_lt hδ0)
      exact le_trans this (le_of_lt h2d)
    have hδ_lb : (1 / 2 : ℝ) ^ H ≤ δ := by
      have hp : (0 : ℝ) < (2 : ℝ) ^ H := by positivity
      rw [one_div, inv_pow, inv_le_comm₀ hp hδ0, ← one_div]
      exact h1_div_δ
    have hcnt_le : (2 * D₀ + 20 * D ^ 2 + 2) * 2 * S ≤ 2 ^ ((15 + cDepthNat) * H) := by
      have hcnt1 : (2 * D₀ + 20 * D ^ 2 + 2) * 2 ≤ 76 * cDepthNat * D ^ 2 * H := by
        have hD0' : D₀ ≤ 8 * cDepthNat * D ^ 2 * H := hD₀
        have hcDH : 1 ≤ cDepthNat * H := Nat.mul_pos hcD hH1
        have hD2_ge : 1 ≤ D ^ 2 := Nat.one_le_pow 2 D (by omega)
        have h1 : 1 ≤ cDepthNat * D ^ 2 * H := by
          calc 1 = 1 * 1 := rfl
            _ ≤ (cDepthNat * H) * D ^ 2 := Nat.mul_le_mul hcDH hD2_ge
            _ = cDepthNat * D ^ 2 * H := by ring
        have h2 : D ^ 2 ≤ cDepthNat * D ^ 2 * H := by
          calc D ^ 2 = 1 * D ^ 2 := (Nat.one_mul _).symm
            _ ≤ (cDepthNat * H) * D ^ 2 := Nat.mul_le_mul_right _ hcDH
            _ = cDepthNat * D ^ 2 * H := by ring
        calc (2 * D₀ + 20 * D ^ 2 + 2) * 2
            = 4 * D₀ + 40 * D ^ 2 + 4 := by ring
          _ ≤ 4 * (8 * cDepthNat * D ^ 2 * H) + 40 * (cDepthNat * D ^ 2 * H) +
                4 * (cDepthNat * D ^ 2 * H) :=
              Nat.add_le_add (Nat.add_le_add (Nat.mul_le_mul_left 4 hD0')
                (Nat.mul_le_mul_left 40 h2)) (by omega)
          _ = 76 * cDepthNat * D ^ 2 * H := by ring
      have h380 : 76 * 5 ≤ 2 ^ (9 * H) := by
        calc 76 * 5 ≤ 2 ^ 9 := by norm_num
          _ ≤ 2 ^ (9 * H) := Nat.pow_le_pow_right (by omega : 0 < 2) (by omega)
      have hcD_pow : cDepthNat ≤ 2 ^ (cDepthNat * H) := nat_le_two_pow_mul_H cDepthNat H hH1
      have hD2_pow : D ^ 2 ≤ 2 ^ (2 * H) := by
        calc D ^ 2 ≤ (2 ^ H) ^ 2 := Nat.pow_le_pow_left hD_pow 2
          _ = 2 ^ (2 * H) := by rw [← Nat.pow_mul]; ring_nf
      have hexp : 9 * H + cDepthNat * H + 2 * H + H + H ≤ (15 + cDepthNat) * H := by
        calc 9 * H + cDepthNat * H + 2 * H + H + H
            = (13 + cDepthNat) * H := by ring
          _ ≤ (15 + cDepthNat) * H := Nat.mul_le_mul_right H (by omega)
      calc (2 * D₀ + 20 * D ^ 2 + 2) * 2 * S
          ≤ (76 * cDepthNat * D ^ 2 * H) * (5 * 2 ^ H) := Nat.mul_le_mul hcnt1 hS_le_raw
        _ = (76 * 5) * cDepthNat * D ^ 2 * H * 2 ^ H := by ring
        _ ≤ 2 ^ (9 * H) * 2 ^ (cDepthNat * H) * 2 ^ (2 * H) * 2 ^ H * 2 ^ H :=
            Nat.mul_le_mul
              (Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul h380 hcD_pow) hD2_pow) hH_pow)
              le_rfl
        _ = 2 ^ (9 * H + cDepthNat * H + 2 * H + H + H) := by simp only [← pow_add]
        _ ≤ 2 ^ ((15 + cDepthNat) * H) := Nat.pow_le_pow_right (by omega : 0 < 2) hexp
    have hcnt_r : ((2 * D₀ + 20 * D ^ 2 + 2 : ℕ) : ℝ) * 2 * (S : ℝ) ≤
        (2 : ℝ) ^ ((15 + cDepthNat) * H) := by exact_mod_cast hcnt_le
    have hφ_split : φ_ev = (1 / 2 : ℝ) ^ ((15 + cDepthNat) * H) * (1 / 2 : ℝ) ^ H := by
      change (1 / 2 : ℝ) ^ ((16 + cDepthNat) * H) = _
      have : (16 + cDepthNat) * H = (15 + cDepthNat) * H + H := by ring
      rw [this, pow_add]
    calc ((2 * D₀ + 20 * D ^ 2 + 2 : ℕ) : ℝ) * (2 * φ_ev) * (S : ℝ)
        = (((2 * D₀ + 20 * D ^ 2 + 2 : ℕ) : ℝ) * 2 * (S : ℝ)) *
            (1 / 2 : ℝ) ^ ((15 + cDepthNat) * H) * (1 / 2 : ℝ) ^ H := by
          rw [hφ_split]; ring
      _ ≤ (2 : ℝ) ^ ((15 + cDepthNat) * H) *
            (1 / 2 : ℝ) ^ ((15 + cDepthNat) * H) * (1 / 2 : ℝ) ^ H := by gcongr
      _ = (1 / 2 : ℝ) ^ H := by rw [← mul_pow]; norm_num
      _ ≤ δ := hδ_lb
  exact ⟨hφ_pos, hφ_lt, hlog_φ, hN_prob, hK0_prob, hstep_prob⟩

lemma pow_mul_pow_le {D H a b A B : ℕ} (hD : 1 ≤ D) (hH : 1 ≤ H) (ha : a ≤ A) (hb : b ≤ B) :
    D ^ a * H ^ b ≤ D ^ A * H ^ B :=
  Nat.mul_le_mul (Nat.pow_le_pow_right hD ha) (Nat.pow_le_pow_right hH hb)

end UL.Proof.lem_7_2.RaceV30
