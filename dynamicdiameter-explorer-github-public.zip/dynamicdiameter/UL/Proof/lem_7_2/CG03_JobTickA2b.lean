import UL.Proof.lem_7_2.CG03_JobTickA2a2

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

theorem exec_popScopeZero {d : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory) :
    DetExecAt 0 inp (.localScope .skip) mem (mem.popDepth 0) 1 := by
  have h := DetExecAt.localScope (fd := 0) (DetExecAt.skip 1 inp (mem.popDepth 0))
  rwa [popDepth_zero_idem] at h

/-! ### 1. Multi-Level Update Propagation Across Job Levels (`propagateAllJobLevelsStmt`) -/

def LevelUsedSlots (mem : ArithRAMMemory) (idx : ℕ) (spLive : Bool) : Finset ℕ :=
  insert (wRead mem 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat (jobLevelLiveSlots mem idx spLive)

lemma mem_levelUsedSlots_of_enc {mem : ArithRAMMemory} {idx : ℕ} {spLive : Bool} {s : ℕ}
    (hs : s ∈ jobLevelSlotSet mem idx)
    (hnot_dead : spLive = false → s ≠ (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat) :
    s ∈ LevelUsedSlots mem idx spLive := by
  unfold jobLevelSlotSet at hs
  unfold LevelUsedSlots jobLevelLiveSlots
  simp only [Finset.mem_insert, Finset.mem_singleton] at hs ⊢
  rcases hs with rfl | hrest
  · exact Or.inl rfl
  · right
    cases spLive with
    | true =>
        simp only [↓reduceIte, Finset.mem_insert, Finset.mem_singleton]
        rcases hrest with rfl | rfl | rfl | rfl
        · exact Or.inr (Or.inl rfl)
        · exact Or.inr (Or.inr (Or.inl rfl))
        · exact Or.inr (Or.inr (Or.inr rfl))
        · exact Or.inl rfl
    | false =>
        simp only [Bool.false_eq_true, ↓reduceIte, Finset.mem_insert, Finset.mem_singleton]
        rcases hrest with rfl | rfl | rfl | h6
        · exact Or.inl rfl
        · exact Or.inr (Or.inl rfl)
        · exact Or.inr (Or.inr rfl)
        · exact False.elim (hnot_dead rfl h6)

def propagateOneJobLevelIterStmt (d D₀ K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    .ite (.intLt (.readHeap 26 (.lit 16)) (.readHeap 19 (.readHeap 26 (.lit 15))))
      (seqList [
        boxWriteW M_box 26 (.lit 7)
          (.add (.mul (.readHeap 26 (.lit 15)) (.lit (D₀ : ℤ))) (.readHeap 26 (.lit 16))),
        propagateJobLevelStmt d K M_box
      ])
      .skip,
    boxWriteW M_box 26 (.lit 16) (.add (.readHeap 26 (.lit 16)) (.lit 1))
  ]

def propagateAllJobLevelsStmt (d D₀ K M_box : ℕ) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 26 (.lit 4) (.readHeap 26 (.lit 13)),
    boxWriteW M_box 26 (.lit 5) (.readHeap 26 (.lit 14)),
    boxWriteW M_box 26 (.lit 8) (.lit 1),
    boxWriteW M_box 26 (.lit 16) (.lit 0),
    .repeatN (.lit (D₀ : ℤ)) (propagateOneJobLevelIterStmt d D₀ K M_box),
    .localScope .skip
  ]

theorem boxSafe_propagateAllJobLevelsStmt {T_max M_box : ℕ} (hT : 28 ≤ T_max) (d D₀ K : ℕ) :
    BoxSafeOuter T_max M_box (propagateAllJobLevelsStmt d D₀ K M_box) := by
  unfold propagateAllJobLevelsStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · refine .repeatN _ (boxSafeOuter_seqList ?_)
    intro s' hs'; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl
    · refine .ite _ (boxSafeOuter_seqList ?_) .skip
      intro s2 hs2; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs2
      rcases hs2 with rfl | rfl
      · exact .boxW (by omega) _ _
      · exact boxSafe_propagateJobLevelStmt hT d K
    · exact .boxW (by omega) _ _
  · exact .localScope .skip

def propagateAllJobLevelsCost (d D₀ K : ℕ) : ℕ :=
  D₀ * ((1100 * (K + 1) + 150 * (d + 1) + 800) + 100) + 150

private def StepInputRel (ins : Bool) (opH : ℕ) (T_pre T_post : Finset ℕ) (passF : Bool) : Prop :=
  if ins then
    opH ∉ T_pre ∧ T_post = (if passF then insert opH T_pre else T_pre)
  else
    passF = true ∧ T_post = T_pre.erase opH

private lemma stepInputRel_card_and_filter {ins : Bool} {opH : ℕ} {T_pre T_post : Finset ℕ} {passF : Bool}
    (hrel : StepInputRel ins opH T_pre T_post passF) :
    T_post.card ≤ T_pre.card + 1 ∧
    ∀ c : ℕ, (T_post.filter (fun x => c ≤ x)).card ≤ (T_pre.filter (fun x => c ≤ x)).card + 1 := by
  unfold StepInputRel at hrel
  cases ins with
  | true =>
      simp only [↓reduceIte] at hrel
      rcases hrel with ⟨_, rfl⟩
      cases passF with
      | true =>
          simp only [↓reduceIte]
          exact ⟨Finset.card_insert_le opH T_pre, fun c => card_filter_ge_insert_le T_pre opH c⟩
      | false =>
          simp only [Bool.false_eq_true, ↓reduceIte]
          exact ⟨by omega, fun _ => by omega⟩
  | false =>
      simp only [Bool.false_eq_true, ↓reduceIte] at hrel
      rcases hrel with ⟨_, rfl⟩
      exact ⟨(Finset.card_erase_le).trans (by omega),
             fun c => (card_filter_ge_erase_le T_pre opH c).trans (by omega)⟩

theorem exec_propagateAllJobLevelsStmt {d n D D₀ K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {r jLen opH : ℕ} {ins : Bool}
    {S_r_pre S_r_post activeH activeH' : Finset ℕ}
    {livePts livePts' : ℕ → EuclideanSpace ℝ (Fin d)}
    (lvs : List (JobLvData d))
    (spLive : ℕ → Bool)
    (hjLen_eq : lvs.length = jLen)
    (hjLen_pos : 1 ≤ jLen) (hjLen_le : jLen ≤ D₀)
    (hopH_K : opH < 2 ^ K)
    (hBox26 : 30 ≤ M_box)
    (hMs : NumSlots * 2 ^ (K + 1) ≤ M_box)
    (hr_reg : wRead mem 26 15 = (r : ℤ))
    (hopH_reg : wRead mem 26 13 = (opH : ℤ))
    (hins_reg : wRead mem 26 14 = (if ins then 1 else 0))
    (hjLen_reg : wRead mem 19 (r : ℤ) = (jLen : ℤ))
    (hLive' : EncLiveCoords d n mem activeH' livePts')
    (hh_act : ins = true → opH ∈ activeH')
    (hchg_ins : ins = true → opH ∉ S_r_pre ∧ S_r_post = insert opH S_r_pre)
    (hchg_del : ins = false → S_r_post = S_r_pre.erase opH)
    (hlive_other : ∀ x ∈ S_r_pre, x ≠ opH → livePts' x = livePts x)
    (hSlot_post : ∀ (j : ℕ) (hj : j < lvs.length) (bS : ℕ), bS < NumSlots → 1 ≤ wRead mem 6 (bS : ℤ) →
      EncSlotCoords d n mem activeH livePts bS (lvs[j]'hj).S_birth (lvs[j]'hj).snapPts →
      EncSlotCoords d n mem activeH' livePts' bS (lvs[j]'hj).S_birth (lvs[j]'hj).snapPts)
    (hseg : SegGenBound K NumSlots mem)
    (hEnc_init : ∀ (j : ℕ) (hj : j < lvs.length),
      EncJobLevel d n D K NumSlots mem activeH livePts (r * D₀ + j)
        (lvs[j]'hj).S_birth (lvs[j]'hj).snapPts (lvs[j]'hj).prov
        (jobHandleInput D livePts lvs S_r_pre j) (spLive j))
    (hph2_prefix : ∀ j < jLen - 1, wRead mem 24 (((2 * (r * D₀ + j) + 0 : ℕ) : ℤ)) = 2)
    (hlv_disj : ∀ i₁ < jLen, ∀ i₂ < jLen, i₁ ≠ i₂ →
      ∀ s ∈ LevelUsedSlots mem (r * D₀ + i₂) (spLive i₂),
        s ∉ jobLevelSlotSet mem (r * D₀ + i₁) ∨
        (spLive i₁ = false ∧ s = (wRead mem 23 (((8 * (r * D₀ + i₁) + 6 : ℕ) : ℤ))).toNat)) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (propagateAllJobLevelsStmt d D₀ K M_box) mem m'
        (propagateAllJobLevelsCost d D₀ K) ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      (∀ (j : ℕ) (hj : j < lvs.length),
        EncJobLevel d n D K NumSlots m' activeH' livePts' (r * D₀ + j)
          (lvs[j]'hj).S_birth (lvs[j]'hj).snapPts (lvs[j]'hj).prov
          (jobHandleInput D livePts' lvs S_r_post j) (spLive j)) ∧
      ((jobHandleInput D livePts' lvs S_r_post (jLen - 1)).card ≤
         (jobHandleInput D livePts lvs S_r_pre (jLen - 1)).card + 1 ∧
       ∀ c : ℕ,
         ((jobHandleInput D livePts' lvs S_r_post (jLen - 1)).filter (fun x => c ≤ x)).card ≤
           ((jobHandleInput D livePts lvs S_r_pre (jLen - 1)).filter (fun x => c ≤ x)).card + 1) ∧
      (∀ s' < NumSlots,
        (∀ j < jLen, s' ∉ jobLevelSlotSet mem (r * D₀ + j) ∨
          (spLive j = false ∧ s' = (wRead mem 23 (((8 * (r * D₀ + j) + 6 : ℕ) : ℤ))).toNat)) →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 3 → i ≠ 4 → i ≠ 5 → i ≠ 6 → i ≠ 7 → i ≠ 8 → i ≠ 16 →
        wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t, t ≠ 8 → t ≠ 26 → ∀ i, rRead m' t i = rRead mem t i) := by
  let m1 := wWrite mem 26 4 (opH : ℤ)
  let m2 := wWrite m1 26 5 (if ins then 1 else 0)
  let m3 := wWrite m2 26 8 1
  let m4 := wWrite m3 26 16 0
  have hd1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 4) (.readHeap 26 (.lit 13))) mem m1 16 :=
    exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) (by simp [hopH_reg]) (by simp [intExprOps])
  have hd2 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 5) (.readHeap 26 (.lit 14))) m1 m2 16 :=
    exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) (by simp [m1, hins_reg]) (by simp [intExprOps])
  have hd3 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 8) (.lit 1)) m2 m3 14 :=
    exec_boxWriteW inp m2 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hd4 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 16) (.lit 0)) m3 m4 14 :=
    exec_boxWriteW inp m3 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  let T_pre : ℕ → Finset ℕ := fun j => jobHandleInput D livePts lvs S_r_pre j
  let T_post : ℕ → Finset ℕ := fun j => jobHandleInput D livePts' lvs S_r_post j
  let Inv : ℕ → ArithRAMMemory → Prop := fun j m =>
    SegGenBound K NumSlots m ∧
    wRead m 26 4 = (opH : ℤ) ∧
    wRead m 26 5 = (if ins then 1 else 0) ∧
    wRead m 26 16 = (j : ℤ) ∧
    (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ i, wRead m t i = wRead mem t i) ∧
    (∀ i, i ≠ 3 → i ≠ 4 → i ≠ 5 → i ≠ 6 → i ≠ 7 → i ≠ 8 → i ≠ 16 → wRead m 26 i = wRead mem 26 i) ∧
    (∀ t, t ≠ 8 → t ≠ 26 → ∀ i, rRead m t i = rRead mem t i) ∧
    (∀ (i : ℕ) (hi : i < lvs.length),
      if i < j then
        EncJobLevel d n D K NumSlots m activeH' livePts' (r * D₀ + i)
          (lvs[i]'hi).S_birth (lvs[i]'hi).snapPts (lvs[i]'hi).prov (T_post i) (spLive i)
      else
        EncJobLevel d n D K NumSlots m activeH livePts (r * D₀ + i)
          (lvs[i]'hi).S_birth (lvs[i]'hi).snapPts (lvs[i]'hi).prov (T_pre i) (spLive i)) ∧
    (j < jLen → ∃ passF : Bool,
      wRead m 26 8 = (if passF then 1 else 0) ∧
      StepInputRel ins opH (T_pre j) (T_post j) passF) ∧
    (jLen ≤ j →
      (T_post (jLen - 1)).card ≤ (T_pre (jLen - 1)).card + 1 ∧
      ∀ c : ℕ, ((T_post (jLen - 1)).filter (fun x => c ≤ x)).card ≤
               ((T_pre (jLen - 1)).filter (fun x => c ≤ x)).card + 1) ∧
    (∀ s' < NumSlots,
      (∀ i < min j jLen, s' ∉ jobLevelSlotSet mem (r * D₀ + i) ∨
        (spLive i = false ∧ s' = (wRead mem 23 (((8 * (r * D₀ + i) + 6 : ℕ) : ℤ))).toNat)) →
      ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m s' S₁ fSq₁)
  have hInv0 : Inv 0 m4 := by
    refine ⟨?_, by simp [m4, m3, m2, m1], by simp [m4, m3, m2], by simp [m4],
      fun t _ _ _ h26 i => by simp [m4, m3, m2, m1, h26],
      fun i _ h4 h5 _ _ h8 h16 => by simp [m4, m3, m2, m1, h4, h5, h8, h16],
      fun _ _ _ _ => by simp [m4, m3, m2, m1], ?_, ?_, fun hle => by omega, ?_⟩
    · exact ⟨by simp [m4, m3, m2, m1]; exact hseg.1,
             fun s hs => by simp [m4, m3, m2, m1]; exact hseg.2.1 s hs,
             fun s hs u hu => by simp [m4, m3, m2, m1]; exact hseg.2.2 s hs u hu⟩
    · intro i hi
      simp only [Nat.not_lt_zero, ↓reduceIte]
      exact (hEnc_init i hi).frame (fun _ _ => rfl)
        (fun _ _ _ _ S₁ fSq₁ _ hE => hE.congr_mem_fSq (by simp [m4, m3, m2, m1])
          (fun _ _ => by simp [m4, m3, m2, m1]) (fun _ _ => by simp [m4, m3, m2, m1])
          (fun _ _ => by simp [m4, m3, m2, m1]) (fun _ _ => by simp [m4, m3, m2, m1]) (fun _ _ => rfl))
        (fun _ _ => by simp [m4, m3, m2, m1])
        (fun _ _ _ hC => hC.congr_mem3 (by simp [m4, m3, m2, m1]) (fun _ => by simp [m4, m3, m2, m1]) (fun _ => by simp [m4, m3, m2, m1]))
        (fun _ _ => by simp [m4, m3, m2, m1])
        (fun _ _ => by simp [m4, m3, m2, m1])
        (fun _ => by simp [m4, m3, m2, m1])
        (fun _ _ => by simp [m4, m3, m2, m1])
    · intro _
      refine ⟨true, by simp [m4, m3], ?_⟩
      unfold StepInputRel
      dsimp only [T_pre, T_post, jobHandleInput_zero]
      cases ins with
      | true =>
          rcases hchg_ins rfl with ⟨hnot, hpost⟩
          simp [hnot, hpost]
      | false =>
          simp [hchg_del rfl]
    · intro s' _ _ S₁ fSq₁ hE
      exact hE.congr_mem_fSq (by simp [m4, m3, m2, m1]) (fun _ _ => by simp [m4, m3, m2, m1])
        (fun _ _ => by simp [m4, m3, m2, m1]) (fun _ _ => by simp [m4, m3, m2, m1])
        (fun _ _ => by simp [m4, m3, m2, m1]) (fun _ _ => rfl)
  have hStep : ∀ j < D₀, ∀ m, Inv j m →
      ∃ m', DetExecAt 0 inp (propagateOneJobLevelIterStmt d D₀ K M_box) m m'
        ((1100 * (K + 1) + 150 * (d + 1) + 800) + 100) ∧ Inv (j + 1) m' := by
    intro j _ m ⟨hseg_m, hw4_m, hw5_m, hw16_m, hwo_m, hw26_m, hro_m, hEnc_m, hRel_m, hDone_m, hSegOut_m⟩
    have hw15_m : wRead m 26 15 = (r : ℤ) := by
      rw [hw26_m 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hr_reg]
    have hw19_m : wRead m 19 (r : ℤ) = (jLen : ℤ) := by
      rw [hwo_m 19 (by decide) (by decide) (by decide) (by decide), hjLen_reg]
    by_cases hj_lt : j < jLen
    · have hj_len : j < lvs.length := hjLen_eq ▸ hj_lt
      have hcond : cValAt 0 inp m (.intLt (.readHeap 26 (.lit 16)) (.readHeap 19 (.readHeap 26 (.lit 15)))) = true := by
        simp [hw16_m, hw15_m, hw19_m, hj_lt]
      rcases hRel_m hj_lt with ⟨passF, hw8_m, hrel_j⟩
      let idx := r * D₀ + j
      let ma := wWrite m 26 7 (idx : ℤ)
      have hda : DetExecAt 0 inp
          (boxWriteW M_box 26 (.lit 7)
            (.add (.mul (.readHeap 26 (.lit 15)) (.lit (D₀ : ℤ))) (.readHeap 26 (.lit 16))))
          m ma 24 := by
        refine exec_boxWriteW inp m _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
        simp only [iValAt_add, iValAt_mul, iValAt_readHeap, iValAt_lit, hw15_m, hw16_m, idx]
        push_cast; rfl
      have hseg_ma : SegGenBound K NumSlots ma :=
        ⟨by simp [ma]; exact hseg_m.1,
         fun s hs => by simp [ma]; exact hseg_m.2.1 s hs,
         fun s hs u hu => by simp [ma]; exact hseg_m.2.2 s hs u hu⟩
      have hLive'_ma : EncLiveCoords d n ma activeH' livePts' :=
        ⟨hLive'.1, fun h hh c => by simp only [ma, rRead_wWrite]; rw [hro_m 4 (by decide) (by decide)]; exact hLive'.2 h hh c⟩
      have hEnc_j_m : EncJobLevel d n D K NumSlots m activeH livePts idx
          (lvs[j]'hj_len).S_birth (lvs[j]'hj_len).snapPts (lvs[j]'hj_len).prov (T_pre j) (spLive j) := by
        have h := hEnc_m j hj_len
        simp only [lt_irrefl, ↓reduceIte] at h
        exact h
      have hEnc_j_ma : EncJobLevel d n D K NumSlots ma activeH livePts idx
          (lvs[j]'hj_len).S_birth (lvs[j]'hj_len).snapPts (lvs[j]'hj_len).prov (T_pre j) (spLive j) :=
        hEnc_j_m.frame (fun _ _ => rfl)
          (fun _ _ _ _ S₁ fSq₁ _ hE => hE.congr_mem_fSq (by simp [ma]) (fun _ _ => by simp [ma])
            (fun _ _ => by simp [ma]) (fun _ _ => by simp [ma]) (fun _ _ => by simp [ma]) (fun _ _ => rfl))
          (fun _ _ => by simp [ma])
          (fun _ _ _ hC => hC.congr_mem3 (by simp [ma]) (fun _ => by simp [ma]) (fun _ => by simp [ma]))
          (fun _ _ => by simp [ma]) (fun _ _ => by simp [ma])
          (fun _ => by simp [ma]) (fun _ _ => by simp [ma])
      have hins_pf : ins = false → passF = true := by
        intro hf; unfold StepInputRel at hrel_j; simp [hf] at hrel_j; exact hrel_j.1
      have hnot_in_j : ins = true → opH ∉ T_pre j := by
        intro ht; unfold StepInputRel at hrel_j; simp [ht] at hrel_j; exact hrel_j.1
      have hlive_other_j : ∀ x ∈ T_pre j, x ≠ opH → livePts' x = livePts x :=
        fun x hx hne => hlive_other x (jobHandleInput_subset D livePts lvs S_r_pre j hx) hne
      have hSlot_ma : ∀ bS < NumSlots, 1 ≤ wRead ma 6 (bS : ℤ) →
          EncSlotCoords d n ma activeH livePts bS (lvs[j]'hj_len).S_birth (lvs[j]'hj_len).snapPts →
          EncSlotCoords d n ma activeH' livePts' bS (lvs[j]'hj_len).S_birth (lvs[j]'hj_len).snapPts := by
        intro bS hbS h6 hC
        have h6_mem : 1 ≤ wRead mem 6 (bS : ℤ) := by
          dsimp only [ma] at h6
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              hwo_m 6 (by decide) (by decide) (by decide) (by decide)] at h6
          exact h6
        have hC_mem : EncSlotCoords d n mem activeH livePts bS (lvs[j]'hj_len).S_birth (lvs[j]'hj_len).snapPts :=
          hC.congr_mem
            (by simp [ma, hwo_m 6 (by decide) (by decide) (by decide) (by decide)])
            (fun i => by simp [ma, hwo_m 11 (by decide) (by decide) (by decide) (by decide)])
            (fun i => by simp [ma, hro_m 11 (by decide) (by decide)])
        exact (hSlot_post j hj_len bS hbS h6_mem hC_mem).congr_mem
          (by simp [ma, hwo_m 6 (by decide) (by decide) (by decide) (by decide)])
          (fun i => by simp [ma, hwo_m 11 (by decide) (by decide) (by decide) (by decide)])
          (fun i => by simp [ma, hro_m 11 (by decide) (by decide)])
      rcases exec_propagateJobLevelStmt inp ma hopH_K hBox26 hMs
          (by simp [ma, hw4_m]) (by simp [ma, hw5_m]) (by simp [ma]) (by simp [ma, hw8_m])
          hins_pf hLive'_ma hh_act hnot_in_j hlive_other_j hSlot_ma hseg_ma hEnc_j_ma
        with ⟨mb, passOut, hdb, _, hseg_mb, hEnc_j_mb, hw8_mb, hpf_out, hres_mb,
              hSegFr_mb, hDead_mb, hwo_mb, hw26_mb, hro_mb⟩
      have hSpar'_eq :
          (if passF then (if ins then insert opH (T_pre j) else (T_pre j).erase opH) else T_pre j) = T_post j := by
        unfold StepInputRel at hrel_j
        cases ins with
        | true =>
            simp only [↓reduceIte] at hrel_j ⊢
            exact hrel_j.2.symm
        | false =>
            simp only [Bool.false_eq_true, ↓reduceIte] at hrel_j ⊢
            rw [hrel_j.1]; simp [hrel_j.2]
      rw [hSpar'_eq] at hEnc_j_mb hres_mb
      have hslot_eq_ma : jobLevelSlotSet ma idx = jobLevelSlotSet mem idx := by
        unfold jobLevelSlotSet
        simp [ma, hwo_m 23 (by decide) (by decide) (by decide) (by decide)]
      have hw23_6_ma : wRead ma 23 (((8 * idx + 6 : ℕ) : ℤ)) = wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ)) := by
        simp [ma, hwo_m 23 (by decide) (by decide) (by decide) (by decide)]
      let mc := wWrite mb 26 16 (((j + 1 : ℕ) : ℤ))
      have hdc : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 16) (.add (.readHeap 26 (.lit 16)) (.lit 1))) mb mc 20 := by
        refine exec_boxWriteW inp mb _ _ rfl (by omega) (by omega) ?_ (by simp [intExprOps])
        have h16 : wRead mb 26 16 = (j : ℤ) := by
          rw [hw26_mb 16 (by decide) (by decide) (by decide)]; simp [ma, hw16_m]
        simp [h16]
      have hd_iter : DetExecAt 0 inp (propagateOneJobLevelIterStmt d D₀ K M_box) m mc
          ((1100 * (K + 1) + 150 * (d + 1) + 800) + 100) := by
        unfold propagateOneJobLevelIterStmt seqList
        exact ((DetExecAt.ite_true hcond (C_c := 15) (by simp [condExprOps, intExprOps])
          (hda.seq hdb)).seq hdc).mono_cost (by omega)
      refine ⟨mc, hd_iter,
        ⟨by simp [mc]; exact hseg_mb.1,
         fun s hs => by simp [mc]; exact hseg_mb.2.1 s hs,
         fun s hs u hu => by simp [mc]; exact hseg_mb.2.2 s hs u hu⟩,
        by simp [mc, hw26_mb 4 (by decide) (by decide) (by decide), ma, hw4_m],
        by simp [mc, hw26_mb 5 (by decide) (by decide) (by decide), ma, hw5_m],
        by simp [mc],
        fun t h8 h9 h10 h26 i => by simp [mc, h26, hwo_mb t h8 h9 h10 h26, ma, hwo_m t h8 h9 h10 h26],
        fun i h3 h4 h5 h6 h7 h8 h16 => by
          simp [mc, h16, hw26_mb i h3 h6 h8, ma, h7, hw26_m i h3 h4 h5 h6 h7 h8 h16],
        fun t h8 h26 i => by simp [mc, hro_mb t h8 h26, ma, hro_m t h8 h26],
        ?_, ?_, ?_, ?_⟩
      · intro i hi
        by_cases hi_eq : i = j
        · subst hi_eq
          simp only [Nat.lt_succ_self, ↓reduceIte]
          exact hEnc_j_mb.frame (fun _ _ => rfl)
            (fun _ _ _ _ S₁ fSq₁ _ hE => hE.congr_mem_fSq (by simp [mc]) (fun _ _ => by simp [mc])
              (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => rfl))
            (fun _ _ => by simp [mc])
            (fun _ _ _ hC => hC.congr_mem3 (by simp [mc]) (fun _ => by simp [mc]) (fun _ => by simp [mc]))
            (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc])
            (fun _ => by simp [mc]) (fun _ _ => by simp [mc])
        · have hiff : (i < j + 1) ↔ (i < j) := by omega
          simp only [hiff]
          have h_prev := hEnc_m i hi
          have hi_lt_jLen : i < jLen := hjLen_eq ▸ hi
          have h_preserve_slot : ∀ s ∈ jobLevelSlotSet m (r * D₀ + i), s < NumSlots →
              (spLive i = false → s = (wRead m 23 (((8 * (r * D₀ + i) + 6 : ℕ) : ℤ))).toNat → True) →
              ∀ S₁ fSq₁,
                (spLive i = false → s ≠ (wRead m 23 (((8 * (r * D₀ + i) + 6 : ℕ) : ℤ))).toNat) →
                EncSegSlot K m s S₁ fSq₁ → EncSegSlot K mc s S₁ fSq₁ := by
            intro s hs_m hs_lt _ S₁ fSq₁ hnot_dead hE_m
            have h23_eq : jobLevelSlotSet m (r * D₀ + i) = jobLevelSlotSet mem (r * D₀ + i) := by
              unfold jobLevelSlotSet
              simp [hwo_m 23 (by decide) (by decide) (by decide) (by decide)]
            have hw23_6_i : wRead m 23 (((8 * (r * D₀ + i) + 6 : ℕ) : ℤ)) =
                wRead mem 23 (((8 * (r * D₀ + i) + 6 : ℕ) : ℤ)) :=
              hwo_m 23 (by decide) (by decide) (by decide) (by decide) _
            rw [h23_eq] at hs_m
            rw [hw23_6_i] at hnot_dead
            have hs_used : s ∈ LevelUsedSlots mem (r * D₀ + i) (spLive i) :=
              mem_levelUsedSlots_of_enc hs_m hnot_dead
            have hE_ma : EncSegSlot K ma s S₁ fSq₁ :=
              hE_m.congr_mem_fSq (by simp [ma]) (fun _ _ => by simp [ma]) (fun _ _ => by simp [ma])
                (fun _ _ => by simp [ma]) (fun _ _ => by simp [ma]) (fun _ _ => rfl)
            have hE_mb : EncSegSlot K mb s S₁ fSq₁ := by
              rcases hlv_disj j hj_lt i hi_lt_jLen (Ne.symm hi_eq) s hs_used with hnot_j | ⟨hdead_j, hs_eq6⟩
              · exact hSegFr_mb s hs_lt (by rwa [hslot_eq_ma]) S₁ fSq₁ hE_ma
              · rw [hs_eq6, ← hw23_6_ma] at hE_ma ⊢
                exact hDead_mb hdead_j S₁ fSq₁ hE_ma
            exact hE_mb.congr_mem_fSq (by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc])
              (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => rfl)
          split_ifs at h_prev ⊢
          · exact h_prev.frame (fun _ _ => rfl) h_preserve_slot
              (fun _ _ => by simp [mc, hwo_mb 6 (by decide) (by decide) (by decide) (by decide), ma])
              (fun _ _ _ hC => hC.congr_mem
                (by simp [mc, hwo_mb 6 (by decide) (by decide) (by decide) (by decide), ma])
                (fun _ => by simp [mc, hwo_mb 11 (by decide) (by decide) (by decide) (by decide), ma])
                (fun _ => by simp [mc, hro_mb 11 (by decide) (by decide), ma]))
              (fun _ _ => by simp [mc, hwo_mb 23 (by decide) (by decide) (by decide) (by decide), ma])
              (fun _ _ => by simp [mc, hwo_mb 24 (by decide) (by decide) (by decide) (by decide), ma])
              (fun _ => by simp [mc, hro_mb 23 (by decide) (by decide), ma])
              (fun _ _ => by simp [mc, hro_mb 24 (by decide) (by decide), ma])
          · exact h_prev.frame (fun _ _ => rfl) h_preserve_slot
              (fun _ _ => by simp [mc, hwo_mb 6 (by decide) (by decide) (by decide) (by decide), ma])
              (fun _ _ _ hC => hC.congr_mem
                (by simp [mc, hwo_mb 6 (by decide) (by decide) (by decide) (by decide), ma])
                (fun _ => by simp [mc, hwo_mb 11 (by decide) (by decide) (by decide) (by decide), ma])
                (fun _ => by simp [mc, hro_mb 11 (by decide) (by decide), ma]))
              (fun _ _ => by simp [mc, hwo_mb 23 (by decide) (by decide) (by decide) (by decide), ma])
              (fun _ _ => by simp [mc, hwo_mb 24 (by decide) (by decide) (by decide) (by decide), ma])
              (fun _ => by simp [mc, hro_mb 23 (by decide) (by decide), ma])
              (fun _ _ => by simp [mc, hro_mb 24 (by decide) (by decide), ma])
      · intro hj1_lt
        refine ⟨passOut, by simp [mc, hw8_mb], ?_⟩
        have hj_lt_sub1 : j < jLen - 1 := by omega
        have hph2_ma : wRead ma 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2 := by
          dsimp only [ma, idx]
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              hwo_m 24 (by decide) (by decide) (by decide) (by decide)]
          exact hph2_prefix j hj_lt_sub1
        have hTp_pre : T_pre (j + 1) = ((lvs[j]'hj_len).ball D).residual livePts (T_pre j) :=
          jobHandleInput_succ D livePts lvs S_r_pre hj_len
        have hTp_post : T_post (j + 1) = ((lvs[j]'hj_len).ball D).residual livePts' (T_post j) :=
          jobHandleInput_succ D livePts' lvs S_r_post hj_len
        unfold StepInputRel
        cases hins_c : ins with
        | true =>
            simp only [↓reduceIte]
            rcases hchg_ins hins_c with ⟨hnot_root, _⟩
            refine ⟨fun hm => hnot_root (jobHandleInput_subset D livePts lvs S_r_pre (j + 1) hm), ?_⟩
            rw [hTp_post, hTp_pre]
            exact hres_mb hins_c hph2_ma
        | false =>
            simp only [Bool.false_eq_true, ↓reduceIte]
            have hpo := hpf_out hins_c
            refine ⟨hpo, ?_⟩
            unfold StepInputRel at hrel_j
            simp only [hins_c, Bool.false_eq_true, ↓reduceIte] at hrel_j
            rw [hTp_post, hrel_j.2, hTp_pre]
            exact nodeResidual_erase_congr ((lvs[j]'hj_len).ball D) (T_pre j) opH hlive_other_j
      · intro hj1_ge
        have hj_eq : j = jLen - 1 := by omega
        subst hj_eq
        exact stepInputRel_card_and_filter hrel_j
      · intro s' hs' hdisj S₁ fSq₁ hE0
        have hmin_le : min j jLen ≤ min (j + 1) jLen := by omega
        have hE_m := hSegOut_m s' hs' (fun i hi => hdisj i (lt_of_lt_of_le hi hmin_le)) S₁ fSq₁ hE0
        have hE_ma : EncSegSlot K ma s' S₁ fSq₁ :=
          hE_m.congr_mem_fSq (by simp [ma]) (fun _ _ => by simp [ma]) (fun _ _ => by simp [ma])
            (fun _ _ => by simp [ma]) (fun _ _ => by simp [ma]) (fun _ _ => rfl)
        have hj_min : j < min (j + 1) jLen := by omega
        have hE_mb : EncSegSlot K mb s' S₁ fSq₁ := by
          rcases hdisj j hj_min with hnot_j | ⟨hdead_j, hs_eq6⟩
          · exact hSegFr_mb s' hs' (by rwa [hslot_eq_ma]) S₁ fSq₁ hE_ma
          · rw [hs_eq6, ← hw23_6_ma] at hE_ma ⊢
            exact hDead_mb hdead_j S₁ fSq₁ hE_ma
        exact hE_mb.congr_mem_fSq (by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc])
          (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => rfl)
    · have hcond : cValAt 0 inp m (.intLt (.readHeap 26 (.lit 16)) (.readHeap 19 (.readHeap 26 (.lit 15)))) = false := by
        simp [hw16_m, hw15_m, hw19_m]; omega
      let mc := wWrite m 26 16 (((j + 1 : ℕ) : ℤ))
      have hdc : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 16) (.add (.readHeap 26 (.lit 16)) (.lit 1))) m mc 20 :=
        exec_boxWriteW inp m _ _ rfl (by omega) (by omega) (by simp [hw16_m]) (by simp [intExprOps])
      have hd_iter : DetExecAt 0 inp (propagateOneJobLevelIterStmt d D₀ K M_box) m mc
          ((1100 * (K + 1) + 150 * (d + 1) + 800) + 100) := by
        unfold propagateOneJobLevelIterStmt seqList
        exact ((DetExecAt.ite_false hcond (C_c := 15) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp m)).seq hdc).mono_cost (by omega)
      have hj_ge : jLen ≤ j := by omega
      have hmin_eq : min (j + 1) jLen = min j jLen := by omega
      refine ⟨mc, hd_iter,
        ⟨by simp [mc]; exact hseg_m.1,
         fun s hs => by simp [mc]; exact hseg_m.2.1 s hs,
         fun s hs u hu => by simp [mc]; exact hseg_m.2.2 s hs u hu⟩,
        by simp [mc, hw4_m], by simp [mc, hw5_m], by simp [mc],
        fun t h8 h9 h10 h26 i => by simp [mc, h26, hwo_m t h8 h9 h10 h26],
        fun i h3 h4 h5 h6 h7 h8 h16 => by simp [mc, h16, hw26_m i h3 h4 h5 h6 h7 h8 h16],
        fun t h8 h26 i => by simp [mc, hro_m t h8 h26],
        ?_, fun hlt => by omega, fun _ => hDone_m hj_ge, ?_⟩
      · intro i hi
        have hlt1 : i < j := lt_of_lt_of_le (hjLen_eq ▸ hi) hj_ge
        have hlt2 : i < j + 1 := by omega
        have hp := hEnc_m i hi
        simp only [hlt1, hlt2, ↓reduceIte] at hp ⊢
        exact hp.frame (fun _ _ => rfl)
          (fun _ _ _ _ S₁ fSq₁ _ hE => hE.congr_mem_fSq (by simp [mc]) (fun _ _ => by simp [mc])
            (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => rfl))
          (fun _ _ => by simp [mc])
          (fun _ _ _ hC => hC.congr_mem3 (by simp [mc]) (fun _ => by simp [mc]) (fun _ => by simp [mc]))
          (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc])
          (fun _ => by simp [mc]) (fun _ _ => by simp [mc])
      · intro s' hs' hdisj S₁ fSq₁ hE0
        rw [hmin_eq] at hdisj
        exact (hSegOut_m s' hs' hdisj S₁ fSq₁ hE0).congr_mem_fSq
          (by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc])
          (fun _ _ => by simp [mc]) (fun _ _ => by simp [mc]) (fun _ _ => rfl)
  rcases DetExecAt.repeatN_nat (.lit (D₀ : ℤ)) _ D₀ 1
      ((1100 * (K + 1) + 150 * (d + 1) + 800) + 100) Inv hInv0 rfl (by simp [intExprOps]) hStep
    with ⟨mD, ⟨hseg_D, _, _, _, hwo_D, hw26_D, hro_D, hEnc_D, _, hDone_D, hSegOut_D⟩, hrep⟩
  have hpop_step := exec_popScopeZero inp mD
  let m' := mD.popDepth 0
  have hex_all : DetExecAt 0 inp (propagateAllJobLevelsStmt d D₀ K M_box) mem m'
      (propagateAllJobLevelsCost d D₀ K) := by
    unfold propagateAllJobLevelsStmt seqList
    exact (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hrep.seq hpop_step))))).mono_cost
      (by unfold propagateAllJobLevelsCost; omega)
  have hmin_D : min D₀ jLen = jLen := Nat.min_eq_right hjLen_le
  refine ⟨m', hex_all, popDepth_zero_idem mD,
    ⟨by simp [m']; exact hseg_D.1,
     fun s hs => by simp [m']; exact hseg_D.2.1 s hs,
     fun s hs u hu => by simp [m']; exact hseg_D.2.2 s hs u hu⟩,
    ?_, hDone_D hjLen_le, ?_,
    fun t h8 h9 h10 h26 i => by simp [m', hwo_D t h8 h9 h10 h26],
    fun i h3 h4 h5 h6 h7 h8 h16 => by simp [m', hw26_D i h3 h4 h5 h6 h7 h8 h16],
    fun t h8 h26 i => by simp [m', hro_D t h8 h26]⟩
  · intro j hj
    have hj_lt_D0 : j < D₀ := lt_of_lt_of_le (hjLen_eq ▸ hj) hjLen_le
    have hp := hEnc_D j hj
    simp only [hj_lt_D0, ↓reduceIte] at hp
    exact hp.frame (fun _ _ => rfl)
      (fun _ _ _ _ S₁ fSq₁ _ hE => hE.congr_mem_fSq (by simp [m']) (fun _ _ => by simp [m'])
        (fun _ _ => by simp [m']) (fun _ _ => by simp [m']) (fun _ _ => by simp [m']) (fun _ _ => rfl))
      (fun _ _ => by simp [m'])
      (fun _ _ _ hC => hC.congr_mem3 (by simp [m']) (fun _ => by simp [m']) (fun _ => by simp [m']))
      (fun _ _ => by simp [m']) (fun _ _ => by simp [m'])
      (fun _ => by simp [m']) (fun _ _ => by simp [m'])
  · intro s' hs' hdisj S₁ fSq₁ hE0
    have hE_D := hSegOut_D s' hs' (by rwa [hmin_D]) S₁ fSq₁ hE0
    exact hE_D.congr_mem_fSq (by simp [m']) (fun _ _ => by simp [m'])
      (fun _ _ => by simp [m']) (fun _ _ => by simp [m'])
      (fun _ _ => by simp [m']) (fun _ _ => rfl)

end UL.Proof_lem_7_2_RacerP46
