import UL.Proof.lem_7_2.CG01_NodeSpec0a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### Stage 2b1: Slot-Disjointness & Last-to-NonLast Helpers for `openLevel` -/

lemma cg01_jobLevelLiveSlots_mono_false (m : ArithRAMMemory) (idx : ℕ) (sp : Bool) :
    jobLevelLiveSlots m idx false ⊆ jobLevelLiveSlots m idx sp := by
  intro x hx
  cases sp with
  | false => exact hx
  | true =>
      unfold jobLevelLiveSlots at hx ⊢
      simp only [Bool.false_eq_true, ↓reduceIte] at hx
      simp only [↓reduceIte]
      exact Finset.mem_insert_of_mem hx

lemma cg01_encJobLevel_last_to_nonlast {d n D K NumSlots : ℕ}
    {m₁ m₂ : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {idx spRS : ℕ} {S_birth S_parent : Finset ℕ}
    {snapPts : ℕ → EuclideanSpace ℝ (Fin d)} {prov : ChainNode d}
    (hEnc : EncJobLevel d n D K NumSlots m₁ activeH livePts idx S_birth snapPts prov S_parent true)
    (hph2 : wRead m₁ 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2)
    (hw_spRS : wRead m₁ 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ))
    (h6_spRS2 : 1 ≤ wRead m₂ 6 (spRS : ℤ))
    (hseg_pres : ∀ s ∈ jobLevelSlotSet m₁ idx, s < NumSlots → s ≠ spRS →
      ∀ S₁ fSq₁, EncSegSlot K m₁ s S₁ fSq₁ → EncSegSlot K m₂ s S₁ fSq₁)
    (hw6_pres : ∀ s ∈ jobLevelSlotSet m₁ idx, s ≠ spRS →
      wRead m₂ 6 (s : ℤ) = wRead m₁ 6 (s : ℤ))
    (hw11 : ∀ k, wRead m₂ 11 k = wRead m₁ 11 k)
    (hr11 : ∀ k, rRead m₂ 11 k = rRead m₁ 11 k)
    (hw23 : ∀ a < 8, wRead m₂ 23 (((8 * idx + a : ℕ) : ℤ)) = wRead m₁ 23 (((8 * idx + a : ℕ) : ℤ)))
    (hw24_0 : wRead m₂ 24 (((2 * idx + 0 : ℕ) : ℤ)) = wRead m₁ 24 (((2 * idx + 0 : ℕ) : ℤ)))
    (hr23 : ∀ c : Fin d, rRead m₂ 23 (((idx * d + c.val : ℕ) : ℤ)) = rRead m₁ 23 (((idx * d + c.val : ℕ) : ℤ)))
    (hr24_0 : rRead m₂ 24 (((2 * idx + 0 : ℕ) : ℤ)) = rRead m₁ 24 (((2 * idx + 0 : ℕ) : ℤ))) :
    EncJobLevel d n D K NumSlots m₂ activeH livePts idx S_birth snapPts prov S_parent false := by
  rcases hEnc with ⟨bS, dS, spDS, rS, spRS', hbS, hdS, hspDS, hrS, hspRS,
    hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
    hw2, hw3, hw4, hw5, hw6_23,
    h6_b, h6_d, h6_sd, h6_r, _,
    hb_pos, hw0, hSeg_b, hSlot_b, hr_o, hPhases⟩
  have hsp_eq : spRS' = spRS := by omega
  subst spRS'
  have hb_in : bS ∈ jobLevelSlotSet m₁ idx := by unfold jobLevelSlotSet; rw [hw2]; simp
  have hd_in : dS ∈ jobLevelSlotSet m₁ idx := by unfold jobLevelSlotSet; rw [hw3]; simp
  have hsd_in : spDS ∈ jobLevelSlotSet m₁ idx := by unfold jobLevelSlotSet; rw [hw4]; simp
  have hr_in : rS ∈ jobLevelSlotSet m₁ idx := by unfold jobLevelSlotSet; rw [hw5]; simp
  rcases hPhases with ⟨_, _, hp0, _⟩ | ⟨_, _, hp1, _⟩ | ⟨_, hrV, hEd, hEspD, hEr, _⟩
  · rw [hph2] at hp0; omega
  · rw [hph2] at hp1; omega
  · refine ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
      hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
      (hw23 2 (by decide)).trans hw2,
      (hw23 3 (by decide)).trans hw3,
      (hw23 4 (by decide)).trans hw4,
      (hw23 5 (by decide)).trans hw5,
      (hw23 6 (by decide)).trans hw6_23,
      by rw [hw6_pres bS hb_in hbspR]; exact h6_b,
      by rw [hw6_pres dS hd_in hdspR]; exact h6_d,
      by rw [hw6_pres spDS hsd_in hspDspR]; exact h6_sd,
      by rw [hw6_pres rS hr_in hrspR]; exact h6_r,
      ⟨fun h0 => by omega, fun h => by cases h⟩,
      hb_pos,
      (hw23 0 (by decide)).trans hw0,
      hseg_pres bS hb_in hbS hbspR _ _ hSeg_b,
      hSlot_b.congr_mem3 (hw6_pres bS hb_in hbspR) hw11 hr11,
      fun c => (hr23 c).trans (hr_o c),
      Or.inr (Or.inr ⟨hw24_0.trans hph2, hr24_0.trans hrV,
        hseg_pres dS hd_in hdS hdspR _ _ hEd,
        hseg_pres spDS hsd_in hspDS hspDspR _ _ hEspD,
        hseg_pres rS hr_in hrS hrspR _ _ hEr,
        fun h => by cases h⟩)⟩

theorem cg01_openLevel_slot_disj
    {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k)
    {g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩)}
    {m₁ m₂ : ArithRAMMemory}
    {lvs_h : List (JobLvData ctx.d)} (hlen_eq : lvs_h.length = g₀.lvs.length)
    {leafS spRS_last dS_n spDS_n rS_n spRS_n : ℕ}
    (pb : ActivePropBuildState ctx gFlag i hi g₀ m₁)
    (hw1_6 : wRead m₁ 1 6 = (leafS : ℤ))
    (hDisj : GlobalSlotDisj ctx.p.D₀ m₁ ctx.st₀.k leafS)
    (hlv_enc : ∀ (j : ℕ) (hj : j < lvs_h.length),
      EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₁
        ctx.P'.activeHandles ctx.P'.handleCoords (i * ctx.p.D₀ + j)
        (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
        (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) j)
        (decide (j + 1 = lvs_h.length)))
    (hw_spRS_last : wRead m₁ 23 (((8 * (i * ctx.p.D₀ + (g₀.lvs.length - 1)) + 6 : ℕ) : ℤ)) = (spRS_last : ℤ))
    (h6_spRS_m1 : wRead m₁ 6 (spRS_last : ℤ) = 0)
    (hdS_n_notU : dS_n ∉ activeSlotSet m₁ ctx.p.D₀)
    (hspDS_n_notU : spDS_n ∉ activeSlotSet m₁ ctx.p.D₀)
    (hrS_n_notU : rS_n ∉ activeSlotSet m₁ ctx.p.D₀)
    (hspRS_n_notU : spRS_n ∉ activeSlotSet m₁ ctx.p.D₀)
    (hw14_2 : ∀ r, wRead m₂ 14 r = wRead m₁ 14 r)
    (hw15_2 : ∀ r, wRead m₂ 15 r = wRead m₁ 15 r)
    (hw16_2 : ∀ r, wRead m₂ 16 r = wRead m₁ 16 r)
    (hw19_i2 : wRead m₂ 19 (i : ℤ) = (((g₀.lvs.length + 1 : ℕ) : ℤ)))
    (hw19_ne2 : ∀ r ≠ i, wRead m₂ 19 (r : ℤ) = wRead m₁ 19 (r : ℤ))
    (hw23_new2 : wRead m₂ 23 (((8 * (i * ctx.p.D₀ + g₀.lvs.length) + 2 : ℕ) : ℤ)) = (spRS_last : ℤ))
    (hlive_new : jobLevelLiveSlots m₂ (i * ctx.p.D₀ + g₀.lvs.length) true = {spRS_n, dS_n, spDS_n, rS_n})
    (hw23_old : ∀ idx ≠ i * ctx.p.D₀ + g₀.lvs.length, ∀ a < 8,
      wRead m₂ 23 (((8 * idx + a : ℕ) : ℤ)) = wRead m₁ 23 (((8 * idx + a : ℕ) : ℤ))) :
    GlobalSlotDisj ctx.p.D₀ m₂ ctx.st₀.k leafS ∧
    (∀ r < ctx.st₀.k, ∀ s ∈ snSlotSet m₁ r,
      s ≠ spRS_last ∧ s ≠ dS_n ∧ s ≠ spDS_n ∧ s ≠ rS_n ∧ s ≠ spRS_n) ∧
    (∀ r < ctx.st₀.k, wRead m₁ 16 (r : ℤ) = 1 →
      ∀ j < (wRead m₁ 19 (r : ℤ)).toNat, (r ≠ i ∨ j ≠ g₀.lvs.length - 1) →
      ∀ s ∈ jobLevelSlotSet m₁ (r * ctx.p.D₀ + j),
        s ≠ spRS_last ∧ s ≠ dS_n ∧ s ≠ spDS_n ∧ s ≠ rS_n ∧ s ≠ spRS_n) := by
  let jLen := g₀.lvs.length
  let lastIdx := i * ctx.p.D₀ + (jLen - 1)
  let newIdx := i * ctx.p.D₀ + jLen
  have hjLen_pos : 1 ≤ jLen := g₀.hlvs_pos
  have hjLen_lt_D0 : jLen < ctx.p.D₀ := by
    rw [ctx.hD0_eq]; exact g₀.lvs_length_lt ctx.hH5 ctx.hn2
  have hdS_np := not_in_activeSlotSet_props pb.hw1_5 hw1_6 hdS_n_notU
  have hspDS_np := not_in_activeSlotSet_props pb.hw1_5 hw1_6 hspDS_n_notU
  have hrS_np := not_in_activeSlotSet_props pb.hw1_5 hw1_6 hrS_n_notU
  have hspRS_np := not_in_activeSlotSet_props pb.hw1_5 hw1_6 hspRS_n_notU
  have h19_i_nat1 : (wRead m₁ 19 (i : ℤ)).toNat = jLen := by rw [pb.hw19_i]; simp [jLen]
  have hlast_in_live1 : spRS_last ∈ jobLevelLiveSlots m₁ lastIdx (decide ((jLen - 1) + 1 = jLen)) := by
    have hd_t : decide ((jLen - 1) + 1 = jLen) = true := by simp; omega
    rw [hd_t]; unfold jobLevelLiveSlots; rw [hw_spRS_last]; simp
  have hsn_ne5 : ∀ r < ctx.st₀.k, ∀ s ∈ snSlotSet m₁ r,
      s ≠ spRS_last ∧ s ≠ dS_n ∧ s ≠ spDS_n ∧ s ≠ rS_n ∧ s ≠ spRS_n := by
    intro r hr s hs
    have hdisj_sn := (hDisj.2.2.2.1 i hi pb.hw16_i (jLen - 1) (by rw [h19_i_nat1]; omega)).2 r hr
    rw [h19_i_nat1] at hdisj_sn
    exact ⟨fun heq => Finset.disjoint_right.mp hdisj_sn hs (heq ▸ hlast_in_live1),
      fun heq => hdS_np.2.2.1 r hr (heq ▸ hs),
      fun heq => hspDS_np.2.2.1 r hr (heq ▸ hs),
      fun heq => hrS_np.2.2.1 r hr (heq ▸ hs),
      fun heq => hspRS_np.2.2.1 r hr (heq ▸ hs)⟩
  have hEnc_m1_all : ∀ r < ctx.st₀.k, wRead m₁ 16 (r : ℤ) = 1 → ∀ j < (wRead m₁ 19 (r : ℤ)).toNat,
      ∃ ah lp Sb sn pr Sp,
        EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₁ ah lp
          (r * ctx.p.D₀ + j) Sb sn pr Sp (decide (j + 1 = (wRead m₁ 19 (r : ℤ)).toNat)) := by
    intro r hr h16 j hj
    rcases Nat.lt_trichotomy r i with hlt | heq_ri | hgt
    · rcases pb.hDone ⟨r, hr⟩ hlt with ⟨oj, _, _, _, hO⟩
      cases hoj : oj with
      | none => rw [hoj] at hO; change wRead m₁ 16 (r : ℤ) = 0 at hO; omega
      | some g₁ =>
          rw [hoj] at hO; rcases hO with ⟨_, _, _, hw19, lh, heq, hlv⟩
          have hj_lh : j < lh.length := by rw [heq]; rw [hw19] at hj; simpa using hj
          have hd_eq : decide (j + 1 = lh.length) = decide (j + 1 = (wRead m₁ 19 (r : ℤ)).toNat) := by
            rw [hw19, heq]; simp
          exact ⟨_, _, _, _, _, _, hd_eq ▸ (hlv j hj_lh).2.2.2.1⟩
    · subst r
      have hj_lh : j < lvs_h.length := by rw [hlen_eq]; rw [h19_i_nat1] at hj; exact hj
      have hd_eq : decide (j + 1 = lvs_h.length) = decide (j + 1 = (wRead m₁ 19 (i : ℤ)).toNat) := by
        rw [h19_i_nat1, hlen_eq]
      exact ⟨_, _, _, _, _, _, hd_eq ▸ hlv_enc j hj_lh⟩
    · have hT := (pb.hTodoGt ⟨r, hr⟩ hgt).2.2.2
      unfold EncTodoJobAt at hT
      cases hoj : ctx.st₀.ownedJob ⟨r, hr⟩ with
      | none => rw [hoj] at hT; change wRead m₁ 16 (r : ℤ) = 0 at hT; omega
      | some g₁ =>
          rw [hoj] at hT; rcases hT with ⟨_, _, _, hw19, lh, heq, hlv⟩
          have hj_lh : j < lh.length := by rw [heq]; rw [hw19] at hj; simpa using hj
          have hd_eq : decide (j + 1 = lh.length) = decide (j + 1 = (wRead m₁ 19 (r : ℤ)).toNat) := by
            rw [hw19, heq]; simp
          exact ⟨_, _, _, _, _, _, hd_eq ▸ (hlv j hj_lh).2.2.2.1⟩
  have hjob_other_ne5 : ∀ r < ctx.st₀.k, wRead m₁ 16 (r : ℤ) = 1 →
      ∀ j < (wRead m₁ 19 (r : ℤ)).toNat, (r ≠ i ∨ j ≠ jLen - 1) →
      ∀ s ∈ jobLevelSlotSet m₁ (r * ctx.p.D₀ + j),
        s ≠ spRS_last ∧ s ≠ dS_n ∧ s ≠ spDS_n ∧ s ≠ rS_n ∧ s ≠ spRS_n := by
    intro r hr h16 j hj hne s hs
    have hdisj_lv := (hDisj.2.2.2.2 r hr h16 j hj i hi pb.hw16_i (jLen - 1)
      (by rw [h19_i_nat1]; omega) hne).1
    rw [h19_i_nat1] at hdisj_lv
    rcases hEnc_m1_all r hr h16 j hj with ⟨_, _, _, _, _, _, hEnc_rj⟩
    have hnot_spRS : spRS_last ∉ jobLevelSlotSet m₁ (r * ctx.p.D₀ + j) :=
      not_mem_jobLevelSlotSet_of_live_disj hEnc_rj h6_spRS_m1
        (fun hin => Finset.disjoint_left.mp hdisj_lv hin hlast_in_live1)
    exact ⟨fun heq => hnot_spRS (heq ▸ hs),
      fun heq => hdS_np.2.2.2 r hr h16 j hj (heq ▸ hs),
      fun heq => hspDS_np.2.2.2 r hr h16 j hj (heq ▸ hs),
      fun heq => hrS_np.2.2.2 r hr h16 j hj (heq ▸ hs),
      fun heq => hspRS_np.2.2.2 r hr h16 j hj (heq ▸ hs)⟩
  refine ⟨?_, hsn_ne5, hjob_other_ne5⟩
  have hsn_eq : ∀ r, snSlotSet m₂ r = snSlotSet m₁ r :=
    fun r => snSlotSet_congr_14_15 (hw14_2 _) (hw15_2 _)
  have hold_sub : ∀ r < ctx.st₀.k, wRead m₁ 16 (r : ℤ) = 1 →
      ∀ j < (wRead m₁ 19 (r : ℤ)).toNat,
        jobLevelLiveSlots m₂ (r * ctx.p.D₀ + j) (decide (j + 1 = (wRead m₂ 19 (r : ℤ)).toNat)) ⊆
          jobLevelLiveSlots m₁ (r * ctx.p.D₀ + j) (decide (j + 1 = (wRead m₁ 19 (r : ℤ)).toNat)) := by
    intro r hr h16 j hj
    have hj_lt_D0 : j < ctx.p.D₀ := by
      rcases (cg01_activePropBuild_gc_hyps pb).2.2.2 r hr h16 with ⟨jL, hjL, hw19_r, _⟩
      rw [hw19_r] at hj; simp only [Int.toNat_natCast] at hj; omega
    have hidx_ne : r * ctx.p.D₀ + j ≠ newIdx := by
      by_cases hri : r = i
      · subst r; rw [h19_i_nat1] at hj; dsimp only [newIdx]; omega
      · exact jobIdx_ne hj_lt_D0 hjLen_lt_D0 (Or.inl hri)
    have heq_m2_m1 : ∀ sp, jobLevelLiveSlots m₂ (r * ctx.p.D₀ + j) sp =
        jobLevelLiveSlots m₁ (r * ctx.p.D₀ + j) sp :=
      fun sp => jobLevelLiveSlots_congr_23
        (hw23_old _ hidx_ne 3 (by decide))
        (hw23_old _ hidx_ne 4 (by decide))
        (hw23_old _ hidx_ne 5 (by decide))
        (hw23_old _ hidx_ne 6 (by decide))
    rw [heq_m2_m1]
    by_cases hri : r = i
    · subst r
      rw [h19_i_nat1] at hj
      have hd_f : decide (j + 1 = (wRead m₂ 19 (i : ℤ)).toNat) = false := by
        rw [hw19_i2]; simp only [Int.toNat_natCast, decide_eq_false_iff_not]; omega
      rw [hd_f]
      exact cg01_jobLevelLiveSlots_mono_false m₁ _ _
    · rw [hw19_ne2 r hri]
  have hnew_live_props : ∀ s ∈ jobLevelLiveSlots m₂ newIdx true,
      (s ≠ 0 ∧ s ≠ leafS) ∧
      (∀ r' < ctx.st₀.k, s ∉ snSlotSet m₁ r') ∧
      (∀ r' < ctx.st₀.k, wRead m₁ 16 (r' : ℤ) = 1 →
        ∀ j' < (wRead m₁ 19 (r' : ℤ)).toNat, s ∉ jobLevelSlotSet m₁ (r' * ctx.p.D₀ + j')) := by
    intro s hs
    rw [hlive_new] at hs
    simp only [Finset.mem_insert, Finset.mem_singleton] at hs
    rcases hs with rfl | rfl | rfl | rfl
    · exact ⟨⟨hspRS_np.1, hspRS_np.2.1⟩, hspRS_np.2.2.1, hspRS_np.2.2.2⟩
    · exact ⟨⟨hdS_np.1, hdS_np.2.1⟩, hdS_np.2.2.1, hdS_np.2.2.2⟩
    · exact ⟨⟨hspDS_np.1, hspDS_np.2.1⟩, hspDS_np.2.2.1, hspDS_np.2.2.2⟩
    · exact ⟨⟨hrS_np.1, hrS_np.2.1⟩, hrS_np.2.2.1, hrS_np.2.2.2⟩
  refine ⟨hDisj.1,
    fun r hr s hs => hDisj.2.1 r hr s (by rwa [hsn_eq] at hs),
    fun r₁ hr₁ r₂ hr₂ hne => by rw [hsn_eq, hsn_eq]; exact hDisj.2.2.1 r₁ hr₁ r₂ hr₂ hne,
    fun r hr h16 j hj => ?_,
    fun r₁ hr₁ h16_1 j₁ hj₁ r₂ hr₂ h16_2 j₂ hj₂ hne => ?_⟩
  · rw [hw16_2] at h16
    by_cases hnew : r = i ∧ j = jLen
    · rcases hnew with ⟨heq_r, heq_j⟩; subst r; subst j
      have hd_t : decide (jLen + 1 = (wRead m₂ 19 (i : ℤ)).toNat) = true := by
        rw [hw19_i2]; simp [jLen]
      rw [hd_t]
      exact ⟨fun s hs => (hnew_live_props s hs).1,
        fun r' hr' => by
          rw [hsn_eq]
          exact Finset.disjoint_left.mpr fun s hs hsn => (hnew_live_props s hs).2.1 r' hr' hsn⟩
    · have hj_old : j < (wRead m₁ 19 (r : ℤ)).toNat := by
        by_cases hri : r = i
        · subst r; rw [hw19_i2] at hj; simp only [Int.toNat_natCast] at hj
          rw [h19_i_nat1]; omega
        · rwa [hw19_ne2 r hri] at hj
      have hsub := hold_sub r hr h16 j hj_old
      have hp := hDisj.2.2.2.1 r hr h16 j hj_old
      exact ⟨fun s hs => hp.1 s (hsub hs),
        fun r' hr' => by rw [hsn_eq]; exact (hp.2 r' hr').mono_left hsub⟩
  · rw [hw16_2] at h16_1; rw [hw16_2] at h16_2
    have char_rj : ∀ r < ctx.st₀.k, wRead m₁ 16 (r : ℤ) = 1 →
        ∀ j < (wRead m₂ 19 (r : ℤ)).toNat,
          (r = i ∧ j = jLen) ∨ j < (wRead m₁ 19 (r : ℤ)).toNat := by
      intro r _ _ j hj
      by_cases hri : r = i
      · subst r; rw [hw19_i2] at hj; simp only [Int.toNat_natCast] at hj
        rw [h19_i_nat1]
        by_cases hjj : j = jLen
        · exact Or.inl ⟨rfl, hjj⟩
        · exact Or.inr (by omega)
      · rw [hw19_ne2 r hri] at hj; exact Or.inr hj
    rcases char_rj r₁ hr₁ h16_1 j₁ hj₁ with ⟨heq_r1, heq_j1⟩ | hj₁_old
    · subst r₁; subst j₁
      rcases char_rj r₂ hr₂ h16_2 j₂ hj₂ with ⟨heq_r2, heq_j2⟩ | hj₂_old
      · subst r₂; subst j₂; simp at hne
      · have hd_t : decide (jLen + 1 = (wRead m₂ 19 (i : ℤ)).toNat) = true := by rw [hw19_i2]; simp [jLen]
        have hj₂_lt_D0 : j₂ < ctx.p.D₀ := by
          rcases (cg01_activePropBuild_gc_hyps pb).2.2.2 r₂ hr₂ h16_2 with ⟨jL, hjL, hw19_r, _⟩
          rw [hw19_r] at hj₂_old; simp only [Int.toNat_natCast] at hj₂_old; omega
        have hidx2_ne : r₂ * ctx.p.D₀ + j₂ ≠ newIdx := by
          by_cases hr2 : r₂ = i
          · subst r₂; rw [h19_i_nat1] at hj₂_old; dsimp only [newIdx]; omega
          · exact jobIdx_ne hj₂_lt_D0 hjLen_lt_D0 (Or.inl hr2)
        refine ⟨?_, ?_⟩
        · rw [hd_t]
          refine Finset.disjoint_left.mpr (fun s hs1 hs2 => ?_)
          have hs2_old := hold_sub r₂ hr₂ h16_2 j₂ hj₂_old hs2
          exact (hnew_live_props s hs1).2.2 r₂ hr₂ h16_2 j₂ hj₂_old
            (jobLevelLiveSlots_subset_slotSet m₁ _ _ hs2_old)
        · change (wRead m₂ 23 (((8 * newIdx + 2 : ℕ) : ℤ))).toNat ≠ _
          rw [hw23_new2, Int.toNat_natCast, hw23_old _ hidx2_ne 2 (by decide)]
          rcases hEnc_m1_all r₂ hr₂ h16_2 j₂ hj₂_old with ⟨_, _, _, _, _, _, hEnc2⟩
          have h6_pos := (encJobLevel_live_and_frozen_slots hEnc2).1
          intro heq; rw [← heq] at h6_pos; omega
    · rcases char_rj r₂ hr₂ h16_2 j₂ hj₂ with ⟨heq_r2, heq_j2⟩ | hj₂_old
      · subst r₂; subst j₂
        have hd_t : decide (jLen + 1 = (wRead m₂ 19 (i : ℤ)).toNat) = true := by rw [hw19_i2]; simp [jLen]
        have hj₁_lt_D0 : j₁ < ctx.p.D₀ := by
          rcases (cg01_activePropBuild_gc_hyps pb).2.2.2 r₁ hr₁ h16_1 with ⟨jL, hjL, hw19_r, _⟩
          rw [hw19_r] at hj₁_old; simp only [Int.toNat_natCast] at hj₁_old; omega
        have hidx1_ne : r₁ * ctx.p.D₀ + j₁ ≠ newIdx := by
          by_cases hr1 : r₁ = i
          · subst r₁; rw [h19_i_nat1] at hj₁_old; dsimp only [newIdx]; omega
          · exact jobIdx_ne hj₁_lt_D0 hjLen_lt_D0 (Or.inl hr1)
        refine ⟨?_, ?_⟩
        · rw [hd_t]
          refine Finset.disjoint_right.mpr (fun s hs2 hs1 => ?_)
          have hs1_old := hold_sub r₁ hr₁ h16_1 j₁ hj₁_old hs1
          exact (hnew_live_props s hs2).2.2 r₁ hr₁ h16_1 j₁ hj₁_old
            (jobLevelLiveSlots_subset_slotSet m₁ _ _ hs1_old)
        · change _ ≠ (wRead m₂ 23 (((8 * newIdx + 2 : ℕ) : ℤ))).toNat
          rw [hw23_new2, Int.toNat_natCast, hw23_old _ hidx1_ne 2 (by decide)]
          rcases hEnc_m1_all r₁ hr₁ h16_1 j₁ hj₁_old with ⟨_, _, _, _, _, _, hEnc1⟩
          have h6_pos := (encJobLevel_live_and_frozen_slots hEnc1).1
          intro heq; rw [heq] at h6_pos; omega
      · have hp := hDisj.2.2.2.2 r₁ hr₁ h16_1 j₁ hj₁_old r₂ hr₂ h16_2 j₂ hj₂_old hne
        have hj₁_lt_D0 : j₁ < ctx.p.D₀ := by
          rcases (cg01_activePropBuild_gc_hyps pb).2.2.2 r₁ hr₁ h16_1 with ⟨jL, hjL, hw19_r, _⟩
          rw [hw19_r] at hj₁_old; simp only [Int.toNat_natCast] at hj₁_old; omega
        have hj₂_lt_D0 : j₂ < ctx.p.D₀ := by
          rcases (cg01_activePropBuild_gc_hyps pb).2.2.2 r₂ hr₂ h16_2 with ⟨jL, hjL, hw19_r, _⟩
          rw [hw19_r] at hj₂_old; simp only [Int.toNat_natCast] at hj₂_old; omega
        have hidx1_ne : r₁ * ctx.p.D₀ + j₁ ≠ newIdx := by
          by_cases hr1 : r₁ = i
          · subst r₁; rw [h19_i_nat1] at hj₁_old; dsimp only [newIdx]; omega
          · exact jobIdx_ne hj₁_lt_D0 hjLen_lt_D0 (Or.inl hr1)
        have hidx2_ne : r₂ * ctx.p.D₀ + j₂ ≠ newIdx := by
          by_cases hr2 : r₂ = i
          · subst r₂; rw [h19_i_nat1] at hj₂_old; dsimp only [newIdx]; omega
          · exact jobIdx_ne hj₂_lt_D0 hjLen_lt_D0 (Or.inl hr2)
        exact ⟨hp.1.mono (hold_sub r₁ hr₁ h16_1 j₁ hj₁_old) (hold_sub r₂ hr₂ h16_2 j₂ hj₂_old),
          by rw [hw23_old _ hidx1_ne 2 (by decide), hw23_old _ hidx2_ne 2 (by decide)]; exact hp.2⟩

end UL.Proof_lem_7_2_RacerP46
