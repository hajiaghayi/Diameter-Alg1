import UL.Proof.lem_7_2.CG03_JobTickA3c

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Monotonicity, Scratch Congruence, & Active-Slot Helpers on `MidLoopUncut` -/

lemma jobLevelLiveSlots_subset_slotSet (mem : ArithRAMMemory) (idx : ℕ) (sp : Bool) :
    jobLevelLiveSlots mem idx sp ⊆ jobLevelSlotSet mem idx := by
  intro x hx
  unfold jobLevelLiveSlots at hx
  unfold jobLevelSlotSet
  cases sp <;> simp only [↓reduceIte, Bool.false_eq_true, Finset.mem_insert, Finset.mem_singleton] at hx ⊢ <;>
    rcases hx with rfl | rfl | rfl | rfl <;> simp

lemma MidLoopUncut.to_false {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ} {m : ArithRAMMemory}
    (hU : MidLoopUncut ctx gFlag i m) :
    MidLoopUncut ctx false i m := by
  rcases hU with ⟨h27, _, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, hDone, hTodo⟩
  refine ⟨h27, (fun h => by cases h), hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, ?_, ?_⟩
  · intro r hr
    rcases hDone r hr with ⟨oj, hInv, _, hHdr, hOwn⟩
    exact ⟨oj, hInv, (fun h => by cases h), hHdr, hOwn⟩
  · intro r hr
    rcases hTodo r hr with ⟨haff_w, hHdr, _, hTd⟩
    exact ⟨haff_w, hHdr, (fun h => by cases h), hTd⟩

lemma MidLoopCut.to_false {ctx : MidLoopCtx} {gFlag : Bool} {m : ArithRAMMemory}
    (hC : MidLoopCut ctx gFlag m) :
    MidLoopCut ctx false m := by
  rcases hC with ⟨h27, st_mid, hu, hInv, hTerm, hEnc, _⟩
  exact ⟨h27, st_mid, hu, hInv, hTerm, hEnc, (fun h => by cases h)⟩

lemma MidLoopUncut.congr_scratch {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ} {m m' : ArithRAMMemory}
    (hU : MidLoopUncut ctx gFlag i m)
    (hw27 : wRead m' 26 27 = wRead m 26 27)
    (hw_other : ∀ t, t ≠ 26 → ∀ idx, wRead m' t idx = wRead m t idx)
    (hr_other : ∀ t, t ≠ 26 → t ≠ 27 → ∀ idx, rRead m' t idx = rRead m t idx) :
    MidLoopUncut ctx gFlag i m' := by
  rcases hU with ⟨h27, hGood₀, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, hDone, hTodo⟩
  have hV := ctx.hV
  have hbc_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.1 (by decide)
  have hage_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.1 (by decide)
  have haff_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.1 (by decide)
  have hrem_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.1 (by decide)
  have hcl_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.2.1 (by decide)
  have hrO_ne26 := rtag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1 (by decide)
  have hrO_ne27 := rtag_ne_of_not_reserved (u := 27) hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1 (by decide)
  have hrV_ne26 := rtag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2 (by decide)
  have hrV_ne27 := rtag_ne_of_not_reserved (u := 27) hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2 (by decide)
  have hSegPres : ∀ s < ctx.p.NumSlots, ∀ S₁ fSq₁,
      EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁ :=
    fun _ _ _ _ hE => hE.congr_mem_fSq
      (hw_other 5 (by decide) _) (fun _ _ => hw_other 8 (by decide) _)
      (fun _ _ => hw_other 9 (by decide) _) (fun _ _ => hw_other 10 (by decide) _)
      (fun _ _ => hr_other 8 (by decide) (by decide) _) (fun _ _ => rfl)
  have hDisj' : GlobalSlotDisj ctx.p.D₀ m' ctx.st₀.k leafS := by
    rcases hDisj with ⟨hlp, hsn0, hsnP, hlv_sn, hlv_lv⟩
    have hsn_eq : ∀ r, snSlotSet m' r = snSlotSet m r :=
      fun r => snSlotSet_congr_14_15 (hw_other 14 (by decide) _) (hw_other 15 (by decide) _)
    have h16_eq : ∀ r, wRead m' 16 (r : ℤ) = wRead m 16 (r : ℤ) := fun _ => hw_other 16 (by decide) _
    have h19_eq : ∀ r, wRead m' 19 (r : ℤ) = wRead m 19 (r : ℤ) := fun _ => hw_other 19 (by decide) _
    have h23_eq : ∀ idx, wRead m' 23 idx = wRead m 23 idx := fun _ => hw_other 23 (by decide) _
    have hlv_eq : ∀ idx sp, jobLevelLiveSlots m' idx sp = jobLevelLiveSlots m idx sp :=
      fun _ _ => jobLevelLiveSlots_congr_23 (h23_eq _) (h23_eq _) (h23_eq _) (h23_eq _)
    refine ⟨hlp,
      fun r hr s hs => by rw [hsn_eq] at hs; exact hsn0 r hr s hs,
      fun r₁ hr₁ r₂ hr₂ hne => by rw [hsn_eq, hsn_eq]; exact hsnP r₁ hr₁ r₂ hr₂ hne,
      fun r hr h16 j hj => ?_,
      fun r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne => ?_⟩
    · dsimp only
      rw [h16_eq r] at h16; rw [h19_eq r] at hj ⊢; rw [hlv_eq]
      rcases hlv_sn r hr h16 j hj with ⟨h0l, hd_sn⟩
      exact ⟨h0l, fun r' hr' => by rw [hsn_eq]; exact hd_sn r' hr'⟩
    · rw [h16_eq r₁] at h16₁; rw [h16_eq r₂] at h16₂
      rw [h19_eq r₁] at hj₁ ⊢; rw [h19_eq r₂] at hj₂ ⊢
      rw [hlv_eq, hlv_eq, h23_eq, h23_eq]
      exact hlv_lv r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne
  refine ⟨hw27.trans h27, hGood₀,
    ⟨by rw [hw_other 1 (by decide)]; exact hSeg.1,
     fun s hs => by rw [hw_other 5 (by decide), hw_other 1 (by decide)]; exact hSeg.2.1 s hs,
     fun s hs u hu => by rw [hw_other 8 (by decide), hw_other 1 (by decide)]; exact hSeg.2.2 s hs u hu⟩,
    ⟨by rw [hw_other 1 (by decide)]; exact hSave.1,
     fun s hs => by rw [hw_other 6 (by decide), hw_other 1 (by decide)]; exact hSave.2.1 s hs,
     fun s hs h hh => by rw [hw_other 11 (by decide), hw_other 1 (by decide)]; exact hSave.2.2 s hs h hh⟩,
    ⟨hLive.1, fun h hh c => by rw [hr_other 4 (by decide) (by decide)]; exact hLive.2 h hh c⟩,
    (hw_other 1 (by decide) _).trans h15,
    (hw_other 6 (by decide) _).trans h60,
    hSegPres 0 (by have := ctx.hSlots_cap; omega) _ _ hSeg0,
    leafS, hl0, hllt,
    (hw_other 1 (by decide) _).trans h16l,
    (hw_other 6 (by decide) _).trans h6l,
    hSegPres leafS hllt _ _ hSegL,
    hDisj', ?_, ?_⟩
  · intro r hr
    rcases hDone r hr with ⟨oj, hInv, hGood_r, hHdr, hOwn⟩
    exact ⟨oj, hInv, hGood_r,
      hHdr.frame_other
        (hw_other _ hbc_ne26 _) (hw_other _ hage_ne26 _)
        (hw_other 14 (by decide) _) (hw_other 15 (by decide) _)
        (fun _ _ => hw_other 6 (by decide) _)
        (fun _ => hr_other _ hrO_ne26 hrO_ne27 _)
        (hr_other _ hrV_ne26 hrV_ne27 _)
        (fun s _ hlt _ _ hE => hSegPres s hlt _ _ hE),
      hOwn.frame_other
        (fun g _ => by rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2))
        (hw_other 16 (by decide) _) (hw_other _ hrem_ne26 _) (hw_other _ hcl_ne26 _)
        (hw_other 19 (by decide) _)
        (fun _ _ _ _ => hw_other 23 (by decide) _)
        (fun _ _ _ _ => hw_other 24 (by decide) _)
        (fun _ _ _ => hr_other 23 (by decide) (by decide) _)
        (fun _ _ _ _ => hr_other 24 (by decide) (by decide) _)
        (fun _ _ _ _ _ => hw_other 6 (by decide) _)
        (fun _ _ _ s _ hlt _ _ _ hE => hSegPres s hlt _ _ hE)
        (fun _ => hw_other 11 (by decide) _)
        (fun _ => hr_other 11 (by decide) (by decide) _)⟩
  · intro r hr
    rcases hTodo r hr with ⟨haff_w, hHdr, hGood_r, hTd⟩
    exact ⟨(hw_other _ haff_ne26 _).trans haff_w,
      hHdr.frame_other
        (hw_other _ hbc_ne26 _) (hw_other _ hage_ne26 _)
        (hw_other 14 (by decide) _) (hw_other 15 (by decide) _)
        (fun _ _ => hw_other 6 (by decide) _)
        (fun _ => hr_other _ hrO_ne26 hrO_ne27 _)
        (hr_other _ hrV_ne26 hrV_ne27 _)
        (fun s _ hlt _ _ hE => hSegPres s hlt _ _ hE),
      hGood_r,
      hTd.frame_other
        (hw_other 16 (by decide) _) (hw_other _ hrem_ne26 _) (hw_other _ hcl_ne26 _)
        (hw_other 19 (by decide) _)
        (fun _ _ _ _ => hw_other 23 (by decide) _)
        (fun _ _ _ _ => hw_other 24 (by decide) _)
        (fun _ _ _ => hr_other 23 (by decide) (by decide) _)
        (fun _ _ _ _ => hr_other 24 (by decide) (by decide) _)
        (fun _ _ _ _ _ => hw_other 6 (by decide) _)
        (fun _ _ _ s _ hlt _ _ _ hE => hSegPres s hlt _ _ hE)
        (fun _ => hw_other 11 (by decide) _)
        (fun _ => hr_other 11 (by decide) (by decide) _)⟩

lemma MidLoopUncut.encJobLevel_at_active {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ} {m : ArithRAMMemory}
    (hU : MidLoopUncut ctx gFlag i m)
    (r j : ℕ) (hr : r < ctx.st₀.k)
    (h16 : wRead m 16 (r : ℤ) = 1)
    (hj : j < (wRead m 19 (r : ℤ)).toNat) :
    (wRead m 19 (r : ℤ)).toNat ≤ ctx.p.D₀ ∧
    ∃ actH lPts Sb sn pr Sp,
      EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m actH lPts
        (r * ctx.p.D₀ + j) Sb sn pr Sp (decide (j + 1 = (wRead m 19 (r : ℤ)).toNat)) := by
  rcases hU with ⟨_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, hDone, hTodo⟩
  by_cases hlt : r < i
  · rcases hDone ⟨r, hr⟩ hlt with ⟨oj, _, _, _, hO⟩
    cases hoj : oj with
    | none => rw [hoj] at hO; change wRead m 16 (r : ℤ) = 0 at hO; omega
    | some g =>
        rw [hoj] at hO
        rcases hO with ⟨_, _, _, h19_r, lvs_h, hlen_eq, hlv_r⟩
        have h19_n : (wRead m 19 (r : ℤ)).toNat = lvs_h.length := by rw [h19_r, ← hlen_eq]; simp
        have hj_le : lvs_h.length ≤ ctx.p.D₀ := by
          rw [hlen_eq, ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2)
        have hj_lh : j < lvs_h.length := h19_n ▸ hj
        exact ⟨h19_n ▸ hj_le, _, _, _, _, _, _, h19_n.symm ▸ (hlv_r j hj_lh).2.2.2.1⟩
  · have hgt : i ≤ r := Nat.le_of_not_lt hlt
    have hT := (hTodo ⟨r, hr⟩ hgt).2.2.2
    unfold EncTodoJobAt at hT
    cases hoj : ctx.st₀.ownedJob ⟨r, hr⟩ with
    | none => rw [hoj] at hT; change wRead m 16 (r : ℤ) = 0 at hT; omega
    | some g =>
        rw [hoj] at hT
        rcases hT with ⟨_, _, _, h19_r, lvs_h, hlen_eq, hlv_r⟩
        have h19_n : (wRead m 19 (r : ℤ)).toNat = lvs_h.length := by rw [h19_r, ← hlen_eq]; simp
        have hj_le : lvs_h.length ≤ ctx.p.D₀ := by
          rw [hlen_eq, ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2)
        have hj_lh : j < lvs_h.length := h19_n ▸ hj
        exact ⟨h19_n ▸ hj_le, _, _, _, _, _, _, h19_n.symm ▸ (hlv_r j hj_lh).2.2.2.1⟩

/-! ### 2. Pure Post-Launch Invariant Builder (`midLoopUncut_after_launch`) -/

theorem midLoopUncut_after_launch
    {ctx : MidLoopCtx} {gFlag b : Bool} {i : ℕ} (hi : i < ctx.st₀.k)
    {m m' : ArithRAMMemory}
    {dS_i oldSp dS0 spDS0 rS0 spRS0 dummySp : ℕ}
    {o_cand : EuclideanSpace ℝ (Fin ctx.d)} {s_cand : ℝ}
    {prov : ChainNode ctx.d}
    (hU : MidLoopUncut ctx gFlag i m)
    (haff : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = true)
    (hnone : ctx.st₀.ownedJob ⟨i, hi⟩ = none)
    (heq_st : ctx.snAge' ⟨i, hi⟩ =
      jobStartAge (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.st₀.birthSnap ⟨i, hi⟩).card)
    (hlarge_h : 4 * ctx.p.L < (ctx.S_post_h ⟨i, hi⟩).card)
    (hw14_i : wRead m 14 (i : ℤ) = (dS_i : ℤ))
    (hw15_i : wRead m 15 (i : ℤ) = (oldSp : ℤ))
    (hdS_i0 : 0 < dS_i) (hdS_i_lt : dS_i < ctx.p.NumSlots)
    (holdSp0 : 0 < oldSp)
    (hne_dS_oldSp : dS_i ≠ oldSp)
    (h6_oldSp_m : wRead m 6 (oldSp : ℤ) = 0)
    (hdS0_pos : 0 < dS0) (hdS0_notU : dS0 ∉ activeSlotSet m ctx.p.D₀)
    (hspDS0_pos : 0 < spDS0) (hspDS0_notU : spDS0 ∉ activeSlotSet m ctx.p.D₀)
    (hrS0_pos : 0 < rS0) (hrS0_notU : rS0 ∉ activeSlotSet m ctx.p.D₀)
    (hspRS0_pos : 0 < spRS0) (hspRS0_notU : spRS0 ∉ activeSlotSet m ctx.p.D₀)
    (hdum_pos : 0 < dummySp) (hdum_lt : dummySp < ctx.p.NumSlots)
    (hdum_notU : dummySp ∉ activeSlotSet m ctx.p.D₀)
    (hdum_ne : dummySp ≠ dS0 ∧ dummySp ≠ spDS0 ∧ dummySp ≠ rS0 ∧ dummySp ≠ spRS0)
    (hw27' : wRead m' 26 27 = 0)
    (hSeg' : SegGenBound ctx.p.K_seg ctx.p.NumSlots m')
    (hSave' : SaveGenBound ctx.n ctx.p.NumSlots m')
    (hLive' : EncLiveCoords ctx.d ctx.n m' ctx.P'.activeHandles ctx.P'.handleCoords)
    (hw1_5' : wRead m' 1 5 = wRead m 1 5)
    (hw1_6' : wRead m' 1 6 = wRead m 1 6)
    (hw11' : ∀ idx, wRead m' 11 idx = wRead m 11 idx)
    (hr11' : ∀ idx, rRead m' 11 idx = rRead m 11 idx)
    (hw14' : ∀ r, wRead m' 14 r = wRead m 14 r)
    (hw15_i' : wRead m' 15 (i : ℤ) = (dummySp : ℤ))
    (hw15_ne' : ∀ r ≠ i, wRead m' 15 (r : ℤ) = wRead m 15 (r : ℤ))
    (hw16_i' : wRead m' 16 (i : ℤ) = 1)
    (hw16_ne' : ∀ r ≠ i, wRead m' 16 (r : ℤ) = wRead m 16 (r : ℤ))
    (hw19_i' : wRead m' 19 (i : ℤ) = 1)
    (hw19_ne' : ∀ r ≠ i, wRead m' 19 (r : ℤ) = wRead m 19 (r : ℤ))
    (hwRem_i' : wRead m' ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) =
      ((jobDeadlineTicks (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2))
        (ctx.S_post_u ⟨i, hi⟩).card : ℕ) : ℤ))
    (hwRem_ne' : ∀ r ≠ i, wRead m' ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) =
      wRead m ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ))
    (hwCl_i' : wRead m' ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx i : ℤ) = 0)
    (hwCl_ne' : ∀ r ≠ i, wRead m' ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ) =
      wRead m ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ))
    (hw_bc' : ∀ r, wRead m' ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ) =
      wRead m ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ))
    (hw_age' : ∀ r, wRead m' ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ) =
      wRead m ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ))
    (hw_aff' : ∀ r, wRead m' ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ) =
      wRead m ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ))
    (hrO' : ∀ idx, rRead m' ctx.cfg.rSnCenterO idx = rRead m ctx.cfg.rSnCenterO idx)
    (hrV' : ∀ idx, rRead m' ctx.cfg.rSnCenterV.tag idx = rRead m ctx.cfg.rSnCenterV.tag idx)
    (h6_dum' : wRead m' 6 (dummySp : ℤ) = 0)
    (hw6_not6' : ∀ s : ℕ, s ≠ oldSp → s ≠ dS0 → s ≠ spDS0 → s ≠ rS0 → s ≠ spRS0 → s ≠ dummySp →
      wRead m' 6 (s : ℤ) = wRead m 6 (s : ℤ))
    (hEmp_dum' : EncSegSlot ctx.p.K_seg m' dummySp ∅ (fun _ => 0))
    (hSegPres' : ∀ s < ctx.p.NumSlots, s ≠ dS0 → s ≠ spDS0 → s ≠ rS0 → s ≠ spRS0 → s ≠ dummySp →
      ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁)
    (hEncLv0' : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m'
      ctx.P'.activeHandles ctx.P'.handleCoords (i * ctx.p.D₀)
      (ctx.S_post_h ⟨i, hi⟩) ctx.P'.handleCoords prov (ctx.S_post_h ⟨i, hi⟩) true)
    (hball0' : ∀ (hb_pos : 0 < (ctx.S_post_h ⟨i, hi⟩).card),
      let α := 1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)
      let bId := (ctx.S_post_h ⟨i, hi⟩).orderEmbOfFin rfl ⟨0, hb_pos⟩
      applyBirthCoreFallback α ctx.P'.handleCoords (ctx.S_post_h ⟨i, hi⟩) prov =
        selectOpenedLevelBall α ctx.uMap'.ghostCoords (ctx.S_post_u ⟨i, hi⟩) (ctx.uMap'.uidOfH bId)
          (.candidate o_cand (liftVariance o_cand s_cand)))
    (hw23_i0 : wRead m' 23 (((8 * (i * ctx.p.D₀) + 2 : ℕ) : ℤ)) = (oldSp : ℤ) ∧
               wRead m' 23 (((8 * (i * ctx.p.D₀) + 3 : ℕ) : ℤ)) = (dS0 : ℤ) ∧
               wRead m' 23 (((8 * (i * ctx.p.D₀) + 4 : ℕ) : ℤ)) = (spDS0 : ℤ) ∧
               wRead m' 23 (((8 * (i * ctx.p.D₀) + 5 : ℕ) : ℤ)) = (rS0 : ℤ) ∧
               wRead m' 23 (((8 * (i * ctx.p.D₀) + 6 : ℕ) : ℤ)) = (spRS0 : ℤ) ∧
               wRead m' 23 (((8 * (i * ctx.p.D₀) + 7 : ℕ) : ℤ)) =
                 ((jobDeadlineTicks (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2))
                   (ctx.S_post_u ⟨i, hi⟩).card : ℕ) : ℤ))
    (hw24_i0 : wRead m' 24 (((2 * (i * ctx.p.D₀) + 0 : ℕ) : ℤ)) = 0 ∧
               wRead m' 24 (((2 * (i * ctx.p.D₀) + 1 : ℕ) : ℤ)) = 0)
    (hw23_ne' : ∀ r ≠ i, ∀ j < ctx.p.D₀, ∀ a < 8,
      wRead m' 23 (((8 * (r * ctx.p.D₀ + j) + a : ℕ) : ℤ)) =
      wRead m 23 (((8 * (r * ctx.p.D₀ + j) + a : ℕ) : ℤ)))
    (hw24_ne' : ∀ r ≠ i, ∀ j < ctx.p.D₀, ∀ a < 2,
      wRead m' 24 (((2 * (r * ctx.p.D₀ + j) + a : ℕ) : ℤ)) =
      wRead m 24 (((2 * (r * ctx.p.D₀ + j) + a : ℕ) : ℤ)))
    (hr23_ne' : ∀ r ≠ i, ∀ j < ctx.p.D₀, ∀ c : Fin ctx.d,
      rRead m' 23 ((((r * ctx.p.D₀ + j) * ctx.d + c.val : ℕ) : ℤ)) =
      rRead m 23 ((((r * ctx.p.D₀ + j) * ctx.d + c.val : ℕ) : ℤ)))
    (hr24_ne' : ∀ r ≠ i, ∀ j < ctx.p.D₀, ∀ a < 2,
      rRead m' 24 (((2 * (r * ctx.p.D₀ + j) + a : ℕ) : ℤ)) =
      rRead m 24 (((2 * (r * ctx.p.D₀ + j) + a : ℕ) : ℤ)))
    (hb_good : b = true → gFlag = true ∧
      let α := 1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)
      let ball := applyBirthCoreFallback α ctx.P'.handleCoords (ctx.S_post_h ⟨i, hi⟩) prov
      IsCenterpoint α (paraboloidLiftSet (fun u : ↥(ctx.S_post_u ⟨i, hi⟩) => ctx.uMap'.ghostCoords u.1))
        (liftedPoint ball.o (ball.V + ‖ball.o‖ ^ 2))) :
    MidLoopUncut ctx b (i + 1) m' := by
  classical
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  have hD : 3 ≤ ctx.d + 3 := by omega
  have hEnc_act := hU.encJobLevel_at_active
  rcases hU with ⟨_, hGood₀, _, _, hLive_m, hw15_m, hw60_m, hSeg0_m,
    leafS, hleaf0, hleaf_lt, hw16_m, hw6leaf_m, hSegLeaf_m, hDisj_m, hDone_m, hTodo_m⟩
  have hdS0_np := not_in_activeSlotSet_props hw15_m hw16_m hdS0_notU
  have hspDS0_np := not_in_activeSlotSet_props hw15_m hw16_m hspDS0_notU
  have hrS0_np := not_in_activeSlotSet_props hw15_m hw16_m hrS0_notU
  have hspRS0_np := not_in_activeSlotSet_props hw15_m hw16_m hspRS0_notU
  have hdum_np := not_in_activeSlotSet_props hw15_m hw16_m hdum_notU
  have holdSp_in_sn : oldSp ∈ snSlotSet m i := by unfold snSlotSet; rw [hw15_i]; simp
  have hdSi_in_sn : dS_i ∈ snSlotSet m i := by unfold snSlotSet; rw [hw14_i]; simp
  have holdSp_ne : oldSp ≠ dS0 ∧ oldSp ≠ spDS0 ∧ oldSp ≠ rS0 ∧ oldSp ≠ spRS0 ∧ oldSp ≠ dummySp :=
    ⟨fun h => hdS0_np.2.2.1 i hi (h ▸ holdSp_in_sn),
     fun h => hspDS0_np.2.2.1 i hi (h ▸ holdSp_in_sn),
     fun h => hrS0_np.2.2.1 i hi (h ▸ holdSp_in_sn),
     fun h => hspRS0_np.2.2.1 i hi (h ▸ holdSp_in_sn),
     fun h => hdum_np.2.2.1 i hi (h ▸ holdSp_in_sn)⟩
  have hdSi_ne : dS_i ≠ dS0 ∧ dS_i ≠ spDS0 ∧ dS_i ≠ rS0 ∧ dS_i ≠ spRS0 ∧ dS_i ≠ dummySp :=
    ⟨fun h => hdS0_np.2.2.1 i hi (h ▸ hdSi_in_sn),
     fun h => hspDS0_np.2.2.1 i hi (h ▸ hdSi_in_sn),
     fun h => hrS0_np.2.2.1 i hi (h ▸ hdSi_in_sn),
     fun h => hspRS0_np.2.2.1 i hi (h ▸ hdSi_in_sn),
     fun h => hdum_np.2.2.1 i hi (h ▸ hdSi_in_sn)⟩
  -- Construct g₀ via ActiveJobGhost.start
  have hsub_post : ctx.S_post_h r_fin ⊆ ctx.P'.activeHandles :=
    cg01_chainInput_subset ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles r_fin.castSucc
  have hmap_eq : ctx.uMap'.mapSet (ctx.S_post_h r_fin) = ctx.S_post_u r_fin :=
    ctx.uMap'.mapSet_chainInput ctx.st₀.nodes r_fin.castSucc
  have hbij := ctx.uMap'.mapSet_bij hsub_post
  have hcard_u_eq_h : (ctx.S_post_u r_fin).card = (ctx.S_post_h r_fin).card := by
    rw [← hmap_eq, hbij.1]
  have hb_pos : 0 < (ctx.S_post_h r_fin).card := Nat.lt_of_le_of_lt (Nat.zero_le _) hlarge_h
  have hb_le_n : (ctx.S_post_h r_fin).card ≤ ctx.n :=
    (Finset.card_le_card hsub_post).trans
      ((activeHandles_card_eq_activeIds_card ctx.hP').trans_le ctx.hP'.1)
  let bId : ℕ := (ctx.S_post_h r_fin).orderEmbOfFin rfl ⟨0, hb_pos⟩
  have hbId_mem : bId ∈ ctx.S_post_h r_fin := Finset.orderEmbOfFin_mem _ rfl ⟨0, hb_pos⟩
  have hbUid_mem : ctx.uMap'.uidOfH bId ∈ ctx.S_post_u r_fin := hmap_eq ▸ (hbij.2.2.1 bId hbId_mem).1
  have hcap_u : (ctx.S_post_u r_fin).card ≤ ctx.n := hcard_u_eq_h ▸ hb_le_n
  have huid_u : ∀ u ∈ ctx.S_post_u r_fin, u < ctx.uMap'.nextUid := hmap_eq ▸ hbij.2.1
  have hlarge_u : 4 * ctx.p.L < (ctx.S_post_u r_fin).card := hcard_u_eq_h.symm ▸ hlarge_h
  let res_cand : SampledCenterResult ctx.d := .candidate o_cand (liftVariance o_cand s_cand)
  let g₀ := ActiveJobGhost.start (ghostCoords := ctx.uMap'.ghostCoords) (B_scan := ctx.p.B_scan)
    res_cand hD ctx.hL_floor hcap_u huid_u hlarge_u hbUid_mem hcard_u_eq_h.symm
  have hInv_g0 : ServingOwnedJobInv (ctx.st₀.birthSnap r_fin) (ctx.snAge' r_fin) (some g₀) := by
    rcases ctx.hwf₀.1 r_fin with ⟨_, _, _, htr_old, hage_old, _⟩
    have hchg_u : IsInputChange (ctx.S_pre_u r_fin) (ctx.S_post_u r_fin) :=
      ((ctx.hPerNode r_fin).2 haff).2.1
    have hc := (hasNodeAge_card_bounds (hasNodeAge_step hage_old hchg_u)).1
    have hsn_eq : ctx.snAge' r_fin = ctx.st₀.snAge r_fin + 1 := by
      unfold MidLoopCtx.snAge'; rw [if_pos haff]
    refine ⟨g₀.hH_pos, by change ctx.snAge' r_fin = _ + 0; rw [Nat.add_zero]; exact heq_st, ?_⟩
    change (ctx.S_post_u r_fin).card ≤ (ctx.st₀.birthSnap r_fin).card + jobStartAge _ (ctx.st₀.birthSnap r_fin).card
    have heq_r : ctx.snAge' r_fin = jobStartAge (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.st₀.birthSnap r_fin).card := heq_st
    omega
  -- Disjointness of other nodes' snSlotSet and jobLevelSlotSet from {oldSp, dS0..dummySp}
  have hsn_ne6 : ∀ r < ctx.st₀.k, r ≠ i → ∀ s ∈ snSlotSet m r,
      s ≠ oldSp ∧ s ≠ dS0 ∧ s ≠ spDS0 ∧ s ≠ rS0 ∧ s ≠ spRS0 ∧ s ≠ dummySp := by
    intro r hr hne s hs
    exact ⟨fun heq => Finset.disjoint_left.mp (hDisj_m.2.2.1 r hr i hi hne) hs (heq ▸ holdSp_in_sn),
      fun heq => hdS0_np.2.2.1 r hr (heq ▸ hs),
      fun heq => hspDS0_np.2.2.1 r hr (heq ▸ hs),
      fun heq => hrS0_np.2.2.1 r hr (heq ▸ hs),
      fun heq => hspRS0_np.2.2.1 r hr (heq ▸ hs),
      fun heq => hdum_np.2.2.1 r hr (heq ▸ hs)⟩
  have hjobSlot_ne6 : ∀ r < ctx.st₀.k, r ≠ i → wRead m 16 (r : ℤ) = 1 →
      ∀ j < (wRead m 19 (r : ℤ)).toNat, ∀ s ∈ jobLevelSlotSet m (r * ctx.p.D₀ + j),
        s ≠ oldSp ∧ s ≠ dS0 ∧ s ≠ spDS0 ∧ s ≠ rS0 ∧ s ≠ spRS0 ∧ s ≠ dummySp := by
    intro r hr hne h16 j hj s hs
    refine ⟨?_,
      fun heq => hdS0_np.2.2.2 r hr h16 j hj (heq ▸ hs),
      fun heq => hspDS0_np.2.2.2 r hr h16 j hj (heq ▸ hs),
      fun heq => hrS0_np.2.2.2 r hr h16 j hj (heq ▸ hs),
      fun heq => hspRS0_np.2.2.2 r hr h16 j hj (heq ▸ hs),
      fun heq => hdum_np.2.2.2 r hr h16 j hj (heq ▸ hs)⟩
    intro heq; subst s
    rcases (hEnc_act r j hr h16 hj).2 with ⟨_, _, _, _, _, _, hE_rj⟩
    have hnot_live : oldSp ∉ jobLevelLiveSlots m (r * ctx.p.D₀ + j)
        (decide (j + 1 = (wRead m 19 (r : ℤ)).toNat)) :=
      Finset.disjoint_right.mp ((hDisj_m.2.2.2.1 r hr h16 j hj).2 i hi) holdSp_in_sn
    exact not_mem_jobLevelSlotSet_of_live_disj hE_rj h6_oldSp_m hnot_live hs
  -- GlobalSlotDisj on m'
  have hsn'_eq_ne : ∀ r ≠ i, snSlotSet m' r = snSlotSet m r :=
    fun r hne => snSlotSet_congr_14_15 (hw14' _) (hw15_ne' r hne)
  have hsn'_i : snSlotSet m' i = {dS_i, dummySp} := by
    unfold snSlotSet; rw [hw14', hw14_i, hw15_i']; simp
  have hlv'_i0 : jobLevelLiveSlots m' (i * ctx.p.D₀ + 0) true = {spRS0, dS0, spDS0, rS0} := by
    unfold jobLevelLiveSlots
    simp only [Nat.add_zero, ↓reduceIte, hw23_i0.2.1, hw23_i0.2.2.1, hw23_i0.2.2.2.1, hw23_i0.2.2.2.2.1, Int.toNat_natCast]
  have hlv'_ne : ∀ r < ctx.st₀.k, r ≠ i → wRead m 16 (r : ℤ) = 1 →
      ∀ j < (wRead m 19 (r : ℤ)).toNat,
        jobLevelLiveSlots m' (r * ctx.p.D₀ + j) (decide (j + 1 = (wRead m 19 (r : ℤ)).toNat)) =
        jobLevelLiveSlots m (r * ctx.p.D₀ + j) (decide (j + 1 = (wRead m 19 (r : ℤ)).toNat)) := by
    intro r hr hne h16 j hj
    have hj_D0 : j < ctx.p.D₀ := lt_of_lt_of_le hj (hEnc_act r j hr h16 hj).1
    exact jobLevelLiveSlots_congr_23
      (hw23_ne' r hne j hj_D0 3 (by decide)) (hw23_ne' r hne j hj_D0 4 (by decide))
      (hw23_ne' r hne j hj_D0 5 (by decide)) (hw23_ne' r hne j hj_D0 6 (by decide))
  have hDisj' : GlobalSlotDisj ctx.p.D₀ m' ctx.st₀.k leafS := by
    rcases hDisj_m with ⟨_, hsn0, hsnP, hlv_sn, hlv_lv⟩
    refine ⟨hleaf0, ?_, ?_, ?_, ?_⟩
    · intro r hr s hs
      by_cases hri : r = i
      · subst r; rw [hsn'_i] at hs
        simp only [Finset.mem_insert, Finset.mem_singleton] at hs
        rcases hs with hA | hB <;> subst s
        · exact hsn0 i hi dS_i hdSi_in_sn
        · exact ⟨hdum_np.1, hdum_np.2.1⟩
      · rw [hsn'_eq_ne r hri] at hs; exact hsn0 r hr s hs
    · intro r₁ hr₁ r₂ hr₂ hne
      by_cases h1 : r₁ = i
      · subst r₁; have h2 : r₂ ≠ i := hne.symm
        rw [hsn'_i, hsn'_eq_ne r₂ h2, Finset.disjoint_left]
        intro s hs1 hs2
        simp only [Finset.mem_insert, Finset.mem_singleton] at hs1
        rcases hs1 with hA | hB <;> subst s
        · exact Finset.disjoint_left.mp (hsnP i hi r₂ hr₂ hne) hdSi_in_sn hs2
        · exact hdum_np.2.2.1 r₂ hr₂ hs2
      · by_cases h2 : r₂ = i
        · subst r₂; rw [hsn'_eq_ne r₁ h1, hsn'_i, Finset.disjoint_right]
          intro s hs2 hs1
          simp only [Finset.mem_insert, Finset.mem_singleton] at hs2
          rcases hs2 with hA | hB <;> subst s
          · exact Finset.disjoint_left.mp (hsnP r₁ hr₁ i hi hne) hs1 hdSi_in_sn
          · exact hdum_np.2.2.1 r₁ hr₁ hs1
        · rw [hsn'_eq_ne r₁ h1, hsn'_eq_ne r₂ h2]; exact hsnP r₁ hr₁ r₂ hr₂ hne
    · intro r hr h16 j hj
      dsimp only
      by_cases hri : r = i
      · subst r; rw [hw19_i', Int.toNat_one] at hj ⊢
        have hj0 : j = 0 := by omega
        subst j
        have hdec : decide (0 + 1 = 1) = true := rfl
        rw [hdec, hlv'_i0]
        refine ⟨?_, ?_⟩
        · intro s hs; simp only [Finset.mem_insert, Finset.mem_singleton] at hs
          rcases hs with hA | hB | hC | hD <;> subst s
          · exact ⟨hspRS0_np.1, hspRS0_np.2.1⟩
          · exact ⟨hdS0_np.1, hdS0_np.2.1⟩
          · exact ⟨hspDS0_np.1, hspDS0_np.2.1⟩
          · exact ⟨hrS0_np.1, hrS0_np.2.1⟩
        · intro r' hr'
          by_cases hr'i : r' = i
          · subst r'; rw [hsn'_i, Finset.disjoint_left]
            intro s hs1 hs2
            simp only [Finset.mem_insert, Finset.mem_singleton] at hs1 hs2
            rcases hs1 with c1 | c2 | c3 | c4 <;> subst s <;> rcases hs2 with hA | hB
            · exact hdSi_ne.2.2.2.1 hA.symm
            · exact hdum_ne.2.2.2 hB.symm
            · exact hdSi_ne.1 hA.symm
            · exact hdum_ne.1 hB.symm
            · exact hdSi_ne.2.1 hA.symm
            · exact hdum_ne.2.1 hB.symm
            · exact hdSi_ne.2.2.1 hA.symm
            · exact hdum_ne.2.2.1 hB.symm
          · rw [hsn'_eq_ne r' hr'i, Finset.disjoint_left]
            intro s hs1 hs2
            simp only [Finset.mem_insert, Finset.mem_singleton] at hs1
            rcases hs1 with c1 | c2 | c3 | c4 <;> subst s
            · exact hspRS0_np.2.2.1 r' hr' hs2
            · exact hdS0_np.2.2.1 r' hr' hs2
            · exact hspDS0_np.2.2.1 r' hr' hs2
            · exact hrS0_np.2.2.1 r' hr' hs2
      · rw [hw16_ne' r hri] at h16; rw [hw19_ne' r hri] at hj ⊢
        rw [hlv'_ne r hr hri h16 j hj]
        rcases hlv_sn r hr h16 j hj with ⟨h0l, hd_sn⟩
        refine ⟨h0l, fun r' hr' => ?_⟩
        by_cases hr'i : r' = i
        · subst r'; rw [hsn'_i, Finset.disjoint_right]
          intro s hs2 hs1
          have hsub_slot : s ∈ jobLevelSlotSet m (r * ctx.p.D₀ + j) :=
            jobLevelLiveSlots_subset_slotSet m _ _ hs1
          simp only [Finset.mem_insert, Finset.mem_singleton] at hs2
          rcases hs2 with hA | hB <;> subst s
          · exact Finset.disjoint_left.mp (hd_sn i hi) hs1 hdSi_in_sn
          · exact hdum_np.2.2.2 r hr h16 j hj hsub_slot
        · rw [hsn'_eq_ne r' hr'i]; exact hd_sn r' hr'
    · intro r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne
      have hCross : ∀ rx < ctx.st₀.k, rx ≠ i → wRead m 16 (rx : ℤ) = 1 →
          ∀ jx < (wRead m 19 (rx : ℤ)).toNat,
            Disjoint (jobLevelLiveSlots m' (i * ctx.p.D₀ + 0) true)
              (jobLevelLiveSlots m (rx * ctx.p.D₀ + jx) (decide (jx + 1 = (wRead m 19 (rx : ℤ)).toNat))) ∧
            oldSp ≠ (wRead m 23 (((8 * (rx * ctx.p.D₀ + jx) + 2 : ℕ) : ℤ))).toNat := by
        intro rx hrx hne_x h16x jx hjx
        refine ⟨?_, ?_⟩
        · rw [hlv'_i0, Finset.disjoint_left]
          intro s hs1 hs2
          have hsub_x : s ∈ jobLevelSlotSet m (rx * ctx.p.D₀ + jx) :=
            jobLevelLiveSlots_subset_slotSet m _ _ hs2
          have hn6 := hjobSlot_ne6 rx hrx hne_x h16x jx hjx s hsub_x
          simp only [Finset.mem_insert, Finset.mem_singleton] at hs1
          rcases hs1 with c1 | c2 | c3 | c4 <;> subst s
          · exact hn6.2.2.2.2.1 rfl
          · exact hn6.2.1 rfl
          · exact hn6.2.2.1 rfl
          · exact hn6.2.2.2.1 rfl
        · have hb_in : (wRead m 23 (((8 * (rx * ctx.p.D₀ + jx) + 2 : ℕ) : ℤ))).toNat ∈
              jobLevelSlotSet m (rx * ctx.p.D₀ + jx) := by
            unfold jobLevelSlotSet; simp
          exact (hjobSlot_ne6 rx hrx hne_x h16x jx hjx _ hb_in).1.symm
      by_cases h1 : r₁ = i
      · subst r₁; rw [hw19_i', Int.toNat_one] at hj₁ ⊢
        have hj1_0 : j₁ = 0 := by omega
        subst j₁
        have h2 : r₂ ≠ i := by
          intro heq
          rcases hne with h | hj
          · exact h heq.symm
          · rw [heq, hw19_i', Int.toNat_one] at hj₂; omega
        rw [hw16_ne' r₂ h2] at h16₂; rw [hw19_ne' r₂ h2] at hj₂ ⊢
        have hj2_D0 : j₂ < ctx.p.D₀ := lt_of_lt_of_le hj₂ (hEnc_act r₂ j₂ hr₂ h16₂ hj₂).1
        have hdec : decide (0 + 1 = 1) = true := rfl
        rw [hdec, hlv'_ne r₂ hr₂ h2 h16₂ j₂ hj₂, hw23_ne' r₂ h2 j₂ hj2_D0 2 (by decide),
            Nat.add_zero, hw23_i0.1, Int.toNat_natCast]
        exact hCross r₂ hr₂ h2 h16₂ j₂ hj₂
      · by_cases h2 : r₂ = i
        · subst r₂; rw [hw19_i', Int.toNat_one] at hj₂ ⊢
          have hj2_0 : j₂ = 0 := by omega
          subst j₂
          rw [hw16_ne' r₁ h1] at h16₁; rw [hw19_ne' r₁ h1] at hj₁ ⊢
          have hj1_D0 : j₁ < ctx.p.D₀ := lt_of_lt_of_le hj₁ (hEnc_act r₁ j₁ hr₁ h16₁ hj₁).1
          have hdec : decide (0 + 1 = 1) = true := rfl
          have hi0 : i * ctx.p.D₀ + 0 = i * ctx.p.D₀ := Nat.add_zero _
          rw [hdec, hlv'_ne r₁ hr₁ h1 h16₁ j₁ hj₁, hw23_ne' r₁ h1 j₁ hj1_D0 2 (by decide),
              hi0, hw23_i0.1, Int.toNat_natCast]
          rcases hCross r₁ hr₁ h1 h16₁ j₁ hj₁ with ⟨hd_c, hne_c⟩
          rw [hi0] at hd_c
          exact ⟨hd_c.symm, hne_c.symm⟩
        · rw [hw16_ne' r₁ h1] at h16₁; rw [hw16_ne' r₂ h2] at h16₂
          rw [hw19_ne' r₁ h1] at hj₁ ⊢; rw [hw19_ne' r₂ h2] at hj₂ ⊢
          have hj1_D0 : j₁ < ctx.p.D₀ := lt_of_lt_of_le hj₁ (hEnc_act r₁ j₁ hr₁ h16₁ hj₁).1
          have hj2_D0 : j₂ < ctx.p.D₀ := lt_of_lt_of_le hj₂ (hEnc_act r₂ j₂ hr₂ h16₂ hj₂).1
          rw [hlv'_ne r₁ hr₁ h1 h16₁ j₁ hj₁, hlv'_ne r₂ hr₂ h2 h16₂ j₂ hj₂,
              hw23_ne' r₁ h1 j₁ hj1_D0 2 (by decide), hw23_ne' r₂ h2 j₂ hj2_D0 2 (by decide)]
          exact hlv_lv r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne
  -- Assemble MidLoopUncut ctx b (i + 1) m'
  have h0_ne : (0 : ℕ) ≠ oldSp ∧ 0 ≠ dS0 ∧ 0 ≠ spDS0 ∧ 0 ≠ rS0 ∧ 0 ≠ spRS0 ∧ 0 ≠ dummySp :=
    ⟨by omega, by omega, by omega, by omega, by omega, by omega⟩
  have hleaf_ne : leafS ≠ oldSp ∧ leafS ≠ dS0 ∧ leafS ≠ spDS0 ∧ leafS ≠ rS0 ∧ leafS ≠ spRS0 ∧ leafS ≠ dummySp :=
    ⟨(hDisj_m.2.1 i hi oldSp holdSp_in_sn).2.symm,
     hdS0_np.2.1.symm, hspDS0_np.2.1.symm, hrS0_np.2.1.symm, hspRS0_np.2.1.symm, hdum_np.2.1.symm⟩
  refine ⟨hw27',
    fun hb => hGood₀ (hb_good hb).1,
    hSeg', hSave', hLive',
    hw1_5'.trans hw15_m,
    (hw6_not6' 0 h0_ne.1 h0_ne.2.1 h0_ne.2.2.1 h0_ne.2.2.2.1 h0_ne.2.2.2.2.1 h0_ne.2.2.2.2.2).trans hw60_m,
    hSegPres' 0 (by have := ctx.hSlots_cap; omega) h0_ne.2.1 h0_ne.2.2.1 h0_ne.2.2.2.1 h0_ne.2.2.2.2.1 h0_ne.2.2.2.2.2 _ _ hSeg0_m,
    leafS, hleaf0, hleaf_lt,
    hw1_6'.trans hw16_m,
    (hw6_not6' leafS hleaf_ne.1 hleaf_ne.2.1 hleaf_ne.2.2.1 hleaf_ne.2.2.2.1 hleaf_ne.2.2.2.2.1 hleaf_ne.2.2.2.2.2).trans hw6leaf_m,
    hSegPres' leafS hleaf_lt hleaf_ne.2.1 hleaf_ne.2.2.1 hleaf_ne.2.2.2.1 hleaf_ne.2.2.2.2.1 hleaf_ne.2.2.2.2.2 _ _ hSegLeaf_m,
    hDisj', ?_, ?_⟩
  · -- Done nodes r < i + 1
    intro r hr_lt
    by_cases hri : r.val = i
    · have hr_eq : r = r_fin := Fin.ext hri
      subst hr_eq
      rcases (hTodo_m r_fin le_rfl).2.1 with
        ⟨dS_x, _, _, _, _, _, _, _, hbc_x, hage_x, hw14_x, _, h6_dx, _, hrO_x, hrV_x, hSegDx, _, _⟩
      have hd_eq : dS_x = dS_i := by rw [hw14_i] at hw14_x; exact_mod_cast hw14_x.symm
      subst dS_x
      let lv_h0 : JobLvData ctx.d :=
        { S_birth := ctx.S_post_h r_fin
          snapPts := ctx.P'.handleCoords
          prov := prov
          openRem := jobDeadlineTicks (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.S_post_u r_fin).card }
      refine ⟨some g₀, hInv_g0, ?_, ?_, ?_⟩
      · intro hb g hg
        injection hg with hgeq; subst hgeq
        intro j hj
        have hj0 : j = 0 := by simp [g₀, ActiveJobGhost.start] at hj; omega
        subst hj0
        have hcp := (hb_good hb).2
        have hbeq := hball0' hb_pos
        dsimp only at hcp hbeq
        change IsCenterpoint _ _ (liftedPoint (selectOpenedLevelBall _ _ _ _ _).o
          ((selectOpenedLevelBall _ _ _ _ _).V + ‖(selectOpenedLevelBall _ _ _ _ _).o‖ ^ 2))
        rwa [← hbeq]
      · refine ⟨dS_i, dummySp, ∅, hdS_i0, hdS_i_lt, hdum_pos, hdum_lt, hdSi_ne.2.2.2.2,
          (hw_bc' i).trans hbc_x, (hw_age' i).trans hage_x,
          (hw14' _).trans hw14_i, hw15_i',
          (hw6_not6' dS_i hne_dS_oldSp hdSi_ne.1 hdSi_ne.2.1 hdSi_ne.2.2.1 hdSi_ne.2.2.2.1 hdSi_ne.2.2.2.2).trans h6_dx,
          h6_dum', fun c => (hrO' _).trans (hrO_x c), (hrV' _).trans hrV_x,
          hSegPres' dS_i hdS_i_lt hdSi_ne.1 hdSi_ne.2.1 hdSi_ne.2.2.1 hdSi_ne.2.2.2.1 hdSi_ne.2.2.2.2 _ _ hSegDx,
          hEmp_dum', fun h => by cases h⟩
      · refine ⟨hw16_i', ?_, hwCl_i', hw19_i', [lv_h0], rfl, ?_⟩
        · change wRead m' ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) =
            (((jobDeadlineTicks _ (ctx.S_post_u r_fin).card - 0 : ℕ) : ℤ))
          simpa using hwRem_i'
        · intro j hj
          have hj0 : j = 0 := by simp at hj; exact hj
          subst hj0
          refine ⟨hball0' hb_pos, rfl,
            ⟨ctx.uMap'.uidOfH, ctx.uMap'.hOfUid,
              fun h hh => by
                change ctx.uMap'.uidOfH h ∈ ctx.S_post_u r_fin ∧
                  ctx.uMap'.ghostCoords (ctx.uMap'.uidOfH h) = ctx.P'.handleCoords h ∧
                  ctx.uMap'.hOfUid (ctx.uMap'.uidOfH h) = h
                exact hmap_eq ▸ hbij.2.2.1 h hh,
              fun u hu => by
                change ctx.uMap'.hOfUid u ∈ ctx.S_post_h r_fin ∧
                  ctx.uMap'.uidOfH (ctx.uMap'.hOfUid u) = u
                exact hbij.2.2.2 u (hmap_eq.symm ▸ hu)⟩,
            by simpa [jobHandleInput_zero] using hEncLv0',
            by rw [Nat.add_zero]; exact hw23_i0.2.2.2.2.2,
            by change 0 < (wRead m' 23 (((8 * (i * ctx.p.D₀) + 2 : ℕ) : ℤ))).toNat; rw [hw23_i0.1]; simpa using holdSp0,
            by change 0 < (wRead m' 23 (((8 * (i * ctx.p.D₀) + 3 : ℕ) : ℤ))).toNat; rw [hw23_i0.2.1]; simpa using hdS0_pos,
            by change 0 < (wRead m' 23 (((8 * (i * ctx.p.D₀) + 4 : ℕ) : ℤ))).toNat; rw [hw23_i0.2.2.1]; simpa using hspDS0_pos,
            by change 0 < (wRead m' 23 (((8 * (i * ctx.p.D₀) + 5 : ℕ) : ℤ))).toNat; rw [hw23_i0.2.2.2.1]; simpa using hrS0_pos,
            by change 0 < (wRead m' 23 (((8 * (i * ctx.p.D₀) + 6 : ℕ) : ℤ))).toNat; rw [hw23_i0.2.2.2.2.1]; simpa using hspRS0_pos,
            fun hlt => by simp at hlt,
            fun _ => ⟨by simpa using hw24_i0.1, by simpa using hw24_i0.2, rfl⟩⟩
    · have hr_lt_i : r.val < i := by omega
      rcases hDone_m r hr_lt_i with ⟨oj, hInv, hGood_r, hHdr, hOwn⟩
      refine ⟨oj, hInv, fun hb g hg => hGood_r (hb_good hb).1 g hg,
        hHdr.frame_other (hw_bc' _) (hw_age' _) (hw14' _) (hw15_ne' r.val hri)
          (fun s hs => by
            have hn := hsn_ne6 r.val r.isLt hri s hs
            exact hw6_not6' s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2.1 hn.2.2.2.2.2)
          (fun _ => hrO' _) (hrV' _)
          (fun s hs hlt _ _ hE => by
            have hn := hsn_ne6 r.val r.isLt hri s hs
            exact hSegPres' s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2.1 hn.2.2.2.2.2 _ _ hE),
        hOwn.frame_other
          (fun g _ => by rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2))
          (hw16_ne' r.val hri) (hwRem_ne' r.val hri) (hwCl_ne' r.val hri) (hw19_ne' r.val hri)
          (hw23_ne' r.val hri) (hw24_ne' r.val hri) (hr23_ne' r.val hri) (hr24_ne' r.val hri)
          (fun j hj h16 s hs => by
            have hn := hjobSlot_ne6 r.val r.isLt hri h16 j hj s hs
            exact hw6_not6' s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2.1 hn.2.2.2.2.2)
          (fun j hj h16 s hs hlt _ _ _ hE => by
            have hn := hjobSlot_ne6 r.val r.isLt hri h16 j hj s hs
            exact hSegPres' s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2.1 hn.2.2.2.2.2 _ _ hE)
          hw11' hr11'⟩
  · -- Todo nodes r ≥ i + 1
    intro r hr_ge
    have hri : r.val ≠ i := by omega
    rcases hTodo_m r (by omega) with ⟨haff_w, hHdr, hGood_r, hTd⟩
    refine ⟨(hw_aff' _).trans haff_w,
      hHdr.frame_other (hw_bc' _) (hw_age' _) (hw14' _) (hw15_ne' r.val hri)
        (fun s hs => by
          have hn := hsn_ne6 r.val r.isLt hri s hs
          exact hw6_not6' s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2.1 hn.2.2.2.2.2)
        (fun _ => hrO' _) (hrV' _)
        (fun s hs hlt _ _ hE => by
          have hn := hsn_ne6 r.val r.isLt hri s hs
          exact hSegPres' s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2.1 hn.2.2.2.2.2 _ _ hE),
      fun hb g hg => hGood_r (hb_good hb).1 g hg,
      hTd.frame_other
        (hw16_ne' r.val hri) (hwRem_ne' r.val hri) (hwCl_ne' r.val hri) (hw19_ne' r.val hri)
        (hw23_ne' r.val hri) (hw24_ne' r.val hri) (hr23_ne' r.val hri) (hr24_ne' r.val hri)
        (fun j hj h16 s hs => by
          have hn := hjobSlot_ne6 r.val r.isLt hri h16 j hj s hs
          exact hw6_not6' s hn.1 hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2.1 hn.2.2.2.2.2)
        (fun j hj h16 s hs hlt _ _ _ hE => by
          have hn := hjobSlot_ne6 r.val r.isLt hri h16 j hj s hs
          exact hSegPres' s hlt hn.2.1 hn.2.2.1 hn.2.2.2.1 hn.2.2.2.2.1 hn.2.2.2.2.2 _ _ hE)
        hw11' hr11'⟩

end UL.Proof_lem_7_2_RacerP46
