import UL.Proof.lem_7_2.CG01_MidGlueB
import UL.Proof.lem_7_2.CG04_PreFinal

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Exact Integer Gate Equivalence & Residual Helpers -/

lemma cg18_canOpenResidualLevel_iff_mul_le {D rem m : ℕ} (hD : 3 ≤ D) :
    CanOpenResidualLevel (1 / (4 * ((D : ℝ) ^ 2))) rem m ↔
      (16384 * D ^ 2) * rem ≤ m := by
  unfold CanOpenResidualLevel scheduleCStar
  have hD_pos : (0 : ℝ) < (D : ℝ) := by exact_mod_cast (by omega : 0 < D)
  have hden_pos : (0 : ℝ) < 16384 * (D : ℝ) ^ 2 := by positivity
  have hrhs_eq : (1 / (4 * (D : ℝ) ^ 2)) * (m : ℝ) / ((4096 : ℕ) : ℝ) =
      (m : ℝ) / (16384 * (D : ℝ) ^ 2) := by
    push_cast
    ring
  rw [hrhs_eq, le_div_iff₀ hden_pos]
  have hlhs_eq : (rem : ℝ) * (16384 * (D : ℝ) ^ 2) = (((16384 * D ^ 2 * rem : ℕ) : ℝ)) := by
    push_cast
    ring
  rw [hlhs_eq]
  exact Nat.cast_le

lemma cg18_card_eq_of_bij_on {S T : Finset ℕ} {f g : ℕ → ℕ}
    (hf : ∀ x ∈ S, f x ∈ T ∧ g (f x) = x)
    (hg : ∀ y ∈ T, g y ∈ S ∧ f (g y) = y) :
    S.card = T.card := by
  refine Finset.card_bij (fun x _ => f x) (fun x hx => (hf x hx).1) ?_ ?_
  · intro x₁ hx₁ x₂ hx₂ heq
    have h := congrArg g heq
    rwa [(hf x₁ hx₁).2, (hf x₂ hx₂).2] at h
  · intro y hy
    exact ⟨g y, (hg y hy).1, (hg y hy).2⟩

lemma cg18_jobHandleInput_eq_prefixResidual_take {d : ℕ} (D : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) :
    ∀ (lvs_h : List (JobLvData d)) (lvs_u : List (OpenedJobLevel d ℕ))
      (S₀ : Finset ℕ) (hlen : lvs_h.length = lvs_u.length)
      (_ : ∀ (k : ℕ) (hk : k < lvs_h.length),
        (lvs_h[k]'hk).ball D = (lvs_u[k]'(hlen ▸ hk)).ball)
      {j : ℕ} (_ : j ≤ lvs_h.length),
      jobHandleInput D pts lvs_h S₀ j = prefixResidual pts (lvs_u.take j) S₀
  | _, _, _, _, _, 0, _ => by simp [prefixResidual]
  | [], _, _, _, _, _ + 1, hj => by simp at hj
  | _ :: _, [], _, hlen, _, _ + 1, _ => by simp at hlen
  | lv_h :: rest_h, lv_u :: rest_u, S₀, hlen, hballs, j + 1, hj => by
      simp only [List.length_cons, Nat.add_right_cancel_iff] at hlen
      simp only [List.length_cons, Nat.add_le_add_iff_right] at hj
      have hb0 : lv_h.ball D = lv_u.ball := hballs 0 (by simp)
      dsimp only [jobHandleInput, List.take_succ_cons]
      have hp_cons : prefixResidual pts (lv_u :: rest_u.take j) S₀ =
          prefixResidual pts (rest_u.take j) (lv_u.ball.residual pts S₀) := rfl
      rw [hp_cons, hb0]
      exact cg18_jobHandleInput_eq_prefixResidual_take D pts rest_h rest_u _ hlen
        (fun k hk => hballs (k + 1) (Nat.succ_lt_succ hk)) hj

/-! ### 2. Post-EndAction Active-Job State & Pure Deadline Splice -/

structure PostEndActionJobState (ctx : MidLoopCtx) (gFlag : Bool)
    (i : ℕ) (hi : i < ctx.st₀.k) (m : ArithRAMMemory)
    (g' : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u ⟨i, hi⟩)) : Prop where
  hw27 : wRead m 26 27 = 0
  hGood₀ : gFlag = true → ∀ r : Fin ctx.st₀.k,
    IsCenterpoint (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2))
      (paraboloidLiftSet (fun u : ↥(ctx.st₀.birthSnap r) => ctx.st₀.uMap.ghostCoords u.1))
      (liftedPoint (ctx.st₀.nodes r).o ((ctx.st₀.nodes r).V + ‖(ctx.st₀.nodes r).o‖ ^ 2))
  hGood_i : gFlag = true → JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g'.lvs
  hage_eq : ctx.snAge' ⟨i, hi⟩ =
    jobStartAge (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.st₀.birthSnap ⟨i, hi⟩).card + g'.t_cur
  hm0_le : (g'.S_root 0).card ≤
    (ctx.st₀.birthSnap ⟨i, hi⟩).card +
      jobStartAge (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.st₀.birthSnap ⟨i, hi⟩).card
  hSeg : SegGenBound ctx.p.K_seg ctx.p.NumSlots m
  hSave : SaveGenBound ctx.n ctx.p.NumSlots m
  hLive : EncLiveCoords ctx.d ctx.n m ctx.P'.activeHandles ctx.P'.handleCoords
  hw1_5 : wRead m 1 5 = (ctx.st₀.k : ℤ)
  hw6_0 : wRead m 6 0 = 0
  hSeg0 : EncSegSlot ctx.p.K_seg m 0 ctx.P'.activeHandles (fun _ => 0)
  hChainRest :
    ∃ leafS : ℕ,
      0 < leafS ∧ leafS < ctx.p.NumSlots ∧
      wRead m 1 6 = (leafS : ℤ) ∧
      wRead m 6 (leafS : ℤ) = 0 ∧
      EncSegSlot ctx.p.K_seg m leafS
        (chainTerminal ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles) (fun _ => 0) ∧
      GlobalSlotDisj ctx.p.D₀ m ctx.st₀.k leafS
  hHdr_i : EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' i (ctx.st₀.nodes ⟨i, hi⟩)
    (ctx.st₀.birthSnap ⟨i, hi⟩).card (ctx.snAge' ⟨i, hi⟩) (ctx.S_post_h ⟨i, hi⟩) false
  hOwn_i : EncOwnedJobAt ctx.cfg ctx.p m ctx.P' ctx.uMap' i
    (ctx.S_post_h ⟨i, hi⟩) (ctx.S_post_u ⟨i, hi⟩) (some g')
  hDone : ∀ (r : Fin ctx.st₀.k), r.val < i →
    ∃ oj : Option (ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
        ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u r)),
      ServingOwnedJobInv (ctx.st₀.birthSnap r) (ctx.snAge' r) oj ∧
      (gFlag = true → ∀ g, oj = some g → JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g.lvs) ∧
      EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' r.val (ctx.st₀.nodes r)
        (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) oj.isNone ∧
      EncOwnedJobAt ctx.cfg ctx.p m ctx.P' ctx.uMap' r.val (ctx.S_post_h r) (ctx.S_post_u r) oj
  hTodo : ∀ (r : Fin ctx.st₀.k), i + 1 ≤ r.val →
    wRead m ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r.val : ℤ) =
      (if ctx.aff r.castSucc then 1 else 0) ∧
    EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' r.val (ctx.st₀.nodes r)
      (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) (ctx.st₀.ownedJob r).isNone ∧
    (gFlag = true → ∀ g, ctx.st₀.ownedJob r = some g →
      JobLevelsCenterGood (ctx.d + 3) ctx.st₀.uMap.ghostCoords g.lvs) ∧
    EncTodoJobAt ctx m r

lemma PostEndActionJobState.to_uncut {ctx : MidLoopCtx} {gFlag : Bool}
    {i : ℕ} {hi : i < ctx.st₀.k} {m : ArithRAMMemory}
    {g' : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u ⟨i, hi⟩)}
    (hSt : PostEndActionJobState ctx gFlag i hi m g')
    (ht_lt : g'.t_cur < g'.H_job) :
    MidLoopUncut ctx gFlag (i + 1) m := by
  rcases hSt.hChainRest with ⟨leafS, hl0, hllt, hw1_6, hw6_leaf, hSegLeaf, hDisj⟩
  refine ⟨hSt.hw27, hSt.hGood₀, hSt.hSeg, hSt.hSave, hSt.hLive,
    hSt.hw1_5, hSt.hw6_0, hSt.hSeg0,
    leafS, hl0, hllt, hw1_6, hw6_leaf, hSegLeaf, hDisj,
    ?_, hSt.hTodo⟩
  intro r hr_lt
  by_cases hri : r.val = i
  · have hr_eq : r = ⟨i, hi⟩ := Fin.ext hri
    subst hr_eq
    refine ⟨some g', ⟨ht_lt, hSt.hage_eq, hSt.hm0_le⟩, ?_, hSt.hHdr_i, hSt.hOwn_i⟩
    intro hgF g hg
    injection hg with hgeq
    subst hgeq
    exact hSt.hGood_i hgF
  · exact hSt.hDone r (by omega)

theorem PostEndActionJobState.deadline_pure
    (h_lem_C_2 : S_lem_C_2)
    {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ} {hi : i < ctx.st₀.k} {m : ArithRAMMemory}
    {g' : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u ⟨i, hi⟩)}
    (hSt : PostEndActionJobState ctx gFlag i hi m g')
    (hdone : g'.t_cur = g'.H_job) :
    g'.ph_cur = 2 ∧
    ∃ st_mid : PureServingState ctx.d ctx.n ctx.H ctx.p.L ctx.p.B_scan ctx.P',
      st_mid.uMap = ctx.uMap' ∧
      st_mid.k = i + g'.lvs.length ∧
      st_mid.k < ctx.p.D₀ ∧
      st_mid.NodesInv ∧
      (chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles).card ≤
        4 * ctx.p.L + 2 ∧
      (gFlag = true → st_mid.AllCentersGood) ∧
      (∀ (a : ℕ) (ha : a < i) (ha_mid : a < st_mid.k),
        st_mid.nodes ⟨a, ha_mid⟩ = ctx.st₀.nodes ⟨a, lt_trans ha hi⟩ ∧
        EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' a (st_mid.nodes ⟨a, ha_mid⟩)
          (st_mid.birthSnap ⟨a, ha_mid⟩).card (st_mid.snAge ⟨a, ha_mid⟩)
          (chainInput ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles (⟨a, ha_mid⟩ : Fin st_mid.k).castSucc)
          (st_mid.ownedJob ⟨a, ha_mid⟩).isNone ∧
        EncOwnedJobAt ctx.cfg ctx.p m ctx.P' st_mid.uMap a
          (chainInput ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles (⟨a, ha_mid⟩ : Fin st_mid.k).castSucc)
          (chainInput st_mid.uMap.ghostCoords st_mid.nodes st_mid.uMap.ActiveUids (⟨a, ha_mid⟩ : Fin st_mid.k).castSucc)
          (st_mid.ownedJob ⟨a, ha_mid⟩)) ∧
      (∀ (j : ℕ) (hj : j < g'.lvs.length) (hj_mid : i + j < st_mid.k),
        st_mid.nodes ⟨i + j, hj_mid⟩ = (g'.lvs[j]'hj).ball ∧
        st_mid.birthSnap ⟨i + j, hj_mid⟩ = (g'.lvs[j]'hj).birthSnapshot ∧
        st_mid.snAge ⟨i + j, hj_mid⟩ = g'.openRem j ∧
        st_mid.ownedJob ⟨i + j, hj_mid⟩ = none ∧
        chainInput ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles (⟨i + j, hj_mid⟩ : Fin st_mid.k).castSucc =
          prefixResidual ctx.P'.handleCoords (g'.lvs.take j) (ctx.S_post_h ⟨i, hi⟩)) ∧
      chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles =
        prefixResidual ctx.P'.handleCoords g'.lvs (ctx.S_post_h ⟨i, hi⟩) := by
  classical
  have hD3 : 3 ≤ ctx.d + 3 := by omega
  rcases g'.finishAtDeadline h_lem_C_2 hD3 ctx.hL_floor ctx.hL_eq10 ctx.hB_floor hdone
    with ⟨_, hph2_g', hres_le, hlvs_props⟩
  let jLen := g'.lvs.length
  let k_mid := i + jLen
  let nodes_mid : Fin k_mid → ChainNode ctx.d := fun idx =>
    if hlt : idx.val < i then
      ctx.st₀.nodes ⟨idx.val, lt_trans hlt hi⟩
    else
      (g'.lvs[idx.val - i]'(by have := idx.isLt; dsimp [k_mid, jLen] at this; omega)).ball
  have hpre_nodes : ∀ a (ha : a < i),
      nodes_mid ⟨a, lt_of_lt_of_le ha (Nat.le_add_right _ _)⟩ =
        ctx.st₀.nodes ⟨a, lt_trans ha hi⟩ :=
    fun _ ha => dif_pos ha
  have hsuf_nodes : ∀ j (hj : j < g'.lvs.length),
      nodes_mid ⟨i + j, Nat.add_lt_add_left hj i⟩ = (g'.lvs[j]'hj).ball := by
    intro j hj
    dsimp only [nodes_mid]
    rw [dif_neg (by omega)]
    have hsub : i + j - i = j := by omega
    simp [hsub]
  have hpre_u : ∀ a (ha : a < i),
      ctx.S_post_u ⟨a, lt_trans ha hi⟩ =
        chainInput ctx.uMap'.ghostCoords nodes_mid ctx.uMap'.ActiveUids
          ⟨a, Nat.lt_succ_of_lt (lt_of_lt_of_le ha (Nat.le_add_right _ _))⟩ := by
    intro a ha
    exact cg01_chainInput_congr_prefix ctx.st₀.nodes nodes_mid (fun _ _ => rfl)
      a (le_of_lt (lt_trans ha hi)) (le_of_lt (lt_of_lt_of_le ha (Nat.le_add_right _ _)))
      (fun x hx => (hpre_nodes x (lt_trans hx ha)).symm)
  have hpre_h : ∀ a (ha : a < i),
      ctx.S_post_h ⟨a, lt_trans ha hi⟩ =
        chainInput ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles
          ⟨a, Nat.lt_succ_of_lt (lt_of_lt_of_le ha (Nat.le_add_right _ _))⟩ := by
    intro a ha
    exact cg01_chainInput_congr_prefix ctx.st₀.nodes nodes_mid (fun _ _ => rfl)
      a (le_of_lt (lt_trans ha hi)) (le_of_lt (lt_of_lt_of_le ha (Nat.le_add_right _ _)))
      (fun x hx => (hpre_nodes x (lt_trans hx ha)).symm)
  have hsuf_age : ∀ j (hj : j < jLen),
      ∃ ta : ℕ, ta ≤ g'.openRem j ∧
        HasNodeAge (g'.lvs[j]'hj).birthSnapshot
          (chainInput ctx.uMap'.ghostCoords nodes_mid ctx.uMap'.ActiveUids
            ⟨i + j, Nat.lt_succ_of_lt (Nat.add_lt_add_left hj i)⟩) ta := by
    intro j hj
    rcases (hlvs_props j hj).2.2.2.2.2.2 with ⟨ta, hta_le, hta_age⟩
    have hsp := cg01_chainInput_splice_suffix ctx.uMap'.ghostCoords ctx.st₀.nodes g'.lvs
      (le_of_lt hi) nodes_mid hpre_nodes hsuf_nodes ctx.uMap'.ActiveUids j (le_of_lt hj)
    exact ⟨ta, hta_le, hsp.symm ▸ hta_age⟩
  choose ta_suf hta_suf using hsuf_age
  have hoj_ex : ∀ idx : Fin k_mid,
      ∃ oj : Option (ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
          ctx.uMap'.nextUid ctx.uMap'.ghostCoords
          (chainInput ctx.uMap'.ghostCoords nodes_mid ctx.uMap'.ActiveUids idx.castSucc)),
        if hlt : idx.val < i then
          let i_old : Fin ctx.st₀.k := ⟨idx.val, lt_trans hlt hi⟩
          ServingOwnedJobInv (ctx.st₀.birthSnap i_old) (ctx.snAge' i_old) oj ∧
          (gFlag = true → ∀ g, oj = some g → JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g.lvs) ∧
          EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' idx.val (ctx.st₀.nodes i_old)
            (ctx.st₀.birthSnap i_old).card (ctx.snAge' i_old)
            (chainInput ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles idx.castSucc) oj.isNone ∧
          EncOwnedJobAt ctx.cfg ctx.p m ctx.P' ctx.uMap' idx.val
            (chainInput ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles idx.castSucc)
            (chainInput ctx.uMap'.ghostCoords nodes_mid ctx.uMap'.ActiveUids idx.castSucc) oj
        else
          oj = none := by
    intro idx
    by_cases hlt : idx.val < i
    · let i_old : Fin ctx.st₀.k := ⟨idx.val, lt_trans hlt hi⟩
      rcases hSt.hDone i_old hlt with ⟨oj₀, hInv₀, hGood_j, hHdr_j, hOwn_j⟩
      rw [hpre_h idx.val hlt] at hHdr_j hOwn_j
      cases hoj₀ : oj₀ with
      | none =>
          rw [hoj₀] at hInv₀ hGood_j hHdr_j hOwn_j
          refine ⟨none, ?_⟩
          rw [dif_pos hlt]
          exact ⟨hInv₀, (fun _ _ h => by cases h), hHdr_j, hOwn_j⟩
      | some g₀ =>
          rw [hoj₀] at hInv₀ hGood_j hHdr_j hOwn_j
          let g₁ := g₀.castPool (hpre_u idx.val hlt)
          refine ⟨some g₁, ?_⟩
          rw [dif_pos hlt]
          refine ⟨(servingOwnedJobInv_castPool (hpre_u idx.val hlt) _ _ (some g₀)).mpr hInv₀,
            ?_, hHdr_j, hOwn_j.castPool (hpre_u idx.val hlt)⟩
          intro hgF g hg
          injection hg with hgeq; subst hgeq
          exact hGood_j hgF g₀ rfl
    · refine ⟨none, ?_⟩
      rw [dif_neg hlt]
  choose oj_mid hoj_mid using hoj_ex
  let st_mid : PureServingState ctx.d ctx.n ctx.H ctx.p.L ctx.p.B_scan ctx.P' :=
    { uMap := ctx.uMap'
      k := k_mid
      nodes := nodes_mid
      birthSnap := fun idx =>
        if hlt : idx.val < i then
          ctx.st₀.birthSnap ⟨idx.val, lt_trans hlt hi⟩
        else
          (g'.lvs[idx.val - i]'(by have := idx.isLt; dsimp [k_mid, jLen] at this; omega)).birthSnapshot
      snAge := fun idx =>
        if hlt : idx.val < i then
          ctx.snAge' ⟨idx.val, lt_trans hlt hi⟩
        else
          g'.openRem (idx.val - i)
      trueAge := fun idx =>
        if hlt : idx.val < i then
          ctx.trueAge' ⟨idx.val, lt_trans hlt hi⟩
        else
          ta_suf (idx.val - i) (by have := idx.isLt; dsimp [k_mid, jLen] at this; omega)
      ownedJob := oj_mid }
  have hinv₀ := ctx.hwf₀.1
  have hNodesInv : st_mid.NodesInv := by
    intro idx
    have hoj_idx := hoj_mid idx
    by_cases hlt : idx.val < i
    · rw [dif_pos hlt] at hoj_idx
      let i_old : Fin ctx.st₀.k := ⟨idx.val, lt_trans hlt hi⟩
      have hbs : st_mid.birthSnap idx = ctx.st₀.birthSnap i_old := dif_pos hlt
      have hsn_eq : st_mid.snAge idx = ctx.snAge' i_old := dif_pos hlt
      have htr_eq : st_mid.trueAge idx = ctx.trueAge' i_old := dif_pos hlt
      have hnod_eq : st_mid.nodes idx = ctx.st₀.nodes i_old := dif_pos hlt
      have hoj_eq : st_mid.ownedJob idx = oj_mid idx := rfl
      rcases hinv₀ i_old with ⟨hb_pos, hb_uid, hb_pass, _, _, _⟩
      dsimp only [PureServingState.NodesInv]
      rw [hbs, hsn_eq, htr_eq, hnod_eq, hoj_eq]
      exact ⟨hb_pos,
        fun u hu => lt_of_lt_of_le (hb_uid u hu) ctx.hle_uid,
        (passesBirthCoreCheck_congr_on _ _ (fun u hu => ctx.hag_uid u (hb_uid u hu))).mpr hb_pass,
        ctx.htr_le' i_old,
        (hpre_u idx.val hlt) ▸ ctx.hhas_age' i_old,
        hoj_idx.1⟩
    · rw [dif_neg hlt] at hoj_idx
      let j := idx.val - i
      have hlt_k : idx.val < i + jLen := idx.isLt
      have hj_lt : j < jLen := by dsimp only [j] at *; omega
      have hidx_eq : idx = ⟨i + j, Nat.add_lt_add_left hj_lt i⟩ := by ext; dsimp only [j]; omega
      have hbs : st_mid.birthSnap idx = (g'.lvs[j]'hj_lt).birthSnapshot := dif_neg hlt
      have hsn_eq : st_mid.snAge idx = g'.openRem j := dif_neg hlt
      have htr_eq : st_mid.trueAge idx = ta_suf j hj_lt := dif_neg hlt
      have hnod_j : st_mid.nodes idx = (g'.lvs[j]'hj_lt).ball := by
        change nodes_mid idx = _; rw [hidx_eq]; exact hsuf_nodes j hj_lt
      have hoj_eq : st_mid.ownedJob idx = oj_mid idx := rfl
      have hp_j := hlvs_props j hj_lt
      dsimp only [PureServingState.NodesInv]
      rw [hbs, hsn_eq, htr_eq, hnod_j, hoj_eq, hoj_idx]
      refine ⟨by have := hp_j.2.1; omega, hp_j.2.2.1, hp_j.2.2.2.1,
        (hta_suf j hj_lt).1, ?_, hp_j.2.2.2.2.1⟩
      have hage_j := (hta_suf j hj_lt).2
      have hcast_eq : idx.castSucc = ⟨i + j, Nat.lt_succ_of_lt (Nat.add_lt_add_left hj_lt i)⟩ := by
        ext; simp only [Fin.val_castSucc]; dsimp [j]; omega
      rwa [hcast_eq]
  have hk_mid_lt : st_mid.k < ctx.p.D₀ := by
    rw [ctx.hD0_eq]
    exact (st_mid.chainLen_and_jobLen_lt ctx.hP' ctx.hH5 ctx.hn2 hNodesInv).1
  have hTerm_le : (chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles).card ≤
      4 * ctx.p.L + 2 := by
    have hterm_uid : chainTerminal ctx.uMap'.ghostCoords nodes_mid ctx.uMap'.ActiveUids =
        prefixResidual ctx.uMap'.ghostCoords g'.lvs (ctx.S_post_u ⟨i, hi⟩) :=
      cg01_chainTerminal_splice ctx.uMap'.ghostCoords ctx.st₀.nodes g'.lvs (le_of_lt hi)
        nodes_mid hpre_nodes hsuf_nodes ctx.uMap'.ActiveUids
    have hcard_eq : (chainTerminal ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles).card =
        (chainTerminal ctx.uMap'.ghostCoords nodes_mid ctx.uMap'.ActiveUids).card := by
      rw [← ctx.uMap'.mapSet_chainTerminal nodes_mid]
      exact (ctx.uMap'.mapSet_bij
        (cg01_chainTerminal_subset ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles)).1.symm
    change (chainTerminal ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles).card ≤ 4 * ctx.p.L + 2
    rw [hcard_eq, hterm_uid]
    exact le_trans hres_le (by omega)
  have hGood_mid : gFlag = true → st_mid.AllCentersGood := by
    intro hgF
    have hcg_cut := hSt.hGood_i hgF
    refine ⟨fun idx => ?_, fun idx g hg => ?_⟩
    · by_cases hlt : idx.val < i
      · let i_old : Fin ctx.st₀.k := ⟨idx.val, lt_trans hlt hi⟩
        have hbs : st_mid.birthSnap idx = ctx.st₀.birthSnap i_old := dif_pos hlt
        have hnod_eq : st_mid.nodes idx = ctx.st₀.nodes i_old := dif_pos hlt
        rw [hbs, hnod_eq]
        exact (isCenterpoint_paraboloid_congr_on _ _
          (fun u hu => ctx.hag_uid u ((hinv₀ i_old).2.1 u hu))).mpr (hSt.hGood₀ hgF i_old)
      · let j := idx.val - i
        have hlt_k : idx.val < i + jLen := idx.isLt
        have hj_lt : j < jLen := by dsimp only [j] at *; omega
        have hidx_eq : idx = ⟨i + j, Nat.add_lt_add_left hj_lt i⟩ := by ext; dsimp only [j]; omega
        have hbs : st_mid.birthSnap idx = (g'.lvs[j]'hj_lt).birthSnapshot := dif_neg hlt
        have hnod_j : st_mid.nodes idx = (g'.lvs[j]'hj_lt).ball := by
          change nodes_mid idx = _; rw [hidx_eq]; exact hsuf_nodes j hj_lt
        rw [hbs, hnod_j]
        exact hcg_cut j hj_lt
    · have hoj_idx := hoj_mid idx
      by_cases hlt : idx.val < i
      · rw [dif_pos hlt] at hoj_idx
        exact hoj_idx.2.1 hgF g hg
      · rw [dif_neg hlt] at hoj_idx
        change oj_mid idx = some g at hg
        rw [hoj_idx] at hg; cases hg
  refine ⟨hph2_g', st_mid, rfl, rfl, hk_mid_lt, hNodesInv, hTerm_le, hGood_mid, ?_, ?_, ?_⟩
  · intro a ha ha_mid
    let idx : Fin k_mid := ⟨a, ha_mid⟩
    have hoj_idx := hoj_mid idx
    rw [dif_pos ha] at hoj_idx
    have hnod : st_mid.nodes idx = ctx.st₀.nodes ⟨a, lt_trans ha hi⟩ := dif_pos ha
    have hbs : st_mid.birthSnap idx = ctx.st₀.birthSnap ⟨a, lt_trans ha hi⟩ := dif_pos ha
    have hsn : st_mid.snAge idx = ctx.snAge' ⟨a, lt_trans ha hi⟩ := dif_pos ha
    have hoj_eq : st_mid.ownedJob idx = oj_mid idx := rfl
    refine ⟨hnod, ?_, ?_⟩
    · rw [hnod, hbs, hsn, hoj_eq]
      exact hoj_idx.2.2.1
    · rw [hoj_eq]
      exact hoj_idx.2.2.2
  · intro j hj hj_mid
    let idx : Fin k_mid := ⟨i + j, hj_mid⟩
    have hnot : ¬ (idx.val < i) := by change ¬ (i + j < i); omega
    have hsub : i + j - i = j := by omega
    have hoj_idx := hoj_mid idx
    rw [dif_neg hnot] at hoj_idx
    refine ⟨hsuf_nodes j hj,
      by change (if hlt : i + j < i then _ else _) = _; rw [dif_neg hnot]; simp [hsub],
      by change (if hlt : i + j < i then _ else _) = _; rw [dif_neg hnot, hsub],
      hoj_idx,
      cg01_chainInput_splice_suffix ctx.P'.handleCoords ctx.st₀.nodes g'.lvs
        (le_of_lt hi) nodes_mid hpre_nodes hsuf_nodes ctx.P'.activeHandles j (le_of_lt hj)⟩
  · exact cg01_chainTerminal_splice ctx.P'.handleCoords ctx.st₀.nodes g'.lvs
      (le_of_lt hi) nodes_mid hpre_nodes hsuf_nodes ctx.P'.activeHandles

end UL.Proof_lem_7_2_RacerP46
