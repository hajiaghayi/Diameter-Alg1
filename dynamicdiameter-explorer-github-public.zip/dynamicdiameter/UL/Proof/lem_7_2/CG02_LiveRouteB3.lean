import UL.Proof.lem_7_2.CG02_LiveRouteB2b

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 6. Complete Live Update Routing Subroutine (`routeLiveUpdateStmt`) & `DetExecAt` Proof -/

/-- Explicit worst-case unit-cost bound for `routeLiveUpdateStmt`. -/
def routeLiveUpdateCost (d K D₀ NumSlots : ℕ) : ℕ :=
  200 * (NumSlots + 1) * (d + 1) +
  (D₀ + 2) * (600 * (K + 1) + 150 * (d + 1) + 400) + 600

/-- Full deterministic live update routing RAM subroutine (`fd = 0`):
1. Updates the active handle table (`EncHandlePool`), live coordinate table (`EncLiveCoords`),
   frozen copy-on-delete snapshots (`EncSlotCoords`), and global active-handle segment tree `slot 0`;
2. Scans the `k ≤ D₀` serving nodes, testing core-ball membership (`‖x - o_r‖^2 ≤ V_r`),
   recording per-node clock-tick flags `wRead _ 20 r`, incrementing `snAge[r]`, and updating
   both `snDictSlot[r]` (`updSegCenterStmt`) and `snSpareSlot[r]` (`updSegZeroStmt`);
3. Updates the terminal leaf pool `leafS = wRead _ 1 6` and pops temporary frames. -/
def routeLiveUpdateStmt (d n K D₀ NumSlots M_box : ℕ) : ArithRAMStmt :=
  seqList [
    routePoolAndSlot0Stmt d n K NumSlots M_box,
    boxWriteW M_box 26 (.lit 7) (.lit 0),
    .repeatN (.lit (D₀ : ℤ)) (routeOneServingNodeStmt d K M_box),
    routeTerminalLeafStmt K M_box
  ]

theorem boxSafe_routeLiveUpdateStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max)
    (d n K D₀ NumSlots : ℕ) :
    BoxSafeOuter T_max M_box (routeLiveUpdateStmt d n K D₀ NumSlots M_box) := by
  unfold routeLiveUpdateStmt
  apply boxSafeOuter_seqList
  intro s hs
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact boxSafe_routePoolAndSlot0Stmt hT d n K NumSlots
  · exact .boxW (by omega) _ _
  · exact .repeatN _ (boxSafe_routeOneServingNodeStmt hT d K)
  · exact boxSafe_routeTerminalLeafStmt hT K

theorem exec_routeLiveUpdateStmt {d n K D₀ NumSlots M_box : ℕ}
    (P : DynamicPointSet d) (op : DynamicUpdate d) (mem : ArithRAMMemory)
    {k : ℕ} {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ}
    (hP : P.WellFormed n)
    (hleg : IsLegalUpdate n Set.univ P op)
    (hBox : RouteBoxBounds d n K D₀ NumSlots M_box)
    (hChain : EncServingChain d n K D₀ NumSlots mem P k nodes snAge) :
    let inp := mkStepInput n P op
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    ∃ (mem' : ArithRAMMemory) (P' : DynamicPointSet d) (opH : ℕ),
      let aff : Fin (k + 1) → Bool := chainLevelAffected P P' nodes ins opH
      let snAge' : Fin k → ℕ := fun r => if aff r.castSucc then snAge r + 1 else snAge r
      DetExecAt 0 inp (routeLiveUpdateStmt d n K D₀ NumSlots M_box) mem mem'
        (routeLiveUpdateCost d K D₀ NumSlots) ∧
      mem'.popDepth 0 = mem' ∧
      applyDynamicUpdate P op (readStepRetH op mem') = some P' ∧
      P'.WellFormed n ∧
      EncServingChain d n K D₀ NumSlots mem' P' k nodes snAge' ∧
      opH < n ∧ opH < 2 ^ K ∧
      wRead mem' 26 4 = (opH : ℤ) ∧
      wRead mem' 26 5 = (if ins then 1 else 0) ∧
      (∀ r : Fin k,
        let S_pre := chainInput P.handleCoords nodes P.activeHandles r.castSucc
        let S_post := chainInput P'.handleCoords nodes P'.activeHandles r.castSucc
        wRead mem' 20 (r.val : ℤ) = (if aff r.castSucc then 1 else 0) ∧
        (aff r.castSucc = false → opH ∉ S_pre ∧ opH ∉ S_post ∧ S_post = S_pre) ∧
        (aff r.castSucc = true →
          IsInputChange S_pre S_post ∧
          (ins = true → opH ∉ S_pre ∧ S_post = insert opH S_pre) ∧
          (ins = false → opH ∈ S_pre ∧ S_post = S_pre.erase opH))) ∧
      (match op with
       | .insert _ _ pt =>
           wRead mem' 0 0 = (opH : ℤ) ∧
           opH ∉ P.activeHandles ∧
           P'.activeHandles = insert opH P.activeHandles ∧
           P'.handleCoords opH = pt ∧
           (∀ h ∈ P.activeHandles, P'.handleCoords h = P.handleCoords h)
       | .delete id =>
           opH = P.handleOfId id ∧
           opH ∈ P.activeHandles ∧
           P'.activeHandles = P.activeHandles.erase opH ∧
           (∀ h ∈ P'.activeHandles, P'.handleCoords h = P.handleCoords h)) ∧
      (∀ s < NumSlots, 1 ≤ wRead mem 6 (s : ℤ) → ∀ S snapPts,
        EncSlotCoords d n mem P.activeHandles P.handleCoords s S snapPts →
        EncSlotCoords d n mem' P'.activeHandles P'.handleCoords s S snapPts) ∧
      (∀ s' < NumSlots,
        s' ≠ 0 → s' ≠ (wRead mem 1 6).toNat → (∀ r : Fin k, s' ∉ snSlotSet mem r.val) →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K mem' s' S₁ fSq₁) ∧
      (∀ t, t ≠ 0 → t ≠ 1 → t ≠ 2 → t ≠ 3 → t ≠ 8 → t ≠ 9 → t ≠ 10 →
            t ≠ 11 → t ≠ 13 → t ≠ 20 → t ≠ 26 →
        ∀ idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 0 → wRead mem' 0 idx = wRead mem 0 idx) ∧
      (∀ idx, idx ≠ 0 → idx ≠ 1 → idx ≠ 2 → wRead mem' 1 idx = wRead mem 1 idx) ∧
      (∀ idx, (idx < 0 ∨ (k : ℤ) ≤ idx) → wRead mem' 13 idx = wRead mem 13 idx) ∧
      (∀ t, t ≠ 4 → t ≠ 8 → t ≠ 11 → t ≠ 26 →
        ∀ idx, rRead mem' t idx = rRead mem t idx) := by
  intro inp ins
  have hBox_full := hBox
  rcases hBox with ⟨hBox30, hBoxD0, hBox_n, hBox_nd, hBox_sn, hBox_snd, hBox_seg⟩
  rcases hChain with ⟨hk_le, hnK, hSlots2, hPool, hseg, hsave, hw15, hw60, hSeg0,
    leafS, hleaf_pos, hleaf_lt, hw16, hw6_leaf, hSeg_leaf, hsn, hdisj_0leaf, hdisj_sn⟩
  -- Step 1: Active handle pool + Slot 0
  rcases exec_routePoolAndSlot0Stmt P op mem hP hleg hnK (by omega)
      hBox30 hBox_n hBox_nd hBox_sn hBox_snd hBox_seg hPool hseg hsave hSeg0
    with ⟨mA, P', opH, hex_A, _, happ_A, hWF_A, hPool_A, hseg_A, hsave_A, hSeg0_A,
          hopH_n, hopH_K, hw26_4_A, hw26_5_A, hw26_9_A, hmatch_A, hSlot_A, hOther_A,
          hw_A, hw0_A, hw1_A, hr_A⟩
  let aff : Fin (k + 1) → Bool := chainLevelAffected P P' nodes ins opH
  let S_pre : Fin (k + 1) → Finset ℕ := chainInput P.handleCoords nodes P.activeHandles
  let S_post : Fin (k + 1) → Finset ℕ := chainInput P'.handleCoords nodes P'.activeHandles
  have hAffProps : ∀ j : Fin (k + 1),
      (aff j = false → opH ∉ S_pre j ∧ opH ∉ S_post j ∧ S_post j = S_pre j) ∧
      (aff j = true →
        IsInputChange (S_pre j) (S_post j) ∧
        (ins = true → opH ∉ S_pre j ∧ S_post j = insert opH (S_pre j)) ∧
        (ins = false → opH ∈ S_pre j ∧ S_post j = (S_pre j).erase opH)) := by
    intro j
    cases op with
    | insert _ _ _ =>
        have hsp := cg02_aff_spec_of_ins nodes hmatch_A.2.1 hmatch_A.2.2.1 hmatch_A.2.2.2.2 j
        refine ⟨fun hf => ⟨hsp.1, (hsp.2.2 hf).1, (hsp.2.2 hf).2⟩, fun ht => ?_⟩
        exact ⟨(hsp.2.1 ht).2, fun _ => ⟨hsp.1, (hsp.2.1 ht).1⟩, fun h => Bool.noConfusion h⟩
    | delete _ =>
        have hsp := cg02_aff_spec_of_del nodes hmatch_A.2.2.1 hmatch_A.2.2.2 j
        refine ⟨fun hf => hsp.2.2 hf, fun ht => ?_⟩
        exact ⟨(hsp.2.1 ht).2, fun h => Bool.noConfusion h, fun _ => ⟨(hsp.2.1 ht).1, hsp.1⟩⟩
  have hCoordsOther : ∀ j : Fin (k + 1), ∀ x ∈ S_pre j, x ≠ opH → P'.handleCoords x = P.handleCoords x := by
    intro j x hx hne
    have hx0 : x ∈ P.activeHandles := cg02_chainInput_subset P.handleCoords nodes P.activeHandles j hx
    cases op with
    | insert _ _ _ => exact hmatch_A.2.2.2.2 x hx0
    | delete _ =>
        have hx' : x ∈ P'.activeHandles := by
          rw [hmatch_A.2.2.1]; exact Finset.mem_erase.mpr ⟨hne, hx0⟩
        exact hmatch_A.2.2.2 x hx'
  have hCoordsUnchanged : ∀ j : Fin (k + 1), aff j = false → ∀ x ∈ S_pre j, P'.handleCoords x = P.handleCoords x := by
    intro j hf x hx
    have hnot : opH ∉ S_pre j := ((hAffProps j).1 hf).1
    exact hCoordsOther j x hx (fun heq => hnot (heq ▸ hx))
  have hCtx : RouteLoopCtx d n K D₀ NumSlots M_box k leafS opH P P' nodes snAge ins mem mA :=
    { hBox := hBox_full
      hSlots2 := hSlots2
      hleaf_lt := hleaf_lt
      hopH_K := hopH_K
      hw15_A := by rw [hw1_A 5 (by decide) (by decide) (by decide), hw15]
      hw14_A := hw_A 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
      hw15_tbl_A := hw_A 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
      hLive_A := hPool_A.1
      hsn := hsn
      hdisj_0leaf := hdisj_0leaf
      hdisj_sn := hdisj_sn
      hh_act_ins := fun hins => by
        dsimp only [ins] at hins
        cases op with
        | insert _ _ _ => rw [hmatch_A.2.2.1]; exact Finset.mem_insert_self _ _
        | delete _ => cases hins
      hAffProps := hAffProps
      hCoordsOther := hCoordsOther
      hCoordsUnchanged := hCoordsUnchanged
      hAffInsFalse := fun hins r haff_r => by
        dsimp only [ins] at hins haff_r ⊢
        cases op with
        | insert _ _ _ => exact cg02_aff_step_of_ins_false nodes hmatch_A.2.1 hmatch_A.2.2.1 hmatch_A.2.2.2.2 r haff_r
        | delete _ => cases hins
      hAffInsTrue := fun hins r haff_r => by
        dsimp only [ins] at hins haff_r ⊢
        cases op with
        | insert _ _ _ => exact cg02_aff_step_of_ins_true nodes hmatch_A.2.1 hmatch_A.2.2.1 hmatch_A.2.2.2.2 r haff_r
        | delete _ => cases hins }
  -- Initialize loop index `26[7] := 0`
  let mB := wWrite mA 26 7 0
  have hex_B : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 7) (.lit 0)) mA mB 15 :=
    exec_boxWriteW inp mA _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hInv0 : RouteLoopInv K NumSlots leafS opH P P' nodes snAge ins mem mA 0 mB := by
    unfold RouteLoopInv; dsimp only
    refine ⟨⟨by simp [mB]; exact hseg_A.1,
             fun s hs => by simp [mB]; exact hseg_A.2.1 s hs,
             fun s hs u hu => by simp [mB]; exact hseg_A.2.2 s hs u hu⟩,
      by simp [mB, hw26_4_A],
      by dsimp only [ins]; rw [show wRead mB 26 5 = wRead mA 26 5 by simp [mB]]; exact hw26_5_A,
      by simp [mB],
      fun hins => ?_,
      hSeg0_A.congr_mem_fSq (by simp [mB]) (fun _ _ => by simp [mB]) (fun _ _ => by simp [mB])
        (fun _ _ => by simp [mB]) (fun _ _ => by simp [mB]) (fun _ _ => rfl),
      (hOther_A leafS hleaf_lt (by omega) _ _ hSeg_leaf).congr_mem_fSq
        (by simp [mB]) (fun _ _ => by simp [mB]) (fun _ _ => by simp [mB])
        (fun _ _ => by simp [mB]) (fun _ _ => by simp [mB]) (fun _ _ => rfl),
      fun r hr => absurd hr (Nat.not_lt_zero _),
      fun r _ => ?_,
      fun s' hs' hne0 _ _ S₁ fSq₁ hE =>
        (hOther_A s' hs' hne0 S₁ fSq₁ hE).congr_mem_fSq
          (by simp [mB]) (fun _ _ => by simp [mB]) (fun _ _ => by simp [mB])
          (fun _ _ => by simp [mB]) (fun _ _ => by simp [mB]) (fun _ _ => rfl),
      fun t _ _ _ _ _ ht26 idx => by simp [mB, ht26],
      fun idx _ => by simp [mB],
      fun t _ _ idx => by simp [mB]⟩
    · dsimp only [ins] at hins ⊢
      cases op with
      | insert _ _ _ =>
          have hfin0 : (⟨min 0 k, Nat.lt_succ_of_le (Nat.min_le_right 0 k)⟩ : Fin (k + 1)) =
              ⟨0, Nat.zero_lt_succ k⟩ :=
            Fin.ext (Nat.zero_min k)
          rw [hfin0, cg02_aff_zero_of_ins nodes hmatch_A.2.2.1]
          simp [mB, hw26_9_A]
      | delete _ => cases hins
    · refine (hsn r).congr_mem
        (by simp [mB]; exact hw_A 13 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
        (by simp [mB]; exact hw_A 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
        (by simp [mB]; exact hw_A 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
        (fun s _ => by simp [mB]; exact hw_A 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
        (fun c => by simp only [mB, rRead_wWrite]; exact hr_A 12 (by decide) (by decide) (by decide) _)
        (by simp [mB]; exact hr_A 13 (by decide) (by decide) (by decide) _)
        (fun s hs_in S₁ fSq₁ hE => ?_)
        (fun _ _ => rfl)
      rcases hsn r with ⟨dS, spS, _, hd_lt, _, hsp_lt, _, _, h14, h15, _⟩
      have hset := EncServingNode.snSlotSet_eq (d := d) (K := K) (NumSlots := NumSlots)
        (livePts := P.handleCoords) (N := nodes r) (S_r := S_pre r.castSucc) (age_r := snAge r) h14 h15
      have hs_lt : s < NumSlots := by rw [hset] at hs_in; simp at hs_in; rcases hs_in with rfl | rfl <;> assumption
      have hs_ne0 : s ≠ 0 := (hdisj_0leaf r s hs_in).1
      exact (hOther_A s hs_lt hs_ne0 S₁ fSq₁ hE).congr_mem_fSq
        (by simp [mB]) (fun _ _ => by simp [mB]) (fun _ _ => by simp [mB])
        (fun _ _ => by simp [mB]) (fun _ _ => by simp [mB]) (fun _ _ => rfl)
  -- Step 2: Run the `D₀`-iteration serving-node loop
  rcases DetExecAt.repeatN_nat (.lit (D₀ : ℤ)) (routeOneServingNodeStmt d K M_box) D₀ 2
      (routeOneServingNodeCost d K)
      (RouteLoopInv K NumSlots leafS opH P P' nodes snAge ins mem mA)
      hInv0 rfl (by simp [intExprOps]) (exec_routeOneServingNodeStmt inp hCtx)
    with ⟨mC, hInvC, hex_loop⟩
  rcases hInvC with ⟨hseg_C, hmC_4, hmC_5, _, hmC_9, hSeg0_C, hSegL_C,
                     hDone_C, _, hRest_C, hw_C, hw13_C, hr_C⟩
  have hmin_D0 : min D₀ k = k := Nat.min_eq_right hk_le
  have hw16_C : wRead mC 1 6 = (leafS : ℤ) := by
    rw [hw_C 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw1_A 6 (by decide) (by decide) (by decide), hw16]
  -- Step 3: Terminal Leaf Pool `routeTerminalLeafStmt`
  have hLeafA : ∃ mL1 : ArithRAMMemory,
      DetExecAt 0 inp
        (.ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
          (boxWriteW M_box 26 (.lit 8) (.readHeap 26 (.lit 9)))
          (checkInSegSlotTo26Stmt K M_box (.readHeap 1 (.lit 6))))
        mC mL1 95 ∧
      wRead mL1 26 8 = (if aff (Fin.last k) then 1 else 0) ∧
      (∀ t, t ≠ 26 → ∀ idx, wRead mL1 t idx = wRead mC t idx) ∧
      (∀ idx, idx ≠ 8 → wRead mL1 26 idx = wRead mC 26 idx) ∧
      (∀ t idx, rRead mL1 t idx = rRead mC t idx) := by
    cases hins_c : ins with
    | true =>
        have hc5 : cValAt 0 inp mC (.intEq (.readHeap 26 (.lit 5)) (.lit 1)) = true := by
          simp [hmC_5, hins_c]
        let mL1 := wWrite mC 26 8 (wRead mC 26 9)
        have hb : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 8) (.readHeap 26 (.lit 9))) mC mL1 18 :=
          exec_boxWriteW inp mC _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
        have h9_val : wRead mC 26 9 = (if aff (Fin.last k) then 1 else 0) := by
          have h9 := hmC_9 hins_c
          have hfin : (⟨min D₀ k, Nat.lt_succ_of_le (Nat.min_le_right D₀ k)⟩ : Fin (k + 1)) = Fin.last k :=
            Fin.ext hmin_D0
          rwa [hfin] at h9
        exact ⟨mL1,
          (DetExecAt.ite_true hc5 (C_c := 10) (by simp [condExprOps, intExprOps]) hb).mono_cost (by omega),
          by simp [mL1, h9_val],
          fun t ht idx => by simp [mL1, ht],
          fun idx hne => by simp [mL1, hne],
          fun _ _ => by simp [mL1]⟩
    | false =>
        have hc5 : cValAt 0 inp mC (.intEq (.readHeap 26 (.lit 5)) (.lit 1)) = false := by
          simp [hmC_5, hins_c]
        rcases exec_checkInSegSlotTo26Stmt inp mC (.readHeap 1 (.lit 6))
            hopH_K (M_box := M_box) (by omega)
            (by simp [hw16_C]) hmC_4 hSegL_C
          with ⟨mL1, hb, _, hw26_8, hwt, hw26, hrt⟩
        have hmem_eq : (if opH ∈ S_pre (Fin.last k) then (1 : ℤ) else 0) = (if aff (Fin.last k) then 1 else 0) := by
          dsimp only [aff, S_pre]
          simp [chainLevelAffected, hins_c]
        exact ⟨mL1,
          (DetExecAt.ite_false hc5 (C_c := 10) (by simp [condExprOps, intExprOps]) hb).mono_cost
            (by simp [intExprOps]),
          hw26_8.trans hmem_eq, hwt, hw26, hrt⟩
  rcases hLeafA with ⟨mL1, hexL1, hmL1_8, hw_mL1, hw26_mL1, hr_mL1⟩
  have hseg_L1 : SegGenBound K NumSlots mL1 :=
    ⟨by rw [hw_mL1 1 (by decide)]; exact hseg_C.1,
     fun s hs => by rw [hw_mL1 5 (by decide), hw_mL1 1 (by decide)]; exact hseg_C.2.1 s hs,
     fun s hs u hu => by rw [hw_mL1 8 (by decide), hw_mL1 1 (by decide)]; exact hseg_C.2.2 s hs u hu⟩
  have liftSeg_L1 : ∀ s' < NumSlots, ∀ S₁ fSq₁, EncSegSlot K mC s' S₁ fSq₁ → EncSegSlot K mL1 s' S₁ fSq₁ := by
    intro s' _ S₁ fSq₁ hE
    exact hE.congr_mem_fSq
      (by rw [hw_mL1 5 (by decide)]) (fun _ _ => by rw [hw_mL1 8 (by decide)])
      (fun _ _ => by rw [hw_mL1 9 (by decide)]) (fun _ _ => by rw [hw_mL1 10 (by decide)])
      (fun _ _ => by rw [hr_mL1]) (fun _ _ => rfl)
  have hLeafB : ∃ mL2 : ArithRAMMemory,
      DetExecAt 0 inp
        (.ite (.intEq (.readHeap 26 (.lit 8)) (.lit 1))
          (seqList [
            boxWriteW M_box 26 (.lit 3) (.readHeap 1 (.lit 6)),
            updSegZeroStmt K M_box
          ]) .skip) mL1 mL2 (220 * (K + 1) + 90) ∧
      SegGenBound K NumSlots mL2 ∧
      EncSegSlot K mL2 leafS (S_post (Fin.last k)) (fun _ => 0) ∧
      (∀ s' < NumSlots, s' ≠ leafS → ∀ S₁ fSq₁, EncSegSlot K mC s' S₁ fSq₁ → EncSegSlot K mL2 s' S₁ fSq₁) ∧
      (∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ idx, wRead mL2 t idx = wRead mC t idx) ∧
      (∀ idx, idx ≠ 3 → idx ≠ 8 → wRead mL2 26 idx = wRead mC 26 idx) ∧
      (∀ t, t ≠ 8 → ∀ idx, rRead mL2 t idx = rRead mC t idx) := by
    cases haffL : aff (Fin.last k) with
    | false =>
        have hc8 : cValAt 0 inp mL1 (.intEq (.readHeap 26 (.lit 8)) (.lit 1)) = false := by
          simp [hmL1_8, haffL]
        have hpost_eq : S_post (Fin.last k) = S_pre (Fin.last k) := ((hAffProps (Fin.last k)).1 haffL).2.2
        exact ⟨mL1,
          (DetExecAt.ite_false hc8 (C_c := 10) (by simp [condExprOps, intExprOps])
            (DetExecAt.skip 0 inp mL1)).mono_cost (by omega),
          hseg_L1,
          hpost_eq ▸ liftSeg_L1 leafS hleaf_lt _ _ hSegL_C,
          fun s' hs' _ S₁ fSq₁ hE => liftSeg_L1 s' hs' S₁ fSq₁ hE,
          fun t _ _ _ ht26 idx => hw_mL1 t ht26 idx,
          fun idx _ h8 => hw26_mL1 idx h8,
          fun t _ idx => hr_mL1 t idx⟩
    | true =>
        have hc8 : cValAt 0 inp mL1 (.intEq (.readHeap 26 (.lit 8)) (.lit 1)) = true := by
          simp [hmL1_8, haffL]
        let mL_a := wWrite mL1 26 3 (leafS : ℤ)
        have hb1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 3) (.readHeap 1 (.lit 6))) mL1 mL_a 20 :=
          exec_boxWriteW inp mL1 _ _ rfl (by omega) (by omega)
            (by rw [iValAt_readHeap, iValAt_lit, hw_mL1 1 (by decide), hw16_C])
            (by simp [intExprOps])
        have hseg_La : SegGenBound K NumSlots mL_a :=
          ⟨by simp [mL_a]; exact hseg_L1.1,
           fun s hs => by simp [mL_a]; exact hseg_L1.2.1 s hs,
           fun s hs u hu => by simp [mL_a]; exact hseg_L1.2.2 s hs u hu⟩
        have hSegL_a : EncSegSlot K mL_a leafS (S_pre (Fin.last k)) (fun _ => 0) :=
          (liftSeg_L1 leafS hleaf_lt _ _ hSegL_C).congr_mem_fSq
            (by simp [mL_a]) (fun _ _ => by simp [mL_a]) (fun _ _ => by simp [mL_a])
            (fun _ _ => by simp [mL_a]) (fun _ _ => by simp [mL_a]) (fun _ _ => rfl)
        rcases exec_updSegZeroStmt inp mL_a (NumSlots := NumSlots) (M_box := M_box)
            (s := leafS) (h := opH) (ins := ins) (S := S_pre (Fin.last k))
            hleaf_lt hopH_K hBox_seg
            (by simp [mL_a])
            (by simp [mL_a, hw26_mL1 4 (by decide), hmC_4])
            (by simp [mL_a, hw26_mL1 5 (by decide), hmC_5])
            hseg_La hSegL_a
          with ⟨mL2, hb2, _, hseg_L2, hSegL_2, hOther_L2, hw_L2, hr_L2⟩
        have hSpost_eq : (if ins then insert opH (S_pre (Fin.last k)) else (S_pre (Fin.last k)).erase opH) = S_post (Fin.last k) := by
          have hT := (hAffProps (Fin.last k)).2 haffL
          cases hins_b : ins with
          | true => exact (hT.2.1 hins_b).2.symm
          | false => exact (hT.2.2 hins_b).2.symm
        refine ⟨mL2,
          (DetExecAt.ite_true hc8 (C_c := 10) (by simp [condExprOps, intExprOps])
            (hb1.seq hb2)).mono_cost (by omega),
          hseg_L2,
          hSpost_eq ▸ hSegL_2,
          fun s' hs' hneL S₁ fSq₁ hE =>
            hOther_L2 s' hs' hneL S₁ fSq₁
              ((liftSeg_L1 s' hs' S₁ fSq₁ hE).congr_mem_fSq
                (by simp [mL_a]) (fun _ _ => by simp [mL_a]) (fun _ _ => by simp [mL_a])
                (fun _ _ => by simp [mL_a]) (fun _ _ => by simp [mL_a]) (fun _ _ => rfl)),
          fun t h8 h9 h10 h26 idx => by rw [hw_L2 t h8 h9 h10]; simp [mL_a, h26, hw_mL1 t h26],
          fun idx h3 h8 => by rw [hw_L2 26 (by decide) (by decide) (by decide)]; simp [mL_a, h3, hw26_mL1 idx h8],
          fun t h8 idx => by rw [hr_L2 t h8]; simp [mL_a, hr_mL1]⟩
  rcases hLeafB with ⟨mL2, hexL2, hseg_L2, hSegL_2, hOther_L2, hw_L2, hw26_L2, hr_L2⟩
  let mem' := mL2.popDepth 0
  have hex_pop : DetExecAt 0 inp (.localScope .skip) mL2 mem' 1 :=
    exec_popScopeZeroStmt inp mL2
  have hex_leaf : DetExecAt 0 inp (routeTerminalLeafStmt K M_box) mC mem' (220 * (K + 1) + 195) := by
    unfold routeTerminalLeafStmt seqList
    exact (hexL1.seq (hexL2.seq hex_pop)).mono_cost (by omega)
  have hex_total : DetExecAt 0 inp (routeLiveUpdateStmt d n K D₀ NumSlots M_box) mem mem'
      (routeLiveUpdateCost d K D₀ NumSlots) := by
    unfold routeLiveUpdateStmt seqList
    refine (hex_A.seq (hex_B.seq (hex_loop.seq hex_leaf))).mono_cost ?_
    unfold routeLiveUpdateCost routeOneServingNodeCost
    nlinarith
  -- Assemble postconditions on `mem' = mL2.popDepth 0`
  have hw_m'_mA : ∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 13 → t ≠ 20 → t ≠ 26 →
      ∀ idx, wRead mem' t idx = wRead mA t idx := by
    intro t h8 h9 h10 h13 h20 h26 idx
    simp [mem', hw_L2 t h8 h9 h10 h26, hw_C t h8 h9 h10 h13 h20 h26]
  have hr_m'_mA : ∀ t, t ≠ 8 → t ≠ 26 → ∀ idx, rRead mem' t idx = rRead mA t idx := by
    intro t h8 h26 idx
    simp [mem', hr_L2 t h8, hr_C t h8 h26]
  have hret_eq : readStepRetH op mem' = readStepRetH op mA := by
    cases op with
    | insert _ _ _ =>
        have h00 : mem'.words.read (.heap 0 0) = mA.words.read (.heap 0 0) := by
          change wRead mem' 0 0 = wRead mA 0 0
          exact hw_m'_mA 0 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) 0
        simp only [readStepRetH, ArithRAMDynamicProgram.readReturnedHandle, h00]
    | delete _ => rfl
  have hPool' : EncHandlePool d n mem' P' := by
    rcases hPool_A with ⟨⟨hl1, hl2⟩, hwm, freeSet, hhwm, hw10, hw11, hw12, hdisj, hun, hst1, hst2, hw2⟩
    refine ⟨⟨hl1, fun h hh c => ?_⟩, hwm, freeSet, hhwm, ?_, ?_, ?_, hdisj, hun, ?_, ?_, ?_⟩
    · rw [hr_m'_mA 4 (by decide) (by decide)]; exact hl2 h hh c
    · rw [hw_m'_mA 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]; exact hw10
    · rw [hw_m'_mA 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]; exact hw11
    · rw [hw_m'_mA 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]; exact hw12
    · intro i hi; rw [hw_m'_mA 3 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]; exact hst1 i hi
    · intro i hi j hj hne
      rw [hw_m'_mA 3 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
          hw_m'_mA 3 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
      exact hst2 i hi j hj hne
    · intro h hh; rw [hw_m'_mA 2 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]; exact hw2 h hh
  have hseg' : SegGenBound K NumSlots mem' :=
    ⟨by simp [mem']; exact hseg_L2.1,
     fun s hs => by simp [mem']; exact hseg_L2.2.1 s hs,
     fun s hs u hu => by simp [mem']; exact hseg_L2.2.2 s hs u hu⟩
  have hsave' : SaveGenBound n NumSlots mem' := by
    refine ⟨hseg'.1, ?_, ?_⟩
    · intro s hs
      rw [hw_m'_mA 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
          hw_m'_mA 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
      exact hsave_A.2.1 s hs
    · intro s hs h hh
      rw [hw_m'_mA 11 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
          hw_m'_mA 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
      exact hsave_A.2.2 s hs h hh
  have liftNotLeaf : ∀ s' < NumSlots, s' ≠ leafS → ∀ S₁ fSq₁,
      EncSegSlot K mC s' S₁ fSq₁ → EncSegSlot K mem' s' S₁ fSq₁ := by
    intro s' hs' hneL S₁ fSq₁ hE
    exact (hOther_L2 s' hs' hneL S₁ fSq₁ hE).congr_mem_fSq
      (by simp [mem']) (fun _ _ => by simp [mem']) (fun _ _ => by simp [mem'])
      (fun _ _ => by simp [mem']) (fun _ _ => by simp [mem']) (fun _ _ => rfl)
  have hSeg0' : EncSegSlot K mem' 0 P'.activeHandles (fun _ => 0) :=
    liftNotLeaf 0 (by omega) (by omega) _ _ hSeg0_C
  have hSegL' : EncSegSlot K mem' leafS (chainTerminal P'.handleCoords nodes P'.activeHandles) (fun _ => 0) := by
    rw [cg02_chainTerminal_eq]
    exact hSegL_2.congr_mem_fSq
      (by simp [mem']) (fun _ _ => by simp [mem']) (fun _ _ => by simp [mem'])
      (fun _ _ => by simp [mem']) (fun _ _ => by simp [mem']) (fun _ _ => rfl)
  have hsnSet_m' : ∀ r : Fin k, snSlotSet mem' r.val = snSlotSet mem r.val := by
    intro r; unfold snSlotSet
    rw [hw_m'_mA 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw_m'_mA 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw_A 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw_A 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
  have hsnSet_C : ∀ r : Fin k, snSlotSet mC r.val = snSlotSet mem r.val := by
    intro r; unfold snSlotSet
    rw [hw_C 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw_C 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw_A 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw_A 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
  have hChain' : EncServingChain d n K D₀ NumSlots mem' P' k nodes
      (fun r => if aff r.castSucc then snAge r + 1 else snAge r) := by
    refine ⟨hk_le, hnK, hSlots2, hPool', hseg', hsave',
      by rw [hw_m'_mA 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
             hw1_A 5 (by decide) (by decide) (by decide), hw15],
      by rw [hw_m'_mA 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
             hw_A 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hw60],
      hSeg0',
      leafS, hleaf_pos, hleaf_lt,
      by rw [hw_m'_mA 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
             hw1_A 6 (by decide) (by decide) (by decide), hw16],
      by rw [hw_m'_mA 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
             hw_A 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hw6_leaf],
      hSegL',
      fun r => ?_,
      fun r s hs => by rw [hsnSet_m' r] at hs; exact hdisj_0leaf r s hs,
      fun r₁ r₂ hne => by rw [hsnSet_m' r₁, hsnSet_m' r₂]; exact hdisj_sn r₁ r₂ hne⟩
    rcases hDone_C r (lt_of_lt_of_le r.isLt hk_le) with ⟨hEN_C, _⟩
    refine hEN_C.congr_mem
      (by simp [mem', hw_L2 13 (by decide) (by decide) (by decide) (by decide)])
      (by simp [mem', hw_L2 14 (by decide) (by decide) (by decide) (by decide)])
      (by simp [mem', hw_L2 15 (by decide) (by decide) (by decide) (by decide)])
      (fun _ _ => by simp [mem', hw_L2 6 (by decide) (by decide) (by decide) (by decide)])
      (fun _ => by simp only [mem', rRead_popDepth, hr_L2 12 (by decide)])
      (by simp [mem', hr_L2 13 (by decide)])
      (fun s hs_in S₁ fSq₁ hE => ?_)
      (fun _ _ => rfl)
    rw [hsnSet_C r] at hs_in
    rcases hsn r with ⟨d1, s1, _, hd1, _, hs1_lt, _, _, e14, e15, _⟩
    have hset' := EncServingNode.snSlotSet_eq (d := d) (K := K) (NumSlots := NumSlots)
      (livePts := P.handleCoords) (N := nodes r) (S_r := S_pre r.castSucc) (age_r := snAge r) e14 e15
    have hslt : s < NumSlots := by rw [hset'] at hs_in; simp at hs_in; rcases hs_in with rfl | rfl <;> assumption
    exact liftNotLeaf s hslt (hdisj_0leaf r s hs_in).2 S₁ fSq₁ hE
  refine ⟨mem', P', opH,
    hex_total,
    popDepth_zero_idem mL2,
    by rwa [hret_eq],
    hWF_A,
    hChain',
    hopH_n, hopH_K,
    by simp [mem', hw26_L2 4 (by decide) (by decide), hmC_4],
    by simp [mem', hw26_L2 5 (by decide) (by decide), hmC_5],
    fun r => ⟨by
      rcases hDone_C r (lt_of_lt_of_le r.isLt hk_le) with ⟨_, hw20_r⟩
      simp [mem', hw_L2 20 (by decide) (by decide) (by decide) (by decide), hw20_r],
      (hAffProps r.castSucc).1,
      (hAffProps r.castSucc).2⟩,
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · cases op with
    | insert _ _ _ =>
        refine ⟨?_, hmatch_A.2.1, hmatch_A.2.2.1, hmatch_A.2.2.2.1, hmatch_A.2.2.2.2⟩
        rw [hw_m'_mA 0 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
        exact hmatch_A.1
    | delete _ => exact hmatch_A
  · intro s hs hw6 S snapPts hSC
    rcases hSlot_A s hs hw6 S snapPts hSC with ⟨h1, Left | Right⟩
    · refine ⟨h1, Or.inl ⟨?_, Left.2.1, Left.2.2⟩⟩
      rw [hw_m'_mA 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]; exact Left.1
    · refine ⟨h1, Or.inr ⟨?_, fun h hh => ⟨?_, ?_⟩⟩⟩
      · rw [hw_m'_mA 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]; exact Right.1
      · intro heq c
        rw [hw_m'_mA 11 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
            hw_m'_mA 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)] at heq
        rw [hr_m'_mA 11 (by decide) (by decide)]
        exact (Right.2 h hh).1 heq c
      · intro hne
        rw [hw_m'_mA 11 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
            hw_m'_mA 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)] at hne
        exact (Right.2 h hh).2 hne
  · intro s' hs' h0 hL_nat hno S₁ fSq₁ hE
    have hL : s' ≠ leafS := by rw [hw16] at hL_nat; simpa using hL_nat
    exact liftNotLeaf s' hs' hL S₁ fSq₁ (hRest_C s' hs' h0 hL hno S₁ fSq₁ hE)
  · intro t h0 h1 h2 h3 h8 h9 h10 h11 h13 h20 h26 idx
    rw [hw_m'_mA t h8 h9 h10 h13 h20 h26, hw_A t h0 h1 h2 h3 h8 h9 h10 h11 h26]
  · intro idx hne0
    rw [hw_m'_mA 0 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hw0_A idx hne0]
  · intro idx h0 h1 h2
    rw [hw_m'_mA 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hw1_A idx h0 h1 h2]
  · intro idx hidx
    simp only [mem', wRead_popDepth, hw_L2 13 (by decide) (by decide) (by decide) (by decide)]
    rw [hw13_C idx (by omega),
        hw_A 13 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
  · intro t h4 h8 h11 h26 idx
    rw [hr_m'_mA t h8 h26, hr_A t h4 h8 h11]

/-! ### 7. Explicit Polynomial Cost and Box-Footprint Bounds for `P46Params` -/

/-- Explicit polynomial upper bounds on `routeLiveUpdateCost` (`≤ 1050000 * D^5 * H^3 ≤ 1050000 * D^19 * H^18`)
and `routeMinBox` (`≤ 20004 * n * D^5 * H^2 ≤ 20004 * n * D^19 * H^18`) under `P46Params` scaling! -/
theorem p46_route_poly_cost_and_box {d n D H K D₀ NumSlots : ℕ}
    (hn : 2 ≤ n)
    (hD_eq : D = d + 3)
    (hD3 : 3 ≤ D)
    (hH5 : 5 ≤ H)
    (hKH : K ≤ H)
    (h2K : 2 ^ K < 2 * n)
    (hD0 : D₀ = 24 * D ^ 2 * H)
    (hSlots : NumSlots = 8 * (D₀ + 2) ^ 2) :
    routeLiveUpdateCost d K D₀ NumSlots ≤ 1050000 * D ^ 5 * H ^ 3 ∧
    routeLiveUpdateCost d K D₀ NumSlots ≤ 1050000 * D ^ 19 * H ^ 18 ∧
    routeMinBox d n K D₀ NumSlots ≤ 20004 * n * D ^ 5 * H ^ 2 ∧
    routeMinBox d n K D₀ NumSlots ≤ 20004 * n * D ^ 19 * H ^ 18 := by
  have hd1 : d + 1 ≤ D := by omega
  have hK1 : K + 1 ≤ 2 * H := by omega
  have hD1 : 1 ≤ D := by omega
  have hH1 : 1 ≤ H := by omega
  have hD2H_ge2 : 2 ≤ D ^ 2 * H := by nlinarith
  have hD0_2 : D₀ + 2 ≤ 25 * D ^ 2 * H := by rw [hD0]; linarith
  have hSlots_le : NumSlots ≤ 5000 * D ^ 4 * H ^ 2 := by
    rw [hSlots]
    have hsq : (D₀ + 2) ^ 2 ≤ (25 * D ^ 2 * H) ^ 2 := Nat.pow_le_pow_left hD0_2 2
    calc 8 * (D₀ + 2) ^ 2 ≤ 8 * (25 * D ^ 2 * H) ^ 2 := Nat.mul_le_mul_left 8 hsq
      _ = 5000 * D ^ 4 * H ^ 2 := by ring
  have hSlots1 : NumSlots + 1 ≤ 5001 * D ^ 4 * H ^ 2 := by
    have h1 : 1 ≤ D ^ 4 * H ^ 2 := Nat.mul_pos (Nat.pow_pos hD1) (Nat.pow_pos hH1)
    linarith
  have hinner : 600 * (K + 1) + 150 * (d + 1) + 400 ≤ 1750 * D * H := by
    have hDH_1 : 1 ≤ D * H := Nat.mul_pos hD1 hH1
    have hH_DH : H ≤ D * H := le_mul_of_one_le_left (Nat.zero_le H) hD1
    have hD_DH : D ≤ D * H := le_mul_of_one_le_right (Nat.zero_le D) hH1
    linarith
  have hcost53 : routeLiveUpdateCost d K D₀ NumSlots ≤ 1050000 * D ^ 5 * H ^ 3 := by
    unfold routeLiveUpdateCost
    have ht1 : 200 * (NumSlots + 1) * (d + 1) ≤ 1000200 * D ^ 5 * H ^ 2 := by
      calc 200 * (NumSlots + 1) * (d + 1)
          ≤ 200 * (5001 * D ^ 4 * H ^ 2) * D :=
            Nat.mul_le_mul (Nat.mul_le_mul_left 200 hSlots1) hd1
        _ = 1000200 * D ^ 5 * H ^ 2 := by ring
    have ht1' : 1000200 * D ^ 5 * H ^ 2 ≤ 1000200 * D ^ 5 * H ^ 3 := by
      have hp : H ^ 2 ≤ H ^ 3 := Nat.pow_le_pow_right hH1 (by decide)
      exact Nat.mul_le_mul_left _ hp
    have ht2 : (D₀ + 2) * (600 * (K + 1) + 150 * (d + 1) + 400) ≤ 43750 * D ^ 3 * H ^ 2 := by
      calc (D₀ + 2) * (600 * (K + 1) + 150 * (d + 1) + 400)
          ≤ (25 * D ^ 2 * H) * (1750 * D * H) := Nat.mul_le_mul hD0_2 hinner
        _ = 43750 * D ^ 3 * H ^ 2 := by ring
    have ht2' : 43750 * D ^ 3 * H ^ 2 ≤ 43750 * D ^ 5 * H ^ 3 := by
      have hpD : D ^ 3 ≤ D ^ 5 := Nat.pow_le_pow_right hD1 (by decide)
      have hpH : H ^ 2 ≤ H ^ 3 := Nat.pow_le_pow_right hH1 (by decide)
      calc 43750 * D ^ 3 * H ^ 2 = 43750 * (D ^ 3 * H ^ 2) := by ring
        _ ≤ 43750 * (D ^ 5 * H ^ 3) := Nat.mul_le_mul_left _ (Nat.mul_le_mul hpD hpH)
        _ = 43750 * D ^ 5 * H ^ 3 := by ring
    have ht3 : 1 ≤ D ^ 5 * H ^ 3 := Nat.mul_pos (Nat.pow_pos hD1) (Nat.pow_pos hH1)
    linarith
  have hcost19 : routeLiveUpdateCost d K D₀ NumSlots ≤ 1050000 * D ^ 19 * H ^ 18 := by
    have hpD : D ^ 5 ≤ D ^ 19 := Nat.pow_le_pow_right hD1 (by decide)
    have hpH : H ^ 3 ≤ H ^ 18 := Nat.pow_le_pow_right hH1 (by decide)
    calc routeLiveUpdateCost d K D₀ NumSlots
        ≤ 1050000 * (D ^ 5 * H ^ 3) := by linarith
      _ ≤ 1050000 * (D ^ 19 * H ^ 18) := Nat.mul_le_mul_left _ (Nat.mul_le_mul hpD hpH)
      _ = 1050000 * D ^ 19 * H ^ 18 := by ring
  have hbox52 : routeMinBox d n K D₀ NumSlots ≤ 20004 * n * D ^ 5 * H ^ 2 := by
    unfold routeMinBox
    have hpos : 1 ≤ n * D ^ 5 * H ^ 2 := by
      have h1 : 1 ≤ D ^ 5 * H ^ 2 := Nat.mul_pos (Nat.pow_pos hD1) (Nat.pow_pos hH1)
      calc 1 = 1 * 1 := by ring
        _ ≤ n * (D ^ 5 * H ^ 2) := Nat.mul_le_mul (by omega) h1
        _ = n * D ^ 5 * H ^ 2 := by ring
    have hb1 : 30 ≤ 20004 * n * D ^ 5 * H ^ 2 := by linarith
    have hb2 : D₀ ≤ 20004 * n * D ^ 5 * H ^ 2 := by
      have hpD : D ^ 2 ≤ D ^ 5 := Nat.pow_le_pow_right hD1 (by decide)
      have hpH : H ≤ H ^ 2 := by simpa using Nat.pow_le_pow_right hH1 (by decide : 1 ≤ 2)
      have h1 : D ^ 2 * H ≤ n * (D ^ 5 * H ^ 2) := by
        calc D ^ 2 * H = 1 * (D ^ 2 * H) := by ring
          _ ≤ n * (D ^ 5 * H ^ 2) := Nat.mul_le_mul (by omega) (Nat.mul_le_mul hpD hpH)
      rw [hD0]
      calc 24 * D ^ 2 * H = 24 * (D ^ 2 * H) := by ring
        _ ≤ 24 * (n * (D ^ 5 * H ^ 2)) := Nat.mul_le_mul_left 24 h1
        _ ≤ 20004 * n * D ^ 5 * H ^ 2 := by linarith
    have hb3 : (NumSlots + 1) * n * (d + 1) ≤ 20004 * n * D ^ 5 * H ^ 2 := by
      calc (NumSlots + 1) * n * (d + 1)
          ≤ (5001 * D ^ 4 * H ^ 2) * n * D :=
            Nat.mul_le_mul (Nat.mul_le_mul_right n hSlots1) hd1
        _ = 5001 * (n * D ^ 5 * H ^ 2) := by ring
        _ ≤ 20004 * n * D ^ 5 * H ^ 2 := by linarith
    have hb4 : NumSlots * 2 ^ (K + 1) ≤ 20004 * n * D ^ 5 * H ^ 2 := by
      have h2K1 : 2 ^ (K + 1) ≤ 4 * n := by rw [pow_succ]; omega
      have hpD : D ^ 4 ≤ D ^ 5 := Nat.pow_le_pow_right hD1 (by decide)
      calc NumSlots * 2 ^ (K + 1)
          ≤ (5000 * D ^ 4 * H ^ 2) * (4 * n) := Nat.mul_le_mul hSlots_le h2K1
        _ = 20000 * n * (D ^ 4 * H ^ 2) := by ring
        _ ≤ 20000 * n * (D ^ 5 * H ^ 2) :=
            Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ hpD)
        _ ≤ 20004 * n * D ^ 5 * H ^ 2 := by linarith
    exact max_le hb1 (max_le hb2 (max_le hb3 hb4))
  have hbox19 : routeMinBox d n K D₀ NumSlots ≤ 20004 * n * D ^ 19 * H ^ 18 := by
    have hpD : D ^ 5 ≤ D ^ 19 := Nat.pow_le_pow_right hD1 (by decide)
    have hpH : H ^ 2 ≤ H ^ 18 := Nat.pow_le_pow_right hH1 (by decide)
    calc routeMinBox d n K D₀ NumSlots
        ≤ (20004 * n) * (D ^ 5 * H ^ 2) := by linarith
      _ ≤ (20004 * n) * (D ^ 19 * H ^ 18) := Nat.mul_le_mul_left _ (Nat.mul_le_mul hpD hpH)
      _ = 20004 * n * D ^ 19 * H ^ 18 := by ring
  exact ⟨hcost53, hcost19, hbox52, hbox19⟩

end UL.Proof_lem_7_2_RacerP46
