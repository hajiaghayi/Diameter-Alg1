import UL.Proof.lem_7_2.RacerP33_H1_RAM
import UL.Proof.cit_hpj19_thm18.H0
import UL.Proof.cit_hpj19_thm18.H1
import UL.Proof.cit_hpj19_thm18.H2
import UL.Proof.cit_hpj19_thm18.H3
import UL.Proof.cit_hpj19_thm18.H4
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP33

open UL.Proof_cit_hpj19_thm18

/-! ### 1. Syntactic localizability check and translation of `hpjProg` into `localFrame 1` -/

def LocalizableInt : IntExpr → Bool
  | .lit _ | .dim => true
  | .intParam e | .neg e => LocalizableInt e
  | .readHeap t e => decide (t < 100) && LocalizableInt e
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ =>
      LocalizableInt e₁ && LocalizableInt e₂
  | _ => false

def LocalizableReal : RealExpr → Bool
  | .ofInt e | .extraReal e => LocalizableInt e
  | .readRealHeap t e => decide (t < 100) && LocalizableInt e
  | .neg r => LocalizableReal r
  | .add r₁ r₂ | .sub r₁ r₂ | .mul r₁ r₂ | .div r₁ r₂ =>
      LocalizableReal r₁ && LocalizableReal r₂
  | _ => false

def LocalizableCond : ArithCondExpr → Bool
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => LocalizableInt e₁ && LocalizableInt e₂
  | .realEq r₁ r₂ | .realLt r₁ r₂ | .realLe r₁ r₂ => LocalizableReal r₁ && LocalizableReal r₂
  | .not c => LocalizableCond c
  | .and c₁ c₂ | .or c₁ c₂ => LocalizableCond c₁ && LocalizableCond c₂

def isActivePtCoord? : RealExpr → Option (IntExpr × IntExpr)
  | .activePtCoord hE cE => some (hE, cE)
  | _ => none

theorem isActivePtCoord_none_of_localizable {r : RealExpr} (hr : LocalizableReal r = true) :
    isActivePtCoord? r = none := by
  cases r <;> simp [LocalizableReal, isActivePtCoord?] at hr ⊢

def LocalizableStmt : ArithRAMStmt → Bool
  | .skip => true
  | .writeWordHeap t idxE valE =>
      decide (t < 100) && LocalizableInt idxE && LocalizableInt valE
  | .writeRealHeap t idxE valE =>
      decide (t < 100) && LocalizableInt idxE &&
        match isActivePtCoord? valE with
        | some (hE, cE) => LocalizableInt hE && LocalizableInt cE
        | none => LocalizableReal valE
  | .randBitHeap t idxE => decide (t < 100) && LocalizableInt idxE
  | .seq s₁ s₂ => LocalizableStmt s₁ && LocalizableStmt s₂
  | .ite c s₁ s₂ => LocalizableCond c && LocalizableStmt s₁ && LocalizableStmt s₂
  | .whileLoop c body => LocalizableCond c && LocalizableStmt body
  | .repeatN cnt body => LocalizableInt cnt && LocalizableStmt body
  | _ => false

def LocalizableCont : ArithRAMCont → Bool
  | .stmt s => LocalizableStmt s
  | .repeatLoop _ body => LocalizableStmt body
  | .popScope _ => false

theorem localizable_hpjProg : LocalizableStmt hpjProg = true := by decide

def locInt : IntExpr → IntExpr
  | .lit c => .lit c
  | .dim => .dim
  | .intParam e => .readLocal 100 (locInt e)
  | .readHeap t e => .readLocal t (locInt e)
  | .neg e => .neg (locInt e)
  | .add e₁ e₂ => .add (locInt e₁) (locInt e₂)
  | .sub e₁ e₂ => .sub (locInt e₁) (locInt e₂)
  | .mul e₁ e₂ => .mul (locInt e₁) (locInt e₂)
  | .div e₁ e₂ => .div (locInt e₁) (locInt e₂)
  | .mod e₁ e₂ => .mod (locInt e₁) (locInt e₂)
  | e => e

def locReal : RealExpr → RealExpr
  | .ofInt e => .ofInt (locInt e)
  | .readRealHeap t e => .readRealLocal t (locInt e)
  | .extraReal e => .readRealLocal 101 (locInt e)
  | .neg r => .neg (locReal r)
  | .add r₁ r₂ => .add (locReal r₁) (locReal r₂)
  | .sub r₁ r₂ => .sub (locReal r₁) (locReal r₂)
  | .mul r₁ r₂ => .mul (locReal r₁) (locReal r₂)
  | .div r₁ r₂ => .div (locReal r₁) (locReal r₂)
  | r => r

def locCond : ArithCondExpr → ArithCondExpr
  | .intEq e₁ e₂ => .intEq (locInt e₁) (locInt e₂)
  | .intLt e₁ e₂ => .intLt (locInt e₁) (locInt e₂)
  | .intLe e₁ e₂ => .intLe (locInt e₁) (locInt e₂)
  | .realEq r₁ r₂ => .realEq (locReal r₁) (locReal r₂)
  | .realLt r₁ r₂ => .realLt (locReal r₁) (locReal r₂)
  | .realLe r₁ r₂ => .realLe (locReal r₁) (locReal r₂)
  | .not c => .not (locCond c)
  | .and c₁ c₂ => .and (locCond c₁) (locCond c₂)
  | .or c₁ c₂ => .or (locCond c₁) (locCond c₂)

def locActivePtWrite (N t : ℕ) (idxE hE cE : IntExpr) : ArithRAMStmt :=
  .ite
    (.and (.and (.intLe (.lit 0) (locInt hE)) (.intLt (locInt hE) (.lit (N : ℤ))))
          (.and (.intLe (.lit 0) (locInt cE)) (.intLt (locInt cE) .dim)))
    (.writeRealLocal t (locInt idxE)
      (.readRealLocal 102 (.add (.mul (locInt hE) .dim) (locInt cE))))
    (.writeRealLocal t (locInt idxE) (.ofInt (.lit 0)))

def locStmt (N : ℕ) : ArithRAMStmt → ArithRAMStmt
  | .skip => .skip
  | .writeWordHeap t idxE valE => .writeWordLocal t (locInt idxE) (locInt valE)
  | .writeRealHeap t idxE valE =>
      match isActivePtCoord? valE with
      | some (hE, cE) => locActivePtWrite N t idxE hE cE
      | none => .writeRealLocal t (locInt idxE) (locReal valE)
  | .randBitHeap t idxE => .randBitLocal t (locInt idxE)
  | .seq s₁ s₂ => .seq (locStmt N s₁) (locStmt N s₂)
  | .ite c s₁ s₂ => .ite (locCond c) (locStmt N s₁) (locStmt N s₂)
  | .whileLoop c body => .whileLoop (locCond c) (locStmt N body)
  | .repeatN cnt body => .repeatN (locInt cnt) (locStmt N body)
  | s => s

def locCont (N : ℕ) : ArithRAMCont → ArithRAMCont
  | .stmt s => .stmt (locStmt N s)
  | .repeatLoop rem body => .repeatLoop rem (locStmt N body)
  | .popScope p => .popScope p

/-! ### 2. Virtual `subHPJInput` and `HPJMemRel` memory simulation relation -/

open Classical in
noncomputable def subHPJInput {d : ℕ} (N : ℕ)
    (ptsN : Fin N → EuclideanSpace ℝ (Fin d)) (φ : ℝ) : ArithRAMInput d :=
  { intParams := List.ofFn (fun k : Fin N => ((⟨Fin.val, Fin.val_injective⟩ : Fin N ↪ ℕ) (id k) : ℤ))
    activeHandles := (Finset.univ : Finset (Fin N)).map ⟨Fin.val, Fin.val_injective⟩
    activeCoords := fun h =>
      if hh : ∃ i : Fin N, (⟨Fin.val, Fin.val_injective⟩ : Fin N ↪ ℕ) i = h then
        ptsN (Classical.choose hh)
      else 0
    extraReals := [φ] }

def HPJMemRel {d : ℕ} (N : ℕ) (ptsN : Fin N → EuclideanSpace ℝ (Fin d)) (φ : ℝ)
    (subMem locMem : ArithRAMMemory) : Prop :=
  (∀ t < 100, ∀ idx : ℤ, wReadL 1 locMem t idx = wRead subMem t idx) ∧
  (∀ t < 100, ∀ idx : ℤ, rReadL 1 locMem t idx = rRead subMem t idx) ∧
  (∀ idx : ℤ, wReadL 1 locMem 100 idx = if 0 ≤ idx ∧ idx < (N : ℤ) then idx else 0) ∧
  (∀ idx : ℤ, rReadL 1 locMem 101 idx = if idx = 0 then φ else 0) ∧
  (∀ (k : Fin N) (c : Fin d),
    rReadL 1 locMem 102 ((k.val : ℤ) * (d : ℤ) + (c.val : ℤ)) = euclideanCoord (ptsN k) c)

theorem popDepth_zero_wWriteL_one (m : ArithRAMMemory) (v : ℕ) (i val : ℤ) :
    (wWriteL 1 m v i val).popDepth 0 = m.popDepth 0 := by
  have hkeep : (RAMCellLoc.localFrame 1 v i).keepAtDepth 0 = false := by
    simp [RAMCellLoc.keepAtDepth]
  unfold wWriteL ArithRAMMemory.popDepth WordStore.popDepth WordStore.write
  dsimp only
  congr 1
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hmem, hk⟩
      · rw [hkeep] at hk; cases hk
      · exact ⟨hmem, hk⟩
    · rintro ⟨hmem, hk⟩
      exact ⟨Or.inr hmem, hk⟩
  · funext loc
    split_ifs with hk
    · have hne : loc ≠ .localFrame 1 v i := by
        intro heq; subst heq; rw [hkeep] at hk; simp at hk
      exact Function.update_of_ne hne val m.words.vals
    · rfl

theorem popDepth_zero_rWriteL_one (m : ArithRAMMemory) (v : ℕ) (i : ℤ) (val : ℝ) :
    (rWriteL 1 m v i val).popDepth 0 = m.popDepth 0 := by
  have hkeep : (RAMCellLoc.localFrame 1 v i).keepAtDepth 0 = false := by
    simp [RAMCellLoc.keepAtDepth]
  unfold rWriteL ArithRAMMemory.popDepth RealStore.popDepth RealStore.write
  dsimp only
  congr 1
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hmem, hk⟩
      · rw [hkeep] at hk; cases hk
      · exact ⟨hmem, hk⟩
    · rintro ⟨hmem, hk⟩
      exact ⟨Or.inr hmem, hk⟩
  · funext loc
    split_ifs with hk
    · have hne : loc ≠ .localFrame 1 v i := by
        intro heq; subst heq; rw [hkeep] at hk; simp at hk
      exact Function.update_of_ne hne val m.reals.vals
    · rfl

theorem HPJMemRel.wWrite_lt {d : ℕ} {N : ℕ} {ptsN : Fin N → EuclideanSpace ℝ (Fin d)} {φ : ℝ}
    {subMem locMem : ArithRAMMemory} (hrel : HPJMemRel N ptsN φ subMem locMem)
    {t : ℕ} (ht : t < 100) (idx val : ℤ) :
    HPJMemRel N ptsN φ (wWrite subMem t idx val) (wWriteL 1 locMem t idx val) := by
  rcases hrel with ⟨hw, hr, h100, h101, h102⟩
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · intro t' ht' idx'
    by_cases heq : t' = t ∧ idx' = idx
    · rcases heq with ⟨rfl, rfl⟩; simp
    · have hne : t' ≠ t ∨ idx' ≠ idx := by tauto
      rw [wReadL_wWriteL_of_ne 1 locMem val hne, wRead_wWrite_of_ne subMem val hne]
      exact hw t' ht' idx'
  · intro t' ht' idx'; simpa using hr t' ht' idx'
  · intro idx'
    rw [wReadL_wWriteL_of_ne 1 locMem val (Or.inl (by omega))]
    exact h100 idx'
  · intro idx'; simpa using h101 idx'
  · intro k c; simpa using h102 k c

theorem HPJMemRel.rWrite_lt {d : ℕ} {N : ℕ} {ptsN : Fin N → EuclideanSpace ℝ (Fin d)} {φ : ℝ}
    {subMem locMem : ArithRAMMemory} (hrel : HPJMemRel N ptsN φ subMem locMem)
    {t : ℕ} (ht : t < 100) (idx : ℤ) (val : ℝ) :
    HPJMemRel N ptsN φ (rWrite subMem t idx val) (rWriteL 1 locMem t idx val) := by
  rcases hrel with ⟨hw, hr, h100, h101, h102⟩
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · intro t' ht' idx'; simpa using hw t' ht' idx'
  · intro t' ht' idx'
    by_cases heq : t' = t ∧ idx' = idx
    · rcases heq with ⟨rfl, rfl⟩; simp
    · have hne : t' ≠ t ∨ idx' ≠ idx := by tauto
      rw [rReadL_rWriteL_of_ne 1 locMem val hne, rRead_rWrite_of_ne subMem val hne]
      exact hr t' ht' idx'
  · intro idx'; simpa using h100 idx'
  · intro idx'
    rw [rReadL_rWriteL_of_ne 1 locMem val (Or.inl (by omega))]
    exact h101 idx'
  · intro k c
    rw [rReadL_rWriteL_of_ne 1 locMem val (Or.inl (by omega))]
    exact h102 k c

theorem HPJMemRel.popDepth_sub {d : ℕ} {N : ℕ} {ptsN : Fin N → EuclideanSpace ℝ (Fin d)} {φ : ℝ}
    {subMem locMem : ArithRAMMemory} (hrel : HPJMemRel N ptsN φ subMem locMem) :
    HPJMemRel N ptsN φ (subMem.popDepth 0) locMem := by
  rcases hrel with ⟨hw, hr, h100, h101, h102⟩
  exact ⟨fun t ht i => by simpa using hw t ht i,
         fun t ht i => by simpa using hr t ht i, h100, h101, h102⟩

theorem sim_locInt {d : ℕ} (outerInp : ArithRAMInput d) (N : ℕ)
    (ptsN : Fin N → EuclideanSpace ℝ (Fin d)) (φ : ℝ)
    {subMem locMem : ArithRAMMemory} (hrel : HPJMemRel N ptsN φ subMem locMem) :
    ∀ {e : IntExpr}, LocalizableInt e = true →
      iValAt 1 outerInp locMem (locInt e) = iValAt 0 (subHPJInput N ptsN φ) subMem e ∧
      intExprOps (locInt e) = intExprOps e
  | .lit _, _ => ⟨rfl, rfl⟩
  | .dim, _ => ⟨rfl, rfl⟩
  | .intParam e, hloc => by
      have ⟨hv, ho⟩ := sim_locInt outerInp N ptsN φ hrel (e := e) hloc
      refine ⟨?_, by simp [locInt, intExprOps, ho]⟩
      simp only [locInt, iValAt_readLocal, iValAt_intParam, hv, hrel.2.2.1]
      set v := iValAt 0 (subHPJInput N ptsN φ) subMem e
      change (if 0 ≤ v ∧ v < (N : ℤ) then v else 0) =
        listGetIntD (List.ofFn (fun k : Fin N => (k.val : ℤ))) v 0
      unfold listGetIntD
      by_cases h0 : 0 ≤ v
      · by_cases hN : v < (N : ℤ)
        · have hlt : v.toNat < N := by omega
          have hget : (List.ofFn (fun k : Fin N => (k.val : ℤ))).getD v.toNat 0 =
              (v.toNat : ℤ) := by
            simp [List.getD_eq_getElem?_getD, hlt]
          rw [if_pos ⟨h0, hN⟩, if_pos h0, hget, Int.toNat_of_nonneg h0]
        · have hge : (List.ofFn (fun k : Fin N => (k.val : ℤ))).length ≤ v.toNat := by
            simp; omega
          rw [if_neg (by tauto), if_pos h0, List.getD_eq_default _ _ hge]
      · rw [if_neg (by tauto), if_neg h0]
  | .readHeap t e, hloc => by
      simp only [LocalizableInt, Bool.and_eq_true, decide_eq_true_eq] at hloc
      have ⟨hv, ho⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      refine ⟨?_, by simp [locInt, intExprOps, ho]⟩
      simp [locInt, hv, hrel.1 t hloc.1]
  | .neg e, hloc => by
      have ⟨hv, ho⟩ := sim_locInt outerInp N ptsN φ hrel (e := e) hloc
      exact ⟨by simp [locInt, hv], by simp [locInt, intExprOps, ho]⟩
  | .add e₁ e₂, hloc => by
      simp only [LocalizableInt, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locInt outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locInt, hv₁, hv₂], by simp [locInt, intExprOps, ho₁, ho₂]⟩
  | .sub e₁ e₂, hloc => by
      simp only [LocalizableInt, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locInt outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locInt, hv₁, hv₂], by simp [locInt, intExprOps, ho₁, ho₂]⟩
  | .mul e₁ e₂, hloc => by
      simp only [LocalizableInt, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locInt outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locInt, hv₁, hv₂], by simp [locInt, intExprOps, ho₁, ho₂]⟩
  | .div e₁ e₂, hloc => by
      simp only [LocalizableInt, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locInt outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locInt, hv₁, hv₂], by simp [locInt, intExprOps, ho₁, ho₂]⟩
  | .mod e₁ e₂, hloc => by
      simp only [LocalizableInt, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locInt outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locInt, hv₁, hv₂], by simp [locInt, intExprOps, ho₁, ho₂]⟩
  | .readLocal _ _, hloc | .activeRatNum _ _, hloc | .activeRatDen _ _, hloc
  | .extraRatNum _, hloc | .extraRatDen _, hloc => by simp [LocalizableInt] at hloc

theorem sim_locReal {d : ℕ} (outerInp : ArithRAMInput d) (N : ℕ)
    (ptsN : Fin N → EuclideanSpace ℝ (Fin d)) (φ : ℝ)
    {subMem locMem : ArithRAMMemory} (hrel : HPJMemRel N ptsN φ subMem locMem) :
    ∀ {r : RealExpr}, LocalizableReal r = true →
      rValAt 1 outerInp locMem (locReal r) = rValAt 0 (subHPJInput N ptsN φ) subMem r ∧
      realExprOps (locReal r) = realExprOps r
  | .ofInt e, hloc => by
      have ⟨hv, ho⟩ := sim_locInt outerInp N ptsN φ hrel (e := e) hloc
      exact ⟨by simp [locReal, hv], by simp [locReal, realExprOps, ho]⟩
  | .readRealHeap t e, hloc => by
      simp only [LocalizableReal, Bool.and_eq_true, decide_eq_true_eq] at hloc
      have ⟨hv, ho⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locReal, hv, hrel.2.1 t hloc.1], by simp [locReal, realExprOps, ho]⟩
  | .extraReal e, hloc => by
      have ⟨hv, ho⟩ := sim_locInt outerInp N ptsN φ hrel (e := e) hloc
      refine ⟨?_, by simp [locReal, realExprOps, ho]⟩
      simp only [locReal, rValAt_readRealLocal, rValAt_extraReal, hv, hrel.2.2.2.1]
      set v := iValAt 0 (subHPJInput N ptsN φ) subMem e
      change (if v = 0 then φ else 0) = listGetIntD [φ] v 0
      unfold listGetIntD
      by_cases hz : v = 0
      · rw [hz]; simp
      · by_cases h0 : 0 ≤ v
        · have hge : ([φ] : List ℝ).length ≤ v.toNat := by simp; omega
          rw [if_neg hz, if_pos h0, List.getD_eq_default _ _ hge]
        · rw [if_neg hz, if_neg h0]
  | .neg r, hloc => by
      have ⟨hv, ho⟩ := sim_locReal outerInp N ptsN φ hrel (r := r) hloc
      exact ⟨by simp [locReal, hv], by simp [locReal, realExprOps, ho]⟩
  | .add r₁ r₂, hloc => by
      simp only [LocalizableReal, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locReal outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locReal outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locReal, hv₁, hv₂], by simp [locReal, realExprOps, ho₁, ho₂]⟩
  | .sub r₁ r₂, hloc => by
      simp only [LocalizableReal, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locReal outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locReal outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locReal, hv₁, hv₂], by simp [locReal, realExprOps, ho₁, ho₂]⟩
  | .mul r₁ r₂, hloc => by
      simp only [LocalizableReal, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locReal outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locReal outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locReal, hv₁, hv₂], by simp [locReal, realExprOps, ho₁, ho₂]⟩
  | .div r₁ r₂, hloc => by
      simp only [LocalizableReal, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locReal outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locReal outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locReal, hv₁, hv₂], by simp [locReal, realExprOps, ho₁, ho₂]⟩
  | .readRealLocal _ _, hloc | .activePtCoord _ _, hloc => by simp [LocalizableReal] at hloc

theorem sim_locCond {d : ℕ} (outerInp : ArithRAMInput d) (N : ℕ)
    (ptsN : Fin N → EuclideanSpace ℝ (Fin d)) (φ : ℝ)
    {subMem locMem : ArithRAMMemory} (hrel : HPJMemRel N ptsN φ subMem locMem) :
    ∀ {c : ArithCondExpr}, LocalizableCond c = true →
      cValAt 1 outerInp locMem (locCond c) = cValAt 0 (subHPJInput N ptsN φ) subMem c ∧
      condExprOps (locCond c) = condExprOps c
  | .intEq e₁ e₂, hloc => by
      simp only [LocalizableCond, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locInt outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locCond, hv₁, hv₂], by simp [locCond, condExprOps, ho₁, ho₂]⟩
  | .intLt e₁ e₂, hloc => by
      simp only [LocalizableCond, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locInt outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locCond, hv₁, hv₂], by simp [locCond, condExprOps, ho₁, ho₂]⟩
  | .intLe e₁ e₂, hloc => by
      simp only [LocalizableCond, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locInt outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locInt outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locCond, hv₁, hv₂], by simp [locCond, condExprOps, ho₁, ho₂]⟩
  | .realEq r₁ r₂, hloc => by
      simp only [LocalizableCond, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locReal outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locReal outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locCond, hv₁, hv₂], by simp [locCond, condExprOps, ho₁, ho₂]⟩
  | .realLt r₁ r₂, hloc => by
      simp only [LocalizableCond, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locReal outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locReal outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locCond, hv₁, hv₂], by simp [locCond, condExprOps, ho₁, ho₂]⟩
  | .realLe r₁ r₂, hloc => by
      simp only [LocalizableCond, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locReal outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locReal outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locCond, hv₁, hv₂], by simp [locCond, condExprOps, ho₁, ho₂]⟩
  | .not c, hloc => by
      have ⟨hv, ho⟩ := sim_locCond outerInp N ptsN φ hrel (c := c) hloc
      exact ⟨by simp [locCond, hv], by simp [locCond, condExprOps, ho]⟩
  | .and c₁ c₂, hloc => by
      simp only [LocalizableCond, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locCond outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locCond outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locCond, hv₁, hv₂], by simp [locCond, condExprOps, ho₁, ho₂]⟩
  | .or c₁ c₂, hloc => by
      simp only [LocalizableCond, Bool.and_eq_true] at hloc
      have ⟨hv₁, ho₁⟩ := sim_locCond outerInp N ptsN φ hrel hloc.1
      have ⟨hv₂, ho₂⟩ := sim_locCond outerInp N ptsN φ hrel hloc.2
      exact ⟨by simp [locCond, hv₁, hv₂], by simp [locCond, condExprOps, ho₁, ho₂]⟩


/-! ### 3. Simulation of `.activePtCoord` write and general continuation stacks -/

theorem isActivePtCoord_eq_some_iff {r : RealExpr} {hE cE : IntExpr} :
    isActivePtCoord? r = some (hE, cE) ↔ r = .activePtCoord hE cE := by
  cases r <;> simp [isActivePtCoord?]

theorem sim_activePtWrite {d : ℕ} (outerInp : ArithRAMInput d) (N t : ℕ)
    (ptsN : Fin N → EuclideanSpace ℝ (Fin d)) (φ : ℝ)
    {idxE hE cE : IntExpr}
    (hidx : LocalizableInt idxE = true)
    (hh : LocalizableInt hE = true)
    (hc : LocalizableInt cE = true)
    {subMem locMem : ArithRAMMemory} (hrel : HPJMemRel N ptsN φ subMem locMem) :
    let subInp := subHPJInput N ptsN φ
    let idx := iValAt 0 subInp subMem idxE
    let val := rValAt 0 subInp subMem (.activePtCoord hE cE)
    let Δu := intExprOps idxE + (intExprOps hE + intExprOps cE + 1) + 1
    DetExecAt 1 outerInp (locActivePtWrite N t idxE hE cE) locMem
      (rWriteL 1 locMem t idx val) (8 * Δu) := by
  classical
  intro subInp idx val Δu
  have ⟨hv_idx, ho_idx⟩ := sim_locInt outerInp N ptsN φ hrel hidx
  have ⟨hv_h, ho_h⟩ := sim_locInt outerInp N ptsN φ hrel hh
  have ⟨hv_c, ho_c⟩ := sim_locInt outerInp N ptsN φ hrel hc
  let h := iValAt 0 subInp subMem hE
  let c := iValAt 0 subInp subMem cE
  let cond : ArithCondExpr :=
    .and (.and (.intLe (.lit 0) (locInt hE)) (.intLt (locInt hE) (.lit (N : ℤ))))
         (.and (.intLe (.lit 0) (locInt cE)) (.intLt (locInt cE) .dim))
  have hcond_ops : condExprOps cond = 2 * intExprOps hE + 2 * intExprOps cE + 11 := by
    dsimp [cond, condExprOps, intExprOps]
    rw [ho_h, ho_c]
    ring
  by_cases hvalid : (0 ≤ h ∧ h < (N : ℤ)) ∧ (0 ≤ c ∧ c < (d : ℤ))
  · rcases hvalid with ⟨⟨hh0, hhN⟩, ⟨hc0, hcd⟩⟩
    have hcond_val : cValAt 1 outerInp locMem cond = true := by
      simp only [cond, cValAt_and, cValAt_intLe, cValAt_intLt, iValAt_lit, iValAt_dim, hv_h, hv_c, Bool.and_eq_true, decide_eq_true_eq]
      exact ⟨⟨hh0, hhN⟩, ⟨hc0, hcd⟩⟩
    have hh_nat : h.toNat < N := by omega
    have hc_nat : c.toNat < d := by omega
    have hh_mem : h.toNat ∈ subInp.activeHandles := by
      simp only [subInp, subHPJInput, Finset.mem_map, Finset.mem_univ, true_and]
      exact ⟨⟨h.toNat, hh_nat⟩, rfl⟩
    have hex_i : ∃ i : Fin N, (⟨Fin.val, Fin.val_injective⟩ : Fin N ↪ ℕ) i = h.toNat :=
      ⟨⟨h.toNat, hh_nat⟩, rfl⟩
    have hchoose : Classical.choose hex_i = ⟨h.toNat, hh_nat⟩ := by
      apply Fin.ext
      exact Classical.choose_spec hex_i
    have hval_eq : val = euclideanCoord (ptsN ⟨h.toNat, hh_nat⟩) ⟨c.toNat, hc_nat⟩ := by
      dsimp only [val]
      rw [rValAt_activePtCoord]
      rw [dif_pos ⟨hh0, hh_mem⟩, dif_pos ⟨hc0, hc_nat⟩]
      change euclideanCoord (if hh : ∃ i : Fin N, (⟨Fin.val, Fin.val_injective⟩ : Fin N ↪ ℕ) i = h.toNat then ptsN (Classical.choose hh) else 0) ⟨c.toNat, hc_nat⟩ = _
      rw [dif_pos hex_i, hchoose]
    have hread102 :
        rValAt 1 outerInp locMem
          (.readRealLocal 102 (.add (.mul (locInt hE) .dim) (locInt cE))) = val := by
      simp only [rValAt_readRealLocal, iValAt_add, iValAt_mul, iValAt_dim, hv_h, hv_c]
      have hcast_h : ((h.toNat : ℤ)) = h := Int.toNat_of_nonneg hh0
      have hcast_c : ((c.toNat : ℤ)) = c := Int.toNat_of_nonneg hc0
      have hidx102 : h * (d : ℤ) + c = (h.toNat : ℤ) * (d : ℤ) + (c.toNat : ℤ) := by
        rw [hcast_h, hcast_c]
      change rReadL 1 locMem 102 (h * (d : ℤ) + c) = val
      rw [hidx102, hrel.2.2.2.2 ⟨h.toNat, hh_nat⟩ ⟨c.toNat, hc_nat⟩, hval_eq]
    have hwr : DetExecAt 1 outerInp
        (.writeRealLocal t (locInt idxE)
          (.readRealLocal 102 (.add (.mul (locInt hE) .dim) (locInt cE))))
        locMem (rWriteL 1 locMem t idx val)
        (intExprOps idxE + intExprOps hE + intExprOps cE + 6) := by
      refine DetExecAt.writeRealLocal 1 outerInp locMem t (locInt idxE) _ hv_idx hread102 ?_
      dsimp [realExprOps, intExprOps]
      rw [ho_idx, ho_h, ho_c]
      omega
    refine (DetExecAt.ite_true hcond_val (le_of_eq hcond_ops) hwr).mono_cost ?_
    have : 1 ≤ intExprOps hE := by cases hE <;> simp [intExprOps] <;> omega
    dsimp [Δu]; omega
  · have hcond_val : cValAt 1 outerInp locMem cond = false := by
      simp only [cond, cValAt_and, cValAt_intLe, cValAt_intLt, iValAt_lit, iValAt_dim,
        hv_h, hv_c, Bool.and_eq_false_iff, decide_eq_false_iff_not]
      change (¬ 0 ≤ h ∨ ¬ h < (N : ℤ)) ∨ (¬ 0 ≤ c ∨ ¬ c < (d : ℤ))
      omega
    have hval_zero : val = 0 := by
      dsimp only [val]
      rw [rValAt_activePtCoord]
      change (if _hh : 0 ≤ h ∧ h.toNat ∈ subInp.activeHandles then
        if hc1 : 0 ≤ c ∧ c.toNat < d then _ else 0 else 0) = 0
      split_ifs with hh_in hc_in
      · exfalso
        rcases hh_in with ⟨hh0, hh_mem⟩
        simp only [subInp, subHPJInput, Finset.mem_map, Finset.mem_univ, true_and] at hh_mem
        rcases hh_mem with ⟨i, hi⟩
        have hhN : h < (N : ℤ) := by
          have : h.toNat < N := hi ▸ i.isLt
          omega
        have hcd : c < (d : ℤ) := by omega
        exact hvalid ⟨⟨hh0, hhN⟩, ⟨hc_in.1, hcd⟩⟩
      · rfl
      · rfl
    have hwr : DetExecAt 1 outerInp
        (.writeRealLocal t (locInt idxE) (.ofInt (.lit 0)))
        locMem (rWriteL 1 locMem t idx val) (intExprOps idxE + 3) := by
      refine DetExecAt.writeRealLocal 1 outerInp locMem t (locInt idxE) (.ofInt (.lit 0))
        hv_idx (by simp [hval_zero]) ?_
      dsimp [realExprOps, intExprOps]
      rw [ho_idx]
    refine (DetExecAt.ite_false hcond_val (le_of_eq hcond_ops) hwr).mono_cost ?_
    dsimp [Δu]; omega

theorem sim_halted_with_tail {d : ℕ} (outerInp : ArithRAMInput d) (N : ℕ)
    (ptsN : Fin N → EuclideanSpace ℝ (Fin d)) (φ : ℝ) :
    ∀ {subFuel : ℕ} {subStk : List ArithRAMCont} {subSt : ArithRAMExecState}
      {subOut : ArithRAMExecOutcome} {locMem₀ : ArithRAMMemory}
      (hstk : ∀ item ∈ subStk, LocalizableCont item = true)
      (hrun : runArithRAMFuel (subHPJInput N ptsN φ) subFuel subStk subSt = .halted subOut)
      (hfd : subSt.frameDepth = 0)
      (hrel : HPJMemRel N ptsN φ subSt.mem locMem₀)
      (tailBits : List Bool) (u₀ peak₀ : ℕ) (outerRest : List ArithRAMCont),
      ∃ (locFuel u₁ peak₁ : ℕ) (locMem₁ : ArithRAMMemory),
        u₁ ≤ u₀ + 8 * (subOut.unitCost - subSt.unitCost) ∧
        HPJMemRel N ptsN φ subOut.mem locMem₁ ∧
        locMem₁.popDepth 0 = locMem₀.popDepth 0 ∧
        ∀ f_rem : ℕ,
          runArithRAMFuel outerInp (locFuel + f_rem)
            (subStk.map (locCont N) ++ outerRest)
            { mem := locMem₀, frameDepth := 1,
              remainingBits := subSt.remainingBits ++ tailBits,
              unitCost := u₀, peakCellSpace := peak₀ } =
          runArithRAMFuel outerInp f_rem outerRest
            { mem := locMem₁, frameDepth := 1,
              remainingBits := tailBits,
              unitCost := u₁, peakCellSpace := peak₁ }
  | subFuel, [], subSt, subOut, locMem₀, _, hrun, _, hrel, tailBits, u₀, peak₀, outerRest => by
      cases subFuel <;> {
        cases hrem : subSt.remainingBits.isEmpty
        · simp [runArithRAMFuel, hrem] at hrun
        · simp [runArithRAMFuel, hrem] at hrun
          subst hrun
          have hnil : subSt.remainingBits = [] := List.isEmpty_iff.mp hrem
          refine ⟨0, u₀, peak₀, locMem₀, by omega, hrel.popDepth_sub, rfl, fun f_rem => ?_⟩
          simp [hnil]
      }
  | 0, _ :: _, _, _, _, _, hrun, _, _, _, _, _, _ => by
      simp [runArithRAMFuel] at hrun
  | subFuel + 1, item :: subRest, subSt, subOut, locMem₀, hstk, hrun, hfd, hrel,
    tailBits, u₀, peak₀, outerRest => by
      have hitem : LocalizableCont item = true := hstk item (List.mem_cons_self)
      have hrest_loc : ∀ x ∈ subRest, LocalizableCont x = true :=
        fun x hx => hstk x (List.mem_cons_of_mem _ hx)
      cases item with
      | popScope _ => simp [LocalizableCont] at hitem
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              rcases sim_halted_with_tail outerInp N ptsN φ hrest_loc hrun hfd hrel
                tailBits u₀ peak₀ outerRest with ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
              refine ⟨1 + f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]; simp only [List.map_cons, List.cons_append, locCont, runArithRAMFuel]
              exact hs₂ f_rem
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ x ∈ (.stmt body :: .repeatLoop r body :: subRest),
                  LocalizableCont x = true := by
                intro x hx
                simp only [List.mem_cons] at hx
                rcases hx with rfl | rfl | hx
                · exact hitem
                · exact hitem
                · exact hrest_loc x hx
              rcases sim_halted_with_tail outerInp N ptsN φ hstk' hrun hfd hrel
                tailBits u₀ peak₀ outerRest with ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
              refine ⟨1 + f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]; simp only [List.map_cons, List.cons_append, locCont, runArithRAMFuel]
              exact hs₂ f_rem
      | stmt s =>
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              have hu_mono := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun
              dsimp only at hu_mono
              rcases sim_halted_with_tail outerInp N ptsN φ hrest_loc hrun hfd hrel
                tailBits (u₀ + 1) peak₀ outerRest with ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
              refine ⟨1 + f₂, u₁, pk₁, m₁, ?_, hrel₁, hpop₁, fun f_rem => ?_⟩
              · dsimp only at hu₁; omega
              · have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
                rw [hf]; simp only [List.map_cons, List.cons_append, locCont, locStmt,
                  runArithRAMFuel]
                exact hs₂ f_rem
          | writeWordHeap t idxE valE =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true,
                decide_eq_true_eq] at hitem
              rcases hitem with ⟨⟨ht, hidx⟩, hval⟩
              simp only [runArithRAMFuel, hfd] at hrun
              have hu_mono := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun
              dsimp only at hu_mono
              have ⟨hv_idx, ho_idx⟩ := sim_locInt outerInp N ptsN φ hrel hidx
              have ⟨hv_val, ho_val⟩ := sim_locInt outerInp N ptsN φ hrel hval
              let subInp := subHPJInput N ptsN φ
              let idx := iValAt 0 subInp subSt.mem idxE
              let val := iValAt 0 subInp subSt.mem valE
              let Δu := intExprOps idxE + intExprOps valE + 1
              have hstep_loc : DetExecAt 1 outerInp (.writeWordLocal t (locInt idxE) (locInt valE))
                  locMem₀ (wWriteL 1 locMem₀ t idx val) Δu :=
                DetExecAt.writeWordLocal 1 outerInp locMem₀ t (locInt idxE) (locInt valE)
                  hv_idx hv_val (by dsimp [Δu]; rw [ho_idx, ho_val])
              rcases hstep_loc (subSt.remainingBits ++ tailBits) u₀ peak₀
                (subRest.map (locCont N) ++ outerRest) with ⟨f₁, u_mid, pk_mid, hu_mid, hs₁⟩
              have hrel' : HPJMemRel N ptsN φ (wWrite subSt.mem t idx val)
                  (wWriteL 1 locMem₀ t idx val) := hrel.wWrite_lt ht idx val
              have hu₁_eq : (evalIntExpr subInp.toWordView 0 subSt.mem.words idxE).2.1 =
                  intExprOps idxE := evalIntExpr_ops _ _ _ idxE
              have hu₂_eq : (evalIntExpr subInp.toWordView 0 subSt.mem.words valE).2.1 =
                  intExprOps valE := evalIntExpr_ops _ _ _ valE
              rcases sim_halted_with_tail outerInp N ptsN φ hrest_loc hrun rfl hrel'
                tailBits u_mid pk_mid outerRest with ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
              refine ⟨f₁ + f₂, u₁, pk₁, m₁, ?_, hrel₁, ?_, fun f_rem => ?_⟩
              · dsimp only [Δu] at hu_mid hu₁ hu_mono
                rw [hu₁_eq, hu₂_eq] at hu₁ hu_mono
                omega
              · rw [hpop₁, popDepth_zero_wWriteL_one]
              · have hf : f₁ + f₂ + f_rem = f₁ + (f₂ + f_rem) := by omega
                rw [hf]; simp only [List.map_cons, List.cons_append, locCont, locStmt]
                rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
          | writeRealHeap t idxE valE =>
              cases hact : isActivePtCoord? valE with
              | some hc_pair =>
                  rcases hc_pair with ⟨hE, cE⟩
                  have hvalE : valE = .activePtCoord hE cE :=
                    isActivePtCoord_eq_some_iff.mp hact
                  subst hvalE
                  simp only [LocalizableCont, LocalizableStmt, isActivePtCoord?,
                    Bool.and_eq_true, decide_eq_true_eq] at hitem
                  rcases hitem with ⟨⟨ht, hidx⟩, ⟨hh, hc⟩⟩
                  simp only [runArithRAMFuel, hfd] at hrun
                  have hu_mono := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun
                  dsimp only at hu_mono
                  let subInp := subHPJInput N ptsN φ
                  let idx := iValAt 0 subInp subSt.mem idxE
                  let val := rValAt 0 subInp subSt.mem (.activePtCoord hE cE)
                  let Δu := intExprOps idxE + (intExprOps hE + intExprOps cE + 1) + 1
                  have hstep_loc := sim_activePtWrite outerInp N t ptsN φ hidx hh hc hrel
                  rcases hstep_loc (subSt.remainingBits ++ tailBits) u₀ peak₀
                    (subRest.map (locCont N) ++ outerRest) with ⟨f₁, u_mid, pk_mid, hu_mid, hs₁⟩
                  have hrel' : HPJMemRel N ptsN φ (rWrite subSt.mem t idx val)
                      (rWriteL 1 locMem₀ t idx val) := hrel.rWrite_lt ht idx val
                  have hu₁_eq : (evalIntExpr subInp.toWordView 0 subSt.mem.words idxE).2.1 =
                      intExprOps idxE := evalIntExpr_ops _ _ _ idxE
                  have hu₂_eq : (evalRealExpr subInp 0 subSt.mem (.activePtCoord hE cE)).2 =
                      intExprOps hE + intExprOps cE + 1 :=
                    evalRealExpr_ops _ _ _ (.activePtCoord hE cE)
                  rcases sim_halted_with_tail outerInp N ptsN φ hrest_loc hrun rfl hrel'
                    tailBits u_mid pk_mid outerRest with ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
                  refine ⟨f₁ + f₂, u₁, pk₁, m₁, ?_, hrel₁, ?_, fun f_rem => ?_⟩
                  · dsimp only [Δu] at hu_mid hu₁ hu_mono
                    rw [hu₁_eq, hu₂_eq] at hu₁ hu_mono
                    omega
                  · rw [hpop₁, popDepth_zero_rWriteL_one]
                  · have hf : f₁ + f₂ + f_rem = f₁ + (f₂ + f_rem) := by omega
                    rw [hf]
                    simp only [List.map_cons, List.cons_append, locCont, locStmt,
                      isActivePtCoord?]
                    rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
              | none =>
                  simp only [LocalizableCont, LocalizableStmt, hact,
                    Bool.and_eq_true, decide_eq_true_eq] at hitem
                  rcases hitem with ⟨⟨ht, hidx⟩, hval⟩
                  simp only [runArithRAMFuel, hfd] at hrun
                  have hu_mono := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun
                  dsimp only at hu_mono
                  have ⟨hv_idx, ho_idx⟩ := sim_locInt outerInp N ptsN φ hrel hidx
                  have ⟨hv_val, ho_val⟩ := sim_locReal outerInp N ptsN φ hrel hval
                  let subInp := subHPJInput N ptsN φ
                  let idx := iValAt 0 subInp subSt.mem idxE
                  let val := rValAt 0 subInp subSt.mem valE
                  let Δu := intExprOps idxE + realExprOps valE + 1
                  have hstep_loc : DetExecAt 1 outerInp
                      (.writeRealLocal t (locInt idxE) (locReal valE))
                      locMem₀ (rWriteL 1 locMem₀ t idx val) Δu :=
                    DetExecAt.writeRealLocal 1 outerInp locMem₀ t (locInt idxE) (locReal valE)
                      hv_idx hv_val (by dsimp [Δu]; rw [ho_idx, ho_val])
                  rcases hstep_loc (subSt.remainingBits ++ tailBits) u₀ peak₀
                    (subRest.map (locCont N) ++ outerRest) with ⟨f₁, u_mid, pk_mid, hu_mid, hs₁⟩
                  have hrel' : HPJMemRel N ptsN φ (rWrite subSt.mem t idx val)
                      (rWriteL 1 locMem₀ t idx val) := hrel.rWrite_lt ht idx val
                  have hu₁_eq : (evalIntExpr subInp.toWordView 0 subSt.mem.words idxE).2.1 =
                      intExprOps idxE := evalIntExpr_ops _ _ _ idxE
                  have hu₂_eq : (evalRealExpr subInp 0 subSt.mem valE).2 =
                      realExprOps valE := evalRealExpr_ops _ _ _ valE
                  rcases sim_halted_with_tail outerInp N ptsN φ hrest_loc hrun rfl hrel'
                    tailBits u_mid pk_mid outerRest with ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
                  refine ⟨f₁ + f₂, u₁, pk₁, m₁, ?_, hrel₁, ?_, fun f_rem => ?_⟩
                  · dsimp only [Δu] at hu_mid hu₁ hu_mono
                    rw [hu₁_eq, hu₂_eq] at hu₁ hu_mono
                    omega
                  · rw [hpop₁, popDepth_zero_rWriteL_one]
                  · have hf : f₁ + f₂ + f_rem = f₁ + (f₂ + f_rem) := by omega
                    rw [hf]
                    simp only [List.map_cons, List.cons_append, locCont, locStmt, hact]
                    rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
          | randBitHeap t idxE =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true,
                decide_eq_true_eq] at hitem
              rcases hitem with ⟨ht, hidx⟩
              cases hbits : subSt.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits, hfd] at hrun
                  have hu_mono := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun
                  dsimp only at hu_mono
                  have ⟨hv_idx, ho_idx⟩ := sim_locInt outerInp N ptsN φ hrel hidx
                  let subInp := subHPJInput N ptsN φ
                  let idx := iValAt 0 subInp subSt.mem idxE
                  let v : ℤ := if bit then 1 else 0
                  have hrel' : HPJMemRel N ptsN φ (wWrite subSt.mem t idx v)
                      (wWriteL 1 locMem₀ t idx v) := hrel.wWrite_lt ht idx v
                  rcases he_loc : evalIntExpr outerInp.toWordView 1 locMem₀.words (locInt idxE)
                    with ⟨idx_loc, u_loc, _⟩
                  have hidx_eq : idx_loc = idx := by dsimp only [idx, subInp]; rw [← hv_idx, iValAt, he_loc]
                  have huloc_eq : u_loc = intExprOps idxE := by
                    have := evalIntExpr_ops outerInp.toWordView 1 locMem₀.words (locInt idxE)
                    rw [he_loc, ho_idx] at this; exact this
                  have husub_eq : (evalIntExpr subInp.toWordView 0 subSt.mem.words idxE).2.1 =
                      intExprOps idxE := evalIntExpr_ops _ _ _ idxE
                  subst hidx_eq
                  let pk_mid := max peak₀
                    (outerInp.inputCellSpace + (wWriteL 1 locMem₀ t idx v).cellCount)
                  rcases sim_halted_with_tail outerInp N ptsN φ hrest_loc hrun rfl hrel'
                    tailBits (u₀ + u_loc + 1) pk_mid outerRest with
                    ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
                  refine ⟨1 + f₂, u₁, pk₁, m₁, ?_, hrel₁, ?_, fun f_rem => ?_⟩
                  · dsimp only at hu₁ hu_mono
                    rw [huloc_eq] at hu₁
                    rw [husub_eq] at hu₁ hu_mono
                    omega
                  · rw [hpop₁, popDepth_zero_wWriteL_one]
                  · have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
                    rw [hf, List.cons_append]
                    simp only [List.map_cons, List.cons_append, locCont, locStmt,
                      runArithRAMFuel, he_loc]
                    dsimp only [wWriteL] at hs₂ ⊢
                    exact hs₂ f_rem
          | seq s₁ s₂ =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ x ∈ (.stmt s₁ :: .stmt s₂ :: subRest),
                  LocalizableCont x = true := by
                intro x hx; simp only [List.mem_cons] at hx
                rcases hx with rfl | rfl | hx
                · exact hitem.1
                · exact hitem.2
                · exact hrest_loc x hx
              rcases sim_halted_with_tail outerInp N ptsN φ hstk' hrun hfd hrel
                tailBits u₀ peak₀ outerRest with ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
              refine ⟨1 + f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]; simp only [List.map_cons, List.cons_append, locCont, locStmt,
                runArithRAMFuel]
              exact hs₂ f_rem
          | ite c tB fB =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true] at hitem
              rcases hitem with ⟨⟨hc_loc, ht_loc⟩, hf_loc⟩
              simp only [runArithRAMFuel, hfd] at hrun
              have hu_mono := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun
              dsimp only at hu_mono
              have ⟨hv_c, ho_c⟩ := sim_locCond outerInp N ptsN φ hrel hc_loc
              rcases hc_eval : evalArithCond outerInp 1 locMem₀ (locCond c) with ⟨flag, u_c⟩
              have hflag : flag = cValAt 0 (subHPJInput N ptsN φ) subSt.mem c := by
                rw [← hv_c, cValAt, hc_eval]
              have huc : u_c = (evalArithCond (subHPJInput N ptsN φ) 0 subSt.mem c).2 := by
                have h1 := evalArithCond_ops outerInp 1 locMem₀ (locCond c)
                have h2 := evalArithCond_ops (subHPJInput N ptsN φ) 0 subSt.mem c
                rw [hc_eval, ho_c, ← h2] at h1; exact h1
              have hstk' : ∀ x ∈ (.stmt (if flag then tB else fB) :: subRest),
                  LocalizableCont x = true := by
                intro x hx; simp only [List.mem_cons] at hx
                rcases hx with rfl | hx
                · split_ifs <;> assumption
                · exact hrest_loc x hx
              have hrun' : runArithRAMFuel (subHPJInput N ptsN φ) subFuel
                  (.stmt (if flag then tB else fB) :: subRest)
                  { subSt with unitCost := subSt.unitCost + u_c } = .halted subOut := by
                cases subSt; dsimp only at hfd hrun ⊢; subst hfd; rw [hflag, huc]; dsimp only [cValAt]; exact hrun
              rcases sim_halted_with_tail outerInp N ptsN φ hstk' hrun' hfd hrel
                tailBits (u₀ + u_c) peak₀ outerRest with ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
              refine ⟨1 + f₂, u₁, pk₁, m₁, ?_, hrel₁, hpop₁, fun f_rem => ?_⟩
              · have hu_m' := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun'
                dsimp only at hu₁ hu_m'; omega
              · have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
                rw [hf]
                simp only [List.map_cons, List.cons_append, locCont, locStmt,
                  runArithRAMFuel, hc_eval]
                cases flag <;> exact hs₂ f_rem
          | whileLoop c body =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true] at hitem
              rcases hitem with ⟨hc_loc, hb_loc⟩
              simp only [runArithRAMFuel, hfd] at hrun
              have hu_mono := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun
              dsimp only at hu_mono
              have ⟨hv_c, ho_c⟩ := sim_locCond outerInp N ptsN φ hrel hc_loc
              rcases hc_eval : evalArithCond outerInp 1 locMem₀ (locCond c) with ⟨flag, u_c⟩
              have hflag : flag = cValAt 0 (subHPJInput N ptsN φ) subSt.mem c := by
                rw [← hv_c, cValAt, hc_eval]
              have huc : u_c = (evalArithCond (subHPJInput N ptsN φ) 0 subSt.mem c).2 := by
                have h1 := evalArithCond_ops outerInp 1 locMem₀ (locCond c)
                have h2 := evalArithCond_ops (subHPJInput N ptsN φ) 0 subSt.mem c
                rw [hc_eval, ho_c, ← h2] at h1; exact h1
              let nextSub := if flag then .stmt body :: .stmt (.whileLoop c body) :: subRest
                else subRest
              have hstk' : ∀ x ∈ nextSub, LocalizableCont x = true := by
                dsimp [nextSub]; split_ifs
                · intro x hx; simp only [List.mem_cons] at hx
                  rcases hx with rfl | rfl | hx
                  · exact hb_loc
                  · simp [LocalizableCont, LocalizableStmt, hc_loc, hb_loc]
                  · exact hrest_loc x hx
                · exact hrest_loc
              have hrun' : runArithRAMFuel (subHPJInput N ptsN φ) subFuel nextSub
                  { subSt with unitCost := subSt.unitCost + u_c } = .halted subOut := by
                cases subSt; dsimp only [nextSub] at hfd hrun ⊢; subst hfd; rw [hflag, huc]; dsimp only [cValAt]; exact hrun
              rcases sim_halted_with_tail outerInp N ptsN φ hstk' hrun' hfd hrel
                tailBits (u₀ + u_c) peak₀ outerRest with ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
              refine ⟨1 + f₂, u₁, pk₁, m₁, ?_, hrel₁, hpop₁, fun f_rem => ?_⟩
              · have hu_m' := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun'
                dsimp only at hu₁ hu_m'; omega
              · have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
                rw [hf]
                simp only [List.map_cons, List.cons_append, locCont, locStmt,
                  runArithRAMFuel, hc_eval]
                cases flag <;> exact hs₂ f_rem
          | repeatN cntE body =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true] at hitem
              rcases hitem with ⟨hcnt_loc, hb_loc⟩
              simp only [runArithRAMFuel, hfd] at hrun
              have hu_mono := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun
              dsimp only at hu_mono
              have ⟨hv_cnt, ho_cnt⟩ := sim_locInt outerInp N ptsN φ hrel hcnt_loc
              rcases he_cnt : evalIntExpr outerInp.toWordView 1 locMem₀.words (locInt cntE)
                with ⟨cnt, u_cnt, _⟩
              have hcnt_eq : cnt = (evalIntExpr (subHPJInput N ptsN φ).toWordView 0
                  subSt.mem.words cntE).1 := by
                change cnt = iValAt 0 (subHPJInput N ptsN φ) subSt.mem cntE
                rw [← hv_cnt, iValAt, he_cnt]
              have hucnt : u_cnt = (evalIntExpr (subHPJInput N ptsN φ).toWordView 0
                  subSt.mem.words cntE).2.1 := by
                have h1 := evalIntExpr_ops outerInp.toWordView 1 locMem₀.words (locInt cntE)
                have h2 := evalIntExpr_ops (subHPJInput N ptsN φ).toWordView 0
                  subSt.mem.words cntE
                rw [he_cnt, ho_cnt, ← h2] at h1; exact h1
              let nIter := if 0 ≤ cnt then cnt.toNat else 0
              have hstk' : ∀ x ∈ (.repeatLoop nIter body :: subRest),
                  LocalizableCont x = true := by
                intro x hx; simp only [List.mem_cons] at hx
                rcases hx with rfl | hx
                · exact hb_loc
                · exact hrest_loc x hx
              have hrun' : runArithRAMFuel (subHPJInput N ptsN φ) subFuel
                  (.repeatLoop nIter body :: subRest)
                  { subSt with unitCost := subSt.unitCost + u_cnt } = .halted subOut := by
                cases subSt; dsimp only at hfd hrun ⊢; subst hfd; dsimp [nIter]; rw [hcnt_eq, hucnt]; exact hrun
              rcases sim_halted_with_tail outerInp N ptsN φ hstk' hrun' hfd hrel
                tailBits (u₀ + u_cnt) peak₀ outerRest with
                ⟨f₂, u₁, pk₁, m₁, hu₁, hrel₁, hpop₁, hs₂⟩
              refine ⟨1 + f₂, u₁, pk₁, m₁, ?_, hrel₁, hpop₁, fun f_rem => ?_⟩
              · have hu_m' := runArithRAMFuel_unitCost_mono (subHPJInput N ptsN φ) hrun'
                dsimp only at hu₁ hu_m'; omega
              · have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
                rw [hf]
                simp only [List.map_cons, List.cons_append, locCont, locStmt,
                  runArithRAMFuel, he_cnt]
                exact hs₂ f_rem
          | writeWordLocal _ _ _ | freeWordHeap _ _ | freeWordLocal _ _
          | writeRealLocal _ _ _ | freeRealHeap _ _ | freeRealLocal _ _
          | randBitLocal _ _ | localScope _ =>
              simp [LocalizableCont, LocalizableStmt] at hitem


theorem sim_short_bits {d : ℕ} (outerInp : ArithRAMInput d) (N : ℕ)
    (ptsN : Fin N → EuclideanSpace ℝ (Fin d)) (φ : ℝ) :
    ∀ {subFuel : ℕ} {subStk : List ArithRAMCont} {subSt : ArithRAMExecState}
      {subOut : ArithRAMExecOutcome} {locMem₀ : ArithRAMMemory}
      {bs pad : List Bool}
      (hstk : ∀ item ∈ subStk, LocalizableCont item = true)
      (hrun : runArithRAMFuel (subHPJInput N ptsN φ) subFuel subStk subSt = .halted subOut)
      (hfd : subSt.frameDepth = 0)
      (hrel : HPJMemRel N ptsN φ subSt.mem locMem₀)
      (hpad : pad ≠ [])
      (hbits_eq : subSt.remainingBits = bs ++ pad)
      (u₀ peak₀ : ℕ) (outerRest : List ArithRAMCont),
      ∃ locFuel : ℕ, ∀ f_rem : ℕ,
        runArithRAMFuel outerInp (locFuel + f_rem)
          (subStk.map (locCont N) ++ outerRest)
          { mem := locMem₀, frameDepth := 1, remainingBits := bs,
            unitCost := u₀, peakCellSpace := peak₀ } = .needMoreBits
  | subFuel, [], subSt, _, _, bs, pad, _, hrun, _, _, hpad, hbits_eq, _, _, _ => by
      cases subFuel <;> {
        cases hrem : subSt.remainingBits.isEmpty
        · simp [runArithRAMFuel, hrem] at hrun
        · exfalso
          have hnil : subSt.remainingBits = [] := List.isEmpty_iff.mp hrem
          rw [hbits_eq] at hnil
          exact hpad (List.append_eq_nil_iff.mp hnil).2
      }
  | 0, _ :: _, _, _, _, _, _, _, hrun, _, _, _, _, _, _, _ => by
      simp [runArithRAMFuel] at hrun
  | subFuel + 1, item :: subRest, subSt, subOut, locMem₀, bs, pad,
    hstk, hrun, hfd, hrel, hpad, hbits_eq, u₀, peak₀, outerRest => by
      have hitem : LocalizableCont item = true := hstk item (List.mem_cons_self)
      have hrest_loc : ∀ x ∈ subRest, LocalizableCont x = true :=
        fun x hx => hstk x (List.mem_cons_of_mem _ hx)
      cases item with
      | popScope _ => simp [LocalizableCont] at hitem
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              rcases sim_short_bits outerInp N ptsN φ hrest_loc hrun hfd hrel hpad hbits_eq
                u₀ peak₀ outerRest with ⟨f₂, hs₂⟩
              refine ⟨1 + f₂, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]; simp only [List.map_cons, List.cons_append, locCont, runArithRAMFuel]
              exact hs₂ f_rem
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ x ∈ (.stmt body :: .repeatLoop r body :: subRest),
                  LocalizableCont x = true := by
                intro x hx; simp only [List.mem_cons] at hx
                rcases hx with rfl | rfl | hx
                · exact hitem
                · exact hitem
                · exact hrest_loc x hx
              rcases sim_short_bits outerInp N ptsN φ hstk' hrun hfd hrel hpad hbits_eq
                u₀ peak₀ outerRest with ⟨f₂, hs₂⟩
              refine ⟨1 + f₂, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]; simp only [List.map_cons, List.cons_append, locCont, runArithRAMFuel]
              exact hs₂ f_rem
      | stmt s =>
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              rcases sim_short_bits outerInp N ptsN φ hrest_loc hrun hfd hrel hpad hbits_eq
                (u₀ + 1) peak₀ outerRest with ⟨f₂, hs₂⟩
              refine ⟨1 + f₂, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]; simp only [List.map_cons, List.cons_append, locCont, locStmt,
                runArithRAMFuel]
              exact hs₂ f_rem
          | writeWordHeap t idxE valE =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true,
                decide_eq_true_eq] at hitem
              rcases hitem with ⟨⟨ht, hidx⟩, hval⟩
              simp only [runArithRAMFuel, hfd] at hrun
              have ⟨hv_idx, ho_idx⟩ := sim_locInt outerInp N ptsN φ hrel hidx
              have ⟨hv_val, ho_val⟩ := sim_locInt outerInp N ptsN φ hrel hval
              let subInp := subHPJInput N ptsN φ
              let idx := iValAt 0 subInp subSt.mem idxE
              let val := iValAt 0 subInp subSt.mem valE
              let Δu := intExprOps idxE + intExprOps valE + 1
              have hstep_loc : DetExecAt 1 outerInp (.writeWordLocal t (locInt idxE) (locInt valE))
                  locMem₀ (wWriteL 1 locMem₀ t idx val) Δu :=
                DetExecAt.writeWordLocal 1 outerInp locMem₀ t (locInt idxE) (locInt valE)
                  hv_idx hv_val (by dsimp [Δu]; rw [ho_idx, ho_val])
              rcases hstep_loc bs u₀ peak₀ (subRest.map (locCont N) ++ outerRest) with
                ⟨f₁, u_mid, pk_mid, _, hs₁⟩
              have hrel' : HPJMemRel N ptsN φ (wWrite subSt.mem t idx val)
                  (wWriteL 1 locMem₀ t idx val) := hrel.wWrite_lt ht idx val
              rcases sim_short_bits outerInp N ptsN φ hrest_loc hrun rfl hrel' hpad hbits_eq
                u_mid pk_mid outerRest with ⟨f₂, hs₂⟩
              refine ⟨f₁ + f₂, fun f_rem => ?_⟩
              have hf : f₁ + f₂ + f_rem = f₁ + (f₂ + f_rem) := by omega
              rw [hf]; simp only [List.map_cons, List.cons_append, locCont, locStmt]
              rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
          | writeRealHeap t idxE valE =>
              cases hact : isActivePtCoord? valE with
              | some hc_pair =>
                  rcases hc_pair with ⟨hE, cE⟩
                  have hvalE : valE = .activePtCoord hE cE :=
                    isActivePtCoord_eq_some_iff.mp hact
                  subst hvalE
                  simp only [LocalizableCont, LocalizableStmt, isActivePtCoord?,
                    Bool.and_eq_true, decide_eq_true_eq] at hitem
                  rcases hitem with ⟨⟨ht, hidx⟩, ⟨hh, hc⟩⟩
                  simp only [runArithRAMFuel, hfd] at hrun
                  let subInp := subHPJInput N ptsN φ
                  let idx := iValAt 0 subInp subSt.mem idxE
                  let val := rValAt 0 subInp subSt.mem (.activePtCoord hE cE)
                  have hstep_loc := sim_activePtWrite outerInp N t ptsN φ hidx hh hc hrel
                  rcases hstep_loc bs u₀ peak₀ (subRest.map (locCont N) ++ outerRest) with
                    ⟨f₁, u_mid, pk_mid, _, hs₁⟩
                  have hrel' : HPJMemRel N ptsN φ (rWrite subSt.mem t idx val)
                      (rWriteL 1 locMem₀ t idx val) := hrel.rWrite_lt ht idx val
                  rcases sim_short_bits outerInp N ptsN φ hrest_loc hrun rfl hrel' hpad hbits_eq
                    u_mid pk_mid outerRest with ⟨f₂, hs₂⟩
                  refine ⟨f₁ + f₂, fun f_rem => ?_⟩
                  have hf : f₁ + f₂ + f_rem = f₁ + (f₂ + f_rem) := by omega
                  rw [hf]
                  simp only [List.map_cons, List.cons_append, locCont, locStmt, isActivePtCoord?]
                  rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
              | none =>
                  simp only [LocalizableCont, LocalizableStmt, hact,
                    Bool.and_eq_true, decide_eq_true_eq] at hitem
                  rcases hitem with ⟨⟨ht, hidx⟩, hval⟩
                  simp only [runArithRAMFuel, hfd] at hrun
                  have ⟨hv_idx, ho_idx⟩ := sim_locInt outerInp N ptsN φ hrel hidx
                  have ⟨hv_val, ho_val⟩ := sim_locReal outerInp N ptsN φ hrel hval
                  let subInp := subHPJInput N ptsN φ
                  let idx := iValAt 0 subInp subSt.mem idxE
                  let val := rValAt 0 subInp subSt.mem valE
                  let Δu := intExprOps idxE + realExprOps valE + 1
                  have hstep_loc : DetExecAt 1 outerInp
                      (.writeRealLocal t (locInt idxE) (locReal valE))
                      locMem₀ (rWriteL 1 locMem₀ t idx val) Δu :=
                    DetExecAt.writeRealLocal 1 outerInp locMem₀ t (locInt idxE) (locReal valE)
                      hv_idx hv_val (by dsimp [Δu]; rw [ho_idx, ho_val])
                  rcases hstep_loc bs u₀ peak₀ (subRest.map (locCont N) ++ outerRest) with
                    ⟨f₁, u_mid, pk_mid, _, hs₁⟩
                  have hrel' : HPJMemRel N ptsN φ (rWrite subSt.mem t idx val)
                      (rWriteL 1 locMem₀ t idx val) := hrel.rWrite_lt ht idx val
                  rcases sim_short_bits outerInp N ptsN φ hrest_loc hrun rfl hrel' hpad hbits_eq
                    u_mid pk_mid outerRest with ⟨f₂, hs₂⟩
                  refine ⟨f₁ + f₂, fun f_rem => ?_⟩
                  have hf : f₁ + f₂ + f_rem = f₁ + (f₂ + f_rem) := by omega
                  rw [hf]
                  simp only [List.map_cons, List.cons_append, locCont, locStmt, hact]
                  rw [hs₁ (f₂ + f_rem), hs₂ f_rem]
          | randBitHeap t idxE =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true,
                decide_eq_true_eq] at hitem
              rcases hitem with ⟨ht, hidx⟩
              cases bs with
              | nil =>
                  refine ⟨1, fun f_rem => ?_⟩
                  have hf : 1 + f_rem = f_rem + 1 := by omega
                  rw [hf]
                  simp [List.map_cons, List.cons_append, locCont, locStmt, runArithRAMFuel]
              | cons bit bs' =>
                  have hsub_bits : subSt.remainingBits = bit :: (bs' ++ pad) := by
                    simpa using hbits_eq
                  simp only [runArithRAMFuel, hsub_bits, hfd] at hrun
                  have ⟨hv_idx, _⟩ := sim_locInt outerInp N ptsN φ hrel hidx
                  let subInp := subHPJInput N ptsN φ
                  let idx := iValAt 0 subInp subSt.mem idxE
                  let v : ℤ := if bit then 1 else 0
                  have hrel' : HPJMemRel N ptsN φ (wWrite subSt.mem t idx v)
                      (wWriteL 1 locMem₀ t idx v) := hrel.wWrite_lt ht idx v
                  rcases he_loc : evalIntExpr outerInp.toWordView 1 locMem₀.words (locInt idxE)
                    with ⟨idx_loc, u_loc, _⟩
                  have hidx_eq : idx_loc = idx := by dsimp only [idx, subInp]; rw [← hv_idx, iValAt, he_loc]
                  subst hidx_eq
                  let pk_mid := max peak₀
                    (outerInp.inputCellSpace + (wWriteL 1 locMem₀ t idx v).cellCount)
                  rcases sim_short_bits outerInp N ptsN φ hrest_loc hrun rfl hrel' hpad rfl
                    (u₀ + u_loc + 1) pk_mid outerRest with ⟨f₂, hs₂⟩
                  refine ⟨1 + f₂, fun f_rem => ?_⟩
                  have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
                  rw [hf]
                  simp only [List.map_cons, List.cons_append, locCont, locStmt,
                    runArithRAMFuel, he_loc]
                  exact hs₂ f_rem
          | seq s₁ s₂ =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ x ∈ (.stmt s₁ :: .stmt s₂ :: subRest),
                  LocalizableCont x = true := by
                intro x hx; simp only [List.mem_cons] at hx
                rcases hx with rfl | rfl | hx
                · exact hitem.1
                · exact hitem.2
                · exact hrest_loc x hx
              rcases sim_short_bits outerInp N ptsN φ hstk' hrun hfd hrel hpad hbits_eq
                u₀ peak₀ outerRest with ⟨f₂, hs₂⟩
              refine ⟨1 + f₂, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]; simp only [List.map_cons, List.cons_append, locCont, locStmt,
                runArithRAMFuel]
              exact hs₂ f_rem
          | ite c tB fB =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true] at hitem
              rcases hitem with ⟨⟨hc_loc, ht_loc⟩, hf_loc⟩
              simp only [runArithRAMFuel, hfd] at hrun
              have ⟨hv_c, ho_c⟩ := sim_locCond outerInp N ptsN φ hrel hc_loc
              rcases hc_eval : evalArithCond outerInp 1 locMem₀ (locCond c) with ⟨flag, u_c⟩
              have hflag : flag = cValAt 0 (subHPJInput N ptsN φ) subSt.mem c := by
                rw [← hv_c, cValAt, hc_eval]
              have huc : u_c = (evalArithCond (subHPJInput N ptsN φ) 0 subSt.mem c).2 := by
                have h1 := evalArithCond_ops outerInp 1 locMem₀ (locCond c)
                have h2 := evalArithCond_ops (subHPJInput N ptsN φ) 0 subSt.mem c
                rw [hc_eval, ho_c, ← h2] at h1; exact h1
              have hstk' : ∀ x ∈ (.stmt (if flag then tB else fB) :: subRest),
                  LocalizableCont x = true := by
                intro x hx; simp only [List.mem_cons] at hx
                rcases hx with rfl | hx
                · split_ifs <;> assumption
                · exact hrest_loc x hx
              have hrun' : runArithRAMFuel (subHPJInput N ptsN φ) subFuel
                  (.stmt (if flag then tB else fB) :: subRest)
                  { subSt with unitCost := subSt.unitCost + u_c } = .halted subOut := by
                cases subSt; dsimp only at hfd hrun ⊢; subst hfd; rw [hflag, huc]; dsimp only [cValAt]; exact hrun
              rcases sim_short_bits outerInp N ptsN φ hstk' hrun' hfd hrel hpad hbits_eq
                (u₀ + u_c) peak₀ outerRest with ⟨f₂, hs₂⟩
              refine ⟨1 + f₂, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]
              simp only [List.map_cons, List.cons_append, locCont, locStmt,
                runArithRAMFuel, hc_eval]
              cases flag <;> exact hs₂ f_rem
          | whileLoop c body =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true] at hitem
              rcases hitem with ⟨hc_loc, hb_loc⟩
              simp only [runArithRAMFuel, hfd] at hrun
              have ⟨hv_c, ho_c⟩ := sim_locCond outerInp N ptsN φ hrel hc_loc
              rcases hc_eval : evalArithCond outerInp 1 locMem₀ (locCond c) with ⟨flag, u_c⟩
              have hflag : flag = cValAt 0 (subHPJInput N ptsN φ) subSt.mem c := by
                rw [← hv_c, cValAt, hc_eval]
              have huc : u_c = (evalArithCond (subHPJInput N ptsN φ) 0 subSt.mem c).2 := by
                have h1 := evalArithCond_ops outerInp 1 locMem₀ (locCond c)
                have h2 := evalArithCond_ops (subHPJInput N ptsN φ) 0 subSt.mem c
                rw [hc_eval, ho_c, ← h2] at h1; exact h1
              let nextSub := if flag then .stmt body :: .stmt (.whileLoop c body) :: subRest
                else subRest
              have hstk' : ∀ x ∈ nextSub, LocalizableCont x = true := by
                dsimp [nextSub]; split_ifs
                · intro x hx; simp only [List.mem_cons] at hx
                  rcases hx with rfl | rfl | hx
                  · exact hb_loc
                  · simp [LocalizableCont, LocalizableStmt, hc_loc, hb_loc]
                  · exact hrest_loc x hx
                · exact hrest_loc
              have hrun' : runArithRAMFuel (subHPJInput N ptsN φ) subFuel nextSub
                  { subSt with unitCost := subSt.unitCost + u_c } = .halted subOut := by
                cases subSt; dsimp only [nextSub] at hfd hrun ⊢; subst hfd; rw [hflag, huc]; dsimp only [cValAt]; exact hrun
              rcases sim_short_bits outerInp N ptsN φ hstk' hrun' hfd hrel hpad hbits_eq
                (u₀ + u_c) peak₀ outerRest with ⟨f₂, hs₂⟩
              refine ⟨1 + f₂, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]
              simp only [List.map_cons, List.cons_append, locCont, locStmt,
                runArithRAMFuel, hc_eval]
              cases flag <;> exact hs₂ f_rem
          | repeatN cntE body =>
              simp only [LocalizableCont, LocalizableStmt, Bool.and_eq_true] at hitem
              rcases hitem with ⟨hcnt_loc, hb_loc⟩
              simp only [runArithRAMFuel, hfd] at hrun
              have ⟨hv_cnt, ho_cnt⟩ := sim_locInt outerInp N ptsN φ hrel hcnt_loc
              rcases he_cnt : evalIntExpr outerInp.toWordView 1 locMem₀.words (locInt cntE)
                with ⟨cnt, u_cnt, _⟩
              have hcnt_eq : cnt = (evalIntExpr (subHPJInput N ptsN φ).toWordView 0
                  subSt.mem.words cntE).1 := by
                change cnt = iValAt 0 (subHPJInput N ptsN φ) subSt.mem cntE
                rw [← hv_cnt, iValAt, he_cnt]
              have hucnt : u_cnt = (evalIntExpr (subHPJInput N ptsN φ).toWordView 0
                  subSt.mem.words cntE).2.1 := by
                have h1 := evalIntExpr_ops outerInp.toWordView 1 locMem₀.words (locInt cntE)
                have h2 := evalIntExpr_ops (subHPJInput N ptsN φ).toWordView 0
                  subSt.mem.words cntE
                rw [he_cnt, ho_cnt, ← h2] at h1; exact h1
              let nIter := if 0 ≤ cnt then cnt.toNat else 0
              have hstk' : ∀ x ∈ (.repeatLoop nIter body :: subRest),
                  LocalizableCont x = true := by
                intro x hx; simp only [List.mem_cons] at hx
                rcases hx with rfl | hx
                · exact hb_loc
                · exact hrest_loc x hx
              have hrun' : runArithRAMFuel (subHPJInput N ptsN φ) subFuel
                  (.repeatLoop nIter body :: subRest)
                  { subSt with unitCost := subSt.unitCost + u_cnt } = .halted subOut := by
                cases subSt; dsimp only at hfd hrun ⊢; subst hfd; dsimp [nIter]; rw [hcnt_eq, hucnt]; exact hrun
              rcases sim_short_bits outerInp N ptsN φ hstk' hrun' hfd hrel hpad hbits_eq
                (u₀ + u_cnt) peak₀ outerRest with ⟨f₂, hs₂⟩
              refine ⟨1 + f₂, fun f_rem => ?_⟩
              have hf : 1 + f₂ + f_rem = (f₂ + f_rem) + 1 := by omega
              rw [hf]
              simp only [List.map_cons, List.cons_append, locCont, locStmt,
                runArithRAMFuel, he_cnt]
              exact hs₂ f_rem
          | writeWordLocal _ _ _ | freeWordHeap _ _ | freeWordLocal _ _
          | writeRealLocal _ _ _ | freeRealHeap _ _ | freeRealLocal _ _
          | randBitLocal _ _ | localScope _ =>
              simp [LocalizableCont, LocalizableStmt] at hitem



/-! ### 4. Top-level `RandExecAt 1` wrapper for `locStmt (2 ^ P.q) hpjProg` -/

private theorem runArithRAMWithBits_some_iff_halted {d : ℕ} {prog : ArithRAMStmt}
    {inp : ArithRAMInput d} {initMem : ArithRAMMemory} {bs : List Bool}
    {out : ArithRAMExecOutcome}
    (h : runArithRAMWithBits prog inp initMem bs = some out) :
    ∃ fuel : ℕ,
      runArithRAMFuel inp fuel [.stmt prog]
        { mem := initMem.popDepth 0
          frameDepth := 0
          remainingBits := bs
          unitCost := 0
          peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } = .halted out := by
  classical
  unfold runArithRAMWithBits at h
  dsimp only at h
  split_ifs at h with hex
  · refine ⟨Nat.find hex, ?_⟩
    generalize hr : runArithRAMFuel inp (Nat.find hex) [.stmt prog] _ = res at h
    cases res with
    | halted o => cases h; rfl
    | needMoreBits | unusedBits | outOfFuel => simp at h

theorem hpjMemRel_of_setup {d : ℕ} (N : ℕ)
    (ptsN : Fin N → EuclideanSpace ℝ (Fin d)) (φ : ℝ)
    (locMem : ArithRAMMemory)
    (ht0 : ∀ t < 100, ∀ idx : ℤ, wReadL 1 locMem t idx = 0)
    (hr0 : ∀ t < 100, ∀ idx : ℤ, rReadL 1 locMem t idx = 0)
    (h100 : ∀ idx : ℤ, wReadL 1 locMem 100 idx = if 0 ≤ idx ∧ idx < (N : ℤ) then idx else 0)
    (h101 : ∀ idx : ℤ, rReadL 1 locMem 101 idx = if idx = 0 then φ else 0)
    (h102 : ∀ (k : Fin N) (c : Fin d),
      rReadL 1 locMem 102 ((k.val : ℤ) * (d : ℤ) + (c.val : ℤ)) = euclideanCoord (ptsN k) c) :
    HPJMemRel N ptsN φ (ArithRAMMemory.empty.popDepth 0) locMem := by
  refine ⟨fun t ht idx => ?_, fun t ht idx => ?_, h100, h101, h102⟩
  · rw [ht0 t ht idx]
    simp [wRead, ArithRAMMemory.popDepth, ArithRAMMemory.empty, WordStore.popDepth,
      WordStore.read, WordStore.empty]
  · rw [hr0 t ht idx]
    simp [rRead, ArithRAMMemory.popDepth, ArithRAMMemory.empty, RealStore.popDepth,
      RealStore.read, RealStore.empty]

theorem sim_locStmt_hpjProg {d : ℕ} (outerInp : ArithRAMInput d)
    {φ : ℝ} (hφ0 : 0 < φ) (hφ1 : φ < 1 / 2)
    (P : HPJParams) (hP_eq : P = hpjParams d φ) (hP : HPJParamProps d φ P)
    (ptsM : Fin (2 ^ P.q) → EuclideanSpace ℝ (Fin d))
    (locMem₀ : ArithRAMMemory)
    (hrel₀ : HPJMemRel (2 ^ P.q) ptsM φ (ArithRAMMemory.empty.popDepth 0) locMem₀) :
    RandExecAt 1 outerInp (locStmt (2 ^ P.q) hpjProg) (P.L * (d + 1 + 3) * P.q) locMem₀
      (fun bits locMem₁ =>
        locMem₁.popDepth 0 = locMem₀.popDepth 0 ∧
        let z := radonWalkOutput (d + 1) P.q P.L (fun j => paraboloidLift (ptsM j)) bits
        (∀ j : Fin d, rReadL 1 locMem₁ 0 (j.val : ℤ) = euclideanCoord (liftedBase z) j) ∧
        rReadL 1 locMem₁ 0 (d : ℤ) = z (Fin.last d))
      (8 * Nat.ceil (hpjOpBound d φ)) := by
  let N := 2 ^ P.q
  let B := P.L * (d + 1 + 3) * P.q
  haveI : Nonempty (Fin N) := ⟨⟨0, Nat.two_pow_pos P.q⟩⟩
  have hspec := hpjProg_spec hφ0 hφ1 P hP_eq hP (Fin N) ptsM ⟨Fin.val, Fin.val_injective⟩ N le_rfl id
  have hinp_eq :
      ({ intParams := List.ofFn (fun k : Fin N => ((⟨Fin.val, Fin.val_injective⟩ : Fin N ↪ ℕ) (id k) : ℤ))
         activeHandles := (Finset.univ : Finset (Fin N)).map ⟨Fin.val, Fin.val_injective⟩
         activeCoords := fun h =>
           if hh : ∃ i : Fin N, (⟨Fin.val, Fin.val_injective⟩ : Fin N ↪ ℕ) i = h then
             ptsM (Classical.choose hh)
           else 0
         extraReals := [φ] } : ArithRAMInput d) = subHPJInput N ptsM φ := rfl
  refine ⟨?_, ?_⟩
  · intro bs hbs u₀ peak₀ outerRest
    let bits_ext : Fin B → Bool := fun j =>
      if hj : j.val < bs.length then bs[j.val] else false
    let full := List.ofFn bits_ext
    let pad := full.drop bs.length
    have hfull_len : full.length = B := List.length_ofFn
    have htake : full.take bs.length = bs := by
      apply List.ext_getElem
      · simp [full, hfull_len]; omega
      · intro i hi1 hi2
        simp [full, bits_ext, hi2]
    have hbits_eq : full = bs ++ pad := by
      simpa [pad, htake] using (List.take_append_drop bs.length full).symm
    have hpad_ne : pad ≠ [] := by
      intro hnil
      have hlen := congrArg List.length hnil
      simp [pad, full, hfull_len] at hlen
      omega
    rcases hspec.2 bits_ext with ⟨subOut, hsome, _, _⟩
    have hsome' : runArithRAMWithBits hpjProg (subHPJInput N ptsM φ) ArithRAMMemory.empty full = some subOut := by
      convert hsome using 2
      unfold subHPJInput
      congr 1
      funext h
      split_ifs <;> rfl
    have hhalted_pair := runArithRAMWithBits_some_iff_halted hsome'
    rcases hhalted_pair with ⟨subFuel, hhalted⟩
    have hstk : ∀ item ∈ ([ArithRAMCont.stmt hpjProg] : List ArithRAMCont),
        LocalizableCont item = true := by
      intro item hmem
      simp only [List.mem_singleton] at hmem
      subst hmem
      exact localizable_hpjProg
    exact sim_short_bits outerInp N ptsM φ hstk hhalted rfl hrel₀ hpad_ne hbits_eq
      u₀ peak₀ outerRest
  · intro bs hbs u₀ peak₀ outerRest
    let bits : Fin B → Bool := fun j => bs[j.val]'(lt_of_lt_of_le j.isLt hbs)
    have htake : bs.take B = List.ofFn bits := by
      apply List.ext_getElem
      · simp; omega
      · intro i hi1 hi2
        simp [bits]
    have hbs_split : bs = List.ofFn bits ++ bs.drop B := by
      rw [← htake]
      exact (List.take_append_drop B bs).symm
    rcases hspec.2 bits with ⟨subOut, hsome, hcost, hread⟩
    have hsome' : runArithRAMWithBits hpjProg (subHPJInput N ptsM φ) ArithRAMMemory.empty (List.ofFn bits) = some subOut := by
      convert hsome using 2
      unfold subHPJInput
      congr 1
      funext h
      split_ifs <;> rfl
    have hhalted_pair := runArithRAMWithBits_some_iff_halted hsome'
    rcases hhalted_pair with ⟨subFuel, hhalted⟩
    have hstk : ∀ item ∈ ([ArithRAMCont.stmt hpjProg] : List ArithRAMCont),
        LocalizableCont item = true := by
      intro item hmem
      simp only [List.mem_singleton] at hmem
      subst hmem
      exact localizable_hpjProg
    rcases sim_halted_with_tail outerInp N ptsM φ hstk hhalted rfl hrel₀
      (bs.drop B) u₀ peak₀ outerRest with
      ⟨locFuel, u₁, pk₁, locMem₁, hu₁, hrel₁, hpop₁, hs₁⟩
    have hcost_nat : subOut.unitCost ≤ Nat.ceil (hpjOpBound d φ) := by
      exact_mod_cast hcost.trans (Nat.le_ceil _)
    refine ⟨locFuel, u₁, pk₁, locMem₁, ?_, ⟨hpop₁, ?_, ?_⟩, fun f_rem => ?_⟩
    · dsimp only at hu₁
      omega
    · intro j
      rw [hrel₁.2.1 0 (by omega) (j.val : ℤ)]
      have hj_eq := congrArg (fun p : EuclideanSpace ℝ (Fin (d + 1)) => p j.castSucc) hread
      simpa [liftedPoint, liftedBase, euclideanCoord, rRead, Fin.snoc_castSucc] using hj_eq
    · rw [hrel₁.2.1 0 (by omega) (d : ℤ)]
      have hd_eq := congrArg (fun p : EuclideanSpace ℝ (Fin (d + 1)) => p (Fin.last d)) hread
      simpa [liftedPoint, euclideanCoord, rRead, Fin.snoc_last] using hd_eq
    · conv_lhs => rw [hbs_split]
      exact hs₁ f_rem

/-! ### 5. Uniform rank sampling via `M_bits`-bit modular reduction and combined HPJ bound -/

theorem bitsFnToNat_injective : ∀ (q : ℕ), Function.Injective (bitsFnToNat q)
  | 0, f₁, f₂, _ => by ext i; exact Fin.elim0 i
  | q + 1, f₁, f₂, h => by
      simp only [bitsFnToNat] at h
      have hlast : (if f₁ (Fin.last q) then 1 else 0) = (if f₂ (Fin.last q) then 1 else 0) := by
        split_ifs at h ⊢ <;> omega
      have hinit_nat : bitsFnToNat q (fun i => f₁ i.castSucc) =
          bitsFnToNat q (fun i => f₂ i.castSucc) := by
        split_ifs at h <;> omega
      have hinit := bitsFnToNat_injective q hinit_nat
      ext i
      refine Fin.lastCases ?_ ?_ i
      · cases h1 : f₁ (Fin.last q) <;> cases h2 : f₂ (Fin.last q) <;> simp_all
      · intro j
        exact congrFun hinit j

theorem bitsFnToFin_bijective (q : ℕ) : Function.Bijective (bitsFnToFin q) := by
  refine (Fintype.bijective_iff_injective_and_card (bitsFnToFin q)).mpr ⟨?_, by simp⟩
  intro f₁ f₂ h
  exact bitsFnToNat_injective q (congrArg Fin.val h)

/-- Read `M_bits` random bits into `localFrame fd v idx` as `(bitsFnToNat M_bits bits : ℤ)`. -/
def readRandNatLocalStmt (v : ℕ) (idx tmpBitIdx : ℤ) (M_bits : ℕ) : ArithRAMStmt :=
  .seq (.writeWordLocal v (.lit idx) (.lit 0))
    (.repeatN (.lit (M_bits : ℤ))
      (.seq (.randBitLocal v (.lit tmpBitIdx))
        (.writeWordLocal v (.lit idx)
          (.add (.mul (.lit 2) (.readLocal v (.lit idx))) (.readLocal v (.lit tmpBitIdx))))))

theorem popDepth_zero_wWriteL_pos {fd : ℕ} (hfd : 1 ≤ fd) (m : ArithRAMMemory) (v : ℕ) (i val : ℤ) :
    (wWriteL fd m v i val).popDepth 0 = m.popDepth 0 := by
  have hkeep : (RAMCellLoc.localFrame fd v i).keepAtDepth 0 = false := by
    simp [RAMCellLoc.keepAtDepth]; omega
  unfold wWriteL ArithRAMMemory.popDepth WordStore.popDepth WordStore.write
  dsimp only
  congr 1
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hmem, hk⟩
      · rw [hkeep] at hk; cases hk
      · exact ⟨hmem, hk⟩
    · rintro ⟨hmem, hk⟩
      exact ⟨Or.inr hmem, hk⟩
  · funext loc
    split_ifs with hk
    · have hne : loc ≠ .localFrame fd v i := by
        intro heq; subst heq; rw [hkeep] at hk; simp at hk
      exact Function.update_of_ne hne val m.words.vals
    · rfl

theorem exec_readRandNatLocalStmt {d : ℕ} {fd : ℕ} (hfd : 1 ≤ fd) (inp : ArithRAMInput d)
    (v : ℕ) (idx tmpBitIdx : ℤ) (hne : idx ≠ tmpBitIdx) (M_bits : ℕ)
    (mem₀ : ArithRAMMemory) :
    RandExecAt fd inp (readRandNatLocalStmt v idx tmpBitIdx M_bits) M_bits mem₀
      (fun bits m_end =>
        wReadL fd m_end v idx = (bitsFnToNat M_bits bits : ℤ) ∧
        (∀ v' idx', (v' ≠ v ∨ (idx' ≠ idx ∧ idx' ≠ tmpBitIdx)) →
          wReadL fd m_end v' idx' = wReadL fd mem₀ v' idx') ∧
        (∀ v' idx', rReadL fd m_end v' idx' = rReadL fd mem₀ v' idx') ∧
        (∀ t idx', wRead m_end t idx' = wRead mem₀ t idx') ∧
        (∀ t idx', rRead m_end t idx' = rRead mem₀ t idx') ∧
        m_end.popDepth 0 = mem₀.popDepth 0)
      (10 + 25 * M_bits) := by
  have hinit : DetExecAt fd inp (.writeWordLocal v (.lit idx) (.lit 0)) mem₀
      (wWriteL fd mem₀ v idx 0) 5 :=
    DetExecAt.writeWordLocal fd inp mem₀ v (.lit idx) (.lit 0) rfl rfl
      (by dsimp [intExprOps]; omega)
  let m_init := wWriteL fd mem₀ v idx 0
  let Inv : ℕ → (ℕ → Fin 1 → Bool) → ArithRAMMemory → Prop := fun i chunks m =>
    wReadL fd m v idx =
      (bitsFnToNat i (fun r : Fin i => chunks r.val ⟨0, Nat.zero_lt_one⟩) : ℤ) ∧
    (∀ v' idx', (v' ≠ v ∨ (idx' ≠ idx ∧ idx' ≠ tmpBitIdx)) →
      wReadL fd m v' idx' = wReadL fd mem₀ v' idx') ∧
    (∀ v' idx', rReadL fd m v' idx' = rReadL fd mem₀ v' idx') ∧
    (∀ t idx', wRead m t idx' = wRead mem₀ t idx') ∧
    (∀ t idx', rRead m t idx' = rRead mem₀ t idx') ∧
    m.popDepth 0 = mem₀.popDepth 0
  have hInv0 : Inv 0 (fun _ _ => false) m_init := by
    refine ⟨by simp [m_init, bitsFnToNat], fun v' idx' hor => ?_,
      fun v' idx' => by simp [m_init], fun t idx' => by simp [m_init],
      fun t idx' => by simp [m_init], popDepth_zero_wWriteL_pos hfd mem₀ v idx 0⟩
    rcases hor with hv | ⟨hi, _⟩
    · exact wReadL_wWriteL_of_ne fd mem₀ 0 (Or.inl hv)
    · exact wReadL_wWriteL_of_ne fd mem₀ 0 (Or.inr hi)
  have hloop := RandExecAt.repeatN_nat (fd := fd) (inp := inp) (chunks₀ := fun _ _ => false)
    (.lit (M_bits : ℤ))
    (.seq (.randBitLocal v (.lit tmpBitIdx))
      (.writeWordLocal v (.lit idx)
        (.add (.mul (.lit 2) (.readLocal v (.lit idx))) (.readLocal v (.lit tmpBitIdx)))))
    M_bits 1 5 25 Inv hInv0 rfl (by dsimp [intExprOps]; omega)
    (fun i _ chunks m ⟨hacc, hlw, hlr, hhw, hhr, hpop⟩ => by
      have hrnd := RandExecAt.randBitLocal fd inp m v (.lit tmpBitIdx) rfl
        (C := 5) (by dsimp [intExprOps]; omega)
      refine RandExecAt.seq_det_right (C₂ := 20) hrnd (fun b m1 hm1 => ?_)
      subst hm1
      let bitVal : ℤ := if b ⟨0, Nat.zero_lt_one⟩ then 1 else 0
      let newAcc : ℤ := 2 * (bitsFnToNat i (fun r : Fin i => chunks r.val ⟨0, Nat.zero_lt_one⟩) : ℤ) + bitVal
      have hwr : DetExecAt fd inp
          (.writeWordLocal v (.lit idx)
            (.add (.mul (.lit 2) (.readLocal v (.lit idx))) (.readLocal v (.lit tmpBitIdx))))
          (wWriteL fd m v tmpBitIdx bitVal)
          (wWriteL fd (wWriteL fd m v tmpBitIdx bitVal) v idx newAcc) 20 := by
        refine DetExecAt.writeWordLocal fd inp _ v (.lit idx) _ rfl ?_ (by dsimp [intExprOps]; omega)
        simp only [iValAt_add, iValAt_mul, iValAt_lit, iValAt_readLocal]
        rw [wReadL_wWriteL_of_ne fd m bitVal (Or.inr hne), hacc, wReadL_wWriteL_self]
      refine ⟨_, hwr, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · rw [wReadL_wWriteL_self]
        dsimp [newAcc, bitVal]
        simp only [bitsFnToNat, Nat.cast_add, Nat.cast_mul, Nat.cast_ofNat]
        have hinit_eq :
            (fun r : Fin i =>
              Function.update chunks i b r.castSucc.val (0 : Fin 1)) =
            (fun r : Fin i => chunks r.val (0 : Fin 1)) := by
          ext r
          rw [Fin.val_castSucc, Function.update_of_ne (ne_of_lt r.isLt)]
        rw [hinit_eq]
        simp only [Fin.val_last, Function.update_self]
        cases b ⟨0, Nat.zero_lt_one⟩ <;> simp
      · intro v' idx' hor
        rcases hor with hv | ⟨hi1, hi2⟩
        · rw [wReadL_wWriteL_of_ne fd _ _ (Or.inl hv),
              wReadL_wWriteL_of_ne fd _ _ (Or.inl hv), hlw v' idx' (Or.inl hv)]
        · rw [wReadL_wWriteL_of_ne fd _ _ (Or.inr hi1),
              wReadL_wWriteL_of_ne fd _ _ (Or.inr hi2), hlw v' idx' (Or.inr ⟨hi1, hi2⟩)]
      · intro v' idx'
        simp [hlr v' idx']
      · intro t idx'
        simp [hhw t idx']
      · intro t idx'
        simp [hhr t idx']
      · rw [popDepth_zero_wWriteL_pos hfd, popDepth_zero_wWriteL_pos hfd, hpop])
  have hseq := RandExecAt.seq_det_left hinit hloop
  refine (hseq.congr_bits (Nat.mul_one M_bits) ?_).mono (fun f m h => h) (by omega)
  intro bits m_end ⟨chunks_N, ⟨hacc, hlw, hlr, hhw, hhr, hpop⟩, hch⟩
  refine ⟨?_, hlw, hlr, hhw, hhr, hpop⟩
  rw [hacc]
  congr 2
  ext r
  rw [hch r]
  dsimp only
  congr 1
  apply Fin.ext
  simp

/-- Modular sample index tuple `(bitsFnToNat M_bits (f j)) % m` for `K` draws. -/
def modSampleTuple {m : ℕ} (hm : 0 < m) (K M_bits : ℕ)
    (f : Fin K → Fin M_bits → Bool) : Fin K → Fin m :=
  fun j => ⟨bitsFnToNat M_bits (f j) % m, Nat.mod_lt _ hm⟩

theorem modSample_bad_card_le {m : ℕ} (hm : 0 < m) (K M_bits : ℕ)
    (Bad : (Fin K → Fin m) → Prop) [DecidablePred Bad]
    {p_bad : ℝ} (hp0 : 0 ≤ p_bad)
    (hBad : ((Finset.univ.filter Bad).card : ℝ) ≤ p_bad * ((m : ℝ) ^ K)) :
    ((Finset.univ.filter (fun f : Fin K → Fin M_bits → Bool =>
        Bad (modSampleTuple hm K M_bits f))).card : ℝ) ≤
      (p_bad + (K : ℝ) * (m : ℝ) / ((2 : ℝ) ^ M_bits)) * (((2 : ℝ) ^ M_bits) ^ K) := by
  classical
  let N2 : ℕ := 2 ^ M_bits
  have hN2_pos : 0 < N2 := Nat.two_pow_pos M_bits
  let e1 : (Fin M_bits → Bool) ≃ Fin N2 :=
    Equiv.ofBijective (bitsFnToFin M_bits) (bitsFnToFin_bijective M_bits)
  let eK : (Fin K → Fin M_bits → Bool) ≃ (Fin K → Fin N2) :=
    Equiv.arrowCongr (Equiv.refl (Fin K)) e1
  let sampNat : (Fin K → Fin N2) → (Fin K → Fin m) :=
    fun u j => ⟨(u j).val % m, Nat.mod_lt _ hm⟩
  have hcard_eq :
      (Finset.univ.filter (fun f : Fin K → Fin M_bits → Bool =>
        Bad (modSampleTuple hm K M_bits f))).card =
      (Finset.univ.filter (fun u : Fin K → Fin N2 => Bad (sampNat u))).card := by
    refine Finset.card_bij (fun f _ => eK f) ?_ ?_ ?_
    · intro f hf
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hf ⊢
      exact hf
    · intro f₁ _ f₂ _ heq
      exact eK.injective heq
    · intro u hu
      refine ⟨eK.symm u, ?_, eK.apply_symm_apply u⟩
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hu ⊢
      convert hu using 2
      ext j
      have happ : e1 ((eK.symm u) j) = u j := congrFun (eK.apply_symm_apply u) j
      have hval : bitsFnToNat M_bits ((eK.symm u) j) = (u j).val := congrArg Fin.val happ
      simp [modSampleTuple, sampNat, hval]
  rw [hcard_eq]
  let q : ℕ := N2 / m
  let Unclean : Finset (Fin K → Fin N2) :=
    Finset.univ.filter (fun u : Fin K → Fin N2 => ∃ j : Fin K, q * m ≤ (u j).val)
  let CleanBad : Finset (Fin K → Fin N2) :=
    Finset.univ.filter (fun u : Fin K → Fin N2 =>
      (∀ j : Fin K, (u j).val < q * m) ∧ Bad (sampNat u))
  have hsub :
      Finset.univ.filter (fun u : Fin K → Fin N2 => Bad (sampNat u)) ⊆ Unclean ∪ CleanBad := by
    intro u hu
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hu
    by_cases hc : ∀ j : Fin K, (u j).val < q * m
    · exact Finset.mem_union_right _ (by simp [CleanBad, hc, hu])
    · push_neg at hc
      exact Finset.mem_union_left _ (by simp [Unclean, hc])
  have hcard_split :
      (Finset.univ.filter (fun u : Fin K → Fin N2 => Bad (sampNat u))).card ≤
        Unclean.card + CleanBad.card :=
    (Finset.card_le_card hsub).trans (Finset.card_union_le _ _)
  -- Bound CleanBad.card ≤ q^K * (filter Bad).card via div/mod injection
  have hClean_le : CleanBad.card ≤ q ^ K * (Finset.univ.filter Bad).card := by
    let Target := (Fin K → Fin q) × {ω : Fin K → Fin m // ω ∈ Finset.univ.filter Bad}
    let phi : {u // u ∈ CleanBad} → Target := fun ⟨u, hu⟩ =>
      have huc : (∀ j : Fin K, (u j).val < q * m) ∧ Bad (sampNat u) := by
        simpa [CleanBad] using hu
      (fun j => ⟨(u j).val / m, (Nat.div_lt_iff_lt_mul hm).mpr (huc.1 j)⟩,
       ⟨sampNat u, by simp [huc.2]⟩)
    have hphi_inj : Function.Injective phi := by
      rintro ⟨u₁, hu₁⟩ ⟨u₂, hu₂⟩ heq
      have h1 := congrArg Prod.fst heq
      have h2 := congrArg (fun x => x.2.1) heq
      apply Subtype.ext
      ext j
      have hdiv : (u₁ j).val / m = (u₂ j).val / m := congrArg Fin.val (congrFun h1 j)
      have hmod : (u₁ j).val % m = (u₂ j).val % m := congrArg Fin.val (congrFun h2 j)
      dsimp only
      linarith [Nat.div_add_mod (u₁ j).val m, Nat.div_add_mod (u₂ j).val m, congrArg (m * ·) hdiv, hmod]
    have hcard_t := Fintype.card_le_of_injective phi hphi_inj
    simp only [Target, Fintype.card_prod, Fintype.card_fun, Fintype.card_fin, Fintype.card_coe] at hcard_t
    exact hcard_t
  -- Bound Unclean.card
  have hUnclean_real :
      (Unclean.card : ℝ) ≤
        ((K : ℝ) * (m : ℝ) / ((2 : ℝ) ^ M_bits)) * (((2 : ℝ) ^ M_bits) ^ K) := by
    cases K with
    | zero =>
        have hempty : Unclean = ∅ := by
          ext u; simp [Unclean]
        simp [hempty]
    | succ K' =>
        have hbi :
            Unclean ⊆ (Finset.univ : Finset (Fin (K' + 1))).biUnion (fun j₀ =>
              Finset.univ.filter (fun u : Fin (K' + 1) → Fin N2 => q * m ≤ (u j₀).val)) := by
          intro u hu
          simp only [Unclean, Finset.mem_filter, Finset.mem_univ, true_and] at hu
          rcases hu with ⟨j₀, hj₀⟩
          exact Finset.mem_biUnion.mpr ⟨j₀, Finset.mem_univ _, by simp [hj₀]⟩
        have hEach : ∀ j₀ : Fin (K' + 1),
            (Finset.univ.filter (fun u : Fin (K' + 1) → Fin N2 => q * m ≤ (u j₀).val)).card ≤
              m * N2 ^ K' := by
          intro j₀
          let S_j := Finset.univ.filter (fun u : Fin (K' + 1) → Fin N2 => q * m ≤ (u j₀).val)
          let psi : {u // u ∈ S_j} → Fin m × ({j : Fin (K' + 1) // j ≠ j₀} → Fin N2) :=
            fun ⟨u, hu⟩ =>
              have hge : q * m ≤ (u j₀).val := by simpa [S_j] using hu
              have hlt : (u j₀).val - q * m < m := by
                have hdm : q * m + N2 % m = N2 := by
                  dsimp [q]; rw [Nat.mul_comm]; exact Nat.div_add_mod N2 m
                have hrm := Nat.mod_lt N2 hm
                have hu_lt := (u j₀).isLt
                omega
              (⟨(u j₀).val - q * m, hlt⟩, fun j => u j.1)
          have hpsi_inj : Function.Injective psi := by
            rintro ⟨u₁, hu₁⟩ ⟨u₂, hu₂⟩ heq
            have hge₁ : q * m ≤ (u₁ j₀).val := by simpa [S_j] using hu₁
            have hge₂ : q * m ≤ (u₂ j₀).val := by simpa [S_j] using hu₂
            have h1 := congrArg (fun p => p.1.val) heq
            have h2 := congrArg Prod.snd heq
            dsimp [psi] at h1 h2
            apply Subtype.ext
            ext j
            by_cases hj : j = j₀
            · subst hj; dsimp only; omega
            · exact congrArg Fin.val (congrFun h2 ⟨j, hj⟩)
          have hc := Fintype.card_le_of_injective psi hpsi_inj
          have hcard_ne : Fintype.card {j : Fin (K' + 1) // j ≠ j₀} = K' := by
            rw [Fintype.card_subtype_compl, Fintype.card_fin, Fintype.card_unique]
            simp
          simpa [Fintype.card_prod, Fintype.card_fun, Fintype.card_fin, Fintype.card_coe, hcard_ne]
            using hc
        have hUnc_nat : Unclean.card ≤ (K' + 1) * (m * N2 ^ K') := by
          calc Unclean.card
              ≤ ((Finset.univ : Finset (Fin (K' + 1))).biUnion (fun j₀ =>
                  Finset.univ.filter (fun u : Fin (K' + 1) → Fin N2 => q * m ≤ (u j₀).val))).card :=
                Finset.card_le_card hbi
            _ ≤ ∑ j₀ : Fin (K' + 1),
                  (Finset.univ.filter (fun u : Fin (K' + 1) → Fin N2 => q * m ≤ (u j₀).val)).card :=
                Finset.card_biUnion_le
            _ ≤ ∑ _j₀ : Fin (K' + 1), (m * N2 ^ K') := Finset.sum_le_sum (fun j₀ _ => hEach j₀)
            _ = (K' + 1) * (m * N2 ^ K') := by simp
        have hN2_real : (N2 : ℝ) = (2 : ℝ) ^ M_bits := by simp [N2]
        have hN2_ne : ((2 : ℝ) ^ M_bits) ≠ 0 := by positivity
        calc (Unclean.card : ℝ)
            ≤ (((K' + 1) * (m * N2 ^ K') : ℕ) : ℝ) := by exact_mod_cast hUnc_nat
          _ = (((K' + 1 : ℕ) : ℝ) * (m : ℝ) / ((2 : ℝ) ^ M_bits)) * (((2 : ℝ) ^ M_bits) ^ (K' + 1)) := by
              push_cast
              rw [hN2_real, pow_succ]
              field_simp [hN2_ne]
  have hClean_real :
      (CleanBad.card : ℝ) ≤ p_bad * (((2 : ℝ) ^ M_bits) ^ K) := by
    have hqm : (q : ℝ) * (m : ℝ) ≤ (2 : ℝ) ^ M_bits := by
      have hqm_nat : q * m ≤ N2 := Nat.div_mul_le_self N2 m
      have : ((q * m : ℕ) : ℝ) ≤ (N2 : ℝ) := by exact_mod_cast hqm_nat
      simpa [N2] using this
    calc (CleanBad.card : ℝ)
        ≤ ((q ^ K * (Finset.univ.filter Bad).card : ℕ) : ℝ) := by exact_mod_cast hClean_le
      _ = ((q : ℝ) ^ K) * ((Finset.univ.filter Bad).card : ℝ) := by push_cast; ring
      _ ≤ ((q : ℝ) ^ K) * (p_bad * ((m : ℝ) ^ K)) :=
          mul_le_mul_of_nonneg_left hBad (by positivity)
      _ = p_bad * (((q : ℝ) * (m : ℝ)) ^ K) := by ring
      _ ≤ p_bad * (((2 : ℝ) ^ M_bits) ^ K) := by
          gcongr
  calc ((Finset.univ.filter (fun u : Fin K → Fin N2 => Bad (sampNat u))).card : ℝ)
      ≤ ((Unclean.card + CleanBad.card : ℕ) : ℝ) := by exact_mod_cast hcard_split
    _ = (Unclean.card : ℝ) + (CleanBad.card : ℝ) := by push_cast; ring
    _ ≤ ((K : ℝ) * (m : ℝ) / ((2 : ℝ) ^ M_bits)) * (((2 : ℝ) ^ M_bits) ^ K) +
          p_bad * (((2 : ℝ) ^ M_bits) ^ K) := add_le_add hUnclean_real hClean_real
    _ = (p_bad + (K : ℝ) * (m : ℝ) / ((2 : ℝ) ^ M_bits)) * (((2 : ℝ) ^ M_bits) ^ K) := by ring

open Classical in
/-- Combined failure-cardinality bound for HPJ centerpoint on `S : Finset ℕ` (`1 ≤ S.card`) when
`2 ^ P.q` initial points are drawn via `M_bits`-bit modular rank sampling (`enum : Fin S.card ≃ ↥S`)
followed by `B_hpj = P.L * (d + 1 + 3) * P.q` Radon-walk bits. -/
theorem hpj_combined_bad_card_le {d : ℕ} {φ_hpj : ℝ}
    (hφ0 : 0 < φ_hpj) (hφ1 : φ_hpj < 1 / 2)
    (P : HPJParams) (hP : HPJParamProps d φ_hpj P)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (S : Finset ℕ) (hS_pos : 0 < S.card)
    (enum : Fin S.card ≃ ↥S)
    (M_bits : ℕ) :
    let K := 2 ^ P.q
    let B_walk := P.L * (d + 1 + 3) * P.q
    let B_tot := K * M_bits + B_walk
    let Q : ↥S → EuclideanSpace ℝ (Fin (d + 1)) := paraboloidLiftSet (fun x : ↥S => pts x.1)
    ((Finset.univ.filter (fun allBits : Fin B_tot → Bool =>
        let sampBits : Fin K → Fin M_bits → Bool := fun j b =>
          allBits ⟨j.val * M_bits + b.val, by
            have hj := j.isLt; have hb := b.isLt
            calc j.val * M_bits + b.val < j.val * M_bits + M_bits := by omega
              _ = (j.val + 1) * M_bits := by ring
              _ ≤ K * M_bits := Nat.mul_le_mul_right M_bits hj
              _ ≤ B_tot := Nat.le_add_right _ _⟩
        let walkBits : Fin B_walk → Bool := fun w =>
          allBits ⟨K * M_bits + w.val, Nat.add_lt_add_left w.isLt _⟩
        let rk := modSampleTuple hS_pos K M_bits sampBits
        let z := radonWalkOutput (d + 1) P.q P.L
          (fun j : Fin K => paraboloidLift (pts (enum (rk j)).1)) walkBits
        ¬ IsCenterpoint (hpjAlpha d) Q z)).card : ℝ) ≤
      (φ_hpj + ((K : ℝ) * (S.card : ℝ) / ((2 : ℝ) ^ M_bits))) * ((2 : ℝ) ^ B_tot) := by
  intro K B_walk B_tot Q
  haveI : Nonempty ↥S := Finset.Nonempty.coe_sort (Finset.card_pos.mp hS_pos)
  -- Step 1: bound bad `rk : Fin K → Fin S.card` where `¬ GoodInitialSample Q (hpjAlpha d) (enum ∘ rk)`
  let BadInit : (Fin K → Fin S.card) → Prop := fun rk =>
    ¬ GoodInitialSample Q (hpjAlpha d) (fun j => enum (rk j))
  have hGoodInit_S :=
    card_goodInitialSample_prefix_ge hφ0 hφ1 P hP ↥S Q K le_rfl
  have hBadInit_le :
      ((Finset.univ.filter BadInit).card : ℝ) ≤ (φ_hpj / 2) * ((S.card : ℝ) ^ K) := by
    let eS : (Fin K → Fin S.card) ≃ (Fin K → ↥S) := Equiv.arrowCongr (Equiv.refl _) enum
    have hgood_eq :
        (Finset.univ.filter (fun rk : Fin K → Fin S.card => ¬ BadInit rk)).card =
        (Finset.univ.filter (fun ω : Fin K → ↥S =>
          GoodInitialSample Q (hpjAlpha d) (fun j : Fin K => ω ⟨j.val, j.isLt⟩))).card := by
      refine Finset.card_bij (fun rk _ => eS rk) ?_ (fun _ _ _ _ h => eS.injective h) ?_
      · intro rk hrk
        simp only [Finset.mem_filter, Finset.mem_univ, true_and, BadInit, not_not] at hrk ⊢
        exact hrk
      · intro ω hω
        refine ⟨eS.symm ω, ?_, eS.apply_symm_apply ω⟩
        simp only [Finset.mem_filter, Finset.mem_univ, true_and, BadInit, not_not] at hω ⊢
        change GoodInitialSample Q (hpjAlpha d) (eS (eS.symm ω))
        rw [eS.apply_symm_apply]
        exact hω
    have hcompl :
        (Finset.univ.filter BadInit).card +
          (Finset.univ.filter (fun rk : Fin K → Fin S.card => ¬ BadInit rk)).card =
        S.card ^ K := by
      have hcf := Finset.card_filter_add_card_filter_not (s := Finset.univ) BadInit
      simpa only [Finset.card_univ, Fintype.card_fun, Fintype.card_fin, Fintype.card_coe] using hcf
    have hcard_S : (Fintype.card (Fin K → ↥S) : ℝ) = (S.card : ℝ) ^ K := by
      simp [Fintype.card_fun, Fintype.card_fin]
    have hcompl_r :
        ((Finset.univ.filter BadInit).card : ℝ) +
          ((Finset.univ.filter (fun rk : Fin K → Fin S.card => ¬ BadInit rk)).card : ℝ) =
        (S.card : ℝ) ^ K := by exact_mod_cast hcompl
    rw [hgood_eq] at hcompl_r
    rw [hcard_S] at hGoodInit_S
    linarith
  have hModBad := modSample_bad_card_le hS_pos K M_bits BadInit (by linarith) hBadInit_le
  -- Step 2: for every `sampBits` with `¬ BadInit (modSampleTuple ...)`, at most `(φ_hpj / 2) * 2^B_walk` walkBits fail
  let splitEquiv :
      (Fin B_tot → Bool) ≃ (Fin K → Fin M_bits → Bool) × (Fin B_walk → Bool) :=
    { toFun := fun allBits =>
        (fun j b => allBits ⟨j.val * M_bits + b.val, by
            have hj := j.isLt; have hb := b.isLt
            calc j.val * M_bits + b.val < j.val * M_bits + M_bits := by omega
              _ = (j.val + 1) * M_bits := by ring
              _ ≤ K * M_bits := Nat.mul_le_mul_right M_bits hj
              _ ≤ B_tot := Nat.le_add_right _ _⟩,
         fun w => allBits ⟨K * M_bits + w.val, Nat.add_lt_add_left w.isLt _⟩)
      invFun := fun ⟨sb, wb⟩ idx =>
        if h : idx.val < K * M_bits then
          have hM_pos : 0 < M_bits := by
            by_contra h0; simp [Nat.eq_zero_of_not_pos h0] at h
          sb ⟨idx.val / M_bits, (Nat.div_lt_iff_lt_mul hM_pos).mpr (by simpa [Nat.mul_comm] using h)⟩
             ⟨idx.val % M_bits, Nat.mod_lt _ hM_pos⟩
        else
          wb ⟨idx.val - K * M_bits, by have := idx.isLt; dsimp [B_tot] at this; omega⟩
      left_inv := fun allBits => by
        ext idx
        by_cases h : idx.val < K * M_bits
        · have hM_pos : 0 < M_bits := by
            by_contra h0; simp [Nat.eq_zero_of_not_pos h0] at h
          simp only [h, ↓reduceDIte]
          congr 1; ext; dsimp
          have := Nat.div_add_mod idx.val M_bits
          rw [Nat.mul_comm] at this
          exact this
        · simp only [h, ↓reduceDIte]
          congr 1; ext; dsimp; omega
      right_inv := fun ⟨sb, wb⟩ => by
        ext j b
        · have hlt : j.val * M_bits + b.val < K * M_bits := by
            calc j.val * M_bits + b.val < j.val * M_bits + M_bits := by have := b.isLt; omega
              _ = (j.val + 1) * M_bits := by ring
              _ ≤ K * M_bits := Nat.mul_le_mul_right M_bits j.isLt
          have hM_pos : 0 < M_bits := Nat.pos_of_ne_zero (by intro h0; subst h0; exact Fin.elim0 b)
          simp only [hlt, ↓reduceDIte]
          have hdiv : (j.val * M_bits + b.val) / M_bits = j.val := by
            rw [Nat.add_comm, Nat.mul_comm, Nat.add_mul_div_left _ _ hM_pos,
              Nat.div_eq_of_lt b.isLt, Nat.zero_add]
          have hmod : (j.val * M_bits + b.val) % M_bits = b.val := by
            rw [Nat.add_comm, Nat.mul_comm, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt b.isLt]
          congr 1 <;> ext <;> simp [hdiv, hmod]
        · have hnlt : ¬ (K * M_bits + j.val < K * M_bits) := by omega
          simp only [hnlt, ↓reduceDIte]
          congr 1; ext; simp }
  let BadPair : ((Fin K → Fin M_bits → Bool) × (Fin B_walk → Bool)) → Prop := fun p =>
    let rk := modSampleTuple hS_pos K M_bits p.1
    let z := radonWalkOutput (d + 1) P.q P.L
      (fun j : Fin K => paraboloidLift (pts (enum (rk j)).1)) p.2
    ¬ IsCenterpoint (hpjAlpha d) Q z
  have hbij :
      (Finset.univ.filter (fun allBits : Fin B_tot → Bool => BadPair (splitEquiv allBits))).card =
      (Finset.univ.filter BadPair).card := by
    refine Finset.card_bij (fun a _ => splitEquiv a) ?_ (fun _ _ _ _ h => splitEquiv.injective h) ?_
    · intro a ha; simpa using ha
    · intro p hp
      refine ⟨splitEquiv.symm p, ?_, splitEquiv.apply_symm_apply p⟩
      simpa [splitEquiv.apply_symm_apply] using hp
  change ((Finset.univ.filter (fun allBits : Fin B_tot → Bool =>
    BadPair (splitEquiv allBits))).card : ℝ) ≤ _
  rw [hbij]
  let S1 := Finset.univ.filter (fun sb : Fin K → Fin M_bits → Bool =>
    BadInit (modSampleTuple hS_pos K M_bits sb))
  have hsub2 :
      Finset.univ.filter BadPair ⊆
        (S1 ×ˢ (Finset.univ : Finset (Fin B_walk → Bool))) ∪
        (Finset.univ.filter (fun sb => ¬ BadInit (modSampleTuple hS_pos K M_bits sb))).biUnion
          (fun sb => (Finset.univ.filter (fun wb : Fin B_walk → Bool => BadPair (sb, wb))).map
            ⟨fun wb => (sb, wb), fun _ _ h => (Prod.mk.inj h).2⟩) := by
    rintro ⟨sb, wb⟩ hp
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hp
    by_cases hb : BadInit (modSampleTuple hS_pos K M_bits sb)
    · exact Finset.mem_union_left _ (by simp [S1, hb])
    · refine Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨sb, by simp [hb], ?_⟩)
      simp [hp]
  have hWalkEach : ∀ sb : Fin K → Fin M_bits → Bool,
      ¬ BadInit (modSampleTuple hS_pos K M_bits sb) →
      ((Finset.univ.filter (fun wb : Fin B_walk → Bool => BadPair (sb, wb))).card : ℝ) ≤
        (φ_hpj / 2) * ((2 : ℝ) ^ B_walk) := by
    intro sb hgood
    simp only [BadInit, not_not] at hgood
    have hgw := card_goodWalkBits_centerpoint_ge hφ0 hφ1 P hP
      (fun pts' K' hK' hr => gaussRadonPoint_avoid_of_convex pts' K' hK' hr)
      ↥S Q (fun j => enum (modSampleTuple hS_pos K M_bits sb j)) hgood
    have hcompl :
        (Finset.univ.filter (fun wb : Fin B_walk → Bool => BadPair (sb, wb))).card +
        (Finset.univ.filter (fun wb : Fin B_walk → Bool =>
          IsCenterpoint (hpjAlpha d) Q
            (radonWalkOutput (d + 1) P.q P.L
              (fun j => Q (enum (modSampleTuple hS_pos K M_bits sb j))) wb))).card =
        2 ^ B_walk := by
      have hcf := Finset.card_filter_add_card_filter_not (s := Finset.univ) (fun wb : Fin B_walk → Bool => BadPair (sb, wb))
      have heq_neg : Finset.univ.filter (fun wb : Fin B_walk → Bool => ¬ BadPair (sb, wb)) =
          Finset.univ.filter (fun wb : Fin B_walk → Bool =>
            IsCenterpoint (hpjAlpha d) Q
              (radonWalkOutput (d + 1) P.q P.L
                (fun j => Q (enum (modSampleTuple hS_pos K M_bits sb j))) wb)) := by
        ext wb; simp only [Finset.mem_filter, Finset.mem_univ, true_and]; dsimp only [BadPair, Q, paraboloidLiftSet]; exact not_not
      rw [← heq_neg]
      simpa only [Finset.card_univ, Fintype.card_fun, Fintype.card_fin, Fintype.card_bool] using hcf
    have hcompl_r :
        ((Finset.univ.filter (fun wb : Fin B_walk → Bool => BadPair (sb, wb))).card : ℝ) +
        ((Finset.univ.filter (fun wb : Fin B_walk → Bool =>
          IsCenterpoint (hpjAlpha d) Q
            (radonWalkOutput (d + 1) P.q P.L
              (fun j => Q (enum (modSampleTuple hS_pos K M_bits sb j))) wb))).card : ℝ) =
        (2 : ℝ) ^ B_walk := by exact_mod_cast hcompl
    linarith
  have hcard_tot :
      ((Finset.univ.filter BadPair).card : ℝ) ≤
        (S1.card : ℝ) * ((2 : ℝ) ^ B_walk) +
        (((2 : ℝ) ^ M_bits) ^ K) * ((φ_hpj / 2) * ((2 : ℝ) ^ B_walk)) := by
    have hnat :
        (Finset.univ.filter BadPair).card ≤
          (S1 ×ˢ (Finset.univ : Finset (Fin B_walk → Bool))).card +
          ∑ sb ∈ Finset.univ.filter (fun sb => ¬ BadInit (modSampleTuple hS_pos K M_bits sb)),
            (Finset.univ.filter (fun wb : Fin B_walk → Bool => BadPair (sb, wb))).card := by
      calc (Finset.univ.filter BadPair).card
          ≤ _ := (Finset.card_le_card hsub2).trans (Finset.card_union_le _ _)
        _ ≤ (S1 ×ˢ (Finset.univ : Finset (Fin B_walk → Bool))).card +
              ∑ sb ∈ Finset.univ.filter (fun sb => ¬ BadInit (modSampleTuple hS_pos K M_bits sb)),
                ((Finset.univ.filter (fun wb : Fin B_walk → Bool => BadPair (sb, wb))).map
                  ⟨fun wb => (sb, wb), fun _ _ h => (Prod.mk.inj h).2⟩).card :=
            Nat.add_le_add_left Finset.card_biUnion_le _
        _ = _ := by simp
    have hprod_card :
        ((S1 ×ˢ (Finset.univ : Finset (Fin B_walk → Bool))).card : ℝ) =
          (S1.card : ℝ) * ((2 : ℝ) ^ B_walk) := by
      simp [Finset.card_product]
    have hsum_le :
        ((∑ sb ∈ Finset.univ.filter (fun sb => ¬ BadInit (modSampleTuple hS_pos K M_bits sb)),
            (Finset.univ.filter (fun wb : Fin B_walk → Bool => BadPair (sb, wb))).card : ℕ) : ℝ) ≤
          (((2 : ℝ) ^ M_bits) ^ K) * ((φ_hpj / 2) * ((2 : ℝ) ^ B_walk)) := by
      push_cast
      calc ∑ sb ∈ Finset.univ.filter (fun sb => ¬ BadInit (modSampleTuple hS_pos K M_bits sb)),
              ((Finset.univ.filter (fun wb : Fin B_walk → Bool => BadPair (sb, wb))).card : ℝ)
          ≤ ∑ _sb ∈ Finset.univ.filter (fun sb => ¬ BadInit (modSampleTuple hS_pos K M_bits sb)),
              ((φ_hpj / 2) * ((2 : ℝ) ^ B_walk)) := by
            apply Finset.sum_le_sum
            intro sb hsb
            simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hsb
            exact hWalkEach sb hsb
        _ ≤ ∑ _sb : Fin K → Fin M_bits → Bool, ((φ_hpj / 2) * ((2 : ℝ) ^ B_walk)) := by
            apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
            intro _ _ _; positivity
        _ = (((2 : ℝ) ^ M_bits) ^ K) * ((φ_hpj / 2) * ((2 : ℝ) ^ B_walk)) := by
            simp [Fintype.card_fun, Fintype.card_fin, pow_mul]
    have hr := (Nat.cast_le (α := ℝ)).mpr hnat
    rw [Nat.cast_add, hprod_card] at hr
    exact hr.trans (add_le_add_right hsum_le _)
  have hpow_tot : (((2 : ℝ) ^ M_bits) ^ K) * ((2 : ℝ) ^ B_walk) = (2 : ℝ) ^ B_tot := by
    dsimp [B_tot]
    rw [← pow_mul, Nat.mul_comm M_bits K, ← pow_add]
  calc ((Finset.univ.filter BadPair).card : ℝ)
      ≤ (S1.card : ℝ) * ((2 : ℝ) ^ B_walk) +
          (((2 : ℝ) ^ M_bits) ^ K) * ((φ_hpj / 2) * ((2 : ℝ) ^ B_walk)) := hcard_tot
    _ ≤ ((φ_hpj / 2 + (K : ℝ) * (S.card : ℝ) / ((2 : ℝ) ^ M_bits)) * (((2 : ℝ) ^ M_bits) ^ K)) *
          ((2 : ℝ) ^ B_walk) +
          (((2 : ℝ) ^ M_bits) ^ K) * ((φ_hpj / 2) * ((2 : ℝ) ^ B_walk)) := by
        gcongr
    _ = (φ_hpj + ((K : ℝ) * (S.card : ℝ) / ((2 : ℝ) ^ M_bits))) *
          ((((2 : ℝ) ^ M_bits) ^ K) * ((2 : ℝ) ^ B_walk)) := by ring
    _ = (φ_hpj + ((K : ℝ) * (S.card : ℝ) / ((2 : ℝ) ^ M_bits))) * ((2 : ℝ) ^ B_tot) := by
        rw [hpow_tot]

end UL.Proof_lem_7_2_RacerP33
