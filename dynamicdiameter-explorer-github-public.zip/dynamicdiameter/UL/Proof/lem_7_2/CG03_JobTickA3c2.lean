import UL.Proof.lem_7_2.CG03_JobTickA3c2_tail

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 2b. Execution of `launchPendingJobAtRStmt` -/

theorem exec_launchPendingJobAtRStmt
    (h_lem_5_1 : S_lem_5_1)
    (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k) {m : ArithRAMMemory}
    (hpop : m.popDepth 0 = m)
    (hw15_reg : wRead m 26 15 = (i : ℤ))
    (hU : MidLoopUncut ctx gFlag i m)
    (haff : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = true)
    (hnone : ctx.st₀.ownedJob ⟨i, hi⟩ = none)
    (heq_st : ctx.snAge' ⟨i, hi⟩ =
      jobStartAge (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.st₀.birthSnap ⟨i, hi⟩).card)
    (hlarge_h : 4 * ctx.p.L < (ctx.S_post_h ⟨i, hi⟩).card) :
    RandExecBad inp
      (launchPendingJobAtRStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p)
      ctx.p.B_hpj m
      (fun m' =>
        wRead m' 0 0 = wRead m 0 0 ∧
        wRead m' 26 13 = wRead m 26 13 ∧
        wRead m' 26 14 = wRead m 26 14 ∧
        wRead m' 26 15 = (i : ℤ) ∧
        wRead m' 26 28 = wRead m 26 28 ∧
        MidLoopUncut ctx false (i + 1) m')
      (fun m' => gFlag = true → MidLoopUncut ctx true (i + 1) m')
      (2 * ctx.p.φ_ev)
      (freshAllocFiveCost ctx.p.D₀ ctx.p.NumSlots + hpjFreezeRunInitCost ctx.d ctx.n ctx.p +
        ctx.p.K_seg + 400) := by
  classical
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  have hi_D0 : i < ctx.p.D₀ := lt_trans hi ctx.origK_lt_D0
  have hi_box : i < ctx.M_box :=
    lt_of_lt_of_le (lt_of_lt_of_le hi_D0 (by have := ctx.hSlots_cap; nlinarith)) ctx.hBox_slots
  have hD : 3 ≤ ctx.d + 3 := by omega
  rcases ctx.hV with ⟨_, hWF_bc, hWF_age, hWF_aff, _, _,
    hRes_bc, hRes_age, hRes_aff, hRes_rem, hRes_cl,
    _, _, hd_bc_rem, hd_bc_cl, _, hd_age_rem, hd_age_cl, hd_aff_rem, hd_aff_cl, _,
    _, _, _, hRes_rO, hRes_rV⟩
  have hjob_box := ctx.jobIdx_box_bounds (j := 0) hi ctx.D0_pos
  have hU_orig := hU
  rcases hU.gc_hyps with ⟨hk_le, hw_cL, _, _, _, hsn_gc, hjob_gc⟩
  rcases hU with ⟨h27_m, _, hSeg_m, hSave_m, hLive_m, hw15_m, _, _,
    leafS, _, hleaf_lt, hw16_m, _, _, _, _, hTodo_m⟩
  rcases (hTodo_m r_fin le_rfl).2.1 with
    ⟨dS_i, oldSp, T_sp_i, hdS_i0, hdS_i_lt, holdSp0, holdSp_lt, hne_dS_oldSp,
      _, _, hw14_i, hw15_i, _, h6_oldSp, _, _, _, hSegOldSp, hidle_i⟩
  have hidle_true : (ctx.st₀.ownedJob r_fin).isNone = true := by rw [hnone]; rfl
  have hT_eq : T_sp_i = ctx.S_post_h r_fin := hidle_i hidle_true
  subst hT_eq
  have holdSp_in_sn : oldSp ∈ snSlotSet m i := by unfold snSlotSet; rw [hw15_i]; simp
  rcases exec_freshAllocFiveSlotsStmt inp m ctx.hSlots_cap ctx.hBox30 ctx.hBox_slots
      hk_le hw_cL hleaf_lt hw16_m hsn_gc hjob_gc hSeg_m hSave_m
    with ⟨m1, dS0, spDS0, rS0, spRS0, dummySp, hd1, hpop1,
      hdS0_pos, hdS0_lt, hdS0_notU,
      hspDS0_pos, hspDS0_lt, hspDS0_notU,
      hrS0_pos, hrS0_lt, hrS0_notU,
      hspRS0_pos, hspRS0_lt, hspRS0_notU,
      hdum_pos, hdum_lt, hdum_notU,
      hne_01, hne_02, hne_03, hne_12, hne_13, hne_23,
      hdum_ne0, hdum_ne1, hdum_ne2, hdum_ne3,
      hw20_1, hw21_1, hw22_1, hw23_1, hw19_1,
      _, _, _, _, h6_dum_1,
      hSeg_1, hSave_1,
      _, _, _, _, hEmp_dum,
      hSegPres_1, _, hw6_1, hw_oth_1, hw1_1, hw26_1, hr_1⟩
  have hdS0_np := not_in_activeSlotSet_props hw15_m hw16_m hdS0_notU
  have hspDS0_np := not_in_activeSlotSet_props hw15_m hw16_m hspDS0_notU
  have hrS0_np := not_in_activeSlotSet_props hw15_m hw16_m hrS0_notU
  have hspRS0_np := not_in_activeSlotSet_props hw15_m hw16_m hspRS0_notU
  have hdum_np := not_in_activeSlotSet_props hw15_m hw16_m hdum_notU
  have holdSp_ne : oldSp ≠ dS0 ∧ oldSp ≠ spDS0 ∧ oldSp ≠ rS0 ∧ oldSp ≠ spRS0 ∧ oldSp ≠ dummySp :=
    ⟨fun h => hdS0_np.2.2.1 i hi (h ▸ holdSp_in_sn),
     fun h => hspDS0_np.2.2.1 i hi (h ▸ holdSp_in_sn),
     fun h => hrS0_np.2.2.1 i hi (h ▸ holdSp_in_sn),
     fun h => hspRS0_np.2.2.1 i hi (h ▸ holdSp_in_sn),
     fun h => hdum_np.2.2.1 i hi (h ▸ holdSp_in_sn)⟩
  have hw26_15_1 : wRead m1 26 15 = (i : ℤ) :=
    (hw26_1 15 (by decide) (by decide) (by decide) (by decide) (by decide)).trans hw15_reg
  have hw15_i_1 : wRead m1 15 (i : ℤ) = (oldSp : ℤ) :=
    (hw_oth_1 15 (by decide) (by decide) (by decide) (by decide) (by decide) _).trans hw15_i
  let m2 := wWrite m1 26 1 (oldSp : ℤ)
  have hpop2 : m2.popDepth 0 = m2 := wWrite_popDepth_zero hpop1 26 1 _
  have hd2 : DetExecAt 0 inp (boxWriteW ctx.M_box 26 (.lit 1) (.readHeap 15 (.readHeap 26 (.lit 15)))) m1 m2 18 :=
    exec_boxWriteW inp m1 _ _ rfl (by omega) (by have h := ctx.hBox30; omega)
      (by simp [hw26_15_1, hw15_i_1]) (by simp [intExprOps])
  let m3 := wWrite m2 15 (i : ℤ) (dummySp : ℤ)
  have hpop3 : m3.popDepth 0 = m3 := wWrite_popDepth_zero hpop2 15 _ _
  have hd3 : DetExecAt 0 inp (boxWriteW ctx.M_box 15 (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 19))) m2 m3 18 :=
    exec_boxWriteW inp m2 _ _
      (by dsimp only [m2]; rw [iValAt_readHeap, iValAt_lit, wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw26_15_1])
      (by positivity) (by exact_mod_cast hi_box)
      (by dsimp only [m2]; rw [iValAt_readHeap, iValAt_lit, wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw19_1])
      (by simp [intExprOps])
  have hsub_post : ctx.S_post_h r_fin ⊆ ctx.P'.activeHandles :=
    cg01_chainInput_subset ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles r_fin.castSucc
  have hlt_post : ∀ h ∈ ctx.S_post_h r_fin, h < ctx.n := fun h hh => hLive_m.1 h (hsub_post hh)
  have hw3_1 : ∀ t, t ≠ 15 → t ≠ 26 → ∀ idx, wRead m3 t idx = wRead m1 t idx := by
    intro t h15 h26 idx; dsimp only [m3, m2]
    rw [wRead_wWrite_of_ne _ _ (Or.inl h15), wRead_wWrite_of_ne _ _ (Or.inl h26)]
  have hw3_26 : ∀ idx, idx ≠ 1 → wRead m3 26 idx = wRead m1 26 idx := by
    intro idx h1; dsimp only [m3, m2]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inr h1)]
  have hSeg_3 : SegGenBound ctx.p.K_seg ctx.p.NumSlots m3 :=
    ⟨by rw [hw3_1 1 (by decide) (by decide)]; exact hSeg_1.1,
     fun s hs => by rw [hw3_1 5 (by decide) (by decide), hw3_1 1 (by decide) (by decide)]; exact hSeg_1.2.1 s hs,
     fun s hs u hu => by rw [hw3_1 8 (by decide) (by decide), hw3_1 1 (by decide) (by decide)]; exact hSeg_1.2.2 s hs u hu⟩
  have hSave_3 : SaveGenBound ctx.n ctx.p.NumSlots m3 :=
    ⟨by rw [hw3_1 1 (by decide) (by decide)]; exact hSave_1.1,
     fun s hs => by rw [hw3_1 6 (by decide) (by decide), hw3_1 1 (by decide) (by decide)]; exact hSave_1.2.1 s hs,
     fun s hs h hh => by rw [hw3_1 11 (by decide) (by decide), hw3_1 1 (by decide) (by decide)]; exact hSave_1.2.2 s hs h hh⟩
  rcases exec_freezeSlot26_1Stmt inp m3 (activeH := ctx.P'.activeHandles) (livePts := ctx.P'.handleCoords)
      (S := ctx.S_post_h r_fin) holdSp_lt
      (by dsimp only [m3, m2]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self])
      (by have h := ctx.hBox30; omega) ctx.hBox_slots hSeg_3 hSave_3 hsub_post hlt_post
    with ⟨m4, hd4, hpop4, hSeg_4, hSave_4, h6_oldSp_4, hSlot_oldSp_4, _, hw6_4, hw_oth_4, hw1_4, hr_4⟩
  have hSegOldSp_1 : EncSegSlot ctx.p.K_seg m1 oldSp (ctx.S_post_h r_fin) (fun _ => 0) :=
    hSegPres_1 oldSp holdSp_lt holdSp_ne.1 holdSp_ne.2.1 holdSp_ne.2.2.1 holdSp_ne.2.2.2.1 holdSp_ne.2.2.2.2 _ _ hSegOldSp
  have hSegOldSp_4 : EncSegSlot ctx.p.K_seg m4 oldSp (ctx.S_post_h r_fin) (fun _ => 0) :=
    hSegOldSp_1.congr_mem_fSq
      (by rw [hw_oth_4 5 (by decide) (by decide), hw3_1 5 (by decide) (by decide)])
      (fun _ _ => by rw [hw_oth_4 8 (by decide) (by decide), hw3_1 8 (by decide) (by decide)])
      (fun _ _ => by rw [hw_oth_4 9 (by decide) (by decide), hw3_1 9 (by decide) (by decide)])
      (fun _ _ => by rw [hw_oth_4 10 (by decide) (by decide), hw3_1 10 (by decide) (by decide)])
      (fun _ _ => by rw [hr_4]; dsimp only [m3, m2]; rw [rRead_wWrite, rRead_wWrite]) (fun _ _ => rfl)
  have hw26_1_4 : wRead m4 26 1 = (oldSp : ℤ) := by
    rw [hw_oth_4 26 (by decide) (by decide)]; dsimp only [m3, m2]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]
  rcases exec_readSlotCardTo24Stmt inp m4 (.readHeap 26 (.lit 1)) (Nat.le_trans (by decide : 25 ≤ 30) ctx.hBox30)
      (by rw [hpop4]; simp [hw26_1_4]) hSegOldSp_4
    with ⟨m5, hd5, hpop5, hw24_5, hw_oth_5, hw26_5, hr_5⟩
  have hmap_eq : ctx.uMap'.mapSet (ctx.S_post_h r_fin) = ctx.S_post_u r_fin :=
    ctx.uMap'.mapSet_chainInput ctx.st₀.nodes r_fin.castSucc
  have hbij := ctx.uMap'.mapSet_bij hsub_post
  have hcard_u_eq_h : (ctx.S_post_u r_fin).card = (ctx.S_post_h r_fin).card := by
    rw [← hmap_eq, hbij.1]
  let α : ℝ := 1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)
  let H_job0 : ℕ := jobDeadlineTicks α (ctx.S_post_u r_fin).card
  have hH_job0_div : iValAt 0 inp m5
      (.div (.readHeap 26 (.lit 24)) (.lit (((16384 * ctx.p.D ^ 2 : ℕ) : ℤ)))) = (H_job0 : ℤ) := by
    simp only [iValAt_div, iValAt_readHeap, iValAt_lit, hw24_5, ctx.hD_eq, ← hcard_u_eq_h]
    rw [← Int.natCast_ediv, ← jobDeadlineTicks_eq_nat (ctx.d + 3) hD (ctx.S_post_u r_fin).card]
  let m6 := wWrite m5 26 25 (H_job0 : ℤ)
  have hpop6 : m6.popDepth 0 = m6 := wWrite_popDepth_zero hpop5 26 25 _
  have hd6 : DetExecAt 0 inp
      (boxWriteW ctx.M_box 26 (.lit 25) (.div (.readHeap 26 (.lit 24)) (.lit (((16384 * ctx.p.D ^ 2 : ℕ) : ℤ)))))
      m5 m6 22 :=
    exec_boxWriteW inp m5 _ _ rfl (by omega) (by have h := ctx.hBox30; omega) hH_job0_div (by simp [intExprOps])
  have hw26_15_6 : wRead m6 26 15 = (i : ℤ) := by
    dsimp only [m6]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw26_5 15 (by decide),
        hw_oth_4 26 (by decide) (by decide), hw3_26 15 (by decide), hw26_15_1]
  let m7 := wWrite m6 26 7 (((i * ctx.p.D₀ : ℕ) : ℤ))
  have hpop7 : m7.popDepth 0 = m7 := wWrite_popDepth_zero hpop6 26 7 _
  have hd7 : DetExecAt 0 inp
      (boxWriteW ctx.M_box 26 (.lit 7) (.mul (.readHeap 26 (.lit 15)) (.lit (ctx.p.D₀ : ℤ))))
      m6 m7 18 :=
    exec_boxWriteW inp m6 _ _ rfl (by omega) (by have h := ctx.hBox30; omega)
      (by simp only [iValAt_mul, iValAt_readHeap, iValAt_lit, hw26_15_6]; push_cast; rfl)
      (by simp [intExprOps])
  have hw7_not26 : ∀ t, t ≠ 26 → ∀ idx, wRead m7 t idx = wRead m4 t idx := by
    intro t ht idx; dsimp only [m7, m6]
    rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht), hw_oth_5 t ht]
  have hr7_1 : ∀ t idx, rRead m7 t idx = rRead m1 t idx := by
    intro t idx; dsimp only [m7, m6]
    rw [rRead_wWrite, rRead_wWrite, hr_5, hr_4]; dsimp only [m3, m2]; rw [rRead_wWrite, rRead_wWrite]
  have hr7_eq : ∀ t idx, rRead m7 t idx = rRead m t idx := fun t idx => (hr7_1 t idx).trans (hr_1 t idx)
  have hw7_26_prev : ∀ idx, idx ≠ 7 → idx ≠ 24 → idx ≠ 25 → wRead m7 26 idx = wRead m4 26 idx := by
    intro idx h7 h24 h25; dsimp only [m7, m6]
    rw [wRead_wWrite_of_ne _ _ (Or.inr h7), wRead_wWrite_of_ne _ _ (Or.inr h25), hw26_5 idx h24]
  have hw7_26_m1 : ∀ idx, idx ≠ 1 → idx ≠ 7 → idx ≠ 24 → idx ≠ 25 → wRead m7 26 idx = wRead m1 26 idx :=
    fun idx h1 h7 h24 h25 => (hw7_26_prev idx h7 h24 h25).trans ((hw_oth_4 26 (by decide) (by decide) idx).trans (hw3_26 idx h1))
  have hw7_oth_m : ∀ t, t ≠ 1 → t ≠ 5 → t ≠ 6 → t ≠ 7 → t ≠ 15 → t ≠ 26 → ∀ idx, wRead m7 t idx = wRead m t idx :=
    fun t h1 h5 h6 h7 h15 h26 idx =>
      (hw7_not26 t h26 idx).trans ((hw_oth_4 t h1 h6 idx).trans ((hw3_1 t h15 h26 idx).trans (hw_oth_1 t h1 h5 h6 h7 h26 idx)))
  have hw7_1_keep : ∀ idx, idx ≠ 3 → wRead m7 1 idx = wRead m 1 idx :=
    fun idx h3 => (hw7_not26 1 (by decide) idx).trans ((hw1_4 idx h3).trans ((hw3_1 1 (by decide) (by decide) idx).trans (hw1_1 idx h3)))
  have hw7_15_i : wRead m7 15 (i : ℤ) = (dummySp : ℤ) := by
    rw [hw7_not26 15 (by decide), hw_oth_4 15 (by decide) (by decide)]; dsimp only [m3]; rw [wRead_wWrite_self]
  have hw7_15_ne : ∀ r, r ≠ i → wRead m7 15 (r : ℤ) = wRead m 15 (r : ℤ) := by
    intro r hne; have hz : (r : ℤ) ≠ (i : ℤ) := fun h => hne (Nat.cast_inj.mp h)
    rw [hw7_not26 15 (by decide), hw_oth_4 15 (by decide) (by decide)]; dsimp only [m3, m2]
    rw [wRead_wWrite_of_ne _ _ (Or.inr hz), wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        hw_oth_1 15 (by decide) (by decide) (by decide) (by decide) (by decide)]
  have hw7_6_dum : wRead m7 6 (dummySp : ℤ) = 0 := by
    rw [hw7_not26 6 (by decide), hw6_4 _ (fun h => holdSp_ne.2.2.2.2 (Nat.cast_inj.mp h).symm),
        hw3_1 6 (by decide) (by decide), h6_dum_1]
  have hw7_6_oth : ∀ s, s ≠ oldSp → s ≠ dS0 → s ≠ spDS0 → s ≠ rS0 → s ≠ spRS0 → s ≠ dummySp →
      wRead m7 6 (s : ℤ) = wRead m 6 (s : ℤ) := by
    intro s n_old n0 n1 n2 n3 ndum
    rw [hw7_not26 6 (by decide), hw6_4 _ (fun h => n_old (Nat.cast_inj.mp h)), hw3_1 6 (by decide) (by decide), hw6_1 _ (fun h => n0 (Nat.cast_inj.mp h)) (fun h => n1 (Nat.cast_inj.mp h)) (fun h => n2 (Nat.cast_inj.mp h)) (fun h => n3 (Nat.cast_inj.mp h)) (fun h => ndum (Nat.cast_inj.mp h))]
  have h17_seg : ∀ t, t ≠ 1 → t ≠ 6 → t ≠ 15 → t ≠ 26 → ∀ idx, wRead m7 t idx = wRead m1 t idx :=
    fun t h1 h6 h15 h26 idx => (hw7_not26 t h26 idx).trans ((hw_oth_4 t h1 h6 idx).trans (hw3_1 t h15 h26 idx))
  have hb_pos : 0 < (ctx.S_post_h r_fin).card := Nat.lt_of_le_of_lt (Nat.zero_le _) hlarge_h
  have hb_le_n : (ctx.S_post_h r_fin).card ≤ ctx.n :=
    (Finset.card_le_card hsub_post).trans
      ((activeHandles_card_eq_activeIds_card ctx.hP').trans_le ctx.hP'.1)
  have hSeg_7 : SegGenBound ctx.p.K_seg ctx.p.NumSlots m7 :=
    ⟨by rw [hw7_not26 1 (by decide)]; exact hSeg_4.1,
     fun s hs => by rw [hw7_not26 5 (by decide), hw7_not26 1 (by decide)]; exact hSeg_4.2.1 s hs,
     fun s hs u hu => by rw [hw7_not26 8 (by decide), hw7_not26 1 (by decide)]; exact hSeg_4.2.2 s hs u hu⟩
  have hSave_7 : SaveGenBound ctx.n ctx.p.NumSlots m7 :=
    ⟨by rw [hw7_not26 1 (by decide)]; exact hSave_4.1,
     fun s hs => by rw [hw7_not26 6 (by decide), hw7_not26 1 (by decide)]; exact hSave_4.2.1 s hs,
     fun s hs h hh => by rw [hw7_not26 11 (by decide), hw7_not26 1 (by decide)]; exact hSave_4.2.2 s hs h hh⟩
  have hLive_7 : EncLiveCoords ctx.d ctx.n m7 ctx.P'.activeHandles ctx.P'.handleCoords :=
    ⟨hLive_m.1, fun h hh c => by rw [hr7_eq]; exact hLive_m.2 h hh c⟩
  have hSegOldSp_7 : EncSegSlot ctx.p.K_seg m7 oldSp (ctx.S_post_h r_fin) (fun _ => 0) :=
    hSegOldSp_4.congr_mem_fSq
      (hw7_not26 5 (by decide) _) (fun _ _ => hw7_not26 8 (by decide) _)
      (fun _ _ => hw7_not26 9 (by decide) _) (fun _ _ => hw7_not26 10 (by decide) _)
      (fun _ _ => by dsimp only [m7, m6]; rw [rRead_wWrite, rRead_wWrite, hr_5]) (fun _ _ => rfl)
  have hSlotOldSp_7 : EncSlotCoords ctx.d ctx.n m7 ctx.P'.activeHandles ctx.P'.handleCoords oldSp
      (ctx.S_post_h r_fin) ctx.P'.handleCoords :=
    hSlot_oldSp_4.congr_mem3 (hw7_not26 6 (by decide) _)
      (fun _ => hw7_not26 11 (by decide) _)
      (fun _ => by dsimp only [m7, m6]; rw [rRead_wWrite, rRead_wWrite, hr_5])
  have hw7_26_7 : wRead m7 26 7 = (((i * ctx.p.D₀ : ℕ) : ℤ)) := by dsimp only [m7]; rw [wRead_wWrite_self]
  have hw7_26_24 : wRead m7 26 24 = ((ctx.S_post_h r_fin).card : ℤ) := by
    dsimp only [m7, m6]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hw24_5
  have hw7_26_25 : wRead m7 26 25 = (H_job0 : ℤ) := by
    dsimp only [m7, m6]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
  have hw7_26_15 : wRead m7 26 15 = (i : ℤ) := by
    dsimp only [m7]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw26_15_6]
  have hHpj := exec_hpjFreezeRunInitStmt h_lem_5_1 ctx.p inp m7
      (idx := i * ctx.p.D₀) (bS := oldSp) (dS := dS0) (spDS := spDS0) (rS := rS0) (spRS := spRS0)
      (openRem := H_job0)
      (S_birth := ctx.S_post_h r_fin) (S_parent := ctx.S_post_h r_fin) (S_uid := ctx.S_post_u r_fin)
      (activeH := ctx.P'.activeHandles) (livePts := ctx.P'.handleCoords) (snapPts := ctx.P'.handleCoords)
      (ghostCoords := ctx.uMap'.ghostCoords) (uidOfH := ctx.uMap'.uidOfH) (hOfUid := ctx.uMap'.hOfUid)
      hpop7 ctx.hD_eq ctx.hkφ ctx.hφ0 ctx.hφ1 ctx.hp_eq ctx.hp_props ctx.hbias_hpj ctx.hB_hpj
      holdSp_lt hdS0_lt hspDS0_lt hrS0_lt hspRS0_lt
      ⟨holdSp_ne.1, holdSp_ne.2.1, holdSp_ne.2.2.1, holdSp_ne.2.2.2.1,
       hne_01, hne_02, hne_03, hne_12, hne_13, hne_23⟩
      hb_pos hb_le_n ctx.hBox30 ctx.hBox_slots ctx.hBox_samp ctx.hBox_d
      (by simpa using hjob_box.1) (by simpa using hjob_box.2)
      hw7_26_7
      (by rw [hw7_26_prev 1 (by decide) (by decide) (by decide)]; exact hw26_1_4)
      (by rw [hw7_26_m1 20 (by decide) (by decide) (by decide) (by decide)]; exact hw20_1)
      (by rw [hw7_26_m1 21 (by decide) (by decide) (by decide) (by decide)]; exact hw21_1)
      (by rw [hw7_26_m1 22 (by decide) (by decide) (by decide) (by decide)]; exact hw22_1)
      (by rw [hw7_26_m1 23 (by decide) (by decide) (by decide) (by decide)]; exact hw23_1)
      hw7_26_24 hw7_26_25
      (by rw [hw7_not26 6 (by decide)]; exact h6_oldSp_4)
      hSeg_7 hSave_7 hLive_7 hSegOldSp_7 hSlotOldSp_7
      (fun h hh => hmap_eq ▸ hbij.2.2.1 h hh)
      (fun u hu => hbij.2.2.2 u (hmap_eq.symm ▸ hu))
  let tailStmt : ArithRAMStmt := seqList [
    boxWriteW ctx.M_box 16 (.readHeap 26 (.lit 15)) (.lit 1),
    ctx.cfg.jobRem.writeW ctx.M_box (.readHeap 26 (.lit 15)) (.readHeap 26 (.lit 25)),
    ctx.cfg.jobClosed.writeW ctx.M_box (.readHeap 26 (.lit 15)) (.lit 0),
    boxWriteW ctx.M_box 19 (.readHeap 26 (.lit 15)) (.lit 1),
    .localScope .skip
  ]
  have hFrom7 : RandExecBad inp (.seq (hpjFreezeRunInitStmt ctx.d ctx.n ctx.M_box ctx.p) tailStmt)
      ctx.p.B_hpj m7
      (fun m' =>
        wRead m' 0 0 = wRead m 0 0 ∧
        wRead m' 26 13 = wRead m 26 13 ∧
        wRead m' 26 14 = wRead m 26 14 ∧
        wRead m' 26 15 = (i : ℤ) ∧
        wRead m' 26 28 = wRead m 26 28 ∧
        MidLoopUncut ctx false (i + 1) m')
      (fun m' => gFlag = true → MidLoopUncut ctx true (i + 1) m')
      (2 * ctx.p.φ_ev)
      (hpjFreezeRunInitCost ctx.d ctx.n ctx.p + 150) := by
    refine RandExecBad.seq_det_right hpop7 hHpj ?_
    intro m8 hpop8 hSafe8
    rcases hSafe8 with ⟨hSeg_8, hSave_8, hEncLv_8, ⟨o_cand, s_cand, _, hball_8⟩,
      _, hw23_2_8, hw23_3_8, hw23_4_8, hw23_5_8, hw23_6_8, hw23_7_8,
      _, _, hw24_0_8, hw24_1_8,
      _, _, _, _,
      hSegPres_8, _, hw_oth_8, hw26_8, hw6Fr_8, hw23Fr_8, hw24Fr_8,
      hr_oth_8, hr23Fr_8, hr24Fr_8⟩
    have hw15_8 : wRead m8 26 15 = (i : ℤ) := (hw26_8 15 (by decide)).trans hw7_26_15
    have hw25_8 : wRead m8 26 25 = (H_job0 : ℤ) := (hw26_8 25 (by decide)).trans hw7_26_25
    rcases launchTail_exec ctx inp i H_job0 hi_D0 hi_box m8 hpop8 hw15_8 hw25_8 with
      ⟨m', hd_tail, hpop', hw'_res, hr'_eq,
       hw'_16_i, hw'_16_ne, hw'_19_i, hw'_19_ne,
       hw'_rem_i, hw'_rem_ne, hw'_cl_i, hw'_cl_ne, hw'_hdr_disj⟩
    have hw8_not_chg : ∀ t, t ≠ 1 → t ≠ 5 → t ≠ 6 → t ≠ 7 → t ≠ 15 → t ≠ 23 → t ≠ 24 → t ≠ 26 →
        ∀ idx, wRead m8 t idx = wRead m t idx :=
      fun t h1 h5 h6 h7 h15 h23 h24 h26 idx => (hw_oth_8 t h6 h23 h24 h26 idx).trans (hw7_oth_m t h1 h5 h6 h7 h15 h26 idx)
    have hr'_not23_24_27 : ∀ t, t ≠ 23 → t ≠ 24 → t ≠ 27 → ∀ idx, rRead m' t idx = rRead m t idx :=
      fun t h23 h24 h27 idx => (hr'_eq t idx).trans ((hr_oth_8 t h23 h24 h27 idx).trans (hr7_eq t idx))
    have hSeg_1_to_m' : ∀ s < ctx.p.NumSlots, ∀ S₁ fSq₁,
        EncSegSlot ctx.p.K_seg m1 s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁ := by
      intro s hs S₁ fSq₁ hE1
      have hE7 : EncSegSlot ctx.p.K_seg m7 s S₁ fSq₁ :=
        hE1.congr_mem_fSq
          (h17_seg 5 (by decide) (by decide) (by decide) (by decide) _)
          (fun _ _ => h17_seg 8 (by decide) (by decide) (by decide) (by decide) _)
          (fun _ _ => h17_seg 9 (by decide) (by decide) (by decide) (by decide) _)
          (fun _ _ => h17_seg 10 (by decide) (by decide) (by decide) (by decide) _)
          (fun _ _ => hr7_1 8 _) (fun _ _ => rfl)
      exact (hSegPres_8 s hs S₁ fSq₁ hE7).congr_mem_fSq
        (hw'_res 5 (by decide) (by decide) (by decide) _)
        (fun _ _ => hw'_res 8 (by decide) (by decide) (by decide) _)
        (fun _ _ => hw'_res 9 (by decide) (by decide) (by decide) _)
        (fun _ _ => hw'_res 10 (by decide) (by decide) (by decide) _)
        (fun _ _ => hr'_eq 8 _) (fun _ _ => rfl)
    have hSegPres_m_m' : ∀ s < ctx.p.NumSlots,
        s ≠ dS0 → s ≠ spDS0 → s ≠ rS0 → s ≠ spRS0 → s ≠ dummySp →
        ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁ :=
      fun s hs n0 n1 n2 n3 ndum S₁ fSq₁ hE =>
        hSeg_1_to_m' s hs S₁ fSq₁ (hSegPres_1 s hs n0 n1 n2 n3 ndum S₁ fSq₁ hE)
    have hEmp_dum' : EncSegSlot ctx.p.K_seg m' dummySp ∅ (fun _ => 0) :=
      hSeg_1_to_m' dummySp hdum_lt _ _ (hEmp_dum (fun _ => 0))
    have hEncLv0' : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m'
        ctx.P'.activeHandles ctx.P'.handleCoords (i * ctx.p.D₀)
        (ctx.S_post_h r_fin) ctx.P'.handleCoords (provAtIdx ctx.d m8 (i * ctx.p.D₀))
        (ctx.S_post_h r_fin) true := by
      have h8 : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m8
          ctx.P'.activeHandles ctx.P'.handleCoords (i * ctx.p.D₀)
          (ctx.S_post_h r_fin) ctx.P'.handleCoords (provAtIdx ctx.d m8 (i * ctx.p.D₀))
          (ctx.S_post_h r_fin) true := ctx.hD_eq ▸ hEncLv_8
      exact h8.frame_slotSet (fun _ _ => rfl) (fun _ _ => rfl)
        (fun _ _ _ _ _ _ hE => hE.congr_mem_fSq
          (hw'_res 5 (by decide) (by decide) (by decide) _)
          (fun _ _ => hw'_res 8 (by decide) (by decide) (by decide) _)
          (fun _ _ => hw'_res 9 (by decide) (by decide) (by decide) _)
          (fun _ _ => hw'_res 10 (by decide) (by decide) (by decide) _)
          (fun _ _ => hr'_eq 8 _) (fun _ _ => rfl))
        (fun _ _ => hw'_res 6 (by decide) (by decide) (by decide) _)
        (fun _ => hw'_res 11 (by decide) (by decide) (by decide) _)
        (fun _ => hr'_eq 11 _)
        (fun _ _ => hw'_res 23 (by decide) (by decide) (by decide) _)
        (fun _ _ => hw'_res 24 (by decide) (by decide) (by decide) _)
        (fun _ => hr'_eq 23 _) (fun _ _ => hr'_eq 24 _)
    have hApplyLaunch : ∀ (b : Bool),
        (b = true → gFlag = true ∧
          IsCenterpoint (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2))
            (paraboloidLiftSet (fun u : ↥(ctx.S_post_u r_fin) => ctx.uMap'.ghostCoords u.1))
            (liftedPoint
              (applyBirthCoreFallback (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) ctx.P'.handleCoords
                (ctx.S_post_h r_fin) (provAtIdx ctx.d m8 (i * ctx.p.D₀))).o
              ((applyBirthCoreFallback (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) ctx.P'.handleCoords
                (ctx.S_post_h r_fin) (provAtIdx ctx.d m8 (i * ctx.p.D₀))).V +
               ‖(applyBirthCoreFallback (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) ctx.P'.handleCoords
                (ctx.S_post_h r_fin) (provAtIdx ctx.d m8 (i * ctx.p.D₀))).o‖ ^ 2))) →
        MidLoopUncut ctx b (i + 1) m' := by
      intro b hb_g
      exact midLoopUncut_after_launch hi hU_orig haff hnone heq_st hlarge_h
        hw14_i hw15_i hdS_i0 hdS_i_lt holdSp0 hne_dS_oldSp h6_oldSp
        hdS0_pos hdS0_notU hspDS0_pos hspDS0_notU hrS0_pos hrS0_notU hspRS0_pos hspRS0_notU
        hdum_pos hdum_lt hdum_notU ⟨hdum_ne0, hdum_ne1, hdum_ne2, hdum_ne3⟩
        ((hw'_res 26 (by decide) (by decide) (by decide) 27).trans
          ((hw26_8 27 (by decide)).trans
            ((hw7_26_m1 27 (by decide) (by decide) (by decide) (by decide)).trans
              ((hw26_1 27 (by decide) (by decide) (by decide) (by decide) (by decide)).trans h27_m))))
        ⟨by rw [hw'_res 1 (by decide) (by decide) (by decide)]; exact hSeg_8.1,
         fun s hs => by rw [hw'_res 5 (by decide) (by decide) (by decide), hw'_res 1 (by decide) (by decide) (by decide)]; exact hSeg_8.2.1 s hs,
         fun s hs u hu => by rw [hw'_res 8 (by decide) (by decide) (by decide), hw'_res 1 (by decide) (by decide) (by decide)]; exact hSeg_8.2.2 s hs u hu⟩
        ⟨by rw [hw'_res 1 (by decide) (by decide) (by decide)]; exact hSave_8.1,
         fun s hs => by rw [hw'_res 6 (by decide) (by decide) (by decide), hw'_res 1 (by decide) (by decide) (by decide)]; exact hSave_8.2.1 s hs,
         fun s hs h hh => by rw [hw'_res 11 (by decide) (by decide) (by decide), hw'_res 1 (by decide) (by decide) (by decide)]; exact hSave_8.2.2 s hs h hh⟩
        ⟨hLive_m.1, fun h hh c => by rw [hr'_not23_24_27 4 (by decide) (by decide) (by decide)]; exact hLive_m.2 h hh c⟩
        ((hw'_res 1 (by decide) (by decide) (by decide) 5).trans
          ((hw_oth_8 1 (by decide) (by decide) (by decide) (by decide) 5).trans (hw7_1_keep 5 (by decide))))
        ((hw'_res 1 (by decide) (by decide) (by decide) 6).trans
          ((hw_oth_8 1 (by decide) (by decide) (by decide) (by decide) 6).trans (hw7_1_keep 6 (by decide))))
        (fun idx => (hw'_res 11 (by decide) (by decide) (by decide) idx).trans
          (hw8_not_chg 11 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) idx))
        (hr'_not23_24_27 11 (by decide) (by decide) (by decide))
        (fun idx => (hw'_res 14 (by decide) (by decide) (by decide) idx).trans
          (hw8_not_chg 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) idx))
        ((hw'_res 15 (by decide) (by decide) (by decide) _).trans
          ((hw_oth_8 15 (by decide) (by decide) (by decide) (by decide) _).trans hw7_15_i))
        (fun r hne => (hw'_res 15 (by decide) (by decide) (by decide) _).trans
          ((hw_oth_8 15 (by decide) (by decide) (by decide) (by decide) _).trans (hw7_15_ne r hne)))
        hw'_16_i
        (fun r hne => (hw'_16_ne r hne).trans
          (hw8_not_chg 16 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _))
        hw'_19_i
        (fun r hne => (hw'_19_ne r hne).trans
          (hw8_not_chg 19 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _))
        hw'_rem_i
        (fun r hne => (hw'_rem_ne r hne).trans
          (hw8_not_chg _
            (tag_ne_of_not_reserved (u := 1) hRes_rem (by decide))
            (tag_ne_of_not_reserved (u := 5) hRes_rem (by decide))
            (tag_ne_of_not_reserved (u := 6) hRes_rem (by decide))
            (tag_ne_of_not_reserved (u := 7) hRes_rem (by decide))
            (tag_ne_of_not_reserved (u := 15) hRes_rem (by decide))
            (tag_ne_of_not_reserved (u := 23) hRes_rem (by decide))
            (tag_ne_of_not_reserved (u := 24) hRes_rem (by decide))
            (tag_ne_of_not_reserved (u := 26) hRes_rem (by decide)) _))
        hw'_cl_i
        (fun r hne => (hw'_cl_ne r hne).trans
          (hw8_not_chg _
            (tag_ne_of_not_reserved (u := 1) hRes_cl (by decide))
            (tag_ne_of_not_reserved (u := 5) hRes_cl (by decide))
            (tag_ne_of_not_reserved (u := 6) hRes_cl (by decide))
            (tag_ne_of_not_reserved (u := 7) hRes_cl (by decide))
            (tag_ne_of_not_reserved (u := 15) hRes_cl (by decide))
            (tag_ne_of_not_reserved (u := 23) hRes_cl (by decide))
            (tag_ne_of_not_reserved (u := 24) hRes_cl (by decide))
            (tag_ne_of_not_reserved (u := 26) hRes_cl (by decide)) _))
        (fun r => (hw'_hdr_disj ctx.cfg.snBirthCard hWF_bc hRes_bc hd_bc_rem hd_bc_cl r).trans
          (hw8_not_chg _
            (tag_ne_of_not_reserved (u := 1) hRes_bc (by decide))
            (tag_ne_of_not_reserved (u := 5) hRes_bc (by decide))
            (tag_ne_of_not_reserved (u := 6) hRes_bc (by decide))
            (tag_ne_of_not_reserved (u := 7) hRes_bc (by decide))
            (tag_ne_of_not_reserved (u := 15) hRes_bc (by decide))
            (tag_ne_of_not_reserved (u := 23) hRes_bc (by decide))
            (tag_ne_of_not_reserved (u := 24) hRes_bc (by decide))
            (tag_ne_of_not_reserved (u := 26) hRes_bc (by decide)) _))
        (fun r => (hw'_hdr_disj ctx.cfg.snAge hWF_age hRes_age hd_age_rem hd_age_cl r).trans
          (hw8_not_chg _
            (tag_ne_of_not_reserved (u := 1) hRes_age (by decide))
            (tag_ne_of_not_reserved (u := 5) hRes_age (by decide))
            (tag_ne_of_not_reserved (u := 6) hRes_age (by decide))
            (tag_ne_of_not_reserved (u := 7) hRes_age (by decide))
            (tag_ne_of_not_reserved (u := 15) hRes_age (by decide))
            (tag_ne_of_not_reserved (u := 23) hRes_age (by decide))
            (tag_ne_of_not_reserved (u := 24) hRes_age (by decide))
            (tag_ne_of_not_reserved (u := 26) hRes_age (by decide)) _))
        (fun r => (hw'_hdr_disj ctx.cfg.snAffected hWF_aff hRes_aff hd_aff_rem hd_aff_cl r).trans
          (hw8_not_chg _
            (tag_ne_of_not_reserved (u := 1) hRes_aff (by decide))
            (tag_ne_of_not_reserved (u := 5) hRes_aff (by decide))
            (tag_ne_of_not_reserved (u := 6) hRes_aff (by decide))
            (tag_ne_of_not_reserved (u := 7) hRes_aff (by decide))
            (tag_ne_of_not_reserved (u := 15) hRes_aff (by decide))
            (tag_ne_of_not_reserved (u := 23) hRes_aff (by decide))
            (tag_ne_of_not_reserved (u := 24) hRes_aff (by decide))
            (tag_ne_of_not_reserved (u := 26) hRes_aff (by decide)) _))
        (hr'_not23_24_27 _
          (rtag_ne_of_not_reserved (u := 23) hRes_rO (by decide))
          (rtag_ne_of_not_reserved (u := 24) hRes_rO (by decide))
          (rtag_ne_of_not_reserved (u := 27) hRes_rO (by decide)))
        (hr'_not23_24_27 _
          (rtag_ne_of_not_reserved (u := 23) hRes_rV (by decide))
          (rtag_ne_of_not_reserved (u := 24) hRes_rV (by decide))
          (rtag_ne_of_not_reserved (u := 27) hRes_rV (by decide)))
        ((hw'_res 6 (by decide) (by decide) (by decide) _).trans
          ((hw6Fr_8 _ (fun h => hdum_ne0 (Nat.cast_inj.mp h)) (fun h => hdum_ne1 (Nat.cast_inj.mp h)) (fun h => hdum_ne2 (Nat.cast_inj.mp h)) (fun h => hdum_ne3 (Nat.cast_inj.mp h))).trans hw7_6_dum))
        (fun s n_old n0 n1 n2 n3 ndum =>
          (hw'_res 6 (by decide) (by decide) (by decide) _).trans
            ((hw6Fr_8 _ (fun h => n0 (Nat.cast_inj.mp h)) (fun h => n1 (Nat.cast_inj.mp h)) (fun h => n2 (Nat.cast_inj.mp h)) (fun h => n3 (Nat.cast_inj.mp h))).trans (hw7_6_oth s n_old n0 n1 n2 n3 ndum)))
        hEmp_dum' hSegPres_m_m' hEncLv0'
        (fun _ => by simpa [ctx.hD_eq] using hball_8)
        ⟨(hw'_res 23 (by decide) (by decide) (by decide) _).trans hw23_2_8,
         (hw'_res 23 (by decide) (by decide) (by decide) _).trans hw23_3_8,
         (hw'_res 23 (by decide) (by decide) (by decide) _).trans hw23_4_8,
         (hw'_res 23 (by decide) (by decide) (by decide) _).trans hw23_5_8,
         (hw'_res 23 (by decide) (by decide) (by decide) _).trans hw23_6_8,
         (hw'_res 23 (by decide) (by decide) (by decide) _).trans hw23_7_8⟩
        ⟨(hw'_res 24 (by decide) (by decide) (by decide) _).trans hw24_0_8,
         (hw'_res 24 (by decide) (by decide) (by decide) _).trans hw24_1_8⟩
        (fun r hne j hj a ha => by
          have hidx_ne : r * ctx.p.D₀ + j ≠ i * ctx.p.D₀ := by simpa using jobIdx_ne hj ctx.D0_pos (Or.inl hne)
          exact (hw'_res 23 (by decide) (by decide) (by decide) _).trans
            ((hw23Fr_8 _ (jobIdx_disj_w23 hidx_ne ha)).trans
              (hw7_oth_m 23 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)))
        (fun r hne j hj a ha => by
          have hidx_ne : r * ctx.p.D₀ + j ≠ i * ctx.p.D₀ := by simpa using jobIdx_ne hj ctx.D0_pos (Or.inl hne)
          exact (hw'_res 24 (by decide) (by decide) (by decide) _).trans
            ((hw24Fr_8 _ (jobIdx_disj_w24 hidx_ne ha)).trans
              (hw7_oth_m 24 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)))
        (fun r hne j hj c => by
          have hidx_ne : r * ctx.p.D₀ + j ≠ i * ctx.p.D₀ := by simpa using jobIdx_ne hj ctx.D0_pos (Or.inl hne)
          exact (hr'_eq _ _).trans ((hr23Fr_8 _ (jobIdx_disj_r23 hidx_ne c.isLt)).trans (hr7_eq _ _)))
        (fun r hne j hj a ha => by
          have hidx_ne : r * ctx.p.D₀ + j ≠ i * ctx.p.D₀ := by simpa using jobIdx_ne hj ctx.D0_pos (Or.inl hne)
          exact (hr'_eq _ _).trans ((hr24Fr_8 _ (jobIdx_disj_w24 hidx_ne ha)).trans (hr7_eq _ _)))
        hb_g
    refine ⟨m', hd_tail, hpop',
      ⟨(hw'_res 0 (by decide) (by decide) (by decide) 0).trans
         (hw8_not_chg 0 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) 0),
       (hw'_res 26 (by decide) (by decide) (by decide) 13).trans
         ((hw26_8 13 (by decide)).trans
           ((hw7_26_m1 13 (by decide) (by decide) (by decide) (by decide)).trans
             (hw26_1 13 (by decide) (by decide) (by decide) (by decide) (by decide)))),
       (hw'_res 26 (by decide) (by decide) (by decide) 14).trans
         ((hw26_8 14 (by decide)).trans
           ((hw7_26_m1 14 (by decide) (by decide) (by decide) (by decide)).trans
             (hw26_1 14 (by decide) (by decide) (by decide) (by decide) (by decide)))),
       (hw'_res 26 (by decide) (by decide) (by decide) 15).trans hw15_8,
       (hw'_res 26 (by decide) (by decide) (by decide) 28).trans
         ((hw26_8 28 (by decide)).trans
           ((hw7_26_m1 28 (by decide) (by decide) (by decide) (by decide)).trans
             (hw26_1 28 (by decide) (by decide) (by decide) (by decide) (by decide)))),
       hApplyLaunch false (fun h => by cases h)⟩,
      fun hcp8 hgF => hApplyLaunch true (fun _ => ⟨hgF, by simpa [ctx.hD_eq] using hcp8⟩)⟩
  have hFrom6 := RandExecBad.seq_det_left hpop6 hpop7 hd7 hFrom7
  have hFrom5 := RandExecBad.seq_det_left hpop5 hpop6 hd6 hFrom6
  have hFrom4 := RandExecBad.seq_det_left hpop4 hpop5 hd5 hFrom5
  have hFrom3 := RandExecBad.seq_det_left hpop3 hpop4 hd4 hFrom4
  have hFrom2 := RandExecBad.seq_det_left hpop2 hpop3 hd3 hFrom3
  have hFrom1 := RandExecBad.seq_det_left hpop1 hpop2 hd2 hFrom2
  exact (RandExecBad.seq_det_left hpop hpop1 hd1 hFrom1).mono
    (fun _ h => h) (fun _ _ h => h) le_rfl (by simp [intExprOps]; omega)

end UL.Proof_lem_7_2_RacerP46
