import UL.Proof.lem_7_2.CG01_MidGlueA2a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Execution Proof for One Synchronous Leaf-Splitting Round (`exec_syncSplitOneRoundStmt`) -/

private lemma syncSplitTraj_congr {d n H L B_scan : ℕ} {P : DynamicPointSet d}
    (st₀ : PureServingState d n H L B_scan P)
    {c₁ c₂ : ℕ → EuclideanSpace ℝ (Fin d) × ℝ} :
    ∀ (r : ℕ), (∀ j < r, c₁ j = c₂ j) → syncSplitTraj st₀ c₁ r = syncSplitTraj st₀ c₂ r
  | 0, _ => rfl
  | r + 1, h => by
      have ih := syncSplitTraj_congr st₀ r (fun j hj => h j (Nat.lt_succ_of_lt hj))
      have hr := h r (Nat.lt_succ_self r)
      simp only [syncSplitTraj, ih, hr]

theorem exec_syncSplitOneRoundStmt
    (h_lem_5_1 : S_lem_5_1)
    {cHpj cBase d n t M_box : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (hM : p46BoxSize d n p ≤ M_box)
    (inp : ArithRAMInput d)
    {P' : DynamicPointSet d} (hP' : P'.WellFormed n)
    (st : PureServingState d n p.H p.L p.B_scan P')
    (hinv : st.NodesInv)
    (hleaf_cap : (chainTerminal P'.handleCoords st.nodes P'.activeHandles).card ≤ 4 * p.L + 2)
    {mem : ArithRAMMemory} (hpop : mem.popDepth 0 = mem)
    (hChain : EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots mem P' st.k st.nodes st.snAge
      (fun r => (st.ownedJob r).isNone))
    (hJobs : CG01_EncJobs p P' st mem) :
    RandExecBad inp (syncSplitOneRoundStmt d n M_box p) p.B_hpj mem
      (fun m' =>
        wRead m' 0 0 = wRead mem 0 0 ∧
        ∃ cand : EuclideanSpace ℝ (Fin d) × ℝ,
          let st' := st.syncSplitOne cand.1 cand.2
          st'.NodesInv ∧
          (chainTerminal P'.handleCoords st'.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
          EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m' P' st'.k st'.nodes st'.snAge
            (fun r => (st'.ownedJob r).isNone) ∧
          CG01_EncJobs p P' st' m')
      (fun m' =>
        st.AllCentersGood →
          ∃ cand : EuclideanSpace ℝ (Fin d) × ℝ,
            let st' := st.syncSplitOne cand.1 cand.2
            st'.NodesInv ∧
            (chainTerminal P'.handleCoords st'.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
            EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m' P' st'.k st'.nodes st'.snAge
              (fun r => (st'.ownedJob r).isNone) ∧
            CG01_EncJobs p P' st' m' ∧
            st'.AllCentersGood)
      (2 * p.φ_ev) (syncSplitOneRoundCost d n p) := by
  classical
  let S_leaf := chainTerminal P'.handleCoords st.nodes P'.activeHandles
  rcases p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM
    with ⟨_, _, _, _, h30, hD0_M, _, hd1, _, _, hS_M, _, _, _, hS2K, hhpj, hidx⟩
  have hLenBounds := st.chainLen_and_jobLen_lt hP' hp.hH5 hp.hn2 hinv
  have hk_lt_D0 : st.k < p.D₀ := by rw [hp.hD0]; exact hLenBounds.1
  have hk_le_D0 : st.k ≤ p.D₀ := le_of_lt hk_lt_D0
  have hk1_le_D0 : st.k + 1 ≤ p.D₀ := hk_lt_D0
  have hk_box : st.k < M_box := by omega
  have hk_snO : st.k * d + d ≤ M_box := by
    have hk_le_sq : st.k ≤ p.D₀ * p.D₀ :=
      le_trans hk_le_D0 (Nat.le_mul_of_pos_right _ (by omega : 1 ≤ p.D₀))
    exact (hidx st.k hk_le_sq).2
  rcases hChain.2 with ⟨_, _, hPool0, _, _, _, _, _,
    leafS, _, hleaf_lt, hw16_0, _, hSegLeaf_0, _, _, _⟩
  rcases exec_midReadLeafCardTo19Stmt inp mem (by omega : 25 ≤ M_box) hw16_0 hSegLeaf_0
    with ⟨m1, e_read19, hpop1, hw19_1, hw_not26_1, _, hr_1⟩
  have hw00_1 : wRead m1 0 0 = wRead mem 0 0 := hw_not26_1 0 (by decide) 0
  have hChain1 : EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m1 P' st.k st.nodes st.snAge
      (fun r => (st.ownedJob r).isNone) :=
    EncServingChainRelaxed.congr_not_0_26 hChain (fun t _ h26 i => hw_not26_1 t h26 i) (fun t _ _ i => hr_1 t i)
  have hJobs1 : CG01_EncJobs p P' st m1 :=
    cg01_encJobs_congr_not_0_26 (fun t _ h26 i => hw_not26_1 t h26 i) (fun t _ _ i => hr_1 t i) hJobs
  let condE : ArithCondExpr := .intLt (.lit (((2 * p.L + 1 : ℕ) : ℤ))) (.readHeap 26 (.lit 19))
  have hcond_ops : condExprOps condE ≤ 10 := by simp [condE, condExprOps, intExprOps]
  by_cases hgt : 2 * p.L + 1 < S_leaf.card
  · -- True branch
    have hc_true : cValAt 0 inp m1 condE = true := by
      simp only [condE, cValAt, evalArithCond, evalIntExpr]
      change decide ((((2 * p.L + 1 : ℕ) : ℤ)) < wRead m1 26 19) = true
      rw [hw19_1, decide_eq_true_eq]
      exact_mod_cast hgt
    have hS_pos : 0 < S_leaf.card := by omega
    have hS_sub : S_leaf ⊆ P'.activeHandles :=
      cg01_chainTerminal_subset P'.handleCoords st.nodes P'.activeHandles
    have hS_lt_n : ∀ h ∈ S_leaf, h < n := fun h hh => hPool0.1.1 h (hS_sub hh)
    have hS_le_n : S_leaf.card ≤ n := by
      calc S_leaf.card ≤ (Finset.range n).card :=
          Finset.card_le_card (fun h hh => Finset.mem_range.mpr (hS_lt_n h hh))
        _ = n := Finset.card_range n
    rcases hChain1.2 with ⟨_, _, hPool1, hSegGen1, hSaveGen1, hw15_1, _, _,
      leafS1, _, _, hw16_1, hw6leaf_1, hSegLeaf_1, hsn1, _, _⟩
    have hleaf1_eq : leafS1 = leafS := by
      have : (leafS1 : ℤ) = (leafS : ℤ) := by rw [← hw16_1, hw_not26_1 1 (by decide) 6, hw16_0]
      exact_mod_cast this
    rw [hleaf1_eq] at hw16_1 hw6leaf_1 hSegLeaf_1
    have hsn_lt1 : ∀ r < st.k,
        ∃ (dS spS : ℕ), dS < p.NumSlots ∧ spS < p.NumSlots ∧
          wRead m1 14 (r : ℤ) = (dS : ℤ) ∧ wRead m1 15 (r : ℤ) = (spS : ℤ) := by
      intro r hr
      rcases hsn1 ⟨r, hr⟩ with ⟨dS, spS, _, hd, _, hsp, _, _, e14, e15, _⟩
      exact ⟨dS, spS, hd, hsp, e14, e15⟩
    have hjob_lt1 : ∀ r < st.k, wRead m1 16 (r : ℤ) = 1 →
        ∃ (jLen : ℕ), jLen ≤ p.D₀ ∧ wRead m1 19 (r : ℤ) = (jLen : ℤ) ∧
          ∀ j < jLen,
            ∃ (s2 s3 s4 s5 s6 : ℕ),
              s2 < p.NumSlots ∧ s3 < p.NumSlots ∧ s4 < p.NumSlots ∧
              s5 < p.NumSlots ∧ s6 < p.NumSlots ∧
              wRead m1 23 (((8 * (r * p.D₀ + j) + 2 : ℕ) : ℤ)) = (s2 : ℤ) ∧
              wRead m1 23 (((8 * (r * p.D₀ + j) + 3 : ℕ) : ℤ)) = (s3 : ℤ) ∧
              wRead m1 23 (((8 * (r * p.D₀ + j) + 4 : ℕ) : ℤ)) = (s4 : ℤ) ∧
              wRead m1 23 (((8 * (r * p.D₀ + j) + 5 : ℕ) : ℤ)) = (s5 : ℤ) ∧
              wRead m1 23 (((8 * (r * p.D₀ + j) + 6 : ℕ) : ℤ)) = (s6 : ℤ) := by
      intro r hr h16
      have hoj := hJobs1.2.2.1 ⟨r, hr⟩
      cases hoj_c : st.ownedJob ⟨r, hr⟩ with
      | none => rw [hoj_c] at hoj; change wRead m1 16 (r : ℤ) = 0 at hoj; omega
      | some g =>
          rw [hoj_c] at hoj
          rcases hoj with ⟨_, _, _, hw19, lvs_h, hlen_eq, hlv_all⟩
          have hj_le : g.lvs.length ≤ p.D₀ := by
            rw [hp.hD0]; exact le_of_lt (hLenBounds.2 ⟨r, hr⟩ g hoj_c)
          refine ⟨g.lvs.length, hj_le, hw19, fun j hj => ?_⟩
          rcases (hlv_all j (hlen_eq ▸ hj)).2.2.2.1 with ⟨bS, dS, spDS, rS, spRS,
            hb, hd, hsd, hr_s, hsr, _, _, _, _, _, _, _, _, _, _, e2, e3, e4, e5, e6, _⟩
          exact ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, e2, e3, e4, e5, e6⟩
    rcases exec_freshAllocFourSlotsStmt (n := n) (K := p.K_seg) inp m1
        (le_of_eq hp.hSlots.symm) h30 hS_M hk_le_D0 hw15_1 hleaf_lt hw16_1
        hsn_lt1 hjob_lt1 hSegGen1 hSaveGen1
      with ⟨m2, dS, spDS, rS, spRS, e_alloc, _,
        hdS0, hdS_lt, hdS_notU,
        hsp0, hsp_lt, hsp_notU,
        hrS0, hrS_lt, hrS_notU,
        _, _, hspR_notU,
        hd_sp, hd_r, _, hsp_r, _, _,
        hw20_2, hw21_2, hw22_2, _,
        hw6_dS2, hw6_sp2, hw6_rS2, _,
        _, hSegGen2, hSaveGen2,
        hSeg_dS2, hSeg_sp2, hSeg_rS2, _,
        hSegPres2, hSlotPres2, hw6Pres2, hwNot2, hw1Pres2, hw26Pres2, hr2⟩
    have hU_dS := not_in_activeSlotSet_props hw15_1 hw16_1 hdS_notU
    have hU_sp := not_in_activeSlotSet_props hw15_1 hw16_1 hsp_notU
    have hU_rS := not_in_activeSlotSet_props hw15_1 hw16_1 hrS_notU
    have hU_sr := not_in_activeSlotSet_props hw15_1 hw16_1 hspR_notU
    let m3 := wWrite m2 26 0 1
    have e_w26_0 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 0) (.lit 1)) m2 m3 20 :=
      exec_boxWriteW inp m2 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
    have hw16_3 : wRead m3 1 6 = (leafS : ℤ) := by
      simp [m3, hw1Pres2 6 (by decide), hw16_1]
    let m4 := wWrite m3 26 1 (leafS : ℤ)
    have e_w26_1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 1) (.readHeap 1 (.lit 6))) m3 m4 20 :=
      exec_boxWriteW inp m3 _ _ rfl (by omega) (by omega) (by simp [hw16_3]) (by simp [intExprOps])
    have hw15_4 : wRead m4 1 5 = (st.k : ℤ) := by simp [m4, m3, hw1Pres2 5 (by decide), hw15_1]
    have hw19_4 : wRead m4 26 19 = (S_leaf.card : ℤ) := by
      simp only [m4, m3, wRead_wWrite_of_ne _ _ (Or.inr (by decide : (19 : ℤ) ≠ 1)),
        wRead_wWrite_of_ne _ _ (Or.inr (by decide : (19 : ℤ) ≠ 0)),
        hw26Pres2 19 (by decide) (by decide) (by decide) (by decide)]
      exact hw19_1
    have hw20_4 : wRead m4 26 20 = (dS : ℤ) := by simp [m4, m3, hw20_2]
    have hw21_4 : wRead m4 26 21 = (spDS : ℤ) := by simp [m4, m3, hw21_2]
    have hw22_4 : wRead m4 26 22 = (rS : ℤ) := by simp [m4, m3, hw22_2]
    rcases exec_midWriteSplitWordHdrsStmt inp m4 h30 hk_box hw15_4 hw19_4 hw20_4 hw21_4 hw22_4
      with ⟨m5, e_hdrs, hpop5, hw15_5, hw16_5, hw12k_5, hw13k_5, hw14k_5, hw15k_5, hw16k_5,
        hwHdrPre_5, hw26Pres_5, hwNot_5, hw1Pres_5, hr_5⟩
    have e_pre : DetExecAt 0 inp (syncSplitPreHPJStmt M_box p.D₀ p.NumSlots) m1 m5
        (freshAllocFourCost p.D₀ p.NumSlots + 240) := by
      unfold syncSplitPreHPJStmt seqList
      exact (e_alloc.seq (e_w26_0.seq (e_w26_1.seq e_hdrs))).mono_cost (by omega)
    have hw26_0_5 : wRead m5 26 0 = 1 := by rw [hw26Pres_5 0 (by decide)]; simp [m4, m3]
    have hw26_1_5 : wRead m5 26 1 = (leafS : ℤ) := by rw [hw26Pres_5 1 (by decide)]; simp [m4]
    have hw26_20_5 : wRead m5 26 20 = (dS : ℤ) := by rw [hw26Pres_5 20 (by decide)]; exact hw20_4
    have hw26_21_5 : wRead m5 26 21 = (spDS : ℤ) := by rw [hw26Pres_5 21 (by decide)]; exact hw21_4
    have hw26_22_5 : wRead m5 26 22 = (rS : ℤ) := by rw [hw26Pres_5 22 (by decide)]; exact hw22_4
    have hw_m5_m2 : ∀ t, t ≠ 1 → t ≠ 12 → t ≠ 13 → t ≠ 14 → t ≠ 15 → t ≠ 16 → t ≠ 26 →
        ∀ i, wRead m5 t i = wRead m2 t i := by
      intro t h1 h12 h13 h14 h15 h16 h26 i
      rw [hwNot_5 t h1 h12 h13 h14 h15 h16 h26 i]; simp [m4, m3, h26]
    have hr_m5_m1 : ∀ t i, rRead m5 t i = rRead m1 t i := by
      intro t i; rw [hr_5]; simp [m4, m3, hr2]
    have hSegGen5 : SegGenBound p.K_seg p.NumSlots m5 :=
      ⟨by rw [hw1Pres_5 3 (by decide) (by decide)]; simp [m4, m3]; exact hSegGen2.1,
       fun s hs => by
         rw [hw_m5_m2 5 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
             hw1Pres_5 3 (by decide) (by decide)]
         simp [m4, m3]; exact hSegGen2.2.1 s hs,
       fun s hs u hu => by
         rw [hw_m5_m2 8 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
             hw1Pres_5 3 (by decide) (by decide)]
         simp [m4, m3]; exact hSegGen2.2.2 s hs u hu⟩
    have hLive5 : EncLiveCoords d n m5 P'.activeHandles P'.handleCoords :=
      ⟨hPool1.1.1, fun h hh c => by rw [hr_m5_m1]; exact hPool1.1.2 h hh c⟩
    have hSeg_m2_to_m5 : ∀ {s : ℕ} {S₁ : Finset ℕ} {fSq₁ : ℕ → ℝ},
        EncSegSlot p.K_seg m2 s S₁ fSq₁ → EncSegSlot p.K_seg m5 s S₁ fSq₁ := fun hE =>
      hE.congr_mem_fSq
        (hw_m5_m2 5 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
        (fun _ _ => hw_m5_m2 8 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
        (fun _ _ => hw_m5_m2 9 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
        (fun _ _ => hw_m5_m2 10 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) _)
        (fun _ _ => by rw [hr_m5_m1, ← hr2])
        (fun _ _ => rfl)
    have hSegLeaf_5 : EncSegSlot p.K_seg m5 leafS S_leaf (fun _ => 0) :=
      hSeg_m2_to_m5 (hSegPres2 leafS hleaf_lt hU_dS.2.1.symm hU_sp.2.1.symm hU_rS.2.1.symm hU_sr.2.1.symm
        S_leaf _ hSegLeaf_1)
    have hw6_leaf5 : wRead m5 6 (leafS : ℤ) = 0 := by
      rw [hw_m5_m2 6 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
          hw6Pres2 (leafS : ℤ) (by exact_mod_cast hU_dS.2.1.symm) (by exact_mod_cast hU_sp.2.1.symm)
            (by exact_mod_cast hU_rS.2.1.symm) (by exact_mod_cast hU_sr.2.1.symm)]
      exact hw6leaf_1
    have hSlotLeaf_5 : EncSlotCoords d n m5 P'.activeHandles P'.handleCoords leafS S_leaf P'.handleCoords :=
      ⟨hS_lt_n, Or.inl ⟨hw6_leaf5, hS_sub, fun _ _ => rfl⟩⟩
    rcases exec_runHPJOnSlotStmt_active (M_box := M_box) p inp m5
        hw26_0_5 hw26_1_5 hS_pos hS_le_n
        hp.hD_eq hp.hφ_eq hp.hφ0 hp.hφ1 hp.hPhp_eq hp.hPhp_props hp.hbias_hpj hp.hBhpj
        hhpj hd1 hSegLeaf_5 hLive5 hSlotLeaf_5
      with ⟨Post_hpj, Bad_hpj, _, hR_hpj, hBad_card, hPost_hpj⟩
    let Safe6 : ArithRAMMemory → Prop := fun m6 =>
      m6.popDepth 0 = m6 ∧
      (∀ t idx, wRead m6 t idx = wRead m5 t idx) ∧
      (∀ t, t ≠ 27 → ∀ idx, rRead m6 t idx = rRead m5 t idx)
    let Good6 : ArithRAMMemory → Prop := fun m6 =>
      let o_out : EuclideanSpace ℝ (Fin d) := WithLp.toLp 2 (fun c : Fin d => rRead m6 27 (c.val : ℤ))
      let s_out : ℝ := rRead m6 27 (d : ℤ)
      IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
        (paraboloidLiftSet (fun x : ↥S_leaf => P'.handleCoords x.1)) (liftedPoint o_out s_out)
    have hHPJ_bad : RandExecBad inp (runHPJOnSlotStmt d n M_box p) p.B_hpj m5
        Safe6 Good6 (2 * p.φ_ev) (hpjCallCost d n p) := by
      refine ⟨by have := hp.hφ0; linarith, Post_hpj, Bad_hpj, inferInstance, hR_hpj, hBad_card, ?_⟩
      intro bits m6 hp6
      rcases hPost_hpj bits m6 hp6 with ⟨hp_m6, hw_m6, hr_m6, hg_m6⟩
      refine ⟨hp_m6, ⟨hp_m6, hw_m6, hr_m6⟩, fun hnb => ?_⟩
      have hcp := hg_m6 hnb; rwa [hp.hD_eq] at hcp
    have hPostDet : ∀ m6, m6.popDepth 0 = m6 → Safe6 m6 →
        ∃ m9,
          DetExecAt 0 inp (syncSplitPostHPJStmt d n M_box p) m6 m9
            (syncSplitPostHPJCost d p) ∧
          m9.popDepth 0 = m9 ∧
          (wRead m9 0 0 = wRead mem 0 0 ∧
            ∃ cand : EuclideanSpace ℝ (Fin d) × ℝ,
              let st' := st.syncSplitOne cand.1 cand.2
              st'.NodesInv ∧
              (chainTerminal P'.handleCoords st'.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
              EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m9 P' st'.k st'.nodes st'.snAge
                (fun r => (st'.ownedJob r).isNone) ∧
              CG01_EncJobs p P' st' m9) ∧
          (Good6 m6 →
            st.AllCentersGood →
              ∃ cand : EuclideanSpace ℝ (Fin d) × ℝ,
                let st' := st.syncSplitOne cand.1 cand.2
                st'.NodesInv ∧
                (chainTerminal P'.handleCoords st'.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
                EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m9 P' st'.k st'.nodes st'.snAge
                  (fun r => (st'.ownedJob r).isNone) ∧
                CG01_EncJobs p P' st' m9 ∧
                st'.AllCentersGood) := by
      intro m6 _ ⟨_, hw_6_5, hr_6_5⟩
      let o_cand : EuclideanSpace ℝ (Fin d) := WithLp.toLp 2 (fun c : Fin d => rRead m6 27 (c.val : ℤ))
      let s_cand : ℝ := rRead m6 27 (d : ℤ)
      let bId_h : ℕ := S_leaf.orderEmbOfFin rfl ⟨0, hS_pos⟩
      let prov : ChainNode d :=
        provisionalCenter P'.handleCoords bId_h (.candidate o_cand (liftVariance o_cand s_cand))
      let B_new : ChainNode d :=
        selectOpenedLevelBall (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) P'.handleCoords S_leaf bId_h
          (.candidate o_cand (liftVariance o_cand s_cand))
      have hB_eq_fall : applyBirthCoreFallback (1 / (4 * (p.D : ℝ) ^ 2)) P'.handleCoords S_leaf prov = B_new := by
        rw [hp.hD_eq]; rfl
      have hSegLeaf_6 : EncSegSlot p.K_seg m6 leafS S_leaf (fun _ => 0) :=
        hSegLeaf_5.congr_mem_fSq (hw_6_5 5 _) (fun _ _ => hw_6_5 8 _) (fun _ _ => hw_6_5 9 _)
          (fun _ _ => hw_6_5 10 _) (fun _ _ => hr_6_5 8 (by decide) _) (fun _ _ => rfl)
      have hLive6 : EncLiveCoords d n m6 P'.activeHandles P'.handleCoords :=
        ⟨hLive5.1, fun h hh c => by rw [hr_6_5 4 (by decide)]; exact hLive5.2 h hh c⟩
      have hSlotLeaf_6 : EncSlotCoords d n m6 P'.activeHandles P'.handleCoords leafS S_leaf P'.handleCoords :=
        encSlotCoords_congr_6_11 hSlotLeaf_5 (hw_6_5 6 _) (hw_6_5 11) (hr_6_5 11 (by decide))
      rcases exec_provisionalFromHPJStmt (M_box := M_box) inp m6
          (by rw [hw_6_5]; exact hw26_1_5) hS_pos hd1 hSegLeaf_6 hLive6 hSlotLeaf_6
        with ⟨m7, e_prov, _, hw_7_6, hr_7_6, hr27o_7, hr27V_7⟩
      have hw_7_5 : ∀ t i, wRead m7 t i = wRead m5 t i := fun t i => (hw_7_6 t i).trans (hw_6_5 t i)
      have hr_7_5 : ∀ t, t ≠ 27 → ∀ i, rRead m7 t i = rRead m5 t i :=
        fun t ht i => (hr_7_6 t ht i).trans (hr_6_5 t ht i)
      have hSeg_m2_to_m7 : ∀ {s : ℕ} {S₁ : Finset ℕ} {fSq₁ : ℕ → ℝ},
          EncSegSlot p.K_seg m2 s S₁ fSq₁ → EncSegSlot p.K_seg m7 s S₁ fSq₁ := fun hE =>
        (hSeg_m2_to_m5 hE).congr_mem_fSq (hw_7_5 5 _) (fun _ _ => hw_7_5 8 _)
          (fun _ _ => hw_7_5 9 _) (fun _ _ => hw_7_5 10 _) (fun _ _ => hr_7_5 8 (by decide) _) (fun _ _ => rfl)
      have hSegGen7 : SegGenBound p.K_seg p.NumSlots m7 :=
        ⟨by rw [hw_7_5]; exact hSegGen5.1,
         fun s hs => by rw [hw_7_5, hw_7_5]; exact hSegGen5.2.1 s hs,
         fun s hs u hu => by rw [hw_7_5, hw_7_5]; exact hSegGen5.2.2 s hs u hu⟩
      have hLive7 : EncLiveCoords d n m7 P'.activeHandles P'.handleCoords :=
        ⟨hLive5.1, fun h hh c => by rw [hr_7_5 4 (by decide)]; exact hLive5.2 h hh c⟩
      rcases exec_syncCoreAndPartitionStmt (n := n) (NumSlots := p.NumSlots)
          (M_sync := 4 * p.L + 2) (M_box := M_box) inp m7
          hp.hD3 hleaf_lt hdS_lt hsp_lt hrS_lt
          ⟨hU_dS.2.1.symm, hU_sp.2.1.symm, hU_rS.2.1.symm, hd_sp, hd_r, hsp_r⟩
          (by rw [hw_7_5]; exact hw26_1_5)
          (by rw [hw_7_5]; exact hw26_20_5)
          (by rw [hw_7_5]; exact hw26_21_5)
          (by rw [hw_7_5]; exact hw26_22_5)
          hS_pos hleaf_cap hS_sub (by omega : 26 ≤ M_box) hd1 hS2K
          hSegGen7
          (hSegLeaf_5.congr_mem_fSq (hw_7_5 5 _) (fun _ _ => hw_7_5 8 _)
            (fun _ _ => hw_7_5 9 _) (fun _ _ => hw_7_5 10 _) (fun _ _ => hr_7_5 8 (by decide) _) (fun _ _ => rfl))
          (hSeg_m2_to_m7 (hSeg_dS2 _))
          (hSeg_m2_to_m7 (hSeg_sp2 _))
          (hSeg_m2_to_m7 (hSeg_rS2 _))
          hLive7 hr27o_7 hr27V_7
        with ⟨m8, e_sync, _, hSegGen8, hSeg_dS8, hSeg_sp8, hSeg_rS8, hSegPres8,
          hw_8_7, hr_8_7, hr27o_8, hr27V_8⟩
      rw [hB_eq_fall] at hSeg_dS8 hSeg_rS8 hr27o_8 hr27V_8
      have hw15_8 : wRead m8 1 5 = (((st.k + 1 : ℕ) : ℤ)) := by
        rw [hw_8_7 1 (by decide) (by decide) (by decide) (by decide), hw_7_5]; exact hw15_5
      rcases exec_midStoreSplitRealCenterStmt inp m8 h30 hk_box hk_snO hw15_8 hr27o_8 hr27V_8
        with ⟨m9, e_store, hpop9, hr12k_9, hr13k_9, hrHdrPre_9, hw_9_8, hr_9_8⟩
      have e_post : DetExecAt 0 inp (syncSplitPostHPJStmt d n M_box p) m6 m9
          (syncSplitPostHPJCost d p) := by
        unfold syncSplitPostHPJStmt syncSplitPostHPJCost seqList
        exact (e_prov.seq (e_sync.seq e_store)).mono_cost (by linarith)
      have hw_9_5 : ∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ i, wRead m9 t i = wRead m5 t i := by
        intro t h8 h9 h10 h26 i; rw [hw_9_8 t h26, hw_8_7 t h8 h9 h10 h26, hw_7_5]
      have hw_9_2_notHdr : ∀ t, t ≠ 1 → t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 12 → t ≠ 13 →
          t ≠ 14 → t ≠ 15 → t ≠ 16 → t ≠ 26 → ∀ i, wRead m9 t i = wRead m2 t i := by
        intro t h1 h8 h9 h10 h12 h13 h14 h15 h16 h26 i
        rw [hw_9_5 t h8 h9 h10 h26, hw_m5_m2 t h1 h12 h13 h14 h15 h16 h26]
      have hw_9_1_static : ∀ t, t ≠ 1 → t ≠ 5 → t ≠ 6 → t ≠ 7 → t ≠ 8 → t ≠ 9 → t ≠ 10 →
          t ≠ 12 → t ≠ 13 → t ≠ 14 → t ≠ 15 → t ≠ 16 → t ≠ 26 →
          ∀ i, wRead m9 t i = wRead m1 t i := by
        intro t h1 h5 h6 h7 h8 h9 h10 h12 h13 h14 h15 h16 h26 i
        rw [hw_9_2_notHdr t h1 h8 h9 h10 h12 h13 h14 h15 h16 h26, hwNot2 t h1 h5 h6 h7 h26]
      have hr_9_1_static : ∀ t, t ≠ 8 → t ≠ 12 → t ≠ 13 → t ≠ 26 → t ≠ 27 →
          ∀ i, rRead m9 t i = rRead m1 t i := by
        intro t h8 h12 h13 h26 h27 i
        rw [hr_9_8 t h12 h13, hr_8_7 t h8 h26 h27, hr_7_5 t h27, hr_m5_m1]
      have hw00_9 : wRead m9 0 0 = wRead mem 0 0 := by
        rw [hw_9_1_static 0 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
            (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hw00_1]
      have hSeg_m8_to_m9 : ∀ {s : ℕ} {S₁ : Finset ℕ} {fSq₁ : ℕ → ℝ},
          EncSegSlot p.K_seg m8 s S₁ fSq₁ → EncSegSlot p.K_seg m9 s S₁ fSq₁ := fun hE =>
        hE.congr_mem_fSq
          (hw_9_8 5 (by decide) _) (fun _ _ => hw_9_8 8 (by decide) _)
          (fun _ _ => hw_9_8 9 (by decide) _) (fun _ _ => hw_9_8 10 (by decide) _)
          (fun _ _ => hr_9_8 8 (by decide) (by decide) _) (fun _ _ => rfl)
      have hLive9 : EncLiveCoords d n m9 P'.activeHandles P'.handleCoords :=
        ⟨hPool1.1.1, fun h hh c => by
          rw [hr_9_1_static 4 (by decide) (by decide) (by decide) (by decide) (by decide)]
          exact hPool1.1.2 h hh c⟩
      have hPool9 : EncHandlePool d n m9 P' := by
        rcases hPool1.2 with ⟨hwm, freeSet, hhwm, e10, e11, e12, hdisj, hunion, hf1, hf2, hw2_f⟩
        have hw1_low : ∀ idx : ℤ, idx ≠ 3 → idx ≠ 5 → idx ≠ 6 → wRead m9 1 idx = wRead m1 1 idx := by
          intro idx h3 h5 h6
          rw [hw_9_5 1 (by decide) (by decide) (by decide) (by decide), hw1Pres_5 idx h5 h6]
          simp [m4, m3, hw1Pres2 idx h3]
        have hw3_eq := hw_9_1_static 3 (by decide) (by decide) (by decide) (by decide) (by decide)
          (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
        have hw2_eq := hw_9_1_static 2 (by decide) (by decide) (by decide) (by decide) (by decide)
          (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
        exact ⟨hLive9, hwm, freeSet, hhwm,
          by rw [hw1_low 0 (by decide) (by decide) (by decide)]; exact e10,
          by rw [hw1_low 1 (by decide) (by decide) (by decide)]; exact e11,
          by rw [hw1_low 2 (by decide) (by decide) (by decide)]; exact e12,
          hdisj, hunion,
          fun i hi => by rw [hw3_eq]; exact hf1 i hi,
          fun i hi j hj hne => by rw [hw3_eq, hw3_eq]; exact hf2 i hi j hj hne,
          fun h hh => by rw [hw2_eq]; exact hw2_f h hh⟩
      have hSegGen9 : SegGenBound p.K_seg p.NumSlots m9 :=
        ⟨by rw [hw_9_8 1 (by decide)]; exact hSegGen8.1,
         fun s hs => by rw [hw_9_8 5 (by decide), hw_9_8 1 (by decide)]; exact hSegGen8.2.1 s hs,
         fun s hs u hu => by rw [hw_9_8 8 (by decide), hw_9_8 1 (by decide)]; exact hSegGen8.2.2 s hs u hu⟩
      have hSaveGen9 : SaveGenBound n p.NumSlots m9 :=
        ⟨by rw [hw_9_5 1 (by decide) (by decide) (by decide) (by decide),
                hw1Pres_5 3 (by decide) (by decide)]; simp [m4, m3]; exact hSaveGen2.1,
         fun s hs => by
           rw [hw_9_2_notHdr 6 (by decide) (by decide) (by decide) (by decide) (by decide)
               (by decide) (by decide) (by decide) (by decide) (by decide),
               hw_9_5 1 (by decide) (by decide) (by decide) (by decide),
               hw1Pres_5 3 (by decide) (by decide)]; simp [m4, m3]; exact hSaveGen2.2.1 s hs,
         fun s hs h hh => by
           rw [hw_9_2_notHdr 11 (by decide) (by decide) (by decide) (by decide) (by decide)
               (by decide) (by decide) (by decide) (by decide) (by decide),
               hw_9_5 1 (by decide) (by decide) (by decide) (by decide),
               hw1Pres_5 3 (by decide) (by decide)]; simp [m4, m3]; exact hSaveGen2.2.2 s hs h hh⟩
      have hwHdrPre_9 : ∀ r < st.k,
          wRead m9 12 (r : ℤ) = wRead m1 12 (r : ℤ) ∧
          wRead m9 13 (r : ℤ) = wRead m1 13 (r : ℤ) ∧
          wRead m9 14 (r : ℤ) = wRead m1 14 (r : ℤ) ∧
          wRead m9 15 (r : ℤ) = wRead m1 15 (r : ℤ) ∧
          wRead m9 16 (r : ℤ) = wRead m1 16 (r : ℤ) := by
        intro r hr
        rcases hwHdrPre_5 r hr with ⟨e12, e13, e14, e15, e16⟩
        refine ⟨?_, ?_, ?_, ?_, ?_⟩
        · rw [hw_9_5 12 (by decide) (by decide) (by decide) (by decide), e12]; simp [m4, m3, hwNot2 12 (by decide) (by decide) (by decide) (by decide) (by decide)]
        · rw [hw_9_5 13 (by decide) (by decide) (by decide) (by decide), e13]; simp [m4, m3, hwNot2 13 (by decide) (by decide) (by decide) (by decide) (by decide)]
        · rw [hw_9_5 14 (by decide) (by decide) (by decide) (by decide), e14]; simp [m4, m3, hwNot2 14 (by decide) (by decide) (by decide) (by decide) (by decide)]
        · rw [hw_9_5 15 (by decide) (by decide) (by decide) (by decide), e15]; simp [m4, m3, hwNot2 15 (by decide) (by decide) (by decide) (by decide) (by decide)]
        · rw [hw_9_5 16 (by decide) (by decide) (by decide) (by decide), e16]; simp [m4, m3, hwNot2 16 (by decide) (by decide) (by decide) (by decide) (by decide)]
      have hCoupled := syncSplit_append_coupled st hgt rfl hk1_le_D0 hChain1 hJobs1 hw15_1 hw16_1
        hdS0 hdS_lt hdS_notU hsp0 hsp_lt hsp_notU hrS0 hrS_lt hrS_notU hspR_notU hd_sp hd_r hsp_r
        hPool9 hSegGen9 hSaveGen9
        (by rw [hw_9_8 1 (by decide)]; exact hw15_8)
        (by rw [hw_9_5 1 (by decide) (by decide) (by decide) (by decide)]; exact hw16_5)
        (by rw [hw_9_5 12 (by decide) (by decide) (by decide) (by decide)]; exact hw12k_5)
        (by rw [hw_9_5 13 (by decide) (by decide) (by decide) (by decide)]; exact hw13k_5)
        (by rw [hw_9_5 14 (by decide) (by decide) (by decide) (by decide)]; exact hw14k_5)
        (by rw [hw_9_5 15 (by decide) (by decide) (by decide) (by decide)]; exact hw15k_5)
        (by rw [hw_9_5 16 (by decide) (by decide) (by decide) (by decide)]; exact hw16k_5)
        (by rw [hw_9_2_notHdr 6 (by decide) (by decide) (by decide) (by decide) (by decide)
                (by decide) (by decide) (by decide) (by decide) (by decide)]; exact hw6_dS2)
        (by rw [hw_9_2_notHdr 6 (by decide) (by decide) (by decide) (by decide) (by decide)
                (by decide) (by decide) (by decide) (by decide) (by decide)]; exact hw6_sp2)
        (by rw [hw_9_2_notHdr 6 (by decide) (by decide) (by decide) (by decide) (by decide)
                (by decide) (by decide) (by decide) (by decide) (by decide)]; exact hw6_rS2)
        hwHdrPre_9
        (fun t ht i => by
          fin_cases ht <;>
            exact hw_9_1_static _ (by decide) (by decide) (by decide) (by decide) (by decide)
              (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) i)
        (fun t ht i => by
          fin_cases ht <;>
            exact hr_9_1_static _ (by decide) (by decide) (by decide) (by decide) (by decide) i)
        (fun r hr => ⟨by rw [(hrHdrPre_9 r hr).1, hr_8_7 13 (by decide) (by decide) (by decide),
                              hr_7_5 13 (by decide), hr_m5_m1],
                      fun c => by rw [(hrHdrPre_9 r hr).2 c, hr_8_7 12 (by decide) (by decide) (by decide),
                                      hr_7_5 12 (by decide), hr_m5_m1]⟩)
        (fun s hs h1 h2 h3 h4 _ _ hE =>
          hSeg_m8_to_m9 (hSegPres8 s hs h1 h2 h3 _ _ (hSeg_m2_to_m7 (hSegPres2 s hs h1 h2 h3 h4 _ _ hE))))
        (fun s h1 h2 h3 h4 => by
          rw [hw_9_2_notHdr 6 (by decide) (by decide) (by decide) (by decide) (by decide)
              (by decide) (by decide) (by decide) (by decide) (by decide),
              hw6Pres2 (s : ℤ) (by exact_mod_cast h1) (by exact_mod_cast h2)
                (by exact_mod_cast h3) (by exact_mod_cast h4)])
        (fun s hs h1 h2 h3 h4 _ _ hC =>
          encSlotCoords_congr_6_11 (hSlotPres2 P'.activeHandles P'.handleCoords s hs h1 h2 h3 h4 _ _ hC)
            (hw_9_2_notHdr 6 (by decide) (by decide) (by decide) (by decide) (by decide)
              (by decide) (by decide) (by decide) (by decide) (by decide) _)
            (hw_9_2_notHdr 11 (by decide) (by decide) (by decide) (by decide) (by decide)
              (by decide) (by decide) (by decide) (by decide) (by decide))
            (fun i => by rw [hr_9_1_static 11 (by decide) (by decide) (by decide) (by decide) (by decide), ← hr2]))
        hr12k_9 hr13k_9
        (hSeg_m8_to_m9 hSeg_dS8) (hSeg_m8_to_m9 hSeg_sp8) (hSeg_m8_to_m9 hSeg_rS8)
      have hsp_pure := st.syncSplitOne_spec h_lem_5_1 hp.hL_floor hinv o_cand s_cand
      have hst'_leaf : (chainTerminal P'.handleCoords (st.syncSplitOne o_cand s_cand).nodes P'.activeHandles).card ≤
          4 * p.L + 2 := by
        rcases hsp_pure.2.2.2.1 hgt with ⟨_, _, hadd_c⟩; omega
      exact ⟨m9, e_post, hpop9,
        ⟨hw00_9, (o_cand, s_cand), hsp_pure.2.1, hst'_leaf, hCoupled.1, hCoupled.2⟩,
        fun hGood6 hGood_st =>
          ⟨(o_cand, s_cand), hsp_pure.2.1, hst'_leaf, hCoupled.1, hCoupled.2,
           hsp_pure.2.2.2.2 hGood_st (fun _ => hGood6)⟩⟩
    have hTrueBody := RandExecBad.seq_det_left hpop1 hpop5 e_pre
      (RandExecBad.seq_det_right hpop5 hHPJ_bad hPostDet)
    have hIte := RandExecBad.ite_true (fB := randDummyBitsStmt p.B_hpj) hc_true hcond_ops hTrueBody
    exact (RandExecBad.seq_det_left hpop hpop1 e_read19 hIte).mono
      (fun _ hs => hs) (fun _ _ hg => hg) le_rfl (by unfold syncSplitOneRoundCost; linarith)
  · -- False branch
    have hc_false : cValAt 0 inp m1 condE = false := by
      simp only [condE, cValAt, evalArithCond, evalIntExpr]
      change decide ((((2 * p.L + 1 : ℕ) : ℤ)) < wRead m1 26 19) = false
      rw [hw19_1, decide_eq_false_iff_not]
      intro hlt_z; exact hgt (by exact_mod_cast hlt_z)
    have hDummy := exec_randDummyBitsStmt inp m1 p.B_hpj
    have hst_eq : st.syncSplitOne 0 0 = st := dif_neg hgt
    have hFalseBody : RandExecBad inp (randDummyBitsStmt p.B_hpj) p.B_hpj m1
        (fun m' =>
          wRead m' 0 0 = wRead mem 0 0 ∧
          ∃ cand : EuclideanSpace ℝ (Fin d) × ℝ,
            let st' := st.syncSplitOne cand.1 cand.2
            st'.NodesInv ∧
            (chainTerminal P'.handleCoords st'.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
            EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m' P' st'.k st'.nodes st'.snAge
              (fun r => (st'.ownedJob r).isNone) ∧
            CG01_EncJobs p P' st' m')
        (fun m' =>
          st.AllCentersGood →
            ∃ cand : EuclideanSpace ℝ (Fin d) × ℝ,
              let st' := st.syncSplitOne cand.1 cand.2
              st'.NodesInv ∧
              (chainTerminal P'.handleCoords st'.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
              EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m' P' st'.k st'.nodes st'.snAge
                (fun r => (st'.ownedJob r).isNone) ∧
              CG01_EncJobs p P' st' m' ∧
              st'.AllCentersGood)
        (2 * p.φ_ev)
        (freshAllocFourCost p.D₀ p.NumSlots + 240 + hpjCallCost d n p + syncSplitPostHPJCost d p) := by
      have hcost_le : 10 + 10 * p.B_hpj ≤
          freshAllocFourCost p.D₀ p.NumSlots + 240 + hpjCallCost d n p + syncSplitPostHPJCost d p := by
        unfold hpjCallCost; omega
      refine ⟨by have := hp.hφ0; linarith,
        (fun _ m' => m' = m1.popDepth 0), (fun _ => False), inferInstance,
        hDummy.mono (fun _ _ h => h) hcost_le,
        by simp only [Finset.filter_false, Finset.card_empty, Nat.cast_zero]
           exact mul_nonneg (by have := hp.hφ0; linarith) (by positivity),
        ?_⟩
      intro _ m' hm'
      rw [hpop1] at hm'; subst hm'
      refine ⟨hpop1,
        ⟨hw00_1, (0, 0), by rw [hst_eq]; exact ⟨hinv, hleaf_cap, hChain1, hJobs1⟩⟩,
        fun _ hGood_st =>
          ⟨(0, 0), by rw [hst_eq]; exact ⟨hinv, hleaf_cap, hChain1, hJobs1, hGood_st⟩⟩⟩
    have hIte := RandExecBad.ite_false
      (tB := .seq (syncSplitPreHPJStmt M_box p.D₀ p.NumSlots)
        (.seq (runHPJOnSlotStmt d n M_box p) (syncSplitPostHPJStmt d n M_box p)))
      hc_false hcond_ops hFalseBody
    exact (RandExecBad.seq_det_left hpop hpop1 e_read19 hIte).mono
      (fun _ hs => hs) (fun _ _ hg => hg) le_rfl (by unfold syncSplitOneRoundCost; linarith)

/-! ### 2. Full `20 * (d + 3)^2`-Round Synchronous Leaf-Splitting Stage (`syncSplitAllRoundsStmt`) -/

def syncSplitAllRoundsStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  .repeatN (.lit (((20 * (d + 3) ^ 2 : ℕ) : ℤ))) (syncSplitOneRoundStmt d n M_box p)

noncomputable def syncSplitAllRoundsCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  10 + (20 * (d + 3) ^ 2) * syncSplitOneRoundCost d n p

theorem boxSafe_syncSplitAllRoundsStmt {d n T_max M_box : ℕ}
    (hT : 28 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (syncSplitAllRoundsStmt d n M_box p) :=
  .repeatN _ (boxSafe_syncSplitOneRoundStmt hT p)

private def SplitPrefixAt {d n : ℕ} (p : P46Params d n) {P' : DynamicPointSet d}
    (mem₀ : ArithRAMMemory)
    (st_mid : PureServingState d n p.H p.L p.B_scan P')
    (i : ℕ) (st : PureServingState d n p.H p.L p.B_scan P') (m : ArithRAMMemory) : Prop :=
  wRead m 0 0 = wRead mem₀ 0 0 ∧
  (∃ cands : ℕ → EuclideanSpace ℝ (Fin d) × ℝ, st = syncSplitTraj st_mid cands i) ∧
  st.NodesInv ∧
  (chainTerminal P'.handleCoords st.nodes P'.activeHandles).card ≤ 4 * p.L + 2 ∧
  EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots m P' st.k st.nodes st.snAge
    (fun r => (st.ownedJob r).isNone) ∧
  CG01_EncJobs p P' st m

theorem exec_syncSplitAllRoundsStmt
    (h_lem_5_1 : S_lem_5_1)
    {cHpj cBase d n t M_box : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (hM : p46BoxSize d n p ≤ M_box)
    (inp : ArithRAMInput d)
    {P' : DynamicPointSet d} (hP' : P'.WellFormed n)
    (st_mid : PureServingState d n p.H p.L p.B_scan P')
    (hinv_mid : st_mid.NodesInv)
    (hleaf_mid : (chainTerminal P'.handleCoords st_mid.nodes P'.activeHandles).card ≤ 4 * p.L + 2)
    {mem₀ : ArithRAMMemory} (hpop₀ : mem₀.popDepth 0 = mem₀)
    (hChain₀ : EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots mem₀ P' st_mid.k st_mid.nodes st_mid.snAge
      (fun r => (st_mid.ownedJob r).isNone))
    (hJobs₀ : CG01_EncJobs p P' st_mid mem₀) :
    let R := 20 * (d + 3) ^ 2
    RandExecBad inp (syncSplitAllRoundsStmt d n M_box p) (R * p.B_hpj) mem₀
      (fun m_out =>
        wRead m_out 0 0 = wRead mem₀ 0 0 ∧
        ∃ st₁, CoupledServingStateRelaxed p (CG01_EncJobs p) P' st₁ m_out)
      (fun m_out =>
        st_mid.AllCentersGood →
          ∃ st₁, CoupledServingStateRelaxed p (CG01_EncJobs p) P' st₁ m_out ∧ st₁.AllCentersGood)
      ((R : ℝ) * (2 * p.φ_ev)) (syncSplitAllRoundsCost d n p) := by
  classical
  intro R
  let SafeInv : ℕ → ArithRAMMemory → Prop := fun i m =>
    m.popDepth 0 = m ∧ ∃ st, SplitPrefixAt p mem₀ st_mid i st m
  let GoodInv : ℕ → ArithRAMMemory → Prop := fun i m =>
    m.popDepth 0 = m ∧ ∃ st, SplitPrefixAt p mem₀ st_mid i st m ∧ st.AllCentersGood
  have hSafe₀ : SafeInv 0 mem₀ :=
    ⟨hpop₀, st_mid, rfl, ⟨fun _ => (0, 0), rfl⟩, hinv_mid, hleaf_mid, hChain₀, hJobs₀⟩
  have hstep : ∀ i < R, ∀ m, m.popDepth 0 = m → SafeInv i m →
      RandExecBad inp (syncSplitOneRoundStmt d n M_box p) p.B_hpj m
        (SafeInv (i + 1)) (fun m' => GoodInv i m → GoodInv (i + 1) m')
        (2 * p.φ_ev) (syncSplitOneRoundCost d n p) := by
    intro i _ m hpm hs
    by_cases hG : GoodInv i m
    · rcases hG with ⟨_, st, ⟨hw00, ⟨cands, hst_eq⟩, hinv, hleaf, hCh, hJb⟩, hGood_st⟩
      have hOne := (exec_syncSplitOneRoundStmt h_lem_5_1 hp hn hM inp hP' st hinv hleaf hpm hCh hJb).with_popDepth
      refine hOne.mono ?_ ?_ le_rfl le_rfl
      · rintro m' ⟨hpm', hw00', cand, hinv', hleaf', hCh', hJb'⟩
        let cands' := Function.update cands i cand
        have htr_eq : syncSplitTraj st_mid cands' (i + 1) = st.syncSplitOne cand.1 cand.2 := by
          dsimp only [syncSplitTraj, cands']
          rw [syncSplitTraj_congr st_mid i (fun j hj => Function.update_of_ne (by omega : j ≠ i) cand cands),
              ← hst_eq, Function.update_self]
        exact ⟨hpm', st.syncSplitOne cand.1 cand.2,
          hw00'.trans hw00, ⟨cands', htr_eq.symm⟩, hinv', hleaf', hCh', hJb'⟩
      · rintro m' ⟨hpm', hw00', _⟩ hg_imp _
        rcases hg_imp hGood_st with ⟨cand, hinv', hleaf', hCh', hJb', hGood'⟩
        let cands' := Function.update cands i cand
        have htr_eq : syncSplitTraj st_mid cands' (i + 1) = st.syncSplitOne cand.1 cand.2 := by
          dsimp only [syncSplitTraj, cands']
          rw [syncSplitTraj_congr st_mid i (fun j hj => Function.update_of_ne (by omega : j ≠ i) cand cands),
              ← hst_eq, Function.update_self]
        exact ⟨hpm', st.syncSplitOne cand.1 cand.2,
          ⟨hw00'.trans hw00, ⟨cands', htr_eq.symm⟩, hinv', hleaf', hCh', hJb'⟩, hGood'⟩
    · rcases hs with ⟨_, st, hw00, ⟨cands, hst_eq⟩, hinv, hleaf, hCh, hJb⟩
      have hOne := (exec_syncSplitOneRoundStmt h_lem_5_1 hp hn hM inp hP' st hinv hleaf hpm hCh hJb).with_popDepth
      refine hOne.mono ?_ ?_ le_rfl le_rfl
      · rintro m' ⟨hpm', hw00', cand, hinv', hleaf', hCh', hJb'⟩
        let cands' := Function.update cands i cand
        have htr_eq : syncSplitTraj st_mid cands' (i + 1) = st.syncSplitOne cand.1 cand.2 := by
          dsimp only [syncSplitTraj, cands']
          rw [syncSplitTraj_congr st_mid i (fun j hj => Function.update_of_ne (by omega : j ≠ i) cand cands),
              ← hst_eq, Function.update_self]
        exact ⟨hpm', st.syncSplitOne cand.1 cand.2,
          hw00'.trans hw00, ⟨cands', htr_eq.symm⟩, hinv', hleaf', hCh', hJb'⟩
      · intro _ _ _ hg_in
        exact False.elim (hG hg_in)
  have hRep := RandExecBad.repeatN_nat
    (.lit (((20 * (d + 3) ^ 2 : ℕ) : ℤ))) (syncSplitOneRoundStmt d n M_box p)
    R p.B_hpj 10 (syncSplitOneRoundCost d n p)
    (by have := hp.hφ0; linarith) SafeInv GoodInv hpop₀ hSafe₀ rfl (by simp [intExprOps]) hstep
  refine hRep.mono ?_ ?_ le_rfl le_rfl
  · rintro m_out ⟨hpm_out, st₁, hw00, ⟨cands, hst₁_eq⟩, _, _, hCh₁, hJb₁⟩
    have hwf₁ : st₁.WellFormed := by
      rw [hst₁_eq]
      exact (syncSplitTraj_wellFormed h_lem_5_1 st_mid hp.hL_floor hinv_mid hleaf_mid cands).2.1
    exact ⟨hw00, st₁, hpm_out, hwf₁, hCh₁, hJb₁⟩
  · rintro m_out _ hg_imp hGood_mid
    have hG₀ : GoodInv 0 mem₀ :=
      ⟨hpop₀, st_mid, ⟨rfl, ⟨fun _ => (0, 0), rfl⟩, hinv_mid, hleaf_mid, hChain₀, hJobs₀⟩, hGood_mid⟩
    rcases hg_imp hG₀ with ⟨hpm_out, st₁, ⟨_, ⟨cands, hst₁_eq⟩, _, _, hCh₁, hJb₁⟩, hGood₁⟩
    have hwf₁ : st₁.WellFormed := by
      rw [hst₁_eq]
      exact (syncSplitTraj_wellFormed h_lem_5_1 st_mid hp.hL_floor hinv_mid hleaf_mid cands).2.1
    exact ⟨st₁, ⟨hpm_out, hwf₁, hCh₁, hJb₁⟩, hGood₁⟩

end UL.Proof_lem_7_2_RacerP46
