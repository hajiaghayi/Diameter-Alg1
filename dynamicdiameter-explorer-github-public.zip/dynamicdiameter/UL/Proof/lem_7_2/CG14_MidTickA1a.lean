import UL.Proof.lem_7_2.CG03_JobTickA3c2a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Active Affected Job Phase 1a: `propAndBuildActiveJobStmt` & Step-Build + Norm Helper -/

def stepBuildAndNormLastStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let jLenE : IntExpr := .readHeap 19 rE
  let lastIdxE : IntExpr := .add (.mul rE (.lit (p.D₀ : ℤ))) (.sub jLenE (.lit 1))
  seqList [
    boxWriteW M_box 26 (.lit 7) lastIdxE,
    .ite (.intEq jLenE (.lit 1))
      (boxWriteW M_box 26 (.lit 9) (.readHeap 14 rE))
      (boxWriteW M_box 26 (.lit 9)
        (.readHeap 23 (.add (.mul (.lit 8) (.sub (.readHeap 26 (.lit 7)) (.lit 1))) (.lit 5)))),
    stepBuildJobLevelStmt d n p.D p.K_seg p.K_batch M_box,
    .ite (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 2))
      (boxWriteW M_box 24 (.add (.mul (.lit 2) (.readHeap 26 (.lit 7))) (.lit 1)) (.lit 0))
      .skip
  ]

def propAndBuildActiveJobStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  .seq (propagateAllJobLevelsStmt d p.D₀ p.K_seg M_box)
       (stepBuildAndNormLastStmt d n M_box p)

theorem boxSafe_stepBuildAndNormLastStmt {d n T_max M_box : ℕ}
    (hT : 28 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (stepBuildAndNormLastStmt d n M_box p) := by
  unfold stepBuildAndNormLastStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact .ite _ (.boxW (by omega) _ _) (.boxW (by omega) _ _)
  · exact boxSafe_stepBuildJobLevelStmt hT d n p.D p.K_seg p.K_batch
  · exact .ite _ (.boxW (by omega) _ _) .skip

theorem boxSafe_propAndBuildActiveJobStmt {d n T_max M_box : ℕ}
    (hT : 28 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (propAndBuildActiveJobStmt d n M_box p) :=
  .seq (boxSafe_propagateAllJobLevelsStmt hT d p.D₀ p.K_seg)
       (boxSafe_stepBuildAndNormLastStmt hT p)

def propAndBuildActiveJobCost {d n : ℕ} (p : P46Params d n) : ℕ :=
  propagateAllJobLevelsCost d p.D₀ p.K_seg +
    (2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 250)

lemma cg14_card_eq_of_bij {A B : Finset ℕ} {f g : ℕ → ℕ}
    (hf : ∀ x ∈ A, f x ∈ B ∧ g (f x) = x)
    (hg : ∀ y ∈ B, g y ∈ A ∧ f (g y) = y) :
    A.card = B.card := by
  refine Finset.card_bij (fun x _ => f x) (fun x hx => (hf x hx).1) ?_ ?_
  · intro x₁ hx₁ x₂ hx₂ heq
    have h := congrArg g heq
    rwa [(hf x₁ hx₁).2, (hf x₂ hx₂).2] at h
  · intro y hy
    exact ⟨g y, (hg y hy).1, (hg y hy).2⟩

theorem exec_stepBuildAndNormLastStmt
    (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    {i jLen pS : ℕ} (hi : i < ctx.st₀.k)
    {mp : ArithRAMMemory}
    {lvs_h : List (JobLvData ctx.d)}
    {Spar_old : Finset ℕ} {fSq_p : ℕ → ℝ}
    {ph_pre scan_pre m_last : ℕ}
    (hlen_eq : lvs_h.length = jLen)
    (hjLen_pos : 1 ≤ jLen)
    (hjLen_lt_D0 : jLen < ctx.p.D₀)
    (hm_last_eq : (lvs_h[jLen - 1]'(by omega)).S_birth.card = m_last)
    (hmp_15 : wRead mp 26 15 = (i : ℤ))
    (hmp_19 : wRead mp 19 (i : ℤ) = (jLen : ℤ))
    (hpS_lt : pS < ctx.p.NumSlots)
    (hpS_disj : pS ∉ jobLevelSlotSet mp (i * ctx.p.D₀ + (jLen - 1)))
    (hpS_branch :
      (jLen = 1 → wRead mp 14 (i : ℤ) = (pS : ℤ)) ∧
      (jLen ≠ 1 → wRead mp 23 (((8 * (i * ctx.p.D₀ + (jLen - 2)) + 5 : ℕ) : ℤ)) = (pS : ℤ)))
    (hSeg_p : EncSegSlot ctx.p.K_seg mp pS
      (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) (jLen - 1)) fSq_p)
    (hLive : EncLiveCoords ctx.d ctx.n mp ctx.P'.activeHandles ctx.P'.handleCoords)
    (hseg_mp : SegGenBound ctx.p.K_seg ctx.p.NumSlots mp)
    (hsave_mp : SaveGenBound ctx.n ctx.p.NumSlots mp)
    (hEnc_last_mp : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots mp
      ctx.P'.activeHandles ctx.P'.handleCoords (i * ctx.p.D₀ + (jLen - 1))
      (lvs_h[jLen - 1]'(by omega)).S_birth (lvs_h[jLen - 1]'(by omega)).snapPts
      (lvs_h[jLen - 1]'(by omega)).prov
      (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) (jLen - 1)) true)
    (hw_ph_mp : wRead mp 24 (((2 * (i * ctx.p.D₀ + (jLen - 1)) + 0 : ℕ) : ℤ)) = (ph_pre : ℤ))
    (hw_sc_mp : wRead mp 24 (((2 * (i * ctx.p.D₀ + (jLen - 1)) + 1 : ℕ) : ℤ)) = (scan_pre : ℤ))
    (hpar_sc :
      ((jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) (jLen - 1)).filter
        (fun x => scan_pre ≤ x)).card ≤
      (Spar_old.filter (fun x => scan_pre ≤ x)).card + 1) :
    let lastIdx := i * ctx.p.D₀ + (jLen - 1)
    let Spar_last_h' := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
      (ctx.S_post_h ⟨i, hi⟩) (jLen - 1)
    ∃ (m₁ : ArithRAMMemory) (ph' scan' : ℕ),
      DetExecAt 0 inp (stepBuildAndNormLastStmt ctx.d ctx.n ctx.M_box ctx.p) mp m₁
        (2400 * (ctx.p.K_batch + 1) * (ctx.p.K_seg + ctx.d + 5) + 250) ∧
      m₁.popDepth 0 = m₁ ∧
      SegGenBound ctx.p.K_seg ctx.p.NumSlots m₁ ∧
      SaveGenBound ctx.n ctx.p.NumSlots m₁ ∧
      ph' ≤ 2 ∧
      wRead m₁ 24 (((2 * lastIdx + 0 : ℕ) : ℤ)) = (ph' : ℤ) ∧
      wRead m₁ 24 (((2 * lastIdx + 1 : ℕ) : ℤ)) = (scan' : ℤ) ∧
      EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₁
        ctx.P'.activeHandles ctx.P'.handleCoords lastIdx
        (lvs_h[jLen - 1]'(by omega)).S_birth (lvs_h[jLen - 1]'(by omega)).snapPts
        (lvs_h[jLen - 1]'(by omega)).prov Spar_last_h' true ∧
      ((ph_pre = 0 →
         (scan_pre + (ctx.p.B_scan + 1) < m_last → ph' = 0 ∧ scan' = scan_pre + (ctx.p.B_scan + 1)) ∧
         (m_last ≤ scan_pre + (ctx.p.B_scan + 1) → ph' = 1 ∧ scan' = 0)) ∧
       (ph_pre = 1 →
         ph' = 2 ∨
         (ph' = 1 ∧
           (Spar_last_h'.filter (fun x => scan' ≤ x)).card + ctx.p.B_scan ≤
             (Spar_old.filter (fun x => scan_pre ≤ x)).card)) ∧
       (ph_pre = 2 → ph' = 2)) ∧
      (∀ s < ctx.p.NumSlots, s ∉ jobLevelSlotSet mp lastIdx →
        ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg mp s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁) ∧
      (∀ s < ctx.p.NumSlots, ∀ S₁ sp₁,
        EncSlotCoords ctx.d ctx.n mp ctx.P'.activeHandles ctx.P'.handleCoords s S₁ sp₁ →
        EncSlotCoords ctx.d ctx.n m₁ ctx.P'.activeHandles ctx.P'.handleCoords s S₁ sp₁) ∧
      (∀ t, t ≠ 1 → t ≠ 5 → t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 23 → t ≠ 24 → t ≠ 26 →
        ∀ idx, wRead m₁ t idx = wRead mp t idx) ∧
      (∀ idx, idx ≠ 3 → wRead m₁ 1 idx = wRead mp 1 idx) ∧
      (∀ idx, idx ≠ ((8 * lastIdx + 1 : ℕ) : ℤ) → wRead m₁ 23 idx = wRead mp 23 idx) ∧
      (∀ idx : ℤ, (idx < ((2 * lastIdx : ℕ) : ℤ) ∨ ((2 * lastIdx + 2 : ℕ) : ℤ) ≤ idx) →
        wRead m₁ 24 idx = wRead mp 24 idx) ∧
      (∀ idx : ℤ, idx ≠ 3 → idx ≠ 4 → idx ≠ 5 → idx ≠ 6 → idx ≠ 7 → idx ≠ 8 → idx ≠ 9 → idx ≠ 25 →
        wRead m₁ 26 idx = wRead mp 26 idx) ∧
      (∀ t, t ≠ 8 → t ≠ 24 → t ≠ 26 → ∀ idx, rRead m₁ t idx = rRead mp t idx) ∧
      (∀ idx : ℤ, (idx < ((2 * lastIdx : ℕ) : ℤ) ∨ ((2 * lastIdx + 2 : ℕ) : ℤ) ≤ idx) →
        rRead m₁ 24 idx = rRead mp 24 idx) := by
  intro lastIdx Spar_last_h'
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  have hD_p : 3 ≤ ctx.p.D := by rw [ctx.hD_eq]; omega
  have hlast_lt_lh : jLen - 1 < lvs_h.length := by omega
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let jLenE : IntExpr := .readHeap 19 rE
  let lastIdxE : IntExpr := .add (.mul rE (.lit (ctx.p.D₀ : ℤ))) (.sub jLenE (.lit 1))
  let mq1 := wWrite mp 26 7 (lastIdx : ℤ)
  have hd_q1 : DetExecAt 0 inp (boxWriteW ctx.M_box 26 (.lit 7) lastIdxE) mp mq1 35 := by
    refine exec_boxWriteW inp mp _ _ rfl (by omega) (by have := ctx.hBox30; omega) ?_
      (by simp [lastIdxE, jLenE, rE, intExprOps])
    simp only [lastIdxE, jLenE, rE, iValAt_add, iValAt_mul, iValAt_sub, iValAt_readHeap, iValAt_lit,
      hmp_15, hmp_19, lastIdx]
    omega
  let mq2 := wWrite mq1 26 9 (pS : ℤ)
  have hd_q2 : DetExecAt 0 inp
      (.ite (.intEq jLenE (.lit 1))
        (boxWriteW ctx.M_box 26 (.lit 9) (.readHeap 14 rE))
        (boxWriteW ctx.M_box 26 (.lit 9)
          (.readHeap 23 (.add (.mul (.lit 8) (.sub (.readHeap 26 (.lit 7)) (.lit 1))) (.lit 5)))))
      mq1 mq2 60 := by
    have hmq1_15 : wRead mq1 26 15 = (i : ℤ) := by simp [mq1, hmp_15]
    have hmq1_19 : wRead mq1 19 (i : ℤ) = (jLen : ℤ) := by simp [mq1, hmp_19]
    by_cases hj1 : jLen = 1
    · have hc_eq1 : cValAt 0 inp mq1 (.intEq jLenE (.lit 1)) = true := by
        simp [jLenE, rE, hmq1_15, hmq1_19, hj1]
      have hd_w9 : DetExecAt 0 inp (boxWriteW ctx.M_box 26 (.lit 9) (.readHeap 14 rE)) mq1 mq2 25 := by
        refine exec_boxWriteW inp mq1 _ _ rfl (by omega) (by have := ctx.hBox30; omega) ?_
          (by simp [rE, intExprOps])
        simp only [rE, iValAt_readHeap, iValAt_lit, hmq1_15, mq1]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hpS_branch.1 hj1]
      exact (DetExecAt.ite_true hc_eq1 (C_c := 15) (by simp [condExprOps, jLenE, rE, intExprOps]) hd_w9).mono_cost (by omega)
    · have hc_ne1 : cValAt 0 inp mq1 (.intEq jLenE (.lit 1)) = false := by
        simp [jLenE, rE, hmq1_15, hmq1_19, hj1]
      have hd_w9 : DetExecAt 0 inp
          (boxWriteW ctx.M_box 26 (.lit 9)
            (.readHeap 23 (.add (.mul (.lit 8) (.sub (.readHeap 26 (.lit 7)) (.lit 1))) (.lit 5))))
          mq1 mq2 35 := by
        refine exec_boxWriteW inp mq1 _ _ rfl (by omega) (by have := ctx.hBox30; omega) ?_
          (by simp [intExprOps])
        have hmq1_7 : wRead mq1 26 7 = (lastIdx : ℤ) := by simp [mq1]
        simp only [iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_sub, iValAt_lit, hmq1_7]
        have hj2 : 2 ≤ jLen := by omega
        have hidx_eq : (8 : ℤ) * ((lastIdx : ℤ) - 1) + 5 = ((8 * (i * ctx.p.D₀ + (jLen - 2)) + 5 : ℕ) : ℤ) := by
          dsimp only [lastIdx]; omega
        rw [hidx_eq]; dsimp only [mq1]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hpS_branch.2 hj1]
      exact (DetExecAt.ite_false hc_ne1 (C_c := 15) (by simp [condExprOps, jLenE, rE, intExprOps]) hd_w9).mono_cost (by omega)
  have hwo_mq2 : ∀ t, t ≠ 26 → ∀ idx, wRead mq2 t idx = wRead mp t idx :=
    fun t ht idx => by simp [mq2, mq1, ht]
  have hw26_mq2 : ∀ idx, idx ≠ 7 → idx ≠ 9 → wRead mq2 26 idx = wRead mp 26 idx :=
    fun idx h7 h9 => by simp [mq2, mq1, h7, h9]
  have hr_mq2 : ∀ t idx, rRead mq2 t idx = rRead mp t idx := fun _ _ => by simp [mq2, mq1]
  have hslot_mq2 : jobLevelSlotSet mq2 lastIdx = jobLevelSlotSet mp lastIdx := by
    unfold jobLevelSlotSet; simp [hwo_mq2 23 (by decide)]
  have hS_par_sub : Spar_last_h' ⊆ ctx.P'.activeHandles :=
    (jobHandleInput_subset (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) (jLen - 1)).trans
      (cg01_chainInput_subset ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles r_fin.castSucc)
  have hBox_last := (ctx.jobIdx_box_bounds hi (by omega : jLen - 1 < ctx.p.D₀)).1
  have hLive_mq2 : EncLiveCoords ctx.d ctx.n mq2 ctx.P'.activeHandles ctx.P'.handleCoords :=
    ⟨hLive.1, fun h hh c => by rw [hr_mq2]; exact hLive.2 h hh c⟩
  have hseg_mq2 : SegGenBound ctx.p.K_seg ctx.p.NumSlots mq2 :=
    ⟨by rw [hwo_mq2 1 (by decide)]; exact hseg_mp.1,
     fun s hs => by rw [hwo_mq2 5 (by decide), hwo_mq2 1 (by decide)]; exact hseg_mp.2.1 s hs,
     fun s hs u hu => by rw [hwo_mq2 8 (by decide), hwo_mq2 1 (by decide)]; exact hseg_mp.2.2 s hs u hu⟩
  have hsave_mq2 : SaveGenBound ctx.n ctx.p.NumSlots mq2 :=
    ⟨by rw [hwo_mq2 1 (by decide)]; exact hsave_mp.1,
     fun s hs => by rw [hwo_mq2 6 (by decide), hwo_mq2 1 (by decide)]; exact hsave_mp.2.1 s hs,
     fun s hs h hh => by rw [hwo_mq2 11 (by decide), hwo_mq2 1 (by decide)]; exact hsave_mp.2.2 s hs h hh⟩
  have hSeg_p_mq2 : EncSegSlot ctx.p.K_seg mq2 pS Spar_last_h' fSq_p :=
    hSeg_p.congr_mem_fSq (by rw [hwo_mq2 5 (by decide)]) (fun _ _ => by rw [hwo_mq2 8 (by decide)])
      (fun _ _ => by rw [hwo_mq2 9 (by decide)]) (fun _ _ => by rw [hwo_mq2 10 (by decide)])
      (fun _ _ => by rw [hr_mq2]) (fun _ _ => rfl)
  have hEnc_last_mq2 : EncJobLevel ctx.d ctx.n ctx.p.D ctx.p.K_seg ctx.p.NumSlots mq2
      ctx.P'.activeHandles ctx.P'.handleCoords lastIdx
      (lvs_h[jLen - 1]'hlast_lt_lh).S_birth (lvs_h[jLen - 1]'hlast_lt_lh).snapPts
      (lvs_h[jLen - 1]'hlast_lt_lh).prov Spar_last_h' true := by
    rw [ctx.hD_eq]
    exact hEnc_last_mp.frame (fun _ _ => rfl)
      (fun _ _ _ _ _ _ _ h0 => h0.congr_mem_fSq (by rw [hwo_mq2 5 (by decide)])
        (fun _ _ => by rw [hwo_mq2 8 (by decide)]) (fun _ _ => by rw [hwo_mq2 9 (by decide)])
        (fun _ _ => by rw [hwo_mq2 10 (by decide)]) (fun _ _ => by rw [hr_mq2]) (fun _ _ => rfl))
      (fun _ _ => by rw [hwo_mq2 6 (by decide)])
      (fun _ _ _ hC => hC.congr_mem3 (by rw [hwo_mq2 6 (by decide)])
        (fun _ => by rw [hwo_mq2 11 (by decide)]) (fun _ => by rw [hr_mq2]))
      (fun _ _ => by rw [hwo_mq2 23 (by decide)])
      (fun _ _ => by rw [hwo_mq2 24 (by decide)])
      (fun _ => by rw [hr_mq2]) (fun _ _ => by rw [hr_mq2])
  rcases exec_stepBuildJobLevelStmt (K_batch := ctx.p.K_batch) inp mq2 hD_p ctx.hn_2K hpS_lt (by rwa [hslot_mq2]) hS_par_sub
      ctx.hBox_slots hBox_last ctx.hBox30 ctx.hBox_seg
      (by dsimp only [mq2, mq1]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
      (by dsimp only [mq2]; exact wRead_wWrite_self _ _ _ _)
      hLive_mq2 hseg_mq2 hsave_mq2 hSeg_p_mq2 hEnc_last_mq2
    with ⟨mb, hd_build, hpop_mb, hseg_mb, hsave_mb, hEnc_last_mb,
          hph0_step, hph1_step, hph2_step,
          hSegFr_mb, _, hSnapFr_mb,
          hwo_mb, hw1_mb, hw23_mb, hw24_mb, hw26_mb, hro_mb, hr24_mb⟩
  have hmb_7 : wRead mb 26 7 = (lastIdx : ℤ) := by
    rw [hw26_mb 7 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]; simp [mq2, mq1]
  have h2last0 : (2 : ℤ) * (lastIdx : ℤ) = ((2 * lastIdx + 0 : ℕ) : ℤ) := by push_cast; ring
  have h2last1 : (2 : ℤ) * (lastIdx : ℤ) + 1 = ((2 * lastIdx + 1 : ℕ) : ℤ) := by push_cast; ring
  have hBox_24 : ((2 * lastIdx + 1 : ℕ) : ℤ) < (ctx.M_box : ℤ) := by omega
  have hw_ph_mq2 : wRead mq2 24 (((2 * lastIdx + 0 : ℕ) : ℤ)) = (ph_pre : ℤ) := by
    rw [hwo_mq2 24 (by decide), hw_ph_mp]
  have hw_sc_mq2 : wRead mq2 24 (((2 * lastIdx + 1 : ℕ) : ℤ)) = (scan_pre : ℤ) := by
    rw [hwo_mq2 24 (by decide), hw_sc_mp]
  have hEnc_d3 : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots mb
      ctx.P'.activeHandles ctx.P'.handleCoords lastIdx
      (lvs_h[jLen - 1]'hlast_lt_lh).S_birth (lvs_h[jLen - 1]'hlast_lt_lh).snapPts
      (lvs_h[jLen - 1]'hlast_lt_lh).prov Spar_last_h' true :=
    ctx.hD_eq ▸ hEnc_last_mb
  have h_norm : ∃ (m₁ : ArithRAMMemory) (ph' scan' : ℕ),
      DetExecAt 0 inp
        (.ite (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 2))
          (boxWriteW ctx.M_box 24 (.add (.mul (.lit 2) (.readHeap 26 (.lit 7))) (.lit 1)) (.lit 0))
          .skip)
        mb m₁ 45 ∧
      m₁.popDepth 0 = m₁ ∧
      ph' ≤ 2 ∧
      wRead m₁ 24 (((2 * lastIdx + 0 : ℕ) : ℤ)) = (ph' : ℤ) ∧
      wRead m₁ 24 (((2 * lastIdx + 1 : ℕ) : ℤ)) = (scan' : ℤ) ∧
      EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₁
        ctx.P'.activeHandles ctx.P'.handleCoords lastIdx
        (lvs_h[jLen - 1]'hlast_lt_lh).S_birth (lvs_h[jLen - 1]'hlast_lt_lh).snapPts
        (lvs_h[jLen - 1]'hlast_lt_lh).prov Spar_last_h' true ∧
      ((ph_pre = 0 →
         (scan_pre + (ctx.p.B_scan + 1) < m_last → ph' = 0 ∧ scan' = scan_pre + (ctx.p.B_scan + 1)) ∧
         (m_last ≤ scan_pre + (ctx.p.B_scan + 1) → ph' = 1 ∧ scan' = 0)) ∧
       (ph_pre = 1 →
         ph' = 2 ∨
         (ph' = 1 ∧
           (Spar_last_h'.filter (fun x => scan' ≤ x)).card + ctx.p.B_scan ≤
             (Spar_old.filter (fun x => scan_pre ≤ x)).card)) ∧
       (ph_pre = 2 → ph' = 2)) ∧
      (∀ t, t ≠ 24 → ∀ idx, wRead m₁ t idx = wRead mb t idx) ∧
      (∀ idx, idx ≠ ((2 * lastIdx + 1 : ℕ) : ℤ) → wRead m₁ 24 idx = wRead mb 24 idx) ∧
      (∀ t idx, rRead m₁ t idx = rRead mb t idx) := by
    rcases hEnc_d3 with ⟨bS_l, dS_l, spDS_l, rS_l, spRS_l, hb_l, hd_l, hsd_l, hr_l, hsr_l,
      n1, n2, n3, n4, n5, n6, n7, n8, n9, n10,
      e2, e3, e4, e5, e6, g2, g3, g4, g5, g6, hb_pos_l, e0, hSeg_b_l, hSlot_b_l, ho_l, hPh_mb⟩
    rcases hPh_mb with ⟨cur', hcur', hph_mb0, hsc_mb0, hcore_mb, hrV_mb, hrmax_mb, _⟩ |
                       ⟨cur', hcur', hph_mb1, hsc_mb1, hrV_mb, hEd_mb, hEspD_mb, hEr_mb, _, hEspR_mb⟩ |
                       ⟨hph_mb2, hrV_mb, hEd_mb, hEspD_mb, hEr_mb, hEspR_mb⟩
    · have hc_f : cValAt 0 inp mb (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 2)) = false := by
        simp only [cValAt_intEq, iValAt_readHeap, iValAt_mul, iValAt_lit, hmb_7]; rw [h2last0, hph_mb0]; decide
      refine ⟨mb, 0, cur',
        (DetExecAt.ite_false hc_f (C_c := 16) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp mb)).mono_cost (by omega),
        hpop_mb, by omega, hph_mb0, hsc_mb0,
        ⟨bS_l, dS_l, spDS_l, rS_l, spRS_l, hb_l, hd_l, hsd_l, hr_l, hsr_l,
         n1, n2, n3, n4, n5, n6, n7, n8, n9, n10,
         e2, e3, e4, e5, e6, g2, g3, g4, g5, g6, hb_pos_l, e0, hSeg_b_l, hSlot_b_l, ho_l,
         Or.inl ⟨cur', hcur', hph_mb0, hsc_mb0, hcore_mb, hrV_mb, hrmax_mb, rfl⟩⟩,
        ?_, (fun _ _ _ => rfl), (fun _ _ => rfl), (fun _ _ => rfl)⟩
      refine ⟨fun hp0 => ?_, fun hp1 => ?_, fun hp2 => ?_⟩
      · have h0 := hph0_step scan_pre (by rw [hw_ph_mq2, hp0]; rfl) hw_sc_mq2
        rw [hm_last_eq, ctx.hKbatch] at h0
        refine ⟨fun hlt => ⟨rfl, ?_⟩, fun hge => ?_⟩
        · have heq := (h0.1 hlt).2; rw [hsc_mb0] at heq; exact_mod_cast heq
        · have heq := (h0.2 hge).1; rw [hph_mb0] at heq; omega
      · rcases hph1_step scan_pre (by rw [hw_ph_mq2, hp1]; rfl) hw_sc_mq2 with h2 | ⟨_, _, h1, _⟩
        · rw [hph_mb0] at h2; omega
        · rw [hph_mb0] at h1; omega
      · have h2 := hph2_step (by rw [hw_ph_mq2, hp2]; rfl)
        rw [hph_mb0] at h2; omega
    · have hc_f : cValAt 0 inp mb (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 2)) = false := by
        simp only [cValAt_intEq, iValAt_readHeap, iValAt_mul, iValAt_lit, hmb_7]; rw [h2last0, hph_mb1]; decide
      refine ⟨mb, 1, cur',
        (DetExecAt.ite_false hc_f (C_c := 16) (by simp [condExprOps, intExprOps])
          (DetExecAt.skip 0 inp mb)).mono_cost (by omega),
        hpop_mb, by omega, hph_mb1, hsc_mb1,
        ⟨bS_l, dS_l, spDS_l, rS_l, spRS_l, hb_l, hd_l, hsd_l, hr_l, hsr_l,
         n1, n2, n3, n4, n5, n6, n7, n8, n9, n10,
         e2, e3, e4, e5, e6, g2, g3, g4, g5, g6, hb_pos_l, e0, hSeg_b_l, hSlot_b_l, ho_l,
         Or.inr (Or.inl ⟨cur', hcur', hph_mb1, hsc_mb1, hrV_mb, hEd_mb, hEspD_mb, hEr_mb, rfl, hEspR_mb⟩)⟩,
        ?_, (fun _ _ _ => rfl), (fun _ _ => rfl), (fun _ _ => rfl)⟩
      refine ⟨fun hp0 => ?_, fun hp1 => ?_, fun hp2 => ?_⟩
      · have h0 := hph0_step scan_pre (by rw [hw_ph_mq2, hp0]; rfl) hw_sc_mq2
        rw [hm_last_eq, ctx.hKbatch] at h0
        refine ⟨fun hlt => ?_, fun hge => ⟨rfl, ?_⟩⟩
        · have heq := (h0.1 hlt).1; rw [hph_mb1] at heq; omega
        · have heq := (h0.2 hge).2; rw [hsc_mb1] at heq; exact_mod_cast heq
      · rcases hph1_step scan_pre (by rw [hw_ph_mq2, hp1]; rfl) hw_sc_mq2 with h2 | ⟨cur1, _, _, hsc1, hrem1⟩
        · rw [hph_mb1] at h2; omega
        · right
          have hcur_eq : cur' = cur1 := by exact_mod_cast (hsc_mb1.symm.trans hsc1)
          subst hcur_eq
          rw [ctx.hKbatch] at hrem1
          have hpar_sc' : (Spar_last_h'.filter (fun x => scan_pre ≤ x)).card ≤
              (Spar_old.filter (fun x => scan_pre ≤ x)).card + 1 := hpar_sc
          exact ⟨rfl, by omega⟩
      · have h2 := hph2_step (by rw [hw_ph_mq2, hp2]; rfl)
        rw [hph_mb1] at h2; omega
    · have hc_t : cValAt 0 inp mb (.intEq (.readHeap 24 (.mul (.lit 2) (.readHeap 26 (.lit 7)))) (.lit 2)) = true := by
        simp only [cValAt_intEq, iValAt_readHeap, iValAt_mul, iValAt_lit, hmb_7]; rw [h2last0, hph_mb2]; decide
      let m₁ := wWrite mb 24 (((2 * lastIdx + 1 : ℕ) : ℤ)) 0
      have hw_m1_o : ∀ t, t ≠ 24 → ∀ idx, wRead m₁ t idx = wRead mb t idx :=
        fun t ht idx => wRead_wWrite_of_ne _ _ (Or.inl ht)
      have hr_m1_all : ∀ t idx, rRead m₁ t idx = rRead mb t idx :=
        fun _ _ => by simp [m₁]
      have hd_z : DetExecAt 0 inp
          (boxWriteW ctx.M_box 24 (.add (.mul (.lit 2) (.readHeap 26 (.lit 7))) (.lit 1)) (.lit 0))
          mb m₁ 28 :=
        exec_boxWriteW inp mb _ _
          (by simp only [iValAt_add, iValAt_mul, iValAt_lit, iValAt_readHeap, hmb_7, h2last1])
          (by omega) hBox_24 rfl (by simp [intExprOps])
      have hSeg_m1 : ∀ s S₁ fSq₁, EncSegSlot ctx.p.K_seg mb s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁ :=
        fun _ _ _ hE => hE.congr_mem_fSq (hw_m1_o 5 (by decide) _)
          (fun _ _ => hw_m1_o 8 (by decide) _) (fun _ _ => hw_m1_o 9 (by decide) _)
          (fun _ _ => hw_m1_o 10 (by decide) _) (fun _ _ => hr_m1_all _ _) (fun _ _ => rfl)
      refine ⟨m₁, 2, 0,
        (DetExecAt.ite_true hc_t (C_c := 16) (by simp [condExprOps, intExprOps]) hd_z).mono_cost (by omega),
        wWrite_popDepth_zero hpop_mb 24 _ 0, by omega,
        by dsimp only [m₁]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hph_mb2]; rfl,
        wRead_wWrite_self _ _ _ _,
        ⟨bS_l, dS_l, spDS_l, rS_l, spRS_l, hb_l, hd_l, hsd_l, hr_l, hsr_l,
         n1, n2, n3, n4, n5, n6, n7, n8, n9, n10,
         (hw_m1_o 23 (by decide) _).trans e2, (hw_m1_o 23 (by decide) _).trans e3,
         (hw_m1_o 23 (by decide) _).trans e4, (hw_m1_o 23 (by decide) _).trans e5,
         (hw_m1_o 23 (by decide) _).trans e6,
         by rw [hw_m1_o 6 (by decide)]; exact g2,
         (hw_m1_o 6 (by decide) _).trans g3, (hw_m1_o 6 (by decide) _).trans g4,
         (hw_m1_o 6 (by decide) _).trans g5,
         by rw [hw_m1_o 6 (by decide)]; exact g6,
         hb_pos_l, (hw_m1_o 23 (by decide) _).trans e0,
         hSeg_m1 _ _ _ hSeg_b_l,
         hSlot_b_l.congr_mem3 (hw_m1_o 6 (by decide) _) (fun _ => hw_m1_o 11 (by decide) _) (fun _ => hr_m1_all _ _),
         fun c => (hr_m1_all _ _).trans (ho_l c),
         Or.inr (Or.inr ⟨by dsimp only [m₁]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hph_mb2],
           (hr_m1_all _ _).trans hrV_mb,
           hSeg_m1 _ _ _ hEd_mb, hSeg_m1 _ _ _ hEspD_mb, hSeg_m1 _ _ _ hEr_mb,
           fun htr => hSeg_m1 _ _ _ (hEspR_mb htr)⟩)⟩,
        ?_,
        hw_m1_o,
        fun idx hne => wRead_wWrite_of_ne _ _ (Or.inr hne),
        hr_m1_all⟩
      refine ⟨fun hp0 => ?_, fun _ => Or.inl rfl, fun _ => rfl⟩
      have h0 := hph0_step scan_pre (by rw [hw_ph_mq2, hp0]; rfl) hw_sc_mq2
      by_cases hlt : scan_pre + ctx.p.K_batch < (lvs_h[jLen - 1]'hlast_lt_lh).S_birth.card
      · have heq := (h0.1 hlt).1; rw [hph_mb2] at heq; omega
      · have heq := (h0.2 (by omega)).1; rw [hph_mb2] at heq; omega
  rcases h_norm with ⟨m₁, ph', scan', hd_norm, hpop_m1, hph'_le, hw24_ph, hw24_sc,
    hEnc_last_m1, hbuild_1, hwo_m1, hw24_m1, hr_m1⟩
  have hex_sb : DetExecAt 0 inp (stepBuildAndNormLastStmt ctx.d ctx.n ctx.M_box ctx.p) mp m₁
      (2400 * (ctx.p.K_batch + 1) * (ctx.p.K_seg + ctx.d + 5) + 250) := by
    unfold stepBuildAndNormLastStmt seqList
    exact (hd_q1.seq (hd_q2.seq (hd_build.seq hd_norm))).mono_cost (by omega)
  refine ⟨m₁, ph', scan', hex_sb, hpop_m1,
    ⟨by rw [hwo_m1 1 (by decide)]; exact hseg_mb.1,
     fun s hs => by rw [hwo_m1 5 (by decide), hwo_m1 1 (by decide)]; exact hseg_mb.2.1 s hs,
     fun s hs u hu => by rw [hwo_m1 8 (by decide), hwo_m1 1 (by decide)]; exact hseg_mb.2.2 s hs u hu⟩,
    ⟨by rw [hwo_m1 1 (by decide)]; exact hsave_mb.1,
     fun s hs => by rw [hwo_m1 6 (by decide), hwo_m1 1 (by decide)]; exact hsave_mb.2.1 s hs,
     fun s hs h hh => by rw [hwo_m1 11 (by decide), hwo_m1 1 (by decide)]; exact hsave_mb.2.2 s hs h hh⟩,
    hph'_le, hw24_ph, hw24_sc, hEnc_last_m1, hbuild_1,
    (fun s hs_lt hs_not S₁ fSq₁ hE_mp => by
      have hE_mq2 := hE_mp.congr_mem_fSq (by rw [hwo_mq2 5 (by decide)]) (fun _ _ => by rw [hwo_mq2 8 (by decide)])
        (fun _ _ => by rw [hwo_mq2 9 (by decide)]) (fun _ _ => by rw [hwo_mq2 10 (by decide)])
        (fun _ _ => by rw [hr_mq2]) (fun _ _ => rfl)
      exact (hSegFr_mb s hs_lt (by rwa [hslot_mq2]) S₁ fSq₁ hE_mq2).congr_mem_fSq
        (by rw [hwo_m1 5 (by decide)]) (fun _ _ => by rw [hwo_m1 8 (by decide)])
        (fun _ _ => by rw [hwo_m1 9 (by decide)]) (fun _ _ => by rw [hwo_m1 10 (by decide)])
        (fun _ _ => by rw [hr_m1]) (fun _ _ => rfl)),
    (fun s hs_lt S₁ sp₁ hC_mp => by
      have hC_mq2 := hC_mp.congr_mem3 (by rw [hwo_mq2 6 (by decide)])
        (fun _ => by rw [hwo_mq2 11 (by decide)]) (fun _ => by rw [hr_mq2])
      exact (hSnapFr_mb s hs_lt S₁ sp₁ hC_mq2).congr_mem3
        (by rw [hwo_m1 6 (by decide)]) (fun _ => by rw [hwo_m1 11 (by decide)]) (fun _ => by rw [hr_m1])),
    (fun t h1 h5 h8 h9 h10 h23 h24 h26 idx => by
      rw [hwo_m1 t h24, hwo_mb t h1 h5 h8 h9 h10 h23 h24 h26, hwo_mq2 t h26]),
    (fun idx h3 => by rw [hwo_m1 1 (by decide), hw1_mb idx h3, hwo_mq2 1 (by decide)]),
    (fun idx hne => by rw [hwo_m1 23 (by decide), hw23_mb idx hne, hwo_mq2 23 (by decide)]),
    (fun idx hout => by rw [hw24_m1 idx (by omega), hw24_mb idx hout, hwo_mq2 24 (by decide)]),
    (fun idx h3 h4 h5 h6 h7 h8 h9 h25 => by
      rw [hwo_m1 26 (by decide), hw26_mb idx h3 h4 h5 h6 h8 h25, hw26_mq2 idx h7 h9]),
    (fun t h8 h24 h26 idx => by rw [hr_m1, hro_mb t h8 h24 h26, hr_mq2]),
    (fun idx hout => by rw [hr_m1, hr24_mb idx hout, hr_mq2])⟩

end UL.Proof_lem_7_2_RacerP46
