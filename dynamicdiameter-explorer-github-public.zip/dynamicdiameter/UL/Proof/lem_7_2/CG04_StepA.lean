import Mathlib
import UL.Stmt.lem_7_2
import UL.Proof.lem_7_2.CG01_ServingSchedA
import UL.Proof.lem_7_2.CG02_LiveRouteRAM
import UL.Proof.lem_7_2.CG04_Bridge
import UL.Proof.lem_7_2.CG04_SmallCap
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Structured `P46ParamsValid` Bundle & Box-Bound Projections -/

structure P46ParamsValid (cHpj cBase d n t : ℕ) (δ : ℝ) (p : P46Params d n) : Prop where
  hD_eq : p.D = d + 3
  hH_eq : p.H = Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
  hcB_eq : p.cBase = cBase
  hD3 : 3 ≤ p.D
  hH5 : 5 ≤ p.H
  hn2 : n < 2 ^ p.H
  ht2 : t < 2 ^ p.H
  hD2 : p.D < 2 ^ p.H
  hK_ge1 : 1 ≤ p.K_seg
  hK_le_H : p.K_seg ≤ p.H
  hn_le_2K : n ≤ 2 ^ p.K_seg
  h2K_lt_2n : 2 ^ p.K_seg < 2 * n
  hD0 : p.D₀ = 24 * (d + 3) ^ 2 * p.H
  hkφ : p.k_φ = 20 * p.H
  hφ_eq : p.φ_ev = (1 / 2 : ℝ) ^ p.k_φ
  hφ0 : 0 < p.φ_ev
  hφ1 : p.φ_ev < 1 / 2
  hK0_ge1 : 1 ≤ p.K₀
  hK0_le : p.K₀ ≤ 84 * cBase * (d + 3) ^ 2 * p.H
  hPhp_eq : p.P_hpj = hpjParams d p.φ_ev
  hPhp_props : HPJParamProps d p.φ_ev p.P_hpj
  hOpCeil : Nat.ceil (hpjOpBound d p.φ_ev) ≤ (cHpj * 21 ^ 3) * (d + 3) ^ 7 * p.H ^ 6
  hmD_le : p.P_hpj.m * (d + 3) ≤ (cHpj * 21 ^ 3) * (d + 3) ^ 7 * p.H ^ 6
  hH_le_Mbits : p.H ≤ p.M_bits
  hMbits_le : p.M_bits ≤ (105 + cHpj + 4 * cBase) * p.H
  hbias_hpj : ((2 ^ p.P_hpj.q : ℕ) : ℝ) * (n : ℝ) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev
  hbias_base : (p.K₀ : ℝ) * (n : ℝ) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev
  hfb_le : ((2 * p.D₀ + 20 * (d + 3) ^ 2 + 2 : ℕ) : ℝ) * (2 * p.φ_ev) ≤
    perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ
  hL_eq : p.L = (68719476736 + 8 * (84 * cBase)) * (d + 3) ^ 4 * p.H ^ 2
  hL_floor : 68719476736 * (d + 3) ^ 4 ≤ p.L
  hL_eq10 : SatisfiesLeafCutoffEq10 d n (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) 0 p.K₀ p.L
  hBscan : p.B_scan = 16777216 * (d + 3) ^ 4
  hKbatch : p.K_batch = p.B_scan + 1
  hSlots : p.NumSlots = 8 * (p.D₀ + 2) ^ 2
  hBhpj : p.B_hpj = (2 ^ p.P_hpj.q) * p.M_bits + p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q
  hBstep : p.B_step = (p.D₀ + 20 * (d + 3) ^ 2) * p.B_hpj + p.D₀ * p.K₀ * p.M_bits
  hmc_gen : ∀ (pts : ℕ → EuclideanSpace ℝ (Fin d))
      (P₀ S : Finset ℕ) (age : ℕ)
      (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
      (y : ℕ) (farthest : (Fin p.K₀ → ℕ) → ℕ),
    1 ≤ P₀.card →
    IsCenterpoint (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2))
      (paraboloidLiftSet (fun i : ↥P₀ => pts i.1)) (liftedPoint o s) →
    HasNodeAge P₀ S age →
    (age : ℝ) ≤ (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) * (P₀.card : ℝ) / 16 →
    IsNodeMaxRadiusPoint pts o S y →
    let V := liftVariance o s
    let samples := Fintype.piFinset (fun _ : Fin p.K₀ => S)
    (∀ samp ∈ samples,
      (∃ j : Fin p.K₀, farthest samp = samp j) ∧
      ∀ j : Fin p.K₀, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖) →
    (((open Classical in samples.filter (fun samp =>
        ¬ IsNodeBaselinePair pts o V S y (farthest samp))).card : ℝ) /
      (samples.card : ℝ)) ≤ p.φ_ev

theorem exists_valid_p46Params
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj cBase : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    (hcB_eq : cBase = extractCBaseNat h_mc)
    {d n t : ℕ} (hn : 2 ≤ n) (ht : 1 ≤ t)
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2) :
    ∃ p : P46Params d n, P46ParamsValid cHpj cBase d n t δ p := by
  let D : ℕ := d + 3
  let H : ℕ := Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
  rcases build_p46Params h_mc hcHpj hn ht hδ0 hδ1 D H cBase rfl rfl hcB_eq
    with ⟨p, hD_eq, hH_eq, hcB_p, hD3, hH5, hn2, ht2, hD2,
          hK1, hKH, hnK, h2K, hD0, hkφ, hφ_eq, hφ0, hφ1,
          hK0_1, hK0_le, hPhp_eq, hPhp_props, hOp, hmD,
          hHM, hMbits, hb_hpj, hb_base, hfb,
          hL_eq, hL_fl, hL_10, hBs, hKb, hSl, hBh, hBst, hmc⟩
  refine ⟨p, ?_⟩
  exact
    { hD_eq := hD_eq
      hH_eq := hH_eq
      hcB_eq := hcB_p
      hD3 := hD3
      hH5 := hH5
      hn2 := hn2
      ht2 := ht2
      hD2 := hD2
      hK_ge1 := hK1
      hK_le_H := hKH
      hn_le_2K := hnK
      h2K_lt_2n := h2K
      hD0 := by simpa [D, hH_eq] using hD0
      hkφ := by simpa [hH_eq] using hkφ
      hφ_eq := hφ_eq
      hφ0 := hφ0
      hφ1 := hφ1
      hK0_ge1 := hK0_1
      hK0_le := by simpa [D, hH_eq] using hK0_le
      hPhp_eq := hPhp_eq
      hPhp_props := hPhp_props
      hOpCeil := by simpa [D, hH_eq] using hOp
      hmD_le := by simpa [D, hH_eq] using hmD
      hH_le_Mbits := hHM
      hMbits_le := by simpa [hH_eq] using hMbits
      hbias_hpj := hb_hpj
      hbias_base := hb_base
      hfb_le := by simpa [D] using hfb
      hL_eq := by simpa [D, hH_eq] using hL_eq
      hL_floor := by simpa [D] using hL_fl
      hL_eq10 := by simpa [D] using hL_10
      hBscan := by simpa [D] using hBs
      hKbatch := hKb
      hSlots := hSl
      hBhpj := hBh
      hBstep := by simpa [D] using hBst
      hmc_gen := by simpa [D] using hmc }

theorem P46ParamsValid.routeBoxBounds
    {cHpj cBase d n t M_box : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n) (hM : p46BoxSize d n p ≤ M_box) :
    RouteBoxBounds d n p.K_seg p.D₀ p.NumSlots M_box ∧
    16 ≤ M_box ∧
    2 ≤ p.NumSlots ∧
    p.NumSlots ≤ M_box ∧
    d + 1 ≤ M_box ∧
    p.D₀ * d ≤ M_box ∧
    (2 ^ p.P_hpj.q) * d ≤ M_box ∧
    (∀ idx ≤ p.D₀ * p.D₀, 8 * idx + 8 ≤ M_box ∧ idx * d + d ≤ M_box) := by
  rcases p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM
    with ⟨_, _, _, _, h30, hD0_M, h2S, hd1, hn_M, hnd_M, hS_M, hSn, hSnd, _, hS2K, hhpj, hidx⟩
  have hD0_le_S : p.D₀ ≤ p.NumSlots := by
    rw [hp.hSlots]
    have h1 : p.D₀ + 2 ≤ (p.D₀ + 2) ^ 2 := by
      simpa using Nat.pow_le_pow_right (by omega : 1 ≤ p.D₀ + 2) (by decide : 1 ≤ 2)
    omega
  have hD0_d : p.D₀ * d ≤ M_box := by
    calc p.D₀ * d ≤ p.NumSlots * d := Nat.mul_le_mul_right d hD0_le_S
      _ = p.NumSlots * 1 * d := by ring
      _ ≤ p.NumSlots * n * d := Nat.mul_le_mul_right d (Nat.mul_le_mul_left _ (by omega))
      _ ≤ M_box := hSnd
  exact ⟨⟨h30, hD0_M, hn_M, hnd_M, hSn, hSnd, hS2K⟩,
    by omega, h2S, hS_M, hd1, hD0_d, hhpj, hidx⟩

/-! ### 2. Live Routing + `GhostUidMap` Coupled Execution Bridge -/

theorem exec_routeLiveUpdate_with_uid
    {d n K D₀ NumSlots M_box : ℕ}
    (P : DynamicPointSet d) (op : DynamicUpdate d) (mem : ArithRAMMemory)
    (uMap : GhostUidMap d P)
    {k : ℕ} {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ}
    (hP : P.WellFormed n)
    (hleg : IsLegalUpdate n Set.univ P op)
    (hBox : RouteBoxBounds d n K D₀ NumSlots M_box)
    (hChain : EncServingChain d n K D₀ NumSlots mem P k nodes snAge) :
    let inp := mkStepInput n P op
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    ∃ (mem' : ArithRAMMemory) (P' : DynamicPointSet d) (opH : ℕ) (uMap' : GhostUidMap d P'),
      let aff : Fin (k + 1) → Bool := chainLevelAffected P P' nodes ins opH
      let snAge' : Fin k → ℕ := fun r => if aff r.castSucc then snAge r + 1 else snAge r
      DetExecAt 0 inp (routeLiveUpdateStmt d n K D₀ NumSlots M_box) mem mem'
        (routeLiveUpdateCost d K D₀ NumSlots) ∧
      mem'.popDepth 0 = mem' ∧
      applyDynamicUpdate P op (readStepRetH op mem') = some P' ∧
      P'.WellFormed n ∧
      EncServingChain d n K D₀ NumSlots mem' P' k nodes snAge' ∧
      opH < n ∧ opH < 2 ^ K ∧
      wRead mem' 26 4 = (opH : ℤ) ∧
      wRead mem' 26 5 = (if ins then 1 else 0) ∧
      uMap.nextUid ≤ uMap'.nextUid ∧
      (∀ u < uMap.nextUid, uMap'.ghostCoords u = uMap.ghostCoords u) ∧
      IsInputChange P.activeHandles P'.activeHandles ∧
      (∀ h ∈ P.activeHandles, h ∈ P'.activeHandles → P'.handleCoords h = P.handleCoords h) ∧
      (∀ h ∈ P.activeHandles, h ≠ opH → h ∈ P'.activeHandles ∧ P'.handleCoords h = P.handleCoords h) ∧
      (∀ r : Fin k,
        let S_pre_h := chainInput P.handleCoords nodes P.activeHandles r.castSucc
        let S_post_h := chainInput P'.handleCoords nodes P'.activeHandles r.castSucc
        let S_pre_u := chainInput uMap.ghostCoords nodes uMap.ActiveUids r.castSucc
        let S_post_u := chainInput uMap'.ghostCoords nodes uMap'.ActiveUids r.castSucc
        wRead mem' 20 (r.val : ℤ) = (if aff r.castSucc then 1 else 0) ∧
        (aff r.castSucc = false →
          opH ∉ S_pre_h ∧ opH ∉ S_post_h ∧ S_post_h = S_pre_h ∧ S_post_u = S_pre_u) ∧
        (aff r.castSucc = true →
          IsInputChange S_pre_h S_post_h ∧
          IsInputChange S_pre_u S_post_u ∧
          (ins = true → opH ∉ S_pre_h ∧ S_post_h = insert opH S_pre_h) ∧
          (ins = false → opH ∈ S_pre_h ∧ S_post_h = S_pre_h.erase opH) ∧
          (∃ ev_r : PoolUpdateEvent ℕ,
            ev_r.isClockTick = true ∧
            IsValidPoolUpdateEvent S_pre_u S_post_u ev_r)) ∧
        (∀ (P₀ : Finset ℕ) (trAge : ℕ),
          trAge ≤ snAge r →
          HasNodeAge P₀ S_pre_u trAge →
          ∃ trAge' ≤ snAge' r, HasNodeAge P₀ S_post_u trAge')) ∧
      (∀ s < NumSlots, 1 ≤ wRead mem 6 (s : ℤ) → ∀ S snapPts,
        EncSlotCoords d n mem P.activeHandles P.handleCoords s S snapPts →
        EncSlotCoords d n mem' P'.activeHandles P'.handleCoords s S snapPts) ∧
      (∀ s' < NumSlots,
        s' ≠ 0 → s' ≠ (wRead mem 1 6).toNat → (∀ r : Fin k, s' ∉ snSlotSet mem r.val) →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K mem' s' S₁ fSq₁) ∧
      (∀ t, t ≠ 0 → t ≠ 1 → t ≠ 2 → t ≠ 3 → t ≠ 8 → t ≠ 9 → t ≠ 10 →
            t ≠ 11 → t ≠ 13 → t ≠ 20 → t ≠ 26 →
        ∀ idx, wRead mem' t idx = wRead mem t idx) ∧
      (∀ idx, idx ≠ 0 → wRead mem' 0 idx = wRead mem 0 idx) ∧
      (∀ idx, idx ≠ 0 → idx ≠ 1 → idx ≠ 2 → wRead mem' 1 idx = wRead mem 1 idx) ∧
      (∀ idx, (idx < 0 ∨ (k : ℤ) ≤ idx) → wRead mem' 13 idx = wRead mem 13 idx) ∧
      (∀ t, t ≠ 4 → t ≠ 8 → t ≠ 11 → t ≠ 26 →
        ∀ idx, rRead mem' t idx = rRead mem t idx) := by
  intro inp ins
  rcases exec_routeLiveUpdateStmt P op mem hP hleg hBox hChain
    with ⟨mem', P', opH, hex, hpop, happ, hWF', hChain', hopH_n, hopH_K,
          hw26_4, hw26_5, hPerNode, hmatch, hSnap, hOtherSeg,
          hw_o, hw0_o, hw1_o, hw13_o, hr_o⟩
  let aff : Fin (k + 1) → Bool := chainLevelAffected P P' nodes ins opH
  let snAge' : Fin k → ℕ := fun r => if aff r.castSucc then snAge r + 1 else snAge r
  cases op with
  | insert id _ pt =>
      rcases hmatch with ⟨_, hnot_opH, hact_ins, hpt_opH, hpres_ins⟩
      let uMap' : GhostUidMap d P' := uMap.stepInsert hnot_opH hact_ins hpt_opH hpres_ins
      rcases uMap.stepInsert_props hnot_opH hact_ins hpt_opH hpres_ins
        with ⟨hle_uid, hag_uid, hmap_ins⟩
      have hchg_root : IsInputChange P.activeHandles P'.activeHandles := by
        unfold IsInputChange; left; refine ⟨opH, hnot_opH, ?_⟩; ext x; simp [hact_ins]
      have hcoords_root : ∀ h ∈ P.activeHandles, h ∈ P'.activeHandles → P'.handleCoords h = P.handleCoords h :=
        fun h hh _ => hpres_ins h hh
      have hcoords_ne : ∀ h ∈ P.activeHandles, h ≠ opH → h ∈ P'.activeHandles ∧ P'.handleCoords h = P.handleCoords h := by
        intro h hh _
        exact ⟨by rw [hact_ins]; exact Finset.mem_insert_of_mem hh, hpres_ins h hh⟩
      refine ⟨mem', P', opH, uMap', hex, hpop, happ, hWF', hChain', hopH_n, hopH_K,
        hw26_4, hw26_5, hle_uid, hag_uid, hchg_root, hcoords_root, hcoords_ne, ?_,
        hSnap, hOtherSeg, hw_o, hw0_o, hw1_o, hw13_o, hr_o⟩
      intro r
      let S_pre_h := chainInput P.handleCoords nodes P.activeHandles r.castSucc
      let S_post_h := chainInput P'.handleCoords nodes P'.activeHandles r.castSucc
      let S_pre_u := chainInput uMap.ghostCoords nodes uMap.ActiveUids r.castSucc
      let S_post_u := chainInput uMap'.ghostCoords nodes uMap'.ActiveUids r.castSucc
      have hsub_pre : S_pre_h ⊆ P.activeHandles :=
        cg01_chainInput_subset P.handleCoords nodes P.activeHandles r.castSucc
      have hmap_pre : uMap.mapSet S_pre_h = S_pre_u :=
        uMap.mapSet_chainInput nodes r.castSucc
      have hmap_post : uMap'.mapSet S_post_h = S_post_u :=
        uMap'.mapSet_chainInput nodes r.castSucc
      rcases hPerNode r with ⟨hw20_r, haff_f, haff_t⟩
      rcases hmap_ins S_pre_h hsub_pre with ⟨hmap_unch, hev_ins, hchg_ins_u⟩
      have h0_u : aff r.castSucc = false → S_post_u = S_pre_u := by
        intro hf
        have hSh_eq : S_post_h = S_pre_h := (haff_f hf).2.2
        rw [← hmap_post, hSh_eq, hmap_unch, hmap_pre]
      have h1_u : aff r.castSucc = true →
          IsInputChange S_pre_u S_post_u ∧
          IsValidPoolUpdateEvent S_pre_u S_post_u (.externalInsert uMap.nextUid) := by
        intro ht
        have hSh_ins : S_post_h = insert opH S_pre_h := ((haff_t ht).2.1 rfl).2
        have hpost_eq : S_post_u = uMap'.mapSet (insert opH S_pre_h) := by
          rw [← hmap_post, hSh_ins]
        rw [← hmap_pre, hpost_eq]
        exact ⟨hchg_ins_u, hev_ins⟩
      refine ⟨hw20_r,
        fun hf => ⟨(haff_f hf).1, (haff_f hf).2.1, (haff_f hf).2.2, h0_u hf⟩,
        fun ht => ⟨(haff_t ht).1, (h1_u ht).1, (haff_t ht).2.1, (haff_t ht).2.2,
          ⟨.externalInsert uMap.nextUid, rfl, (h1_u ht).2⟩⟩,
        ?_⟩
      intro P₀ trAge htr_le hage_pre
      rcases cg02_hasNodeAge_opt_step (aff := aff r.castSucc) hage_pre h0_u (fun ht => (h1_u ht).1)
        with ⟨trAge', htr'_le, hage_post⟩
      refine ⟨trAge', ?_, hage_post⟩
      change trAge' ≤ if aff r.castSucc = true then snAge r + 1 else snAge r
      cases hb : aff r.castSucc <;> simp [hb] at htr'_le ⊢ <;> omega
  | delete id =>
      rcases hmatch with ⟨_, hin_opH, hact_del, hpres_del⟩
      let uMap' : GhostUidMap d P' := uMap.stepDelete hin_opH hact_del hpres_del
      rcases uMap.stepDelete_props hin_opH hact_del hpres_del
        with ⟨hle_uid, hag_uid, hmap_del⟩
      have hchg_root : IsInputChange P.activeHandles P'.activeHandles := by
        unfold IsInputChange; right; refine ⟨opH, hin_opH, ?_⟩; ext x; simp [hact_del]
      have hcoords_root : ∀ h ∈ P.activeHandles, h ∈ P'.activeHandles → P'.handleCoords h = P.handleCoords h :=
        fun h _ hh' => hpres_del h hh'
      have hcoords_ne : ∀ h ∈ P.activeHandles, h ≠ opH → h ∈ P'.activeHandles ∧ P'.handleCoords h = P.handleCoords h := by
        intro h hh hne
        have hh' : h ∈ P'.activeHandles := by
          rw [hact_del]; exact Finset.mem_erase.mpr ⟨hne, hh⟩
        exact ⟨hh', hpres_del h hh'⟩
      refine ⟨mem', P', opH, uMap', hex, hpop, happ, hWF', hChain', hopH_n, hopH_K,
        hw26_4, hw26_5, hle_uid, hag_uid, hchg_root, hcoords_root, hcoords_ne, ?_,
        hSnap, hOtherSeg, hw_o, hw0_o, hw1_o, hw13_o, hr_o⟩
      intro r
      let S_pre_h := chainInput P.handleCoords nodes P.activeHandles r.castSucc
      let S_post_h := chainInput P'.handleCoords nodes P'.activeHandles r.castSucc
      let S_pre_u := chainInput uMap.ghostCoords nodes uMap.ActiveUids r.castSucc
      let S_post_u := chainInput uMap'.ghostCoords nodes uMap'.ActiveUids r.castSucc
      have hsub_pre : S_pre_h ⊆ P.activeHandles :=
        cg01_chainInput_subset P.handleCoords nodes P.activeHandles r.castSucc
      have hmap_pre : uMap.mapSet S_pre_h = S_pre_u :=
        uMap.mapSet_chainInput nodes r.castSucc
      have hmap_post : uMap'.mapSet S_post_h = S_post_u :=
        uMap'.mapSet_chainInput nodes r.castSucc
      rcases hPerNode r with ⟨hw20_r, haff_f, haff_t⟩
      rcases hmap_del S_pre_h hsub_pre with ⟨hmap_not, hmap_in⟩
      have h0_u : aff r.castSucc = false → S_post_u = S_pre_u := by
        intro hf
        have hnot_pre : opH ∉ S_pre_h := (haff_f hf).1
        have hSh_eq : S_post_h = S_pre_h := (haff_f hf).2.2
        rw [← hmap_post, hSh_eq, hmap_not hnot_pre, hmap_pre]
      have h1_u : aff r.castSucc = true →
          IsInputChange S_pre_u S_post_u ∧
          IsValidPoolUpdateEvent S_pre_u S_post_u (.externalDelete (uMap.uidOfH opH)) := by
        intro ht
        have hin_pre : opH ∈ S_pre_h := ((haff_t ht).2.2 rfl).1
        have hSh_del : S_post_h = S_pre_h.erase opH := ((haff_t ht).2.2 rfl).2
        rcases hmap_in hin_pre with ⟨hev_del, hchg_del_u⟩
        have hpost_eq : S_post_u = uMap'.mapSet (S_pre_h.erase opH) := by
          rw [← hmap_post, hSh_del]
        rw [← hmap_pre, hpost_eq]
        exact ⟨hchg_del_u, hev_del⟩
      refine ⟨hw20_r,
        fun hf => ⟨(haff_f hf).1, (haff_f hf).2.1, (haff_f hf).2.2, h0_u hf⟩,
        fun ht => ⟨(haff_t ht).1, (h1_u ht).1, (haff_t ht).2.1, (haff_t ht).2.2,
          ⟨.externalDelete (uMap.uidOfH opH), rfl, (h1_u ht).2⟩⟩,
        ?_⟩
      intro P₀ trAge htr_le hage_pre
      rcases cg02_hasNodeAge_opt_step (aff := aff r.castSucc) hage_pre h0_u (fun ht => (h1_u ht).1)
        with ⟨trAge', htr'_le, hage_post⟩
      refine ⟨trAge', ?_, hage_post⟩
      change trAge' ≤ if aff r.castSucc = true then snAge r + 1 else snAge r
      cases hb : aff r.castSucc <;> simp [hb] at htr'_le ⊢ <;> omega

/-! ### 3. Universal Polynomial Cost & Space Bounds for `P46ParamsValid` -/

def p46BoxPolyConst (cHpj : ℕ) : ℕ :=
  28 * (10090 + cHpj * 21 ^ 3)

theorem P46ParamsValid.box_poly_le
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    28 * p46BoxSize d n p ≤ p46BoxPolyConst cHpj * n * (D ^ 19 * H ^ 18) := by
  intro D H
  have hD_p : p.D = D := hp.hD_eq
  have hH_p : p.H = H := hp.hH_eq
  have hD3 : 3 ≤ D := by rw [← hD_p]; exact hp.hD3
  have hH5 : 5 ≤ H := by rw [← hH_p]; exact hp.hH5
  have hD0 : p.D₀ = 24 * D ^ 2 * H := by
    have h := hp.hD0; rw [hH_p] at h; exact h
  have hmD : p.P_hpj.m * D ≤ (cHpj * 21 ^ 3) * D ^ 7 * H ^ 6 := by
    have h := hp.hmD_le; rw [hH_p] at h; exact h
  have h1 := p46BoxSize_poly_le (D := D) (H := H) (cHpj := cHpj) p hn rfl hD3 hH5
    hD0 hp.hSlots hp.hPhp_props hmD
  calc 28 * p46BoxSize d n p
      ≤ 28 * ((10090 + cHpj * 21 ^ 3) * n * (D ^ 19 * H ^ 18)) := Nat.mul_le_mul_left 28 h1
    _ = p46BoxPolyConst cHpj * n * (D ^ 19 * H ^ 18) := by unfold p46BoxPolyConst; ring

theorem P46ParamsValid.all_component_costs_poly_le
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    let C_hpj0 := cHpj * 21 ^ 3
    let C_mb := 105 + cHpj + 4 * cBase
    let C_L := 68719476736 + 8 * (84 * cBase)
    let P19 := D ^ 19 * H ^ 18
    1 ≤ P19 ∧
    D * H ≤ P19 ∧
    D ^ 2 * H ≤ P19 ∧
    D ^ 5 * H ^ 3 ≤ P19 ∧
    routeLiveUpdateCost d p.K_seg p.D₀ p.NumSlots ≤ 1050000 * P19 ∧
    (p.D₀ + 20 * D ^ 2 + 2) * hpjCallCost d n p ≤
      (46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
        16 * (C_hpj0 * (C_mb + 1)) + 500)) * P19 ∧
    (p.D₀ + 2) * baselineCallCost d n p ≤
      (26 * (250 * (84 * cBase + 1) * (C_mb + 4) + 500)) * P19 ∧
    (350 * (4 * p.L + 5) * (4 * p.L + 5) * (p.K_seg + d + 5) + 500) ≤
      (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3 + 500) * P19 ∧
    (p.D₀ + 2) * (p.D₀ + 2) * (2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5)) ≤
      (625 * (2400 * 16777218 * 3 + 15000)) * P19 ∧
    (4 * p.D₀ + 80 * D ^ 2 + 20) *
        (40 * p.NumSlots + 300 * (p.D₀ + 1) * (p.D₀ + 1) + 35 * (p.NumSlots + 1) + 500) ≤
      (196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * P19 := by
  intro D H C_hpj0 C_mb C_L P19
  have hD_p : p.D = D := hp.hD_eq
  have hH_p : p.H = H := hp.hH_eq
  have hD3 : 3 ≤ D := by rw [← hD_p]; exact hp.hD3
  have hH5 : 5 ≤ H := by rw [← hH_p]; exact hp.hH5
  have hD1 : 1 ≤ D := by omega
  have hH1 : 1 ≤ H := by omega
  have hK_le : p.K_seg ≤ H := by rw [← hH_p]; exact hp.hK_le_H
  have hD0 : p.D₀ = 24 * D ^ 2 * H := by have h := hp.hD0; rw [hH_p] at h; exact h
  have hkφ : p.k_φ = 20 * H := by have h := hp.hkφ; rw [hH_p] at h; exact h
  have hK0 : p.K₀ ≤ 84 * cBase * D ^ 2 * H := by have h := hp.hK0_le; rw [hH_p] at h; exact h
  have hOp : Nat.ceil (hpjOpBound d p.φ_ev) ≤ (cHpj * 21 ^ 3) * D ^ 7 * H ^ 6 := by
    have h := hp.hOpCeil; rw [hH_p] at h; exact h
  have hmD : p.P_hpj.m * D ≤ (cHpj * 21 ^ 3) * D ^ 7 * H ^ 6 := by
    have h := hp.hmD_le; rw [hH_p] at h; exact h
  have hMb : p.M_bits ≤ (105 + cHpj + 4 * cBase) * H := by
    have h := hp.hMbits_le; rw [hH_p] at h; exact h
  have hL : p.L = (68719476736 + 8 * (84 * cBase)) * D ^ 4 * H ^ 2 := by
    have h := hp.hL_eq; rw [hH_p] at h; exact h
  rcases p46_route_poly_cost_and_box hn rfl hD3 hH5 hK_le hp.h2K_lt_2n hD0 hp.hSlots
    with ⟨_, hRoute19, _, _⟩
  rcases p46_component_costs_poly_le (D := D) (H := H) (cBase := cBase) (cHpj := cHpj) p
    rfl hD3 hH5 hK_le hD0 hkφ hK0 hp.hPhp_props hOp hmD hMb hL hp.hBscan hp.hKbatch hp.hSlots hp.hBhpj
    with ⟨_, _, _, hHpjTot, hBaseTot, hLeafTot, hJobTot, hGCTot⟩
  refine ⟨one_le_target hD1 hH1,
    by simpa using pow_mul_pow_le_target hD1 hH1 (by decide : 1 ≤ 19) (by decide : 1 ≤ 18),
    by simpa using pow_mul_pow_le_target hD1 hH1 (by decide : 2 ≤ 19) (by decide : 1 ≤ 18),
    pow_mul_pow_le_target hD1 hH1 (by decide : 5 ≤ 19) (by decide : 3 ≤ 18),
    ?_, hHpjTot, hBaseTot, hLeafTot, hJobTot, hGCTot⟩
  calc routeLiveUpdateCost d p.K_seg p.D₀ p.NumSlots
      ≤ 1050000 * D ^ 19 * H ^ 18 := hRoute19
    _ = 1050000 * P19 := by ring

end UL.Proof_lem_7_2_RacerP46
