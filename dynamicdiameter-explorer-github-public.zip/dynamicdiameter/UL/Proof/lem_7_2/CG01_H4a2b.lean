import UL.Proof.lem_7_2.CG01_H4a2a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 3. Pure Ghost History Wrapper `ActiveJobGhost` for `S_lem_C_2` -/

/-- Encapsulated ghost history of one active pending replacement job on root pool `S_cur_uid`
(in monotone UID space `< nextUid`). Completely isolates `S_lem_C_2`, `ScheduleTickPass`,
and `two_phase_job_build_ready` from RAM execution! -/
structure ActiveJobGhost (d n D L B_scan nextUid : ℕ)
    (ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S_cur_uid : Finset ℕ) : Type where
  H_job : ℕ
  t_cur : ℕ
  closed : Bool
  lvs : List (OpenedJobLevel d ℕ)
  openRem : ℕ → ℕ
  ph_cur : ℕ
  scan_cur : ℕ
  Spar_last_h : Finset ℕ
  hH_pos : 1 ≤ H_job
  ht_le : t_cur ≤ H_job
  hlvs_pos : 1 ≤ lvs.length
  hph_le : ph_cur ≤ 2
  hprev_ready : ∀ (j : ℕ) (hj : j + 1 < lvs.length),
    (lvs[j]'(Nat.lt_of_succ_lt hj)).backgroundReady = true
  hlast_ready :
    (lvs[lvs.length - 1]'(Nat.sub_lt hlvs_pos Nat.one_pos)).backgroundReady = decide (ph_cur = 2)
  S_root : ℕ → Finset ℕ
  ev : ℕ → PoolUpdateEvent ℕ
  job_hist : ℕ → PendingReplacementJob d ℕ
  hS_cap : ∀ s ≤ t_cur, (S_root s).card ≤ n
  hS_uid : ∀ s ≤ t_cur, ∀ u ∈ S_root s, u < nextUid
  hS_last : S_root t_cur = S_cur_uid
  hm0 : 4 * L < (S_root 0).card
  hH_eq : H_job = jobDeadlineTicks (1 / (4 * (D : ℝ) ^ 2)) (S_root 0).card
  hev_tick : ∀ t < t_cur, (ev t).isClockTick = true
  hev_valid : ∀ t < t_cur, IsValidPoolUpdateEvent (S_root t) (S_root (t + 1)) (ev t)
  hinit : ScheduleTickPass (1 / (4 * (D : ℝ) ^ 2)) L ghostCoords
    (initPendingJob (1 / (4 * (D : ℝ) ^ 2)) (S_root 0)) (job_hist 0)
  hstep : ∀ t < t_cur,
    ScheduleTickPass (1 / (4 * (D : ℝ) ^ 2)) L ghostCoords
      (updatePendingJobRootPool ghostCoords (job_hist t) (ev t) (S_root (t + 1))) (job_hist (t + 1))
  hrem_eq : ∀ s ≤ t_cur,
    (job_hist s).remainingTicks = H_job - s ∧ (job_hist s).deadlineTicks = H_job
  hcur_job : job_hist t_cur =
    { deadlineTicks := H_job
      remainingTicks := H_job - t_cur
      completedPrefix := lvs
      currentResidual := prefixResidual ghostCoords lvs S_cur_uid
      closedAsLeaf := closed }
  hlvs_inv : ∀ (j : ℕ) (hj : j < lvs.length),
    let lv := lvs[j]'hj
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    2 * L + 1 < lv.birthSnapshot.card ∧
    (∀ u ∈ lv.birthSnapshot, u < nextUid) ∧
    PassesBirthCoreCheck α ghostCoords lv.ball lv.birthSnapshot ∧
    ∃ (s_open : ℕ),
      s_open ≤ t_cur ∧
      openRem j = H_job - s_open ∧
      CanOpenResidualLevel α (openRem j) lv.birthSnapshot.card ∧
      (∃ (age_j : ℕ), age_j ≤ t_cur - s_open ∧
        HasNodeAge lv.birthSnapshot (prefixResidual ghostCoords (lvs.take j) S_cur_uid) age_j) ∧
      (∀ s < s_open, (job_hist s).completedPrefix[j]? = none) ∧
      (∃ (ph_tr cur_tr : ℕ → ℕ) (Spar_tr : ℕ → Finset ℕ),
        ph_tr 0 = 0 ∧ cur_tr 0 = 0 ∧ (Spar_tr 0).card = lv.birthSnapshot.card ∧
        (∀ τ < t_cur - s_open,
          ((Spar_tr (τ + 1)).card ≤ (Spar_tr τ).card + 1 ∧
            ∀ c : ℕ, ((Spar_tr (τ + 1)).filter (fun x => c ≤ x)).card ≤
                     ((Spar_tr τ).filter (fun x => c ≤ x)).card + 1) ∧
          (ph_tr τ = 0 →
            (cur_tr τ + (B_scan + 1) < lv.birthSnapshot.card →
              ph_tr (τ + 1) = 0 ∧ cur_tr (τ + 1) = cur_tr τ + (B_scan + 1)) ∧
            (lv.birthSnapshot.card ≤ cur_tr τ + (B_scan + 1) →
              ph_tr (τ + 1) = 1 ∧ cur_tr (τ + 1) = 0)) ∧
          (ph_tr τ = 1 →
            ph_tr (τ + 1) = 2 ∨
            (ph_tr (τ + 1) = 1 ∧
              ((Spar_tr (τ + 1)).filter (fun x => cur_tr (τ + 1) ≤ x)).card + B_scan ≤
                ((Spar_tr τ).filter (fun x => cur_tr τ ≤ x)).card)) ∧
          (ph_tr τ = 2 → ph_tr (τ + 1) = 2)) ∧
        (∀ s : ℕ, s_open ≤ s → s ≤ t_cur →
          ∃ lv_s : OpenedJobLevel d ℕ,
            (job_hist s).completedPrefix[j]? = some lv_s ∧
            lv_s.birthSnapshot = lv.birthSnapshot ∧
            lv_s.ball = lv.ball ∧
            lv_s.backgroundReady = decide (ph_tr (s - s_open) = 2)) ∧
        (j = lvs.length - 1 →
          ph_tr (t_cur - s_open) = ph_cur ∧
          cur_tr (t_cur - s_open) = scan_cur ∧
          Spar_tr (t_cur - s_open) = Spar_last_h))

/-- Every active pending job has `lvs.length < 24 * (d + 3)^2 * H = D₀` at EVERY tick! -/
theorem ActiveJobGhost.lvs_length_lt {d n H L B_scan nextUid : ℕ}
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)} {S_cur_uid : Finset ℕ}
    (hH : 5 ≤ H) (hn2 : n < 2 ^ H)
    (g : ActiveJobGhost d n (d + 3) L B_scan nextUid ghostCoords S_cur_uid) :
    g.lvs.length < 24 * (d + 3) ^ 2 * H := by
  have hD : 3 ≤ d + 3 := by omega
  have hL0 : 68719476736 * (d + 3) ^ 4 ≤ max L (68719476736 * (d + 3) ^ 4) := le_max_right _ _
  have hS_cap : S_cur_uid.card ≤ n := g.hS_last ▸ g.hS_cap g.t_cur le_rfl
  let k := g.lvs.length
  let nodes : Fin k → ChainNode d := fun i => (g.lvs[i.val]'i.isLt).ball
  let P₀ : Fin k → Finset ℕ := fun i => (g.lvs[i.val]'i.isLt).birthSnapshot
  have hvalid_ex : ∀ i : Fin k,
      ∃ age_i : ℕ,
        let α := 1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)
        2 ≤ (P₀ i).card ∧
        PassesBirthCoreCheck α ghostCoords (nodes i) (P₀ i) ∧
        HasNodeAge (P₀ i) (chainInput ghostCoords nodes S_cur_uid i.castSucc) age_i ∧
        (age_i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16 := by
    intro i
    rcases g.hlvs_inv i.val i.isLt with ⟨hlarge, _, hpass, s_open, _, hrem_eq, hcan, ⟨age_j, hage_le, hage⟩, _⟩
    refine ⟨age_j, by dsimp [P₀]; omega, hpass, ?_, ?_⟩
    · rwa [prefixResidual_eq_chainInput ghostCoords g.lvs S_cur_uid i.val (le_of_lt i.isLt)] at hage
    · have hop_le : age_j ≤ g.openRem i.val := by have := g.ht_le; omega
      have hcan_real : ((g.openRem i.val : ℕ) : ℝ) ≤
          (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) * ((P₀ i).card : ℝ) / 4096 := hcan
      have h1 : (age_j : ℝ) ≤ (g.openRem i.val : ℝ) := by exact_mod_cast hop_le
      have hpos : 0 ≤ (1 / (4 * ((d + 3 : ℕ) : ℝ) ^ 2)) * ((P₀ i).card : ℝ) := by positivity
      linarith
  choose age_fn hage_fn using hvalid_ex
  exact unconditional_chain_len_lt hH hn2 ghostCoords S_cur_uid hS_cap nodes P₀ age_fn hage_fn

/-- Operation 1: Start a fresh `ActiveJobGhost` at `t_cur = 0` when `4 * L < S_0_uid.card`,
immediately opening `lv_0`! -/
noncomputable def ActiveJobGhost.start {d n D L B_scan nextUid : ℕ}
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {S_0_uid : Finset ℕ} {Spar_0_h : Finset ℕ}
    {bUid : ℕ} (res : SampledCenterResult d)
    (hD : 3 ≤ D) (hL : 68719476736 * D ^ 4 ≤ L)
    (hcap : S_0_uid.card ≤ n)
    (huid : ∀ u ∈ S_0_uid, u < nextUid)
    (hm0 : 4 * L < S_0_uid.card)
    (hb : bUid ∈ S_0_uid)
    (hcard_eq : Spar_0_h.card = S_0_uid.card) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    let ball_0 := selectOpenedLevelBall α ghostCoords S_0_uid bUid res
    let H_job := jobDeadlineTicks α S_0_uid.card
    let lv_0 : OpenedJobLevel d ℕ :=
      { birthSnapshot := S_0_uid, ball := ball_0, indexMode := .radiusDictOnly, backgroundReady := false }
    ActiveJobGhost d n D L B_scan nextUid ghostCoords S_0_uid :=
  let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
  let ball_0 := selectOpenedLevelBall α ghostCoords S_0_uid bUid res
  let H_job := jobDeadlineTicks α S_0_uid.card
  let lv_0 : OpenedJobLevel d ℕ :=
    { birthSnapshot := S_0_uid, ball := ball_0, indexMode := .radiusDictOnly, backgroundReady := false }
  let j0 := openLargeLevelInJob ghostCoords (initPendingJob α S_0_uid) ball_0 .radiusDictOnly
  have hprops := job_start_open_props hD hL hm0
  have hα2 : α ≤ 2 := by have := (alpha_pos_and_lt_half D hD).2.1; linarith
  have hpass0 : PassesBirthCoreCheck α ghostCoords ball_0 S_0_uid :=
    passesBirthCoreCheck_selectOpenedLevelBall hα2 ghostCoords S_0_uid hb res
  have hgate0 : JobGateStep α L ghostCoords (initPendingJob α S_0_uid) j0 :=
    ⟨rfl, fun _ h => by simp [initPendingJob] at h, hprops.2.1,
     Or.inr ⟨hprops.2.2, res, ball_0, .radiusDictOnly,
       isValidOpenedLevelBall_selectOpenedLevelBall α ghostCoords hb res, rfl⟩⟩
  have hquies0 : IsJobTickQuiescent α j0 :=
    Or.inr (Or.inl ⟨lv_0, by simp [j0, openLargeLevelInJob, initPendingJob, lv_0], rfl⟩)
  { H_job := H_job
    t_cur := 0
    closed := false
    lvs := [lv_0]
    openRem := fun _ => H_job
    ph_cur := 0
    scan_cur := 0
    Spar_last_h := Spar_0_h
    hH_pos := hprops.1
    ht_le := Nat.zero_le _
    hlvs_pos := by simp
    hph_le := by omega
    hprev_ready := fun j hj => by simp at hj
    hlast_ready := by simp [lv_0]
    S_root := fun _ => S_0_uid
    ev := fun _ => .unaffected
    job_hist := fun _ => j0
    hS_cap := fun _ _ => hcap
    hS_uid := fun _ _ => huid
    hS_last := rfl
    hm0 := hm0
    hH_eq := rfl
    hev_tick := fun _ ht => by omega
    hev_valid := fun _ ht => by omega
    hinit := ⟨JobWithinTickChain.gate hgate0 (.refl j0), hquies0⟩
    hstep := fun _ ht => by omega
    hrem_eq := fun s hs => by
      have hs0 : s = 0 := by omega
      subst hs0; simp [j0, openLargeLevelInJob, initPendingJob, H_job]
    hcur_job := by dsimp [j0, openLargeLevelInJob, initPendingJob, H_job, lv_0]; rw [prefixResidual_cons, prefixResidual_nil]
    hlvs_inv := fun j hj => by
      have hj0 : j = 0 := by simp at hj; exact hj
      subst hj0
      simp only [List.getElem_cons_zero]
      refine ⟨by dsimp [lv_0]; exact hprops.2.2, huid, hpass0, 0, le_rfl, Nat.sub_zero H_job, hprops.2.1,
        ⟨0, le_rfl, by rw [List.take_zero, prefixResidual_nil]; exact hasNodeAge_zero S_0_uid⟩,
        fun _ hs => by omega,
        ⟨fun _ => 0, fun _ => 0, fun _ => Spar_0_h, rfl, rfl, hcard_eq,
          fun _ hτ => by omega,
          fun s _ hs0 => by
            have hs_eq : s = 0 := by omega
            subst hs_eq
            exact ⟨lv_0, by simp [j0, openLargeLevelInJob, initPendingJob, lv_0], rfl, rfl, rfl⟩,
          fun _ => ⟨rfl, rfl, rfl⟩⟩⟩ }

/-- Operation 2: Lift `ActiveJobGhost` across a monotone `ghostCoords → ghostCoords'` extension
(agreeing on all `u < nextUid`, with `nextUid ≤ nextUid'`), used on unaffected steps (`tickFlag = 0`)
or before applying a clock tick! -/
noncomputable def ActiveJobGhost.liftCoords {d n D L B_scan nextUid nextUid' : ℕ}
    {ghostCoords ghostCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {S_cur_uid : Finset ℕ}
    (g : ActiveJobGhost d n D L B_scan nextUid ghostCoords S_cur_uid)
    (hle_uid : nextUid ≤ nextUid')
    (hag : ∀ u < nextUid, ghostCoords' u = ghostCoords u) :
    ActiveJobGhost d n D L B_scan nextUid' ghostCoords' S_cur_uid :=
  have hon_root : ∀ s ≤ g.t_cur, ∀ u ∈ g.S_root s, ghostCoords' u = ghostCoords u :=
    fun s hs u hu => hag u (g.hS_uid s hs u hu)
  have hon_cur : ∀ u ∈ S_cur_uid, ghostCoords' u = ghostCoords u :=
    g.hS_last ▸ hon_root g.t_cur le_rfl
  { H_job := g.H_job
    t_cur := g.t_cur
    closed := g.closed
    lvs := g.lvs
    openRem := g.openRem
    ph_cur := g.ph_cur
    scan_cur := g.scan_cur
    Spar_last_h := g.Spar_last_h
    hH_pos := g.hH_pos
    ht_le := g.ht_le
    hlvs_pos := g.hlvs_pos
    hph_le := g.hph_le
    hprev_ready := g.hprev_ready
    hlast_ready := g.hlast_ready
    S_root := g.S_root
    ev := g.ev
    job_hist := g.job_hist
    hS_cap := g.hS_cap
    hS_uid := fun s hs u hu => lt_of_lt_of_le (g.hS_uid s hs u hu) hle_uid
    hS_last := g.hS_last
    hm0 := g.hm0
    hH_eq := g.hH_eq
    hev_tick := g.hev_tick
    hev_valid := g.hev_valid
    hinit := scheduleTickPass_congr_on _ L g.hinit (hon_root 0 (Nat.zero_le _))
    hstep := fun t ht => by
      have hupd_eq : updatePendingJobRootPool ghostCoords' (g.job_hist t) (g.ev t) (g.S_root (t + 1)) =
          updatePendingJobRootPool ghostCoords (g.job_hist t) (g.ev t) (g.S_root (t + 1)) := by
        unfold updatePendingJobRootPool
        rw [prefixResidual_congr_on _ (hon_root (t + 1) (Nat.succ_le_of_lt ht))]
      rw [hupd_eq]
      refine scheduleTickPass_congr_on _ L (g.hstep t ht) (fun x hx => ?_)
      have hsub := prefixResidual_subset ghostCoords (g.job_hist t).completedPrefix (g.S_root (t + 1)) hx
      exact hon_root (t + 1) (Nat.succ_le_of_lt ht) x hsub
    hrem_eq := g.hrem_eq
    hcur_job := by
      rw [prefixResidual_congr_on g.lvs hon_cur]
      exact g.hcur_job
    hlvs_inv := fun j hj => by
      rcases g.hlvs_inv j hj with ⟨hlarge, huid_b, hpass, s_open, hs_le, hrem_j, hcan,
        ⟨age_j, ha_le, hage⟩, hnone, tr_pack⟩
      refine ⟨hlarge,
        fun u hu => lt_of_lt_of_le (huid_b u hu) hle_uid,
        (passesBirthCoreCheck_congr_on _ _ (fun u hu => hag u (huid_b u hu))).mpr hpass,
        s_open, hs_le, hrem_j, hcan,
        ⟨age_j, ha_le, by rw [prefixResidual_congr_on (g.lvs.take j) hon_cur]; exact hage⟩,
        hnone, tr_pack⟩ }

/-- Choices taken at the end of a clock tick `t_cur → t_cur + 1` (after running `stepBuildJobLevelStmt`
to reach `(ph', scan', Spar_last_h')` on `lastIdx = g.lvs.length - 1`):
- `waitOrBuild`: job stays un-extended (`closed' = g.closed`, quiescent because `closed = true ∨ ph' < 2 ∨ ¬ CanOpen`);
- `closeLeaf`: `closed = false`, `ph' = 2`, `CanOpen`, `curRes'.card ≤ 2 * L + 1` → sets `closed' = true`;
- `openLevel`: `closed = false`, `ph' = 2`, `CanOpen`, `2 * L + 1 < curRes'.card` → appends `lv_new`! -/
inductive JobTickEndAction (d D L : ℕ) (ghostCoords' : ℕ → EuclideanSpace ℝ (Fin d))
    (rem' : ℕ) (closed : Bool) (ph' : ℕ) (curRes' : Finset ℕ) : Type
  | waitOrBuild
      (hq : closed = true ∨ ph' < 2 ∨
        ¬ CanOpenResidualLevel (1 / (4 * (D : ℝ) ^ 2)) rem' curRes'.card)
  | closeLeaf
      (hcl : closed = false)
      (hph2 : ph' = 2)
      (hcan : CanOpenResidualLevel (1 / (4 * (D : ℝ) ^ 2)) rem' curRes'.card)
      (hsmall : curRes'.card ≤ 2 * L + 1)
  | openLevel
      (hcl : closed = false)
      (hph2 : ph' = 2)
      (hcan : CanOpenResidualLevel (1 / (4 * (D : ℝ) ^ 2)) rem' curRes'.card)
      (hlarge : 2 * L + 1 < curRes'.card)
      (bUid : ℕ) (hb : bUid ∈ curRes')
      (res : SampledCenterResult d)
      (Spar_new_h : Finset ℕ)
      (hcard_new : Spar_new_h.card = curRes'.card)

/-- Resulting `(closed', lvs', openRem', ph_out, scan_out, Spar_out)` of `JobTickEndAction`. -/
noncomputable def applyJobTickEndAction {d D L : ℕ}
    {ghostCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {rem' : ℕ} {closed : Bool} {ph' : ℕ} {curRes' : Finset ℕ}
    (lvs_rdy : List (OpenedJobLevel d ℕ))
    (openRem : ℕ → ℕ) (scan' : ℕ) (Spar_last_h' : Finset ℕ)
    (act : JobTickEndAction d D L ghostCoords' rem' closed ph' curRes') :
    Bool × List (OpenedJobLevel d ℕ) × (ℕ → ℕ) × ℕ × ℕ × Finset ℕ :=
  match act with
  | .waitOrBuild _ => (closed, lvs_rdy, openRem, ph', scan', Spar_last_h')
  | .closeLeaf _ _ _ _ => (true, lvs_rdy, openRem, ph', scan', Spar_last_h')
  | .openLevel _ _ _ _ bUid _ res Spar_new_h _ =>
      let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
      let ball_new := selectOpenedLevelBall α ghostCoords' curRes' bUid res
      let lv_new : OpenedJobLevel d ℕ :=
        { birthSnapshot := curRes', ball := ball_new, indexMode := .radiusDictOnly, backgroundReady := false }
      (false, lvs_rdy ++ [lv_new], Function.update openRem lvs_rdy.length rem', 0, 0, Spar_new_h)


end UL.Proof_lem_7_2_RacerP46
