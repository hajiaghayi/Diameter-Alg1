import UL.Proof.lem_7_2.CG04_RouteRelA

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 5b. Affected Serving-Node Branch (`aff = true`) & Full Single-Iteration Step -/

/-- Affected active serving-node step (`r : Fin k` and `aff r.castSucc = true`). -/
theorem exec_routeOneServingNodeStmt_aff_rel {d n K D₀ NumSlots M_box k leafS opH : ℕ}
    (inp : ArithRAMInput d)
    {P P' : DynamicPointSet d} {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ} {idle : Fin k → Bool}
    {ins : Bool} {mem mA : ArithRAMMemory}
    (hCtx : RouteLoopCtxRel d n K D₀ NumSlots M_box k leafS opH P P' nodes snAge idle ins mem mA)
    (r : Fin k) (hi_D0 : r.val < D₀) {m : ArithRAMMemory}
    (hm : RouteLoopInvRel K NumSlots leafS opH P P' nodes snAge idle ins mem mA r.val m)
    (haff_c : chainLevelAffected P P' nodes ins opH r.castSucc = true) :
    ∃ m_next : ArithRAMMemory,
      DetExecAt 0 inp (routeOneServingNodeStmt d K M_box) m m_next (routeOneServingNodeCost d K) ∧
      RouteLoopInvRel K NumSlots leafS opH P P' nodes snAge idle ins mem mA (r.val + 1) m_next := by
  have hBox30 := hCtx.hBox.1
  have hBoxD0 := hCtx.hBox.2.1
  have hBox_seg := hCtx.hBox.2.2.2.2.2.2
  have hSlots2 := hCtx.hSlots2
  have hleaf_lt := hCtx.hleaf_lt
  have hopH_K := hCtx.hopH_K
  have hi_lt : r.val < k := r.isLt
  have hm_copy := hm
  rcases hm with ⟨hseg_m, hm26_4, hm26_5, hm26_7, hm26_9, hSeg0_m, hSegL_m,
                  hDone_m, hTodo_m, hRest_m, hw_m, hw13_m, hr_m⟩
  have hw15_m : wRead m 1 5 = (k : ℤ) := by
    rw [hw_m 1 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide), hCtx.hw15_A]
  have hsnSet_eq : ∀ r' : Fin k, snSlotSet m r'.val = snSlotSet mem r'.val := by
    intro r'; unfold snSlotSet
    rw [hw_m 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hw_m 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
        hCtx.hw14_A, hCtx.hw15_tbl_A]
  have hmin_i : min r.val k = r.val := Nat.min_eq_left (Nat.le_of_lt hi_lt)
  have hmin_succ : min (r.val + 1) k = r.val + 1 := Nat.min_eq_left (Nat.succ_le_of_lt hi_lt)
  have hcond_lt : cValAt 0 inp m (.intLt (.readHeap 26 (.lit 7)) (.readHeap 1 (.lit 5))) = true := by
    simp only [cValAt_intLt, iValAt_readHeap, iValAt_lit, hm26_7, hw15_m, decide_eq_true_eq]
    exact_mod_cast hi_lt
  rcases hTodo_m r le_rfl with ⟨dS, spS, hd0, hd_lt, hsp0, hsp_lt, hd_ne_sp,
    hw13_r, hw14_r, hw15_r, hw6_d, hw6_sp, hr12_r, hr13_r, hSeg_d, T_sp, hSeg_sp, hidle_sp⟩
  have hset_r : snSlotSet mem r.val = {dS, spS} := by
    rw [← hsnSet_eq r]
    exact EncServingNode.snSlotSet_eq (d := d) (K := K) (NumSlots := NumSlots)
      (livePts := P.handleCoords) (N := nodes r)
      (S_r := chainInput P.handleCoords nodes P.activeHandles r.castSucc) (age_r := snAge r) hw14_r hw15_r
  have hd_in_r : dS ∈ snSlotSet mem r.val := by rw [hset_r]; simp
  have hsp_in_r : spS ∈ snSlotSet mem r.val := by rw [hset_r]; simp
  have hd_ne0 : dS ≠ 0 := (hCtx.hdisj_0leaf r dS hd_in_r).1
  have hd_neL : dS ≠ leafS := (hCtx.hdisj_0leaf r dS hd_in_r).2
  have hsp_ne0 : spS ≠ 0 := (hCtx.hdisj_0leaf r spS hsp_in_r).1
  have hsp_neL : spS ≠ leafS := (hCtx.hdisj_0leaf r spS hsp_in_r).2
  rcases exec_routeOneServingNodeStmt_stepAB_rel inp hCtx r hi_D0 hm_copy hw14_r hSeg_d
    with ⟨m2, hSeqAB, hseg_m2, liftSeg_m2, hm2_8, hw26_m2, hm2_20_i, hm2_20_ne, hw_m2, hr_m2⟩
  have hc8 : cValAt 0 inp m2 (.intEq (.readHeap 26 (.lit 8)) (.lit 1)) = true := by
    simp [hm2_8, haff_c]
  -- 1. Increment `snAge[r]` in `wRead _ 13 r.val`
  let m3 := wWrite m2 13 (r.val : ℤ) ((snAge r + 1 : ℕ) : ℤ)
  have hb_age : DetExecAt 0 inp
      (boxWriteW M_box 13 (.readHeap 26 (.lit 7))
        (.add (.readHeap 13 (.readHeap 26 (.lit 7))) (.lit 1))) m2 m3 25 :=
    exec_boxWriteW inp m2 _ _
      (by simp [hw26_m2 7 (by decide), hm26_7])
      (by omega) (by have : r.val < M_box := lt_of_lt_of_le hi_D0 hBoxD0; exact_mod_cast this)
      (by simp [hw26_m2 7 (by decide), hm26_7, hw_m2 13 (by decide) (by decide), hw13_r])
      (by simp [intExprOps])
  -- 2. Set `26[3] := dS`, `26[6] := r.val * d`, and run `updSegCenterStmt d K M_box 12`
  let m4 := wWrite m3 26 3 (dS : ℤ)
  let m5 := wWrite m4 26 6 (((r.val * d : ℕ) : ℤ))
  have hb_s14 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 3) (.readHeap 14 (.readHeap 26 (.lit 7)))) m3 m4 20 :=
    exec_boxWriteW inp m3 _ _ rfl (by omega) (by omega)
      (by simp [m3, hw26_m2 7 (by decide), hm26_7, hw_m2 14 (by decide) (by decide), hw14_r])
      (by simp [intExprOps])
  have hb_ob : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 6) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ)))) m4 m5 20 :=
    exec_boxWriteW inp m4 _ _ rfl (by omega) (by omega)
      (by simp [m4, m3, hw26_m2 7 (by decide), hm26_7])
      (by simp [intExprOps])
  have hLive_m5 : EncLiveCoords d n m5 P'.activeHandles P'.handleCoords :=
    ⟨hCtx.hLive_A.1, fun h hh c => by
      simp only [m5, m4, m3, rRead_wWrite, hr_m2, hr_m 4 (by decide) (by decide)]
      exact hCtx.hLive_A.2 h hh c⟩
  have hseg_m5 : SegGenBound K NumSlots m5 :=
    ⟨by simp [m5, m4, m3]; exact hseg_m2.1,
     fun s hs => by simp [m5, m4, m3]; exact hseg_m2.2.1 s hs,
     fun s hs u hu => by simp [m5, m4, m3]; exact hseg_m2.2.2 s hs u hu⟩
  have liftSeg_m5 : ∀ s' < NumSlots, ∀ S₁ fSq₁, EncSegSlot K m s' S₁ fSq₁ → EncSegSlot K m5 s' S₁ fSq₁ := by
    intro s' hs' S₁ fSq₁ hE
    exact (liftSeg_m2 s' hs' S₁ fSq₁ hE).congr_mem_fSq
      (by simp [m5, m4, m3]) (fun _ _ => by simp [m5, m4, m3]) (fun _ _ => by simp [m5, m4, m3])
      (fun _ _ => by simp [m5, m4, m3]) (fun _ _ => by simp [m5, m4, m3]) (fun _ _ => rfl)
  rcases exec_updSegCenterStmt inp m5 (n := n) (NumSlots := NumSlots) (M_box := M_box) (rTag := 12)
      (s := dS) (h := opH) (oBase := r.val * d) (ins := ins) (o := (nodes r).o)
      (activeH := P'.activeHandles) (livePts := P.handleCoords) (livePts' := P'.handleCoords)
      (S := chainInput P.handleCoords nodes P.activeHandles r.castSucc)
      hd_lt hopH_K (by omega) hBox_seg ⟨by decide, by decide⟩
      (by simp [m5, m4])
      (by simp [m5, m4, m3, hw26_m2 4 (by decide), hm26_4])
      (by simp [m5, m4, m3, hw26_m2 5 (by decide), hm26_5])
      (by simp [m5])
      (fun c => by simp only [m5, m4, m3, rRead_wWrite, hr_m2]; exact hr12_r c)
      hLive_m5 hCtx.hh_act_ins
      (fun x hx hne => hCtx.hCoordsOther r.castSucc x hx hne)
      hseg_m5
      (liftSeg_m5 dS hd_lt _ _ hSeg_d)
    with ⟨m6, hb_uC, _, hseg_m6, hSeg_d6, hr26_0_m6, hOther_m6, hw_m6, hr_m6, _⟩
  -- 3. Set `26[3] := spS` and run `updSegZeroStmt K M_box`
  let m7 := wWrite m6 26 3 (spS : ℤ)
  have hb_s15 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 3) (.readHeap 15 (.readHeap 26 (.lit 7)))) m6 m7 20 :=
    exec_boxWriteW inp m6 _ _ rfl (by omega) (by omega)
      (by rw [iValAt_readHeap, iValAt_readHeap, iValAt_lit,
              hw_m6 26 (by decide) (by decide) (by decide),
              hw_m6 15 (by decide) (by decide) (by decide)]
          simp [m5, m4, m3, hw26_m2 7 (by decide), hm26_7, hw_m2 15 (by decide) (by decide), hw15_r])
      (by simp [intExprOps])
  have hseg_m7 : SegGenBound K NumSlots m7 :=
    ⟨by simp [m7]; exact hseg_m6.1,
     fun s hs => by simp [m7]; exact hseg_m6.2.1 s hs,
     fun s hs u hu => by simp [m7]; exact hseg_m6.2.2 s hs u hu⟩
  have hSeg_sp7 : EncSegSlot K m7 spS T_sp (fun _ => 0) :=
    (hOther_m6 spS hsp_lt hd_ne_sp.symm _ _ (liftSeg_m5 spS hsp_lt _ _ hSeg_sp)).congr_mem_fSq
      (by simp [m7]) (fun _ _ => by simp [m7]) (fun _ _ => by simp [m7])
      (fun _ _ => by simp [m7]) (fun _ _ => by simp [m7]) (fun _ _ => rfl)
  rcases exec_updSegZeroStmt inp m7 (NumSlots := NumSlots) (M_box := M_box)
      (s := spS) (h := opH) (ins := ins) (S := T_sp)
      hsp_lt hopH_K hBox_seg
      (by simp [m7])
      (by simp [m7, hw_m6 26 (by decide) (by decide) (by decide), m5, m4, m3, hw26_m2 4 (by decide), hm26_4])
      (by simp [m7, hw_m6 26 (by decide) (by decide) (by decide), m5, m4, m3, hw26_m2 5 (by decide), hm26_5])
      hseg_m7 hSeg_sp7
    with ⟨m8, hb_uZ, _, hseg_m8, hSeg_sp8, hOther_m8, hw_m8, hr_m8⟩
  have hSpost_eq :
      (if ins then insert opH (chainInput P.handleCoords nodes P.activeHandles r.castSucc)
              else (chainInput P.handleCoords nodes P.activeHandles r.castSucc).erase opH) =
      chainInput P'.handleCoords nodes P'.activeHandles r.castSucc := by
    have hT := (hCtx.hAffProps r.castSucc).2 haff_c
    cases hins_b : ins with
    | true => exact (hT.2.1 hins_b).2.symm
    | false => exact (hT.2.2 hins_b).2.symm
  have hSeg_d8 : EncSegSlot K m8 dS
      (chainInput P'.handleCoords nodes P'.activeHandles r.castSucc)
      (fun x => euclideanDistSq (P'.handleCoords x) (nodes r).o) := by
    rw [← hSpost_eq]
    exact hOther_m8 dS hd_lt hd_ne_sp _ _
      (hSeg_d6.congr_mem_fSq (by simp [m7]) (fun _ _ => by simp [m7]) (fun _ _ => by simp [m7])
        (fun _ _ => by simp [m7]) (fun _ _ => by simp [m7]) (fun _ _ => rfl))
  let T_sp' : Finset ℕ := if ins then insert opH T_sp else T_sp.erase opH
  have hSeg_sp8' : EncSegSlot K m8 spS T_sp' (fun _ => 0) := hSeg_sp8
  -- 4. Core-ball membership test on `ins == true`
  have hStepCore : ∃ m9 : ArithRAMMemory,
      DetExecAt 0 inp
        (.ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
          (.ite (.realLe (.readRealHeap 26 (.lit 0))
                         (.readRealHeap 13 (.readHeap 26 (.lit 7))))
            (boxWriteW M_box 26 (.lit 9) (.lit 0))
            (boxWriteW M_box 26 (.lit 9) (.lit 1)))
          .skip) m8 m9 45 ∧
      (ins = true → wRead m9 26 9 = (if chainLevelAffected P P' nodes ins opH r.succ then 1 else 0)) ∧
      (∀ t, t ≠ 26 → ∀ idx, wRead m9 t idx = wRead m8 t idx) ∧
      (∀ idx, idx ≠ 9 → wRead m9 26 idx = wRead m8 26 idx) ∧
      (∀ t idx, rRead m9 t idx = rRead m8 t idx) := by
    cases hins_c : ins with
    | false =>
        have hc5 : cValAt 0 inp m8 (.intEq (.readHeap 26 (.lit 5)) (.lit 1)) = false := by
          rw [cValAt_intEq, iValAt_readHeap, iValAt_lit,
              hw_m8 26 (by decide) (by decide) (by decide)]
          simp [m7, hw_m6 26 (by decide) (by decide) (by decide), m5, m4, m3,
                hw26_m2 5 (by decide), hm26_5, hins_c]
        exact ⟨m8,
          (DetExecAt.ite_false hc5 (C_c := 10) (by simp [condExprOps, intExprOps])
            (DetExecAt.skip 0 inp m8)).mono_cost (by omega),
          fun h => Bool.noConfusion h,
          fun _ _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl⟩
    | true =>
        have hc5 : cValAt 0 inp m8 (.intEq (.readHeap 26 (.lit 5)) (.lit 1)) = true := by
          rw [cValAt_intEq, iValAt_readHeap, iValAt_lit,
              hw_m8 26 (by decide) (by decide) (by decide)]
          simp [m7, hw_m6 26 (by decide) (by decide) (by decide), m5, m4, m3,
                hw26_m2 5 (by decide), hm26_5, hins_c]
        have hr0_m8 : rRead m8 26 0 = euclideanDistSq (P'.handleCoords opH) (nodes r).o := by
          rw [hr_m8 26 (by decide)]; simp [m7, hr26_0_m6 hins_c]
        have hr13_m8 : rRead m8 13 (wRead m8 26 7) = (nodes r).V := by
          have hw7_m8 : wRead m8 26 7 = (r.val : ℤ) := by
            rw [hw_m8 26 (by decide) (by decide) (by decide)]
            simp [m7, hw_m6 26 (by decide) (by decide) (by decide), m5, m4, m3, hw26_m2 7 (by decide), hm26_7]
          rw [hw7_m8, hr_m8 13 (by decide)]
          simp [m7, hr_m6 13 (by decide) (by decide), m5, m4, m3, hr_m2, hr13_r]
        have haff_succ : chainLevelAffected P P' nodes true opH r.succ =
            (if euclideanDistSq (P'.handleCoords opH) (nodes r).o ≤ (nodes r).V then false else true) := by
          simpa [hins_c] using hCtx.hAffInsTrue hins_c r haff_c
        by_cases hle : euclideanDistSq (P'.handleCoords opH) (nodes r).o ≤ (nodes r).V
        · have hcr : cValAt 0 inp m8
              (.realLe (.readRealHeap 26 (.lit 0)) (.readRealHeap 13 (.readHeap 26 (.lit 7)))) = true := by
            simp [cValAt_realLe, rValAt_readRealHeap, iValAt_readHeap, iValAt_lit, hr0_m8, hr13_m8, hle]
          let m9 := wWrite m8 26 9 0
          have hb9 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 9) (.lit 0)) m8 m9 15 :=
            exec_boxWriteW inp m8 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
          have hin : DetExecAt 0 inp
              (.ite (.realLe (.readRealHeap 26 (.lit 0)) (.readRealHeap 13 (.readHeap 26 (.lit 7))))
                (boxWriteW M_box 26 (.lit 9) (.lit 0))
                (boxWriteW M_box 26 (.lit 9) (.lit 1))) m8 m9 30 :=
            (DetExecAt.ite_true hcr (C_c := 15) (by simp [condExprOps, realExprOps, intExprOps]) hb9).mono_cost (by omega)
          exact ⟨m9,
            (DetExecAt.ite_true hc5 (C_c := 10) (by simp [condExprOps, intExprOps]) hin).mono_cost (by omega),
            fun _ => by simp [m9, haff_succ, hle],
            fun t ht idx => by simp [m9, ht],
            fun idx hne => by simp [m9, hne],
            fun _ _ => by simp [m9]⟩
        · have hcr : cValAt 0 inp m8
              (.realLe (.readRealHeap 26 (.lit 0)) (.readRealHeap 13 (.readHeap 26 (.lit 7)))) = false := by
            simp [cValAt_realLe, rValAt_readRealHeap, iValAt_readHeap, iValAt_lit, hr0_m8, hr13_m8, hle]
          let m9 := wWrite m8 26 9 1
          have hb9 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 9) (.lit 1)) m8 m9 15 :=
            exec_boxWriteW inp m8 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
          have hin : DetExecAt 0 inp
              (.ite (.realLe (.readRealHeap 26 (.lit 0)) (.readRealHeap 13 (.readHeap 26 (.lit 7))))
                (boxWriteW M_box 26 (.lit 9) (.lit 0))
                (boxWriteW M_box 26 (.lit 9) (.lit 1))) m8 m9 30 :=
            (DetExecAt.ite_false hcr (C_c := 15) (by simp [condExprOps, realExprOps, intExprOps]) hb9).mono_cost (by omega)
          exact ⟨m9,
            (DetExecAt.ite_true hc5 (C_c := 10) (by simp [condExprOps, intExprOps]) hin).mono_cost (by omega),
            fun _ => by simp [m9, haff_succ, hle],
            fun t ht idx => by simp [m9, ht],
            fun idx hne => by simp [m9, hne],
            fun _ _ => by simp [m9]⟩
  rcases hStepCore with ⟨m9, hb_core, hm9_9, hw_m9, hw26_m9, hr_m9⟩
  have hex_true : DetExecAt 0 inp
      (.ite (.intEq (.readHeap 26 (.lit 8)) (.lit 1))
        (seqList [
          boxWriteW M_box 13 (.readHeap 26 (.lit 7))
            (.add (.readHeap 13 (.readHeap 26 (.lit 7))) (.lit 1)),
          boxWriteW M_box 26 (.lit 3) (.readHeap 14 (.readHeap 26 (.lit 7))),
          boxWriteW M_box 26 (.lit 6) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ))),
          updSegCenterStmt d K M_box 12,
          boxWriteW M_box 26 (.lit 3) (.readHeap 15 (.readHeap 26 (.lit 7))),
          updSegZeroStmt K M_box,
          .ite (.intEq (.readHeap 26 (.lit 5)) (.lit 1))
            (.ite (.realLe (.readRealHeap 26 (.lit 0))
                           (.readRealHeap 13 (.readHeap 26 (.lit 7))))
              (boxWriteW M_box 26 (.lit 9) (.lit 0))
              (boxWriteW M_box 26 (.lit 9) (.lit 1)))
            .skip
        ]) .skip) m2 m9 (440 * (K + 1) + 120 * (d + 1) + 280) := by
    unfold seqList
    have hseq := hb_age.seq (hb_s14.seq (hb_ob.seq (hb_uC.seq (hb_s15.seq (hb_uZ.seq hb_core)))))
    exact (DetExecAt.ite_true hc8 (C_c := 10) (by simp [condExprOps, intExprOps]) hseq).mono_cost (by omega)
  let m_next := wWrite m9 26 7 ((r.val + 1 : ℕ) : ℤ)
  have hw26_7_m9 : wRead m9 26 7 = (r.val : ℤ) := by
    rw [hw26_m9 7 (by decide), hw_m8 26 (by decide) (by decide) (by decide)]
    simp [m7, hw_m6 26 (by decide) (by decide) (by decide), m5, m4, m3, hw26_m2 7 (by decide), hm26_7]
  have hex4 : DetExecAt 0 inp
      (boxWriteW M_box 26 (.lit 7) (.add (.readHeap 26 (.lit 7)) (.lit 1))) m9 m_next 20 :=
    exec_boxWriteW inp m9 _ _ rfl (by omega) (by omega)
      (by simp [hw26_7_m9]) (by simp [intExprOps])
  have hex_body : DetExecAt 0 inp (routeOneServingNodeStmt d K M_box) m m_next (routeOneServingNodeCost d K) := by
    have h123 := hSeqAB hex_true
    unfold routeOneServingNodeStmt
    unfold seqList at h123 ⊢
    exact ((DetExecAt.ite_true hcond_lt (C_c := 15) (by simp [condExprOps, intExprOps]) h123).seq hex4).mono_cost
      (by unfold routeOneServingNodeCost; omega)
  have liftOtherSlot : ∀ s' < NumSlots, s' ≠ dS → s' ≠ spS → ∀ S₁ fSq₁,
      EncSegSlot K m s' S₁ fSq₁ → EncSegSlot K m_next s' S₁ fSq₁ := by
    intro s' hs' hne_d hne_sp S₁ fSq₁ hE
    have hE6 := hOther_m6 s' hs' hne_d S₁ fSq₁ (liftSeg_m5 s' hs' S₁ fSq₁ hE)
    have hE7 : EncSegSlot K m7 s' S₁ fSq₁ := hE6.congr_mem_fSq (by simp [m7]) (fun _ _ => by simp [m7])
      (fun _ _ => by simp [m7]) (fun _ _ => by simp [m7]) (fun _ _ => by simp [m7]) (fun _ _ => rfl)
    have hE8 := hOther_m8 s' hs' hne_sp S₁ fSq₁ hE7
    exact hE8.congr_mem_fSq
      (by simp [m_next, hw_m9 5 (by decide)])
      (fun _ _ => by simp [m_next, hw_m9 8 (by decide)])
      (fun _ _ => by simp [m_next, hw_m9 9 (by decide)])
      (fun _ _ => by simp [m_next, hw_m9 10 (by decide)])
      (fun _ _ => by simp [m_next, hr_m9])
      (fun _ _ => rfl)
  have hw_not_seg_next : ∀ t, t ≠ 8 → t ≠ 9 → t ≠ 10 → t ≠ 26 → ∀ idx, wRead m_next t idx = wRead m3 t idx := by
    intro t h8 h9 h10 h26 idx
    simp [m_next, h26, hw_m9 t h26, hw_m8 t h8 h9 h10, m7, hw_m6 t h8 h9 h10, m5, m4]
  have hr_not_seg_next : ∀ t, t ≠ 8 → t ≠ 26 → ∀ idx, rRead m_next t idx = rRead m t idx := by
    intro t h8 h26 idx
    simp [m_next, hr_m9, hr_m8 t h8, m7, hr_m6 t h8 h26, m5, m4, m3, hr_m2]
  refine ⟨m_next, hex_body, ?_⟩
  unfold RouteLoopInvRel
  dsimp only
  refine ⟨⟨by simp [m_next, hw_m9 1 (by decide)]; exact hseg_m8.1,
     fun s hs => by simp [m_next, hw_m9 5 (by decide), hw_m9 1 (by decide)]; exact hseg_m8.2.1 s hs,
     fun s hs u hu => by simp [m_next, hw_m9 8 (by decide), hw_m9 1 (by decide)]; exact hseg_m8.2.2 s hs u hu⟩,
    by simp [m_next, hw26_m9 4 (by decide), hw_m8 26 (by decide) (by decide) (by decide),
             m7, hw_m6 26 (by decide) (by decide) (by decide), m5, m4, m3, hw26_m2 4 (by decide), hm26_4],
    by simp [m_next, hw26_m9 5 (by decide), hw_m8 26 (by decide) (by decide) (by decide),
             m7, hw_m6 26 (by decide) (by decide) (by decide), m5, m4, m3, hw26_m2 5 (by decide), hm26_5],
    by simp [m_next],
    fun hins => ?_,
    liftOtherSlot 0 (by omega) hd_ne0.symm hsp_ne0.symm _ _ hSeg0_m,
    liftOtherSlot leafS hleaf_lt hd_neL.symm hsp_neL.symm _ _ hSegL_m,
    fun r' hr' => ?_,
    fun r' hr' => ?_,
    fun s' hs' h0 hL hno S₁ fSq₁ hE =>
      liftOtherSlot s' hs'
        (fun heq => hno r (heq ▸ hd_in_r))
        (fun heq => hno r (heq ▸ hsp_in_r))
        S₁ fSq₁ (hRest_m s' hs' h0 hL hno S₁ fSq₁ hE),
    fun t h8 h9 h10 h13 h20 h26 idx => by
      rw [hw_not_seg_next t h8 h9 h10 h26]
      simp [m3, h13, hw_m2 t h20 h26, hw_m t h8 h9 h10 h13 h20 h26],
    fun idx hidx => by
      rw [hw_not_seg_next 13 (by decide) (by decide) (by decide) (by decide)]
      have hne_i : idx ≠ (r.val : ℤ) := by omega
      simp [m3, hne_i, hw_m2 13 (by decide) (by decide), hw13_m idx (by omega)],
    fun t h8 h26 idx => by rw [hr_not_seg_next t h8 h26, hr_m t h8 h26]⟩
  · have hfin_s : (⟨min (r.val + 1) k, Nat.lt_succ_of_le (Nat.min_le_right (r.val + 1) k)⟩ : Fin (k + 1)) = r.succ :=
      Fin.ext hmin_succ
    rw [hfin_s]
    simp [m_next, hm9_9 hins]
  · rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hr') with hlt_i | heq_i
    · rcases hDone_m r' hlt_i with ⟨hEN, hw20_r'⟩
      have hne_r : r' ≠ r := fun heq => by subst heq; omega
      have hne_i : (r'.val : ℤ) ≠ (r.val : ℤ) := by omega
      have hdisj_rr := Finset.disjoint_left.mp (hCtx.hdisj_sn r' r hne_r)
      refine ⟨hEN.congr_mem
        (by rw [hw_not_seg_next 13 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hne_i, hw_m2 13 (by decide) (by decide)])
        (by rw [hw_not_seg_next 14 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 14 (by decide) (by decide)])
        (by rw [hw_not_seg_next 15 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 15 (by decide) (by decide)])
        (fun s _ => by rw [hw_not_seg_next 6 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 6 (by decide) (by decide)])
        (fun _ => hr_not_seg_next 12 (by decide) (by decide) _)
        (hr_not_seg_next 13 (by decide) (by decide) _)
        (fun s hs_in S₁ fSq₁ hE => by
          rw [hsnSet_eq r'] at hs_in
          rcases hCtx.hsn r' with ⟨d1, s1, _, hd1, _, hs1_lt, _, _, e14, e15, _⟩
          have hset' := EncServingNode.snSlotSet_eq (d := d) (K := K) (NumSlots := NumSlots)
            (livePts := P.handleCoords) (N := nodes r')
            (S_r := chainInput P.handleCoords nodes P.activeHandles r'.castSucc) (age_r := snAge r') e14 e15
          have hslt : s < NumSlots := by rw [hset'] at hs_in; simp at hs_in; rcases hs_in with rfl | rfl <;> assumption
          have hnot_r : s ∉ snSlotSet mem r.val := hdisj_rr hs_in
          exact liftOtherSlot s hslt (fun he => hnot_r (he ▸ hd_in_r)) (fun he => hnot_r (he ▸ hsp_in_r)) S₁ fSq₁ hE)
        (fun _ _ => rfl),
        by rw [hw_not_seg_next 20 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hm2_20_ne _ hne_i, hw20_r']⟩
    · have hr'_eq : r' = r := Fin.ext heq_i
      subst hr'_eq
      have hSeg_d_next : EncSegSlot K m_next dS
          (chainInput P'.handleCoords nodes P'.activeHandles r'.castSucc)
          (fun x => euclideanDistSq (P'.handleCoords x) (nodes r').o) :=
        hSeg_d8.congr_mem_fSq
          (by simp [m_next, hw_m9 5 (by decide)])
          (fun _ _ => by simp [m_next, hw_m9 8 (by decide)])
          (fun _ _ => by simp [m_next, hw_m9 9 (by decide)])
          (fun _ _ => by simp [m_next, hw_m9 10 (by decide)])
          (fun _ _ => by simp [m_next, hr_m9])
          (fun _ _ => rfl)
      have hSeg_sp_next : EncSegSlot K m_next spS T_sp' (fun _ => 0) :=
        hSeg_sp8'.congr_mem_fSq
          (by simp [m_next, hw_m9 5 (by decide)])
          (fun _ _ => by simp [m_next, hw_m9 8 (by decide)])
          (fun _ _ => by simp [m_next, hw_m9 9 (by decide)])
          (fun _ _ => by simp [m_next, hw_m9 10 (by decide)])
          (fun _ _ => by simp [m_next, hr_m9])
          (fun _ _ => rfl)
      refine ⟨⟨dS, spS, hd0, hd_lt, hsp0, hsp_lt, hd_ne_sp,
        by rw [hw_not_seg_next 13 (by decide) (by decide) (by decide) (by decide)]; simp [m3, haff_c],
        by rw [hw_not_seg_next 14 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 14 (by decide) (by decide), hw14_r],
        by rw [hw_not_seg_next 15 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 15 (by decide) (by decide), hw15_r],
        by rw [hw_not_seg_next 6 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 6 (by decide) (by decide), hw6_d],
        by rw [hw_not_seg_next 6 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 6 (by decide) (by decide), hw6_sp],
        fun c => by rw [hr_not_seg_next 12 (by decide) (by decide)]; exact hr12_r c,
        by rw [hr_not_seg_next 13 (by decide) (by decide)]; exact hr13_r,
        hSeg_d_next, T_sp', hSeg_sp_next, fun hi => by dsimp [T_sp']; rw [hidle_sp hi, hSpost_eq]⟩,
        by rw [hw_not_seg_next 20 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hm2_20_i, haff_c]⟩
  · have hne_r : r' ≠ r := fun heq => by subst heq; omega
    have hne_i : (r'.val : ℤ) ≠ (r.val : ℤ) := by omega
    have hdisj_rr := Finset.disjoint_left.mp (hCtx.hdisj_sn r' r hne_r)
    exact (hTodo_m r' (Nat.le_of_succ_le hr')).congr_mem
      (by rw [hw_not_seg_next 13 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hne_i, hw_m2 13 (by decide) (by decide)])
      (by rw [hw_not_seg_next 14 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 14 (by decide) (by decide)])
      (by rw [hw_not_seg_next 15 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 15 (by decide) (by decide)])
      (fun s _ => by rw [hw_not_seg_next 6 (by decide) (by decide) (by decide) (by decide)]; simp [m3, hw_m2 6 (by decide) (by decide)])
      (fun _ => hr_not_seg_next 12 (by decide) (by decide) _)
      (hr_not_seg_next 13 (by decide) (by decide) _)
      (fun s hs_in S₁ fSq₁ hE => by
        rw [hsnSet_eq r'] at hs_in
        rcases hCtx.hsn r' with ⟨d1, s1, _, hd1, _, hs1_lt, _, _, e14, e15, _⟩
        have hset' := EncServingNode.snSlotSet_eq (d := d) (K := K) (NumSlots := NumSlots)
          (livePts := P.handleCoords) (N := nodes r')
          (S_r := chainInput P.handleCoords nodes P.activeHandles r'.castSucc) (age_r := snAge r') e14 e15
        have hslt : s < NumSlots := by rw [hset'] at hs_in; simp at hs_in; rcases hs_in with rfl | rfl <;> assumption
        have hnot_r : s ∉ snSlotSet mem r.val := hdisj_rr hs_in
        exact liftOtherSlot s hslt (fun he => hnot_r (he ▸ hd_in_r)) (fun he => hnot_r (he ▸ hsp_in_r)) S₁ fSq₁ hE)
      (fun _ _ => rfl)

/-- Complete single-iteration `DetExecAt` step for `routeOneServingNodeStmt` across `i < D₀`. -/
theorem exec_routeOneServingNodeStmt_rel {d n K D₀ NumSlots M_box k leafS opH : ℕ}
    (inp : ArithRAMInput d)
    {P P' : DynamicPointSet d} {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ} {idle : Fin k → Bool}
    {ins : Bool} {mem mA : ArithRAMMemory}
    (hCtx : RouteLoopCtxRel d n K D₀ NumSlots M_box k leafS opH P P' nodes snAge idle ins mem mA)
    (i : ℕ) (hi_D0 : i < D₀) (m : ArithRAMMemory)
    (hm : RouteLoopInvRel K NumSlots leafS opH P P' nodes snAge idle ins mem mA i m) :
    ∃ m_next : ArithRAMMemory,
      DetExecAt 0 inp (routeOneServingNodeStmt d K M_box) m m_next (routeOneServingNodeCost d K) ∧
      RouteLoopInvRel K NumSlots leafS opH P P' nodes snAge idle ins mem mA (i + 1) m_next := by
  by_cases hi_lt : i < k
  · cases haff : chainLevelAffected P P' nodes ins opH (⟨i, hi_lt⟩ : Fin k).castSucc with
    | false => exact exec_routeOneServingNodeStmt_unaff_rel inp hCtx ⟨i, hi_lt⟩ hi_D0 hm haff
    | true => exact exec_routeOneServingNodeStmt_aff_rel inp hCtx ⟨i, hi_lt⟩ hi_D0 hm haff
  · exact exec_routeOneServingNodeStmt_pad_rel inp hCtx (Nat.le_of_not_lt hi_lt) hm

end UL.Proof_lem_7_2_RacerP46
