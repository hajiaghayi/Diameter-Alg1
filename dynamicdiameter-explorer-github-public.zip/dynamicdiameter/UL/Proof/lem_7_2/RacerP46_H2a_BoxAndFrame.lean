import UL.Proof.lem_7_2.RacerP33_H1_RAM
import UL.Proof.lem_7_2.RacerP33_H2_LocHPJ

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33

/-! ### 1. Syntactic Heap-Tag Frame Checkers & `DetExecAt` Frame Preservation -/

def writesWordTag (t : ℕ) : ArithRAMStmt → Bool
  | .writeWordHeap t' _ _ | .freeWordHeap t' _ | .randBitHeap t' _ => decide (t' = t)
  | .seq s₁ s₂ | .ite _ s₁ s₂ => writesWordTag t s₁ || writesWordTag t s₂
  | .whileLoop _ b | .repeatN _ b | .localScope b => writesWordTag t b
  | _ => false

def writesWordTagCont (t : ℕ) : ArithRAMCont → Bool
  | .stmt s => writesWordTag t s
  | .repeatLoop _ b => writesWordTag t b
  | .popScope _ => false

def writesRealTag (t : ℕ) : ArithRAMStmt → Bool
  | .writeRealHeap t' _ _ | .freeRealHeap t' _ => decide (t' = t)
  | .seq s₁ s₂ | .ite _ s₁ s₂ => writesRealTag t s₁ || writesRealTag t s₂
  | .whileLoop _ b | .repeatN _ b | .localScope b => writesRealTag t b
  | _ => false

def writesRealTagCont (t : ℕ) : ArithRAMCont → Bool
  | .stmt s => writesRealTag t s
  | .repeatLoop _ b => writesRealTag t b
  | .popScope _ => false

theorem popDepth_zero_idem (mem : ArithRAMMemory) :
    (mem.popDepth 0).popDepth 0 = mem.popDepth 0 := by
  unfold ArithRAMMemory.popDepth WordStore.popDepth RealStore.popDepth
  dsimp only
  congr 1
  · congr 1
    · ext loc; simp
    · funext loc; by_cases hk : loc.keepAtDepth 0 <;> simp [hk]
  · congr 1
    · ext loc; simp
    · funext loc; by_cases hk : loc.keepAtDepth 0 <;> simp [hk]

theorem wRead_eq_of_popDepth_zero {m₁ m₂ : ArithRAMMemory}
    (h : m₁.popDepth 0 = m₂.popDepth 0) (t : ℕ) (idx : ℤ) :
    wRead m₁ t idx = wRead m₂ t idx := by
  have h1 : wRead (m₁.popDepth 0) t idx = wRead (m₂.popDepth 0) t idx := by rw [h]
  simpa using h1

theorem rRead_eq_of_popDepth_zero {m₁ m₂ : ArithRAMMemory}
    (h : m₁.popDepth 0 = m₂.popDepth 0) (t : ℕ) (idx : ℤ) :
    rRead m₁ t idx = rRead m₂ t idx := by
  have h1 : rRead (m₁.popDepth 0) t idx = rRead (m₂.popDepth 0) t idx := by rw [h]
  simpa using h1

theorem runArithRAMFuel_out_popDepth_zero {d : ℕ} (inp : ArithRAMInput d) :
    ∀ (fuel : ℕ) (stk : List ArithRAMCont) (st : ArithRAMExecState) (out : ArithRAMExecOutcome),
      runArithRAMFuel inp fuel stk st = .halted out →
      out.mem.popDepth 0 = out.mem
  | 0, [], st, out, hrun => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; exact popDepth_zero_idem st.mem
  | 0, _ :: _, _, _, hrun => by simp [runArithRAMFuel] at hrun
  | fuel + 1, [], st, out, hrun => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; exact popDepth_zero_idem st.mem
  | fuel + 1, item :: rest, st, out, hrun => by
      cases item with
      | popScope _ =>
          simp only [runArithRAMFuel] at hrun
          exact runArithRAMFuel_out_popDepth_zero inp fuel rest _ out hrun
      | repeatLoop rem body =>
          cases rem <;> simp only [runArithRAMFuel] at hrun <;>
            exact runArithRAMFuel_out_popDepth_zero inp fuel _ _ out hrun
      | stmt s =>
          cases s with
          | randBitHeap _ _ | randBitLocal _ _ =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons _ _ =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  exact runArithRAMFuel_out_popDepth_zero inp fuel _ _ out hrun
          | _ =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_out_popDepth_zero inp fuel _ _ out hrun

theorem runArithRAMFuel_preserves_wTag {d : ℕ} (inp : ArithRAMInput d) (t : ℕ) :
    ∀ (fuel : ℕ) (stk : List ArithRAMCont) (st : ArithRAMExecState) (out : ArithRAMExecOutcome),
      (∀ c ∈ stk, writesWordTagCont t c = false) →
      runArithRAMFuel inp fuel stk st = .halted out →
      ∀ idx : ℤ, wRead out.mem t idx = wRead st.mem t idx
  | 0, [], st, out, _, hrun, idx => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; simp
  | 0, _ :: _, _, _, _, hrun, _ => by simp [runArithRAMFuel] at hrun
  | fuel + 1, [], st, out, _, hrun, idx => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; simp
  | fuel + 1, item :: rest, st, out, hstk, hrun, idx => by
      have hitem : writesWordTagCont t item = false := hstk item List.mem_cons_self
      have hrest : ∀ c ∈ rest, writesWordTagCont t c = false :=
        fun c hc => hstk c (List.mem_cons_of_mem _ hc)
      cases item with
      | popScope prev =>
          simp only [runArithRAMFuel] at hrun
          rw [runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx]
          simp
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt body :: .repeatLoop r body :: rest),
                  writesWordTagCont t c = false := by
                intro c hc; simp only [List.mem_cons] at hc
                rcases hc with rfl | rfl | hc
                · exact hitem
                · exact hitem
                · exact hrest c hc
              exact runArithRAMFuel_preserves_wTag inp t fuel _ _ out hstk' hrun idx
      | stmt s =>
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx
          | writeWordHeap t' idxE valE =>
              simp only [writesWordTagCont, writesWordTag, decide_eq_false_iff_not] at hitem
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx]
              exact wRead_wWrite_of_ne st.mem _ (Or.inl (Ne.symm hitem))
          | writeWordLocal v idxE valE =>
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx]
              simp [wRead, WordStore.read, WordStore.write]
          | freeWordHeap t' idxE =>
              simp only [writesWordTagCont, writesWordTag, decide_eq_false_iff_not] at hitem
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx]
              exact wRead_wFree_of_ne st.mem (Or.inl (Ne.symm hitem))
          | freeWordLocal v idxE =>
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx]
              simp [wRead, WordStore.read, WordStore.free]
          | writeRealHeap _ _ _ | writeRealLocal _ _ _ | freeRealHeap _ _ | freeRealLocal _ _ =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx
          | randBitHeap t' idxE =>
              simp only [writesWordTagCont, writesWordTag, decide_eq_false_iff_not] at hitem
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  rw [runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx]
                  exact wRead_wWrite_of_ne st.mem _ (Or.inl (Ne.symm hitem))
          | randBitLocal v idxE =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  rw [runArithRAMFuel_preserves_wTag inp t fuel rest _ out hrest hrun idx]
                  simp [wRead, WordStore.read, WordStore.write]
          | seq s₁ s₂ =>
              simp only [writesWordTagCont, writesWordTag, Bool.or_eq_false_iff] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt s₁ :: .stmt s₂ :: rest),
                  writesWordTagCont t c = false := by
                intro c hc; simp only [List.mem_cons] at hc
                rcases hc with rfl | rfl | hc
                · exact hitem.1
                · exact hitem.2
                · exact hrest c hc
              exact runArithRAMFuel_preserves_wTag inp t fuel _ _ out hstk' hrun idx
          | ite c tB fB =>
              simp only [writesWordTagCont, writesWordTag, Bool.or_eq_false_iff] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (.stmt (if (evalArithCond inp st.frameDepth st.mem c).1 then tB else fB) :: rest),
                  writesWordTagCont t item' = false := by
                intro item' hi; simp only [List.mem_cons] at hi
                rcases hi with rfl | hi
                · split_ifs <;> [exact hitem.1; exact hitem.2]
                · exact hrest item' hi
              exact runArithRAMFuel_preserves_wTag inp t fuel _ _ out hstk' hrun idx
          | whileLoop c body =>
              simp only [writesWordTagCont, writesWordTag] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (if (evalArithCond inp st.frameDepth st.mem c).1
                  then .stmt body :: .stmt (.whileLoop c body) :: rest else rest),
                  writesWordTagCont t item' = false := by
                split_ifs
                · intro item' hi; simp only [List.mem_cons] at hi
                  rcases hi with rfl | rfl | hi
                  · exact hitem
                  · exact hitem
                  · exact hrest item' hi
                · exact hrest
              exact runArithRAMFuel_preserves_wTag inp t fuel _ _ out hstk' hrun idx
          | repeatN cntE body =>
              simp only [writesWordTagCont, writesWordTag] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (ArithRAMCont.repeatLoop
                  (if 0 ≤ (evalIntExpr inp.toWordView st.frameDepth st.mem.words cntE).1
                   then (evalIntExpr inp.toWordView st.frameDepth st.mem.words cntE).1.toNat else 0)
                  body :: rest),
                  writesWordTagCont t item' = false := by
                intro item' hi; simp only [List.mem_cons] at hi
                rcases hi with rfl | hi
                · exact hitem
                · exact hrest item' hi
              exact runArithRAMFuel_preserves_wTag inp t fuel _ _ out hstk' hrun idx
          | localScope body =>
              simp only [writesWordTagCont, writesWordTag] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (.stmt body :: .popScope st.frameDepth :: rest),
                  writesWordTagCont t item' = false := by
                intro item' hi; simp only [List.mem_cons] at hi
                rcases hi with rfl | rfl | hi
                · exact hitem
                · rfl
                · exact hrest item' hi
              rw [runArithRAMFuel_preserves_wTag inp t fuel _ _ out hstk' hrun idx]
              simp

theorem runArithRAMFuel_preserves_rTag {d : ℕ} (inp : ArithRAMInput d) (t : ℕ) :
    ∀ (fuel : ℕ) (stk : List ArithRAMCont) (st : ArithRAMExecState) (out : ArithRAMExecOutcome),
      (∀ c ∈ stk, writesRealTagCont t c = false) →
      runArithRAMFuel inp fuel stk st = .halted out →
      ∀ idx : ℤ, rRead out.mem t idx = rRead st.mem t idx
  | 0, [], st, out, _, hrun, idx => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; simp
  | 0, _ :: _, _, _, _, hrun, _ => by simp [runArithRAMFuel] at hrun
  | fuel + 1, [], st, out, _, hrun, idx => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; simp
  | fuel + 1, item :: rest, st, out, hstk, hrun, idx => by
      have hitem : writesRealTagCont t item = false := hstk item List.mem_cons_self
      have hrest : ∀ c ∈ rest, writesRealTagCont t c = false :=
        fun c hc => hstk c (List.mem_cons_of_mem _ hc)
      cases item with
      | popScope prev =>
          simp only [runArithRAMFuel] at hrun
          rw [runArithRAMFuel_preserves_rTag inp t fuel rest _ out hrest hrun idx]
          simp
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_rTag inp t fuel rest _ out hrest hrun idx
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt body :: .repeatLoop r body :: rest),
                  writesRealTagCont t c = false := by
                intro c hc; simp only [List.mem_cons] at hc
                rcases hc with rfl | rfl | hc
                · exact hitem
                · exact hitem
                · exact hrest c hc
              exact runArithRAMFuel_preserves_rTag inp t fuel _ _ out hstk' hrun idx
      | stmt s =>
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_rTag inp t fuel rest _ out hrest hrun idx
          | writeWordHeap _ _ _ | writeWordLocal _ _ _ | freeWordHeap _ _ | freeWordLocal _ _ =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_rTag inp t fuel rest _ out hrest hrun idx
          | writeRealHeap t' idxE valE =>
              simp only [writesRealTagCont, writesRealTag, decide_eq_false_iff_not] at hitem
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_rTag inp t fuel rest _ out hrest hrun idx]
              exact rRead_rWrite_of_ne st.mem _ (Or.inl (Ne.symm hitem))
          | writeRealLocal v idxE valE =>
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_rTag inp t fuel rest _ out hrest hrun idx]
              simp [rRead, RealStore.read, RealStore.write]
          | freeRealHeap t' idxE =>
              simp only [writesRealTagCont, writesRealTag, decide_eq_false_iff_not] at hitem
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_rTag inp t fuel rest _ out hrest hrun idx]
              exact rRead_rFree_of_ne st.mem (Or.inl (Ne.symm hitem))
          | freeRealLocal v idxE =>
              simp only [runArithRAMFuel] at hrun
              rw [runArithRAMFuel_preserves_rTag inp t fuel rest _ out hrest hrun idx]
              simp [rRead, RealStore.read, RealStore.free]
          | randBitHeap _ _ | randBitLocal _ _ =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  exact runArithRAMFuel_preserves_rTag inp t fuel rest _ out hrest hrun idx
          | seq s₁ s₂ =>
              simp only [writesRealTagCont, writesRealTag, Bool.or_eq_false_iff] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt s₁ :: .stmt s₂ :: rest),
                  writesRealTagCont t c = false := by
                intro c hc; simp only [List.mem_cons] at hc
                rcases hc with rfl | rfl | hc
                · exact hitem.1
                · exact hitem.2
                · exact hrest c hc
              exact runArithRAMFuel_preserves_rTag inp t fuel _ _ out hstk' hrun idx
          | ite c tB fB =>
              simp only [writesRealTagCont, writesRealTag, Bool.or_eq_false_iff] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (.stmt (if (evalArithCond inp st.frameDepth st.mem c).1 then tB else fB) :: rest),
                  writesRealTagCont t item' = false := by
                intro item' hi; simp only [List.mem_cons] at hi
                rcases hi with rfl | hi
                · split_ifs <;> [exact hitem.1; exact hitem.2]
                · exact hrest item' hi
              exact runArithRAMFuel_preserves_rTag inp t fuel _ _ out hstk' hrun idx
          | whileLoop c body =>
              simp only [writesRealTagCont, writesRealTag] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (if (evalArithCond inp st.frameDepth st.mem c).1
                  then .stmt body :: .stmt (.whileLoop c body) :: rest else rest),
                  writesRealTagCont t item' = false := by
                split_ifs
                · intro item' hi; simp only [List.mem_cons] at hi
                  rcases hi with rfl | rfl | hi
                  · exact hitem
                  · exact hitem
                  · exact hrest item' hi
                · exact hrest
              exact runArithRAMFuel_preserves_rTag inp t fuel _ _ out hstk' hrun idx
          | repeatN cntE body =>
              simp only [writesRealTagCont, writesRealTag] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (ArithRAMCont.repeatLoop
                  (if 0 ≤ (evalIntExpr inp.toWordView st.frameDepth st.mem.words cntE).1
                   then (evalIntExpr inp.toWordView st.frameDepth st.mem.words cntE).1.toNat else 0)
                  body :: rest),
                  writesRealTagCont t item' = false := by
                intro item' hi; simp only [List.mem_cons] at hi
                rcases hi with rfl | hi
                · exact hitem
                · exact hrest item' hi
              exact runArithRAMFuel_preserves_rTag inp t fuel _ _ out hstk' hrun idx
          | localScope body =>
              simp only [writesRealTagCont, writesRealTag] at hitem
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ item' ∈ (.stmt body :: .popScope st.frameDepth :: rest),
                  writesRealTagCont t item' = false := by
                intro item' hi; simp only [List.mem_cons] at hi
                rcases hi with rfl | rfl | hi
                · exact hitem
                · rfl
                · exact hrest item' hi
              rw [runArithRAMFuel_preserves_rTag inp t fuel _ _ out hstk' hrun idx]
              simp

theorem pres_wRead {d fd : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {m₀ m₁ : ArithRAMMemory} {C t : ℕ}
    (h : DetExecAt fd inp s m₀ m₁ C) (ht : writesWordTag t s = false) (idx : ℤ) :
    wRead m₁ t idx = wRead m₀ t idx := by
  rcases h [] 0 0 [] with ⟨fuel, u₁, pk₁, _, hs⟩
  have hrun := hs 1
  change runArithRAMFuel inp (fuel + 1) [.stmt s] _ = .halted _ at hrun
  have hstk : ∀ c ∈ ([ArithRAMCont.stmt s] : List ArithRAMCont), writesWordTagCont t c = false := by
    intro c hc; simp only [List.mem_singleton] at hc; subst hc; exact ht
  have heq := runArithRAMFuel_preserves_wTag inp t (fuel + 1) [.stmt s] _ _ hstk hrun idx
  simpa using heq

theorem pres_rRead {d fd : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {m₀ m₁ : ArithRAMMemory} {C t : ℕ}
    (h : DetExecAt fd inp s m₀ m₁ C) (ht : writesRealTag t s = false) (idx : ℤ) :
    rRead m₁ t idx = rRead m₀ t idx := by
  rcases h [] 0 0 [] with ⟨fuel, u₁, pk₁, _, hs⟩
  have hrun := hs 1
  change runArithRAMFuel inp (fuel + 1) [.stmt s] _ = .halted _ at hrun
  have hstk : ∀ c ∈ ([ArithRAMCont.stmt s] : List ArithRAMCont), writesRealTagCont t c = false := by
    intro c hc; simp only [List.mem_singleton] at hc; subst hc; exact ht
  have heq := runArithRAMFuel_preserves_rTag inp t (fuel + 1) [.stmt s] _ _ hstk hrun idx
  simpa using heq

/-! ### 2. `boxWriteW` / `boxWriteR` & Syntactic `BoxSafeInner` Space Preservation -/

def boxWriteW (M_box t : ℕ) (idxE valE : IntExpr) : ArithRAMStmt :=
  .ite (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ))))
       (.writeWordHeap t idxE valE) .skip

def boxWriteR (M_box t : ℕ) (idxE : IntExpr) (valE : RealExpr) : ArithRAMStmt :=
  .ite (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ))))
       (.writeRealHeap t idxE valE) .skip

@[simp] theorem writesWordTag_boxWriteW (t M_box t' : ℕ) (idxE valE : IntExpr) :
    writesWordTag t (boxWriteW M_box t' idxE valE) = decide (t' = t) := by
  simp [boxWriteW, writesWordTag]

@[simp] theorem writesRealTag_boxWriteW (t M_box t' : ℕ) (idxE valE : IntExpr) :
    writesRealTag t (boxWriteW M_box t' idxE valE) = false := by
  simp [boxWriteW, writesRealTag]

@[simp] theorem writesWordTag_boxWriteR (t M_box t' : ℕ) (idxE : IntExpr) (valE : RealExpr) :
    writesWordTag t (boxWriteR M_box t' idxE valE) = false := by
  simp [boxWriteR, writesWordTag]

@[simp] theorem writesRealTag_boxWriteR (t M_box t' : ℕ) (idxE : IntExpr) (valE : RealExpr) :
    writesRealTag t (boxWriteR M_box t' idxE valE) = decide (t' = t) := by
  simp [boxWriteR, writesRealTag]

@[simp] theorem writesWordTag_seqList (t : ℕ) : ∀ (ss : List ArithRAMStmt),
    writesWordTag t (seqList ss) = ss.any (writesWordTag t)
  | [] => rfl
  | [s] => by simp [seqList]
  | s₁ :: s₂ :: ss => by
      simp [seqList, writesWordTag, writesWordTag_seqList t (s₂ :: ss)]

@[simp] theorem writesRealTag_seqList (t : ℕ) : ∀ (ss : List ArithRAMStmt),
    writesRealTag t (seqList ss) = ss.any (writesRealTag t)
  | [] => rfl
  | [s] => by simp [seqList]
  | s₁ :: s₂ :: ss => by
      simp [seqList, writesRealTag, writesRealTag_seqList t (s₂ :: ss)]

theorem exec_boxWriteW {d fd : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {M_box t : ℕ} (idxE valE : IntExpr) {idx val : ℤ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hi0 : 0 ≤ idx) (hi1 : idx < (M_box : ℤ))
    (hval : iValAt fd inp mem valE = val)
    (hcost : 3 * intExprOps idxE + intExprOps valE + 6 ≤ C) :
    DetExecAt fd inp (boxWriteW M_box t idxE valE) mem (wWrite mem t idx val) C := by
  have hc : cValAt fd inp mem (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) = true := by
    simp only [cValAt_and, cValAt_intLe, cValAt_intLt, iValAt_lit, hidx,
      Bool.and_eq_true, decide_eq_true_eq]
    exact ⟨hi0, hi1⟩
  have hwr : DetExecAt fd inp (.writeWordHeap t idxE valE) mem (wWrite mem t idx val)
      (intExprOps idxE + intExprOps valE + 1) :=
    DetExecAt.writeWordHeap fd inp mem t idxE valE hidx hval le_rfl
  refine (DetExecAt.ite_true hc (C_c := 2 * intExprOps idxE + 5)
    (by dsimp [condExprOps, intExprOps]; omega) hwr).mono_cost (by omega)

theorem exec_boxWriteR {d fd : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {M_box t : ℕ} (idxE : IntExpr) (valE : RealExpr) {idx : ℤ} {val : ℝ} {C : ℕ}
    (hidx : iValAt fd inp mem idxE = idx)
    (hi0 : 0 ≤ idx) (hi1 : idx < (M_box : ℤ))
    (hval : rValAt fd inp mem valE = val)
    (hcost : 3 * intExprOps idxE + realExprOps valE + 6 ≤ C) :
    DetExecAt fd inp (boxWriteR M_box t idxE valE) mem (rWrite mem t idx val) C := by
  have hc : cValAt fd inp mem (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) = true := by
    simp only [cValAt_and, cValAt_intLe, cValAt_intLt, iValAt_lit, hidx,
      Bool.and_eq_true, decide_eq_true_eq]
    exact ⟨hi0, hi1⟩
  have hwr : DetExecAt fd inp (.writeRealHeap t idxE valE) mem (rWrite mem t idx val)
      (intExprOps idxE + realExprOps valE + 1) :=
    DetExecAt.writeRealHeap fd inp mem t idxE valE hidx hval le_rfl
  refine (DetExecAt.ite_true hc (C_c := 2 * intExprOps idxE + 5)
    (by dsimp [condExprOps, intExprOps]; omega) hwr).mono_cost (by omega)

inductive BoxSafeInner (T_max M_box : ℕ) : ArithRAMStmt → Prop
  | skip : BoxSafeInner T_max M_box .skip
  | writeWordLocal (v : ℕ) (idxE valE : IntExpr) :
      BoxSafeInner T_max M_box (.writeWordLocal v idxE valE)
  | writeRealLocal (v : ℕ) (idxE : IntExpr) (valE : RealExpr) :
      BoxSafeInner T_max M_box (.writeRealLocal v idxE valE)
  | randBitLocal (v : ℕ) (idxE : IntExpr) :
      BoxSafeInner T_max M_box (.randBitLocal v idxE)
  | boxW {t : ℕ} (ht : t < T_max) (idxE valE : IntExpr) :
      BoxSafeInner T_max M_box (boxWriteW M_box t idxE valE)
  | boxR {t : ℕ} (ht : t < T_max) (idxE : IntExpr) (valE : RealExpr) :
      BoxSafeInner T_max M_box (boxWriteR M_box t idxE valE)
  | seq {s₁ s₂} : BoxSafeInner T_max M_box s₁ → BoxSafeInner T_max M_box s₂ →
      BoxSafeInner T_max M_box (.seq s₁ s₂)
  | ite (c : ArithCondExpr) {s₁ s₂} :
      BoxSafeInner T_max M_box s₁ → BoxSafeInner T_max M_box s₂ →
      BoxSafeInner T_max M_box (.ite c s₁ s₂)
  | whileLoop (c : ArithCondExpr) {b} :
      BoxSafeInner T_max M_box b → BoxSafeInner T_max M_box (.whileLoop c b)
  | repeatN (cntE : IntExpr) {b} :
      BoxSafeInner T_max M_box b → BoxSafeInner T_max M_box (.repeatN cntE b)
  | localScope {b} :
      BoxSafeInner T_max M_box b → BoxSafeInner T_max M_box (.localScope b)

theorem boxSafeInner_seqList {T_max M_box : ℕ} :
    ∀ {ss : List ArithRAMStmt},
      (∀ s ∈ ss, BoxSafeInner T_max M_box s) → BoxSafeInner T_max M_box (seqList ss)
  | [], _ => .skip
  | [s], h => h s List.mem_cons_self
  | s₁ :: s₂ :: ss, h =>
      .seq (h s₁ List.mem_cons_self)
        (boxSafeInner_seqList (fun s hs => h s (List.mem_cons_of_mem _ hs)))

theorem boxSafeInner_readRandNatLocalStmt (T_max M_box v : ℕ) (idx tmp : ℤ) (M_bits : ℕ) :
    BoxSafeInner T_max M_box (readRandNatLocalStmt v idx tmp M_bits) :=
  .seq (.writeWordLocal _ _ _) (.repeatN _ (.seq (.randBitLocal _ _) (.writeWordLocal _ _ _)))

theorem boxSafeInner_locStmt (T_max M_box N : ℕ) :
    ∀ {s : ArithRAMStmt}, LocalizableStmt s = true → BoxSafeInner T_max M_box (locStmt N s)
  | .skip, _ => .skip
  | .writeWordHeap _ _ _, _ => .writeWordLocal _ _ _
  | .writeRealHeap _ _ valE, _ => by
      unfold locStmt
      cases isActivePtCoord? valE with
      | none => exact .writeRealLocal _ _ _
      | some _ => exact .ite _ (.writeRealLocal _ _ _) (.writeRealLocal _ _ _)
  | .randBitHeap _ _, _ => .randBitLocal _ _
  | .seq s₁ s₂, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      exact .seq (boxSafeInner_locStmt T_max M_box N h.1) (boxSafeInner_locStmt T_max M_box N h.2)
  | .ite c s₁ s₂, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      exact .ite _ (boxSafeInner_locStmt T_max M_box N h.1.2) (boxSafeInner_locStmt T_max M_box N h.2)
  | .whileLoop c b, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      exact .whileLoop _ (boxSafeInner_locStmt T_max M_box N h.2)
  | .repeatN cntE b, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      exact .repeatN _ (boxSafeInner_locStmt T_max M_box N h.2)
  | .writeWordLocal _ _ _, h | .freeWordHeap _ _, h | .freeWordLocal _ _, h
  | .freeRealHeap _ _, h | .freeRealLocal _ _, h | .writeRealLocal _ _ _, h
  | .randBitLocal _ _, h | .localScope _, h => by
      simp [LocalizableStmt] at h

inductive SafeContInner (T_max M_box : ℕ) : ℕ → List ArithRAMCont → Prop
  | done_zero : SafeContInner T_max M_box 0 []
  | scope_zero {b : ArithRAMStmt} :
      BoxSafeInner T_max M_box b →
      SafeContInner T_max M_box 0 [.stmt (.localScope b)]
  | pop_succ {fd : ℕ} {rest : List ArithRAMCont} :
      SafeContInner T_max M_box fd rest →
      SafeContInner T_max M_box (fd + 1) (.popScope fd :: rest)
  | stmt_pos {fd : ℕ} {s : ArithRAMStmt} {rest : List ArithRAMCont} :
      1 ≤ fd → BoxSafeInner T_max M_box s →
      SafeContInner T_max M_box fd rest →
      SafeContInner T_max M_box fd (.stmt s :: rest)
  | repeat_pos {fd rem : ℕ} {b : ArithRAMStmt} {rest : List ArithRAMCont} :
      1 ≤ fd → BoxSafeInner T_max M_box b →
      SafeContInner T_max M_box fd rest →
      SafeContInner T_max M_box fd (.repeatLoop rem b :: rest)

theorem runArithRAMFuel_preserves_box_inner {d T_max M_box : ℕ} (inp : ArithRAMInput d) :
    ∀ (fuel : ℕ) (stk : List ArithRAMCont) (st : ArithRAMExecState) (out : ArithRAMExecOutcome),
      SafeContInner T_max M_box st.frameDepth stk →
      HeapOnlyInBox T_max M_box st.mem →
      runArithRAMFuel inp fuel stk st = .halted out →
      HeapOnlyInBox T_max M_box out.mem
  | 0, [], st, out, _, hbox, hrun => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; exact heapOnlyInBox_popDepth 0 hbox
  | 0, _ :: _, _, _, _, _, hrun => by simp [runArithRAMFuel] at hrun
  | fuel + 1, [], st, out, _, hbox, hrun => by
      cases hrem : st.remainingBits.isEmpty <;> simp [runArithRAMFuel, hrem] at hrun
      subst hrun; exact heapOnlyInBox_popDepth 0 hbox
  | fuel + 1, item :: rest, ⟨mem, fd, remBits, uCost, pk⟩, out, hsafe, hbox, hrun => by
      dsimp only at hsafe hbox hrun
      let st : ArithRAMExecState := ⟨mem, fd, remBits, uCost, pk⟩
      change runArithRAMFuel inp (fuel + 1) (item :: rest) st = .halted out at hrun
      cases hsafe with
      | scope_zero hb =>
          simp only [st, runArithRAMFuel] at hrun
          exact runArithRAMFuel_preserves_box_inner inp fuel _ _ out
            (.stmt_pos (by simp [st]) hb (.pop_succ .done_zero))
            (heapOnlyInBox_popDepth 0 hbox) hrun
      | @pop_succ prev rest' hrest =>
          simp only [st, runArithRAMFuel] at hrun
          exact runArithRAMFuel_preserves_box_inner inp fuel rest _ out hrest
            (heapOnlyInBox_popDepth prev hbox) hrun
      | @repeat_pos fd' rem b rest' hfd hb hrest =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_inner inp fuel rest _ out hrest hbox hrun
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_inner inp fuel _ _ out
                (.stmt_pos hfd hb (.repeat_pos hfd hb hrest)) hbox hrun
      | stmt_pos hfd hs hrest =>
          cases hs with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_inner inp fuel rest _ out hrest hbox hrun
          | writeWordLocal v idxE valE =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_inner inp fuel rest _ out hrest
                (heapOnlyInBox_wWriteL hfd v _ _ hbox) hrun
          | writeRealLocal v idxE valE =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_inner inp fuel rest _ out hrest
                (heapOnlyInBox_rWriteL hfd v _ _ hbox) hrun
          | randBitLocal v idxE =>
              cases hbits : st.remainingBits with
              | nil => simp [runArithRAMFuel, hbits] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel, hbits] at hrun
                  exact runArithRAMFuel_preserves_box_inner inp fuel rest _ out hrest
                    (heapOnlyInBox_wWriteL hfd v _ _ hbox) hrun
          | @boxW t ht idxE valE =>
              simp only [boxWriteW, runArithRAMFuel] at hrun
              rcases hc : evalArithCond inp st.frameDepth st.mem
                (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) with ⟨flag, u_c⟩
              rw [hc] at hrun; dsimp only at hrun
              cases flag with
              | false =>
                  simp only [Bool.false_eq_true, ↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_inner inp fuel _ _ out
                    (.stmt_pos hfd .skip hrest) hbox hrun
              | true =>
                  simp only [↓reduceIte] at hrun
                  cases fuel with
                  | zero => simp [runArithRAMFuel] at hrun
                  | succ fuel' =>
                      simp only [runArithRAMFuel] at hrun
                      have hcond_t : cValAt st.frameDepth inp st.mem
                          (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) = true := by
                        rw [cValAt, hc]
                      simp only [cValAt_and, cValAt_intLe, cValAt_intLt, iValAt_lit,
                        Bool.and_eq_true, decide_eq_true_eq, iValAt] at hcond_t
                      exact runArithRAMFuel_preserves_box_inner inp fuel' rest _ out hrest
                        (heapOnlyInBox_wWrite _ hbox ht hcond_t.1 hcond_t.2) hrun
          | @boxR t ht idxE valE =>
              simp only [boxWriteR, runArithRAMFuel] at hrun
              rcases hc : evalArithCond inp st.frameDepth st.mem
                (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) with ⟨flag, u_c⟩
              rw [hc] at hrun; dsimp only at hrun
              cases flag with
              | false =>
                  simp only [Bool.false_eq_true, ↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_inner inp fuel _ _ out
                    (.stmt_pos hfd .skip hrest) hbox hrun
              | true =>
                  simp only [↓reduceIte] at hrun
                  cases fuel with
                  | zero => simp [runArithRAMFuel] at hrun
                  | succ fuel' =>
                      simp only [runArithRAMFuel] at hrun
                      have hcond_t : cValAt st.frameDepth inp st.mem
                          (.and (.intLe (.lit 0) idxE) (.intLt idxE (.lit (M_box : ℤ)))) = true := by
                        rw [cValAt, hc]
                      simp only [cValAt_and, cValAt_intLe, cValAt_intLt, iValAt_lit,
                        Bool.and_eq_true, decide_eq_true_eq, iValAt] at hcond_t
                      exact runArithRAMFuel_preserves_box_inner inp fuel' rest _ out hrest
                        (heapOnlyInBox_rWrite _ hbox ht hcond_t.1 hcond_t.2) hrun
          | seq h₁ h₂ =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_inner inp fuel _ _ out
                (.stmt_pos hfd h₁ (.stmt_pos hfd h₂ hrest)) hbox hrun
          | @ite c tB fB h₁ h₂ =>
              simp only [runArithRAMFuel] at hrun
              have hbr : BoxSafeInner T_max M_box
                  (if (evalArithCond inp st.frameDepth st.mem c).1 then tB else fB) := by
                split_ifs <;> assumption
              exact runArithRAMFuel_preserves_box_inner inp fuel _ _ out
                (.stmt_pos hfd hbr hrest) hbox hrun
          | whileLoop c hb =>
              simp only [runArithRAMFuel] at hrun
              rcases hc : evalArithCond inp st.frameDepth st.mem c with ⟨flag, u_c⟩
              rw [hc] at hrun; dsimp only at hrun
              cases flag with
              | false =>
                  simp only [Bool.false_eq_true, ↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_inner inp fuel rest _ out hrest hbox hrun
              | true =>
                  simp only [↓reduceIte] at hrun
                  exact runArithRAMFuel_preserves_box_inner inp fuel _ _ out
                    (.stmt_pos hfd hb (.stmt_pos hfd (.whileLoop c hb) hrest)) hbox hrun
          | repeatN cntE hb =>
              simp only [runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_inner inp fuel _ _ out
                (.repeat_pos hfd hb hrest) hbox hrun
          | localScope hb =>
              simp only [st, runArithRAMFuel] at hrun
              exact runArithRAMFuel_preserves_box_inner inp fuel _ _ out
                (.stmt_pos (by simp [st]) hb (.pop_succ hrest)) (heapOnlyInBox_popDepth fd hbox) hrun

/-- Running `.localScope body` from `mem₀` (`HeapOnlyInBox T_max M_box mem₀`, `mem₀.popDepth 0 = mem₀`)
on any halting bit list `bs` preserves `HeapOnlyInBox T_max M_box` and `popDepth 0` idempotence. -/
theorem runArithRAMWithBits_localScope_box {d T_max M_box : ℕ}
    {body : ArithRAMStmt} (hbody : BoxSafeInner T_max M_box body)
    {inp : ArithRAMInput d} {mem₀ : ArithRAMMemory} {bs : List Bool} {out : ArithRAMExecOutcome}
    (hbox₀ : HeapOnlyInBox T_max M_box mem₀)
    (hrun : runArithRAMWithBits (.localScope body) inp mem₀ bs = some out) :
    HeapOnlyInBox T_max M_box out.mem ∧ out.mem.popDepth 0 = out.mem := by
  classical
  unfold runArithRAMWithBits at hrun
  dsimp only at hrun
  split_ifs at hrun with hex
  generalize hr : runArithRAMFuel inp (Nat.find hex) [.stmt (.localScope body)] _ = res at hrun
  cases res with
  | needMoreBits | unusedBits | outOfFuel => simp at hrun
  | halted o =>
      have hout_eq : o = out := Option.some.inj hrun
      subst hout_eq
      exact ⟨runArithRAMFuel_preserves_box_inner inp (Nat.find hex) [.stmt (.localScope body)] _ o
               (.scope_zero hbody) (heapOnlyInBox_popDepth 0 hbox₀) hr,
             runArithRAMFuel_out_popDepth_zero inp (Nat.find hex) [.stmt (.localScope body)] _ o hr⟩

end UL.Proof_lem_7_2_RacerP46
