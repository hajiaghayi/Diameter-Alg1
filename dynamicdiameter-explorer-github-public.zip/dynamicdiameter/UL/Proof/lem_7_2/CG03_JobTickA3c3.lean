import UL.Proof.lem_7_2.CG03_JobTickA3c2

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

lemma MidLoopCut.congr_scratch {ctx : MidLoopCtx} {gFlag : Bool} {m m' : ArithRAMMemory}
    (hC : MidLoopCut ctx gFlag m)
    (hw27 : wRead m' 26 27 = wRead m 26 27)
    (hw_other : ∀ t, t ≠ 26 → ∀ idx, wRead m' t idx = wRead m t idx)
    (hr_other : ∀ t, t ≠ 26 → t ≠ 27 → ∀ idx, rRead m' t idx = rRead m t idx) :
    MidLoopCut ctx gFlag m' := by
  rcases hC with ⟨h27, st_mid, hu, hInv, hTerm, hEnc, hGood⟩
  rcases hEnc with ⟨hk_le, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, hNodes⟩
  rcases ctx.hV with ⟨_, _, _, _, _, _,
    hRes_bc, hRes_age, _, hRes_rem, hRes_cl,
    _, _, _, _, _, _, _, _, _, _,
    _, _, _, hRes_rO, hRes_rV⟩
  have hbc_ne26 := tag_ne_of_not_reserved (u := 26) hRes_bc (by decide)
  have hage_ne26 := tag_ne_of_not_reserved (u := 26) hRes_age (by decide)
  have hrem_ne26 := tag_ne_of_not_reserved (u := 26) hRes_rem (by decide)
  have hcl_ne26 := tag_ne_of_not_reserved (u := 26) hRes_cl (by decide)
  have hrO_ne26 := rtag_ne_of_not_reserved (u := 26) hRes_rO (by decide)
  have hrO_ne27 := rtag_ne_of_not_reserved (u := 27) hRes_rO (by decide)
  have hrV_ne26 := rtag_ne_of_not_reserved (u := 26) hRes_rV (by decide)
  have hrV_ne27 := rtag_ne_of_not_reserved (u := 27) hRes_rV (by decide)
  have hSegPres : ∀ s < ctx.p.NumSlots, ∀ S₁ fSq₁,
      EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁ :=
    fun _ _ _ _ hE => hE.congr_mem_fSq
      (hw_other 5 (by decide) _) (fun _ _ => hw_other 8 (by decide) _)
      (fun _ _ => hw_other 9 (by decide) _) (fun _ _ => hw_other 10 (by decide) _)
      (fun _ _ => hr_other 8 (by decide) (by decide) _) (fun _ _ => rfl)
  have hDisj' : GlobalSlotDisj ctx.p.D₀ m' st_mid.k leafS := by
    rcases hDisj with ⟨hlp, hsn0, hsnP, hlv_sn, hlv_lv⟩
    have hsn_eq : ∀ r, snSlotSet m' r = snSlotSet m r :=
      fun r => snSlotSet_congr_14_15 (hw_other 14 (by decide) _) (hw_other 15 (by decide) _)
    have h16_eq : ∀ r, wRead m' 16 (r : ℤ) = wRead m 16 (r : ℤ) := fun _ => hw_other 16 (by decide) _
    have h19_eq : ∀ r, wRead m' 19 (r : ℤ) = wRead m 19 (r : ℤ) := fun _ => hw_other 19 (by decide) _
    have h23_eq : ∀ idx, wRead m' 23 idx = wRead m 23 idx := fun _ => hw_other 23 (by decide) _
    have hlv_eq : ∀ idx sp, jobLevelLiveSlots m' idx sp = jobLevelLiveSlots m idx sp :=
      fun _ _ => jobLevelLiveSlots_congr_23 (h23_eq _) (h23_eq _) (h23_eq _) (h23_eq _)
    refine ⟨hlp,
      fun r hr s hs => by rw [hsn_eq] at hs; exact hsn0 r hr s hs,
      fun r₁ hr₁ r₂ hr₂ hne => by rw [hsn_eq, hsn_eq]; exact hsnP r₁ hr₁ r₂ hr₂ hne,
      fun r hr h16 j hj => ?_,
      fun r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne => ?_⟩
    · dsimp only
      rw [h16_eq r] at h16; rw [h19_eq r] at hj ⊢; rw [hlv_eq]
      rcases hlv_sn r hr h16 j hj with ⟨h0l, hd_sn⟩
      exact ⟨h0l, fun r' hr' => by rw [hsn_eq]; exact hd_sn r' hr'⟩
    · rw [h16_eq r₁] at h16₁; rw [h16_eq r₂] at h16₂
      rw [h19_eq r₁] at hj₁ ⊢; rw [h19_eq r₂] at hj₂ ⊢
      rw [hlv_eq, hlv_eq, h23_eq, h23_eq]
      exact hlv_lv r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne
  refine ⟨hw27.trans h27, st_mid, hu, hInv, hTerm, ?_, hGood⟩
  refine ⟨hk_le,
    ⟨by rw [hw_other 1 (by decide)]; exact hSeg.1,
     fun s hs => by rw [hw_other 5 (by decide), hw_other 1 (by decide)]; exact hSeg.2.1 s hs,
     fun s hs u hu => by rw [hw_other 8 (by decide), hw_other 1 (by decide)]; exact hSeg.2.2 s hs u hu⟩,
    ⟨by rw [hw_other 1 (by decide)]; exact hSave.1,
     fun s hs => by rw [hw_other 6 (by decide), hw_other 1 (by decide)]; exact hSave.2.1 s hs,
     fun s hs h hh => by rw [hw_other 11 (by decide), hw_other 1 (by decide)]; exact hSave.2.2 s hs h hh⟩,
    ⟨hLive.1, fun h hh c => by rw [hr_other 4 (by decide) (by decide)]; exact hLive.2 h hh c⟩,
    (hw_other 1 (by decide) _).trans h15,
    (hw_other 6 (by decide) _).trans h60,
    hSegPres 0 (by have := ctx.hSlots_cap; omega) _ _ hSeg0,
    leafS, hl0, hllt,
    (hw_other 1 (by decide) _).trans h16l,
    (hw_other 6 (by decide) _).trans h6l,
    hSegPres leafS hllt _ _ hSegL,
    hDisj', ?_⟩
  intro r
  exact ⟨(hNodes r).1.frame_other
      (hw_other _ hbc_ne26 _) (hw_other _ hage_ne26 _)
      (hw_other 14 (by decide) _) (hw_other 15 (by decide) _)
      (fun _ _ => hw_other 6 (by decide) _)
      (fun _ => hr_other _ hrO_ne26 hrO_ne27 _)
      (hr_other _ hrV_ne26 hrV_ne27 _)
      (fun s _ hlt _ _ hE => hSegPres s hlt _ _ hE),
    (hNodes r).2.frame_other
      (fun g _ => by rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2))
      (hw_other 16 (by decide) _) (hw_other _ hrem_ne26 _) (hw_other _ hcl_ne26 _)
      (hw_other 19 (by decide) _)
      (fun _ _ _ _ => hw_other 23 (by decide) _)
      (fun _ _ _ _ => hw_other 24 (by decide) _)
      (fun _ _ _ => hr_other 23 (by decide) (by decide) _)
      (fun _ _ _ _ => hr_other 24 (by decide) (by decide) _)
      (fun _ _ _ _ _ => hw_other 6 (by decide) _)
      (fun _ _ _ s _ hlt _ _ _ hE => hSegPres s hlt _ _ hE)
      (fun _ => hw_other 11 (by decide) _)
      (fun _ => hr_other 11 (by decide) (by decide) _)⟩

/-! ### 1. Pure Unaffected & Idle-Wait Step Promotions on `MidLoopUncut` -/

theorem midLoopUncut_step_idle_wait
    {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k) {m : ArithRAMMemory}
    (hU : MidLoopUncut ctx gFlag i m)
    (hnone : ctx.st₀.ownedJob ⟨i, hi⟩ = none)
    (hwait : ctx.snAge' ⟨i, hi⟩ <
      jobStartAge (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.st₀.birthSnap ⟨i, hi⟩).card) :
    MidLoopUncut ctx gFlag (i + 1) m := by
  rcases hU with ⟨h27, hGood₀, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, hDone, hTodo⟩
  refine ⟨h27, hGood₀, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, ?_, fun r hr => hTodo r (by omega)⟩
  intro r hr_lt
  by_cases hri : r.val = i
  · have hr_eq : r = ⟨i, hi⟩ := Fin.ext hri
    subst hr_eq
    rcases hTodo ⟨i, hi⟩ le_rfl with ⟨_, hHdr, _, hTd⟩
    unfold EncTodoJobAt at hTd
    rw [hnone] at hHdr hTd
    exact ⟨none, hwait, (fun _ _ h => by cases h), hHdr, hTd⟩
  · exact hDone r (by omega)

theorem midLoopUncut_step_unaffected
    {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k) {m : ArithRAMMemory}
    (hU : MidLoopUncut ctx gFlag i m)
    (haff_f : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = false) :
    MidLoopUncut ctx gFlag (i + 1) m := by
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  rcases (ctx.hPerNode r_fin).1 haff_f with ⟨hopH_not_pre, _, hSh_eq, hSu_eq⟩
  change ctx.S_post_h r_fin = ctx.S_pre_h r_fin at hSh_eq
  have hsn_eq : ctx.snAge' r_fin = ctx.st₀.snAge r_fin := by
    unfold MidLoopCtx.snAge'; rw [haff_f]; simp
  rcases hU with ⟨h27, hGood₀, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, hDone, hTodo⟩
  refine ⟨h27, hGood₀, hSeg, hSave, hLive, h15, h60, hSeg0,
    leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, ?_, fun r hr => hTodo r (by omega)⟩
  intro r hr_lt
  by_cases hri : r.val = i
  · have hr_eq : r = r_fin := Fin.ext hri
    subst hr_eq
    rcases hTodo r_fin le_rfl with ⟨_, hHdr, hGood_r, hTd⟩
    have hinv_r := (ctx.hwf₀.1 r_fin).2.2.2.2.2
    unfold EncTodoJobAt at hTd
    cases hoj : ctx.st₀.ownedJob r_fin with
    | none =>
        rw [hoj] at hinv_r hHdr hTd
        have hwait : ctx.snAge' r_fin <
            jobStartAge (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.st₀.birthSnap r_fin).card := by
          rw [hsn_eq]; exact hinv_r
        exact ⟨none, hwait, (fun _ _ h => by cases h), hHdr, hTd⟩
    | some g =>
        rw [hoj] at hinv_r hHdr hTd
        rcases hinv_r with ⟨ht_lt, hage_eq, hm0_le⟩
        let g_lift := (g.liftCoords ctx.hle_uid ctx.hag_uid).castPool hSu_eq.symm
        have hInv_new : ServingOwnedJobInv (ctx.st₀.birthSnap r_fin) (ctx.snAge' r_fin) (some g_lift) := by
          have h1 : ServingOwnedJobInv (ctx.st₀.birthSnap r_fin) (ctx.snAge' r_fin)
              (some (g.liftCoords ctx.hle_uid ctx.hag_uid)) := by
            refine ⟨ht_lt, ?_, hm0_le⟩
            rw [hsn_eq]; exact hage_eq
          exact (servingOwnedJobInv_castPool hSu_eq.symm _ _
            (some (g.liftCoords ctx.hle_uid ctx.hag_uid))).mpr h1
        have hGood_new : gFlag = true → ∀ g₁, some g_lift = some g₁ →
            JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g₁.lvs := by
          intro hgF g₁ hg₁
          injection hg₁ with hgeq; subst hgeq
          have hcg := hGood_r hgF g hoj
          have hlvs_eq : g_lift.lvs = g.lvs := by
            rfl
          intro j hj
          have hj_g : j < g.lvs.length := hlvs_eq ▸ hj
          have hball_eq : (g_lift.lvs[j]'hj) = (g.lvs[j]'hj_g) := by simp [hlvs_eq]
          rw [hball_eq]
          exact (isCenterpoint_paraboloid_congr_on _ _
            (fun u hu => ctx.hag_uid u ((g.hlvs_inv j hj_g).2.1 u hu))).mpr (hcg j hj_g)
        -- Lift EncTodoJobAt on g to EncOwnedJobAt on g.liftCoords, then castPool!
        rcases hTd with ⟨h16, hrem, hcl, h19, lvs_h, hlen_eq, hlv⟩
        have hsub_pre : ctx.S_pre_h r_fin ⊆ ctx.P.activeHandles :=
          cg01_chainInput_subset ctx.P.handleCoords ctx.st₀.nodes ctx.P.activeHandles r_fin.castSucc
        have hpts_pre : ∀ x ∈ ctx.S_pre_h r_fin,
            ctx.P'.handleCoords x = bridgeHandleCoords ctx.P ctx.P' x := by
          intro x hx
          have hne_opH : x ≠ ctx.opH := fun heq => hopH_not_pre (heq ▸ hx)
          rw [bridgeHandleCoords_eq_pre (hsub_pre hx)]
          exact (ctx.hcoords_ne x (hsub_pre hx) hne_opH).2
        have hpts_pre_P : ∀ x ∈ ctx.S_pre_h r_fin,
            ctx.P'.handleCoords x = ctx.P.handleCoords x := by
          intro x hx
          exact (ctx.hcoords_ne x (hsub_pre hx) (fun heq => hopH_not_pre (heq ▸ hx))).2
        have hOwn_pre : EncOwnedJobAt ctx.cfg ctx.p m ctx.P' ctx.uMap' r_fin.val
            (ctx.S_post_h r_fin) (ctx.S_pre_u r_fin)
            (some (g.liftCoords ctx.hle_uid ctx.hag_uid)) := by
          refine ⟨h16, hrem, hcl, h19, lvs_h, hlen_eq, ?_⟩
          intro j hj
          have hj_g : j < g.lvs.length := hlen_eq ▸ hj
          rcases hlv j hj with ⟨hb_eq, hor_eq, ⟨f_b, g_b, hf_b, hg_b⟩,
            hEnc, hw7, hp2, hp3, hp4, hp5, hp6, hpre2, hlast⟩
          have hinput_br : jobHandleInput (ctx.d + 3) (bridgeHandleCoords ctx.P ctx.P') lvs_h (ctx.S_pre_h r_fin) j =
              jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) j := by
            rw [hSh_eq]
            exact jobHandleInput_congr_pts (ctx.d + 3) lvs_h (ctx.S_pre_h r_fin)
              (fun x hx => (hpts_pre x hx).symm) j
          have hinput_P : jobHandleInput (ctx.d + 3) ctx.P.handleCoords lvs_h (ctx.S_pre_h r_fin) j =
              jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) j := by
            rw [hSh_eq]
            exact jobHandleInput_congr_pts (ctx.d + 3) lvs_h (ctx.S_pre_h r_fin)
              (fun x hx => (hpts_pre_P x hx).symm) j
          have hEnc' : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m
              ctx.P'.activeHandles ctx.P'.handleCoords (r_fin.val * ctx.p.D₀ + j)
              (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
              (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) j)
              (decide (j + 1 = lvs_h.length)) := by
            rw [← hinput_br]
            exact hEnc.frame_slotSet
              (fun x hx => hpts_pre x (jobHandleInput_subset (ctx.d + 3) _ _ _ _ hx))
              (fun _ hh => (bridgeHandleCoords_eq_post ctx.hcoords_root hh).symm)
              (fun _ _ _ _ _ _ hE => hE) (fun _ _ => rfl) (fun _ => rfl) (fun _ => rfl)
              (fun _ _ => rfl) (fun _ _ => rfl) (fun _ => rfl) (fun _ _ => rfl)
          refine ⟨hb_eq, hor_eq,
            ⟨f_b, g_b,
              fun h hh => by
                rcases hf_b h hh with ⟨hmem_u, hcoord_u, hinv_fb⟩
                exact ⟨hmem_u,
                  (ctx.hag_uid (f_b h) ((g.hlvs_inv j hj_g).2.1 (f_b h) hmem_u)).trans hcoord_u,
                  hinv_fb⟩,
              hg_b⟩,
            hEnc', hw7, hp2, hp3, hp4, hp5, hp6, hpre2,
            fun heq => ⟨(hlast heq).1, (hlast heq).2.1, (hlast heq).2.2.trans hinput_P⟩⟩
        exact ⟨some g_lift, hInv_new, hGood_new, hHdr, hOwn_pre.castPool hSu_eq.symm⟩
  · exact hDone r (by omega)


/-! ### 2. Execution of `idleAffectedNodeStmt` -/

theorem exec_idleAffectedNodeStmt
    (h_lem_5_1 : S_lem_5_1)
    (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k) {m : ArithRAMMemory}
    (hpop : m.popDepth 0 = m)
    (hw15_reg : wRead m 26 15 = (i : ℤ))
    (hU : MidLoopUncut ctx gFlag i m)
    (haff : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = true)
    (hnone : ctx.st₀.ownedJob ⟨i, hi⟩ = none) :
    RandExecBad inp
      (idleAffectedNodeStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p)
      ctx.p.B_hpj m
      (fun m' =>
        wRead m' 0 0 = wRead m 0 0 ∧
        wRead m' 26 13 = wRead m 26 13 ∧
        wRead m' 26 14 = wRead m 26 14 ∧
        wRead m' 26 15 = (i : ℤ) ∧
        wRead m' 26 28 = wRead m 26 28 ∧
        (MidLoopUncut ctx false (i + 1) m' ∨ MidLoopCut ctx false m'))
      (fun m' =>
        gFlag = true → (MidLoopUncut ctx true (i + 1) m' ∨ MidLoopCut ctx true m'))
      (2 * ctx.p.φ_ev)
      (idleAffectedNodeCost ctx.d ctx.n ctx.cfg ctx.p) := by
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  have hD : 3 ≤ ctx.d + 3 := by omega
  have hi_D0 : i < ctx.p.D₀ := lt_trans hi ctx.origK_lt_D0
  have hi_box : i < ctx.M_box :=
    lt_of_lt_of_le (lt_of_lt_of_le hi_D0 (by have := ctx.hSlots_cap; nlinarith)) ctx.hBox_slots
  let α : ℝ := 1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)
  have hinv_r := (ctx.hwf₀.1 r_fin).2.2.2.2.2
  rw [hnone] at hinv_r
  change ctx.st₀.snAge r_fin < jobStartAge α (ctx.st₀.birthSnap r_fin).card at hinv_r
  have hsn_eq : ctx.snAge' r_fin = ctx.st₀.snAge r_fin + 1 := by
    unfold MidLoopCtx.snAge'; rw [if_pos haff]
  have hU_copy := hU
  rcases hU_copy with ⟨_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, hTodo_m⟩
  rcases (hTodo_m r_fin le_rfl).2.1 with
    ⟨dS_i, spS_i, _, _, _, _, _, _, hbc_i, hage_i, hw14_i, hw15_i, _, _, _, _, hSegDi, _, _⟩
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let ageE : IntExpr := ctx.cfg.snAge.readE rE
  let startAgeE : IntExpr := .div (ctx.cfg.snBirthCard.readE rE) (.lit (((256 * ctx.p.D ^ 2 : ℕ) : ℤ)))
  have hval_age : iValAt 0 inp m ageE = (ctx.snAge' r_fin : ℤ) := by
    dsimp only [ageE, rE]
    simp only [HdrField.readE, HdrField.idxE, iValAt_readHeap, iValAt_add, iValAt_mul, iValAt_lit, hw15_reg]
    have hidx : (((ctx.cfg.snAge.stride : ℤ) * (i : ℤ) + (ctx.cfg.snAge.off : ℤ)) : ℤ) =
        ((ctx.cfg.snAge.idx i : ℕ) : ℤ) := by unfold HdrField.idx; push_cast; rfl
    rw [hidx, hage_i]
  have hval_start : iValAt 0 inp m startAgeE =
      ((jobStartAge α (ctx.st₀.birthSnap r_fin).card : ℕ) : ℤ) := by
    simp only [startAgeE, iValAt_div, iValAt_lit, HdrField.readE, HdrField.idxE, HdrField.idx,
      iValAt_readHeap, iValAt_add, iValAt_mul, rE, hw15_reg, hbc_i, ctx.hD_eq]
    have hidx : (((ctx.cfg.snBirthCard.stride : ℤ) * (i : ℤ) + (ctx.cfg.snBirthCard.off : ℤ)) : ℤ) =
        ((ctx.cfg.snBirthCard.idx i : ℕ) : ℤ) := by unfold HdrField.idx; push_cast; rfl
    rw [hidx, hbc_i, ← Int.natCast_ediv, ← jobStartAge_eq_nat (ctx.d + 3) hD (ctx.st₀.birthSnap r_fin).card]
  unfold idleAffectedNodeStmt
  by_cases hlt_st : ctx.snAge' r_fin < jobStartAge α (ctx.st₀.birthSnap r_fin).card
  · -- Branch 1: snAge' < jobStartAge
    have hc_true : cValAt 0 inp m (.intLt ageE startAgeE) = true := by
      rw [cValAt_intLt, hval_age, hval_start]; simp only [decide_eq_true_eq]
      exact_mod_cast hlt_st
    have hDum := exec_dummyHPJStmt ctx.p inp m hpop (Nat.le_trans (by decide : 1 ≤ 30) ctx.hBox30) (le_of_lt ctx.hφ0)
    refine (RandExecBad.ite_true hc_true (C_c := 35)
      (by dsimp [ageE, startAgeE, rE, condExprOps, HdrField.readE, HdrField.idxE, intExprOps]; omega) hDum).mono
      ?_ ?_ le_rfl (by unfold idleAffectedNodeCost hpjFreezeRunInitCost; dsimp only; omega)
    · intro m' hm'
      subst hm'
      have hU' : MidLoopUncut ctx gFlag i (wWrite m 26 0 0) :=
        hU.congr_scratch (wRead_wWrite_of_ne _ _ (Or.inr (by decide)))
          (fun t ht _ => wRead_wWrite_of_ne _ _ (Or.inl ht))
          (fun t _ _ idx => rRead_wWrite m t 26 idx 0 0)
      exact ⟨wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hw15_reg,
        wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        Or.inl (midLoopUncut_step_idle_wait hi hU'.to_false hnone hlt_st)⟩
    · intro m' hm' _ hgF
      subst hm'; subst hgF
      have hU' : MidLoopUncut ctx true i (wWrite m 26 0 0) :=
        hU.congr_scratch (wRead_wWrite_of_ne _ _ (Or.inr (by decide)))
          (fun t ht _ => wRead_wWrite_of_ne _ _ (Or.inl ht))
          (fun t _ _ idx => rRead_wWrite m t 26 idx 0 0)
      exact Or.inl (midLoopUncut_step_idle_wait hi hU' hnone hlt_st)
  · -- Branch 2: snAge' = jobStartAge
    have heq_st : ctx.snAge' r_fin = jobStartAge α (ctx.st₀.birthSnap r_fin).card := by omega
    have hc_false : cValAt 0 inp m (.intLt ageE startAgeE) = false := by
      rw [cValAt_intLt, hval_age, hval_start]; simp only [decide_eq_false_iff_not, not_lt]
      exact_mod_cast le_of_eq heq_st.symm
    rcases exec_readSlotCardTo24Stmt inp m (.readHeap 14 rE) (Nat.le_trans (by decide : 25 ≤ 30) ctx.hBox30)
        (by rw [hpop]; dsimp only [rE]; rw [iValAt_readHeap, iValAt_readHeap, iValAt_lit, hw15_reg]; exact hw14_i) hSegDi
      with ⟨m_c, hd_card, hpop_c, hw24_c, hw_oth_c, hw26_c, hr_c⟩
    have hw15_c : wRead m_c 26 15 = (i : ℤ) := (hw26_c 15 (by decide)).trans hw15_reg
    have hU_c : MidLoopUncut ctx gFlag i m_c :=
      hU.congr_scratch (hw26_c 27 (by decide)) hw_oth_c (fun _ _ _ _ => hr_c _ _)
    by_cases hlarge : 4 * ctx.p.L < (ctx.S_post_h r_fin).card
    · -- Branch 2a: Launch job!
      have hc_lg : cValAt 0 inp m_c (.intLt (.lit (((4 * ctx.p.L : ℕ) : ℤ))) (.readHeap 26 (.lit 24))) = true := by
        rw [cValAt_intLt, iValAt_lit, iValAt_readHeap, iValAt_lit, hw24_c]; simp only [decide_eq_true_eq]
        exact_mod_cast hlarge
      have hLaunch := exec_launchPendingJobAtRStmt h_lem_5_1 ctx inp hi hpop_c hw15_c hU_c haff hnone heq_st hlarge
      refine (RandExecBad.ite_false hc_false (C_c := 35)
        (by dsimp [ageE, startAgeE, rE, condExprOps, HdrField.readE, HdrField.idxE, intExprOps]; omega)
        (RandExecBad.seq_det_left hpop hpop_c hd_card
          (RandExecBad.ite_true hc_lg (C_c := 15) (by simp [condExprOps, intExprOps]) hLaunch))).mono
        ?_ ?_ le_rfl (by unfold idleAffectedNodeCost; dsimp only [rE]; simp [intExprOps]; omega)
      · intro m' ⟨h0, h13, h14, h15, h28, hU'⟩
        exact ⟨h0.trans (hw_oth_c 0 (by decide) _),
          h13.trans (hw26_c 13 (by decide)),
          h14.trans (hw26_c 14 (by decide)),
          h15,
          h28.trans (hw26_c 28 (by decide)),
          Or.inl hU'⟩
      · intro m' _ hG hgF
        exact Or.inl (hG hgF)
    · -- Branch 2b: Truncate small!
      have hsmall : (ctx.S_post_h r_fin).card ≤ 4 * ctx.p.L := by omega
      have hc_sm : cValAt 0 inp m_c (.intLt (.lit (((4 * ctx.p.L : ℕ) : ℤ))) (.readHeap 26 (.lit 24))) = false := by
        rw [cValAt_intLt, iValAt_lit, iValAt_readHeap, iValAt_lit, hw24_c]; simp only [decide_eq_false_iff_not, not_lt]
        exact_mod_cast hsmall
      let t1 := wWrite m_c 1 6 (wRead m_c 15 (i : ℤ))
      have ht1_p : t1.popDepth 0 = t1 := wWrite_popDepth_zero hpop_c 1 6 _
      have et1 : DetExecAt 0 inp (boxWriteW ctx.M_box 1 (.lit 6) (.readHeap 15 rE)) m_c t1 18 :=
        exec_boxWriteW inp m_c _ _ rfl (by omega) (by have h := ctx.hBox30; omega)
          (by dsimp [rE]; simp [hw15_c]) (by dsimp [rE, intExprOps]; omega)
      let t2 := wWrite t1 1 5 (i : ℤ)
      have ht2_p : t2.popDepth 0 = t2 := wWrite_popDepth_zero ht1_p 1 5 _
      have et2 : DetExecAt 0 inp (boxWriteW ctx.M_box 1 (.lit 5) rE) t1 t2 16 :=
        exec_boxWriteW inp t1 _ _ rfl (by omega) (by have h := ctx.hBox30; omega)
          (by dsimp only [t1, rE]; rw [iValAt_readHeap, iValAt_lit, wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hw15_c])
          (by dsimp [rE, intExprOps]; omega)
      let t3 := wWrite t2 26 27 1
      have ht3_p : t3.popDepth 0 = t3 := wWrite_popDepth_zero ht2_p 26 27 _
      have et3 : DetExecAt 0 inp (boxWriteW ctx.M_box 26 (.lit 27) (.lit 1)) t2 t3 14 :=
        exec_boxWriteW inp t2 _ _ rfl (by omega) (by have h := ctx.hBox30; omega) rfl (by simp [intExprOps])
      have hDum := exec_dummyHPJStmt ctx.p inp t3 ht3_p (Nat.le_trans (by decide : 1 ≤ 30) ctx.hBox30) (le_of_lt ctx.hφ0)
      have hBr2 := RandExecBad.seq_det_left hpop_c ht1_p et1
        (RandExecBad.seq_det_left ht1_p ht2_p et2
          (RandExecBad.seq_det_left ht2_p ht3_p et3 hDum))
      refine (RandExecBad.ite_false hc_false (C_c := 35)
        (by dsimp [ageE, startAgeE, rE, condExprOps, HdrField.readE, HdrField.idxE, intExprOps]; omega)
        (RandExecBad.seq_det_left hpop hpop_c hd_card
          (RandExecBad.ite_false hc_sm (C_c := 15) (by simp [condExprOps, intExprOps]) hBr2))).mono
        ?_ ?_ le_rfl (by unfold idleAffectedNodeCost hpjFreezeRunInitCost; dsimp only [rE]; simp [intExprOps]; omega)
      · intro m' hm'
        subst hm'
        have hCut : MidLoopCut ctx gFlag (wWrite t3 26 0 0) :=
          midLoopCut_of_truncateSmall hi hU_c hnone hsmall
            (by dsimp only [t3]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
            (by dsimp only [t3, t2]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self])
            (by dsimp only [t3, t2, t1]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
            (by dsimp only [t3, t2, t1]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide))])
            (fun tb h1 h26 idx => by dsimp only [t3, t2, t1]; rw [wRead_wWrite_of_ne _ _ (Or.inl h26), wRead_wWrite_of_ne _ _ (Or.inl h26), wRead_wWrite_of_ne _ _ (Or.inl h1), wRead_wWrite_of_ne _ _ (Or.inl h1)])
            (fun tb _ idx => by dsimp only [t3, t2, t1]; rw [rRead_wWrite, rRead_wWrite, rRead_wWrite, rRead_wWrite])
        refine ⟨?_, ?_, ?_, ?_, ?_, Or.inr hCut.to_false⟩
        · dsimp only [t3, t2, t1]
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              hw_oth_c 0 (by decide)]
        · dsimp only [t3, t2, t1]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              hw26_c 13 (by decide)]
        · dsimp only [t3, t2, t1]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              hw26_c 14 (by decide)]
        · dsimp only [t3, t2, t1]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hw15_c]
        · dsimp only [t3, t2, t1]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              hw26_c 28 (by decide)]
      · intro m' hm' _ hgF
        subst hm'; subst hgF
        exact Or.inr (midLoopCut_of_truncateSmall hi hU_c hnone hsmall
          (by dsimp only [t3]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
          (by dsimp only [t3, t2]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self])
          (by dsimp only [t3, t2, t1]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
          (by dsimp only [t3, t2, t1]; rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide))])
          (fun tb h1 h26 idx => by dsimp only [t3, t2, t1]; rw [wRead_wWrite_of_ne _ _ (Or.inl h26), wRead_wWrite_of_ne _ _ (Or.inl h26), wRead_wWrite_of_ne _ _ (Or.inl h1), wRead_wWrite_of_ne _ _ (Or.inl h1)])
          (fun tb _ idx => by dsimp only [t3, t2, t1]; rw [rRead_wWrite, rRead_wWrite, rRead_wWrite, rRead_wWrite]))

end UL.Proof_lem_7_2_RacerP46
