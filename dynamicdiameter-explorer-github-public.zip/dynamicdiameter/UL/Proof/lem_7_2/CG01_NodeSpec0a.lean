import UL.Proof.lem_7_2.CG14_MidTickA1b
import UL.Proof.lem_7_2.CG18_JobTickA1

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### Stage 2a: Pure Post-EndAction Builders (`ActivePropBuildState → PostEndActionJobState`) -/

lemma cg01_activePropBuild_gc_hyps
    {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ} {hi : i < ctx.st₀.k}
    {g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩)}
    {m₁ : ArithRAMMemory}
    (pb : ActivePropBuildState ctx gFlag i hi g₀ m₁) :
    ctx.st₀.k ≤ ctx.p.D₀ ∧
    wRead m₁ 1 5 = (ctx.st₀.k : ℤ) ∧
    (∀ r < ctx.st₀.k, ∃ (dS spS : ℕ), dS < ctx.p.NumSlots ∧ spS < ctx.p.NumSlots ∧
      wRead m₁ 14 (r : ℤ) = (dS : ℤ) ∧ wRead m₁ 15 (r : ℤ) = (spS : ℤ)) ∧
    (∀ r < ctx.st₀.k, wRead m₁ 16 (r : ℤ) = 1 →
      ∃ jLen ≤ ctx.p.D₀, wRead m₁ 19 (r : ℤ) = (jLen : ℤ) ∧
        ∀ j < jLen, ∃ (s2 s3 s4 s5 s6 : ℕ),
          s2 < ctx.p.NumSlots ∧ s3 < ctx.p.NumSlots ∧ s4 < ctx.p.NumSlots ∧
          s5 < ctx.p.NumSlots ∧ s6 < ctx.p.NumSlots ∧
          wRead m₁ 23 (((8 * (r * ctx.p.D₀ + j) + 2 : ℕ) : ℤ)) = (s2 : ℤ) ∧
          wRead m₁ 23 (((8 * (r * ctx.p.D₀ + j) + 3 : ℕ) : ℤ)) = (s3 : ℤ) ∧
          wRead m₁ 23 (((8 * (r * ctx.p.D₀ + j) + 4 : ℕ) : ℤ)) = (s4 : ℤ) ∧
          wRead m₁ 23 (((8 * (r * ctx.p.D₀ + j) + 5 : ℕ) : ℤ)) = (s5 : ℤ) ∧
          wRead m₁ 23 (((8 * (r * ctx.p.D₀ + j) + 6 : ℕ) : ℤ)) = (s6 : ℤ)) := by
  refine ⟨le_of_lt ctx.origK_lt_D0, pb.hw1_5, ?_, ?_⟩
  · intro r hr
    rcases Nat.lt_trichotomy r i with hlt | rfl | hgt
    · rcases pb.hDone ⟨r, hr⟩ hlt with ⟨_, _, _, ⟨dS, spS, _, _, hd, _, hsp, _, _, _, e14, e15, _⟩, _⟩
      exact ⟨dS, spS, hd, hsp, e14, e15⟩
    · rcases pb.hHdr_i with ⟨dS, spS, _, _, hd, _, hsp, _, _, _, e14, e15, _⟩
      exact ⟨dS, spS, hd, hsp, e14, e15⟩
    · rcases (pb.hTodoGt ⟨r, hr⟩ hgt).2.1 with ⟨dS, spS, _, _, hd, _, hsp, _, _, _, e14, e15, _⟩
      exact ⟨dS, spS, hd, hsp, e14, e15⟩
  · intro r hr h16
    rcases Nat.lt_trichotomy r i with hlt | rfl | hgt
    · rcases pb.hDone ⟨r, hr⟩ hlt with ⟨oj, _, _, _, hO⟩
      cases hoj : oj with
      | none => rw [hoj] at hO; change wRead m₁ 16 (r : ℤ) = 0 at hO; omega
      | some g₁ =>
          rw [hoj] at hO; rcases hO with ⟨_, _, _, hw19, lh, heq, hlv⟩
          refine ⟨g₁.lvs.length, by rw [ctx.hD0_eq]; exact le_of_lt (g₁.lvs_length_lt ctx.hH5 ctx.hn2), hw19, fun j hj => ?_⟩
          rcases (hlv j (heq ▸ hj)).2.2.2.1 with ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, _, _, _, _, _, _, _, _, _, _, e2, e3, e4, e5, e6, _⟩
          exact ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, e2, e3, e4, e5, e6⟩
    · rcases pb.hJob_i with ⟨lh, heq, _, _, _, _, _, hlv, _, _⟩
      refine ⟨g₀.lvs.length, by rw [ctx.hD0_eq]; exact le_of_lt (g₀.lvs_length_lt ctx.hH5 ctx.hn2), pb.hw19_i, fun j hj => ?_⟩
      rcases (hlv j (heq ▸ hj)).2.2.2.1 with ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, _, _, _, _, _, _, _, _, _, _, e2, e3, e4, e5, e6, _⟩
      exact ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, e2, e3, e4, e5, e6⟩
    · have hT := (pb.hTodoGt ⟨r, hr⟩ hgt).2.2.2
      unfold EncTodoJobAt at hT
      cases hoj : ctx.st₀.ownedJob ⟨r, hr⟩ with
      | none => rw [hoj] at hT; change wRead m₁ 16 (r : ℤ) = 0 at hT; omega
      | some g₁ =>
          rw [hoj] at hT; rcases hT with ⟨_, _, _, hw19, lh, heq, hlv⟩
          refine ⟨g₁.lvs.length, by rw [ctx.hD0_eq]; exact le_of_lt (g₁.lvs_length_lt ctx.hH5 ctx.hn2), hw19, fun j hj => ?_⟩
          rcases (hlv j (heq ▸ hj)).2.2.2.1 with ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, _, _, _, _, _, _, _, _, _, _, e2, e3, e4, e5, e6, _⟩
          exact ⟨bS, dS, spDS, rS, spRS, hb, hd, hsd, hr_s, hsr, e2, e3, e4, e5, e6⟩

lemma cg01_lift_jobLevelsCenterGood
    {ctx : MidLoopCtx} {S_u : Finset ℕ}
    (g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords S_u)
    (hGood : JobLevelsCenterGood (ctx.d + 3) ctx.st₀.uMap.ghostCoords g₀.lvs) :
    JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g₀.lvs := by
  intro j hj
  have huid : ∀ u ∈ (g₀.lvs[j]'hj).birthSnapshot, u < ctx.st₀.uMap.nextUid :=
    (g₀.hlvs_inv j hj).2.1
  exact (isCenterpoint_paraboloid_congr_on _ _
    (fun u hu => ctx.hag_uid u (huid u hu))).mpr (hGood j hj)

lemma cg01_curRes_bij
    (ctx : MidLoopCtx) {i : ℕ} (hi : i < ctx.st₀.k)
    (lvs_h : List (JobLvData ctx.d))
    (lvs_u : List (OpenedJobLevel ctx.d ℕ))
    (hlen : lvs_h.length = lvs_u.length)
    (hballs : ∀ (j : ℕ) (hj : j < lvs_h.length),
      (lvs_h[j]'hj).ball (ctx.d + 3) = (lvs_u[j]'(hlen ▸ hj)).ball) :
    let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
    let curRes_h := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
      (ctx.S_post_h r_fin) lvs_h.length
    let curRes_u := prefixResidual ctx.uMap'.ghostCoords lvs_u (ctx.S_post_u r_fin)
    curRes_h ⊆ ctx.P'.activeHandles ∧
    (∀ h ∈ curRes_h,
      ctx.uMap'.uidOfH h ∈ curRes_u ∧
      ctx.uMap'.ghostCoords (ctx.uMap'.uidOfH h) = ctx.P'.handleCoords h ∧
      ctx.uMap'.hOfUid (ctx.uMap'.uidOfH h) = h) ∧
    (∀ u ∈ curRes_u,
      ctx.uMap'.hOfUid u ∈ curRes_h ∧
      ctx.uMap'.uidOfH (ctx.uMap'.hOfUid u) = u) ∧
    curRes_h.card = curRes_u.card := by
  intro r_fin curRes_h curRes_u
  have hsub_root : ctx.S_post_h r_fin ⊆ ctx.P'.activeHandles :=
    cg01_chainInput_subset ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles r_fin.castSucc
  have hsub_cur : curRes_h ⊆ ctx.P'.activeHandles :=
    (jobHandleInput_subset (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) lvs_h.length).trans
      hsub_root
  have hmap_eq : ctx.uMap'.mapSet (ctx.S_post_h r_fin) = ctx.S_post_u r_fin :=
    ctx.uMap'.mapSet_chainInput ctx.st₀.nodes r_fin.castSucc
  have hbij_root := ctx.uMap'.mapSet_bij hsub_root
  have hf0 : ∀ h ∈ ctx.S_post_h r_fin,
      ctx.uMap'.uidOfH h ∈ ctx.S_post_u r_fin ∧
      ctx.uMap'.ghostCoords (ctx.uMap'.uidOfH h) = ctx.P'.handleCoords h ∧
      ctx.uMap'.hOfUid (ctx.uMap'.uidOfH h) = h :=
    fun h hh => hmap_eq ▸ hbij_root.2.2.1 h hh
  have hg0 : ∀ u ∈ ctx.S_post_u r_fin,
      ctx.uMap'.hOfUid u ∈ ctx.S_post_h r_fin ∧
      ctx.uMap'.uidOfH (ctx.uMap'.hOfUid u) = u :=
    fun u hu => hbij_root.2.2.2 u (hmap_eq.symm ▸ hu)
  have hbij_end := jobHandleInput_bij_prefixResidual (ctx.d + 3)
    ctx.P'.handleCoords ctx.uMap'.ghostCoords ctx.uMap'.uidOfH ctx.uMap'.hOfUid
    lvs_h lvs_u (ctx.S_post_h r_fin) (ctx.S_post_u r_fin)
    hlen hballs hf0 hg0 le_rfl
  have htake_all : lvs_u.take lvs_h.length = lvs_u := by
    rw [hlen, List.take_length]
  rw [htake_all] at hbij_end
  exact ⟨hsub_cur, hbij_end.1, hbij_end.2.1, hbij_end.2.2⟩

/-- Pure post-action builder for `.waitOrBuild` and `.closeLeaf` (where `lvs` length is unchanged
and only `jobRem`, `jobClosed`, and scratch tag `26` change between `m₁` and `m₂`). -/
theorem cg01_postEndAction_of_waitOrClose
    (h_lem_5_1 : S_lem_5_1)
    {ctx : MidLoopCtx} {gFlag b : Bool} {i : ℕ} (hi : i < ctx.st₀.k)
    {g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩)}
    {m₁ m₂ : ArithRAMMemory}
    {lvs_h : List (JobLvData ctx.d)} {hlen_eq : lvs_h.length = g₀.lvs.length}
    {ph' scan' : ℕ}
    (pb : ActivePropBuildState ctx gFlag i hi g₀ m₁)
    (haff : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = true)
    (hsome : ctx.st₀.ownedJob ⟨i, hi⟩ = some g₀)
    (hph'_le : ph' ≤ 2)
    (hw24_0 : wRead m₁ 24 (((2 * (i * ctx.p.D₀ + (g₀.lvs.length - 1)) + 0 : ℕ) : ℤ)) = (ph' : ℤ))
    (hw24_1 : wRead m₁ 24 (((2 * (i * ctx.p.D₀ + (g₀.lvs.length - 1)) + 1 : ℕ) : ℤ)) = (scan' : ℤ))
    (hlv_all : ∀ (j : ℕ) (hj : j < lvs_h.length),
      let idx := i * ctx.p.D₀ + j
      let hj_g : j < g₀.lvs.length := hlen_eq ▸ hj
      (lvs_h[j]'hj).ball (ctx.d + 3) = (g₀.lvs[j]'hj_g).ball ∧
      (lvs_h[j]'hj).openRem = g₀.openRem j ∧
      (∃ (f_b g_b : ℕ → ℕ),
        (∀ h ∈ (lvs_h[j]'hj).S_birth,
          f_b h ∈ (g₀.lvs[j]'hj_g).birthSnapshot ∧
          ctx.uMap'.ghostCoords (f_b h) = (lvs_h[j]'hj).snapPts h ∧
          g_b (f_b h) = h) ∧
        (∀ u ∈ (g₀.lvs[j]'hj_g).birthSnapshot,
          g_b u ∈ (lvs_h[j]'hj).S_birth ∧
          f_b (g_b u) = u)) ∧
      EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₁
        ctx.P'.activeHandles ctx.P'.handleCoords idx
        (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
        (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) j)
        (decide (j + 1 = lvs_h.length)) ∧
      wRead m₁ 23 (((8 * idx + 7 : ℕ) : ℤ)) = (g₀.openRem j : ℤ) ∧
      0 < (wRead m₁ 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 3 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 4 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 5 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat ∧
      (j + 1 < lvs_h.length → wRead m₁ 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2))
    (hpar_1 :
      let Spar_last_h' := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) (g₀.lvs.length - 1)
      Spar_last_h'.card ≤ g₀.Spar_last_h.card + 1 ∧
      ∀ c : ℕ, (Spar_last_h'.filter (fun x => c ≤ x)).card ≤
               (g₀.Spar_last_h.filter (fun x => c ≤ x)).card + 1)
    (hbuild_1 :
      let Spar_last_h' := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) (g₀.lvs.length - 1)
      let m_last := (g₀.lvs[g₀.lvs.length - 1]'(Nat.sub_lt g₀.hlvs_pos Nat.one_pos)).birthSnapshot.card
      (g₀.ph_cur = 0 →
        (g₀.scan_cur + (ctx.p.B_scan + 1) < m_last → ph' = 0 ∧ scan' = g₀.scan_cur + (ctx.p.B_scan + 1)) ∧
        (m_last ≤ g₀.scan_cur + (ctx.p.B_scan + 1) → ph' = 1 ∧ scan' = 0)) ∧
      (g₀.ph_cur = 1 →
        ph' = 2 ∨
        (ph' = 1 ∧
          (Spar_last_h'.filter (fun x => scan' ≤ x)).card + ctx.p.B_scan ≤
            (g₀.Spar_last_h.filter (fun x => g₀.scan_cur ≤ x)).card)) ∧
      (g₀.ph_cur = 2 → ph' = 2))
    (act : JobTickEndAction ctx.d (ctx.d + 3) ctx.p.L ctx.uMap'.ghostCoords
      (g₀.H_job - (g₀.t_cur + 1)) g₀.closed ph'
      (prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u ⟨i, hi⟩)))
    (hact_wc : (∃ hq, act = .waitOrBuild hq) ∨ (∃ h1 h2 h3 h4, act = .closeLeaf h1 h2 h3 h4))
    (closed_out : Bool)
    (hcl_eq : closed_out = (match act with | .waitOrBuild _ => g₀.closed | .closeLeaf _ _ _ _ => true | .openLevel .. => false))
    (hw27_2 : wRead m₂ 26 27 = 0)
    (hwRem_i2 : wRead m₂ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) =
      (((g₀.H_job - (g₀.t_cur + 1) : ℕ) : ℤ)))
    (hwRem_ne2 : ∀ r ≠ i, wRead m₂ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) =
      wRead m₁ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ))
    (hwCl_i2 : wRead m₂ ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx i : ℤ) =
      (if closed_out then 1 else 0))
    (hwCl_ne2 : ∀ r ≠ i, wRead m₂ ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ) =
      wRead m₁ ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ))
    (hw_other : ∀ t, t ≠ 26 → t ≠ ctx.cfg.jobRem.tag → t ≠ ctx.cfg.jobClosed.tag →
      ∀ idx, wRead m₂ t idx = wRead m₁ t idx)
    (hw_bc2 : ∀ r, wRead m₂ ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ) =
      wRead m₁ ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ))
    (hw_age2 : ∀ r, wRead m₂ ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ) =
      wRead m₁ ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ))
    (hw_aff2 : ∀ r, wRead m₂ ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ) =
      wRead m₁ ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ))
    (hr_all : ∀ t idx, rRead m₂ t idx = rRead m₁ t idx)
    (hb_imp : b = true → gFlag = true) :
    ∃ g' : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
        ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u ⟨i, hi⟩),
      PostEndActionJobState ctx b i hi m₂ g' := by
  classical
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  have hD : 3 ≤ ctx.d + 3 := by omega
  rcases ctx.hwf₀.1 r_fin with ⟨_, _, _, _, _, hjob0⟩
  rw [hsome] at hjob0
  rcases hjob0 with ⟨ht_lt, hage0_eq, hm0_le0⟩
  rcases ((ctx.hPerNode r_fin).2 haff).2.2.2.2 with ⟨ev_r, hev_ck, hev_v⟩
  have hsub_post : ctx.S_post_h r_fin ⊆ ctx.P'.activeHandles :=
    cg01_chainInput_subset ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles r_fin.castSucc
  have hmap_eq : ctx.uMap'.mapSet (ctx.S_post_h r_fin) = ctx.S_post_u r_fin :=
    ctx.uMap'.mapSet_chainInput ctx.st₀.nodes r_fin.castSucc
  have hbij := ctx.uMap'.mapSet_bij hsub_post
  have hcap_u : (ctx.S_post_u r_fin).card ≤ ctx.n := by
    rw [← hmap_eq, hbij.1]
    exact (Finset.card_le_card hsub_post).trans
      ((activeHandles_card_eq_activeIds_card ctx.hP').trans_le ctx.hP'.1)
  have huid_u : ∀ u ∈ ctx.S_post_u r_fin, u < ctx.uMap'.nextUid := hmap_eq ▸ hbij.2.1
  let g_lift := g₀.liftCoords ctx.hle_uid ctx.hag_uid
  let g' := g_lift.stepTick hD ht_lt ev_r hev_ck hev_v hcap_u huid_u hph'_le hpar_1 hbuild_1 act
  -- Reserved tag non-equalities from ctx.hV
  have hRes_rem := ctx.hV.2.2.2.2.2.2.2.2.2.1
  have hRes_cl := ctx.hV.2.2.2.2.2.2.2.2.2.2.1
  have hw_res : ∀ t ∈ reservedWordTags, t ≠ 26 → ∀ idx, wRead m₂ t idx = wRead m₁ t idx := by
    intro t ht hne26 idx
    exact hw_other t hne26
      (Ne.symm (tag_ne_of_not_reserved hRes_rem ht))
      (Ne.symm (tag_ne_of_not_reserved hRes_cl ht)) idx
  have hw1 : ∀ idx, wRead m₂ 1 idx = wRead m₁ 1 idx := hw_res 1 (by decide) (by decide)
  have hw5 : ∀ idx, wRead m₂ 5 idx = wRead m₁ 5 idx := hw_res 5 (by decide) (by decide)
  have hw6 : ∀ idx, wRead m₂ 6 idx = wRead m₁ 6 idx := hw_res 6 (by decide) (by decide)
  have hw8 : ∀ idx, wRead m₂ 8 idx = wRead m₁ 8 idx := hw_res 8 (by decide) (by decide)
  have hw9 : ∀ idx, wRead m₂ 9 idx = wRead m₁ 9 idx := hw_res 9 (by decide) (by decide)
  have hw10 : ∀ idx, wRead m₂ 10 idx = wRead m₁ 10 idx := hw_res 10 (by decide) (by decide)
  have hw11 : ∀ idx, wRead m₂ 11 idx = wRead m₁ 11 idx := hw_res 11 (by decide) (by decide)
  have hw3 : ∀ idx, wRead m₂ 3 idx = wRead m₁ 3 idx := hw_res 3 (by decide) (by decide)
  have hw14 : ∀ idx, wRead m₂ 14 idx = wRead m₁ 14 idx := hw_res 14 (by decide) (by decide)
  have hw15 : ∀ idx, wRead m₂ 15 idx = wRead m₁ 15 idx := hw_res 15 (by decide) (by decide)
  have hw16 : ∀ idx, wRead m₂ 16 idx = wRead m₁ 16 idx := hw_res 16 (by decide) (by decide)
  have hw19 : ∀ idx, wRead m₂ 19 idx = wRead m₁ 19 idx := hw_res 19 (by decide) (by decide)
  have hw23 : ∀ idx, wRead m₂ 23 idx = wRead m₁ 23 idx := hw_res 23 (by decide) (by decide)
  have hw24 : ∀ idx, wRead m₂ 24 idx = wRead m₁ 24 idx := hw_res 24 (by decide) (by decide)
  have hSeg_pres : ∀ s, ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m₂ s S₁ fSq₁ :=
    fun s _ _ hE => hE.congr_mem_fSq (hw5 _) (fun _ _ => hw8 _) (fun _ _ => hw9 _)
      (fun _ _ => hw10 _) (fun _ _ => hr_all 8 _) (fun _ _ => rfl)
  have hSlot_pres : ∀ s S₁ sp₁,
      EncSlotCoords ctx.d ctx.n m₁ ctx.P'.activeHandles ctx.P'.handleCoords s S₁ sp₁ →
      EncSlotCoords ctx.d ctx.n m₂ ctx.P'.activeHandles ctx.P'.handleCoords s S₁ sp₁ :=
    fun s _ _ hC => hC.congr_mem3 (hw6 _) (fun _ => hw11 _) (fun _ => hr_all 11 _)
  refine ⟨g', ?_⟩
  rcases pb.hChainRest with ⟨leafS, hl0, hllt, hw1_6, hw6_leaf, hSegLeaf, hDisj⟩
  have hDisj2 : GlobalSlotDisj ctx.p.D₀ m₂ ctx.st₀.k leafS := by
    rcases hDisj with ⟨h0, hd1, hd2, hd3, hd4⟩
    have hsn_eq : ∀ r, snSlotSet m₂ r = snSlotSet m₁ r :=
      fun r => snSlotSet_congr_14_15 (hw14 _) (hw15 _)
    have hlive_eq : ∀ idx sp, jobLevelLiveSlots m₂ idx sp = jobLevelLiveSlots m₁ idx sp :=
      fun idx sp => jobLevelLiveSlots_congr_23 (hw23 _) (hw23 _) (hw23 _) (hw23 _)
    refine ⟨h0,
      fun r hr s hs => hd1 r hr s (by rwa [hsn_eq] at hs),
      fun r₁ hr₁ r₂ hr₂ hne => by rw [hsn_eq, hsn_eq]; exact hd2 r₁ hr₁ r₂ hr₂ hne,
      fun r hr h16 j hj => ?_,
      fun r₁ hr₁ h16_1 j₁ hj₁ r₂ hr₂ h16_2 j₂ hj₂ hne => ?_⟩
    · rw [hw16] at h16; rw [hw19] at hj ⊢
      have hp := hd3 r hr h16 j hj
      exact ⟨fun s hs => hp.1 s (by rwa [hlive_eq] at hs),
        fun r' hr' => by rw [hlive_eq, hsn_eq]; exact hp.2 r' hr'⟩
    · rw [hw16] at h16_1; rw [hw16] at h16_2
      rw [hw19 r₁] at hj₁ ⊢; rw [hw19 r₂] at hj₂ ⊢
      have hp := hd4 r₁ hr₁ h16_1 j₁ hj₁ r₂ hr₂ h16_2 j₂ hj₂ hne
      rw [hlive_eq, hlive_eq, hw23, hw23]
      exact hp
  refine
    { hw27 := hw27_2
      hGood₀ := fun hb => pb.hGood₀ (hb_imp hb)
      hGood_i := fun hb => by
        have hgl := cg01_lift_jobLevelsCenterGood g₀ (pb.hGood_i (hb_imp hb))
        exact JobLevelsCenterGood.stepTick h_lem_5_1 g_lift hD ht_lt ev_r hev_ck hev_v
          hcap_u huid_u hph'_le hpar_1 hbuild_1 act hgl
          (fun _ _ _ _ _ _ _ _ _ hopen => by
            rcases hact_wc with ⟨_, heq⟩ | ⟨_, _, _, _, heq⟩ <;> rw [heq] at hopen <;> cases hopen)
      hage_eq := by
        change ctx.snAge' r_fin =
          jobStartAge (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) (ctx.st₀.birthSnap r_fin).card + (g₀.t_cur + 1)
        unfold MidLoopCtx.snAge'
        rw [if_pos haff, hage0_eq, Nat.add_assoc]
      hm0_le := by
        have hS0 : g'.S_root 0 = g₀.S_root 0 := by
          dsimp only [g', g_lift, ActiveJobGhost.stepTick, ActiveJobGhost.liftCoords]
          exact Function.update_of_ne (by omega) _ _
        rwa [hS0]
      hSeg := ⟨by rw [hw1]; exact pb.hSeg.1,
               fun s hs => by rw [hw5, hw1]; exact pb.hSeg.2.1 s hs,
               fun s hs u hu => by rw [hw8, hw1]; exact pb.hSeg.2.2 s hs u hu⟩
      hSave := ⟨by rw [hw1]; exact pb.hSave.1,
                fun s hs => by rw [hw6, hw1]; exact pb.hSave.2.1 s hs,
                fun s hs h hh => by rw [hw11, hw1]; exact pb.hSave.2.2 s hs h hh⟩
      hLive := ⟨pb.hLive.1,
                fun h hh c => by rw [hr_all]; exact pb.hLive.2 h hh c⟩
      hw1_5 := (hw1 5).trans pb.hw1_5
      hw6_0 := (hw6 0).trans pb.hw6_0
      hSeg0 := hSeg_pres 0 _ _ pb.hSeg0
      hChainRest := ⟨leafS, hl0, hllt, (hw1 6).trans hw1_6, (hw6 _).trans hw6_leaf,
        hSeg_pres leafS _ _ hSegLeaf, hDisj2⟩
      hHdr_i := pb.hHdr_i.frame_other (hw_bc2 i) (hw_age2 i) (hw14 _) (hw15 _)
        (fun s _ => hw6 _) (fun _ => hr_all _ _) (hr_all _ _)
        (fun s _ _ _ _ hE => hSeg_pres s _ _ hE)
      hOwn_i := ?_
      hDone := fun r hr_lt => ?_
      hTodo := fun r hr_ge => ?_ }
  · -- EncOwnedJobAt on i for some g'
    have hH' : g'.H_job = g₀.H_job := rfl
    have ht' : g'.t_cur = g₀.t_cur + 1 := rfl
    have hcl' : g'.closed = closed_out := by
      rw [hcl_eq]
      rcases hact_wc with ⟨hq, rfl⟩ | ⟨h1, h2, h3, h4, rfl⟩ <;> rfl
    have hlvs'_len : g'.lvs.length = g₀.lvs.length := by
      rcases hact_wc with ⟨hq, rfl⟩ | ⟨h1, h2, h3, h4, rfl⟩ <;>
        simp [g', g_lift, ActiveJobGhost.stepTick, ActiveJobGhost.liftCoords, applyJobTickEndAction]
    have hop' : g'.openRem = g₀.openRem := by
      rcases hact_wc with ⟨hq, rfl⟩ | ⟨h1, h2, h3, h4, rfl⟩ <;> rfl
    have hph_out : g'.ph_cur = ph' := by
      rcases hact_wc with ⟨hq, rfl⟩ | ⟨h1, h2, h3, h4, rfl⟩ <;> rfl
    have hscan_out : g'.scan_cur = scan' := by
      rcases hact_wc with ⟨hq, rfl⟩ | ⟨h1, h2, h3, h4, rfl⟩ <;> rfl
    have hSpar_out : g'.Spar_last_h = jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h r_fin) (g₀.lvs.length - 1) := by
      rcases hact_wc with ⟨hq, rfl⟩ | ⟨h1, h2, h3, h4, rfl⟩ <;> rfl
    refine ⟨(hw16 _).trans pb.hw16_i,
      by rw [hH', ht']; exact hwRem_i2,
      by rw [hcl']; exact hwCl_i2,
      by rw [hlvs'_len, hw19]; exact pb.hw19_i,
      lvs_h, hlen_eq.trans hlvs'_len.symm, fun j hj => ?_⟩
    have hj_g0 : j < g₀.lvs.length := hlen_eq ▸ hj
    have hj_g' : j < g'.lvs.length := (hlen_eq.trans hlvs'_len.symm) ▸ hj
    have hlv_eq_ball_bs :
        (g'.lvs[j]'hj_g').ball = (g₀.lvs[j]'hj_g0).ball ∧
        (g'.lvs[j]'hj_g').birthSnapshot = (g₀.lvs[j]'hj_g0).birthSnapshot := by
      let last_j := g₀.lvs.length - 1
      have hlast_lt : last_j < g₀.lvs.length := Nat.sub_lt g₀.hlvs_pos Nat.one_pos
      let lv_rdy : OpenedJobLevel ctx.d ℕ :=
        { g₀.lvs[last_j]'hlast_lt with backgroundReady := decide (ph' = 2) }
      have hl_rdy : g'.lvs = g₀.lvs.set last_j lv_rdy := by
        rcases hact_wc with ⟨hq, rfl⟩ | ⟨h1, h2, h3, h4, rfl⟩ <;> rfl
      by_cases heq_j : j = last_j
      · subst heq_j
        have hget : g'.lvs[last_j]'hj_g' = lv_rdy := by simp [hl_rdy]
        rw [hget]; exact ⟨rfl, rfl⟩
      · have hget : g'.lvs[j]'hj_g' = g₀.lvs[j]'hj_g0 := by
          simp [hl_rdy, List.getElem_set_ne (Ne.symm heq_j)]
        rw [hget]; exact ⟨rfl, rfl⟩
    rcases hlv_all j hj with ⟨hball_j, hop_j, ⟨f_b, g_b, hfb, hgb⟩, hEnc_j,
      hw23_7, hp2, hp3, hp4, hp5, hp6, hph2_lt⟩
    let idx := i * ctx.p.D₀ + j
    have hEnc_j2 : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₂
        ctx.P'.activeHandles ctx.P'.handleCoords idx
        (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
        (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) j)
        (decide (j + 1 = lvs_h.length)) :=
      hEnc_j.frame_slotSet
        (fun _ _ => rfl) (fun _ _ => rfl)
        (fun s _ _ _ _ _ hE => hSeg_pres s _ _ hE)
        (fun _ _ => hw6 _) hw11 (hr_all 11)
        (fun _ _ => hw23 _) (fun _ _ => hw24 _)
        (fun _ => hr_all 23 _) (fun _ _ => hr_all 24 _)
    refine ⟨hball_j.trans hlv_eq_ball_bs.1.symm,
      by rw [hop']; exact hop_j,
      ⟨f_b, g_b,
        fun h hh => ⟨hlv_eq_ball_bs.2.symm ▸ (hfb h hh).1, (hfb h hh).2⟩,
        fun u hu => hgb u (hlv_eq_ball_bs.2 ▸ hu)⟩,
      hEnc_j2,
      by rw [hop', hw23]; exact hw23_7,
      by rw [hw23]; exact hp2,
      by rw [hw23]; exact hp3,
      by rw [hw23]; exact hp4,
      by rw [hw23]; exact hp5,
      by rw [hw23]; exact hp6,
      fun hlt => by rw [hw24]; exact hph2_lt hlt,
      fun hj_last => ?_⟩
    have hj_eq_pred : j = g₀.lvs.length - 1 := by omega
    subst hj_eq_pred
    refine ⟨by rw [hph_out, hw24]; exact hw24_0,
            by rw [hscan_out, hw24]; exact hw24_1,
            hSpar_out⟩
  · -- hDone: r < i
    have hri : r.val ≠ i := by omega
    rcases pb.hDone r hr_lt with ⟨oj, hInv, hGood_r, hHdr, hOwn⟩
    refine ⟨oj, hInv, fun hb g hg => hGood_r (hb_imp hb) g hg,
      hHdr.frame_other (hw_bc2 _) (hw_age2 _) (hw14 _) (hw15 _)
        (fun _ _ => hw6 _) (fun _ => hr_all _ _) (hr_all _ _)
        (fun s _ _ _ _ hE => hSeg_pres s _ _ hE),
      hOwn.frame_other
        (fun g _ => by rw [ctx.hD0_eq]; exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2))
        (hw16 _) (hwRem_ne2 r.val hri) (hwCl_ne2 r.val hri) (hw19 _)
        (fun _ _ _ _ => hw23 _) (fun _ _ _ _ => hw24 _)
        (fun _ _ _ => hr_all 23 _) (fun _ _ _ _ => hr_all 24 _)
        (fun _ _ _ _ _ => hw6 _)
        (fun _ _ _ s _ _ _ _ _ hE => hSeg_pres s _ _ hE)
        hw11 (hr_all 11)⟩
  · -- hTodo: r ≥ i + 1
    have hri : r.val ≠ i := by omega
    rcases pb.hTodoGt r (by omega) with ⟨haff_w, hHdr, hGood_r, hTd⟩
    refine ⟨(hw_aff2 _).trans haff_w,
      hHdr.frame_other (hw_bc2 _) (hw_age2 _) (hw14 _) (hw15 _)
        (fun _ _ => hw6 _) (fun _ => hr_all _ _) (hr_all _ _)
        (fun s _ _ _ _ hE => hSeg_pres s _ _ hE),
      fun hb g hg => hGood_r (hb_imp hb) g hg,
      hTd.frame_other
        (hw16 _) (hwRem_ne2 r.val hri) (hwCl_ne2 r.val hri) (hw19 _)
        (fun _ _ _ _ => hw23 _) (fun _ _ _ _ => hw24 _)
        (fun _ _ _ => hr_all 23 _) (fun _ _ _ _ => hr_all 24 _)
        (fun _ _ _ _ _ => hw6 _)
        (fun _ _ _ s _ _ _ _ _ hE => hSeg_pres s _ _ hE)
        hw11 (hr_all 11)⟩

end UL.Proof_lem_7_2_RacerP46
