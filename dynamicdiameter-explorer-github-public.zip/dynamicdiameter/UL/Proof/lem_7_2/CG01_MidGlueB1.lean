import UL.Proof.lem_7_2.CG01_MidGlueA
import UL.Proof.lem_7_2.CG03_JobTickA3c

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. `preservesPoolWords` Simp Combinators & `locStmt` / `runHPJOnSlotStmt` Lemmas -/

@[simp] theorem cg01_writesWordTag_locStmt (t N : ℕ) :
    ∀ {s : ArithRAMStmt}, LocalizableStmt s = true → writesWordTag t (locStmt N s) = false
  | .skip, _ => rfl
  | .writeWordHeap _ _ _, _ => rfl
  | .writeRealHeap _ _ valE, _ => by
      unfold locStmt
      cases isActivePtCoord? valE <;> simp [locActivePtWrite, writesWordTag]
  | .randBitHeap _ _, _ => rfl
  | .seq s₁ s₂, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      simp [locStmt, writesWordTag, cg01_writesWordTag_locStmt t N h.1, cg01_writesWordTag_locStmt t N h.2]
  | .ite _ s₁ s₂, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      simp [locStmt, writesWordTag, cg01_writesWordTag_locStmt t N h.1.2, cg01_writesWordTag_locStmt t N h.2]
  | .whileLoop _ b, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      simp [locStmt, writesWordTag, cg01_writesWordTag_locStmt t N h.2]
  | .repeatN _ b, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      simp [locStmt, writesWordTag, cg01_writesWordTag_locStmt t N h.2]
  | .writeWordLocal _ _ _, h | .freeWordHeap _ _, h | .freeWordLocal _ _, h
  | .freeRealHeap _ _, h | .freeRealLocal _ _, h | .writeRealLocal _ _ _, h
  | .randBitLocal _ _, h | .localScope _, h => by
      simp [LocalizableStmt] at h

@[simp] theorem cg01_writesWord1Low_locStmt (N : ℕ) :
    ∀ {s : ArithRAMStmt}, LocalizableStmt s = true → writesWord1Low (locStmt N s) = false
  | .skip, _ => rfl
  | .writeWordHeap _ _ _, _ => rfl
  | .writeRealHeap _ _ valE, _ => by
      unfold locStmt
      cases isActivePtCoord? valE <;> simp [locActivePtWrite, writesWord1Low]
  | .randBitHeap _ _, _ => rfl
  | .seq s₁ s₂, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      simp [locStmt, writesWord1Low, cg01_writesWord1Low_locStmt N h.1, cg01_writesWord1Low_locStmt N h.2]
  | .ite _ s₁ s₂, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      simp [locStmt, writesWord1Low, cg01_writesWord1Low_locStmt N h.1.2, cg01_writesWord1Low_locStmt N h.2]
  | .whileLoop _ b, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      simp [locStmt, writesWord1Low, cg01_writesWord1Low_locStmt N h.2]
  | .repeatN _ b, h => by
      simp only [LocalizableStmt, Bool.and_eq_true] at h
      simp [locStmt, writesWord1Low, cg01_writesWord1Low_locStmt N h.2]
  | .writeWordLocal _ _ _, h | .freeWordHeap _ _, h | .freeWordLocal _ _, h
  | .freeRealHeap _ _, h | .freeRealLocal _ _, h | .writeRealLocal _ _ _, h
  | .randBitLocal _ _, h | .localScope _, h => by
      simp [LocalizableStmt] at h

@[simp] theorem cg01_preservesPoolWords_skip : preservesPoolWords .skip = true := rfl

@[simp] theorem cg01_preservesPoolWords_writeWordLocal (v : ℕ) (i val : IntExpr) :
    preservesPoolWords (.writeWordLocal v i val) = true := rfl

@[simp] theorem cg01_preservesPoolWords_writeRealLocal (v : ℕ) (i : IntExpr) (val : RealExpr) :
    preservesPoolWords (.writeRealLocal v i val) = true := rfl

@[simp] theorem cg01_preservesPoolWords_randBitLocal (v : ℕ) (i : IntExpr) :
    preservesPoolWords (.randBitLocal v i) = true := rfl

@[simp] theorem cg01_preservesPoolWords_boxWriteR (M_box t : ℕ) (i : IntExpr) (val : RealExpr) :
    preservesPoolWords (boxWriteR M_box t i val) = true := by
  simp [preservesPoolWords]

@[simp] theorem cg01_preservesPoolWords_seq (s₁ s₂ : ArithRAMStmt) :
    preservesPoolWords (.seq s₁ s₂) = (preservesPoolWords s₁ && preservesPoolWords s₂) := by
  simp only [preservesPoolWords, writesWordTag, writesWord1Low, Bool.not_or]
  cases writesWordTag 0 s₁ <;> cases writesWordTag 0 s₂ <;>
    cases writesWordTag 2 s₁ <;> cases writesWordTag 2 s₂ <;>
    cases writesWordTag 3 s₁ <;> cases writesWordTag 3 s₂ <;>
    cases writesWord1Low s₁ <;> cases writesWord1Low s₂ <;> rfl

@[simp] theorem cg01_preservesPoolWords_ite (c : ArithCondExpr) (s₁ s₂ : ArithRAMStmt) :
    preservesPoolWords (.ite c s₁ s₂) = (preservesPoolWords s₁ && preservesPoolWords s₂) := by
  simp only [preservesPoolWords, writesWordTag, writesWord1Low, Bool.not_or]
  cases writesWordTag 0 s₁ <;> cases writesWordTag 0 s₂ <;>
    cases writesWordTag 2 s₁ <;> cases writesWordTag 2 s₂ <;>
    cases writesWordTag 3 s₁ <;> cases writesWordTag 3 s₂ <;>
    cases writesWord1Low s₁ <;> cases writesWord1Low s₂ <;> rfl

@[simp] theorem cg01_preservesPoolWords_repeatN (cnt : IntExpr) (b : ArithRAMStmt) :
    preservesPoolWords (.repeatN cnt b) = preservesPoolWords b := rfl

@[simp] theorem cg01_preservesPoolWords_localScope (b : ArithRAMStmt) :
    preservesPoolWords (.localScope b) = preservesPoolWords b := rfl

@[simp] theorem cg01_cg01_preservesPoolWords_seqList : ∀ (ss : List ArithRAMStmt),
    preservesPoolWords (seqList ss) = ss.all preservesPoolWords
  | [] => rfl
  | [s] => by simp [seqList]
  | s :: s' :: ss => by
      simp only [seqList, cg01_preservesPoolWords_seq, List.all_cons]
      rw [cg01_cg01_preservesPoolWords_seqList (s' :: ss), List.all_cons]

theorem cg01_preservesPoolWords_boxWriteW_of_ne (M_box t : ℕ) (idxE valE : IntExpr)
    (h0 : t ≠ 0) (h1 : t ≠ 1) (h2 : t ≠ 2) (h3 : t ≠ 3) :
    preservesPoolWords (boxWriteW M_box t idxE valE) = true := by
  simp [preservesPoolWords, h0, h1, h2, h3]

theorem cg01_preservesPoolWords_boxWriteW_1_lit (M_box : ℕ) (k : ℕ) (hk : 3 ≤ k) (valE : IntExpr) :
    preservesPoolWords (boxWriteW M_box 1 (.lit (k : ℤ)) valE) = true := by
  have hge : (3 : ℤ) ≤ (k : ℤ) := by exact_mod_cast hk
  simp [preservesPoolWords, isLitGe3, hge]

theorem cg01_preservesPoolWords_locStmt (N : ℕ) {s : ArithRAMStmt}
    (h : LocalizableStmt s = true) :
    preservesPoolWords (locStmt N s) = true := by
  simp [preservesPoolWords, cg01_writesWordTag_locStmt _ N h, cg01_writesWord1Low_locStmt N h]

@[simp] theorem cg01_preservesPoolWords_boxWriteW_26 (M_box : ℕ) (idxE valE : IntExpr) :
    preservesPoolWords (boxWriteW M_box 26 idxE valE) = true := by
  simp [preservesPoolWords]

@[simp] theorem cg01_preservesPoolWords_runHPJOnSlotStmt {d n M_box : ℕ} (p : P46Params d n) :
    preservesPoolWords (runHPJOnSlotStmt d n M_box p) = true := by
  have hloc := cg01_preservesPoolWords_locStmt (2 ^ p.P_hpj.q) localizable_hpjProg
  unfold runHPJOnSlotStmt hpjSampleScopeStmt hpjSampleIterDetStmt hpjWalkScopeStmt
    hpjWalkSetupStmt hpjWalkCopyOutStmt randDummyBitsStmt
    cardAndMaxSegSlotStmt selectByRankSegStmt selectRankStepStmt
    readSlotPtToLocalStmt loadHeapCoordsToLocalStmt storeLocalCoordsToHeapStmt
    readRandNatLocalStmt
  simp [hloc]

private lemma cg01_ctx_hw26_5 {d n : ℕ} {p : P46Params d n}
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    (ctx : PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap') :
    wRead mem_rt 26 5 = (if updateIsInsert op then 1 else 0) := by
  have h := ctx.hw26_5
  cases op <;> exact h

private lemma cg01_ctx_hChain_rt {d n : ℕ} {p : P46Params d n}
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    (ctx : PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap') :
    EncServingChainRelaxed d n p.K_seg p.D₀ p.NumSlots mem_rt P' st₀.k st₀.nodes
      (fun r => if chainLevelAffected P P' st₀.nodes (updateIsInsert op) opH r.castSucc
                then st₀.snAge r + 1 else st₀.snAge r)
      (fun r => (st₀.ownedJob r).isNone) := by
  have h := ctx.hChain_rt
  cases op <;> exact h

private lemma cg01_ctx_hPerNode {d n : ℕ} {p : P46Params d n}
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    (ctx : PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap')
    (r : Fin st₀.k) :
    let ins := updateIsInsert op
    let aff := chainLevelAffected P P' st₀.nodes ins opH
    let S_pre_h := chainInput P.handleCoords st₀.nodes P.activeHandles r.castSucc
    let S_post_h := chainInput P'.handleCoords st₀.nodes P'.activeHandles r.castSucc
    let S_pre_u := chainInput st₀.uMap.ghostCoords st₀.nodes st₀.uMap.ActiveUids r.castSucc
    let S_post_u := chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc
    wRead mem_rt 20 (r.val : ℤ) = (if aff r.castSucc then 1 else 0) ∧
    (aff r.castSucc = false → opH ∉ S_pre_h ∧ opH ∉ S_post_h ∧ S_post_h = S_pre_h ∧ S_post_u = S_pre_u) ∧
    (aff r.castSucc = true →
      IsInputChange S_pre_h S_post_h ∧
      IsInputChange S_pre_u S_post_u ∧
      (ins = true → opH ∉ S_pre_h ∧ S_post_h = insert opH S_pre_h) ∧
      (ins = false → opH ∈ S_pre_h ∧ S_post_h = S_pre_h.erase opH) ∧
      ∃ ev_r : PoolUpdateEvent ℕ, ev_r.isClockTick = true ∧ IsValidPoolUpdateEvent S_pre_u S_post_u ev_r) := by
  have h := ctx.hPerNode r
  cases op <;> exact ⟨h.1, h.2.1, h.2.2.1⟩

private lemma cg01_ctx_exists_trueAge {d n : ℕ} {p : P46Params d n}
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    (ctx : PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap') :
    ∃ trueAge' : Fin st₀.k → ℕ,
      (∀ r : Fin st₀.k,
        trueAge' r ≤ (if chainLevelAffected P P' st₀.nodes (updateIsInsert op) opH r.castSucc
                      then st₀.snAge r + 1 else st₀.snAge r)) ∧
      (∀ r : Fin st₀.k,
        HasNodeAge (st₀.birthSnap r)
          (chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc) (trueAge' r)) := by
  rcases ctx.exists_trueAge_post with ⟨tr, h1, h2⟩
  refine ⟨tr, fun r => ?_, h2⟩
  have hr := h1 r
  cases op <;> exact hr

/-! ### 2. `MidLoopCtx` Construction & Initial `PostRouteContextRelaxed → MidLoopState 0` Bridge -/

noncomputable def cg01_mkMidLoopCtx
    {cHpj cBase d n t M_box : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (hM : p46BoxSize d n p ≤ M_box)
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    (ctx : PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap') :
    MidLoopCtx :=
  let hExAge := cg01_ctx_exists_trueAge ctx
  let trueAge' := Classical.choose hExAge
  let hAgeSpec := Classical.choose_spec hExAge
  let hLow := p46BoxSize_lower_bounds p hn hp.hSlots hp.h2K_lt_2n hM
  let hR := hp.routeBoxBounds hn hM
  { T_max := 28
    M_box := M_box
    cfg := defaultChainHdrCfg
    d := d
    n := n
    H := p.H
    p := p
    P := P
    P' := P'
    op := op
    opH := opH
    uMap' := uMap'
    st₀ := st₀
    trueAge' := trueAge'
    hV := valid_defaultChainHdrCfg (le_refl 28)
    hD_eq := hp.hD_eq
    hH5 := hp.hH5
    hn2 := hp.hn2
    hn_2K := hp.hn_le_2K
    hD0_eq := hp.hD0
    hL_floor := hp.hL_floor
    hL_eq10 := hp.hL_eq10
    hB_floor := le_of_eq hp.hBscan.symm
    hKbatch := hp.hKbatch
    hSlots_cap := le_of_eq hp.hSlots.symm
    hkφ := hp.hφ_eq
    hφ0 := hp.hφ0
    hφ1 := hp.hφ1
    hp_eq := hp.hPhp_eq
    hp_props := hp.hPhp_props
    hbias_hpj := hp.hbias_hpj
    hB_hpj := hp.hBhpj
    hBox30 := hLow.2.2.2.2.1
    hBox_slots := hR.2.2.2.1
    hBox_samp := hR.2.2.2.2.2.2.1
    hBox_d := hR.2.2.2.2.1
    hBox_w23 := (hR.2.2.2.2.2.2.2 (p.D₀ * p.D₀) le_rfl).1
    hBox_r23 := (hR.2.2.2.2.2.2.2 (p.D₀ * p.D₀) le_rfl).2
    hBox_seg := hR.1.2.2.2.2.2.2
    hBox_hdr := by
      have hm : defaultChainHdrCfg.maxStride = 1 := by decide
      have hD0_M := hLow.2.2.2.2.2.1
      rw [hm]; omega
    hBox_snO := hR.2.2.2.2.2.1
    hwf₀ := ctx.hCoupled_pre.2.1
    hP := ctx.hP_wf
    hP' := ctx.hP'_wf
    hopH_n := ctx.hopH_n
    hopH_K := ctx.hopH_K
    hle_uid := ctx.hle_uid
    hag_uid := ctx.hag_uid
    hchg_root := ctx.hchg_root
    hcoords_root := ctx.hcoords_root
    hcoords_ne := ctx.hcoords_ne
    htr_le' := hAgeSpec.1
    hhas_age' := hAgeSpec.2
    hPerNode := fun r => ⟨(cg01_ctx_hPerNode ctx r).2.1, (cg01_ctx_hPerNode ctx r).2.2⟩ }

def cg01MidLoopInitStmt (M_box : ℕ) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 26 (.lit 13) (.readHeap 26 (.lit 4)),
    boxWriteW M_box 26 (.lit 14) (.readHeap 26 (.lit 5)),
    boxWriteW M_box 26 (.lit 15) (.lit 0),
    boxWriteW M_box 26 (.lit 27) (.lit 0),
    boxWriteW M_box 26 (.lit 28) (.readHeap 1 (.lit 5)),
    .localScope .skip
  ]

theorem boxSafe_cg01MidLoopInitStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) :
    BoxSafeOuter T_max M_box (cg01MidLoopInitStmt M_box) := by
  unfold cg01MidLoopInitStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .localScope .skip

@[simp] theorem preservesPoolWords_cg01MidLoopInitStmt (M_box : ℕ) :
    preservesPoolWords (cg01MidLoopInitStmt M_box) = true := by
  simp [cg01MidLoopInitStmt]

theorem exec_cg01MidLoopInitStmt
    {cHpj cBase d n t M_box : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (hM : p46BoxSize d n p ≤ M_box)
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    (ctx : PostRouteContextRelaxed p (CG01_EncJobs p) P op m_pre st₀ mem_rt P' opH uMap') :
    let loopCtx := cg01_mkMidLoopCtx hp hn hM ctx
    ∃ m_init : ArithRAMMemory,
      DetExecAt 0 (mkStepInput n P op) (cg01MidLoopInitStmt M_box) mem_rt m_init 120 ∧
      m_init.popDepth 0 = m_init ∧
      MidLoopState loopCtx (wRead mem_rt 0 0) false 0 m_init ∧
      (st₀.AllCentersGood → MidLoopState loopCtx (wRead mem_rt 0 0) true 0 m_init) := by
  intro loopCtx
  let inp := mkStepInput n P op
  have h30 : 30 ≤ M_box := loopCtx.hBox30
  rcases cg01_ctx_hChain_rt ctx with ⟨_, _, _, hPool_rt, hSeg_rt, hSave_rt, hw15_rt, hw60_rt, hSeg0_rt,
    leafS_rt, hl0_rt, hllt_rt, hw16_rt, hw6l_rt, hSegL_rt, hsn_rt, _, _⟩
  have hw26_5_ins : wRead mem_rt 26 5 = (if loopCtx.ins then 1 else 0) :=
    cg01_ctx_hw26_5 ctx
  let s1 := wWrite mem_rt 26 13 (opH : ℤ)
  have e1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 13) (.readHeap 26 (.lit 4))) mem_rt s1 16 :=
    exec_boxWriteW inp mem_rt _ _ rfl (by omega) (by omega) (by simp [ctx.hw26_4]) (by simp [intExprOps])
  let s2 := wWrite s1 26 14 (if loopCtx.ins then 1 else 0)
  have e2 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 14) (.readHeap 26 (.lit 5))) s1 s2 16 :=
    exec_boxWriteW inp s1 _ _ rfl (by omega) (by omega) (by simp [s1, hw26_5_ins]) (by simp [intExprOps])
  let s3 := wWrite s2 26 15 0
  have e3 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 15) (.lit 0)) s2 s3 14 :=
    exec_boxWriteW inp s2 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  let s4 := wWrite s3 26 27 0
  have e4 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 27) (.lit 0)) s3 s4 14 :=
    exec_boxWriteW inp s3 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  let s5 := wWrite s4 26 28 (st₀.k : ℤ)
  have e5 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 28) (.readHeap 1 (.lit 5))) s4 s5 16 :=
    exec_boxWriteW inp s4 _ _ rfl (by omega) (by omega) (by simp [s4, s3, s2, s1, hw15_rt]) (by simp [intExprOps])
  have e6 := exec_popScopeZero inp s5
  let m_init := s5.popDepth 0
  have hex : DetExecAt 0 inp (cg01MidLoopInitStmt M_box) mem_rt m_init 120 := by
    unfold cg01MidLoopInitStmt seqList
    exact (e1.seq (e2.seq (e3.seq (e4.seq (e5.seq e6))))).mono_cost (by omega)
  have hw_init_rt : ∀ tb, tb ≠ 26 → ∀ idx, wRead m_init tb idx = wRead mem_rt tb idx := by
    intro tb hne idx; simp [m_init, s5, s4, s3, s2, s1, hne]
  have hr_init_rt : ∀ tb idx, rRead m_init tb idx = rRead mem_rt tb idx := by
    intro tb idx; simp [m_init, s5, s4, s3, s2, s1]
  have hw26_13 : wRead m_init 26 13 = (opH : ℤ) := by simp [m_init, s5, s4, s3, s2, s1]
  have hw26_14 : wRead m_init 26 14 = (if loopCtx.ins then 1 else 0) := by simp [m_init, s5, s4, s3, s2]
  have hw26_15 : wRead m_init 26 15 = 0 := by simp [m_init, s5, s4, s3]
  have hw26_27 : wRead m_init 26 27 = 0 := by simp [m_init, s5, s4]
  have hw26_28 : wRead m_init 26 28 = (st₀.k : ℤ) := by simp [m_init, s5]
  -- Helper proving MidLoopUncut loopCtx gFlag 0 m_init when (gFlag = true → st₀.AllCentersGood)
  have hUncut0 : ∀ gFlag : Bool, (gFlag = true → st₀.AllCentersGood) →
      MidLoopUncut loopCtx gFlag 0 m_init := by
    intro gFlag hGood_imp
    rcases ctx.hCoupled_pre.2.2.2 with ⟨hbc_pre, _, hoj_pre, hdisj_pre⟩
    rcases ctx.hCoupled_pre.2.2.1 with ⟨_, _, _, _, _, _, _, hw60_pre, _,
      leafS_pre, _, _, hw16_pre, hw6l_pre, _, hsn_pre, _, _⟩
    have hleaf_eq : leafS_rt = leafS_pre := by
      have : (leafS_rt : ℤ) = (leafS_pre : ℤ) := by
        rw [← hw16_rt, ctx.hw1_other 6 (by decide) (by decide) (by decide), hw16_pre]
      exact_mod_cast this
    have hw16_pre_nat : (wRead m_pre 1 6).toNat = leafS_pre := by rw [hw16_pre]; simp
    rw [hw16_pre_nat] at hdisj_pre
    have hSegPres_init : ∀ {s : ℕ} {S₁ : Finset ℕ} {fSq₁ : ℕ → ℝ},
        EncSegSlot p.K_seg mem_rt s S₁ fSq₁ → EncSegSlot p.K_seg m_init s S₁ fSq₁ := fun hE =>
      hE.congr_mem_fSq
        (hw_init_rt 5 (by decide) _) (fun _ _ => hw_init_rt 8 (by decide) _)
        (fun _ _ => hw_init_rt 9 (by decide) _) (fun _ _ => hw_init_rt 10 (by decide) _)
        (fun _ _ => hr_init_rt 8 _) (fun _ _ => rfl)
    -- GlobalSlotDisj preserved from m_pre to m_init
    have hw_disj_eq : ∀ tb, tb ∈ ({14, 15, 16, 19, 23} : Finset ℕ) →
        ∀ idx, wRead m_init tb idx = wRead m_pre tb idx := by
      intro tb htb idx
      fin_cases htb <;>
        exact (hw_init_rt _ (by decide) idx).trans
          (ctx.hw_other _ (by decide) (by decide) (by decide) (by decide) (by decide)
            (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) idx)
    have hDisj_init : GlobalSlotDisj p.D₀ m_init st₀.k leafS_rt := by
      rw [hleaf_eq]
      rcases hdisj_pre with ⟨hlp, hsn0, hsnP, hlv_sn, hlv_lv⟩
      have hsn_eq : ∀ r, snSlotSet m_init r = snSlotSet m_pre r :=
        fun r => snSlotSet_congr_14_15 (hw_disj_eq 14 (by decide) _) (hw_disj_eq 15 (by decide) _)
      have h16_eq := hw_disj_eq 16 (by decide)
      have h19_eq := hw_disj_eq 19 (by decide)
      have h23_eq := hw_disj_eq 23 (by decide)
      have hlv_eq : ∀ idx sp, jobLevelLiveSlots m_init idx sp = jobLevelLiveSlots m_pre idx sp :=
        fun _ _ => jobLevelLiveSlots_congr_23 (h23_eq _) (h23_eq _) (h23_eq _) (h23_eq _)
      refine ⟨hlp,
        fun r hr s hs => by rw [hsn_eq] at hs; exact hsn0 r hr s hs,
        fun r₁ hr₁ r₂ hr₂ hne => by rw [hsn_eq, hsn_eq]; exact hsnP r₁ hr₁ r₂ hr₂ hne,
        fun r hr h16 j hj => ?_,
        fun r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne => ?_⟩
      · dsimp only
        rw [h16_eq] at h16; rw [h19_eq] at hj ⊢; rw [hlv_eq]
        rcases hlv_sn r hr h16 j hj with ⟨h0l, hd_sn⟩
        exact ⟨h0l, fun r' hr' => by rw [hsn_eq]; exact hd_sn r' hr'⟩
      · rw [h16_eq] at h16₁ h16₂
        rw [h19_eq] at hj₁ hj₂; rw [h19_eq, h19_eq, hlv_eq, hlv_eq, h23_eq, h23_eq]
        exact hlv_lv r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne
    refine ⟨hw26_27,
      fun hgF r => (hGood_imp hgF).1 r,
      ⟨by rw [hw_init_rt 1 (by decide)]; exact hSeg_rt.1,
       fun s hs => by rw [hw_init_rt 5 (by decide), hw_init_rt 1 (by decide)]; exact hSeg_rt.2.1 s hs,
       fun s hs u hu => by rw [hw_init_rt 8 (by decide), hw_init_rt 1 (by decide)]; exact hSeg_rt.2.2 s hs u hu⟩,
      ⟨by rw [hw_init_rt 1 (by decide)]; exact hSave_rt.1,
       fun s hs => by rw [hw_init_rt 6 (by decide), hw_init_rt 1 (by decide)]; exact hSave_rt.2.1 s hs,
       fun s hs h hh => by rw [hw_init_rt 11 (by decide), hw_init_rt 1 (by decide)]; exact hSave_rt.2.2 s hs h hh⟩,
      ⟨hPool_rt.1.1, fun h hh c => by rw [hr_init_rt 4]; exact hPool_rt.1.2 h hh c⟩,
      by rw [hw_init_rt 1 (by decide)]; exact hw15_rt,
      by rw [hw_init_rt 6 (by decide)]; exact hw60_rt,
      hSegPres_init hSeg0_rt,
      leafS_rt, hl0_rt, hllt_rt,
      by rw [hw_init_rt 1 (by decide)]; exact hw16_rt,
      by rw [hw_init_rt 6 (by decide)]; exact hw6l_rt,
      hSegPres_init hSegL_rt,
      hDisj_init,
      fun _ hr => absurd hr (Nat.not_lt_zero _),
      ?_⟩
    intro r _
    refine ⟨?_, ?_, fun hgF g hg => (hGood_imp hgF).2 r g hg, ?_⟩
    · change wRead m_init 20 (((1 * r.val + 0 : ℕ) : ℤ)) =
        if chainLevelAffected P P' st₀.nodes (updateIsInsert op) opH r.castSucc then 1 else 0
      simp only [one_mul, add_zero]
      rw [hw_init_rt 20 (by decide)]
      exact (cg01_ctx_hPerNode ctx r).1
    · -- EncNodeHeaderAt at m_init
      rcases hsn_rt r with ⟨dS, spS, hd0, hd_lt, hs0, hs_lt, hne,
        e13, e14, e15, e6d, e6s, er12, er13, hSegD, T_sp, hSegSp, hidle⟩
      refine ⟨dS, spS, T_sp, hd0, hd_lt, hs0, hs_lt, hne,
        by change wRead m_init 12 (((1 * r.val + 0 : ℕ) : ℤ)) = _
           simp only [one_mul, add_zero]
           rw [hw_init_rt 12 (by decide),
               ctx.hw_other 12 (by decide) (by decide) (by decide) (by decide) (by decide)
                 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
           exact hbc_pre r,
        by change wRead m_init 13 (((1 * r.val + 0 : ℕ) : ℤ)) =
             (((if chainLevelAffected P P' st₀.nodes (updateIsInsert op) opH r.castSucc
                then st₀.snAge r + 1 else st₀.snAge r : ℕ) : ℤ))
           simp only [one_mul, add_zero]
           rw [hw_init_rt 13 (by decide)]; exact e13,
        by rw [hw_init_rt 14 (by decide)]; exact e14,
        by rw [hw_init_rt 15 (by decide)]; exact e15,
        by rw [hw_init_rt 6 (by decide)]; exact e6d,
        by rw [hw_init_rt 6 (by decide)]; exact e6s,
        fun c => by change rRead m_init 12 _ = _; rw [hr_init_rt 12]; exact er12 c,
        by change rRead m_init 13 (((1 * r.val + 0 : ℕ) : ℤ)) = _
           simp only [one_mul, add_zero]
           rw [hr_init_rt 13]; exact er13,
        hSegPres_init hSegD,
        hSegPres_init hSegSp,
        hidle⟩
    · -- EncTodoJobAt loopCtx m_init r
      have hoj_r := hoj_pre r
      dsimp only [EncTodoJobAt, loopCtx, cg01_mkMidLoopCtx]
      cases hoj_c : st₀.ownedJob r with
      | none =>
          rw [hoj_c] at hoj_r
          dsimp only [EncOwnedJobAt] at hoj_r
          rw [hw_disj_eq 16 (by decide)]
          exact hoj_r
      | some g =>
          rw [hoj_c] at hoj_r
          rcases hoj_r with ⟨e16, e17, e18, e19, lvs_h, hlen_eq, hlv_all⟩
          have hw6_eq : ∀ s, wRead mem_rt 6 s = wRead m_pre 6 s :=
            ctx.hw_other 6 (by decide) (by decide) (by decide) (by decide) (by decide)
              (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
          have hw23_rt := ctx.hw_other 23 (by decide) (by decide) (by decide) (by decide) (by decide)
            (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
          have hw24_rt := ctx.hw_other 24 (by decide) (by decide) (by decide) (by decide) (by decide)
            (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
          have hr23_rt := ctx.hr_other 23 (by decide) (by decide) (by decide) (by decide)
          have hr24_rt := ctx.hr_other 24 (by decide) (by decide) (by decide) (by decide)
          refine ⟨by rw [hw_disj_eq 16 (by decide)]; exact e16,
            by dsimp only [defaultChainHdrCfg, HdrField.idx] at e17 ⊢
               rw [hw_init_rt 17 (by decide),
                   ctx.hw_other 17 (by decide) (by decide) (by decide) (by decide) (by decide)
                     (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
               exact e17,
            by dsimp only [defaultChainHdrCfg, HdrField.idx] at e18 ⊢
               rw [hw_init_rt 18 (by decide),
                   ctx.hw_other 18 (by decide) (by decide) (by decide) (by decide) (by decide)
                     (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)]
               exact e18,
            by rw [hw_disj_eq 19 (by decide)]; exact e19,
            lvs_h, hlen_eq, fun j hj => ?_⟩
          rcases hlv_all j hj with ⟨hb, ho, hbij, hEnc_pre, hw7, p2, p3, p4, p5, p6, hpre2, hlast⟩
          let idx := r.val * p.D₀ + j
          let spLive := decide (j + 1 = lvs_h.length)
          have hj_toNat : j < (wRead m_pre 19 (r.val : ℤ)).toNat := by rw [e19]; omega
          have hS_pre_sub : chainInput P.handleCoords st₀.nodes P.activeHandles r.castSucc ⊆ P.activeHandles :=
            cg01_chainInput_subset P.handleCoords st₀.nodes P.activeHandles r.castSucc
          have hS_par_sub : jobHandleInput (d + 3) P.handleCoords lvs_h
              (chainInput P.handleCoords st₀.nodes P.activeHandles r.castSucc) j ⊆ P.activeHandles :=
            (jobHandleInput_subset (d + 3) P.handleCoords lvs_h _ j).trans hS_pre_sub
          -- Lift EncJobLevel from m_pre to mem_rt via liftPreJobLevelAfterRoute
          have hEnc_rt : EncJobLevel d n (d + 3) p.K_seg p.NumSlots mem_rt
              P'.activeHandles (bridgeHandleCoords P P') idx
              (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
              (jobHandleInput (d + 3) (bridgeHandleCoords P P') lvs_h
                (chainInput P.handleCoords st₀.nodes P.activeHandles r.castSucc) j) spLive := by
            have hinp_eq : jobHandleInput (d + 3) (bridgeHandleCoords P P') lvs_h
                (chainInput P.handleCoords st₀.nodes P.activeHandles r.castSucc) j =
                jobHandleInput (d + 3) P.handleCoords lvs_h
                  (chainInput P.handleCoords st₀.nodes P.activeHandles r.castSucc) j :=
              jobHandleInput_congr_pts (d + 3) lvs_h _ (fun x hx => bridgeHandleCoords_eq_pre (hS_pre_sub hx)) j
            rw [hinp_eq]
            refine liftPreJobLevelAfterRoute hS_par_sub hEnc_pre ?_ ctx.hSnap
              hw6_eq hw23_rt hw24_rt hr23_rt hr24_rt ctx.hcoords_root
            intro s hs_in hs_lt hnot_dead S₁ fSq₁ hE
            have hs_used : s ∈ LevelUsedSlots m_pre idx spLive :=
              mem_levelUsedSlots_of_enc hs_in hnot_dead
            unfold LevelUsedSlots at hs_used
            simp only [Finset.mem_insert] at hs_used
            rcases hs_used with rfl | hs_live
            · -- s = bS, which is frozen (1 ≤ wRead m_pre 6 s)
              have h6_pos : 1 ≤ wRead m_pre 6 (((wRead m_pre 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat : ℤ)) :=
                (encJobLevel_live_and_frozen_slots hEnc_pre).1
              set bS := (wRead m_pre 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat
              have hb_ne0 : bS ≠ 0 := by intro h0; rw [h0] at h6_pos; simpa [hw60_pre] using h6_pos
              have hb_neL : bS ≠ (wRead m_pre 1 6).toNat := by
                rw [hw16_pre_nat]; intro hL; rw [hL, hw6l_pre] at h6_pos; omega
              have hb_notSn : ∀ r' : Fin st₀.k, bS ∉ snSlotSet m_pre r'.val := by
                intro r' hmem
                rcases hsn_pre r' with ⟨dS', spS', _, _, _, _, _, _, e14', e15', e6d', e6s', _⟩
                unfold snSlotSet at hmem
                rw [e14', e15'] at hmem
                simp only [Int.toNat_natCast, Finset.mem_insert, Finset.mem_singleton] at hmem
                rcases hmem with rfl | rfl <;> omega
              exact ctx.hOtherSeg bS hs_lt hb_ne0 hb_neL hb_notSn S₁ fSq₁ hE
            · -- s ∈ jobLevelLiveSlots m_pre idx spLive
              have hsp_eq : spLive = decide (j + 1 = (wRead m_pre 19 (r.val : ℤ)).toNat) := by
                dsimp [spLive]; rw [e19, hlen_eq]; simp
              rw [hsp_eq] at hs_live
              rcases hdisj_pre.2.2.2.1 r.val r.isLt e16 j hj_toNat with ⟨h0L, hdisj_sn⟩
              exact ctx.hOtherSeg s hs_lt (h0L s hs_live).1
                (by rw [hw16_pre_nat]; exact (h0L s hs_live).2)
                (fun r' hmem => Finset.disjoint_left.mp (hdisj_sn r'.val r'.isLt) hs_live hmem)
                S₁ fSq₁ hE
          -- Lift EncJobLevel from mem_rt to m_init (only table 26 changed!)
          have hEnc_init := encJobLevel_congr_not_0_26
            (fun tb _ h26 idx' => hw_init_rt tb h26 idx')
            (fun tb _ _ idx' => hr_init_rt tb idx') hEnc_rt
          have hw23_init : ∀ idx', wRead m_init 23 idx' = wRead m_pre 23 idx' :=
            fun idx' => (hw_init_rt 23 (by decide) idx').trans (hw23_rt idx')
          have hw24_init : ∀ idx', wRead m_init 24 idx' = wRead m_pre 24 idx' :=
            fun idx' => (hw_init_rt 24 (by decide) idx').trans (hw24_rt idx')
          exact ⟨hb, ho, hbij, hEnc_init,
            by rw [hw23_init]; exact hw7,
            by rw [hw23_init]; exact p2,
            by rw [hw23_init]; exact p3,
            by rw [hw23_init]; exact p4,
            by rw [hw23_init]; exact p5,
            by rw [hw23_init]; exact p6,
            fun hlt => by rw [hw24_init]; exact hpre2 hlt,
            fun heq => ⟨by rw [hw24_init]; exact (hlast heq).1,
                        by rw [hw24_init]; exact (hlast heq).2.1,
                        (hlast heq).2.2⟩⟩
  refine ⟨m_init, hex, popDepth_zero_idem s5,
    ⟨hw_init_rt 0 (by decide) 0, hw26_13, hw26_14, hw26_15, hw26_28,
      Or.inl (hUncut0 false (fun hf => by cases hf))⟩,
    fun hGood₀ =>
      ⟨hw_init_rt 0 (by decide) 0, hw26_13, hw26_14, hw26_15, hw26_28,
        Or.inl (hUncut0 true (fun _ => hGood₀))⟩⟩

/-! ### 3. Final Extraction at `i = p.D₀` (`cg01_extract_st_mid_of_end`) -/

theorem cg01_extract_st_mid_of_end
    (ctx : MidLoopCtx) {gFlag : Bool} {m : ArithRAMMemory}
    (hor : MidLoopUncut ctx gFlag ctx.p.D₀ m ∨ MidLoopCut ctx gFlag m) :
    ∃ st_mid : PureServingState ctx.d ctx.n ctx.H ctx.p.L ctx.p.B_scan ctx.P',
      st_mid.uMap = ctx.uMap' ∧
      st_mid.NodesInv ∧
      (chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles).card ≤ 4 * ctx.p.L + 2 ∧
      EncFullChainAndJobs ctx.d ctx.n ctx.H ctx.cfg ctx.p m ctx.P' st_mid ∧
      (gFlag = true → st_mid.AllCentersGood) := by
  classical
  rcases hor with hU | hC
  · rcases hU with ⟨_, hGood₀, hSeg, hSave, hLive, h15, h60, hSeg0,
      leafS, hl0, hllt, h16l, h6l, hSegL, hDisj, hDone, _⟩
    have hk_lt : ctx.st₀.k < ctx.p.D₀ := ctx.origK_lt_D0
    have hoj_ex : ∀ r : Fin ctx.st₀.k,
        ∃ oj : Option (ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
            ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u r)),
          ServingOwnedJobInv (ctx.st₀.birthSnap r) (ctx.snAge' r) oj ∧
          (gFlag = true → ∀ g, oj = some g → JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g.lvs) ∧
          EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' r.val (ctx.st₀.nodes r)
            (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) oj.isNone ∧
          EncOwnedJobAt ctx.cfg ctx.p m ctx.P' ctx.uMap' r.val (ctx.S_post_h r) (ctx.S_post_u r) oj :=
      fun r => hDone r (lt_trans r.isLt hk_lt)
    choose oj_fn hoj_fn using hoj_ex
    let st_mid : PureServingState ctx.d ctx.n ctx.H ctx.p.L ctx.p.B_scan ctx.P' :=
      { uMap := ctx.uMap'
        k := ctx.st₀.k
        nodes := ctx.st₀.nodes
        birthSnap := ctx.st₀.birthSnap
        snAge := ctx.snAge'
        trueAge := ctx.trueAge'
        ownedJob := oj_fn }
    have hNodesInv : st_mid.NodesInv := by
      intro r
      rcases ctx.hwf₀.1 r with ⟨hb_pos, hb_uid, hb_pass, _, _, _⟩
      exact ⟨hb_pos,
        fun u hu => lt_of_lt_of_le (hb_uid u hu) ctx.hle_uid,
        (passesBirthCoreCheck_congr_on _ _ (fun u hu => ctx.hag_uid u (hb_uid u hu))).mpr hb_pass,
        ctx.htr_le' r,
        ctx.hhas_age' r,
        (hoj_fn r).1⟩
    have hD4_pos : 1 ≤ (ctx.d + 3) ^ 4 := Nat.one_le_pow 4 (ctx.d + 3) (by omega)
    have hL1 : 1 ≤ ctx.p.L := by have := ctx.hL_floor; omega
    have hleaf_le : (chainTerminal ctx.P'.handleCoords st_mid.nodes ctx.P'.activeHandles).card ≤
        4 * ctx.p.L + 2 := by
      have hstep := cg01_chainTerminal_card_step_le ctx.st₀.nodes ctx.hchg_root ctx.hcoords_root
      have hpre_le : (chainTerminal ctx.P.handleCoords ctx.st₀.nodes ctx.P.activeHandles).card ≤
          3 * ctx.p.L + 2 := ctx.hwf₀.2
      dsimp only [st_mid]
      omega
    have hFull : EncFullChainAndJobs ctx.d ctx.n ctx.H ctx.cfg ctx.p m ctx.P' st_mid :=
      ⟨le_of_lt hk_lt, hSeg, hSave, hLive, h15, h60, hSeg0,
       leafS, hl0, hllt, h16l, h6l, hSegL, hDisj,
       fun r => ⟨(hoj_fn r).2.2.1, (hoj_fn r).2.2.2⟩⟩
    have hGood_mid : gFlag = true → st_mid.AllCentersGood := by
      intro hgF
      refine ⟨fun r => ?_, fun r g hg => (hoj_fn r).2.1 hgF g hg⟩
      exact (isCenterpoint_paraboloid_congr_on _ _
        (fun u hu => ctx.hag_uid u ((ctx.hwf₀.1 r).2.1 u hu))).mpr (hGood₀ hgF r)
    exact ⟨st_mid, rfl, hNodesInv, hleaf_le, hFull, hGood_mid⟩
  · exact hC.2

end UL.Proof_lem_7_2_RacerP46
