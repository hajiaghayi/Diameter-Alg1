import Mathlib
import UL.Stmt.lem_C_2
import UL.Proof.lem_7_2.CG01_H4a2d

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

lemma popDepth_idem_gen (m : ArithRAMMemory) (k : ℕ) :
    (m.popDepth k).popDepth k = m.popDepth k := by
  unfold ArithRAMMemory.popDepth WordStore.popDepth RealStore.popDepth
  dsimp only
  congr 1
  · congr 1
    · ext l; simp
    · funext l; by_cases hk : l.keepAtDepth k <;> simp [hk]
  · congr 1
    · ext l; simp
    · funext l; by_cases hk : l.keepAtDepth k <;> simp [hk]

lemma popDepth_succ_of_eq {m : ArithRAMMemory} {k : ℕ} (h : m.popDepth k = m) :
    m.popDepth (k + 1) = m := by
  have hkeep : ∀ l : RAMCellLoc, l.keepAtDepth k = true → l.keepAtDepth (k + 1) = true := by
    intro l hk; cases l with
    | heap _ _ => rfl
    | localFrame d _ _ => simp only [RAMCellLoc.keepAtDepth, decide_eq_true_eq] at hk ⊢; omega
  rw [← h]
  unfold ArithRAMMemory.popDepth WordStore.popDepth RealStore.popDepth
  dsimp only
  congr 1
  · congr 1
    · ext l; simp only [Finset.mem_filter, and_iff_left_iff_imp]; exact fun ⟨_, hk⟩ => hkeep l hk
    · funext l
      by_cases hk : l.keepAtDepth k = true
      · simp [hk, hkeep l hk]
      · have hkf : l.keepAtDepth k = false := Bool.eq_false_iff.mpr hk
        by_cases hk1 : l.keepAtDepth (k + 1) = true <;> simp [hkf, hk1]
  · congr 1
    · ext l; simp only [Finset.mem_filter, and_iff_left_iff_imp]; exact fun ⟨_, hk⟩ => hkeep l hk
    · funext l
      by_cases hk : l.keepAtDepth k = true
      · simp [hk, hkeep l hk]
      · have hkf : l.keepAtDepth k = false := Bool.eq_false_iff.mpr hk
        by_cases hk1 : l.keepAtDepth (k + 1) = true <;> simp [hkf, hk1]

lemma mem_writeWord_popDepth {m : ArithRAMMemory} {k : ℕ} {loc : RAMCellLoc} (v : ℤ)
    (hm : m.popDepth k = m) (hloc : loc.keepAtDepth k = true) :
    ({ m with words := m.words.write loc v } : ArithRAMMemory).popDepth k =
      { m with words := m.words.write loc v } := by
  have hws : m.words.popDepth k = m.words := congrArg ArithRAMMemory.words hm
  have hrs : m.reals.popDepth k = m.reals := congrArg ArithRAMMemory.reals hm
  have hlive : ∀ l ∈ m.words.live, l.keepAtDepth k = true := fun l hl => by
    have : l ∈ (m.words.popDepth k).live := by rwa [hws]
    exact (Finset.mem_filter.mp this).2
  unfold ArithRAMMemory.popDepth WordStore.popDepth WordStore.write
  dsimp only; rw [hrs]; congr 1; congr 1
  · ext l; simp only [Finset.mem_filter, Finset.mem_insert, and_iff_left_iff_imp]
    rintro (rfl | hl); exact hloc; exact hlive l hl
  · funext l; by_cases heq : l = loc
    · subst heq; simp [hloc]
    · simp only [Function.update_of_ne heq]; exact congrFun (congrArg WordStore.vals hws) l

lemma mem_freeWord_popDepth {m : ArithRAMMemory} {k : ℕ} {loc : RAMCellLoc}
    (hm : m.popDepth k = m) :
    ({ m with words := m.words.free loc } : ArithRAMMemory).popDepth k =
      { m with words := m.words.free loc } := by
  have hws : m.words.popDepth k = m.words := congrArg ArithRAMMemory.words hm
  have hrs : m.reals.popDepth k = m.reals := congrArg ArithRAMMemory.reals hm
  have hlive : ∀ l ∈ m.words.live, l.keepAtDepth k = true := fun l hl => by
    have : l ∈ (m.words.popDepth k).live := by rwa [hws]
    exact (Finset.mem_filter.mp this).2
  unfold ArithRAMMemory.popDepth WordStore.popDepth WordStore.free
  dsimp only; rw [hrs]; congr 1; congr 1
  · ext l; simp only [Finset.mem_filter, Finset.mem_erase, and_iff_left_iff_imp]
    exact fun ⟨_, hl⟩ => hlive l hl
  · funext l; by_cases heq : l = loc
    · subst heq; simp
    · simp only [Function.update_of_ne heq]; exact congrFun (congrArg WordStore.vals hws) l

lemma mem_writeReal_popDepth {m : ArithRAMMemory} {k : ℕ} {loc : RAMCellLoc} (v : ℝ)
    (hm : m.popDepth k = m) (hloc : loc.keepAtDepth k = true) :
    ({ m with reals := m.reals.write loc v } : ArithRAMMemory).popDepth k =
      { m with reals := m.reals.write loc v } := by
  have hws : m.words.popDepth k = m.words := congrArg ArithRAMMemory.words hm
  have hrs : m.reals.popDepth k = m.reals := congrArg ArithRAMMemory.reals hm
  have hlive : ∀ l ∈ m.reals.live, l.keepAtDepth k = true := fun l hl => by
    have : l ∈ (m.reals.popDepth k).live := by rwa [hrs]
    exact (Finset.mem_filter.mp this).2
  unfold ArithRAMMemory.popDepth RealStore.popDepth RealStore.write
  dsimp only; rw [hws]; congr 1; congr 1
  · ext l; simp only [Finset.mem_filter, Finset.mem_insert, and_iff_left_iff_imp]
    rintro (rfl | hl); exact hloc; exact hlive l hl
  · funext l; by_cases heq : l = loc
    · subst heq; simp [hloc]
    · simp only [Function.update_of_ne heq]; exact congrFun (congrArg RealStore.vals hrs) l

lemma mem_freeReal_popDepth {m : ArithRAMMemory} {k : ℕ} {loc : RAMCellLoc}
    (hm : m.popDepth k = m) :
    ({ m with reals := m.reals.free loc } : ArithRAMMemory).popDepth k =
      { m with reals := m.reals.free loc } := by
  have hws : m.words.popDepth k = m.words := congrArg ArithRAMMemory.words hm
  have hrs : m.reals.popDepth k = m.reals := congrArg ArithRAMMemory.reals hm
  have hlive : ∀ l ∈ m.reals.live, l.keepAtDepth k = true := fun l hl => by
    have : l ∈ (m.reals.popDepth k).live := by rwa [hrs]
    exact (Finset.mem_filter.mp this).2
  unfold ArithRAMMemory.popDepth RealStore.popDepth RealStore.free
  dsimp only; rw [hws]; congr 1; congr 1
  · ext l; simp only [Finset.mem_filter, Finset.mem_erase, and_iff_left_iff_imp]
    exact fun ⟨_, hl⟩ => hlive l hl
  · funext l; by_cases heq : l = loc
    · subst heq; simp
    · simp only [Function.update_of_ne heq]; exact congrFun (congrArg RealStore.vals hrs) l

inductive BalCont : ℕ → List ArithRAMCont → Prop
  | nil : BalCont 0 []
  | stmt {fd : ℕ} {s : ArithRAMStmt} {rest : List ArithRAMCont} :
      BalCont fd rest → BalCont fd (.stmt s :: rest)
  | rep {fd rem : ℕ} {b : ArithRAMStmt} {rest : List ArithRAMCont} :
      BalCont fd rest → BalCont fd (.repeatLoop rem b :: rest)
  | pop {fd : ℕ} {rest : List ArithRAMCont} :
      BalCont fd rest → BalCont (fd + 1) (.popScope fd :: rest)

private def ContOutProp {d : ℕ} (inp : ArithRAMInput d) (stk : List ArithRAMCont)
    (st : ArithRAMExecState) (out : ArithRAMExecOutcome) : Prop :=
  ∃ (f_used u_add : ℕ),
    st.unitCost + u_add = out.unitCost ∧
    ∀ (extraBits : List Bool) (u₀ pk₀ : ℕ) (rest : List ArithRAMCont),
      ∃ pk₁ : ℕ,
        ∀ f_rem : ℕ,
          runArithRAMFuel inp (f_used + f_rem) (stk ++ rest)
            { mem := st.mem, frameDepth := st.frameDepth,
              remainingBits := st.remainingBits ++ extraBits,
              unitCost := u₀, peakCellSpace := pk₀ } =
          runArithRAMFuel inp f_rem rest
            { mem := out.mem, frameDepth := 0, remainingBits := extraBits,
              unitCost := u₀ + u_add, peakCellSpace := pk₁ }

private lemma lift_contOutProp {d : ℕ} {inp : ArithRAMInput d}
    {stk stk' : List ArithRAMCont} {st st' : ArithRAMExecState} {out : ArithRAMExecOutcome}
    (u_step : ℕ) (pk_step : ℕ → ℕ)
    (hu_st : st'.unitCost = st.unitCost + u_step)
    (hstep_fn : ∀ (extraBits : List Bool) (u₀ pk₀ : ℕ) (rest : List ArithRAMCont) (f : ℕ),
      runArithRAMFuel inp (f + 1) (stk ++ rest)
        { mem := st.mem, frameDepth := st.frameDepth,
          remainingBits := st.remainingBits ++ extraBits,
          unitCost := u₀, peakCellSpace := pk₀ } =
      runArithRAMFuel inp f (stk' ++ rest)
        { mem := st'.mem, frameDepth := st'.frameDepth,
          remainingBits := st'.remainingBits ++ extraBits,
          unitCost := u₀ + u_step, peakCellSpace := pk_step pk₀ })
    (ih : ContOutProp inp stk' st' out) :
    ContOutProp inp stk st out := by
  rcases ih with ⟨fu, ua, hua, hcont⟩
  refine ⟨fu + 1, u_step + ua, by omega, fun extraBits u₀ pk₀ rest => ?_⟩
  rcases hcont extraBits (u₀ + u_step) (pk_step pk₀) rest with ⟨pk₁, hfn⟩
  refine ⟨pk₁, fun f_rem => ?_⟩
  have hf : (fu + 1) + f_rem = (fu + f_rem) + 1 := by omega
  have hu : u₀ + u_step + ua = u₀ + (u_step + ua) := by omega
  rw [hf, hstep_fn extraBits u₀ pk₀ rest (fu + f_rem), hfn f_rem, hu]

private theorem runArithRAMFuel_append_cont {d : ℕ} (inp : ArithRAMInput d) :
    ∀ (fuel : ℕ) (stk : List ArithRAMCont) (st : ArithRAMExecState) (out : ArithRAMExecOutcome),
      BalCont st.frameDepth stk →
      st.mem.popDepth st.frameDepth = st.mem →
      runArithRAMFuel inp fuel stk st = .halted out →
      ContOutProp inp stk st out
  | fuel, [], ⟨mem, fd, remBits, uCost, pk⟩, out, hbal, hpop, hrun => by
      dsimp only at hbal hpop
      cases hbal
      cases hrem : remBits.isEmpty
      · cases fuel <;> simp [runArithRAMFuel, hrem] at hrun
      · have hnil : remBits = [] := List.isEmpty_iff.mp hrem
        subst hnil
        have hout : out = { mem := mem.popDepth 0, unitCost := uCost, peakCellSpace := pk } := by
          cases fuel <;> simp [runArithRAMFuel] at hrun <;> exact hrun.symm
        subst hout
        refine ⟨0, 0, Nat.add_zero uCost, fun extraBits u₀ pk₀ rest => ⟨pk₀, fun f_rem => ?_⟩⟩
        simp [hpop]
  | 0, _ :: _, _, _, _, _, hrun => by simp [runArithRAMFuel] at hrun
  | fuel + 1, item :: stk', ⟨mem, fd, remBits, uCost, pk⟩, out, hbal, hpop, hrun => by
      dsimp only at hbal hpop
      cases hbal with
      | @pop prev _ hrest =>
          simp only [runArithRAMFuel] at hrun
          exact lift_contOutProp 0 id (Nat.add_zero _) (fun _ _ _ _ _ => rfl)
            (runArithRAMFuel_append_cont inp fuel stk' _ out hrest (popDepth_idem_gen mem prev) hrun)
      | @rep _ rem body _ hrest =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              exact lift_contOutProp 0 id (Nat.add_zero _) (fun _ _ _ _ _ => rfl)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest hpop hrun)
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              exact lift_contOutProp 0 id (Nat.add_zero _) (fun _ _ _ _ _ => rfl)
                (runArithRAMFuel_append_cont inp fuel (.stmt body :: .repeatLoop r body :: stk')
                  _ out (.stmt (.rep hrest)) hpop hrun)
      | @stmt _ s _ hrest =>
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              exact lift_contOutProp 1 id rfl (fun _ _ _ _ _ => rfl)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest hpop hrun)
          | writeWordHeap table idxE valE =>
              rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
              rcases he2 : evalIntExpr inp.toWordView fd mem.words valE with ⟨val, u₂, _⟩
              simp only [runArithRAMFuel, he1, he2] at hrun
              exact lift_contOutProp (u₁ + u₂ + 1)
                (fun p0 => max p0 (inp.inputCellSpace + ({ mem with words := mem.words.write (.heap table idx) val } : ArithRAMMemory).cellCount))
                (by dsimp; omega)
                (fun _ _ _ _ _ => by simp only [List.cons_append, runArithRAMFuel, he1, he2]; congr 2; omega)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest
                  (mem_writeWord_popDepth val hpop rfl) hrun)
          | writeWordLocal var idxE valE =>
              rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
              rcases he2 : evalIntExpr inp.toWordView fd mem.words valE with ⟨val, u₂, _⟩
              simp only [runArithRAMFuel, he1, he2] at hrun
              exact lift_contOutProp (u₁ + u₂ + 1)
                (fun p0 => max p0 (inp.inputCellSpace + ({ mem with words := mem.words.write (.localFrame fd var idx) val } : ArithRAMMemory).cellCount))
                (by dsimp; omega)
                (fun _ _ _ _ _ => by simp only [List.cons_append, runArithRAMFuel, he1, he2]; congr 2; omega)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest
                  (mem_writeWord_popDepth val hpop (by simp [RAMCellLoc.keepAtDepth])) hrun)
          | freeWordHeap table idxE =>
              rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
              simp only [runArithRAMFuel, he1] at hrun
              exact lift_contOutProp (u₁ + 1) id (by dsimp; omega)
                (fun _ _ _ _ _ => by dsimp only [List.cons_append]; simp only [runArithRAMFuel, he1, id_eq, Nat.add_assoc]; try rfl)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest (mem_freeWord_popDepth hpop) hrun)
          | freeWordLocal var idxE =>
              rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
              simp only [runArithRAMFuel, he1] at hrun
              exact lift_contOutProp (u₁ + 1) id (by dsimp; omega)
                (fun _ _ _ _ _ => by dsimp only [List.cons_append]; simp only [runArithRAMFuel, he1, id_eq, Nat.add_assoc]; try rfl)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest (mem_freeWord_popDepth hpop) hrun)
          | writeRealHeap table idxE valE =>
              rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
              rcases he2 : evalRealExpr inp fd mem valE with ⟨val, u₂⟩
              simp only [runArithRAMFuel, he1, he2] at hrun
              exact lift_contOutProp (u₁ + u₂ + 1)
                (fun p0 => max p0 (inp.inputCellSpace + ({ mem with reals := mem.reals.write (.heap table idx) val } : ArithRAMMemory).cellCount))
                (by dsimp; omega)
                (fun _ _ _ _ _ => by simp only [List.cons_append, runArithRAMFuel, he1, he2]; congr 2; omega)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest
                  (mem_writeReal_popDepth val hpop rfl) hrun)
          | writeRealLocal var idxE valE =>
              rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
              rcases he2 : evalRealExpr inp fd mem valE with ⟨val, u₂⟩
              simp only [runArithRAMFuel, he1, he2] at hrun
              exact lift_contOutProp (u₁ + u₂ + 1)
                (fun p0 => max p0 (inp.inputCellSpace + ({ mem with reals := mem.reals.write (.localFrame fd var idx) val } : ArithRAMMemory).cellCount))
                (by dsimp; omega)
                (fun _ _ _ _ _ => by simp only [List.cons_append, runArithRAMFuel, he1, he2]; congr 2; omega)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest
                  (mem_writeReal_popDepth val hpop (by simp [RAMCellLoc.keepAtDepth])) hrun)
          | freeRealHeap table idxE =>
              rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
              simp only [runArithRAMFuel, he1] at hrun
              exact lift_contOutProp (u₁ + 1) id (by dsimp; omega)
                (fun _ _ _ _ _ => by dsimp only [List.cons_append]; simp only [runArithRAMFuel, he1, id_eq, Nat.add_assoc]; try rfl)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest (mem_freeReal_popDepth hpop) hrun)
          | freeRealLocal var idxE =>
              rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
              simp only [runArithRAMFuel, he1] at hrun
              exact lift_contOutProp (u₁ + 1) id (by dsimp; omega)
                (fun _ _ _ _ _ => by dsimp only [List.cons_append]; simp only [runArithRAMFuel, he1, id_eq, Nat.add_assoc]; try rfl)
                (runArithRAMFuel_append_cont inp fuel stk' _ out hrest (mem_freeReal_popDepth hpop) hrun)
          | randBitHeap table idxE =>
              cases remBits with
              | nil => simp [runArithRAMFuel] at hrun
              | cons bit bs' =>
                  rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
                  simp only [runArithRAMFuel, he1] at hrun
                  let v : ℤ := if bit then 1 else 0
                  exact lift_contOutProp (u₁ + 1)
                    (fun p0 => max p0 (inp.inputCellSpace + ({ mem with words := mem.words.write (.heap table idx) v } : ArithRAMMemory).cellCount))
                    (by dsimp; omega)
                    (fun _ _ _ _ _ => by dsimp only [List.cons_append]; simp only [runArithRAMFuel, he1, id_eq, Nat.add_assoc]; try rfl)
                    (runArithRAMFuel_append_cont inp fuel stk' _ out hrest
                      (mem_writeWord_popDepth v hpop rfl) hrun)
          | randBitLocal var idxE =>
              cases remBits with
              | nil => simp [runArithRAMFuel] at hrun
              | cons bit bs' =>
                  rcases he1 : evalIntExpr inp.toWordView fd mem.words idxE with ⟨idx, u₁, _⟩
                  simp only [runArithRAMFuel, he1] at hrun
                  let v : ℤ := if bit then 1 else 0
                  exact lift_contOutProp (u₁ + 1)
                    (fun p0 => max p0 (inp.inputCellSpace + ({ mem with words := mem.words.write (.localFrame fd var idx) v } : ArithRAMMemory).cellCount))
                    (by dsimp; omega)
                    (fun _ _ _ _ _ => by dsimp only [List.cons_append]; simp only [runArithRAMFuel, he1, id_eq, Nat.add_assoc]; try rfl)
                    (runArithRAMFuel_append_cont inp fuel stk' _ out hrest
                      (mem_writeWord_popDepth v hpop (by simp [RAMCellLoc.keepAtDepth])) hrun)
          | seq s₁ s₂ =>
              simp only [runArithRAMFuel] at hrun
              exact lift_contOutProp 0 id (Nat.add_zero _) (fun _ _ _ _ _ => rfl)
                (runArithRAMFuel_append_cont inp fuel (.stmt s₁ :: .stmt s₂ :: stk')
                  _ out (.stmt (.stmt hrest)) hpop hrun)
          | ite cond tB fB =>
              rcases hec : evalArithCond inp fd mem cond with ⟨flag, uc⟩
              simp only [runArithRAMFuel, hec] at hrun
              exact lift_contOutProp uc id rfl
                (fun _ _ _ _ _ => by simp only [List.cons_append, runArithRAMFuel, hec, id_eq])
                (runArithRAMFuel_append_cont inp fuel (.stmt (if flag then tB else fB) :: stk')
                  _ out (.stmt hrest) hpop hrun)
          | whileLoop cond body =>
              rcases hec : evalArithCond inp fd mem cond with ⟨flag, uc⟩
              simp only [runArithRAMFuel, hec] at hrun
              have hbal' : BalCont fd (if flag then .stmt body :: .stmt (.whileLoop cond body) :: stk' else stk') := by
                split_ifs; exact .stmt (.stmt hrest); exact hrest
              exact lift_contOutProp uc id rfl
                (fun _ _ _ _ _ => by simp only [List.cons_append, runArithRAMFuel, hec, id_eq]; split_ifs <;> rfl)
                (runArithRAMFuel_append_cont inp fuel _ _ out hbal' hpop hrun)
          | repeatN countE body =>
              rcases hec : evalIntExpr inp.toWordView fd mem.words countE with ⟨cnt, uc, _⟩
              simp only [runArithRAMFuel, hec] at hrun
              exact lift_contOutProp uc id rfl
                (fun _ _ _ _ _ => by simp only [List.cons_append, runArithRAMFuel, hec, id_eq])
                (runArithRAMFuel_append_cont inp fuel (.repeatLoop (if 0 ≤ cnt then cnt.toNat else 0) body :: stk')
                  _ out (.rep hrest) hpop hrun)
          | localScope body =>
              simp only [runArithRAMFuel] at hrun
              have hpop_cl : (mem.popDepth fd).popDepth (fd + 1) = mem.popDepth fd := by
                rw [hpop]; exact popDepth_succ_of_eq hpop
              exact lift_contOutProp 0 id (Nat.add_zero _) (fun _ _ _ _ _ => rfl)
                (runArithRAMFuel_append_cont inp fuel (.stmt body :: .popScope fd :: stk')
                  _ out (.stmt (.pop hrest)) hpop_cl hrun)

theorem RandExecAt.det_mem {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {B C : ℕ} {mem₀ : ArithRAMMemory} {Post : (Fin B → Bool) → ArithRAMMemory → Prop}
    (hpop₀ : mem₀.popDepth 0 = mem₀)
    (hpop_post : ∀ f m, Post f m → m.popDepth 0 = m)
    (h : RandExecAt 0 inp s B mem₀ Post C) :
    ∃ nextM : (Fin B → Bool) → ArithRAMMemory,
      (∀ f, (nextM f).popDepth 0 = nextM f ∧ Post f (nextM f)) ∧
      RandExecAt 0 inp s B mem₀ (fun f m => m = nextM f) C := by
  classical
  have hex : ∀ f : Fin B → Bool,
      ∃ (fuel u₁ pk₁ : ℕ) (m₁ : ArithRAMMemory),
        u₁ ≤ C ∧ m₁.popDepth 0 = m₁ ∧ Post f m₁ ∧
        runArithRAMFuel inp fuel [.stmt s]
          { mem := mem₀, frameDepth := 0, remainingBits := List.ofFn f,
            unitCost := 0, peakCellSpace := 0 } =
          .halted { mem := m₁, unitCost := u₁, peakCellSpace := pk₁ } := by
    intro f
    rcases h.2 (List.ofFn f) (by simp) 0 0 [] with ⟨fuel, u₁, pk₁, m₁, hu₁, hp₁, hs⟩
    have hp₁' : Post f m₁ := by convert hp₁ using 1; ext i; simp
    have hm₁_pop : m₁.popDepth 0 = m₁ := hpop_post f m₁ hp₁'
    refine ⟨fuel, u₁, pk₁, m₁, by omega, hm₁_pop, hp₁', ?_⟩
    have hs0 := hs 0
    rw [Nat.add_zero] at hs0
    rw [hs0]
    have hdrop : (List.ofFn f).drop B = [] := by simp
    simp [runArithRAMFuel, hdrop, hm₁_pop]
  choose fuelFn uFn pkFn nextM huFn hpopFn hPostFn hrunFn using hex
  refine ⟨nextM, fun f => ⟨hpopFn f, hPostFn f⟩, h.1, ?_⟩
  intro bs hbs u₀ pk₀ rest
  let f : Fin B → Bool := fun i => bs[i.val]'(lt_of_lt_of_le i.isLt hbs)
  have hbs_eq : bs = List.ofFn f ++ bs.drop B := by
    have htake : List.ofFn f = bs.take B := by
      apply List.ext_getElem; simp [hbs]; intro i hi1 hi2; simp [f]
    rw [htake, List.take_append_drop]
  rcases runArithRAMFuel_append_cont inp (fuelFn f) [.stmt s] _ _
      (.stmt .nil) hpop₀ (hrunFn f) with ⟨fu, ua, hua, hcont⟩
  rcases hcont (bs.drop B) u₀ pk₀ rest with ⟨pk₁, hfn⟩
  have hu_le : u₀ + ua ≤ u₀ + C := by
    have h1 := huFn f
    have h2 : 0 + ua = uFn f := hua
    omega
  refine ⟨fu, u₀ + ua, pk₁, nextM f, hu_le, rfl, fun f_rem => ?_⟩
  have h1 := hfn f_rem
  rw [← hbs_eq] at h1
  exact h1

lemma bad_card_seq_adaptive {B₁ B₂ : ℕ} {p₁ p₂ : ℝ}
    (hp₁ : 0 ≤ p₁) (hp₂ : 0 ≤ p₂)
    (Bad₁ : (Fin B₁ → Bool) → Prop) [DecidablePred Bad₁]
    (Bad₂ : (Fin B₁ → Bool) → (Fin B₂ → Bool) → Prop) [∀ b₁, DecidablePred (Bad₂ b₁)]
    (hc₁ : ((Finset.univ.filter Bad₁).card : ℝ) ≤ p₁ * ((2 : ℝ) ^ B₁))
    (hc₂ : ∀ b₁, ((Finset.univ.filter (Bad₂ b₁)).card : ℝ) ≤ p₂ * ((2 : ℝ) ^ B₂)) :
    let BadComb : (Fin (B₁ + B₂) → Bool) → Prop := fun bits =>
      let b₁ : Fin B₁ → Bool := fun i => bits ⟨i.val, by omega⟩
      let b₂ : Fin B₂ → Bool := fun j => bits ⟨B₁ + j.val, by omega⟩
      Bad₁ b₁ ∨ Bad₂ b₁ b₂
    ((open Classical in (Finset.univ.filter BadComb).card) : ℝ) ≤
      (p₁ + p₂) * ((2 : ℝ) ^ (B₁ + B₂)) := by
  classical
  intro BadComb
  let splitE : (Fin (B₁ + B₂) → Bool) ≃ (Fin B₁ → Bool) × (Fin B₂ → Bool) :=
    { toFun := fun bits =>
        (fun i => bits ⟨i.val, by omega⟩, fun j => bits ⟨B₁ + j.val, by omega⟩)
      invFun := fun p k =>
        if hk : k.val < B₁ then p.1 ⟨k.val, hk⟩ else p.2 ⟨k.val - B₁, by omega⟩
      left_inv := fun bits => by
        ext k; dsimp only
        by_cases hk : k.val < B₁
        · simp [hk]
        · simp only [hk, ↓reduceDIte]; congr 1; ext; dsimp; omega
      right_inv := fun ⟨b₁, b₂⟩ => by
        ext i
        · dsimp only; simp [i.isLt]
        · dsimp only
          have hnot : ¬ (B₁ + i.val < B₁) := by omega
          simp only [hnot, ↓reduceDIte]; congr 1; ext; dsimp; omega }
  let S_pair : Finset ((Fin B₁ → Bool) × (Fin B₂ → Bool)) :=
    Finset.univ.filter (fun p => Bad₁ p.1 ∨ Bad₂ p.1 p.2)
  have hcard_eq : (Finset.univ.filter BadComb).card = S_pair.card := by
    refine Finset.card_bij (fun bits _ => splitE bits) ?_ ?_ ?_
    · intro bits hb
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, BadComb, S_pair, splitE] at hb ⊢
      exact hb
    · intro x _ y _ heq; exact splitE.injective heq
    · intro p hp
      refine ⟨splitE.symm p, ?_, splitE.apply_symm_apply p⟩
      have hp' : Bad₁ (splitE (splitE.symm p)).1 ∨
          Bad₂ (splitE (splitE.symm p)).1 (splitE (splitE.symm p)).2 := by
        rw [splitE.apply_symm_apply]
        exact (Finset.mem_filter.mp hp).2
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hp'⟩
  let A₁ : Finset ((Fin B₁ → Bool) × (Fin B₂ → Bool)) :=
    (Finset.univ.filter Bad₁) ×ˢ (Finset.univ : Finset (Fin B₂ → Bool))
  let A₂ : Finset ((Fin B₁ → Bool) × (Fin B₂ → Bool)) :=
    ((Finset.univ : Finset (Fin B₁ → Bool)).sigma (fun b₁ => Finset.univ.filter (Bad₂ b₁))).map
      ⟨fun s => (s.1, s.2), fun x y h => by cases x; cases y; cases h; rfl⟩
  have hsub : S_pair ⊆ A₁ ∪ A₂ := by
    intro ⟨b₁, b₂⟩ hp
    rcases (Finset.mem_filter.mp hp).2 with h1 | h2
    · exact Finset.mem_union_left _ (Finset.mem_product.mpr
        ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, h1⟩, Finset.mem_univ _⟩)
    · refine Finset.mem_union_right _ (Finset.mem_map.mpr ⟨⟨b₁, b₂⟩, ?_, rfl⟩)
      exact Finset.mem_sigma.mpr ⟨Finset.mem_univ _, Finset.mem_filter.mpr ⟨Finset.mem_univ _, h2⟩⟩
  have hle_nat : S_pair.card ≤ A₁.card + A₂.card :=
    (Finset.card_le_card hsub).trans (Finset.card_union_le _ _)
  have hA₁ : (A₁.card : ℝ) ≤ p₁ * ((2 : ℝ) ^ (B₁ + B₂)) := by
    have hc : A₁.card = (Finset.univ.filter Bad₁).card * 2 ^ B₂ := by simp [A₁]
    rw [hc, Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat, pow_add]
    calc ((Finset.univ.filter Bad₁).card : ℝ) * (2 : ℝ) ^ B₂ ≤ (p₁ * (2 : ℝ) ^ B₁) * (2 : ℝ) ^ B₂ := mul_le_mul_of_nonneg_right hc₁ (by positivity)
      _ = p₁ * ((2 : ℝ) ^ B₁ * (2 : ℝ) ^ B₂) := by ring
  have hA₂ : (A₂.card : ℝ) ≤ p₂ * ((2 : ℝ) ^ (B₁ + B₂)) := by
    have hc : A₂.card = ∑ b₁ : (Fin B₁ → Bool), (Finset.univ.filter (Bad₂ b₁)).card := by
      simp [A₂, Finset.card_sigma]
    rw [hc, Nat.cast_sum]
    calc ∑ b₁ : (Fin B₁ → Bool), ((Finset.univ.filter (Bad₂ b₁)).card : ℝ)
        ≤ ∑ _b₁ : (Fin B₁ → Bool), (p₂ * ((2 : ℝ) ^ B₂)) :=
          Finset.sum_le_sum (fun b₁ _ => hc₂ b₁)
      _ = ((2 ^ B₁ : ℕ) : ℝ) * (p₂ * ((2 : ℝ) ^ B₂)) := by simp
      _ = p₂ * ((2 : ℝ) ^ (B₁ + B₂)) := by push_cast; rw [pow_add]; ring
  rw [hcard_eq]
  have hle_r : (S_pair.card : ℝ) ≤ (A₁.card : ℝ) + (A₂.card : ℝ) := by exact_mod_cast hle_nat
  have _ := hp₁; have _ := hp₂
  linarith

def RandExecBad {d : ℕ} (inp : ArithRAMInput d) (s : ArithRAMStmt) (B : ℕ)
    (mem₀ : ArithRAMMemory)
    (SafePost : ArithRAMMemory → Prop)
    (GoodPost : ArithRAMMemory → Prop)
    (p_bad : ℝ) (costBound : ℕ) : Prop :=
  0 ≤ p_bad ∧
  ∃ (Post : (Fin B → Bool) → ArithRAMMemory → Prop)
    (Bad : (Fin B → Bool) → Prop) (_ : DecidablePred Bad),
    RandExecAt 0 inp s B mem₀ Post costBound ∧
    ((Finset.univ.filter Bad).card : ℝ) ≤ p_bad * ((2 : ℝ) ^ B) ∧
    ∀ (bits : Fin B → Bool) (m' : ArithRAMMemory),
      Post bits m' →
        m'.popDepth 0 = m' ∧
        SafePost m' ∧
        (¬ Bad bits → GoodPost m')

theorem RandExecBad.mono {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt} {B : ℕ}
    {mem₀ : ArithRAMMemory} {Safe₁ Safe₂ Good₁ Good₂ : ArithRAMMemory → Prop}
    {p₁ p₂ : ℝ} {C₁ C₂ : ℕ}
    (h : RandExecBad inp s B mem₀ Safe₁ Good₁ p₁ C₁)
    (hS : ∀ m, Safe₁ m → Safe₂ m)
    (hG : ∀ m, Safe₁ m → Good₁ m → Good₂ m)
    (hp : p₁ ≤ p₂)
    (hC : C₁ ≤ C₂) :
    RandExecBad inp s B mem₀ Safe₂ Good₂ p₂ C₂ := by
  rcases h with ⟨hp₁, Post, Bad, _, hR, hcard, hpost⟩
  refine ⟨by linarith, Post, Bad, inferInstance, hR.mono (fun _ _ hp' => hp') hC, ?_, ?_⟩
  · exact hcard.trans (mul_le_mul_of_nonneg_right hp (by positivity))
  · intro bits m' hp'
    rcases hpost bits m' hp' with ⟨hpop, hs, hg⟩
    exact ⟨hpop, hS m' hs, fun hnb => hG m' hs (hg hnb)⟩

theorem RandExecBad.of_det {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {mem₀ mem₁ : ArithRAMMemory} {SafePost GoodPost : ArithRAMMemory → Prop} {C : ℕ}
    (hd : DetExecAt 0 inp s mem₀ mem₁ C)
    (hpop₁ : mem₁.popDepth 0 = mem₁)
    (hS : SafePost mem₁)
    (hG : GoodPost mem₁) :
    RandExecBad inp s 0 mem₀ SafePost GoodPost 0 C := by
  refine ⟨le_rfl, (fun _ m => m = mem₁), (fun _ => False), inferInstance,
    RandExecAt.of_det hd, by simp, ?_⟩
  intro _ m' hm'; subst hm'; exact ⟨hpop₁, hS, fun _ => hG⟩

theorem RandExecBad.congr_bits {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {B₁ B₂ : ℕ} {mem₀ : ArithRAMMemory} {SafePost GoodPost : ArithRAMMemory → Prop}
    {p_bad : ℝ} {C : ℕ}
    (hB : B₁ = B₂)
    (h : RandExecBad inp s B₁ mem₀ SafePost GoodPost p_bad C) :
    RandExecBad inp s B₂ mem₀ SafePost GoodPost p_bad C := by
  subst hB; exact h

theorem RandExecBad.seq {d : ℕ} {inp : ArithRAMInput d} {s₁ s₂ : ArithRAMStmt}
    {B₁ B₂ : ℕ} {mem₀ : ArithRAMMemory}
    {Safe₁ Safe₂ Good₁ Good₂ : ArithRAMMemory → Prop}
    {p₁ p₂ : ℝ} {C₁ C₂ : ℕ}
    (hpop₀ : mem₀.popDepth 0 = mem₀)
    (h₁ : RandExecBad inp s₁ B₁ mem₀ Safe₁ Good₁ p₁ C₁)
    (h₂ : ∀ m₁, m₁.popDepth 0 = m₁ → Safe₁ m₁ →
      RandExecBad inp s₂ B₂ m₁ Safe₂ (fun m₂ => Good₁ m₁ → Good₂ m₂) p₂ C₂) :
    RandExecBad inp (.seq s₁ s₂) (B₁ + B₂) mem₀ Safe₂ Good₂ (p₁ + p₂) (C₁ + C₂) := by
  classical
  rcases h₁ with ⟨hp₁, Post₁, Bad₁, _, hR₁, hcard₁, hpost₁⟩
  rcases RandExecAt.det_mem hpop₀ (fun f m hp => (hpost₁ f m hp).1) hR₁
    with ⟨nextM₁, hnext₁, hR₁_det⟩
  have hex₂ : ∀ b₁ : Fin B₁ → Bool,
      ∃ (Post₂ : (Fin B₂ → Bool) → ArithRAMMemory → Prop)
        (Bad₂ : (Fin B₂ → Bool) → Prop),
        0 ≤ p₂ ∧
        RandExecAt 0 inp s₂ B₂ (nextM₁ b₁) Post₂ C₂ ∧
        ((Finset.univ.filter Bad₂).card : ℝ) ≤ p₂ * ((2 : ℝ) ^ B₂) ∧
        ∀ (b₂ : Fin B₂ → Bool) (m₂ : ArithRAMMemory),
          Post₂ b₂ m₂ →
            m₂.popDepth 0 = m₂ ∧ Safe₂ m₂ ∧
            (¬ Bad₂ b₂ → Good₁ (nextM₁ b₁) → Good₂ m₂) := by
    intro b₁
    rcases hpost₁ b₁ (nextM₁ b₁) (hnext₁ b₁).2 with ⟨hpop₁, hs₁, _⟩
    rcases h₂ (nextM₁ b₁) hpop₁ hs₁ with ⟨hp₂, P₂, Bd₂, _, hR₂, hc₂, hp₂'⟩
    exact ⟨P₂, Bd₂, hp₂, hR₂, by convert hc₂, hp₂'⟩
  have hp₂ : 0 ≤ p₂ := (hex₂ (fun _ => false)).choose_spec.choose_spec.1
  choose Post₂ Bad₂ _ hR₂ hcard₂ hpost₂ using hex₂
  let leftB : (Fin (B₁ + B₂) → Bool) → (Fin B₁ → Bool) := fun bits i => bits ⟨i.val, by omega⟩
  let rightB : (Fin (B₁ + B₂) → Bool) → (Fin B₂ → Bool) := fun bits j => bits ⟨B₁ + j.val, by omega⟩
  let PostComb : (Fin (B₁ + B₂) → Bool) → ArithRAMMemory → Prop := fun bits m₂ =>
    Post₂ (leftB bits) (rightB bits) m₂
  let BadComb : (Fin (B₁ + B₂) → Bool) → Prop := fun bits =>
    Bad₁ (leftB bits) ∨ Bad₂ (leftB bits) (rightB bits)
  have hR_comb : RandExecAt 0 inp (.seq s₁ s₂) (B₁ + B₂) mem₀ PostComb (C₁ + C₂) := by
    refine RandExecAt.seq hR₁_det ?_
    intro b₁ m₁ hm₁; subst hm₁
    refine (hR₂ b₁).mono ?_ le_rfl
    intro b₂ m₂ hm₂
    dsimp only [PostComb, leftB, rightB]
    have hl : (fun i : Fin B₁ =>
        if hj : (i.val < B₁) then b₁ ⟨i.val, hj⟩ else b₂ ⟨i.val - B₁, by omega⟩) = b₁ := by
      ext i; simp [i.isLt]
    have hr : (fun j : Fin B₂ =>
        if hj : (B₁ + j.val < B₁) then b₁ ⟨B₁ + j.val, hj⟩
        else b₂ ⟨B₁ + j.val - B₁, by omega⟩) = b₂ := by
      ext j
      have hnot : ¬ (B₁ + j.val < B₁) := by omega
      simp only [hnot, ↓reduceDIte]; congr 1; ext; dsimp; omega
    rw [hl, hr]; exact hm₂
  have hcard_comb := bad_card_seq_adaptive hp₁ hp₂ Bad₁ Bad₂ (by convert hcard₁) (fun b₁ => by convert hcard₂ b₁)
  refine ⟨by linarith, PostComb, BadComb, inferInstance, hR_comb, hcard_comb, ?_⟩
  intro bits m₂ hm₂
  rcases hpost₂ (leftB bits) (rightB bits) m₂ hm₂ with ⟨hpop₂, hs₂, hg₂⟩
  rcases hpost₁ (leftB bits) (nextM₁ (leftB bits)) (hnext₁ (leftB bits)).2 with ⟨_, _, hg₁⟩
  refine ⟨hpop₂, hs₂, fun hnb => ?_⟩
  exact hg₂ (fun h2 => hnb (Or.inr h2)) (hg₁ (fun h1 => hnb (Or.inl h1)))

theorem RandExecBad.seq_det_left {d : ℕ} {inp : ArithRAMInput d} {s₁ s₂ : ArithRAMStmt}
    {B : ℕ} {mem₀ mem₁ : ArithRAMMemory}
    {SafePost GoodPost : ArithRAMMemory → Prop}
    {p_bad : ℝ} {C₁ C₂ : ℕ}
    (hpop₀ : mem₀.popDepth 0 = mem₀)
    (hpop₁ : mem₁.popDepth 0 = mem₁)
    (hd : DetExecAt 0 inp s₁ mem₀ mem₁ C₁)
    (hr : RandExecBad inp s₂ B mem₁ SafePost GoodPost p_bad C₂) :
    RandExecBad inp (.seq s₁ s₂) B mem₀ SafePost GoodPost p_bad (C₁ + C₂) := by
  have h1 : RandExecBad inp s₁ 0 mem₀ (fun m => m = mem₁) (fun _ => True) 0 C₁ :=
    RandExecBad.of_det hd hpop₁ rfl trivial
  have hcomb := RandExecBad.seq hpop₀ h1 (fun m₁ _ hm₁ => by
    subst hm₁
    exact hr.mono (fun _ h => h) (fun _ _ hg _ => hg) le_rfl le_rfl)
  rw [zero_add, zero_add] at hcomb
  exact hcomb

theorem RandExecBad.seq_det_right {d : ℕ} {inp : ArithRAMInput d} {s₁ s₂ : ArithRAMStmt}
    {B : ℕ} {mem₀ : ArithRAMMemory}
    {Safe₁ Safe₂ Good₁ Good₂ : ArithRAMMemory → Prop}
    {p_bad : ℝ} {C₁ C₂ : ℕ}
    (hpop₀ : mem₀.popDepth 0 = mem₀)
    (hr : RandExecBad inp s₁ B mem₀ Safe₁ Good₁ p_bad C₁)
    (hd : ∀ m₁, m₁.popDepth 0 = m₁ → Safe₁ m₁ →
      ∃ m₂, DetExecAt 0 inp s₂ m₁ m₂ C₂ ∧ m₂.popDepth 0 = m₂ ∧
        Safe₂ m₂ ∧ (Good₁ m₁ → Good₂ m₂)) :
    RandExecBad inp (.seq s₁ s₂) B mem₀ Safe₂ Good₂ p_bad (C₁ + C₂) := by
  have hcomb := RandExecBad.seq hpop₀ hr (fun m₁ hp₁ hs₁ => by
    rcases hd m₁ hp₁ hs₁ with ⟨m₂, hd₂, hp₂, hs₂, hg₂⟩
    exact RandExecBad.of_det hd₂ hp₂ hs₂ hg₂)
  rw [Nat.add_zero, add_zero] at hcomb
  exact hcomb

theorem RandExecBad.ite_true {d : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {B : ℕ} {mem₀ : ArithRAMMemory}
    {SafePost GoodPost : ArithRAMMemory → Prop} {p_bad : ℝ} {C_c C : ℕ}
    (hc : cValAt 0 inp mem₀ cond = true)
    (hcc : condExprOps cond ≤ C_c)
    (ht : RandExecBad inp tB B mem₀ SafePost GoodPost p_bad C) :
    RandExecBad inp (.ite cond tB fB) B mem₀ SafePost GoodPost p_bad (C_c + C) := by
  rcases ht with ⟨hp, Post, Bad, _, hR, hcard, hpost⟩
  exact ⟨hp, Post, Bad, inferInstance, RandExecAt.ite_true hc hcc hR, hcard, hpost⟩

theorem RandExecBad.ite_false {d : ℕ} {inp : ArithRAMInput d} {cond : ArithCondExpr}
    {tB fB : ArithRAMStmt} {B : ℕ} {mem₀ : ArithRAMMemory}
    {SafePost GoodPost : ArithRAMMemory → Prop} {p_bad : ℝ} {C_c C : ℕ}
    (hc : cValAt 0 inp mem₀ cond = false)
    (hcc : condExprOps cond ≤ C_c)
    (hf : RandExecBad inp fB B mem₀ SafePost GoodPost p_bad C) :
    RandExecBad inp (.ite cond tB fB) B mem₀ SafePost GoodPost p_bad (C_c + C) := by
  rcases hf with ⟨hp, Post, Bad, _, hR, hcard, hpost⟩
  exact ⟨hp, Post, Bad, inferInstance, RandExecAt.ite_false hc hcc hR, hcard, hpost⟩


end UL.Proof_lem_7_2_RacerP46
