import Mathlib
import UL.Stmt.lem_7_2
import UL.Stmt.cit_hpj19_thm18
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_mc_baseline
import UL.Stmt.lem_5_2
import UL.Stmt.lem_C_2
import UL.Stmt.clm_7_3_failure_budget
import UL.Proof.lem_7_2.CG01_ServingSchedC
import UL.Proof.lem_7_2.CG03_JobTickB1
import UL.Proof.lem_7_2.CG04_StepAns
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Concrete `AnswerStageSpec` Instantiation from `CG03_JobTickB1` -/

lemma baselineLeafFinalizeCost_eq_p46AnsStageCost (d n M_leaf : ℕ) (p : P46Params d n) :
    baselineLeafFinalizeCost d n M_leaf p = p46AnsStageCost d n M_leaf p :=
  rfl

def buildAnswerStageSpec
    (h_lem_5_2 : S_lem_5_2)
    {d n T_max M_box : ℕ}
    (hT : 27 ≤ T_max)
    (p : P46Params d n) :
    AnswerStageSpec d n T_max M_box p where
  ansStmt := baselineLeafAndFinalizeStmt d n (3 * p.L + 2) M_box p
  hBoxSafe := boxSafe_baselineLeafAndFinalizeStmt hT p
  hExecAns := by
    intro k inp mem P leafS fSq0 fSqLeaf ghostCoords ActiveUids uidOfH hOfUid nodes P_good
    exact exec_baselineLeafAndFinalizeStmt (M_leaf := 3 * p.L + 2) (M_box := M_box)
      (P := P) (leafS := leafS) (fSq0 := fSq0) (fSqLeaf := fSqLeaf)
      (ghostCoords := ghostCoords) (ActiveUids := ActiveUids)
      (uidOfH := uidOfH) (hOfUid := hOfUid) (P_good := P_good)
      h_lem_5_2 p inp mem nodes

/-! ### 2. Post-Routing `trueAge'` Extraction & Single-Hypothesis `MiddleTickSplitSpec` Bridge -/

lemma PostRouteContext.exists_trueAge_post
    {d n : ℕ} {p : P46Params d n}
    {EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop}
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
    {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
    {opH : ℕ} {uMap' : GhostUidMap d P'}
    (ctx : PostRouteContext p EncJobs P op m_pre st₀ mem_rt P' opH uMap') :
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    let aff : Fin (st₀.k + 1) → Bool := chainLevelAffected P P' st₀.nodes ins opH
    let snAge' : Fin st₀.k → ℕ := fun r => if aff r.castSucc then st₀.snAge r + 1 else st₀.snAge r
    ∃ trueAge' : Fin st₀.k → ℕ,
      (∀ r : Fin st₀.k, trueAge' r ≤ snAge' r) ∧
      (∀ r : Fin st₀.k,
        HasNodeAge (st₀.birthSnap r)
          (chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc) (trueAge' r)) := by
  classical
  intro ins aff snAge'
  have hex : ∀ r : Fin st₀.k,
      ∃ trAge' ≤ snAge' r,
        HasNodeAge (st₀.birthSnap r)
          (chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc) trAge' := by
    intro r
    rcases ctx.hCoupled_pre.2.1.1 r with ⟨_, _, _, htr_le, hage_pre, _⟩
    have hp := (ctx.hPerNode r).2.2.2 (st₀.birthSnap r) (st₀.trueAge r) htr_le hage_pre
    cases op <;> exact hp
  choose trueAge' htr_le' hhas_age' using hex
  exact ⟨trueAge', htr_le', hhas_age'⟩

/-- Reduces `UL.S_lem_7_2` directly to constructing `MiddleTickSplitSpec` (with `CG03_JobTickB1`'s
answer-readout stage already wired in via `buildAnswerStageSpec h_lem_5_2`). -/
theorem prove_S_lem_7_2_of_only_middleTickSplit
    (h_lem_5_2 : S_lem_5_2)
    (h_fb : S_clm_7_3_failure_budget)
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    (C_cap C_mid_poly C_box_poly : ℕ)
    (hBuild : ∀ (d n t : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        C_cap * (D ^ 4 * H ^ 2) < n →
        ∀ (p : P46Params d n),
          P46ParamsValid cHpj (extractCBaseNat h_mc) d n t δ p →
          ∃ mid : MiddleTickSplitSpec cHpj (extractCBaseNat h_mc) d n t δ p,
            mid.C_mid ≤ C_mid_poly * (D ^ 19 * H ^ 18) ∧
            mid.T_max * mid.M_box ≤ C_box_poly * n * (D ^ 19 * H ^ 18)) :
    S_lem_7_2 := by
  refine prove_S_lem_7_2_of_middleTickSplitSpec h_fb h_mc hcHpj C_cap C_mid_poly C_box_poly ?_
  intro d n t hd1 hn ht δ hδ0 hδ1 D H hcap p hp
  rcases hBuild d n t hd1 hn ht δ hδ0 hδ1 hcap p hp with ⟨mid, hCmid, hBox⟩
  exact ⟨mid, buildAnswerStageSpec h_lem_5_2 mid.hT27 p, hCmid, hBox⟩

end UL.Proof_lem_7_2_RacerP46
