import UL.Proof.lem_7_2.CG01_H4a2b

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-- Operation 3: Advance `ActiveJobGhost` across ONE root-pool clock tick `t_cur → t_cur + 1`
(when `g.t_cur < g.H_job`, already lifted to `ghostCoords'` via `liftCoords`)! -/
noncomputable def ActiveJobGhost.stepTick {d n D L B_scan nextUid' : ℕ}
    {ghostCoords' : ℕ → EuclideanSpace ℝ (Fin d)}
    {S_cur_uid S_cur_uid' : Finset ℕ}
    (g : ActiveJobGhost d n D L B_scan nextUid' ghostCoords' S_cur_uid)
    (hD : 3 ≤ D)
    (ht_lt : g.t_cur < g.H_job)
    (ev_step : PoolUpdateEvent ℕ)
    (hev_ck : ev_step.isClockTick = true)
    (hev_v : IsValidPoolUpdateEvent S_cur_uid S_cur_uid' ev_step)
    (hcap' : S_cur_uid'.card ≤ n)
    (huid' : ∀ u ∈ S_cur_uid', u < nextUid')
    {ph' scan' : ℕ} {Spar_last_h' : Finset ℕ}
    (hph'_le : ph' ≤ 2)
    (hpar_1 : Spar_last_h'.card ≤ g.Spar_last_h.card + 1 ∧
      ∀ c : ℕ, (Spar_last_h'.filter (fun x => c ≤ x)).card ≤
               (g.Spar_last_h.filter (fun x => c ≤ x)).card + 1)
    (hbuild_1 :
      let m_last := (g.lvs[g.lvs.length - 1]'(Nat.sub_lt g.hlvs_pos Nat.one_pos)).birthSnapshot.card
      (g.ph_cur = 0 →
        (g.scan_cur + (B_scan + 1) < m_last → ph' = 0 ∧ scan' = g.scan_cur + (B_scan + 1)) ∧
        (m_last ≤ g.scan_cur + (B_scan + 1) → ph' = 1 ∧ scan' = 0)) ∧
      (g.ph_cur = 1 →
        ph' = 2 ∨
        (ph' = 1 ∧
          (Spar_last_h'.filter (fun x => scan' ≤ x)).card + B_scan ≤
            (g.Spar_last_h.filter (fun x => g.scan_cur ≤ x)).card)) ∧
      (g.ph_cur = 2 → ph' = 2))
    (act : JobTickEndAction d D L ghostCoords' (g.H_job - (g.t_cur + 1)) g.closed ph'
      (prefixResidual ghostCoords' g.lvs S_cur_uid')) :
    ActiveJobGhost d n D L B_scan nextUid' ghostCoords' S_cur_uid' := by
  classical
  let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
  have hα2 : α ≤ 2 := by have := (alpha_pos_and_lt_half D hD).2.1; linarith
  let lastIdx := g.lvs.length - 1
  have hlast_lt : lastIdx < g.lvs.length := Nat.sub_lt g.hlvs_pos Nat.one_pos
  let lv_last_old := g.lvs[lastIdx]'hlast_lt
  let lv_last_rdy : OpenedJobLevel d ℕ := { lv_last_old with backgroundReady := decide (ph' = 2) }
  let lvs_rdy := g.lvs.set lastIdx lv_last_rdy
  let rem' := g.H_job - (g.t_cur + 1)
  let curRes' := prefixResidual ghostCoords' g.lvs S_cur_uid'
  have hchg_root : IsInputChange S_cur_uid S_cur_uid' := by
    cases ev_step with
    | externalInsert id => exact Or.inl ⟨id, hev_v.1, hev_v.2⟩
    | externalDelete id => exact Or.inr ⟨id, hev_v.1, hev_v.2⟩
    | virtualValueDelete => cases hev_ck
    | unaffected => cases hev_ck
  have hres_rdy_eq : prefixResidual ghostCoords' lvs_rdy S_cur_uid' = curRes' :=
    prefixResidual_set_ball_eq ghostCoords' g.lvs lastIdx lv_last_rdy hlast_lt rfl S_cur_uid'
  let j_upd := updatePendingJobRootPool ghostCoords' (g.job_hist g.t_cur) ev_step S_cur_uid'
  have hj_upd_eq : j_upd =
      { deadlineTicks := g.H_job
        remainingTicks := rem'
        completedPrefix := g.lvs
        currentResidual := curRes'
        closedAsLeaf := g.closed } := by
    dsimp [j_upd, updatePendingJobRootPool]
    rw [g.hcur_job]
    have htk : ev_step.ticks = 1 := by unfold PoolUpdateEvent.ticks; simp [hev_ck]
    dsimp [rem', curRes']
    congr 1; omega
  let j_mid : PendingReplacementJob d ℕ :=
    { deadlineTicks := g.H_job
      remainingTicks := rem'
      completedPrefix := lvs_rdy
      currentResidual := curRes'
      closedAsLeaf := g.closed }
  have hmark : JobMarkReadyStep j_upd j_mid := by
    rw [hj_upd_eq]
    dsimp only [j_mid, lvs_rdy]
    refine ⟨rfl, rfl, rfl, rfl, ?_⟩
    rw [List.forall₂_iff_get]
    refine ⟨by simp, fun i hi1 hi2 => ?_⟩
    simp only [List.get_eq_getElem]
    by_cases heq : i = lastIdx
    · subst heq
      simp only [List.getElem_set_self, lv_last_rdy, lv_last_old]
      refine ⟨trivial, trivial, trivial, fun hrdy => ?_⟩
      rw [g.hlast_ready, decide_eq_true_eq] at hrdy
      simp [hbuild_1.2.2 hrdy]
    · rw [List.getElem_set_ne (Ne.symm heq)]
      exact ⟨rfl, rfl, rfl, id⟩
  have hall_rdy_if2 : ph' = 2 → ∀ lv ∈ lvs_rdy, lv.backgroundReady = true := by
    intro h2 lv hmem
    rcases List.mem_iff_getElem.mp hmem with ⟨i, hi, rfl⟩
    dsimp only [lvs_rdy] at hi ⊢
    simp only [List.length_set] at hi
    by_cases heq : i = lastIdx
    · subst heq; simp [lv_last_rdy, h2]
    · rw [List.getElem_set_ne (Ne.symm heq)]
      exact g.hprev_ready i (by dsimp [lastIdx] at heq; omega)
  let out := applyJobTickEndAction lvs_rdy g.openRem scan' Spar_last_h' act
  let closed' := out.1
  let lvs' := out.2.1
  let openRem' := out.2.2.1
  let ph_out := out.2.2.2.1
  let scan_out := out.2.2.2.2.1
  let Spar_out := out.2.2.2.2.2
  let j_end : PendingReplacementJob d ℕ :=
    { deadlineTicks := g.H_job
      remainingTicks := rem'
      completedPrefix := lvs'
      currentResidual := prefixResidual ghostCoords' lvs' S_cur_uid'
      closedAsLeaf := closed' }
  have hpass_end : ScheduleTickPass α L ghostCoords' j_upd j_end := by
    cases act with
    | waitOrBuild hq =>
        have hje : j_end = j_mid := by
          dsimp [j_end, j_mid, closed', lvs', out, applyJobTickEndAction]
          rw [hres_rdy_eq]
        rw [hje]
        refine ⟨JobWithinTickChain.markReady hmark (.refl j_mid), ?_⟩
        rcases hq with hcl | hlt2 | hncan
        · exact Or.inl hcl
        · refine Or.inr (Or.inl ⟨lv_last_rdy, ?_, ?_⟩)
          · dsimp only [j_mid, lvs_rdy]
            exact List.mem_iff_getElem.mpr ⟨lastIdx, by simp [hlast_lt], by simp⟩
          · dsimp only [lv_last_rdy]; simp; omega
        · exact Or.inr (Or.inr hncan)
    | closeLeaf hcl hph2 hcan hsmall =>
        have hje : j_end = closeResidualAsLeafInJob j_mid := by
          dsimp [j_end, j_mid, closeResidualAsLeafInJob, closed', lvs', out, applyJobTickEndAction]
          rw [hres_rdy_eq]
        rw [hje]
        have hgate : JobGateStep α L ghostCoords' j_mid (closeResidualAsLeafInJob j_mid) :=
          ⟨hcl, hall_rdy_if2 hph2, hcan, Or.inl ⟨hsmall, rfl⟩⟩
        exact ⟨JobWithinTickChain.markReady hmark (.gate hgate (.refl _)), Or.inl rfl⟩
    | openLevel hcl hph2 hcan hlarge bUid hb res Spar_new_h hcard_new =>
        let ball_new := selectOpenedLevelBall α ghostCoords' curRes' bUid res
        have hje : j_end = openLargeLevelInJob ghostCoords' j_mid ball_new .radiusDictOnly := by
          dsimp [j_end, j_mid, openLargeLevelInJob, closed', lvs', out, applyJobTickEndAction, ball_new, α]
          rw [prefixResidual_append_singleton, hres_rdy_eq, hcl]
        rw [hje]
        have hgate : JobGateStep α L ghostCoords' j_mid
            (openLargeLevelInJob ghostCoords' j_mid ball_new .radiusDictOnly) :=
          ⟨hcl, hall_rdy_if2 hph2, hcan,
           Or.inr ⟨hlarge, res, ball_new, .radiusDictOnly,
             isValidOpenedLevelBall_selectOpenedLevelBall α ghostCoords' hb res, rfl⟩⟩
        have hquies : IsJobTickQuiescent α (openLargeLevelInJob ghostCoords' j_mid ball_new .radiusDictOnly) :=
          Or.inr (Or.inl ⟨{ birthSnapshot := j_mid.currentResidual, ball := ball_new, indexMode := .radiusDictOnly, backgroundReady := false }, List.mem_append_right _ (List.mem_singleton.mpr rfl), rfl⟩)
        exact ⟨JobWithinTickChain.markReady hmark (.gate hgate (.refl _)), hquies⟩
  let S_root' := Function.update g.S_root (g.t_cur + 1) S_cur_uid'
  let ev' := Function.update g.ev g.t_cur ev_step
  let job_hist' := Function.update g.job_hist (g.t_cur + 1) j_end
  have hS_old : ∀ s ≤ g.t_cur, S_root' s = g.S_root s :=
    fun _ hs => Function.update_of_ne (by omega) _ _
  have hj_old : ∀ s ≤ g.t_cur, job_hist' s = g.job_hist s :=
    fun _ hs => Function.update_of_ne (by omega) _ _
  have hev_old : ∀ t < g.t_cur, ev' t = g.ev t :=
    fun _ ht => Function.update_of_ne (by omega) _ _
  have hlvs'_pos : 1 ≤ lvs'.length := by
    cases act <;> simp [lvs', out, applyJobTickEndAction, lvs_rdy, g.hlvs_pos]
  have hph_out_le : ph_out ≤ 2 := by
    cases act <;> simp [ph_out, out, applyJobTickEndAction, hph'_le]
  have hprev_rdy' : ∀ (j : ℕ) (hj : j + 1 < lvs'.length),
      (lvs'[j]'(Nat.lt_of_succ_lt hj)).backgroundReady = true := by
    intro j hj
    cases act with
    | waitOrBuild _ =>
        dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy] at hj ⊢
        simp only [List.length_set] at hj
        rw [List.getElem_set_ne (by dsimp [lastIdx]; omega)]
        exact g.hprev_ready j hj
    | closeLeaf _ _ _ _ =>
        dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy] at hj ⊢
        simp only [List.length_set] at hj
        rw [List.getElem_set_ne (by dsimp [lastIdx]; omega)]
        exact g.hprev_ready j hj
    | openLevel _ hph2 _ _ _ _ _ _ _ =>
        dsimp only [lvs', out, applyJobTickEndAction] at hj ⊢
        simp only [List.length_append, List.length_singleton] at hj
        have hj_lt_rdy : j < lvs_rdy.length := by omega
        rw [List.getElem_append_left hj_lt_rdy]
        exact hall_rdy_if2 hph2 _ (List.getElem_mem hj_lt_rdy)
  have hlast_rdy' :
      (lvs'[lvs'.length - 1]'(Nat.sub_lt hlvs'_pos Nat.one_pos)).backgroundReady = decide (ph_out = 2) := by
    cases act with
    | waitOrBuild _ =>
        dsimp only [lvs', ph_out, out, applyJobTickEndAction, lvs_rdy, lastIdx, lv_last_rdy]
        simp
    | closeLeaf _ _ _ _ =>
        dsimp only [lvs', ph_out, out, applyJobTickEndAction, lvs_rdy, lastIdx, lv_last_rdy]
        simp
    | openLevel _ _ _ _ _ _ _ _ _ =>
        dsimp only [lvs', ph_out, out, applyJobTickEndAction]
        simp
  refine
    { H_job := g.H_job
      t_cur := g.t_cur + 1
      closed := closed'
      lvs := lvs'
      openRem := openRem'
      ph_cur := ph_out
      scan_cur := scan_out
      Spar_last_h := Spar_out
      hH_pos := g.hH_pos
      ht_le := Nat.succ_le_of_lt ht_lt
      hlvs_pos := hlvs'_pos
      hph_le := hph_out_le
      hprev_ready := hprev_rdy'
      hlast_ready := hlast_rdy'
      S_root := S_root'
      ev := ev'
      job_hist := job_hist'
      hS_cap := fun s hs => by
        rcases Nat.lt_or_eq_of_le hs with hlt | rfl
        · rw [hS_old s (by omega)]; exact g.hS_cap s (by omega)
        · dsimp only [S_root']; simp [hcap']
      hS_uid := fun s hs => by
        rcases Nat.lt_or_eq_of_le hs with hlt | rfl
        · rw [hS_old s (by omega)]; exact g.hS_uid s (by omega)
        · dsimp only [S_root']; simp; exact huid'
      hS_last := by dsimp only [S_root']; simp
      hm0 := by rw [hS_old 0 (Nat.zero_le _)]; exact g.hm0
      hH_eq := by rw [hS_old 0 (Nat.zero_le _)]; exact g.hH_eq
      hev_tick := fun t ht => by
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp ht) with hlt | rfl
        · rw [hev_old t hlt]; exact g.hev_tick t hlt
        · dsimp only [ev']; simp [hev_ck]
      hev_valid := fun t ht => by
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp ht) with hlt | rfl
        · rw [hS_old t (by omega), hS_old (t + 1) (by omega), hev_old t hlt]
          exact g.hev_valid t hlt
        · rw [hS_old g.t_cur le_rfl, g.hS_last]
          dsimp only [S_root', ev']; simp [hev_v]
      hinit := by rw [hS_old 0 (Nat.zero_le _), hj_old 0 (Nat.zero_le _)]; exact g.hinit
      hstep := fun t ht => by
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp ht) with hlt | rfl
        · rw [hj_old t (by omega), hj_old (t + 1) (by omega), hS_old (t + 1) (by omega), hev_old t hlt]
          exact g.hstep t hlt
        · rw [hj_old g.t_cur le_rfl]
          dsimp only [ev', S_root', job_hist']
          simp only [Function.update_self]
          exact hpass_end
      hrem_eq := fun s hs => by
        rcases Nat.lt_or_eq_of_le hs with hlt | rfl
        · rw [hj_old s (by omega)]; exact g.hrem_eq s (by omega)
        · dsimp only [job_hist', j_end, rem']; simp
      hcur_job := by dsimp only [job_hist', j_end, rem']; simp
      hlvs_inv := fun j hj => ?_ }
  by_cases hj_old_lt : j < g.lvs.length
  · have hj_rdy_lt : j < lvs_rdy.length := by dsimp [lvs_rdy]; simp [hj_old_lt]
    have hlv'_bs : (lvs'[j]'hj).birthSnapshot = (g.lvs[j]'hj_old_lt).birthSnapshot := by
      cases act with
      | waitOrBuild _ =>
          dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy]
          by_cases heq : j = lastIdx
          · subst heq; simp [lv_last_rdy, lv_last_old]
          · rw [List.getElem_set_ne (Ne.symm heq)]
      | closeLeaf _ _ _ _ =>
          dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy]
          by_cases heq : j = lastIdx
          · subst heq; simp [lv_last_rdy, lv_last_old]
          · rw [List.getElem_set_ne (Ne.symm heq)]
      | openLevel _ _ _ _ _ _ _ _ _ =>
          dsimp only [lvs', out, applyJobTickEndAction]
          rw [List.getElem_append_left hj_rdy_lt]
          dsimp only [lvs_rdy]
          by_cases heq : j = lastIdx
          · subst heq; simp [lv_last_rdy, lv_last_old]
          · rw [List.getElem_set_ne (Ne.symm heq)]
    have hlv'_ball : (lvs'[j]'hj).ball = (g.lvs[j]'hj_old_lt).ball := by
      cases act with
      | waitOrBuild _ =>
          dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy]
          by_cases heq : j = lastIdx
          · subst heq; simp [lv_last_rdy, lv_last_old]
          · rw [List.getElem_set_ne (Ne.symm heq)]
      | closeLeaf _ _ _ _ =>
          dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy]
          by_cases heq : j = lastIdx
          · subst heq; simp [lv_last_rdy, lv_last_old]
          · rw [List.getElem_set_ne (Ne.symm heq)]
      | openLevel _ _ _ _ _ _ _ _ _ =>
          dsimp only [lvs', out, applyJobTickEndAction]
          rw [List.getElem_append_left hj_rdy_lt]
          dsimp only [lvs_rdy]
          by_cases heq : j = lastIdx
          · subst heq; simp [lv_last_rdy, lv_last_old]
          · rw [List.getElem_set_ne (Ne.symm heq)]
    have hop_eq : openRem' j = g.openRem j := by
      cases act with
      | waitOrBuild _ => rfl
      | closeLeaf _ _ _ _ => rfl
      | openLevel _ _ _ _ _ _ _ _ _ =>
          dsimp only [openRem', out, applyJobTickEndAction]
          exact Function.update_of_ne (by dsimp [lvs_rdy]; simp; omega) _ _
    have htake_res : prefixResidual ghostCoords' (lvs'.take j) S_cur_uid' =
        prefixResidual ghostCoords' (g.lvs.take j) S_cur_uid' := by
      have htake_rdy : prefixResidual ghostCoords' (lvs_rdy.take j) S_cur_uid' =
          prefixResidual ghostCoords' (g.lvs.take j) S_cur_uid' := by
        have htk_eq : lvs_rdy.take j = g.lvs.take j := by
          dsimp [lvs_rdy]
          apply List.ext_getElem (by simp)
          intro k hk1 hk2
          simp only [List.getElem_take]
          rw [List.getElem_set_ne (by simp at hk1; dsimp [lastIdx]; omega)]
        rw [htk_eq]
      cases act with
      | waitOrBuild _ => exact htake_rdy
      | closeLeaf _ _ _ _ => exact htake_rdy
      | openLevel _ _ _ _ _ _ _ _ _ =>
          dsimp only [lvs', out, applyJobTickEndAction]
          rw [List.take_append_of_le_length (le_of_lt hj_rdy_lt)]
          exact htake_rdy
    rcases g.hlvs_inv j hj_old_lt with ⟨hlarge, huid_b, hpass, s_open, hs_le, hrem_j, hcan,
      ⟨age_j, ha_le, hage⟩, hnone, ⟨ph_tr, cur_tr, Spar_tr, hp0, hc0, hSc0, htr_step, htr_hist, htr_last⟩⟩
    rcases hasNodeAge_prefixResidual_step ghostCoords' (g.lvs.take j) hage hchg_root with ⟨age_j', ha'_le, hage'⟩
    refine ⟨by rw [hlv'_bs]; exact hlarge,
      by rw [hlv'_bs]; exact huid_b,
      by rw [hlv'_bs, hlv'_ball]; exact hpass,
      s_open, by omega, by rw [hop_eq, hrem_j],
      by rw [hop_eq, hlv'_bs]; exact hcan,
      ⟨age_j', by omega, by rw [hlv'_bs, htake_res]; exact hage'⟩,
      fun s hs => by rw [hj_old s (by omega)]; exact hnone s hs,
      ?_⟩
    let τ_end := g.t_cur - s_open
    have hτ_succ : g.t_cur + 1 - s_open = τ_end + 1 := by omega
    by_cases hj_is_last : j = lastIdx
    · rcases htr_last hj_is_last with ⟨hph_end, hcur_end, hSpar_end⟩
      let ph_tr' := Function.update ph_tr (τ_end + 1) ph'
      let cur_tr' := Function.update cur_tr (τ_end + 1) scan'
      let Spar_tr' := Function.update Spar_tr (τ_end + 1) Spar_last_h'
      have hp_old : ∀ τ ≤ τ_end, ph_tr' τ = ph_tr τ := fun _ h => Function.update_of_ne (by omega) _ _
      have hc_old : ∀ τ ≤ τ_end, cur_tr' τ = cur_tr τ := fun _ h => Function.update_of_ne (by omega) _ _
      have hS_tr_old : ∀ τ ≤ τ_end, Spar_tr' τ = Spar_tr τ := fun _ h => Function.update_of_ne (by omega) _ _
      refine ⟨ph_tr', cur_tr', Spar_tr',
        by rw [hp_old 0 (Nat.zero_le _), hp0],
        by rw [hc_old 0 (Nat.zero_le _), hc0],
        by rw [hS_tr_old 0 (Nat.zero_le _), hSc0, hlv'_bs],
        fun τ hτ => ?_,
        fun s hs1 hs2 => ?_,
        fun hj_still_last => ?_⟩
      · rw [hτ_succ] at hτ
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hτ) with hlt | rfl
        · rw [hp_old τ (by omega), hp_old (τ + 1) (by omega),
              hc_old τ (by omega), hc_old (τ + 1) (by omega),
              hS_tr_old τ (by omega), hS_tr_old (τ + 1) (by omega), hlv'_bs]
          exact htr_step τ hlt
        · rw [hp_old τ_end le_rfl, hc_old τ_end le_rfl, hS_tr_old τ_end le_rfl, hlv'_bs]
          dsimp only [ph_tr', cur_tr', Spar_tr']
          simp only [Function.update_self]
          dsimp only [τ_end] at *
          rw [hph_end, hcur_end, hSpar_end]
          subst hj_is_last
          exact ⟨hpar_1, hbuild_1⟩
      · rcases Nat.lt_or_eq_of_le hs2 with hlt | rfl
        · rw [hj_old s (by omega), hp_old (s - s_open) (by omega)]
          rcases htr_hist s hs1 (by omega) with ⟨lv_s, hget, hbs_s, hbl_s, hrdy_s⟩
          exact ⟨lv_s, hget, hbs_s.trans hlv'_bs.symm, hbl_s.trans hlv'_ball.symm, hrdy_s⟩
        · rw [hτ_succ]
          dsimp only [job_hist', ph_tr']
          simp only [Function.update_self]
          refine ⟨lv_last_rdy, ?_, ?_, ?_, rfl⟩
          · dsimp only [j_end]
            subst hj_is_last
            cases act with
            | waitOrBuild _ =>
                dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy]
                rw [List.getElem?_eq_getElem (by simp [hlast_lt]), List.getElem_set_self]
            | closeLeaf _ _ _ _ =>
                dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy]
                rw [List.getElem?_eq_getElem (by simp [hlast_lt]), List.getElem_set_self]
            | openLevel _ _ _ _ _ _ _ _ _ =>
                dsimp only [lvs', out, applyJobTickEndAction]
                rw [List.getElem?_append_left hj_rdy_lt]
                dsimp only [lvs_rdy]
                rw [List.getElem?_eq_getElem (by simp [hlast_lt]), List.getElem_set_self]
          · rw [hlv'_bs]; subst hj_is_last; rfl
          · rw [hlv'_ball]; subst hj_is_last; rfl
      · rw [hτ_succ]
        dsimp only [ph_tr', cur_tr', Spar_tr']
        simp only [Function.update_self]
        cases act with
        | waitOrBuild _ => exact ⟨rfl, rfl, rfl⟩
        | closeLeaf _ _ _ _ => exact ⟨rfl, rfl, rfl⟩
        | openLevel _ _ _ _ _ _ _ _ _ =>
            exfalso
            dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy] at hj_still_last
            simp only [List.length_append, List.length_singleton, List.length_set] at hj_still_last
            dsimp [lastIdx] at hj_is_last
            omega
    · have hj_succ_lt : j + 1 < g.lvs.length := by dsimp [lastIdx] at hj_is_last; omega
      have hrdy_old := g.hprev_ready j hj_succ_lt
      rcases htr_hist g.t_cur hs_le le_rfl with ⟨lv_tc, hget_tc, _, _, hrdy_tc⟩
      have hget_eq : (g.job_hist g.t_cur).completedPrefix[j]? = some (g.lvs[j]'hj_old_lt) := by
        rw [g.hcur_job]; simp [List.getElem?_eq_getElem hj_old_lt]
      rw [hget_eq] at hget_tc
      injection hget_tc with hlv_tc_eq
      subst hlv_tc_eq
      have hph_end2 : ph_tr τ_end = 2 := by
        rw [hrdy_old] at hrdy_tc
        exact of_decide_eq_true hrdy_tc.symm
      let ph_tr' := Function.update ph_tr (τ_end + 1) 2
      let Spar_tr' := Function.update Spar_tr (τ_end + 1) (Spar_tr τ_end)
      have hp_old : ∀ τ ≤ τ_end, ph_tr' τ = ph_tr τ := fun _ h => Function.update_of_ne (by omega) _ _
      have hS_tr_old : ∀ τ ≤ τ_end, Spar_tr' τ = Spar_tr τ := fun _ h => Function.update_of_ne (by omega) _ _
      have hj_not_new_last : j ≠ lvs'.length - 1 := by
        cases act <;> dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy] <;> simp <;> omega
      refine ⟨ph_tr', cur_tr, Spar_tr',
        by rw [hp_old 0 (Nat.zero_le _), hp0],
        hc0,
        by rw [hS_tr_old 0 (Nat.zero_le _), hSc0, hlv'_bs],
        fun τ hτ => ?_,
        fun s hs1 hs2 => ?_,
        fun hcontra => False.elim (hj_not_new_last hcontra)⟩
      · rw [hτ_succ] at hτ
        rcases Nat.lt_or_eq_of_le (Nat.lt_succ_iff.mp hτ) with hlt | rfl
        · rw [hp_old τ (by omega), hp_old (τ + 1) (by omega),
              hS_tr_old τ (by omega), hS_tr_old (τ + 1) (by omega), hlv'_bs]
          exact htr_step τ hlt
        · rw [hp_old τ_end le_rfl, hS_tr_old τ_end le_rfl]
          dsimp only [ph_tr', Spar_tr']
          simp only [Function.update_self, hph_end2]
          exact ⟨⟨by omega, fun _ => by omega⟩,
            (fun h0 => by omega),
            (fun h1 => by omega),
            (fun _ => trivial)⟩
      · rcases Nat.lt_or_eq_of_le hs2 with hlt | rfl
        · rw [hj_old s (by omega), hp_old (s - s_open) (by omega)]
          rcases htr_hist s hs1 (by omega) with ⟨lv_s, hget, hbs_s, hbl_s, hrdy_s⟩
          exact ⟨lv_s, hget, hbs_s.trans hlv'_bs.symm, hbl_s.trans hlv'_ball.symm, hrdy_s⟩
        · rw [hτ_succ]
          dsimp only [job_hist', ph_tr']
          simp only [Function.update_self]
          refine ⟨g.lvs[j]'hj_old_lt, ?_, hlv'_bs.symm, hlv'_ball.symm, by simp [hrdy_old]⟩
          dsimp only [j_end]
          cases act with
          | waitOrBuild _ =>
              dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy]
              rw [List.getElem?_eq_getElem hj_rdy_lt, List.getElem_set_ne (Ne.symm hj_is_last)]
          | closeLeaf _ _ _ _ =>
              dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy]
              rw [List.getElem?_eq_getElem hj_rdy_lt, List.getElem_set_ne (Ne.symm hj_is_last)]
          | openLevel _ _ _ _ _ _ _ _ _ =>
              dsimp only [lvs', out, applyJobTickEndAction]
              rw [List.getElem?_append_left hj_rdy_lt, List.getElem?_eq_getElem hj_rdy_lt]
              dsimp only [lvs_rdy]
              rw [List.getElem_set_ne (Ne.symm hj_is_last)]
  · cases act with
    | waitOrBuild _ =>
        dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy] at hj
        simp only [List.length_set] at hj
        exact False.elim (hj_old_lt hj)
    | closeLeaf _ _ _ _ =>
        dsimp only [lvs', out, applyJobTickEndAction, lvs_rdy] at hj
        simp only [List.length_set] at hj
        exact False.elim (hj_old_lt hj)
    | openLevel hcl hph2 hcan hlarge bUid hb res Spar_new_h hcard_new =>
        have hj_len : j < g.lvs.length + 1 := by
          simpa [lvs', out, applyJobTickEndAction, lvs_rdy] using hj
        have hj_eq : j = g.lvs.length := by omega
        subst hj_eq
        let ball_new := selectOpenedLevelBall α ghostCoords' curRes' bUid res
        let lv_new : OpenedJobLevel d ℕ :=
          { birthSnapshot := curRes', ball := ball_new, indexMode := .radiusDictOnly, backgroundReady := false }
        have hrdy_len : lvs_rdy.length = g.lvs.length := by dsimp [lvs_rdy]; simp
        have hlv'_eq : lvs'[g.lvs.length]'hj = lv_new := by
          dsimp only [lvs', out, applyJobTickEndAction, lv_new, ball_new, α, curRes']
          rw [List.getElem_append_right (by omega)]
          simp [hrdy_len]
        have hop_new : openRem' g.lvs.length = rem' := by
          dsimp only [openRem', out, applyJobTickEndAction]
          rw [hrdy_len, Function.update_self]
        have huid_curRes : ∀ u ∈ curRes', u < nextUid' :=
          fun u hu => huid' u (prefixResidual_subset ghostCoords' g.lvs S_cur_uid' hu)
        have htake_full : prefixResidual ghostCoords' (lvs'.take g.lvs.length) S_cur_uid' = curRes' := by
          dsimp only [lvs', out, applyJobTickEndAction]
          rw [← hrdy_len, List.take_append_of_le_length le_rfl, List.take_length]
          exact hres_rdy_eq
        have hnone_new : ∀ s < g.t_cur + 1, (job_hist' s).completedPrefix[g.lvs.length]? = none := by
          intro s hs
          rw [hj_old s (by omega)]
          have h1step : ∀ t < g.t_cur,
              (g.job_hist t).completedPrefix.length ≤ (g.job_hist (t + 1)).completedPrefix.length := by
            intro t ht
            have hch := (g.hstep t ht).1
            have hch_len : ∀ {x y : PendingReplacementJob d ℕ},
                JobWithinTickChain α L ghostCoords' x y →
                  x.completedPrefix.length ≤ y.completedPrefix.length := by
              intro x y hc
              induction hc with
              | refl _ => exact le_rfl
              | markReady hm _ ih =>
                  exact le_trans (le_of_eq hm.2.2.2.2.length_eq) ih
              | gate hg _ ih =>
                  rcases hg with ⟨_, _, _, (⟨_, rfl⟩ | ⟨_, _, _, _, _, rfl⟩)⟩
                  · exact ih
                  · simp only [openLargeLevelInJob, List.length_append, List.length_singleton] at ih
                    omega
            simpa [updatePendingJobRootPool] using hch_len hch
          have hlen_mono : ∀ a b : ℕ, a ≤ b → b ≤ g.t_cur →
              (g.job_hist a).completedPrefix.length ≤ (g.job_hist b).completedPrefix.length := by
            intro a b hab hbt
            induction b with
            | zero =>
                have ha0 : a = 0 := by omega
                subst ha0; exact le_rfl
            | succ b ih =>
                rcases Nat.lt_or_eq_of_le hab with hlt | rfl
                · exact le_trans (ih (by omega) (by omega)) (h1step b (by omega))
                · exact le_rfl
          have hle_len := hlen_mono s g.t_cur (by omega) le_rfl
          rw [g.hcur_job] at hle_len
          exact List.getElem?_eq_none hle_len
        rw [hlv'_eq]
        refine ⟨hlarge, huid_curRes,
          passesBirthCoreCheck_selectOpenedLevelBall hα2 ghostCoords' curRes' hb res,
          g.t_cur + 1, le_rfl, hop_new,
          by rw [hop_new]; exact hcan,
          ⟨0, Nat.zero_le _, by rw [htake_full]; exact hasNodeAge_zero curRes'⟩,
          hnone_new,
          ⟨fun _ => 0, fun _ => 0, fun _ => Spar_new_h, rfl, rfl, hcard_new,
            fun _ hτ => by omega,
            fun s hs1 hs2 => by
              have hs_eq : s = g.t_cur + 1 := by omega
              subst hs_eq
              dsimp only [job_hist']
              simp only [Function.update_self]
              refine ⟨lv_new, ?_, rfl, rfl, rfl⟩
              dsimp only [j_end, lvs', out, applyJobTickEndAction, lv_new, ball_new, α, curRes']
              rw [List.getElem?_append_right (by omega)]
              simp [hrdy_len],
            fun _ => ⟨by dsimp [ph_out, out, applyJobTickEndAction],
                      by dsimp [scan_out, out, applyJobTickEndAction],
                      by dsimp [Spar_out, out, applyJobTickEndAction]⟩⟩⟩

end UL.Proof_lem_7_2_RacerP46
