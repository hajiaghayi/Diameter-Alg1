import UL.Proof.lem_7_2.CG01_NodeSpec0c

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### Stage 2d: Full Active-Job End-of-Tick Action (`cg01EndActionJobStmt`) -/

def cg01EndActionJobStmt (d n M_box : ℕ) (cfg : ChainHdrCfg) (p : P46Params d n) : ArithRAMStmt :=
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let jLenE : IntExpr := .readHeap 19 rE
  let lastIdxE : IntExpr := .add (.mul rE (.lit (p.D₀ : ℤ))) (.sub jLenE (.lit 1))
  let phE : IntExpr := .readHeap 24 (.mul (.lit 2) lastIdxE)
  let dummyHpj : ArithRAMStmt := seqList [
    boxWriteW M_box 26 (.lit 0) (.lit 0),
    runHPJOnSlotStmt d n M_box p
  ]
  seqList [
    cfg.jobRem.writeW M_box rE (.sub (cfg.jobRem.readE rE) (.lit 1)),
    .ite (.and (.intEq (cfg.jobClosed.readE rE) (.lit 0)) (.intEq phE (.lit 2)))
      (seqList [
        readSlotCardTo24Stmt p.K_seg M_box (.readHeap 23 (.add (.mul (.lit 8) lastIdxE) (.lit 5))),
        .ite (.intLe (.mul (.lit (((16384 * (d + 3) ^ 2 : ℕ) : ℤ))) (cfg.jobRem.readE rE))
                     (.readHeap 26 (.lit 24)))
          (.ite (.intLe (.readHeap 26 (.lit 24)) (.lit (((2 * p.L + 1 : ℕ) : ℤ))))
            (seqList [
              cfg.jobClosed.writeW M_box rE (.lit 1),
              dummyHpj
            ])
            (cg01OpenNewLevelAtRStmt d n M_box cfg p))
          dummyHpj
      ])
      dummyHpj
  ]

theorem boxSafe_cg01EndActionJobStmt {d n T_max M_box : ℕ} {cfg : ChainHdrCfg}
    (hV : cfg.Valid T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (cg01EndActionJobStmt d n M_box cfg p) := by
  have hT28 := hV.1
  have hDum : BoxSafeOuter T_max M_box
      (seqList [boxWriteW M_box 26 (.lit 0) (.lit 0), runHPJOnSlotStmt d n M_box p]) :=
    .seq (.boxW (by omega) _ _) (boxSafe_runHPJOnSlotStmt hT28 p)
  unfold cg01EndActionJobStmt
  refine .seq (boxSafe_hdrWriteW hV.2.2.2.2.1.1 _ _) (.ite _ ?_ hDum)
  refine .seq (boxSafe_readSlotCardTo24Stmt (by omega) _ _) (.ite _ ?_ hDum)
  exact .ite _ (.seq (boxSafe_hdrWriteW hV.2.2.2.2.2.1.1 _ _) hDum)
    (boxSafe_cg01OpenNewLevelAtRStmt hT28 p)

noncomputable def cg01EndActionJobCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  cg01OpenNewLevelCost d n p + 400

theorem exec_cg01EndActionJobStmt
    (h_lem_5_1 : S_lem_5_1)
    (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k)
    {g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩)}
    {m₁ : ArithRAMMemory}
    (hw15 : wRead m₁ 26 15 = (i : ℤ))
    (pb : ActivePropBuildState ctx gFlag i hi g₀ m₁)
    (haff : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = true)
    (hsome : ctx.st₀.ownedJob ⟨i, hi⟩ = some g₀) :
    RandExecBad inp (cg01EndActionJobStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p) ctx.p.B_hpj m₁
      (fun m' =>
        wRead m' 0 0 = wRead m₁ 0 0 ∧
        wRead m' 26 13 = wRead m₁ 26 13 ∧
        wRead m' 26 14 = wRead m₁ 26 14 ∧
        wRead m' 26 15 = (i : ℤ) ∧
        wRead m' 26 28 = wRead m₁ 26 28 ∧
        ∃ g', PostEndActionJobState ctx false i hi m' g')
      (fun m' =>
        gFlag = true → ∃ g', PostEndActionJobState ctx true i hi m' g')
      (2 * ctx.p.φ_ev)
      (cg01EndActionJobCost ctx.d ctx.n ctx.p) := by
  classical
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  let jLen := g₀.lvs.length
  let lastIdx := i * ctx.p.D₀ + (jLen - 1)
  let rem' := g₀.H_job - (g₀.t_cur + 1)
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let jLenE : IntExpr := .readHeap 19 rE
  let lastIdxE : IntExpr := .add (.mul rE (.lit (ctx.p.D₀ : ℤ))) (.sub jLenE (.lit 1))
  let phE : IntExpr := .readHeap 24 (.mul (.lit 2) lastIdxE)
  let dummyHpj : ArithRAMStmt := seqList [
    boxWriteW ctx.M_box 26 (.lit 0) (.lit 0),
    runHPJOnSlotStmt ctx.d ctx.n ctx.M_box ctx.p
  ]
  have hD : 3 ≤ ctx.d + 3 := by omega
  have hjLen_pos : 1 ≤ jLen := g₀.hlvs_pos
  rcases ctx.hwf₀.1 r_fin with ⟨_, _, _, _, _, hjob0⟩
  rw [hsome] at hjob0
  have ht_lt : g₀.t_cur < g₀.H_job := hjob0.1
  rcases pb.hJob_i with ⟨lvs_h, hlen_eq, ph', scan', hph'_le, hw24_0, hw24_1, hlv_all, hpar_1, hbuild_1⟩
  let curRes_h := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) lvs_h.length
  let curRes_u := prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u r_fin)
  have hcard_cur : curRes_h.card = curRes_u.card :=
    (cg01_curRes_bij ctx hi lvs_h g₀.lvs hlen_eq (fun j hj => (hlv_all j hj).1)).2.2.2
  -- Header WF & Disjointness from ctx.hV
  have hWF_bc := ctx.hV.2.1
  have hWF_age := ctx.hV.2.2.1
  have hWF_aff := ctx.hV.2.2.2.1
  have hWF_rem := ctx.hV.2.2.2.2.1
  have hWF_cl := ctx.hV.2.2.2.2.2.1
  have hRes_rem := ctx.hV.2.2.2.2.2.2.2.2.2.1
  have hRes_cl := ctx.hV.2.2.2.2.2.2.2.2.2.2.1
  have hd_bc_rem := ctx.hV.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hd_bc_cl := ctx.hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hd_age_rem := ctx.hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hd_age_cl := ctx.hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hd_aff_rem := ctx.hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hd_aff_cl := ctx.hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hd_rem_cl := ctx.hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
  have hi_D0 : i < ctx.p.D₀ := lt_trans hi ctx.origK_lt_D0
  -- Step 1: Decrement cfg.jobRem at rE
  let m_rem := wWrite m₁ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) (rem' : ℤ)
  have hpop_rem : m_rem.popDepth 0 = m_rem := wWrite_popDepth_zero pb.hpop _ _ _
  have hd_rem : DetExecAt 0 inp
      (ctx.cfg.jobRem.writeW ctx.M_box rE (.sub (ctx.cfg.jobRem.readE rE) (.lit 1))) m₁ m_rem 45 := by
    refine exec_hdrWriteW inp m₁ ctx.cfg.jobRem rE (.sub (ctx.cfg.jobRem.readE rE) (.lit 1)) (by simp [rE, hw15]) (ctx.cfg.idx_lt_box ctx.hV ctx.hBox_hdr hi_D0).2.2.2.1 ?_ (by simp [HdrField.readE, HdrField.idxE, rE, intExprOps])
    simp only [HdrField.readE, HdrField.idxE, rE, iValAt_add, iValAt_sub, iValAt_mul, iValAt_readHeap, iValAt_lit, hw15]
    have hidx_eq : ((ctx.cfg.jobRem.stride : ℤ) * (i : ℤ) + (ctx.cfg.jobRem.off : ℤ)) =
        (ctx.cfg.jobRem.idx i : ℤ) := by unfold HdrField.idx; push_cast; ring
    rw [hidx_eq, pb.hwRem_i]
    dsimp only [rem']; omega
  have hw_rem_not : ∀ t, t ≠ ctx.cfg.jobRem.tag → ∀ k, wRead m_rem t k = wRead m₁ t k :=
    fun t ht _ => wRead_wWrite_of_ne _ _ (Or.inl ht)
  have hw_rem_res : ∀ t ∈ reservedWordTags, ∀ k, wRead m_rem t k = wRead m₁ t k :=
    fun t ht k => hw_rem_not t (Ne.symm (tag_ne_of_not_reserved hRes_rem ht)) k
  have hwRem_i_rem : wRead m_rem ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) = (rem' : ℤ) :=
    wRead_wWrite_self _ _ _ _
  have hwRem_ne_rem : ∀ r ≠ i, wRead m_rem ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) =
      wRead m₁ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) :=
    fun r hne => wRead_wWrite_of_ne _ _ (Or.inr (HdrField.ne_same_field hWF_rem hne))
  have hwCl_rem : ∀ r, wRead m_rem ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ) =
      wRead m₁ ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ) :=
    fun r => wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_cl hWF_rem hd_rem_cl.symm r i)
  have hwBc_rem : ∀ r, wRead m_rem ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ) =
      wRead m₁ ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ) :=
    fun r => wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_bc hWF_rem hd_bc_rem r i)
  have hwAge_rem : ∀ r, wRead m_rem ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ) =
      wRead m₁ ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ) :=
    fun r => wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_age hWF_rem hd_age_rem r i)
  have hwAff_rem : ∀ r, wRead m_rem ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ) =
      wRead m₁ ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ) :=
    fun r => wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_aff hWF_rem hd_aff_rem r i)
  have hw15_rem : wRead m_rem 26 15 = (i : ℤ) := (hw_rem_res 26 (by decide) 15).trans hw15
  have hlastIdx_eval_rem : iValAt 0 inp m_rem lastIdxE = (lastIdx : ℤ) := by
    have hw19_rem := (hw_rem_res 19 (by decide) (i : ℤ)).trans pb.hw19_i
    simp only [lastIdxE, jLenE, rE, iValAt_add, iValAt_sub, iValAt_mul, iValAt_readHeap, iValAt_lit, hw15_rem, hw19_rem]
    dsimp only [lastIdx, jLen]; omega
  -- Step 2: Check cReady := (jobClosed == 0) && (ph == 2)
  let cReady : ArithCondExpr := .and (.intEq (ctx.cfg.jobClosed.readE rE) (.lit 0)) (.intEq phE (.lit 2))
  have hcReady_ops : condExprOps cReady ≤ 45 := by
    simp [cReady, phE, lastIdxE, jLenE, rE, HdrField.readE, HdrField.idxE, condExprOps, intExprOps]
  have hCl_eval_rem : iValAt 0 inp m_rem (ctx.cfg.jobClosed.readE rE) = (if g₀.closed then 1 else 0) := by
    simp only [HdrField.readE, HdrField.idxE, rE, iValAt_add, iValAt_sub, iValAt_mul, iValAt_readHeap, iValAt_lit, hw15_rem]
    have hidx_eq : ((ctx.cfg.jobClosed.stride : ℤ) * (i : ℤ) + (ctx.cfg.jobClosed.off : ℤ)) =
        (ctx.cfg.jobClosed.idx i : ℤ) := by unfold HdrField.idx; push_cast; ring
    rw [hidx_eq, hwCl_rem i, pb.hwCl_i]
  have hph_eval_rem : iValAt 0 inp m_rem phE = (ph' : ℤ) := by
    change wRead m_rem 24 (2 * iValAt 0 inp m_rem lastIdxE) = (ph' : ℤ)
    rw [hlastIdx_eval_rem, hw_rem_res 24 (by decide)]
    have heq_idx : (2 * (lastIdx : ℤ)) = (((2 * lastIdx + 0 : ℕ) : ℤ)) := by push_cast; ring
    rw [heq_idx]; exact hw24_0
  have hOpenSub : RandExecBad inp
      (.ite cReady
        (seqList [
          readSlotCardTo24Stmt ctx.p.K_seg ctx.M_box (.readHeap 23 (.add (.mul (.lit 8) lastIdxE) (.lit 5))),
          .ite (.intLe (.mul (.lit (((16384 * (ctx.d + 3) ^ 2 : ℕ) : ℤ))) (ctx.cfg.jobRem.readE rE))
                       (.readHeap 26 (.lit 24)))
            (.ite (.intLe (.readHeap 26 (.lit 24)) (.lit (((2 * ctx.p.L + 1 : ℕ) : ℤ))))
              (seqList [ctx.cfg.jobClosed.writeW ctx.M_box rE (.lit 1), dummyHpj])
              (cg01OpenNewLevelAtRStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p))
            dummyHpj
        ])
        dummyHpj)
      ctx.p.B_hpj m_rem
      (fun m' =>
        wRead m' 0 0 = wRead m₁ 0 0 ∧
        wRead m' 26 13 = wRead m₁ 26 13 ∧
        wRead m' 26 14 = wRead m₁ 26 14 ∧
        wRead m' 26 15 = (i : ℤ) ∧
        wRead m' 26 28 = wRead m₁ 26 28 ∧
        ∃ g', PostEndActionJobState ctx false i hi m' g')
      (fun m' =>
        gFlag = true → ∃ g', PostEndActionJobState ctx true i hi m' g')
      (2 * ctx.p.φ_ev)
      (cg01OpenNewLevelCost ctx.d ctx.n ctx.p + 340) := by
    by_cases hready : g₀.closed = false ∧ ph' = 2
    · -- Ready branch (g₀.closed = false ∧ ph' = 2)
      rcases hready with ⟨hcl_f, hph2⟩
      have hcReady_true : cValAt 0 inp m_rem cReady = true := by
        simp only [cReady, cValAt, evalArithCond]
        change (decide (iValAt 0 inp m_rem (ctx.cfg.jobClosed.readE rE) = 0) &&
                decide (iValAt 0 inp m_rem phE = 2)) = true
        rw [hCl_eval_rem, hph_eval_rem, hcl_f, hph2]; rfl
      -- Read residual cardinality into 26[24]
      have hlast_lh : jLen - 1 < lvs_h.length := by rw [hlen_eq]; omega
      have hd_last_t : decide ((jLen - 1) + 1 = lvs_h.length) = true := by
        rw [hlen_eq]; simp only [decide_eq_true_eq]; dsimp only [jLen]; omega
      have hEnc_last_m1 := (hlv_all (jLen - 1) hlast_lh).2.2.2.1
      rw [hd_last_t] at hEnc_last_m1
      have hw24_last_m1 : wRead m₁ 24 (((2 * lastIdx + 0 : ℕ) : ℤ)) = 2 := by rw [hw24_0, hph2]; rfl
      rcases encJobLevel_phase2_resSlots hEnc_last_m1 hw24_last_m1
        with ⟨rS_last, _, _, _, _, hw_rS_last, _, _, _, hSeg_rS_m1, _⟩
      have hSeg_rS_cur : EncSegSlot ctx.p.K_seg m_rem rS_last curRes_h (fun _ => 0) := by
        have hres_eq : ((lvs_h[jLen - 1]'hlast_lh).ball (ctx.d + 3)).residual ctx.P'.handleCoords
            (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) (jLen - 1)) = curRes_h := by
          have hs := (jobHandleInput_succ (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) hlast_lh).symm
          have heq_len : (jLen - 1) + 1 = lvs_h.length := by rw [hlen_eq]; dsimp only [jLen]; omega
          rwa [heq_len] at hs
        rw [hres_eq] at hSeg_rS_m1
        exact hSeg_rS_m1.congr_mem_fSq
          (hw_rem_res 5 (by decide) _) (fun _ _ => hw_rem_res 8 (by decide) _)
          (fun _ _ => hw_rem_res 9 (by decide) _) (fun _ _ => hw_rem_res 10 (by decide) _)
          (fun _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ => rfl)
      let rSE : IntExpr := .readHeap 23 (.add (.mul (.lit 8) lastIdxE) (.lit 5))
      have hrSE_eval : iValAt 1 inp (m_rem.popDepth 0) rSE = (rS_last : ℤ) := by
        rw [hpop_rem]
        have hw15_1 : iValAt 1 inp m_rem lastIdxE = (lastIdx : ℤ) := by
          have hw19_rem := (hw_rem_res 19 (by decide) (i : ℤ)).trans pb.hw19_i
          simp only [lastIdxE, jLenE, rE, iValAt_add, iValAt_sub, iValAt_mul, iValAt_readHeap, iValAt_lit, hw15_rem, hw19_rem]
          dsimp only [lastIdx, jLen]; omega
        change wRead m_rem 23 (8 * iValAt 1 inp m_rem lastIdxE + 5) = (rS_last : ℤ)
        rw [hw15_1, hw_rem_res 23 (by decide)]
        have heq_idx : (8 * (lastIdx : ℤ) + 5) = (((8 * lastIdx + 5 : ℕ) : ℤ)) := by push_cast; ring
        rw [heq_idx, hw_rS_last]
      rcases exec_readSlotCardTo24Stmt inp m_rem rSE (Nat.le_trans (by decide : 25 ≤ 30) ctx.hBox30) hrSE_eval hSeg_rS_cur
        with ⟨m_c, hd_card, hpop_c, hw24_c, hw_c_not26, hw26_c, hr_c⟩
      have hd_card' : DetExecAt 0 inp (readSlotCardTo24Stmt ctx.p.K_seg ctx.M_box rSE) m_rem m_c 110 :=
        hd_card.mono_cost (by simp [rSE, lastIdxE, jLenE, rE, intExprOps])
      have hw15_c : wRead m_c 26 15 = (i : ℤ) := (hw26_c 15 (by decide)).trans hw15_rem
      have hw27_c : wRead m_c 26 27 = 0 :=
        (hw26_c 27 (by decide)).trans ((hw_rem_res 26 (by decide) 27).trans pb.hw27)
      have hwRem_ic : wRead m_c ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) = (rem' : ℤ) :=
        (hw_c_not26 _ (tag_ne_of_not_reserved hRes_rem (by decide)) _).trans hwRem_i_rem
      have hwRem_nec : ∀ r ≠ i, wRead m_c ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) =
          wRead m₁ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) :=
        fun r hne => (hw_c_not26 _ (tag_ne_of_not_reserved hRes_rem (by decide)) _).trans (hwRem_ne_rem r hne)
      have hw_mc_not : ∀ t, t ≠ 26 → t ≠ ctx.cfg.jobRem.tag → ∀ k, wRead m_c t k = wRead m₁ t k :=
        fun t h26 hrem k => (hw_c_not26 t h26 k).trans (hw_rem_not t hrem k)
      have hr_mc : ∀ t k, rRead m_c t k = rRead m₁ t k :=
        fun t k => (hr_c t k).trans (rRead_wWrite _ _ _ _ _ _)
      -- Check cGate
      let cGate : ArithCondExpr :=
        .intLe (.mul (.lit (((16384 * (ctx.d + 3) ^ 2 : ℕ) : ℤ))) (ctx.cfg.jobRem.readE rE))
               (.readHeap 26 (.lit 24))
      have hcGate_ops : condExprOps cGate ≤ 25 := by
        simp [cGate, HdrField.readE, HdrField.idxE, rE, condExprOps, intExprOps]
      have hRem_eval_c : iValAt 0 inp m_c (ctx.cfg.jobRem.readE rE) = (rem' : ℤ) := by
        simp only [HdrField.readE, HdrField.idxE, rE, iValAt_add, iValAt_sub, iValAt_mul, iValAt_readHeap, iValAt_lit, hw15_c]
        have hidx_eq : ((ctx.cfg.jobRem.stride : ℤ) * (i : ℤ) + (ctx.cfg.jobRem.off : ℤ)) =
            (ctx.cfg.jobRem.idx i : ℤ) := by unfold HdrField.idx; push_cast; ring
        rw [hidx_eq, hwRem_ic]
      have hGateBranch : RandExecBad inp
          (.ite cGate
            (.ite (.intLe (.readHeap 26 (.lit 24)) (.lit (((2 * ctx.p.L + 1 : ℕ) : ℤ))))
              (seqList [ctx.cfg.jobClosed.writeW ctx.M_box rE (.lit 1), dummyHpj])
              (cg01OpenNewLevelAtRStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p))
            dummyHpj)
          ctx.p.B_hpj m_c
          (fun m' =>
            wRead m' 0 0 = wRead m₁ 0 0 ∧
            wRead m' 26 13 = wRead m₁ 26 13 ∧
            wRead m' 26 14 = wRead m₁ 26 14 ∧
            wRead m' 26 15 = (i : ℤ) ∧
            wRead m' 26 28 = wRead m₁ 26 28 ∧
            ∃ g', PostEndActionJobState ctx false i hi m' g')
          (fun m' =>
            gFlag = true → ∃ g', PostEndActionJobState ctx true i hi m' g')
          (2 * ctx.p.φ_ev)
          (cg01OpenNewLevelCost ctx.d ctx.n ctx.p + 170) := by
        by_cases hcan : CanOpenResidualLevel (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) rem' curRes_u.card
        · -- CanOpenResidualLevel holds!
          have hmul_le : (16384 * (ctx.d + 3) ^ 2) * rem' ≤ curRes_h.card := by
            rw [hcard_cur]; exact (cg18_canOpenResidualLevel_iff_mul_le hD).mp hcan
          have hcGate_true : cValAt 0 inp m_c cGate = true := by
            simp only [cGate, cValAt, evalArithCond]
            change decide (iValAt 0 inp m_c (.mul (.lit _) (ctx.cfg.jobRem.readE rE)) ≤ wRead m_c 26 24) = true
            simp only [iValAt_mul, iValAt_lit, hRem_eval_c, hw24_c, decide_eq_true_eq]
            exact_mod_cast hmul_le
          let cSmall : ArithCondExpr :=
            .intLe (.readHeap 26 (.lit 24)) (.lit (((2 * ctx.p.L + 1 : ℕ) : ℤ)))
          have hcSmall_ops : condExprOps cSmall ≤ 15 := by simp [cSmall, condExprOps, intExprOps]
          have hSmallBranch : RandExecBad inp
              (.ite cSmall
                (seqList [ctx.cfg.jobClosed.writeW ctx.M_box rE (.lit 1), dummyHpj])
                (cg01OpenNewLevelAtRStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p))
              ctx.p.B_hpj m_c
              (fun m' =>
                wRead m' 0 0 = wRead m₁ 0 0 ∧
                wRead m' 26 13 = wRead m₁ 26 13 ∧
                wRead m' 26 14 = wRead m₁ 26 14 ∧
                wRead m' 26 15 = (i : ℤ) ∧
                wRead m' 26 28 = wRead m₁ 26 28 ∧
                ∃ g', PostEndActionJobState ctx false i hi m' g')
              (fun m' =>
                gFlag = true → ∃ g', PostEndActionJobState ctx true i hi m' g')
              (2 * ctx.p.φ_ev)
              (cg01OpenNewLevelCost ctx.d ctx.n ctx.p + 130) := by
            by_cases hsmall : curRes_u.card ≤ 2 * ctx.p.L + 1
            · -- closeLeaf branch!
              have hcSmall_true : cValAt 0 inp m_c cSmall = true := by
                simp only [cSmall, cValAt, evalArithCond]
                change decide (iValAt 0 inp m_c (.readHeap 26 (.lit 24)) ≤ iValAt 0 inp m_c (.lit _)) = true
                simp only [iValAt_readHeap, iValAt_lit, hw24_c, hcard_cur, decide_eq_true_eq]
                exact_mod_cast hsmall
              let m_cl := wWrite m_c ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx i : ℤ) 1
              have hpop_cl : m_cl.popDepth 0 = m_cl := wWrite_popDepth_zero hpop_c _ _ _
              have hd_cl : DetExecAt 0 inp (ctx.cfg.jobClosed.writeW ctx.M_box rE (.lit 1)) m_c m_cl 35 :=
                exec_hdrWriteW inp m_c ctx.cfg.jobClosed rE (.lit 1) (by simp [rE, hw15_c]) (ctx.cfg.idx_lt_box ctx.hV ctx.hBox_hdr hi_D0).2.2.2.2.1 rfl
                  (by simp [rE, intExprOps])
              have hDum := exec_dummyHPJStmt (M_box := ctx.M_box) ctx.p inp m_cl hpop_cl (by have := ctx.hBox30; omega) (le_of_lt ctx.hφ0)
              have hClSeq := RandExecBad.seq_det_left hpop_c hpop_cl hd_cl hDum
              let act := JobTickEndAction.closeLeaf (ghostCoords' := ctx.uMap'.ghostCoords) hcl_f hph2 hcan hsmall
              have hnot_cl_rem : ∀ r, wRead m_cl ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) =
                  wRead m_c ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) :=
                fun r => wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_rem hWF_cl hd_rem_cl r i)
              have hnot_cl_bc : ∀ r, wRead m_cl ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ) =
                  wRead m_c ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ) :=
                fun r => wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_bc hWF_cl hd_bc_cl r i)
              have hnot_cl_age : ∀ r, wRead m_cl ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ) =
                  wRead m_c ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ) :=
                fun r => wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_age hWF_cl hd_age_cl r i)
              have hnot_cl_aff : ∀ r, wRead m_cl ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ) =
                  wRead m_c ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ) :=
                fun r => wRead_wWrite_of_ne _ _ (HdrField.ne_cell hWF_aff hWF_cl hd_aff_cl r i)
              have buildClose : ∀ b : Bool, (b = true → gFlag = true) →
                  ∃ g', PostEndActionJobState ctx b i hi (wWrite m_cl 26 0 0) g' := fun b hb =>
                cg01_postEndAction_of_waitOrClose h_lem_5_1 (hlen_eq := hlen_eq) hi pb haff hsome hph'_le hw24_0 hw24_1
                  hlv_all hpar_1 hbuild_1 act (Or.inr ⟨hcl_f, hph2, hcan, hsmall, rfl⟩) true rfl
                  (by dsimp only [m_cl]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                        wRead_wWrite_of_ne _ _ (Or.inl (Ne.symm (tag_ne_of_not_reserved hRes_cl (by decide)))), hw27_c])
                  (by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_rem (by decide))), hnot_cl_rem i, hwRem_ic])
                  (fun r hne => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_rem (by decide))), hnot_cl_rem r, hwRem_nec r hne])
                  (by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_cl (by decide)))]; exact wRead_wWrite_self _ _ _ _)
                  (fun r hne => by
                    rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_cl (by decide)))]
                    dsimp only [m_cl]
                    rw [wRead_wWrite_of_ne _ _ (Or.inr (HdrField.ne_same_field hWF_cl hne)),
                        hw_c_not26 _ (tag_ne_of_not_reserved hRes_cl (by decide)), hwCl_rem r])
                  (fun t h26 hrem hcl_t k => by
                    rw [wRead_wWrite_of_ne _ _ (Or.inl h26)]; dsimp only [m_cl]
                    rw [wRead_wWrite_of_ne _ _ (Or.inl hcl_t), hw_mc_not t h26 hrem k])
                  (fun r => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.1 (by decide))),
                                   hnot_cl_bc r, hw_c_not26 _ (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.1 (by decide)), hwBc_rem r])
                  (fun r => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.1 (by decide))),
                                   hnot_cl_age r, hw_c_not26 _ (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.1 (by decide)), hwAge_rem r])
                  (fun r => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.2.1 (by decide))),
                                   hnot_cl_aff r, hw_c_not26 _ (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.2.1 (by decide)), hwAff_rem r])
                  (fun t k => by rw [rRead_wWrite]; dsimp only [m_cl]; rw [rRead_wWrite, hr_mc])
                  hb
              refine (RandExecBad.ite_true (fB := cg01OpenNewLevelAtRStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p)
                  hcSmall_true hcSmall_ops hClSeq).mono ?_ ?_ le_rfl
                (by unfold cg01OpenNewLevelCost hpjFreezeRunInitCost; omega)
              · intro m' hm'; subst hm'
                have hw0_eq : wRead (wWrite m_cl 26 0 0) 0 0 = wRead m₁ 0 0 := by
                  rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]; dsimp only [m_cl]
                  rw [wRead_wWrite_of_ne _ _ (Or.inl (Ne.symm (tag_ne_of_not_reserved hRes_cl (by decide)))),
                      hw_mc_not 0 (by decide) (Ne.symm (tag_ne_of_not_reserved hRes_rem (by decide)))]
                have hw26_cl : ∀ idx, idx ≠ 0 → idx ≠ 24 → wRead (wWrite m_cl 26 0 0) 26 idx = wRead m₁ 26 idx := by
                  intro idx h0 h24; rw [wRead_wWrite_of_ne _ _ (Or.inr h0)]; dsimp only [m_cl]
                  rw [wRead_wWrite_of_ne _ _ (Or.inl (Ne.symm (tag_ne_of_not_reserved hRes_cl (by decide)))),
                      hw26_c idx h24, hw_rem_res 26 (by decide)]
                exact ⟨hw0_eq, hw26_cl 13 (by decide) (by decide), hw26_cl 14 (by decide) (by decide),
                  (hw26_cl 15 (by decide) (by decide)).trans hw15,
                  hw26_cl 28 (by decide) (by decide), buildClose false (fun h => by cases h)⟩
              · intro m' hm' _ hgF; subst hm'; exact buildClose true (fun _ => hgF)
            · -- openLevel branch (2 * L + 1 < curRes_u.card)!
              have hlarge : 2 * ctx.p.L + 1 < curRes_u.card := by omega
              have hcSmall_false : cValAt 0 inp m_c cSmall = false := by
                simp only [cSmall, cValAt, evalArithCond]
                change decide (iValAt 0 inp m_c (.readHeap 26 (.lit 24)) ≤ iValAt 0 inp m_c (.lit _)) = false
                simp only [iValAt_readHeap, iValAt_lit, hw24_c, hcard_cur, decide_eq_false_iff_not]
                exact_mod_cast hsmall
              have hOpen := exec_cg01OpenNewLevelAtRStmt h_lem_5_1 ctx inp hi hlen_eq pb haff hsome
                hph'_le hlv_all hpar_1 hbuild_1 hcl_f hph2 hw24_last_m1 hcan hlarge
                hpop_c hw15_c hw24_c hw27_c hwRem_ic hwRem_nec hw_mc_not
                (fun r => (hw_c_not26 _ (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.1 (by decide)) _).trans (hwBc_rem r))
                (fun r => (hw_c_not26 _ (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.1 (by decide)) _).trans (hwAge_rem r))
                (fun r => (hw_c_not26 _ (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.2.1 (by decide)) _).trans (hwAff_rem r))
                (fun r => (hw_c_not26 _ (tag_ne_of_not_reserved hRes_cl (by decide)) _).trans (hwCl_rem r))
                hr_mc
              refine (RandExecBad.ite_false (tB := seqList [ctx.cfg.jobClosed.writeW ctx.M_box rE (.lit 1), dummyHpj])
                  hcSmall_false hcSmall_ops hOpen).mono ?_ ?_ le_rfl (by omega)
              · rintro m' ⟨e0, e13, e14, e15, e28, hex⟩
                exact ⟨e0.trans (hw_mc_not 0 (by decide) (Ne.symm (tag_ne_of_not_reserved hRes_rem (by decide))) 0),
                  e13.trans ((hw26_c 13 (by decide)).trans (hw_rem_res 26 (by decide) 13)),
                  e14.trans ((hw26_c 14 (by decide)).trans (hw_rem_res 26 (by decide) 14)),
                  e15,
                  e28.trans ((hw26_c 28 (by decide)).trans (hw_rem_res 26 (by decide) 28)),
                  hex⟩
              · intro _ _ hg; exact hg
          exact (RandExecBad.ite_true (fB := dummyHpj) hcGate_true hcGate_ops hSmallBranch).mono
            (fun _ h => h) (fun _ _ h => h) le_rfl (by omega)
        · -- ¬ CanOpenResidualLevel: waitOrBuild!
          have hnot_mul : ¬ ((16384 * (ctx.d + 3) ^ 2) * rem' ≤ curRes_h.card) := by
            rw [hcard_cur]; exact fun h => hcan ((cg18_canOpenResidualLevel_iff_mul_le hD).mpr h)
          have hcGate_false : cValAt 0 inp m_c cGate = false := by
            simp only [cGate, cValAt, evalArithCond]
            change decide (iValAt 0 inp m_c (.mul (.lit _) (ctx.cfg.jobRem.readE rE)) ≤ wRead m_c 26 24) = false
            simp only [iValAt_mul, iValAt_lit, hRem_eval_c, hw24_c, decide_eq_false_iff_not]
            exact_mod_cast hnot_mul
          have hDum := exec_dummyHPJStmt (M_box := ctx.M_box) ctx.p inp m_c hpop_c (by have := ctx.hBox30; omega) (le_of_lt ctx.hφ0)
          let act : JobTickEndAction ctx.d (ctx.d + 3) ctx.p.L ctx.uMap'.ghostCoords rem' g₀.closed ph' curRes_u :=
            .waitOrBuild (Or.inr (Or.inr hcan))
          have buildWaitGate : ∀ b : Bool, (b = true → gFlag = true) →
              ∃ g', PostEndActionJobState ctx b i hi (wWrite m_c 26 0 0) g' := fun b hb =>
            cg01_postEndAction_of_waitOrClose h_lem_5_1 (hlen_eq := hlen_eq) hi pb haff hsome hph'_le hw24_0 hw24_1
              hlv_all hpar_1 hbuild_1 act (Or.inl ⟨_, rfl⟩) g₀.closed rfl
              (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw27_c])
              (by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_rem (by decide))), hwRem_ic])
              (fun r hne => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_rem (by decide))), hwRem_nec r hne])
              (by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_cl (by decide))),
                      hw_c_not26 _ (tag_ne_of_not_reserved hRes_cl (by decide)), hwCl_rem i, pb.hwCl_i])
              (fun r _ => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_cl (by decide))),
                                hw_c_not26 _ (tag_ne_of_not_reserved hRes_cl (by decide)), hwCl_rem r])
              (fun t h26 hrem _ k => by rw [wRead_wWrite_of_ne _ _ (Or.inl h26), hw_mc_not t h26 hrem k])
              (fun r => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.1 (by decide))),
                              hw_c_not26 _ (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.1 (by decide)), hwBc_rem r])
              (fun r => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.1 (by decide))),
                              hw_c_not26 _ (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.1 (by decide)), hwAge_rem r])
              (fun r => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.2.1 (by decide))),
                              hw_c_not26 _ (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.2.1 (by decide)), hwAff_rem r])
              (fun t k => by rw [rRead_wWrite, hr_mc])
              hb
          refine (RandExecBad.ite_false
            (tB := .ite (.intLe (.readHeap 26 (.lit 24)) (.lit (((2 * ctx.p.L + 1 : ℕ) : ℤ)))) (seqList [ctx.cfg.jobClosed.writeW ctx.M_box rE (.lit 1), dummyHpj])
              (cg01OpenNewLevelAtRStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p))
            hcGate_false hcGate_ops hDum).mono ?_ ?_ le_rfl
              (by unfold cg01OpenNewLevelCost hpjFreezeRunInitCost; omega)
          · intro m' hm'; subst hm'
            refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                          hw_mc_not 0 (by decide) (Ne.symm (tag_ne_of_not_reserved hRes_rem (by decide)))],
              by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw26_c 13 (by decide), hw_rem_res 26 (by decide)],
              by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw26_c 14 (by decide), hw_rem_res 26 (by decide)],
              by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw15_c],
              by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw26_c 28 (by decide), hw_rem_res 26 (by decide)],
              buildWaitGate false (fun h => by cases h)⟩
          · intro m' hm' _ hgF; subst hm'; exact buildWaitGate true (fun _ => hgF)
      have hCardThenGate := RandExecBad.seq_det_left hpop_rem hpop_c hd_card' hGateBranch
      exact (RandExecBad.ite_true (fB := dummyHpj) hcReady_true hcReady_ops hCardThenGate).mono
        (fun _ h => h) (fun _ _ h => h) le_rfl (by omega)
    · -- Not ready (g₀.closed = true ∨ ph' < 2): waitOrBuild!
      have hq : g₀.closed = true ∨ ph' < 2 ∨
          ¬ CanOpenResidualLevel (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)) rem' curRes_u.card := by
        cases hcl_b : g₀.closed
        · have hne2 : ph' ≠ 2 := fun h => hready ⟨hcl_b, h⟩
          right; left; omega
        · left; rfl
      have hcReady_false : cValAt 0 inp m_rem cReady = false := by
        simp only [cReady, cValAt, evalArithCond]
        change (decide (iValAt 0 inp m_rem (ctx.cfg.jobClosed.readE rE) = 0) &&
                decide (iValAt 0 inp m_rem phE = 2)) = false
        rw [hCl_eval_rem, hph_eval_rem]
        cases hcl_b : g₀.closed
        · have hne2 : (ph' : ℤ) ≠ 2 := fun h => hready ⟨hcl_b, by omega⟩
          simp [hne2]
        · simp
      have hDum := exec_dummyHPJStmt (M_box := ctx.M_box) ctx.p inp m_rem hpop_rem (by have := ctx.hBox30; omega) (le_of_lt ctx.hφ0)
      let act := JobTickEndAction.waitOrBuild (L := ctx.p.L) (ghostCoords' := ctx.uMap'.ghostCoords) hq
      have buildWait : ∀ b : Bool, (b = true → gFlag = true) →
          ∃ g', PostEndActionJobState ctx b i hi (wWrite m_rem 26 0 0) g' := fun b hb =>
        cg01_postEndAction_of_waitOrClose h_lem_5_1 (hlen_eq := hlen_eq) hi pb haff hsome hph'_le hw24_0 hw24_1
          hlv_all hpar_1 hbuild_1 act (Or.inl ⟨hq, rfl⟩) g₀.closed rfl
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw_rem_res 26 (by decide), pb.hw27])
          (by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_rem (by decide))), hwRem_i_rem])
          (fun r hne => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_rem (by decide))), hwRem_ne_rem r hne])
          (by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_cl (by decide))), hwCl_rem i, pb.hwCl_i])
          (fun r _ => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved hRes_cl (by decide))), hwCl_rem r])
          (fun t h26 hrem _ k => by rw [wRead_wWrite_of_ne _ _ (Or.inl h26), hw_rem_not t hrem k])
          (fun r => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.1 (by decide))), hwBc_rem r])
          (fun r => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.1 (by decide))), hwAge_rem r])
          (fun r => by rw [wRead_wWrite_of_ne _ _ (Or.inl (tag_ne_of_not_reserved ctx.hV.2.2.2.2.2.2.2.2.1 (by decide))), hwAff_rem r])
          (fun _ _ => by rw [rRead_wWrite, rRead_wWrite])
          hb
      refine (RandExecBad.ite_false
        (tB := seqList [
          readSlotCardTo24Stmt ctx.p.K_seg ctx.M_box (.readHeap 23 (.add (.mul (.lit 8) lastIdxE) (.lit 5))),
          .ite (.intLe (.mul (.lit (((16384 * (ctx.d + 3) ^ 2 : ℕ) : ℤ))) (ctx.cfg.jobRem.readE rE))
                       (.readHeap 26 (.lit 24)))
            (.ite (.intLe (.readHeap 26 (.lit 24)) (.lit (((2 * ctx.p.L + 1 : ℕ) : ℤ))))
              (seqList [ctx.cfg.jobClosed.writeW ctx.M_box rE (.lit 1), dummyHpj])
              (cg01OpenNewLevelAtRStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p))
            dummyHpj
        ])
        hcReady_false hcReady_ops hDum).mono ?_ ?_ le_rfl
          (by unfold cg01OpenNewLevelCost hpjFreezeRunInitCost; omega)
      · intro m' hm'; subst hm'
        refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hw_rem_res 0 (by decide)],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw_rem_res 26 (by decide)],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw_rem_res 26 (by decide)],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw15_rem],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hw_rem_res 26 (by decide)],
          buildWait false (fun h => by cases h)⟩
      · intro m' hm' _ hgF; subst hm'; exact buildWait true (fun _ => hgF)
  exact (RandExecBad.seq_det_left pb.hpop hpop_rem hd_rem hOpenSub).mono
    (fun _ h => h) (fun _ _ h => h) le_rfl (by unfold cg01EndActionJobCost; omega)

end UL.Proof_lem_7_2_RacerP46
