import Mathlib
import UL.Stmt.lem_7_2
import UL.Stmt.clm_7_3_failure_budget
import UL.Proof.lem_7_2.RacerP46_H3a_HPJAndBaseline
import UL.Proof.lem_7_2.RacerP46_H3b_BaselineAndLeaf
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Endpoint Polynomial (`IsBoundedByPoly2`) and Monomial Dominance Helpers -/

/-- `C * D^19 * H^18` satisfies `IsBoundedByPoly2` for every nonnegative constant `C ≥ 0`. -/
theorem isBoundedByPoly2_endpoint (C : ℝ) (hC : 0 ≤ C) :
    IsBoundedByPoly2 (fun D H => C * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18)) := by
  refine ⟨C, 19, hC, fun D H => ?_⟩
  have hDH_nat : D ^ 19 * H ^ 18 ≤ (D + 1) ^ 19 * (H + 1) ^ 19 :=
    Nat.mul_le_mul (Nat.pow_le_pow_left (Nat.le_succ D) 19)
      ((Nat.pow_le_pow_left (Nat.le_succ H) 18).trans
        (Nat.pow_le_pow_right (Nat.succ_pos H) (by decide : 18 ≤ 19)))
  have hDH : (D : ℝ) ^ 19 * (H : ℝ) ^ 18 ≤ ((D : ℝ) + 1) ^ 19 * ((H : ℝ) + 1) ^ 19 := by
    exact_mod_cast hDH_nat
  calc C * (D : ℝ) ^ 19 * (H : ℝ) ^ 18
      = C * ((D : ℝ) ^ 19 * (H : ℝ) ^ 18) := by ring
    _ ≤ C * (((D : ℝ) + 1) ^ 19 * ((H : ℝ) + 1) ^ 19) := mul_le_mul_of_nonneg_left hDH hC
    _ = C * ((D : ℝ) + 1) ^ 19 * ((H : ℝ) + 1) ^ 19 := by ring

lemma pow_mul_pow_le_target {D H a b : ℕ} (hD : 1 ≤ D) (hH : 1 ≤ H)
    (ha : a ≤ 19) (hb : b ≤ 18) :
    D ^ a * H ^ b ≤ D ^ 19 * H ^ 18 :=
  Nat.mul_le_mul (Nat.pow_le_pow_right hD ha) (Nat.pow_le_pow_right hH hb)

lemma coef_pow_mul_pow_le_target (c : ℕ) {D H a b : ℕ} (hD : 1 ≤ D) (hH : 1 ≤ H)
    (ha : a ≤ 19) (hb : b ≤ 18) :
    c * (D ^ a * H ^ b) ≤ c * (D ^ 19 * H ^ 18) :=
  Nat.mul_le_mul_left c (pow_mul_pow_le_target hD hH ha hb)

lemma one_le_target {D H : ℕ} (hD : 1 ≤ D) (hH : 1 ≤ H) :
    1 ≤ D ^ 19 * H ^ 18 := by
  simpa using pow_mul_pow_le_target hD hH (Nat.zero_le 19) (Nat.zero_le 18)

/-! ### 2. Abstract Single-Step Simulation Specification (`StepSimSpec`) -/

/-- Abstract single-step `fd = 0` ArithRAM simulation contract for horizon `t`. -/
structure StepSimSpec (d n t : ℕ) (δ : ℝ) where
  updateStmt0 : ArithRAMStmt
  B_step : ℕ
  uBound : ℕ
  T_max : ℕ
  M_box : ℕ
  φ_step : ℝ
  SafeInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop
  GoodInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop
  hBoxSafe : BoxSafeOuter T_max M_box updateStmt0
  hφ_le : φ_step ≤ perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ
  hSafe₀ : SafeInv 0 (DynamicPointSet.empty d) ArithRAMMemory.empty
  hGood₀ : GoodInv 0 (DynamicPointSet.empty d) ArithRAMMemory.empty
  hStep : ∀ (k : ℕ) (P : DynamicPointSet d) (mem₀ : ArithRAMMemory) (op : DynamicUpdate d),
    k < t →
    P.WellFormed n →
    mem₀.popDepth 0 = mem₀ →
    HeapOnlyInBox T_max M_box mem₀ →
    SafeInv k P mem₀ →
    IsLegalUpdate n Set.univ P op →
      ∃ (Post : (Fin B_step → Bool) → ArithRAMMemory → Prop)
        (Bad : (Fin B_step → Bool) → Prop) (_ : DecidablePred Bad),
        RandExecAt 0 (mkStepInput n P op) updateStmt0 B_step mem₀ Post uBound ∧
        ((Finset.univ.filter Bad).card : ℝ) ≤ φ_step * ((2 : ℝ) ^ B_step) ∧
        (∀ (bits : Fin B_step → Bool) (m₁ : ArithRAMMemory),
          Post bits m₁ →
            let m_out := m₁.popDepth 0
            ∃ P' : DynamicPointSet d,
              applyDynamicUpdate P op (readStepRetH op m_out) = some P' ∧
              SafeInv (k + 1) P' m_out ∧
              (GoodInv k P mem₀ → ¬ Bad bits →
                IsValidFactorCAnswer (Real.sqrt 2) P' (readStoredAns m_out) ∧
                GoodInv (k + 1) P' m_out))

/-- Converts a `StepSimSpec d n t δ` whose work `uBound` and box size `T_max * M_box` obey
polynomial `D^19 * H^18` bounds into the exact existential witness of `S_lem_7_2`. -/
theorem StepSimSpec.to_endpoint_instance
    (h_fb : S_clm_7_3_failure_budget)
    {d n t : ℕ} (hn : 2 ≤ n) (ht : 1 ≤ t)
    {δ : ℝ} (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (spec : StepSimSpec d n t δ)
    {C_u C_box : ℕ} (hCu1 : 1 ≤ C_u)
    {C_time C_space : ℝ}
    (hCt : (C_u : ℝ) ≤ C_time)
    (hCs : ((4 + 2 * C_box + C_u : ℕ) : ℝ) ≤ C_space)
    (hu_poly :
      let D : ℕ := d + 3
      let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
      spec.uBound ≤ C_u * (D ^ 19 * H ^ 18))
    (hbox_poly :
      let D : ℕ := d + 3
      let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
      spec.T_max * spec.M_box ≤ C_box * n * (D ^ 19 * H ^ 18)) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    ∃ (prog : ArithRAMDynamicProgram) (initOut : ArithRAMExecOutcome),
      prog.evalInit n d = some initOut ∧
      let alg := mkArithAlg d n prog initOut
      SatisfiesDynamicStorageAndQueryModel 4 1 alg ∧
      SatisfiesMonteCarloGuarantee n t δ (Real.sqrt 2) Set.univ alg ∧
      SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg
        (C_time * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18)) ∧
      SatisfiesBoundedSpaceBound n t Set.univ alg
        (C_space * (n : ℝ) * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18)) := by
  intro D H
  have hsb := scale_basic_bounds (d := d) hn ht hδ0 hδ1
  obtain ⟨hD3, hH5, _, _, _, _, _⟩ := hsb
  have hD1 : 1 ≤ D := le_trans (by decide : 1 ≤ 3) hD3
  have hH1 : 1 ≤ H := le_trans (by decide : 1 ≤ 5) hH5
  let P19 : ℕ := D ^ 19 * H ^ 18
  have hP1 : 1 ≤ P19 := one_le_target hD1 hH1
  have hD_le_P : D ≤ P19 := by
    simpa using pow_mul_pow_le_target hD1 hH1 (by decide : 1 ≤ 19) (Nat.zero_le 18)
  have hu_poly' : spec.uBound ≤ C_u * P19 := hu_poly
  have hbox_poly' : spec.T_max * spec.M_box ≤ C_box * n * P19 := hbox_poly
  have hu_le : (max 1 spec.uBound : ℝ) ≤ C_time * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18) := by
    have hnat1 : 1 ≤ C_u * P19 := Nat.mul_le_mul hCu1 hP1
    have hcast : (max (1 : ℝ) (spec.uBound : ℝ)) ≤ ((C_u * P19 : ℕ) : ℝ) :=
      max_le (by exact_mod_cast hnat1) (by exact_mod_cast hu_poly')
    have hrhs : ((C_u * P19 : ℕ) : ℝ) ≤ C_time * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18) := by
      have hcast_eq :
          ((C_u * P19 : ℕ) : ℝ) = (C_u : ℝ) * (((D : ℝ) ^ 19) * ((H : ℝ) ^ 18)) := by
        dsimp [P19]; push_cast; ring
      rw [hcast_eq, mul_assoc]
      exact mul_le_mul_of_nonneg_right hCt (by positivity)
    exact hcast.trans hrhs
  have hs_le :
      ((max 1 (3 + n * (d + 1) + d + 2 * (spec.T_max * spec.M_box) + spec.uBound) : ℕ) : ℝ) ≤
        C_space * (n : ℝ) * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18) := by
    have hn1 : 1 ≤ n := by omega
    have h_3 : 3 ≤ 2 * (n * P19) := by
      have : 2 ≤ n * P19 := by
        calc 2 = 2 * 1 := by omega
          _ ≤ n * P19 := Nat.mul_le_mul hn hP1
      omega
    have hd1_D : d + 1 ≤ D := by dsimp [D]; omega
    have hd_D : d ≤ D := by dsimp [D]; omega
    have h_nd1 : n * (d + 1) ≤ n * P19 :=
      Nat.mul_le_mul_left n (hd1_D.trans hD_le_P)
    have h_d : d ≤ n * P19 := by
      calc d ≤ D := hd_D
        _ ≤ P19 := hD_le_P
        _ = 1 * P19 := by omega
        _ ≤ n * P19 := Nat.mul_le_mul_right P19 hn1
    have h_inp : 3 + n * (d + 1) + d ≤ 4 * (n * P19) := by omega
    have h_box2 : 2 * (spec.T_max * spec.M_box) ≤ (2 * C_box) * (n * P19) := by
      have hb : spec.T_max * spec.M_box ≤ C_box * (n * P19) := by
        rw [← Nat.mul_assoc]; exact hbox_poly'
      calc 2 * (spec.T_max * spec.M_box)
          ≤ 2 * (C_box * (n * P19)) := Nat.mul_le_mul_left 2 hb
        _ = (2 * C_box) * (n * P19) := by ring
    have h_u : spec.uBound ≤ C_u * (n * P19) := by
      calc spec.uBound ≤ C_u * P19 := hu_poly'
        _ = C_u * (1 * P19) := by ring
        _ ≤ C_u * (n * P19) := Nat.mul_le_mul_left C_u (Nat.mul_le_mul_right P19 hn1)
    have h_sum :
        3 + n * (d + 1) + d + 2 * (spec.T_max * spec.M_box) + spec.uBound ≤
          (4 + 2 * C_box + C_u) * (n * P19) := by
      calc 3 + n * (d + 1) + d + 2 * (spec.T_max * spec.M_box) + spec.uBound
          ≤ 4 * (n * P19) + (2 * C_box) * (n * P19) + C_u * (n * P19) := by omega
        _ = (4 + 2 * C_box + C_u) * (n * P19) := by ring
    have h_one : 1 ≤ (4 + 2 * C_box + C_u) * (n * P19) := by
      have hc : 1 ≤ 4 + 2 * C_box + C_u := by omega
      have hnp : 1 ≤ n * P19 := Nat.mul_le_mul hn1 hP1
      exact Nat.mul_le_mul hc hnp
    have h_max_nat :
        max 1 (3 + n * (d + 1) + d + 2 * (spec.T_max * spec.M_box) + spec.uBound) ≤
          (4 + 2 * C_box + C_u) * (n * P19) :=
      max_le h_one h_sum
    have hcast :
        ((max 1 (3 + n * (d + 1) + d + 2 * (spec.T_max * spec.M_box) + spec.uBound) : ℕ) : ℝ) ≤
          (((4 + 2 * C_box + C_u) * (n * P19) : ℕ) : ℝ) := by
      exact_mod_cast h_max_nat
    have hrhs :
        (((4 + 2 * C_box + C_u) * (n * P19) : ℕ) : ℝ) ≤
          C_space * (n : ℝ) * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18) := by
      let Ctot : ℕ := 4 + 2 * C_box + C_u
      have hcast_eq :
          ((Ctot * (n * P19) : ℕ) : ℝ) =
            (Ctot : ℝ) * ((n : ℝ) * ((D : ℝ) ^ 19) * ((H : ℝ) ^ 18)) := by
        rw [Nat.cast_mul]
        dsimp [P19]
        push_cast
        ring
      change ((Ctot * (n * P19) : ℕ) : ℝ) ≤ _
      rw [hcast_eq]
      calc (Ctot : ℝ) * ((n : ℝ) * (D : ℝ) ^ 19 * (H : ℝ) ^ 18)
          ≤ C_space * ((n : ℝ) * (D : ℝ) ^ 19 * (H : ℝ) ^ 18) :=
            mul_le_mul_of_nonneg_right hCs (by positivity)
        _ = C_space * (n : ℝ) * (D : ℝ) ^ 19 * (H : ℝ) ^ 18 := by ring
    exact hcast.trans hrhs
  refine ⟨{ initStmt := .skip, updateStmt := spec.updateStmt0 }, ?_⟩
  exact p46_horizon_bridge_outer h_fb hn ht hδ0 hδ1 spec.updateStmt0
    spec.hBoxSafe spec.SafeInv spec.GoodInv spec.hφ_le hu_le hs_le
    spec.hSafe₀ spec.hGood₀ spec.hStep

/-- Unconditional reduction of `S_lem_7_2` to a family of `StepSimSpec d n t δ` instances. -/
theorem prove_S_lem_7_2_of_all_stepSimSpec
    (h_fb : S_clm_7_3_failure_budget)
    (C_u C_box : ℕ)
    (hSpec : ∀ (d n t : ℕ), 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        ∃ spec : StepSimSpec d n t δ,
          spec.uBound ≤ (max 1 C_u) * (D ^ 19 * H ^ 18) ∧
          spec.T_max * spec.M_box ≤ C_box * n * (D ^ 19 * H ^ 18)) :
    S_lem_7_2 := by
  unfold S_lem_7_2
  let Cu := max 1 C_u
  have hCu1 : 1 ≤ Cu := le_max_left 1 C_u
  let C_time : ℝ := (Cu : ℝ)
  let C_space : ℝ := ((4 + 2 * C_box + Cu : ℕ) : ℝ)
  refine ⟨C_time, C_space, 4, 1, by positivity, by positivity, ?_⟩
  intro d n t hn ht δ hδ0 hδ1
  rcases hSpec d n t hn ht δ hδ0 hδ1 with ⟨spec, hu_poly, hbox_poly⟩
  exact spec.to_endpoint_instance h_fb hn ht hδ0 hδ1 hCu1 le_rfl le_rfl hu_poly hbox_poly

/-! ### 3. Concrete `P46Params` Box-Size & Cost-Bound Lemmas for Integration -/

/-- Canonical box width `M_box` dominating all heap-array indices in `RacerP46`. -/
def p46BoxSize (d n : ℕ) (p : P46Params d n) : ℕ :=
  64 + p.D₀ + (p.NumSlots + 1) * n * (d + 4) + (2 ^ p.P_hpj.q) * (d + 1)

theorem p46BoxSize_lower_bounds {d n M_box : ℕ} (p : P46Params d n)
    (hn : 2 ≤ n)
    (hSlots_eq : p.NumSlots = 8 * (p.D₀ + 2) ^ 2)
    (h2K_lt : 2 ^ p.K_seg < 2 * n)
    (hM : p46BoxSize d n p ≤ M_box) :
    4 ≤ M_box ∧
    7 ≤ M_box ∧
    13 ≤ M_box ∧
    26 ≤ M_box ∧
    30 ≤ M_box ∧
    p.D₀ ≤ M_box ∧
    2 ≤ p.NumSlots ∧
    d + 1 ≤ M_box ∧
    n ≤ M_box ∧
    n * d ≤ M_box ∧
    p.NumSlots ≤ M_box ∧
    p.NumSlots * n ≤ M_box ∧
    p.NumSlots * n * d ≤ M_box ∧
    (p.NumSlots + 1) * n * (d + 1) ≤ M_box ∧
    p.NumSlots * 2 ^ (p.K_seg + 1) ≤ M_box ∧
    (2 ^ p.P_hpj.q) * d ≤ M_box ∧
    (∀ idx ≤ p.D₀ * p.D₀, 8 * idx + 8 ≤ M_box ∧ idx * d + d ≤ M_box) := by
  have h4_sq : 4 ≤ (p.D₀ + 2) ^ 2 := by
    simpa using Nat.pow_le_pow_left (Nat.le_add_left 2 p.D₀) 2
  have hSlots_ge32 : 32 ≤ p.NumSlots := by
    rw [hSlots_eq]; omega
  have hSlots_pos : 1 ≤ p.NumSlots := by omega
  have hpow_pos : 1 ≤ 2 ^ p.P_hpj.q := Nat.one_le_pow _ 2 (by decide)
  have hbase_sn1 : (p.NumSlots + 1) * n * (d + 4) ≤ M_box := by
    unfold p46BoxSize at hM; omega
  have hbase_sn : p.NumSlots * n * (d + 4) ≤ M_box := by
    have : p.NumSlots * n * (d + 4) ≤ (p.NumSlots + 1) * n * (d + 4) :=
      Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ (Nat.le_succ _))
    exact this.trans hbase_sn1
  have hSn1d1 : (p.NumSlots + 1) * n * (d + 1) ≤ M_box := by
    have : (p.NumSlots + 1) * n * (d + 1) ≤ (p.NumSlots + 1) * n * (d + 4) :=
      Nat.mul_le_mul_left _ (by omega)
    exact this.trans hbase_sn1
  have hbase_hpj : (2 ^ p.P_hpj.q) * (d + 1) ≤ M_box := by
    unfold p46BoxSize at hM; omega
  have hd1 : d + 1 ≤ M_box := by
    calc d + 1 = 1 * (d + 1) := by omega
      _ ≤ (2 ^ p.P_hpj.q) * (d + 1) := Nat.mul_le_mul_right _ hpow_pos
      _ ≤ M_box := hbase_hpj
  have hn_le : n ≤ M_box := by
    have : n ≤ p.NumSlots * n * (d + 4) := by
      calc n = 1 * n * 1 := by omega
        _ ≤ p.NumSlots * n * (d + 4) :=
            Nat.mul_le_mul (Nat.mul_le_mul_right n hSlots_pos) (by omega)
    omega
  have hnd_le : n * d ≤ M_box := by
    have : n * d ≤ p.NumSlots * n * (d + 4) := by
      calc n * d = 1 * n * d := by ring
        _ ≤ p.NumSlots * n * (d + 4) :=
            Nat.mul_le_mul (Nat.mul_le_mul_right n hSlots_pos) (by omega)
    omega
  have hSn : p.NumSlots * n ≤ M_box := by
    have : p.NumSlots * n ≤ p.NumSlots * n * (d + 4) := by
      calc p.NumSlots * n = p.NumSlots * n * 1 := by omega
        _ ≤ p.NumSlots * n * (d + 4) := Nat.mul_le_mul_left _ (by omega)
    omega
  have hS_le : p.NumSlots ≤ M_box := by
    have : p.NumSlots ≤ p.NumSlots * n := by
      calc p.NumSlots = p.NumSlots * 1 := by omega
        _ ≤ p.NumSlots * n := Nat.mul_le_mul_left _ (by omega)
    omega
  have hSnd : p.NumSlots * n * d ≤ M_box := by
    have : p.NumSlots * n * d ≤ p.NumSlots * n * (d + 4) :=
      Nat.mul_le_mul_left _ (by omega)
    omega
  have hS2K : p.NumSlots * 2 ^ (p.K_seg + 1) ≤ M_box := by
    have h2K1 : 2 ^ (p.K_seg + 1) ≤ n * (d + 4) := by
      have h4n : 2 ^ (p.K_seg + 1) ≤ 4 * n := by
        rw [pow_succ]
        omega
      have h4d : 4 * n ≤ n * (d + 4) := by
        calc 4 * n = n * 4 := by ring
          _ ≤ n * (d + 4) := Nat.mul_le_mul_left n (by omega)
      exact h4n.trans h4d
    calc p.NumSlots * 2 ^ (p.K_seg + 1)
        ≤ p.NumSlots * (n * (d + 4)) := Nat.mul_le_mul_left _ h2K1
      _ = p.NumSlots * n * (d + 4) := by ring
      _ ≤ M_box := hbase_sn
  have hhpj_d : (2 ^ p.P_hpj.q) * d ≤ M_box := by
    calc (2 ^ p.P_hpj.q) * d
        ≤ (2 ^ p.P_hpj.q) * (d + 1) := Nat.mul_le_mul_left _ (by omega)
      _ ≤ M_box := hbase_hpj
  refine ⟨by unfold p46BoxSize at hM; omega,
          by unfold p46BoxSize at hM; omega,
          by unfold p46BoxSize at hM; omega,
          by unfold p46BoxSize at hM; omega,
          by unfold p46BoxSize at hM; omega,
          by unfold p46BoxSize at hM; omega,
          by omega, hd1, hn_le, hnd_le, hS_le, hSn, hSnd, hSn1d1, hS2K, hhpj_d, ?_⟩
  intro idx hidx
  have hsq_ge : p.D₀ * p.D₀ + 4 ≤ (p.D₀ + 2) ^ 2 := by
    have heq : (p.D₀ + 2) ^ 2 = p.D₀ * p.D₀ + 4 * p.D₀ + 4 := by ring
    rw [heq]; omega
  have h8 : 8 * idx + 8 ≤ p.NumSlots := by
    rw [hSlots_eq]; omega
  have hidx1 : idx + 1 ≤ p.NumSlots := by
    rw [hSlots_eq]; omega
  have hidxd : idx * d + d ≤ p.NumSlots * d := by
    calc idx * d + d = (idx + 1) * d := by ring
      _ ≤ p.NumSlots * d := Nat.mul_le_mul_right d hidx1
  refine ⟨h8.trans hS_le, ?_⟩
  calc idx * d + d
      ≤ p.NumSlots * d := hidxd
    _ = p.NumSlots * 1 * d := by ring
    _ ≤ p.NumSlots * n * d :=
        Nat.mul_le_mul_right d (Nat.mul_le_mul_left _ (by omega))
    _ ≤ M_box := hSnd

/-- Polynomial upper bound `p46BoxSize d n p ≤ (10090 + cHpj * 21^3) * n * (D^19 * H^18)`. -/
theorem p46BoxSize_poly_le {d n D H cHpj : ℕ} (p : P46Params d n)
    (hn : 2 ≤ n)
    (hD_eq : D = d + 3)
    (hD3 : 3 ≤ D) (hH5 : 5 ≤ H)
    (hD0 : p.D₀ = 24 * D ^ 2 * H)
    (hSlots : p.NumSlots = 8 * (p.D₀ + 2) ^ 2)
    (hHpjProps : HPJParamProps d p.φ_ev p.P_hpj)
    (hmD : p.P_hpj.m * D ≤ (cHpj * 21 ^ 3) * D ^ 7 * H ^ 6) :
    p46BoxSize d n p ≤ (10090 + cHpj * 21 ^ 3) * n * (D ^ 19 * H ^ 18) := by
  have hD1 : 1 ≤ D := by omega
  have hH1 : 1 ≤ H := by omega
  have hn1 : 1 ≤ n := by omega
  let P19 : ℕ := D ^ 19 * H ^ 18
  have hP1 : 1 ≤ P19 := one_le_target hD1 hH1
  have hD4H2_1 : 1 ≤ D ^ 4 * H ^ 2 :=
    Nat.mul_le_mul (Nat.one_le_pow 4 D hD1) (Nat.one_le_pow 2 H hH1)
  have hD0_2 : p.D₀ + 2 ≤ 25 * (D ^ 2 * H) := by
    have hD2 : 9 ≤ D ^ 2 := by
      simpa using Nat.pow_le_pow_left hD3 2
    have h2 : 2 ≤ D ^ 2 * H := by
      have : 45 ≤ D ^ 2 * H := Nat.mul_le_mul hD2 hH5
      omega
    rw [hD0]
    have heq : 24 * D ^ 2 * H = 24 * (D ^ 2 * H) := by ring
    rw [heq]; omega
  have hterm_D0 : p.D₀ ≤ 24 * n * P19 := by
    rw [hD0]
    calc 24 * D ^ 2 * H = 24 * 1 * (D ^ 2 * H ^ 1) := by ring
      _ ≤ 24 * n * P19 :=
          Nat.mul_le_mul (Nat.mul_le_mul_left 24 hn1)
            (pow_mul_pow_le_target hD1 hH1 (by decide : 2 ≤ 19) (by decide : 1 ≤ 18))
  have hSlots1_le : p.NumSlots + 1 ≤ 5001 * (D ^ 4 * H ^ 2) := by
    have hSlots_le : p.NumSlots ≤ 5000 * (D ^ 4 * H ^ 2) := by
      rw [hSlots]
      calc 8 * (p.D₀ + 2) ^ 2
          ≤ 8 * (25 * (D ^ 2 * H)) ^ 2 :=
            Nat.mul_le_mul_left 8 (Nat.pow_le_pow_left hD0_2 2)
        _ = 5000 * (D ^ 4 * H ^ 2) := by ring
    omega
  have hd4 : d + 4 ≤ 2 * D := by omega
  have hterm_sn : (p.NumSlots + 1) * n * (d + 4) ≤ 10002 * n * P19 := by
    calc (p.NumSlots + 1) * n * (d + 4)
        ≤ (5001 * (D ^ 4 * H ^ 2)) * n * (2 * D) :=
          Nat.mul_le_mul (Nat.mul_le_mul_right n hSlots1_le) hd4
      _ = 10002 * n * (D ^ 5 * H ^ 2) := by ring
      _ ≤ 10002 * n * P19 :=
          Nat.mul_le_mul_left _ (pow_mul_pow_le_target hD1 hH1 (by decide) (by decide))
  have hm_eq : 2 ^ p.P_hpj.q = p.P_hpj.m := hHpjProps.2.2.2.2.2.2.2.1.symm
  have hterm_hpj : (2 ^ p.P_hpj.q) * (d + 1) ≤ (cHpj * 21 ^ 3) * n * P19 := by
    rw [hm_eq]
    have hd1_D : d + 1 ≤ D := by omega
    calc p.P_hpj.m * (d + 1)
        ≤ p.P_hpj.m * D := Nat.mul_le_mul_left _ hd1_D
      _ ≤ (cHpj * 21 ^ 3) * D ^ 7 * H ^ 6 := hmD
      _ = (cHpj * 21 ^ 3) * 1 * (D ^ 7 * H ^ 6) := by ring
      _ ≤ (cHpj * 21 ^ 3) * n * P19 :=
          Nat.mul_le_mul (Nat.mul_le_mul_left _ hn1)
            (pow_mul_pow_le_target hD1 hH1 (by decide) (by decide))
  have hterm_64 : 64 ≤ 64 * n * P19 := by
    have : 1 ≤ n * P19 := Nat.mul_le_mul hn1 hP1
    calc 64 = 64 * 1 := by omega
      _ ≤ 64 * (n * P19) := Nat.mul_le_mul_left 64 this
      _ = 64 * n * P19 := by ring
  unfold p46BoxSize
  calc 64 + p.D₀ + (p.NumSlots + 1) * n * (d + 4) + (2 ^ p.P_hpj.q) * (d + 1)
      ≤ 64 * n * P19 + 24 * n * P19 + 10002 * n * P19 + (cHpj * 21 ^ 3) * n * P19 := by omega
    _ = (10090 + cHpj * 21 ^ 3) * n * P19 := by ring

/-- Explicit polynomial bounds on HPJ, baseline, leaf, split, job-tick, and GC work terms
under `P46Params`, all dominated by `D^19 * H^18` up to constants depending only on `(cBase, cHpj)`. -/
theorem p46_component_costs_poly_le {d n D H cBase cHpj : ℕ} (p : P46Params d n)
    (hD_eq : D = d + 3)
    (hD3 : 3 ≤ D) (hH5 : 5 ≤ H)
    (hK_le : p.K_seg ≤ H)
    (hD0 : p.D₀ = 24 * D ^ 2 * H)
    (hkφ : p.k_φ = 20 * H)
    (hK0 : p.K₀ ≤ 84 * cBase * D ^ 2 * H)
    (hHpjProps : HPJParamProps d p.φ_ev p.P_hpj)
    (hOpCeil : Nat.ceil (hpjOpBound d p.φ_ev) ≤ (cHpj * 21 ^ 3) * D ^ 7 * H ^ 6)
    (hmD : p.P_hpj.m * D ≤ (cHpj * 21 ^ 3) * D ^ 7 * H ^ 6)
    (hMbits : p.M_bits ≤ (105 + cHpj + 4 * cBase) * H)
    (hL : p.L = (68719476736 + 8 * (84 * cBase)) * D ^ 4 * H ^ 2)
    (hBscan : p.B_scan = 16777216 * D ^ 4)
    (hKbatch : p.K_batch = p.B_scan + 1)
    (hSlots : p.NumSlots = 8 * (p.D₀ + 2) ^ 2)
    (hBhpj : p.B_hpj = (2 ^ p.P_hpj.q) * p.M_bits + p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q) :
    let C_hpj0 := cHpj * 21 ^ 3
    let C_mb := 105 + cHpj + 4 * cBase
    let C_L := 68719476736 + 8 * (84 * cBase)
    let P19 := D ^ 19 * H ^ 18
    p.B_hpj ≤ (C_hpj0 * (C_mb + 1)) * (D ^ 7 * H ^ 7) ∧
    hpjCallCost d n p ≤
      (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
        16 * (C_hpj0 * (C_mb + 1)) + 500) * (D ^ 8 * H ^ 7) ∧
    baselineCallCost d n p ≤
      (250 * (84 * cBase + 1) * (C_mb + 4) + 500) * (D ^ 3 * H ^ 2) ∧
    (p.D₀ + 20 * D ^ 2 + 2) * hpjCallCost d n p ≤
      (46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
        16 * (C_hpj0 * (C_mb + 1)) + 500)) * P19 ∧
    (p.D₀ + 2) * baselineCallCost d n p ≤
      (26 * (250 * (84 * cBase + 1) * (C_mb + 4) + 500)) * P19 ∧
    (350 * (4 * p.L + 5) * (4 * p.L + 5) * (p.K_seg + d + 5) + 500) ≤
      (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3 + 500) * P19 ∧
    (p.D₀ + 2) * (p.D₀ + 2) * (2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5)) ≤
      (625 * (2400 * 16777218 * 3 + 15000)) * P19 ∧
    (4 * p.D₀ + 80 * D ^ 2 + 20) *
        (40 * p.NumSlots + 300 * (p.D₀ + 1) * (p.D₀ + 1) + 35 * (p.NumSlots + 1) + 500) ≤
      (196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * P19 := by
  intro C_hpj0 C_mb C_L P19
  have hD1 : 1 ≤ D := by omega
  have hH1 : 1 ≤ H := by omega
  have hDH1 : 1 ≤ D * H := Nat.mul_le_mul hD1 hH1
  have hD2H1 : 1 ≤ D ^ 2 * H :=
    Nat.mul_le_mul (Nat.one_le_pow 2 D hD1) hH1
  have hD4H2_1 : 1 ≤ D ^ 4 * H ^ 2 :=
    Nat.mul_le_mul (Nat.one_le_pow 4 D hD1) (Nat.one_le_pow 2 H hH1)
  have hD7H6_1 : 1 ≤ D ^ 7 * H ^ 6 :=
    Nat.mul_le_mul (Nat.one_le_pow 7 D hD1) (Nat.one_le_pow 6 H hH1)
  have hm_eq : 2 ^ p.P_hpj.q = p.P_hpj.m := hHpjProps.2.2.2.2.2.2.2.1.symm
  have hm_le : 2 ^ p.P_hpj.q ≤ C_hpj0 * (D ^ 7 * H ^ 6) := by
    rw [hm_eq]
    calc p.P_hpj.m ≤ p.P_hpj.m * D := by
          calc p.P_hpj.m = p.P_hpj.m * 1 := by omega
            _ ≤ p.P_hpj.m * D := Nat.mul_le_mul_left _ hD1
      _ ≤ C_hpj0 * D ^ 7 * H ^ 6 := hmD
      _ = C_hpj0 * (D ^ 7 * H ^ 6) := by ring
  have hLwalk_le : p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q ≤ C_hpj0 * (D ^ 7 * H ^ 6) := by
    have hPD : p.P_hpj.D = d + 1 := hHpjProps.1
    have hwork_real := hHpjProps.2.2.2.2.2.2.2.2.2.2.2.2.2
    have hterm_nat :
        p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q ≤
          p.P_hpj.k_d + p.P_hpj.k_phi + p.P_hpj.m * (p.P_hpj.D + 2) +
            p.P_hpj.L * ((p.P_hpj.D + 3) * (p.P_hpj.q + 1) + (p.P_hpj.D + 3) ^ 3) := by
      rw [← hPD]
      have h1 : p.P_hpj.L * (p.P_hpj.D + 3) * p.P_hpj.q ≤
          p.P_hpj.L * ((p.P_hpj.D + 3) * (p.P_hpj.q + 1)) := by
        calc p.P_hpj.L * (p.P_hpj.D + 3) * p.P_hpj.q
            = p.P_hpj.L * ((p.P_hpj.D + 3) * p.P_hpj.q) := by ring
          _ ≤ p.P_hpj.L * ((p.P_hpj.D + 3) * (p.P_hpj.q + 1)) :=
              Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ (by omega))
      have h2 : p.P_hpj.L * ((p.P_hpj.D + 3) * (p.P_hpj.q + 1)) ≤
          p.P_hpj.L * ((p.P_hpj.D + 3) * (p.P_hpj.q + 1) + (p.P_hpj.D + 3) ^ 3) :=
        Nat.mul_le_mul_left _ (Nat.le_add_right _ _)
      exact (h1.trans h2).trans (Nat.le_add_left _ _)
    have h_le_op : ((p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q : ℕ) : ℝ) ≤ hpjOpBound d p.φ_ev := by
      have hcast :
          ((p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q : ℕ) : ℝ) ≤
            ((p.P_hpj.k_d + p.P_hpj.k_phi + p.P_hpj.m * (p.P_hpj.D + 2) +
              p.P_hpj.L * ((p.P_hpj.D + 3) * (p.P_hpj.q + 1) + (p.P_hpj.D + 3) ^ 3) : ℕ) : ℝ) := by
        exact_mod_cast hterm_nat
      have hnn :
          (0 : ℝ) ≤ ((p.P_hpj.k_d + p.P_hpj.k_phi + p.P_hpj.m * (p.P_hpj.D + 2) +
            p.P_hpj.L * ((p.P_hpj.D + 3) * (p.P_hpj.q + 1) + (p.P_hpj.D + 3) ^ 3) : ℕ) : ℝ) :=
        Nat.cast_nonneg _
      linarith
    have h_le_ceil : p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q ≤ Nat.ceil (hpjOpBound d p.φ_ev) := by
      exact_mod_cast h_le_op.trans (Nat.le_ceil _)
    calc p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q
        ≤ Nat.ceil (hpjOpBound d p.φ_ev) := h_le_ceil
      _ ≤ C_hpj0 * D ^ 7 * H ^ 6 := hOpCeil
      _ = C_hpj0 * (D ^ 7 * H ^ 6) := by ring
  have hBhpj_le : p.B_hpj ≤ (C_hpj0 * (C_mb + 1)) * (D ^ 7 * H ^ 7) := by
    rw [hBhpj]
    have ht1 : (2 ^ p.P_hpj.q) * p.M_bits ≤ (C_hpj0 * C_mb) * (D ^ 7 * H ^ 7) := by
      calc (2 ^ p.P_hpj.q) * p.M_bits
          ≤ (C_hpj0 * (D ^ 7 * H ^ 6)) * (C_mb * H) := Nat.mul_le_mul hm_le hMbits
        _ = (C_hpj0 * C_mb) * (D ^ 7 * H ^ 7) := by ring
    have ht2 : p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q ≤ C_hpj0 * (D ^ 7 * H ^ 7) := by
      calc p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q
          ≤ C_hpj0 * (D ^ 7 * H ^ 6) := hLwalk_le
        _ = C_hpj0 * (D ^ 7 * H ^ 6 * 1) := by ring
        _ ≤ C_hpj0 * (D ^ 7 * H ^ 6 * H) :=
            Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ hH1)
        _ = C_hpj0 * (D ^ 7 * H ^ 7) := by ring
    calc (2 ^ p.P_hpj.q) * p.M_bits + p.P_hpj.L * (d + 1 + 3) * p.P_hpj.q
        ≤ (C_hpj0 * C_mb) * (D ^ 7 * H ^ 7) + C_hpj0 * (D ^ 7 * H ^ 7) := Nat.add_le_add ht1 ht2
      _ = (C_hpj0 * (C_mb + 1)) * (D ^ 7 * H ^ 7) := by ring
  have hKd5 : p.K_seg + d + 5 ≤ 3 * (D * H) := by
    have hd5 : d + 5 ≤ 2 * D := by omega
    have hK_DH : p.K_seg ≤ D * H := by
      calc p.K_seg ≤ H := hK_le
        _ = 1 * H := by omega
        _ ≤ D * H := Nat.mul_le_mul_right H hD1
    have hd5_DH : d + 5 ≤ 2 * (D * H) := by
      calc d + 5 ≤ 2 * D := hd5
        _ = 2 * (D * 1) := by ring
        _ ≤ 2 * (D * H) := Nat.mul_le_mul_left 2 (Nat.mul_le_mul_left D hH1)
    omega
  have hMKd5 : p.M_bits + p.K_seg + d + 5 ≤ (C_mb + 4) * (D * H) := by
    have hMb_DH : p.M_bits ≤ C_mb * (D * H) := by
      calc p.M_bits ≤ C_mb * H := hMbits
        _ = C_mb * (1 * H) := by ring
        _ ≤ C_mb * (D * H) := Nat.mul_le_mul_left _ (Nat.mul_le_mul_right H hD1)
    have heq : (C_mb + 4) * (D * H) = C_mb * (D * H) + 4 * (D * H) := by ring
    rw [heq]; omega
  have hHpjCost :
      hpjCallCost d n p ≤
        (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
          16 * (C_hpj0 * (C_mb + 1)) + 500) * (D ^ 8 * H ^ 7) := by
    unfold hpjCallCost
    have hD8H7_1 : 1 ≤ D ^ 8 * H ^ 7 :=
      Nat.mul_le_mul (Nat.one_le_pow 8 D hD1) (Nat.one_le_pow 7 H hH1)
    have hm1 : 2 ^ p.P_hpj.q + 1 ≤ (C_hpj0 + 1) * (D ^ 7 * H ^ 6) := by
      calc 2 ^ p.P_hpj.q + 1
          ≤ C_hpj0 * (D ^ 7 * H ^ 6) + 1 * (D ^ 7 * H ^ 6) := Nat.add_le_add hm_le (by omega)
        _ = (C_hpj0 + 1) * (D ^ 7 * H ^ 6) := by ring
    have ht1 :
        250 * (2 ^ p.P_hpj.q + 1) * (p.M_bits + p.K_seg + d + 5) ≤
          (250 * (C_hpj0 + 1) * (C_mb + 4)) * (D ^ 8 * H ^ 7) := by
      calc 250 * (2 ^ p.P_hpj.q + 1) * (p.M_bits + p.K_seg + d + 5)
          ≤ 250 * ((C_hpj0 + 1) * (D ^ 7 * H ^ 6)) * ((C_mb + 4) * (D * H)) :=
            Nat.mul_le_mul (Nat.mul_le_mul_left 250 hm1) hMKd5
        _ = (250 * (C_hpj0 + 1) * (C_mb + 4)) * (D ^ 8 * H ^ 7) := by ring
    have ht2 : 30 * p.k_φ ≤ 600 * (D ^ 8 * H ^ 7) := by
      rw [hkφ]
      have hH_le : H ≤ D ^ 8 * H ^ 7 := by
        calc H = 1 * H ^ 1 := by ring
          _ ≤ D ^ 8 * H ^ 7 :=
              Nat.mul_le_mul (Nat.one_le_pow 8 D hD1) (Nat.pow_le_pow_right hH1 (by decide))
      calc 30 * (20 * H) = 600 * H := by ring
        _ ≤ 600 * (D ^ 8 * H ^ 7) := Nat.mul_le_mul_left 600 hH_le
    have ht3 : 8 * Nat.ceil (hpjOpBound d p.φ_ev) ≤ (8 * C_hpj0) * (D ^ 8 * H ^ 7) := by
      have h76 : D ^ 7 * H ^ 6 ≤ D ^ 8 * H ^ 7 :=
        Nat.mul_le_mul (Nat.pow_le_pow_right hD1 (by decide)) (Nat.pow_le_pow_right hH1 (by decide))
      calc 8 * Nat.ceil (hpjOpBound d p.φ_ev)
          ≤ 8 * (C_hpj0 * D ^ 7 * H ^ 6) := Nat.mul_le_mul_left 8 hOpCeil
        _ = (8 * C_hpj0) * (D ^ 7 * H ^ 6) := by ring
        _ ≤ (8 * C_hpj0) * (D ^ 8 * H ^ 7) := Nat.mul_le_mul_left _ h76
    have ht4 : 16 * p.B_hpj ≤ (16 * (C_hpj0 * (C_mb + 1))) * (D ^ 8 * H ^ 7) := by
      have h77 : D ^ 7 * H ^ 7 ≤ D ^ 8 * H ^ 7 :=
        Nat.mul_le_mul (Nat.pow_le_pow_right hD1 (by decide)) le_rfl
      calc 16 * p.B_hpj
          ≤ 16 * ((C_hpj0 * (C_mb + 1)) * (D ^ 7 * H ^ 7)) := Nat.mul_le_mul_left 16 hBhpj_le
        _ = (16 * (C_hpj0 * (C_mb + 1))) * (D ^ 7 * H ^ 7) := by ring
        _ ≤ (16 * (C_hpj0 * (C_mb + 1))) * (D ^ 8 * H ^ 7) := Nat.mul_le_mul_left _ h77
    have ht5 : 500 ≤ 500 * (D ^ 8 * H ^ 7) := by omega
    calc 250 * (2 ^ p.P_hpj.q + 1) * (p.M_bits + p.K_seg + d + 5) +
            30 * p.k_φ + 8 * Nat.ceil (hpjOpBound d p.φ_ev) + 16 * p.B_hpj + 500
        ≤ (250 * (C_hpj0 + 1) * (C_mb + 4)) * (D ^ 8 * H ^ 7) +
            600 * (D ^ 8 * H ^ 7) + (8 * C_hpj0) * (D ^ 8 * H ^ 7) +
            (16 * (C_hpj0 * (C_mb + 1))) * (D ^ 8 * H ^ 7) + 500 * (D ^ 8 * H ^ 7) := by omega
      _ = (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
            16 * (C_hpj0 * (C_mb + 1)) + 500) * (D ^ 8 * H ^ 7) := by ring
  have hBaseCost :
      baselineCallCost d n p ≤
        (250 * (84 * cBase + 1) * (C_mb + 4) + 500) * (D ^ 3 * H ^ 2) := by
    unfold baselineCallCost
    have hD3H2_1 : 1 ≤ D ^ 3 * H ^ 2 :=
      Nat.mul_le_mul (Nat.one_le_pow 3 D hD1) (Nat.one_le_pow 2 H hH1)
    have hK0_1 : p.K₀ + 1 ≤ (84 * cBase + 1) * (D ^ 2 * H) := by
      calc p.K₀ + 1
          ≤ 84 * cBase * D ^ 2 * H + 1 * (D ^ 2 * H) := Nat.add_le_add hK0 (by omega)
        _ = (84 * cBase + 1) * (D ^ 2 * H) := by ring
    have ht1 :
        250 * (p.K₀ + 1) * (p.M_bits + p.K_seg + d + 5) ≤
          (250 * (84 * cBase + 1) * (C_mb + 4)) * (D ^ 3 * H ^ 2) := by
      calc 250 * (p.K₀ + 1) * (p.M_bits + p.K_seg + d + 5)
          ≤ 250 * ((84 * cBase + 1) * (D ^ 2 * H)) * ((C_mb + 4) * (D * H)) :=
            Nat.mul_le_mul (Nat.mul_le_mul_left 250 hK0_1) hMKd5
        _ = (250 * (84 * cBase + 1) * (C_mb + 4)) * (D ^ 3 * H ^ 2) := by ring
    have ht2 : 500 ≤ 500 * (D ^ 3 * H ^ 2) := by omega
    calc 250 * (p.K₀ + 1) * (p.M_bits + p.K_seg + d + 5) + 500
        ≤ (250 * (84 * cBase + 1) * (C_mb + 4)) * (D ^ 3 * H ^ 2) + 500 * (D ^ 3 * H ^ 2) :=
          Nat.add_le_add ht1 ht2
      _ = (250 * (84 * cBase + 1) * (C_mb + 4) + 500) * (D ^ 3 * H ^ 2) := by ring
  have hD0_2 : p.D₀ + 2 ≤ 25 * (D ^ 2 * H) := by
    have hD2 : 9 ≤ D ^ 2 := by simpa using Nat.pow_le_pow_left hD3 2
    have h2 : 2 ≤ D ^ 2 * H := by
      have : 45 ≤ D ^ 2 * H := Nat.mul_le_mul hD2 hH5
      omega
    rw [hD0]
    have heq : 24 * D ^ 2 * H = 24 * (D ^ 2 * H) := by ring
    rw [heq]; omega
  have hD0_20 : p.D₀ + 20 * D ^ 2 + 2 ≤ 46 * (D ^ 2 * H) := by
    rw [hD0]
    have hD2_le : D ^ 2 ≤ D ^ 2 * H := by
      calc D ^ 2 = D ^ 2 * 1 := by ring
        _ ≤ D ^ 2 * H := Nat.mul_le_mul_left _ hH1
    have heq : 24 * D ^ 2 * H = 24 * (D ^ 2 * H) := by ring
    rw [heq]; omega
  have hHpjTot :
      (p.D₀ + 20 * D ^ 2 + 2) * hpjCallCost d n p ≤
        (46 * (250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
          16 * (C_hpj0 * (C_mb + 1)) + 500)) * P19 := by
    let Kh := 250 * (C_hpj0 + 1) * (C_mb + 4) + 600 + 8 * C_hpj0 +
      16 * (C_hpj0 * (C_mb + 1)) + 500
    calc (p.D₀ + 20 * D ^ 2 + 2) * hpjCallCost d n p
        ≤ (46 * (D ^ 2 * H)) * (Kh * (D ^ 8 * H ^ 7)) := Nat.mul_le_mul hD0_20 hHpjCost
      _ = (46 * Kh) * (D ^ 10 * H ^ 8) := by ring
      _ ≤ (46 * Kh) * P19 :=
          Nat.mul_le_mul_left _ (pow_mul_pow_le_target hD1 hH1 (by decide) (by decide))
  have hBaseTot :
      (p.D₀ + 2) * baselineCallCost d n p ≤
        (26 * (250 * (84 * cBase + 1) * (C_mb + 4) + 500)) * P19 := by
    let Kb := 250 * (84 * cBase + 1) * (C_mb + 4) + 500
    have hD0_26 : p.D₀ + 2 ≤ 26 * (D ^ 2 * H) := by omega
    calc (p.D₀ + 2) * baselineCallCost d n p
        ≤ (26 * (D ^ 2 * H)) * (Kb * (D ^ 3 * H ^ 2)) := Nat.mul_le_mul hD0_26 hBaseCost
      _ = (26 * Kb) * (D ^ 5 * H ^ 3) := by ring
      _ ≤ (26 * Kb) * P19 :=
          Nat.mul_le_mul_left _ (pow_mul_pow_le_target hD1 hH1 (by decide) (by decide))
  have hLeafTot :
      350 * (4 * p.L + 5) * (4 * p.L + 5) * (p.K_seg + d + 5) + 500 ≤
        (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3 + 500) * P19 := by
    have h4L5 : 4 * p.L + 5 ≤ (4 * C_L + 5) * (D ^ 4 * H ^ 2) := by
      rw [hL]
      calc 4 * (C_L * D ^ 4 * H ^ 2) + 5
          ≤ 4 * (C_L * (D ^ 4 * H ^ 2)) + 5 * (D ^ 4 * H ^ 2) := by
            have : 5 ≤ 5 * (D ^ 4 * H ^ 2) := by omega
            have heq : C_L * D ^ 4 * H ^ 2 = C_L * (D ^ 4 * H ^ 2) := by ring
            rw [heq]; omega
        _ = (4 * C_L + 5) * (D ^ 4 * H ^ 2) := by ring
    have ht1 :
        350 * (4 * p.L + 5) * (4 * p.L + 5) * (p.K_seg + d + 5) ≤
          (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3) * P19 := by
      calc 350 * (4 * p.L + 5) * (4 * p.L + 5) * (p.K_seg + d + 5)
          ≤ 350 * ((4 * C_L + 5) * (D ^ 4 * H ^ 2)) *
              ((4 * C_L + 5) * (D ^ 4 * H ^ 2)) * (3 * (D * H)) :=
            Nat.mul_le_mul
              (Nat.mul_le_mul (Nat.mul_le_mul_left 350 h4L5) h4L5) hKd5
        _ = (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3) * (D ^ 9 * H ^ 5) := by ring
        _ ≤ (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3) * P19 :=
            Nat.mul_le_mul_left _ (pow_mul_pow_le_target hD1 hH1 (by decide) (by decide))
    have hP1 : 1 ≤ P19 := one_le_target hD1 hH1
    have ht2 : 500 ≤ 500 * P19 := by omega
    calc 350 * (4 * p.L + 5) * (4 * p.L + 5) * (p.K_seg + d + 5) + 500
        ≤ (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3) * P19 + 500 * P19 := Nat.add_le_add ht1 ht2
      _ = (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3 + 500) * P19 := by ring
  have hJobTot :
      (p.D₀ + 2) * (p.D₀ + 2) *
          (2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5)) ≤
        (625 * (2400 * 16777218 * 3 + 15000)) * P19 := by
    have hKb1 : p.K_batch + 1 ≤ 16777218 * D ^ 4 := by
      rw [hKbatch, hBscan]
      have : 1 ≤ D ^ 4 := Nat.one_le_pow 4 D hD1
      omega
    have hinner :
        2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5) ≤
          (2400 * 16777218 * 3 + 15000) * (D ^ 5 * H) := by
      have ha :
          2400 * (p.K_batch + 1) * (p.K_seg + d + 5) ≤
            (2400 * 16777218 * 3) * (D ^ 5 * H) := by
        calc 2400 * (p.K_batch + 1) * (p.K_seg + d + 5)
            ≤ 2400 * (16777218 * D ^ 4) * (3 * (D * H)) :=
              Nat.mul_le_mul (Nat.mul_le_mul_left 2400 hKb1) hKd5
          _ = (2400 * 16777218 * 3) * (D ^ 5 * H) := by ring
      have hb : 5000 * (p.K_seg + d + 5) ≤ 15000 * (D ^ 5 * H) := by
        have hD_D5 : D ≤ D ^ 5 := by
          simpa using Nat.pow_le_pow_right hD1 (by decide : 1 ≤ 5)
        have hDH_51 : D * H ≤ D ^ 5 * H :=
          Nat.mul_le_mul_right H hD_D5
        calc 5000 * (p.K_seg + d + 5)
            ≤ 5000 * (3 * (D * H)) := Nat.mul_le_mul_left 5000 hKd5
          _ = 15000 * (D * H) := by ring
          _ ≤ 15000 * (D ^ 5 * H) := Nat.mul_le_mul_left 15000 hDH_51
      calc 2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5)
          ≤ (2400 * 16777218 * 3) * (D ^ 5 * H) + 15000 * (D ^ 5 * H) := Nat.add_le_add ha hb
        _ = (2400 * 16777218 * 3 + 15000) * (D ^ 5 * H) := by ring
    calc (p.D₀ + 2) * (p.D₀ + 2) *
            (2400 * (p.K_batch + 1) * (p.K_seg + d + 5) + 5000 * (p.K_seg + d + 5))
        ≤ (25 * (D ^ 2 * H)) * (25 * (D ^ 2 * H)) *
            ((2400 * 16777218 * 3 + 15000) * (D ^ 5 * H)) :=
          Nat.mul_le_mul (Nat.mul_le_mul hD0_2 hD0_2) hinner
      _ = (625 * (2400 * 16777218 * 3 + 15000)) * (D ^ 9 * H ^ 3) := by ring
      _ ≤ (625 * (2400 * 16777218 * 3 + 15000)) * P19 :=
          Nat.mul_le_mul_left _ (pow_mul_pow_le_target hD1 hH1 (by decide) (by decide))
  have hGCTot :
      (4 * p.D₀ + 80 * D ^ 2 + 20) *
          (40 * p.NumSlots + 300 * (p.D₀ + 1) * (p.D₀ + 1) + 35 * (p.NumSlots + 1) + 500) ≤
        (196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * P19 := by
    have hcnt : 4 * p.D₀ + 80 * D ^ 2 + 20 ≤ 196 * (D ^ 2 * H) := by
      rw [hD0]
      have hD2_le : D ^ 2 ≤ D ^ 2 * H := by
        calc D ^ 2 = D ^ 2 * 1 := by ring
          _ ≤ D ^ 2 * H := Nat.mul_le_mul_left _ hH1
      have heq : 24 * D ^ 2 * H = 24 * (D ^ 2 * H) := by ring
      rw [heq]; omega
    have hSlots_le : p.NumSlots ≤ 5000 * (D ^ 4 * H ^ 2) := by
      rw [hSlots]
      calc 8 * (p.D₀ + 2) ^ 2
          ≤ 8 * (25 * (D ^ 2 * H)) ^ 2 :=
            Nat.mul_le_mul_left 8 (Nat.pow_le_pow_left hD0_2 2)
        _ = 5000 * (D ^ 4 * H ^ 2) := by ring
    have hSlots1 : p.NumSlots + 1 ≤ 5001 * (D ^ 4 * H ^ 2) := by omega
    have hD0_1_sq : (p.D₀ + 1) * (p.D₀ + 1) ≤ 625 * (D ^ 4 * H ^ 2) := by
      have hD0_1 : p.D₀ + 1 ≤ 25 * (D ^ 2 * H) := by omega
      calc (p.D₀ + 1) * (p.D₀ + 1)
          ≤ (25 * (D ^ 2 * H)) * (25 * (D ^ 2 * H)) := Nat.mul_le_mul hD0_1 hD0_1
        _ = 625 * (D ^ 4 * H ^ 2) := by ring
    have hgc_one :
        40 * p.NumSlots + 300 * (p.D₀ + 1) * (p.D₀ + 1) + 35 * (p.NumSlots + 1) + 500 ≤
          (40 * 5000 + 300 * 625 + 35 * 5001 + 500) * (D ^ 4 * H ^ 2) := by
      have ha : 40 * p.NumSlots ≤ (40 * 5000) * (D ^ 4 * H ^ 2) := by
        calc 40 * p.NumSlots ≤ 40 * (5000 * (D ^ 4 * H ^ 2)) := Nat.mul_le_mul_left 40 hSlots_le
          _ = (40 * 5000) * (D ^ 4 * H ^ 2) := by ring
      have hb : 300 * (p.D₀ + 1) * (p.D₀ + 1) ≤ (300 * 625) * (D ^ 4 * H ^ 2) := by
        calc 300 * (p.D₀ + 1) * (p.D₀ + 1)
            = 300 * ((p.D₀ + 1) * (p.D₀ + 1)) := by ring
          _ ≤ 300 * (625 * (D ^ 4 * H ^ 2)) := Nat.mul_le_mul_left 300 hD0_1_sq
          _ = (300 * 625) * (D ^ 4 * H ^ 2) := by ring
      have hc : 35 * (p.NumSlots + 1) ≤ (35 * 5001) * (D ^ 4 * H ^ 2) := by
        calc 35 * (p.NumSlots + 1)
            ≤ 35 * (5001 * (D ^ 4 * H ^ 2)) := Nat.mul_le_mul_left 35 hSlots1
          _ = (35 * 5001) * (D ^ 4 * H ^ 2) := by ring
      have hd : 500 ≤ 500 * (D ^ 4 * H ^ 2) := by omega
      calc 40 * p.NumSlots + 300 * (p.D₀ + 1) * (p.D₀ + 1) + 35 * (p.NumSlots + 1) + 500
          ≤ (40 * 5000) * (D ^ 4 * H ^ 2) + (300 * 625) * (D ^ 4 * H ^ 2) +
              (35 * 5001) * (D ^ 4 * H ^ 2) + 500 * (D ^ 4 * H ^ 2) := by omega
        _ = (40 * 5000 + 300 * 625 + 35 * 5001 + 500) * (D ^ 4 * H ^ 2) := by ring
    calc (4 * p.D₀ + 80 * D ^ 2 + 20) *
            (40 * p.NumSlots + 300 * (p.D₀ + 1) * (p.D₀ + 1) + 35 * (p.NumSlots + 1) + 500)
        ≤ (196 * (D ^ 2 * H)) *
            ((40 * 5000 + 300 * 625 + 35 * 5001 + 500) * (D ^ 4 * H ^ 2)) :=
          Nat.mul_le_mul hcnt hgc_one
      _ = (196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * (D ^ 6 * H ^ 3) := by ring
      _ ≤ (196 * (40 * 5000 + 300 * 625 + 35 * 5001 + 500)) * P19 :=
          Nat.mul_le_mul_left _ (pow_mul_pow_le_target hD1 hH1 (by decide) (by decide))
  exact ⟨hBhpj_le, hHpjCost, hBaseCost, hHpjTot, hBaseTot, hLeafTot, hJobTot, hGCTot⟩

end UL.Proof_lem_7_2_RacerP46
