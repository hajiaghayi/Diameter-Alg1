import Mathlib
import UL.Stmt.lem_7_2
import UL.Stmt.cit_hpj19_thm18
import UL.Stmt.clm_5_1_mc_baseline
import UL.Stmt.lem_5_2
import UL.Stmt.clm_7_3_failure_budget
import UL.Proof.lem_7_2.CG01_ServingSchedB
import UL.Proof.lem_7_2.CG03_JobTickA0b
import UL.Proof.lem_7_2.CG04_StepA
set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. `RandExecBad` Pop-Depth Exposure & `EncServingChain` Answer-Stage Congruence -/

lemma RandExecBad.with_popDepth {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt} {B : ℕ}
    {mem₀ : ArithRAMMemory} {SafePost GoodPost : ArithRAMMemory → Prop}
    {p_bad : ℝ} {C : ℕ}
    (h : RandExecBad inp s B mem₀ SafePost GoodPost p_bad C) :
    RandExecBad inp s B mem₀ (fun m' => m'.popDepth 0 = m' ∧ SafePost m') GoodPost p_bad C := by
  rcases h with ⟨hp, Post, Bad, hDec, hR, hcard, hpost⟩
  refine ⟨hp, Post, Bad, hDec, hR, hcard, fun bits m' hm' => ?_⟩
  rcases hpost bits m' hm' with ⟨hpop, hs, hg⟩
  exact ⟨hpop, ⟨hpop, hs⟩, hg⟩

lemma snSlotSet_congr_not_0_26 {mem m' : ArithRAMMemory}
    (hw : ∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx)
    (r : ℕ) :
    snSlotSet m' r = snSlotSet mem r := by
  unfold snSlotSet
  rw [hw 14 (by decide) (by decide) (r : ℤ), hw 15 (by decide) (by decide) (r : ℤ)]

lemma EncServingNode.congr_not_0_26 {d K NumSlots : ℕ} {mem m' : ArithRAMMemory}
    {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {r : ℕ} {N : ChainNode d} {S_r : Finset ℕ} {age_r : ℕ}
    (h : EncServingNode d K NumSlots mem livePts r N S_r age_r)
    (hw : ∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx)
    (hr : ∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx) :
    EncServingNode d K NumSlots m' livePts r N S_r age_r := by
  rcases h with ⟨dS, spS, hdS0, hdS_lt, hspS0, hspS_lt, hne,
    h13, h14, h15, h6d, h6sp, h12, hr13, hSegD, hSegSp⟩
  refine ⟨dS, spS, hdS0, hdS_lt, hspS0, hspS_lt, hne,
    by rw [hw 13 (by decide) (by decide)]; exact h13,
    by rw [hw 14 (by decide) (by decide)]; exact h14,
    by rw [hw 15 (by decide) (by decide)]; exact h15,
    by rw [hw 6 (by decide) (by decide)]; exact h6d,
    by rw [hw 6 (by decide) (by decide)]; exact h6sp,
    fun c => by rw [hr 12 (by decide) (by decide)]; exact h12 c,
    by rw [hr 13 (by decide) (by decide)]; exact hr13,
    hSegD.congr_mem_fSq
      (hw 5 (by decide) (by decide) _)
      (fun _ _ => hw 8 (by decide) (by decide) _)
      (fun _ _ => hw 9 (by decide) (by decide) _)
      (fun _ _ => hw 10 (by decide) (by decide) _)
      (fun _ _ => hr 8 (by decide) (by decide) _)
      (fun _ _ => rfl),
    hSegSp.congr_mem_fSq
      (hw 5 (by decide) (by decide) _)
      (fun _ _ => hw 8 (by decide) (by decide) _)
      (fun _ _ => hw 9 (by decide) (by decide) _)
      (fun _ _ => hw 10 (by decide) (by decide) _)
      (fun _ _ => hr 8 (by decide) (by decide) _)
      (fun _ _ => rfl)⟩

theorem EncServingChain.congr_not_0_26 {d n K D₀ NumSlots : ℕ} {mem m' : ArithRAMMemory}
    {P : DynamicPointSet d} {k : ℕ}
    {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ}
    (hC : EncServingChain d n K D₀ NumSlots mem P k nodes snAge)
    (hw : ∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx)
    (hr : ∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx) :
    EncServingChain d n K D₀ NumSlots m' P k nodes snAge := by
  rcases hC with ⟨hk, hnK, hSlots, hPool, hSegGen, hSaveGen, hw15, hw60, hSeg0,
    leafS, hleaf0, hleaf_lt, hw16, hw6leaf, hSegLeaf, hsn, hdisj0, hdisjPair⟩
  have hLive' : EncLiveCoords d n m' P.activeHandles P.handleCoords := by
    refine ⟨hPool.1.1, fun h hh c => ?_⟩
    rw [hr 4 (by decide) (by decide)]
    exact hPool.1.2 h hh c
  have hPool' : EncHandlePool d n m' P := by
    rcases hPool.2 with ⟨hwm, freeSet, hhwm, hw10, hw11, hw12, hdisj, hunion, hfree1, hfree2, hw2⟩
    refine ⟨hLive', hwm, freeSet, hhwm,
      by rw [hw 1 (by decide) (by decide)]; exact hw10,
      by rw [hw 1 (by decide) (by decide)]; exact hw11,
      by rw [hw 1 (by decide) (by decide)]; exact hw12,
      hdisj, hunion,
      fun i hi => by rw [hw 3 (by decide) (by decide)]; exact hfree1 i hi,
      fun i hi j hj hne => by
        rw [hw 3 (by decide) (by decide), hw 3 (by decide) (by decide)]
        exact hfree2 i hi j hj hne,
      fun h hh => by rw [hw 2 (by decide) (by decide)]; exact hw2 h hh⟩
  have hSegGen' : SegGenBound K NumSlots m' := by
    refine ⟨by rw [hw 1 (by decide) (by decide)]; exact hSegGen.1,
      fun s hs => by
        rw [hw 5 (by decide) (by decide), hw 1 (by decide) (by decide)]
        exact hSegGen.2.1 s hs,
      fun s hs u hu => by
        rw [hw 8 (by decide) (by decide), hw 1 (by decide) (by decide)]
        exact hSegGen.2.2 s hs u hu⟩
  have hSaveGen' : SaveGenBound n NumSlots m' := by
    refine ⟨by rw [hw 1 (by decide) (by decide)]; exact hSaveGen.1,
      fun s hs => by
        rw [hw 6 (by decide) (by decide), hw 1 (by decide) (by decide)]
        exact hSaveGen.2.1 s hs,
      fun s hs h hh => by
        rw [hw 11 (by decide) (by decide), hw 1 (by decide) (by decide)]
        exact hSaveGen.2.2 s hs h hh⟩
  refine ⟨hk, hnK, hSlots, hPool', hSegGen', hSaveGen',
    by rw [hw 1 (by decide) (by decide)]; exact hw15,
    by rw [hw 6 (by decide) (by decide)]; exact hw60,
    hSeg0.congr_mem_fSq
      (hw 5 (by decide) (by decide) _)
      (fun _ _ => hw 8 (by decide) (by decide) _)
      (fun _ _ => hw 9 (by decide) (by decide) _)
      (fun _ _ => hw 10 (by decide) (by decide) _)
      (fun _ _ => hr 8 (by decide) (by decide) _)
      (fun _ _ => rfl),
    leafS, hleaf0, hleaf_lt,
    by rw [hw 1 (by decide) (by decide)]; exact hw16,
    by rw [hw 6 (by decide) (by decide)]; exact hw6leaf,
    hSegLeaf.congr_mem_fSq
      (hw 5 (by decide) (by decide) _)
      (fun _ _ => hw 8 (by decide) (by decide) _)
      (fun _ _ => hw 9 (by decide) (by decide) _)
      (fun _ _ => hw 10 (by decide) (by decide) _)
      (fun _ _ => hr 8 (by decide) (by decide) _)
      (fun _ _ => rfl),
    fun r => (hsn r).congr_not_0_26 hw hr,
    fun r s hs => by rw [snSlotSet_congr_not_0_26 hw r] at hs; exact hdisj0 r s hs,
    fun r₁ r₂ hne => by
      rw [snSlotSet_congr_not_0_26 hw r₁, snSlotSet_congr_not_0_26 hw r₂]
      exact hdisjPair r₁ r₂ hne⟩

lemma EncServingChain.answer_hyps {d n K D₀ NumSlots : ℕ} {mem : ArithRAMMemory}
    {P : DynamicPointSet d} {k : ℕ}
    {nodes : Fin k → ChainNode d} {snAge : Fin k → ℕ}
    (hC : EncServingChain d n K D₀ NumSlots mem P k nodes snAge) :
    k ≤ D₀ ∧
    wRead mem 1 5 = (k : ℤ) ∧
    wRead mem 1 2 = (P.activeHandles.card : ℤ) ∧
    EncLiveCoords d n mem P.activeHandles P.handleCoords ∧
    EncSegSlot K mem 0 P.activeHandles (fun _ => 0) ∧
    ∃ leafS : ℕ,
      wRead mem 1 6 = (leafS : ℤ) ∧
      EncSegSlot K mem leafS (chainTerminal P.handleCoords nodes P.activeHandles) (fun _ => 0) ∧
      (∀ i : Fin k, ∃ dS < NumSlots,
        wRead mem 14 (i.val : ℤ) = (dS : ℤ) ∧
        EncSegSlot K mem dS
          (chainInput P.handleCoords nodes P.activeHandles i.castSucc)
          (fun x => euclideanDistSq (P.handleCoords x) (nodes i).o)) := by
  rcases hC with ⟨hk, _, _, hPool, _, _, hw15, _, hSeg0,
    leafS, _, _, hw16, _, hSegLeaf, hsn, _, _⟩
  rcases hPool with ⟨hLive, _, _, _, _, _, hw12, _, _, _, _, _⟩
  refine ⟨hk, hw15, hw12, hLive, hSeg0, leafS, hw16, hSegLeaf, fun i => ?_⟩
  rcases hsn i with ⟨dS, _, _, hdS_lt, _, _, _, _, h14, _, _, _, _, _, hSegD, _⟩
  exact ⟨dS, hdS_lt, h14, hSegD⟩

/-! ### 2. Pure Answer-Stage Centerpoint Witnesses & Polynomial Cost Bound -/

lemma PureServingState.answer_hyps
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    {P : DynamicPointSet d}
    (st : PureServingState d n p.H p.L p.B_scan P)
    (hwf : st.WellFormed) :
    (chainTerminal P.handleCoords st.nodes P.activeHandles).card ≤ 3 * p.L + 2 ∧
    (∀ h ∈ P.activeHandles,
      st.uMap.uidOfH h ∈ st.uMap.ActiveUids ∧
      st.uMap.ghostCoords (st.uMap.uidOfH h) = P.handleCoords h ∧
      st.uMap.hOfUid (st.uMap.uidOfH h) = h) ∧
    (∀ u ∈ st.uMap.ActiveUids,
      st.uMap.hOfUid u ∈ P.activeHandles ∧ st.uMap.uidOfH (st.uMap.hOfUid u) = u) ∧
    (∀ (pts : ℕ → EuclideanSpace ℝ (Fin d))
         (P₀ S₀ : Finset ℕ) (age : ℕ) (o : EuclideanSpace ℝ (Fin d)) (s_lift : ℝ)
         (y : ℕ) (farthest : (Fin p.K₀ → ℕ) → ℕ),
       1 ≤ P₀.card →
       IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
         (paraboloidLiftSet (fun i : ↥P₀ => pts i.1)) (liftedPoint o s_lift) →
       HasNodeAge P₀ S₀ age →
       (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀.card : ℝ) / 16 →
       IsNodeMaxRadiusPoint pts o S₀ y →
       let V := liftVariance o s_lift
       let samples := Fintype.piFinset (fun _ : Fin p.K₀ => S₀)
       (∀ samp ∈ samples,
         (∃ j : Fin p.K₀, farthest samp = samp j) ∧
         ∀ j : Fin p.K₀, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖) →
       (((open Classical in samples.filter (fun samp =>
           ¬ IsNodeBaselinePair pts o V S₀ y (farthest samp))).card : ℝ) /
         (samples.card : ℝ)) ≤ p.φ_ev) ∧
    (st.AllCentersGood → ∀ i : Fin st.k,
      ∃ (P₀_uid : Finset ℕ) (age : ℕ),
        1 ≤ P₀_uid.card ∧
        IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
          (paraboloidLiftSet (fun u : ↥P₀_uid => st.uMap.ghostCoords u.1))
          (liftedPoint (st.nodes i).o ((st.nodes i).V + ‖(st.nodes i).o‖ ^ 2)) ∧
        HasNodeAge P₀_uid (chainInput st.uMap.ghostCoords st.nodes st.uMap.ActiveUids i.castSucc) age ∧
        (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀_uid.card : ℝ) / 16) := by
  have hD_eq : p.D = d + 3 := hp.hD_eq
  refine ⟨hwf.2, st.uMap.hbij_H, st.uMap.hbij_U, ?_, ?_⟩
  · intro pts P₀ S₀ age o s_lift y farthest hcard hcp hage hage_le hmax
    rw [hD_eq] at hcp hage_le
    exact hp.hmc_gen pts P₀ S₀ age o s_lift y farthest hcard hcp hage hage_le hmax
  · intro hGood i
    rcases hwf.1 i with ⟨hlarge, _, _, _, hage_i, _⟩
    have htr_le := (st.age_le_alpha_sixteen hwf.1 i).2
    have hcp_i := hGood.1 i
    refine ⟨st.birthSnap i, st.trueAge i, by omega, ?_, hage_i, ?_⟩
    · rw [hD_eq]; exact hcp_i
    · rw [hD_eq]; exact htr_le

def p46AnsStageCost (d n M_leaf : ℕ) (p : P46Params d n) : ℕ :=
  (p.D₀ * (baselineCallCost d n p + 120) + 100) +
    350 * (M_leaf + 1) * (M_leaf + 1) * (p.K_seg + d + 5) +
    250 * (p.K_seg + d + 5) + 1000

def p46AnsPolyConst (cHpj cBase : ℕ) : ℕ :=
  let C_mb := 105 + cHpj + 4 * cBase
  let C_L := 68719476736 + 8 * (84 * cBase)
  26 * (250 * (84 * cBase + 1) * (C_mb + 4) + 500) +
    (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3 + 500) + 4730

theorem P46ParamsValid.ansStageCost_poly_le
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    p46AnsStageCost d n (3 * p.L + 2) p ≤ p46AnsPolyConst cHpj cBase * (D ^ 19 * H ^ 18) := by
  intro D H
  let C_mb := 105 + cHpj + 4 * cBase
  let C_L := 68719476736 + 8 * (84 * cBase)
  let P19 := D ^ 19 * H ^ 18
  have hD_p : p.D = D := hp.hD_eq
  have hH_p : p.H = H := hp.hH_eq
  have hD3 : 3 ≤ D := by rw [← hD_p]; exact hp.hD3
  have hH5 : 5 ≤ H := by rw [← hH_p]; exact hp.hH5
  have hK_le : p.K_seg ≤ H := by rw [← hH_p]; exact hp.hK_le_H
  have hD0 : p.D₀ = 24 * D ^ 2 * H := by have h := hp.hD0; rw [hH_p] at h; exact h
  rcases hp.all_component_costs_poly_le hn
    with ⟨h1_P0, hDH_P0, hD2H_P0, _, _, _, hBaseTot, hLeafTot, _, _⟩
  have h1_P : 1 ≤ P19 := h1_P0
  have hDH_P : D * H ≤ P19 := hDH_P0
  have hD2H_P : D ^ 2 * H ≤ P19 := hD2H_P0
  have hA : p.D₀ * baselineCallCost d n p ≤
      (26 * (250 * (84 * cBase + 1) * (C_mb + 4) + 500)) * P19 := by
    exact (Nat.mul_le_mul_right _ (by omega : p.D₀ ≤ p.D₀ + 2)).trans hBaseTot
  have hB : p.D₀ * 120 + 100 ≤ 2980 * P19 := by
    have hD0_P : p.D₀ ≤ 24 * P19 := by
      rw [hD0, Nat.mul_assoc]
      exact Nat.mul_le_mul_left 24 hD2H_P
    omega
  have hC : 350 * ((3 * p.L + 2) + 1) * ((3 * p.L + 2) + 1) * (p.K_seg + d + 5) ≤
      (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3 + 500) * P19 := by
    have hL_le : (3 * p.L + 2) + 1 ≤ 4 * p.L + 5 := by omega
    have hm1 : 350 * ((3 * p.L + 2) + 1) ≤ 350 * (4 * p.L + 5) := Nat.mul_le_mul_left 350 hL_le
    have hm2 : 350 * ((3 * p.L + 2) + 1) * ((3 * p.L + 2) + 1) ≤
        350 * (4 * p.L + 5) * (4 * p.L + 5) := Nat.mul_le_mul hm1 hL_le
    have hm3 : 350 * ((3 * p.L + 2) + 1) * ((3 * p.L + 2) + 1) * (p.K_seg + d + 5) ≤
        350 * (4 * p.L + 5) * (4 * p.L + 5) * (p.K_seg + d + 5) :=
      Nat.mul_le_mul_right (p.K_seg + d + 5) hm2
    exact hm3.trans ((Nat.le_add_right _ 500).trans hLeafTot)
  have hD_part : 250 * (p.K_seg + d + 5) + 1000 ≤ 1750 * P19 := by
    have hH_DH : H ≤ D * H := by
      calc H = 1 * H := by ring
        _ ≤ D * H := Nat.mul_le_mul_right H (by omega)
    have hD_DH : D ≤ D * H := by
      calc D = D * 1 := by ring
        _ ≤ D * H := Nat.mul_le_mul_left D (by omega)
    have h1_DH : 1 ≤ D * H := Nat.mul_pos (by omega) (by omega)
    have hKd : p.K_seg + d + 5 ≤ 3 * (D * H) := by
      have hdD : d + 3 = D := rfl
      omega
    have hKd_P : p.K_seg + d + 5 ≤ 3 * P19 :=
      hKd.trans (Nat.mul_le_mul_left 3 hDH_P)
    omega
  unfold p46AnsStageCost p46AnsPolyConst
  dsimp only
  have hmul : p.D₀ * (baselineCallCost d n p + 120) + 100 =
      p.D₀ * baselineCallCost d n p + (p.D₀ * 120 + 100) := by ring
  rw [hmul]
  calc p.D₀ * baselineCallCost d n p + (p.D₀ * 120 + 100) +
        350 * (3 * p.L + 2 + 1) * (3 * p.L + 2 + 1) * (p.K_seg + d + 5) +
        250 * (p.K_seg + d + 5) + 1000
      = (p.D₀ * baselineCallCost d n p + (p.D₀ * 120 + 100) +
          350 * (3 * p.L + 2 + 1) * (3 * p.L + 2 + 1) * (p.K_seg + d + 5)) +
          (250 * (p.K_seg + d + 5) + 1000) := by ring
    _ ≤ ((26 * (250 * (84 * cBase + 1) * (C_mb + 4) + 500)) * P19 +
          (2980 * P19) +
          ((350 * (4 * C_L + 5) * (4 * C_L + 5) * 3 + 500) * P19)) +
          (1750 * P19) :=
          Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hA hB) hC) hD_part
    _ = (26 * (250 * (84 * cBase + 1) * (C_mb + 4) + 500) +
          (350 * (4 * C_L + 5) * (4 * C_L + 5) * 3 + 500) + 4730) * P19 := by ring

/-! ### 3. Coupled State, Step Prefix (`stepBootAndRouteStmt`), and `PostRouteContext` -/

def CoupledServingState {d n : ℕ} (p : P46Params d n)
    (EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop)
    (P : DynamicPointSet d)
    (st : PureServingState d n p.H p.L p.B_scan P)
    (mem : ArithRAMMemory) : Prop :=
  mem.popDepth 0 = mem ∧
  st.WellFormed ∧
  EncServingChain d n p.K_seg p.D₀ p.NumSlots mem P st.k st.nodes st.snAge ∧
  EncJobs P st mem

def stepBootAndRouteStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  .seq (ensureServingChainInitStmt M_box)
       (routeLiveUpdateStmt d n p.K_seg p.D₀ p.NumSlots M_box)

def stepBootAndRouteCost (d : ℕ) {n : ℕ} (p : P46Params d n) : ℕ :=
  250 + routeLiveUpdateCost d p.K_seg p.D₀ p.NumSlots

theorem boxSafe_stepBootAndRouteStmt {d n T_max M_box : ℕ}
    (hT : 27 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (stepBootAndRouteStmt d n M_box p) :=
  .seq (boxSafe_ensureServingChainInitStmt (by omega))
       (boxSafe_routeLiveUpdateStmt hT d n p.K_seg p.D₀ p.NumSlots)

theorem P46ParamsValid.stepBootAndRouteCost_poly_le
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n) :
    let D : ℕ := d + 3
    let H : ℕ := Nat.ceil (Real.logb 2 ((2 * ((d + 3 : ℕ) : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
    stepBootAndRouteCost d p ≤ 1050250 * (D ^ 19 * H ^ 18) := by
  intro D H
  rcases hp.all_component_costs_poly_le hn with ⟨h1_P0, _, _, _, hRoute0, _, _, _, _, _⟩
  have h1_P : 1 ≤ D ^ 19 * H ^ 18 := h1_P0
  have hRoute : routeLiveUpdateCost d p.K_seg p.D₀ p.NumSlots ≤ 1050000 * (D ^ 19 * H ^ 18) := hRoute0
  unfold stepBootAndRouteCost
  omega

structure PostRouteContext {d n : ℕ} (p : P46Params d n)
    (EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop)
    (P : DynamicPointSet d) (op : DynamicUpdate d)
    (m_pre : ArithRAMMemory) (st₀ : PureServingState d n p.H p.L p.B_scan P)
    (mem_rt : ArithRAMMemory) (P' : DynamicPointSet d)
    (opH : ℕ) (uMap' : GhostUidMap d P') : Prop where
  hCoupled_pre : CoupledServingState p EncJobs P st₀ m_pre
  hP_wf : P.WellFormed n
  hleg : IsLegalUpdate n Set.univ P op
  hpop_rt : mem_rt.popDepth 0 = mem_rt
  happ : applyDynamicUpdate P op (readStepRetH op mem_rt) = some P'
  hP'_wf : P'.WellFormed n
  hChain_rt :
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    let aff : Fin (st₀.k + 1) → Bool := chainLevelAffected P P' st₀.nodes ins opH
    EncServingChain d n p.K_seg p.D₀ p.NumSlots mem_rt P' st₀.k st₀.nodes
      (fun r => if aff r.castSucc then st₀.snAge r + 1 else st₀.snAge r)
  hopH_n : opH < n
  hopH_K : opH < 2 ^ p.K_seg
  hw26_4 : wRead mem_rt 26 4 = (opH : ℤ)
  hw26_5 :
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    wRead mem_rt 26 5 = (if ins then 1 else 0)
  hle_uid : st₀.uMap.nextUid ≤ uMap'.nextUid
  hag_uid : ∀ u < st₀.uMap.nextUid, uMap'.ghostCoords u = st₀.uMap.ghostCoords u
  hchg_root : IsInputChange P.activeHandles P'.activeHandles
  hcoords_root : ∀ h ∈ P.activeHandles, h ∈ P'.activeHandles → P'.handleCoords h = P.handleCoords h
  hcoords_ne : ∀ h ∈ P.activeHandles, h ≠ opH → h ∈ P'.activeHandles ∧ P'.handleCoords h = P.handleCoords h
  hPerNode :
    let ins : Bool := match op with | .insert _ _ _ => true | .delete _ => false
    let aff : Fin (st₀.k + 1) → Bool := chainLevelAffected P P' st₀.nodes ins opH
    let snAge' : Fin st₀.k → ℕ := fun r => if aff r.castSucc then st₀.snAge r + 1 else st₀.snAge r
    ∀ r : Fin st₀.k,
      let S_pre_h := chainInput P.handleCoords st₀.nodes P.activeHandles r.castSucc
      let S_post_h := chainInput P'.handleCoords st₀.nodes P'.activeHandles r.castSucc
      let S_pre_u := chainInput st₀.uMap.ghostCoords st₀.nodes st₀.uMap.ActiveUids r.castSucc
      let S_post_u := chainInput uMap'.ghostCoords st₀.nodes uMap'.ActiveUids r.castSucc
      wRead mem_rt 20 (r.val : ℤ) = (if aff r.castSucc then 1 else 0) ∧
      (aff r.castSucc = false →
        opH ∉ S_pre_h ∧ opH ∉ S_post_h ∧ S_post_h = S_pre_h ∧ S_post_u = S_pre_u) ∧
      (aff r.castSucc = true →
        IsInputChange S_pre_h S_post_h ∧
        IsInputChange S_pre_u S_post_u ∧
        (ins = true → opH ∉ S_pre_h ∧ S_post_h = insert opH S_pre_h) ∧
        (ins = false → opH ∈ S_pre_h ∧ S_post_h = S_pre_h.erase opH) ∧
        (∃ ev_r : PoolUpdateEvent ℕ,
          ev_r.isClockTick = true ∧
          IsValidPoolUpdateEvent S_pre_u S_post_u ev_r)) ∧
      (∀ (P₀ : Finset ℕ) (trAge : ℕ),
        trAge ≤ st₀.snAge r →
        HasNodeAge P₀ S_pre_u trAge →
        ∃ trAge' ≤ snAge' r, HasNodeAge P₀ S_post_u trAge')
  hSnap : ∀ s < p.NumSlots, 1 ≤ wRead m_pre 6 (s : ℤ) → ∀ S snapPts,
    EncSlotCoords d n m_pre P.activeHandles P.handleCoords s S snapPts →
    EncSlotCoords d n mem_rt P'.activeHandles P'.handleCoords s S snapPts
  hOtherSeg : ∀ s' < p.NumSlots,
    s' ≠ 0 → s' ≠ (wRead m_pre 1 6).toNat → (∀ r : Fin st₀.k, s' ∉ snSlotSet m_pre r.val) →
    ∀ S₁ fSq₁, EncSegSlot p.K_seg m_pre s' S₁ fSq₁ → EncSegSlot p.K_seg mem_rt s' S₁ fSq₁
  hw_other : ∀ tbl, tbl ≠ 0 → tbl ≠ 1 → tbl ≠ 2 → tbl ≠ 3 → tbl ≠ 8 → tbl ≠ 9 → tbl ≠ 10 →
        tbl ≠ 11 → tbl ≠ 13 → tbl ≠ 20 → tbl ≠ 26 →
    ∀ idx, wRead mem_rt tbl idx = wRead m_pre tbl idx
  hw0_other : ∀ idx, idx ≠ 0 → wRead mem_rt 0 idx = wRead m_pre 0 idx
  hw1_other : ∀ idx, idx ≠ 0 → idx ≠ 1 → idx ≠ 2 → wRead mem_rt 1 idx = wRead m_pre 1 idx
  hw13_other : ∀ idx, (idx < 0 ∨ (st₀.k : ℤ) ≤ idx) → wRead mem_rt 13 idx = wRead m_pre 13 idx
  hr_other : ∀ tbl, tbl ≠ 4 → tbl ≠ 8 → tbl ≠ 11 → tbl ≠ 26 →
    ∀ idx, rRead mem_rt tbl idx = rRead m_pre tbl idx

/-! ### 4. Abstract `FullPostRouteSpec`, `AnswerStageSpec`, and `MiddleTickSplitSpec` Contracts -/

structure FullPostRouteSpec (cHpj cBase d n t : ℕ) (δ : ℝ) (p : P46Params d n) where
  EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop
  postRouteStmt : ArithRAMStmt
  T_max : ℕ
  M_box : ℕ
  B_post : ℕ
  C_post : ℕ
  p_post : ℝ
  hT27 : 27 ≤ T_max
  hBox_ge : p46BoxSize d n p ≤ M_box
  hBoxSafe : BoxSafeOuter T_max M_box postRouteStmt
  hp_budget : p_post ≤ perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ
  hEncJobs_empty : ∀ m : ArithRAMMemory,
    m.popDepth 0 = m →
    EncServingChain d n p.K_seg p.D₀ p.NumSlots m (DynamicPointSet.empty d) 0 Fin.elim0 Fin.elim0 →
    (∀ tbl, tbl ≠ 1 → tbl ≠ 5 → ∀ idx, wRead m tbl idx = 0) →
    (∀ tbl idx, rRead m tbl idx = 0) →
    EncJobs (DynamicPointSet.empty d) (PureServingState.empty d n p.H p.L p.B_scan) m
  hExecPostRoute :
    ∀ {P : DynamicPointSet d} {op : DynamicUpdate d}
      {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
      {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
      {opH : ℕ} {uMap' : GhostUidMap d P'}
      {P_good₀ : Prop},
      (P_good₀ → st₀.AllCentersGood) →
      PostRouteContext p EncJobs P op m_pre st₀ mem_rt P' opH uMap' →
      RandExecBad (mkStepInput n P op) postRouteStmt B_post mem_rt
        (fun m_out =>
          wRead m_out 0 0 = wRead mem_rt 0 0 ∧
          ∃ st₁, CoupledServingState p EncJobs P' st₁ m_out)
        (fun m_out =>
          P_good₀ →
            IsValidFactorCAnswer (Real.sqrt 2) P' (readStoredAns m_out) ∧
            ∃ st₁, CoupledServingState p EncJobs P' st₁ m_out ∧ st₁.AllCentersGood)
        p_post C_post

def FullPostRouteSpec.to_stepSimSpec
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (spec : FullPostRouteSpec cHpj cBase d n t δ p) :
    StepSimSpec d n t δ := by
  let SafeInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop := fun k P mem =>
    (k = 0 ∧ P = DynamicPointSet.empty d ∧ mem = ArithRAMMemory.empty) ∨
    ∃ st, CoupledServingState p spec.EncJobs P st mem
  let GoodInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop := fun k P mem =>
    (k = 0 ∧ P = DynamicPointSet.empty d ∧ mem = ArithRAMMemory.empty) ∨
    ∃ st, CoupledServingState p spec.EncJobs P st mem ∧ st.AllCentersGood
  have hBounds := hp.routeBoxBounds hn spec.hBox_ge
  have hRouteBox := hBounds.1
  have h2Slots := hBounds.2.2.1
  have hSlotsBox := hBounds.2.2.2.1
  refine
    { updateStmt0 := .seq (stepBootAndRouteStmt d n spec.M_box p) spec.postRouteStmt
      B_step := spec.B_post
      uBound := stepBootAndRouteCost d p + spec.C_post
      T_max := spec.T_max
      M_box := spec.M_box
      φ_step := spec.p_post
      SafeInv := SafeInv
      GoodInv := GoodInv
      hBoxSafe := .seq (boxSafe_stepBootAndRouteStmt spec.hT27 p) spec.hBoxSafe
      hφ_le := spec.hp_budget
      hSafe₀ := Or.inl ⟨rfl, rfl, rfl⟩
      hGood₀ := Or.inl ⟨rfl, rfl, rfl⟩
      hStep := ?_ }
  intro k P mem₀ op _ hP hpop₀ _ hSafe hleg
  classical
  let inp := mkStepInput n P op
  let P_good₀ : Prop := GoodInv k P mem₀
  have hBoot : ∃ (m_pre : ArithRAMMemory) (st₀ : PureServingState d n p.H p.L p.B_scan P),
      DetExecAt 0 inp (ensureServingChainInitStmt spec.M_box) mem₀ m_pre 250 ∧
      CoupledServingState p spec.EncJobs P st₀ m_pre ∧
      (P_good₀ → st₀.AllCentersGood) := by
    by_cases hG_ex : ∃ st, CoupledServingState p spec.EncJobs P st mem₀ ∧ st.AllCentersGood
    · rcases hG_ex with ⟨st₀, hC₀, hGood_st₀⟩
      have hex_pres := (exec_ensureServingChainInitStmt_pres (M_box := spec.M_box)
        inp mem₀ hC₀.2.2.1).mono_cost (by omega : 20 ≤ 250)
      exact ⟨mem₀, st₀, hex_pres, hC₀, fun _ => hGood_st₀⟩
    · by_cases hInit0 : k = 0 ∧ P = DynamicPointSet.empty d ∧ mem₀ = ArithRAMMemory.empty
      · rcases hInit0 with ⟨_, rfl, rfl⟩
        rcases exec_ensureServingChainInitStmt_empty (K := p.K_seg) (D₀ := p.D₀)
          (NumSlots := p.NumSlots) (M_box := spec.M_box) inp
          hp.hn_le_2K h2Slots (by have := hRouteBox.1; omega) hSlotsBox
          with ⟨m_pre, hex_emp, hpop_pre, hChain_emp, hw_emp, hr_emp⟩
        let st_emp := PureServingState.empty d n p.H p.L p.B_scan
        have hJobs_emp : spec.EncJobs (DynamicPointSet.empty d) st_emp m_pre :=
          spec.hEncJobs_empty m_pre hpop_pre hChain_emp hw_emp hr_emp
        refine ⟨m_pre, st_emp, hex_emp,
          ⟨hpop_pre, PureServingState.empty_wellFormed d n p.H p.L p.B_scan, hChain_emp, hJobs_emp⟩,
          fun _ => PureServingState.empty_allCentersGood d n p.H p.L p.B_scan⟩
      · have hExSafe : ∃ st, CoupledServingState p spec.EncJobs P st mem₀ :=
          Or.resolve_left hSafe hInit0
        rcases hExSafe with ⟨st₀, hC₀⟩
        have hex_pres := (exec_ensureServingChainInitStmt_pres (M_box := spec.M_box)
          inp mem₀ hC₀.2.2.1).mono_cost (by omega : 20 ≤ 250)
        refine ⟨mem₀, st₀, hex_pres, hC₀, ?_⟩
        intro hg
        exact False.elim (hg.elim hInit0 hG_ex)
  rcases hBoot with ⟨m_pre, st₀, hex_init, hC₀, hGood₀_imp⟩
  rcases exec_routeLiveUpdate_with_uid (M_box := spec.M_box)
      P op m_pre st₀.uMap hP hleg hRouteBox hC₀.2.2.1
    with ⟨mem_rt, P', opH, uMap', hex_rt, hpop_rt, happ, hP'_wf, hChain_rt, hopH_n, hopH_K,
          hw26_4, hw26_5, hle_uid, hag_uid, hchg_root, hcoords_root, hcoords_ne,
          hPerNode, hSnap, hOtherSeg, hw_other, hw0_other, hw1_other, hw13_other, hr_other⟩
  have hex_prefix : DetExecAt 0 inp (stepBootAndRouteStmt d n spec.M_box p) mem₀ mem_rt
      (stepBootAndRouteCost d p) :=
    hex_init.seq hex_rt
  have ctx : PostRouteContext p spec.EncJobs P op m_pre st₀ mem_rt P' opH uMap' :=
    { hCoupled_pre := hC₀
      hP_wf := hP
      hleg := hleg
      hpop_rt := hpop_rt
      happ := happ
      hP'_wf := hP'_wf
      hChain_rt := by cases op <;> exact hChain_rt
      hopH_n := hopH_n
      hopH_K := hopH_K
      hw26_4 := hw26_4
      hw26_5 := by cases op <;> exact hw26_5
      hle_uid := hle_uid
      hag_uid := hag_uid
      hchg_root := hchg_root
      hcoords_root := hcoords_root
      hcoords_ne := hcoords_ne
      hPerNode := by cases op <;> exact hPerNode
      hSnap := hSnap
      hOtherSeg := hOtherSeg
      hw_other := hw_other
      hw0_other := hw0_other
      hw1_other := hw1_other
      hw13_other := hw13_other
      hr_other := hr_other }
  have hBad_post := spec.hExecPostRoute hGood₀_imp ctx
  have hBad_full := RandExecBad.seq_det_left hpop₀ hpop_rt hex_prefix hBad_post
  rcases hBad_full with ⟨_, Post, Bad, hDec, hR, hcard, hpost⟩
  refine ⟨Post, Bad, hDec, hR, hcard, ?_⟩
  intro bits m₁ hm₁
  rcases hpost bits m₁ hm₁ with ⟨hpop₁, ⟨hw00, hExSafe'⟩, hg₁⟩
  dsimp only
  rw [hpop₁]
  refine ⟨P', ?_, Or.inr hExSafe', ?_⟩
  · rw [readStepRetH_congr op hw00]
    exact happ
  · intro hG₀ hnb
    rcases hg₁ hnb hG₀ with ⟨hAns, hExGood'⟩
    exact ⟨hAns, Or.inr hExGood'⟩

structure AnswerStageSpec (d n T_max M_box : ℕ) (p : P46Params d n) where
  ansStmt : ArithRAMStmt
  hBoxSafe : BoxSafeOuter T_max M_box ansStmt
  hExecAns :
    ∀ {k : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory)
      {P : DynamicPointSet d} {leafS : ℕ} {fSq0 fSqLeaf : ℕ → ℝ}
      {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
      {ActiveUids : Finset ℕ} {uidOfH hOfUid : ℕ → ℕ}
      (nodes : Fin k → ChainNode d)
      {P_good : Prop},
      mem.popDepth 0 = mem →
      P.WellFormed n →
      k ≤ p.D₀ →
      wRead mem 1 5 = (k : ℤ) →
      wRead mem 1 2 = (P.activeHandles.card : ℤ) →
      wRead mem 1 6 = (leafS : ℤ) →
      (chainTerminal P.handleCoords nodes P.activeHandles).card ≤ 3 * p.L + 2 →
      16 ≤ M_box →
      EncLiveCoords d n mem P.activeHandles P.handleCoords →
      EncSegSlot p.K_seg mem 0 P.activeHandles fSq0 →
      EncSegSlot p.K_seg mem leafS
        (chainTerminal P.handleCoords nodes P.activeHandles) fSqLeaf →
      (∀ i : Fin k, ∃ dS < p.NumSlots,
        wRead mem 14 (i.val : ℤ) = (dS : ℤ) ∧
        EncSegSlot p.K_seg mem dS
          (chainInput P.handleCoords nodes P.activeHandles i.castSucc)
          (fun x => euclideanDistSq (P.handleCoords x) (nodes i).o)) →
      (∀ h ∈ P.activeHandles,
        uidOfH h ∈ ActiveUids ∧ ghostCoords (uidOfH h) = P.handleCoords h ∧ hOfUid (uidOfH h) = h) →
      (∀ u ∈ ActiveUids, hOfUid u ∈ P.activeHandles ∧ uidOfH (hOfUid u) = u) →
      1 ≤ p.K₀ → 0 < p.φ_ev →
      ((p.K₀ : ℝ) * (n : ℝ)) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev →
      (∀ (pts : ℕ → EuclideanSpace ℝ (Fin d))
           (P₀ S₀ : Finset ℕ) (age : ℕ) (o : EuclideanSpace ℝ (Fin d)) (s_lift : ℝ)
           (y : ℕ) (farthest : (Fin p.K₀ → ℕ) → ℕ),
         1 ≤ P₀.card →
         IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
           (paraboloidLiftSet (fun i : ↥P₀ => pts i.1)) (liftedPoint o s_lift) →
         HasNodeAge P₀ S₀ age →
         (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀.card : ℝ) / 16 →
         IsNodeMaxRadiusPoint pts o S₀ y →
         let V := liftVariance o s_lift
         let samples := Fintype.piFinset (fun _ : Fin p.K₀ => S₀)
         (∀ samp ∈ samples,
           (∃ j : Fin p.K₀, farthest samp = samp j) ∧
           ∀ j : Fin p.K₀, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖) →
         (((open Classical in samples.filter (fun samp =>
             ¬ IsNodeBaselinePair pts o V S₀ y (farthest samp))).card : ℝ) /
           (samples.card : ℝ)) ≤ p.φ_ev) →
      (P_good → ∀ i : Fin k,
        ∃ (P₀_uid : Finset ℕ) (age : ℕ),
          1 ≤ P₀_uid.card ∧
          IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
            (paraboloidLiftSet (fun u : ↥P₀_uid => ghostCoords u.1))
            (liftedPoint (nodes i).o ((nodes i).V + ‖(nodes i).o‖ ^ 2)) ∧
          HasNodeAge P₀_uid (chainInput ghostCoords nodes ActiveUids i.castSucc) age ∧
          (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀_uid.card : ℝ) / 16) →
      RandExecBad inp ansStmt (p.D₀ * p.K₀ * p.M_bits) mem
        (fun m' =>
          wRead m' 0 0 = wRead mem 0 0 ∧
          (∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, wRead m' tbl idx = wRead mem tbl idx) ∧
          (∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, rRead m' tbl idx = rRead mem tbl idx))
        (fun m' => P_good → IsValidFactorCAnswer (Real.sqrt 2) P (readStoredAns m'))
        ((p.D₀ : ℝ) * (2 * p.φ_ev))
        (p46AnsStageCost d n (3 * p.L + 2) p)

structure MiddleTickSplitSpec (cHpj cBase d n t : ℕ) (δ : ℝ) (p : P46Params d n) where
  EncJobs : ∀ (P : DynamicPointSet d), PureServingState d n p.H p.L p.B_scan P → ArithRAMMemory → Prop
  midStmt : ArithRAMStmt
  T_max : ℕ
  M_box : ℕ
  B_mid : ℕ
  C_mid : ℕ
  p_mid : ℝ
  hT27 : 27 ≤ T_max
  hBox_ge : p46BoxSize d n p ≤ M_box
  hBoxSafe : BoxSafeOuter T_max M_box midStmt
  hp_budget : p_mid + (p.D₀ : ℝ) * (2 * p.φ_ev) ≤
    perEventFailureBudget (execFailureScaleBit n t d 0 δ) 1 δ
  hEncJobs_empty : ∀ m : ArithRAMMemory,
    m.popDepth 0 = m →
    EncServingChain d n p.K_seg p.D₀ p.NumSlots m (DynamicPointSet.empty d) 0 Fin.elim0 Fin.elim0 →
    (∀ tbl, tbl ≠ 1 → tbl ≠ 5 → ∀ idx, wRead m tbl idx = 0) →
    (∀ tbl idx, rRead m tbl idx = 0) →
    EncJobs (DynamicPointSet.empty d) (PureServingState.empty d n p.H p.L p.B_scan) m
  hEncJobs_congr_not_0_26 : ∀ {P : DynamicPointSet d}
    {st : PureServingState d n p.H p.L p.B_scan P} {m m' : ArithRAMMemory},
    (∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, wRead m' tbl idx = wRead m tbl idx) →
    (∀ tbl, tbl ≠ 0 → tbl ≠ 26 → ∀ idx, rRead m' tbl idx = rRead m tbl idx) →
    EncJobs P st m → EncJobs P st m'
  hExecMid :
    ∀ {P : DynamicPointSet d} {op : DynamicUpdate d}
      {m_pre : ArithRAMMemory} {st₀ : PureServingState d n p.H p.L p.B_scan P}
      {mem_rt : ArithRAMMemory} {P' : DynamicPointSet d}
      {opH : ℕ} {uMap' : GhostUidMap d P'}
      {P_good₀ : Prop},
      (P_good₀ → st₀.AllCentersGood) →
      PostRouteContext p EncJobs P op m_pre st₀ mem_rt P' opH uMap' →
      RandExecBad (mkStepInput n P op) midStmt B_mid mem_rt
        (fun m_mid =>
          wRead m_mid 0 0 = wRead mem_rt 0 0 ∧
          ∃ st₁, CoupledServingState p EncJobs P' st₁ m_mid)
        (fun m_mid =>
          P_good₀ →
            ∃ st₁, CoupledServingState p EncJobs P' st₁ m_mid ∧ st₁.AllCentersGood)
        p_mid C_mid

def MiddleTickSplitSpec.to_fullPostRouteSpec
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (mid : MiddleTickSplitSpec cHpj cBase d n t δ p)
    (ans : AnswerStageSpec d n mid.T_max mid.M_box p) :
    FullPostRouteSpec cHpj cBase d n t δ p := by
  have hBox16 : 16 ≤ mid.M_box := (hp.routeBoxBounds hn mid.hBox_ge).2.1
  refine
    { EncJobs := mid.EncJobs
      postRouteStmt := .seq mid.midStmt ans.ansStmt
      T_max := mid.T_max
      M_box := mid.M_box
      B_post := mid.B_mid + p.D₀ * p.K₀ * p.M_bits
      C_post := mid.C_mid + p46AnsStageCost d n (3 * p.L + 2) p
      p_post := mid.p_mid + (p.D₀ : ℝ) * (2 * p.φ_ev)
      hT27 := mid.hT27
      hBox_ge := mid.hBox_ge
      hBoxSafe := .seq mid.hBoxSafe ans.hBoxSafe
      hp_budget := mid.hp_budget
      hEncJobs_empty := mid.hEncJobs_empty
      hExecPostRoute := ?_ }
  intro P op m_pre st₀ mem_rt P' opH uMap' P_good₀ hGood₀ ctx
  classical
  let inp := mkStepInput n P op
  refine RandExecBad.seq ctx.hpop_rt (mid.hExecMid hGood₀ ctx) ?_
  intro m_mid hpop_mid hSafe_mid
  rcases hSafe_mid with ⟨hw00_mid, hExSafe_mid⟩
  by_cases hExGood_mid : ∃ st₁, CoupledServingState p mid.EncJobs P' st₁ m_mid ∧ st₁.AllCentersGood
  · rcases hExGood_mid with ⟨st₁, hC₁, hGood_st₁⟩
    rcases hC₁.2.2.1.answer_hyps with ⟨hk_le, hw_cL, hw_card, hLive, hSeg0, leafS, hw_leaf, hSegLeaf, hsn_dict⟩
    rcases st₁.answer_hyps hp hC₁.2.1 with ⟨hleaf_le, hbij_H, hbij_U, hmc_gen, hGoodChain⟩
    have hAns := (ans.hExecAns (P_good := True) inp m_mid st₁.nodes hpop_mid ctx.hP'_wf
      hk_le hw_cL hw_card hw_leaf hleaf_le hBox16 hLive hSeg0 hSegLeaf hsn_dict
      hbij_H hbij_U hp.hK0_ge1 hp.hφ0 hp.hbias_base hmc_gen (fun _ => hGoodChain hGood_st₁)).with_popDepth
    refine hAns.mono ?_ ?_ le_rfl le_rfl
    · intro m_out ⟨hpop_out, hw00_ans, hw_ans, hr_ans⟩
      have hChain_out := hC₁.2.2.1.congr_not_0_26 hw_ans hr_ans
      have hJobs_out := mid.hEncJobs_congr_not_0_26 hw_ans hr_ans hC₁.2.2.2
      exact ⟨hw00_ans.trans hw00_mid, st₁, ⟨hpop_out, hC₁.2.1, hChain_out, hJobs_out⟩⟩
    · intro m_out ⟨hpop_out, _, hw_ans, hr_ans⟩ hAnsValid _ _
      have hChain_out := hC₁.2.2.1.congr_not_0_26 hw_ans hr_ans
      have hJobs_out := mid.hEncJobs_congr_not_0_26 hw_ans hr_ans hC₁.2.2.2
      exact ⟨hAnsValid trivial, st₁, ⟨hpop_out, hC₁.2.1, hChain_out, hJobs_out⟩, hGood_st₁⟩
  · rcases hExSafe_mid with ⟨st₁, hC₁⟩
    rcases hC₁.2.2.1.answer_hyps with ⟨hk_le, hw_cL, hw_card, hLive, hSeg0, leafS, hw_leaf, hSegLeaf, hsn_dict⟩
    rcases st₁.answer_hyps hp hC₁.2.1 with ⟨hleaf_le, hbij_H, hbij_U, hmc_gen, _⟩
    have hAns := (ans.hExecAns (P_good := False) inp m_mid st₁.nodes hpop_mid ctx.hP'_wf
      hk_le hw_cL hw_card hw_leaf hleaf_le hBox16 hLive hSeg0 hSegLeaf hsn_dict
      hbij_H hbij_U hp.hK0_ge1 hp.hφ0 hp.hbias_base hmc_gen (fun hf => False.elim hf)).with_popDepth
    refine hAns.mono ?_ ?_ le_rfl le_rfl
    · intro m_out ⟨hpop_out, hw00_ans, hw_ans, hr_ans⟩
      have hChain_out := hC₁.2.2.1.congr_not_0_26 hw_ans hr_ans
      have hJobs_out := mid.hEncJobs_congr_not_0_26 hw_ans hr_ans hC₁.2.2.2
      exact ⟨hw00_ans.trans hw00_mid, st₁, ⟨hpop_out, hC₁.2.1, hChain_out, hJobs_out⟩⟩
    · intro _ _ _ hImp hPG₀
      exact False.elim (hExGood_mid (hImp hPG₀))

def MiddleTickSplitSpec.to_stepSimSpec
    {cHpj cBase d n t : ℕ} {δ : ℝ} {p : P46Params d n}
    (hp : P46ParamsValid cHpj cBase d n t δ p)
    (hn : 2 ≤ n)
    (mid : MiddleTickSplitSpec cHpj cBase d n t δ p)
    (ans : AnswerStageSpec d n mid.T_max mid.M_box p) :
    StepSimSpec d n t δ :=
  (mid.to_fullPostRouteSpec hp hn ans).to_stepSimSpec hp hn

/-! ### 5. Top-Level Horizon & Polynomial Endpoint Bridges to `UL.S_lem_7_2` -/

theorem prove_S_lem_7_2_of_fullPostRouteSpec
    (h_fb : S_clm_7_3_failure_budget)
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    (C_cap C_post_poly C_box_poly : ℕ)
    (hBuild : ∀ (d n t : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        C_cap * (D ^ 4 * H ^ 2) < n →
        ∀ (p : P46Params d n),
          P46ParamsValid cHpj (extractCBaseNat h_mc) d n t δ p →
          ∃ spec : FullPostRouteSpec cHpj (extractCBaseNat h_mc) d n t δ p,
            spec.C_post ≤ C_post_poly * (D ^ 19 * H ^ 18) ∧
            spec.T_max * spec.M_box ≤ C_box_poly * n * (D ^ 19 * H ^ 18)) :
    S_lem_7_2 := by
  let Cu_main := 1050250 + C_post_poly
  refine prove_S_lem_7_2_of_conditional_stepSimSpec h_fb C_cap Cu_main C_box_poly ?_
  intro d n t hd1 hn ht δ hδ0 hδ1 D H hcap
  let cBase : ℕ := extractCBaseNat h_mc
  rcases exists_valid_p46Params h_mc hcHpj (rfl : cBase = extractCBaseNat h_mc) hn ht hδ0 hδ1
    with ⟨p, hp⟩
  rcases hBuild d n t hd1 hn ht δ hδ0 hδ1 hcap p hp with ⟨spec, hCpost, hBox⟩
  have hPref : stepBootAndRouteCost d p ≤ 1050250 * (D ^ 19 * H ^ 18) :=
    hp.stepBootAndRouteCost_poly_le hn
  refine ⟨spec.to_stepSimSpec hp hn, ?_, hBox⟩
  change stepBootAndRouteCost d p + spec.C_post ≤ (1050250 + C_post_poly) * (D ^ 19 * H ^ 18)
  calc stepBootAndRouteCost d p + spec.C_post
      ≤ 1050250 * (D ^ 19 * H ^ 18) + C_post_poly * (D ^ 19 * H ^ 18) := Nat.add_le_add hPref hCpost
    _ = (1050250 + C_post_poly) * (D ^ 19 * H ^ 18) := by ring

theorem prove_S_lem_7_2_of_middleTickSplitSpec
    (h_fb : S_clm_7_3_failure_budget)
    (h_mc : S_clm_5_1_mc_baseline)
    {cHpj : ℕ} (hcHpj : (2 : ℝ) ^ 80 ≤ (cHpj : ℝ))
    (C_cap C_mid_poly C_box_poly : ℕ)
    (hBuild : ∀ (d n t : ℕ), 1 ≤ d → 2 ≤ n → 1 ≤ t →
      ∀ (δ : ℝ), 0 < δ → δ < 1 / 2 →
        let D : ℕ := d + 3
        let H : ℕ := Nat.ceil (Real.logb 2 ((2 * (D : ℝ) * (n : ℝ) * (t : ℝ)) / δ))
        C_cap * (D ^ 4 * H ^ 2) < n →
        ∀ (p : P46Params d n),
          P46ParamsValid cHpj (extractCBaseNat h_mc) d n t δ p →
          ∃ (mid : MiddleTickSplitSpec cHpj (extractCBaseNat h_mc) d n t δ p)
            (_ans : AnswerStageSpec d n mid.T_max mid.M_box p),
            mid.C_mid ≤ C_mid_poly * (D ^ 19 * H ^ 18) ∧
            mid.T_max * mid.M_box ≤ C_box_poly * n * (D ^ 19 * H ^ 18)) :
    S_lem_7_2 := by
  let cBase : ℕ := extractCBaseNat h_mc
  let C_ans_poly := p46AnsPolyConst cHpj cBase
  refine prove_S_lem_7_2_of_fullPostRouteSpec h_fb h_mc hcHpj C_cap (C_mid_poly + C_ans_poly) C_box_poly ?_
  intro d n t hd1 hn ht δ hδ0 hδ1 D H hcap p hp
  rcases hBuild d n t hd1 hn ht δ hδ0 hδ1 hcap p hp with ⟨mid, ans, hCmid, hBox⟩
  have hCans : p46AnsStageCost d n (3 * p.L + 2) p ≤ C_ans_poly * (D ^ 19 * H ^ 18) :=
    hp.ansStageCost_poly_le hn
  refine ⟨mid.to_fullPostRouteSpec hp hn ans, ?_, hBox⟩
  change mid.C_mid + p46AnsStageCost d n (3 * p.L + 2) p ≤ (C_mid_poly + C_ans_poly) * (D ^ 19 * H ^ 18)
  calc mid.C_mid + p46AnsStageCost d n (3 * p.L + 2) p
      ≤ C_mid_poly * (D ^ 19 * H ^ 18) + C_ans_poly * (D ^ 19 * H ^ 18) := Nat.add_le_add hCmid hCans
    _ = (C_mid_poly + C_ans_poly) * (D ^ 19 * H ^ 18) := by ring

end UL.Proof_lem_7_2_RacerP46
