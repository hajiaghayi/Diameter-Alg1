import UL.Proof.lem_7_2.CG14_MidTickA1a

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Phase-2 Residual Slot Extractor & `ActivePropBuildState` -/

lemma encJobLevel_phase2_resSlots {d n D K NumSlots : ℕ} {mem : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {idx : ℕ} {lv : JobLvData d} {S_parent : Finset ℕ} {spLive : Bool}
    (hEnc : EncJobLevel d n D K NumSlots mem activeH livePts idx lv.S_birth lv.snapPts lv.prov S_parent spLive)
    (hph2 : wRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2) :
    ∃ (rS spRS : ℕ),
      rS < NumSlots ∧ spRS < NumSlots ∧ rS ≠ spRS ∧
      wRead mem 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ) ∧
      wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ) ∧
      wRead mem 6 (rS : ℤ) = 0 ∧
      (wRead mem 6 (spRS : ℤ) = 0 ↔ spLive = true) ∧
      EncSegSlot K mem rS ((lv.ball D).residual livePts S_parent) (fun _ => 0) ∧
      (spLive = true → EncSegSlot K mem spRS ((lv.ball D).residual livePts S_parent) (fun _ => 0)) := by
  rcases hEnc with ⟨_, _, _, rS, spRS, _, _, _, hrS_lt, hspRS_lt,
    _, _, _, _, _, _, _, _, _, hrspR,
    _, _, _, hw_rS, hw_spRS, _, _, _, h6_rS, h6_spRS, _, _, _, _, _, hPh⟩
  rcases hPh with ⟨_, _, hp0, _⟩ | ⟨_, _, hp1, _⟩ | ⟨_, _, _, _, hEr, hEspR⟩
  · rw [hph2] at hp0; omega
  · rw [hph2] at hp1; omega
  · unfold JobLvData.ball
    exact ⟨rS, spRS, hrS_lt, hspRS_lt, hrspR, hw_rS, hw_spRS, h6_rS, h6_spRS, hEr, hEspR⟩

lemma cg14_prev_idx_props {jLen len : ℕ} (hpos : 1 ≤ jLen) (hne1 : jLen ≠ 1) (hlen : len = jLen) :
    jLen - 2 < len ∧
    jLen - 2 + 1 < len ∧
    jLen - 1 = (jLen - 2) + 1 ∧
    jLen - 2 ≠ jLen - 1 := by
  omega

lemma cg14_last_eq_len {jLen len : ℕ} (hpos : 1 ≤ jLen) (hlen : len = jLen) :
    decide ((jLen - 1) + 1 = len) = true ∧ (jLen - 1) + 1 = len := by
  simp only [decide_eq_true_eq]; omega

lemma cg14_ne_pred_of_succ_lt {j len jLen : ℕ} (h : j + 1 < len) (hlen : len = jLen) :
    j ≠ jLen - 1 := by
  omega

lemma MidLoopCtx.zero_lt_NumSlots (ctx : MidLoopCtx) : 0 < ctx.p.NumSlots :=
  lt_of_lt_of_le (by positivity : 0 < 8 * (ctx.p.D₀ + 2) ^ 2) ctx.hSlots_cap

/-- Packaged postcondition of `propAndBuildActiveJobStmt` on serving node `i < ctx.st₀.k`. -/
structure ActivePropBuildState (ctx : MidLoopCtx) (gFlag : Bool)
    (i : ℕ) (hi : i < ctx.st₀.k)
    (g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩))
    (m₁ : ArithRAMMemory) : Prop where
  hpop : m₁.popDepth 0 = m₁
  hw27 : wRead m₁ 26 27 = 0
  hGood₀ : gFlag = true → ∀ r : Fin ctx.st₀.k,
    IsCenterpoint (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2))
      (paraboloidLiftSet (fun u : ↥(ctx.st₀.birthSnap r) => ctx.st₀.uMap.ghostCoords u.1))
      (liftedPoint (ctx.st₀.nodes r).o ((ctx.st₀.nodes r).V + ‖(ctx.st₀.nodes r).o‖ ^ 2))
  hSeg : SegGenBound ctx.p.K_seg ctx.p.NumSlots m₁
  hSave : SaveGenBound ctx.n ctx.p.NumSlots m₁
  hLive : EncLiveCoords ctx.d ctx.n m₁ ctx.P'.activeHandles ctx.P'.handleCoords
  hw1_5 : wRead m₁ 1 5 = (ctx.st₀.k : ℤ)
  hw6_0 : wRead m₁ 6 0 = 0
  hSeg0 : EncSegSlot ctx.p.K_seg m₁ 0 ctx.P'.activeHandles (fun _ => 0)
  hChainRest :
    ∃ leafS : ℕ,
      0 < leafS ∧ leafS < ctx.p.NumSlots ∧
      wRead m₁ 1 6 = (leafS : ℤ) ∧
      wRead m₁ 6 (leafS : ℤ) = 0 ∧
      EncSegSlot ctx.p.K_seg m₁ leafS
        (chainTerminal ctx.P'.handleCoords ctx.st₀.nodes ctx.P'.activeHandles) (fun _ => 0) ∧
      GlobalSlotDisj ctx.p.D₀ m₁ ctx.st₀.k leafS
  hDone : ∀ (r : Fin ctx.st₀.k), r.val < i →
    ∃ oj : Option (ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
        ctx.uMap'.nextUid ctx.uMap'.ghostCoords (ctx.S_post_u r)),
      ServingOwnedJobInv (ctx.st₀.birthSnap r) (ctx.snAge' r) oj ∧
      (gFlag = true → ∀ g, oj = some g → JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g.lvs) ∧
      EncNodeHeaderAt ctx.cfg ctx.p m₁ ctx.P' r.val (ctx.st₀.nodes r)
        (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) oj.isNone ∧
      EncOwnedJobAt ctx.cfg ctx.p m₁ ctx.P' ctx.uMap' r.val (ctx.S_post_h r) (ctx.S_post_u r) oj
  hTodoGt : ∀ (r : Fin ctx.st₀.k), i < r.val →
    wRead m₁ ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r.val : ℤ) =
      (if ctx.aff r.castSucc then 1 else 0) ∧
    EncNodeHeaderAt ctx.cfg ctx.p m₁ ctx.P' r.val (ctx.st₀.nodes r)
      (ctx.st₀.birthSnap r).card (ctx.snAge' r) (ctx.S_post_h r) (ctx.st₀.ownedJob r).isNone ∧
    (gFlag = true → ∀ g, ctx.st₀.ownedJob r = some g →
      JobLevelsCenterGood (ctx.d + 3) ctx.st₀.uMap.ghostCoords g.lvs) ∧
    EncTodoJobAt ctx m₁ r
  hHdr_i : EncNodeHeaderAt ctx.cfg ctx.p m₁ ctx.P' i (ctx.st₀.nodes ⟨i, hi⟩)
    (ctx.st₀.birthSnap ⟨i, hi⟩).card (ctx.snAge' ⟨i, hi⟩) (ctx.S_post_h ⟨i, hi⟩) false
  hGood_i : gFlag = true → JobLevelsCenterGood (ctx.d + 3) ctx.st₀.uMap.ghostCoords g₀.lvs
  hw16_i : wRead m₁ 16 (i : ℤ) = 1
  hwRem_i : wRead m₁ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) = (((g₀.H_job - g₀.t_cur : ℕ) : ℤ))
  hwCl_i : wRead m₁ ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx i : ℤ) = (if g₀.closed then 1 else 0)
  hw19_i : wRead m₁ 19 (i : ℤ) = (g₀.lvs.length : ℤ)
  hJob_i :
    ∃ (lvs_h : List (JobLvData ctx.d)) (hlen_eq : lvs_h.length = g₀.lvs.length) (ph' scan' : ℕ),
      let lastIdx := i * ctx.p.D₀ + (g₀.lvs.length - 1)
      let Spar_last_h' := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) (g₀.lvs.length - 1)
      ph' ≤ 2 ∧
      wRead m₁ 24 (((2 * lastIdx + 0 : ℕ) : ℤ)) = (ph' : ℤ) ∧
      wRead m₁ 24 (((2 * lastIdx + 1 : ℕ) : ℤ)) = (scan' : ℤ) ∧
      (∀ (j : ℕ) (hj : j < lvs_h.length),
        let idx := i * ctx.p.D₀ + j
        let hj_g : j < g₀.lvs.length := hlen_eq ▸ hj
        (lvs_h[j]'hj).ball (ctx.d + 3) = (g₀.lvs[j]'hj_g).ball ∧
        (lvs_h[j]'hj).openRem = g₀.openRem j ∧
        (∃ (f_b g_b : ℕ → ℕ),
          (∀ h ∈ (lvs_h[j]'hj).S_birth,
            f_b h ∈ (g₀.lvs[j]'hj_g).birthSnapshot ∧
            ctx.uMap'.ghostCoords (f_b h) = (lvs_h[j]'hj).snapPts h ∧
            g_b (f_b h) = h) ∧
          (∀ u ∈ (g₀.lvs[j]'hj_g).birthSnapshot,
            g_b u ∈ (lvs_h[j]'hj).S_birth ∧
            f_b (g_b u) = u)) ∧
        EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₁
          ctx.P'.activeHandles ctx.P'.handleCoords idx
          (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
          (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) j)
          (decide (j + 1 = lvs_h.length)) ∧
        wRead m₁ 23 (((8 * idx + 7 : ℕ) : ℤ)) = (g₀.openRem j : ℤ) ∧
        0 < (wRead m₁ 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat ∧
        0 < (wRead m₁ 23 (((8 * idx + 3 : ℕ) : ℤ))).toNat ∧
        0 < (wRead m₁ 23 (((8 * idx + 4 : ℕ) : ℤ))).toNat ∧
        0 < (wRead m₁ 23 (((8 * idx + 5 : ℕ) : ℤ))).toNat ∧
        0 < (wRead m₁ 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat ∧
        (j + 1 < lvs_h.length → wRead m₁ 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2)) ∧
      (Spar_last_h'.card ≤ g₀.Spar_last_h.card + 1 ∧
        ∀ c : ℕ, (Spar_last_h'.filter (fun x => c ≤ x)).card ≤
                 (g₀.Spar_last_h.filter (fun x => c ≤ x)).card + 1) ∧
      (let m_last := (g₀.lvs[g₀.lvs.length - 1]'(Nat.sub_lt g₀.hlvs_pos Nat.one_pos)).birthSnapshot.card
       (g₀.ph_cur = 0 →
         (g₀.scan_cur + (ctx.p.B_scan + 1) < m_last → ph' = 0 ∧ scan' = g₀.scan_cur + (ctx.p.B_scan + 1)) ∧
         (m_last ≤ g₀.scan_cur + (ctx.p.B_scan + 1) → ph' = 1 ∧ scan' = 0)) ∧
       (g₀.ph_cur = 1 →
         ph' = 2 ∨
         (ph' = 1 ∧
           (Spar_last_h'.filter (fun x => scan' ≤ x)).card + ctx.p.B_scan ≤
             (g₀.Spar_last_h.filter (fun x => g₀.scan_cur ≤ x)).card)) ∧
       (g₀.ph_cur = 2 → ph' = 2))

end UL.Proof_lem_7_2_RacerP46
