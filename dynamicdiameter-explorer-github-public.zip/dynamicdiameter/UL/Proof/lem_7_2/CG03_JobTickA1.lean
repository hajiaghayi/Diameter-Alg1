import UL.Proof.lem_7_2.CG03_JobTickA0b
import UL.Proof.lem_7_2.CG01_ServingSchedA

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. `DetExecAt.unique_mem` & Parameterized Header Config (`HdrField`, `ChainHdrCfg`) -/

theorem DetExecAt.unique_mem {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {mem m₁ m₂ : ArithRAMMemory} {C₁ C₂ : ℕ}
    (h₁ : DetExecAt 0 inp s mem m₁ C₁)
    (h₂ : DetExecAt 0 inp s mem m₂ C₂)
    (hp₁ : m₁.popDepth 0 = m₁)
    (hp₂ : m₂.popDepth 0 = m₂) :
    m₁ = m₂ := by
  rcases h₁ [] 0 0 [] with ⟨f₁, u₁, pk₁, _, hs₁⟩
  rcases h₂ [] 0 0 [] with ⟨f₂, u₂, pk₂, _, hs₂⟩
  have e₁ := hs₁ f₂
  have e₂ := hs₂ f₁
  simp only [runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, hp₁] at e₁
  simp only [runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, hp₂] at e₂
  rw [Nat.add_comm f₁ f₂, e₂] at e₁
  injection e₁ with ho
  exact (congrArg ArithRAMExecOutcome.mem ho).symm

structure HdrField : Type where
  tag : ℕ
  stride : ℕ := 1
  off : ℕ := 0

def HdrField.idx (f : HdrField) (r : ℕ) : ℕ := f.stride * r + f.off

def HdrField.idxE (f : HdrField) (rE : IntExpr) : IntExpr :=
  .add (.mul (.lit (f.stride : ℤ)) rE) (.lit (f.off : ℤ))

def HdrField.readE (f : HdrField) (rE : IntExpr) : IntExpr :=
  .readHeap f.tag (f.idxE rE)

def HdrField.readRealE (f : HdrField) (rE : IntExpr) : RealExpr :=
  .readRealHeap f.tag (f.idxE rE)

def HdrField.writeW (f : HdrField) (M_box : ℕ) (rE valE : IntExpr) : ArithRAMStmt :=
  boxWriteW M_box f.tag (f.idxE rE) valE

def HdrField.writeR (f : HdrField) (M_box : ℕ) (rE : IntExpr) (valE : RealExpr) : ArithRAMStmt :=
  boxWriteR M_box f.tag (f.idxE rE) valE

def HdrField.WF (T_max : ℕ) (f : HdrField) : Prop :=
  f.tag < T_max ∧ 1 ≤ f.stride ∧ f.off < f.stride

def HdrField.Disj (f₁ f₂ : HdrField) : Prop :=
  f₁.tag ≠ f₂.tag ∨ (f₁.stride = f₂.stride ∧ f₁.off ≠ f₂.off)

lemma HdrField.Disj.symm {f₁ f₂ : HdrField} (h : HdrField.Disj f₁ f₂) : HdrField.Disj f₂ f₁ := by
  rcases h with ht | ⟨hs, ho⟩
  · exact Or.inl ht.symm
  · exact Or.inr ⟨hs.symm, ho.symm⟩

lemma HdrField.ne_cell {T_max : ℕ} {f₁ f₂ : HdrField}
    (h1 : f₁.WF T_max) (h2 : f₂.WF T_max) (hd : HdrField.Disj f₁ f₂) (r₁ r₂ : ℕ) :
    f₁.tag ≠ f₂.tag ∨ ((f₁.idx r₁ : ℤ) ≠ (f₂.idx r₂ : ℤ)) := by
  rcases hd with ht | ⟨hs, ho⟩
  · exact Or.inl ht
  · right
    intro heq
    have hnat : f₁.stride * r₁ + f₁.off = f₂.stride * r₂ + f₂.off := by
      unfold HdrField.idx at heq; exact_mod_cast heq
    rw [← hs] at hnat
    have hm : (f₁.stride * r₁ + f₁.off) % f₁.stride = (f₁.stride * r₂ + f₂.off) % f₁.stride :=
      congrArg (· % f₁.stride) hnat
    rw [Nat.mul_add_mod, Nat.mul_add_mod, Nat.mod_eq_of_lt h1.2.2,
      Nat.mod_eq_of_lt (hs ▸ h2.2.2)] at hm
    exact ho hm

lemma HdrField.ne_same_field {T_max : ℕ} {f : HdrField} (hf : f.WF T_max)
    {r₁ r₂ : ℕ} (hne : r₁ ≠ r₂) :
    (f.idx r₁ : ℤ) ≠ (f.idx r₂ : ℤ) := by
  intro heq
  have hnat : f.stride * r₁ + f.off = f.stride * r₂ + f.off := by
    unfold HdrField.idx at heq; exact_mod_cast heq
  have hm : f.stride * r₁ = f.stride * r₂ := by omega
  exact hne (Nat.eq_of_mul_eq_mul_left hf.2.1 hm)

theorem boxSafe_hdrWriteW {T_max M_box : ℕ} {f : HdrField} (hf : f.tag < T_max)
    (rE valE : IntExpr) :
    BoxSafeOuter T_max M_box (f.writeW M_box rE valE) :=
  BoxSafeOuter.boxW hf _ _

theorem boxSafe_hdrWriteR {T_max M_box : ℕ} {f : HdrField} (hf : f.tag < T_max)
    (rE : IntExpr) (valE : RealExpr) :
    BoxSafeOuter T_max M_box (f.writeR M_box rE valE) :=
  BoxSafeOuter.boxR hf _ _

theorem exec_hdrWriteW {d M_box : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (f : HdrField) (rE valE : IntExpr) {r : ℕ} {val : ℤ} {C : ℕ}
    (hr : iValAt 0 inp mem rE = (r : ℤ))
    (hidx_lt : f.idx r < M_box)
    (hval : iValAt 0 inp mem valE = val)
    (hC : 3 * intExprOps rE + intExprOps valE + 18 ≤ C) :
    DetExecAt 0 inp (f.writeW M_box rE valE) mem (wWrite mem f.tag (f.idx r : ℤ) val) C := by
  unfold HdrField.writeW
  refine exec_boxWriteW inp mem (f.idxE rE) valE ?_ (by positivity) (by exact_mod_cast hidx_lt) hval ?_
  · simp [HdrField.idxE, HdrField.idx, hr]
  · dsimp [HdrField.idxE, intExprOps]; omega

theorem exec_hdrWriteR {d M_box : ℕ} (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (f : HdrField) (rE : IntExpr) (valE : RealExpr) {r : ℕ} {val : ℝ} {C : ℕ}
    (hr : iValAt 0 inp mem rE = (r : ℤ))
    (hidx_lt : f.idx r < M_box)
    (hval : rValAt 0 inp mem valE = val)
    (hC : 3 * intExprOps rE + realExprOps valE + 18 ≤ C) :
    DetExecAt 0 inp (f.writeR M_box rE valE) mem (rWrite mem f.tag (f.idx r : ℤ) val) C := by
  unfold HdrField.writeR
  refine exec_boxWriteR inp mem (f.idxE rE) valE ?_ (by positivity) (by exact_mod_cast hidx_lt) hval ?_
  · simp [HdrField.idxE, HdrField.idx, hr]
  · dsimp [HdrField.idxE, intExprOps]; omega

structure ChainHdrCfg : Type where
  snBirthCard : HdrField := { tag := 12 }
  snAge : HdrField := { tag := 13 }
  snAffected : HdrField := { tag := 20 }
  jobRem : HdrField := { tag := 17 }
  jobClosed : HdrField := { tag := 18 }
  rSnCenterO : ℕ := 12
  rSnCenterV : HdrField := { tag := 13 }
  stepOpHTag : ℕ := 26
  stepOpHIdx : ℤ := 4
  stepInsTag : ℕ := 26
  stepInsIdx : ℤ := 5

def defaultChainHdrCfg : ChainHdrCfg := {}

def reservedWordTags : Finset ℕ :=
  {0, 1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 14, 15, 16, 19, 23, 24, 26}

def reservedRealTags : Finset ℕ :=
  {0, 4, 8, 11, 23, 24, 26, 27}

def ChainHdrCfg.Valid (T_max : ℕ) (cfg : ChainHdrCfg) : Prop :=
  28 ≤ T_max ∧
  cfg.snBirthCard.WF T_max ∧
  cfg.snAge.WF T_max ∧
  cfg.snAffected.WF T_max ∧
  cfg.jobRem.WF T_max ∧
  cfg.jobClosed.WF T_max ∧
  cfg.snBirthCard.tag ∉ reservedWordTags ∧
  cfg.snAge.tag ∉ reservedWordTags ∧
  cfg.snAffected.tag ∉ reservedWordTags ∧
  cfg.jobRem.tag ∉ reservedWordTags ∧
  cfg.jobClosed.tag ∉ reservedWordTags ∧
  HdrField.Disj cfg.snBirthCard cfg.snAge ∧
  HdrField.Disj cfg.snBirthCard cfg.snAffected ∧
  HdrField.Disj cfg.snBirthCard cfg.jobRem ∧
  HdrField.Disj cfg.snBirthCard cfg.jobClosed ∧
  HdrField.Disj cfg.snAge cfg.snAffected ∧
  HdrField.Disj cfg.snAge cfg.jobRem ∧
  HdrField.Disj cfg.snAge cfg.jobClosed ∧
  HdrField.Disj cfg.snAffected cfg.jobRem ∧
  HdrField.Disj cfg.snAffected cfg.jobClosed ∧
  HdrField.Disj cfg.jobRem cfg.jobClosed ∧
  cfg.rSnCenterO < T_max ∧
  cfg.rSnCenterV.WF T_max ∧
  cfg.rSnCenterO ≠ cfg.rSnCenterV.tag ∧
  cfg.rSnCenterO ∉ reservedRealTags ∧
  cfg.rSnCenterV.tag ∉ reservedRealTags

theorem valid_defaultChainHdrCfg {T_max : ℕ} (hT : 28 ≤ T_max) :
    defaultChainHdrCfg.Valid T_max := by
  refine ⟨hT, ⟨by dsimp [defaultChainHdrCfg]; omega, by decide, by decide⟩,
    ⟨by dsimp [defaultChainHdrCfg]; omega, by decide, by decide⟩,
    ⟨by dsimp [defaultChainHdrCfg]; omega, by decide, by decide⟩,
    ⟨by dsimp [defaultChainHdrCfg]; omega, by decide, by decide⟩,
    ⟨by dsimp [defaultChainHdrCfg]; omega, by decide, by decide⟩,
    by decide, by decide, by decide, by decide, by decide,
    Or.inl (by decide), Or.inl (by decide), Or.inl (by decide), Or.inl (by decide),
    Or.inl (by decide), Or.inl (by decide), Or.inl (by decide),
    Or.inl (by decide), Or.inl (by decide), Or.inl (by decide),
    by dsimp [defaultChainHdrCfg]; omega,
    ⟨by dsimp [defaultChainHdrCfg]; omega, by decide, by decide⟩,
    by decide, by decide, by decide⟩

def ChainHdrCfg.maxStride (cfg : ChainHdrCfg) : ℕ :=
  max cfg.snBirthCard.stride
    (max cfg.snAge.stride
      (max cfg.snAffected.stride
        (max cfg.jobRem.stride (max cfg.jobClosed.stride cfg.rSnCenterV.stride))))

lemma ChainHdrCfg.idx_lt_box {T_max D₀ M_box : ℕ} {cfg : ChainHdrCfg}
    (hV : cfg.Valid T_max) (hM : cfg.maxStride * D₀ ≤ M_box) {r : ℕ} (hr : r < D₀) :
    cfg.snBirthCard.idx r < M_box ∧
    cfg.snAge.idx r < M_box ∧
    cfg.snAffected.idx r < M_box ∧
    cfg.jobRem.idx r < M_box ∧
    cfg.jobClosed.idx r < M_box ∧
    cfg.rSnCenterV.idx r < M_box := by
  have h1 : cfg.snBirthCard.stride ≤ cfg.maxStride := le_max_left _ _
  have h2 : cfg.snAge.stride ≤ cfg.maxStride := le_trans (le_max_left _ _) (le_max_right _ _)
  have h3 : cfg.snAffected.stride ≤ cfg.maxStride :=
    le_trans (le_max_left _ _) (le_trans (le_max_right _ _) (le_max_right _ _))
  have h4 : cfg.jobRem.stride ≤ cfg.maxStride :=
    le_trans (le_max_left _ _) (le_trans (le_max_right _ _) (le_trans (le_max_right _ _) (le_max_right _ _)))
  have h5 : cfg.jobClosed.stride ≤ cfg.maxStride :=
    le_trans (le_max_left _ _) (le_trans (le_max_right _ _)
      (le_trans (le_max_right _ _) (le_trans (le_max_right _ _) (le_max_right _ _))))
  have h6 : cfg.rSnCenterV.stride ≤ cfg.maxStride :=
    le_trans (le_max_right _ _) (le_trans (le_max_right _ _)
      (le_trans (le_max_right _ _) (le_trans (le_max_right _ _) (le_max_right _ _))))
  have hbound : ∀ (f : HdrField), f.WF T_max → f.stride ≤ cfg.maxStride → f.idx r < M_box := by
    intro f hwf hst
    unfold HdrField.idx
    calc f.stride * r + f.off
        < f.stride * r + f.stride := Nat.add_lt_add_left hwf.2.2 _
      _ = f.stride * (r + 1) := by ring
      _ ≤ cfg.maxStride * D₀ := Nat.mul_le_mul hst (Nat.succ_le_of_lt hr)
      _ ≤ M_box := hM
  exact ⟨hbound _ hV.2.1 h1, hbound _ hV.2.2.1 h2, hbound _ hV.2.2.2.1 h3,
    hbound _ hV.2.2.2.2.1 h4, hbound _ hV.2.2.2.2.2.1 h5,
    hbound _ hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1 h6⟩

/-! ### 2. Pure Job Chain, Bijection & Centerpoint Helpers -/

lemma hpj_good_ball_centerpoint
    (h_lem_5_1 : S_lem_5_1) {d D : ℕ} (hD : 3 ≤ D)
    (snapPts ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S_h S_uid : Finset ℕ) (hS_pos : 0 < S_h.card)
    (uidOfH hOfUid : ℕ → ℕ)
    (hf : ∀ h ∈ S_h, uidOfH h ∈ S_uid ∧ ghostCoords (uidOfH h) = snapPts h ∧ hOfUid (uidOfH h) = h)
    (hg : ∀ u ∈ S_uid, hOfUid u ∈ S_h ∧ uidOfH (hOfUid u) = u)
    {bId : ℕ} (hb : bId ∈ S_h)
    (o_cand : EuclideanSpace ℝ (Fin d)) (s_cand : ℝ)
    (hcp : IsCenterpoint (1 / (4 * (D : ℝ) ^ 2))
      (paraboloidLiftSet (fun x : ↥S_h => snapPts x.1)) (liftedPoint o_cand s_cand)) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    let prov := provisionalCenter snapPts bId (.candidate o_cand (liftVariance o_cand s_cand))
    let ball := applyBirthCoreFallback α snapPts S_h prov
    ball = selectOpenedLevelBall α ghostCoords S_uid (uidOfH bId)
      (.candidate o_cand (liftVariance o_cand s_cand)) ∧
    IsCenterpoint α (paraboloidLiftSet (fun u : ↥S_uid => ghostCoords u.1))
      (liftedPoint ball.o (ball.V + ‖ball.o‖ ^ 2)) := by
  intro α prov ball
  have hball_eq := selectOpenedLevelBall_bij_uid α snapPts ghostCoords S_h S_uid
    uidOfH hOfUid hf hg hb o_cand s_cand
  have hcp_uid := centerpoint_paraboloid_bij_uid snapPts ghostCoords S_h S_uid uidOfH hOfUid hf hg _ hcp
  have hcard_uid : 1 ≤ S_uid.card := by
    rcases Finset.card_pos.mp hS_pos with ⟨x, hx⟩
    exact Finset.one_le_card.mpr ⟨uidOfH x, (hf x hx).1⟩
  have hα0 : 0 < α := (alpha_pos_and_lt_half D hD).1
  have hcp_sel := (selectOpenedLevelBall_centerpoint_of_hpj h_lem_5_1 hα0 ghostCoords
    hcard_uid (uidOfH bId) o_cand s_cand hcp_uid).2.2.2
  refine ⟨hball_eq, ?_⟩
  simpa only [← hball_eq] using hcp_sel

structure JobLvData (d : ℕ) : Type where
  S_birth : Finset ℕ
  snapPts : ℕ → EuclideanSpace ℝ (Fin d)
  prov : ChainNode d
  openRem : ℕ

noncomputable def JobLvData.ball {d : ℕ} (D : ℕ) (lv : JobLvData d) : ChainNode d :=
  applyBirthCoreFallback (1 / (4 * (D : ℝ) ^ 2)) lv.snapPts lv.S_birth lv.prov

noncomputable def jobHandleInput {d : ℕ} (D : ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d)) :
    List (JobLvData d) → Finset ℕ → ℕ → Finset ℕ
  | _, S_root, 0 => S_root
  | [], S_root, _ + 1 => S_root
  | lv :: rest, S_root, j + 1 =>
      jobHandleInput D livePts rest ((lv.ball D).residual livePts S_root) j

noncomputable def jobHandleResidual {d : ℕ} (D : ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d))
    (lvs : List (JobLvData d)) (S_root : Finset ℕ) : Finset ℕ :=
  jobHandleInput D livePts lvs S_root lvs.length

@[simp] lemma jobHandleInput_zero {d : ℕ} (D : ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d))
    (lvs : List (JobLvData d)) (S_root : Finset ℕ) :
    jobHandleInput D livePts lvs S_root 0 = S_root := by
  cases lvs <;> rfl

lemma nodeResidual_subset_self {d : ℕ} {ι : Type}
    (B : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) :
    B.residual pts S ⊆ S :=
  fun x hx => (mem_nodeResidual_iff_distSq_gt _ _ _ _ |>.mp hx).1

lemma jobHandleInput_succ {d : ℕ} (D : ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d)) :
    ∀ (lvs : List (JobLvData d)) (S_root : Finset ℕ) {j : ℕ} (hj : j < lvs.length),
      jobHandleInput D livePts lvs S_root (j + 1) =
        ((lvs[j]'hj).ball D).residual livePts (jobHandleInput D livePts lvs S_root j)
  | [], _, _x, hj => by simp at hj
  | lv :: rest, S_root, 0, _ => by simp [jobHandleInput]
  | lv :: rest, S_root, j + 1, hj => by
      simp only [List.length_cons, Nat.add_lt_add_iff_right] at hj
      exact jobHandleInput_succ D livePts rest ((lv.ball D).residual livePts S_root) hj

lemma jobHandleInput_append_le {d : ℕ} (D : ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d)) :
    ∀ (lvs extra : List (JobLvData d)) (S_root : Finset ℕ) {j : ℕ},
      j ≤ lvs.length →
      jobHandleInput D livePts (lvs ++ extra) S_root j = jobHandleInput D livePts lvs S_root j
  | _, _, _, 0, _ => by simp
  | [], _, _, _ + 1, hj => by simp at hj
  | lv :: rest, extra, S_root, j + 1, hj => by
      simp only [List.length_cons, Nat.add_le_add_iff_right] at hj
      exact jobHandleInput_append_le D livePts rest extra ((lv.ball D).residual livePts S_root) hj

lemma jobHandleInput_subset {d : ℕ} (D : ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d)) :
    ∀ (lvs : List (JobLvData d)) (S_root : Finset ℕ) (j : ℕ),
      jobHandleInput D livePts lvs S_root j ⊆ S_root
  | _, S_root, 0 => by simp
  | [], S_root, _ + 1 => Finset.Subset.refl S_root
  | lv :: rest, S_root, j + 1 =>
      (jobHandleInput_subset D livePts rest _ j).trans (nodeResidual_subset_self _ _ _)

lemma jobHandleInput_congr_on {d : ℕ} (D : ℕ)
    {livePts livePts' : ℕ → EuclideanSpace ℝ (Fin d)} :
    ∀ (lvs : List (JobLvData d)) {S_root : Finset ℕ}
      (_ : ∀ x ∈ S_root, livePts' x = livePts x) (j : ℕ),
      jobHandleInput D livePts' lvs S_root j = jobHandleInput D livePts lvs S_root j
  | _, _, _, 0 => by simp
  | [], _, _, _ + 1 => rfl
  | lv :: rest, S_root, hon, j + 1 => by
      have hres : (lv.ball D).residual livePts' S_root = (lv.ball D).residual livePts S_root :=
        nodeResidual_congr_on (lv.ball D) S_root hon
      dsimp only [jobHandleInput]; rw [hres]
      exact jobHandleInput_congr_on D rest
        (fun x hx => hon x (nodeResidual_subset_self _ _ _ hx)) j

lemma nodeResidual_bij_uid {d : ℕ} (B : ChainNode d)
    (livePts ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (S_h S_uid : Finset ℕ) (uidOfH hOfUid : ℕ → ℕ)
    (hf : ∀ h ∈ S_h, uidOfH h ∈ S_uid ∧ ghostCoords (uidOfH h) = livePts h ∧ hOfUid (uidOfH h) = h)
    (hg : ∀ u ∈ S_uid, hOfUid u ∈ S_h ∧ uidOfH (hOfUid u) = u) :
    (∀ h ∈ B.residual livePts S_h,
      uidOfH h ∈ B.residual ghostCoords S_uid ∧
      ghostCoords (uidOfH h) = livePts h ∧ hOfUid (uidOfH h) = h) ∧
    (∀ u ∈ B.residual ghostCoords S_uid,
      hOfUid u ∈ B.residual livePts S_h ∧ uidOfH (hOfUid u) = u) := by
  constructor
  · intro h hh
    rw [mem_nodeResidual_iff_distSq_gt] at hh ⊢
    exact ⟨⟨(hf h hh.1).1, by rw [(hf h hh.1).2.1]; exact hh.2⟩,
      (hf h hh.1).2.1, (hf h hh.1).2.2⟩
  · intro u hu
    rw [mem_nodeResidual_iff_distSq_gt] at hu ⊢
    have hgu := (hg u hu.1).1
    have hpt : livePts (hOfUid u) = ghostCoords u := by
      have h1 := (hf (hOfUid u) hgu).2.1; rw [(hg u hu.1).2] at h1; exact h1.symm
    exact ⟨⟨hgu, by rw [hpt]; exact hu.2⟩, (hg u hu.1).2⟩

lemma jobHandleInput_bij_prefixResidual {d : ℕ} (D : ℕ)
    (livePts ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (uidOfH hOfUid : ℕ → ℕ) :
    ∀ (lvs_h : List (JobLvData d)) (lvs_u : List (OpenedJobLevel d ℕ))
      (S_h S_uid : Finset ℕ)
      (hlen : lvs_h.length = lvs_u.length)
      (_ : ∀ (i : ℕ) (hi : i < lvs_h.length),
        (lvs_h[i]'hi).ball D = (lvs_u[i]'(hlen ▸ hi)).ball)
      (_ : ∀ h ∈ S_h, uidOfH h ∈ S_uid ∧ ghostCoords (uidOfH h) = livePts h ∧ hOfUid (uidOfH h) = h)
      (_ : ∀ u ∈ S_uid, hOfUid u ∈ S_h ∧ uidOfH (hOfUid u) = u)
      {j : ℕ} (hj : j ≤ lvs_h.length),
      let Th := jobHandleInput D livePts lvs_h S_h j
      let Tu := prefixResidual ghostCoords (lvs_u.take j) S_uid
      (∀ h ∈ Th, uidOfH h ∈ Tu ∧ ghostCoords (uidOfH h) = livePts h ∧ hOfUid (uidOfH h) = h) ∧
      (∀ u ∈ Tu, hOfUid u ∈ Th ∧ uidOfH (hOfUid u) = u) ∧
      Th.card = Tu.card
  | lvs_h, lvs_u, S_h, S_uid, _, _, hf, hg, 0, _hj => by
      simp only [jobHandleInput_zero, List.take_zero, prefixResidual]
      refine ⟨hf, hg, Finset.card_bij (fun h _ => uidOfH h) (fun h hh => (hf h hh).1) ?_ ?_⟩
      · intro x hx y hy heq
        have := congrArg hOfUid heq; rwa [(hf x hx).2.2, (hf y hy).2.2] at this
      · intro u hu; exact ⟨hOfUid u, (hg u hu).1, (hg u hu).2⟩
  | [], _, _, _, _, _, _, _, _ + 1, hj => by simp at hj
  | _ :: _, [], _, _, hlen, _, _, _, _ + 1, _ => by simp at hlen
  | lv_h :: rest_h, lv_u :: rest_u, S_h, S_uid, hlen, hballs, hf, hg, j + 1, hj => by
      simp only [List.length_cons, Nat.add_right_cancel_iff] at hlen
      simp only [List.length_cons, Nat.add_le_add_iff_right] at hj
      have hb0 : lv_h.ball D = lv_u.ball := hballs 0 (by simp)
      rcases nodeResidual_bij_uid (lv_h.ball D) livePts ghostCoords S_h S_uid uidOfH hOfUid hf hg
        with ⟨hf', hg'⟩
      rw [hb0] at hf' hg'
      dsimp only [jobHandleInput, List.take_succ_cons]
      have hp_cons : prefixResidual ghostCoords (lv_u :: rest_u.take j) S_uid =
          prefixResidual ghostCoords (rest_u.take j) (lv_u.ball.residual ghostCoords S_uid) := rfl
      rw [hp_cons, hb0]
      exact jobHandleInput_bij_prefixResidual D livePts ghostCoords uidOfH hOfUid
        rest_h rest_u _ _ hlen (fun i hi => hballs (i + 1) (Nat.succ_lt_succ hi)) hf' hg' hj

lemma activeSlotSet_card_add5_le {mem : ArithRAMMemory} {D₀ : ℕ}
    (hcL : (wRead mem 1 5).toNat ≤ D₀)
    (hjL : ∀ r < (wRead mem 1 5).toNat,
      wRead mem 16 (r : ℤ) = 1 → (wRead mem 19 (r : ℤ)).toNat ≤ D₀) :
    (activeSlotSet mem D₀).card + 5 ≤ 8 * (D₀ + 2) ^ 2 := by
  unfold activeSlotSet
  have hbi : (((Finset.range (wRead mem 1 5).toNat).biUnion
      (fun r => snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r)).card) ≤ D₀ * (2 + 5 * D₀) := by
    have h1 := Finset.card_biUnion_le (s := Finset.range (wRead mem 1 5).toNat)
      (t := fun r => snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r)
    have h2 : ∑ r ∈ Finset.range (wRead mem 1 5).toNat,
        (snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r).card ≤
        ∑ _r ∈ Finset.range (wRead mem 1 5).toNat, (2 + 5 * D₀) := by
      refine Finset.sum_le_sum (fun r hr => ?_)
      exact (Finset.card_union_le _ _).trans
        (Nat.add_le_add (snSlotSet_card_le mem r)
          (jobOwnedSlotSet_card_le mem D₀ r (hjL r (Finset.mem_range.mp hr))))
    rw [Finset.sum_const, Finset.card_range, smul_eq_mul] at h2
    exact h1.trans (h2.trans (Nat.mul_le_mul_right (2 + 5 * D₀) hcL))
  let U := (Finset.range (wRead mem 1 5).toNat).biUnion
    (fun r => snSlotSet mem r ∪ jobOwnedSlotSet mem D₀ r)
  have hins1 := Finset.card_insert_le 0 (insert (wRead mem 1 6).toNat U)
  have hins2 := Finset.card_insert_le (wRead mem 1 6).toNat U
  change (insert 0 (insert (wRead mem 1 6).toNat U)).card + 5 ≤ _
  change U.card ≤ _ at hbi
  nlinarith

def jobLevelLiveSlots (mem : ArithRAMMemory) (idx : ℕ) (spareResLive : Bool) : Finset ℕ :=
  let base : Finset ℕ :=
    { (wRead mem 23 (((8 * idx + 3 : ℕ) : ℤ))).toNat,
      (wRead mem 23 (((8 * idx + 4 : ℕ) : ℤ))).toNat,
      (wRead mem 23 (((8 * idx + 5 : ℕ) : ℤ))).toNat }
  if spareResLive then insert (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat base else base

lemma not_mem_jobLevelSlotSet_of_live_disj {d n D K NumSlots : ℕ} {mem : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {idx : ℕ} {S_birth S_parent : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d} {spareResLive : Bool} {s : ℕ}
    (hEnc : EncJobLevel d n D K NumSlots mem activeH livePts idx S_birth snapPts prov S_parent spareResLive)
    (hs_live : wRead mem 6 (s : ℤ) = 0)
    (hs_disj : s ∉ jobLevelLiveSlots mem idx spareResLive) :
    s ∉ jobLevelSlotSet mem idx := by
  rcases hEnc with ⟨bS, dS, spDS, rS, spRS, _, _, _, _, _,
    _, _, _, _, _, _, _, _, _, _,
    hw_bS, hw_dS, hw_spDS, hw_rS, hw_spRS,
    h6_bS, _, _, _, h6_spRS_iff, _⟩
  unfold jobLevelSlotSet
  rw [hw_bS, hw_dS, hw_spDS, hw_rS, hw_spRS]
  simp only [Int.toNat_natCast, Finset.mem_insert, Finset.mem_singleton, not_or]
  unfold jobLevelLiveSlots at hs_disj
  rw [hw_dS, hw_spDS, hw_rS, hw_spRS] at hs_disj
  simp only [Int.toNat_natCast] at hs_disj
  refine ⟨by intro h; subst h; omega, ?_⟩
  cases spareResLive with
  | true =>
      simp only [↓reduceIte, Finset.mem_insert, Finset.mem_singleton, not_or] at hs_disj
      exact ⟨hs_disj.2.1, hs_disj.2.2.1, hs_disj.2.2.2, hs_disj.1⟩
  | false =>
      simp only [Bool.false_eq_true, ↓reduceIte, Finset.mem_insert, Finset.mem_singleton, not_or] at hs_disj
      refine ⟨hs_disj.1, hs_disj.2.1, hs_disj.2.2, ?_⟩
      intro h; subst h
      exact absurd (h6_spRS_iff.mp hs_live) (by decide)

end UL.Proof_lem_7_2_RacerP46
