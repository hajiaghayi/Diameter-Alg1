import UL.Proof.lem_7_2.CG03_JobTickA0b

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Per-Update Node Baseline Refresh (`refreshAllBaselinesStmt`) -/

def refreshOneBaselineIterStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  seqList [
    .ite (.intLt (.readHeap 26 (.lit 15)) (.readHeap 1 (.lit 5)))
      (seqList [
        boxWriteW M_box 26 (.lit 0) (.lit 1),
        boxWriteW M_box 26 (.lit 1) (.readHeap 14 (.readHeap 26 (.lit 15)))
      ])
      (boxWriteW M_box 26 (.lit 0) (.lit 0)),
    runBaselineSlotStmt d n M_box p,
    boxWriteW M_box 26 (.lit 15) (.add (.readHeap 26 (.lit 15)) (.lit 1))
  ]

theorem boxSafe_refreshOneBaselineIterStmt {d n T_max M_box : ℕ}
    (hT : 27 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (refreshOneBaselineIterStmt d n M_box p) := by
  unfold refreshOneBaselineIterStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl
  · refine .ite _ (boxSafeOuter_seqList ?_) (.boxW (by omega) _ _)
    intro s' hs'; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs'
    rcases hs' with rfl | rfl <;> exact .boxW (by omega) _ _
  · exact boxSafe_runBaselineSlotStmt hT p
  · exact .boxW (by omega) _ _

def refreshAllBaselinesStmt (d n M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  seqList [
    boxWriteW M_box 26 (.lit 10) (.lit 0),
    boxWriteW M_box 26 (.lit 15) (.lit 0),
    .repeatN (.lit (p.D₀ : ℤ)) (refreshOneBaselineIterStmt d n M_box p)
  ]

theorem boxSafe_refreshAllBaselinesStmt {d n T_max M_box : ℕ}
    (hT : 27 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (refreshAllBaselinesStmt d n M_box p) := by
  unfold refreshAllBaselinesStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl
  · exact .boxW (by omega) _ _
  · exact .boxW (by omega) _ _
  · exact .repeatN _ (boxSafe_refreshOneBaselineIterStmt hT p)

def refreshAllBaselinesCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  p.D₀ * (baselineCallCost d n p + 120) + 100

private lemma chainInput_bij_uid {d k : ℕ}
    (hCoords ghostCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (ActiveH ActiveUids : Finset ℕ) (uidOfH hOfUid : ℕ → ℕ)
    (hf : ∀ h ∈ ActiveH, uidOfH h ∈ ActiveUids ∧ ghostCoords (uidOfH h) = hCoords h ∧ hOfUid (uidOfH h) = h)
    (hg : ∀ u ∈ ActiveUids, hOfUid u ∈ ActiveH ∧ uidOfH (hOfUid u) = u)
    (nodes : Fin k → ChainNode d) :
    ∀ (j : ℕ) (hj : j ≤ k),
      let Sh := chainInput hCoords nodes ActiveH ⟨j, Nat.lt_succ_of_le hj⟩
      let Su := chainInput ghostCoords nodes ActiveUids ⟨j, Nat.lt_succ_of_le hj⟩
      Sh ⊆ ActiveH ∧
      (∀ h ∈ Sh, uidOfH h ∈ Su ∧ ghostCoords (uidOfH h) = hCoords h ∧ hOfUid (uidOfH h) = h) ∧
      (∀ u ∈ Su, hOfUid u ∈ Sh ∧ uidOfH (hOfUid u) = u)
  | 0, _ => by
      have h0h : chainInput hCoords nodes ActiveH ⟨0, Nat.zero_lt_succ k⟩ = ActiveH := rfl
      have h0u : chainInput ghostCoords nodes ActiveUids ⟨0, Nat.zero_lt_succ k⟩ = ActiveUids := rfl
      dsimp only; rw [h0h, h0u]; exact ⟨Finset.Subset.refl _, hf, hg⟩
  | j + 1, hj => by
      have hj_lt : j < k := hj
      rcases chainInput_bij_uid hCoords ghostCoords ActiveH ActiveUids uidOfH hOfUid hf hg nodes j
          (le_of_lt hj_lt) with ⟨hsub_j, hfj, hgj⟩
      have hsh : chainInput hCoords nodes ActiveH ⟨j + 1, Nat.lt_succ_of_le hj⟩ =
          (nodes ⟨j, hj_lt⟩).residual hCoords (chainInput hCoords nodes ActiveH ⟨j, Nat.lt_succ_of_le (le_of_lt hj_lt)⟩) := rfl
      have hsu : chainInput ghostCoords nodes ActiveUids ⟨j + 1, Nat.lt_succ_of_le hj⟩ =
          (nodes ⟨j, hj_lt⟩).residual ghostCoords (chainInput ghostCoords nodes ActiveUids ⟨j, Nat.lt_succ_of_le (le_of_lt hj_lt)⟩) := rfl
      dsimp only; rw [hsh, hsu]
      refine ⟨(fun x hx => hsub_j ((mem_nodeResidual_iff_distSq_gt _ _ _ _ |>.mp hx).1)), ?_, ?_⟩
      · intro h hh
        rw [mem_nodeResidual_iff_distSq_gt] at hh ⊢
        exact ⟨⟨(hfj h hh.1).1, by rw [(hfj h hh.1).2.1]; exact hh.2⟩,
          (hfj h hh.1).2.1, (hfj h hh.1).2.2⟩
      · intro u hu
        rw [mem_nodeResidual_iff_distSq_gt] at hu ⊢
        have hgu := (hgj u hu.1).1
        have hpt : hCoords (hOfUid u) = ghostCoords u := by
          have h1 := (hfj (hOfUid u) hgu).2.1; rw [(hgj u hu.1).2] at h1; exact h1.symm
        exact ⟨⟨hgu, by rw [hpt]; exact hu.2⟩, (hgj u hu.1).2⟩

theorem exec_refreshAllBaselinesStmt {d n k M_box : ℕ}
    (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {P : DynamicPointSet d}
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {ActiveUids : Finset ℕ} {uidOfH hOfUid : ℕ → ℕ}
    (nodes : Fin k → ChainNode d)
    {P_good : Prop}
    (hpop₀ : mem.popDepth 0 = mem)
    (hP : P.WellFormed n)
    (hk_le : k ≤ p.D₀)
    (hw_cL : wRead mem 1 5 = (k : ℤ))
    (hBox : 16 ≤ M_box)
    (hLive : EncLiveCoords d n mem P.activeHandles P.handleCoords)
    (hsn_dict : ∀ i : Fin k, ∃ dS < p.NumSlots,
      wRead mem 14 (i.val : ℤ) = (dS : ℤ) ∧
      EncSegSlot p.K_seg mem dS
        (chainInput P.handleCoords nodes P.activeHandles i.castSucc)
        (fun x => euclideanDistSq (P.handleCoords x) (nodes i).o))
    (hbij_H : ∀ h ∈ P.activeHandles,
      uidOfH h ∈ ActiveUids ∧ ghostCoords (uidOfH h) = P.handleCoords h ∧ hOfUid (uidOfH h) = h)
    (hbij_U : ∀ u ∈ ActiveUids, hOfUid u ∈ P.activeHandles ∧ uidOfH (hOfUid u) = u)
    (hK0_pos : 1 ≤ p.K₀) (hφ0 : 0 < p.φ_ev)
    (hbias : ((p.K₀ : ℝ) * (n : ℝ)) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev)
    (hmc_gen : ∀ (pts : ℕ → EuclideanSpace ℝ (Fin d))
         (P₀ S₀ : Finset ℕ) (age : ℕ) (o : EuclideanSpace ℝ (Fin d)) (s_lift : ℝ)
         (y : ℕ) (farthest : (Fin p.K₀ → ℕ) → ℕ),
       1 ≤ P₀.card →
       IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
         (paraboloidLiftSet (fun i : ↥P₀ => pts i.1)) (liftedPoint o s_lift) →
       HasNodeAge P₀ S₀ age →
       (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀.card : ℝ) / 16 →
       IsNodeMaxRadiusPoint pts o S₀ y →
       let V := liftVariance o s_lift
       let samples := Fintype.piFinset (fun _ : Fin p.K₀ => S₀)
       (∀ samp ∈ samples,
         (∃ j : Fin p.K₀, farthest samp = samp j) ∧
         ∀ j : Fin p.K₀, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖) →
       (((open Classical in samples.filter (fun samp =>
           ¬ IsNodeBaselinePair pts o V S₀ y (farthest samp))).card : ℝ) /
         (samples.card : ℝ)) ≤ p.φ_ev)
    (hGoodChain : P_good → ∀ i : Fin k,
      ∃ (P₀_uid : Finset ℕ) (age : ℕ),
        1 ≤ P₀_uid.card ∧
        IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
          (paraboloidLiftSet (fun u : ↥P₀_uid => ghostCoords u.1))
          (liftedPoint (nodes i).o ((nodes i).V + ‖(nodes i).o‖ ^ 2)) ∧
        HasNodeAge P₀_uid (chainInput ghostCoords nodes ActiveUids i.castSucc) age ∧
        (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀_uid.card : ℝ) / 16) :
    RandExecBad inp (refreshAllBaselinesStmt d n M_box p) (p.D₀ * p.K₀ * p.M_bits) mem
      (fun m' =>
        BestCandInv P m' ∧
        (∀ t, t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
        (∀ t, t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx))
      (fun m' =>
        P_good →
          ∃ basePairs : Fin k → Option (ℕ × ℕ),
            (∀ i : Fin k,
              (nodes i).SatisfiesBaselineCond ghostCoords
                (chainInput ghostCoords nodes ActiveUids i.castSucc) (basePairs i)) ∧
            (∀ i : Fin k, ∀ u v : ℕ,
              basePairs i = some (u, v) → u ≠ v →
                wRead m' 26 10 = 1 ∧
                ‖ghostCoords u - ghostCoords v‖ ^ 2 ≤ rRead m' 26 10))
      ((p.D₀ : ℝ) * (2 * p.φ_ev))
      (refreshAllBaselinesCost d n p) := by
  classical
  have hact_le_n : P.activeHandles.card ≤ n := by
    rw [activeHandles_card_eq_activeIds_card hP]; exact hP.1
  let m1 := wWrite mem 26 10 0
  let m2 := wWrite m1 26 15 0
  have hm1_pop : m1.popDepth 0 = m1 := mem_writeWord_popDepth 0 hpop₀ rfl
  have hm2_pop : m2.popDepth 0 = m2 := mem_writeWord_popDepth 0 hm1_pop rfl
  have hd1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 10) (.lit 0)) mem m1 14 :=
    exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hd2 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 15) (.lit 0)) m1 m2 14 :=
    exec_boxWriteW inp m1 _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  let SafeI : ℕ → ArithRAMMemory → Prop := fun r m =>
    wRead m 26 15 = (r : ℤ) ∧
    BestCandInv P m ∧
    (∀ t, t ≠ 26 → ∀ idx, wRead m t idx = wRead mem t idx) ∧
    (∀ t, t ≠ 26 → ∀ idx, rRead m t idx = rRead mem t idx)
  let GoodI : ℕ → ArithRAMMemory → Prop := fun r m =>
    P_good → ∀ (i : Fin k), i.val < r →
      ∃ pair : Option (ℕ × ℕ),
        (nodes i).SatisfiesBaselineCond ghostCoords
          (chainInput ghostCoords nodes ActiveUids i.castSucc) pair ∧
        ∀ u v : ℕ, pair = some (u, v) → u ≠ v →
          wRead m 26 10 = 1 ∧ ‖ghostCoords u - ghostCoords v‖ ^ 2 ≤ rRead m 26 10
  have hSafe0 : SafeI 0 m2 :=
    ⟨by simp [m2], Or.inl (by simp [m2, m1]),
     fun t ht idx => by simp [m2, m1, ht], fun t _ idx => by simp [m2, m1]⟩
  have hGood0 : GoodI 0 m2 := fun _ i hi => by omega
  have hIter : ∀ r < p.D₀, ∀ m, m.popDepth 0 = m → SafeI r m →
      RandExecBad inp (refreshOneBaselineIterStmt d n M_box p) (p.K₀ * p.M_bits) m
        (SafeI (r + 1)) (fun m' => GoodI r m → GoodI (r + 1) m')
        (2 * p.φ_ev) (baselineCallCost d n p + 120) := by
    intro r _ m hpm ⟨hw15_m, hInv_m, hwo_m, hro_m⟩
    have hwcL_m : wRead m 1 5 = (k : ℤ) := by rw [hwo_m 1 (by decide), hw_cL]
    by_cases hr_lt : r < k
    · have hcond : cValAt 0 inp m (.intLt (.readHeap 26 (.lit 15)) (.readHeap 1 (.lit 5))) = true := by
        simp [hw15_m, hwcL_m, hr_lt]
      rcases hsn_dict ⟨r, hr_lt⟩ with ⟨dS, _, hw14_r, hSeg_r0⟩
      let ma1 := wWrite m 26 0 1
      let ma2 := wWrite ma1 26 1 (dS : ℤ)
      have hpa1 : ma1.popDepth 0 = ma1 := mem_writeWord_popDepth 1 hpm rfl
      have hpa2 : ma2.popDepth 0 = ma2 := mem_writeWord_popDepth (dS : ℤ) hpa1 rfl
      have hda1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 0) (.lit 1)) m ma1 14 :=
        exec_boxWriteW inp m _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
      have hda2 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 1) (.readHeap 14 (.readHeap 26 (.lit 15))))
          ma1 ma2 22 :=
        exec_boxWriteW inp ma1 _ _ rfl (by omega) (by omega)
          (by simp [ma1, hw15_m, hwo_m 14 (by decide), hw14_r]) (by simp [intExprOps])
      have hd_br : DetExecAt 0 inp
          (.ite (.intLt (.readHeap 26 (.lit 15)) (.readHeap 1 (.lit 5)))
            (seqList [boxWriteW M_box 26 (.lit 0) (.lit 1),
                      boxWriteW M_box 26 (.lit 1) (.readHeap 14 (.readHeap 26 (.lit 15)))])
            (boxWriteW M_box 26 (.lit 0) (.lit 0))) m ma2 50 :=
        (DetExecAt.ite_true hcond (C_c := 10) (by simp [condExprOps, intExprOps])
          (hda1.seq hda2)).mono_cost (by omega)
      have hInv_a2 : BestCandInv P ma2 :=
        hInv_m.congr_mem (by simp [ma2, ma1]) (by simp [ma2, ma1]) (by simp [ma2, ma1]) (by simp [ma2, ma1])
      have hLive_a2 : EncLiveCoords d n ma2 P.activeHandles P.handleCoords :=
        ⟨hLive.1, fun h hh c => by simp [ma2, ma1]; rw [hro_m 4 (by decide)]; exact hLive.2 h hh c⟩
      have hSeg_a2 : EncSegSlot p.K_seg ma2 dS
          (chainInput P.handleCoords nodes P.activeHandles (⟨r, hr_lt⟩ : Fin k).castSucc)
          (fun x => euclideanDistSq (P.handleCoords x) (nodes ⟨r, hr_lt⟩).o) :=
        hSeg_r0.congr_mem_fSq
          (by simp [ma2, ma1]; exact hwo_m 5 (by decide) _)
          (fun _ _ => by simp [ma2, ma1]; exact hwo_m 8 (by decide) _)
          (fun _ _ => by simp [ma2, ma1]; exact hwo_m 9 (by decide) _)
          (fun _ _ => by simp [ma2, ma1]; exact hwo_m 10 (by decide) _)
          (fun _ _ => by simp [ma2, ma1]; exact hro_m 8 (by decide) _) (fun _ _ => rfl)
      rcases chainInput_bij_uid P.handleCoords ghostCoords P.activeHandles ActiveUids
          uidOfH hOfUid hbij_H hbij_U nodes r (le_of_lt hr_lt) with ⟨hSr_sub, hf_r, hg_r⟩
      have hSr_le : (chainInput P.handleCoords nodes P.activeHandles (⟨r, hr_lt⟩ : Fin k).castSucc).card ≤ n :=
        (Finset.card_le_card hSr_sub).trans hact_le_n
      rcases exec_runBaselineSlotStmt_active (M_box := M_box) p inp ma2 (P_good := P_good)
          (by simp [ma2, ma1]) (by simp [ma2]) (by omega) hInv_a2 hLive_a2 hSr_sub hSr_le hSeg_a2
          hK0_pos hφ0 hbias hmc_gen hf_r hg_r (fun hG => hGoodChain hG ⟨r, hr_lt⟩)
        with ⟨PostB, BadB, _, hRB, hcardB, hpostB⟩
      have hBadB : RandExecBad inp (runBaselineSlotStmt d n M_box p) (p.K₀ * p.M_bits) ma2
          (fun m3 =>
            BestCandInv P m3 ∧
            (wRead m 26 10 = 1 → wRead m3 26 10 = 1 ∧ rRead m 26 10 ≤ rRead m3 26 10) ∧
            wRead m3 26 15 = (r : ℤ) ∧
            (∀ t, t ≠ 26 → ∀ idx, wRead m3 t idx = wRead mem t idx) ∧
            (∀ t, t ≠ 26 → ∀ idx, rRead m3 t idx = rRead mem t idx))
          (fun m3 =>
            P_good → ∃ pair : Option (ℕ × ℕ),
              (nodes ⟨r, hr_lt⟩).SatisfiesBaselineCond ghostCoords
                (chainInput ghostCoords nodes ActiveUids (⟨r, hr_lt⟩ : Fin k).castSucc) pair ∧
              ∀ u v : ℕ, pair = some (u, v) → u ≠ v →
                wRead m3 26 10 = 1 ∧ ‖ghostCoords u - ghostCoords v‖ ^ 2 ≤ rRead m3 26 10)
          (2 * p.φ_ev) (baselineCallCost d n p) := by
        refine ⟨by positivity, PostB, BadB, inferInstance, hRB, hcardB, fun bits m3 hp => ?_⟩
        rcases hpostB bits m3 hp with ⟨hp3, hI3, hmon3, hwo3, hw26_3, hro3, _, hg3⟩
        refine ⟨hp3, ⟨hI3, ?_, ?_, ?_, ?_⟩, fun hnb hG => hg3 hG hnb⟩
        · intro h10; simpa [ma2, ma1] using hmon3 (by simpa [ma2, ma1] using h10)
        · rw [hw26_3 15 (by decide) (by decide) (by decide)]; simp [ma2, ma1, hw15_m]
        · intro t ht idx; rw [hwo3 t ht]; simp [ma2, ma1, ht, hwo_m t ht idx]
        · intro t ht idx; rw [hro3 t ht]; simp [ma2, ma1, hro_m t ht idx]
      have hStep2 : RandExecBad inp
          (.seq (runBaselineSlotStmt d n M_box p)
                (boxWriteW M_box 26 (.lit 15) (.add (.readHeap 26 (.lit 15)) (.lit 1))))
          (p.K₀ * p.M_bits) ma2 (SafeI (r + 1)) (fun m4 => GoodI r m → GoodI (r + 1) m4)
          (2 * p.φ_ev) (baselineCallCost d n p + 20) := by
        refine RandExecBad.seq_det_right hpa2 hBadB ?_
        intro m3 hp3 ⟨hI3, hmon3, hw15_3, hwo3, hro3⟩
        let m4 := wWrite m3 26 15 (((r + 1 : ℕ) : ℤ))
        have hd_inc : DetExecAt 0 inp
            (boxWriteW M_box 26 (.lit 15) (.add (.readHeap 26 (.lit 15)) (.lit 1))) m3 m4 20 :=
          exec_boxWriteW inp m3 _ _ rfl (by omega) (by omega)
            (by simp [hw15_3]) (by simp [intExprOps])
        refine ⟨m4, hd_inc, mem_writeWord_popDepth _ hp3 rfl,
          ⟨by simp [m4],
           hI3.congr_mem (by simp [m4]) (by simp [m4]) (by simp [m4]) (by simp [m4]),
           fun t ht idx => by simp [m4, ht, hwo3 t ht],
           fun t ht idx => by simp [m4, hro3 t ht]⟩, ?_⟩
        intro hg3 hg_prev hG i hi_lt
        by_cases hi_eq : i.val = r
        · have hi_fin : i = ⟨r, hr_lt⟩ := Fin.ext hi_eq
          subst hi_fin
          rcases hg3 hG with ⟨pair, hcond_p, hb_p⟩
          refine ⟨pair, hcond_p, fun u v huv hne => ?_⟩
          rcases hb_p u v huv hne with ⟨h10, hle⟩
          exact ⟨by simp [m4, h10], by simpa [m4] using hle⟩
        · rcases hg_prev hG i (by omega) with ⟨pair, hcond_p, hb_p⟩
          refine ⟨pair, hcond_p, fun u v huv hne => ?_⟩
          rcases hb_p u v huv hne with ⟨h10, hle⟩
          rcases hmon3 h10 with ⟨h10', hmono⟩
          exact ⟨by simp [m4, h10'], by simp only [m4, rRead_wWrite]; exact hle.trans hmono⟩
      exact (RandExecBad.seq_det_left hpm hpa2 hd_br hStep2).mono
        (fun _ h => h) (fun _ _ h => h) le_rfl (by omega)
    · have hcond : cValAt 0 inp m (.intLt (.readHeap 26 (.lit 15)) (.readHeap 1 (.lit 5))) = false := by
        simp [hw15_m, hwcL_m]; omega
      let mb1 := wWrite m 26 0 0
      have hpb1 : mb1.popDepth 0 = mb1 := mem_writeWord_popDepth 0 hpm rfl
      have hdb1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 0) (.lit 0)) m mb1 14 :=
        exec_boxWriteW inp m _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
      have hd_br : DetExecAt 0 inp
          (.ite (.intLt (.readHeap 26 (.lit 15)) (.readHeap 1 (.lit 5)))
            (seqList [boxWriteW M_box 26 (.lit 0) (.lit 1),
                      boxWriteW M_box 26 (.lit 1) (.readHeap 14 (.readHeap 26 (.lit 15)))])
            (boxWriteW M_box 26 (.lit 0) (.lit 0))) m mb1 30 :=
        (DetExecAt.ite_false hcond (C_c := 10) (by simp [condExprOps, intExprOps]) hdb1).mono_cost (by omega)
      have hRB_inact := exec_runBaselineSlotStmt_inactive (M_box := M_box) p inp mb1 (by simp [mb1])
      have hBad_inact : RandExecBad inp (runBaselineSlotStmt d n M_box p) (p.K₀ * p.M_bits) mb1
          (fun m3 => m3 = mb1) (fun _ => True) (2 * p.φ_ev) (baselineCallCost d n p) := by
        refine ⟨by positivity, (fun _ m3 => m3 = mb1.popDepth 0), (fun _ => False), inferInstance,
          hRB_inact, by simp; positivity, fun _ m3 hm3 => ?_⟩
        rw [hm3, hpb1]; exact ⟨hpb1, rfl, fun _ => trivial⟩
      have hStep2 : RandExecBad inp
          (.seq (runBaselineSlotStmt d n M_box p)
                (boxWriteW M_box 26 (.lit 15) (.add (.readHeap 26 (.lit 15)) (.lit 1))))
          (p.K₀ * p.M_bits) mb1 (SafeI (r + 1)) (fun m4 => GoodI r m → GoodI (r + 1) m4)
          (2 * p.φ_ev) (baselineCallCost d n p + 20) := by
        refine RandExecBad.seq_det_right hpb1 hBad_inact ?_
        intro m3 _ hm3; subst hm3
        let m4 := wWrite mb1 26 15 (((r + 1 : ℕ) : ℤ))
        have hd_inc : DetExecAt 0 inp
            (boxWriteW M_box 26 (.lit 15) (.add (.readHeap 26 (.lit 15)) (.lit 1))) mb1 m4 20 :=
          exec_boxWriteW inp mb1 _ _ rfl (by omega) (by omega)
            (by simp [mb1, hw15_m]) (by simp [intExprOps])
        refine ⟨m4, hd_inc, mem_writeWord_popDepth _ hpb1 rfl,
          ⟨by simp [m4],
           hInv_m.congr_mem (by simp [m4, mb1]) (by simp [m4, mb1]) (by simp [m4, mb1]) (by simp [m4, mb1]),
           fun t ht idx => by simp [m4, mb1, ht, hwo_m t ht],
           fun t ht idx => by simp [m4, mb1, hro_m t ht]⟩, ?_⟩
        intro _ hg_prev hG i _
        have hi_lt_r : i.val < r := by have := i.isLt; omega
        rcases hg_prev hG i hi_lt_r with ⟨pair, hcond_p, hb_p⟩
        refine ⟨pair, hcond_p, fun u v huv hne => ?_⟩
        rcases hb_p u v huv hne with ⟨h10, hle⟩
        exact ⟨by simp [m4, mb1, h10], by simpa [m4, mb1] using hle⟩
      exact (RandExecBad.seq_det_left hpm hpb1 hd_br hStep2).mono
        (fun _ h => h) (fun _ _ h => h) le_rfl (by omega)
  have hRep := RandExecBad.repeatN_nat (.lit (p.D₀ : ℤ)) (refreshOneBaselineIterStmt d n M_box p)
    p.D₀ (p.K₀ * p.M_bits) 10 (baselineCallCost d n p + 120) (by positivity)
    SafeI GoodI hm2_pop hSafe0 rfl (by simp [intExprOps]) hIter
  have hSeq2 := RandExecBad.seq_det_left hm1_pop hm2_pop hd2 hRep
  have hSeq1 := RandExecBad.seq_det_left hpop₀ hm1_pop hd1 hSeq2
  refine (RandExecBad.congr_bits (by ring) hSeq1).mono ?_ ?_ le_rfl (by unfold refreshAllBaselinesCost; omega)
  · intro m' ⟨_, hI, hwo, hro⟩; exact ⟨hI, hwo, hro⟩
  · intro m' _ hg hG
    have hall := hg hGood0 hG
    have hex : ∀ i : Fin k, ∃ pair : Option (ℕ × ℕ),
        (nodes i).SatisfiesBaselineCond ghostCoords
          (chainInput ghostCoords nodes ActiveUids i.castSucc) pair ∧
        ∀ u v : ℕ, pair = some (u, v) → u ≠ v →
          wRead m' 26 10 = 1 ∧ ‖ghostCoords u - ghostCoords v‖ ^ 2 ≤ rRead m' 26 10 :=
      fun i => hall i (lt_of_lt_of_le i.isLt hk_le)
    choose bp hbp using hex
    exact ⟨bp, fun i => (hbp i).1, fun i => (hbp i).2⟩

/-! ### 2. Combined Baseline Refresh + Leaf Scan + Answer Finalization (`baselineLeafAndFinalizeStmt`) -/

def baselineLeafAndFinalizeStmt (d n M_leaf M_box : ℕ) (p : P46Params d n) : ArithRAMStmt :=
  seqList [
    refreshAllBaselinesStmt d n M_box p,
    scanLeafPairsStmt d p.K_seg M_leaf M_box,
    finalizeStepAnswerStmt d p.K_seg M_box
  ]

theorem boxSafe_baselineLeafAndFinalizeStmt {d n T_max M_leaf M_box : ℕ}
    (hT : 27 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (baselineLeafAndFinalizeStmt d n M_leaf M_box p) := by
  unfold baselineLeafAndFinalizeStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl
  · exact boxSafe_refreshAllBaselinesStmt hT p
  · exact boxSafe_scanLeafPairsStmt hT d p.K_seg M_leaf
  · exact boxSafe_finalizeStepAnswerStmt hT d p.K_seg

def baselineLeafFinalizeCost (d n M_leaf : ℕ) (p : P46Params d n) : ℕ :=
  refreshAllBaselinesCost d n p +
    350 * (M_leaf + 1) * (M_leaf + 1) * (p.K_seg + d + 5) +
    250 * (p.K_seg + d + 5) + 1000

theorem exec_baselineLeafAndFinalizeStmt
    (h_lem_5_2 : S_lem_5_2)
    {d n k M_leaf M_box : ℕ}
    (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {P : DynamicPointSet d} {leafS : ℕ} {fSq0 fSqLeaf : ℕ → ℝ}
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {ActiveUids : Finset ℕ} {uidOfH hOfUid : ℕ → ℕ}
    (nodes : Fin k → ChainNode d)
    {P_good : Prop}
    (hpop₀ : mem.popDepth 0 = mem)
    (hP : P.WellFormed n)
    (hk_le : k ≤ p.D₀)
    (hw_cL : wRead mem 1 5 = (k : ℤ))
    (hw_card : wRead mem 1 2 = (P.activeHandles.card : ℤ))
    (hw_leaf : wRead mem 1 6 = (leafS : ℤ))
    (hleaf_le : (chainTerminal P.handleCoords nodes P.activeHandles).card ≤ M_leaf)
    (hBox : 16 ≤ M_box)
    (hLive : EncLiveCoords d n mem P.activeHandles P.handleCoords)
    (hSeg0 : EncSegSlot p.K_seg mem 0 P.activeHandles fSq0)
    (hSegLeaf : EncSegSlot p.K_seg mem leafS
      (chainTerminal P.handleCoords nodes P.activeHandles) fSqLeaf)
    (hsn_dict : ∀ i : Fin k, ∃ dS < p.NumSlots,
      wRead mem 14 (i.val : ℤ) = (dS : ℤ) ∧
      EncSegSlot p.K_seg mem dS
        (chainInput P.handleCoords nodes P.activeHandles i.castSucc)
        (fun x => euclideanDistSq (P.handleCoords x) (nodes i).o))
    (hbij_H : ∀ h ∈ P.activeHandles,
      uidOfH h ∈ ActiveUids ∧ ghostCoords (uidOfH h) = P.handleCoords h ∧ hOfUid (uidOfH h) = h)
    (hbij_U : ∀ u ∈ ActiveUids, hOfUid u ∈ P.activeHandles ∧ uidOfH (hOfUid u) = u)
    (hK0_pos : 1 ≤ p.K₀) (hφ0 : 0 < p.φ_ev)
    (hbias : ((p.K₀ : ℝ) * (n : ℝ)) / ((2 : ℝ) ^ p.M_bits) ≤ p.φ_ev)
    (hmc_gen : ∀ (pts : ℕ → EuclideanSpace ℝ (Fin d))
         (P₀ S₀ : Finset ℕ) (age : ℕ) (o : EuclideanSpace ℝ (Fin d)) (s_lift : ℝ)
         (y : ℕ) (farthest : (Fin p.K₀ → ℕ) → ℕ),
       1 ≤ P₀.card →
       IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
         (paraboloidLiftSet (fun i : ↥P₀ => pts i.1)) (liftedPoint o s_lift) →
       HasNodeAge P₀ S₀ age →
       (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀.card : ℝ) / 16 →
       IsNodeMaxRadiusPoint pts o S₀ y →
       let V := liftVariance o s_lift
       let samples := Fintype.piFinset (fun _ : Fin p.K₀ => S₀)
       (∀ samp ∈ samples,
         (∃ j : Fin p.K₀, farthest samp = samp j) ∧
         ∀ j : Fin p.K₀, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖) →
       (((open Classical in samples.filter (fun samp =>
           ¬ IsNodeBaselinePair pts o V S₀ y (farthest samp))).card : ℝ) /
         (samples.card : ℝ)) ≤ p.φ_ev)
    (hGoodChain : P_good → ∀ i : Fin k,
      ∃ (P₀_uid : Finset ℕ) (age : ℕ),
        1 ≤ P₀_uid.card ∧
        IsCenterpoint (1 / (4 * ((p.D : ℝ) ^ 2)))
          (paraboloidLiftSet (fun u : ↥P₀_uid => ghostCoords u.1))
          (liftedPoint (nodes i).o ((nodes i).V + ‖(nodes i).o‖ ^ 2)) ∧
        HasNodeAge P₀_uid (chainInput ghostCoords nodes ActiveUids i.castSucc) age ∧
        (age : ℝ) ≤ (1 / (4 * ((p.D : ℝ) ^ 2))) * (P₀_uid.card : ℝ) / 16) :
    RandExecBad inp (baselineLeafAndFinalizeStmt d n M_leaf M_box p) (p.D₀ * p.K₀ * p.M_bits) mem
      (fun m' =>
        wRead m' 0 0 = wRead mem 0 0 ∧
        (∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, wRead m' t idx = wRead mem t idx) ∧
        (∀ t, t ≠ 0 → t ≠ 26 → ∀ idx, rRead m' t idx = rRead mem t idx))
      (fun m' => P_good → IsValidFactorCAnswer (Real.sqrt 2) P (readStoredAns m'))
      ((p.D₀ : ℝ) * (2 * p.φ_ev))
      (baselineLeafFinalizeCost d n M_leaf p) := by
  have hBase := exec_refreshAllBaselinesStmt p inp mem nodes hpop₀ hP hk_le hw_cL hBox hLive
    hsn_dict hbij_H hbij_U hK0_pos hφ0 hbias hmc_gen hGoodChain
  refine (RandExecBad.seq_det_right
    (C₂ := (350 * (M_leaf + 1) * (M_leaf + 1) * (p.K_seg + d + 5) + 500) +
           (250 * (p.K_seg + d + 5) + 300))
    hpop₀ hBase ?_).mono
    (fun _ h => h) (fun _ _ h => h) le_rfl (by unfold baselineLeafFinalizeCost; omega)
  intro m1 _ ⟨hInv1, hwo1, hro1⟩
  rcases chainInput_bij_uid P.handleCoords ghostCoords P.activeHandles ActiveUids
      uidOfH hOfUid hbij_H hbij_U nodes k le_rfl with ⟨hLeaf_sub, hf_leaf, hg_leaf⟩
  have hLive1 : EncLiveCoords d n m1 P.activeHandles P.handleCoords :=
    ⟨hLive.1, fun h hh c => by rw [hro1 4 (by decide)]; exact hLive.2 h hh c⟩
  have hSegLeaf1 : EncSegSlot p.K_seg m1 leafS
      (chainTerminal P.handleCoords nodes P.activeHandles) fSqLeaf :=
    hSegLeaf.congr_mem_fSq (hwo1 5 (by decide) _) (fun _ _ => hwo1 8 (by decide) _)
      (fun _ _ => hwo1 9 (by decide) _) (fun _ _ => hwo1 10 (by decide) _)
      (fun _ _ => hro1 8 (by decide) _) (fun _ _ => rfl)
  rcases exec_scanLeafPairsStmt (M_box := M_box) inp m1 (by rw [hwo1 1 (by decide), hw_leaf]) (by omega)
      hInv1 hLive1 hLeaf_sub hleaf_le hSegLeaf1
    with ⟨m2, hd_scan, _, hInv2, hmon2, hwo2, _, hro2, _, hleaf_pairs2⟩
  have hLive2 : EncLiveCoords d n m2 P.activeHandles P.handleCoords :=
    ⟨hLive1.1, fun h hh c => by rw [hro2 4 (by decide)]; exact hLive1.2 h hh c⟩
  have hSeg0_2 : EncSegSlot p.K_seg m2 0 P.activeHandles fSq0 :=
    hSeg0.congr_mem_fSq
      (by rw [hwo2 5 (by decide), hwo1 5 (by decide)])
      (fun _ _ => by rw [hwo2 8 (by decide), hwo1 8 (by decide)])
      (fun _ _ => by rw [hwo2 9 (by decide), hwo1 9 (by decide)])
      (fun _ _ => by rw [hwo2 10 (by decide), hwo1 10 (by decide)])
      (fun _ _ => by rw [hro2 8 (by decide), hro1 8 (by decide)]) (fun _ _ => rfl)
  rcases exec_finalizeStepAnswerStmt (M_box := M_box) inp m2 hP
      (by rw [hwo2 1 (by decide), hwo1 1 (by decide), hw_card]) (by omega)
      hInv2 hLive2 hSeg0_2
    with ⟨m3, hd_fin, hp3, hw00_3, hwo3, hro3, hans_le1, hans_ge2⟩
  refine ⟨m3, hd_scan.seq hd_fin, hp3,
    ⟨by rw [hw00_3, hwo2 0 (by decide), hwo1 0 (by decide)],
     fun t ht0 ht26 idx => by rw [hwo3 t ht0 ht26, hwo2 t ht26, hwo1 t ht26],
     fun t ht0 ht26 idx => by rw [hro3 t ht0 ht26, hro2 t ht26, hro1 t ht26]⟩, ?_⟩
  intro hg1 hG
  by_cases hle1 : P.activeIds.card ≤ 1
  · exact hans_le1 hle1
  · have hge2 : 2 ≤ P.activeIds.card := by omega
    rcases hans_ge2 hge2 with ⟨bestH1, bestH2, hb1, hb2, hb_ne, hans_eq, hbest_ge⟩
    rw [hans_eq]
    rcases hg1 hG with ⟨basePairs, hbp_cond, hbp_sq⟩
    rcases exists_leafPair_uid_of_distinct_bound P.handleCoords ghostCoords
        (chainTerminal P.handleCoords nodes P.activeHandles)
        (chainTerminal ghostCoords nodes ActiveUids)
        uidOfH hOfUid hf_leaf hg_leaf
        (euclideanDistSq (P.handleCoords bestH1) (P.handleCoords bestH2))
        (fun a ha b hb hab => by
          rcases hleaf_pairs2 a ha b hb hab with ⟨h10_2, hsq_2⟩
          exact hsq_2.trans (hbest_ge h10_2))
      with ⟨leafPair, hleaf_act, hleaf_diam, hleaf_sq⟩
    refine p46_valid_answer_of_chain_and_leaf h_lem_5_2 hP hge2 hbij_H hbij_U
      nodes basePairs leafPair hbp_cond hleaf_act hleaf_diam hb1 hb2 hb_ne ?_ hleaf_sq
    intro i u v huv hne
    rcases hbp_sq i u v huv hne with ⟨h10_1, hsq_1⟩
    rcases hmon2 h10_1 with ⟨h10_2, hmono12⟩
    exact (hsq_1.trans hmono12).trans (hbest_ge h10_2)

end UL.Proof_lem_7_2_RacerP46
