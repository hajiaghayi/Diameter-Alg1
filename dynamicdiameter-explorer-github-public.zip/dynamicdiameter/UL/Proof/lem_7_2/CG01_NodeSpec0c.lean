import UL.Proof.lem_7_2.CG01_NodeSpec0c1

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### Stage 2c2: Full RAM `openLevel` Execution (`cg01OpenNewLevelAtRStmt`) -/

def cg01OpenNewLevelAtRStmt (d n M_box : ℕ) (cfg : ChainHdrCfg) (p : P46Params d n) : ArithRAMStmt :=
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let jLenE : IntExpr := .readHeap 19 rE
  seqList [
    cg01OpenLevelPrepStmt d n M_box cfg p,
    hpjFreezeRunInitStmt d n M_box p,
    boxWriteW M_box 19 rE (.add jLenE (.lit 1)),
    .localScope .skip
  ]

theorem boxSafe_cg01OpenNewLevelAtRStmt {d n T_max M_box : ℕ} {cfg : ChainHdrCfg}
    (hT : 28 ≤ T_max) (p : P46Params d n) :
    BoxSafeOuter T_max M_box (cg01OpenNewLevelAtRStmt d n M_box cfg p) := by
  unfold cg01OpenNewLevelAtRStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl
  · exact boxSafe_cg01OpenLevelPrepStmt (by omega) p
  · exact boxSafe_hpjFreezeRunInitStmt hT p
  · exact .boxW (by omega) _ _
  · exact .localScope .skip

noncomputable def cg01OpenNewLevelCost (d n : ℕ) (p : P46Params d n) : ℕ :=
  freshAllocFourCost p.D₀ p.NumSlots + hpjFreezeRunInitCost d n p + 250

theorem exec_cg01OpenNewLevelAtRStmt
    (h_lem_5_1 : S_lem_5_1)
    (ctx : MidLoopCtx) (inp : ArithRAMInput ctx.d)
    {gFlag : Bool} {i : ℕ} (hi : i < ctx.st₀.k)
    {g₀ : ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
      ctx.st₀.uMap.nextUid ctx.st₀.uMap.ghostCoords (ctx.S_pre_u ⟨i, hi⟩)}
    {m₁ m_c : ArithRAMMemory}
    {lvs_h : List (JobLvData ctx.d)} (hlen_eq : lvs_h.length = g₀.lvs.length)
    {ph' scan' : ℕ}
    (pb : ActivePropBuildState ctx gFlag i hi g₀ m₁)
    (haff : ctx.aff (⟨i, hi⟩ : Fin ctx.st₀.k).castSucc = true)
    (hsome : ctx.st₀.ownedJob ⟨i, hi⟩ = some g₀)
    (hph'_le : ph' ≤ 2)
    (hlv_all : ∀ (j : ℕ) (hj : j < lvs_h.length),
      let idx := i * ctx.p.D₀ + j
      let hj_g : j < g₀.lvs.length := hlen_eq ▸ hj
      (lvs_h[j]'hj).ball (ctx.d + 3) = (g₀.lvs[j]'hj_g).ball ∧
      (lvs_h[j]'hj).openRem = g₀.openRem j ∧
      (∃ (f_b g_b : ℕ → ℕ),
        (∀ h ∈ (lvs_h[j]'hj).S_birth,
          f_b h ∈ (g₀.lvs[j]'hj_g).birthSnapshot ∧
          ctx.uMap'.ghostCoords (f_b h) = (lvs_h[j]'hj).snapPts h ∧
          g_b (f_b h) = h) ∧
        (∀ u ∈ (g₀.lvs[j]'hj_g).birthSnapshot,
          g_b u ∈ (lvs_h[j]'hj).S_birth ∧
          f_b (g_b u) = u)) ∧
      EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m₁
        ctx.P'.activeHandles ctx.P'.handleCoords idx
        (lvs_h[j]'hj).S_birth (lvs_h[j]'hj).snapPts (lvs_h[j]'hj).prov
        (jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) j)
        (decide (j + 1 = lvs_h.length)) ∧
      wRead m₁ 23 (((8 * idx + 7 : ℕ) : ℤ)) = (g₀.openRem j : ℤ) ∧
      0 < (wRead m₁ 23 (((8 * idx + 2 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 3 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 4 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 5 : ℕ) : ℤ))).toNat ∧
      0 < (wRead m₁ 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat ∧
      (j + 1 < lvs_h.length → wRead m₁ 24 (((2 * idx + 0 : ℕ) : ℤ)) = 2))
    (hpar_1 :
      let Spar_last_h' := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) (g₀.lvs.length - 1)
      Spar_last_h'.card ≤ g₀.Spar_last_h.card + 1 ∧
      ∀ c : ℕ, (Spar_last_h'.filter (fun x => c ≤ x)).card ≤
               (g₀.Spar_last_h.filter (fun x => c ≤ x)).card + 1)
    (hbuild_1 :
      let Spar_last_h' := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h
        (ctx.S_post_h ⟨i, hi⟩) (g₀.lvs.length - 1)
      let m_last := (g₀.lvs[g₀.lvs.length - 1]'(Nat.sub_lt g₀.hlvs_pos Nat.one_pos)).birthSnapshot.card
      (g₀.ph_cur = 0 →
        (g₀.scan_cur + (ctx.p.B_scan + 1) < m_last → ph' = 0 ∧ scan' = g₀.scan_cur + (ctx.p.B_scan + 1)) ∧
        (m_last ≤ g₀.scan_cur + (ctx.p.B_scan + 1) → ph' = 1 ∧ scan' = 0)) ∧
      (g₀.ph_cur = 1 →
        ph' = 2 ∨
        (ph' = 1 ∧
          (Spar_last_h'.filter (fun x => scan' ≤ x)).card + ctx.p.B_scan ≤
            (g₀.Spar_last_h.filter (fun x => g₀.scan_cur ≤ x)).card)) ∧
      (g₀.ph_cur = 2 → ph' = 2))
    (hcl : g₀.closed = false)
    (hph2 : ph' = 2)
    (hw24_last_m1 : wRead m₁ 24 (((2 * (i * ctx.p.D₀ + (g₀.lvs.length - 1)) + 0 : ℕ) : ℤ)) = 2)
    (hcan : CanOpenResidualLevel (1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2))
      (g₀.H_job - (g₀.t_cur + 1))
      (prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u ⟨i, hi⟩)).card)
    (hlarge : 2 * ctx.p.L + 1 <
      (prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u ⟨i, hi⟩)).card)
    (hpop_c : m_c.popDepth 0 = m_c)
    (hw15_c : wRead m_c 26 15 = (i : ℤ))
    (hw24_c : wRead m_c 26 24 =
      ((jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h ⟨i, hi⟩) lvs_h.length).card : ℤ))
    (hw27_c : wRead m_c 26 27 = 0)
    (hwRem_ic : wRead m_c ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx i : ℤ) =
      (((g₀.H_job - (g₀.t_cur + 1) : ℕ) : ℤ)))
    (hwRem_nec : ∀ r ≠ i, wRead m_c ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ) =
      wRead m₁ ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r : ℤ))
    (hw_mc_not : ∀ t, t ≠ 26 → t ≠ ctx.cfg.jobRem.tag → ∀ k, wRead m_c t k = wRead m₁ t k)
    (hw_bc_c : ∀ r, wRead m_c ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ) =
      wRead m₁ ctx.cfg.snBirthCard.tag (ctx.cfg.snBirthCard.idx r : ℤ))
    (hw_age_c : ∀ r, wRead m_c ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ) =
      wRead m₁ ctx.cfg.snAge.tag (ctx.cfg.snAge.idx r : ℤ))
    (hw_aff_c : ∀ r, wRead m_c ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ) =
      wRead m₁ ctx.cfg.snAffected.tag (ctx.cfg.snAffected.idx r : ℤ))
    (hw_cl_c : ∀ r, wRead m_c ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ) =
      wRead m₁ ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r : ℤ))
    (hr_mc : ∀ t k, rRead m_c t k = rRead m₁ t k) :
    RandExecBad inp (cg01OpenNewLevelAtRStmt ctx.d ctx.n ctx.M_box ctx.cfg ctx.p) ctx.p.B_hpj m_c
      (fun m' =>
        wRead m' 0 0 = wRead m_c 0 0 ∧
        wRead m' 26 13 = wRead m_c 26 13 ∧
        wRead m' 26 14 = wRead m_c 26 14 ∧
        wRead m' 26 15 = (i : ℤ) ∧
        wRead m' 26 28 = wRead m_c 26 28 ∧
        ∃ g', PostEndActionJobState ctx false i hi m' g')
      (fun m' =>
        gFlag = true → ∃ g', PostEndActionJobState ctx true i hi m' g')
      (2 * ctx.p.φ_ev)
      (cg01OpenNewLevelCost ctx.d ctx.n ctx.p) := by
  classical
  let r_fin : Fin ctx.st₀.k := ⟨i, hi⟩
  let jLen := g₀.lvs.length
  let newIdx := i * ctx.p.D₀ + jLen
  let rem' := g₀.H_job - (g₀.t_cur + 1)
  let curRes_h := jobHandleInput (ctx.d + 3) ctx.P'.handleCoords lvs_h (ctx.S_post_h r_fin) lvs_h.length
  let curRes_u := prefixResidual ctx.uMap'.ghostCoords g₀.lvs (ctx.S_post_u r_fin)
  have hjLen_lt_D0 : jLen < ctx.p.D₀ := by
    rw [ctx.hD0_eq]; exact g₀.lvs_length_lt ctx.hH5 ctx.hn2
  have hi_D0 : i < ctx.p.D₀ := lt_trans hi ctx.origK_lt_D0
  have hi_box : i < ctx.M_box := by
    have h8 := ctx.hBox_w23
    have hle : i + 1 ≤ ctx.p.D₀ * ctx.p.D₀ := by
      have h1 : i + 1 ≤ ctx.p.D₀ := hi_D0
      have h2 : 1 ≤ ctx.p.D₀ := ctx.D0_pos
      nlinarith
    omega
  have hjob_box := ctx.jobIdx_box_bounds hi hjLen_lt_D0
  have hRes_rem := ctx.hV.2.2.2.2.2.2.2.2.2.1
  have hw_mc_res : ∀ t ∈ reservedWordTags, t ≠ 26 → ∀ k, wRead m_c t k = wRead m₁ t k :=
    fun t ht hne26 k => hw_mc_not t hne26 (Ne.symm (tag_ne_of_not_reserved hRes_rem ht)) k
  rcases cg01_curRes_bij ctx hi lvs_h g₀.lvs hlen_eq (fun j hj => (hlv_all j hj).1)
    with ⟨hsub_cur, hf_cur, hg_cur, hcard_cur⟩
  have hb_pos : 0 < curRes_h.card := by change 0 < _; rw [hcard_cur]; omega
  have hb_le_n : curRes_h.card ≤ ctx.n :=
    (Finset.card_le_card hsub_cur).trans
      ((activeHandles_card_eq_activeIds_card ctx.hP').trans_le ctx.hP'.1)
  rcases exec_cg01OpenLevelPrepStmt ctx inp hi hlen_eq pb
      (fun j hj => ⟨(hlv_all j hj).1, (hlv_all j hj).2.2.2.1, (hlv_all j hj).2.2.2.2.2.2.2.2.2.1⟩)
      hw24_last_m1 hpop_c hw15_c hw24_c hwRem_ic hw_mc_not hr_mc
    with ⟨m_25, spRS_last, dS_n, spDS_n, rS_n, spRS_n,
      hd_prep, hpop_25, hspRS_last_pos, hspRS_last_lt, hw_spRS_last, h6_spRS_m1,
      hdS_n0, hdS_n_lt, hdS_n_notU, hspDS_n0, hspDS_n_lt, hspDS_n_notU,
      hrS_n0, hrS_n_lt, hrS_n_notU, hspRS_n0, hspRS_n_lt, hspRS_n_notU,
      hdist5, hw25_7, hw25_1, hw25_20, hw25_21, hw25_22, hw25_23, hw25_24, hw25_25,
      h6_spRS_25, hSeg_25, hSave_25, hLive_25, hSeg_spRS_25, hSlot_spRS_25,
      hSegPres_m1_25, hw6_25_m1, hw25_1_c, hw25_oth_c, hw25_26_c, hr25_c⟩
  have hHpj := exec_hpjFreezeRunInitStmt h_lem_5_1 ctx.p inp m_25
    (idx := newIdx) (bS := spRS_last) (dS := dS_n) (spDS := spDS_n) (rS := rS_n) (spRS := spRS_n)
    (openRem := rem')
    (S_birth := curRes_h) (S_parent := curRes_h) (S_uid := curRes_u)
    (activeH := ctx.P'.activeHandles) (livePts := ctx.P'.handleCoords) (snapPts := ctx.P'.handleCoords)
    (ghostCoords := ctx.uMap'.ghostCoords) (uidOfH := ctx.uMap'.uidOfH) (hOfUid := ctx.uMap'.hOfUid)
    hpop_25 ctx.hD_eq ctx.hkφ ctx.hφ0 ctx.hφ1 ctx.hp_eq ctx.hp_props ctx.hbias_hpj ctx.hB_hpj
    hspRS_last_lt hdS_n_lt hspDS_n_lt hrS_n_lt hspRS_n_lt hdist5
    hb_pos hb_le_n ctx.hBox30 ctx.hBox_slots ctx.hBox_samp ctx.hBox_d
    hjob_box.1 hjob_box.2
    hw25_7 hw25_1 hw25_20 hw25_21 hw25_22 hw25_23 hw25_24 hw25_25
    h6_spRS_25 hSeg_25 hSave_25 hLive_25 hSeg_spRS_25 hSlot_spRS_25 hf_cur hg_cur
  let rE : IntExpr := .readHeap 26 (.lit 15)
  let jLenE : IntExpr := .readHeap 19 rE
  let tailStmt : ArithRAMStmt := seqList [
    boxWriteW ctx.M_box 19 rE (.add jLenE (.lit 1)),
    .localScope .skip
  ]
  have hFrom25 : RandExecBad inp (.seq (hpjFreezeRunInitStmt ctx.d ctx.n ctx.M_box ctx.p) tailStmt)
      ctx.p.B_hpj m_25
      (fun m' =>
        wRead m' 0 0 = wRead m_c 0 0 ∧
        wRead m' 26 13 = wRead m_c 26 13 ∧
        wRead m' 26 14 = wRead m_c 26 14 ∧
        wRead m' 26 15 = (i : ℤ) ∧
        wRead m' 26 28 = wRead m_c 26 28 ∧
        ∃ g', PostEndActionJobState ctx false i hi m' g')
      (fun m' =>
        gFlag = true → ∃ g', PostEndActionJobState ctx true i hi m' g')
      (2 * ctx.p.φ_ev)
      (hpjFreezeRunInitCost ctx.d ctx.n ctx.p + 40) := by
    refine RandExecBad.seq_det_right hpop_25 hHpj ?_
    intro m_hpj hpop_hpj hSafe_hpj
    rcases hSafe_hpj with ⟨hSeg_hpj, hSave_hpj, hEncLv_hpj, ⟨o_cand, s_cand, _, hball_hpj⟩,
      _, hw23_2_h, hw23_3_h, hw23_4_h, hw23_5_h, hw23_6_h, hw23_7_h,
      _, hlive_new_h, hw24_0_h, hw24_1_h,
      _, _, _, _,
      hSegPres_h, _, hw_oth_h, hw26_h, hw6Fr_h, hw23Fr_h, hw24Fr_h,
      hr_oth_h, hr23Fr_h, hr24Fr_h⟩
    have hw26_15_hpj : wRead m_hpj 26 15 = (i : ℤ) :=
      (hw26_h 15 (by decide)).trans
        ((hw25_26_c 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)).trans hw15_c)
    have hw19_i_hpj : wRead m_hpj 19 (i : ℤ) = (jLen : ℤ) :=
      (hw_oth_h 19 (by decide) (by decide) (by decide) (by decide) _).trans
        ((hw25_oth_c 19 (by decide) (by decide) (by decide) (by decide) (by decide) _).trans
          ((hw_mc_res 19 (by decide) (by decide) _).trans pb.hw19_i))
    let m_end := wWrite m_hpj 19 (i : ℤ) (((jLen + 1 : ℕ) : ℤ))
    have hpop_end : m_end.popDepth 0 = m_end := wWrite_popDepth_zero hpop_hpj 19 _ _
    have hd_19 : DetExecAt 0 inp (boxWriteW ctx.M_box 19 rE (.add jLenE (.lit 1))) m_hpj m_end 25 :=
      exec_boxWriteW inp m_hpj _ _
        (by simp [rE, iValAt_readHeap, iValAt_lit, hw26_15_hpj])
        (by positivity) (by exact_mod_cast hi_box)
        (by simp only [jLenE, rE, iValAt_add, iValAt_readHeap, iValAt_lit, hw26_15_hpj, hw19_i_hpj]; push_cast; rfl)
        (by simp [jLenE, rE, intExprOps])
    have hd_skip : DetExecAt 0 inp (.localScope .skip) m_end m_end 5 := by
      simpa [hpop_end] using (DetExecAt.localScope (fd := 0) (DetExecAt.skip 1 inp (m_end.popDepth 0))).mono_cost (by omega)
    have hd_tail : DetExecAt 0 inp tailStmt m_hpj m_end 40 :=
      (hd_19.seq hd_skip).mono_cost (by omega)
    have hw_end_not19 : ∀ t, t ≠ 19 → ∀ k, wRead m_end t k = wRead m_hpj t k :=
      fun t ht _ => wRead_wWrite_of_ne _ _ (Or.inl ht)
    have hr_end_hpj : ∀ t k, rRead m_end t k = rRead m_hpj t k :=
      fun _ _ => by dsimp only [m_end]; rw [rRead_wWrite]
    have hw_hpj_unch : ∀ t, t ≠ 1 → t ≠ 5 → t ≠ 6 → t ≠ 7 → t ≠ 23 → t ≠ 24 → t ≠ 26 →
        ∀ k, wRead m_hpj t k = wRead m_c t k :=
      fun t h1 h5 h6 h7 h23 h24 h26 k =>
        (hw_oth_h t h6 h23 h24 h26 k).trans (hw25_oth_c t h1 h5 h6 h7 h26 k)
    have hSeg_end : SegGenBound ctx.p.K_seg ctx.p.NumSlots m_end :=
      ⟨by rw [hw_end_not19 1 (by decide)]; exact hSeg_hpj.1,
       fun s hs => by rw [hw_end_not19 5 (by decide), hw_end_not19 1 (by decide)]; exact hSeg_hpj.2.1 s hs,
       fun s hs u hu => by rw [hw_end_not19 8 (by decide), hw_end_not19 1 (by decide)]; exact hSeg_hpj.2.2 s hs u hu⟩
    have hSave_end : SaveGenBound ctx.n ctx.p.NumSlots m_end :=
      ⟨by rw [hw_end_not19 1 (by decide)]; exact hSave_hpj.1,
       fun s hs => by rw [hw_end_not19 6 (by decide), hw_end_not19 1 (by decide)]; exact hSave_hpj.2.1 s hs,
       fun s hs h hh => by rw [hw_end_not19 11 (by decide), hw_end_not19 1 (by decide)]; exact hSave_hpj.2.2 s hs h hh⟩
    have hLive_end : EncLiveCoords ctx.d ctx.n m_end ctx.P'.activeHandles ctx.P'.handleCoords :=
      ⟨pb.hLive.1, fun h hh c => by
        rw [hr_end_hpj, hr_oth_h 4 (by decide) (by decide) (by decide), hr25_c, hr_mc]
        exact pb.hLive.2 h hh c⟩
    have hSegPres_m1_end : ∀ s < ctx.p.NumSlots, s ≠ dS_n → s ≠ spDS_n → s ≠ rS_n → s ≠ spRS_n →
        ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m₁ s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m_end s S₁ fSq₁ :=
      fun s hs n0 n1 n2 n3 S₁ fSq₁ hEm1 =>
        (hSegPres_h s hs S₁ fSq₁ (hSegPres_m1_25 s hs n0 n1 n2 n3 S₁ fSq₁ hEm1)).congr_mem_fSq
          (hw_end_not19 5 (by decide) _) (fun _ _ => hw_end_not19 8 (by decide) _)
          (fun _ _ => hw_end_not19 9 (by decide) _) (fun _ _ => hw_end_not19 10 (by decide) _)
          (fun _ _ => hr_end_hpj 8 _) (fun _ _ => rfl)
    have hEncLvNew_end : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m_end
        ctx.P'.activeHandles ctx.P'.handleCoords newIdx
        curRes_h ctx.P'.handleCoords (provAtIdx ctx.d m_hpj newIdx) curRes_h true := by
      have h_hpj_d : EncJobLevel ctx.d ctx.n (ctx.d + 3) ctx.p.K_seg ctx.p.NumSlots m_hpj
          ctx.P'.activeHandles ctx.P'.handleCoords newIdx
          curRes_h ctx.P'.handleCoords (provAtIdx ctx.d m_hpj newIdx) curRes_h true :=
        ctx.hD_eq ▸ hEncLv_hpj
      exact h_hpj_d.frame_slotSet (fun _ _ => rfl) (fun _ _ => rfl)
        (fun _ _ _ _ _ _ hE => hE.congr_mem_fSq
          (hw_end_not19 5 (by decide) _) (fun _ _ => hw_end_not19 8 (by decide) _)
          (fun _ _ => hw_end_not19 9 (by decide) _) (fun _ _ => hw_end_not19 10 (by decide) _)
          (fun _ _ => hr_end_hpj 8 _) (fun _ _ => rfl))
        (fun _ _ => hw_end_not19 6 (by decide) _)
        (hw_end_not19 11 (by decide)) (hr_end_hpj 11)
        (fun _ _ => hw_end_not19 23 (by decide) _)
        (fun _ _ => hw_end_not19 24 (by decide) _)
        (fun _ => hr_end_hpj 23 _) (fun _ _ => hr_end_hpj 24 _)
    have hRes_cl := ctx.hV.2.2.2.2.2.2.2.2.2.2.1
    have hRes_bc := ctx.hV.2.2.2.2.2.2.1
    have hRes_age := ctx.hV.2.2.2.2.2.2.2.1
    have hRes_aff := ctx.hV.2.2.2.2.2.2.2.2.1
    have hRes_rO := ctx.hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1
    have hRes_rV := ctx.hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2
    have hw_hdr_tag : ∀ t, t ∉ reservedWordTags → ∀ k, wRead m_end t k = wRead m_c t k :=
      fun t hnot k => (hw_end_not19 t (tag_ne_of_not_reserved hnot (by decide)) k).trans
        (hw_hpj_unch t
          (tag_ne_of_not_reserved hnot (by decide)) (tag_ne_of_not_reserved hnot (by decide))
          (tag_ne_of_not_reserved hnot (by decide)) (tag_ne_of_not_reserved hnot (by decide))
          (tag_ne_of_not_reserved hnot (by decide)) (tag_ne_of_not_reserved hnot (by decide))
          (tag_ne_of_not_reserved hnot (by decide)) k)
    have hr_hdr_tag : ∀ t, t ∉ reservedRealTags → ∀ k, rRead m_end t k = rRead m₁ t k :=
      fun t hnot k => (hr_end_hpj t k).trans
        ((hr_oth_h t (rtag_ne_of_not_reserved hnot (by decide))
          (rtag_ne_of_not_reserved hnot (by decide))
          (rtag_ne_of_not_reserved hnot (by decide)) k).trans
          ((hr25_c t k).trans (hr_mc t k)))
    have buildPost : ∀ (b : Bool),
        (b = true → gFlag = true ∧
          let α := 1 / (4 * ((ctx.d + 3 : ℕ) : ℝ) ^ 2)
          let ball := applyBirthCoreFallback α ctx.P'.handleCoords curRes_h (provAtIdx ctx.d m_hpj newIdx)
          IsCenterpoint α (paraboloidLiftSet (fun u : ↥curRes_u => ctx.uMap'.ghostCoords u.1))
            (liftedPoint ball.o (ball.V + ‖ball.o‖ ^ 2))) →
        ∃ g', PostEndActionJobState ctx b i hi m_end g' := fun b hb_g =>
      cg01_postEndAction_of_openLevel h_lem_5_1 (hlen_eq := hlen_eq) hi pb haff hsome hph'_le hlv_all hpar_1 hbuild_1
        hcl hph2 hw24_last_m1 hcan hlarge hw_spRS_last hspRS_last_pos h6_spRS_m1
        hdS_n0 hdS_n_notU hspDS_n0 hspDS_n_notU hrS_n0 hrS_n_notU hspRS_n0 hspRS_n_notU
        ((hw_end_not19 26 (by decide) 27).trans
          ((hw26_h 27 (by decide)).trans
            ((hw25_26_c 27 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)).trans hw27_c)))
        hSeg_end hSave_end hLive_end
        ((hw_end_not19 1 (by decide) 5).trans
          ((hw_oth_h 1 (by decide) (by decide) (by decide) (by decide) 5).trans
            ((hw25_1_c 5 (by decide) (by decide)).trans (hw_mc_res 1 (by decide) (by decide) 5))))
        ((hw_end_not19 1 (by decide) 6).trans
          ((hw_oth_h 1 (by decide) (by decide) (by decide) (by decide) 6).trans
            ((hw25_1_c 6 (by decide) (by decide)).trans (hw_mc_res 1 (by decide) (by decide) 6))))
        (fun k => (hw_end_not19 11 (by decide) k).trans
          ((hw_hpj_unch 11 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) k).trans
            (hw_mc_res 11 (by decide) (by decide) k)))
        (fun k => (hr_end_hpj 11 k).trans
          ((hr_oth_h 11 (by decide) (by decide) (by decide) k).trans
            ((hr25_c 11 k).trans (hr_mc 11 k))))
        (fun r => (hw_end_not19 14 (by decide) r).trans
          ((hw_hpj_unch 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) r).trans
            (hw_mc_res 14 (by decide) (by decide) r)))
        (fun r => (hw_end_not19 15 (by decide) r).trans
          ((hw_hpj_unch 15 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) r).trans
            (hw_mc_res 15 (by decide) (by decide) r)))
        (fun r => (hw_end_not19 16 (by decide) r).trans
          ((hw_hpj_unch 16 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) r).trans
            (hw_mc_res 16 (by decide) (by decide) r)))
        (by dsimp only [m_end]; rw [wRead_wWrite_self])
        (fun r hne => by
          have hz : (r : ℤ) ≠ (i : ℤ) := fun h => hne (Nat.cast_inj.mp h)
          dsimp only [m_end]
          rw [wRead_wWrite_of_ne _ _ (Or.inr hz),
              hw_hpj_unch 19 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide),
              hw_mc_res 19 (by decide) (by decide)])
        ((hw_hdr_tag _ hRes_rem _).trans hwRem_ic)
        (fun r hne => (hw_hdr_tag _ hRes_rem _).trans (hwRem_nec r hne))
        ((hw_hdr_tag _ hRes_cl _).trans ((hw_cl_c i).trans (by rw [pb.hwCl_i, hcl]; rfl)))
        (fun r _ => (hw_hdr_tag _ hRes_cl _).trans (hw_cl_c r))
        (fun r => (hw_hdr_tag _ hRes_bc _).trans (hw_bc_c r))
        (fun r => (hw_hdr_tag _ hRes_age _).trans (hw_age_c r))
        (fun r => (hw_hdr_tag _ hRes_aff _).trans (hw_aff_c r))
        (hr_hdr_tag _ hRes_rO)
        (hr_hdr_tag _ hRes_rV)
        (by
          rw [hw_end_not19 6 (by decide),
              hw6Fr_h _ (fun h => hdist5.1 (Nat.cast_inj.mp h))
                        (fun h => hdist5.2.1 (Nat.cast_inj.mp h))
                        (fun h => hdist5.2.2.1 (Nat.cast_inj.mp h))
                        (fun h => hdist5.2.2.2.1 (Nat.cast_inj.mp h))]
          exact h6_spRS_25)
        (fun s nsp n0 n1 n2 n3 => by
          rw [hw_end_not19 6 (by decide),
              hw6Fr_h _ (fun h => n0 (Nat.cast_inj.mp h)) (fun h => n1 (Nat.cast_inj.mp h))
                        (fun h => n2 (Nat.cast_inj.mp h)) (fun h => n3 (Nat.cast_inj.mp h)),
              hw6_25_m1 s nsp n0 n1 n2 n3])
        hSegPres_m1_end
        hEncLvNew_end
        (fun _ => by simpa [ctx.hD_eq] using hball_hpj)
        ⟨(hw_end_not19 23 (by decide) _).trans hw23_2_h,
         (hw_end_not19 23 (by decide) _).trans hw23_3_h,
         (hw_end_not19 23 (by decide) _).trans hw23_4_h,
         (hw_end_not19 23 (by decide) _).trans hw23_5_h,
         (hw_end_not19 23 (by decide) _).trans hw23_6_h,
         (hw_end_not19 23 (by decide) _).trans hw23_7_h,
         (jobLevelLiveSlots_congr_23
           (hw_end_not19 23 (by decide) _) (hw_end_not19 23 (by decide) _)
           (hw_end_not19 23 (by decide) _) (hw_end_not19 23 (by decide) _)).trans hlive_new_h⟩
        ⟨(hw_end_not19 24 (by decide) _).trans hw24_0_h,
         (hw_end_not19 24 (by decide) _).trans hw24_1_h⟩
        (fun idx hne a ha => by
          rw [hw_end_not19 23 (by decide), hw23Fr_h _ (jobIdx_disj_w23 hne ha),
              hw25_oth_c 23 (by decide) (by decide) (by decide) (by decide) (by decide),
              hw_mc_res 23 (by decide) (by decide)])
        (fun idx hne a ha => by
          rw [hw_end_not19 24 (by decide), hw24Fr_h _ (jobIdx_disj_w24 hne ha),
              hw25_oth_c 24 (by decide) (by decide) (by decide) (by decide) (by decide),
              hw_mc_res 24 (by decide) (by decide)])
        (fun idx hne c => by
          rw [hr_end_hpj, hr23Fr_h _ (jobIdx_disj_r23 hne c.isLt), hr25_c, hr_mc])
        (fun idx hne a ha => by
          rw [hr_end_hpj, hr24Fr_h _ (jobIdx_disj_w24 hne ha), hr25_c, hr_mc])
        hb_g
    refine ⟨m_end, hd_tail, hpop_end,
      ⟨(hw_end_not19 0 (by decide) 0).trans
         (hw_hpj_unch 0 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) 0),
       (hw_end_not19 26 (by decide) 13).trans
         ((hw26_h 13 (by decide)).trans
           (hw25_26_c 13 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))),
       (hw_end_not19 26 (by decide) 14).trans
         ((hw26_h 14 (by decide)).trans
           (hw25_26_c 14 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))),
       (hw_end_not19 26 (by decide) 15).trans hw26_15_hpj,
       (hw_end_not19 26 (by decide) 28).trans
         ((hw26_h 28 (by decide)).trans
           (hw25_26_c 28 (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide))),
       buildPost false (fun h => by cases h)⟩,
      fun hcp_hpj hgF => buildPost true (fun _ => ⟨hgF, by simpa [ctx.hD_eq] using hcp_hpj⟩)⟩
  exact (RandExecBad.seq_det_left hpop_c hpop_25 hd_prep hFrom25).mono
    (fun _ h => h) (fun _ _ h => h) le_rfl (by unfold cg01OpenNewLevelCost; omega)

end UL.Proof_lem_7_2_RacerP46
