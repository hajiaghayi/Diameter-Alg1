import UL.Proof.lem_7_2.CG03_JobTickA3b

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 1. Tag/Index Disjointness, Dummy HPJ Wrapper, & Node/Job Frame Lemmas -/

lemma tag_ne_of_not_reserved {t u : ℕ} (ht : t ∉ reservedWordTags) (hu : u ∈ reservedWordTags) :
    t ≠ u :=
  fun h => ht (h ▸ hu)

lemma rtag_ne_of_not_reserved {t u : ℕ} (ht : t ∉ reservedRealTags) (hu : u ∈ reservedRealTags) :
    t ≠ u :=
  fun h => ht (h ▸ hu)

lemma jobIdx_ne {D₀ r₁ r₂ j₁ j₂ : ℕ} (hj₁ : j₁ < D₀) (hj₂ : j₂ < D₀)
    (hne : r₁ ≠ r₂ ∨ j₁ ≠ j₂) :
    r₁ * D₀ + j₁ ≠ r₂ * D₀ + j₂ := by
  intro heq
  rcases Nat.lt_trichotomy r₁ r₂ with hlt | rfl | hgt
  · have hle : (r₁ + 1) * D₀ ≤ r₂ * D₀ := Nat.mul_le_mul_right D₀ hlt
    have hmul : r₁ * D₀ + D₀ ≤ r₂ * D₀ := by simpa [Nat.add_mul] using hle
    omega
  · rcases hne with hr | hj
    · exact hr rfl
    · omega
  · have hle : (r₂ + 1) * D₀ ≤ r₁ * D₀ := Nat.mul_le_mul_right D₀ hgt
    have hmul : r₂ * D₀ + D₀ ≤ r₁ * D₀ := by simpa [Nat.add_mul] using hle
    omega

lemma jobIdx_disj_w23 {idx₁ idx₂ a : ℕ} (hne : idx₁ ≠ idx₂) (ha : a < 8) :
    (((8 * idx₁ + a : ℕ) : ℤ) < ((8 * idx₂ : ℕ) : ℤ) ∨
     ((8 * idx₂ + 8 : ℕ) : ℤ) ≤ ((8 * idx₁ + a : ℕ) : ℤ)) := by
  omega

lemma jobIdx_disj_w24 {idx₁ idx₂ a : ℕ} (hne : idx₁ ≠ idx₂) (ha : a < 2) :
    (((2 * idx₁ + a : ℕ) : ℤ) < ((2 * idx₂ : ℕ) : ℤ) ∨
     ((2 * idx₂ + 2 : ℕ) : ℤ) ≤ ((2 * idx₁ + a : ℕ) : ℤ)) := by
  omega

lemma jobIdx_disj_r23 {d idx₁ idx₂ c : ℕ} (hne : idx₁ ≠ idx₂) (hc : c < d) :
    (((idx₁ * d + c : ℕ) : ℤ) < ((idx₂ * d : ℕ) : ℤ) ∨
     ((idx₂ * d + d : ℕ) : ℤ) ≤ ((idx₁ * d + c : ℕ) : ℤ)) := by
  rcases Nat.lt_or_gt_of_ne hne with hlt | hgt
  · left
    have h1 : (idx₁ + 1) * d ≤ idx₂ * d := Nat.mul_le_mul_right d hlt
    have h2 : idx₁ * d + d ≤ idx₂ * d := by simpa [Nat.add_mul] using h1
    omega
  · right
    have h1 : (idx₂ + 1) * d ≤ idx₁ * d := Nat.mul_le_mul_right d hgt
    have h2 : idx₂ * d + d ≤ idx₁ * d := by simpa [Nat.add_mul] using h1
    omega

lemma MidLoopCtx.D0_pos (ctx : MidLoopCtx) : 1 ≤ ctx.p.D₀ := by
  rw [ctx.hD0_eq]
  have h1 : 1 ≤ (ctx.d + 3) ^ 2 := Nat.one_le_pow 2 (ctx.d + 3) (by omega)
  have h5 := ctx.hH5
  nlinarith

lemma MidLoopCtx.jobIdx_box_bounds (ctx : MidLoopCtx) {r j : ℕ}
    (hr : r < ctx.st₀.k) (hj : j < ctx.p.D₀) :
    8 * (r * ctx.p.D₀ + j) + 8 ≤ ctx.M_box ∧
    (r * ctx.p.D₀ + j) * ctx.d + ctx.d ≤ ctx.M_box := by
  have hr_D0 : r < ctx.p.D₀ := lt_trans hr ctx.origK_lt_D0
  have hle_prod : r * ctx.p.D₀ + j + 1 ≤ ctx.p.D₀ * ctx.p.D₀ := by
    have h1 : r + 1 ≤ ctx.p.D₀ := hr_D0
    have h2 : (r + 1) * ctx.p.D₀ ≤ ctx.p.D₀ * ctx.p.D₀ := Nat.mul_le_mul_right _ h1
    have h3 : r * ctx.p.D₀ + ctx.p.D₀ ≤ ctx.p.D₀ * ctx.p.D₀ := by simpa [Nat.add_mul] using h2
    omega
  refine ⟨?_, ?_⟩
  · have h8 := ctx.hBox_w23; omega
  · have hd_mul : (r * ctx.p.D₀ + j + 1) * ctx.d ≤ (ctx.p.D₀ * ctx.p.D₀) * ctx.d :=
      Nat.mul_le_mul_right ctx.d hle_prod
    have hd_exp : (r * ctx.p.D₀ + j) * ctx.d + ctx.d ≤ (ctx.p.D₀ * ctx.p.D₀) * ctx.d := by
      simpa [Nat.add_mul] using hd_mul
    have hr23 := ctx.hBox_r23
    omega

lemma wWrite_popDepth_zero {m : ArithRAMMemory} (hpop : m.popDepth 0 = m) (t : ℕ) (idx val : ℤ) :
    (wWrite m t idx val).popDepth 0 = wWrite m t idx val :=
  mem_writeWord_popDepth (loc := .heap t idx) val hpop rfl

theorem exec_dummyHPJStmt {d n M_box : ℕ}
    (p : P46Params d n) (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    (hpop : mem.popDepth 0 = mem)
    (hBox26 : 1 ≤ M_box)
    (hφ0 : 0 ≤ p.φ_ev) :
    RandExecBad inp
      (seqList [boxWriteW M_box 26 (.lit 0) (.lit 0), runHPJOnSlotStmt d n M_box p])
      p.B_hpj mem
      (fun m' => m' = wWrite mem 26 0 0)
      (fun _ => True)
      (2 * p.φ_ev)
      (hpjCallCost d n p + 25) := by
  let m1 := wWrite mem 26 0 0
  have hd1 : DetExecAt 0 inp (boxWriteW M_box 26 (.lit 0) (.lit 0)) mem m1 14 :=
    exec_boxWriteW inp mem _ _ rfl (by omega) (by omega) rfl (by simp [intExprOps])
  have hpop1 : m1.popDepth 0 = m1 := mem_writeWord_popDepth (loc := .heap 26 0) 0 hpop rfl
  have hr2 := exec_runHPJOnSlotStmt_inactive (M_box := M_box) p inp m1 (by simp [m1])
  have hbad : RandExecBad inp (runHPJOnSlotStmt d n M_box p) p.B_hpj m1
      (fun m' => m' = m1) (fun _ => True) (2 * p.φ_ev) (hpjCallCost d n p) := by
    refine ⟨by linarith, fun _ m' => m' = m1.popDepth 0, fun _ => False, inferInstance, hr2, ?_, ?_⟩
    · have h0 : Finset.univ.filter (fun (_ : Fin p.B_hpj → Bool) => False) = ∅ := by ext; simp
      rw [h0, Finset.card_empty, Nat.cast_zero]
      exact mul_nonneg (by linarith) (by positivity)
    · intro _ m' hm'
      rw [hpop1] at hm'
      subst hm'
      exact ⟨hpop1, rfl, fun _ => trivial⟩
  exact (RandExecBad.seq_det_left hpop hpop1 hd1 hbad).mono (fun _ h => h) (fun _ _ h => h) le_rfl (by omega)

lemma snSlotSet_congr_14_15 {m m' : ArithRAMMemory} {r : ℕ}
    (h14 : wRead m' 14 (r : ℤ) = wRead m 14 (r : ℤ))
    (h15 : wRead m' 15 (r : ℤ) = wRead m 15 (r : ℤ)) :
    snSlotSet m' r = snSlotSet m r := by
  unfold snSlotSet
  rw [h14, h15]

lemma jobLevelLiveSlots_congr_23 {m m' : ArithRAMMemory} {idx : ℕ} {sp : Bool}
    (h3 : wRead m' 23 (((8 * idx + 3 : ℕ) : ℤ)) = wRead m 23 (((8 * idx + 3 : ℕ) : ℤ)))
    (h4 : wRead m' 23 (((8 * idx + 4 : ℕ) : ℤ)) = wRead m 23 (((8 * idx + 4 : ℕ) : ℤ)))
    (h5 : wRead m' 23 (((8 * idx + 5 : ℕ) : ℤ)) = wRead m 23 (((8 * idx + 5 : ℕ) : ℤ)))
    (h6 : wRead m' 23 (((8 * idx + 6 : ℕ) : ℤ)) = wRead m 23 (((8 * idx + 6 : ℕ) : ℤ))) :
    jobLevelLiveSlots m' idx sp = jobLevelLiveSlots m idx sp := by
  unfold jobLevelLiveSlots
  rw [h3, h4, h5, h6]

lemma EncJobLevel.frame_slotSet {d n D K NumSlots : ℕ} {mem mem' : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts livePts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {idx : ℕ} {S_birth : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d} {S_parent : Finset ℕ} {spareResLive : Bool}
    (hEnc : EncJobLevel d n D K NumSlots mem activeH livePts idx S_birth snapPts prov S_parent spareResLive)
    (hlive_on : ∀ x ∈ S_parent, livePts' x = livePts x)
    (hlive_act : ∀ h ∈ activeH, livePts' h = livePts h)
    (hseg_pres : ∀ s ∈ jobLevelSlotSet mem idx, s < NumSlots →
      (spareResLive = false → s ≠ (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat) →
      ∀ S₁ fSq₁, EncSegSlot K mem s S₁ fSq₁ → EncSegSlot K mem' s S₁ fSq₁)
    (hsave_pres : ∀ s ∈ jobLevelSlotSet mem idx,
      wRead mem' 6 (s : ℤ) = wRead mem 6 (s : ℤ))
    (hw11 : ∀ i, wRead mem' 11 i = wRead mem 11 i)
    (hr11 : ∀ i, rRead mem' 11 i = rRead mem 11 i)
    (hw23 : ∀ r < 8, wRead mem' 23 (((8 * idx + r : ℕ) : ℤ)) = wRead mem 23 (((8 * idx + r : ℕ) : ℤ)))
    (hw24 : ∀ r < 2, wRead mem' 24 (((2 * idx + r : ℕ) : ℤ)) = wRead mem 24 (((2 * idx + r : ℕ) : ℤ)))
    (hr23 : ∀ c : Fin d, rRead mem' 23 (((idx * d + c.val : ℕ) : ℤ)) = rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)))
    (hr24 : ∀ r < 2, rRead mem' 24 (((2 * idx + r : ℕ) : ℤ)) = rRead mem 24 (((2 * idx + r : ℕ) : ℤ))) :
    EncJobLevel d n D K NumSlots mem' activeH livePts' idx S_birth snapPts prov S_parent spareResLive := by
  rcases hEnc with ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
    hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
    hw_bS, hw_dS, hw_spDS, hw_rS, hw_spRS,
    h6_bS, h6_dS, h6_spDS, h6_rS, h6_spRS,
    hb_pos, hw_bCard, hSeg_bS, hSlot_bS, hr_o, hPhases⟩
  let ball := applyBirthCoreFallback (1 / (4 * (D : ℝ) ^ 2)) snapPts S_birth prov
  have hspRS_toNat : (wRead mem 23 (((8 * idx + 6 : ℕ) : ℤ))).toNat = spRS := by rw [hw_spRS]; omega
  have hmem_bS : bS ∈ jobLevelSlotSet mem idx := by unfold jobLevelSlotSet; rw [hw_bS]; simp
  have hmem_dS : dS ∈ jobLevelSlotSet mem idx := by unfold jobLevelSlotSet; rw [hw_dS]; simp
  have hmem_spDS : spDS ∈ jobLevelSlotSet mem idx := by unfold jobLevelSlotSet; rw [hw_spDS]; simp
  have hmem_rS : rS ∈ jobLevelSlotSet mem idx := by unfold jobLevelSlotSet; rw [hw_rS]; simp
  have hmem_spRS : spRS ∈ jobLevelSlotSet mem idx := by unfold jobLevelSlotSet; rw [hw_spRS]; simp
  refine ⟨bS, dS, spDS, rS, spRS, hbS, hdS, hspDS, hrS, hspRS,
    hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR,
    by rw [hw23 2 (by omega), hw_bS],
    by rw [hw23 3 (by omega), hw_dS],
    by rw [hw23 4 (by omega), hw_spDS],
    by rw [hw23 5 (by omega), hw_rS],
    by rw [hw23 6 (by omega), hw_spRS],
    by rw [hsave_pres bS hmem_bS]; exact h6_bS,
    by rw [hsave_pres dS hmem_dS]; exact h6_dS,
    by rw [hsave_pres spDS hmem_spDS]; exact h6_spDS,
    by rw [hsave_pres rS hmem_rS]; exact h6_rS,
    by rw [hsave_pres spRS hmem_spRS]; exact h6_spRS,
    hb_pos,
    by rw [hw23 0 (by omega), hw_bCard],
    hseg_pres bS hmem_bS hbS (fun _ => by rw [hspRS_toNat]; exact hbspR) _ _ hSeg_bS,
    (hSlot_bS.congr_mem3 (hsave_pres bS hmem_bS) hw11 hr11).congr_pts_on hlive_act,
    fun c => by rw [hr23 c, hr_o c],
    ?_⟩
  rcases hPhases with ⟨cur, hcur, hph, hwcur, hwcore, hrV, hrmax, hlive⟩ |
                      ⟨cur, hcur, hph, hwcur, hrV, hEd, hEspD, hEr, hlive, hEspR⟩ |
                      ⟨hph, hrV, hEd, hEspD, hEr, hEspR⟩
  · left
    exact ⟨cur, hcur, by rw [hw24 0 (by omega), hph], by rw [hw24 1 (by omega), hwcur],
      by rw [hw23 1 (by omega), hwcore], by rw [hr24 0 (by omega), hrV],
      fun hne => by rw [hr24 1 (by omega), hrmax hne], hlive⟩
  · right; left
    have hres_eq : ball.residual livePts' (S_parent.filter (· < cur)) =
        ball.residual livePts (S_parent.filter (· < cur)) := by
      ext y; rw [mem_nodeResidual_iff_distSq_gt, mem_nodeResidual_iff_distSq_gt]
      exact and_congr_right fun hy => by rw [hlive_on y (Finset.mem_filter.mp hy).1]
    have hd_pres := hseg_pres dS hmem_dS hdS (fun _ => by rw [hspRS_toNat]; exact hdspR) _ _ hEd
    refine ⟨cur, hcur, by rw [hw24 0 (by omega), hph], by rw [hw24 1 (by omega), hwcur],
      by rw [hr24 0 (by omega), hrV],
      hd_pres.congr_mem_fSq rfl (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl)
        (fun y hy => by rw [hlive_on y (Finset.mem_filter.mp hy).1]),
      hseg_pres spDS hmem_spDS hspDS (fun _ => by rw [hspRS_toNat]; exact hspDspR) _ _ hEspD,
      by rw [hres_eq]; exact hseg_pres rS hmem_rS hrS (fun _ => by rw [hspRS_toNat]; exact hrspR) _ _ hEr,
      hlive,
      by rw [hres_eq]; exact hseg_pres spRS hmem_spRS hspRS (fun hf => by rw [hlive] at hf; cases hf) _ _ hEspR⟩
  · right; right
    have hres_eq : ball.residual livePts' S_parent = ball.residual livePts S_parent := by
      ext y; rw [mem_nodeResidual_iff_distSq_gt, mem_nodeResidual_iff_distSq_gt]
      exact and_congr_right fun hy => by rw [hlive_on y hy]
    have hd_pres := hseg_pres dS hmem_dS hdS (fun _ => by rw [hspRS_toNat]; exact hdspR) _ _ hEd
    refine ⟨by rw [hw24 0 (by omega), hph], by rw [hr24 0 (by omega), hrV],
      hd_pres.congr_mem_fSq rfl (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl) (fun _ _ => rfl)
        (fun y hy => by rw [hlive_on y hy]),
      hseg_pres spDS hmem_spDS hspDS (fun _ => by rw [hspRS_toNat]; exact hspDspR) _ _ hEspD,
      by rw [hres_eq]; exact hseg_pres rS hmem_rS hrS (fun _ => by rw [hspRS_toNat]; exact hrspR) _ _ hEr,
      fun hlive => by
        rw [hres_eq]
        exact hseg_pres spRS hmem_spRS hspRS (fun hf => by rw [hlive] at hf; cases hf) _ _ (hEspR hlive)⟩

lemma EncNodeHeaderAt.frame_other {d n : ℕ}
    {cfg : ChainHdrCfg} {p : P46Params d n} {m m' : ArithRAMMemory}
    {P : DynamicPointSet d} {r : ℕ} {node : ChainNode d}
    {birthCard snAge : ℕ} {S_r : Finset ℕ} {idle : Bool}
    (hH : EncNodeHeaderAt cfg p m P r node birthCard snAge S_r idle)
    (hw_bc : wRead m' cfg.snBirthCard.tag (cfg.snBirthCard.idx r : ℤ) =
             wRead m cfg.snBirthCard.tag (cfg.snBirthCard.idx r : ℤ))
    (hw_age : wRead m' cfg.snAge.tag (cfg.snAge.idx r : ℤ) =
              wRead m cfg.snAge.tag (cfg.snAge.idx r : ℤ))
    (hw14 : wRead m' 14 (r : ℤ) = wRead m 14 (r : ℤ))
    (hw15 : wRead m' 15 (r : ℤ) = wRead m 15 (r : ℤ))
    (hw6 : ∀ s ∈ snSlotSet m r, wRead m' 6 (s : ℤ) = wRead m 6 (s : ℤ))
    (hrO : ∀ c : Fin d, rRead m' cfg.rSnCenterO (((r * d + c.val : ℕ) : ℤ)) =
                        rRead m cfg.rSnCenterO (((r * d + c.val : ℕ) : ℤ)))
    (hrV : rRead m' cfg.rSnCenterV.tag (cfg.rSnCenterV.idx r : ℤ) =
           rRead m cfg.rSnCenterV.tag (cfg.rSnCenterV.idx r : ℤ))
    (hseg : ∀ s ∈ snSlotSet m r, s < p.NumSlots →
      ∀ S₁ fSq₁, EncSegSlot p.K_seg m s S₁ fSq₁ → EncSegSlot p.K_seg m' s S₁ fSq₁) :
    EncNodeHeaderAt cfg p m' P r node birthCard snAge S_r idle := by
  rcases hH with ⟨dS, spS, T_sp, hd0, hd_lt, hsp0, hsp_lt, hne,
    hbc, hage, h14, h15, h6d, h6sp, hO, hV, hSegD, hSegSp, hidle⟩
  have hd_in : dS ∈ snSlotSet m r := by unfold snSlotSet; rw [h14]; simp
  have hsp_in : spS ∈ snSlotSet m r := by unfold snSlotSet; rw [h15]; simp
  exact ⟨dS, spS, T_sp, hd0, hd_lt, hsp0, hsp_lt, hne,
    hw_bc.trans hbc, hw_age.trans hage, hw14.trans h14, hw15.trans h15,
    (hw6 dS hd_in).trans h6d, (hw6 spS hsp_in).trans h6sp,
    fun c => (hrO c).trans (hO c), hrV.trans hV,
    hseg dS hd_in hd_lt _ _ hSegD,
    hseg spS hsp_in hsp_lt _ _ hSegSp,
    hidle⟩

lemma EncOwnedJobAt.frame_other {d n L B_scan : ℕ}
    {cfg : ChainHdrCfg} {p : P46Params d n} {m m' : ArithRAMMemory}
    {P : DynamicPointSet d} {uMap : GhostUidMap d P}
    {r : ℕ} {S_r_h S_r_uid : Finset ℕ}
    {oj : Option (ActiveJobGhost d n (d + 3) L B_scan uMap.nextUid uMap.ghostCoords S_r_uid)}
    (hO : EncOwnedJobAt cfg p m P uMap r S_r_h S_r_uid oj)
    (hjLen_lt : ∀ g, oj = some g → g.lvs.length ≤ p.D₀)
    (hw16 : wRead m' 16 (r : ℤ) = wRead m 16 (r : ℤ))
    (hwRem : wRead m' cfg.jobRem.tag (cfg.jobRem.idx r : ℤ) =
             wRead m cfg.jobRem.tag (cfg.jobRem.idx r : ℤ))
    (hwCl : wRead m' cfg.jobClosed.tag (cfg.jobClosed.idx r : ℤ) =
            wRead m cfg.jobClosed.tag (cfg.jobClosed.idx r : ℤ))
    (hw19 : wRead m' 19 (r : ℤ) = wRead m 19 (r : ℤ))
    (hw23 : ∀ j < p.D₀, ∀ a < 8,
      wRead m' 23 (((8 * (r * p.D₀ + j) + a : ℕ) : ℤ)) =
      wRead m 23 (((8 * (r * p.D₀ + j) + a : ℕ) : ℤ)))
    (hw24 : ∀ j < p.D₀, ∀ a < 2,
      wRead m' 24 (((2 * (r * p.D₀ + j) + a : ℕ) : ℤ)) =
      wRead m 24 (((2 * (r * p.D₀ + j) + a : ℕ) : ℤ)))
    (hr23 : ∀ j < p.D₀, ∀ c : Fin d,
      rRead m' 23 ((((r * p.D₀ + j) * d + c.val : ℕ) : ℤ)) =
      rRead m 23 ((((r * p.D₀ + j) * d + c.val : ℕ) : ℤ)))
    (hr24 : ∀ j < p.D₀, ∀ a < 2,
      rRead m' 24 (((2 * (r * p.D₀ + j) + a : ℕ) : ℤ)) =
      rRead m 24 (((2 * (r * p.D₀ + j) + a : ℕ) : ℤ)))
    (hw6 : ∀ j < (wRead m 19 (r : ℤ)).toNat, wRead m 16 (r : ℤ) = 1 →
      ∀ s ∈ jobLevelSlotSet m (r * p.D₀ + j), wRead m' 6 (s : ℤ) = wRead m 6 (s : ℤ))
    (hseg : ∀ j < (wRead m 19 (r : ℤ)).toNat, wRead m 16 (r : ℤ) = 1 →
      let sp := decide (j + 1 = (wRead m 19 (r : ℤ)).toNat)
      ∀ s ∈ jobLevelSlotSet m (r * p.D₀ + j), s < p.NumSlots →
        (sp = false → s ≠ (wRead m 23 (((8 * (r * p.D₀ + j) + 6 : ℕ) : ℤ))).toNat) →
        ∀ S₁ fSq₁, EncSegSlot p.K_seg m s S₁ fSq₁ → EncSegSlot p.K_seg m' s S₁ fSq₁)
    (hw11 : ∀ idx, wRead m' 11 idx = wRead m 11 idx)
    (hr11 : ∀ idx, rRead m' 11 idx = rRead m 11 idx) :
    EncOwnedJobAt cfg p m' P uMap r S_r_h S_r_uid oj := by
  cases hoj : oj with
  | none =>
      rw [hoj] at hO
      change wRead m' 16 (r : ℤ) = 0
      exact hw16.trans hO
  | some g =>
      rw [hoj] at hO
      rcases hO with ⟨h16, hrem, hcl, h19, lvs_h, hlen_eq, hlv⟩
      have hlen_le : lvs_h.length ≤ p.D₀ := hlen_eq ▸ hjLen_lt g hoj
      have h19_nat : (wRead m 19 (r : ℤ)).toNat = lvs_h.length := by rw [h19, ← hlen_eq]; simp
      refine ⟨hw16.trans h16, hwRem.trans hrem, hwCl.trans hcl, hw19.trans h19, lvs_h, hlen_eq, ?_⟩
      intro j hj
      have hj_D0 : j < p.D₀ := lt_of_lt_of_le hj hlen_le
      have hj_19 : j < (wRead m 19 (r : ℤ)).toNat := h19_nat ▸ hj
      rcases hlv j hj with ⟨hb_eq, hor_eq, hbij, hEnc, hw7, hp2, hp3, hp4, hp5, hp6, hpre2, hlast⟩
      refine ⟨hb_eq, hor_eq, hbij, ?_,
        (hw23 j hj_D0 7 (by decide)).trans hw7,
        by rw [hw23 j hj_D0 2 (by decide)]; exact hp2,
        by rw [hw23 j hj_D0 3 (by decide)]; exact hp3,
        by rw [hw23 j hj_D0 4 (by decide)]; exact hp4,
        by rw [hw23 j hj_D0 5 (by decide)]; exact hp5,
        by rw [hw23 j hj_D0 6 (by decide)]; exact hp6,
        fun hlt => (hw24 j hj_D0 0 (by decide)).trans (hpre2 hlt),
        fun heq => ⟨(hw24 j hj_D0 0 (by decide)).trans (hlast heq).1,
                    (hw24 j hj_D0 1 (by decide)).trans (hlast heq).2.1,
                    (hlast heq).2.2⟩⟩
      exact hEnc.frame_slotSet (fun _ _ => rfl) (fun _ _ => rfl)
        (fun s hs hlt hnd S₁ fSq₁ hE => by
          have hsp_eq : decide (j + 1 = (wRead m 19 (r : ℤ)).toNat) = decide (j + 1 = lvs_h.length) := by
            rw [h19_nat]
          exact hseg j hj_19 h16 s hs hlt (hsp_eq ▸ hnd) S₁ fSq₁ hE)
        (fun s hs => hw6 j hj_19 h16 s hs)
        hw11 hr11
        (fun a ha => hw23 j hj_D0 a ha)
        (fun a ha => hw24 j hj_D0 a ha)
        (fun c => hr23 j hj_D0 c)
        (fun a ha => hr24 j hj_D0 a ha)

lemma EncTodoJobAt.frame_other {ctx : MidLoopCtx} {m m' : ArithRAMMemory}
    {r : Fin ctx.st₀.k}
    (hT : EncTodoJobAt ctx m r)
    (hw16 : wRead m' 16 (r.val : ℤ) = wRead m 16 (r.val : ℤ))
    (hwRem : wRead m' ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r.val : ℤ) =
             wRead m ctx.cfg.jobRem.tag (ctx.cfg.jobRem.idx r.val : ℤ))
    (hwCl : wRead m' ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r.val : ℤ) =
            wRead m ctx.cfg.jobClosed.tag (ctx.cfg.jobClosed.idx r.val : ℤ))
    (hw19 : wRead m' 19 (r.val : ℤ) = wRead m 19 (r.val : ℤ))
    (hw23 : ∀ j < ctx.p.D₀, ∀ a < 8,
      wRead m' 23 (((8 * (r.val * ctx.p.D₀ + j) + a : ℕ) : ℤ)) =
      wRead m 23 (((8 * (r.val * ctx.p.D₀ + j) + a : ℕ) : ℤ)))
    (hw24 : ∀ j < ctx.p.D₀, ∀ a < 2,
      wRead m' 24 (((2 * (r.val * ctx.p.D₀ + j) + a : ℕ) : ℤ)) =
      wRead m 24 (((2 * (r.val * ctx.p.D₀ + j) + a : ℕ) : ℤ)))
    (hr23 : ∀ j < ctx.p.D₀, ∀ c : Fin ctx.d,
      rRead m' 23 ((((r.val * ctx.p.D₀ + j) * ctx.d + c.val : ℕ) : ℤ)) =
      rRead m 23 ((((r.val * ctx.p.D₀ + j) * ctx.d + c.val : ℕ) : ℤ)))
    (hr24 : ∀ j < ctx.p.D₀, ∀ a < 2,
      rRead m' 24 (((2 * (r.val * ctx.p.D₀ + j) + a : ℕ) : ℤ)) =
      rRead m 24 (((2 * (r.val * ctx.p.D₀ + j) + a : ℕ) : ℤ)))
    (hw6 : ∀ j < (wRead m 19 (r.val : ℤ)).toNat, wRead m 16 (r.val : ℤ) = 1 →
      ∀ s ∈ jobLevelSlotSet m (r.val * ctx.p.D₀ + j), wRead m' 6 (s : ℤ) = wRead m 6 (s : ℤ))
    (hseg : ∀ j < (wRead m 19 (r.val : ℤ)).toNat, wRead m 16 (r.val : ℤ) = 1 →
      let sp := decide (j + 1 = (wRead m 19 (r.val : ℤ)).toNat)
      ∀ s ∈ jobLevelSlotSet m (r.val * ctx.p.D₀ + j), s < ctx.p.NumSlots →
        (sp = false → s ≠ (wRead m 23 (((8 * (r.val * ctx.p.D₀ + j) + 6 : ℕ) : ℤ))).toNat) →
        ∀ S₁ fSq₁, EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁)
    (hw11 : ∀ idx, wRead m' 11 idx = wRead m 11 idx)
    (hr11 : ∀ idx, rRead m' 11 idx = rRead m 11 idx) :
    EncTodoJobAt ctx m' r := by
  unfold EncTodoJobAt at hT ⊢
  cases hoj : ctx.st₀.ownedJob r with
  | none =>
      rw [hoj] at hT
      exact hw16.trans hT
  | some g =>
      rw [hoj] at hT
      rcases hT with ⟨h16, hrem, hcl, h19, lvs_h, hlen_eq, hlv⟩
      have hlen_le : lvs_h.length ≤ ctx.p.D₀ := by
        rw [hlen_eq, ctx.hD0_eq]
        exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2)
      have h19_nat : (wRead m 19 (r.val : ℤ)).toNat = lvs_h.length := by rw [h19, ← hlen_eq]; simp
      refine ⟨hw16.trans h16, hwRem.trans hrem, hwCl.trans hcl, hw19.trans h19, lvs_h, hlen_eq, ?_⟩
      intro j hj
      have hj_D0 : j < ctx.p.D₀ := lt_of_lt_of_le hj hlen_le
      have hj_19 : j < (wRead m 19 (r.val : ℤ)).toNat := h19_nat ▸ hj
      rcases hlv j hj with ⟨hb_eq, hor_eq, hbij, hEnc, hw7, hp2, hp3, hp4, hp5, hp6, hpre2, hlast⟩
      refine ⟨hb_eq, hor_eq, hbij, ?_,
        (hw23 j hj_D0 7 (by decide)).trans hw7,
        by rw [hw23 j hj_D0 2 (by decide)]; exact hp2,
        by rw [hw23 j hj_D0 3 (by decide)]; exact hp3,
        by rw [hw23 j hj_D0 4 (by decide)]; exact hp4,
        by rw [hw23 j hj_D0 5 (by decide)]; exact hp5,
        by rw [hw23 j hj_D0 6 (by decide)]; exact hp6,
        fun hlt => (hw24 j hj_D0 0 (by decide)).trans (hpre2 hlt),
        fun heq => ⟨(hw24 j hj_D0 0 (by decide)).trans (hlast heq).1,
                    (hw24 j hj_D0 1 (by decide)).trans (hlast heq).2.1,
                    (hlast heq).2.2⟩⟩
      exact hEnc.frame_slotSet (fun _ _ => rfl) (fun _ _ => rfl)
        (fun s hs hlt hnd S₁ fSq₁ hE => by
          have hsp_eq : decide (j + 1 = (wRead m 19 (r.val : ℤ)).toNat) = decide (j + 1 = lvs_h.length) := by
            rw [h19_nat]
          exact hseg j hj_19 h16 s hs hlt (hsp_eq ▸ hnd) S₁ fSq₁ hE)
        (fun s hs => hw6 j hj_19 h16 s hs)
        hw11 hr11
        (fun a ha => hw23 j hj_D0 a ha)
        (fun a ha => hw24 j hj_D0 a ha)
        (fun c => hr23 j hj_D0 c)
        (fun a ha => hr24 j hj_D0 a ha)

/-! ### 2. Small-Input Truncation Transition (`MidLoopUncut` → `MidLoopCut`) -/

lemma EncOwnedJobAt.castPool {d n L B_scan : ℕ}
    {cfg : ChainHdrCfg} {p : P46Params d n} {mem : ArithRAMMemory}
    {P : DynamicPointSet d} {uMap : GhostUidMap d P}
    {r : ℕ} {S_r_h S₁ S₂ : Finset ℕ} (hS : S₁ = S₂)
    {g : ActiveJobGhost d n (d + 3) L B_scan uMap.nextUid uMap.ghostCoords S₁}
    (hO : EncOwnedJobAt cfg p mem P uMap r S_r_h S₁ (some g)) :
    EncOwnedJobAt cfg p mem P uMap r S_r_h S₂ (some (g.castPool hS)) := by
  subst hS; exact hO

theorem midLoopCut_of_truncateSmall {ctx : MidLoopCtx} {gFlag : Bool} {i : ℕ}
    (hi : i < ctx.st₀.k) {m m' : ArithRAMMemory}
    (hU : MidLoopUncut ctx gFlag i m)
    (hnone : ctx.st₀.ownedJob ⟨i, hi⟩ = none)
    (hsmall : (ctx.S_post_h ⟨i, hi⟩).card ≤ 4 * ctx.p.L)
    (hw26_27 : wRead m' 26 27 = 1)
    (hw1_5 : wRead m' 1 5 = (i : ℤ))
    (hw1_6 : wRead m' 1 6 = wRead m 15 (i : ℤ))
    (hw1_3 : wRead m' 1 3 = wRead m 1 3)
    (hw_other : ∀ t, t ≠ 1 → t ≠ 26 → ∀ idx, wRead m' t idx = wRead m t idx)
    (hr_other : ∀ t, t ≠ 27 → ∀ idx, rRead m' t idx = rRead m t idx) :
    MidLoopCut ctx gFlag m' := by
  classical
  rcases hU with ⟨_, hGood₀, hSeg, hSave, hLive, _, hw60, hSeg0,
    leafS, _, _, _, _, _, hDisj, hDone, hTodo⟩
  let r_cut : Fin ctx.st₀.k := ⟨i, hi⟩
  rcases (hTodo r_cut le_rfl).2.1 with
    ⟨dS_i, spS_i, T_sp_i, _, _, hsp0, hsp_lt, _, _, _, hw14_i, hw15_i, _, h6sp_i, _, _, _, hSegSp_i, hidle_i⟩
  have hidle_true : (ctx.st₀.ownedJob r_cut).isNone = true := by rw [hnone]; rfl
  have hT_eq : T_sp_i = ctx.S_post_h r_cut := hidle_i hidle_true
  subst hT_eq
  let nodes_mid : Fin i → ChainNode ctx.d :=
    fun j => ctx.st₀.nodes ⟨j.val, lt_trans j.isLt hi⟩
  have hpre_h : ∀ j : Fin i,
      ctx.S_post_h ⟨j.val, lt_trans j.isLt hi⟩ =
        chainInput ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles j.castSucc := by
    intro j
    exact cg01_chainInput_congr_prefix ctx.st₀.nodes nodes_mid (fun _ _ => rfl)
      j.val (le_of_lt (lt_trans j.isLt hi)) (le_of_lt j.isLt) (fun _ _ => rfl)
  have hpre_u : ∀ j : Fin i,
      ctx.S_post_u ⟨j.val, lt_trans j.isLt hi⟩ =
        chainInput ctx.uMap'.ghostCoords nodes_mid ctx.uMap'.ActiveUids j.castSucc := by
    intro j
    exact cg01_chainInput_congr_prefix ctx.st₀.nodes nodes_mid (fun _ _ => rfl)
      j.val (le_of_lt (lt_trans j.isLt hi)) (le_of_lt j.isLt) (fun _ _ => rfl)
  have hterm_h : chainTerminal ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles =
      ctx.S_post_h r_cut := by
    rw [cg01_chainTerminal_eq]
    exact cg01_chainInput_congr_prefix nodes_mid ctx.st₀.nodes (fun _ _ => rfl)
      i le_rfl (le_of_lt hi) (fun _ _ => rfl)
  have hoj_ex : ∀ j : Fin i,
      ∃ oj : Option (ActiveJobGhost ctx.d ctx.n (ctx.d + 3) ctx.p.L ctx.p.B_scan
          ctx.uMap'.nextUid ctx.uMap'.ghostCoords
          (chainInput ctx.uMap'.ghostCoords nodes_mid ctx.uMap'.ActiveUids j.castSucc)),
        ServingOwnedJobInv (ctx.st₀.birthSnap ⟨j.val, lt_trans j.isLt hi⟩)
          (ctx.snAge' ⟨j.val, lt_trans j.isLt hi⟩) oj ∧
        (gFlag = true → ∀ g, oj = some g → JobLevelsCenterGood (ctx.d + 3) ctx.uMap'.ghostCoords g.lvs) ∧
        EncNodeHeaderAt ctx.cfg ctx.p m ctx.P' j.val (nodes_mid j)
          (ctx.st₀.birthSnap ⟨j.val, lt_trans j.isLt hi⟩).card
          (ctx.snAge' ⟨j.val, lt_trans j.isLt hi⟩)
          (chainInput ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles j.castSucc) oj.isNone ∧
        EncOwnedJobAt ctx.cfg ctx.p m ctx.P' ctx.uMap' j.val
          (chainInput ctx.P'.handleCoords nodes_mid ctx.P'.activeHandles j.castSucc)
          (chainInput ctx.uMap'.ghostCoords nodes_mid ctx.uMap'.ActiveUids j.castSucc) oj := by
    intro j
    let j_old : Fin ctx.st₀.k := ⟨j.val, lt_trans j.isLt hi⟩
    rcases hDone j_old j.isLt with ⟨oj₀, hInv₀, hGood_j, hHdr_j, hOwn_j⟩
    rw [hpre_h j] at hHdr_j hOwn_j
    cases hoj₀ : oj₀ with
    | none =>
        rw [hoj₀] at hInv₀ hGood_j hHdr_j hOwn_j
        exact ⟨none, hInv₀, (fun _ _ h => by cases h), hHdr_j, hOwn_j⟩
    | some g₀ =>
        rw [hoj₀] at hInv₀ hGood_j hHdr_j hOwn_j
        let g₁ := g₀.castPool (hpre_u j)
        have hInv₁ : ServingOwnedJobInv (ctx.st₀.birthSnap j_old) (ctx.snAge' j_old) (some g₁) :=
          (servingOwnedJobInv_castPool (hpre_u j) _ _ (some g₀)).mpr hInv₀
        refine ⟨some g₁, hInv₁, ?_, hHdr_j, hOwn_j.castPool (hpre_u j)⟩
        intro hgF g hg
        injection hg with hgeq; subst hgeq
        exact hGood_j hgF g₀ rfl
  choose oj_fn hoj_fn using hoj_ex
  let st_mid : PureServingState ctx.d ctx.n ctx.H ctx.p.L ctx.p.B_scan ctx.P' :=
    { uMap := ctx.uMap'
      k := i
      nodes := nodes_mid
      birthSnap := fun j => ctx.st₀.birthSnap ⟨j.val, lt_trans j.isLt hi⟩
      snAge := fun j => ctx.snAge' ⟨j.val, lt_trans j.isLt hi⟩
      trueAge := fun j => ctx.trueAge' ⟨j.val, lt_trans j.isLt hi⟩
      ownedJob := oj_fn }
  have hinv₀ := ctx.hwf₀.1
  have hNodesInv : st_mid.NodesInv := by
    intro j
    let j_old : Fin ctx.st₀.k := ⟨j.val, lt_trans j.isLt hi⟩
    rcases hinv₀ j_old with ⟨hb_pos, hb_uid, hb_pass, _, _, _⟩
    refine ⟨hb_pos,
      fun u hu => lt_of_lt_of_le (hb_uid u hu) ctx.hle_uid,
      (passesBirthCoreCheck_congr_on _ _ (fun u hu => ctx.hag_uid u (hb_uid u hu))).mpr hb_pass,
      ctx.htr_le' j_old,
      (hpre_u j) ▸ ctx.hhas_age' j_old,
      (hoj_fn j).1⟩
  have hGood_mid : gFlag = true → st_mid.AllCentersGood := by
    intro hgF
    refine ⟨fun j => ?_, fun j g hg => (hoj_fn j).2.1 hgF g hg⟩
    let j_old : Fin ctx.st₀.k := ⟨j.val, lt_trans j.isLt hi⟩
    exact (isCenterpoint_paraboloid_congr_on _ _
      (fun u hu => ctx.hag_uid u ((hinv₀ j_old).2.1 u hu))).mpr (hGood₀ hgF j_old)
  have hSeg' : SegGenBound ctx.p.K_seg ctx.p.NumSlots m' :=
    ⟨by rw [hw1_3]; exact hSeg.1,
     fun s hs => by rw [hw_other 5 (by decide) (by decide), hw1_3]; exact hSeg.2.1 s hs,
     fun s hs u hu => by rw [hw_other 8 (by decide) (by decide), hw1_3]; exact hSeg.2.2 s hs u hu⟩
  have hSave' : SaveGenBound ctx.n ctx.p.NumSlots m' :=
    ⟨by rw [hw1_3]; exact hSave.1,
     fun s hs => by rw [hw_other 6 (by decide) (by decide), hw1_3]; exact hSave.2.1 s hs,
     fun s hs h hh => by rw [hw_other 11 (by decide) (by decide), hw1_3]; exact hSave.2.2 s hs h hh⟩
  have hLive' : EncLiveCoords ctx.d ctx.n m' ctx.P'.activeHandles ctx.P'.handleCoords :=
    ⟨hLive.1, fun h hh c => by rw [hr_other 4 (by decide)]; exact hLive.2 h hh c⟩
  have hSegPres : ∀ s < ctx.p.NumSlots, ∀ S₁ fSq₁,
      EncSegSlot ctx.p.K_seg m s S₁ fSq₁ → EncSegSlot ctx.p.K_seg m' s S₁ fSq₁ :=
    fun s _ S₁ fSq₁ hE => hE.congr_mem_fSq
      (hw_other 5 (by decide) (by decide) _)
      (fun _ _ => hw_other 8 (by decide) (by decide) _)
      (fun _ _ => hw_other 9 (by decide) (by decide) _)
      (fun _ _ => hw_other 10 (by decide) (by decide) _)
      (fun _ _ => hr_other 8 (by decide) _)
      (fun _ _ => rfl)
  have hsp_in_i : spS_i ∈ snSlotSet m i := by unfold snSlotSet; rw [hw15_i]; simp
  have hDisj' : GlobalSlotDisj ctx.p.D₀ m' i spS_i := by
    rcases hDisj with ⟨_, hsn0, hsnP, hlv_sn, hlv_lv⟩
    have hsn_eq : ∀ r, snSlotSet m' r = snSlotSet m r :=
      fun r => snSlotSet_congr_14_15
        (hw_other 14 (by decide) (by decide) _) (hw_other 15 (by decide) (by decide) _)
    have h16_eq : ∀ r, wRead m' 16 (r : ℤ) = wRead m 16 (r : ℤ) :=
      fun r => hw_other 16 (by decide) (by decide) _
    have h19_eq : ∀ r, wRead m' 19 (r : ℤ) = wRead m 19 (r : ℤ) :=
      fun r => hw_other 19 (by decide) (by decide) _
    have h23_eq : ∀ idx, wRead m' 23 idx = wRead m 23 idx :=
      fun idx => hw_other 23 (by decide) (by decide) idx
    have hlv_eq : ∀ idx sp, jobLevelLiveSlots m' idx sp = jobLevelLiveSlots m idx sp :=
      fun idx sp => jobLevelLiveSlots_congr_23 (h23_eq _) (h23_eq _) (h23_eq _) (h23_eq _)
    refine ⟨hsp0, ?_, ?_, ?_, ?_⟩
    · intro r hr s hs
      rw [hsn_eq r] at hs
      have hne_ri : r ≠ i := by omega
      have hdisj_ri := hsnP r (lt_trans hr hi) i hi hne_ri
      exact ⟨(hsn0 r (lt_trans hr hi) s hs).1,
        fun heq => Finset.disjoint_left.mp hdisj_ri hs (heq ▸ hsp_in_i)⟩
    · intro r₁ hr₁ r₂ hr₂ hne
      rw [hsn_eq r₁, hsn_eq r₂]
      exact hsnP r₁ (lt_trans hr₁ hi) r₂ (lt_trans hr₂ hi) hne
    · intro r hr h16 j hj
      dsimp only
      rw [h16_eq r] at h16; rw [h19_eq r] at hj ⊢; rw [hlv_eq]
      rcases hlv_sn r (lt_trans hr hi) h16 j hj with ⟨h0l, hdisj_sn⟩
      refine ⟨fun s hs => ⟨(h0l s hs).1,
        fun heq => Finset.disjoint_left.mp (hdisj_sn i hi) hs (heq ▸ hsp_in_i)⟩, ?_⟩
      intro r' hr'
      rw [hsn_eq r']
      exact hdisj_sn r' (lt_trans hr' hi)
    · intro r₁ hr₁ h16₁ j₁ hj₁ r₂ hr₂ h16₂ j₂ hj₂ hne
      rw [h16_eq r₁] at h16₁; rw [h16_eq r₂] at h16₂
      rw [h19_eq r₁] at hj₁ ⊢; rw [h19_eq r₂] at hj₂ ⊢
      rw [hlv_eq, hlv_eq, h23_eq, h23_eq]
      exact hlv_lv r₁ (lt_trans hr₁ hi) h16₁ j₁ hj₁ r₂ (lt_trans hr₂ hi) h16₂ j₂ hj₂ hne
  refine ⟨hw26_27, st_mid, rfl, hNodesInv, ?_, ?_, hGood_mid⟩
  · rw [hterm_h]; exact le_trans hsmall (by omega)
  · refine ⟨le_of_lt (lt_trans hi ctx.origK_lt_D0), hSeg', hSave', hLive',
      hw1_5, by rw [hw_other 6 (by decide) (by decide)]; exact hw60,
      hSegPres 0 (by have := ctx.hSlots_cap; omega) _ _ hSeg0,
      spS_i, hsp0, hsp_lt, hw1_6.trans hw15_i,
      by rw [hw_other 6 (by decide) (by decide)]; exact h6sp_i,
      hterm_h.symm ▸ hSegPres spS_i hsp_lt _ _ hSegSp_i,
      hDisj', ?_⟩
    intro j
    have hV := ctx.hV
    have hbc_ne1 := tag_ne_of_not_reserved (u := 1) hV.2.2.2.2.2.2.1 (by decide)
    have hbc_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.1 (by decide)
    have hage_ne1 := tag_ne_of_not_reserved (u := 1) hV.2.2.2.2.2.2.2.1 (by decide)
    have hage_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.1 (by decide)
    have hrem_ne1 := tag_ne_of_not_reserved (u := 1) hV.2.2.2.2.2.2.2.2.2.1 (by decide)
    have hrem_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.1 (by decide)
    have hcl_ne1 := tag_ne_of_not_reserved (u := 1) hV.2.2.2.2.2.2.2.2.2.2.1 (by decide)
    have hcl_ne26 := tag_ne_of_not_reserved (u := 26) hV.2.2.2.2.2.2.2.2.2.2.1 (by decide)
    have hrO_ne27 := rtag_ne_of_not_reserved (u := 27) hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1 (by decide)
    have hrV_ne27 := rtag_ne_of_not_reserved (u := 27) hV.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2.2 (by decide)
    refine ⟨(hoj_fn j).2.2.1.frame_other
        (hw_other _ hbc_ne1 hbc_ne26 _)
        (hw_other _ hage_ne1 hage_ne26 _)
        (hw_other 14 (by decide) (by decide) _)
        (hw_other 15 (by decide) (by decide) _)
        (fun _ _ => hw_other 6 (by decide) (by decide) _)
        (fun _ => hr_other _ hrO_ne27 _)
        (hr_other _ hrV_ne27 _)
        (fun s _ hlt S₁ fSq₁ hE => hSegPres s hlt S₁ fSq₁ hE),
      (hoj_fn j).2.2.2.frame_other
        (fun g hg => by
          rw [ctx.hD0_eq]
          exact le_of_lt (g.lvs_length_lt ctx.hH5 ctx.hn2))
        (hw_other 16 (by decide) (by decide) _)
        (hw_other _ hrem_ne1 hrem_ne26 _)
        (hw_other _ hcl_ne1 hcl_ne26 _)
        (hw_other 19 (by decide) (by decide) _)
        (fun _ _ _ _ => hw_other 23 (by decide) (by decide) _)
        (fun _ _ _ _ => hw_other 24 (by decide) (by decide) _)
        (fun _ _ _ => hr_other 23 (by decide) _)
        (fun _ _ _ _ => hr_other 24 (by decide) _)
        (fun _ _ _ _ _ => hw_other 6 (by decide) (by decide) _)
        (fun _ _ _ s _ hlt _ S₁ fSq₁ hE => hSegPres s hlt S₁ fSq₁ hE)
        (fun _ => hw_other 11 (by decide) (by decide) _)
        (fun _ => hr_other 11 (by decide) _)⟩

end UL.Proof_lem_7_2_RacerP46
