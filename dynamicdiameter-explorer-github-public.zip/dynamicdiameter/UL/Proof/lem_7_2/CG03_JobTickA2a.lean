import UL.Proof.lem_7_2.CG03_JobTickA1

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

lemma EncSlotCoords.congr_mem3 {d n : ℕ} {m m' : ArithRAMMemory}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {s : ℕ} {S : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    (h : EncSlotCoords d n m activeH livePts s S snapPts)
    (hw6 : wRead m' 6 (s : ℤ) = wRead m 6 (s : ℤ))
    (hw11 : ∀ i, wRead m' 11 i = wRead m 11 i)
    (hr11 : ∀ i, rRead m' 11 i = rRead m 11 i) :
    EncSlotCoords d n m' activeH livePts s S snapPts := by
  rcases h with ⟨hlt, h0 | ⟨h1, hsaved⟩⟩
  · exact ⟨hlt, Or.inl ⟨by rw [hw6]; exact h0.1, h0.2⟩⟩
  · refine ⟨hlt, Or.inr ⟨by rw [hw6]; exact h1, fun x hx => ?_⟩⟩
    rw [hw11, hw6]
    rcases hsaved x hx with ⟨heq, hne⟩
    exact ⟨fun he c => by rw [hr11]; exact heq he c, hne⟩

/-! ### 1. Fresh 4-Slot and 5-Slot Allocation Subroutines (`freshAllocFourSlotsStmt`, `freshAllocFiveSlotsStmt`) -/

def freshAllocFourSlotsStmt (D₀ NumSlots M_box : ℕ) : ArithRAMStmt :=
  seqList [
    gcSlotInUseStmt D₀ NumSlots M_box,
    allocMarkAndResetSlotStmt NumSlots M_box 20,
    allocMarkAndResetSlotStmt NumSlots M_box 21,
    allocMarkAndResetSlotStmt NumSlots M_box 22,
    allocMarkAndResetSlotStmt NumSlots M_box 23
  ]

def freshAllocFiveSlotsStmt (D₀ NumSlots M_box : ℕ) : ArithRAMStmt :=
  seqList [
    freshAllocFourSlotsStmt D₀ NumSlots M_box,
    allocMarkAndResetSlotStmt NumSlots M_box 19
  ]

theorem boxSafe_freshAllocFourSlotsStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (D₀ NumSlots : ℕ) :
    BoxSafeOuter T_max M_box (freshAllocFourSlotsStmt D₀ NumSlots M_box) := by
  unfold freshAllocFourSlotsStmt
  apply boxSafeOuter_seqList
  intro s hs; simp only [List.mem_cons, List.not_mem_nil, or_false] at hs
  rcases hs with rfl | rfl | rfl | rfl | rfl
  · exact boxSafe_gcSlotInUseStmt (by omega) D₀ NumSlots
  · exact boxSafe_allocMarkAndResetSlotStmt hT NumSlots 20
  · exact boxSafe_allocMarkAndResetSlotStmt hT NumSlots 21
  · exact boxSafe_allocMarkAndResetSlotStmt hT NumSlots 22
  · exact boxSafe_allocMarkAndResetSlotStmt hT NumSlots 23

theorem boxSafe_freshAllocFiveSlotsStmt {T_max M_box : ℕ} (hT : 27 ≤ T_max) (D₀ NumSlots : ℕ) :
    BoxSafeOuter T_max M_box (freshAllocFiveSlotsStmt D₀ NumSlots M_box) :=
  .seq (boxSafe_freshAllocFourSlotsStmt hT D₀ NumSlots)
       (boxSafe_allocMarkAndResetSlotStmt hT NumSlots 19)

def freshAllocFourCost (D₀ NumSlots : ℕ) : ℕ :=
  (40 * NumSlots + 300 * (D₀ + 1) * (D₀ + 1) + 200) + 4 * (35 * (NumSlots + 1) + 200)

def freshAllocFiveCost (D₀ NumSlots : ℕ) : ℕ :=
  freshAllocFourCost D₀ NumSlots + (35 * (NumSlots + 1) + 200)

private lemma zero_mem_activeSlotSet (mem : ArithRAMMemory) (D₀ : ℕ) :
    0 ∈ activeSlotSet mem D₀ := by
  unfold activeSlotSet
  exact Finset.mem_insert_self 0 _

private lemma filter_card_lt_of_card_lt {U : Finset ℕ} {NumSlots : ℕ} (h : U.card < NumSlots) :
    (U.filter (· < NumSlots)).card < NumSlots :=
  lt_of_le_of_lt (Finset.card_filter_le _ _) h

theorem exec_freshAllocFourSlotsStmt {d n K D₀ NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {chainLen leafS : ℕ}
    (hSlots_cap : 8 * (D₀ + 2) ^ 2 ≤ NumSlots)
    (hBox26 : 30 ≤ M_box)
    (hBox_slots : NumSlots ≤ M_box)
    (hcL_le : chainLen ≤ D₀)
    (hw_cL : wRead mem 1 5 = (chainLen : ℤ))
    (hleaf_lt : leafS < NumSlots)
    (hw_leaf : wRead mem 1 6 = (leafS : ℤ))
    (hsn_lt : ∀ r < chainLen,
      ∃ (dS spS : ℕ), dS < NumSlots ∧ spS < NumSlots ∧
        wRead mem 14 (r : ℤ) = (dS : ℤ) ∧ wRead mem 15 (r : ℤ) = (spS : ℤ))
    (hjob_lt : ∀ r < chainLen, wRead mem 16 (r : ℤ) = 1 →
      ∃ (jLen : ℕ), jLen ≤ D₀ ∧ wRead mem 19 (r : ℤ) = (jLen : ℤ) ∧
        ∀ j < jLen,
          ∃ (s2 s3 s4 s5 s6 : ℕ),
            s2 < NumSlots ∧ s3 < NumSlots ∧ s4 < NumSlots ∧ s5 < NumSlots ∧ s6 < NumSlots ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 2 : ℕ) : ℤ)) = (s2 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 3 : ℕ) : ℤ)) = (s3 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 4 : ℕ) : ℤ)) = (s4 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 5 : ℕ) : ℤ)) = (s5 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 6 : ℕ) : ℤ)) = (s6 : ℤ))
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem) :
    let U₀ := activeSlotSet mem D₀
    ∃ (m' : ArithRAMMemory) (dS spDS rS spRS : ℕ),
      DetExecAt 0 inp (freshAllocFourSlotsStmt D₀ NumSlots M_box) mem m'
        (freshAllocFourCost D₀ NumSlots) ∧
      m'.popDepth 0 = m' ∧
      0 < dS ∧ dS < NumSlots ∧ dS ∉ U₀ ∧
      0 < spDS ∧ spDS < NumSlots ∧ spDS ∉ U₀ ∧
      0 < rS ∧ rS < NumSlots ∧ rS ∉ U₀ ∧
      0 < spRS ∧ spRS < NumSlots ∧ spRS ∉ U₀ ∧
      dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧ spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS ∧
      wRead m' 26 20 = (dS : ℤ) ∧
      wRead m' 26 21 = (spDS : ℤ) ∧
      wRead m' 26 22 = (rS : ℤ) ∧
      wRead m' 26 23 = (spRS : ℤ) ∧
      wRead m' 6 (dS : ℤ) = 0 ∧
      wRead m' 6 (spDS : ℤ) = 0 ∧
      wRead m' 6 (rS : ℤ) = 0 ∧
      wRead m' 6 (spRS : ℤ) = 0 ∧
      (∀ s < NumSlots,
        wRead m' 7 (s : ℤ) = if s ∈ insert spRS (insert rS (insert spDS (insert dS U₀))) then 1 else 0) ∧
      SegGenBound K NumSlots m' ∧
      SaveGenBound n NumSlots m' ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' dS ∅ fSq) ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' spDS ∅ fSq) ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' rS ∅ fSq) ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' spRS ∅ fSq) ∧
      (∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ (activeH : Finset ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d)),
        ∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
          ∀ S₁ sp₁, EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
            EncSlotCoords d n m' activeH livePts s' S₁ sp₁) ∧
      (∀ s' : ℤ, s' ≠ (dS : ℤ) → s' ≠ (spDS : ℤ) → s' ≠ (rS : ℤ) → s' ≠ (spRS : ℤ) →
        wRead m' 6 s' = wRead mem 6 s') ∧
      (∀ t, t ≠ 1 → t ≠ 5 → t ≠ 6 → t ≠ 7 → t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 3 → wRead m' 1 i = wRead mem 1 i) ∧
      (∀ i, i ≠ 20 → i ≠ 21 → i ≠ 22 → i ≠ 23 → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) := by
  intro U₀
  have hSlots_pos : 1 ≤ NumSlots := by nlinarith
  have hcL_toNat : (wRead mem 1 5).toNat ≤ D₀ := by rw [hw_cL]; omega
  have hjL_toNat : ∀ r < (wRead mem 1 5).toNat,
      wRead mem 16 (r : ℤ) = 1 → (wRead mem 19 (r : ℤ)).toNat ≤ D₀ := by
    intro r hr h16
    rw [hw_cL, Int.toNat_natCast] at hr
    rcases hjob_lt r hr h16 with ⟨jL, hjL_le, hw19, _⟩
    rw [hw19]; omega
  have hU0_add5 : U₀.card + 5 ≤ NumSlots :=
    (activeSlotSet_card_add5_le hcL_toNat hjL_toNat).trans hSlots_cap
  have h0_U0 : 0 ∈ U₀ := zero_mem_activeSlotSet mem D₀
  rcases exec_gcSlotInUseStmt inp mem hSlots_pos hBox_slots hcL_le hw_cL hleaf_lt hw_leaf hsn_lt hjob_lt
    with ⟨m0, hd0, hp0, hmap0, hwo0, hro0⟩
  have hseg0 : SegGenBound K NumSlots m0 :=
    ⟨by rw [hwo0 1 (by decide)]; exact hseg.1,
     fun s hs => by rw [hwo0 5 (by decide), hwo0 1 (by decide)]; exact hseg.2.1 s hs,
     fun s hs u hu => by rw [hwo0 8 (by decide), hwo0 1 (by decide)]; exact hseg.2.2 s hs u hu⟩
  have hsave0 : SaveGenBound n NumSlots m0 :=
    ⟨by rw [hwo0 1 (by decide)]; exact hsave.1,
     fun s hs => by rw [hwo0 6 (by decide), hwo0 1 (by decide)]; exact hsave.2.1 s hs,
     fun s hs h hh => by rw [hwo0 11 (by decide), hwo0 1 (by decide)]; exact hsave.2.2 s hs h hh⟩
  rcases exec_allocMarkAndResetSlotStmt (destReg := 20) inp m0 (used := U₀)
      (filter_card_lt_of_card_lt (by omega)) hmap0 (by omega) (by omega) hBox_slots hseg0 hsave0
    with ⟨m1, dS, hd1, _, hdS_lt, hdS_not, hw20_1, hw6_dS_1, hmap1, hseg1, hsave1,
          hEmpty_dS_1, hSeg_fr1, hSlot_fr1, hw6_fr1, hwo1, hw1_1, hw26_1, hro1⟩
  let U₁ := insert dS U₀
  have hU1_card : U₁.card ≤ U₀.card + 1 := Finset.card_insert_le _ _
  rcases exec_allocMarkAndResetSlotStmt (destReg := 21) inp m1 (used := U₁)
      (filter_card_lt_of_card_lt (by omega)) hmap1 (by omega) (by omega) hBox_slots hseg1 hsave1
    with ⟨m2, spDS, hd2, _, hspDS_lt, hspDS_not1, hw21_2, hw6_spDS_2, hmap2, hseg2, hsave2,
          hEmpty_spDS_2, hSeg_fr2, hSlot_fr2, hw6_fr2, hwo2, hw1_2, hw26_2, hro2⟩
  let U₂ := insert spDS U₁
  have hU2_card : U₂.card ≤ U₁.card + 1 := Finset.card_insert_le _ _
  rcases exec_allocMarkAndResetSlotStmt (destReg := 22) inp m2 (used := U₂)
      (filter_card_lt_of_card_lt (by omega)) hmap2 (by omega) (by omega) hBox_slots hseg2 hsave2
    with ⟨m3, rS, hd3, _, hrS_lt, hrS_not2, hw22_3, hw6_rS_3, hmap3, hseg3, hsave3,
          hEmpty_rS_3, hSeg_fr3, hSlot_fr3, hw6_fr3, hwo3, hw1_3, hw26_3, hro3⟩
  let U₃ := insert rS U₂
  have hU3_card : U₃.card ≤ U₂.card + 1 := Finset.card_insert_le _ _
  rcases exec_allocMarkAndResetSlotStmt (destReg := 23) inp m3 (used := U₃)
      (filter_card_lt_of_card_lt (by omega)) hmap3 (by omega) (by omega) hBox_slots hseg3 hsave3
    with ⟨m4, spRS, hd4, hp4, hspRS_lt, hspRS_not3, hw23_4, hw6_spRS_4, hmap4, hseg4, hsave4,
          hEmpty_spRS_4, hSeg_fr4, hSlot_fr4, hw6_fr4, hwo4, hw1_4, hw26_4, hro4⟩
  simp only [U₁, U₂, U₃, Finset.mem_insert, not_or] at hspDS_not1 hrS_not2 hspRS_not3
  rcases hspDS_not1 with ⟨hspDS_ne_dS, hspDS_not0⟩
  rcases hrS_not2 with ⟨hrS_ne_spDS, hrS_ne_dS, hrS_not0⟩
  rcases hspRS_not3 with ⟨hspRS_ne_rS, hspRS_ne_spDS, hspRS_ne_dS, hspRS_not0⟩
  have hdS_pos : 0 < dS := Nat.pos_of_ne_zero (fun h => hdS_not (h ▸ h0_U0))
  have hspDS_pos : 0 < spDS := Nat.pos_of_ne_zero (fun h => hspDS_not0 (h ▸ h0_U0))
  have hrS_pos : 0 < rS := Nat.pos_of_ne_zero (fun h => hrS_not0 (h ▸ h0_U0))
  have hspRS_pos : 0 < spRS := Nat.pos_of_ne_zero (fun h => hspRS_not0 (h ▸ h0_U0))
  have hex : DetExecAt 0 inp (freshAllocFourSlotsStmt D₀ NumSlots M_box) mem m4
      (freshAllocFourCost D₀ NumSlots) := by
    unfold freshAllocFourSlotsStmt seqList
    exact (hd0.seq (hd1.seq (hd2.seq (hd3.seq hd4)))).mono_cost
      (by unfold freshAllocFourCost; omega)
  refine ⟨m4, dS, spDS, rS, spRS, hex, hp4,
    hdS_pos, hdS_lt, hdS_not,
    hspDS_pos, hspDS_lt, hspDS_not0,
    hrS_pos, hrS_lt, hrS_not0,
    hspRS_pos, hspRS_lt, hspRS_not0,
    (Ne.symm hspDS_ne_dS), (Ne.symm hrS_ne_dS), (Ne.symm hspRS_ne_dS),
    (Ne.symm hrS_ne_spDS), (Ne.symm hspRS_ne_spDS), (Ne.symm hspRS_ne_rS),
    by rw [hw26_4 20 (by decide), hw26_3 20 (by decide), hw26_2 20 (by decide)]; exact hw20_1,
    by rw [hw26_4 21 (by decide), hw26_3 21 (by decide)]; exact hw21_2,
    by rw [hw26_4 22 (by decide)]; exact hw22_3,
    hw23_4,
    by rw [hw6_fr4 _ (by exact_mod_cast (Ne.symm hspRS_ne_dS)),
           hw6_fr3 _ (by exact_mod_cast (Ne.symm hrS_ne_dS)),
           hw6_fr2 _ (by exact_mod_cast (Ne.symm hspDS_ne_dS)), hw6_dS_1],
    by rw [hw6_fr4 _ (by exact_mod_cast (Ne.symm hspRS_ne_spDS)),
           hw6_fr3 _ (by exact_mod_cast (Ne.symm hrS_ne_spDS)), hw6_spDS_2],
    by rw [hw6_fr4 _ (by exact_mod_cast (Ne.symm hspRS_ne_rS)), hw6_rS_3],
    hw6_spRS_4,
    hmap4, hseg4, hsave4,
    fun fSq => hSeg_fr4 dS hdS_lt (Ne.symm hspRS_ne_dS) _ _
      (hSeg_fr3 dS hdS_lt (Ne.symm hrS_ne_dS) _ _
        (hSeg_fr2 dS hdS_lt (Ne.symm hspDS_ne_dS) _ _ (hEmpty_dS_1 fSq))),
    fun fSq => hSeg_fr4 spDS hspDS_lt (Ne.symm hspRS_ne_spDS) _ _
      (hSeg_fr3 spDS hspDS_lt (Ne.symm hrS_ne_spDS) _ _ (hEmpty_spDS_2 fSq)),
    fun fSq => hSeg_fr4 rS hrS_lt (Ne.symm hspRS_ne_rS) _ _ (hEmpty_rS_3 fSq),
    hEmpty_spRS_4,
    ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro s' hs' hn1 hn2 hn3 hn4 S₁ fSq₁ hE
    have hE0 : EncSegSlot K m0 s' S₁ fSq₁ :=
      hE.congr_mem_fSq (hwo0 5 (by decide) _) (fun _ _ => hwo0 8 (by decide) _)
        (fun _ _ => hwo0 9 (by decide) _) (fun _ _ => hwo0 10 (by decide) _)
        (fun _ _ => hro0 8 _) (fun _ _ => rfl)
    exact hSeg_fr4 s' hs' hn4 _ _ (hSeg_fr3 s' hs' hn3 _ _
      (hSeg_fr2 s' hs' hn2 _ _ (hSeg_fr1 s' hs' hn1 _ _ hE0)))
  · intro activeH livePts s' hs' hn1 hn2 hn3 hn4 S₁ sp₁ hC
    have hC0 : EncSlotCoords d n m0 activeH livePts s' S₁ sp₁ :=
      hC.congr_mem3 (hwo0 6 (by decide) _) (hwo0 11 (by decide)) (hro0 11)
    exact hSlot_fr4 activeH livePts s' hs' hn4 _ _
      (hSlot_fr3 activeH livePts s' hs' hn3 _ _
        (hSlot_fr2 activeH livePts s' hs' hn2 _ _
          (hSlot_fr1 activeH livePts s' hs' hn1 _ _ hC0)))
  · intro s' hn1 hn2 hn3 hn4
    rw [hw6_fr4 s' hn4, hw6_fr3 s' hn3, hw6_fr2 s' hn2, hw6_fr1 s' hn1, hwo0 6 (by decide)]
  · intro t h1 h5 h6 h7 h26 i
    rw [hwo4 t h1 h5 h6 h7 h26, hwo3 t h1 h5 h6 h7 h26, hwo2 t h1 h5 h6 h7 h26,
        hwo1 t h1 h5 h6 h7 h26, hwo0 t h7]
  · intro i hi
    rw [hw1_4 i hi, hw1_3 i hi, hw1_2 i hi, hw1_1 i hi, hwo0 1 (by decide)]
  · intro i h20 h21 h22 h23
    rw [hw26_4 i h23, hw26_3 i h22, hw26_2 i h21, hw26_1 i h20, hwo0 26 (by decide)]
  · intro t i
    rw [hro4, hro3, hro2, hro1, hro0]

theorem exec_freshAllocFiveSlotsStmt {d n K D₀ NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {chainLen leafS : ℕ}
    (hSlots_cap : 8 * (D₀ + 2) ^ 2 ≤ NumSlots)
    (hBox26 : 30 ≤ M_box)
    (hBox_slots : NumSlots ≤ M_box)
    (hcL_le : chainLen ≤ D₀)
    (hw_cL : wRead mem 1 5 = (chainLen : ℤ))
    (hleaf_lt : leafS < NumSlots)
    (hw_leaf : wRead mem 1 6 = (leafS : ℤ))
    (hsn_lt : ∀ r < chainLen,
      ∃ (dS spS : ℕ), dS < NumSlots ∧ spS < NumSlots ∧
        wRead mem 14 (r : ℤ) = (dS : ℤ) ∧ wRead mem 15 (r : ℤ) = (spS : ℤ))
    (hjob_lt : ∀ r < chainLen, wRead mem 16 (r : ℤ) = 1 →
      ∃ (jLen : ℕ), jLen ≤ D₀ ∧ wRead mem 19 (r : ℤ) = (jLen : ℤ) ∧
        ∀ j < jLen,
          ∃ (s2 s3 s4 s5 s6 : ℕ),
            s2 < NumSlots ∧ s3 < NumSlots ∧ s4 < NumSlots ∧ s5 < NumSlots ∧ s6 < NumSlots ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 2 : ℕ) : ℤ)) = (s2 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 3 : ℕ) : ℤ)) = (s3 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 4 : ℕ) : ℤ)) = (s4 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 5 : ℕ) : ℤ)) = (s5 : ℤ) ∧
            wRead mem 23 (((8 * (r * D₀ + j) + 6 : ℕ) : ℤ)) = (s6 : ℤ))
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem) :
    let U₀ := activeSlotSet mem D₀
    ∃ (m' : ArithRAMMemory) (dS spDS rS spRS dummySp : ℕ),
      DetExecAt 0 inp (freshAllocFiveSlotsStmt D₀ NumSlots M_box) mem m'
        (freshAllocFiveCost D₀ NumSlots) ∧
      m'.popDepth 0 = m' ∧
      0 < dS ∧ dS < NumSlots ∧ dS ∉ U₀ ∧
      0 < spDS ∧ spDS < NumSlots ∧ spDS ∉ U₀ ∧
      0 < rS ∧ rS < NumSlots ∧ rS ∉ U₀ ∧
      0 < spRS ∧ spRS < NumSlots ∧ spRS ∉ U₀ ∧
      0 < dummySp ∧ dummySp < NumSlots ∧ dummySp ∉ U₀ ∧
      dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧ spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS ∧
      dummySp ≠ dS ∧ dummySp ≠ spDS ∧ dummySp ≠ rS ∧ dummySp ≠ spRS ∧
      wRead m' 26 20 = (dS : ℤ) ∧
      wRead m' 26 21 = (spDS : ℤ) ∧
      wRead m' 26 22 = (rS : ℤ) ∧
      wRead m' 26 23 = (spRS : ℤ) ∧
      wRead m' 26 19 = (dummySp : ℤ) ∧
      wRead m' 6 (dS : ℤ) = 0 ∧
      wRead m' 6 (spDS : ℤ) = 0 ∧
      wRead m' 6 (rS : ℤ) = 0 ∧
      wRead m' 6 (spRS : ℤ) = 0 ∧
      wRead m' 6 (dummySp : ℤ) = 0 ∧
      SegGenBound K NumSlots m' ∧
      SaveGenBound n NumSlots m' ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' dS ∅ fSq) ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' spDS ∅ fSq) ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' rS ∅ fSq) ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' spRS ∅ fSq) ∧
      (∀ fSq : ℕ → ℝ, EncSegSlot K m' dummySp ∅ fSq) ∧
      (∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS → s' ≠ dummySp →
        ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ (activeH : Finset ℕ) (livePts : ℕ → EuclideanSpace ℝ (Fin d)),
        ∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS → s' ≠ dummySp →
          ∀ S₁ sp₁, EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
            EncSlotCoords d n m' activeH livePts s' S₁ sp₁) ∧
      (∀ s' : ℤ, s' ≠ (dS : ℤ) → s' ≠ (spDS : ℤ) → s' ≠ (rS : ℤ) → s' ≠ (spRS : ℤ) → s' ≠ (dummySp : ℤ) →
        wRead m' 6 s' = wRead mem 6 s') ∧
      (∀ t, t ≠ 1 → t ≠ 5 → t ≠ 6 → t ≠ 7 → t ≠ 26 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ i, i ≠ 3 → wRead m' 1 i = wRead mem 1 i) ∧
      (∀ i, i ≠ 19 → i ≠ 20 → i ≠ 21 → i ≠ 22 → i ≠ 23 → wRead m' 26 i = wRead mem 26 i) ∧
      (∀ t i, rRead m' t i = rRead mem t i) := by
  intro U₀
  have hcL_toNat : (wRead mem 1 5).toNat ≤ D₀ := by rw [hw_cL]; omega
  have hjL_toNat : ∀ r < (wRead mem 1 5).toNat,
      wRead mem 16 (r : ℤ) = 1 → (wRead mem 19 (r : ℤ)).toNat ≤ D₀ := by
    intro r hr h16
    rw [hw_cL, Int.toNat_natCast] at hr
    rcases hjob_lt r hr h16 with ⟨jL, hjL_le, hw19, _⟩
    rw [hw19]; omega
  have hU0_add5 : U₀.card + 5 ≤ NumSlots :=
    (activeSlotSet_card_add5_le hcL_toNat hjL_toNat).trans hSlots_cap
  have h0_U0 : 0 ∈ U₀ := zero_mem_activeSlotSet mem D₀
  rcases exec_freshAllocFourSlotsStmt inp mem hSlots_cap hBox26 hBox_slots hcL_le hw_cL hleaf_lt
      hw_leaf hsn_lt hjob_lt hseg hsave
    with ⟨m4, dS, spDS, rS, spRS, hd4, _,
          hdS_pos, hdS_lt, hdS_not, hspDS_pos, hspDS_lt, hspDS_not,
          hrS_pos, hrS_lt, hrS_not, hspRS_pos, hspRS_lt, hspRS_not,
          h12, h13, h14, h23, h24, h34,
          hw20_4, hw21_4, hw22_4, hw23_4,
          hw6_dS_4, hw6_spDS_4, hw6_rS_4, hw6_spRS_4,
          hmap4, hseg4, hsave4,
          hEmp1, hEmp2, hEmp3, hEmp4,
          hSeg4, hSlot4, hw6_fr4, hwo4, hw1_4, hw26_4, hro4⟩
  let U₄ := insert spRS (insert rS (insert spDS (insert dS U₀)))
  have hU4_card : U₄.card ≤ U₀.card + 4 := by
    have c1 := Finset.card_insert_le spRS (insert rS (insert spDS (insert dS U₀)))
    have c2 := Finset.card_insert_le rS (insert spDS (insert dS U₀))
    have c3 := Finset.card_insert_le spDS (insert dS U₀)
    have c4 := Finset.card_insert_le dS U₀
    change U₄.card ≤ _ at c1
    omega
  rcases exec_allocMarkAndResetSlotStmt (destReg := 19) inp m4 (used := U₄)
      (filter_card_lt_of_card_lt (by omega)) hmap4 (by omega) (by omega) hBox_slots hseg4 hsave4
    with ⟨m5, dummySp, hd5, hp5, hdum_lt, hdum_not4, hw19_5, hw6_dum_5, _, hseg5, hsave5,
          hEmp5, hSeg_fr5, hSlot_fr5, hw6_fr5, hwo5, hw1_5, hw26_5, hro5⟩
  simp only [U₄, Finset.mem_insert, not_or] at hdum_not4
  rcases hdum_not4 with ⟨hdum_ne_spRS, hdum_ne_rS, hdum_ne_spDS, hdum_ne_dS, hdum_not0⟩
  have hdum_pos : 0 < dummySp := Nat.pos_of_ne_zero (fun h => hdum_not0 (h ▸ h0_U0))
  refine ⟨m5, dS, spDS, rS, spRS, dummySp,
    (hd4.seq hd5).mono_cost (by unfold freshAllocFiveCost; omega), hp5,
    hdS_pos, hdS_lt, hdS_not, hspDS_pos, hspDS_lt, hspDS_not,
    hrS_pos, hrS_lt, hrS_not, hspRS_pos, hspRS_lt, hspRS_not,
    hdum_pos, hdum_lt, hdum_not0,
    h12, h13, h14, h23, h24, h34,
    hdum_ne_dS, hdum_ne_spDS, hdum_ne_rS, hdum_ne_spRS,
    by rw [hw26_5 20 (by decide)]; exact hw20_4,
    by rw [hw26_5 21 (by decide)]; exact hw21_4,
    by rw [hw26_5 22 (by decide)]; exact hw22_4,
    by rw [hw26_5 23 (by decide)]; exact hw23_4,
    hw19_5,
    by rw [hw6_fr5 _ (by exact_mod_cast (Ne.symm hdum_ne_dS)), hw6_dS_4],
    by rw [hw6_fr5 _ (by exact_mod_cast (Ne.symm hdum_ne_spDS)), hw6_spDS_4],
    by rw [hw6_fr5 _ (by exact_mod_cast (Ne.symm hdum_ne_rS)), hw6_rS_4],
    by rw [hw6_fr5 _ (by exact_mod_cast (Ne.symm hdum_ne_spRS)), hw6_spRS_4],
    hw6_dum_5,
    hseg5, hsave5,
    fun fSq => hSeg_fr5 dS hdS_lt (Ne.symm hdum_ne_dS) _ _ (hEmp1 fSq),
    fun fSq => hSeg_fr5 spDS hspDS_lt (Ne.symm hdum_ne_spDS) _ _ (hEmp2 fSq),
    fun fSq => hSeg_fr5 rS hrS_lt (Ne.symm hdum_ne_rS) _ _ (hEmp3 fSq),
    fun fSq => hSeg_fr5 spRS hspRS_lt (Ne.symm hdum_ne_spRS) _ _ (hEmp4 fSq),
    hEmp5,
    fun s' hs' n1 n2 n3 n4 n5 S₁ fSq₁ hE =>
      hSeg_fr5 s' hs' n5 _ _ (hSeg4 s' hs' n1 n2 n3 n4 S₁ fSq₁ hE),
    fun activeH livePts s' hs' n1 n2 n3 n4 n5 S₁ sp₁ hC =>
      hSlot_fr5 activeH livePts s' hs' n5 _ _ (hSlot4 activeH livePts s' hs' n1 n2 n3 n4 S₁ sp₁ hC),
    fun s' n1 n2 n3 n4 n5 => by rw [hw6_fr5 s' n5, hw6_fr4 s' n1 n2 n3 n4],
    fun t h1 h5 h6 h7 h26 i => by rw [hwo5 t h1 h5 h6 h7 h26, hwo4 t h1 h5 h6 h7 h26],
    fun i hi => by rw [hw1_5 i hi, hw1_4 i hi],
    fun i h19 h20 h21 h22 h23 => by rw [hw26_5 i h19, hw26_4 i h20 h21 h22 h23],
    fun t i => by rw [hro5, hro4]⟩

/-! ### 2. Exact Slot-Header Wrapper for `initJobLevelStmt` & `hpjFreezeRunInitStmt` -/

noncomputable def provAtIdx (d : ℕ) (mem : ArithRAMMemory) (idx : ℕ) : ChainNode d :=
  { o := WithLp.toLp 2 (fun c : Fin d => rRead mem 23 (((idx * d + c.val : ℕ) : ℤ)))
    V := max 0 (rRead mem 24 (((2 * idx + 0 : ℕ) : ℤ)))
    V_nonneg := le_max_left 0 _ }

theorem exec_initJobLevelExact {d n D K NumSlots M_box : ℕ}
    (inp : ArithRAMInput d) (mem : ArithRAMMemory)
    {idx bS dS spDS rS spRS openRem : ℕ}
    {S_birth S_parent : Finset ℕ} {snapPts : ℕ → EuclideanSpace ℝ (Fin d)}
    {activeH : Finset ℕ} {livePts : ℕ → EuclideanSpace ℝ (Fin d)}
    {prov : ChainNode d}
    (hbS : bS < NumSlots) (hdS : dS < NumSlots)
    (hspDS : spDS < NumSlots) (hrS : rS < NumSlots) (hspRS : spRS < NumSlots)
    (hdist : bS ≠ dS ∧ bS ≠ spDS ∧ bS ≠ rS ∧ bS ≠ spRS ∧
             dS ≠ spDS ∧ dS ≠ rS ∧ dS ≠ spRS ∧
             spDS ≠ rS ∧ spDS ≠ spRS ∧ rS ≠ spRS)
    (hb_pos : 0 < S_birth.card)
    (hBox_slots : NumSlots ≤ M_box)
    (hBox_w23 : 8 * idx + 8 ≤ M_box)
    (hBox_r23 : idx * d + d ≤ M_box)
    (hidx_reg : wRead mem 26 7 = (idx : ℤ))
    (hbS_reg : wRead mem 26 1 = (bS : ℤ))
    (hdS_reg : wRead mem 26 20 = (dS : ℤ))
    (hspDS_reg : wRead mem 26 21 = (spDS : ℤ))
    (hrS_reg : wRead mem 26 22 = (rS : ℤ))
    (hspRS_reg : wRead mem 26 23 = (spRS : ℤ))
    (hbCard_reg : wRead mem 26 24 = (S_birth.card : ℤ))
    (hrem_reg : wRead mem 26 25 = (openRem : ℤ))
    (hprov_o : ∀ c : Fin d, rRead mem 27 (c.val : ℤ) = euclideanCoord prov.o c)
    (hprov_V : rRead mem 27 (d : ℤ) = prov.V)
    (h6_bS : 1 ≤ wRead mem 6 (bS : ℤ))
    (hseg : SegGenBound K NumSlots mem)
    (hsave : SaveGenBound n NumSlots mem)
    (hSeg_bS : EncSegSlot K mem bS S_birth (fun _ => 0))
    (hSlot_bS : EncSlotCoords d n mem activeH livePts bS S_birth snapPts) :
    ∃ m' : ArithRAMMemory,
      DetExecAt 0 inp (initJobLevelStmt d M_box) mem m' (120 * (d + 1) + 400) ∧
      m'.popDepth 0 = m' ∧
      SegGenBound K NumSlots m' ∧
      SaveGenBound n NumSlots m' ∧
      EncJobLevel d n D K NumSlots m' activeH livePts idx S_birth snapPts prov S_parent true ∧
      provAtIdx d m' idx = prov ∧
      wRead m' 23 (((8 * idx + 0 : ℕ) : ℤ)) = (S_birth.card : ℤ) ∧
      wRead m' 23 (((8 * idx + 2 : ℕ) : ℤ)) = (bS : ℤ) ∧
      wRead m' 23 (((8 * idx + 3 : ℕ) : ℤ)) = (dS : ℤ) ∧
      wRead m' 23 (((8 * idx + 4 : ℕ) : ℤ)) = (spDS : ℤ) ∧
      wRead m' 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ) ∧
      wRead m' 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ) ∧
      wRead m' 23 (((8 * idx + 7 : ℕ) : ℤ)) = (openRem : ℤ) ∧
      jobLevelSlotSet m' idx = {bS, dS, spDS, rS, spRS} ∧
      jobLevelLiveSlots m' idx true = {spRS, dS, spDS, rS} ∧
      wRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = 0 ∧
      wRead m' 24 (((2 * idx + 1 : ℕ) : ℤ)) = 0 ∧
      wRead m' 6 (dS : ℤ) = 0 ∧
      wRead m' 6 (spDS : ℤ) = 0 ∧
      wRead m' 6 (rS : ℤ) = 0 ∧
      wRead m' 6 (spRS : ℤ) = 0 ∧
      (∀ s' < NumSlots, ∀ S₁ fSq₁, EncSegSlot K mem s' S₁ fSq₁ → EncSegSlot K m' s' S₁ fSq₁) ∧
      (∀ s' < NumSlots, s' ≠ dS → s' ≠ spDS → s' ≠ rS → s' ≠ spRS →
        ∀ S₁ sp₁, EncSlotCoords d n mem activeH livePts s' S₁ sp₁ →
          EncSlotCoords d n m' activeH livePts s' S₁ sp₁) ∧
      (∀ t, t ≠ 6 → t ≠ 23 → t ≠ 24 → ∀ i, wRead m' t i = wRead mem t i) ∧
      (∀ s' : ℤ, s' ≠ (dS : ℤ) → s' ≠ (spDS : ℤ) → s' ≠ (rS : ℤ) → s' ≠ (spRS : ℤ) →
        wRead m' 6 s' = wRead mem 6 s') ∧
      (∀ i : ℤ, (i < ((8 * idx : ℕ) : ℤ) ∨ ((8 * idx + 8 : ℕ) : ℤ) ≤ i) →
        wRead m' 23 i = wRead mem 23 i) ∧
      (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
        wRead m' 24 i = wRead mem 24 i) ∧
      (∀ t, t ≠ 23 → t ≠ 24 → ∀ i, rRead m' t i = rRead mem t i) ∧
      (∀ i : ℤ, (i < ((idx * d : ℕ) : ℤ) ∨ ((idx * d + d : ℕ) : ℤ) ≤ i) →
        rRead m' 23 i = rRead mem 23 i) ∧
      (∀ i : ℤ, (i < ((2 * idx : ℕ) : ℤ) ∨ ((2 * idx + 2 : ℕ) : ℤ) ≤ i) →
        rRead m' 24 i = rRead mem 24 i) := by
  rcases exec_initJobLevelStmt (D := D) (S_parent := S_parent) inp mem hbS hdS hspDS hrS hspRS
      hdist hb_pos hBox_slots hBox_w23 hBox_r23 hidx_reg hbS_reg hdS_reg hspDS_reg hrS_reg
      hspRS_reg hbCard_reg hrem_reg hprov_o hprov_V h6_bS hseg hsave hSeg_bS hSlot_bS
    with ⟨m', hex, hp', hseg', hsave', hEnc', hw7', hw24_0', hw24_1',
          hSegFr', hSlotFr', hwo', hw6Fr', hw23Fr', hw24Fr', hro', hr23Fr', hr24Fr'⟩
  rcases hdist with ⟨hbd, hbspD, hbr, hbspR, hdspD, hdr, hdspR, hspDr, hspDspR, hrspR⟩
  let m0 := mem.popDepth 0
  let m1 := wWrite m0 6 (dS : ℤ) 0
  let m2 := wWrite m1 6 (spDS : ℤ) 0
  let m3 := wWrite m2 6 (rS : ℤ) 0
  let m4 := wWrite m3 6 (spRS : ℤ) 0
  have hs1 : DetExecAt 1 inp (boxWriteW M_box 6 (.readHeap 26 (.lit 20)) (.lit 0)) m0 m1 16 :=
    exec_boxWriteW inp m0 _ _ (by simp [m0, hdS_reg]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hs2 : DetExecAt 1 inp (boxWriteW M_box 6 (.readHeap 26 (.lit 21)) (.lit 0)) m1 m2 16 :=
    exec_boxWriteW inp m1 _ _ (by simp [m1, m0, hspDS_reg]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hs3 : DetExecAt 1 inp (boxWriteW M_box 6 (.readHeap 26 (.lit 22)) (.lit 0)) m2 m3 16 :=
    exec_boxWriteW inp m2 _ _ (by simp [m2, m1, m0, hrS_reg]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hs4 : DetExecAt 1 inp (boxWriteW M_box 6 (.readHeap 26 (.lit 23)) (.lit 0)) m3 m4 16 :=
    exec_boxWriteW inp m3 _ _ (by simp [m3, m2, m1, m0, hspRS_reg]) (by omega) (by omega) rfl (by simp [intExprOps])
  let m5 := wWriteL 1 m4 29 19 (((8 * idx : ℕ) : ℤ))
  have hs5 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 19) (.mul (.lit 8) (.readHeap 26 (.lit 7)))) m4 m5 8 := by
    refine DetExecAt.writeWordLocal 1 inp m4 29 _ _ rfl ?_ (by simp [intExprOps])
    have hm4_7 : wRead m4 26 7 = (idx : ℤ) := by simp [m4, m3, m2, m1, m0, hidx_reg]
    simp only [iValAt_mul, iValAt_lit, iValAt_readHeap, hm4_7]; push_cast; rfl
  let a0 := wWrite m5 23 (((8 * idx + 0 : ℕ) : ℤ)) (S_birth.card : ℤ)
  let a1 := wWrite a0 23 (((8 * idx + 1 : ℕ) : ℤ)) 0
  let a2 := wWrite a1 23 (((8 * idx + 2 : ℕ) : ℤ)) (bS : ℤ)
  let a3 := wWrite a2 23 (((8 * idx + 3 : ℕ) : ℤ)) (dS : ℤ)
  let a4 := wWrite a3 23 (((8 * idx + 4 : ℕ) : ℤ)) (spDS : ℤ)
  let a5 := wWrite a4 23 (((8 * idx + 5 : ℕ) : ℤ)) (rS : ℤ)
  let a6 := wWrite a5 23 (((8 * idx + 6 : ℕ) : ℤ)) (spRS : ℤ)
  let a7 := wWrite a6 23 (((8 * idx + 7 : ℕ) : ℤ)) (openRem : ℤ)
  have hm5_26 : ∀ i, wRead m5 26 i = wRead mem 26 i := by
    intro i; dsimp only [m5, m4, m3, m2, m1, m0]
    repeat (first | rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))] | rw [wRead_wWriteL])
    exact wRead_popDepth _ _ _ _
  have ha0 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 0)) (.readHeap 26 (.lit 24))) m5 a0 20 :=
    exec_boxWriteW inp m5 _ _ (by simp [m5]) (by omega) (by omega) (by simp [hm5_26, hbCard_reg]) (by simp [intExprOps])
  have ha1 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 1)) (.lit 0)) a0 a1 25 :=
    exec_boxWriteW inp a0 _ _ (by simp [a0, m5]) (by omega) (by omega) rfl (by simp [intExprOps])
  have ha2 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 2)) (.readHeap 26 (.lit 1))) a1 a2 20 :=
    exec_boxWriteW inp a1 _ _ (by simp [a1, a0, m5]) (by omega) (by omega)
      (by simp [a1, a0, hm5_26, hbS_reg]) (by simp [intExprOps])
  have ha3 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 3)) (.readHeap 26 (.lit 20))) a2 a3 20 :=
    exec_boxWriteW inp a2 _ _ (by simp [a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a2, a1, a0, hm5_26, hdS_reg]) (by simp [intExprOps])
  have ha4 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 4)) (.readHeap 26 (.lit 21))) a3 a4 20 :=
    exec_boxWriteW inp a3 _ _ (by simp [a3, a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a3, a2, a1, a0, hm5_26, hspDS_reg]) (by simp [intExprOps])
  have ha5 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 5)) (.readHeap 26 (.lit 22))) a4 a5 20 :=
    exec_boxWriteW inp a4 _ _ (by simp [a4, a3, a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a4, a3, a1, a0, a2, hm5_26, hrS_reg]) (by simp [intExprOps])
  have ha6 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 6)) (.readHeap 26 (.lit 23))) a5 a6 20 :=
    exec_boxWriteW inp a5 _ _ (by simp [a5, a4, a3, a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a5, a4, a3, a2, a1, a0, hm5_26, hspRS_reg]) (by simp [intExprOps])
  have ha7 : DetExecAt 1 inp (boxWriteW M_box 23 (.add (.readLocal 29 (.lit 19)) (.lit 7)) (.readHeap 26 (.lit 25))) a6 a7 20 :=
    exec_boxWriteW inp a6 _ _ (by simp [a6, a5, a4, a3, a2, a1, a0, m5]) (by omega) (by omega)
      (by simp [a6, a5, a4, a3, a2, a1, a0, hm5_26, hrem_reg]) (by simp [intExprOps])
  have ha7_26 : ∀ i, wRead a7 26 i = wRead mem 26 i := by
    intro i
    dsimp only [a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0]
    repeat (first | rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))] | rw [wRead_wWriteL])
    exact wRead_popDepth _ _ _ _
  have ha7_r27 : ∀ i, rRead a7 27 i = rRead mem 27 i := by
    intro i
    dsimp only [a7, a6, a5, a4, a3, a2, a1, a0, m5, m4, m3, m2, m1, m0]
    repeat (first | rw [rRead_wWrite] | rw [rRead_wWriteL])
    exact rRead_popDepth _ _ _ _
  let b0 := wWriteL 1 a7 29 19 (((2 * idx : ℕ) : ℤ))
  have hb0 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 19) (.mul (.lit 2) (.readHeap 26 (.lit 7)))) a7 b0 8 := by
    refine DetExecAt.writeWordLocal 1 inp a7 29 _ _ rfl ?_ (by simp [intExprOps])
    simp only [iValAt_mul, iValAt_lit, iValAt_readHeap, ha7_26, hidx_reg]; push_cast; rfl
  let b1 := wWrite b0 24 (((2 * idx + 0 : ℕ) : ℤ)) 0
  let b2 := wWrite b1 24 (((2 * idx + 1 : ℕ) : ℤ)) 0
  let b3 := rWrite b2 24 (((2 * idx + 0 : ℕ) : ℤ)) prov.V
  let b4 := rWrite b3 24 (((2 * idx + 1 : ℕ) : ℤ)) 0
  have hb1 : DetExecAt 1 inp (boxWriteW M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 0)) (.lit 0)) b0 b1 25 :=
    exec_boxWriteW inp b0 _ _ (by simp [b0]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hb2 : DetExecAt 1 inp (boxWriteW M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 1)) (.lit 0)) b1 b2 25 :=
    exec_boxWriteW inp b1 _ _ (by simp [b1, b0]) (by omega) (by omega) rfl (by simp [intExprOps])
  have hb3 : DetExecAt 1 inp (boxWriteR M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 0)) (.readRealHeap 27 (.lit (d : ℤ)))) b2 b3 20 := by
    refine exec_boxWriteR inp b2 _ _ (by simp [b2, b1, b0]) (by omega) (by omega) ?_ (by simp [intExprOps, realExprOps])
    dsimp only [b2, b1, b0]
    rw [rValAt_readRealHeap, iValAt_lit, rRead_wWrite, rRead_wWrite, rRead_wWriteL, ha7_r27, hprov_V]
  have hb4 : DetExecAt 1 inp (boxWriteR M_box 24 (.add (.readLocal 29 (.lit 19)) (.lit 1)) (.ofInt (.lit 0))) b3 b4 25 :=
    exec_boxWriteR inp b3 _ _ (by simp [b3, b2, b1, b0]) (by omega) (by omega)
      (by simp) (by simp [intExprOps, realExprOps])
  let c0 := wWriteL 1 b4 29 18 0
  have hc0 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.lit 0)) b4 c0 4 :=
    DetExecAt.writeWordLocal 1 inp b4 29 _ _ rfl rfl (by simp [intExprOps])
  rcases exec_loadHeapCoordsToLocalStmt inp c0 (rTag := 27) (idxBase := 18) (destOff := 0)
      (base := 0) (pt := prov.o) (by decide) (by simp [c0])
      (fun c => by
        dsimp only [c0, b4, b3, b2, b1, b0]
        rw [Nat.zero_add, rRead_wWriteL, rRead_rWrite_of_ne _ _ (Or.inl (by decide)),
            rRead_rWrite_of_ne _ _ (Or.inl (by decide)), rRead_wWrite, rRead_wWrite, rRead_wWriteL, ha7_r27]
        exact hprov_o c)
    with ⟨c1, hc1, hloc_c1, hw_c1, _, _, _, _, _⟩
  let c2 := wWriteL 1 c1 29 18 (((idx * d : ℕ) : ℤ))
  have hc2 : DetExecAt 1 inp (.writeWordLocal 29 (.lit 18) (.mul (.readHeap 26 (.lit 7)) (.lit (d : ℤ)))) c1 c2 8 := by
    refine DetExecAt.writeWordLocal 1 inp c1 29 _ _ rfl ?_ (by simp [intExprOps])
    have hc1_7 : wRead c1 26 7 = (idx : ℤ) := by
      rw [hw_c1]; dsimp only [c0, b4, b3, b2, b1, b0]
      rw [wRead_wWriteL, wRead_rWrite, wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWriteL, ha7_26, hidx_reg]
    simp only [iValAt_mul, iValAt_lit, iValAt_readHeap, hc1_7]; push_cast; rfl
  rcases exec_storeLocalCoordsToHeapStmt inp c2 (M_box := M_box) (rTag := 23) (idxBase := 18) (srcOff := 0)
      (base := idx * d) (pt := prov.o) (by decide) (by simp [c2]) hBox_r23
      (fun c => by simp [c2, Nat.zero_add]; simpa using hloc_c1 c)
    with ⟨c3, hc3, _, _, _, hw_c3, _, _, _, _⟩
  have hex_alt := DetExecAt.localScope (fd := 0)
    (hs1.seq (hs2.seq (hs3.seq (hs4.seq (hs5.seq
      (ha0.seq (ha1.seq (ha2.seq (ha3.seq (ha4.seq (ha5.seq (ha6.seq (ha7.seq
        (hb0.seq (hb1.seq (hb2.seq (hb3.seq (hb4.seq (hc0.seq (hc1.seq (hc2.seq hc3)))))))))))))))))))))
  have hm_eq : m' = c3.popDepth 0 :=
    DetExecAt.unique_mem hex hex_alt hp' (popDepth_zero_idem c3)
  have hw_m'_a7 : ∀ t i, t ≠ 24 → wRead m' t i = wRead a7 t i := by
    intro t i ht24
    rw [hm_eq, wRead_popDepth, hw_c3]
    dsimp only [c2]
    rw [wRead_wWriteL, hw_c1]
    dsimp only [c0, b4, b3]
    rw [wRead_wWriteL, wRead_rWrite, wRead_rWrite,
        wRead_wWrite_of_ne _ _ (Or.inl ht24),
        wRead_wWrite_of_ne _ _ (Or.inl ht24)]
    simp [b0, m5]
  have stp7 : ∀ k < 7, wRead a7 23 (((8 * idx + k : ℕ) : ℤ)) = wRead a6 23 (((8 * idx + k : ℕ) : ℤ)) :=
    fun k hk => wRead_wWrite_of_ne _ _ (Or.inr (by omega))
  have stp6 : ∀ k < 6, wRead a6 23 (((8 * idx + k : ℕ) : ℤ)) = wRead a5 23 (((8 * idx + k : ℕ) : ℤ)) :=
    fun k hk => wRead_wWrite_of_ne _ _ (Or.inr (by omega))
  have stp5 : ∀ k < 5, wRead a5 23 (((8 * idx + k : ℕ) : ℤ)) = wRead a4 23 (((8 * idx + k : ℕ) : ℤ)) :=
    fun k hk => wRead_wWrite_of_ne _ _ (Or.inr (by omega))
  have stp4 : ∀ k < 4, wRead a4 23 (((8 * idx + k : ℕ) : ℤ)) = wRead a3 23 (((8 * idx + k : ℕ) : ℤ)) :=
    fun k hk => wRead_wWrite_of_ne _ _ (Or.inr (by omega))
  have stp3 : ∀ k < 3, wRead a3 23 (((8 * idx + k : ℕ) : ℤ)) = wRead a2 23 (((8 * idx + k : ℕ) : ℤ)) :=
    fun k hk => wRead_wWrite_of_ne _ _ (Or.inr (by omega))
  have stp2 : ∀ k < 2, wRead a2 23 (((8 * idx + k : ℕ) : ℤ)) = wRead a1 23 (((8 * idx + k : ℕ) : ℤ)) :=
    fun k hk => wRead_wWrite_of_ne _ _ (Or.inr (by omega))
  have stp1 : ∀ k < 1, wRead a1 23 (((8 * idx + k : ℕ) : ℤ)) = wRead a0 23 (((8 * idx + k : ℕ) : ℤ)) :=
    fun k hk => wRead_wWrite_of_ne _ _ (Or.inr (by omega))
  have hw0 : wRead m' 23 (((8 * idx + 0 : ℕ) : ℤ)) = (S_birth.card : ℤ) := by
    rw [hw_m'_a7 23 _ (by decide), stp7 0 (by omega), stp6 0 (by omega), stp5 0 (by omega),
        stp4 0 (by omega), stp3 0 (by omega), stp2 0 (by omega), stp1 0 (by omega)]
    exact wRead_wWrite_self _ _ _ _
  have hw2 : wRead m' 23 (((8 * idx + 2 : ℕ) : ℤ)) = (bS : ℤ) := by
    rw [hw_m'_a7 23 _ (by decide), stp7 2 (by omega), stp6 2 (by omega), stp5 2 (by omega),
        stp4 2 (by omega), stp3 2 (by omega)]
    exact wRead_wWrite_self _ _ _ _
  have hw3 : wRead m' 23 (((8 * idx + 3 : ℕ) : ℤ)) = (dS : ℤ) := by
    rw [hw_m'_a7 23 _ (by decide), stp7 3 (by omega), stp6 3 (by omega), stp5 3 (by omega),
        stp4 3 (by omega)]
    exact wRead_wWrite_self _ _ _ _
  have hw4 : wRead m' 23 (((8 * idx + 4 : ℕ) : ℤ)) = (spDS : ℤ) := by
    rw [hw_m'_a7 23 _ (by decide), stp7 4 (by omega), stp6 4 (by omega), stp5 4 (by omega)]
    exact wRead_wWrite_self _ _ _ _
  have hw5 : wRead m' 23 (((8 * idx + 5 : ℕ) : ℤ)) = (rS : ℤ) := by
    rw [hw_m'_a7 23 _ (by decide), stp7 5 (by omega), stp6 5 (by omega)]
    exact wRead_wWrite_self _ _ _ _
  have hw6 : wRead m' 23 (((8 * idx + 6 : ℕ) : ℤ)) = (spRS : ℤ) := by
    rw [hw_m'_a7 23 _ (by decide), stp7 6 (by omega)]
    exact wRead_wWrite_self _ _ _ _
  have ha7_m4 : ∀ i, wRead a7 6 i = wRead m4 6 i := by
    intro i
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
    simp [b0, m5]
  have hw6_dS : wRead m' 6 (dS : ℤ) = 0 := by
    rw [hw_m'_a7 6 _ (by decide), ha7_m4,
        wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hdspR)),
        wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hdr)),
        wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hdspD))]
    exact wRead_wWrite_self _ _ _ _
  have hw6_spDS : wRead m' 6 (spDS : ℤ) = 0 := by
    rw [hw_m'_a7 6 _ (by decide), ha7_m4,
        wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hspDspR)),
        wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hspDr))]
    exact wRead_wWrite_self _ _ _ _
  have hw6_rS : wRead m' 6 (rS : ℤ) = 0 := by
    rw [hw_m'_a7 6 _ (by decide), ha7_m4,
        wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hrspR))]
    exact wRead_wWrite_self _ _ _ _
  have hw6_spRS : wRead m' 6 (spRS : ℤ) = 0 := by
    rw [hw_m'_a7 6 _ (by decide), ha7_m4]
    exact wRead_wWrite_self _ _ _ _
  have hprov_eq : provAtIdx d m' idx = prov := by
    rcases hEnc' with ⟨_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _,
      _, _, _, _, _, _, _, _, _, _, _, _, _, _, hr_o', hph'⟩
    have hr_V' : rRead m' 24 (((2 * idx + 0 : ℕ) : ℤ)) = prov.V := by
      rcases hph' with ⟨_, _, _, _, _, hV, _, _⟩ | ⟨_, _, h1, _⟩ | ⟨h2, _⟩
      · exact hV
      · rw [hw24_0'] at h1; omega
      · rw [hw24_0'] at h2; omega
    have ho_eq : WithLp.toLp 2 (fun c : Fin d => rRead m' 23 (((idx * d + c.val : ℕ) : ℤ))) = prov.o := by
      ext c
      change rRead m' 23 (((idx * d + c.val : ℕ) : ℤ)) = euclideanCoord prov.o c
      exact hr_o' c
    have hV_max : max 0 (rRead m' 24 (((2 * idx + 0 : ℕ) : ℤ))) = prov.V := by
      rw [hr_V', max_eq_right prov.V_nonneg]
    cases prov
    dsimp [provAtIdx] at ho_eq hV_max ⊢
    congr
  have hslot_set : jobLevelSlotSet m' idx = {bS, dS, spDS, rS, spRS} := by
    unfold jobLevelSlotSet
    rw [hw2, hw3, hw4, hw5, hw6]
    simp
  have hlive_set : jobLevelLiveSlots m' idx true = {spRS, dS, spDS, rS} := by
    unfold jobLevelLiveSlots
    rw [hw3, hw4, hw5, hw6]
    simp
  exact ⟨m', hex, hp', hseg', hsave', hEnc', hprov_eq, hw0, hw2, hw3, hw4, hw5, hw6, hw7',
    hslot_set, hlive_set, hw24_0', hw24_1', hw6_dS, hw6_spDS, hw6_rS, hw6_spRS,
    hSegFr', hSlotFr', hwo', hw6Fr', hw23Fr', hw24Fr', hro', hr23Fr', hr24Fr'⟩

end UL.Proof_lem_7_2_RacerP46
