import UL.Proof.lem_7_2.CG01_ServingSchedC

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30

/-! ### 6. Outer Determinism Tightening (`OuterCleanStmt` & `RandExecAt.tighten_outer`) -/

private lemma wordStore_popDepth_zero_write_heap {ws : WordStore}
    (h : ws.popDepth 0 = ws) (t : ℕ) (idx val : ℤ) :
    (ws.write (.heap t idx) val).popDepth 0 = ws.write (.heap t idx) val := by
  have hlive : ws.live.filter (fun loc => loc.keepAtDepth 0 = true) = ws.live :=
    congrArg WordStore.live h
  have hvals : (fun loc => if loc.keepAtDepth 0 then ws.vals loc else 0) = ws.vals :=
    congrArg WordStore.vals h
  unfold WordStore.write WordStore.popDepth
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_insert]
    rcases eq_or_ne loc (.heap t idx) with rfl | hne
    · simp [RAMCellLoc.keepAtDepth]
    · simp only [hne, false_or]
      exact ⟨fun h1 => h1.1, fun h1 => by
        have hm : loc ∈ ws.live.filter (fun l => l.keepAtDepth 0 = true) := hlive.symm ▸ h1
        exact Finset.mem_filter.mp hm⟩
  · funext loc
    rcases eq_or_ne loc (.heap t idx) with rfl | hne
    · simp [RAMCellLoc.keepAtDepth]
    · simp only [Function.update_of_ne hne]
      exact congrFun hvals loc

private lemma wordStore_popDepth_zero_free_heap {ws : WordStore}
    (h : ws.popDepth 0 = ws) (t : ℕ) (idx : ℤ) :
    (ws.free (.heap t idx)).popDepth 0 = ws.free (.heap t idx) := by
  have hlive : ws.live.filter (fun loc => loc.keepAtDepth 0 = true) = ws.live :=
    congrArg WordStore.live h
  have hvals : (fun loc => if loc.keepAtDepth 0 then ws.vals loc else 0) = ws.vals :=
    congrArg WordStore.vals h
  unfold WordStore.free WordStore.popDepth
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_erase]
    rcases eq_or_ne loc (.heap t idx) with rfl | hne
    · tauto
    · simp only [ne_eq, hne, not_false_eq_true, true_and]
      exact ⟨fun h1 => h1.1, fun h1 => by
        have hm : loc ∈ ws.live.filter (fun l => l.keepAtDepth 0 = true) := hlive.symm ▸ h1
        exact Finset.mem_filter.mp hm⟩
  · funext loc
    rcases eq_or_ne loc (.heap t idx) with rfl | hne
    · simp [RAMCellLoc.keepAtDepth]
    · simp only [Function.update_of_ne hne]
      exact congrFun hvals loc

private lemma realStore_popDepth_zero_write_heap {rs : RealStore}
    (h : rs.popDepth 0 = rs) (t : ℕ) (idx : ℤ) (val : ℝ) :
    (rs.write (.heap t idx) val).popDepth 0 = rs.write (.heap t idx) val := by
  have hlive : rs.live.filter (fun loc => loc.keepAtDepth 0 = true) = rs.live :=
    congrArg RealStore.live h
  have hvals : (fun loc => if loc.keepAtDepth 0 then rs.vals loc else 0) = rs.vals :=
    congrArg RealStore.vals h
  unfold RealStore.write RealStore.popDepth
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_insert]
    rcases eq_or_ne loc (.heap t idx) with rfl | hne
    · simp [RAMCellLoc.keepAtDepth]
    · simp only [hne, false_or]
      exact ⟨fun h1 => h1.1, fun h1 => by
        have hm : loc ∈ rs.live.filter (fun l => l.keepAtDepth 0 = true) := hlive.symm ▸ h1
        exact Finset.mem_filter.mp hm⟩
  · funext loc
    rcases eq_or_ne loc (.heap t idx) with rfl | hne
    · simp [RAMCellLoc.keepAtDepth]
    · simp only [Function.update_of_ne hne]
      exact congrFun hvals loc

private lemma realStore_popDepth_zero_free_heap {rs : RealStore}
    (h : rs.popDepth 0 = rs) (t : ℕ) (idx : ℤ) :
    (rs.free (.heap t idx)).popDepth 0 = rs.free (.heap t idx) := by
  have hlive : rs.live.filter (fun loc => loc.keepAtDepth 0 = true) = rs.live :=
    congrArg RealStore.live h
  have hvals : (fun loc => if loc.keepAtDepth 0 then rs.vals loc else 0) = rs.vals :=
    congrArg RealStore.vals h
  unfold RealStore.free RealStore.popDepth
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_erase]
    rcases eq_or_ne loc (.heap t idx) with rfl | hne
    · tauto
    · simp only [ne_eq, hne, not_false_eq_true, true_and]
      exact ⟨fun h1 => h1.1, fun h1 => by
        have hm : loc ∈ rs.live.filter (fun l => l.keepAtDepth 0 = true) := hlive.symm ▸ h1
        exact Finset.mem_filter.mp hm⟩
  · funext loc
    rcases eq_or_ne loc (.heap t idx) with rfl | hne
    · simp [RAMCellLoc.keepAtDepth]
    · simp only [Function.update_of_ne hne]
      exact congrFun hvals loc

private lemma mem_popDepth_zero_writeWordHeap {m : ArithRAMMemory}
    (h : m.popDepth 0 = m) (t : ℕ) (idx val : ℤ) :
    ({ m with words := m.words.write (.heap t idx) val } : ArithRAMMemory).popDepth 0 =
      { m with words := m.words.write (.heap t idx) val } := by
  have hw : m.words.popDepth 0 = m.words := congrArg ArithRAMMemory.words h
  have hr : m.reals.popDepth 0 = m.reals := congrArg ArithRAMMemory.reals h
  unfold ArithRAMMemory.popDepth
  dsimp only
  rw [wordStore_popDepth_zero_write_heap hw, hr]

private lemma mem_popDepth_zero_freeWordHeap {m : ArithRAMMemory}
    (h : m.popDepth 0 = m) (t : ℕ) (idx : ℤ) :
    ({ m with words := m.words.free (.heap t idx) } : ArithRAMMemory).popDepth 0 =
      { m with words := m.words.free (.heap t idx) } := by
  have hw : m.words.popDepth 0 = m.words := congrArg ArithRAMMemory.words h
  have hr : m.reals.popDepth 0 = m.reals := congrArg ArithRAMMemory.reals h
  unfold ArithRAMMemory.popDepth
  dsimp only
  rw [wordStore_popDepth_zero_free_heap hw, hr]

private lemma mem_popDepth_zero_writeRealHeap {m : ArithRAMMemory}
    (h : m.popDepth 0 = m) (t : ℕ) (idx : ℤ) (val : ℝ) :
    ({ m with reals := m.reals.write (.heap t idx) val } : ArithRAMMemory).popDepth 0 =
      { m with reals := m.reals.write (.heap t idx) val } := by
  have hw : m.words.popDepth 0 = m.words := congrArg ArithRAMMemory.words h
  have hr : m.reals.popDepth 0 = m.reals := congrArg ArithRAMMemory.reals h
  unfold ArithRAMMemory.popDepth
  dsimp only
  rw [hw, realStore_popDepth_zero_write_heap hr]

private lemma mem_popDepth_zero_freeRealHeap {m : ArithRAMMemory}
    (h : m.popDepth 0 = m) (t : ℕ) (idx : ℤ) :
    ({ m with reals := m.reals.free (.heap t idx) } : ArithRAMMemory).popDepth 0 =
      { m with reals := m.reals.free (.heap t idx) } := by
  have hw : m.words.popDepth 0 = m.words := congrArg ArithRAMMemory.words h
  have hr : m.reals.popDepth 0 = m.reals := congrArg ArithRAMMemory.reals h
  unfold ArithRAMMemory.popDepth
  dsimp only
  rw [hw, realStore_popDepth_zero_free_heap hr]

/-- Statements that never touch `localFrame 0` directly at `frameDepth = 0` (any body inside
`.localScope` runs at `frameDepth ≥ 1` and is unrestricted). -/
inductive OuterCleanStmt : ArithRAMStmt → Prop
  | skip : OuterCleanStmt .skip
  | writeWordHeap (t : ℕ) (i v : IntExpr) : OuterCleanStmt (.writeWordHeap t i v)
  | freeWordHeap (t : ℕ) (i : IntExpr) : OuterCleanStmt (.freeWordHeap t i)
  | writeRealHeap (t : ℕ) (i : IntExpr) (v : RealExpr) : OuterCleanStmt (.writeRealHeap t i v)
  | freeRealHeap (t : ℕ) (i : IntExpr) : OuterCleanStmt (.freeRealHeap t i)
  | randBitHeap (t : ℕ) (i : IntExpr) : OuterCleanStmt (.randBitHeap t i)
  | seq {s₁ s₂} : OuterCleanStmt s₁ → OuterCleanStmt s₂ → OuterCleanStmt (.seq s₁ s₂)
  | ite (c : ArithCondExpr) {s₁ s₂} :
      OuterCleanStmt s₁ → OuterCleanStmt s₂ → OuterCleanStmt (.ite c s₁ s₂)
  | whileLoop (c : ArithCondExpr) {b} : OuterCleanStmt b → OuterCleanStmt (.whileLoop c b)
  | repeatN (cnt : IntExpr) {b} : OuterCleanStmt b → OuterCleanStmt (.repeatN cnt b)
  | localScope (b : ArithRAMStmt) : OuterCleanStmt (.localScope b)

theorem BoxSafeOuter.to_outerClean {T_max M_box : ℕ} {s : ArithRAMStmt}
    (h : BoxSafeOuter T_max M_box s) : OuterCleanStmt s := by
  induction h with
  | skip => exact .skip
  | boxW _ idxE valE => exact .ite _ (.writeWordHeap _ idxE valE) .skip
  | boxR _ idxE valE => exact .ite _ (.writeRealHeap _ idxE valE) .skip
  | localScope _ => exact .localScope _
  | seq _ _ ih₁ ih₂ => exact .seq ih₁ ih₂
  | ite c _ _ ih₁ ih₂ => exact .ite c ih₁ ih₂
  | repeatN cnt _ ih => exact .repeatN cnt ih

inductive OuterCleanStack : ℕ → List ArithRAMCont → Prop
  | nil_zero : OuterCleanStack 0 []
  | stmt_zero {s rest} :
      OuterCleanStmt s → OuterCleanStack 0 rest → OuterCleanStack 0 (.stmt s :: rest)
  | repeat_zero (rem : ℕ) {b rest} :
      OuterCleanStmt b → OuterCleanStack 0 rest → OuterCleanStack 0 (.repeatLoop rem b :: rest)
  | pop_succ (prev : ℕ) {rest} :
      OuterCleanStack prev rest → OuterCleanStack (prev + 1) (.popScope prev :: rest)
  | stmt_pos {fd : ℕ} (hfd : 1 ≤ fd) (s : ArithRAMStmt) {rest} :
      OuterCleanStack fd rest → OuterCleanStack fd (.stmt s :: rest)
  | repeat_pos {fd : ℕ} (hfd : 1 ≤ fd) (rem : ℕ) (b : ArithRAMStmt) {rest} :
      OuterCleanStack fd rest → OuterCleanStack fd (.repeatLoop rem b :: rest)

private lemma runArithRAMFuel_forward_outer {d : ℕ} (inp : ArithRAMInput d) :
    ∀ (fuel : ℕ) (stk rest : List ArithRAMCont)
      (m : ArithRAMMemory) (fd : ℕ) (bs extra : List Bool) (u₁ pk₁ u₂ pk₂ : ℕ)
      (out : ArithRAMExecOutcome),
      OuterCleanStack fd stk →
      (fd = 0 → m.popDepth 0 = m) →
      runArithRAMFuel inp fuel stk
        { mem := m, frameDepth := fd, remainingBits := bs,
          unitCost := u₁, peakCellSpace := pk₁ } = .halted out →
      ∃ (fuel' u_out pk_out : ℕ),
        u₁ + u_out = out.unitCost + u₂ ∧
        ∀ f_rem : ℕ,
          runArithRAMFuel inp (fuel' + f_rem) (stk ++ rest)
            { mem := m, frameDepth := fd, remainingBits := bs ++ extra,
              unitCost := u₂, peakCellSpace := pk₂ } =
          runArithRAMFuel inp f_rem rest
            { mem := out.mem
              frameDepth := 0
              remainingBits := extra
              unitCost := u_out
              peakCellSpace := pk_out }
  | fuel, [], rest, m, fd, bs, extra, u₁, pk₁, u₂, pk₂, out, hsafe, hpop, hrun => by
      cases hsafe with
      | nil_zero =>
          have hpop0 : m.popDepth 0 = m := hpop rfl
          have hhalted : bs.isEmpty = true ∧
              out = { mem := m.popDepth 0, unitCost := u₁, peakCellSpace := pk₁ } := by
            cases fuel <;> {
              dsimp only [runArithRAMFuel] at hrun
              split_ifs at hrun with hrem
              · exact ⟨hrem, (ArithRAMRunStatus.halted.inj hrun).symm⟩
            }
          have hnil : bs = [] := List.isEmpty_iff.mp hhalted.1
          have hout_mem : out.mem = m := by rw [hhalted.2]; dsimp only; exact hpop0
          have hout_u : out.unitCost = u₁ := by rw [hhalted.2]
          refine ⟨0, u₂, pk₂, by rw [hout_u], fun f_rem => ?_⟩
          simp only [Nat.zero_add, List.nil_append, hnil, hout_mem]
  | 0, _ :: _, _, _, _, _, _, _, _, _, _, _, _, _, hrun => by
      simp [runArithRAMFuel] at hrun
  | fuel + 1, item :: stk', rest, m, fd, bs, extra, u₁, pk₁, u₂, pk₂, out, hsafe, hpop, hrun => by
      cases hsafe with
      | pop_succ prev hrest =>
          simp only [runArithRAMFuel] at hrun
          have hpop' : prev = 0 → (m.popDepth prev).popDepth 0 = m.popDepth prev := by
            intro hp; subst hp; exact popDepth_zero_idem m
          rcases runArithRAMFuel_forward_outer inp fuel stk' rest
              (m.popDepth prev) prev bs extra u₁ pk₁ u₂ pk₂ out hrest hpop' hrun
            with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
          refine ⟨fuel' + 1, u_out, pk_out, hu_eq, fun f_rem => ?_⟩
          rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
          exact hstep f_rem
      | repeat_zero rem hb hrest =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m 0 bs extra u₁ pk₁ u₂ pk₂ out hrest hpop hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, hu_eq, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel
                  (.stmt _ :: .repeatLoop r _ :: stk') rest
                  m 0 bs extra u₁ pk₁ u₂ pk₂ out
                  (.stmt_zero hb (.repeat_zero r hb hrest)) hpop hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, hu_eq, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
      | repeat_pos hfd_pos rem b hrest =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m fd bs extra u₁ pk₁ u₂ pk₂ out hrest hpop hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, hu_eq, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel
                  (.stmt b :: .repeatLoop r b :: stk') rest
                  m fd bs extra u₁ pk₁ u₂ pk₂ out
                  (.stmt_pos hfd_pos b (.repeat_pos hfd_pos r b hrest)) hpop hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, hu_eq, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
      | stmt_zero hs hrest =>
          have hpop0 : m.popDepth 0 = m := hpop rfl
          cases hs with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m 0 bs extra (u₁ + 1) pk₁ (u₂ + 1) pk₂ out hrest (fun _ => hpop0) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | writeWordHeap t idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m.words idxE
              let e2 := evalIntExpr inp.toWordView 0 m.words valE
              let m' : ArithRAMMemory := { m with words := m.words.write (.heap t e1.1) e2.1 }
              let cSp := inp.inputCellSpace + m'.cellCount
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' 0 bs extra (u₁ + e1.2.1 + e2.2.1 + 1) (max pk₁ cSp)
                  (u₂ + e1.2.1 + e2.2.1 + 1) (max pk₂ cSp) out
                  hrest (fun _ => mem_popDepth_zero_writeWordHeap hpop0 _ _ _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | freeWordHeap t idxE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m.words idxE
              let m' : ArithRAMMemory := { m with words := m.words.free (.heap t e1.1) }
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' 0 bs extra (u₁ + e1.2.1 + 1) pk₁ (u₂ + e1.2.1 + 1) pk₂ out
                  hrest (fun _ => mem_popDepth_zero_freeWordHeap hpop0 _ _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | writeRealHeap t idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m.words idxE
              let e2 := evalRealExpr inp 0 m valE
              let m' : ArithRAMMemory := { m with reals := m.reals.write (.heap t e1.1) e2.1 }
              let cSp := inp.inputCellSpace + m'.cellCount
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' 0 bs extra (u₁ + e1.2.1 + e2.2 + 1) (max pk₁ cSp)
                  (u₂ + e1.2.1 + e2.2 + 1) (max pk₂ cSp) out
                  hrest (fun _ => mem_popDepth_zero_writeRealHeap hpop0 _ _ _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | freeRealHeap t idxE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m.words idxE
              let m' : ArithRAMMemory := { m with reals := m.reals.free (.heap t e1.1) }
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' 0 bs extra (u₁ + e1.2.1 + 1) pk₁ (u₂ + e1.2.1 + 1) pk₂ out
                  hrest (fun _ => mem_popDepth_zero_freeRealHeap hpop0 _ _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | randBitHeap t idxE =>
              cases bs with
              | nil => simp [runArithRAMFuel] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel] at hrun
                  let e1 := evalIntExpr inp.toWordView 0 m.words idxE
                  let v : ℤ := if bit then 1 else 0
                  let m' : ArithRAMMemory := { m with words := m.words.write (.heap t e1.1) v }
                  let cSp := inp.inputCellSpace + m'.cellCount
                  rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                      m' 0 bs' extra (u₁ + e1.2.1 + 1) (max pk₁ cSp)
                      (u₂ + e1.2.1 + 1) (max pk₂ cSp) out
                      hrest (fun _ => mem_popDepth_zero_writeWordHeap hpop0 _ _ _) hrun
                    with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
                  refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
                  rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega,
                      List.cons_append, List.cons_append]
                  exact hstep f_rem
          | seq h₁ h₂ =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel (_ :: _ :: stk') rest
                  m 0 bs extra u₁ pk₁ u₂ pk₂ out
                  (.stmt_zero h₁ (.stmt_zero h₂ hrest)) (fun _ => hpop0) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, hu_eq, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | @ite c s₁ s₂ h₁ h₂ =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalArithCond inp 0 m c
              have hch : OuterCleanStmt (if ec.1 then s₁ else s₂) := by
                dsimp only [ec]; split_ifs <;> assumption
              rcases runArithRAMFuel_forward_outer inp fuel (_ :: stk') rest
                  m 0 bs extra (u₁ + ec.2) pk₁ (u₂ + ec.2) pk₂ out
                  (.stmt_zero hch hrest) (fun _ => hpop0) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | @whileLoop c b hb =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalArithCond inp 0 m c
              cases hfl : ec.1 with
              | false =>
                  have hrun' : runArithRAMFuel inp fuel stk'
                      { mem := m, frameDepth := 0, remainingBits := bs,
                        unitCost := u₁ + ec.2, peakCellSpace := pk₁ } = .halted out := by
                    simpa only [ec, hfl, Bool.false_eq_true, ↓reduceIte] using hrun
                  rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                      m 0 bs extra (u₁ + ec.2) pk₁ (u₂ + ec.2) pk₂ out
                      hrest (fun _ => hpop0) hrun'
                    with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
                  refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
                  rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
                  dsimp only [runArithRAMFuel]
                  change runArithRAMFuel inp (fuel' + f_rem)
                    (if ec.1 = true then .stmt b :: .stmt (.whileLoop c b) :: (stk' ++ rest)
                     else stk' ++ rest) _ = _
                  rw [hfl]; exact hstep f_rem
              | true =>
                  have hrun' : runArithRAMFuel inp fuel (.stmt b :: .stmt (.whileLoop c b) :: stk')
                      { mem := m, frameDepth := 0, remainingBits := bs,
                        unitCost := u₁ + ec.2, peakCellSpace := pk₁ } = .halted out := by
                    simpa only [ec, hfl, ↓reduceIte] using hrun
                  rcases runArithRAMFuel_forward_outer inp fuel (_ :: _ :: stk') rest
                      m 0 bs extra (u₁ + ec.2) pk₁ (u₂ + ec.2) pk₂ out
                      (.stmt_zero hb (.stmt_zero (.whileLoop c hb) hrest))
                      (fun _ => hpop0) hrun'
                    with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
                  refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
                  rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
                  dsimp only [runArithRAMFuel]
                  change runArithRAMFuel inp (fuel' + f_rem)
                    (if ec.1 = true then .stmt b :: .stmt (.whileLoop c b) :: (stk' ++ rest)
                     else stk' ++ rest) _ = _
                  rw [hfl]; exact hstep f_rem
          | repeatN cnt hb =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m.words cnt
              let nIter := if 0 ≤ e1.1 then e1.1.toNat else 0
              rcases runArithRAMFuel_forward_outer inp fuel (.repeatLoop nIter _ :: stk') rest
                  m 0 bs extra (u₁ + e1.2.1) pk₁ (u₂ + e1.2.1) pk₂ out
                  (.repeat_zero nIter hb hrest) (fun _ => hpop0) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | localScope b =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel (.stmt b :: .popScope 0 :: stk') rest
                  (m.popDepth 0) 1 bs extra u₁ pk₁ u₂ pk₂ out
                  (.stmt_pos (by decide) b (.pop_succ 0 hrest)) (by omega) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, hu_eq, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
      | stmt_pos hfd_pos s hrest =>
          have hvac : ∀ m' : ArithRAMMemory, fd = 0 → m'.popDepth 0 = m' :=
            fun _ h0 => absurd h0 (by omega)
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m fd bs extra (u₁ + 1) pk₁ (u₂ + 1) pk₂ out hrest (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | writeWordHeap t idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView fd m.words idxE
              let e2 := evalIntExpr inp.toWordView fd m.words valE
              let m' : ArithRAMMemory := { m with words := m.words.write (.heap t e1.1) e2.1 }
              let cSp := inp.inputCellSpace + m'.cellCount
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' fd bs extra (u₁ + e1.2.1 + e2.2.1 + 1) (max pk₁ cSp)
                  (u₂ + e1.2.1 + e2.2.1 + 1) (max pk₂ cSp) out hrest (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | writeWordLocal var idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView fd m.words idxE
              let e2 := evalIntExpr inp.toWordView fd m.words valE
              let m' : ArithRAMMemory :=
                { m with words := m.words.write (.localFrame fd var e1.1) e2.1 }
              let cSp := inp.inputCellSpace + m'.cellCount
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' fd bs extra (u₁ + e1.2.1 + e2.2.1 + 1) (max pk₁ cSp)
                  (u₂ + e1.2.1 + e2.2.1 + 1) (max pk₂ cSp) out hrest (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | freeWordHeap t idxE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView fd m.words idxE
              let m' : ArithRAMMemory := { m with words := m.words.free (.heap t e1.1) }
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' fd bs extra (u₁ + e1.2.1 + 1) pk₁ (u₂ + e1.2.1 + 1) pk₂ out hrest (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | freeWordLocal var idxE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView fd m.words idxE
              let m' : ArithRAMMemory := { m with words := m.words.free (.localFrame fd var e1.1) }
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' fd bs extra (u₁ + e1.2.1 + 1) pk₁ (u₂ + e1.2.1 + 1) pk₂ out hrest (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | writeRealHeap t idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView fd m.words idxE
              let e2 := evalRealExpr inp fd m valE
              let m' : ArithRAMMemory := { m with reals := m.reals.write (.heap t e1.1) e2.1 }
              let cSp := inp.inputCellSpace + m'.cellCount
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' fd bs extra (u₁ + e1.2.1 + e2.2 + 1) (max pk₁ cSp)
                  (u₂ + e1.2.1 + e2.2 + 1) (max pk₂ cSp) out hrest (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | writeRealLocal var idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView fd m.words idxE
              let e2 := evalRealExpr inp fd m valE
              let m' : ArithRAMMemory :=
                { m with reals := m.reals.write (.localFrame fd var e1.1) e2.1 }
              let cSp := inp.inputCellSpace + m'.cellCount
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' fd bs extra (u₁ + e1.2.1 + e2.2 + 1) (max pk₁ cSp)
                  (u₂ + e1.2.1 + e2.2 + 1) (max pk₂ cSp) out hrest (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | freeRealHeap t idxE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView fd m.words idxE
              let m' : ArithRAMMemory := { m with reals := m.reals.free (.heap t e1.1) }
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' fd bs extra (u₁ + e1.2.1 + 1) pk₁ (u₂ + e1.2.1 + 1) pk₂ out hrest (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | freeRealLocal var idxE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView fd m.words idxE
              let m' : ArithRAMMemory := { m with reals := m.reals.free (.localFrame fd var e1.1) }
              rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                  m' fd bs extra (u₁ + e1.2.1 + 1) pk₁ (u₂ + e1.2.1 + 1) pk₂ out hrest (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | randBitHeap t idxE =>
              cases bs with
              | nil => simp [runArithRAMFuel] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel] at hrun
                  let e1 := evalIntExpr inp.toWordView fd m.words idxE
                  let v : ℤ := if bit then 1 else 0
                  let m' : ArithRAMMemory := { m with words := m.words.write (.heap t e1.1) v }
                  let cSp := inp.inputCellSpace + m'.cellCount
                  rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                      m' fd bs' extra (u₁ + e1.2.1 + 1) (max pk₁ cSp)
                      (u₂ + e1.2.1 + 1) (max pk₂ cSp) out hrest (hvac _) hrun
                    with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
                  refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
                  rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega,
                      List.cons_append, List.cons_append]
                  exact hstep f_rem
          | randBitLocal var idxE =>
              cases bs with
              | nil => simp [runArithRAMFuel] at hrun
              | cons bit bs' =>
                  simp only [runArithRAMFuel] at hrun
                  let e1 := evalIntExpr inp.toWordView fd m.words idxE
                  let v : ℤ := if bit then 1 else 0
                  let m' : ArithRAMMemory :=
                    { m with words := m.words.write (.localFrame fd var e1.1) v }
                  let cSp := inp.inputCellSpace + m'.cellCount
                  rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                      m' fd bs' extra (u₁ + e1.2.1 + 1) (max pk₁ cSp)
                      (u₂ + e1.2.1 + 1) (max pk₂ cSp) out hrest (hvac _) hrun
                    with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
                  refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
                  rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega,
                      List.cons_append, List.cons_append]
                  exact hstep f_rem
          | seq s₁ s₂ =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel (_ :: _ :: stk') rest
                  m fd bs extra u₁ pk₁ u₂ pk₂ out
                  (.stmt_pos hfd_pos s₁ (.stmt_pos hfd_pos s₂ hrest)) (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, hu_eq, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | ite c s₁ s₂ =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalArithCond inp fd m c
              rcases runArithRAMFuel_forward_outer inp fuel (_ :: stk') rest
                  m fd bs extra (u₁ + ec.2) pk₁ (u₂ + ec.2) pk₂ out
                  (.stmt_pos hfd_pos _ hrest) (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | whileLoop c b =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalArithCond inp fd m c
              cases hfl : ec.1 with
              | false =>
                  have hrun' : runArithRAMFuel inp fuel stk'
                      { mem := m, frameDepth := fd, remainingBits := bs,
                        unitCost := u₁ + ec.2, peakCellSpace := pk₁ } = .halted out := by
                    simpa only [ec, hfl, Bool.false_eq_true, ↓reduceIte] using hrun
                  rcases runArithRAMFuel_forward_outer inp fuel stk' rest
                      m fd bs extra (u₁ + ec.2) pk₁ (u₂ + ec.2) pk₂ out
                      hrest (hvac _) hrun'
                    with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
                  refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
                  rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
                  dsimp only [runArithRAMFuel]
                  change runArithRAMFuel inp (fuel' + f_rem)
                    (if ec.1 = true then .stmt b :: .stmt (.whileLoop c b) :: (stk' ++ rest)
                     else stk' ++ rest) _ = _
                  rw [hfl]; exact hstep f_rem
              | true =>
                  have hrun' : runArithRAMFuel inp fuel (.stmt b :: .stmt (.whileLoop c b) :: stk')
                      { mem := m, frameDepth := fd, remainingBits := bs,
                        unitCost := u₁ + ec.2, peakCellSpace := pk₁ } = .halted out := by
                    simpa only [ec, hfl, ↓reduceIte] using hrun
                  rcases runArithRAMFuel_forward_outer inp fuel (_ :: _ :: stk') rest
                      m fd bs extra (u₁ + ec.2) pk₁ (u₂ + ec.2) pk₂ out
                      (.stmt_pos hfd_pos b (.stmt_pos hfd_pos (.whileLoop c b) hrest))
                      (hvac _) hrun'
                    with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
                  refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
                  rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
                  dsimp only [runArithRAMFuel]
                  change runArithRAMFuel inp (fuel' + f_rem)
                    (if ec.1 = true then .stmt b :: .stmt (.whileLoop c b) :: (stk' ++ rest)
                     else stk' ++ rest) _ = _
                  rw [hfl]; exact hstep f_rem
          | repeatN cnt b =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView fd m.words cnt
              let nIter := if 0 ≤ e1.1 then e1.1.toNat else 0
              rcases runArithRAMFuel_forward_outer inp fuel (.repeatLoop nIter b :: stk') rest
                  m fd bs extra (u₁ + e1.2.1) pk₁ (u₂ + e1.2.1) pk₂ out
                  (.repeat_pos hfd_pos nIter b hrest) (hvac _) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, by omega, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem
          | localScope b =>
              simp only [runArithRAMFuel] at hrun
              rcases runArithRAMFuel_forward_outer inp fuel (.stmt b :: .popScope fd :: stk') rest
                  (m.popDepth fd) (fd + 1) bs extra u₁ pk₁ u₂ pk₂ out
                  (.stmt_pos (by omega) b (.pop_succ fd hrest)) (by omega) hrun
                with ⟨fuel', u_out, pk_out, hu_eq, hstep⟩
              refine ⟨fuel' + 1, u_out, pk_out, hu_eq, fun f_rem => ?_⟩
              rw [show (fuel' + 1) + f_rem = (fuel' + f_rem) + 1 by omega, List.cons_append]
              exact hstep f_rem

/-- Tightens any `fd = 0` `RandExecAt` on an `OuterCleanStmt` (e.g. `BoxSafeOuter`) so its output
memory is a pure deterministic function `fn : (Fin B → Bool) → ArithRAMMemory` of the `B` random bits! -/
theorem RandExecAt.tighten_outer {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {B C : ℕ} {mem₀ : ArithRAMMemory}
    {Post : (Fin B → Bool) → ArithRAMMemory → Prop}
    (hs : OuterCleanStmt s)
    (hmem₀ : mem₀.popDepth 0 = mem₀)
    (h : RandExecAt 0 inp s B mem₀ Post C)
    (hpop_post : ∀ f m₁, Post f m₁ → m₁.popDepth 0 = m₁) :
    ∃ fn : (Fin B → Bool) → ArithRAMMemory,
      (∀ f : Fin B → Bool, (fn f).popDepth 0 = fn f ∧ Post f (fn f)) ∧
      RandExecAt 0 inp s B mem₀ (fun f m₁ => m₁ = fn f ∧ Post f m₁) C := by
  classical
  have hex_canon : ∀ f : Fin B → Bool,
      ∃ (fuel_f u_f pk_f : ℕ) (m_f : ArithRAMMemory),
        u_f ≤ C ∧
        m_f.popDepth 0 = m_f ∧
        Post f m_f ∧
        runArithRAMFuel inp fuel_f [.stmt s]
          { mem := mem₀, frameDepth := 0, remainingBits := List.ofFn f,
            unitCost := 0, peakCellSpace := 0 } =
        .halted { mem := m_f, unitCost := u_f, peakCellSpace := pk_f } := by
    intro f
    have hbs_f : B ≤ (List.ofFn f).length := by simp
    rcases h.2 (List.ofFn f) hbs_f 0 0 [] with ⟨fuel_f, u_f, pk_f, m_f, hu_f, hp_f, hrun_f⟩
    have hf_eq : (fun i : Fin B => (List.ofFn f)[i.val]'(lt_of_lt_of_le i.isLt hbs_f)) = f := by
      ext i; simp
    rw [hf_eq] at hp_f
    have hm_pop : m_f.popDepth 0 = m_f := hpop_post f m_f hp_f
    have h0 := hrun_f 0
    have hdrop : (List.ofFn f).drop B = [] := by simp
    simp only [Nat.add_zero, hdrop, runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, hm_pop] at h0
    exact ⟨fuel_f, u_f, pk_f, m_f, by omega, hm_pop, hp_f, h0⟩
  choose fuel_fn u_fn pk_fn fn hspec using hex_canon
  refine ⟨fn, fun f => ⟨(hspec f).2.1, (hspec f).2.2.1⟩, h.1, ?_⟩
  intro bs hbs u₀ peak₀ rest
  let f : Fin B → Bool := fun i => bs[i.val]'(lt_of_lt_of_le i.isLt hbs)
  have htake : List.ofFn f = bs.take B := by
    apply List.ext_getElem
    · simp [Nat.min_eq_left hbs]
    · intro i hi₁ hi₂
      simp [f]
  have hbs_split : bs = List.ofFn f ++ bs.drop B := by
    rw [htake, List.take_append_drop]
  rcases hspec f with ⟨hu_f, _, hp_f, hrun_f⟩
  rcases runArithRAMFuel_forward_outer inp (fuel_fn f) [.stmt s] rest
      mem₀ 0 (List.ofFn f) (bs.drop B) 0 0 u₀ peak₀
      { mem := fn f, unitCost := u_fn f, peakCellSpace := pk_fn f }
      (.stmt_zero hs .nil_zero) (fun _ => hmem₀) hrun_f
    with ⟨fuel', u₂, pk₂, hu_eq, hstep⟩
  dsimp only at hu_eq hstep
  refine ⟨fuel', u₂, pk₂, fn f, by omega, ⟨rfl, hp_f⟩, fun f_rem => ?_⟩
  have hh := hstep f_rem
  rw [List.singleton_append, ← hbs_split] at hh
  exact hh

end UL.Proof_lem_7_2_RacerP46
