import UL.Proof.lem_7_2.CG01_H4a2c

set_option autoImplicit false

namespace UL.Proof_lem_7_2_RacerP46

open UL
open UL.Proof_lem_7_2_RacerP33
open UL.Proof.lem_7_2.RaceV30


/-- Helper extending a finite two-phase build trace `(ph_tr, cur_tr, Spar_tr)` on `0 .. τ_end` to all `τ : ℕ`. -/
private def extendTwoPhaseState (m B_scan : ℕ) : ℕ × ℕ → ℕ × ℕ
  | (ph, cur) =>
      if ph = 0 then
        if cur + (B_scan + 1) < m then (0, cur + (B_scan + 1)) else (1, 0)
      else
        (2, 0)

private def extTailPair (m B_scan ph_end cur_end : ℕ) : ℕ → ℕ × ℕ
  | 0 => (ph_end, cur_end)
  | k + 1 => extendTwoPhaseState m B_scan (extTailPair m B_scan ph_end cur_end k)

/-- Operation 4: At `g.t_cur = g.H_job` (`remTicks = 0`), invoke `h_lem_C_2 : S_lem_C_2` and
`two_phase_job_build_ready` to certify readiness, residual leaf size `≤ 3 * L + 2`, and valid ages
`< jobStartAge` on all `K = g.lvs.length` replacement levels! -/
theorem ActiveJobGhost.finishAtDeadline
    (h_lem_C_2 : S_lem_C_2)
    {d n D K₀ L B_scan nextUid : ℕ}
    {ghostCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {S_cur_uid : Finset ℕ}
    (g : ActiveJobGhost d n D L B_scan nextUid ghostCoords S_cur_uid)
    (hD : 3 ≤ D)
    (hL_floor : 68719476736 * D ^ 4 ≤ L)
    (hL_eq10 : SatisfiesLeafCutoffEq10 d n (1 / (4 * (D : ℝ) ^ 2)) 0 K₀ L)
    (hB_floor : 16777216 * D ^ 4 ≤ B_scan)
    (hdone : g.t_cur = g.H_job) :
    let α : ℝ := 1 / (4 * (D : ℝ) ^ 2)
    g.closed = true ∧
    g.ph_cur = 2 ∧
    (prefixResidual ghostCoords g.lvs S_cur_uid).card ≤ 3 * L + 2 ∧
    ∀ (j : ℕ) (hj : j < g.lvs.length),
      let lv := g.lvs[j]'hj
      lv.backgroundReady = true ∧
      2 * L + 1 < lv.birthSnapshot.card ∧
      (∀ u ∈ lv.birthSnapshot, u < nextUid) ∧
      PassesBirthCoreCheck α ghostCoords lv.ball lv.birthSnapshot ∧
      g.openRem j < jobStartAge α lv.birthSnapshot.card ∧
      (g.openRem j : ℝ) ≤ α * (lv.birthSnapshot.card : ℝ) / 16 ∧
      ∃ trueAge ≤ g.openRem j,
        HasNodeAge lv.birthSnapshot (prefixResidual ghostCoords (g.lvs.take j) S_cur_uid) trueAge := by
  intro α
  obtain ⟨hα_pos, hα_half, _, _, _⟩ := alpha_pos_and_lt_half D hD
  have hα_le1 : α ≤ 1 := by linarith
  let T := g.H_job
  have hT_eq : g.t_cur = T := hdone
  let S_fn : Fin (T + 1) → Finset ℕ := fun s => g.S_root s.val
  let ev_fn : Fin T → PoolUpdateEvent ℕ := fun t => g.ev t.val
  let job_fn : Fin (T + 1) → PendingReplacementJob d ℕ := fun s => g.job_hist s.val
  have htick_all : ∀ e ∈ List.ofFn ev_fn, e.isClockTick = true := by
    intro e he
    rcases List.mem_ofFn.mp he with ⟨t, rfl⟩
    exact g.hev_tick t.val (by omega)
  have hcount_drop : ∀ k ≤ T, poolClockTickCount ((List.ofFn ev_fn).drop k) = T - k := by
    intro k hk
    unfold poolClockTickCount
    have hall_drop : ∀ e ∈ (List.ofFn ev_fn).drop k, e.isClockTick = true :=
      fun e he => htick_all e (List.mem_of_mem_drop he)
    rw [List.countP_eq_length.mpr hall_drop, List.length_drop, List.length_ofFn]
  have hdeadline : poolClockTickCount (List.ofFn ev_fn) = jobDeadlineTicks α (S_fn 0).card := by
    have h0 := hcount_drop 0 (Nat.zero_le T)
    rw [List.drop_zero, Nat.sub_zero] at h0
    dsimp only [S_fn, T] at h0 ⊢
    exact h0.trans g.hH_eq
  have hstep_fn : ∀ t : Fin T,
      if (ev_fn t).isClockTick then
        ScheduleTickPass α L ghostCoords
          (updatePendingJobRootPool ghostCoords (job_fn t.castSucc) (ev_fn t) (S_fn t.succ)) (job_fn t.succ)
      else
        job_fn t.succ = job_fn t.castSucc := by
    intro t
    have hck : (ev_fn t).isClockTick = true := g.hev_tick t.val (by omega)
    rw [if_pos hck]
    exact g.hstep t.val (by omega)
  -- Prove `h_build` for `S_lem_C_2` via `two_phase_job_build_ready`:
  have hbuild_fn : ∀ (idx : ℕ) (t_open : Fin (T + 1)) (lv : OpenedJobLevel d ℕ),
      (∀ s : Fin (T + 1), s < t_open → (job_fn s).completedPrefix[idx]? = none) →
      (job_fn t_open).completedPrefix[idx]? = some lv →
      ∃ b : ℕ,
        (b : ℝ) ≤ α ^ 2 * (lv.birthSnapshot.card : ℝ) / (64 * (scheduleCStar : ℝ)) ∧
        ∀ s : Fin (T + 1),
          t_open ≤ s →
          b ≤ (job_fn t_open).remainingTicks - (job_fn s).remainingTicks →
          ∃ lv_s : OpenedJobLevel d ℕ,
            (job_fn s).completedPrefix[idx]? = some lv_s ∧ lv_s.backgroundReady = true := by
    intro idx t_open lv hbefore hopen
    -- Since `(job_fn (Fin.last T)).completedPrefix = g.lvs` and `idx` is present at `t_open`, `idx < g.lvs.length`!
    have hidx_lt : idx < g.lvs.length := by
      -- If `idx ≥ g.lvs.length`, wait: let's check `(job_fn t_open).completedPrefix[idx]? = some lv` against `hlvs_inv`!
      -- Note `job_fn (Fin.last T) = g.job_hist g.t_cur`, which has `completedPrefix = g.lvs`.
      -- Monotonicity of `completedPrefix.length` gives `(job_fn t_open).completedPrefix.length ≤ g.lvs.length`!
      have h1step : ∀ t < g.t_cur,
          (g.job_hist t).completedPrefix.length ≤ (g.job_hist (t + 1)).completedPrefix.length := by
        intro t ht
        have hch := (g.hstep t ht).1
        have hch_len : ∀ {x y : PendingReplacementJob d ℕ},
            JobWithinTickChain α L ghostCoords x y →
              x.completedPrefix.length ≤ y.completedPrefix.length := by
          intro x y hc
          induction hc with
          | refl _ => exact le_rfl
          | markReady hm _ ih => exact le_trans (le_of_eq hm.2.2.2.2.length_eq) ih
          | gate hg _ ih =>
              rcases hg with ⟨_, _, _, (⟨_, rfl⟩ | ⟨_, _, _, _, _, rfl⟩)⟩
              · exact ih
              · simp only [openLargeLevelInJob, List.length_append, List.length_singleton] at ih; omega
        simpa [updatePendingJobRootPool] using hch_len hch
      have hmono : ∀ d_k : ℕ, t_open.val + d_k ≤ g.t_cur →
          (g.job_hist t_open.val).completedPrefix.length ≤ (g.job_hist (t_open.val + d_k)).completedPrefix.length := by
        intro d_k hdk
        induction d_k with
        | zero => simp
        | succ d_k ih =>
            exact le_trans (ih (by omega)) (h1step (t_open.val + d_k) (by omega))
      have hle_end := hmono (g.t_cur - t_open.val) (by omega)
      rw [Nat.add_sub_of_le (by have := t_open.isLt; omega), g.hcur_job] at hle_end
      have hlt_open : idx < (job_fn t_open).completedPrefix.length := by
        by_contra hge
        rw [List.getElem?_eq_none (by omega)] at hopen
        cases hopen
      exact lt_of_lt_of_le hlt_open hle_end
    rcases g.hlvs_inv idx hidx_lt with ⟨hlarge, _, _, s_open, hs_le, _, _, _, hnone_s,
      ⟨ph_tr, cur_tr, Spar_tr, hp0, hc0, hSc0, htr_step, htr_hist, _⟩⟩
    -- Show `t_open.val = s_open`:
    have ht_eq_s : t_open.val = s_open := by
      by_contra hne
      rcases lt_or_gt_of_ne hne with hlt | hgt
      · have hn := hnone_s t_open.val hlt
        dsimp [job_fn] at hopen; rw [hn] at hopen; cases hopen
      · rcases htr_hist s_open le_rfl hs_le with ⟨lv0, hsome0, _⟩
        have hn := hbefore ⟨s_open, by omega⟩ hgt
        dsimp [job_fn] at hn; rw [hn] at hsome0; cases hsome0
    rcases htr_hist t_open.val (by omega) (by have := t_open.isLt; omega) with ⟨lv_to, hsome_to, hbs_to, _, _⟩
    dsimp [job_fn] at hopen
    rw [hopen] at hsome_to
    injection hsome_to with hlv_eq
    subst hlv_eq
    let m_b := (g.lvs[idx]'hidx_lt).birthSnapshot.card
    let τ_end := g.t_cur - s_open
    let ph_ext : ℕ → ℕ := fun τ =>
      if τ ≤ τ_end then ph_tr τ else (extTailPair m_b B_scan (ph_tr τ_end) (cur_tr τ_end) (τ - τ_end)).1
    let cur_ext : ℕ → ℕ := fun τ =>
      if τ ≤ τ_end then cur_tr τ else (extTailPair m_b B_scan (ph_tr τ_end) (cur_tr τ_end) (τ - τ_end)).2
    let Spar_ext : ℕ → Finset ℕ := fun τ =>
      if τ ≤ τ_end then Spar_tr τ else Spar_tr τ_end
    have htail_eq : ∀ k : ℕ,
        (ph_ext (τ_end + k), cur_ext (τ_end + k)) =
          extTailPair m_b B_scan (ph_tr τ_end) (cur_tr τ_end) k := by
      intro k
      cases k with
      | zero => simp [ph_ext, cur_ext, extTailPair]
      | succ k =>
          have hgt : ¬ (τ_end + (k + 1) ≤ τ_end) := by omega
          have hsub : τ_end + (k + 1) - τ_end = k + 1 := by omega
          simp [ph_ext, cur_ext, hgt, hsub]
    rcases two_phase_job_build_ready hD hL_floor (by simpa [m_b] using hlarge) hB_floor
        ph_ext cur_ext Spar_ext
        (by simp [ph_ext, hp0])
        (by simp [cur_ext, hc0])
        (by simp [Spar_ext, hSc0])
        (fun τ => by
          by_cases hlt : τ < τ_end
          · have h1 : τ ≤ τ_end := le_of_lt hlt
            have h2 : τ + 1 ≤ τ_end := hlt
            simp only [Spar_ext, if_pos h1, if_pos h2]
            exact (htr_step τ hlt).1
          · have hge : τ_end ≤ τ := by omega
            have h2 : ¬ (τ + 1 ≤ τ_end) := by omega
            by_cases heq : τ = τ_end
            · subst heq; simp [Spar_ext, h2]
            · have h1 : ¬ (τ ≤ τ_end) := by omega
              simp [Spar_ext, h1, h2])
        (fun τ => by
          by_cases hlt : τ < τ_end
          · have h1 : τ ≤ τ_end := le_of_lt hlt
            have h2 : τ + 1 ≤ τ_end := hlt
            simp only [ph_ext, cur_ext, Spar_ext, if_pos h1, if_pos h2]
            exact (htr_step τ hlt).2
          · have hge : τ_end ≤ τ := by omega
            let k := τ - τ_end
            have hτk : τ = τ_end + k := by omega
            have hτk1 : τ + 1 = τ_end + (k + 1) := by omega
            have hp_k : ph_ext (τ_end + k) = (extTailPair m_b B_scan (ph_tr τ_end) (cur_tr τ_end) k).1 :=
              congrArg Prod.fst (htail_eq k)
            have hc_k : cur_ext (τ_end + k) = (extTailPair m_b B_scan (ph_tr τ_end) (cur_tr τ_end) k).2 :=
              congrArg Prod.snd (htail_eq k)
            have hp_k1 : ph_ext (τ_end + (k + 1)) = (extTailPair m_b B_scan (ph_tr τ_end) (cur_tr τ_end) (k + 1)).1 :=
              congrArg Prod.fst (htail_eq (k + 1))
            have hc_k1 : cur_ext (τ_end + (k + 1)) = (extTailPair m_b B_scan (ph_tr τ_end) (cur_tr τ_end) (k + 1)).2 :=
              congrArg Prod.snd (htail_eq (k + 1))
            rw [← hτk] at hp_k hc_k
            rw [← hτk1] at hp_k1 hc_k1
            rw [hp_k, hc_k, hp_k1, hc_k1]
            dsimp only [extTailPair, extendTwoPhaseState]
            set p0 := (extTailPair m_b B_scan (ph_tr τ_end) (cur_tr τ_end) k).1
            set c0 := (extTailPair m_b B_scan (ph_tr τ_end) (cur_tr τ_end) k).2
            refine ⟨fun hp0_eq => ?_, fun hp1_eq => ?_, fun hp2_eq => ?_⟩
            · rw [if_pos hp0_eq]
              exact ⟨fun hlt_m => by rw [if_pos hlt_m]; exact ⟨rfl, rfl⟩,
                     fun hge_m => by rw [if_neg (by omega)]; exact ⟨rfl, rfl⟩⟩
            · rw [if_neg (by omega)]; exact Or.inl rfl
            · rw [if_neg (by omega)])
      with ⟨hb_real, hb_ready⟩
    refine ⟨maxLevelBuildTicks α m_b, by rw [hbs_to]; exact hb_real, fun s hs_ge hb_le => ?_⟩
    have hrem_to := (g.hrem_eq t_open.val (by have := t_open.isLt; omega)).1
    have hrem_s := (g.hrem_eq s.val (by have := s.isLt; omega)).1
    have hdiff : (job_fn t_open).remainingTicks - (job_fn s).remainingTicks = s.val - s_open := by
      dsimp [job_fn]
      rw [hrem_to, hrem_s, ht_eq_s]
      have hs_le_H : s.val ≤ g.H_job := by have := s.isLt; omega
      have hto_le_s : s_open ≤ s.val := by rw [← ht_eq_s]; exact hs_ge
      omega
    rw [hdiff] at hb_le
    have hs_le_tc : s.val ≤ g.t_cur := by have := s.isLt; omega
    have hτ_le : s.val - s_open ≤ τ_end := by dsimp [τ_end]; omega
    have hph2_ext := hb_ready (s.val - s_open) hb_le
    simp only [ph_ext, if_pos hτ_le] at hph2_ext
    rcases htr_hist s.val (by rw [← ht_eq_s]; exact hs_ge) hs_le_tc with ⟨lv_s, hget_s, _, _, hrdy_s⟩
    exact ⟨lv_s, hget_s, by rw [hrdy_s, hph2_ext]; rfl⟩
  -- Invoke `h_lem_C_2`!
  have hC2 := h_lem_C_2 d n ℕ ghostCoords α 0 K₀ L T S_fn ev_fn job_fn
    hα_pos hα_le1 hL_eq10
    (fun s => g.hS_cap s.val (by have := s.isLt; omega))
    g.hm0
    (fun t => g.hev_valid t.val (by omega))
    hdeadline g.hinit hstep_fn hbuild_fn
  rcases hC2 with ⟨hrdy_end, hwf_end, _, _, hres_le, hages_end, _, _⟩
  have hlast_job : job_fn (Fin.last T) = g.job_hist g.t_cur := by
    dsimp [job_fn]; rw [hT_eq]
  have hlast_S : S_fn (Fin.last T) = S_cur_uid := by
    dsimp [S_fn]; rw [← hT_eq, g.hS_last]
  rw [hlast_job, g.hcur_job] at hrdy_end hwf_end hres_le hages_end
  rw [hlast_S] at hwf_end hages_end
  have hcl_true : g.closed = true := hrdy_end.2.1
  have hall_ready : ∀ (j : ℕ) (hj : j < g.lvs.length), (g.lvs[j]'hj).backgroundReady = true :=
    fun j hj => hrdy_end.2.2 _ (List.getElem_mem hj)
  have hph_2 : g.ph_cur = 2 := by
    have hr := hall_ready (g.lvs.length - 1) (Nat.sub_lt g.hlvs_pos Nat.one_pos)
    rw [g.hlast_ready] at hr
    exact of_decide_eq_true hr
  refine ⟨hcl_true, hph_2, hres_le, fun j hj => ?_⟩
  rcases g.hlvs_inv j hj with ⟨hlarge, huid_b, hpass, s_open, hs_le, hrem_j, hcan, _, hnone_s, htr_pack⟩
  rcases htr_pack with ⟨_, _, _, _, _, _, _, htr_hist, _⟩
  rcases hages_end ⟨j, hj⟩ with ⟨t_open_f, hlt_len, hge_len, hel_real, trueAge, hta_le, hta_age⟩
  -- Show `t_open_f.val = s_open`!
  have ht_f_eq : t_open_f.val = s_open := by
    by_contra hne
    rcases lt_or_gt_of_ne hne with hlt | hgt
    · have hn := hnone_s t_open_f.val hlt
      have hsome := List.getElem?_eq_getElem (l := (job_fn t_open_f).completedPrefix) hge_len
      dsimp [job_fn] at hsome; rw [hn] at hsome; cases hsome
    · rcases htr_hist s_open le_rfl hs_le with ⟨lv0, hsome0, _⟩
      have hle_j := hlt_len ⟨s_open, by omega⟩ hgt
      dsimp [job_fn] at hle_j
      rw [List.getElem?_eq_none hle_j] at hsome0; cases hsome0
  have hel_eq : poolClockTickCount ((List.ofFn ev_fn).drop t_open_f.val) = g.openRem j := by
    rw [hcount_drop t_open_f.val (by have := t_open_f.isLt; omega), ht_f_eq, hrem_j]
  rw [hel_eq] at hta_le
  rcases openRem_lt_jobStartAge hD hL_floor hlarge hcan with ⟨hop_lt_st, hop_le_16⟩
  exact ⟨hall_ready j hj, hlarge, huid_b, hpass, hop_lt_st, hop_le_16, trueAge, hta_le, hta_age⟩


end UL.Proof_lem_7_2_RacerP46
