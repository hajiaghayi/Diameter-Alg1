import UL.Stmt.clm_5_1_chain_contraction
import UL.Stmt.lem_5_1
set_option autoImplicit false

namespace UL

open Classical in
private theorem pointCount_subtype_eq_card_filter_5_1 {d : ℕ} {ι : Type*} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d)) (A : Finset ι)
    (T : Set (EuclideanSpace ℝ (Fin d))) :
    pointCount (fun i : ↥A => pts i.1) T = (A.filter (fun i => pts i ∈ T)).card := by
  unfold pointCount
  rw [← Finset.card_map ⟨Subtype.val, Subtype.val_injective⟩]
  apply congrArg Finset.card
  ext x
  simp [and_comm]

open Classical in
private theorem nodeCore_subset {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) :
    nodeCore pts o V S ⊆ S :=
  Finset.filter_subset _ S

open Classical in
private theorem card_nodeResidual_add_nodeCore {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) :
    (nodeResidual pts o V S).card + (nodeCore pts o V S).card = S.card :=
  Finset.card_sdiff_add_card_eq_card (Finset.filter_subset _ S)

open Classical in
private theorem nodeResidual_subset {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) :
    nodeResidual pts o V S ⊆ S :=
  Finset.sdiff_subset

private theorem hasNodeAge_to_ops {ι : Type*} [DecidableEq ι]
    {P₀ S : Finset ι} {age : ℕ} (h : HasNodeAge P₀ S age) :
    S.card ≤ P₀.card + age ∧
    ∃ ops : List (ι ⊕ ι),
      (ops.filter Sum.isRight).length ≤ age ∧
      ops.foldl (fun acc op =>
        match op with
        | Sum.inl j => insert j acc
        | Sum.inr j => acc.erase j) P₀ = S := by
  induction age generalizing S with
  | zero =>
    rcases h with ⟨seq, h0, hlast, _⟩
    have hEq : P₀ = S := by
      have : (0 : Fin 1) = Fin.last 0 := rfl
      rw [← h0, ← hlast, this]
    subst hEq
    exact ⟨by omega, [], by simp, rfl⟩
  | succ t ih =>
    rcases h with ⟨seq, h0, hlast, hstep⟩
    let seq' : Fin (t + 1) → Finset ι := fun j => seq j.castSucc
    let S_mid : Finset ι := seq (Fin.last t).castSucc
    have hmid : HasNodeAge P₀ S_mid t := by
      refine ⟨seq', h0, rfl, fun r => ?_⟩
      have hsucc : (r.succ : Fin (t + 1)).castSucc = r.castSucc.succ := by
        ext
        simp
      dsimp only [seq']
      rw [hsucc]
      exact hstep r.castSucc
    rcases ih hmid with ⟨hcard_mid, ops_mid, hfilt_mid, hfold_mid⟩
    have hlast_step : IsInputChange S_mid S := by
      have hlast_eq : (Fin.last t).succ = Fin.last (t + 1) := by
        ext
        simp
      have hs := hstep (Fin.last t)
      rwa [hlast_eq, hlast] at hs
    rcases hlast_step with ⟨j, _, hS_eq⟩ | ⟨j, _, hS_eq⟩
    · have hS_ins : S = insert j S_mid := by
        rw [hS_eq]
        ext x
        simp
      refine ⟨?_, ops_mid ++ [Sum.inl j], ?_, ?_⟩
      · rw [hS_ins]
        have h1 : (insert j S_mid).card ≤ S_mid.card + 1 := Finset.card_insert_le j S_mid
        omega
      · simp only [List.filter_append]
        have hnil : ([Sum.inl j] : List (ι ⊕ ι)).filter Sum.isRight = [] := rfl
        rw [hnil, List.append_nil]
        omega
      · simp [List.foldl_append, hfold_mid, hS_ins]
    · have hS_era : S = S_mid.erase j := by
        rw [hS_eq]
        ext x
        simp
      refine ⟨?_, ops_mid ++ [Sum.inr j], ?_, ?_⟩
      · rw [hS_era]
        have h1 : (S_mid.erase j).card ≤ S_mid.card := Finset.card_erase_le
        omega
      · simp only [List.filter_append]
        have hcons : ([Sum.inr j] : List (ι ⊕ ι)).filter Sum.isRight = [Sum.inr j] := rfl
        rw [hcons, List.length_append, List.length_singleton]
        omega
      · simp [List.foldl_append, hfold_mid, hS_era]

private theorem chainInput_zero {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι) :
    chainInput pts nodes P 0 = P := rfl

private theorem chainInput_succ {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (i : Fin k) :
    chainInput pts nodes P i.succ =
      (nodes i).residual pts (chainInput pts nodes P i.castSucc) := by
  unfold chainInput
  simp only [Fin.val_succ, Fin.val_castSucc]
  rfl

private theorem chainInput_cons_succ {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (N₀ : ChainNode d) (tail : Fin k → ChainNode d)
    (P : Finset ι) (j : Fin (k + 1)) :
    chainInput pts (Fin.cons N₀ tail) P j.succ =
      chainInput pts tail (N₀.residual pts P) j := by
  rcases j with ⟨m, hm⟩
  induction m with
  | zero =>
    rw [show (⟨0, hm⟩ : Fin (k + 1)) = 0 from rfl, chainInput_succ, Fin.cons_zero]
    rfl
  | succ m ih =>
    have hm_lt : m < k := Nat.lt_of_succ_lt_succ hm
    have ih_val : chainInput pts (Fin.cons N₀ tail) P (⟨m, Nat.lt_succ_of_lt hm_lt⟩ : Fin (k + 1)).succ =
        chainInput pts tail (N₀.residual pts P) ⟨m, Nat.lt_succ_of_lt hm_lt⟩ :=
      ih (Nat.lt_succ_of_lt hm_lt)
    rw [show (⟨m + 1, hm⟩ : Fin (k + 1)).succ = ((⟨m, hm_lt⟩ : Fin k).succ : Fin (k + 1)).succ from rfl,
      chainInput_succ, Fin.cons_succ]
    have hcast : ((⟨m, hm_lt⟩ : Fin k).succ : Fin (k + 1)).castSucc =
        (⟨m, Nat.lt_succ_of_lt hm_lt⟩ : Fin (k + 1)).succ := rfl
    rw [hcast, ih_val]
    rw [show (⟨m + 1, hm⟩ : Fin (k + 1)) = (⟨m, hm_lt⟩ : Fin k).succ from rfl, chainInput_succ]
    rfl

private theorem liftVariance_nonneg_of_centerpoint {d : ℕ} {ι : Type} [DecidableEq ι]
    (h_lem_5_1 : S_lem_5_1)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (P₀ : Finset ι) (hm : 1 ≤ P₀.card)
    {α : ℝ} (hα : 0 < α)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s)) :
    0 ≤ liftVariance o s := by
  unfold S_lem_5_1 at h_lem_5_1
  unfold IsCenterpoint at hcp
  rw [Fintype.card_coe] at hcp
  have h51 := (h_lem_5_1 d ι pts P₀ hm α hα o s hcp).2.2 0 [] (by simp)
  dsimp only at h51
  have hsq : α * (P₀.card : ℝ) - (0 : ℕ) ≤
      (pointCount (fun i : ↥(P₀ ∩ P₀) => pts i.1) {x | ‖x - o‖ ^ 2 ≤ liftVariance o s} : ℝ) :=
    h51.2.1
  have hm_pos : (0 : ℝ) < (P₀.card : ℝ) := by exact_mod_cast (Nat.lt_of_lt_of_le Nat.zero_lt_one hm)
  have hpos_real : (0 : ℝ) <
      (pointCount (fun i : ↥(P₀ ∩ P₀) => pts i.1) {x | ‖x - o‖ ^ 2 ≤ liftVariance o s} : ℝ) := by
    have hαm : 0 < α * (P₀.card : ℝ) := mul_pos hα hm_pos
    push_cast at hsq
    linarith
  have hpos_nat : 0 <
      pointCount (fun i : ↥(P₀ ∩ P₀) => pts i.1) {x | ‖x - o‖ ^ 2 ≤ liftVariance o s} := by
    exact_mod_cast hpos_real
  unfold pointCount at hpos_nat
  obtain ⟨i₀, hi₀⟩ := Finset.card_pos.mp hpos_nat
  have hi₀_mem : ‖pts i₀.1 - o‖ ^ 2 ≤ liftVariance o s := (Finset.mem_filter.mp hi₀).2
  exact (sq_nonneg _).trans hi₀_mem

private theorem single_node_contraction
    (h_lem_5_1 : S_lem_5_1)
    {d : ℕ} {ι : Type} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {α : ℝ} (hα : 0 < α) (hα1 : α ≤ 1)
    (P₀ S : Finset ι) (hm : 1 ≤ P₀.card)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s))
    (age : ℕ) (hage : HasNodeAge P₀ S age)
    (hage_le : (age : ℝ) ≤ α * (P₀.card : ℝ) / 16) :
    let V := liftVariance o s
    let C := nodeCore pts o V S
    let child := nodeResidual pts o V S
    let m : ℝ := P₀.card
    15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
    (S.card : ℝ) ≤ (1 + α / 16) * m ∧
    (child.card : ℝ) ≤ (1 - (15 / 17 : ℝ) * α) * (S.card : ℝ) := by
  dsimp only
  rcases hasNodeAge_to_ops hage with ⟨hS_card_nat, ops, hops_filt, rfl⟩
  set S_cur := ops.foldl (fun acc op =>
    match op with
    | Sum.inl j => insert j acc
    | Sum.inr j => acc.erase j) P₀
  set V := liftVariance o s
  set C := nodeCore pts o V S_cur
  set child := nodeResidual pts o V S_cur
  set m : ℝ := (P₀.card : ℝ)
  unfold S_lem_5_1 at h_lem_5_1
  unfold IsCenterpoint at hcp
  rw [Fintype.card_coe] at hcp
  have h51 := (h_lem_5_1 d ι pts P₀ hm α hα o s hcp).2.2 age ops hops_filt
  dsimp only at h51
  have hsurv : α * m - (age : ℝ) ≤
      (pointCount (fun i : ↥(P₀ ∩ S_cur) => pts i.1) (coreBall o V) : ℝ) := h51.1
  have hcnt_eq : pointCount (fun i : ↥(P₀ ∩ S_cur) => pts i.1) (coreBall o V) = (P₀ ∩ C).card := by
    rw [pointCount_subtype_eq_card_filter_5_1]
    apply congrArg Finset.card
    ext x
    simp only [C, nodeCore, Finset.mem_filter, Finset.mem_inter]
    tauto
  have hcore_lb : 15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) := by
    rw [hcnt_eq] at hsurv
    linarith
  have hS_ub : (S_cur.card : ℝ) ≤ (1 + α / 16) * m := by
    have hS_real : (S_cur.card : ℝ) ≤ (P₀.card : ℝ) + (age : ℝ) := by exact_mod_cast hS_card_nat
    dsimp only [m]
    linarith
  have hchild_add : child.card + C.card = S_cur.card :=
    card_nodeResidual_add_nodeCore pts o V S_cur
  have hchild_real : (child.card : ℝ) = (S_cur.card : ℝ) - (C.card : ℝ) := by
    have hcast : (child.card : ℝ) + (C.card : ℝ) = (S_cur.card : ℝ) := by exact_mod_cast hchild_add
    linarith
  have hinter_le_C : ((P₀ ∩ C).card : ℝ) ≤ (C.card : ℝ) := by
    exact_mod_cast Finset.card_le_card Finset.inter_subset_right
  have hm_nonneg : 0 ≤ m := Nat.cast_nonneg _
  have hchild_ub : (child.card : ℝ) ≤ (1 - (15 / 17 : ℝ) * α) * (S_cur.card : ℝ) := by
    rw [hchild_real]
    nlinarith
  exact ⟨hcore_lb, hS_ub, hchild_ub⟩

private theorem build_chain_aux
    (h_lem_5_1 : S_lem_5_1)
    {d : ℕ} {ι : Type} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {α : ℝ} (hα : 0 < α) (hα1 : α ≤ 1)
    (L_leaf : ℕ) :
    ∀ (bound : ℕ) (P : Finset ι), P.card ≤ bound →
      (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
        ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
      ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
        (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
        (∀ i : Fin k,
          L_leaf < (chainInput pts nodes P i.castSucc).card ∧
          (nodes i).o = o i ∧
          (nodes i).V = liftVariance (o i) (s i) ∧
          IsCenterpoint α
            (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
            (liftedPoint (o i) (s i))) ∧
        (chainTerminal pts nodes P).card ≤ L_leaf ∧
        (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2 := by
  intro bound
  induction bound with
  | zero =>
    intro P hP0 _
    have hP_le : P.card ≤ L_leaf := by omega
    refine ⟨0, Fin.elim0, Fin.elim0, Fin.elim0, fun i => Fin.elim0 i, ?_, ?_⟩
    · simpa [chainTerminal, chainInput_zero] using hP_le
    · simp only [chainTerminal, chainInput_zero, Finset.card_product, sq]
      exact Nat.mul_le_mul hP_le hP_le
  | succ b ih =>
    intro P hPb hcp
    by_cases hgt : L_leaf < P.card
    · obtain ⟨o₀, s₀, hcp₀⟩ := hcp P (Finset.Subset.refl P) hgt
      have hm : 1 ≤ P.card := by omega
      have hV₀ : 0 ≤ liftVariance o₀ s₀ :=
        liftVariance_nonneg_of_centerpoint h_lem_5_1 pts P hm hα o₀ s₀ hcp₀
      let N₀ : ChainNode d := ⟨o₀, liftVariance o₀ s₀, hV₀⟩
      let P' : Finset ι := N₀.residual pts P
      have hage0 : HasNodeAge P P 0 := ⟨fun _ => P, rfl, rfl, fun r => Fin.elim0 r⟩
      have hage0_le : ((0 : ℕ) : ℝ) ≤ α * (P.card : ℝ) / 16 := by
        push_cast
        positivity
      have hcontr := single_node_contraction h_lem_5_1 pts hα hα1 P P hm o₀ s₀ hcp₀ 0 hage0 hage0_le
      have hcore_pos_real : (0 : ℝ) < ((P ∩ nodeCore pts o₀ (liftVariance o₀ s₀) P).card : ℝ) := by
        have hm_pos : (0 : ℝ) < (P.card : ℝ) := by
          exact_mod_cast (Nat.lt_of_lt_of_le Nat.zero_lt_one hm)
        have h15 : 0 < 15 * α * (P.card : ℝ) / 16 := by positivity
        exact h15.trans_le hcontr.1
      have hcore_pos : 0 < (P ∩ nodeCore pts o₀ (liftVariance o₀ s₀) P).card := by
        exact_mod_cast hcore_pos_real
      have hC_pos : 0 < (nodeCore pts o₀ (liftVariance o₀ s₀) P).card :=
        hcore_pos.trans_le (Finset.card_le_card Finset.inter_subset_right)
      have hP'_lt : P'.card < P.card := by
        have hadd : P'.card + (nodeCore pts o₀ (liftVariance o₀ s₀) P).card = P.card :=
          card_nodeResidual_add_nodeCore pts o₀ (liftVariance o₀ s₀) P
        omega
      have hP'_le : P'.card ≤ b := by omega
      have hP'_sub : P' ⊆ P := nodeResidual_subset pts o₀ (liftVariance o₀ s₀) P
      obtain ⟨k', tailNodes, tailO, tailS, htail_nodes, htail_term, htail_prod⟩ :=
        ih P' hP'_le (fun S hSP' => hcp S (hSP'.trans hP'_sub))
      refine ⟨k' + 1, Fin.cons N₀ tailNodes, Fin.cons o₀ tailO, Fin.cons s₀ tailS, ?_, ?_, ?_⟩
      · intro i
        refine Fin.cases ?_ ?_ i
        · simp only [Fin.castSucc_zero, chainInput_zero, Fin.cons_zero]
          exact ⟨hgt, rfl, rfl, hcp₀⟩
        · intro i'
          have hcast : (i'.succ : Fin (k' + 1)).castSucc = (i'.castSucc).succ := by
            ext
            simp
          rw [hcast, chainInput_cons_succ]
          simp only [Fin.cons_succ]
          exact htail_nodes i'
      · have hterm_eq : chainTerminal pts (Fin.cons N₀ tailNodes) P =
            chainTerminal pts tailNodes P' := by
          unfold chainTerminal
          have hlast : Fin.last (k' + 1) = (Fin.last k').succ := by
            ext
            simp
          rw [hlast, chainInput_cons_succ]
        rwa [hterm_eq]
      · have hterm_eq : chainTerminal pts (Fin.cons N₀ tailNodes) P =
            chainTerminal pts tailNodes P' := by
          unfold chainTerminal
          have hlast : Fin.last (k' + 1) = (Fin.last k').succ := by
            ext
            simp
          rw [hlast, chainInput_cons_succ]
        rwa [hterm_eq]
    · have hP_le : P.card ≤ L_leaf := Nat.le_of_not_lt hgt
      refine ⟨0, Fin.elim0, Fin.elim0, Fin.elim0, fun i => Fin.elim0 i, ?_, ?_⟩
      · simpa [chainTerminal, chainInput_zero] using hP_le
      · simp only [chainTerminal, chainInput_zero, Finset.card_product, sq]
        exact Nat.mul_le_mul hP_le hP_le

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_5_1_chain_contraction (h_lem_5_1 : S_lem_5_1) : S_clm_5_1_chain_contraction := by
  unfold S_clm_5_1_chain_contraction
  let c₁ : ℝ := 15 / 17
  have hc₁_pos : 0 < c₁ := by norm_num [c₁]
  have hlog2_pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
  let C_nodes : ℝ := c₁⁻¹ + (Real.log 2)⁻¹
  have hC_pos : 0 < C_nodes := by positivity
  refine ⟨c₁, C_nodes, hc₁_pos, hC_pos, ?_⟩
  intro d ι _ pts α hα hα1
  have hpart1 : ∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
      ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
        IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
        ∀ (age : ℕ), HasNodeAge P₀ S age →
          (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
          let V := liftVariance o s
          let C := nodeCore pts o V S
          let child := nodeResidual pts o V S
          let m : ℝ := P₀.card
          15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
          (S.card : ℝ) ≤ (1 + α / 16) * m ∧
          (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ) := by
    intro P₀ S hm o s hcp age hage hage_le
    exact single_node_contraction h_lem_5_1 pts hα hα1 P₀ S hm o s hcp age hage hage_le
  have hpart2 : ∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
      ∀ (k : ℕ) (nodes : Fin k → ChainNode d)
          (P₀ : Fin k → Finset ι)
          (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
          (age : Fin k → ℕ),
        (∀ i : Fin k,
          (nodes i).o = o i ∧
          (nodes i).V = liftVariance (o i) (s i) ∧
          1 ≤ (P₀ i).card ∧
          IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
          HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
          (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
        (∀ j : Fin (k + 1),
          ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
        ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
        (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) := by
    intro n P hPn k nodes P₀ o s age hnodes
    have hfactor_nonneg : 0 ≤ 1 - c₁ * α := by
      change 0 ≤ 1 - (15 / 17 : ℝ) * α
      linarith
    have hchain_bound : ∀ (m : ℕ) (hm : m ≤ k),
        ((chainInput pts nodes P ⟨m, Nat.lt_succ_of_le hm⟩).card : ℝ) ≤
          (1 - c₁ * α) ^ m * (P.card : ℝ) := by
      intro m
      induction m with
      | zero =>
        intro _
        simp [chainInput_zero]
      | succ m ih =>
        intro hm
        have hm_lt : m < k := Nat.lt_of_succ_le hm
        have ih_m := ih (Nat.le_of_lt hm_lt)
        let idx : Fin k := ⟨m, hm_lt⟩
        rcases hnodes idx with ⟨ho, hV, hm_card, hcp, hage, hage_le⟩
        have hcontr := single_node_contraction h_lem_5_1 pts hα hα1
          (P₀ idx) (chainInput pts nodes P idx.castSucc) hm_card (o idx) (s idx) hcp (age idx) hage hage_le
        have hstep_eq : chainInput pts nodes P ⟨m + 1, Nat.lt_succ_of_le hm⟩ =
            nodeResidual pts (o idx) (liftVariance (o idx) (s idx))
              (chainInput pts nodes P idx.castSucc) := by
          have h1 := chainInput_succ pts nodes P idx
          unfold ChainNode.residual at h1
          rw [ho, hV] at h1
          exact h1
        calc ((chainInput pts nodes P ⟨m + 1, Nat.lt_succ_of_le hm⟩).card : ℝ)
            = ((nodeResidual pts (o idx) (liftVariance (o idx) (s idx))
                (chainInput pts nodes P idx.castSucc)).card : ℝ) := by rw [hstep_eq]
          _ ≤ (1 - c₁ * α) * ((chainInput pts nodes P idx.castSucc).card : ℝ) := hcontr.2.2
          _ ≤ (1 - c₁ * α) * ((1 - c₁ * α) ^ m * (P.card : ℝ)) :=
              mul_le_mul_of_nonneg_left ih_m hfactor_nonneg
          _ = (1 - c₁ * α) ^ (m + 1) * (P.card : ℝ) := by rw [pow_succ', mul_assoc]
    have hj_bound : ∀ j : Fin (k + 1),
        ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ) :=
      fun j => hchain_bound j.val (Nat.lt_succ_iff.mp j.isLt)
    have hterm_bound : ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) := by
      simpa [chainTerminal] using hj_bound (Fin.last k)
    have hk_bound : (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) := by
      rcases Nat.eq_zero_or_pos k with rfl | hk_pos
      · have hlog_nonneg : 0 ≤ Real.log ((n : ℝ) + 1) :=
          Real.log_nonneg (by linarith [Nat.cast_nonneg (α := ℝ) n])
        simp only [Nat.cast_zero]
        positivity
      · let ilast : Fin k := ⟨k - 1, Nat.sub_lt hk_pos Nat.zero_lt_one⟩
        rcases hnodes ilast with ⟨_, _, hm_last, hcp_last, hage_last, hage_le_last⟩
        have hcontr_last := single_node_contraction h_lem_5_1 pts hα hα1
          (P₀ ilast) (chainInput pts nodes P ilast.castSucc) hm_last
          (o ilast) (s ilast) hcp_last (age ilast) hage_last hage_le_last
        have hcore_pos_real : (0 : ℝ) <
            ((P₀ ilast ∩ nodeCore pts (o ilast) (liftVariance (o ilast) (s ilast))
              (chainInput pts nodes P ilast.castSucc)).card : ℝ) := by
          have hm_pos : (0 : ℝ) < ((P₀ ilast).card : ℝ) := by
            exact_mod_cast (Nat.lt_of_lt_of_le Nat.zero_lt_one hm_last)
          have h15 : 0 < 15 * α * ((P₀ ilast).card : ℝ) / 16 := by positivity
          exact h15.trans_le hcontr_last.1
        have hcore_pos : 0 <
            (P₀ ilast ∩ nodeCore pts (o ilast) (liftVariance (o ilast) (s ilast))
              (chainInput pts nodes P ilast.castSucc)).card := by
          exact_mod_cast hcore_pos_real
        have hS_last_pos : 1 ≤ (chainInput pts nodes P ilast.castSucc).card := by
          have hsub : P₀ ilast ∩ nodeCore pts (o ilast) (liftVariance (o ilast) (s ilast))
              (chainInput pts nodes P ilast.castSucc) ⊆
              chainInput pts nodes P ilast.castSucc :=
            Finset.inter_subset_right.trans
              (nodeCore_subset pts (o ilast) (liftVariance (o ilast) (s ilast)) _)
          exact Nat.succ_le_of_lt (hcore_pos.trans_le (Finset.card_le_card hsub))
        have h1_le_pow : (1 : ℝ) ≤ (1 - c₁ * α) ^ (k - 1) * (n : ℝ) := by
          have hS_real : (1 : ℝ) ≤ ((chainInput pts nodes P ilast.castSucc).card : ℝ) := by
            exact_mod_cast hS_last_pos
          have hj_last := hj_bound ilast.castSucc
          simp only [Fin.val_castSucc, ilast] at hj_last
          have hPn_real : (P.card : ℝ) ≤ (n : ℝ) := by exact_mod_cast hPn
          have hpow_nonneg : 0 ≤ (1 - c₁ * α) ^ (k - 1) := pow_nonneg hfactor_nonneg _
          exact hS_real.trans (hj_last.trans (mul_le_mul_of_nonneg_left hPn_real hpow_nonneg))
        have hn_pos : 1 ≤ n := by
          by_contra hn0
          have h0 : n = 0 := by omega
          subst h0
          simp at h1_le_pow
          linarith
        have hexp_step : 1 - c₁ * α ≤ Real.exp (-(c₁ * α)) := by
          have h := Real.add_one_le_exp (-(c₁ * α))
          linarith
        have hpow_exp : (1 - c₁ * α) ^ (k - 1) ≤ Real.exp (-((k - 1 : ℕ) * (c₁ * α))) := by
          calc (1 - c₁ * α) ^ (k - 1)
              ≤ (Real.exp (-(c₁ * α))) ^ (k - 1) :=
                pow_le_pow_left₀ hfactor_nonneg hexp_step (k - 1)
            _ = Real.exp ((k - 1 : ℕ) * (-(c₁ * α))) := (Real.exp_nat_mul _ _).symm
            _ = Real.exp (-((k - 1 : ℕ) * (c₁ * α))) := by ring_nf
        have hn_nonneg : (0 : ℝ) ≤ (n : ℝ) := Nat.cast_nonneg n
        have h1_le_exp_n : (1 : ℝ) ≤ Real.exp (-((k - 1 : ℕ) * (c₁ * α))) * (n : ℝ) :=
          h1_le_pow.trans (mul_le_mul_of_nonneg_right hpow_exp hn_nonneg)
        have hexp_le_n1 : Real.exp ((k - 1 : ℕ) * (c₁ * α)) ≤ (n : ℝ) + 1 := by
          have hexp_pos : 0 < Real.exp ((k - 1 : ℕ) * (c₁ * α)) := Real.exp_pos _
          have hmul := mul_le_mul_of_nonneg_left h1_le_exp_n hexp_pos.le
          have hcancel : Real.exp ((k - 1 : ℕ) * (c₁ * α)) *
              Real.exp (-((k - 1 : ℕ) * (c₁ * α))) = 1 := by
            rw [← Real.exp_add, add_neg_cancel, Real.exp_zero]
          have hle_n : Real.exp ((k - 1 : ℕ) * (c₁ * α)) ≤ (n : ℝ) := by
            calc Real.exp ((k - 1 : ℕ) * (c₁ * α))
                ≤ Real.exp ((k - 1 : ℕ) * (c₁ * α)) *
                    (Real.exp (-((k - 1 : ℕ) * (c₁ * α))) * (n : ℝ)) := by simpa using hmul
              _ = (Real.exp ((k - 1 : ℕ) * (c₁ * α)) *
                    Real.exp (-((k - 1 : ℕ) * (c₁ * α)))) * (n : ℝ) := by ring
              _ = (n : ℝ) := by rw [hcancel, one_mul]
          linarith
        have hkm1_mul_le : ((k - 1 : ℕ) : ℝ) * (c₁ * α) ≤ Real.log ((n : ℝ) + 1) := by
          have hlog := Real.log_le_log (Real.exp_pos _) hexp_le_n1
          rwa [Real.log_exp] at hlog
        have hkm1_le : ((k - 1 : ℕ) : ℝ) ≤ c₁⁻¹ * α⁻¹ * Real.log ((n : ℝ) + 1) := by
          have hpos_prod : 0 < c₁ * α := mul_pos hc₁_pos hα
          have hdiv := (le_div_iff₀ hpos_prod).mpr hkm1_mul_le
          calc ((k - 1 : ℕ) : ℝ) ≤ Real.log ((n : ℝ) + 1) / (c₁ * α) := hdiv
            _ = c₁⁻¹ * α⁻¹ * Real.log ((n : ℝ) + 1) := by ring
        have h1_le_log : (1 : ℝ) ≤ (Real.log 2)⁻¹ * α⁻¹ * Real.log ((n : ℝ) + 1) := by
          have hn2 : (2 : ℝ) ≤ (n : ℝ) + 1 := by
            have hn1_real : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn_pos
            linarith
          have hlog2_le : Real.log 2 ≤ Real.log ((n : ℝ) + 1) :=
            Real.log_le_log (by norm_num) hn2
          have h1_log : (1 : ℝ) ≤ (Real.log 2)⁻¹ * Real.log ((n : ℝ) + 1) := by
            rw [inv_mul_eq_div, one_le_div hlog2_pos]
            exact hlog2_le
          have h1_inv_α : (1 : ℝ) ≤ α⁻¹ := (one_le_inv₀ hα).mpr hα1
          have hnonneg_log : 0 ≤ (Real.log 2)⁻¹ * Real.log ((n : ℝ) + 1) := by positivity
          calc (1 : ℝ) ≤ 1 * ((Real.log 2)⁻¹ * Real.log ((n : ℝ) + 1)) := by linarith
            _ ≤ α⁻¹ * ((Real.log 2)⁻¹ * Real.log ((n : ℝ) + 1)) :=
                mul_le_mul_of_nonneg_right h1_inv_α hnonneg_log
            _ = (Real.log 2)⁻¹ * α⁻¹ * Real.log ((n : ℝ) + 1) := by ring
        have hk_split : (k : ℝ) = ((k - 1 : ℕ) : ℝ) + 1 := by
          have hk_eq : (k - 1) + 1 = k := Nat.sub_add_cancel hk_pos
          exact_mod_cast hk_eq.symm
        calc (k : ℝ) = ((k - 1 : ℕ) : ℝ) + 1 := hk_split
          _ ≤ c₁⁻¹ * α⁻¹ * Real.log ((n : ℝ) + 1) +
                (Real.log 2)⁻¹ * α⁻¹ * Real.log ((n : ℝ) + 1) := add_le_add hkm1_le h1_le_log
          _ = C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) := by dsimp [C_nodes]; ring
    exact ⟨hj_bound, hterm_bound, hk_bound⟩
  refine ⟨hpart1, fun n P hPn => ⟨hpart2 n P hPn, ?_⟩⟩
  intro L_leaf hcp
  obtain ⟨k, nodes, o, s, hnodes_prop, hterm_le, hprod_le⟩ :=
    build_chain_aux h_lem_5_1 pts hα hα1 L_leaf P.card P (le_refl _) hcp
  have hk_le : (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) := by
    refine (hpart2 n P hPn k nodes (fun i => chainInput pts nodes P i.castSucc)
      o s (fun _ => 0) ?_).2.2
    intro i
    rcases hnodes_prop i with ⟨hL_lt, ho_i, hV_i, hcp_i⟩
    have hm_i : 1 ≤ (chainInput pts nodes P i.castSucc).card := by omega
    have hage0 : HasNodeAge (chainInput pts nodes P i.castSucc)
        (chainInput pts nodes P i.castSucc) 0 :=
      ⟨fun _ => chainInput pts nodes P i.castSucc, rfl, rfl, fun r => Fin.elim0 r⟩
    have hage0_le : ((0 : ℕ) : ℝ) ≤
        α * ((chainInput pts nodes P i.castSucc).card : ℝ) / 16 := by
      push_cast
      positivity
    exact ⟨ho_i, hV_i, hm_i, hcp_i, hage0, hage0_le⟩
  exact ⟨k, nodes, o, s, hk_le, hnodes_prop, hterm_le, hprod_le⟩

end UL
