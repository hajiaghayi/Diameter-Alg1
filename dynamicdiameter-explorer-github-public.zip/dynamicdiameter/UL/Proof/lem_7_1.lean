import UL.Stmt.lem_7_1
import UL.Stmt.lem_C_3
import UL.Proof.lem_7_1.RaceV31_H3_MC
import UL.Proof.lem_7_1.RaceCG_H4_Cert
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_7_1 (h_lem_C_3 : S_lem_C_3) : S_lem_7_1 := by
  let _ := h_lem_C_3
  unfold S_lem_7_1
  refine ⟨1000, 2, by norm_num, ?_⟩
  intro d d_s n ι instDec pts h h_pos h_lt_one σ θ hσθ facs hfacs P_life hPlife maxOps hmaxOps
  letI : DecidableEq ι := instDec
  refine ⟨?_, ?_⟩
  · intro δ_fail hδ0 hδ1 MCBirthState MCIndexState mkMC hMC
    exact UL.Proof_lem_7_1_RaceV31.part1_mc_wrapper
      (C_wrap := 1000) (deg_log := 2) (by norm_num) (by omega)
      d d_s n ι pts h h_pos h_lt_one σ θ hσθ facs hfacs P_life hPlife maxOps hmaxOps
      δ_fail hδ0 hδ1 MCBirthState MCIndexState mkMC hMC
  · intro δ_margin netLogBound hδ0 hnet0 N hN_net CertBirthState CertPhaseState mkCert hCert
    exact UL.Proof_lem_7_1_RaceV31.part2_cert_wrapper
      (C_wrap := 1000) (deg_log := 2) (by norm_num) (by omega)
      d d_s n ι pts h h_pos h_lt_one σ θ hσθ facs hfacs P_life hPlife maxOps hmaxOps
      δ_margin netLogBound hδ0 hnet0 N hN_net CertBirthState CertPhaseState mkCert hCert

end UL
