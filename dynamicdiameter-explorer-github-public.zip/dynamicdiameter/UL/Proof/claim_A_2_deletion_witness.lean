import UL.Stmt.claim_A_2_deletion_witness
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_block_witness
import UL.Stmt.lem_A_2
set_option autoImplicit false

namespace UL

namespace Proof_claim_A_2_deletion_witness

private lemma liftedPoint_apply_castSucc {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (k : Fin d) :
    (liftedPoint o s) k.castSucc = o k := by
  simp [liftedPoint]

private lemma liftedPoint_apply_last {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) :
    (liftedPoint o s) (Fin.last d) = s := by
  simp [liftedPoint]

private lemma euclidean_sum_smul_apply {n : ℕ} {ι : Type*} [DecidableEq ι]
    (B : Finset ι) (c : ι → ℝ) (f : ι → EuclideanSpace ℝ (Fin n)) (k : Fin n) :
    (∑ p ∈ B, c p • f p) k = ∑ p ∈ B, c p * f p k := by
  induction B using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
    simp [Finset.sum_insert ha, ih]

private lemma sum_inner_left {d : ℕ} {ι : Type*} [DecidableEq ι]
    (B : Finset ι) (f : ι → EuclideanSpace ℝ (Fin d)) (q : EuclideanSpace ℝ (Fin d)) :
    ∑ p ∈ B, inner ℝ (f p) q = inner ℝ (∑ p ∈ B, f p) q := by
  induction B using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
    rw [Finset.sum_insert ha, Finset.sum_insert ha, inner_add_left, ih]

private lemma sum_inner_right {n : ℕ} {ι : Type*} [DecidableEq ι]
    (B : Finset ι) (c : ι → ℝ) (f : ι → EuclideanSpace ℝ (Fin n))
    (v : EuclideanSpace ℝ (Fin n)) :
    ∑ p ∈ B, c p * inner ℝ v (f p) = inner ℝ v (∑ p ∈ B, c p • f p) := by
  induction B using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
    rw [Finset.sum_insert ha, Finset.sum_insert ha, inner_add_right, inner_smul_right, ih]

private lemma exists_pos_coeff {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {z : EuclideanSpace ℝ (Fin (d + 1))}
    (cert : BlockCertificate pts P₀ z) :
    ∃ p₀ ∈ cert.B, 0 < cert.coeff p₀ := by
  by_contra! hle
  have hsum : ∑ p ∈ cert.B, cert.coeff p ≤ 0 := Finset.sum_nonpos hle
  linarith [cert.sum_coeff]

private lemma cert_meets_closedHalfspace {d : ℕ} {ι : Type*} [DecidableEq ι]
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {z : EuclideanSpace ℝ (Fin (d + 1))}
    (cert : BlockCertificate pts P₀ z)
    {H : Set (EuclideanSpace ℝ (Fin (d + 1)))}
    (hH : IsClosedHalfspace H) (hz : z ∈ H) :
    ∃ p ∈ cert.B, paraboloidLift (pts p) ∈ H := by
  rcases hH with ⟨v, _, γ, rfl⟩
  simp only [Set.mem_setOf_eq] at hz ⊢
  by_contra! hgt
  obtain ⟨p₀, hp₀B, hp₀pos⟩ := exists_pos_coeff cert
  have hlt : ∑ p ∈ cert.B, cert.coeff p * γ <
      ∑ p ∈ cert.B, cert.coeff p * inner ℝ v (paraboloidLift (pts p)) := by
    refine Finset.sum_lt_sum (fun p hp => ?_) ⟨p₀, hp₀B, ?_⟩
    · exact mul_le_mul_of_nonneg_left (hgt p hp).le (cert.coeff_nonneg p hp)
    · exact mul_lt_mul_of_pos_left (hgt p₀ hp₀B) hp₀pos
  rw [← Finset.sum_mul, cert.sum_coeff, one_mul, sum_inner_right, cert.sum_lift] at hlt
  linarith

private lemma cert_sum_pts {d : ℕ} {ι : Type*} [DecidableEq ι]
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (cert : BlockCertificate pts P₀ (liftedPoint o s)) :
    ∑ p ∈ cert.B, cert.coeff p • pts p = o := by
  ext k
  rw [euclidean_sum_smul_apply]
  have hk : (∑ p ∈ cert.B, cert.coeff p • paraboloidLift (pts p)) k.castSucc =
      (liftedPoint o s) k.castSucc := by
    rw [cert.sum_lift]
  rw [euclidean_sum_smul_apply, liftedPoint_apply_castSucc] at hk
  simpa [paraboloidLift, liftedPoint_apply_castSucc] using hk

private lemma cert_sum_sq {d : ℕ} {ι : Type*} [DecidableEq ι]
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (cert : BlockCertificate pts P₀ (liftedPoint o s)) :
    ∑ p ∈ cert.B, cert.coeff p * ‖pts p‖ ^ 2 = s := by
  have hlast : (∑ p ∈ cert.B, cert.coeff p • paraboloidLift (pts p)) (Fin.last d) =
      (liftedPoint o s) (Fin.last d) := by
    rw [cert.sum_lift]
  rw [euclidean_sum_smul_apply, liftedPoint_apply_last] at hlast
  simpa [paraboloidLift, liftedPoint_apply_last] using hlast

private lemma cert_variance_identity {d : ℕ} {ι : Type*} [DecidableEq ι]
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (cert : BlockCertificate pts P₀ (liftedPoint o s))
    (q : EuclideanSpace ℝ (Fin d)) :
    ∑ p ∈ cert.B, cert.coeff p * ‖pts p - q‖ ^ 2 = ‖q - o‖ ^ 2 + liftVariance o s := by
  have hexpand : ∀ p : ι,
      cert.coeff p * ‖pts p - q‖ ^ 2 =
        cert.coeff p * ‖pts p‖ ^ 2 - 2 * inner ℝ (cert.coeff p • pts p) q +
          cert.coeff p * ‖q‖ ^ 2 := by
    intro p
    rw [norm_sub_sq_real, inner_smul_left, RCLike.conj_to_real]
    ring
  calc
    ∑ p ∈ cert.B, cert.coeff p * ‖pts p - q‖ ^ 2
        = ∑ p ∈ cert.B, (cert.coeff p * ‖pts p‖ ^ 2 -
            2 * inner ℝ (cert.coeff p • pts p) q + cert.coeff p * ‖q‖ ^ 2) := by
          refine Finset.sum_congr rfl (fun p _ => hexpand p)
    _ = (∑ p ∈ cert.B, cert.coeff p * ‖pts p‖ ^ 2) -
          2 * (∑ p ∈ cert.B, inner ℝ (cert.coeff p • pts p) q) +
          (∑ p ∈ cert.B, cert.coeff p) * ‖q‖ ^ 2 := by
          rw [Finset.sum_add_distrib, Finset.sum_sub_distrib,
            ← Finset.mul_sum, ← Finset.sum_mul]
    _ = s - 2 * inner ℝ o q + 1 * ‖q‖ ^ 2 := by
          rw [cert_sum_sq cert, sum_inner_left, cert_sum_pts cert, cert.sum_coeff]
    _ = ‖q - o‖ ^ 2 + liftVariance o s := by
          unfold liftVariance
          rw [norm_sub_sq_real, real_inner_comm]
          ring

private lemma exists_le_of_convex_sum {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {z : EuclideanSpace ℝ (Fin (d + 1))}
    (cert : BlockCertificate pts P₀ z)
    (g : ι → ℝ) (c : ℝ) (hsum : ∑ p ∈ cert.B, cert.coeff p * g p = c) :
    ∃ p ∈ cert.B, g p ≤ c := by
  by_contra! hgt
  obtain ⟨p₀, hp₀B, hp₀pos⟩ := exists_pos_coeff cert
  have hlt : ∑ p ∈ cert.B, cert.coeff p * c < ∑ p ∈ cert.B, cert.coeff p * g p := by
    refine Finset.sum_lt_sum (fun p hp => ?_) ⟨p₀, hp₀B, ?_⟩
    · exact mul_le_mul_of_nonneg_left (hgt p hp).le (cert.coeff_nonneg p hp)
    · exact mul_lt_mul_of_pos_left (hgt p₀ hp₀B) hp₀pos
  rw [← Finset.sum_mul, cert.sum_coeff, one_mul, hsum] at hlt
  linarith

private lemma exists_ge_of_convex_sum {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ι}
    {z : EuclideanSpace ℝ (Fin (d + 1))}
    (cert : BlockCertificate pts P₀ z)
    (g : ι → ℝ) (c : ℝ) (hsum : ∑ p ∈ cert.B, cert.coeff p * g p = c) :
    ∃ p ∈ cert.B, c ≤ g p := by
  by_contra! hlt_all
  obtain ⟨p₀, hp₀B, hp₀pos⟩ := exists_pos_coeff cert
  have hlt : ∑ p ∈ cert.B, cert.coeff p * g p < ∑ p ∈ cert.B, cert.coeff p * c := by
    refine Finset.sum_lt_sum (fun p hp => ?_) ⟨p₀, hp₀B, ?_⟩
    · exact mul_le_mul_of_nonneg_left (hlt_all p hp).le (cert.coeff_nonneg p hp)
    · exact mul_lt_mul_of_pos_left (hlt_all p₀ hp₀B) hp₀pos
  rw [← Finset.sum_mul, cert.sum_coeff, one_mul, hsum] at hlt
  linarith

open Classical in
private lemma card_sdiff_le_one_of_isInputChange {ι : Type*}
    {S S' : Finset ι} (h : IsInputChange S S') :
    (S \ S').card ≤ 1 := by
  rcases h with ⟨j, _, hS'⟩ | ⟨j, _, hS'⟩
  · have hsub : S \ S' = ∅ := by
      ext x
      simp only [Finset.mem_sdiff, Finset.notMem_empty, iff_false, not_and, not_not]
      intro hxS
      rw [hS']
      exact Finset.mem_insert_of_mem hxS
    rw [hsub]
    simp
  · have hsub : S \ S' ⊆ {j} := by
      intro x hx
      rw [Finset.mem_sdiff] at hx
      rw [Finset.mem_singleton]
      by_contra hxj
      apply hx.2
      rw [hS']
      exact Finset.mem_erase.mpr ⟨hxj, hx.1⟩
    exact (Finset.card_le_card hsub).trans (by simp)

private lemma fin_mono_prop {T : ℕ} (Q : Fin (T + 1) → Prop)
    (hstep : ∀ r : Fin T, Q r.castSucc → Q r.succ)
    {t₁ t₂ : Fin (T + 1)} (hle : t₁ ≤ t₂) (ht₁ : Q t₁) : Q t₂ := by
  have haux : ∀ (m a : ℕ) (ha : a < T + 1) (hb : a + m < T + 1),
      Q ⟨a, ha⟩ → Q ⟨a + m, hb⟩ := by
    intro m
    induction m with
    | zero =>
      intro a ha hb hQ
      simpa using hQ
    | succ m ih =>
      intro a ha hb hQ
      have had_lt : a + m < T := by omega
      exact hstep ⟨a + m, had_lt⟩ (ih a ha (by omega) hQ)
  rcases t₁ with ⟨a, ha⟩
  rcases t₂ with ⟨b, hb⟩
  have hab : a ≤ b := Fin.le_def.mp hle
  obtain ⟨m, rfl⟩ := Nat.exists_eq_add_of_le hab
  exact haux m a ha hb ht₁

private lemma applyDynamicUpdate_props {d : ℕ}
    {P P' : DynamicPointSet d} {op : DynamicUpdate d} {hdl : Option ℕ}
    (h : applyDynamicUpdate P op hdl = some P') :
    P.nextLifetime ≤ P'.nextLifetime ∧
    ((∀ x ∈ P.activeIds, P.lifetimeOfId x < P.nextLifetime) →
      (∀ x ∈ P'.activeIds, P'.lifetimeOfId x < P'.nextLifetime)) ∧
    (∀ ℓ : ℕ, ℓ < P.nextLifetime →
      ℓ ∉ P.activeIds.image P.lifetimeOfId →
      ℓ ∉ P'.activeIds.image P'.lifetimeOfId) ∧
    (∀ id extName pt, op = DynamicUpdate.insert id extName pt →
      P'.lifetimeOfId id = P.nextLifetime) := by
  unfold applyDynamicUpdate at h
  cases op with
  | insert id₀ extName₀ pt₀ =>
    cases hdl with
    | none => simp at h
    | some h₀ =>
      dsimp only at h
      split_ifs at h with hcond
      injection h with hP'
      subst hP'
      dsimp only
      refine ⟨by omega, ?_, ?_, ?_⟩
      · intro hinv x hx
        rcases Finset.mem_insert.mp hx with rfl | hxP
        · simp
        · have hne : x ≠ id₀ := fun h_eq => hcond.1 (h_eq ▸ hxP)
          simp only [Function.update_of_ne hne]
          exact Nat.lt_succ_of_lt (hinv x hxP)
      · intro ℓ hℓ_lt hℓ_abs hℓ_mem
        rcases Finset.mem_image.mp hℓ_mem with ⟨x, hx_mem, hx_eq⟩
        rcases Finset.mem_insert.mp hx_mem with rfl | hxP
        · simp only [Function.update_self] at hx_eq
          omega
        · have hne : x ≠ id₀ := fun h_eq => hcond.1 (h_eq ▸ hxP)
          simp only [Function.update_of_ne hne] at hx_eq
          exact hℓ_abs (Finset.mem_image.mpr ⟨x, hxP, hx_eq⟩)
      · intro id _ _ hop
        injection hop with hid _ _
        subst hid
        simp
  | delete id₀ =>
    cases hdl with
    | some h₀ => simp at h
    | none =>
      dsimp only at h
      split_ifs at h with hcond
      injection h with hP'
      subst hP'
      dsimp only
      refine ⟨le_rfl, ?_, ?_, ?_⟩
      · intro hinv x hx
        rcases Finset.mem_erase.mp hx with ⟨hne, hxP⟩
        simp only [Function.update_of_ne hne]
        exact hinv x hxP
      · intro ℓ _ hℓ_abs hℓ_mem
        rcases Finset.mem_image.mp hℓ_mem with ⟨x, hx_mem, hx_eq⟩
        rcases Finset.mem_erase.mp hx_mem with ⟨hne, hxP⟩
        simp only [Function.update_of_ne hne] at hx_eq
        exact hℓ_abs (Finset.mem_image.mpr ⟨x, hxP, hx_eq⟩)
      · intro _ _ _ hop
        nomatch hop

end Proof_claim_A_2_deletion_witness

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_claim_A_2_deletion_witness (h_lem_5_1 : S_lem_5_1) (h_clm_5_1_block_witness : S_clm_5_1_block_witness) (h_lem_A_2 : S_lem_A_2) : S_claim_A_2_deletion_witness := by
  have _ : S_lem_5_1 ∧ S_clm_5_1_block_witness ∧ S_lem_A_2 := ⟨h_lem_5_1, h_clm_5_1_block_witness, h_lem_A_2⟩
  unfold S_claim_A_2_deletion_witness
  intro d _hd s₀ hs₀ ι pts P₀ hm _hrat o s k hk certs _hcard hdisj
  classical
  dsimp only
  let z : EuclideanSpace ℝ (Fin (d + 1)) := liftedPoint o s
  let m : ℝ := P₀.card
  let β : ℝ := 1 / (4 * (s₀ : ℝ))
  let V : ℝ := liftVariance o s
  have hs₀_pos : (0 : ℝ) < (s₀ : ℝ) := by exact_mod_cast (show 0 < s₀ by omega)
  have hm_ge : 2 * (s₀ : ℝ) ≤ m := by dsimp [m]; exact_mod_cast hm
  have hβm_eq : β * m = m / (4 * (s₀ : ℝ)) := by
    dsimp [β, m]
    ring
  have hβm_le_k : β * m ≤ (k : ℝ) := by
    rw [hβm_eq]
    exact hk
  have hk_pos_real : (0 : ℝ) < (k : ℝ) := by
    have hpos : (0 : ℝ) < m / (4 * (s₀ : ℝ)) := by
      apply div_pos <;> linarith
    linarith
  have hk_pos : 0 < k := by exact_mod_cast hk_pos_real
  have h_halfspace_meets :
      ∀ H : Set (EuclideanSpace ℝ (Fin (d + 1))),
        IsClosedHalfspace H → z ∈ H →
        ∀ i : Fin k, ∃ p ∈ (certs i).B, paraboloidLift (pts p) ∈ H := by
    intro H hH hz i
    exact Proof_claim_A_2_deletion_witness.cert_meets_closedHalfspace (certs i) hH hz
  have h_var_id :
      ∀ (i : Fin k) (q : EuclideanSpace ℝ (Fin d)),
        ∑ p ∈ (certs i).B, (certs i).coeff p * ‖pts p - q‖ ^ 2 = ‖q - o‖ ^ 2 + V := by
    intro i q
    exact Proof_claim_A_2_deletion_witness.cert_variance_identity (certs i) q
  have hV_nonneg : 0 ≤ V := by
    let i₀ : Fin k := ⟨0, hk_pos⟩
    have hid := h_var_id i₀ o
    rw [sub_self, norm_zero, sq, zero_mul, zero_add] at hid
    rw [← hid]
    exact Finset.sum_nonneg (fun p hp =>
      mul_nonneg ((certs i₀).coeff_nonneg p hp) (sq_nonneg _))
  refine ⟨?_, h_halfspace_meets, hV_nonneg, h_var_id, ?_, ?_, ?_, ?_, ?_⟩
  · -- Conjunct 1: halfspace depth ≥ β * m
    let Q : P₀ → EuclideanSpace ℝ (Fin (d + 1)) := paraboloidLiftSet (fun p : P₀ => pts p.1)
    have h_cnt_ge : ∀ H : Set (EuclideanSpace ℝ (Fin (d + 1))),
        IsClosedHalfspace H → z ∈ H → k ≤ pointCount Q H := by
      intro H hH hz
      have hex : ∀ i : Fin k, ∃ p : P₀, p.1 ∈ (certs i).B ∧ Q p ∈ H := by
        intro i
        obtain ⟨p, hpB, hpH⟩ := h_halfspace_meets H hH hz i
        exact ⟨⟨p, (certs i).subset_birth hpB⟩, hpB, hpH⟩
      choose f hfB hfH using hex
      have hf_inj : Function.Injective f := by
        intro i j hij
        by_contra hne
        have hp_eq : (f i).1 = (f j).1 := congrArg Subtype.val hij
        exact Finset.disjoint_left.mp (hdisj i j hne) (hfB i) (hp_eq ▸ hfB j)
      have hsub : Finset.univ.image f ⊆ Finset.univ.filter (fun p : P₀ => Q p ∈ H) := by
        intro p hp
        rcases Finset.mem_image.mp hp with ⟨i, _, rfl⟩
        exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, hfH i⟩
      calc
        k = (Finset.univ : Finset (Fin k)).card := by simp
        _ = (Finset.univ.image f).card := (Finset.card_image_of_injective _ hf_inj).symm
        _ ≤ (Finset.univ.filter (fun p : P₀ => Q p ∈ H)).card := Finset.card_le_card hsub
        _ = pointCount Q H := rfl
    let v₀ : EuclideanSpace ℝ (Fin (d + 1)) := EuclideanSpace.single 0 (1 : ℝ)
    have hv₀ : v₀ ≠ 0 := by simp [v₀]
    let H₀ : Set (EuclideanSpace ℝ (Fin (d + 1))) := {x | inner ℝ v₀ x ≤ inner ℝ v₀ z}
    let A : Set ℕ := {n : ℕ | ∃ H : Set (EuclideanSpace ℝ (Fin (d + 1))),
      IsClosedHalfspace H ∧ z ∈ H ∧ n = pointCount Q H}
    have hA_ne : A.Nonempty :=
      ⟨pointCount Q H₀, H₀, ⟨v₀, hv₀, inner ℝ v₀ z, rfl⟩, Set.mem_setOf.mpr le_rfl, rfl⟩
    rcases Nat.sInf_mem hA_ne with ⟨H₁, hH₁_closed, hzH₁, hdepth_eq⟩
    have hk_le_depth : k ≤ halfspaceDepth Q z := by
      change k ≤ sInf A
      rw [hdepth_eq]
      exact h_cnt_ge H₁ hH₁_closed hzH₁
    have hk_le_depth_real : (k : ℝ) ≤ (halfspaceDepth Q z : ℝ) := by
      exact_mod_cast hk_le_depth
    linarith
  · -- Conjunct 5: ≥ 15 * β * m / 16 intact blocks across T ≤ β * m / 16 input changes
    intro T seq hT hseq0 hchg
    let D : Finset ι := Finset.univ.biUnion (fun r : Fin T => seq r.castSucc \ seq r.succ)
    have hD_card : D.card ≤ T := by
      calc
        D.card ≤ ∑ r : Fin T, (seq r.castSucc \ seq r.succ).card := Finset.card_biUnion_le
        _ ≤ ∑ _r : Fin T, 1 := Finset.sum_le_sum (fun r _ =>
            Proof_claim_A_2_deletion_witness.card_sdiff_le_one_of_isInputChange (hchg r))
        _ = T := by simp
    have h_stay : ∀ p ∈ P₀, p ∉ D → ∀ t : Fin (T + 1), p ∈ seq t := by
      intro p hp0 hpD t
      refine Fin.induction ?_ ?_ t
      · rwa [hseq0]
      · intro r ih
        by_contra hp_not
        apply hpD
        exact Finset.mem_biUnion.mpr
          ⟨r, Finset.mem_univ r, Finset.mem_sdiff.mpr ⟨ih, hp_not⟩⟩
    let pred : Fin k → Prop := fun i => ∀ t : Fin (T + 1), (certs i).IsIntact (seq t)
    let Good : Finset (Fin k) := Finset.univ.filter pred
    let Bad : Finset (Fin k) := Finset.univ.filter (fun i => ¬ pred i)
    have h_sum_cards : Good.card + Bad.card = k := by
      have h1 := Finset.card_filter_add_card_filter_not (s := (Finset.univ : Finset (Fin k))) pred
      simpa [Good, Bad] using h1
    have h_bad_inter : ∀ i ∈ Bad, 1 ≤ ((certs i).B ∩ D).card := by
      intro i hi
      have hnot : ¬ ∀ t : Fin (T + 1), (certs i).IsIntact (seq t) :=
        (Finset.mem_filter.mp hi).2
      push_neg at hnot
      rcases hnot with ⟨t, hnot_intact⟩
      obtain ⟨p, hpB, hp_not_seq⟩ := Finset.not_subset.mp hnot_intact
      have hpD : p ∈ D := by
        by_contra hp_not_D
        exact hp_not_seq (h_stay p ((certs i).subset_birth hpB) hp_not_D t)
      exact Finset.one_le_card.mpr ⟨p, Finset.mem_inter.mpr ⟨hpB, hpD⟩⟩
    have h_bad_disj : (Bad : Set (Fin k)).PairwiseDisjoint (fun i => (certs i).B ∩ D) := by
      intro i _ j _ hne
      exact Disjoint.mono Finset.inter_subset_left Finset.inter_subset_left (hdisj i j hne)
    have hBad_le : Bad.card ≤ D.card := by
      calc
        Bad.card = ∑ _i ∈ Bad, 1 := by simp
        _ ≤ ∑ i ∈ Bad, ((certs i).B ∩ D).card := Finset.sum_le_sum h_bad_inter
        _ = (Bad.biUnion (fun i => (certs i).B ∩ D)).card :=
            (Finset.card_biUnion h_bad_disj).symm
        _ ≤ D.card :=
            Finset.card_le_card (Finset.biUnion_subset.mpr (fun _ _ => Finset.inter_subset_right))
    have hk_le_good_T : k ≤ Good.card + T := by omega
    have hk_le_real : (k : ℝ) ≤ (Good.card : ℝ) + (T : ℝ) := by exact_mod_cast hk_le_good_T
    have hGood_eq : Good = Finset.univ.filter (fun i : Fin k =>
        ∀ t : Fin (T + 1), (certs i).IsIntact (seq t)) := by
      ext i
      simp [Good, pred]
    rw [← hGood_eq]
    linarith
  · -- Conjunct 6: intact block supplies core point and variance witness
    intro S i hintact
    refine ⟨?_, ?_⟩
    · have hid := h_var_id i o
      rw [sub_self, norm_zero, sq, zero_mul, zero_add] at hid
      obtain ⟨p, hpB, hp_le⟩ :=
        Proof_claim_A_2_deletion_witness.exists_le_of_convex_sum
          (certs i) (fun p => ‖pts p - o‖ ^ 2) V hid
      refine ⟨p, hpB, ?_⟩
      unfold nodeCore coreBall
      rw [Finset.mem_filter]
      refine ⟨hintact hpB, ?_⟩
      rw [Metric.mem_closedBall, dist_eq_norm]
      calc
        ‖pts p - o‖ = Real.sqrt (‖pts p - o‖ ^ 2) := (Real.sqrt_sq (norm_nonneg _)).symm
        _ ≤ Real.sqrt V := Real.sqrt_le_sqrt hp_le
    · intro q
      have hid := h_var_id i q
      obtain ⟨p, hpB, hp_ge⟩ :=
        Proof_claim_A_2_deletion_witness.exists_ge_of_convex_sum
          (certs i) (fun p => ‖pts p - q‖ ^ 2) (‖q - o‖ ^ 2 + V) hid
      refine ⟨p, hpB, hintact hpB, ?_⟩
      unfold IsVarianceWitness
      linarith
  · -- Conjunct 7: fresh identities outside P₀ are outside every certificate block
    intro j hjP₀ i hjB
    exact hjP₀ ((certs i).subset_birth hjB)
  · -- Conjunct 8: invalidated block cannot revive under fresh-identity insertions
    intro T seq hseq0 hstep i t₁ t₂ hle hnot₁ hintact₂
    obtain ⟨p, hpB, hp_not₁⟩ := Finset.not_subset.mp hnot₁
    have hp0 : p ∈ seq 0 := hseq0 ▸ (certs i).subset_birth hpB
    have hp_not₂ : p ∉ seq t₂ := by
      refine Proof_claim_A_2_deletion_witness.fin_mono_prop
        (fun t => p ∉ seq t) ?_ hle hp_not₁
      intro r hp_abs
      rcases hstep r with ⟨j, hj_fresh, hsucc⟩ | ⟨j, _, hsucc⟩
      · rw [hsucc, Finset.mem_insert, not_or]
        refine ⟨?_, hp_abs⟩
        intro hpj
        subst hpj
        exact hj_fresh 0 (Fin.zero_le _) hp0
      · rw [hsucc, Finset.mem_erase]
        intro hmem
        exact hp_abs hmem.2
    exact hp_not₂ (hintact₂ hpB)
  · -- Conjunct 9: DynamicPointSet fresh lifetimes and irreversibility of block invalidation
    intro n T P_dyn ops handles ltOf hWF0 hlt_init hupd
    have hinv0 : ∀ x ∈ (P_dyn 0).activeIds, (P_dyn 0).lifetimeOfId x < (P_dyn 0).nextLifetime :=
      hWF0.2.2.2.1
    have hinv : ∀ t : Fin (T + 1),
        ∀ x ∈ (P_dyn t).activeIds, (P_dyn t).lifetimeOfId x < (P_dyn t).nextLifetime := by
      intro t
      refine Proof_claim_A_2_deletion_witness.fin_mono_prop
        (fun u => ∀ x ∈ (P_dyn u).activeIds, (P_dyn u).lifetimeOfId x < (P_dyn u).nextLifetime)
        (fun r hr => (Proof_claim_A_2_deletion_witness.applyDynamicUpdate_props (hupd r)).2.1 hr)
        (Fin.zero_le t) hinv0
    have hnext_mono : ∀ u v : Fin (T + 1), u ≤ v →
        (P_dyn u).nextLifetime ≤ (P_dyn v).nextLifetime := by
      intro u v huv
      refine Proof_claim_A_2_deletion_witness.fin_mono_prop
        (fun w => (P_dyn u).nextLifetime ≤ (P_dyn w).nextLifetime)
        (fun r hr => hr.trans (Proof_claim_A_2_deletion_witness.applyDynamicUpdate_props (hupd r)).1)
        huv le_rfl
    have hlt_lt0 : ∀ p ∈ P₀, ltOf p < (P_dyn 0).nextLifetime := by
      intro p hp0
      rcases Finset.mem_image.mp (hlt_init p hp0) with ⟨x, hx_mem, hx_eq⟩
      rw [← hx_eq]
      exact hinv0 x hx_mem
    refine ⟨?_, ?_⟩
    · intro r id extName pt hop
      have h_ins_lt : (P_dyn r.succ).lifetimeOfId id = (P_dyn r.castSucc).nextLifetime :=
        (Proof_claim_A_2_deletion_witness.applyDynamicUpdate_props (hupd r)).2.2.2
          id extName pt hop
      refine ⟨?_, ?_⟩
      · intro u hu hid_u
        have h1 : (P_dyn u).lifetimeOfId id < (P_dyn u).nextLifetime := hinv u id hid_u
        have h2 : (P_dyn u).nextLifetime ≤ (P_dyn r.castSucc).nextLifetime :=
          hnext_mono u r.castSucc hu
        omega
      · intro i hmem
        rcases Finset.mem_image.mp hmem with ⟨p, hpB, hp_eq⟩
        have h1 : ltOf p < (P_dyn 0).nextLifetime := hlt_lt0 p ((certs i).subset_birth hpB)
        have h2 : (P_dyn 0).nextLifetime ≤ (P_dyn r.castSucc).nextLifetime :=
          hnext_mono 0 r.castSucc (Fin.zero_le _)
        omega
    · intro i t₁ t₂ hle hnot₁ hintact₂
      obtain ⟨ℓ, hℓ_B, hℓ_not₁⟩ := Finset.not_subset.mp hnot₁
      rcases Finset.mem_image.mp hℓ_B with ⟨p, hpB, rfl⟩
      have hp_lt0 : ltOf p < (P_dyn 0).nextLifetime := hlt_lt0 p ((certs i).subset_birth hpB)
      have hℓ_not₂ : ltOf p ∉ (P_dyn t₂).activeIds.image (P_dyn t₂).lifetimeOfId := by
        refine Proof_claim_A_2_deletion_witness.fin_mono_prop
          (fun t => ltOf p ∉ (P_dyn t).activeIds.image (P_dyn t).lifetimeOfId)
          ?_ hle hℓ_not₁
        intro r h_abs
        have hp_ltr : ltOf p < (P_dyn r.castSucc).nextLifetime :=
          lt_of_lt_of_le hp_lt0 (hnext_mono 0 r.castSucc (Fin.zero_le _))
        exact (Proof_claim_A_2_deletion_witness.applyDynamicUpdate_props (hupd r)).2.2.1
          (ltOf p) hp_ltr h_abs
      exact hℓ_not₂ (hintact₂ hℓ_B)

end UL
