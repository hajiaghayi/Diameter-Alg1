import Mathlib
import UL.Proof.cit_vc71_halfspace_uc.H0
set_option autoImplicit false

namespace UL.Proof_cit_vc71_halfspace_uc

theorem exists_closedHalfspace_of_pos {D : ℕ} (hD : 1 ≤ D) :
    Nonempty {H : Set (EuclideanSpace ℝ (Fin D)) // IsClosedHalfspace H} := by
  let i₀ : Fin D := ⟨0, by omega⟩
  let v₀ : EuclideanSpace ℝ (Fin D) := EuclideanSpace.single i₀ 1
  have hv₀ : v₀ ≠ 0 := by
    intro h
    have h1 : v₀ i₀ = 1 := by simp [v₀]
    have h0 : v₀ i₀ = 0 := by simp [h]
    linarith
  exact ⟨⟨{x | inner ℝ v₀ x ≤ 0}, v₀, hv₀, 0, rfl⟩⟩

private theorem convex_of_isClosedHalfspace {D : ℕ}
    {H : Set (EuclideanSpace ℝ (Fin D))} (hH : IsClosedHalfspace H) :
    Convex ℝ H ∧ Convex ℝ Hᶜ := by
  rcases hH with ⟨v, _, β, rfl⟩
  constructor
  · intro x hx y hy a b ha hb hab
    simp only [Set.mem_setOf_eq] at hx hy ⊢
    rw [inner_add_right, real_inner_smul_right, real_inner_smul_right]
    have h1 : a * inner ℝ v x ≤ a * β := mul_le_mul_of_nonneg_left hx ha
    have h2 : b * inner ℝ v y ≤ b * β := mul_le_mul_of_nonneg_left hy hb
    calc
      a * inner ℝ v x + b * inner ℝ v y ≤ a * β + b * β := add_le_add h1 h2
      _ = (a + b) * β := (add_mul a b β).symm
      _ = β := by rw [hab, one_mul]
  · intro x hx y hy a b ha hb hab
    simp only [Set.mem_compl_iff, Set.mem_setOf_eq, not_le] at hx hy ⊢
    rw [inner_add_right, real_inner_smul_right, real_inner_smul_right]
    rcases eq_or_lt_of_le ha with rfl | ha_pos
    · have hb1 : b = 1 := by linarith
      subst hb1
      linarith
    · have h1 : a * β < a * inner ℝ v x := mul_lt_mul_of_pos_left hx ha_pos
      have h2 : b * β ≤ b * inner ℝ v y := mul_le_mul_of_nonneg_left hy.le hb
      calc
        β = (a + b) * β := by rw [hab, one_mul]
        _ = a * β + b * β := add_mul a b β
        _ < a * inner ℝ v x + b * inner ℝ v y := add_lt_add_of_lt_of_le h1 h2

theorem card_halfspaceTraceFamily_le {D : ℕ} {κ : Type*} [Fintype κ]
    (z : κ → EuclideanSpace ℝ (Fin D)) :
    (halfspaceTraceFamily z).card ≤ ∑ k ∈ Finset.Iic (D + 1), (Fintype.card κ).choose k := by
  classical
  let 𝒜 : Finset (Finset κ) := halfspaceTraceFamily z
  have hshat : ∀ J : Finset κ, 𝒜.Shatters J → J.card ≤ D + 1 := by
    intro J hs
    by_contra! hcard
    let f : J → EuclideanSpace ℝ (Fin D) := fun j => z j.1
    have hdep : ¬ AffineIndependent ℝ f := by
      intro hf
      have h1 : Fintype.card J ≤ Module.finrank ℝ (vectorSpan ℝ (Set.range f)) + 1 :=
        hf.card_le_finrank_succ
      have h2 : Module.finrank ℝ (vectorSpan ℝ (Set.range f)) ≤
          Module.finrank ℝ (EuclideanSpace ℝ (Fin D)) :=
        Submodule.finrank_le _
      have h3 : Module.finrank ℝ (EuclideanSpace ℝ (Fin D)) = D :=
        finrank_euclideanSpace_fin
      have h4 : Fintype.card J = J.card := Fintype.card_coe J
      omega
    obtain ⟨I, p, hpI, hpIc⟩ := Convex.radon_partition hdep
    let T : Finset κ :=
      (J.attach.filter (fun j : J => j ∈ I)).map ⟨Subtype.val, Subtype.val_injective⟩
    have hTJ : T ⊆ J := by
      intro x hx
      simp only [T, Finset.mem_map, Finset.mem_filter, Finset.mem_attach, true_and,
        Function.Embedding.coeFn_mk] at hx
      rcases hx with ⟨j, _, rfl⟩
      exact j.2
    have hmemT : ∀ j : J, j.1 ∈ T ↔ j ∈ I := by
      intro j
      simp only [T, Finset.mem_map, Finset.mem_filter, Finset.mem_attach, true_and,
        Function.Embedding.coeFn_mk, Subtype.coe_inj, exists_eq_right]
    obtain ⟨A, hA, hJA⟩ := hs hTJ
    simp only [𝒜, halfspaceTraceFamily, Finset.mem_filter, Finset.mem_univ, true_and] at hA
    rcases hA with ⟨H, hH, rfl⟩
    have hmemH : ∀ j : J, f j ∈ H ↔ j ∈ I := by
      intro j
      rw [← hmemT j, ← hJA]
      simp only [Finset.mem_inter, j.2, true_and, Finset.mem_filter, Finset.mem_univ, f]
    obtain ⟨hconvH, hconvHc⟩ := convex_of_isClosedHalfspace hH
    have hpH : p ∈ H := by
      apply convexHull_min _ hconvH hpI
      rintro _ ⟨j, hj, rfl⟩
      exact (hmemH j).mpr hj
    have hpHc : p ∈ Hᶜ := by
      apply convexHull_min _ hconvHc hpIc
      rintro _ ⟨j, hj, rfl⟩
      exact fun hfj => hj ((hmemH j).mp hfj)
    exact hpHc hpH
  have hvc : 𝒜.vcDim ≤ D + 1 :=
    Finset.sup_le fun J hJ => hshat J (Finset.mem_shatterer.mp hJ)
  calc
    𝒜.card ≤ 𝒜.shatterer.card := Finset.card_le_card_shatterer 𝒜
    _ ≤ ∑ k ∈ Finset.Iic 𝒜.vcDim, (Fintype.card κ).choose k :=
      Finset.card_shatterer_le_sum_vcDim
    _ ≤ ∑ k ∈ Finset.Iic (D + 1), (Fintype.card κ).choose k :=
      Finset.sum_le_sum_of_subset (Finset.Iic_subset_Iic.mpr hvc)

end UL.Proof_cit_vc71_halfspace_uc
