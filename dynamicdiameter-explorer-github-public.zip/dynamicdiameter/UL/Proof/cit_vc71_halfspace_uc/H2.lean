import Mathlib
import UL.Proof.cit_vc71_halfspace_uc.H0
set_option autoImplicit false

namespace UL.Proof_cit_vc71_halfspace_uc

open Classical in
private theorem pointCount_le_card {k : ℕ} {ι : Type*} [Fintype ι]
    (Q : ι → EuclideanSpace ℝ (Fin k)) (S : Set (EuclideanSpace ℝ (Fin k))) :
    pointCount Q S ≤ Fintype.card ι :=
  Finset.card_le_univ _

theorem popFreq_mem_Icc {D : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) (H : Set (EuclideanSpace ℝ (Fin D))) :
    0 ≤ popFreq P H ∧ popFreq P H ≤ 1 := by
  unfold popFreq
  have hpos : (0 : ℝ) < (Fintype.card ι : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  exact ⟨div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _),
    (div_le_one hpos).mpr (Nat.cast_le.mpr (pointCount_le_card P H))⟩

theorem empFreq_mem_Icc {D N : ℕ} {ι : Type*} (hN : 1 ≤ N)
    (P : ι → EuclideanSpace ℝ (Fin D)) (ω : Fin N → ι)
    (H : Set (EuclideanSpace ℝ (Fin D))) :
    0 ≤ empFreq P ω H ∧ empFreq P ω H ≤ 1 := by
  unfold empFreq
  have hpos : (0 : ℝ) < (N : ℝ) := Nat.cast_pos.mpr (by omega)
  have hle : pointCount (fun t : Fin N => P (ω t)) H ≤ N := by
    simpa [Fintype.card_fin] using pointCount_le_card (fun t : Fin N => P (ω t)) H
  exact ⟨div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _),
    (div_le_one hpos).mpr (Nat.cast_le.mpr hle)⟩

open Classical in
theorem pi_uniform_real_eq_card_div (N : ℕ) (ι : Type*)
    [Fintype ι] [Nonempty ι] [MeasurableSpace ι] [DiscreteMeasurableSpace ι]
    (E : Set (Fin N → ι)) :
    (MeasureTheory.Measure.pi
      (fun _ : Fin N => (PMF.uniformOfFintype ι).toMeasure)).real E =
      ((Finset.univ.filter (fun ω : Fin N → ι => ω ∈ E)).card : ℝ) /
        (Fintype.card (Fin N → ι) : ℝ) := by
  let ν : MeasureTheory.Measure ι := (PMF.uniformOfFintype ι).toMeasure
  let μ : MeasureTheory.Measure (Fin N → ι) := MeasureTheory.Measure.pi (fun _ : Fin N => ν)
  let s : Finset (Fin N → ι) := Finset.univ.filter (fun ω : Fin N → ι => ω ∈ E)
  have hsE : (s : Set (Fin N → ι)) = E := by
    ext ω
    simp [s]
  have hsing : ∀ ω : Fin N → ι, μ.real {ω} = ((Fintype.card (Fin N → ι) : ℝ))⁻¹ := by
    intro ω
    have hν : ∀ t : Fin N, ν {ω t} = (Fintype.card ι : ENNReal)⁻¹ := by
      intro t
      rw [PMF.toMeasure_apply_singleton _ (ω t) (measurableSet_singleton _),
        PMF.uniformOfFintype_apply]
    have hμ : μ {ω} = (Fintype.card (Fin N → ι) : ENNReal)⁻¹ := by
      rw [MeasureTheory.Measure.pi_singleton]
      simp_rw [hν]
      rw [Finset.prod_const, Finset.card_univ, Fintype.card_fin, ← ENNReal.inv_pow,
        ← Nat.cast_pow, Fintype.card_fun, Fintype.card_fin]
    rw [MeasureTheory.measureReal_def, hμ, ENNReal.toReal_inv, ENNReal.toReal_natCast]
  change μ.real E = (s.card : ℝ) / (Fintype.card (Fin N → ι) : ℝ)
  rw [← hsE, ← MeasureTheory.sum_measureReal_singleton (μ := μ) s]
  simp_rw [hsing]
  rw [Finset.sum_const, nsmul_eq_mul, div_eq_mul_inv]

private theorem sum_sq_le_mul_card {ι : Type*} [Fintype ι]
    (a : ι → ℝ) (ha0 : ∑ i : ι, a i = 0) (hab : ∀ i : ι, |a i| ≤ 1) (N : ℕ) :
    ∑ ω : Fin N → ι, (∑ t : Fin N, a (ω t)) ^ 2 ≤
      (N : ℝ) * (Fintype.card (Fin N → ι) : ℝ) := by
  have hoff : ∀ s r : Fin N, s ≠ r → ∑ ω : Fin N → ι, a (ω s) * a (ω r) = 0 := by
    intro s r hsr
    let g : Fin N → ι → ℝ := fun u i => if u = s then a i else if u = r then a i else 1
    calc
      ∑ ω : Fin N → ι, a (ω s) * a (ω r)
          = ∑ ω ∈ Fintype.piFinset (fun _ : Fin N => (Finset.univ : Finset ι)),
              ∏ u : Fin N, g u (ω u) := by
        rw [Fintype.piFinset_univ]
        refine Finset.sum_congr rfl fun ω _ => ?_
        rw [Fintype.prod_eq_mul s r hsr (fun u hu => by simp [g, hu.1, hu.2])]
        simp [g, hsr.symm]
      _ = ∏ u : Fin N, ∑ i : ι, g u i :=
        Finset.sum_prod_piFinset (Finset.univ : Finset ι) g
      _ = 0 := by
        refine Finset.prod_eq_zero (Finset.mem_univ s) ?_
        simpa [g] using ha0
  have hrow : ∀ s : Fin N,
      ∑ r : Fin N, ∑ ω : Fin N → ι, a (ω s) * a (ω r) =
        ∑ ω : Fin N → ι, a (ω s) * a (ω s) := by
    intro s
    exact Fintype.sum_eq_single s fun r hrs => hoff s r hrs.symm
  have hdiag : ∀ s : Fin N,
      ∑ ω : Fin N → ι, a (ω s) * a (ω s) ≤ (Fintype.card (Fin N → ι) : ℝ) := by
    intro s
    calc
      ∑ ω : Fin N → ι, a (ω s) * a (ω s) ≤ ∑ _ω : Fin N → ι, (1 : ℝ) := by
        refine Finset.sum_le_sum fun ω _ => ?_
        obtain ⟨hl, hu⟩ := abs_le.mp (hab (ω s))
        nlinarith
      _ = (Fintype.card (Fin N → ι) : ℝ) := by simp
  have hexpand :
      ∑ ω : Fin N → ι, (∑ t : Fin N, a (ω t)) ^ 2 =
        ∑ s : Fin N, ∑ r : Fin N, ∑ ω : Fin N → ι, a (ω s) * a (ω r) := by
    simp_rw [sq, Fintype.sum_mul_sum]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun s _ => ?_
    rw [Finset.sum_comm]
  calc
    ∑ ω : Fin N → ι, (∑ t : Fin N, a (ω t)) ^ 2
        = ∑ s : Fin N, ∑ r : Fin N, ∑ ω : Fin N → ι, a (ω s) * a (ω r) := hexpand
    _ ≤ ∑ _s : Fin N, (Fintype.card (Fin N → ι) : ℝ) := by
      refine Finset.sum_le_sum fun s _ => ?_
      rw [hrow s]
      exact hdiag s
    _ = (N : ℝ) * (Fintype.card (Fin N → ι) : ℝ) := by
      rw [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]

open Classical in
private theorem sum_empFreq_sub_popFreq_sq_le {D N : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) (H : Set (EuclideanSpace ℝ (Fin D))) (hN : 1 ≤ N) :
    ∑ ω' : Fin N → ι, (empFreq P ω' H - popFreq P H) ^ 2 ≤
      (Fintype.card (Fin N → ι) : ℝ) / (N : ℝ) := by
  let a : ι → ℝ := fun i => (if P i ∈ H then (1 : ℝ) else 0) - popFreq P H
  have hcard_pos : (0 : ℝ) < (Fintype.card ι : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have hN_pos : (0 : ℝ) < (N : ℝ) := Nat.cast_pos.mpr (by omega)
  have ha0 : ∑ i : ι, a i = 0 := by
    simp only [a, Finset.sum_sub_distrib, Finset.sum_boole, Finset.sum_const, Finset.card_univ,
      nsmul_eq_mul]
    unfold popFreq pointCount
    rw [mul_div_cancel₀ _ (ne_of_gt hcard_pos), sub_self]
  have hab : ∀ i : ι, |a i| ≤ 1 := by
    intro i
    obtain ⟨h0, h1⟩ := popFreq_mem_Icc P H
    dsimp [a]
    split_ifs <;> exact abs_le.mpr ⟨by linarith, by linarith⟩
  have hdiff : ∀ ω' : Fin N → ι,
      empFreq P ω' H - popFreq P H = (∑ t : Fin N, a (ω' t)) / (N : ℝ) := by
    intro ω'
    simp only [a, Finset.sum_sub_distrib, Finset.sum_boole, Finset.sum_const, Finset.card_univ,
      Fintype.card_fin, nsmul_eq_mul]
    unfold empFreq pointCount
    rw [sub_div, mul_div_cancel_left₀ _ (ne_of_gt hN_pos)]
  simp_rw [hdiff, div_pow]
  rw [← Finset.sum_div]
  calc
    (∑ ω' : Fin N → ι, (∑ t : Fin N, a (ω' t)) ^ 2) / (N : ℝ) ^ 2
        ≤ ((N : ℝ) * (Fintype.card (Fin N → ι) : ℝ)) / (N : ℝ) ^ 2 := by
      exact div_le_div_of_nonneg_right (sum_sq_le_mul_card a ha0 hab N) (sq_nonneg _)
    _ = (Fintype.card (Fin N → ι) : ℝ) / (N : ℝ) := by
      have hN0 : (N : ℝ) ≠ 0 := ne_of_gt hN_pos
      rw [sq, mul_comm (N : ℝ), mul_div_mul_right _ _ hN0]

open Classical in
private theorem card_le_two_mul_goodGhost {D N : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) (H : Set (EuclideanSpace ℝ (Fin D)))
    {ε : ℝ} (hN : 1 ≤ N) (hε : 0 < ε) (hNε : 8 ≤ (N : ℝ) * ε ^ 2) :
    (Fintype.card (Fin N → ι) : ℝ) ≤
      2 * ((Finset.univ.filter
        (fun ω' : Fin N → ι => |empFreq P ω' H - popFreq P H| ≤ ε / 2)).card : ℝ) := by
  let good : Finset (Fin N → ι) :=
    Finset.univ.filter (fun ω' : Fin N → ι => |empFreq P ω' H - popFreq P H| ≤ ε / 2)
  let bad : Finset (Fin N → ι) :=
    Finset.univ.filter (fun ω' : Fin N → ι => ¬ |empFreq P ω' H - popFreq P H| ≤ ε / 2)
  have hpart : (good.card : ℝ) + (bad.card : ℝ) = (Fintype.card (Fin N → ι) : ℝ) := by
    have hnat : good.card + bad.card = Fintype.card (Fin N → ι) := by
      simpa [good, bad, Finset.card_univ] using
        (Finset.card_filter_add_card_filter_not
          (s := (Finset.univ : Finset (Fin N → ι)))
          (p := fun ω' : Fin N → ι => |empFreq P ω' H - popFreq P H| ≤ ε / 2))
    exact_mod_cast hnat
  have hbad_sq : (bad.card : ℝ) * (ε / 2) ^ 2 ≤ (Fintype.card (Fin N → ι) : ℝ) / (N : ℝ) := by
    calc
      (bad.card : ℝ) * (ε / 2) ^ 2 = ∑ _ω' ∈ bad, (ε / 2) ^ 2 := by
        rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ ∑ ω' ∈ bad, (empFreq P ω' H - popFreq P H) ^ 2 := by
        refine Finset.sum_le_sum fun ω' hω' => ?_
        have hlt : ε / 2 < |empFreq P ω' H - popFreq P H| :=
          lt_of_not_ge (Finset.mem_filter.mp hω').2
        have hle : |ε / 2| ≤ |empFreq P ω' H - popFreq P H| := by
          rw [abs_of_pos (half_pos hε)]
          exact le_of_lt hlt
        simpa [sq_abs] using sq_le_sq.mpr hle
      _ ≤ ∑ ω' : Fin N → ι, (empFreq P ω' H - popFreq P H) ^ 2 :=
        Finset.sum_le_univ_sum_of_nonneg fun _ => sq_nonneg _
      _ ≤ (Fintype.card (Fin N → ι) : ℝ) / (N : ℝ) :=
        sum_empFreq_sub_popFreq_sq_le P H hN
  have hN_pos : (0 : ℝ) < (N : ℝ) := Nat.cast_pos.mpr (by omega)
  have hbad_mul : (bad.card : ℝ) * ((N : ℝ) * (ε / 2) ^ 2) ≤ (Fintype.card (Fin N → ι) : ℝ) := by
    have h1 := mul_le_mul_of_nonneg_right hbad_sq (le_of_lt hN_pos)
    rw [div_mul_cancel₀ _ (ne_of_gt hN_pos)] at h1
    linarith
  have htwo_le : (2 : ℝ) ≤ (N : ℝ) * (ε / 2) ^ 2 := by
    nlinarith
  have hbad_two : 2 * (bad.card : ℝ) ≤ (Fintype.card (Fin N → ι) : ℝ) := by
    have hnonneg : (0 : ℝ) ≤ (bad.card : ℝ) := Nat.cast_nonneg _
    have h2 : (bad.card : ℝ) * 2 ≤ (bad.card : ℝ) * ((N : ℝ) * (ε / 2) ^ 2) :=
      mul_le_mul_of_nonneg_left htwo_le hnonneg
    linarith
  change (Fintype.card (Fin N → ι) : ℝ) ≤ 2 * (good.card : ℝ)
  linarith

theorem symmetrization_card_le {D N : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) {ε : ℝ}
    (hN : 1 ≤ N) (hε : 0 < ε) (hNε : 8 ≤ (N : ℝ) * ε ^ 2) :
    ((badSampleFinset P ε : Finset (Fin N → ι)).card : ℝ) /
        (Fintype.card (Fin N → ι) : ℝ) ≤
      2 * (((doubleBadFinset P ε : Finset ((Fin N → ι) × (Fin N → ι))).card : ℝ) /
        (Fintype.card ((Fin N → ι) × (Fin N → ι)) : ℝ)) := by
  classical
  let Ω := Fin N → ι
  let B : Finset Ω := badSampleFinset P ε
  let DB : Finset (Ω × Ω) := doubleBadFinset P ε
  let goodGhost (H : Set (EuclideanSpace ℝ (Fin D))) : Finset Ω :=
    Finset.univ.filter (fun ω' : Ω => |empFreq P ω' H - popFreq P H| ≤ ε / 2)
  let witness (ω : Ω) : Set (EuclideanSpace ℝ (Fin D)) :=
    if h : ∃ H : Set (EuclideanSpace ℝ (Fin D)),
        IsClosedHalfspace H ∧ ε < |empFreq P ω H - popFreq P H|
      then Classical.choose h
      else ∅
  let fiber (ω : Ω) : Finset (Ω × Ω) := ({ω} : Finset Ω) ×ˢ goodGhost (witness ω)
  let U : Finset (Ω × Ω) := B.biUnion fiber
  have hsub : U ⊆ DB := by
    intro p hp
    rcases Finset.mem_biUnion.mp hp with ⟨ω, hωB, hp_fib⟩
    rcases Finset.mem_product.mp hp_fib with ⟨hp1, hp2⟩
    have hp1' : p.1 = ω := Finset.mem_singleton.mp hp1
    have hex : ∃ H : Set (EuclideanSpace ℝ (Fin D)),
        IsClosedHalfspace H ∧ ε < |empFreq P ω H - popFreq P H| := by
      simpa [B, badSampleFinset] using hωB
    have hw_eq : witness ω = Classical.choose hex := dif_pos hex
    obtain ⟨hH, hbad⟩ := Classical.choose_spec hex
    rw [← hw_eq] at hH hbad
    have hgood : |empFreq P p.2 (witness ω) - popFreq P (witness ω)| ≤ ε / 2 :=
      (Finset.mem_filter.mp hp2).2
    have htri := abs_sub_le (empFreq P ω (witness ω)) (empFreq P p.2 (witness ω))
      (popFreq P (witness ω))
    have hdiff : ε / 2 < |empFreq P p.1 (witness ω) - empFreq P p.2 (witness ω)| := by
      rw [hp1']
      linarith
    simp only [DB, doubleBadFinset, Finset.mem_filter, Finset.mem_univ, true_and]
    exact ⟨witness ω, hH, hdiff⟩
  have hdisj : (B : Set Ω).PairwiseDisjoint fiber := by
    intro ω₁ _ ω₂ _ hne
    refine Finset.disjoint_left.mpr ?_
    intro p hp1 hp2
    have h1 : p.1 = ω₁ := Finset.mem_singleton.mp (Finset.mem_product.mp hp1).1
    have h2 : p.1 = ω₂ := Finset.mem_singleton.mp (Finset.mem_product.mp hp2).1
    exact hne (h1.symm.trans h2)
  have hU_card : U.card = ∑ ω ∈ B, (goodGhost (witness ω)).card := by
    rw [Finset.card_biUnion hdisj]
    refine Finset.sum_congr rfl fun ω _ => ?_
    simp [fiber]
  have hcount : (B.card : ℝ) * (Fintype.card Ω : ℝ) ≤ 2 * (DB.card : ℝ) := by
    calc
      (B.card : ℝ) * (Fintype.card Ω : ℝ) = ∑ _ω ∈ B, (Fintype.card Ω : ℝ) := by
        rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ ∑ ω ∈ B, 2 * ((goodGhost (witness ω)).card : ℝ) := by
        refine Finset.sum_le_sum fun ω _ => ?_
        simpa [Ω, goodGhost, Finset.filter_congr_decidable] using
          card_le_two_mul_goodGhost P (witness ω) hN hε hNε
      _ = 2 * (U.card : ℝ) := by
        rw [← Finset.mul_sum, hU_card, Nat.cast_sum]
      _ ≤ 2 * (DB.card : ℝ) := by
        exact mul_le_mul_of_nonneg_left (Nat.cast_le.mpr (Finset.card_le_card hsub)) (by norm_num)
  have hΩ_pos : (0 : ℝ) < (Fintype.card Ω : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have hΩ_ne : (Fintype.card Ω : ℝ) ≠ 0 := ne_of_gt hΩ_pos
  have hprod_card : (Fintype.card (Ω × Ω) : ℝ) =
      (Fintype.card Ω : ℝ) * (Fintype.card Ω : ℝ) := by
    exact_mod_cast Fintype.card_prod Ω Ω
  change (B.card : ℝ) / (Fintype.card Ω : ℝ) ≤
    2 * ((DB.card : ℝ) / (Fintype.card (Ω × Ω) : ℝ))
  calc
    (B.card : ℝ) / (Fintype.card Ω : ℝ)
        = ((B.card : ℝ) * (Fintype.card Ω : ℝ)) /
            ((Fintype.card Ω : ℝ) * (Fintype.card Ω : ℝ)) := by
      rw [mul_div_mul_right _ _ hΩ_ne]
    _ ≤ (2 * (DB.card : ℝ)) /
          ((Fintype.card Ω : ℝ) * (Fintype.card Ω : ℝ)) := by
      exact div_le_div_of_nonneg_right hcount (mul_nonneg (le_of_lt hΩ_pos) (le_of_lt hΩ_pos))
    _ = 2 * ((DB.card : ℝ) / (Fintype.card (Ω × Ω) : ℝ)) := by
      rw [← hprod_card, mul_div_assoc]

end UL.Proof_cit_vc71_halfspace_uc
