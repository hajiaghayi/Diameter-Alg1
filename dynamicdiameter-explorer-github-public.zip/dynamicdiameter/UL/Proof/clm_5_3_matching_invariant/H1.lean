import UL.Stmt.clm_5_3_matching_invariant
set_option autoImplicit false

namespace UL.Proof_clm_5_3_matching_invariant

open UL

theorem nodup_map_eq_of_mem {α β : Type*} {l : List α} {f : α → β}
    (hnd : (l.map f).Nodup) {a b : α} (ha : a ∈ l) (hb : b ∈ l) (hfab : f a = f b) :
    a = b := by
  induction l with
  | nil => cases ha
  | cons hd tl ih =>
    rw [List.map_cons, List.nodup_cons] at hnd
    rcases hnd with ⟨hnot_mem, hnd_tl⟩
    rcases List.mem_cons.mp ha with rfl | ha_tl <;>
    rcases List.mem_cons.mp hb with rfl | hb_tl
    · rfl
    · exfalso
      apply hnot_mem
      rw [hfab]
      exact List.mem_map_of_mem hb_tl
    · exfalso
      apply hnot_mem
      rw [← hfab]
      exact List.mem_map_of_mem ha_tl
    · exact ih hnd_tl ha_tl hb_tl

theorem nodup_append_singleton {α : Type*} {l : List α} {x : α}
    (hl : l.Nodup) (hx : x ∉ l) : (l ++ [x]).Nodup := by
  induction l with
  | nil => exact List.nodup_singleton x
  | cons hd tl ih =>
    rw [List.cons_append, List.nodup_cons]
    rw [List.nodup_cons] at hl
    rw [List.mem_cons, not_or] at hx
    refine ⟨?_, ih hl.2 hx.2⟩
    rw [List.mem_append, List.mem_singleton, not_or]
    exact ⟨hl.1, fun h => hx.1 h.symm⟩

theorem nodup_append_middle_of_lt {α : Type*} {A B : List α} {e : α} {f : α → ℕ}
    (hnd : ((A ++ B).map f).Nodup)
    (hA : ∀ x ∈ A, f x < f e)
    (hB : ∀ x ∈ B, f x < f e) :
    (((A ++ [e]) ++ B).map f).Nodup := by
  induction A with
  | nil =>
    simp only [List.nil_append, List.singleton_append, List.map_cons, List.nodup_cons] at hnd ⊢
    refine ⟨?_, hnd⟩
    intro hmem
    rcases List.mem_map.mp hmem with ⟨x, hx, hfx⟩
    exact (Nat.ne_of_lt (hB x hx)) hfx
  | cons hd tl ih =>
    simp only [List.cons_append, List.map_cons, List.nodup_cons] at hnd ⊢
    refine ⟨?_, ih hnd.2 (fun x hx => hA x (List.mem_cons_of_mem _ hx))⟩
    intro hmem
    rw [List.append_assoc, List.map_append, List.mem_append] at hmem
    rcases hmem with htl | heb
    · apply hnd.1
      rw [List.map_append, List.mem_append]
      exact Or.inl htl
    · rw [List.singleton_append, List.map_cons, List.mem_cons] at heb
      rcases heb with hfe | hBmem
      · exact (Nat.ne_of_lt (hA hd List.mem_cons_self)) hfe
      · apply hnd.1
        rw [List.map_append, List.mem_append]
        exact Or.inr hBmem

theorem filter_eq_length_le_one {α β : Type*} {l : List α} {f : α → β}
    (hnd : (l.map f).Nodup) (p : α → Bool) (target : β)
    (hp : ∀ x, p x = true → f x = target) :
    (l.filter p).length ≤ 1 := by
  induction l with
  | nil => simp
  | cons hd tl ih =>
    rw [List.map_cons, List.nodup_cons] at hnd
    rcases hnd with ⟨hnot_mem, hnd_tl⟩
    by_cases hphd : p hd = true
    · rw [List.filter_cons_of_pos hphd]
      have htl_nil : tl.filter p = [] := by
        rw [List.filter_eq_nil_iff]
        intro x hx hpx
        apply hnot_mem
        rw [hp hd hphd, ← hp x hpx]
        exact List.mem_map_of_mem hx
      rw [htl_nil]
      simp
    · rw [List.filter_cons_of_neg hphd]
      exact ih hnd_tl

open Classical in
theorem bipartiteMatching_of_wellFormed {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ι}
    {st : LocalMatchingState ι} (hwf : st.WellFormed pts V_L V_R) :
    IsBipartiteMatching V_L V_R st.matching := by
  rcases hwf with ⟨hndL, hndR, hedges, _⟩
  refine ⟨?_, ?_, ?_⟩
  · intro xy hxy
    unfold LocalMatchingState.matching at hxy
    rw [List.mem_toFinset, List.mem_map] at hxy
    rcases hxy with ⟨e, he, rfl⟩
    rcases hedges e he with ⟨heL, heR, _⟩
    exact Finset.mem_product.mpr ⟨heL, heR⟩
  · intro x y₁ y₂ h1 h2
    unfold LocalMatchingState.matching at h1 h2
    rw [List.mem_toFinset, List.mem_map] at h1 h2
    rcases h1 with ⟨e₁, he₁, hp₁⟩
    rcases h2 with ⟨e₂, he₂, hp₂⟩
    unfold MatchingEdge.pair at hp₁ hp₂
    have hx₁ : e₁.left = x := Prod.mk.inj hp₁ |>.1
    have hy₁ : e₁.right = y₁ := Prod.mk.inj hp₁ |>.2
    have hx₂ : e₂.left = x := Prod.mk.inj hp₂ |>.1
    have hy₂ : e₂.right = y₂ := Prod.mk.inj hp₂ |>.2
    have he12 : e₁ = e₂ := nodup_map_eq_of_mem hndL he₁ he₂ (hx₁.trans hx₂.symm)
    rw [← hy₁, ← hy₂, he12]
  · intro x₁ x₂ y h1 h2
    unfold LocalMatchingState.matching at h1 h2
    rw [List.mem_toFinset, List.mem_map] at h1 h2
    rcases h1 with ⟨e₁, he₁, hp₁⟩
    rcases h2 with ⟨e₂, he₂, hp₂⟩
    unfold MatchingEdge.pair at hp₁ hp₂
    have hx₁ : e₁.left = x₁ := Prod.mk.inj hp₁ |>.1
    have hy₁ : e₁.right = y := Prod.mk.inj hp₁ |>.2
    have hx₂ : e₂.left = x₂ := Prod.mk.inj hp₂ |>.1
    have hy₂ : e₂.right = y := Prod.mk.inj hp₂ |>.2
    have he12 : e₁ = e₂ := nodup_map_eq_of_mem hndR he₁ he₂ (hy₁.trans hy₂.symm)
    rw [← hx₁, ← hx₂, he12]

open Classical in
theorem weakEdgesOn_mono {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ) (lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (ℓ : ℕ)
    {A₀ A B₀ B : Finset ι} (hA : A₀ ⊆ A) (hB : B₀ ⊆ B) :
    weakEdgesOn pts m0 lam o V ℓ A₀ B₀ ⊆ weakEdgesOn pts m0 lam o V ℓ A B := by
  intro xy hxy
  unfold weakEdgesOn at hxy ⊢
  rw [Finset.mem_filter, Finset.mem_product] at hxy ⊢
  exact ⟨⟨hA hxy.1.1, hB hxy.1.2⟩, hxy.2⟩

open Classical in
theorem strongEdgesOn_mem_of_subsets {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ) (γ lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (ℓ : ℕ)
    {A₀ A B₀ B : Finset ι} {xy : ι × ι}
    (hxy : xy ∈ strongEdgesOn pts m0 γ lam o V ℓ A B)
    (hx : xy.1 ∈ A₀) (hy : xy.2 ∈ B₀) :
    xy ∈ strongEdgesOn pts m0 γ lam o V ℓ A₀ B₀ := by
  unfold strongEdgesOn at hxy ⊢
  rw [Finset.mem_filter, Finset.mem_product] at hxy ⊢
  exact ⟨⟨hx, hy⟩, hxy.2⟩

open Classical in
theorem attach_edge_preserves_invariant {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (m0 : ℕ) (γ lam : ℚ) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (ℓ : ℕ)
    (V_L V_R : Finset ι)
    (st : LocalMatchingState ι) (v : CopyVertex ι) (st' : LocalMatchingState ι)
    (hinv :
      let V_L₀ := if v.side = .left then V_L.erase v.id else V_L
      let V_R₀ := if v.side = .right then V_R.erase v.id else V_R
      st.SatisfiesInvariant pts V_L₀ V_R₀
        (weakEdgesOn pts m0 lam o V ℓ V_L₀ V_R₀)
        (strongEdgesOn pts m0 γ lam o V ℓ V_L₀ V_R₀))
    (hstep : ValidAttachEdgeStep pts V_L V_R
      (weakEdgesOn pts m0 lam o V ℓ V_L V_R)
      (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R)
      st v st') :
    st'.SatisfiesInvariant pts V_L V_R
      (weakEdgesOn pts m0 lam o V ℓ V_L V_R)
      (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R) := by
  rcases v with ⟨side, vid⟩
  rcases hstep with ⟨⟨hact, hunm, hnidx⟩, ans, hprom, rfl⟩
  cases side with
  | left =>
    dsimp only at hinv
    rw [if_pos rfl, if_neg (by intro h; cases h)] at hinv
    dsimp only [isCopyActive, LocalMatchingState.isCopyMatched,
      LocalMatchingState.isCopyInIndex, LocalMatchingState.oppositeIndexSet] at hact hunm hnidx hprom
    rcases hinv with ⟨⟨hndL, hndR, hedges, hndLidx, hlset, hndRidx, hrset, hndLife, hlifeL, hlifeR⟩,
      ⟨hM_weak, _, hdisj⟩⟩
    have hVL_sub : V_L.erase vid ⊆ V_L := Finset.erase_subset vid V_L
    cases ans with
    | some w =>
      dsimp only [SatisfiesEdgeSearchPromise] at hprom
      rcases hprom with ⟨hw_rset, hvw_weak⟩
      have hw_unmR : w ∈ unmatchedRight V_R st.matching := by rwa [← hrset]
      unfold unmatchedRight at hw_unmR
      rw [Finset.mem_filter] at hw_unmR
      rcases hw_unmR with ⟨hw_VR, hw_nomatch⟩
      have hw_not_R : w ∉ st.matchingList.map MatchingEdge.right := by
        intro hmem
        rcases List.mem_map.mp hmem with ⟨e, he, her⟩
        apply hw_nomatch e.left
        unfold LocalMatchingState.matching
        rw [List.mem_toFinset, List.mem_map]
        exact ⟨e, he, by simp [MatchingEdge.pair, her]⟩
      have hvid_not_L : vid ∉ st.matchingList.map MatchingEdge.left := by
        intro hmem
        rcases List.mem_map.mp hmem with ⟨e, he, hel⟩
        exact hunm ⟨e, he, hel⟩
      let st1 := attachStep pts st ⟨.left, vid⟩ (some w)
      have hM1_eq : st1.matching = insert (vid, w) st.matching := by
        ext xy
        simp [st1, attachStep, LocalMatchingState.matching, MatchingEdge.pair]
      have hwf1 : st1.WellFormed pts V_L V_R := by
        dsimp only [st1, attachStep, LocalMatchingState.WellFormed]
        refine ⟨?_, ?_, ?_, hndLidx, ?_, ?_, ?_, ?_, hlifeL, ?_⟩
        · rw [List.map_append, List.map_singleton]
          exact nodup_append_singleton hndL hvid_not_L
        · rw [List.map_append, List.map_singleton]
          exact nodup_append_singleton hndR hw_not_R
        · intro e he
          rcases List.mem_append.mp he with he_old | he_new
          · rcases hedges e he_old with ⟨h1, h2, h3⟩
            exact ⟨hVL_sub h1, h2, h3⟩
          · rw [List.mem_singleton] at he_new
            subst he_new
            exact ⟨hact, hw_VR, rfl⟩
        · change st.leftIndexSet = unmatchedLeft V_L st1.matching
          rw [hlset, hM1_eq]
          ext x
          simp only [unmatchedLeft, Finset.mem_filter, Finset.mem_erase, Finset.mem_insert]
          constructor
          · rintro ⟨⟨hx_ne, hx_VL⟩, hx_unm⟩
            refine ⟨hx_VL, fun y hxy => ?_⟩
            rcases hxy with heq | hmem
            · exact hx_ne (Prod.mk.inj heq).1
            · exact hx_unm y hmem
          · rintro ⟨hx_VL, hx_unm⟩
            have hx_ne : x ≠ vid := by
              intro hEq
              subst hEq
              exact hx_unm w (Or.inl rfl)
            exact ⟨⟨hx_ne, hx_VL⟩, fun y hmem => hx_unm y (Or.inr hmem)⟩
        · exact hndRidx.sublist ((List.filter_sublist).map _)
        · ext y
          have hy_lhs : y ∈ st1.rightIndexSet ↔ y ∈ st.rightIndexSet ∧ y ≠ w := by
            simp only [st1, attachStep, LocalMatchingState.rightIndexSet, List.mem_toFinset,
              List.mem_map, List.mem_filter, decide_eq_true_eq]
            constructor
            · rintro ⟨e, ⟨he, hne⟩, rfl⟩
              exact ⟨⟨e, he, rfl⟩, hne⟩
            · rintro ⟨⟨e, he, rfl⟩, hne⟩
              exact ⟨e, ⟨he, hne⟩, rfl⟩
          change y ∈ st1.rightIndexSet ↔ y ∈ unmatchedRight V_R st1.matching
          rw [hy_lhs, hrset, hM1_eq]
          simp only [unmatchedRight, Finset.mem_filter, Finset.mem_insert]
          constructor
          · rintro ⟨⟨hy_VR, hy_unm⟩, hy_ne⟩
            refine ⟨hy_VR, fun x hxy => ?_⟩
            rcases hxy with heq | hmem
            · exact hy_ne (Prod.mk.inj heq).2
            · exact hy_unm x hmem
          · rintro ⟨hy_VR, hy_unm⟩
            have hy_ne : y ≠ w := by
              intro hEq
              subst hEq
              exact hy_unm vid (Or.inl rfl)
            exact ⟨⟨hy_VR, fun x hmem => hy_unm x (Or.inr hmem)⟩, hy_ne⟩
        · exact hndLife.sublist ((List.Sublist.append_left List.filter_sublist _).map _)
        · intro e he
          exact hlifeR e (List.mem_of_mem_filter he)
      refine ⟨hwf1, ?_, bipartiteMatching_of_wellFormed hwf1, ?_⟩
      · change st1.matching ⊆ weakEdgesOn pts m0 lam o V ℓ V_L V_R
        rw [hM1_eq]
        refine Finset.insert_subset_iff.mpr ⟨hvw_weak, ?_⟩
        exact hM_weak.trans (weakEdgesOn_mono pts m0 lam o V ℓ hVL_sub (Finset.Subset.refl V_R))
      · change Disjoint (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R)
          (unmatchedLeft V_L st1.matching ×ˢ unmatchedRight V_R st1.matching)
        rw [Finset.disjoint_left]
        intro xy hxy_strong hxy_prod
        rw [Finset.mem_product] at hxy_prod
        rcases hxy_prod with ⟨hx_uL1, hy_uR1⟩
        have hx_uL0 : xy.1 ∈ unmatchedLeft (V_L.erase vid) st.matching := by
          have h5 := hwf1.2.2.2.2.1
          change st.leftIndexSet = unmatchedLeft V_L st1.matching at h5
          rwa [← hlset, h5]
        have hy_uR0 : xy.2 ∈ unmatchedRight V_R st.matching := by
          rw [hM1_eq] at hy_uR1
          simp only [unmatchedRight, Finset.mem_filter, Finset.mem_insert] at hy_uR1 ⊢
          exact ⟨hy_uR1.1, fun x hmem => hy_uR1.2 x (Or.inr hmem)⟩
        have hx_VL0 : xy.1 ∈ V_L.erase vid := (Finset.mem_filter.mp hx_uL0).1
        have hy_VR0 : xy.2 ∈ V_R := (Finset.mem_filter.mp hy_uR0).1
        have hstrong0 := strongEdgesOn_mem_of_subsets pts m0 γ lam o V ℓ hxy_strong hx_VL0 hy_VR0
        exact Finset.disjoint_left.mp hdisj hstrong0 (Finset.mem_product.mpr ⟨hx_uL0, hy_uR0⟩)
    | none =>
      dsimp only [SatisfiesEdgeSearchPromise] at hprom
      have hvid_not_Lidx : vid ∉ st.leftUnmatchedIndex.map UnmatchedEntry.id := by
        intro hmem
        rcases List.mem_map.mp hmem with ⟨e, he, heid⟩
        exact hnidx ⟨e, he, heid⟩
      have hvid_nomatch : ∀ y, (vid, y) ∉ st.matching := by
        intro y hmem
        unfold LocalMatchingState.matching at hmem
        rw [List.mem_toFinset, List.mem_map] at hmem
        rcases hmem with ⟨e, he, hp⟩
        exact hunm ⟨e, he, (Prod.mk.inj hp).1⟩
      let st1 := attachStep pts st ⟨.left, vid⟩ none
      have hwf1 : st1.WellFormed pts V_L V_R := by
        dsimp only [st1, attachStep, LocalMatchingState.WellFormed]
        refine ⟨hndL, hndR, ?_, ?_, ?_, hndRidx, hrset, ?_, ?_, ?_⟩
        · intro e he
          rcases hedges e he with ⟨h1, h2, h3⟩
          exact ⟨hVL_sub h1, h2, h3⟩
        · rw [List.map_append, List.map_singleton]
          exact nodup_append_singleton hndLidx hvid_not_Lidx
        · ext x
          have hx_lhs : x ∈ st1.leftIndexSet ↔ x = vid ∨ x ∈ st.leftIndexSet := by
            simp [st1, attachStep, LocalMatchingState.leftIndexSet, or_comm]
          change x ∈ st1.leftIndexSet ↔ x ∈ unmatchedLeft V_L st.matching
          rw [hx_lhs, hlset]
          simp only [unmatchedLeft, Finset.mem_filter, Finset.mem_erase]
          constructor
          · rintro (rfl | ⟨⟨_, hx_VL⟩, hx_unm⟩)
            · exact ⟨hact, hvid_nomatch⟩
            · exact ⟨hx_VL, hx_unm⟩
          · rintro ⟨hx_VL, hx_unm⟩
            by_cases hEq : x = vid
            · exact Or.inl hEq
            · exact Or.inr ⟨⟨hEq, hx_VL⟩, hx_unm⟩
        · exact nodup_append_middle_of_lt hndLife hlifeL hlifeR
        · intro e he
          rcases List.mem_append.mp he with he_old | he_new
          · exact Nat.lt_succ_of_lt (hlifeL e he_old)
          · rw [List.mem_singleton] at he_new
            subst he_new
            exact Nat.lt_succ_self _
        · intro e he
          exact Nat.lt_succ_of_lt (hlifeR e he)
      refine ⟨hwf1, ?_, bipartiteMatching_of_wellFormed hwf1, ?_⟩
      · exact hM_weak.trans (weakEdgesOn_mono pts m0 lam o V ℓ hVL_sub (Finset.Subset.refl V_R))
      · change Disjoint (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R)
          (unmatchedLeft V_L st.matching ×ˢ unmatchedRight V_R st.matching)
        rw [Finset.disjoint_left]
        intro xy hxy_strong hxy_prod
        rw [Finset.mem_product] at hxy_prod
        rcases hxy_prod with ⟨hx_uL, hy_uR⟩
        by_cases hEq : xy.1 = vid
        · have hy_rset : xy.2 ∈ st.rightIndexSet := by rwa [hrset]
          have hpair : (vid, xy.2) ∈ strongEdgesOn pts m0 γ lam o V ℓ V_L V_R := by
            rcases xy with ⟨x1, y1⟩
            dsimp only at hEq ⊢
            subst hEq
            exact hxy_strong
          exact hprom xy.2 hy_rset hpair
        · have hx_uL0 : xy.1 ∈ unmatchedLeft (V_L.erase vid) st.matching := by
            simp only [unmatchedLeft, Finset.mem_filter, Finset.mem_erase] at hx_uL ⊢
            exact ⟨⟨hEq, hx_uL.1⟩, hx_uL.2⟩
          have hx_VL0 : xy.1 ∈ V_L.erase vid := (Finset.mem_filter.mp hx_uL0).1
          have hy_VR0 : xy.2 ∈ V_R := (Finset.mem_filter.mp hy_uR).1
          have hstrong0 := strongEdgesOn_mem_of_subsets pts m0 γ lam o V ℓ hxy_strong hx_VL0 hy_VR0
          exact Finset.disjoint_left.mp hdisj hstrong0 (Finset.mem_product.mpr ⟨hx_uL0, hy_uR⟩)
  | right =>
    dsimp only at hinv
    rw [if_neg (by intro h; cases h), if_pos rfl] at hinv
    dsimp only [isCopyActive, LocalMatchingState.isCopyMatched,
      LocalMatchingState.isCopyInIndex, LocalMatchingState.oppositeIndexSet] at hact hunm hnidx hprom
    rcases hinv with ⟨⟨hndL, hndR, hedges, hndLidx, hlset, hndRidx, hrset, hndLife, hlifeL, hlifeR⟩,
      ⟨hM_weak, _, hdisj⟩⟩
    have hVR_sub : V_R.erase vid ⊆ V_R := Finset.erase_subset vid V_R
    cases ans with
    | some w =>
      dsimp only [SatisfiesEdgeSearchPromise] at hprom
      rcases hprom with ⟨hw_lset, hvw_weak⟩
      have hw_unmL : w ∈ unmatchedLeft V_L st.matching := by rwa [← hlset]
      unfold unmatchedLeft at hw_unmL
      rw [Finset.mem_filter] at hw_unmL
      rcases hw_unmL with ⟨hw_VL, hw_nomatch⟩
      have hw_not_L : w ∉ st.matchingList.map MatchingEdge.left := by
        intro hmem
        rcases List.mem_map.mp hmem with ⟨e, he, hel⟩
        apply hw_nomatch e.right
        unfold LocalMatchingState.matching
        rw [List.mem_toFinset, List.mem_map]
        exact ⟨e, he, by simp [MatchingEdge.pair, hel]⟩
      have hvid_not_R : vid ∉ st.matchingList.map MatchingEdge.right := by
        intro hmem
        rcases List.mem_map.mp hmem with ⟨e, he, her⟩
        exact hunm ⟨e, he, her⟩
      let st1 := attachStep pts st ⟨.right, vid⟩ (some w)
      have hM1_eq : st1.matching = insert (w, vid) st.matching := by
        ext xy
        simp [st1, attachStep, LocalMatchingState.matching, MatchingEdge.pair]
      have hwf1 : st1.WellFormed pts V_L V_R := by
        dsimp only [st1, attachStep, LocalMatchingState.WellFormed]
        refine ⟨?_, ?_, ?_, ?_, ?_, hndRidx, ?_, ?_, ?_, hlifeR⟩
        · rw [List.map_append, List.map_singleton]
          exact nodup_append_singleton hndL hw_not_L
        · rw [List.map_append, List.map_singleton]
          exact nodup_append_singleton hndR hvid_not_R
        · intro e he
          rcases List.mem_append.mp he with he_old | he_new
          · rcases hedges e he_old with ⟨h1, h2, h3⟩
            exact ⟨h1, hVR_sub h2, h3⟩
          · rw [List.mem_singleton] at he_new
            subst he_new
            exact ⟨hw_VL, hact, rfl⟩
        · exact hndLidx.sublist ((List.filter_sublist).map _)
        · ext x
          have hx_lhs : x ∈ st1.leftIndexSet ↔ x ∈ st.leftIndexSet ∧ x ≠ w := by
            simp only [st1, attachStep, LocalMatchingState.leftIndexSet, List.mem_toFinset,
              List.mem_map, List.mem_filter, decide_eq_true_eq]
            constructor
            · rintro ⟨e, ⟨he, hne⟩, rfl⟩
              exact ⟨⟨e, he, rfl⟩, hne⟩
            · rintro ⟨⟨e, he, rfl⟩, hne⟩
              exact ⟨e, ⟨he, hne⟩, rfl⟩
          change x ∈ st1.leftIndexSet ↔ x ∈ unmatchedLeft V_L st1.matching
          rw [hx_lhs, hlset, hM1_eq]
          simp only [unmatchedLeft, Finset.mem_filter, Finset.mem_insert]
          constructor
          · rintro ⟨⟨hx_VL, hx_unm⟩, hx_ne⟩
            refine ⟨hx_VL, fun y hxy => ?_⟩
            rcases hxy with heq | hmem
            · exact hx_ne (Prod.mk.inj heq).1
            · exact hx_unm y hmem
          · rintro ⟨hx_VL, hx_unm⟩
            have hx_ne : x ≠ w := by
              intro hEq
              subst hEq
              exact hx_unm vid (Or.inl rfl)
            exact ⟨⟨hx_VL, fun y hmem => hx_unm y (Or.inr hmem)⟩, hx_ne⟩
        · change st.rightIndexSet = unmatchedRight V_R st1.matching
          rw [hrset, hM1_eq]
          ext y
          simp only [unmatchedRight, Finset.mem_filter, Finset.mem_erase, Finset.mem_insert]
          constructor
          · rintro ⟨⟨hy_ne, hy_VR⟩, hy_unm⟩
            refine ⟨hy_VR, fun x hxy => ?_⟩
            rcases hxy with heq | hmem
            · exact hy_ne (Prod.mk.inj heq).2
            · exact hy_unm x hmem
          · rintro ⟨hy_VR, hy_unm⟩
            have hy_ne : y ≠ vid := by
              intro hEq
              subst hEq
              exact hy_unm w (Or.inl rfl)
            exact ⟨⟨hy_ne, hy_VR⟩, fun x hmem => hy_unm x (Or.inr hmem)⟩
        · exact hndLife.sublist ((List.Sublist.append_right List.filter_sublist _).map _)
        · intro e he
          exact hlifeL e (List.mem_of_mem_filter he)
      refine ⟨hwf1, ?_, bipartiteMatching_of_wellFormed hwf1, ?_⟩
      · change st1.matching ⊆ weakEdgesOn pts m0 lam o V ℓ V_L V_R
        rw [hM1_eq]
        refine Finset.insert_subset_iff.mpr ⟨hvw_weak, ?_⟩
        exact hM_weak.trans (weakEdgesOn_mono pts m0 lam o V ℓ (Finset.Subset.refl V_L) hVR_sub)
      · change Disjoint (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R)
          (unmatchedLeft V_L st1.matching ×ˢ unmatchedRight V_R st1.matching)
        rw [Finset.disjoint_left]
        intro xy hxy_strong hxy_prod
        rw [Finset.mem_product] at hxy_prod
        rcases hxy_prod with ⟨hx_uL1, hy_uR1⟩
        have hx_uL0 : xy.1 ∈ unmatchedLeft V_L st.matching := by
          rw [hM1_eq] at hx_uL1
          simp only [unmatchedLeft, Finset.mem_filter, Finset.mem_insert] at hx_uL1 ⊢
          exact ⟨hx_uL1.1, fun y hmem => hx_uL1.2 y (Or.inr hmem)⟩
        have hy_uR0 : xy.2 ∈ unmatchedRight (V_R.erase vid) st.matching := by
          have h7 := hwf1.2.2.2.2.2.2.1
          change st.rightIndexSet = unmatchedRight V_R st1.matching at h7
          rwa [← hrset, h7]
        have hx_VL0 : xy.1 ∈ V_L := (Finset.mem_filter.mp hx_uL0).1
        have hy_VR0 : xy.2 ∈ V_R.erase vid := (Finset.mem_filter.mp hy_uR0).1
        have hstrong0 := strongEdgesOn_mem_of_subsets pts m0 γ lam o V ℓ hxy_strong hx_VL0 hy_VR0
        exact Finset.disjoint_left.mp hdisj hstrong0 (Finset.mem_product.mpr ⟨hx_uL0, hy_uR0⟩)
    | none =>
      dsimp only [SatisfiesEdgeSearchPromise] at hprom
      have hvid_not_Ridx : vid ∉ st.rightUnmatchedIndex.map UnmatchedEntry.id := by
        intro hmem
        rcases List.mem_map.mp hmem with ⟨e, he, heid⟩
        exact hnidx ⟨e, he, heid⟩
      have hvid_nomatch : ∀ x, (x, vid) ∉ st.matching := by
        intro x hmem
        unfold LocalMatchingState.matching at hmem
        rw [List.mem_toFinset, List.mem_map] at hmem
        rcases hmem with ⟨e, he, hp⟩
        exact hunm ⟨e, he, (Prod.mk.inj hp).2⟩
      let st1 := attachStep pts st ⟨.right, vid⟩ none
      have hwf1 : st1.WellFormed pts V_L V_R := by
        dsimp only [st1, attachStep, LocalMatchingState.WellFormed]
        refine ⟨hndL, hndR, ?_, hndLidx, hlset, ?_, ?_, ?_, ?_, ?_⟩
        · intro e he
          rcases hedges e he with ⟨h1, h2, h3⟩
          exact ⟨h1, hVR_sub h2, h3⟩
        · rw [List.map_append, List.map_singleton]
          exact nodup_append_singleton hndRidx hvid_not_Ridx
        · ext y
          have hy_lhs : y ∈ st1.rightIndexSet ↔ y = vid ∨ y ∈ st.rightIndexSet := by
            simp [st1, attachStep, LocalMatchingState.rightIndexSet, or_comm]
          change y ∈ st1.rightIndexSet ↔ y ∈ unmatchedRight V_R st.matching
          rw [hy_lhs, hrset]
          simp only [unmatchedRight, Finset.mem_filter, Finset.mem_erase]
          constructor
          · rintro (rfl | ⟨⟨_, hy_VR⟩, hy_unm⟩)
            · exact ⟨hact, hvid_nomatch⟩
            · exact ⟨hy_VR, hy_unm⟩
          · rintro ⟨hy_VR, hy_unm⟩
            by_cases hEq : y = vid
            · exact Or.inl hEq
            · exact Or.inr ⟨⟨hEq, hy_VR⟩, hy_unm⟩
        · rw [← List.append_assoc, List.map_append, List.map_singleton]
          refine nodup_append_singleton hndLife ?_
          intro hz
          rcases List.mem_map.mp hz with ⟨e, he, hfe⟩
          rcases List.mem_append.mp he with heL | heR
          · exact (Nat.ne_of_lt (hlifeL e heL)) hfe
          · exact (Nat.ne_of_lt (hlifeR e heR)) hfe
        · intro e he
          exact Nat.lt_succ_of_lt (hlifeL e he)
        · intro e he
          rcases List.mem_append.mp he with he_old | he_new
          · exact Nat.lt_succ_of_lt (hlifeR e he_old)
          · rw [List.mem_singleton] at he_new
            subst he_new
            exact Nat.lt_succ_self _
      refine ⟨hwf1, ?_, bipartiteMatching_of_wellFormed hwf1, ?_⟩
      · exact hM_weak.trans (weakEdgesOn_mono pts m0 lam o V ℓ (Finset.Subset.refl V_L) hVR_sub)
      · change Disjoint (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R)
          (unmatchedLeft V_L st.matching ×ˢ unmatchedRight V_R st.matching)
        rw [Finset.disjoint_left]
        intro xy hxy_strong hxy_prod
        rw [Finset.mem_product] at hxy_prod
        rcases hxy_prod with ⟨hx_uL, hy_uR⟩
        by_cases hEq : xy.2 = vid
        · have hx_lset : xy.1 ∈ st.leftIndexSet := by rwa [hlset]
          have hpair : (xy.1, vid) ∈ strongEdgesOn pts m0 γ lam o V ℓ V_L V_R := by
            rcases xy with ⟨x1, y1⟩
            dsimp only at hEq ⊢
            subst hEq
            exact hxy_strong
          exact hprom xy.1 hx_lset hpair
        · have hy_uR0 : xy.2 ∈ unmatchedRight (V_R.erase vid) st.matching := by
            simp only [unmatchedRight, Finset.mem_filter, Finset.mem_erase] at hy_uR ⊢
            exact ⟨⟨hEq, hy_uR.1⟩, hy_uR.2⟩
          have hx_VL0 : xy.1 ∈ V_L := (Finset.mem_filter.mp hx_uL).1
          have hy_VR0 : xy.2 ∈ V_R.erase vid := (Finset.mem_filter.mp hy_uR0).1
          have hstrong0 := strongEdgesOn_mem_of_subsets pts m0 γ lam o V ℓ hxy_strong hx_VL0 hy_VR0
          exact Finset.disjoint_left.mp hdisj hstrong0 (Finset.mem_product.mpr ⟨hx_uL, hy_uR0⟩)

open Classical in
noncomputable def remLeft {ι : Type*} (us : List (CopyVertex ι)) (A : Finset ι) : Finset ι :=
  A.filter (fun x => CopyVertex.mk .left x ∉ us)

open Classical in
noncomputable def remRight {ι : Type*} (us : List (CopyVertex ι)) (B : Finset ι) : Finset ι :=
  B.filter (fun y => CopyVertex.mk .right y ∉ us)

open Classical in
theorem surviving_partners_bounds {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ι}
    {st : LocalMatchingState ι} (hwf : st.WellFormed pts V_L V_R) (p : ι) :
    (survivingFormerPartnerSet st p).card ≤ 2 ∧
    (survivingFormerPartners st p).length ≤ 2 := by
  rcases hwf with ⟨hndL, hndR, _⟩
  have hlenR : ((st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
      (fun e => CopyVertex.mk .right e.right)).length ≤ 1 := by
    rw [List.length_map]
    exact filter_eq_length_le_one hndL _ p (fun x hx => (of_decide_eq_true hx).1)
  have hlenL : ((st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
      (fun e => CopyVertex.mk .left e.left)).length ≤ 1 := by
    rw [List.length_map]
    exact filter_eq_length_le_one hndR _ p (fun x hx => (of_decide_eq_true hx).1)
  have hlen_dedup : (survivingFormerPartners st p).length ≤ 2 := by
    unfold survivingFormerPartners
    refine le_trans (List.Sublist.length_le (List.dedup_sublist _)) ?_
    rw [List.length_append]
    omega
  have hcard : (survivingFormerPartnerSet st p).card ≤ 2 := by
    unfold survivingFormerPartnerSet
    exact (List.toFinset_card_le _).trans hlen_dedup
  exact ⟨hcard, hlen_dedup⟩

open Classical in
theorem surviving_partners_active {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ι}
    {st : LocalMatchingState ι} (hwf : st.WellFormed pts V_L V_R) (p : ι)
    {u : CopyVertex ι} (hu : u ∈ survivingFormerPartners st p) :
    isCopyActive (V_L.erase p) (V_R.erase p) u := by
  rcases hwf with ⟨_, _, hedges, _⟩
  unfold survivingFormerPartners at hu
  rw [List.mem_dedup, List.mem_append] at hu
  rcases hu with huR | huL
  · rw [List.mem_map] at huR
    rcases huR with ⟨e, he, rfl⟩
    rw [List.mem_filter, decide_eq_true_eq] at he
    rcases he with ⟨he_mem, _, hne⟩
    have heR : e.right ∈ V_R := (hedges e he_mem).2.1
    simp [isCopyActive, hne, heR]
  · rw [List.mem_map] at huL
    rcases huL with ⟨e, he, rfl⟩
    rw [List.mem_filter, decide_eq_true_eq] at he
    rcases he with ⟨he_mem, _, hne⟩
    have heL : e.left ∈ V_L := (hedges e he_mem).1
    simp [isCopyActive, hne, heL]

open Classical in
theorem removeCopies_satisfies_invariant {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (m0 : ℕ) (γ lam : ℚ) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (ℓ : ℕ)
    (V_L V_R : Finset ι) (st : LocalMatchingState ι) (p : ι)
    (hinv : st.SatisfiesInvariant pts V_L V_R
      (weakEdgesOn pts m0 lam o V ℓ V_L V_R)
      (strongEdgesOn pts m0 γ lam o V ℓ V_L V_R)) :
    let F := survivingFormerPartners st p
    let A₀ := remLeft F (V_L.erase p)
    let B₀ := remRight F (V_R.erase p)
    (removeCopiesFromState st p).SatisfiesInvariant pts A₀ B₀
      (weakEdgesOn pts m0 lam o V ℓ A₀ B₀)
      (strongEdgesOn pts m0 γ lam o V ℓ A₀ B₀) := by
  dsimp only
  set F := survivingFormerPartners st p
  set A₀ := remLeft F (V_L.erase p)
  set B₀ := remRight F (V_R.erase p)
  let st0 := removeCopiesFromState st p
  rcases hinv with ⟨⟨hndL, hndR, hedges, hndLidx, hlset, hndRidx, hrset, hndLife, hlifeL, hlifeR⟩,
    ⟨hM_weak, _, hdisj⟩⟩
  have hmem_F_left : ∀ x : ι, CopyVertex.mk .left x ∈ F ↔
      ∃ e ∈ st.matchingList, e.right = p ∧ e.left ≠ p ∧ e.left = x := by
    intro x
    simp only [F, survivingFormerPartners, List.mem_dedup, List.mem_append, List.mem_map,
      List.mem_filter, decide_eq_true_eq]
    constructor
    · rintro (⟨e, _, h⟩ | ⟨e, ⟨he, hrp, hlp⟩, h⟩)
      · cases h
      · exact ⟨e, he, hrp, hlp, CopyVertex.mk.inj h |>.2⟩
    · rintro ⟨e, he, hrp, hlp, rfl⟩
      exact Or.inr ⟨e, ⟨he, hrp, hlp⟩, rfl⟩
  have hmem_F_right : ∀ y : ι, CopyVertex.mk .right y ∈ F ↔
      ∃ e ∈ st.matchingList, e.left = p ∧ e.right ≠ p ∧ e.right = y := by
    intro y
    simp only [F, survivingFormerPartners, List.mem_dedup, List.mem_append, List.mem_map,
      List.mem_filter, decide_eq_true_eq]
    constructor
    · rintro (⟨e, ⟨he, hlp, hrp⟩, h⟩ | ⟨e, _, h⟩)
      · exact ⟨e, he, hlp, hrp, CopyVertex.mk.inj h |>.2⟩
      · cases h
    · rintro ⟨e, he, hlp, hrp, rfl⟩
      exact Or.inl ⟨e, ⟨he, hlp, hrp⟩, rfl⟩
  have hM0_iff : ∀ x y : ι, (x, y) ∈ st0.matching ↔ (x, y) ∈ st.matching ∧ x ≠ p ∧ y ≠ p := by
    intro x y
    simp only [st0, removeCopiesFromState, LocalMatchingState.matching, List.mem_toFinset,
      List.mem_map, List.mem_filter, decide_eq_true_eq, MatchingEdge.pair]
    constructor
    · rintro ⟨e, ⟨he, hlp, hrp⟩, hxy⟩
      rcases Prod.mk.inj hxy with ⟨rfl, rfl⟩
      exact ⟨⟨e, he, rfl⟩, hlp, hrp⟩
    · rintro ⟨⟨e, he, hxy⟩, hxp, hyp⟩
      rcases Prod.mk.inj hxy with ⟨rfl, rfl⟩
      exact ⟨e, ⟨he, hxp, hyp⟩, rfl⟩
  have hwf0 : st0.WellFormed pts A₀ B₀ := by
    dsimp only [st0, removeCopiesFromState, LocalMatchingState.WellFormed]
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · exact hndL.sublist ((List.filter_sublist).map _)
    · exact hndR.sublist ((List.filter_sublist).map _)
    · intro e he
      rw [List.mem_filter, decide_eq_true_eq] at he
      rcases he with ⟨he_mem, hlp, hrp⟩
      rcases hedges e he_mem with ⟨heL, heR, hdist⟩
      have heA : e.left ∈ A₀ := by
        refine Finset.mem_filter.mpr ⟨Finset.mem_erase.mpr ⟨hlp, heL⟩, ?_⟩
        rw [hmem_F_left]
        rintro ⟨e', he', he'r, _, he'l⟩
        have heq := nodup_map_eq_of_mem hndL he_mem he' he'l.symm
        exact hrp (heq ▸ he'r)
      have heB : e.right ∈ B₀ := by
        refine Finset.mem_filter.mpr ⟨Finset.mem_erase.mpr ⟨hrp, heR⟩, ?_⟩
        rw [hmem_F_right]
        rintro ⟨e', he', he'l, _, he'r⟩
        have heq := nodup_map_eq_of_mem hndR he_mem he' he'r.symm
        exact hlp (heq ▸ he'l)
      exact ⟨heA, heB, hdist⟩
    · exact hndLidx.sublist ((List.filter_sublist).map _)
    · ext x
      have hx_lhs : x ∈ st0.leftIndexSet ↔ x ∈ st.leftIndexSet ∧ x ≠ p := by
        simp only [st0, removeCopiesFromState, LocalMatchingState.leftIndexSet, List.mem_toFinset,
          List.mem_map, List.mem_filter, decide_eq_true_eq]
        constructor
        · rintro ⟨e, ⟨he, hne⟩, rfl⟩; exact ⟨⟨e, he, rfl⟩, hne⟩
        · rintro ⟨⟨e, he, rfl⟩, hne⟩; exact ⟨e, ⟨he, hne⟩, rfl⟩
      change x ∈ st0.leftIndexSet ↔ x ∈ unmatchedLeft A₀ st0.matching
      rw [hx_lhs, hlset]
      simp only [unmatchedLeft, A₀, remLeft, Finset.mem_filter, Finset.mem_erase, hmem_F_left,
        hM0_iff]
      constructor
      · rintro ⟨⟨hx_VL, hx_unm⟩, hxp⟩
        refine ⟨⟨⟨hxp, hx_VL⟩, ?_⟩, fun y ⟨hmem, _, _⟩ => hx_unm y hmem⟩
        rintro ⟨e, he, hrp, _, rfl⟩
        apply hx_unm p
        unfold LocalMatchingState.matching
        rw [List.mem_toFinset, List.mem_map]
        exact ⟨e, he, by simp [MatchingEdge.pair, hrp]⟩
      · rintro ⟨⟨⟨hxp, hx_VL⟩, hnoF⟩, hx_unm0⟩
        refine ⟨⟨hx_VL, fun y hxy => ?_⟩, hxp⟩
        by_cases hyp : y = p
        · subst hyp
          unfold LocalMatchingState.matching at hxy
          rw [List.mem_toFinset, List.mem_map] at hxy
          rcases hxy with ⟨e, he, hp_eq⟩
          rcases Prod.mk.inj hp_eq with ⟨hel, her⟩
          exact hnoF ⟨e, he, her, hel ▸ hxp, hel⟩
        · exact hx_unm0 y ⟨hxy, hxp, hyp⟩
    · exact hndRidx.sublist ((List.filter_sublist).map _)
    · ext y
      have hy_lhs : y ∈ st0.rightIndexSet ↔ y ∈ st.rightIndexSet ∧ y ≠ p := by
        simp only [st0, removeCopiesFromState, LocalMatchingState.rightIndexSet, List.mem_toFinset,
          List.mem_map, List.mem_filter, decide_eq_true_eq]
        constructor
        · rintro ⟨e, ⟨he, hne⟩, rfl⟩; exact ⟨⟨e, he, rfl⟩, hne⟩
        · rintro ⟨⟨e, he, rfl⟩, hne⟩; exact ⟨e, ⟨he, hne⟩, rfl⟩
      change y ∈ st0.rightIndexSet ↔ y ∈ unmatchedRight B₀ st0.matching
      rw [hy_lhs, hrset]
      simp only [unmatchedRight, B₀, remRight, Finset.mem_filter, Finset.mem_erase, hmem_F_right,
        hM0_iff]
      constructor
      · rintro ⟨⟨hy_VR, hy_unm⟩, hyp⟩
        refine ⟨⟨⟨hyp, hy_VR⟩, ?_⟩, fun x ⟨hmem, _, _⟩ => hy_unm x hmem⟩
        rintro ⟨e, he, hlp, _, rfl⟩
        apply hy_unm p
        unfold LocalMatchingState.matching
        rw [List.mem_toFinset, List.mem_map]
        exact ⟨e, he, by simp [MatchingEdge.pair, hlp]⟩
      · rintro ⟨⟨⟨hyp, hy_VR⟩, hnoF⟩, hy_unm0⟩
        refine ⟨⟨hy_VR, fun x hxy => ?_⟩, hyp⟩
        by_cases hxp : x = p
        · subst hxp
          unfold LocalMatchingState.matching at hxy
          rw [List.mem_toFinset, List.mem_map] at hxy
          rcases hxy with ⟨e, he, hp_eq⟩
          rcases Prod.mk.inj hp_eq with ⟨hel, her⟩
          exact hnoF ⟨e, he, hel, her ▸ hyp, her⟩
        · exact hy_unm0 x ⟨hxy, hxp, hyp⟩
    · exact hndLife.sublist
        ((List.Sublist.append List.filter_sublist List.filter_sublist).map _)
    · intro e he
      exact hlifeL e (List.mem_of_mem_filter he)
    · intro e he
      exact hlifeR e (List.mem_of_mem_filter he)
  refine ⟨hwf0, ?_, bipartiteMatching_of_wellFormed hwf0, ?_⟩
  · intro xy hxy
    rcases xy with ⟨x, y⟩
    have hmem_bip := (bipartiteMatching_of_wellFormed hwf0).1 hxy
    rw [Finset.mem_product] at hmem_bip
    have hxy_old : (x, y) ∈ st.matching := ((hM0_iff x y).mp hxy).1
    have hweak_old := hM_weak hxy_old
    unfold weakEdgesOn at hweak_old ⊢
    rw [Finset.mem_filter, Finset.mem_product] at hweak_old ⊢
    exact ⟨hmem_bip, hweak_old.2⟩
  · rw [Finset.disjoint_left]
    intro xy hxy_strong hxy_prod
    rw [Finset.mem_product] at hxy_prod
    rcases hxy_prod with ⟨hx_uL0, hy_uR0⟩
    have hx_uL : xy.1 ∈ unmatchedLeft V_L st.matching := by
      have h5 := hwf0.2.2.2.2.1
      rw [← h5] at hx_uL0
      simp only [st0, removeCopiesFromState, LocalMatchingState.leftIndexSet, List.mem_toFinset,
        List.mem_map, List.mem_filter, decide_eq_true_eq] at hx_uL0
      rcases hx_uL0 with ⟨e, ⟨he, _⟩, heid⟩
      rw [← hlset]
      simp only [LocalMatchingState.leftIndexSet, List.mem_toFinset, List.mem_map]
      exact ⟨e, he, heid⟩
    have hy_uR : xy.2 ∈ unmatchedRight V_R st.matching := by
      have h7 := hwf0.2.2.2.2.2.2.1
      rw [← h7] at hy_uR0
      simp only [st0, removeCopiesFromState, LocalMatchingState.rightIndexSet, List.mem_toFinset,
        List.mem_map, List.mem_filter, decide_eq_true_eq] at hy_uR0
      rcases hy_uR0 with ⟨e, ⟨he, _⟩, heid⟩
      rw [← hrset]
      simp only [LocalMatchingState.rightIndexSet, List.mem_toFinset, List.mem_map]
      exact ⟨e, he, heid⟩
    have hx_VL : xy.1 ∈ V_L := (Finset.mem_filter.mp hx_uL).1
    have hy_VR : xy.2 ∈ V_R := (Finset.mem_filter.mp hy_uR).1
    have hstrong := strongEdgesOn_mem_of_subsets pts m0 γ lam o V ℓ hxy_strong hx_VL hy_VR
    exact Finset.disjoint_left.mp hdisj hstrong (Finset.mem_product.mpr ⟨hx_uL, hy_uR⟩)

end UL.Proof_clm_5_3_matching_invariant
