import UL.Stmt.lem_C_2
set_option autoImplicit false

namespace UL.Proof.lem_C_2.H1

open UL

/-! ### 1. List and `poolClockTickCount` helpers -/

theorem list_take_succ {α : Type*} (l : List α) (i : ℕ) (hi : i < l.length) :
    l.take (i + 1) = l.take i ++ [l[i]'hi] := by
  induction l generalizing i with
  | nil => simp at hi
  | cons hd tl ih =>
    cases i with
    | zero => simp
    | succ j =>
      simp only [List.take_succ_cons, List.getElem_cons_succ, List.cons_append]
      exact congrArg (hd :: ·) (ih j (Nat.lt_of_succ_lt_succ hi))

theorem poolClockTickCount_append {ι : Type*} (l₁ l₂ : List (PoolUpdateEvent ι)) :
    poolClockTickCount (l₁ ++ l₂) = poolClockTickCount l₁ + poolClockTickCount l₂ := by
  unfold poolClockTickCount
  exact List.countP_append

theorem poolClockTickCount_take_add_drop {ι : Type*} (l : List (PoolUpdateEvent ι)) (i : ℕ) :
    poolClockTickCount (l.take i) + poolClockTickCount (l.drop i) = poolClockTickCount l := by
  rw [← poolClockTickCount_append, List.take_append_drop]

theorem poolClockTickCount_singleton {ι : Type*} (e : PoolUpdateEvent ι) :
    poolClockTickCount [e] = e.ticks := by
  unfold poolClockTickCount PoolUpdateEvent.ticks
  cases hx : e.isClockTick <;> simp [hx]

theorem poolClockTickCount_ofFn_take_succ {ι : Type*} {T : ℕ}
    (ev : Fin T → PoolUpdateEvent ι) (t : Fin T) :
    poolClockTickCount ((List.ofFn ev).take t.succ.val) =
      poolClockTickCount ((List.ofFn ev).take t.castSucc.val) + (ev t).ticks := by
  have hlen : t.val < (List.ofFn ev).length := by
    rw [List.length_ofFn]
    exact t.isLt
  have htake := list_take_succ (List.ofFn ev) t.val hlen
  simp only [Fin.val_succ, Fin.val_castSucc]
  rw [htake, poolClockTickCount_append, poolClockTickCount_singleton, List.getElem_ofFn]

theorem poolClockTickCount_take_mono {ι : Type*} (l : List (PoolUpdateEvent ι))
    {i j : ℕ} (hij : i ≤ j) :
    poolClockTickCount (l.take i) ≤ poolClockTickCount (l.take j) := by
  have h_eq : l.take i = (l.take j).take i := by
    rw [List.take_take, Nat.min_eq_left hij]
  rw [h_eq]
  have h_sum := poolClockTickCount_take_add_drop (l.take j) i
  omega

/-! ### 2. `prefixResidual` and `chainInput` characterization -/

def inPrefixRes {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (pfx : List (OpenedJobLevel d ι)) (i : ι) : Prop :=
  ∀ lv ∈ pfx, pts i ∉ coreBall lv.ball.o lv.ball.V

open Classical in
theorem prefixResidual_eq_filter {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (pfx : List (OpenedJobLevel d ι)) (S : Finset ι) :
    prefixResidual pts pfx S = S.filter (inPrefixRes pts pfx) := by
  induction pfx generalizing S with
  | nil =>
    ext x
    simp [prefixResidual, inPrefixRes]
  | cons hd tl ih =>
    have hcons : prefixResidual pts (hd :: tl) S = prefixResidual pts tl (hd.ball.residual pts S) := rfl
    rw [hcons, ih]
    ext x
    simp only [Finset.mem_filter, ChainNode.residual, nodeResidual, ChainNode.core, nodeCore,
      Finset.mem_sdiff, inPrefixRes, List.mem_cons, forall_eq_or_imp]
    tauto

theorem prefixResidual_append {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (p₁ p₂ : List (OpenedJobLevel d ι)) (S : Finset ι) :
    prefixResidual pts (p₁ ++ p₂) S = prefixResidual pts p₂ (prefixResidual pts p₁ S) := by
  unfold prefixResidual
  exact List.foldl_append

theorem prefixResidual_singleton {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (lv : OpenedJobLevel d ι) (S : Finset ι) :
    prefixResidual pts [lv] S = lv.ball.residual pts S :=
  rfl

theorem chainInput_eq_prefixResidual_take {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (pfx : List (OpenedJobLevel d ι)) (S : Finset ι)
    (j : Fin (pfx.length + 1)) :
    chainInput pts (fun i : Fin pfx.length => (pfx[i.val]'i.isLt).ball) S j =
      prefixResidual pts (pfx.take j.val) S := by
  rcases j with ⟨m, hm⟩
  induction m with
  | zero => rfl
  | succ m ih =>
    have hm_lt : m < pfx.length := Nat.lt_of_succ_lt_succ hm
    have hci :
        chainInput pts (fun i : Fin pfx.length => (pfx[i.val]'i.isLt).ball) S ⟨m + 1, hm⟩ =
          (pfx[m]'hm_lt).ball.residual pts
            (chainInput pts (fun i : Fin pfx.length => (pfx[i.val]'i.isLt).ball) S
              ⟨m, Nat.lt_succ_of_lt hm_lt⟩) := rfl
    rw [hci, ih (Nat.lt_succ_of_lt hm_lt)]
    simp only [list_take_succ pfx m hm_lt, prefixResidual_append, prefixResidual_singleton]

/-! ### 3. `HasNodeAge` and pool update event lemmas -/

theorem hasNodeAge_refl {ι : Type*} (A : Finset ι) : HasNodeAge A A 0 :=
  ⟨fun _ => A, rfl, rfl, fun r => Fin.elim0 r⟩

theorem hasNodeAge_step {ι : Type*} {A B C : Finset ι} {a : ℕ}
    (hAB : HasNodeAge A B a) (hBC : IsInputChange B C) :
    HasNodeAge A C (a + 1) := by
  rcases hAB with ⟨seq, h0, hlast, hstep⟩
  let seq' : Fin (a + 2) → Finset ι := fun j =>
    if hj : j.val < a + 1 then seq ⟨j.val, hj⟩ else C
  refine ⟨seq', ?_, ?_, ?_⟩
  · dsimp only [seq']
    have h0lt : (0 : Fin (a + 2)).val < a + 1 := Nat.zero_lt_succ a
    rw [dif_pos h0lt]
    exact h0
  · dsimp only [seq']
    have hnot : ¬ ((Fin.last (a + 1)).val < a + 1) := by simp
    rw [dif_neg hnot]
  · intro r
    dsimp only [seq']
    have hcs : r.castSucc.val < a + 1 := r.isLt
    rw [dif_pos hcs]
    by_cases hr : r.val < a
    · have hsc : r.succ.val < a + 1 := Nat.succ_lt_succ hr
      rw [dif_pos hsc]
      exact hstep ⟨r.val, hr⟩
    · have hra : r.val = a := by omega
      have hsc_not : ¬ (r.succ.val < a + 1) := by
        simp [Fin.val_succ, hra]
      rw [dif_neg hsc_not]
      have h_eq : (⟨r.castSucc.val, hcs⟩ : Fin (a + 1)) = Fin.last a := by
        ext
        simp [hra]
      rw [h_eq, hlast]
      exact hBC

open Classical in
theorem hasNodeAge_card_bounds {ι : Type*} {P₀ S : Finset ι} {a : ℕ}
    (h : HasNodeAge P₀ S a) :
    (S \ P₀).card ≤ a ∧ (P₀ \ S).card ≤ a ∧ S.card ≤ P₀.card + a := by
  induction a generalizing S with
  | zero =>
    rcases h with ⟨seq, h0, hlast, _⟩
    have hEq : P₀ = S := by
      have : (0 : Fin 1) = Fin.last 0 := rfl
      rw [← h0, ← hlast, this]
    subst hEq
    simp
  | succ t ih =>
    rcases h with ⟨seq, h0, hlast, hstep⟩
    let seq_mid : Fin (t + 1) → Finset ι := fun j => seq j.castSucc
    let S_mid : Finset ι := seq (Fin.last t).castSucc
    have hmid : HasNodeAge P₀ S_mid t := by
      refine ⟨seq_mid, h0, rfl, fun r => ?_⟩
      have hsucc : (r.succ : Fin (t + 1)).castSucc = r.castSucc.succ := by
        ext
        simp
      dsimp only [seq_mid]
      rw [hsucc]
      exact hstep r.castSucc
    rcases ih hmid with ⟨hs1, hs2, hs3⟩
    have hlast_step : IsInputChange S_mid S := by
      have hlast_eq : (Fin.last t).succ = Fin.last (t + 1) := by
        ext
        simp
      have hs := hstep (Fin.last t)
      rwa [hlast_eq, hlast] at hs
    rcases hlast_step with ⟨x, _, rfl⟩ | ⟨x, _, rfl⟩
    · have hsub1 : insert x S_mid \ P₀ ⊆ insert x (S_mid \ P₀) := by
        intro y hy
        simp only [Finset.mem_sdiff, Finset.mem_insert] at hy ⊢
        rcases hy.1 with rfl | hy1
        · exact Or.inl rfl
        · exact Or.inr ⟨hy1, hy.2⟩
      have hsub2 : P₀ \ insert x S_mid ⊆ P₀ \ S_mid := by
        intro y hy
        simp only [Finset.mem_sdiff, Finset.mem_insert] at hy ⊢
        exact ⟨hy.1, fun h => hy.2 (Or.inr h)⟩
      have hc1 := (Finset.card_le_card hsub1).trans (Finset.card_insert_le x (S_mid \ P₀))
      have hc2 := Finset.card_le_card hsub2
      have hc3 := Finset.card_insert_le x S_mid
      omega
    · have hsub1 : S_mid.erase x \ P₀ ⊆ S_mid \ P₀ := by
        intro y hy
        simp only [Finset.mem_sdiff, Finset.mem_erase] at hy ⊢
        exact ⟨hy.1.2, hy.2⟩
      have hsub2 : P₀ \ S_mid.erase x ⊆ insert x (P₀ \ S_mid) := by
        intro y hy
        simp only [Finset.mem_sdiff, Finset.mem_erase, Finset.mem_insert] at hy ⊢
        by_cases hyx : y = x
        · exact Or.inl hyx
        · exact Or.inr ⟨hy.1, fun h => hy.2 ⟨hyx, h⟩⟩
      have hc1 := Finset.card_le_card hsub1
      have hc2 := (Finset.card_le_card hsub2).trans (Finset.card_insert_le x (P₀ \ S_mid))
      have hc3 : (S_mid.erase x).card ≤ S_mid.card := Finset.card_erase_le
      omega

open Classical in
theorem filter_validPoolUpdateEvent {ι : Type*} (P : ι → Prop)
    {S S' : Finset ι} {e : PoolUpdateEvent ι}
    (he : IsValidPoolUpdateEvent S S' e) :
    ((S'.filter P = S.filter P) ∨
      (e.isClockTick = true ∧ IsInputChange (S.filter P) (S'.filter P))) ∧
    (S'.filter P).card ≤ (S.filter P).card + e.ticks ∧
    (S.filter P).card ≤ (S'.filter P).card + e.ticks := by
  cases e with
  | externalInsert id =>
    rcases he with ⟨hid_not, rfl⟩
    simp only [PoolUpdateEvent.isClockTick, PoolUpdateEvent.ticks, ↓reduceIte]
    by_cases hP : P id
    · have hfilt : (insert id S).filter P = insert id (S.filter P) := by
        rw [Finset.filter_insert, if_pos hP]
      rw [hfilt]
      have hid_not_f : id ∉ S.filter P := by
        simp [hid_not]
      refine ⟨Or.inr ⟨trivial, Or.inl ⟨id, hid_not_f, rfl⟩⟩, ?_, ?_⟩
      · exact Finset.card_insert_le id (S.filter P)
      · have hsub : S.filter P ⊆ insert id (S.filter P) := Finset.subset_insert id (S.filter P)
        have hle := Finset.card_le_card hsub
        omega
    · have hfilt : (insert id S).filter P = S.filter P := by
        rw [Finset.filter_insert, if_neg hP]
      rw [hfilt]
      exact ⟨Or.inl rfl, by omega, by omega⟩
  | externalDelete id =>
    rcases he with ⟨hid_in, rfl⟩
    simp only [PoolUpdateEvent.isClockTick, PoolUpdateEvent.ticks, ↓reduceIte]
    by_cases hP : P id
    · have hfilt : (S.erase id).filter P = (S.filter P).erase id := by
        ext x
        simp [and_assoc]
      rw [hfilt]
      have hid_in_f : id ∈ S.filter P := Finset.mem_filter.mpr ⟨hid_in, hP⟩
      have hcard_eq : ((S.filter P).erase id).card + 1 = (S.filter P).card :=
        Finset.card_erase_add_one hid_in_f
      refine ⟨Or.inr ⟨trivial, Or.inr ⟨id, hid_in_f, rfl⟩⟩, by omega, by omega⟩
    · have hfilt : (S.erase id).filter P = S.filter P := by
        ext x
        simp only [Finset.mem_filter, Finset.mem_erase]
        constructor
        · rintro ⟨⟨_, hxS⟩, hxP⟩
          exact ⟨hxS, hxP⟩
        · rintro ⟨hxS, hxP⟩
          refine ⟨⟨?_, hxS⟩, hxP⟩
          rintro rfl
          exact hP hxP
      rw [hfilt]
      exact ⟨Or.inl rfl, by omega, by omega⟩
  | virtualValueDelete =>
    subst he
    simp [PoolUpdateEvent.isClockTick, PoolUpdateEvent.ticks]
  | unaffected =>
    subst he
    simp [PoolUpdateEvent.isClockTick, PoolUpdateEvent.ticks]

open Classical in
theorem hasNodeAge_filter_trajectory {ι : Type*} {T : ℕ}
    (S_root : Fin (T + 1) → Finset ι)
    (ev : Fin T → PoolUpdateEvent ι)
    (h_ev : ∀ t : Fin T, IsValidPoolUpdateEvent (S_root t.castSucc) (S_root t.succ) (ev t))
    (P : ι → Prop) (s₁ s₂ : Fin (T + 1)) (hs : s₁ ≤ s₂) :
    ∃ a : ℕ,
      a ≤ poolClockTickCount ((List.ofFn ev).take s₂.val) -
          poolClockTickCount ((List.ofFn ev).take s₁.val) ∧
      HasNodeAge ((S_root s₁).filter P) ((S_root s₂).filter P) a := by
  rcases s₂ with ⟨k, hk⟩
  change s₁.val ≤ k at hs
  induction k with
  | zero =>
    have hs0 : s₁ = ⟨0, hk⟩ := by
      ext
      exact Nat.eq_zero_of_le_zero hs
    subst hs0
    exact ⟨0, by omega, hasNodeAge_refl _⟩
  | succ k ih =>
    by_cases h_eq : s₁.val = k + 1
    · have hs_eq : s₁ = ⟨k + 1, hk⟩ := by
        ext
        exact h_eq
      subst hs_eq
      exact ⟨0, by omega, hasNodeAge_refl _⟩
    · have hs_le : s₁.val ≤ k := by omega
      have hk_lt_T : k < T := Nat.lt_of_succ_lt_succ hk
      let u : Fin T := ⟨k, hk_lt_T⟩
      rcases ih (Nat.lt_succ_of_lt hk_lt_T) hs_le with ⟨a₀, ha₀_le, ha₀_age⟩
      have h_u_cs : (⟨k, Nat.lt_succ_of_lt hk_lt_T⟩ : Fin (T + 1)) = u.castSucc := rfl
      have h_u_sc : (⟨k + 1, hk⟩ : Fin (T + 1)) = u.succ := rfl
      rw [h_u_cs] at ha₀_age ha₀_le
      rw [h_u_sc]
      have h_mono :
          poolClockTickCount ((List.ofFn ev).take s₁.val) ≤
            poolClockTickCount ((List.ofFn ev).take u.castSucc.val) :=
        poolClockTickCount_take_mono (List.ofFn ev) hs_le
      have h_tk := poolClockTickCount_ofFn_take_succ ev u
      rcases (filter_validPoolUpdateEvent P (h_ev u)).1 with h_same | ⟨htick, hchg⟩
      · rw [h_same]
        exact ⟨a₀, by omega, ha₀_age⟩
      · have hticks_one : (ev u).ticks = 1 := by
          unfold PoolUpdateEvent.ticks
          simp [htick]
        exact ⟨a₀ + 1, by omega, hasNodeAge_step ha₀_age hchg⟩

/-! ### 4. Core fallback, contraction, and gate-slack arithmetic -/

theorem cutoff_alpha_sq_lb {d n : ℕ} {α C : ℝ} {K₀ L : ℕ}
    (hα_pos : 0 < α)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L) :
    (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) ≤ α ^ 2 * (L : ℝ) := by
  have h1 : (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ ≤ (L : ℝ) := hL.1
  have hα2 : 0 < α ^ 2 := sq_pos_of_pos hα_pos
  have hmul := mul_le_mul_of_nonneg_left h1 (le_of_lt hα2)
  have hcancel : α ^ 2 * ((2 : ℝ) ^ 20 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹) =
      (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) := by
    field_simp [ne_of_gt hα2]
  linarith

theorem cutoff_L_pos {d n : ℕ} {α C : ℝ} {K₀ L : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L) :
    1 ≤ L := by
  have h1 := cutoff_alpha_sq_lb hα_pos hL
  have hα2_le : α ^ 2 ≤ 1 := by nlinarith
  have hL_nonneg : 0 ≤ (L : ℝ) := Nat.cast_nonneg L
  have h2 : α ^ 2 * (L : ℝ) ≤ 1 * (L : ℝ) :=
    mul_le_mul_of_nonneg_right hα2_le hL_nonneg
  unfold scheduleCStar at h1
  have h3 : (1 : ℝ) ≤ (L : ℝ) := by norm_num at h1; linarith
  exact_mod_cast h3

open Classical in
theorem applyBirthCoreFallback_passes {d : ℕ} {ι : Type*}
    {α : ℝ} (hα_le : α ≤ 1)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_birth : Finset ι) (res : SampledCenterResult d) (ball : ChainNode d)
    (hvalid : IsValidOpenedLevelBall α pts S_birth res ball) :
    PassesBirthCoreCheck α pts ball S_birth := by
  rcases hvalid with ⟨prov, _, rfl⟩
  unfold applyBirthCoreFallback
  by_cases hchk : PassesBirthCoreCheck α pts prov S_birth
  · simp [hchk]
  · simp only [hchk, ↓reduceIte]
    unfold PassesBirthCoreCheck maxBirthRadiusBall ChainNode.core nodeCore
    have hfilt :
        S_birth.filter (fun i => pts i ∈ coreBall prov.o ((nodeMaxRadius pts prov.o S_birth) ^ 2)) =
          S_birth := by
      apply Finset.filter_eq_self.mpr
      intro x hx
      have hne : S_birth.Nonempty := ⟨x, hx⟩
      have hle : ‖pts x - prov.o‖ ≤ nodeMaxRadius pts prov.o S_birth := by
        unfold nodeMaxRadius
        rw [dif_pos hne]
        exact Finset.le_sup' (fun i => ‖pts i - prov.o‖) hx
      have hmax_nonneg : 0 ≤ nodeMaxRadius pts prov.o S_birth :=
        le_trans (norm_nonneg _) hle
      unfold coreBall
      rw [Metric.mem_closedBall, dist_eq_norm, Real.sqrt_sq hmax_nonneg]
      exact hle
    rw [hfilt]
    have hm_nonneg : 0 ≤ (S_birth.card : ℝ) := Nat.cast_nonneg _
    have hmul : α * (S_birth.card : ℝ) ≤ 1 * (S_birth.card : ℝ) :=
      mul_le_mul_of_nonneg_right hα_le hm_nonneg
    linarith

open Classical in
theorem birth_residual_card_le {d : ℕ} {ι : Type*}
    {α : ℝ} (pts : ι → EuclideanSpace ℝ (Fin d))
    (ball : ChainNode d) (P₀ : Finset ι)
    (hcore : PassesBirthCoreCheck α pts ball P₀) :
    ((ball.residual pts P₀).card : ℝ) ≤ (1 - α / 2) * (P₀.card : ℝ) := by
  have hsum_nat : (ball.residual pts P₀).card + (ball.core pts P₀).card = P₀.card :=
    Finset.card_sdiff_add_card_eq_card (Finset.filter_subset _ P₀)
  have hsum : ((ball.residual pts P₀).card : ℝ) + ((ball.core pts P₀).card : ℝ) = (P₀.card : ℝ) := by
    exact_mod_cast hsum_nat
  unfold PassesBirthCoreCheck at hcore
  linarith

open Classical in
theorem aged_residual_card_le {d : ℕ} {ι : Type*}
    {α : ℝ} (pts : ι → EuclideanSpace ℝ (Fin d))
    (ball : ChainNode d) (P₀ S : Finset ι) {a : ℕ}
    (hcore : PassesBirthCoreCheck α pts ball P₀)
    (hage : HasNodeAge P₀ S a) :
    ((ball.residual pts S).card : ℝ) ≤ (1 - α / 2) * (P₀.card : ℝ) + (a : ℝ) := by
  have hsub : ball.residual pts S ⊆ ball.residual pts P₀ ∪ (S \ P₀) := by
    intro x hx
    simp only [ChainNode.residual, nodeResidual, nodeCore,
      Finset.mem_sdiff, Finset.mem_filter, Finset.mem_union] at hx ⊢
    have hnot : pts x ∉ coreBall ball.o ball.V := fun hc => hx.2 ⟨hx.1, hc⟩
    by_cases hx0 : x ∈ P₀
    · exact Or.inl ⟨hx0, fun hc => hnot hc.2⟩
    · exact Or.inr ⟨hx.1, hx0⟩
  have hcard_nat : (ball.residual pts S).card ≤ (ball.residual pts P₀).card + (S \ P₀).card :=
    (Finset.card_le_card hsub).trans (Finset.card_union_le _ _)
  have hs_diff : (S \ P₀).card ≤ a := (hasNodeAge_card_bounds hage).1
  have hcard_a : (ball.residual pts S).card ≤ (ball.residual pts P₀).card + a := by omega
  have hcard_r : ((ball.residual pts S).card : ℝ) ≤ ((ball.residual pts P₀).card : ℝ) + (a : ℝ) := by
    exact_mod_cast hcard_a
  have hbirth := birth_residual_card_le pts ball P₀ hcore
  linarith

open Classical in
theorem birth_to_birth_contraction {d : ℕ} {ι : Type*}
    {α : ℝ} (hα_pos : 0 < α)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (ball : ChainNode d) (P₀ S : Finset ι) {a : ℕ}
    (hcore : PassesBirthCoreCheck α pts ball P₀)
    (hage : HasNodeAge P₀ S a)
    (ha_le : (a : ℝ) ≤ α * (P₀.card : ℝ) / (scheduleCStar : ℝ)) :
    ((ball.residual pts S).card : ℝ) ≤ (1 - α / 4) * (P₀.card : ℝ) := by
  have h1 := aged_residual_card_le pts ball P₀ S hcore hage
  have hαm : 0 ≤ α * (P₀.card : ℝ) := mul_nonneg (le_of_lt hα_pos) (Nat.cast_nonneg _)
  unfold scheduleCStar at ha_le
  norm_num at ha_le
  linarith

open Classical in
theorem current_input_contraction {d : ℕ} {ι : Type*}
    {α : ℝ} (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (ball : ChainNode d) (P₀ S : Finset ι) {a : ℕ}
    (hcore : PassesBirthCoreCheck α pts ball P₀)
    (hage : HasNodeAge P₀ S a)
    (ha_le : (a : ℝ) ≤ α * (P₀.card : ℝ) / (scheduleCStar : ℝ)) :
    ((ball.residual pts S).card : ℝ) ≤ (1 - α / 4) * (S.card : ℝ) := by
  have hsub_core : ball.core pts P₀ ⊆ ball.core pts S ∪ (P₀ \ S) := by
    intro x hx
    simp only [ChainNode.core, nodeCore, Finset.mem_filter, Finset.mem_union,
      Finset.mem_sdiff] at hx ⊢
    by_cases hxs : x ∈ S
    · exact Or.inl ⟨hxs, hx.2⟩
    · exact Or.inr ⟨hx.1, hxs⟩
  have hcore_nat : (ball.core pts P₀).card ≤ (ball.core pts S).card + (P₀ \ S).card :=
    (Finset.card_le_card hsub_core).trans (Finset.card_union_le _ _)
  rcases hasNodeAge_card_bounds hage with ⟨_, hp0_s, hs_le_nat⟩
  have hcore_a_nat : (ball.core pts P₀).card ≤ (ball.core pts S).card + a := by omega
  have hcore_a : ((ball.core pts P₀).card : ℝ) ≤ ((ball.core pts S).card : ℝ) + (a : ℝ) := by
    exact_mod_cast hcore_a_nat
  have hs_le : (S.card : ℝ) ≤ (P₀.card : ℝ) + (a : ℝ) := by exact_mod_cast hs_le_nat
  have hsum_nat : (ball.residual pts S).card + (ball.core pts S).card = S.card :=
    Finset.card_sdiff_add_card_eq_card (Finset.filter_subset _ S)
  have hsum : ((ball.residual pts S).card : ℝ) + ((ball.core pts S).card : ℝ) = (S.card : ℝ) := by
    exact_mod_cast hsum_nat
  unfold PassesBirthCoreCheck at hcore
  unfold scheduleCStar at ha_le
  norm_num at ha_le
  have hαs : α * (S.card : ℝ) ≤ α * ((P₀.card : ℝ) + (a : ℝ)) :=
    mul_le_mul_of_nonneg_left hs_le (le_of_lt hα_pos)
  have hαa : α * (a : ℝ) ≤ 1 * (a : ℝ) :=
    mul_le_mul_of_nonneg_right hα_le (Nat.cast_nonneg a)
  have hαm : 0 ≤ α * (P₀.card : ℝ) := mul_nonneg (le_of_lt hα_pos) (Nat.cast_nonneg _)
  linarith

open Classical in
theorem gate_closed_during_build {d n : ℕ} {ι : Type*}
    {α C : ℝ} {K₀ L : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (ball : ChainNode d) (P₀ S : Finset ι)
    {r_open r_now trueAge : ℕ}
    (hlarge : IsLargeResidualLevel L P₀.card)
    (hcore : PassesBirthCoreCheck α pts ball P₀)
    (hr_lb : α * (P₀.card : ℝ) / (scheduleCStar : ℝ) - 2 < (r_open : ℝ))
    (hr_le : r_now ≤ r_open)
    (hΔ_le : ((r_open - r_now : ℕ) : ℝ) ≤
      α ^ 2 * (P₀.card : ℝ) / (64 * (scheduleCStar : ℝ)))
    (hage_le : trueAge ≤ r_open - r_now)
    (hage : HasNodeAge P₀ S trueAge) :
    ¬ CanOpenResidualLevel α r_now (ball.residual pts S).card := by
  unfold CanOpenResidualLevel
  set Δr : ℕ := r_open - r_now
  have hr_sub : (r_now : ℝ) = (r_open : ℝ) - (Δr : ℝ) := by
    have hnat : r_now + Δr = r_open := Nat.add_sub_of_le hr_le
    have hcast : (r_now : ℝ) + (Δr : ℝ) = (r_open : ℝ) := by exact_mod_cast hnat
    linarith
  have hm_gt_L : (L : ℝ) ≤ (P₀.card : ℝ) := by
    unfold IsLargeResidualLevel at hlarge
    have hnat : L ≤ P₀.card := by omega
    exact_mod_cast hnat
  have hcut := cutoff_alpha_sq_lb hα_pos hL
  have hα2m_lb : (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) ≤ α ^ 2 * (P₀.card : ℝ) := by
    have hmul := mul_le_mul_of_nonneg_left hm_gt_L (sq_nonneg α)
    linarith
  have hm'_le := aged_residual_card_le pts ball P₀ S hcore hage
  have htrue_le : (trueAge : ℝ) ≤ (Δr : ℝ) := by exact_mod_cast hage_le
  have hm'_Δ : ((ball.residual pts S).card : ℝ) ≤ (1 - α / 2) * (P₀.card : ℝ) + (Δr : ℝ) := by
    linarith
  have hα_mul : α * ((ball.residual pts S).card : ℝ) ≤
      α * ((1 - α / 2) * (P₀.card : ℝ) + (Δr : ℝ)) :=
    mul_le_mul_of_nonneg_left hm'_Δ (le_of_lt hα_pos)
  have hαΔ : α * (Δr : ℝ) ≤ 1 * (Δr : ℝ) :=
    mul_le_mul_of_nonneg_right hα_le (Nat.cast_nonneg Δr)
  have h_expand : α * ((1 - α / 2) * (P₀.card : ℝ) + (Δr : ℝ)) =
      α * (P₀.card : ℝ) - (α ^ 2 * (P₀.card : ℝ)) / 2 + α * (Δr : ℝ) := by ring
  unfold scheduleCStar at hr_lb hΔ_le hα2m_lb ⊢
  norm_num at hr_lb hΔ_le hα2m_lb ⊢
  linarith

theorem leaf_close_lyapunov {α : ℝ} {L r m : ℕ}
    (hα_le : α ≤ 1)
    (hleaf : IsResidualLeafSize L m)
    (hgate : CanOpenResidualLevel α r m) :
    m + r ≤ 3 * L + 2 := by
  unfold IsResidualLeafSize at hleaf
  unfold CanOpenResidualLevel scheduleCStar at hgate
  have hm_cast : (m : ℝ) ≤ 2 * (L : ℝ) + 1 := by exact_mod_cast hleaf
  have hαm : α * (m : ℝ) ≤ 1 * (m : ℝ) :=
    mul_le_mul_of_nonneg_right hα_le (Nat.cast_nonneg m)
  have hr_lt : (r : ℝ) < ((L + 1 : ℕ) : ℝ) := by
    push_cast
    norm_num at hgate
    linarith
  have hr_nat : r < L + 1 := Nat.cast_lt.mp hr_lt
  omega

theorem deadline_gate_bounds {α : ℝ} (hα_pos : 0 < α) (m₀ : ℕ) :
    CanOpenResidualLevel α (jobDeadlineTicks α m₀) m₀ ∧
    α * (m₀ : ℝ) / (scheduleCStar : ℝ) - 2 < ((jobDeadlineTicks α m₀ : ℕ) : ℝ) := by
  unfold CanOpenResidualLevel jobDeadlineTicks
  set x : ℝ := α * (m₀ : ℝ) / (scheduleCStar : ℝ)
  have hx_nonneg : 0 ≤ x := by
    dsimp only [x]
    unfold scheduleCStar
    positivity
  have hle : (⌊x⌋₊ : ℝ) ≤ x := Nat.floor_le hx_nonneg
  have hlt : x - 1 < (⌊x⌋₊ : ℝ) := Nat.sub_one_lt_floor x
  exact ⟨hle, by linarith⟩

theorem pre_tick_gate_lb {α : ℝ} (hα_pos : 0 < α) (hα_le : α ≤ 1)
    {r_old r_pre m_old m_pre : ℕ}
    (hr_eq : r_old = r_pre + 1)
    (hm_le : m_pre ≤ m_old + 1)
    (hnot_open : ¬ CanOpenResidualLevel α r_old m_old) :
    α * (m_pre : ℝ) / (scheduleCStar : ℝ) - 2 < (r_pre : ℝ) := by
  unfold CanOpenResidualLevel at hnot_open
  push_neg at hnot_open
  have hr_cast : (r_old : ℝ) = (r_pre : ℝ) + 1 := by exact_mod_cast hr_eq
  have hm_cast : (m_pre : ℝ) ≤ (m_old : ℝ) + 1 := by exact_mod_cast hm_le
  have hαm : α * ((m_pre : ℝ) - 1) ≤ α * (m_old : ℝ) :=
    mul_le_mul_of_nonneg_left (by linarith) (le_of_lt hα_pos)
  unfold scheduleCStar at hnot_open ⊢
  norm_num at hnot_open ⊢
  linarith

/-! ### 5. `PrefixEvolves`, `MarkReadySummary`, and `JobWithinTickChain` splitting -/

def LevelEvolves {d : ℕ} {ι : Type} (lv₁ lv₂ : OpenedJobLevel d ι) : Prop :=
  lv₂.birthSnapshot = lv₁.birthSnapshot ∧
  lv₂.ball = lv₁.ball ∧
  lv₂.indexMode = lv₁.indexMode ∧
  (lv₁.backgroundReady = true → lv₂.backgroundReady = true)

def PrefixEvolves {d : ℕ} {ι : Type} (p₁ p₂ : List (OpenedJobLevel d ι)) : Prop :=
  p₁.length ≤ p₂.length ∧
  ∀ (i : ℕ) (h₁ : i < p₁.length) (h₂ : i < p₂.length),
    LevelEvolves (p₁[i]'h₁) (p₂[i]'h₂)

theorem LevelEvolves.refl {d : ℕ} {ι : Type} (lv : OpenedJobLevel d ι) :
    LevelEvolves lv lv :=
  ⟨rfl, rfl, rfl, id⟩

theorem LevelEvolves.trans {d : ℕ} {ι : Type}
    {lv₁ lv₂ lv₃ : OpenedJobLevel d ι}
    (h₁₂ : LevelEvolves lv₁ lv₂) (h₂₃ : LevelEvolves lv₂ lv₃) :
    LevelEvolves lv₁ lv₃ :=
  ⟨h₂₃.1.trans h₁₂.1, h₂₃.2.1.trans h₁₂.2.1, h₂₃.2.2.1.trans h₁₂.2.2.1,
    fun h => h₂₃.2.2.2 (h₁₂.2.2.2 h)⟩

theorem PrefixEvolves.refl {d : ℕ} {ι : Type} (p : List (OpenedJobLevel d ι)) :
    PrefixEvolves p p :=
  ⟨le_rfl, fun _ _ _ => LevelEvolves.refl _⟩

theorem PrefixEvolves.trans {d : ℕ} {ι : Type}
    {p₁ p₂ p₃ : List (OpenedJobLevel d ι)}
    (h₁₂ : PrefixEvolves p₁ p₂) (h₂₃ : PrefixEvolves p₂ p₃) :
    PrefixEvolves p₁ p₃ := by
  refine ⟨le_trans h₁₂.1 h₂₃.1, fun i h₁ h₃ => ?_⟩
  have h₂ : i < p₂.length := Nat.lt_of_lt_of_le h₁ h₁₂.1
  exact LevelEvolves.trans (h₁₂.2 i h₁ h₂) (h₂₃.2 i h₂ h₃)

theorem prefixResidual_eq_of_balls_eq {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (p₁ p₂ : List (OpenedJobLevel d ι)) (S : Finset ι)
    (hlen : p₁.length = p₂.length)
    (hballs : ∀ (i : ℕ) (h₁ : i < p₁.length) (h₂ : i < p₂.length),
      (p₂[i]'h₂).ball = (p₁[i]'h₁).ball) :
    prefixResidual pts p₁ S = prefixResidual pts p₂ S := by
  classical
  rw [prefixResidual_eq_filter, prefixResidual_eq_filter]
  apply congrArg (S.filter ·)
  funext x
  apply propext
  simp only [inPrefixRes, List.mem_iff_getElem]
  constructor
  · intro h lv ⟨i, hi₂, hlv⟩
    have hi₁ : i < p₁.length := by omega
    subst hlv
    rw [hballs i hi₁ hi₂]
    exact h (p₁[i]'hi₁) ⟨i, hi₁, rfl⟩
  · intro h lv ⟨i, hi₁, hlv⟩
    have hi₂ : i < p₂.length := by omega
    subst hlv
    rw [← hballs i hi₁ hi₂]
    exact h (p₂[i]'hi₂) ⟨i, hi₂, rfl⟩

theorem prefixResidual_take_eq_of_prefixEvolves {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {p₁ p₂ : List (OpenedJobLevel d ι)} (S : Finset ι)
    (hevol : PrefixEvolves p₁ p₂) (k : ℕ) (hk : k ≤ p₁.length) :
    prefixResidual pts (p₁.take k) S = prefixResidual pts (p₂.take k) S := by
  have hk₂ : k ≤ p₂.length := le_trans hk hevol.1
  apply prefixResidual_eq_of_balls_eq pts (p₁.take k) (p₂.take k) S
  · simp [Nat.min_eq_left hk, Nat.min_eq_left hk₂]
  · intro i hi₁ hi₂
    have hi_k : i < k := by
      simp [Nat.min_eq_left hk] at hi₁
      exact hi₁
    simp only [List.getElem_take]
    exact (hevol.2 i (Nat.lt_of_lt_of_le hi_k hk) (Nat.lt_of_lt_of_le hi_k hk₂)).2.1

def MarkReadySummary {d : ℕ} {ι : Type} (j₁ j₂ : PendingReplacementJob d ι) : Prop :=
  j₂.deadlineTicks = j₁.deadlineTicks ∧
  j₂.remainingTicks = j₁.remainingTicks ∧
  j₂.currentResidual = j₁.currentResidual ∧
  j₂.closedAsLeaf = j₁.closedAsLeaf ∧
  j₂.completedPrefix.length = j₁.completedPrefix.length ∧
  PrefixEvolves j₁.completedPrefix j₂.completedPrefix

theorem MarkReadySummary.refl {d : ℕ} {ι : Type} (j : PendingReplacementJob d ι) :
    MarkReadySummary j j :=
  ⟨rfl, rfl, rfl, rfl, rfl, PrefixEvolves.refl _⟩

theorem MarkReadySummary.trans {d : ℕ} {ι : Type}
    {j₁ j₂ j₃ : PendingReplacementJob d ι}
    (h₁₂ : MarkReadySummary j₁ j₂) (h₂₃ : MarkReadySummary j₂ j₃) :
    MarkReadySummary j₁ j₃ :=
  ⟨h₂₃.1.trans h₁₂.1, h₂₃.2.1.trans h₁₂.2.1, h₂₃.2.2.1.trans h₁₂.2.2.1,
    h₂₃.2.2.2.1.trans h₁₂.2.2.2.1, h₂₃.2.2.2.2.1.trans h₁₂.2.2.2.2.1,
    PrefixEvolves.trans h₁₂.2.2.2.2.2 h₂₃.2.2.2.2.2⟩

theorem markReadyStep_summary {d : ℕ} {ι : Type}
    {j₁ j₂ : PendingReplacementJob d ι} (h : JobMarkReadyStep j₁ j₂) :
    MarkReadySummary j₁ j₂ := by
  rcases h with ⟨hd, hr, hc, hcl, hf2⟩
  have hlen : j₁.completedPrefix.length = j₂.completedPrefix.length := hf2.length_eq
  rw [List.forall₂_iff_get] at hf2
  refine ⟨hd, hr, hc, hcl, hlen.symm, ⟨le_of_eq hlen, fun i hi₁ hi₂ => ?_⟩⟩
  exact hf2.2 i hi₁ hi₂

theorem gateStep_preserves_clocks_and_prefix {d : ℕ} {ι : Type}
    {α : ℝ} {L : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d)}
    {j₁ j₂ : PendingReplacementJob d ι} (h : JobGateStep α L pts j₁ j₂) :
    j₂.deadlineTicks = j₁.deadlineTicks ∧
    j₂.remainingTicks = j₁.remainingTicks ∧
    PrefixEvolves j₁.completedPrefix j₂.completedPrefix := by
  rcases h with ⟨_, _, _, hact⟩
  rcases hact with ⟨_, rfl⟩ | ⟨_, _, ball, mode, _, rfl⟩
  · exact ⟨rfl, rfl, PrefixEvolves.refl _⟩
  · refine ⟨rfl, rfl, ⟨by simp [openLargeLevelInJob], fun i hi₁ hi₂ => ?_⟩⟩
    simp only [openLargeLevelInJob] at hi₂ ⊢
    rw [List.getElem_append_left hi₁]
    exact LevelEvolves.refl _

theorem chain_preserves_clocks_and_prefix {d : ℕ} {ι : Type}
    {α : ℝ} {L : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d)}
    {j₁ j₂ : PendingReplacementJob d ι} (h : JobWithinTickChain α L pts j₁ j₂) :
    j₂.deadlineTicks = j₁.deadlineTicks ∧
    j₂.remainingTicks = j₁.remainingTicks ∧
    PrefixEvolves j₁.completedPrefix j₂.completedPrefix := by
  induction h with
  | refl j => exact ⟨rfl, rfl, PrefixEvolves.refl _⟩
  | markReady hs _ ih =>
    have hm := markReadyStep_summary hs
    exact ⟨ih.1.trans hm.1, ih.2.1.trans hm.2.1, PrefixEvolves.trans hm.2.2.2.2.2 ih.2.2⟩
  | gate hg _ ih =>
    have hp := gateStep_preserves_clocks_and_prefix hg
    exact ⟨ih.1.trans hp.1, ih.2.1.trans hp.2.1, PrefixEvolves.trans hp.2.2 ih.2.2⟩

theorem chain_split_first_gate {d : ℕ} {ι : Type}
    {α : ℝ} {L : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d)}
    {j_pre j_post : PendingReplacementJob d ι}
    (h : JobWithinTickChain α L pts j_pre j_post) :
    MarkReadySummary j_pre j_post ∨
      ∃ j₁ j₂ : PendingReplacementJob d ι,
        MarkReadySummary j_pre j₁ ∧
        JobGateStep α L pts j₁ j₂ ∧
        JobWithinTickChain α L pts j₂ j_post := by
  induction h with
  | refl j => exact Or.inl (MarkReadySummary.refl j)
  | markReady hs _ ih =>
    have hm := markReadyStep_summary hs
    rcases ih with hsum | ⟨j₁, j₂, hsum, hgate, hrest⟩
    · exact Or.inl (MarkReadySummary.trans hm hsum)
    · exact Or.inr ⟨j₁, j₂, MarkReadySummary.trans hm hsum, hgate, hrest⟩
  | gate hg hrest _ =>
    exact Or.inr ⟨_, _, MarkReadySummary.refl _, hg, hrest⟩

theorem chain_of_closed {d : ℕ} {ι : Type}
    {α : ℝ} {L : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d)}
    {j₁ j₂ : PendingReplacementJob d ι}
    (h : JobWithinTickChain α L pts j₁ j₂)
    (hcl : j₁.closedAsLeaf = true) :
    MarkReadySummary j₁ j₂ := by
  induction h with
  | refl j => exact MarkReadySummary.refl j
  | markReady hs _ ih =>
    have hm := markReadyStep_summary hs
    have hcl2 : _ = true := hm.2.2.2.1.trans hcl
    exact MarkReadySummary.trans hm (ih hcl2)
  | gate hg _ _ =>
    have hfalse : _ = false := hg.1
    rw [hcl] at hfalse
    cases hfalse

theorem chain_of_gate_closed {d : ℕ} {ι : Type}
    {α : ℝ} {L : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d)}
    {j₁ j₂ : PendingReplacementJob d ι}
    (h : JobWithinTickChain α L pts j₁ j₂)
    (hng : ¬ CanOpenResidualLevel α j₁.remainingTicks j₁.currentResidual.card) :
    MarkReadySummary j₁ j₂ := by
  induction h with
  | refl j => exact MarkReadySummary.refl j
  | @markReady j_a j_b j_c hs _ ih =>
    have hm := markReadyStep_summary hs
    have hng2 : ¬ CanOpenResidualLevel α j_b.remainingTicks j_b.currentResidual.card := by
      rw [hm.2.1, hm.2.2.1]
      exact hng
    exact MarkReadySummary.trans hm (ih hng2)
  | gate hg _ _ =>
    exact False.elim (hng hg.2.2.1)

end UL.Proof.lem_C_2.H1
