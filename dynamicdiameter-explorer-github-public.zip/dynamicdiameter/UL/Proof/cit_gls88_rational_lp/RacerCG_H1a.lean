import Mathlib
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

theorem real_abs_int_eq_natAbs (z : ℤ) : |(z : ℝ)| = ((z.natAbs : ℕ) : ℝ) := by
  cases z with
  | ofNat m =>
      simp only [Int.ofNat_eq_natCast, Int.cast_natCast, Int.natAbs_natCast]
      exact abs_of_nonneg (Nat.cast_nonneg m)
  | negSucc m =>
      rw [Int.negSucc_eq]
      simp only [Int.natAbs_neg, Int.cast_neg, abs_neg]
      have hm : (((m : ℤ) + 1).natAbs : ℕ) = m + 1 := by omega
      rw [hm]
      push_cast
      exact abs_of_nonneg (by positivity)


/-! ### 1. Algebraic Farkas' Lemma via Fourier-Motzkin Elimination -/

/-- Algebraic Farkas' Lemma over `ℝ` for an arbitrary finite constraint index type `ι`. -/
theorem farkas_le_fintype (n : ℕ) :
    ∀ {ι : Type} [Fintype ι] [DecidableEq ι] (M : ι → Fin n → ℝ) (d : ι → ℝ),
      (∃ x : Fin n → ℝ, ∀ i : ι, ∑ j : Fin n, M i j * x j ≤ d i) ∨
      (∃ y : ι → ℝ, (∀ i : ι, 0 ≤ y i) ∧
        (∀ j : Fin n, ∑ i : ι, y i * M i j = 0) ∧
        ∑ i : ι, y i * d i < 0) := by
  induction n with
  | zero =>
      intro ι _ _ M d
      by_cases h : ∀ i : ι, 0 ≤ d i
      · left
        exact ⟨Fin.elim0, fun i => by simp [h i]⟩
      · right
        push_neg at h
        rcases h with ⟨i₀, hi₀⟩
        refine ⟨fun i => if i = i₀ then 1 else 0, ?_, ?_, ?_⟩
        · intro i
          by_cases hik : i = i₀ <;> simp [hik]
        · intro j
          exact Fin.elim0 j
        · simp [hi₀]
  | succ n ih =>
      intro ι _ _ M d
      let c : ι → ℝ := fun i => M i (Fin.last n)
      let M' : (ι × ι) ⊕ ι → Fin n → ℝ := fun k j =>
        match k with
        | Sum.inl (p, q) =>
            if 0 < c p ∧ c q < 0 then (-c q) * M p j.castSucc + c p * M q j.castSucc else 0
        | Sum.inr z =>
            if c z = 0 then M z j.castSucc else 0
      let d' : (ι × ι) ⊕ ι → ℝ := fun k =>
        match k with
        | Sum.inl (p, q) =>
            if 0 < c p ∧ c q < 0 then (-c q) * d p + c p * d q else 0
        | Sum.inr z =>
            if c z = 0 then d z else 0
      rcases ih M' d' with ⟨x', hx'⟩ | ⟨y', hy'_nn, hy'_zero, hy'_neg⟩
      · left
        let R : ι → ℝ := fun i => ∑ j : Fin n, M i j.castSucc * x' j
        have hPair : ∀ p q : ι, 0 < c p → c q < 0 →
            (R q - d q) / (-c q) ≤ (d p - R p) / c p := by
          intro p q hp hq
          have hk := hx' (Sum.inl (p, q))
          simp only [M', d', hp, hq, and_self, ↓reduceIte] at hk
          have hsum : (∑ j : Fin n, ((-c q) * M p j.castSucc + c p * M q j.castSucc) * x' j) =
              (-c q) * R p + c p * R q := by
            simp only [R, add_mul, mul_assoc, Finset.sum_add_distrib, ← Finset.mul_sum]
          rw [hsum] at hk
          have hcq : 0 < -c q := neg_pos.mpr hq
          rw [div_le_div_iff₀ hcq hp]
          linarith
        have hZero : ∀ z : ι, c z = 0 → R z ≤ d z := by
          intro z hz
          have hk := hx' (Sum.inr z)
          simpa [M', d', hz] using hk
        let Pos : Finset ι := Finset.univ.filter (fun p => 0 < c p)
        let Neg : Finset ι := Finset.univ.filter (fun q => c q < 0)
        let xLast : ℝ :=
          if hPos : Pos.Nonempty then
            Pos.inf' hPos (fun p => (d p - R p) / c p)
          else if hNeg : Neg.Nonempty then
            Neg.sup' hNeg (fun q => (R q - d q) / (-c q))
          else 0
        refine ⟨Fin.snoc x' xLast, fun i => ?_⟩
        rw [Fin.sum_univ_castSucc]
        simp only [Fin.snoc_castSucc, Fin.snoc_last]
        change R i + c i * xLast ≤ d i
        rcases lt_trichotomy (c i) 0 with hci_neg | hci_zero | hci_pos
        · have hiNeg : i ∈ Neg := Finset.mem_filter.mpr ⟨Finset.mem_univ i, hci_neg⟩
          have hcq : 0 < -c i := neg_pos.mpr hci_neg
          have hxLast_ge : (R i - d i) / (-c i) ≤ xLast := by
            by_cases hPos : Pos.Nonempty
            · simp only [xLast, hPos, ↓reduceDIte, Finset.le_inf'_iff]
              intro p hp
              exact hPair p i (Finset.mem_filter.mp hp).2 hci_neg
            · have hNeg : Neg.Nonempty := ⟨i, hiNeg⟩
              simp only [xLast, hPos, hNeg, ↓reduceDIte]
              exact Finset.le_sup' (fun q => (R q - d q) / (-c q)) hiNeg
          have hmul := mul_le_mul_of_nonneg_left hxLast_ge hcq.le
          rw [mul_div_cancel₀ _ hcq.ne'] at hmul
          linarith
        · rw [hci_zero, zero_mul, add_zero]
          exact hZero i hci_zero
        · have hiPos : i ∈ Pos := Finset.mem_filter.mpr ⟨Finset.mem_univ i, hci_pos⟩
          have hPos : Pos.Nonempty := ⟨i, hiPos⟩
          have hxLast_le : xLast ≤ (d i - R i) / c i := by
            simp only [xLast, hPos, ↓reduceDIte]
            exact Finset.inf'_le (fun p => (d p - R p) / c p) hiPos
          have hmul := mul_le_mul_of_nonneg_left hxLast_le hci_pos.le
          rw [mul_div_cancel₀ _ hci_pos.ne'] at hmul
          linarith
      · right
        let yPair : ι → ι → ℝ := fun p q => y' (Sum.inl (p, q))
        let yZero : ι → ℝ := fun z => y' (Sum.inr z)
        let y : ι → ℝ := fun i =>
          (if 0 < c i then ∑ q : ι, (if c q < 0 then yPair i q * (-c q) else 0) else 0) +
          (if c i < 0 then ∑ p : ι, (if 0 < c p then yPair p i * c p else 0) else 0) +
          (if c i = 0 then yZero i else 0)
        have hy_nn : ∀ i : ι, 0 ≤ y i := by
          intro i
          dsimp only [y]
          refine add_nonneg (add_nonneg ?_ ?_) ?_
          · split_ifs with h1
            · refine Finset.sum_nonneg (fun q _ => ?_)
              split_ifs with h2
              · exact mul_nonneg (hy'_nn _) (neg_nonneg.mpr h2.le)
              · exact le_rfl
            · exact le_rfl
          · split_ifs with h1
            · refine Finset.sum_nonneg (fun p _ => ?_)
              split_ifs with h2
              · exact mul_nonneg (hy'_nn _) h2.le
              · exact le_rfl
            · exact le_rfl
          · split_ifs
            · exact hy'_nn _
            · exact le_rfl
        have hLinear : ∀ v : ι → ℝ,
            ∑ i : ι, y i * v i =
              (∑ p : ι, ∑ q : ι,
                if 0 < c p ∧ c q < 0 then yPair p q * ((-c q) * v p + c p * v q) else 0) +
              (∑ z : ι, if c z = 0 then yZero z * v z else 0) := by
          intro v
          simp only [y, add_mul, Finset.sum_add_distrib]
          congr 1
          · have h1 : (∑ p : ι, (if 0 < c p then ∑ q : ι,
                if c q < 0 then yPair p q * (-c q) else 0 else 0) * v p) =
                ∑ p : ι, ∑ q : ι,
                  if 0 < c p ∧ c q < 0 then yPair p q * ((-c q) * v p) else 0 := by
              refine Finset.sum_congr rfl (fun p _ => ?_)
              by_cases hp : 0 < c p
              · simp only [hp, ↓reduceIte, true_and, Finset.sum_mul]
                refine Finset.sum_congr rfl (fun q _ => ?_)
                by_cases hq : c q < 0 <;> simp [hq, mul_assoc]
              · simp [hp]
            have h2 : (∑ q : ι, (if c q < 0 then ∑ p : ι,
                if 0 < c p then yPair p q * c p else 0 else 0) * v q) =
                ∑ p : ι, ∑ q : ι,
                  if 0 < c p ∧ c q < 0 then yPair p q * (c p * v q) else 0 := by
              rw [Finset.sum_comm (s := Finset.univ) (t := Finset.univ)
                (f := fun p q => if 0 < c p ∧ c q < 0 then yPair p q * (c p * v q) else 0)]
              refine Finset.sum_congr rfl (fun q _ => ?_)
              by_cases hq : c q < 0
              · simp only [hq, ↓reduceIte, and_true, Finset.sum_mul]
                refine Finset.sum_congr rfl (fun p _ => ?_)
                by_cases hp : 0 < c p <;> simp [hp, mul_assoc]
              · simp [hq]
            rw [h1, h2, ← Finset.sum_add_distrib]
            refine Finset.sum_congr rfl (fun p _ => ?_)
            rw [← Finset.sum_add_distrib]
            refine Finset.sum_congr rfl (fun q _ => ?_)
            by_cases hpq : 0 < c p ∧ c q < 0 <;> simp [hpq, mul_add]
          · refine Finset.sum_congr rfl (fun z _ => ?_)
            by_cases hz : c z = 0 <;> simp [hz]
        refine ⟨y, hy_nn, ?_, ?_⟩
        · intro j
          refine Fin.lastCases ?_ (fun j' => ?_) j
          · change ∑ i : ι, y i * c i = 0
            rw [hLinear c]
            have h1 : (∑ p : ι, ∑ q : ι,
                if 0 < c p ∧ c q < 0 then yPair p q * ((-c q) * c p + c p * c q) else 0) = 0 := by
              refine Finset.sum_eq_zero (fun p _ => Finset.sum_eq_zero (fun q _ => ?_))
              by_cases hpq : 0 < c p ∧ c q < 0
              · rw [if_pos hpq]; ring
              · rw [if_neg hpq]
            have h2 : (∑ z : ι, if c z = 0 then yZero z * c z else 0) = 0 := by
              refine Finset.sum_eq_zero (fun z _ => ?_)
              by_cases hz : c z = 0
              · rw [if_pos hz, hz, mul_zero]
              · rw [if_neg hz]
            rw [h1, h2, add_zero]
          · rw [hLinear (fun i => M i j'.castSucc)]
            have hEq := hy'_zero j'
            rw [Fintype.sum_sum_type, Fintype.sum_prod_type] at hEq
            refine Eq.trans ?_ hEq
            congr 1
            · refine Finset.sum_congr rfl (fun p _ => Finset.sum_congr rfl (fun q _ => ?_))
              dsimp only [M', yPair]
              by_cases hpq : 0 < c p ∧ c q < 0
              · rw [if_pos hpq, if_pos hpq]
              · rw [if_neg hpq, if_neg hpq, mul_zero]
            · refine Finset.sum_congr rfl (fun z _ => ?_)
              dsimp only [M', yZero]
              by_cases hz : c z = 0
              · rw [if_pos hz, if_pos hz]
              · rw [if_neg hz, if_neg hz, mul_zero]
        · rw [hLinear d]
          have hLt := hy'_neg
          rw [Fintype.sum_sum_type, Fintype.sum_prod_type] at hLt
          have hEqSum :
              (∑ p : ι, ∑ q : ι,
                if 0 < c p ∧ c q < 0 then yPair p q * ((-c q) * d p + c p * d q) else 0) +
              (∑ z : ι, if c z = 0 then yZero z * d z else 0) =
              (∑ x : ι, ∑ y_1 : ι, y' (Sum.inl (x, y_1)) * d' (Sum.inl (x, y_1))) +
              ∑ x : ι, y' (Sum.inr x) * d' (Sum.inr x) := by
            congr 1
            · refine Finset.sum_congr rfl (fun p _ => Finset.sum_congr rfl (fun q _ => ?_))
              dsimp only [d', yPair]
              by_cases hpq : 0 < c p ∧ c q < 0
              · rw [if_pos hpq, if_pos hpq]
              · rw [if_neg hpq, if_neg hpq, mul_zero]
            · refine Finset.sum_congr rfl (fun z _ => ?_)
              dsimp only [d', yZero]
              by_cases hz : c z = 0
              · rw [if_pos hz, if_pos hz]
              · rw [if_neg hz, if_neg hz, mul_zero]
          rw [hEqSum]
          exact hLt

theorem farkas_infeasible_iff {n m : ℕ} (M : Fin m → Fin n → ℝ) (d : Fin m → ℝ) :
    ¬ (∃ x : Fin n → ℝ, ∀ i : Fin m, ∑ j : Fin n, M i j * x j ≤ d i) ↔
      (∃ y : Fin m → ℝ, (∀ i : Fin m, 0 ≤ y i) ∧
        (∀ j : Fin n, ∑ i : Fin m, y i * M i j = 0) ∧
        ∑ i : Fin m, y i * d i < 0) := by
  constructor
  · intro hNot
    rcases farkas_le_fintype n M d with hFeas | hCert
    · exact False.elim (hNot hFeas)
    · exact hCert
  · rintro ⟨y, hy_nn, hy_eq, hy_lt⟩ ⟨x, hx⟩
    have h1 : ∑ i : Fin m, y i * (∑ j : Fin n, M i j * x j) ≤ ∑ i : Fin m, y i * d i :=
      Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hx i) (hy_nn i))
    have h2 : ∑ i : Fin m, y i * (∑ j : Fin n, M i j * x j) = 0 := by
      calc ∑ i : Fin m, y i * (∑ j : Fin n, M i j * x j)
          = ∑ i : Fin m, ∑ j : Fin n, y i * M i j * x j := by
              refine Finset.sum_congr rfl (fun i _ => ?_)
              rw [Finset.mul_sum]
              exact Finset.sum_congr rfl (fun j _ => by ring)
        _ = ∑ j : Fin n, (∑ i : Fin m, y i * M i j) * x j := by
              rw [Finset.sum_comm]
              exact Finset.sum_congr rfl (fun j _ => (Finset.sum_mul _ _ _).symm)
        _ = 0 := by simp [hy_eq]
    linarith

/-! ### 2. Active-Set Self-Reduction Lemma -/

theorem activeSet_eq_subset_le {n nEq nLe : ℕ}
    (A_eq : Fin nEq → Fin n → ℝ) (b_eq : Fin nEq → ℝ)
    (A_le : Fin nLe → Fin n → ℝ) (b_le : Fin nLe → ℝ)
    (S : Finset (Fin nLe))
    (x₀ : Fin n → ℝ)
    (hx₀_eq : ∀ i : Fin nEq, ∑ j : Fin n, A_eq i j * x₀ j = b_eq i)
    (hx₀_S : ∀ k ∈ S, ∑ j : Fin n, A_le k j * x₀ j = b_le k)
    (hx₀_le : ∀ k : Fin nLe, ∑ j : Fin n, A_le k j * x₀ j ≤ b_le k)
    (hMax : ∀ k : Fin nLe, k ∉ S →
      ¬ ∃ z : Fin n → ℝ,
          (∀ i : Fin nEq, ∑ j : Fin n, A_eq i j * z j = b_eq i) ∧
          (∀ s ∈ S, ∑ j : Fin n, A_le s j * z j = b_le s) ∧
          (∀ m : Fin nLe, ∑ j : Fin n, A_le m j * z j ≤ b_le m) ∧
          ∑ j : Fin n, A_le k j * z j = b_le k)
    (y : Fin n → ℝ)
    (hy_eq : ∀ i : Fin nEq, ∑ j : Fin n, A_eq i j * y j = b_eq i)
    (hy_S : ∀ k ∈ S, ∑ j : Fin n, A_le k j * y j = b_le k) :
    ∀ k : Fin nLe, ∑ j : Fin n, A_le k j * y j ≤ b_le k := by
  by_contra hNotAll
  push_neg at hNotAll
  rcases hNotAll with ⟨k₀, hk₀_gt⟩
  let Viol : Finset (Fin nLe) :=
    Finset.univ.filter (fun k => b_le k < ∑ j : Fin n, A_le k j * y j)
  have hk₀_mem : k₀ ∈ Viol := Finset.mem_filter.mpr ⟨Finset.mem_univ k₀, hk₀_gt⟩
  have hViol_ne : Viol.Nonempty := ⟨k₀, hk₀_mem⟩
  let ratio : Fin nLe → ℝ := fun k =>
    (b_le k - ∑ j : Fin n, A_le k j * x₀ j) /
      ((∑ j : Fin n, A_le k j * y j) - ∑ j : Fin n, A_le k j * x₀ j)
  obtain ⟨k_star, hk_star_mem, hk_star_min⟩ := Viol.exists_min_image ratio hViol_ne
  have hk_star_gt : b_le k_star < ∑ j : Fin n, A_le k_star j * y j :=
    (Finset.mem_filter.mp hk_star_mem).2
  have hk_star_not_S : k_star ∉ S := by
    intro hmem
    have := hy_S k_star hmem
    linarith
  have hx₀_strict : ∑ j : Fin n, A_le k_star j * x₀ j < b_le k_star := by
    rcases (hx₀_le k_star).lt_or_eq with hlt | heq
    · exact hlt
    · exfalso
      exact hMax k_star hk_star_not_S ⟨x₀, hx₀_eq, hx₀_S, hx₀_le, heq⟩
  let t : ℝ := ratio k_star
  have hden_pos : ∀ k ∈ Viol,
      0 < (∑ j : Fin n, A_le k j * y j) - ∑ j : Fin n, A_le k j * x₀ j := by
    intro k hk
    have hgt := (Finset.mem_filter.mp hk).2
    have hle := hx₀_le k
    linarith
  have ht_pos : 0 < t := div_pos (by linarith) (hden_pos k_star hk_star_mem)
  have ht_lt_one : t < 1 := (div_lt_one (hden_pos k_star hk_star_mem)).mpr (by linarith)
  let z : Fin n → ℝ := fun j => (1 - t) * x₀ j + t * y j
  have hLin : ∀ (row : Fin n → ℝ),
      ∑ j : Fin n, row j * z j =
        (1 - t) * (∑ j : Fin n, row j * x₀ j) + t * (∑ j : Fin n, row j * y j) := by
    intro row
    have h1 : ∀ j : Fin n, row j * z j = (1 - t) * (row j * x₀ j) + t * (row j * y j) := by
      intro j; dsimp [z]; ring
    simp_rw [h1, Finset.sum_add_distrib, ← Finset.mul_sum]
  refine hMax k_star hk_star_not_S ⟨z, ?_, ?_, ?_, ?_⟩
  · intro i
    rw [hLin (A_eq i), hx₀_eq i, hy_eq i]
    ring
  · intro s hs
    rw [hLin (A_le s), hx₀_S s hs, hy_S s hs]
    ring
  · intro m
    rw [hLin (A_le m)]
    by_cases hm : b_le m < ∑ j : Fin n, A_le m j * y j
    · have hm_mem : m ∈ Viol := Finset.mem_filter.mpr ⟨Finset.mem_univ m, hm⟩
      have ht_le : t ≤ ratio m := hk_star_min m hm_mem
      have hdm := hden_pos m hm_mem
      have hmul := (le_div_iff₀ hdm).mp ht_le
      nlinarith [hx₀_le m]
    · push_neg at hm
      nlinarith [hx₀_le m, ht_pos, ht_lt_one]
  · rw [hLin (A_le k_star)]
    have hdk := hden_pos k_star hk_star_mem
    have hmul : t * ((∑ j : Fin n, A_le k_star j * y j) - ∑ j : Fin n, A_le k_star j * x₀ j) =
        b_le k_star - ∑ j : Fin n, A_le k_star j * x₀ j :=
      div_mul_cancel₀ _ hdk.ne'
    linarith

/-! ### 3. Nonsingular Submatrices and Leibniz Determinant Bounds -/

theorem exists_ne_zero_mulVec_eq_zero_of_lt :
    ∀ {r s : ℕ}, r < s → ∀ (A : Matrix (Fin r) (Fin s) ℝ),
      ∃ w : Fin s → ℝ, w ≠ 0 ∧ A.mulVec w = 0
  | 0, s + 1, _, _ =>
      ⟨fun j => if j = 0 then 1 else 0,
        by intro h; simpa using congr_fun h 0,
        funext (fun i => Fin.elim0 i)⟩
  | r + 1, s + 1, hs, A => by
      have hrs : r < s := Nat.lt_of_succ_lt_succ hs
      by_cases hRowZero : ∀ j : Fin (s + 1), A (Fin.last r) j = 0
      · obtain ⟨w, hw_ne, hw_eq⟩ :=
          exists_ne_zero_mulVec_eq_zero_of_lt (Nat.lt_succ_of_lt hrs)
            (A.submatrix Fin.castSucc id)
        refine ⟨w, hw_ne, funext (fun i => ?_)⟩
        refine Fin.lastCases ?_ (fun i' => ?_) i
        · simp [Matrix.mulVec, dotProduct, hRowZero]
        · exact congr_fun hw_eq i'
      · push_neg at hRowZero
        rcases hRowZero with ⟨j₀, hj₀⟩
        let σ : Equiv.Perm (Fin (s + 1)) := Equiv.swap j₀ (Fin.last s)
        let B : Matrix (Fin (r + 1)) (Fin (s + 1)) ℝ := A.submatrix id σ
        have hBp : B (Fin.last r) (Fin.last s) ≠ 0 := by simpa [B, σ] using hj₀
        let p : ℝ := B (Fin.last r) (Fin.last s)
        let B' : Matrix (Fin r) (Fin s) ℝ := fun i j =>
          B i.castSucc j.castSucc - (B i.castSucc (Fin.last s) / p) * B (Fin.last r) j.castSucc
        obtain ⟨w', hw'_ne, hw'_eq⟩ := exists_ne_zero_mulVec_eq_zero_of_lt hrs B'
        let wLast : ℝ := - (∑ j : Fin s, B (Fin.last r) j.castSucc * w' j) / p
        let u : Fin (s + 1) → ℝ := Fin.snoc w' wLast
        have hu_ne : u ≠ 0 := by
          intro hu0
          apply hw'_ne
          ext j
          simpa [u] using congr_fun hu0 j.castSucc
        have hBu : B.mulVec u = 0 := by
          ext i
          refine Fin.lastCases ?_ (fun i' => ?_) i
          · simp only [Matrix.mulVec, dotProduct, Fin.sum_univ_castSucc, u,
              Fin.snoc_castSucc, Fin.snoc_last, Pi.zero_apply]
            change (∑ j : Fin s, B (Fin.last r) j.castSucc * w' j) + p * wLast = 0
            dsimp only [wLast]
            rw [mul_div_cancel₀ _ hBp]
            ring
          · have hi' := congr_fun hw'_eq i'
            simp only [Matrix.mulVec, dotProduct, B', Pi.zero_apply] at hi'
            simp only [Matrix.mulVec, dotProduct, Fin.sum_univ_castSucc, u,
              Fin.snoc_castSucc, Fin.snoc_last, Pi.zero_apply]
            have h1 : ∑ j : Fin s,
                (B i'.castSucc j.castSucc -
                  B i'.castSucc (Fin.last s) / p * B (Fin.last r) j.castSucc) * w' j =
                (∑ j : Fin s, B i'.castSucc j.castSucc * w' j) -
                  (B i'.castSucc (Fin.last s) / p) *
                    (∑ j : Fin s, B (Fin.last r) j.castSucc * w' j) := by
              simp only [sub_mul, Finset.sum_sub_distrib, mul_assoc, ← Finset.mul_sum]
            rw [h1] at hi'
            dsimp only [wLast]
            have : B i'.castSucc (Fin.last s) *
                (-(∑ j : Fin s, B (Fin.last r) j.castSucc * w' j) / p) =
                -(B i'.castSucc (Fin.last s) / p *
                  (∑ j : Fin s, B (Fin.last r) j.castSucc * w' j)) := by ring
            linarith
        refine ⟨u ∘ σ.symm, ?_, ?_⟩
        · intro h0
          apply hu_ne
          ext j
          simpa using congr_fun h0 (σ j)
        · ext i
          have hbi := congr_fun hBu i
          simp only [Matrix.mulVec, dotProduct, B, Matrix.submatrix_apply, id_eq,
            Pi.zero_apply, Function.comp_apply] at hbi ⊢
          rw [← Equiv.sum_comp (σ : Fin (s + 1) ≃ Fin (s + 1))]
          simpa using hbi

theorem exists_submatrix_det_ne_zero_of_ker_trivial :
    ∀ {r s : ℕ} (A : Matrix (Fin r) (Fin s) ℝ),
      (∀ w : Fin s → ℝ, A.mulVec w = 0 → w = 0) →
      s ≤ r ∧ ∃ ι : Fin s → Fin r, Function.Injective ι ∧ (A.submatrix ι id).det ≠ 0
  | r, 0, _, _ =>
      ⟨Nat.zero_le r, Fin.elim0, fun i => Fin.elim0 i, by simp⟩
  | r, s + 1, A, hKer => by
      have hsr : s + 1 ≤ r := by
        by_contra hlt
        push_neg at hlt
        obtain ⟨w, hw_ne, hw_eq⟩ := exists_ne_zero_mulVec_eq_zero_of_lt hlt A
        exact hw_ne (hKer w hw_eq)
      have hCol : ∃ i₀ : Fin r, A i₀ (Fin.last s) ≠ 0 := by
        by_contra hAllZero
        push_neg at hAllZero
        let eLast : Fin (s + 1) → ℝ := fun j => if j = Fin.last s then 1 else 0
        have h := hKer eLast (by
          ext i
          simp only [Matrix.mulVec, dotProduct, eLast, Pi.zero_apply]
          refine Finset.sum_eq_zero (fun j _ => ?_)
          by_cases hj : j = Fin.last s <;> simp [hj, hAllZero i])
        simpa [eLast] using congr_fun h (Fin.last s)
      rcases hCol with ⟨i₀, hi₀⟩
      let p : ℝ := A i₀ (Fin.last s)
      let A' : Matrix (Fin r) (Fin s) ℝ := fun i j =>
        A i j.castSucc - (A i (Fin.last s) / p) * A i₀ j.castSucc
      have hA'_i0 : ∀ j : Fin s, A' i₀ j = 0 := by
        intro j
        dsimp only [A', p]
        rw [div_self hi₀, one_mul, sub_self]
      have hKer' : ∀ w : Fin s → ℝ, A'.mulVec w = 0 → w = 0 := by
        intro w hw
        let wLast : ℝ := - (∑ j : Fin s, A i₀ j.castSucc * w j) / p
        have hAw : A.mulVec (Fin.snoc w wLast) = 0 := by
          ext i
          simp only [Matrix.mulVec, dotProduct, Fin.sum_univ_castSucc,
            Fin.snoc_castSucc, Fin.snoc_last, Pi.zero_apply]
          have hwi := congr_fun hw i
          simp only [Matrix.mulVec, dotProduct, A', Pi.zero_apply] at hwi
          have h1 : ∑ j : Fin s,
              (A i j.castSucc - A i (Fin.last s) / p * A i₀ j.castSucc) * w j =
              (∑ j : Fin s, A i j.castSucc * w j) -
                (A i (Fin.last s) / p) * (∑ j : Fin s, A i₀ j.castSucc * w j) := by
            simp only [sub_mul, Finset.sum_sub_distrib, mul_assoc, ← Finset.mul_sum]
          rw [h1] at hwi
          dsimp only [wLast]
          have : A i (Fin.last s) * (-(∑ j : Fin s, A i₀ j.castSucc * w j) / p) =
              -(A i (Fin.last s) / p * (∑ j : Fin s, A i₀ j.castSucc * w j)) := by ring
          linarith
        have h0 := hKer (Fin.snoc w wLast) hAw
        ext j
        simpa using congr_fun h0 j.castSucc
      obtain ⟨_, ι', hι'_inj, hdet'⟩ := exists_submatrix_det_ne_zero_of_ker_trivial A' hKer'
      have hi₀_not_mem : ∀ k : Fin s, ι' k ≠ i₀ := by
        intro k hk
        apply hdet'
        refine Matrix.det_eq_zero_of_row_eq_zero k (fun j => ?_)
        simp [Matrix.submatrix_apply, hk, hA'_i0]
      let ι : Fin (s + 1) → Fin r := Fin.snoc ι' i₀
      have hι_inj : Function.Injective ι := by
        intro a b
        refine Fin.lastCases ?_ (fun a' => ?_) a <;> refine Fin.lastCases ?_ (fun b' => ?_) b <;>
          intro hab
        · rfl
        · simp only [ι, Fin.snoc_last, Fin.snoc_castSucc] at hab
          exact False.elim (hi₀_not_mem b' hab.symm)
        · simp only [ι, Fin.snoc_last, Fin.snoc_castSucc] at hab
          exact False.elim (hi₀_not_mem a' hab)
        · simp only [ι, Fin.snoc_castSucc] at hab
          exact congrArg Fin.castSucc (hι'_inj hab)
      have hSubInj : Function.Injective (A.submatrix ι id).mulVec := by
        intro u v huv
        have hu : (A.submatrix ι id).mulVec (u - v) = 0 := by
          rw [Matrix.mulVec_sub, huv, sub_self]
        suffices h0 : u - v = 0 from sub_eq_zero.mp h0
        have hu_last_row := congr_fun hu (Fin.last s)
        simp only [Matrix.mulVec, dotProduct, Matrix.submatrix_apply, ι, id_eq,
          Fin.sum_univ_castSucc, Fin.snoc_last, Pi.zero_apply] at hu_last_row
        have hu_last : (u - v) (Fin.last s) =
            - (∑ j : Fin s, A i₀ j.castSucc * (u - v) j.castSucc) / p := by
          dsimp only [p]
          apply eq_div_of_mul_eq hi₀
          linarith
        have hB'u : (A'.submatrix ι' id).mulVec (Fin.init (u - v)) = 0 := by
          ext k
          have huk := congr_fun hu k.castSucc
          simp only [Matrix.mulVec, dotProduct, Matrix.submatrix_apply, ι, id_eq,
            Fin.sum_univ_castSucc, Fin.snoc_castSucc, Pi.zero_apply] at huk
          simp only [Matrix.mulVec, dotProduct, Matrix.submatrix_apply, id_eq, Fin.init,
            A', Pi.zero_apply]
          have h1 : ∑ j : Fin s,
              (A (ι' k) j.castSucc - A (ι' k) (Fin.last s) / p * A i₀ j.castSucc) *
                (u - v) j.castSucc =
              (∑ j : Fin s, A (ι' k) j.castSucc * (u - v) j.castSucc) -
                (A (ι' k) (Fin.last s) / p) *
                  (∑ j : Fin s, A i₀ j.castSucc * (u - v) j.castSucc) := by
            simp only [sub_mul, Finset.sum_sub_distrib, mul_assoc, ← Finset.mul_sum]
          rw [h1]
          rw [hu_last] at huk
          have : A (ι' k) (Fin.last s) *
              (-(∑ j : Fin s, A i₀ j.castSucc * (u - v) j.castSucc) / p) =
              -(A (ι' k) (Fin.last s) / p *
                (∑ j : Fin s, A i₀ j.castSucc * (u - v) j.castSucc)) := by
            ring
          linarith
        have hUnit' : IsUnit (A'.submatrix ι' id) :=
          (Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_iff_ne_zero.mpr hdet')
        have hInitZero : Fin.init (u - v) = 0 :=
          (Matrix.mulVec_injective_iff_isUnit.mpr hUnit') (by simpa using hB'u)
        have hu_cast : ∀ j : Fin s, (u - v) j.castSucc = 0 := fun j => congr_fun hInitZero j
        ext j
        refine Fin.lastCases ?_ (fun j' => hu_cast j') j
        simp [hu_last, hu_cast]
      have hUnit : IsUnit (A.submatrix ι id) :=
        Matrix.mulVec_injective_iff_isUnit.mp hSubInj
      have hdet : (A.submatrix ι id).det ≠ 0 :=
        isUnit_iff_ne_zero.mp ((Matrix.isUnit_iff_isUnit_det _).mp hUnit)
      exact ⟨hsr, ι, hι_inj, hdet⟩

theorem abs_det_le_factorial_mul_pow_real {k : ℕ} (A : Matrix (Fin k) (Fin k) ℝ) (U : ℝ)
    (hU : 0 ≤ U) (hA : ∀ i j : Fin k, |A i j| ≤ U) :
    |A.det| ≤ (k.factorial : ℝ) * U ^ k := by
  rw [Matrix.det_apply]
  calc |∑ σ : Equiv.Perm (Fin k), Equiv.Perm.sign σ • ∏ i : Fin k, A (σ i) i|
      ≤ ∑ σ : Equiv.Perm (Fin k), |Equiv.Perm.sign σ • ∏ i : Fin k, A (σ i) i| :=
        Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ _σ : Equiv.Perm (Fin k), U ^ k := by
        refine Finset.sum_le_sum (fun σ _ => ?_)
        have hsign : |Equiv.Perm.sign σ • ∏ i : Fin k, A (σ i) i| =
            |∏ i : Fin k, A (σ i) i| := by
          rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hs | hs <;> simp [hs]
        rw [hsign, Finset.abs_prod]
        calc ∏ i : Fin k, |A (σ i) i|
            ≤ ∏ _i : Fin k, U :=
              Finset.prod_le_prod (fun _ _ => abs_nonneg _) (fun i _ => hA (σ i) i)
          _ = U ^ k := by simp
    _ = (k.factorial : ℝ) * U ^ k := by
        simp [Fintype.card_perm]

theorem natAbs_det_le_factorial_mul_pow_int {k : ℕ} (A : Matrix (Fin k) (Fin k) ℤ) (U : ℕ)
    (hA : ∀ i j : Fin k, (A i j).natAbs ≤ U) :
    A.det.natAbs ≤ k.factorial * U ^ k := by
  have hReal : |(A.map (Int.castRingHom ℝ)).det| ≤ (k.factorial : ℝ) * (U : ℝ) ^ k := by
    refine abs_det_le_factorial_mul_pow_real _ (U : ℝ) (Nat.cast_nonneg U) (fun i j => ?_)
    have hij : |(A i j : ℝ)| ≤ (U : ℝ) := by
      have : ((A i j).natAbs : ℝ) ≤ (U : ℝ) := by exact_mod_cast hA i j
      have habs : |(A i j : ℝ)| = ((A i j).natAbs : ℝ) := real_abs_int_eq_natAbs (A i j)
      linarith
    simpa using hij
  have hCastDet : (A.map (Int.castRingHom ℝ)).det = (A.det : ℝ) :=
    (RingHom.map_det (Int.castRingHom ℝ) A).symm
  rw [hCastDet] at hReal
  have hAbs : |(A.det : ℝ)| = ((A.det.natAbs : ℕ) : ℝ) := real_abs_int_eq_natAbs A.det
  rw [hAbs] at hReal
  exact_mod_cast hReal

/-! ### 4. Bounded Primal Solution and Bounded Integer Farkas Certificate -/

theorem int_lp_bounded_primal {n m : ℕ} (M : Fin m → Fin n → ℤ) (d : Fin m → ℤ) (U : ℕ)
    (hU : 1 ≤ U)
    (hM : ∀ (i : Fin m) (j : Fin n), (M i j).natAbs ≤ U)
    (hd : ∀ i : Fin m, (d i).natAbs ≤ U)
    (hFeas : ∃ x : Fin n → ℝ, ∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * x j ≤ (d i : ℝ)) :
    ∃ x_star : Fin n → ℝ,
      (∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * x_star j ≤ (d i : ℝ)) ∧
      (∀ j : Fin n, |x_star j| ≤ (n.factorial : ℝ) * (U : ℝ) ^ n) := by
  classical
  let FeasSet : Finset (Finset (Fin m)) :=
    Finset.univ.filter (fun S =>
      ∃ x : Fin n → ℝ,
        (∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * x j ≤ (d i : ℝ)) ∧
        (∀ i ∈ S, ∑ j : Fin n, (M i j : ℝ) * x j = (d i : ℝ)))
  have hEmpty_mem : (∅ : Finset (Fin m)) ∈ FeasSet := by
    rcases hFeas with ⟨x, hx⟩
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, x, hx, fun _ h => False.elim (Finset.notMem_empty _ h)⟩
  obtain ⟨S, hS_mem, hS_max⟩ := FeasSet.exists_max_image Finset.card ⟨∅, hEmpty_mem⟩
  rcases (Finset.mem_filter.mp hS_mem).2 with ⟨x₀, hx₀_le, hx₀_S⟩
  have hSubLe : ∀ y : Fin n → ℝ,
      (∀ i ∈ S, ∑ j : Fin n, (M i j : ℝ) * y j = (d i : ℝ)) →
      ∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * y j ≤ (d i : ℝ) := by
    intro y hy_S
    refine activeSet_eq_subset_le (nEq := 0) Fin.elim0 Fin.elim0
      (fun i j => (M i j : ℝ)) (fun i => (d i : ℝ)) S x₀
      (fun i => Fin.elim0 i) hx₀_S hx₀_le ?_ y (fun i => Fin.elim0 i) hy_S
    intro k hk ⟨z, _, hz_S, hz_le, hz_k⟩
    have hIns_mem : insert k S ∈ FeasSet := by
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, z, hz_le, ?_⟩
      intro i hi
      rcases Finset.mem_insert.mp hi with rfl | hiS
      · exact hz_k
      · exact hz_S i hiS
    have hle := hS_max (insert k S) hIns_mem
    rw [Finset.card_insert_of_notMem hk] at hle
    omega
  let ZeroSet : Finset (Finset (Fin n)) :=
    Finset.univ.filter (fun Z =>
      ∃ y : Fin n → ℝ,
        (∀ i ∈ S, ∑ j : Fin n, (M i j : ℝ) * y j = (d i : ℝ)) ∧
        (∀ j ∈ Z, y j = 0))
  have hZEmpty_mem : (∅ : Finset (Fin n)) ∈ ZeroSet :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _, x₀, hx₀_S, fun _ h => False.elim (Finset.notMem_empty _ h)⟩
  obtain ⟨Z, hZ_mem, hZ_max⟩ := ZeroSet.exists_max_image Finset.card ⟨∅, hZEmpty_mem⟩
  rcases (Finset.mem_filter.mp hZ_mem).2 with ⟨x_star, hx_star_S, hx_star_Z⟩
  let F : Finset (Fin n) := Finset.univ \ Z
  let k : ℕ := F.card
  let r : ℕ := S.card
  let eF : Fin k ≃ F := F.equivFin.symm
  let eS : Fin r ≃ S := S.equivFin.symm
  let A : Matrix (Fin r) (Fin k) ℝ := fun p q => (M (eS p).1 (eF q).1 : ℝ)
  have hKer : ∀ w : Fin k → ℝ, A.mulVec w = 0 → w = 0 := by
    intro w hw
    by_contra hw_ne
    have hEx : ∃ q₀ : Fin k, w q₀ ≠ 0 := by
      by_contra hall
      push_neg at hall
      exact hw_ne (funext hall)
    rcases hEx with ⟨q₀, hq₀⟩
    let v : Fin n → ℝ := fun j => if hj : j ∈ F then w (eF.symm ⟨j, hj⟩) else 0
    have hv_Z : ∀ j ∈ Z, v j = 0 := by
      intro j hj
      have hjF : j ∉ F := fun h => (Finset.mem_sdiff.mp h).2 hj
      simp [v, hjF]
    have hv_q0 : v (eF q₀).1 = w q₀ := by
      have hjF : (eF q₀).1 ∈ F := (eF q₀).2
      simp [v, hjF]
    have hv_S : ∀ i ∈ S, ∑ j : Fin n, (M i j : ℝ) * v j = 0 := by
      intro i hi
      let p : Fin r := eS.symm ⟨i, hi⟩
      have hp : (eS p).1 = i := by simp [p]
      have hrow := congr_fun hw p
      simp only [Matrix.mulVec, dotProduct, A, hp, Pi.zero_apply] at hrow
      calc ∑ j : Fin n, (M i j : ℝ) * v j
          = ∑ j ∈ F, (M i j : ℝ) * v j := by
              rw [← Finset.sum_subset (Finset.subset_univ F)]
              intro j _ hjF
              simp [v, hjF]
        _ = ∑ x : F, (M i x.1 : ℝ) * w (eF.symm x) := by
              rw [← Finset.sum_coe_sort F]
              refine Finset.sum_congr rfl (fun x _ => ?_)
              simp [v, x.2]
        _ = ∑ q : Fin k, (M i (eF q).1 : ℝ) * w q := by
              rw [← eF.sum_comp]
              simp
        _ = 0 := hrow
    let α : ℝ := x_star (eF q₀).1 / w q₀
    let y' : Fin n → ℝ := fun j => x_star j - α * v j
    have hj₀_not_Z : (eF q₀).1 ∉ Z := (Finset.mem_sdiff.mp (eF q₀).2).2
    have hInsZ : insert (eF q₀).1 Z ∈ ZeroSet := by
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, y', ?_, ?_⟩
      · intro i hi
        have h1 : ∑ j : Fin n, (M i j : ℝ) * y' j =
            (∑ j : Fin n, (M i j : ℝ) * x_star j) - α * (∑ j : Fin n, (M i j : ℝ) * v j) := by
          have hterm : ∀ j : Fin n, (M i j : ℝ) * y' j =
              (M i j : ℝ) * x_star j - α * ((M i j : ℝ) * v j) := by
            intro j; dsimp [y']; ring
          simp_rw [hterm, Finset.sum_sub_distrib, ← Finset.mul_sum]
        rw [h1, hx_star_S i hi, hv_S i hi, mul_zero, sub_zero]
      · intro j hj
        rcases Finset.mem_insert.mp hj with rfl | hjZ
        · dsimp only [y', α]
          rw [hv_q0, div_mul_cancel₀ _ hq₀, sub_self]
        · simp [y', hx_star_Z j hjZ, hv_Z j hjZ]
    have hle := hZ_max _ hInsZ
    rw [Finset.card_insert_of_notMem hj₀_not_Z] at hle
    omega
  obtain ⟨_, ι, _, hdet⟩ := exists_submatrix_det_ne_zero_of_ker_trivial A hKer
  let B_int : Matrix (Fin k) (Fin k) ℤ := fun p q => M (eS (ι p)).1 (eF q).1
  let B_real : Matrix (Fin k) (Fin k) ℝ := A.submatrix ι id
  have hB_map : B_real = B_int.map (Int.castRingHom ℝ) := by ext p q; rfl
  have hB_det_cast : B_real.det = (B_int.det : ℝ) := by
    rw [hB_map]
    exact (RingHom.map_det (Int.castRingHom ℝ) B_int).symm
  have hB_int_ne : B_int.det ≠ 0 := by
    intro h0
    apply hdet
    rw [hB_det_cast, h0, Int.cast_zero]
  have hDetGeOne : (1 : ℝ) ≤ |B_real.det| := by
    rw [hB_det_cast, ← Int.cast_abs]
    exact_mod_cast Int.one_le_abs hB_int_ne
  let rhs : Fin k → ℝ := fun p => (d (eS (ι p)).1 : ℝ)
  have hB_eq : B_real.mulVec (fun q => x_star (eF q).1) = rhs := by
    ext p
    simp only [Matrix.mulVec, dotProduct, B_real, Matrix.submatrix_apply, A, id_eq, rhs]
    have hRow := hx_star_S (eS (ι p)).1 (eS (ι p)).2
    rw [← hRow]
    symm
    calc ∑ j : Fin n, (M (eS (ι p)).1 j : ℝ) * x_star j
        = ∑ j ∈ F, (M (eS (ι p)).1 j : ℝ) * x_star j := by
            rw [← Finset.sum_subset (Finset.subset_univ F)]
            intro j _ hjF
            have hjZ : j ∈ Z := by
              by_contra hnotZ
              exact hjF (Finset.mem_sdiff.mpr ⟨Finset.mem_univ j, hnotZ⟩)
            simp [hx_star_Z j hjZ]
      _ = ∑ x : F, (M (eS (ι p)).1 x.1 : ℝ) * x_star x.1 := by
            rw [← Finset.sum_coe_sort F]
      _ = ∑ q : Fin k, (M (eS (ι p)).1 (eF q).1 : ℝ) * x_star (eF q).1 := by
            rw [← eF.sum_comp]
  have hCramer := Matrix.mulVec_cramer B_real rhs
  have hUnit : IsUnit B_real := (Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_iff_ne_zero.mpr hdet)
  have hSolEq : B_real.det • (fun q : Fin k => x_star (eF q).1) = B_real.cramer rhs := by
    apply Matrix.mulVec_injective_iff_isUnit.mpr hUnit
    rw [Matrix.mulVec_smul, hB_eq, hCramer]
  have hk_le_n : k ≤ n := by
    simpa [k, F] using (Finset.card_le_univ (Finset.univ \ Z))
  refine ⟨x_star, hSubLe x_star hx_star_S, fun j => ?_⟩
  by_cases hjZ : j ∈ Z
  · rw [hx_star_Z j hjZ, abs_zero]
    positivity
  · have hjF : j ∈ F := Finset.mem_sdiff.mpr ⟨Finset.mem_univ j, hjZ⟩
    let q : Fin k := eF.symm ⟨j, hjF⟩
    have hq : (eF q).1 = j := by simp [q]
    have hqj := congr_fun hSolEq q
    simp only [Pi.smul_apply, smul_eq_mul, hq, Matrix.cramer_apply] at hqj
    have hAbsUpd : |(B_real.updateCol q rhs).det| ≤ (k.factorial : ℝ) * (U : ℝ) ^ k := by
      refine abs_det_le_factorial_mul_pow_real _ (U : ℝ) (Nat.cast_nonneg U) (fun p q' => ?_)
      by_cases hqq : q' = q
      · subst hqq
        simp only [Matrix.updateCol_self, rhs]
        have habs := real_abs_int_eq_natAbs (d (eS (ι p)).1)
        rw [habs]
        exact_mod_cast hd _
      · simp only [Matrix.updateCol_ne hqq, B_real, Matrix.submatrix_apply, A, id_eq]
        have habs := real_abs_int_eq_natAbs (M (eS (ι p)).1 (eF q').1)
        rw [habs]
        exact_mod_cast hM _ _
    have hAbsProd : |B_real.det| * |x_star j| ≤ (k.factorial : ℝ) * (U : ℝ) ^ k := by
      rw [← abs_mul, hqj]
      exact hAbsUpd
    have hBound_k : |x_star j| ≤ (k.factorial : ℝ) * (U : ℝ) ^ k := by
      nlinarith [abs_nonneg (x_star j)]
    have hFac : (k.factorial : ℝ) ≤ (n.factorial : ℝ) := by
      exact_mod_cast Nat.factorial_le hk_le_n
    have hPow : (U : ℝ) ^ k ≤ (U : ℝ) ^ n := by
      exact_mod_cast Nat.pow_le_pow_right hU hk_le_n
    calc |x_star j| ≤ (k.factorial : ℝ) * (U : ℝ) ^ k := hBound_k
      _ ≤ (n.factorial : ℝ) * (U : ℝ) ^ n :=
          mul_le_mul hFac hPow (by positivity) (by positivity)

theorem int_lp_farkas_bounded {n m : ℕ} (M : Fin m → Fin n → ℤ) (d : Fin m → ℤ) (U : ℕ)
    (hU : 1 ≤ U)
    (hM : ∀ (i : Fin m) (j : Fin n), (M i j).natAbs ≤ U)
    (hd : ∀ i : Fin m, (d i).natAbs ≤ U)
    (hInfeas : ¬ ∃ x : Fin n → ℝ, ∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * x j ≤ (d i : ℝ)) :
    ∃ y : Fin m → ℤ,
      (∀ i : Fin m, 0 ≤ y i) ∧
      (∀ j : Fin n, ∑ i : Fin m, y i * M i j = 0) ∧
      ∑ i : Fin m, y i * d i ≤ -1 ∧
      ∑ i : Fin m, y i ≤ ((n + 1) * (n + 1).factorial * U ^ (n + 1) : ℕ) := by
  classical
  obtain ⟨y₀, hy₀_nn, hy₀_eq, hy₀_lt⟩ :=
    (farkas_infeasible_iff (fun i j => (M i j : ℝ)) (fun i => (d i : ℝ))).mp hInfeas
  let s₀ : ℝ := -(∑ i : Fin m, y₀ i * (d i : ℝ))
  have hs₀_pos : 0 < s₀ := neg_pos.mpr hy₀_lt
  let y₁ : Fin m → ℝ := fun i => (1 / s₀) * y₀ i
  let SuppSet : Finset (Finset (Fin m)) :=
    Finset.univ.filter (fun S =>
      ∃ y : Fin m → ℝ,
        (∀ i : Fin m, 0 ≤ y i) ∧
        (∀ i : Fin m, i ∉ S → y i = 0) ∧
        (∀ j : Fin n, ∑ i : Fin m, y i * (M i j : ℝ) = 0) ∧
        ∑ i : Fin m, y i * (d i : ℝ) = -1)
  have hUniv_mem : (Finset.univ : Finset (Fin m)) ∈ SuppSet := by
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, y₁, ?_, ?_, ?_, ?_⟩
    · intro i
      exact mul_nonneg (one_div_nonneg.mpr hs₀_pos.le) (hy₀_nn i)
    · intro i hi
      exact False.elim (hi (Finset.mem_univ i))
    · intro j
      have h : ∑ i : Fin m, y₁ i * (M i j : ℝ) = (1 / s₀) * ∑ i : Fin m, y₀ i * (M i j : ℝ) := by
        simp only [y₁, mul_assoc, ← Finset.mul_sum]
      rw [h, hy₀_eq j, mul_zero]
    · have h : ∑ i : Fin m, y₁ i * (d i : ℝ) = (1 / s₀) * ∑ i : Fin m, y₀ i * (d i : ℝ) := by
        simp only [y₁, mul_assoc, ← Finset.mul_sum]
      rw [h]
      have hsum : ∑ i : Fin m, y₀ i * (d i : ℝ) = -s₀ := by simp [s₀]
      rw [hsum, one_div, inv_mul_eq_div, neg_div, div_self hs₀_pos.ne']
  obtain ⟨S, hS_mem, hS_min⟩ := SuppSet.exists_min_image Finset.card ⟨Finset.univ, hUniv_mem⟩
  rcases (Finset.mem_filter.mp hS_mem).2 with ⟨y_star, hy_nn, hy_out, hy_eq, hy_d⟩
  have hy_pos : ∀ i ∈ S, 0 < y_star i := by
    intro i hi
    rcases (hy_nn i).lt_or_eq with hpos | hzero
    · exact hpos
    · exfalso
      have hErase_mem : S.erase i ∈ SuppSet := by
        refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, y_star, hy_nn, ?_, hy_eq, hy_d⟩
        intro r hr
        by_cases hri : r = i
        · subst hri; exact hzero.symm
        · exact hy_out r (fun hrS => hr (Finset.mem_erase.mpr ⟨hri, hrS⟩))
      have hle := hS_min (S.erase i) hErase_mem
      have hlt := Finset.card_erase_lt_of_mem hi
      omega
  let k : ℕ := S.card
  let eS : Fin k ≃ S := S.equivFin.symm
  let C_int : Matrix (Fin (n + 1)) (Fin k) ℤ := fun p q =>
    Fin.lastCases (d (eS q).1) (fun j => M (eS q).1 j) p
  let C_real : Matrix (Fin (n + 1)) (Fin k) ℝ := C_int.map (Int.castRingHom ℝ)
  have hKer : ∀ w : Fin k → ℝ, C_real.mulVec w = 0 → w = 0 := by
    intro w hw
    by_contra hw_ne
    have hEx : ∃ q₀ : Fin k, w q₀ ≠ 0 := by
      by_contra hall; push_neg at hall; exact hw_ne (funext hall)
    rcases hEx with ⟨q₀, hq₀⟩
    let sgnW : ℝ := if 0 < w q₀ then 1 else -1
    let v : Fin k → ℝ := fun q => sgnW * w q
    have hv_q0 : 0 < v q₀ := by
      dsimp only [v, sgnW]
      rcases lt_trichotomy (w q₀) 0 with hneg | hzero | hpos
      · simp [not_lt.mpr hneg.le]; linarith
      · exact False.elim (hq₀ hzero)
      · simp [hpos]
    have hCv : C_real.mulVec v = 0 := by
      have : v = sgnW • w := rfl
      rw [this, Matrix.mulVec_smul, hw, smul_zero]
    let PosQ : Finset (Fin k) := Finset.univ.filter (fun q => 0 < v q)
    obtain ⟨q_star, hq_star_mem, hq_star_min⟩ :=
      PosQ.exists_min_image (fun q => y_star (eS q).1 / v q)
        ⟨q₀, Finset.mem_filter.mpr ⟨Finset.mem_univ q₀, hv_q0⟩⟩
    have hv_star_pos : 0 < v q_star := (Finset.mem_filter.mp hq_star_mem).2
    let t : ℝ := y_star (eS q_star).1 / v q_star
    have ht_pos : 0 < t := div_pos (hy_pos (eS q_star).1 (eS q_star).2) hv_star_pos
    let y' : Fin m → ℝ := fun i =>
      if hi : i ∈ S then y_star i - t * v (eS.symm ⟨i, hi⟩) else 0
    have hv_sum : ∀ g : Fin m → ℝ,
        ∑ i : Fin m, (if hi : i ∈ S then v (eS.symm ⟨i, hi⟩) else 0) * g i =
          ∑ q : Fin k, g (eS q).1 * v q := by
      intro g
      calc ∑ i : Fin m, (if hi : i ∈ S then v (eS.symm ⟨i, hi⟩) else 0) * g i
          = ∑ i ∈ S, (if hi : i ∈ S then v (eS.symm ⟨i, hi⟩) else 0) * g i := by
              rw [← Finset.sum_subset (Finset.subset_univ S)]
              intro i _ hiS; simp [hiS]
        _ = ∑ x : S, v (eS.symm x) * g x.1 := by
              rw [← Finset.sum_coe_sort S]
              refine Finset.sum_congr rfl (fun x _ => ?_)
              simp [x.2]
        _ = ∑ q : Fin k, v q * g (eS q).1 := by
              rw [← eS.sum_comp]; simp
        _ = ∑ q : Fin k, g (eS q).1 * v q :=
              Finset.sum_congr rfl (fun _ _ => mul_comm _ _)
    have hy'_split : ∀ g : Fin m → ℝ,
        ∑ i : Fin m, y' i * g i =
          (∑ i : Fin m, y_star i * g i) - t * (∑ q : Fin k, g (eS q).1 * v q) := by
      intro g
      rw [← hv_sum g, Finset.mul_sum, ← Finset.sum_sub_distrib]
      refine Finset.sum_congr rfl (fun i _ => ?_)
      by_cases hi : i ∈ S
      · simp [y', hi]; ring
      · simp [y', hi, hy_out i hi]
    have hErase : S.erase (eS q_star).1 ∈ SuppSet := by
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, y', ?_, ?_, ?_, ?_⟩
      · intro i
        by_cases hi : i ∈ S
        · simp only [y', hi, ↓reduceDIte]
          let q : Fin k := eS.symm ⟨i, hi⟩
          have hq : (eS q).1 = i := by simp [q]
          by_cases hvq : 0 < v q
          · have hle := hq_star_min q (Finset.mem_filter.mpr ⟨Finset.mem_univ q, hvq⟩)
            have hmul := (le_div_iff₀ hvq).mp hle
            rw [hq] at hmul
            linarith
          · push_neg at hvq
            have : t * v q ≤ 0 := mul_nonpos_of_nonneg_of_nonpos ht_pos.le hvq
            linarith [hy_nn i]
        · simp [y', hi]
      · intro i hiEr
        by_cases hi : i ∈ S
        · have hi_eq : i = (eS q_star).1 := by
            by_contra hne
            exact hiEr (Finset.mem_erase.mpr ⟨hne, hi⟩)
          subst hi_eq
          simp only [y', (eS q_star).2, ↓reduceDIte, Subtype.coe_eta, Equiv.symm_apply_apply]
          dsimp only [t]
          rw [div_mul_cancel₀ _ hv_star_pos.ne', sub_self]
        · simp [y', hi]
      · intro j
        rw [hy'_split (fun i => (M i j : ℝ)), hy_eq j]
        have hcj := congr_fun hCv j.castSucc
        simp only [Matrix.mulVec, dotProduct, C_real, Matrix.map_apply, C_int,
          Fin.lastCases_castSucc, Pi.zero_apply] at hcj
        change (0 : ℝ) - t * ∑ q : Fin k, (M (eS q).1 j : ℝ) * v q = 0
        have hcj' : ∑ q : Fin k, (M (eS q).1 j : ℝ) * v q = 0 := hcj
        rw [hcj', mul_zero, sub_zero]
      · rw [hy'_split (fun i => (d i : ℝ)), hy_d]
        have hcd := congr_fun hCv (Fin.last n)
        simp only [Matrix.mulVec, dotProduct, C_real, Matrix.map_apply, C_int,
          Fin.lastCases_last, Pi.zero_apply] at hcd
        have hcd' : ∑ q : Fin k, (d (eS q).1 : ℝ) * v q = 0 := hcd
        rw [hcd', mul_zero, sub_zero]
    have hle := hS_min _ hErase
    have hlt := Finset.card_erase_lt_of_mem (eS q_star).2
    omega
  obtain ⟨hk_le, ι, _, hdet⟩ := exists_submatrix_det_ne_zero_of_ker_trivial C_real hKer
  let B_int : Matrix (Fin k) (Fin k) ℤ := C_int.submatrix ι id
  let B_real : Matrix (Fin k) (Fin k) ℝ := C_real.submatrix ι id
  have hB_map : B_real = B_int.map (Int.castRingHom ℝ) := by ext p q; rfl
  have hB_det_cast : B_real.det = (B_int.det : ℝ) := by
    rw [hB_map]
    exact (RingHom.map_det (Int.castRingHom ℝ) B_int).symm
  have hB_int_ne : B_int.det ≠ 0 := by
    intro h0; apply hdet; rw [hB_det_cast, h0, Int.cast_zero]
  let rhs_int : Fin k → ℤ := fun p => if ι p = Fin.last n then -1 else 0
  let rhs_real : Fin k → ℝ := fun p => (rhs_int p : ℝ)
  have hB_eq : B_real.mulVec (fun q => y_star (eS q).1) = rhs_real := by
    ext p
    simp only [Matrix.mulVec, dotProduct, B_real, Matrix.submatrix_apply, id_eq, rhs_real, rhs_int]
    have hSumRestrict : ∀ g : Fin m → ℝ,
        ∑ q : Fin k, g (eS q).1 * y_star (eS q).1 = ∑ i : Fin m, y_star i * g i := by
      intro g
      calc ∑ q : Fin k, g (eS q).1 * y_star (eS q).1
          = ∑ x : S, g x.1 * y_star x.1 := by rw [← eS.sum_comp]
        _ = ∑ i ∈ S, g i * y_star i := Finset.sum_coe_sort S (fun i => g i * y_star i)
        _ = ∑ i : Fin m, g i * y_star i := by
              rw [Finset.sum_subset (Finset.subset_univ S)]
              intro i _ hiS; simp [hy_out i hiS]
        _ = ∑ i : Fin m, y_star i * g i :=
              Finset.sum_congr rfl (fun _ _ => mul_comm _ _)
    refine Fin.lastCases ?_ (fun j => ?_) (ι p)
    · simp only [C_real, Matrix.map_apply, C_int, Fin.lastCases_last, ↓reduceIte, Int.cast_neg,
        Int.cast_one]
      exact hSumRestrict (fun i => (d i : ℝ)) |>.trans hy_d
    · have hne : j.castSucc ≠ Fin.last n := Fin.castSucc_ne_last j
      simp only [C_real, Matrix.map_apply, C_int, Fin.lastCases_castSucc, hne, ↓reduceIte,
        Int.cast_zero]
      exact hSumRestrict (fun i => (M i j : ℝ)) |>.trans (hy_eq j)
  have hUnit : IsUnit B_real := (Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_iff_ne_zero.mpr hdet)
  have hSolEq : B_real.det • (fun q : Fin k => y_star (eS q).1) = B_real.cramer rhs_real := by
    apply Matrix.mulVec_injective_iff_isUnit.mpr hUnit
    rw [Matrix.mulVec_smul, hB_eq, Matrix.mulVec_cramer]
  let sgn : ℤ := if 0 < B_int.det then 1 else -1
  have hsgn_abs : ((sgn * B_int.det : ℤ) : ℝ) = |B_real.det| := by
    rw [hB_det_cast]
    dsimp only [sgn]
    rcases lt_trichotomy B_int.det 0 with hneg | hzero | hpos
    · have hn : ¬ 0 < B_int.det := not_lt.mpr hneg.le
      have hnegR : (B_int.det : ℝ) < 0 := by exact_mod_cast hneg
      simp [hn, abs_of_neg hnegR]
    · exact False.elim (hB_int_ne hzero)
    · have hposR : 0 < (B_int.det : ℝ) := by exact_mod_cast hpos
      simp [hpos, abs_of_pos hposR]
  have hAbsGeOne : (1 : ℝ) ≤ |B_real.det| := by
    rw [hB_det_cast, ← Int.cast_abs]
    exact_mod_cast Int.one_le_abs hB_int_ne
  let y_int : Fin m → ℤ := fun i =>
    if hi : i ∈ S then sgn * (B_int.cramer rhs_int) (eS.symm ⟨i, hi⟩) else 0
  have hy_int_cast : ∀ i : Fin m, (y_int i : ℝ) = |B_real.det| * y_star i := by
    intro i
    by_cases hi : i ∈ S
    · let q : Fin k := eS.symm ⟨i, hi⟩
      have hq : (eS q).1 = i := by simp [q]
      have hqj := congr_fun hSolEq q
      simp only [Pi.smul_apply, smul_eq_mul, hq, Matrix.cramer_apply] at hqj
      have hCramerCast : (((B_int.cramer rhs_int) q : ℤ) : ℝ) = (B_real.updateCol q rhs_real).det := by
        rw [Matrix.cramer_apply]
        have hUpd : B_real.updateCol q rhs_real = (B_int.updateCol q rhs_int).map (Int.castRingHom ℝ) := by
          ext p q'
          by_cases hqq : q' = q
          · subst hqq; simp [rhs_real]
          · simp [hqq, hB_map]
        rw [hUpd]
        exact RingHom.map_det (Int.castRingHom ℝ) (B_int.updateCol q rhs_int)
      simp only [y_int, hi, ↓reduceDIte, Int.cast_mul]
      change (sgn : ℝ) * (((B_int.cramer rhs_int) q : ℤ) : ℝ) = |B_real.det| * y_star i
      rw [hCramerCast, ← hqj]
      have h1 : (sgn : ℝ) * (B_real.det * y_star i) = ((sgn * B_int.det : ℤ) : ℝ) * y_star i := by
        rw [hB_det_cast, Int.cast_mul]; ring
      rw [h1, hsgn_abs]
    · simp [y_int, hi, hy_out i hi]
  refine ⟨y_int, ?_, ?_, ?_, ?_⟩
  · intro i
    have h : (0 : ℝ) ≤ (y_int i : ℝ) := by
      rw [hy_int_cast i]
      exact mul_nonneg (abs_nonneg _) (hy_nn i)
    exact_mod_cast h
  · intro j
    have h : ((∑ i : Fin m, y_int i * M i j : ℤ) : ℝ) = 0 := by
      push_cast
      have h1 : ∑ i : Fin m, (y_int i : ℝ) * (M i j : ℝ) =
          |B_real.det| * ∑ i : Fin m, y_star i * (M i j : ℝ) := by
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl (fun i _ => ?_)
        rw [hy_int_cast i]; ring
      rw [h1, hy_eq j, mul_zero]
    exact_mod_cast h
  · have h : ((∑ i : Fin m, y_int i * d i : ℤ) : ℝ) ≤ -1 := by
      push_cast
      have h1 : ∑ i : Fin m, (y_int i : ℝ) * (d i : ℝ) =
          |B_real.det| * ∑ i : Fin m, y_star i * (d i : ℝ) := by
        rw [Finset.mul_sum]
        refine Finset.sum_congr rfl (fun i _ => ?_)
        rw [hy_int_cast i]; ring
      rw [h1, hy_d]
      linarith
    exact_mod_cast h
  · have hEach : ∀ i ∈ S, y_int i ≤ ((n + 1).factorial * U ^ (n + 1) : ℕ) := by
      intro i hi
      let q : Fin k := eS.symm ⟨i, hi⟩
      have hAbs : (y_int i).natAbs ≤ k.factorial * U ^ k := by
        simp only [y_int, hi, ↓reduceDIte]
        have hsgn1 : sgn.natAbs = 1 := by dsimp [sgn]; split_ifs <;> rfl
        rw [Int.natAbs_mul, hsgn1, one_mul]
        change ((B_int.updateCol q rhs_int).det).natAbs ≤ k.factorial * U ^ k
        refine natAbs_det_le_factorial_mul_pow_int _ U (fun p q' => ?_)
        by_cases hqq : q' = q
        · subst hqq
          simp only [Matrix.updateCol_self, rhs_int]
          split_ifs <;> omega
        · simp only [Matrix.updateCol_ne hqq, B_int, Matrix.submatrix_apply, id_eq, C_int]
          refine Fin.lastCases ?_ (fun j => ?_) (ι p)
          · simpa using hd _
          · simpa using hM _ _
      have h1 : y_int i ≤ (y_int i).natAbs := Int.le_natAbs
      have h2 : k.factorial * U ^ k ≤ (n + 1).factorial * U ^ (n + 1) :=
        Nat.mul_le_mul (Nat.factorial_le hk_le) (Nat.pow_le_pow_right hU hk_le)
      omega
    calc ∑ i : Fin m, y_int i
        = ∑ i ∈ S, y_int i := by
            rw [← Finset.sum_subset (Finset.subset_univ S)]
            intro i _ hiS; simp [y_int, hiS]
      _ ≤ ∑ _i ∈ S, (((n + 1).factorial * U ^ (n + 1) : ℕ) : ℤ) :=
            Finset.sum_le_sum (fun i hi => hEach i hi)
      _ = (k : ℤ) * (((n + 1).factorial * U ^ (n + 1) : ℕ) : ℤ) := by simp [k]
      _ ≤ (((n + 1) * ((n + 1).factorial * U ^ (n + 1)) : ℕ) : ℤ) := by
            push_cast
            exact mul_le_mul_of_nonneg_right (by exact_mod_cast hk_le) (by positivity)
      _ = (((n + 1) * (n + 1).factorial * U ^ (n + 1) : ℕ) : ℤ) := by
            push_cast; ring

/-! ### 5. Perturbation Equivalence and Full-Dimensional Euclidean Ball Witness -/

theorem factorial_lt_two_pow_sq (k : ℕ) : k * k.factorial < 2 ^ ((k + 1) * (k + 1)) := by
  have h1 : k.factorial ≤ k ^ k := Nat.factorial_le_pow k
  have h2 : k < 2 ^ k := Nat.lt_two_pow_self
  rcases Nat.eq_zero_or_pos k with rfl | hk
  · norm_num
  · have h3 : k * k.factorial ≤ k * k ^ k := Nat.mul_le_mul_left k h1
    have h4 : k * k ^ k = k ^ (k + 1) := by rw [pow_succ']
    have h5 : k ^ (k + 1) < (2 ^ k) ^ (k + 1) :=
      Nat.pow_lt_pow_left h2 (by omega)
    have h6 : (2 ^ k) ^ (k + 1) ≤ 2 ^ ((k + 1) * (k + 1)) := by
      rw [← pow_mul]
      exact Nat.pow_le_pow_right (by omega) (Nat.mul_le_mul_right (k + 1) (by omega))
    omega

theorem bound_lt_two_pow_E (n L : ℕ) :
    (n + 1) * (n + 1).factorial * (2 ^ L) ^ (n + 1) < 2 ^ ((n + 2) * (n + 2 + L)) := by
  have h1 := factorial_lt_two_pow_sq (n + 1)
  have h2 : ((2 ^ L) ^ (n + 1) : ℕ) = 2 ^ (L * (n + 1)) := (pow_mul 2 L (n + 1)).symm
  rw [h2]
  calc (n + 1) * (n + 1).factorial * 2 ^ (L * (n + 1))
      < 2 ^ ((n + 2) * (n + 2)) * 2 ^ (L * (n + 1)) :=
        Nat.mul_lt_mul_of_pos_right h1 (by positivity)
    _ = 2 ^ ((n + 2) * (n + 2) + L * (n + 1)) := (pow_add 2 _ _).symm
    _ ≤ 2 ^ ((n + 2) * (n + 2 + L)) := by
        refine Nat.pow_le_pow_right (by omega) ?_
        nlinarith

theorem int_lp_perturbation_ball {n m L : ℕ} (hn : 2 ≤ n) (hL : 1 ≤ L)
    (M : Fin m → Fin n → ℤ) (d : Fin m → ℤ)
    (hM : ∀ (i : Fin m) (j : Fin n), (M i j).natAbs ≤ 2 ^ L)
    (hd : ∀ i : Fin m, (d i).natAbs ≤ 2 ^ L) :
    let E : ℕ := (n + 2) * (n + 2 + L)
    let Q : ℕ := 2 ^ (E + 1)
    let r : ℝ := (2 : ℝ) ^ (-(2 * E : ℤ))
    let R_init : ℝ := (2 : ℝ) ^ E
    ((∃ x : Fin n → ℝ, ∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * x j ≤ (d i : ℝ)) ↔
      (∃ x : Fin n → ℝ, ∀ i : Fin m,
        ∑ j : Fin n, (M i j : ℝ) * x j ≤ (d i : ℝ) + 1 / (Q : ℝ))) ∧
    ((∃ x : Fin n → ℝ, ∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * x j ≤ (d i : ℝ)) →
      ∃ x_star : Fin n → ℝ,
        (∀ x : Fin n → ℝ, (∑ j : Fin n, (x j - x_star j) ^ 2 ≤ r ^ 2) →
          ∑ j : Fin n, (x j) ^ 2 ≤ R_init ^ 2) ∧
        (∀ x : Fin n → ℝ, (∑ j : Fin n, (x j - x_star j) ^ 2 ≤ r ^ 2) →
          ∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * x j ≤ (d i : ℝ) + 1 / (Q : ℝ))) := by
  intro E Q r R_init
  have hU : 1 ≤ 2 ^ L := Nat.one_le_two_pow
  have hQ_pos : (0 : ℝ) < (Q : ℝ) := by dsimp [Q]; positivity
  have hBoundE := bound_lt_two_pow_E n L
  constructor
  · constructor
    · rintro ⟨x, hx⟩
      refine ⟨x, fun i => ?_⟩
      have : (0 : ℝ) ≤ 1 / (Q : ℝ) := by positivity
      linarith [hx i]
    · intro hPert
      by_contra hInfeas
      obtain ⟨y, hy_nn, hy_eq, hy_d, hy_sum⟩ :=
        int_lp_farkas_bounded M d (2 ^ L) hU hM hd hInfeas
      rcases hPert with ⟨x, hx⟩
      have h1 : ∑ i : Fin m, (y i : ℝ) * (∑ j : Fin n, (M i j : ℝ) * x j) ≤
          ∑ i : Fin m, (y i : ℝ) * ((d i : ℝ) + 1 / (Q : ℝ)) := by
        refine Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (hx i) ?_)
        exact_mod_cast hy_nn i
      have hLHS : ∑ i : Fin m, (y i : ℝ) * (∑ j : Fin n, (M i j : ℝ) * x j) = 0 := by
        calc ∑ i : Fin m, (y i : ℝ) * (∑ j : Fin n, (M i j : ℝ) * x j)
            = ∑ i : Fin m, ∑ j : Fin n, ((y i : ℝ) * (M i j : ℝ)) * x j := by
                refine Finset.sum_congr rfl (fun i _ => ?_)
                rw [Finset.mul_sum]
                exact Finset.sum_congr rfl (fun j _ => by ring)
          _ = ∑ j : Fin n, (∑ i : Fin m, (y i : ℝ) * (M i j : ℝ)) * x j := by
                rw [Finset.sum_comm]
                exact Finset.sum_congr rfl (fun j _ => (Finset.sum_mul _ _ _).symm)
          _ = 0 := by
                refine Finset.sum_eq_zero (fun j _ => ?_)
                have hj : ((∑ i : Fin m, y i * M i j : ℤ) : ℝ) = 0 := by exact_mod_cast hy_eq j
                push_cast at hj
                rw [hj, zero_mul]
      have hRHS_d : ∑ i : Fin m, (y i : ℝ) * (d i : ℝ) ≤ -1 := by exact_mod_cast hy_d
      have hSumY_lt : (∑ i : Fin m, (y i : ℝ)) < ((2 ^ E : ℕ) : ℝ) := by
        have hInt : ∑ i : Fin m, y i < (2 ^ E : ℕ) :=
          lt_of_le_of_lt hy_sum (by exact_mod_cast hBoundE)
        exact_mod_cast hInt
      have hQ_eq : (Q : ℝ) = 2 * ((2 ^ E : ℕ) : ℝ) := by
        dsimp [Q]
        rw [pow_succ']
        push_cast
        ring
      have hRHS_split : ∑ i : Fin m, (y i : ℝ) * ((d i : ℝ) + 1 / (Q : ℝ)) =
          (∑ i : Fin m, (y i : ℝ) * (d i : ℝ)) + (∑ i : Fin m, (y i : ℝ)) / (Q : ℝ) := by
        simp only [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul, mul_one_div,
          Finset.sum_div]
      have hDiv : (∑ i : Fin m, (y i : ℝ)) / (Q : ℝ) < 1 / 2 := by
        rw [div_lt_div_iff₀ hQ_pos (by norm_num), hQ_eq]
        linarith
      linarith
  · intro hFeas
    obtain ⟨x_star, hx_le, hx_abs⟩ := int_lp_bounded_primal M d (2 ^ L) hU hM hd hFeas
    refine ⟨x_star, ?_, ?_⟩
    · intro x hdist
      have hr_le_one : r ≤ 1 := by
        dsimp [r]
        exact zpow_le_one_of_nonpos₀ (by norm_num) (by omega)
      have hCoord : ∀ j : Fin n, |x j| ≤ (n.factorial : ℝ) * ((2 ^ L : ℕ) : ℝ) ^ n + 1 := by
        intro j
        have hsq : (x j - x_star j) ^ 2 ≤ r ^ 2 := by
          have hle := Finset.single_le_sum (f := fun k : Fin n => (x k - x_star k) ^ 2)
            (fun k _ => sq_nonneg _) (Finset.mem_univ j)
          exact hle.trans hdist
        have habs_diff : |x j - x_star j| ≤ r := by
          have hr0 : 0 ≤ r := by dsimp [r]; positivity
          simpa [abs_of_nonneg hr0] using sq_le_sq.mp hsq
        have htri : |x j| ≤ |x_star j| + |x j - x_star j| := by
          calc |x j| = |x_star j + (x j - x_star j)| := by ring_nf
            _ ≤ |x_star j| + |x j - x_star j| := abs_add_le _ _
        linarith [hx_abs j]
      have hNatB : n * (n.factorial * (2 ^ L) ^ n + 1) ≤ 2 ^ E := by
        have h1 : n.factorial * (2 ^ L) ^ n + 1 ≤ (n + 1).factorial * (2 ^ L) ^ (n + 1) := by
          have hf : 2 * n.factorial ≤ (n + 1).factorial := by
            rw [Nat.factorial_succ]
            exact Nat.mul_le_mul_right _ (by omega)
          have hp : (2 ^ L) ^ n ≤ (2 ^ L) ^ (n + 1) := Nat.pow_le_pow_right hU (by omega)
          have hp1 : 1 ≤ n.factorial * (2 ^ L) ^ (n + 1) :=
            Nat.mul_pos (Nat.factorial_pos n) (by positivity)
          calc n.factorial * (2 ^ L) ^ n + 1
              ≤ n.factorial * (2 ^ L) ^ (n + 1) + n.factorial * (2 ^ L) ^ (n + 1) :=
                Nat.add_le_add (Nat.mul_le_mul_left _ hp) hp1
            _ = 2 * n.factorial * (2 ^ L) ^ (n + 1) := by ring
            _ ≤ (n + 1).factorial * (2 ^ L) ^ (n + 1) := Nat.mul_le_mul_right _ hf
        calc n * (n.factorial * (2 ^ L) ^ n + 1)
            ≤ (n + 1) * ((n + 1).factorial * (2 ^ L) ^ (n + 1)) :=
              Nat.mul_le_mul (by omega) h1
          _ = (n + 1) * (n + 1).factorial * (2 ^ L) ^ (n + 1) := by ring
          _ ≤ 2 ^ E := hBoundE.le
      let B0 : ℝ := (n.factorial : ℝ) * ((2 ^ L : ℕ) : ℝ) ^ n + 1
      have hB0_nn : 0 ≤ B0 := by positivity
      have hnB0 : (n : ℝ) * B0 ≤ R_init := by
        dsimp [B0, R_init]
        exact_mod_cast hNatB
      have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
      calc ∑ j : Fin n, (x j) ^ 2
          = ∑ j : Fin n, |x j| ^ 2 := by simp [sq_abs]
        _ ≤ ∑ _j : Fin n, B0 ^ 2 :=
            Finset.sum_le_sum (fun j _ => pow_le_pow_left₀ (abs_nonneg _) (hCoord j) 2)
        _ = (n : ℝ) * B0 ^ 2 := by simp
        _ ≤ ((n : ℝ) * B0) ^ 2 := by nlinarith
        _ ≤ R_init ^ 2 := pow_le_pow_left₀ (by positivity) hnB0 2
    · intro x hdist i
      have hr0 : 0 ≤ r := by dsimp [r]; positivity
      have hDiff : ∀ j : Fin n, |x j - x_star j| ≤ r := fun j => by
        have hsq : (x j - x_star j) ^ 2 ≤ r ^ 2 :=
          (Finset.single_le_sum (f := fun k : Fin n => (x k - x_star k) ^ 2)
            (fun k _ => sq_nonneg _) (Finset.mem_univ j)).trans hdist
        simpa [abs_of_nonneg hr0] using sq_le_sq.mp hsq
      have hRowSplit : ∑ j : Fin n, (M i j : ℝ) * x j =
          (∑ j : Fin n, (M i j : ℝ) * x_star j) +
          ∑ j : Fin n, (M i j : ℝ) * (x j - x_star j) := by
        rw [← Finset.sum_add_distrib]
        exact Finset.sum_congr rfl (fun _ _ => by ring)
      have hErr : ∑ j : Fin n, (M i j : ℝ) * (x j - x_star j) ≤ (n : ℝ) * ((2 ^ L : ℕ) : ℝ) * r := by
        calc ∑ j : Fin n, (M i j : ℝ) * (x j - x_star j)
            ≤ ∑ j : Fin n, |(M i j : ℝ) * (x j - x_star j)| :=
              Finset.sum_le_sum (fun _ _ => le_abs_self _)
          _ ≤ ∑ _j : Fin n, ((2 ^ L : ℕ) : ℝ) * r := by
              refine Finset.sum_le_sum (fun j _ => ?_)
              rw [abs_mul]
              have hm_le : |(M i j : ℝ)| ≤ ((2 ^ L : ℕ) : ℝ) := by
                have habs := real_abs_int_eq_natAbs (M i j)
                rw [habs]
                exact_mod_cast hM i j
              exact mul_le_mul hm_le (hDiff j) (abs_nonneg _) (by positivity)
          _ = (n : ℝ) * ((2 ^ L : ℕ) : ℝ) * r := by simp [mul_assoc]
      have hSmall : (n : ℝ) * ((2 ^ L : ℕ) : ℝ) * r ≤ 1 / (Q : ℝ) := by
        have hNat : n * 2 ^ L * 2 ^ (E + 1) ≤ 2 ^ (2 * E) := by
          have hn2 : n ≤ 2 ^ n := Nat.lt_two_pow_self.le
          have hExp : n + L + (E + 1) ≤ 2 * E := by
            dsimp [E]
            nlinarith
          calc n * 2 ^ L * 2 ^ (E + 1)
              ≤ 2 ^ n * 2 ^ L * 2 ^ (E + 1) :=
                Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ hn2)
            _ = 2 ^ (n + L + (E + 1)) := by rw [← pow_add, ← pow_add]
            _ ≤ 2 ^ (2 * E) := Nat.pow_le_pow_right (by omega) hExp
        have hReal : (n : ℝ) * ((2 ^ L : ℕ) : ℝ) * (Q : ℝ) ≤ (2 : ℝ) ^ (2 * E) := by
          dsimp [Q]
          exact_mod_cast hNat
        have hr_inv : r = 1 / ((2 : ℝ) ^ (2 * E)) := by
          dsimp [r]
          have hexp : (-(2 * (E : ℤ))) = -(((2 * E : ℕ) : ℤ)) := by push_cast; ring
          rw [hexp, zpow_neg, zpow_natCast, one_div]
        rw [hr_inv]
        have h2E_pos : (0 : ℝ) < (2 : ℝ) ^ (2 * E) := by positivity
        rw [le_div_iff₀ hQ_pos]
        calc (n : ℝ) * ((2 ^ L : ℕ) : ℝ) * (1 / (2 : ℝ) ^ (2 * E)) * (Q : ℝ)
            = ((n : ℝ) * ((2 ^ L : ℕ) : ℝ) * (Q : ℝ)) / (2 : ℝ) ^ (2 * E) := by ring
          _ ≤ 1 := (div_le_one h2E_pos).mpr hReal
      linarith [hx_le i]

end UL.Proof.cit_gls88_rational_lp.RacerCG
