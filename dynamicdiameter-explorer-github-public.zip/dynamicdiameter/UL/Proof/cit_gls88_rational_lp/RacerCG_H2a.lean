import Mathlib
import UL.Proof.cit_gls88_rational_lp.RacerCG_H1a
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

/-! ### 1. Rank-1 Determinant & Exact Inflated Half-Ball Step -/

theorem det_one_sub_outer {N : ℕ} (u v : Fin N → ℝ) :
    (1 - Matrix.of (fun i j : Fin N => u i * v j)).det = 1 - ∑ i : Fin N, v i * u i := by
  let B : Matrix (Fin 1) (Fin N) ℝ := fun _ j => v j
  let C : Matrix (Fin N) (Fin 1) ℝ := fun i _ => u i
  have h1 := Matrix.det_fromBlocks_one₁₁ B C (1 : Matrix (Fin N) (Fin N) ℝ)
  have h2 := Matrix.det_fromBlocks_one₂₂ (1 : Matrix (Fin 1) (Fin 1) ℝ) B C
  have hCB : (1 : Matrix (Fin N) (Fin N) ℝ) - C * B =
      1 - Matrix.of (fun i j : Fin N => u i * v j) := by
    ext i j
    simp [Matrix.mul_apply, B, C]
  have hBC : ((1 : Matrix (Fin 1) (Fin 1) ℝ) - B * C).det = 1 - ∑ i : Fin N, v i * u i := by
    rw [Matrix.det_fin_one]
    simp [Matrix.mul_apply, B, C]
  rw [← hCB, ← h1, h2, hBC]

noncomputable def ellLam1 (N : ℕ) : ℝ := (N : ℝ) / ((N : ℝ) + 1)
noncomputable def ellLam2 (N : ℕ) : ℝ := (2 * (N : ℝ) ^ 2 - 1) / (2 * (N : ℝ) ^ 2 - 2)
noncomputable def ellInfl (N : ℕ) : ℝ := (8 * (N : ℝ) ^ 2 + 1) / (8 * (N : ℝ) ^ 2)

noncomputable def ellStepMat (N : ℕ) (w : Fin N → ℝ) : Matrix (Fin N) (Fin N) ℝ :=
  ellInfl N • (ellLam2 N • (1 : Matrix (Fin N) (Fin N) ℝ) -
    (ellLam2 N - ellLam1 N) • Matrix.of (fun i j : Fin N => w i * w j))

theorem ell_params_pos {N : ℕ} (hN : 2 ≤ N) :
    0 < ellLam1 N ∧ ellLam1 N < 1 ∧ 1 < ellLam2 N ∧ 1 < ellInfl N ∧
    ellLam2 N - ellLam1 N = (2 * (N : ℝ) - 1) / (2 * (N : ℝ) ^ 2 - 2) := by
  have hNR : (2 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
  have hd1 : (0 : ℝ) < (N : ℝ) + 1 := by linarith
  have hd2 : (0 : ℝ) < 2 * (N : ℝ) ^ 2 - 2 := by nlinarith only [hNR]
  have hd3 : (0 : ℝ) < 8 * (N : ℝ) ^ 2 := by nlinarith only [hNR]
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · unfold ellLam1; positivity
  · unfold ellLam1; rw [div_lt_one hd1]; linarith
  · unfold ellLam2; rw [one_lt_div hd2]; linarith
  · unfold ellInfl; rw [one_lt_div hd3]; linarith
  · unfold ellLam2 ellLam1
    rw [div_sub_div _ _ hd2.ne' hd1.ne', div_eq_div_iff (mul_ne_zero hd2.ne' hd1.ne') hd2.ne']
    ring

theorem ellStepMat_frobenius_le {N : ℕ} (hN : 2 ≤ N)
    (B_t : Matrix (Fin N) (Fin N) ℝ) (w : Fin N → ℝ) (hw : ∑ j : Fin N, (w j) ^ 2 ≤ 1) :
    ∑ i : Fin N, ∑ j : Fin N, ((B_t * ellStepMat N w) i j) ^ 2 ≤
      (7 / 4 : ℝ) ^ 2 * ∑ i : Fin N, ∑ j : Fin N, (B_t i j) ^ 2 := by
  have hNR : (2 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
  obtain ⟨hl1_pos, hl1_lt1, hl2_gt1, hinfl_gt1, _⟩ := ell_params_pos hN
  let l1 := ellLam1 N
  let l2 := ellLam2 N
  let inf := ellInfl N
  have hinf_l2 : inf * l2 ≤ 7 / 4 := by
    dsimp [inf, l2, ellInfl, ellLam2]
    have hd2 : (0 : ℝ) < 2 * (N : ℝ) ^ 2 - 2 := by nlinarith only [hNR]
    have hd3 : (0 : ℝ) < 8 * (N : ℝ) ^ 2 := by nlinarith only [hNR]
    have h1 : (8 * (N : ℝ) ^ 2 + 1) / (8 * (N : ℝ) ^ 2) ≤ 33 / 32 := by
      rw [div_le_div_iff₀ hd3 (by norm_num)]; nlinarith only [hNR]
    have h2 : (2 * (N : ℝ) ^ 2 - 1) / (2 * (N : ℝ) ^ 2 - 2) ≤ 7 / 6 := by
      rw [div_le_div_iff₀ hd2 (by norm_num)]; nlinarith only [hNR]
    calc ((8 * (N : ℝ) ^ 2 + 1) / (8 * (N : ℝ) ^ 2)) *
          ((2 * (N : ℝ) ^ 2 - 1) / (2 * (N : ℝ) ^ 2 - 2))
        ≤ (33 / 32) * (7 / 6) := mul_le_mul h1 h2 (by positivity) (by norm_num)
      _ ≤ 7 / 4 := by norm_num
  have hRow : ∀ i : Fin N,
      ∑ j : Fin N, ((B_t * ellStepMat N w) i j) ^ 2 ≤ (7 / 4 : ℝ) ^ 2 * ∑ j : Fin N, (B_t i j) ^ 2 := by
    intro i
    let s : ℝ := ∑ k : Fin N, B_t i k * w k
    let γ : ℝ := ∑ j : Fin N, (w j) ^ 2
    have hEntry : ∀ j : Fin N,
        (B_t * ellStepMat N w) i j = inf * (l2 * B_t i j - (l2 - l1) * s * w j) := by
      intro j
      simp only [ellStepMat, Matrix.mul_apply, Matrix.smul_apply, Matrix.sub_apply,
        Matrix.one_apply, Matrix.of_apply, smul_eq_mul]
      have h1 : ∑ k : Fin N, B_t i k * (inf * (l2 * (if k = j then 1 else 0) - (l2 - l1) * (w k * w j))) =
          (∑ k : Fin N, if k = j then inf * l2 * B_t i k else 0) -
            (inf * (l2 - l1) * w j) * (∑ k : Fin N, B_t i k * w k) := by
        rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
        refine Finset.sum_congr rfl (fun k _ => ?_)
        by_cases hkj : k = j <;> simp [hkj] <;> ring
      change ∑ k : Fin N, B_t i k * (inf * (l2 * (if k = j then 1 else 0) - (l2 - l1) * (w k * w j))) = _
      rw [h1]
      simp only [Finset.sum_ite_eq', Finset.mem_univ, ↓reduceIte, s]
      ring
    have hExpand : ∑ j : Fin N, (l2 * B_t i j - (l2 - l1) * s * w j) ^ 2 =
        l2 ^ 2 * (∑ j : Fin N, (B_t i j) ^ 2) -
          (l2 - l1) * (2 * l2 - (l2 - l1) * γ) * s ^ 2 := by
      calc ∑ j : Fin N, (l2 * B_t i j - (l2 - l1) * s * w j) ^ 2
          = ∑ j : Fin N, (l2 ^ 2 * (B_t i j) ^ 2 -
              (2 * l2 * (l2 - l1) * s) * (B_t i j * w j) +
              ((l2 - l1) ^ 2 * s ^ 2) * (w j) ^ 2) := by
              refine Finset.sum_congr rfl (fun j _ => by ring)
        _ = l2 ^ 2 * (∑ j : Fin N, (B_t i j) ^ 2) -
              (2 * l2 * (l2 - l1) * s) * s +
              ((l2 - l1) ^ 2 * s ^ 2) * γ := by
              simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum, s, γ]
        _ = l2 ^ 2 * (∑ j : Fin N, (B_t i j) ^ 2) -
              (l2 - l1) * (2 * l2 - (l2 - l1) * γ) * s ^ 2 := by ring
    have hNonnegTerm : 0 ≤ (l2 - l1) * (2 * l2 - (l2 - l1) * γ) * s ^ 2 := by
      have hdiff : 0 ≤ l2 - l1 := by linarith
      have h2l2 : 0 ≤ 2 * l2 - (l2 - l1) * γ := by
        have hγ : (l2 - l1) * γ ≤ l2 - l1 := mul_le_of_le_one_right hdiff hw
        linarith
      exact mul_nonneg (mul_nonneg hdiff h2l2) (sq_nonneg s)
    have hSumInner : ∑ j : Fin N, (l2 * B_t i j - (l2 - l1) * s * w j) ^ 2 ≤
        l2 ^ 2 * ∑ j : Fin N, (B_t i j) ^ 2 := by
      linarith [hExpand]
    calc ∑ j : Fin N, ((B_t * ellStepMat N w) i j) ^ 2
        = ∑ j : Fin N, inf ^ 2 * (l2 * B_t i j - (l2 - l1) * s * w j) ^ 2 := by
            refine Finset.sum_congr rfl (fun j _ => by rw [hEntry j]; ring)
      _ = inf ^ 2 * ∑ j : Fin N, (l2 * B_t i j - (l2 - l1) * s * w j) ^ 2 := by
            rw [← Finset.mul_sum]
      _ ≤ inf ^ 2 * (l2 ^ 2 * ∑ j : Fin N, (B_t i j) ^ 2) :=
            mul_le_mul_of_nonneg_left hSumInner (sq_nonneg inf)
      _ = (inf * l2) ^ 2 * ∑ j : Fin N, (B_t i j) ^ 2 := by ring
      _ ≤ (7 / 4 : ℝ) ^ 2 * ∑ j : Fin N, (B_t i j) ^ 2 := by
            refine mul_le_mul_of_nonneg_right ?_ (Finset.sum_nonneg (fun _ _ => sq_nonneg _))
            exact pow_le_pow_left₀ (by positivity) hinf_l2 2
  calc ∑ i : Fin N, ∑ j : Fin N, ((B_t * ellStepMat N w) i j) ^ 2
      ≤ ∑ i : Fin N, (7 / 4 : ℝ) ^ 2 * ∑ j : Fin N, (B_t i j) ^ 2 :=
        Finset.sum_le_sum (fun i _ => hRow i)
    _ = (7 / 4 : ℝ) ^ 2 * ∑ i : Fin N, ∑ j : Fin N, (B_t i j) ^ 2 := by
        rw [← Finset.mul_sum]

theorem exact_half_ball_step {N : ℕ} (hN : 2 ≤ N)
    (g_hat : Fin N → ℝ) (hg : ∑ j : Fin N, (g_hat j) ^ 2 = 1)
    (ρ : ℝ) (hρ_lo : 1 - 1 / (16 * (N : ℝ) ^ 2) ≤ ρ) (hρ_hi : ρ ≤ 1) :
    let w : Fin N → ℝ := fun j => ρ * g_hat j
    let M_step := ellStepMat N w
    (∀ u : Fin N → ℝ, (∑ j : Fin N, (u j) ^ 2 ≤ 1) → (∑ j : Fin N, g_hat j * u j ≤ 0) →
      ∃ u' : Fin N → ℝ,
        M_step.mulVec u' = (fun j => u j + (1 / ((N : ℝ) + 1)) * w j) ∧
        ∑ j : Fin N, (u' j) ^ 2 ≤ (1 / ellInfl N) ^ 2) ∧
    |M_step.det| ≤ Real.exp (- 1 / (5 * ((N : ℝ) + 1))) := by
  intro w M_step
  have hNR : (2 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
  obtain ⟨hl1_pos, hl1_lt1, hl2_gt1, hinfl_gt1, hdiff_eq⟩ := ell_params_pos hN
  let l1 := ellLam1 N
  let l2 := ellLam2 N
  let inf := ellInfl N
  have hρ_pos : 0 < ρ := by
    have h16 : 1 / (16 * (N : ℝ) ^ 2) ≤ 1 / 64 := by
      rw [div_le_div_iff₀ (by nlinarith only [hNR]) (by norm_num)]
      nlinarith only [hNR]
    linarith
  have hρ2_le1 : ρ ^ 2 ≤ 1 := by nlinarith only [hρ_pos, hρ_hi]
  let l1' : ℝ := l2 - ρ ^ 2 * (l2 - l1)
  have hl1'_ge_l1 : l1 ≤ l1' := by
    dsimp [l1']
    have : ρ ^ 2 * (l2 - l1) ≤ 1 * (l2 - l1) :=
      mul_le_mul_of_nonneg_right hρ2_le1 (by linarith)
    linarith
  have hl1'_pos : 0 < l1' := lt_of_lt_of_le hl1_pos hl1'_ge_l1
  have hl1'_le_l2 : l1' ≤ l2 := by
    dsimp [l1']
    have : 0 ≤ ρ ^ 2 * (l2 - l1) := mul_nonneg (sq_nonneg ρ) (by linarith)
    linarith
  have hw_sq : ∑ j : Fin N, (w j) ^ 2 = ρ ^ 2 := by
    have h1 : ∀ j : Fin N, (w j) ^ 2 = ρ ^ 2 * (g_hat j) ^ 2 := fun j => by dsimp [w]; ring
    simp_rw [h1, ← Finset.mul_sum, hg, mul_one]
  constructor
  · intro u hu_sq hu_cut
    let β : ℝ := ∑ j : Fin N, g_hat j * u j
    have hβ_le0 : β ≤ 0 := hu_cut
    have hβ_ge_neg1 : -1 ≤ β := by
      have h0 : 0 ≤ ∑ j : Fin N, (u j + g_hat j) ^ 2 :=
        Finset.sum_nonneg (fun _ _ => sq_nonneg _)
      have hexp : ∑ j : Fin N, (u j + g_hat j) ^ 2 =
          (∑ j : Fin N, (u j) ^ 2) + 2 * β + (∑ j : Fin N, (g_hat j) ^ 2) := by
        calc ∑ j : Fin N, (u j + g_hat j) ^ 2
            = ∑ j : Fin N, ((u j) ^ 2 + 2 * (g_hat j * u j) + (g_hat j) ^ 2) :=
                Finset.sum_congr rfl (fun _ _ => by ring)
          _ = (∑ j : Fin N, (u j) ^ 2) + 2 * β + (∑ j : Fin N, (g_hat j) ^ 2) := by
                simp only [Finset.sum_add_distrib, ← Finset.mul_sum, β]
      rw [hexp, hg] at h0
      linarith
    let u_perp : Fin N → ℝ := fun j => u j - β * g_hat j
    have horth : ∑ j : Fin N, g_hat j * u_perp j = 0 := by
      calc ∑ j : Fin N, g_hat j * (u j - β * g_hat j)
          = (∑ j : Fin N, g_hat j * u j) - β * (∑ j : Fin N, (g_hat j) ^ 2) := by
              have hpt : ∀ j : Fin N, g_hat j * (u j - β * g_hat j) =
                  g_hat j * u j - β * (g_hat j) ^ 2 := fun _ => by ring
              simp_rw [hpt, Finset.sum_sub_distrib, ← Finset.mul_sum]
        _ = 0 := by rw [hg]; dsimp [β]; ring
    have hperp_sq : ∑ j : Fin N, (u_perp j) ^ 2 ≤ 1 - β ^ 2 := by
      have hexp : ∑ j : Fin N, (u_perp j) ^ 2 = (∑ j : Fin N, (u j) ^ 2) - β ^ 2 := by
        calc ∑ j : Fin N, (u j - β * g_hat j) ^ 2
            = ∑ j : Fin N, ((u j) ^ 2 - 2 * β * (g_hat j * u j) + β ^ 2 * (g_hat j) ^ 2) :=
                Finset.sum_congr rfl (fun _ _ => by ring)
          _ = (∑ j : Fin N, (u j) ^ 2) - 2 * β * β + β ^ 2 * (∑ j : Fin N, (g_hat j) ^ 2) := by
                simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum, β]
          _ = (∑ j : Fin N, (u j) ^ 2) - β ^ 2 := by rw [hg]; ring
      linarith
    let αt : ℝ := ρ / ((N : ℝ) + 1)
    let c1 : ℝ := (β + αt) / l1'
    let c2 : ℝ := 1 / l2
    let u' : Fin N → ℝ := fun j => (1 / inf) * (c1 * g_hat j + c2 * u_perp j)
    refine ⟨u', ?_, ?_⟩
    · ext i
      simp only [M_step, ellStepMat, Matrix.smul_mulVec_assoc, Pi.smul_apply, smul_eq_mul,
        Matrix.sub_mulVec, Matrix.one_mulVec]
      have hDotW : ∑ j : Fin N, w j * u' j = (1 / inf) * (c1 * ρ) := by
        calc ∑ j : Fin N, (ρ * g_hat j) * ((1 / inf) * (c1 * g_hat j + c2 * u_perp j))
            = (1 / inf) * c1 * ρ * (∑ j : Fin N, (g_hat j) ^ 2) +
                (1 / inf) * c2 * ρ * (∑ j : Fin N, g_hat j * u_perp j) := by
                have hpt : ∀ j : Fin N,
                    (ρ * g_hat j) * ((1 / inf) * (c1 * g_hat j + c2 * u_perp j)) =
                    ((1 / inf) * c1 * ρ) * (g_hat j) ^ 2 +
                      ((1 / inf) * c2 * ρ) * (g_hat j * u_perp j) := fun _ => by ring
                simp_rw [hpt, Finset.sum_add_distrib, ← Finset.mul_sum]
          _ = (1 / inf) * (c1 * ρ) := by rw [hg, horth]; ring
      have hMatW : (Matrix.of (fun a b : Fin N => w a * w b)).mulVec u' i =
          w i * (∑ j : Fin N, w j * u' j) := by
        simp only [Matrix.mulVec, dotProduct, Matrix.of_apply, mul_assoc, ← Finset.mul_sum]
      change inf * (l2 * u' i - (l2 - l1) * (Matrix.of (fun a b => w a * w b)).mulVec u' i) =
        u i + 1 / ((N : ℝ) + 1) * w i
      rw [hMatW, hDotW]
      dsimp only [u', w, u_perp, c1, c2, αt, l1']
      have hinf_ne : inf ≠ 0 := by linarith
      have hl1'_ne : l2 - ρ ^ 2 * (l2 - l1) ≠ 0 := hl1'_pos.ne'
      have hl2_ne : l2 ≠ 0 := by linarith
      field_simp [hinf_ne, hl1'_ne, hl2_ne]
      ring
    · have hExpandU' : ∑ j : Fin N, (c1 * g_hat j + c2 * u_perp j) ^ 2 =
          c1 ^ 2 + c2 ^ 2 * ∑ j : Fin N, (u_perp j) ^ 2 := by
        calc ∑ j : Fin N, (c1 * g_hat j + c2 * u_perp j) ^ 2
            = c1 ^ 2 * (∑ j : Fin N, (g_hat j) ^ 2) +
                (2 * c1 * c2) * (∑ j : Fin N, g_hat j * u_perp j) +
                c2 ^ 2 * (∑ j : Fin N, (u_perp j) ^ 2) := by
                have hpt : ∀ j : Fin N, (c1 * g_hat j + c2 * u_perp j) ^ 2 =
                    c1 ^ 2 * (g_hat j) ^ 2 + (2 * c1 * c2) * (g_hat j * u_perp j) +
                      c2 ^ 2 * (u_perp j) ^ 2 := fun _ => by ring
                simp_rw [hpt, Finset.sum_add_distrib, ← Finset.mul_sum]
          _ = c1 ^ 2 + c2 ^ 2 * ∑ j : Fin N, (u_perp j) ^ 2 := by rw [hg, horth]; ring
      let f0 : ℝ := (αt / l1') ^ 2 + (1 / l2) ^ 2
      let fm1 : ℝ := ((1 - αt) / l1') ^ 2
      have hId : c1 ^ 2 + c2 ^ 2 * (1 - β ^ 2) =
          (-β) * fm1 + (1 + β) * f0 + (1 / l1' ^ 2 - 1 / l2 ^ 2) * β * (β + 1) := by
        dsimp [c1, c2, f0, fm1]
        ring
      have hQuadNeg : (1 / l1' ^ 2 - 1 / l2 ^ 2) * β * (β + 1) ≤ 0 := by
        have h1 : 1 / l2 ^ 2 ≤ 1 / l1' ^ 2 :=
          one_div_le_one_div_of_le (sq_pos_of_pos hl1'_pos)
            (pow_le_pow_left₀ hl1'_pos.le hl1'_le_l2 2)
        have h2 : β * (β + 1) ≤ 0 := mul_nonpos_of_nonpos_of_nonneg hβ_le0 (by linarith)
        have h3 : 0 ≤ 1 / l1' ^ 2 - 1 / l2 ^ 2 := sub_nonneg.mpr h1
        exact mul_nonpos_of_nonneg_of_nonpos h3 (by simpa [mul_assoc] using h2) |> fun _ => by
          rw [mul_assoc]
          exact mul_nonpos_of_nonneg_of_nonpos h3 h2
      have hfm1_le1 : fm1 ≤ 1 := by
        dsimp [fm1]
        have hα_lt1 : 0 ≤ 1 - αt := by
          dsimp [αt]
          rw [sub_nonneg, div_le_one (by linarith)]
          linarith
        have hle_l1' : 1 - αt ≤ l1' := by
          have hd1 : (0 : ℝ) < (N : ℝ) + 1 := by linarith
          have hdiff_gt : 1 / ((N : ℝ) + 1) ≤ l2 - l1 := by
            have hl1_eq : 1 - l1 = 1 / ((N : ℝ) + 1) := by
              dsimp [l1, ellLam1]; field_simp [hd1.ne']; ring
            linarith
          have hprod : 1 / ((N : ℝ) + 1) ≤ (1 + ρ) * (l2 - l1) := by
            calc 1 / ((N : ℝ) + 1) = 1 * (1 / ((N : ℝ) + 1)) := by ring
              _ ≤ (1 + ρ) * (l2 - l1) :=
                  mul_le_mul (by linarith) hdiff_gt (by positivity) (by linarith)
          have hid2 : l1' - (1 - αt) =
              (1 - ρ) * ((1 + ρ) * (l2 - l1) - 1 / ((N : ℝ) + 1)) := by
            dsimp [l1', αt, l1, ellLam1]
            field_simp [hd1.ne']
            ring
          have hnn : 0 ≤ (1 - ρ) * ((1 + ρ) * (l2 - l1) - 1 / ((N : ℝ) + 1)) :=
            mul_nonneg (by linarith) (by linarith)
          linarith
        have hdiv : (1 - αt) / l1' ≤ 1 := (div_le_one hl1'_pos).mpr hle_l1'
        have hdiv_nn : 0 ≤ (1 - αt) / l1' := div_nonneg hα_lt1 hl1'_pos.le
        exact pow_le_one₀ hdiv_nn hdiv
      have hf0_le1 : f0 ≤ 1 := by
        dsimp [f0]
        have hα_div : αt / l1' ≤ 1 / (N : ℝ) := by
          have h1 : αt ≤ 1 / ((N : ℝ) + 1) := by
            dsimp [αt]
            exact div_le_div_of_nonneg_right hρ_hi (by linarith)
          have h2 : αt / l1' ≤ (1 / ((N : ℝ) + 1)) / l1 :=
            div_le_div₀ (by positivity) h1 hl1_pos hl1'_ge_l1
          have h3 : (1 / ((N : ℝ) + 1)) / l1 = 1 / (N : ℝ) := by
            dsimp [l1, ellLam1]
            have hd1 : ((N : ℝ) + 1) ≠ 0 := by linarith
            have hn0 : (N : ℝ) ≠ 0 := by linarith
            field_simp [hd1, hn0]
          linarith
        have hsq1 : (αt / l1') ^ 2 ≤ (1 / (N : ℝ)) ^ 2 :=
          pow_le_pow_left₀ (by positivity) hα_div 2
        have hsum_exact : (1 / (N : ℝ)) ^ 2 + (1 / l2) ^ 2 ≤ 1 := by
          dsimp [l2, ellLam2]
          have hn0 : (N : ℝ) ≠ 0 := by linarith
          have hd2 : (0 : ℝ) < 2 * (N : ℝ) ^ 2 - 1 := by nlinarith only [hNR]
          have hinv : 1 / ((2 * (N : ℝ) ^ 2 - 1) / (2 * (N : ℝ) ^ 2 - 2)) =
              (2 * (N : ℝ) ^ 2 - 2) / (2 * (N : ℝ) ^ 2 - 1) := one_div_div _ _
          rw [hinv]
          have hden_pos : (0 : ℝ) < (N : ℝ) ^ 2 * (2 * (N : ℝ) ^ 2 - 1) ^ 2 := by positivity
          apply le_of_mul_le_mul_right _ hden_pos
          have hLHS : ((1 / (N : ℝ)) ^ 2 +
              ((2 * (N : ℝ) ^ 2 - 2) / (2 * (N : ℝ) ^ 2 - 1)) ^ 2) *
              ((N : ℝ) ^ 2 * (2 * (N : ℝ) ^ 2 - 1) ^ 2) =
              4 * (N : ℝ) ^ 6 - 4 * (N : ℝ) ^ 4 + 1 := by
            have ht1 : (1 / (N : ℝ)) ^ 2 * ((N : ℝ) ^ 2 * (2 * (N : ℝ) ^ 2 - 1) ^ 2) =
                (2 * (N : ℝ) ^ 2 - 1) ^ 2 := by
              rw [div_pow, one_pow, ← mul_assoc, div_mul_cancel₀ _ (pow_ne_zero 2 hn0), one_mul]
            have ht2 : ((2 * (N : ℝ) ^ 2 - 2) / (2 * (N : ℝ) ^ 2 - 1)) ^ 2 *
                ((N : ℝ) ^ 2 * (2 * (N : ℝ) ^ 2 - 1) ^ 2) =
                (N : ℝ) ^ 2 * (2 * (N : ℝ) ^ 2 - 2) ^ 2 := by
              rw [div_pow, mul_comm ((N : ℝ) ^ 2), ← mul_assoc,
                div_mul_cancel₀ _ (pow_ne_zero 2 hd2.ne'), mul_comm]
            rw [add_mul, ht1, ht2]
            ring
          have hRHS : 1 * ((N : ℝ) ^ 2 * (2 * (N : ℝ) ^ 2 - 1) ^ 2) =
              4 * (N : ℝ) ^ 6 - 4 * (N : ℝ) ^ 4 + (N : ℝ) ^ 2 := by ring
          rw [hLHS, hRHS]
          nlinarith only [hNR]
        linarith
      have hInnerLe1 : c1 ^ 2 + c2 ^ 2 * ∑ j : Fin N, (u_perp j) ^ 2 ≤ 1 := by
        have hle1 : c1 ^ 2 + c2 ^ 2 * ∑ j : Fin N, (u_perp j) ^ 2 ≤
            c1 ^ 2 + c2 ^ 2 * (1 - β ^ 2) :=
          add_le_add_right (mul_le_mul_of_nonneg_left hperp_sq (sq_nonneg c2)) _ |> fun _ => by
            linarith [mul_le_mul_of_nonneg_left hperp_sq (sq_nonneg c2)]
        have ht1 : (-β) * fm1 ≤ (-β) * 1 :=
          mul_le_mul_of_nonneg_left hfm1_le1 (by linarith)
        have ht2 : (1 + β) * f0 ≤ (1 + β) * 1 :=
          mul_le_mul_of_nonneg_left hf0_le1 (by linarith)
        linarith [hle1, hId, hQuadNeg, ht1, ht2]
      calc ∑ j : Fin N, (u' j) ^ 2
          = (1 / inf) ^ 2 * ∑ j : Fin N, (c1 * g_hat j + c2 * u_perp j) ^ 2 := by
              rw [Finset.mul_sum]
              exact Finset.sum_congr rfl (fun j _ => by dsimp [u']; ring)
        _ = (1 / inf) ^ 2 * (c1 ^ 2 + c2 ^ 2 * ∑ j : Fin N, (u_perp j) ^ 2) := by
              rw [hExpandU']
        _ ≤ (1 / inf) ^ 2 * 1 :=
              mul_le_mul_of_nonneg_left hInnerLe1 (sq_nonneg _)
        _ = (1 / inf) ^ 2 := mul_one _
  · have hFactor : M_step = (inf * l2) •
        ((1 : Matrix (Fin N) (Fin N) ℝ) -
          Matrix.of (fun i j : Fin N => (((l2 - l1) / l2) * w i) * w j)) := by
      ext i j
      simp only [M_step, ellStepMat, Matrix.smul_apply, Matrix.sub_apply, Matrix.one_apply,
        Matrix.of_apply, smul_eq_mul]
      have hl2_ne : l2 ≠ 0 := by linarith
      field_simp [hl2_ne]
      ring
    have hDetEq : M_step.det = inf ^ N * l2 ^ (N - 1) * l1' := by
      rw [hFactor, Matrix.det_smul, Fintype.card_fin, det_one_sub_outer]
      have hSumW : ∑ i : Fin N, w i * (((l2 - l1) / l2) * w i) = ((l2 - l1) / l2) * ρ ^ 2 := by
        rw [← hw_sq, Finset.mul_sum]
        exact Finset.sum_congr rfl (fun _ _ => by ring)
      rw [hSumW, mul_pow]
      have hl2N : l2 ^ N = l2 ^ (N - 1) * l2 := by
        have hN_split : N = (N - 1) + 1 := by omega
        conv_lhs => rw [hN_split, pow_succ]
      rw [hl2N]
      have hl2_ne : l2 ≠ 0 := by linarith
      dsimp only [l1']
      field_simp [hl2_ne]
    have hDetPos : 0 < M_step.det := by
      rw [hDetEq]
      have : 0 < inf := by linarith
      have : 0 < l2 := by linarith
      positivity
    rw [abs_of_pos hDetPos, hDetEq]
    have hExp1 : inf ^ N ≤ Real.exp (1 / (8 * (N : ℝ))) := by
      have h1 : inf ≤ Real.exp (1 / (8 * (N : ℝ) ^ 2)) := by
        have hid : inf = 1 / (8 * (N : ℝ) ^ 2) + 1 := by
          dsimp [inf, ellInfl]
          have hd3 : 8 * (N : ℝ) ^ 2 ≠ 0 := by nlinarith only [hNR]
          field_simp [hd3]; ring
        rw [hid]
        exact Real.add_one_le_exp _
      calc inf ^ N
          ≤ (Real.exp (1 / (8 * (N : ℝ) ^ 2))) ^ N :=
            pow_le_pow_left₀ (by linarith) h1 N
        _ = Real.exp ((N : ℝ) * (1 / (8 * (N : ℝ) ^ 2))) := (Real.exp_nat_mul _ N).symm
        _ = Real.exp (1 / (8 * (N : ℝ))) := by
            congr 1
            have hn0 : (N : ℝ) ≠ 0 := by linarith
            field_simp [hn0]
    have hExp2 : l2 ^ (N - 1) ≤ Real.exp (1 / (2 * ((N : ℝ) + 1))) := by
      have h1 : l2 ≤ Real.exp (1 / (2 * (N : ℝ) ^ 2 - 2)) := by
        have hid : l2 = 1 / (2 * (N : ℝ) ^ 2 - 2) + 1 := by
          dsimp only [l2, ellLam2]
          have hd2 : 2 * (N : ℝ) ^ 2 - 2 ≠ 0 := by nlinarith only [hNR]
          have hnum : 2 * (N : ℝ) ^ 2 - 1 = 1 + (2 * (N : ℝ) ^ 2 - 2) := by ring
          rw [hnum, add_div, div_self hd2]
        rw [hid]
        exact Real.add_one_le_exp _
      calc l2 ^ (N - 1)
          ≤ (Real.exp (1 / (2 * (N : ℝ) ^ 2 - 2))) ^ (N - 1) :=
            pow_le_pow_left₀ (by linarith) h1 (N - 1)
        _ = Real.exp (((N - 1 : ℕ) : ℝ) * (1 / (2 * (N : ℝ) ^ 2 - 2))) :=
            (Real.exp_nat_mul _ (N - 1)).symm
        _ = Real.exp (1 / (2 * ((N : ℝ) + 1))) := by
            congr 1
            have hcast : ((N - 1 : ℕ) : ℝ) = (N : ℝ) - 1 := by
              rw [Nat.cast_sub (by omega), Nat.cast_one]
            rw [hcast]
            have hnm1 : (N : ℝ) - 1 ≠ 0 := by linarith
            have hnp1 : (N : ℝ) + 1 ≠ 0 := by linarith
            have hd2 : 2 * (N : ℝ) ^ 2 - 2 = 2 * ((N : ℝ) - 1) * ((N : ℝ) + 1) := by ring
            rw [hd2]
            field_simp [hnm1, hnp1]
    have hExp3 : l1' ≤ Real.exp (- (15 / 16) / ((N : ℝ) + 1)) := by
      have h1mρ2 : 1 - ρ ^ 2 ≤ 1 / (8 * (N : ℝ) ^ 2) := by
        have h1mρ : 1 - ρ ≤ 1 / (16 * (N : ℝ) ^ 2) := by linarith
        calc 1 - ρ ^ 2 = (1 - ρ) * (1 + ρ) := by ring
          _ ≤ (1 / (16 * (N : ℝ) ^ 2)) * 2 :=
              mul_le_mul h1mρ (by linarith) (by linarith) (by positivity)
          _ = 1 / (8 * (N : ℝ) ^ 2) := by ring
      have hdiff_le : l2 - l1 ≤ 2 / ((N : ℝ) + 1) := by
        rw [hdiff_eq, div_le_div_iff₀ (by nlinarith only [hNR]) (by linarith)]
        nlinarith only [hNR]
      have hl1'_ub : l1' ≤ (- (15 / 16) / ((N : ℝ) + 1)) + 1 := by
        have hEq : l1' = l1 + (1 - ρ ^ 2) * (l2 - l1) := by dsimp [l1']; ring
        rw [hEq]
        have hProd : (1 - ρ ^ 2) * (l2 - l1) ≤ (1 / (8 * (N : ℝ) ^ 2)) * (2 / ((N : ℝ) + 1)) :=
          mul_le_mul h1mρ2 hdiff_le (by linarith) (by positivity)
        have hProd2 : (1 / (8 * (N : ℝ) ^ 2)) * (2 / ((N : ℝ) + 1)) ≤
            (1 / 16) / ((N : ℝ) + 1) := by
          have h8 : 1 / (8 * (N : ℝ) ^ 2) ≤ 1 / 32 := by
            rw [div_le_div_iff₀ (by nlinarith only [hNR]) (by norm_num)]; nlinarith only [hNR]
          calc (1 / (8 * (N : ℝ) ^ 2)) * (2 / ((N : ℝ) + 1))
              ≤ (1 / 32) * (2 / ((N : ℝ) + 1)) :=
                mul_le_mul_of_nonneg_right h8 (by positivity)
            _ = (1 / 16) / ((N : ℝ) + 1) := by ring
        have hl1_eq : l1 = 1 - 1 / ((N : ℝ) + 1) := by
          dsimp [l1, ellLam1]
          have hd1 : (N : ℝ) + 1 ≠ 0 := by linarith
          field_simp [hd1]; ring
        have hChain : (1 - ρ ^ 2) * (l2 - l1) ≤ (1 / 16) / ((N : ℝ) + 1) := hProd.trans hProd2
        have hSub : 1 - 1 / ((N : ℝ) + 1) + (1 / 16) / ((N : ℝ) + 1) =
            (- (15 / 16) / ((N : ℝ) + 1)) + 1 := by ring
        linarith [hChain, hl1_eq, hSub]
      exact hl1'_ub.trans (Real.add_one_le_exp _)
    calc inf ^ N * l2 ^ (N - 1) * l1'
        ≤ Real.exp (1 / (8 * (N : ℝ))) * Real.exp (1 / (2 * ((N : ℝ) + 1))) *
            Real.exp (- (15 / 16) / ((N : ℝ) + 1)) := by
          refine mul_le_mul (mul_le_mul hExp1 hExp2 (by positivity) (by positivity))
            hExp3 hl1'_pos.le (by positivity)
      _ = Real.exp (1 / (8 * (N : ℝ)) + 1 / (2 * ((N : ℝ) + 1)) +
            (- (15 / 16) / ((N : ℝ) + 1))) := by
          rw [← Real.exp_add, ← Real.exp_add]
      _ ≤ Real.exp (- 1 / (5 * ((N : ℝ) + 1))) := by
          rw [Real.exp_le_exp]
          have h1 : 1 / (8 * (N : ℝ)) ≤ (3 / 16) / ((N : ℝ) + 1) := by
            rw [div_le_div_iff₀ (by linarith) (by linarith)]
            linarith
          have h2 : (3 / 16) / ((N : ℝ) + 1) + 1 / (2 * ((N : ℝ) + 1)) +
              (- (15 / 16) / ((N : ℝ) + 1)) = - 1 / (4 * ((N : ℝ) + 1)) := by
            have hd1 : (N : ℝ) + 1 ≠ 0 := by linarith
            field_simp [hd1]; ring
          have h3 : - 1 / (4 * ((N : ℝ) + 1)) ≤ - 1 / (5 * ((N : ℝ) + 1)) := by
            have hd4 : (0 : ℝ) < 4 * ((N : ℝ) + 1) := by linarith
            have hd5 : (0 : ℝ) < 5 * ((N : ℝ) + 1) := by linarith
            rw [neg_div, neg_div, neg_le_neg_iff, div_le_div_iff₀ hd5 hd4]
            linarith
          linarith

/-! ### 2. Ball-in-Ellipsoid Right Inverse & Rounded Step Preservation -/

theorem ball_in_ellipsoid_right_inv {N : ℕ} {r : ℝ} (hr : 0 < r)
    (x_star c : Fin N → ℝ) (B : Matrix (Fin N) (Fin N) ℝ)
    (hBall : ∀ x : Fin N → ℝ, (∑ j : Fin N, (x j - x_star j) ^ 2 ≤ r ^ 2) →
      ∃ v : Fin N → ℝ, (∑ j : Fin N, (v j) ^ 2 ≤ 1) ∧ x = c + B.mulVec v) :
    ∃ W : Matrix (Fin N) (Fin N) ℝ,
      B * W = 1 ∧
      (∀ i j : Fin N, |W i j| ≤ 2 / r) ∧
      (r / 2) ^ N / (N.factorial : ℝ) ≤ |B.det| := by
  classical
  obtain ⟨v0, hv0_sq, hv0_eq⟩ := hBall x_star (by simp [sq_nonneg, hr.le])
  have hEk : ∀ k : Fin N,
      ∃ vk : Fin N → ℝ, (∑ j : Fin N, (vk j) ^ 2 ≤ 1) ∧
        (fun j : Fin N => x_star j + (if j = k then r else 0)) = c + B.mulVec vk := by
    intro k
    refine hBall (fun j => x_star j + (if j = k then r else 0)) ?_
    have hsum : ∑ j : Fin N, ((x_star j + (if j = k then r else 0)) - x_star j) ^ 2 = r ^ 2 := by
      have hpt : ∀ j : Fin N, ((x_star j + (if j = k then r else 0)) - x_star j) ^ 2 =
          if j = k then r ^ 2 else 0 := by
        intro j; by_cases hjk : j = k <;> simp [hjk]
      simp_rw [hpt]
      simp
    linarith
  choose vk hvk_sq hvk_eq using hEk
  let W : Matrix (Fin N) (Fin N) ℝ := fun i k => (vk k i - v0 i) / r
  have hBW : B * W = 1 := by
    ext i k
    have hk := congr_fun (hvk_eq k) i
    have h0 := congr_fun hv0_eq i
    simp only [Pi.add_apply] at hk h0
    have hDiff : B.mulVec (vk k) i - B.mulVec v0 i = if i = k then r else 0 := by linarith
    have hCol : (B * W) i k = (1 / r) * (B.mulVec (vk k) i - B.mulVec v0 i) := by
      simp only [Matrix.mul_apply, W, Matrix.mulVec, dotProduct]
      rw [← Finset.sum_sub_distrib, Finset.mul_sum]
      exact Finset.sum_congr rfl (fun j _ => by ring)
    rw [hCol, hDiff]
    by_cases hik : i = k
    · subst hik; simp [one_div, inv_mul_cancel₀ hr.ne']
    · simp [hik, Matrix.one_apply]
  have hW_abs : ∀ i k : Fin N, |W i k| ≤ 2 / r := by
    intro i k
    have hv0_i : |v0 i| ≤ 1 := by
      have hsq : (v0 i) ^ 2 ≤ 1 ^ 2 := by
        have hle := Finset.single_le_sum (f := fun j : Fin N => (v0 j) ^ 2)
          (fun _ _ => sq_nonneg _) (Finset.mem_univ i)
        linarith
      simpa using sq_le_sq.mp hsq
    have hvk_i : |vk k i| ≤ 1 := by
      have hsq : (vk k i) ^ 2 ≤ 1 ^ 2 := by
        have hle := Finset.single_le_sum (f := fun j : Fin N => (vk k j) ^ 2)
          (fun _ _ => sq_nonneg _) (Finset.mem_univ i)
        linarith [hvk_sq k]
      simpa using sq_le_sq.mp hsq
    dsimp only [W]
    rw [abs_div, abs_of_pos hr]
    refine div_le_div_of_nonneg_right ?_ hr.le
    calc |vk k i - v0 i| ≤ |vk k i| + |v0 i| := abs_sub _ _
      _ ≤ 1 + 1 := add_le_add hvk_i hv0_i
      _ = 2 := by norm_num
  have hW_det_ub : |W.det| ≤ (N.factorial : ℝ) * (2 / r) ^ N :=
    abs_det_le_factorial_mul_pow_real W (2 / r) (by positivity) hW_abs
  have hProdDet : |B.det| * |W.det| = 1 := by
    rw [← abs_mul, ← Matrix.det_mul, hBW, Matrix.det_one, abs_one]
  have hFacPos : (0 : ℝ) < (N.factorial : ℝ) := by exact_mod_cast Nat.factorial_pos N
  have hDetLB : (r / 2) ^ N / (N.factorial : ℝ) ≤ |B.det| := by
    rw [div_le_iff₀ hFacPos]
    have h1 : 1 ≤ |B.det| * ((N.factorial : ℝ) * (2 / r) ^ N) := by
      rw [← hProdDet]
      exact mul_le_mul_of_nonneg_left hW_det_ub (abs_nonneg B.det)
    have h2 : (r / 2) ^ N * 1 ≤ (r / 2) ^ N * (|B.det| * ((N.factorial : ℝ) * (2 / r) ^ N)) :=
      mul_le_mul_of_nonneg_left h1 (pow_nonneg (by positivity) N)
    have hpow : (r / 2) ^ N * (2 / r) ^ N = 1 := by
      rw [← mul_pow]
      have : (r / 2) * (2 / r) = 1 := by field_simp [hr.ne']
      rw [this, one_pow]
    have h3 : (r / 2) ^ N * (|B.det| * ((N.factorial : ℝ) * (2 / r) ^ N)) =
        |B.det| * (N.factorial : ℝ) := by
      calc (r / 2) ^ N * (|B.det| * ((N.factorial : ℝ) * (2 / r) ^ N))
          = |B.det| * (N.factorial : ℝ) * ((r / 2) ^ N * (2 / r) ^ N) := by ring
        _ = |B.det| * (N.factorial : ℝ) := by rw [hpow, mul_one]
    linarith
  exact ⟨W, hBW, hW_abs, hDetLB⟩

theorem one_add_pow_le_one_add_two_mul {x : ℝ} (hx : 0 ≤ x) :
    ∀ k : ℕ, 2 * (k : ℝ) * x ≤ 1 → (1 + x) ^ k ≤ 1 + 2 * (k : ℝ) * x
  | 0, _ => by simp
  | k + 1, hk1 => by
      have hk : 2 * (k : ℝ) * x ≤ 1 := by
        push_cast at hk1
        nlinarith only [hx, hk1]
      have ih := one_add_pow_le_one_add_two_mul hx k hk
      rw [pow_succ']
      push_cast
      have hmid : (2 * (k : ℝ) * x) * x ≤ 1 * x := mul_le_mul_of_nonneg_right hk hx
      calc (1 + x) * (1 + x) ^ k
          ≤ (1 + x) * (1 + 2 * (k : ℝ) * x) := mul_le_mul_of_nonneg_left ih (by linarith)
        _ = 1 + (2 * (k : ℝ) + 1) * x + (2 * (k : ℝ) * x) * x := by ring
        _ ≤ 1 + (2 * (k : ℝ) + 1) * x + 1 * x := by linarith [hmid]
        _ = 1 + 2 * ((k : ℝ) + 1) * x := by ring

theorem det_one_add_perturbation {N : ℕ} (hN : 1 ≤ N)
    (E : Matrix (Fin N) (Fin N) ℝ) (δ₀ : ℝ) (hδ0 : 0 ≤ δ₀)
    (hSmall : 2 * (N : ℝ) * δ₀ ≤ 1 / 4)
    (hE : ∀ i j : Fin N, |E i j| ≤ δ₀) :
    1 - (N : ℝ) * δ₀ - (N.factorial : ℝ) * (2 : ℝ) ^ N * δ₀ ≤ (1 + E).det ∧
    |(1 + E).det| ≤ 1 + 2 * (N : ℝ) * δ₀ + (N.factorial : ℝ) * (2 : ℝ) ^ N * δ₀ := by
  classical
  have hNR : (1 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
  have hδ_le1 : δ₀ ≤ 1 := by nlinarith only [hNR, hδ0, hSmall]
  rw [Matrix.det_apply]
  let term : Equiv.Perm (Fin N) → ℝ :=
    fun σ => Equiv.Perm.sign σ • ∏ i : Fin N, (1 + E) (σ i) i
  have hSplit : ∑ σ : Equiv.Perm (Fin N), term σ =
      term 1 + ∑ σ ∈ (Finset.univ : Finset (Equiv.Perm (Fin N))).erase 1, term σ :=
    (Finset.add_sum_erase Finset.univ term (Finset.mem_univ 1)).symm
  rw [hSplit]
  have hNonIdEach : ∀ σ ∈ (Finset.univ : Finset (Equiv.Perm (Fin N))).erase 1,
      |term σ| ≤ (2 : ℝ) ^ N * δ₀ := by
    intro σ hσ
    have hσ_ne : σ ≠ 1 := (Finset.mem_erase.mp hσ).1
    have hExMove : ∃ i₀ : Fin N, σ i₀ ≠ i₀ := by
      by_contra hall
      push_neg at hall
      exact hσ_ne (Equiv.ext hall)
    rcases hExMove with ⟨i₀, hi₀⟩
    dsimp only [term]
    have hsign : |Equiv.Perm.sign σ • ∏ i : Fin N, (1 + E) (σ i) i| =
        ∏ i : Fin N, |(1 + E) (σ i) i| := by
      rcases Int.units_eq_one_or (Equiv.Perm.sign σ) with hs | hs <;> simp [hs, Finset.abs_prod]
    rw [hsign, ← Finset.mul_prod_erase Finset.univ _ (Finset.mem_univ i₀)]
    have hi0_bound : |(1 + E) (σ i₀) i₀| ≤ δ₀ := by
      simp [Matrix.one_apply, hi₀, hE (σ i₀) i₀]
    have hRest_bound : ∏ i ∈ (Finset.univ : Finset (Fin N)).erase i₀, |(1 + E) (σ i) i| ≤
        ∏ _i ∈ (Finset.univ : Finset (Fin N)).erase i₀, (2 : ℝ) := by
      refine Finset.prod_le_prod (fun _ _ => abs_nonneg _) (fun i _ => ?_)
      by_cases hsi : σ i = i
      · simp only [Matrix.add_apply, hsi, Matrix.one_apply_eq]
        have htri : |1 + E i i| ≤ 1 + |E i i| := by simpa using abs_add_le (1 : ℝ) (E i i)
        linarith [hE i i]
      · simp only [Matrix.add_apply, Matrix.one_apply_ne hsi, zero_add]
        linarith [hE (σ i) i]
    have hPowErase : (∏ _i ∈ (Finset.univ : Finset (Fin N)).erase i₀, (2 : ℝ)) ≤ (2 : ℝ) ^ N := by
      rw [Finset.prod_const]
      have hcard : ((Finset.univ : Finset (Fin N)).erase i₀).card ≤ N := by
        simpa [Fintype.card_fin] using Finset.card_le_univ ((Finset.univ : Finset (Fin N)).erase i₀)
      exact pow_le_pow_right₀ (by norm_num) hcard
    calc |(1 + E) (σ i₀) i₀| * ∏ i ∈ Finset.univ.erase i₀, |(1 + E) (σ i) i|
        ≤ δ₀ * (2 : ℝ) ^ N :=
          mul_le_mul hi0_bound (hRest_bound.trans hPowErase)
            (Finset.prod_nonneg (fun _ _ => abs_nonneg _)) hδ0
      _ = (2 : ℝ) ^ N * δ₀ := by ring
  have hNonIdSum : |∑ σ ∈ (Finset.univ : Finset (Equiv.Perm (Fin N))).erase 1, term σ| ≤
      (N.factorial : ℝ) * (2 : ℝ) ^ N * δ₀ := by
    calc |∑ σ ∈ Finset.univ.erase 1, term σ|
        ≤ ∑ σ ∈ Finset.univ.erase 1, |term σ| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ _σ ∈ (Finset.univ : Finset (Equiv.Perm (Fin N))).erase 1, (2 : ℝ) ^ N * δ₀ :=
          Finset.sum_le_sum hNonIdEach
      _ = ((Finset.univ.erase (1 : Equiv.Perm (Fin N))).card : ℝ) * ((2 : ℝ) ^ N * δ₀) := by simp
      _ ≤ (N.factorial : ℝ) * ((2 : ℝ) ^ N * δ₀) := by
          refine mul_le_mul_of_nonneg_right ?_ (by positivity)
          have hcard : (Finset.univ.erase (1 : Equiv.Perm (Fin N))).card ≤ N.factorial := by
            calc (Finset.univ.erase (1 : Equiv.Perm (Fin N))).card
                ≤ (Finset.univ : Finset (Equiv.Perm (Fin N))).card := Finset.card_le_univ _
              _ = N.factorial := by simp [Fintype.card_perm]
          exact_mod_cast hcard
      _ = (N.factorial : ℝ) * (2 : ℝ) ^ N * δ₀ := by ring
  have hTerm1_eq : term 1 = ∏ i : Fin N, (1 + E i i) := by
    simp [term, Equiv.Perm.one_apply, Matrix.one_apply]
  have hDiagNonneg : ∀ i : Fin N, 0 ≤ 1 + E i i := by
    intro i
    have := (abs_le.mp (hE i i)).1
    linarith
  have hTerm1_ub : term 1 ≤ 1 + 2 * (N : ℝ) * δ₀ := by
    rw [hTerm1_eq]
    calc ∏ i : Fin N, (1 + E i i)
        ≤ ∏ _i : Fin N, (1 + δ₀) :=
          Finset.prod_le_prod (fun i _ => hDiagNonneg i)
            (fun i _ => by linarith [(abs_le.mp (hE i i)).2])
      _ = (1 + δ₀) ^ N := by simp
      _ ≤ 1 + 2 * (N : ℝ) * δ₀ :=
          one_add_pow_le_one_add_two_mul hδ0 N (by linarith)
  have hTerm1_lb : 1 - (N : ℝ) * δ₀ ≤ term 1 := by
    rw [hTerm1_eq]
    have hBernLower : ∀ (s : Finset (Fin N)),
        1 - (s.card : ℝ) * δ₀ ≤ ∏ i ∈ s, (1 + E i i) := by
      intro s
      refine Finset.induction_on s (by simp) ?_
      intro a s ha ih
      rw [Finset.prod_insert ha, Finset.card_insert_of_notMem ha]
      push_cast
      by_cases hPos : 0 ≤ 1 - (s.card : ℝ) * δ₀
      · have ha_lb : 1 - δ₀ ≤ 1 + E a a := by linarith [(abs_le.mp (hE a a)).1]
        calc 1 - ((s.card : ℝ) + 1) * δ₀
            = (1 - δ₀) * (1 - (s.card : ℝ) * δ₀) - (s.card : ℝ) * δ₀ ^ 2 := by ring
          _ ≤ (1 - δ₀) * (1 - (s.card : ℝ) * δ₀) := by
              have : 0 ≤ (s.card : ℝ) * δ₀ ^ 2 := by positivity
              linarith
          _ ≤ (1 + E a a) * ∏ i ∈ s, (1 + E i i) :=
              mul_le_mul ha_lb ih hPos (hDiagNonneg a)
      · have hProdNonneg : 0 ≤ (1 + E a a) * ∏ i ∈ s, (1 + E i i) :=
          mul_nonneg (hDiagNonneg a) (Finset.prod_nonneg (fun i _ => hDiagNonneg i))
        linarith
    have hUniv := hBernLower Finset.univ
    simpa [Fintype.card_fin] using hUniv
  have hTerm1_nonneg : 0 ≤ term 1 := by
    rw [hTerm1_eq]
    exact Finset.prod_nonneg (fun i _ => hDiagNonneg i)
  constructor
  · have hSumLb := (abs_le.mp hNonIdSum).1
    linarith
  · calc |term 1 + ∑ σ ∈ Finset.univ.erase 1, term σ|
        ≤ |term 1| + |∑ σ ∈ Finset.univ.erase 1, term σ| := abs_add_le _ _
      _ = term 1 + |∑ σ ∈ Finset.univ.erase 1, term σ| := by rw [abs_of_nonneg hTerm1_nonneg]
      _ ≤ 1 + 2 * (N : ℝ) * δ₀ + (N.factorial : ℝ) * (2 : ℝ) ^ N * δ₀ :=
          add_le_add hTerm1_ub hNonIdSum

theorem rounded_ellipsoid_step {N : ℕ} (hN : 2 ≤ N) {r ε : ℝ} (hr : 0 < r) (hε_nn : 0 ≤ ε)
    (hε : ε * (128 * (N : ℝ) ^ 4 * (N.factorial : ℝ) * (2 : ℝ) ^ N) ≤ r)
    (x_star c' c_next : Fin N → ℝ)
    (B' B_next : Matrix (Fin N) (Fin N) ℝ)
    (hBall' : ∀ x : Fin N → ℝ, (∑ j : Fin N, (x j - x_star j) ^ 2 ≤ r ^ 2) →
      ∃ v : Fin N → ℝ, (∑ j : Fin N, (v j) ^ 2 ≤ (1 / ellInfl N) ^ 2) ∧ x = c' + B'.mulVec v)
    (hc_err : ∀ i : Fin N, |c_next i - c' i| ≤ ε)
    (hB_err : ∀ i j : Fin N, |B_next i j - B' i j| ≤ ε) :
    (∀ x : Fin N → ℝ, (∑ j : Fin N, (x j - x_star j) ^ 2 ≤ r ^ 2) →
      ∃ u : Fin N → ℝ, (∑ j : Fin N, (u j) ^ 2 ≤ 1) ∧ x = c_next + B_next.mulVec u) ∧
    |B_next.det| ≤ Real.exp (1 / (10 * ((N : ℝ) + 1))) * |B'.det| := by
  classical
  have hNR : (2 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
  have hNR2 : (4 : ℝ) ≤ (N : ℝ) ^ 2 := by nlinarith only [hNR]
  obtain ⟨_, _, _, hinfl_gt1, _⟩ := ell_params_pos hN
  have hInvInflSq_le1 : (1 / ellInfl N) ^ 2 ≤ 1 := by
    have h1 : 1 / ellInfl N ≤ 1 := (div_le_one (by linarith)).mpr hinfl_gt1.le
    exact pow_le_one₀ (by positivity) h1
  obtain ⟨W, hBW, hW_abs, _⟩ := ball_in_ellipsoid_right_inv hr x_star c' B'
    (fun x hx => by
      obtain ⟨v, hv_sq, hv_eq⟩ := hBall' x hx
      exact ⟨v, hv_sq.trans hInvInflSq_le1, hv_eq⟩)
  let dB : Matrix (Fin N) (Fin N) ℝ := B_next - B'
  let dc : Fin N → ℝ := c_next - c'
  let E_mat : Matrix (Fin N) (Fin N) ℝ := W * dB
  have hBnext_factor : B_next = B' * (1 + E_mat) := by
    calc B_next = B' + (B' * W) * dB := by rw [hBW, Matrix.one_mul]; simp [dB]
      _ = B' * (1 + E_mat) := by simp [E_mat, Matrix.mul_add, Matrix.mul_assoc]
  let δ₀ : ℝ := (2 * (N : ℝ) / r) * ε
  have hδ0_nn : 0 ≤ δ₀ := by positivity
  have hE_entry : ∀ i j : Fin N, |E_mat i j| ≤ δ₀ := by
    intro i j
    simp only [E_mat, Matrix.mul_apply]
    calc |∑ k : Fin N, W i k * dB k j|
        ≤ ∑ k : Fin N, |W i k * dB k j| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ _k : Fin N, (2 / r) * ε := by
          refine Finset.sum_le_sum (fun k _ => ?_)
          rw [abs_mul]
          exact mul_le_mul (hW_abs i k) (hB_err k j) (abs_nonneg _) (by positivity)
      _ = δ₀ := by simp [δ₀]; ring
  have hFacGe1 : (1 : ℝ) ≤ (N.factorial : ℝ) := by exact_mod_cast Nat.factorial_pos N
  have h2NGe1 : (1 : ℝ) ≤ (2 : ℝ) ^ N := one_le_pow₀ (by norm_num)
  have hProdSmall : δ₀ * (64 * (N : ℝ) ^ 3 * (N.factorial : ℝ) * (2 : ℝ) ^ N) ≤ 1 := by
    dsimp [δ₀]
    have hEq : 2 * (N : ℝ) / r * ε * (64 * (N : ℝ) ^ 3 * (N.factorial : ℝ) * (2 : ℝ) ^ N) =
        (ε * (128 * (N : ℝ) ^ 4 * (N.factorial : ℝ) * (2 : ℝ) ^ N)) / r := by ring
    rw [hEq, div_le_one hr]
    exact hε
  have hFac2Ge1 : (1 : ℝ) ≤ (N.factorial : ℝ) * (2 : ℝ) ^ N :=
    one_le_mul_of_one_le_of_one_le hFacGe1 h2NGe1
  have hδ_tiny : δ₀ ≤ 1 / (64 * (N : ℝ) ^ 3) := by
    rw [le_div_iff₀ (by positivity)]
    calc δ₀ * (64 * (N : ℝ) ^ 3)
        = (δ₀ * (64 * (N : ℝ) ^ 3)) * 1 := by ring
      _ ≤ (δ₀ * (64 * (N : ℝ) ^ 3)) * ((N.factorial : ℝ) * (2 : ℝ) ^ N) :=
          mul_le_mul_of_nonneg_left hFac2Ge1 (by positivity)
      _ = δ₀ * (64 * (N : ℝ) ^ 3 * (N.factorial : ℝ) * (2 : ℝ) ^ N) := by ring
      _ ≤ 1 := hProdSmall
  have h2Nδ : 2 * (N : ℝ) * δ₀ ≤ 1 / 4 := by
    have h1 : 2 * (N : ℝ) * δ₀ ≤ 2 * (N : ℝ) * (1 / (64 * (N : ℝ) ^ 3)) :=
      mul_le_mul_of_nonneg_left hδ_tiny (by positivity)
    have h2 : 2 * (N : ℝ) * (1 / (64 * (N : ℝ) ^ 3)) ≤ 1 / 4 := by
      rw [mul_one_div, div_le_div_iff₀ (by positivity) (by norm_num)]
      nlinarith only [hNR, hNR2]
    linarith
  obtain ⟨hDetLb, hDetUb⟩ := det_one_add_perturbation (by omega) E_mat δ₀ hδ0_nn h2Nδ hE_entry
  have hFacTerm : (N.factorial : ℝ) * (2 : ℝ) ^ N * δ₀ ≤ 1 / (64 * (N : ℝ) ^ 3) := by
    rw [le_div_iff₀ (by positivity)]
    have : (N.factorial : ℝ) * (2 : ℝ) ^ N * δ₀ * (64 * (N : ℝ) ^ 3) =
        δ₀ * (64 * (N : ℝ) ^ 3 * (N.factorial : ℝ) * (2 : ℝ) ^ N) := by ring
    linarith
  have hDetGeHalf : 1 / 2 ≤ (1 + E_mat).det := by
    have h1 : (N : ℝ) * δ₀ ≤ 1 / 8 := by linarith
    have h2 : 1 / (64 * (N : ℝ) ^ 3) ≤ 1 / 8 := by
      rw [div_le_div_iff₀ (by positivity) (by norm_num)]; nlinarith only [hNR, hNR2]
    linarith
  have hDetNeZero : (1 + E_mat).det ≠ 0 := by linarith
  constructor
  · intro x hx
    obtain ⟨v, hv_sq, hv_eq⟩ := hBall' x hx
    let rhs : Fin N → ℝ := v - W.mulVec dc
    let u : Fin N → ℝ := (1 / (1 + E_mat).det) • (1 + E_mat).cramer rhs
    have hOneAddEq : (1 + E_mat).mulVec u = rhs := by
      dsimp only [u]
      rw [Matrix.mulVec_smul, Matrix.mulVec_cramer, smul_smul, one_div,
        inv_mul_cancel₀ hDetNeZero, one_smul]
    refine ⟨u, ?_, ?_⟩
    · have hUnivNe : (Finset.univ : Finset (Fin N)).Nonempty :=
        ⟨⟨0, by omega⟩, Finset.mem_univ _⟩
      let M_u : ℝ := Finset.univ.sup' hUnivNe (fun j => |u j|)
      have hMu_nn : 0 ≤ M_u :=
        (abs_nonneg (u ⟨0, by omega⟩)).trans
          (Finset.le_sup' (fun j : Fin N => |u j|) (Finset.mem_univ _))
      have hWdc : ∀ i : Fin N, |(W.mulVec dc) i| ≤ δ₀ := by
        intro i
        simp only [Matrix.mulVec, dotProduct]
        calc |∑ k : Fin N, W i k * dc k|
            ≤ ∑ k : Fin N, |W i k * dc k| := Finset.abs_sum_le_sum_abs _ _
          _ ≤ ∑ _k : Fin N, (2 / r) * ε := by
              refine Finset.sum_le_sum (fun k _ => ?_)
              rw [abs_mul]
              exact mul_le_mul (hW_abs i k) (hc_err k) (abs_nonneg _) (by positivity)
          _ = δ₀ := by simp [δ₀]; ring
      have hDiff_uv : ∀ i : Fin N, |u i - v i| ≤ δ₀ + (N : ℝ) * δ₀ * M_u := by
        intro i
        have hi := congr_fun hOneAddEq i
        simp only [Matrix.add_mulVec, Matrix.one_mulVec, Pi.add_apply, rhs, Pi.sub_apply] at hi
        have hu_sub : u i - v i = - (W.mulVec dc) i - (E_mat.mulVec u) i := by linarith
        have hEu : |(E_mat.mulVec u) i| ≤ (N : ℝ) * δ₀ * M_u := by
          simp only [Matrix.mulVec, dotProduct]
          calc |∑ k : Fin N, E_mat i k * u k|
              ≤ ∑ k : Fin N, |E_mat i k * u k| := Finset.abs_sum_le_sum_abs _ _
            _ ≤ ∑ _k : Fin N, δ₀ * M_u := by
                refine Finset.sum_le_sum (fun k _ => ?_)
                rw [abs_mul]
                exact mul_le_mul (hE_entry i k)
                  (Finset.le_sup' (fun j : Fin N => |u j|) (Finset.mem_univ k))
                  (abs_nonneg _) hδ0_nn
            _ = (N : ℝ) * δ₀ * M_u := by simp [mul_assoc]
        rw [hu_sub]
        calc |- (W.mulVec dc) i - (E_mat.mulVec u) i|
            = |(W.mulVec dc) i + (E_mat.mulVec u) i| := by rw [← neg_add', abs_neg]
          _ ≤ |(W.mulVec dc) i| + |(E_mat.mulVec u) i| := abs_add_le _ _
          _ ≤ δ₀ + (N : ℝ) * δ₀ * M_u := add_le_add (hWdc i) hEu
      have hVi_le1 : ∀ i : Fin N, |v i| ≤ 1 := by
        intro i
        have hsq : (v i) ^ 2 ≤ 1 ^ 2 := by
          have hle := Finset.single_le_sum (f := fun j : Fin N => (v j) ^ 2)
            (fun _ _ => sq_nonneg _) (Finset.mem_univ i)
          linarith [hv_sq.trans hInvInflSq_le1]
        simpa using sq_le_sq.mp hsq
      have hMu_bound : M_u ≤ 1 + δ₀ + (N : ℝ) * δ₀ * M_u := by
        refine Finset.sup'_le hUnivNe _ (fun i _ => ?_)
        have htri : |u i| ≤ |v i| + |u i - v i| := by
          calc |u i| = |v i + (u i - v i)| := by ring_nf
            _ ≤ |v i| + |u i - v i| := abs_add_le _ _
        linarith [hVi_le1 i, hDiff_uv i]
      have hMu_le3 : M_u ≤ 3 := by
        have hNδ_half : (N : ℝ) * δ₀ ≤ 1 / 8 := by linarith
        have hNδ_Mu : (N : ℝ) * δ₀ * M_u ≤ (1 / 8) * M_u :=
          mul_le_mul_of_nonneg_right hNδ_half hMu_nn
        have hδ_half : δ₀ ≤ 1 / 8 := by
          have h64 : 1 / (64 * (N : ℝ) ^ 3) ≤ 1 / 8 := by
            rw [div_le_div_iff₀ (by positivity) (by norm_num)]; nlinarith only [hNR, hNR2]
          linarith
        linarith
      let η : ℝ := δ₀ + 3 * (N : ℝ) * δ₀
      have hη_nn : 0 ≤ η := by positivity
      have hDiff_η : ∀ i : Fin N, |u i - v i| ≤ η := by
        intro i
        have h1 := hDiff_uv i
        have h2 : (N : ℝ) * δ₀ * M_u ≤ (N : ℝ) * δ₀ * 3 :=
          mul_le_mul_of_nonneg_left hMu_le3 (by positivity)
        dsimp [η]
        linarith
      have hNη_small : (N : ℝ) * (2 * η + η ^ 2) ≤ 1 / (8 * (N : ℝ) ^ 2 + 1) := by
        have hN_le_fac2 : 4 * (N : ℝ) ≤ (N.factorial : ℝ) * (2 : ℝ) ^ N := by
          have hNat : 4 * N ≤ N.factorial * 2 ^ N := by
            have h1 : N ≤ 2 ^ N := Nat.lt_two_pow_self.le
            rcases eq_or_lt_of_le hN with rfl | hN3
            · norm_num
            · have hfac6 : 6 ≤ N.factorial := by
                have hle := Nat.factorial_le (by omega : 3 ≤ N)
                simpa [Nat.factorial] using hle
              nlinarith only [h1, hN3, hfac6]
          exact_mod_cast hNat
        have hδ_tiny4 : δ₀ ≤ 1 / (256 * (N : ℝ) ^ 4) := by
          rw [le_div_iff₀ (by positivity)]
          calc δ₀ * (256 * (N : ℝ) ^ 4)
              = δ₀ * (64 * (N : ℝ) ^ 3) * (4 * (N : ℝ)) := by ring
            _ ≤ δ₀ * (64 * (N : ℝ) ^ 3) * ((N.factorial : ℝ) * (2 : ℝ) ^ N) :=
                mul_le_mul_of_nonneg_left hN_le_fac2 (by positivity)
            _ = δ₀ * (64 * (N : ℝ) ^ 3 * (N.factorial : ℝ) * (2 : ℝ) ^ N) := by ring
            _ ≤ 1 := hProdSmall
        have hη_tiny : η ≤ 1 / (64 * (N : ℝ) ^ 3) := by
          dsimp [η]
          have : 1 + 3 * (N : ℝ) ≤ 4 * (N : ℝ) := by linarith
          calc δ₀ + 3 * (N : ℝ) * δ₀ = (1 + 3 * (N : ℝ)) * δ₀ := by ring
            _ ≤ (4 * (N : ℝ)) * (1 / (256 * (N : ℝ) ^ 4)) :=
                mul_le_mul this hδ_tiny4 hδ0_nn (by positivity)
            _ = 1 / (64 * (N : ℝ) ^ 3) := by
                have hn0 : (N : ℝ) ≠ 0 := by linarith
                field_simp [hn0]; ring
        have hη_le1 : η ≤ 1 := by
          have : 1 / (64 * (N : ℝ) ^ 3) ≤ 1 := by
            rw [div_le_one (by positivity)]; nlinarith only [hNR, hNR2]
          linarith
        have h2η : 2 * η + η ^ 2 ≤ 3 * η := by nlinarith only [hη_nn, hη_le1]
        calc (N : ℝ) * (2 * η + η ^ 2)
            ≤ (N : ℝ) * (3 * η) := mul_le_mul_of_nonneg_left h2η (by positivity)
          _ ≤ (N : ℝ) * (3 * (1 / (64 * (N : ℝ) ^ 3))) :=
              mul_le_mul_of_nonneg_left (by linarith) (by positivity)
          _ = 3 / (64 * (N : ℝ) ^ 2) := by
              have hn0 : (N : ℝ) ≠ 0 := by linarith
              field_simp [hn0]
          _ ≤ 1 / (8 * (N : ℝ) ^ 2 + 1) := by
              rw [div_le_div_iff₀ (by positivity) (by positivity)]
              nlinarith only [hNR, hNR2]
      have hInvInflGap : (1 / ellInfl N) ^ 2 + 1 / (8 * (N : ℝ) ^ 2 + 1) ≤ 1 := by
        dsimp only [ellInfl]
        have hd4 : (0 : ℝ) < 8 * (N : ℝ) ^ 2 + 1 := by positivity
        have hinv : 1 / ((8 * (N : ℝ) ^ 2 + 1) / (8 * (N : ℝ) ^ 2)) =
            (8 * (N : ℝ) ^ 2) / (8 * (N : ℝ) ^ 2 + 1) := one_div_div _ _
        rw [hinv]
        apply le_of_mul_le_mul_right _ (sq_pos_of_pos hd4)
        have hLHS : (((8 * (N : ℝ) ^ 2) / (8 * (N : ℝ) ^ 2 + 1)) ^ 2 +
            1 / (8 * (N : ℝ) ^ 2 + 1)) * (8 * (N : ℝ) ^ 2 + 1) ^ 2 =
            64 * (N : ℝ) ^ 4 + 8 * (N : ℝ) ^ 2 + 1 := by
          have hd4sq : (8 * (N : ℝ) ^ 2 + 1) ^ 2 ≠ 0 := pow_ne_zero 2 hd4.ne'
          rw [div_pow]
          field_simp [hd4.ne', hd4sq]
          try ring
        have hRHS : 1 * (8 * (N : ℝ) ^ 2 + 1) ^ 2 =
            64 * (N : ℝ) ^ 4 + 16 * (N : ℝ) ^ 2 + 1 := by ring
        rw [hLHS, hRHS]
        nlinarith only [hNR, hNR2]
      calc ∑ i : Fin N, (u i) ^ 2
          = ∑ i : Fin N, (v i + (u i - v i)) ^ 2 :=
              Finset.sum_congr rfl (fun _ _ => by ring)
        _ ≤ ∑ i : Fin N, ((v i) ^ 2 + 2 * η + η ^ 2) := by
              refine Finset.sum_le_sum (fun i _ => ?_)
              have hd := hDiff_η i
              have hv := hVi_le1 i
              have hprod : (v i) * (u i - v i) ≤ |v i| * |u i - v i| := by
                rw [← abs_mul]; exact le_abs_self _
              have hprod2 : |v i| * |u i - v i| ≤ 1 * η :=
                mul_le_mul hv hd (abs_nonneg _) zero_le_one
              have hsq_d : (u i - v i) ^ 2 ≤ η ^ 2 := by
                rw [← sq_abs]
                exact pow_le_pow_left₀ (abs_nonneg _) hd 2
              have hexp : (v i + (u i - v i)) ^ 2 =
                  (v i) ^ 2 + 2 * ((v i) * (u i - v i)) + (u i - v i) ^ 2 := by ring
              linarith
        _ = (∑ i : Fin N, (v i) ^ 2) + (N : ℝ) * (2 * η + η ^ 2) := by
              simp [Finset.sum_add_distrib]
              ring
        _ ≤ (1 / ellInfl N) ^ 2 + 1 / (8 * (N : ℝ) ^ 2 + 1) :=
              add_le_add hv_sq hNη_small
        _ ≤ 1 := hInvInflGap
    · rw [hBnext_factor, ← Matrix.mulVec_mulVec, hOneAddEq]
      simp only [rhs, Matrix.mulVec_sub, Matrix.mulVec_mulVec, hBW, Matrix.one_mulVec]
      rw [hv_eq]
      ext i
      simp only [Pi.add_apply, Pi.sub_apply, dc]
      ring
  · rw [hBnext_factor, Matrix.det_mul, abs_mul, mul_comm]
    refine mul_le_mul_of_nonneg_right ?_ (abs_nonneg B'.det)
    have hSumSmall : 2 * (N : ℝ) * δ₀ + (N.factorial : ℝ) * (2 : ℝ) ^ N * δ₀ ≤
        1 / (10 * ((N : ℝ) + 1)) := by
      have h1 : 2 * (N : ℝ) * δ₀ ≤ 2 * (N : ℝ) * (1 / (64 * (N : ℝ) ^ 3)) :=
        mul_le_mul_of_nonneg_left hδ_tiny (by positivity)
      have h2 : 2 * (N : ℝ) * (1 / (64 * (N : ℝ) ^ 3)) = 1 / (32 * (N : ℝ) ^ 2) := by
        have hn0 : (N : ℝ) ≠ 0 := by linarith
        field_simp [hn0]; ring
      have h3 : 1 / (32 * (N : ℝ) ^ 2) + 1 / (64 * (N : ℝ) ^ 3) ≤ 1 / (10 * ((N : ℝ) + 1)) := by
        have h3a : 1 / (32 * (N : ℝ) ^ 2) ≤ 1 / (20 * ((N : ℝ) + 1)) := by
          rw [div_le_div_iff₀ (by positivity) (by positivity)]; nlinarith only [hNR, hNR2]
        have h3b : 1 / (64 * (N : ℝ) ^ 3) ≤ 1 / (20 * ((N : ℝ) + 1)) := by
          rw [div_le_div_iff₀ (by positivity) (by positivity)]; nlinarith only [hNR, hNR2]
        have h3c : 1 / (20 * ((N : ℝ) + 1)) + 1 / (20 * ((N : ℝ) + 1)) =
            1 / (10 * ((N : ℝ) + 1)) := by
          have hd1 : (N : ℝ) + 1 ≠ 0 := by linarith
          field_simp [hd1]; ring
        linarith
      linarith [hFacTerm]
    calc |(1 + E_mat).det|
        ≤ 1 + 2 * (N : ℝ) * δ₀ + (N.factorial : ℝ) * (2 : ℝ) ^ N * δ₀ := hDetUb
      _ ≤ 1 / (10 * ((N : ℝ) + 1)) + 1 := by linarith
      _ ≤ Real.exp (1 / (10 * ((N : ℝ) + 1))) := Real.add_one_le_exp _

end UL.Proof.cit_gls88_rational_lp.RacerCG
