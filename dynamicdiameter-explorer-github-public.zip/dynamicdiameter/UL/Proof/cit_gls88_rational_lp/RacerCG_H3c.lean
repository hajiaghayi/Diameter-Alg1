import Mathlib
import UL.Proof.cit_gls88_rational_lp.RacerCG_H3b
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

/-! ### 1. Value-Bounded `exec_for_val`, Prefix-Sum & `sumLoopStmt` -/

/-- Like `exec_for`, except the loop bound `N` only needs `N ≤ 2 ^ K` (not `N ≤ maxIdx`),
since `forLoopStmt` only writes `0 .. N` as a *value* into fixed cell `.heap 10 ctrSlot`. -/
theorem exec_for_val {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    (ctrSlot : ℤ) (countE : UL.IntExpr) (body : UL.BitRAMStmt)
    (N m_body : ℕ) (Inv : ℕ → UL.WordStore → Prop)
    {ws₀ : UL.WordStore}
    (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hslot1 : ctrSlot ≤ (maxIdx : ℤ))
    (hN_val : N ≤ 2 ^ K)
    (hcnt : evalVal inp (hWrite ws₀ 10 ctrSlot 0) countE = (N : ℤ))
    (hInv₀ : Inv 0 (hWrite ws₀ 10 ctrSlot 0))
    (hstep : ∀ k < N, ∀ ws : UL.WordStore,
      StoreBounded 31 maxIdx K ws →
      hRead ws 10 ctrSlot = (k : ℤ) →
      Inv k ws →
      ∃ ws', ExecBit inp maxIdx K body ws ws' (m_body * stepU) (m_body * stepB K) ∧
        hRead ws' 10 ctrSlot = (k : ℤ) ∧
        Inv (k + 1) (hWrite ws' 10 ctrSlot ((k : ℤ) + 1)))
    (hslot_wf : ctrSlot.natAbs ≤ 64 := by decide)
    (hslot0 : 0 ≤ ctrSlot := by decide)
    (hwf_cnt : exprWf 31 countE = true := by decide)
    (hsz_cnt : exprNodes countE ≤ 64 ∧ exprLeaves countE ≤ 64 := by decide) :
    ∃ ws_N : UL.WordStore,
      hRead ws_N 10 ctrSlot = (N : ℤ) ∧
      Inv N ws_N ∧
      ExecBit inp maxIdx K (forLoopStmt ctrSlot countE body) ws₀ ws_N
        ((2 + N * (m_body + 1)) * stepU)
        ((2 + N * (m_body + 1)) * stepB K) := by
  have h0_init := exec_write hctx hws₀ 10 (.lit ctrSlot) (.lit 0) ctrSlot 0 rfl rfl
    hslot0 hslot1 (by simp) (by decide)
    (by simp [exprWf, decide_eq_true hslot_wf]) (by decide)
    (by dsimp [exprNodes, exprLeaves]; omega)
  let FullInv : ℕ → UL.WordStore → Prop := fun k ws =>
    hRead ws 10 ctrSlot = (k : ℤ) ∧ Inv k ws
  have hFull0 : FullInv 0 (hWrite ws₀ 10 ctrSlot 0) :=
    ⟨hRead_hWrite_self ws₀ 10 ctrSlot 0, hInv₀⟩
  obtain ⟨ws_N, ⟨hctrN, hInvN⟩, hrep⟩ := ExecBit.repeatN_nat hctx countE
    (.seq body (.writeHeap 10 (.lit ctrSlot) (.add (.readHeap 10 (.lit ctrSlot)) (.lit 1))))
    N ((m_body + 1) * stepU) ((m_body + 1) * stepB K) FullInv h0_init.2.1 hFull0 hwf_cnt hcnt
    (fun k hk ws hws ⟨hctr, hIk⟩ => by
      obtain ⟨ws', hbody, hctr', hIk1⟩ := hstep k hk ws hws hctr hIk
      have hk1_abs : ((k : ℤ) + 1).natAbs ≤ 2 ^ K := by omega
      have hinc := exec_write hctx hbody.2.1 10 (.lit ctrSlot)
        (.add (.readHeap 10 (.lit ctrSlot)) (.lit 1))
        ctrSlot ((k : ℤ) + 1) rfl
        (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hctr'])
        hslot0 hslot1 hk1_abs (by decide)
        (by simp [exprWf, decide_eq_true hslot_wf])
        (by simp [exprWf, decide_eq_true hslot_wf])
        (by dsimp [exprNodes, exprLeaves]; omega)
      refine ⟨hWrite ws' 10 ctrSlot ((k : ℤ) + 1), hbody.seq_steps hinc, ?_, hIk1⟩
      rw [hRead_hWrite_self]; push_cast; ring)
  refine ⟨ws_N, hctrN, hInvN, (h0_init.seq hrep).mono ?_ ?_⟩
  · have h1 : exprNodes countE ≤ stepU := by dsimp [stepU]; omega
    calc 1 * stepU + (exprNodes countE + N * ((m_body + 1) * stepU))
        ≤ 1 * stepU + (stepU + N * ((m_body + 1) * stepU)) :=
          Nat.add_le_add_left (Nat.add_le_add_right h1 _) _
      _ = (2 + N * (m_body + 1)) * stepU := by ring
  · have hL : 2 * exprLeaves countE * K ≤ 128 * K := Nat.mul_le_mul_right K (by omega)
    have h1 : exprNodes countE * (2 * exprLeaves countE * K) ^ 2 ≤ stepB K := by
      dsimp [stepB]
      calc exprNodes countE * (2 * exprLeaves countE * K) ^ 2
          ≤ 64 * (128 * K) ^ 2 := Nat.mul_le_mul hsz_cnt.1 (Nat.pow_le_pow_left hL 2)
        _ = 1048576 * K ^ 2 := by ring
        _ ≤ 2000000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)
    calc 1 * stepB K + (exprNodes countE * (2 * exprLeaves countE * K) ^ 2 +
            N * ((m_body + 1) * stepB K))
        ≤ 1 * stepB K + (stepB K + N * ((m_body + 1) * stepB K)) :=
          Nat.add_le_add_left (Nat.add_le_add_right h1 _) _
      _ = (2 + N * (m_body + 1)) * stepB K := by ring

theorem row_col_lt_mul {m n i j : ℕ} (hi : i < m) (hj : j < n) : i * n + j < m * n := by
  calc i * n + j < i * n + n := Nat.add_lt_add_left hj _
    _ = (i + 1) * n := by ring
    _ ≤ m * n := Nat.mul_le_mul_right n hi

def prefixSum {n : ℕ} (f : Fin n → ℤ) (k : ℕ) (hk : k ≤ n) : ℤ :=
  Fin.foldl k (fun acc (i : Fin k) => acc + f ⟨i.val, lt_of_lt_of_le i.isLt hk⟩) 0

theorem prefixSum_zero {n : ℕ} (f : Fin n → ℤ) (h0 : 0 ≤ n) :
    prefixSum f 0 h0 = 0 := by
  simp [prefixSum, Fin.foldl_zero]

theorem prefixSum_succ {n : ℕ} (f : Fin n → ℤ) (k : ℕ) (hk : k + 1 ≤ n) :
    prefixSum f (k + 1) hk = prefixSum f k (Nat.le_of_succ_le hk) + f ⟨k, hk⟩ := by
  dsimp [prefixSum]
  rw [Fin.foldl_succ_last]; rfl

theorem prefixSum_eq_sum {n : ℕ} (f : Fin n → ℤ) :
    prefixSum f n le_rfl = ∑ i : Fin n, f i := by
  have h : ∀ k : ℕ, (hk : k ≤ n) →
      prefixSum f k hk = ∑ i : Fin k, f ⟨i.val, lt_of_lt_of_le i.isLt hk⟩ := by
    intro k
    induction k with
    | zero =>
        intro hk
        rw [prefixSum_zero]
        simp
    | succ k ih =>
        intro hk
        rw [prefixSum_succ, ih (Nat.le_of_succ_le hk), Fin.sum_univ_castSucc]
        rfl
  simpa using h n le_rfl

theorem prefixSum_natAbs_le {n B : ℕ} (f : Fin n → ℤ)
    (hf : ∀ i : Fin n, (f i).natAbs ≤ B) (k : ℕ) (hk : k ≤ n) :
    (prefixSum f k hk).natAbs ≤ k * B := by
  induction k with
  | zero => simp [prefixSum_zero]
  | succ k ih =>
      rw [prefixSum_succ]
      have h1 : (prefixSum f k (Nat.le_of_succ_le hk) + f ⟨k, hk⟩).natAbs ≤
          (prefixSum f k (Nat.le_of_succ_le hk)).natAbs + (f ⟨k, hk⟩).natAbs :=
        Int.natAbs_add_le _ _
      calc (prefixSum f k (Nat.le_of_succ_le hk) + f ⟨k, hk⟩).natAbs
          ≤ k * B + B := h1.trans (Nat.add_le_add (ih (Nat.le_of_succ_le hk)) (hf ⟨k, hk⟩))
        _ = (k + 1) * B := by ring

def sumLoopStmt (ctrSlot accSlot : ℤ) (countE termE : UL.IntExpr) : UL.BitRAMStmt :=
  .seq
    (.writeHeap 10 (.lit accSlot) (.lit 0))
    (forLoopStmt ctrSlot countE
      (.writeHeap 10 (.lit accSlot) (.add (.readHeap 10 (.lit accSlot)) termE)))

theorem exec_sumLoopStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {n maxIdx K B : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    (ctrSlot accSlot : ℤ)
    (hslots : 0 ≤ ctrSlot ∧ ctrSlot ≤ 64 ∧ 0 ≤ accSlot ∧ accSlot ≤ 64 ∧ ctrSlot ≠ accSlot)
    (h64 : 64 ≤ maxIdx) (hn_ub : n ≤ maxIdx)
    (countE termE : UL.IntExpr)
    (hwf_cnt : exprWf 31 countE = true)
    (hsz_cnt : exprNodes countE ≤ 64 ∧ exprLeaves countE ≤ 64)
    (hwf_term : exprWf 31 termE = true)
    (hsz_term : exprNodes termE ≤ 40 ∧ exprLeaves termE ≤ 40)
    (f : Fin n → ℤ)
    (hfB : ∀ i : Fin n, (f i).natAbs ≤ B)
    (hsumB : n * B ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hcnt : ∀ ws : UL.WordStore,
      PreservesOutside (fun t idx => t = 10 ∧ (idx = ctrSlot ∨ idx = accSlot)) ws₀ ws →
      evalVal inp ws countE = (n : ℤ))
    (hterm : ∀ (k : ℕ) (hk : k < n) (ws : UL.WordStore),
      PreservesOutside (fun t idx => t = 10 ∧ (idx = ctrSlot ∨ idx = accSlot)) ws₀ ws →
      hRead ws 10 ctrSlot = (k : ℤ) →
      evalVal inp ws termE = f ⟨k, hk⟩) :
    let mod : ℕ → ℤ → Prop := fun t idx => t = 10 ∧ (idx = ctrSlot ∨ idx = accSlot)
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      hRead ws₁ 10 accSlot = ∑ i : Fin n, f i ∧
      ExecBit inp maxIdx K (sumLoopStmt ctrSlot accSlot countE termE) ws₀ ws₁
        ((3 + 2 * n) * stepU) ((3 + 2 * n) * stepB K) := by
  intro mod
  have hacc_wf : decide (accSlot.natAbs ≤ 64) = true := decide_eq_true (by omega)
  have hctr_wf : ctrSlot.natAbs ≤ 64 := by omega
  have hs0 := exec_write hctx hws₀ 10 (.lit accSlot) (.lit 0) accSlot 0 rfl rfl
    hslots.2.2.1 (by omega) (by simp) (by decide)
    (by simp [exprWf, hacc_wf]) (by decide) (by dsimp [exprNodes, exprLeaves]; omega)
  let ws1 := hWrite ws₀ 10 accSlot 0
  have hpr1 : PreservesOutside mod ws₀ ws1 :=
    PreservesOutside.write ws₀ 0 (by dsimp [mod]; omega)
  let Inv : ℕ → UL.WordStore → Prop := fun k ws =>
    PreservesOutside mod ws₀ ws ∧
    ((hk : k ≤ n) → hRead ws 10 accSlot = prefixSum f k hk)
  have hInv0 : Inv 0 (hWrite ws1 10 ctrSlot 0) := by
    refine ⟨hpr1.trans (PreservesOutside.write ws1 0 (by dsimp [mod]; omega)), fun hk => ?_⟩
    rw [prefixSum_zero, hRead_hWrite_of_ne ws1 0 (Or.inr hslots.2.2.2.2.symm), hRead_hWrite_self]
  have hcnt1 : evalVal inp (hWrite ws1 10 ctrSlot 0) countE = (n : ℤ) :=
    hcnt _ (hpr1.trans (PreservesOutside.write ws1 0 (by dsimp [mod]; omega)))
  obtain ⟨ws2, _, ⟨hpr2, hdone⟩, hs1⟩ := exec_for hctx ctrSlot countE
    (.writeHeap 10 (.lit accSlot) (.add (.readHeap 10 (.lit accSlot)) termE))
    n 1 Inv hs0.2.1 (by omega) hn_ub hcnt1 hInv0
    (fun k hk ws hws hctr_k ⟨hpr, hacc_k⟩ => by
      have hterm_k : evalVal inp ws termE = f ⟨k, hk⟩ := hterm k hk ws hpr hctr_k
      have hval_add : evalVal inp ws (.add (.readHeap 10 (.lit accSlot)) termE) =
          prefixSum f (k + 1) hk := by
        rw [prefixSum_succ]
        simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hacc_k hk.le, hterm_k]
      have hv_abs : (prefixSum f (k + 1) hk).natAbs ≤ 2 ^ K :=
        (prefixSum_natAbs_le f hfB (k + 1) hk).trans
          ((Nat.mul_le_mul_right B hk).trans hsumB)
      have hw := exec_write hctx hws 10 (.lit accSlot)
        (.add (.readHeap 10 (.lit accSlot)) termE)
        accSlot (prefixSum f (k + 1) hk) rfl hval_add
        hslots.2.2.1 (by omega) hv_abs (by decide)
        (by simp [exprWf, hacc_wf])
        (by simp [exprWf, hacc_wf, hwf_term])
        (by dsimp [exprNodes, exprLeaves]; omega)
      let ws' := hWrite ws 10 accSlot (prefixSum f (k + 1) hk)
      refine ⟨ws', hw, ?_, ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inr hslots.2.2.2.2), hctr_k]
      · refine ⟨(hpr.trans (PreservesOutside.write ws _ (by dsimp [mod]; omega))).trans
            (PreservesOutside.write ws' _ (by dsimp [mod]; omega)), fun _ => ?_⟩
        rw [hRead_hWrite_of_ne ws' _ (Or.inr hslots.2.2.2.2.symm), hRead_hWrite_self])
    hctr_wf hslots.1 hwf_cnt hsz_cnt
  have htot := (hs0.seq_steps hs1).mono_steps
    (show 1 + (2 + n * (1 + 1)) ≤ 3 + 2 * n by ring_nf; omega)
  have hdone' := hdone le_rfl
  rw [prefixSum_eq_sum] at hdone'
  exact ⟨ws2, hpr2, hdone', htot⟩


/-! ### 2. `ellParam` Monotonicity & Global Magnitude Bounds (`5 * B_sqrt ≤ K`) -/

theorem ellParamE_mono_L {N L₁ L₂ : ℕ} (h : L₁ ≤ L₂) :
    ellParamE N L₁ ≤ ellParamE N L₂ :=
  Nat.mul_le_mul_left (N + 2) (Nat.add_le_add_left h (N + 2))

theorem ellParamT_mono_L {N L₁ L₂ : ℕ} (h : L₁ ≤ L₂) :
    ellParamT N L₁ ≤ ellParamT N L₂ := by
  dsimp [ellParamT]
  have hE := ellParamE_mono_L (N := N) h
  exact Nat.add_le_add_right (Nat.mul_le_mul_left _ (by omega)) 1

theorem ellParamBsqrt_mono_L {N L₁ L₂ : ℕ} (h : L₁ ≤ L₂) :
    ellParamBsqrt N L₁ ≤ ellParamBsqrt N L₂ := by
  dsimp [ellParamBsqrt]
  have hE := ellParamE_mono_L (N := N) h
  have hT := ellParamT_mono_L (N := N) h
  omega

theorem five_ellParamBsqrt_le_solverK {nVars nEq nLe B' L : ℕ}
    (hL : L ≤ B' * (nVars + 2)) :
    5 * ellParamBsqrt (nVars + 2) L ≤ solverK nVars nEq nLe B' := by
  have hm := ellParamBsqrt_mono_L (N := nVars + 2) hL
  dsimp [solverK]
  omega

theorem ell_basic_exp_bounds {N L K : ℕ} (hN : 2 ≤ N) (hL : 1 ≤ L)
    (hBK : 5 * ellParamBsqrt N L ≤ K) :
    let E := ellParamE N L
    let T := ellParamT N L
    let B_sqrt := ellParamBsqrt N L
    20 ≤ E ∧
    N + L ≤ E ∧
    9 + 6 * N ≤ 2 * E ∧
    6 * E ≤ K ∧
    E + 1 ≤ K ∧
    7 * E ≤ K ∧
    B_sqrt ≤ K ∧
    2 * B_sqrt ≤ K ∧
    (E : ℤ).natAbs ≤ 2 ^ K ∧
    (T : ℤ).natAbs ≤ 2 ^ K ∧
    (B_sqrt : ℤ).natAbs ≤ 2 ^ K ∧
    (16 * (N : ℤ) * (N : ℤ)).natAbs ≤ 2 ^ K := by
  intro E T B_sqrt
  have hE20 : 20 ≤ E := by
    dsimp [E, ellParamE]
    calc 20 = 4 * 5 := rfl
      _ ≤ (N + 2) * (N + 2 + L) := Nat.mul_le_mul (by omega) (by omega)
  have hNLE : N + L ≤ E := by
    dsimp [E, ellParamE]
    have h1 : 1 * (N + 2 + L) ≤ (N + 2) * (N + 2 + L) := Nat.mul_le_mul_right _ (by omega)
    omega
  have h96 : 9 + 6 * N ≤ 2 * E := by
    have h1 : (N + 2) * (N + 3) ≤ E := by
      dsimp [E, ellParamE]
      exact Nat.mul_le_mul_left (N + 2) (by omega)
    have h2 : 9 + 6 * N ≤ 2 * ((N + 2) * (N + 3)) := by
      have : 2 * ((N + 2) * (N + 3)) = 2 * N * N + 10 * N + 12 := by ring
      omega
    omega
  have hEB : 10 * E + 2 * T = B_sqrt := rfl
  have hBK1 : B_sqrt ≤ K := by omega
  have hE_abs : (E : ℤ).natAbs ≤ 2 ^ K := by
    rw [Int.natAbs_natCast]
    exact Nat.lt_two_pow_self.le.trans (Nat.pow_le_pow_right (by omega) (by omega))
  have hT_abs : (T : ℤ).natAbs ≤ 2 ^ K := by
    rw [Int.natAbs_natCast]
    exact Nat.lt_two_pow_self.le.trans (Nat.pow_le_pow_right (by omega) (by omega))
  have hB_abs : (B_sqrt : ℤ).natAbs ≤ 2 ^ K := by
    rw [Int.natAbs_natCast]
    exact Nat.lt_two_pow_self.le.trans (Nat.pow_le_pow_right (by omega) hBK1)
  have hKell_abs : (16 * (N : ℤ) * (N : ℤ)).natAbs ≤ 2 ^ K := by
    have hEq : (16 * (N : ℤ) * (N : ℤ)).natAbs = 16 * N * N := by
      have : (16 * (N : ℤ) * (N : ℤ)) = ((16 * N * N : ℕ) : ℤ) := by push_cast; ring
      rw [this, Int.natAbs_natCast]
    rw [hEq]
    have hN2 : N ≤ 2 ^ N := Nat.lt_two_pow_self.le
    have h1 : 16 * N * N ≤ 2 ^ (4 + 2 * N) := by
      calc 16 * N * N = 2 ^ 4 * N ^ 2 := by ring
        _ ≤ 2 ^ 4 * (2 ^ N) ^ 2 := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hN2 2)
        _ = 2 ^ (4 + 2 * N) := by rw [← pow_mul, ← pow_add]; ring_nf
    have h2 : 4 + 2 * N ≤ K := by omega
    exact h1.trans (Nat.pow_le_pow_right (by omega) h2)
  exact ⟨hE20, hNLE, h96, by omega, by omega, by omega, hBK1, by omega,
    hE_abs, hT_abs, hB_abs, hKell_abs⟩

theorem ell_step_mag_helpers {m N L t K : ℕ} (hN : 2 ≤ N) (hL : 1 ≤ L)
    (ht : t < ellParamT N L) (hBK : 5 * ellParamBsqrt N L ≤ K)
    {M_pad : Fin m → Fin N → ℤ}
    (hM : ∀ (i : Fin m) (j : Fin N), (M_pad i j).natAbs ≤ 2 ^ L)
    {st : EllState N} (hMag : EllMagInv (ellParamE N L) t st) :
    let E := ellParamE N L
    (∀ (i : Fin m) (j : Fin N),
      (M_pad i j * st.C j).natAbs ≤ 2 ^ L * (t * 2 ^ (9 * E + 2 * t))) ∧
    N * (2 ^ L * (t * 2 ^ (9 * E + 2 * t))) ≤ 2 ^ K ∧
    (∀ (i₀ : Fin m) (k j : Fin N),
      (M_pad i₀ k * st.A k j).natAbs ≤ 2 ^ L * 2 ^ (8 * E + 2 * t)) ∧
    N * (2 ^ L * 2 ^ (8 * E + 2 * t)) ≤ 2 ^ (9 * E + 2 * t) ∧
    2 ^ (9 * E + 2 * t) ≤ 2 ^ K ∧
    N * (2 ^ (9 * E + 2 * t) * 2 ^ (9 * E + 2 * t)) ≤ 2 ^ K ∧
    (∀ (i k : Fin N) (gk : ℤ), gk.natAbs ≤ 2 ^ (9 * E + 2 * t) →
      (st.A i k * gk).natAbs ≤ 2 ^ (17 * E + 4 * t)) ∧
    N * 2 ^ (17 * E + 4 * t) ≤ 2 ^ (18 * E + 4 * t) ∧
    2 ^ (18 * E + 4 * t) ≤ 2 ^ K := by
  intro E
  let B_sqrt := ellParamBsqrt N L
  obtain ⟨hE20, hNLE, _, _, _, _, hBK1, _, _, _, _, _⟩ := ell_basic_exp_bounds hN hL hBK
  have hEB : 10 * E + 2 * ellParamT N L = B_sqrt := rfl
  have hN_pow : N ≤ 2 ^ N := Nat.lt_two_pow_self.le
  have hNE : N ≤ 2 ^ E := hN_pow.trans (Nat.pow_le_pow_right (by omega) (by omega))
  have hNL_pow : N * 2 ^ L ≤ 2 ^ E := by
    calc N * 2 ^ L ≤ 2 ^ N * 2 ^ L := Nat.mul_le_mul_right _ hN_pow
      _ = 2 ^ (N + L) := (pow_add 2 N L).symm
      _ ≤ 2 ^ E := Nat.pow_le_pow_right (by omega) hNLE
  have ht_pow : t ≤ 2 ^ B_sqrt :=
    Nat.lt_two_pow_self.le.trans (Nat.pow_le_pow_right (by omega) (by omega))
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro i j
    rw [Int.natAbs_mul]
    exact Nat.mul_le_mul (hM i j) (hMag.2 j)
  · calc N * (2 ^ L * (t * 2 ^ (9 * E + 2 * t)))
        = (N * 2 ^ L) * t * 2 ^ (9 * E + 2 * t) := by ring
      _ ≤ 2 ^ E * 2 ^ B_sqrt * 2 ^ B_sqrt :=
          Nat.mul_le_mul (Nat.mul_le_mul hNL_pow ht_pow)
            (Nat.pow_le_pow_right (by omega) (by omega))
      _ = 2 ^ (E + 2 * B_sqrt) := by rw [← pow_add, ← pow_add]; ring_nf
      _ ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) (by omega)
  · intro i₀ k j
    rw [Int.natAbs_mul]
    exact Nat.mul_le_mul (hM i₀ k) (ellMagInv_entry_abs hMag k j)
  · calc N * (2 ^ L * 2 ^ (8 * E + 2 * t))
        = (N * 2 ^ L) * 2 ^ (8 * E + 2 * t) := by ring
      _ ≤ 2 ^ E * 2 ^ (8 * E + 2 * t) := Nat.mul_le_mul_right _ hNL_pow
      _ = 2 ^ (9 * E + 2 * t) := by rw [← pow_add]; ring_nf
  · exact Nat.pow_le_pow_right (by omega) (by omega)
  · calc N * (2 ^ (9 * E + 2 * t) * 2 ^ (9 * E + 2 * t))
        ≤ 2 ^ E * (2 ^ B_sqrt * 2 ^ B_sqrt) :=
          Nat.mul_le_mul hNE (Nat.mul_le_mul
            (Nat.pow_le_pow_right (by omega) (by omega))
            (Nat.pow_le_pow_right (by omega) (by omega)))
      _ = 2 ^ (E + 2 * B_sqrt) := by rw [← pow_add, ← pow_add]; ring_nf
      _ ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) (by omega)
  · intro i k gk hgk
    rw [Int.natAbs_mul]
    calc (st.A i k).natAbs * gk.natAbs
        ≤ 2 ^ (8 * E + 2 * t) * 2 ^ (9 * E + 2 * t) :=
          Nat.mul_le_mul (ellMagInv_entry_abs hMag i k) hgk
      _ = 2 ^ (17 * E + 4 * t) := by rw [← pow_add]; ring_nf
  · calc N * 2 ^ (17 * E + 4 * t)
        ≤ 2 ^ E * 2 ^ (17 * E + 4 * t) := Nat.mul_le_mul_right _ hNE
      _ = 2 ^ (18 * E + 4 * t) := by rw [← pow_add]; ring_nf
  · exact Nat.pow_le_pow_right (by omega) (by omega)

theorem ell_update_scalars_bound {N L t K : ℕ} (hN : 2 ≤ N) (hL : 1 ≤ L)
    (ht : t < ellParamT N L) (hBK : 5 * ellParamBsqrt N L ≤ K)
    {L_ceil : ℤ} (hLc1 : 1 ≤ L_ceil) (hLcB : L_ceil ≤ (2 : ℤ) ^ ellParamBsqrt N L)
    {aij hi gj : ℤ}
    (haij : aij.natAbs ≤ 2 ^ (8 * ellParamE N L + 2 * t))
    (hhi : hi.natAbs ≤ 2 ^ (18 * ellParamE N L + 4 * t))
    (hgj : gj.natAbs ≤ 2 ^ (9 * ellParamE N L + 2 * t)) :
    let K_ell : ℤ := 16 * (N : ℤ) * (N : ℤ)
    (((N : ℤ) + 1) * L_ceil).natAbs ≤ 2 ^ K ∧
    (8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) * L_ceil * L_ceil).natAbs ≤ 2 ^ K ∧
    ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * aij).natAbs ≤ 2 ^ K ∧
    ((2 * (N : ℤ) - 1) * (K_ell * K_ell) * hi * gj).natAbs ≤ 2 ^ K := by
  intro K_ell
  let E := ellParamE N L
  let B_sqrt := ellParamBsqrt N L
  obtain ⟨hE20, hNLE, h96, _, _, _, _, _, _, _, _, _⟩ := ell_basic_exp_bounds hN hL hBK
  have hEB : 10 * E + 2 * ellParamT N L = B_sqrt := rfl
  have hN_pow : N ≤ 2 ^ N := Nat.lt_two_pow_self.le
  have hLc_abs : L_ceil.natAbs ≤ 2 ^ B_sqrt := by
    have h0 : 0 ≤ L_ceil := by omega
    have hEq : (L_ceil.natAbs : ℤ) = L_ceil := Int.natAbs_of_nonneg h0
    have hleZ : (L_ceil.natAbs : ℤ) ≤ ((2 ^ B_sqrt : ℕ) : ℤ) := by
      rw [hEq]; simpa using hLcB
    exact Nat.cast_le.mp hleZ
  have hN1_pow : N + 1 ≤ 2 ^ E := by
    have h1 : N < 2 ^ N := Nat.lt_two_pow_self
    exact (Nat.succ_le_of_lt h1).trans (Nat.pow_le_pow_right (by omega) (by omega))
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [Int.natAbs_mul]
    have hc : ((N : ℤ) + 1).natAbs = N + 1 := by
      have : ((N : ℤ) + 1) = ((N + 1 : ℕ) : ℤ) := by push_cast; ring
      rw [this, Int.natAbs_natCast]
    rw [hc]
    calc (N + 1) * L_ceil.natAbs
        ≤ 2 ^ E * 2 ^ B_sqrt := Nat.mul_le_mul hN1_pow hLc_abs
      _ = 2 ^ (E + B_sqrt) := (pow_add 2 E B_sqrt).symm
      _ ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) (by omega)
  · have hpos1 : 0 ≤ (2 * (N : ℤ) * (N : ℤ) - 2) := by
      have hNZ : (2 : ℤ) ≤ (N : ℤ) := by omega
      nlinarith only [hNZ]
    have hc : (8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2)).natAbs ≤ 16 * N ^ 4 := by
      have hle : 8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) ≤
          ((16 * N ^ 4 : ℕ) : ℤ) := by
        push_cast
        have hNZ : (2 : ℤ) ≤ (N : ℤ) := by omega
        nlinarith only [hNZ]
      have h0 : 0 ≤ 8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) :=
        mul_nonneg (by positivity) hpos1
      have hEq : ((8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2)).natAbs : ℤ) ≤
          ((16 * N ^ 4 : ℕ) : ℤ) := by
        rw [Int.natAbs_of_nonneg h0]; exact hle
      exact Nat.cast_le.mp hEq
    have h16N4 : 16 * N ^ 4 ≤ 2 ^ (2 * E) := by
      calc 16 * N ^ 4 = 2 ^ 4 * N ^ 4 := by ring
        _ ≤ 2 ^ 4 * (2 ^ N) ^ 4 := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hN_pow 4)
        _ = 2 ^ (4 + 4 * N) := by rw [← pow_mul, ← pow_add]; ring_nf
        _ ≤ 2 ^ (2 * E) := Nat.pow_le_pow_right (by omega) (by omega)
    rw [Int.natAbs_mul, Int.natAbs_mul]
    calc (8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2)).natAbs * L_ceil.natAbs * L_ceil.natAbs
        ≤ 2 ^ (2 * E) * 2 ^ B_sqrt * 2 ^ B_sqrt :=
          Nat.mul_le_mul (Nat.mul_le_mul (hc.trans h16N4) hLc_abs) hLc_abs
      _ = 2 ^ (2 * E + 2 * B_sqrt) := by rw [← pow_add, ← pow_add]; ring_nf
      _ ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) (by omega)
  · have hc : (2 * (N : ℤ) * (N : ℤ) - 1).natAbs ≤ 2 * N ^ 2 := by
      have hNZ : (2 : ℤ) ≤ (N : ℤ) := by omega
      have h0 : 0 ≤ 2 * (N : ℤ) * (N : ℤ) - 1 := by nlinarith only [hNZ]
      have hle : ((2 * (N : ℤ) * (N : ℤ) - 1).natAbs : ℤ) ≤ ((2 * N ^ 2 : ℕ) : ℤ) := by
        rw [Int.natAbs_of_nonneg h0]; push_cast; nlinarith only [hNZ]
      exact Nat.cast_le.mp hle
    have h2N2 : 2 * N ^ 2 ≤ 2 ^ E := by
      calc 2 * N ^ 2 ≤ 2 ^ 1 * (2 ^ N) ^ 2 :=
            Nat.mul_le_mul_left 2 (Nat.pow_le_pow_left hN_pow 2)
        _ = 2 ^ (1 + 2 * N) := by rw [← pow_mul, ← pow_add]; ring_nf
        _ ≤ 2 ^ E := Nat.pow_le_pow_right (by omega) (by omega)
    rw [Int.natAbs_mul, Int.natAbs_mul, Int.natAbs_mul]
    calc (2 * (N : ℤ) * (N : ℤ) - 1).natAbs * (L_ceil.natAbs * L_ceil.natAbs) * aij.natAbs
        ≤ 2 ^ E * (2 ^ B_sqrt * 2 ^ B_sqrt) * 2 ^ B_sqrt :=
          Nat.mul_le_mul (Nat.mul_le_mul (hc.trans h2N2) (Nat.mul_le_mul hLc_abs hLc_abs))
            (haij.trans (Nat.pow_le_pow_right (by omega) (by omega)))
      _ = 2 ^ (E + 3 * B_sqrt) := by rw [← pow_add, ← pow_add, ← pow_add]; ring_nf
      _ ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) (by omega)
  · have hc : ((2 * (N : ℤ) - 1) * (K_ell * K_ell)).natAbs ≤ 512 * N ^ 5 := by
      dsimp [K_ell]
      have hNZ : (2 : ℤ) ≤ (N : ℤ) := by omega
      have h0 : 0 ≤ (2 * (N : ℤ) - 1) * ((16 * (N : ℤ) * (N : ℤ)) * (16 * (N : ℤ) * (N : ℤ))) :=
        mul_nonneg (by omega) (mul_self_nonneg _)
      have hle : (((2 * (N : ℤ) - 1) * ((16 * (N : ℤ) * (N : ℤ)) * (16 * (N : ℤ) * (N : ℤ)))).natAbs : ℤ) ≤
          ((512 * N ^ 5 : ℕ) : ℤ) := by
        rw [Int.natAbs_of_nonneg h0]
        push_cast
        have hposK : 0 ≤ (N : ℤ) ^ 4 := by positivity
        nlinarith only [hNZ, hposK]
      exact Nat.cast_le.mp hle
    have h512 : 512 * N ^ 5 ≤ 2 ^ (2 * E) := by
      calc 512 * N ^ 5 = 2 ^ 9 * N ^ 5 := by ring
        _ ≤ 2 ^ 9 * (2 ^ N) ^ 5 := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hN_pow 5)
        _ = 2 ^ (9 + 5 * N) := by rw [← pow_mul, ← pow_add]; ring_nf
        _ ≤ 2 ^ (2 * E) := Nat.pow_le_pow_right (by omega) (by omega)
    rw [Int.natAbs_mul, Int.natAbs_mul]
    calc ((2 * (N : ℤ) - 1) * (K_ell * K_ell)).natAbs * hi.natAbs * gj.natAbs
        ≤ 2 ^ (2 * E) * 2 ^ (18 * E + 4 * t) * 2 ^ (9 * E + 2 * t) :=
          Nat.mul_le_mul (Nat.mul_le_mul (hc.trans h512) hhi) hgj
      _ = 2 ^ (29 * E + 6 * t) := by rw [← pow_add, ← pow_add]; ring_nf
      _ ≤ 2 ^ (3 * B_sqrt) := Nat.pow_le_pow_right (by omega) (by omega)
      _ ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) (by omega)

theorem ellMagInv_state_abs_le {N L t K : ℕ}
    (hN : 2 ≤ N) (hL : 1 ≤ L) (ht : t ≤ ellParamT N L)
    (hBK : 5 * ellParamBsqrt N L ≤ K)
    {st : EllState N} (hMag : EllMagInv (ellParamE N L) t st) :
    (∀ i : Fin N, (st.C i).natAbs ≤ 2 ^ K) ∧
    (∀ i j : Fin N, (st.A i j).natAbs ≤ 2 ^ K) := by
  let E := ellParamE N L
  let B_sqrt := ellParamBsqrt N L
  obtain ⟨_, _, _, _, _, _, hBK1, _, _, _, _, _⟩ := ell_basic_exp_bounds hN hL hBK
  have hEB : 10 * E + 2 * ellParamT N L = B_sqrt := rfl
  have ht_pow : t ≤ 2 ^ B_sqrt :=
    Nat.lt_two_pow_self.le.trans (Nat.pow_le_pow_right (by omega) (by omega))
  refine ⟨fun i => ?_, fun i j => ?_⟩
  · calc (st.C i).natAbs ≤ t * 2 ^ (9 * E + 2 * t) := hMag.2 i
      _ ≤ 2 ^ B_sqrt * 2 ^ B_sqrt :=
          Nat.mul_le_mul ht_pow (Nat.pow_le_pow_right (by omega) (by omega))
      _ = 2 ^ (2 * B_sqrt) := by rw [← pow_add]; ring_nf
      _ ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) (by omega)
  · exact (ellMagInv_entry_abs hMag i j).trans
      (Nat.pow_le_pow_right (by omega) (by omega))


/-! ### 3. `isqrtCeilStmt` & `exec_isqrtCeilStmt` -/

theorem isqrtStep_fold_bounds (B_sqrt : ℕ) (X : ℤ) :
    ∀ k : ℕ, k ≤ B_sqrt →
      let lh := Fin.foldl k (fun lh (_ : Fin k) => isqrtStep X lh) (0, (2 : ℤ) ^ B_sqrt)
      0 ≤ lh.1 ∧ lh.1 ≤ (2 : ℤ) ^ B_sqrt ∧ 0 ≤ lh.2 ∧ lh.2 ≤ (2 : ℤ) ^ B_sqrt := by
  intro k
  induction k with
  | zero =>
      intro _
      simp only [Fin.foldl_zero]
      exact ⟨le_rfl, by positivity, by positivity, le_rfl⟩
  | succ k ih =>
      intro hk
      rw [Fin.foldl_succ_last]
      have hprev_bnd := ih (Nat.le_of_succ_le hk)
      dsimp only at hprev_bnd ⊢
      generalize Fin.foldl k (fun lh (_ : Fin k) => isqrtStep X lh) (0, (2 : ℤ) ^ B_sqrt) = prev at hprev_bnd ⊢
      obtain ⟨h10, h1B, h20, h2B⟩ := hprev_bnd
      have hmid0 : 0 ≤ (prev.1 + prev.2) / 2 := Int.ediv_nonneg (by omega) (by omega)
      have hmidB : (prev.1 + prev.2) / 2 ≤ (2 : ℤ) ^ B_sqrt := by
        have hsum : prev.1 + prev.2 ≤ 2 * (2 : ℤ) ^ B_sqrt := by linarith
        omega
      dsimp only [isqrtStep]
      by_cases hc : X ≤ ((prev.1 + prev.2) / 2) * ((prev.1 + prev.2) / 2)
      · rw [if_pos hc]; exact ⟨h10, h1B, hmid0, hmidB⟩
      · rw [if_neg hc]; exact ⟨hmid0, hmidB, h20, h2B⟩

def isqrtCeilStmt : UL.BitRAMStmt :=
  let BsqrtE := UL.IntExpr.readHeap 10 (.lit 11)
  let powBE := UL.IntExpr.readHeap 10 (.lit 15)
  let XE := UL.IntExpr.readHeap 10 (.lit 21)
  let loE := UL.IntExpr.readHeap 10 (.lit 22)
  let hiE := UL.IntExpr.readHeap 10 (.lit 23)
  let midE := UL.IntExpr.readHeap 10 (.lit 24)
  seqBitStmts
    [ .writeHeap 10 (.lit 22) (.lit 0)
    , .writeHeap 10 (.lit 23) powBE
    , forLoopStmt 43 BsqrtE
        (.seq
          (.writeHeap 10 (.lit 24) (.div (.add loE hiE) (.lit 2)))
          (.ite (.intLe XE (.mul midE midE))
            (.writeHeap 10 (.lit 23) midE)
            (.writeHeap 10 (.lit 22) midE)))
    , .writeHeap 10 (.lit 25) hiE ]

theorem exec_isqrtCeilStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {B_sqrt maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hBK : B_sqrt ≤ K)
    {X : ℤ}
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hB_ws : hRead ws₀ 10 11 = (B_sqrt : ℤ))
    (hpow_ws : hRead ws₀ 10 15 = (2 : ℤ) ^ B_sqrt)
    (hX_ws : hRead ws₀ 10 21 = X) :
    let mod : ℕ → ℤ → Prop := fun t idx =>
      t = 10 ∧ (idx = 22 ∨ idx = 23 ∨ idx = 24 ∨ idx = 25 ∨ idx = 43)
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      hRead ws₁ 10 25 = isqrtCeil B_sqrt X ∧
      ExecBit inp maxIdx K isqrtCeilStmt ws₀ ws₁
        ((6 + 4 * B_sqrt) * stepU) ((6 + 4 * B_sqrt) * stepB K) := by
  intro mod
  have hB_pow : B_sqrt ≤ 2 ^ K :=
    Nat.lt_two_pow_self.le.trans (Nat.pow_le_pow_right (by omega) hBK)
  have hpow_abs : ((2 : ℤ) ^ B_sqrt).natAbs ≤ 2 ^ K := by
    have : ((2 : ℤ) ^ B_sqrt).natAbs = 2 ^ B_sqrt := by
      rw [show (2 : ℤ) ^ B_sqrt = ((2 ^ B_sqrt : ℕ) : ℤ) by push_cast; rfl, Int.natAbs_natCast]
    rw [this]; exact Nat.pow_le_pow_right (by omega) hBK
  have hs1 := exec_write hctx hws₀ 10 (.lit 22) (.lit 0) 22 0 rfl rfl
    (by omega) (by omega) (by simp)
  let ws1 := hWrite ws₀ 10 22 0
  have hpow_ws1 : evalVal inp ws1 (.readHeap 10 (.lit 15)) = (2 : ℤ) ^ B_sqrt := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hpow_ws]
  have hs2 := exec_write hctx hs1.2.1 10 (.lit 23) (.readHeap 10 (.lit 15))
    23 ((2 : ℤ) ^ B_sqrt) rfl hpow_ws1 (by omega) (by omega) hpow_abs
  let ws2 := hWrite ws1 10 23 ((2 : ℤ) ^ B_sqrt)
  have hpr2 : PreservesOutside mod ws₀ ws2 :=
    (PreservesOutside.write ws₀ 0 (by dsimp [mod]; omega)).trans
      (PreservesOutside.write ws1 _ (by dsimp [mod]; omega))
  let lhAt : ℕ → ℤ × ℤ := fun k =>
    Fin.foldl k (fun lh (_ : Fin k) => isqrtStep X lh) (0, (2 : ℤ) ^ B_sqrt)
  let Inv : ℕ → UL.WordStore → Prop := fun k ws =>
    PreservesOutside mod ws₀ ws ∧
    hRead ws 10 22 = (lhAt k).1 ∧
    hRead ws 10 23 = (lhAt k).2
  have hInv0 : Inv 0 (hWrite ws2 10 43 0) := by
    refine ⟨hpr2.trans (PreservesOutside.write ws2 0 (by dsimp [mod]; omega)), ?_, ?_⟩
    · dsimp [lhAt, ws2, ws1]
      rw [Fin.foldl_zero,
          hRead_hWrite_of_ne (hWrite (hWrite ws₀ 10 22 0) 10 23 ((2 : ℤ) ^ B_sqrt)) 0 (Or.inr (by omega)),
          hRead_hWrite_of_ne (hWrite ws₀ 10 22 0) _ (Or.inr (by omega)),
          hRead_hWrite_self]
    · dsimp [lhAt, ws2]
      rw [Fin.foldl_zero,
          hRead_hWrite_of_ne (hWrite ws1 10 23 ((2 : ℤ) ^ B_sqrt)) 0 (Or.inr (by omega)),
          hRead_hWrite_self]
  have hcnt : evalVal inp (hWrite ws2 10 43 0) (.readHeap 10 (.lit 11)) = (B_sqrt : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws2 0 (Or.inr (by omega)), hpr2 10 11 (by dsimp [mod]; omega), hB_ws]
  obtain ⟨ws3, _, ⟨hpr3, hlo3, hhi3⟩, hs3⟩ := exec_for_val hctx 43 (.readHeap 10 (.lit 11))
    (.seq
      (.writeHeap 10 (.lit 24) (.div (.add (.readHeap 10 (.lit 22)) (.readHeap 10 (.lit 23))) (.lit 2)))
      (.ite (.intLe (.readHeap 10 (.lit 21)) (.mul (.readHeap 10 (.lit 24)) (.readHeap 10 (.lit 24))))
        (.writeHeap 10 (.lit 23) (.readHeap 10 (.lit 24)))
        (.writeHeap 10 (.lit 22) (.readHeap 10 (.lit 24)))))
    B_sqrt 3 Inv hs2.2.1 (by omega) hB_pow hcnt hInv0
    (fun k hk ws hws hctr_k ⟨hpr, hlo_k, hhi_k⟩ => by
      have hbnd := isqrtStep_fold_bounds B_sqrt X k hk.le
      change 0 ≤ (lhAt k).1 ∧ (lhAt k).1 ≤ (2 : ℤ) ^ B_sqrt ∧
        0 ≤ (lhAt k).2 ∧ (lhAt k).2 ≤ (2 : ℤ) ^ B_sqrt at hbnd
      obtain ⟨h10, h1B, h20, h2B⟩ := hbnd
      let mid := ((lhAt k).1 + (lhAt k).2) / 2
      have hmid0 : 0 ≤ mid := Int.ediv_nonneg (by omega) (by omega)
      have hmidB : mid ≤ (2 : ℤ) ^ B_sqrt := by
        dsimp [mid]; omega
      have hmid_abs : mid.natAbs ≤ 2 ^ K := by
        have hleZ : (mid.natAbs : ℤ) ≤ ((2 ^ B_sqrt : ℕ) : ℤ) := by
          rw [Int.natAbs_of_nonneg hmid0]; simpa using hmidB
        exact (Nat.cast_le.mp hleZ).trans (Nat.pow_le_pow_right (by omega) hBK)
      have hmid_ev : evalVal inp ws
          (.div (.add (.readHeap 10 (.lit 22)) (.readHeap 10 (.lit 23))) (.lit 2)) = mid := by
        simp only [evalVal_div, evalVal_add, evalVal_readHeap, evalVal_lit, hlo_k, hhi_k]; rfl
      have hw_mid := exec_write hctx hws 10 (.lit 24)
        (.div (.add (.readHeap 10 (.lit 22)) (.readHeap 10 (.lit 23))) (.lit 2))
        24 mid rfl hmid_ev (by omega) (by omega) hmid_abs
      let wsm := hWrite ws 10 24 mid
      have hX_wsm : hRead wsm 10 21 = X := by
        rw [hRead_hWrite_of_ne ws mid (Or.inr (by omega)), hpr 10 21 (by dsimp [mod]; omega), hX_ws]
      have h24_wsm : hRead wsm 10 24 = mid := hRead_hWrite_self ws 10 24 mid
      have hfold_succ : lhAt (k + 1) = isqrtStep X (lhAt k) := by
        dsimp [lhAt]; rw [Fin.foldl_succ_last]
      by_cases hc : X ≤ mid * mid
      · have hcond : evalCondVal inp wsm
            (.intLe (.readHeap 10 (.lit 21)) (.mul (.readHeap 10 (.lit 24)) (.readHeap 10 (.lit 24)))) = true := by
          simp only [evalCondVal_intLe, evalVal_readHeap, evalVal_mul, evalVal_lit,
            hX_wsm, h24_wsm, decide_eq_true_eq]
          exact hc
        have hw_hi := exec_write hctx hw_mid.2.1 10 (.lit 23) (.readHeap 10 (.lit 24))
          23 mid rfl (by simp only [evalVal_readHeap, evalVal_lit]; exact hRead_hWrite_self ws 10 24 mid)
          (by omega) (by omega) hmid_abs
        have hite := exec_ite_true hctx
          (.intLe (.readHeap 10 (.lit 21)) (.mul (.readHeap 10 (.lit 24)) (.readHeap 10 (.lit 24))))
          (.writeHeap 10 (.lit 23) (.readHeap 10 (.lit 24)))
          (.writeHeap 10 (.lit 22) (.readHeap 10 (.lit 24)))
          hcond hw_hi
        let ws' := hWrite wsm 10 23 mid
        refine ⟨ws', hw_mid.seq_steps hite, ?_, ?_⟩
        · rw [hRead_hWrite_of_ne wsm mid (Or.inr (by omega)),
              hRead_hWrite_of_ne ws mid (Or.inr (by omega)), hctr_k]
        · refine ⟨((hpr.trans (PreservesOutside.write ws mid (by dsimp [mod]; omega))).trans
              (PreservesOutside.write wsm mid (by dsimp [mod]; omega))).trans
              (PreservesOutside.write ws' _ (by dsimp [mod]; omega)), ?_, ?_⟩
          · rw [hfold_succ]; dsimp [isqrtStep]; rw [if_pos hc]
            rw [hRead_hWrite_of_ne ws' _ (Or.inr (by omega)),
                hRead_hWrite_of_ne wsm mid (Or.inr (by omega)),
                hRead_hWrite_of_ne ws mid (Or.inr (by omega)), hlo_k]
          · rw [hfold_succ]; dsimp [isqrtStep]; rw [if_pos hc]
            rw [hRead_hWrite_of_ne ws' _ (Or.inr (by omega)), hRead_hWrite_self]
      · have hcond : evalCondVal inp wsm
            (.intLe (.readHeap 10 (.lit 21)) (.mul (.readHeap 10 (.lit 24)) (.readHeap 10 (.lit 24)))) = false := by
          simp only [evalCondVal_intLe, evalVal_readHeap, evalVal_mul, evalVal_lit,
            hX_wsm, h24_wsm, decide_eq_false_iff_not]
          exact hc
        have hw_lo := exec_write hctx hw_mid.2.1 10 (.lit 22) (.readHeap 10 (.lit 24))
          22 mid rfl (by simp only [evalVal_readHeap, evalVal_lit]; exact hRead_hWrite_self ws 10 24 mid)
          (by omega) (by omega) hmid_abs
        have hite := exec_ite_false hctx
          (.intLe (.readHeap 10 (.lit 21)) (.mul (.readHeap 10 (.lit 24)) (.readHeap 10 (.lit 24))))
          (.writeHeap 10 (.lit 23) (.readHeap 10 (.lit 24)))
          (.writeHeap 10 (.lit 22) (.readHeap 10 (.lit 24)))
          hcond hw_lo
        let ws' := hWrite wsm 10 22 mid
        refine ⟨ws', hw_mid.seq_steps hite, ?_, ?_⟩
        · rw [hRead_hWrite_of_ne wsm mid (Or.inr (by omega)),
              hRead_hWrite_of_ne ws mid (Or.inr (by omega)), hctr_k]
        · refine ⟨((hpr.trans (PreservesOutside.write ws mid (by dsimp [mod]; omega))).trans
              (PreservesOutside.write wsm mid (by dsimp [mod]; omega))).trans
              (PreservesOutside.write ws' _ (by dsimp [mod]; omega)), ?_, ?_⟩
          · rw [hfold_succ]; dsimp [isqrtStep]; rw [if_neg hc]
            rw [hRead_hWrite_of_ne ws' _ (Or.inr (by omega)), hRead_hWrite_self]
          · rw [hfold_succ]; dsimp [isqrtStep]; rw [if_neg hc]
            rw [hRead_hWrite_of_ne ws' _ (Or.inr (by omega)),
                hRead_hWrite_of_ne wsm mid (Or.inr (by omega)),
                hRead_hWrite_of_ne ws mid (Or.inr (by omega)), hhi_k])
  have hhi3_abs : (lhAt B_sqrt).2.natAbs ≤ 2 ^ K := by
    rw [← hhi3]; exact storeBounded_read_abs hs3.2.1 (.heap 10 23)
  have hs4 := exec_write hctx hs3.2.1 10 (.lit 25) (.readHeap 10 (.lit 23))
    25 (lhAt B_sqrt).2 rfl (by simp only [evalVal_readHeap, evalVal_lit, hhi3])
    (by omega) (by omega) hhi3_abs
  let ws4 := hWrite ws3 10 25 (lhAt B_sqrt).2
  have htot := (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps hs4))).mono_steps
    (show 1 + (1 + ((2 + B_sqrt * (3 + 1)) + 1)) ≤ 6 + 4 * B_sqrt by ring_nf; omega)
  refine ⟨ws4, hpr3.trans (PreservesOutside.write ws3 _ (by dsimp [mod]; omega)), ?_, htot⟩
  rw [hRead_hWrite_self]; rfl


/-! ### 4. `findViolatedRowStmt` & `exec_findViolatedRowStmt` -/

def findViolatedRowStmt : UL.BitRAMStmt :=
  let NE := UL.IntExpr.readHeap 10 (.lit 3)
  let mOraE := UL.IntExpr.readHeap 10 (.lit 4)
  let PE := UL.IntExpr.readHeap 10 (.lit 12)
  let QE := UL.IntExpr.readHeap 10 (.lit 13)
  let violE := UL.IntExpr.readHeap 10 (.lit 18)
  let accE := UL.IntExpr.readHeap 10 (.lit 19)
  let iE := UL.IntExpr.readHeap 10 (.lit 42)
  let jE := UL.IntExpr.readHeap 10 (.lit 43)
  .seq
    (.writeHeap 10 (.lit 18) (.lit (-1)))
    (forLoopStmt 42 mOraE
      (.seq
        (sumLoopStmt 43 19 NE
          (.mul (.readHeap 24 (.add (.mul iE NE) jE)) (.readHeap 26 jE)))
        (.ite (.and (.intEq violE (.lit (-1)))
                (.intLt (.mul PE (.add (.mul QE (.readHeap 25 iE)) (.lit 1)))
                        (.mul QE accE)))
          (.writeHeap 10 (.lit 18) iE)
          .skip)))

theorem exec_findViolatedRowStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {N m_ora maxIdx K B_prod : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : N ≤ maxIdx ∧ m_ora ≤ maxIdx)
    {P Q : ℤ}
    {M_pad : Fin m_ora → Fin N → ℤ} {rhs : Fin m_ora → ℤ} {C : Fin N → ℤ}
    (hProdB : ∀ (i : Fin m_ora) (j : Fin N), (M_pad i j * C j).natAbs ≤ B_prod)
    (hSumB : N * B_prod ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hN_ws : hRead ws₀ 10 3 = (N : ℤ))
    (hm_ws : hRead ws₀ 10 4 = (m_ora : ℤ))
    (hP_ws : hRead ws₀ 10 12 = P)
    (hQ_ws : hRead ws₀ 10 13 = Q)
    (hM_ws : ∀ (i : Fin m_ora) (j : Fin N), hRead ws₀ 24 ((i.val * N + j.val : ℕ) : ℤ) = M_pad i j)
    (hd_ws : ∀ i : Fin m_ora, hRead ws₀ 25 (i.val : ℤ) = rhs i)
    (hC_ws : ∀ j : Fin N, hRead ws₀ 26 (j.val : ℤ) = C j) :
    let mod : ℕ → ℤ → Prop := fun t idx =>
      t = 10 ∧ (idx = 18 ∨ idx = 19 ∨ idx = 42 ∨ idx = 43)
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      hRead ws₁ 10 18 = findViolatedRow P Q M_pad rhs C ∧
      ExecBit inp maxIdx K findViolatedRowStmt ws₀ ws₁
        ((4 + m_ora * (6 + 2 * N)) * stepU) ((4 + m_ora * (6 + 2 * N)) * stepB K) := by
  intro mod
  have hs0 := exec_write hctx hws₀ 10 (.lit 18) (.lit (-1)) 18 (-1) rfl rfl
    (by omega) (by omega) Nat.one_le_two_pow
  let ws1 := hWrite ws₀ 10 18 (-1)
  have hpr1 : PreservesOutside mod ws₀ ws1 :=
    PreservesOutside.write ws₀ (-1) (by dsimp [mod]; omega)
  let stepFn : ℤ → Fin m_ora → ℤ := fun v i =>
    if v == -1 && P * (Q * rhs i + 1) < Q * (∑ j : Fin N, M_pad i j * C j) then (i.val : ℤ) else v
  let violAt : (r : ℕ) → r ≤ m_ora → ℤ := fun r hr =>
    Fin.foldl r (fun v (i : Fin r) => stepFn v ⟨i.val, lt_of_lt_of_le i.isLt hr⟩) (-1)
  let Inv : ℕ → UL.WordStore → Prop := fun r ws =>
    PreservesOutside mod ws₀ ws ∧
    ((hr : r ≤ m_ora) → hRead ws 10 18 = violAt r hr)
  have hInv0 : Inv 0 (hWrite ws1 10 42 0) := by
    refine ⟨hpr1.trans (PreservesOutside.write ws1 0 (by dsimp [mod]; omega)), fun _ => ?_⟩
    dsimp [violAt, ws1]
    rw [Fin.foldl_zero, hRead_hWrite_of_ne (hWrite ws₀ 10 18 (-1)) 0 (Or.inr (by omega)),
        hRead_hWrite_self]
  have hcnt : evalVal inp (hWrite ws1 10 42 0) (.readHeap 10 (.lit 4)) = (m_ora : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws1 0 (Or.inr (by omega)), hpr1 10 4 (by dsimp [mod]; omega), hm_ws]
  obtain ⟨ws2, _, ⟨hpr2, hdone⟩, hs1⟩ := exec_for hctx 42 (.readHeap 10 (.lit 4))
    (.seq
      (sumLoopStmt 43 19 (.readHeap 10 (.lit 3))
        (.mul (.readHeap 24 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3)))
          (.readHeap 10 (.lit 43)))) (.readHeap 26 (.readHeap 10 (.lit 43)))))
      (.ite (.and (.intEq (.readHeap 10 (.lit 18)) (.lit (-1)))
              (.intLt (.mul (.readHeap 10 (.lit 12))
                        (.add (.mul (.readHeap 10 (.lit 13)) (.readHeap 25 (.readHeap 10 (.lit 42))))
                          (.lit 1)))
                      (.mul (.readHeap 10 (.lit 13)) (.readHeap 10 (.lit 19)))))
        (.writeHeap 10 (.lit 18) (.readHeap 10 (.lit 42)))
        .skip))
    m_ora (5 + 2 * N) Inv hs0.2.1 (by omega) hIdx.2 hcnt hInv0
    (fun r hr ws hws hctr_r ⟨hpr, hviol_r⟩ => by
      let rFin : Fin m_ora := ⟨r, hr⟩
      obtain ⟨ws_s, hpr_s, hsum_s, hex_s⟩ := exec_sumLoopStmt hctx 43 19
        (by omega) h64 hIdx.1
        (.readHeap 10 (.lit 3))
        (.mul (.readHeap 24 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3)))
          (.readHeap 10 (.lit 43)))) (.readHeap 26 (.readHeap 10 (.lit 43))))
        (by decide) (by decide) (by decide) (by decide)
        (fun j => M_pad rFin j * C j) (hProdB rFin) hSumB hws
        (fun w hp => by
          simp only [evalVal_readHeap, evalVal_lit]
          rw [hp 10 3 (by omega), hpr 10 3 (by dsimp [mod]; omega), hN_ws])
        (fun j hj w hp hctr_j => by
          have hr_w : hRead w 10 42 = (r : ℤ) := by rw [hp 10 42 (by omega), hctr_r]
          have hN_w : hRead w 10 3 = (N : ℤ) := by
            rw [hp 10 3 (by omega), hpr 10 3 (by dsimp [mod]; omega), hN_ws]
          have hij : (r : ℤ) * (N : ℤ) + (j : ℤ) = ((r * N + j : ℕ) : ℤ) := by push_cast; ring
          have hM_w : hRead w 24 ((r * N + j : ℕ) : ℤ) = M_pad rFin ⟨j, hj⟩ := by
            rw [hp 24 _ (by omega), hpr 24 _ (by dsimp [mod]; omega)]; exact hM_ws rFin ⟨j, hj⟩
          have hC_w : hRead w 26 (j : ℤ) = C ⟨j, hj⟩ := by
            rw [hp 26 _ (by omega), hpr 26 _ (by dsimp [mod]; omega)]; exact hC_ws ⟨j, hj⟩
          simp only [evalVal_mul, evalVal_readHeap, evalVal_add, evalVal_lit,
            hr_w, hN_w, hctr_j, hij, hM_w, hC_w])
      have hpr_ws_s : PreservesOutside mod ws₀ ws_s :=
        hpr.trans (hpr_s.mono (by intro t idx h; dsimp [mod]; omega))
      have hv_s : hRead ws_s 10 18 = violAt r hr.le := by
        rw [hpr_s 10 18 (by omega), hviol_r hr.le]
      have hr_s : hRead ws_s 10 42 = (r : ℤ) := by rw [hpr_s 10 42 (by omega), hctr_r]
      have hP_s : hRead ws_s 10 12 = P := by rw [hpr_ws_s 10 12 (by dsimp [mod]; omega), hP_ws]
      have hQ_s : hRead ws_s 10 13 = Q := by rw [hpr_ws_s 10 13 (by dsimp [mod]; omega), hQ_ws]
      have hd_s : hRead ws_s 25 (r : ℤ) = rhs rFin := by
        rw [hpr_ws_s 25 _ (by dsimp [mod]; omega)]; exact hd_ws rFin
      let bCond : Bool :=
        (violAt r hr.le == -1) &&
          decide (P * (Q * rhs rFin + 1) < Q * (∑ j : Fin N, M_pad rFin j * C j))
      let condE := UL.BitCondExpr.and (.intEq (.readHeap 10 (.lit 18)) (.lit (-1)))
        (.intLt (.mul (.readHeap 10 (.lit 12))
                  (.add (.mul (.readHeap 10 (.lit 13)) (.readHeap 25 (.readHeap 10 (.lit 42))))
                    (.lit 1)))
                (.mul (.readHeap 10 (.lit 13)) (.readHeap 10 (.lit 19))))
      have hcond_ev : evalCondVal inp ws_s condE = bCond := by
        simp only [condE, bCond, evalCondVal_and, evalCondVal_intEq, evalCondVal_intLt,
          evalVal_mul, evalVal_add, evalVal_readHeap, evalVal_lit,
          hv_s, hr_s, hP_s, hQ_s, hd_s, hsum_s]; rfl
      have hfold_succ : violAt (r + 1) hr = stepFn (violAt r hr.le) rFin := by
        dsimp [violAt]; rw [Fin.foldl_succ_last]; rfl
      cases hb : bCond
      · have hite := exec_ite_false hctx condE
          (.writeHeap 10 (.lit 18) (.readHeap 10 (.lit 42))) .skip
          (by rw [hcond_ev, hb]) (exec_skip hctx hex_s.2.1)
        refine ⟨ws_s, (hex_s.seq_steps hite).mono_steps (by omega), hr_s, ?_⟩
        refine ⟨hpr_ws_s.trans (PreservesOutside.write ws_s _ (by dsimp [mod]; omega)), fun _ => ?_⟩
        rw [hRead_hWrite_of_ne ws_s _ (Or.inr (by omega)), hv_s, hfold_succ]
        change violAt r hr.le = if bCond = true then (r : ℤ) else violAt r hr.le
        rw [hb]; rfl
      · have hr_abs : (r : ℤ).natAbs ≤ 2 ^ K := by
          rw [Int.natAbs_natCast]
          exact (hr.le.trans hIdx.2).trans hctx.hMaxIdx
        have hw_v := exec_write hctx hex_s.2.1 10 (.lit 18) (.readHeap 10 (.lit 42))
          18 (r : ℤ) rfl (by simp only [evalVal_readHeap, evalVal_lit, hr_s])
          (by omega) (by omega) hr_abs
        have hite := exec_ite_true hctx condE
          (.writeHeap 10 (.lit 18) (.readHeap 10 (.lit 42))) .skip
          (by rw [hcond_ev, hb]) hw_v
        let ws' := hWrite ws_s 10 18 (r : ℤ)
        refine ⟨ws', (hex_s.seq_steps hite).mono_steps (by omega), ?_, ?_⟩
        · rw [hRead_hWrite_of_ne ws_s _ (Or.inr (by omega)), hr_s]
        · refine ⟨(hpr_ws_s.trans (PreservesOutside.write ws_s _ (by dsimp [mod]; omega))).trans
              (PreservesOutside.write ws' _ (by dsimp [mod]; omega)), fun _ => ?_⟩
          rw [hRead_hWrite_of_ne ws' _ (Or.inr (by omega)), hRead_hWrite_self, hfold_succ]
          change (r : ℤ) = if bCond = true then (r : ℤ) else violAt r hr.le
          rw [hb]; rfl)
  have htot := (hs0.seq_steps hs1).mono_steps
    (show 1 + (2 + m_ora * (5 + 2 * N + 1)) ≤ 4 + m_ora * (6 + 2 * N) by ring_nf; omega)
  exact ⟨ws2, hpr2, hdone le_rfl, htot⟩


/-! ### 5. `ellStepStmt` & `exec_ellStepStmt` -/

def EllParamsInHeap {N m_ora : ℕ} (L : ℕ)
    (M_pad : Fin m_ora → Fin N → ℤ) (rhs : Fin m_ora → ℤ)
    (ws : UL.WordStore) : Prop :=
  let E := ellParamE N L
  let T := ellParamT N L
  let B_sqrt := ellParamBsqrt N L
  hRead ws 10 3 = (N : ℤ) ∧
  hRead ws 10 4 = (m_ora : ℤ) ∧
  hRead ws 10 7 = (L : ℤ) ∧
  hRead ws 10 9 = (E : ℤ) ∧
  hRead ws 10 10 = (T : ℤ) ∧
  hRead ws 10 11 = (B_sqrt : ℤ) ∧
  hRead ws 10 12 = (2 : ℤ) ^ (6 * E) ∧
  hRead ws 10 13 = (2 : ℤ) ^ (E + 1) ∧
  hRead ws 10 14 = (2 : ℤ) ^ (7 * E) ∧
  hRead ws 10 15 = (2 : ℤ) ^ B_sqrt ∧
  hRead ws 10 16 = 16 * (N : ℤ) * (N : ℤ) ∧
  (∀ (i : Fin m_ora) (j : Fin N), hRead ws 24 ((i.val * N + j.val : ℕ) : ℤ) = M_pad i j) ∧
  (∀ i : Fin m_ora, hRead ws 25 (i.val : ℤ) = rhs i)

theorem EllParamsInHeap.preserve {N m_ora L : ℕ}
    {M_pad : Fin m_ora → Fin N → ℤ} {rhs : Fin m_ora → ℤ}
    {mod : ℕ → ℤ → Prop} {ws₀ ws₁ : UL.WordStore}
    (h : EllParamsInHeap L M_pad rhs ws₀)
    (hpr : PreservesOutside mod ws₀ ws₁)
    (h10 : ∀ idx : ℤ, 3 ≤ idx → idx ≤ 16 → ¬ mod 10 idx)
    (h24 : ∀ idx : ℤ, ¬ mod 24 idx)
    (h25 : ∀ idx : ℤ, ¬ mod 25 idx) :
    EllParamsInHeap L M_pad rhs ws₁ := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, fun i j => ?_, fun i => ?_⟩
  · rw [hpr 10 3 (h10 3 (by omega) (by omega))]; exact h.1
  · rw [hpr 10 4 (h10 4 (by omega) (by omega))]; exact h.2.1
  · rw [hpr 10 7 (h10 7 (by omega) (by omega))]; exact h.2.2.1
  · rw [hpr 10 9 (h10 9 (by omega) (by omega))]; exact h.2.2.2.1
  · rw [hpr 10 10 (h10 10 (by omega) (by omega))]; exact h.2.2.2.2.1
  · rw [hpr 10 11 (h10 11 (by omega) (by omega))]; exact h.2.2.2.2.2.1
  · rw [hpr 10 12 (h10 12 (by omega) (by omega))]; exact h.2.2.2.2.2.2.1
  · rw [hpr 10 13 (h10 13 (by omega) (by omega))]; exact h.2.2.2.2.2.2.2.1
  · rw [hpr 10 14 (h10 14 (by omega) (by omega))]; exact h.2.2.2.2.2.2.2.2.1
  · rw [hpr 10 15 (h10 15 (by omega) (by omega))]; exact h.2.2.2.2.2.2.2.2.2.1
  · rw [hpr 10 16 (h10 16 (by omega) (by omega))]; exact h.2.2.2.2.2.2.2.2.2.2.1
  · rw [hpr 24 _ (h24 _)]; exact h.2.2.2.2.2.2.2.2.2.2.2.1 i j
  · rw [hpr 25 _ (h25 _)]; exact h.2.2.2.2.2.2.2.2.2.2.2.2 i

def EllStateInHeap {N : ℕ} (st : EllState N) (ws : UL.WordStore) : Prop :=
  hRead ws 10 17 = st.status ∧
  (∀ i : Fin N, hRead ws 26 (i.val : ℤ) = st.C i) ∧
  (∀ (i j : Fin N), hRead ws 27 ((i.val * N + j.val : ℕ) : ℤ) = st.A i j)

theorem EllStateInHeap.preserve {N : ℕ} {st : EllState N}
    {mod : ℕ → ℤ → Prop} {ws₀ ws₁ : UL.WordStore}
    (h : EllStateInHeap st ws₀)
    (hpr : PreservesOutside mod ws₀ ws₁)
    (h17 : ¬ mod 10 17)
    (h26 : ∀ idx : ℤ, 0 ≤ idx → idx < (N : ℤ) → ¬ mod 26 idx)
    (h27 : ∀ idx : ℤ, 0 ≤ idx → idx < ((N * N : ℕ) : ℤ) → ¬ mod 27 idx) :
    EllStateInHeap st ws₁ := by
  refine ⟨?_, fun i => ?_, fun i j => ?_⟩
  · rw [hpr 10 17 h17]; exact h.1
  · rw [hpr 26 _ (h26 _ (Nat.cast_nonneg _) (Nat.cast_lt.mpr i.isLt))]; exact h.2.1 i
  · rw [hpr 27 _ (h27 _ (Nat.cast_nonneg _) (Nat.cast_lt.mpr (row_col_lt_mul i.isLt j.isLt)))]
    exact h.2.2 i j

theorem ellStep_active_eq {m N L : ℕ} {M_pad : Fin m → Fin N → ℤ} {rhs : Fin m → ℤ}
    {st : EllState N} (hst0 : st.status = 0) (i₀ : Fin m)
    (hviol : findViolatedRow ((2 : ℤ) ^ (6 * ellParamE N L)) ((2 : ℤ) ^ (ellParamE N L + 1))
      M_pad rhs st.C = (i₀.val : ℤ))
    (hS_pos : 0 < ∑ j : Fin N, (∑ k : Fin N, M_pad i₀ k * st.A k j) *
                               (∑ k : Fin N, M_pad i₀ k * st.A k j)) :
    let B_sqrt := ellParamBsqrt N L
    let K_ell : ℤ := 16 * (N : ℤ) * (N : ℤ)
    let G : Fin N → ℤ := fun j => ∑ k : Fin N, M_pad i₀ k * st.A k j
    let S_norm : ℤ := ∑ j : Fin N, G j * G j
    let L_ceil : ℤ := isqrtCeil B_sqrt (K_ell * K_ell * S_norm)
    let H : Fin N → ℤ := fun i => ∑ k : Fin N, st.A i k * G k
    let denC : ℤ := ((N : ℤ) + 1) * L_ceil
    let denA : ℤ := 8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) * L_ceil * L_ceil
    ellStep L M_pad rhs st =
      { status := 0
        C := fun i => st.C i - (K_ell * H i) / denC
        A := fun i j =>
          ((8 * (N : ℤ) * (N : ℤ) + 1) *
            ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * st.A i j -
              (2 * (N : ℤ) - 1) * (K_ell * K_ell) * H i * G j)) / denA } := by
  intro B_sqrt K_ell G S_norm L_ceil H denC denA
  unfold ellStep
  have hne : ¬ ((st.status != 0) = true) := by simp [hst0]
  rw [if_neg hne]
  dsimp only
  have hv_cond : 0 ≤ findViolatedRow ((2 : ℤ) ^ (6 * ellParamE N L))
      ((2 : ℤ) ^ (ellParamE N L + 1)) M_pad rhs st.C ∧
      (findViolatedRow ((2 : ℤ) ^ (6 * ellParamE N L))
        ((2 : ℤ) ^ (ellParamE N L + 1)) M_pad rhs st.C).toNat < m := by
    rw [hviol]
    exact ⟨Nat.cast_nonneg _, by simp [i₀.isLt]⟩
  rw [dif_pos hv_cond]
  have hi₀_eq : (⟨(findViolatedRow ((2 : ℤ) ^ (6 * ellParamE N L))
      ((2 : ℤ) ^ (ellParamE N L + 1)) M_pad rhs st.C).toNat, hv_cond.2⟩ : Fin m) = i₀ := by
    ext; dsimp only; rw [hviol]; exact Int.toNat_natCast i₀.val
  rw [hi₀_eq]
  have hnot_le : ¬ (S_norm ≤ 0) := not_le.mpr hS_pos
  rw [if_neg hnot_le]

def ellComputeGSStmt : UL.BitRAMStmt :=
  let NE := UL.IntExpr.readHeap 10 (.lit 3)
  let violE := UL.IntExpr.readHeap 10 (.lit 18)
  let accE := UL.IntExpr.readHeap 10 (.lit 19)
  let iE := UL.IntExpr.readHeap 10 (.lit 42)
  let kE := UL.IntExpr.readHeap 10 (.lit 43)
  .seq
    (forLoopStmt 42 NE
      (.seq
        (sumLoopStmt 43 19 NE
          (.mul (.readHeap 24 (.add (.mul violE NE) kE))
                (.readHeap 27 (.add (.mul kE NE) iE))))
        (.writeHeap 26 (.add NE iE) accE)))
    (sumLoopStmt 42 20 NE
      (.mul (.readHeap 26 (.add NE iE)) (.readHeap 26 (.add NE iE))))

theorem exec_ellComputeGSStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {N m_ora L t maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hN : 2 ≤ N) (hL : 1 ≤ L) (ht : t < ellParamT N L)
    (hBK : 5 * ellParamBsqrt N L ≤ K)
    (hIdx : 4 * N ≤ maxIdx ∧ m_ora ≤ maxIdx)
    {M_pad : Fin m_ora → Fin N → ℤ} {rhs : Fin m_ora → ℤ}
    (hM : ∀ i j, (M_pad i j).natAbs ≤ 2 ^ L)
    {st : EllState N} (hMag : EllMagInv (ellParamE N L) t st)
    (i₀ : Fin m_ora)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hPar : EllParamsInHeap L M_pad rhs ws₀)
    (hSt : EllStateInHeap st ws₀)
    (hviol : hRead ws₀ 10 18 = (i₀.val : ℤ)) :
    let G : Fin N → ℤ := fun j => ∑ k : Fin N, M_pad i₀ k * st.A k j
    let S_norm : ℤ := ∑ j : Fin N, G j * G j
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (idx = 19 ∨ idx = 20 ∨ idx = 42 ∨ idx = 43)) ∨
      (t_id = 26 ∧ (N : ℤ) ≤ idx ∧ idx < ((2 * N : ℕ) : ℤ))
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ j : Fin N, hRead ws₁ 26 ((N + j.val : ℕ) : ℤ) = G j) ∧
      hRead ws₁ 10 20 = S_norm ∧
      ExecBit inp maxIdx K ellComputeGSStmt ws₀ ws₁
        ((6 + N * (7 + 2 * N)) * stepU) ((6 + N * (7 + 2 * N)) * stepB K) := by
  intro G S_norm mod
  obtain ⟨_, _, hMA_b, hG_sum, h9E_K, hS_sum, _, _, _⟩ := ell_step_mag_helpers hN hL ht hBK hM hMag
  have hG_abs : ∀ j : Fin N, (G j).natAbs ≤ 2 ^ (9 * ellParamE N L + 2 * t) := by
    intro j
    dsimp [G]
    rw [← prefixSum_eq_sum]
    exact (prefixSum_natAbs_le _ (fun k => hMA_b i₀ k j) N le_rfl).trans hG_sum
  let InvG : ℕ → UL.WordStore → Prop := fun p ws =>
    PreservesOutside mod ws₀ ws ∧
    (∀ j : Fin N, j.val < p → hRead ws 26 ((N + j.val : ℕ) : ℤ) = G j)
  have hInvG0 : InvG 0 (hWrite ws₀ 10 42 0) :=
    ⟨PreservesOutside.write ws₀ 0 (by dsimp [mod]; omega),
     fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
  have hcntG : evalVal inp (hWrite ws₀ 10 42 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hPar.1]
  obtain ⟨ws1, _, ⟨hpr1, hG_done⟩, hs1⟩ := exec_for hctx 42 (.readHeap 10 (.lit 3))
    (.seq
      (sumLoopStmt 43 19 (.readHeap 10 (.lit 3))
        (.mul (.readHeap 24 (.add (.mul (.readHeap 10 (.lit 18)) (.readHeap 10 (.lit 3)))
                (.readHeap 10 (.lit 43))))
              (.readHeap 27 (.add (.mul (.readHeap 10 (.lit 43)) (.readHeap 10 (.lit 3)))
                (.readHeap 10 (.lit 42))))))
      (.writeHeap 26 (.add (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 42))) (.readHeap 10 (.lit 19))))
    N (4 + 2 * N) InvG hws₀ (by omega) (by omega) hcntG hInvG0
    (fun j hj ws hws hctr_j ⟨hpr, hprev⟩ => by
      let jFin : Fin N := ⟨j, hj⟩
      obtain ⟨ws_s, hpr_s, hsum_s, hex_s⟩ := exec_sumLoopStmt hctx 43 19
        (by omega) h64 (by omega)
        (.readHeap 10 (.lit 3))
        (.mul (.readHeap 24 (.add (.mul (.readHeap 10 (.lit 18)) (.readHeap 10 (.lit 3)))
                (.readHeap 10 (.lit 43))))
              (.readHeap 27 (.add (.mul (.readHeap 10 (.lit 43)) (.readHeap 10 (.lit 3)))
                (.readHeap 10 (.lit 42)))))
        (by decide) (by decide) (by decide) (by decide)
        (fun k => M_pad i₀ k * st.A k jFin)
        (fun k => hMA_b i₀ k jFin) (hG_sum.trans h9E_K) hws
        (fun w hp => by
          simp only [evalVal_readHeap, evalVal_lit]
          rw [hp 10 3 (by omega), hpr 10 3 (by dsimp [mod]; omega), hPar.1])
        (fun k hk w hp hctr_k => by
          have hv_w : hRead w 10 18 = (i₀.val : ℤ) := by
            rw [hp 10 18 (by omega), hpr 10 18 (by dsimp [mod]; omega), hviol]
          have hN_w : hRead w 10 3 = (N : ℤ) := by
            rw [hp 10 3 (by omega), hpr 10 3 (by dsimp [mod]; omega), hPar.1]
          have hj_w : hRead w 10 42 = (j : ℤ) := by rw [hp 10 42 (by omega), hctr_j]
          have hik : (i₀.val : ℤ) * (N : ℤ) + (k : ℤ) = ((i₀.val * N + k : ℕ) : ℤ) := by push_cast; ring
          have hkj : (k : ℤ) * (N : ℤ) + (j : ℤ) = ((k * N + j : ℕ) : ℤ) := by push_cast; ring
          have hM_w : hRead w 24 ((i₀.val * N + k : ℕ) : ℤ) = M_pad i₀ ⟨k, hk⟩ := by
            rw [hp 24 _ (by omega), hpr 24 _ (by dsimp [mod]; omega)]
            exact hPar.2.2.2.2.2.2.2.2.2.2.2.1 i₀ ⟨k, hk⟩
          have hA_w : hRead w 27 ((k * N + j : ℕ) : ℤ) = st.A ⟨k, hk⟩ jFin := by
            rw [hp 27 _ (by omega), hpr 27 _ (by dsimp [mod]; omega)]
            exact hSt.2.2 ⟨k, hk⟩ jFin
          simp only [evalVal_mul, evalVal_readHeap, evalVal_add, evalVal_lit,
            hv_w, hN_w, hj_w, hctr_k, hik, hkj, hM_w, hA_w])
      have hN_s : hRead ws_s 10 3 = (N : ℤ) := by
        rw [hpr_s 10 3 (by omega), hpr 10 3 (by dsimp [mod]; omega), hPar.1]
      have hj_s : hRead ws_s 10 42 = (j : ℤ) := by rw [hpr_s 10 42 (by omega), hctr_j]
      have hidx_ev : evalVal inp ws_s (.add (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 42))) =
          ((N + j : ℕ) : ℤ) := by
        simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hN_s, hj_s]; push_cast; ring
      have hw_g := exec_write hctx hex_s.2.1 26
        (.add (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 42))) (.readHeap 10 (.lit 19))
        ((N + j : ℕ) : ℤ) (G jFin) hidx_ev
        (by simp only [evalVal_readHeap, evalVal_lit, hsum_s]; rfl)
        (Nat.cast_nonneg _) (Nat.cast_le.mpr (by omega))
        ((hG_abs jFin).trans h9E_K)
      let ws' := hWrite ws_s 26 ((N + j : ℕ) : ℤ) (G jFin)
      refine ⟨ws', (hex_s.seq_steps hw_g).mono_steps (by omega), ?_, ?_⟩
      · rw [hRead_hWrite_of_ne ws_s _ (Or.inl (by omega)), hj_s]
      · refine ⟨((hpr.trans (hpr_s.mono (by intro t_id idx h; dsimp [mod]; omega))).trans
            (PreservesOutside.write ws_s _
              (Or.inr ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right N j),
                Nat.cast_lt.mpr (by omega : N + j < 2 * N)⟩))).trans
            (PreservesOutside.write ws' _ (by dsimp [mod]; omega)), fun j' hj' => ?_⟩
        rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
        rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne ws_s _ (Or.inr (by omega)), hpr_s 26 _ (by omega)]
          exact hprev j' hlt
        · have hj_eq : j' = jFin := Fin.ext heq
          subst hj_eq
          exact hRead_hWrite_self ws_s 26 _ _)
  obtain ⟨ws2, hpr_sn, hS_ws2, hs2⟩ := exec_sumLoopStmt hctx 42 20
    (by omega) h64 (by omega)
    (.readHeap 10 (.lit 3))
    (.mul (.readHeap 26 (.add (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 42))))
          (.readHeap 26 (.add (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 42)))))
    (by decide) (by decide) (by decide) (by decide)
    (fun j => G j * G j)
    (fun j => by rw [Int.natAbs_mul]; exact Nat.mul_le_mul (hG_abs j) (hG_abs j))
    hS_sum hs1.2.1
    (fun w hp => by
      simp only [evalVal_readHeap, evalVal_lit]
      rw [hp 10 3 (by omega), hpr1 10 3 (by dsimp [mod]; omega), hPar.1])
    (fun j hj w hp hctr_j => by
      have hN_w : hRead w 10 3 = (N : ℤ) := by
        rw [hp 10 3 (by omega), hpr1 10 3 (by dsimp [mod]; omega), hPar.1]
      have hNj : (N : ℤ) + (j : ℤ) = ((N + j : ℕ) : ℤ) := by push_cast; ring
      have hG_w : hRead w 26 ((N + j : ℕ) : ℤ) = G ⟨j, hj⟩ := by
        rw [hp 26 _ (by omega)]; exact hG_done ⟨j, hj⟩ hj
      simp only [evalVal_mul, evalVal_readHeap, evalVal_add, evalVal_lit,
        hN_w, hctr_j, hNj, hG_w])
  have hpr_tot : PreservesOutside mod ws₀ ws2 :=
    hpr1.trans (hpr_sn.mono (by intro t_id idx h; dsimp [mod]; omega))
  have htot : ExecBit inp maxIdx K ellComputeGSStmt ws₀ ws2
      ((6 + N * (7 + 2 * N)) * stepU) ((6 + N * (7 + 2 * N)) * stepB K) := by
    refine (hs1.seq_steps hs2).mono_steps ?_
    calc (2 + N * (4 + 2 * N + 1)) + (3 + 2 * N)
        = 5 + N * (7 + 2 * N) := by ring
      _ ≤ 6 + N * (7 + 2 * N) := by omega
  exact ⟨ws2, hpr_tot, fun j => by rw [hpr_sn 26 _ (by omega)]; exact hG_done j j.isLt,
    hS_ws2, htot⟩

def ellUpdateMatrixAStmt : UL.BitRAMStmt :=
  let NE := UL.IntExpr.readHeap 10 (.lit 3)
  let KellE := UL.IntExpr.readHeap 10 (.lit 16)
  let LcE := UL.IntExpr.readHeap 10 (.lit 25)
  let denAE := UL.IntExpr.readHeap 10 (.lit 27)
  let tmp1E := UL.IntExpr.readHeap 10 (.lit 28)
  let tmp2E := UL.IntExpr.readHeap 10 (.lit 29)
  let iE := UL.IntExpr.readHeap 10 (.lit 42)
  let jE := UL.IntExpr.readHeap 10 (.lit 43)
  let ijE := UL.IntExpr.add (.mul iE NE) jE
  let nnE := UL.IntExpr.mul NE NE
  .seq
    (forLoopStmt 42 NE
      (forLoopStmt 43 NE
        (seqBitStmts
          [ .writeHeap 10 (.lit 28)
              (.mul (.mul (.sub (.mul (.mul (.lit 2) NE) NE) (.lit 1)) (.mul LcE LcE))
                    (.readHeap 27 ijE))
          , .writeHeap 10 (.lit 29)
              (.mul (.mul (.mul (.sub (.mul (.lit 2) NE) (.lit 1)) (.mul KellE KellE))
                    (.readHeap 26 (.add (.mul (.lit 2) NE) iE)))
                    (.readHeap 26 (.add NE jE)))
          , .writeHeap 27 (.add nnE ijE)
              (.div (.mul (.add (.mul (.mul (.lit 8) NE) NE) (.lit 1))
                          (.sub tmp1E tmp2E)) denAE) ])))
    (forLoopStmt 42 NE
      (forLoopStmt 43 NE
        (.writeHeap 27 ijE (.readHeap 27 (.add nnE ijE)))))

theorem exec_ellUpdateMatrixAStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {N maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : N ≤ maxIdx ∧ 2 * (N * N) ≤ maxIdx)
    (K_ell L_ceil denA : ℤ)
    (G H : Fin N → ℤ)
    (A_old A_new : Fin N → Fin N → ℤ)
    (hForm : ∀ i j : Fin N, A_new i j =
      ((8 * (N : ℤ) * (N : ℤ) + 1) *
        ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * A_old i j -
          (2 * (N : ℤ) - 1) * (K_ell * K_ell) * H i * G j)) / denA)
    (hTmp1B : ∀ i j : Fin N,
      ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * A_old i j).natAbs ≤ 2 ^ K)
    (hTmp2B : ∀ i j : Fin N,
      ((2 * (N : ℤ) - 1) * (K_ell * K_ell) * H i * G j).natAbs ≤ 2 ^ K)
    (hNewAB : ∀ i j : Fin N, (A_new i j).natAbs ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hN_ws : hRead ws₀ 10 3 = (N : ℤ))
    (hK_ws : hRead ws₀ 10 16 = K_ell)
    (hLc_ws : hRead ws₀ 10 25 = L_ceil)
    (hdA_ws : hRead ws₀ 10 27 = denA)
    (hG_ws : ∀ j : Fin N, hRead ws₀ 26 ((N + j.val : ℕ) : ℤ) = G j)
    (hH_ws : ∀ i : Fin N, hRead ws₀ 26 ((2 * N + i.val : ℕ) : ℤ) = H i)
    (hA_ws : ∀ i j : Fin N, hRead ws₀ 27 ((i.val * N + j.val : ℕ) : ℤ) = A_old i j) :
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (idx = 28 ∨ idx = 29 ∨ idx = 42 ∨ idx = 43)) ∨ t_id = 27
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ i j : Fin N, hRead ws₁ 27 ((i.val * N + j.val : ℕ) : ℤ) = A_new i j) ∧
      ExecBit inp maxIdx K ellUpdateMatrixAStmt ws₀ ws₁
        ((5 + N * (6 + 6 * N)) * stepU) ((5 + N * (6 + 6 * N)) * stepB K) := by
  intro mod
  let modA1 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 28 ∨ idx = 29 ∨ idx = 42 ∨ idx = 43)) ∨
    (t_id = 27 ∧ ((N * N : ℕ) : ℤ) ≤ idx ∧ idx < ((2 * (N * N) : ℕ) : ℤ))
  let InvA1 : ℕ → UL.WordStore → Prop := fun r ws =>
    PreservesOutside modA1 ws₀ ws ∧
    (∀ (i j : Fin N), i.val < r →
      hRead ws 27 ((N * N + (i.val * N + j.val) : ℕ) : ℤ) = A_new i j)
  have hInvA1_0 : InvA1 0 (hWrite ws₀ 10 42 0) :=
    ⟨PreservesOutside.write ws₀ 0 (by dsimp [modA1]; omega),
     fun _ _ h => False.elim (Nat.not_lt_zero _ h)⟩
  have hcntA1 : evalVal inp (hWrite ws₀ 10 42 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hN_ws]
  obtain ⟨ws7, _, ⟨hprA1, hA1_done⟩, hs7⟩ := exec_for hctx 42 (.readHeap 10 (.lit 3))
    (forLoopStmt 43 (.readHeap 10 (.lit 3))
      (seqBitStmts
        [ .writeHeap 10 (.lit 28)
            (.mul (.mul (.sub (.mul (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 3))) (.lit 1))
                        (.mul (.readHeap 10 (.lit 25)) (.readHeap 10 (.lit 25))))
                  (.readHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3)))
                    (.readHeap 10 (.lit 43)))))
        , .writeHeap 10 (.lit 29)
            (.mul (.mul (.mul (.sub (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.lit 1))
                          (.mul (.readHeap 10 (.lit 16)) (.readHeap 10 (.lit 16))))
                        (.readHeap 26 (.add (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 42)))))
                  (.readHeap 26 (.add (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 43)))))
        , .writeHeap 27
            (.add (.mul (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 3)))
                  (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))))
            (.div (.mul (.add (.mul (.mul (.lit 8) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 3))) (.lit 1))
                        (.sub (.readHeap 10 (.lit 28)) (.readHeap 10 (.lit 29))))
                  (.readHeap 10 (.lit 27))) ]))
    N (2 + 4 * N) InvA1 hws₀ (by omega) hIdx.1 hcntA1 hInvA1_0
    (fun i hi ws hws hctr_i ⟨hpr_i, hprev_i⟩ => by
      let iFin : Fin N := ⟨i, hi⟩
      let modIn : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ (idx = 28 ∨ idx = 29 ∨ idx = 43)) ∨
        (t_id = 27 ∧ ((N * N + i * N : ℕ) : ℤ) ≤ idx ∧ idx < ((N * N + (i + 1) * N : ℕ) : ℤ))
      let InvIn : ℕ → UL.WordStore → Prop := fun c wsi =>
        PreservesOutside modIn ws wsi ∧
        (∀ j : Fin N, j.val < c →
          hRead wsi 27 ((N * N + (i * N + j.val) : ℕ) : ℤ) = A_new iFin j)
      have hInvIn0 : InvIn 0 (hWrite ws 10 43 0) :=
        ⟨PreservesOutside.write ws 0 (by dsimp [modIn]; omega),
         fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
      have hcntIn : evalVal inp (hWrite ws 10 43 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne ws 0 (Or.inr (by omega)), hpr_i 10 3 (by dsimp [modA1]; omega), hN_ws]
      obtain ⟨ws_in, _, ⟨hprIn, hRow_done⟩, hex_in⟩ := exec_for hctx 43 (.readHeap 10 (.lit 3))
        (seqBitStmts [_, _, _])
        N 3 InvIn hws (by omega) hIdx.1 hcntIn hInvIn0
        (fun j hj wsi hwsi hctr_j ⟨hpr_j, hprev_j⟩ => by
          let jFin : Fin N := ⟨j, hj⟩
          have hij_lt_NN : i * N + j < N * N := row_col_lt_mul hi hj
          have hij_lt_next : i * N + j < (i + 1) * N := by
            calc i * N + j < i * N + N := Nat.add_lt_add_left hj _
              _ = (i + 1) * N := by ring
          have hNext_le_NN : (i + 1) * N ≤ N * N := Nat.mul_le_mul_right N hi
          have h_preserve_wsi : ∀ t_id idx, ¬ modIn t_id idx → ¬ modA1 t_id idx →
              hRead wsi t_id idx = hRead ws₀ t_id idx := by
            intro t_id idx h1 h2; rw [hpr_j t_id idx h1, hpr_i t_id idx h2]
          have hN_w : hRead wsi 10 3 = (N : ℤ) := by
            rw [h_preserve_wsi 10 3 (by dsimp [modIn]; omega) (by dsimp [modA1]; omega), hN_ws]
          have hK_w : hRead wsi 10 16 = K_ell := by
            rw [h_preserve_wsi 10 16 (by dsimp [modIn]; omega) (by dsimp [modA1]; omega), hK_ws]
          have hLc_w : hRead wsi 10 25 = L_ceil := by
            rw [h_preserve_wsi 10 25 (by dsimp [modIn]; omega) (by dsimp [modA1]; omega), hLc_ws]
          have hdA_w : hRead wsi 10 27 = denA := by
            rw [h_preserve_wsi 10 27 (by dsimp [modIn]; omega) (by dsimp [modA1]; omega), hdA_ws]
          have hi_w : hRead wsi 10 42 = (i : ℤ) := by
            rw [hpr_j 10 42 (by dsimp [modIn]; omega), hctr_i]
          have hij_eq : (i : ℤ) * (N : ℤ) + (j : ℤ) = ((i * N + j : ℕ) : ℤ) := by push_cast; ring
          have h2Ni : (2 : ℤ) * (N : ℤ) + (i : ℤ) = ((2 * N + i : ℕ) : ℤ) := by push_cast; ring
          have hNj : (N : ℤ) + (j : ℤ) = ((N + j : ℕ) : ℤ) := by push_cast; ring
          have hAij_w : hRead wsi 27 ((i * N + j : ℕ) : ℤ) = A_old iFin jFin := by
            rw [h_preserve_wsi 27 _ (by dsimp [modIn]; omega) (by dsimp [modA1]; omega)]
            exact hA_ws iFin jFin
          have hHi_w : hRead wsi 26 ((2 * N + i : ℕ) : ℤ) = H iFin := by
            rw [h_preserve_wsi 26 _ (by dsimp [modIn]; omega) (by dsimp [modA1]; omega)]
            exact hH_ws iFin
          have hGj_w : hRead wsi 26 ((N + j : ℕ) : ℤ) = G jFin := by
            rw [h_preserve_wsi 26 _ (by dsimp [modIn]; omega) (by dsimp [modA1]; omega)]
            exact hG_ws jFin
          let vTmp1 := (2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * A_old iFin jFin
          let vTmp2 := (2 * (N : ℤ) - 1) * (K_ell * K_ell) * H iFin * G jFin
          have hw1 := exec_write hctx hwsi 10 (.lit 28)
            (.mul (.mul (.sub (.mul (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 3))) (.lit 1))
                        (.mul (.readHeap 10 (.lit 25)) (.readHeap 10 (.lit 25))))
                  (.readHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3)))
                    (.readHeap 10 (.lit 43)))))
            28 vTmp1 rfl
            (by simp only [evalVal_mul, evalVal_sub, evalVal_add, evalVal_readHeap, evalVal_lit,
                  hN_w, hLc_w, hi_w, hctr_j, hij_eq, hAij_w]; rfl)
            (by omega) (by omega) (hTmp1B iFin jFin)
          let wsa := hWrite wsi 10 28 vTmp1
          have hw2 := exec_write hctx hw1.2.1 10 (.lit 29)
            (.mul (.mul (.mul (.sub (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.lit 1))
                          (.mul (.readHeap 10 (.lit 16)) (.readHeap 10 (.lit 16))))
                        (.readHeap 26 (.add (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 42)))))
                  (.readHeap 26 (.add (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 43)))))
            29 vTmp2 rfl
            (by
              have hN_a : hRead wsa 10 3 = (N : ℤ) := by rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hN_w]
              have hK_a : hRead wsa 10 16 = K_ell := by rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hK_w]
              have hi_a : hRead wsa 10 42 = (i : ℤ) := by rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hi_w]
              have hj_a : hRead wsa 10 43 = (j : ℤ) := by rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hctr_j]
              have hH_a : hRead wsa 26 ((2 * N + i : ℕ) : ℤ) = H iFin := by
                rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hHi_w]
              have hG_a : hRead wsa 26 ((N + j : ℕ) : ℤ) = G jFin := by
                rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hGj_w]
              dsimp only [wsa] at hN_a hK_a hi_a hj_a hH_a hG_a
              simp only [evalVal_mul, evalVal_sub, evalVal_add, evalVal_readHeap, evalVal_lit,
                hN_a, hK_a, hi_a, hj_a, h2Ni, hNj, hH_a, hG_a]; rfl)
            (by omega) (by omega) (hTmp2B iFin jFin)
          let wsb := hWrite wsa 10 29 vTmp2
          have hdst_ev : evalVal inp wsb
              (.add (.mul (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 3)))
                    (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))) =
              ((N * N + (i * N + j) : ℕ) : ℤ) := by
            have hN_b : hRead wsb 10 3 = (N : ℤ) := by
              rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hN_w]
            have hi_b : hRead wsb 10 42 = (i : ℤ) := by
              rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hi_w]
            have hj_b : hRead wsb 10 43 = (j : ℤ) := by
              rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hctr_j]
            simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hN_b, hi_b, hj_b]
            push_cast; ring
          have hval3_ev : evalVal inp wsb
              (.div (.mul (.add (.mul (.mul (.lit 8) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 3))) (.lit 1))
                          (.sub (.readHeap 10 (.lit 28)) (.readHeap 10 (.lit 29))))
                    (.readHeap 10 (.lit 27))) = A_new iFin jFin := by
            have hN_b : hRead wsb 10 3 = (N : ℤ) := by
              rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hN_w]
            have hdA_b : hRead wsb 10 27 = denA := by
              rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hdA_w]
            have h28_b : hRead wsb 10 28 = vTmp1 := by
              rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)), hRead_hWrite_self]
            have h29_b : hRead wsb 10 29 = vTmp2 := hRead_hWrite_self wsa 10 29 vTmp2
            simp only [evalVal_div, evalVal_mul, evalVal_add, evalVal_sub, evalVal_readHeap, evalVal_lit,
              hN_b, hdA_b, h28_b, h29_b, hForm iFin jFin, vTmp1, vTmp2]
          have hw3 := exec_write hctx hw2.2.1 27
            (.add (.mul (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 3)))
                  (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))))
            (.div (.mul (.add (.mul (.mul (.lit 8) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 3))) (.lit 1))
                        (.sub (.readHeap 10 (.lit 28)) (.readHeap 10 (.lit 29))))
                  (.readHeap 10 (.lit 27)))
            ((N * N + (i * N + j) : ℕ) : ℤ) (A_new iFin jFin)
            (by dsimp only [wsb, wsa] at hdst_ev; exact hdst_ev)
            (by dsimp only [wsb, wsa] at hval3_ev; exact hval3_ev)
            (Nat.cast_nonneg _)
            (Nat.cast_le.mpr (by omega : N * N + (i * N + j) ≤ maxIdx))
            (hNewAB iFin jFin)
          let wsc := hWrite wsb 27 ((N * N + (i * N + j) : ℕ) : ℤ) (A_new iFin jFin)
          refine ⟨wsc, (hw1.seq_steps (hw2.seq_steps hw3)).mono_steps (by omega), ?_, ?_⟩
          · rw [hRead_hWrite_of_ne wsb _ (Or.inl (by omega)),
                hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                hRead_hWrite_of_ne wsi _ (Or.inr (by omega)), hctr_j]
          · refine ⟨(((hpr_j.trans (PreservesOutside.write wsi _ (by dsimp [modIn]; omega))).trans
                (PreservesOutside.write wsa _ (by dsimp [modIn]; omega))).trans
                (PreservesOutside.write wsb _
                  (Or.inr ⟨rfl, Nat.cast_le.mpr (by omega),
                    Nat.cast_lt.mpr (Nat.add_lt_add_left hij_lt_next (N * N))⟩))).trans
                (PreservesOutside.write wsc _ (by dsimp [modIn]; omega)),
              fun j' hj' => ?_⟩
            rw [hRead_hWrite_of_ne wsc _ (Or.inl (by omega))]
            rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
            · rw [hRead_hWrite_of_ne wsb _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsa _ (Or.inl (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inl (by omega))]
              exact hprev_j j' hlt
            · have hj_eq : j' = jFin := Fin.ext heq
              subst hj_eq; exact hRead_hWrite_self wsb 27 _ _)
      have hNext_le_NN : (i + 1) * N ≤ N * N := Nat.mul_le_mul_right N hi
      refine ⟨ws_in, hex_in.mono_steps (by ring_nf; omega), ?_, ?_⟩
      · rw [hprIn 10 42 (by dsimp [modIn]; omega), hctr_i]
      · refine ⟨(hpr_i.trans (hprIn.mono (by
            intro t_id idx h; dsimp [modIn] at h; dsimp [modA1]
            rcases h with ⟨rfl, h1⟩ | ⟨rfl, hlo, hhi⟩
            · exact Or.inl ⟨rfl, by omega⟩
            · have h2NN : N * N + (i + 1) * N ≤ 2 * (N * N) := by
                calc N * N + (i + 1) * N ≤ N * N + N * N := Nat.add_le_add_left hNext_le_NN _
                  _ = 2 * (N * N) := (two_mul (N * N)).symm
              exact Or.inr ⟨rfl, le_trans (Nat.cast_le.mpr (Nat.le_add_right _ _)) hlo,
                lt_of_lt_of_le hhi (Nat.cast_le.mpr h2NN)⟩))).trans
          (PreservesOutside.write ws_in _ (by dsimp [modA1]; omega)),
          fun i' j' hi' => ?_⟩
        rw [hRead_hWrite_of_ne ws_in _ (Or.inl (by omega))]
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · have hlt_i : i'.val * N + j'.val < i * N := by
            calc i'.val * N + j'.val < i'.val * N + N := Nat.add_lt_add_left j'.isLt _
              _ = (i'.val + 1) * N := by ring
              _ ≤ i * N := Nat.mul_le_mul_right N hlt
          rw [hprIn 27 _ (by dsimp [modIn]; omega)]
          exact hprev_i i' j' hlt
        · have hi_eq : i' = iFin := Fin.ext heq
          subst hi_eq; exact hRow_done j' j'.isLt)
  let modA2 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 42 ∨ idx = 43)) ∨
    (t_id = 27 ∧ 0 ≤ idx ∧ idx < ((N * N : ℕ) : ℤ))
  let InvA2 : ℕ → UL.WordStore → Prop := fun r ws =>
    PreservesOutside modA2 ws7 ws ∧
    (∀ (i j : Fin N), i.val < r → hRead ws 27 ((i.val * N + j.val : ℕ) : ℤ) = A_new i j)
  have hInvA2_0 : InvA2 0 (hWrite ws7 10 42 0) :=
    ⟨PreservesOutside.write ws7 0 (by dsimp [modA2]; omega),
     fun _ _ h => False.elim (Nat.not_lt_zero _ h)⟩
  have hcntA2 : evalVal inp (hWrite ws7 10 42 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws7 0 (Or.inr (by omega)), hprA1 10 3 (by dsimp [modA1]; omega), hN_ws]
  obtain ⟨ws8, _, ⟨hprA2, hA2_done⟩, hs8⟩ := exec_for hctx 42 (.readHeap 10 (.lit 3))
    (forLoopStmt 43 (.readHeap 10 (.lit 3))
      (.writeHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
        (.readHeap 27 (.add (.mul (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 3)))
          (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))))))
    N (2 + 2 * N) InvA2 hs7.2.1 (by omega) hIdx.1 hcntA2 hInvA2_0
    (fun i hi ws hws hctr_i ⟨hpr_i, hprev_i⟩ => by
      let iFin : Fin N := ⟨i, hi⟩
      let modIn2 : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 43) ∨
        (t_id = 27 ∧ ((i * N : ℕ) : ℤ) ≤ idx ∧ idx < (((i + 1) * N : ℕ) : ℤ))
      let InvIn2 : ℕ → UL.WordStore → Prop := fun c wsi =>
        PreservesOutside modIn2 ws wsi ∧
        (∀ j : Fin N, j.val < c → hRead wsi 27 ((i * N + j.val : ℕ) : ℤ) = A_new iFin j)
      have hInvIn2_0 : InvIn2 0 (hWrite ws 10 43 0) :=
        ⟨PreservesOutside.write ws 0 (by dsimp [modIn2]; omega),
         fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
      have hcntIn2 : evalVal inp (hWrite ws 10 43 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne ws 0 (Or.inr (by omega)),
            hpr_i 10 3 (by dsimp [modA2]; omega), hprA1 10 3 (by dsimp [modA1]; omega), hN_ws]
      obtain ⟨ws_in, _, ⟨hprIn2, hRow2_done⟩, hex_in2⟩ := exec_for hctx 43 (.readHeap 10 (.lit 3))
        (.writeHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
          (.readHeap 27 (.add (.mul (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 3)))
            (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))))))
        N 1 InvIn2 hws (by omega) hIdx.1 hcntIn2 hInvIn2_0
        (fun j hj wsi hwsi hctr_j ⟨hpr_j, hprev_j⟩ => by
          let jFin : Fin N := ⟨j, hj⟩
          have hij_lt_next : i * N + j < (i + 1) * N := by
            calc i * N + j < i * N + N := Nat.add_lt_add_left hj _
              _ = (i + 1) * N := by ring
          have hNext_le_NN : (i + 1) * N ≤ N * N := Nat.mul_le_mul_right N hi
          have hN_w : hRead wsi 10 3 = (N : ℤ) := by
            rw [hpr_j 10 3 (by dsimp [modIn2]; omega), hpr_i 10 3 (by dsimp [modA2]; omega),
                hprA1 10 3 (by dsimp [modA1]; omega), hN_ws]
          have hi_w : hRead wsi 10 42 = (i : ℤ) := by
            rw [hpr_j 10 42 (by dsimp [modIn2]; omega), hctr_i]
          have hij_eq : (i : ℤ) * (N : ℤ) + (j : ℤ) = ((i * N + j : ℕ) : ℤ) := by push_cast; ring
          have hsrc_eq : (N : ℤ) * (N : ℤ) + ((i * N + j : ℕ) : ℤ) =
              ((N * N + (i * N + j) : ℕ) : ℤ) := by push_cast; ring
          have hA_src : hRead wsi 27 ((N * N + (i * N + j) : ℕ) : ℤ) = A_new iFin jFin := by
            have hge_src : (((i + 1) * N : ℕ) : ℤ) ≤ ((N * N + (i * N + j) : ℕ) : ℤ) :=
              Nat.cast_le.mpr (hNext_le_NN.trans (Nat.le_add_right _ _))
            have hge_nn : ((N * N : ℕ) : ℤ) ≤ ((N * N + (i * N + j) : ℕ) : ℤ) :=
              Nat.cast_le.mpr (Nat.le_add_right _ _)
            rw [hpr_j 27 _ (fun h => by
                  rcases h with ⟨h, _⟩ | ⟨_, _, hlt⟩
                  · exact absurd h (by decide)
                  · exact absurd hlt (not_lt.mpr hge_src)),
                hpr_i 27 _ (fun h => by
                  rcases h with ⟨h, _⟩ | ⟨_, _, hlt⟩
                  · exact absurd h (by decide)
                  · exact absurd hlt (not_lt.mpr hge_nn))]
            exact hA1_done iFin jFin hi
          have hw_cp := exec_write hctx hwsi 27
            (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
            (.readHeap 27 (.add (.mul (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 3)))
              (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))))
            ((i * N + j : ℕ) : ℤ) (A_new iFin jFin)
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_w, hN_w, hctr_j, hij_eq])
            (by simp only [evalVal_readHeap, evalVal_add, evalVal_mul, evalVal_lit,
                  hi_w, hN_w, hctr_j, hij_eq, hsrc_eq, hA_src])
            (Nat.cast_nonneg _)
            (Nat.cast_le.mpr (by omega : i * N + j ≤ maxIdx))
            (hNewAB iFin jFin)
          let wsi' := hWrite wsi 27 ((i * N + j : ℕ) : ℤ) (A_new iFin jFin)
          refine ⟨wsi', hw_cp, ?_, ?_⟩
          · rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hctr_j]
          · refine ⟨(hpr_j.trans (PreservesOutside.write wsi _
                (Or.inr ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right _ _),
                  Nat.cast_lt.mpr hij_lt_next⟩))).trans
              (PreservesOutside.write wsi' _ (by dsimp [modIn2]; omega)), fun j' hj' => ?_⟩
            rw [hRead_hWrite_of_ne wsi' _ (Or.inl (by omega))]
            rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
            · rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]; exact hprev_j j' hlt
            · have hj_eq : j' = jFin := Fin.ext heq
              subst hj_eq; exact hRead_hWrite_self wsi 27 _ _)
      have hNext_le_NN : (i + 1) * N ≤ N * N := Nat.mul_le_mul_right N hi
      refine ⟨ws_in, hex_in2.mono_steps (by ring_nf; omega), ?_, ?_⟩
      · rw [hprIn2 10 42 (by dsimp [modIn2]; omega), hctr_i]
      · refine ⟨(hpr_i.trans (hprIn2.mono (by
            intro t_id idx h; dsimp [modIn2] at h; dsimp [modA2]
            rcases h with ⟨rfl, h1⟩ | ⟨rfl, hlo, hhi⟩
            · exact Or.inl ⟨rfl, Or.inr h1⟩
            · exact Or.inr ⟨rfl, le_trans (Nat.cast_nonneg _) hlo,
                lt_of_lt_of_le hhi (Nat.cast_le.mpr hNext_le_NN)⟩))).trans
          (PreservesOutside.write ws_in _ (by dsimp [modA2]; omega)),
          fun i' j' hi' => ?_⟩
        rw [hRead_hWrite_of_ne ws_in _ (Or.inl (by omega))]
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · have hlt_i : i'.val * N + j'.val < i * N := by
            calc i'.val * N + j'.val < i'.val * N + N := Nat.add_lt_add_left j'.isLt _
              _ = (i'.val + 1) * N := by ring
              _ ≤ i * N := Nat.mul_le_mul_right N hlt
          rw [hprIn2 27 _ (by dsimp [modIn2]; omega)]
          exact hprev_i i' j' hlt
        · have hi_eq : i' = iFin := Fin.ext heq
          subst hi_eq; exact hRow2_done j' j'.isLt)
  have hpr_tot : PreservesOutside mod ws₀ ws8 :=
    (hprA1.mono (by intro t_id idx h; dsimp [modA1] at h; dsimp [mod]; omega)).trans
      (hprA2.mono (by intro t_id idx h; dsimp [modA2] at h; dsimp [mod]; omega))
  have htot := (hs7.seq_steps hs8).mono_steps
    (show (2 + N * (2 + 4 * N + 1)) + (2 + N * (2 + 2 * N + 1)) ≤ 5 + N * (6 + 6 * N) by ring_nf; omega)
  exact ⟨ws8, hpr_tot, fun i j => hA2_done i j i.isLt, htot⟩

def ellUpdateStateStmt : UL.BitRAMStmt :=
  let NE := UL.IntExpr.readHeap 10 (.lit 3)
  let KellE := UL.IntExpr.readHeap 10 (.lit 16)
  let accE := UL.IntExpr.readHeap 10 (.lit 19)
  let SnormE := UL.IntExpr.readHeap 10 (.lit 20)
  let LcE := UL.IntExpr.readHeap 10 (.lit 25)
  let denCE := UL.IntExpr.readHeap 10 (.lit 26)
  let iE := UL.IntExpr.readHeap 10 (.lit 42)
  let jE := UL.IntExpr.readHeap 10 (.lit 43)
  seqBitStmts
    [ .writeHeap 10 (.lit 21) (.mul (.mul KellE KellE) SnormE)
    , isqrtCeilStmt
    , forLoopStmt 42 NE
        (.seq
          (sumLoopStmt 43 19 NE
            (.mul (.readHeap 27 (.add (.mul iE NE) jE))
                  (.readHeap 26 (.add NE jE))))
          (.writeHeap 26 (.add (.mul (.lit 2) NE) iE) accE))
    , .writeHeap 10 (.lit 26) (.mul (.add NE (.lit 1)) LcE)
    , .writeHeap 10 (.lit 27)
        (.mul (.mul (.mul (.mul (.mul (.lit 8) NE) NE)
                    (.sub (.mul (.mul (.lit 2) NE) NE) (.lit 2))) LcE) LcE)
    , forLoopStmt 42 NE
        (.writeHeap 26 iE
          (.sub (.readHeap 26 iE)
            (.div (.mul KellE (.readHeap 26 (.add (.mul (.lit 2) NE) iE))) denCE)))
    , ellUpdateMatrixAStmt ]

theorem exec_ellUpdateStateStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {N m_ora L t maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hN : 2 ≤ N) (hL : 1 ≤ L) (ht : t < ellParamT N L)
    (hBK : 5 * ellParamBsqrt N L ≤ K)
    (hIdx : 4 * N ≤ maxIdx ∧ 2 * (N * N) ≤ maxIdx)
    {M_pad : Fin m_ora → Fin N → ℤ} {rhs : Fin m_ora → ℤ}
    (hM : ∀ i j, (M_pad i j).natAbs ≤ 2 ^ L)
    {st : EllState N} (hMag : EllMagInv (ellParamE N L) t st)
    (hst0 : st.status = 0)
    (i₀ : Fin m_ora)
    (hviol_eq : findViolatedRow ((2 : ℤ) ^ (6 * ellParamE N L)) ((2 : ℤ) ^ (ellParamE N L + 1))
      M_pad rhs st.C = (i₀.val : ℤ))
    (hS_pos : 0 < ∑ j : Fin N, (∑ k : Fin N, M_pad i₀ k * st.A k j) *
                                (∑ k : Fin N, M_pad i₀ k * st.A k j))
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hPar : EllParamsInHeap L M_pad rhs ws₀)
    (hSt : EllStateInHeap st ws₀)
    (hG_ws : ∀ j : Fin N, hRead ws₀ 26 ((N + j.val : ℕ) : ℤ) = ∑ k : Fin N, M_pad i₀ k * st.A k j)
    (hS_ws : hRead ws₀ 10 20 = ∑ j : Fin N, (∑ k : Fin N, M_pad i₀ k * st.A k j) *
                                             (∑ k : Fin N, M_pad i₀ k * st.A k j)) :
    let B_sqrt := ellParamBsqrt N L
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ ((19 ≤ idx ∧ idx ≤ 29) ∨ idx = 42 ∨ idx = 43)) ∨
      t_id = 26 ∨ t_id = 27
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      EllStateInHeap (ellStep L M_pad rhs st) ws₁ ∧
      ExecBit inp maxIdx K ellUpdateStateStmt ws₀ ws₁
        ((24 + 4 * B_sqrt + N * (16 + 8 * N)) * stepU)
        ((24 + 4 * B_sqrt + N * (16 + 8 * N)) * stepB K) := by
  intro B_sqrt mod
  let E := ellParamE N L
  let K_ell : ℤ := 16 * (N : ℤ) * (N : ℤ)
  let G : Fin N → ℤ := fun j => ∑ k : Fin N, M_pad i₀ k * st.A k j
  let S_norm : ℤ := ∑ j : Fin N, G j * G j
  have hStepEq0 := ellStep_active_eq (L := L) hst0 i₀ hviol_eq hS_pos
  dsimp only at hStepEq0
  have hMagNext0 : EllMagInv E (t + 1) (ellStep L M_pad rhs st) :=
    ellMagInv_step hN hL ht M_pad rhs hM hMag
  generalize hLc_def : isqrtCeil B_sqrt (K_ell * K_ell * S_norm) = L_ceil at hStepEq0
  generalize hstNext_def : ellStep L M_pad rhs st = stNext at hStepEq0 hMagNext0 ⊢
  let H : Fin N → ℤ := fun i => ∑ k : Fin N, st.A i k * G k
  let denC : ℤ := ((N : ℤ) + 1) * L_ceil
  let denA : ℤ := 8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) * L_ceil * L_ceil
  have hStepEq : stNext =
      { status := 0
        C := fun i => st.C i - (K_ell * H i) / denC
        A := fun i j =>
          ((8 * (N : ℤ) * (N : ℤ) + 1) *
            ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * st.A i j -
              (2 * (N : ℤ) - 1) * (K_ell * K_ell) * H i * G j)) / denA } := hStepEq0
  have hMagNext : EllMagInv E (t + 1) stNext := hMagNext0
  obtain ⟨hNextC_abs, hNextA_abs⟩ := ellMagInv_state_abs_le hN hL ht hBK hMagNext
  obtain ⟨_, _, _, _, _, _, hBK1, h2BK, _, _, _, _⟩ := ell_basic_exp_bounds hN hL hBK
  obtain ⟨_, _, hMA_b, hG_sum, h9E_K, _, hAG_b, hH_sum, h18E_K⟩ :=
    ell_step_mag_helpers hN hL ht hBK hM hMag
  have hG_abs : ∀ j : Fin N, (G j).natAbs ≤ 2 ^ (9 * E + 2 * t) := by
    intro j; dsimp [G]; rw [← prefixSum_eq_sum]
    exact (prefixSum_natAbs_le _ (fun k => hMA_b i₀ k j) N le_rfl).trans hG_sum
  have hK_pos : 0 < K_ell := by
    dsimp [K_ell]; have hNZ : (2 : ℤ) ≤ (N : ℤ) := by omega
    nlinarith only [hNZ]
  have hX_lo : 1 ≤ K_ell * K_ell * S_norm := by
    change 0 < S_norm at hS_pos; nlinarith
  have hX_hi : K_ell * K_ell * S_norm ≤ ((2 : ℤ) ^ B_sqrt) ^ 2 :=
    ellStep_isqrt_range hN hL ht.le M_pad hM hMag i₀
  have hX_abs : (K_ell * K_ell * S_norm).natAbs ≤ 2 ^ K := by
    have h0 : 0 ≤ K_ell * K_ell * S_norm := by omega
    have hleZ : ((K_ell * K_ell * S_norm).natAbs : ℤ) ≤ ((2 ^ (2 * B_sqrt) : ℕ) : ℤ) := by
      rw [Int.natAbs_of_nonneg h0]
      calc K_ell * K_ell * S_norm ≤ ((2 : ℤ) ^ B_sqrt) ^ 2 := hX_hi
        _ = (2 : ℤ) ^ (2 * B_sqrt) := by rw [← pow_mul]; ring_nf
        _ = ((2 ^ (2 * B_sqrt) : ℕ) : ℤ) := by push_cast; rfl
    exact (Nat.cast_le.mp hleZ).trans (Nat.pow_le_pow_right (by omega) h2BK)
  have hs1 := exec_write hctx hws₀ 10 (.lit 21)
    (.mul (.mul (.readHeap 10 (.lit 16)) (.readHeap 10 (.lit 16))) (.readHeap 10 (.lit 20)))
    21 (K_ell * K_ell * S_norm) rfl
    (by simp only [evalVal_mul, evalVal_readHeap, evalVal_lit,
          hPar.2.2.2.2.2.2.2.2.2.2.1, hS_ws]; rfl)
    (by omega) (by omega) hX_abs
  let ws1 := hWrite ws₀ 10 21 (K_ell * K_ell * S_norm)
  have hpr1 : PreservesOutside mod ws₀ ws1 :=
    PreservesOutside.write ws₀ _ (by dsimp [mod]; omega)
  have hSpecSq := isqrtCeil_spec B_sqrt (K_ell * K_ell * S_norm) hX_lo hX_hi
  dsimp only at hSpecSq
  rw [hLc_def] at hSpecSq
  obtain ⟨hLc_lo, hLc_hi, _, _⟩ := hSpecSq
  obtain ⟨ws2, hpr_sq, hLc_ws2_raw, hs2⟩ := exec_isqrtCeilStmt hctx h64 hBK1 hs1.2.1
    (by rw [hpr1 10 11 (by dsimp [mod]; omega)]; exact hPar.2.2.2.2.2.1)
    (by rw [hpr1 10 15 (by dsimp [mod]; omega)]; exact hPar.2.2.2.2.2.2.2.2.2.1)
    (hRead_hWrite_self ws₀ 10 21 _)
  have hLc_ws2 : hRead ws2 10 25 = L_ceil := by rwa [hLc_def] at hLc_ws2_raw
  have hpr2 : PreservesOutside mod ws₀ ws2 :=
    hpr1.trans (hpr_sq.mono (by intro t_id idx h; dsimp [mod]; omega))
  have hH_abs : ∀ i : Fin N, (H i).natAbs ≤ 2 ^ (18 * E + 4 * t) := by
    intro i; dsimp [H]; rw [← prefixSum_eq_sum]
    exact (prefixSum_natAbs_le _ (fun k => hAG_b i k (G k) (hG_abs k)) N le_rfl).trans hH_sum
  let modH : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 19 ∨ idx = 42 ∨ idx = 43)) ∨
    (t_id = 26 ∧ ((2 * N : ℕ) : ℤ) ≤ idx ∧ idx < ((3 * N : ℕ) : ℤ))
  let InvH : ℕ → UL.WordStore → Prop := fun p ws =>
    PreservesOutside modH ws2 ws ∧
    (∀ i : Fin N, i.val < p → hRead ws 26 ((2 * N + i.val : ℕ) : ℤ) = H i)
  have hInvH0 : InvH 0 (hWrite ws2 10 42 0) :=
    ⟨PreservesOutside.write ws2 0 (by dsimp [modH]; omega),
     fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
  have hcntH : evalVal inp (hWrite ws2 10 42 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws2 0 (Or.inr (by omega)), hpr2 10 3 (by dsimp [mod]; omega), hPar.1]
  obtain ⟨ws3, _, ⟨hprH, hH_done⟩, hs3⟩ := exec_for hctx 42 (.readHeap 10 (.lit 3))
    (.seq
      (sumLoopStmt 43 19 (.readHeap 10 (.lit 3))
        (.mul (.readHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3)))
                (.readHeap 10 (.lit 43))))
              (.readHeap 26 (.add (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 43))))))
      (.writeHeap 26 (.add (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 42)))
        (.readHeap 10 (.lit 19))))
    N (4 + 2 * N) InvH hs2.2.1 (by omega) (by omega) hcntH hInvH0
    (fun i hi ws hws hctr_i ⟨hpr_h, hprev_h⟩ => by
      let iFin : Fin N := ⟨i, hi⟩
      obtain ⟨ws_s, hpr_s, hsum_s, hex_s⟩ := exec_sumLoopStmt hctx 43 19
        (by omega) h64 (by omega)
        (.readHeap 10 (.lit 3))
        (.mul (.readHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3)))
                (.readHeap 10 (.lit 43))))
              (.readHeap 26 (.add (.readHeap 10 (.lit 3)) (.readHeap 10 (.lit 43)))))
        (by decide) (by decide) (by decide) (by decide)
        (fun k => st.A iFin k * G k)
        (fun k => hAG_b iFin k (G k) (hG_abs k)) (hH_sum.trans h18E_K) hws
        (fun w hp => by
          simp only [evalVal_readHeap, evalVal_lit]
          rw [hp 10 3 (by omega), hpr_h 10 3 (by dsimp [modH]; omega),
              hpr2 10 3 (by dsimp [mod]; omega), hPar.1])
        (fun k hk w hp hctr_k => by
          have hi_w : hRead w 10 42 = (i : ℤ) := by rw [hp 10 42 (by omega), hctr_i]
          have hN_w : hRead w 10 3 = (N : ℤ) := by
            rw [hp 10 3 (by omega), hpr_h 10 3 (by dsimp [modH]; omega),
                hpr2 10 3 (by dsimp [mod]; omega), hPar.1]
          have hik : (i : ℤ) * (N : ℤ) + (k : ℤ) = ((i * N + k : ℕ) : ℤ) := by push_cast; ring
          have hNk : (N : ℤ) + (k : ℤ) = ((N + k : ℕ) : ℤ) := by push_cast; ring
          have hA_w : hRead w 27 ((i * N + k : ℕ) : ℤ) = st.A iFin ⟨k, hk⟩ := by
            rw [hp 27 _ (by omega), hpr_h 27 _ (by dsimp [modH]; omega),
                hpr_sq 27 _ (by omega), hRead_hWrite_of_ne ws₀ _ (Or.inl (by omega))]
            exact hSt.2.2 iFin ⟨k, hk⟩
          have hG_w : hRead w 26 ((N + k : ℕ) : ℤ) = G ⟨k, hk⟩ := by
            rw [hp 26 _ (by omega), hpr_h 26 _ (by dsimp [modH]; omega),
                hpr_sq 26 _ (by omega), hRead_hWrite_of_ne ws₀ _ (Or.inl (by omega))]
            exact hG_ws ⟨k, hk⟩
          simp only [evalVal_mul, evalVal_readHeap, evalVal_add, evalVal_lit,
            hi_w, hN_w, hctr_k, hik, hNk, hA_w, hG_w])
      have hN_s : hRead ws_s 10 3 = (N : ℤ) := by
        rw [hpr_s 10 3 (by omega), hpr_h 10 3 (by dsimp [modH]; omega),
            hpr2 10 3 (by dsimp [mod]; omega), hPar.1]
      have hi_s : hRead ws_s 10 42 = (i : ℤ) := by rw [hpr_s 10 42 (by omega), hctr_i]
      have hidx_ev : evalVal inp ws_s (.add (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 42))) =
          ((2 * N + i : ℕ) : ℤ) := by
        simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hN_s, hi_s]; push_cast; ring
      have hw_h := exec_write hctx hex_s.2.1 26
        (.add (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 42)))
        (.readHeap 10 (.lit 19))
        ((2 * N + i : ℕ) : ℤ) (H iFin) hidx_ev
        (by simp only [evalVal_readHeap, evalVal_lit, hsum_s]; rfl)
        (Nat.cast_nonneg _) (Nat.cast_le.mpr (by omega))
        ((hH_abs iFin).trans h18E_K)
      let ws' := hWrite ws_s 26 ((2 * N + i : ℕ) : ℤ) (H iFin)
      refine ⟨ws', (hex_s.seq_steps hw_h).mono_steps (by omega), ?_, ?_⟩
      · rw [hRead_hWrite_of_ne ws_s _ (Or.inl (by omega)), hi_s]
      · refine ⟨((hpr_h.trans (hpr_s.mono (by intro t_id idx h; dsimp [modH]; omega))).trans
            (PreservesOutside.write ws_s _
              (Or.inr ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right (2 * N) i),
                Nat.cast_lt.mpr (by omega : 2 * N + i < 3 * N)⟩))).trans
            (PreservesOutside.write ws' _ (by dsimp [modH]; omega)), fun i' hi' => ?_⟩
        rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne ws_s _ (Or.inr (by omega)), hpr_s 26 _ (by omega)]
          exact hprev_h i' hlt
        · have hi_eq : i' = iFin := Fin.ext heq
          subst hi_eq
          exact hRead_hWrite_self ws_s 26 _ _)
  have hpr3 : PreservesOutside mod ws₀ ws3 :=
    hpr2.trans (hprH.mono (by intro t_id idx h; dsimp [modH] at h; dsimp [mod]; omega))
  have hScal0 := ell_update_scalars_bound hN hL ht hBK hLc_lo hLc_hi
    (aij := 0) (hi := 0) (gj := 0) (by simp) (by simp) (by simp)
  have hN_ws3 : hRead ws3 10 3 = (N : ℤ) := by rw [hpr3 10 3 (by dsimp [mod]; omega), hPar.1]
  have hLc_ws3 : hRead ws3 10 25 = L_ceil := by rw [hprH 10 25 (by dsimp [modH]; omega), hLc_ws2]
  have hs4 := exec_write hctx hs3.2.1 10 (.lit 26)
    (.mul (.add (.readHeap 10 (.lit 3)) (.lit 1)) (.readHeap 10 (.lit 25)))
    26 denC rfl
    (by simp only [evalVal_mul, evalVal_add, evalVal_readHeap, evalVal_lit, hN_ws3, hLc_ws3]; rfl)
    (by omega) (by omega) hScal0.1
  let ws4 := hWrite ws3 10 26 denC
  have hN_ws4 : hRead ws4 10 3 = (N : ℤ) := by
    rw [hRead_hWrite_of_ne ws3 denC (Or.inr (by omega)), hN_ws3]
  have hLc_ws4 : hRead ws4 10 25 = L_ceil := by
    rw [hRead_hWrite_of_ne ws3 denC (Or.inr (by omega)), hLc_ws3]
  have hs5 := exec_write hctx hs4.2.1 10 (.lit 27)
    (.mul (.mul (.mul (.mul (.mul (.lit 8) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 3)))
                (.sub (.mul (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 3))) (.lit 2)))
          (.readHeap 10 (.lit 25))) (.readHeap 10 (.lit 25)))
    27 denA rfl
    (by
      dsimp only [ws4] at hN_ws4 hLc_ws4
      simp only [evalVal_mul, evalVal_sub, evalVal_readHeap, evalVal_lit, hN_ws4, hLc_ws4]; rfl)
    (by omega) (by omega) hScal0.2.1
  let ws5 := hWrite ws4 10 27 denA
  have hpr5 : PreservesOutside mod ws₀ ws5 :=
    (hpr3.trans (PreservesOutside.write ws3 denC (by dsimp [mod]; omega))).trans
      (PreservesOutside.write ws4 denA (by dsimp [mod]; omega))
  have hC_ws5 : ∀ i : Fin N, hRead ws5 26 (i.val : ℤ) = st.C i := by
    intro i
    have hi_lt : (i.val : ℤ) < ((2 * N : ℕ) : ℤ) := Nat.cast_lt.mpr (by omega)
    rw [hRead_hWrite_of_ne ws4 denA (Or.inl (by omega)),
        hRead_hWrite_of_ne ws3 denC (Or.inl (by omega)),
        hprH 26 _ (by dsimp [modH]; omega),
        hpr_sq 26 _ (by omega),
        hRead_hWrite_of_ne ws₀ _ (Or.inl (by omega))]
    exact hSt.2.1 i
  have hG_ws5 : ∀ j : Fin N, hRead ws5 26 ((N + j.val : ℕ) : ℤ) = G j := by
    intro j
    have hj_lt : ((N + j.val : ℕ) : ℤ) < ((2 * N : ℕ) : ℤ) := Nat.cast_lt.mpr (by omega)
    rw [hRead_hWrite_of_ne ws4 denA (Or.inl (by omega)),
        hRead_hWrite_of_ne ws3 denC (Or.inl (by omega)),
        hprH 26 _ (by dsimp [modH]; omega),
        hpr_sq 26 _ (by omega),
        hRead_hWrite_of_ne ws₀ _ (Or.inl (by omega))]
    exact hG_ws j
  have hH_ws5 : ∀ i : Fin N, hRead ws5 26 ((2 * N + i.val : ℕ) : ℤ) = H i := by
    intro i
    rw [hRead_hWrite_of_ne ws4 denA (Or.inl (by omega)),
        hRead_hWrite_of_ne ws3 denC (Or.inl (by omega))]
    exact hH_done i i.isLt
  have hA_ws5 : ∀ (i j : Fin N), hRead ws5 27 ((i.val * N + j.val : ℕ) : ℤ) = st.A i j := by
    intro i j
    rw [hRead_hWrite_of_ne ws4 denA (Or.inl (by omega)),
        hRead_hWrite_of_ne ws3 denC (Or.inl (by omega)),
        hprH 27 _ (by dsimp [modH]; omega),
        hpr_sq 27 _ (by omega),
        hRead_hWrite_of_ne ws₀ _ (Or.inl (by omega))]
    exact hSt.2.2 i j
  have hdenC_ws5 : hRead ws5 10 26 = denC := by
    rw [hRead_hWrite_of_ne ws4 denA (Or.inr (by omega)), hRead_hWrite_self]
  have hdenA_ws5 : hRead ws5 10 27 = denA := hRead_hWrite_self ws4 10 27 denA
  have hLc_ws5 : hRead ws5 10 25 = L_ceil := by
    rw [hRead_hWrite_of_ne ws4 denA (Or.inr (by omega)), hLc_ws4]
  -- Step 6: C[i] := stNext.C i (in-place on 26[0..N-1])
  let modC : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨ (t_id = 26 ∧ 0 ≤ idx ∧ idx < (N : ℤ))
  let InvC : ℕ → UL.WordStore → Prop := fun p ws =>
    PreservesOutside modC ws5 ws ∧
    (∀ i : Fin N, i.val < p → hRead ws 26 (i.val : ℤ) = stNext.C i) ∧
    (∀ i : Fin N, p ≤ i.val → hRead ws 26 (i.val : ℤ) = st.C i)
  have hInvC0 : InvC 0 (hWrite ws5 10 42 0) := by
    refine ⟨PreservesOutside.write ws5 0 (by dsimp [modC]; omega),
      fun _ h => False.elim (Nat.not_lt_zero _ h), fun i _ => ?_⟩
    rw [hRead_hWrite_of_ne ws5 0 (Or.inl (by omega))]; exact hC_ws5 i
  have hcntC : evalVal inp (hWrite ws5 10 42 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws5 0 (Or.inr (by omega)), hpr5 10 3 (by dsimp [mod]; omega), hPar.1]
  obtain ⟨ws6, _, ⟨hprC, hC_done, _⟩, hs6⟩ := exec_for hctx 42 (.readHeap 10 (.lit 3))
    (.writeHeap 26 (.readHeap 10 (.lit 42))
      (.sub (.readHeap 26 (.readHeap 10 (.lit 42)))
        (.div (.mul (.readHeap 10 (.lit 16))
                (.readHeap 26 (.add (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 42)))))
              (.readHeap 10 (.lit 26)))))
    N 1 InvC hs5.2.1 (by omega) (by omega) hcntC hInvC0
    (fun i hi ws hws hctr_i ⟨hpr_c, hprev_c, hunch_c⟩ => by
      let iFin : Fin N := ⟨i, hi⟩
      have hN_w : hRead ws 10 3 = (N : ℤ) := by
        rw [hpr_c 10 3 (by dsimp [modC]; omega), hpr5 10 3 (by dsimp [mod]; omega), hPar.1]
      have hK_w : hRead ws 10 16 = K_ell := by
        rw [hpr_c 10 16 (by dsimp [modC]; omega), hpr5 10 16 (by dsimp [mod]; omega)]
        exact hPar.2.2.2.2.2.2.2.2.2.2.1
      have hdC_w : hRead ws 10 26 = denC := by
        rw [hpr_c 10 26 (by dsimp [modC]; omega), hdenC_ws5]
      have hCi_w : hRead ws 26 (i : ℤ) = st.C iFin := hunch_c iFin le_rfl
      have h2Ni : (2 : ℤ) * (N : ℤ) + (i : ℤ) = ((2 * N + i : ℕ) : ℤ) := by push_cast; ring
      have hHi_w : hRead ws 26 ((2 * N + i : ℕ) : ℤ) = H iFin := by
        have hge : (N : ℤ) ≤ ((2 * N + i : ℕ) : ℤ) := Nat.cast_le.mpr (by omega)
        rw [hpr_c 26 _ (by dsimp [modC]; omega)]; exact hH_ws5 iFin
      have hval_c : evalVal inp ws
          (.sub (.readHeap 26 (.readHeap 10 (.lit 42)))
            (.div (.mul (.readHeap 10 (.lit 16))
                    (.readHeap 26 (.add (.mul (.lit 2) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 42)))))
                  (.readHeap 10 (.lit 26)))) = stNext.C iFin := by
        simp only [evalVal_sub, evalVal_div, evalVal_mul, evalVal_add, evalVal_readHeap, evalVal_lit,
          hctr_i, hCi_w, hK_w, hN_w, h2Ni, hHi_w, hdC_w, hStepEq]
      have hw_c := exec_write hctx hws 26 (.readHeap 10 (.lit 42)) _
        (i : ℤ) (stNext.C iFin)
        (by simp only [evalVal_readHeap, evalVal_lit, hctr_i]) hval_c
        (Nat.cast_nonneg _) (Nat.cast_le.mpr (by omega)) (hNextC_abs iFin)
      let ws' := hWrite ws 26 (i : ℤ) (stNext.C iFin)
      refine ⟨ws', hw_c, ?_, ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega)), hctr_i]
      · refine ⟨(hpr_c.trans (PreservesOutside.write ws _
            (Or.inr ⟨rfl, Nat.cast_nonneg _, Nat.cast_lt.mpr hi⟩))).trans
          (PreservesOutside.write ws' _ (by dsimp [modC]; omega)),
          fun i' hi' => ?_, fun i' hi' => ?_⟩
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
          · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]; exact hprev_c i' hlt
          · have hi_eq : i' = iFin := Fin.ext heq
            subst hi_eq; exact hRead_hWrite_self ws 26 _ _
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inr (by omega))]
          exact hunch_c i' (by omega))
  have hpr6 : PreservesOutside mod ws₀ ws6 :=
    hpr5.trans (hprC.mono (by intro t_id idx h; dsimp [modC] at h; dsimp [mod]; omega))
  -- Step 7-8 via exec_ellUpdateMatrixAStmt!
  obtain ⟨ws8, hprMA, hA_done, hsMA⟩ := exec_ellUpdateMatrixAStmt hctx h64
    ⟨by omega, hIdx.2⟩ K_ell L_ceil denA G H st.A stNext.A
    (fun i j => by rw [hStepEq])
    (fun i j => (ell_update_scalars_bound hN hL ht hBK hLc_lo hLc_hi
      (ellMagInv_entry_abs hMag i j) (hH_abs i) (hG_abs j)).2.2.1)
    (fun i j => (ell_update_scalars_bound hN hL ht hBK hLc_lo hLc_hi
      (ellMagInv_entry_abs hMag i j) (hH_abs i) (hG_abs j)).2.2.2)
    hNextA_abs hs6.2.1
    (by rw [hpr6 10 3 (by dsimp [mod]; omega), hPar.1])
    (by rw [hpr6 10 16 (by dsimp [mod]; omega)]; exact hPar.2.2.2.2.2.2.2.2.2.2.1)
    (by rw [hprC 10 25 (by dsimp [modC]; omega), hLc_ws5])
    (by rw [hprC 10 27 (by dsimp [modC]; omega), hdenA_ws5])
    (fun j => by
      have hge : (N : ℤ) ≤ ((N + j.val : ℕ) : ℤ) := Nat.cast_le.mpr (by omega)
      rw [hprC 26 _ (by dsimp [modC]; omega)]; exact hG_ws5 j)
    (fun i => by
      have hge : (N : ℤ) ≤ ((2 * N + i.val : ℕ) : ℤ) := Nat.cast_le.mpr (by omega)
      rw [hprC 26 _ (by dsimp [modC]; omega)]; exact hH_ws5 i)
    (fun i j => by rw [hprC 27 _ (by dsimp [modC]; omega)]; exact hA_ws5 i j)
  have hpr8 : PreservesOutside mod ws₀ ws8 :=
    hpr6.trans (hprMA.mono (by intro t_id idx h; dsimp [mod]; omega))
  have hSt8 : EllStateInHeap stNext ws8 := by
    refine ⟨?_, fun i => ?_, hA_done⟩
    · rw [hpr8 10 17 (by dsimp [mod]; omega), hSt.1, hst0, hStepEq]
    · rw [hprMA 26 _ (by omega)]; exact hC_done i i.isLt
  have htot := (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps
    (hs5.seq_steps (hs6.seq_steps hsMA)))))).mono_steps
    (by
      calc 1 + ((6 + 4 * B_sqrt) + ((2 + N * (4 + 2 * N + 1)) +
            (1 + (1 + ((2 + N * (1 + 1)) + (5 + N * (6 + 6 * N)))))))
          = 18 + 4 * B_sqrt + N * (13 + 8 * N) := by ring
        _ ≤ 18 + 4 * B_sqrt + N * (16 + 8 * N) :=
            Nat.add_le_add_left (Nat.mul_le_mul_left N (by omega)) _
        _ ≤ 24 + 4 * B_sqrt + N * (16 + 8 * N) := by omega)
  exact ⟨ws8, hpr8, hSt8, htot⟩

def ellStepStmt : UL.BitRAMStmt :=
  let mOraE := UL.IntExpr.readHeap 10 (.lit 4)
  let statE := UL.IntExpr.readHeap 10 (.lit 17)
  let violE := UL.IntExpr.readHeap 10 (.lit 18)
  let SnormE := UL.IntExpr.readHeap 10 (.lit 20)
  .ite (.not (.intEq statE (.lit 0)))
    .skip
    (.seq
      findViolatedRowStmt
      (.ite (.and (.intLe (.lit 0) violE) (.intLt violE mOraE))
        (.seq
          ellComputeGSStmt
          (.ite (.intLe SnormE (.lit 0))
            (.writeHeap 10 (.lit 17) (.lit (-1)))
            ellUpdateStateStmt))
        (.writeHeap 10 (.lit 17) (.lit 1))))

theorem exec_ellStepStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {N m_ora L t maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hN : 2 ≤ N) (hL : 1 ≤ L) (ht : t < ellParamT N L)
    (hBK : 5 * ellParamBsqrt N L ≤ K)
    (hIdx : 4 * N ≤ maxIdx ∧ 2 * (N * N) ≤ maxIdx ∧ m_ora ≤ maxIdx)
    {M_pad : Fin m_ora → Fin N → ℤ} {rhs : Fin m_ora → ℤ}
    (hM : ∀ i j, (M_pad i j).natAbs ≤ 2 ^ L)
    {st : EllState N} (hMag : EllMagInv (ellParamE N L) t st)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hPar : EllParamsInHeap L M_pad rhs ws₀)
    (hSt : EllStateInHeap st ws₀) :
    let B_sqrt := ellParamBsqrt N L
    let m_step := 40 + m_ora * (6 + 2 * N) + 4 * B_sqrt + N * (23 + 10 * N)
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ ((17 ≤ idx ∧ idx ≤ 29) ∨ idx = 42 ∨ idx = 43)) ∨
      t_id = 26 ∨ t_id = 27
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      EllStateInHeap (ellStep L M_pad rhs st) ws₁ ∧
      ExecBit inp maxIdx K ellStepStmt ws₀ ws₁
        (m_step * stepU) (m_step * stepB K) := by
  intro B_sqrt m_step mod
  let E := ellParamE N L
  by_cases hst : st.status = 0
  · have hcond0 : evalCondVal inp ws₀ (.not (.intEq (.readHeap 10 (.lit 17)) (.lit 0))) = false := by
      simp only [evalCondVal_not, evalCondVal_intEq, evalVal_readHeap, evalVal_lit, hSt.1, hst]
      rfl
    obtain ⟨hDotB, hDotSum, _, _, _, _, _, _, _⟩ := ell_step_mag_helpers hN hL ht hBK hM hMag
    obtain ⟨ws_v, hpr_v, hviol_ws, hex_v⟩ := exec_findViolatedRowStmt hctx h64
      ⟨by omega, hIdx.2.2⟩ hDotB hDotSum hws₀
      hPar.1 hPar.2.1 hPar.2.2.2.2.2.2.1 hPar.2.2.2.2.2.2.2.1
      hPar.2.2.2.2.2.2.2.2.2.2.2.1 hPar.2.2.2.2.2.2.2.2.2.2.2.2 hSt.2.1
    have hpr_v_mod : PreservesOutside mod ws₀ ws_v :=
      hpr_v.mono (by intro t_id idx h; dsimp [mod]; omega)
    have hPar_v := hPar.preserve hpr_v (by intro idx _ _; omega) (by omega) (by omega)
    have hSt_v := hSt.preserve hpr_v (by omega) (by omega) (by omega)
    let viol := findViolatedRow ((2 : ℤ) ^ (6 * E)) ((2 : ℤ) ^ (E + 1)) M_pad rhs st.C
    change hRead ws_v 10 18 = viol at hviol_ws
    let condViol := UL.BitCondExpr.and (.intLe (.lit 0) (.readHeap 10 (.lit 18)))
      (.intLt (.readHeap 10 (.lit 18)) (.readHeap 10 (.lit 4)))
    by_cases hv : 0 ≤ viol ∧ viol.toNat < m_ora
    · have hv_ltZ : viol < (m_ora : ℤ) := by omega
      have hc_viol : evalCondVal inp ws_v condViol = true := by
        simp only [condViol, evalCondVal_and, evalCondVal_intLe, evalCondVal_intLt,
          evalVal_lit, evalVal_readHeap, hviol_ws, hPar_v.2.1,
          decide_eq_true hv.1, decide_eq_true hv_ltZ, Bool.and_self]
      let i₀ : Fin m_ora := ⟨viol.toNat, hv.2⟩
      have hviol_i₀ : viol = (i₀.val : ℤ) := by dsimp [i₀]; omega
      obtain ⟨ws_gs, hpr_gs, hG_gs, hS_gs, hex_gs⟩ := exec_ellComputeGSStmt hctx h64
        hN hL ht hBK ⟨hIdx.1, hIdx.2.2⟩ hM hMag i₀ hex_v.2.1 hPar_v hSt_v
        (by rw [hviol_ws, hviol_i₀])
      have hpr_gs_mod : PreservesOutside mod ws₀ ws_gs :=
        hpr_v_mod.trans (hpr_gs.mono (by intro t_id idx h; dsimp [mod]; omega))
      have hPar_gs := hPar_v.preserve hpr_gs (by intro idx _ _; omega) (by omega) (by omega)
      have hSt_gs := hSt_v.preserve hpr_gs (by omega)
        (by intro idx _ hlt; omega) (by omega)
      let G : Fin N → ℤ := fun j => ∑ k : Fin N, M_pad i₀ k * st.A k j
      let S_norm : ℤ := ∑ j : Fin N, G j * G j
      by_cases hS0 : S_norm ≤ 0
      · have hc_S : evalCondVal inp ws_gs (.intLe (.readHeap 10 (.lit 20)) (.lit 0)) = true := by
          simp only [evalCondVal_intLe, evalVal_readHeap, evalVal_lit, hS_gs, decide_eq_true_eq]
          exact hS0
        have hw_neg1 := exec_write hctx hex_gs.2.1 10 (.lit 17) (.lit (-1))
          17 (-1) rfl rfl (by omega) (by omega) Nat.one_le_two_pow
        have hite_S := exec_ite_true hctx (.intLe (.readHeap 10 (.lit 20)) (.lit 0))
          (.writeHeap 10 (.lit 17) (.lit (-1))) ellUpdateStateStmt hc_S hw_neg1
        have hite_v := exec_ite_true hctx condViol _ (.writeHeap 10 (.lit 17) (.lit 1))
          hc_viol (hex_gs.seq_steps hite_S)
        have hite_0 := exec_ite_false hctx (.not (.intEq (.readHeap 10 (.lit 17)) (.lit 0)))
          .skip _ hcond0 (hex_v.seq_steps hite_v)
        let ws' := hWrite ws_gs 10 17 (-1)
        have hStepDeg : ellStep L M_pad rhs st = { st with status := -1 } := by
          unfold ellStep
          have hne : ¬ ((st.status != 0) = true) := by simp [hst]
          rw [if_neg hne]; dsimp only
          rw [dif_pos hv]
          rw [if_pos hS0]
        refine ⟨ws', hpr_gs_mod.trans (PreservesOutside.write ws_gs (-1) (by dsimp [mod]; omega)), ?_, ?_⟩
        · rw [hStepDeg]
          refine ⟨hRead_hWrite_self ws_gs 10 17 (-1), fun i => ?_, fun i j => ?_⟩
          · rw [hRead_hWrite_of_ne ws_gs (-1) (Or.inl (by omega))]; exact hSt_gs.2.1 i
          · rw [hRead_hWrite_of_ne ws_gs (-1) (Or.inl (by omega))]; exact hSt_gs.2.2 i j
        · refine hite_0.mono_steps ?_
          dsimp [m_step]
          calc (4 + m_ora * (6 + 2 * N)) + ((6 + N * (7 + 2 * N)) + (1 + 1) + 1) + 1
              = 14 + m_ora * (6 + 2 * N) + N * (7 + 2 * N) := by ring
            _ ≤ 14 + m_ora * (6 + 2 * N) + N * (23 + 10 * N) :=
                Nat.add_le_add_left (Nat.mul_le_mul_left N (by omega)) _
            _ ≤ 40 + m_ora * (6 + 2 * N) + 4 * B_sqrt + N * (23 + 10 * N) := by omega
      · have hS_pos : 0 < S_norm := not_le.mp hS0
        have hc_S : evalCondVal inp ws_gs (.intLe (.readHeap 10 (.lit 20)) (.lit 0)) = false := by
          simp only [evalCondVal_intLe, evalVal_readHeap, evalVal_lit, hS_gs, decide_eq_false_iff_not]
          exact hS0
        obtain ⟨ws_up, hpr_up, hSt_up, hex_up⟩ := exec_ellUpdateStateStmt hctx h64
          hN hL ht hBK ⟨hIdx.1, hIdx.2.1⟩ hM hMag hst i₀
          (by rw [← hviol_i₀]) hS_pos hex_gs.2.1 hPar_gs hSt_gs hG_gs hS_gs
        have hite_S := exec_ite_false hctx (.intLe (.readHeap 10 (.lit 20)) (.lit 0))
          (.writeHeap 10 (.lit 17) (.lit (-1))) ellUpdateStateStmt hc_S hex_up
        have hite_v := exec_ite_true hctx condViol _ (.writeHeap 10 (.lit 17) (.lit 1))
          hc_viol (hex_gs.seq_steps hite_S)
        have hite_0 := exec_ite_false hctx (.not (.intEq (.readHeap 10 (.lit 17)) (.lit 0)))
          .skip _ hcond0 (hex_v.seq_steps hite_v)
        refine ⟨ws_up, hpr_gs_mod.trans (hpr_up.mono (by intro t_id idx h; dsimp [mod]; omega)),
          hSt_up, hite_0.mono_steps ?_⟩
        dsimp [m_step]
        calc (4 + m_ora * (6 + 2 * N)) +
              ((6 + N * (7 + 2 * N)) + ((24 + 4 * B_sqrt + N * (16 + 8 * N)) + 1) + 1) + 1
            = 37 + m_ora * (6 + 2 * N) + 4 * B_sqrt + N * (23 + 10 * N) := by ring
          _ ≤ 40 + m_ora * (6 + 2 * N) + 4 * B_sqrt + N * (23 + 10 * N) := by omega
    · have hc_viol : evalCondVal inp ws_v condViol = false := by
        simp only [condViol, evalCondVal_and, evalCondVal_intLe, evalCondVal_intLt,
          evalVal_lit, evalVal_readHeap, hviol_ws, hPar_v.2.1, Bool.and_eq_false_iff,
          decide_eq_false_iff_not]
        by_cases h0 : 0 ≤ viol
        · right; omega
        · left; exact h0
      have hw_1 := exec_write hctx hex_v.2.1 10 (.lit 17) (.lit 1)
        17 1 rfl rfl (by omega) (by omega) Nat.one_le_two_pow
      have hite_v := exec_ite_false hctx condViol
        (.seq ellComputeGSStmt (.ite (.intLe (.readHeap 10 (.lit 20)) (.lit 0))
          (.writeHeap 10 (.lit 17) (.lit (-1))) ellUpdateStateStmt))
        (.writeHeap 10 (.lit 17) (.lit 1)) hc_viol hw_1
      have hite_0 := exec_ite_false hctx (.not (.intEq (.readHeap 10 (.lit 17)) (.lit 0)))
        .skip _ hcond0 (hex_v.seq_steps hite_v)
      let ws' := hWrite ws_v 10 17 1
      have hStepFeas : ellStep L M_pad rhs st = { st with status := 1 } := by
        unfold ellStep
        have hne : ¬ ((st.status != 0) = true) := by simp [hst]
        rw [if_neg hne]; dsimp only
        rw [dif_neg hv]
      refine ⟨ws', hpr_v_mod.trans (PreservesOutside.write ws_v 1 (by dsimp [mod]; omega)), ?_, ?_⟩
      · rw [hStepFeas]
        refine ⟨hRead_hWrite_self ws_v 10 17 1, fun i => ?_, fun i j => ?_⟩
        · rw [hRead_hWrite_of_ne ws_v 1 (Or.inl (by omega))]; exact hSt_v.2.1 i
        · rw [hRead_hWrite_of_ne ws_v 1 (Or.inl (by omega))]; exact hSt_v.2.2 i j
      · refine hite_0.mono_steps ?_
        dsimp [m_step]; omega
  · have hcond0 : evalCondVal inp ws₀ (.not (.intEq (.readHeap 10 (.lit 17)) (.lit 0))) = true := by
      simp only [evalCondVal_not, evalCondVal_intEq, evalVal_readHeap, evalVal_lit, hSt.1,
        decide_eq_false hst]; rfl
    have hStepDone : ellStep L M_pad rhs st = st := by
      unfold ellStep
      have hne : (st.status != 0) = true := by simp [bne, hst]
      rw [if_pos hne]
    have hite_0 := exec_ite_true hctx (.not (.intEq (.readHeap 10 (.lit 17)) (.lit 0)))
      .skip
      (.seq findViolatedRowStmt
        (.ite (.and (.intLe (.lit 0) (.readHeap 10 (.lit 18))) (.intLt (.readHeap 10 (.lit 18)) (.readHeap 10 (.lit 4))))
          (.seq ellComputeGSStmt (.ite (.intLe (.readHeap 10 (.lit 20)) (.lit 0))
            (.writeHeap 10 (.lit 17) (.lit (-1))) ellUpdateStateStmt))
          (.writeHeap 10 (.lit 17) (.lit 1))))
      hcond0 (exec_skip hctx hws₀)
    refine ⟨ws₀, PreservesOutside.refl mod ws₀, ?_, hite_0.mono_steps (by dsimp [m_step]; omega)⟩
    rwa [hStepDone]


/-! ### 6. `ellipsoidDecideStmt` & `exec_ellipsoidDecideStmt` -/

def ellipsoidDecideStmt : UL.BitRAMStmt :=
  let NE := UL.IntExpr.readHeap 10 (.lit 3)
  let LE := UL.IntExpr.readHeap 10 (.lit 7)
  let EE := UL.IntExpr.readHeap 10 (.lit 9)
  let TE := UL.IntExpr.readHeap 10 (.lit 10)
  let BsqrtE := UL.IntExpr.readHeap 10 (.lit 11)
  let pow7EE := UL.IntExpr.readHeap 10 (.lit 14)
  let iE := UL.IntExpr.readHeap 10 (.lit 42)
  let jE := UL.IntExpr.readHeap 10 (.lit 43)
  let ijE := UL.IntExpr.add (.mul iE NE) jE
  seqBitStmts
    [ .writeHeap 10 (.lit 9) (.mul (.add NE (.lit 2)) (.add (.add NE (.lit 2)) LE))
    , .writeHeap 10 (.lit 10)
        (.add (.mul (.mul (.mul (.lit 10) (.add NE (.lit 1))) NE)
                    (.add (.add (.mul (.lit 3) EE) NE) (.lit 2))) (.lit 1))
    , .writeHeap 10 (.lit 11) (.add (.mul (.lit 10) EE) (.mul (.lit 2) TE))
    , pow2Stmt 10 (.lit 12) (.mul (.lit 6) EE)
    , pow2Stmt 10 (.lit 13) (.add EE (.lit 1))
    , pow2Stmt 10 (.lit 14) (.mul (.lit 7) EE)
    , pow2Stmt 10 (.lit 15) BsqrtE
    , .writeHeap 10 (.lit 16) (.mul (.mul (.lit 16) NE) NE)
    , .writeHeap 10 (.lit 17) (.lit 0)
    , forLoopStmt 42 NE (.writeHeap 26 iE (.lit 0))
    , forLoopStmt 42 NE
        (forLoopStmt 43 NE
          (.ite (.intEq iE jE)
            (.writeHeap 27 ijE pow7EE)
            (.writeHeap 27 ijE (.lit 0))))
    , forLoopStmt 41 TE ellStepStmt ]

theorem exec_ellipsoidDecideStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe L maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hL : 1 ≤ L)
    (hBK : 5 * ellParamBsqrt (nVars + 2) L ≤ K)
    (hIdx : 4 * (nVars + 2) ≤ maxIdx ∧
            2 * ((nVars + 2) * (nVars + 2)) ≤ maxIdx ∧
            (2 * nEq + 2 * nLe) ≤ maxIdx)
    {M_ora : Fin (2 * nEq + 2 * nLe) → Fin nVars → ℤ}
    {d_ora : Fin (2 * nEq + 2 * nLe) → ℤ}
    (hM_ora : ∀ i j, (M_ora i j).natAbs ≤ 2 ^ L)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hL_ws : hRead ws₀ 10 7 = (L : ℤ))
    (hM_ws : ∀ (r : Fin (2 * nEq + 2 * nLe)) (j : Fin (nVars + 2)),
      hRead ws₀ 24 ((r.val * (nVars + 2) + j.val : ℕ) : ℤ) = padCols M_ora r j)
    (hd_ws : ∀ r : Fin (2 * nEq + 2 * nLe), hRead ws₀ 25 (r.val : ℤ) = d_ora r) :
    let N := nVars + 2
    let m_ora := 2 * nEq + 2 * nLe
    let T := ellParamT N L
    let B_sqrt := ellParamBsqrt N L
    let m_step := 40 + m_ora * (6 + 2 * N) + 4 * B_sqrt + N * (23 + 10 * N)
    let m_tot := 30 + 3 * B_sqrt + N * (6 + 3 * N) + T * (m_step + 1)
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ ((9 ≤ idx ∧ idx ≤ 29) ∨ (41 ≤ idx ∧ idx ≤ 43))) ∨
      t_id = 26 ∨ t_id = 27
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (hRead ws₁ 10 17 == 1) = ellipsoidDecide nVars m_ora L M_ora d_ora ∧
      ExecBit inp maxIdx K ellipsoidDecideStmt ws₀ ws₁
        (m_tot * stepU) (m_tot * stepB K) := by
  intro N m_ora T B_sqrt m_step m_tot mod
  let E := ellParamE N L
  have hN2 : 2 ≤ N := by dsimp [N]; omega
  have hMpad : ∀ (r : Fin m_ora) (j : Fin N), (padCols M_ora r j).natAbs ≤ 2 ^ L := by
    intro r j; dsimp [padCols]
    by_cases hj : j.val < nVars
    · rw [dif_pos hj]; exact hM_ora r ⟨j.val, hj⟩
    · rw [dif_neg hj]; simp
  obtain ⟨_, _, _, h6EK, hE1K, h7EK, hBK1, _, hE_abs, hT_abs, hB_abs, hKell_abs⟩ :=
    ell_basic_exp_bounds hN2 hL hBK
  have hEB : 10 * E + 2 * T = B_sqrt := rfl
  have hs1 := exec_write hctx hws₀ 10 (.lit 9)
    (.mul (.add (.readHeap 10 (.lit 3)) (.lit 2))
          (.add (.add (.readHeap 10 (.lit 3)) (.lit 2)) (.readHeap 10 (.lit 7))))
    9 (E : ℤ) rfl
    (by simp only [evalVal_mul, evalVal_add, evalVal_readHeap, evalVal_lit,
          hDims.2.2.2.1, hL_ws]; dsimp [E, ellParamE, N])
    (by omega) (by omega) hE_abs
  let ws1 := hWrite ws₀ 10 9 (E : ℤ)
  have hs2 := exec_write hctx hs1.2.1 10 (.lit 10)
    (.add (.mul (.mul (.mul (.lit 10) (.add (.readHeap 10 (.lit 3)) (.lit 1))) (.readHeap 10 (.lit 3)))
                (.add (.add (.mul (.lit 3) (.readHeap 10 (.lit 9))) (.readHeap 10 (.lit 3))) (.lit 2)))
          (.lit 1))
    10 (T : ℤ) rfl
    (by
      have hN_1 : hRead ws1 10 3 = (N : ℤ) := by
        rw [hRead_hWrite_of_ne ws₀ _ (Or.inr (by omega))]; exact hDims.2.2.2.1
      have hE_1 : hRead ws1 10 9 = (E : ℤ) := hRead_hWrite_self ws₀ 10 9 (E : ℤ)
      dsimp only [ws1] at hN_1 hE_1
      simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hN_1, hE_1]
      dsimp [T, ellParamT])
    (by omega) (by omega) hT_abs
  let ws2 := hWrite ws1 10 10 (T : ℤ)
  have hs3 := exec_write hctx hs2.2.1 10 (.lit 11)
    (.add (.mul (.lit 10) (.readHeap 10 (.lit 9))) (.mul (.lit 2) (.readHeap 10 (.lit 10))))
    11 (B_sqrt : ℤ) rfl
    (by
      have hE_2 : hRead ws2 10 9 = (E : ℤ) := by
        rw [hRead_hWrite_of_ne ws1 _ (Or.inr (by omega)), hRead_hWrite_self]
      have hT_2 : hRead ws2 10 10 = (T : ℤ) := hRead_hWrite_self ws1 10 10 (T : ℤ)
      dsimp only [ws2, ws1] at hE_2 hT_2
      simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hE_2, hT_2]
      dsimp [B_sqrt, ellParamBsqrt, E, T])
    (by omega) (by omega) hB_abs
  let ws3 := hWrite ws2 10 11 (B_sqrt : ℤ)
  have hpr3 : PreservesOutside (fun t_id idx => t_id = 10 ∧ (idx = 9 ∨ idx = 10 ∨ idx = 11)) ws₀ ws3 :=
    ((PreservesOutside.write ws₀ _ (by omega)).trans
      (PreservesOutside.write ws1 _ (by omega))).trans
      (PreservesOutside.write ws2 _ (by omega))
  have hE_ws3 : hRead ws3 10 9 = (E : ℤ) := by
    rw [hRead_hWrite_of_ne ws2 _ (Or.inr (by omega)),
        hRead_hWrite_of_ne ws1 _ (Or.inr (by omega)), hRead_hWrite_self]
  have hB_ws3 : hRead ws3 10 11 = (B_sqrt : ℤ) := hRead_hWrite_self ws2 10 11 (B_sqrt : ℤ)
  obtain ⟨ws4, hP_ws4, hpr4, hs4⟩ := exec_pow2 hctx hs3.2.1 10 12 (6 * E)
    (.mul (.lit 6) (.readHeap 10 (.lit 9))) (by omega) h6EK
    (by
      simp only [evalVal_mul, evalVal_lit, evalVal_readHeap]
      rw [hRead_hWrite_of_ne _ 1 (Or.inr (by omega))]
      dsimp only [ws3, ws2, ws1] at hE_ws3; rw [hE_ws3]; push_cast; ring)
  obtain ⟨ws5, hQ_ws5, hpr5, hs5⟩ := exec_pow2 hctx hs4.2.1 10 13 (E + 1)
    (.add (.readHeap 10 (.lit 9)) (.lit 1)) (by omega) hE1K
    (by
      simp only [evalVal_add, evalVal_readHeap, evalVal_lit]
      rw [hRead_hWrite_of_ne ws4 1 (Or.inr (by omega)), hpr4 10 9 (by omega), hE_ws3]
      push_cast; ring)
  obtain ⟨ws6, h7E_ws6, hpr6, hs6⟩ := exec_pow2 hctx hs5.2.1 10 14 (7 * E)
    (.mul (.lit 7) (.readHeap 10 (.lit 9))) (by omega) h7EK
    (by
      simp only [evalVal_mul, evalVal_lit, evalVal_readHeap]
      rw [hRead_hWrite_of_ne ws5 1 (Or.inr (by omega)), hpr5 10 9 (by omega),
          hpr4 10 9 (by omega), hE_ws3]
      push_cast; ring)
  obtain ⟨ws7, hPB_ws7, hpr7, hs7⟩ := exec_pow2 hctx hs6.2.1 10 15 B_sqrt
    (.readHeap 10 (.lit 11)) (by omega) hBK1
    (by
      simp only [evalVal_readHeap, evalVal_lit]
      rw [hRead_hWrite_of_ne ws6 1 (Or.inr (by omega)), hpr6 10 11 (by omega),
          hpr5 10 11 (by omega), hpr4 10 11 (by omega), hB_ws3])
  have hpr07 : PreservesOutside (fun t_id idx => t_id = 10 ∧ (9 ≤ idx ∧ idx ≤ 15)) ws₀ ws7 :=
    ((((hpr3.mono (by intro _ _ h; omega)).trans
      (hpr4.mono (by intro _ _ h; omega))).trans
      (hpr5.mono (by intro _ _ h; omega))).trans
      (hpr6.mono (by intro _ _ h; omega))).trans
      (hpr7.mono (by intro _ _ h; omega))
  have hN_ws7 : hRead ws7 10 3 = (N : ℤ) := by rw [hpr07 10 3 (by omega)]; exact hDims.2.2.2.1
  have hs8 := exec_write hctx hs7.2.1 10 (.lit 16)
    (.mul (.mul (.lit 16) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 3)))
    16 (16 * (N : ℤ) * (N : ℤ)) rfl
    (by simp only [evalVal_mul, evalVal_lit, evalVal_readHeap, hN_ws7])
    (by omega) (by omega) hKell_abs
  let ws8 := hWrite ws7 10 16 (16 * (N : ℤ) * (N : ℤ))
  have hs9 := exec_write hctx hs8.2.1 10 (.lit 17) (.lit 0)
    17 0 rfl rfl (by omega) (by omega) (by simp)
  let ws9 := hWrite ws8 10 17 0
  have hpr09 : PreservesOutside (fun t_id idx => t_id = 10 ∧ (9 ≤ idx ∧ idx ≤ 17)) ws₀ ws9 :=
    ((hpr07.mono (by intro _ _ h; omega)).trans
      (PreservesOutside.write ws7 _ (by omega))).trans
      (PreservesOutside.write ws8 0 (by omega))
  have hPar9 : EllParamsInHeap L (padCols M_ora) d_ora ws9 := by
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, fun r j => ?_, fun r => ?_⟩
    · rw [hpr09 10 3 (by omega)]; exact hDims.2.2.2.1
    · rw [hpr09 10 4 (by omega)]; exact hDims.2.2.2.2.1
    · rw [hpr09 10 7 (by omega)]; exact hL_ws
    · rw [hRead_hWrite_of_ne ws8 0 (Or.inr (by omega)),
          hRead_hWrite_of_ne ws7 _ (Or.inr (by omega)),
          hpr7 10 9 (by omega), hpr6 10 9 (by omega), hpr5 10 9 (by omega),
          hpr4 10 9 (by omega), hE_ws3]
    · rw [hRead_hWrite_of_ne ws8 0 (Or.inr (by omega)),
          hRead_hWrite_of_ne ws7 _ (Or.inr (by omega)),
          hpr7 10 10 (by omega), hpr6 10 10 (by omega), hpr5 10 10 (by omega),
          hpr4 10 10 (by omega),
          hRead_hWrite_of_ne ws2 _ (Or.inr (by omega)), hRead_hWrite_self]
    · rw [hRead_hWrite_of_ne ws8 0 (Or.inr (by omega)),
          hRead_hWrite_of_ne ws7 _ (Or.inr (by omega)),
          hpr7 10 11 (by omega), hpr6 10 11 (by omega), hpr5 10 11 (by omega),
          hpr4 10 11 (by omega), hB_ws3]
    · rw [hRead_hWrite_of_ne ws8 0 (Or.inr (by omega)),
          hRead_hWrite_of_ne ws7 _ (Or.inr (by omega)),
          hpr7 10 12 (by omega), hpr6 10 12 (by omega), hpr5 10 12 (by omega), hP_ws4]
    · rw [hRead_hWrite_of_ne ws8 0 (Or.inr (by omega)),
          hRead_hWrite_of_ne ws7 _ (Or.inr (by omega)),
          hpr7 10 13 (by omega), hpr6 10 13 (by omega), hQ_ws5]
    · rw [hRead_hWrite_of_ne ws8 0 (Or.inr (by omega)),
          hRead_hWrite_of_ne ws7 _ (Or.inr (by omega)),
          hpr7 10 14 (by omega), h7E_ws6]
    · rw [hRead_hWrite_of_ne ws8 0 (Or.inr (by omega)),
          hRead_hWrite_of_ne ws7 _ (Or.inr (by omega)), hPB_ws7]
    · rw [hRead_hWrite_of_ne ws8 0 (Or.inr (by omega)), hRead_hWrite_self]
    · rw [hpr09 24 _ (by omega)]; exact hM_ws r j
    · rw [hpr09 25 _ (by omega)]; exact hd_ws r
  -- 10. Initialize C[0..N-1] := 0
  let modInitC : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨ (t_id = 26 ∧ 0 ≤ idx ∧ idx < (N : ℤ))
  let InvInitC : ℕ → UL.WordStore → Prop := fun p ws =>
    PreservesOutside modInitC ws9 ws ∧
    (∀ i : Fin N, i.val < p → hRead ws 26 (i.val : ℤ) = 0)
  have hInvIC0 : InvInitC 0 (hWrite ws9 10 42 0) :=
    ⟨PreservesOutside.write ws9 0 (by dsimp [modInitC]; omega),
     fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
  have hcntIC : evalVal inp (hWrite ws9 10 42 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws9 0 (Or.inr (by omega)), hPar9.1]
  obtain ⟨ws10, _, ⟨hprIC, hIC_done⟩, hs10⟩ := exec_for hctx 42 (.readHeap 10 (.lit 3))
    (.writeHeap 26 (.readHeap 10 (.lit 42)) (.lit 0))
    N 1 InvInitC hs9.2.1 (by omega) (by omega) hcntIC hInvIC0
    (fun i hi ws hws hctr_i ⟨hpr_i, hprev_i⟩ => by
      have hw_z := exec_write hctx hws 26 (.readHeap 10 (.lit 42)) (.lit 0)
        (i : ℤ) 0 (by simp only [evalVal_readHeap, evalVal_lit, hctr_i]) rfl
        (Nat.cast_nonneg _) (Nat.cast_le.mpr (by omega)) (by simp)
      let ws' := hWrite ws 26 (i : ℤ) 0
      refine ⟨ws', hw_z, ?_, ?_⟩
      · rw [hRead_hWrite_of_ne ws 0 (Or.inl (by omega)), hctr_i]
      · refine ⟨(hpr_i.trans (PreservesOutside.write ws 0
            (Or.inr ⟨rfl, Nat.cast_nonneg _, Nat.cast_lt.mpr hi⟩))).trans
          (PreservesOutside.write ws' _ (by dsimp [modInitC]; omega)), fun i' hi' => ?_⟩
        rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne ws 0 (Or.inr (by omega))]; exact hprev_i i' hlt
        · rw [heq]; exact hRead_hWrite_self ws 26 _ 0)
  have hPar10 := hPar9.preserve hprIC (by intro idx _ _; dsimp [modInitC]; omega)
    (by dsimp [modInitC]; omega) (by dsimp [modInitC]; omega)
  -- 11. Initialize A[i, j]
  let modInitA : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 42 ∨ idx = 43)) ∨ (t_id = 27 ∧ 0 ≤ idx ∧ idx < ((N * N : ℕ) : ℤ))
  let InvInitA : ℕ → UL.WordStore → Prop := fun r ws =>
    PreservesOutside modInitA ws10 ws ∧
    (∀ (i j : Fin N), i.val < r →
      hRead ws 27 ((i.val * N + j.val : ℕ) : ℤ) = (ellInit N L).A i j)
  have hInvIA0 : InvInitA 0 (hWrite ws10 10 42 0) :=
    ⟨PreservesOutside.write ws10 0 (by dsimp [modInitA]; omega),
     fun _ _ h => False.elim (Nat.not_lt_zero _ h)⟩
  have hcntIA : evalVal inp (hWrite ws10 10 42 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws10 0 (Or.inr (by omega)), hPar10.1]
  have h7E_abs : ((2 : ℤ) ^ (7 * E)).natAbs ≤ 2 ^ K := by
    rw [show (2 : ℤ) ^ (7 * E) = ((2 ^ (7 * E) : ℕ) : ℤ) by push_cast; rfl, Int.natAbs_natCast]
    exact Nat.pow_le_pow_right (by omega) h7EK
  obtain ⟨ws11, _, ⟨hprIA, hIA_done⟩, hs11⟩ := exec_for hctx 42 (.readHeap 10 (.lit 3))
    (forLoopStmt 43 (.readHeap 10 (.lit 3))
      (.ite (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 43)))
        (.writeHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
          (.readHeap 10 (.lit 14)))
        (.writeHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
          (.lit 0))))
    N (2 + 3 * N) InvInitA hs10.2.1 (by omega) (by omega) hcntIA hInvIA0
    (fun i hi ws hws hctr_i ⟨hpr_i, hprev_i⟩ => by
      let iFin : Fin N := ⟨i, hi⟩
      let modInA : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 43) ∨
        (t_id = 27 ∧ ((i * N : ℕ) : ℤ) ≤ idx ∧ idx < (((i + 1) * N : ℕ) : ℤ))
      let InvInA : ℕ → UL.WordStore → Prop := fun c wsi =>
        PreservesOutside modInA ws wsi ∧
        (∀ j : Fin N, j.val < c →
          hRead wsi 27 ((i * N + j.val : ℕ) : ℤ) = (ellInit N L).A iFin j)
      have hInvInA0 : InvInA 0 (hWrite ws 10 43 0) :=
        ⟨PreservesOutside.write ws 0 (by dsimp [modInA]; omega),
         fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
      have hcntInA : evalVal inp (hWrite ws 10 43 0) (.readHeap 10 (.lit 3)) = (N : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne ws 0 (Or.inr (by omega)),
            hpr_i 10 3 (by dsimp [modInitA]; omega), hPar10.1]
      obtain ⟨ws_in, _, ⟨hprInA, hRowA_done⟩, hex_inA⟩ := exec_for hctx 43 (.readHeap 10 (.lit 3))
        (.ite (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 43)))
          (.writeHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
            (.readHeap 10 (.lit 14)))
          (.writeHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
            (.lit 0)))
        N 2 InvInA hws (by omega) (by omega) hcntInA hInvInA0
        (fun j hj wsi hwsi hctr_j ⟨hpr_j, hprev_j⟩ => by
          let jFin : Fin N := ⟨j, hj⟩
          have hij_lt_next : i * N + j < (i + 1) * N := by
            calc i * N + j < i * N + N := Nat.add_lt_add_left hj _
              _ = (i + 1) * N := by ring
          have hNext_le_NN : (i + 1) * N ≤ N * N := Nat.mul_le_mul_right N hi
          have hN_w : hRead wsi 10 3 = (N : ℤ) := by
            rw [hpr_j 10 3 (by dsimp [modInA]; omega), hpr_i 10 3 (by dsimp [modInitA]; omega), hPar10.1]
          have hi_w : hRead wsi 10 42 = (i : ℤ) := by
            rw [hpr_j 10 42 (by dsimp [modInA]; omega), hctr_i]
          have h7E_w : hRead wsi 10 14 = (2 : ℤ) ^ (7 * E) := by
            rw [hpr_j 10 14 (by dsimp [modInA]; omega), hpr_i 10 14 (by dsimp [modInitA]; omega)]
            exact hPar10.2.2.2.2.2.2.2.2.1
          have hij_eq : (i : ℤ) * (N : ℤ) + (j : ℤ) = ((i * N + j : ℕ) : ℤ) := by push_cast; ring
          have hij_max : i * N + j ≤ maxIdx :=
            (hij_lt_next.le.trans hNext_le_NN).trans (by dsimp [N]; omega)
          have hdst_ev : evalVal inp wsi
              (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))) =
              ((i * N + j : ℕ) : ℤ) := by
            simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_w, hN_w, hctr_j, hij_eq]
          by_cases hij : i = j
          · have hc : evalCondVal inp wsi (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 43))) = true := by
              simp only [evalCondVal_intEq, evalVal_readHeap, evalVal_lit, hi_w, hctr_j, hij, decide_true]
            have hw_d := exec_write hctx hwsi 27
              (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
              (.readHeap 10 (.lit 14))
              ((i * N + j : ℕ) : ℤ) ((2 : ℤ) ^ (7 * E))
              hdst_ev (by simp only [evalVal_readHeap, evalVal_lit, h7E_w])
              (Nat.cast_nonneg _) (Nat.cast_le.mpr hij_max) h7E_abs
            have hite := exec_ite_true hctx (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 43)))
              _ (.writeHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))) (.lit 0))
              hc hw_d
            let wsi' := hWrite wsi 27 ((i * N + j : ℕ) : ℤ) ((2 : ℤ) ^ (7 * E))
            refine ⟨wsi', hite, ?_, ?_⟩
            · rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hctr_j]
            · refine ⟨(hpr_j.trans (PreservesOutside.write wsi _
                  (Or.inr ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hij_lt_next⟩))).trans
                (PreservesOutside.write wsi' _ (by dsimp [modInA]; omega)), fun j' hj' => ?_⟩
              rw [hRead_hWrite_of_ne wsi' _ (Or.inl (by omega))]
              rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
              · rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]; exact hprev_j j' hlt
              · have hj_eq : j' = jFin := Fin.ext heq
                subst hj_eq
                have hijF : iFin = jFin := Fin.ext hij
                rw [hRead_hWrite_self]; dsimp [ellInit]; rw [if_pos hijF]
          · have hc : evalCondVal inp wsi (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 43))) = false := by
              simp only [evalCondVal_intEq, evalVal_readHeap, evalVal_lit, hi_w, hctr_j,
                decide_eq_false_iff_not]; omega
            have hw_z := exec_write hctx hwsi 27
              (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
              (.lit 0)
              ((i * N + j : ℕ) : ℤ) 0 hdst_ev rfl
              (Nat.cast_nonneg _) (Nat.cast_le.mpr hij_max) (by simp)
            have hite := exec_ite_false hctx (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 43)))
              (.writeHeap 27 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43)))
                (.readHeap 10 (.lit 14))) _ hc hw_z
            let wsi' := hWrite wsi 27 ((i * N + j : ℕ) : ℤ) 0
            refine ⟨wsi', hite, ?_, ?_⟩
            · rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hctr_j]
            · refine ⟨(hpr_j.trans (PreservesOutside.write wsi _
                  (Or.inr ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hij_lt_next⟩))).trans
                (PreservesOutside.write wsi' _ (by dsimp [modInA]; omega)), fun j' hj' => ?_⟩
              rw [hRead_hWrite_of_ne wsi' _ (Or.inl (by omega))]
              rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
              · rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]; exact hprev_j j' hlt
              · have hj_eq : j' = jFin := Fin.ext heq
                subst hj_eq
                have hijF : iFin ≠ jFin := fun h => hij (congrArg Fin.val h)
                rw [hRead_hWrite_self]; dsimp [ellInit]; rw [if_neg hijF])
      have hNext_le_NN : (i + 1) * N ≤ N * N := Nat.mul_le_mul_right N hi
      refine ⟨ws_in, hex_inA.mono_steps (by ring_nf; omega), ?_, ?_⟩
      · rw [hprInA 10 42 (by dsimp [modInA]; omega), hctr_i]
      · refine ⟨(hpr_i.trans (hprInA.mono (by
            intro t_id idx h; dsimp [modInA] at h; dsimp [modInitA]
            rcases h with ⟨rfl, h1⟩ | ⟨rfl, hlo, hhi⟩
            · exact Or.inl ⟨rfl, Or.inr h1⟩
            · exact Or.inr ⟨rfl, le_trans (Nat.cast_nonneg _) hlo,
                lt_of_lt_of_le hhi (Nat.cast_le.mpr hNext_le_NN)⟩))).trans
          (PreservesOutside.write ws_in _ (by dsimp [modInitA]; omega)),
          fun i' j' hi' => ?_⟩
        rw [hRead_hWrite_of_ne ws_in _ (Or.inl (by omega))]
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · have hlt_i : i'.val * N + j'.val < i * N := by
            calc i'.val * N + j'.val < i'.val * N + N := Nat.add_lt_add_left j'.isLt _
              _ = (i'.val + 1) * N := by ring
              _ ≤ i * N := Nat.mul_le_mul_right N hlt
          rw [hprInA 27 _ (by dsimp [modInA]; omega)]; exact hprev_i i' j' hlt
        · have hi_eq : i' = iFin := Fin.ext heq
          subst hi_eq; exact hRowA_done j' j'.isLt)
  have hPar11 := hPar10.preserve hprIA (by intro idx _ _; dsimp [modInitA]; omega)
    (by dsimp [modInitA]; omega) (by dsimp [modInitA]; omega)
  have hpr011 : PreservesOutside mod ws₀ ws11 :=
    ((hpr09.mono (by intro t_id idx h; dsimp [mod]; omega)).trans
      (hprIC.mono (by intro t_id idx h; dsimp [modInitC] at h; dsimp [mod]; omega))).trans
      (hprIA.mono (by intro t_id idx h; dsimp [modInitA] at h; dsimp [mod]; omega))
  have hSt11 : EllStateInHeap (ellInit N L) ws11 := by
    refine ⟨?_, fun i => ?_, fun i j => hIA_done i j i.isLt⟩
    · rw [hprIA 10 17 (by dsimp [modInitA]; omega),
          hprIC 10 17 (by dsimp [modInitC]; omega)]
      exact hRead_hWrite_self ws8 10 17 0
    · rw [hprIA 26 _ (by dsimp [modInitA]; omega)]
      exact hIC_done i i.isLt
  -- 12. Outer loop t < T running ellStepStmt (via exec_for_val!)
  let runAt : ℕ → EllState N := fun t =>
    Fin.foldl t (fun st _ => ellStep L (padCols M_ora) d_ora st) (ellInit N L)
  have hRunMag : ∀ t ≤ T, EllMagInv E t (runAt t) := by
    intro t
    induction t with
    | zero =>
        intro _; dsimp [runAt]; rw [Fin.foldl_zero]; exact ellMagInv_init hN2 hL
    | succ t ih =>
        intro ht
        have hf : runAt (t + 1) = ellStep L (padCols M_ora) d_ora (runAt t) := by
          dsimp [runAt]; rw [Fin.foldl_succ_last]
        rw [hf]
        exact ellMagInv_step hN2 hL ht (padCols M_ora) d_ora hMpad (ih (Nat.le_of_succ_le ht))
  let InvRun : ℕ → UL.WordStore → Prop := fun t ws =>
    PreservesOutside mod ws₀ ws ∧
    EllParamsInHeap L (padCols M_ora) d_ora ws ∧
    EllStateInHeap (runAt t) ws
  have hInvRun0 : InvRun 0 (hWrite ws11 10 41 0) := by
    have hp : PreservesOutside (fun t_id idx => t_id = 10 ∧ idx = 41) ws11 (hWrite ws11 10 41 0) :=
      PreservesOutside.write ws11 0 ⟨rfl, rfl⟩
    refine ⟨hpr011.trans (hp.mono (by intro t_id idx h; dsimp [mod]; omega)),
      hPar11.preserve hp (by intro idx _ _; omega) (by omega) (by omega), ?_⟩
    dsimp [runAt]; rw [Fin.foldl_zero]
    exact hSt11.preserve hp (by omega) (by omega) (by omega)
  have hcntRun : evalVal inp (hWrite ws11 10 41 0) (.readHeap 10 (.lit 10)) = (T : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws11 0 (Or.inr (by omega)), hPar11.2.2.2.2.1]
  have hT_pow : T ≤ 2 ^ K := by
    have : (T : ℤ).natAbs = T := Int.natAbs_natCast T
    rwa [← this]
  obtain ⟨ws12, _, ⟨hpr12, _, hSt12⟩, hs12⟩ := exec_for_val hctx 41 (.readHeap 10 (.lit 10))
    ellStepStmt T m_step InvRun hs11.2.1 (by omega) hT_pow hcntRun hInvRun0
    (fun t ht ws hws hctr_t ⟨hpr_t, hPar_t, hSt_t⟩ => by
      obtain ⟨ws_s, hpr_s, hSt_s, hex_s⟩ := exec_ellStepStmt hctx h64 hN2 hL ht hBK
        hIdx hMpad (hRunMag t ht.le) hws hPar_t hSt_t
      have hf : runAt (t + 1) = ellStep L (padCols M_ora) d_ora (runAt t) := by
        dsimp [runAt]; rw [Fin.foldl_succ_last]
      let ws_next := hWrite ws_s 10 41 ((t : ℤ) + 1)
      have hp_cnt : PreservesOutside (fun t_id idx => t_id = 10 ∧ idx = 41) ws_s ws_next :=
        PreservesOutside.write ws_s _ ⟨rfl, rfl⟩
      refine ⟨ws_s, hex_s, ?_, ?_⟩
      · rw [hpr_s 10 41 (by omega), hctr_t]
      · refine ⟨(hpr_t.trans (hpr_s.mono (by intro t_id idx h; dsimp [mod]; omega))).trans
            (hp_cnt.mono (by intro t_id idx h; dsimp [mod]; omega)),
          (hPar_t.preserve hpr_s (by intro idx _ _; omega) (by omega) (by omega)).preserve
            hp_cnt (by intro idx _ _; omega) (by omega) (by omega), ?_⟩
        rw [hf]
        exact hSt_s.preserve hp_cnt (by omega) (by omega) (by omega))
  have htot := (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps
    (hs5.seq_steps (hs6.seq_steps (hs7.seq_steps (hs8.seq_steps
      (hs9.seq_steps (hs10.seq_steps (hs11.seq_steps hs12))))))))))).mono_steps
    (by
      dsimp [m_tot]
      have hexp_sum : (2 + 6 * E) + ((2 + (E + 1)) + ((2 + 7 * E) + (2 + B_sqrt))) ≤ 9 + 3 * B_sqrt := by
        omega
      calc 1 + (1 + (1 + ((2 + 6 * E) + ((2 + (E + 1)) + ((2 + 7 * E) + ((2 + B_sqrt) +
            (1 + (1 + ((2 + N * (1 + 1)) + ((2 + N * (2 + 3 * N + 1)) + (2 + T * (m_step + 1))))))))))))
          = 11 + ((2 + 6 * E) + ((2 + (E + 1)) + ((2 + 7 * E) + (2 + B_sqrt)))) +
              N * (5 + 3 * N) + T * (m_step + 1) := by ring
        _ ≤ 11 + (9 + 3 * B_sqrt) + N * (6 + 3 * N) + T * (m_step + 1) :=
            Nat.add_le_add_right
              (Nat.add_le_add (Nat.add_le_add_left hexp_sum 11)
                (Nat.mul_le_mul_left N (by omega))) _
        _ ≤ 30 + 3 * B_sqrt + N * (6 + 3 * N) + T * (m_step + 1) := by omega)
  have hDecEq : (hRead ws12 10 17 == 1) = ellipsoidDecide nVars m_ora L M_ora d_ora := by
    rw [hSt12.1]; rfl
  exact ⟨ws12, hpr12, hDecEq, htot⟩

end UL.Proof.cit_gls88_rational_lp.RacerCG
