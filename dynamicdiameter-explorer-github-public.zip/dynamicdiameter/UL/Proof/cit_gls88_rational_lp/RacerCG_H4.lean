import Mathlib
import UL.Def.def_A_convex_hull_cert
import UL.Stmt.cit_gls88_rational_lp
import UL.Proof.cit_gls88_rational_lp.RacerCG_H3d
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

/-! ### 1. List `flatMap` / `getD` Indexing & Input Space Bounds -/

theorem listGetIntD_nat {α : Type*} (xs : List α) (k : ℕ) (fb : α) :
    UL.listGetIntD xs (k : ℤ) fb = xs.getD k fb := by
  simp [UL.listGetIntD]

theorem list_getD_append_left {α : Type*} :
    ∀ (xs ys : List α) (k : ℕ) (fb : α), k < xs.length →
      (xs ++ ys).getD k fb = xs.getD k fb
  | [], _, _, _, hk => False.elim (Nat.not_lt_zero _ hk)
  | _ :: _, _, 0, _, _ => rfl
  | _ :: xs, ys, k + 1, fb, hk =>
      list_getD_append_left xs ys k fb (Nat.lt_of_succ_lt_succ hk)

theorem list_getD_append_add {α : Type*} :
    ∀ (xs ys : List α) (j : ℕ) (fb : α),
      (xs ++ ys).getD (xs.length + j) fb = ys.getD j fb
  | [], ys, j, fb => by simp
  | x :: xs, ys, j, fb => by
      have h : (x :: xs).length + j = (xs.length + j) + 1 := by simp; omega
      rw [List.cons_append, h, List.getD_eq_getElem?_getD, List.getElem?_cons_succ,
          ← List.getD_eq_getElem?_getD]
      exact list_getD_append_add xs ys j fb

theorem list_getD_ofFn {α : Type*} {n : ℕ} (f : Fin n → α) (j : Fin n) (fb : α) :
    (List.ofFn f).getD j.val fb = f j := by
  rw [List.getD_eq_getElem?_getD, List.getElem?_ofFn]
  simp [j.isLt]

theorem flatMap_const_length {α β : Type*} :
    ∀ (xs : List β) (rowFn : β → List α) (W : ℕ),
      (∀ x ∈ xs, (rowFn x).length = W) →
      (xs.flatMap rowFn).length = xs.length * W
  | [], _, _, _ => by simp
  | x :: xs, rowFn, W, hW => by
      simp only [List.flatMap_cons, List.length_append, List.length_cons]
      rw [hW x List.mem_cons_self,
          flatMap_const_length xs rowFn W (fun y hy => hW y (List.mem_cons_of_mem _ hy))]
      ring

theorem flatMap_const_getD {α β : Type*} :
    ∀ (xs : List β) (rowFn : β → List α) (W : ℕ) (fb : α),
      (∀ x ∈ xs, (rowFn x).length = W) →
      ∀ (k : ℕ) (hk : k < xs.length) (j : ℕ), j < W →
        (xs.flatMap rowFn).getD (k * W + j) fb = (rowFn (xs[k])).getD j fb
  | [], _, _, _, _, _, hk, _, _ => False.elim (Nat.not_lt_zero _ hk)
  | x :: xs, rowFn, W, fb, hW, 0, _, j, hj => by
      simp only [List.flatMap_cons, Nat.zero_mul, Nat.zero_add, List.getElem_cons_zero]
      exact list_getD_append_left (rowFn x) (xs.flatMap rowFn) j fb
        (by rw [hW x List.mem_cons_self]; exact hj)
  | x :: xs, rowFn, W, fb, hW, k + 1, hk, j, hj => by
      simp only [List.flatMap_cons, List.getElem_cons_succ]
      have hx : (rowFn x).length = W := hW x List.mem_cons_self
      have hidx : (k + 1) * W + j = (rowFn x).length + (k * W + j) := by rw [hx]; ring
      rw [hidx, list_getD_append_add]
      exact flatMap_const_getD xs rowFn W fb
        (fun y hy => hW y (List.mem_cons_of_mem _ hy))
        k (Nat.lt_of_succ_lt_succ hk) j hj

theorem flatMap_finRange_length {α : Type*} (m W : ℕ) (rowFn : Fin m → List α)
    (hW : ∀ i : Fin m, (rowFn i).length = W) :
    ((List.finRange m).flatMap rowFn).length = m * W := by
  rw [flatMap_const_length (List.finRange m) rowFn W (fun x _ => hW x), List.length_finRange]

theorem flatMap_finRange_getD {α : Type*} (m W : ℕ) (rowFn : Fin m → List α) (fb : α)
    (hW : ∀ i : Fin m, (rowFn i).length = W)
    (i : Fin m) {j : ℕ} (hj : j < W) :
    ((List.finRange m).flatMap rowFn).getD (i.val * W + j) fb = (rowFn i).getD j fb := by
  have hi : i.val < (List.finRange m).length := by rw [List.length_finRange]; exact i.isLt
  have h := flatMap_const_getD (List.finRange m) rowFn W fb (fun x _ => hW x) i.val hi j hj
  simpa using h

theorem list_map_sum_le {α : Type*} :
    ∀ (xs : List α) (f : α → ℕ) (M : ℕ),
      (∀ x ∈ xs, f x ≤ M) → (xs.map f).sum ≤ xs.length * M
  | [], _, _, _ => by simp
  | x :: xs, f, M, h => by
      simp only [List.map_cons, List.sum_cons, List.length_cons]
      have hx := h x List.mem_cons_self
      have hxs := list_map_sum_le xs f M (fun y hy => h y (List.mem_cons_of_mem _ hy))
      calc f x + (xs.map f).sum ≤ M + xs.length * M := Nat.add_le_add hx hxs
        _ = (xs.length + 1) * M := by ring

theorem input_ZeroDim_bounds (K : ℕ) (intParams : List ℤ) (extraRats : List ℚ)
    (hInt : ∀ z ∈ intParams, z.natAbs ≤ 2 ^ K)
    (hRat : ∀ q ∈ extraRats, q.num.natAbs ≤ 2 ^ K ∧ q.den ≤ 2 ^ K) :
    let inp : UL.BitRAMInput 0 :=
      { intParams := intParams
        activeHandles := ∅
        activeRatCoords := fun _ k => Fin.elim0 k
        extraRats := extraRats }
    InputMagBounded K inp ∧
    inp.inputCellSpace = intParams.length + 2 * extraRats.length ∧
    inp.inputBitSpace ≤ intParams.length * (K + 3) + extraRats.length * (2 * K + 6) := by
  intro inp
  refine ⟨⟨Nat.zero_le _, hInt, hRat⟩, ?_, ?_⟩
  · simp [UL.BitRAMInput.inputCellSpace, inp]
  · simp only [UL.BitRAMInput.inputBitSpace, inp, Finset.sum_empty, add_zero]
    have h1 : (intParams.map UL.intBitLength).sum ≤ intParams.length * (K + 3) :=
      list_map_sum_le intParams UL.intBitLength (K + 3)
        (fun z hz => intBitLength_le_of_natAbs_le_two_pow (hInt z hz))
    have h2 : (extraRats.map UL.ratBitLength).sum ≤ extraRats.length * (2 * K + 6) :=
      list_map_sum_le extraRats UL.ratBitLength (2 * K + 6) (fun q hq => by
        obtain ⟨hn, hd⟩ := hRat q hq
        have hb1 := intBitLength_le_of_natAbs_le_two_pow hn
        have hb2 := natBitLength_le_of_le_two_pow hd
        unfold UL.ratBitLength
        omega)
    exact Nat.add_le_add h1 h2

/-! ### 2. `Fin` Sum Splitting & `EuclideanSpace` Convex-Hull Equivalence -/

theorem sum_fin_add {α : Type*} [AddCommMonoid α] (a : ℕ) :
    ∀ (b : ℕ) (f : Fin (a + b) → α),
      (∑ v : Fin (a + b), f v) =
        (∑ i : Fin a, f ⟨i.val, by omega⟩) + (∑ j : Fin b, f ⟨a + j.val, by omega⟩)
  | 0, _ => by simp
  | b + 1, f => by
      change (∑ v : Fin ((a + b) + 1), f v) = _
      rw [Fin.sum_univ_castSucc, sum_fin_add a b (fun v => f v.castSucc),
          Fin.sum_univ_castSucc, add_assoc]
      rfl

theorem sum_fin_mul {α : Type*} [AddCommMonoid α] :
    ∀ (r s : ℕ) (f : Fin (r * s) → α),
      (∑ k : Fin (r * s), f k) =
        ∑ i : Fin r, ∑ j : Fin s, f ⟨i.val * s + j.val, row_col_lt_mul i.isLt j.isLt⟩
  | 0, s, f => by
      rw [Fin.sum_univ_zero]
      exact Finset.sum_eq_zero (fun k _ => Fin.elim0 (Fin.cast (Nat.zero_mul s) k))
  | r + 1, s, f => by
      have hs_eq : (r + 1) * s = r * s + s := Nat.succ_mul r s
      rw [← (finCongr hs_eq).symm.sum_comp]
      rw [sum_fin_add (r * s) s, sum_fin_mul r s, Fin.sum_univ_castSucc]
      congr 1

theorem euclidean_eq_iff_coords {D : ℕ} (x y : EuclideanSpace ℝ (Fin D)) :
    x = y ↔ ∀ c : Fin D, WithLp.equiv 2 (Fin D → ℝ) x c = WithLp.equiv 2 (Fin D → ℝ) y c := by
  constructor
  · rintro rfl _; rfl
  · intro h
    apply (WithLp.equiv 2 (Fin D → ℝ)).injective
    funext c
    exact h c

theorem euclidean_sum_smul_ratPoint_coord {D s : ℕ} (pts : Fin s → Fin D → ℚ)
    (w : Fin s → ℝ) (c : Fin D) :
    WithLp.equiv 2 (Fin D → ℝ) (∑ j : Fin s, w j • UL.ratPointToEuclidean (pts j)) c =
      ∑ j : Fin s, (pts j c : ℝ) * w j := by
  induction s with
  | zero => simp
  | succ s ih =>
      rw [Fin.sum_univ_castSucc, Fin.sum_univ_castSucc]
      change (WithLp.equiv 2 (Fin D → ℝ) (∑ j : Fin s, w j.castSucc • UL.ratPointToEuclidean (pts j.castSucc)) c) +
          w (Fin.last s) * (WithLp.equiv 2 (Fin D → ℝ) (UL.ratPointToEuclidean (pts (Fin.last s))) c) = _
      rw [ih (fun j => pts j.castSucc) (fun j => w j.castSucc)]
      dsimp [UL.ratPointToEuclidean]
      ring

theorem isConvexHullCert_rat_iff {D s : ℕ} (pts : Fin s → Fin D → ℚ)
    (z : EuclideanSpace ℝ (Fin D)) (w : Fin s → ℝ) :
    UL.IsConvexHullCert (fun j => UL.ratPointToEuclidean (pts j)) z w ↔
      (∀ j : Fin s, 0 ≤ w j) ∧
      (∑ j : Fin s, w j = 1) ∧
      (∀ c : Fin D, ∑ j : Fin s, (pts j c : ℝ) * w j = WithLp.equiv 2 (Fin D → ℝ) z c) := by
  unfold UL.IsConvexHullCert
  rw [euclidean_eq_iff_coords]
  simp only [euclidean_sum_smul_ratPoint_coord]

/-! ### 3. Polynomial Resource Bound Combinator -/

theorem poly_solver_bounds (nVars nEq nLe B : ℕ) (m_extra lenInt lenRat : ℕ)
    (hm_extra : m_extra ≤ 40 * (nVars + nEq + nLe + 1) ^ 2)
    (hlenInt : lenInt ≤ 4)
    (hlenRat : lenRat ≤ 4 * (nVars + nEq + nLe + 1) ^ 2) :
    let B' := max B 1
    let maxIdx := solverMaxIdx nVars nEq nLe
    let K := solverK nVars nEq nLe B'
    let M_tot := m_extra + solverStepBound nVars nEq nLe B' + (10 + 4 * nVars)
    let S := nVars + nEq + nLe + B + 1
    let bound := (10 ^ 26) * S ^ 22
    M_tot * stepU ≤ bound ∧
    M_tot * stepB K ≤ bound ∧
    (lenInt + 2 * lenRat + 32 * (maxIdx + 1)) ≤ bound ∧
    (lenInt * (K + 3) + lenRat * (2 * K + 6) + 32 * (maxIdx + 1) * (2 * K + 14)) ≤ bound ∧
    2 * K + 5 ≤ bound := by
  intro B' maxIdx K M_tot S₀ bound
  dsimp only [bound]
  suffices ∀ (S : ℕ), S = nVars + nEq + nLe + B + 1 →
      M_tot * stepU ≤ (10 ^ 26) * S ^ 22 ∧
      M_tot * stepB K ≤ (10 ^ 26) * S ^ 22 ∧
      (lenInt + 2 * lenRat + 32 * (maxIdx + 1)) ≤ (10 ^ 26) * S ^ 22 ∧
      (lenInt * (K + 3) + lenRat * (2 * K + 6) + 32 * (maxIdx + 1) * (2 * K + 14)) ≤ (10 ^ 26) * S ^ 22 ∧
      2 * K + 5 ≤ (10 ^ 26) * S ^ 22 from
    this S₀ rfl
  intro S hS_def
  have hS1 : 1 ≤ S := by omega
  have spow_mono : ∀ {a b : ℕ}, a ≤ b → S ^ a ≤ S ^ b :=
    fun h => Nat.pow_le_pow_right hS1 h
  have h1S : ∀ k : ℕ, 1 ≤ S ^ k := fun k => Nat.one_le_pow k S hS1
  have hSS : ∀ {k : ℕ}, 1 ≤ k → S ≤ S ^ k := fun hk => by
    simpa only [pow_one] using spow_mono hk
  have hB'_le : B' ≤ S := by dsimp [B']; omega
  have hSub_le : nVars + nEq + nLe + 1 ≤ S := by omega
  have hN_le : nVars + 2 ≤ 2 * S := by omega
  have hmOra_le : 2 * nEq + 2 * nLe ≤ 2 * S := by omega
  have hmBar_le : nEq + nLe ≤ S := by omega
  let B_int := B' * (nVars + 2)
  have hBint_le : B_int ≤ 2 * S ^ 2 := by
    calc B' * (nVars + 2) ≤ S * (2 * S) := Nat.mul_le_mul hB'_le hN_le
      _ = 2 * S ^ 2 := by ring
  have hE_le : ellParamE (nVars + 2) B_int ≤ 24 * S ^ 3 := by
    dsimp [ellParamE]
    have h1 : nVars + 2 + 2 ≤ 4 * S := by omega
    have h2 : nVars + 2 + 2 + B_int ≤ 6 * S ^ 2 := by
      have h1a : nVars + 2 + 2 ≤ 4 * S ^ 2 := h1.trans (Nat.mul_le_mul_left 4 (hSS (by decide)))
      omega
    calc (nVars + 2 + 2) * (nVars + 2 + 2 + B_int) ≤ (4 * S) * (6 * S ^ 2) := Nat.mul_le_mul h1 h2
      _ = 24 * S ^ 3 := by ring
  have hT_le : ellParamT (nVars + 2) B_int ≤ 4600 * S ^ 5 := by
    dsimp [ellParamT]
    have h1 : 10 * (nVars + 2 + 1) * (nVars + 2) ≤ 60 * S ^ 2 := by
      have ha : nVars + 2 + 1 ≤ 3 * S := by omega
      calc 10 * (nVars + 2 + 1) * (nVars + 2) ≤ 10 * (3 * S) * (2 * S) :=
            Nat.mul_le_mul (Nat.mul_le_mul_left 10 ha) hN_le
        _ = 60 * S ^ 2 := by ring
    have h2 : 3 * ellParamE (nVars + 2) B_int + (nVars + 2) + 2 ≤ 76 * S ^ 3 := by
      have hb : nVars + 2 + 2 ≤ 4 * S ^ 3 :=
        (by omega : nVars + 2 + 2 ≤ 4 * S).trans (Nat.mul_le_mul_left 4 (hSS (by decide)))
      omega
    have h3 : 1 ≤ 40 * S ^ 5 := le_trans (h1S 5) (by have := h1S 5; omega)
    calc 10 * (nVars + 2 + 1) * (nVars + 2) * (3 * ellParamE (nVars + 2) B_int + (nVars + 2) + 2) + 1
        ≤ (60 * S ^ 2) * (76 * S ^ 3) + 40 * S ^ 5 := Nat.add_le_add (Nat.mul_le_mul h1 h2) h3
      _ = 4600 * S ^ 5 := by ring
  have hBsqrt_le : ellParamBsqrt (nVars + 2) B_int ≤ 9500 * S ^ 5 := by
    dsimp [ellParamBsqrt]
    have hE5 : ellParamE (nVars + 2) B_int ≤ 24 * S ^ 5 :=
      hE_le.trans (Nat.mul_le_mul_left 24 (spow_mono (by decide)))
    omega
  have hK_le : K ≤ 48000 * S ^ 5 := by
    dsimp [K, solverK]
    have h20 : 20 * (nVars + nEq + nLe + 4) ≤ 80 * S ^ 5 :=
      (by omega : 20 * (nVars + nEq + nLe + 4) ≤ 80 * S).trans
        (Nat.mul_le_mul_left 80 (hSS (by decide)))
    change 5 * ellParamBsqrt (nVars + 2) B_int + 20 * (nVars + nEq + nLe + 4) ≤ 48000 * S ^ 5
    omega
  have hMaxIdx1_le : maxIdx + 1 ≤ 200 * S ^ 2 := by
    dsimp [maxIdx, solverMaxIdx]
    have h1 : nVars + nEq + nLe + 4 ≤ 4 * S := by omega
    have h2 : (nVars + nEq + nLe + 4) ^ 2 ≤ 16 * S ^ 2 := by
      calc (nVars + nEq + nLe + 4) ^ 2 ≤ (4 * S) ^ 2 := Nat.pow_le_pow_left h1 2
        _ = 16 * S ^ 2 := by ring
    have h65 := h1S 2
    omega
  have hEll_le : ellStepBound nVars nEq nLe B_int ≤ 200000000 * S ^ 10 := by
    dsimp [ellStepBound]
    let m_step := 40 + (2 * nEq + 2 * nLe) * (6 + 2 * (nVars + 2)) +
      4 * ellParamBsqrt (nVars + 2) B_int + (nVars + 2) * (23 + 10 * (nVars + 2))
    have hm_step : m_step + 1 ≤ 40000 * S ^ 5 := by
      dsimp [m_step]
      have ha : (2 * nEq + 2 * nLe) * (6 + 2 * (nVars + 2)) ≤ 20 * S ^ 5 := by
        have ht1 : 6 + 2 * (nVars + 2) ≤ 10 * S := by omega
        have ht2 : (2 * nEq + 2 * nLe) * (6 + 2 * (nVars + 2)) ≤ 20 * S ^ 2 := by
          calc (2 * nEq + 2 * nLe) * (6 + 2 * (nVars + 2)) ≤ (2 * S) * (10 * S) := Nat.mul_le_mul hmOra_le ht1
            _ = 20 * S ^ 2 := by ring
        exact ht2.trans (Nat.mul_le_mul_left 20 (spow_mono (by decide)))
      have hb : (nVars + 2) * (23 + 10 * (nVars + 2)) ≤ 86 * S ^ 5 := by
        have ht1 : 23 + 10 * (nVars + 2) ≤ 43 * S := by omega
        have ht2 : (nVars + 2) * (23 + 10 * (nVars + 2)) ≤ 86 * S ^ 2 := by
          calc (nVars + 2) * (23 + 10 * (nVars + 2)) ≤ (2 * S) * (43 * S) := Nat.mul_le_mul hN_le ht1
            _ = 86 * S ^ 2 := by ring
        exact ht2.trans (Nat.mul_le_mul_left 86 (spow_mono (by decide)))
      have hc := h1S 5
      omega
    have hinit : 30 + 3 * ellParamBsqrt (nVars + 2) B_int + (nVars + 2) * (6 + 3 * (nVars + 2)) ≤
        30000 * S ^ 10 := by
      have hc : (nVars + 2) * (6 + 3 * (nVars + 2)) ≤ 24 * S ^ 10 := by
        have ht1 : 6 + 3 * (nVars + 2) ≤ 12 * S := by omega
        have ht2 : (nVars + 2) * (6 + 3 * (nVars + 2)) ≤ 24 * S ^ 2 := by
          calc (nVars + 2) * (6 + 3 * (nVars + 2)) ≤ (2 * S) * (12 * S) := Nat.mul_le_mul hN_le ht1
            _ = 24 * S ^ 2 := by ring
        exact ht2.trans (Nat.mul_le_mul_left 24 (spow_mono (by decide)))
      have hBs10 : ellParamBsqrt (nVars + 2) B_int ≤ 9500 * S ^ 10 :=
        hBsqrt_le.trans (Nat.mul_le_mul_left 9500 (spow_mono (by decide)))
      have hd := h1S 10
      omega
    have hprod : ellParamT (nVars + 2) B_int * (m_step + 1) ≤ 184000000 * S ^ 10 := by
      calc ellParamT (nVars + 2) B_int * (m_step + 1)
          ≤ (4600 * S ^ 5) * (40000 * S ^ 5) := Nat.mul_le_mul hT_le hm_step
        _ = 184000000 * S ^ 10 := by ring
    dsimp [m_step] at hprod
    omega
  have hMtot_le : M_tot ≤ 500000000 * S ^ 11 := by
    dsimp [M_tot, solverStepBound, coreStepBound]
    have hex : m_extra ≤ 40 * S ^ 11 :=
      (hm_extra.trans (Nat.mul_le_mul_left 40 (Nat.pow_le_pow_left hSub_le 2))).trans
        (Nat.mul_le_mul_left 40 (spow_mono (by decide)))
    have h_ora_b : 10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars) ≤ 30 * S ^ 2 := by
      have ht1 : 8 + 2 * nVars ≤ 10 * S := by omega
      have hp : (2 * nEq + 2 * nLe) * (8 + 2 * nVars) ≤ 20 * S ^ 2 := by
        calc (2 * nEq + 2 * nLe) * (8 + 2 * nVars) ≤ (2 * S) * (10 * S) := Nat.mul_le_mul hmOra_le ht1
          _ = 20 * S ^ 2 := by ring
      have hc := h1S 2
      omega
    have h_ora_11 : 10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars) ≤ 30 * S ^ 11 :=
      h_ora_b.trans (Nat.mul_le_mul_left 30 (spow_mono (by decide)))
    have h_iter : 8 + 4 * nLe + (10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars)) +
        ellStepBound nVars nEq nLe B_int + 1 ≤ 200000100 * S ^ 10 := by
      have hnL10 : nLe ≤ S ^ 10 := (by omega : nLe ≤ S).trans (hSS (by decide))
      have hora10 : 10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars) ≤ 30 * S ^ 10 :=
        h_ora_b.trans (Nat.mul_le_mul_left 30 (spow_mono (by decide)))
      have hc := h1S 10
      omega
    have h_act_tot : nLe * (8 + 4 * nLe + (10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars)) +
        ellStepBound nVars nEq nLe B_int + 1) ≤ 200000100 * S ^ 11 := by
      have hnL1 : nLe ≤ S := by omega
      calc nLe * _ ≤ S * (200000100 * S ^ 10) := Nat.mul_le_mul hnL1 h_iter
        _ = 200000100 * S ^ 11 := by ring
    have h_bar_col : 15 + (nEq + nLe) * (12 + 5 * (nVars + 1)) + 7 ≤ 40 * S ^ 2 := by
      have ht1 : 12 + 5 * (nVars + 1) ≤ 17 * S := by omega
      have hp : (nEq + nLe) * (12 + 5 * (nVars + 1)) ≤ 17 * S ^ 2 := by
        calc (nEq + nLe) * (12 + 5 * (nVars + 1)) ≤ S * (17 * S) := Nat.mul_le_mul hmBar_le ht1
          _ = 17 * S ^ 2 := by ring
      have hc := h1S 2
      omega
    have h_bar_tot : 10 + nVars * (15 + (nEq + nLe) * (12 + 5 * (nVars + 1)) + 7) ≤ 50 * S ^ 11 := by
      have hnV1 : nVars ≤ S := by omega
      have hp : nVars * (15 + (nEq + nLe) * (12 + 5 * (nVars + 1)) + 7) ≤ 40 * S ^ 3 := by
        calc nVars * _ ≤ S * (40 * S ^ 2) := Nat.mul_le_mul hnV1 h_bar_col
          _ = 40 * S ^ 3 := by ring
      have hp3 : 10 + nVars * (15 + (nEq + nLe) * (12 + 5 * (nVars + 1)) + 7) ≤ 50 * S ^ 3 := by
        have hc := h1S 3; omega
      exact hp3.trans (Nat.mul_le_mul_left 50 (spow_mono (by decide)))
    have h94 : (nEq + nLe) * (9 + 4 * nVars) ≤ 13 * S ^ 11 := by
      have ht1 : 9 + 4 * nVars ≤ 13 * S := by omega
      have ht2 : (nEq + nLe) * (9 + 4 * nVars) ≤ 13 * S ^ 2 := by
        calc (nEq + nLe) * (9 + 4 * nVars) ≤ S * (13 * S) := Nat.mul_le_mul hmBar_le ht1
          _ = 13 * S ^ 2 := by ring
      exact ht2.trans (Nat.mul_le_mul_left 13 (spow_mono (by decide)))
    have h75 : (nEq + nLe) * (7 + 5 * nVars) ≤ 12 * S ^ 11 := by
      have ht1 : 7 + 5 * nVars ≤ 12 * S := by omega
      have ht2 : (nEq + nLe) * (7 + 5 * nVars) ≤ 12 * S ^ 2 := by
        calc (nEq + nLe) * (7 + 5 * nVars) ≤ S * (12 * S) := Nat.mul_le_mul hmBar_le ht1
          _ = 12 * S ^ 2 := by ring
      exact ht2.trans (Nat.mul_le_mul_left 12 (spow_mono (by decide)))
    have h62 : (nEq + nLe) * (6 + 2 * nVars) ≤ 8 * S ^ 11 := by
      have ht1 : 6 + 2 * nVars ≤ 8 * S := by omega
      have ht2 : (nEq + nLe) * (6 + 2 * nVars) ≤ 8 * S ^ 2 := by
        calc (nEq + nLe) * (6 + 2 * nVars) ≤ S * (8 * S) := Nat.mul_le_mul hmBar_le ht1
          _ = 8 * S ^ 2 := by ring
      exact ht2.trans (Nat.mul_le_mul_left 8 (spow_mono (by decide)))
    have hBint11 : B_int ≤ 2 * S ^ 11 := hBint_le.trans (Nat.mul_le_mul_left 2 (spow_mono (by decide)))
    have hEll11 : ellStepBound nVars nEq nLe B_int ≤ 200000000 * S ^ 11 :=
      hEll_le.trans (Nat.mul_le_mul_left 200000000 (spow_mono (by decide)))
    have hnL11 : nLe ≤ S ^ 11 := (by omega : nLe ≤ S).trans (hSS (by decide))
    have hnV11 : nVars ≤ S ^ 11 := (by omega : nVars ≤ S).trans (hSS (by decide))
    have hc11 := h1S 11
    change m_extra + ((4 + (nEq + nLe) * (9 + 4 * nVars)) +
      (30 + (nEq + nLe) * (7 + 5 * nVars) + 3 * B_int + 2 * nLe +
        (10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars)) + ellStepBound nVars nEq nLe B_int +
        nLe * (8 + 4 * nLe + (10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars)) +
          ellStepBound nVars nEq nLe B_int + 1) +
        (10 + (nEq + nLe) * (6 + 2 * nVars) + 2 * nVars) +
        (10 + nVars * (15 + (nEq + nLe) * (12 + 5 * (nVars + 1)) + 7)) + 3 * nVars)) +
      (10 + 4 * nVars) ≤ 500000000 * S ^ 11
    omega
  have hlenRat_S : lenRat ≤ 4 * S ^ 2 :=
    hlenRat.trans (Nat.mul_le_mul_left 4 (Nat.pow_le_pow_left hSub_le 2))
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · dsimp [stepU]
    have hs := spow_mono (a := 11) (b := 22) (by decide)
    calc M_tot * 100 ≤ (500000000 * S ^ 11) * 100 := Nat.mul_le_mul_right 100 hMtot_le
      _ = 50000000000 * S ^ 11 := by ring
      _ ≤ 10 ^ 26 * S ^ 11 := Nat.mul_le_mul_right _ (by norm_num)
      _ ≤ 10 ^ 26 * S ^ 22 := Nat.mul_le_mul_left _ hs
  · dsimp [stepB]
    have hK2 : K ^ 2 ≤ 2304000000 * S ^ 10 := by
      calc K ^ 2 ≤ (48000 * S ^ 5) ^ 2 := Nat.pow_le_pow_left hK_le 2
        _ = 2304000000 * S ^ 10 := by ring
    have hs := spow_mono (a := 21) (b := 22) (by decide)
    calc M_tot * (2000000 * K ^ 2)
        ≤ (500000000 * S ^ 11) * (2000000 * (2304000000 * S ^ 10)) :=
          Nat.mul_le_mul hMtot_le (Nat.mul_le_mul_left 2000000 hK2)
      _ = 2304000000000000000000000 * S ^ 21 := by ring
      _ ≤ 10 ^ 26 * S ^ 21 := Nat.mul_le_mul_right _ (by norm_num)
      _ ≤ 10 ^ 26 * S ^ 22 := Nat.mul_le_mul_left _ hs
  · have hc2 := h1S 2
    have hs2 := spow_mono (a := 2) (b := 22) (by decide)
    have h1 : lenInt + 2 * lenRat + 32 * (maxIdx + 1) ≤ 7000 * S ^ 2 := by omega
    calc lenInt + 2 * lenRat + 32 * (maxIdx + 1) ≤ 7000 * S ^ 2 := h1
      _ ≤ 10 ^ 26 * S ^ 2 := Nat.mul_le_mul_right _ (by norm_num)
      _ ≤ 10 ^ 26 * S ^ 22 := Nat.mul_le_mul_left _ hs2
  · have hc5 := h1S 5
    have h2K14 : 2 * K + 14 ≤ 100000 * S ^ 5 := by omega
    have hK3 : K + 3 ≤ 50000 * S ^ 5 := by omega
    have hterm1 : lenInt * (K + 3) ≤ 200000 * S ^ 7 := by
      calc lenInt * (K + 3) ≤ 4 * (50000 * S ^ 5) := Nat.mul_le_mul hlenInt hK3
        _ = 200000 * S ^ 5 := by ring
        _ ≤ 200000 * S ^ 7 := Nat.mul_le_mul_left 200000 (spow_mono (by decide))
    have hterm2 : lenRat * (2 * K + 6) ≤ 400000 * S ^ 7 := by
      have h2K6 : 2 * K + 6 ≤ 100000 * S ^ 5 := by omega
      calc lenRat * (2 * K + 6) ≤ (4 * S ^ 2) * (100000 * S ^ 5) := Nat.mul_le_mul hlenRat_S h2K6
        _ = 400000 * S ^ 7 := by ring
    have hterm3 : 32 * (maxIdx + 1) * (2 * K + 14) ≤ 640000000 * S ^ 7 := by
      calc 32 * (maxIdx + 1) * (2 * K + 14)
          ≤ (32 * (200 * S ^ 2)) * (100000 * S ^ 5) :=
            Nat.mul_le_mul (Nat.mul_le_mul_left 32 hMaxIdx1_le) h2K14
        _ = 640000000 * S ^ 7 := by ring
    have hs722 := spow_mono (a := 7) (b := 22) (by decide)
    have hsum : lenInt * (K + 3) + lenRat * (2 * K + 6) + 32 * (maxIdx + 1) * (2 * K + 14) ≤
        700000000 * S ^ 7 := by omega
    calc lenInt * (K + 3) + lenRat * (2 * K + 6) + 32 * (maxIdx + 1) * (2 * K + 14)
        ≤ 700000000 * S ^ 7 := hsum
      _ ≤ 10 ^ 26 * S ^ 7 := Nat.mul_le_mul_right _ (by norm_num)
      _ ≤ 10 ^ 26 * S ^ 22 := Nat.mul_le_mul_left _ hs722
  · have hc5 := h1S 5
    have hs522 := spow_mono (a := 5) (b := 22) (by decide)
    have h1 : 2 * K + 5 ≤ 100000 * S ^ 5 := by omega
    calc 2 * K + 5 ≤ 100000 * S ^ 5 := h1
      _ ≤ 10 ^ 26 * S ^ 5 := Nat.mul_le_mul_right _ (by norm_num)
      _ ≤ 10 ^ 26 * S ^ 22 := Nat.mul_le_mul_left _ hs522

private theorem rat_sum_eq_to_real {n : ℕ} (c x : Fin n → ℚ) (rhs : ℚ)
    (h : ∑ v : Fin n, c v * x v = rhs) :
    ∑ v : Fin n, (c v : ℝ) * (x v : ℝ) = (rhs : ℝ) := by
  exact_mod_cast h

private theorem rat_sum_le_to_real {n : ℕ} (c x : Fin n → ℚ) (rhs : ℚ)
    (h : ∑ v : Fin n, c v * x v ≤ rhs) :
    ∑ v : Fin n, (c v : ℝ) * (x v : ℝ) ≤ (rhs : ℝ) := by
  exact_mod_cast h

private theorem scale_pow22_two (P : ℕ) :
    10 ^ 26 * (2 * P) ^ 22 ≤ 10 ^ 34 * P ^ 22 := by
  rw [mul_pow, ← mul_assoc]
  exact Nat.mul_le_mul_right (P ^ 22) (by norm_num)

private theorem scale_pow22_six_sq (P : ℕ) :
    10 ^ 26 * (6 * P ^ 2) ^ 22 ≤ 10 ^ 45 * P ^ 44 := by
  rw [mul_pow, ← pow_mul, ← mul_assoc]
  exact Nat.mul_le_mul_right (P ^ 44) (by norm_num)

private theorem cert_scale_bound (D s B : ℕ) :
    10 ^ 26 * (s + (D + 1) + s + B + 1) ^ 22 ≤ 10 ^ 34 * (D + s + B + 1) ^ 22 := by
  have hSP : s + (D + 1) + s + B + 1 ≤ 2 * (D + s + B + 1) := by omega
  exact (Nat.mul_le_mul_left (10 ^ 26) (Nat.pow_le_pow_left hSP 22)).trans
    (scale_pow22_two (D + s + B + 1))

private theorem hull_scale_bound (D r s B : ℕ) :
    10 ^ 26 * ((D + r * s) + (r * D + r) + r * s + B + 1) ^ 22 ≤
      10 ^ 45 * (D + r + s + B + 1) ^ 44 := by
  generalize hP : D + r + s + B + 1 = P
  have hP1 : 1 ≤ P := by omega
  have hrs : r * s ≤ P ^ 2 := by
    calc r * s ≤ P * P := Nat.mul_le_mul (by omega) (by omega)
      _ = P ^ 2 := (sq P).symm
  have hrD : r * D ≤ P ^ 2 := by
    calc r * D ≤ P * P := Nat.mul_le_mul (by omega) (by omega)
      _ = P ^ 2 := (sq P).symm
  have hlin : D + r + B + 1 ≤ P ^ 2 := by
    calc D + r + B + 1 ≤ P * 1 := by omega
      _ ≤ P * P := Nat.mul_le_mul_left P hP1
      _ = P ^ 2 := (sq P).symm
  have hSP : (D + r * s) + (r * D + r) + r * s + B + 1 ≤ 6 * P ^ 2 := by omega
  exact (Nat.mul_le_mul_left (10 ^ 26) (Nat.pow_le_pow_left hSP 22)).trans
    (scale_pow22_six_sq P)

/-! ### 4. Shared Adapter Gadgets (`writeDimsStmt`, `copyVecOutStmt`, `zeroInitRatBlockStmt`) -/

def writeDimsStmt (nVarsE nEqE nLeE : UL.IntExpr) : UL.BitRAMStmt :=
  seqBitStmts
    [ .writeHeap 10 (.lit 0) nVarsE
    , .writeHeap 10 (.lit 1) nEqE
    , .writeHeap 10 (.lit 2) nLeE
    , .writeHeap 10 (.lit 3) (.add (.readHeap 10 (.lit 0)) (.lit 2))
    , .writeHeap 10 (.lit 4) (.add (.mul (.lit 2) (.readHeap 10 (.lit 1)))
                                   (.mul (.lit 2) (.readHeap 10 (.lit 2))))
    , .writeHeap 10 (.lit 5) (.add (.readHeap 10 (.lit 1)) (.readHeap 10 (.lit 2))) ]

theorem exec_writeDimsStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars + 2 ≤ maxIdx ∧ 2 * nEq + 2 * nLe ≤ maxIdx)
    (nVarsE nEqE nLeE : UL.IntExpr)
    (hwfV : exprWf 31 nVarsE = true) (hwfE : exprWf 31 nEqE = true) (hwfL : exprWf 31 nLeE = true)
    (hszV : exprNodes nVarsE ≤ 20 ∧ exprLeaves nVarsE ≤ 20)
    (hszE : exprNodes nEqE ≤ 20 ∧ exprLeaves nEqE ≤ 20)
    (hszL : exprNodes nLeE ≤ 20 ∧ exprLeaves nLeE ≤ 20)
    (hV : ∀ ws, evalVal inp ws nVarsE = (nVars : ℤ))
    (hE : ∀ ws, evalVal inp ws nEqE = (nEq : ℤ))
    (hL : ∀ ws, evalVal inp ws nLeE = (nLe : ℤ))
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀) :
    ∃ ws₁ : UL.WordStore,
      DimsInHeap nVars nEq nLe ws₁ ∧
      ExecBit inp maxIdx K (writeDimsStmt nVarsE nEqE nLeE) ws₀ ws₁ (6 * stepU) (6 * stepB K) := by
  have hbV : (nVars : ℤ).natAbs ≤ 2 ^ K := by
    have : nVars ≤ maxIdx := (Nat.le_add_right nVars 2).trans hIdx.1
    simpa using this.trans hctx.hMaxIdx
  have hbE : (nEq : ℤ).natAbs ≤ 2 ^ K := by
    have : nEq ≤ maxIdx := (by omega : nEq ≤ 2 * nEq + 2 * nLe).trans hIdx.2
    simpa using this.trans hctx.hMaxIdx
  have hbL : (nLe : ℤ).natAbs ≤ 2 ^ K := by
    have : nLe ≤ maxIdx := (by omega : nLe ≤ 2 * nEq + 2 * nLe).trans hIdx.2
    simpa using this.trans hctx.hMaxIdx
  have hbN : ((nVars + 2 : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
    simpa using hIdx.1.trans hctx.hMaxIdx
  have hbmO : ((2 * nEq + 2 * nLe : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
    simpa using hIdx.2.trans hctx.hMaxIdx
  have hbmB : ((nEq + nLe : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
    have : nEq + nLe ≤ maxIdx := (by omega : nEq + nLe ≤ 2 * nEq + 2 * nLe).trans hIdx.2
    simpa using this.trans hctx.hMaxIdx
  have hs0 := exec_write hctx hws₀ 10 (.lit 0) nVarsE 0 (nVars : ℤ) rfl (hV ws₀)
    (by omega) (by omega) hbV (by decide) (by decide) hwfV
    (by dsimp [exprNodes, exprLeaves]; omega)
  let ws1 := hWrite ws₀ 10 0 (nVars : ℤ); have hws1 : StoreBounded 31 maxIdx K ws1 := hs0.2.1
  have hs1 := exec_write hctx hws1 10 (.lit 1) nEqE 1 (nEq : ℤ) rfl (hE ws1)
    (by omega) (by omega) hbE (by decide) (by decide) hwfE
    (by dsimp [exprNodes, exprLeaves]; omega)
  let ws2 := hWrite ws1 10 1 (nEq : ℤ); have hws2 : StoreBounded 31 maxIdx K ws2 := hs1.2.1
  have hs2 := exec_write hctx hws2 10 (.lit 2) nLeE 2 (nLe : ℤ) rfl (hL ws2)
    (by omega) (by omega) hbL (by decide) (by decide) hwfL
    (by dsimp [exprNodes, exprLeaves]; omega)
  let ws3 := hWrite ws2 10 2 (nLe : ℤ); have hws3 : StoreBounded 31 maxIdx K ws3 := hs2.2.1
  have h0_3 : hRead ws3 10 0 = (nVars : ℤ) := by
    rw [hRead_hWrite_of_ne ws2 _ (Or.inr (by omega)),
        hRead_hWrite_of_ne ws1 _ (Or.inr (by omega)), hRead_hWrite_self]
  have hs3 := exec_write hctx hws3 10 (.lit 3) (.add (.readHeap 10 (.lit 0)) (.lit 2))
    3 ((nVars + 2 : ℕ) : ℤ) rfl
    (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, h0_3]
        exact_mod_cast (rfl : nVars + 2 = nVars + 2))
    (by omega) (by omega) hbN
  let ws4 := hWrite ws3 10 3 ((nVars + 2 : ℕ) : ℤ); have hws4 : StoreBounded 31 maxIdx K ws4 := hs3.2.1
  have h1_4 : hRead ws4 10 1 = (nEq : ℤ) := by
    rw [hRead_hWrite_of_ne ws3 _ (Or.inr (by omega)),
        hRead_hWrite_of_ne ws2 _ (Or.inr (by omega)), hRead_hWrite_self]
  have h2_4 : hRead ws4 10 2 = (nLe : ℤ) := by
    rw [hRead_hWrite_of_ne ws3 _ (Or.inr (by omega)), hRead_hWrite_self]
  have hs4 := exec_write hctx hws4 10 (.lit 4)
    (.add (.mul (.lit 2) (.readHeap 10 (.lit 1))) (.mul (.lit 2) (.readHeap 10 (.lit 2))))
    4 ((2 * nEq + 2 * nLe : ℕ) : ℤ) rfl
    (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, h1_4, h2_4]
        exact_mod_cast (rfl : 2 * nEq + 2 * nLe = 2 * nEq + 2 * nLe))
    (by omega) (by omega) hbmO
  let ws5 := hWrite ws4 10 4 ((2 * nEq + 2 * nLe : ℕ) : ℤ); have hws5 : StoreBounded 31 maxIdx K ws5 := hs4.2.1
  have h1_5 : hRead ws5 10 1 = (nEq : ℤ) := by
    rw [hRead_hWrite_of_ne ws4 _ (Or.inr (by omega)), h1_4]
  have h2_5 : hRead ws5 10 2 = (nLe : ℤ) := by
    rw [hRead_hWrite_of_ne ws4 _ (Or.inr (by omega)), h2_4]
  have hs5 := exec_write hctx hws5 10 (.lit 5)
    (.add (.readHeap 10 (.lit 1)) (.readHeap 10 (.lit 2)))
    5 ((nEq + nLe : ℕ) : ℤ) rfl
    (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, h1_5, h2_5]
        exact_mod_cast (rfl : nEq + nLe = nEq + nLe))
    (by omega) (by omega) hbmB
  let ws6 := hWrite ws5 10 5 ((nEq + nLe : ℕ) : ℤ)
  refine ⟨ws6, ⟨?_, ?_, ?_, ?_, ?_, hRead_hWrite_self ws5 10 5 _⟩,
    (hs0.seq_steps (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps hs5))))).mono_steps le_rfl⟩
  · rw [hRead_hWrite_of_ne ws5 _ (Or.inr (by omega)),
        hRead_hWrite_of_ne ws4 _ (Or.inr (by omega)),
        hRead_hWrite_of_ne ws3 _ (Or.inr (by omega)), h0_3]
  · rw [hRead_hWrite_of_ne ws5 _ (Or.inr (by omega)), h1_5]
  · rw [hRead_hWrite_of_ne ws5 _ (Or.inr (by omega)), h2_5]
  · rw [hRead_hWrite_of_ne ws5 _ (Or.inr (by omega)),
        hRead_hWrite_of_ne ws4 _ (Or.inr (by omega)), hRead_hWrite_self]
  · rw [hRead_hWrite_of_ne ws5 _ (Or.inr (by omega)), hRead_hWrite_self]

def copyVecOutStmt (dstT : ℕ) (countE srcOffE : UL.IntExpr) : UL.BitRAMStmt :=
  let kE := UL.IntExpr.readHeap 10 (.lit 42)
  let srcPairE := UL.IntExpr.mul (.lit 2) (.add srcOffE kE)
  forLoopStmt 42 countE
    (seqBitStmts
      [ .writeHeap dstT (.mul (.lit 2) kE) (.readHeap 31 srcPairE)
      , .writeHeap dstT (.add (.mul (.lit 2) kE) (.lit 1)) (.readHeap 31 (.add srcPairE (.lit 1))) ])

theorem exec_copyVecOutStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars count srcOff maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hOffCount : srcOff + count ≤ nVars)
    (h2nV : 2 * nVars ≤ maxIdx)
    (dstT : ℕ) (hdstT : dstT = 1 ∨ dstT = 2)
    (countE srcOffE : UL.IntExpr)
    (hwfC : exprWf 31 countE = true) (hwfO : exprWf 31 srcOffE = true)
    (hszC : exprNodes countE ≤ 16 ∧ exprLeaves countE ≤ 16)
    (hszO : exprNodes srcOffE ≤ 16 ∧ exprLeaves srcOffE ≤ 16)
    (hC : ∀ ws, evalVal inp ws countE = (count : ℤ))
    (hO : ∀ ws, evalVal inp ws srcOffE = (srcOff : ℤ))
    (solNum solDen : Fin nVars → ℤ)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (h31_ws : ∀ j : Fin nVars,
      hRead ws₀ 31 (2 * (j.val : ℤ)) = solNum j ∧
      hRead ws₀ 31 (2 * (j.val : ℤ) + 1) = solDen j) :
    let mod : ℕ → ℤ → Prop := fun t_id idx => (t_id = 10 ∧ idx = 42) ∨ t_id = dstT
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ k : Fin count,
        hRead ws₁ dstT (2 * (k.val : ℤ)) = solNum ⟨srcOff + k.val, by omega⟩ ∧
        hRead ws₁ dstT (2 * (k.val : ℤ) + 1) = solDen ⟨srcOff + k.val, by omega⟩) ∧
      ExecBit inp maxIdx K (copyVecOutStmt dstT countE srcOffE) ws₀ ws₁
        ((2 + 3 * count) * stepU) ((2 + 3 * count) * stepB K) := by
  intro mod
  have hdst_le31 : dstT ≤ 31 := by omega
  have hdst_ne10 : dstT ≠ 10 := by omega
  have hdst_ne31 : dstT ≠ 31 := by omega
  have hcnt_le : count ≤ maxIdx := by omega
  let P : ℕ → UL.WordStore → Prop := fun C ws =>
    ∀ k : Fin count, k.val < C →
      hRead ws dstT (2 * (k.val : ℤ)) = solNum ⟨srcOff + k.val, by omega⟩ ∧
      hRead ws dstT (2 * (k.val : ℤ) + 1) = solDen ⟨srcOff + k.val, by omega⟩
  obtain ⟨ws₁, hpr₁, hDone₁, hex₁⟩ := exec_for_frame hctx 42 countE
    (seqBitStmts
      [ .writeHeap dstT (.mul (.lit 2) (.readHeap 10 (.lit 42)))
          (.readHeap 31 (.mul (.lit 2) (.add srcOffE (.readHeap 10 (.lit 42)))))
      , .writeHeap dstT (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1))
          (.readHeap 31 (.add (.mul (.lit 2) (.add srcOffE (.readHeap 10 (.lit 42)))) (.lit 1))) ])
    count 2 mod P hws₀ (by omega) hcnt_le
    (by dsimp [mod]; omega)
    (fun C ws v => by
      dsimp [P]; constructor <;> intro h k hk
      · obtain ⟨h1, h2⟩ := h k hk
        rw [hRead_hWrite_of_ne ws v (Or.inl hdst_ne10)] at h1 h2
        exact ⟨h1, h2⟩
      · rw [hRead_hWrite_of_ne ws v (Or.inl hdst_ne10),
            hRead_hWrite_of_ne ws v (Or.inl hdst_ne10)]
        exact h k hk)
    (hC _) (fun _ h => False.elim (Nat.not_lt_zero _ h))
    (fun k hk ws hws hctr_k hpr_k hprev_k => by
      let jFin : Fin nVars := ⟨srcOff + k, by omega⟩
      have hsrc_pair : 2 * ((srcOff : ℤ) + (k : ℤ)) = 2 * (jFin.val : ℤ) := by
        dsimp [jFin]
      have h31_n : hRead ws 31 (2 * (jFin.val : ℤ)) = solNum jFin := by
        rw [hpr_k 31 _ (by dsimp [mod]; omega)]; exact (h31_ws jFin).1
      have h31_d : hRead ws 31 (2 * (jFin.val : ℤ) + 1) = solDen jFin := by
        rw [hpr_k 31 _ (by dsimp [mod]; omega)]; exact (h31_ws jFin).2
      have hn_abs : (solNum jFin).natAbs ≤ 2 ^ K := by
        rw [← h31_n]; exact storeBounded_read_abs hws _
      have hd_abs : (solDen jFin).natAbs ≤ 2 ^ K := by
        rw [← h31_d]; exact storeBounded_read_abs hws _
      have hw1 := exec_write hctx hws dstT
        (.mul (.lit 2) (.readHeap 10 (.lit 42)))
        (.readHeap 31 (.mul (.lit 2) (.add srcOffE (.readHeap 10 (.lit 42)))))
        (2 * (k : ℤ)) (solNum jFin)
        (by simp only [evalVal_mul, evalVal_lit, evalVal_readHeap, hctr_k])
        (by simp only [evalVal_readHeap, evalVal_mul, evalVal_add, evalVal_lit, hO ws, hctr_k, hsrc_pair, h31_n])
        (by omega) (by omega) hn_abs hdst_le31 (by decide)
        (by simp [exprWf, hwfO]) (by dsimp [exprNodes, exprLeaves]; omega)
      let wsa := hWrite ws dstT (2 * (k : ℤ)) (solNum jFin)
      have hwsa : StoreBounded 31 maxIdx K wsa := hw1.2.1
      have hk_a : hRead wsa 10 42 = (k : ℤ) := by
        rw [hRead_hWrite_of_ne ws _ (Or.inl hdst_ne10.symm), hctr_k]
      have h31_da : hRead wsa 31 (2 * (jFin.val : ℤ) + 1) = solDen jFin := by
        rw [hRead_hWrite_of_ne ws _ (Or.inl hdst_ne31.symm), h31_d]
      have hw2 := exec_write hctx hwsa dstT
        (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1))
        (.readHeap 31 (.add (.mul (.lit 2) (.add srcOffE (.readHeap 10 (.lit 42)))) (.lit 1)))
        (2 * (k : ℤ) + 1) (solDen jFin)
        (by simp only [evalVal_add, evalVal_mul, evalVal_lit, evalVal_readHeap, hk_a])
        (by simp only [evalVal_readHeap, evalVal_add, evalVal_mul, evalVal_lit, hO wsa, hk_a, hsrc_pair, h31_da])
        (by omega) (by omega) hd_abs hdst_le31 (by decide)
        (by simp [exprWf, hwfO]) (by dsimp [exprNodes, exprLeaves]; omega)
      refine ⟨_, hw1.seq_steps hw2, ?_,
        (hpr_k.trans (PreservesOutside.write ws _ (Or.inr rfl))).trans
          (PreservesOutside.write wsa _ (Or.inr rfl)), ?_⟩
      · rw [hRead_hWrite_of_ne wsa _ (Or.inl hdst_ne10.symm), hk_a]
      · intro k' hk'
        rcases (show k'.val < k ∨ k'.val = k by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
              hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inr (by omega))]
          exact hprev_k k' hlt
        · simp only [heq]
          exact ⟨by rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega))]
                    exact hRead_hWrite_self ws dstT _ (solNum jFin),
                 hRead_hWrite_self wsa dstT _ (solDen jFin)⟩)
    (by decide) (by decide) hwfC ⟨hszC.1.trans (by decide), hszC.2.trans (by decide)⟩
  exact ⟨ws₁, hpr₁, fun k => hDone₁ k k.isLt, hex₁.mono_steps (by omega)⟩

def zeroInitRatBlockStmt (rowsSlot tANum tADen tbNum tbDen : ℕ) : UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let nRowsE := UL.IntExpr.readHeap 10 (.lit rowsSlot)
  let iE := UL.IntExpr.readHeap 10 (.lit 41)
  let jE := UL.IntExpr.readHeap 10 (.lit 42)
  let ijE := UL.IntExpr.add (.mul iE nVarsE) jE
  forLoopStmt 41 nRowsE
    (seqBitStmts
      [ .writeHeap tbNum iE (.lit 0)
      , .writeHeap tbDen iE (.lit 1)
      , forLoopStmt 42 nVarsE
          (seqBitStmts
            [ .writeHeap tANum ijE (.lit 0)
            , .writeHeap tADen ijE (.lit 1) ]) ])

theorem exec_zeroInitRatBlockStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nRows maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars ≤ maxIdx ∧ nRows ≤ maxIdx ∧ nRows * nVars ≤ maxIdx)
    (rowsSlot : ℕ) (hslot : rowsSlot = 1 ∨ rowsSlot = 2)
    (tANum tADen tbNum tbDen : ℕ)
    (ht : 11 ≤ tANum ∧ tANum ≤ 18 ∧ 11 ≤ tADen ∧ tADen ≤ 18 ∧
          11 ≤ tbNum ∧ tbNum ≤ 18 ∧ 11 ≤ tbDen ∧ tbDen ≤ 18 ∧
          tANum ≠ tADen ∧ tANum ≠ tbNum ∧ tANum ≠ tbDen ∧
          tADen ≠ tbNum ∧ tADen ≠ tbDen ∧ tbNum ≠ tbDen)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hnV_ws : hRead ws₀ 10 0 = (nVars : ℤ))
    (hnR_ws : hRead ws₀ 10 (rowsSlot : ℤ) = (nRows : ℤ)) :
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (idx = 41 ∨ idx = 42)) ∨
      t_id = tANum ∨ t_id = tADen ∨ t_id = tbNum ∨ t_id = tbDen
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ (i : Fin nRows) (j : Fin nVars),
        hRead ws₁ tANum ((i.val * nVars + j.val : ℕ) : ℤ) = 0 ∧
        hRead ws₁ tADen ((i.val * nVars + j.val : ℕ) : ℤ) = 1) ∧
      (∀ i : Fin nRows,
        hRead ws₁ tbNum (i.val : ℤ) = 0 ∧
        hRead ws₁ tbDen (i.val : ℤ) = 1) ∧
      ExecBit inp maxIdx K (zeroInitRatBlockStmt rowsSlot tANum tADen tbNum tbDen) ws₀ ws₁
        ((2 + nRows * (5 + 3 * nVars)) * stepU) ((2 + nRows * (5 + 3 * nVars)) * stepB K) := by
  intro mod
  let PRow : ℕ → UL.WordStore → Prop := fun R ws =>
    (∀ (i : Fin nRows), i.val < R → ∀ (j : Fin nVars),
      hRead ws tANum ((i.val * nVars + j.val : ℕ) : ℤ) = 0 ∧
      hRead ws tADen ((i.val * nVars + j.val : ℕ) : ℤ) = 1) ∧
    (∀ (i : Fin nRows), i.val < R →
      hRead ws tbNum (i.val : ℤ) = 0 ∧
      hRead ws tbDen (i.val : ℤ) = 1)
  have hcntR : evalVal inp (hWrite ws₀ 10 41 0) (.readHeap 10 (.lit rowsSlot)) = (nRows : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hnR_ws]
  obtain ⟨ws₁, hpr₁, ⟨hADone, hbDone⟩, hex₁⟩ := exec_for_frame hctx 41 (.readHeap 10 (.lit rowsSlot))
    (seqBitStmts
      [ .writeHeap tbNum (.readHeap 10 (.lit 41)) (.lit 0)
      , .writeHeap tbDen (.readHeap 10 (.lit 41)) (.lit 1)
      , forLoopStmt 42 (.readHeap 10 (.lit 0))
          (seqBitStmts
            [ .writeHeap tANum (.add (.mul (.readHeap 10 (.lit 41)) (.readHeap 10 (.lit 0)))
                (.readHeap 10 (.lit 42))) (.lit 0)
            , .writeHeap tADen (.add (.mul (.readHeap 10 (.lit 41)) (.readHeap 10 (.lit 0)))
                (.readHeap 10 (.lit 42))) (.lit 1) ]) ])
    nRows (4 + 3 * nVars) mod PRow hws₀ (by omega) hIdx.2.1
    (by dsimp [mod]; omega)
    (fun R ws v => by
      dsimp [PRow]
      constructor <;> rintro ⟨h1, h2⟩ <;> refine ⟨fun i hi j => ?_, fun i hi => ?_⟩
      · obtain ⟨a, b⟩ := h1 i hi j
        rw [hRead_hWrite_of_ne ws v (Or.inl (by omega))] at a b; exact ⟨a, b⟩
      · obtain ⟨a, b⟩ := h2 i hi
        rw [hRead_hWrite_of_ne ws v (Or.inl (by omega))] at a b; exact ⟨a, b⟩
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by omega)),
            hRead_hWrite_of_ne ws v (Or.inl (by omega))]; exact h1 i hi j
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by omega)),
            hRead_hWrite_of_ne ws v (Or.inl (by omega))]; exact h2 i hi)
    hcntR ⟨fun _ h _ => False.elim (Nat.not_lt_zero _ h), fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
    (fun i hi ws hws hctr_i hpr_i ⟨hA_prev, hb_prev⟩ => by
      have hNext_le : (i + 1) * nVars ≤ nRows * nVars := Nat.mul_le_mul_right nVars hi
      have hwb1 := exec_write hctx hws tbNum (.readHeap 10 (.lit 41)) (.lit 0)
        (i : ℤ) 0 (by simp [hctr_i]) rfl (Nat.cast_nonneg _)
        (Nat.cast_le.mpr (hi.le.trans hIdx.2.1)) (by simp) (by omega)
      let wsb1 := hWrite ws tbNum (i : ℤ) 0; have hwsb1 : StoreBounded 31 maxIdx K wsb1 := hwb1.2.1
      have hi_b1 : hRead wsb1 10 41 = (i : ℤ) := by
        rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega)), hctr_i]
      have hwb2 := exec_write hctx hwsb1 tbDen (.readHeap 10 (.lit 41)) (.lit 1)
        (i : ℤ) 1 (by simp [hi_b1]) rfl (Nat.cast_nonneg _)
        (Nat.cast_le.mpr (hi.le.trans hIdx.2.1)) Nat.one_le_two_pow (by omega)
      let wsb2 := hWrite wsb1 tbDen (i : ℤ) 1; have hwsb2 : StoreBounded 31 maxIdx K wsb2 := hwb2.2.1
      let modIn : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 42) ∨
        ((t_id = tANum ∨ t_id = tADen) ∧
          ((i * nVars : ℕ) : ℤ) ≤ idx ∧ idx < (((i + 1) * nVars : ℕ) : ℤ))
      let PIn : ℕ → UL.WordStore → Prop := fun C wsi =>
        ∀ j : Fin nVars, j.val < C →
          hRead wsi tANum ((i * nVars + j.val : ℕ) : ℤ) = 0 ∧
          hRead wsi tADen ((i * nVars + j.val : ℕ) : ℤ) = 1
      have hcntIn : evalVal inp (hWrite wsb2 10 42 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne wsb2 0 (Or.inr (by omega)),
            hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)),
            hRead_hWrite_of_ne ws _ (Or.inl (by omega)),
            hpr_i 10 0 (by dsimp [mod]; omega), hnV_ws]
      obtain ⟨ws_in, hprIn, hDoneIn, hexIn⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 0))
        (seqBitStmts
          [ .writeHeap tANum (.add (.mul (.readHeap 10 (.lit 41)) (.readHeap 10 (.lit 0)))
              (.readHeap 10 (.lit 42))) (.lit 0)
          , .writeHeap tADen (.add (.mul (.readHeap 10 (.lit 41)) (.readHeap 10 (.lit 0)))
              (.readHeap 10 (.lit 42))) (.lit 1) ])
        nVars 2 modIn PIn hwsb2 (by omega) hIdx.1
        (by dsimp [modIn]; omega)
        (fun C wsi v => by
          dsimp [PIn]; constructor <;> intro h j hj
          · obtain ⟨a, b⟩ := h j hj
            rw [hRead_hWrite_of_ne wsi v (Or.inl (by omega))] at a b; exact ⟨a, b⟩
          · rw [hRead_hWrite_of_ne wsi v (Or.inl (by omega)),
                hRead_hWrite_of_ne wsi v (Or.inl (by omega))]; exact h j hj)
        hcntIn (fun _ h => False.elim (Nat.not_lt_zero _ h))
        (fun j hj wsi hwsi hctr_j hpr_j hprev_j => by
          have hij_lt : i * nVars + j < (i + 1) * nVars := by
            calc i * nVars + j < i * nVars + nVars := Nat.add_lt_add_left hj _
              _ = (i + 1) * nVars := by ring
          have hi_w : hRead wsi 10 41 = (i : ℤ) := by
            rw [hpr_j 10 41 (by dsimp [modIn]; omega),
                hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)), hi_b1]
          have hnV_w : hRead wsi 10 0 = (nVars : ℤ) := by
            rw [hpr_j 10 0 (by dsimp [modIn]; omega),
                hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)),
                hRead_hWrite_of_ne ws _ (Or.inl (by omega)),
                hpr_i 10 0 (by dsimp [mod]; omega), hnV_ws]
          have hwa1 := exec_write hctx hwsi tANum
            (.add (.mul (.readHeap 10 (.lit 41)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 42)))
            (.lit 0) ((i * nVars + j : ℕ) : ℤ) 0
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_w, hnV_w, hctr_j]
                exact_mod_cast (rfl : i * nVars + j = i * nVars + j))
            rfl (Nat.cast_nonneg _)
            (Nat.cast_le.mpr ((hij_lt.le.trans hNext_le).trans hIdx.2.2))
            (by simp) (by omega)
          let wsa1 := hWrite wsi tANum ((i * nVars + j : ℕ) : ℤ) 0
          have hwsa1 : StoreBounded 31 maxIdx K wsa1 := hwa1.2.1
          have hi_a1 : hRead wsa1 10 41 = (i : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hi_w]
          have hnV_a1 : hRead wsa1 10 0 = (nVars : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hnV_w]
          have hj_a1 : hRead wsa1 10 42 = (j : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hctr_j]
          have hwa2 := exec_write hctx hwsa1 tADen
            (.add (.mul (.readHeap 10 (.lit 41)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 42)))
            (.lit 1) ((i * nVars + j : ℕ) : ℤ) 1
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_a1, hnV_a1, hj_a1]
                exact_mod_cast (rfl : i * nVars + j = i * nVars + j))
            rfl (Nat.cast_nonneg _)
            (Nat.cast_le.mpr ((hij_lt.le.trans hNext_le).trans hIdx.2.2))
            Nat.one_le_two_pow (by omega)
          refine ⟨_, hwa1.seq_steps hwa2, ?_,
            (hpr_j.trans (PreservesOutside.write wsi _
              (Or.inr ⟨Or.inl rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hij_lt⟩))).trans
              (PreservesOutside.write wsa1 _
                (Or.inr ⟨Or.inr rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hij_lt⟩)), ?_⟩
          · rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by omega)), hj_a1]
          · intro j' hj'
            rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
            · rw [hRead_hWrite_of_ne wsa1 _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsa1 _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]
              exact hprev_j j' hlt
            · simp only [heq]
              exact ⟨by rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by omega))]
                        exact hRead_hWrite_self wsi tANum _ 0,
                     hRead_hWrite_self wsa1 tADen _ 1⟩)
      have hpr_step : PreservesOutside mod ws₀ ws_in :=
        ((hpr_i.trans (PreservesOutside.write ws _ (by dsimp [mod]; omega))).trans
          (PreservesOutside.write wsb1 _ (by dsimp [mod]; omega))).trans
          (hprIn.mono (by intro t idx h; dsimp [modIn] at h; dsimp [mod]; omega))
      refine ⟨ws_in, (hwb1.seq_steps (hwb2.seq_steps hexIn)).mono_steps (by omega), ?_, hpr_step, ⟨?_, ?_⟩⟩
      · rw [hprIn 10 41 (by dsimp [modIn]; omega),
            hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)), hi_b1]
      · intro i' hi' j'
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · have hlt_idx : i'.val * nVars + j'.val < i * nVars := row_col_lt_mul hlt j'.isLt
          have hnot_in1 : ¬ modIn tANum ((i'.val * nVars + j'.val : ℕ) : ℤ) := by
            rintro (⟨h, _⟩ | ⟨_, hge, _⟩)
            · omega
            · exact not_le.mpr (Nat.cast_lt.mpr hlt_idx) hge
          have hnot_in2 : ¬ modIn tADen ((i'.val * nVars + j'.val : ℕ) : ℤ) := by
            rintro (⟨h, _⟩ | ⟨_, hge, _⟩)
            · omega
            · exact not_le.mpr (Nat.cast_lt.mpr hlt_idx) hge
          rw [hprIn tANum _ hnot_in1, hprIn tADen _ hnot_in2,
              hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inl (by omega)),
              hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
          exact hA_prev i' hlt j'
        · simp only [heq]; exact hDoneIn j' j'.isLt
      · intro i' hi'
        rw [hprIn tbNum _ (by dsimp [modIn]; omega), hprIn tbDen _ (by dsimp [modIn]; omega)]
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
              hRead_hWrite_of_ne wsb1 _ (Or.inr (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
          exact hb_prev i' hlt
        · simp only [heq]
          exact ⟨by rw [hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega))]
                    exact hRead_hWrite_self ws tbNum _ 0,
                 hRead_hWrite_self wsb1 tbDen _ 1⟩)
    (by decide) (by decide) (by rcases hslot with rfl | rfl <;> decide)
    (by rcases hslot with rfl | rfl <;> decide)
  exact ⟨ws₁, hpr₁, fun i j => hADone i i.isLt j, fun i => hbDone i i.isLt,
    hex₁.mono_steps (le_of_eq (by ring))⟩

/-! ### 5. Part 1: General Exact Rational Linear Feasibility Programming (`progLP`) -/

def loadLPBlockStmt (rowsSlot tANum tADen tbNum tbDen : ℕ) (baseOffE : UL.IntExpr) : UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.intParam (.lit 0)
  let wE := UL.IntExpr.add nVarsE (.lit 1)
  let nRowsE := UL.IntExpr.readHeap 10 (.lit rowsSlot)
  let iE := UL.IntExpr.readHeap 10 (.lit 41)
  let jE := UL.IntExpr.readHeap 10 (.lit 42)
  let dstE := UL.IntExpr.add (.mul iE nVarsE) jE
  let srcE := UL.IntExpr.add baseOffE (.add (.mul iE wE) jE)
  let rhsSrcE := UL.IntExpr.add baseOffE (.add (.mul iE wE) nVarsE)
  forLoopStmt 41 nRowsE
    (seqBitStmts
      [ .writeHeap tbNum iE (.extraRatNum rhsSrcE)
      , .writeHeap tbDen iE (.extraRatDen rhsSrcE)
      , forLoopStmt 42 nVarsE
          (seqBitStmts
            [ .writeHeap tANum dstE (.extraRatNum srcE)
            , .writeHeap tADen dstE (.extraRatDen srcE) ]) ])

theorem exec_loadLPBlockStmt {inp : UL.BitRAMInput 0}
    {nVars nRows baseOff maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars ≤ maxIdx ∧ nRows ≤ maxIdx ∧ nRows * nVars ≤ maxIdx)
    (rowsSlot : ℕ) (hslot : rowsSlot = 1 ∨ rowsSlot = 2)
    (tANum tADen tbNum tbDen : ℕ)
    (ht : 11 ≤ tANum ∧ tANum ≤ 18 ∧ 11 ≤ tADen ∧ tADen ≤ 18 ∧
          11 ≤ tbNum ∧ tbNum ≤ 18 ∧ 11 ≤ tbDen ∧ tbDen ≤ 18 ∧
          tANum ≠ tADen ∧ tANum ≠ tbNum ∧ tANum ≠ tbDen ∧
          tADen ≠ tbNum ∧ tADen ≠ tbDen ∧ tbNum ≠ tbDen)
    (baseOffE : UL.IntExpr)
    (hwfB : exprWf 31 baseOffE = true)
    (hszB : exprNodes baseOffE ≤ 12 ∧ exprLeaves baseOffE ≤ 12)
    (hB : ∀ ws, evalVal inp ws baseOffE = (baseOff : ℤ))
    (hnV_param : ∀ ws, evalVal inp ws (.intParam (.lit 0)) = (nVars : ℤ))
    (A : Fin nRows → Fin nVars → ℚ) (b : Fin nRows → ℚ)
    (hGetA : ∀ (i : Fin nRows) (j : Fin nVars),
      inp.extraRats.getD (baseOff + (i.val * (nVars + 1) + j.val)) 0 = A i j)
    (hGetb : ∀ i : Fin nRows,
      inp.extraRats.getD (baseOff + (i.val * (nVars + 1) + nVars)) 0 = b i)
    (hAB : ∀ i j, (A i j).num.natAbs ≤ 2 ^ K ∧ (A i j).den ≤ 2 ^ K)
    (hbB : ∀ i, (b i).num.natAbs ≤ 2 ^ K ∧ (b i).den ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hnR_ws : hRead ws₀ 10 (rowsSlot : ℤ) = (nRows : ℤ)) :
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (idx = 41 ∨ idx = 42)) ∨
      t_id = tANum ∨ t_id = tADen ∨ t_id = tbNum ∨ t_id = tbDen
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ (i : Fin nRows) (j : Fin nVars),
        hRead ws₁ tANum ((i.val * nVars + j.val : ℕ) : ℤ) = (A i j).num ∧
        hRead ws₁ tADen ((i.val * nVars + j.val : ℕ) : ℤ) = ((A i j).den : ℤ)) ∧
      (∀ i : Fin nRows,
        hRead ws₁ tbNum (i.val : ℤ) = (b i).num ∧
        hRead ws₁ tbDen (i.val : ℤ) = ((b i).den : ℤ)) ∧
      ExecBit inp maxIdx K (loadLPBlockStmt rowsSlot tANum tADen tbNum tbDen baseOffE) ws₀ ws₁
        ((2 + nRows * (5 + 3 * nVars)) * stepU) ((2 + nRows * (5 + 3 * nVars)) * stepB K) := by
  intro mod
  let PRow : ℕ → UL.WordStore → Prop := fun R ws =>
    (∀ (i : Fin nRows), i.val < R → ∀ (j : Fin nVars),
      hRead ws tANum ((i.val * nVars + j.val : ℕ) : ℤ) = (A i j).num ∧
      hRead ws tADen ((i.val * nVars + j.val : ℕ) : ℤ) = ((A i j).den : ℤ)) ∧
    (∀ (i : Fin nRows), i.val < R →
      hRead ws tbNum (i.val : ℤ) = (b i).num ∧
      hRead ws tbDen (i.val : ℤ) = ((b i).den : ℤ))
  have hcntR : evalVal inp (hWrite ws₀ 10 41 0) (.readHeap 10 (.lit rowsSlot)) = (nRows : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hnR_ws]
  obtain ⟨ws₁, hpr₁, ⟨hADone, hbDone⟩, hex₁⟩ := exec_for_frame hctx 41 (.readHeap 10 (.lit rowsSlot))
    (seqBitStmts
      [ .writeHeap tbNum (.readHeap 10 (.lit 41))
          (.extraRatNum (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
            (.add (.intParam (.lit 0)) (.lit 1))) (.intParam (.lit 0)))))
      , .writeHeap tbDen (.readHeap 10 (.lit 41))
          (.extraRatDen (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
            (.add (.intParam (.lit 0)) (.lit 1))) (.intParam (.lit 0)))))
      , forLoopStmt 42 (.intParam (.lit 0))
          (seqBitStmts
            [ .writeHeap tANum
                (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                (.extraRatNum (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
                  (.add (.intParam (.lit 0)) (.lit 1))) (.readHeap 10 (.lit 42)))))
            , .writeHeap tADen
                (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                (.extraRatDen (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
                  (.add (.intParam (.lit 0)) (.lit 1))) (.readHeap 10 (.lit 42))))) ]) ])
    nRows (4 + 3 * nVars) mod PRow hws₀ (by omega) hIdx.2.1
    (by dsimp [mod]; omega)
    (fun R ws v => by
      dsimp [PRow]
      constructor <;> rintro ⟨h1, h2⟩ <;> refine ⟨fun i hi j => ?_, fun i hi => ?_⟩
      · obtain ⟨a, b0⟩ := h1 i hi j
        rw [hRead_hWrite_of_ne ws v (Or.inl (by omega))] at a b0; exact ⟨a, b0⟩
      · obtain ⟨a, b0⟩ := h2 i hi
        rw [hRead_hWrite_of_ne ws v (Or.inl (by omega))] at a b0; exact ⟨a, b0⟩
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by omega)),
            hRead_hWrite_of_ne ws v (Or.inl (by omega))]; exact h1 i hi j
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by omega)),
            hRead_hWrite_of_ne ws v (Or.inl (by omega))]; exact h2 i hi)
    hcntR ⟨fun _ h _ => False.elim (Nat.not_lt_zero _ h), fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
    (fun i hi ws hws hctr_i hpr_i ⟨hA_prev, hb_prev⟩ => by
      let iFin : Fin nRows := ⟨i, hi⟩
      have hNext_le : (i + 1) * nVars ≤ nRows * nVars := Nat.mul_le_mul_right nVars hi
      have hrhs_idx : (baseOff : ℤ) + ((i : ℤ) * ((nVars : ℤ) + 1) + (nVars : ℤ)) =
          ((baseOff + (i * (nVars + 1) + nVars) : ℕ) : ℤ) :=
        by exact_mod_cast (rfl : baseOff + (i * (nVars + 1) + nVars) = baseOff + (i * (nVars + 1) + nVars))
      have hwb1 := exec_write hctx hws tbNum (.readHeap 10 (.lit 41))
        (.extraRatNum (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
          (.add (.intParam (.lit 0)) (.lit 1))) (.intParam (.lit 0)))))
        (i : ℤ) (b iFin).num
        (by simp [hctr_i])
        (by simp only [evalVal_extraRatNum, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
              hB ws, hctr_i, hnV_param ws, hrhs_idx, listGetIntD_nat]
            exact congrArg Rat.num (hGetb iFin))
        (Nat.cast_nonneg _) (Nat.cast_le.mpr (hi.le.trans hIdx.2.1))
        (hbB iFin).1 (by omega) (by decide) (by simp [exprWf, hwfB])
        (by dsimp [exprNodes, exprLeaves]; omega)
      let wsb1 := hWrite ws tbNum (i : ℤ) (b iFin).num
      have hwsb1 : StoreBounded 31 maxIdx K wsb1 := hwb1.2.1
      have hi_b1 : hRead wsb1 10 41 = (i : ℤ) := by
        rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega)), hctr_i]
      have hwb2 := exec_write hctx hwsb1 tbDen (.readHeap 10 (.lit 41))
        (.extraRatDen (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
          (.add (.intParam (.lit 0)) (.lit 1))) (.intParam (.lit 0)))))
        (i : ℤ) ((b iFin).den : ℤ)
        (by simp [hi_b1])
        (by simp only [evalVal_extraRatDen, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
              hB wsb1, hi_b1, hnV_param wsb1, hrhs_idx, listGetIntD_nat]
            exact congrArg (fun q : ℚ => (q.den : ℤ)) (hGetb iFin))
        (Nat.cast_nonneg _) (Nat.cast_le.mpr (hi.le.trans hIdx.2.1))
        (by simpa using (hbB iFin).2) (by omega) (by decide) (by simp [exprWf, hwfB])
        (by dsimp [exprNodes, exprLeaves]; omega)
      let wsb2 := hWrite wsb1 tbDen (i : ℤ) ((b iFin).den : ℤ)
      have hwsb2 : StoreBounded 31 maxIdx K wsb2 := hwb2.2.1
      let modIn : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 42) ∨
        ((t_id = tANum ∨ t_id = tADen) ∧
          ((i * nVars : ℕ) : ℤ) ≤ idx ∧ idx < (((i + 1) * nVars : ℕ) : ℤ))
      let PIn : ℕ → UL.WordStore → Prop := fun C wsi =>
        ∀ j : Fin nVars, j.val < C →
          hRead wsi tANum ((i * nVars + j.val : ℕ) : ℤ) = (A iFin j).num ∧
          hRead wsi tADen ((i * nVars + j.val : ℕ) : ℤ) = ((A iFin j).den : ℤ)
      obtain ⟨ws_in, hprIn, hDoneIn, hexIn⟩ := exec_for_frame hctx 42 (.intParam (.lit 0))
        (seqBitStmts
          [ .writeHeap tANum
              (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
              (.extraRatNum (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
                (.add (.intParam (.lit 0)) (.lit 1))) (.readHeap 10 (.lit 42)))))
          , .writeHeap tADen
              (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
              (.extraRatDen (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
                (.add (.intParam (.lit 0)) (.lit 1))) (.readHeap 10 (.lit 42))))) ])
        nVars 2 modIn PIn hwsb2 (by omega) hIdx.1
        (by dsimp [modIn]; omega)
        (fun C wsi v => by
          dsimp [PIn]; constructor <;> intro h j hj
          · obtain ⟨a, b0⟩ := h j hj
            rw [hRead_hWrite_of_ne wsi v (Or.inl (by omega))] at a b0; exact ⟨a, b0⟩
          · rw [hRead_hWrite_of_ne wsi v (Or.inl (by omega)),
                hRead_hWrite_of_ne wsi v (Or.inl (by omega))]; exact h j hj)
        (hnV_param _) (fun _ h => False.elim (Nat.not_lt_zero _ h))
        (fun j hj wsi hwsi hctr_j hpr_j hprev_j => by
          let jFin : Fin nVars := ⟨j, hj⟩
          have hij_lt : i * nVars + j < (i + 1) * nVars := by
            calc i * nVars + j < i * nVars + nVars := Nat.add_lt_add_left hj _
              _ = (i + 1) * nVars := by ring
          have hi_w : hRead wsi 10 41 = (i : ℤ) := by
            rw [hpr_j 10 41 (by dsimp [modIn]; omega),
                hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)), hi_b1]
          have hsrc_idx : (baseOff : ℤ) + ((i : ℤ) * ((nVars : ℤ) + 1) + (j : ℤ)) =
              ((baseOff + (i * (nVars + 1) + j) : ℕ) : ℤ) :=
            by exact_mod_cast (rfl : baseOff + (i * (nVars + 1) + j) = baseOff + (i * (nVars + 1) + j))
          have hwa1 := exec_write hctx hwsi tANum
            (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
            (.extraRatNum (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
              (.add (.intParam (.lit 0)) (.lit 1))) (.readHeap 10 (.lit 42)))))
            ((i * nVars + j : ℕ) : ℤ) (A iFin jFin).num
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_w, hnV_param wsi, hctr_j]
                exact_mod_cast (rfl : i * nVars + j = i * nVars + j))
            (by simp only [evalVal_extraRatNum, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
                  hB wsi, hi_w, hnV_param wsi, hctr_j, hsrc_idx, listGetIntD_nat]
                exact congrArg Rat.num (hGetA iFin jFin))
            (Nat.cast_nonneg _)
            (Nat.cast_le.mpr ((hij_lt.le.trans hNext_le).trans hIdx.2.2))
            (hAB iFin jFin).1 (by omega) (by decide) (by simp [exprWf, hwfB])
            (by dsimp [exprNodes, exprLeaves]; omega)
          let wsa1 := hWrite wsi tANum ((i * nVars + j : ℕ) : ℤ) (A iFin jFin).num
          have hwsa1 : StoreBounded 31 maxIdx K wsa1 := hwa1.2.1
          have hi_a1 : hRead wsa1 10 41 = (i : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hi_w]
          have hj_a1 : hRead wsa1 10 42 = (j : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega)), hctr_j]
          have hwa2 := exec_write hctx hwsa1 tADen
            (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
            (.extraRatDen (.add baseOffE (.add (.mul (.readHeap 10 (.lit 41))
              (.add (.intParam (.lit 0)) (.lit 1))) (.readHeap 10 (.lit 42)))))
            ((i * nVars + j : ℕ) : ℤ) ((A iFin jFin).den : ℤ)
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_a1, hnV_param wsa1, hj_a1]
                exact_mod_cast (rfl : i * nVars + j = i * nVars + j))
            (by simp only [evalVal_extraRatDen, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
                  hB wsa1, hi_a1, hnV_param wsa1, hj_a1, hsrc_idx, listGetIntD_nat]
                exact congrArg (fun q : ℚ => (q.den : ℤ)) (hGetA iFin jFin))
            (Nat.cast_nonneg _)
            (Nat.cast_le.mpr ((hij_lt.le.trans hNext_le).trans hIdx.2.2))
            (by simpa using (hAB iFin jFin).2) (by omega) (by decide) (by simp [exprWf, hwfB])
            (by dsimp [exprNodes, exprLeaves]; omega)
          refine ⟨_, hwa1.seq_steps hwa2, ?_,
            (hpr_j.trans (PreservesOutside.write wsi _
              (Or.inr ⟨Or.inl rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hij_lt⟩))).trans
              (PreservesOutside.write wsa1 _
                (Or.inr ⟨Or.inr rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hij_lt⟩)), ?_⟩
          · rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by omega)), hj_a1]
          · intro j' hj'
            rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
            · rw [hRead_hWrite_of_ne wsa1 _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsa1 _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]
              exact hprev_j j' hlt
            · have hj_eq : j' = jFin := Fin.ext heq; subst hj_eq
              exact ⟨by rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by omega))]
                        exact hRead_hWrite_self wsi tANum _ _,
                     hRead_hWrite_self wsa1 tADen _ _⟩)
      have hpr_step : PreservesOutside mod ws₀ ws_in :=
        ((hpr_i.trans (PreservesOutside.write ws _ (by dsimp [mod]; omega))).trans
          (PreservesOutside.write wsb1 _ (by dsimp [mod]; omega))).trans
          (hprIn.mono (by intro t idx h; dsimp [modIn] at h; dsimp [mod]; omega))
      refine ⟨ws_in, (hwb1.seq_steps (hwb2.seq_steps hexIn)).mono_steps (by omega), ?_, hpr_step, ⟨?_, ?_⟩⟩
      · rw [hprIn 10 41 (by dsimp [modIn]; omega),
            hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)), hi_b1]
      · intro i' hi' j'
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · have hlt_idx : i'.val * nVars + j'.val < i * nVars := row_col_lt_mul hlt j'.isLt
          have hnot_in1 : ¬ modIn tANum ((i'.val * nVars + j'.val : ℕ) : ℤ) := by
            rintro (⟨h, _⟩ | ⟨_, hge, _⟩); · omega
            · exact not_le.mpr (Nat.cast_lt.mpr hlt_idx) hge
          have hnot_in2 : ¬ modIn tADen ((i'.val * nVars + j'.val : ℕ) : ℤ) := by
            rintro (⟨h, _⟩ | ⟨_, hge, _⟩); · omega
            · exact not_le.mpr (Nat.cast_lt.mpr hlt_idx) hge
          rw [hprIn tANum _ hnot_in1, hprIn tADen _ hnot_in2,
              hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inl (by omega)),
              hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
          exact hA_prev i' hlt j'
        · have hi_eq : i' = iFin := Fin.ext heq; subst hi_eq
          exact hDoneIn j' j'.isLt
      · intro i' hi'
        rw [hprIn tbNum _ (by dsimp [modIn]; omega), hprIn tbDen _ (by dsimp [modIn]; omega)]
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
              hRead_hWrite_of_ne wsb1 _ (Or.inr (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
          exact hb_prev i' hlt
        · have hi_eq : i' = iFin := Fin.ext heq; subst hi_eq
          exact ⟨by rw [hRead_hWrite_of_ne wsb1 _ (Or.inl (by omega))]
                    exact hRead_hWrite_self ws tbNum _ _,
                 hRead_hWrite_self wsb1 tbDen _ _⟩)
    (by decide) (by decide) (by rcases hslot with rfl | rfl <;> decide)
    (by rcases hslot with rfl | rfl <;> decide)
  exact ⟨ws₁, hpr₁, fun i j => hADone i i.isLt j, fun i => hbDone i i.isLt,
    hex₁.mono_steps (le_of_eq (by ring))⟩

def progLP : UL.BitRAMStmt :=
  seqBitStmts
    [ writeDimsStmt (.intParam (.lit 0)) (.intParam (.lit 1)) (.intParam (.lit 2))
    , loadLPBlockStmt 1 11 12 13 14 (.lit 0)
    , loadLPBlockStmt 2 15 16 17 18
        (.mul (.intParam (.lit 1)) (.add (.intParam (.lit 0)) (.lit 1)))
    , solveRationalLPStmt
    , .writeHeap 0 (.lit 0) (.readHeap 30 (.lit 0))
    , copyVecOutStmt 1 (.intParam (.lit 0)) (.lit 0) ]

theorem part1_progLP :
    ∃ (prog : UL.BitRAMStmt) (C deg : ℕ),
      ∀ (nVars nEq nLe B : ℕ)
        (A_eq : Fin nEq → Fin nVars → ℚ) (b_eq : Fin nEq → ℚ)
        (A_le : Fin nLe → Fin nVars → ℚ) (b_le : Fin nLe → ℚ),
        (∀ (i : Fin nEq) (j : Fin nVars), UL.RatCoordBitBounded B (A_eq i j)) →
        (∀ i : Fin nEq, UL.RatCoordBitBounded B (b_eq i)) →
        (∀ (i : Fin nLe) (j : Fin nVars), UL.RatCoordBitBounded B (A_le i j)) →
        (∀ i : Fin nLe, UL.RatCoordBitBounded B (b_le i)) →
        let eqRows : List ℚ :=
          (List.finRange nEq).flatMap (fun i => List.ofFn (A_eq i) ++ [b_eq i])
        let leRows : List ℚ :=
          (List.finRange nLe).flatMap (fun i => List.ofFn (A_le i) ++ [b_le i])
        let inp : UL.BitRAMInput 0 :=
          { intParams := [(nVars : ℤ), (nEq : ℤ), (nLe : ℤ)]
            activeHandles := ∅
            activeRatCoords := fun _ k => Fin.elim0 k
            extraRats := eqRows ++ leRows }
        let bound : ℕ := C * (nVars + nEq + nLe + B + 1) ^ deg
        ∃ out : UL.BitRAMExecOutcome,
          UL.runBitRAMWithBits prog inp UL.WordStore.empty [] = some out ∧
          out.unitCost ≤ bound ∧
          out.bitCost ≤ bound ∧
          out.peakCellSpace ≤ bound ∧
          out.peakBitSpace ≤ bound ∧
          let flag : ℤ := out.words.read (.heap 0 0)
          (flag = 0 ∨ flag = 1) ∧
          (flag = 1 ↔
            ∃ x : Fin nVars → ℝ,
              (∀ i : Fin nEq, ∑ j : Fin nVars, (A_eq i j : ℝ) * x j = (b_eq i : ℝ)) ∧
              (∀ i : Fin nLe, ∑ j : Fin nVars, (A_le i j : ℝ) * x j ≤ (b_le i : ℝ))) ∧
          (flag = 1 →
            let solNum : Fin nVars → ℤ := fun j => out.words.read (.heap 1 (2 * (j.val : ℤ)))
            let solDen : Fin nVars → ℤ := fun j => out.words.read (.heap 1 (2 * (j.val : ℤ) + 1))
            let xRat : Fin nVars → ℚ := fun j => (solNum j : ℚ) / (solDen j : ℚ)
            (∀ j : Fin nVars,
              0 < solDen j ∧
              UL.intBitLength (solNum j) ≤ bound ∧
              UL.intBitLength (solDen j) ≤ bound ∧
              UL.RatCoordBitBounded bound (xRat j) ∧
              UL.ratBitLength (xRat j) ≤ bound) ∧
            (∀ i : Fin nEq, ∑ j : Fin nVars, A_eq i j * xRat j = b_eq i) ∧
            (∀ i : Fin nLe, ∑ j : Fin nVars, A_le i j * xRat j ≤ b_le i)) := by
  refine ⟨progLP, 10 ^ 26, 22, ?_⟩
  intro nVars nEq nLe B A_eq b_eq A_le b_le hAeqB hbeqB hAleB hbleB eqRows leRows inp bound
  let B' := max B 1
  let maxIdx := solverMaxIdx nVars nEq nLe
  let K := solverK nVars nEq nLe B'
  have hB'1 : 1 ≤ B' := le_max_right B 1
  have hB'_le_K : B' ≤ K :=
    (Nat.le_mul_of_pos_right B' (by omega : 0 < nVars + 2)).trans bInt_le_solverK
  have hPowB'K : 2 ^ B' ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) hB'_le_K
  obtain ⟨h64, hnV, hnE, hnL, _, hnV2, h2nV, _, _, hmOra, hnEnV, hnLnV, _, _, _, _, _, _⟩ :=
    solverMaxIdx_bounds nVars nEq nLe
  have hMaxPow := solverMaxIdx_le_two_pow nVars nEq nLe B'
  -- Lengths and getD of eqRows ++ leRows
  have hEqRowLen : ∀ i : Fin nEq, (List.ofFn (A_eq i) ++ [b_eq i]).length = nVars + 1 :=
    fun i => by simp
  have hLeRowLen : ∀ k : Fin nLe, (List.ofFn (A_le k) ++ [b_le k]).length = nVars + 1 :=
    fun k => by simp
  have hEqLen : eqRows.length = nEq * (nVars + 1) :=
    flatMap_finRange_length nEq (nVars + 1) _ hEqRowLen
  have hLeLen : leRows.length = nLe * (nVars + 1) :=
    flatMap_finRange_length nLe (nVars + 1) _ hLeRowLen
  have hGetEqA : ∀ (i : Fin nEq) (j : Fin nVars),
      inp.extraRats.getD (0 + (i.val * (nVars + 1) + j.val)) 0 = A_eq i j := by
    intro i j
    dsimp [inp]; rw [Nat.zero_add]
    have hlt : i.val * (nVars + 1) + j.val < eqRows.length := by
      rw [hEqLen]; exact row_col_lt_mul i.isLt (by omega)
    rw [list_getD_append_left eqRows leRows _ 0 hlt,
        flatMap_finRange_getD nEq (nVars + 1) _ 0 hEqRowLen i (by omega),
        list_getD_append_left _ _ j.val 0 (by simp [j.isLt]),
        list_getD_ofFn]
  have hGetEqb : ∀ i : Fin nEq,
      inp.extraRats.getD (0 + (i.val * (nVars + 1) + nVars)) 0 = b_eq i := by
    intro i
    dsimp [inp]; rw [Nat.zero_add]
    have hlt : i.val * (nVars + 1) + nVars < eqRows.length := by
      rw [hEqLen]; exact row_col_lt_mul i.isLt (by omega)
    rw [list_getD_append_left eqRows leRows _ 0 hlt,
        flatMap_finRange_getD nEq (nVars + 1) _ 0 hEqRowLen i (by omega)]
    have h1 := list_getD_append_add (List.ofFn (A_eq i)) [b_eq i] 0 0
    rw [List.length_ofFn, Nat.add_zero] at h1
    exact h1
  have hGetLeA : ∀ (k : Fin nLe) (j : Fin nVars),
      inp.extraRats.getD (nEq * (nVars + 1) + (k.val * (nVars + 1) + j.val)) 0 = A_le k j := by
    intro k j
    dsimp [inp]; rw [← hEqLen, list_getD_append_add,
        flatMap_finRange_getD nLe (nVars + 1) _ 0 hLeRowLen k (by omega),
        list_getD_append_left _ _ j.val 0 (by simp [j.isLt]),
        list_getD_ofFn]
  have hGetLeb : ∀ k : Fin nLe,
      inp.extraRats.getD (nEq * (nVars + 1) + (k.val * (nVars + 1) + nVars)) 0 = b_le k := by
    intro k
    dsimp [inp]; rw [← hEqLen, list_getD_append_add,
        flatMap_finRange_getD nLe (nVars + 1) _ 0 hLeRowLen k (by omega)]
    have h1 := list_getD_append_add (List.ofFn (A_le k)) [b_le k] 0 0
    rw [List.length_ofFn, Nat.add_zero] at h1
    exact h1
  -- Input magnitude & space bounds
  have hIntB : ∀ z ∈ [(nVars : ℤ), (nEq : ℤ), (nLe : ℤ)], z.natAbs ≤ 2 ^ K := by
    intro z hz
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hz
    rcases hz with rfl | rfl | rfl
    · simpa using hnV.trans hMaxPow
    · simpa using hnE.trans hMaxPow
    · simpa using hnL.trans hMaxPow
  have hExtraB : ∀ q ∈ eqRows ++ leRows, q.num.natAbs ≤ 2 ^ K ∧ q.den ≤ 2 ^ K := by
    intro q hq
    have hCB : UL.RatCoordBitBounded B q := by
      rw [List.mem_append] at hq
      rcases hq with hq1 | hq2
      · rw [List.mem_flatMap] at hq1
        rcases hq1 with ⟨i, _, hmem⟩
        rw [List.mem_append] at hmem
        rcases hmem with hA | hb
        · rw [List.mem_ofFn] at hA; rcases hA with ⟨j, rfl⟩; exact hAeqB i j
        · simp only [List.mem_singleton] at hb; subst hb; exact hbeqB i
      · rw [List.mem_flatMap] at hq2
        rcases hq2 with ⟨k, _, hmem⟩
        rw [List.mem_append] at hmem
        rcases hmem with hA | hb
        · rw [List.mem_ofFn] at hA; rcases hA with ⟨j, rfl⟩; exact hAleB k j
        · simp only [List.mem_singleton] at hb; subst hb; exact hbleB k
    obtain ⟨hn, hd, _, _, _⟩ := ratCoordBitBounded_imp_natAbs_le hCB
    exact ⟨hn.trans hPowB'K, hd.trans hPowB'K⟩
  obtain ⟨hInpMag, hInpCells, hInpBits⟩ :=
    input_ZeroDim_bounds K [(nVars : ℤ), (nEq : ℤ), (nLe : ℤ)] (eqRows ++ leRows) hIntB hExtraB
  have hctx : HeapCtx inp maxIdx K := ⟨solverK_ge6 nVars nEq nLe B', hMaxPow, hInpMag⟩
  have hp0 : ∀ ws, evalVal inp ws (.intParam (.lit 0)) = (nVars : ℤ) := fun _ => rfl
  have hp1 : ∀ ws, evalVal inp ws (.intParam (.lit 1)) = (nEq : ℤ) := fun _ => rfl
  have hp2 : ∀ ws, evalVal inp ws (.intParam (.lit 2)) = (nLe : ℤ) := fun _ => rfl
  -- Execute progLP step by step
  obtain ⟨ws1, hDim1, hs1⟩ := exec_writeDimsStmt hctx h64 ⟨hnV2, hmOra⟩
    (.intParam (.lit 0)) (.intParam (.lit 1)) (.intParam (.lit 2))
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    hp0 hp1 hp2 (storeBounded_empty 31 maxIdx K)
  have hAeq_B' := fun i j => ratCoordBitBounded_imp_natAbs_le (hAeqB i j)
  have hbeq_B' := fun i => ratCoordBitBounded_imp_natAbs_le (hbeqB i)
  have hAle_B' := fun k j => ratCoordBitBounded_imp_natAbs_le (hAleB k j)
  have hble_B' := fun k => ratCoordBitBounded_imp_natAbs_le (hbleB k)
  obtain ⟨ws2, hpr2, hAeq_ws2, hbeq_ws2, hs2⟩ := exec_loadLPBlockStmt hctx h64
    ⟨hnV, hnE, hnEnV⟩ 1 (Or.inl rfl) 11 12 13 14 (by decide) (.lit 0)
    (by decide) (by decide) (fun _ => rfl) hp0 A_eq b_eq hGetEqA hGetEqb
    (fun i j => ⟨(hAeq_B' i j).1.trans hPowB'K, (hAeq_B' i j).2.1.trans hPowB'K⟩)
    (fun i => ⟨(hbeq_B' i).1.trans hPowB'K, (hbeq_B' i).2.1.trans hPowB'K⟩)
    hs1.2.1 hDim1.2.1
  have hDim2 := hDim1.preserve hpr2 (by intro idx _ _; omega)
  obtain ⟨ws3, hpr3, hAle_ws3, hble_ws3, hs3⟩ := exec_loadLPBlockStmt hctx h64
    ⟨hnV, hnL, hnLnV⟩ 2 (Or.inr rfl) 15 16 17 18 (by decide)
    (.mul (.intParam (.lit 1)) (.add (.intParam (.lit 0)) (.lit 1)))
    (by decide) (by decide)
    (fun ws => by
      simp only [evalVal_mul, evalVal_add, evalVal_lit, hp1 ws, hp0 ws]
      exact_mod_cast (rfl : nEq * (nVars + 1) = nEq * (nVars + 1)))
    hp0 A_le b_le hGetLeA hGetLeb
    (fun k j => ⟨(hAle_B' k j).1.trans hPowB'K, (hAle_B' k j).2.1.trans hPowB'K⟩)
    (fun k => ⟨(hble_B' k).1.trans hPowB'K, (hble_B' k).2.1.trans hPowB'K⟩)
    hs2.2.1 hDim2.2.2.1
  have hDim3 := hDim2.preserve hpr3 (by intro idx _ _; omega)
  have hRat3 : RatLPInHeap
      (fun i j => (A_eq i j).num) (fun i j => ((A_eq i j).den : ℤ))
      (fun i => (b_eq i).num) (fun i => ((b_eq i).den : ℤ))
      (fun k j => (A_le k j).num) (fun k j => ((A_le k j).den : ℤ))
      (fun k => (b_le k).num) (fun k => ((b_le k).den : ℤ)) ws3 := by
    refine ⟨fun i j => ?_, fun i => ?_, hAle_ws3, hble_ws3⟩
    · rw [hpr3 11 _ (by omega), hpr3 12 _ (by omega)]; exact hAeq_ws2 i j
    · rw [hpr3 13 _ (by omega), hpr3 14 _ (by omega)]; exact hbeq_ws2 i
  obtain ⟨ws4, _, hFlag4, hSol4, hs4⟩ := exec_solveRationalLPStmt hB'1 hctx
    (fun i j => (A_eq i j).num) (fun i j => ((A_eq i j).den : ℤ))
    (fun i => (b_eq i).num) (fun i => ((b_eq i).den : ℤ))
    (fun k j => (A_le k j).num) (fun k j => ((A_le k j).den : ℤ))
    (fun k => (b_le k).num) (fun k => ((b_le k).den : ℤ))
    (fun i j => Nat.cast_pos.mpr (A_eq i j).pos)
    (fun i => Nat.cast_pos.mpr (b_eq i).pos)
    (fun k j => Nat.cast_pos.mpr (A_le k j).pos)
    (fun k => Nat.cast_pos.mpr (b_le k).pos)
    (fun i j => (hAeq_B' i j).1)
    (fun i j => by simpa using (hAeq_B' i j).2.1)
    (fun i => (hbeq_B' i).1)
    (fun i => by simpa using (hbeq_B' i).2.1)
    (fun k j => (hAle_B' k j).1)
    (fun k j => by simpa using (hAle_B' k j).2.1)
    (fun k => (hble_B' k).1)
    (fun k => by simpa using (hble_B' k).2.1)
    hs3.2.1 hDim3 hRat3
  let res := solveRationalLP
    (fun i j => (A_eq i j).num) (fun i j => ((A_eq i j).den : ℤ))
    (fun i => (b_eq i).num) (fun i => ((b_eq i).den : ℤ))
    (fun k j => (A_le k j).num) (fun k j => ((A_le k j).den : ℤ))
    (fun k => (b_le k).num) (fun k => ((b_le k).den : ℤ))
  have hFlag_abs : res.1.natAbs ≤ 2 ^ K := by
    rw [← hFlag4]; exact storeBounded_read_abs hs4.2.1 _
  have hs5 := exec_write hctx hs4.2.1 0 (.lit 0) (.readHeap 30 (.lit 0))
    0 res.1 rfl (by rw [evalVal_readHeap, evalVal_lit, hFlag4]) (by omega) (by omega) hFlag_abs
  let ws5 := hWrite ws4 0 0 res.1; have hws5 : StoreBounded 31 maxIdx K ws5 := hs5.2.1
  have hSol5 : ∀ j : Fin nVars,
      hRead ws5 31 (2 * (j.val : ℤ)) = res.2.1 j ∧
      hRead ws5 31 (2 * (j.val : ℤ) + 1) = res.2.2 j := by
    intro j
    rw [hRead_hWrite_of_ne ws4 _ (Or.inl (by decide)),
        hRead_hWrite_of_ne ws4 _ (Or.inl (by decide))]
    exact hSol4 j
  obtain ⟨ws6, hpr6, hOut6, hs6⟩ := exec_copyVecOutStmt hctx h64
    (by omega : 0 + nVars ≤ nVars) h2nV 1 (Or.inl rfl) (.intParam (.lit 0)) (.lit 0)
    (by decide) (by decide) (by decide) (by decide) hp0 (fun _ => rfl)
    res.2.1 res.2.2 hws5 hSol5
  let m_extra := 10 + (nEq + nLe) * (5 + 3 * nVars)
  have hExecTot : ExecBit inp maxIdx K progLP UL.WordStore.empty ws6
      ((m_extra + solverStepBound nVars nEq nLe B' + (10 + 4 * nVars)) * stepU)
      ((m_extra + solverStepBound nVars nEq nLe B' + (10 + 4 * nVars)) * stepB K) :=
    (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps (hs5.seq_steps hs6))))).mono_steps
      (Nat.le.intro (by dsimp [m_extra]; ring : _ + (7 + nVars) = _))
  obtain ⟨out, hRun, hout_ws, huCost, hbCost, hpCells, hpBits⟩ := hExecTot.to_runBitRAMWithBits
  have hm_extra_le : m_extra ≤ 40 * (nVars + nEq + nLe + 1) ^ 2 := by
    dsimp [m_extra]
    exact Nat.le.intro (by
      ring : (10 + (nEq + nLe) * (5 + 3 * nVars)) +
        (30 + 80 * nVars + 75 * nEq + 75 * nLe + 77 * (nEq * nVars) + 77 * (nLe * nVars) +
         80 * (nEq * nLe) + 40 * nVars ^ 2 + 40 * nEq ^ 2 + 40 * nLe ^ 2) =
        40 * (nVars + nEq + nLe + 1) ^ 2)
  have hlenRat_le : (eqRows ++ leRows).length ≤ 4 * (nVars + nEq + nLe + 1) ^ 2 := by
    rw [List.length_append, hEqLen, hLeLen]
    exact Nat.le.intro (by
      ring : (nEq * (nVars + 1) + nLe * (nVars + 1)) +
        (4 + 8 * nVars + 7 * nEq + 7 * nLe + 7 * (nEq * nVars) + 7 * (nLe * nVars) +
         8 * (nEq * nLe) + 4 * nVars ^ 2 + 4 * nEq ^ 2 + 4 * nLe ^ 2) =
        4 * (nVars + nEq + nLe + 1) ^ 2)
  obtain ⟨hBU, hBB, hBC, hBP, hBK5⟩ := poly_solver_bounds nVars nEq nLe B
    m_extra 3 (eqRows ++ leRows).length hm_extra_le (by omega) hlenRat_le
  have hPure := solveRationalLP_spec hB'1
    (fun i j => (A_eq i j).num) (fun i j => ((A_eq i j).den : ℤ))
    (fun i => (b_eq i).num) (fun i => ((b_eq i).den : ℤ))
    (fun k j => (A_le k j).num) (fun k j => ((A_le k j).den : ℤ))
    (fun k => (b_le k).num) (fun k => ((b_le k).den : ℤ))
    (fun i j => Nat.cast_pos.mpr (A_eq i j).pos)
    (fun i => Nat.cast_pos.mpr (b_eq i).pos)
    (fun k j => Nat.cast_pos.mpr (A_le k j).pos)
    (fun k => Nat.cast_pos.mpr (b_le k).pos)
    (fun i j => (hAeq_B' i j).1) (fun i j => by simpa using (hAeq_B' i j).2.1)
    (fun i => (hbeq_B' i).1) (fun i => by simpa using (hbeq_B' i).2.1)
    (fun k j => (hAle_B' k j).1) (fun k j => by simpa using (hAle_B' k j).2.1)
    (fun k => (hble_B' k).1) (fun k => by simpa using (hble_B' k).2.1)
  simp only [Int.cast_natCast, Rat.num_div_den] at hPure
  change (res.1 = 0 ∨ res.1 = 1) ∧ _ ∧ _ at hPure
  obtain ⟨hF01, hFIff, hFWhen1⟩ := hPure
  have hOutFlag : out.words.read (.heap 0 0) = res.1 := by
    rw [hout_ws]
    change hRead ws6 0 0 = res.1
    rw [hpr6 0 0 (by omega)]; exact hRead_hWrite_self ws4 0 0 res.1
  have hCellsLe : ctxPeakCells inp maxIdx ≤ 3 + 2 * (eqRows ++ leRows).length + 32 * (maxIdx + 1) := by
    dsimp [ctxPeakCells, inp]; rw [hInpCells]; simp
  refine ⟨out, hRun, huCost.trans hBU, hbCost.trans hBB,
    hpCells.trans (hCellsLe.trans hBC),
    hpBits.trans ((Nat.add_le_add_right hInpBits _).trans (by simpa using hBP)),
    ?_, ?_, ?_⟩
  · rw [hOutFlag]; exact hF01
  · rw [hOutFlag]; exact hFIff
  · intro h1
    rw [hOutFlag] at h1
    obtain ⟨hSolB, hEqSat, hLeSat⟩ := hFWhen1 h1
    have hBarK := bareiss_bound_le_two_pow_solverK nVars nEq nLe B'
    have hReadSol : ∀ j : Fin nVars,
        out.words.read (.heap 1 (2 * (j.val : ℤ))) = res.2.1 j ∧
        out.words.read (.heap 1 (2 * (j.val : ℤ) + 1)) = res.2.2 j := by
      intro j
      rw [hout_ws]
      simpa using hOut6 j
    refine ⟨fun j => ?_, ?_, ?_⟩
    · dsimp only; rw [(hReadSol j).1, (hReadSol j).2]
      obtain ⟨hpos, hnB, hdB⟩ := hSolB j
      obtain ⟨hb1, hb2, hb3, hb4⟩ :=
        rat_div_bit_bounds hpos (hnB.trans hBarK) (hdB.trans hBarK) hBK5
      exact ⟨hpos, hb1, hb2, hb3, hb4⟩
    · have hRS1 : ∀ j, out.words.read (.heap 1 (2 * (j.val : ℤ))) = res.2.1 j := fun j => (hReadSol j).1
      have hRS2 : ∀ j, out.words.read (.heap 1 (2 * (j.val : ℤ) + 1)) = res.2.2 j := fun j => (hReadSol j).2
      intro i; simp only [hRS1, hRS2]; exact hEqSat i
    · have hRS1 : ∀ j, out.words.read (.heap 1 (2 * (j.val : ℤ))) = res.2.1 j := fun j => (hReadSol j).1
      have hRS2 : ∀ j, out.words.read (.heap 1 (2 * (j.val : ℤ) + 1)) = res.2.2 j := fun j => (hReadSol j).2
      intro k; simp only [hRS1, hRS2]; exact hLeSat k

/-! ### 6. Sparse Index Injectivity & Part 3 (`progCert`) -/

theorem row_col_inj {W r₁ c₁ r₂ c₂ : ℕ} (hc₁ : c₁ < W) (hc₂ : c₂ < W)
    (heq : r₁ * W + c₁ = r₂ * W + c₂) : r₁ = r₂ ∧ c₁ = c₂ := by
  have hr : r₁ = r₂ := by
    rcases lt_trichotomy r₁ r₂ with hlt | h | hgt
    · exfalso
      have h1 : r₁ * W + c₁ < (r₁ + 1) * W := by
        calc r₁ * W + c₁ < r₁ * W + W := Nat.add_lt_add_left hc₁ _
          _ = (r₁ + 1) * W := by ring
      have h2 : (r₁ + 1) * W ≤ r₂ * W := Nat.mul_le_mul_right W hlt
      omega
    · exact h
    · exfalso
      have h1 : r₂ * W + c₂ < (r₂ + 1) * W := by
        calc r₂ * W + c₂ < r₂ * W + W := Nat.add_lt_add_left hc₂ _
          _ = (r₂ + 1) * W := by ring
      have h2 : (r₂ + 1) * W ≤ r₁ * W := Nat.mul_le_mul_right W hgt
      omega
  subst hr
  exact ⟨rfl, by omega⟩

def loadCertStmt : UL.BitRAMStmt :=
  let DE := UL.IntExpr.intParam (.lit 0)
  let sE := UL.IntExpr.intParam (.lit 1)
  let cE := UL.IntExpr.readHeap 10 (.lit 41)
  let jE := UL.IntExpr.readHeap 10 (.lit 42)
  let srcPtE := UL.IntExpr.add DE (.add (.mul jE DE) cE)
  seqBitStmts
    [ writeDimsStmt sE (.add DE (.lit 1)) sE
    , zeroInitRatBlockStmt 1 11 12 13 14
    , zeroInitRatBlockStmt 2 15 16 17 18
    , forLoopStmt 41 DE
        (seqBitStmts
          [ .writeHeap 13 cE (.extraRatNum cE)
          , .writeHeap 14 cE (.extraRatDen cE)
          , forLoopStmt 42 sE
              (seqBitStmts
                [ .writeHeap 11 (.add (.mul cE sE) jE) (.extraRatNum srcPtE)
                , .writeHeap 12 (.add (.mul cE sE) jE) (.extraRatDen srcPtE) ]) ])
    , .writeHeap 13 DE (.lit 1)
    , forLoopStmt 42 sE
        (.writeHeap 11 (.add (.mul DE sE) jE) (.lit 1))
    , forLoopStmt 42 sE
        (.writeHeap 15 (.add (.mul jE sE) jE) (.lit (-1))) ]

def progCert : UL.BitRAMStmt :=
  seqBitStmts
    [ loadCertStmt
    , solveRationalLPStmt
    , .writeHeap 0 (.lit 0) (.readHeap 30 (.lit 0))
    , copyVecOutStmt 1 (.intParam (.lit 1)) (.lit 0) ]

theorem part3_progCert :
    ∃ (prog : UL.BitRAMStmt) (C deg : ℕ),
      ∀ (D s B : ℕ) (pts : Fin s → Fin D → ℚ) (zRat : Fin D → ℚ),
        (∀ j : Fin s, UL.RatPointBitBounded B (pts j)) →
        UL.RatPointBitBounded B zRat →
        let flatPts : List ℚ :=
          (List.finRange s).flatMap (fun j => List.ofFn (pts j))
        let inp : UL.BitRAMInput 0 :=
          { intParams := [(D : ℤ), (s : ℤ)]
            activeHandles := ∅
            activeRatCoords := fun _ k => Fin.elim0 k
            extraRats := List.ofFn zRat ++ flatPts }
        let bound : ℕ := C * (D + s + B + 1) ^ deg
        ∃ out : UL.BitRAMExecOutcome,
          UL.runBitRAMWithBits prog inp UL.WordStore.empty [] = some out ∧
          out.unitCost ≤ bound ∧
          out.bitCost ≤ bound ∧
          out.peakCellSpace ≤ bound ∧
          out.peakBitSpace ≤ bound ∧
          let flag : ℤ := out.words.read (.heap 0 0)
          (flag = 0 ∨ flag = 1) ∧
          (flag = 1 ↔
            UL.HasConvexHullCert (fun j : Fin s => UL.ratPointToEuclidean (pts j))
              (UL.ratPointToEuclidean zRat)) ∧
          (flag = 1 →
            let lamNum : Fin s → ℤ := fun j => out.words.read (.heap 1 (2 * (j.val : ℤ)))
            let lamDen : Fin s → ℤ := fun j => out.words.read (.heap 1 (2 * (j.val : ℤ) + 1))
            let lam : Fin s → ℚ := fun j => (lamNum j : ℚ) / (lamDen j : ℚ)
            (∀ j : Fin s,
              0 < lamDen j ∧
              UL.intBitLength (lamNum j) ≤ bound ∧
              UL.intBitLength (lamDen j) ≤ bound ∧
              UL.RatCoordBitBounded bound (lam j) ∧
              UL.ratBitLength (lam j) ≤ bound) ∧
            UL.IsConvexHullCert (fun j : Fin s => UL.ratPointToEuclidean (pts j))
              (UL.ratPointToEuclidean zRat) (fun j : Fin s => (lam j : ℝ))) := by
  refine ⟨progCert, 10 ^ 34, 22, ?_⟩
  intro D s B pts zRat hPtsB hzB flatPts inp bound
  let nVars := s
  let nEq := D + 1
  let nLe := s
  let B' := max B 1
  let maxIdx := solverMaxIdx nVars nEq nLe
  let K := solverK nVars nEq nLe B'
  have hB'1 : 1 ≤ B' := le_max_right B 1
  have hB'_le_K : B' ≤ K :=
    (Nat.le_mul_of_pos_right B' (by omega : 0 < nVars + 2)).trans bInt_le_solverK
  have hPowB'K : 2 ^ B' ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) hB'_le_K
  obtain ⟨h64, hnV, hnE, hnL, _, hnV2, h2nV, _, _, hmOra, hnEnV, hnLnV, _, _, _, _, _, _⟩ :=
    solverMaxIdx_bounds nVars nEq nLe
  have hD_le : D ≤ maxIdx := (Nat.le_succ D).trans hnE
  have hMaxPow := solverMaxIdx_le_two_pow nVars nEq nLe B'
  -- List indexing
  have hFlatLen : flatPts.length = s * D :=
    flatMap_finRange_length s D (fun j => List.ofFn (pts j)) (fun _ => List.length_ofFn)
  have hGetZ : ∀ c : Fin D, inp.extraRats.getD c.val 0 = zRat c := by
    intro c
    dsimp [inp]
    rw [list_getD_append_left (List.ofFn zRat) flatPts c.val 0 (by simp [c.isLt]), list_getD_ofFn]
  have hGetPt : ∀ (j : Fin s) (c : Fin D),
      inp.extraRats.getD (D + (j.val * D + c.val)) 0 = pts j c := by
    intro j c
    dsimp [inp]
    have h1 := list_getD_append_add (List.ofFn zRat) flatPts (j.val * D + c.val) 0
    rw [List.length_ofFn] at h1
    rw [h1, flatMap_finRange_getD s D _ 0 (fun _ => List.length_ofFn) j c.isLt,
        list_getD_ofFn]
  -- Input bounds
  have hIntB : ∀ z ∈ [(D : ℤ), (s : ℤ)], z.natAbs ≤ 2 ^ K := by
    intro z hz
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hz
    rcases hz with rfl | rfl
    · simpa using hD_le.trans hMaxPow
    · simpa using hnV.trans hMaxPow
  have hExtraB : ∀ q ∈ List.ofFn zRat ++ flatPts, q.num.natAbs ≤ 2 ^ K ∧ q.den ≤ 2 ^ K := by
    intro q hq
    have hCB : UL.RatCoordBitBounded B q := by
      rw [List.mem_append] at hq
      rcases hq with hq1 | hq2
      · rw [List.mem_ofFn] at hq1; rcases hq1 with ⟨c, rfl⟩; exact hzB c
      · rw [List.mem_flatMap] at hq2
        rcases hq2 with ⟨j, _, hmem⟩
        rw [List.mem_ofFn] at hmem; rcases hmem with ⟨c, rfl⟩; exact hPtsB j c
    obtain ⟨hn, hd, _, _, _⟩ := ratCoordBitBounded_imp_natAbs_le hCB
    exact ⟨hn.trans hPowB'K, hd.trans hPowB'K⟩
  obtain ⟨hInpMag, hInpCells, hInpBits⟩ :=
    input_ZeroDim_bounds K [(D : ℤ), (s : ℤ)] (List.ofFn zRat ++ flatPts) hIntB hExtraB
  have hctx : HeapCtx inp maxIdx K := ⟨solverK_ge6 nVars nEq nLe B', hMaxPow, hInpMag⟩
  have hpD : ∀ ws, evalVal inp ws (.intParam (.lit 0)) = (D : ℤ) := fun _ => rfl
  have hps : ∀ ws, evalVal inp ws (.intParam (.lit 1)) = (s : ℤ) := fun _ => rfl
  have hz_B' := fun c => ratCoordBitBounded_imp_natAbs_le (hzB c)
  have hpt_B' := fun j c => ratCoordBitBounded_imp_natAbs_le (hPtsB j c)
  -- Target LP arrays
  let A_eq_num : Fin nEq → Fin nVars → ℤ :=
    fun r j => if h : r.val < D then (pts j ⟨r.val, h⟩).num else 1
  let A_eq_den : Fin nEq → Fin nVars → ℤ :=
    fun r j => if h : r.val < D then ((pts j ⟨r.val, h⟩).den : ℤ) else 1
  let b_eq_num : Fin nEq → ℤ :=
    fun r => if h : r.val < D then (zRat ⟨r.val, h⟩).num else 1
  let b_eq_den : Fin nEq → ℤ :=
    fun r => if h : r.val < D then ((zRat ⟨r.val, h⟩).den : ℤ) else 1
  let A_le_num : Fin nLe → Fin nVars → ℤ := fun k j => if j = k then -1 else 0
  let A_le_den : Fin nLe → Fin nVars → ℤ := fun _ _ => 1
  let b_le_num : Fin nLe → ℤ := fun _ => 0
  let b_le_den : Fin nLe → ℤ := fun _ => 1
  -- Step 1: writeDimsStmt
  obtain ⟨ws1, hDim1, hs1⟩ := exec_writeDimsStmt hctx h64 ⟨hnV2, hmOra⟩
    (.intParam (.lit 1)) (.add (.intParam (.lit 0)) (.lit 1)) (.intParam (.lit 1))
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    hps (fun ws => by simp only [evalVal_add, evalVal_lit, hpD ws]; exact_mod_cast (rfl : D + 1 = nEq)) hps
    (storeBounded_empty 31 maxIdx K)
  -- Step 2 & 3: zero-init eq and le blocks
  obtain ⟨ws2, hpr2, hZ1_A, hZ1_b, hs2⟩ := exec_zeroInitRatBlockStmt hctx h64
    ⟨hnV, hnE, hnEnV⟩ 1 (Or.inl rfl) 11 12 13 14 (by decide) hs1.2.1 hDim1.1 hDim1.2.1
  have hDim2 := hDim1.preserve hpr2 (by intro idx _ _; omega)
  obtain ⟨ws3, hpr3, hZ2_A, hZ2_b, hs3⟩ := exec_zeroInitRatBlockStmt hctx h64
    ⟨hnV, hnL, hnLnV⟩ 2 (Or.inr rfl) 15 16 17 18 (by decide) hs2.2.1 hDim2.1 hDim2.2.2.1
  have hDim3 := hDim2.preserve hpr3 (by intro idx _ _; omega)
  have hZ1A_3 : ∀ (r : Fin nEq) (j : Fin nVars),
      hRead ws3 11 ((r.val * s + j.val : ℕ) : ℤ) = 0 ∧
      hRead ws3 12 ((r.val * s + j.val : ℕ) : ℤ) = 1 := by
    intro r j; rw [hpr3 11 _ (by omega), hpr3 12 _ (by omega)]; exact hZ1_A r j
  have hZ1b_3 : ∀ r : Fin nEq, hRead ws3 13 (r.val : ℤ) = 0 ∧ hRead ws3 14 (r.val : ℤ) = 1 := by
    intro r; rw [hpr3 13 _ (by omega), hpr3 14 _ (by omega)]; exact hZ1_b r
  -- Step 4: loop c < D populating rows 0 .. D - 1 of eq
  let modC : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 41 ∨ idx = 42)) ∨
    ((t_id = 11 ∨ t_id = 12) ∧ 0 ≤ idx ∧ idx < ((D * s : ℕ) : ℤ)) ∨
    ((t_id = 13 ∨ t_id = 14) ∧ 0 ≤ idx ∧ idx < (D : ℤ))
  let PC : ℕ → UL.WordStore → Prop := fun R ws =>
    (∀ (c : Fin D), c.val < R → ∀ (j : Fin s),
      hRead ws 11 ((c.val * s + j.val : ℕ) : ℤ) = (pts j c).num ∧
      hRead ws 12 ((c.val * s + j.val : ℕ) : ℤ) = ((pts j c).den : ℤ)) ∧
    (∀ (c : Fin D), c.val < R →
      hRead ws 13 (c.val : ℤ) = (zRat c).num ∧
      hRead ws 14 (c.val : ℤ) = ((zRat c).den : ℤ))
  obtain ⟨ws4, hpr4, ⟨hPts4, hz4⟩, hs4⟩ := exec_for_frame hctx 41 (.intParam (.lit 0))
    (seqBitStmts
      [ .writeHeap 13 (.readHeap 10 (.lit 41)) (.extraRatNum (.readHeap 10 (.lit 41)))
      , .writeHeap 14 (.readHeap 10 (.lit 41)) (.extraRatDen (.readHeap 10 (.lit 41)))
      , forLoopStmt 42 (.intParam (.lit 1))
          (seqBitStmts
            [ .writeHeap 11 (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42)))
                (.extraRatNum (.add (.intParam (.lit 0))
                  (.add (.mul (.readHeap 10 (.lit 42)) (.intParam (.lit 0))) (.readHeap 10 (.lit 41)))))
            , .writeHeap 12 (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42)))
                (.extraRatDen (.add (.intParam (.lit 0))
                  (.add (.mul (.readHeap 10 (.lit 42)) (.intParam (.lit 0))) (.readHeap 10 (.lit 41))))) ]) ])
    D (4 + 3 * s) modC PC hs3.2.1 (by omega) hD_le
    (by dsimp [modC]; omega)
    (fun R ws v => by
      dsimp [PC]; constructor <;> rintro ⟨h1, h2⟩ <;> refine ⟨fun c hc j => ?_, fun c hc => ?_⟩
      · obtain ⟨a, b0⟩ := h1 c hc j; rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at a b0; exact ⟨a, b0⟩
      · obtain ⟨a, b0⟩ := h2 c hc; rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at a b0; exact ⟨a, b0⟩
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide)),
            hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h1 c hc j
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide)),
            hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h2 c hc)
    (hpD _) ⟨fun _ h _ => False.elim (Nat.not_lt_zero _ h), fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
    (fun c hc ws hws hctr_c hpr_c ⟨hA_prev, hb_prev⟩ => by
      let cFin : Fin D := ⟨c, hc⟩
      have hNext_le : (c + 1) * s ≤ D * s := Nat.mul_le_mul_right s hc
      have hDs_le : D * s ≤ maxIdx :=
        (Nat.mul_le_mul_right s (Nat.le_succ D)).trans hnEnV
      have hwb1 := exec_write hctx hws 13 (.readHeap 10 (.lit 41))
        (.extraRatNum (.readHeap 10 (.lit 41))) (c : ℤ) (zRat cFin).num
        (by simp [hctr_c])
        (by simp only [evalVal_extraRatNum, evalVal_readHeap, evalVal_lit, hctr_c, listGetIntD_nat]
            exact congrArg Rat.num (hGetZ cFin))
        (Nat.cast_nonneg _) (Nat.cast_le.mpr (hc.le.trans hD_le))
        ((hz_B' cFin).1.trans hPowB'K)
      let wsb1 := hWrite ws 13 (c : ℤ) (zRat cFin).num
      have hwsb1 : StoreBounded 31 maxIdx K wsb1 := hwb1.2.1
      have hc_b1 : hRead wsb1 10 41 = (c : ℤ) := by
        rw [hRead_hWrite_of_ne ws _ (Or.inl (by decide)), hctr_c]
      have hwb2 := exec_write hctx hwsb1 14 (.readHeap 10 (.lit 41))
        (.extraRatDen (.readHeap 10 (.lit 41))) (c : ℤ) ((zRat cFin).den : ℤ)
        (by simp [hc_b1])
        (by simp only [evalVal_extraRatDen, evalVal_readHeap, evalVal_lit, hc_b1, listGetIntD_nat]
            exact congrArg (fun q : ℚ => (q.den : ℤ)) (hGetZ cFin))
        (Nat.cast_nonneg _) (Nat.cast_le.mpr (hc.le.trans hD_le))
        (by simpa using (hz_B' cFin).2.1.trans hPowB'K)
      let wsb2 := hWrite wsb1 14 (c : ℤ) ((zRat cFin).den : ℤ)
      have hwsb2 : StoreBounded 31 maxIdx K wsb2 := hwb2.2.1
      let modIn : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 42) ∨
        ((t_id = 11 ∨ t_id = 12) ∧ ((c * s : ℕ) : ℤ) ≤ idx ∧ idx < (((c + 1) * s : ℕ) : ℤ))
      let PIn : ℕ → UL.WordStore → Prop := fun C wsi =>
        ∀ j : Fin s, j.val < C →
          hRead wsi 11 ((c * s + j.val : ℕ) : ℤ) = (pts j cFin).num ∧
          hRead wsi 12 ((c * s + j.val : ℕ) : ℤ) = ((pts j cFin).den : ℤ)
      obtain ⟨ws_in, hprIn, hDoneIn, hexIn⟩ := exec_for_frame hctx 42 (.intParam (.lit 1))
        (seqBitStmts
          [ .writeHeap 11 (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42)))
              (.extraRatNum (.add (.intParam (.lit 0))
                (.add (.mul (.readHeap 10 (.lit 42)) (.intParam (.lit 0))) (.readHeap 10 (.lit 41)))))
          , .writeHeap 12 (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42)))
              (.extraRatDen (.add (.intParam (.lit 0))
                (.add (.mul (.readHeap 10 (.lit 42)) (.intParam (.lit 0))) (.readHeap 10 (.lit 41))))) ])
        s 2 modIn PIn hwsb2 (by omega) hnV
        (by dsimp [modIn]; omega)
        (fun C wsi v => by
          dsimp [PIn]; constructor <;> intro h j hj
          · obtain ⟨a, b0⟩ := h j hj; rw [hRead_hWrite_of_ne wsi v (Or.inl (by decide))] at a b0; exact ⟨a, b0⟩
          · rw [hRead_hWrite_of_ne wsi v (Or.inl (by decide)),
                hRead_hWrite_of_ne wsi v (Or.inl (by decide))]; exact h j hj)
        (hps _) (fun _ h => False.elim (Nat.not_lt_zero _ h))
        (fun j hj wsi hwsi hctr_j hpr_j hprev_j => by
          let jFin : Fin s := ⟨j, hj⟩
          have hcj_lt : c * s + j < (c + 1) * s := by
            calc c * s + j < c * s + s := Nat.add_lt_add_left hj _
              _ = (c + 1) * s := by ring
          have hc_w : hRead wsi 10 41 = (c : ℤ) := by
            rw [hpr_j 10 41 (by dsimp [modIn]; omega),
                hRead_hWrite_of_ne wsb1 _ (Or.inl (by decide)), hc_b1]
          have hsrc_eq : (D : ℤ) + ((j : ℤ) * (D : ℤ) + (c : ℤ)) =
              ((D + (j * D + c) : ℕ) : ℤ) :=
            by exact_mod_cast (rfl : D + (j * D + c) = D + (j * D + c))
          have hwa1 := exec_write hctx hwsi 11
            (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42)))
            (.extraRatNum (.add (.intParam (.lit 0))
              (.add (.mul (.readHeap 10 (.lit 42)) (.intParam (.lit 0))) (.readHeap 10 (.lit 41)))))
            ((c * s + j : ℕ) : ℤ) (pts jFin cFin).num
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hc_w, hps wsi, hctr_j]
                exact_mod_cast (rfl : c * s + j = c * s + j))
            (by simp only [evalVal_extraRatNum, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
                  hpD wsi, hctr_j, hc_w, hsrc_eq, listGetIntD_nat]
                exact congrArg Rat.num (hGetPt jFin cFin))
            (Nat.cast_nonneg _)
            (Nat.cast_le.mpr ((hcj_lt.le.trans hNext_le).trans hDs_le))
            ((hpt_B' jFin cFin).1.trans hPowB'K)
          let wsa1 := hWrite wsi 11 ((c * s + j : ℕ) : ℤ) (pts jFin cFin).num
          have hwsa1 : StoreBounded 31 maxIdx K wsa1 := hwa1.2.1
          have hc_a1 : hRead wsa1 10 41 = (c : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by decide)), hc_w]
          have hj_a1 : hRead wsa1 10 42 = (j : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by decide)), hctr_j]
          have hwa2 := exec_write hctx hwsa1 12
            (.add (.mul (.readHeap 10 (.lit 41)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42)))
            (.extraRatDen (.add (.intParam (.lit 0))
              (.add (.mul (.readHeap 10 (.lit 42)) (.intParam (.lit 0))) (.readHeap 10 (.lit 41)))))
            ((c * s + j : ℕ) : ℤ) ((pts jFin cFin).den : ℤ)
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hc_a1, hps wsa1, hj_a1]
                exact_mod_cast (rfl : c * s + j = c * s + j))
            (by simp only [evalVal_extraRatDen, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
                  hpD wsa1, hj_a1, hc_a1, hsrc_eq, listGetIntD_nat]
                exact congrArg (fun q : ℚ => (q.den : ℤ)) (hGetPt jFin cFin))
            (Nat.cast_nonneg _)
            (Nat.cast_le.mpr ((hcj_lt.le.trans hNext_le).trans hDs_le))
            (by simpa using (hpt_B' jFin cFin).2.1.trans hPowB'K)
          refine ⟨_, hwa1.seq_steps hwa2, ?_,
            (hpr_j.trans (PreservesOutside.write wsi _
              (Or.inr ⟨Or.inl rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hcj_lt⟩))).trans
              (PreservesOutside.write wsa1 _
                (Or.inr ⟨Or.inr rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hcj_lt⟩)), ?_⟩
          · rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by decide)), hj_a1]
          · intro j' hj'
            rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
            · rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by decide)),
                  hRead_hWrite_of_ne wsi _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsa1 _ (Or.inr (by omega)),
                  hRead_hWrite_of_ne wsi _ (Or.inl (by decide))]
              exact hprev_j j' hlt
            · have hj_eq : j' = jFin := Fin.ext heq; subst hj_eq
              exact ⟨by rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by decide))]
                        exact hRead_hWrite_self wsi 11 _ _,
                     hRead_hWrite_self wsa1 12 _ _⟩)
      have hpr_step : PreservesOutside modC ws3 ws_in :=
        ((hpr_c.trans (PreservesOutside.write ws _ (by dsimp [modC]; omega))).trans
          (PreservesOutside.write wsb1 _ (by dsimp [modC]; omega))).trans
          (hprIn.mono (by
            intro t idx h; dsimp [modIn] at h; dsimp [modC]
            rcases h with ⟨rfl, rfl⟩ | ⟨ht, hlo, hhi⟩
            · exact Or.inl ⟨rfl, Or.inr rfl⟩
            · exact Or.inr (Or.inl ⟨ht, le_trans (Nat.cast_nonneg _) hlo,
                lt_of_lt_of_le hhi (Nat.cast_le.mpr hNext_le)⟩)))
      refine ⟨ws_in, (hwb1.seq_steps (hwb2.seq_steps hexIn)).mono_steps (by omega), ?_, hpr_step, ⟨?_, ?_⟩⟩
      · rw [hprIn 10 41 (by dsimp [modIn]; omega),
            hRead_hWrite_of_ne wsb1 _ (Or.inl (by decide)), hc_b1]
      · intro c' hc' j'
        rcases (show c'.val < c ∨ c'.val = c by omega) with hlt | heq
        · have hlt_idx : c'.val * s + j'.val < c * s := row_col_lt_mul hlt j'.isLt
          rw [hprIn 11 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, hge, _⟩; · exact absurd h (by decide)
                · exact not_le.mpr (Nat.cast_lt.mpr hlt_idx) hge),
              hprIn 12 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, hge, _⟩; · exact absurd h (by decide)
                · exact not_le.mpr (Nat.cast_lt.mpr hlt_idx) hge),
              hRead_hWrite_of_ne wsb1 _ (Or.inl (by decide)),
              hRead_hWrite_of_ne ws _ (Or.inl (by decide)),
              hRead_hWrite_of_ne wsb1 _ (Or.inl (by decide)),
              hRead_hWrite_of_ne ws _ (Or.inl (by decide))]
          exact hA_prev c' hlt j'
        · have hc_eq : c' = cFin := Fin.ext heq; subst hc_eq
          exact hDoneIn j' j'.isLt
      · intro c' hc'
        rw [hprIn 13 _ (by dsimp [modIn]; omega), hprIn 14 _ (by dsimp [modIn]; omega)]
        rcases (show c'.val < c ∨ c'.val = c by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne wsb1 _ (Or.inl (by decide)),
              hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
              hRead_hWrite_of_ne wsb1 _ (Or.inr (by omega)),
              hRead_hWrite_of_ne ws _ (Or.inl (by decide))]
          exact hb_prev c' hlt
        · have hc_eq : c' = cFin := Fin.ext heq; subst hc_eq
          exact ⟨by rw [hRead_hWrite_of_ne wsb1 _ (Or.inl (by decide))]
                    exact hRead_hWrite_self ws 13 _ _,
                 hRead_hWrite_self wsb1 14 _ _⟩)
  -- Step 5: write 13[D] := 1
  have hs5 := exec_write hctx hs4.2.1 13 (.intParam (.lit 0)) (.lit 1)
    (D : ℤ) 1 (hpD ws4) rfl (Nat.cast_nonneg _) (Nat.cast_le.mpr hD_le) Nat.one_le_two_pow
  let ws5 := hWrite ws4 13 (D : ℤ) 1; have hws5 : StoreBounded 31 maxIdx K ws5 := hs5.2.1
  -- Step 6: write 11[D * s + j] := 1 for j < s
  let modRowD : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨ (t_id = 11 ∧ ((D * s : ℕ) : ℤ) ≤ idx)
  let PRowD : ℕ → UL.WordStore → Prop := fun C ws =>
    ∀ j : Fin s, j.val < C → hRead ws 11 ((D * s + j.val : ℕ) : ℤ) = 1
  obtain ⟨ws6, hpr6, hRowD6, hs6⟩ := exec_for_frame hctx 42 (.intParam (.lit 1))
    (.writeHeap 11 (.add (.mul (.intParam (.lit 0)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42))) (.lit 1))
    s 1 modRowD PRowD hws5 (by omega) hnV
    (by dsimp [modRowD]; omega)
    (fun C ws v => by
      dsimp [PRowD]; constructor <;> intro h j hj
      · have := h j hj; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h j hj)
    (hps _) (fun _ h => False.elim (Nat.not_lt_zero _ h))
    (fun j hj ws hws hctr_j hpr_j hprev_j => by
      have hidx_le : D * s + j ≤ maxIdx :=
        (row_col_lt_mul (Nat.lt_succ_self D) hj).le.trans hnEnV
      have hw := exec_write hctx hws 11
        (.add (.mul (.intParam (.lit 0)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42))) (.lit 1)
        ((D * s + j : ℕ) : ℤ) 1
        (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hpD ws, hps ws, hctr_j]
            exact_mod_cast (rfl : D * s + j = D * s + j))
        rfl (Nat.cast_nonneg _) (Nat.cast_le.mpr hidx_le) Nat.one_le_two_pow
      refine ⟨_, hw, ?_,
        hpr_j.trans (PreservesOutside.write ws _
          (Or.inr ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right _ _)⟩)), ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by decide))]; exact hctr_j
      · intro j' hj'
        rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]; exact hprev_j j' hlt
        · simp only [heq]; exact hRead_hWrite_self ws 11 _ 1)
  -- Step 7: write 15[k * s + k] := -1 for k < s
  let modDiag : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨ t_id = 15
  let PDiag : ℕ → UL.WordStore → Prop := fun K_done ws =>
    ∀ (k j : Fin s),
      hRead ws 15 ((k.val * s + j.val : ℕ) : ℤ) = if k.val < K_done ∧ j = k then -1 else 0
  have hPDiag0 : PDiag 0 ws6 := by
    intro k j
    simp only [Nat.not_lt_zero, false_and, ↓reduceIte]
    rw [hpr6 15 _ (by dsimp [modRowD]; omega),
        hRead_hWrite_of_ne ws4 _ (Or.inl (by decide)),
        hpr4 15 _ (by dsimp [modC]; omega)]
    exact (hZ2_A k j).1
  obtain ⟨ws7, hpr7, hDiag7, hs7⟩ := exec_for_frame hctx 42 (.intParam (.lit 1))
    (.writeHeap 15 (.add (.mul (.readHeap 10 (.lit 42)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42))) (.lit (-1)))
    s 1 modDiag PDiag hs6.2.1 (by omega) hnV
    (by dsimp [modDiag]; omega)
    (fun C ws v => by
      dsimp [PDiag]; constructor <;> intro h k j
      · have := h k j; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h k j)
    (hps _) hPDiag0
    (fun k hk ws hws hctr_k hpr_k hprev_k => by
      let kFin : Fin s := ⟨k, hk⟩
      have hkk_le : k * s + k ≤ maxIdx := (row_col_lt_mul hk hk).le.trans hnLnV
      have hw := exec_write hctx hws 15
        (.add (.mul (.readHeap 10 (.lit 42)) (.intParam (.lit 1))) (.readHeap 10 (.lit 42))) (.lit (-1))
        ((k * s + k : ℕ) : ℤ) (-1)
        (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hctr_k, hps ws]
            exact_mod_cast (rfl : k * s + k = k * s + k))
        rfl (Nat.cast_nonneg _) (Nat.cast_le.mpr hkk_le) Nat.one_le_two_pow
      refine ⟨_, hw, ?_, hpr_k.trans (PreservesOutside.write ws _ (Or.inr rfl)), ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by decide))]; exact hctr_k
      · intro k' j'
        by_cases heq_idx : k'.val * s + j'.val = k * s + k
        · obtain ⟨hkeq, hjeq⟩ := row_col_inj j'.isLt hk heq_idx
          have hjk : j' = k' := Fin.ext (hjeq.trans hkeq.symm)
          have hlt1 : k'.val < k + 1 := by omega
          rw [if_pos ⟨hlt1, hjk⟩]; simp only [heq_idx]
          exact hRead_hWrite_self ws 15 _ (-1)
        · have hne_z : ((k'.val * s + j'.val : ℕ) : ℤ) ≠ ((k * s + k : ℕ) : ℤ) :=
            fun h => heq_idx (Int.ofNat.inj h)
          rw [hRead_hWrite_of_ne ws _ (Or.inr hne_z), hprev_k k' j']
          by_cases hjk : j' = k'
          · have hk_ne : k'.val ≠ k := fun h => heq_idx (by rw [hjk, h])
            have hiff : (k'.val < k ↔ k'.val < k + 1) := by omega
            simp [hjk, hiff]
          · simp [hjk])
  -- Assemble DimsInHeap & RatLPInHeap at ws7
  have hDim7 : DimsInHeap nVars nEq nLe ws7 := by
    have hp4 := hDim3.preserve hpr4 (by intro idx _ _; dsimp [modC]; omega)
    have hp5 := hp4.preserve (ws₁ := ws5)
      (PreservesOutside.write (mod := fun t i => t = 13 ∧ i = (D : ℤ)) ws4 1 ⟨rfl, rfl⟩)
      (by intro idx _ _; omega)
    have hp6 := hp5.preserve hpr6 (by intro idx _ _; dsimp [modRowD]; omega)
    exact hp6.preserve hpr7 (by intro idx _ _; dsimp [modDiag]; omega)
  have hRat7 : RatLPInHeap A_eq_num A_eq_den b_eq_num b_eq_den A_le_num A_le_den b_le_num b_le_den ws7 := by
    refine ⟨fun r j => ?_, fun r => ?_, fun k j => ?_, fun k => ?_⟩
    · rw [hpr7 11 _ (by dsimp [modDiag]; omega), hpr7 12 _ (by dsimp [modDiag]; omega)]
      by_cases hr : r.val < D
      · have hlt_Ds : r.val * s + j.val < D * s := row_col_lt_mul hr j.isLt
        rw [hpr6 11 _ (fun h => by
              rcases h with ⟨h, _⟩ | ⟨_, hge⟩; · exact absurd h (by decide)
              · exact not_le.mpr (Nat.cast_lt.mpr hlt_Ds) hge),
            hpr6 12 _ (by dsimp [modRowD]; omega),
            hRead_hWrite_of_ne ws4 _ (Or.inl (by decide)),
            hRead_hWrite_of_ne ws4 _ (Or.inl (by decide))]
        dsimp [A_eq_num, A_eq_den]; rw [dif_pos hr, dif_pos hr]
        exact hPts4 ⟨r.val, hr⟩ hr j
      · have hr_eq : r.val = D := by have := r.isLt; dsimp [nEq] at this; omega
        dsimp [A_eq_num, A_eq_den]; rw [dif_neg hr, dif_neg hr]
        refine ⟨?_, ?_⟩
        · simp only [hr_eq]; exact hRowD6 j j.isLt
        · rw [hpr6 12 _ (by dsimp [modRowD]; omega),
              hRead_hWrite_of_ne ws4 _ (Or.inl (by decide)),
              hpr4 12 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, _, hlt⟩ | ⟨h, _⟩
                · exact absurd h (by decide)
                · simp only [hr_eq] at hlt
                  exact not_lt.mpr (Nat.cast_le.mpr (Nat.le_add_right (D * s) j.val)) hlt
                · omega)]
          exact (hZ1A_3 r j).2
    · rw [hpr7 13 _ (by dsimp [modDiag]; omega), hpr7 14 _ (by dsimp [modDiag]; omega),
          hpr6 13 _ (by dsimp [modRowD]; omega), hpr6 14 _ (by dsimp [modRowD]; omega)]
      by_cases hr : r.val < D
      · dsimp [b_eq_num, b_eq_den]; rw [dif_pos hr, dif_pos hr]
        rw [hRead_hWrite_of_ne ws4 _ (Or.inr (by omega)),
            hRead_hWrite_of_ne ws4 _ (Or.inl (by decide))]
        exact hz4 ⟨r.val, hr⟩ hr
      · have hr_eq : r.val = D := by have := r.isLt; dsimp [nEq] at this; omega
        dsimp [b_eq_num, b_eq_den]; rw [dif_neg hr, dif_neg hr]
        refine ⟨?_, ?_⟩
        · simp only [hr_eq]; exact hRead_hWrite_self ws4 13 (D : ℤ) 1
        · rw [hRead_hWrite_of_ne ws4 _ (Or.inl (by decide)),
              hpr4 14 _ (by dsimp [modC]; omega)]
          exact (hZ1b_3 r).2
    · refine ⟨?_, ?_⟩
      · have hd := hDiag7 k j
        simpa [A_le_num, k.isLt] using hd
      · rw [hpr7 16 _ (by dsimp [modDiag]; omega), hpr6 16 _ (by dsimp [modRowD]; omega),
            hRead_hWrite_of_ne ws4 _ (Or.inl (by decide)), hpr4 16 _ (by dsimp [modC]; omega)]
        exact (hZ2_A k j).2
    · rw [hpr7 17 _ (by dsimp [modDiag]; omega), hpr7 18 _ (by dsimp [modDiag]; omega),
          hpr6 17 _ (by dsimp [modRowD]; omega), hpr6 18 _ (by dsimp [modRowD]; omega),
          hRead_hWrite_of_ne ws4 _ (Or.inl (by decide)),
          hRead_hWrite_of_ne ws4 _ (Or.inl (by decide)),
          hpr4 17 _ (by dsimp [modC]; omega), hpr4 18 _ (by dsimp [modC]; omega)]
      exact hZ2_b k
  -- Step 8: solveRationalLPStmt + output copy
  have hEqDenPos : ∀ r j, 0 < A_eq_den r j := by
    intro r j; dsimp [A_eq_den]; split_ifs with h
    · exact Nat.cast_pos.mpr (pts j ⟨r.val, h⟩).pos
    · omega
  have hbEqDenPos : ∀ r, 0 < b_eq_den r := by
    intro r; dsimp [b_eq_den]; split_ifs with h
    · exact Nat.cast_pos.mpr (zRat ⟨r.val, h⟩).pos
    · omega
  have hEqNumB : ∀ r j, (A_eq_num r j).natAbs ≤ 2 ^ B' := by
    intro r j; dsimp [A_eq_num]; split_ifs with h
    · exact (hpt_B' j ⟨r.val, h⟩).1
    · exact Nat.one_le_two_pow
  have hEqDenB : ∀ r j, (A_eq_den r j).natAbs ≤ 2 ^ B' := by
    intro r j; dsimp [A_eq_den]; split_ifs with h
    · simpa using (hpt_B' j ⟨r.val, h⟩).2.1
    · exact Nat.one_le_two_pow
  have hbEqNumB : ∀ r, (b_eq_num r).natAbs ≤ 2 ^ B' := by
    intro r; dsimp [b_eq_num]; split_ifs with h
    · exact (hz_B' ⟨r.val, h⟩).1
    · exact Nat.one_le_two_pow
  have hbEqDenB : ∀ r, (b_eq_den r).natAbs ≤ 2 ^ B' := by
    intro r; dsimp [b_eq_den]; split_ifs with h
    · simpa using (hz_B' ⟨r.val, h⟩).2.1
    · exact Nat.one_le_two_pow
  have hLeNumB : ∀ k j, (A_le_num k j).natAbs ≤ 2 ^ B' := by
    intro k j; dsimp [A_le_num]; split_ifs <;> simp [Nat.one_le_two_pow]
  obtain ⟨ws8, _, hFlag8, hSol8, hs8⟩ := exec_solveRationalLPStmt hB'1 hctx
    A_eq_num A_eq_den b_eq_num b_eq_den A_le_num A_le_den b_le_num b_le_den
    hEqDenPos hbEqDenPos (fun _ _ => Int.zero_lt_one) (fun _ => Int.zero_lt_one)
    hEqNumB hEqDenB hbEqNumB hbEqDenB
    hLeNumB (fun _ _ => Nat.one_le_two_pow) (fun _ => Nat.zero_le _) (fun _ => Nat.one_le_two_pow)
    hs7.2.1 hDim7 hRat7
  let res := solveRationalLP A_eq_num A_eq_den b_eq_num b_eq_den A_le_num A_le_den b_le_num b_le_den
  have hFlag_abs : res.1.natAbs ≤ 2 ^ K := by
    rw [← hFlag8]; exact storeBounded_read_abs hs8.2.1 _
  have hs9 := exec_write hctx hs8.2.1 0 (.lit 0) (.readHeap 30 (.lit 0))
    0 res.1 rfl (by rw [evalVal_readHeap, evalVal_lit, hFlag8]) (by omega) (by omega) hFlag_abs
  let ws9 := hWrite ws8 0 0 res.1; have hws9 : StoreBounded 31 maxIdx K ws9 := hs9.2.1
  have hSol9 : ∀ j : Fin nVars,
      hRead ws9 31 (2 * (j.val : ℤ)) = res.2.1 j ∧
      hRead ws9 31 (2 * (j.val : ℤ) + 1) = res.2.2 j := by
    intro j
    rw [hRead_hWrite_of_ne ws8 _ (Or.inl (by decide)),
        hRead_hWrite_of_ne ws8 _ (Or.inl (by decide))]
    exact hSol8 j
  obtain ⟨ws10, hpr10, hOut10, hs10⟩ := exec_copyVecOutStmt hctx h64
    (by omega : 0 + s ≤ nVars) h2nV 1 (Or.inl rfl) (.intParam (.lit 1)) (.lit 0)
    (by decide) (by decide) (by decide) (by decide) hps (fun _ => rfl)
    res.2.1 res.2.2 hws9 hSol9
  let m_extra := 20 + (nEq + s) * (5 + 3 * s) + D * (5 + 3 * s) + 4 * s
  have hLoadExec : ExecBit inp maxIdx K loadCertStmt UL.WordStore.empty ws7
      (m_extra * stepU) (m_extra * stepB K) :=
    (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps (hs5.seq_steps (hs6.seq_steps hs7)))))).mono_steps
      (Nat.le.intro (by dsimp [m_extra, nVars, nEq, nLe]; ring : _ + 3 = _))
  have hExecTot : ExecBit inp maxIdx K progCert UL.WordStore.empty ws10
      ((m_extra + solverStepBound nVars nEq nLe B' + (10 + 4 * nVars)) * stepU)
      ((m_extra + solverStepBound nVars nEq nLe B' + (10 + 4 * nVars)) * stepB K) :=
    (hLoadExec.seq_steps (hs8.seq_steps (hs9.seq_steps hs10))).mono_steps
      (by dsimp [nVars]; omega)
  obtain ⟨out, hRun, hout_ws, huCost, hbCost, hpCells, hpBits⟩ := hExecTot.to_runBitRAMWithBits
  -- Bound scaling: S = s + (D + 1) + s + B + 1 ≤ 2 * (D + s + B + 1)
  have hm_extra_le : m_extra ≤ 40 * (nVars + nEq + nLe + 1) ^ 2 := by
    dsimp [m_extra, nVars, nEq, nLe]
    exact Nat.le.intro (by
      ring : (20 + ((D + 1) + s) * (5 + 3 * s) + D * (5 + 3 * s) + 4 * s) +
        (135 + 150 * D + 308 * s + 154 * (D * s) + 40 * D ^ 2 + 157 * s ^ 2) =
        40 * (s + (D + 1) + s + 1) ^ 2)
  have hlenRat_le : (List.ofFn zRat ++ flatPts).length ≤ 4 * (nVars + nEq + nLe + 1) ^ 2 := by
    rw [List.length_append, List.length_ofFn, hFlatLen]; dsimp [nVars, nEq, nLe]
    exact Nat.le.intro (by
      ring : (D + s * D) +
        (16 + 15 * D + 32 * s + 15 * (s * D) + 4 * D ^ 2 + 16 * s ^ 2) =
        4 * (s + (D + 1) + s + 1) ^ 2)
  obtain ⟨hBU0, hBB0, hBC0, hBP0, hBK50⟩ := poly_solver_bounds nVars nEq nLe B
    m_extra 2 (List.ofFn zRat ++ flatPts).length hm_extra_le (by omega) hlenRat_le
  have hScale : 10 ^ 26 * (nVars + nEq + nLe + B + 1) ^ 22 ≤ bound :=
    cert_scale_bound D s B
  have hPure := solveRationalLP_spec hB'1
    A_eq_num A_eq_den b_eq_num b_eq_den A_le_num A_le_den b_le_num b_le_den
    hEqDenPos hbEqDenPos (fun _ _ => Int.zero_lt_one) (fun _ => Int.zero_lt_one)
    hEqNumB hEqDenB hbEqNumB hbEqDenB
    hLeNumB (fun _ _ => Nat.one_le_two_pow) (fun _ => Nat.zero_le _) (fun _ => Nat.one_le_two_pow)
  change (res.1 = 0 ∨ res.1 = 1) ∧ _ ∧ _ at hPure
  obtain ⟨hF01, hFIff, hFWhen1⟩ := hPure
  -- Equivalence of LP system over ℝ with IsConvexHullCert
  have hSysIff : ∀ w : Fin s → ℝ,
      ((∀ r : Fin nEq, ∑ j : Fin s, (((A_eq_num r j : ℚ) / (A_eq_den r j : ℚ) : ℚ) : ℝ) * w j =
          (((b_eq_num r : ℚ) / (b_eq_den r : ℚ) : ℚ) : ℝ)) ∧
       (∀ k : Fin s, ∑ j : Fin s, (((A_le_num k j : ℚ) / (A_le_den k j : ℚ) : ℚ) : ℝ) * w j ≤
          (((b_le_num k : ℚ) / (b_le_den k : ℚ) : ℚ) : ℝ))) ↔
      UL.IsConvexHullCert (fun j => UL.ratPointToEuclidean (pts j)) (UL.ratPointToEuclidean zRat) w := by
    intro w
    rw [isConvexHullCert_rat_iff]
    have hLeIff : ∀ k : Fin s,
        (∑ j : Fin s, (((A_le_num k j : ℚ) / (A_le_den k j : ℚ) : ℚ) : ℝ) * w j ≤
          (((b_le_num k : ℚ) / (b_le_den k : ℚ) : ℚ) : ℝ)) ↔ 0 ≤ w k := by
      intro k
      have hsum : ∑ j : Fin s, (((A_le_num k j : ℚ) / (A_le_den k j : ℚ) : ℚ) : ℝ) * w j = - w k := by
        have hterm : ∀ j : Fin s,
            (((A_le_num k j : ℚ) / (A_le_den k j : ℚ) : ℚ) : ℝ) * w j =
              if j = k then -w k else 0 := by
          intro j; dsimp [A_le_num, A_le_den]; split_ifs with h <;> subst_vars <;> simp
        rw [Finset.sum_congr rfl (fun j _ => hterm j)]; simp
      rw [hsum]; dsimp [b_le_num, b_le_den]; norm_num
    constructor
    · rintro ⟨hEq, hLe⟩
      refine ⟨fun k => (hLeIff k).mp (hLe k), ?_, fun c => ?_⟩
      · have hr := hEq (Fin.last D)
        have hn : ¬ ((Fin.last D).val < D) := by simp
        simpa [A_eq_num, A_eq_den, b_eq_num, b_eq_den, hn] using hr
      · have hr := hEq ⟨c.val, Nat.lt_succ_of_lt c.isLt⟩
        have hc : c.val < D := c.isLt
        simpa [A_eq_num, A_eq_den, b_eq_num, b_eq_den, hc, Rat.num_div_den, UL.ratPointToEuclidean] using hr
    · rintro ⟨hNonneg, hSum1, hCoords⟩
      refine ⟨fun r => ?_, fun k => (hLeIff k).mpr (hNonneg k)⟩
      by_cases hr : r.val < D
      · have hc := hCoords ⟨r.val, hr⟩
        simpa [A_eq_num, A_eq_den, b_eq_num, b_eq_den, hr, Rat.num_div_den, UL.ratPointToEuclidean] using hc
      · simpa [A_eq_num, A_eq_den, b_eq_num, b_eq_den, hr] using hSum1
  have hOutFlag : out.words.read (.heap 0 0) = res.1 := by
    rw [hout_ws]
    change hRead ws10 0 0 = res.1
    rw [hpr10 0 0 (by omega)]; exact hRead_hWrite_self ws8 0 0 res.1
  have hCellsLe : ctxPeakCells inp maxIdx ≤ 2 + 2 * (List.ofFn zRat ++ flatPts).length + 32 * (maxIdx + 1) := by
    dsimp [ctxPeakCells, inp]; rw [hInpCells]; simp
  have hBP0' : 2 * (K + 3) + (List.ofFn zRat ++ flatPts).length * (2 * K + 6) +
      32 * (maxIdx + 1) * (2 * K + 14) ≤ 10 ^ 26 * (nVars + nEq + nLe + B + 1) ^ 22 := hBP0
  have hBitsLe : ctxPeakBits inp maxIdx K ≤ bound := by
    dsimp [ctxPeakBits, inp]
    exact (Nat.add_le_add_right (by simpa using hInpBits) _).trans (hBP0'.trans hScale)
  refine ⟨out, hRun, huCost.trans (hBU0.trans hScale), hbCost.trans (hBB0.trans hScale),
    hpCells.trans (hCellsLe.trans (hBC0.trans hScale)),
    hpBits.trans hBitsLe,
    ?_, ?_, ?_⟩
  · rw [hOutFlag]; exact hF01
  · rw [hOutFlag]
    exact hFIff.trans (by unfold UL.HasConvexHullCert; exact exists_congr hSysIff)
  · intro h1
    rw [hOutFlag] at h1
    obtain ⟨hSolB, hEqSat, hLeSat⟩ := hFWhen1 h1
    have hBarK := bareiss_bound_le_two_pow_solverK nVars nEq nLe B'
    have hReadSol : ∀ j : Fin s,
        out.words.read (.heap 1 (2 * (j.val : ℤ))) = res.2.1 j ∧
        out.words.read (.heap 1 (2 * (j.val : ℤ) + 1)) = res.2.2 j := by
      intro j; rw [hout_ws]; simpa using hOut10 j
    refine ⟨fun j => ?_, ?_⟩
    · dsimp only; rw [(hReadSol j).1, (hReadSol j).2]
      obtain ⟨hpos, hnB, hdB⟩ := hSolB j
      obtain ⟨hb1, hb2, hb3, hb4⟩ :=
        rat_div_bit_bounds hpos (hnB.trans hBarK) (hdB.trans hBarK) (hBK50.trans hScale)
      exact ⟨hpos, hb1, hb2, hb3, hb4⟩
    · have hRS1 : ∀ j, out.words.read (.heap 1 (2 * (j.val : ℤ))) = res.2.1 j := fun j => (hReadSol j).1
      have hRS2 : ∀ j, out.words.read (.heap 1 (2 * (j.val : ℤ) + 1)) = res.2.2 j := fun j => (hReadSol j).2
      apply (hSysIff _).mp
      simp only [hRS1, hRS2]
      exact ⟨fun r => by exact_mod_cast hEqSat r, fun k => by exact_mod_cast hLeSat k⟩

/-! ### 7. Part 2: Common Convex-Hull Point LP (`progHull`) -/

theorem div_mod_of_lt_mul {k r W : ℕ} (h : k < r * W) :
    0 < W ∧ k / W < r ∧ k % W < W ∧ (k / W) * W + k % W = k := by
  have hW : 0 < W := by
    by_contra h0
    have hW0 : W = 0 := by omega
    subst hW0; simp at h
  have hmod : k % W < W := Nat.mod_lt k hW
  have hdivmod : (k / W) * W + k % W = k := by
    rw [Nat.mul_comm, Nat.div_add_mod]
  have hdiv : k / W < r := by
    by_contra hge
    have hrle : r ≤ k / W := by omega
    have hmul : r * W ≤ (k / W) * W := Nat.mul_le_mul_right W hrle
    omega
  exact ⟨hW, hdiv, hmod, hdivmod⟩

theorem div_mod_encode_eq {r W : ℕ} (i : Fin r) (j : Fin W) :
    (i.val * W + j.val) / W = i.val ∧ (i.val * W + j.val) % W = j.val := by
  have hlt : i.val * W + j.val < r * W := row_col_lt_mul i.isLt j.isLt
  obtain ⟨_, _, hmod, heq⟩ := div_mod_of_lt_mul hlt
  exact row_col_inj hmod j.isLt heq

def hullLoadBlockPtsStmt : UL.BitRAMStmt :=
  let DE := UL.IntExpr.intParam (.lit 0)
  let sE := UL.IntExpr.intParam (.lit 2)
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let iE := UL.IntExpr.readHeap 10 (.lit 40)
  let jE := UL.IntExpr.readHeap 10 (.lit 41)
  let cE := UL.IntExpr.readHeap 10 (.lit 42)
  let rowE := UL.IntExpr.add (.mul iE DE) cE
  let colE := UL.IntExpr.add DE (.add (.mul iE sE) jE)
  let dstE := UL.IntExpr.add (.mul rowE nVarsE) colE
  let srcE := UL.IntExpr.add (.mul (.add (.mul iE sE) jE) DE) cE
  forLoopStmt 41 sE
    (forLoopStmt 42 DE
      (seqBitStmts
        [ .writeHeap 11 dstE (.extraRatNum srcE)
        , .writeHeap 12 dstE (.extraRatDen srcE) ]))

theorem exec_hullLoadBlockPtsStmt {inp : UL.BitRAMInput 0}
    {D r s maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : D ≤ maxIdx ∧ s ≤ maxIdx ∧ (r * D + r) * (D + r * s) ≤ maxIdx)
    (hpD : ∀ ws, evalVal inp ws (.intParam (.lit 0)) = (D : ℤ))
    (hps : ∀ ws, evalVal inp ws (.intParam (.lit 2)) = (s : ℤ))
    (pts : Fin r → Fin s → Fin D → ℚ)
    (hGetPt : ∀ (i : Fin r) (j : Fin s) (c : Fin D),
      inp.extraRats.getD ((i.val * s + j.val) * D + c.val) 0 = pts i j c)
    (hPtK : ∀ i j c, (pts i j c).num.natAbs ≤ 2 ^ K ∧ (pts i j c).den ≤ 2 ^ K)
    (i : Fin r)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hnV_ws : hRead ws₀ 10 0 = ((D + r * s : ℕ) : ℤ))
    (hi_ws : hRead ws₀ 10 40 = (i.val : ℤ)) :
    let nVars := D + r * s
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (idx = 41 ∨ idx = 42)) ∨
      ((t_id = 11 ∨ t_id = 12) ∧
        ∃ (j : Fin s) (c : Fin D),
          idx = (((i.val * D + c.val) * nVars + (D + (i.val * s + j.val)) : ℕ) : ℤ))
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ (j : Fin s) (c : Fin D),
        hRead ws₁ 11 (((i.val * D + c.val) * nVars + (D + (i.val * s + j.val)) : ℕ) : ℤ) = (pts i j c).num ∧
        hRead ws₁ 12 (((i.val * D + c.val) * nVars + (D + (i.val * s + j.val)) : ℕ) : ℤ) = ((pts i j c).den : ℤ)) ∧
      ExecBit inp maxIdx K hullLoadBlockPtsStmt ws₀ ws₁
        ((2 + s * (3 + 3 * D)) * stepU) ((2 + s * (3 + 3 * D)) * stepB K) := by
  intro nVars mod
  let PJ : ℕ → UL.WordStore → Prop := fun J ws =>
    ∀ (j : Fin s), j.val < J → ∀ (c : Fin D),
      hRead ws 11 (((i.val * D + c.val) * nVars + (D + (i.val * s + j.val)) : ℕ) : ℤ) = (pts i j c).num ∧
      hRead ws 12 (((i.val * D + c.val) * nVars + (D + (i.val * s + j.val)) : ℕ) : ℤ) = ((pts i j c).den : ℤ)
  obtain ⟨ws₁, hpr₁, hDone₁, hex₁⟩ := exec_for_frame hctx 41 (.intParam (.lit 2))
    (forLoopStmt 42 (.intParam (.lit 0))
      (seqBitStmts
        [ .writeHeap 11
            (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                        (.readHeap 10 (.lit 0)))
                  (.add (.intParam (.lit 0))
                        (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2))) (.readHeap 10 (.lit 41)))))
            (.extraRatNum (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2)))
                                            (.readHeap 10 (.lit 41))) (.intParam (.lit 0)))
                                (.readHeap 10 (.lit 42))))
        , .writeHeap 12
            (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                        (.readHeap 10 (.lit 0)))
                  (.add (.intParam (.lit 0))
                        (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2))) (.readHeap 10 (.lit 41)))))
            (.extraRatDen (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2)))
                                            (.readHeap 10 (.lit 41))) (.intParam (.lit 0)))
                                (.readHeap 10 (.lit 42)))) ]))
    s (2 + 3 * D) mod PJ hws₀ (by omega) hIdx.2.1
    (by dsimp [mod]; omega)
    (fun J ws v => by
      dsimp [PJ]; constructor <;> intro h j hj c
      · obtain ⟨a, b0⟩ := h j hj c; rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at a b0; exact ⟨a, b0⟩
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide)),
            hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h j hj c)
    (hps _) (fun _ h _ => False.elim (Nat.not_lt_zero _ h))
    (fun j hj ws hws hctr_j hpr_j hprev_j => by
      let jFin : Fin s := ⟨j, hj⟩
      let modC : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 42) ∨
        ((t_id = 11 ∨ t_id = 12) ∧
          ∃ c : Fin D, idx = (((i.val * D + c.val) * nVars + (D + (i.val * s + j)) : ℕ) : ℤ))
      let PC : ℕ → UL.WordStore → Prop := fun C wsi =>
        ∀ (c : Fin D), c.val < C →
          hRead wsi 11 (((i.val * D + c.val) * nVars + (D + (i.val * s + j)) : ℕ) : ℤ) = (pts i jFin c).num ∧
          hRead wsi 12 (((i.val * D + c.val) * nVars + (D + (i.val * s + j)) : ℕ) : ℤ) = ((pts i jFin c).den : ℤ)
      obtain ⟨ws_in, hprIn, hDoneIn, hexIn⟩ := exec_for_frame hctx 42 (.intParam (.lit 0))
        (seqBitStmts
          [ .writeHeap 11
              (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                          (.readHeap 10 (.lit 0)))
                    (.add (.intParam (.lit 0))
                          (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2))) (.readHeap 10 (.lit 41)))))
              (.extraRatNum (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2)))
                                              (.readHeap 10 (.lit 41))) (.intParam (.lit 0)))
                                  (.readHeap 10 (.lit 42))))
          , .writeHeap 12
              (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                          (.readHeap 10 (.lit 0)))
                    (.add (.intParam (.lit 0))
                          (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2))) (.readHeap 10 (.lit 41)))))
              (.extraRatDen (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2)))
                                              (.readHeap 10 (.lit 41))) (.intParam (.lit 0)))
                                  (.readHeap 10 (.lit 42)))) ]) D 2 modC PC hws (by omega) hIdx.1
        (by dsimp [modC]; omega)
        (fun C wsi v => by
          dsimp [PC]; constructor <;> intro h c hc
          · obtain ⟨a, b0⟩ := h c hc; rw [hRead_hWrite_of_ne wsi v (Or.inl (by decide))] at a b0; exact ⟨a, b0⟩
          · rw [hRead_hWrite_of_ne wsi v (Or.inl (by decide)),
                hRead_hWrite_of_ne wsi v (Or.inl (by decide))]; exact h c hc)
        (hpD _) (fun _ h => False.elim (Nat.not_lt_zero _ h))
        (fun c hc wsi hwsi hctr_c hpr_c hprev_c => by
          let cFin : Fin D := ⟨c, hc⟩
          have hrow_lt : i.val * D + c < r * D + r :=
            lt_of_lt_of_le (row_col_lt_mul i.isLt hc) (Nat.le_add_right _ _)
          have hcol_lt : D + (i.val * s + j) < nVars := by
            dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt hj) D
          have hdst_le : (i.val * D + c) * nVars + (D + (i.val * s + j)) ≤ maxIdx :=
            (row_col_lt_mul hrow_lt hcol_lt).le.trans hIdx.2.2
          have hi_w : hRead wsi 10 40 = (i.val : ℤ) := by
            rw [hpr_c 10 40 (by dsimp [modC]; omega), hpr_j 10 40 (by dsimp [mod]; omega), hi_ws]
          have hj_w : hRead wsi 10 41 = (j : ℤ) := by
            rw [hpr_c 10 41 (by dsimp [modC]; omega), hctr_j]
          have hnV_w : hRead wsi 10 0 = (nVars : ℤ) := by
            rw [hpr_c 10 0 (by dsimp [modC]; omega), hpr_j 10 0 (by dsimp [mod]; omega), hnV_ws]
          let dstNat := (i.val * D + c) * nVars + (D + (i.val * s + j))
          let srcNat := (i.val * s + j) * D + c
          have hdst_eq : ((i.val : ℤ) * (D : ℤ) + (c : ℤ)) * (nVars : ℤ) +
              ((D : ℤ) + ((i.val : ℤ) * (s : ℤ) + (j : ℤ))) = (dstNat : ℤ) :=
            by exact_mod_cast (rfl : (i.val * D + c) * nVars + (D + (i.val * s + j)) = dstNat)
          have hsrc_eq : ((i.val : ℤ) * (s : ℤ) + (j : ℤ)) * (D : ℤ) + (c : ℤ) = (srcNat : ℤ) :=
            by exact_mod_cast (rfl : (i.val * s + j) * D + c = srcNat)
          have hwa1 := exec_write hctx hwsi 11
            (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                        (.readHeap 10 (.lit 0)))
                  (.add (.intParam (.lit 0))
                        (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2))) (.readHeap 10 (.lit 41)))))
            (.extraRatNum (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2)))
                                            (.readHeap 10 (.lit 41))) (.intParam (.lit 0)))
                                (.readHeap 10 (.lit 42))))
            (dstNat : ℤ) (pts i jFin cFin).num
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
                  hi_w, hpD wsi, hctr_c, hnV_w, hps wsi, hj_w, hdst_eq])
            (by simp only [evalVal_extraRatNum, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
                  hi_w, hps wsi, hj_w, hpD wsi, hctr_c, hsrc_eq, listGetIntD_nat]
                exact congrArg Rat.num (hGetPt i jFin cFin))
            (Nat.cast_nonneg _) (Nat.cast_le.mpr hdst_le) (hPtK i jFin cFin).1
          let wsa1 := hWrite wsi 11 (dstNat : ℤ) (pts i jFin cFin).num
          have hwsa1 : StoreBounded 31 maxIdx K wsa1 := hwa1.2.1
          have hi_a1 : hRead wsa1 10 40 = (i.val : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by decide)), hi_w]
          have hj_a1 : hRead wsa1 10 41 = (j : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by decide)), hj_w]
          have hc_a1 : hRead wsa1 10 42 = (c : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by decide)), hctr_c]
          have hnV_a1 : hRead wsa1 10 0 = (nVars : ℤ) := by
            rw [hRead_hWrite_of_ne wsi _ (Or.inl (by decide)), hnV_w]
          have hwa2 := exec_write hctx hwsa1 12
            (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                        (.readHeap 10 (.lit 0)))
                  (.add (.intParam (.lit 0))
                        (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2))) (.readHeap 10 (.lit 41)))))
            (.extraRatDen (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2)))
                                            (.readHeap 10 (.lit 41))) (.intParam (.lit 0)))
                                (.readHeap 10 (.lit 42))))
            (dstNat : ℤ) ((pts i jFin cFin).den : ℤ)
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
                  hi_a1, hpD wsa1, hc_a1, hnV_a1, hps wsa1, hj_a1, hdst_eq])
            (by simp only [evalVal_extraRatDen, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
                  hi_a1, hps wsa1, hj_a1, hpD wsa1, hc_a1, hsrc_eq, listGetIntD_nat]
                exact congrArg (fun q : ℚ => (q.den : ℤ)) (hGetPt i jFin cFin))
            (Nat.cast_nonneg _) (Nat.cast_le.mpr hdst_le) (by simpa using (hPtK i jFin cFin).2)
          refine ⟨_, hwa1.seq_steps hwa2, ?_,
            (hpr_c.trans (PreservesOutside.write wsi _ (Or.inr ⟨Or.inl rfl, cFin, rfl⟩))).trans
              (PreservesOutside.write wsa1 _ (Or.inr ⟨Or.inr rfl, cFin, rfl⟩)), ?_⟩
          · rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by decide)), hc_a1]
          · intro c' hc'
            rcases (show c'.val < c ∨ c'.val = c by omega) with hlt | heq
            · have hne_c : (((i.val * D + c'.val) * nVars + (D + (i.val * s + j)) : ℕ) : ℤ) ≠ (dstNat : ℤ) := by
                intro h
                have ⟨hrow_eq, _⟩ := row_col_inj hcol_lt hcol_lt (Int.ofNat.inj h)
                omega
              rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by decide)),
                  hRead_hWrite_of_ne wsi _ (Or.inr hne_c),
                  hRead_hWrite_of_ne wsa1 _ (Or.inr hne_c),
                  hRead_hWrite_of_ne wsi _ (Or.inl (by decide))]
              exact hprev_c c' hlt
            · have hc_eq : c' = cFin := Fin.ext heq; subst hc_eq
              exact ⟨by rw [hRead_hWrite_of_ne wsa1 _ (Or.inl (by decide))]
                        exact hRead_hWrite_self wsi 11 _ _,
                     hRead_hWrite_self wsa1 12 _ _⟩)
      have hpr_step : PreservesOutside mod ws₀ ws_in :=
        hpr_j.trans (hprIn.mono (by
          intro t idx h; dsimp [modC] at h; dsimp [mod]
          rcases h with ⟨rfl, rfl⟩ | ⟨ht, cFin, rfl⟩
          · exact Or.inl ⟨rfl, Or.inr rfl⟩
          · exact Or.inr ⟨ht, jFin, cFin, rfl⟩))
      refine ⟨ws_in, hexIn.mono_steps (by omega), ?_, hpr_step, ?_⟩
      · rw [hprIn 10 41 (by dsimp [modC]; omega), hctr_j]
      · intro j' hj' c'
        rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
        · have hnot_c : ∀ t_id, (t_id = 11 ∨ t_id = 12) →
              ¬ modC t_id (((i.val * D + c'.val) * nVars + (D + (i.val * s + j'.val)) : ℕ) : ℤ) := by
            rintro t_id _ (⟨h, _⟩ | ⟨_, c0, hidx⟩)
            · omega
            · have hc1 : D + (i.val * s + j'.val) < nVars := by
                dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j'.isLt) D
              have hc2 : D + (i.val * s + j) < nVars := by
                dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt hj) D
              obtain ⟨_, hcol_eq⟩ := row_col_inj hc1 hc2 (Int.ofNat.inj hidx)
              omega
          rw [hprIn 11 _ (hnot_c 11 (Or.inl rfl)), hprIn 12 _ (hnot_c 12 (Or.inr rfl))]
          exact hprev_j j' hlt c'
        · have hj_eq : j' = jFin := Fin.ext heq; subst hj_eq
          exact hDoneIn c' c'.isLt)
  exact ⟨ws₁, hpr₁, fun j c => hDone₁ j j.isLt c, hex₁.mono_steps (le_of_eq (by ring))⟩

def hullAEq_num {D r s : ℕ} (pts : Fin r → Fin s → Fin D → ℚ)
    (row : Fin (r * D + r)) (v : Fin (D + r * s)) : ℤ :=
  if hrow : row.val < r * D then
    let hd := div_mod_of_lt_mul hrow
    let i : Fin r := ⟨row.val / D, hd.2.1⟩
    let c : Fin D := ⟨row.val % D, hd.2.2.1⟩
    if hv : v.val < D then
      if v.val = c.val then -1 else 0
    else
      let hvs : v.val - D < r * s := by omega
      let hds := div_mod_of_lt_mul hvs
      let i' : Fin r := ⟨(v.val - D) / s, hds.2.1⟩
      let j' : Fin s := ⟨(v.val - D) % s, hds.2.2.1⟩
      if i' = i then (pts i j' c).num else 0
  else
    let i : Fin r := ⟨row.val - r * D, by omega⟩
    if hv : v.val < D then 0
    else
      let hvs : v.val - D < r * s := by omega
      let hds := div_mod_of_lt_mul hvs
      let i' : Fin r := ⟨(v.val - D) / s, hds.2.1⟩
      if i' = i then 1 else 0

def hullAEq_den {D r s : ℕ} (pts : Fin r → Fin s → Fin D → ℚ)
    (row : Fin (r * D + r)) (v : Fin (D + r * s)) : ℤ :=
  if hrow : row.val < r * D then
    let hd := div_mod_of_lt_mul hrow
    let i : Fin r := ⟨row.val / D, hd.2.1⟩
    let c : Fin D := ⟨row.val % D, hd.2.2.1⟩
    if hv : v.val < D then 1
    else
      let hvs : v.val - D < r * s := by omega
      let hds := div_mod_of_lt_mul hvs
      let i' : Fin r := ⟨(v.val - D) / s, hds.2.1⟩
      let j' : Fin s := ⟨(v.val - D) % s, hds.2.2.1⟩
      if i' = i then ((pts i j' c).den : ℤ) else 1
  else 1

def hullbEq_num {D r : ℕ} (row : Fin (r * D + r)) : ℤ :=
  if row.val < r * D then 0 else 1

def hullbEq_den {D r : ℕ} (_ : Fin (r * D + r)) : ℤ := 1

def hullALe_num {D r s : ℕ} (k : Fin (r * s)) (v : Fin (D + r * s)) : ℤ :=
  if v.val = D + k.val then -1 else 0

def hullALe_den {D r s : ℕ} (_ : Fin (r * s)) (_ : Fin (D + r * s)) : ℤ := 1

def hullbLe_num {r s : ℕ} (_ : Fin (r * s)) : ℤ := 0
def hullbLe_den {r s : ℕ} (_ : Fin (r * s)) : ℤ := 1

/-- Predicate that block `i < r` corresponds to rows `[i * D, (i + 1) * D)` and row `r * D + i`. -/
def RowOfBlock (D r i row : ℕ) : Prop :=
  (i * D ≤ row ∧ row < (i + 1) * D) ∨ row = r * D + i

theorem rowOfBlock_disjoint {D r i₁ i₂ row : ℕ} (hi₁ : i₁ < r) (hi₂ : i₂ < r) (hne : i₁ ≠ i₂)
    (h1 : RowOfBlock D r i₁ row) (h2 : RowOfBlock D r i₂ row) : False := by
  dsimp [RowOfBlock] at h1 h2
  have hlt1 : (i₁ + 1) * D ≤ r * D := Nat.mul_le_mul_right D hi₁
  have hlt2 : (i₂ + 1) * D ≤ r * D := Nat.mul_le_mul_right D hi₂
  rcases h1 with ⟨ha1, hb1⟩ | rfl
  · rcases h2 with ⟨ha2, hb2⟩ | rfl
    · rcases lt_trichotomy i₁ i₂ with h | h | h
      · have : (i₁ + 1) * D ≤ i₂ * D := Nat.mul_le_mul_right D h
        omega
      · exact hne h
      · have : (i₂ + 1) * D ≤ i₁ * D := Nat.mul_le_mul_right D h
        omega
    · omega
  · rcases h2 with ⟨ha2, hb2⟩ | heq
    · omega
    · omega

def hullInitBlockStmt : UL.BitRAMStmt :=
  let DE := UL.IntExpr.intParam (.lit 0)
  let rE := UL.IntExpr.intParam (.lit 1)
  let sE := UL.IntExpr.intParam (.lit 2)
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let iE := UL.IntExpr.readHeap 10 (.lit 40)
  let kE := UL.IntExpr.readHeap 10 (.lit 42)
  let rowCE := UL.IntExpr.add (.mul iE DE) kE
  let sumRowE := UL.IntExpr.add (.mul rE DE) iE
  seqBitStmts
    [ forLoopStmt 42 DE
        (.writeHeap 11 (.add (.mul rowCE nVarsE) kE) (.lit (-1)))
    , hullLoadBlockPtsStmt
    , .writeHeap 13 sumRowE (.lit 1)
    , forLoopStmt 42 sE
        (.writeHeap 11
          (.add (.mul sumRowE nVarsE) (.add DE (.add (.mul iE sE) kE)))
          (.lit 1)) ]

theorem exec_hullInitBlockStmt {inp : UL.BitRAMInput 0}
    {D r s maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : D ≤ maxIdx ∧ s ≤ maxIdx ∧ r * D + r ≤ maxIdx ∧ (r * D + r) * (D + r * s) ≤ maxIdx)
    (hpD : ∀ ws, evalVal inp ws (.intParam (.lit 0)) = (D : ℤ))
    (hpr : ∀ ws, evalVal inp ws (.intParam (.lit 1)) = (r : ℤ))
    (hps : ∀ ws, evalVal inp ws (.intParam (.lit 2)) = (s : ℤ))
    (pts : Fin r → Fin s → Fin D → ℚ)
    (hGetPt : ∀ (i : Fin r) (j : Fin s) (c : Fin D),
      inp.extraRats.getD ((i.val * s + j.val) * D + c.val) 0 = pts i j c)
    (hPtK : ∀ i j c, (pts i j c).num.natAbs ≤ 2 ^ K ∧ (pts i j c).den ≤ 2 ^ K)
    (i : Fin r)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hnV_ws : hRead ws₀ 10 0 = ((D + r * s : ℕ) : ℤ))
    (hi_ws : hRead ws₀ 10 40 = (i.val : ℤ))
    (hZero_i : ∀ (row : Fin (r * D + r)), RowOfBlock D r i.val row.val →
      (∀ v : Fin (D + r * s),
        hRead ws₀ 11 ((row.val * (D + r * s) + v.val : ℕ) : ℤ) = 0 ∧
        hRead ws₀ 12 ((row.val * (D + r * s) + v.val : ℕ) : ℤ) = 1) ∧
      (hRead ws₀ 13 (row.val : ℤ) = 0 ∧ hRead ws₀ 14 (row.val : ℤ) = 1)) :
    let nVars := D + r * s
    let nEq := r * D + r
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (idx = 41 ∨ idx = 42)) ∨
      ((t_id = 11 ∨ t_id = 12) ∧
        ∃ (row : Fin nEq) (v : Fin nVars),
          RowOfBlock D r i.val row.val ∧ idx = ((row.val * nVars + v.val : ℕ) : ℤ)) ∨
      (t_id = 13 ∧ idx = ((r * D + i.val : ℕ) : ℤ))
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ (row : Fin nEq), RowOfBlock D r i.val row.val →
        (∀ v : Fin nVars,
          hRead ws₁ 11 ((row.val * nVars + v.val : ℕ) : ℤ) = hullAEq_num pts row v ∧
          hRead ws₁ 12 ((row.val * nVars + v.val : ℕ) : ℤ) = hullAEq_den pts row v) ∧
        (hRead ws₁ 13 (row.val : ℤ) = hullbEq_num row ∧
         hRead ws₁ 14 (row.val : ℤ) = hullbEq_den row)) ∧
      ExecBit inp maxIdx K hullInitBlockStmt ws₀ ws₁
        ((10 + 2 * D + s * (5 + 3 * D)) * stepU) ((10 + 2 * D + s * (5 + 3 * D)) * stepB K) := by
  intro nVars nEq mod
  -- Substep 1: write -1 at (i * D + c, c) for c < D
  let mod1 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨
    (t_id = 11 ∧ ∃ c : Fin D, idx = (((i.val * D + c.val) * nVars + c.val : ℕ) : ℤ))
  let P1 : ℕ → UL.WordStore → Prop := fun C ws =>
    ∀ (c c' : Fin D),
      hRead ws 11 (((i.val * D + c.val) * nVars + c'.val : ℕ) : ℤ) =
        if c.val < C ∧ c' = c then -1 else 0
  have hP1_0 : P1 0 ws₀ := by
    intro c c'
    simp only [Nat.not_lt_zero, false_and, ↓reduceIte]
    have hrow_lt : i.val * D + c.val < nEq :=
      lt_of_lt_of_le (row_col_lt_mul i.isLt c.isLt) (Nat.le_add_right _ _)
    have hrob : RowOfBlock D r i.val (i.val * D + c.val) := by
      left; refine ⟨Nat.le_add_right _ _, ?_⟩
      calc i.val * D + c.val < i.val * D + D := Nat.add_lt_add_left c.isLt _
        _ = (i.val + 1) * D := by ring
    exact ((hZero_i ⟨i.val * D + c.val, hrow_lt⟩ hrob).1 ⟨c'.val, by omega⟩).1
  obtain ⟨ws1, hpr1, hDone1, hs1⟩ := exec_for_frame hctx 42 (.intParam (.lit 0))
    (.writeHeap 11
      (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                  (.readHeap 10 (.lit 0)))
            (.readHeap 10 (.lit 42)))
      (.lit (-1)))
    D 1 mod1 P1 hws₀ (by omega) hIdx.1
    (by dsimp [mod1]; omega)
    (fun C ws v => by
      dsimp [P1]; constructor <;> intro h c c'
      · have := h c c'; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h c c')
    (hpD _) hP1_0
    (fun c hc ws hws hctr_c hpr_c hprev_c => by
      let cFin : Fin D := ⟨c, hc⟩
      have hrow_lt : i.val * D + c < nEq :=
        lt_of_lt_of_le (row_col_lt_mul i.isLt hc) (Nat.le_add_right _ _)
      have hcol_lt : c < nVars := by dsimp [nVars]; omega
      have hdst_le : (i.val * D + c) * nVars + c ≤ maxIdx :=
        (row_col_lt_mul hrow_lt hcol_lt).le.trans hIdx.2.2.2
      have hi_w : hRead ws 10 40 = (i.val : ℤ) := by
        rw [hpr_c 10 40 (by dsimp [mod1]; omega), hi_ws]
      have hnV_w : hRead ws 10 0 = (nVars : ℤ) := by
        rw [hpr_c 10 0 (by dsimp [mod1]; omega), hnV_ws]
      have hw := exec_write hctx hws 11
        (.add (.mul (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 0))) (.readHeap 10 (.lit 42)))
                    (.readHeap 10 (.lit 0)))
              (.readHeap 10 (.lit 42)))
        (.lit (-1)) (((i.val * D + c) * nVars + c : ℕ) : ℤ) (-1)
        (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_w, hpD ws, hctr_c, hnV_w]
            exact_mod_cast (rfl : (i.val * D + c) * nVars + c = (i.val * D + c) * nVars + c))
        rfl (Nat.cast_nonneg _) (Nat.cast_le.mpr hdst_le) Nat.one_le_two_pow
      refine ⟨_, hw, ?_, hpr_c.trans (PreservesOutside.write ws _ (Or.inr ⟨rfl, cFin, rfl⟩)), ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by decide))]; exact hctr_c
      · intro c₁ c₂
        by_cases heq_idx : (i.val * D + c₁.val) * nVars + c₂.val = (i.val * D + c) * nVars + c
        · have hc₂_lt : c₂.val < nVars := by dsimp [nVars]; omega
          obtain ⟨hreq, hc₂eq⟩ := row_col_inj hc₂_lt hcol_lt heq_idx
          have hc₁eq : c₁.val = c := by omega
          have hc_eq : c₂ = c₁ := Fin.ext (hc₂eq.trans hc₁eq.symm)
          rw [if_pos ⟨by omega, hc_eq⟩]; simp only [heq_idx]
          exact hRead_hWrite_self ws 11 _ (-1)
        · have hne_z : (((i.val * D + c₁.val) * nVars + c₂.val : ℕ) : ℤ) ≠
              (((i.val * D + c) * nVars + c : ℕ) : ℤ) := fun h => heq_idx (Int.ofNat.inj h)
          rw [hRead_hWrite_of_ne ws _ (Or.inr hne_z), hprev_c c₁ c₂]
          by_cases hcc : c₂ = c₁
          · have hne_c : c₁.val ≠ c := fun h => heq_idx (by rw [hcc, h])
            have hiff : (c₁.val < c ↔ c₁.val < c + 1) := by omega
            simp [hcc, hiff]
          · simp [hcc])
  -- Substep 2: hullLoadBlockPtsStmt
  have hnV_ws1 : hRead ws1 10 0 = (nVars : ℤ) := by
    rw [hpr1 10 0 (by dsimp [mod1]; omega), hnV_ws]
  have hi_ws1 : hRead ws1 10 40 = (i.val : ℤ) := by
    rw [hpr1 10 40 (by dsimp [mod1]; omega), hi_ws]
  obtain ⟨ws2, hpr2, hPts2, hs2⟩ := exec_hullLoadBlockPtsStmt hctx h64
    ⟨hIdx.1, hIdx.2.1, hIdx.2.2.2⟩ hpD hps pts hGetPt hPtK i hs1.2.1 hnV_ws1 hi_ws1
  -- Substep 3: write 13[r * D + i] := 1
  have hi_ws2 : hRead ws2 10 40 = (i.val : ℤ) := by
    rw [hpr2 10 40 (by omega), hi_ws1]
  have hsumRow_le : r * D + i.val ≤ maxIdx :=
    (Nat.add_le_add_left i.isLt.le (r * D)).trans hIdx.2.2.1
  have hs3 := exec_write hctx hs2.2.1 13
    (.add (.mul (.intParam (.lit 1)) (.intParam (.lit 0))) (.readHeap 10 (.lit 40))) (.lit 1)
    ((r * D + i.val : ℕ) : ℤ) 1
    (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hpr ws2, hpD ws2, hi_ws2]
        exact_mod_cast (rfl : r * D + i.val = r * D + i.val))
    rfl (Nat.cast_nonneg _) (Nat.cast_le.mpr hsumRow_le) Nat.one_le_two_pow
  let ws3 := hWrite ws2 13 ((r * D + i.val : ℕ) : ℤ) 1
  have hws3 : StoreBounded 31 maxIdx K ws3 := hs3.2.1
  -- Substep 4: write 11[(r * D + i) * nVars + (D + i * s + j)] := 1 for j < s
  let mod4 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨
    (t_id = 11 ∧ ∃ j : Fin s, idx = (((r * D + i.val) * nVars + (D + (i.val * s + j.val)) : ℕ) : ℤ))
  let P4 : ℕ → UL.WordStore → Prop := fun J ws =>
    ∀ j : Fin s, j.val < J →
      hRead ws 11 (((r * D + i.val) * nVars + (D + (i.val * s + j.val)) : ℕ) : ℤ) = 1
  obtain ⟨ws4, hpr4, hDone4, hs4⟩ := exec_for_frame hctx 42 (.intParam (.lit 2))
    (.writeHeap 11
      (.add (.mul (.add (.mul (.intParam (.lit 1)) (.intParam (.lit 0))) (.readHeap 10 (.lit 40)))
                  (.readHeap 10 (.lit 0)))
            (.add (.intParam (.lit 0))
                  (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2))) (.readHeap 10 (.lit 42)))))
      (.lit 1))
    s 1 mod4 P4 hws3 (by omega) hIdx.2.1
    (by dsimp [mod4]; omega)
    (fun J ws v => by
      dsimp [P4]; constructor <;> intro h j hj
      · have := h j hj; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h j hj)
    (hps _) (fun _ h => False.elim (Nat.not_lt_zero _ h))
    (fun j hj ws hws hctr_j hpr_j hprev_j => by
      let jFin : Fin s := ⟨j, hj⟩
      have hr_lt : r * D + i.val < nEq := by dsimp [nEq]; omega
      have hc_lt : D + (i.val * s + j) < nVars := by
        dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt hj) D
      have hdst_le : (r * D + i.val) * nVars + (D + (i.val * s + j)) ≤ maxIdx :=
        (row_col_lt_mul hr_lt hc_lt).le.trans hIdx.2.2.2
      have hi_w : hRead ws 10 40 = (i.val : ℤ) := by
        rw [hpr_j 10 40 (by dsimp [mod4]; omega),
            hRead_hWrite_of_ne ws2 _ (Or.inl (by decide)), hi_ws2]
      have hnV_w : hRead ws 10 0 = (nVars : ℤ) := by
        rw [hpr_j 10 0 (by dsimp [mod4]; omega),
            hRead_hWrite_of_ne ws2 _ (Or.inl (by decide)),
            hpr2 10 0 (by omega), hnV_ws1]
      have hw := exec_write hctx hws 11
        (.add (.mul (.add (.mul (.intParam (.lit 1)) (.intParam (.lit 0))) (.readHeap 10 (.lit 40)))
                    (.readHeap 10 (.lit 0)))
              (.add (.intParam (.lit 0))
                    (.add (.mul (.readHeap 10 (.lit 40)) (.intParam (.lit 2))) (.readHeap 10 (.lit 42)))))
        (.lit 1) (((r * D + i.val) * nVars + (D + (i.val * s + j)) : ℕ) : ℤ) 1
        (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
              hpr ws, hpD ws, hi_w, hnV_w, hps ws, hctr_j]
            exact_mod_cast (rfl : (r * D + i.val) * nVars + (D + (i.val * s + j)) =
              (r * D + i.val) * nVars + (D + (i.val * s + j))))
        rfl (Nat.cast_nonneg _) (Nat.cast_le.mpr hdst_le) Nat.one_le_two_pow
      refine ⟨_, hw, ?_, hpr_j.trans (PreservesOutside.write ws _ (Or.inr ⟨rfl, jFin, rfl⟩)), ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by decide))]; exact hctr_j
      · intro j' hj'
        rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]; exact hprev_j j' hlt
        · have hj_eq : j' = jFin := Fin.ext heq; subst hj_eq
          exact hRead_hWrite_self ws 11 _ 1)
  -- Combine PreservesOutside mod ws₀ ws4
  have hpr1_mod : PreservesOutside mod ws₀ ws1 :=
    hpr1.mono (by
      intro t idx h; dsimp [mod1] at h; dsimp [mod]
      rcases h with ⟨rfl, rfl⟩ | ⟨rfl, c, rfl⟩
      · exact Or.inl ⟨rfl, Or.inr rfl⟩
      · refine Or.inr (Or.inl ⟨Or.inl rfl, ⟨i.val * D + c.val,
            lt_of_lt_of_le (row_col_lt_mul i.isLt c.isLt) (Nat.le_add_right _ _)⟩,
          ⟨c.val, by dsimp [nVars]; omega⟩, ?_, rfl⟩)
        left; refine ⟨Nat.le_add_right _ _, ?_⟩
        calc i.val * D + c.val < i.val * D + D := Nat.add_lt_add_left c.isLt _
          _ = (i.val + 1) * D := by ring)
  have hpr2_mod : PreservesOutside mod ws1 ws2 :=
    hpr2.mono (by
      intro t idx h; dsimp [mod]
      rcases h with ⟨rfl, h1⟩ | ⟨ht, j, c, rfl⟩
      · exact Or.inl ⟨rfl, h1⟩
      · refine Or.inr (Or.inl ⟨ht, ⟨i.val * D + c.val,
            lt_of_lt_of_le (row_col_lt_mul i.isLt c.isLt) (Nat.le_add_right _ _)⟩,
          ⟨D + (i.val * s + j.val), by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩,
          ?_, rfl⟩)
        left; refine ⟨Nat.le_add_right _ _, ?_⟩
        calc i.val * D + c.val < i.val * D + D := Nat.add_lt_add_left c.isLt _
          _ = (i.val + 1) * D := by ring)
  have hpr3_mod : PreservesOutside mod ws2 ws3 :=
    PreservesOutside.write (mod := mod) ws2 1 (by dsimp [mod]; exact Or.inr (Or.inr ⟨rfl, rfl⟩))
  have hpr4_mod : PreservesOutside mod ws3 ws4 :=
    hpr4.mono (by
      intro t idx h; dsimp [mod4] at h; dsimp [mod]
      rcases h with ⟨rfl, rfl⟩ | ⟨rfl, j, rfl⟩
      · exact Or.inl ⟨rfl, Or.inr rfl⟩
      · exact Or.inr (Or.inl ⟨Or.inl rfl, ⟨r * D + i.val, by dsimp [nEq]; omega⟩,
          ⟨D + (i.val * s + j.val), by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩,
          Or.inr rfl, rfl⟩))
  have hpr_all : PreservesOutside mod ws₀ ws4 :=
    ((hpr1_mod.trans hpr2_mod).trans hpr3_mod).trans hpr4_mod
  refine ⟨ws4, hpr_all, ?_,
    (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps hs4))).mono_steps
      (Nat.le.intro (by ring : _ + 3 = _))⟩
  -- Verify all entries on RowOfBlock D r i.val row.val
  intro row hrob
  rcases hrob with ⟨hlo_r, hhi_r⟩ | hsum_r
  · -- Coordinate row: i.val * D ≤ row.val < (i.val + 1) * D
    have hrow_lt_rD : row.val < r * D :=
      lt_of_lt_of_le hhi_r (Nat.mul_le_mul_right D i.isLt)
    let c : Fin D := ⟨row.val - i.val * D, by
      have : (i.val + 1) * D = i.val * D + D := by ring
      omega⟩
    have hrow_eq : row.val = i.val * D + c.val := by dsimp [c]; omega
    have hdm := div_mod_encode_eq i c
    have hrob_orig : RowOfBlock D r i.val row.val := Or.inl ⟨hlo_r, hhi_r⟩
    refine ⟨fun v => ?_, ?_⟩
    · -- Entry (row, v) in 11 and 12
      have hnot4_11 : ¬ mod4 11 ((row.val * nVars + v.val : ℕ) : ℤ) := by
        rintro (⟨h, _⟩ | ⟨_, j, hidx⟩)
        · exact absurd h (by decide)
        · have hc2 : D + (i.val * s + j.val) < nVars := by
            dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D
          obtain ⟨hr_eq, _⟩ := row_col_inj v.isLt hc2 (Int.ofNat.inj hidx)
          omega
      rw [hpr4 11 _ hnot4_11, hpr4 12 _ (by dsimp [mod4]; omega),
          hRead_hWrite_of_ne ws2 _ (Or.inl (by decide)),
          hRead_hWrite_of_ne ws2 _ (Or.inl (by decide))]
      dsimp only [hullAEq_num, hullAEq_den]
      rw [dif_pos hrow_lt_rD, dif_pos hrow_lt_rD]
      have hi_div : (⟨row.val / D, (div_mod_of_lt_mul hrow_lt_rD).2.1⟩ : Fin r) = i := by
        ext; simp only [hrow_eq, hdm.1]
      have hc_mod : (⟨row.val % D, (div_mod_of_lt_mul hrow_lt_rD).2.2.1⟩ : Fin D) = c := by
        ext; simp only [hrow_eq, hdm.2]
      rw [hi_div, hc_mod]
      by_cases hv : v.val < D
      · rw [dif_pos hv, dif_pos hv]
        have hnot2 : ∀ t_id, (t_id = 11 ∨ t_id = 12) →
            ¬ ((t_id = 10 ∧ (((row.val * nVars + v.val : ℕ) : ℤ) = 41 ∨
                             ((row.val * nVars + v.val : ℕ) : ℤ) = 42)) ∨
               (t_id = 11 ∨ t_id = 12) ∧ ∃ (j : Fin s) (c0 : Fin D),
                 ((row.val * nVars + v.val : ℕ) : ℤ) =
                   (((i.val * D + c0.val) * nVars + (D + (i.val * s + j.val)) : ℕ) : ℤ)) := by
          rintro t_id _
          rintro (⟨h, _⟩ | ⟨_, j, c0, hidx⟩)
          · omega
          · have hc2 : D + (i.val * s + j.val) < nVars := by
              dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D
            obtain ⟨_, hv_eq⟩ := row_col_inj v.isLt hc2 (Int.ofNat.inj hidx)
            omega
        rw [hpr2 11 _ (hnot2 11 (Or.inl rfl)),
            hpr2 12 _ (hnot2 12 (Or.inr rfl))]
        clear hnot2
        refine ⟨?_, ?_⟩
        · have hd1 := hDone1 c ⟨v.val, hv⟩
          simp only [hrow_eq, c.isLt, true_and, Fin.ext_iff, hdm.2] at hd1 ⊢
          exact hd1
        · rw [hpr1 12 _ (by dsimp [mod1]; omega)]
          exact ((hZero_i row hrob_orig).1 v).2
      · rw [dif_neg hv, dif_neg hv]
        let hvs : v.val - D < r * s := by dsimp [nVars] at v; omega
        let hds := div_mod_of_lt_mul hvs
        let i' : Fin r := ⟨(v.val - D) / s, hds.2.1⟩
        let j' : Fin s := ⟨(v.val - D) % s, hds.2.2.1⟩
        have hv_decomp : v.val = D + (i'.val * s + j'.val) := by
          have := hds.2.2.2; dsimp [i', j']; omega
        by_cases hii : i' = i
        · rw [if_pos hii, if_pos hii]
          have hidx_eq : row.val * nVars + v.val =
              (i.val * D + c.val) * nVars + (D + (i.val * s + j'.val)) := by
            rw [hrow_eq, hv_decomp, hii]
          rw [hidx_eq]
          exact hPts2 j' c
        · rw [if_neg hii, if_neg hii]
          have hnot2_i : ∀ (j : Fin s) (c0 : Fin D),
              row.val * nVars + v.val ≠ (i.val * D + c0.val) * nVars + (D + (i.val * s + j.val)) := by
            intro j c0 hidx
            have hc2 : D + (i.val * s + j.val) < nVars := by
              dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D
            obtain ⟨_, hv_eq⟩ := row_col_inj v.isLt hc2 hidx
            have hsub : i'.val * s + j'.val = i.val * s + j.val := by omega
            obtain ⟨hieq, _⟩ := row_col_inj j'.isLt j.isLt hsub
            exact hii (Fin.ext hieq)
          rw [hpr2 11 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, j, c0, hidx⟩; · omega
                · exact hnot2_i j c0 (Int.ofNat.inj hidx)),
              hpr2 12 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, j, c0, hidx⟩; · omega
                · exact hnot2_i j c0 (Int.ofNat.inj hidx)),
              hpr1 11 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, c0, hidx⟩; · omega
                · have hc0_lt : c0.val < nVars := by dsimp [nVars]; omega
                  obtain ⟨_, hv_eq⟩ := row_col_inj v.isLt hc0_lt (Int.ofNat.inj hidx)
                  have := c0.isLt; omega),
              hpr1 12 _ (by dsimp [mod1]; omega)]
          exact (hZero_i row hrob_orig).1 v
    · -- RHS (row) in 13 and 14
      dsimp [hullbEq_num, hullbEq_den]
      rw [if_pos hrow_lt_rD]
      have hne_sum : (row.val : ℤ) ≠ ((r * D + i.val : ℕ) : ℤ) := by omega
      rw [hpr4 13 _ (by dsimp [mod4]; omega), hpr4 14 _ (by dsimp [mod4]; omega),
          hRead_hWrite_of_ne ws2 _ (Or.inr hne_sum),
          hRead_hWrite_of_ne ws2 _ (Or.inl (by decide)),
          hpr2 13 _ (by omega), hpr2 14 _ (by omega),
          hpr1 13 _ (by dsimp [mod1]; omega), hpr1 14 _ (by dsimp [mod1]; omega)]
      exact (hZero_i row hrob_orig).2
  · -- Sum-to-1 row: row.val = r * D + i.val
    have hnot_lt : ¬ (row.val < r * D) := by omega
    have hrob_orig : RowOfBlock D r i.val row.val := Or.inr hsum_r
    refine ⟨fun v => ?_, ?_⟩
    · dsimp only [hullAEq_num, hullAEq_den]
      rw [dif_neg hnot_lt, dif_neg hnot_lt]
      have hi_sub : (⟨row.val - r * D, by omega⟩ : Fin r) = i := by ext; dsimp only; omega
      rw [hi_sub]
      have hnot2_sum : ∀ (j : Fin s) (c0 : Fin D),
          row.val * nVars + v.val ≠ (i.val * D + c0.val) * nVars + (D + (i.val * s + j.val)) := by
        intro j c0 hidx
        have hc2 : D + (i.val * s + j.val) < nVars := by
          dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D
        obtain ⟨hr_eq, _⟩ := row_col_inj v.isLt hc2 hidx
        have := row_col_lt_mul i.isLt c0.isLt; omega
      have hnot1_sum : ∀ c0 : Fin D,
          row.val * nVars + v.val ≠ (i.val * D + c0.val) * nVars + c0.val := by
        intro c0 hidx
        have hc0 : c0.val < nVars := by dsimp [nVars]; omega
        obtain ⟨hr_eq, _⟩ := row_col_inj v.isLt hc0 hidx
        have := row_col_lt_mul i.isLt c0.isLt; omega
      have h12_eq : hRead ws4 12 ((row.val * nVars + v.val : ℕ) : ℤ) = 1 := by
        rw [hpr4 12 _ (by dsimp [mod4]; omega),
            hRead_hWrite_of_ne ws2 _ (Or.inl (by decide)),
            hpr2 12 _ (fun h => by
              rcases h with ⟨h, _⟩ | ⟨_, j, c0, hidx⟩; · omega
              · exact hnot2_sum j c0 (Int.ofNat.inj hidx)),
            hpr1 12 _ (by dsimp [mod1]; omega)]
        exact ((hZero_i row hrob_orig).1 v).2
      by_cases hv : v.val < D
      · rw [dif_pos hv]
        refine ⟨?_, h12_eq⟩
        rw [hpr4 11 _ (fun h => by
              rcases h with ⟨h, _⟩ | ⟨_, j, hidx⟩; · omega
              · have hc2 : D + (i.val * s + j.val) < nVars := by
                  dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D
                obtain ⟨_, hv_eq⟩ := row_col_inj v.isLt hc2 (Int.ofNat.inj hidx); omega),
            hRead_hWrite_of_ne ws2 _ (Or.inl (by decide)),
            hpr2 11 _ (fun h => by
              rcases h with ⟨h, _⟩ | ⟨_, j, c0, hidx⟩; · omega
              · exact hnot2_sum j c0 (Int.ofNat.inj hidx)),
            hpr1 11 _ (fun h => by
              rcases h with ⟨h, _⟩ | ⟨_, c0, hidx⟩; · omega
              · exact hnot1_sum c0 (Int.ofNat.inj hidx))]
        exact ((hZero_i row hrob_orig).1 v).1
      · rw [dif_neg hv]
        let hvs : v.val - D < r * s := by dsimp [nVars] at v; omega
        let hds := div_mod_of_lt_mul hvs
        let i' : Fin r := ⟨(v.val - D) / s, hds.2.1⟩
        let j' : Fin s := ⟨(v.val - D) % s, hds.2.2.1⟩
        have hv_decomp : v.val = D + (i'.val * s + j'.val) := by
          have := hds.2.2.2; dsimp [i', j']; omega
        by_cases hii : i' = i
        · rw [if_pos hii]
          refine ⟨?_, h12_eq⟩
          have hidx_eq : row.val * nVars + v.val =
              (r * D + i.val) * nVars + (D + (i.val * s + j'.val)) := by
            rw [hsum_r, hv_decomp, hii]
          rw [hidx_eq]
          exact hDone4 j' j'.isLt
        · rw [if_neg hii]
          refine ⟨?_, h12_eq⟩
          rw [hpr4 11 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, j, hidx⟩; · omega
                · have hc2 : D + (i.val * s + j.val) < nVars := by
                    dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D
                  obtain ⟨_, hv_eq⟩ := row_col_inj v.isLt hc2 (Int.ofNat.inj hidx)
                  have hsub : i'.val * s + j'.val = i.val * s + j.val := by omega
                  obtain ⟨hieq, _⟩ := row_col_inj j'.isLt j.isLt hsub
                  exact hii (Fin.ext hieq)),
              hRead_hWrite_of_ne ws2 _ (Or.inl (by decide)),
              hpr2 11 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, j, c0, hidx⟩; · omega
                · exact hnot2_sum j c0 (Int.ofNat.inj hidx)),
              hpr1 11 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, c0, hidx⟩; · omega
                · exact hnot1_sum c0 (Int.ofNat.inj hidx))]
          exact ((hZero_i row hrob_orig).1 v).1
    · dsimp [hullbEq_num, hullbEq_den]
      rw [if_neg hnot_lt]
      refine ⟨?_, ?_⟩
      · rw [hpr4 13 _ (by dsimp [mod4]; omega)]; simp only [hsum_r]
        exact hRead_hWrite_self ws2 13 _ 1
      · rw [hpr4 14 _ (by dsimp [mod4]; omega),
            hRead_hWrite_of_ne ws2 _ (Or.inl (by decide)),
            hpr2 14 _ (by omega), hpr1 14 _ (by dsimp [mod1]; omega)]
        exact ((hZero_i row hrob_orig).2).2


def loadHullStmt : UL.BitRAMStmt :=
  let DE := UL.IntExpr.intParam (.lit 0)
  let rE := UL.IntExpr.intParam (.lit 1)
  let sE := UL.IntExpr.intParam (.lit 2)
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let kE := UL.IntExpr.readHeap 10 (.lit 42)
  seqBitStmts
    [ writeDimsStmt (.add DE (.mul rE sE)) (.add (.mul rE DE) rE) (.mul rE sE)
    , zeroInitRatBlockStmt 1 11 12 13 14
    , zeroInitRatBlockStmt 2 15 16 17 18
    , forLoopStmt 40 rE hullInitBlockStmt
    , forLoopStmt 42 (.mul rE sE)
        (.writeHeap 15 (.add (.mul kE nVarsE) (.add DE kE)) (.lit (-1))) ]

def progHullRZero : UL.BitRAMStmt :=
  let kE := UL.IntExpr.readHeap 10 (.lit 42)
  seqBitStmts
    [ .writeHeap 0 (.lit 0) (.lit 1)
    , forLoopStmt 42 (.intParam (.lit 0))
        (seqBitStmts
          [ .writeHeap 1 (.mul (.lit 2) kE) (.lit 0)
          , .writeHeap 1 (.add (.mul (.lit 2) kE) (.lit 1)) (.lit 1) ]) ]

def progHullRPos : UL.BitRAMStmt :=
  let DE := UL.IntExpr.intParam (.lit 0)
  let rE := UL.IntExpr.intParam (.lit 1)
  let sE := UL.IntExpr.intParam (.lit 2)
  seqBitStmts
    [ loadHullStmt
    , solveRationalLPStmt
    , .writeHeap 0 (.lit 0) (.readHeap 30 (.lit 0))
    , copyVecOutStmt 1 DE (.lit 0)
    , copyVecOutStmt 2 (.mul rE sE) DE ]

def progHull : UL.BitRAMStmt :=
  .ite (.intEq (.intParam (.lit 1)) (.lit 0)) progHullRZero progHullRPos

theorem part2_progHull :
    ∃ (prog : UL.BitRAMStmt) (C deg : ℕ),
      ∀ (D r s B : ℕ) (pts : Fin r → Fin s → Fin D → ℚ),
        (∀ (i : Fin r) (j : Fin s), UL.RatPointBitBounded B (pts i j)) →
        let flatPts : List ℚ :=
          (List.finRange r).flatMap (fun i =>
            (List.finRange s).flatMap (fun j => List.ofFn (pts i j)))
        let inp : UL.BitRAMInput 0 :=
          { intParams := [(D : ℤ), (r : ℤ), (s : ℤ)]
            activeHandles := ∅
            activeRatCoords := fun _ k => Fin.elim0 k
            extraRats := flatPts }
        let bound : ℕ := C * (D + r + s + B + 1) ^ deg
        ∃ out : UL.BitRAMExecOutcome,
          UL.runBitRAMWithBits prog inp UL.WordStore.empty [] = some out ∧
          out.unitCost ≤ bound ∧
          out.bitCost ≤ bound ∧
          out.peakCellSpace ≤ bound ∧
          out.peakBitSpace ≤ bound ∧
          let flag : ℤ := out.words.read (.heap 0 0)
          (flag = 0 ∨ flag = 1) ∧
          (flag = 1 ↔
            ∃ z : EuclideanSpace ℝ (Fin D),
              ∀ i : Fin r,
                UL.HasConvexHullCert (fun j : Fin s => UL.ratPointToEuclidean (pts i j)) z) ∧
          (flag = 1 →
            let zNum : Fin D → ℤ := fun k => out.words.read (.heap 1 (2 * (k.val : ℤ)))
            let zDen : Fin D → ℤ := fun k => out.words.read (.heap 1 (2 * (k.val : ℤ) + 1))
            let zRat : Fin D → ℚ := fun k => (zNum k : ℚ) / (zDen k : ℚ)
            let lamNum : Fin r → Fin s → ℤ :=
              fun i j => out.words.read (.heap 2 (2 * ((i.val * s + j.val : ℕ) : ℤ)))
            let lamDen : Fin r → Fin s → ℤ :=
              fun i j => out.words.read (.heap 2 (2 * ((i.val * s + j.val : ℕ) : ℤ) + 1))
            let lam : Fin r → Fin s → ℚ := fun i j => (lamNum i j : ℚ) / (lamDen i j : ℚ)
            UL.RatPointBitBounded bound zRat ∧
            (∀ k : Fin D,
              0 < zDen k ∧
              UL.intBitLength (zNum k) ≤ bound ∧
              UL.intBitLength (zDen k) ≤ bound ∧
              UL.ratBitLength (zRat k) ≤ bound) ∧
            (∀ (i : Fin r) (j : Fin s),
              0 < lamDen i j ∧
              UL.intBitLength (lamNum i j) ≤ bound ∧
              UL.intBitLength (lamDen i j) ≤ bound ∧
              UL.RatCoordBitBounded bound (lam i j) ∧
              UL.ratBitLength (lam i j) ≤ bound) ∧
            (∀ i : Fin r,
              UL.IsConvexHullCert (fun j : Fin s => UL.ratPointToEuclidean (pts i j))
                (UL.ratPointToEuclidean zRat) (fun j : Fin s => (lam i j : ℝ)))) := by
  refine ⟨progHull, 10 ^ 45, 44, ?_⟩
  intro D r s B pts hPtsB flatPts inp bound
  have hpD : ∀ ws, evalVal inp ws (.intParam (.lit 0)) = (D : ℤ) := fun _ => rfl
  have hpr : ∀ ws, evalVal inp ws (.intParam (.lit 1)) = (r : ℤ) := fun _ => rfl
  have hps : ∀ ws, evalVal inp ws (.intParam (.lit 2)) = (s : ℤ) := fun _ => rfl
  by_cases hr0 : r = 0
  · -- Edge case r = 0: vacuous block list, z = 0 ∈ ℝ^D is immediately valid
    subst hr0
    have hFlatNil : flatPts = [] := by simp [flatPts]
    let maxIdx₀ := 64 + 2 * D + s
    let K₀ := 8 + D + s + B
    have hK₀6 : 6 ≤ K₀ := by dsimp [K₀]; omega
    have hMaxPow₀ : maxIdx₀ ≤ 2 ^ K₀ := by
      have h1 : 64 + 2 * D + s ≤ 64 * (D + s + 1) := by omega
      have h2 : D + s + 1 ≤ 2 ^ (D + s + 1) := Nat.lt_two_pow_self.le
      calc maxIdx₀ ≤ 2 ^ 6 * 2 ^ (D + s + 1) := (h1.trans (Nat.mul_le_mul_left 64 h2))
        _ = 2 ^ (6 + (D + s + 1)) := (pow_add 2 6 (D + s + 1)).symm
        _ ≤ 2 ^ K₀ := Nat.pow_le_pow_right (by omega) (by dsimp [K₀]; omega)
    have hIntB₀ : ∀ z ∈ [(D : ℤ), (0 : ℤ), (s : ℤ)], z.natAbs ≤ 2 ^ K₀ := by
      intro z hz
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hz
      rcases hz with rfl | rfl | rfl
      · have : D ≤ maxIdx₀ := by dsimp [maxIdx₀]; omega
        simpa using this.trans hMaxPow₀
      · simp
      · have : s ≤ maxIdx₀ := by dsimp [maxIdx₀]; omega
        simpa using this.trans hMaxPow₀
    have hExtraB₀ : ∀ q ∈ flatPts, q.num.natAbs ≤ 2 ^ K₀ ∧ q.den ≤ 2 ^ K₀ := by
      rw [hFlatNil]; intro _ h; simp at h
    obtain ⟨hInpMag₀, hInpCells₀, hInpBits₀⟩ :=
      input_ZeroDim_bounds K₀ [(D : ℤ), 0, (s : ℤ)] flatPts hIntB₀ hExtraB₀
    have hctx₀ : HeapCtx inp maxIdx₀ K₀ := ⟨hK₀6, hMaxPow₀, hInpMag₀⟩
    have hs_f1 := exec_write hctx₀ (storeBounded_empty 31 maxIdx₀ K₀)
      0 (.lit 0) (.lit 1) 0 1 rfl rfl (by omega) (by dsimp [maxIdx₀]; omega) Nat.one_le_two_pow
    let ws1 := hWrite UL.WordStore.empty 0 0 1
    have hws1 : StoreBounded 31 maxIdx₀ K₀ ws1 := hs_f1.2.1
    let modZ₀ : ℕ → ℤ → Prop := fun t_id idx => (t_id = 10 ∧ idx = 42) ∨ t_id = 1
    let PZ₀ : ℕ → UL.WordStore → Prop := fun C ws =>
      ∀ k : Fin D, k.val < C →
        hRead ws 1 (2 * (k.val : ℤ)) = 0 ∧ hRead ws 1 (2 * (k.val : ℤ) + 1) = 1
    obtain ⟨ws2, hprZ₀, hDoneZ₀, hs_z⟩ := exec_for_frame hctx₀ 42 (.intParam (.lit 0))
      (seqBitStmts
        [ .writeHeap 1 (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 0)
        , .writeHeap 1 (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1)) (.lit 1) ])
      D 2 modZ₀ PZ₀ hws1 (by dsimp [maxIdx₀]; omega) (by dsimp [maxIdx₀]; omega)
      (by dsimp [modZ₀]; omega)
      (fun C ws v => by
        dsimp [PZ₀]; constructor <;> intro h k hk
        · obtain ⟨a, b0⟩ := h k hk; rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at a b0; exact ⟨a, b0⟩
        · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide)),
              hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h k hk)
      (hpD _) (fun _ h => False.elim (Nat.not_lt_zero _ h))
      (fun k hk ws hws hctr_k hpr_k hprev_k => by
        have hw1 := exec_write hctx₀ hws 1 (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 0)
          (2 * (k : ℤ)) 0 (by simp [hctr_k]) rfl (by omega) (by dsimp [maxIdx₀]; omega) (by simp)
        let wsa := hWrite ws 1 (2 * (k : ℤ)) 0; have hwsa : StoreBounded 31 maxIdx₀ K₀ wsa := hw1.2.1
        have hk_a : hRead wsa 10 42 = (k : ℤ) := by
          rw [hRead_hWrite_of_ne ws _ (Or.inl (by decide)), hctr_k]
        have hw2 := exec_write hctx₀ hwsa 1
          (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1)) (.lit 1)
          (2 * (k : ℤ) + 1) 1 (by simp [hk_a]) rfl (by omega) (by dsimp [maxIdx₀]; omega) Nat.one_le_two_pow
        refine ⟨_, hw1.seq_steps hw2, ?_,
          (hpr_k.trans (PreservesOutside.write ws _ (Or.inr rfl))).trans
            (PreservesOutside.write wsa _ (Or.inr rfl)), ?_⟩
        · rw [hRead_hWrite_of_ne wsa _ (Or.inl (by decide)), hk_a]
        · intro k' hk'
          rcases (show k'.val < k ∨ k'.val = k by omega) with hlt | heq
          · rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
                hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega))]
            exact hprev_k k' hlt
          · simp only [heq]
            exact ⟨by rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega))]
                      exact hRead_hWrite_self ws 1 _ 0,
                   hRead_hWrite_self wsa 1 _ 1⟩)
    have hExec₀ : ExecBit inp maxIdx₀ K₀ progHull UL.WordStore.empty ws2
        ((4 + 3 * D) * stepU) ((4 + 3 * D) * stepB K₀) :=
      (exec_ite_true hctx₀ (.intEq (.intParam (.lit 1)) (.lit 0)) progHullRZero progHullRPos
        rfl (hs_f1.seq_steps hs_z)).mono_steps (by omega)
    obtain ⟨out, hRun, hout_ws, huCost, hbCost, hpCells, hpBits⟩ := hExec₀.to_runBitRAMWithBits
    let P := D + 0 + s + B + 1
    have hP1 : 1 ≤ P := by dsimp [P]; omega
    have ppow_mono : ∀ {a b : ℕ}, a ≤ b → P ^ a ≤ P ^ b := fun h => Nat.pow_le_pow_right hP1 h
    have hPP : ∀ {k : ℕ}, 1 ≤ k → P ≤ P ^ k := fun hk => by simpa only [pow_one] using ppow_mono hk
    have hK₀_le : K₀ ≤ 8 * P := by dsimp [K₀, P]; omega
    have hMax₀_le : maxIdx₀ + 1 ≤ 65 * P := by dsimp [maxIdx₀, P]; omega
    have hBU : (4 + 3 * D) * stepU ≤ bound := by
      dsimp [stepU, bound]
      have h1 : (4 + 3 * D) * 100 ≤ 400 * P := by dsimp [P]; omega
      exact (h1.trans (Nat.mul_le_mul_left 400 (hPP (by decide)))).trans
        (Nat.mul_le_mul_right _ (by norm_num : 400 ≤ 10 ^ 45))
    have hBB : (4 + 3 * D) * stepB K₀ ≤ bound := by
      dsimp [stepB, bound]
      have h1 : 4 + 3 * D ≤ 4 * P := by dsimp [P]; omega
      have h2 : K₀ ^ 2 ≤ 64 * P ^ 2 := by
        calc K₀ ^ 2 ≤ (8 * P) ^ 2 := Nat.pow_le_pow_left hK₀_le 2
          _ = 64 * P ^ 2 := by ring
      calc (4 + 3 * D) * (2000000 * K₀ ^ 2)
          ≤ (4 * P) * (2000000 * (64 * P ^ 2)) := Nat.mul_le_mul h1 (Nat.mul_le_mul_left _ h2)
        _ = 512000000 * P ^ 3 := by ring
        _ ≤ 10 ^ 45 * P ^ 3 := Nat.mul_le_mul_right _ (by norm_num)
        _ ≤ 10 ^ 45 * P ^ 44 := Nat.mul_le_mul_left _ (ppow_mono (by decide))
    have hBC : ctxPeakCells inp maxIdx₀ ≤ bound := by
      dsimp [ctxPeakCells, bound, inp]; rw [hInpCells₀, hFlatNil]; simp only [List.length_cons, List.length_nil]
      have h1 : 3 + 2 * 0 + 32 * (maxIdx₀ + 1) ≤ 3000 * P := by omega
      exact (h1.trans (Nat.mul_le_mul_left 3000 (hPP (by decide)))).trans
        (Nat.mul_le_mul_right _ (by norm_num : 3000 ≤ 10 ^ 45))
    have hBP : ctxPeakBits inp maxIdx₀ K₀ ≤ bound := by
      dsimp [ctxPeakBits, bound]
      have h1 : inp.inputBitSpace ≤ 33 * P ^ 2 := by
        have h1a : inp.inputBitSpace ≤ 3 * (K₀ + 3) := by simpa [hFlatNil] using hInpBits₀
        have h1b : 3 * (K₀ + 3) ≤ 33 * P := by omega
        exact (h1a.trans h1b).trans (Nat.mul_le_mul_left 33 (hPP (by decide)))
      have h2 : 2 * K₀ + 14 ≤ 30 * P := by omega
      have h3 : 32 * (maxIdx₀ + 1) * (2 * K₀ + 14) ≤ 62400 * P ^ 2 := by
        calc 32 * (maxIdx₀ + 1) * (2 * K₀ + 14)
            ≤ (32 * (65 * P)) * (30 * P) := Nat.mul_le_mul (Nat.mul_le_mul_left 32 hMax₀_le) h2
          _ = 62400 * P ^ 2 := by ring
      have hsum : inp.inputBitSpace + 32 * (maxIdx₀ + 1) * (2 * K₀ + 14) ≤ 70000 * P ^ 2 := by omega
      exact hsum.trans ((Nat.mul_le_mul_right _ (by norm_num : 70000 ≤ 10 ^ 45)).trans
        (Nat.mul_le_mul_left _ (ppow_mono (by decide))))
    have hOutFlag : out.words.read (.heap 0 0) = 1 := by
      rw [hout_ws]; change hRead ws2 0 0 = 1
      rw [hprZ₀ 0 0 (by dsimp [modZ₀]; omega)]; exact hRead_hWrite_self _ 0 0 1
    have h2K₀_bound : 2 * K₀ + 5 ≤ bound := by
      dsimp [bound]
      have h1 : 2 * K₀ + 5 ≤ 21 * P := by omega
      exact (h1.trans (Nat.mul_le_mul_left 21 (hPP (by decide)))).trans
        (Nat.mul_le_mul_right _ (by norm_num : 21 ≤ 10 ^ 45))
    refine ⟨out, hRun, huCost.trans hBU, hbCost.trans hBB, hpCells.trans hBC, hpBits.trans hBP,
      by rw [hOutFlag]; exact Or.inr rfl, ?_, ?_⟩
    · rw [hOutFlag]
      exact ⟨fun _ => ⟨0, fun i => Fin.elim0 i⟩, fun _ => rfl⟩
    · intro _
      have hReadZ : ∀ k : Fin D,
          out.words.read (.heap 1 (2 * (k.val : ℤ))) = 0 ∧
          out.words.read (.heap 1 (2 * (k.val : ℤ) + 1)) = 1 := by
        intro k; rw [hout_ws]; exact hDoneZ₀ k k.isLt
      have hb01 := rat_div_bit_bounds (num := 0) (den := 1) (K := K₀) (bound := bound)
        (by decide) (by simp) Nat.one_le_two_pow h2K₀_bound
      refine ⟨fun k => ?_, fun k => ?_, fun i => Fin.elim0 i, fun i => Fin.elim0 i⟩
      · dsimp only; rw [(hReadZ k).1, (hReadZ k).2]; exact hb01.2.2.1
      · dsimp only; rw [(hReadZ k).1, (hReadZ k).2]
        exact ⟨by decide, hb01.1, hb01.2.1, hb01.2.2.2⟩
  · -- Main case: 1 ≤ r
    have hr1 : 1 ≤ r := by omega
    let nVars := D + r * s
    let nEq := r * D + r
    let nLe := r * s
    let B' := max B 1
    let maxIdx := solverMaxIdx nVars nEq nLe
    let K := solverK nVars nEq nLe B'
    have hB'1 : 1 ≤ B' := le_max_right B 1
    have hB'_le_K : B' ≤ K :=
      (Nat.le_mul_of_pos_right B' (by omega : 0 < nVars + 2)).trans bInt_le_solverK
    have hPowB'K : 2 ^ B' ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) hB'_le_K
    obtain ⟨h64, hnV, hnE, hnL, _, hnV2, h2nV, _, _, hmOra, hnEnV, hnLnV, _, _, _, _, _, _⟩ :=
      solverMaxIdx_bounds nVars nEq nLe
    have hD_le : D ≤ maxIdx := (Nat.le_add_right D (r * s)).trans hnV
    have hr_le : r ≤ maxIdx := (Nat.le_add_left r (r * D)).trans hnE
    have hs_le : s ≤ maxIdx := by
      calc s = 1 * s := (one_mul s).symm
        _ ≤ r * s := Nat.mul_le_mul_right s hr1
        _ ≤ maxIdx := hnL
    have hMaxPow := solverMaxIdx_le_two_pow nVars nEq nLe B'
    -- List indexing on flatPts
    have hInLen : ∀ i : Fin r,
        ((List.finRange s).flatMap (fun j => List.ofFn (pts i j))).length = s * D :=
      fun i => flatMap_finRange_length s D _ (fun _ => List.length_ofFn)
    have hFlatLen : flatPts.length = r * (s * D) :=
      flatMap_finRange_length r (s * D) _ hInLen
    have hGetPt : ∀ (i : Fin r) (j : Fin s) (c : Fin D),
        inp.extraRats.getD ((i.val * s + j.val) * D + c.val) 0 = pts i j c := by
      intro i j c
      dsimp [inp]
      have hidx : (i.val * s + j.val) * D + c.val = i.val * (s * D) + (j.val * D + c.val) := by ring
      rw [hidx, flatMap_finRange_getD r (s * D) _ 0 hInLen i (row_col_lt_mul j.isLt c.isLt),
          flatMap_finRange_getD s D _ 0 (fun _ => List.length_ofFn) j c.isLt,
          list_getD_ofFn]
    -- Input magnitude & space bounds
    have hIntB : ∀ z ∈ [(D : ℤ), (r : ℤ), (s : ℤ)], z.natAbs ≤ 2 ^ K := by
      intro z hz
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hz
      rcases hz with rfl | rfl | rfl
      · simpa using hD_le.trans hMaxPow
      · simpa using hr_le.trans hMaxPow
      · simpa using hs_le.trans hMaxPow
    have hExtraB : ∀ q ∈ flatPts, q.num.natAbs ≤ 2 ^ K ∧ q.den ≤ 2 ^ K := by
      intro q hq
      rw [List.mem_flatMap] at hq
      rcases hq with ⟨i, _, hq2⟩
      rw [List.mem_flatMap] at hq2
      rcases hq2 with ⟨j, _, hq3⟩
      rw [List.mem_ofFn] at hq3
      rcases hq3 with ⟨c, rfl⟩
      obtain ⟨hn, hd, _, _, _⟩ := ratCoordBitBounded_imp_natAbs_le (hPtsB i j c)
      exact ⟨hn.trans hPowB'K, hd.trans hPowB'K⟩
    obtain ⟨hInpMag, hInpCells, hInpBits⟩ :=
      input_ZeroDim_bounds K [(D : ℤ), (r : ℤ), (s : ℤ)] flatPts hIntB hExtraB
    have hctx : HeapCtx inp maxIdx K := ⟨solverK_ge6 nVars nEq nLe B', hMaxPow, hInpMag⟩
    have hpt_B' := fun i j c => ratCoordBitBounded_imp_natAbs_le (hPtsB i j c)
    have hPtK : ∀ i j c, (pts i j c).num.natAbs ≤ 2 ^ K ∧ (pts i j c).den ≤ 2 ^ K :=
      fun i j c => ⟨(hpt_B' i j c).1.trans hPowB'K, (hpt_B' i j c).2.1.trans hPowB'K⟩
    -- Step 1: writeDimsStmt
    obtain ⟨ws1, hDim1, hs1⟩ := exec_writeDimsStmt hctx h64 ⟨hnV2, hmOra⟩
      (.add (.intParam (.lit 0)) (.mul (.intParam (.lit 1)) (.intParam (.lit 2))))
      (.add (.mul (.intParam (.lit 1)) (.intParam (.lit 0))) (.intParam (.lit 1)))
      (.mul (.intParam (.lit 1)) (.intParam (.lit 2)))
      (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
      (fun ws => by simp only [evalVal_add, evalVal_mul, hpD ws, hpr ws, hps ws]; exact_mod_cast (rfl : D + r * s = nVars))
      (fun ws => by simp only [evalVal_add, evalVal_mul, hpr ws, hpD ws]; exact_mod_cast (rfl : r * D + r = nEq))
      (fun ws => by simp only [evalVal_mul, hpr ws, hps ws]; exact_mod_cast (rfl : r * s = nLe))
      (storeBounded_empty 31 maxIdx K)
    -- Step 2 & 3: zero-init eq and le blocks
    obtain ⟨ws2, hpr2, hZ1_A, hZ1_b, hs2⟩ := exec_zeroInitRatBlockStmt hctx h64
      ⟨hnV, hnE, hnEnV⟩ 1 (Or.inl rfl) 11 12 13 14 (by decide) hs1.2.1 hDim1.1 hDim1.2.1
    have hDim2 := hDim1.preserve hpr2 (by intro idx _ _; omega)
    obtain ⟨ws3, hpr3, hZ2_A, hZ2_b, hs3⟩ := exec_zeroInitRatBlockStmt hctx h64
      ⟨hnV, hnL, hnLnV⟩ 2 (Or.inr rfl) 15 16 17 18 (by decide) hs2.2.1 hDim2.1 hDim2.2.2.1
    have hDim3 := hDim2.preserve hpr3 (by intro idx _ _; omega)
    have hZ1A_3 : ∀ (row : Fin nEq) (v : Fin nVars),
        hRead ws3 11 ((row.val * nVars + v.val : ℕ) : ℤ) = 0 ∧
        hRead ws3 12 ((row.val * nVars + v.val : ℕ) : ℤ) = 1 := by
      intro row v; rw [hpr3 11 _ (by omega), hpr3 12 _ (by omega)]; exact hZ1_A row v
    have hZ1b_3 : ∀ row : Fin nEq, hRead ws3 13 (row.val : ℤ) = 0 ∧ hRead ws3 14 (row.val : ℤ) = 1 := by
      intro row; rw [hpr3 13 _ (by omega), hpr3 14 _ (by omega)]; exact hZ1_b row
    -- Step 4: loop i < r executing hullInitBlockStmt
    let modBlk : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (40 ≤ idx ∧ idx ≤ 42)) ∨ t_id = 11 ∨ t_id = 12 ∨ t_id = 13
    let PBlk : ℕ → UL.WordStore → Prop := fun I ws =>
      ∀ (i : Fin r) (row : Fin nEq), RowOfBlock D r i.val row.val →
        (i.val < I →
          (∀ v : Fin nVars,
            hRead ws 11 ((row.val * nVars + v.val : ℕ) : ℤ) = hullAEq_num pts row v ∧
            hRead ws 12 ((row.val * nVars + v.val : ℕ) : ℤ) = hullAEq_den pts row v) ∧
          (hRead ws 13 (row.val : ℤ) = hullbEq_num row ∧
           hRead ws 14 (row.val : ℤ) = hullbEq_den row)) ∧
        (I ≤ i.val →
          (∀ v : Fin nVars,
            hRead ws 11 ((row.val * nVars + v.val : ℕ) : ℤ) = 0 ∧
            hRead ws 12 ((row.val * nVars + v.val : ℕ) : ℤ) = 1) ∧
          (hRead ws 13 (row.val : ℤ) = 0 ∧ hRead ws 14 (row.val : ℤ) = 1))
    have hPBlk0 : PBlk 0 ws3 := by
      intro i row _
      exact ⟨fun h => False.elim (Nat.not_lt_zero _ h),
             fun _ => ⟨fun v => hZ1A_3 row v, hZ1b_3 row⟩⟩
    obtain ⟨ws4, hpr4, hDoneBlk4, hs4⟩ := exec_for_frame hctx 40 (.intParam (.lit 1))
      hullInitBlockStmt r (10 + 2 * D + s * (5 + 3 * D)) modBlk PBlk hs3.2.1 (by omega) hr_le
      (by dsimp [modBlk]; omega)
      (fun I ws val => by
        dsimp [PBlk]
        have hign : ∀ (t : ℕ), t ≠ 10 → ∀ idx, hRead (hWrite ws 10 40 val) t idx = hRead ws t idx :=
          fun t ht idx => hRead_hWrite_of_ne ws val (Or.inl ht)
        constructor <;> intro h i row hrob
        · obtain ⟨h1, h2⟩ := h i row hrob
          refine ⟨fun hlt => ?_, fun hge => ?_⟩
          · obtain ⟨ha, hb⟩ := h1 hlt
            simp only [hign 11 (by decide), hign 12 (by decide),
              hign 13 (by decide), hign 14 (by decide)] at ha hb
            exact ⟨ha, hb⟩
          · obtain ⟨ha, hb⟩ := h2 hge
            simp only [hign 11 (by decide), hign 12 (by decide),
              hign 13 (by decide), hign 14 (by decide)] at ha hb
            exact ⟨ha, hb⟩
        · obtain ⟨h1, h2⟩ := h i row hrob
          refine ⟨fun hlt => ?_, fun hge => ?_⟩
          · obtain ⟨ha, hb⟩ := h1 hlt
            simp only [hign 11 (by decide), hign 12 (by decide),
              hign 13 (by decide), hign 14 (by decide)]
            exact ⟨ha, hb⟩
          · obtain ⟨ha, hb⟩ := h2 hge
            simp only [hign 11 (by decide), hign 12 (by decide),
              hign 13 (by decide), hign 14 (by decide)]
            exact ⟨ha, hb⟩)
      (hpr _) hPBlk0
      (fun i hi ws hws hctr_i hpr_i hprev_i => by
        let iFin : Fin r := ⟨i, hi⟩
        have hnV_w : hRead ws 10 0 = (nVars : ℤ) := by
          rw [hpr_i 10 0 (by dsimp [modBlk]; omega), hDim3.1]
        have hZero_i : ∀ row : Fin nEq, RowOfBlock D r i row.val →
            (∀ v : Fin nVars,
              hRead ws 11 ((row.val * nVars + v.val : ℕ) : ℤ) = 0 ∧
              hRead ws 12 ((row.val * nVars + v.val : ℕ) : ℤ) = 1) ∧
            (hRead ws 13 (row.val : ℤ) = 0 ∧ hRead ws 14 (row.val : ℤ) = 1) :=
          fun row hrob => (hprev_i iFin row hrob).2 le_rfl
        obtain ⟨ws_b, hpr_b, hDone_b, hex_b⟩ := exec_hullInitBlockStmt hctx h64
          ⟨hD_le, hs_le, hnE, hnEnV⟩ hpD hpr hps pts hGetPt hPtK iFin hws hnV_w hctr_i hZero_i
        have hpr_step : PreservesOutside modBlk ws3 ws_b :=
          hpr_i.trans (hpr_b.mono (by
            intro t idx h; dsimp [modBlk]
            rcases h with ⟨rfl, h1 | h1⟩ | ⟨rfl | rfl, _⟩ | ⟨rfl, _⟩ <;> omega))
        refine ⟨ws_b, hex_b, ?_, hpr_step, ?_⟩
        · rw [hpr_b 10 40 (by omega), hctr_i]
        · intro i' row hrob'
          by_cases hieq : i' = iFin
          · subst hieq
            exact ⟨fun _ => hDone_b row hrob', fun hge => absurd hge (by simp [iFin])⟩
          · have hne_i : i'.val ≠ i := fun h => hieq (Fin.ext h)
            have hnot_row : ∀ t_id, (t_id = 11 ∨ t_id = 12) → ∀ v : Fin nVars,
                ¬ ((t_id = 10 ∧ (((row.val * nVars + v.val : ℕ) : ℤ) = 41 ∨
                    ((row.val * nVars + v.val : ℕ) : ℤ) = 42)) ∨
                   ((t_id = 11 ∨ t_id = 12) ∧
                     ∃ (row0 : Fin nEq) (v0 : Fin nVars),
                       RowOfBlock D r i row0.val ∧
                       ((row.val * nVars + v.val : ℕ) : ℤ) = ((row0.val * nVars + v0.val : ℕ) : ℤ)) ∨
                   (t_id = 13 ∧ ((row.val * nVars + v.val : ℕ) : ℤ) = ((r * D + i : ℕ) : ℤ))) := by
              rintro t_id ht v (⟨h, _⟩ | ⟨_, row0, v0, hrob0, hidx⟩ | ⟨h, _⟩)
              · omega
              · obtain ⟨hr_eq, _⟩ := row_col_inj v.isLt v0.isLt (Int.ofNat.inj hidx)
                rw [← hr_eq] at hrob0
                exact rowOfBlock_disjoint i'.isLt hi hne_i hrob' hrob0
              · omega
            have hnot_13 : (row.val : ℤ) ≠ ((r * D + i : ℕ) : ℤ) := by
              intro h
              have hr_eq : row.val = r * D + i := Int.ofNat.inj h
              exact rowOfBlock_disjoint i'.isLt hi hne_i hrob' (Or.inr hr_eq)
            have heq11 : ∀ v : Fin nVars,
                hRead ws_b 11 ((row.val * nVars + v.val : ℕ) : ℤ) =
                hRead ws 11 ((row.val * nVars + v.val : ℕ) : ℤ) :=
              fun v => hpr_b 11 _ (hnot_row 11 (Or.inl rfl) v)
            have heq12 : ∀ v : Fin nVars,
                hRead ws_b 12 ((row.val * nVars + v.val : ℕ) : ℤ) =
                hRead ws 12 ((row.val * nVars + v.val : ℕ) : ℤ) :=
              fun v => hpr_b 12 _ (hnot_row 12 (Or.inr rfl) v)
            have heq13 : hRead ws_b 13 (row.val : ℤ) = hRead ws 13 (row.val : ℤ) :=
              hpr_b 13 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨h | h, _⟩ | ⟨_, hidx⟩
                · omega
                · omega
                · omega
                · exact hnot_13 hidx)
            have heq14 : hRead ws_b 14 (row.val : ℤ) = hRead ws 14 (row.val : ℤ) :=
              hpr_b 14 _ (by omega)
            simp only [heq11, heq12, heq13, heq14]
            obtain ⟨hp1, hp2⟩ := hprev_i i' row hrob'
            exact ⟨fun hlt => hp1 (by omega), fun hge => hp2 (by omega)⟩)
    -- Step 5: write 15[k * nVars + (D + k)] := -1 for k < r * s
    have hDim4 := hDim3.preserve hpr4 (by intro idx _ _; dsimp [modBlk]; omega)
    let modLe : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ idx = 42) ∨ t_id = 15
    let PLe : ℕ → UL.WordStore → Prop := fun K_done ws =>
      ∀ (k : Fin nLe) (v : Fin nVars),
        hRead ws 15 ((k.val * nVars + v.val : ℕ) : ℤ) =
          if k.val < K_done ∧ v.val = D + k.val then -1 else 0
    have hPLe0 : PLe 0 ws4 := by
      intro k v
      simp only [Nat.not_lt_zero, false_and, ↓reduceIte]
      rw [hpr4 15 _ (by dsimp [modBlk]; omega)]
      exact (hZ2_A k v).1
    obtain ⟨ws5, hpr5, hLe5, hs5⟩ := exec_for_frame hctx 42
      (.mul (.intParam (.lit 1)) (.intParam (.lit 2)))
      (.writeHeap 15
        (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
              (.add (.intParam (.lit 0)) (.readHeap 10 (.lit 42))))
        (.lit (-1)))
      nLe 1 modLe PLe hs4.2.1 (by omega) hnL
      (by dsimp [modLe]; omega)
      (fun C ws val => by
        dsimp [PLe]; constructor <;> intro h k v
        · have := h k v; rwa [hRead_hWrite_of_ne ws val (Or.inl (by decide))] at this
        · rw [hRead_hWrite_of_ne ws val (Or.inl (by decide))]; exact h k v)
      (by simp only [evalVal_mul, hpr _, hps _]; exact_mod_cast (rfl : r * s = nLe))
      hPLe0
      (fun k hk ws hws hctr_k hpr_k hprev_k => by
        have hcol_lt : D + k < nVars := by dsimp [nVars, nLe] at hk ⊢; omega
        have hdst_le : k * nVars + (D + k) ≤ maxIdx :=
          (row_col_lt_mul hk hcol_lt).le.trans hnLnV
        have hnV_w : hRead ws 10 0 = (nVars : ℤ) := by
          rw [hpr_k 10 0 (by dsimp [modLe]; omega), hDim4.1]
        have hw := exec_write hctx hws 15
          (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
                (.add (.intParam (.lit 0)) (.readHeap 10 (.lit 42))))
          (.lit (-1)) ((k * nVars + (D + k) : ℕ) : ℤ) (-1)
          (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hctr_k, hnV_w, hpD ws]
              exact_mod_cast (rfl : k * nVars + (D + k) = k * nVars + (D + k)))
          rfl (Nat.cast_nonneg _) (Nat.cast_le.mpr hdst_le) Nat.one_le_two_pow
        refine ⟨_, hw, ?_, hpr_k.trans (PreservesOutside.write ws _ (Or.inr rfl)), ?_⟩
        · rw [hRead_hWrite_of_ne ws _ (Or.inl (by decide))]; exact hctr_k
        · intro k' v'
          by_cases heq_idx : k'.val * nVars + v'.val = k * nVars + (D + k)
          · obtain ⟨hkeq, hveq⟩ := row_col_inj v'.isLt hcol_lt heq_idx
            rw [if_pos ⟨by omega, by omega⟩]; simp only [heq_idx]
            exact hRead_hWrite_self ws 15 _ (-1)
          · have hne_z : ((k'.val * nVars + v'.val : ℕ) : ℤ) ≠ ((k * nVars + (D + k) : ℕ) : ℤ) :=
              fun h => heq_idx (Int.ofNat.inj h)
            rw [hRead_hWrite_of_ne ws _ (Or.inr hne_z), hprev_k k' v']
            by_cases hvk : v'.val = D + k'.val
            · have hk_ne : k'.val ≠ k := fun h => heq_idx (by rw [hvk, h])
              have hiff : (k'.val < k ↔ k'.val < k + 1) := by omega
              simp [hvk, hiff]
            · simp [hvk])
    -- Assemble RatLPInHeap at ws5
    have hDim5 := hDim4.preserve hpr5 (by intro idx _ _; dsimp [modLe]; omega)
    have hRowBlockExists : ∀ row : Fin nEq, ∃ i : Fin r, RowOfBlock D r i.val row.val := by
      intro row
      by_cases hlt : row.val < r * D
      · obtain ⟨_, hdiv, hmod, hdm⟩ := div_mod_of_lt_mul hlt
        refine ⟨⟨row.val / D, hdiv⟩, Or.inl ⟨by dsimp only; omega, ?_⟩⟩
        calc row.val = (row.val / D) * D + row.val % D := hdm.symm
          _ < (row.val / D) * D + D := Nat.add_lt_add_left hmod _
          _ = (row.val / D + 1) * D := by ring
      · exact ⟨⟨row.val - r * D, by dsimp [nEq] at row; omega⟩, Or.inr (by dsimp only; omega)⟩
    have hRat5 : RatLPInHeap
        (hullAEq_num pts) (hullAEq_den pts) hullbEq_num hullbEq_den
        hullALe_num hullALe_den hullbLe_num hullbLe_den ws5 := by
      refine ⟨fun row v => ?_, fun row => ?_, fun k v => ?_, fun k => ?_⟩
      · obtain ⟨i, hrob⟩ := hRowBlockExists row
        rw [hpr5 11 _ (by dsimp [modLe]; omega), hpr5 12 _ (by dsimp [modLe]; omega)]
        exact ((hDoneBlk4 i row hrob).1 i.isLt).1 v
      · obtain ⟨i, hrob⟩ := hRowBlockExists row
        rw [hpr5 13 _ (by dsimp [modLe]; omega), hpr5 14 _ (by dsimp [modLe]; omega)]
        exact ((hDoneBlk4 i row hrob).1 i.isLt).2
      · refine ⟨?_, ?_⟩
        · simpa [hullALe_num, k.isLt] using hLe5 k v
        · rw [hpr5 16 _ (by dsimp [modLe]; omega), hpr4 16 _ (by dsimp [modBlk]; omega)]
          exact (hZ2_A k v).2
      · rw [hpr5 17 _ (by dsimp [modLe]; omega), hpr5 18 _ (by dsimp [modLe]; omega),
            hpr4 17 _ (by dsimp [modBlk]; omega), hpr4 18 _ (by dsimp [modBlk]; omega)]
        exact hZ2_b k
    -- Step 6: solveRationalLPStmt + output copies
    have hEqDenPos : ∀ row v, 0 < hullAEq_den pts row v := by
      intro row v; dsimp [hullAEq_den]
      split_ifs with h1 h2 h3
      · omega
      · exact Nat.cast_pos.mpr (pts _ _ _).pos
      · omega
      · omega
    have hEqNumB : ∀ row v, (hullAEq_num pts row v).natAbs ≤ 2 ^ B' := by
      intro row v; dsimp [hullAEq_num]
      split_ifs with h1 h2 h3 h4 h5 h6 <;> try simp [Nat.one_le_two_pow]
      exact (hpt_B' _ _ _).1
    have hEqDenB : ∀ row v, (hullAEq_den pts row v).natAbs ≤ 2 ^ B' := by
      intro row v; dsimp [hullAEq_den]
      split_ifs with h1 h2 h3 <;> try simp [Nat.one_le_two_pow]
      simpa using (hpt_B' _ _ _).2.1
    have hLeNumB : ∀ (k : Fin nLe) (v : Fin nVars),
        (hullALe_num (D := D) (r := r) (s := s) k v).natAbs ≤ 2 ^ B' := by
      intro k v; dsimp [hullALe_num]; split_ifs <;> simp [Nat.one_le_two_pow]
    obtain ⟨ws6, _, hFlag6, hSol6, hs6⟩ := exec_solveRationalLPStmt hB'1 hctx
      (hullAEq_num pts) (hullAEq_den pts) hullbEq_num hullbEq_den
      hullALe_num hullALe_den hullbLe_num hullbLe_den
      hEqDenPos (fun _ => Int.zero_lt_one) (fun _ _ => Int.zero_lt_one) (fun _ => Int.zero_lt_one)
      hEqNumB hEqDenB
      (fun row => by dsimp [hullbEq_num]; split_ifs <;> simp [Nat.one_le_two_pow])
      (fun _ => Nat.one_le_two_pow)
      hLeNumB (fun _ _ => Nat.one_le_two_pow) (fun _ => Nat.zero_le _) (fun _ => Nat.one_le_two_pow)
      hs5.2.1 hDim5 hRat5
    let res := solveRationalLP
      (hullAEq_num pts) (hullAEq_den pts) hullbEq_num hullbEq_den
      hullALe_num hullALe_den hullbLe_num hullbLe_den
    have hFlag_abs : res.1.natAbs ≤ 2 ^ K := by
      rw [← hFlag6]; exact storeBounded_read_abs hs6.2.1 _
    have hs7 := exec_write hctx hs6.2.1 0 (.lit 0) (.readHeap 30 (.lit 0))
      0 res.1 rfl (by rw [evalVal_readHeap, evalVal_lit, hFlag6]) (by omega) (by omega) hFlag_abs
    let ws7 := hWrite ws6 0 0 res.1; have hws7 : StoreBounded 31 maxIdx K ws7 := hs7.2.1
    have hSol7 : ∀ v : Fin nVars,
        hRead ws7 31 (2 * (v.val : ℤ)) = res.2.1 v ∧
        hRead ws7 31 (2 * (v.val : ℤ) + 1) = res.2.2 v := by
      intro v
      rw [hRead_hWrite_of_ne ws6 _ (Or.inl (by decide)),
          hRead_hWrite_of_ne ws6 _ (Or.inl (by decide))]
      exact hSol6 v
    obtain ⟨ws8, hpr8, hOutZ8, hs8⟩ := exec_copyVecOutStmt hctx h64
      (by dsimp [nVars]; omega : 0 + D ≤ nVars) h2nV 1 (Or.inl rfl) (.intParam (.lit 0)) (.lit 0)
      (by decide) (by decide) (by decide) (by decide) hpD (fun _ => rfl)
      res.2.1 res.2.2 hws7 hSol7
    have hSol8 : ∀ v : Fin nVars,
        hRead ws8 31 (2 * (v.val : ℤ)) = res.2.1 v ∧
        hRead ws8 31 (2 * (v.val : ℤ) + 1) = res.2.2 v := by
      intro v
      rw [hpr8 31 _ (by omega), hpr8 31 _ (by omega)]
      exact hSol7 v
    obtain ⟨ws9, hpr9, hOutLam9, hs9⟩ := exec_copyVecOutStmt hctx h64
      (le_rfl : D + r * s ≤ nVars) h2nV 2 (Or.inr rfl)
      (.mul (.intParam (.lit 1)) (.intParam (.lit 2))) (.intParam (.lit 0))
      (by decide) (by decide) (by decide) (by decide)
      (fun ws => by simp only [evalVal_mul, hpr ws, hps ws]; exact_mod_cast (rfl : r * s = r * s))
      hpD res.2.1 res.2.2 hs8.2.1 hSol8
    let m_extra := 20 + (nEq + nLe) * (5 + 3 * nVars) + r * (11 + 2 * D + s * (5 + 3 * D)) + 2 * nLe
    have hLoadExec : ExecBit inp maxIdx K loadHullStmt UL.WordStore.empty ws5
        (m_extra * stepU) (m_extra * stepB K) :=
      (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps hs5)))).mono_steps
        (Nat.le.intro (by dsimp [m_extra, nVars, nEq, nLe]; ring : _ + 6 = _))
    have hPosExec : ExecBit inp maxIdx K progHullRPos UL.WordStore.empty ws9
        ((m_extra + solverStepBound nVars nEq nLe B' + (9 + 4 * nVars)) * stepU)
        ((m_extra + solverStepBound nVars nEq nLe B' + (9 + 4 * nVars)) * stepB K) :=
      (hLoadExec.seq_steps (hs6.seq_steps (hs7.seq_steps (hs8.seq_steps hs9)))).mono_steps
        (by dsimp [nVars]; omega)
    have hCondR : evalCondVal inp UL.WordStore.empty (.intEq (.intParam (.lit 1)) (.lit 0)) = false := by
      simp only [evalCondVal_intEq, evalVal_lit, hpr UL.WordStore.empty]
      exact decide_eq_false (by omega)
    have hExecTot : ExecBit inp maxIdx K progHull UL.WordStore.empty ws9
        ((m_extra + solverStepBound nVars nEq nLe B' + (10 + 4 * nVars)) * stepU)
        ((m_extra + solverStepBound nVars nEq nLe B' + (10 + 4 * nVars)) * stepB K) :=
      (exec_ite_false hctx (.intEq (.intParam (.lit 1)) (.lit 0)) progHullRZero progHullRPos
        hCondR hPosExec).mono_steps (by omega)
    obtain ⟨out, hRun, hout_ws, huCost, hbCost, hpCells, hpBits⟩ := hExecTot.to_runBitRAMWithBits
    -- Polynomial bound scaling: S ≤ 6 * P ^ 2 where P = D + r + s + B + 1
    have hm_extra_le : m_extra ≤ 40 * (nVars + nEq + nLe + 1) ^ 2 := by
      dsimp [m_extra, nVars, nEq, nLe]
      exact Nat.le.intro (by
        ring : (20 + ((r * D + r) + r * s) * (5 + 3 * (D + r * s)) +
            r * (11 + 2 * D + s * (5 + 3 * D)) + 2 * (r * s)) +
          (20 + 80 * D + 64 * r + 150 * (r * D) + 148 * (r * s) + 154 * (r * D * s) +
           77 * (r * D ^ 2) + 157 * (r ^ 2 * s) + 157 * (r ^ 2 * D * s) +
           80 * (r ^ 2 * D) + 40 * D ^ 2 + 40 * r ^ 2 + 40 * (r ^ 2 * D ^ 2) +
           157 * (r ^ 2 * s ^ 2)) =
          40 * ((D + r * s) + (r * D + r) + r * s + 1) ^ 2)
    have hlenRat_le : flatPts.length ≤ 4 * (nVars + nEq + nLe + 1) ^ 2 := by
      rw [hFlatLen]; dsimp [nVars, nEq, nLe]
      exact Nat.le.intro (by
        ring : r * (s * D) +
          (4 + 8 * D + 8 * r + 16 * (r * D) + 16 * (r * s) + 15 * (r * D * s) +
           8 * (r * D ^ 2) + 16 * (r ^ 2 * s) + 16 * (r ^ 2 * D * s) +
           8 * (r ^ 2 * D) + 4 * D ^ 2 + 4 * r ^ 2 + 4 * (r ^ 2 * D ^ 2) +
           16 * (r ^ 2 * s ^ 2)) =
          4 * ((D + r * s) + (r * D + r) + r * s + 1) ^ 2)
    obtain ⟨hBU0, hBB0, hBC0, hBP0, hBK50⟩ := poly_solver_bounds nVars nEq nLe B
      m_extra 3 flatPts.length hm_extra_le (by omega) hlenRat_le
    have hScale : 10 ^ 26 * (nVars + nEq + nLe + B + 1) ^ 22 ≤ bound :=
      hull_scale_bound D r s B
    -- Pure LP spec & equivalence with multi-block convex-hull intersection
    have hPure := solveRationalLP_spec hB'1
      (hullAEq_num pts) (hullAEq_den pts) hullbEq_num hullbEq_den
      hullALe_num hullALe_den hullbLe_num hullbLe_den
      hEqDenPos (fun _ => Int.zero_lt_one) (fun _ _ => Int.zero_lt_one) (fun _ => Int.zero_lt_one)
      hEqNumB hEqDenB
      (fun row => by dsimp [hullbEq_num]; split_ifs <;> simp [Nat.one_le_two_pow])
      (fun _ => Nat.one_le_two_pow)
      hLeNumB (fun _ _ => Nat.one_le_two_pow) (fun _ => Nat.zero_le _) (fun _ => Nat.one_le_two_pow)
    change (res.1 = 0 ∨ res.1 = 1) ∧ _ ∧ _ at hPure
    obtain ⟨hF01, hFIff, hFWhen1⟩ := hPure
    -- Row/Inequality helper characterization for any x : Fin (D + r * s) → ℝ
    have hSysDecomp : ∀ x : Fin nVars → ℝ,
        ((∀ row : Fin nEq, ∑ v : Fin nVars,
            (((hullAEq_num pts row v : ℚ) / (hullAEq_den pts row v : ℚ) : ℚ) : ℝ) * x v =
            (((hullbEq_num row : ℚ) / (hullbEq_den row : ℚ) : ℚ) : ℝ)) ∧
         (∀ k : Fin nLe, ∑ v : Fin nVars,
            (((hullALe_num k v : ℚ) / (hullALe_den k v : ℚ) : ℚ) : ℝ) * x v ≤
            (((hullbLe_num k : ℚ) / (hullbLe_den k : ℚ) : ℚ) : ℝ))) ↔
        (∀ i : Fin r, UL.IsConvexHullCert
          (fun j : Fin s => UL.ratPointToEuclidean (pts i j))
          ((WithLp.equiv 2 (Fin D → ℝ)).symm (fun c : Fin D => x ⟨c.val, by dsimp [nVars]; omega⟩))
          (fun j : Fin s => x ⟨D + (i.val * s + j.val),
            by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩)) := by
      intro x
      -- Helper 1: inequality k ↔ 0 ≤ x (D + k)
      have hLeOne : ∀ k : Fin nLe,
          (∑ v : Fin nVars, (((hullALe_num k v : ℚ) / (hullALe_den k v : ℚ) : ℚ) : ℝ) * x v ≤
            (((hullbLe_num k : ℚ) / (hullbLe_den k : ℚ) : ℚ) : ℝ)) ↔
          0 ≤ x ⟨D + k.val, by dsimp [nVars, nLe] at k ⊢; omega⟩ := by
        intro k
        let vk : Fin nVars := ⟨D + k.val, by dsimp [nVars, nLe] at k ⊢; omega⟩
        have hsum : ∑ v : Fin nVars, (((hullALe_num k v : ℚ) / (hullALe_den k v : ℚ) : ℚ) : ℝ) * x v =
            - x vk := by
          have hterm : ∀ v : Fin nVars,
              (((hullALe_num k v : ℚ) / (hullALe_den k v : ℚ) : ℚ) : ℝ) * x v =
                if v = vk then - x vk else 0 := by
            intro v; dsimp [hullALe_num, hullALe_den]
            by_cases hv : v = vk
            · subst hv; simp [vk]
            · have hne : v.val ≠ D + k.val := fun h => hv (Fin.ext h)
              rw [if_neg hne, if_neg hv]; simp
          rw [Finset.sum_congr rfl (fun v _ => hterm v)]; simp
        rw [hsum]; dsimp [hullbLe_num, hullbLe_den, vk]; norm_num
      -- Helper 2: coordinate row (i * D + c)
      have hCoordRow : ∀ (i : Fin r) (c : Fin D),
          let row : Fin nEq := ⟨i.val * D + c.val,
            lt_of_lt_of_le (row_col_lt_mul i.isLt c.isLt) (Nat.le_add_right _ _)⟩
          ∑ v : Fin nVars, (((hullAEq_num pts row v : ℚ) / (hullAEq_den pts row v : ℚ) : ℚ) : ℝ) * x v =
            - x ⟨c.val, by dsimp [nVars]; omega⟩ +
            ∑ j : Fin s, (pts i j c : ℝ) * x ⟨D + (i.val * s + j.val),
              by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩ := by
        intro i c row
        have hrow_lt : row.val < r * D := row_col_lt_mul i.isLt c.isLt
        have hdm := div_mod_encode_eq i c
        rw [sum_fin_add D (r * s), sum_fin_mul r s]
        congr 1
        · have hterm1 : ∀ c' : Fin D,
              (((hullAEq_num pts row ⟨c'.val, by omega⟩ : ℚ) /
                (hullAEq_den pts row ⟨c'.val, by omega⟩ : ℚ) : ℚ) : ℝ) *
                x ⟨c'.val, by dsimp [nVars]; omega⟩ =
              if c' = c then - x ⟨c.val, by dsimp [nVars]; omega⟩ else 0 := by
            intro c'
            dsimp [hullAEq_num, hullAEq_den]
            rw [dif_pos hrow_lt, dif_pos hrow_lt, dif_pos c'.isLt, dif_pos c'.isLt]
            have hc_mod : row.val % D = c.val := hdm.2
            rw [hc_mod]
            by_cases hcc : c' = c
            · subst hcc; simp
            · have hne : c'.val ≠ c.val := fun h => hcc (Fin.ext h)
              simp [hcc, hne]
          rw [Finset.sum_congr rfl (fun c' _ => hterm1 c')]; simp
        · have hterm2 : ∀ i' : Fin r,
              (∑ j' : Fin s,
                (((hullAEq_num pts row ⟨D + (i'.val * s + j'.val),
                    Nat.add_lt_add_left (row_col_lt_mul i'.isLt j'.isLt) D⟩ : ℚ) /
                  (hullAEq_den pts row ⟨D + (i'.val * s + j'.val),
                    Nat.add_lt_add_left (row_col_lt_mul i'.isLt j'.isLt) D⟩ : ℚ) : ℚ) : ℝ) *
                  x ⟨D + (i'.val * s + j'.val),
                    by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i'.isLt j'.isLt) D⟩) =
              if i' = i then
                ∑ j' : Fin s, (pts i j' c : ℝ) * x ⟨D + (i.val * s + j'.val),
                  by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j'.isLt) D⟩
              else 0 := by
            intro i'
            by_cases hii : i' = i
            · subst hii; rw [if_pos rfl]
              refine Finset.sum_congr rfl (fun j' _ => ?_)
              have hnotD : ¬ (D + (i'.val * s + j'.val) < D) := by omega
              have hdm_ij := div_mod_encode_eq i' j'
              dsimp [hullAEq_num, hullAEq_den]
              rw [dif_pos hrow_lt, dif_pos hrow_lt, dif_neg hnotD, dif_neg hnotD]
              have hsub_eq : (D + (i'.val * s + j'.val)) - D = i'.val * s + j'.val := by omega
              have hi_eq : (⟨((D + (i'.val * s + j'.val)) - D) / s,
                  by rw [hsub_eq, hdm_ij.1]; exact i'.isLt⟩ : Fin r) = i' := by
                ext; simp [hsub_eq, hdm_ij.1]
              have hj_eq : (⟨((D + (i'.val * s + j'.val)) - D) % s,
                  by rw [hsub_eq, hdm_ij.2]; exact j'.isLt⟩ : Fin s) = j' := by
                ext; simp [hsub_eq, hdm_ij.2]
              have hi_row : (⟨row.val / D, by dsimp [row]; rw [hdm.1]; exact i'.isLt⟩ : Fin r) = i' := by
                ext; simp [row, hdm.1]
              have hc_row : (⟨row.val % D, by dsimp [row]; rw [hdm.2]; exact c.isLt⟩ : Fin D) = c := by
                ext; simp [row, hdm.2]
              rw [hi_eq, hj_eq, hi_row, hc_row, if_pos rfl, if_pos rfl, Int.cast_natCast, Rat.num_div_den]
            · rw [if_neg hii]
              refine Finset.sum_eq_zero (fun j' _ => ?_)
              have hnotD : ¬ (D + (i'.val * s + j'.val) < D) := by omega
              have hdm_ij := div_mod_encode_eq i' j'
              dsimp [hullAEq_num, hullAEq_den]
              rw [dif_pos hrow_lt, dif_pos hrow_lt, dif_neg hnotD, dif_neg hnotD]
              have hsub_eq : (D + (i'.val * s + j'.val)) - D = i'.val * s + j'.val := by omega
              have hi_eq : (⟨((D + (i'.val * s + j'.val)) - D) / s,
                  by rw [hsub_eq, hdm_ij.1]; exact i'.isLt⟩ : Fin r) = i' := by
                ext; simp [hsub_eq, hdm_ij.1]
              have hi_row : (⟨row.val / D, by dsimp [row]; rw [hdm.1]; exact i.isLt⟩ : Fin r) = i := by
                ext; simp [row, hdm.1]
              rw [hi_eq, hi_row, if_neg hii, if_neg hii]
              simp
          rw [Finset.sum_congr rfl (fun i' _ => hterm2 i')]; simp
      -- Helper 3: sum-to-1 row (r * D + i)
      have hSumRow : ∀ i : Fin r,
          let row : Fin nEq := ⟨r * D + i.val, by dsimp [nEq]; omega⟩
          ∑ v : Fin nVars, (((hullAEq_num pts row v : ℚ) / (hullAEq_den pts row v : ℚ) : ℚ) : ℝ) * x v =
            ∑ j : Fin s, x ⟨D + (i.val * s + j.val),
              by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩ := by
        intro i row
        have hnot_lt : ¬ (row.val < r * D) := by dsimp [row]; omega
        rw [sum_fin_add D (r * s), sum_fin_mul r s]
        have hz1 : (∑ c' : Fin D,
            (((hullAEq_num pts row ⟨c'.val, by omega⟩ : ℚ) /
              (hullAEq_den pts row ⟨c'.val, by omega⟩ : ℚ) : ℚ) : ℝ) *
              x ⟨c'.val, by dsimp [nVars]; omega⟩) = 0 := by
          refine Finset.sum_eq_zero (fun c' _ => ?_)
          dsimp [hullAEq_num, hullAEq_den]
          rw [dif_neg hnot_lt, dif_pos c'.isLt]
          simp
        rw [hz1, zero_add]
        have hterm2 : ∀ i' : Fin r,
            (∑ j' : Fin s,
              (((hullAEq_num pts row ⟨D + (i'.val * s + j'.val),
                  Nat.add_lt_add_left (row_col_lt_mul i'.isLt j'.isLt) D⟩ : ℚ) /
                (hullAEq_den pts row ⟨D + (i'.val * s + j'.val),
                  Nat.add_lt_add_left (row_col_lt_mul i'.isLt j'.isLt) D⟩ : ℚ) : ℚ) : ℝ) *
                x ⟨D + (i'.val * s + j'.val),
                  by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i'.isLt j'.isLt) D⟩) =
            if i' = i then
              ∑ j' : Fin s, x ⟨D + (i.val * s + j'.val),
                by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j'.isLt) D⟩
            else 0 := by
          intro i'
          have hi_row : (⟨row.val - r * D, by dsimp [nEq] at row; omega⟩ : Fin r) = i := by
            ext; dsimp [row]; omega
          by_cases hii : i' = i
          · subst hii; rw [if_pos rfl]
            refine Finset.sum_congr rfl (fun j' _ => ?_)
            have hnotD : ¬ (D + (i'.val * s + j'.val) < D) := by omega
            have hdm_ij := div_mod_encode_eq i' j'
            dsimp [hullAEq_num, hullAEq_den]
            rw [dif_neg hnot_lt, dif_neg hnot_lt, dif_neg hnotD]
            have hsub_eq : (D + (i'.val * s + j'.val)) - D = i'.val * s + j'.val := by omega
            have hi_eq : (⟨((D + (i'.val * s + j'.val)) - D) / s,
                by rw [hsub_eq, hdm_ij.1]; exact i'.isLt⟩ : Fin r) = i' := by
              ext; simp [hsub_eq, hdm_ij.1]
            rw [hi_eq, hi_row, if_pos rfl]
            simp
          · rw [if_neg hii]
            refine Finset.sum_eq_zero (fun j' _ => ?_)
            have hnotD : ¬ (D + (i'.val * s + j'.val) < D) := by omega
            have hdm_ij := div_mod_encode_eq i' j'
            dsimp [hullAEq_num, hullAEq_den]
            rw [dif_neg hnot_lt, dif_neg hnot_lt, dif_neg hnotD]
            have hsub_eq : (D + (i'.val * s + j'.val)) - D = i'.val * s + j'.val := by omega
            have hi_eq : (⟨((D + (i'.val * s + j'.val)) - D) / s,
                by rw [hsub_eq, hdm_ij.1]; exact i'.isLt⟩ : Fin r) = i' := by
              ext; simp [hsub_eq, hdm_ij.1]
            rw [hi_eq, hi_row, if_neg hii]
            simp
        rw [Finset.sum_congr rfl (fun i' _ => hterm2 i')]; simp
      -- Combine both directions of hSysDecomp
      constructor
      · rintro ⟨hEq, hLe⟩ i
        rw [isConvexHullCert_rat_iff]
        refine ⟨fun j => ?_, ?_, fun c => ?_⟩
        · have hk := (hLeOne ⟨i.val * s + j.val, row_col_lt_mul i.isLt j.isLt⟩).mp
            (hLe ⟨i.val * s + j.val, row_col_lt_mul i.isLt j.isLt⟩)
          exact hk
        · have hs_i := hEq ⟨r * D + i.val, by dsimp [nEq]; omega⟩
          rw [hSumRow i] at hs_i
          have hrhs : (((hullbEq_num (D := D) (r := r) ⟨r * D + i.val, by omega⟩ : ℚ) /
              (hullbEq_den (D := D) (r := r) ⟨r * D + i.val, by omega⟩ : ℚ) : ℚ) : ℝ) = 1 := by
            dsimp [hullbEq_num, hullbEq_den]; rw [if_neg (by omega)]; norm_num
          exact hs_i.trans hrhs
        · let row_ic : Fin (r * D + r) := ⟨i.val * D + c.val,
            lt_of_lt_of_le (row_col_lt_mul i.isLt c.isLt) (Nat.le_add_right _ _)⟩
          have hc_i := hEq row_ic
          rw [hCoordRow i c] at hc_i
          have hrhs : (((hullbEq_num row_ic : ℚ) / (hullbEq_den row_ic : ℚ) : ℚ) : ℝ) = 0 := by
            dsimp [hullbEq_num, hullbEq_den, row_ic]
            rw [if_pos (row_col_lt_mul i.isLt c.isLt)]; norm_num
          rw [hrhs] at hc_i
          simp only [Equiv.apply_symm_apply]
          linarith
      · intro hCerts
        refine ⟨fun row => ?_, fun k => ?_⟩
        · by_cases hlt : row.val < r * D
          · obtain ⟨_, hdiv, hmod, hdm⟩ := div_mod_of_lt_mul hlt
            let i : Fin r := ⟨row.val / D, hdiv⟩
            let c : Fin D := ⟨row.val % D, hmod⟩
            have hrow_eq : row = ⟨i.val * D + c.val,
                lt_of_lt_of_le (row_col_lt_mul i.isLt c.isLt) (Nat.le_add_right _ _)⟩ :=
              Fin.ext hdm.symm
            rw [hrow_eq, hCoordRow i c]
            obtain ⟨_, _, hCoords⟩ := (isConvexHullCert_rat_iff _ _ _).mp (hCerts i)
            have hc := hCoords c
            simp only [Equiv.apply_symm_apply] at hc
            let row_ic : Fin (r * D + r) := ⟨i.val * D + c.val,
              lt_of_lt_of_le (row_col_lt_mul i.isLt c.isLt) (Nat.le_add_right _ _)⟩
            have hrhs : (((hullbEq_num row_ic : ℚ) / (hullbEq_den row_ic : ℚ) : ℚ) : ℝ) = 0 := by
              dsimp [hullbEq_num, hullbEq_den, row_ic]
              rw [if_pos (row_col_lt_mul i.isLt c.isLt)]; norm_num
            rw [hrhs]; linarith
          · let i : Fin r := ⟨row.val - r * D, by dsimp [nEq] at row; omega⟩
            have hrow_eq : row = ⟨r * D + i.val, by dsimp [nEq]; omega⟩ := by
              ext; dsimp [i]; omega
            rw [hrow_eq, hSumRow i]
            obtain ⟨_, hSum1, _⟩ := (isConvexHullCert_rat_iff _ _ _).mp (hCerts i)
            let row_si : Fin (r * D + r) := ⟨r * D + i.val, by omega⟩
            have hrhs : (((hullbEq_num row_si : ℚ) / (hullbEq_den row_si : ℚ) : ℚ) : ℝ) = 1 := by
              dsimp [hullbEq_num, hullbEq_den, row_si]; rw [if_neg (by omega)]; norm_num
            rw [hrhs]; exact hSum1
        · obtain ⟨_, hdiv, hmod, hdm⟩ := div_mod_of_lt_mul k.isLt
          let i : Fin r := ⟨k.val / s, hdiv⟩
          let j : Fin s := ⟨k.val % s, hmod⟩
          obtain ⟨hNonneg, _, _⟩ := (isConvexHullCert_rat_iff _ _ _).mp (hCerts i)
          apply (hLeOne k).mpr
          have hvk : (⟨D + k.val, by dsimp [nVars, nLe] at k ⊢; omega⟩ : Fin nVars) =
              ⟨D + (i.val * s + j.val),
                by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩ := by
            ext; dsimp [i, j]; omega
          rw [hvk]; exact hNonneg j
    have hOutFlag : out.words.read (.heap 0 0) = res.1 := by
      rw [hout_ws]; change hRead ws9 0 0 = res.1
      rw [hpr9 0 0 (by omega), hpr8 0 0 (by omega)]
      exact hRead_hWrite_self ws6 0 0 res.1
    have hCellsLe : ctxPeakCells inp maxIdx ≤ 3 + 2 * flatPts.length + 32 * (maxIdx + 1) := by
      dsimp [ctxPeakCells, inp]; rw [hInpCells]; simp
    have hBP0' : 3 * (K + 3) + flatPts.length * (2 * K + 6) +
        32 * (maxIdx + 1) * (2 * K + 14) ≤ 10 ^ 26 * (nVars + nEq + nLe + B + 1) ^ 22 := hBP0
    have hBitsLe : ctxPeakBits inp maxIdx K ≤ bound := by
      dsimp [ctxPeakBits, inp]
      exact (Nat.add_le_add_right (by simpa using hInpBits) _).trans (hBP0'.trans hScale)
    refine ⟨out, hRun, huCost.trans (hBU0.trans hScale), hbCost.trans (hBB0.trans hScale),
      hpCells.trans (hCellsLe.trans (hBC0.trans hScale)),
      hpBits.trans hBitsLe,
      ?_, ?_, ?_⟩
    · rw [hOutFlag]; exact hF01
    · rw [hOutFlag]
      refine hFIff.trans ⟨?_, ?_⟩
      · rintro ⟨(x : Fin nVars → ℝ), hx⟩
        exact ⟨(WithLp.equiv 2 (Fin D → ℝ)).symm (fun c => x ⟨c.val, by dsimp [nVars]; omega⟩),
          fun i => ⟨_, (hSysDecomp x).mp hx i⟩⟩
      · rintro ⟨z, hz⟩
        let lamWitness : Fin r → Fin s → ℝ := fun i => Classical.choose (hz i)
        have hlamSpec : ∀ i : Fin r,
            UL.IsConvexHullCert (fun j => UL.ratPointToEuclidean (pts i j)) z (lamWitness i) :=
          fun i => Classical.choose_spec (hz i)
        let x : Fin nVars → ℝ := fun v =>
          if hv : v.val < D then WithLp.equiv 2 (Fin D → ℝ) z ⟨v.val, hv⟩
          else
            let hvs : v.val - D < r * s := by dsimp [nVars] at v; omega
            let hds := div_mod_of_lt_mul hvs
            lamWitness ⟨(v.val - D) / s, hds.2.1⟩ ⟨(v.val - D) % s, hds.2.2.1⟩
        refine ⟨x, (hSysDecomp x).mpr (fun i => ?_)⟩
        have hz_eq : ((WithLp.equiv 2 (Fin D → ℝ)).symm
            (fun c : Fin D => x ⟨c.val, by dsimp [nVars]; omega⟩)) = z := by
          have hfn : (fun c : Fin D => x ⟨c.val, by dsimp [nVars]; omega⟩) =
              WithLp.equiv 2 (Fin D → ℝ) z := by
            funext c; dsimp [x]; rw [dif_pos c.isLt]
          rw [hfn, Equiv.symm_apply_apply]
        have hw_eq : (fun j : Fin s => x ⟨D + (i.val * s + j.val),
            by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩) =
            lamWitness i := by
          funext j
          dsimp [x]
          rw [dif_neg (by omega)]
          have hdm := div_mod_encode_eq i j
          have hsub : (D + (i.val * s + j.val)) - D = i.val * s + j.val := by omega
          have hi_eq : (⟨((D + (i.val * s + j.val)) - D) / s,
              by rw [hsub, hdm.1]; exact i.isLt⟩ : Fin r) = i := by
            ext; simp [hsub, hdm.1]
          have hj_eq : (⟨((D + (i.val * s + j.val)) - D) % s,
              by rw [hsub, hdm.2]; exact j.isLt⟩ : Fin s) = j := by
            ext; simp [hsub, hdm.2]
          rw [hi_eq, hj_eq]
        rw [hz_eq, hw_eq]
        exact hlamSpec i
    · intro h1
      rw [hOutFlag] at h1
      obtain ⟨hSolB, hEqSat, hLeSat⟩ := hFWhen1 h1
      have hBarK := bareiss_bound_le_two_pow_solverK nVars nEq nLe B'
      have hReadZ : ∀ k : Fin D,
          out.words.read (.heap 1 (2 * (k.val : ℤ))) = res.2.1 ⟨k.val, by omega⟩ ∧
          out.words.read (.heap 1 (2 * (k.val : ℤ) + 1)) = res.2.2 ⟨k.val, by omega⟩ := by
        intro k
        rw [hout_ws]
        change hRead ws9 1 (2 * (k.val : ℤ)) = _ ∧ hRead ws9 1 (2 * (k.val : ℤ) + 1) = _
        rw [hpr9 1 _ (by omega), hpr9 1 _ (by omega)]
        simpa using hOutZ8 k
      have hReadLam : ∀ (i : Fin r) (j : Fin s),
          out.words.read (.heap 2 (2 * ((i.val * s + j.val : ℕ) : ℤ))) =
            res.2.1 ⟨D + (i.val * s + j.val),
              Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩ ∧
          out.words.read (.heap 2 (2 * ((i.val * s + j.val : ℕ) : ℤ) + 1)) =
            res.2.2 ⟨D + (i.val * s + j.val),
              Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩ := by
        intro i j
        rw [hout_ws]
        simpa using hOutLam9 ⟨i.val * s + j.val, row_col_lt_mul i.isLt j.isLt⟩
      have hZBounds : ∀ k : Fin D,
          let vj : Fin nVars := ⟨k.val, by dsimp [nVars]; omega⟩
          0 < res.2.2 vj ∧
          UL.intBitLength (res.2.1 vj) ≤ bound ∧
          UL.intBitLength (res.2.2 vj) ≤ bound ∧
          UL.RatCoordBitBounded bound ((res.2.1 vj : ℚ) / (res.2.2 vj : ℚ)) ∧
          UL.ratBitLength ((res.2.1 vj : ℚ) / (res.2.2 vj : ℚ)) ≤ bound := by
        intro k vj
        obtain ⟨hpos, hnB, hdB⟩ := hSolB vj
        obtain ⟨hb1, hb2, hb3, hb4⟩ :=
          rat_div_bit_bounds hpos (hnB.trans hBarK) (hdB.trans hBarK) (hBK50.trans hScale)
        exact ⟨hpos, hb1, hb2, hb3, hb4⟩
      refine ⟨fun k => ?_, fun k => ?_, fun i j => ?_, ?_⟩
      · dsimp only; rw [(hReadZ k).1, (hReadZ k).2]; exact (hZBounds k).2.2.2.1
      · dsimp only; rw [(hReadZ k).1, (hReadZ k).2]
        exact ⟨(hZBounds k).1, (hZBounds k).2.1, (hZBounds k).2.2.1, (hZBounds k).2.2.2.2⟩
      · dsimp only; rw [(hReadLam i j).1, (hReadLam i j).2]
        let vj : Fin nVars := ⟨D + (i.val * s + j.val),
          by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩
        obtain ⟨hpos, hnB, hdB⟩ := hSolB vj
        obtain ⟨hb1, hb2, hb3, hb4⟩ :=
          rat_div_bit_bounds hpos (hnB.trans hBarK) (hdB.trans hBarK) (hBK50.trans hScale)
        exact ⟨hpos, hb1, hb2, hb3, hb4⟩
      · let xSol : Fin nVars → ℝ := fun v => (((res.2.1 v : ℚ) / (res.2.2 v : ℚ) : ℚ) : ℝ)
        have hxSol_cert := (hSysDecomp xSol).mp
          ⟨fun row => rat_sum_eq_to_real
              (fun v => (hullAEq_num pts row v : ℚ) / (hullAEq_den pts row v : ℚ))
              (fun v => (res.2.1 v : ℚ) / (res.2.2 v : ℚ))
              ((hullbEq_num row : ℚ) / (hullbEq_den row : ℚ))
              (hEqSat row),
           fun k => rat_sum_le_to_real
              (fun v => (hullALe_num k v : ℚ) / (hullALe_den k v : ℚ))
              (fun v => (res.2.1 v : ℚ) / (res.2.2 v : ℚ))
              ((hullbLe_num k : ℚ) / (hullbLe_den k : ℚ))
              (hLeSat k)⟩
        intro i
        have hi_cert := hxSol_cert i
        have hz_eq : ((WithLp.equiv 2 (Fin D → ℝ)).symm
            (fun c : Fin D => xSol ⟨c.val, by dsimp [nVars]; omega⟩)) =
            UL.ratPointToEuclidean (fun k : Fin D =>
              ((out.words.read (.heap 1 (2 * (k.val : ℤ))) : ℚ) /
               (out.words.read (.heap 1 (2 * (k.val : ℤ) + 1)) : ℚ))) := by
          dsimp [UL.ratPointToEuclidean, xSol]
          congr 1; funext k
          rw [(hReadZ k).1, (hReadZ k).2]
        have hw_eq : (fun j : Fin s => xSol ⟨D + (i.val * s + j.val),
            by dsimp [nVars]; exact Nat.add_lt_add_left (row_col_lt_mul i.isLt j.isLt) D⟩) =
            (fun j : Fin s => (((out.words.read (.heap 2 (2 * ((i.val * s + j.val : ℕ) : ℤ))) : ℚ) /
              (out.words.read (.heap 2 (2 * ((i.val * s + j.val : ℕ) : ℤ) + 1)) : ℚ) : ℚ) : ℝ)) := by
          funext j; dsimp only [xSol]; rw [(hReadLam i j).1, (hReadLam i j).2]
        rwa [hz_eq, hw_eq] at hi_cert

end UL.Proof.cit_gls88_rational_lp.RacerCG
