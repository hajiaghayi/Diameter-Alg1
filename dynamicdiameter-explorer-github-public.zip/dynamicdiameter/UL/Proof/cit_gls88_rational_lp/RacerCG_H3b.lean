import Mathlib
import UL.Proof.cit_gls88_rational_lp.RacerCG_H2c
import UL.Proof.cit_gls88_rational_lp.RacerCG_H3a
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

/-! ### 1. Step-Normalized `ExecBit` Wrappers & Footprint Framing (`PreservesOutside`) -/

def stepU : ℕ := 100
def stepB (K : ℕ) : ℕ := 2000000 * K ^ 2

def PreservesOutside (mod : ℕ → ℤ → Prop) (ws₀ ws₁ : UL.WordStore) : Prop :=
  ∀ (t : ℕ) (i : ℤ), ¬ mod t i → hRead ws₁ t i = hRead ws₀ t i

theorem PreservesOutside.refl (mod : ℕ → ℤ → Prop) (ws : UL.WordStore) :
    PreservesOutside mod ws ws :=
  fun _ _ _ => rfl

theorem PreservesOutside.trans {mod : ℕ → ℤ → Prop} {ws₀ ws₁ ws₂ : UL.WordStore}
    (h₁ : PreservesOutside mod ws₀ ws₁) (h₂ : PreservesOutside mod ws₁ ws₂) :
    PreservesOutside mod ws₀ ws₂ :=
  fun t i hnot => (h₂ t i hnot).trans (h₁ t i hnot)

theorem PreservesOutside.mono {mod₁ mod₂ : ℕ → ℤ → Prop} {ws₀ ws₁ : UL.WordStore}
    (hsub : ∀ t i, mod₁ t i → mod₂ t i) (h : PreservesOutside mod₁ ws₀ ws₁) :
    PreservesOutside mod₂ ws₀ ws₁ :=
  fun t i hnot => h t i (fun hm => hnot (hsub t i hm))

theorem PreservesOutside.write {mod : ℕ → ℤ → Prop} (ws : UL.WordStore)
    {t : ℕ} {idx : ℤ} (val : ℤ) (hmod : mod t idx) :
    PreservesOutside mod ws (hWrite ws t idx val) := by
  intro t' i' hnot
  apply hRead_hWrite_of_ne
  by_contra hneg
  push_neg at hneg
  rcases hneg with ⟨rfl, rfl⟩
  exact hnot hmod

theorem ExecBit.seq_steps {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    {s₁ s₂ : UL.BitRAMStmt} {ws₀ ws₁ ws₂ : UL.WordStore} {m₁ m₂ : ℕ}
    (h₁ : ExecBit inp maxIdx K s₁ ws₀ ws₁ (m₁ * stepU) (m₁ * stepB K))
    (h₂ : ExecBit inp maxIdx K s₂ ws₁ ws₂ (m₂ * stepU) (m₂ * stepB K)) :
    ExecBit inp maxIdx K (.seq s₁ s₂) ws₀ ws₂ ((m₁ + m₂) * stepU) ((m₁ + m₂) * stepB K) := by
  refine (h₁.seq h₂).mono ?_ ?_
  · rw [Nat.add_mul]
  · rw [Nat.add_mul]

theorem ExecBit.mono_steps {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    {s : UL.BitRAMStmt} {ws₀ ws₁ : UL.WordStore} {m₁ m₂ : ℕ}
    (h : ExecBit inp maxIdx K s ws₀ ws₁ (m₁ * stepU) (m₁ * stepB K))
    (hm : m₁ ≤ m₂) :
    ExecBit inp maxIdx K s ws₀ ws₁ (m₂ * stepU) (m₂ * stepB K) :=
  h.mono (Nat.mul_le_mul_right _ hm) (Nat.mul_le_mul_right _ hm)

theorem exec_skip {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) {ws : UL.WordStore} (hws : StoreBounded 31 maxIdx K ws) :
    ExecBit inp maxIdx K .skip ws ws (1 * stepU) (1 * stepB K) := by
  refine (ExecBit.skip hws).mono (by dsimp [stepU]; omega) ?_
  dsimp [stepB]
  have hK := hctx.hK
  have h1 : 1 ≤ K ^ 2 := by rw [sq]; exact Nat.mul_pos (by omega) (by omega)
  calc 1 ≤ 2000000 * 1 := by omega
    _ ≤ 1 * (2000000 * K ^ 2) := by rw [one_mul]; exact Nat.mul_le_mul_left _ h1

theorem exec_write {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    {ws : UL.WordStore} (hws : StoreBounded 31 maxIdx K ws)
    (t : ℕ) (idxE valE : UL.IntExpr) (idx val : ℤ)
    (hidx_eq : evalVal inp ws idxE = idx)
    (hval_eq : evalVal inp ws valE = val)
    (hi0 : 0 ≤ idx) (hi1 : idx ≤ (maxIdx : ℤ))
    (hv : val.natAbs ≤ 2 ^ K)
    (ht : t ≤ 31 := by decide)
    (hwf_i : exprWf 31 idxE = true := by decide)
    (hwf_v : exprWf 31 valE = true := by decide)
    (hsize : exprNodes idxE + exprNodes valE + 2 ≤ 64 ∧
             exprLeaves idxE + exprLeaves valE + 2 ≤ 64 := by decide) :
    ExecBit inp maxIdx K (.writeHeap t idxE valE) ws (hWrite ws t idx val)
      (1 * stepU) (1 * stepB K) := by
  have hw := ExecBit.writeHeap hctx hws t idxE valE ht hwf_i hwf_v
    (by rwa [hidx_eq]) (by rwa [hidx_eq]) (by rwa [hval_eq])
  dsimp only at hw
  rw [hidx_eq, hval_eq] at hw
  refine hw.mono ?_ ?_
  · dsimp [stepU]; omega
  · dsimp [stepB]
    rw [one_mul]
    have hL : 2 * (exprLeaves idxE + exprLeaves valE + 2) * K ≤ 128 * K :=
      Nat.mul_le_mul_right K (by omega)
    calc (exprNodes idxE + exprNodes valE + 2) *
          (2 * (exprLeaves idxE + exprLeaves valE + 2) * K) ^ 2
        ≤ 64 * (128 * K) ^ 2 :=
          Nat.mul_le_mul hsize.1 (Nat.pow_le_pow_left hL 2)
      _ = 1048576 * K ^ 2 := by ring
      _ ≤ 2000000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)

theorem exec_ite_true {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    {ws₀ ws₁ : UL.WordStore} (cond : UL.BitCondExpr) (tB fB : UL.BitRAMStmt) {m : ℕ}
    (hcond : evalCondVal inp ws₀ cond = true)
    (ht : ExecBit inp maxIdx K tB ws₀ ws₁ (m * stepU) (m * stepB K))
    (hwf_c : condWf 31 cond = true := by decide)
    (hsz_c : condNodes cond ≤ 64 ∧ condLeaves cond ≤ 64 := by decide) :
    ExecBit inp maxIdx K (.ite cond tB fB) ws₀ ws₁
      ((m + 1) * stepU) ((m + 1) * stepB K) := by
  refine (ExecBit.ite_true hctx cond tB fB hwf_c hcond ht).mono ?_ ?_
  · dsimp [stepU]; omega
  · have hL : 2 * condLeaves cond * K ≤ 128 * K := Nat.mul_le_mul_right K (by omega)
    have hc : condNodes cond * (2 * condLeaves cond * K) ^ 2 ≤ stepB K := by
      dsimp [stepB]
      calc condNodes cond * (2 * condLeaves cond * K) ^ 2
          ≤ 64 * (128 * K) ^ 2 := Nat.mul_le_mul hsz_c.1 (Nat.pow_le_pow_left hL 2)
        _ = 1048576 * K ^ 2 := by ring
        _ ≤ 2000000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)
    calc condNodes cond * (2 * condLeaves cond * K) ^ 2 + m * stepB K
        ≤ stepB K + m * stepB K := Nat.add_le_add_right hc _
      _ = (m + 1) * stepB K := by ring

theorem exec_ite_false {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    {ws₀ ws₁ : UL.WordStore} (cond : UL.BitCondExpr) (tB fB : UL.BitRAMStmt) {m : ℕ}
    (hcond : evalCondVal inp ws₀ cond = false)
    (hf : ExecBit inp maxIdx K fB ws₀ ws₁ (m * stepU) (m * stepB K))
    (hwf_c : condWf 31 cond = true := by decide)
    (hsz_c : condNodes cond ≤ 64 ∧ condLeaves cond ≤ 64 := by decide) :
    ExecBit inp maxIdx K (.ite cond tB fB) ws₀ ws₁
      ((m + 1) * stepU) ((m + 1) * stepB K) := by
  refine (ExecBit.ite_false hctx cond tB fB hwf_c hcond hf).mono ?_ ?_
  · dsimp [stepU]; omega
  · have hL : 2 * condLeaves cond * K ≤ 128 * K := Nat.mul_le_mul_right K (by omega)
    have hc : condNodes cond * (2 * condLeaves cond * K) ^ 2 ≤ stepB K := by
      dsimp [stepB]
      calc condNodes cond * (2 * condLeaves cond * K) ^ 2
          ≤ 64 * (128 * K) ^ 2 := Nat.mul_le_mul hsz_c.1 (Nat.pow_le_pow_left hL 2)
        _ = 1048576 * K ^ 2 := by ring
        _ ≤ 2000000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)
    calc condNodes cond * (2 * condLeaves cond * K) ^ 2 + m * stepB K
        ≤ stepB K + m * stepB K := Nat.add_le_add_right hc _
      _ = (m + 1) * stepB K := by ring

theorem exec_for {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    (ctrSlot : ℤ) (countE : UL.IntExpr) (body : UL.BitRAMStmt)
    (N m_body : ℕ) (Inv : ℕ → UL.WordStore → Prop)
    {ws₀ : UL.WordStore}
    (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hslot1 : ctrSlot ≤ (maxIdx : ℤ))
    (hN_le : N ≤ maxIdx)
    (hcnt : evalVal inp (hWrite ws₀ 10 ctrSlot 0) countE = (N : ℤ))
    (hInv₀ : Inv 0 (hWrite ws₀ 10 ctrSlot 0))
    (hstep : ∀ k < N, ∀ ws : UL.WordStore,
      StoreBounded 31 maxIdx K ws →
      hRead ws 10 ctrSlot = (k : ℤ) →
      Inv k ws →
      ∃ ws', ExecBit inp maxIdx K body ws ws' (m_body * stepU) (m_body * stepB K) ∧
        hRead ws' 10 ctrSlot = (k : ℤ) ∧
        Inv (k + 1) (hWrite ws' 10 ctrSlot ((k : ℤ) + 1)))
    (hslot_wf : ctrSlot.natAbs ≤ 64 := by decide)
    (hslot0 : 0 ≤ ctrSlot := by decide)
    (hwf_cnt : exprWf 31 countE = true := by decide)
    (hsz_cnt : exprNodes countE ≤ 64 ∧ exprLeaves countE ≤ 64 := by decide) :
    ∃ ws_N : UL.WordStore,
      hRead ws_N 10 ctrSlot = (N : ℤ) ∧
      Inv N ws_N ∧
      ExecBit inp maxIdx K (forLoopStmt ctrSlot countE body) ws₀ ws_N
        ((2 + N * (m_body + 1)) * stepU)
        ((2 + N * (m_body + 1)) * stepB K) := by
  obtain ⟨ws_N, hctrN, hInvN, hex⟩ := exec_forLoopStmt hctx ctrSlot countE body
    N (m_body * stepU) (m_body * stepB K) Inv hws₀ hslot_wf hslot0 hslot1 hN_le
    hwf_cnt hcnt hInv₀ hstep
  refine ⟨ws_N, hctrN, hInvN, hex.mono ?_ ?_⟩
  · have h1 : 10 + exprNodes countE ≤ 2 * stepU := by dsimp [stepU]; omega
    have h2 : N * (m_body * stepU + 10) ≤ N * ((m_body + 1) * stepU) :=
      Nat.mul_le_mul_left N (by dsimp [stepU]; omega)
    calc 10 + exprNodes countE + N * (m_body * stepU + 10)
        ≤ 2 * stepU + N * ((m_body + 1) * stepU) := Nat.add_le_add h1 h2
      _ = (2 + N * (m_body + 1)) * stepU := by ring
  · have hL : 2 * exprLeaves countE * K ≤ 128 * K := Nat.mul_le_mul_right K (by omega)
    have h1 : 1000 * K ^ 2 + exprNodes countE * (2 * exprLeaves countE * K) ^ 2 ≤ 2 * stepB K := by
      dsimp [stepB]
      have hc : exprNodes countE * (2 * exprLeaves countE * K) ^ 2 ≤ 1048576 * K ^ 2 := by
        calc exprNodes countE * (2 * exprLeaves countE * K) ^ 2
            ≤ 64 * (128 * K) ^ 2 := Nat.mul_le_mul hsz_cnt.1 (Nat.pow_le_pow_left hL 2)
          _ = 1048576 * K ^ 2 := by ring
      calc 1000 * K ^ 2 + exprNodes countE * (2 * exprLeaves countE * K) ^ 2
          ≤ 1000 * K ^ 2 + 1048576 * K ^ 2 := Nat.add_le_add_left hc _
        _ = 1049576 * K ^ 2 := by ring
        _ ≤ 2 * (2000000 * K ^ 2) := by
            rw [← mul_assoc]; exact Nat.mul_le_mul_right _ (by omega)
    have h2 : N * (m_body * stepB K + 2000 * K ^ 2) ≤ N * ((m_body + 1) * stepB K) := by
      refine Nat.mul_le_mul_left N ?_
      dsimp [stepB]
      have hle : 2000 * K ^ 2 ≤ 2000000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)
      calc m_body * (2000000 * K ^ 2) + 2000 * K ^ 2
          ≤ m_body * (2000000 * K ^ 2) + 2000000 * K ^ 2 := Nat.add_le_add_left hle _
        _ = (m_body + 1) * (2000000 * K ^ 2) := by ring
    calc 1000 * K ^ 2 + exprNodes countE * (2 * exprLeaves countE * K) ^ 2 +
          N * (m_body * stepB K + 2000 * K ^ 2)
        ≤ 2 * stepB K + N * ((m_body + 1) * stepB K) := Nat.add_le_add h1 h2
      _ = (2 + N * (m_body + 1)) * stepB K := by ring

theorem exec_pow2 {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (dstT : ℕ) (dstIdx : ℤ) (exp : ℕ) (expE : UL.IntExpr)
    (hdst1 : dstIdx ≤ (maxIdx : ℤ))
    (hexp_le : exp ≤ K)
    (hexp_val : evalVal inp (hWrite ws₀ dstT dstIdx 1) expE = (exp : ℤ))
    (ht : dstT ≤ 31 := by decide)
    (hdst_wf : dstIdx.natAbs ≤ 64 := by decide)
    (hdst0 : 0 ≤ dstIdx := by decide)
    (hwf_exp : exprWf 31 expE = true := by decide)
    (hsz_exp : exprNodes expE ≤ 64 ∧ exprLeaves expE ≤ 64 := by decide) :
    ∃ ws₁ : UL.WordStore,
      hRead ws₁ dstT dstIdx = (2 : ℤ) ^ exp ∧
      PreservesOutside (fun t i => t = dstT ∧ i = dstIdx) ws₀ ws₁ ∧
      ExecBit inp maxIdx K (pow2Stmt dstT (.lit dstIdx) expE) ws₀ ws₁
        ((2 + exp) * stepU) ((2 + exp) * stepB K) := by
  obtain ⟨ws₁, hpow, hfr, hex⟩ := exec_pow2Stmt hctx hws₀ dstT dstIdx exp expE
    ht hdst_wf hdst0 hdst1 hexp_le hwf_exp hexp_val
  refine ⟨ws₁, hpow, ?_, hex.mono ?_ ?_⟩
  · intro t i hnot
    exact hfr t i (by tauto)
  · dsimp [stepU]; omega
  · have hL : 2 * exprLeaves expE * K ≤ 128 * K := Nat.mul_le_mul_right K (by omega)
    have h1 : 1000 * K ^ 2 + exprNodes expE * (2 * exprLeaves expE * K) ^ 2 ≤ 2 * stepB K := by
      dsimp [stepB]
      have hc : exprNodes expE * (2 * exprLeaves expE * K) ^ 2 ≤ 1048576 * K ^ 2 := by
        calc exprNodes expE * (2 * exprLeaves expE * K) ^ 2
            ≤ 64 * (128 * K) ^ 2 := Nat.mul_le_mul hsz_exp.1 (Nat.pow_le_pow_left hL 2)
          _ = 1048576 * K ^ 2 := by ring
      calc 1000 * K ^ 2 + exprNodes expE * (2 * exprLeaves expE * K) ^ 2
          ≤ 1000 * K ^ 2 + 1048576 * K ^ 2 := Nat.add_le_add_left hc _
        _ = 1049576 * K ^ 2 := by ring
        _ ≤ 2 * (2000000 * K ^ 2) := by
            rw [← mul_assoc]; exact Nat.mul_le_mul_right _ (by omega)
    have h2 : exp * (2000 * K ^ 2) ≤ exp * stepB K :=
      Nat.mul_le_mul_left exp (by dsimp [stepB]; exact Nat.mul_le_mul_right _ (by omega))
    calc 1000 * K ^ 2 + exprNodes expE * (2 * exprLeaves expE * K) ^ 2 + exp * (2000 * K ^ 2)
        ≤ 2 * stepB K + exp * stepB K := Nat.add_le_add h1 h2
      _ = (2 + exp) * stepB K := by ring

/-! ### 2. Global Workspace Parameters & Heap Region Predicates -/

def solverMaxIdx (nVars nEq nLe : ℕ) : ℕ :=
  64 + 8 * (nVars + nEq + nLe + 4) ^ 2

def solverK (nVars nEq nLe B' : ℕ) : ℕ :=
  5 * ellParamBsqrt (nVars + 2) (B' * (nVars + 2)) + 20 * (nVars + nEq + nLe + 4)

theorem solverMaxIdx_ge64 (nVars nEq nLe : ℕ) : 64 ≤ solverMaxIdx nVars nEq nLe := by
  dsimp [solverMaxIdx]; omega

theorem solverK_ge6 (nVars nEq nLe B' : ℕ) : 6 ≤ solverK nVars nEq nLe B' := by
  dsimp [solverK]; omega

theorem solverMaxIdx_le_two_pow (nVars nEq nLe B' : ℕ) :
    solverMaxIdx nVars nEq nLe ≤ 2 ^ solverK nVars nEq nLe B' := by
  let S := nVars + nEq + nLe + 4
  have hS : 4 ≤ S := by dsimp [S]; omega
  have h1 : 64 + 8 * S ^ 2 ≤ 64 * S ^ 2 := by
    have : 1 ≤ S ^ 2 := by rw [sq]; exact Nat.mul_pos (by omega) (by omega)
    have : 16 ≤ S ^ 2 := by rw [sq]; exact Nat.mul_le_mul hS hS
    omega
  have hS2 : S ≤ 2 ^ S := Nat.lt_two_pow_self.le
  have h2 : 64 * S ^ 2 ≤ 2 ^ (6 + 2 * S) := by
    calc 64 * S ^ 2 ≤ 2 ^ 6 * (2 ^ S) ^ 2 :=
          Nat.mul_le_mul_left 64 (Nat.pow_le_pow_left hS2 2)
      _ = 2 ^ (6 + 2 * S) := by rw [← pow_mul, ← pow_add]; ring_nf
  have h3 : 6 + 2 * S ≤ solverK nVars nEq nLe B' := by
    dsimp [solverK, S]; omega
  exact (h1.trans h2).trans (Nat.pow_le_pow_right (by omega) h3)

theorem bInt_le_solverK {nVars nEq nLe B' : ℕ} :
    B' * (nVars + 2) ≤ solverK nVars nEq nLe B' := by
  dsimp [solverK, ellParamBsqrt, ellParamE]
  have : B' * (nVars + 2) ≤ (nVars + 2 + 2) * (nVars + 2 + 2 + B' * (nVars + 2)) :=
    Nat.le_trans (Nat.le_add_left _ _) (Nat.le_mul_of_pos_left _ (by omega))
  omega

def DimsInHeap (nVars nEq nLe : ℕ) (ws : UL.WordStore) : Prop :=
  hRead ws 10 0 = (nVars : ℤ) ∧
  hRead ws 10 1 = (nEq : ℤ) ∧
  hRead ws 10 2 = (nLe : ℤ) ∧
  hRead ws 10 3 = ((nVars + 2 : ℕ) : ℤ) ∧
  hRead ws 10 4 = ((2 * nEq + 2 * nLe : ℕ) : ℤ) ∧
  hRead ws 10 5 = ((nEq + nLe : ℕ) : ℤ)

theorem DimsInHeap.preserve {nVars nEq nLe : ℕ} {mod : ℕ → ℤ → Prop}
    {ws₀ ws₁ : UL.WordStore} (h : DimsInHeap nVars nEq nLe ws₀)
    (hpr : PreservesOutside mod ws₀ ws₁)
    (hnot : ∀ i : ℤ, 0 ≤ i → i ≤ 5 → ¬ mod 10 i) :
    DimsInHeap nVars nEq nLe ws₁ := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpr 10 0 (hnot 0 (by omega) (by omega))]; exact h.1
  · rw [hpr 10 1 (hnot 1 (by omega) (by omega))]; exact h.2.1
  · rw [hpr 10 2 (hnot 2 (by omega) (by omega))]; exact h.2.2.1
  · rw [hpr 10 3 (hnot 3 (by omega) (by omega))]; exact h.2.2.2.1
  · rw [hpr 10 4 (hnot 4 (by omega) (by omega))]; exact h.2.2.2.2.1
  · rw [hpr 10 5 (hnot 5 (by omega) (by omega))]; exact h.2.2.2.2.2

def RatLPInHeap {nVars nEq nLe : ℕ}
    (A_eq_num A_eq_den : Fin nEq → Fin nVars → ℤ)
    (b_eq_num b_eq_den : Fin nEq → ℤ)
    (A_le_num A_le_den : Fin nLe → Fin nVars → ℤ)
    (b_le_num b_le_den : Fin nLe → ℤ)
    (ws : UL.WordStore) : Prop :=
  (∀ (i : Fin nEq) (j : Fin nVars),
    hRead ws 11 ((i.val * nVars + j.val : ℕ) : ℤ) = A_eq_num i j ∧
    hRead ws 12 ((i.val * nVars + j.val : ℕ) : ℤ) = A_eq_den i j) ∧
  (∀ i : Fin nEq,
    hRead ws 13 (i.val : ℤ) = b_eq_num i ∧
    hRead ws 14 (i.val : ℤ) = b_eq_den i) ∧
  (∀ (k : Fin nLe) (j : Fin nVars),
    hRead ws 15 ((k.val * nVars + j.val : ℕ) : ℤ) = A_le_num k j ∧
    hRead ws 16 ((k.val * nVars + j.val : ℕ) : ℤ) = A_le_den k j) ∧
  (∀ k : Fin nLe,
    hRead ws 17 (k.val : ℤ) = b_le_num k ∧
    hRead ws 18 (k.val : ℤ) = b_le_den k)

def ClearedLPInHeap {nVars nEq nLe : ℕ}
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (ws : UL.WordStore) : Prop :=
  (∀ (i : Fin nEq) (j : Fin nVars),
    hRead ws 19 ((i.val * nVars + j.val : ℕ) : ℤ) = M_eq i j) ∧
  (∀ i : Fin nEq, hRead ws 20 (i.val : ℤ) = d_eq i) ∧
  (∀ (k : Fin nLe) (j : Fin nVars),
    hRead ws 21 ((k.val * nVars + j.val : ℕ) : ℤ) = M_le k j) ∧
  (∀ k : Fin nLe, hRead ws 22 (k.val : ℤ) = d_le k)

theorem ClearedLPInHeap.preserve {nVars nEq nLe : ℕ}
    {M_eq : Fin nEq → Fin nVars → ℤ} {d_eq : Fin nEq → ℤ}
    {M_le : Fin nLe → Fin nVars → ℤ} {d_le : Fin nLe → ℤ}
    {mod : ℕ → ℤ → Prop} {ws₀ ws₁ : UL.WordStore}
    (h : ClearedLPInHeap M_eq d_eq M_le d_le ws₀)
    (hpr : PreservesOutside mod ws₀ ws₁)
    (hnot : ∀ t i, 19 ≤ t → t ≤ 22 → ¬ mod t i) :
    ClearedLPInHeap M_eq d_eq M_le d_le ws₁ := by
  refine ⟨fun i j => ?_, fun i => ?_, fun k j => ?_, fun k => ?_⟩
  · rw [hpr 19 _ (hnot 19 _ (by omega) (by omega))]; exact h.1 i j
  · rw [hpr 20 _ (hnot 20 _ (by omega) (by omega))]; exact h.2.1 i
  · rw [hpr 21 _ (hnot 21 _ (by omega) (by omega))]; exact h.2.2.1 k j
  · rw [hpr 22 _ (hnot 22 _ (by omega) (by omega))]; exact h.2.2.2 k

/-! ### 3. Row-Denominator Clearing Subroutine (`clearBlockStmt` & `clearRowsStmt`) -/

/-- Clear a block of `nRows` (`countSlot` in Table `10`, using `nVars` at `(10, 0)`), reading
`rowNum, rowDen, rhsNum, rhsDen` from `(tANum, tADen, tbNum, tbDen)` and writing `M, d` to `(tM, td)`. -/
def clearBlockStmt (countSlot : ℤ) (tANum tADen tbNum tbDen tM td : ℕ) : UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let rE := UL.IntExpr.readHeap 10 (.lit 42)
  let jE := UL.IntExpr.readHeap 10 (.lit 43)
  let ijE := UL.IntExpr.add (.mul rE nVarsE) jE
  let accE := UL.IntExpr.readHeap 10 (.lit 19)
  forLoopStmt 42 (.readHeap 10 (.lit countSlot))
    (seqBitStmts
      [ .writeHeap 10 (.lit 19) (.lit 1)
      , forLoopStmt 43 nVarsE
          (.writeHeap 10 (.lit 19) (.mul accE (.readHeap tADen ijE)))
      , .writeHeap 10 (.lit 19) (.mul accE (.readHeap tbDen rE))
      , forLoopStmt 43 nVarsE
          (.writeHeap tM ijE
            (.mul (.readHeap tANum ijE) (.div accE (.readHeap tADen ijE))))
      , .writeHeap td rE
          (.mul (.readHeap tbNum rE) (.div accE (.readHeap tbDen rE))) ])

theorem exec_clearBlockStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nRows maxIdx K B' : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    (h64 : 64 ≤ maxIdx)
    (hDimIdx : nRows ≤ maxIdx ∧ nVars ≤ maxIdx ∧ nRows * nVars ≤ maxIdx)
    (hBK : B' * (nVars + 2) ≤ K)
    (countSlot : ℤ) (hcs_wf : countSlot.natAbs ≤ 64) (hcs_range : 0 ≤ countSlot ∧ countSlot ≤ 5)
    {tANum tADen tbNum tbDen tM td : ℕ}
    (ht_in : 11 ≤ tANum ∧ tANum ≤ 18 ∧ 11 ≤ tADen ∧ tADen ≤ 18 ∧
             11 ≤ tbNum ∧ tbNum ≤ 18 ∧ 11 ≤ tbDen ∧ tbDen ≤ 18)
    (ht_out : 19 ≤ tM ∧ tM ≤ 22 ∧ 19 ≤ td ∧ td ≤ 22 ∧ tM ≠ td)
    (A_num A_den : Fin nRows → Fin nVars → ℤ)
    (b_num b_den : Fin nRows → ℤ)
    (hDenPos : ∀ i j, 0 < A_den i j) (hbDenPos : ∀ i, 0 < b_den i)
    (hNumB : ∀ i j, (A_num i j).natAbs ≤ 2 ^ B')
    (hDenB : ∀ i j, (A_den i j).natAbs ≤ 2 ^ B')
    (hbNumB : ∀ i, (b_num i).natAbs ≤ 2 ^ B')
    (hbDenB : ∀ i, (b_den i).natAbs ≤ 2 ^ B')
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hnVars_ws : hRead ws₀ 10 0 = (nVars : ℤ))
    (hnRows_ws : hRead ws₀ 10 countSlot = (nRows : ℤ))
    (hA_ws : ∀ (i : Fin nRows) (j : Fin nVars),
      hRead ws₀ tANum ((i.val * nVars + j.val : ℕ) : ℤ) = A_num i j ∧
      hRead ws₀ tADen ((i.val * nVars + j.val : ℕ) : ℤ) = A_den i j)
    (hb_ws : ∀ i : Fin nRows,
      hRead ws₀ tbNum (i.val : ℤ) = b_num i ∧
      hRead ws₀ tbDen (i.val : ℤ) = b_den i) :
    let mod : ℕ → ℤ → Prop := fun t idx =>
      (t = 10 ∧ (idx = 19 ∨ idx = 42 ∨ idx = 43)) ∨ t = tM ∨ t = td
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ (i : Fin nRows) (j : Fin nVars),
        hRead ws₁ tM ((i.val * nVars + j.val : ℕ) : ℤ) =
          clearRowCoeffs nVars (A_num i) (A_den i) (b_den i) j) ∧
      (∀ i : Fin nRows,
        hRead ws₁ td (i.val : ℤ) = clearRowRhs nVars (A_den i) (b_num i) (b_den i)) ∧
      ExecBit inp maxIdx K (clearBlockStmt countSlot tANum tADen tbNum tbDen tM td) ws₀ ws₁
        ((2 + nRows * (8 + 4 * nVars + 1)) * stepU)
        ((2 + nRows * (8 + 4 * nVars + 1)) * stepB K) := by
  intro mod
  have hmod_not_in : ∀ t idx, 11 ≤ t → t ≤ 18 → ¬ mod t idx := by
    intro t idx h1 h2; dsimp [mod]; omega
  have hmod_not_dim : ∀ idx, 0 ≤ idx → idx ≤ 5 → ¬ mod 10 idx := by
    intro idx h1 h2; dsimp [mod]; omega
  let InvRow : ℕ → UL.WordStore → Prop := fun r ws =>
    PreservesOutside mod ws₀ ws ∧
    (∀ (i : Fin nRows), i.val < r → ∀ (j : Fin nVars),
      hRead ws tM ((i.val * nVars + j.val : ℕ) : ℤ) =
        clearRowCoeffs nVars (A_num i) (A_den i) (b_den i) j) ∧
    (∀ (i : Fin nRows), i.val < r →
      hRead ws td (i.val : ℤ) = clearRowRhs nVars (A_den i) (b_num i) (b_den i))
  have hInv0 : InvRow 0 (hWrite ws₀ 10 42 0) :=
    ⟨PreservesOutside.write ws₀ 0 (by dsimp [mod]; omega),
     fun _ h => False.elim (Nat.not_lt_zero _ h),
     fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
  have hcnt_eq : evalVal inp (hWrite ws₀ 10 42 0) (.readHeap 10 (.lit countSlot)) = (nRows : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hnRows_ws]
  obtain ⟨ws₁, _, ⟨hpr₁, hM_done, hd_done⟩, hex₁⟩ := exec_for hctx 42
    (.readHeap 10 (.lit countSlot))
    (seqBitStmts
      [ .writeHeap 10 (.lit 19) (.lit 1)
      , forLoopStmt 43 (.readHeap 10 (.lit 0))
          (.writeHeap 10 (.lit 19) (.mul (.readHeap 10 (.lit 19))
            (.readHeap tADen (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
              (.readHeap 10 (.lit 43))))))
      , .writeHeap 10 (.lit 19) (.mul (.readHeap 10 (.lit 19))
          (.readHeap tbDen (.readHeap 10 (.lit 42))))
      , forLoopStmt 43 (.readHeap 10 (.lit 0))
          (.writeHeap tM (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
              (.readHeap 10 (.lit 43)))
            (.mul (.readHeap tANum (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
                (.readHeap 10 (.lit 43))))
              (.div (.readHeap 10 (.lit 19))
                (.readHeap tADen (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
                  (.readHeap 10 (.lit 43)))))))
      , .writeHeap td (.readHeap 10 (.lit 42))
          (.mul (.readHeap tbNum (.readHeap 10 (.lit 42)))
            (.div (.readHeap 10 (.lit 19))
              (.readHeap tbDen (.readHeap 10 (.lit 42))))) ])
    nRows (8 + 4 * nVars) InvRow hws₀ (by omega) hDimIdx.1 hcnt_eq hInv0
    (fun r hr ws hws hctr_r ⟨hpr, hM_prev, hd_prev⟩ => by
      let rFin : Fin nRows := ⟨r, hr⟩
      have hClear := clearRow_spec (A_num rFin) (A_den rFin) (b_num rFin) (b_den rFin)
        (hDenPos rFin) (hbDenPos rFin) (hNumB rFin) (hDenB rFin) (hbNumB rFin) (hbDenB rFin)
      -- Step 1: acc := 1
      have hs1 := exec_write hctx hws 10 (.lit 19) (.lit 1) 19 1 rfl rfl (by omega) (by omega)
        Nat.one_le_two_pow
      let ws1 := hWrite ws 10 19 1
      have hpr1 : PreservesOutside mod ws₀ ws1 :=
        hpr.trans (PreservesOutside.write ws 1 (by dsimp [mod]; omega))
      -- Step 2: inner product loop j < nVars
      let prodAt : (k : ℕ) → k ≤ nVars → ℤ := fun k hk =>
        Fin.foldl k (fun acc (j : Fin k) => acc * A_den rFin ⟨j.val, lt_of_lt_of_le j.isLt hk⟩) 1
      have hProdAbs : ∀ k : ℕ, (hk : k ≤ nVars) → (prodAt k hk).natAbs ≤ 2 ^ (B' * k) := by
        intro k
        induction k with
        | zero => intro _; simp [prodAt, Fin.foldl_zero]
        | succ k ih =>
            intro hk
            have hf : prodAt (k + 1) hk = prodAt k (Nat.le_of_succ_le hk) * A_den rFin ⟨k, hk⟩ := by
              dsimp [prodAt]; rw [Fin.foldl_succ_last]; rfl
            rw [hf, Int.natAbs_mul]
            calc (prodAt k (Nat.le_of_succ_le hk)).natAbs * (A_den rFin ⟨k, hk⟩).natAbs
                ≤ 2 ^ (B' * k) * 2 ^ B' := Nat.mul_le_mul (ih (Nat.le_of_succ_le hk)) (hDenB rFin ⟨k, hk⟩)
              _ = 2 ^ (B' * (k + 1)) := by rw [← pow_add]; ring_nf
      let modP : ℕ → ℤ → Prop := fun t idx => t = 10 ∧ (idx = 19 ∨ idx = 43)
      let InvP : ℕ → UL.WordStore → Prop := fun k wsp =>
        PreservesOutside modP ws1 wsp ∧
        ((hk : k ≤ nVars) → hRead wsp 10 19 = prodAt k hk)
      have hInvP0 : InvP 0 (hWrite ws1 10 43 0) :=
        ⟨PreservesOutside.write ws1 0 (by dsimp [modP]; omega),
         fun _ => by
           dsimp [ws1, prodAt]
           rw [Fin.foldl_zero, hRead_hWrite_of_ne (hWrite ws 10 19 1) 0 (Or.inr (by omega)),
               hRead_hWrite_self]⟩
      have hnV_ws1 : evalVal inp (hWrite ws1 10 43 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne ws1 0 (Or.inr (by omega)),
            hpr1 10 0 (hmod_not_dim 0 (by omega) (by omega)), hnVars_ws]
      obtain ⟨ws2, _, ⟨hprP, hProdDone⟩, hs2⟩ := exec_for hctx 43 (.readHeap 10 (.lit 0))
        (.writeHeap 10 (.lit 19) (.mul (.readHeap 10 (.lit 19))
          (.readHeap tADen (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
            (.readHeap 10 (.lit 43))))))
        nVars 1 InvP hs1.2.1 (by omega) hDimIdx.2.1 hnV_ws1 hInvP0
        (fun j hj wsp hwsp hctr_j ⟨hpr_p, hacc_p⟩ => by
          have hk_le : j ≤ nVars := hj.le
          have hacc_val := hacc_p hk_le
          let jFin : Fin nVars := ⟨j, hj⟩
          have hr_wsp : hRead wsp 10 42 = (r : ℤ) := by
            rw [hpr_p 10 42 (by dsimp [modP]; omega),
                hRead_hWrite_of_ne ws 1 (Or.inr (by omega)), hctr_r]
          have hnV_wsp : hRead wsp 10 0 = (nVars : ℤ) := by
            rw [hpr_p 10 0 (by dsimp [modP]; omega),
                hpr1 10 0 (hmod_not_dim 0 (by omega) (by omega)), hnVars_ws]
          have hAden_wsp : hRead wsp tADen ((r * nVars + j : ℕ) : ℤ) = A_den rFin jFin := by
            rw [hpr_p tADen _ (by dsimp [modP]; omega),
                hpr1 tADen _ (hmod_not_in tADen _ ht_in.2.2.1 ht_in.2.2.2.1)]
            exact (hA_ws rFin jFin).2
          have hval_mul : evalVal inp wsp (.mul (.readHeap 10 (.lit 19))
              (.readHeap tADen (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
                (.readHeap 10 (.lit 43))))) = prodAt (j + 1) hj := by
            have hij : (r : ℤ) * (nVars : ℤ) + (j : ℤ) = ((r * nVars + j : ℕ) : ℤ) := by
              push_cast; ring
            have hf : prodAt (j + 1) hj = prodAt j hk_le * A_den rFin jFin := by
              dsimp [prodAt]; rw [Fin.foldl_succ_last]; rfl
            simp only [evalVal_mul, evalVal_readHeap, evalVal_lit, evalVal_add,
              hacc_val, hr_wsp, hnV_wsp, hctr_j, hij, hAden_wsp, hf]
          have hv_abs : (prodAt (j + 1) hj).natAbs ≤ 2 ^ K :=
            (hProdAbs (j + 1) hj).trans (Nat.pow_le_pow_right (by omega)
              ((Nat.mul_le_mul_left B' (by omega : j + 1 ≤ nVars + 2)).trans hBK))
          have hw_mul := exec_write hctx hwsp 10 (.lit 19) _ 19 (prodAt (j + 1) hj) rfl hval_mul (by omega) (by omega) hv_abs
            (by decide) (by decide) (by simp [exprWf, decide_eq_true (by omega : tADen ≤ 31)])
            (by dsimp [exprNodes, exprLeaves]; omega)
          let wsp' := hWrite wsp 10 19 (prodAt (j + 1) hj)
          refine ⟨wsp', hw_mul, ?_, ?_⟩
          · rw [hRead_hWrite_of_ne wsp _ (Or.inr (by omega)), hctr_j]
          · refine ⟨(hpr_p.trans (PreservesOutside.write wsp _ (by dsimp [modP]; omega))).trans
                (PreservesOutside.write wsp' _ (by dsimp [modP]; omega)), fun _ => ?_⟩
            rw [hRead_hWrite_of_ne wsp' _ (Or.inr (by omega)), hRead_hWrite_self])
        (by decide) (by decide) (by decide) (by decide)
      -- Step 3: acc := acc * b_den rFin (= clearRowDen)
      have hpr2 : PreservesOutside mod ws₀ ws2 :=
        hpr1.trans (hprP.mono (by intro t idx h; dsimp [modP] at h; dsimp [mod]; omega))
      let D_row := clearRowDen nVars (A_den rFin) (b_den rFin)
      have hD_eq : prodAt nVars le_rfl * b_den rFin = D_row := rfl
      have hr_ws2 : hRead ws2 10 42 = (r : ℤ) := by
        rw [hprP 10 42 (by dsimp [modP]; omega),
            hRead_hWrite_of_ne ws 1 (Or.inr (by omega)), hctr_r]
      have hbden_ws2 : hRead ws2 tbDen (r : ℤ) = b_den rFin := by
        rw [hpr2 tbDen _ (hmod_not_in tbDen _ ht_in.2.2.2.2.2.2.1 ht_in.2.2.2.2.2.2.2)]
        exact (hb_ws rFin).2
      have hval_D : evalVal inp ws2 (.mul (.readHeap 10 (.lit 19))
          (.readHeap tbDen (.readHeap 10 (.lit 42)))) = D_row := by
        simp only [evalVal_mul, evalVal_readHeap, evalVal_lit, hProdDone le_rfl, hr_ws2, hbden_ws2, hD_eq]
      have hD_abs : D_row.natAbs ≤ 2 ^ K :=
        hClear.2.1.trans (Nat.pow_le_pow_right (by omega)
          ((Nat.mul_le_mul_left B' (by omega : nVars + 1 ≤ nVars + 2)).trans hBK))
      have hs3 := exec_write hctx hs2.2.1 10 (.lit 19) _ 19 D_row rfl hval_D (by omega) (by omega) hD_abs
        (by decide) (by decide)
        (by simp [exprWf, decide_eq_true (by omega : tbDen ≤ 31)])
        (by dsimp [exprNodes, exprLeaves]; omega)
      let ws3 := hWrite ws2 10 19 D_row
      have hpr3 : PreservesOutside mod ws₀ ws3 :=
        hpr2.trans (PreservesOutside.write ws2 D_row (by dsimp [mod]; omega))
      -- Step 4: loop j < nVars writing tM[r * nVars + j] := clearRowCoeffs ... j
      let modC : ℕ → ℤ → Prop := fun t idx =>
        (t = 10 ∧ idx = 43) ∨ (t = tM ∧ (r * nVars : ℕ) ≤ idx ∧ idx < ((r + 1) * nVars : ℕ))
      let InvC : ℕ → UL.WordStore → Prop := fun k wsc =>
        PreservesOutside modC ws3 wsc ∧
        (∀ j : Fin nVars, j.val < k →
          hRead wsc tM ((r * nVars + j.val : ℕ) : ℤ) =
            clearRowCoeffs nVars (A_num rFin) (A_den rFin) (b_den rFin) j)
      have hInvC0 : InvC 0 (hWrite ws3 10 43 0) :=
        ⟨PreservesOutside.write ws3 0 (by dsimp [modC]; omega),
         fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
      have hnV_ws3 : evalVal inp (hWrite ws3 10 43 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne ws3 0 (Or.inr (by omega)),
            hpr3 10 0 (hmod_not_dim 0 (by omega) (by omega)), hnVars_ws]
      obtain ⟨ws4, _, ⟨hprC, hRowC_done⟩, hs4⟩ := exec_for hctx 43 (.readHeap 10 (.lit 0))
        (.writeHeap tM (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
            (.readHeap 10 (.lit 43)))
          (.mul (.readHeap tANum (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
              (.readHeap 10 (.lit 43))))
            (.div (.readHeap 10 (.lit 19))
              (.readHeap tADen (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
                (.readHeap 10 (.lit 43)))))))
        nVars 1 InvC hs3.2.1 (by omega) hDimIdx.2.1 hnV_ws3 hInvC0
        (fun j hj wsc hwsc hctr_j ⟨hpr_c, hprev_c⟩ => by
          let jFin : Fin nVars := ⟨j, hj⟩
          have hr_wsc : hRead wsc 10 42 = (r : ℤ) := by
            rw [hpr_c 10 42 (by dsimp [modC]; omega),
                hRead_hWrite_of_ne ws2 D_row (Or.inr (by omega)), hr_ws2]
          have hnV_wsc : hRead wsc 10 0 = (nVars : ℤ) := by
            rw [hpr_c 10 0 (by dsimp [modC]; omega),
                hpr3 10 0 (hmod_not_dim 0 (by omega) (by omega)), hnVars_ws]
          have hD_wsc : hRead wsc 10 19 = D_row := by
            rw [hpr_c 10 19 (by dsimp [modC]; omega), hRead_hWrite_self]
          have hij_eq : (r : ℤ) * (nVars : ℤ) + (j : ℤ) = ((r * nVars + j : ℕ) : ℤ) := by
            push_cast; ring
          have hAnum_wsc : hRead wsc tANum ((r * nVars + j : ℕ) : ℤ) = A_num rFin jFin := by
            rw [hpr_c tANum _ (by dsimp [modC]; omega),
                hpr3 tANum _ (hmod_not_in tANum _ ht_in.1 ht_in.2.1)]
            exact (hA_ws rFin jFin).1
          have hAden_wsc : hRead wsc tADen ((r * nVars + j : ℕ) : ℤ) = A_den rFin jFin := by
            rw [hpr_c tADen _ (by dsimp [modC]; omega),
                hpr3 tADen _ (hmod_not_in tADen _ ht_in.2.2.1 ht_in.2.2.2.1)]
            exact (hA_ws rFin jFin).2
          have hidx_c : evalVal inp wsc (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
              (.readHeap 10 (.lit 43))) = ((r * nVars + j : ℕ) : ℤ) := by
            simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
              hr_wsc, hnV_wsc, hctr_j, hij_eq]
          let cVal := clearRowCoeffs nVars (A_num rFin) (A_den rFin) (b_den rFin) jFin
          have hval_c : evalVal inp wsc (.mul (.readHeap tANum (.add (.mul (.readHeap 10 (.lit 42))
                (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43))))
              (.div (.readHeap 10 (.lit 19))
                (.readHeap tADen (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
                  (.readHeap 10 (.lit 43)))))) = cVal := by
            simp only [evalVal_mul, evalVal_div, evalVal_readHeap, evalVal_lit, evalVal_add,
              hr_wsc, hnV_wsc, hctr_j, hij_eq, hAnum_wsc, hD_wsc, hAden_wsc]
            rfl
          have hij_ub : ((r * nVars + j : ℕ) : ℤ) ≤ (maxIdx : ℤ) := by
            have h1 : r * nVars + j < (r + 1) * nVars := by
              calc r * nVars + j < r * nVars + nVars := Nat.add_lt_add_left hj _
                _ = (r + 1) * nVars := by ring
            have h2 : (r + 1) * nVars ≤ nRows * nVars := Nat.mul_le_mul_right nVars hr
            exact_mod_cast (h1.le.trans (h2.trans hDimIdx.2.2))
          have hc_abs : cVal.natAbs ≤ 2 ^ K :=
            (hClear.2.2.1 jFin).trans (Nat.pow_le_pow_right (by omega) hBK)
          have hwf_ij : exprWf 31 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0)))
              (.readHeap 10 (.lit 43))) = true := by decide
          have hw_c := exec_write hctx hwsc tM _ _ ((r * nVars + j : ℕ) : ℤ) cVal hidx_c hval_c (Nat.cast_nonneg _) hij_ub hc_abs
            (by omega) hwf_ij
            (by simp [exprWf, decide_eq_true (by omega : tANum ≤ 31), decide_eq_true (by omega : tADen ≤ 31)])
            (by dsimp [exprNodes, exprLeaves]; omega)
          let wsc' := hWrite wsc tM ((r * nVars + j : ℕ) : ℤ) cVal
          have hlt_rn : r * nVars + j < (r + 1) * nVars := by
            calc r * nVars + j < r * nVars + nVars := Nat.add_lt_add_left hj _
              _ = (r + 1) * nVars := by ring
          refine ⟨wsc', hw_c, ?_, ?_⟩
          · rw [hRead_hWrite_of_ne wsc _ (Or.inl (by omega)), hctr_j]
          · refine ⟨(hpr_c.trans (PreservesOutside.write wsc cVal
                (Or.inr ⟨rfl, by exact_mod_cast Nat.le_add_right _ _, by exact_mod_cast hlt_rn⟩))).trans
              (PreservesOutside.write wsc' _ (Or.inl ⟨rfl, rfl⟩)), fun j' hj' => ?_⟩
            rw [hRead_hWrite_of_ne wsc' _ (Or.inl (by omega))]
            rcases Nat.lt_succ_iff_lt_or_eq.mp hj' with hlt | heq
            · rw [hRead_hWrite_of_ne wsc _ (Or.inr (by omega))]
              exact hprev_c j' hlt
            · have hj_eq : j' = jFin := Fin.ext heq
              subst hj_eq
              exact hRead_hWrite_self wsc tM _ cVal)
        (by decide) (by decide) (by decide) (by decide)
      -- Step 5: write td[r] := clearRowRhs ...
      have hr_ws4 : hRead ws4 10 42 = (r : ℤ) := by
        rw [hprC 10 42 (by dsimp [modC]; omega),
            hRead_hWrite_of_ne ws2 D_row (Or.inr (by omega)), hr_ws2]
      have hD_ws4 : hRead ws4 10 19 = D_row := by
        rw [hprC 10 19 (by dsimp [modC]; omega), hRead_hWrite_self]
      have hpr4 : PreservesOutside mod ws₀ ws4 :=
        hpr3.trans (hprC.mono (by intro t idx h; dsimp [modC] at h; dsimp [mod]; tauto))
      have hbnum_ws4 : hRead ws4 tbNum (r : ℤ) = b_num rFin := by
        rw [hpr4 tbNum _ (hmod_not_in tbNum _ ht_in.2.2.2.2.1 ht_in.2.2.2.2.2.1)]
        exact (hb_ws rFin).1
      have hbden_ws4 : hRead ws4 tbDen (r : ℤ) = b_den rFin := by
        rw [hpr4 tbDen _ (hmod_not_in tbDen _ ht_in.2.2.2.2.2.2.1 ht_in.2.2.2.2.2.2.2)]
        exact (hb_ws rFin).2
      let rhsVal := clearRowRhs nVars (A_den rFin) (b_num rFin) (b_den rFin)
      have hval_rhs : evalVal inp ws4 (.mul (.readHeap tbNum (.readHeap 10 (.lit 42)))
          (.div (.readHeap 10 (.lit 19)) (.readHeap tbDen (.readHeap 10 (.lit 42))))) = rhsVal := by
        simp only [evalVal_mul, evalVal_div, evalVal_readHeap, evalVal_lit,
          hr_ws4, hbnum_ws4, hD_ws4, hbden_ws4]
        rfl
      have hrhs_abs : rhsVal.natAbs ≤ 2 ^ K :=
        hClear.2.2.2.1.trans (Nat.pow_le_pow_right (by omega) hBK)
      have hs5 := exec_write hctx hs4.2.1 td (.readHeap 10 (.lit 42)) _ (r : ℤ) rhsVal
        (by simp [hr_ws4]) hval_rhs (Nat.cast_nonneg _) (by omega) hrhs_abs
        (by omega) (by decide)
        (by simp [exprWf, decide_eq_true (by omega : tbNum ≤ 31), decide_eq_true (by omega : tbDen ≤ 31)])
        (by dsimp [exprNodes, exprLeaves]; omega)
      let ws5 := hWrite ws4 td (r : ℤ) rhsVal
      have hseq := (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps hs5)))).mono_steps
        (show 1 + ((2 + nVars * (1 + 1)) + (1 + ((2 + nVars * (1 + 1)) + 1))) ≤ 8 + 4 * nVars by ring_nf; omega)
      refine ⟨ws5, hseq, ?_, ?_⟩
      · rw [hRead_hWrite_of_ne ws4 _ (Or.inl (by omega)), hr_ws4]
      · refine ⟨(hpr4.trans (PreservesOutside.write ws4 rhsVal (by dsimp [mod]; omega))).trans
            (PreservesOutside.write ws5 _ (by dsimp [mod]; omega)),
          fun i hi j => ?_, fun i hi => ?_⟩
        · rw [hRead_hWrite_of_ne ws5 _ (Or.inl (by omega)),
              hRead_hWrite_of_ne ws4 _ (Or.inl ht_out.2.2.2.2)]
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | heq
          · have hlt_idx : i.val * nVars + j.val < r * nVars := by
              calc i.val * nVars + j.val < i.val * nVars + nVars := Nat.add_lt_add_left j.isLt _
                _ = (i.val + 1) * nVars := by ring
                _ ≤ r * nVars := Nat.mul_le_mul_right nVars hlt
            rw [hprC tM _ (by dsimp [modC]; omega),
                hRead_hWrite_of_ne ws2 _ (Or.inl (by omega)),
                hprP tM _ (by dsimp [modP]; omega),
                hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
            exact hM_prev i hlt j
          · have hi_eq : i = rFin := Fin.ext heq
            subst hi_eq
            exact hRowC_done j j.isLt
        · rw [hRead_hWrite_of_ne ws5 _ (Or.inl (by omega))]
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | heq
          · rw [hRead_hWrite_of_ne ws4 _ (Or.inr (by omega)),
                hprC td _ (by dsimp [modC]; have := ht_out.2.2.2.2; omega),
                hRead_hWrite_of_ne ws2 _ (Or.inl (by omega)),
                hprP td _ (by dsimp [modP]; omega),
                hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
            exact hd_prev i hlt
          · have hi_eq : i = rFin := Fin.ext heq
            subst hi_eq
            exact hRead_hWrite_self ws4 td (r : ℤ) rhsVal)
    (by decide) (by decide) (by simp [exprWf, hcs_wf]) (by dsimp [exprNodes, exprLeaves]; omega)
  exact ⟨ws₁, hpr₁, fun i j => hM_done i i.isLt j, fun i => hd_done i i.isLt, hex₁⟩


/-! ### 4. `computeMaxEntryStmt` and `ceilLog2Stmt` -/

/-- Compute `absInt e` into `(10, 28)` (`tmp1`) and update `(10, 6) := maxInt (10, 6) (10, 28)`. -/
def updateMaxAbsStmt (valE : UL.IntExpr) : UL.BitRAMStmt :=
  .seq
    (.ite (.intLe (.lit 0) valE)
      (.writeHeap 10 (.lit 28) valE)
      (.writeHeap 10 (.lit 28) (.neg valE)))
    (.ite (.intLe (.readHeap 10 (.lit 6)) (.readHeap 10 (.lit 28)))
      (.writeHeap 10 (.lit 6) (.readHeap 10 (.lit 28)))
      .skip)

theorem exec_updateMaxAbsStmt {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (valE : UL.IntExpr) {v acc : ℤ}
    (hacc : hRead ws₀ 10 6 = acc)
    (hval : evalVal inp ws₀ valE = v)
    (_hacc_abs : acc.natAbs ≤ 2 ^ K)
    (hv_abs : v.natAbs ≤ 2 ^ K)
    (hwf_v : exprWf 31 valE = true)
    (hsz_v : exprNodes valE ≤ 20 ∧ exprLeaves valE ≤ 20) :
    ∃ ws₁ : UL.WordStore,
      hRead ws₁ 10 6 = maxInt acc (absInt v) ∧
      PreservesOutside (fun t idx => t = 10 ∧ (idx = 6 ∨ idx = 28)) ws₀ ws₁ ∧
      ExecBit inp maxIdx K (updateMaxAbsStmt valE) ws₀ ws₁ (4 * stepU) (4 * stepB K) := by
  have hs1 : ∃ ws_a : UL.WordStore,
      hRead ws_a 10 28 = absInt v ∧
      hRead ws_a 10 6 = acc ∧
      PreservesOutside (fun t idx => t = 10 ∧ (idx = 6 ∨ idx = 28)) ws₀ ws_a ∧
      ExecBit inp maxIdx K
        (.ite (.intLe (.lit 0) valE)
          (.writeHeap 10 (.lit 28) valE)
          (.writeHeap 10 (.lit 28) (.neg valE))) ws₀ ws_a (2 * stepU) (2 * stepB K) := by
    by_cases h0 : 0 ≤ v
    · have hc : evalCondVal inp ws₀ (.intLe (.lit 0) valE) = true := by simp [hval, h0]
      have hw := exec_write hctx hws₀ 10 (.lit 28) valE 28 v rfl hval (by omega) (by omega) hv_abs
        (by decide) (by decide) hwf_v (by dsimp [exprNodes, exprLeaves]; omega)
      have hite := exec_ite_true hctx (.intLe (.lit 0) valE)
        (.writeHeap 10 (.lit 28) valE) (.writeHeap 10 (.lit 28) (.neg valE)) hc hw
        (by simp [condWf, exprWf, hwf_v])
        (by dsimp [condNodes, condLeaves, exprNodes, exprLeaves]; omega)
      refine ⟨hWrite ws₀ 10 28 v, ?_, ?_, ?_, hite⟩
      · simp [absInt, h0]
      · rw [hRead_hWrite_of_ne ws₀ _ (Or.inr (by omega)), hacc]
      · exact PreservesOutside.write ws₀ v (by omega)
    · have hc : evalCondVal inp ws₀ (.intLe (.lit 0) valE) = false := by simp [hval, h0]
      have hneg_val : evalVal inp ws₀ (.neg valE) = -v := by simp [hval]
      have hneg_abs : (-v).natAbs ≤ 2 ^ K := by simpa using hv_abs
      have hw := exec_write hctx hws₀ 10 (.lit 28) (.neg valE) 28 (-v) rfl hneg_val (by omega) (by omega) hneg_abs
        (by decide) (by decide) (by simp [exprWf, hwf_v])
        (by dsimp [exprNodes, exprLeaves]; omega)
      have hite := exec_ite_false hctx (.intLe (.lit 0) valE)
        (.writeHeap 10 (.lit 28) valE) (.writeHeap 10 (.lit 28) (.neg valE)) hc hw
        (by simp [condWf, exprWf, hwf_v])
        (by dsimp [condNodes, condLeaves, exprNodes, exprLeaves]; omega)
      refine ⟨hWrite ws₀ 10 28 (-v), ?_, ?_, ?_, hite⟩
      · simp [absInt, h0]
      · rw [hRead_hWrite_of_ne ws₀ _ (Or.inr (by omega)), hacc]
      · exact PreservesOutside.write ws₀ (-v) (by omega)
  obtain ⟨ws_a, h28, h6, hpr_a, hex_a⟩ := hs1
  by_cases hle : acc ≤ absInt v
  · have hc2 : evalCondVal inp ws_a (.intLe (.readHeap 10 (.lit 6)) (.readHeap 10 (.lit 28))) = true := by
      simp only [evalCondVal_intLe, evalVal_readHeap, evalVal_lit, h6, h28, decide_eq_true_eq]
      exact hle
    have habs_v : (absInt v).natAbs ≤ 2 ^ K := by rw [absInt_eq_natAbs, Int.natAbs_natCast]; exact hv_abs
    have hw2 := exec_write hctx hex_a.2.1 10 (.lit 6) (.readHeap 10 (.lit 28)) 6 (absInt v)
      rfl (by simp [h28]) (by omega) (by omega) habs_v
    have hite2 := exec_ite_true hctx (.intLe (.readHeap 10 (.lit 6)) (.readHeap 10 (.lit 28)))
      (.writeHeap 10 (.lit 6) (.readHeap 10 (.lit 28))) .skip hc2 hw2
    refine ⟨hWrite ws_a 10 6 (absInt v), ?_, ?_, hex_a.seq_steps hite2⟩
    · rw [hRead_hWrite_self, maxInt_eq_max, max_eq_right hle]
    · exact hpr_a.trans (PreservesOutside.write ws_a _ (by omega))
  · have hc2 : evalCondVal inp ws_a (.intLe (.readHeap 10 (.lit 6)) (.readHeap 10 (.lit 28))) = false := by
      simp only [evalCondVal_intLe, evalVal_readHeap, evalVal_lit, h6, h28, decide_eq_false_iff_not]
      exact hle
    have hsk := exec_skip hctx hex_a.2.1
    have hite2 := exec_ite_false hctx (.intLe (.readHeap 10 (.lit 6)) (.readHeap 10 (.lit 28)))
      (.writeHeap 10 (.lit 6) (.readHeap 10 (.lit 28))) .skip hc2 hsk
    refine ⟨ws_a, ?_, hpr_a, hex_a.seq_steps hite2⟩
    rw [h6, maxInt_eq_max, max_eq_left (le_of_not_ge hle)]

/-- Scan `nRows` (`countSlot`) of `(tM, td)` updating `(10, 6)` via `rowMaxAbs`. -/
def maxBlockStmt (countSlot : ℤ) (tM td : ℕ) : UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let rE := UL.IntExpr.readHeap 10 (.lit 42)
  let jE := UL.IntExpr.readHeap 10 (.lit 43)
  let ijE := UL.IntExpr.add (.mul rE nVarsE) jE
  forLoopStmt 42 (.readHeap 10 (.lit countSlot))
    (.seq
      (forLoopStmt 43 nVarsE (updateMaxAbsStmt (.readHeap tM ijE)))
      (updateMaxAbsStmt (.readHeap td rE)))

def computeMaxEntryStmt : UL.BitRAMStmt :=
  seqBitStmts
    [ .writeHeap 10 (.lit 6) (.lit 2)
    , maxBlockStmt 1 19 20
    , maxBlockStmt 2 21 22 ]

theorem exec_maxBlockStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nRows maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hDimIdx : nRows ≤ maxIdx ∧ nVars ≤ maxIdx ∧ nRows * nVars ≤ maxIdx)
    (countSlot : ℤ) (hcs_wf : countSlot.natAbs ≤ 64) (hcs_range : 0 ≤ countSlot ∧ countSlot ≤ 5)
    {tM td : ℕ} (htM : 19 ≤ tM ∧ tM ≤ 22) (htd : 19 ≤ td ∧ td ≤ 22)
    (M : Fin nRows → Fin nVars → ℤ) (rhs : Fin nRows → ℤ)
    (hMB : ∀ i j, (M i j).natAbs ≤ 2 ^ K)
    (hrhsB : ∀ i, (rhs i).natAbs ≤ 2 ^ K)
    {init : ℤ} (hinitB : init.natAbs ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hnVars_ws : hRead ws₀ 10 0 = (nVars : ℤ))
    (hnRows_ws : hRead ws₀ 10 countSlot = (nRows : ℤ))
    (hacc_ws : hRead ws₀ 10 6 = init)
    (hM_ws : ∀ (i : Fin nRows) (j : Fin nVars),
      hRead ws₀ tM ((i.val * nVars + j.val : ℕ) : ℤ) = M i j)
    (hrhs_ws : ∀ i : Fin nRows, hRead ws₀ td (i.val : ℤ) = rhs i) :
    let mod : ℕ → ℤ → Prop := fun t idx =>
      t = 10 ∧ (idx = 6 ∨ idx = 28 ∨ idx = 42 ∨ idx = 43)
    ∃ ws₁ : UL.WordStore,
      hRead ws₁ 10 6 = Fin.foldl nRows (fun acc i => rowMaxAbs acc (M i) (rhs i)) init ∧
      PreservesOutside mod ws₀ ws₁ ∧
      ExecBit inp maxIdx K (maxBlockStmt countSlot tM td) ws₀ ws₁
        ((2 + nRows * (6 + 5 * nVars + 1)) * stepU)
        ((2 + nRows * (6 + 5 * nVars + 1)) * stepB K) := by
  intro mod
  have hmaxInt_abs : ∀ {a b : ℤ}, a.natAbs ≤ 2 ^ K → b.natAbs ≤ 2 ^ K →
      (maxInt a (absInt b)).natAbs ≤ 2 ^ K := by
    intro a b ha hb
    rw [maxInt_eq_max, absInt_eq_natAbs]
    rcases le_total a (b.natAbs : ℤ) with h | h
    · rw [max_eq_right h, Int.natAbs_natCast]; exact hb
    · rw [max_eq_left h]; exact ha
  let foldRow : (r : ℕ) → r ≤ nRows → ℤ := fun r hr =>
    Fin.foldl r (fun acc (i : Fin r) =>
      rowMaxAbs acc (M ⟨i.val, lt_of_lt_of_le i.isLt hr⟩) (rhs ⟨i.val, lt_of_lt_of_le i.isLt hr⟩)) init
  have hFoldRowB : ∀ r : ℕ, (hr : r ≤ nRows) → (foldRow r hr).natAbs ≤ 2 ^ K := by
    intro r
    induction r with
    | zero => intro _; simpa [foldRow, Fin.foldl_zero] using hinitB
    | succ r ih =>
        intro hr
        have hf : foldRow (r + 1) hr =
            rowMaxAbs (foldRow r (Nat.le_of_succ_le hr)) (M ⟨r, hr⟩) (rhs ⟨r, hr⟩) := by
          dsimp [foldRow]; rw [Fin.foldl_succ_last]; rfl
        rw [hf]
        dsimp [rowMaxAbs]
        apply hmaxInt_abs _ (hrhsB ⟨r, hr⟩)
        have hInner : ∀ k : ℕ, (hk : k ≤ nVars) →
            (Fin.foldl k (fun acc (j : Fin k) =>
              maxInt acc (absInt (M ⟨r, hr⟩ ⟨j.val, lt_of_lt_of_le j.isLt hk⟩)))
              (foldRow r (Nat.le_of_succ_le hr))).natAbs ≤ 2 ^ K := by
          intro k
          induction k with
          | zero => intro _; simpa [Fin.foldl_zero] using ih (Nat.le_of_succ_le hr)
          | succ k ihk =>
              intro hk
              rw [Fin.foldl_succ_last]
              exact hmaxInt_abs (ihk (Nat.le_of_succ_le hk)) (hMB ⟨r, hr⟩ ⟨k, hk⟩)
        exact hInner nVars le_rfl
  let Inv : ℕ → UL.WordStore → Prop := fun r ws =>
    PreservesOutside mod ws₀ ws ∧
    ((hr : r ≤ nRows) → hRead ws 10 6 = foldRow r hr)
  have htM31 : decide (tM ≤ 31) = true := decide_eq_true (by omega)
  have htd31 : decide (td ≤ 31) = true := decide_eq_true (by omega)
  have hInv0 : Inv 0 (hWrite ws₀ 10 42 0) :=
    ⟨PreservesOutside.write ws₀ 0 (by dsimp [mod]; omega),
     fun _ => by
       dsimp [foldRow]
       rw [Fin.foldl_zero, hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hacc_ws]⟩
  have hcnt : evalVal inp (hWrite ws₀ 10 42 0) (.readHeap 10 (.lit countSlot)) = (nRows : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hnRows_ws]
  obtain ⟨ws₁, _, ⟨hpr₁, hdone⟩, hex₁⟩ := exec_for hctx 42 (.readHeap 10 (.lit countSlot))
    (.seq
      (forLoopStmt 43 (.readHeap 10 (.lit 0))
        (updateMaxAbsStmt (.readHeap tM
          (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43))))))
      (updateMaxAbsStmt (.readHeap td (.readHeap 10 (.lit 42)))))
    nRows (6 + 5 * nVars) Inv hws₀ (by omega) hDimIdx.1 hcnt hInv0
    (fun r hr ws hws hctr_r ⟨hpr, hacc_r⟩ => by
      let rFin : Fin nRows := ⟨r, hr⟩
      let curInit := foldRow r hr.le
      let innerAt : (k : ℕ) → k ≤ nVars → ℤ := fun k hk =>
        Fin.foldl k (fun acc (j : Fin k) =>
          maxInt acc (absInt (M rFin ⟨j.val, lt_of_lt_of_le j.isLt hk⟩))) curInit
      have hInnerB : ∀ k : ℕ, (hk : k ≤ nVars) → (innerAt k hk).natAbs ≤ 2 ^ K := by
        intro k
        induction k with
        | zero => intro _; simpa [innerAt, Fin.foldl_zero] using hFoldRowB r hr.le
        | succ k ihk =>
            intro hk
            have hf : innerAt (k + 1) hk =
                maxInt (innerAt k (Nat.le_of_succ_le hk)) (absInt (M rFin ⟨k, hk⟩)) := by
              dsimp [innerAt]; rw [Fin.foldl_succ_last]; rfl
            rw [hf]
            exact hmaxInt_abs (ihk (Nat.le_of_succ_le hk)) (hMB rFin ⟨k, hk⟩)
      let modIn : ℕ → ℤ → Prop := fun t idx => t = 10 ∧ (idx = 6 ∨ idx = 28 ∨ idx = 43)
      let InvIn : ℕ → UL.WordStore → Prop := fun k wsi =>
        PreservesOutside modIn ws wsi ∧
        ((hk : k ≤ nVars) → hRead wsi 10 6 = innerAt k hk)
      have hInvIn0 : InvIn 0 (hWrite ws 10 43 0) :=
        ⟨PreservesOutside.write ws 0 (by dsimp [modIn]; omega),
         fun _ => by
           dsimp [innerAt]
           rw [Fin.foldl_zero, hRead_hWrite_of_ne ws 0 (Or.inr (by omega)), hacc_r hr.le]⟩
      have hnV_ws : evalVal inp (hWrite ws 10 43 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne ws 0 (Or.inr (by omega)),
            hpr 10 0 (by dsimp [mod]; omega), hnVars_ws]
      obtain ⟨ws_in, _, ⟨hprIn, hInDone⟩, hs_in⟩ := exec_for hctx 43 (.readHeap 10 (.lit 0))
        (updateMaxAbsStmt (.readHeap tM
          (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43)))))
        nVars 4 InvIn hws (by omega) hDimIdx.2.1 hnV_ws hInvIn0
        (fun j hj wsi hwsi hctr_j ⟨hpr_i, hacc_i⟩ => by
          let jFin : Fin nVars := ⟨j, hj⟩
          have hr_wsi : hRead wsi 10 42 = (r : ℤ) := by
            rw [hpr_i 10 42 (by dsimp [modIn]; omega), hctr_r]
          have hnV_wsi : hRead wsi 10 0 = (nVars : ℤ) := by
            rw [hpr_i 10 0 (by dsimp [modIn]; omega), hpr 10 0 (by dsimp [mod]; omega), hnVars_ws]
          have hM_wsi : hRead wsi tM ((r * nVars + j : ℕ) : ℤ) = M rFin jFin := by
            rw [hpr_i tM _ (by dsimp [modIn]; omega), hpr tM _ (by dsimp [mod]; omega)]
            exact hM_ws rFin jFin
          have hij_eq : (r : ℤ) * (nVars : ℤ) + (j : ℤ) = ((r * nVars + j : ℕ) : ℤ) := by
            push_cast; ring
          have hval_M : evalVal inp wsi (.readHeap tM
              (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43)))) =
              M rFin jFin := by
            simp only [evalVal_readHeap, evalVal_add, evalVal_mul, evalVal_lit,
              hr_wsi, hnV_wsi, hctr_j, hij_eq, hM_wsi]
          obtain ⟨wsi', h6', hpr_u, hex_u⟩ := exec_updateMaxAbsStmt hctx h64 hwsi _
            (hacc_i hj.le) hval_M (hInnerB j hj.le) (hMB rFin jFin)
            (by simp [exprWf, htM31]) (by dsimp [exprNodes, exprLeaves]; omega)
          refine ⟨wsi', hex_u, ?_, ?_⟩
          · rw [hpr_u 10 43 (by omega), hctr_j]
          · refine ⟨(hpr_i.trans (hpr_u.mono (by intro t idx h; dsimp [modIn]; omega))).trans
                (PreservesOutside.write wsi' _ (by dsimp [modIn]; omega)), fun _ => ?_⟩
            rw [hRead_hWrite_of_ne wsi' _ (Or.inr (by omega)), h6']
            dsimp [innerAt]; rw [Fin.foldl_succ_last]; rfl)
        (by decide) (by decide) (by decide) (by decide)
      -- Update with rhs rFin
      have hr_wsin : hRead ws_in 10 42 = (r : ℤ) := by
        rw [hprIn 10 42 (by dsimp [modIn]; omega), hctr_r]
      have hrhs_wsin : evalVal inp ws_in (.readHeap td (.readHeap 10 (.lit 42))) = rhs rFin := by
        simp only [evalVal_readHeap, evalVal_lit, hr_wsin]
        rw [hprIn td _ (by dsimp [modIn]; omega), hpr td _ (by dsimp [mod]; omega)]
        exact hrhs_ws rFin
      obtain ⟨ws_out, h6_out, hpr_out, hs_out⟩ := exec_updateMaxAbsStmt hctx h64 hs_in.2.1 _
        (hInDone le_rfl) hrhs_wsin (hInnerB nVars le_rfl) (hrhsB rFin)
        (by simp [exprWf, htd31]) (by dsimp [exprNodes, exprLeaves]; omega)
      have hpr_tot : PreservesOutside mod ws₀ ws_out :=
        (hpr.trans (hprIn.mono (by intro t idx h; dsimp [modIn] at h; dsimp [mod]; omega))).trans
          (hpr_out.mono (by intro t idx h; dsimp [mod]; omega))
      refine ⟨ws_out, (hs_in.seq_steps hs_out).mono_steps (by omega), ?_, ?_⟩
      · rw [hpr_out 10 42 (by omega), hr_wsin]
      · refine ⟨hpr_tot.trans (PreservesOutside.write ws_out _ (by dsimp [mod]; omega)), fun _ => ?_⟩
        rw [hRead_hWrite_of_ne ws_out _ (Or.inr (by omega)), h6_out]
        dsimp [foldRow, rowMaxAbs, innerAt, curInit]
        rw [Fin.foldl_succ_last]; rfl)
    (by decide) (by decide) (by simp [exprWf, hcs_wf]) (by dsimp [exprNodes, exprLeaves]; omega)
  exact ⟨ws₁, hdone le_rfl, hpr₁, hex₁⟩

theorem exec_computeMaxEntryStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars ≤ maxIdx ∧ nEq ≤ maxIdx ∧ nLe ≤ maxIdx ∧
            nEq * nVars ≤ maxIdx ∧ nLe * nVars ≤ maxIdx)
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (hMeqB : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ K) (hdeqB : ∀ i, (d_eq i).natAbs ≤ 2 ^ K)
    (hMleB : ∀ k j, (M_le k j).natAbs ≤ 2 ^ K) (hdleB : ∀ k, (d_le k).natAbs ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hCleared : ClearedLPInHeap M_eq d_eq M_le d_le ws₀) :
    let mod : ℕ → ℤ → Prop := fun t idx =>
      t = 10 ∧ (idx = 6 ∨ idx = 28 ∨ idx = 42 ∨ idx = 43)
    ∃ ws₁ : UL.WordStore,
      hRead ws₁ 10 6 = computeMaxEntry M_eq d_eq M_le d_le ∧
      PreservesOutside mod ws₀ ws₁ ∧
      ExecBit inp maxIdx K computeMaxEntryStmt ws₀ ws₁
        ((6 + (nEq + nLe) * (7 + 5 * nVars)) * stepU)
        ((6 + (nEq + nLe) * (7 + 5 * nVars)) * stepB K) := by
  intro mod
  have h2_abs : (2 : ℤ).natAbs ≤ 2 ^ K := by
    have hK := hctx.hK
    exact (show 2 = 2 ^ 1 from rfl).trans_le (Nat.pow_le_pow_right (by omega) (by omega))
  have hs0 := exec_write hctx hws₀ 10 (.lit 6) (.lit 2) 6 2 rfl rfl (by omega) (by omega) h2_abs
  let ws1 := hWrite ws₀ 10 6 2
  have hpr1 : PreservesOutside mod ws₀ ws1 :=
    PreservesOutside.write ws₀ 2 (by dsimp [mod]; omega)
  have hDim1 := hDims.preserve hpr1 (by intro idx _ _; dsimp [mod]; omega)
  have hCl1 := hCleared.preserve hpr1 (by intro t idx _ _; dsimp [mod]; omega)
  obtain ⟨ws2, h6_2, hpr2, hs1⟩ := exec_maxBlockStmt hctx h64
    ⟨hIdx.2.1, hIdx.1, hIdx.2.2.2.1⟩ 1 (by decide) (by omega) (by omega) (by omega)
    M_eq d_eq hMeqB hdeqB h2_abs hs0.2.1 hDim1.1 hDim1.2.1 (hRead_hWrite_self ws₀ 10 6 2)
    hCl1.1 hCl1.2.1
  have hpr12 : PreservesOutside mod ws₀ ws2 := hpr1.trans hpr2
  have hDim2 := hDims.preserve hpr12 (by intro idx _ _; dsimp [mod]; omega)
  have hCl2 := hCleared.preserve hpr12 (by intro t idx _ _; dsimp [mod]; omega)
  have h6_2_abs : (Fin.foldl nEq (fun acc i => rowMaxAbs acc (M_eq i) (d_eq i)) 2).natAbs ≤ 2 ^ K := by
    rw [← h6_2]
    exact storeBounded_read_abs hs1.2.1 (.heap 10 6)
  obtain ⟨ws3, h6_3, hpr3, hs2⟩ := exec_maxBlockStmt hctx h64
    ⟨hIdx.2.2.1, hIdx.1, hIdx.2.2.2.2⟩ 2 (by decide) (by omega) (by omega) (by omega)
    M_le d_le hMleB hdleB h6_2_abs hs1.2.1 hDim2.1 hDim2.2.2.1 h6_2 hCl2.2.2.1 hCl2.2.2.2
  have htot : ExecBit inp maxIdx K computeMaxEntryStmt ws₀ ws3
      ((6 + (nEq + nLe) * (7 + 5 * nVars)) * stepU)
      ((6 + (nEq + nLe) * (7 + 5 * nVars)) * stepB K) := by
    refine ((hs0.seq_steps (hs1.seq_steps hs2))).mono_steps ?_
    calc 1 + ((2 + nEq * (6 + 5 * nVars + 1)) + (2 + nLe * (6 + 5 * nVars + 1)))
        = 5 + (nEq + nLe) * (7 + 5 * nVars) := by ring
      _ ≤ 6 + (nEq + nLe) * (7 + 5 * nVars) := by omega
  exact ⟨ws3, h6_3, hpr12.trans hpr3, htot⟩

/-- `ceilLog2Stmt` computes `(L, pow2) = ceilLog2Pure U_max` into `(10, 7)` and `(10, 8)`. -/
def ceilLog2Stmt : UL.BitRAMStmt :=
  seqBitStmts
    [ .writeHeap 10 (.lit 7) (.lit 1)
    , .writeHeap 10 (.lit 8) (.lit 2)
    , .whileLoop (.intLt (.readHeap 10 (.lit 8)) (.readHeap 10 (.lit 6)))
        (.seq
          (.writeHeap 10 (.lit 7) (.add (.readHeap 10 (.lit 7)) (.lit 1)))
          (.writeHeap 10 (.lit 8) (.mul (.lit 2) (.readHeap 10 (.lit 8))))) ]

theorem ceilLog2Aux_steps (U_max : ℤ) :
    ∀ (fuel L₀ : ℕ) (pow2 : ℤ),
      pow2 = (2 : ℤ) ^ L₀ →
      1 ≤ L₀ →
      U_max ≤ pow2 + (fuel : ℤ) →
      let res := ceilLog2Aux U_max fuel L₀ pow2
      L₀ ≤ res.1 ∧ res.2 = (2 : ℤ) ^ res.1 ∧ U_max ≤ res.2 ∧
      (∀ j : ℕ, L₀ ≤ j → j < res.1 → (2 : ℤ) ^ j < U_max) := by
  intro fuel
  induction fuel with
  | zero =>
      intro L₀ pow2 hpow _ hU
      simp only [ceilLog2Aux, Nat.cast_zero, add_zero] at hU ⊢
      exact ⟨le_rfl, hpow, hU, fun _ h1 h2 => by omega⟩
  | succ fuel ih =>
      intro L₀ pow2 hpow hL1 hU
      simp only [ceilLog2Aux]
      by_cases hlt : pow2 < U_max
      · rw [if_pos hlt]
        have hp2 : (2 : ℤ) ≤ pow2 := by
          rw [hpow]
          have : (2 : ℤ) ^ 1 ≤ (2 : ℤ) ^ L₀ := pow_le_pow_right₀ (by norm_num) hL1
          simpa using this
        have hU' : U_max ≤ 2 * pow2 + (fuel : ℤ) := by push_cast at hU; linarith
        obtain ⟨hle, hp_out, hU_out, hall⟩ := ih (L₀ + 1) (2 * pow2) (by rw [hpow, pow_succ']) (by omega) hU'
        refine ⟨by omega, hp_out, hU_out, fun j hj1 hj2 => ?_⟩
        rcases eq_or_lt_of_le hj1 with rfl | hgt
        · rwa [← hpow]
        · exact hall j hgt hj2
      · rw [if_neg hlt]
        exact ⟨le_rfl, hpow, le_of_not_gt hlt, fun _ h1 h2 => by omega⟩

theorem exec_ceilLog2Stmt {d : ℕ} {inp : UL.BitRAMInput d}
    {maxIdx K B_int : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hB1 : 1 ≤ B_int) (hBK : B_int ≤ K)
    {U_max : ℤ} (hU2 : 2 ≤ U_max) (hU_ub : U_max ≤ (2 : ℤ) ^ B_int)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hU_ws : hRead ws₀ 10 6 = U_max) :
    let L_out := (ceilLog2Pure U_max).1
    let pow2_out := (ceilLog2Pure U_max).2
    let mod : ℕ → ℤ → Prop := fun t idx => t = 10 ∧ (idx = 7 ∨ idx = 8)
    ∃ ws₁ : UL.WordStore,
      hRead ws₁ 10 7 = (L_out : ℤ) ∧
      hRead ws₁ 10 8 = pow2_out ∧
      PreservesOutside mod ws₀ ws₁ ∧
      ExecBit inp maxIdx K ceilLog2Stmt ws₀ ws₁
        ((5 + 3 * B_int) * stepU) ((5 + 3 * B_int) * stepB K) := by
  intro L_out pow2_out mod
  have hSpec := ceilLog2Pure_spec U_max B_int hB1 hU_ub
  change 1 ≤ L_out ∧ L_out ≤ B_int ∧ pow2_out = (2 : ℤ) ^ L_out ∧ U_max ≤ pow2_out at hSpec
  obtain ⟨hL1, hLB, hpow_eq, hU_le⟩ := hSpec
  obtain ⟨_, _, _, hAllLt⟩ := ceilLog2Aux_steps U_max U_max.toNat 1 2 (by norm_num) le_rfl (by omega)
  change ∀ j : ℕ, 1 ≤ j → j < L_out → (2 : ℤ) ^ j < U_max at hAllLt
  have hs1 := exec_write hctx hws₀ 10 (.lit 7) (.lit 1) 7 1 rfl rfl (by omega) (by omega) Nat.one_le_two_pow
  let ws1 := hWrite ws₀ 10 7 1
  have h2_abs : (2 : ℤ).natAbs ≤ 2 ^ K := by
    have hK := hctx.hK
    exact (show 2 = 2 ^ 1 from rfl).trans_le (Nat.pow_le_pow_right (by omega) (by omega))
  have hs2 := exec_write hctx hs1.2.1 10 (.lit 8) (.lit 2) 8 2 rfl rfl (by omega) (by omega) h2_abs
  let ws2 := hWrite ws1 10 8 2
  have hpr2 : PreservesOutside mod ws₀ ws2 :=
    (PreservesOutside.write ws₀ 1 (by dsimp [mod]; omega)).trans
      (PreservesOutside.write ws1 2 (by dsimp [mod]; omega))
  let N_iter := L_out - 1
  let Inv : ℕ → UL.WordStore → Prop := fun i ws =>
    PreservesOutside mod ws₀ ws ∧
    hRead ws 10 7 = ((i + 1 : ℕ) : ℤ) ∧
    hRead ws 10 8 = (2 : ℤ) ^ (i + 1)
  have hInv0 : Inv 0 ws2 :=
    ⟨hpr2,
     by dsimp [ws2, ws1]; rw [hRead_hWrite_of_ne ws1 2 (Or.inr (by omega)), hRead_hWrite_self],
     by simp [ws2]⟩
  let cond := UL.BitCondExpr.intLt (.readHeap 10 (.lit 8)) (.readHeap 10 (.lit 6))
  let body := UL.BitRAMStmt.seq
    (.writeHeap 10 (.lit 7) (.add (.readHeap 10 (.lit 7)) (.lit 1)))
    (.writeHeap 10 (.lit 8) (.mul (.lit 2) (.readHeap 10 (.lit 8))))
  obtain ⟨ws3, ⟨hpr3, hL3, hp3⟩, hwl⟩ := ExecBit.whileLoop_nat hctx cond body
    N_iter (2 * stepU) (2 * stepB K) Inv hs2.2.1 hInv0 (by decide)
    (fun i hi ws hws ⟨hpr, hi7, hi8⟩ => by
      have hi1_lt : i + 1 < L_out := by omega
      have hlt_i : (2 : ℤ) ^ (i + 1) < U_max := hAllLt (i + 1) (by omega) hi1_lt
      have hU_w : hRead ws 10 6 = U_max := by rw [hpr 10 6 (by dsimp [mod]; omega), hU_ws]
      refine ⟨by simp [cond, hi8, hU_w, hlt_i], ?_⟩
      have hi2_le_K : i + 2 ≤ K := by omega
      have h7_abs : (((i + 1 : ℕ) : ℤ) + 1).natAbs ≤ 2 ^ K := by
        have h1 : (((i + 1 : ℕ) : ℤ) + 1).natAbs = i + 2 := by omega
        rw [h1]
        exact Nat.lt_two_pow_self.le.trans (Nat.pow_le_pow_right (by omega) hi2_le_K)
      have hw7 := exec_write hctx hws 10 (.lit 7) (.add (.readHeap 10 (.lit 7)) (.lit 1))
        7 (((i + 1 : ℕ) : ℤ) + 1) rfl (by simp [hi7]) (by omega) (by omega) h7_abs
      let wsa := hWrite ws 10 7 (((i + 1 : ℕ) : ℤ) + 1)
      have hi8_a : hRead wsa 10 8 = (2 : ℤ) ^ (i + 1) := by
        rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hi8]
      have h8_abs : ((2 : ℤ) * (2 : ℤ) ^ (i + 1)).natAbs ≤ 2 ^ K := by
        rw [← pow_succ']
        have : 2 ^ (i + 2) ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) hi2_le_K
        simpa using this
      have hw8 := exec_write hctx hw7.2.1 10 (.lit 8) (.mul (.lit 2) (.readHeap 10 (.lit 8)))
        8 ((2 : ℤ) * (2 : ℤ) ^ (i + 1)) rfl
        (by dsimp only [wsa] at hi8_a; simp only [evalVal_mul, evalVal_lit, evalVal_readHeap, hi8_a])
        (by omega) (by omega) h8_abs
      let wsb := hWrite wsa 10 8 ((2 : ℤ) * (2 : ℤ) ^ (i + 1))
      refine ⟨wsb, hw7.seq_steps hw8, ?_, ?_, ?_⟩
      · exact (hpr.trans (PreservesOutside.write ws _ (by dsimp [mod]; omega))).trans
          (PreservesOutside.write wsa _ (by dsimp [mod]; omega))
      · rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)), hRead_hWrite_self]
        push_cast; ring
      · rw [hRead_hWrite_self, ← pow_succ'])
    (fun ws _ ⟨hpr, _, hi8⟩ => by
      have hEqL : N_iter + 1 = L_out := by omega
      rw [hEqL, ← hpow_eq] at hi8
      have hU_w : hRead ws 10 6 = U_max := by rw [hpr 10 6 (by dsimp [mod]; omega), hU_ws]
      simp [cond, hi8, hU_w, not_lt.mpr hU_le])
  have hEqL : N_iter + 1 = L_out := by omega
  rw [hEqL] at hL3 hp3
  rw [← hpow_eq] at hp3
  have hN_le : N_iter ≤ B_int := by omega
  have hwl_steps : ExecBit inp maxIdx K (.whileLoop cond body) ws2 ws3
      ((1 + 3 * B_int) * stepU) ((1 + 3 * B_int) * stepB K) := by
    refine hwl.mono ?_ ?_
    · have huc : condNodes cond ≤ stepU := by decide
      calc (N_iter + 1) * condNodes cond + N_iter * (2 * stepU)
          ≤ (B_int + 1) * stepU + B_int * (2 * stepU) :=
            Nat.add_le_add (Nat.mul_le_mul (by omega) huc)
              (Nat.mul_le_mul_right _ hN_le)
        _ = (1 + 3 * B_int) * stepU := by ring
    · have hbc : condNodes cond * (2 * condLeaves cond * K) ^ 2 ≤ stepB K := by
        dsimp [cond, condNodes, condLeaves, exprNodes, exprLeaves, stepB]
        calc 5 * (2 * 4 * K) ^ 2 = 320 * K ^ 2 := by ring
          _ ≤ 2000000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)
      calc (N_iter + 1) * (condNodes cond * (2 * condLeaves cond * K) ^ 2) + N_iter * (2 * stepB K)
          ≤ (B_int + 1) * stepB K + B_int * (2 * stepB K) :=
            Nat.add_le_add (Nat.mul_le_mul (by omega) hbc)
              (Nat.mul_le_mul_right _ hN_le)
        _ = (1 + 3 * B_int) * stepB K := by ring
  have htot := (hs1.seq_steps (hs2.seq_steps hwl_steps)).mono_steps
    (show 1 + (1 + (1 + 3 * B_int)) ≤ 5 + 3 * B_int by omega)
  exact ⟨ws3, hL3, hp3, hpr3, htot⟩


/-! ### 5. `buildOracleStmt` (Table 24 = `padCols (buildOracleM ...)`, Table 25 = `buildOracleD ...`) -/

/-- Populate one row `rE` of `(oracleM_pad, oracleD)` (Tables 24, 25) from source row `srcRowE`
of `(srcTM, srcTd)` with sign `sgn` (`1` or `-1`), or all zeros if `zeroRow = true`. -/
def writeOracleRowStmt (rE srcRowE : UL.IntExpr) (srcTM srcTd : ℕ) (sgn : ℤ) (zeroRow : Bool) :
    UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let NE := UL.IntExpr.readHeap 10 (.lit 3)
  let jE := UL.IntExpr.readHeap 10 (.lit 43)
  let dstIJE := UL.IntExpr.add (.mul rE NE) jE
  let srcIJE := UL.IntExpr.add (.mul srcRowE nVarsE) jE
  let mValE := if zeroRow then UL.IntExpr.lit 0
               else if sgn == 1 then .readHeap srcTM srcIJE
               else .neg (.readHeap srcTM srcIJE)
  let dValE := if zeroRow then UL.IntExpr.lit 0
               else if sgn == 1 then .readHeap srcTd srcRowE
               else .neg (.readHeap srcTd srcRowE)
  seqBitStmts
    [ .writeHeap 25 rE dValE
    , forLoopStmt 43 nVarsE (.writeHeap 24 dstIJE mValE)
    , .writeHeap 24 (.add (.mul rE NE) nVarsE) (.lit 0)
    , .writeHeap 24 (.add (.mul rE NE) (.add nVarsE (.lit 1))) (.lit 0) ]

/-- Build the `(2 * nEq + 2 * nLe) × (nVars + 2)` padded oracle system in Tables 24 & 25,
reading boolean active flags `0 / 1` from Table 23 starting at `actOffE`. -/
def buildOracleStmt (actOffE : UL.IntExpr) : UL.BitRAMStmt :=
  let nEqE := UL.IntExpr.readHeap 10 (.lit 1)
  let nLeE := UL.IntExpr.readHeap 10 (.lit 2)
  let iE := UL.IntExpr.readHeap 10 (.lit 42)
  let r2E := UL.IntExpr.add nEqE iE
  let r3E := UL.IntExpr.add (.mul (.lit 2) nEqE) iE
  let r4E := UL.IntExpr.add (.add (.mul (.lit 2) nEqE) nLeE) iE
  seqBitStmts
    [ forLoopStmt 42 nEqE (writeOracleRowStmt iE iE 19 20 1 false)
    , forLoopStmt 42 nEqE (writeOracleRowStmt r2E iE 19 20 (-1) false)
    , forLoopStmt 42 nLeE (writeOracleRowStmt r3E iE 21 22 1 false)
    , forLoopStmt 42 nLeE
        (.ite (.intEq (.readHeap 23 (.add actOffE iE)) (.lit 1))
          (writeOracleRowStmt r4E iE 21 22 (-1) false)
          (writeOracleRowStmt r4E iE 21 22 1 true)) ]

theorem exec_writeOracleRowStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars m_ora maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars ≤ maxIdx ∧ m_ora * (nVars + 2) ≤ maxIdx ∧ m_ora ≤ maxIdx)
    {r srcRow nSrcRows : ℕ} (hr : r < m_ora) (hsrc : srcRow < nSrcRows)
    (rE srcRowE : UL.IntExpr)
    (hwf_r : exprWf 31 rE = true) (hwf_s : exprWf 31 srcRowE = true)
    (hsz_r : exprNodes rE ≤ 12 ∧ exprLeaves rE ≤ 12)
    (hsz_s : exprNodes srcRowE ≤ 12 ∧ exprLeaves srcRowE ≤ 12)
    (hdep_r : ∀ ws₁ ws₂ : UL.WordStore,
      hRead ws₁ 10 1 = hRead ws₂ 10 1 → hRead ws₁ 10 2 = hRead ws₂ 10 2 →
      hRead ws₁ 10 42 = hRead ws₂ 10 42 → evalVal inp ws₁ rE = evalVal inp ws₂ rE)
    (hdep_s : ∀ ws₁ ws₂ : UL.WordStore,
      hRead ws₁ 10 42 = hRead ws₂ 10 42 → evalVal inp ws₁ srcRowE = evalVal inp ws₂ srcRowE)
    {srcTM srcTd : ℕ} (htM : 19 ≤ srcTM ∧ srcTM ≤ 22) (htd : 19 ≤ srcTd ∧ srcTd ≤ 22)
    (sgn : ℤ) (hsgn : sgn = 1 ∨ sgn = -1) (zeroRow : Bool)
    (srcM : Fin nSrcRows → Fin nVars → ℤ) (srcD : Fin nSrcRows → ℤ)
    (hMB : ∀ i j, (srcM i j).natAbs ≤ 2 ^ K)
    (hdB : ∀ i, (srcD i).natAbs ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hnV : hRead ws₀ 10 0 = (nVars : ℤ))
    (hN : hRead ws₀ 10 3 = ((nVars + 2 : ℕ) : ℤ))
    (hr_val : evalVal inp ws₀ rE = (r : ℤ))
    (hs_val : evalVal inp ws₀ srcRowE = (srcRow : ℤ))
    (hsrcM_ws : ∀ j : Fin nVars, hRead ws₀ srcTM ((srcRow * nVars + j.val : ℕ) : ℤ) = srcM ⟨srcRow, hsrc⟩ j)
    (hsrcD_ws : hRead ws₀ srcTd (srcRow : ℤ) = srcD ⟨srcRow, hsrc⟩) :
    let N := nVars + 2
    let targetM : Fin N → ℤ := fun j =>
      if hj : j.val < nVars then
        if zeroRow then 0 else sgn * srcM ⟨srcRow, hsrc⟩ ⟨j.val, hj⟩
      else 0
    let targetD : ℤ := if zeroRow then 0 else sgn * srcD ⟨srcRow, hsrc⟩
    let modR : ℕ → ℤ → Prop := fun t idx =>
      (t = 10 ∧ idx = 43) ∨
      (t = 24 ∧ ((r * N : ℕ) : ℤ) ≤ idx ∧ idx < (((r + 1) * N : ℕ) : ℤ)) ∨
      (t = 25 ∧ idx = (r : ℤ))
    ∃ ws₁ : UL.WordStore,
      PreservesOutside modR ws₀ ws₁ ∧
      hRead ws₁ 25 (r : ℤ) = targetD ∧
      (∀ j : Fin N, hRead ws₁ 24 ((r * N + j.val : ℕ) : ℤ) = targetM j) ∧
      ExecBit inp maxIdx K (writeOracleRowStmt rE srcRowE srcTM srcTd sgn zeroRow) ws₀ ws₁
        ((5 + 2 * nVars) * stepU) ((5 + 2 * nVars) * stepB K) := by
  intro N targetM targetD modR
  let dValE : UL.IntExpr :=
    if zeroRow then .lit 0
    else if sgn == 1 then .readHeap srcTd srcRowE
    else .neg (.readHeap srcTd srcRowE)
  let mValE : UL.IntExpr :=
    if zeroRow then .lit 0
    else if sgn == 1 then .readHeap srcTM (.add (.mul srcRowE (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43)))
    else .neg (.readHeap srcTM (.add (.mul srcRowE (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43))))
  have hd_eval : evalVal inp ws₀ dValE = targetD := by
    dsimp [dValE, targetD]
    cases zeroRow
    · rcases hsgn with rfl | rfl <;> simp [hs_val, hsrcD_ws]
    · simp
  have hd_abs : targetD.natAbs ≤ 2 ^ K := by
    dsimp [targetD]
    cases zeroRow
    · rcases hsgn with rfl | rfl <;> simpa using hdB ⟨srcRow, hsrc⟩
    · simp
  have htd31 : decide (srcTd ≤ 31) = true := decide_eq_true (by omega)
  have htM31 : decide (srcTM ≤ 31) = true := decide_eq_true (by omega)
  have hwf_d : exprWf 31 dValE = true := by
    dsimp [dValE]; cases zeroRow
    · rcases hsgn with rfl | rfl <;> simp [exprWf, htd31, hwf_s]
    · rfl
  have hsz_d : exprNodes (rE) + exprNodes dValE + 2 ≤ 64 ∧
      exprLeaves rE + exprLeaves dValE + 2 ≤ 64 := by
    dsimp [dValE]; cases zeroRow
    · rcases hsgn with rfl | rfl <;> dsimp [exprNodes, exprLeaves] <;> omega
    · dsimp [exprNodes, exprLeaves]; omega
  have hs1 := exec_write hctx hws₀ 25 rE dValE (r : ℤ) targetD hr_val hd_eval
    (Nat.cast_nonneg _) (by omega) hd_abs (by decide) hwf_r hwf_d hsz_d
  let ws1 := hWrite ws₀ 25 (r : ℤ) targetD
  have hpr1 : PreservesOutside modR ws₀ ws1 :=
    PreservesOutside.write ws₀ targetD (by dsimp [modR]; omega)
  -- Loop j < nVars
  let modL : ℕ → ℤ → Prop := fun t idx =>
    (t = 10 ∧ idx = 43) ∨
    (t = 24 ∧ ((r * N : ℕ) : ℤ) ≤ idx ∧ idx < ((r * N + nVars : ℕ) : ℤ))
  let Inv : ℕ → UL.WordStore → Prop := fun k ws =>
    PreservesOutside modL ws1 ws ∧
    (∀ j : Fin nVars, j.val < k → hRead ws 24 ((r * N + j.val : ℕ) : ℤ) = targetM (Fin.castAdd 2 j))
  have hInv0 : Inv 0 (hWrite ws1 10 43 0) :=
    ⟨PreservesOutside.write ws1 0 (by dsimp [modL]; omega),
     fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
  have hnV_ws1 : evalVal inp (hWrite ws1 10 43 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws1 0 (Or.inr (by omega)),
        hRead_hWrite_of_ne ws₀ _ (Or.inl (by omega)), hnV]
  obtain ⟨ws2, _, ⟨hprL, hCols⟩, hs2⟩ := exec_for hctx 43 (.readHeap 10 (.lit 0))
    (.writeHeap 24 (.add (.mul rE (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))) mValE)
    nVars 1 Inv hs1.2.1 (by omega) hIdx.1 hnV_ws1 hInv0
    (fun j hj ws hws hctr_j ⟨hpr_l, hprev⟩ => by
      let jFin : Fin nVars := ⟨j, hj⟩
      have hr_ws : evalVal inp ws rE = (r : ℤ) := by
        rw [hdep_r ws ws₀
          (by rw [hpr_l 10 1 (by dsimp [modL]; omega), hpr1 10 1 (by dsimp [modR]; omega)])
          (by rw [hpr_l 10 2 (by dsimp [modL]; omega), hpr1 10 2 (by dsimp [modR]; omega)])
          (by rw [hpr_l 10 42 (by dsimp [modL]; omega), hpr1 10 42 (by dsimp [modR]; omega)]),
          hr_val]
      have hs_ws : evalVal inp ws srcRowE = (srcRow : ℤ) := by
        rw [hdep_s ws ws₀
          (by rw [hpr_l 10 42 (by dsimp [modL]; omega), hpr1 10 42 (by dsimp [modR]; omega)]),
          hs_val]
      have hnV_ws : hRead ws 10 0 = (nVars : ℤ) := by
        rw [hpr_l 10 0 (by dsimp [modL]; omega), hpr1 10 0 (by dsimp [modR]; omega), hnV]
      have hN_ws : hRead ws 10 3 = (N : ℤ) := by
        rw [hpr_l 10 3 (by dsimp [modL]; omega), hpr1 10 3 (by dsimp [modR]; omega), hN]
      have hidx_dst : evalVal inp ws (.add (.mul rE (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))) =
          ((r * N + j : ℕ) : ℤ) := by
        simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hr_ws, hN_ws, hctr_j]
        push_cast; ring
      have hsrcM_j : hRead ws srcTM ((srcRow * nVars + j : ℕ) : ℤ) = srcM ⟨srcRow, hsrc⟩ jFin := by
        rw [hpr_l srcTM _ (by dsimp [modL]; omega), hpr1 srcTM _ (by dsimp [modR]; omega)]
        exact hsrcM_ws jFin
      have hm_eval : evalVal inp ws mValE = targetM (Fin.castAdd 2 jFin) := by
        have hij_s : (srcRow : ℤ) * (nVars : ℤ) + (j : ℤ) = ((srcRow * nVars + j : ℕ) : ℤ) := by
          push_cast; ring
        dsimp only [targetM, Fin.val_castAdd, jFin]
        rw [dif_pos hj]
        cases zeroRow
        · rcases hsgn with rfl | rfl
          · change evalVal inp ws (.readHeap srcTM (.add (.mul srcRowE (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43)))) =
              1 * srcM ⟨srcRow, hsrc⟩ ⟨j, hj⟩
            simp only [evalVal_readHeap, evalVal_add, evalVal_mul, evalVal_lit,
              hs_ws, hnV_ws, hctr_j, hij_s, hsrcM_j, one_mul]; rfl
          · change evalVal inp ws (.neg (.readHeap srcTM (.add (.mul srcRowE (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43))))) =
              -1 * srcM ⟨srcRow, hsrc⟩ ⟨j, hj⟩
            simp only [evalVal_neg, evalVal_readHeap, evalVal_add, evalVal_mul, evalVal_lit,
              hs_ws, hnV_ws, hctr_j, hij_s, hsrcM_j, neg_one_mul]; rfl
        · change evalVal inp ws (.lit 0) = 0
          rfl
      have hm_abs : (targetM (Fin.castAdd 2 jFin)).natAbs ≤ 2 ^ K := by
        simp only [targetM, Fin.val_castAdd, jFin, dif_pos hj]
        cases zeroRow
        · rcases hsgn with rfl | rfl <;> simpa using hMB ⟨srcRow, hsrc⟩ jFin
        · simp
      have hdst_ub : ((r * N + j : ℕ) : ℤ) ≤ (maxIdx : ℤ) := by
        have h1 : r * N + j < (r + 1) * N := by
          calc r * N + j < r * N + N := Nat.add_lt_add_left (by dsimp [N]; omega) _
            _ = (r + 1) * N := by ring
        have h2 : (r + 1) * N ≤ m_ora * N := Nat.mul_le_mul_right N hr
        exact Nat.cast_le.mpr (h1.le.trans (h2.trans hIdx.2.1))
      have hwf_dst : exprWf 31 (.add (.mul rE (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))) = true := by
        simp [exprWf, hwf_r]
      have hwf_m : exprWf 31 mValE = true := by
        dsimp [mValE]; cases zeroRow
        · rcases hsgn with rfl | rfl <;> simp [exprWf, htM31, hwf_s]
        · rfl
      have hsz_m : exprNodes (.add (.mul rE (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))) +
          exprNodes mValE + 2 ≤ 64 ∧
          exprLeaves (.add (.mul rE (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 43))) +
          exprLeaves mValE + 2 ≤ 64 := by
        dsimp [mValE]; cases zeroRow
        · rcases hsgn with rfl | rfl <;> dsimp [exprNodes, exprLeaves] <;> omega
        · dsimp [exprNodes, exprLeaves]; omega
      have hw_m := exec_write hctx hws 24 _ _ ((r * N + j : ℕ) : ℤ) (targetM (Fin.castAdd 2 jFin)) hidx_dst hm_eval
        (Nat.cast_nonneg _) hdst_ub hm_abs (by decide) hwf_dst hwf_m hsz_m
      let ws' := hWrite ws 24 ((r * N + j : ℕ) : ℤ) (targetM (Fin.castAdd 2 jFin))
      refine ⟨ws', hw_m, ?_, ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega)), hctr_j]
      · refine ⟨(hpr_l.trans (PreservesOutside.write ws _
            (Or.inr ⟨rfl, by exact_mod_cast Nat.le_add_right _ _,
              by exact_mod_cast Nat.add_lt_add_left hj (r * N)⟩))).trans
          (PreservesOutside.write ws' _ (Or.inl ⟨rfl, rfl⟩)), fun j' hj' => ?_⟩
        rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hj' with hlt | heq
        · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]
          exact hprev j' hlt
        · have hj_eq : j' = jFin := Fin.ext heq
          subst hj_eq
          exact hRead_hWrite_self ws 24 _ _)
    (by decide) (by decide) (by decide) (by decide)
  -- Two zero padding writes at r * N + nVars and r * N + nVars + 1
  have hr_ws2 : evalVal inp ws2 rE = (r : ℤ) := by
    rw [hdep_r ws2 ws₀
      (by rw [hprL 10 1 (by dsimp [modL]; omega), hpr1 10 1 (by dsimp [modR]; omega)])
      (by rw [hprL 10 2 (by dsimp [modL]; omega), hpr1 10 2 (by dsimp [modR]; omega)])
      (by rw [hprL 10 42 (by dsimp [modL]; omega), hpr1 10 42 (by dsimp [modR]; omega)]),
      hr_val]
  have hnV_ws2 : hRead ws2 10 0 = (nVars : ℤ) := by
    rw [hprL 10 0 (by dsimp [modL]; omega), hpr1 10 0 (by dsimp [modR]; omega), hnV]
  have hN_ws2 : hRead ws2 10 3 = (N : ℤ) := by
    rw [hprL 10 3 (by dsimp [modL]; omega), hpr1 10 3 (by dsimp [modR]; omega), hN]
  have hpad1_lt : r * N + nVars < (r + 1) * N := by
    calc r * N + nVars < r * N + N := Nat.add_lt_add_left (by dsimp [N]; omega) _
      _ = (r + 1) * N := by ring
  have hpad2_lt : r * N + (nVars + 1) < (r + 1) * N := by
    calc r * N + (nVars + 1) < r * N + N := Nat.add_lt_add_left (by dsimp [N]; omega) _
      _ = (r + 1) * N := by ring
  have hpad1_ub : ((r * N + nVars : ℕ) : ℤ) ≤ (maxIdx : ℤ) :=
    Nat.cast_le.mpr (hpad1_lt.le.trans ((Nat.mul_le_mul_right N hr).trans hIdx.2.1))
  have hpad2_ub : ((r * N + (nVars + 1) : ℕ) : ℤ) ≤ (maxIdx : ℤ) :=
    Nat.cast_le.mpr (hpad2_lt.le.trans ((Nat.mul_le_mul_right N hr).trans hIdx.2.1))
  have hs3 := exec_write hctx hs2.2.1 24
    (.add (.mul rE (.readHeap 10 (.lit 3))) (.readHeap 10 (.lit 0))) (.lit 0)
    ((r * N + nVars : ℕ) : ℤ) 0
    (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hr_ws2, hN_ws2, hnV_ws2]; push_cast; ring) rfl
    (Nat.cast_nonneg _) hpad1_ub (by simp)
    (by decide) (by simp [exprWf, hwf_r]) (by decide)
    (by dsimp [exprNodes, exprLeaves]; omega)
  let ws3 := hWrite ws2 24 ((r * N + nVars : ℕ) : ℤ) 0
  have hr_ws3 : evalVal inp ws3 rE = (r : ℤ) := by
    rw [hdep_r ws3 ws2
      (hRead_hWrite_of_ne ws2 0 (Or.inl (by omega)))
      (hRead_hWrite_of_ne ws2 0 (Or.inl (by omega)))
      (hRead_hWrite_of_ne ws2 0 (Or.inl (by omega))), hr_ws2]
  have hnV_ws3 : hRead ws3 10 0 = (nVars : ℤ) := by
    rw [hRead_hWrite_of_ne ws2 0 (Or.inl (by omega)), hnV_ws2]
  have hN_ws3 : hRead ws3 10 3 = (N : ℤ) := by
    rw [hRead_hWrite_of_ne ws2 0 (Or.inl (by omega)), hN_ws2]
  have hs4 := exec_write hctx hs3.2.1 24
    (.add (.mul rE (.readHeap 10 (.lit 3))) (.add (.readHeap 10 (.lit 0)) (.lit 1))) (.lit 0)
    ((r * N + (nVars + 1) : ℕ) : ℤ) 0
    (by
      dsimp only [ws3] at hr_ws3 hnV_ws3 hN_ws3
      simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hr_ws3, hN_ws3, hnV_ws3]
      push_cast; ring) rfl
    (Nat.cast_nonneg _) hpad2_ub (by simp)
    (by decide) (by simp [exprWf, hwf_r]) (by decide)
    (by dsimp [exprNodes, exprLeaves]; omega)
  let ws4 := hWrite ws3 24 ((r * N + (nVars + 1) : ℕ) : ℤ) 0
  have hpr_tot : PreservesOutside modR ws₀ ws4 := by
    have hp2 : PreservesOutside modR ws₀ ws2 :=
      hpr1.trans (hprL.mono (by
        intro t idx h; dsimp [modL] at h; dsimp [modR]
        rcases h with h1 | ⟨rfl, hlo, hhi⟩
        · exact Or.inl h1
        · exact Or.inr (Or.inl ⟨rfl, hlo, lt_of_lt_of_le hhi (Nat.cast_le.mpr hpad1_lt.le)⟩)))
    have hp3 := hp2.trans (PreservesOutside.write ws2 0
      (Or.inr (Or.inl ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hpad1_lt⟩)))
    exact hp3.trans (PreservesOutside.write ws3 0
      (Or.inr (Or.inl ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hpad2_lt⟩)))
  have htot := (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps hs4))).mono_steps
    (show 1 + ((2 + nVars * (1 + 1)) + (1 + 1)) ≤ 5 + 2 * nVars by ring_nf; omega)
  refine ⟨ws4, hpr_tot, ?_, fun j => ?_, htot⟩
  · rw [hRead_hWrite_of_ne ws3 0 (Or.inl (by omega)),
        hRead_hWrite_of_ne ws2 0 (Or.inl (by omega)),
        hprL 25 _ (by dsimp [modL]; omega),
        hRead_hWrite_self]
  · by_cases hj : j.val < nVars
    · rw [hRead_hWrite_of_ne ws3 0 (Or.inr (by omega)),
          hRead_hWrite_of_ne ws2 0 (Or.inr (by omega))]
      exact hCols ⟨j.val, hj⟩ hj
    · rcases (show j.val = nVars ∨ j.val = nVars + 1 by dsimp [N] at j; omega) with heq | heq
      · rw [heq, hRead_hWrite_of_ne ws3 0 (Or.inr (by omega)), hRead_hWrite_self]
        simp [targetM, hj]
      · rw [heq, hRead_hWrite_self]
        simp [targetM, hj]

theorem exec_buildOracleStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars ≤ maxIdx ∧ nEq ≤ maxIdx ∧ nLe ≤ maxIdx ∧
            (2 * nEq + 2 * nLe) * (nVars + 2) ≤ maxIdx ∧ (2 * nEq + 2 * nLe) ≤ maxIdx)
    (actOff : ℕ) (actOffE : UL.IntExpr)
    (hwf_off : exprWf 31 actOffE = true)
    (hsz_off : exprNodes actOffE ≤ 10 ∧ exprLeaves actOffE ≤ 10)
    (hdep_off : ∀ ws₁ ws₂ : UL.WordStore,
      hRead ws₁ 10 2 = hRead ws₂ 10 2 → evalVal inp ws₁ actOffE = evalVal inp ws₂ actOffE)
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (act : Fin nLe → Bool)
    (hMeqB : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ K) (hdeqB : ∀ i, (d_eq i).natAbs ≤ 2 ^ K)
    (hMleB : ∀ k j, (M_le k j).natAbs ≤ 2 ^ K) (hdleB : ∀ k, (d_le k).natAbs ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hCleared : ClearedLPInHeap M_eq d_eq M_le d_le ws₀)
    (hoff_val : evalVal inp ws₀ actOffE = (actOff : ℤ))
    (hAct_ws : ∀ k : Fin nLe, hRead ws₀ 23 ((actOff + k.val : ℕ) : ℤ) = if act k then 1 else 0) :
    let m_ora := 2 * nEq + 2 * nLe
    let N := nVars + 2
    let mod : ℕ → ℤ → Prop := fun t idx =>
      (t = 10 ∧ (idx = 42 ∨ idx = 43)) ∨ t = 24 ∨ t = 25
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ (r : Fin m_ora) (j : Fin N),
        hRead ws₁ 24 ((r.val * N + j.val : ℕ) : ℤ) =
          padCols (buildOracleM M_eq M_le act) r j) ∧
      (∀ r : Fin m_ora,
        hRead ws₁ 25 (r.val : ℤ) = buildOracleD d_eq d_le act r) ∧
      ExecBit inp maxIdx K (buildOracleStmt actOffE) ws₀ ws₁
        ((10 + m_ora * (8 + 2 * nVars)) * stepU)
        ((10 + m_ora * (8 + 2 * nVars)) * stepB K) := by
  intro m_ora N mod
  let iE := UL.IntExpr.readHeap 10 (.lit 42)
  let nEqE := UL.IntExpr.readHeap 10 (.lit 1)
  let nLeE := UL.IntExpr.readHeap 10 (.lit 2)
  let r2E := UL.IntExpr.add nEqE iE
  let r3E := UL.IntExpr.add (.mul (.lit 2) nEqE) iE
  let r4E := UL.IntExpr.add (.add (.mul (.lit 2) nEqE) nLeE) iE
  -- Helper: row agreement on prefix `0 .. R - 1`
  let RowsMatch : ℕ → UL.WordStore → Prop := fun R ws =>
    (∀ (r : Fin m_ora), r.val < R → ∀ (j : Fin N),
      hRead ws 24 ((r.val * N + j.val : ℕ) : ℤ) = padCols (buildOracleM M_eq M_le act) r j) ∧
    (∀ (r : Fin m_ora), r.val < R →
      hRead ws 25 (r.val : ℤ) = buildOracleD d_eq d_le act r)
  -- Loop 1: 0 .. nEq - 1
  let Inv1 : ℕ → UL.WordStore → Prop := fun k ws =>
    PreservesOutside mod ws₀ ws ∧ RowsMatch k ws
  have hInv1_0 : Inv1 0 (hWrite ws₀ 10 42 0) :=
    ⟨PreservesOutside.write ws₀ 0 (by dsimp [mod]; omega),
     fun _ h => False.elim (Nat.not_lt_zero _ h),
     fun _ h => False.elim (Nat.not_lt_zero _ h)⟩
  have hcnt1 : evalVal inp (hWrite ws₀ 10 42 0) nEqE = (nEq : ℤ) := by
    simp only [nEqE, evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hDims.2.1]
  obtain ⟨ws1, _, ⟨hpr1, hRM1⟩, hex1⟩ := exec_for hctx 42 nEqE
    (writeOracleRowStmt iE iE 19 20 1 false) nEq (5 + 2 * nVars) Inv1 hws₀ (by omega) hIdx.2.1
    hcnt1 hInv1_0
    (fun i hi ws hws hctr_i ⟨hpr, hrm_M, hrm_D⟩ => by
      have hr_lt : i < m_ora := by dsimp [m_ora]; omega
      have hDim_ws := hDims.preserve hpr (by intro idx _ _; dsimp [mod]; omega)
      have hCl_ws := hCleared.preserve hpr (by intro t idx h1 h2; dsimp [mod]; omega)
      obtain ⟨ws', hpr_r, hd_r, hM_r, hex_r⟩ := exec_writeOracleRowStmt hctx h64
        ⟨hIdx.1, hIdx.2.2.2.1, hIdx.2.2.2.2⟩ hr_lt hi iE iE (by decide) (by decide)
        (by decide) (by decide)
        (fun _ _ _ _ h42 => by simp [iE, h42]) (fun _ _ h42 => by simp [iE, h42])
        (by omega) (by omega) 1 (Or.inl rfl) false M_eq d_eq hMeqB hdeqB hws
        hDim_ws.1 hDim_ws.2.2.2.1 (by simp [iE, hctr_i]) (by simp [iE, hctr_i])
        (fun j => hCl_ws.1 ⟨i, hi⟩ j) (hCl_ws.2.1 ⟨i, hi⟩)
      refine ⟨ws', hex_r, ?_, ?_⟩
      · rw [hpr_r 10 42 (by omega), hctr_i]
      · refine ⟨(hpr.trans (hpr_r.mono (by intro t idx h; dsimp [mod]; omega))).trans
            (PreservesOutside.write ws' _ (by dsimp [mod]; omega)),
          fun r hr' j => ?_, fun r hr' => ?_⟩
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < i ∨ r.val = i by omega) with hlt | heq
          · have hlt_idx : r.val * (nVars + 2) + j.val < i * (nVars + 2) := by
              calc r.val * (nVars + 2) + j.val < r.val * (nVars + 2) + (nVars + 2) :=
                    Nat.add_lt_add_left j.isLt _
                _ = (r.val + 1) * (nVars + 2) := by ring
                _ ≤ i * (nVars + 2) := Nat.mul_le_mul_right _ hlt
            dsimp only [N]
            rw [hpr_r 24 _ (by omega)]; exact hrm_M r hlt j
          · dsimp only [N] at j ⊢
            rw [heq, hM_r j]
            dsimp only [padCols]
            by_cases hj : j.val < nVars
            · rw [dif_pos hj, dif_pos hj]
              have hr_eq : (⟨r.val, by omega⟩ : Fin nEq) = ⟨i, hi⟩ := by ext; exact heq
              dsimp only [buildOracleM]
              rw [dif_pos (by omega : r.val < nEq)]
              simp [hr_eq]
            · rw [dif_neg hj, dif_neg hj]
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < i ∨ r.val = i by omega) with hlt | heq
          · rw [hpr_r 25 _ (by omega)]; exact hrm_D r hlt
          · rw [heq, hd_r]
            have hr_eq : (⟨r.val, by omega⟩ : Fin nEq) = ⟨i, hi⟩ := by ext; exact heq
            dsimp only [buildOracleD]
            rw [dif_pos (by omega : r.val < nEq)]
            simp [hr_eq])
  -- Loop 2: nEq .. 2 * nEq - 1
  let Inv2 : ℕ → UL.WordStore → Prop := fun k ws =>
    PreservesOutside mod ws₀ ws ∧ RowsMatch (nEq + k) ws
  have hInv2_0 : Inv2 0 (hWrite ws1 10 42 0) := by
    refine ⟨hpr1.trans (PreservesOutside.write ws1 0 (by dsimp [mod]; omega)), ?_, ?_⟩
    · intro r hr j; rw [hRead_hWrite_of_ne ws1 0 (Or.inl (by omega))]; exact hRM1.1 r (by omega) j
    · intro r hr; rw [hRead_hWrite_of_ne ws1 0 (Or.inl (by omega))]; exact hRM1.2 r (by omega)
  have hcnt2 : evalVal inp (hWrite ws1 10 42 0) nEqE = (nEq : ℤ) := by
    simp only [nEqE, evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws1 0 (Or.inr (by omega)), hpr1 10 1 (by dsimp [mod]; omega), hDims.2.1]
  obtain ⟨ws2, _, ⟨hpr2, hRM2⟩, hex2⟩ := exec_for hctx 42 nEqE
    (writeOracleRowStmt r2E iE 19 20 (-1) false) nEq (5 + 2 * nVars) Inv2 hex1.2.1 (by omega) hIdx.2.1
    hcnt2 hInv2_0
    (fun i hi ws hws hctr_i ⟨hpr, hrm_M, hrm_D⟩ => by
      have hr_lt : nEq + i < m_ora := by dsimp [m_ora]; omega
      have hDim_ws := hDims.preserve hpr (by intro idx _ _; dsimp [mod]; omega)
      have hCl_ws := hCleared.preserve hpr (by intro t idx h1 h2; dsimp [mod]; omega)
      have hr2_val : evalVal inp ws r2E = ((nEq + i : ℕ) : ℤ) := by
        simp only [r2E, nEqE, iE, evalVal_add, evalVal_readHeap, evalVal_lit, hDim_ws.2.1, hctr_i]
        push_cast; ring
      obtain ⟨ws', hpr_r, hd_r, hM_r, hex_r⟩ := exec_writeOracleRowStmt hctx h64
        ⟨hIdx.1, hIdx.2.2.2.1, hIdx.2.2.2.2⟩ hr_lt hi r2E iE (by decide) (by decide)
        (by decide) (by decide)
        (fun _ _ h1 _ h42 => by simp [r2E, nEqE, iE, h1, h42]) (fun _ _ h42 => by simp [iE, h42])
        (by omega) (by omega) (-1) (Or.inr rfl) false M_eq d_eq hMeqB hdeqB hws
        hDim_ws.1 hDim_ws.2.2.2.1 hr2_val (by simp [iE, hctr_i])
        (fun j => hCl_ws.1 ⟨i, hi⟩ j) (hCl_ws.2.1 ⟨i, hi⟩)
      refine ⟨ws', hex_r, ?_, ?_⟩
      · rw [hpr_r 10 42 (by omega), hctr_i]
      · refine ⟨(hpr.trans (hpr_r.mono (by intro t idx h; dsimp [mod]; omega))).trans
            (PreservesOutside.write ws' _ (by dsimp [mod]; omega)),
          fun r hr' j => ?_, fun r hr' => ?_⟩
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < nEq + i ∨ r.val = nEq + i by omega) with hlt | heq
          · have hlt_idx : r.val * (nVars + 2) + j.val < (nEq + i) * (nVars + 2) := by
              calc r.val * (nVars + 2) + j.val < r.val * (nVars + 2) + (nVars + 2) :=
                    Nat.add_lt_add_left j.isLt _
                _ = (r.val + 1) * (nVars + 2) := by ring
                _ ≤ (nEq + i) * (nVars + 2) := Nat.mul_le_mul_right _ hlt
            dsimp only [N]
            rw [hpr_r 24 _ (by omega)]; exact hrm_M r hlt j
          · dsimp only [N] at j ⊢
            rw [heq, hM_r j]
            dsimp only [padCols]
            by_cases hj : j.val < nVars
            · rw [dif_pos hj, dif_pos hj]
              have hr1 : ¬ (r.val < nEq) := by omega
              have hr2 : r.val - nEq < nEq := by omega
              have hsub : (⟨r.val - nEq, hr2⟩ : Fin nEq) = ⟨i, hi⟩ := by ext; dsimp only; omega
              dsimp only [buildOracleM]
              rw [dif_neg hr1, dif_pos hr2]
              simp [hsub]
            · rw [dif_neg hj, dif_neg hj]
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < nEq + i ∨ r.val = nEq + i by omega) with hlt | heq
          · rw [hpr_r 25 _ (by omega)]; exact hrm_D r hlt
          · rw [heq, hd_r]
            have hr1 : ¬ (r.val < nEq) := by omega
            have hr2 : r.val - nEq < nEq := by omega
            have hsub : (⟨r.val - nEq, hr2⟩ : Fin nEq) = ⟨i, hi⟩ := by ext; dsimp only; omega
            dsimp only [buildOracleD]
            rw [dif_neg hr1, dif_pos hr2]
            simp [hsub])
  -- Loop 3: 2 * nEq .. 2 * nEq + nLe - 1
  let Inv3 : ℕ → UL.WordStore → Prop := fun k ws =>
    PreservesOutside mod ws₀ ws ∧ RowsMatch (2 * nEq + k) ws
  have hInv3_0 : Inv3 0 (hWrite ws2 10 42 0) := by
    have h2eq : nEq + nEq = 2 * nEq := by ring
    refine ⟨hpr2.trans (PreservesOutside.write ws2 0 (by dsimp [mod]; omega)), ?_, ?_⟩
    · intro r hr j; rw [hRead_hWrite_of_ne ws2 0 (Or.inl (by omega))]; exact hRM2.1 r (by omega) j
    · intro r hr; rw [hRead_hWrite_of_ne ws2 0 (Or.inl (by omega))]; exact hRM2.2 r (by omega)
  have hcnt3 : evalVal inp (hWrite ws2 10 42 0) nLeE = (nLe : ℤ) := by
    simp only [nLeE, evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws2 0 (Or.inr (by omega)), hpr2 10 2 (by dsimp [mod]; omega), hDims.2.2.1]
  obtain ⟨ws3, _, ⟨hpr3, hRM3⟩, hex3⟩ := exec_for hctx 42 nLeE
    (writeOracleRowStmt r3E iE 21 22 1 false) nLe (5 + 2 * nVars) Inv3 hex2.2.1 (by omega) hIdx.2.2.1
    hcnt3 hInv3_0
    (fun k hk ws hws hctr_k ⟨hpr, hrm_M, hrm_D⟩ => by
      have hr_lt : 2 * nEq + k < m_ora := by dsimp [m_ora]; omega
      have hDim_ws := hDims.preserve hpr (by intro idx _ _; dsimp [mod]; omega)
      have hCl_ws := hCleared.preserve hpr (by intro t idx h1 h2; dsimp [mod]; omega)
      have hr3_val : evalVal inp ws r3E = ((2 * nEq + k : ℕ) : ℤ) := by
        simp only [r3E, nEqE, iE, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hDim_ws.2.1, hctr_k]
        push_cast; ring
      obtain ⟨ws', hpr_r, hd_r, hM_r, hex_r⟩ := exec_writeOracleRowStmt hctx h64
        ⟨hIdx.1, hIdx.2.2.2.1, hIdx.2.2.2.2⟩ hr_lt hk r3E iE (by decide) (by decide)
        (by decide) (by decide)
        (fun _ _ h1 _ h42 => by simp [r3E, nEqE, iE, h1, h42]) (fun _ _ h42 => by simp [iE, h42])
        (by omega) (by omega) 1 (Or.inl rfl) false M_le d_le hMleB hdleB hws
        hDim_ws.1 hDim_ws.2.2.2.1 hr3_val (by simp [iE, hctr_k])
        (fun j => hCl_ws.2.2.1 ⟨k, hk⟩ j) (hCl_ws.2.2.2 ⟨k, hk⟩)
      refine ⟨ws', hex_r, ?_, ?_⟩
      · rw [hpr_r 10 42 (by omega), hctr_k]
      · refine ⟨(hpr.trans (hpr_r.mono (by intro t idx h; dsimp [mod]; omega))).trans
            (PreservesOutside.write ws' _ (by dsimp [mod]; omega)),
          fun r hr' j => ?_, fun r hr' => ?_⟩
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < 2 * nEq + k ∨ r.val = 2 * nEq + k by omega) with hlt | heq
          · have hlt_idx : r.val * (nVars + 2) + j.val < (2 * nEq + k) * (nVars + 2) := by
              calc r.val * (nVars + 2) + j.val < r.val * (nVars + 2) + (nVars + 2) :=
                    Nat.add_lt_add_left j.isLt _
                _ = (r.val + 1) * (nVars + 2) := by ring
                _ ≤ (2 * nEq + k) * (nVars + 2) := Nat.mul_le_mul_right _ hlt
            dsimp only [N]
            rw [hpr_r 24 _ (by omega)]; exact hrm_M r hlt j
          · dsimp only [N] at j ⊢
            rw [heq, hM_r j]
            dsimp only [padCols]
            by_cases hj : j.val < nVars
            · rw [dif_pos hj, dif_pos hj]
              have hr1 : ¬ (r.val < nEq) := by omega
              have hr2 : ¬ (r.val - nEq < nEq) := by omega
              have hr3 : r.val - 2 * nEq < nLe := by omega
              have hsub : (⟨r.val - 2 * nEq, hr3⟩ : Fin nLe) = ⟨k, hk⟩ := by ext; dsimp only; omega
              dsimp only [buildOracleM]
              rw [dif_neg hr1, dif_neg hr2, dif_pos hr3]
              simp [hsub]
            · rw [dif_neg hj, dif_neg hj]
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < 2 * nEq + k ∨ r.val = 2 * nEq + k by omega) with hlt | heq
          · rw [hpr_r 25 _ (by omega)]; exact hrm_D r hlt
          · rw [heq, hd_r]
            have hr1 : ¬ (r.val < nEq) := by omega
            have hr2 : ¬ (r.val - nEq < nEq) := by omega
            have hr3 : r.val - 2 * nEq < nLe := by omega
            have hsub : (⟨r.val - 2 * nEq, hr3⟩ : Fin nLe) = ⟨k, hk⟩ := by ext; dsimp only; omega
            dsimp only [buildOracleD]
            rw [dif_neg hr1, dif_neg hr2, dif_pos hr3]
            simp [hsub])
  -- Loop 4: 2 * nEq + nLe .. 2 * nEq + 2 * nLe - 1
  let Inv4 : ℕ → UL.WordStore → Prop := fun k ws =>
    PreservesOutside mod ws₀ ws ∧ RowsMatch (2 * nEq + nLe + k) ws
  have hInv4_0 : Inv4 0 (hWrite ws3 10 42 0) := by
    refine ⟨hpr3.trans (PreservesOutside.write ws3 0 (by dsimp [mod]; omega)), ?_, ?_⟩
    · intro r hr j; rw [hRead_hWrite_of_ne ws3 0 (Or.inl (by omega))]; exact hRM3.1 r (by omega) j
    · intro r hr; rw [hRead_hWrite_of_ne ws3 0 (Or.inl (by omega))]; exact hRM3.2 r (by omega)
  have hcnt4 : evalVal inp (hWrite ws3 10 42 0) nLeE = (nLe : ℤ) := by
    simp only [nLeE, evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws3 0 (Or.inr (by omega)), hpr3 10 2 (by dsimp [mod]; omega), hDims.2.2.1]
  obtain ⟨ws4, _, ⟨hpr4, hRM4⟩, hex4⟩ := exec_for hctx 42 nLeE
    (.ite (.intEq (.readHeap 23 (.add actOffE iE)) (.lit 1))
      (writeOracleRowStmt r4E iE 21 22 (-1) false)
      (writeOracleRowStmt r4E iE 21 22 1 true))
    nLe (6 + 2 * nVars) Inv4 hex3.2.1 (by omega) hIdx.2.2.1 hcnt4 hInv4_0
    (fun k hk ws hws hctr_k ⟨hpr, hrm_M, hrm_D⟩ => by
      have hr_lt : 2 * nEq + nLe + k < m_ora := by dsimp [m_ora]; omega
      have hDim_ws := hDims.preserve hpr (by intro idx _ _; dsimp [mod]; omega)
      have hCl_ws := hCleared.preserve hpr (by intro t idx h1 h2; dsimp [mod]; omega)
      have hr4_val : evalVal inp ws r4E = ((2 * nEq + nLe + k : ℕ) : ℤ) := by
        simp only [r4E, nEqE, nLeE, iE, evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit,
          hDim_ws.2.1, hDim_ws.2.2.1, hctr_k]
        push_cast; ring
      have hoff_ws : evalVal inp ws actOffE = (actOff : ℤ) := by
        rw [hdep_off ws ws₀ (hpr 10 2 (by dsimp [mod]; omega)), hoff_val]
      have hact_ws : hRead ws 23 ((actOff + k : ℕ) : ℤ) = if act ⟨k, hk⟩ then 1 else 0 := by
        rw [hpr 23 _ (by dsimp [mod]; omega)]
        exact hAct_ws ⟨k, hk⟩
      have hcond_eq : evalCondVal inp ws (.intEq (.readHeap 23 (.add actOffE iE)) (.lit 1)) =
          act ⟨k, hk⟩ := by
        have hidx : (actOff : ℤ) + (k : ℤ) = ((actOff + k : ℕ) : ℤ) := by push_cast; ring
        simp only [evalCondVal_intEq, evalVal_readHeap, evalVal_add, evalVal_lit, iE,
          hoff_ws, hctr_k, hidx, hact_ws]
        cases act ⟨k, hk⟩ <;> rfl
      have hwf_c : condWf 31 (.intEq (.readHeap 23 (.add actOffE iE)) (.lit 1)) = true := by
        simp [condWf, exprWf, hwf_off, iE]
      have hsz_c : condNodes (.intEq (.readHeap 23 (.add actOffE iE)) (.lit 1)) ≤ 64 ∧
          condLeaves (.intEq (.readHeap 23 (.add actOffE iE)) (.lit 1)) ≤ 64 := by
        dsimp [condNodes, condLeaves, exprNodes, exprLeaves, iE]; omega
      cases hact_b : act ⟨k, hk⟩
      · -- inactive: zeroRow = true
        obtain ⟨ws', hpr_r, hd_r, hM_r, hex_r⟩ := exec_writeOracleRowStmt hctx h64
          ⟨hIdx.1, hIdx.2.2.2.1, hIdx.2.2.2.2⟩ hr_lt hk r4E iE (by decide) (by decide)
          (by decide) (by decide)
          (fun _ _ h1 h2 h42 => by simp [r4E, nEqE, nLeE, iE, h1, h2, h42])
          (fun _ _ h42 => by simp [iE, h42])
          (by omega) (by omega) 1 (Or.inl rfl) true M_le d_le hMleB hdleB hws
          hDim_ws.1 hDim_ws.2.2.2.1 hr4_val (by simp [iE, hctr_k])
          (fun j => hCl_ws.2.2.1 ⟨k, hk⟩ j) (hCl_ws.2.2.2 ⟨k, hk⟩)
        have hite := exec_ite_false hctx (.intEq (.readHeap 23 (.add actOffE iE)) (.lit 1))
          (writeOracleRowStmt r4E iE 21 22 (-1) false)
          (writeOracleRowStmt r4E iE 21 22 1 true)
          (by rw [hcond_eq, hact_b]) hex_r hwf_c hsz_c
        refine ⟨ws', hite.mono_steps (by omega), by rw [hpr_r 10 42 (by omega), hctr_k], ?_⟩
        refine ⟨(hpr.trans (hpr_r.mono (by intro t idx h; dsimp [mod]; omega))).trans
            (PreservesOutside.write ws' _ (by dsimp [mod]; omega)),
          fun r hr' j => ?_, fun r hr' => ?_⟩
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < 2 * nEq + nLe + k ∨ r.val = 2 * nEq + nLe + k by omega) with hlt | heq
          · have hlt_idx : r.val * (nVars + 2) + j.val < (2 * nEq + nLe + k) * (nVars + 2) := by
              calc r.val * (nVars + 2) + j.val < r.val * (nVars + 2) + (nVars + 2) :=
                    Nat.add_lt_add_left j.isLt _
                _ = (r.val + 1) * (nVars + 2) := by ring
                _ ≤ (2 * nEq + nLe + k) * (nVars + 2) := Nat.mul_le_mul_right _ hlt
            dsimp only [N]
            rw [hpr_r 24 _ (by omega)]; exact hrm_M r hlt j
          · dsimp only [N] at j ⊢
            rw [heq, hM_r j]
            dsimp only [padCols]
            by_cases hj : j.val < nVars
            · rw [dif_pos hj, dif_pos hj]
              have hr1 : ¬ (r.val < nEq) := by omega
              have hr2 : ¬ (r.val - nEq < nEq) := by omega
              have hr3 : ¬ (r.val - 2 * nEq < nLe) := by omega
              have hsub : (⟨r.val - (2 * nEq + nLe), by dsimp [m_ora] at r; omega⟩ : Fin nLe) = ⟨k, hk⟩ := by
                ext; dsimp only; omega
              dsimp only [buildOracleM]
              rw [dif_neg hr1, dif_neg hr2, dif_neg hr3]
              simp [hsub, hact_b]
            · rw [dif_neg hj, dif_neg hj]
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < 2 * nEq + nLe + k ∨ r.val = 2 * nEq + nLe + k by omega) with hlt | heq
          · rw [hpr_r 25 _ (by omega)]; exact hrm_D r hlt
          · rw [heq, hd_r]
            have hr1 : ¬ (r.val < nEq) := by omega
            have hr2 : ¬ (r.val - nEq < nEq) := by omega
            have hr3 : ¬ (r.val - 2 * nEq < nLe) := by omega
            have hsub : (⟨r.val - (2 * nEq + nLe), by dsimp [m_ora] at r; omega⟩ : Fin nLe) = ⟨k, hk⟩ := by
              ext; dsimp only; omega
            dsimp only [buildOracleD]
            rw [dif_neg hr1, dif_neg hr2, dif_neg hr3]
            simp [hsub, hact_b]
      · -- active: sgn = -1, zeroRow = false
        obtain ⟨ws', hpr_r, hd_r, hM_r, hex_r⟩ := exec_writeOracleRowStmt hctx h64
          ⟨hIdx.1, hIdx.2.2.2.1, hIdx.2.2.2.2⟩ hr_lt hk r4E iE (by decide) (by decide)
          (by decide) (by decide)
          (fun _ _ h1 h2 h42 => by simp [r4E, nEqE, nLeE, iE, h1, h2, h42])
          (fun _ _ h42 => by simp [iE, h42])
          (by omega) (by omega) (-1) (Or.inr rfl) false M_le d_le hMleB hdleB hws
          hDim_ws.1 hDim_ws.2.2.2.1 hr4_val (by simp [iE, hctr_k])
          (fun j => hCl_ws.2.2.1 ⟨k, hk⟩ j) (hCl_ws.2.2.2 ⟨k, hk⟩)
        have hite := exec_ite_true hctx (.intEq (.readHeap 23 (.add actOffE iE)) (.lit 1))
          (writeOracleRowStmt r4E iE 21 22 (-1) false)
          (writeOracleRowStmt r4E iE 21 22 1 true)
          (by rw [hcond_eq, hact_b]) hex_r hwf_c hsz_c
        refine ⟨ws', hite.mono_steps (by omega), by rw [hpr_r 10 42 (by omega), hctr_k], ?_⟩
        refine ⟨(hpr.trans (hpr_r.mono (by intro t idx h; dsimp [mod]; omega))).trans
            (PreservesOutside.write ws' _ (by dsimp [mod]; omega)),
          fun r hr' j => ?_, fun r hr' => ?_⟩
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < 2 * nEq + nLe + k ∨ r.val = 2 * nEq + nLe + k by omega) with hlt | heq
          · have hlt_idx : r.val * (nVars + 2) + j.val < (2 * nEq + nLe + k) * (nVars + 2) := by
              calc r.val * (nVars + 2) + j.val < r.val * (nVars + 2) + (nVars + 2) :=
                    Nat.add_lt_add_left j.isLt _
                _ = (r.val + 1) * (nVars + 2) := by ring
                _ ≤ (2 * nEq + nLe + k) * (nVars + 2) := Nat.mul_le_mul_right _ hlt
            dsimp only [N]
            rw [hpr_r 24 _ (by omega)]; exact hrm_M r hlt j
          · dsimp only [N] at j ⊢
            rw [heq, hM_r j]
            dsimp only [padCols]
            by_cases hj : j.val < nVars
            · rw [dif_pos hj, dif_pos hj]
              have hr1 : ¬ (r.val < nEq) := by omega
              have hr2 : ¬ (r.val - nEq < nEq) := by omega
              have hr3 : ¬ (r.val - 2 * nEq < nLe) := by omega
              have hsub : (⟨r.val - (2 * nEq + nLe), by dsimp [m_ora] at r; omega⟩ : Fin nLe) = ⟨k, hk⟩ := by
                ext; dsimp only; omega
              dsimp only [buildOracleM]
              rw [dif_neg hr1, dif_neg hr2, dif_neg hr3]
              simp [hsub, hact_b]
            · rw [dif_neg hj, dif_neg hj]
        · rw [hRead_hWrite_of_ne ws' _ (Or.inl (by omega))]
          rcases (show r.val < 2 * nEq + nLe + k ∨ r.val = 2 * nEq + nLe + k by omega) with hlt | heq
          · rw [hpr_r 25 _ (by omega)]; exact hrm_D r hlt
          · rw [heq, hd_r]
            have hr1 : ¬ (r.val < nEq) := by omega
            have hr2 : ¬ (r.val - nEq < nEq) := by omega
            have hr3 : ¬ (r.val - 2 * nEq < nLe) := by omega
            have hsub : (⟨r.val - (2 * nEq + nLe), by dsimp [m_ora] at r; omega⟩ : Fin nLe) = ⟨k, hk⟩ := by
              ext; dsimp only; omega
            dsimp only [buildOracleD]
            rw [dif_neg hr1, dif_neg hr2, dif_neg hr3]
            simp [hsub, hact_b])
  have hm_eq : 2 * nEq + nLe + nLe = m_ora := by dsimp [m_ora]; omega
  rw [hm_eq] at hRM4
  have htot : ExecBit inp maxIdx K (buildOracleStmt actOffE) ws₀ ws4
      ((10 + m_ora * (8 + 2 * nVars)) * stepU) ((10 + m_ora * (8 + 2 * nVars)) * stepB K) := by
    have hc := hex1.seq_steps (hex2.seq_steps (hex3.seq_steps hex4))
    refine hc.mono_steps ?_
    dsimp [m_ora]
    have h1 : (2 + nEq * (5 + 2 * nVars + 1)) +
        ((2 + nEq * (5 + 2 * nVars + 1)) +
          ((2 + nLe * (5 + 2 * nVars + 1)) + (2 + nLe * (6 + 2 * nVars + 1)))) ≤
        10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars) := by
      have hEq1 : nEq * (5 + 2 * nVars + 1) ≤ nEq * (8 + 2 * nVars) := Nat.mul_le_mul_left _ (by omega)
      have hLe1 : nLe * (5 + 2 * nVars + 1) ≤ nLe * (8 + 2 * nVars) := Nat.mul_le_mul_left _ (by omega)
      have hLe2 : nLe * (6 + 2 * nVars + 1) ≤ nLe * (8 + 2 * nVars) := Nat.mul_le_mul_left _ (by omega)
      calc (2 + nEq * (5 + 2 * nVars + 1)) +
            ((2 + nEq * (5 + 2 * nVars + 1)) +
              ((2 + nLe * (5 + 2 * nVars + 1)) + (2 + nLe * (6 + 2 * nVars + 1))))
          ≤ (2 + nEq * (8 + 2 * nVars)) +
            ((2 + nEq * (8 + 2 * nVars)) +
              ((2 + nLe * (8 + 2 * nVars)) + (2 + nLe * (8 + 2 * nVars)))) := by omega
        _ = 8 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars) := by ring
        _ ≤ 10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars) := by omega
    exact h1
  exact ⟨ws4, hpr4, fun r j => hRM4.1 r r.isLt j, fun r => hRM4.2 r r.isLt, htot⟩

end UL.Proof.cit_gls88_rational_lp.RacerCG
