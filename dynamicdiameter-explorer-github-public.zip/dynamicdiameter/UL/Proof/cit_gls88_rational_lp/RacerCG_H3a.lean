import Mathlib
import UL.Def.def_computation_model
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

/-! ### 1. Binary Encoding Length & Rational Reduction Lemmas -/

theorem natBitLength_mono {a b : ℕ} (h : a ≤ b) :
    UL.natBitLength a ≤ UL.natBitLength b := by
  unfold UL.natBitLength
  exact Nat.add_le_add_right (Nat.log_mono_right h) 1

theorem nat_le_two_pow_of_natBitLength_le {m B : ℕ} (h : UL.natBitLength m ≤ B) :
    m ≤ 2 ^ B := by
  by_cases hm : m = 0
  · subst hm; exact Nat.zero_le _
  · unfold UL.natBitLength at h
    have hlt : Nat.log 2 m < B := by omega
    exact ((Nat.log_lt_iff_lt_pow (by decide : 1 < 2) hm).mp hlt).le

theorem natBitLength_le_of_le_two_pow {m K : ℕ} (h : m ≤ 2 ^ K) :
    UL.natBitLength m ≤ K + 2 := by
  by_cases hm : m = 0
  · subst hm; unfold UL.natBitLength; simp
  · unfold UL.natBitLength
    have hlt : m < 2 ^ (K + 1) := by
      have hpow : 2 ^ K < 2 ^ (K + 1) :=
        Nat.pow_lt_pow_right (by decide : 1 < 2) (Nat.lt_succ_self K)
      exact lt_of_le_of_lt h hpow
    have hlog : Nat.log 2 m < K + 1 :=
      (Nat.log_lt_iff_lt_pow (by decide : 1 < 2) hm).mpr hlt
    omega

theorem intBitLength_le_of_natAbs_le_two_pow {z : ℤ} {K : ℕ} (h : z.natAbs ≤ 2 ^ K) :
    UL.intBitLength z ≤ K + 3 := by
  unfold UL.intBitLength
  split_ifs with hz
  · omega
  · have hn := natBitLength_le_of_le_two_pow h
    omega

theorem ratCoordBitBounded_imp_natAbs_le {B : ℕ} {q : ℚ} (hq : UL.RatCoordBitBounded B q) :
    q.num.natAbs ≤ 2 ^ (max B 1) ∧ q.den ≤ 2 ^ (max B 1) ∧
    UL.intBitLength q.num ≤ max B 1 + 3 ∧
    UL.intBitLength (q.den : ℤ) ≤ max B 1 + 3 ∧
    UL.ratBitLength q ≤ 2 * max B 1 + 5 := by
  have hB : B ≤ max B 1 := le_max_left B 1
  have hnum_le : q.num.natAbs ≤ 2 ^ (max B 1) :=
    nat_le_two_pow_of_natBitLength_le (hq.1.trans hB)
  have hden_le : q.den ≤ 2 ^ (max B 1) :=
    nat_le_two_pow_of_natBitLength_le (hq.2.trans hB)
  have h1 : UL.intBitLength q.num ≤ max B 1 + 3 :=
    intBitLength_le_of_natAbs_le_two_pow hnum_le
  have h2 : UL.intBitLength (q.den : ℤ) ≤ max B 1 + 3 :=
    intBitLength_le_of_natAbs_le_two_pow (by simpa using hden_le)
  have h3 : UL.natBitLength q.den ≤ max B 1 + 2 :=
    natBitLength_le_of_le_two_pow hden_le
  refine ⟨hnum_le, hden_le, h1, h2, ?_⟩
  unfold UL.ratBitLength
  omega

theorem rat_div_bit_bounds {num den : ℤ} {K bound : ℕ}
    (hden_pos : 0 < den)
    (hnum : num.natAbs ≤ 2 ^ K)
    (hden : den.natAbs ≤ 2 ^ K)
    (hbound : 2 * K + 5 ≤ bound) :
    let q : ℚ := (num : ℚ) / (den : ℚ)
    UL.intBitLength num ≤ bound ∧
    UL.intBitLength den ≤ bound ∧
    UL.RatCoordBitBounded bound q ∧
    UL.ratBitLength q ≤ bound := by
  intro q
  have hden_neQ : (den : ℚ) ≠ 0 := by exact_mod_cast hden_pos.ne'
  have hqd_neQ : (q.den : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr q.pos.ne'
  have h1 : ((q.num : ℚ) / (q.den : ℚ)) * (den : ℚ) = (num : ℚ) := by
    rw [Rat.num_div_den]
    exact div_mul_cancel₀ _ hden_neQ
  have h2 : (q.num : ℚ) * (den : ℚ) = (num : ℚ) * (q.den : ℚ) := by
    calc (q.num : ℚ) * (den : ℚ)
        = (((q.num : ℚ) / (q.den : ℚ)) * (q.den : ℚ)) * (den : ℚ) := by
            rw [div_mul_cancel₀ _ hqd_neQ]
      _ = (((q.num : ℚ) / (q.den : ℚ)) * (den : ℚ)) * (q.den : ℚ) := by ring
      _ = (num : ℚ) * (q.den : ℚ) := by rw [h1]
  have hZ : q.num * den = num * (q.den : ℤ) := by exact_mod_cast h2
  have hN : q.num.natAbs * den.natAbs = num.natAbs * q.den := by
    have := congrArg Int.natAbs hZ
    simpa [Int.natAbs_mul] using this
  have hdvd_prod : q.den ∣ q.num.natAbs * den.natAbs :=
    ⟨num.natAbs, by linarith⟩
  have hden_dvd : q.den ∣ den.natAbs :=
    q.reduced.symm.dvd_of_dvd_mul_left hdvd_prod
  have hden_abs_pos : 0 < den.natAbs := Int.natAbs_pos.mpr hden_pos.ne'
  have hqden_le : q.den ≤ den.natAbs := Nat.le_of_dvd hden_abs_pos hden_dvd
  have hqnum_le : q.num.natAbs ≤ num.natAbs := by
    apply Nat.le_of_mul_le_mul_right _ hden_abs_pos
    rw [hN]
    exact Nat.mul_le_mul_left _ hqden_le
  have hb_num : UL.intBitLength num ≤ K + 3 := intBitLength_le_of_natAbs_le_two_pow hnum
  have hb_den : UL.intBitLength den ≤ K + 3 := intBitLength_le_of_natAbs_le_two_pow hden
  have hqn_b : UL.natBitLength q.num.natAbs ≤ K + 2 :=
    natBitLength_le_of_le_two_pow (hqnum_le.trans hnum)
  have hqd_b : UL.natBitLength q.den ≤ K + 2 :=
    natBitLength_le_of_le_two_pow (hqden_le.trans hden)
  have hqn_int : UL.intBitLength q.num ≤ K + 3 :=
    intBitLength_le_of_natAbs_le_two_pow (hqnum_le.trans hnum)
  refine ⟨by omega, by omega, ⟨by omega, by omega⟩, ?_⟩
  unfold UL.ratBitLength
  omega

theorem list_sum_le_length_mul {xs : List ℕ} {M : ℕ} (h : ∀ x ∈ xs, x ≤ M) :
    xs.sum ≤ xs.length * M := by
  induction xs with
  | nil => simp
  | cons x xs ih =>
      simp only [List.sum_cons, List.length_cons]
      have hx : x ≤ M := h x List.mem_cons_self
      have hxs : xs.sum ≤ xs.length * M := ih (fun y hy => h y (List.mem_cons_of_mem x hy))
      calc x + xs.sum ≤ M + xs.length * M := Nat.add_le_add hx hxs
        _ = (xs.length + 1) * M := by ring

/-! ### 2. Clean Heap `WordStore` & Bounded Cell Invariants -/

def CleanWords (ws : UL.WordStore) : Prop :=
  ws.popDepth 0 = ws

theorem cleanWords_empty : CleanWords UL.WordStore.empty := by
  unfold CleanWords UL.WordStore.popDepth UL.WordStore.empty
  simp

theorem cleanWords_write_heap {ws : UL.WordStore} (h : CleanWords ws) (t : ℕ) (i : ℤ) (v : ℤ) :
    CleanWords (ws.write (.heap t i) v) := by
  unfold CleanWords at h ⊢
  have hlive : (ws.popDepth 0).live = ws.live := congrArg UL.WordStore.live h
  have hvals : (ws.popDepth 0).vals = ws.vals := congrArg UL.WordStore.vals h
  cases ws with
  | mk live vals =>
    simp only [UL.WordStore.popDepth] at hlive hvals
    unfold UL.WordStore.write UL.WordStore.popDepth
    congr 1
    · ext loc
      simp only [Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨rfl | hmem, _⟩
        · exact Or.inl rfl
        · exact Or.inr hmem
      · rintro (rfl | hmem)
        · exact ⟨Or.inl rfl, rfl⟩
        · have hmem' : loc ∈ Finset.filter (fun l => l.keepAtDepth 0 = true) live := by
            rw [hlive]; exact hmem
          exact ⟨Or.inr hmem, (Finset.mem_filter.mp hmem').2⟩
    · funext loc
      by_cases heq : loc = .heap t i
      · subst heq; simp [UL.RAMCellLoc.keepAtDepth]
      · have hv := congrFun hvals loc
        simp [Function.update, heq] at hv ⊢
        exact hv

def hRead (ws : UL.WordStore) (t : ℕ) (i : ℤ) : ℤ :=
  ws.read (.heap t i)

def hWrite (ws : UL.WordStore) (t : ℕ) (i : ℤ) (v : ℤ) : UL.WordStore :=
  ws.write (.heap t i) v

@[simp] theorem hRead_empty (t : ℕ) (i : ℤ) : hRead UL.WordStore.empty t i = 0 := by
  simp [hRead, UL.WordStore.empty, UL.WordStore.read]

@[simp] theorem hRead_hWrite_self (ws : UL.WordStore) (t : ℕ) (i : ℤ) (v : ℤ) :
    hRead (hWrite ws t i v) t i = v := by
  simp [hRead, hWrite, UL.WordStore.read, UL.WordStore.write]

theorem hRead_hWrite_of_ne (ws : UL.WordStore) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℤ)
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    hRead (hWrite ws t₂ i₂ v) t₁ i₁ = hRead ws t₁ i₁ := by
  have hloc : (UL.RAMCellLoc.heap t₁ i₁) ≠ (UL.RAMCellLoc.heap t₂ i₂) := by
    intro h
    cases h
    rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [hRead, hWrite, UL.WordStore.read, UL.WordStore.write, hloc]

def allowedHeapCells (maxT maxIdx : ℕ) : Finset UL.RAMCellLoc :=
  (Finset.range (maxT + 1)).biUnion (fun t : ℕ =>
    (Finset.range (maxIdx + 1)).image (fun i : ℕ => UL.RAMCellLoc.heap t (i : ℤ)))

theorem mem_allowedHeapCells {maxT maxIdx t : ℕ} {idx : ℤ}
    (ht : t ≤ maxT) (hi0 : 0 ≤ idx) (hi1 : idx ≤ (maxIdx : ℤ)) :
    UL.RAMCellLoc.heap t idx ∈ allowedHeapCells maxT maxIdx := by
  unfold allowedHeapCells
  rw [Finset.mem_biUnion]
  refine ⟨t, Finset.mem_range.mpr (by omega), ?_⟩
  rw [Finset.mem_image]
  refine ⟨idx.toNat, Finset.mem_range.mpr (by omega), ?_⟩
  rw [Int.toNat_of_nonneg hi0]

theorem card_allowedHeapCells_le (maxT maxIdx : ℕ) :
    (allowedHeapCells maxT maxIdx).card ≤ (maxT + 1) * (maxIdx + 1) := by
  unfold allowedHeapCells
  calc ((Finset.range (maxT + 1)).biUnion _).card
      ≤ ∑ t ∈ Finset.range (maxT + 1),
          ((Finset.range (maxIdx + 1)).image (fun i : ℕ => UL.RAMCellLoc.heap t (i : ℤ))).card :=
        Finset.card_biUnion_le
    _ ≤ ∑ _t ∈ Finset.range (maxT + 1), (maxIdx + 1) := by
        refine Finset.sum_le_sum (fun t _ => ?_)
        exact Finset.card_image_le.trans (by simp)
    _ = (maxT + 1) * (maxIdx + 1) := by simp

theorem bitLength_of_mem_allowedHeapCells {maxT maxIdx : ℕ} {loc : UL.RAMCellLoc}
    (hmem : loc ∈ allowedHeapCells maxT maxIdx) :
    loc.bitLength ≤ UL.natBitLength maxT + UL.intBitLength (maxIdx : ℤ) + 2 := by
  unfold allowedHeapCells at hmem
  rw [Finset.mem_biUnion] at hmem
  rcases hmem with ⟨t, ht, himg⟩
  rw [Finset.mem_range] at ht
  rw [Finset.mem_image] at himg
  rcases himg with ⟨i, hi, rfl⟩
  rw [Finset.mem_range] at hi
  dsimp only [UL.RAMCellLoc.bitLength]
  have ht_b : UL.natBitLength t ≤ UL.natBitLength maxT := natBitLength_mono (by omega)
  have hi_b : UL.intBitLength (i : ℤ) ≤ UL.intBitLength (maxIdx : ℤ) + 2 := by
    by_cases hi0 : i = 0
    · subst hi0; unfold UL.intBitLength; simp
    · have hm0 : maxIdx ≠ 0 := by omega
      unfold UL.intBitLength
      have h1 : (i : ℤ) ≠ 0 := by omega
      have h2 : (maxIdx : ℤ) ≠ 0 := by omega
      rw [if_neg h1, if_neg h2]
      have hmono : UL.natBitLength i ≤ UL.natBitLength maxIdx := natBitLength_mono (by omega)
      exact (Nat.add_le_add_left hmono 1).trans (Nat.le_add_right _ 2)
  omega

/-- Combined store invariant: clean heap-only store, live cells within `[0..maxT] × [0..maxIdx]`,
and all stored integer magnitudes bounded by `2 ^ K`. -/
def StoreBounded (maxT maxIdx K : ℕ) (ws : UL.WordStore) : Prop :=
  CleanWords ws ∧
  ws.live ⊆ allowedHeapCells maxT maxIdx ∧
  (∀ loc ∈ ws.live, (ws.vals loc).natAbs ≤ 2 ^ K)

theorem storeBounded_empty (maxT maxIdx K : ℕ) :
    StoreBounded maxT maxIdx K UL.WordStore.empty :=
  ⟨cleanWords_empty, Finset.empty_subset _, fun _ h => by simp [UL.WordStore.empty] at h⟩

theorem storeBounded_read_abs {maxT maxIdx K : ℕ} {ws : UL.WordStore}
    (hws : StoreBounded maxT maxIdx K ws) (loc : UL.RAMCellLoc) :
    (ws.read loc).natAbs ≤ 2 ^ K := by
  unfold UL.WordStore.read
  split_ifs with hmem
  · exact hws.2.2 loc hmem
  · simp

theorem storeBounded_write {maxT maxIdx K t : ℕ} {idx val : ℤ} {ws : UL.WordStore}
    (hws : StoreBounded maxT maxIdx K ws)
    (ht : t ≤ maxT) (hi0 : 0 ≤ idx) (hi1 : idx ≤ (maxIdx : ℤ))
    (hval : val.natAbs ≤ 2 ^ K) :
    StoreBounded maxT maxIdx K (hWrite ws t idx val) := by
  refine ⟨cleanWords_write_heap hws.1 t idx val, ?_, ?_⟩
  · intro loc hmem
    simp only [hWrite, UL.WordStore.write, Finset.mem_insert] at hmem
    rcases hmem with rfl | hmem'
    · exact mem_allowedHeapCells ht hi0 hi1
    · exact hws.2.1 hmem'
  · intro loc hmem
    simp only [hWrite, UL.WordStore.write, Finset.mem_insert] at hmem
    by_cases heq : loc = .heap t idx
    · subst heq
      simp [hWrite, UL.WordStore.write, hval]
    · rcases hmem with rfl | hmem'
      · exact absurd rfl heq
      · simp [hWrite, UL.WordStore.write, Function.update, heq, hws.2.2 loc hmem']

theorem storeBounded_space_le {maxT maxIdx K : ℕ} {ws : UL.WordStore}
    (hws : StoreBounded maxT maxIdx K ws)
    (hmaxIdx : maxIdx ≤ 2 ^ K) :
    ws.cellCount ≤ (maxT + 1) * (maxIdx + 1) ∧
    ws.bitSize ≤ (maxT + 1) * (maxIdx + 1) * (UL.natBitLength maxT + 2 * K + 8) := by
  have hcard : ws.live.card ≤ (maxT + 1) * (maxIdx + 1) :=
    (Finset.card_le_card hws.2.1).trans (card_allowedHeapCells_le maxT maxIdx)
  refine ⟨hcard, ?_⟩
  unfold UL.WordStore.bitSize
  have hmaxIdx_b : UL.intBitLength (maxIdx : ℤ) ≤ K + 3 :=
    intBitLength_le_of_natAbs_le_two_pow (by simpa using hmaxIdx)
  calc ∑ loc ∈ ws.live, (loc.bitLength + UL.intBitLength (ws.vals loc))
      ≤ ∑ _loc ∈ ws.live, (UL.natBitLength maxT + 2 * K + 8) := by
        refine Finset.sum_le_sum (fun loc hmem => ?_)
        have hloc := bitLength_of_mem_allowedHeapCells (hws.2.1 hmem)
        have hv := intBitLength_le_of_natAbs_le_two_pow (hws.2.2 loc hmem)
        omega
    _ = ws.live.card * (UL.natBitLength maxT + 2 * K + 8) := by simp
    _ ≤ (maxT + 1) * (maxIdx + 1) * (UL.natBitLength maxT + 2 * K + 8) :=
        Nat.mul_le_mul_right _ hcard

/-! ### 3. Pure Value Semantics & Fast Polynomial Bit-Cost Bounds for `IntExpr` -/

def evalVal {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e : UL.IntExpr) : ℤ :=
  (UL.evalIntExpr inp 0 ws e).1

def evalCondVal {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (c : UL.BitCondExpr) : Bool :=
  (UL.evalBitCond inp 0 ws c).1

@[simp] theorem evalVal_lit {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (c : ℤ) :
    evalVal inp ws (.lit c) = c := rfl

@[simp] theorem evalVal_dim {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) :
    evalVal inp ws .dim = (d : ℤ) := rfl

@[simp] theorem evalVal_intParam {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e : UL.IntExpr) :
    evalVal inp ws (.intParam e) = UL.listGetIntD inp.intParams (evalVal inp ws e) 0 := rfl

@[simp] theorem evalVal_readHeap {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (t : ℕ) (e : UL.IntExpr) :
    evalVal inp ws (.readHeap t e) = hRead ws t (evalVal inp ws e) := rfl

@[simp] theorem evalVal_extraRatNum {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e : UL.IntExpr) :
    evalVal inp ws (.extraRatNum e) = (UL.listGetIntD inp.extraRats (evalVal inp ws e) 0).num := rfl

@[simp] theorem evalVal_extraRatDen {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e : UL.IntExpr) :
    evalVal inp ws (.extraRatDen e) = ((UL.listGetIntD inp.extraRats (evalVal inp ws e) 0).den : ℤ) := rfl

@[simp] theorem evalVal_neg {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e : UL.IntExpr) :
    evalVal inp ws (.neg e) = - evalVal inp ws e := rfl

@[simp] theorem evalVal_add {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e₁ e₂ : UL.IntExpr) :
    evalVal inp ws (.add e₁ e₂) = evalVal inp ws e₁ + evalVal inp ws e₂ := rfl

@[simp] theorem evalVal_sub {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e₁ e₂ : UL.IntExpr) :
    evalVal inp ws (.sub e₁ e₂) = evalVal inp ws e₁ - evalVal inp ws e₂ := rfl

@[simp] theorem evalVal_mul {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e₁ e₂ : UL.IntExpr) :
    evalVal inp ws (.mul e₁ e₂) = evalVal inp ws e₁ * evalVal inp ws e₂ := rfl

@[simp] theorem evalVal_div {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e₁ e₂ : UL.IntExpr) :
    evalVal inp ws (.div e₁ e₂) = evalVal inp ws e₁ / evalVal inp ws e₂ := rfl

@[simp] theorem evalCondVal_intEq {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e₁ e₂ : UL.IntExpr) :
    evalCondVal inp ws (.intEq e₁ e₂) = decide (evalVal inp ws e₁ = evalVal inp ws e₂) := rfl

@[simp] theorem evalCondVal_intLt {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e₁ e₂ : UL.IntExpr) :
    evalCondVal inp ws (.intLt e₁ e₂) = decide (evalVal inp ws e₁ < evalVal inp ws e₂) := rfl

@[simp] theorem evalCondVal_intLe {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (e₁ e₂ : UL.IntExpr) :
    evalCondVal inp ws (.intLe e₁ e₂) = decide (evalVal inp ws e₁ ≤ evalVal inp ws e₂) := rfl

@[simp] theorem evalCondVal_not {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (c : UL.BitCondExpr) :
    evalCondVal inp ws (.not c) = !evalCondVal inp ws c := rfl

@[simp] theorem evalCondVal_and {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (c₁ c₂ : UL.BitCondExpr) :
    evalCondVal inp ws (.and c₁ c₂) = (evalCondVal inp ws c₁ && evalCondVal inp ws c₂) := rfl

@[simp] theorem evalCondVal_or {d : ℕ} (inp : UL.BitRAMInput d) (ws : UL.WordStore) (c₁ c₂ : UL.BitCondExpr) :
    evalCondVal inp ws (.or c₁ c₂) = (evalCondVal inp ws c₁ || evalCondVal inp ws c₂) := rfl

def InputMagBounded {d : ℕ} (K : ℕ) (inp : UL.BitRAMInput d) : Prop :=
  d ≤ 2 ^ K ∧
  (∀ z ∈ inp.intParams, z.natAbs ≤ 2 ^ K) ∧
  (∀ q ∈ inp.extraRats, q.num.natAbs ≤ 2 ^ K ∧ q.den ≤ 2 ^ K)

def exprLeaves : UL.IntExpr → ℕ
  | .lit _ => 1
  | .dim => 1
  | .intParam e => exprLeaves e + 1
  | .readHeap _ e => exprLeaves e + 1
  | .readLocal _ e => exprLeaves e + 1
  | .activeRatNum e₁ e₂ => exprLeaves e₁ + exprLeaves e₂ + 1
  | .activeRatDen e₁ e₂ => exprLeaves e₁ + exprLeaves e₂ + 1
  | .extraRatNum e => exprLeaves e + 1
  | .extraRatDen e => exprLeaves e + 1
  | .neg e => exprLeaves e
  | .add e₁ e₂ => exprLeaves e₁ + exprLeaves e₂
  | .sub e₁ e₂ => exprLeaves e₁ + exprLeaves e₂
  | .mul e₁ e₂ => exprLeaves e₁ + exprLeaves e₂
  | .div e₁ e₂ => exprLeaves e₁ + exprLeaves e₂
  | .mod e₁ e₂ => exprLeaves e₁ + exprLeaves e₂

def exprNodes : UL.IntExpr → ℕ
  | .lit _ => 1
  | .dim => 1
  | .intParam e => exprNodes e + 1
  | .readHeap _ e => exprNodes e + 1
  | .readLocal _ e => exprNodes e + 1
  | .activeRatNum e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .activeRatDen e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .extraRatNum e => exprNodes e + 1
  | .extraRatDen e => exprNodes e + 1
  | .neg e => exprNodes e + 1
  | .add e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .sub e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .mul e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .div e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .mod e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1

def exprWf (maxT : ℕ) : UL.IntExpr → Bool
  | .lit c => decide (c.natAbs ≤ 64)
  | .dim => true
  | .intParam e => exprWf maxT e
  | .readHeap t e => decide (t ≤ maxT) && exprWf maxT e
  | .readLocal _ _ => false
  | .activeRatNum _ _ => false
  | .activeRatDen _ _ => false
  | .extraRatNum e => exprWf maxT e
  | .extraRatDen e => exprWf maxT e
  | .neg e => exprWf maxT e
  | .add e₁ e₂ => exprWf maxT e₁ && exprWf maxT e₂
  | .sub e₁ e₂ => exprWf maxT e₁ && exprWf maxT e₂
  | .mul e₁ e₂ => exprWf maxT e₁ && exprWf maxT e₂
  | .div e₁ e₂ => exprWf maxT e₁ && exprWf maxT e₂
  | .mod _ _ => false

theorem exprLeaves_pos (e : UL.IntExpr) : 1 ≤ exprLeaves e := by
  induction e <;> simp [exprLeaves] <;> omega

private theorem listGetD_mem_or_eq {α : Type*} :
    ∀ (xs : List α) (n : ℕ) (fb : α), xs.getD n fb = fb ∨ xs.getD n fb ∈ xs
  | [], _, _ => Or.inl rfl
  | _ :: _, 0, _ => Or.inr List.mem_cons_self
  | _ :: xs, n + 1, fb =>
      match listGetD_mem_or_eq xs n fb with
      | Or.inl h => Or.inl h
      | Or.inr h => Or.inr (List.mem_cons_of_mem _ h)

private theorem listGetIntD_mem_or_eq {α : Type*} (xs : List α) (idx : ℤ) (fb : α) :
    UL.listGetIntD xs idx fb = fb ∨ UL.listGetIntD xs idx fb ∈ xs := by
  unfold UL.listGetIntD
  split_ifs with h
  · exact listGetD_mem_or_eq xs idx.toNat fb
  · exact Or.inl rfl

-- Zero-whnf elementary ℕ cost combinators
private theorem hib_le_two_mul_mul {z : ℤ} {L K : ℕ} (hK : 6 ≤ K) (hL : 1 ≤ L)
    (hz : z.natAbs ≤ 2 ^ (L * K)) :
    UL.intBitLength z ≤ 2 * L * K := by
  have h1 := intBitLength_le_of_natAbs_le_two_pow hz
  have hLK : 6 ≤ L * K := by
    calc 6 = 1 * 6 := rfl
      _ ≤ L * K := Nat.mul_le_mul hL hK
  have heq : 2 * L * K = L * K + L * K := by ring
  omega

private theorem nat_add_le_mul_of_ge_two {a b : ℕ} (ha : 2 ≤ a) (hb : 2 ≤ b) :
    a + b ≤ a * b := by
  obtain ⟨a', rfl⟩ : ∃ a', a = a' + 2 := ⟨a - 2, by omega⟩
  obtain ⟨b', rfl⟩ : ∃ b', b = b' + 2 := ⟨b - 2, by omega⟩
  have h : (a' + 2) * (b' + 2) = a' * b' + a' + b' + (a' + 2 + (b' + 2)) := by ring
  omega

private theorem pow2_sum_le_pow2_add {L1 L2 K : ℕ} (hK : 6 ≤ K) (hL1 : 1 ≤ L1) (hL2 : 1 ≤ L2) :
    2 ^ (L1 * K) + 2 ^ (L2 * K) ≤ 2 ^ ((L1 + L2) * K) := by
  have hp1 : 2 ≤ 2 ^ (L1 * K) := by
    have h1 : 1 ≤ L1 * K := Nat.mul_pos hL1 (by omega)
    exact (show 2 = 2 ^ 1 from rfl).trans_le (Nat.pow_le_pow_right (by omega) h1)
  have hp2 : 2 ≤ 2 ^ (L2 * K) := by
    have h1 : 1 ≤ L2 * K := Nat.mul_pos hL2 (by omega)
    exact (show 2 = 2 ^ 1 from rfl).trans_le (Nat.pow_le_pow_right (by omega) h1)
  calc 2 ^ (L1 * K) + 2 ^ (L2 * K)
      ≤ 2 ^ (L1 * K) * 2 ^ (L2 * K) := nat_add_le_mul_of_ge_two hp1 hp2
    _ = 2 ^ ((L1 + L2) * K) := by rw [← pow_add, ← Nat.add_mul]

private theorem nat_cost_leaf {x M : ℕ} (hx : x ≤ M) (hM : 1 ≤ M) :
    x ≤ 1 * M ^ 2 := by
  calc x = x * 1 := (Nat.mul_one x).symm
    _ ≤ M * M := Nat.mul_le_mul hx hM
    _ = 1 * M ^ 2 := by ring

private theorem nat_cost_unary1 {b1 N1 x M : ℕ}
    (hb1 : b1 ≤ N1 * M ^ 2) (hx : x ≤ M) (hM : 1 ≤ M) :
    b1 + x ≤ (N1 + 1) * M ^ 2 := by
  have hx2 : x ≤ M ^ 2 := by
    calc x = x * 1 := (Nat.mul_one x).symm
      _ ≤ M * M := Nat.mul_le_mul hx hM
      _ = M ^ 2 := (sq M).symm
  calc b1 + x ≤ N1 * M ^ 2 + M ^ 2 := Nat.add_le_add hb1 hx2
    _ = (N1 + 1) * M ^ 2 := by ring

private theorem nat_cost_unary2 {b1 N1 x y M : ℕ}
    (hb1 : b1 ≤ N1 * M ^ 2) (hx : x ≤ M) (hy : y ≤ M) (hM : 2 ≤ M) :
    b1 + x + y ≤ (N1 + 1) * M ^ 2 := by
  have hxy : x + y ≤ M ^ 2 := by
    calc x + y ≤ M + M := Nat.add_le_add hx hy
      _ = 2 * M := (two_mul M).symm
      _ ≤ M * M := Nat.mul_le_mul_right M hM
      _ = M ^ 2 := (sq M).symm
  calc b1 + x + y = b1 + (x + y) := Nat.add_assoc _ _ _
    _ ≤ N1 * M ^ 2 + M ^ 2 := Nat.add_le_add hb1 hxy
    _ = (N1 + 1) * M ^ 2 := by ring

private theorem nat_cost_unary3 {b1 N1 x y z M : ℕ}
    (hb1 : b1 ≤ N1 * M ^ 2) (hx : x ≤ M) (hy : y ≤ M) (hz : z ≤ M) (hM : 3 ≤ M) :
    b1 + x + y + z ≤ (N1 + 1) * M ^ 2 := by
  have hxyz : x + y + z ≤ M ^ 2 := by
    calc x + y + z ≤ M + M + M := Nat.add_le_add (Nat.add_le_add hx hy) hz
      _ = 3 * M := by ring
      _ ≤ M * M := Nat.mul_le_mul_right M hM
      _ = M ^ 2 := (sq M).symm
  calc b1 + x + y + z = b1 + (x + y + z) := by ring
    _ ≤ N1 * M ^ 2 + M ^ 2 := Nat.add_le_add hb1 hxyz
    _ = (N1 + 1) * M ^ 2 := by ring

private theorem nat_cost_bin_add {b1 b2 N1 N2 x y M : ℕ}
    (hb1 : b1 ≤ N1 * M ^ 2) (hb2 : b2 ≤ N2 * M ^ 2)
    (hx : x ≤ M) (hy : y ≤ M) (hM : 2 ≤ M) :
    b1 + b2 + x + y ≤ (N1 + N2 + 1) * M ^ 2 := by
  have hxy : x + y ≤ M ^ 2 := by
    calc x + y ≤ M + M := Nat.add_le_add hx hy
      _ = 2 * M := (two_mul M).symm
      _ ≤ M * M := Nat.mul_le_mul_right M hM
      _ = M ^ 2 := (sq M).symm
  calc b1 + b2 + x + y = (b1 + b2) + (x + y) := by ring
    _ ≤ (N1 * M ^ 2 + N2 * M ^ 2) + M ^ 2 := Nat.add_le_add (Nat.add_le_add hb1 hb2) hxy
    _ = (N1 + N2 + 1) * M ^ 2 := by ring

private theorem nat_cost_bin_mul {b1 b2 N1 N2 x y M : ℕ}
    (hb1 : b1 ≤ N1 * M ^ 2) (hb2 : b2 ≤ N2 * M ^ 2)
    (hx : x ≤ M) (hy : y ≤ M) :
    b1 + b2 + x * y ≤ (N1 + N2 + 1) * M ^ 2 := by
  have hxy : x * y ≤ M ^ 2 := by rw [sq]; exact Nat.mul_le_mul hx hy
  calc b1 + b2 + x * y ≤ (N1 * M ^ 2 + N2 * M ^ 2) + M ^ 2 :=
        Nat.add_le_add (Nat.add_le_add hb1 hb2) hxy
    _ = (N1 + N2 + 1) * M ^ 2 := by ring

private theorem nat_cost_write {b1 b2 N1 N2 x y M : ℕ}
    (hb1 : b1 ≤ N1 * M ^ 2) (hb2 : b2 ≤ N2 * M ^ 2)
    (hx : x ≤ M) (hy : y ≤ M) (hM : 2 ≤ M) :
    b1 + b2 + x + y ≤ (N1 + N2 + 2) * M ^ 2 :=
  (nat_cost_bin_add hb1 hb2 hx hy hM).trans (Nat.mul_le_mul_right _ (by omega))

private theorem two_mul_L_K_ge {L K : ℕ} (hK : 6 ≤ K) (hL : 1 ≤ L) :
    12 ≤ 2 * L * K := by
  calc 12 = 2 * 1 * 6 := rfl
    _ ≤ 2 * L * K := Nat.mul_le_mul (Nat.mul_le_mul_left 2 hL) hK

private theorem two_mul_mono {L1 L2 K : ℕ} (h : L1 ≤ L2) :
    2 * L1 * K ≤ 2 * L2 * K :=
  Nat.mul_le_mul_right K (Nat.mul_le_mul_left 2 h)

theorem evalIntExpr_cost_bound {d maxT maxIdx K : ℕ}
    (hK : 6 ≤ K) (hT : UL.natBitLength maxT ≤ 2 * K)
    {inp : UL.BitRAMInput d} (hinp : InputMagBounded K inp)
    {ws : UL.WordStore} (hws : StoreBounded maxT maxIdx K ws)
    (e : UL.IntExpr) (hwf : exprWf maxT e = true) :
    let res := UL.evalIntExpr inp 0 ws e
    res.1.natAbs ≤ 2 ^ (exprLeaves e * K) ∧
    res.2.1 ≤ exprNodes e ∧
    res.2.2 ≤ exprNodes e * (2 * exprLeaves e * K) ^ 2 := by
  induction e with
  | lit c =>
      simp only [exprWf, decide_eq_true_eq] at hwf
      have hcK : c.natAbs ≤ 2 ^ (1 * K) :=
        hwf.trans ((show 64 = 2 ^ 6 from rfl).trans_le (Nat.pow_le_pow_right (by omega) (by omega)))
      have hb := hib_le_two_mul_mul hK le_rfl hcK
      simp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hcK, le_rfl, nat_cost_leaf hb (by have := two_mul_L_K_ge hK le_rfl; omega)⟩
  | dim =>
      have hdK : (d : ℤ).natAbs ≤ 2 ^ (1 * K) := by simpa using hinp.1
      have hb := hib_le_two_mul_mul hK le_rfl hdK
      simp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hdK, le_rfl, nat_cost_leaf hb (by have := two_mul_L_K_ge hK le_rfl; omega)⟩
  | intParam idxE ih =>
      simp only [exprWf] at hwf
      obtain ⟨hidx_abs, hu1, hb1⟩ := ih hwf
      have hL1 : 1 ≤ exprLeaves idxE := exprLeaves_pos idxE
      have hL : 1 ≤ exprLeaves idxE + 1 := Nat.succ_pos _
      let v := UL.listGetIntD inp.intParams (UL.evalIntExpr inp 0 ws idxE).1 0
      have hv_abs : v.natAbs ≤ 2 ^ K := by
        rcases listGetIntD_mem_or_eq inp.intParams (UL.evalIntExpr inp 0 ws idxE).1 0 with h0 | hmem
        · simp [v, h0]
        · exact hinp.2.1 v hmem
      have hv_absL : v.natAbs ≤ 2 ^ ((exprLeaves idxE + 1) * K) :=
        hv_abs.trans (Nat.pow_le_pow_right (by omega)
          ((show K = 1 * K from (one_mul K).symm).trans_le (Nat.mul_le_mul_right K hL)))
      have hM := two_mul_mono (K := K) (Nat.le_succ (exprLeaves idxE))
      have hb_idx := (hib_le_two_mul_mul hK hL1 hidx_abs).trans hM
      have hb_v := hib_le_two_mul_mul hK hL hv_absL
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM 2))
      have hM12 := two_mul_L_K_ge hK hL
      simp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hv_absL, Nat.succ_le_succ hu1, nat_cost_unary2 hb1' hb_idx hb_v (by omega)⟩
  | readHeap t idxE ih =>
      simp only [exprWf, Bool.and_eq_true, decide_eq_true_eq] at hwf
      obtain ⟨hidx_abs, hu1, hb1⟩ := ih hwf.2
      have hL1 : 1 ≤ exprLeaves idxE := exprLeaves_pos idxE
      have hL : 1 ≤ exprLeaves idxE + 1 := Nat.succ_pos _
      let idx := (UL.evalIntExpr inp 0 ws idxE).1
      let v := ws.read (.heap t idx)
      have hv_absL : v.natAbs ≤ 2 ^ ((exprLeaves idxE + 1) * K) :=
        (storeBounded_read_abs hws (.heap t idx)).trans (Nat.pow_le_pow_right (by omega)
          ((show K = 1 * K from (one_mul K).symm).trans_le (Nat.mul_le_mul_right K hL)))
      have hM := two_mul_mono (K := K) (Nat.le_succ (exprLeaves idxE))
      have ht_b : UL.natBitLength t ≤ 2 * (exprLeaves idxE + 1) * K :=
        ((natBitLength_mono hwf.1).trans hT).trans
          ((show 2 * K = 2 * 1 * K by ring).trans_le (two_mul_mono hL))
      have hb_idx := (hib_le_two_mul_mul hK hL1 hidx_abs).trans hM
      have hb_v := hib_le_two_mul_mul hK hL hv_absL
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM 2))
      have hM12 := two_mul_L_K_ge hK hL
      simp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hv_absL, Nat.succ_le_succ hu1, nat_cost_unary3 hb1' ht_b hb_idx hb_v (by omega)⟩
  | readLocal _ _ _ => simp [exprWf] at hwf
  | activeRatNum _ _ _ _ => simp [exprWf] at hwf
  | activeRatDen _ _ _ _ => simp [exprWf] at hwf
  | extraRatNum idxE ih =>
      simp only [exprWf] at hwf
      obtain ⟨hidx_abs, hu1, hb1⟩ := ih hwf
      have hL1 : 1 ≤ exprLeaves idxE := exprLeaves_pos idxE
      have hL : 1 ≤ exprLeaves idxE + 1 := Nat.succ_pos _
      let idx := (UL.evalIntExpr inp 0 ws idxE).1
      let q := UL.listGetIntD inp.extraRats idx 0
      have hv_abs : q.num.natAbs ≤ 2 ^ K := by
        rcases listGetIntD_mem_or_eq inp.extraRats idx 0 with h0 | hmem
        · simp [q, h0]
        · exact (hinp.2.2 q hmem).1
      have hv_absL : q.num.natAbs ≤ 2 ^ ((exprLeaves idxE + 1) * K) :=
        hv_abs.trans (Nat.pow_le_pow_right (by omega)
          ((show K = 1 * K from (one_mul K).symm).trans_le (Nat.mul_le_mul_right K hL)))
      have hM := two_mul_mono (K := K) (Nat.le_succ (exprLeaves idxE))
      have hb_idx := (hib_le_two_mul_mul hK hL1 hidx_abs).trans hM
      have hb_v := hib_le_two_mul_mul hK hL hv_absL
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM 2))
      have hM12 := two_mul_L_K_ge hK hL
      simp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hv_absL, Nat.succ_le_succ hu1, nat_cost_unary2 hb1' hb_idx hb_v (by omega)⟩
  | extraRatDen idxE ih =>
      simp only [exprWf] at hwf
      obtain ⟨hidx_abs, hu1, hb1⟩ := ih hwf
      have hL1 : 1 ≤ exprLeaves idxE := exprLeaves_pos idxE
      have hL : 1 ≤ exprLeaves idxE + 1 := Nat.succ_pos _
      let idx := (UL.evalIntExpr inp 0 ws idxE).1
      let q := UL.listGetIntD inp.extraRats idx 0
      have hv_abs : ((q.den : ℤ)).natAbs ≤ 2 ^ K := by
        rcases listGetIntD_mem_or_eq inp.extraRats idx 0 with h0 | hmem
        · have h1 : q = 0 := h0; rw [h1]; simpa using Nat.one_le_two_pow
        · simpa using (hinp.2.2 q hmem).2
      have hv_absL : ((q.den : ℤ)).natAbs ≤ 2 ^ ((exprLeaves idxE + 1) * K) :=
        hv_abs.trans (Nat.pow_le_pow_right (by omega)
          ((show K = 1 * K from (one_mul K).symm).trans_le (Nat.mul_le_mul_right K hL)))
      have hM := two_mul_mono (K := K) (Nat.le_succ (exprLeaves idxE))
      have hb_idx := (hib_le_two_mul_mul hK hL1 hidx_abs).trans hM
      have hb_v := hib_le_two_mul_mul hK hL hv_absL
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM 2))
      have hM12 := two_mul_L_K_ge hK hL
      simp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hv_absL, Nat.succ_le_succ hu1, nat_cost_unary2 hb1' hb_idx hb_v (by omega)⟩
  | neg e₁ ih =>
      simp only [exprWf] at hwf
      obtain ⟨hv1, hu1, hb1⟩ := ih hwf
      have hL : 1 ≤ exprLeaves e₁ := exprLeaves_pos e₁
      have hbv1 := hib_le_two_mul_mul hK hL hv1
      have hM12 := two_mul_L_K_ge hK hL
      simp only [UL.evalIntExpr, exprLeaves, exprNodes, Int.natAbs_neg]
      exact ⟨hv1, Nat.succ_le_succ hu1, nat_cost_unary1 hb1 hbv1 (by omega)⟩
  | add e₁ e₂ ih₁ ih₂ =>
      simp only [exprWf, Bool.and_eq_true] at hwf
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hwf.1
      obtain ⟨hv2, hu2, hb2⟩ := ih₂ hwf.2
      have hL1 := exprLeaves_pos e₁; have hL2 := exprLeaves_pos e₂
      have hv_sum := (Int.natAbs_add_le _ _).trans
        ((Nat.add_le_add hv1 hv2).trans (pow2_sum_le_pow2_add hK hL1 hL2))
      have hM1 := two_mul_mono (K := K) (Nat.le_add_right (exprLeaves e₁) (exprLeaves e₂))
      have hM2 := two_mul_mono (K := K) (Nat.le_add_left (exprLeaves e₂) (exprLeaves e₁))
      have hbv1 := (hib_le_two_mul_mul hK hL1 hv1).trans hM1
      have hbv2 := (hib_le_two_mul_mul hK hL2 hv2).trans hM2
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM1 2))
      have hb2' := hb2.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM2 2))
      have hM12 := two_mul_L_K_ge hK (by omega : 1 ≤ exprLeaves e₁ + exprLeaves e₂)
      dsimp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hv_sum, Nat.add_le_add_right (Nat.add_le_add hu1 hu2) 1,
        nat_cost_bin_add hb1' hb2' hbv1 hbv2 (by omega)⟩
  | sub e₁ e₂ ih₁ ih₂ =>
      simp only [exprWf, Bool.and_eq_true] at hwf
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hwf.1
      obtain ⟨hv2, hu2, hb2⟩ := ih₂ hwf.2
      have hL1 := exprLeaves_pos e₁; have hL2 := exprLeaves_pos e₂
      have hv_sub := (Int.natAbs_sub_le _ _).trans
        ((Nat.add_le_add hv1 hv2).trans (pow2_sum_le_pow2_add hK hL1 hL2))
      have hM1 := two_mul_mono (K := K) (Nat.le_add_right (exprLeaves e₁) (exprLeaves e₂))
      have hM2 := two_mul_mono (K := K) (Nat.le_add_left (exprLeaves e₂) (exprLeaves e₁))
      have hbv1 := (hib_le_two_mul_mul hK hL1 hv1).trans hM1
      have hbv2 := (hib_le_two_mul_mul hK hL2 hv2).trans hM2
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM1 2))
      have hb2' := hb2.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM2 2))
      have hM12 := two_mul_L_K_ge hK (by omega : 1 ≤ exprLeaves e₁ + exprLeaves e₂)
      dsimp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hv_sub, Nat.add_le_add_right (Nat.add_le_add hu1 hu2) 1,
        nat_cost_bin_add hb1' hb2' hbv1 hbv2 (by omega)⟩
  | mul e₁ e₂ ih₁ ih₂ =>
      simp only [exprWf, Bool.and_eq_true] at hwf
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hwf.1
      obtain ⟨hv2, hu2, hb2⟩ := ih₂ hwf.2
      have hL1 := exprLeaves_pos e₁; have hL2 := exprLeaves_pos e₂
      have hv_mul : ((UL.evalIntExpr inp 0 ws e₁).1 * (UL.evalIntExpr inp 0 ws e₂).1).natAbs ≤
          2 ^ ((exprLeaves e₁ + exprLeaves e₂) * K) := by
        rw [Int.natAbs_mul]
        calc (UL.evalIntExpr inp 0 ws e₁).1.natAbs * (UL.evalIntExpr inp 0 ws e₂).1.natAbs
            ≤ 2 ^ (exprLeaves e₁ * K) * 2 ^ (exprLeaves e₂ * K) := Nat.mul_le_mul hv1 hv2
          _ = 2 ^ ((exprLeaves e₁ + exprLeaves e₂) * K) := by rw [← pow_add, ← Nat.add_mul]
      have hM1 := two_mul_mono (K := K) (Nat.le_add_right (exprLeaves e₁) (exprLeaves e₂))
      have hM2 := two_mul_mono (K := K) (Nat.le_add_left (exprLeaves e₂) (exprLeaves e₁))
      have hbv1 := (hib_le_two_mul_mul hK hL1 hv1).trans hM1
      have hbv2 := (hib_le_two_mul_mul hK hL2 hv2).trans hM2
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM1 2))
      have hb2' := hb2.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM2 2))
      dsimp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hv_mul, Nat.add_le_add_right (Nat.add_le_add hu1 hu2) 1,
        nat_cost_bin_mul hb1' hb2' hbv1 hbv2⟩
  | div e₁ e₂ ih₁ ih₂ =>
      simp only [exprWf, Bool.and_eq_true] at hwf
      obtain ⟨hv1, hu1, hb1⟩ := ih₁ hwf.1
      obtain ⟨hv2, hu2, hb2⟩ := ih₂ hwf.2
      have hL1 := exprLeaves_pos e₁; have hL2 := exprLeaves_pos e₂
      have hv_div : ((UL.evalIntExpr inp 0 ws e₁).1 / (UL.evalIntExpr inp 0 ws e₂).1).natAbs ≤
          2 ^ ((exprLeaves e₁ + exprLeaves e₂) * K) :=
        (Int.natAbs_ediv_le_natAbs _ _).trans (hv1.trans (Nat.pow_le_pow_right (by omega)
          (Nat.mul_le_mul_right K (Nat.le_add_right _ _))))
      have hM1 := two_mul_mono (K := K) (Nat.le_add_right (exprLeaves e₁) (exprLeaves e₂))
      have hM2 := two_mul_mono (K := K) (Nat.le_add_left (exprLeaves e₂) (exprLeaves e₁))
      have hbv1 := (hib_le_two_mul_mul hK hL1 hv1).trans hM1
      have hbv2 := (hib_le_two_mul_mul hK hL2 hv2).trans hM2
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM1 2))
      have hb2' := hb2.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM2 2))
      dsimp only [UL.evalIntExpr, exprLeaves, exprNodes]
      exact ⟨hv_div, Nat.add_le_add_right (Nat.add_le_add hu1 hu2) 1,
        nat_cost_bin_mul hb1' hb2' hbv1 hbv2⟩
  | mod _ _ _ _ => simp [exprWf] at hwf

def condLeaves : UL.BitCondExpr → ℕ
  | .intEq e₁ e₂ => exprLeaves e₁ + exprLeaves e₂
  | .intLt e₁ e₂ => exprLeaves e₁ + exprLeaves e₂
  | .intLe e₁ e₂ => exprLeaves e₁ + exprLeaves e₂
  | .not c => condLeaves c
  | .and c₁ c₂ => condLeaves c₁ + condLeaves c₂
  | .or c₁ c₂ => condLeaves c₁ + condLeaves c₂

def condNodes : UL.BitCondExpr → ℕ
  | .intEq e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .intLt e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .intLe e₁ e₂ => exprNodes e₁ + exprNodes e₂ + 1
  | .not c => condNodes c + 1
  | .and c₁ c₂ => condNodes c₁ + condNodes c₂ + 1
  | .or c₁ c₂ => condNodes c₁ + condNodes c₂ + 1

def condWf (maxT : ℕ) : UL.BitCondExpr → Bool
  | .intEq e₁ e₂ => exprWf maxT e₁ && exprWf maxT e₂
  | .intLt e₁ e₂ => exprWf maxT e₁ && exprWf maxT e₂
  | .intLe e₁ e₂ => exprWf maxT e₁ && exprWf maxT e₂
  | .not c => condWf maxT c
  | .and c₁ c₂ => condWf maxT c₁ && condWf maxT c₂
  | .or c₁ c₂ => condWf maxT c₁ && condWf maxT c₂

theorem condLeaves_pos (c : UL.BitCondExpr) : 1 ≤ condLeaves c := by
  induction c with
  | intEq e₁ _ => have := exprLeaves_pos e₁; simp [condLeaves]; omega
  | intLt e₁ _ => have := exprLeaves_pos e₁; simp [condLeaves]; omega
  | intLe e₁ _ => have := exprLeaves_pos e₁; simp [condLeaves]; omega
  | not _ ih => simpa [condLeaves] using ih
  | and _ _ ih₁ _ => simp [condLeaves]; omega
  | or _ _ ih₁ _ => simp [condLeaves]; omega

theorem evalBitCond_cost_bound {d maxT maxIdx K : ℕ}
    (hK : 6 ≤ K) (hT : UL.natBitLength maxT ≤ 2 * K)
    {inp : UL.BitRAMInput d} (hinp : InputMagBounded K inp)
    {ws : UL.WordStore} (hws : StoreBounded maxT maxIdx K ws)
    (c : UL.BitCondExpr) (hwf : condWf maxT c = true) :
    let res := UL.evalBitCond inp 0 ws c
    res.2.1 ≤ condNodes c ∧
    res.2.2 ≤ condNodes c * (2 * condLeaves c * K) ^ 2 := by
  induction c with
  | intEq e₁ e₂ =>
      simp only [condWf, Bool.and_eq_true] at hwf
      obtain ⟨hv1, hu1, hb1⟩ := evalIntExpr_cost_bound hK hT hinp hws e₁ hwf.1
      obtain ⟨hv2, hu2, hb2⟩ := evalIntExpr_cost_bound hK hT hinp hws e₂ hwf.2
      have hL1 := exprLeaves_pos e₁; have hL2 := exprLeaves_pos e₂
      have hM1 := two_mul_mono (K := K) (Nat.le_add_right (exprLeaves e₁) (exprLeaves e₂))
      have hM2 := two_mul_mono (K := K) (Nat.le_add_left (exprLeaves e₂) (exprLeaves e₁))
      have hbv1 := (hib_le_two_mul_mul hK hL1 hv1).trans hM1
      have hbv2 := (hib_le_two_mul_mul hK hL2 hv2).trans hM2
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM1 2))
      have hb2' := hb2.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM2 2))
      have hM12 := two_mul_L_K_ge hK (by omega : 1 ≤ exprLeaves e₁ + exprLeaves e₂)
      dsimp only [UL.evalBitCond, condNodes, condLeaves]
      exact ⟨Nat.add_le_add_right (Nat.add_le_add hu1 hu2) 1,
        nat_cost_bin_add hb1' hb2' hbv1 hbv2 (by omega)⟩
  | intLt e₁ e₂ =>
      simp only [condWf, Bool.and_eq_true] at hwf
      obtain ⟨hv1, hu1, hb1⟩ := evalIntExpr_cost_bound hK hT hinp hws e₁ hwf.1
      obtain ⟨hv2, hu2, hb2⟩ := evalIntExpr_cost_bound hK hT hinp hws e₂ hwf.2
      have hL1 := exprLeaves_pos e₁; have hL2 := exprLeaves_pos e₂
      have hM1 := two_mul_mono (K := K) (Nat.le_add_right (exprLeaves e₁) (exprLeaves e₂))
      have hM2 := two_mul_mono (K := K) (Nat.le_add_left (exprLeaves e₂) (exprLeaves e₁))
      have hbv1 := (hib_le_two_mul_mul hK hL1 hv1).trans hM1
      have hbv2 := (hib_le_two_mul_mul hK hL2 hv2).trans hM2
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM1 2))
      have hb2' := hb2.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM2 2))
      have hM12 := two_mul_L_K_ge hK (by omega : 1 ≤ exprLeaves e₁ + exprLeaves e₂)
      dsimp only [UL.evalBitCond, condNodes, condLeaves]
      exact ⟨Nat.add_le_add_right (Nat.add_le_add hu1 hu2) 1,
        nat_cost_bin_add hb1' hb2' hbv1 hbv2 (by omega)⟩
  | intLe e₁ e₂ =>
      simp only [condWf, Bool.and_eq_true] at hwf
      obtain ⟨hv1, hu1, hb1⟩ := evalIntExpr_cost_bound hK hT hinp hws e₁ hwf.1
      obtain ⟨hv2, hu2, hb2⟩ := evalIntExpr_cost_bound hK hT hinp hws e₂ hwf.2
      have hL1 := exprLeaves_pos e₁; have hL2 := exprLeaves_pos e₂
      have hM1 := two_mul_mono (K := K) (Nat.le_add_right (exprLeaves e₁) (exprLeaves e₂))
      have hM2 := two_mul_mono (K := K) (Nat.le_add_left (exprLeaves e₂) (exprLeaves e₁))
      have hbv1 := (hib_le_two_mul_mul hK hL1 hv1).trans hM1
      have hbv2 := (hib_le_two_mul_mul hK hL2 hv2).trans hM2
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM1 2))
      have hb2' := hb2.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM2 2))
      have hM12 := two_mul_L_K_ge hK (by omega : 1 ≤ exprLeaves e₁ + exprLeaves e₂)
      dsimp only [UL.evalBitCond, condNodes, condLeaves]
      exact ⟨Nat.add_le_add_right (Nat.add_le_add hu1 hu2) 1,
        nat_cost_bin_add hb1' hb2' hbv1 hbv2 (by omega)⟩
  | not c₁ ih =>
      simp only [condWf] at hwf
      obtain ⟨hu1, hb1⟩ := ih hwf
      have hM12 := two_mul_L_K_ge hK (condLeaves_pos c₁)
      dsimp only [UL.evalBitCond, condNodes, condLeaves]
      exact ⟨Nat.succ_le_succ hu1, nat_cost_unary1 hb1 (by omega) (by omega)⟩
  | and c₁ c₂ ih₁ ih₂ =>
      simp only [condWf, Bool.and_eq_true] at hwf
      obtain ⟨hu1, hb1⟩ := ih₁ hwf.1
      obtain ⟨hu2, hb2⟩ := ih₂ hwf.2
      have hL1 := condLeaves_pos c₁
      have hM1 := two_mul_mono (K := K) (Nat.le_add_right (condLeaves c₁) (condLeaves c₂))
      have hM2 := two_mul_mono (K := K) (Nat.le_add_left (condLeaves c₂) (condLeaves c₁))
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM1 2))
      have hb2' := hb2.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM2 2))
      have hM12 := two_mul_L_K_ge hK (by omega : 1 ≤ condLeaves c₁ + condLeaves c₂)
      dsimp only [UL.evalBitCond, condNodes, condLeaves]
      exact ⟨Nat.add_le_add_right (Nat.add_le_add hu1 hu2) 1,
        by simpa only [Nat.mul_one] using
          nat_cost_bin_mul hb1' hb2' (x := 1) (y := 1) (by omega) (by omega)⟩
  | or c₁ c₂ ih₁ ih₂ =>
      simp only [condWf, Bool.and_eq_true] at hwf
      obtain ⟨hu1, hb1⟩ := ih₁ hwf.1
      obtain ⟨hu2, hb2⟩ := ih₂ hwf.2
      have hL1 := condLeaves_pos c₁
      have hM1 := two_mul_mono (K := K) (Nat.le_add_right (condLeaves c₁) (condLeaves c₂))
      have hM2 := two_mul_mono (K := K) (Nat.le_add_left (condLeaves c₂) (condLeaves c₁))
      have hb1' := hb1.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM1 2))
      have hb2' := hb2.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hM2 2))
      have hM12 := two_mul_L_K_ge hK (by omega : 1 ≤ condLeaves c₁ + condLeaves c₂)
      dsimp only [UL.evalBitCond, condNodes, condLeaves]
      exact ⟨Nat.add_le_add_right (Nat.add_le_add hu1 hu2) 1,
        by simpa only [Nat.mul_one] using
          nat_cost_bin_mul hb1' hb2' (x := 1) (y := 1) (by omega) (by omega)⟩

/-! ### 4. Compositional `ExecBit` Continuation-Passing Framework -/

theorem runBitRAMFuel_mono {d : ℕ} (inp : UL.BitRAMInput d) :
    ∀ {fuel₁ fuel₂ : ℕ} {stack : List UL.BitRAMCont} {st : UL.BitRAMExecState}
      {res : UL.BitRAMRunStatus},
      res ≠ .outOfFuel →
      fuel₁ ≤ fuel₂ →
      UL.runBitRAMFuel inp fuel₁ stack st = res →
      UL.runBitRAMFuel inp fuel₂ stack st = res
  | f₁, f₂, [], st, res, _, _, hrun => by
      cases f₁ <;> cases f₂ <;> simpa [UL.runBitRAMFuel] using hrun
  | 0, _, _ :: _, _, res, hne, _, hrun => by
      simp [UL.runBitRAMFuel] at hrun
      exact absurd hrun.symm hne
  | f₁ + 1, 0, _ :: _, _, _, _, hle, _ => by omega
  | f₁ + 1, f₂ + 1, item :: rest, st, res, hne, hle, hrun => by
      have hle' : f₁ ≤ f₂ := by omega
      cases item with
      | popScope prev =>
          simp only [UL.runBitRAMFuel] at hrun ⊢
          exact runBitRAMFuel_mono inp hne hle' hrun
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | succ r =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
      | stmt s =>
          cases s with
          | skip =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | writeHeap table idxE valE =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | writeLocal var idxE valE =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | freeHeap table idxE =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | freeLocal var idxE =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | randBitHeap table idxE =>
              cases hbits : st.remainingBits with
              | nil => simp [UL.runBitRAMFuel, hbits] at hrun ⊢; exact hrun
              | cons bit bs' =>
                  simp only [UL.runBitRAMFuel, hbits] at hrun ⊢
                  exact runBitRAMFuel_mono inp hne hle' hrun
          | randBitLocal var idxE =>
              cases hbits : st.remainingBits with
              | nil => simp [UL.runBitRAMFuel, hbits] at hrun ⊢; exact hrun
              | cons bit bs' =>
                  simp only [UL.runBitRAMFuel, hbits] at hrun ⊢
                  exact runBitRAMFuel_mono inp hne hle' hrun
          | seq s₁ s₂ =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | ite cond tB fB =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | whileLoop cond body =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | repeatN countE body =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun
          | localScope body =>
              simp only [UL.runBitRAMFuel] at hrun ⊢
              exact runBitRAMFuel_mono inp hne hle' hrun

theorem runBitRAMWithBits_eq_some_of_fuel {d : ℕ} (prog : UL.BitRAMStmt) (inp : UL.BitRAMInput d)
    (initWords : UL.WordStore) (bs : List Bool) (fuel : ℕ) (out : UL.BitRAMExecOutcome)
    (hfuel : UL.runBitRAMFuel inp fuel [.stmt prog]
      { words := initWords.popDepth 0
        frameDepth := 0
        remainingBits := bs
        unitCost := 0
        bitCost := 0
        peakCellSpace := inp.inputCellSpace + (initWords.popDepth 0).cellCount
        peakBitSpace := inp.inputBitSpace + (initWords.popDepth 0).bitSize } = .halted out) :
    UL.runBitRAMWithBits prog inp initWords bs = some out := by
  classical
  unfold UL.runBitRAMWithBits
  dsimp only
  let initSt : UL.BitRAMExecState :=
    { words := initWords.popDepth 0
      frameDepth := 0
      remainingBits := bs
      unitCost := 0
      bitCost := 0
      peakCellSpace := inp.inputCellSpace + (initWords.popDepth 0).cellCount
      peakBitSpace := inp.inputBitSpace + (initWords.popDepth 0).bitSize }
  have hex : ∃ f : ℕ, ∃ o : UL.BitRAMExecOutcome,
      UL.runBitRAMFuel inp f [.stmt prog] initSt = .halted o := ⟨fuel, out, hfuel⟩
  rw [dif_pos hex]
  have hle : Nat.find hex ≤ fuel := Nat.find_min' hex ⟨out, hfuel⟩
  rcases Nat.find_spec hex with ⟨out₀, hout₀⟩
  have heq : UL.runBitRAMFuel inp fuel [.stmt prog] initSt = .halted out₀ :=
    runBitRAMFuel_mono inp (by simp) hle hout₀
  have hout_eq : out₀ = out := by
    rw [hfuel] at heq
    exact UL.BitRAMRunStatus.halted.inj heq.symm
  dsimp only [initSt] at hout₀
  rw [hout₀]
  dsimp only
  rw [hout_eq]

def mkBitState (ws : UL.WordStore) (u b pc pb : ℕ) : UL.BitRAMExecState :=
  { words := ws
    frameDepth := 0
    remainingBits := []
    unitCost := u
    bitCost := b
    peakCellSpace := pc
    peakBitSpace := pb }

structure HeapCtx {d : ℕ} (inp : UL.BitRAMInput d) (maxIdx K : ℕ) : Prop where
  hK : 6 ≤ K
  hMaxIdx : maxIdx ≤ 2 ^ K
  hInp : InputMagBounded K inp

def ctxPeakCells {d : ℕ} (inp : UL.BitRAMInput d) (maxIdx : ℕ) : ℕ :=
  inp.inputCellSpace + 32 * (maxIdx + 1)

def ctxPeakBits {d : ℕ} (inp : UL.BitRAMInput d) (maxIdx K : ℕ) : ℕ :=
  inp.inputBitSpace + 32 * (maxIdx + 1) * (2 * K + 14)

def ExecBit {d : ℕ} (inp : UL.BitRAMInput d) (maxIdx K : ℕ) (prog : UL.BitRAMStmt)
    (ws₀ ws₁ : UL.WordStore) (U_cost B_cost : ℕ) : Prop :=
  StoreBounded 31 maxIdx K ws₀ ∧
  StoreBounded 31 maxIdx K ws₁ ∧
  ∀ (u₀ b₀ pc₀ pb₀ : ℕ) (rest : List UL.BitRAMCont),
    ∃ (fuel₀ u₁ b₁ pc₁ pb₁ : ℕ),
      u₁ ≤ u₀ + U_cost ∧
      b₁ ≤ b₀ + B_cost ∧
      pc₁ ≤ max pc₀ (ctxPeakCells inp maxIdx) ∧
      pb₁ ≤ max pb₀ (ctxPeakBits inp maxIdx K) ∧
      ∀ fuel : ℕ,
        UL.runBitRAMFuel inp (fuel₀ + fuel) (.stmt prog :: rest) (mkBitState ws₀ u₀ b₀ pc₀ pb₀) =
        UL.runBitRAMFuel inp fuel rest (mkBitState ws₁ u₁ b₁ pc₁ pb₁)

theorem ExecBit.mono {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ} {prog : UL.BitRAMStmt}
    {ws₀ ws₁ : UL.WordStore} {U₁ B₁ U₂ B₂ : ℕ}
    (h : ExecBit inp maxIdx K prog ws₀ ws₁ U₁ B₁)
    (hU : U₁ ≤ U₂) (hB : B₁ ≤ B₂) :
    ExecBit inp maxIdx K prog ws₀ ws₁ U₂ B₂ := by
  refine ⟨h.1, h.2.1, fun u₀ b₀ pc₀ pb₀ rest => ?_⟩
  rcases h.2.2 u₀ b₀ pc₀ pb₀ rest with ⟨f₀, u₁, b₁, pc₁, pb₁, hu, hb, hpc, hpb, hs⟩
  exact ⟨f₀, u₁, b₁, pc₁, pb₁, by omega, by omega, hpc, hpb, hs⟩

theorem ExecBit.to_runBitRAMWithBits {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    {prog : UL.BitRAMStmt} {ws₁ : UL.WordStore} {U_cost B_cost : ℕ}
    (h : ExecBit inp maxIdx K prog UL.WordStore.empty ws₁ U_cost B_cost) :
    ∃ out : UL.BitRAMExecOutcome,
      UL.runBitRAMWithBits prog inp UL.WordStore.empty [] = some out ∧
      out.words = ws₁ ∧
      out.unitCost ≤ U_cost ∧
      out.bitCost ≤ B_cost ∧
      out.peakCellSpace ≤ ctxPeakCells inp maxIdx ∧
      out.peakBitSpace ≤ ctxPeakBits inp maxIdx K := by
  rcases h with ⟨hws₀, hws₁, hrun⟩
  have hpc0 : inp.inputCellSpace + UL.WordStore.empty.cellCount ≤ ctxPeakCells inp maxIdx := by
    simp [ctxPeakCells, UL.WordStore.empty, UL.WordStore.cellCount]
  have hpb0 : inp.inputBitSpace + UL.WordStore.empty.bitSize ≤ ctxPeakBits inp maxIdx K := by
    simp [ctxPeakBits, UL.WordStore.empty, UL.WordStore.bitSize]
  rcases hrun 0 0
      (inp.inputCellSpace + UL.WordStore.empty.cellCount)
      (inp.inputBitSpace + UL.WordStore.empty.bitSize) [] with
    ⟨f₀, u₁, b₁, pc₁, pb₁, hu, hb, hpc, hpb, hstep⟩
  let out : UL.BitRAMExecOutcome :=
    { words := ws₁, unitCost := u₁, bitCost := b₁, peakCellSpace := pc₁, peakBitSpace := pb₁ }
  refine ⟨out, ?_, rfl, by dsimp [out]; omega, by dsimp [out]; omega,
    by dsimp [out]; exact hpc.trans (max_eq_right hpc0).le,
    by dsimp [out]; exact hpb.trans (max_eq_right hpb0).le⟩
  apply runBitRAMWithBits_eq_some_of_fuel prog inp UL.WordStore.empty [] (f₀ + 1) out
  rw [hws₀.1]
  change UL.runBitRAMFuel inp (f₀ + 1) [.stmt prog]
    (mkBitState UL.WordStore.empty 0 0
      (inp.inputCellSpace + UL.WordStore.empty.cellCount)
      (inp.inputBitSpace + UL.WordStore.empty.bitSize)) = .halted out
  rw [hstep 1]
  dsimp [UL.runBitRAMFuel, mkBitState, out]
  rw [hws₁.1]

theorem ExecBit.skip {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ} {ws : UL.WordStore}
    (hws : StoreBounded 31 maxIdx K ws) :
    ExecBit inp maxIdx K .skip ws ws 1 1 := by
  refine ⟨hws, hws, fun u₀ b₀ pc₀ pb₀ rest =>
    ⟨1, u₀ + 1, b₀ + 1, pc₀, pb₀, le_rfl, le_rfl, le_max_left _ _, le_max_left _ _, fun fuel => ?_⟩⟩
  rw [Nat.add_comm 1 fuel]
  rfl

theorem ExecBit.seq {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ} {s₁ s₂ : UL.BitRAMStmt}
    {ws₀ ws₁ ws₂ : UL.WordStore} {U₁ B₁ U₂ B₂ : ℕ}
    (h₁ : ExecBit inp maxIdx K s₁ ws₀ ws₁ U₁ B₁)
    (h₂ : ExecBit inp maxIdx K s₂ ws₁ ws₂ U₂ B₂) :
    ExecBit inp maxIdx K (.seq s₁ s₂) ws₀ ws₂ (U₁ + U₂) (B₁ + B₂) := by
  refine ⟨h₁.1, h₂.2.1, fun u₀ b₀ pc₀ pb₀ rest => ?_⟩
  rcases h₁.2.2 u₀ b₀ pc₀ pb₀ (.stmt s₂ :: rest) with
    ⟨f₁, u₁, b₁, pc₁, pb₁, hu₁, hb₁, hpc₁, hpb₁, hs₁⟩
  rcases h₂.2.2 u₁ b₁ pc₁ pb₁ rest with
    ⟨f₂, u₂, b₂, pc₂, pb₂, hu₂, hb₂, hpc₂, hpb₂, hs₂⟩
  refine ⟨1 + f₁ + f₂, u₂, b₂, pc₂, pb₂, by omega, by omega,
    hpc₂.trans (max_le hpc₁ (le_max_right _ _)),
    hpb₂.trans (max_le hpb₁ (le_max_right _ _)), fun fuel => ?_⟩
  have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
  rw [hfuel]
  dsimp only [UL.runBitRAMFuel]
  rw [hs₁ (f₂ + fuel), hs₂ fuel]

theorem ExecBit.writeHeap {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    {ws : UL.WordStore} (hws : StoreBounded 31 maxIdx K ws)
    (t : ℕ) (idxE valE : UL.IntExpr)
    (ht : t ≤ 31)
    (hwf_i : exprWf 31 idxE = true)
    (hwf_v : exprWf 31 valE = true)
    (hi0 : 0 ≤ evalVal inp ws idxE)
    (hi1 : evalVal inp ws idxE ≤ (maxIdx : ℤ))
    (hv : (evalVal inp ws valE).natAbs ≤ 2 ^ K) :
    let N_tot := exprNodes idxE + exprNodes valE + 2
    let L_tot := exprLeaves idxE + exprLeaves valE + 2
    ExecBit inp maxIdx K (.writeHeap t idxE valE) ws
      (hWrite ws t (evalVal inp ws idxE) (evalVal inp ws valE))
      N_tot (N_tot * (2 * L_tot * K) ^ 2) := by
  intro N_tot L_tot
  have hK := hctx.hK
  have hT31 : UL.natBitLength 31 ≤ 2 * K := by
    have : UL.natBitLength 31 = 5 := by decide
    omega
  obtain ⟨_, hui, hbi⟩ := evalIntExpr_cost_bound hK hT31 hctx.hInp hws idxE hwf_i
  obtain ⟨_, huv, hbv⟩ := evalIntExpr_cost_bound hK hT31 hctx.hInp hws valE hwf_v
  let idx := evalVal inp ws idxE
  let val := evalVal inp ws valE
  let ws' := hWrite ws t idx val
  have hws' : StoreBounded 31 maxIdx K ws' := storeBounded_write hws ht hi0 hi1 hv
  obtain ⟨hcells, hbits⟩ := storeBounded_space_le hws' hctx.hMaxIdx
  have hpc_le : inp.inputCellSpace + ws'.cellCount ≤ ctxPeakCells inp maxIdx := by
    dsimp [ctxPeakCells]; omega
  have hpb_le : inp.inputBitSpace + ws'.bitSize ≤ ctxPeakBits inp maxIdx K := by
    have ht5 : UL.natBitLength 31 = 5 := by decide
    rw [ht5] at hbits
    dsimp [ctxPeakBits]
    calc inp.inputBitSpace + ws'.bitSize
        ≤ inp.inputBitSpace + 32 * (maxIdx + 1) * (5 + 2 * K + 8) := Nat.add_le_add_left hbits _
      _ ≤ inp.inputBitSpace + 32 * (maxIdx + 1) * (2 * K + 14) :=
          Nat.add_le_add_left (Nat.mul_le_mul_left _ (by omega)) _
  refine ⟨hws, hws', fun u₀ b₀ pc₀ pb₀ rest => ?_⟩
  let u₁ := (UL.evalIntExpr inp 0 ws idxE).2.1
  let b₁ := (UL.evalIntExpr inp 0 ws idxE).2.2
  let u₂ := (UL.evalIntExpr inp 0 ws valE).2.1
  let b₂ := (UL.evalIntExpr inp 0 ws valE).2.2
  let loc := UL.RAMCellLoc.heap t idx
  have hL_ge2 : 2 ≤ L_tot := by dsimp [L_tot]; omega
  have h2LK : 2 * 2 * K ≤ 2 * L_tot * K := two_mul_mono hL_ge2
  have hloc_b : loc.bitLength ≤ 2 * L_tot * K := by
    unfold UL.RAMCellLoc.bitLength
    have ht_b : UL.natBitLength t ≤ 5 :=
      (natBitLength_mono ht).trans (by decide : UL.natBitLength 31 = 5).le
    have hi_b : UL.intBitLength idx ≤ K + 3 := by
      have hi_abs : idx.natAbs ≤ 2 ^ K := by
        have : idx.natAbs ≤ maxIdx := by omega
        exact this.trans hctx.hMaxIdx
      exact intBitLength_le_of_natAbs_le_two_pow hi_abs
    calc UL.natBitLength t + UL.intBitLength idx
        ≤ 5 + (K + 3) := Nat.add_le_add ht_b hi_b
      _ ≤ 2 * 2 * K := by omega
      _ ≤ 2 * L_tot * K := h2LK
  have hval_b : UL.intBitLength val ≤ 2 * L_tot * K := by
    have hv_b := intBitLength_le_of_natAbs_le_two_pow hv
    calc UL.intBitLength val ≤ K + 3 := hv_b
      _ ≤ 2 * 2 * K := by omega
      _ ≤ 2 * L_tot * K := h2LK
  have hMi := two_mul_mono (K := K) (by dsimp [L_tot]; omega : exprLeaves idxE ≤ L_tot)
  have hMv := two_mul_mono (K := K) (by dsimp [L_tot]; omega : exprLeaves valE ≤ L_tot)
  have hbi' := hbi.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hMi 2))
  have hbv' := hbv.trans (Nat.mul_le_mul_left _ (Nat.pow_le_pow_left hMv 2))
  have hM12 := two_mul_L_K_ge hK (by omega : 1 ≤ L_tot)
  have hbcost : b₁ + b₂ + loc.bitLength + UL.intBitLength val ≤ N_tot * (2 * L_tot * K) ^ 2 :=
    nat_cost_write hbi' hbv' hloc_b hval_b (by omega)
  refine ⟨1, u₀ + u₁ + u₂ + 1, b₀ + b₁ + b₂ + loc.bitLength + UL.intBitLength val,
    max pc₀ (inp.inputCellSpace + ws'.cellCount),
    max pb₀ (inp.inputBitSpace + ws'.bitSize),
    by dsimp [N_tot]; omega,
    by omega,
    max_le_max_left pc₀ hpc_le,
    max_le_max_left pb₀ hpb_le,
    fun fuel => ?_⟩
  rw [Nat.add_comm 1 fuel]
  rfl

theorem ExecBit.ite_true {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    {ws₀ ws₁ : UL.WordStore} (cond : UL.BitCondExpr) (tB fB : UL.BitRAMStmt)
    {U_b B_b : ℕ}
    (hwf_c : condWf 31 cond = true)
    (hcond : evalCondVal inp ws₀ cond = true)
    (ht : ExecBit inp maxIdx K tB ws₀ ws₁ U_b B_b) :
    ExecBit inp maxIdx K (.ite cond tB fB) ws₀ ws₁
      (condNodes cond + U_b)
      (condNodes cond * (2 * condLeaves cond * K) ^ 2 + B_b) := by
  have hT31 : UL.natBitLength 31 ≤ 2 * K := by
    have : UL.natBitLength 31 = 5 := by decide
    have := hctx.hK; omega
  obtain ⟨huc, hbc⟩ := evalBitCond_cost_bound hctx.hK hT31 hctx.hInp ht.1 cond hwf_c
  refine ⟨ht.1, ht.2.1, fun u₀ b₀ pc₀ pb₀ rest => ?_⟩
  let uc := (UL.evalBitCond inp 0 ws₀ cond).2.1
  let bc := (UL.evalBitCond inp 0 ws₀ cond).2.2
  rcases ht.2.2 (u₀ + uc) (b₀ + bc) pc₀ pb₀ rest with
    ⟨f₁, u₁, b₁, pc₁, pb₁, hu₁, hb₁, hpc₁, hpb₁, hs₁⟩
  refine ⟨1 + f₁, u₁, b₁, pc₁, pb₁, by omega, by omega, hpc₁, hpb₁, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  dsimp only [UL.runBitRAMFuel, mkBitState]
  have hflag : (UL.evalBitCond inp 0 ws₀ cond).1 = true := hcond
  simp only [hflag, ↓reduceIte]
  exact hs₁ fuel

theorem ExecBit.ite_false {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    {ws₀ ws₁ : UL.WordStore} (cond : UL.BitCondExpr) (tB fB : UL.BitRAMStmt)
    {U_b B_b : ℕ}
    (hwf_c : condWf 31 cond = true)
    (hcond : evalCondVal inp ws₀ cond = false)
    (hf : ExecBit inp maxIdx K fB ws₀ ws₁ U_b B_b) :
    ExecBit inp maxIdx K (.ite cond tB fB) ws₀ ws₁
      (condNodes cond + U_b)
      (condNodes cond * (2 * condLeaves cond * K) ^ 2 + B_b) := by
  have hT31 : UL.natBitLength 31 ≤ 2 * K := by
    have : UL.natBitLength 31 = 5 := by decide
    have := hctx.hK; omega
  obtain ⟨huc, hbc⟩ := evalBitCond_cost_bound hctx.hK hT31 hctx.hInp hf.1 cond hwf_c
  refine ⟨hf.1, hf.2.1, fun u₀ b₀ pc₀ pb₀ rest => ?_⟩
  let uc := (UL.evalBitCond inp 0 ws₀ cond).2.1
  let bc := (UL.evalBitCond inp 0 ws₀ cond).2.2
  rcases hf.2.2 (u₀ + uc) (b₀ + bc) pc₀ pb₀ rest with
    ⟨f₁, u₁, b₁, pc₁, pb₁, hu₁, hb₁, hpc₁, hpb₁, hs₁⟩
  refine ⟨1 + f₁, u₁, b₁, pc₁, pb₁, by omega, by omega, hpc₁, hpb₁, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  dsimp only [UL.runBitRAMFuel, mkBitState]
  have hflag : (UL.evalBitCond inp 0 ws₀ cond).1 = false := hcond
  simp only [hflag, Bool.false_eq_true, ↓reduceIte]
  exact hs₁ fuel

theorem ExecBit.repeatN_nat {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    (countE : UL.IntExpr) (body : UL.BitRAMStmt)
    (N U_b B_b : ℕ) (Inv : ℕ → UL.WordStore → Prop)
    {ws₀ : UL.WordStore}
    (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hInv₀ : Inv 0 ws₀)
    (hwf_cnt : exprWf 31 countE = true)
    (hcnt : evalVal inp ws₀ countE = (N : ℤ))
    (hstep : ∀ i < N, ∀ ws : UL.WordStore, StoreBounded 31 maxIdx K ws → Inv i ws →
      ∃ ws', ExecBit inp maxIdx K body ws ws' U_b B_b ∧ Inv (i + 1) ws') :
    ∃ ws_N : UL.WordStore,
      Inv N ws_N ∧
      ExecBit inp maxIdx K (.repeatN countE body) ws₀ ws_N
        (exprNodes countE + N * U_b)
        (exprNodes countE * (2 * exprLeaves countE * K) ^ 2 + N * B_b) := by
  have hT31 : UL.natBitLength 31 ≤ 2 * K := by
    have : UL.natBitLength 31 = 5 := by decide
    have := hctx.hK; omega
  obtain ⟨_, huc, hbc⟩ := evalIntExpr_cost_bound hctx.hK hT31 hctx.hInp hws₀ countE hwf_cnt
  have hloop : ∀ k : ℕ, k ≤ N → ∀ ws : UL.WordStore, StoreBounded 31 maxIdx K ws → Inv (N - k) ws →
      ∃ ws_N : UL.WordStore, StoreBounded 31 maxIdx K ws_N ∧ Inv N ws_N ∧
        ∀ (u₀ b₀ pc₀ pb₀ : ℕ) (rest : List UL.BitRAMCont),
          ∃ (fuel₀ u₁ b₁ pc₁ pb₁ : ℕ),
            u₁ ≤ u₀ + k * U_b ∧
            b₁ ≤ b₀ + k * B_b ∧
            pc₁ ≤ max pc₀ (ctxPeakCells inp maxIdx) ∧
            pb₁ ≤ max pb₀ (ctxPeakBits inp maxIdx K) ∧
            ∀ fuel : ℕ,
              UL.runBitRAMFuel inp (fuel₀ + fuel) (.repeatLoop k body :: rest) (mkBitState ws u₀ b₀ pc₀ pb₀) =
              UL.runBitRAMFuel inp fuel rest (mkBitState ws_N u₁ b₁ pc₁ pb₁) := by
    intro k
    induction k with
    | zero =>
        intro _ ws hws hIm
        rw [Nat.sub_zero] at hIm
        refine ⟨ws, hws, hIm, fun u₀ b₀ pc₀ pb₀ rest =>
          ⟨1, u₀, b₀, pc₀, pb₀, by simp, by simp, le_max_left _ _, le_max_left _ _, fun fuel => ?_⟩⟩
        rw [Nat.add_comm 1 fuel]; rfl
    | succ k ih =>
        intro hk ws hws hIm
        have hi_lt : N - (k + 1) < N := by omega
        have hsucc : N - (k + 1) + 1 = N - k := by omega
        rcases hstep (N - (k + 1)) hi_lt ws hws hIm with ⟨ws', hbody, hIm'⟩
        rw [hsucc] at hIm'
        rcases ih (by omega) ws' hbody.2.1 hIm' with ⟨ws_N, hws_N, hIm_N, hrest⟩
        refine ⟨ws_N, hws_N, hIm_N, fun u₀ b₀ pc₀ pb₀ rest => ?_⟩
        rcases hbody.2.2 u₀ b₀ pc₀ pb₀ (.repeatLoop k body :: rest) with
          ⟨f₁, u₁, b₁, pc₁, pb₁, hu₁, hb₁, hpc₁, hpb₁, hs₁⟩
        rcases hrest u₁ b₁ pc₁ pb₁ rest with
          ⟨f₂, u₂, b₂, pc₂, pb₂, hu₂, hb₂, hpc₂, hpb₂, hs₂⟩
        refine ⟨1 + f₁ + f₂, u₂, b₂, pc₂, pb₂, ?_, ?_,
          hpc₂.trans (max_le hpc₁ (le_max_right _ _)),
          hpb₂.trans (max_le hpb₁ (le_max_right _ _)), fun fuel => ?_⟩
        · calc u₂ ≤ u₀ + U_b + k * U_b := by omega
            _ = u₀ + (k + 1) * U_b := by ring
        · calc b₂ ≤ b₀ + B_b + k * B_b := by omega
            _ = b₀ + (k + 1) * B_b := by ring
        · have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
          rw [hfuel]
          dsimp only [UL.runBitRAMFuel]
          rw [hs₁ (f₂ + fuel), hs₂ fuel]
  rcases hloop N le_rfl ws₀ hws₀ (by simpa using hInv₀) with ⟨ws_N, hws_N, hIm_N, hrun⟩
  refine ⟨ws_N, hIm_N, hws₀, hws_N, fun u₀ b₀ pc₀ pb₀ rest => ?_⟩
  let uc := (UL.evalIntExpr inp 0 ws₀ countE).2.1
  let bc := (UL.evalIntExpr inp 0 ws₀ countE).2.2
  rcases hrun (u₀ + uc) (b₀ + bc) pc₀ pb₀ rest with
    ⟨f₁, u₁, b₁, pc₁, pb₁, hu₁, hb₁, hpc₁, hpb₁, hs₁⟩
  refine ⟨1 + f₁, u₁, b₁, pc₁, pb₁, by omega, by omega, hpc₁, hpb₁, fun fuel => ?_⟩
  have hfuel : 1 + f₁ + fuel = (f₁ + fuel) + 1 := by omega
  rw [hfuel]
  dsimp only [UL.runBitRAMFuel, mkBitState]
  have hval : (UL.evalIntExpr inp 0 ws₀ countE).1 = (N : ℤ) := hcnt
  have hnIter : (if (0 : ℤ) ≤ (N : ℤ) then ((N : ℤ)).toNat else 0) = N := by simp
  simp only [hval, hnIter]
  exact hs₁ fuel

theorem ExecBit.whileLoop_nat {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    (cond : UL.BitCondExpr) (body : UL.BitRAMStmt)
    (N U_b B_b : ℕ) (Inv : ℕ → UL.WordStore → Prop)
    {ws₀ : UL.WordStore}
    (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hInv₀ : Inv 0 ws₀)
    (hwf_c : condWf 31 cond = true)
    (hstep : ∀ i < N, ∀ ws : UL.WordStore, StoreBounded 31 maxIdx K ws → Inv i ws →
      evalCondVal inp ws cond = true ∧
      ∃ ws', ExecBit inp maxIdx K body ws ws' U_b B_b ∧ Inv (i + 1) ws')
    (hexit : ∀ ws : UL.WordStore, StoreBounded 31 maxIdx K ws → Inv N ws →
      evalCondVal inp ws cond = false) :
    let U_c := condNodes cond
    let B_c := condNodes cond * (2 * condLeaves cond * K) ^ 2
    ∃ ws_N : UL.WordStore,
      Inv N ws_N ∧
      ExecBit inp maxIdx K (.whileLoop cond body) ws₀ ws_N
        ((N + 1) * U_c + N * U_b)
        ((N + 1) * B_c + N * B_b) := by
  intro U_c B_c
  have hT31 : UL.natBitLength 31 ≤ 2 * K := by
    have : UL.natBitLength 31 = 5 := by decide
    have := hctx.hK; omega
  suffices hrem : ∀ k : ℕ, k ≤ N → ∀ ws : UL.WordStore, StoreBounded 31 maxIdx K ws → Inv (N - k) ws →
      ∃ ws_N : UL.WordStore,
        Inv N ws_N ∧
        ExecBit inp maxIdx K (.whileLoop cond body) ws ws_N
          ((k + 1) * U_c + k * U_b)
          ((k + 1) * B_c + k * B_b) by
    simpa using hrem N le_rfl ws₀ hws₀ (by simpa using hInv₀)
  intro k
  induction k with
  | zero =>
      intro _ ws hws hIm
      rw [Nat.sub_zero] at hIm
      have hfalse := hexit ws hws hIm
      obtain ⟨huc, hbc⟩ := evalBitCond_cost_bound hctx.hK hT31 hctx.hInp hws cond hwf_c
      refine ⟨ws, hIm, hws, hws, fun u₀ b₀ pc₀ pb₀ rest => ?_⟩
      let uc := (UL.evalBitCond inp 0 ws cond).2.1
      let bc := (UL.evalBitCond inp 0 ws cond).2.2
      refine ⟨1, u₀ + uc, b₀ + bc, pc₀, pb₀,
        by simp only [Nat.zero_add, one_mul, zero_mul, add_zero]; exact Nat.add_le_add_left huc u₀,
        by simp only [Nat.zero_add, one_mul, zero_mul, add_zero]; exact Nat.add_le_add_left hbc b₀,
        le_max_left _ _, le_max_left _ _, fun fuel => ?_⟩
      rw [Nat.add_comm 1 fuel]
      dsimp only [UL.runBitRAMFuel, mkBitState]
      have hf : (UL.evalBitCond inp 0 ws cond).1 = false := hfalse
      simp [hf, uc, bc]
  | succ k ih =>
      intro hk ws hws hIm
      have hi_lt : N - (k + 1) < N := by omega
      have hsucc : N - (k + 1) + 1 = N - k := by omega
      obtain ⟨htrue, ws', hbody, hIm'⟩ := hstep (N - (k + 1)) hi_lt ws hws hIm
      rw [hsucc] at hIm'
      obtain ⟨ws_N, hIm_N, hrest⟩ := ih (by omega) ws' hbody.2.1 hIm'
      obtain ⟨huc, hbc⟩ := evalBitCond_cost_bound hctx.hK hT31 hctx.hInp hws cond hwf_c
      refine ⟨ws_N, hIm_N, hws, hrest.2.1, fun u₀ b₀ pc₀ pb₀ rest => ?_⟩
      let uc := (UL.evalBitCond inp 0 ws cond).2.1
      let bc := (UL.evalBitCond inp 0 ws cond).2.2
      rcases hbody.2.2 (u₀ + uc) (b₀ + bc) pc₀ pb₀ (.stmt (.whileLoop cond body) :: rest) with
        ⟨f₁, u₁, b₁, pc₁, pb₁, hu₁, hb₁, hpc₁, hpb₁, hs₁⟩
      rcases hrest.2.2 u₁ b₁ pc₁ pb₁ rest with
        ⟨f₂, u₂, b₂, pc₂, pb₂, hu₂, hb₂, hpc₂, hpb₂, hs₂⟩
      refine ⟨1 + f₁ + f₂, u₂, b₂, pc₂, pb₂, ?_, ?_,
        hpc₂.trans (max_le hpc₁ (le_max_right _ _)),
        hpb₂.trans (max_le hpb₁ (le_max_right _ _)), fun fuel => ?_⟩
      · have h1 : uc ≤ U_c := huc
        calc u₂ ≤ u₀ + uc + U_b + ((k + 1) * U_c + k * U_b) := by omega
          _ ≤ u₀ + U_c + U_b + ((k + 1) * U_c + k * U_b) := by omega
          _ = u₀ + ((k + 2) * U_c + (k + 1) * U_b) := by ring
      · have h1 : bc ≤ B_c := hbc
        calc b₂ ≤ b₀ + bc + B_b + ((k + 1) * B_c + k * B_b) := by omega
          _ ≤ b₀ + B_c + B_b + ((k + 1) * B_c + k * B_b) := by omega
          _ = b₀ + ((k + 2) * B_c + (k + 1) * B_b) := by ring
      · have hfuel : 1 + f₁ + f₂ + fuel = (f₁ + (f₂ + fuel)) + 1 := by omega
        rw [hfuel]
        dsimp only [UL.runBitRAMFuel, mkBitState]
        have ht : (UL.evalBitCond inp 0 ws cond).1 = true := htrue
        simp only [ht, ↓reduceIte]
        dsimp only [mkBitState, uc, bc] at hs₁ hs₂
        rw [hs₁ (f₂ + fuel), hs₂ fuel]

def seqBitStmts : List UL.BitRAMStmt → UL.BitRAMStmt
  | [] => .skip
  | [s] => s
  | s :: ss => .seq s (seqBitStmts ss)

/-- Indexed `for`-loop storing its `0 .. N-1` counter in `.heap 10 ctrSlot`. -/
def forLoopStmt (ctrSlot : ℤ) (countE : UL.IntExpr) (body : UL.BitRAMStmt) : UL.BitRAMStmt :=
  .seq (.writeHeap 10 (.lit ctrSlot) (.lit 0))
    (.repeatN countE
      (.seq body
        (.writeHeap 10 (.lit ctrSlot) (.add (.readHeap 10 (.lit ctrSlot)) (.lit 1)))))

theorem exec_forLoopStmt {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    (ctrSlot : ℤ) (countE : UL.IntExpr) (body : UL.BitRAMStmt)
    (N U_b B_b : ℕ) (Inv : ℕ → UL.WordStore → Prop)
    {ws₀ : UL.WordStore}
    (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hslot_wf : ctrSlot.natAbs ≤ 64)
    (hslot0 : 0 ≤ ctrSlot) (hslot1 : ctrSlot ≤ (maxIdx : ℤ))
    (hN_le : N ≤ maxIdx)
    (hwf_cnt : exprWf 31 countE = true)
    (hcnt : evalVal inp (hWrite ws₀ 10 ctrSlot 0) countE = (N : ℤ))
    (hInv₀ : Inv 0 (hWrite ws₀ 10 ctrSlot 0))
    (hstep : ∀ k < N, ∀ ws : UL.WordStore,
      StoreBounded 31 maxIdx K ws →
      hRead ws 10 ctrSlot = (k : ℤ) →
      Inv k ws →
      ∃ ws', ExecBit inp maxIdx K body ws ws' U_b B_b ∧
        hRead ws' 10 ctrSlot = (k : ℤ) ∧
        Inv (k + 1) (hWrite ws' 10 ctrSlot ((k : ℤ) + 1))) :
    ∃ ws_N : UL.WordStore,
      hRead ws_N 10 ctrSlot = (N : ℤ) ∧
      Inv N ws_N ∧
      ExecBit inp maxIdx K (forLoopStmt ctrSlot countE body) ws₀ ws_N
        (10 + exprNodes countE + N * (U_b + 10))
        (1000 * K ^ 2 + exprNodes countE * (2 * exprLeaves countE * K) ^ 2 +
          N * (B_b + 2000 * K ^ 2)) := by
  have hwf_slot : exprWf 31 (.lit ctrSlot) = true := by simp [exprWf, hslot_wf]
  have hwf_0 : exprWf 31 (.lit 0) = true := by decide
  have h0_init : ExecBit inp maxIdx K (.writeHeap 10 (.lit ctrSlot) (.lit 0)) ws₀
      (hWrite ws₀ 10 ctrSlot 0) 4 (4 * (8 * K) ^ 2) :=
    ExecBit.writeHeap hctx hws₀ 10 (.lit ctrSlot) (.lit 0) (by omega)
      hwf_slot hwf_0 hslot0 hslot1 (by simp)
  let FullInv : ℕ → UL.WordStore → Prop := fun k ws =>
    hRead ws 10 ctrSlot = (k : ℤ) ∧ Inv k ws
  have hFull0 : FullInv 0 (hWrite ws₀ 10 ctrSlot 0) :=
    ⟨by simp, hInv₀⟩
  have hwf_inc : exprWf 31 (.add (.readHeap 10 (.lit ctrSlot)) (.lit 1)) = true := by
    simp [exprWf, hslot_wf]
  obtain ⟨ws_N, ⟨hctrN, hInvN⟩, hrep⟩ := ExecBit.repeatN_nat hctx countE
    (.seq body (.writeHeap 10 (.lit ctrSlot) (.add (.readHeap 10 (.lit ctrSlot)) (.lit 1))))
    N (U_b + 7) (B_b + 7 * (12 * K) ^ 2) FullInv h0_init.2.1 hFull0 hwf_cnt hcnt
    (fun k hk ws hws ⟨hctr, hIk⟩ => by
      obtain ⟨ws', hbody, hctr', hIk1⟩ := hstep k hk ws hws hctr hIk
      have hk1_abs : ((k : ℤ) + 1).natAbs ≤ 2 ^ K := by
        have : ((k : ℤ) + 1).natAbs ≤ maxIdx := by omega
        exact this.trans hctx.hMaxIdx
      have hinc : ExecBit inp maxIdx K
          (.writeHeap 10 (.lit ctrSlot) (.add (.readHeap 10 (.lit ctrSlot)) (.lit 1)))
          ws' (hWrite ws' 10 ctrSlot ((k : ℤ) + 1)) 7 (7 * (12 * K) ^ 2) := by
        have hval_eq : evalVal inp ws' (.add (.readHeap 10 (.lit ctrSlot)) (.lit 1)) =
            (k : ℤ) + 1 := by simp [hctr']
        have hw := ExecBit.writeHeap hctx hbody.2.1 10 (.lit ctrSlot)
          (.add (.readHeap 10 (.lit ctrSlot)) (.lit 1)) (by omega) hwf_slot hwf_inc
          hslot0 hslot1 (by rw [hval_eq]; exact hk1_abs)
        dsimp only [exprNodes, exprLeaves] at hw
        rw [hval_eq] at hw
        exact hw
      refine ⟨hWrite ws' 10 ctrSlot ((k : ℤ) + 1), hbody.seq hinc, ?_, hIk1⟩
      rw [hRead_hWrite_self]
      push_cast; ring)
  refine ⟨ws_N, hctrN, hInvN, (h0_init.seq hrep).mono ?_ ?_⟩
  · have hmul : N * (U_b + 7) ≤ N * (U_b + 10) := Nat.mul_le_mul_left N (by omega)
    omega
  · have h1 : 4 * (8 * K) ^ 2 ≤ 1000 * K ^ 2 := by
      calc 4 * (8 * K) ^ 2 = 256 * K ^ 2 := by ring
        _ ≤ 1000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)
    have h2 : N * (B_b + 7 * (12 * K) ^ 2) ≤ N * (B_b + 2000 * K ^ 2) := by
      refine Nat.mul_le_mul_left N (Nat.add_le_add_left ?_ B_b)
      calc 7 * (12 * K) ^ 2 = 1008 * K ^ 2 := by ring
        _ ≤ 2000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)
    omega

/-- Compute `(2 : ℤ) ^ exp` into `.heap dstT dstIdx` using `repeatN expE`. -/
def pow2Stmt (dstT : ℕ) (dstIdxE expE : UL.IntExpr) : UL.BitRAMStmt :=
  .seq (.writeHeap dstT dstIdxE (.lit 1))
    (.repeatN expE
      (.writeHeap dstT dstIdxE (.mul (.lit 2) (.readHeap dstT dstIdxE))))

theorem exec_pow2Stmt {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (dstT : ℕ) (dstIdx : ℤ) (exp : ℕ) (expE : UL.IntExpr)
    (ht : dstT ≤ 31)
    (hdst_wf : dstIdx.natAbs ≤ 64)
    (hdst0 : 0 ≤ dstIdx) (hdst1 : dstIdx ≤ (maxIdx : ℤ))
    (hexp_le : exp ≤ K)
    (hwf_exp : exprWf 31 expE = true)
    (hexp_val : evalVal inp (hWrite ws₀ dstT dstIdx 1) expE = (exp : ℤ)) :
    ∃ ws₁ : UL.WordStore,
      hRead ws₁ dstT dstIdx = (2 : ℤ) ^ exp ∧
      (∀ t i, (t ≠ dstT ∨ i ≠ dstIdx) → hRead ws₁ t i = hRead ws₀ t i) ∧
      ExecBit inp maxIdx K (pow2Stmt dstT (.lit dstIdx) expE) ws₀ ws₁
        (10 + exprNodes expE + exp * 10)
        (1000 * K ^ 2 + exprNodes expE * (2 * exprLeaves expE * K) ^ 2 + exp * (2000 * K ^ 2)) := by
  have hwf_dst : exprWf 31 (.lit dstIdx) = true := by simp [exprWf, hdst_wf]
  have h1_abs : (1 : ℤ).natAbs ≤ 2 ^ K := Nat.one_le_two_pow
  have hinit : ExecBit inp maxIdx K (.writeHeap dstT (.lit dstIdx) (.lit 1)) ws₀
      (hWrite ws₀ dstT dstIdx 1) 4 (4 * (8 * K) ^ 2) :=
    ExecBit.writeHeap hctx hws₀ dstT (.lit dstIdx) (.lit 1) ht hwf_dst (by decide)
      hdst0 hdst1 h1_abs
  let Inv : ℕ → UL.WordStore → Prop := fun k ws =>
    hRead ws dstT dstIdx = (2 : ℤ) ^ k ∧
    (∀ t i, (t ≠ dstT ∨ i ≠ dstIdx) → hRead ws t i = hRead ws₀ t i)
  have hInv0 : Inv 0 (hWrite ws₀ dstT dstIdx 1) :=
    ⟨by simp, fun t i hne => hRead_hWrite_of_ne ws₀ 1 hne⟩
  have hwf_mul : exprWf 31 (.mul (.lit 2) (.readHeap dstT (.lit dstIdx))) = true := by
    simp [exprWf, ht, hdst_wf]
  obtain ⟨ws₁, ⟨hpow, hframe⟩, hrep⟩ := ExecBit.repeatN_nat hctx expE
    (.writeHeap dstT (.lit dstIdx) (.mul (.lit 2) (.readHeap dstT (.lit dstIdx))))
    exp 7 (7 * (12 * K) ^ 2) Inv hinit.2.1 hInv0 hwf_exp hexp_val
    (fun k hk ws hws ⟨hk_pow, hk_fr⟩ => by
      have hval_eq : evalVal inp ws (.mul (.lit 2) (.readHeap dstT (.lit dstIdx))) =
          (2 : ℤ) ^ (k + 1) := by
        simp [hk_pow, pow_succ']
      have hk1_abs : ((2 : ℤ) ^ (k + 1)).natAbs ≤ 2 ^ K := by
        have : 2 ^ (k + 1) ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) (by omega)
        simpa using this
      have hw := ExecBit.writeHeap hctx hws dstT (.lit dstIdx)
        (.mul (.lit 2) (.readHeap dstT (.lit dstIdx))) ht hwf_dst hwf_mul hdst0 hdst1
        (by rw [hval_eq]; exact hk1_abs)
      dsimp only [exprNodes, exprLeaves, evalVal_lit] at hw
      rw [hval_eq] at hw
      refine ⟨hWrite ws dstT dstIdx ((2 : ℤ) ^ (k + 1)), hw, by simp, fun t i hne => ?_⟩
      rw [hRead_hWrite_of_ne ws _ hne, hk_fr t i hne])
  refine ⟨ws₁, hpow, hframe, (hinit.seq hrep).mono ?_ ?_⟩
  · have hmul : exp * 7 ≤ exp * 10 := Nat.mul_le_mul_left exp (by omega)
    omega
  · have h1 : 4 * (8 * K) ^ 2 ≤ 1000 * K ^ 2 := by
      calc 4 * (8 * K) ^ 2 = 256 * K ^ 2 := by ring
        _ ≤ 1000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)
    have h2 : exp * (7 * (12 * K) ^ 2) ≤ exp * (2000 * K ^ 2) := by
      refine Nat.mul_le_mul_left exp ?_
      calc 7 * (12 * K) ^ 2 = 1008 * K ^ 2 := by ring
        _ ≤ 2000 * K ^ 2 := Nat.mul_le_mul_right _ (by omega)
    omega

end UL.Proof.cit_gls88_rational_lp.RacerCG
