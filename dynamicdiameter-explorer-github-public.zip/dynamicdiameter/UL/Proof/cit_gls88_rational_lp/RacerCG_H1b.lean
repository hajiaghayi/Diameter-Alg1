import Mathlib
import UL.Proof.cit_gls88_rational_lp.RacerCG_H1a
set_option autoImplicit false

open scoped Matrix

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

@[simp] private theorem castRingHom_apply_rat (z : ℤ) : (Int.castRingHom ℚ) z = (z : ℚ) := rfl

/-- Non-dependent `snoc` on `Fin k → α`. -/
def snocFin {k : ℕ} {α : Type*} (f : Fin k → α) (x : α) : Fin (k + 1) → α :=
  Fin.lastCases x f

@[simp] theorem snocFin_last {k : ℕ} {α : Type*} (f : Fin k → α) (x : α) :
    snocFin f x (Fin.last k) = x := Fin.lastCases_last

@[simp] theorem snocFin_castSucc {k : ℕ} {α : Type*} (f : Fin k → α) (x : α) (i : Fin k) :
    snocFin f x i.castSucc = f i := Fin.lastCases_castSucc i

/-! ### Bareiss Fraction-Free Gauss-Jordan Elimination -/

/-- Determinant of a `(k + 1) × (k + 1)` matrix whose top-right `k × 1` entries vanish:
equals `(top-left k × k det) * (bottom-right entry)`. -/
theorem det_snoc_of_topRight_zero {k : ℕ} (H : Matrix (Fin (k + 1)) (Fin (k + 1)) ℚ)
    (hz : ∀ p : Fin k, H p.castSucc (Fin.last k) = 0) :
    H.det = (H.submatrix Fin.castSucc Fin.castSucc).det * H (Fin.last k) (Fin.last k) := by
  rw [Matrix.det_succ_column _ (Fin.last k)]
  rw [Fin.sum_univ_castSucc]
  have hZero : ∑ p : Fin k,
      (-1 : ℚ) ^ (p.castSucc.val + (Fin.last k).val) * H p.castSucc (Fin.last k) *
        (H.submatrix p.castSucc.succAbove (Fin.last k).succAbove).det = 0 := by
    refine Finset.sum_eq_zero (fun p _ => ?_)
    simp [hz p]
  rw [hZero, zero_add]
  have hSign : (-1 : ℚ) ^ ((Fin.last k).val + (Fin.last k).val) = 1 := by
    simp only [Fin.val_last]
    rw [← two_mul, pow_mul]
    norm_num
  have hSucc : (Fin.last k).succAbove = Fin.castSucc := Fin.succAbove_last
  rw [hSign, one_mul, hSucc]
  ring

/-- Fundamental Schur-Cramer identity over `ℚ`: if `B.mulVec u = col_j`, then
the bordered `(k + 1) × (k + 1)` matrix `D = [B, col_j; row_i, m_ij]` has
`D.det = B.det * (m_ij - ∑ q, row_i q * u q)`. -/
theorem det_bordered_eq_mul_schur {k : ℕ}
    (B : Matrix (Fin k) (Fin k) ℚ) (col_j row_i : Fin k → ℚ) (m_ij : ℚ)
    (u : Fin k → ℚ) (hu : B.mulVec u = col_j) :
    let D : Matrix (Fin (k + 1)) (Fin (k + 1)) ℚ := fun p q =>
      Fin.lastCases
        (Fin.lastCases m_ij row_i q)
        (fun p' => Fin.lastCases (col_j p') (B p') q) p
    D.det = B.det * (m_ij - ∑ q : Fin k, row_i q * u q) := by
  intro D
  let U : Matrix (Fin (k + 1)) (Fin (k + 1)) ℚ := fun p q =>
    Fin.lastCases
      (Fin.lastCases 1 (fun _ => 0) q)
      (fun p' => Fin.lastCases (-u p') (fun q' => if p' = q' then 1 else 0) q) p
  have hU_det : U.det = 1 := by
    rw [← Matrix.det_transpose U]
    rw [det_snoc_of_topRight_zero Uᵀ]
    · have hSub : Uᵀ.submatrix Fin.castSucc Fin.castSucc = 1 := by
        ext p q
        simp only [Matrix.submatrix_apply, Matrix.transpose_apply, U, Fin.lastCases_castSucc,
          Matrix.one_apply]
        by_cases hpq : p = q
        · subst hpq; simp
        · have hqp : q ≠ p := Ne.symm hpq; simp [hpq, hqp]
      rw [hSub, Matrix.det_one]
      simp [U]
    · intro p
      simp [Matrix.transpose_apply, U]
  have hDU_zero : ∀ p : Fin k, (D * U) p.castSucc (Fin.last k) = 0 := by
    intro p
    simp only [Matrix.mul_apply, Fin.sum_univ_castSucc, D, U, Fin.lastCases_castSucc,
      Fin.lastCases_last, mul_one]
    have hp := congr_fun hu p
    simp only [Matrix.mulVec, dotProduct] at hp
    have hsum : ∑ q : Fin k, B p q * (-u q) = -(∑ q : Fin k, B p q * u q) := by
      simp only [mul_neg, Finset.sum_neg_distrib]
    rw [hsum, hp]
    ring
  have hDU_sub : (D * U).submatrix Fin.castSucc Fin.castSucc = B := by
    ext p q
    simp only [Matrix.submatrix_apply, Matrix.mul_apply, Fin.sum_univ_castSucc, D, U,
      Fin.lastCases_castSucc, Fin.lastCases_last, mul_zero, add_zero, mul_ite, mul_one]
    simp
  have hDU_bot : (D * U) (Fin.last k) (Fin.last k) = m_ij - ∑ q : Fin k, row_i q * u q := by
    simp only [Matrix.mul_apply, Fin.sum_univ_castSucc, D, U, Fin.lastCases_last,
      Fin.lastCases_castSucc, mul_one]
    have hsum : ∑ q : Fin k, row_i q * (-u q) = -(∑ q : Fin k, row_i q * u q) := by
      simp only [mul_neg, Finset.sum_neg_distrib]
    rw [hsum]
    ring
  calc D.det = D.det * U.det := by rw [hU_det, mul_one]
    _ = (D * U).det := (Matrix.det_mul D U).symm
    _ = ((D * U).submatrix Fin.castSucc Fin.castSucc).det * (D * U) (Fin.last k) (Fin.last k) :=
        det_snoc_of_topRight_zero (D * U) hDU_zero
    _ = B.det * (m_ij - ∑ q : Fin k, row_i q * u q) := by rw [hDU_sub, hDU_bot]

/-- Helper connecting `snocFin` submatrix to `Fin.lastCases` matrix. -/
theorem snoc_submatrix_eq_lastCases {m n k : ℕ} (M : Fin m → Fin n → ℤ)
    (R : Fin k → Fin m) (C : Fin k → Fin n) (i : Fin m) (j : Fin n) :
    (Matrix.of (fun (p : Fin (k + 1)) (q : Fin (k + 1)) =>
      (M (snocFin R i p) (snocFin C j q) : ℚ))) =
    (fun (p : Fin (k + 1)) (q : Fin (k + 1)) =>
      Fin.lastCases
        (Fin.lastCases (M i j : ℚ) (fun q' => (M i (C q') : ℚ)) q)
        (fun p' => Fin.lastCases (M (R p') j : ℚ) (fun q' => (M (R p') (C q') : ℚ)) q) p) := by
  ext p q
  refine Fin.lastCases ?_ (fun p' => ?_) p <;> refine Fin.lastCases ?_ (fun q' => ?_) q <;>
    simp [snocFin_last, snocFin_castSucc]

/-- State of the Bareiss fraction-free Gauss-Jordan elimination loop. -/
structure BareissState (m n : ℕ) where
  A : Fin m → Fin (n + 1) → ℤ
  prevPiv : ℤ
  rowUsed : Fin m → Bool
  pivRowOfCol : Fin n → ℤ

/-- Find the first unused row `r` with `A r c ≠ 0`, returning `-1` if none exists. -/
def findPivotRow {m n : ℕ} (A : Fin m → Fin (n + 1) → ℤ) (rowUsed : Fin m → Bool)
    (c : Fin (n + 1)) : ℤ :=
  Fin.foldl m (fun found r =>
    if found == -1 && !rowUsed r && A r c != 0 then (r.val : ℤ) else found) (-1)

theorem findPivotRow_spec {m n : ℕ} (A : Fin m → Fin (n + 1) → ℤ) (rowUsed : Fin m → Bool)
    (c : Fin (n + 1)) :
    (findPivotRow A rowUsed c = -1 ∧ ∀ r : Fin m, rowUsed r = false → A r c = 0) ∨
    (∃ r₀ : Fin m, findPivotRow A rowUsed c = (r₀.val : ℤ) ∧
      rowUsed r₀ = false ∧ A r₀ c ≠ 0) := by
  let step : ℤ → Fin m → ℤ := fun found r =>
    if found == -1 && !rowUsed r && A r c != 0 then (r.val : ℤ) else found
  suffices h : ∀ k : ℕ, (hk : k ≤ m) →
      let res := Fin.foldl k (fun found (r : Fin k) => step found ⟨r.val, lt_of_lt_of_le r.isLt hk⟩) (-1)
      (res = -1 ∧ ∀ r : Fin m, r.val < k → rowUsed r = false → A r c = 0) ∨
      (∃ r₀ : Fin m, r₀.val < k ∧ res = (r₀.val : ℤ) ∧ rowUsed r₀ = false ∧ A r₀ c ≠ 0) by
    rcases h m le_rfl with ⟨h1, h2⟩ | ⟨r₀, _, h1, h2, h3⟩
    · left
      exact ⟨h1, fun r hr => h2 r r.isLt hr⟩
    · right
      exact ⟨r₀, h1, h2, h3⟩
  intro k
  induction k with
  | zero =>
      intro _
      left
      exact ⟨by simp [Fin.foldl_zero], fun r hr => False.elim (Nat.not_lt_zero _ hr)⟩
  | succ k ih =>
      intro hk
      have hfold : Fin.foldl (k + 1) (fun found (r : Fin (k + 1)) =>
          step found ⟨r.val, lt_of_lt_of_le r.isLt hk⟩) (-1) =
          step (Fin.foldl k (fun found (r : Fin k) =>
            step found ⟨r.val, lt_of_lt_of_le r.isLt (Nat.le_of_succ_le hk)⟩) (-1))
            ⟨k, hk⟩ := by
        rw [Fin.foldl_succ_last]
        rfl
      rw [hfold]
      rcases ih (Nat.le_of_succ_le hk) with ⟨hNeg, hZero⟩ | ⟨r₀, hr₀_lt, hEq, hUnused, hNe⟩
      · rw [hNeg]
        let rk : Fin m := ⟨k, hk⟩
        by_cases hCond : rowUsed rk = false ∧ A rk c ≠ 0
        · right
          refine ⟨rk, Nat.lt_succ_self k, ?_, hCond.1, hCond.2⟩
          simp [step, rk, hCond.1, hCond.2]
        · left
          have hStep : step (-1) rk = -1 := by
            by_cases hu : rowUsed rk = false
            · have ha : A rk c = 0 := by
                by_contra hne
                exact hCond ⟨hu, hne⟩
              simp [step, hu, ha]
            · cases hru : rowUsed rk
              · exact False.elim (hu hru)
              · simp [step, hru]
          rw [hStep]
          refine ⟨rfl, fun r hr hu => ?_⟩
          rcases Nat.lt_succ_iff_lt_or_eq.mp hr with hlt | heq
          · exact hZero r hlt hu
          · have hr_eq : r = rk := Fin.ext heq
            subst hr_eq
            by_contra hne
            exact hCond ⟨hu, hne⟩
      · right
        have hNotNeg1 : (r₀.val : ℤ) ≠ -1 := by omega
        have hStep : step (r₀.val : ℤ) ⟨k, hk⟩ = (r₀.val : ℤ) := by
          simp [step, hNotNeg1]
        rw [hEq, hStep]
        exact ⟨r₀, Nat.lt_succ_of_lt hr₀_lt, rfl, hUnused, hNe⟩

/-- One column step of Bareiss fraction-free Gauss-Jordan elimination. -/
def bareissColStep {m n : ℕ} (st : BareissState m n) (c : Fin n) : BareissState m n :=
  let cCol : Fin (n + 1) := c.castSucc
  let pr := findPivotRow st.A st.rowUsed cCol
  if h : 0 ≤ pr ∧ pr.toNat < m then
    let r₀ : Fin m := ⟨pr.toNat, h.2⟩
    let piv : ℤ := st.A r₀ cCol
    { A := fun i j =>
        if i = r₀ then st.A r₀ j
        else (piv * st.A i j - st.A i cCol * st.A r₀ j) / st.prevPiv
      prevPiv := piv
      rowUsed := fun i => if i = r₀ then true else st.rowUsed i
      pivRowOfCol := fun j => if j = c then (r₀.val : ℤ) else st.pivRowOfCol j }
  else
    st

/-- Initial Bareiss state for `T₀ x = rhs₀`. -/
def bareissInit {m n : ℕ} (T₀ : Fin m → Fin n → ℤ) (rhs₀ : Fin m → ℤ) : BareissState m n :=
  { A := fun i j => Fin.lastCases (rhs₀ i) (T₀ i) j
    prevPiv := 1
    rowUsed := fun _ => false
    pivRowOfCol := fun _ => -1 }

/-- Run all `n` columns of Bareiss elimination. -/
def bareissRun {m n : ℕ} (T₀ : Fin m → Fin n → ℤ) (rhs₀ : Fin m → ℤ) : BareissState m n :=
  Fin.foldl n bareissColStep (bareissInit T₀ rhs₀)

/-- Extract exact rational solution `(solNum, solDen)` with positive denominators. -/
def bareissSolve {m n : ℕ} (T₀ : Fin m → Fin n → ℤ) (rhs₀ : Fin m → ℤ) :
    (Fin n → ℤ) × (Fin n → ℤ) :=
  let st := bareissRun T₀ rhs₀
  let sgn : ℤ := if 0 < st.prevPiv then 1 else -1
  let den : ℤ := sgn * st.prevPiv
  (fun j =>
    let pr := st.pivRowOfCol j
    if h : 0 ≤ pr ∧ pr.toNat < m then
      sgn * st.A ⟨pr.toNat, h.2⟩ (Fin.last n)
    else 0,
   fun j =>
    let pr := st.pivRowOfCol j
    if _ : 0 ≤ pr ∧ pr.toNat < m then den else 1)

/-- Structural invariant of Bareiss elimination after `c` columns (`c ≤ n`). -/
def BareissInv {m n : ℕ} (M : Fin m → Fin (n + 1) → ℤ) (c : ℕ) (st : BareissState m n) : Prop :=
  ∃ (k : ℕ) (R : Fin k → Fin m) (C : Fin k → Fin n),
    k ≤ c ∧
    Function.Injective R ∧
    Function.Injective C ∧
    (∀ q : Fin k, (C q).val < c) ∧
    (∀ i : Fin m, st.rowUsed i = true ↔ ∃ p : Fin k, R p = i) ∧
    (∀ j : Fin n,
      ((∃ p : Fin k, C p = j) → ∃ p : Fin k, C p = j ∧ st.pivRowOfCol j = ((R p).val : ℤ)) ∧
      ((¬ ∃ p : Fin k, C p = j) → st.pivRowOfCol j = -1)) ∧
    let B_int : Matrix (Fin k) (Fin k) ℤ := fun p q => M (R p) (C q).castSucc
    st.prevPiv = B_int.det ∧
    B_int.det ≠ 0 ∧
    (∀ (p : Fin k) (j : Fin (n + 1)),
      st.A (R p) j = (B_int.updateCol p (fun q => M (R q) j)).det) ∧
    (∀ i : Fin m, st.rowUsed i = false → ∀ j : Fin (n + 1),
      st.A i j =
        (Matrix.of (fun (p : Fin (k + 1)) (q : Fin (k + 1)) =>
          M (snocFin R i p) (snocFin (fun q' => (C q').castSucc) j q))).det) ∧
    (∀ j : Fin n, j.val < c → (¬ ∃ p : Fin k, C p = j) →
      ∀ i : Fin m, st.rowUsed i = false → st.A i j.castSucc = 0)

theorem bareissInv_init {m n : ℕ} (T₀ : Fin m → Fin n → ℤ) (rhs₀ : Fin m → ℤ) :
    BareissInv (fun i j => Fin.lastCases (rhs₀ i) (T₀ i) j) 0 (bareissInit T₀ rhs₀) := by
  refine ⟨0, Fin.elim0, Fin.elim0, le_rfl,
    fun p => Fin.elim0 p, fun q => Fin.elim0 q, fun q => Fin.elim0 q, ?_, ?_, ?_⟩
  · intro i
    simp [bareissInit]
  · intro j
    refine ⟨fun ⟨p, _⟩ => Fin.elim0 p, fun _ => rfl⟩
  · refine ⟨by simp [bareissInit], by simp, fun p => Fin.elim0 p, ?_, ?_⟩
    · intro i _ j
      rw [Matrix.det_fin_one]
      dsimp only [Matrix.of_apply, bareissInit]
      have h0 : (0 : Fin (0 + 1)) = Fin.last 0 := rfl
      rw [h0, snocFin_last, snocFin_last]
    · intro j hj
      exact False.elim (Nat.not_lt_zero _ hj)

theorem bareissInv_step {m n : ℕ} (M : Fin m → Fin (n + 1) → ℤ) (c : Fin n)
    (st : BareissState m n) (hInv : BareissInv M c.val st) :
    BareissInv M (c.val + 1) (bareissColStep st c) := by
  rcases hInv with ⟨k, R, C, hkc, hR_inj, hC_inj, hC_lt, hUsed, hPivMap,
    hPrev, hDetNe, hPivRows, hNonPivRows, hZeroCols⟩
  let cCol : Fin (n + 1) := c.castSucc
  rcases findPivotRow_spec st.A st.rowUsed cCol with ⟨hNoPiv, hAllZeroC⟩ | ⟨r₀, hFound, hr₀_unused, hPivNe⟩
  · -- No pivot in column c
    have hCondFalse : ¬ (0 ≤ findPivotRow st.A st.rowUsed cCol ∧
        (findPivotRow st.A st.rowUsed cCol).toNat < m) := by
      rw [hNoPiv]; omega
    have hStepEq : bareissColStep st c = st := by
      unfold bareissColStep
      dsimp only
      rw [dif_neg hCondFalse]
    rw [hStepEq]
    refine ⟨k, R, C, Nat.le_succ_of_le hkc, hR_inj, hC_inj,
      fun q => Nat.lt_succ_of_lt (hC_lt q), hUsed, hPivMap, hPrev, hDetNe,
      hPivRows, hNonPivRows, ?_⟩
    intro j hj hNotIn i hi
    rcases Nat.lt_succ_iff_lt_or_eq.mp hj with hlt | heq
    · exact hZeroCols j hlt hNotIn i hi
    · have hjc : j = c := Fin.ext heq
      subst hjc
      exact hAllZeroC i hi
  · -- Pivot found at unused row r₀
    have hCondTrue : 0 ≤ findPivotRow st.A st.rowUsed cCol ∧
        (findPivotRow st.A st.rowUsed cCol).toNat < m := by
      rw [hFound]
      exact ⟨Nat.cast_nonneg r₀.val, by simpa using r₀.isLt⟩
    have hr₀_eq : (⟨(findPivotRow st.A st.rowUsed cCol).toNat, hCondTrue.2⟩ : Fin m) = r₀ := by
      ext
      simp [hFound]
    let R' : Fin (k + 1) → Fin m := snocFin R r₀
    let C' : Fin (k + 1) → Fin n := snocFin C c
    have hr₀_not_R : ∀ p : Fin k, R p ≠ r₀ := by
      intro p hp
      have htrue := (hUsed r₀).mpr ⟨p, hp⟩
      rw [hr₀_unused] at htrue
      exact Bool.false_ne_true htrue
    have hc_not_C : ∀ q : Fin k, C q ≠ c := by
      intro q hq
      have hlt := hC_lt q
      rw [hq] at hlt
      exact lt_irrefl _ hlt
    have hR'_inj : Function.Injective R' := by
      intro a b
      refine Fin.lastCases ?_ (fun a' => ?_) a <;> refine Fin.lastCases ?_ (fun b' => ?_) b <;>
        intro hab
      · rfl
      · simp only [R', snocFin_last, snocFin_castSucc] at hab
        exact False.elim (hr₀_not_R b' hab.symm)
      · simp only [R', snocFin_last, snocFin_castSucc] at hab
        exact False.elim (hr₀_not_R a' hab)
      · simp only [R', snocFin_castSucc] at hab
        exact congrArg Fin.castSucc (hR_inj hab)
    have hC'_inj : Function.Injective C' := by
      intro a b
      refine Fin.lastCases ?_ (fun a' => ?_) a <;> refine Fin.lastCases ?_ (fun b' => ?_) b <;>
        intro hab
      · rfl
      · simp only [C', snocFin_last, snocFin_castSucc] at hab
        exact False.elim (hc_not_C b' hab.symm)
      · simp only [C', snocFin_last, snocFin_castSucc] at hab
        exact False.elim (hc_not_C a' hab)
      · simp only [C', snocFin_castSucc] at hab
        exact congrArg Fin.castSucc (hC_inj hab)
    have hC'_lt : ∀ q : Fin (k + 1), (C' q).val < c.val + 1 := by
      intro q
      refine Fin.lastCases ?_ (fun q' => ?_) q
      · simp [C']
      · simp only [C', snocFin_castSucc]
        exact Nat.lt_succ_of_lt (hC_lt q')
    let B_int : Matrix (Fin k) (Fin k) ℤ := fun p q => M (R p) (C q).castSucc
    let B'_int : Matrix (Fin (k + 1)) (Fin (k + 1)) ℤ := fun p q => M (R' p) (C' q).castSucc
    have hPiv_eq_det : st.A r₀ cCol = B'_int.det := by
      rw [hNonPivRows r₀ hr₀_unused cCol]
      congr 1
      ext p q
      simp only [Matrix.of_apply, B'_int, R', C']
      congr 2
      refine Fin.lastCases ?_ (fun q' => ?_) q <;> simp [cCol]
    have hB'_det_ne : B'_int.det ≠ 0 := by
      rw [← hPiv_eq_det]
      exact hPivNe
    -- Schur-Cramer rational helper for any row i (with st.rowUsed i = false) and column j
    let B_Q : Matrix (Fin k) (Fin k) ℚ := (Int.castRingHom ℚ).mapMatrix B_int
    have hBQ_det : B_Q.det = (B_int.det : ℚ) :=
      (RingHom.map_det (Int.castRingHom ℚ) B_int).symm
    have hBQ_ne : B_Q.det ≠ 0 := by
      rw [hBQ_det]; exact_mod_cast hDetNe
    let u_of : Fin (n + 1) → Fin k → ℚ := fun j p =>
      ((B_int.updateCol p (fun q => M (R q) j)).det : ℚ) / (B_int.det : ℚ)
    have hu_of_eq : ∀ (j : Fin (n + 1)) (p : Fin k),
        u_of j p = (st.A (R p) j : ℚ) / (B_int.det : ℚ) := by
      intro j p
      rw [hPivRows p j]
    have hBQ_u : ∀ j : Fin (n + 1), B_Q.mulVec (u_of j) = fun p => (M (R p) j : ℚ) := by
      intro j
      have hCr := Matrix.mulVec_cramer B_Q (fun p => (M (R p) j : ℚ))
      have hu_cr : u_of j = (1 / B_Q.det) • B_Q.cramer (fun p => (M (R p) j : ℚ)) := by
        ext p
        simp only [u_of, Pi.smul_apply, smul_eq_mul, one_div, Matrix.cramer_apply, hBQ_det]
        have hUpd : B_Q.updateCol p (fun q => (M (R q) j : ℚ)) =
            (Int.castRingHom ℚ).mapMatrix (B_int.updateCol p (fun q => M (R q) j)) := by
          ext p' q'
          by_cases hqp : q' = p <;> simp [hqp, B_Q]
        rw [hUpd, ← RingHom.map_det (Int.castRingHom ℚ)]
        simp only [castRingHom_apply_rat]
        ring
      rw [hu_cr, Matrix.mulVec_smul, hCr, smul_smul, one_div, inv_mul_cancel₀ hBQ_ne, one_smul]
    have hSchurUnused : ∀ (i : Fin m), st.rowUsed i = false → ∀ (j : Fin (n + 1)),
        (st.A i j : ℚ) / (B_int.det : ℚ) =
          (M i j : ℚ) - ∑ q : Fin k, (M i (C q).castSucc : ℚ) * u_of j q := by
      intro i hi j
      rw [hNonPivRows i hi j]
      let D_int : Matrix (Fin (k + 1)) (Fin (k + 1)) ℤ :=
        Matrix.of (fun p q => M (snocFin R i p) (snocFin (fun q' => (C q').castSucc) j q))
      have hD_cast : (D_int.det : ℚ) = ((Int.castRingHom ℚ).mapMatrix D_int).det :=
        RingHom.map_det (Int.castRingHom ℚ) D_int
      rw [hD_cast]
      have hD_eq : (Int.castRingHom ℚ).mapMatrix D_int =
          (fun (p : Fin (k + 1)) (q : Fin (k + 1)) =>
            Fin.lastCases
              (Fin.lastCases (M i j : ℚ) (fun q' => (M i (C q').castSucc : ℚ)) q)
              (fun p' => Fin.lastCases (M (R p') j : ℚ) (B_Q p') q) p) := by
        simpa [D_int, B_Q] using snoc_submatrix_eq_lastCases M R (fun q' => (C q').castSucc) i j
      rw [hD_eq]
      have hSch := det_bordered_eq_mul_schur B_Q (fun p' => (M (R p') j : ℚ))
        (fun q' => (M i (C q').castSucc : ℚ)) (M i j : ℚ) (u_of j) (hBQ_u j)
      dsimp only at hSch
      rw [hSch, hBQ_det, mul_div_cancel_left₀ _ (by exact_mod_cast hDetNe)]
    -- Now connect u'_of for (R', C') with u_of
    let B'_Q : Matrix (Fin (k + 1)) (Fin (k + 1)) ℚ := (Int.castRingHom ℚ).mapMatrix B'_int
    have hB'Q_det : B'_Q.det = (B'_int.det : ℚ) :=
      (RingHom.map_det (Int.castRingHom ℚ) B'_int).symm
    have hB'Q_ne : B'_Q.det ≠ 0 := by
      rw [hB'Q_det]; exact_mod_cast hB'_det_ne
    let v_of : Fin (n + 1) → Fin (k + 1) → ℚ := fun j p =>
      Fin.lastCases
        ((st.A r₀ j : ℚ) / (B'_int.det : ℚ))
        (fun p' => u_of j p' - ((st.A r₀ j : ℚ) / (B'_int.det : ℚ)) * u_of cCol p') p
    have hB'Q_v : ∀ j : Fin (n + 1), B'_Q.mulVec (v_of j) = fun p => (M (R' p) j : ℚ) := by
      intro j
      ext p
      simp only [Matrix.mulVec, dotProduct, Fin.sum_univ_castSucc, B'_Q, RingHom.mapMatrix_apply,
        Matrix.map_apply, castRingHom_apply_rat, B'_int, R', C', v_of, Fin.lastCases_castSucc,
        Fin.lastCases_last, snocFin_last]
      have hcCast : (snocFin C c (Fin.last k)).castSucc = cCol := by simp [cCol]
      have hqCast : ∀ x : Fin k, (snocFin C c x.castSucc).castSucc = (C x).castSucc := by
        intro x; simp
      refine Fin.lastCases ?_ (fun p' => ?_) p
      · simp only [snocFin_last, hqCast]
        have h1 : (∑ x : Fin k, (M r₀ (C x).castSucc : ℚ) *
            (u_of j x - (st.A r₀ j : ℚ) / (B'_int.det : ℚ) * u_of cCol x)) =
            (∑ x : Fin k, (M r₀ (C x).castSucc : ℚ) * u_of j x) -
              ((st.A r₀ j : ℚ) / (B'_int.det : ℚ)) *
                (∑ x : Fin k, (M r₀ (C x).castSucc : ℚ) * u_of cCol x) := by
          have hpt : ∀ x : Fin k, (M r₀ (C x).castSucc : ℚ) *
              (u_of j x - (st.A r₀ j : ℚ) / (B'_int.det : ℚ) * u_of cCol x) =
              (M r₀ (C x).castSucc : ℚ) * u_of j x -
                ((st.A r₀ j : ℚ) / (B'_int.det : ℚ)) * ((M r₀ (C x).castSucc : ℚ) * u_of cCol x) := by
            intro x; ring
          simp_rw [hpt, Finset.sum_sub_distrib, ← Finset.mul_sum]
        rw [h1]
        have hs_j := hSchurUnused r₀ hr₀_unused j
        have hs_c := hSchurUnused r₀ hr₀_unused cCol
        have hsum_j : ∑ x : Fin k, (M r₀ (C x).castSucc : ℚ) * u_of j x =
            (M r₀ j : ℚ) - (st.A r₀ j : ℚ) / (B_int.det : ℚ) := by linarith
        have hsum_c : ∑ x : Fin k, (M r₀ (C x).castSucc : ℚ) * u_of cCol x =
            (M r₀ cCol : ℚ) - (B'_int.det : ℚ) / (B_int.det : ℚ) := by
          rw [hPiv_eq_det] at hs_c
          linarith
        rw [hsum_j, hsum_c]
        have hBne : (B_int.det : ℚ) ≠ 0 := by exact_mod_cast hDetNe
        have hB'ne : (Matrix.det fun p q => (M (snocFin R r₀ p) (snocFin C c q).castSucc : ℚ)) ≠ 0 := by
          simpa [B'_Q, B'_int, R', C'] using hB'Q_ne
        dsimp only [B'_int, R', C', cCol] at *
        field_simp [hBne, hB'ne]
        ring
      · simp only [snocFin_castSucc]
        have h1 : (∑ x : Fin k, (M (R p') (C x).castSucc : ℚ) *
            (u_of j x - (st.A r₀ j : ℚ) / (B'_int.det : ℚ) * u_of cCol x)) =
            (B_Q.mulVec (u_of j)) p' -
              ((st.A r₀ j : ℚ) / (B'_int.det : ℚ)) * (B_Q.mulVec (u_of cCol)) p' := by
          simp only [Matrix.mulVec, dotProduct, B_Q, RingHom.mapMatrix_apply, Matrix.map_apply,
            castRingHom_apply_rat, B_int]
          have hpt : ∀ x : Fin k, (M (R p') (C x).castSucc : ℚ) *
              (u_of j x - (st.A r₀ j : ℚ) / (B'_int.det : ℚ) * u_of cCol x) =
              (M (R p') (C x).castSucc : ℚ) * u_of j x -
                ((st.A r₀ j : ℚ) / (B'_int.det : ℚ)) *
                  ((M (R p') (C x).castSucc : ℚ) * u_of cCol x) := by
            intro x; ring
          simp_rw [hpt, Finset.sum_sub_distrib, ← Finset.mul_sum]
        rw [h1, hBQ_u j, hBQ_u cCol]
        ring
    have hv_cramer : ∀ (j : Fin (n + 1)) (p : Fin (k + 1)),
        ((B'_int.updateCol p (fun q => M (R' q) j)).det : ℚ) = (B'_int.det : ℚ) * v_of j p := by
      intro j p
      have hUnit : IsUnit B'_Q :=
        (Matrix.isUnit_iff_isUnit_det _).mpr (isUnit_iff_ne_zero.mpr hB'Q_ne)
      have hSolEq : B'_Q.det • v_of j = B'_Q.cramer (fun q => (M (R' q) j : ℚ)) := by
        apply Matrix.mulVec_injective_iff_isUnit.mpr hUnit
        rw [Matrix.mulVec_smul, hB'Q_v j, Matrix.mulVec_cramer]
      have hp := congr_fun hSolEq p
      simp only [Pi.smul_apply, smul_eq_mul, Matrix.cramer_apply, hB'Q_det] at hp
      have hUpd : B'_Q.updateCol p (fun q => (M (R' q) j : ℚ)) =
          (Int.castRingHom ℚ).mapMatrix (B'_int.updateCol p (fun q => M (R' q) j)) := by
        ext p' q'
        by_cases hqp : q' = p <;> simp [hqp, B'_Q]
      rw [hUpd, ← RingHom.map_det (Int.castRingHom ℚ)] at hp
      exact hp.symm
    -- Assemble BareissInv at c + 1
    have hst' : bareissColStep st c =
        { A := fun i j =>
            if i = r₀ then st.A r₀ j
            else (st.A r₀ cCol * st.A i j - st.A i cCol * st.A r₀ j) / st.prevPiv
          prevPiv := st.A r₀ cCol
          rowUsed := fun i => if i = r₀ then true else st.rowUsed i
          pivRowOfCol := fun j => if j = c then (r₀.val : ℤ) else st.pivRowOfCol j } := by
      unfold bareissColStep
      have hCondTrue' : 0 ≤ findPivotRow st.A st.rowUsed c.castSucc ∧
          (findPivotRow st.A st.rowUsed c.castSucc).toNat < m := hCondTrue
      have hr₀_eq' : (⟨(findPivotRow st.A st.rowUsed c.castSucc).toNat, hCondTrue'.2⟩ : Fin m) = r₀ := hr₀_eq
      have htoNat : (findPivotRow st.A st.rowUsed c.castSucc).toNat = r₀.val :=
        congrArg Fin.val hr₀_eq'
      dsimp only [cCol]
      rw [dif_pos hCondTrue']
      simp only [hr₀_eq', htoNat]
    refine ⟨k + 1, R', C', Nat.succ_le_succ hkc, hR'_inj, hC'_inj, hC'_lt, ?_, ?_, ?_⟩
    · intro i
      rw [hst']
      dsimp only
      by_cases hir : i = r₀
      · subst hir
        simp only [↓reduceIte, true_iff]
        exact ⟨Fin.last k, by simp [R']⟩
      · simp only [hir, ↓reduceIte, hUsed i]
        constructor
        · rintro ⟨p, hp⟩
          exact ⟨p.castSucc, by simpa [R'] using hp⟩
        · rintro ⟨p, hp⟩
          revert hp
          refine Fin.lastCases ?_ (fun p' => ?_) p <;> intro hp
          · simp [R'] at hp; exact False.elim (hir hp.symm)
          · exact ⟨p', by simpa [R'] using hp⟩
    · intro j
      rw [hst']
      dsimp only
      by_cases hjc : j = c
      · subst hjc
        simp only [↓reduceIte]
        refine ⟨fun _ => ⟨Fin.last k, by simp [C'], by simp [R']⟩, fun hNot => ?_⟩
        exact False.elim (hNot ⟨Fin.last k, by simp [C']⟩)
      · simp only [hjc, ↓reduceIte]
        have hEquiv : (∃ p : Fin (k + 1), C' p = j) ↔ (∃ p' : Fin k, C p' = j) := by
          constructor
          · rintro ⟨p, hp⟩
            revert hp
            refine Fin.lastCases ?_ (fun p' => ?_) p <;> intro hp
            · simp [C'] at hp; exact False.elim (hjc hp.symm)
            · exact ⟨p', by simpa [C'] using hp⟩
          · rintro ⟨p', hp'⟩
            exact ⟨p'.castSucc, by simpa [C'] using hp'⟩
        constructor
        · intro hIn
          rcases (hPivMap j).1 (hEquiv.mp hIn) with ⟨p', hp', hpr⟩
          exact ⟨p'.castSucc, by simpa [C'] using hp', by simpa [R'] using hpr⟩
        · intro hNot
          exact (hPivMap j).2 (fun h => hNot (hEquiv.mpr h))
    · refine ⟨by rw [hst']; exact hPiv_eq_det, hB'_det_ne, ?_, ?_, ?_⟩
      · -- Pivot rows of st'
        intro p j
        rw [hst']
        dsimp only
        refine Fin.lastCases ?_ (fun p' => ?_) p
        · simp only [R', snocFin_last, ↓reduceIte]
          rw [hNonPivRows r₀ hr₀_unused j]
          congr 1
          ext a b
          by_cases hb : b = Fin.last k
          · subst hb; simp [B'_int, R', C']
          · obtain ⟨b', rfl⟩ := Fin.eq_castSucc_of_ne_last hb
            simp [B'_int, R', C']
        · simp only [R', snocFin_castSucc, hr₀_not_R p', ↓reduceIte]
          have hMulEqQ :
              ((st.A r₀ cCol * st.A (R p') j - st.A (R p') cCol * st.A r₀ j : ℤ) : ℚ) =
              (((B'_int.updateCol p'.castSucc (fun q => M (R' q) j)).det * st.prevPiv : ℤ) : ℚ) := by
            simp only [Int.cast_sub, Int.cast_mul]
            rw [hv_cramer j p'.castSucc, hPrev, hPiv_eq_det]
            simp only [v_of, Fin.lastCases_castSucc, hu_of_eq]
            have hBne : (B_int.det : ℚ) ≠ 0 := by exact_mod_cast hDetNe
            have hB'ne : (B'_int.det : ℚ) ≠ 0 := by exact_mod_cast hB'_det_ne
            field_simp [hBne, hB'ne]
            ring
          have hMulEqZ :
              st.A r₀ cCol * st.A (R p') j - st.A (R p') cCol * st.A r₀ j =
              (B'_int.updateCol p'.castSucc (fun q => M (R' q) j)).det * st.prevPiv := by
            exact_mod_cast hMulEqQ
          have hPrevNe : st.prevPiv ≠ 0 := by rw [hPrev]; exact hDetNe
          rw [hMulEqZ, Int.mul_ediv_cancel _ hPrevNe]
      · -- Non-pivot rows of st'
        intro i hi' j
        have hi_ne_r0 : i ≠ r₀ := by
          intro heq; subst heq; simp [hst'] at hi'
        have hi_unused : st.rowUsed i = false := by
          simpa [hst', hi_ne_r0] using hi'
        rw [hst']
        dsimp only
        simp only [hi_ne_r0, ↓reduceIte]
        let D'_int : Matrix (Fin (k + 2)) (Fin (k + 2)) ℤ :=
          Matrix.of (fun p q => M (snocFin R' i p) (snocFin (fun q' => (C' q').castSucc) j q))
        have hD'Q : (D'_int.det : ℚ) =
            (B'_int.det : ℚ) * ((M i j : ℚ) - ∑ q : Fin (k + 1), (M i (C' q).castSucc : ℚ) * v_of j q) := by
          have hCast : (D'_int.det : ℚ) = ((Int.castRingHom ℚ).mapMatrix D'_int).det :=
            RingHom.map_det (Int.castRingHom ℚ) D'_int
          rw [hCast]
          have hEq := snoc_submatrix_eq_lastCases M R' (fun q' => (C' q').castSucc) i j
          dsimp only [D'_int]
          have hMap : (Int.castRingHom ℚ).mapMatrix (Matrix.of (fun p q => M (snocFin R' i p)
              (snocFin (fun q' => (C' q').castSucc) j q))) =
              Matrix.of (fun p q => (M (snocFin R' i p)
                (snocFin (fun q' => (C' q').castSucc) j q) : ℚ)) := by
            ext p q; rfl
          rw [hMap, hEq]
          have hSch := det_bordered_eq_mul_schur B'_Q (fun p' => (M (R' p') j : ℚ))
            (fun q' => (M i (C' q').castSucc : ℚ)) (M i j : ℚ) (v_of j) (hB'Q_v j)
          dsimp only at hSch
          have hEqMat' :
              (fun (p : Fin (k + 2)) (q : Fin (k + 2)) =>
                Fin.lastCases
                  (Fin.lastCases (M i j : ℚ) (fun q' => (M i (C' q').castSucc : ℚ)) q)
                  (fun p' => Fin.lastCases (M (R' p') j : ℚ) (fun q' => (M (R' p') (C' q').castSucc : ℚ)) q) p :
                Matrix (Fin (k + 2)) (Fin (k + 2)) ℚ) =
              (fun (p : Fin (k + 2)) (q : Fin (k + 2)) =>
                Fin.lastCases
                  (Fin.lastCases (M i j : ℚ) (fun q' => (M i (C' q').castSucc : ℚ)) q)
                  (fun p' => Fin.lastCases (M (R' p') j : ℚ) (B'_Q p') q) p) := by
            ext p q
            refine Fin.lastCases ?_ (fun p' => ?_) p <;> refine Fin.lastCases ?_ (fun q' => ?_) q <;>
              simp [B'_Q, B'_int]
          rw [hEqMat', hSch, hB'Q_det]
        have hMulEqQ :
            ((st.A r₀ cCol * st.A i j - st.A i cCol * st.A r₀ j : ℤ) : ℚ) =
            ((D'_int.det * st.prevPiv : ℤ) : ℚ) := by
          simp only [Int.cast_sub, Int.cast_mul]
          rw [hD'Q, hPrev, hPiv_eq_det]
          simp only [Fin.sum_univ_castSucc, C', v_of, snocFin_castSucc, snocFin_last,
            Fin.lastCases_castSucc, Fin.lastCases_last]
          have hcCast : c.castSucc = cCol := rfl
          rw [hcCast]
          have hSplit : ∑ x : Fin k, (M i (C x).castSucc : ℚ) *
              (u_of j x - (st.A r₀ j : ℚ) / (B'_int.det : ℚ) * u_of cCol x) =
              (∑ x : Fin k, (M i (C x).castSucc : ℚ) * u_of j x) -
                ((st.A r₀ j : ℚ) / (B'_int.det : ℚ)) *
                  (∑ x : Fin k, (M i (C x).castSucc : ℚ) * u_of cCol x) := by
            have hpt : ∀ x : Fin k, (M i (C x).castSucc : ℚ) *
                (u_of j x - (st.A r₀ j : ℚ) / (B'_int.det : ℚ) * u_of cCol x) =
                (M i (C x).castSucc : ℚ) * u_of j x -
                  ((st.A r₀ j : ℚ) / (B'_int.det : ℚ)) * ((M i (C x).castSucc : ℚ) * u_of cCol x) := by
              intro x; ring
            simp_rw [hpt, Finset.sum_sub_distrib, ← Finset.mul_sum]
          rw [hSplit]
          have hs_ij := hSchurUnused i hi_unused j
          have hs_ic := hSchurUnused i hi_unused cCol
          have hsum_j : ∑ x : Fin k, (M i (C x).castSucc : ℚ) * u_of j x =
              (M i j : ℚ) - (st.A i j : ℚ) / (B_int.det : ℚ) := by linarith
          have hsum_c : ∑ x : Fin k, (M i (C x).castSucc : ℚ) * u_of cCol x =
              (M i cCol : ℚ) - (st.A i cCol : ℚ) / (B_int.det : ℚ) := by linarith
          rw [hsum_j, hsum_c]
          have hBne : (B_int.det : ℚ) ≠ 0 := by exact_mod_cast hDetNe
          have hB'ne : (B'_int.det : ℚ) ≠ 0 := by exact_mod_cast hB'_det_ne
          field_simp [hBne, hB'ne]
          ring
        have hMulEqZ :
            st.A r₀ cCol * st.A i j - st.A i cCol * st.A r₀ j = D'_int.det * st.prevPiv := by
          exact_mod_cast hMulEqQ
        have hPrevNe : st.prevPiv ≠ 0 := by rw [hPrev]; exact hDetNe
        rw [hMulEqZ, Int.mul_ediv_cancel _ hPrevNe]
      · -- Processed non-pivot columns stay 0 on unused rows
        intro j hj hNotIn' i hi'
        have hi_ne_r0 : i ≠ r₀ := by
          intro heq; subst heq; simp [hst'] at hi'
        have hi_unused : st.rowUsed i = false := by
          simpa [hst', hi_ne_r0] using hi'
        have hj_ne_c : j ≠ c := by
          intro heq; subst heq
          exact hNotIn' ⟨Fin.last k, by simp [C']⟩
        have hj_lt_c : j.val < c.val := by
          have : j.val ≠ c.val := fun h => hj_ne_c (Fin.ext h)
          omega
        have hNotIn : ¬ ∃ p : Fin k, C p = j := by
          rintro ⟨p, hp⟩
          exact hNotIn' ⟨p.castSucc, by simpa [C'] using hp⟩
        have hZero_i := hZeroCols j hj_lt_c hNotIn i hi_unused
        have hZero_r0 := hZeroCols j hj_lt_c hNotIn r₀ hr₀_unused
        rw [hst']
        dsimp only
        simp [hi_ne_r0, hZero_i, hZero_r0]

theorem bareissInv_entry_bound {m n : ℕ} (M : Fin m → Fin (n + 1) → ℤ) (U : ℕ) (hU : 1 ≤ U)
    (hM : ∀ (i : Fin m) (j : Fin (n + 1)), (M i j).natAbs ≤ U)
    {c : ℕ} (hc : c ≤ n) {st : BareissState m n} (hInv : BareissInv M c st) :
    st.prevPiv.natAbs ≤ (n + 1).factorial * U ^ (n + 1) ∧
    (∀ (i : Fin m) (j : Fin (n + 1)), (st.A i j).natAbs ≤ (n + 1).factorial * U ^ (n + 1)) := by
  rcases hInv with ⟨k, R, C, hkc, _, _, _, hUsed, _, hPrev, _, hPivRows, hNonPivRows, _⟩
  have hk_le : k ≤ n := hkc.trans hc
  have hk1_le : k + 1 ≤ n + 1 := Nat.succ_le_succ hk_le
  have hFac_k : k.factorial * U ^ k ≤ (n + 1).factorial * U ^ (n + 1) :=
    Nat.mul_le_mul (Nat.factorial_le (Nat.le_succ_of_le hk_le))
      (Nat.pow_le_pow_right hU (Nat.le_succ_of_le hk_le))
  have hFac_k1 : (k + 1).factorial * U ^ (k + 1) ≤ (n + 1).factorial * U ^ (n + 1) :=
    Nat.mul_le_mul (Nat.factorial_le hk1_le) (Nat.pow_le_pow_right hU hk1_le)
  constructor
  · rw [hPrev]
    exact (natAbs_det_le_factorial_mul_pow_int _ U (fun p q => hM _ _)).trans hFac_k
  · intro i j
    cases hru : st.rowUsed i
    · rw [hNonPivRows i hru j]
      exact (natAbs_det_le_factorial_mul_pow_int _ U (fun p q => hM _ _)).trans hFac_k1
    · obtain ⟨p, rfl⟩ := (hUsed i).mp hru
      rw [hPivRows p j]
      refine (natAbs_det_le_factorial_mul_pow_int _ U (fun p' q' => ?_)).trans hFac_k
      by_cases hqp : q' = p
      · subst hqp; simpa using hM _ _
      · simpa [Matrix.updateCol_ne hqp] using hM _ _

/-- Full correctness and determinant bound theorem for `bareissSolve`. -/
theorem bareissSolve_spec {m n : ℕ} (T₀ : Fin m → Fin n → ℤ) (rhs₀ : Fin m → ℤ) (U : ℕ)
    (hU : 1 ≤ U)
    (hT : ∀ (i : Fin m) (j : Fin n), (T₀ i j).natAbs ≤ U)
    (hrhs : ∀ i : Fin m, (rhs₀ i).natAbs ≤ U)
    (hFeas : ∃ x : Fin n → ℝ, ∀ i : Fin m, ∑ j : Fin n, (T₀ i j : ℝ) * x j = (rhs₀ i : ℝ)) :
    let (solNum, solDen) := bareissSolve T₀ rhs₀
    let xRat : Fin n → ℚ := fun j => (solNum j : ℚ) / (solDen j : ℚ)
    (∀ j : Fin n,
      0 < solDen j ∧
      (solNum j).natAbs ≤ (n + 1).factorial * U ^ (n + 1) ∧
      (solDen j).natAbs ≤ (n + 1).factorial * U ^ (n + 1)) ∧
    (∀ i : Fin m, ∑ j : Fin n, (T₀ i j : ℚ) * xRat j = (rhs₀ i : ℚ)) := by
  let M : Fin m → Fin (n + 1) → ℤ := fun i j => Fin.lastCases (rhs₀ i) (T₀ i) j
  have hM : ∀ (i : Fin m) (j : Fin (n + 1)), (M i j).natAbs ≤ U := by
    intro i j
    refine Fin.lastCases ?_ (fun j' => ?_) j
    · simp [M, hrhs i]
    · simp [M, hT i j']
  have hFoldInv : ∀ c : ℕ, (hc : c ≤ n) →
      BareissInv M c (Fin.foldl c (fun st (j : Fin c) =>
        bareissColStep st ⟨j.val, lt_of_lt_of_le j.isLt hc⟩) (bareissInit T₀ rhs₀)) := by
    intro c
    induction c with
    | zero =>
        intro _
        simpa [M, Fin.foldl_zero] using bareissInv_init T₀ rhs₀
    | succ c ih =>
        intro hc
        rw [Fin.foldl_succ_last]
        exact bareissInv_step M ⟨c, hc⟩ _ (ih (Nat.le_of_succ_le hc))
  have hFinalInv : BareissInv M n (bareissRun T₀ rhs₀) := hFoldInv n le_rfl
  have hBounds := bareissInv_entry_bound M U hU hM le_rfl hFinalInv
  rcases hFinalInv with ⟨k, R, C, hkn, hR_inj, hC_inj, _, hUsed, hPivMap,
    hPrev, hDetNe, hPivRows, hNonPivRows, hZeroCols⟩
  let st := bareissRun T₀ rhs₀
  let sgn : ℤ := if 0 < st.prevPiv then 1 else -1
  let den : ℤ := sgn * st.prevPiv
  have hDenPos : 0 < den := by
    dsimp only [den, sgn]
    have hne : st.prevPiv ≠ 0 := by rw [hPrev]; exact hDetNe
    rcases lt_trichotomy st.prevPiv 0 with hneg | hzero | hpos
    · have : ¬ 0 < st.prevPiv := not_lt.mpr hneg.le
      simp [this]; omega
    · exact False.elim (hne hzero)
    · simp [hpos]
  have hsgn_abs : sgn.natAbs = 1 := by dsimp [sgn]; split_ifs <;> rfl
  have hDenAbs : den.natAbs ≤ (n + 1).factorial * U ^ (n + 1) := by
    dsimp only [den]
    rw [Int.natAbs_mul, hsgn_abs, one_mul]
    exact hBounds.1
  let solNum : Fin n → ℤ := (bareissSolve T₀ rhs₀).1
  let solDen : Fin n → ℤ := (bareissSolve T₀ rhs₀).2
  let xRat : Fin n → ℚ := fun j => (solNum j : ℚ) / (solDen j : ℚ)
  have hSolNum_eq : ∀ j : Fin n, solNum j =
      if h : 0 ≤ st.pivRowOfCol j ∧ (st.pivRowOfCol j).toNat < m then
        sgn * st.A ⟨(st.pivRowOfCol j).toNat, h.2⟩ (Fin.last n)
      else 0 := fun _ => rfl
  have hSolDen_eq : ∀ j : Fin n, solDen j =
      if _ : 0 ≤ st.pivRowOfCol j ∧ (st.pivRowOfCol j).toNat < m then den else 1 := fun _ => rfl
  change (∀ j : Fin n, 0 < solDen j ∧
      (solNum j).natAbs ≤ (n + 1).factorial * U ^ (n + 1) ∧
      (solDen j).natAbs ≤ (n + 1).factorial * U ^ (n + 1)) ∧
    (∀ i : Fin m, ∑ j : Fin n, (T₀ i j : ℚ) * xRat j = (rhs₀ i : ℚ))
  constructor
  · intro j
    rw [hSolNum_eq j, hSolDen_eq j]
    by_cases hj : 0 ≤ st.pivRowOfCol j ∧ (st.pivRowOfCol j).toNat < m
    · rw [dif_pos hj, dif_pos hj]
      refine ⟨hDenPos, ?_, hDenAbs⟩
      rw [Int.natAbs_mul, hsgn_abs, one_mul]
      exact hBounds.2 _ _
    · rw [dif_neg hj, dif_neg hj]
      have h1 : 1 ≤ (n + 1).factorial := Nat.factorial_pos (n + 1)
      have h2 : 1 ≤ U ^ (n + 1) := Nat.one_le_pow _ _ hU
      have hprod : 1 ≤ (n + 1).factorial * U ^ (n + 1) := Nat.mul_pos h1 h2
      exact ⟨by omega, by simp, by simpa using hprod⟩
  · -- Prove xRat solves every row i : Fin m
    let B_int : Matrix (Fin k) (Fin k) ℤ := fun p q => M (R p) (C q).castSucc
    let B_Q : Matrix (Fin k) (Fin k) ℚ := (Int.castRingHom ℚ).mapMatrix B_int
    have hBQ_det : B_Q.det = (B_int.det : ℚ) :=
      (RingHom.map_det (Int.castRingHom ℚ) B_int).symm
    have hBQ_ne : B_Q.det ≠ 0 := by rw [hBQ_det]; exact_mod_cast hDetNe
    have hsgn_sq : (sgn : ℚ) / ((sgn : ℚ) * (B_int.det : ℚ)) = 1 / (B_int.det : ℚ) := by
      have hsne : (sgn : ℚ) ≠ 0 := by dsimp [sgn]; split_ifs <;> norm_num
      field_simp [hsne, hBQ_ne]
    -- Characterize xRat on C q vs outside range C
    have hxRat_in : ∀ q : Fin k,
        xRat (C q) = (st.A (R q) (Fin.last n) : ℚ) / (B_int.det : ℚ) := by
      intro q
      rcases (hPivMap (C q)).1 ⟨q, rfl⟩ with ⟨q', hqq', hpr⟩
      have hq_eq : q' = q := hC_inj hqq'
      subst q'
      have hCond : 0 ≤ st.pivRowOfCol (C q) ∧ (st.pivRowOfCol (C q)).toNat < m := by
        rw [hpr]
        exact ⟨Nat.cast_nonneg _, by simpa using (R q).isLt⟩
      have hr_eq : (⟨(st.pivRowOfCol (C q)).toNat, hCond.2⟩ : Fin m) = R q := by
        ext
        dsimp only
        rw [hpr]
        exact Int.toNat_natCast _
      dsimp only [xRat]
      rw [hSolNum_eq (C q), hSolDen_eq (C q), dif_pos hCond, dif_pos hCond, hr_eq]
      dsimp only [den]
      rw [hPrev]
      simp only [Int.cast_mul]
      have hsne : (sgn : ℚ) ≠ 0 := by dsimp [sgn]; split_ifs <;> norm_num
      have hbne : (B_int.det : ℚ) ≠ 0 := by exact_mod_cast hDetNe
      have hprev_eq : (B_int.det : ℚ) = ((Matrix.of (fun p q => M (R p) (C q).castSucc)).det : ℚ) := rfl
      field_simp [hsne, hbne]
      try ring
    have hxRat_out : ∀ j : Fin n, (¬ ∃ q : Fin k, C q = j) → xRat j = 0 := by
      intro j hNot
      have hpr := (hPivMap j).2 hNot
      have hCond : ¬ (0 ≤ st.pivRowOfCol j ∧ (st.pivRowOfCol j).toNat < m) := by
        rw [hpr]; omega
      dsimp only [xRat]
      rw [hSolNum_eq j, hSolDen_eq j, dif_neg hCond, dif_neg hCond]
      simp
    -- First show xRat solves all pivot rows R p
    have hxRat_piv : ∀ p : Fin k, ∑ j : Fin n, (T₀ (R p) j : ℚ) * xRat j = (rhs₀ (R p) : ℚ) := by
      intro p
      let S_cols : Finset (Fin n) := Finset.univ.image C
      calc ∑ j : Fin n, (T₀ (R p) j : ℚ) * xRat j
          = ∑ j ∈ S_cols, (T₀ (R p) j : ℚ) * xRat j := by
              rw [← Finset.sum_subset (Finset.subset_univ S_cols)]
              intro j _ hjS
              have hNot : ¬ ∃ q : Fin k, C q = j := by
                rintro ⟨q, rfl⟩
                exact hjS (Finset.mem_image_of_mem C (Finset.mem_univ q))
              simp [hxRat_out j hNot]
        _ = ∑ q : Fin k, (T₀ (R p) (C q) : ℚ) * xRat (C q) := by
              rw [Finset.sum_image (fun a _ b _ h => hC_inj h)]
        _ = (1 / B_Q.det) * (B_Q.mulVec (B_Q.cramer (fun q => (rhs₀ (R q) : ℚ)))) p := by
              rw [hBQ_det]
              simp only [Matrix.mulVec, dotProduct, B_Q, RingHom.mapMatrix_apply, Matrix.map_apply,
                B_int, Matrix.cramer_apply, Finset.mul_sum]
              refine Finset.sum_congr rfl (fun q _ => ?_)
              rw [hxRat_in q, hPivRows q (Fin.last n)]
              have hUpd : (B_Q.updateCol q (fun q' => (rhs₀ (R q') : ℚ))) =
                  (Int.castRingHom ℚ).mapMatrix (B_int.updateCol q (fun q' => M (R q') (Fin.last n))) := by
                ext a b
                by_cases hbq : b = q <;> simp [hbq, B_Q, M]
              change _ = 1 / (B_int.det : ℚ) *
                ((Int.castRingHom ℚ) (M (R p) (C q).castSucc) *
                  (B_Q.updateCol q (fun q' => (rhs₀ (R q') : ℚ))).det)
              rw [hUpd, ← RingHom.map_det (Int.castRingHom ℚ)]
              have hM_eq : M (R p) (C q).castSucc = T₀ (R p) (C q) := by simp [M]
              rw [hM_eq]
              try simp only [castRingHom_apply_rat]
              ring
        _ = (rhs₀ (R p) : ℚ) := by
              rw [Matrix.mulVec_cramer]
              simp only [Pi.smul_apply, smul_eq_mul, one_div]
              exact inv_mul_cancel_left₀ hBQ_ne _
    -- Now show every row i : Fin m is solved!
    intro i
    cases hru : st.rowUsed i
    · -- Non-pivot row i: show row i of T₀ is a linear combination of pivot rows of T₀!
      -- Specifically, let w : Fin k → ℚ solve B_Qᵀ.mulVec w = fun q => T₀ i (C q).
      let row_iC : Fin k → ℚ := fun q => (T₀ i (C q) : ℚ)
      let w : Fin k → ℚ := (1 / B_Qᵀ.det) • B_Qᵀ.cramer row_iC
      have hBT_ne : B_Qᵀ.det ≠ 0 := by rwa [Matrix.det_transpose]
      have hBT_w : B_Qᵀ.mulVec w = row_iC := by
        dsimp only [w]
        rw [Matrix.mulVec_smul, Matrix.mulVec_cramer, smul_smul, one_div,
          inv_mul_cancel₀ hBT_ne, one_smul]
      -- Show that for EVERY variable column j : Fin n, T₀ i j = ∑ p : Fin k, w p * T₀ (R p) j!
      have hRowComb : ∀ j : Fin n, (T₀ i j : ℚ) = ∑ p : Fin k, w p * (T₀ (R p) j : ℚ) := by
        intro j
        -- First note st.A i j.castSucc = 0!
        have hAij_zero : st.A i j.castSucc = 0 := by
          by_cases hIn : ∃ q : Fin k, C q = j
          · rcases hIn with ⟨q₀, rfl⟩
            rw [hNonPivRows i hru (C q₀).castSucc]
            refine Matrix.det_zero_of_column_eq (i := q₀.castSucc) (j := Fin.last k)
              (Fin.castSucc_ne_last q₀) (fun p => ?_)
            simp [snocFin_castSucc, snocFin_last]
          · exact hZeroCols j j.isLt hIn i hru
        -- By Schur-Cramer on (R, C) and (i, j.castSucc):
        let u_j : Fin k → ℚ := (1 / B_Q.det) • B_Q.cramer (fun p => (T₀ (R p) j : ℚ))
        have hBQ_uj : B_Q.mulVec u_j = fun p => (T₀ (R p) j : ℚ) := by
          dsimp only [u_j]
          rw [Matrix.mulVec_smul, Matrix.mulVec_cramer, smul_smul, one_div,
            inv_mul_cancel₀ hBQ_ne, one_smul]
        have hDetZero :
            (Matrix.of (fun (p : Fin (k + 1)) (q : Fin (k + 1)) =>
              (M (snocFin R i p) (snocFin (fun q' => (C q').castSucc) j.castSucc q) : ℚ))).det = 0 := by
          have hInt := hNonPivRows i hru j.castSucc
          rw [hAij_zero] at hInt
          have hCast := (RingHom.map_det (Int.castRingHom ℚ)
            (Matrix.of (fun (p : Fin (k + 1)) (q : Fin (k + 1)) =>
              M (snocFin R i p) (snocFin (fun q' => (C q').castSucc) j.castSucc q)))).symm
          rw [← hInt, map_zero] at hCast
          exact hCast
        rw [snoc_submatrix_eq_lastCases] at hDetZero
        have hSch := det_bordered_eq_mul_schur B_Q (fun p => (T₀ (R p) j : ℚ)) row_iC (T₀ i j : ℚ)
          u_j hBQ_uj
        dsimp only at hSch
        have hEqMat :
            (fun (p : Fin (k + 1)) (q : Fin (k + 1)) =>
              Fin.lastCases
                (Fin.lastCases (M i j.castSucc : ℚ) (fun q' => (M i (C q').castSucc : ℚ)) q)
                (fun p' => Fin.lastCases (M (R p') j.castSucc : ℚ)
                  (fun q' => (M (R p') (C q').castSucc : ℚ)) q) p : Matrix (Fin (k + 1)) (Fin (k + 1)) ℚ) =
            (fun (p : Fin (k + 1)) (q : Fin (k + 1)) =>
              Fin.lastCases
                (Fin.lastCases (T₀ i j : ℚ) row_iC q)
                (fun p' => Fin.lastCases (T₀ (R p') j : ℚ) (B_Q p') q) p) := by
          ext p q
          refine Fin.lastCases ?_ (fun p' => ?_) p <;> refine Fin.lastCases ?_ (fun q' => ?_) q <;>
            simp [M, row_iC, B_Q, B_int]
        rw [hEqMat] at hDetZero
        rw [hDetZero] at hSch
        have hDiffZero : (T₀ i j : ℚ) - ∑ q : Fin k, row_iC q * u_j q = 0 :=
          (mul_eq_zero.mp hSch.symm).resolve_left hBQ_ne
        have hEq1 : (T₀ i j : ℚ) = ∑ q : Fin k, row_iC q * u_j q := sub_eq_zero.mp hDiffZero
        rw [hEq1, ← hBT_w]
        calc ∑ q : Fin k, (B_Qᵀ.mulVec w) q * u_j q
            = ∑ q : Fin k, (∑ p : Fin k, B_Q p q * w p) * u_j q := by
                simp [Matrix.mulVec, dotProduct]
          _ = ∑ p : Fin k, w p * (∑ q : Fin k, B_Q p q * u_j q) := by
                simp_rw [Finset.sum_mul]
                rw [Finset.sum_comm]
                refine Finset.sum_congr rfl (fun p _ => ?_)
                rw [Finset.mul_sum]
                exact Finset.sum_congr rfl (fun q _ => by ring)
          _ = ∑ p : Fin k, w p * (B_Q.mulVec u_j) p := by
                simp [Matrix.mulVec, dotProduct]
          _ = ∑ p : Fin k, w p * (T₀ (R p) j : ℚ) := by rw [hBQ_uj]
      -- Deduce rhs₀ i = ∑ p : Fin k, w p * rhs₀ (R p) from real feasibility hFeas!
      rcases hFeas with ⟨x_real, hx_real⟩
      have hRhsCombR : (rhs₀ i : ℝ) = ∑ p : Fin k, (w p : ℝ) * (rhs₀ (R p) : ℝ) := by
        rw [← hx_real i]
        have hRowR : ∀ j : Fin n, (T₀ i j : ℝ) = ∑ p : Fin k, (w p : ℝ) * (T₀ (R p) j : ℝ) := by
          intro j
          exact_mod_cast hRowComb j
        calc ∑ j : Fin n, (T₀ i j : ℝ) * x_real j
            = ∑ j : Fin n, (∑ p : Fin k, (w p : ℝ) * (T₀ (R p) j : ℝ)) * x_real j := by
                refine Finset.sum_congr rfl (fun j _ => by rw [hRowR j])
          _ = ∑ p : Fin k, (w p : ℝ) * (∑ j : Fin n, (T₀ (R p) j : ℝ) * x_real j) := by
                simp_rw [Finset.sum_mul, mul_assoc]
                rw [Finset.sum_comm]
                exact Finset.sum_congr rfl (fun p _ => (Finset.mul_sum _ _ _).symm)
          _ = ∑ p : Fin k, (w p : ℝ) * (rhs₀ (R p) : ℝ) := by
                refine Finset.sum_congr rfl (fun p _ => by rw [hx_real (R p)])
      have hRhsCombQ : (rhs₀ i : ℚ) = ∑ p : Fin k, w p * (rhs₀ (R p) : ℚ) := by
        exact_mod_cast hRhsCombR
      rw [hRhsCombQ]
      calc ∑ j : Fin n, (T₀ i j : ℚ) * xRat j
          = ∑ j : Fin n, (∑ p : Fin k, w p * (T₀ (R p) j : ℚ)) * xRat j := by
              refine Finset.sum_congr rfl (fun j _ => by rw [hRowComb j])
        _ = ∑ p : Fin k, w p * (∑ j : Fin n, (T₀ (R p) j : ℚ) * xRat j) := by
              simp_rw [Finset.sum_mul, mul_assoc]
              rw [Finset.sum_comm]
              exact Finset.sum_congr rfl (fun p _ => (Finset.mul_sum _ _ _).symm)
        _ = ∑ p : Fin k, w p * (rhs₀ (R p) : ℚ) := by
              refine Finset.sum_congr rfl (fun p _ => by rw [hxRat_piv p])
    · obtain ⟨p, rfl⟩ := (hUsed i).mp hru
      exact hxRat_piv p


theorem bareissRun_step_bound {m n : ℕ} (T₀ : Fin m → Fin n → ℤ) (rhs₀ : Fin m → ℤ) (U : ℕ)
    (hU : 1 ≤ U)
    (hT : ∀ (i : Fin m) (j : Fin n), (T₀ i j).natAbs ≤ U)
    (hrhs : ∀ i : Fin m, (rhs₀ i).natAbs ≤ U)
    (c : ℕ) (hc : c ≤ n) :
    let st := Fin.foldl c (fun st (j : Fin c) =>
      bareissColStep st ⟨j.val, lt_of_lt_of_le j.isLt hc⟩) (bareissInit T₀ rhs₀)
    st.prevPiv.natAbs ≤ (n + 1).factorial * U ^ (n + 1) ∧
    (∀ (i : Fin m) (j : Fin (n + 1)), (st.A i j).natAbs ≤ (n + 1).factorial * U ^ (n + 1)) := by
  let M : Fin m → Fin (n + 1) → ℤ := fun i j => Fin.lastCases (rhs₀ i) (T₀ i) j
  have hM : ∀ (i : Fin m) (j : Fin (n + 1)), (M i j).natAbs ≤ U := by
    intro i j
    refine Fin.lastCases ?_ (fun j' => ?_) j
    · simp [M, hrhs i]
    · simp [M, hT i j']
  have hFoldInv : ∀ c' : ℕ, (hc' : c' ≤ n) →
      BareissInv M c' (Fin.foldl c' (fun st (j : Fin c') =>
        bareissColStep st ⟨j.val, lt_of_lt_of_le j.isLt hc'⟩) (bareissInit T₀ rhs₀)) := by
    intro c'
    induction c' with
    | zero =>
        intro _
        simpa [M, Fin.foldl_zero] using bareissInv_init T₀ rhs₀
    | succ c' ih =>
        intro hc'
        rw [Fin.foldl_succ_last]
        exact bareissInv_step M ⟨c', hc'⟩ _ (ih (Nat.le_of_succ_le hc'))
  exact bareissInv_entry_bound M U hU hM hc (hFoldInv c hc)

end UL.Proof.cit_gls88_rational_lp.RacerCG
