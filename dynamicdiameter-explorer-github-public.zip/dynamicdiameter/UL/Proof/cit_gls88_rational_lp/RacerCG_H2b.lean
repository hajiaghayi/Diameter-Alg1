import Mathlib
import UL.Proof.cit_gls88_rational_lp.RacerCG_H2a
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

/-! ### 1. Integer Euclidean Division Rounding & Exact Binary-Search `isqrtCeil` -/

theorem ediv_approx_abs_le_one (a b : ℤ) (hb : 0 < b) :
    |(a : ℝ) / (b : ℝ) - ((a / b : ℤ) : ℝ)| ≤ 1 := by
  have hbR : (0 : ℝ) < (b : ℝ) := by exact_mod_cast hb
  have hdiv : b * (a / b) + a % b = a := Int.ediv_add_emod a b
  have hmod0 : 0 ≤ a % b := Int.emod_nonneg a hb.ne'
  have hmod1 : a % b < b := Int.emod_lt_of_pos a hb
  have hdivR : (b : ℝ) * ((a / b : ℤ) : ℝ) + ((a % b : ℤ) : ℝ) = (a : ℝ) := by
    exact_mod_cast hdiv
  have hmod0R : (0 : ℝ) ≤ ((a % b : ℤ) : ℝ) := by exact_mod_cast hmod0
  have hmod1R : ((a % b : ℤ) : ℝ) < (b : ℝ) := by exact_mod_cast hmod1
  have hDiff : (a : ℝ) / (b : ℝ) - ((a / b : ℤ) : ℝ) = ((a % b : ℤ) : ℝ) / (b : ℝ) := by
    field_simp [hbR.ne']
    linarith
  rw [hDiff, abs_of_nonneg (div_nonneg hmod0R hbR.le)]
  exact (div_le_one hbR).mpr hmod1R.le

def isqrtStep (X : ℤ) (lohi : ℤ × ℤ) : ℤ × ℤ :=
  let mid := (lohi.1 + lohi.2) / 2
  if X ≤ mid * mid then (lohi.1, mid) else (mid, lohi.2)

def isqrtCeil (B_sqrt : ℕ) (X : ℤ) : ℤ :=
  (Fin.foldl B_sqrt (fun lohi _ => isqrtStep X lohi) (0, (2 : ℤ) ^ B_sqrt)).2

theorem isqrtCeil_spec (B_sqrt : ℕ) (X : ℤ) (hX_lo : 1 ≤ X)
    (hX_hi : X ≤ ((2 : ℤ) ^ B_sqrt) ^ 2) :
    let Lc := isqrtCeil B_sqrt X
    1 ≤ Lc ∧ Lc ≤ (2 : ℤ) ^ B_sqrt ∧ (Lc - 1) ^ 2 < X ∧ X ≤ Lc ^ 2 := by
  have hInv : ∀ k : ℕ, (hk : k ≤ B_sqrt) →
      let lohi := Fin.foldl k (fun lh (_ : Fin k) => isqrtStep X lh) (0, (2 : ℤ) ^ B_sqrt)
      0 ≤ lohi.1 ∧ lohi.2 ≤ (2 : ℤ) ^ B_sqrt ∧
      lohi.2 - lohi.1 = (2 : ℤ) ^ (B_sqrt - k) ∧
      lohi.1 ^ 2 < X ∧ X ≤ lohi.2 ^ 2 := by
    intro k
    induction k with
    | zero =>
        intro _
        rw [Fin.foldl_zero, Nat.sub_zero]
        dsimp only
        exact ⟨le_rfl, le_rfl, sub_zero _, by norm_num; linarith, hX_hi⟩
    | succ k ih =>
        intro hk
        rw [Fin.foldl_succ_last]
        obtain ⟨hlo0, hhiB, hdiff, hloX, hhiX⟩ := ih (Nat.le_of_succ_le hk)
        let lh := Fin.foldl k (fun lh (_ : Fin k) => isqrtStep X lh) (0, (2 : ℤ) ^ B_sqrt)
        change 0 ≤ (isqrtStep X lh).1 ∧ (isqrtStep X lh).2 ≤ (2 : ℤ) ^ B_sqrt ∧
          (isqrtStep X lh).2 - (isqrtStep X lh).1 = (2 : ℤ) ^ (B_sqrt - (k + 1)) ∧
          (isqrtStep X lh).1 ^ 2 < X ∧ X ≤ (isqrtStep X lh).2 ^ 2
        let d : ℤ := (2 : ℤ) ^ (B_sqrt - (k + 1))
        have hd_pos : 0 < d := by dsimp [d]; positivity
        have hsub_eq : B_sqrt - k = (B_sqrt - (k + 1)) + 1 := by omega
        have hdiff2 : lh.2 - lh.1 = 2 * d := by
          rw [hdiff, hsub_eq, pow_succ']
        have hsum_eq : lh.1 + lh.2 = (lh.1 + d) * 2 := by linarith
        have hmid_eq : (lh.1 + lh.2) / 2 = lh.1 + d := by
          rw [hsum_eq, Int.mul_ediv_cancel _ (by norm_num)]
        dsimp only [isqrtStep]
        rw [hmid_eq]
        by_cases hcond : X ≤ (lh.1 + d) * (lh.1 + d)
        · rw [if_pos hcond]
          refine ⟨hlo0, by linarith, by ring, hloX, ?_⟩
          simpa [sq] using hcond
        · rw [if_neg hcond]
          push_neg at hcond
          refine ⟨by linarith, hhiB, by linarith, ?_, hhiX⟩
          simpa [sq] using hcond
  have hB := hInv B_sqrt le_rfl
  let lh := Fin.foldl B_sqrt (fun lh (_ : Fin B_sqrt) => isqrtStep X lh) (0, (2 : ℤ) ^ B_sqrt)
  change 0 ≤ lh.1 ∧ lh.2 ≤ (2 : ℤ) ^ B_sqrt ∧ lh.2 - lh.1 = (2 : ℤ) ^ (B_sqrt - B_sqrt) ∧
    lh.1 ^ 2 < X ∧ X ≤ lh.2 ^ 2 at hB
  obtain ⟨hlo0, hhiB, hdiff, hloX, hhiX⟩ := hB
  simp only [Nat.sub_self, pow_zero] at hdiff
  have hlo_eq : lh.1 = lh.2 - 1 := by omega
  rw [hlo_eq] at hlo0 hloX
  unfold isqrtCeil
  change 1 ≤ lh.2 ∧ lh.2 ≤ (2 : ℤ) ^ B_sqrt ∧ (lh.2 - 1) ^ 2 < X ∧ X ≤ lh.2 ^ 2
  exact ⟨by omega, hhiB, hloX, hhiX⟩

/-! ### 2. Pure Functional Rounded Integer Ellipsoid Feasibility Oracle -/

structure EllState (N : ℕ) where
  status : ℤ
  C : Fin N → ℤ
  A : Fin N → Fin N → ℤ

def padCols {n m : ℕ} (M : Fin m → Fin n → ℤ) : Fin m → Fin (n + 2) → ℤ :=
  fun i j => if hj : j.val < n then M i ⟨j.val, hj⟩ else 0

def findViolatedRow {m N : ℕ} (P Q : ℤ) (M_pad : Fin m → Fin N → ℤ) (d : Fin m → ℤ)
    (C : Fin N → ℤ) : ℤ :=
  Fin.foldl m (fun v i =>
    if v == -1 && P * (Q * d i + 1) < Q * (∑ j : Fin N, M_pad i j * C j) then
      (i.val : ℤ)
    else v) (-1)

theorem findViolatedRow_spec {m N : ℕ} (P Q : ℤ) (M_pad : Fin m → Fin N → ℤ) (d : Fin m → ℤ)
    (C : Fin N → ℤ) :
    (findViolatedRow P Q M_pad d C = -1 ∧
      ∀ i : Fin m, Q * (∑ j : Fin N, M_pad i j * C j) ≤ P * (Q * d i + 1)) ∨
    (∃ i₀ : Fin m, findViolatedRow P Q M_pad d C = (i₀.val : ℤ) ∧
      P * (Q * d i₀ + 1) < Q * (∑ j : Fin N, M_pad i₀ j * C j)) := by
  let step : ℤ → Fin m → ℤ := fun v i =>
    if v == -1 && P * (Q * d i + 1) < Q * (∑ j : Fin N, M_pad i j * C j) then (i.val : ℤ) else v
  suffices h : ∀ k : ℕ, (hk : k ≤ m) →
      let res := Fin.foldl k (fun v (i : Fin k) => step v ⟨i.val, lt_of_lt_of_le i.isLt hk⟩) (-1)
      (res = -1 ∧ ∀ i : Fin m, i.val < k → Q * (∑ j : Fin N, M_pad i j * C j) ≤ P * (Q * d i + 1)) ∨
      (∃ i₀ : Fin m, i₀.val < k ∧ res = (i₀.val : ℤ) ∧
        P * (Q * d i₀ + 1) < Q * (∑ j : Fin N, M_pad i₀ j * C j)) by
    rcases h m le_rfl with ⟨h1, h2⟩ | ⟨i₀, _, h1, h2⟩
    · left; exact ⟨h1, fun i => h2 i i.isLt⟩
    · right; exact ⟨i₀, h1, h2⟩
  intro k
  induction k with
  | zero =>
      intro _
      left
      exact ⟨by simp [Fin.foldl_zero], fun i hi => False.elim (Nat.not_lt_zero _ hi)⟩
  | succ k ih =>
      intro hk
      let prev := Fin.foldl k (fun v (i : Fin k) => step v ⟨i.val, lt_of_lt_of_le i.isLt (Nat.le_of_succ_le hk)⟩) (-1)
      have hfold : Fin.foldl (k + 1) (fun v (i : Fin (k + 1)) => step v ⟨i.val, lt_of_lt_of_le i.isLt hk⟩) (-1) =
          step prev ⟨k, hk⟩ := by
        rw [Fin.foldl_succ_last]; rfl
      dsimp only
      rw [hfold]
      rcases ih (Nat.le_of_succ_le hk) with ⟨hNeg, hLe⟩ | ⟨i₀, hi₀_lt, hEq, hGt⟩
      · have hprev : prev = -1 := hNeg
        rw [hprev]
        let ik : Fin m := ⟨k, hk⟩
        by_cases hCond : P * (Q * d ik + 1) < Q * (∑ j : Fin N, M_pad ik j * C j)
        · right
          refine ⟨ik, Nat.lt_succ_self k, ?_, hCond⟩
          simp [step, ik, hCond]
        · left
          push_neg at hCond
          have hStep : step (-1) ik = -1 := by
            simp [step, not_lt.mpr hCond]
          rw [hStep]
          refine ⟨rfl, fun i hi => ?_⟩
          rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | heq
          · exact hLe i hlt
          · have hi_eq : i = ik := Fin.ext heq
            subst hi_eq
            exact hCond
      · right
        have hNotNeg1 : (i₀.val : ℤ) ≠ -1 := by omega
        have hprev : prev = (i₀.val : ℤ) := hEq
        rw [hprev]
        have hStep : step (i₀.val : ℤ) ⟨k, hk⟩ = (i₀.val : ℤ) := by simp [step, hNotNeg1]
        rw [hStep]
        exact ⟨i₀, Nat.lt_succ_of_lt hi₀_lt, rfl, hGt⟩

def ellParamE (N L : ℕ) : ℕ := (N + 2) * (N + 2 + L)
def ellParamT (N L : ℕ) : ℕ := 10 * (N + 1) * N * (3 * ellParamE N L + N + 2) + 1
def ellParamBsqrt (N L : ℕ) : ℕ := 10 * ellParamE N L + 2 * ellParamT N L

def ellInit (N L : ℕ) : EllState N :=
  let E := ellParamE N L
  { status := 0
    C := fun _ => 0
    A := fun i j => if i = j then (2 : ℤ) ^ (7 * E) else 0 }

def ellStep {m N : ℕ} (L : ℕ) (M_pad : Fin m → Fin N → ℤ) (d : Fin m → ℤ)
    (st : EllState N) : EllState N :=
  if st.status != 0 then
    st
  else
    let E := ellParamE N L
    let Q : ℤ := (2 : ℤ) ^ (E + 1)
    let P : ℤ := (2 : ℤ) ^ (6 * E)
    let B_sqrt := ellParamBsqrt N L
    let K : ℤ := 16 * (N : ℤ) * (N : ℤ)
    let viol := findViolatedRow P Q M_pad d st.C
    if h : 0 ≤ viol ∧ viol.toNat < m then
      let i₀ : Fin m := ⟨viol.toNat, h.2⟩
      let G : Fin N → ℤ := fun j => ∑ k : Fin N, M_pad i₀ k * st.A k j
      let S_norm : ℤ := ∑ j : Fin N, G j * G j
      if S_norm ≤ 0 then
        { st with status := -1 }
      else
        let L_ceil : ℤ := isqrtCeil B_sqrt (K * K * S_norm)
        let H : Fin N → ℤ := fun i => ∑ k : Fin N, st.A i k * G k
        let denC : ℤ := ((N : ℤ) + 1) * L_ceil
        let denA : ℤ := 8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) * L_ceil * L_ceil
        { status := 0
          C := fun i => st.C i - (K * H i) / denC
          A := fun i j =>
            ((8 * (N : ℤ) * (N : ℤ) + 1) *
              ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * st.A i j -
                (2 * (N : ℤ) - 1) * (K * K) * H i * G j)) / denA }
    else
      { st with status := 1 }

def ellRun (n m L : ℕ) (M : Fin m → Fin n → ℤ) (d : Fin m → ℤ) : EllState (n + 2) :=
  let N := n + 2
  let T := ellParamT N L
  Fin.foldl T (fun st _ => ellStep L (padCols M) d st) (ellInit N L)

def ellipsoidDecide (n m L : ℕ) (M : Fin m → Fin n → ℤ) (d : Fin m → ℤ) : Bool :=
  (ellRun n m L M d).status == 1


/-! ### 3. Algebraic Bridge & Unconditional Magnitude Invariants of `ellStep` -/

theorem ellStep_exact_formulas {N : ℕ} (hN : 2 ≤ N)
    (stC : Fin N → ℤ) (stA : Fin N → Fin N → ℤ) (G : Fin N → ℤ)
    (L_ceil : ℤ) (hLc : 1 ≤ L_ceil) (P_real : ℝ) (hP : 0 < P_real) :
    let K : ℤ := 16 * (N : ℤ) * (N : ℤ)
    let H : Fin N → ℤ := fun i => ∑ k : Fin N, stA i k * G k
    let denC : ℤ := ((N : ℤ) + 1) * L_ceil
    let denA : ℤ := 8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) * L_ceil * L_ceil
    let w : Fin N → ℝ := fun j => ((K : ℝ) * (G j : ℝ)) / (L_ceil : ℝ)
    let c_t : Fin N → ℝ := fun i => (stC i : ℝ) / P_real
    let B_t : Matrix (Fin N) (Fin N) ℝ := fun i j => (stA i j : ℝ) / P_real
    let c' : Fin N → ℝ := fun i => c_t i - (1 / ((N : ℝ) + 1)) * (B_t.mulVec w) i
    let B' : Matrix (Fin N) (Fin N) ℝ := B_t * ellStepMat N w
    0 < denC ∧ 0 < denA ∧
    (∀ i : Fin N, P_real * c' i = (stC i : ℝ) - ((K * H i : ℤ) : ℝ) / (denC : ℝ)) ∧
    (∀ i j : Fin N, P_real * B' i j =
      (((8 * (N : ℤ) * (N : ℤ) + 1) *
        ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * stA i j -
          (2 * (N : ℤ) - 1) * (K * K) * H i * G j) : ℤ) : ℝ) / (denA : ℝ)) := by
  intro K H denC denA w c_t B_t c' B'
  have hNR : (2 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
  have hNZ : (2 : ℤ) ≤ (N : ℤ) := by omega
  have hdenC_pos : 0 < denC := by dsimp [denC]; nlinarith only [hNZ, hLc]
  have hdenA_pos : 0 < denA := by
    dsimp [denA]
    have h1 : (0 : ℤ) < 8 * (N : ℤ) * (N : ℤ) := by nlinarith only [hNZ]
    have h2 : (0 : ℤ) < 2 * (N : ℤ) * (N : ℤ) - 2 := by nlinarith only [hNZ]
    have h3 : (0 : ℤ) < L_ceil * L_ceil := mul_pos (by omega) (by omega)
    exact mul_pos (mul_pos (mul_pos h1 h2) (by omega)) (by omega)
  have hLcR_ne : (L_ceil : ℝ) ≠ 0 := by
    have : (0 : ℝ) < (L_ceil : ℝ) := by exact_mod_cast (by omega : 0 < L_ceil)
    exact this.ne'
  have hP_ne : P_real ≠ 0 := hP.ne'
  obtain ⟨_, _, _, _, hdiff_eq⟩ := ell_params_pos hN
  refine ⟨hdenC_pos, hdenA_pos, ?_, ?_⟩
  · intro i
    dsimp only [c', c_t, B_t]
    have hBw : (Matrix.of (fun a b : Fin N => (stA a b : ℝ) / P_real)).mulVec w i =
        ((K : ℝ) * (H i : ℝ)) / (P_real * (L_ceil : ℝ)) := by
      simp only [Matrix.mulVec, dotProduct, Matrix.of_apply, w, H, Int.cast_sum, Int.cast_mul]
      rw [Finset.mul_sum, Finset.sum_div]
      refine Finset.sum_congr rfl (fun k _ => ?_)
      field_simp [hP_ne, hLcR_ne]
      try ring
    change P_real * ((stC i : ℝ) / P_real -
      1 / ((N : ℝ) + 1) * (Matrix.of (fun a b => (stA a b : ℝ) / P_real)).mulVec w i) = _
    rw [hBw]
    have hd1 : (N : ℝ) + 1 ≠ 0 := by linarith
    have hdenCR : (denC : ℝ) = ((N : ℝ) + 1) * (L_ceil : ℝ) := by dsimp [denC]; push_cast; ring
    rw [hdenCR, Int.cast_mul K (H i)]
    dsimp only [K] at *
    field_simp [hP_ne, hd1, hLcR_ne]
    try ring
  · intro i j
    have hEntry : B' i j = ellInfl N *
        (ellLam2 N * ((stA i j : ℝ) / P_real) -
          (ellLam2 N - ellLam1 N) * (((K : ℝ) * (H i : ℝ)) / (P_real * (L_ceil : ℝ))) * w j) := by
      dsimp only [B', B_t, ellStepMat]
      simp only [Matrix.mul_apply, Matrix.smul_apply, Matrix.sub_apply, Matrix.one_apply,
        Matrix.of_apply, smul_eq_mul]
      have h1 : ∑ k : Fin N, ((stA i k : ℝ) / P_real) *
          (ellInfl N * (ellLam2 N * (if k = j then 1 else 0) -
            (ellLam2 N - ellLam1 N) * (w k * w j))) =
          (∑ k : Fin N, if k = j then ellInfl N * ellLam2 N * ((stA i k : ℝ) / P_real) else 0) -
            (ellInfl N * (ellLam2 N - ellLam1 N) * w j) *
              (∑ k : Fin N, ((stA i k : ℝ) / P_real) * w k) := by
        rw [Finset.mul_sum, ← Finset.sum_sub_distrib]
        refine Finset.sum_congr rfl (fun k _ => ?_)
        by_cases hkj : k = j <;> simp [hkj] <;> ring
      change ∑ k : Fin N, ((stA i k : ℝ) / P_real) * _ = _
      rw [h1]
      simp only [Finset.sum_ite_eq', Finset.mem_univ, ↓reduceIte]
      have hSumW : ∑ k : Fin N, ((stA i k : ℝ) / P_real) * w k =
          ((K : ℝ) * (H i : ℝ)) / (P_real * (L_ceil : ℝ)) := by
        simp only [w, H, Int.cast_sum, Int.cast_mul]
        rw [Finset.mul_sum, Finset.sum_div]
        refine Finset.sum_congr rfl (fun k _ => ?_)
        dsimp only [K]
        field_simp [hP_ne, hLcR_ne]
        try ring
      rw [hSumW]
      ring
    rw [hEntry, hdiff_eq]
    dsimp only [ellInfl, ellLam2, w, denA, K]
    push_cast
    have hd2 : 2 * (N : ℝ) ^ 2 - 2 ≠ 0 := by nlinarith only [hNR]
    have hd3 : 8 * (N : ℝ) ^ 2 ≠ 0 := by nlinarith only [hNR]
    have hL2 : (L_ceil : ℝ) * (L_ceil : ℝ) ≠ 0 := mul_ne_zero hLcR_ne hLcR_ne
    field_simp [hP_ne, hd2, hd3, hLcR_ne, hL2]
    try ring

/-- Unconditional Frobenius and center bounds at every iteration `t ≤ T` of `ellRun`,
together with the `isqrtCeil` range invariant `K^2 * S_norm ≤ (2^B_sqrt)^2`. -/
def EllMagInv {N : ℕ} (E t : ℕ) (st : EllState N) : Prop :=
  (∑ i : Fin N, ∑ j : Fin N, (st.A i j : ℝ) ^ 2 ≤ ((2 : ℝ) ^ (8 * E + 2 * t)) ^ 2) ∧
  (∀ i : Fin N, (st.C i).natAbs ≤ t * 2 ^ (9 * E + 2 * t))

theorem ellMagInv_entry_abs {N E t : ℕ} {st : EllState N} (hMag : EllMagInv E t st)
    (i j : Fin N) : (st.A i j).natAbs ≤ 2 ^ (8 * E + 2 * t) := by
  have hsq : (st.A i j : ℝ) ^ 2 ≤ ((2 : ℝ) ^ (8 * E + 2 * t)) ^ 2 := by
    have h1 := Finset.single_le_sum (f := fun b : Fin N => (st.A i b : ℝ) ^ 2)
      (fun _ _ => sq_nonneg _) (Finset.mem_univ j)
    have h2 := Finset.single_le_sum (f := fun a : Fin N => ∑ b : Fin N, (st.A a b : ℝ) ^ 2)
      (fun _ _ => Finset.sum_nonneg (fun _ _ => sq_nonneg _)) (Finset.mem_univ i)
    exact (h1.trans h2).trans hMag.1
  have habs := sq_le_sq.mp hsq
  rw [real_abs_int_eq_natAbs, abs_of_nonneg (by positivity)] at habs
  have hpow : ((2 : ℝ) ^ (8 * E + 2 * t)) = (((2 ^ (8 * E + 2 * t) : ℕ) : ℝ)) := by norm_cast
  rw [hpow] at habs
  exact_mod_cast habs

theorem ellStep_isqrt_range {m N L t : ℕ} (hN : 2 ≤ N) (hL : 1 ≤ L)
    (ht : t ≤ ellParamT N L)
    (M_pad : Fin m → Fin N → ℤ)
    (hM : ∀ (i : Fin m) (j : Fin N), (M_pad i j).natAbs ≤ 2 ^ L)
    {st : EllState N} (hMag : EllMagInv (ellParamE N L) t st)
    (i₀ : Fin m) :
    let K : ℤ := 16 * (N : ℤ) * (N : ℤ)
    let G : Fin N → ℤ := fun j => ∑ k : Fin N, M_pad i₀ k * st.A k j
    let S_norm : ℤ := ∑ j : Fin N, G j * G j
    K * K * S_norm ≤ ((2 : ℤ) ^ (ellParamBsqrt N L)) ^ 2 := by
  intro K G S_norm
  let E := ellParamE N L
  let T := ellParamT N L
  let B_sqrt := ellParamBsqrt N L
  have hG_abs : ∀ j : Fin N, (G j).natAbs ≤ N * 2 ^ L * 2 ^ (8 * E + 2 * t) := by
    intro j
    have hR : |(G j : ℝ)| ≤ (N : ℝ) * ((2 ^ L : ℕ) : ℝ) * ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ) := by
      dsimp only [G]
      simp only [Int.cast_sum, Int.cast_mul]
      calc |∑ k : Fin N, (M_pad i₀ k : ℝ) * (st.A k j : ℝ)|
          ≤ ∑ k : Fin N, |(M_pad i₀ k : ℝ) * (st.A k j : ℝ)| := Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ _k : Fin N, ((2 ^ L : ℕ) : ℝ) * ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ) := by
            refine Finset.sum_le_sum (fun k _ => ?_)
            rw [abs_mul, real_abs_int_eq_natAbs, real_abs_int_eq_natAbs]
            exact mul_le_mul (by exact_mod_cast hM i₀ k)
              (by exact_mod_cast ellMagInv_entry_abs hMag k j) (by positivity) (by positivity)
        _ = (N : ℝ) * ((2 ^ L : ℕ) : ℝ) * ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ) := by
            simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
            ring
    rw [real_abs_int_eq_natAbs] at hR
    push_cast at hR
    exact_mod_cast hR
  have hGJ_pow : ∀ j : Fin N, (G j).natAbs ≤ 2 ^ (9 * E + 2 * t) := by
    intro j
    have hNL : N * 2 ^ L ≤ 2 ^ E := by
      have h1 : N ≤ 2 ^ N := Nat.lt_two_pow_self.le
      have h2 : N + L ≤ E := by dsimp [E, ellParamE]; nlinarith
      calc N * 2 ^ L ≤ 2 ^ N * 2 ^ L := Nat.mul_le_mul_right _ h1
        _ = 2 ^ (N + L) := (pow_add 2 N L).symm
        _ ≤ 2 ^ E := Nat.pow_le_pow_right (by omega) h2
    calc (G j).natAbs ≤ N * 2 ^ L * 2 ^ (8 * E + 2 * t) := hG_abs j
      _ ≤ 2 ^ E * 2 ^ (8 * E + 2 * t) := Nat.mul_le_mul_right _ hNL
      _ = 2 ^ (9 * E + 2 * t) := by rw [← pow_add]; ring_nf
  -- Bound K * K * S_norm in ℤ via ℕ
  have hKN_pow : (16 * N * N) ^ 2 * N ≤ 2 ^ (2 * E) := by
    have h1 : N ≤ 2 ^ N := Nat.lt_two_pow_self.le
    have h5 : 256 * N ^ 5 ≤ 2 ^ (8 + 5 * N) := by
      have hN5 : N ^ 5 ≤ (2 ^ N) ^ 5 := Nat.pow_le_pow_left h1 5
      calc 256 * N ^ 5 ≤ 2 ^ 8 * (2 ^ N) ^ 5 := Nat.mul_le_mul_left 256 hN5
        _ = 2 ^ (8 + 5 * N) := by rw [← pow_mul, ← pow_add]; ring_nf
    have hexp : 8 + 5 * N ≤ 2 * E := by
      dsimp [E, ellParamE]
      nlinarith
    calc (16 * N * N) ^ 2 * N = 256 * N ^ 5 := by ring
      _ ≤ 2 ^ (8 + 5 * N) := h5
      _ ≤ 2 ^ (2 * E) := Nat.pow_le_pow_right (by omega) hexp
  have hS_ub : S_norm ≤ ((N * (2 ^ (9 * E + 2 * t)) ^ 2 : ℕ) : ℤ) := by
    dsimp only [S_norm]
    calc ∑ j : Fin N, G j * G j
        ≤ ∑ _j : Fin N, (((2 ^ (9 * E + 2 * t)) ^ 2 : ℕ) : ℤ) := by
          refine Finset.sum_le_sum (fun j _ => ?_)
          have hj : (G j * G j).natAbs ≤ (2 ^ (9 * E + 2 * t)) ^ 2 := by
            rw [Int.natAbs_mul, ← sq]
            exact Nat.pow_le_pow_left (hGJ_pow j) 2
          have hnn : 0 ≤ G j * G j := mul_self_nonneg (G j)
          have heq : G j * G j = ((G j * G j).natAbs : ℤ) := (Int.natAbs_of_nonneg hnn).symm
          rw [heq]
          exact_mod_cast hj
      _ = ((N * (2 ^ (9 * E + 2 * t)) ^ 2 : ℕ) : ℤ) := by simp; try ring
  have hS_nn : 0 ≤ S_norm := Finset.sum_nonneg (fun j _ => mul_self_nonneg (G j))
  have hKK_eq : K * K = (((16 * N * N) ^ 2 : ℕ) : ℤ) := by push_cast; dsimp [K]; ring
  rw [hKK_eq]
  calc (((16 * N * N) ^ 2 : ℕ) : ℤ) * S_norm
      ≤ (((16 * N * N) ^ 2 : ℕ) : ℤ) * ((N * (2 ^ (9 * E + 2 * t)) ^ 2 : ℕ) : ℤ) :=
        mul_le_mul_of_nonneg_left hS_ub (by positivity)
    _ = ((((16 * N * N) ^ 2 * N) * (2 ^ (9 * E + 2 * t)) ^ 2 : ℕ) : ℤ) := by push_cast; ring
    _ ≤ (((2 ^ (2 * E) * (2 ^ (9 * E + 2 * t)) ^ 2 : ℕ)) : ℤ) := by
        exact_mod_cast Nat.mul_le_mul_right _ hKN_pow
    _ ≤ ((2 : ℤ) ^ B_sqrt) ^ 2 := by
        have hNat : 2 ^ (2 * E) * (2 ^ (9 * E + 2 * t)) ^ 2 ≤ (2 ^ B_sqrt) ^ 2 := by
          have h1 : 2 ^ (2 * E) * (2 ^ (9 * E + 2 * t)) ^ 2 = 2 ^ (20 * E + 4 * t) := by
            rw [← pow_mul, ← pow_add]; ring_nf
          have h2 : (2 ^ B_sqrt) ^ 2 = 2 ^ (2 * B_sqrt) := by
            rw [← pow_mul]; ring_nf
          rw [h1, h2]
          refine Nat.pow_le_pow_right (by omega) ?_
          dsimp [B_sqrt, ellParamBsqrt, T] at ht ⊢
          omega
        exact_mod_cast hNat

theorem ellMagInv_init {N L : ℕ} (hN : 2 ≤ N) (hL : 1 ≤ L) :
    EllMagInv (ellParamE N L) 0 (ellInit N L) := by
  let E := ellParamE N L
  constructor
  · change ∑ i : Fin N, ∑ j : Fin N, ((if i = j then (2 : ℤ) ^ (7 * E) else 0 : ℤ) : ℝ) ^ 2 ≤
        ((2 : ℝ) ^ (8 * E)) ^ 2
    have hDiag : ∀ i : Fin N,
        ∑ j : Fin N, ((if i = j then (2 : ℤ) ^ (7 * E) else 0 : ℤ) : ℝ) ^ 2 =
          ((2 : ℝ) ^ (7 * E)) ^ 2 := by
      intro i
      have hpt : ∀ j : Fin N, ((if i = j then (2 : ℤ) ^ (7 * E) else 0 : ℤ) : ℝ) ^ 2 =
          if j = i then ((2 : ℝ) ^ (7 * E)) ^ 2 else 0 := by
        intro j
        by_cases hij : i = j
        · subst hij; simp
        · have hji : j ≠ i := Ne.symm hij; simp [hij, hji]
      simp_rw [hpt]
      simp
    simp_rw [hDiag]
    simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    have hN_le : (N : ℝ) ≤ ((2 : ℝ) ^ E) ^ 2 := by
      have hNat : N ≤ (2 ^ E) ^ 2 := by
        have h1 : N ≤ 2 ^ N := Nat.lt_two_pow_self.le
        have h2 : N ≤ 2 * E := by dsimp [E, ellParamE]; nlinarith
        calc N ≤ 2 ^ N := h1
          _ ≤ 2 ^ (2 * E) := Nat.pow_le_pow_right (by omega) h2
          _ = (2 ^ E) ^ 2 := by rw [← pow_mul]; ring_nf
      exact_mod_cast hNat
    calc (N : ℝ) * ((2 : ℝ) ^ (7 * E)) ^ 2
        ≤ ((2 : ℝ) ^ E) ^ 2 * ((2 : ℝ) ^ (7 * E)) ^ 2 :=
          mul_le_mul_of_nonneg_right hN_le (by positivity)
      _ = ((2 : ℝ) ^ (8 * E)) ^ 2 := by
          rw [← mul_pow, ← pow_add]
          ring_nf
  · intro i
    dsimp [ellInit]
    omega

theorem ellMagInv_step {m N L t : ℕ} (hN : 2 ≤ N) (hL : 1 ≤ L)
    (ht : t < ellParamT N L)
    (M_pad : Fin m → Fin N → ℤ) (d : Fin m → ℤ)
    (hM : ∀ (i : Fin m) (j : Fin N), (M_pad i j).natAbs ≤ 2 ^ L)
    {st : EllState N} (hMag : EllMagInv (ellParamE N L) t st) :
    EllMagInv (ellParamE N L) (t + 1) (ellStep L M_pad d st) := by
  let E := ellParamE N L
  have hStepMono : EllMagInv E t st → EllMagInv E (t + 1) st := by
    rintro ⟨hA, hC⟩
    refine ⟨?_, ?_⟩
    · have hpow : (2 : ℝ) ^ (8 * E + 2 * t) ≤ (2 : ℝ) ^ (8 * E + 2 * (t + 1)) :=
        pow_le_pow_right₀ (by norm_num) (by omega)
      exact hA.trans (pow_le_pow_left₀ (by positivity) hpow 2)
    · intro i
      calc (st.C i).natAbs ≤ t * 2 ^ (9 * E + 2 * t) := hC i
        _ ≤ (t + 1) * 2 ^ (9 * E + 2 * (t + 1)) :=
            Nat.mul_le_mul (by omega) (Nat.pow_le_pow_right (by omega) (by omega))
  unfold ellStep
  by_cases hst : (st.status != 0) = true
  · rw [if_pos hst]
    exact hStepMono hMag
  · rw [if_neg hst]
    dsimp only
    by_cases hviol : 0 ≤ findViolatedRow ((2 : ℤ) ^ (6 * E)) ((2 : ℤ) ^ (E + 1)) M_pad d st.C ∧
        (findViolatedRow ((2 : ℤ) ^ (6 * E)) ((2 : ℤ) ^ (E + 1)) M_pad d st.C).toNat < m
    · rw [dif_pos hviol]
      let i₀ : Fin m := ⟨(findViolatedRow ((2 : ℤ) ^ (6 * E)) ((2 : ℤ) ^ (E + 1)) M_pad d st.C).toNat, hviol.2⟩
      let G : Fin N → ℤ := fun j => ∑ k : Fin N, M_pad i₀ k * st.A k j
      let S_norm : ℤ := ∑ j : Fin N, G j * G j
      by_cases hS0 : S_norm ≤ 0
      · dsimp only; rw [if_pos hS0]
        exact hStepMono ⟨hMag.1, hMag.2⟩
      · dsimp only; rw [if_neg hS0]
        push_neg at hS0
        have hS1 : 1 ≤ S_norm := by omega
        let K : ℤ := 16 * (N : ℤ) * (N : ℤ)
        have hK_pos : 0 < K := by
          dsimp [K]
          have hNZ : (2 : ℤ) ≤ (N : ℤ) := by omega
          nlinarith only [hNZ]
        have hKKS_lo : 1 ≤ K * K * S_norm := by nlinarith
        have hKKS_hi := ellStep_isqrt_range hN hL ht.le M_pad hM hMag i₀
        obtain ⟨hLc_lo, _, _, hLc_sq⟩ := isqrtCeil_spec (ellParamBsqrt N L) (K * K * S_norm) hKKS_lo hKKS_hi
        let L_ceil : ℤ := isqrtCeil (ellParamBsqrt N L) (K * K * S_norm)
        obtain ⟨hdenC_pos, hdenA_pos, hc_form, hB_form⟩ :=
          ellStep_exact_formulas hN st.C st.A G L_ceil hLc_lo 1 zero_lt_one
        simp only [one_mul, div_one] at hc_form hB_form
        let w : Fin N → ℝ := fun j => ((K : ℝ) * (G j : ℝ)) / (L_ceil : ℝ)
        have hw_sq : ∑ j : Fin N, (w j) ^ 2 ≤ 1 := by
          have hLcR_pos : (0 : ℝ) < (L_ceil : ℝ) := by exact_mod_cast (by omega : 0 < L_ceil)
          have hSum : ∑ j : Fin N, (w j) ^ 2 = ((K * K * S_norm : ℤ) : ℝ) / (L_ceil : ℝ) ^ 2 := by
            dsimp [w, S_norm]
            push_cast
            rw [Finset.mul_sum, Finset.sum_div]
            refine Finset.sum_congr rfl (fun j _ => ?_)
            dsimp only [K]; field_simp [hLcR_pos.ne']; try ring
          rw [hSum, div_le_one (sq_pos_of_pos hLcR_pos)]
          have hsqR : ((K * K * S_norm : ℤ) : ℝ) ≤ ((L_ceil ^ 2 : ℤ) : ℝ) := by exact_mod_cast hLc_sq
          simpa using hsqR
        let B_unscaled : Matrix (Fin N) (Fin N) ℝ := fun i j => (st.A i j : ℝ)
        let B' : Matrix (Fin N) (Fin N) ℝ := B_unscaled * ellStepMat N w
        have hFrobB' : ∑ i : Fin N, ∑ j : Fin N, (B' i j) ^ 2 ≤
            (7 / 4 : ℝ) ^ 2 * ((2 : ℝ) ^ (8 * E + 2 * t)) ^ 2 :=
          (ellStepMat_frobenius_le hN B_unscaled w hw_sq).trans
            (mul_le_mul_of_nonneg_left hMag.1 (by positivity))
        let H : Fin N → ℤ := fun i => ∑ k : Fin N, st.A i k * G k
        let denC : ℤ := ((N : ℤ) + 1) * L_ceil
        let denA : ℤ := 8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) * L_ceil * L_ceil
        let numA : Fin N → Fin N → ℤ := fun i j =>
          (8 * (N : ℤ) * (N : ℤ) + 1) *
            ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * st.A i j -
              (2 * (N : ℤ) - 1) * (K * K) * H i * G j)
        constructor
        · -- Bound ∑ i, ∑ j, (numA i j / denA)^2 ≤ (2^(8*E + 2*(t+1)))^2
          have hPtSq : ∀ i j : Fin N, (((numA i j / denA : ℤ) : ℝ)) ^ 2 ≤ 2 * (B' i j) ^ 2 + 2 := by
            intro i j
            have herr := ediv_approx_abs_le_one (numA i j) denA hdenA_pos
            have hBeq : B' i j = (numA i j : ℝ) / (denA : ℝ) := by
              simpa only [B', B_unscaled, w, K, H, numA, denA, one_mul, div_one] using hB_form i j
            rw [← hBeq] at herr
            let e : ℝ := ((numA i j / denA : ℤ) : ℝ) - B' i j
            have he2 : e ^ 2 ≤ 1 := by
              have he_abs : |e| ≤ 1 := by
                dsimp only [e]
                rw [abs_sub_comm]
                exact herr
              simpa [sq_abs] using pow_le_pow_left₀ (abs_nonneg e) he_abs 2
            have h2sq : (B' i j + e) ^ 2 ≤ 2 * (B' i j) ^ 2 + 2 * e ^ 2 := by
              have : 0 ≤ (B' i j - e) ^ 2 := sq_nonneg _
              linarith [show (B' i j + e) ^ 2 + (B' i j - e) ^ 2 = 2 * (B' i j) ^ 2 + 2 * e ^ 2 by ring]
            have hsum : B' i j + e = ((numA i j / denA : ℤ) : ℝ) := by dsimp [e]; ring
            rw [← hsum]
            linarith
          have hSumA' : ∑ i : Fin N, ∑ j : Fin N, (((numA i j / denA : ℤ) : ℝ)) ^ 2 ≤
              2 * (∑ i : Fin N, ∑ j : Fin N, (B' i j) ^ 2) + 2 * (N : ℝ) ^ 2 := by
            calc ∑ i : Fin N, ∑ j : Fin N, (((numA i j / denA : ℤ) : ℝ)) ^ 2
                ≤ ∑ i : Fin N, ∑ j : Fin N, (2 * (B' i j) ^ 2 + 2) :=
                  Finset.sum_le_sum (fun i _ => Finset.sum_le_sum (fun j _ => hPtSq i j))
              _ = 2 * (∑ i : Fin N, ∑ j : Fin N, (B' i j) ^ 2) + 2 * (N : ℝ) ^ 2 := by
                  simp [Finset.sum_add_distrib, ← Finset.mul_sum]
                  ring
          have h2N2_le : 2 * (N : ℝ) ^ 2 ≤ ((2 : ℝ) ^ (8 * E + 2 * t)) ^ 2 := by
            have hNat : 2 * N ^ 2 ≤ (2 ^ (8 * E + 2 * t)) ^ 2 := by
              have h1 : N ≤ 2 ^ N := Nat.lt_two_pow_self.le
              have h2 : 1 + 2 * N ≤ 2 * (8 * E + 2 * t) := by dsimp [E, ellParamE]; nlinarith
              calc 2 * N ^ 2 ≤ 2 * (2 ^ N) ^ 2 := Nat.mul_le_mul_left 2 (Nat.pow_le_pow_left h1 2)
                _ = 2 ^ (1 + 2 * N) := by rw [← pow_mul, ← pow_succ']; ring_nf
                _ ≤ 2 ^ (2 * (8 * E + 2 * t)) := Nat.pow_le_pow_right (by omega) h2
                _ = (2 ^ (8 * E + 2 * t)) ^ 2 := by rw [← pow_mul]; ring_nf
            exact_mod_cast hNat
          have hPowStep : ((2 : ℝ) ^ (8 * E + 2 * (t + 1))) ^ 2 =
              16 * ((2 : ℝ) ^ (8 * E + 2 * t)) ^ 2 := by
            have : 8 * E + 2 * (t + 1) = (8 * E + 2 * t) + 2 := by omega
            rw [this, pow_add]
            ring
          rw [hPowStep]
          have h49 : 2 * ((7 / 4 : ℝ) ^ 2 * ((2 : ℝ) ^ (8 * E + 2 * t)) ^ 2) +
              ((2 : ℝ) ^ (8 * E + 2 * t)) ^ 2 ≤ 16 * ((2 : ℝ) ^ (8 * E + 2 * t)) ^ 2 := by
            have hpos : (0 : ℝ) ≤ ((2 : ℝ) ^ (8 * E + 2 * t)) ^ 2 := by positivity
            linarith
          linarith [hSumA', mul_le_mul_of_nonneg_left hFrobB' (by norm_num : (0 : ℝ) ≤ 2), h2N2_le]
        · -- Bound (st.C i - (K * H i) / denC).natAbs ≤ (t + 1) * 2^(9*E + 2*(t+1))
          intro i
          have hw_i : ∀ k : Fin N, |w k| ≤ 1 := by
            intro k
            have hsq : (w k) ^ 2 ≤ 1 ^ 2 := by
              have hle := Finset.single_le_sum (f := fun j : Fin N => (w j) ^ 2)
                (fun _ _ => sq_nonneg _) (Finset.mem_univ k)
              linarith
            simpa using sq_le_sq.mp hsq
          have hQuotReal : |((K * H i : ℤ) : ℝ) / (denC : ℝ)| ≤ (N : ℝ) * ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ) := by
            have hEqW : ((K * H i : ℤ) : ℝ) / (denC : ℝ) =
                (1 / ((N : ℝ) + 1)) * ∑ k : Fin N, (st.A i k : ℝ) * w k := by
              have hLcR_ne : (L_ceil : ℝ) ≠ 0 := by
                have : (0 : ℝ) < (L_ceil : ℝ) := by exact_mod_cast (by omega : 0 < L_ceil)
                exact this.ne'
              have hd1 : (N : ℝ) + 1 ≠ 0 := by positivity
              dsimp [H, denC, w]
              push_cast
              rw [Finset.mul_sum, Finset.sum_div]
              rw [Finset.mul_sum]
              refine Finset.sum_congr rfl (fun k _ => ?_)
              dsimp only [K]; field_simp [hd1, hLcR_ne]; try ring
            rw [hEqW, abs_mul]
            have h1N : |1 / ((N : ℝ) + 1)| ≤ 1 := by
              rw [abs_of_pos (by positivity), div_le_one (by positivity)]
              have : (2 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
              linarith
            have hSumW : |∑ k : Fin N, (st.A i k : ℝ) * w k| ≤ (N : ℝ) * ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ) := by
              calc |∑ k : Fin N, (st.A i k : ℝ) * w k|
                  ≤ ∑ k : Fin N, |(st.A i k : ℝ) * w k| := Finset.abs_sum_le_sum_abs _ _
                _ ≤ ∑ _k : Fin N, ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ) * 1 := by
                    refine Finset.sum_le_sum (fun k _ => ?_)
                    rw [abs_mul, real_abs_int_eq_natAbs]
                    exact mul_le_mul (by exact_mod_cast ellMagInv_entry_abs hMag i k) (hw_i k)
                      (abs_nonneg _) (by positivity)
                _ = (N : ℝ) * ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ) := by simp
            calc |1 / ((N : ℝ) + 1)| * |∑ k : Fin N, (st.A i k : ℝ) * w k|
                ≤ 1 * ((N : ℝ) * ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ)) :=
                  mul_le_mul h1N hSumW (abs_nonneg _) zero_le_one
              _ = (N : ℝ) * ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ) := one_mul _
          have hStepAbs : (((K * H i) / denC : ℤ)).natAbs ≤ N * 2 ^ (8 * E + 2 * t) + 1 := by
            have herr := ediv_approx_abs_le_one (K * H i) denC hdenC_pos
            have htri : |(((K * H i) / denC : ℤ) : ℝ)| ≤
                |((K * H i : ℤ) : ℝ) / (denC : ℝ)| + 1 := by
              have h1 := abs_sub_abs_le_abs_sub (((K * H i) / denC : ℤ) : ℝ)
                (((K * H i : ℤ) : ℝ) / (denC : ℝ))
              rw [abs_sub_comm] at herr
              linarith
            rw [real_abs_int_eq_natAbs] at htri
            have hR0 : ((((K * H i) / denC).natAbs : ℕ) : ℝ) ≤
                (N : ℝ) * ((2 ^ (8 * E + 2 * t) : ℕ) : ℝ) + 1 := by
              linarith [htri, hQuotReal]
            have hR : ((((K * H i) / denC).natAbs : ℕ) : ℝ) ≤
                ((N * 2 ^ (8 * E + 2 * t) + 1 : ℕ) : ℝ) := by
              simpa only [Nat.cast_add, Nat.cast_mul, Nat.cast_one] using hR0
            exact_mod_cast hR
          have hStepPow : N * 2 ^ (8 * E + 2 * t) + 1 ≤ 2 ^ (9 * E + 2 * t) := by
            have hN1 : N + 1 ≤ 2 ^ E := by
              have h1 : N < 2 ^ N := Nat.lt_two_pow_self
              have h2 : N ≤ E := by dsimp [E, ellParamE]; nlinarith
              exact (Nat.succ_le_of_lt h1).trans (Nat.pow_le_pow_right (by omega) h2)
            calc N * 2 ^ (8 * E + 2 * t) + 1
                ≤ N * 2 ^ (8 * E + 2 * t) + 2 ^ (8 * E + 2 * t) :=
                  Nat.add_le_add_left Nat.one_le_two_pow _
              _ = (N + 1) * 2 ^ (8 * E + 2 * t) := by ring
              _ ≤ 2 ^ E * 2 ^ (8 * E + 2 * t) := Nat.mul_le_mul_right _ hN1
              _ = 2 ^ (9 * E + 2 * t) := by rw [← pow_add]; ring_nf
          have hSubAbs : (st.C i - (K * H i) / denC).natAbs ≤
              (st.C i).natAbs + ((K * H i) / denC).natAbs := by
            simpa using Int.natAbs_sub_le (st.C i) ((K * H i) / denC)
          calc (st.C i - (K * H i) / denC).natAbs
              ≤ t * 2 ^ (9 * E + 2 * t) + 2 ^ (9 * E + 2 * t) :=
                hSubAbs.trans (Nat.add_le_add (hMag.2 i) (hStepAbs.trans hStepPow))
            _ = (t + 1) * 2 ^ (9 * E + 2 * t) := by ring
            _ ≤ (t + 1) * 2 ^ (9 * E + 2 * (t + 1)) :=
                Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) (by omega))
    · rw [dif_neg hviol]
      exact hStepMono ⟨hMag.1, hMag.2⟩

theorem ellRun_magInv {n m L : ℕ} (hL : 1 ≤ L)
    (M : Fin m → Fin n → ℤ) (d : Fin m → ℤ)
    (hM : ∀ (i : Fin m) (j : Fin n), (M i j).natAbs ≤ 2 ^ L) :
    ∀ t : ℕ, t ≤ ellParamT (n + 2) L →
      EllMagInv (ellParamE (n + 2) L) t
        (Fin.foldl t (fun st _ => ellStep L (padCols M) d st) (ellInit (n + 2) L)) := by
  have hM_pad : ∀ (i : Fin m) (j : Fin (n + 2)), (padCols M i j).natAbs ≤ 2 ^ L := by
    intro i j
    dsimp [padCols]
    split_ifs with hj
    · exact hM i ⟨j.val, hj⟩
    · simp
  intro t
  induction t with
  | zero =>
      intro _
      simpa [Fin.foldl_zero] using ellMagInv_init (by omega) hL
  | succ t ih =>
      intro ht
      rw [Fin.foldl_succ_last]
      exact ellMagInv_step (by omega) hL (Nat.lt_of_succ_le ht) (padCols M) d hM_pad
        (ih (Nat.le_of_succ_le ht))

/-! ### 4. Exact Decision Correctness Theorem `ellipsoidDecide_iff` -/

theorem padCols_sum_eq {n m : ℕ} (M : Fin m → Fin n → ℤ) (i : Fin m)
    (y : Fin (n + 2) → ℝ) :
    ∑ j : Fin (n + 2), (padCols M i j : ℝ) * y j =
      ∑ j : Fin n, (M i j : ℝ) * y (Fin.castAdd 2 j) := by
  rw [Fin.sum_univ_add]
  have h1 : ∑ j : Fin n, (padCols M i (Fin.castAdd 2 j) : ℝ) * y (Fin.castAdd 2 j) =
      ∑ j : Fin n, (M i j : ℝ) * y (Fin.castAdd 2 j) := by
    refine Finset.sum_congr rfl (fun j _ => ?_)
    have hj : (Fin.castAdd 2 j).val < n := j.isLt
    simp [padCols]
  have h2 : ∑ j : Fin 2, (padCols M i (Fin.natAdd n j) : ℝ) * y (Fin.natAdd n j) = 0 := by
    refine Finset.sum_eq_zero (fun j _ => ?_)
    have hj : ¬ (Fin.natAdd n j).val < n := by simp
    simp [padCols]
  rw [h1, h2, add_zero]

theorem ellipsoidDecide_iff {n m L : ℕ} (hL : 1 ≤ L)
    (M : Fin m → Fin n → ℤ) (d : Fin m → ℤ)
    (hM : ∀ (i : Fin m) (j : Fin n), (M i j).natAbs ≤ 2 ^ L)
    (hd : ∀ i : Fin m, (d i).natAbs ≤ 2 ^ L) :
    ellipsoidDecide n m L M d = true ↔
      ∃ x : Fin n → ℝ, ∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * x j ≤ (d i : ℝ) := by
  let N := n + 2
  have hN : 2 ≤ N := by omega
  have hNR : (2 : ℝ) ≤ (N : ℝ) := by exact_mod_cast hN
  let E := ellParamE N L
  let T := ellParamT N L
  let Q : ℤ := (2 : ℤ) ^ (E + 1)
  let P : ℤ := (2 : ℤ) ^ (6 * E)
  let r : ℝ := (2 : ℝ) ^ (-(2 * E : ℤ))
  let R_init : ℝ := (2 : ℝ) ^ E
  let M_pad := padCols M
  have hM_pad : ∀ (i : Fin m) (j : Fin N), (M_pad i j).natAbs ≤ 2 ^ L := by
    intro i j; dsimp [M_pad, padCols]; split_ifs with hj; exact hM i ⟨j.val, hj⟩; simp
  have hPadEquiv : (∃ x : Fin n → ℝ, ∀ i : Fin m, ∑ j : Fin n, (M i j : ℝ) * x j ≤ (d i : ℝ)) ↔
      (∃ y : Fin N → ℝ, ∀ i : Fin m, ∑ j : Fin N, (M_pad i j : ℝ) * y j ≤ (d i : ℝ)) := by
    constructor
    · rintro ⟨x, hx⟩
      refine ⟨fun j => if hj : j.val < n then x ⟨j.val, hj⟩ else 0, fun i => ?_⟩
      rw [padCols_sum_eq]
      have hEq : (∑ j : Fin n, (M i j : ℝ) *
          (if hj : (Fin.castAdd 2 j).val < n then x ⟨(Fin.castAdd 2 j).val, hj⟩ else 0)) =
          ∑ j : Fin n, (M i j : ℝ) * x j := by
        refine Finset.sum_congr rfl (fun j _ => ?_)
        simp [j.isLt]
      rw [hEq]
      exact hx i
    · rintro ⟨y, hy⟩
      refine ⟨fun j => y (Fin.castAdd 2 j), fun i => ?_⟩
      rw [← padCols_sum_eq]
      exact hy i
  obtain ⟨hPertEquiv, hPertBallEx⟩ := int_lp_perturbation_ball hN hL M_pad d hM_pad hd
  let runAt : ℕ → EllState N :=
    fun t => Fin.foldl t (fun st _ => ellStep L M_pad d st) (ellInit N L)
  have hP_pos : (0 : ℝ) < (P : ℝ) := by dsimp [P]; positivity
  have hQ_pos : (0 : ℝ) < (Q : ℝ) := by dsimp [Q]; positivity
  constructor
  · -- Soundness: status == 1 implies feasible
    intro hDec
    have hStatus1 : (runAt T).status = 1 := by
      unfold ellipsoidDecide ellRun at hDec
      exact beq_iff_eq.mp hDec
    have hSound : ∀ t : ℕ, (runAt t).status = 1 →
        ∃ C : Fin N → ℤ, ∀ i : Fin m, Q * (∑ j : Fin N, M_pad i j * C j) ≤ P * (Q * d i + 1) := by
      intro t
      induction t with
      | zero =>
          intro h0
          simp [runAt, Fin.foldl_zero, ellInit] at h0
      | succ t ih =>
          intro ht1
          have hstep_eq : runAt (t + 1) = ellStep L M_pad d (runAt t) := by
            dsimp [runAt]; rw [Fin.foldl_succ_last]
          rw [hstep_eq] at ht1
          unfold ellStep at ht1
          by_cases hnz : ((runAt t).status != 0) = true
          · rw [if_pos hnz] at ht1
            exact ih ht1
          · rw [if_neg hnz] at ht1
            dsimp only at ht1
            by_cases hviol : 0 ≤ findViolatedRow P Q M_pad d (runAt t).C ∧
                (findViolatedRow P Q M_pad d (runAt t).C).toNat < m
            · dsimp only [P, Q, E] at hviol
              rw [dif_pos hviol] at ht1
              split_ifs at ht1 <;> norm_num at ht1
            · rcases findViolatedRow_spec P Q M_pad d (runAt t).C with ⟨_, hAllLe⟩ | ⟨i₀, hEq, _⟩
              · exact ⟨(runAt t).C, hAllLe⟩
              · exfalso
                apply hviol
                rw [hEq]
                exact ⟨Nat.cast_nonneg _, by simp [i₀.isLt]⟩
    obtain ⟨C, hC_le⟩ := hSound T hStatus1
    refine hPadEquiv.mpr (hPertEquiv.mpr ⟨fun j => (C j : ℝ) / (P : ℝ), fun i => ?_⟩)
    have hiR : (Q : ℝ) * (∑ j : Fin N, (M_pad i j : ℝ) * (C j : ℝ)) ≤
        (P : ℝ) * ((Q : ℝ) * (d i : ℝ) + 1) := by
      exact_mod_cast hC_le i
    have hPQ_pos : 0 < (P : ℝ) * (Q : ℝ) := mul_pos hP_pos hQ_pos
    apply le_of_mul_le_mul_left _ hPQ_pos
    have hLHS : ((P : ℝ) * (Q : ℝ)) * (∑ j : Fin N, (M_pad i j : ℝ) * ((C j : ℝ) / (P : ℝ))) =
        (Q : ℝ) * (∑ j : Fin N, (M_pad i j : ℝ) * (C j : ℝ)) := by
      rw [Finset.mul_sum, Finset.mul_sum]
      refine Finset.sum_congr rfl (fun j _ => ?_)
      field_simp [hP_pos.ne']
    have hQ_cast : ((2 ^ ((N + 2) * (N + 2 + L) + 1) : ℕ) : ℝ) = (Q : ℝ) := by dsimp [Q, E, ellParamE]; norm_cast
    rw [hQ_cast, hLHS]
    have hRHS : ((P : ℝ) * (Q : ℝ)) * ((d i : ℝ) + 1 / (Q : ℝ)) =
        (P : ℝ) * ((Q : ℝ) * (d i : ℝ) + 1) := by
      field_simp [hQ_pos.ne']
    rw [hRHS]
    exact hiR
  · -- Completeness: feasible implies status == 1 within T steps
    intro hFeas
    obtain ⟨x_star, hInitBall, hPertBall⟩ := hPertBallEx (hPadEquiv.mp hFeas)
    have hQ_cast : ((2 ^ ((N + 2) * (N + 2 + L) + 1) : ℕ) : ℝ) = (Q : ℝ) := by dsimp [Q, E, ellParamE]; norm_cast
    rw [hQ_cast] at hPertBall
    have hr_pos : 0 < r := by dsimp [r]; positivity
    let cOf : EllState N → Fin N → ℝ := fun st i => (st.C i : ℝ) / (P : ℝ)
    let BOf : EllState N → Matrix (Fin N) (Fin N) ℝ := fun st i j => (st.A i j : ℝ) / (P : ℝ)
    -- Prove main ball + determinant contraction invariant up to T
    have hFeasInv : ∀ t : ℕ, t ≤ T →
        (runAt t).status = 1 ∨
        ((runAt t).status = 0 ∧
          (∀ x : Fin N → ℝ, (∑ j : Fin N, (x j - x_star j) ^ 2 ≤ r ^ 2) →
            ∃ u : Fin N → ℝ, (∑ j : Fin N, (u j) ^ 2 ≤ 1) ∧ x = cOf (runAt t) + (BOf (runAt t)).mulVec u) ∧
          |(BOf (runAt t)).det| ≤ Real.exp (- (t : ℝ) / (10 * ((N : ℝ) + 1))) * R_init ^ N) := by
      intro t
      induction t with
      | zero =>
          intro _
          right
          have hst0 : runAt 0 = ellInit N L := by simp [runAt, Fin.foldl_zero]
          rw [hst0]
          have hB0_eq : BOf (ellInit N L) = R_init • (1 : Matrix (Fin N) (Fin N) ℝ) := by
            ext i j
            dsimp [BOf, ellInit, P, R_init]
            by_cases hij : i = j
            · subst hij
              simp only [↓reduceIte, Matrix.smul_apply, Matrix.one_apply_eq, smul_eq_mul, mul_one]
              push_cast
              have h7 : 7 * E = E + 6 * E := by omega
              rw [h7, pow_add]
              field_simp [hP_pos.ne']
            · simp [hij, Matrix.one_apply_ne hij]
          have hc0_eq : cOf (ellInit N L) = 0 := by ext i; simp [cOf, ellInit]
          refine ⟨rfl, ?_, ?_⟩
          · intro x hx
            have hR_pos : 0 < R_init := by dsimp [R_init]; positivity
            refine ⟨fun j => x j / R_init, ?_, ?_⟩
            · have h1 : ∑ j : Fin N, (x j / R_init) ^ 2 = (∑ j : Fin N, (x j) ^ 2) / R_init ^ 2 := by
                simp_rw [div_pow]
                rw [← Finset.sum_div]
              rw [h1, div_le_one (sq_pos_of_pos hR_pos)]
              exact hInitBall x hx
            · rw [hc0_eq, hB0_eq, zero_add, Matrix.smul_mulVec, Matrix.one_mulVec]
              ext j
              simp [Pi.smul_apply, smul_eq_mul, mul_div_cancel₀ _ hR_pos.ne']
          · rw [hB0_eq, Matrix.det_smul, Fintype.card_fin, Matrix.det_one, mul_one,
              abs_of_pos (by dsimp [R_init]; positivity)]
            simp
      | succ t ih =>
          intro ht1
          have ht_lt : t < T := Nat.lt_of_succ_le ht1
          have hstep_eq : runAt (t + 1) = ellStep L M_pad d (runAt t) := by
            dsimp [runAt]; rw [Fin.foldl_succ_last]
          rcases ih ht_lt.le with hAlready1 | ⟨hst0, hBall, hDet⟩
          · left
            rw [hstep_eq]
            unfold ellStep
            have hnz : ((runAt t).status != 0) = true := by rw [hAlready1]; rfl
            rw [if_pos hnz]
            exact hAlready1
          · rw [hstep_eq]
            have hMag : EllMagInv E t (runAt t) := ellRun_magInv hL M d hM t ht_lt.le
            generalize hst_def : runAt t = st at hst0 hBall hDet hMag ⊢
            have hnz_false : ¬ ((st.status != 0) = true) := by rw [hst0]; decide
            by_cases hviol : 0 ≤ findViolatedRow P Q M_pad d st.C ∧
                (findViolatedRow P Q M_pad d st.C).toNat < m
            · right
              -- Extract violated constraint i₀
              rcases findViolatedRow_spec P Q M_pad d st.C with ⟨hNeg1, _⟩ | ⟨i_v, hEqV, hGtV⟩
              · exfalso; dsimp [P, Q, E] at hviol; rw [hNeg1] at hviol; omega
              have hi0_eq : (⟨(findViolatedRow P Q M_pad d st.C).toNat, hviol.2⟩ : Fin m) = i_v := by
                ext; dsimp only; dsimp [P, Q, E] at hEqV ⊢; rw [hEqV]; exact Int.toNat_natCast _
              let i₀ : Fin m := ⟨(findViolatedRow P Q M_pad d st.C).toNat, hviol.2⟩
              have hViolReal : (d i₀ : ℝ) + 1 / (Q : ℝ) < ∑ k : Fin N, (M_pad i₀ k : ℝ) * cOf st k := by
                have hGt0 : P * (Q * d i₀ + 1) < Q * (∑ k : Fin N, M_pad i₀ k * st.C k) := by
                  simpa [i₀, hi0_eq] using hGtV
                have hGtR : (P : ℝ) * ((Q : ℝ) * (d i₀ : ℝ) + 1) <
                    (Q : ℝ) * (∑ k : Fin N, (M_pad i₀ k : ℝ) * (st.C k : ℝ)) := by
                  exact_mod_cast hGt0
                have hPQ_pos : 0 < (P : ℝ) * (Q : ℝ) := mul_pos hP_pos hQ_pos
                apply lt_of_mul_lt_mul_left _ hPQ_pos.le
                have hL1 : ((P : ℝ) * (Q : ℝ)) * ((d i₀ : ℝ) + 1 / (Q : ℝ)) =
                    (P : ℝ) * ((Q : ℝ) * (d i₀ : ℝ) + 1) := by field_simp [hQ_pos.ne']
                have hR1 : ((P : ℝ) * (Q : ℝ)) * (∑ k : Fin N, (M_pad i₀ k : ℝ) * cOf st k) =
                    (Q : ℝ) * (∑ k : Fin N, (M_pad i₀ k : ℝ) * (st.C k : ℝ)) := by
                  dsimp [cOf]
                  rw [Finset.mul_sum, Finset.mul_sum]
                  refine Finset.sum_congr rfl (fun k _ => ?_)
                  field_simp [hP_pos.ne']
                linarith
              let G : Fin N → ℤ := fun j => ∑ k : Fin N, M_pad i₀ k * st.A k j
              let S_norm : ℤ := ∑ j : Fin N, G j * G j
              -- For any x ∈ B_2(x*, r) with x = c_t + B_t u, we have ∑ j, (G j / P) * u j < 0!
              have hCutNeg : ∀ (x u : Fin N → ℝ),
                  (∑ j : Fin N, (x j - x_star j) ^ 2 ≤ r ^ 2) →
                  x = cOf st + (BOf st).mulVec u →
                  ∑ j : Fin N, ((G j : ℝ) / (P : ℝ)) * u j < 0 := by
                intro x u hx hxu
                have hx_le := hPertBall x hx i₀
                have hDiff : ∑ k : Fin N, (M_pad i₀ k : ℝ) * (x k - cOf st k) < 0 := by
                  have hsp : ∑ k : Fin N, (M_pad i₀ k : ℝ) * (x k - cOf st k) =
                      (∑ k : Fin N, (M_pad i₀ k : ℝ) * x k) -
                        (∑ k : Fin N, (M_pad i₀ k : ℝ) * cOf st k) := by
                    simp_rw [mul_sub, Finset.sum_sub_distrib]
                  linarith
                have hEqG : ∑ k : Fin N, (M_pad i₀ k : ℝ) * (x k - cOf st k) =
                    ∑ j : Fin N, ((G j : ℝ) / (P : ℝ)) * u j := by
                  have hsub : ∀ k : Fin N, x k - cOf st k = ((BOf st).mulVec u) k := by
                    intro k; have hk := congr_fun hxu k; simp only [Pi.add_apply] at hk; linarith
                  simp_rw [hsub, Matrix.mulVec, dotProduct, BOf, Finset.mul_sum]
                  rw [Finset.sum_comm]
                  refine Finset.sum_congr rfl (fun j _ => ?_)
                  dsimp [G]
                  push_cast
                  rw [Finset.sum_div, Finset.sum_mul]
                  exact Finset.sum_congr rfl (fun k _ => by ring)
                linarith
              -- Deduce S_norm ≥ 1 (so ¬ S_norm ≤ 0)!
              have hS_pos : 1 ≤ S_norm := by
                obtain ⟨u_s, _, hu_s_eq⟩ := hBall x_star (by simp [hr_pos.le])
                have hLt0 := hCutNeg x_star u_s (by simp [hr_pos.le]) hu_s_eq
                have hS_nn : 0 ≤ S_norm := Finset.sum_nonneg (fun j _ => mul_self_nonneg (G j))
                by_contra hLe0
                have hS0 : S_norm = 0 := by omega
                have hG0 : ∀ j : Fin N, G j = 0 := by
                  intro j
                  have hle : G j * G j ≤ S_norm :=
                    Finset.single_le_sum (f := fun k : Fin N => G k * G k)
                      (fun k _ => mul_self_nonneg (G k)) (Finset.mem_univ j)
                  have hsq0 : G j * G j ≤ 0 := by linarith
                  have hsq_eq : G j * G j = 0 := le_antisymm hsq0 (mul_self_nonneg (G j))
                  exact mul_self_eq_zero.mp hsq_eq
                have hSum0 : ∑ j : Fin N, ((G j : ℝ) / (P : ℝ)) * u_s j = 0 := by
                  refine Finset.sum_eq_zero (fun j _ => ?_)
                  simp [hG0 j]
                linarith
              have hNotS0 : ¬ S_norm ≤ 0 := by omega
              -- Apply isqrtCeil_spec and exact_half_ball_step + rounded_ellipsoid_step!
              let K : ℤ := 16 * (N : ℤ) * (N : ℤ)
              have hK_pos : 0 < K := by
                dsimp [K]
                have hNZ : (2 : ℤ) ≤ (N : ℤ) := by omega
                nlinarith only [hNZ]
              have hKKS_lo : 1 ≤ K * K * S_norm := by
                have hKK1 : 1 ≤ K * K := by nlinarith only [hK_pos]
                nlinarith only [hKK1, hS_pos]
              have hKKS_hi := ellStep_isqrt_range hN hL ht_lt.le M_pad hM_pad hMag i₀
              obtain ⟨hLc_lo, _, hLc_lt, hLc_sq⟩ :=
                isqrtCeil_spec (ellParamBsqrt N L) (K * K * S_norm) hKKS_lo hKKS_hi
              generalize hLc_def : isqrtCeil (ellParamBsqrt N L) (K * K * S_norm) = L_ceil at hLc_lo hLc_lt hLc_sq
              have hLcR_pos : (0 : ℝ) < (L_ceil : ℝ) := by exact_mod_cast (by omega : 0 < L_ceil)
              let g_norm : ℝ := Real.sqrt (S_norm : ℝ)
              have hSR_pos : (1 : ℝ) ≤ (S_norm : ℝ) := by exact_mod_cast hS_pos
              have hgn_ge1 : 1 ≤ g_norm := by
                dsimp [g_norm]
                rw [← Real.sqrt_one]
                exact Real.sqrt_le_sqrt hSR_pos
              have hgn_pos : 0 < g_norm := by linarith
              let g_hat : Fin N → ℝ := fun j => (G j : ℝ) / g_norm
              have hg_sq : ∑ j : Fin N, (g_hat j) ^ 2 = 1 := by
                have h1 : ∑ j : Fin N, ((G j : ℝ) / g_norm) ^ 2 =
                    (∑ j : Fin N, (G j : ℝ) ^ 2) / g_norm ^ 2 := by
                  simp_rw [div_pow]; rw [← Finset.sum_div]
                dsimp [g_hat]
                rw [h1, Real.sq_sqrt (by positivity)]
                have hsumG : ∑ j : Fin N, (G j : ℝ) ^ 2 = (S_norm : ℝ) := by
                  dsimp [S_norm]; push_cast
                  exact Finset.sum_congr rfl (fun _ _ => sq _)
                rw [hsumG, div_self (by linarith)]
              let ρ : ℝ := ((K : ℝ) * g_norm) / (L_ceil : ℝ)
              have hKgn_le_Lc : (K : ℝ) * g_norm ≤ (L_ceil : ℝ) := by
                have hsqR : ((K : ℝ) * g_norm) ^ 2 ≤ (L_ceil : ℝ) ^ 2 := by
                  rw [mul_pow, Real.sq_sqrt (by positivity)]
                  have hInt : ((K * K * S_norm : ℤ) : ℝ) ≤ ((L_ceil ^ 2 : ℤ) : ℝ) := by
                    exact_mod_cast hLc_sq
                  push_cast at hInt
                  linarith
                have hnn : 0 ≤ (K : ℝ) * g_norm := by
                  have : (0 : ℝ) < (K : ℝ) := by exact_mod_cast hK_pos
                  positivity
                nlinarith only [hsqR, hnn, hLcR_pos]
              have hLc_sub1_lt : (L_ceil : ℝ) - 1 < (K : ℝ) * g_norm := by
                have hsqR : ((L_ceil : ℝ) - 1) ^ 2 < ((K : ℝ) * g_norm) ^ 2 := by
                  rw [mul_pow, Real.sq_sqrt (by positivity)]
                  have hInt : (((L_ceil - 1) ^ 2 : ℤ) : ℝ) < ((K * K * S_norm : ℤ) : ℝ) := by
                    exact_mod_cast hLc_lt
                  push_cast at hInt
                  linarith
                have hnn : 0 ≤ (K : ℝ) * g_norm := by
                  have : (0 : ℝ) < (K : ℝ) := by exact_mod_cast hK_pos
                  positivity
                nlinarith only [hsqR, hnn, hLcR_pos]
              have hρ_hi : ρ ≤ 1 := (div_le_one hLcR_pos).mpr hKgn_le_Lc
              have hρ_lo : 1 - 1 / (16 * (N : ℝ) ^ 2) ≤ ρ := by
                have hKR : (K : ℝ) = 16 * (N : ℝ) ^ 2 := by dsimp [K]; push_cast; ring
                have hLc_ge_K : 16 * (N : ℝ) ^ 2 ≤ (L_ceil : ℝ) := by
                  have : 16 * (N : ℝ) ^ 2 * 1 ≤ (K : ℝ) * g_norm := by
                    rw [hKR]; exact mul_le_mul_of_nonneg_left hgn_ge1 (by positivity)
                  linarith
                have h1 : 1 - ρ = ((L_ceil : ℝ) - (K : ℝ) * g_norm) / (L_ceil : ℝ) := by
                  dsimp [ρ]; field_simp [hLcR_pos.ne']
                have h2 : ((L_ceil : ℝ) - (K : ℝ) * g_norm) / (L_ceil : ℝ) ≤ 1 / (L_ceil : ℝ) :=
                  div_le_div_of_nonneg_right (by linarith) hLcR_pos.le
                have h3 : 1 / (L_ceil : ℝ) ≤ 1 / (16 * (N : ℝ) ^ 2) :=
                  one_div_le_one_div_of_le (by positivity) hLc_ge_K
                linarith
              obtain ⟨hHalfBall, hDetStep⟩ := exact_half_ball_step hN g_hat hg_sq ρ hρ_lo hρ_hi
              let w : Fin N → ℝ := fun j => ((K : ℝ) * (G j : ℝ)) / (L_ceil : ℝ)
              have hw_eq : w = (fun j => ρ * g_hat j) := by
                ext j
                dsimp [w, ρ, g_hat]
                field_simp [hLcR_pos.ne', hgn_pos.ne']
              let c' : Fin N → ℝ := fun i => cOf st i - (1 / ((N : ℝ) + 1)) * ((BOf st).mulVec w) i
              let B' : Matrix (Fin N) (Fin N) ℝ := BOf st * ellStepMat N w
              obtain ⟨hdenC_pos, hdenA_pos, hc_form, hB_form⟩ :=
                ellStep_exact_formulas hN st.C st.A G L_ceil hLc_lo (P : ℝ) hP_pos
              -- Verify B_2(x*, r) maps into c' + B' * {‖u'‖ ≤ 1 / ellInfl N}
              have hBall' : ∀ x : Fin N → ℝ, (∑ j : Fin N, (x j - x_star j) ^ 2 ≤ r ^ 2) →
                  ∃ v : Fin N → ℝ, (∑ j : Fin N, (v j) ^ 2 ≤ (1 / ellInfl N) ^ 2) ∧
                    x = c' + B'.mulVec v := by
                intro x hx
                obtain ⟨u, hu_sq, hxu⟩ := hBall x hx
                have hCutG := hCutNeg x u hx hxu
                have hCutHat : ∑ j : Fin N, g_hat j * u j ≤ 0 := by
                  have hRel : ∑ j : Fin N, ((G j : ℝ) / (P : ℝ)) * u j =
                      (g_norm / (P : ℝ)) * ∑ j : Fin N, g_hat j * u j := by
                    dsimp [g_hat]
                    rw [Finset.mul_sum]
                    refine Finset.sum_congr rfl (fun j _ => ?_)
                    field_simp [hP_pos.ne', hgn_pos.ne']
                  rw [hRel] at hCutG
                  have hpos : 0 < g_norm / (P : ℝ) := div_pos hgn_pos hP_pos
                  nlinarith only [hCutG, hpos]
                obtain ⟨u', hu'_eq, hu'_sq⟩ := hHalfBall u hu_sq hCutHat
                rw [← hw_eq] at hu'_eq
                refine ⟨u', hu'_sq, ?_⟩
                rw [hxu]
                dsimp only [B']
                rw [← Matrix.mulVec_mulVec, hu'_eq]
                have hAdd : (BOf st).mulVec (fun j => u j + 1 / ((N : ℝ) + 1) * w j) =
                    (BOf st).mulVec u + (1 / ((N : ℝ) + 1)) • (BOf st).mulVec w := by
                  have hfn : (fun j => u j + 1 / ((N : ℝ) + 1) * w j) =
                      u + (1 / ((N : ℝ) + 1)) • w := rfl
                  rw [hfn, Matrix.mulVec_add, Matrix.mulVec_smul]
                rw [hAdd]
                ext i
                simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, c']
                ring
              -- Rounding errors bounded by ε = 1 / P
              let st_next := ellStep L M_pad d st
              have hst_next_def : st_next =
                  { status := 0
                    C := fun i => st.C i - (K * (∑ k : Fin N, st.A i k * G k)) / (((N : ℤ) + 1) * L_ceil)
                    A := fun i j =>
                      ((8 * (N : ℤ) * (N : ℤ) + 1) *
                        ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * st.A i j -
                          (2 * (N : ℤ) - 1) * (K * K) * (∑ k : Fin N, st.A i k * G k) * G j)) /
                        (8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) * L_ceil * L_ceil) } := by
                dsimp only [st_next, ellStep]
                rw [if_neg hnz_false]
                dsimp only [P, Q, E] at hviol
                rw [dif_pos hviol, if_neg hNotS0]
                exact congrArg (fun lc =>
                  ({ status := 0
                     C := fun i => st.C i - (K * (∑ k : Fin N, st.A i k * G k)) / (((N : ℤ) + 1) * lc)
                     A := fun i j =>
                       ((8 * (N : ℤ) * (N : ℤ) + 1) *
                         ((2 * (N : ℤ) * (N : ℤ) - 1) * (lc * lc) * st.A i j -
                           (2 * (N : ℤ) - 1) * (K * K) * (∑ k : Fin N, st.A i k * G k) * G j)) /
                         (8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) * lc * lc) } : EllState N)) hLc_def
              let ε : ℝ := 1 / (P : ℝ)
              have hc_err : ∀ i : Fin N, |cOf st_next i - c' i| ≤ ε := by
                intro i
                rw [hst_next_def]
                dsimp only [cOf, ε]
                let numC : ℤ := K * (∑ k : Fin N, st.A i k * G k)
                let denC : ℤ := ((N : ℤ) + 1) * L_ceil
                have h1 : (P : ℝ) * c' i = (st.C i : ℝ) - (numC : ℝ) / (denC : ℝ) := hc_form i
                have herr := ediv_approx_abs_le_one numC denC hdenC_pos
                have hDiff : ((st.C i - numC / denC : ℤ) : ℝ) / (P : ℝ) - c' i =
                    ((numC : ℝ) / (denC : ℝ) - ((numC / denC : ℤ) : ℝ)) / (P : ℝ) := by
                  have hsub : ((st.C i - numC / denC : ℤ) : ℝ) / (P : ℝ) - c' i =
                      (((st.C i - numC / denC : ℤ) : ℝ) - (P : ℝ) * c' i) / (P : ℝ) := by
                    rw [sub_div, mul_div_cancel_left₀ _ hP_pos.ne']
                  rw [hsub, h1, Int.cast_sub]
                  ring
                change |((st.C i - numC / denC : ℤ) : ℝ) / (P : ℝ) - c' i| ≤ 1 / (P : ℝ)
                rw [hDiff, abs_div, abs_of_pos hP_pos]
                exact div_le_div_of_nonneg_right herr hP_pos.le
              have hB_err : ∀ i j : Fin N, |BOf st_next i j - B' i j| ≤ ε := by
                intro i j
                rw [hst_next_def]
                dsimp only [BOf, Matrix.of_apply, ε]
                let numIJ : ℤ := (8 * (N : ℤ) * (N : ℤ) + 1) *
                  ((2 * (N : ℤ) * (N : ℤ) - 1) * (L_ceil * L_ceil) * st.A i j -
                    (2 * (N : ℤ) - 1) * (K * K) * (∑ k : Fin N, st.A i k * G k) * G j)
                let denA : ℤ := 8 * (N : ℤ) * (N : ℤ) * (2 * (N : ℤ) * (N : ℤ) - 2) * L_ceil * L_ceil
                have h1 : (P : ℝ) * B' i j = (numIJ : ℝ) / (denA : ℝ) := hB_form i j
                have herr := ediv_approx_abs_le_one numIJ denA hdenA_pos
                have hDiff : ((numIJ / denA : ℤ) : ℝ) / (P : ℝ) - B' i j =
                    - (((numIJ : ℝ) / (denA : ℝ) - ((numIJ / denA : ℤ) : ℝ)) / (P : ℝ)) := by
                  have hsub : ((numIJ / denA : ℤ) : ℝ) / (P : ℝ) - B' i j =
                      (((numIJ / denA : ℤ) : ℝ) - (P : ℝ) * B' i j) / (P : ℝ) := by
                    rw [sub_div, mul_div_cancel_left₀ _ hP_pos.ne']
                  rw [hsub, h1]
                  ring
                change |((numIJ / denA : ℤ) : ℝ) / (P : ℝ) - B' i j| ≤ 1 / (P : ℝ)
                rw [hDiff, abs_neg, abs_div, abs_of_pos hP_pos]
                exact div_le_div_of_nonneg_right herr hP_pos.le
              have hε_small : ε * (128 * (N : ℝ) ^ 4 * (N.factorial : ℝ) * (2 : ℝ) ^ N) ≤ r := by
                have hNat : 128 * N ^ 4 * N.factorial * 2 ^ N ≤ 2 ^ (4 * E) := by
                  have h1 : N ≤ 2 ^ N := Nat.lt_two_pow_self.le
                  have h2 : N.factorial ≤ N ^ N := Nat.factorial_le_pow N
                  have hN4 : N ^ 4 ≤ (2 ^ N) ^ 4 := Nat.pow_le_pow_left h1 4
                  have hNN : N ^ N ≤ (2 ^ N) ^ N := Nat.pow_le_pow_left h1 N
                  have hexp : 7 + 4 * N + N * N + N ≤ 4 * E := by
                    dsimp [E, ellParamE]
                    have hNL0 : 0 ≤ N * L := Nat.zero_le _
                    nlinarith only [hN, hNL0]
                  calc 128 * N ^ 4 * N.factorial * 2 ^ N
                      ≤ 2 ^ 7 * (2 ^ N) ^ 4 * (2 ^ N) ^ N * 2 ^ N :=
                        Nat.mul_le_mul_right _ (Nat.mul_le_mul (Nat.mul_le_mul_left 128 hN4)
                          (h2.trans hNN))
                    _ = 2 ^ (7 + 4 * N + N * N + N) := by
                        rw [← pow_mul, ← pow_mul, ← pow_add, ← pow_add, ← pow_add]; ring_nf
                    _ ≤ 2 ^ (4 * E) := Nat.pow_le_pow_right (by omega) hexp
                have hReal : 128 * (N : ℝ) ^ 4 * (N.factorial : ℝ) * (2 : ℝ) ^ N ≤ (2 : ℝ) ^ (4 * E) := by
                  exact_mod_cast hNat
                have hPr : (P : ℝ) * r = (2 : ℝ) ^ (4 * E) := by
                  dsimp [P, r]
                  push_cast
                  have hexp : (-(2 * (E : ℤ))) = -(((2 * E : ℕ) : ℤ)) := by push_cast; ring
                  rw [hexp, zpow_neg, zpow_natCast]
                  have h6 : 6 * E = 4 * E + 2 * E := by omega
                  rw [h6, pow_add]
                  have h2E_ne : (2 : ℝ) ^ (2 * E) ≠ 0 := by positivity
                  field_simp [h2E_ne]
                dsimp [ε]
                rw [one_div_mul_eq_div, div_le_iff₀ hP_pos, mul_comm r (P : ℝ), hPr]
                exact hReal
              obtain ⟨hBallNext, hDetNext⟩ :=
                rounded_ellipsoid_step hN hr_pos (by positivity) hε_small
                  x_star c' (cOf st_next) B' (BOf st_next) hBall' hc_err hB_err
              refine ⟨by change st_next.status = 0; rw [hst_next_def], hBallNext, ?_⟩
              have hDetB' : |B'.det| ≤ Real.exp (- 1 / (5 * ((N : ℝ) + 1))) * |(BOf st).det| := by
                dsimp [B']
                rw [Matrix.det_mul, abs_mul, mul_comm, hw_eq]
                exact mul_le_mul_of_nonneg_right hDetStep (abs_nonneg _)
              calc |(BOf st_next).det|
                  ≤ Real.exp (1 / (10 * ((N : ℝ) + 1))) * |B'.det| := hDetNext
                _ ≤ Real.exp (1 / (10 * ((N : ℝ) + 1))) *
                      (Real.exp (- 1 / (5 * ((N : ℝ) + 1))) * |(BOf st).det|) :=
                    mul_le_mul_of_nonneg_left hDetB' (by positivity)
                _ = (Real.exp (1 / (10 * ((N : ℝ) + 1)) + (- 1 / (5 * ((N : ℝ) + 1))))) *
                      |(BOf st).det| := by rw [← mul_assoc, ← Real.exp_add]
                _ ≤ (Real.exp (1 / (10 * ((N : ℝ) + 1)) + (- 1 / (5 * ((N : ℝ) + 1))))) *
                      (Real.exp (- (t : ℝ) / (10 * ((N : ℝ) + 1))) * R_init ^ N) :=
                    mul_le_mul_of_nonneg_left hDet (by positivity)
                _ = Real.exp (- (((t + 1 : ℕ) : ℝ)) / (10 * ((N : ℝ) + 1))) * R_init ^ N := by
                    rw [← mul_assoc, ← Real.exp_add]
                    congr 2
                    push_cast
                    have hd10 : 10 * ((N : ℝ) + 1) ≠ 0 := by linarith
                    have hd5 : 5 * ((N : ℝ) + 1) ≠ 0 := by linarith
                    field_simp [hd10, hd5]
                    ring
            · left
              dsimp only [ellStep]
              rw [if_neg hnz_false]
              dsimp only [P, Q, E] at hviol
              rw [dif_neg hviol]
    -- Evaluate at t = T: second disjunct contradicts ball_in_ellipsoid_right_inv!
    rcases hFeasInv T le_rfl with hWin | ⟨_, hBallT, hDetT⟩
    · unfold ellipsoidDecide ellRun
      exact beq_iff_eq.mpr hWin
    · exfalso
      obtain ⟨_, _, _, hDetLB⟩ := ball_in_ellipsoid_right_inv hr_pos x_star (cOf (runAt T))
        (BOf (runAt T)) hBallT
      -- Lower bound (r / 2)^N / N! ≥ exp(- (N * (2 * E + N + 1))) using 2 ≤ exp 1!
      have hTwoLeExp : (2 : ℝ) ≤ Real.exp 1 := by
        have := Real.add_one_le_exp 1
        linarith
      have hPowTwoLeExp : ∀ k : ℕ, (2 : ℝ) ^ k ≤ Real.exp (k : ℝ) := by
        intro k
        calc (2 : ℝ) ^ k ≤ (Real.exp 1) ^ k := pow_le_pow_left₀ (by norm_num) hTwoLeExp k
          _ = Real.exp ((k : ℝ) * 1) := (Real.exp_nat_mul 1 k).symm
          _ = Real.exp (k : ℝ) := by ring_nf
      have hLB_exp : Real.exp (- ((N * (2 * E + N + 1) : ℕ) : ℝ)) ≤ (r / 2) ^ N / (N.factorial : ℝ) := by
        have hFacPow : (N.factorial : ℝ) ≤ (2 : ℝ) ^ (N * N) := by
          have hNat : N.factorial ≤ 2 ^ (N * N) := by
            calc N.factorial ≤ N ^ N := Nat.factorial_le_pow N
              _ ≤ (2 ^ N) ^ N := Nat.pow_le_pow_left Nat.lt_two_pow_self.le N
              _ = 2 ^ (N * N) := (pow_mul 2 N N).symm
          exact_mod_cast hNat
        have hr2_eq : (r / 2) ^ N = 1 / ((2 : ℝ) ^ (N * (2 * E + 1))) := by
          dsimp [r]
          have hr_eq : (2 : ℝ) ^ (-(2 * (E : ℤ))) / 2 = 1 / ((2 : ℝ) ^ (2 * E + 1)) := by
            have hexp : (-(2 * (E : ℤ))) = -(((2 * E : ℕ) : ℤ)) := by push_cast; ring
            rw [hexp, zpow_neg, zpow_natCast, pow_succ]
            have hne : (2 : ℝ) ^ (2 * E) ≠ 0 := by positivity
            field_simp [hne]
          rw [hr_eq, one_div_pow, ← pow_mul, mul_comm]
        rw [hr2_eq, div_div]
        have hExpSum : N * (2 * E + 1) + N * N = N * (2 * E + N + 1) := by ring
        have hDenLe : (2 : ℝ) ^ (N * (2 * E + 1)) * (N.factorial : ℝ) ≤
            (2 : ℝ) ^ (N * (2 * E + N + 1)) := by
          rw [← hExpSum, pow_add]
          exact mul_le_mul_of_nonneg_left hFacPow (by positivity)
        have hDenExp : (2 : ℝ) ^ (N * (2 * E + N + 1)) ≤
            Real.exp ((N * (2 * E + N + 1) : ℕ) : ℝ) := hPowTwoLeExp _
        have hInv : 1 / Real.exp ((N * (2 * E + N + 1) : ℕ) : ℝ) ≤
            1 / ((2 : ℝ) ^ (N * (2 * E + 1)) * (N.factorial : ℝ)) := by
          have hFacPos : (0 : ℝ) < (N.factorial : ℝ) := by exact_mod_cast Nat.factorial_pos N
          exact one_div_le_one_div_of_le (by positivity) (hDenLe.trans hDenExp)
        rwa [one_div, ← Real.exp_neg] at hInv
      have hUB_exp : |(BOf (runAt T)).det| ≤
          Real.exp (((N * E : ℕ) : ℝ) - (T : ℝ) / (10 * ((N : ℝ) + 1))) := by
        have hRinit_pow : R_init ^ N ≤ Real.exp ((N * E : ℕ) : ℝ) := by
          dsimp [R_init]
          rw [← pow_mul, mul_comm E N]
          exact hPowTwoLeExp (N * E)
        calc |(BOf (runAt T)).det|
            ≤ Real.exp (- (T : ℝ) / (10 * ((N : ℝ) + 1))) * R_init ^ N := hDetT
          _ ≤ Real.exp (- (T : ℝ) / (10 * ((N : ℝ) + 1))) * Real.exp ((N * E : ℕ) : ℝ) :=
              mul_le_mul_of_nonneg_left hRinit_pow (by positivity)
          _ = Real.exp (((N * E : ℕ) : ℝ) - (T : ℝ) / (10 * ((N : ℝ) + 1))) := by
              rw [← Real.exp_add]; congr 1; ring
      have hExpIneq : Real.exp (- ((N * (2 * E + N + 1) : ℕ) : ℝ)) ≤
          Real.exp (((N * E : ℕ) : ℝ) - (T : ℝ) / (10 * ((N : ℝ) + 1))) :=
        (hLB_exp.trans hDetLB).trans hUB_exp
      rw [Real.exp_le_exp] at hExpIneq
      have hd10_pos : (0 : ℝ) < 10 * ((N : ℝ) + 1) := by linarith
      have hMul := mul_le_mul_of_nonneg_right hExpIneq hd10_pos.le
      have hSimpR : (((N * E : ℕ) : ℝ) - (T : ℝ) / (10 * ((N : ℝ) + 1))) * (10 * ((N : ℝ) + 1)) =
          ((N * E : ℕ) : ℝ) * (10 * ((N : ℝ) + 1)) - (T : ℝ) := by
        field_simp [hd10_pos.ne']; try ring
      rw [hSimpR] at hMul
      have hT_le : (T : ℝ) ≤ (((10 * (N + 1) * N * (3 * E + N + 1) : ℕ) : ℝ)) := by
        push_cast at hMul ⊢
        linarith
      have hT_gt : (((10 * (N + 1) * N * (3 * E + N + 1) : ℕ) : ℝ)) < (T : ℝ) := by
        have hNat : 10 * (N + 1) * N * (3 * E + N + 1) < T := by
          have hle : 10 * (N + 1) * N * (3 * E + N + 1) ≤
              10 * (N + 1) * N * (3 * ellParamE N L + N + 2) :=
            Nat.mul_le_mul_left _ (by dsimp [E]; omega)
          dsimp [T, ellParamT]
          omega
        exact_mod_cast hNat
      linarith

end UL.Proof.cit_gls88_rational_lp.RacerCG
