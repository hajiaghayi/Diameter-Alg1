import Mathlib
import UL.Proof.cit_gls88_rational_lp.RacerCG_H1b
import UL.Proof.cit_gls88_rational_lp.RacerCG_H2c
import UL.Proof.cit_gls88_rational_lp.RacerCG_H3c
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

/-! ### 1. Framed Loop Wrapper & Workspace Index / Magnitude Bounds -/

/-- Framed `forLoopStmt` rule: when `mod 10 ctrSlot` holds and `P` ignores `(10, ctrSlot)`,
the step obligation only needs `PreservesOutside mod ws₀ ws'` and `P (k + 1) ws'` directly on `ws'`
(automatically handling the trailing counter increment `hWrite ws' 10 ctrSlot (k + 1)`). -/
theorem exec_for_frame {d : ℕ} {inp : UL.BitRAMInput d} {maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K)
    (ctrSlot : ℤ) (countE : UL.IntExpr) (body : UL.BitRAMStmt)
    (N m_body : ℕ) (mod : ℕ → ℤ → Prop) (P : ℕ → UL.WordStore → Prop)
    {ws₀ : UL.WordStore}
    (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hslot1 : ctrSlot ≤ (maxIdx : ℤ))
    (hN_le : N ≤ maxIdx)
    (hmod_ctr : mod 10 ctrSlot)
    (hP_ign : ∀ (k : ℕ) (ws : UL.WordStore) (v : ℤ), P k (hWrite ws 10 ctrSlot v) ↔ P k ws)
    (hcnt : evalVal inp (hWrite ws₀ 10 ctrSlot 0) countE = (N : ℤ))
    (hP₀ : P 0 ws₀)
    (hstep : ∀ k < N, ∀ ws : UL.WordStore,
      StoreBounded 31 maxIdx K ws →
      hRead ws 10 ctrSlot = (k : ℤ) →
      PreservesOutside mod ws₀ ws →
      P k ws →
      ∃ ws', ExecBit inp maxIdx K body ws ws' (m_body * stepU) (m_body * stepB K) ∧
        hRead ws' 10 ctrSlot = (k : ℤ) ∧
        PreservesOutside mod ws₀ ws' ∧
        P (k + 1) ws')
    (hslot_wf : ctrSlot.natAbs ≤ 64 := by decide)
    (hslot0 : 0 ≤ ctrSlot := by decide)
    (hwf_cnt : exprWf 31 countE = true := by decide)
    (hsz_cnt : exprNodes countE ≤ 64 ∧ exprLeaves countE ≤ 64 := by decide) :
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      P N ws₁ ∧
      ExecBit inp maxIdx K (forLoopStmt ctrSlot countE body) ws₀ ws₁
        ((2 + N * (m_body + 1)) * stepU) ((2 + N * (m_body + 1)) * stepB K) := by
  let Inv : ℕ → UL.WordStore → Prop := fun k ws => PreservesOutside mod ws₀ ws ∧ P k ws
  have hInv₀ : Inv 0 (hWrite ws₀ 10 ctrSlot 0) :=
    ⟨PreservesOutside.write ws₀ 0 hmod_ctr, (hP_ign 0 ws₀ 0).mpr hP₀⟩
  obtain ⟨ws₁, _, ⟨hpr₁, hP₁⟩, hex₁⟩ := exec_for hctx ctrSlot countE body N m_body Inv
    hws₀ hslot1 hN_le hcnt hInv₀
    (fun k hk ws hws hctr ⟨hpr, hPk⟩ => by
      obtain ⟨ws', hex', hctr', hpr', hPk1⟩ := hstep k hk ws hws hctr hpr hPk
      exact ⟨ws', hex', hctr',
        hpr'.trans (PreservesOutside.write ws' ((k : ℤ) + 1) hmod_ctr),
        (hP_ign (k + 1) ws' ((k : ℤ) + 1)).mpr hPk1⟩)
    hslot_wf hslot0 hwf_cnt hsz_cnt
  exact ⟨ws₁, hpr₁, hP₁, hex₁⟩

theorem solverMaxIdx_bounds (nVars nEq nLe : ℕ) :
    let maxIdx := solverMaxIdx nVars nEq nLe
    64 ≤ maxIdx ∧
    nVars ≤ maxIdx ∧
    nEq ≤ maxIdx ∧
    nLe ≤ maxIdx ∧
    nVars + 1 ≤ maxIdx ∧
    nVars + 2 ≤ maxIdx ∧
    2 * nVars ≤ maxIdx ∧
    2 * nLe ≤ maxIdx ∧
    nEq + nLe ≤ maxIdx ∧
    2 * nEq + 2 * nLe ≤ maxIdx ∧
    nEq * nVars ≤ maxIdx ∧
    nLe * nVars ≤ maxIdx ∧
    (2 * nEq + 2 * nLe) * (nVars + 2) ≤ maxIdx ∧
    4 * (nVars + 2) ≤ maxIdx ∧
    2 * ((nVars + 2) * (nVars + 2)) ≤ maxIdx ∧
    (nEq + nLe) * (nVars + 1) ≤ maxIdx ∧
    2 * ((nEq + nLe) * (nVars + 1)) ≤ maxIdx ∧
    (nEq + nLe) + nVars ≤ maxIdx := by
  intro maxIdx
  let S := nVars + nEq + nLe + 4
  have hmax : maxIdx = 64 + 8 * S ^ 2 := rfl
  have hS4 : 4 ≤ S := by dsimp [S]; omega
  refine ⟨by omega, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;>
    (rw [hmax]; dsimp [S] at hS4 ⊢; nlinarith)

private theorem nat_factorial_le_pow (m : ℕ) : m.factorial ≤ m ^ m := by
  induction m with
  | zero => simp
  | succ k ih =>
      rw [Nat.factorial_succ, pow_succ']
      refine Nat.mul_le_mul_left (k + 1) ?_
      exact ih.trans (Nat.pow_le_pow_left (Nat.le_succ k) k)

theorem bareiss_bound_le_two_pow_solverK (nVars nEq nLe B' : ℕ) :
    (nVars + 1).factorial * (2 ^ (B' * (nVars + 2))) ^ (nVars + 1) ≤
      2 ^ solverK nVars nEq nLe B' := by
  let m := nVars + 1
  let B_int := B' * (nVars + 2)
  have hf1 : m.factorial ≤ m ^ m := nat_factorial_le_pow m
  have hf2 : m ^ m ≤ (2 ^ m) ^ m := Nat.pow_le_pow_left Nat.lt_two_pow_self.le m
  have hf3 : (2 ^ m) ^ m = 2 ^ (m * m) := (pow_mul 2 m m).symm
  have hp : (2 ^ B_int) ^ m = 2 ^ (B_int * m) := (pow_mul 2 B_int m).symm
  have hprod : m.factorial * (2 ^ B_int) ^ m ≤ 2 ^ (m * m + B_int * m) := by
    calc m.factorial * (2 ^ B_int) ^ m
        ≤ 2 ^ (m * m) * 2 ^ (B_int * m) := by
          rw [← hp]
          exact Nat.mul_le_mul (hf1.trans (hf2.trans_eq hf3)) le_rfl
      _ = 2 ^ (m * m + B_int * m) := (pow_add 2 (m * m) (B_int * m)).symm
  have hexp : m * m + B_int * m ≤ solverK nVars nEq nLe B' := by
    have h1 : m * m + B_int * m = (nVars + 1) * (nVars + 1 + B_int) := by dsimp [m]; ring
    have h2 : (nVars + 1) * (nVars + 1 + B_int) ≤ (nVars + 2 + 2) * (nVars + 2 + 2 + B_int) :=
      Nat.mul_le_mul (by omega) (by omega)
    have h3 : (nVars + 2 + 2) * (nVars + 2 + 2 + B_int) = ellParamE (nVars + 2) B_int := rfl
    have h4 : ellParamE (nVars + 2) B_int ≤ solverK nVars nEq nLe B' := by
      dsimp [solverK, ellParamBsqrt, B_int]; omega
    exact (h1.trans_le h2).trans (h3.trans_le h4)
  exact hprod.trans (Nat.pow_le_pow_right (by omega) hexp)

theorem fin_lastCases_eq_dite {n : ℕ} {α : Type*} (lastVal : α) (initFn : Fin n → α)
    (j : Fin (n + 1)) :
    Fin.lastCases lastVal initFn j =
      if h : j.val < n then initFn ⟨j.val, h⟩ else lastVal := by
  refine Fin.lastCases ?_ (fun j' => ?_) j
  · simp
  · simp [j'.isLt]

theorem bareissStep_pivRowOfCol_range {m n : ℕ} (st : BareissState m n) (c : Fin n)
    (h : ∀ j : Fin n, st.pivRowOfCol j = -1 ∨ ∃ r₀ : Fin m, st.pivRowOfCol j = (r₀.val : ℤ)) :
    ∀ j : Fin n,
      (bareissColStep st c).pivRowOfCol j = -1 ∨
      ∃ r₀ : Fin m, (bareissColStep st c).pivRowOfCol j = (r₀.val : ℤ) := by
  intro j
  dsimp [bareissColStep]
  split_ifs with hpr
  · dsimp only
    split_ifs with hjc
    · exact Or.inr ⟨⟨(findPivotRow st.A st.rowUsed c.castSucc).toNat, hpr.2⟩, rfl⟩
    · exact h j
  · exact h j

theorem bareissRun_pivRowOfCol_range {m n : ℕ} (T₀ : Fin m → Fin n → ℤ) (rhs₀ : Fin m → ℤ) :
    ∀ j : Fin n,
      (bareissRun T₀ rhs₀).pivRowOfCol j = -1 ∨
      ∃ r₀ : Fin m, (bareissRun T₀ rhs₀).pivRowOfCol j = (r₀.val : ℤ) := by
  suffices h : ∀ k : ℕ, (hk : k ≤ n) →
      ∀ j : Fin n,
        (Fin.foldl k (fun st (c : Fin k) =>
          bareissColStep st ⟨c.val, lt_of_lt_of_le c.isLt hk⟩) (bareissInit T₀ rhs₀)).pivRowOfCol j = -1 ∨
        ∃ r₀ : Fin m,
          (Fin.foldl k (fun st (c : Fin k) =>
            bareissColStep st ⟨c.val, lt_of_lt_of_le c.isLt hk⟩) (bareissInit T₀ rhs₀)).pivRowOfCol j = (r₀.val : ℤ) by
    exact h n le_rfl
  intro k
  induction k with
  | zero =>
      intro _ j
      left
      simp [Fin.foldl_zero, bareissInit]
  | succ k ih =>
      intro hk j
      have hfold : Fin.foldl (k + 1) (fun st (c : Fin (k + 1)) =>
          bareissColStep st ⟨c.val, lt_of_lt_of_le c.isLt hk⟩) (bareissInit T₀ rhs₀) =
          bareissColStep (Fin.foldl k (fun st (c : Fin k) =>
            bareissColStep st ⟨c.val, lt_of_lt_of_le c.isLt (Nat.le_of_succ_le hk)⟩)
            (bareissInit T₀ rhs₀)) ⟨k, hk⟩ := by
        rw [Fin.foldl_succ_last]; rfl
      rw [hfold]
      exact bareissStep_pivRowOfCol_range _ _ (ih (Nat.le_of_succ_le hk)) j

/-! ### 2. `BareissStateInHeap` & `buildActiveEqStmt` -/

def BareissStateInHeap {m n : ℕ} (st : BareissState m n) (ws : UL.WordStore) : Prop :=
  hRead ws 10 30 = st.prevPiv ∧
  (∀ (r : Fin m) (j : Fin (n + 1)),
    hRead ws 28 ((r.val * (n + 1) + j.val : ℕ) : ℤ) = st.A r j) ∧
  (∀ r : Fin m,
    hRead ws 29 (r.val : ℤ) = if st.rowUsed r then 1 else 0) ∧
  (∀ j : Fin n,
    hRead ws 29 ((m + j.val : ℕ) : ℤ) = st.pivRowOfCol j)

theorem BareissStateInHeap.preserve {m n : ℕ} {st : BareissState m n}
    {mod : ℕ → ℤ → Prop} {ws₀ ws₁ : UL.WordStore}
    (h : BareissStateInHeap st ws₀) (hpr : PreservesOutside mod ws₀ ws₁)
    (h30 : ¬ mod 10 30)
    (h28 : ∀ idx, ¬ mod 28 idx)
    (h29 : ∀ idx, ¬ mod 29 idx) :
    BareissStateInHeap st ws₁ := by
  refine ⟨?_, fun r j => ?_, fun r => ?_, fun j => ?_⟩
  · rw [hpr 10 30 h30]; exact h.1
  · rw [hpr 28 _ (h28 _)]; exact h.2.1 r j
  · rw [hpr 29 _ (h29 _)]; exact h.2.2.1 r
  · rw [hpr 29 _ (h29 _)]; exact h.2.2.2 j

theorem BareissStateInHeap_ign_ctr {m n : ℕ} (st : BareissState m n)
    (ctr : ℤ) (hctr : ctr ≠ 30) (ws : UL.WordStore) (v : ℤ) :
    BareissStateInHeap st (hWrite ws 10 ctr v) ↔ BareissStateInHeap st ws := by
  dsimp [BareissStateInHeap]
  rw [hRead_hWrite_of_ne ws v (Or.inr hctr.symm)]
  simp only [and_congr_right_iff]
  intro _
  constructor <;> rintro ⟨h1, h2, h3⟩ <;> refine ⟨fun r j => ?_, fun r => ?_, fun j => ?_⟩
  · have := h1 r j; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
  · have := h2 r; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
  · have := h3 j; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
  · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h1 r j
  · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h2 r
  · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h3 j

def buildActiveEqStmt : UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let nEqE := UL.IntExpr.readHeap 10 (.lit 1)
  let nLeE := UL.IntExpr.readHeap 10 (.lit 2)
  let mBarE := UL.IntExpr.readHeap 10 (.lit 5)
  let wE := UL.IntExpr.readHeap 10 (.lit 28)
  let iE := UL.IntExpr.readHeap 10 (.lit 42)
  let jE := UL.IntExpr.readHeap 10 (.lit 43)
  let rLeE := UL.IntExpr.add nEqE iE
  seqBitStmts
    [ .writeHeap 10 (.lit 28) (.add nVarsE (.lit 1))
    , .writeHeap 10 (.lit 30) (.lit 1)
    , forLoopStmt 42 nEqE
        (seqBitStmts
          [ forLoopStmt 43 nVarsE
              (.writeHeap 28 (.add (.mul iE wE) jE)
                (.readHeap 19 (.add (.mul iE nVarsE) jE)))
          , .writeHeap 28 (.add (.mul iE wE) nVarsE) (.readHeap 20 iE) ])
    , forLoopStmt 42 nLeE
        (seqBitStmts
          [ forLoopStmt 43 nVarsE
              (.writeHeap 28 (.add (.mul rLeE wE) jE)
                (.mul (.readHeap 23 iE) (.readHeap 21 (.add (.mul iE nVarsE) jE))))
          , .writeHeap 28 (.add (.mul rLeE wE) nVarsE)
              (.mul (.readHeap 23 iE) (.readHeap 22 iE)) ])
    , forLoopStmt 42 mBarE (.writeHeap 29 iE (.lit 0))
    , forLoopStmt 42 nVarsE (.writeHeap 29 (.add mBarE iE) (.lit (-1))) ]

theorem exec_buildActiveEqStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars ≤ maxIdx ∧ nEq ≤ maxIdx ∧ nLe ≤ maxIdx ∧
            nVars + 1 ≤ maxIdx ∧ nEq + nLe ≤ maxIdx ∧
            (nEq + nLe) * (nVars + 1) ≤ maxIdx ∧
            (nEq + nLe) + nVars ≤ maxIdx)
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (act : Fin nLe → Bool)
    (hMeqB : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ K) (hdeqB : ∀ i, (d_eq i).natAbs ≤ 2 ^ K)
    (hMleB : ∀ k j, (M_le k j).natAbs ≤ 2 ^ K) (hdleB : ∀ k, (d_le k).natAbs ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hCleared : ClearedLPInHeap M_eq d_eq M_le d_le ws₀)
    (hAct_ws : ∀ k : Fin nLe, hRead ws₀ 23 (k.val : ℤ) = if act k then 1 else 0) :
    let m_bar := nEq + nLe
    let st₀ := bareissInit (buildActiveEqM M_eq M_le act) (buildActiveEqD d_eq d_le act)
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (idx = 28 ∨ idx = 30 ∨ idx = 42 ∨ idx = 43)) ∨ t_id = 28 ∨ t_id = 29
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      BareissStateInHeap st₀ ws₁ ∧
      ExecBit inp maxIdx K buildActiveEqStmt ws₀ ws₁
        ((10 + m_bar * (6 + 2 * nVars) + 2 * nVars) * stepU)
        ((10 + m_bar * (6 + 2 * nVars) + 2 * nVars) * stepB K) := by
  intro m_bar st₀ mod
  let w := nVars + 1
  have hw_abs : ((w : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
    simpa using hIdx.2.2.2.1.trans hctx.hMaxIdx
  have hs1 := exec_write hctx hws₀ 10 (.lit 28) (.add (.readHeap 10 (.lit 0)) (.lit 1))
    28 (w : ℤ) rfl
    (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hDims.1]
        exact_mod_cast (rfl : nVars + 1 = w))
    (by omega) (by omega) hw_abs
  let ws1 := hWrite ws₀ 10 28 (w : ℤ)
  have hs2 := exec_write hctx hs1.2.1 10 (.lit 30) (.lit 1) 30 1 rfl rfl
    (by omega) (by omega) Nat.one_le_two_pow
  let ws2 := hWrite ws1 10 30 1
  have hpr2 : PreservesOutside mod ws₀ ws2 :=
    (PreservesOutside.write ws₀ _ (by dsimp [mod]; omega)).trans
      (PreservesOutside.write ws1 _ (by dsimp [mod]; omega))
  have hw_ws2 : hRead ws2 10 28 = (w : ℤ) := by
    rw [hRead_hWrite_of_ne ws1 _ (Or.inr (by omega)), hRead_hWrite_self]
  have h30_ws2 : hRead ws2 10 30 = 1 := hRead_hWrite_self ws1 10 30 1
  -- Loop 1: 0 .. nEq - 1
  let mod1 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 42 ∨ idx = 43)) ∨
    (t_id = 28 ∧ 0 ≤ idx ∧ idx < ((nEq * w : ℕ) : ℤ))
  let P1 : ℕ → UL.WordStore → Prop := fun R ws =>
    ∀ (r : Fin m_bar), r.val < R → ∀ (j : Fin w),
      hRead ws 28 ((r.val * w + j.val : ℕ) : ℤ) = st₀.A r j
  have hcnt1 : evalVal inp (hWrite ws2 10 42 0) (.readHeap 10 (.lit 1)) = (nEq : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws2 0 (Or.inr (by omega)), hpr2 10 1 (by dsimp [mod]; omega), hDims.2.1]
  obtain ⟨ws3, hprL1, hDone1, hs3⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 1))
    (seqBitStmts
      [ forLoopStmt 43 (.readHeap 10 (.lit 0))
          (.writeHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 43)))
            (.readHeap 19 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43)))))
      , .writeHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 0)))
          (.readHeap 20 (.readHeap 10 (.lit 42))) ])
    nEq (3 + 2 * nVars) mod1 P1 hs2.2.1 (by omega) hIdx.2.1
    (by dsimp [mod1]; omega)
    (fun k ws v => by
      dsimp [P1]; constructor <;> intro h r hr j
      · have := h r hr j; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h r hr j)
    hcnt1 (fun _ h _ => False.elim (Nat.not_lt_zero _ h))
    (fun i hi ws hws hctr_i hpr_i hprev_i => by
      let iEq : Fin nEq := ⟨i, hi⟩
      have hNext_le : (i + 1) * w ≤ nEq * w := Nat.mul_le_mul_right w hi
      have hEqW_le : nEq * w ≤ maxIdx :=
        (Nat.mul_le_mul_right w (Nat.le_add_right nEq nLe)).trans hIdx.2.2.2.2.2.1
      let modIn1 : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 43) ∨
        (t_id = 28 ∧ ((i * w : ℕ) : ℤ) ≤ idx ∧ idx < (((i + 1) * w : ℕ) : ℤ))
      let PIn1 : ℕ → UL.WordStore → Prop := fun c wsi =>
        ∀ j : Fin nVars, j.val < c → hRead wsi 28 ((i * w + j.val : ℕ) : ℤ) = M_eq iEq j
      have hcntIn1 : evalVal inp (hWrite ws 10 43 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne ws 0 (Or.inr (by omega)),
            hpr_i 10 0 (by dsimp [mod1]; omega), hpr2 10 0 (by dsimp [mod]; omega), hDims.1]
      obtain ⟨wsi_end, hprIn1, hCols1, hexIn1⟩ := exec_for_frame hctx 43 (.readHeap 10 (.lit 0))
        (.writeHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 43)))
          (.readHeap 19 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43)))))
        nVars 1 modIn1 PIn1 hws (by omega) hIdx.1
        (by dsimp [modIn1]; omega)
        (fun c wsi v => by
          dsimp [PIn1]; constructor <;> intro h j hj
          · have := h j hj; rwa [hRead_hWrite_of_ne wsi v (Or.inl (by decide))] at this
          · rw [hRead_hWrite_of_ne wsi v (Or.inl (by decide))]; exact h j hj)
        hcntIn1 (fun _ h => False.elim (Nat.not_lt_zero _ h))
        (fun j hj wsi hwsi hctr_j hpr_j hprev_j => by
          let jFin : Fin nVars := ⟨j, hj⟩
          have hij_lt : i * w + j < (i + 1) * w := by
            calc i * w + j < i * w + w := Nat.add_lt_add_left (by dsimp [w]; omega) _
              _ = (i + 1) * w := by ring
          have hi_w : hRead wsi 10 42 = (i : ℤ) := by
            rw [hpr_j 10 42 (by dsimp [modIn1]; omega), hctr_i]
          have hw_w : hRead wsi 10 28 = (w : ℤ) := by
            rw [hpr_j 10 28 (by dsimp [modIn1]; omega),
                hpr_i 10 28 (by dsimp [mod1]; omega), hw_ws2]
          have hnV_w : hRead wsi 10 0 = (nVars : ℤ) := by
            rw [hpr_j 10 0 (by dsimp [modIn1]; omega), hpr_i 10 0 (by dsimp [mod1]; omega),
                hpr2 10 0 (by dsimp [mod]; omega), hDims.1]
          have hM_src : hRead wsi 19 ((i * nVars + j : ℕ) : ℤ) = M_eq iEq jFin := by
            rw [hpr_j 19 _ (by dsimp [modIn1]; omega), hpr_i 19 _ (by dsimp [mod1]; omega),
                hpr2 19 _ (by dsimp [mod]; omega)]
            exact hCleared.1 iEq jFin
          have hw_step := exec_write hctx hwsi 28
            (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 43)))
            (.readHeap 19 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43))))
            ((i * w + j : ℕ) : ℤ) (M_eq iEq jFin)
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_w, hw_w, hctr_j]
                exact_mod_cast (rfl : i * w + j = i * w + j))
            (by have hsrc : (i : ℤ) * (nVars : ℤ) + (j : ℤ) = ((i * nVars + j : ℕ) : ℤ) :=
                  by exact_mod_cast (rfl : i * nVars + j = i * nVars + j)
                simp only [evalVal_readHeap, evalVal_add, evalVal_mul, evalVal_lit, hi_w, hnV_w, hctr_j, hsrc, hM_src])
            (Nat.cast_nonneg _)
            (Nat.cast_le.mpr ((hij_lt.le.trans hNext_le).trans hEqW_le))
            (hMeqB iEq jFin)
          refine ⟨_, hw_step, ?_,
            hpr_j.trans (PreservesOutside.write wsi _
              (Or.inr ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hij_lt⟩)), ?_⟩
          · rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega))]; exact hctr_j
          · intro j' hj'
            rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
            · rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]; exact hprev_j j' hlt
            · have hj_eq : j' = jFin := Fin.ext heq
              subst hj_eq; exact hRead_hWrite_self wsi 28 _ _)
      have hi_end : hRead wsi_end 10 42 = (i : ℤ) := by
        rw [hprIn1 10 42 (by dsimp [modIn1]; omega), hctr_i]
      have hw_end : hRead wsi_end 10 28 = (w : ℤ) := by
        rw [hprIn1 10 28 (by dsimp [modIn1]; omega), hpr_i 10 28 (by dsimp [mod1]; omega), hw_ws2]
      have hnV_end : hRead wsi_end 10 0 = (nVars : ℤ) := by
        rw [hprIn1 10 0 (by dsimp [modIn1]; omega), hpr_i 10 0 (by dsimp [mod1]; omega),
            hpr2 10 0 (by dsimp [mod]; omega), hDims.1]
      have hd_src : hRead wsi_end 20 (i : ℤ) = d_eq iEq := by
        rw [hprIn1 20 _ (by dsimp [modIn1]; omega), hpr_i 20 _ (by dsimp [mod1]; omega),
            hpr2 20 _ (by dsimp [mod]; omega)]
        exact hCleared.2.1 iEq
      have hlast_lt : i * w + nVars < (i + 1) * w := by
        calc i * w + nVars < i * w + w := Nat.add_lt_add_left (by dsimp [w]; omega) _
          _ = (i + 1) * w := by ring
      have hw_rhs := exec_write hctx hexIn1.2.1 28
        (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 0)))
        (.readHeap 20 (.readHeap 10 (.lit 42)))
        ((i * w + nVars : ℕ) : ℤ) (d_eq iEq)
        (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_end, hw_end, hnV_end]
            exact_mod_cast (rfl : i * w + nVars = i * w + nVars))
        (by simp only [evalVal_readHeap, evalVal_lit, hi_end, hd_src])
        (Nat.cast_nonneg _)
        (Nat.cast_le.mpr ((hlast_lt.le.trans hNext_le).trans hEqW_le))
        (hdeqB iEq)
      let ws_out := hWrite wsi_end 28 ((i * w + nVars : ℕ) : ℤ) (d_eq iEq)
      have hpr_step : PreservesOutside mod1 ws2 ws_out :=
        (hpr_i.trans (hprIn1.mono (by
          intro t_id idx h; dsimp [modIn1] at h; dsimp [mod1]
          rcases h with ⟨rfl, rfl⟩ | ⟨rfl, hlo, hhi⟩
          · exact Or.inl ⟨rfl, Or.inr rfl⟩
          · exact Or.inr ⟨rfl, le_trans (Nat.cast_nonneg _) hlo,
              lt_of_lt_of_le hhi (Nat.cast_le.mpr hNext_le)⟩))).trans
          (PreservesOutside.write wsi_end _ (Or.inr ⟨rfl, Nat.cast_nonneg _,
            Nat.cast_lt.mpr (lt_of_lt_of_le hlast_lt hNext_le)⟩))
      refine ⟨ws_out, (hexIn1.seq_steps hw_rhs).mono_steps (by omega), ?_, hpr_step, ?_⟩
      · rw [hRead_hWrite_of_ne wsi_end _ (Or.inl (by omega))]; exact hi_end
      · intro r' hr' j'
        rcases (show r'.val < i ∨ r'.val = i by omega) with hlt | heq
        · have hlt_idx : r'.val * w + j'.val < i * w := row_col_lt_mul hlt j'.isLt
          have hne_rhs : ((r'.val * w + j'.val : ℕ) : ℤ) ≠ ((i * w + nVars : ℕ) : ℤ) :=
            ne_of_lt (Nat.cast_lt.mpr (lt_of_lt_of_le hlt_idx (Nat.le_add_right _ _)))
          rw [hRead_hWrite_of_ne wsi_end _ (Or.inr hne_rhs),
              hprIn1 28 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, hge, _⟩
                · exact absurd h (by decide)
                · exact absurd hge (not_le.mpr (Nat.cast_lt.mpr hlt_idx)))]
          exact hprev_i r' hlt j'
        · dsimp [st₀, bareissInit]
          rw [fin_lastCases_eq_dite]
          by_cases hj : j'.val < nVars
          · rw [dif_pos hj]
            dsimp [buildActiveEqM, ws_out]
            have hr_lt : r'.val < nEq := by omega
            have hr_eq : (⟨r'.val, hr_lt⟩ : Fin nEq) = iEq := Fin.ext heq
            rw [dif_pos hr_lt, hr_eq, heq, hRead_hWrite_of_ne wsi_end _ (Or.inr (by omega))]
            exact hCols1 ⟨j'.val, hj⟩ hj
          · have hj_eq : j'.val = nVars := by have := j'.isLt; dsimp [w] at this; omega
            rw [dif_neg hj]
            dsimp [buildActiveEqD, ws_out]
            have hr_lt : r'.val < nEq := by omega
            have hr_eq : (⟨r'.val, hr_lt⟩ : Fin nEq) = iEq := Fin.ext heq
            rw [dif_pos hr_lt, hr_eq, heq, hj_eq]
            exact hRead_hWrite_self wsi_end 28 _ _)
  -- Loop 2: 0 .. nLe - 1
  let mod2 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 42 ∨ idx = 43)) ∨
    (t_id = 28 ∧ ((nEq * w : ℕ) : ℤ) ≤ idx ∧ idx < ((m_bar * w : ℕ) : ℤ))
  let P2 : ℕ → UL.WordStore → Prop := fun K_done ws =>
    ∀ (k : Fin nLe), k.val < K_done → ∀ (j : Fin w),
      hRead ws 28 (((nEq + k.val) * w + j.val : ℕ) : ℤ) =
        st₀.A ⟨nEq + k.val, by omega⟩ j
  have hcnt2 : evalVal inp (hWrite ws3 10 42 0) (.readHeap 10 (.lit 2)) = (nLe : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws3 0 (Or.inr (by omega)),
        hprL1 10 2 (by dsimp [mod1]; omega), hpr2 10 2 (by dsimp [mod]; omega), hDims.2.2.1]
  obtain ⟨ws4, hprL2, hDone2, hs4⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 2))
    (seqBitStmts
      [ forLoopStmt 43 (.readHeap 10 (.lit 0))
          (.writeHeap 28
            (.add (.mul (.add (.readHeap 10 (.lit 1)) (.readHeap 10 (.lit 42))) (.readHeap 10 (.lit 28)))
                  (.readHeap 10 (.lit 43)))
            (.mul (.readHeap 23 (.readHeap 10 (.lit 42)))
                  (.readHeap 21 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43))))))
      , .writeHeap 28
          (.add (.mul (.add (.readHeap 10 (.lit 1)) (.readHeap 10 (.lit 42))) (.readHeap 10 (.lit 28)))
                (.readHeap 10 (.lit 0)))
          (.mul (.readHeap 23 (.readHeap 10 (.lit 42))) (.readHeap 22 (.readHeap 10 (.lit 42)))) ])
    nLe (3 + 2 * nVars) mod2 P2 hs3.2.1 (by omega) hIdx.2.2.1
    (by dsimp [mod2]; omega)
    (fun c ws v => by
      dsimp [P2]; constructor <;> intro h k hk j
      · have := h k hk j; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h k hk j)
    hcnt2 (fun _ h _ => False.elim (Nat.not_lt_zero _ h))
    (fun k hk ws hws hctr_k hpr_k hprev_k => by
      let kFin : Fin nLe := ⟨k, hk⟩
      let r := nEq + k
      have hr_lt : r < m_bar := by dsimp [r, m_bar]; omega
      have hNext_le : (r + 1) * w ≤ m_bar * w := Nat.mul_le_mul_right w hr_lt
      have hge_eq : nEq * w ≤ r * w := Nat.mul_le_mul_right w (Nat.le_add_right nEq k)
      let modIn2 : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 43) ∨
        (t_id = 28 ∧ ((r * w : ℕ) : ℤ) ≤ idx ∧ idx < (((r + 1) * w : ℕ) : ℤ))
      let PIn2 : ℕ → UL.WordStore → Prop := fun c wsi =>
        ∀ j : Fin nVars, j.val < c →
          hRead wsi 28 ((r * w + j.val : ℕ) : ℤ) = if act kFin then M_le kFin j else 0
      have hcntIn2 : evalVal inp (hWrite ws 10 43 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne ws 0 (Or.inr (by omega)),
            hpr_k 10 0 (by dsimp [mod2]; omega), hprL1 10 0 (by dsimp [mod1]; omega),
            hpr2 10 0 (by dsimp [mod]; omega), hDims.1]
      obtain ⟨wsi_end, hprIn2, hCols2, hexIn2⟩ := exec_for_frame hctx 43 (.readHeap 10 (.lit 0))
        (.writeHeap 28
          (.add (.mul (.add (.readHeap 10 (.lit 1)) (.readHeap 10 (.lit 42))) (.readHeap 10 (.lit 28)))
                (.readHeap 10 (.lit 43)))
          (.mul (.readHeap 23 (.readHeap 10 (.lit 42)))
                (.readHeap 21 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43))))))
        nVars 1 modIn2 PIn2 hws (by omega) hIdx.1
        (by dsimp [modIn2]; omega)
        (fun c wsi v => by
          dsimp [PIn2]; constructor <;> intro h j hj
          · have := h j hj; rwa [hRead_hWrite_of_ne wsi v (Or.inl (by decide))] at this
          · rw [hRead_hWrite_of_ne wsi v (Or.inl (by decide))]; exact h j hj)
        hcntIn2 (fun _ h => False.elim (Nat.not_lt_zero _ h))
        (fun j hj wsi hwsi hctr_j hpr_j hprev_j => by
          let jFin : Fin nVars := ⟨j, hj⟩
          have hrj_lt : r * w + j < (r + 1) * w := by
            calc r * w + j < r * w + w := Nat.add_lt_add_left (by dsimp [w]; omega) _
              _ = (r + 1) * w := by ring
          have hk_w : hRead wsi 10 42 = (k : ℤ) := by
            rw [hpr_j 10 42 (by dsimp [modIn2]; omega), hctr_k]
          have hnE_w : hRead wsi 10 1 = (nEq : ℤ) := by
            rw [hpr_j 10 1 (by dsimp [modIn2]; omega), hpr_k 10 1 (by dsimp [mod2]; omega),
                hprL1 10 1 (by dsimp [mod1]; omega), hpr2 10 1 (by dsimp [mod]; omega), hDims.2.1]
          have hw_w : hRead wsi 10 28 = (w : ℤ) := by
            rw [hpr_j 10 28 (by dsimp [modIn2]; omega), hpr_k 10 28 (by dsimp [mod2]; omega),
                hprL1 10 28 (by dsimp [mod1]; omega), hw_ws2]
          have hnV_w : hRead wsi 10 0 = (nVars : ℤ) := by
            rw [hpr_j 10 0 (by dsimp [modIn2]; omega), hpr_k 10 0 (by dsimp [mod2]; omega),
                hprL1 10 0 (by dsimp [mod1]; omega), hpr2 10 0 (by dsimp [mod]; omega), hDims.1]
          have hact_w : hRead wsi 23 (k : ℤ) = if act kFin then 1 else 0 := by
            rw [hpr_j 23 _ (by dsimp [modIn2]; omega), hpr_k 23 _ (by dsimp [mod2]; omega),
                hprL1 23 _ (by dsimp [mod1]; omega), hpr2 23 _ (by dsimp [mod]; omega)]
            exact hAct_ws kFin
          have hM_src : hRead wsi 21 ((k * nVars + j : ℕ) : ℤ) = M_le kFin jFin := by
            rw [hpr_j 21 _ (by dsimp [modIn2]; omega), hpr_k 21 _ (by dsimp [mod2]; omega),
                hprL1 21 _ (by dsimp [mod1]; omega), hpr2 21 _ (by dsimp [mod]; omega)]
            exact hCleared.2.2.1 kFin jFin
          let vCell : ℤ := if act kFin then M_le kFin jFin else 0
          have hvCell_abs : vCell.natAbs ≤ 2 ^ K := by
            dsimp [vCell]; cases act kFin <;> simp [hMleB kFin jFin]
          have hw_step := exec_write hctx hwsi 28
            (.add (.mul (.add (.readHeap 10 (.lit 1)) (.readHeap 10 (.lit 42))) (.readHeap 10 (.lit 28)))
                  (.readHeap 10 (.lit 43)))
            (.mul (.readHeap 23 (.readHeap 10 (.lit 42)))
                  (.readHeap 21 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 0))) (.readHeap 10 (.lit 43)))))
            ((r * w + j : ℕ) : ℤ) vCell
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hnE_w, hk_w, hw_w, hctr_j]
                exact_mod_cast (rfl : (nEq + k) * w + j = r * w + j))
            (by have hsrc : (k : ℤ) * (nVars : ℤ) + (j : ℤ) = ((k * nVars + j : ℕ) : ℤ) :=
                  by exact_mod_cast (rfl : k * nVars + j = k * nVars + j)
                simp only [evalVal_mul, evalVal_readHeap, evalVal_add, evalVal_lit, hk_w, hnV_w, hctr_j,
                  hact_w, hsrc, hM_src, vCell]
                cases act kFin <;> simp)
            (Nat.cast_nonneg _)
            (Nat.cast_le.mpr ((hrj_lt.le.trans hNext_le).trans hIdx.2.2.2.2.2.1))
            hvCell_abs
          refine ⟨_, hw_step, ?_,
            hpr_j.trans (PreservesOutside.write wsi _
              (Or.inr ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hrj_lt⟩)), ?_⟩
          · rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega))]; exact hctr_j
          · intro j' hj'
            rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
            · rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]; exact hprev_j j' hlt
            · have hj_eq : j' = jFin := Fin.ext heq
              subst hj_eq; exact hRead_hWrite_self wsi 28 _ _)
      have hk_end : hRead wsi_end 10 42 = (k : ℤ) := by
        rw [hprIn2 10 42 (by dsimp [modIn2]; omega), hctr_k]
      have hnE_end : hRead wsi_end 10 1 = (nEq : ℤ) := by
        rw [hprIn2 10 1 (by dsimp [modIn2]; omega), hpr_k 10 1 (by dsimp [mod2]; omega),
            hprL1 10 1 (by dsimp [mod1]; omega), hpr2 10 1 (by dsimp [mod]; omega), hDims.2.1]
      have hw_end : hRead wsi_end 10 28 = (w : ℤ) := by
        rw [hprIn2 10 28 (by dsimp [modIn2]; omega), hpr_k 10 28 (by dsimp [mod2]; omega),
            hprL1 10 28 (by dsimp [mod1]; omega), hw_ws2]
      have hnV_end : hRead wsi_end 10 0 = (nVars : ℤ) := by
        rw [hprIn2 10 0 (by dsimp [modIn2]; omega), hpr_k 10 0 (by dsimp [mod2]; omega),
            hprL1 10 0 (by dsimp [mod1]; omega), hpr2 10 0 (by dsimp [mod]; omega), hDims.1]
      have hact_end : hRead wsi_end 23 (k : ℤ) = if act kFin then 1 else 0 := by
        rw [hprIn2 23 _ (by dsimp [modIn2]; omega), hpr_k 23 _ (by dsimp [mod2]; omega),
            hprL1 23 _ (by dsimp [mod1]; omega), hpr2 23 _ (by dsimp [mod]; omega)]
        exact hAct_ws kFin
      have hd_src : hRead wsi_end 22 (k : ℤ) = d_le kFin := by
        rw [hprIn2 22 _ (by dsimp [modIn2]; omega), hpr_k 22 _ (by dsimp [mod2]; omega),
            hprL1 22 _ (by dsimp [mod1]; omega), hpr2 22 _ (by dsimp [mod]; omega)]
        exact hCleared.2.2.2 kFin
      let vRhs : ℤ := if act kFin then d_le kFin else 0
      have hvRhs_abs : vRhs.natAbs ≤ 2 ^ K := by
        dsimp [vRhs]; cases act kFin <;> simp [hdleB kFin]
      have hlast_lt : r * w + nVars < (r + 1) * w := by
        calc r * w + nVars < r * w + w := Nat.add_lt_add_left (by dsimp [w]; omega) _
          _ = (r + 1) * w := by ring
      have hw_rhs := exec_write hctx hexIn2.2.1 28
        (.add (.mul (.add (.readHeap 10 (.lit 1)) (.readHeap 10 (.lit 42))) (.readHeap 10 (.lit 28)))
              (.readHeap 10 (.lit 0)))
        (.mul (.readHeap 23 (.readHeap 10 (.lit 42))) (.readHeap 22 (.readHeap 10 (.lit 42))))
        ((r * w + nVars : ℕ) : ℤ) vRhs
        (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hnE_end, hk_end, hw_end, hnV_end]
            exact_mod_cast (rfl : (nEq + k) * w + nVars = r * w + nVars))
        (by simp only [evalVal_mul, evalVal_readHeap, evalVal_lit, hk_end, hact_end, hd_src, vRhs]
            cases act kFin <;> simp)
        (Nat.cast_nonneg _)
        (Nat.cast_le.mpr ((hlast_lt.le.trans hNext_le).trans hIdx.2.2.2.2.2.1))
        hvRhs_abs
      let ws_out := hWrite wsi_end 28 ((r * w + nVars : ℕ) : ℤ) vRhs
      have hpr_step : PreservesOutside mod2 ws3 ws_out :=
        (hpr_k.trans (hprIn2.mono (by
          intro t_id idx h; dsimp [modIn2] at h; dsimp [mod2]
          rcases h with ⟨rfl, rfl⟩ | ⟨rfl, hlo, hhi⟩
          · exact Or.inl ⟨rfl, Or.inr rfl⟩
          · exact Or.inr ⟨rfl, le_trans (Nat.cast_le.mpr hge_eq) hlo,
              lt_of_lt_of_le hhi (Nat.cast_le.mpr hNext_le)⟩))).trans
          (PreservesOutside.write wsi_end _ (Or.inr ⟨rfl,
            Nat.cast_le.mpr (hge_eq.trans (Nat.le_add_right _ _)),
            Nat.cast_lt.mpr (lt_of_lt_of_le hlast_lt hNext_le)⟩))
      refine ⟨ws_out, (hexIn2.seq_steps hw_rhs).mono_steps (by omega), ?_, hpr_step, ?_⟩
      · rw [hRead_hWrite_of_ne wsi_end _ (Or.inl (by omega))]; exact hk_end
      · intro k' hk' j'
        rcases (show k'.val < k ∨ k'.val = k by omega) with hlt | heq
        · have hlt_idx : (nEq + k'.val) * w + j'.val < r * w :=
            row_col_lt_mul (by dsimp [r]; omega) j'.isLt
          have hne_rhs : (((nEq + k'.val) * w + j'.val : ℕ) : ℤ) ≠ ((r * w + nVars : ℕ) : ℤ) :=
            ne_of_lt (Nat.cast_lt.mpr (lt_of_lt_of_le hlt_idx (Nat.le_add_right _ _)))
          rw [hRead_hWrite_of_ne wsi_end _ (Or.inr hne_rhs),
              hprIn2 28 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, hge, _⟩
                · exact absurd h (by decide)
                · exact absurd hge (not_le.mpr (Nat.cast_lt.mpr hlt_idx)))]
          exact hprev_k k' hlt j'
        · dsimp [st₀, bareissInit]
          rw [fin_lastCases_eq_dite]
          have hnot_lt : ¬ (nEq + k < nEq) := by omega
          have hk_sub : (⟨(nEq + k) - nEq, by omega⟩ : Fin nLe) = kFin := by ext; dsimp [kFin]; omega
          have hk_eq : k' = kFin := Fin.ext heq
          subst hk_eq
          by_cases hj : j'.val < nVars
          · rw [dif_pos hj]
            have hne_r : (((nEq + kFin.val) * w + j'.val : ℕ) : ℤ) ≠ ((r * w + nVars : ℕ) : ℤ) := by
              dsimp [r, kFin]; omega
            change hRead (hWrite wsi_end 28 ((r * w + nVars : ℕ) : ℤ) vRhs) 28
              (((nEq + kFin.val) * w + j'.val : ℕ) : ℤ) = _
            rw [hRead_hWrite_of_ne wsi_end _ (Or.inr hne_r)]
            dsimp [buildActiveEqM, kFin]
            rw [dif_neg hnot_lt, hk_sub]
            exact hCols2 ⟨j'.val, hj⟩ hj
          · have hj_eq : j'.val = nVars := by have := j'.isLt; dsimp [w] at this; omega
            rw [dif_neg hj]
            dsimp [buildActiveEqD, ws_out, kFin]
            rw [dif_neg hnot_lt, hk_sub, hj_eq]
            exact hRead_hWrite_self wsi_end 28 ((r * w + nVars : ℕ) : ℤ) vRhs)
  -- Combine Table 28 from Loop 1 + Loop 2
  have h28_ws4 : ∀ (r : Fin m_bar) (j : Fin w),
      hRead ws4 28 ((r.val * w + j.val : ℕ) : ℤ) = st₀.A r j := by
    intro r j
    by_cases hr : r.val < nEq
    · have hlt_eq : r.val * w + j.val < nEq * w := row_col_lt_mul hr j.isLt
      rw [hprL2 28 _ (fun h => by
            rcases h with ⟨h, _⟩ | ⟨_, hge, _⟩
            · exact absurd h (by decide)
            · exact absurd hge (not_le.mpr (Nat.cast_lt.mpr hlt_eq)))]
      exact hDone1 r hr j
    · let kFin : Fin nLe := ⟨r.val - nEq, by omega⟩
      have hr_eq : nEq + kFin.val = r.val := by dsimp [kFin]; omega
      have h2 := hDone2 kFin kFin.isLt j
      have hrFin_eq : (⟨nEq + kFin.val, by dsimp [m_bar]; omega⟩ : Fin m_bar) = r :=
        Fin.ext hr_eq
      simpa only [hr_eq, hrFin_eq] using h2
  have hpr4 : PreservesOutside mod ws₀ ws4 :=
    (hpr2.trans (hprL1.mono (by intro t idx h; dsimp [mod1] at h; dsimp [mod]; tauto))).trans
      (hprL2.mono (by intro t idx h; dsimp [mod2] at h; dsimp [mod]; tauto))
  -- Loop 3: 29[0 .. m_bar - 1] := 0
  let mod3 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨ (t_id = 29 ∧ 0 ≤ idx ∧ idx < (m_bar : ℤ))
  let P3 : ℕ → UL.WordStore → Prop := fun R ws =>
    ∀ r : Fin m_bar, r.val < R → hRead ws 29 (r.val : ℤ) = 0
  have hcnt3 : evalVal inp (hWrite ws4 10 42 0) (.readHeap 10 (.lit 5)) = (m_bar : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws4 0 (Or.inr (by omega)), hpr4 10 5 (by dsimp [mod]; omega), hDims.2.2.2.2.2]
  obtain ⟨ws5, hprL3, hDone3, hs5⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 5))
    (.writeHeap 29 (.readHeap 10 (.lit 42)) (.lit 0))
    m_bar 1 mod3 P3 hs4.2.1 (by omega) hIdx.2.2.2.2.1
    (by dsimp [mod3]; omega)
    (fun R ws v => by
      dsimp [P3]; constructor <;> intro h r hr
      · have := h r hr; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h r hr)
    hcnt3 (fun _ h => False.elim (Nat.not_lt_zero _ h))
    (fun r hr ws hws hctr_r hpr_r hprev_r => by
      have hw := exec_write hctx hws 29 (.readHeap 10 (.lit 42)) (.lit 0) (r : ℤ) 0
        (by simp [hctr_r]) rfl (Nat.cast_nonneg _) (by omega) (by simp)
      refine ⟨_, hw, ?_, hpr_r.trans (PreservesOutside.write ws _ (by dsimp [mod3]; omega)), ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega))]; exact hctr_r
      · intro r' hr'
        rcases (show r'.val < r ∨ r'.val = r by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]; exact hprev_r r' hlt
        · rw [heq]; exact hRead_hWrite_self ws 29 _ _)
  -- Loop 4: 29[m_bar .. m_bar + nVars - 1] := -1
  let mod4 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨ (t_id = 29 ∧ (m_bar : ℤ) ≤ idx)
  let P4 : ℕ → UL.WordStore → Prop := fun C ws =>
    ∀ j : Fin nVars, j.val < C → hRead ws 29 ((m_bar + j.val : ℕ) : ℤ) = -1
  have hpr5 : PreservesOutside mod ws₀ ws5 :=
    hpr4.trans (hprL3.mono (by intro t idx h; dsimp [mod3] at h; dsimp [mod]; tauto))
  have hcnt4 : evalVal inp (hWrite ws5 10 42 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws5 0 (Or.inr (by omega)), hpr5 10 0 (by dsimp [mod]; omega), hDims.1]
  obtain ⟨ws6, hprL4, hDone4, hs6⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 0))
    (.writeHeap 29 (.add (.readHeap 10 (.lit 5)) (.readHeap 10 (.lit 42))) (.lit (-1)))
    nVars 1 mod4 P4 hs5.2.1 (by omega) hIdx.1
    (by dsimp [mod4]; omega)
    (fun C ws v => by
      dsimp [P4]; constructor <;> intro h j hj
      · have := h j hj; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h j hj)
    hcnt4 (fun _ h => False.elim (Nat.not_lt_zero _ h))
    (fun j hj ws hws hctr_j hpr_j hprev_j => by
      have hm_w : hRead ws 10 5 = (m_bar : ℤ) := by
        rw [hpr_j 10 5 (by dsimp [mod4]; omega), hpr5 10 5 (by dsimp [mod]; omega), hDims.2.2.2.2.2]
      have hw := exec_write hctx hws 29
        (.add (.readHeap 10 (.lit 5)) (.readHeap 10 (.lit 42))) (.lit (-1))
        ((m_bar + j : ℕ) : ℤ) (-1)
        (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hm_w, hctr_j]
            exact_mod_cast (rfl : m_bar + j = m_bar + j))
        rfl (Nat.cast_nonneg _) (by omega) Nat.one_le_two_pow
      refine ⟨_, hw, ?_, hpr_j.trans (PreservesOutside.write ws _ (by dsimp [mod4]; omega)), ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega))]; exact hctr_j
      · intro j' hj'
        rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]; exact hprev_j j' hlt
        · rw [heq]; exact hRead_hWrite_self ws 29 _ _)
  have hpr6 : PreservesOutside mod ws₀ ws6 :=
    hpr5.trans (hprL4.mono (by intro t idx h; dsimp [mod4] at h; dsimp [mod]; tauto))
  refine ⟨ws6, hpr6, ⟨?_, ?_, ?_, ?_⟩,
    (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps (hs5.seq_steps hs6))))).mono_steps
      (by dsimp [m_bar]; nlinarith)⟩
  · rw [hprL4 10 30 (by dsimp [mod4]; omega), hprL3 10 30 (by dsimp [mod3]; omega),
        hprL2 10 30 (by dsimp [mod2]; omega), hprL1 10 30 (by dsimp [mod1]; omega), h30_ws2]
    rfl
  · intro r j
    rw [hprL4 28 _ (by dsimp [mod4]; omega), hprL3 28 _ (by dsimp [mod3]; omega)]
    exact h28_ws4 r j
  · intro r
    rw [hprL4 29 _ (by dsimp [mod4]; omega)]
    simpa [st₀, bareissInit] using hDone3 r r.isLt
  · intro j
    simpa [st₀, bareissInit] using hDone4 j j.isLt

/-! ### 3. `findPivotRowStmt`, `bareissUpdateMatrixStmt`, `bareissColStepStmt`, `bareissSolveStmt` -/

def findPivotRowStmt : UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let mBarE := UL.IntExpr.readHeap 10 (.lit 5)
  let wE := UL.IntExpr.readHeap 10 (.lit 28)
  let prE := UL.IntExpr.readHeap 10 (.lit 31)
  let cE := UL.IntExpr.readHeap 10 (.lit 41)
  let rE := UL.IntExpr.readHeap 10 (.lit 42)
  seqBitStmts
    [ .writeHeap 10 (.lit 28) (.add nVarsE (.lit 1))
    , .writeHeap 10 (.lit 31) (.lit (-1))
    , forLoopStmt 42 mBarE
        (.ite (.and (.and (.intEq prE (.lit (-1))) (.intEq (.readHeap 29 rE) (.lit 0)))
                    (.not (.intEq (.readHeap 28 (.add (.mul rE wE) cE)) (.lit 0))))
          (.writeHeap 10 (.lit 31) rE)
          .skip) ]

theorem exec_findPivotRowStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars + 1 ≤ maxIdx ∧ nEq + nLe ≤ maxIdx)
    (st : BareissState (nEq + nLe) nVars) (c : Fin nVars)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hc_ws : hRead ws₀ 10 41 = (c.val : ℤ))
    (hBar : BareissStateInHeap st ws₀) :
    let m_bar := nEq + nLe
    let mod : ℕ → ℤ → Prop := fun t_id idx => t_id = 10 ∧ (idx = 28 ∨ idx = 31 ∨ idx = 42)
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      hRead ws₁ 10 28 = ((nVars + 1 : ℕ) : ℤ) ∧
      hRead ws₁ 10 31 = findPivotRow st.A st.rowUsed c.castSucc ∧
      ExecBit inp maxIdx K findPivotRowStmt ws₀ ws₁
        ((4 + 3 * m_bar) * stepU) ((4 + 3 * m_bar) * stepB K) := by
  intro m_bar mod
  let w := nVars + 1
  have hw_abs : ((w : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
    simpa using hIdx.1.trans hctx.hMaxIdx
  have hs1 := exec_write hctx hws₀ 10 (.lit 28) (.add (.readHeap 10 (.lit 0)) (.lit 1))
    28 (w : ℤ) rfl
    (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hDims.1]
        exact_mod_cast (rfl : nVars + 1 = w))
    (by omega) (by omega) hw_abs
  let ws1 := hWrite ws₀ 10 28 (w : ℤ)
  have hs2 := exec_write hctx hs1.2.1 10 (.lit 31) (.lit (-1)) 31 (-1) rfl rfl
    (by omega) (by omega) Nat.one_le_two_pow
  let ws2 := hWrite ws1 10 31 (-1)
  have hpr2 : PreservesOutside mod ws₀ ws2 :=
    (PreservesOutside.write ws₀ _ (by dsimp [mod]; omega)).trans
      (PreservesOutside.write ws1 _ (by dsimp [mod]; omega))
  have hw_ws2 : hRead ws2 10 28 = (w : ℤ) := by
    rw [hRead_hWrite_of_ne ws1 _ (Or.inr (by omega)), hRead_hWrite_self]
  let step : ℤ → Fin m_bar → ℤ := fun found r =>
    if found == -1 && !st.rowUsed r && st.A r c.castSucc != 0 then (r.val : ℤ) else found
  let partFound : (k : ℕ) → k ≤ m_bar → ℤ := fun k hk =>
    Fin.foldl k (fun found (r : Fin k) => step found ⟨r.val, lt_of_lt_of_le r.isLt hk⟩) (-1)
  let modL : ℕ → ℤ → Prop := fun t_id idx => t_id = 10 ∧ (idx = 31 ∨ idx = 42)
  let PL : ℕ → UL.WordStore → Prop := fun k ws =>
    ∀ hk : k ≤ m_bar, hRead ws 10 31 = partFound k hk
  have hcnt : evalVal inp (hWrite ws2 10 42 0) (.readHeap 10 (.lit 5)) = (m_bar : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws2 0 (Or.inr (by omega)),
        hpr2 10 5 (by dsimp [mod]; omega), hDims.2.2.2.2.2]
  obtain ⟨ws3, hprL, hDone, hs3⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 5))
    (.ite (.and (.and (.intEq (.readHeap 10 (.lit 31)) (.lit (-1)))
                      (.intEq (.readHeap 29 (.readHeap 10 (.lit 42))) (.lit 0)))
                (.not (.intEq (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                  (.readHeap 10 (.lit 41)))) (.lit 0))))
      (.writeHeap 10 (.lit 31) (.readHeap 10 (.lit 42)))
      .skip)
    m_bar 2 modL PL hs2.2.1 (by omega) hIdx.2
    (by dsimp [modL]; omega)
    (fun k ws v => by
      dsimp [PL]; constructor <;> intro h hk
      · have := h hk; rwa [hRead_hWrite_of_ne ws v (Or.inr (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inr (by decide))]; exact h hk)
    hcnt
    (fun _ => by simp [partFound, Fin.foldl_zero, hRead_hWrite_self])
    (fun r hr ws hws hctr_r hpr_r hprev_r => by
      let rFin : Fin m_bar := ⟨r, hr⟩
      have hr_le : r ≤ m_bar := hr.le
      have h31_w : hRead ws 10 31 = partFound r hr_le := hprev_r hr_le
      have hw_w : hRead ws 10 28 = (w : ℤ) := by
        rw [hpr_r 10 28 (by dsimp [modL]; omega), hw_ws2]
      have hc_w : hRead ws 10 41 = (c.val : ℤ) := by
        rw [hpr_r 10 41 (by dsimp [modL]; omega), hpr2 10 41 (by dsimp [mod]; omega), hc_ws]
      have hru_w : hRead ws 29 (r : ℤ) = if st.rowUsed rFin then 1 else 0 := by
        rw [hpr_r 29 _ (by dsimp [modL]; omega), hpr2 29 _ (by dsimp [mod]; omega)]
        exact hBar.2.2.1 rFin
      have hrc_eq : (r : ℤ) * (w : ℤ) + (c.val : ℤ) = ((r * w + c.val : ℕ) : ℤ) :=
        by exact_mod_cast (rfl : r * w + c.val = r * w + c.val)
      have hArc_w : hRead ws 28 ((r * w + c.val : ℕ) : ℤ) = st.A rFin c.castSucc := by
        rw [hpr_r 28 _ (by dsimp [modL]; omega), hpr2 28 _ (by dsimp [mod]; omega)]
        exact hBar.2.1 rFin c.castSucc
      let bCond : Bool := (partFound r hr_le == -1 && !st.rowUsed rFin && st.A rFin c.castSucc != 0)
      have hcond_ev : evalCondVal inp ws
          (.and (.and (.intEq (.readHeap 10 (.lit 31)) (.lit (-1)))
                      (.intEq (.readHeap 29 (.readHeap 10 (.lit 42))) (.lit 0)))
                (.not (.intEq (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                  (.readHeap 10 (.lit 41)))) (.lit 0)))) = bCond := by
        simp only [evalCondVal_and, evalCondVal_not, evalCondVal_intEq,
          evalVal_readHeap, evalVal_add, evalVal_mul, evalVal_lit,
          h31_w, hctr_r, hru_w, hw_w, hc_w, hrc_eq, hArc_w]
        dsimp [bCond]
        have h1 : decide (partFound r hr_le = -1) = (partFound r hr_le == -1) := by
          apply Bool.eq_iff_iff.mpr; simp [beq_iff_eq]
        have h2 : decide ((if st.rowUsed rFin then (1 : ℤ) else 0) = 0) = !st.rowUsed rFin := by
          cases st.rowUsed rFin <;> decide
        have h3 : (!decide (st.A rFin c.castSucc = 0)) = (st.A rFin c.castSucc != 0) := by
          by_cases hz : st.A rFin c.castSucc = 0 <;> simp [hz]
        rw [h1, h2, h3]
      have hfold_succ : ∀ hk1 : r + 1 ≤ m_bar,
          partFound (r + 1) hk1 = step (partFound r hr_le) rFin := by
        intro hk1; dsimp [partFound]; rw [Fin.foldl_succ_last]; rfl
      cases hb : bCond
      · have hex_br := exec_ite_false hctx
          (.and (.and (.intEq (.readHeap 10 (.lit 31)) (.lit (-1)))
                      (.intEq (.readHeap 29 (.readHeap 10 (.lit 42))) (.lit 0)))
                (.not (.intEq (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                  (.readHeap 10 (.lit 41)))) (.lit 0))))
          (.writeHeap 10 (.lit 31) (.readHeap 10 (.lit 42))) .skip
          (hcond_ev.trans hb) (exec_skip hctx hws)
        refine ⟨ws, hex_br, hctr_r, hpr_r, fun hk1 => ?_⟩
        rw [hfold_succ hk1, h31_w]
        dsimp [step]
        rw [show (partFound r hr_le == -1 && !st.rowUsed rFin && st.A rFin c.castSucc != 0) = false from hb]
        simp
      · have hr_abs : (r : ℤ).natAbs ≤ 2 ^ K := by
          have : r ≤ maxIdx := hr.le.trans hIdx.2
          simpa using this.trans hctx.hMaxIdx
        have hw_t := exec_write hctx hws 10 (.lit 31) (.readHeap 10 (.lit 42))
          31 (r : ℤ) rfl (by simp [hctr_r]) (by omega) (by omega) hr_abs
        have hex_br := exec_ite_true hctx
          (.and (.and (.intEq (.readHeap 10 (.lit 31)) (.lit (-1)))
                      (.intEq (.readHeap 29 (.readHeap 10 (.lit 42))) (.lit 0)))
                (.not (.intEq (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                  (.readHeap 10 (.lit 41)))) (.lit 0))))
          (.writeHeap 10 (.lit 31) (.readHeap 10 (.lit 42))) .skip
          (hcond_ev.trans hb) hw_t
        refine ⟨hWrite ws 10 31 (r : ℤ), hex_br, ?_,
          hpr_r.trans (PreservesOutside.write ws _ (by dsimp [modL]; omega)), fun hk1 => ?_⟩
        · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]; exact hctr_r
        · rw [hfold_succ hk1, hRead_hWrite_self]
          dsimp [step]
          rw [show (partFound r hr_le == -1 && !st.rowUsed rFin && st.A rFin c.castSucc != 0) = true from hb]
          simp [rFin])
  refine ⟨ws3, hpr2.trans (hprL.mono (by intro t i h; dsimp [modL] at h; dsimp [mod]; omega)),
    by rw [hprL 10 28 (by dsimp [modL]; omega), hw_ws2],
    hDone le_rfl,
    (hs1.seq_steps (hs2.seq_steps hs3)).mono_steps (by omega)⟩

def bareissUpdateMatrixStmt : UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let mBarE := UL.IntExpr.readHeap 10 (.lit 5)
  let wE := UL.IntExpr.readHeap 10 (.lit 28)
  let offE := UL.IntExpr.readHeap 10 (.lit 29)
  let prevPivE := UL.IntExpr.readHeap 10 (.lit 30)
  let prE := UL.IntExpr.readHeap 10 (.lit 31)
  let pivE := UL.IntExpr.readHeap 10 (.lit 32)
  let cE := UL.IntExpr.readHeap 10 (.lit 41)
  let rE := UL.IntExpr.readHeap 10 (.lit 42)
  let jE := UL.IntExpr.readHeap 10 (.lit 43)
  let dstE := UL.IntExpr.add offE jE
  let r0jE := UL.IntExpr.add (.mul prE wE) jE
  let rjE := UL.IntExpr.add (.mul rE wE) jE
  let rcE := UL.IntExpr.add (.mul rE wE) cE
  seqBitStmts
    [ .writeHeap 10 (.lit 28) (.add nVarsE (.lit 1))
    , forLoopStmt 42 mBarE
        (seqBitStmts
          [ .writeHeap 10 (.lit 29) (.add (.mul mBarE wE) (.mul rE wE))
          , forLoopStmt 43 wE
              (.ite (.intEq rE prE)
                (.writeHeap 28 dstE (.readHeap 28 r0jE))
                (.writeHeap 28 dstE
                  (.div (.sub (.mul pivE (.readHeap 28 rjE))
                              (.mul (.readHeap 28 rcE) (.readHeap 28 r0jE)))
                        prevPivE))) ])
    , forLoopStmt 42 mBarE
        (seqBitStmts
          [ .writeHeap 10 (.lit 29) (.add (.mul mBarE wE) (.mul rE wE))
          , forLoopStmt 43 wE
              (.writeHeap 28 rjE (.readHeap 28 dstE)) ]) ]

theorem exec_bareissUpdateMatrixStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars + 1 ≤ maxIdx ∧ nEq + nLe ≤ maxIdx ∧
            2 * ((nEq + nLe) * (nVars + 1)) ≤ maxIdx)
    (st : BareissState (nEq + nLe) nVars) (c : Fin nVars) (r₀ : Fin (nEq + nLe))
    {A_new : Fin (nEq + nLe) → Fin (nVars + 1) → ℤ}
    (hForm : ∀ (i : Fin (nEq + nLe)) (j : Fin (nVars + 1)),
      A_new i j = if i = r₀ then st.A r₀ j
                  else (st.A r₀ c.castSucc * st.A i j - st.A i c.castSucc * st.A r₀ j) / st.prevPiv)
    (hNewB : ∀ i j, (A_new i j).natAbs ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hc_ws : hRead ws₀ 10 41 = (c.val : ℤ))
    (hr0_ws : hRead ws₀ 10 31 = (r₀.val : ℤ))
    (hpiv_ws : hRead ws₀ 10 32 = st.A r₀ c.castSucc)
    (hBar : BareissStateInHeap st ws₀) :
    let m_bar := nEq + nLe
    let w := nVars + 1
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (idx = 28 ∨ idx = 29 ∨ idx = 42 ∨ idx = 43)) ∨ t_id = 28
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ (i : Fin m_bar) (j : Fin w),
        hRead ws₁ 28 ((i.val * w + j.val : ℕ) : ℤ) = A_new i j) ∧
      ExecBit inp maxIdx K bareissUpdateMatrixStmt ws₀ ws₁
        ((5 + m_bar * (8 + 5 * w)) * stepU) ((5 + m_bar * (8 + 5 * w)) * stepB K) := by
  intro m_bar w mod
  have hMW_le : m_bar * w ≤ maxIdx :=
    (Nat.le_mul_of_pos_left _ (by omega : 0 < 2)).trans hIdx.2.2
  have hw_abs : ((w : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
    simpa using hIdx.1.trans hctx.hMaxIdx
  have hs0 := exec_write hctx hws₀ 10 (.lit 28) (.add (.readHeap 10 (.lit 0)) (.lit 1))
    28 (w : ℤ) rfl
    (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hDims.1]
        exact_mod_cast (rfl : nVars + 1 = w))
    (by omega) (by omega) hw_abs
  let ws1 := hWrite ws₀ 10 28 (w : ℤ)
  have hpr1 : PreservesOutside mod ws₀ ws1 :=
    PreservesOutside.write ws₀ _ (by dsimp [mod]; omega)
  have hw_ws1 : hRead ws1 10 28 = (w : ℤ) := hRead_hWrite_self ws₀ 10 28 (w : ℤ)
  -- Phase 1: write A_new into 28[m_bar * w .. 2 * (m_bar * w) - 1]
  let modA1 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 29 ∨ idx = 42 ∨ idx = 43)) ∨
    (t_id = 28 ∧ ((m_bar * w : ℕ) : ℤ) ≤ idx ∧ idx < ((2 * (m_bar * w) : ℕ) : ℤ))
  let PA1 : ℕ → UL.WordStore → Prop := fun R ws =>
    ∀ (i : Fin m_bar) (j : Fin w), i.val < R →
      hRead ws 28 ((m_bar * w + (i.val * w + j.val) : ℕ) : ℤ) = A_new i j
  have hcntA1 : evalVal inp (hWrite ws1 10 42 0) (.readHeap 10 (.lit 5)) = (m_bar : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws1 0 (Or.inr (by omega)), hpr1 10 5 (by dsimp [mod]; omega), hDims.2.2.2.2.2]
  obtain ⟨ws2, hprA1, hA1_done, hs1⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 5))
    (seqBitStmts
      [ .writeHeap 10 (.lit 29)
          (.add (.mul (.readHeap 10 (.lit 5)) (.readHeap 10 (.lit 28)))
                (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))))
      , forLoopStmt 43 (.readHeap 10 (.lit 28))
          (.ite (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 31)))
            (.writeHeap 28 (.add (.readHeap 10 (.lit 29)) (.readHeap 10 (.lit 43)))
              (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 31)) (.readHeap 10 (.lit 28)))
                (.readHeap 10 (.lit 43)))))
            (.writeHeap 28 (.add (.readHeap 10 (.lit 29)) (.readHeap 10 (.lit 43)))
              (.div (.sub (.mul (.readHeap 10 (.lit 32))
                                (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                                  (.readHeap 10 (.lit 43)))))
                          (.mul (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                                  (.readHeap 10 (.lit 41))))
                                (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 31)) (.readHeap 10 (.lit 28)))
                                  (.readHeap 10 (.lit 43))))))
                    (.readHeap 10 (.lit 30))))) ])
    m_bar (3 + 3 * w) modA1 PA1 hs0.2.1 (by omega) hIdx.2.1
    (by dsimp [modA1]; omega)
    (fun R ws v => by
      dsimp [PA1]; constructor <;> intro h i j hi
      · have := h i j hi; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h i j hi)
    hcntA1 (fun _ _ h => False.elim (Nat.not_lt_zero _ h))
    (fun i hi ws hws hctr_i hpr_i hprev_i => by
      let iFin : Fin m_bar := ⟨i, hi⟩
      have hNext_le_MW : (i + 1) * w ≤ m_bar * w := Nat.mul_le_mul_right w hi
      have hoff_le_max : m_bar * w + i * w ≤ maxIdx := by
        have h1 : i * w ≤ m_bar * w := (Nat.mul_le_mul_right w (Nat.le_succ i)).trans hNext_le_MW
        have h2 : m_bar * w + i * w ≤ 2 * (m_bar * w) := by
          calc m_bar * w + i * w ≤ m_bar * w + m_bar * w := Nat.add_le_add_left h1 _
            _ = 2 * (m_bar * w) := (two_mul _).symm
        exact h2.trans hIdx.2.2
      have hoff_abs : ((m_bar * w + i * w : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
        simpa using hoff_le_max.trans hctx.hMaxIdx
      have hm_w0 : hRead ws 10 5 = (m_bar : ℤ) := by
        rw [hpr_i 10 5 (by dsimp [modA1]; omega), hpr1 10 5 (by dsimp [mod]; omega), hDims.2.2.2.2.2]
      have hw_w0 : hRead ws 10 28 = (w : ℤ) := by
        rw [hpr_i 10 28 (by dsimp [modA1]; omega), hw_ws1]
      have hw_off := exec_write hctx hws 10 (.lit 29)
        (.add (.mul (.readHeap 10 (.lit 5)) (.readHeap 10 (.lit 28)))
              (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))))
        29 ((m_bar * w + i * w : ℕ) : ℤ) rfl
        (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hm_w0, hw_w0, hctr_i]
            exact_mod_cast (rfl : m_bar * w + i * w = m_bar * w + i * w))
        (by omega) (by omega) hoff_abs
      let wso := hWrite ws 10 29 ((m_bar * w + i * w : ℕ) : ℤ)
      let modIn1 : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 43) ∨
        (t_id = 28 ∧ ((m_bar * w + i * w : ℕ) : ℤ) ≤ idx ∧ idx < ((m_bar * w + (i + 1) * w : ℕ) : ℤ))
      let PIn1 : ℕ → UL.WordStore → Prop := fun col wsi =>
        ∀ j : Fin w, j.val < col →
          hRead wsi 28 ((m_bar * w + (i * w + j.val) : ℕ) : ℤ) = A_new iFin j
      have hcntIn1 : evalVal inp (hWrite wso 10 43 0) (.readHeap 10 (.lit 28)) = (w : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne wso 0 (Or.inr (by omega)),
            hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hw_w0]
      obtain ⟨ws_in, hprIn1, hRow_done, hexIn1⟩ := exec_for_frame hctx 43 (.readHeap 10 (.lit 28))
        (.ite (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 31)))
          (.writeHeap 28 (.add (.readHeap 10 (.lit 29)) (.readHeap 10 (.lit 43)))
            (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 31)) (.readHeap 10 (.lit 28)))
              (.readHeap 10 (.lit 43)))))
          (.writeHeap 28 (.add (.readHeap 10 (.lit 29)) (.readHeap 10 (.lit 43)))
            (.div (.sub (.mul (.readHeap 10 (.lit 32))
                              (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                                (.readHeap 10 (.lit 43)))))
                        (.mul (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                                (.readHeap 10 (.lit 41))))
                              (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 31)) (.readHeap 10 (.lit 28)))
                                (.readHeap 10 (.lit 43))))))
                  (.readHeap 10 (.lit 30)))))
        w 2 modIn1 PIn1 hw_off.2.1 (by omega) hIdx.1
        (by dsimp [modIn1]; omega)
        (fun col wsi v => by
          dsimp [PIn1]; constructor <;> intro h j hj
          · have := h j hj; rwa [hRead_hWrite_of_ne wsi v (Or.inl (by decide))] at this
          · rw [hRead_hWrite_of_ne wsi v (Or.inl (by decide))]; exact h j hj)
        hcntIn1 (fun _ h => False.elim (Nat.not_lt_zero _ h))
        (fun j hj wsi hwsi hctr_j hpr_j hprev_j => by
          let jFin : Fin w := ⟨j, hj⟩
          have hij_lt_next : i * w + j < (i + 1) * w := by
            calc i * w + j < i * w + w := Nat.add_lt_add_left hj _
              _ = (i + 1) * w := by ring
          have hdst_le_max : m_bar * w + (i * w + j) ≤ maxIdx := by
            have h1 : m_bar * w + (i * w + j) ≤ m_bar * w + m_bar * w :=
              Nat.add_le_add_left (hij_lt_next.le.trans hNext_le_MW) _
            exact (h1.trans_eq (two_mul _).symm).trans hIdx.2.2
          have read28_ws : ∀ (r' : Fin m_bar) (c' : Fin w),
              hRead wsi 28 ((r'.val * w + c'.val : ℕ) : ℤ) = st.A r' c' := by
            intro r' c'
            have hlt_m : ((r'.val * w + c'.val : ℕ) : ℤ) < ((m_bar * w : ℕ) : ℤ) :=
              Nat.cast_lt.mpr (row_col_lt_mul r'.isLt c'.isLt)
            have hlt_o : ((r'.val * w + c'.val : ℕ) : ℤ) < ((m_bar * w + i * w : ℕ) : ℤ) :=
              lt_of_lt_of_le hlt_m (Nat.cast_le.mpr (Nat.le_add_right _ _))
            rw [hpr_j 28 _ (fun h => by
                  rcases h with ⟨h, _⟩ | ⟨_, hge, _⟩
                  · exact absurd h (by decide)
                  · exact absurd hge (not_le.mpr hlt_o)),
                hRead_hWrite_of_ne ws _ (Or.inl (by omega)),
                hpr_i 28 _ (fun h => by
                  rcases h with ⟨h, _⟩ | ⟨_, hge, _⟩
                  · exact absurd h (by decide)
                  · exact absurd hge (not_le.mpr hlt_m)),
                hRead_hWrite_of_ne ws₀ _ (Or.inl (by decide))]
            exact hBar.2.1 r' c'
          have hw_w : hRead wsi 10 28 = (w : ℤ) := by
            rw [hpr_j 10 28 (by dsimp [modIn1]; omega),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hw_w0]
          have hoff_w : hRead wsi 10 29 = ((m_bar * w + i * w : ℕ) : ℤ) := by
            rw [hpr_j 10 29 (by dsimp [modIn1]; omega)]; exact hRead_hWrite_self ws 10 29 _
          have h30_w : hRead wsi 10 30 = st.prevPiv := by
            rw [hpr_j 10 30 (by dsimp [modIn1]; omega),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
                hpr_i 10 30 (by dsimp [modA1]; omega),
                hpr1 10 30 (by dsimp [mod]; omega), hBar.1]
          have h31_w : hRead wsi 10 31 = (r₀.val : ℤ) := by
            rw [hpr_j 10 31 (by dsimp [modIn1]; omega),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
                hpr_i 10 31 (by dsimp [modA1]; omega),
                hpr1 10 31 (by dsimp [mod]; omega), hr0_ws]
          have h32_w : hRead wsi 10 32 = st.A r₀ c.castSucc := by
            rw [hpr_j 10 32 (by dsimp [modIn1]; omega),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
                hpr_i 10 32 (by dsimp [modA1]; omega),
                hpr1 10 32 (by dsimp [mod]; omega), hpiv_ws]
          have h41_w : hRead wsi 10 41 = (c.val : ℤ) := by
            rw [hpr_j 10 41 (by dsimp [modIn1]; omega),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
                hpr_i 10 41 (by dsimp [modA1]; omega),
                hpr1 10 41 (by dsimp [mod]; omega), hc_ws]
          have h42_w : hRead wsi 10 42 = (i : ℤ) := by
            rw [hpr_j 10 42 (by dsimp [modIn1]; omega),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hctr_i]
          have hdst_eq : ((m_bar * w + i * w : ℕ) : ℤ) + (j : ℤ) =
              ((m_bar * w + (i * w + j) : ℕ) : ℤ) :=
            by exact_mod_cast (by ring : (m_bar * w + i * w) + j = m_bar * w + (i * w + j))
          have hr0j_eq : (r₀.val : ℤ) * (w : ℤ) + (j : ℤ) = ((r₀.val * w + j : ℕ) : ℤ) :=
            by exact_mod_cast (rfl : r₀.val * w + j = r₀.val * w + j)
          have hij_eq : (i : ℤ) * (w : ℤ) + (j : ℤ) = ((i * w + j : ℕ) : ℤ) :=
            by exact_mod_cast (rfl : i * w + j = i * w + j)
          have hic_eq : (i : ℤ) * (w : ℤ) + (c.val : ℤ) = ((i * w + c.val : ℕ) : ℤ) :=
            by exact_mod_cast (rfl : i * w + c.val = i * w + c.val)
          have hread_r0j : hRead wsi 28 ((r₀.val * w + j : ℕ) : ℤ) = st.A r₀ jFin :=
            read28_ws r₀ jFin
          have hread_ij : hRead wsi 28 ((i * w + j : ℕ) : ℤ) = st.A iFin jFin :=
            read28_ws iFin jFin
          have hread_ic : hRead wsi 28 ((i * w + c.val : ℕ) : ℤ) = st.A iFin c.castSucc :=
            read28_ws iFin c.castSucc
          have hdst_in_mod : modIn1 28 ((m_bar * w + (i * w + j) : ℕ) : ℤ) :=
            Or.inr ⟨rfl, Nat.cast_le.mpr (by omega),
              Nat.cast_lt.mpr (Nat.add_lt_add_left hij_lt_next _)⟩
          by_cases hir0 : iFin = r₀
          · have hir0_val : (i : ℤ) = (r₀.val : ℤ) := by rw [← hir0]
            have hcond_t : evalCondVal inp wsi (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 31))) = true := by
              simp only [evalCondVal_intEq, evalVal_readHeap, evalVal_lit, h42_w, h31_w, hir0_val, decide_true]
            have hval_t : A_new iFin jFin = st.A r₀ jFin := by rw [hForm iFin jFin, if_pos hir0]
            have hw_t := exec_write hctx hwsi 28
              (.add (.readHeap 10 (.lit 29)) (.readHeap 10 (.lit 43)))
              (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 31)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 43))))
              ((m_bar * w + (i * w + j) : ℕ) : ℤ) (A_new iFin jFin)
              (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hoff_w, hctr_j, hdst_eq])
              (by simp only [evalVal_readHeap, evalVal_add, evalVal_mul, evalVal_lit,
                    h31_w, hw_w, hctr_j, hr0j_eq, hread_r0j, hval_t])
              (Nat.cast_nonneg _) (Nat.cast_le.mpr hdst_le_max) (hNewB iFin jFin)
            refine ⟨_, exec_ite_true hctx _ _ _ hcond_t hw_t, ?_,
              hpr_j.trans (PreservesOutside.write wsi _ hdst_in_mod), ?_⟩
            · rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega))]; exact hctr_j
            · intro j' hj'
              rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
              · rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]; exact hprev_j j' hlt
              · have hj_eq : j' = jFin := Fin.ext heq
                subst hj_eq; exact hRead_hWrite_self wsi 28 _ _
          · have hir0_ne : (i : ℤ) ≠ (r₀.val : ℤ) := fun h => hir0 (Fin.ext (Int.ofNat.inj h))
            have hcond_f : evalCondVal inp wsi (.intEq (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 31))) = false := by
              simp only [evalCondVal_intEq, evalVal_readHeap, evalVal_lit, h42_w, h31_w,
                decide_eq_false hir0_ne]
            have hval_f : A_new iFin jFin =
                (st.A r₀ c.castSucc * st.A iFin jFin - st.A iFin c.castSucc * st.A r₀ jFin) / st.prevPiv := by
              rw [hForm iFin jFin, if_neg hir0]
            have hw_f := exec_write hctx hwsi 28
              (.add (.readHeap 10 (.lit 29)) (.readHeap 10 (.lit 43)))
              (.div (.sub (.mul (.readHeap 10 (.lit 32))
                                (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                                  (.readHeap 10 (.lit 43)))))
                          (.mul (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28)))
                                  (.readHeap 10 (.lit 41))))
                                (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 31)) (.readHeap 10 (.lit 28)))
                                  (.readHeap 10 (.lit 43))))))
                    (.readHeap 10 (.lit 30)))
              ((m_bar * w + (i * w + j) : ℕ) : ℤ) (A_new iFin jFin)
              (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hoff_w, hctr_j, hdst_eq])
              (by simp only [evalVal_div, evalVal_sub, evalVal_mul, evalVal_readHeap, evalVal_add, evalVal_lit,
                    h32_w, h42_w, hw_w, hctr_j, h41_w, h31_w, h30_w,
                    hij_eq, hic_eq, hr0j_eq, hread_ij, hread_ic, hread_r0j, hval_f])
              (Nat.cast_nonneg _) (Nat.cast_le.mpr hdst_le_max) (hNewB iFin jFin)
            refine ⟨_, exec_ite_false hctx _ _ _ hcond_f hw_f, ?_,
              hpr_j.trans (PreservesOutside.write wsi _ hdst_in_mod), ?_⟩
            · rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega))]; exact hctr_j
            · intro j' hj'
              rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
              · rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]; exact hprev_j j' hlt
              · have hj_eq : j' = jFin := Fin.ext heq
                subst hj_eq; exact hRead_hWrite_self wsi 28 _ _)
      have h2MW : m_bar * w + (i + 1) * w ≤ 2 * (m_bar * w) := by
        calc m_bar * w + (i + 1) * w ≤ m_bar * w + m_bar * w := Nat.add_le_add_left hNext_le_MW _
          _ = 2 * (m_bar * w) := (two_mul _).symm
      have hpr_row : PreservesOutside modA1 ws1 ws_in :=
        (hpr_i.trans (PreservesOutside.write ws _ (by dsimp [modA1]; omega))).trans
          (hprIn1.mono (by
            intro t_id idx h; dsimp [modIn1] at h; dsimp [modA1]
            rcases h with ⟨rfl, rfl⟩ | ⟨rfl, hlo, hhi⟩
            · exact Or.inl ⟨rfl, by omega⟩
            · exact Or.inr ⟨rfl, le_trans (Nat.cast_le.mpr (Nat.le_add_right _ _)) hlo,
                lt_of_lt_of_le hhi (Nat.cast_le.mpr h2MW)⟩))
      refine ⟨ws_in, (hw_off.seq_steps hexIn1).mono_steps (by omega), ?_, hpr_row, ?_⟩
      · rw [hprIn1 10 42 (by dsimp [modIn1]; omega),
            hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hctr_i]
      · intro i' j' hi'
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · have hlt_i : i'.val * w + j'.val < i * w := row_col_lt_mul hlt j'.isLt
          have hlt_o : ((m_bar * w + (i'.val * w + j'.val) : ℕ) : ℤ) < ((m_bar * w + i * w : ℕ) : ℤ) :=
            Nat.cast_lt.mpr (Nat.add_lt_add_left hlt_i _)
          rw [hprIn1 28 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, hge, _⟩
                · exact absurd h (by decide)
                · exact absurd hge (not_le.mpr hlt_o)),
              hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
          exact hprev_i i' j' hlt
        · have hi_eq : i' = iFin := Fin.ext heq
          subst hi_eq; exact hRow_done j' j'.isLt)
  -- Phase 2: copy 28[m_bar * w .. 2 * (m_bar * w) - 1] back to 28[0 .. m_bar * w - 1]
  let modA2 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 29 ∨ idx = 42 ∨ idx = 43)) ∨
    (t_id = 28 ∧ 0 ≤ idx ∧ idx < ((m_bar * w : ℕ) : ℤ))
  let PA2 : ℕ → UL.WordStore → Prop := fun R ws =>
    ∀ (i : Fin m_bar) (j : Fin w), i.val < R →
      hRead ws 28 ((i.val * w + j.val : ℕ) : ℤ) = A_new i j
  have hcntA2 : evalVal inp (hWrite ws2 10 42 0) (.readHeap 10 (.lit 5)) = (m_bar : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws2 0 (Or.inr (by omega)),
        hprA1 10 5 (by dsimp [modA1]; omega), hpr1 10 5 (by dsimp [mod]; omega), hDims.2.2.2.2.2]
  obtain ⟨ws3, hprA2, hA2_done, hs2⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 5))
    (seqBitStmts
      [ .writeHeap 10 (.lit 29)
          (.add (.mul (.readHeap 10 (.lit 5)) (.readHeap 10 (.lit 28)))
                (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))))
      , forLoopStmt 43 (.readHeap 10 (.lit 28))
          (.writeHeap 28
            (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 43)))
            (.readHeap 28 (.add (.readHeap 10 (.lit 29)) (.readHeap 10 (.lit 43))))) ])
    m_bar (3 + 2 * w) modA2 PA2 hs1.2.1 (by omega) hIdx.2.1
    (by dsimp [modA2]; omega)
    (fun R ws v => by
      dsimp [PA2]; constructor <;> intro h i j hi
      · have := h i j hi; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h i j hi)
    hcntA2 (fun _ _ h => False.elim (Nat.not_lt_zero _ h))
    (fun i hi ws hws hctr_i hpr_i hprev_i => by
      let iFin : Fin m_bar := ⟨i, hi⟩
      have hNext_le_MW : (i + 1) * w ≤ m_bar * w := Nat.mul_le_mul_right w hi
      have hoff_le_max : m_bar * w + i * w ≤ maxIdx := by
        have h1 : i * w ≤ m_bar * w := (Nat.mul_le_mul_right w (Nat.le_succ i)).trans hNext_le_MW
        have h2 : m_bar * w + i * w ≤ 2 * (m_bar * w) := by
          calc m_bar * w + i * w ≤ m_bar * w + m_bar * w := Nat.add_le_add_left h1 _
            _ = 2 * (m_bar * w) := (two_mul _).symm
        exact h2.trans hIdx.2.2
      have hoff_abs : ((m_bar * w + i * w : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
        simpa using hoff_le_max.trans hctx.hMaxIdx
      have hm_w0 : hRead ws 10 5 = (m_bar : ℤ) := by
        rw [hpr_i 10 5 (by dsimp [modA2]; omega), hprA1 10 5 (by dsimp [modA1]; omega),
            hpr1 10 5 (by dsimp [mod]; omega), hDims.2.2.2.2.2]
      have hw_w0 : hRead ws 10 28 = (w : ℤ) := by
        rw [hpr_i 10 28 (by dsimp [modA2]; omega), hprA1 10 28 (by dsimp [modA1]; omega), hw_ws1]
      have hw_off := exec_write hctx hws 10 (.lit 29)
        (.add (.mul (.readHeap 10 (.lit 5)) (.readHeap 10 (.lit 28)))
              (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))))
        29 ((m_bar * w + i * w : ℕ) : ℤ) rfl
        (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hm_w0, hw_w0, hctr_i]
            exact_mod_cast (rfl : m_bar * w + i * w = m_bar * w + i * w))
        (by omega) (by omega) hoff_abs
      let wso := hWrite ws 10 29 ((m_bar * w + i * w : ℕ) : ℤ)
      let modIn2 : ℕ → ℤ → Prop := fun t_id idx =>
        (t_id = 10 ∧ idx = 43) ∨
        (t_id = 28 ∧ ((i * w : ℕ) : ℤ) ≤ idx ∧ idx < (((i + 1) * w : ℕ) : ℤ))
      let PIn2 : ℕ → UL.WordStore → Prop := fun col wsi =>
        ∀ j : Fin w, j.val < col →
          hRead wsi 28 ((i * w + j.val : ℕ) : ℤ) = A_new iFin j
      have hcntIn2 : evalVal inp (hWrite wso 10 43 0) (.readHeap 10 (.lit 28)) = (w : ℤ) := by
        simp only [evalVal_readHeap, evalVal_lit]
        rw [hRead_hWrite_of_ne wso 0 (Or.inr (by omega)),
            hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hw_w0]
      obtain ⟨ws_in, hprIn2, hRow2_done, hexIn2⟩ := exec_for_frame hctx 43 (.readHeap 10 (.lit 28))
        (.writeHeap 28
          (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 43)))
          (.readHeap 28 (.add (.readHeap 10 (.lit 29)) (.readHeap 10 (.lit 43)))))
        w 1 modIn2 PIn2 hw_off.2.1 (by omega) hIdx.1
        (by dsimp [modIn2]; omega)
        (fun col wsi v => by
          dsimp [PIn2]; constructor <;> intro h j hj
          · have := h j hj; rwa [hRead_hWrite_of_ne wsi v (Or.inl (by decide))] at this
          · rw [hRead_hWrite_of_ne wsi v (Or.inl (by decide))]; exact h j hj)
        hcntIn2 (fun _ h => False.elim (Nat.not_lt_zero _ h))
        (fun j hj wsi hwsi hctr_j hpr_j hprev_j => by
          let jFin : Fin w := ⟨j, hj⟩
          have hij_lt_next : i * w + j < (i + 1) * w := by
            calc i * w + j < i * w + w := Nat.add_lt_add_left hj _
              _ = (i + 1) * w := by ring
          have hw_w : hRead wsi 10 28 = (w : ℤ) := by
            rw [hpr_j 10 28 (by dsimp [modIn2]; omega),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hw_w0]
          have hoff_w : hRead wsi 10 29 = ((m_bar * w + i * w : ℕ) : ℤ) := by
            rw [hpr_j 10 29 (by dsimp [modIn2]; omega)]; exact hRead_hWrite_self ws 10 29 _
          have hi_w : hRead wsi 10 42 = (i : ℤ) := by
            rw [hpr_j 10 42 (by dsimp [modIn2]; omega),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hctr_i]
          have hge_src : (((i + 1) * w : ℕ) : ℤ) ≤ ((m_bar * w + (i * w + j) : ℕ) : ℤ) :=
            Nat.cast_le.mpr (hNext_le_MW.trans (Nat.le_add_right _ _))
          have hge_mw : ((m_bar * w : ℕ) : ℤ) ≤ ((m_bar * w + (i * w + j) : ℕ) : ℤ) :=
            Nat.cast_le.mpr (Nat.le_add_right _ _)
          have hA_src : hRead wsi 28 ((m_bar * w + (i * w + j) : ℕ) : ℤ) = A_new iFin jFin := by
            rw [hpr_j 28 _ (fun h => by
                  rcases h with ⟨h, _⟩ | ⟨_, _, hlt⟩
                  · exact absurd h (by decide)
                  · exact absurd hlt (not_lt.mpr hge_src)),
                hRead_hWrite_of_ne ws _ (Or.inl (by omega)),
                hpr_i 28 _ (fun h => by
                  rcases h with ⟨h, _⟩ | ⟨_, _, hlt⟩
                  · exact absurd h (by decide)
                  · exact absurd hlt (not_lt.mpr hge_mw))]
            exact hA1_done iFin jFin hi
          have hw_cp := exec_write hctx hwsi 28
            (.add (.mul (.readHeap 10 (.lit 42)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 43)))
            (.readHeap 28 (.add (.readHeap 10 (.lit 29)) (.readHeap 10 (.lit 43))))
            ((i * w + j : ℕ) : ℤ) (A_new iFin jFin)
            (by simp only [evalVal_add, evalVal_mul, evalVal_readHeap, evalVal_lit, hi_w, hw_w, hctr_j]
                exact_mod_cast (rfl : i * w + j = i * w + j))
            (by have hsrc_eq : ((m_bar * w + i * w : ℕ) : ℤ) + (j : ℤ) = ((m_bar * w + (i * w + j) : ℕ) : ℤ) :=
                  by exact_mod_cast (by ring : (m_bar * w + i * w) + j = m_bar * w + (i * w + j))
                simp only [evalVal_readHeap, evalVal_add, evalVal_lit, hoff_w, hctr_j, hsrc_eq, hA_src])
            (Nat.cast_nonneg _)
            (Nat.cast_le.mpr ((hij_lt_next.le.trans hNext_le_MW).trans hMW_le))
            (hNewB iFin jFin)
          refine ⟨_, hw_cp, ?_,
            hpr_j.trans (PreservesOutside.write wsi _
              (Or.inr ⟨rfl, Nat.cast_le.mpr (Nat.le_add_right _ _), Nat.cast_lt.mpr hij_lt_next⟩)), ?_⟩
          · rw [hRead_hWrite_of_ne wsi _ (Or.inl (by omega))]; exact hctr_j
          · intro j' hj'
            rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
            · rw [hRead_hWrite_of_ne wsi _ (Or.inr (by omega))]; exact hprev_j j' hlt
            · have hj_eq : j' = jFin := Fin.ext heq
              subst hj_eq; exact hRead_hWrite_self wsi 28 _ _)
      have hpr_row : PreservesOutside modA2 ws2 ws_in :=
        (hpr_i.trans (PreservesOutside.write ws _ (by dsimp [modA2]; omega))).trans
          (hprIn2.mono (by
            intro t_id idx h; dsimp [modIn2] at h; dsimp [modA2]
            rcases h with ⟨rfl, rfl⟩ | ⟨rfl, hlo, hhi⟩
            · exact Or.inl ⟨rfl, by omega⟩
            · exact Or.inr ⟨rfl, le_trans (Nat.cast_nonneg _) hlo,
                lt_of_lt_of_le hhi (Nat.cast_le.mpr hNext_le_MW)⟩))
      refine ⟨ws_in, (hw_off.seq_steps hexIn2).mono_steps (by omega), ?_, hpr_row, ?_⟩
      · rw [hprIn2 10 42 (by dsimp [modIn2]; omega),
            hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hctr_i]
      · intro i' j' hi'
        rcases (show i'.val < i ∨ i'.val = i by omega) with hlt | heq
        · have hlt_i : i'.val * w + j'.val < i * w := row_col_lt_mul hlt j'.isLt
          rw [hprIn2 28 _ (fun h => by
                rcases h with ⟨h, _⟩ | ⟨_, hge, _⟩
                · exact absurd h (by decide)
                · exact absurd hge (not_le.mpr (Nat.cast_lt.mpr hlt_i))),
              hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
          exact hprev_i i' j' hlt
        · have hi_eq : i' = iFin := Fin.ext heq
          subst hi_eq; exact hRow2_done j' j'.isLt)
  have hpr_all : PreservesOutside mod ws₀ ws3 :=
    (hpr1.trans (hprA1.mono (by intro t idx h; dsimp [modA1] at h; dsimp [mod]; tauto))).trans
      (hprA2.mono (by intro t idx h; dsimp [modA2] at h; dsimp [mod]; tauto))
  exact ⟨ws3, hpr_all, fun i j => hA2_done i j i.isLt,
    (hs0.seq_steps (hs1.seq_steps hs2)).mono_steps (by nlinarith)⟩

def bareissColStepStmt : UL.BitRAMStmt :=
  let mBarE := UL.IntExpr.readHeap 10 (.lit 5)
  let wE := UL.IntExpr.readHeap 10 (.lit 28)
  let prE := UL.IntExpr.readHeap 10 (.lit 31)
  let pivE := UL.IntExpr.readHeap 10 (.lit 32)
  let cE := UL.IntExpr.readHeap 10 (.lit 41)
  seqBitStmts
    [ findPivotRowStmt
    , .ite (.intLe (.lit 0) prE)
        (seqBitStmts
          [ .writeHeap 10 (.lit 32) (.readHeap 28 (.add (.mul prE wE) cE))
          , bareissUpdateMatrixStmt
          , .writeHeap 10 (.lit 30) pivE
          , .writeHeap 29 prE (.lit 1)
          , .writeHeap 29 (.add mBarE cE) prE ])
        .skip ]

theorem exec_bareissColStepStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars + 1 ≤ maxIdx ∧ nEq + nLe ≤ maxIdx ∧
            2 * ((nEq + nLe) * (nVars + 1)) ≤ maxIdx ∧
            (nEq + nLe) + nVars ≤ maxIdx)
    (st : BareissState (nEq + nLe) nVars) (c : Fin nVars)
    (hCurB : ∀ i j, (st.A i j).natAbs ≤ 2 ^ K)
    (hNextB : ∀ i j, ((bareissColStep st c).A i j).natAbs ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hc_ws : hRead ws₀ 10 41 = (c.val : ℤ))
    (hBar : BareissStateInHeap st ws₀) :
    let m_bar := nEq + nLe
    let w := nVars + 1
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ (idx = 28 ∨ idx = 29 ∨ idx = 30 ∨ idx = 31 ∨ idx = 32 ∨ idx = 42 ∨ idx = 43)) ∨
      t_id = 28 ∨ t_id = 29
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      BareissStateInHeap (bareissColStep st c) ws₁ ∧
      ExecBit inp maxIdx K bareissColStepStmt ws₀ ws₁
        ((15 + m_bar * (12 + 5 * w)) * stepU) ((15 + m_bar * (12 + 5 * w)) * stepB K) := by
  intro m_bar w mod
  obtain ⟨ws1, hpr1, hw_ws1, hpr_ws1, hs1⟩ := exec_findPivotRowStmt hctx h64
    ⟨hIdx.1, hIdx.2.1⟩ st c hws₀ hDims hc_ws hBar
  have hpr1_mod : PreservesOutside mod ws₀ ws1 :=
    hpr1.mono (by intro t idx h; dsimp [mod]; omega)
  have hDim1 := hDims.preserve hpr1_mod (by intro idx _ _; dsimp [mod]; omega)
  have hc_ws1 : hRead ws1 10 41 = (c.val : ℤ) := by
    rw [hpr1_mod 10 41 (by dsimp [mod]; omega), hc_ws]
  have hBar1 : BareissStateInHeap st ws1 :=
    hBar.preserve hpr1 (by omega) (by intro _; omega) (by intro _; omega)
  rcases findPivotRow_spec st.A st.rowUsed c.castSucc with ⟨hNeg, _⟩ | ⟨r₀, hr₀_eq, _, _⟩
  · -- No pivot found: pr = -1
    have hcond_f : evalCondVal inp ws1 (.intLe (.lit 0) (.readHeap 10 (.lit 31))) = false := by
      simp only [evalCondVal_intLe, evalVal_lit, evalVal_readHeap, hpr_ws1, hNeg]; decide
    have hStepEq : bareissColStep st c = st := by
      dsimp [bareissColStep]
      rw [dif_neg (by rw [hNeg]; omega)]
    rw [hStepEq]
    exact ⟨ws1, hpr1_mod, hBar1,
      (hs1.seq_steps (exec_ite_false hctx (.intLe (.lit 0) (.readHeap 10 (.lit 31))) _ .skip
        hcond_f (exec_skip hctx hs1.2.1))).mono_steps (by dsimp only [m_bar, w]; nlinarith)⟩
  · -- Pivot found at r₀ : Fin m_bar
    have hcond_t : evalCondVal inp ws1 (.intLe (.lit 0) (.readHeap 10 (.lit 31))) = true := by
      simp only [evalCondVal_intLe, evalVal_lit, evalVal_readHeap, hpr_ws1, hr₀_eq]
      exact decide_eq_true (Nat.cast_nonneg _)
    have hPureCond : 0 ≤ findPivotRow st.A st.rowUsed c.castSucc ∧
        (findPivotRow st.A st.rowUsed c.castSucc).toNat < m_bar := by
      rw [hr₀_eq]
      exact ⟨Nat.cast_nonneg _, by simp only [Int.toNat_natCast]; exact r₀.isLt⟩
    have hr₀_fin : (⟨(findPivotRow st.A st.rowUsed c.castSucc).toNat, hPureCond.2⟩ : Fin m_bar) = r₀ := by
      ext; simp [hr₀_eq]
    have hStepForm : ∀ i j, (bareissColStep st c).A i j =
        if i = r₀ then st.A r₀ j
        else (st.A r₀ c.castSucc * st.A i j - st.A i c.castSucc * st.A r₀ j) / st.prevPiv := by
      intro i j
      dsimp [bareissColStep]
      rw [dif_pos hPureCond]
      dsimp only
      rw [hr₀_fin]
    -- Write 10[32] := piv = st.A r₀ c.castSucc
    have hr0c_eq : (r₀.val : ℤ) * (w : ℤ) + (c.val : ℤ) = ((r₀.val * w + c.val : ℕ) : ℤ) :=
      by exact_mod_cast (rfl : r₀.val * w + c.val = r₀.val * w + c.val)
    have hpr_ws1_r0 : hRead ws1 10 31 = (r₀.val : ℤ) := hpr_ws1.trans hr₀_eq
    have hw_ws1' : hRead ws1 10 28 = (w : ℤ) := hw_ws1
    have hA_r0c : hRead ws1 28 ((r₀.val * w + c.val : ℕ) : ℤ) = st.A r₀ c.castSucc :=
      hBar1.2.1 r₀ c.castSucc
    have hs_piv := exec_write hctx hs1.2.1 10 (.lit 32)
      (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 31)) (.readHeap 10 (.lit 28))) (.readHeap 10 (.lit 41))))
      32 (st.A r₀ c.castSucc) rfl
      (by simp only [evalVal_readHeap, evalVal_add, evalVal_mul, evalVal_lit,
            hpr_ws1_r0, hw_ws1', hc_ws1, hr0c_eq, hA_r0c])
      (by omega) (by omega) (hCurB r₀ c.castSucc)
    let ws2 := hWrite ws1 10 32 (st.A r₀ c.castSucc)
    have hws2 : StoreBounded 31 maxIdx K ws2 := hs_piv.2.1
    have hpr2_mod : PreservesOutside mod ws₀ ws2 :=
      hpr1_mod.trans (PreservesOutside.write ws1 _ (by dsimp [mod]; omega))
    have hDim2 := hDims.preserve hpr2_mod (by intro idx _ _; dsimp [mod]; omega)
    have hc_ws2 : hRead ws2 10 41 = (c.val : ℤ) := by
      rw [hRead_hWrite_of_ne ws1 _ (Or.inr (by omega)), hc_ws1]
    have hr0_ws2 : hRead ws2 10 31 = (r₀.val : ℤ) := by
      rw [hRead_hWrite_of_ne ws1 _ (Or.inr (by omega)), hpr_ws1_r0]
    have hpiv_ws2 : hRead ws2 10 32 = st.A r₀ c.castSucc := hRead_hWrite_self ws1 10 32 _
    have hBar2 : BareissStateInHeap st ws2 :=
      hBar1.preserve
        (PreservesOutside.write (mod := fun t i => t = 10 ∧ i = 32) ws1 _ ⟨rfl, rfl⟩)
        (by omega) (by intro _; omega) (by intro _; omega)
    obtain ⟨ws3, hpr3, hA_ws3, hs_mat⟩ := exec_bareissUpdateMatrixStmt hctx h64
      ⟨hIdx.1, hIdx.2.1, hIdx.2.2.1⟩ st c r₀ hStepForm hNextB
      hws2 hDim2 hc_ws2 hr0_ws2 hpiv_ws2 hBar2
    have hpr3_mod : PreservesOutside mod ws₀ ws3 :=
      hpr2_mod.trans (hpr3.mono (by intro t idx h; dsimp [mod]; tauto))
    have hpiv_ws3 : hRead ws3 10 32 = st.A r₀ c.castSucc := by
      rw [hpr3 10 32 (by omega), hpiv_ws2]
    have hr0_ws3 : hRead ws3 10 31 = (r₀.val : ℤ) := by
      rw [hpr3 10 31 (by omega), hr0_ws2]
    have hm_ws3 : hRead ws3 10 5 = (m_bar : ℤ) := by
      rw [hpr3_mod 10 5 (by dsimp [mod]; omega), hDims.2.2.2.2.2]
    have hc_ws3 : hRead ws3 10 41 = (c.val : ℤ) := by
      rw [hpr3_mod 10 41 (by dsimp [mod]; omega), hc_ws]
    -- Write 10[30] := piv
    have hs_prev := exec_write hctx hs_mat.2.1 10 (.lit 30) (.readHeap 10 (.lit 32))
      30 (st.A r₀ c.castSucc) rfl (by simp only [evalVal_readHeap, evalVal_lit, hpiv_ws3])
      (by omega) (by omega) (hCurB r₀ c.castSucc)
    let ws4 := hWrite ws3 10 30 (st.A r₀ c.castSucc)
    have hws4 : StoreBounded 31 maxIdx K ws4 := hs_prev.2.1
    -- Write 29[r₀] := 1
    have hr0_ws4 : hRead ws4 10 31 = (r₀.val : ℤ) := by
      rw [hRead_hWrite_of_ne ws3 _ (Or.inr (by omega)), hr0_ws3]
    have hs_ru := exec_write hctx hws4 29 (.readHeap 10 (.lit 31)) (.lit 1)
      (r₀.val : ℤ) 1 (by simp only [evalVal_readHeap, evalVal_lit, hr0_ws4]) rfl (Nat.cast_nonneg _)
      (Nat.cast_le.mpr (r₀.isLt.le.trans hIdx.2.1)) Nat.one_le_two_pow
    let ws5 := hWrite ws4 29 (r₀.val : ℤ) 1
    have hws5 : StoreBounded 31 maxIdx K ws5 := hs_ru.2.1
    -- Write 29[m_bar + c] := r₀
    have hm_ws5 : hRead ws5 10 5 = (m_bar : ℤ) := by
      rw [hRead_hWrite_of_ne ws4 _ (Or.inl (by omega)),
          hRead_hWrite_of_ne ws3 _ (Or.inr (by omega)), hm_ws3]
    have hc_ws5 : hRead ws5 10 41 = (c.val : ℤ) := by
      rw [hRead_hWrite_of_ne ws4 _ (Or.inl (by omega)),
          hRead_hWrite_of_ne ws3 _ (Or.inr (by omega)), hc_ws3]
    have hr0_ws5 : hRead ws5 10 31 = (r₀.val : ℤ) := by
      rw [hRead_hWrite_of_ne ws4 _ (Or.inl (by omega)), hr0_ws4]
    have hr0_abs : ((r₀.val : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
      simpa using (r₀.isLt.le.trans hIdx.2.1).trans hctx.hMaxIdx
    have hs_prc := exec_write hctx hws5 29
      (.add (.readHeap 10 (.lit 5)) (.readHeap 10 (.lit 41))) (.readHeap 10 (.lit 31))
      ((m_bar + c.val : ℕ) : ℤ) (r₀.val : ℤ)
      (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hm_ws5, hc_ws5]
          exact_mod_cast (rfl : m_bar + c.val = m_bar + c.val))
      (by simp only [evalVal_readHeap, evalVal_lit, hr0_ws5]) (Nat.cast_nonneg _)
      (Nat.cast_le.mpr ((Nat.add_le_add_left c.isLt.le m_bar).trans hIdx.2.2.2))
      hr0_abs
    let ws6 := hWrite ws5 29 ((m_bar + c.val : ℕ) : ℤ) (r₀.val : ℤ)
    have hpr6_mod : PreservesOutside mod ws₀ ws6 :=
      ((hpr3_mod.trans (PreservesOutside.write ws3 _ (by dsimp [mod]; omega))).trans
        (PreservesOutside.write ws4 _ (by dsimp [mod]; omega))).trans
        (PreservesOutside.write ws5 _ (by dsimp [mod]; omega))
    have hex_t := exec_ite_true hctx (.intLe (.lit 0) (.readHeap 10 (.lit 31))) _ .skip
      hcond_t (hs_piv.seq_steps (hs_mat.seq_steps (hs_prev.seq_steps (hs_ru.seq_steps hs_prc))))
    refine ⟨ws6, hpr6_mod, ⟨?_, ?_, ?_, ?_⟩,
      (hs1.seq_steps hex_t).mono_steps (by dsimp only [m_bar, w]; nlinarith)⟩
    · dsimp [bareissColStep]; rw [dif_pos hPureCond]; dsimp only; rw [hr₀_fin]
      rw [hRead_hWrite_of_ne ws5 _ (Or.inl (by omega)),
          hRead_hWrite_of_ne ws4 _ (Or.inl (by omega)), hRead_hWrite_self]
    · intro i j
      rw [hRead_hWrite_of_ne ws5 _ (Or.inl (by omega)),
          hRead_hWrite_of_ne ws4 _ (Or.inl (by omega)),
          hRead_hWrite_of_ne ws3 _ (Or.inl (by omega))]
      exact hA_ws3 i j
    · intro r
      dsimp [bareissColStep]; rw [dif_pos hPureCond]; dsimp only; rw [hr₀_fin]
      have hne_mc : (r.val : ℤ) ≠ ((m_bar + c.val : ℕ) : ℤ) := by
        have := r.isLt; omega
      rw [hRead_hWrite_of_ne ws5 _ (Or.inr hne_mc)]
      by_cases hrr0 : r = r₀
      · subst hrr0; simp [ws5, hRead_hWrite_self]
      · have hne_r0 : (r.val : ℤ) ≠ (r₀.val : ℤ) := fun h => hrr0 (Fin.ext (Int.ofNat.inj h))
        rw [if_neg hrr0, hRead_hWrite_of_ne ws4 _ (Or.inr hne_r0),
            hRead_hWrite_of_ne ws3 _ (Or.inl (by omega)),
            hpr3 29 _ (by omega)]
        exact hBar2.2.2.1 r
    · intro j
      have hrhs_eq : (bareissColStep st c).pivRowOfCol j =
          if j = c then (r₀.val : ℤ) else st.pivRowOfCol j := by
        dsimp [bareissColStep]; rw [dif_pos hPureCond]; dsimp only
        simp only [hr₀_eq, Int.toNat_natCast]
      rw [hrhs_eq]
      change hRead (hWrite ws5 29 ((m_bar + c.val : ℕ) : ℤ) (r₀.val : ℤ)) 29 ((m_bar + j.val : ℕ) : ℤ) = _
      by_cases hjc : j = c
      · rw [if_pos hjc]; simp only [hjc]
        exact hRead_hWrite_self ws5 29 ((m_bar + c.val : ℕ) : ℤ) (r₀.val : ℤ)
      · have hne_jc : ((m_bar + j.val : ℕ) : ℤ) ≠ ((m_bar + c.val : ℕ) : ℤ) := by
          intro h
          have hnat : m_bar + j.val = m_bar + c.val := Int.ofNat.inj h
          exact hjc (Fin.ext (by omega))
        have hne_r0 : ((m_bar + j.val : ℕ) : ℤ) ≠ (r₀.val : ℤ) := by
          have := r₀.isLt; omega
        rw [if_neg hjc, hRead_hWrite_of_ne ws5 _ (Or.inr hne_jc),
            hRead_hWrite_of_ne ws4 _ (Or.inr hne_r0),
            hRead_hWrite_of_ne ws3 _ (Or.inl (by omega)),
            hpr3 29 _ (by omega)]
        exact hBar2.2.2.2 j

def bareissSolveStmt : UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let mBarE := UL.IntExpr.readHeap 10 (.lit 5)
  let wE := UL.IntExpr.readHeap 10 (.lit 28)
  let prevPivE := UL.IntExpr.readHeap 10 (.lit 30)
  let prE := UL.IntExpr.readHeap 10 (.lit 31)
  let sgnE := UL.IntExpr.readHeap 10 (.lit 33)
  let denE := UL.IntExpr.readHeap 10 (.lit 34)
  let jE := UL.IntExpr.readHeap 10 (.lit 42)
  seqBitStmts
    [ forLoopStmt 41 nVarsE bareissColStepStmt
    , .writeHeap 10 (.lit 28) (.add nVarsE (.lit 1))
    , .ite (.intLt (.lit 0) prevPivE)
        (.writeHeap 10 (.lit 33) (.lit 1))
        (.writeHeap 10 (.lit 33) (.lit (-1)))
    , .writeHeap 10 (.lit 34) (.mul sgnE prevPivE)
    , forLoopStmt 42 nVarsE
        (seqBitStmts
          [ .writeHeap 10 (.lit 31) (.readHeap 29 (.add mBarE jE))
          , .ite (.intLe (.lit 0) prE)
              (seqBitStmts
                [ .writeHeap 31 (.mul (.lit 2) jE)
                    (.mul sgnE (.readHeap 28 (.add (.mul prE wE) nVarsE)))
                , .writeHeap 31 (.add (.mul (.lit 2) jE) (.lit 1)) denE ])
              (seqBitStmts
                [ .writeHeap 31 (.mul (.lit 2) jE) (.lit 0)
                , .writeHeap 31 (.add (.mul (.lit 2) jE) (.lit 1)) (.lit 1) ]) ]) ]

theorem exec_bareissSolveStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe U maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hIdx : nVars ≤ maxIdx ∧ nVars + 1 ≤ maxIdx ∧ 2 * nVars ≤ maxIdx ∧
            nEq + nLe ≤ maxIdx ∧ 2 * ((nEq + nLe) * (nVars + 1)) ≤ maxIdx ∧
            (nEq + nLe) + nVars ≤ maxIdx)
    (T₀ : Fin (nEq + nLe) → Fin nVars → ℤ) (rhs₀ : Fin (nEq + nLe) → ℤ)
    (hU : 1 ≤ U)
    (hT : ∀ i j, (T₀ i j).natAbs ≤ U)
    (hrhs : ∀ i, (rhs₀ i).natAbs ≤ U)
    (hBarB : (nVars + 1).factorial * U ^ (nVars + 1) ≤ 2 ^ K)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hInit : BareissStateInHeap (bareissInit T₀ rhs₀) ws₀) :
    let m_bar := nEq + nLe
    let w := nVars + 1
    let m_col := 15 + m_bar * (12 + 5 * w)
    let m_tot := 10 + nVars * (m_col + 7)
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ ((28 ≤ idx ∧ idx ≤ 34) ∨ (41 ≤ idx ∧ idx ≤ 43))) ∨
      t_id = 28 ∨ t_id = 29 ∨ t_id = 31
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ j : Fin nVars,
        hRead ws₁ 31 (2 * (j.val : ℤ)) = (bareissSolve T₀ rhs₀).1 j ∧
        hRead ws₁ 31 (2 * (j.val : ℤ) + 1) = (bareissSolve T₀ rhs₀).2 j) ∧
      ExecBit inp maxIdx K bareissSolveStmt ws₀ ws₁
        (m_tot * stepU) (m_tot * stepB K) := by
  intro m_bar w m_col m_tot mod
  let stAt : (c : ℕ) → c ≤ nVars → BareissState m_bar nVars := fun c hc =>
    Fin.foldl c (fun s (j : Fin c) => bareissColStep s ⟨j.val, lt_of_lt_of_le j.isLt hc⟩)
      (bareissInit T₀ rhs₀)
  have hStepBound : ∀ (c : ℕ) (hc : c ≤ nVars),
      (stAt c hc).prevPiv.natAbs ≤ 2 ^ K ∧
      (∀ i j, ((stAt c hc).A i j).natAbs ≤ 2 ^ K) := by
    intro c hc
    obtain ⟨hp, hA⟩ := bareissRun_step_bound T₀ rhs₀ U hU hT hrhs c hc
    exact ⟨hp.trans hBarB, fun i j => (hA i j).trans hBarB⟩
  let modRun : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ ((28 ≤ idx ∧ idx ≤ 32) ∨ (41 ≤ idx ∧ idx ≤ 43))) ∨
    t_id = 28 ∨ t_id = 29
  let PRun : ℕ → UL.WordStore → Prop := fun c ws =>
    ∀ hc : c ≤ nVars, BareissStateInHeap (stAt c hc) ws
  have hcntRun : evalVal inp (hWrite ws₀ 10 41 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hDims.1]
  obtain ⟨ws1, hprRun, hDoneRun, hs1⟩ := exec_for_frame hctx 41 (.readHeap 10 (.lit 0))
    bareissColStepStmt nVars m_col modRun PRun hws₀ (by omega) hIdx.1
    (by dsimp [modRun]; omega)
    (fun c ws v => by
      dsimp [PRun]; constructor <;> intro h hc
      · exact (BareissStateInHeap_ign_ctr (stAt c hc) 41 (by decide) ws v).mp (h hc)
      · exact (BareissStateInHeap_ign_ctr (stAt c hc) 41 (by decide) ws v).mpr (h hc))
    hcntRun
    (fun _ => by simpa [stAt, Fin.foldl_zero] using hInit)
    (fun c hc ws hws hctr_c hpr_c hprev_c => by
      let cFin : Fin nVars := ⟨c, hc⟩
      have hst_succ : stAt (c + 1) hc = bareissColStep (stAt c hc.le) cFin := by
        dsimp [stAt]; rw [Fin.foldl_succ_last]; rfl
      have hCurB := (hStepBound c hc.le).2
      have hNextB : ∀ i j, ((bareissColStep (stAt c hc.le) cFin).A i j).natAbs ≤ 2 ^ K := by
        rw [← hst_succ]; exact (hStepBound (c + 1) hc).2
      have hDim_w := hDims.preserve hpr_c (by intro idx _ _; dsimp [modRun]; omega)
      obtain ⟨ws_s, hpr_s, hBar_s, hex_s⟩ := exec_bareissColStepStmt hctx h64
        ⟨hIdx.2.1, hIdx.2.2.2.1, hIdx.2.2.2.2.1, hIdx.2.2.2.2.2⟩
        (stAt c hc.le) cFin hCurB hNextB hws hDim_w hctr_c (hprev_c hc.le)
      refine ⟨ws_s, hex_s, ?_,
        hpr_c.trans (hpr_s.mono (by intro t idx h; dsimp [modRun]; omega)),
        fun hc1 => ?_⟩
      · rw [hpr_s 10 41 (by omega), hctr_c]
      · have hprf : stAt (c + 1) hc1 = bareissColStep (stAt c hc.le) cFin := hst_succ
        rwa [hprf])
  let stFinal := bareissRun T₀ rhs₀
  have hstFinal_eq : stAt nVars le_rfl = stFinal := rfl
  have hBarFinal : BareissStateInHeap stFinal ws1 := by
    simpa only [hstFinal_eq] using hDoneRun le_rfl
  obtain ⟨hpivB_fin, hAB_fin⟩ := hStepBound nVars le_rfl
  rw [hstFinal_eq] at hpivB_fin hAB_fin
  have hpr1_mod : PreservesOutside mod ws₀ ws1 :=
    hprRun.mono (by intro t idx h; dsimp [modRun] at h; dsimp [mod]; omega)
  have hDim1 := hDims.preserve hpr1_mod (by intro idx _ _; dsimp [mod]; omega)
  -- Write 10[28] := w
  have hw_abs : ((w : ℕ) : ℤ).natAbs ≤ 2 ^ K := by
    simpa using hIdx.2.1.trans hctx.hMaxIdx
  have hs2 := exec_write hctx hs1.2.1 10 (.lit 28) (.add (.readHeap 10 (.lit 0)) (.lit 1))
    28 (w : ℤ) rfl
    (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hDim1.1]
        exact_mod_cast (rfl : nVars + 1 = w))
    (by omega) (by omega) hw_abs
  let ws2 := hWrite ws1 10 28 (w : ℤ)
  have hws2 : StoreBounded 31 maxIdx K ws2 := hs2.2.1
  have hpr2_mod : PreservesOutside mod ws₀ ws2 :=
    hpr1_mod.trans (PreservesOutside.write ws1 _ (by dsimp [mod]; omega))
  have h30_ws2 : hRead ws2 10 30 = stFinal.prevPiv := by
    rw [hRead_hWrite_of_ne ws1 _ (Or.inr (by omega)), hBarFinal.1]
  -- Compute sgn in 10[33]
  let sgn : ℤ := if 0 < stFinal.prevPiv then 1 else -1
  have hsgn_step : ∃ ws3 : UL.WordStore,
      PreservesOutside (fun t_id idx => t_id = 10 ∧ idx = 33) ws2 ws3 ∧
      hRead ws3 10 33 = sgn ∧
      ExecBit inp maxIdx K
        (.ite (.intLt (.lit 0) (.readHeap 10 (.lit 30)))
          (.writeHeap 10 (.lit 33) (.lit 1))
          (.writeHeap 10 (.lit 33) (.lit (-1))))
        ws2 ws3 (2 * stepU) (2 * stepB K) := by
    by_cases hp : 0 < stFinal.prevPiv
    · have hc : evalCondVal inp ws2 (.intLt (.lit 0) (.readHeap 10 (.lit 30))) = true := by
        simp [evalCondVal_intLt, h30_ws2, hp]
      have hw := exec_write hctx hws2 10 (.lit 33) (.lit 1) 33 1 rfl rfl
        (by omega) (by omega) Nat.one_le_two_pow
      exact ⟨_, PreservesOutside.write (mod := fun t_id idx => t_id = 10 ∧ idx = 33) ws2 1 ⟨rfl, rfl⟩,
        by simp [sgn, hp, hRead_hWrite_self],
        exec_ite_true hctx _ _ _ hc hw⟩
    · have hc : evalCondVal inp ws2 (.intLt (.lit 0) (.readHeap 10 (.lit 30))) = false := by
        simp [evalCondVal_intLt, h30_ws2, hp]
      have hw := exec_write hctx hws2 10 (.lit 33) (.lit (-1)) 33 (-1) rfl rfl
        (by omega) (by omega) Nat.one_le_two_pow
      exact ⟨_, PreservesOutside.write (mod := fun t_id idx => t_id = 10 ∧ idx = 33) ws2 (-1) ⟨rfl, rfl⟩,
        by simp [sgn, hp, hRead_hWrite_self],
        exec_ite_false hctx _ _ _ hc hw⟩
  obtain ⟨ws3, hpr3, hsgn_ws3, hs3⟩ := hsgn_step
  have hpr3_mod : PreservesOutside mod ws₀ ws3 :=
    hpr2_mod.trans (hpr3.mono (by intro t idx h; dsimp [mod]; omega))
  -- Compute den = sgn * stFinal.prevPiv in 10[34]
  let den : ℤ := sgn * stFinal.prevPiv
  have hsgn_abs : sgn.natAbs = 1 := by dsimp [sgn]; split_ifs <;> rfl
  have hden_abs : den.natAbs ≤ 2 ^ K := by
    dsimp [den]; rw [Int.natAbs_mul, hsgn_abs, one_mul]; exact hpivB_fin
  have h30_ws3 : hRead ws3 10 30 = stFinal.prevPiv := by
    rw [hpr3 10 30 (by omega), h30_ws2]
  have hs4 := exec_write hctx hs3.2.1 10 (.lit 34)
    (.mul (.readHeap 10 (.lit 33)) (.readHeap 10 (.lit 30)))
    34 den rfl (by simp only [evalVal_mul, evalVal_readHeap, evalVal_lit, hsgn_ws3, h30_ws3, den])
    (by omega) (by omega) hden_abs
  let ws4 := hWrite ws3 10 34 den
  have hws4 : StoreBounded 31 maxIdx K ws4 := hs4.2.1
  have hpr4_mod : PreservesOutside mod ws₀ ws4 :=
    hpr3_mod.trans (PreservesOutside.write ws3 _ (by dsimp [mod]; omega))
  let mod14 : ℕ → ℤ → Prop := fun t_id idx => t_id = 10 ∧ (idx = 28 ∨ idx = 33 ∨ idx = 34)
  have hpr14 : PreservesOutside mod14 ws1 ws4 :=
    (PreservesOutside.write (mod := mod14) ws1 _ (by dsimp [mod14]; omega)).trans
      ((hpr3.mono (by intro t i h; dsimp [mod14]; omega)).trans
        (PreservesOutside.write (mod := mod14) ws3 _ (by dsimp [mod14]; omega)))
  have hBar4 : BareissStateInHeap stFinal ws4 :=
    hBarFinal.preserve hpr14 (by dsimp [mod14]; omega)
      (by intro _; dsimp [mod14]; omega) (by intro _; dsimp [mod14]; omega)
  have hw_ws4 : hRead ws4 10 28 = (w : ℤ) := by
    rw [hRead_hWrite_of_ne ws3 _ (Or.inr (by omega)), hpr3 10 28 (by omega), hRead_hWrite_self]
  have hsgn_ws4 : hRead ws4 10 33 = sgn := by
    rw [hRead_hWrite_of_ne ws3 _ (Or.inr (by omega)), hsgn_ws3]
  have hden_ws4 : hRead ws4 10 34 = den := hRead_hWrite_self ws3 10 34 den
  have hDim4 := hDims.preserve hpr4_mod (by intro idx _ _; dsimp [mod]; omega)
  -- Extraction loop j = 0 .. nVars - 1
  let modExt : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ (idx = 31 ∨ idx = 42)) ∨
    (t_id = 31 ∧ 0 ≤ idx ∧ idx < (2 * (nVars : ℤ)))
  let PExt : ℕ → UL.WordStore → Prop := fun C ws =>
    ∀ j : Fin nVars, j.val < C →
      hRead ws 31 (2 * (j.val : ℤ)) = (bareissSolve T₀ rhs₀).1 j ∧
      hRead ws 31 (2 * (j.val : ℤ) + 1) = (bareissSolve T₀ rhs₀).2 j
  have hcntExt : evalVal inp (hWrite ws4 10 42 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws4 0 (Or.inr (by omega)), hDim4.1]
  obtain ⟨ws5, hprExt, hDoneExt, hs5⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 0))
    (seqBitStmts
      [ .writeHeap 10 (.lit 31) (.readHeap 29 (.add (.readHeap 10 (.lit 5)) (.readHeap 10 (.lit 42))))
      , .ite (.intLe (.lit 0) (.readHeap 10 (.lit 31)))
          (seqBitStmts
            [ .writeHeap 31 (.mul (.lit 2) (.readHeap 10 (.lit 42)))
                (.mul (.readHeap 10 (.lit 33))
                  (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 31)) (.readHeap 10 (.lit 28)))
                    (.readHeap 10 (.lit 0)))))
            , .writeHeap 31 (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1))
                (.readHeap 10 (.lit 34)) ])
          (seqBitStmts
            [ .writeHeap 31 (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 0)
            , .writeHeap 31 (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1)) (.lit 1) ]) ])
    nVars 4 modExt PExt hws4 (by omega) hIdx.1
    (by dsimp [modExt]; omega)
    (fun C ws v => by
      dsimp [PExt]; constructor <;> intro h j hj
      · obtain ⟨h1, h2⟩ := h j hj
        rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at h1 h2
        exact ⟨h1, h2⟩
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide)),
            hRead_hWrite_of_ne ws v (Or.inl (by decide))]
        exact h j hj)
    hcntExt (fun _ h => False.elim (Nat.not_lt_zero _ h))
    (fun j hj ws hws hctr_j hpr_j hprev_j => by
      let jFin : Fin nVars := ⟨j, hj⟩
      let pr := stFinal.pivRowOfCol jFin
      have hm_w : hRead ws 10 5 = (m_bar : ℤ) := by
        rw [hpr_j 10 5 (by dsimp [modExt]; omega), hDim4.2.2.2.2.2]
      have hpr_range := bareissRun_pivRowOfCol_range T₀ rhs₀ jFin
      have hpr_abs : pr.natAbs ≤ 2 ^ K := by
        rcases hpr_range with hneg | ⟨r₀, hr₀⟩
        · dsimp [pr]; rw [hneg]; exact Nat.one_le_two_pow
        · dsimp [pr]; rw [hr₀]
          simpa using (r₀.isLt.le.trans hIdx.2.2.2.1).trans hctx.hMaxIdx
      have h29_w : hRead ws 29 ((m_bar + j : ℕ) : ℤ) = pr := by
        rw [hpr_j 29 _ (by dsimp [modExt]; omega)]; exact hBar4.2.2.2 jFin
      have hw_pr := exec_write hctx hws 10 (.lit 31)
        (.readHeap 29 (.add (.readHeap 10 (.lit 5)) (.readHeap 10 (.lit 42))))
        31 pr rfl
        (by have heq : (m_bar : ℤ) + (j : ℤ) = ((m_bar + j : ℕ) : ℤ) :=
              by exact_mod_cast (rfl : m_bar + j = m_bar + j)
            simp only [evalVal_readHeap, evalVal_add, evalVal_lit, hm_w, hctr_j, heq, h29_w])
        (by omega) (by omega) hpr_abs
      let wsp := hWrite ws 10 31 pr
      have hwsp : StoreBounded 31 maxIdx K wsp := hw_pr.2.1
      have h31_p : hRead wsp 10 31 = pr := hRead_hWrite_self ws 10 31 pr
      have hj_p : hRead wsp 10 42 = (j : ℤ) := by
        rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hctr_j]
      have h2j_le : 2 * (j : ℤ) + 1 ≤ (maxIdx : ℤ) := by
        have := hIdx.2.2.1; omega
      rcases hpr_range with hneg | ⟨r₀, hr₀⟩
      · have hneg' : pr = -1 := hneg
        have hcond_f : evalCondVal inp wsp (.intLe (.lit 0) (.readHeap 10 (.lit 31))) = false := by
          simp [evalCondVal_intLe, h31_p, hneg']
        have hw_n := exec_write hctx hwsp 31 (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 0)
          (2 * (j : ℤ)) 0 (by simp [hj_p]) rfl (by omega) (by omega) (by simp)
        let wsn := hWrite wsp 31 (2 * (j : ℤ)) 0
        have hwsn : StoreBounded 31 maxIdx K wsn := hw_n.2.1
        have hj_n : hRead wsn 10 42 = (j : ℤ) := by
          rw [hRead_hWrite_of_ne wsp _ (Or.inl (by omega)), hj_p]
        have hw_d := exec_write hctx hwsn 31
          (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1)) (.lit 1)
          (2 * (j : ℤ) + 1) 1 (by simp [hj_n]) rfl (by omega) h2j_le Nat.one_le_two_pow
        let wsd := hWrite wsn 31 (2 * (j : ℤ) + 1) 1
        have hSol0 : (bareissSolve T₀ rhs₀).1 jFin = 0 ∧ (bareissSolve T₀ rhs₀).2 jFin = 1 := by
          dsimp [bareissSolve]
          have hn : ¬ (0 ≤ stFinal.pivRowOfCol jFin ∧ (stFinal.pivRowOfCol jFin).toNat < m_bar) := by
            change ¬ (0 ≤ pr ∧ pr.toNat < m_bar); rw [hneg']; omega
          exact ⟨dif_neg hn, dif_neg hn⟩
        refine ⟨wsd, hw_pr.seq_steps (exec_ite_false hctx (.intLe (.lit 0) (.readHeap 10 (.lit 31))) _ _
          hcond_f (hw_n.seq_steps hw_d)), ?_,
          ((hpr_j.trans (PreservesOutside.write ws _ (by dsimp [modExt]; omega))).trans
            (PreservesOutside.write wsp _ (by dsimp [modExt]; omega))).trans
            (PreservesOutside.write wsn _ (by dsimp [modExt]; omega)), ?_⟩
        · rw [hRead_hWrite_of_ne wsn _ (Or.inl (by omega)), hj_n]
        · intro j' hj'
          rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
          · rw [hRead_hWrite_of_ne wsn _ (Or.inr (by omega)),
                hRead_hWrite_of_ne wsp _ (Or.inr (by omega)),
                hRead_hWrite_of_ne ws _ (Or.inl (by omega)),
                hRead_hWrite_of_ne wsn _ (Or.inr (by omega)),
                hRead_hWrite_of_ne wsp _ (Or.inr (by omega)),
                hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
            exact hprev_j j' hlt
          · have hj_eq : j' = jFin := Fin.ext heq
            subst hj_eq
            refine ⟨?_, ?_⟩
            · rw [hSol0.1, hRead_hWrite_of_ne wsn _ (Or.inr (by omega))]
              exact hRead_hWrite_self wsp 31 _ 0
            · rw [hSol0.2]; exact hRead_hWrite_self wsn 31 _ 1
      · have hr₀' : pr = (r₀.val : ℤ) := hr₀
        have hcond_t : evalCondVal inp wsp (.intLe (.lit 0) (.readHeap 10 (.lit 31))) = true := by
          simp only [evalCondVal_intLe, evalVal_lit, evalVal_readHeap, h31_p, hr₀']
          exact decide_eq_true (Nat.cast_nonneg _)
        have hw_p : hRead wsp 10 28 = (w : ℤ) := by
          rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hpr_j 10 28 (by dsimp [modExt]; omega), hw_ws4]
        have hnV_p : hRead wsp 10 0 = (nVars : ℤ) := by
          rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hpr_j 10 0 (by dsimp [modExt]; omega), hDim4.1]
        have hsgn_p : hRead wsp 10 33 = sgn := by
          rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hpr_j 10 33 (by dsimp [modExt]; omega), hsgn_ws4]
        have hden_p : hRead wsp 10 34 = den := by
          rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega)), hpr_j 10 34 (by dsimp [modExt]; omega), hden_ws4]
        have h28_p : hRead wsp 28 ((r₀.val * w + nVars : ℕ) : ℤ) = stFinal.A r₀ (Fin.last nVars) := by
          rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega)), hpr_j 28 _ (by dsimp [modExt]; omega)]
          exact hBar4.2.1 r₀ (Fin.last nVars)
        let numVal : ℤ := sgn * stFinal.A r₀ (Fin.last nVars)
        have hnum_abs : numVal.natAbs ≤ 2 ^ K := by
          dsimp [numVal]; rw [Int.natAbs_mul, hsgn_abs, one_mul]; exact hAB_fin r₀ (Fin.last nVars)
        have h31_p_r0 : hRead wsp 10 31 = (r₀.val : ℤ) := h31_p.trans hr₀'
        have hw_n := exec_write hctx hwsp 31
          (.mul (.lit 2) (.readHeap 10 (.lit 42)))
          (.mul (.readHeap 10 (.lit 33))
            (.readHeap 28 (.add (.mul (.readHeap 10 (.lit 31)) (.readHeap 10 (.lit 28)))
              (.readHeap 10 (.lit 0)))))
          (2 * (j : ℤ)) numVal (by simp [hj_p])
          (by have hidx : (r₀.val : ℤ) * (w : ℤ) + (nVars : ℤ) = ((r₀.val * w + nVars : ℕ) : ℤ) :=
                by exact_mod_cast (rfl : r₀.val * w + nVars = r₀.val * w + nVars)
              simp only [evalVal_mul, evalVal_readHeap, evalVal_add, evalVal_lit,
                hsgn_p, h31_p_r0, hw_p, hnV_p, hidx, h28_p, numVal])
          (by omega) (by omega) hnum_abs
        let wsn := hWrite wsp 31 (2 * (j : ℤ)) numVal
        have hwsn : StoreBounded 31 maxIdx K wsn := hw_n.2.1
        have hj_n : hRead wsn 10 42 = (j : ℤ) := by
          rw [hRead_hWrite_of_ne wsp _ (Or.inl (by omega)), hj_p]
        have hden_n : hRead wsn 10 34 = den := by
          rw [hRead_hWrite_of_ne wsp _ (Or.inl (by omega)), hden_p]
        have hw_d := exec_write hctx hwsn 31
          (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1)) (.readHeap 10 (.lit 34))
          (2 * (j : ℤ) + 1) den (by simp [hj_n]) (by simp [hden_n]) (by omega) h2j_le hden_abs
        let wsd := hWrite wsn 31 (2 * (j : ℤ) + 1) den
        have hpure_ok : 0 ≤ stFinal.pivRowOfCol jFin ∧ (stFinal.pivRowOfCol jFin).toNat < m_bar := by
          change 0 ≤ pr ∧ pr.toNat < m_bar
          rw [hr₀']
          exact ⟨Nat.cast_nonneg _, by simp only [Int.toNat_natCast]; exact r₀.isLt⟩
        have hr₀_eq_fin : (⟨(stFinal.pivRowOfCol jFin).toNat, hpure_ok.2⟩ : Fin m_bar) = r₀ := by
          ext; change pr.toNat = r₀.val; simp [hr₀']
        have hSol1 : (bareissSolve T₀ rhs₀).1 jFin = numVal ∧ (bareissSolve T₀ rhs₀).2 jFin = den := by
          dsimp [bareissSolve]
          exact ⟨by rw [dif_pos hpure_ok, hr₀_eq_fin], dif_pos hpure_ok⟩
        refine ⟨wsd, hw_pr.seq_steps (exec_ite_true hctx (.intLe (.lit 0) (.readHeap 10 (.lit 31))) _ _
          hcond_t (hw_n.seq_steps hw_d)), ?_,
          ((hpr_j.trans (PreservesOutside.write ws _ (by dsimp [modExt]; omega))).trans
            (PreservesOutside.write wsp _ (by dsimp [modExt]; omega))).trans
            (PreservesOutside.write wsn _ (by dsimp [modExt]; omega)), ?_⟩
        · rw [hRead_hWrite_of_ne wsn _ (Or.inl (by omega)), hj_n]
        · intro j' hj'
          rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
          · rw [hRead_hWrite_of_ne wsn _ (Or.inr (by omega)),
                hRead_hWrite_of_ne wsp _ (Or.inr (by omega)),
                hRead_hWrite_of_ne ws _ (Or.inl (by omega)),
                hRead_hWrite_of_ne wsn _ (Or.inr (by omega)),
                hRead_hWrite_of_ne wsp _ (Or.inr (by omega)),
                hRead_hWrite_of_ne ws _ (Or.inl (by omega))]
            exact hprev_j j' hlt
          · have hj_eq : j' = jFin := Fin.ext heq
            subst hj_eq
            refine ⟨?_, ?_⟩
            · rw [hSol1.1, hRead_hWrite_of_ne wsn _ (Or.inr (by omega))]
              exact hRead_hWrite_self wsp 31 _ numVal
            · rw [hSol1.2]; exact hRead_hWrite_self wsn 31 _ den)
  have hpr5_mod : PreservesOutside mod ws₀ ws5 :=
    hpr4_mod.trans (hprExt.mono (by intro t idx h; dsimp [modExt] at h; dsimp [mod]; omega))
  exact ⟨ws5, hpr5_mod, fun j => hDoneExt j j.isLt,
    (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps hs5)))).mono_steps
      (by dsimp [m_tot]; nlinarith)⟩

/-! ### 4. `activeSetStepStmt`, `solveCoreIntLPStmt`, and `solveRationalLPStmt` -/

def ellStepBound (nVars nEq nLe L : ℕ) : ℕ :=
  let N := nVars + 2
  let m_ora := 2 * nEq + 2 * nLe
  let T := ellParamT N L
  let B_sqrt := ellParamBsqrt N L
  let m_step := 40 + m_ora * (6 + 2 * N) + 4 * B_sqrt + N * (23 + 10 * N)
  30 + 3 * B_sqrt + N * (6 + 3 * N) + T * (m_step + 1)

theorem ellStepBound_mono_L {nVars nEq nLe L₁ L₂ : ℕ} (h : L₁ ≤ L₂) :
    ellStepBound nVars nEq nLe L₁ ≤ ellStepBound nVars nEq nLe L₂ := by
  dsimp [ellStepBound]
  have hB := ellParamBsqrt_mono_L (N := nVars + 2) h
  have hT := ellParamT_mono_L (N := nVars + 2) h
  have hstep : 40 + (2 * nEq + 2 * nLe) * (6 + 2 * (nVars + 2)) +
      4 * ellParamBsqrt (nVars + 2) L₁ + (nVars + 2) * (23 + 10 * (nVars + 2)) + 1 ≤
      40 + (2 * nEq + 2 * nLe) * (6 + 2 * (nVars + 2)) +
      4 * ellParamBsqrt (nVars + 2) L₂ + (nVars + 2) * (23 + 10 * (nVars + 2)) + 1 := by omega
  exact Nat.add_le_add (by omega) (Nat.mul_le_mul hT hstep)

def activeSetStepStmt : UL.BitRAMStmt :=
  let nLeE := UL.IntExpr.readHeap 10 (.lit 2)
  let kE := UL.IntExpr.readHeap 10 (.lit 40)
  let sE := UL.IntExpr.readHeap 10 (.lit 42)
  seqBitStmts
    [ forLoopStmt 42 nLeE
        (.writeHeap 23 (.add nLeE sE) (.readHeap 23 sE))
    , .writeHeap 23 (.add nLeE kE) (.lit 1)
    , buildOracleStmt nLeE
    , ellipsoidDecideStmt
    , .ite (.intEq (.readHeap 10 (.lit 17)) (.lit 1))
        (forLoopStmt 42 nLeE
          (.writeHeap 23 sE (.readHeap 23 (.add nLeE sE))))
        .skip ]

theorem exec_activeSetStepStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe L B_int maxIdx K : ℕ}
    (hctx : HeapCtx inp maxIdx K) (h64 : 64 ≤ maxIdx)
    (hL1 : 1 ≤ L) (hLB : L ≤ B_int)
    (hBK : 5 * ellParamBsqrt (nVars + 2) B_int ≤ K)
    (hIdx : nVars ≤ maxIdx ∧ nEq ≤ maxIdx ∧ nLe ≤ maxIdx ∧ 2 * nLe ≤ maxIdx ∧
            (2 * nEq + 2 * nLe) * (nVars + 2) ≤ maxIdx ∧
            (2 * nEq + 2 * nLe) ≤ maxIdx ∧
            4 * (nVars + 2) ≤ maxIdx ∧
            2 * ((nVars + 2) * (nVars + 2)) ≤ maxIdx)
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (hMeqL : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ L) (hdeqL : ∀ i, (d_eq i).natAbs ≤ 2 ^ L)
    (hMleL : ∀ k j, (M_le k j).natAbs ≤ 2 ^ L) (hdleL : ∀ k, (d_le k).natAbs ≤ 2 ^ L)
    (act : Fin nLe → Bool) (k : Fin nLe)
    {ws₀ : UL.WordStore} (hws₀ : StoreBounded 31 maxIdx K ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hL_ws : hRead ws₀ 10 7 = (L : ℤ))
    (hk_ws : hRead ws₀ 10 40 = (k.val : ℤ))
    (hCleared : ClearedLPInHeap M_eq d_eq M_le d_le ws₀)
    (hAct_ws : ∀ s : Fin nLe, hRead ws₀ 23 (s.val : ℤ) = if act s then 1 else 0) :
    let cand : Fin nLe → Bool := fun s => if s = k then true else act s
    let nextAct : Fin nLe → Bool :=
      if ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
          (buildOracleM M_eq M_le cand) (buildOracleD d_eq d_le cand) then cand else act
    let m_ora_b := 10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars)
    let m_iter := 8 + 4 * nLe + m_ora_b + ellStepBound nVars nEq nLe B_int
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ ((9 ≤ idx ∧ idx ≤ 29) ∨ (41 ≤ idx ∧ idx ≤ 43))) ∨
      t_id = 23 ∨ t_id = 24 ∨ t_id = 25 ∨ t_id = 26 ∨ t_id = 27
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      (∀ s : Fin nLe, hRead ws₁ 23 (s.val : ℤ) = if nextAct s then 1 else 0) ∧
      ExecBit inp maxIdx K activeSetStepStmt ws₀ ws₁
        (m_iter * stepU) (m_iter * stepB K) := by
  intro cand nextAct m_ora_b m_iter mod
  have hLK : L ≤ K := by
    have h1 := ellParamBsqrt_mono_L (N := nVars + 2) hLB
    have h2 : L ≤ ellParamBsqrt (nVars + 2) L := by
      dsimp [ellParamBsqrt, ellParamE]
      have : L ≤ (nVars + 2 + 2) * (nVars + 2 + 2 + L) :=
        (Nat.le_add_left _ _).trans (Nat.le_mul_of_pos_left _ (by omega))
      omega
    omega
  have hPowLK : 2 ^ L ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) hLK
  have hMeqK : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ K := fun i j => (hMeqL i j).trans hPowLK
  have hdeqK : ∀ i, (d_eq i).natAbs ≤ 2 ^ K := fun i => (hdeqL i).trans hPowLK
  have hMleK : ∀ i j, (M_le i j).natAbs ≤ 2 ^ K := fun i j => (hMleL i j).trans hPowLK
  have hdleK : ∀ i, (d_le i).natAbs ≤ 2 ^ K := fun i => (hdleL i).trans hPowLK
  -- Step 1: copy act[0..nLe-1] -> 23[nLe..2*nLe-1]
  let modC1 : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨ (t_id = 23 ∧ (nLe : ℤ) ≤ idx ∧ idx < 2 * (nLe : ℤ))
  let PC1 : ℕ → UL.WordStore → Prop := fun S ws =>
    ∀ s : Fin nLe, s.val < S → hRead ws 23 ((nLe + s.val : ℕ) : ℤ) = if act s then 1 else 0
  have hcntC1 : evalVal inp (hWrite ws₀ 10 42 0) (.readHeap 10 (.lit 2)) = (nLe : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws₀ 0 (Or.inr (by omega)), hDims.2.2.1]
  obtain ⟨ws1, hprC1, hDoneC1, hs1⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 2))
    (.writeHeap 23 (.add (.readHeap 10 (.lit 2)) (.readHeap 10 (.lit 42)))
      (.readHeap 23 (.readHeap 10 (.lit 42))))
    nLe 1 modC1 PC1 hws₀ (by omega) hIdx.2.2.1
    (by dsimp [modC1]; omega)
    (fun S ws v => by
      dsimp [PC1]; constructor <;> intro h s hs
      · have := h s hs; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h s hs)
    hcntC1 (fun _ h => False.elim (Nat.not_lt_zero _ h))
    (fun s hs ws hws hctr_s hpr_s hprev_s => by
      let sFin : Fin nLe := ⟨s, hs⟩
      have hnL_w : hRead ws 10 2 = (nLe : ℤ) := by
        rw [hpr_s 10 2 (by dsimp [modC1]; omega), hDims.2.2.1]
      have hsrc_w : hRead ws 23 (s : ℤ) = if act sFin then 1 else 0 := by
        rw [hpr_s 23 _ (by dsimp [modC1]; omega)]; exact hAct_ws sFin
      have hv_abs : (if act sFin then (1 : ℤ) else 0).natAbs ≤ 2 ^ K := by
        cases act sFin <;> simp [Nat.one_le_two_pow]
      have hw := exec_write hctx hws 23
        (.add (.readHeap 10 (.lit 2)) (.readHeap 10 (.lit 42)))
        (.readHeap 23 (.readHeap 10 (.lit 42)))
        ((nLe + s : ℕ) : ℤ) (if act sFin then 1 else 0)
        (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hnL_w, hctr_s]
            exact_mod_cast (rfl : nLe + s = nLe + s))
        (by simp only [evalVal_readHeap, evalVal_lit, hctr_s, hsrc_w])
        (Nat.cast_nonneg _)
        (Nat.cast_le.mpr (by have := hIdx.2.2.2.1; omega))
        hv_abs
      refine ⟨_, hw, ?_, hpr_s.trans (PreservesOutside.write ws _ (by dsimp [modC1]; omega)), ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega))]; exact hctr_s
      · intro s' hs'
        rcases (show s'.val < s ∨ s'.val = s by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]; exact hprev_s s' hlt
        · have hs_eq : s' = sFin := Fin.ext heq
          subst hs_eq; exact hRead_hWrite_self ws 23 _ _)
  -- Step 2: write 23[nLe + k] := 1
  have hnL_ws1 : hRead ws1 10 2 = (nLe : ℤ) := by
    rw [hprC1 10 2 (by dsimp [modC1]; omega), hDims.2.2.1]
  have hk_ws1 : hRead ws1 10 40 = (k.val : ℤ) := by
    rw [hprC1 10 40 (by dsimp [modC1]; omega), hk_ws]
  have hs2 := exec_write hctx hs1.2.1 23
    (.add (.readHeap 10 (.lit 2)) (.readHeap 10 (.lit 40))) (.lit 1)
    ((nLe + k.val : ℕ) : ℤ) 1
    (by simp only [evalVal_add, evalVal_readHeap, evalVal_lit, hnL_ws1, hk_ws1]
        exact_mod_cast (rfl : nLe + k.val = nLe + k.val))
    rfl (Nat.cast_nonneg _)
    (Nat.cast_le.mpr (by have := k.isLt; have := hIdx.2.2.2.1; omega))
    Nat.one_le_two_pow
  let ws2 := hWrite ws1 23 ((nLe + k.val : ℕ) : ℤ) 1
  have hws2 : StoreBounded 31 maxIdx K ws2 := hs2.2.1
  have hpr2 : PreservesOutside mod ws₀ ws2 :=
    (hprC1.mono (by intro t i h; dsimp [modC1] at h; dsimp [mod]; omega)).trans
      (PreservesOutside.write ws1 _ (by dsimp [mod]; omega))
  have hAct_ws2 : ∀ s : Fin nLe, hRead ws2 23 (s.val : ℤ) = if act s then 1 else 0 := by
    intro s
    have hne : (s.val : ℤ) ≠ ((nLe + k.val : ℕ) : ℤ) := by have := s.isLt; omega
    rw [hRead_hWrite_of_ne ws1 _ (Or.inr hne), hprC1 23 _ (by dsimp [modC1]; have := s.isLt; omega)]
    exact hAct_ws s
  have hCand_ws2 : ∀ s : Fin nLe, hRead ws2 23 ((nLe + s.val : ℕ) : ℤ) = if cand s then 1 else 0 := by
    intro s
    dsimp [cand]
    by_cases hsk : s = k
    · subst hsk
      rw [if_pos rfl]
      exact hRead_hWrite_self ws1 23 ((nLe + s.val : ℕ) : ℤ) 1
    · have hne : ((nLe + s.val : ℕ) : ℤ) ≠ ((nLe + k.val : ℕ) : ℤ) := by
        intro h; exact hsk (Fin.ext (by have := Int.ofNat.inj h; omega))
      rw [if_neg hsk]
      change hRead (hWrite ws1 23 ((nLe + k.val : ℕ) : ℤ) 1) 23 ((nLe + s.val : ℕ) : ℤ) = _
      rw [hRead_hWrite_of_ne ws1 _ (Or.inr hne)]
      exact hDoneC1 s s.isLt
  have hDim2 := hDims.preserve hpr2 (by intro idx _ _; dsimp [mod]; omega)
  have hCl2 := hCleared.preserve hpr2 (by intro t idx _ _; dsimp [mod]; omega)
  -- Step 3: buildOracleStmt (.readHeap 10 (.lit 2))
  obtain ⟨ws3, hpr3, hM_ora3, hd_ora3, hs3⟩ := exec_buildOracleStmt hctx h64
    ⟨hIdx.1, hIdx.2.1, hIdx.2.2.1, hIdx.2.2.2.2.1, hIdx.2.2.2.2.2.1⟩
    nLe (.readHeap 10 (.lit 2)) (by decide) (by decide) (fun _ _ h => h)
    M_eq d_eq M_le d_le cand hMeqK hdeqK hMleK hdleK
    hws2 hDim2 hCl2 hDim2.2.2.1 hCand_ws2
  have hpr3_mod : PreservesOutside mod ws₀ ws3 :=
    hpr2.trans (hpr3.mono (by intro t i h; dsimp [mod]; omega))
  have hDim3 := hDims.preserve hpr3_mod (by intro idx _ _; dsimp [mod]; omega)
  have hL_ws3 : hRead ws3 10 7 = (L : ℤ) := by
    rw [hpr3_mod 10 7 (by dsimp [mod]; omega), hL_ws]
  have hOraB := (buildOracle_entry_bound M_eq d_eq M_le d_le cand hMeqL hdeqL hMleL hdleL).1
  have h5BK : 5 * ellParamBsqrt (nVars + 2) L ≤ K :=
    (Nat.mul_le_mul_left 5 (ellParamBsqrt_mono_L hLB)).trans hBK
  -- Step 4: ellipsoidDecideStmt
  obtain ⟨ws4, hpr4, hDec4, hs4_raw⟩ := exec_ellipsoidDecideStmt hctx h64 hL1 h5BK
    ⟨hIdx.2.2.2.2.2.2.1, hIdx.2.2.2.2.2.2.2, hIdx.2.2.2.2.2.1⟩
    hOraB hs3.2.1 hDim3 hL_ws3 hM_ora3 hd_ora3
  have hs4 := hs4_raw.mono_steps (ellStepBound_mono_L hLB)
  have hpr4_mod : PreservesOutside mod ws₀ ws4 :=
    hpr3_mod.trans (hpr4.mono (by intro t i h; dsimp [mod]; omega))
  have hAct_ws4 : ∀ s : Fin nLe, hRead ws4 23 (s.val : ℤ) = if act s then 1 else 0 := by
    intro s
    rw [hpr4 23 _ (by omega), hpr3 23 _ (by omega)]
    exact hAct_ws2 s
  have hCand_ws4 : ∀ s : Fin nLe, hRead ws4 23 ((nLe + s.val : ℕ) : ℤ) = if cand s then 1 else 0 := by
    intro s
    rw [hpr4 23 _ (by omega), hpr3 23 _ (by omega)]
    exact hCand_ws2 s
  have hDim4 := hDims.preserve hpr4_mod (by intro idx _ _; dsimp [mod]; omega)
  have hCondEq : evalCondVal inp ws4 (.intEq (.readHeap 10 (.lit 17)) (.lit 1)) =
      ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
        (buildOracleM M_eq M_le cand) (buildOracleD d_eq d_le cand) := by
    simp only [evalCondVal_intEq, evalVal_readHeap, evalVal_lit]
    have hb : decide (hRead ws4 10 17 = 1) = (hRead ws4 10 17 == 1) := by
      apply Bool.eq_iff_iff.mpr; simp [beq_iff_eq]
    exact hb.trans hDec4
  -- Step 5: conditional copy cand -> act
  cases hDecBool : ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
      (buildOracleM M_eq M_le cand) (buildOracleD d_eq d_le cand)
  · refine ⟨ws4, hpr4_mod, ?_,
      (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps
        (exec_ite_false hctx (.intEq (.readHeap 10 (.lit 17)) (.lit 1)) _ .skip
          (hCondEq.trans hDecBool) (exec_skip hctx hs4.2.1)))))).mono_steps
        (by dsimp [m_iter, m_ora_b]; omega)⟩
    intro s; simpa [nextAct, hDecBool] using hAct_ws4 s
  · let modC2 : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ idx = 42) ∨ (t_id = 23 ∧ 0 ≤ idx ∧ idx < (nLe : ℤ))
    let PC2 : ℕ → UL.WordStore → Prop := fun S ws =>
      ∀ s : Fin nLe, s.val < S → hRead ws 23 (s.val : ℤ) = if cand s then 1 else 0
    have hcntC2 : evalVal inp (hWrite ws4 10 42 0) (.readHeap 10 (.lit 2)) = (nLe : ℤ) := by
      simp only [evalVal_readHeap, evalVal_lit]
      rw [hRead_hWrite_of_ne ws4 0 (Or.inr (by omega)), hDim4.2.2.1]
    obtain ⟨ws5, hprC2, hDoneC2, hs5_loop⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 2))
      (.writeHeap 23 (.readHeap 10 (.lit 42))
        (.readHeap 23 (.add (.readHeap 10 (.lit 2)) (.readHeap 10 (.lit 42)))))
      nLe 1 modC2 PC2 hs4.2.1 (by omega) hIdx.2.2.1
      (by dsimp [modC2]; omega)
      (fun S ws v => by
        dsimp [PC2]; constructor <;> intro h s hs
        · have := h s hs; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
        · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h s hs)
      hcntC2 (fun _ h => False.elim (Nat.not_lt_zero _ h))
      (fun s hs ws hws hctr_s hpr_s hprev_s => by
        let sFin : Fin nLe := ⟨s, hs⟩
        have hnL_w : hRead ws 10 2 = (nLe : ℤ) := by
          rw [hpr_s 10 2 (by dsimp [modC2]; omega), hDim4.2.2.1]
        have hsrc_w : hRead ws 23 ((nLe + s : ℕ) : ℤ) = if cand sFin then 1 else 0 := by
          rw [hpr_s 23 _ (by dsimp [modC2]; omega)]; exact hCand_ws4 sFin
        have hv_abs : (if cand sFin then (1 : ℤ) else 0).natAbs ≤ 2 ^ K := by
          cases cand sFin <;> simp [Nat.one_le_two_pow]
        have hw := exec_write hctx hws 23
          (.readHeap 10 (.lit 42))
          (.readHeap 23 (.add (.readHeap 10 (.lit 2)) (.readHeap 10 (.lit 42))))
          (s : ℤ) (if cand sFin then 1 else 0)
          (by simp only [evalVal_readHeap, evalVal_lit, hctr_s])
          (by have heq : (nLe : ℤ) + (s : ℤ) = ((nLe + s : ℕ) : ℤ) :=
                by exact_mod_cast (rfl : nLe + s = nLe + s)
              simp only [evalVal_readHeap, evalVal_add, evalVal_lit, hnL_w, hctr_s, heq, hsrc_w])
          (Nat.cast_nonneg _)
          (Nat.cast_le.mpr (hs.le.trans hIdx.2.2.1))
          hv_abs
        refine ⟨_, hw, ?_, hpr_s.trans (PreservesOutside.write ws _ (by dsimp [modC2]; omega)), ?_⟩
        · rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega))]; exact hctr_s
        · intro s' hs'
          rcases (show s'.val < s ∨ s'.val = s by omega) with hlt | heq
          · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]; exact hprev_s s' hlt
          · have hs_eq : s' = sFin := Fin.ext heq
            subst hs_eq; exact hRead_hWrite_self ws 23 _ _)
    have hex5 := exec_ite_true hctx (.intEq (.readHeap 10 (.lit 17)) (.lit 1)) _ .skip
      (hCondEq.trans hDecBool) hs5_loop
    have hpr5_mod : PreservesOutside mod ws₀ ws5 :=
      hpr4_mod.trans (hprC2.mono (by intro t i h; dsimp [modC2] at h; dsimp [mod]; omega))
    refine ⟨ws5, hpr5_mod, ?_,
      (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps hex5)))).mono_steps
        (by dsimp [m_iter, m_ora_b]; omega)⟩
    intro s; dsimp [nextAct]; rw [if_pos hDecBool]; exact hDoneC2 s s.isLt

def solveCoreIntLPStmt : UL.BitRAMStmt :=
  let nVarsE := UL.IntExpr.readHeap 10 (.lit 0)
  let nLeE := UL.IntExpr.readHeap 10 (.lit 2)
  let iE := UL.IntExpr.readHeap 10 (.lit 42)
  seqBitStmts
    [ computeMaxEntryStmt
    , ceilLog2Stmt
    , forLoopStmt 42 nLeE (.writeHeap 23 iE (.lit 0))
    , buildOracleStmt (.lit 0)
    , ellipsoidDecideStmt
    , .ite (.intEq (.readHeap 10 (.lit 17)) (.lit 1))
        (seqBitStmts
          [ forLoopStmt 40 nLeE activeSetStepStmt
          , buildActiveEqStmt
          , bareissSolveStmt
          , .writeHeap 30 (.lit 0) (.lit 1) ])
        (seqBitStmts
          [ .writeHeap 30 (.lit 0) (.lit 0)
          , forLoopStmt 42 nVarsE
              (seqBitStmts
                [ .writeHeap 31 (.mul (.lit 2) iE) (.lit 0)
                , .writeHeap 31 (.add (.mul (.lit 2) iE) (.lit 1)) (.lit 1) ]) ]) ]

def coreStepBound (nVars nEq nLe B_int : ℕ) : ℕ :=
  let m_bar := nEq + nLe
  let m_ora := 2 * nEq + 2 * nLe
  let m_ora_b := 10 + m_ora * (8 + 2 * nVars)
  let m_ell := ellStepBound nVars nEq nLe B_int
  let m_iter := 8 + 4 * nLe + m_ora_b + m_ell
  let m_bar_col := 15 + m_bar * (12 + 5 * (nVars + 1))
  let m_bareiss := 10 + nVars * (m_bar_col + 7)
  30 + m_bar * (7 + 5 * nVars) + 3 * B_int + 2 * nLe + m_ora_b + m_ell +
    nLe * (m_iter + 1) + (10 + m_bar * (6 + 2 * nVars) + 2 * nVars) + m_bareiss + 3 * nVars

theorem exec_solveCoreIntLPStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe B' : ℕ} (hB' : 1 ≤ B')
    (hctx : HeapCtx inp (solverMaxIdx nVars nEq nLe) (solverK nVars nEq nLe B'))
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (hMeq : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ (B' * (nVars + 2)))
    (hdeq : ∀ i, (d_eq i).natAbs ≤ 2 ^ (B' * (nVars + 2)))
    (hMle : ∀ k j, (M_le k j).natAbs ≤ 2 ^ (B' * (nVars + 2)))
    (hdle : ∀ k, (d_le k).natAbs ≤ 2 ^ (B' * (nVars + 2)))
    {ws₀ : UL.WordStore}
    (hws₀ : StoreBounded 31 (solverMaxIdx nVars nEq nLe) (solverK nVars nEq nLe B') ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hCleared : ClearedLPInHeap M_eq d_eq M_le d_le ws₀) :
    let maxIdx := solverMaxIdx nVars nEq nLe
    let K := solverK nVars nEq nLe B'
    let B_int := B' * (nVars + 2)
    let res := solveCoreIntLP M_eq d_eq M_le d_le
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ 6 ≤ idx) ∨ (23 ≤ t_id ∧ t_id ≤ 31)
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      hRead ws₁ 30 0 = res.1 ∧
      (∀ j : Fin nVars,
        hRead ws₁ 31 (2 * (j.val : ℤ)) = res.2.1 j ∧
        hRead ws₁ 31 (2 * (j.val : ℤ) + 1) = res.2.2 j) ∧
      ExecBit inp maxIdx K solveCoreIntLPStmt ws₀ ws₁
        (coreStepBound nVars nEq nLe B_int * stepU)
        (coreStepBound nVars nEq nLe B_int * stepB K) := by
  intro maxIdx K B_int res mod
  obtain ⟨h64, hnV, hnE, hnL, hnV1, _, h2nV, h2nL, hmBar, hmOra,
    hnEnV, hnLnV, hmOraN, h4N, h2NN, hmBarW, h2mBarW, hmBarP⟩ :=
    solverMaxIdx_bounds nVars nEq nLe
  have hB_ge2 : 2 ≤ B_int := by dsimp [B_int]; nlinarith only [hB']
  have hPowGe2 : 2 ≤ 2 ^ B_int := by
    calc 2 = 2 ^ 1 := rfl
      _ ≤ 2 ^ B_int := Nat.pow_le_pow_right (by omega) (by omega)
  have hBK : B_int ≤ K := bInt_le_solverK
  have hPowBK : 2 ^ B_int ≤ 2 ^ K := Nat.pow_le_pow_right (by omega) hBK
  have hMeqK : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ K := fun i j => (hMeq i j).trans hPowBK
  have hdeqK : ∀ i, (d_eq i).natAbs ≤ 2 ^ K := fun i => (hdeq i).trans hPowBK
  have hMleK : ∀ k j, (M_le k j).natAbs ≤ 2 ^ K := fun k j => (hMle k j).trans hPowBK
  have hdleK : ∀ k, (d_le k).natAbs ≤ 2 ^ K := fun k => (hdle k).trans hPowBK
  -- Step 1: computeMaxEntryStmt
  obtain ⟨ws1, h6_ws1, hpr1, hs1⟩ := exec_computeMaxEntryStmt hctx h64
    ⟨hnV, hnE, hnL, hnEnV, hnLnV⟩ M_eq d_eq M_le d_le hMeqK hdeqK hMleK hdleK
    hws₀ hDims hCleared
  let U_max := computeMaxEntry M_eq d_eq M_le d_le
  obtain ⟨hU2, hU_ub_nat, hMeqU, hdeqU, hMleU, hdleU⟩ :=
    computeMaxEntry_spec M_eq d_eq M_le d_le (2 ^ B_int) hPowGe2 hMeq hdeq hMle hdle
  have hU_ub : U_max ≤ (2 : ℤ) ^ B_int := by simpa using hU_ub_nat
  have hpr1_mod : PreservesOutside mod ws₀ ws1 :=
    hpr1.mono (by intro t i h; dsimp [mod]; omega)
  -- Step 2: ceilLog2Stmt
  obtain ⟨ws2, hL_ws2, _, hpr2, hs2⟩ := exec_ceilLog2Stmt hctx h64
    (by omega : 1 ≤ B_int) hBK hU2 hU_ub hs1.2.1 h6_ws1
  let L := (ceilLog2Pure U_max).1
  obtain ⟨hL1, hLB, hpow_eq, hU_le_pow⟩ :=
    ceilLog2Pure_spec U_max B_int (by omega) hU_ub
  have hMeqL : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ L := by
    intro i j; have := (hMeqU i j).trans (hpow_eq ▸ hU_le_pow); exact_mod_cast this
  have hdeqL : ∀ i, (d_eq i).natAbs ≤ 2 ^ L := by
    intro i; have := (hdeqU i).trans (hpow_eq ▸ hU_le_pow); exact_mod_cast this
  have hMleL : ∀ k j, (M_le k j).natAbs ≤ 2 ^ L := by
    intro k j; have := (hMleU k j).trans (hpow_eq ▸ hU_le_pow); exact_mod_cast this
  have hdleL : ∀ k, (d_le k).natAbs ≤ 2 ^ L := by
    intro k; have := (hdleU k).trans (hpow_eq ▸ hU_le_pow); exact_mod_cast this
  have hpr2_mod : PreservesOutside mod ws₀ ws2 :=
    hpr1_mod.trans (hpr2.mono (by intro t i h; dsimp [mod]; omega))
  have hDim2 := hDims.preserve hpr2_mod (by intro idx _ _; dsimp [mod]; omega)
  -- Step 3: initAct := false in 23[0 .. nLe - 1]
  let initAct : Fin nLe → Bool := fun _ => false
  let modInitA : ℕ → ℤ → Prop := fun t_id idx =>
    (t_id = 10 ∧ idx = 42) ∨ (t_id = 23 ∧ 0 ≤ idx ∧ idx < (nLe : ℤ))
  let PInitA : ℕ → UL.WordStore → Prop := fun S ws =>
    ∀ s : Fin nLe, s.val < S → hRead ws 23 (s.val : ℤ) = 0
  have hcntInitA : evalVal inp (hWrite ws2 10 42 0) (.readHeap 10 (.lit 2)) = (nLe : ℤ) := by
    simp only [evalVal_readHeap, evalVal_lit]
    rw [hRead_hWrite_of_ne ws2 0 (Or.inr (by omega)), hDim2.2.2.1]
  obtain ⟨ws3, hprInitA, hDoneInitA, hs3⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 2))
    (.writeHeap 23 (.readHeap 10 (.lit 42)) (.lit 0))
    nLe 1 modInitA PInitA hs2.2.1 (by omega) hnL
    (by dsimp [modInitA]; omega)
    (fun S ws v => by
      dsimp [PInitA]; constructor <;> intro h s hs
      · have := h s hs; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
      · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h s hs)
    hcntInitA (fun _ h => False.elim (Nat.not_lt_zero _ h))
    (fun s hs ws hws hctr_s hpr_s hprev_s => by
      have hw := exec_write hctx hws 23 (.readHeap 10 (.lit 42)) (.lit 0)
        (s : ℤ) 0 (by simp only [evalVal_readHeap, evalVal_lit, hctr_s]) rfl (Nat.cast_nonneg _)
        (Nat.cast_le.mpr (hs.le.trans hnL)) (by simp)
      refine ⟨_, hw, ?_, hpr_s.trans (PreservesOutside.write ws _ (by dsimp [modInitA]; omega)), ?_⟩
      · rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega))]; exact hctr_s
      · intro s' hs'
        rcases (show s'.val < s ∨ s'.val = s by omega) with hlt | heq
        · rw [hRead_hWrite_of_ne ws _ (Or.inr (by omega))]; exact hprev_s s' hlt
        · rw [heq]; exact hRead_hWrite_self ws 23 _ _)
  have hpr3_mod : PreservesOutside mod ws₀ ws3 :=
    hpr2_mod.trans (hprInitA.mono (by intro t i h; dsimp [modInitA] at h; dsimp [mod]; omega))
  have hDim3 := hDims.preserve hpr3_mod (by intro idx _ _; dsimp [mod]; omega)
  have hCl3 := hCleared.preserve hpr3_mod (by intro t idx _ _; dsimp [mod]; omega)
  have hInitA_ws3 : ∀ s : Fin nLe, hRead ws3 23 ((0 + s.val : ℕ) : ℤ) = if initAct s then 1 else 0 := by
    intro s; simpa [initAct] using hDoneInitA s s.isLt
  -- Step 4: buildOracleStmt (.lit 0)
  obtain ⟨ws4, hpr4, hM_ora4, hd_ora4, hs4⟩ := exec_buildOracleStmt hctx h64
    ⟨hnV, hnE, hnL, hmOraN, hmOra⟩ 0 (.lit 0) (by decide) (by decide) (fun _ _ _ => rfl)
    M_eq d_eq M_le d_le initAct hMeqK hdeqK hMleK hdleK
    hs3.2.1 hDim3 hCl3 rfl hInitA_ws3
  have hpr4_mod : PreservesOutside mod ws₀ ws4 :=
    hpr3_mod.trans (hpr4.mono (by intro t i h; dsimp [mod]; omega))
  have hDim4 := hDims.preserve hpr4_mod (by intro idx _ _; dsimp [mod]; omega)
  have hL_ws4 : hRead ws4 10 7 = (L : ℤ) := by
    rw [hpr4 10 7 (by omega), hprInitA 10 7 (by dsimp [modInitA]; omega), hL_ws2]
  have h5BK_int : 5 * ellParamBsqrt (nVars + 2) B_int ≤ K :=
    five_ellParamBsqrt_le_solverK le_rfl
  have h5BK : 5 * ellParamBsqrt (nVars + 2) L ≤ K :=
    five_ellParamBsqrt_le_solverK hLB
  have hOraInitB := (buildOracle_entry_bound M_eq d_eq M_le d_le initAct hMeqL hdeqL hMleL hdleL).1
  -- Step 5: ellipsoidDecideStmt
  obtain ⟨ws5, hpr5, hDec5, hs5_raw⟩ := exec_ellipsoidDecideStmt hctx h64 hL1 h5BK
    ⟨h4N, h2NN, hmOra⟩ hOraInitB hs4.2.1 hDim4 hL_ws4 hM_ora4 hd_ora4
  have hs5 := hs5_raw.mono_steps (ellStepBound_mono_L hLB)
  have hpr5_mod : PreservesOutside mod ws₀ ws5 :=
    hpr4_mod.trans (hpr5.mono (by intro t i h; dsimp [mod]; omega))
  have hCond5 : evalCondVal inp ws5 (.intEq (.readHeap 10 (.lit 17)) (.lit 1)) =
      ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
        (buildOracleM M_eq M_le initAct) (buildOracleD d_eq d_le initAct) := by
    simp only [evalCondVal_intEq, evalVal_readHeap, evalVal_lit]
    have hb : decide (hRead ws5 10 17 = 1) = (hRead ws5 10 17 == 1) := by
      apply Bool.eq_iff_iff.mpr; simp [beq_iff_eq]
    exact hb.trans hDec5
  have hDim5 := hDims.preserve hpr5_mod (by intro idx _ _; dsimp [mod]; omega)
  have hCl5 := hCleared.preserve hpr5_mod (by intro t idx _ _; dsimp [mod]; omega)
  have hL_ws5 : hRead ws5 10 7 = (L : ℤ) := by
    rw [hpr5 10 7 (by omega), hL_ws4]
  have hInitA_ws5 : ∀ s : Fin nLe, hRead ws5 23 (s.val : ℤ) = if initAct s then 1 else 0 := by
    intro s
    rw [hpr5 23 _ (by omega), hpr4 23 _ (by omega)]
    simpa using hInitA_ws3 s
  cases hInitBool : ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
      (buildOracleM M_eq M_le initAct) (buildOracleD d_eq d_le initAct)
  · -- Infeasible branch
    have hw_f0 := exec_write hctx hs5.2.1 30 (.lit 0) (.lit 0) 0 0 rfl rfl
      (by omega) (by omega) (by simp)
    let ws6 := hWrite ws5 30 0 0
    have hws6 : StoreBounded 31 maxIdx K ws6 := hw_f0.2.1
    have hpr6_mod : PreservesOutside mod ws₀ ws6 :=
      hpr5_mod.trans (PreservesOutside.write ws5 _ (by dsimp [mod]; omega))
    have hDim6 := hDims.preserve hpr6_mod (by intro idx _ _; dsimp [mod]; omega)
    let modZ : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ idx = 42) ∨ (t_id = 31 ∧ 0 ≤ idx ∧ idx < 2 * (nVars : ℤ))
    let PZ : ℕ → UL.WordStore → Prop := fun C ws =>
      ∀ j : Fin nVars, j.val < C →
        hRead ws 31 (2 * (j.val : ℤ)) = 0 ∧ hRead ws 31 (2 * (j.val : ℤ) + 1) = 1
    have hcntZ : evalVal inp (hWrite ws6 10 42 0) (.readHeap 10 (.lit 0)) = (nVars : ℤ) := by
      simp only [evalVal_readHeap, evalVal_lit]
      rw [hRead_hWrite_of_ne ws6 0 (Or.inr (by omega)), hDim6.1]
    obtain ⟨ws7, hprZ, hDoneZ, hsZ⟩ := exec_for_frame hctx 42 (.readHeap 10 (.lit 0))
      (seqBitStmts
        [ .writeHeap 31 (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 0)
        , .writeHeap 31 (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1)) (.lit 1) ])
      nVars 2 modZ PZ hws6 (by omega) hnV
      (by dsimp [modZ]; omega)
      (fun C ws v => by
        dsimp [PZ]; constructor <;> intro h j hj
        · obtain ⟨h1, h2⟩ := h j hj
          rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at h1 h2
          exact ⟨h1, h2⟩
        · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide)),
              hRead_hWrite_of_ne ws v (Or.inl (by decide))]
          exact h j hj)
      hcntZ (fun _ h => False.elim (Nat.not_lt_zero _ h))
      (fun j hj ws hws hctr_j hpr_j hprev_j => by
        have hw1 := exec_write hctx hws 31 (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 0)
          (2 * (j : ℤ)) 0 (by simp [hctr_j]) rfl (by omega) (by omega) (by simp)
        let wsa := hWrite ws 31 (2 * (j : ℤ)) 0
        have hwsa : StoreBounded 31 maxIdx K wsa := hw1.2.1
        have hj_a : hRead wsa 10 42 = (j : ℤ) := by
          rw [hRead_hWrite_of_ne ws _ (Or.inl (by omega)), hctr_j]
        have hw2 := exec_write hctx hwsa 31
          (.add (.mul (.lit 2) (.readHeap 10 (.lit 42))) (.lit 1)) (.lit 1)
          (2 * (j : ℤ) + 1) 1 (by simp [hj_a]) rfl (by omega) (by omega) Nat.one_le_two_pow
        refine ⟨_, hw1.seq_steps hw2, ?_,
          (hpr_j.trans (PreservesOutside.write ws _ (by dsimp [modZ]; omega))).trans
            (PreservesOutside.write wsa _ (by dsimp [modZ]; omega)), ?_⟩
        · rw [hRead_hWrite_of_ne wsa _ (Or.inl (by omega)), hj_a]
        · intro j' hj'
          rcases (show j'.val < j ∨ j'.val = j by omega) with hlt | heq
          · rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega)),
                hRead_hWrite_of_ne wsa _ (Or.inr (by omega)),
                hRead_hWrite_of_ne ws _ (Or.inr (by omega))]
            exact hprev_j j' hlt
          · rw [heq]
            exact ⟨by rw [hRead_hWrite_of_ne wsa _ (Or.inr (by omega))]
                      exact hRead_hWrite_self ws 31 _ 0,
                   hRead_hWrite_self wsa 31 _ 1⟩)
    have hpr7_mod : PreservesOutside mod ws₀ ws7 :=
      hpr6_mod.trans (hprZ.mono (by intro t i h; dsimp [modZ] at h; dsimp [mod]; omega))
    have hres_eq : res = (0, fun _ => 0, fun _ => 1) := by
      dsimp [res, solveCoreIntLP]
      change (if ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
        (buildOracleM M_eq M_le initAct) (buildOracleD d_eq d_le initAct) then _ else _) = _
      rw [if_neg (by rw [hInitBool]; decide)]
    refine ⟨ws7, hpr7_mod, ?_, ?_,
      (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps (hs5.seq_steps
        (exec_ite_false hctx (.intEq (.readHeap 10 (.lit 17)) (.lit 1)) _ _
          (hCond5.trans hInitBool) (hw_f0.seq_steps hsZ))))))).mono_steps
        (by dsimp [coreStepBound]; omega)⟩
    · rw [hres_eq, hprZ 30 0 (by dsimp [modZ]; omega)]; exact hRead_hWrite_self ws5 30 0 0
    · intro j; rw [hres_eq]; exact hDoneZ j j.isLt
  · -- Feasible branch: active-set loop + buildActiveEqStmt + bareissSolveStmt
    let actStepPure : (Fin nLe → Bool) → Fin nLe → (Fin nLe → Bool) := fun act k =>
      let cand : Fin nLe → Bool := fun s => if s = k then true else act s
      if ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
          (buildOracleM M_eq M_le cand) (buildOracleD d_eq d_le cand) then cand else act
    let actAt : (k : ℕ) → k ≤ nLe → (Fin nLe → Bool) := fun k hk =>
      Fin.foldl k (fun act (s : Fin k) => actStepPure act ⟨s.val, lt_of_lt_of_le s.isLt hk⟩) initAct
    let m_ora_b := 10 + (2 * nEq + 2 * nLe) * (8 + 2 * nVars)
    let m_iter := 8 + 4 * nLe + m_ora_b + ellStepBound nVars nEq nLe B_int
    let modAct : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ ((9 ≤ idx ∧ idx ≤ 29) ∨ (40 ≤ idx ∧ idx ≤ 43))) ∨
      (23 ≤ t_id ∧ t_id ≤ 27)
    let PAct : ℕ → UL.WordStore → Prop := fun k ws =>
      ∀ hk : k ≤ nLe, ∀ s : Fin nLe, hRead ws 23 (s.val : ℤ) = if actAt k hk s then 1 else 0
    have hcntAct : evalVal inp (hWrite ws5 10 40 0) (.readHeap 10 (.lit 2)) = (nLe : ℤ) := by
      simp only [evalVal_readHeap, evalVal_lit]
      rw [hRead_hWrite_of_ne ws5 0 (Or.inr (by omega)), hDim5.2.2.1]
    obtain ⟨ws6, hprAct, hDoneAct, hsAct⟩ := exec_for_frame hctx 40 (.readHeap 10 (.lit 2))
      activeSetStepStmt nLe m_iter modAct PAct hs5.2.1 (by omega) hnL
      (by dsimp [modAct]; omega)
      (fun k ws v => by
        dsimp [PAct]; constructor <;> intro h hk s
        · have := h hk s; rwa [hRead_hWrite_of_ne ws v (Or.inl (by decide))] at this
        · rw [hRead_hWrite_of_ne ws v (Or.inl (by decide))]; exact h hk s)
      hcntAct
      (fun _ s => by simpa [actAt, Fin.foldl_zero] using hInitA_ws5 s)
      (fun k hk ws hws hctr_k hpr_k hprev_k => by
        let kFin : Fin nLe := ⟨k, hk⟩
        have hDim_w := hDims.preserve
          (hpr5_mod.trans (hpr_k.mono (by intro t i h; dsimp [modAct] at h; dsimp [mod]; omega)))
          (by intro idx _ _; dsimp [mod]; omega)
        have hCl_w := hCleared.preserve
          (hpr5_mod.trans (hpr_k.mono (by intro t i h; dsimp [modAct] at h; dsimp [mod]; omega)))
          (by intro t idx _ _; dsimp [mod]; omega)
        have hL_w : hRead ws 10 7 = (L : ℤ) := by
          rw [hpr_k 10 7 (by dsimp [modAct]; omega), hL_ws5]
        obtain ⟨ws_s, hpr_s, hAct_s, hex_s⟩ := exec_activeSetStepStmt hctx h64 hL1 hLB h5BK_int
          ⟨hnV, hnE, hnL, h2nL, hmOraN, hmOra, h4N, h2NN⟩
          M_eq d_eq M_le d_le hMeqL hdeqL hMleL hdleL
          (actAt k hk.le) kFin hws hDim_w hL_w hctr_k hCl_w (hprev_k hk.le)
        refine ⟨ws_s, hex_s, ?_,
          hpr_k.trans (hpr_s.mono (by intro t i h; dsimp [modAct]; omega)),
          fun hk1 s => ?_⟩
        · rw [hpr_s 10 40 (by omega), hctr_k]
        · have hfold : actAt (k + 1) hk1 = actStepPure (actAt k hk.le) kFin := by
            dsimp [actAt]; rw [Fin.foldl_succ_last]; rfl
          rw [hfold]; exact hAct_s s)
    let finalAct := actAt nLe le_rfl
    have hpr6_mod : PreservesOutside mod ws₀ ws6 :=
      hpr5_mod.trans (hprAct.mono (by intro t i h; dsimp [modAct] at h; dsimp [mod]; omega))
    have hDim6 := hDims.preserve hpr6_mod (by intro idx _ _; dsimp [mod]; omega)
    have hCl6 := hCleared.preserve hpr6_mod (by intro t idx _ _; dsimp [mod]; omega)
    -- buildActiveEqStmt
    obtain ⟨ws7, hpr7, hBar7, hs7⟩ := exec_buildActiveEqStmt hctx h64
      ⟨hnV, hnE, hnL, hnV1, hmBar, hmBarW, hmBarP⟩
      M_eq d_eq M_le d_le finalAct hMeqK hdeqK hMleK hdleK
      hsAct.2.1 hDim6 hCl6 (hDoneAct le_rfl)
    have hpr7_mod : PreservesOutside mod ws₀ ws7 :=
      hpr6_mod.trans (hpr7.mono (by intro t i h; dsimp [mod]; omega))
    have hDim7 := hDims.preserve hpr7_mod (by intro idx _ _; dsimp [mod]; omega)
    -- bareissSolveStmt
    have hActEqM_B : ∀ r j, (buildActiveEqM M_eq M_le finalAct r j).natAbs ≤ 2 ^ B_int := by
      intro r j; dsimp [buildActiveEqM]; split_ifs; exact hMeq _ j; exact hMle _ j; simp
    have hActEqD_B : ∀ r, (buildActiveEqD d_eq d_le finalAct r).natAbs ≤ 2 ^ B_int := by
      intro r; dsimp [buildActiveEqD]; split_ifs; exact hdeq _; exact hdle _; simp
    obtain ⟨ws8, hpr8, hSol8, hs8⟩ := exec_bareissSolveStmt hctx h64
      ⟨hnV, hnV1, h2nV, hmBar, h2mBarW, hmBarP⟩
      (buildActiveEqM M_eq M_le finalAct) (buildActiveEqD d_eq d_le finalAct)
      Nat.one_le_two_pow hActEqM_B hActEqD_B
      (bareiss_bound_le_two_pow_solverK nVars nEq nLe B')
      hs7.2.1 hDim7 hBar7
    have hpr8_mod : PreservesOutside mod ws₀ ws8 :=
      hpr7_mod.trans (hpr8.mono (by intro t i h; dsimp [mod]; omega))
    -- Write flag := 1
    have hs9 := exec_write hctx hs8.2.1 30 (.lit 0) (.lit 1) 0 1 rfl rfl
      (by omega) (by omega) Nat.one_le_two_pow
    let ws9 := hWrite ws8 30 0 1
    have hpr9_mod : PreservesOutside mod ws₀ ws9 :=
      hpr8_mod.trans (PreservesOutside.write ws8 _ (by dsimp [mod]; omega))
    have hres_eq : res =
        (1, (bareissSolve (buildActiveEqM M_eq M_le finalAct) (buildActiveEqD d_eq d_le finalAct)).1,
            (bareissSolve (buildActiveEqM M_eq M_le finalAct) (buildActiveEqD d_eq d_le finalAct)).2) := by
      dsimp [res, solveCoreIntLP]
      change (if ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
        (buildOracleM M_eq M_le initAct) (buildOracleD d_eq d_le initAct) then _ else _) = _
      rw [if_pos hInitBool]
    refine ⟨ws9, hpr9_mod, ?_, ?_,
      (hs1.seq_steps (hs2.seq_steps (hs3.seq_steps (hs4.seq_steps (hs5.seq_steps
        (exec_ite_true hctx (.intEq (.readHeap 10 (.lit 17)) (.lit 1)) _ _
          (hCond5.trans hInitBool) (hsAct.seq_steps (hs7.seq_steps (hs8.seq_steps hs9))))))))).mono_steps
        (by dsimp [coreStepBound, m_iter, m_ora_b]; omega)⟩
    · rw [hres_eq]; exact hRead_hWrite_self ws8 30 0 1
    · intro j
      rw [hres_eq, hRead_hWrite_of_ne ws8 _ (Or.inl (by omega)),
          hRead_hWrite_of_ne ws8 _ (Or.inl (by omega))]
      exact hSol8 j

def solveRationalLPStmt : UL.BitRAMStmt :=
  seqBitStmts
    [ clearBlockStmt 1 11 12 13 14 19 20
    , clearBlockStmt 2 15 16 17 18 21 22
    , solveCoreIntLPStmt ]

def solverStepBound (nVars nEq nLe B' : ℕ) : ℕ :=
  (4 + (nEq + nLe) * (9 + 4 * nVars)) + coreStepBound nVars nEq nLe (B' * (nVars + 2))

theorem exec_solveRationalLPStmt {d : ℕ} {inp : UL.BitRAMInput d}
    {nVars nEq nLe B' : ℕ} (hB' : 1 ≤ B')
    (hctx : HeapCtx inp (solverMaxIdx nVars nEq nLe) (solverK nVars nEq nLe B'))
    (A_eq_num A_eq_den : Fin nEq → Fin nVars → ℤ)
    (b_eq_num b_eq_den : Fin nEq → ℤ)
    (A_le_num A_le_den : Fin nLe → Fin nVars → ℤ)
    (b_le_num b_le_den : Fin nLe → ℤ)
    (hEqDenPos : ∀ i j, 0 < A_eq_den i j)
    (hbEqDenPos : ∀ i, 0 < b_eq_den i)
    (hLeDenPos : ∀ k j, 0 < A_le_den k j)
    (hbLeDenPos : ∀ k, 0 < b_le_den k)
    (hEqNumB : ∀ i j, (A_eq_num i j).natAbs ≤ 2 ^ B')
    (hEqDenB : ∀ i j, (A_eq_den i j).natAbs ≤ 2 ^ B')
    (hbEqNumB : ∀ i, (b_eq_num i).natAbs ≤ 2 ^ B')
    (hbEqDenB : ∀ i, (b_eq_den i).natAbs ≤ 2 ^ B')
    (hLeNumB : ∀ k j, (A_le_num k j).natAbs ≤ 2 ^ B')
    (hLeDenB : ∀ k j, (A_le_den k j).natAbs ≤ 2 ^ B')
    (hbLeNumB : ∀ k, (b_le_num k).natAbs ≤ 2 ^ B')
    (hbLeDenB : ∀ k, (b_le_den k).natAbs ≤ 2 ^ B')
    {ws₀ : UL.WordStore}
    (hws₀ : StoreBounded 31 (solverMaxIdx nVars nEq nLe) (solverK nVars nEq nLe B') ws₀)
    (hDims : DimsInHeap nVars nEq nLe ws₀)
    (hRat : RatLPInHeap A_eq_num A_eq_den b_eq_num b_eq_den A_le_num A_le_den b_le_num b_le_den ws₀) :
    let maxIdx := solverMaxIdx nVars nEq nLe
    let K := solverK nVars nEq nLe B'
    let res := solveRationalLP A_eq_num A_eq_den b_eq_num b_eq_den A_le_num A_le_den b_le_num b_le_den
    let mod : ℕ → ℤ → Prop := fun t_id idx =>
      (t_id = 10 ∧ 6 ≤ idx) ∨ (19 ≤ t_id ∧ t_id ≤ 31)
    ∃ ws₁ : UL.WordStore,
      PreservesOutside mod ws₀ ws₁ ∧
      hRead ws₁ 30 0 = res.1 ∧
      (∀ j : Fin nVars,
        hRead ws₁ 31 (2 * (j.val : ℤ)) = res.2.1 j ∧
        hRead ws₁ 31 (2 * (j.val : ℤ) + 1) = res.2.2 j) ∧
      ExecBit inp maxIdx K solveRationalLPStmt ws₀ ws₁
        (solverStepBound nVars nEq nLe B' * stepU)
        (solverStepBound nVars nEq nLe B' * stepB K) := by
  intro maxIdx K res mod
  obtain ⟨h64, hnV, hnE, hnL, _, _, _, _, _, _, hnEnV, hnLnV, _, _, _, _, _, _⟩ :=
    solverMaxIdx_bounds nVars nEq nLe
  have hBK : B' * (nVars + 2) ≤ K := bInt_le_solverK
  -- Clear equality block -> Tables 19, 20
  obtain ⟨ws1, hpr1, hMeq_ws1, hdeq_ws1, hs1⟩ := exec_clearBlockStmt
    (tANum := 11) (tADen := 12) (tbNum := 13) (tbDen := 14) (tM := 19) (td := 20)
    hctx h64 ⟨hnE, hnV, hnEnV⟩ hBK 1 (by decide) (by decide)
    (by decide) (by decide)
    A_eq_num A_eq_den b_eq_num b_eq_den hEqDenPos hbEqDenPos
    hEqNumB hEqDenB hbEqNumB hbEqDenB
    hws₀ hDims.1 hDims.2.1 hRat.1 hRat.2.1
  have hpr1_mod : PreservesOutside mod ws₀ ws1 :=
    hpr1.mono (by intro t i h; dsimp [mod]; omega)
  have hDim1 := hDims.preserve hpr1_mod (by intro idx _ _; dsimp [mod]; omega)
  have hAle_ws1 : ∀ k j,
      hRead ws1 15 ((k.val * nVars + j.val : ℕ) : ℤ) = A_le_num k j ∧
      hRead ws1 16 ((k.val * nVars + j.val : ℕ) : ℤ) = A_le_den k j := by
    intro k j
    rw [hpr1 15 _ (by omega), hpr1 16 _ (by omega)]
    exact hRat.2.2.1 k j
  have hble_ws1 : ∀ k,
      hRead ws1 17 (k.val : ℤ) = b_le_num k ∧
      hRead ws1 18 (k.val : ℤ) = b_le_den k := by
    intro k
    rw [hpr1 17 _ (by omega), hpr1 18 _ (by omega)]
    exact hRat.2.2.2 k
  -- Clear inequality block -> Tables 21, 22
  obtain ⟨ws2, hpr2, hMle_ws2, hdle_ws2, hs2⟩ := exec_clearBlockStmt
    (tANum := 15) (tADen := 16) (tbNum := 17) (tbDen := 18) (tM := 21) (td := 22)
    hctx h64 ⟨hnL, hnV, hnLnV⟩ hBK 2 (by decide) (by decide)
    (by decide) (by decide)
    A_le_num A_le_den b_le_num b_le_den hLeDenPos hbLeDenPos
    hLeNumB hLeDenB hbLeNumB hbLeDenB
    hs1.2.1 hDim1.1 hDim1.2.2.1 hAle_ws1 hble_ws1
  have hpr2_mod : PreservesOutside mod ws₀ ws2 :=
    hpr1_mod.trans (hpr2.mono (by intro t i h; dsimp [mod]; omega))
  have hDim2 := hDims.preserve hpr2_mod (by intro idx _ _; dsimp [mod]; omega)
  let M_eq : Fin nEq → Fin nVars → ℤ :=
    fun i => clearRowCoeffs nVars (A_eq_num i) (A_eq_den i) (b_eq_den i)
  let d_eq : Fin nEq → ℤ :=
    fun i => clearRowRhs nVars (A_eq_den i) (b_eq_num i) (b_eq_den i)
  let M_le : Fin nLe → Fin nVars → ℤ :=
    fun k => clearRowCoeffs nVars (A_le_num k) (A_le_den k) (b_le_den k)
  let d_le : Fin nLe → ℤ :=
    fun k => clearRowRhs nVars (A_le_den k) (b_le_num k) (b_le_den k)
  have hCl2 : ClearedLPInHeap M_eq d_eq M_le d_le ws2 := by
    refine ⟨fun i j => ?_, fun i => ?_, hMle_ws2, hdle_ws2⟩
    · rw [hpr2 19 _ (by omega)]; exact hMeq_ws1 i j
    · rw [hpr2 20 _ (by omega)]; exact hdeq_ws1 i
  have hEqSpec := fun i => clearRow_spec (A_eq_num i) (A_eq_den i) (b_eq_num i) (b_eq_den i)
    (hEqDenPos i) (hbEqDenPos i) (hEqNumB i) (hEqDenB i) (hbEqNumB i) (hbEqDenB i)
  have hLeSpec := fun k => clearRow_spec (A_le_num k) (A_le_den k) (b_le_num k) (b_le_den k)
    (hLeDenPos k) (hbLeDenPos k) (hLeNumB k) (hLeDenB k) (hbLeNumB k) (hbLeDenB k)
  obtain ⟨ws3, hpr3, hFlag3, hSol3, hs3⟩ := exec_solveCoreIntLPStmt hB' hctx
    M_eq d_eq M_le d_le
    (fun i j => (hEqSpec i).2.2.1 j) (fun i => (hEqSpec i).2.2.2.1)
    (fun k j => (hLeSpec k).2.2.1 j) (fun k => (hLeSpec k).2.2.2.1)
    hs2.2.1 hDim2 hCl2
  have hpr3_mod : PreservesOutside mod ws₀ ws3 :=
    hpr2_mod.trans (hpr3.mono (by intro t i h; dsimp [mod]; omega))
  exact ⟨ws3, hpr3_mod, hFlag3, hSol3,
    (hs1.seq_steps (hs2.seq_steps hs3)).mono_steps
      (by unfold solverStepBound; nlinarith)⟩

end UL.Proof.cit_gls88_rational_lp.RacerCG
