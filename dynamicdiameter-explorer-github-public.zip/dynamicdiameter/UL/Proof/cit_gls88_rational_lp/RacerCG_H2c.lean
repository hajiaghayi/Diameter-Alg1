import Mathlib
import UL.Proof.cit_gls88_rational_lp.RacerCG_H1b
import UL.Proof.cit_gls88_rational_lp.RacerCG_H2b
set_option autoImplicit false

namespace UL.Proof.cit_gls88_rational_lp.RacerCG

/-! ### 1. Exact Integer `ceilLog2Pure` -/

def absInt (z : ℤ) : ℤ := if 0 ≤ z then z else -z
def maxInt (a b : ℤ) : ℤ := if a ≤ b then b else a

@[simp] theorem absInt_eq_natAbs (z : ℤ) : absInt z = (z.natAbs : ℤ) := by
  unfold absInt
  rcases le_or_gt 0 z with h | h
  · rw [if_pos h, Int.natAbs_of_nonneg h]
  · rw [if_neg (not_le.mpr h), Int.ofNat_natAbs_of_nonpos h.le]

@[simp] theorem maxInt_eq_max (a b : ℤ) : maxInt a b = max a b := by
  unfold maxInt
  by_cases h : a ≤ b
  · rw [if_pos h, max_eq_right h]
  · rw [if_neg h, max_eq_left (le_of_not_ge h)]

def ceilLog2Aux (U_max : ℤ) : ℕ → ℕ → ℤ → ℕ × ℤ
  | 0, L, pow2 => (L, pow2)
  | fuel + 1, L, pow2 =>
      if pow2 < U_max then ceilLog2Aux U_max fuel (L + 1) (2 * pow2) else (L, pow2)

def ceilLog2Pure (U_max : ℤ) : ℕ × ℤ :=
  ceilLog2Aux U_max U_max.toNat 1 2

theorem ceilLog2Pure_spec (U_max : ℤ) (B_ub : ℕ) (hB : 1 ≤ B_ub)
    (hU_ub : U_max ≤ (2 : ℤ) ^ B_ub) :
    let (L, pow2) := ceilLog2Pure U_max
    1 ≤ L ∧ L ≤ B_ub ∧ pow2 = (2 : ℤ) ^ L ∧ U_max ≤ pow2 := by
  have hAux : ∀ (fuel L : ℕ) (pow2 : ℤ),
      1 ≤ L → L ≤ B_ub → pow2 = (2 : ℤ) ^ L → U_max ≤ pow2 + (fuel : ℤ) →
      let res := ceilLog2Aux U_max fuel L pow2
      1 ≤ res.1 ∧ res.1 ≤ B_ub ∧ res.2 = (2 : ℤ) ^ res.1 ∧ U_max ≤ res.2 := by
    intro fuel
    induction fuel with
    | zero =>
        intro L pow2 hL1 hLB hpow hU
        simp only [ceilLog2Aux, Nat.cast_zero, add_zero] at hU ⊢
        exact ⟨hL1, hLB, hpow, hU⟩
    | succ fuel ih =>
        intro L pow2 hL1 hLB hpow hU
        simp only [ceilLog2Aux]
        by_cases hlt : pow2 < U_max
        · rw [if_pos hlt]
          have hL_lt_B : L < B_ub := by
            by_contra hge
            have hEqB : L = B_ub := by omega
            subst hEqB
            rw [hpow] at hlt
            linarith
          have hpow2_ge2 : (2 : ℤ) ≤ pow2 := by
            rw [hpow]
            have : (2 : ℤ) ^ 1 ≤ (2 : ℤ) ^ L := pow_le_pow_right₀ (by norm_num) hL1
            simpa using this
          refine ih (L + 1) (2 * pow2) (by omega) (by omega) ?_ ?_
          · rw [hpow, pow_succ']
          · push_cast at hU
            linarith
        · rw [if_neg hlt]
          exact ⟨hL1, hLB, hpow, le_of_not_gt hlt⟩
  exact hAux U_max.toNat 1 2 le_rfl hB (by norm_num) (by omega)

/-! ### 2. Row-Wise Denominator Clearing -/

def clearRowDen (nVars : ℕ) (rowDen : Fin nVars → ℤ) (rhsDen : ℤ) : ℤ :=
  (Fin.foldl nVars (fun acc j => acc * rowDen j) 1) * rhsDen

def clearRowCoeffs (nVars : ℕ) (rowNum rowDen : Fin nVars → ℤ) (rhsDen : ℤ) : Fin nVars → ℤ :=
  let D := clearRowDen nVars rowDen rhsDen
  fun j => rowNum j * (D / rowDen j)

def clearRowRhs (nVars : ℕ) (rowDen : Fin nVars → ℤ) (rhsNum rhsDen : ℤ) : ℤ :=
  let D := clearRowDen nVars rowDen rhsDen
  rhsNum * (D / rhsDen)

theorem foldl_mul_eq_prod {n : ℕ} (f : Fin n → ℤ) :
    Fin.foldl n (fun acc j => acc * f j) 1 = ∏ j : Fin n, f j := by
  induction n with
  | zero => simp [Fin.foldl_zero]
  | succ n ih =>
      rw [Fin.foldl_succ_last, ih (fun j => f j.castSucc), Fin.prod_univ_castSucc]

theorem clearRow_spec {nVars B' : ℕ}
    (rowNum rowDen : Fin nVars → ℤ) (rhsNum rhsDen : ℤ)
    (hRowPos : ∀ j : Fin nVars, 0 < rowDen j) (hRhsPos : 0 < rhsDen)
    (hRowNum : ∀ j : Fin nVars, (rowNum j).natAbs ≤ 2 ^ B')
    (hRowDen : ∀ j : Fin nVars, (rowDen j).natAbs ≤ 2 ^ B')
    (hRhsNum : rhsNum.natAbs ≤ 2 ^ B')
    (hRhsDen : rhsDen.natAbs ≤ 2 ^ B') :
    let D := clearRowDen nVars rowDen rhsDen
    let intRow := clearRowCoeffs nVars rowNum rowDen rhsDen
    let intRhs := clearRowRhs nVars rowDen rhsNum rhsDen
    0 < D ∧
    D.natAbs ≤ 2 ^ (B' * (nVars + 1)) ∧
    (∀ j : Fin nVars, (intRow j).natAbs ≤ 2 ^ (B' * (nVars + 2))) ∧
    intRhs.natAbs ≤ 2 ^ (B' * (nVars + 2)) ∧
    (∀ j : Fin nVars, (intRow j : ℚ) = (D : ℚ) * ((rowNum j : ℚ) / (rowDen j : ℚ))) ∧
    (intRhs : ℚ) = (D : ℚ) * ((rhsNum : ℚ) / (rhsDen : ℚ)) := by
  intro D intRow intRhs
  have hD_eq : D = (∏ j : Fin nVars, rowDen j) * rhsDen := by
    dsimp [D, clearRowDen]
    rw [foldl_mul_eq_prod]
  have hD_pos : 0 < D := by
    rw [hD_eq]
    exact mul_pos (Finset.prod_pos (fun j _ => hRowPos j)) hRhsPos
  have hProdAbs : (∏ j : Fin nVars, rowDen j).natAbs ≤ 2 ^ (B' * nVars) := by
    have h1 : ∀ {k : ℕ} (g : Fin k → ℤ), (∏ j : Fin k, g j).natAbs = ∏ j : Fin k, (g j).natAbs := by
      intro k
      induction k with
      | zero => intro _; simp
      | succ k ih =>
          intro g
          rw [Fin.prod_univ_castSucc, Int.natAbs_mul, ih (fun j => g j.castSucc), Fin.prod_univ_castSucc]
    rw [h1 rowDen]
    calc ∏ j : Fin nVars, (rowDen j).natAbs
        ≤ ∏ _j : Fin nVars, 2 ^ B' := Finset.prod_le_prod' (fun j _ => hRowDen j)
      _ = (2 ^ B') ^ nVars := by simp
      _ = 2 ^ (B' * nVars) := (pow_mul 2 B' nVars).symm
  have hD_abs : D.natAbs ≤ 2 ^ (B' * (nVars + 1)) := by
    rw [hD_eq, Int.natAbs_mul]
    calc (∏ j : Fin nVars, rowDen j).natAbs * rhsDen.natAbs
        ≤ 2 ^ (B' * nVars) * 2 ^ B' := Nat.mul_le_mul hProdAbs hRhsDen
      _ = 2 ^ (B' * (nVars + 1)) := by rw [← pow_add]; ring_nf
  have hPowAdd : 2 ^ B' * 2 ^ (B' * (nVars + 1)) = 2 ^ (B' * (nVars + 2)) := by
    rw [← pow_add]; ring_nf
  refine ⟨hD_pos, hD_abs, ?_, ?_, ?_, ?_⟩
  · intro j
    dsimp [intRow, clearRowCoeffs]
    rw [Int.natAbs_mul]
    calc (rowNum j).natAbs * (D / rowDen j).natAbs
        ≤ 2 ^ B' * D.natAbs := Nat.mul_le_mul (hRowNum j) (Int.natAbs_ediv_le_natAbs _ _)
      _ ≤ 2 ^ B' * 2 ^ (B' * (nVars + 1)) := Nat.mul_le_mul_left _ hD_abs
      _ = 2 ^ (B' * (nVars + 2)) := hPowAdd
  · dsimp [intRhs, clearRowRhs]
    rw [Int.natAbs_mul]
    calc rhsNum.natAbs * (D / rhsDen).natAbs
        ≤ 2 ^ B' * D.natAbs := Nat.mul_le_mul hRhsNum (Int.natAbs_ediv_le_natAbs _ _)
      _ ≤ 2 ^ B' * 2 ^ (B' * (nVars + 1)) := Nat.mul_le_mul_left _ hD_abs
      _ = 2 ^ (B' * (nVars + 2)) := hPowAdd
  · intro j
    have hdvd : rowDen j ∣ D := by
      rw [hD_eq]
      exact dvd_mul_of_dvd_left (Finset.dvd_prod_of_mem _ (Finset.mem_univ j)) _
    have hmul : (D / rowDen j) * rowDen j = D := Int.ediv_mul_cancel hdvd
    have hden_ne : (rowDen j : ℚ) ≠ 0 := by exact_mod_cast (hRowPos j).ne'
    change ((rowNum j * (D / rowDen j) : ℤ) : ℚ) = (D : ℚ) * ((rowNum j : ℚ) / (rowDen j : ℚ))
    have hmulQ : ((D / rowDen j : ℤ) : ℚ) * (rowDen j : ℚ) = (D : ℚ) := by exact_mod_cast hmul
    have hquotQ : ((D / rowDen j : ℤ) : ℚ) = (D : ℚ) / (rowDen j : ℚ) :=
      (eq_div_iff hden_ne).mpr hmulQ
    rw [Int.cast_mul, hquotQ]
    ring
  · have hdvd : rhsDen ∣ D := by rw [hD_eq]; exact dvd_mul_left _ _
    have hmul : (D / rhsDen) * rhsDen = D := Int.ediv_mul_cancel hdvd
    have hden_ne : (rhsDen : ℚ) ≠ 0 := by exact_mod_cast hRhsPos.ne'
    change ((rhsNum * (D / rhsDen) : ℤ) : ℚ) = (D : ℚ) * ((rhsNum : ℚ) / (rhsDen : ℚ))
    have hmulQ : ((D / rhsDen : ℤ) : ℚ) * (rhsDen : ℚ) = (D : ℚ) := by exact_mod_cast hmul
    have hquotQ : ((D / rhsDen : ℤ) : ℚ) = (D : ℚ) / (rhsDen : ℚ) :=
      (eq_div_iff hden_ne).mpr hmulQ
    rw [Int.cast_mul, hquotQ]
    ring


/-! ### 3. Active-Set Self-Reduction `solveCoreIntLP` and `solveRationalLP` -/

def rowMaxAbs {n : ℕ} (init : ℤ) (row : Fin n → ℤ) (rhs : ℤ) : ℤ :=
  maxInt (Fin.foldl n (fun acc j => maxInt acc (absInt (row j))) init) (absInt rhs)

def computeMaxEntry {nVars nEq nLe : ℕ}
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ) : ℤ :=
  let m1 := Fin.foldl nEq (fun acc i => rowMaxAbs acc (M_eq i) (d_eq i)) 2
  Fin.foldl nLe (fun acc k => rowMaxAbs acc (M_le k) (d_le k)) m1

theorem foldl_maxInt_ge {m : ℕ} (init : ℤ) (f : Fin m → ℤ)
    (step : ℤ → Fin m → ℤ)
    (hMono : ∀ a i, a ≤ step a i)
    (hBound : ∀ a i, f i ≤ step a i) :
    init ≤ Fin.foldl m step init ∧ ∀ i : Fin m, f i ≤ Fin.foldl m step init := by
  induction m with
  | zero =>
      simp only [Fin.foldl_zero]
      exact ⟨le_rfl, fun i => Fin.elim0 i⟩
  | succ m ih =>
      rw [Fin.foldl_succ_last]
      obtain ⟨hInit, hPrev⟩ := ih (fun i => f i.castSucc) (fun a i => step a i.castSucc)
        (fun a i => hMono a i.castSucc) (fun a i => hBound a i.castSucc)
      let prev := Fin.foldl m (fun a (i : Fin m) => step a i.castSucc) init
      refine ⟨hInit.trans (hMono prev (Fin.last m)), fun i => ?_⟩
      refine Fin.lastCases ?_ (fun i' => ?_) i
      · exact hBound prev (Fin.last m)
      · exact (hPrev i').trans (hMono prev (Fin.last m))

theorem foldl_maxInt_le {m : ℕ} (init U : ℤ) (step : ℤ → Fin m → ℤ)
    (hInit : init ≤ U)
    (hStep : ∀ a i, a ≤ U → step a i ≤ U) :
    Fin.foldl m step init ≤ U := by
  induction m with
  | zero => simpa [Fin.foldl_zero] using hInit
  | succ m ih =>
      rw [Fin.foldl_succ_last]
      exact hStep _ (Fin.last m) (ih (fun a i => step a i.castSucc) (fun a i ha => hStep a i.castSucc ha))

theorem computeMaxEntry_spec {nVars nEq nLe : ℕ}
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (U : ℕ) (hU2 : 2 ≤ U)
    (hMeq : ∀ i j, (M_eq i j).natAbs ≤ U) (hdeq : ∀ i, (d_eq i).natAbs ≤ U)
    (hMle : ∀ k j, (M_le k j).natAbs ≤ U) (hdle : ∀ k, (d_le k).natAbs ≤ U) :
    let U_max := computeMaxEntry M_eq d_eq M_le d_le
    2 ≤ U_max ∧ U_max ≤ (U : ℤ) ∧
    (∀ i j, ((M_eq i j).natAbs : ℤ) ≤ U_max) ∧
    (∀ i, ((d_eq i).natAbs : ℤ) ≤ U_max) ∧
    (∀ k j, ((M_le k j).natAbs : ℤ) ≤ U_max) ∧
    (∀ k, ((d_le k).natAbs : ℤ) ≤ U_max) := by
  intro U_max
  have hRowMono : ∀ {n : ℕ} (a : ℤ) (r : Fin n → ℤ) (b : ℤ), a ≤ rowMaxAbs a r b := by
    intro n a r b
    dsimp [rowMaxAbs]
    rw [maxInt_eq_max]
    have h1 := (foldl_maxInt_ge a (fun j => absInt (r j))
      (fun acc j => maxInt acc (absInt (r j)))
      (fun acc j => by simp) (fun acc j => by simp)).1
    exact h1.trans (le_max_left _ _)
  have hRowEntry : ∀ {n : ℕ} (a : ℤ) (r : Fin n → ℤ) (b : ℤ),
      (∀ j : Fin n, ((r j).natAbs : ℤ) ≤ rowMaxAbs a r b) ∧
      (b.natAbs : ℤ) ≤ rowMaxAbs a r b := by
    intro n a r b
    dsimp [rowMaxAbs]
    rw [maxInt_eq_max]
    have h2 := (foldl_maxInt_ge a (fun j => absInt (r j))
      (fun acc j => maxInt acc (absInt (r j)))
      (fun acc j => by simp) (fun acc j => by simp)).2
    refine ⟨fun j => ?_, by simp [le_max_right]⟩
    have hj := h2 j
    rw [absInt_eq_natAbs] at hj
    exact hj.trans (le_max_left _ _)
  have hRowUb : ∀ {n : ℕ} (a : ℤ) (r : Fin n → ℤ) (b : ℤ),
      a ≤ (U : ℤ) → (∀ j, (r j).natAbs ≤ U) → b.natAbs ≤ U → rowMaxAbs a r b ≤ (U : ℤ) := by
    intro n a r b ha hr hb
    dsimp [rowMaxAbs]
    rw [maxInt_eq_max, max_le_iff]
    refine ⟨?_, by rw [absInt_eq_natAbs]; exact_mod_cast hb⟩
    refine foldl_maxInt_le a (U : ℤ) _ ha (fun acc j hacc => ?_)
    rw [maxInt_eq_max, absInt_eq_natAbs, max_le_iff]
    exact ⟨hacc, by exact_mod_cast hr j⟩
  let m1 := Fin.foldl nEq (fun acc i => rowMaxAbs acc (M_eq i) (d_eq i)) 2
  have hm1_ge : 2 ≤ m1 := (foldl_maxInt_ge 2 (fun _ => 0) _
    (fun acc i => hRowMono acc (M_eq i) (d_eq i))
    (fun acc i => (Nat.cast_nonneg _).trans (hRowEntry acc (M_eq i) (d_eq i)).2)).1
  have hm2_ge : m1 ≤ U_max := (foldl_maxInt_ge m1 (fun _ => 0) _
    (fun acc k => hRowMono acc (M_le k) (d_le k))
    (fun acc k => (Nat.cast_nonneg _).trans (hRowEntry acc (M_le k) (d_le k)).2)).1
  have hm1_ub : m1 ≤ (U : ℤ) := foldl_maxInt_le 2 (U : ℤ) _ (by omega)
    (fun acc i hacc => hRowUb acc (M_eq i) (d_eq i) hacc (hMeq i) (hdeq i))
  have hm2_ub : U_max ≤ (U : ℤ) := foldl_maxInt_le m1 (U : ℤ) _ hm1_ub
    (fun acc k hacc => hRowUb acc (M_le k) (d_le k) hacc (hMle k) (hdle k))

  -- Direct per-entry extraction via foldl_maxInt_ge!
  have hMeq_le : ∀ (i : Fin nEq) (j : Fin nVars), ((M_eq i j).natAbs : ℤ) ≤ m1 := by
    intro i j
    exact (foldl_maxInt_ge 2 (fun i' => ((M_eq i' j).natAbs : ℤ))
      (fun acc i' => rowMaxAbs acc (M_eq i') (d_eq i'))
      (fun acc i' => hRowMono acc (M_eq i') (d_eq i'))
      (fun acc i' => (hRowEntry acc (M_eq i') (d_eq i')).1 j)).2 i
  have hdeq_le : ∀ i : Fin nEq, ((d_eq i).natAbs : ℤ) ≤ m1 := by
    intro i
    exact (foldl_maxInt_ge 2 (fun i' => ((d_eq i').natAbs : ℤ))
      (fun acc i' => rowMaxAbs acc (M_eq i') (d_eq i'))
      (fun acc i' => hRowMono acc (M_eq i') (d_eq i'))
      (fun acc i' => (hRowEntry acc (M_eq i') (d_eq i')).2)).2 i
  have hMle_le : ∀ (k : Fin nLe) (j : Fin nVars), ((M_le k j).natAbs : ℤ) ≤ U_max := by
    intro k j
    exact (foldl_maxInt_ge m1 (fun k' => ((M_le k' j).natAbs : ℤ))
      (fun acc k' => rowMaxAbs acc (M_le k') (d_le k'))
      (fun acc k' => hRowMono acc (M_le k') (d_le k'))
      (fun acc k' => (hRowEntry acc (M_le k') (d_le k')).1 j)).2 k
  have hdle_le : ∀ k : Fin nLe, ((d_le k).natAbs : ℤ) ≤ U_max := by
    intro k
    exact (foldl_maxInt_ge m1 (fun k' => ((d_le k').natAbs : ℤ))
      (fun acc k' => rowMaxAbs acc (M_le k') (d_le k'))
      (fun acc k' => hRowMono acc (M_le k') (d_le k'))
      (fun acc k' => (hRowEntry acc (M_le k') (d_le k')).2)).2 k
  exact ⟨hm1_ge.trans hm2_ge, hm2_ub,
    fun i j => (hMeq_le i j).trans hm2_ge,
    fun i => (hdeq_le i).trans hm2_ge,
    hMle_le, hdle_le⟩

/-- Fixed-size `(2 * nEq + 2 * nLe)`-row inequality system encoding
`M_eq x = d_eq ∧ M_le x ≤ d_le ∧ (∀ k, active k = true → M_le k x = d_le k)`. -/
def buildOracleM {nVars nEq nLe : ℕ}
    (M_eq : Fin nEq → Fin nVars → ℤ) (M_le : Fin nLe → Fin nVars → ℤ)
    (active : Fin nLe → Bool) : Fin (2 * nEq + 2 * nLe) → Fin nVars → ℤ :=
  fun r j =>
    if h1 : r.val < nEq then
      M_eq ⟨r.val, h1⟩ j
    else if h2 : r.val - nEq < nEq then
      - M_eq ⟨r.val - nEq, h2⟩ j
    else if h3 : r.val - 2 * nEq < nLe then
      M_le ⟨r.val - 2 * nEq, h3⟩ j
    else
      let k : Fin nLe := ⟨r.val - (2 * nEq + nLe), by omega⟩
      if active k then - M_le k j else 0

def buildOracleD {nEq nLe : ℕ}
    (d_eq : Fin nEq → ℤ) (d_le : Fin nLe → ℤ)
    (active : Fin nLe → Bool) : Fin (2 * nEq + 2 * nLe) → ℤ :=
  fun r =>
    if h1 : r.val < nEq then
      d_eq ⟨r.val, h1⟩
    else if h2 : r.val - nEq < nEq then
      - d_eq ⟨r.val - nEq, h2⟩
    else if h3 : r.val - 2 * nEq < nLe then
      d_le ⟨r.val - 2 * nEq, h3⟩
    else
      let k : Fin nLe := ⟨r.val - (2 * nEq + nLe), by omega⟩
      if active k then - d_le k else 0

theorem buildOracle_feas_iff {nVars nEq nLe : ℕ}
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (active : Fin nLe → Bool) (x : Fin nVars → ℝ) :
    (∀ r : Fin (2 * nEq + 2 * nLe),
      ∑ j : Fin nVars, (buildOracleM M_eq M_le active r j : ℝ) * x j ≤
        (buildOracleD d_eq d_le active r : ℝ)) ↔
    ((∀ i : Fin nEq, ∑ j : Fin nVars, (M_eq i j : ℝ) * x j = (d_eq i : ℝ)) ∧
     (∀ k : Fin nLe, ∑ j : Fin nVars, (M_le k j : ℝ) * x j ≤ (d_le k : ℝ)) ∧
     (∀ k : Fin nLe, active k = true → ∑ j : Fin nVars, (M_le k j : ℝ) * x j = (d_le k : ℝ))) := by
  have hNegSum : ∀ (row : Fin nVars → ℤ) (rhs : ℤ),
      (∑ j : Fin nVars, ((- row j : ℤ) : ℝ) * x j ≤ ((- rhs : ℤ) : ℝ)) ↔
      (rhs : ℝ) ≤ ∑ j : Fin nVars, (row j : ℝ) * x j := by
    intro row rhs
    have h1 : ∑ j : Fin nVars, ((- row j : ℤ) : ℝ) * x j =
        - ∑ j : Fin nVars, (row j : ℝ) * x j := by
      push_cast; simp only [neg_mul, Finset.sum_neg_distrib]
    rw [h1, Int.cast_neg]
    constructor <;> intro h <;> linarith
  constructor
  · intro hAll
    refine ⟨?_, ?_, ?_⟩
    · intro i
      have hPos := hAll ⟨i.val, by omega⟩
      have hNeg := hAll ⟨nEq + i.val, by omega⟩
      have hc1 : i.val < nEq := i.isLt
      have hc21 : ¬ (nEq + i.val < nEq) := by omega
      have hc22 : (nEq + i.val) - nEq < nEq := by omega
      have hi_sub : (⟨(nEq + i.val) - nEq, hc22⟩ : Fin nEq) = i := by ext; simp
      simp only [buildOracleM, buildOracleD, hc1, ↓reduceDIte] at hPos
      simp only [buildOracleM, buildOracleD, hc21, hc22, ↓reduceDIte, hi_sub] at hNeg
      have hGe := (hNegSum (M_eq i) (d_eq i)).mp hNeg
      exact le_antisymm hPos hGe
    · intro k
      have hk := hAll ⟨2 * nEq + k.val, by omega⟩
      have hc1 : ¬ (2 * nEq + k.val < nEq) := by omega
      have hc2 : ¬ ((2 * nEq + k.val) - nEq < nEq) := by omega
      have hc3 : (2 * nEq + k.val) - 2 * nEq < nLe := by omega
      have hk_sub : (⟨(2 * nEq + k.val) - 2 * nEq, hc3⟩ : Fin nLe) = k := by ext; simp
      simp only [buildOracleM, buildOracleD, hc1, hc2, hc3, ↓reduceDIte, hk_sub] at hk
      exact hk
    · intro k hact
      have hPos := hAll ⟨2 * nEq + k.val, by omega⟩
      have hNeg := hAll ⟨2 * nEq + nLe + k.val, by omega⟩
      have hc1 : ¬ (2 * nEq + k.val < nEq) := by omega
      have hc2 : ¬ ((2 * nEq + k.val) - nEq < nEq) := by omega
      have hc3 : (2 * nEq + k.val) - 2 * nEq < nLe := by omega
      have hk_sub : (⟨(2 * nEq + k.val) - 2 * nEq, hc3⟩ : Fin nLe) = k := by ext; simp
      simp only [buildOracleM, buildOracleD, hc1, hc2, hc3, ↓reduceDIte, hk_sub] at hPos
      have hd1 : ¬ (2 * nEq + nLe + k.val < nEq) := by omega
      have hd2 : ¬ ((2 * nEq + nLe + k.val) - nEq < nEq) := by omega
      have hd3 : ¬ ((2 * nEq + nLe + k.val) - 2 * nEq < nLe) := by omega
      have hk_sub2 : (⟨(2 * nEq + nLe + k.val) - (2 * nEq + nLe), by omega⟩ : Fin nLe) = k := by
        ext; dsimp only; omega
      simp only [buildOracleM, buildOracleD, hd1, hd2, hd3, ↓reduceDIte, hk_sub2, hact, ↓reduceIte] at hNeg
      exact le_antisymm hPos ((hNegSum (M_le k) (d_le k)).mp hNeg)
  · rintro ⟨hEq, hLe, hAct⟩ r
    by_cases h1 : r.val < nEq
    · simp only [buildOracleM, buildOracleD, h1, ↓reduceDIte]
      exact (hEq ⟨r.val, h1⟩).le
    · by_cases h2 : r.val - nEq < nEq
      · simp only [buildOracleM, buildOracleD, h1, h2, ↓reduceDIte]
        exact (hNegSum _ _).mpr (hEq ⟨r.val - nEq, h2⟩).ge
      · by_cases h3 : r.val - 2 * nEq < nLe
        · simp only [buildOracleM, buildOracleD, h1, h2, h3, ↓reduceDIte]
          exact hLe ⟨r.val - 2 * nEq, h3⟩
        · simp only [buildOracleM, buildOracleD, h1, h2, h3, ↓reduceDIte]
          let k : Fin nLe := ⟨r.val - (2 * nEq + nLe), by omega⟩
          cases hact : active k
          · simp
          · simp only [↓reduceIte]
            exact (hNegSum _ _).mpr (hAct k hact).ge

/-- Fixed-size `(nEq + nLe)`-row equality system for `bareissSolve` after active-set selection. -/
def buildActiveEqM {nVars nEq nLe : ℕ}
    (M_eq : Fin nEq → Fin nVars → ℤ) (M_le : Fin nLe → Fin nVars → ℤ)
    (active : Fin nLe → Bool) : Fin (nEq + nLe) → Fin nVars → ℤ :=
  fun r j =>
    if h : r.val < nEq then
      M_eq ⟨r.val, h⟩ j
    else
      let k : Fin nLe := ⟨r.val - nEq, by omega⟩
      if active k then M_le k j else 0

def buildActiveEqD {nEq nLe : ℕ}
    (d_eq : Fin nEq → ℤ) (d_le : Fin nLe → ℤ)
    (active : Fin nLe → Bool) : Fin (nEq + nLe) → ℤ :=
  fun r =>
    if h : r.val < nEq then
      d_eq ⟨r.val, h⟩
    else
      let k : Fin nLe := ⟨r.val - nEq, by omega⟩
      if active k then d_le k else 0

/-- Complete pure functional integer LP solver via `ellipsoidDecide` + active-set + `bareissSolve`. -/
def solveCoreIntLP {nVars nEq nLe : ℕ}
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ) :
    ℤ × (Fin nVars → ℤ) × (Fin nVars → ℤ) :=
  let U_max := computeMaxEntry M_eq d_eq M_le d_le
  let (L, _) := ceilLog2Pure U_max
  let initAct : Fin nLe → Bool := fun _ => false
  if ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
      (buildOracleM M_eq M_le initAct) (buildOracleD d_eq d_le initAct) then
    let finalAct := Fin.foldl nLe (fun act k =>
      let cand : Fin nLe → Bool := fun s => if s = k then true else act s
      if ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
          (buildOracleM M_eq M_le cand) (buildOracleD d_eq d_le cand) then
        cand
      else act) initAct
    let (solNum, solDen) := bareissSolve
      (buildActiveEqM M_eq M_le finalAct) (buildActiveEqD d_eq d_le finalAct)
    (1, solNum, solDen)
  else
    (0, fun _ => 0, fun _ => 1)

/-- Complete pure functional rational LP solver via row-denominator clearing + `solveCoreIntLP`. -/
def solveRationalLP {nVars nEq nLe : ℕ}
    (A_eq_num A_eq_den : Fin nEq → Fin nVars → ℤ)
    (b_eq_num b_eq_den : Fin nEq → ℤ)
    (A_le_num A_le_den : Fin nLe → Fin nVars → ℤ)
    (b_le_num b_le_den : Fin nLe → ℤ) :
    ℤ × (Fin nVars → ℤ) × (Fin nVars → ℤ) :=
  let M_eq : Fin nEq → Fin nVars → ℤ :=
    fun i => clearRowCoeffs nVars (A_eq_num i) (A_eq_den i) (b_eq_den i)
  let d_eq : Fin nEq → ℤ :=
    fun i => clearRowRhs nVars (A_eq_den i) (b_eq_num i) (b_eq_den i)
  let M_le : Fin nLe → Fin nVars → ℤ :=
    fun k => clearRowCoeffs nVars (A_le_num k) (A_le_den k) (b_le_den k)
  let d_le : Fin nLe → ℤ :=
    fun k => clearRowRhs nVars (A_le_den k) (b_le_num k) (b_le_den k)
  solveCoreIntLP M_eq d_eq M_le d_le

theorem buildOracle_entry_bound {nVars nEq nLe U : ℕ}
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (active : Fin nLe → Bool)
    (hMeq : ∀ i j, (M_eq i j).natAbs ≤ U) (hdeq : ∀ i, (d_eq i).natAbs ≤ U)
    (hMle : ∀ k j, (M_le k j).natAbs ≤ U) (hdle : ∀ k, (d_le k).natAbs ≤ U) :
    (∀ r j, (buildOracleM M_eq M_le active r j).natAbs ≤ U) ∧
    (∀ r, (buildOracleD d_eq d_le active r).natAbs ≤ U) := by
  constructor
  · intro r j
    dsimp [buildOracleM]
    split_ifs with h1 h2 h3 hact
    · exact hMeq _ j
    · simpa using hMeq _ j
    · exact hMle _ j
    · simpa using hMle _ j
    · simp
  · intro r
    dsimp [buildOracleD]
    split_ifs with h1 h2 h3 hact
    · exact hdeq _
    · simpa using hdeq _
    · exact hdle _
    · simpa using hdle _
    · simp

theorem solveCoreIntLP_spec {nVars nEq nLe B_int : ℕ} (hB : 1 ≤ B_int)
    (M_eq : Fin nEq → Fin nVars → ℤ) (d_eq : Fin nEq → ℤ)
    (M_le : Fin nLe → Fin nVars → ℤ) (d_le : Fin nLe → ℤ)
    (hMeq : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ B_int)
    (hdeq : ∀ i, (d_eq i).natAbs ≤ 2 ^ B_int)
    (hMle : ∀ k j, (M_le k j).natAbs ≤ 2 ^ B_int)
    (hdle : ∀ k, (d_le k).natAbs ≤ 2 ^ B_int) :
    let (flag, solNum, solDen) := solveCoreIntLP M_eq d_eq M_le d_le
    let xRat : Fin nVars → ℚ := fun j => (solNum j : ℚ) / (solDen j : ℚ)
    (flag = 0 ∨ flag = 1) ∧
    (flag = 1 ↔
      ∃ x : Fin nVars → ℝ,
        (∀ i : Fin nEq, ∑ j : Fin nVars, (M_eq i j : ℝ) * x j = (d_eq i : ℝ)) ∧
        (∀ k : Fin nLe, ∑ j : Fin nVars, (M_le k j : ℝ) * x j ≤ (d_le k : ℝ))) ∧
    (flag = 1 →
      (∀ j : Fin nVars,
        0 < solDen j ∧
        (solNum j).natAbs ≤ (nVars + 1).factorial * (2 ^ B_int) ^ (nVars + 1) ∧
        (solDen j).natAbs ≤ (nVars + 1).factorial * (2 ^ B_int) ^ (nVars + 1)) ∧
      (∀ i : Fin nEq, ∑ j : Fin nVars, (M_eq i j : ℚ) * xRat j = (d_eq i : ℚ)) ∧
      (∀ k : Fin nLe, ∑ j : Fin nVars, (M_le k j : ℚ) * xRat j ≤ (d_le k : ℚ))) := by
  let U_max := computeMaxEntry M_eq d_eq M_le d_le
  have h2B : 2 ≤ 2 ^ B_int := by
    have : 2 ^ 1 ≤ 2 ^ B_int := Nat.pow_le_pow_right (by omega) hB
    simpa using this
  obtain ⟨hU2, hU_ub, hMeqU, hdeqU, hMleU, hdleU⟩ :=
    computeMaxEntry_spec M_eq d_eq M_le d_le (2 ^ B_int) h2B hMeq hdeq hMle hdle
  have hU_ubZ : U_max ≤ (2 : ℤ) ^ B_int := by simpa using hU_ub
  have hLogSpec := ceilLog2Pure_spec U_max B_int hB hU_ubZ
  let L := (ceilLog2Pure U_max).1
  let pow2 := (ceilLog2Pure U_max).2
  change 1 ≤ L ∧ L ≤ B_int ∧ pow2 = (2 : ℤ) ^ L ∧ U_max ≤ pow2 at hLogSpec
  obtain ⟨hL1, hLB, hpow2, hU_le_pow2⟩ := hLogSpec
  have hMeqL : ∀ i j, (M_eq i j).natAbs ≤ 2 ^ L := by
    intro i j
    have hz : ((M_eq i j).natAbs : ℤ) ≤ (2 : ℤ) ^ L := (hMeqU i j).trans (hpow2 ▸ hU_le_pow2)
    exact_mod_cast hz
  have hdeqL : ∀ i, (d_eq i).natAbs ≤ 2 ^ L := by
    intro i
    have hz : ((d_eq i).natAbs : ℤ) ≤ (2 : ℤ) ^ L := (hdeqU i).trans (hpow2 ▸ hU_le_pow2)
    exact_mod_cast hz
  have hMleL : ∀ k j, (M_le k j).natAbs ≤ 2 ^ L := by
    intro k j
    have hz : ((M_le k j).natAbs : ℤ) ≤ (2 : ℤ) ^ L := (hMleU k j).trans (hpow2 ▸ hU_le_pow2)
    exact_mod_cast hz
  have hdleL : ∀ k, (d_le k).natAbs ≤ 2 ^ L := by
    intro k
    have hz : ((d_le k).natAbs : ℤ) ≤ (2 : ℤ) ^ L := (hdleU k).trans (hpow2 ▸ hU_le_pow2)
    exact_mod_cast hz
  let FeasAct : (Fin nLe → Bool) → Prop := fun act =>
    ∃ x : Fin nVars → ℝ,
      (∀ i : Fin nEq, ∑ j : Fin nVars, (M_eq i j : ℝ) * x j = (d_eq i : ℝ)) ∧
      (∀ k : Fin nLe, ∑ j : Fin nVars, (M_le k j : ℝ) * x j ≤ (d_le k : ℝ)) ∧
      (∀ k : Fin nLe, act k = true → ∑ j : Fin nVars, (M_le k j : ℝ) * x j = (d_le k : ℝ))
  have hDecIff : ∀ act : Fin nLe → Bool,
      ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
        (buildOracleM M_eq M_le act) (buildOracleD d_eq d_le act) = true ↔ FeasAct act := by
    intro act
    obtain ⟨hOM, hOD⟩ := buildOracle_entry_bound M_eq d_eq M_le d_le act hMeqL hdeqL hMleL hdleL
    rw [ellipsoidDecide_iff hL1 _ _ hOM hOD]
    exact ⟨fun ⟨x, hx⟩ => ⟨x, (buildOracle_feas_iff M_eq d_eq M_le d_le act x).mp hx⟩,
      fun ⟨x, hx⟩ => ⟨x, (buildOracle_feas_iff M_eq d_eq M_le d_le act x).mpr hx⟩⟩
  let initAct : Fin nLe → Bool := fun _ => false
  have hInitFeasIff : FeasAct initAct ↔
      (∃ x : Fin nVars → ℝ,
        (∀ i : Fin nEq, ∑ j : Fin nVars, (M_eq i j : ℝ) * x j = (d_eq i : ℝ)) ∧
        (∀ k : Fin nLe, ∑ j : Fin nVars, (M_le k j : ℝ) * x j ≤ (d_le k : ℝ))) := by
    constructor
    · rintro ⟨x, h1, h2, _⟩; exact ⟨x, h1, h2⟩
    · rintro ⟨x, h1, h2⟩; exact ⟨x, h1, h2, fun k hk => by simp [initAct] at hk⟩
  unfold solveCoreIntLP
  dsimp only
  by_cases hInitDec : ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
      (buildOracleM M_eq M_le initAct) (buildOracleD d_eq d_le initAct) = true
  · have hInitDec' : ellipsoidDecide nVars (2 * nEq + 2 * nLe)
        (ceilLog2Pure (computeMaxEntry M_eq d_eq M_le d_le)).1
        (buildOracleM M_eq M_le (fun _ => false)) (buildOracleD d_eq d_le (fun _ => false)) = true :=
      hInitDec
    rw [if_pos hInitDec']
    dsimp only
    have hFeas0 : FeasAct initAct := (hDecIff initAct).mp hInitDec
    refine ⟨Or.inr rfl, ⟨fun _ => hInitFeasIff.mp hFeas0, fun _ => rfl⟩, fun _ => ?_⟩
    -- Prove active-set loop invariant
    let actStep : (Fin nLe → Bool) → Fin nLe → (Fin nLe → Bool) := fun act k =>
      let cand : Fin nLe → Bool := fun s => if s = k then true else act s
      if ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
          (buildOracleM M_eq M_le cand) (buildOracleD d_eq d_le cand) then
        cand
      else act
    have hActInv : ∀ t : ℕ, (ht : t ≤ nLe) →
        let act := Fin.foldl t (fun a (k : Fin t) => actStep a ⟨k.val, lt_of_lt_of_le k.isLt ht⟩) initAct
        FeasAct act ∧
        (∀ k : Fin nLe, k.val < t → act k = false →
          ¬ FeasAct (fun s => if s = k then true else act s)) := by
      intro t
      induction t with
      | zero =>
          intro _
          dsimp only
          rw [Fin.foldl_zero]
          exact ⟨hFeas0, fun k hk => False.elim (Nat.not_lt_zero _ hk)⟩
      | succ t ih =>
          intro ht
          let prev := Fin.foldl t (fun a (k : Fin t) =>
            actStep a ⟨k.val, lt_of_lt_of_le k.isLt (Nat.le_of_succ_le ht)⟩) initAct
          have hfold : Fin.foldl (t + 1) (fun a (k : Fin (t + 1)) =>
              actStep a ⟨k.val, lt_of_lt_of_le k.isLt ht⟩) initAct = actStep prev ⟨t, ht⟩ := by
            rw [Fin.foldl_succ_last]; rfl
          dsimp only
          rw [hfold]
          obtain ⟨hPrevFeas, hPrevMax⟩ := ih (Nat.le_of_succ_le ht)
          let kt : Fin nLe := ⟨t, ht⟩
          let cand : Fin nLe → Bool := fun s => if s = kt then true else prev s
          have hactStep_eq : actStep prev ⟨t, ht⟩ =
              if ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
                (buildOracleM M_eq M_le cand) (buildOracleD d_eq d_le cand) then cand else prev := rfl
          rw [hactStep_eq]
          by_cases hCandDec : ellipsoidDecide nVars (2 * nEq + 2 * nLe) L
              (buildOracleM M_eq M_le cand) (buildOracleD d_eq d_le cand) = true
          · rw [if_pos hCandDec]
            refine ⟨(hDecIff cand).mp hCandDec, fun k hk hCandFalse hFeasCandK => ?_⟩
            have hk_ne_kt : k ≠ kt := by
              intro heq
              have hc1 : cand k = true := by dsimp [cand]; rw [if_pos heq]
              rw [hc1] at hCandFalse
              exact Bool.false_ne_true hCandFalse.symm
            have hk_lt_t : k.val < t := by
              have : k.val ≠ t := fun h => hk_ne_kt (Fin.ext h)
              omega
            have hPrevFalse : prev k = false := by
              have hc2 : cand k = prev k := by dsimp [cand]; rw [if_neg hk_ne_kt]
              rwa [← hc2]
            apply hPrevMax k hk_lt_t hPrevFalse
            rcases hFeasCandK with ⟨z, hz1, hz2, hz3⟩
            refine ⟨z, hz1, hz2, fun s hs => hz3 s ?_⟩
            dsimp only at hs ⊢
            by_cases hsk : s = k
            · simp [hsk]
            · rw [if_neg hsk] at hs ⊢
              dsimp [cand]
              by_cases hst : s = kt
              · simp [hst]
              · rw [if_neg hst]; exact hs
          · rw [if_neg hCandDec]
            refine ⟨hPrevFeas, fun k hk hPrevFalse => ?_⟩
            rcases Nat.lt_succ_iff_lt_or_eq.mp hk with hlt | heq
            · exact hPrevMax k hlt hPrevFalse
            · have hk_eq : k = kt := Fin.ext heq
              subst hk_eq
              intro hFeasKt
              exact hCandDec ((hDecIff cand).mpr hFeasKt)
    let finalAct := Fin.foldl nLe actStep initAct
    obtain ⟨hFinalFeas, hFinalMax⟩ := hActInv nLe le_rfl
    change FeasAct finalAct at hFinalFeas
    change ∀ k : Fin nLe, k.val < nLe → finalAct k = false →
      ¬ FeasAct (fun s => if s = k then true else finalAct s) at hFinalMax
    rcases hFinalFeas with ⟨x₀, hx₀_eq, hx₀_le, hx₀_act⟩
    -- Apply bareissSolve_spec on buildActiveEqM / buildActiveEqD
    have hAEq_M : ∀ r j, (buildActiveEqM M_eq M_le finalAct r j).natAbs ≤ 2 ^ L := by
      intro r j; dsimp [buildActiveEqM]; split_ifs; exact hMeqL _ j; exact hMleL _ j; simp
    have hAEq_D : ∀ r, (buildActiveEqD d_eq d_le finalAct r).natAbs ≤ 2 ^ L := by
      intro r; dsimp [buildActiveEqD]; split_ifs; exact hdeqL _; exact hdleL _; simp
    have hAEq_Feas : ∃ x : Fin nVars → ℝ, ∀ r : Fin (nEq + nLe),
        ∑ j : Fin nVars, (buildActiveEqM M_eq M_le finalAct r j : ℝ) * x j =
          (buildActiveEqD d_eq d_le finalAct r : ℝ) := by
      refine ⟨x₀, fun r => ?_⟩
      dsimp [buildActiveEqM, buildActiveEqD]
      split_ifs with h1 hact
      · exact hx₀_eq ⟨r.val, h1⟩
      · exact hx₀_act ⟨r.val - nEq, by omega⟩ hact
      · simp
    have hPowPos : 1 ≤ 2 ^ L := Nat.one_le_two_pow
    have hBar := bareissSolve_spec
      (buildActiveEqM M_eq M_le finalAct) (buildActiveEqD d_eq d_le finalAct)
      (2 ^ L) hPowPos hAEq_M hAEq_D hAEq_Feas
    let solNum := (bareissSolve (buildActiveEqM M_eq M_le finalAct) (buildActiveEqD d_eq d_le finalAct)).1
    let solDen := (bareissSolve (buildActiveEqM M_eq M_le finalAct) (buildActiveEqD d_eq d_le finalAct)).2
    let xRat : Fin nVars → ℚ := fun j => (solNum j : ℚ) / (solDen j : ℚ)
    change (∀ j : Fin nVars, 0 < solDen j ∧
        (solNum j).natAbs ≤ (nVars + 1).factorial * (2 ^ L) ^ (nVars + 1) ∧
        (solDen j).natAbs ≤ (nVars + 1).factorial * (2 ^ L) ^ (nVars + 1)) ∧
      (∀ r : Fin (nEq + nLe),
        ∑ j : Fin nVars, (buildActiveEqM M_eq M_le finalAct r j : ℚ) * xRat j =
          (buildActiveEqD d_eq d_le finalAct r : ℚ)) at hBar
    obtain ⟨hSolBounds, hSolEqs⟩ := hBar
    have hPowMono : (nVars + 1).factorial * (2 ^ L) ^ (nVars + 1) ≤
        (nVars + 1).factorial * (2 ^ B_int) ^ (nVars + 1) :=
      Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (Nat.pow_le_pow_right (by omega) hLB) _)
    have hxRat_eq : ∀ i : Fin nEq, ∑ j : Fin nVars, (M_eq i j : ℚ) * xRat j = (d_eq i : ℚ) := by
      intro i
      have hr := hSolEqs ⟨i.val, by omega⟩
      have hi : i.val < nEq := i.isLt
      simpa [buildActiveEqM, buildActiveEqD, hi] using hr
    have hxRat_act : ∀ k : Fin nLe, finalAct k = true →
        ∑ j : Fin nVars, (M_le k j : ℚ) * xRat j = (d_le k : ℚ) := by
      intro k hk
      have hr := hSolEqs ⟨nEq + k.val, by omega⟩
      have hn : ¬ (nEq + k.val < nEq) := by omega
      have hsub : (⟨(nEq + k.val) - nEq, by omega⟩ : Fin nLe) = k := by ext; simp
      simpa [buildActiveEqM, buildActiveEqD, hn, hsub, hk] using hr
    -- Use activeSet_eq_subset_le over ℝ to deduce ALL inequalities hold for xRat!
    let S : Finset (Fin nLe) := Finset.univ.filter (fun k => finalAct k = true)
    have hxRat_leR : ∀ k : Fin nLe, ∑ j : Fin nVars, (M_le k j : ℝ) * (xRat j : ℝ) ≤ (d_le k : ℝ) := by
      refine activeSet_eq_subset_le
        (fun i j => (M_eq i j : ℝ)) (fun i => (d_eq i : ℝ))
        (fun k j => (M_le k j : ℝ)) (fun k => (d_le k : ℝ))
        S x₀ hx₀_eq
        (fun k hk => hx₀_act k (Finset.mem_filter.mp hk).2)
        hx₀_le
        (fun k hkNot ⟨z, hz1, hz2, hz3, hz4⟩ => ?_)
        (fun j => (xRat j : ℝ))
        (fun i => by dsimp only; exact_mod_cast hxRat_eq i)
        (fun k hk => by dsimp only; exact_mod_cast hxRat_act k (Finset.mem_filter.mp hk).2)
      have hkFalse : finalAct k = false := by
        cases hfk : finalAct k
        · rfl
        · exfalso; exact hkNot (Finset.mem_filter.mpr ⟨Finset.mem_univ k, hfk⟩)
      apply hFinalMax k k.isLt hkFalse
      refine ⟨z, hz1, hz3, fun s hs => ?_⟩
      by_cases hsk : s = k
      · subst hsk; exact hz4
      · simp only [hsk, ↓reduceIte] at hs
        exact hz2 s (Finset.mem_filter.mpr ⟨Finset.mem_univ s, hs⟩)
    have hxRat_le : ∀ k : Fin nLe, ∑ j : Fin nVars, (M_le k j : ℚ) * xRat j ≤ (d_le k : ℚ) := by
      intro k
      exact_mod_cast hxRat_leR k
    exact ⟨fun j => ⟨(hSolBounds j).1, (hSolBounds j).2.1.trans hPowMono, (hSolBounds j).2.2.trans hPowMono⟩,
      hxRat_eq, hxRat_le⟩
  · have hInitDec' : ¬ ellipsoidDecide nVars (2 * nEq + 2 * nLe)
        (ceilLog2Pure (computeMaxEntry M_eq d_eq M_le d_le)).1
        (buildOracleM M_eq M_le (fun _ => false)) (buildOracleD d_eq d_le (fun _ => false)) = true :=
      hInitDec
    rw [if_neg hInitDec']
    dsimp only
    refine ⟨Or.inl rfl, ⟨fun h => by omega, fun hFeas => ?_⟩, fun h => by omega⟩
    exact False.elim (hInitDec ((hDecIff initAct).mpr (hInitFeasIff.mpr hFeas)))

theorem solveRationalLP_spec {nVars nEq nLe B' : ℕ} (hB' : 1 ≤ B')
    (A_eq_num A_eq_den : Fin nEq → Fin nVars → ℤ)
    (b_eq_num b_eq_den : Fin nEq → ℤ)
    (A_le_num A_le_den : Fin nLe → Fin nVars → ℤ)
    (b_le_num b_le_den : Fin nLe → ℤ)
    (hEqDenPos : ∀ i j, 0 < A_eq_den i j)
    (hbEqDenPos : ∀ i, 0 < b_eq_den i)
    (hLeDenPos : ∀ k j, 0 < A_le_den k j)
    (hbLeDenPos : ∀ k, 0 < b_le_den k)
    (hEqNumB : ∀ i j, (A_eq_num i j).natAbs ≤ 2 ^ B')
    (hEqDenB : ∀ i j, (A_eq_den i j).natAbs ≤ 2 ^ B')
    (hbEqNumB : ∀ i, (b_eq_num i).natAbs ≤ 2 ^ B')
    (hbEqDenB : ∀ i, (b_eq_den i).natAbs ≤ 2 ^ B')
    (hLeNumB : ∀ k j, (A_le_num k j).natAbs ≤ 2 ^ B')
    (hLeDenB : ∀ k j, (A_le_den k j).natAbs ≤ 2 ^ B')
    (hbLeNumB : ∀ k, (b_le_num k).natAbs ≤ 2 ^ B')
    (hbLeDenB : ∀ k, (b_le_den k).natAbs ≤ 2 ^ B') :
    let (flag, solNum, solDen) := solveRationalLP
      A_eq_num A_eq_den b_eq_num b_eq_den A_le_num A_le_den b_le_num b_le_den
    let xRat : Fin nVars → ℚ := fun j => (solNum j : ℚ) / (solDen j : ℚ)
    let B_int : ℕ := B' * (nVars + 2)
    (flag = 0 ∨ flag = 1) ∧
    (flag = 1 ↔
      ∃ x : Fin nVars → ℝ,
        (∀ i : Fin nEq, ∑ j : Fin nVars, (((A_eq_num i j : ℚ) / (A_eq_den i j : ℚ) : ℚ) : ℝ) * x j =
          (((b_eq_num i : ℚ) / (b_eq_den i : ℚ) : ℚ) : ℝ)) ∧
        (∀ k : Fin nLe, ∑ j : Fin nVars, (((A_le_num k j : ℚ) / (A_le_den k j : ℚ) : ℚ) : ℝ) * x j ≤
          (((b_le_num k : ℚ) / (b_le_den k : ℚ) : ℚ) : ℝ))) ∧
    (flag = 1 →
      (∀ j : Fin nVars,
        0 < solDen j ∧
        (solNum j).natAbs ≤ (nVars + 1).factorial * (2 ^ B_int) ^ (nVars + 1) ∧
        (solDen j).natAbs ≤ (nVars + 1).factorial * (2 ^ B_int) ^ (nVars + 1)) ∧
      (∀ i : Fin nEq, ∑ j : Fin nVars, ((A_eq_num i j : ℚ) / (A_eq_den i j : ℚ)) * xRat j =
        (b_eq_num i : ℚ) / (b_eq_den i : ℚ)) ∧
      (∀ k : Fin nLe, ∑ j : Fin nVars, ((A_le_num k j : ℚ) / (A_le_den k j : ℚ)) * xRat j ≤
        (b_le_num k : ℚ) / (b_le_den k : ℚ))) := by
  let M_eq : Fin nEq → Fin nVars → ℤ :=
    fun i => clearRowCoeffs nVars (A_eq_num i) (A_eq_den i) (b_eq_den i)
  let d_eq : Fin nEq → ℤ :=
    fun i => clearRowRhs nVars (A_eq_den i) (b_eq_num i) (b_eq_den i)
  let M_le : Fin nLe → Fin nVars → ℤ :=
    fun k => clearRowCoeffs nVars (A_le_num k) (A_le_den k) (b_le_den k)
  let d_le : Fin nLe → ℤ :=
    fun k => clearRowRhs nVars (A_le_den k) (b_le_num k) (b_le_den k)
  let B_int : ℕ := B' * (nVars + 2)
  have hB_int : 1 ≤ B_int := by dsimp [B_int]; nlinarith only [hB']
  have hEqSpec := fun i => clearRow_spec (A_eq_num i) (A_eq_den i) (b_eq_num i) (b_eq_den i)
    (hEqDenPos i) (hbEqDenPos i) (hEqNumB i) (hEqDenB i) (hbEqNumB i) (hbEqDenB i)
  have hLeSpec := fun k => clearRow_spec (A_le_num k) (A_le_den k) (b_le_num k) (b_le_den k)
    (hLeDenPos k) (hbLeDenPos k) (hLeNumB k) (hLeDenB k) (hbLeNumB k) (hbLeDenB k)
  have hCore := solveCoreIntLP_spec hB_int M_eq d_eq M_le d_le
    (fun i j => (hEqSpec i).2.2.1 j)
    (fun i => (hEqSpec i).2.2.2.1)
    (fun k j => (hLeSpec k).2.2.1 j)
    (fun k => (hLeSpec k).2.2.2.1)
  unfold solveRationalLP
  let res := solveCoreIntLP M_eq d_eq M_le d_le
  change (res.1 = 0 ∨ res.1 = 1) ∧ _ ∧ _ at hCore
  obtain ⟨hFlag01, hFlagIff, hWhen1⟩ := hCore
  have hEqRowReal : ∀ (i : Fin nEq) (x : Fin nVars → ℝ),
      (∑ j : Fin nVars, (M_eq i j : ℝ) * x j = (d_eq i : ℝ)) ↔
      (∑ j : Fin nVars, (((A_eq_num i j : ℚ) / (A_eq_den i j : ℚ) : ℚ) : ℝ) * x j =
        (((b_eq_num i : ℚ) / (b_eq_den i : ℚ) : ℚ) : ℝ)) := by
    intro i x
    let D := clearRowDen nVars (A_eq_den i) (b_eq_den i)
    have hD_pos : (0 : ℝ) < (D : ℝ) := by exact_mod_cast (hEqSpec i).1
    have hM_i : ∀ j, (M_eq i j : ℝ) = (D : ℝ) * (((A_eq_num i j : ℚ) / (A_eq_den i j : ℚ) : ℚ) : ℝ) := by
      intro j
      have hQ := (hEqSpec i).2.2.2.2.1 j
      exact_mod_cast hQ
    have hd_i : (d_eq i : ℝ) = (D : ℝ) * (((b_eq_num i : ℚ) / (b_eq_den i : ℚ) : ℚ) : ℝ) := by
      have hQ := (hEqSpec i).2.2.2.2.2
      exact_mod_cast hQ
    have hSum : ∑ j : Fin nVars, (M_eq i j : ℝ) * x j =
        (D : ℝ) * ∑ j : Fin nVars, (((A_eq_num i j : ℚ) / (A_eq_den i j : ℚ) : ℚ) : ℝ) * x j := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun j _ => by rw [hM_i j, mul_assoc])
    rw [hSum, hd_i]
    exact mul_right_inj' hD_pos.ne'
  have hLeRowReal : ∀ (k : Fin nLe) (x : Fin nVars → ℝ),
      (∑ j : Fin nVars, (M_le k j : ℝ) * x j ≤ (d_le k : ℝ)) ↔
      (∑ j : Fin nVars, (((A_le_num k j : ℚ) / (A_le_den k j : ℚ) : ℚ) : ℝ) * x j ≤
        (((b_le_num k : ℚ) / (b_le_den k : ℚ) : ℚ) : ℝ)) := by
    intro k x
    let D := clearRowDen nVars (A_le_den k) (b_le_den k)
    have hD_pos : (0 : ℝ) < (D : ℝ) := by exact_mod_cast (hLeSpec k).1
    have hM_k : ∀ j, (M_le k j : ℝ) = (D : ℝ) * (((A_le_num k j : ℚ) / (A_le_den k j : ℚ) : ℚ) : ℝ) := by
      intro j
      have hQ := (hLeSpec k).2.2.2.2.1 j
      exact_mod_cast hQ
    have hd_k : (d_le k : ℝ) = (D : ℝ) * (((b_le_num k : ℚ) / (b_le_den k : ℚ) : ℚ) : ℝ) := by
      have hQ := (hLeSpec k).2.2.2.2.2
      exact_mod_cast hQ
    have hSum : ∑ j : Fin nVars, (M_le k j : ℝ) * x j =
        (D : ℝ) * ∑ j : Fin nVars, (((A_le_num k j : ℚ) / (A_le_den k j : ℚ) : ℚ) : ℝ) * x j := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun j _ => by rw [hM_k j, mul_assoc])
    rw [hSum, hd_k]
    exact mul_le_mul_iff_right₀ hD_pos
  refine ⟨hFlag01, ?_, ?_⟩
  · rw [hFlagIff]
    exact ⟨fun ⟨x, h1, h2⟩ => ⟨x, fun i => (hEqRowReal i x).mp (h1 i), fun k => (hLeRowReal k x).mp (h2 k)⟩,
      fun ⟨x, h1, h2⟩ => ⟨x, fun i => (hEqRowReal i x).mpr (h1 i), fun k => (hLeRowReal k x).mpr (h2 k)⟩⟩
  · intro h1
    obtain ⟨hSolB, hSolEqQ, hSolLeQ⟩ := hWhen1 h1
    refine ⟨hSolB, fun i => ?_, fun k => ?_⟩
    · have hR : ∑ j : Fin nVars, (((A_eq_num i j : ℚ) / (A_eq_den i j : ℚ) : ℚ) : ℝ) * ((res.2.1 j : ℚ) / (res.2.2 j : ℚ) : ℝ) =
          (((b_eq_num i : ℚ) / (b_eq_den i : ℚ) : ℚ) : ℝ) := by
        apply (hEqRowReal i _).mp
        have := hSolEqQ i
        exact_mod_cast this
      exact_mod_cast hR
    · have hR : ∑ j : Fin nVars, (((A_le_num k j : ℚ) / (A_le_den k j : ℚ) : ℚ) : ℝ) * ((res.2.1 j : ℚ) / (res.2.2 j : ℚ) : ℝ) ≤
          (((b_le_num k : ℚ) / (b_le_den k : ℚ) : ℚ) : ℝ) := by
        apply (hLeRowReal k _).mp
        have := hSolLeQ k
        exact_mod_cast this
      exact_mod_cast hR

end UL.Proof.cit_gls88_rational_lp.RacerCG

