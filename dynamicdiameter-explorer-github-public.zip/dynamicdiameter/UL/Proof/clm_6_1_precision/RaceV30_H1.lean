import Mathlib
import UL.Stmt.clm_6_1_precision
import UL.Proof.lem_6_2.H1
import UL.Proof.lem_6_3.H5_Prob
set_option autoImplicit false

open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Real

namespace UL.Proof_clm_6_1_precision_RaceV30

/-! ### 1. Basic constants and rational bit-length helper -/

theorem two_le_sqrt_two_pi : (2 : ℝ) ≤ Real.sqrt (2 * Real.pi) := by
  have hpi : (3 : ℝ) < Real.pi := Real.pi_gt_three
  calc (2 : ℝ) = Real.sqrt 4 := by norm_num
    _ ≤ Real.sqrt (2 * Real.pi) := Real.sqrt_le_sqrt (by linarith)

theorem sqrt_two_pi_le_four : Real.sqrt (2 * Real.pi) ≤ 4 := by
  have hpi : Real.pi < 4 := Real.pi_lt_four
  calc Real.sqrt (2 * Real.pi) ≤ Real.sqrt 16 := Real.sqrt_le_sqrt (by linarith)
    _ = 4 := by norm_num

theorem natBitLength_le_of_lt_two_pow {n B : ℕ} (hB : 1 ≤ B) (hn : n < 2 ^ B) :
    UL.natBitLength n ≤ B := by
  unfold UL.natBitLength
  by_cases h0 : n = 0
  · subst h0; simp; omega
  · have hlt : Nat.log 2 n < B := Nat.log_lt_of_lt_pow h0 hn
    omega

theorem ratCoordBitBounded_of_div {z : ℤ} {D B : ℕ}
    (hB : 1 ≤ B) (hD : 1 ≤ D) (hD_lt : D < 2 ^ B) (hz_lt : z.natAbs < 2 ^ B) :
    UL.RatCoordBitBounded B ((z : ℚ) / (D : ℚ)) := by
  set q : ℚ := (z : ℚ) / (D : ℚ)
  have hD_pos : 0 < D := hD
  have hq_eq : (q.num : ℚ) / (q.den : ℚ) = (z : ℚ) / (D : ℚ) := Rat.num_div_den q
  have hq_den_ne : (q.den : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr q.den_nz
  have hD_ne : (D : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hcross_q : (q.num : ℚ) * (D : ℚ) = (z : ℚ) * (q.den : ℚ) :=
    (div_eq_div_iff hq_den_ne hD_ne).mp hq_eq
  have hcross_z : q.num * (D : ℤ) = z * (q.den : ℤ) := by exact_mod_cast hcross_q
  have hcross_nat : q.num.natAbs * D = z.natAbs * q.den := by
    have h := congrArg Int.natAbs hcross_z
    simpa [Int.natAbs_mul] using h
  have hdvd_prod : q.den ∣ q.num.natAbs * D := ⟨z.natAbs, by rw [hcross_nat, mul_comm]⟩
  have hdvd_D : q.den ∣ D := q.reduced.symm.dvd_of_dvd_mul_left hdvd_prod
  have hden_le : q.den ≤ D := Nat.le_of_dvd hD_pos hdvd_D
  have hnum_le : q.num.natAbs ≤ z.natAbs := by
    have hmul_le : q.num.natAbs * D ≤ z.natAbs * D := by
      rw [hcross_nat]
      exact Nat.mul_le_mul_left z.natAbs hden_le
    exact Nat.le_of_mul_le_mul_right hmul_le hD_pos
  exact ⟨natBitLength_le_of_lt_two_pow hB (lt_of_le_of_lt hnum_le hz_lt),
    natBitLength_le_of_lt_two_pow hB (lt_of_le_of_lt hden_le hD_lt)⟩

/-! ### 2. Part 1: 1D Gaussian anti-concentration and comparison stability -/

theorem test_iff_of_two_sided_margin {d' : ℕ}
    {u G G' : EuclideanSpace ℝ (Fin d')} {τ τ' Δ : ℝ}
    (hdiff : |τ' - τ| + |inner ℝ (G' - G) u| ≤ Δ)
    (hnot : inner ℝ G u ∉ Set.Icc (τ - Δ) (τ + Δ)) :
    UL.gaussianDataTest τ' G' u ↔ τ ≤ inner ℝ G u := by
  unfold UL.gaussianDataTest
  rw [inner_sub_left] at hdiff
  have ht1 : -|τ' - τ| ≤ τ' - τ := neg_abs_le _
  have ht2 : τ' - τ ≤ |τ' - τ| := le_abs_self _
  have hi1 : -|inner ℝ G' u - inner ℝ G u| ≤ inner ℝ G' u - inner ℝ G u := neg_abs_le _
  have hi2 : inner ℝ G' u - inner ℝ G u ≤ |inner ℝ G' u - inner ℝ G u| := le_abs_self _
  have hΔ0 : 0 ≤ Δ := le_trans (add_nonneg (abs_nonneg _) (abs_nonneg _)) hdiff
  by_cases hlo : τ - Δ ≤ inner ℝ G u
  · have hhi : ¬ (inner ℝ G u ≤ τ + Δ) := fun h => hnot ⟨hlo, h⟩
    push_neg at hhi
    exact ⟨fun _ => by linarith, fun _ => by linarith⟩
  · push_neg at hlo
    exact ⟨fun h => by linarith, fun h => by linarith⟩

theorem stdGaussian_inner_Icc_le {d' : ℕ}
    (u : EuclideanSpace ℝ (Fin d')) (hu : UL.IsUnitVec u)
    (τ Δ : ℝ) (hΔ : 0 ≤ Δ) :
    (UL.stdGaussianMeasure d').real {G | inner ℝ G u ∈ Set.Icc (τ - Δ) (τ + Δ)} ≤
      2 * Δ / Real.sqrt (2 * Real.pi) := by
  have hmeas_f : Measurable (fun G : EuclideanSpace ℝ (Fin d') => inner ℝ G u) :=
    (continuous_id.inner continuous_const).measurable
  let S : Set ℝ := Set.Icc (τ - Δ) (τ + Δ)
  have hpre : {G : EuclideanSpace ℝ (Fin d') | inner ℝ G u ∈ S} =
      (fun G => inner ℝ G u) ⁻¹' S := rfl
  rw [hpre, MeasureTheory.measureReal_def, ← Measure.map_apply hmeas_f measurableSet_Icc,
    UL.Proof_lem_6_2.map_inner_stdGaussianMeasure u hu]
  change (gaussianReal 0 1).real S ≤ 2 * Δ / Real.sqrt (2 * Real.pi)
  have h_eq_int : (gaussianReal 0 1).real S = ∫ x in S, gaussianPDFReal 0 1 x := by
    rw [MeasureTheory.measureReal_def, gaussianReal_apply_eq_integral 0 one_ne_zero S,
      ENNReal.toReal_ofReal (integral_nonneg fun x => gaussianPDFReal_nonneg 0 1 x)]
  let c : ℝ := (Real.sqrt (2 * Real.pi))⁻¹
  have hc_ge : ∀ x ∈ S, gaussianPDFReal 0 1 x ≤ c := by
    intro x _
    have hexp : Real.exp (-(x ^ 2 / 2)) ≤ 1 := by
      apply Real.exp_le_one_iff.mpr
      have : 0 ≤ x ^ 2 / 2 := by positivity
      linarith
    have hpdf : gaussianPDFReal 0 1 x = c * Real.exp (-(x ^ 2 / 2)) := by
      unfold gaussianPDFReal c
      simp [neg_div]
    rw [hpdf]
    calc c * Real.exp (-(x ^ 2 / 2)) ≤ c * 1 :=
          mul_le_mul_of_nonneg_left hexp (by unfold c; positivity)
      _ = c := mul_one c
  have hint : ∫ x in S, gaussianPDFReal 0 1 x ≤ volume.real S • c := by
    rw [← MeasureTheory.setIntegral_const c]
    exact MeasureTheory.setIntegral_mono_on
      (integrable_gaussianPDFReal 0 1).integrableOn
      (MeasureTheory.integrableOn_const measure_Icc_lt_top.ne)
      measurableSet_Icc hc_ge
  have hab : τ - Δ ≤ τ + Δ := by linarith
  have hvol : volume.real S = 2 * Δ := by
    rw [Real.volume_real_Icc_of_le hab]
    ring
  rw [h_eq_int]
  refine hint.trans_eq ?_
  rw [hvol, smul_eq_mul]
  dsimp only [c]
  ring

theorem stdGaussian_inner_Icc_le_delta {d' : ℕ}
    (u : EuclideanSpace ℝ (Fin d')) (hu : UL.IsUnitVec u)
    (τ Δ : ℝ) (hΔ : 0 ≤ Δ) :
    (UL.stdGaussianMeasure d').real {G | inner ℝ G u ∈ Set.Icc (τ - Δ) (τ + Δ)} ≤ Δ := by
  have h1 := stdGaussian_inner_Icc_le u hu τ Δ hΔ
  have hsqrt : (2 : ℝ) ≤ Real.sqrt (2 * Real.pi) := two_le_sqrt_two_pi
  have hsqrt_pos : 0 < Real.sqrt (2 * Real.pi) := by linarith
  have h2 : 2 * Δ / Real.sqrt (2 * Real.pi) ≤ Δ := by
    rw [div_le_iff₀ hsqrt_pos]
    nlinarith
  exact h1.trans h2

theorem part1_proof :
    ∀ (d' : ℕ), 1 ≤ d' →
      ∀ (u : EuclideanSpace ℝ (Fin d')), UL.IsUnitVec u →
      ∀ (τ Δ : ℝ), 0 ≤ Δ →
        (∀ G G_approx : EuclideanSpace ℝ (Fin d'),
          |inner ℝ (G_approx - G) u| ≤ Δ →
          inner ℝ G u ∉ Set.Icc (τ - Δ) (τ + Δ) →
          (UL.gaussianDataTest τ G_approx u ↔ UL.gaussianDataTest τ G u)) ∧
        (UL.stdGaussianMeasure d').real {G | inner ℝ G u ∈ Set.Icc (τ - Δ) (τ + Δ)} ≤
          2 * Δ / Real.sqrt (2 * Real.pi) := by
  intro d' _hd' u hu τ Δ hΔ
  refine ⟨fun G G_approx hdiff hnot => ?_, stdGaussian_inner_Icc_le u hu τ Δ hΔ⟩
  exact test_iff_of_two_sided_margin (τ' := τ) (by simpa using hdiff) hnot

/-! ### 3. Part 2: Finite list union bound over cap comparisons -/

theorem measureReal_exists_mem_list_le {Ω α : Type*} [MeasurableSpace Ω]
    (μ : Measure Ω) [IsFiniteMeasure μ]
    (L : List α) (E : α → Set Ω) {B : ℝ} (hB : 0 ≤ B)
    (hE : ∀ c ∈ L, μ.real (E c) ≤ B) :
    μ.real {ω | ∃ c ∈ L, ω ∈ E c} ≤ (L.length : ℝ) * B := by
  induction L with
  | nil =>
      have hemp : {ω : Ω | ∃ c ∈ ([] : List α), ω ∈ E c} = ∅ := by ext ω; simp
      rw [hemp]
      simp
  | cons a tl ih =>
      have hset : {ω : Ω | ∃ c ∈ a :: tl, ω ∈ E c} = E a ∪ {ω : Ω | ∃ c ∈ tl, ω ∈ E c} := by
        ext ω
        simp [List.mem_cons, or_and_right, exists_or]
      rw [hset, List.length_cons, Nat.cast_add, Nat.cast_one, add_mul, one_mul]
      have ha : μ.real (E a) ≤ B := hE a (List.mem_cons_self)
      have htl : μ.real {ω | ∃ c ∈ tl, ω ∈ E c} ≤ (tl.length : ℝ) * B :=
        ih (fun c hc => hE c (List.mem_cons_of_mem a hc))
      linarith [UL.Proof_lem_6_3.measureReal_union_le_add μ (E a) {ω | ∃ c ∈ tl, ω ∈ E c}]

theorem pi_coord_inner_Icc_le_delta {ι : Type*} [Fintype ι] {d' : ℕ}
    (r : ι) (u : EuclideanSpace ℝ (Fin d')) (hu : UL.IsUnitVec u)
    (τ Δ : ℝ) (hΔ : 0 ≤ Δ) :
    (Measure.pi (fun _ : ι => UL.stdGaussianMeasure d')).real
        {G | inner ℝ (G r) u ∈ Set.Icc (τ - Δ) (τ + Δ)} ≤ Δ := by
  let μ_pi := Measure.pi (fun _ : ι => UL.stdGaussianMeasure d')
  let A : Set (EuclideanSpace ℝ (Fin d')) := {g | inner ℝ g u ∈ Set.Icc (τ - Δ) (τ + Δ)}
  have hA_meas : MeasurableSet A :=
    measurableSet_Icc.preimage (continuous_id.inner continuous_const).measurable
  have hmp := MeasureTheory.measurePreserving_eval (fun _ : ι => UL.stdGaussianMeasure d') r
  have hpre : {G : ι → EuclideanSpace ℝ (Fin d') | inner ℝ (G r) u ∈ Set.Icc (τ - Δ) (τ + Δ)} =
      (Function.eval r) ⁻¹' A := rfl
  rw [hpre, MeasureTheory.measureReal_def, ← Measure.map_apply hmp.measurable hA_meas,
    hmp.map_eq, ← MeasureTheory.measureReal_def]
  exact stdGaussian_inner_Icc_le_delta u hu τ Δ hΔ

theorem part2_proof :
    ∀ (d' K : ℕ), 1 ≤ d' → 1 ≤ K →
      ∀ (cmps : List (Fin K × EuclideanSpace ℝ (Fin d') × ℝ)),
        1 ≤ cmps.length →
        (∀ c ∈ cmps, UL.IsUnitVec c.2.1) →
        ∀ (ε : ℝ), 0 < ε →
        ∀ (p_bits : ℕ),
          Real.logb 2 (cmps.length : ℝ) + Real.logb 2 (1 / ε) ≤ (p_bits : ℝ) →
          (MeasureTheory.Measure.pi (fun _ : Fin K => UL.stdGaussianMeasure d')).real
              {G | ∃ c ∈ cmps, inner ℝ (G c.1) c.2.1 ∈
                Set.Icc (c.2.2 - (2 : ℝ) ^ (-(p_bits : ℤ)))
                        (c.2.2 + (2 : ℝ) ^ (-(p_bits : ℤ)))} ≤ ε ∧
          (∀ G G_approx : Fin K → EuclideanSpace ℝ (Fin d'),
            (∀ r : Fin K, ‖G_approx r - G r‖ ≤ (2 : ℝ) ^ (-(p_bits : ℤ))) →
            (¬ ∃ c ∈ cmps, inner ℝ (G c.1) c.2.1 ∈
              Set.Icc (c.2.2 - (2 : ℝ) ^ (-(p_bits : ℤ)))
                      (c.2.2 + (2 : ℝ) ^ (-(p_bits : ℤ)))) →
            ∀ c ∈ cmps,
              (UL.gaussianDataTest c.2.2 (G_approx c.1) c.2.1 ↔
                UL.gaussianDataTest c.2.2 (G c.1) c.2.1)) := by
  intro d' K _hd' _hK cmps hlen hunit ε hε p_bits hbits
  let Δ : ℝ := (2 : ℝ) ^ (-(p_bits : ℤ))
  have hΔ_pos : 0 < Δ := by positivity
  refine ⟨?_, ?_⟩
  · let μ_K := Measure.pi (fun _ : Fin K => UL.stdGaussianMeasure d')
    let E_c : (Fin K × EuclideanSpace ℝ (Fin d') × ℝ) → Set (Fin K → EuclideanSpace ℝ (Fin d')) :=
      fun c => {G | inner ℝ (G c.1) c.2.1 ∈ Set.Icc (c.2.2 - Δ) (c.2.2 + Δ)}
    have hstep1 : μ_K.real {G | ∃ c ∈ cmps, G ∈ E_c c} ≤ (cmps.length : ℝ) * Δ :=
      measureReal_exists_mem_list_le μ_K cmps E_c hΔ_pos.le
        (fun c hc => pi_coord_inner_Icc_le_delta c.1 c.2.1 (hunit c hc) c.2.2 Δ hΔ_pos.le)
    have hlen_pos : (0 : ℝ) < (cmps.length : ℝ) := by exact_mod_cast hlen
    have hlog2_pos : 0 < Real.log 2 := Real.log_pos (by norm_num)
    have hlog_le : Real.log ((cmps.length : ℝ) * (1 / ε)) ≤ Real.log ((2 : ℝ) ^ p_bits) := by
      unfold Real.logb at hbits
      rw [← add_div, div_le_iff₀ hlog2_pos] at hbits
      rw [Real.log_mul hlen_pos.ne' (by positivity), Real.log_pow]
      exact hbits
    have hprod_le : (cmps.length : ℝ) * (1 / ε) ≤ (2 : ℝ) ^ p_bits := by
      have hexp := Real.exp_le_exp.mpr hlog_le
      rwa [Real.exp_log (by positivity), Real.exp_log (by positivity)] at hexp
    have hΔ_eq : Δ = ((2 : ℝ) ^ p_bits)⁻¹ := by
      dsimp [Δ]
      rw [zpow_neg, zpow_natCast]
    have hbound : (cmps.length : ℝ) * Δ ≤ ε := by
      rw [hΔ_eq, ← div_eq_mul_inv, div_le_iff₀ (by positivity)]
      have hmul := mul_le_mul_of_nonneg_right hprod_le hε.le
      calc (cmps.length : ℝ) = ((cmps.length : ℝ) * (1 / ε)) * ε := by field_simp
        _ ≤ (2 : ℝ) ^ p_bits * ε := hmul
        _ = ε * (2 : ℝ) ^ p_bits := mul_comm _ _
    exact hstep1.trans hbound
  · intro G G_approx hnorm hno c hc
    have hc_not : inner ℝ (G c.1) c.2.1 ∉ Set.Icc (c.2.2 - Δ) (c.2.2 + Δ) :=
      fun hmem => hno ⟨c, hc, hmem⟩
    have hu : ‖c.2.1‖ = 1 := hunit c hc
    have hcs : |inner ℝ (G_approx c.1 - G c.1) c.2.1| ≤ Δ := by
      calc |inner ℝ (G_approx c.1 - G c.1) c.2.1|
          ≤ ‖G_approx c.1 - G c.1‖ * ‖c.2.1‖ := abs_real_inner_le_norm _ _
        _ = ‖G_approx c.1 - G c.1‖ := by rw [hu, mul_one]
        _ ≤ Δ := hnorm c.1
    exact test_iff_of_two_sided_margin (τ' := c.2.2) (by simpa using hcs) hc_not

/-! ### 4. Part 3: Exact rational signed-squared cap test -/

theorem real_signed_sq_cap_iff {R L s : ℝ} (hs : 0 < s) :
    R * s ≤ L ↔
      ((0 < R ∧ 0 ≤ L ∧ R ^ 2 * s ^ 2 ≤ L ^ 2) ∨
       (R ≤ 0 ∧ (0 ≤ L ∨ L ^ 2 ≤ R ^ 2 * s ^ 2))) := by
  constructor
  · intro h
    by_cases hR : 0 < R
    · left
      have hRs : 0 < R * s := mul_pos hR hs
      have hL : 0 ≤ L := by linarith
      refine ⟨hR, hL, ?_⟩
      nlinarith
    · right
      push_neg at hR
      refine ⟨hR, ?_⟩
      by_cases hL : 0 ≤ L
      · exact Or.inl hL
      · push_neg at hL
        exact Or.inr (by nlinarith)
  · rintro (⟨hR, hL, hsq⟩ | ⟨hR, hL | hsq⟩)
    · have hRs : 0 ≤ R * s := mul_nonneg hR.le hs.le
      nlinarith
    · have hRs : R * s ≤ 0 := mul_nonpos_of_nonpos_of_nonneg hR hs.le
      linarith
    · have hRs : R * s ≤ 0 := mul_nonpos_of_nonpos_of_nonneg hR hs.le
      by_cases hL0 : 0 ≤ L
      · linarith
      · push_neg at hL0
        nlinarith

theorem part3_data_iff {d : ℕ} (A B a₀ : ℚ) (Gtilde : Fin (d + 1) → ℚ) (w : Fin d → ℚ)
    (hw : UL.ratPointToEuclidean w ≠ 0) :
    UL.gaussianDataTest (a₀ : ℝ) (UL.ratPointToEuclidean Gtilde) (UL.paddedNormalizedRatVec A B w) ↔
      UL.ratSignedSquaredCapTest A B a₀ Gtilde w := by
  let wE : EuclideanSpace ℝ (Fin d) := UL.ratPointToEuclidean w
  have hw_pos : 0 < ‖wE‖ := norm_pos_iff.mpr hw
  have hw_ne : ‖wE‖ ≠ 0 := hw_pos.ne'
  let L_q : ℚ := A * ∑ i : Fin d, Gtilde (Fin.castSucc i) * w i
  let R_q : ℚ := a₀ - B * Gtilde (Fin.last d)
  let N_q : ℚ := ∑ i : Fin d, (w i) ^ 2
  have hinner : inner ℝ (UL.ratPointToEuclidean Gtilde) (UL.paddedNormalizedRatVec A B w) =
      (L_q : ℝ) / ‖wE‖ + (B : ℝ) * (Gtilde (Fin.last d) : ℝ) := by
    rw [PiLp.inner_apply, Fin.sum_univ_castSucc]
    have hbase : (∑ i : Fin d, inner ℝ ((UL.ratPointToEuclidean Gtilde) (Fin.castSucc i))
        ((UL.paddedNormalizedRatVec A B w) (Fin.castSucc i))) = (L_q : ℝ) / ‖wE‖ := by
      have hterm : ∀ i : Fin d,
          inner ℝ ((UL.ratPointToEuclidean Gtilde) (Fin.castSucc i))
              ((UL.paddedNormalizedRatVec A B w) (Fin.castSucc i)) =
            ((A : ℝ) * ((Gtilde (Fin.castSucc i) : ℝ) * (w i : ℝ))) / ‖wE‖ := by
        intro i
        simp only [UL.ratPointToEuclidean, UL.paddedNormalizedRatVec, UL.euclideanCoord, wE,
          WithLp.equiv_symm_apply, WithLp.equiv_apply, Fin.snoc_castSucc,
          RCLike.inner_apply, conj_trivial]
        ring
      simp_rw [hterm, ← Finset.sum_div, ← Finset.mul_sum]
      congr 1
      simp [L_q, Rat.cast_mul, Rat.cast_sum]
    have hlast : inner ℝ ((UL.ratPointToEuclidean Gtilde) (Fin.last d))
        ((UL.paddedNormalizedRatVec A B w) (Fin.last d)) =
        (B : ℝ) * (Gtilde (Fin.last d) : ℝ) := by
      simp only [UL.ratPointToEuclidean, UL.paddedNormalizedRatVec,
        WithLp.equiv_symm_apply, Fin.snoc_last, RCLike.inner_apply, conj_trivial]
    rw [hbase, hlast]
  have hN_eq : (N_q : ℝ) = ‖wE‖ ^ 2 := by
    rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
    simp only [N_q, wE, UL.ratPointToEuclidean, WithLp.equiv_symm_apply,
      RCLike.inner_apply, conj_trivial, Rat.cast_sum, Rat.cast_pow]
    refine Finset.sum_congr rfl fun i _ => by ring
  have hstep1 : UL.gaussianDataTest (a₀ : ℝ)
        (UL.ratPointToEuclidean Gtilde) (UL.paddedNormalizedRatVec A B w) ↔
      (R_q : ℝ) * ‖wE‖ ≤ (L_q : ℝ) := by
    unfold UL.gaussianDataTest
    rw [hinner]
    have hR : (R_q : ℝ) = (a₀ : ℝ) - (B : ℝ) * (Gtilde (Fin.last d) : ℝ) := by
      simp [R_q]
    constructor
    · intro h
      have h1 : (R_q : ℝ) ≤ (L_q : ℝ) / ‖wE‖ := by linarith
      exact (le_div_iff₀ hw_pos).mp h1
    · intro h
      have h1 : (R_q : ℝ) ≤ (L_q : ℝ) / ‖wE‖ := (le_div_iff₀ hw_pos).mpr h
      linarith
  rw [hstep1, real_signed_sq_cap_iff hw_pos, ← hN_eq]
  unfold UL.ratSignedSquaredCapTest
  change ((0 : ℝ) < (R_q : ℝ) ∧ (0 : ℝ) ≤ (L_q : ℝ) ∧ (R_q : ℝ) ^ 2 * (N_q : ℝ) ≤ (L_q : ℝ) ^ 2) ∨
      ((R_q : ℝ) ≤ 0 ∧ ((0 : ℝ) ≤ (L_q : ℝ) ∨ (L_q : ℝ) ^ 2 ≤ (R_q : ℝ) ^ 2 * (N_q : ℝ))) ↔
    (0 < R_q ∧ 0 ≤ L_q ∧ R_q ^ 2 * N_q ≤ L_q ^ 2) ∨
    (R_q ≤ 0 ∧ (0 ≤ L_q ∨ L_q ^ 2 ≤ R_q ^ 2 * N_q))
  have h1 : ((0 : ℝ) < (R_q : ℝ)) ↔ (0 < R_q) := Rat.cast_pos
  have h2 : ((0 : ℝ) ≤ (L_q : ℝ)) ↔ (0 ≤ L_q) := Rat.cast_nonneg
  have h3 : ((R_q : ℝ) ≤ 0) ↔ (R_q ≤ 0) := Rat.cast_nonpos
  have h4 : ((R_q : ℝ) ^ 2 * (N_q : ℝ) ≤ (L_q : ℝ) ^ 2) ↔ (R_q ^ 2 * N_q ≤ L_q ^ 2) := by
    exact_mod_cast Iff.rfl
  have h5 : ((L_q : ℝ) ^ 2 ≤ (R_q : ℝ) ^ 2 * (N_q : ℝ)) ↔ (L_q ^ 2 ≤ R_q ^ 2 * N_q) := by
    exact_mod_cast Iff.rfl
  rw [h1, h2, h3, h4, h5]

theorem part3_proof :
    ∀ (d : ℕ), 1 ≤ d →
      ∀ (A B : ℚ) (Gtilde : Fin (d + 1) → ℚ) (w : Fin d → ℚ),
        UL.ratPointToEuclidean w ≠ 0 →
        (A ^ 2 + B ^ 2 = 1 → UL.IsUnitVec (UL.paddedNormalizedRatVec A B w)) ∧
        (∀ a₀ : ℚ,
          UL.gaussianDataTest (a₀ : ℝ)
              (UL.ratPointToEuclidean Gtilde) (UL.paddedNormalizedRatVec A B w) ↔
            UL.ratSignedSquaredCapTest A B a₀ Gtilde w) ∧
        (∀ x_q t_q : ℚ,
          UL.gaussianQueryTest (x_q : ℝ) (t_q : ℝ)
              (UL.ratPointToEuclidean Gtilde) (UL.paddedNormalizedRatVec A (-B) w) ↔
            UL.ratSignedSquaredCapTest A (-B) (x_q * t_q) Gtilde w) := by
  intro d _hd A B Gtilde w hw
  refine ⟨?_, fun a₀ => part3_data_iff A B a₀ Gtilde w hw, ?_⟩
  · intro hAB
    unfold UL.IsUnitVec
    let wE : EuclideanSpace ℝ (Fin d) := UL.ratPointToEuclidean w
    have hw_pos : 0 < ‖wE‖ := norm_pos_iff.mpr hw
    have hw_ne : ‖wE‖ ≠ 0 := hw_pos.ne'
    have hnorm_sq : ‖UL.paddedNormalizedRatVec A B w‖ ^ 2 = 1 := by
      rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply, Fin.sum_univ_castSucc]
      have hbase : (∑ i : Fin d,
          inner ℝ ((UL.paddedNormalizedRatVec A B w) (Fin.castSucc i))
            ((UL.paddedNormalizedRatVec A B w) (Fin.castSucc i))) = (A : ℝ) ^ 2 := by
        have hterm : ∀ i : Fin d,
            inner ℝ ((UL.paddedNormalizedRatVec A B w) (Fin.castSucc i))
              ((UL.paddedNormalizedRatVec A B w) (Fin.castSucc i)) =
              (A : ℝ) ^ 2 * ((wE i) ^ 2 / ‖wE‖ ^ 2) := by
          intro i
          simp only [UL.paddedNormalizedRatVec, UL.euclideanCoord, wE,
            WithLp.equiv_symm_apply, WithLp.equiv_apply, Fin.snoc_castSucc,
            RCLike.inner_apply, conj_trivial]
          ring
        simp_rw [hterm, ← Finset.mul_sum, ← Finset.sum_div]
        have hw_sum : (∑ i : Fin d, (wE i) ^ 2) = ‖wE‖ ^ 2 := by
          rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
          refine Finset.sum_congr rfl fun i _ => by simp [sq]
        rw [hw_sum, div_self (pow_ne_zero 2 hw_ne), mul_one]
      have hlast : inner ℝ ((UL.paddedNormalizedRatVec A B w) (Fin.last d))
          ((UL.paddedNormalizedRatVec A B w) (Fin.last d)) = (B : ℝ) ^ 2 := by
        simp only [UL.paddedNormalizedRatVec, WithLp.equiv_symm_apply, Fin.snoc_last,
          RCLike.inner_apply, conj_trivial]
        ring
      rw [hbase, hlast]
      exact_mod_cast hAB
    have hnn : 0 ≤ ‖UL.paddedNormalizedRatVec A B w‖ := norm_nonneg _
    nlinarith
  · intro x_q t_q
    unfold UL.gaussianQueryTest
    have hcast : (x_q : ℝ) * (t_q : ℝ) = ((x_q * t_q : ℚ) : ℝ) := (Rat.cast_mul x_q t_q).symm
    rw [hcast]
    exact part3_data_iff A (-B) (x_q * t_q) Gtilde w hw

end UL.Proof_clm_6_1_precision_RaceV30
