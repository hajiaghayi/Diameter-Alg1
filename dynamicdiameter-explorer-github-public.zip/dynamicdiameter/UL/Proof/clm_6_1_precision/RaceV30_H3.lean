import Mathlib
import UL.Stmt.clm_6_1_precision
import UL.Proof.lem_6_2.H1
import UL.Proof.lem_6_3.H5_Prob
set_option autoImplicit false

open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Real

namespace UL.Proof_clm_6_1_precision_RaceV30

/-! ### 1. Deterministic work, space, and answer validity on any cap family -/

theorem explicitStoredTuples_card_le {ι : Type*} {D R ℓ M₀ : ℕ}
    (F : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d : ℝ) (cap_u : ℕ) (pts : ι → EuclideanSpace ℝ (Fin D)) (r : Fin R) (i : ι) :
    (UL.explicitStoredTuples F τ_d cap_u pts r i).card ≤ cap_u := by
  unfold UL.explicitStoredTuples
  dsimp only
  split_ifs with h
  · exact h
  · simp

theorem explicitPointDataWork_le {ι : Type*} {D R ℓ M₀ : ℕ}
    (F : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d : ℝ) (cap_u : ℕ) (pts : ι → EuclideanSpace ℝ (Fin D)) (i : ι) :
    UL.explicitPointDataWork F τ_d cap_u pts i ≤ R * ℓ * M₀ * D + R * (cap_u * ℓ) := by
  unfold UL.explicitPointDataWork
  have hsum : (∑ r : Fin R, (UL.explicitStoredTuples F τ_d cap_u pts r i).card * ℓ) ≤
      R * (cap_u * ℓ) := by
    calc (∑ r : Fin R, (UL.explicitStoredTuples F τ_d cap_u pts r i).card * ℓ)
        ≤ ∑ _r : Fin R, cap_u * ℓ :=
          Finset.sum_le_sum fun r _ =>
            Nat.mul_le_mul_right ℓ (explicitStoredTuples_card_le F τ_d cap_u pts r i)
      _ = R * (cap_u * ℓ) := by simp
  omega

theorem explicitIndexSpace_le {ι : Type*} {D R ℓ M₀ : ℕ}
    (F : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d : ℝ) (cap_u : ℕ) (gen : UL.SearchGeneration ι D) :
    UL.explicitIndexSpace F τ_d cap_u gen ≤ R * ℓ * M₀ * D + gen.m * (R * (cap_u * ℓ)) := by
  unfold UL.explicitIndexSpace
  have h_inner : ∀ i ∈ gen.P₀,
      (∑ r : Fin R, (UL.explicitStoredTuples F τ_d cap_u gen.pts r i).card * ℓ) ≤
        R * (cap_u * ℓ) := by
    intro i _
    calc (∑ r : Fin R, (UL.explicitStoredTuples F τ_d cap_u gen.pts r i).card * ℓ)
        ≤ ∑ _r : Fin R, cap_u * ℓ :=
          Finset.sum_le_sum fun r _ =>
            Nat.mul_le_mul_right ℓ (explicitStoredTuples_card_le F τ_d cap_u gen.pts r i)
      _ = R * (cap_u * ℓ) := by simp
  have h_outer : (∑ i ∈ gen.P₀,
      ∑ r : Fin R, (UL.explicitStoredTuples F τ_d cap_u gen.pts r i).card * ℓ) ≤
      gen.m * (R * (cap_u * ℓ)) := by
    calc (∑ i ∈ gen.P₀,
          ∑ r : Fin R, (UL.explicitStoredTuples F τ_d cap_u gen.pts r i).card * ℓ)
        ≤ ∑ _i ∈ gen.P₀, R * (cap_u * ℓ) := Finset.sum_le_sum h_inner
      _ = gen.m * (R * (cap_u * ℓ)) := by simp [UL.SearchGeneration.m]
  omega

theorem explicitCappedQuery_valid {ι : Type*} [DecidableEq ι] {D R ℓ M₀ : ℕ}
    (F : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d τ_q : ℝ) (cap_u cap_q : ℕ)
    (gen : UL.SearchGeneration ι D) (P : Finset ι) (q : UL.SearchQuery ι D) :
    q.IsValidAnswer P (UL.explicitCappedQuery F τ_d τ_q cap_u cap_q gen P q) := by
  classical
  unfold UL.SearchQuery.IsValidAnswer UL.IsValidSearchAnswer
  cases hq : UL.explicitCappedQuery F τ_d τ_q cap_u cap_q gen P q with
  | none => trivial
  | some i =>
      unfold UL.explicitCappedQuery at hq
      rcases List.findSome?_eq_some_iff.mp hq with ⟨_, r, _, _, hr_eq, _⟩
      dsimp only at hr_eq
      have hacc_b := List.find?_some hr_eq
      have hacc : q.accept i := of_decide_eq_true hacc_b
      have hmem_take : i ∈ _ := List.mem_of_find?_eq_some hr_eq
      have hmem_cand : i ∈ _ := List.mem_of_mem_take hmem_take
      rcases List.mem_flatMap.mp hmem_cand with ⟨tup, _, hi_list⟩
      have hi_filt : i ∈ (gen.P₀ ∩ P).filter (fun i' =>
          tup ∈ UL.explicitStoredTuples F τ_d cap_u gen.pts r i') :=
        Finset.mem_toList.mp hi_list
      have hi_P : i ∈ P := (Finset.mem_inter.mp (Finset.mem_filter.mp hi_filt).1).2
      exact ⟨hi_P, hacc⟩

theorem explicitQueryWork_le {ι : Type*} [DecidableEq ι] {D R ℓ M₀ : ℕ}
    (F : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d τ_q : ℝ) (cap_u cap_q : ℕ)
    (gen : UL.SearchGeneration ι D) (P : Finset ι) (q : UL.SearchQuery ι D) :
    UL.explicitQueryWork F τ_d τ_q cap_u cap_q gen P q ≤
      R * ℓ * M₀ * D + R * (cap_q * ℓ + (cap_q + 1)) := by
  classical
  unfold UL.explicitQueryWork
  have hsum : (∑ r : Fin R,
      let visitedTuples :=
        (Fintype.piFinset (fun s : Fin ℓ => UL.explicitQueryBaseSet F τ_q q.z r s)).toList.take cap_q
      let candidates := visitedTuples.flatMap fun tup =>
        ((gen.P₀ ∩ P).filter (fun i =>
          tup ∈ UL.explicitStoredTuples F τ_d cap_u gen.pts r i)).toList
      visitedTuples.length * ℓ + (candidates.take (cap_q + 1)).length) ≤
      R * (cap_q * ℓ + (cap_q + 1)) := by
    calc _ ≤ ∑ _r : Fin R, (cap_q * ℓ + (cap_q + 1)) := by
          refine Finset.sum_le_sum fun r _ => ?_
          have h1 : ((Fintype.piFinset
              (fun s : Fin ℓ => UL.explicitQueryBaseSet F τ_q q.z r s)).toList.take cap_q).length ≤
              cap_q := List.length_take_le _ _
          have h2 := List.length_take_le (cap_q + 1)
            (((Fintype.piFinset
              (fun s : Fin ℓ => UL.explicitQueryBaseSet F τ_q q.z r s)).toList.take cap_q).flatMap
              fun tup => ((gen.P₀ ∩ P).filter (fun i =>
                tup ∈ UL.explicitStoredTuples F τ_d cap_u gen.pts r i)).toList)
          have hm1 : ((Fintype.piFinset
              (fun s : Fin ℓ => UL.explicitQueryBaseSet F τ_q q.z r s)).toList.take cap_q).length * ℓ ≤
              cap_q * ℓ := Nat.mul_le_mul_right ℓ h1
          exact Nat.add_le_add hm1 h2
      _ = R * (cap_q * ℓ + (cap_q + 1)) := by simp
  omega

/-! ### 2. Elementary list lemmas -/

private lemma list_map_snd_flatMap_pair {α β : Type*} (xs : List α) (f : α → List β) :
    (xs.flatMap (fun a => (f a).map (fun b => (a, b)))).map Prod.snd = xs.flatMap f := by
  induction xs with
  | nil => rfl
  | cons a tl ih =>
      simp only [List.flatMap_cons, List.map_append, List.map_map, Function.comp_def,
        List.map_id', ih]

private lemma list_mem_flatMap_pair_fst {α β : Type*} {xs : List α} {f : α → List β}
    {p : α × β} (hp : p ∈ xs.flatMap (fun a => (f a).map (fun b => (a, b)))) :
    p.1 ∈ xs ∧ p.2 ∈ f p.1 := by
  rcases List.mem_flatMap.mp hp with ⟨a, ha, hp_map⟩
  rcases List.mem_map.mp hp_map with ⟨b, hb, rfl⟩
  exact ⟨ha, hb⟩

private lemma list_nodup_flatMap_pair {α β : Type*} {xs : List α} (hxs : xs.Nodup)
    (f : α → List β) (hf : ∀ a, (f a).Nodup) :
    (xs.flatMap (fun a => (f a).map (fun b => (a, b)))).Nodup := by
  induction xs with
  | nil => simp
  | cons a tl ih =>
      rcases List.nodup_cons.mp hxs with ⟨ha_not_mem, htl_nodup⟩
      simp only [List.flatMap_cons]
      refine List.nodup_append.mpr ⟨?_, ih htl_nodup, ?_⟩
      · exact (hf a).map (fun b₁ b₂ h => (Prod.ext_iff.mp h).2)
      · intro p₁ hp₁ p₂ hp₂ heq
        subst heq
        rcases List.mem_map.mp hp₁ with ⟨b, _, rfl⟩
        exact ha_not_mem (list_mem_flatMap_pair_fst hp₂).1

private lemma list_map_take_eq {α β : Type*} (xs : List α) (n : ℕ) (g : α → β) :
    (xs.take n).map g = (xs.map g).take n := by
  induction xs generalizing n with
  | nil => simp
  | cons a tl ih =>
      cases n with
      | zero => simp
      | succ m => simp [ih m]

private lemma list_findSome_eq_none_imp {α β : Type*} {xs : List α} {g : α → Option β}
    (h : xs.findSome? g = none) : ∀ x ∈ xs, g x = none := by
  induction xs with
  | nil => intro x hx; cases hx
  | cons a tl ih =>
      intro x hx
      simp only [List.findSome?_cons] at h
      cases hga : g a with
      | some v => rw [hga] at h; simp at h
      | none =>
          rw [hga] at h
          rcases List.mem_cons.mp hx with rfl | htl
          · exact hga
          · exact ih h x htl

/-! ### 3. Copy extraction and single-copy query non-`none` under test agreement -/

theorem finProdFinEquiv_eq_capIdx {ℓ M₀ : ℕ} (j : Fin ℓ) (s : Fin M₀) :
    finProdFinEquiv (j, s) = UL.Proof_lem_6_3.capIdx j s := by
  apply Fin.ext
  dsimp [finProdFinEquiv, UL.Proof_lem_6_3.capIdx]
  ring

noncomputable def extractCopy {R ℓ M₀ D : ℕ} (r : Fin R)
    (F : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) :
    Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin D) :=
  fun u =>
    let js := finProdFinEquiv.symm u
    F (r, js.1, js.2)

@[simp]
theorem extractCopy_capIdx {R ℓ M₀ D : ℕ} (r : Fin R)
    (F : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (j : Fin ℓ) (s : Fin M₀) :
    extractCopy r F (UL.Proof_lem_6_3.capIdx j s) = F (r, j, s) := by
  unfold extractCopy
  rw [← finProdFinEquiv_eq_capIdx, Equiv.symm_apply_apply]

theorem explicitCappedQuery_ne_none_of_copy_good {ι : Type*} [DecidableEq ι]
    {D R ℓ M₀ cap_u cap_q : ℕ} {τ_d τ_q x t_ideal : ℝ}
    (gen : UL.SearchGeneration ι D) (enum : Fin gen.m ≃ ↥gen.P₀)
    (P : Finset ι) (hP : gen.IsSurvivingSubset P)
    (q : UL.SearchQuery ι D) (hcompat : gen.IsCompatible P q)
    {i_star : ι} (hi_star_P : i_star ∈ P)
    (htarget : gen.h ≤ inner ℝ (gen.pts i_star) q.z)
    (F_disc F_id : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (r : Fin R)
    (h_data_eq : ∀ (s : Fin ℓ) (k : Fin M₀), ∀ i ∈ gen.P₀,
      UL.gaussianDataTest τ_d (F_disc (r, s, k)) (gen.pts i) ↔
        UL.gaussianDataTest t_ideal (F_id (r, s, k)) (gen.pts i))
    (h_query_eq : ∀ (s : Fin ℓ) (k : Fin M₀),
      UL.gaussianDataTest τ_q (F_disc (r, s, k)) q.z ↔
        UL.gaussianQueryTest x t_ideal (F_id (r, s, k)) q.z)
    (h_good :
      let ω_r := extractCopy r F_id
      let ptsK : Fin gen.m → EuclideanSpace ℝ (Fin D) := fun k => gen.pts (enum k).1
      (∃ τ : Fin ℓ → Fin M₀, UL.Proof_lem_6_3.IsSharedTuple x t_ideal ω_r (gen.pts i_star) q.z τ) ∧
      UL.Proof_lem_6_3.dataTupleCard t_ideal ω_r (gen.pts i_star) ≤ cap_u ∧
      UL.Proof_lem_6_3.queryTupleCard x t_ideal ω_r q.z ≤ cap_q ∧
      UL.Proof_lem_6_3.badSharedCard x t_ideal ptsK q.z ω_r ≤ cap_q) :
    UL.explicitCappedQuery F_disc τ_d τ_q cap_u cap_q gen P q ≠ none := by
  classical
  let ω_r := extractCopy r F_id
  let ptsK : Fin gen.m → EuclideanSpace ℝ (Fin D) := fun k => gen.pts (enum k).1
  rcases h_good with ⟨⟨τ_star, hτ_data, hτ_query⟩, hcard_u, hcard_q, hcard_bad⟩
  have hi_star_P0 : i_star ∈ gen.P₀ := hP hi_star_P
  -- Target must be accepted by compatibility + `gen.h > 0`
  have hacc_star : q.accept i_star := by
    by_contra hrej
    have hle0 : inner ℝ (gen.pts i_star) q.z ≤ 0 := hcompat i_star hi_star_P hrej
    linarith [gen.h_pos]
  -- Data product finset equals ideal `IsDataTuple` filter for every `i ∈ gen.P₀`
  have hdata_pi_eq : ∀ i ∈ gen.P₀,
      Fintype.piFinset (fun s : Fin ℓ => UL.explicitDataBaseSet F_disc τ_d (gen.pts i) r s) =
        Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ =>
          UL.Proof_lem_6_3.IsDataTuple t_ideal ω_r (gen.pts i) τ) := by
    intro i hi
    ext τ
    simp only [Fintype.mem_piFinset, UL.explicitDataBaseSet, Finset.mem_filter, Finset.mem_univ,
      true_and, UL.Proof_lem_6_3.IsDataTuple, ω_r, extractCopy_capIdx]
    exact forall_congr' fun s => h_data_eq s (τ s) i hi
  -- Stored tuples for `i_star` are uncapped
  have hstored_star : UL.explicitStoredTuples F_disc τ_d cap_u gen.pts r i_star =
      Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ =>
        UL.Proof_lem_6_3.IsDataTuple t_ideal ω_r (gen.pts i_star) τ) := by
    unfold UL.explicitStoredTuples
    dsimp only
    rw [hdata_pi_eq i_star hi_star_P0]
    exact if_pos hcard_u
  -- Stored tuples for any `i ∈ gen.P₀` satisfy `IsDataTuple`
  have hstored_imp : ∀ i ∈ gen.P₀, ∀ τ ∈ UL.explicitStoredTuples F_disc τ_d cap_u gen.pts r i,
      UL.Proof_lem_6_3.IsDataTuple t_ideal ω_r (gen.pts i) τ := by
    intro i hi τ hτ
    unfold UL.explicitStoredTuples at hτ
    dsimp only at hτ
    split_ifs at hτ with hc
    · rw [hdata_pi_eq i hi] at hτ
      exact (Finset.mem_filter.mp hτ).2
    · simp at hτ
  -- Query product finset equals ideal `IsQueryTuple` filter and is uncapped by `take cap_q`
  let QSet := Fintype.piFinset (fun s : Fin ℓ => UL.explicitQueryBaseSet F_disc τ_q q.z r s)
  have hquery_pi_eq : QSet =
      Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ =>
        UL.Proof_lem_6_3.IsQueryTuple x t_ideal ω_r q.z τ) := by
    ext τ
    simp only [QSet, Fintype.mem_piFinset, UL.explicitQueryBaseSet, Finset.mem_filter,
      Finset.mem_univ, true_and, UL.Proof_lem_6_3.IsQueryTuple, ω_r, extractCopy_capIdx]
    exact forall_congr' fun s => h_query_eq s (τ s)
  have hQ_len_le : QSet.toList.length ≤ cap_q := by
    rw [Finset.length_toList, hquery_pi_eq]
    exact hcard_q
  let visitedTuples := QSet.toList.take cap_q
  have hvis_eq : visitedTuples = QSet.toList := List.take_of_length_le hQ_len_le
  let L_cand : (Fin ℓ → Fin M₀) → List ι := fun tup =>
    ((gen.P₀ ∩ P).filter (fun i =>
      tup ∈ UL.explicitStoredTuples F_disc τ_d cap_u gen.pts r i)).toList
  let candidates := visitedTuples.flatMap L_cand
  -- Show copy `r` returns non-`none`
  have hcopy_ne : (candidates.take (cap_q + 1)).find? (fun i => decide (q.accept i)) ≠ none := by
    intro hfind_none
    have hall_rej : ∀ i ∈ candidates.take (cap_q + 1), ¬ q.accept i := by
      intro i hi
      have hd := (List.find?_eq_none.mp hfind_none) i hi
      intro hacc
      exact hd (decide_eq_true hacc)
    -- `i_star ∈ candidates` via `τ_star`
    have hτ_vis : τ_star ∈ visitedTuples := by
      rw [hvis_eq, Finset.mem_toList, hquery_pi_eq, Finset.mem_filter]
      exact ⟨Finset.mem_univ _, hτ_query⟩
    have hi_star_L : i_star ∈ L_cand τ_star := by
      dsimp [L_cand]
      rw [Finset.mem_toList, Finset.mem_filter, Finset.mem_inter, hstored_star, Finset.mem_filter]
      exact ⟨⟨hi_star_P0, hi_star_P⟩, Finset.mem_univ _, hτ_data⟩
    have hi_star_cand : i_star ∈ candidates :=
      List.mem_flatMap.mpr ⟨τ_star, hτ_vis, hi_star_L⟩
    -- Hence `cap_q + 1 ≤ candidates.length`
    have hcand_len : cap_q + 1 ≤ candidates.length := by
      by_contra hlt
      push_neg at hlt
      have htake_all : candidates.take (cap_q + 1) = candidates :=
        List.take_of_length_le hlt.le
      rw [htake_all] at hall_rej
      exact hall_rej i_star hi_star_cand hacc_star
    -- Lift to `pairs` without duplicates and inject into `badSharedCard`
    let pairs : List ((Fin ℓ → Fin M₀) × ι) :=
      visitedTuples.flatMap (fun tup => (L_cand tup).map (fun i => (tup, i)))
    have hpairs_snd : pairs.map Prod.snd = candidates :=
      list_map_snd_flatMap_pair visitedTuples L_cand
    have hpairs_nodup : pairs.Nodup := by
      refine list_nodup_flatMap_pair ?_ L_cand (fun _ => Finset.nodup_toList _)
      rw [hvis_eq]
      exact Finset.nodup_toList _
    let P_take := pairs.take (cap_q + 1)
    have hPtake_nodup : P_take.Nodup := hpairs_nodup.take
    have hpairs_len : cap_q + 1 ≤ pairs.length := by
      have hlen_eq : pairs.length = candidates.length := by
        rw [← hpairs_snd, List.length_map]
      omega
    have hPtake_len : P_take.length = cap_q + 1 :=
      List.length_take_of_le hpairs_len
    have hPtake_card : P_take.toFinset.card = cap_q + 1 := by
      rw [List.toFinset_card_of_nodup hPtake_nodup, hPtake_len]
    have hm_pos : 0 < gen.m := gen.nonempty.card_pos
    let toBadIdx : ((Fin ℓ → Fin M₀) × ι) → Fin gen.m × (Fin ℓ → Fin M₀) := fun p =>
      if hi : p.2 ∈ gen.P₀ then (enum.symm ⟨p.2, hi⟩, p.1) else (⟨0, hm_pos⟩, p.1)
    let BadFin : Finset (Fin gen.m × (Fin ℓ → Fin M₀)) :=
      Finset.univ.filter (fun kt : Fin gen.m × (Fin ℓ → Fin M₀) =>
        inner ℝ (ptsK kt.1) q.z ≤ 0 ∧
          UL.Proof_lem_6_3.IsSharedTuple x t_ideal ω_r (ptsK kt.1) q.z kt.2)
    have hmem_Ptake : ∀ p ∈ P_take.toFinset,
        p.2 ∈ gen.P₀ ∧ p.2 ∈ P ∧ ¬ q.accept p.2 ∧
          UL.Proof_lem_6_3.IsSharedTuple x t_ideal ω_r (gen.pts p.2) q.z p.1 := by
      intro p hp_fin
      have hp_take : p ∈ P_take := List.mem_toFinset.mp hp_fin
      have hp_pairs : p ∈ pairs := List.mem_of_mem_take hp_take
      rcases list_mem_flatMap_pair_fst hp_pairs with ⟨hp1_vis, hp2_L⟩
      have hp1_q : UL.Proof_lem_6_3.IsQueryTuple x t_ideal ω_r q.z p.1 := by
        rw [hvis_eq, Finset.mem_toList, hquery_pi_eq, Finset.mem_filter] at hp1_vis
        exact hp1_vis.2
      have hp2_filt := Finset.mem_filter.mp (Finset.mem_toList.mp hp2_L)
      rcases Finset.mem_inter.mp hp2_filt.1 with ⟨hp2_P0, hp2_P⟩
      have hp1_d : UL.Proof_lem_6_3.IsDataTuple t_ideal ω_r (gen.pts p.2) p.1 :=
        hstored_imp p.2 hp2_P0 p.1 hp2_filt.2
      have hp2_cand_take : p.2 ∈ candidates.take (cap_q + 1) := by
        rw [← hpairs_snd, ← list_map_take_eq]
        exact List.mem_map_of_mem hp_take
      exact ⟨hp2_P0, hp2_P, hall_rej p.2 hp2_cand_take, ⟨hp1_d, hp1_q⟩⟩
    have hinj : Set.InjOn toBadIdx (P_take.toFinset : Set ((Fin ℓ → Fin M₀) × ι)) := by
      intro p₁ hp₁ p₂ hp₂ heq
      have h1 := (hmem_Ptake p₁ hp₁).1
      have h2 := (hmem_Ptake p₂ hp₂).1
      simp only [toBadIdx, dif_pos h1, dif_pos h2, Prod.mk.injEq] at heq
      have hsub := enum.symm.injective heq.1
      have hval : p₁.2 = p₂.2 := congrArg Subtype.val hsub
      exact Prod.ext heq.2 hval
    have himg_sub : P_take.toFinset.image toBadIdx ⊆ BadFin := by
      intro kt hkt
      rcases Finset.mem_image.mp hkt with ⟨p, hp, rfl⟩
      rcases hmem_Ptake p hp with ⟨hp_P0, hp_P, hp_rej, hp_sh⟩
      have hcor : inner ℝ (gen.pts p.2) q.z ≤ 0 := hcompat p.2 hp_P hp_rej
      simp only [toBadIdx, dif_pos hp_P0, BadFin, Finset.mem_filter, Finset.mem_univ, true_and,
        ptsK, Equiv.apply_symm_apply]
      exact ⟨hcor, hp_sh⟩
    have hcard_le : P_take.toFinset.card ≤ BadFin.card := by
      rw [← Finset.card_image_of_injOn hinj]
      exact Finset.card_le_card himg_sub
    have hbad_le : BadFin.card ≤ cap_q := hcard_bad
    omega
  -- Conclude `explicitCappedQuery ≠ none`
  intro hall_none
  unfold UL.explicitCappedQuery at hall_none
  exact hcopy_ne (list_findSome_eq_none_imp hall_none r (List.mem_finRange r))

/-! ### 4. Independent `R`-copy failure probability and `E_ideal` -/

private def sumCapEquiv (R K : ℕ) : Fin K ⊕ (Fin R × Fin K) ≃ Fin (R + 1) × Fin K where
  toFun
    | .inl u => (0, u)
    | .inr (r, u) => (r.succ, u)
  invFun p := Fin.cases (.inl p.2) (fun r' => .inr (r', p.2)) p.1
  left_inv x := by rcases x with u | ⟨r, u⟩ <;> simp
  right_inv p := by rcases p with ⟨r, u⟩; cases r using Fin.cases <;> simp

theorem prod_copies_prob_eq (R K D : ℕ)
    (B : Set (Fin K → EuclideanSpace ℝ (Fin D))) (hB : MeasurableSet B) :
    (Measure.pi (fun _ : Fin R × Fin K => UL.stdGaussianMeasure D)).real
        {F | ∀ r : Fin R, (fun u => F (r, u)) ∈ B} =
      ((Measure.pi (fun _ : Fin K => UL.stdGaussianMeasure D)).real B) ^ R := by
  let μ₀ := UL.stdGaussianMeasure D
  let μ_K := Measure.pi (fun _ : Fin K => μ₀)
  induction R with
  | zero =>
      have hset : {F : Fin 0 × Fin K → EuclideanSpace ℝ (Fin D) |
          ∀ r : Fin 0, (fun u => F (r, u)) ∈ B} = Set.univ := by
        ext F; simp
      rw [hset]
      simp
  | succ R ih =>
      let E_ty := EuclideanSpace ℝ (Fin D)
      let mp1 := (MeasureTheory.measurePreserving_piCongrLeft
        (fun _ : Fin (R + 1) × Fin K => μ₀) (sumCapEquiv R K)).symm
      let mp2 := MeasureTheory.measurePreserving_sumPiEquivProdPi
        (X := fun _ : Fin K ⊕ (Fin R × Fin K) => E_ty) (fun _ => μ₀)
      let mp := mp2.comp mp1
      let S_R : Set (Fin R × Fin K → E_ty) := {F' | ∀ r : Fin R, (fun u => F' (r, u)) ∈ B}
      have hSR_meas : MeasurableSet S_R := by
        have h_eq : S_R = ⋂ r : Fin R, (fun F' : Fin R × Fin K → E_ty => fun u => F' (r, u)) ⁻¹' B := by
          ext F'; simp [S_R]
        rw [h_eq]
        refine MeasurableSet.iInter fun r => hB.preimage ?_
        rw [measurable_pi_iff]
        intro u
        exact measurable_pi_apply (r, u)
      let Φ_fn : (Fin (R + 1) × Fin K → E_ty) → (Fin K → E_ty) × (Fin R × Fin K → E_ty) :=
        (MeasurableEquiv.sumPiEquivProdPi (fun _ : Fin K ⊕ (Fin R × Fin K) => E_ty)) ∘
          (MeasurableEquiv.piCongrLeft (fun _ : Fin (R + 1) × Fin K => E_ty) (sumCapEquiv R K)).symm
      have hmp_fn : MeasurePreserving Φ_fn
          (Measure.pi (fun _ : Fin (R + 1) × Fin K => μ₀))
          (μ_K.prod (Measure.pi (fun _ : Fin R × Fin K => μ₀))) := mp
      have hpre : {F : Fin (R + 1) × Fin K → E_ty |
          ∀ r : Fin (R + 1), (fun u => F (r, u)) ∈ B} = Φ_fn ⁻¹' (B ×ˢ S_R) := by
        ext F
        exact Fin.forall_fin_succ
      rw [hpre, MeasureTheory.measureReal_def, ← Measure.map_apply hmp_fn.measurable (hB.prod hSR_meas),
        hmp_fn.map_eq, ← MeasureTheory.measureReal_def, MeasureTheory.measureReal_prod_prod,
        ih, pow_succ']

theorem all_copies_bad_prob_eq {R ℓ M₀ D : ℕ}
    (B : Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin D))) (hB : MeasurableSet B) :
    (Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure D)).real
        {F | ∀ r : Fin R, extractCopy r F ∈ B} =
      ((Measure.pi (fun _ : Fin (ℓ * M₀) => UL.stdGaussianMeasure D)).real B) ^ R := by
  let E_ty := EuclideanSpace ℝ (Fin D)
  let μ₀ := UL.stdGaussianMeasure D
  let e_idx : Fin R × Fin (ℓ * M₀) ≃ UL.ExplicitCapIdx R ℓ M₀ :=
    Equiv.prodCongr (Equiv.refl (Fin R)) finProdFinEquiv.symm
  let mp := (MeasureTheory.measurePreserving_piCongrLeft
    (fun _ : UL.ExplicitCapIdx R ℓ M₀ => μ₀) e_idx).symm
  let Ψ_fn : (UL.ExplicitCapIdx R ℓ M₀ → E_ty) → (Fin R × Fin (ℓ * M₀) → E_ty) :=
    (MeasurableEquiv.piCongrLeft (fun _ : UL.ExplicitCapIdx R ℓ M₀ => E_ty) e_idx).symm
  let S_prod : Set (Fin R × Fin (ℓ * M₀) → E_ty) :=
    {G | ∀ r : Fin R, (fun u => G (r, u)) ∈ B}
  have hS_meas : MeasurableSet S_prod := by
    have h_eq : S_prod = ⋂ r : Fin R,
        (fun G : Fin R × Fin (ℓ * M₀) → E_ty => fun u => G (r, u)) ⁻¹' B := by
      ext G; simp [S_prod]
    rw [h_eq]
    refine MeasurableSet.iInter fun r => hB.preimage ?_
    rw [measurable_pi_iff]
    intro u
    exact measurable_pi_apply (r, u)
  have hpre : {F : UL.ExplicitCapIdx R ℓ M₀ → E_ty | ∀ r : Fin R, extractCopy r F ∈ B} =
      Ψ_fn ⁻¹' S_prod := rfl
  rw [hpre, MeasureTheory.measureReal_def, ← Measure.map_apply mp.measurable hS_meas,
    mp.map_eq, ← MeasureTheory.measureReal_def]
  exact prod_copies_prob_eq R (ℓ * M₀) D B hB

theorem idealGoodEvent_exists {ι : Type*} [DecidableEq ι]
    {D R ℓ M₀ cap_u cap_q : ℕ}
    (hℓ : 1 ≤ ℓ) (hM₀ : 1 ≤ M₀)
    (hCap_u_pos : 1 ≤ cap_u) (hCap_q_pos : 1 ≤ cap_q)
    (gen : UL.SearchGeneration ι D)
    {x t_ideal p_u p_q p₁ p₂ : ℝ}
    (hprobs : UL.IsGaussianFilterProbs D gen.h x t_ideal p_u p_q p₁ p₂)
    (hp₁_pos : 0 < p₁)
    (hp₁_M : Real.log (100 * (ℓ : ℝ)) ≤ p₁ * (M₀ : ℝ))
    (hCap_u : 100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1) ≤ (cap_u : ℝ))
    (hCap_q : 100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1) ≤ (cap_q : ℝ))
    (hCap_bad : 100 * ((gen.m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1) ≤ (cap_q : ℝ))
    (Q_net : List (EuclideanSpace ℝ (Fin D)))
    (hQ_unit : ∀ z ∈ Q_net, UL.IsUnitVec z) :
    let μ_cpl := Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure D)
    ∃ E_ideal : Set (UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)),
      MeasurableSet E_ideal ∧
      1 - (gen.m : ℝ) * (Q_net.length : ℝ) * (1 / 10 : ℝ) ^ R ≤ μ_cpl.real E_ideal ∧
      (∀ (F_id F_disc : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) (τ_d τ_q : ℝ),
        F_id ∈ E_ideal →
        (∀ idx : UL.ExplicitCapIdx R ℓ M₀,
          (∀ i ∈ gen.P₀,
            UL.gaussianDataTest τ_d (F_disc idx) (gen.pts i) ↔
              UL.gaussianDataTest t_ideal (F_id idx) (gen.pts i)) ∧
          (∀ z ∈ Q_net,
            UL.gaussianDataTest τ_q (F_disc idx) z ↔
              UL.gaussianQueryTest x t_ideal (F_id idx) z)) →
        ∀ (P : Finset ι) (q : UL.SearchQuery ι D),
          gen.IsSurvivingSubset P →
          q.z ∈ Q_net →
          gen.IsCompatible P q →
          gen.IsCorrectAnswer P q
            (UL.explicitCappedQuery F_disc τ_d τ_q cap_u cap_q gen P q)) := by
  classical
  intro μ_cpl
  let enum : Fin gen.m ≃ ↥gen.P₀ := (Finset.equivFin gen.P₀).symm
  let ptsK : Fin gen.m → EuclideanSpace ℝ (Fin D) := fun k => gen.pts (enum k).1
  have hunit_ptsK : ∀ k : Fin gen.m, UL.IsUnitVec (ptsK k) :=
    fun k => gen.unit_pts (enum k).1 (enum k).2
  let G_single : (ι × EuclideanSpace ℝ (Fin D)) →
      Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin D)) := fun iz =>
    {ω | (∃ τ : Fin ℓ → Fin M₀, UL.Proof_lem_6_3.IsSharedTuple x t_ideal ω (gen.pts iz.1) iz.2 τ) ∧
         UL.Proof_lem_6_3.dataTupleCard t_ideal ω (gen.pts iz.1) ≤ cap_u ∧
         UL.Proof_lem_6_3.queryTupleCard x t_ideal ω iz.2 ≤ cap_q ∧
         UL.Proof_lem_6_3.badSharedCard x t_ideal ptsK iz.2 ω ≤ cap_q}
  let Targets : Finset (ι × EuclideanSpace ℝ (Fin D)) :=
    (gen.P₀ ×ˢ Q_net.toFinset).filter (fun iz => gen.h ≤ inner ℝ (gen.pts iz.1) iz.2)
  let B_iz : (ι × EuclideanSpace ℝ (Fin D)) →
      Set (UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) := fun iz =>
    {F | ∀ r : Fin R, extractCopy r F ∈ (G_single iz)ᶜ}
  have hB_each : ∀ iz ∈ Targets,
      MeasurableSet (B_iz iz) ∧ μ_cpl.real (B_iz iz) ≤ (1 / 10 : ℝ) ^ R := by
    intro iz hiz
    rcases Finset.mem_filter.mp hiz with ⟨hprod, htar⟩
    rcases Finset.mem_product.mp hprod with ⟨hi_P0, hz_Q⟩
    have hz_mem : iz.2 ∈ Q_net := List.mem_toFinset.mp hz_Q
    rcases UL.Proof_lem_6_3.goodEvent_prob_ge hℓ hM₀ hprobs hp₁_pos hp₁_M
      hCap_u_pos hCap_q_pos hCap_u hCap_q hCap_bad ptsK hunit_ptsK
      (gen.unit_pts iz.1 hi_P0) (hQ_unit iz.2 hz_mem) htar with ⟨hG_meas, hG_prob⟩
    have hGc_meas : MeasurableSet (G_single iz)ᶜ := hG_meas.compl
    let μ_single := Measure.pi (fun _ : Fin (ℓ * M₀) => UL.stdGaussianMeasure D)
    have hGc_prob : μ_single.real (G_single iz)ᶜ ≤ 1 / 10 := by
      rw [UL.Proof_lem_6_3.probReal_compl_eq μ_single hG_meas]
      linarith
    have hB_meas : MeasurableSet (B_iz iz) := by
      have h_eq : B_iz iz = ⋂ r : Fin R,
          (fun F : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D) => extractCopy r F) ⁻¹'
            (G_single iz)ᶜ := by
        ext F; simp [B_iz]
      rw [h_eq]
      refine MeasurableSet.iInter fun r => hGc_meas.preimage ?_
      rw [measurable_pi_iff]
      intro u
      exact measurable_pi_apply _
    have hB_prob : μ_cpl.real (B_iz iz) ≤ (1 / 10 : ℝ) ^ R := by
      rw [all_copies_bad_prob_eq (G_single iz)ᶜ hGc_meas]
      exact pow_le_pow_left₀ MeasureTheory.measureReal_nonneg hGc_prob R
    exact ⟨hB_meas, hB_prob⟩
  let B_all := ⋃ iz ∈ Targets, B_iz iz
  have hB_all_meas : MeasurableSet B_all :=
    Finset.measurableSet_biUnion _ fun iz hiz => (hB_each iz hiz).1
  have hTargets_card : Targets.card ≤ gen.m * Q_net.length := by
    calc Targets.card ≤ (gen.P₀ ×ˢ Q_net.toFinset).card := Finset.card_filter_le _ _
      _ = gen.P₀.card * Q_net.toFinset.card := Finset.card_product _ _
      _ ≤ gen.m * Q_net.length := Nat.mul_le_mul_left gen.m (List.toFinset_card_le Q_net)
  have hB_all_prob : μ_cpl.real B_all ≤ (gen.m : ℝ) * (Q_net.length : ℝ) * (1 / 10 : ℝ) ^ R := by
    calc μ_cpl.real B_all
        ≤ ∑ iz ∈ Targets, μ_cpl.real (B_iz iz) :=
          UL.Proof_lem_6_3.measureReal_biUnion_finset_le_sum μ_cpl _ _
      _ ≤ ∑ _iz ∈ Targets, (1 / 10 : ℝ) ^ R :=
          Finset.sum_le_sum fun iz hiz => (hB_each iz hiz).2
      _ = (Targets.card : ℝ) * (1 / 10 : ℝ) ^ R := by simp
      _ ≤ ((gen.m * Q_net.length : ℕ) : ℝ) * (1 / 10 : ℝ) ^ R :=
          mul_le_mul_of_nonneg_right (by exact_mod_cast hTargets_card) (by positivity)
      _ = (gen.m : ℝ) * (Q_net.length : ℝ) * (1 / 10 : ℝ) ^ R := by push_cast; ring
  refine ⟨B_allᶜ, hB_all_meas.compl, ?_, ?_⟩
  · rw [UL.Proof_lem_6_3.probReal_compl_eq μ_cpl hB_all_meas]
    linarith
  · intro F_id F_disc τ_d τ_q hFid h_agree P q hP hqz hcompat
    refine ⟨explicitCappedQuery_valid F_disc τ_d τ_q cap_u cap_q gen P q, ?_⟩
    intro hans_none ⟨i_star, hi_star_P, htar⟩
    have hi_star_P0 : i_star ∈ gen.P₀ := hP hi_star_P
    have hmem_tar : (i_star, q.z) ∈ Targets := by
      simp only [Targets, Finset.mem_filter, Finset.mem_product, List.mem_toFinset]
      exact ⟨⟨hi_star_P0, hqz⟩, htar⟩
    have hnot_bad : F_id ∉ B_iz (i_star, q.z) :=
      fun hbad => hFid (Set.mem_biUnion hmem_tar hbad)
    have hex_r : ∃ r : Fin R, extractCopy r F_id ∈ G_single (i_star, q.z) := by
      by_contra hall
      push_neg at hall
      exact hnot_bad hall
    rcases hex_r with ⟨r, hr_good⟩
    have hne := explicitCappedQuery_ne_none_of_copy_good gen enum P hP q hcompat
      hi_star_P htar F_disc F_id r
      (fun s k i hi => (h_agree (r, s, k)).1 i hi)
      (fun s k => (h_agree (r, s, k)).2 q.z hqz)
      hr_good
    exact hne hans_none

end UL.Proof_clm_6_1_precision_RaceV30
