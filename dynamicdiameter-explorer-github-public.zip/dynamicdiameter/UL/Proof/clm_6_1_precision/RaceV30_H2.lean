import Mathlib
import UL.Stmt.clm_6_1_precision
import UL.Proof.lem_6_2.H1
import UL.Proof.lem_6_2.H2
import UL.Proof.lem_6_3.H2_Params
import UL.Proof.lem_6_3.H5_Prob
import UL.Proof.clm_6_1_precision.RaceV30_H1
set_option autoImplicit false

open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Real

namespace UL.Proof_clm_6_1_precision_RaceV30

/-! ### 1. Standard 1D normal CDF, continuity, tails, and local density lower bound -/

noncomputable def stdNormalCDF (x : ℝ) : ℝ :=
  (gaussianReal 0 1).real (Set.Iic x)

theorem stdNormal_map_neg :
    (gaussianReal 0 1).map (fun x : ℝ => -x) = gaussianReal 0 1 := by
  let μ₁ : Measure ℝ := gaussianReal 0 1
  have hmeas : Measurable (fun x : ℝ => -x) := measurable_neg
  haveI : IsProbabilityMeasure (μ₁.map (fun x : ℝ => -x)) :=
    Measure.isProbabilityMeasure_map hmeas.aemeasurable
  apply Measure.ext_of_charFun
  ext u
  rw [charFun_apply_real, integral_map hmeas.aemeasurable (by fun_prop)]
  have h_eq : (∫ x, Complex.exp ((u : ℂ) * ((-x : ℝ) : ℂ) * Complex.I) ∂μ₁) =
      charFun μ₁ (-u) := by
    rw [charFun_apply_real]
    refine integral_congr_ae (ae_of_all _ fun x => ?_)
    push_cast
    ring_nf
  rw [h_eq, UL.Proof_lem_6_2.charFun_stdNormal, UL.Proof_lem_6_2.charFun_stdNormal]
  congr 1
  push_cast
  ring

theorem stdNormalCDF_mono {a b : ℝ} (hab : a ≤ b) :
    stdNormalCDF a ≤ stdNormalCDF b :=
  MeasureTheory.measureReal_mono (Set.Iic_subset_Iic.mpr hab)

theorem stdNormalCDF_sub_eq_Ioc {a b : ℝ} (hab : a ≤ b) :
    stdNormalCDF b - stdNormalCDF a = (gaussianReal 0 1).real (Set.Ioc a b) := by
  unfold stdNormalCDF
  have hunion : Set.Iic a ∪ Set.Ioc a b = Set.Iic b := Set.Iic_union_Ioc_eq_Iic hab
  have hdisj : Disjoint (Set.Iic a) (Set.Ioc a b) :=
    Set.disjoint_left.mpr fun x hx1 hx2 => by simp at hx1 hx2; linarith
  have hadd : (gaussianReal 0 1).real (Set.Iic b) =
      (gaussianReal 0 1).real (Set.Iic a) + (gaussianReal 0 1).real (Set.Ioc a b) := by
    rw [← hunion]
    simp only [MeasureTheory.measureReal_def]
    rw [measure_union hdisj measurableSet_Ioc,
      ENNReal.toReal_add (measure_ne_top _ _) (measure_ne_top _ _)]
  linarith

theorem stdNormal_Ioc_le_sub {a b : ℝ} (hab : a ≤ b) :
    (gaussianReal 0 1).real (Set.Ioc a b) ≤ b - a := by
  let S : Set ℝ := Set.Ioc a b
  have h_eq_int : (gaussianReal 0 1).real S = ∫ x in S, gaussianPDFReal 0 1 x := by
    rw [MeasureTheory.measureReal_def, gaussianReal_apply_eq_integral 0 one_ne_zero S,
      ENNReal.toReal_ofReal (integral_nonneg fun x => gaussianPDFReal_nonneg 0 1 x)]
  have hc_ge : ∀ x ∈ S, gaussianPDFReal 0 1 x ≤ (1 : ℝ) := by
    intro x _
    have hnn : 0 ≤ x ^ 2 / 2 := by positivity
    have hexp : Real.exp (-(x ^ 2 / 2)) ≤ 1 :=
      Real.exp_le_one_iff.mpr (by linarith)
    have hsqrt : (2 : ℝ) ≤ Real.sqrt (2 * Real.pi) := two_le_sqrt_two_pi
    have hinv : (Real.sqrt (2 * Real.pi))⁻¹ ≤ 1 := inv_le_one_of_one_le₀ (by linarith)
    have hpdf : gaussianPDFReal 0 1 x = (Real.sqrt (2 * Real.pi))⁻¹ * Real.exp (-(x ^ 2 / 2)) := by
      unfold gaussianPDFReal; simp [neg_div]
    rw [hpdf]
    nlinarith [Real.exp_pos (-(x ^ 2 / 2))]
  have hint : ∫ x in S, gaussianPDFReal 0 1 x ≤ volume.real S • (1 : ℝ) := by
    rw [← MeasureTheory.setIntegral_const (1 : ℝ)]
    exact MeasureTheory.setIntegral_mono_on
      (integrable_gaussianPDFReal 0 1).integrableOn
      (MeasureTheory.integrableOn_const measure_Ioc_lt_top.ne)
      measurableSet_Ioc hc_ge
  rw [h_eq_int]
  refine hint.trans_eq ?_
  simp [S, Real.volume_real_Ioc_of_le hab]

theorem continuous_stdNormalCDF : Continuous stdNormalCDF := by
  rw [Metric.continuous_iff]
  intro x ε hε
  refine ⟨ε, hε, fun y hy => ?_⟩
  rw [Real.dist_eq] at hy ⊢
  rcases le_total x y with hxy | hyx
  · have h0 : 0 ≤ stdNormalCDF y - stdNormalCDF x := sub_nonneg.mpr (stdNormalCDF_mono hxy)
    have h1 : stdNormalCDF y - stdNormalCDF x ≤ y - x := by
      rw [stdNormalCDF_sub_eq_Ioc hxy]; exact stdNormal_Ioc_le_sub hxy
    rw [abs_of_nonneg h0]
    rw [abs_of_nonneg (by linarith)] at hy
    linarith
  · have h0 : 0 ≤ stdNormalCDF x - stdNormalCDF y := sub_nonneg.mpr (stdNormalCDF_mono hyx)
    have h1 : stdNormalCDF x - stdNormalCDF y ≤ x - y := by
      rw [stdNormalCDF_sub_eq_Ioc hyx]; exact stdNormal_Ioc_le_sub hyx
    rw [abs_sub_comm, abs_of_nonneg h0]
    rw [abs_sub_comm, abs_of_nonneg (by linarith)] at hy
    linarith

theorem stdNormalCDF_neg_le {s : ℝ} (hs : 0 ≤ s) :
    stdNormalCDF (-s) ≤ Real.exp (-(s ^ 2 / 2)) := by
  unfold stdNormalCDF
  have hpre : Set.Iic (-s) = (fun x : ℝ => -x) ⁻¹' Set.Ici s := by
    ext x; simp [le_neg]
  rw [hpre, MeasureTheory.measureReal_def, ← Measure.map_apply measurable_neg measurableSet_Ici,
    stdNormal_map_neg, ← MeasureTheory.measureReal_def]
  exact UL.Proof_lem_6_2.stdGaussian_tail_le hs

theorem one_sub_stdNormalCDF_le {s : ℝ} (hs : 0 ≤ s) :
    1 - stdNormalCDF s ≤ Real.exp (-(s ^ 2 / 2)) := by
  have hcompl : (gaussianReal 0 1).real (Set.Iic s)ᶜ = 1 - stdNormalCDF s :=
    UL.Proof_lem_6_3.probReal_compl_eq (gaussianReal 0 1) measurableSet_Iic
  rw [← hcompl, Set.compl_Iic]
  exact (MeasureTheory.measureReal_mono Set.Ioi_subset_Ici_self).trans
    (UL.Proof_lem_6_2.stdGaussian_tail_le hs)

theorem stdNormal_abs_gt_le (T : ℕ) :
    (gaussianReal 0 1).real {z : ℝ | (T : ℝ) < |z|} ≤
      2 * Real.exp (-((T : ℝ) ^ 2 / 2)) := by
  have hsub : {z : ℝ | (T : ℝ) < |z|} ⊆ Set.Ici (T : ℝ) ∪ Set.Iic (-(T : ℝ)) := by
    intro z hz
    simp only [Set.mem_setOf_eq, lt_abs] at hz
    rcases hz with h | h
    · exact Or.inl (Set.mem_Ici.mpr h.le)
    · exact Or.inr (Set.mem_Iic.mpr (by linarith))
  have h1 : (gaussianReal 0 1).real {z : ℝ | (T : ℝ) < |z|} ≤
      (gaussianReal 0 1).real (Set.Ici (T : ℝ)) + (gaussianReal 0 1).real (Set.Iic (-(T : ℝ))) :=
    (MeasureTheory.measureReal_mono hsub).trans
      (UL.Proof_lem_6_3.measureReal_union_le_add (gaussianReal 0 1) _ _)
  have hT0 : (0 : ℝ) ≤ (T : ℝ) := Nat.cast_nonneg (α := ℝ) T
  have h_hi := UL.Proof_lem_6_2.stdGaussian_tail_le hT0
  have h_lo : (gaussianReal 0 1).real (Set.Iic (-(T : ℝ))) ≤ Real.exp (-((T : ℝ) ^ 2 / 2)) :=
    stdNormalCDF_neg_le hT0
  linarith

theorem stdNormalCDF_sub_ge_on_box (T : ℕ) {a b : ℝ}
    (ha : -((T + 1 : ℕ) : ℝ) ≤ a) (hab : a ≤ b) (hb : b ≤ ((T + 1 : ℕ) : ℝ)) :
    (2 : ℝ) ^ (-(((T + 1) ^ 2 + 2 : ℕ) : ℤ)) * (b - a) ≤ stdNormalCDF b - stdNormalCDF a := by
  rw [stdNormalCDF_sub_eq_Ioc hab]
  let S : Set ℝ := Set.Ioc a b
  have h_eq_int : (gaussianReal 0 1).real S = ∫ u in S, gaussianPDFReal 0 1 u := by
    rw [MeasureTheory.measureReal_def, gaussianReal_apply_eq_integral 0 one_ne_zero S,
      ENNReal.toReal_ofReal (integral_nonneg fun u => gaussianPDFReal_nonneg 0 1 u)]
  let M : ℕ := (T + 1) ^ 2
  let c : ℝ := (2 : ℝ) ^ (-((M + 2 : ℕ) : ℤ))
  have hexp_M : (2 : ℝ) ^ (-(M : ℤ)) ≤ Real.exp (-((M : ℝ) / 2)) := by
    have hpow : Real.exp ((M : ℝ) / 2) ≤ (2 : ℝ) ^ M := by
      have heq : Real.exp ((M : ℝ) / 2) = (Real.exp (1 / 2 : ℝ)) ^ M := by
        rw [← Real.exp_nat_mul]; congr 1; ring
      rw [heq]
      exact pow_le_pow_left₀ (Real.exp_pos _).le UL.Proof_lem_6_3.exp_half_le_two M
    rw [zpow_neg, zpow_natCast, Real.exp_neg]
    exact inv_anti₀ (Real.exp_pos _) hpow
  have hsqrt_inv : (2 : ℝ) ^ (-2 : ℤ) ≤ (Real.sqrt (2 * Real.pi))⁻¹ := by
    have hpos : 0 < Real.sqrt (2 * Real.pi) := by linarith [two_le_sqrt_two_pi]
    have hle4 : Real.sqrt (2 * Real.pi) ≤ 4 := sqrt_two_pi_le_four
    have h4 : (2 : ℝ) ^ (-2 : ℤ) = (4 : ℝ)⁻¹ := by norm_num
    rw [h4]
    exact inv_anti₀ hpos hle4
  have hc_le : ∀ u ∈ S, c ≤ gaussianPDFReal 0 1 u := by
    intro u hu
    have hu1 : -((T + 1 : ℕ) : ℝ) ≤ u := le_trans ha hu.1.le
    have hu2 : u ≤ ((T + 1 : ℕ) : ℝ) := le_trans hu.2 hb
    have husq : u ^ 2 ≤ (M : ℝ) := by
      have hM_eq : (M : ℝ) = ((T + 1 : ℕ) : ℝ) ^ 2 := by dsimp [M]; push_cast; ring
      rw [hM_eq]
      nlinarith
    have hexp_u : (2 : ℝ) ^ (-(M : ℤ)) ≤ Real.exp (-(u ^ 2 / 2)) :=
      hexp_M.trans (Real.exp_le_exp.mpr (by linarith))
    have hpdf : gaussianPDFReal 0 1 u = (Real.sqrt (2 * Real.pi))⁻¹ * Real.exp (-(u ^ 2 / 2)) := by
      unfold gaussianPDFReal; simp [neg_div]
    have hc_eq : c = (2 : ℝ) ^ (-2 : ℤ) * (2 : ℝ) ^ (-(M : ℤ)) := by
      dsimp [c]
      rw [← zpow_add₀ (by norm_num)]
      congr 1
      omega
    rw [hpdf, hc_eq]
    exact mul_le_mul hsqrt_inv hexp_u (by positivity) (by positivity)
  have hint : c * volume.real S ≤ ∫ u in S, gaussianPDFReal 0 1 u :=
    MeasureTheory.setIntegral_ge_of_const_le_real measurableSet_Ioc measure_Ioc_lt_top.ne
      hc_le (integrable_gaussianPDFReal 0 1).integrableOn
  rw [h_eq_int]
  dsimp only [S] at hint
  rwa [Real.volume_real_Ioc_of_le hab] at hint

/-! ### 2. 1D Quantile equipartition and dyadic sample coordinates -/

theorem exists_stdNormalCDF_eq {p : ℝ} (hp0 : 0 < p) (hp1 : p < 1) :
    ∃ q : ℝ, stdNormalCDF q = p := by
  let δ : ℝ := min p (1 - p)
  have hδ_pos : 0 < δ := lt_min hp0 (by linarith)
  let S : ℝ := 2 / δ + 2
  have h2δ : 0 < 2 / δ := by positivity
  have hS_ge2 : 2 ≤ S := by dsimp [S]; linarith
  have hexp_lt : Real.exp (-(S ^ 2 / 2)) < δ := by
    have h1 : 1 / δ < S := by
      have : 0 < 1 / δ := by positivity
      have heq : S = 2 * (1 / δ) + 2 := by dsimp [S]; ring
      linarith
    have h2 : S ≤ S ^ 2 / 2 := by nlinarith
    have h3 : S ^ 2 / 2 + 1 ≤ Real.exp (S ^ 2 / 2) := by
      linarith [Real.add_one_le_exp (S ^ 2 / 2)]
    have h4 : 1 / δ < Real.exp (S ^ 2 / 2) := by linarith
    rw [Real.exp_neg]
    have := inv_strictAnti₀ (by positivity : 0 < 1 / δ) h4
    simpa using this
  have hlo : stdNormalCDF (-S) ≤ p := by
    have := (stdNormalCDF_neg_le (by linarith : 0 ≤ S)).trans_lt (hexp_lt.trans_le (min_le_left _ _))
    linarith
  have hhi : p ≤ stdNormalCDF S := by
    have := (one_sub_stdNormalCDF_le (by linarith : 0 ≤ S)).trans_lt (hexp_lt.trans_le (min_le_right _ _))
    linarith
  have hmem : p ∈ Set.Icc (stdNormalCDF (-S)) (stdNormalCDF S) := ⟨hlo, hhi⟩
  rcases intermediate_value_Icc (by linarith : -S ≤ S) continuous_stdNormalCDF.continuousOn hmem with
    ⟨q, _, hq⟩
  exact ⟨q, hq⟩

noncomputable def bitsEquiv (b : ℕ) : (Fin b → Bool) ≃ Fin (2 ^ b) :=
  (Fintype.equivFin (Fin b → Bool)).trans (finCongr (by simp))

private lemma quantile_prob_in_Ioo {b j : ℕ} (hj1 : 1 ≤ j) (hj2 : j < 2 ^ b) :
    0 < (j : ℝ) / ((2 ^ b : ℕ) : ℝ) ∧ (j : ℝ) / ((2 ^ b : ℕ) : ℝ) < 1 := by
  have hN_pos : (0 : ℝ) < ((2 ^ b : ℕ) : ℝ) := by positivity
  refine ⟨div_pos (by exact_mod_cast hj1) hN_pos, (div_lt_one hN_pos).mpr (by exact_mod_cast hj2)⟩

noncomputable def qVal (b : ℕ) (j : ℕ) : ℝ :=
  if h : 1 ≤ j ∧ j < 2 ^ b then
    Classical.choose (exists_stdNormalCDF_eq (quantile_prob_in_Ioo h.1 h.2).1
      (quantile_prob_in_Ioo h.1 h.2).2)
  else
    0

theorem stdNormalCDF_qVal {b j : ℕ} (hj1 : 1 ≤ j) (hj2 : j < 2 ^ b) :
    stdNormalCDF (qVal b j) = (j : ℝ) / ((2 ^ b : ℕ) : ℝ) := by
  unfold qVal
  rw [dif_pos ⟨hj1, hj2⟩]
  exact Classical.choose_spec (exists_stdNormalCDF_eq (quantile_prob_in_Ioo hj1 hj2).1
    (quantile_prob_in_Ioo hj1 hj2).2)

theorem qVal_strictMono {b i j : ℕ} (hi1 : 1 ≤ i) (hij : i < j) (hj2 : j < 2 ^ b) :
    qVal b i < qVal b j := by
  by_contra hle
  push_neg at hle
  have hmono := stdNormalCDF_mono hle
  rw [stdNormalCDF_qVal (by omega) hj2, stdNormalCDF_qVal hi1 (by omega)] at hmono
  have hN_pos : (0 : ℝ) < ((2 ^ b : ℕ) : ℝ) := by positivity
  have hij_r : (i : ℝ) < (j : ℝ) := by exact_mod_cast hij
  have hlt : (i : ℝ) / ((2 ^ b : ℕ) : ℝ) < (j : ℝ) / ((2 ^ b : ℕ) : ℝ) :=
    div_lt_div_of_pos_right hij_r hN_pos
  linarith

theorem qVal_mono {b i j : ℕ} (hi1 : 1 ≤ i) (hij : i ≤ j) (hj2 : j < 2 ^ b) :
    qVal b i ≤ qVal b j := by
  rcases eq_or_lt_of_le hij with rfl | hlt
  · exact le_rfl
  · exact (qVal_strictMono hi1 hlt hj2).le

noncomputable def binSet (b : ℕ) (k : Fin (2 ^ b)) : Set ℝ :=
  if k.1 = 0 then Set.Iic (qVal b 1)
  else if k.1 + 1 < 2 ^ b then Set.Ioc (qVal b k.1) (qVal b (k.1 + 1))
  else Set.Ioi (qVal b (2 ^ b - 1))

theorem measurableSet_binSet (b : ℕ) (k : Fin (2 ^ b)) : MeasurableSet (binSet b k) := by
  unfold binSet
  split_ifs
  · exact measurableSet_Iic
  · exact measurableSet_Ioc
  · exact measurableSet_Ioi

theorem binSet_upper {b : ℕ} {k : Fin (2 ^ b)} (hk : k.1 + 1 < 2 ^ b) {u : ℝ}
    (hu : u ∈ binSet b k) : u ≤ qVal b (k.1 + 1) := by
  unfold binSet at hu
  by_cases hk0 : k.1 = 0
  · rw [if_pos hk0] at hu
    simpa [hk0] using hu
  · rw [if_neg hk0, if_pos hk] at hu
    exact hu.2

theorem binSet_lower {b : ℕ} (hb : 1 ≤ b) {k : Fin (2 ^ b)} (hk0 : 0 < k.1) {v : ℝ}
    (hv : v ∈ binSet b k) : qVal b k.1 < v := by
  have hk_ne : k.1 ≠ 0 := by omega
  unfold binSet at hv
  rw [if_neg hk_ne] at hv
  by_cases hlt : k.1 + 1 < 2 ^ b
  · rw [if_pos hlt] at hv
    exact hv.1
  · rw [if_neg hlt] at hv
    have hk_eq : k.1 = 2 ^ b - 1 := by have := k.2; omega
    rw [hk_eq]
    exact hv

theorem binSet_pairwiseDisjoint (b : ℕ) (hb : 1 ≤ b) {j k : Fin (2 ^ b)} (hjk : j ≠ k) :
    Disjoint (binSet b j) (binSet b k) := by
  have hval_ne : j.1 ≠ k.1 := fun h => hjk (Fin.ext h)
  suffices haux : ∀ a c : Fin (2 ^ b), a.1 < c.1 → Disjoint (binSet b a) (binSet b c) by
    rcases lt_or_gt_of_ne hval_ne with hlt | hgt
    · exact haux j k hlt
    · exact (haux k j hgt).symm
  intro a c hac
  refine Set.disjoint_left.mpr fun x hxa hxc => ?_
  have ha_ub : x ≤ qVal b (a.1 + 1) := binSet_upper (by have := c.2; omega) hxa
  have hc_lb : qVal b c.1 < x := binSet_lower hb (by omega) hxc
  have hq_le : qVal b (a.1 + 1) ≤ qVal b c.1 := qVal_mono (by omega) (by omega) c.2
  linarith

theorem exists_mem_binSet (b : ℕ) (hb : 1 ≤ b) (x : ℝ) :
    ∃ k : Fin (2 ^ b), x ∈ binSet b k := by
  have hN : 2 ≤ 2 ^ b := by
    calc 2 = 2 ^ 1 := rfl
      _ ≤ 2 ^ b := Nat.pow_le_pow_right (by decide) hb
  have hcover_le : ∀ m : ℕ, 1 ≤ m → m < 2 ^ b → x ≤ qVal b m →
      ∃ k : Fin (2 ^ b), x ∈ binSet b k := by
    intro m hm1
    induction m with
    | zero => omega
    | succ n ih =>
        intro hn_lt hx
        by_cases hn0 : n = 0
        · subst hn0
          refine ⟨⟨0, by omega⟩, ?_⟩
          simp [binSet, hx]
        · by_cases hxn : x ≤ qVal b n
          · exact ih (by omega) (by omega) hxn
          · push_neg at hxn
            refine ⟨⟨n, by omega⟩, ?_⟩
            unfold binSet
            rw [if_neg hn0, if_pos hn_lt]
            exact ⟨hxn, hx⟩
  by_cases hx_last : x ≤ qVal b (2 ^ b - 1)
  · exact hcover_le (2 ^ b - 1) (by omega) (by omega) hx_last
  · push_neg at hx_last
    refine ⟨⟨2 ^ b - 1, by omega⟩, ?_⟩
    unfold binSet
    dsimp only
    rw [if_neg (by omega), if_neg (by omega)]
    exact hx_last

noncomputable def binIdx (b : ℕ) (hb : 1 ≤ b) (x : ℝ) : Fin (2 ^ b) :=
  Classical.choose (exists_mem_binSet b hb x)

theorem binIdx_eq_iff (b : ℕ) (hb : 1 ≤ b) (x : ℝ) (k : Fin (2 ^ b)) :
    binIdx b hb x = k ↔ x ∈ binSet b k := by
  have hspec : x ∈ binSet b (binIdx b hb x) := Classical.choose_spec (exists_mem_binSet b hb x)
  constructor
  · rintro rfl; exact hspec
  · intro hxk
    by_contra hne
    exact Set.disjoint_left.mp (binSet_pairwiseDisjoint b hb hne) hspec hxk

noncomputable def encode1D (b : ℕ) (hb : 1 ≤ b) (x : ℝ) : Fin b → Bool :=
  (bitsEquiv b).symm (binIdx b hb x)

theorem preimage_encode1D_singleton (b : ℕ) (hb : 1 ≤ b) (bits : Fin b → Bool) :
    encode1D b hb ⁻¹' ({bits} : Set (Fin b → Bool)) = binSet b (bitsEquiv b bits) := by
  ext x
  simp only [Set.mem_preimage, Set.mem_singleton_iff, encode1D]
  rw [Equiv.symm_apply_eq, binIdx_eq_iff]

theorem measurable_encode1D (b : ℕ) (hb : 1 ≤ b) :
    Measurable (encode1D b hb) := by
  classical
  intro S _hS
  have hS_eq : S = ⋃ bits ∈ Finset.univ.filter (fun v : Fin b → Bool => v ∈ S),
      ({bits} : Set (Fin b → Bool)) := by
    ext v; simp
  rw [hS_eq, Set.preimage_iUnion₂]
  refine Finset.measurableSet_biUnion _ fun bits _ => ?_
  rw [preimage_encode1D_singleton]
  exact measurableSet_binSet b (bitsEquiv b bits)

theorem binSet_measure (b : ℕ) (hb : 1 ≤ b) (k : Fin (2 ^ b)) :
    gaussianReal 0 1 (binSet b k) = (((2 ^ b : ℕ) : ℝ≥0∞))⁻¹ := by
  have hN : 2 ≤ 2 ^ b := by
    calc 2 = 2 ^ 1 := rfl
      _ ≤ 2 ^ b := Nat.pow_le_pow_right (by decide) hb
  have hN_pos : (0 : ℝ) < ((2 ^ b : ℕ) : ℝ) := by positivity
  have hreal : (gaussianReal 0 1).real (binSet b k) = (((2 ^ b : ℕ) : ℝ))⁻¹ := by
    unfold binSet
    split_ifs with hk0 hklt
    · change stdNormalCDF (qVal b 1) = _
      rw [stdNormalCDF_qVal (by omega) (by omega)]
      simp [one_div]
    · have hk1 : 1 ≤ k.1 := by omega
      have hq_le : qVal b k.1 ≤ qVal b (k.1 + 1) := qVal_mono hk1 (by omega) hklt
      rw [← stdNormalCDF_sub_eq_Ioc hq_le,
        stdNormalCDF_qVal (by omega) hklt, stdNormalCDF_qVal hk1 (by omega)]
      push_cast
      field_simp
      ring
    · have hk_eq : k.1 = 2 ^ b - 1 := by have := k.2; omega
      rw [← Set.compl_Iic, UL.Proof_lem_6_3.probReal_compl_eq (gaussianReal 0 1) measurableSet_Iic]
      change 1 - stdNormalCDF (qVal b (2 ^ b - 1)) = _
      rw [stdNormalCDF_qVal (by omega) (by omega)]
      have hsub : ((2 ^ b - 1 : ℕ) : ℝ) = ((2 ^ b : ℕ) : ℝ) - 1 := by
        rw [Nat.cast_sub (by omega : 1 ≤ 2 ^ b), Nat.cast_one]
      rw [hsub]
      field_simp
      ring
  have hfin1 : gaussianReal 0 1 (binSet b k) ≠ ⊤ := measure_ne_top _ _
  have hfin2 : (((2 ^ b : ℕ) : ℝ≥0∞))⁻¹ ≠ ⊤ :=
    ENNReal.inv_ne_top.mpr (Nat.cast_ne_zero.mpr (by positivity))
  refine (ENNReal.toReal_eq_toReal_iff' hfin1 hfin2).mp ?_
  rw [← MeasureTheory.measureReal_def, hreal, ENNReal.toReal_inv, ENNReal.toReal_natCast]

/-! ### 3. Clamped dyadic sample coordinate and error on `[-T, T]` -/

noncomputable def sampleCoord1D (b : ℕ) (T : ℕ) (bits : Fin b → Bool) : ℚ :=
  let k := bitsEquiv b bits
  let bound : ℝ := ((T + 1 : ℕ) : ℝ)
  let raw : ℝ := if k.1 = 0 then 0 else max (-bound) (min bound (qVal b k.1))
  (⌊raw * ((2 ^ b : ℕ) : ℝ)⌋ : ℚ) / ((2 ^ b : ℕ) : ℚ)

theorem sampleCoord1D_bitBounded {b T B_prec : ℕ}
    (hB : b + T + 3 ≤ B_prec) (bits : Fin b → Bool) :
    UL.RatCoordBitBounded B_prec (sampleCoord1D b T bits) := by
  have hB1 : 1 ≤ B_prec := by omega
  let bound : ℝ := ((T + 1 : ℕ) : ℝ)
  let k := bitsEquiv b bits
  let raw : ℝ := if k.1 = 0 then 0 else max (-bound) (min bound (qVal b k.1))
  have hraw_lo : -bound ≤ raw := by
    dsimp [raw]
    split_ifs
    · dsimp [bound]; linarith [Nat.cast_nonneg (α := ℝ) (T + 1)]
    · exact le_max_left _ _
  have hraw_hi : raw ≤ bound := by
    dsimp [raw]
    split_ifs
    · dsimp [bound]; positivity
    · exact max_le (by dsimp [bound]; linarith [ (by positivity : (0 : ℝ) ≤ bound) ])
        (min_le_left _ _)
  let M : ℕ := (T + 1) * 2 ^ b
  have hy_lo : -((M : ℤ) : ℝ) ≤ raw * ((2 ^ b : ℕ) : ℝ) := by
    have : -((M : ℤ) : ℝ) = -bound * ((2 ^ b : ℕ) : ℝ) := by
      dsimp [M, bound]; push_cast; ring
    rw [this]
    exact mul_le_mul_of_nonneg_right hraw_lo (by positivity)
  have hy_hi : raw * ((2 ^ b : ℕ) : ℝ) ≤ ((M : ℤ) : ℝ) := by
    have : ((M : ℤ) : ℝ) = bound * ((2 ^ b : ℕ) : ℝ) := by
      dsimp [M, bound]; push_cast; ring
    rw [this]
    exact mul_le_mul_of_nonneg_right hraw_hi (by positivity)
  let z : ℤ := ⌊raw * ((2 ^ b : ℕ) : ℝ)⌋
  have hz_lo : -(M : ℤ) ≤ z := Int.le_floor.mpr (by simpa using hy_lo)
  have hz_hi : z ≤ (M : ℤ) := Int.cast_le.mp ((Int.floor_le _).trans hy_hi)
  have hz_abs : z.natAbs ≤ M := by omega
  have hTp1 : T + 1 < 2 ^ (T + 2) := by
    have := Nat.lt_two_pow_self (n := T + 1)
    have hpow : 2 ^ (T + 1) ≤ 2 ^ (T + 2) := Nat.pow_le_pow_right (by decide) (by omega)
    omega
  have hM_lt : M < 2 ^ B_prec := by
    calc M = (T + 1) * 2 ^ b := rfl
      _ < 2 ^ (T + 2) * 2 ^ b := Nat.mul_lt_mul_of_pos_right hTp1 (by positivity)
      _ = 2 ^ (b + T + 2) := by rw [← pow_add]; ring_nf
      _ ≤ 2 ^ B_prec := Nat.pow_le_pow_right (by decide) (by omega)
  have hD_lt : 2 ^ b < 2 ^ B_prec :=
    Nat.pow_lt_pow_right (by decide) (by omega)
  exact ratCoordBitBounded_of_div hB1 (Nat.one_le_pow b 2 (by decide)) hD_lt
    (lt_of_le_of_lt hz_abs hM_lt)

theorem sampleCoord1D_approx_on_box {T p_coord : ℕ}
    {z : ℝ} (hz : |z| ≤ (T : ℝ)) :
    let m_exp : ℕ := (T + 1) ^ 2 + 2
    let b : ℕ := m_exp + p_coord + 2
    have hb : 1 ≤ b := by omega
    |((sampleCoord1D b T (encode1D b hb z) : ℚ) : ℝ) - z| ≤
      (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) := by
  intro m_exp b hb
  rcases abs_le.mp hz with ⟨hz_lo, hz_hi⟩
  let k : Fin (2 ^ b) := binIdx b hb z
  have hzk : z ∈ binSet b k := (binIdx_eq_iff b hb z k).mp rfl
  have hbits_k : bitsEquiv b (encode1D b hb z) = k := by simp [encode1D, k]
  have h2b_eq : (((2 ^ b : ℕ) : ℝ))⁻¹ = (2 : ℝ) ^ (-(b : ℤ)) := by
    rw [zpow_neg, zpow_natCast]; push_cast; rfl
  have hlt_pow : (2 : ℝ) ^ (-(b : ℤ)) < (2 : ℝ) ^ (-(m_exp : ℤ)) :=
    zpow_lt_zpow_right₀ (by norm_num) (by dsimp [b]; omega)
  -- Left unit buffer `[-(T + 1), -T]`
  have hbuf_L : (2 : ℝ) ^ (-(m_exp : ℤ)) ≤
      stdNormalCDF (-(T : ℝ)) - stdNormalCDF (-((T + 1 : ℕ) : ℝ)) := by
    have h := stdNormalCDF_sub_ge_on_box T (a := -((T + 1 : ℕ) : ℝ)) (b := -(T : ℝ))
      le_rfl (by push_cast; linarith) (by push_cast; linarith [Nat.cast_nonneg (α := ℝ) T])
    have hlen : -(T : ℝ) - -((T + 1 : ℕ) : ℝ) = 1 := by push_cast; ring
    rw [hlen, mul_one] at h
    exact h
  -- Right unit buffer `[T, T + 1]`
  have hbuf_R : (2 : ℝ) ^ (-(m_exp : ℤ)) ≤
      stdNormalCDF ((T + 1 : ℕ) : ℝ) - stdNormalCDF (T : ℝ) := by
    have h := stdNormalCDF_sub_ge_on_box T (a := (T : ℝ)) (b := ((T + 1 : ℕ) : ℝ))
      (by push_cast; linarith [Nat.cast_nonneg (α := ℝ) T]) (by push_cast; linarith) le_rfl
    have hlen : ((T + 1 : ℕ) : ℝ) - (T : ℝ) = 1 := by push_cast; ring
    rw [hlen, mul_one] at h
    exact h
  have hcdf_0 : 0 ≤ stdNormalCDF (-((T + 1 : ℕ) : ℝ)) := MeasureTheory.measureReal_nonneg
  have hcdf_1 : stdNormalCDF ((T + 1 : ℕ) : ℝ) ≤ 1 := by
    unfold stdNormalCDF
    simpa [MeasureTheory.measureReal_def] using ENNReal.toReal_mono ENNReal.one_ne_top prob_le_one
  -- `k.1 ≠ 0`
  have hk0 : k.1 ≠ 0 := by
    intro h0
    have hle : z ≤ qVal b 1 := by
      unfold binSet at hzk; rwa [if_pos h0] at hzk
    have hcdf_z : stdNormalCDF (-(T : ℝ)) ≤ stdNormalCDF (qVal b 1) :=
      stdNormalCDF_mono (hz_lo.trans hle)
    have hq1 : stdNormalCDF (qVal b 1) = (2 : ℝ) ^ (-(b : ℤ)) := by
      rw [stdNormalCDF_qVal (by omega) (by
        calc 1 < 2 ^ 1 := by decide
          _ ≤ 2 ^ b := Nat.pow_le_pow_right (by decide) hb)]
      rw [Nat.cast_one, one_div, h2b_eq]
    linarith
  -- `k.1 + 1 < 2 ^ b`
  have hklt : k.1 + 1 < 2 ^ b := by
    by_contra hge
    have hk_eq : k.1 = 2 ^ b - 1 := by have := k.2; omega
    have hgt : qVal b (2 ^ b - 1) < z := by
      unfold binSet at hzk; rwa [if_neg hk0, if_neg hge] at hzk
    have hcdf_z : stdNormalCDF (qVal b (2 ^ b - 1)) ≤ stdNormalCDF (T : ℝ) :=
      stdNormalCDF_mono (hgt.le.trans hz_hi)
    have hq_last : stdNormalCDF (qVal b (2 ^ b - 1)) = 1 - (2 : ℝ) ^ (-(b : ℤ)) := by
      have h2b_ge2 : 2 ≤ 2 ^ b := by
        calc 2 = 2 ^ 1 := rfl
          _ ≤ 2 ^ b := Nat.pow_le_pow_right (by decide) hb
      rw [stdNormalCDF_qVal (by omega) (by omega)]
      have hsub : ((2 ^ b - 1 : ℕ) : ℝ) = ((2 ^ b : ℕ) : ℝ) - 1 := by
        rw [Nat.cast_sub (by omega : 1 ≤ 2 ^ b), Nat.cast_one]
      rw [hsub, sub_div, div_self (by positivity), one_div, h2b_eq]
    linarith
  -- Extract `qVal b k.1 < z ≤ qVal b (k.1 + 1)`
  have hz_mem : qVal b k.1 < z ∧ z ≤ qVal b (k.1 + 1) := by
    unfold binSet at hzk
    rwa [if_neg hk0, if_pos hklt] at hzk
  have hk1 : 1 ≤ k.1 := by omega
  have hcdf_step : stdNormalCDF (qVal b (k.1 + 1)) - stdNormalCDF (qVal b k.1) =
      (2 : ℝ) ^ (-(b : ℤ)) := by
    rw [stdNormalCDF_qVal (by omega) hklt, stdNormalCDF_qVal hk1 (by omega)]
    push_cast
    rw [add_div, add_sub_cancel_left, one_div, zpow_neg, zpow_natCast]
  -- `-(T + 1) ≤ qVal b k.1`
  have hq_lo : -((T + 1 : ℕ) : ℝ) ≤ qVal b k.1 := by
    by_contra hlt_lo
    push_neg at hlt_lo
    have hc1 := stdNormalCDF_mono hlt_lo.le
    have hc2 := stdNormalCDF_mono (hz_lo.trans hz_mem.2)
    linarith
  -- `qVal b (k.1 + 1) ≤ T + 1`
  have hq_hi : qVal b (k.1 + 1) ≤ ((T + 1 : ℕ) : ℝ) := by
    by_contra hgt_hi
    push_neg at hgt_hi
    have hc1 := stdNormalCDF_mono (hz_mem.1.le.trans hz_hi)
    have hc2 := stdNormalCDF_mono hgt_hi.le
    linarith
  -- Width bound `qVal b (k.1 + 1) - qVal b k.1 ≤ 2^{-(p_coord + 2)}`
  have hq_le : qVal b k.1 ≤ qVal b (k.1 + 1) := hz_mem.1.le.trans hz_mem.2
  have hwidth : qVal b (k.1 + 1) - qVal b k.1 ≤ (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) := by
    have hdens := stdNormalCDF_sub_ge_on_box T hq_lo hq_le hq_hi
    change (2 : ℝ) ^ (-(m_exp : ℤ)) * (qVal b (k.1 + 1) - qVal b k.1) ≤ _ at hdens
    rw [hcdf_step] at hdens
    have hmul := mul_le_mul_of_nonneg_left hdens (by positivity : 0 ≤ (2 : ℝ) ^ (m_exp : ℤ))
    have h1 : (2 : ℝ) ^ (m_exp : ℤ) * ((2 : ℝ) ^ (-(m_exp : ℤ)) * (qVal b (k.1 + 1) - qVal b k.1)) =
        qVal b (k.1 + 1) - qVal b k.1 := by
      rw [← mul_assoc, ← zpow_add₀ (by norm_num), add_neg_cancel, zpow_zero, one_mul]
    have h2 : (2 : ℝ) ^ (m_exp : ℤ) * (2 : ℝ) ^ (-(b : ℤ)) =
        (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) := by
      rw [← zpow_add₀ (by norm_num)]
      congr 1
      dsimp [b]
      omega
    rwa [h1, h2] at hmul
  -- Floor rounding error `|(sampleCoord1D ... : ℝ) - qVal b k.1| ≤ 2^{-b}`
  have hq_hi_k : qVal b k.1 ≤ ((T + 1 : ℕ) : ℝ) := hq_le.trans hq_hi
  have hclamp : (if k.1 = 0 then (0 : ℝ)
      else max (-((T + 1 : ℕ) : ℝ)) (min ((T + 1 : ℕ) : ℝ) (qVal b k.1))) = qVal b k.1 := by
    rw [if_neg hk0, min_eq_right hq_hi_k, max_eq_right hq_lo]
  have hsc_eq : ((sampleCoord1D b T (encode1D b hb z) : ℚ) : ℝ) =
      (⌊qVal b k.1 * ((2 ^ b : ℕ) : ℝ)⌋ : ℝ) / ((2 ^ b : ℕ) : ℝ) := by
    unfold sampleCoord1D
    simp only [hbits_k, hclamp, Rat.cast_div, Rat.cast_intCast, Rat.cast_natCast]
  have h2b_pos : (0 : ℝ) < ((2 ^ b : ℕ) : ℝ) := by positivity
  have hfl_lo : qVal b k.1 - (2 : ℝ) ^ (-(b : ℤ)) ≤
      ((sampleCoord1D b T (encode1D b hb z) : ℚ) : ℝ) := by
    rw [hsc_eq, ← h2b_eq, ← one_div]
    rw [le_div_iff₀ h2b_pos]
    have hlt := Int.sub_one_lt_floor (qVal b k.1 * ((2 ^ b : ℕ) : ℝ))
    have : qVal b k.1 * ((2 ^ b : ℕ) : ℝ) - 1 ≤ (⌊qVal b k.1 * ((2 ^ b : ℕ) : ℝ)⌋ : ℝ) := hlt.le
    have hmul : (qVal b k.1 - 1 / ((2 ^ b : ℕ) : ℝ)) * ((2 ^ b : ℕ) : ℝ) =
        qVal b k.1 * ((2 ^ b : ℕ) : ℝ) - 1 := by field_simp
    linarith
  have hfl_hi : ((sampleCoord1D b T (encode1D b hb z) : ℚ) : ℝ) ≤ qVal b k.1 := by
    rw [hsc_eq, div_le_iff₀ h2b_pos]
    exact Int.floor_le _
  have h2b_le_p : (2 : ℝ) ^ (-(b : ℤ)) ≤ (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) :=
    zpow_le_zpow_right₀ (by norm_num) (by dsimp [b]; omega)
  have hhalf : (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) + (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) =
      (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) := by
    have heq : -((p_coord + 1 : ℕ) : ℤ) = -((p_coord + 2 : ℕ) : ℤ) + 1 := by omega
    rw [heq, zpow_add₀ (by norm_num), zpow_one]
    ring
  rw [abs_le]
  refine ⟨?_, ?_⟩
  · linarith [hz_mem.2, hwidth, hfl_lo, h2b_le_p, hhalf]
  · linarith [hz_mem.1, hfl_hi, h2b_le_p, hhalf]

/-! ### 4. Product coupling on `ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)` -/

noncomputable def projBitsMap {R ℓ M₀ D b : ℕ} (hb : 1 ≤ b)
    (ω_c : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) :
    UL.ExplicitBitSeed R ℓ M₀ D b :=
  fun q => encode1D b hb (UL.euclideanCoord (ω_c q.1) q.2.1) q.2.2

theorem measurable_euclideanCoord {D : ℕ} (j : Fin D) :
    Measurable (fun v : EuclideanSpace ℝ (Fin D) => UL.euclideanCoord v j) := by
  exact (measurable_pi_apply j).comp (MeasurableEquiv.toLp 2 (Fin D → ℝ)).symm.measurable

theorem measurable_projBitsMap {R ℓ M₀ D b : ℕ} (hb : 1 ≤ b) :
    Measurable (projBitsMap (R := R) (ℓ := ℓ) (M₀ := M₀) (D := D) hb) := by
  rw [measurable_pi_iff]
  intro q
  exact ((measurable_pi_apply q.2.2).comp (measurable_encode1D b hb)).comp
    ((measurable_euclideanCoord q.2.1).comp (measurable_pi_apply q.1))

theorem stdGaussianMeasure_coord_rect {D : ℕ} (A : Fin D → Set ℝ)
    (hA : ∀ j : Fin D, MeasurableSet (A j)) :
    UL.stdGaussianMeasure D {v | ∀ j : Fin D, UL.euclideanCoord v j ∈ A j} =
      ∏ j : Fin D, gaussianReal 0 1 (A j) := by
  let S : Set (EuclideanSpace ℝ (Fin D)) := {v | ∀ j : Fin D, UL.euclideanCoord v j ∈ A j}
  have hS_meas : MeasurableSet S := by
    have h_eq : S = ⋂ j : Fin D, (fun v => UL.euclideanCoord v j) ⁻¹' A j := by
      ext v; simp [S]
    rw [h_eq]
    exact MeasurableSet.iInter fun j => (hA j).preimage (measurable_euclideanCoord j)
  have hmeas_toLp : Measurable (WithLp.toLp 2 : (Fin D → ℝ) → EuclideanSpace ℝ (Fin D)) :=
    (MeasurableEquiv.toLp 2 (Fin D → ℝ)).measurable
  change UL.stdGaussianMeasure D S = _
  rw [UL.Proof_lem_6_2.stdGaussianMeasure_eq_map_toLp, Measure.map_apply hmeas_toLp hS_meas]
  have hpre : (WithLp.toLp 2 : (Fin D → ℝ) → EuclideanSpace ℝ (Fin D)) ⁻¹' S = Set.univ.pi A := by
    ext x; simp [S, UL.euclideanCoord]
  rw [hpre, Measure.pi_pi]

theorem map_projBitsMap_eq_uniform {R ℓ M₀ D b : ℕ} (hb : 1 ≤ b) :
    (Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure D)).map
        (projBitsMap hb) =
      (PMF.uniformOfFintype (UL.ExplicitBitSeed R ℓ M₀ D b)).toMeasure := by
  classical
  let Seed := UL.ExplicitBitSeed R ℓ M₀ D b
  let μ_cpl := Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure D)
  let μ_lhs := μ_cpl.map (projBitsMap hb)
  let μ_rhs := (PMF.uniformOfFintype Seed).toMeasure
  have hmp : Measurable (projBitsMap (R := R) (ℓ := ℓ) (M₀ := M₀) (D := D) hb) :=
    measurable_projBitsMap hb
  have hsing : ∀ ω : Seed, μ_lhs ({ω} : Set Seed) = μ_rhs ({ω} : Set Seed) := by
    intro ω
    rw [Measure.map_apply hmp MeasurableSet.of_discrete,
      PMF.toMeasure_apply_singleton _ _ MeasurableSet.of_discrete, PMF.uniformOfFintype_apply]
    let C_idx : UL.ExplicitCapIdx R ℓ M₀ → Set (EuclideanSpace ℝ (Fin D)) :=
      fun idx => {v | ∀ j : Fin D,
        UL.euclideanCoord v j ∈ encode1D b hb ⁻¹' ({fun bitIdx => ω (idx, j, bitIdx)} : Set (Fin b → Bool))}
    have hpre : projBitsMap hb ⁻¹' ({ω} : Set Seed) = Set.univ.pi C_idx := by
      ext ω_c
      simp only [Set.mem_preimage, Set.mem_singleton_iff, Set.mem_univ_pi, C_idx, Set.mem_setOf_eq,
        projBitsMap, funext_iff, Prod.forall]
    rw [hpre, Measure.pi_pi]
    have hterm : ∀ idx : UL.ExplicitCapIdx R ℓ M₀,
        UL.stdGaussianMeasure D (C_idx idx) = ((((2 ^ b : ℕ) : ℝ≥0∞))⁻¹) ^ D := by
      intro idx
      dsimp only [C_idx]
      rw [stdGaussianMeasure_coord_rect _ (fun j => by
        rw [preimage_encode1D_singleton]; exact measurableSet_binSet b _)]
      have hj : ∀ j : Fin D,
          gaussianReal 0 1 (encode1D b hb ⁻¹' ({fun bitIdx => ω (idx, j, bitIdx)} : Set (Fin b → Bool))) =
            (((2 ^ b : ℕ) : ℝ≥0∞))⁻¹ := by
        intro j
        rw [preimage_encode1D_singleton, binSet_measure b hb]
      simp_rw [hj]
      simp
    simp_rw [hterm]
    rw [Finset.prod_const, Finset.card_univ, ← ENNReal.inv_pow, ← ENNReal.inv_pow, ← pow_mul]
    congr 1
    have hcard : Fintype.card Seed = (2 ^ b) ^ (D * Fintype.card (UL.ExplicitCapIdx R ℓ M₀)) := by
      dsimp [Seed, UL.ExplicitBitSeed]
      simp only [Fintype.card_fun, Fintype.card_prod, Fintype.card_fin, Fintype.card_bool]
      rw [← pow_mul]
      congr 1
      ring
    rw [hcard]
    push_cast
    rfl
  ext E _hE
  let S_fin : Finset Seed := Finset.univ.filter (fun ω : Seed => ω ∈ E)
  have hE_eq : E = ⋃ ω ∈ S_fin, ({ω} : Set Seed) := by ext ω; simp [S_fin]
  have hdisj : (S_fin : Set Seed).PairwiseDisjoint (fun ω : Seed => ({ω} : Set Seed)) :=
    fun _ _ _ _ hne => Set.disjoint_singleton.mpr hne
  rw [hE_eq,
    MeasureTheory.measure_biUnion_finset hdisj (fun _ _ => MeasurableSet.of_discrete),
    MeasureTheory.measure_biUnion_finset hdisj (fun _ _ => MeasurableSet.of_discrete)]
  exact Finset.sum_congr rfl fun ω _ => hsing ω

theorem pi_coord_abs_gt_prob_le {R ℓ M₀ D : ℕ} (T : ℕ) :
    (Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure D)).real
        {ω_c | ∃ (idx : UL.ExplicitCapIdx R ℓ M₀) (j : Fin D),
          (T : ℝ) < |UL.euclideanCoord (ω_c idx) j|} ≤
      (R * ℓ * M₀ * D : ℕ) * (2 * Real.exp (-((T : ℝ) ^ 2 / 2))) := by
  classical
  let μ_cpl := Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure D)
  let Pairs := UL.ExplicitCapIdx R ℓ M₀ × Fin D
  let E_p : Pairs → Set (UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D)) :=
    fun p => {ω_c | (T : ℝ) < |UL.euclideanCoord (ω_c p.1) p.2|}
  have hset : {ω_c : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D) |
      ∃ (idx : UL.ExplicitCapIdx R ℓ M₀) (j : Fin D),
        (T : ℝ) < |UL.euclideanCoord (ω_c idx) j|} =
      ⋃ p ∈ (Finset.univ : Finset Pairs), E_p p := by
    ext ω_c
    simp only [Set.mem_setOf_eq, Set.mem_iUnion, Finset.mem_univ, exists_true_left, E_p]
    constructor
    · rintro ⟨idx, j, h⟩; exact ⟨(idx, j), h⟩
    · rintro ⟨⟨idx, j⟩, h⟩; exact ⟨idx, j, h⟩
  have h_each : ∀ p : Pairs, μ_cpl.real (E_p p) ≤ 2 * Real.exp (-((T : ℝ) ^ 2 / 2)) := by
    intro p
    let A_1D : Set ℝ := {z : ℝ | (T : ℝ) < |z|}
    have hA_meas : MeasurableSet A_1D :=
      (measurableSet_lt measurable_const continuous_abs.measurable)
    let A_vec : Set (EuclideanSpace ℝ (Fin D)) := {v | UL.euclideanCoord v p.2 ∈ A_1D}
    have hAv_meas : MeasurableSet A_vec := hA_meas.preimage (measurable_euclideanCoord p.2)
    have hmp := MeasureTheory.measurePreserving_eval
      (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure D) p.1
    have hpre1 : E_p p = (Function.eval p.1) ⁻¹' A_vec := rfl
    rw [hpre1, MeasureTheory.measureReal_def, ← Measure.map_apply hmp.measurable hAv_meas,
      hmp.map_eq]
    have hrect : A_vec = {v | ∀ j' : Fin D,
        UL.euclideanCoord v j' ∈ (if j' = p.2 then A_1D else Set.univ)} := by
      ext v; simp [A_vec]
    rw [hrect, stdGaussianMeasure_coord_rect _ (fun j' => by
      split_ifs
      · exact hA_meas
      · exact MeasurableSet.univ)]
    have hprod : (∏ j' : Fin D, gaussianReal 0 1 (if j' = p.2 then A_1D else Set.univ)) =
        gaussianReal 0 1 A_1D := by
      have hterm : ∀ j' : Fin D,
          gaussianReal 0 1 (if j' = p.2 then A_1D else Set.univ) =
            if j' = p.2 then gaussianReal 0 1 A_1D else 1 := by
        intro j'; split_ifs <;> simp
      simp_rw [hterm]
      simp
    rw [hprod, ← MeasureTheory.measureReal_def]
    exact stdNormal_abs_gt_le T
  rw [hset]
  calc μ_cpl.real (⋃ p ∈ (Finset.univ : Finset Pairs), E_p p)
      ≤ ∑ p ∈ (Finset.univ : Finset Pairs), μ_cpl.real (E_p p) :=
        UL.Proof_lem_6_3.measureReal_biUnion_finset_le_sum μ_cpl _ _
    _ ≤ ∑ _p ∈ (Finset.univ : Finset Pairs), (2 * Real.exp (-((T : ℝ) ^ 2 / 2))) :=
        Finset.sum_le_sum fun p _ => h_each p
    _ = (R * ℓ * M₀ * D : ℕ) * (2 * Real.exp (-((T : ℝ) ^ 2 / 2))) := by
        simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, Pairs, UL.ExplicitCapIdx,
          Fintype.card_prod, Fintype.card_fin]
        push_cast
        ring

theorem euclidean_norm_sub_le_of_coord {D : ℕ}
    {v w : EuclideanSpace ℝ (Fin D)} {δ : ℝ} (hδ : 0 ≤ δ)
    (hc : ∀ j : Fin D, |UL.euclideanCoord v j - UL.euclideanCoord w j| ≤ δ) :
    ‖v - w‖ ≤ (D : ℝ) * δ := by
  have hsq : ‖v - w‖ ^ 2 ≤ ((D : ℝ) * δ) ^ 2 := by
    have hnorm : ‖v - w‖ ^ 2 = ∑ j : Fin D, (UL.euclideanCoord v j - UL.euclideanCoord w j) ^ 2 := by
      rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
      refine Finset.sum_congr rfl fun j _ => ?_
      simp [UL.euclideanCoord, sq]
    rw [hnorm]
    have hsum : (∑ j : Fin D, (UL.euclideanCoord v j - UL.euclideanCoord w j) ^ 2) ≤
        (D : ℝ) * δ ^ 2 := by
      calc (∑ j : Fin D, (UL.euclideanCoord v j - UL.euclideanCoord w j) ^ 2)
          ≤ ∑ _j : Fin D, δ ^ 2 := by
            refine Finset.sum_le_sum fun j _ => ?_
            rcases abs_le.mp (hc j) with ⟨h1, h2⟩
            nlinarith
        _ = (D : ℝ) * δ ^ 2 := by simp
    have hD_sq : (D : ℝ) ≤ (D : ℝ) ^ 2 := by
      by_cases hD0 : D = 0
      · subst hD0; norm_num
      · have hD1 : (1 : ℝ) ≤ (D : ℝ) := by exact_mod_cast (Nat.pos_of_ne_zero hD0)
        nlinarith
    calc (∑ j : Fin D, (UL.euclideanCoord v j - UL.euclideanCoord w j) ^ 2)
        ≤ (D : ℝ) * δ ^ 2 := hsum
      _ ≤ (D : ℝ) ^ 2 * δ ^ 2 := mul_le_mul_of_nonneg_right hD_sq (sq_nonneg δ)
      _ = ((D : ℝ) * δ) ^ 2 := by ring
  have hnn1 : 0 ≤ ‖v - w‖ := norm_nonneg _
  have hnn2 : 0 ≤ (D : ℝ) * δ := by positivity
  nlinarith

end UL.Proof_clm_6_1_precision_RaceV30
