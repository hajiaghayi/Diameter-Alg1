import Mathlib
import UL.Stmt.clm_6_1_precision
import UL.Stmt.lem_6_2
import UL.Proof.lem_6_2.H1
import UL.Proof.lem_6_3.H2_Params
import UL.Proof.lem_6_3.H5_Prob
import UL.Proof.clm_6_1_precision.RaceV30_H1
import UL.Proof.clm_6_1_precision.RaceV30_H2
import UL.Proof.clm_6_1_precision.RaceV30_H3
set_option autoImplicit false

open MeasureTheory ProbabilityTheory
open scoped ENNReal NNReal Real

namespace UL.Proof_clm_6_1_precision_RaceV30

/-! ### 1. Bivariate polynomial bound combinators (`NonnegPoly2`) -/

def NonnegPoly2 (f : ℕ → ℕ → ℝ) : Prop :=
  (∀ d L : ℕ, 0 ≤ f d L) ∧ UL.IsBoundedByPoly2 f

lemma nonnegPoly2_congr {f g : ℕ → ℕ → ℝ} (hfg : ∀ d L : ℕ, f d L = g d L)
    (hf : NonnegPoly2 f) : NonnegPoly2 g := by
  rcases hf with ⟨h0, C, deg, hC, hbd⟩
  refine ⟨fun d L => hfg d L ▸ h0 d L, C, deg, hC, fun d L => ?_⟩
  rw [← hfg d L]
  exact hbd d L

lemma nonnegPoly2_const {c : ℝ} (hc : 0 ≤ c) : NonnegPoly2 (fun _ _ => c) := by
  refine ⟨fun _ _ => hc, c, 0, hc, fun d L => ?_⟩
  simp

lemma nonnegPoly2_d : NonnegPoly2 (fun d _ => (d : ℝ)) := by
  refine ⟨fun d _ => Nat.cast_nonneg d, 1, 1, zero_le_one, fun d L => ?_⟩
  have hd0 : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
  have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  simp only [pow_one, one_mul]
  nlinarith

lemma nonnegPoly2_L : NonnegPoly2 (fun _ L => (L : ℝ)) := by
  refine ⟨fun _ L => Nat.cast_nonneg L, 1, 1, zero_le_one, fun d L => ?_⟩
  have hd0 : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
  have hL0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  simp only [pow_one, one_mul]
  nlinarith

lemma nonnegPoly2_add {f g : ℕ → ℕ → ℝ} (hf : NonnegPoly2 f) (hg : NonnegPoly2 g) :
    NonnegPoly2 (fun d L => f d L + g d L) := by
  rcases hf with ⟨hf0, C₁, deg₁, hC₁, hbd₁⟩
  rcases hg with ⟨hg0, C₂, deg₂, hC₂, hbd₂⟩
  refine ⟨fun d L => add_nonneg (hf0 d L) (hg0 d L),
    C₁ + C₂, max deg₁ deg₂, add_nonneg hC₁ hC₂, fun d L => ?_⟩
  have hd1 : (1 : ℝ) ≤ (d : ℝ) + 1 := by linarith [Nat.cast_nonneg (α := ℝ) d]
  have hL1 : (1 : ℝ) ≤ (L : ℝ) + 1 := by linarith [Nat.cast_nonneg (α := ℝ) L]
  have hp_d1 : ((d : ℝ) + 1) ^ deg₁ ≤ ((d : ℝ) + 1) ^ max deg₁ deg₂ :=
    pow_le_pow_right₀ hd1 (le_max_left _ _)
  have hp_L1 : ((L : ℝ) + 1) ^ deg₁ ≤ ((L : ℝ) + 1) ^ max deg₁ deg₂ :=
    pow_le_pow_right₀ hL1 (le_max_left _ _)
  have hp_d2 : ((d : ℝ) + 1) ^ deg₂ ≤ ((d : ℝ) + 1) ^ max deg₁ deg₂ :=
    pow_le_pow_right₀ hd1 (le_max_right _ _)
  have hp_L2 : ((L : ℝ) + 1) ^ deg₂ ≤ ((L : ℝ) + 1) ^ max deg₁ deg₂ :=
    pow_le_pow_right₀ hL1 (le_max_right _ _)
  have ht1 : f d L ≤ C₁ * ((d : ℝ) + 1) ^ max deg₁ deg₂ * ((L : ℝ) + 1) ^ max deg₁ deg₂ := by
    calc f d L ≤ C₁ * ((d : ℝ) + 1) ^ deg₁ * ((L : ℝ) + 1) ^ deg₁ := hbd₁ d L
      _ = C₁ * (((d : ℝ) + 1) ^ deg₁ * ((L : ℝ) + 1) ^ deg₁) := by ring
      _ ≤ C₁ * (((d : ℝ) + 1) ^ max deg₁ deg₂ * ((L : ℝ) + 1) ^ max deg₁ deg₂) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul hp_d1 hp_L1 (by positivity) (by positivity)) hC₁
      _ = C₁ * ((d : ℝ) + 1) ^ max deg₁ deg₂ * ((L : ℝ) + 1) ^ max deg₁ deg₂ := by ring
  have ht2 : g d L ≤ C₂ * ((d : ℝ) + 1) ^ max deg₁ deg₂ * ((L : ℝ) + 1) ^ max deg₁ deg₂ := by
    calc g d L ≤ C₂ * ((d : ℝ) + 1) ^ deg₂ * ((L : ℝ) + 1) ^ deg₂ := hbd₂ d L
      _ = C₂ * (((d : ℝ) + 1) ^ deg₂ * ((L : ℝ) + 1) ^ deg₂) := by ring
      _ ≤ C₂ * (((d : ℝ) + 1) ^ max deg₁ deg₂ * ((L : ℝ) + 1) ^ max deg₁ deg₂) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul hp_d2 hp_L2 (by positivity) (by positivity)) hC₂
      _ = C₂ * ((d : ℝ) + 1) ^ max deg₁ deg₂ * ((L : ℝ) + 1) ^ max deg₁ deg₂ := by ring
  linarith

lemma nonnegPoly2_mul {f g : ℕ → ℕ → ℝ} (hf : NonnegPoly2 f) (hg : NonnegPoly2 g) :
    NonnegPoly2 (fun d L => f d L * g d L) := by
  rcases hf with ⟨hf0, C₁, deg₁, hC₁, hbd₁⟩
  rcases hg with ⟨hg0, C₂, deg₂, hC₂, hbd₂⟩
  refine ⟨fun d L => mul_nonneg (hf0 d L) (hg0 d L),
    C₁ * C₂, deg₁ + deg₂, mul_nonneg hC₁ hC₂, fun d L => ?_⟩
  have h1 := hbd₁ d L
  have h2 := hbd₂ d L
  have hr1 : 0 ≤ C₁ * ((d : ℝ) + 1) ^ deg₁ * ((L : ℝ) + 1) ^ deg₁ := by positivity
  calc f d L * g d L
      ≤ (C₁ * ((d : ℝ) + 1) ^ deg₁ * ((L : ℝ) + 1) ^ deg₁) *
          (C₂ * ((d : ℝ) + 1) ^ deg₂ * ((L : ℝ) + 1) ^ deg₂) :=
        mul_le_mul h1 h2 (hg0 d L) hr1
    _ = (C₁ * C₂) * (((d : ℝ) + 1) ^ deg₁ * ((d : ℝ) + 1) ^ deg₂) *
          (((L : ℝ) + 1) ^ deg₁ * ((L : ℝ) + 1) ^ deg₂) := by ring
    _ = (C₁ * C₂) * ((d : ℝ) + 1) ^ (deg₁ + deg₂) * ((L : ℝ) + 1) ^ (deg₁ + deg₂) := by
        rw [← pow_add, ← pow_add]

lemma nonnegPoly2_pow {f : ℕ → ℕ → ℝ} (hf : NonnegPoly2 f) (k : ℕ) :
    NonnegPoly2 (fun d L => (f d L) ^ k) := by
  induction k with
  | zero =>
      exact nonnegPoly2_congr (fun _ _ => (pow_zero _).symm) (nonnegPoly2_const zero_le_one)
  | succ n ih =>
      exact nonnegPoly2_congr (fun d L => (pow_succ (f d L) n).symm) (nonnegPoly2_mul ih hf)

/-! ### 2. Explicit polynomial parameter formulas and `IsBoundedByPoly2` -/

def R_fn (C_net_nat d L : ℕ) : ℕ :=
  L + C_net_nat * d * (d + L) + 1

def E_M_fn (C_M_nat L : ℕ) : ℕ :=
  C_M_nat + 3 * (L + 2) ^ 2 + 2

def K_tail_fn (ℓ C_net_nat C_M_nat d L : ℕ) : ℕ :=
  R_fn C_net_nat d L + ℓ + E_M_fn C_M_nat L + d + 2 * L + 3

def T_fn (ℓ C_net_nat C_M_nat d L : ℕ) : ℕ :=
  K_tail_fn ℓ C_net_nat C_M_nat d L + 2

def p_bits_fn (ℓ C_net_nat C_M_nat d L : ℕ) : ℕ :=
  R_fn C_net_nat d L + ℓ + E_M_fn C_M_nat L + 4 * L + 2 * C_net_nat * d * (d + L) + 2

def p_coord_fn (ℓ C_net_nat C_M_nat d L : ℕ) : ℕ :=
  p_bits_fn ℓ C_net_nat C_M_nat d L + d + 2

def m_exp_fn (ℓ C_net_nat C_M_nat d L : ℕ) : ℕ :=
  (T_fn ℓ C_net_nat C_M_nat d L + 1) ^ 2 + 2

def b_fn (ℓ C_net_nat C_M_nat d L : ℕ) : ℕ :=
  m_exp_fn ℓ C_net_nat C_M_nat d L + p_coord_fn ℓ C_net_nat C_M_nat d L + 2

def B_prec_fn (ℓ C_net_nat C_M_nat d L : ℕ) : ℕ :=
  b_fn ℓ C_net_nat C_M_nat d L + T_fn ℓ C_net_nat C_M_nat d L + ℓ + 2 * L + 6

noncomputable def S_exp_val (ℓ : ℕ) : ℝ :=
  Real.exp ((ℓ + 2 : ℕ) : ℝ)

noncomputable def K_I_fn (ℓ C_net_nat C_M_nat d L : ℕ) : ℝ :=
  ((R_fn C_net_nat d L * ℓ : ℕ) : ℝ) *
    ((C_M_nat : ℝ) * ((L : ℝ) + 2) ^ 2 * (S_exp_val ℓ) ^ 2 + 2)

noncomputable def P_M_fn (ℓ C_M_nat L : ℕ) : ℝ :=
  ((C_M_nat : ℝ) * ((L : ℝ) + 2) ^ 2 + 2) ^ ℓ

noncomputable def K_u_fn (ℓ C_M_nat L : ℕ) : ℝ :=
  100 * (P_M_fn ℓ C_M_nat L * S_exp_val ℓ + 1) + 2

noncomputable def K_q_fn (ℓ C_M_nat L : ℕ) : ℝ :=
  100 * (P_M_fn ℓ C_M_nat L * (S_exp_val ℓ) ^ 2 + 1) + 2

noncomputable def poly_cap_fn (ℓ C_net_nat C_M_nat d L : ℕ) : ℝ :=
  K_I_fn ℓ C_net_nat C_M_nat d L * ((d : ℝ) + 1) +
    ((R_fn C_net_nat d L * (ℓ + 2) : ℕ) : ℝ) * (K_u_fn ℓ C_M_nat L + K_q_fn ℓ C_M_nat L)

lemma nonnegPoly2_R_fn (C_net_nat : ℕ) :
    NonnegPoly2 (fun d L => (R_fn C_net_nat d L : ℝ)) := by
  refine nonnegPoly2_congr (fun d L => by unfold R_fn; push_cast; rfl) ?_
  exact nonnegPoly2_add
    (nonnegPoly2_add nonnegPoly2_L
      (nonnegPoly2_mul
        (nonnegPoly2_mul (nonnegPoly2_const (Nat.cast_nonneg C_net_nat)) nonnegPoly2_d)
        (nonnegPoly2_add nonnegPoly2_d nonnegPoly2_L)))
    (nonnegPoly2_const zero_le_one)

lemma nonnegPoly2_E_M_fn (C_M_nat : ℕ) :
    NonnegPoly2 (fun _ L => (E_M_fn C_M_nat L : ℝ)) := by
  refine nonnegPoly2_congr (fun _ L => by unfold E_M_fn; push_cast; rfl) ?_
  exact nonnegPoly2_add
    (nonnegPoly2_add (nonnegPoly2_const (Nat.cast_nonneg C_M_nat))
      (nonnegPoly2_mul (nonnegPoly2_const (by norm_num))
        (nonnegPoly2_pow (nonnegPoly2_add nonnegPoly2_L (nonnegPoly2_const (by norm_num))) 2)))
    (nonnegPoly2_const (by norm_num))

lemma nonnegPoly2_T_fn (ℓ C_net_nat C_M_nat : ℕ) :
    NonnegPoly2 (fun d L => (T_fn ℓ C_net_nat C_M_nat d L : ℝ)) := by
  have hK : NonnegPoly2 (fun d L => (K_tail_fn ℓ C_net_nat C_M_nat d L : ℝ)) := by
    refine nonnegPoly2_congr (fun d L => by unfold K_tail_fn; push_cast; rfl) ?_
    exact nonnegPoly2_add
      (nonnegPoly2_add
        (nonnegPoly2_add
          (nonnegPoly2_add
            (nonnegPoly2_add (nonnegPoly2_R_fn C_net_nat) (nonnegPoly2_const (Nat.cast_nonneg ℓ)))
            (nonnegPoly2_E_M_fn C_M_nat))
          nonnegPoly2_d)
        (nonnegPoly2_mul (nonnegPoly2_const (by norm_num)) nonnegPoly2_L))
      (nonnegPoly2_const (by norm_num))
  refine nonnegPoly2_congr (fun d L => by unfold T_fn; push_cast; rfl) ?_
  exact nonnegPoly2_add hK (nonnegPoly2_const (by norm_num))

lemma nonnegPoly2_B_prec_fn (ℓ C_net_nat C_M_nat : ℕ) :
    NonnegPoly2 (fun d L => (B_prec_fn ℓ C_net_nat C_M_nat d L : ℝ)) := by
  have hp_bits : NonnegPoly2 (fun d L => (p_bits_fn ℓ C_net_nat C_M_nat d L : ℝ)) := by
    refine nonnegPoly2_congr (fun d L => by unfold p_bits_fn; push_cast; rfl) ?_
    exact nonnegPoly2_add
      (nonnegPoly2_add
        (nonnegPoly2_add
          (nonnegPoly2_add
            (nonnegPoly2_add (nonnegPoly2_R_fn C_net_nat) (nonnegPoly2_const (Nat.cast_nonneg ℓ)))
            (nonnegPoly2_E_M_fn C_M_nat))
          (nonnegPoly2_mul (nonnegPoly2_const (by norm_num)) nonnegPoly2_L))
        (nonnegPoly2_mul
          (nonnegPoly2_mul
            (nonnegPoly2_mul (nonnegPoly2_const (by norm_num))
              (nonnegPoly2_const (Nat.cast_nonneg C_net_nat)))
            nonnegPoly2_d)
          (nonnegPoly2_add nonnegPoly2_d nonnegPoly2_L)))
      (nonnegPoly2_const (by norm_num))
  have hp_coord : NonnegPoly2 (fun d L => (p_coord_fn ℓ C_net_nat C_M_nat d L : ℝ)) := by
    refine nonnegPoly2_congr (fun d L => by unfold p_coord_fn; push_cast; rfl) ?_
    exact nonnegPoly2_add (nonnegPoly2_add hp_bits nonnegPoly2_d) (nonnegPoly2_const (by norm_num))
  have hm_exp : NonnegPoly2 (fun d L => (m_exp_fn ℓ C_net_nat C_M_nat d L : ℝ)) := by
    refine nonnegPoly2_congr (fun d L => by unfold m_exp_fn; push_cast; rfl) ?_
    exact nonnegPoly2_add
      (nonnegPoly2_pow
        (nonnegPoly2_add (nonnegPoly2_T_fn ℓ C_net_nat C_M_nat) (nonnegPoly2_const zero_le_one)) 2)
      (nonnegPoly2_const (by norm_num))
  have hb : NonnegPoly2 (fun d L => (b_fn ℓ C_net_nat C_M_nat d L : ℝ)) := by
    refine nonnegPoly2_congr (fun d L => by unfold b_fn; push_cast; rfl) ?_
    exact nonnegPoly2_add (nonnegPoly2_add hm_exp hp_coord) (nonnegPoly2_const (by norm_num))
  refine nonnegPoly2_congr (fun d L => by unfold B_prec_fn; push_cast; rfl) ?_
  exact nonnegPoly2_add
    (nonnegPoly2_add
      (nonnegPoly2_add
        (nonnegPoly2_add hb (nonnegPoly2_T_fn ℓ C_net_nat C_M_nat))
        (nonnegPoly2_const (Nat.cast_nonneg ℓ)))
      (nonnegPoly2_mul (nonnegPoly2_const (by norm_num)) nonnegPoly2_L))
    (nonnegPoly2_const (by norm_num))

lemma nonnegPoly2_poly_cap_fn (ℓ C_net_nat C_M_nat : ℕ) :
    NonnegPoly2 (poly_cap_fn ℓ C_net_nat C_M_nat) := by
  have hS : 0 ≤ S_exp_val ℓ := (Real.exp_pos _).le
  have hS2 : 0 ≤ (S_exp_val ℓ) ^ 2 := sq_nonneg _
  have hL2 : NonnegPoly2 (fun _ L => ((L : ℝ) + 2) ^ 2) :=
    nonnegPoly2_pow (nonnegPoly2_add nonnegPoly2_L (nonnegPoly2_const (by norm_num))) 2
  have hKI : NonnegPoly2 (K_I_fn ℓ C_net_nat C_M_nat) := by
    refine nonnegPoly2_congr (fun d L => by unfold K_I_fn; push_cast; rfl) ?_
    exact nonnegPoly2_mul
      (nonnegPoly2_mul (nonnegPoly2_R_fn C_net_nat) (nonnegPoly2_const (Nat.cast_nonneg ℓ)))
      (nonnegPoly2_add
        (nonnegPoly2_mul
          (nonnegPoly2_mul (nonnegPoly2_const (Nat.cast_nonneg C_M_nat)) hL2)
          (nonnegPoly2_const hS2))
        (nonnegPoly2_const (by norm_num)))
  have hPM : NonnegPoly2 (fun _ L => P_M_fn ℓ C_M_nat L) :=
    nonnegPoly2_pow
      (nonnegPoly2_add
        (nonnegPoly2_mul (nonnegPoly2_const (Nat.cast_nonneg C_M_nat)) hL2)
        (nonnegPoly2_const (by norm_num)))
      ℓ
  have hKu : NonnegPoly2 (fun _ L => K_u_fn ℓ C_M_nat L) :=
    nonnegPoly2_add
      (nonnegPoly2_mul (nonnegPoly2_const (by norm_num))
        (nonnegPoly2_add (nonnegPoly2_mul hPM (nonnegPoly2_const hS))
          (nonnegPoly2_const zero_le_one)))
      (nonnegPoly2_const (by norm_num))
  have hKq : NonnegPoly2 (fun _ L => K_q_fn ℓ C_M_nat L) :=
    nonnegPoly2_add
      (nonnegPoly2_mul (nonnegPoly2_const (by norm_num))
        (nonnegPoly2_add (nonnegPoly2_mul hPM (nonnegPoly2_const hS2))
          (nonnegPoly2_const zero_le_one)))
      (nonnegPoly2_const (by norm_num))
  refine nonnegPoly2_congr (fun d L => by unfold poly_cap_fn; push_cast; rfl) ?_
  exact nonnegPoly2_add
    (nonnegPoly2_mul hKI (nonnegPoly2_add nonnegPoly2_d (nonnegPoly2_const zero_le_one)))
    (nonnegPoly2_mul
      (nonnegPoly2_mul (nonnegPoly2_R_fn C_net_nat)
        (nonnegPoly2_const (by positivity : (0 : ℝ) ≤ (ℓ : ℝ) + 2)))
      (nonnegPoly2_add hKu hKq))

/-! ### 3. Auxiliary real/list/measurability helpers for Part 4 -/

lemma exp_mul_le_rpow {y S m α : ℝ} {k : ℕ}
    (hS1 : 1 ≤ S) (hm1 : 1 ≤ m) (hα0 : 0 ≤ α) (hαk : α ≤ (k : ℝ))
    (hexp : Real.exp y ≤ S * m) :
    Real.exp (α * y) ≤ S ^ k * m ^ α := by
  have h1 : Real.exp (α * y) = (Real.exp y) ^ α := by
    rw [Real.rpow_def_of_pos (Real.exp_pos y), Real.log_exp]
    ring_nf
  rw [h1]
  calc (Real.exp y) ^ α
      ≤ (S * m) ^ α := Real.rpow_le_rpow (Real.exp_pos y).le hexp hα0
    _ = S ^ α * m ^ α := Real.mul_rpow (by linarith) (by linarith)
    _ ≤ S ^ (k : ℝ) * m ^ α :=
        mul_le_mul_of_nonneg_right (Real.rpow_le_rpow_of_exponent_le hS1 hαk)
          (Real.rpow_nonneg (by linarith) α)
    _ = S ^ k * m ^ α := by rw [Real.rpow_natCast]

lemma euclideanCoord_ratPointToEuclidean {D : ℕ} (q : Fin D → ℚ) (j : Fin D) :
    UL.euclideanCoord (UL.ratPointToEuclidean q) j = (q j : ℝ) := by
  unfold UL.euclideanCoord UL.ratPointToEuclidean
  simp

lemma length_flatMap_map {α β γ : Type*} (xs : List α) (ys : List β) (f : α → β → γ) :
    (xs.flatMap (fun a => ys.map (f a))).length = xs.length * ys.length := by
  induction xs with
  | nil => simp
  | cons a tl ih =>
      simp only [List.flatMap_cons, List.length_append, List.length_map, ih, List.length_cons]
      ring

lemma measurableSet_exists_mem_list {Ω α : Type*} [MeasurableSpace Ω]
    (L : List α) (E : α → Set Ω) (hE : ∀ c ∈ L, MeasurableSet (E c)) :
    MeasurableSet {ω : Ω | ∃ c ∈ L, ω ∈ E c} := by
  induction L with
  | nil =>
      have hemp : {ω : Ω | ∃ c ∈ ([] : List α), ω ∈ E c} = ∅ := by ext ω; simp
      rw [hemp]
      exact MeasurableSet.empty
  | cons a tl ih =>
      have hcons : {ω : Ω | ∃ c ∈ a :: tl, ω ∈ E c} = E a ∪ {ω : Ω | ∃ c ∈ tl, ω ∈ E c} := by
        ext ω; simp
      rw [hcons]
      exact (hE a (by simp)).union (ih fun c hc => hE c (by simp [hc]))

/-! ### 4. Complete proof of Part 4 of `S_clm_6_1_precision` -/

/-! ### 4. Modular helper lemmas for Part 4 of `S_clm_6_1_precision` -/

lemma R_fn_pos (C_net_nat d L : ℕ) : 1 ≤ R_fn C_net_nat d L := by
  unfold R_fn; omega

lemma b_fn_pos (ℓ C_net_nat C_M_nat d L : ℕ) : 1 ≤ b_fn ℓ C_net_nat C_M_nat d L := by
  unfold b_fn; omega

lemma B_prec_fn_pos (ℓ C_net_nat C_M_nat d L : ℕ) : 1 ≤ B_prec_fn ℓ C_net_nat C_M_nat d L := by
  unfold B_prec_fn; omega

lemma b_fn_le_B_prec_fn (ℓ C_net_nat C_M_nat d L : ℕ) :
    b_fn ℓ C_net_nat C_M_nat d L ≤ B_prec_fn ℓ C_net_nat C_M_nat d L := by
  unfold B_prec_fn; omega

lemma sampleCoord_fn_bitBounded (ℓ C_net_nat C_M_nat d L : ℕ)
    (bits : Fin (b_fn ℓ C_net_nat C_M_nat d L) → Bool) :
    UL.RatCoordBitBounded (B_prec_fn ℓ C_net_nat C_M_nat d L)
      (sampleCoord1D (b_fn ℓ C_net_nat C_M_nat d L) (T_fn ℓ C_net_nat C_M_nat d L) bits) := by
  apply sampleCoord1D_bitBounded _ bits
  unfold B_prec_fn
  omega

lemma sampleCoord_fn_approx_on_box {ℓ C_net_nat C_M_nat d L : ℕ}
    (hb : 1 ≤ b_fn ℓ C_net_nat C_M_nat d L)
    {z : ℝ} (hz : |z| ≤ (T_fn ℓ C_net_nat C_M_nat d L : ℝ)) :
    |((sampleCoord1D (b_fn ℓ C_net_nat C_M_nat d L) (T_fn ℓ C_net_nat C_M_nat d L)
        (encode1D (b_fn ℓ C_net_nat C_M_nat d L) hb z) : ℚ) : ℝ) - z| ≤
      (2 : ℝ) ^ (-((p_coord_fn ℓ C_net_nat C_M_nat d L + 1 : ℕ) : ℤ)) :=
  sampleCoord1D_approx_on_box
    (T := T_fn ℓ C_net_nat C_M_nat d L) (p_coord := p_coord_fn ℓ C_net_nat C_M_nat d L) hz

lemma two_mul_le_add_two_sq (K : ℕ) : 2 * K ≤ (K + 2) ^ 2 := by
  calc 2 * K ≤ K * K + 4 * K + 4 := by omega
    _ = (K + 2) ^ 2 := by ring

lemma part4_L_and_Q_bounds
    {C_net : ℝ} {C_net_nat d m Q_len L_log : ℕ}
    (hd : 1 ≤ d) (hm_pos : 1 ≤ m)
    (hCnet_le : C_net ≤ (C_net_nat : ℝ))
    {η ε₀ : ℝ} (hη_pos : 0 < η) (hη_le : η ≤ 1) (hε₀_pos : 0 < ε₀) (hε₀_lt : ε₀ < 1)
    (hQ_len : (Q_len : ℝ) ≤ Real.exp (C_net * (d : ℝ) * Real.log (2 * (d : ℝ) / η)))
    (hL_eq : L_log = Nat.ceil (Real.log (2 * (m : ℝ) / ε₀) + Real.log (2 / η))) :
    1 ≤ L_log ∧
    (m : ℝ) ≤ (2 : ℝ) ^ (2 * L_log) ∧
    Real.log (m : ℝ) ≤ (L_log : ℝ) ∧
    4 / ε₀ ≤ (2 : ℝ) ^ (2 * L_log + 1) ∧
    (Q_len : ℝ) ≤ (2 : ℝ) ^ (2 * (C_net_nat * d * (d + L_log))) ∧
    (m : ℝ) * (Q_len : ℝ) * (1 / 10 : ℝ) ^ (R_fn C_net_nat d L_log) ≤ ε₀ / 2 := by
  have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm_pos
  have hm_pos_r : (0 : ℝ) < (m : ℝ) := by positivity
  have hd_ge1 : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  have hA1_gt1 : 1 < 2 * (m : ℝ) / ε₀ := by
    rw [one_lt_div hε₀_pos]; linarith
  have hA1_pos : 0 < Real.log (2 * (m : ℝ) / ε₀) := Real.log_pos hA1_gt1
  have hA2_gt1 : 1 < 2 / η := by
    rw [one_lt_div hη_pos]; linarith
  have hA2_pos : 0 < Real.log (2 / η) := Real.log_pos hA2_gt1
  have hL_pos : 1 ≤ L_log := by
    rw [hL_eq]; exact Nat.ceil_pos.mpr (by linarith)
  have hL_ge_sum : Real.log (2 * (m : ℝ) / ε₀) + Real.log (2 / η) ≤ (L_log : ℝ) := by
    rw [hL_eq]; exact Nat.le_ceil _
  have hA1_le_L : Real.log (2 * (m : ℝ) / ε₀) ≤ (L_log : ℝ) := by linarith
  have hA2_le_L : Real.log (2 / η) ≤ (L_log : ℝ) := by linarith
  have h2m_div_le_exp : 2 * (m : ℝ) / ε₀ ≤ Real.exp (L_log : ℝ) := by
    rw [← Real.exp_log (by positivity : 0 < 2 * (m : ℝ) / ε₀)]
    exact Real.exp_le_exp.mpr hA1_le_L
  have hm_le_eps_exp : (m : ℝ) ≤ (ε₀ / 2) * Real.exp (L_log : ℝ) := by
    have hmul := mul_le_mul_of_nonneg_left h2m_div_le_exp (by positivity : 0 ≤ ε₀ / 2)
    have hsimp : (ε₀ / 2) * (2 * (m : ℝ) / ε₀) = (m : ℝ) := by field_simp
    rwa [hsimp] at hmul
  have hm_2 : (m : ℝ) ≤ (2 : ℝ) ^ (2 * L_log) := by
    calc (m : ℝ)
        ≤ 2 * (m : ℝ) / ε₀ := by
          rw [le_div_iff₀ hε₀_pos]
          have : (m : ℝ) * ε₀ ≤ (m : ℝ) * 1 :=
            mul_le_mul_of_nonneg_left hε₀_lt.le hm_pos_r.le
          linarith
      _ ≤ Real.exp (L_log : ℝ) := h2m_div_le_exp
      _ ≤ (2 : ℝ) ^ (2 * L_log) := UL.Proof_lem_6_3.exp_le_two_pow_two_mul L_log le_rfl
  have hlog_m_le_L : Real.log (m : ℝ) ≤ (L_log : ℝ) := by
    have hm_le_exp : (m : ℝ) ≤ Real.exp (L_log : ℝ) := by
      have : (ε₀ / 2) * Real.exp (L_log : ℝ) ≤ 1 * Real.exp (L_log : ℝ) :=
        mul_le_mul_of_nonneg_right (by linarith) (Real.exp_pos _).le
      linarith
    calc Real.log (m : ℝ)
        ≤ Real.log (Real.exp (L_log : ℝ)) := Real.log_le_log hm_pos_r hm_le_exp
      _ = (L_log : ℝ) := Real.log_exp (L_log : ℝ)
  have h2_div_eps_le : 2 / ε₀ ≤ (2 : ℝ) ^ (2 * L_log) := by
    calc 2 / ε₀ ≤ 2 * (m : ℝ) / ε₀ := div_le_div_of_nonneg_right (by linarith) hε₀_pos.le
      _ ≤ Real.exp (L_log : ℝ) := h2m_div_le_exp
      _ ≤ (2 : ℝ) ^ (2 * L_log) := UL.Proof_lem_6_3.exp_le_two_pow_two_mul L_log le_rfl
  have h4_div_eps_le : 4 / ε₀ ≤ (2 : ℝ) ^ (2 * L_log + 1) := by
    calc 4 / ε₀ = (2 / ε₀) * 2 := by ring
      _ ≤ (2 : ℝ) ^ (2 * L_log) * 2 := mul_le_mul_of_nonneg_right h2_div_eps_le (by norm_num)
      _ = (2 : ℝ) ^ (2 * L_log + 1) := by rw [pow_succ]
  have hlog_2d_eta : Real.log (2 * (d : ℝ) / η) ≤ ((d + L_log : ℕ) : ℝ) := by
    have heq : 2 * (d : ℝ) / η = (d : ℝ) * (2 / η) := by ring
    rw [heq, Real.log_mul (by positivity) (by positivity)]
    have hlog_d : Real.log (d : ℝ) ≤ (d : ℝ) := by
      calc Real.log (d : ℝ)
          ≤ Real.log (Real.exp (d : ℝ)) :=
            Real.log_le_log (by positivity) (by linarith [Real.add_one_le_exp (d : ℝ)])
        _ = (d : ℝ) := Real.log_exp (d : ℝ)
    push_cast
    linarith
  have hlog_2d_nonneg : 0 ≤ Real.log (2 * (d : ℝ) / η) := by
    apply Real.log_nonneg
    rw [le_div_iff₀ hη_pos]
    linarith
  have hQ_exp : (Q_len : ℝ) ≤ Real.exp (((C_net_nat * d * (d + L_log) : ℕ) : ℝ)) := by
    refine hQ_len.trans (Real.exp_le_exp.mpr ?_)
    calc C_net * (d : ℝ) * Real.log (2 * (d : ℝ) / η)
        ≤ (C_net_nat : ℝ) * (d : ℝ) * ((d + L_log : ℕ) : ℝ) := by
          apply mul_le_mul
          · exact mul_le_mul_of_nonneg_right hCnet_le (by positivity)
          · exact hlog_2d_eta
          · exact hlog_2d_nonneg
          · positivity
      _ = ((C_net_nat * d * (d + L_log) : ℕ) : ℝ) := by push_cast; ring
  have hQ_pow2 : (Q_len : ℝ) ≤ (2 : ℝ) ^ (2 * (C_net_nat * d * (d + L_log))) :=
    hQ_exp.trans (UL.Proof_lem_6_3.exp_le_two_pow_two_mul _ le_rfl)
  have h10R_le : (m : ℝ) * (Q_len : ℝ) * (1 / 10 : ℝ) ^ (R_fn C_net_nat d L_log) ≤ ε₀ / 2 := by
    have h10_exp : (1 / 10 : ℝ) ≤ Real.exp (-1) := by
      have hmul : Real.exp (-1) * Real.exp 1 = 1 := by
        rw [← Real.exp_add, neg_add_cancel, Real.exp_zero]
      have hle : Real.exp (-1) * Real.exp 1 ≤ Real.exp (-1) * 10 :=
        mul_le_mul_of_nonneg_left (by linarith [UL.Proof_lem_6_3.exp_one_le_four]) (Real.exp_pos (-1)).le
      rw [div_le_iff₀ (by norm_num : (0 : ℝ) < 10)]
      linarith
    have hpow_R : (1 / 10 : ℝ) ^ (R_fn C_net_nat d L_log) ≤
        Real.exp (-((R_fn C_net_nat d L_log : ℕ) : ℝ)) := by
      calc (1 / 10 : ℝ) ^ (R_fn C_net_nat d L_log)
          ≤ (Real.exp (-1)) ^ (R_fn C_net_nat d L_log) :=
            pow_le_pow_left₀ (by norm_num) h10_exp _
        _ = Real.exp (-((R_fn C_net_nat d L_log : ℕ) : ℝ)) := by
            rw [← Real.exp_nat_mul]; congr 1; ring
    calc (m : ℝ) * (Q_len : ℝ) * (1 / 10 : ℝ) ^ (R_fn C_net_nat d L_log)
        ≤ ((ε₀ / 2) * Real.exp (L_log : ℝ)) *
            Real.exp (((C_net_nat * d * (d + L_log) : ℕ) : ℝ)) *
            Real.exp (-((R_fn C_net_nat d L_log : ℕ) : ℝ)) := by
          apply mul_le_mul
          · exact mul_le_mul hm_le_eps_exp hQ_exp (Nat.cast_nonneg _) (by positivity)
          · exact hpow_R
          · positivity
          · positivity
      _ = (ε₀ / 2) * (Real.exp (L_log : ℝ) *
            (Real.exp (((C_net_nat * d * (d + L_log) : ℕ) : ℝ)) *
              Real.exp (-((R_fn C_net_nat d L_log : ℕ) : ℝ)))) := by ring
      _ = (ε₀ / 2) *
            Real.exp ((L_log : ℝ) + ((C_net_nat * d * (d + L_log) : ℕ) : ℝ) +
              -((R_fn C_net_nat d L_log : ℕ) : ℝ)) := by
          rw [← Real.exp_add, ← Real.exp_add, add_assoc]
      _ ≤ (ε₀ / 2) * 1 := by
          apply mul_le_mul_of_nonneg_left _ (by positivity)
          apply Real.exp_le_one_iff.mpr
          unfold R_fn
          push_cast
          linarith
      _ = ε₀ / 2 := mul_one _
  exact ⟨hL_pos, hm_2, hlog_m_le_L, h4_div_eps_le, hQ_pow2, h10R_le⟩

noncomputable def t_raw_of (ℓ m : ℕ) : ℝ :=
  max 1 (Real.sqrt (2 * Real.log (m : ℝ) / (ℓ : ℝ)))

noncomputable def τ_d_of (ℓ m L_log : ℕ) : ℚ :=
  (Nat.ceil (t_raw_of ℓ m * ((ℓ * (L_log + 1) : ℕ) : ℝ)) : ℚ) / ((ℓ * (L_log + 1) : ℕ) : ℚ)

lemma part4_threshold_bounds
    {ℓ C_net_nat C_M_nat d m L_log : ℕ}
    (hℓ : 1 ≤ ℓ) (hm_pos : 1 ≤ m)
    (hlog_m_le_L : Real.log (m : ℝ) ≤ (L_log : ℝ)) :
    1 ≤ ((τ_d_of ℓ m L_log : ℚ) : ℝ) ∧
    ((τ_d_of ℓ m L_log : ℚ) : ℝ) ≤ ((L_log + 2 : ℕ) : ℝ) ∧
    (m : ℝ) ≤ Real.exp ((ℓ : ℝ) * ((τ_d_of ℓ m L_log : ℚ) : ℝ) ^ 2 / 2) ∧
    Real.exp ((ℓ : ℝ) * ((τ_d_of ℓ m L_log : ℚ) : ℝ) ^ 2 / 2) ≤ S_exp_val ℓ * (m : ℝ) ∧
    UL.RatCoordBitBounded (B_prec_fn ℓ C_net_nat C_M_nat d L_log) (τ_d_of ℓ m L_log) := by
  have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm_pos
  have hm_pos_r : (0 : ℝ) < (m : ℝ) := by positivity
  have hℓ_ge1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
  have hℓ_pos : (0 : ℝ) < (ℓ : ℝ) := by positivity
  have hlog_m_nonneg : 0 ≤ Real.log (m : ℝ) := Real.log_nonneg hm_ge1
  set D_step : ℕ := ℓ * (L_log + 1) with hD_def
  have hD_step_pos : 1 ≤ D_step := Nat.mul_pos hℓ (by omega)
  have hD_step_pos_r : (0 : ℝ) < (D_step : ℝ) := by exact_mod_cast hD_step_pos
  set t_raw : ℝ := t_raw_of ℓ m with htr_def
  set num_td : ℕ := Nat.ceil (t_raw * (D_step : ℝ)) with hnum_def
  set t_ideal : ℝ := ((τ_d_of ℓ m L_log : ℚ) : ℝ) with hti_def
  have ht_ideal_eq : t_ideal = (num_td : ℝ) / (D_step : ℝ) := by
    rw [hti_def, τ_d_of, ← hD_def, ← htr_def, ← hnum_def]
    push_cast
    rfl
  have ht_raw_ge1 : 1 ≤ t_raw := le_max_left 1 _
  have ht_raw_le_ideal : t_raw ≤ t_ideal := by
    rw [ht_ideal_eq, le_div_iff₀ hD_step_pos_r]
    exact Nat.le_ceil _
  have ht_ideal_ge1 : 1 ≤ t_ideal := ht_raw_ge1.trans ht_raw_le_ideal
  have ht_ideal_le_step : t_ideal ≤ t_raw + 1 / (D_step : ℝ) := by
    rw [ht_ideal_eq, add_div', div_le_div_iff_of_pos_right hD_step_pos_r]
    · exact (Nat.ceil_lt_add_one (mul_nonneg (by positivity) hD_step_pos_r.le)).le
    · exact hD_step_pos_r.ne'
  have ht_raw_le_Lp1 : t_raw ≤ ((L_log + 1 : ℕ) : ℝ) := by
    rw [htr_def, t_raw_of]
    refine max_le (by push_cast; linarith [Nat.cast_nonneg (α := ℝ) L_log]) ?_
    have hdiv_le : 2 * Real.log (m : ℝ) / (ℓ : ℝ) ≤ ((L_log + 1 : ℕ) : ℝ) ^ 2 := by
      have h1 : 2 * Real.log (m : ℝ) / (ℓ : ℝ) ≤ 2 * (L_log : ℝ) := by
        rw [div_le_iff₀ hℓ_pos]
        calc 2 * Real.log (m : ℝ)
            ≤ 2 * (L_log : ℝ) := by linarith
          _ = (2 * (L_log : ℝ)) * 1 := (mul_one _).symm
          _ ≤ (2 * (L_log : ℝ)) * (ℓ : ℝ) :=
              mul_le_mul_of_nonneg_left hℓ_ge1 (by positivity)
      have h2 : 2 * (L_log : ℝ) ≤ ((L_log + 1 : ℕ) : ℝ) ^ 2 := by
        push_cast
        linarith [sq_nonneg (L_log : ℝ)]
      linarith
    calc Real.sqrt (2 * Real.log (m : ℝ) / (ℓ : ℝ))
        ≤ Real.sqrt (((L_log + 1 : ℕ) : ℝ) ^ 2) := Real.sqrt_le_sqrt hdiv_le
      _ = ((L_log + 1 : ℕ) : ℝ) := Real.sqrt_sq (by positivity)
  have ht_ideal_le_Lp2 : t_ideal ≤ ((L_log + 2 : ℕ) : ℝ) := by
    have hinv_le1 : 1 / (D_step : ℝ) ≤ 1 :=
      div_le_one_of_le₀ (by exact_mod_cast hD_step_pos) (by positivity)
    push_cast at ht_raw_le_Lp1 ⊢
    linarith
  have hm_le_exp_lt2 : (m : ℝ) ≤ Real.exp ((ℓ : ℝ) * t_ideal ^ 2 / 2) := by
    have hsq_ge : 2 * Real.log (m : ℝ) / (ℓ : ℝ) ≤ t_ideal ^ 2 := by
      have hsqrt_le : Real.sqrt (2 * Real.log (m : ℝ) / (ℓ : ℝ)) ≤ t_ideal :=
        (le_max_right 1 _).trans ht_raw_le_ideal
      have h0 : 0 ≤ 2 * Real.log (m : ℝ) / (ℓ : ℝ) := by positivity
      calc 2 * Real.log (m : ℝ) / (ℓ : ℝ)
          = (Real.sqrt (2 * Real.log (m : ℝ) / (ℓ : ℝ))) ^ 2 := (Real.sq_sqrt h0).symm
        _ ≤ t_ideal ^ 2 := pow_le_pow_left₀ (Real.sqrt_nonneg _) hsqrt_le 2
    have hlog_le : Real.log (m : ℝ) ≤ (ℓ : ℝ) * t_ideal ^ 2 / 2 := by
      have hmul := mul_le_mul_of_nonneg_left hsq_ge (by positivity : 0 ≤ (ℓ : ℝ) / 2)
      have hsimp : ((ℓ : ℝ) / 2) * (2 * Real.log (m : ℝ) / (ℓ : ℝ)) = Real.log (m : ℝ) := by
        field_simp
      have hrhs : ((ℓ : ℝ) / 2) * t_ideal ^ 2 = (ℓ : ℝ) * t_ideal ^ 2 / 2 := by ring
      rwa [hsimp, hrhs] at hmul
    rw [← Real.exp_log hm_pos_r]
    exact Real.exp_le_exp.mpr hlog_le
  have hexp_lt2_le_Sm : Real.exp ((ℓ : ℝ) * t_ideal ^ 2 / 2) ≤ S_exp_val ℓ * (m : ℝ) := by
    have hraw_sq : (ℓ : ℝ) * t_raw ^ 2 / 2 ≤ (ℓ : ℝ) + Real.log (m : ℝ) := by
      rw [htr_def, t_raw_of]
      rcases max_choice 1 (Real.sqrt (2 * Real.log (m : ℝ) / (ℓ : ℝ))) with htr | htr
      · rw [htr]; linarith
      · rw [htr, Real.sq_sqrt (by positivity)]
        have : (ℓ : ℝ) * (2 * Real.log (m : ℝ) / (ℓ : ℝ)) / 2 = Real.log (m : ℝ) := by
          field_simp
        linarith
    have hideal_sq : (ℓ : ℝ) * t_ideal ^ 2 / 2 ≤ ((ℓ + 2 : ℕ) : ℝ) + Real.log (m : ℝ) := by
      have hsq_le : t_ideal ^ 2 ≤ (t_raw + 1 / (D_step : ℝ)) ^ 2 :=
        pow_le_pow_left₀ (by positivity) ht_ideal_le_step 2
      have h1 : (ℓ : ℝ) * t_ideal ^ 2 / 2 ≤ (ℓ : ℝ) * (t_raw + 1 / (D_step : ℝ)) ^ 2 / 2 :=
        div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hsq_le hℓ_pos.le) (by norm_num)
      have hD_eq : (D_step : ℝ) = (ℓ : ℝ) * ((L_log + 1 : ℕ) : ℝ) := by
        rw [hD_def]; push_cast; ring
      have hLp1_pos : (0 : ℝ) < ((L_log + 1 : ℕ) : ℝ) := by positivity
      have hexpand : (ℓ : ℝ) * (t_raw + 1 / (D_step : ℝ)) ^ 2 / 2 =
          (ℓ : ℝ) * t_raw ^ 2 / 2 + t_raw / ((L_log + 1 : ℕ) : ℝ) +
            1 / (2 * (ℓ : ℝ) * ((L_log + 1 : ℕ) : ℝ) ^ 2) := by
        rw [hD_eq]
        field_simp
        ring
      have ht_div1 : t_raw / ((L_log + 1 : ℕ) : ℝ) ≤ 1 :=
        (div_le_one hLp1_pos).mpr ht_raw_le_Lp1
      have ht_div2 : 1 / (2 * (ℓ : ℝ) * ((L_log + 1 : ℕ) : ℝ) ^ 2) ≤ 1 := by
        apply div_le_one_of_le₀ _ (by positivity)
        have hLp1_ge1 : (1 : ℝ) ≤ ((L_log + 1 : ℕ) : ℝ) ^ 2 :=
          one_le_pow₀ (by exact_mod_cast (by omega : 1 ≤ L_log + 1))
        calc (1 : ℝ) ≤ 2 * 1 * 1 := by norm_num
          _ ≤ 2 * (ℓ : ℝ) * ((L_log + 1 : ℕ) : ℝ) ^ 2 := by gcongr
      push_cast
      linarith
    calc Real.exp ((ℓ : ℝ) * t_ideal ^ 2 / 2)
        ≤ Real.exp (((ℓ + 2 : ℕ) : ℝ) + Real.log (m : ℝ)) := Real.exp_le_exp.mpr hideal_sq
      _ = S_exp_val ℓ * (m : ℝ) := by
          rw [Real.exp_add, Real.exp_log hm_pos_r]; rfl
  have hτ_d_bits : UL.RatCoordBitBounded (B_prec_fn ℓ C_net_nat C_M_nat d L_log) (τ_d_of ℓ m L_log) := by
    have hnum_le : num_td ≤ (L_log + 1) * D_step := by
      rw [hnum_def]
      refine Nat.ceil_le.mpr ?_
      rw [Nat.cast_mul (L_log + 1) D_step]
      exact mul_le_mul_of_nonneg_right ht_raw_le_Lp1 hD_step_pos_r.le
    have h1 : L_log + 1 < 2 ^ (L_log + 1) := Nat.lt_two_pow_self
    have h2 : ℓ < 2 ^ ℓ := Nat.lt_two_pow_self
    have hprod_lt : (L_log + 1) * D_step < 2 ^ (B_prec_fn ℓ C_net_nat C_M_nat d L_log) := by
      calc (L_log + 1) * D_step
          = ℓ * (L_log + 1) * (L_log + 1) := by rw [hD_def]; ring
        _ < 2 ^ ℓ * 2 ^ (L_log + 1) * 2 ^ (L_log + 1) :=
            Nat.mul_lt_mul_of_lt_of_lt (Nat.mul_lt_mul_of_lt_of_lt h2 h1) h1
        _ = 2 ^ (ℓ + 2 * L_log + 2) := by rw [← pow_add, ← pow_add]; congr 1; omega
        _ ≤ 2 ^ (B_prec_fn ℓ C_net_nat C_M_nat d L_log) :=
            Nat.pow_le_pow_right (by decide) (by unfold B_prec_fn; omega)
    have hD_le_num : D_step ≤ num_td := by
      have hmul : (1 : ℝ) * (D_step : ℝ) ≤ t_raw * (D_step : ℝ) :=
        mul_le_mul_of_nonneg_right ht_raw_ge1 hD_step_pos_r.le
      have hle : (D_step : ℝ) ≤ (num_td : ℝ) :=
        (by linarith : (D_step : ℝ) ≤ t_raw * (D_step : ℝ)).trans (Nat.le_ceil _)
      exact_mod_cast hle
    have hτ_eq : τ_d_of ℓ m L_log = ((num_td : ℤ) : ℚ) / (D_step : ℚ) := by
      rw [τ_d_of, ← hD_def, ← htr_def, ← hnum_def]; simp
    rw [hτ_eq]
    exact ratCoordBitBounded_of_div
      (B_prec_fn_pos ℓ C_net_nat C_M_nat d L_log) hD_step_pos
      (lt_of_le_of_lt (hD_le_num.trans hnum_le) hprod_lt)
      (by simpa using lt_of_le_of_lt hnum_le hprod_lt)
  exact ⟨ht_ideal_ge1, ht_ideal_le_Lp2, hm_le_exp_lt2, hexp_lt2_le_Sm, hτ_d_bits⟩

noncomputable def M₀_of (C_M_nat : ℕ) (h x t_ideal : ℝ) : ℕ :=
  Nat.ceil ((C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2)) + 1

noncomputable def cap_u_of (ℓ M₀ : ℕ) (t_ideal : ℝ) : ℕ :=
  Nat.ceil (100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) + 1)) + 1

noncomputable def cap_q_of (ℓ M₀ : ℕ) (x t_ideal : ℝ) : ℕ :=
  Nat.ceil (100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) + 1)) + 1

noncomputable def τ_q_of (b : ℕ) (x t_ideal : ℝ) : ℚ :=
  (⌊x * t_ideal * ((2 ^ b : ℕ) : ℝ)⌋ : ℚ) / ((2 ^ b : ℕ) : ℚ)

lemma M₀_of_pos (C_M_nat : ℕ) (h x t_ideal : ℝ) : 1 ≤ M₀_of C_M_nat h x t_ideal := by
  unfold M₀_of; omega

lemma cap_u_of_pos (ℓ M₀ : ℕ) (t_ideal : ℝ) : 1 ≤ cap_u_of ℓ M₀ t_ideal := by
  unfold cap_u_of; omega

lemma cap_q_of_pos (ℓ M₀ : ℕ) (x t_ideal : ℝ) : 1 ≤ cap_q_of ℓ M₀ x t_ideal := by
  unfold cap_q_of; omega

lemma part4_prob_cap_reqs
    {ℓ C_M_nat m : ℕ} (hℓ : 1 ≤ ℓ) (hm_pos : 1 ≤ m)
    {c_h h x t_ideal p_u p_q p₁ p₂ : ℝ}
    (hc_h_pos : 0 < c_h)
    (hCM_ge : Real.log (100 * (ℓ : ℝ)) / c_h ≤ (C_M_nat : ℝ))
    (ht_ge1 : 1 ≤ t_ideal)
    (hm_le_exp_lt2 : (m : ℝ) ≤ Real.exp ((ℓ : ℝ) * t_ideal ^ 2 / 2))
    (hp_u_nn : 0 ≤ p_u) (hp_q_nn : 0 ≤ p_q) (hp₂_nn : 0 ≤ p₂)
    (hp_u : p_u ≤ Real.exp (-(t_ideal ^ 2 / 2)))
    (hp_q : p_q ≤ Real.exp (-(x ^ 2 * t_ideal ^ 2 / 2)))
    (hp₁ : c_h * t_ideal ^ (-2 : ℤ) * Real.exp (-(UL.I_h h x * t_ideal ^ 2 / 2)) ≤ p₁)
    (hp₂ : p₂ ≤ Real.exp (-((1 + x ^ 2) * t_ideal ^ 2 / 2))) :
    let M₀ := M₀_of C_M_nat h x t_ideal
    0 < p₁ ∧
    Real.log (100 * (ℓ : ℝ)) ≤ p₁ * (M₀ : ℝ) ∧
    100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1) ≤ (cap_u_of ℓ M₀ t_ideal : ℝ) ∧
    100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1) ≤ (cap_q_of ℓ M₀ x t_ideal : ℝ) ∧
    100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1) ≤ (cap_q_of ℓ M₀ x t_ideal : ℝ) := by
  intro M₀
  have hℓ_ge1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
  have hm_pos_r : (0 : ℝ) < (m : ℝ) := by exact_mod_cast hm_pos
  have hp₁_pos : 0 < p₁ := by
    have : 0 < c_h * t_ideal ^ (-2 : ℤ) * Real.exp (-(UL.I_h h x * t_ideal ^ 2 / 2)) := by
      positivity
    linarith
  have hp₁_M : Real.log (100 * (ℓ : ℝ)) ≤ p₁ * (M₀ : ℝ) := by
    set C_M0 : ℝ := Real.log (100 * (ℓ : ℝ)) / c_h
    have hM_ge : C_M0 * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) ≤ (M₀ : ℝ) := by
      calc C_M0 * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2)
          ≤ (C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) := by
            apply mul_le_mul_of_nonneg_right
            · exact mul_le_mul_of_nonneg_right hCM_ge (sq_nonneg _)
            · exact (Real.exp_pos _).le
        _ ≤ (Nat.ceil ((C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2)) : ℝ) :=
            Nat.le_ceil _
        _ ≤ (M₀ : ℝ) := by dsimp [M₀, M₀_of]; push_cast; linarith
    have hlog_pos : 0 < Real.log (100 * (ℓ : ℝ)) := Real.log_pos (by linarith)
    have hCM0_nn : 0 ≤ C_M0 := div_nonneg hlog_pos.le hc_h_pos.le
    have hprod_eq :
        (c_h * t_ideal ^ (-2 : ℤ) * Real.exp (-(UL.I_h h x * t_ideal ^ 2 / 2))) *
          (C_M0 * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2)) =
        Real.log (100 * (ℓ : ℝ)) := by
      dsimp [C_M0]
      have ht_ne : t_ideal ≠ 0 := by linarith
      have hc_ne : c_h ≠ 0 := hc_h_pos.ne'
      rw [show t_ideal ^ (-2 : ℤ) = (t_ideal ^ 2)⁻¹ by rw [zpow_neg, zpow_two, ← sq]]
      have hexp_mul : Real.exp (-(UL.I_h h x * t_ideal ^ 2 / 2)) *
          Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) = 1 := by
        rw [← Real.exp_add, neg_add_cancel, Real.exp_zero]
      calc (c_h * (t_ideal ^ 2)⁻¹ * Real.exp (-(UL.I_h h x * t_ideal ^ 2 / 2))) *
            (Real.log (100 * (ℓ : ℝ)) / c_h * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2))
          = (c_h * (Real.log (100 * (ℓ : ℝ)) / c_h)) * ((t_ideal ^ 2)⁻¹ * t_ideal ^ 2) *
              (Real.exp (-(UL.I_h h x * t_ideal ^ 2 / 2)) *
                Real.exp (UL.I_h h x * t_ideal ^ 2 / 2)) := by ring
        _ = Real.log (100 * (ℓ : ℝ)) * 1 * 1 := by
            rw [mul_div_cancel₀ _ hc_ne, inv_mul_cancel₀ (pow_ne_zero 2 ht_ne), hexp_mul]
        _ = Real.log (100 * (ℓ : ℝ)) := by ring
    rw [← hprod_eq]
    exact mul_le_mul hp₁ hM_ge (by positivity) hp₁_pos.le
  have hCap_u : 100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1) ≤ (cap_u_of ℓ M₀ t_ideal : ℝ) := by
    have hpu_pow : p_u ^ ℓ ≤ Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) := by
      calc p_u ^ ℓ ≤ (Real.exp (-(t_ideal ^ 2 / 2))) ^ ℓ := pow_le_pow_left₀ hp_u_nn hp_u ℓ
        _ = Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) := by
            rw [← Real.exp_nat_mul]; congr 1; ring
    calc 100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1)
        ≤ 100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) + 1) := by gcongr
      _ ≤ (Nat.ceil (100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) + 1)) : ℝ) :=
          Nat.le_ceil _
      _ ≤ (cap_u_of ℓ M₀ t_ideal : ℝ) := by unfold cap_u_of; push_cast; linarith
  have hCap_q : 100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1) ≤ (cap_q_of ℓ M₀ x t_ideal : ℝ) := by
    have hpq_pow : p_q ^ ℓ ≤ Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) := by
      calc p_q ^ ℓ ≤ (Real.exp (-(x ^ 2 * t_ideal ^ 2 / 2))) ^ ℓ := pow_le_pow_left₀ hp_q_nn hp_q ℓ
        _ = Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) := by
            rw [← Real.exp_nat_mul]; congr 1; ring
    calc 100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1)
        ≤ 100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) + 1) := by gcongr
      _ ≤ (Nat.ceil (100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) + 1)) : ℝ) :=
          Nat.le_ceil _
      _ ≤ (cap_q_of ℓ M₀ x t_ideal : ℝ) := by unfold cap_q_of; push_cast; linarith
  have hCap_bad : 100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1) ≤ (cap_q_of ℓ M₀ x t_ideal : ℝ) := by
    have hp2_pow : (m : ℝ) * p₂ ^ ℓ ≤ Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) := by
      have hp2_l : p₂ ^ ℓ ≤ Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) *
          Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) := by
        calc p₂ ^ ℓ ≤ (Real.exp (-((1 + x ^ 2) * t_ideal ^ 2 / 2))) ^ ℓ :=
              pow_le_pow_left₀ hp₂_nn hp₂ ℓ
          _ = Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2) + -((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) := by
              rw [← Real.exp_nat_mul]; congr 1; ring
          _ = Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) *
                Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) := Real.exp_add _ _
      have hm_exp_le1 : (m : ℝ) * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) ≤ 1 := by
        calc (m : ℝ) * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2))
            ≤ Real.exp ((ℓ : ℝ) * t_ideal ^ 2 / 2) * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) :=
              mul_le_mul_of_nonneg_right hm_le_exp_lt2 (Real.exp_pos _).le
          _ = 1 := by rw [← Real.exp_add, add_neg_cancel, Real.exp_zero]
      calc (m : ℝ) * p₂ ^ ℓ
          ≤ (m : ℝ) * (Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) *
              Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2))) :=
            mul_le_mul_of_nonneg_left hp2_l hm_pos_r.le
        _ = ((m : ℝ) * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2))) *
              Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) := by ring
        _ ≤ 1 * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) :=
            mul_le_mul_of_nonneg_right hm_exp_le1 (Real.exp_pos _).le
        _ = Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) := one_mul _
    calc 100 * ((m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1)
        = 100 * ((M₀ : ℝ) ^ ℓ * ((m : ℝ) * p₂ ^ ℓ) + 1) := by ring
      _ ≤ 100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) + 1) := by gcongr
      _ ≤ (Nat.ceil (100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) + 1)) : ℝ) :=
          Nat.le_ceil _
      _ ≤ (cap_q_of ℓ M₀ x t_ideal : ℝ) := by unfold cap_q_of; push_cast; linarith
  exact ⟨hp₁_pos, hp₁_M, hCap_u, hCap_q, hCap_bad⟩

lemma part4_size_and_M0_bounds
    {ℓ C_net_nat C_M_nat d m L_log : ℕ} (hℓ : 1 ≤ ℓ) (hm_pos : 1 ≤ m)
    {h x t_ideal : ℝ} (hh_pos : 0 < h) (hh_lt1 : h < 1) (hx_ge : h ≤ x) (hx_le : x ≤ 1)
    (ht_ge1 : 1 ≤ t_ideal) (ht_le_Lp2 : t_ideal ≤ ((L_log + 2 : ℕ) : ℝ))
    (hexp_lt2_le_Sm : Real.exp ((ℓ : ℝ) * t_ideal ^ 2 / 2) ≤ S_exp_val ℓ * (m : ℝ)) :
    let M₀ := M₀_of C_M_nat h x t_ideal
    (M₀ : ℝ) ≤ (2 : ℝ) ^ (E_M_fn C_M_nat L_log) ∧
    ((R_fn C_net_nat d L_log * ℓ * M₀ : ℕ) : ℝ) ≤
      (m : ℝ) ^ (UL.I_h h x / (ℓ : ℝ)) * K_I_fn ℓ C_net_nat C_M_nat d L_log ∧
    (cap_u_of ℓ M₀ t_ideal : ℝ) ≤
      (m : ℝ) ^ (UL.u_search h x) * K_u_fn ℓ C_M_nat L_log ∧
    (cap_q_of ℓ M₀ x t_ideal : ℝ) ≤
      (m : ℝ) ^ (UL.q_search h x) * K_q_fn ℓ C_M_nat L_log := by
  intro M₀
  have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm_pos
  have hℓ_ge1 : (1 : ℝ) ≤ (ℓ : ℝ) := by exact_mod_cast hℓ
  have hℓ_pos : (0 : ℝ) < (ℓ : ℝ) := by positivity
  rcases UL.Proof_lem_6_3.I_h_bounds hh_pos hh_lt1 hx_ge hx_le
    with ⟨hI_ge1, hI_le2, hu_ge0, hu_le1, hq_ge0, hq_le1pu⟩
  have hq_le2 : UL.q_search h x ≤ 2 := by linarith
  have hS_ge1 : 1 ≤ S_exp_val ℓ := Real.one_le_exp (by positivity)
  have hM_ceil_ub : (M₀ : ℝ) ≤
      (C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) + 2 := by
    have : M₀ = Nat.ceil ((C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2)) + 1 := rfl
    rw [this]; push_cast
    have h0 : 0 ≤ (C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) := by
      positivity
    linarith [(Nat.ceil_lt_add_one h0).le]
  have ht2_le : t_ideal ^ 2 ≤ ((L_log : ℝ) + 2) ^ 2 := by
    have : t_ideal ≤ (L_log : ℝ) + 2 := by push_cast at ht_le_Lp2; exact ht_le_Lp2
    exact pow_le_pow_left₀ (by positivity) this 2
  have hM₀_le_2EM : (M₀ : ℝ) ≤ (2 : ℝ) ^ (E_M_fn C_M_nat L_log) := by
    have ht2_nat : t_ideal ^ 2 ≤ (((L_log + 2) ^ 2 : ℕ) : ℝ) := by
      calc t_ideal ^ 2 ≤ (((L_log + 2 : ℕ) : ℝ)) ^ 2 :=
            pow_le_pow_left₀ (by positivity) ht_le_Lp2 2
        _ = (((L_log + 2) ^ 2 : ℕ) : ℝ) := by push_cast; ring
    have hIt2_le : UL.I_h h x * t_ideal ^ 2 / 2 ≤ (((L_log + 2) ^ 2 : ℕ) : ℝ) := by
      have hmul := mul_le_mul hI_le2 ht2_nat (sq_nonneg _) (by norm_num)
      linarith
    have hexp_pow : Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) ≤ (2 : ℝ) ^ (2 * (L_log + 2) ^ 2) :=
      UL.Proof_lem_6_3.exp_le_two_pow_two_mul ((L_log + 2) ^ 2) hIt2_le
    have hCM_pow : (C_M_nat : ℝ) ≤ (2 : ℝ) ^ C_M_nat :=
      UL.Proof_lem_6_3.nat_cast_le_two_pow C_M_nat
    have ht2_pow : t_ideal ^ 2 ≤ (2 : ℝ) ^ ((L_log + 2) ^ 2) :=
      ht2_nat.trans (UL.Proof_lem_6_3.nat_cast_le_two_pow ((L_log + 2) ^ 2))
    have hprod_pow : (C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) ≤
        (2 : ℝ) ^ (C_M_nat + 3 * (L_log + 2) ^ 2) := by
      calc (C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2)
          ≤ (2 : ℝ) ^ C_M_nat * (2 : ℝ) ^ ((L_log + 2) ^ 2) * (2 : ℝ) ^ (2 * (L_log + 2) ^ 2) := by
            apply mul_le_mul
            · exact mul_le_mul hCM_pow ht2_pow (sq_nonneg _) (by positivity)
            · exact hexp_pow
            · exact (Real.exp_pos _).le
            · positivity
        _ = (2 : ℝ) ^ (C_M_nat + 3 * (L_log + 2) ^ 2) := by
            rw [← pow_add, ← pow_add]; congr 1; ring
    have hge1 : (1 : ℝ) ≤ (2 : ℝ) ^ (C_M_nat + 3 * (L_log + 2) ^ 2) :=
      one_le_pow₀ (by norm_num)
    calc (M₀ : ℝ)
        ≤ (2 : ℝ) ^ (C_M_nat + 3 * (L_log + 2) ^ 2) + 2 := by linarith
      _ ≤ (2 : ℝ) ^ (C_M_nat + 3 * (L_log + 2) ^ 2) * 4 := by linarith
      _ = (2 : ℝ) ^ (E_M_fn C_M_nat L_log) := by
          unfold E_M_fn; rw [pow_add]; ring
  have hexp_I_le : Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) ≤
      (S_exp_val ℓ) ^ 2 * (m : ℝ) ^ (UL.I_h h x / (ℓ : ℝ)) := by
    have heq : UL.I_h h x * t_ideal ^ 2 / 2 =
        (UL.I_h h x / (ℓ : ℝ)) * ((ℓ : ℝ) * t_ideal ^ 2 / 2) := by field_simp
    have hαk : UL.I_h h x / (ℓ : ℝ) ≤ ((2 : ℕ) : ℝ) := by
      rw [div_le_iff₀ hℓ_pos]
      push_cast
      calc UL.I_h h x ≤ 2 := hI_le2
        _ = 2 * 1 := (mul_one 2).symm
        _ ≤ 2 * (ℓ : ℝ) := mul_le_mul_of_nonneg_left hℓ_ge1 (by norm_num)
    rw [heq]
    exact exp_mul_le_rpow hS_ge1 hm_ge1 (div_nonneg (by linarith) hℓ_pos.le) hαk hexp_lt2_le_Sm
  have hM₀_ub_exp : (M₀ : ℝ) ≤
      ((C_M_nat : ℝ) * ((L_log : ℝ) + 2) ^ 2 + 2) * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) := by
    have hexp_ge1 : 1 ≤ Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) :=
      Real.one_le_exp (by positivity)
    calc (M₀ : ℝ)
        ≤ (C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) + 2 := hM_ceil_ub
      _ ≤ (C_M_nat : ℝ) * ((L_log : ℝ) + 2) ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) +
            2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) := by
          gcongr
          linarith
      _ = ((C_M_nat : ℝ) * ((L_log : ℝ) + 2) ^ 2 + 2) *
            Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) := by ring
  have hM₀_ub_I : (M₀ : ℝ) ≤
      ((C_M_nat : ℝ) * ((L_log : ℝ) + 2) ^ 2 * (S_exp_val ℓ) ^ 2 + 2) *
        (m : ℝ) ^ (UL.I_h h x / (ℓ : ℝ)) := by
    have hm_rpow_ge1 : 1 ≤ (m : ℝ) ^ (UL.I_h h x / (ℓ : ℝ)) :=
      Real.one_le_rpow hm_ge1 (div_nonneg (by linarith) hℓ_pos.le)
    calc (M₀ : ℝ)
        ≤ (C_M_nat : ℝ) * t_ideal ^ 2 * Real.exp (UL.I_h h x * t_ideal ^ 2 / 2) + 2 := hM_ceil_ub
      _ ≤ (C_M_nat : ℝ) * ((L_log : ℝ) + 2) ^ 2 *
            ((S_exp_val ℓ) ^ 2 * (m : ℝ) ^ (UL.I_h h x / (ℓ : ℝ))) +
          2 * (m : ℝ) ^ (UL.I_h h x / (ℓ : ℝ)) := by
          apply add_le_add
          · exact mul_le_mul
              (mul_le_mul_of_nonneg_left ht2_le (Nat.cast_nonneg _))
              hexp_I_le (Real.exp_pos _).le (by positivity)
          · linarith
      _ = ((C_M_nat : ℝ) * ((L_log : ℝ) + 2) ^ 2 * (S_exp_val ℓ) ^ 2 + 2) *
            (m : ℝ) ^ (UL.I_h h x / (ℓ : ℝ)) := by ring
  have hRlM₀_le_KI : ((R_fn C_net_nat d L_log * ℓ * M₀ : ℕ) : ℝ) ≤
      (m : ℝ) ^ (UL.I_h h x / (ℓ : ℝ)) * K_I_fn ℓ C_net_nat C_M_nat d L_log := by
    have hmul := mul_le_mul_of_nonneg_left hM₀_ub_I
      (by positivity : (0 : ℝ) ≤ ((R_fn C_net_nat d L_log * ℓ : ℕ) : ℝ))
    unfold K_I_fn
    push_cast at hmul ⊢
    linarith
  have hM₀_pow_ub : (M₀ : ℝ) ^ ℓ ≤
      P_M_fn ℓ C_M_nat L_log * Real.exp ((ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2) := by
    calc (M₀ : ℝ) ^ ℓ
        ≤ (((C_M_nat : ℝ) * ((L_log : ℝ) + 2) ^ 2 + 2) *
            Real.exp (UL.I_h h x * t_ideal ^ 2 / 2)) ^ ℓ :=
          pow_le_pow_left₀ (Nat.cast_nonneg _) hM₀_ub_exp ℓ
      _ = P_M_fn ℓ C_M_nat L_log * (Real.exp (UL.I_h h x * t_ideal ^ 2 / 2)) ^ ℓ := by
          rw [mul_pow]; rfl
      _ = P_M_fn ℓ C_M_nat L_log * Real.exp ((ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2) := by
          rw [← Real.exp_nat_mul]; congr 2; ring
  have hPM_nn : 0 ≤ P_M_fn ℓ C_M_nat L_log := by unfold P_M_fn; positivity
  have hcap_u_le_Ku : (cap_u_of ℓ M₀ t_ideal : ℝ) ≤
      (m : ℝ) ^ (UL.u_search h x) * K_u_fn ℓ C_M_nat L_log := by
    have hceil_ub : (cap_u_of ℓ M₀ t_ideal : ℝ) ≤
        100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) + 1) + 2 := by
      unfold cap_u_of; push_cast
      linarith [(Nat.ceil_lt_add_one (by positivity :
        0 ≤ 100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) + 1))).le]
    have hexp_u : Real.exp ((ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2) *
        Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) ≤
        S_exp_val ℓ * (m : ℝ) ^ (UL.u_search h x) := by
      rw [← Real.exp_add]
      have heq : (ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2 + -((ℓ : ℝ) * t_ideal ^ 2 / 2) =
          UL.u_search h x * ((ℓ : ℝ) * t_ideal ^ 2 / 2) := by
        unfold UL.u_search; ring
      rw [heq]
      simpa using exp_mul_le_rpow (k := 1) hS_ge1 hm_ge1 hu_ge0 (by simpa using hu_le1) hexp_lt2_le_Sm
    have hprod_u : (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) ≤
        P_M_fn ℓ C_M_nat L_log * S_exp_val ℓ * (m : ℝ) ^ (UL.u_search h x) := by
      calc (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2))
          ≤ (P_M_fn ℓ C_M_nat L_log * Real.exp ((ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2)) *
              Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) :=
            mul_le_mul_of_nonneg_right hM₀_pow_ub (Real.exp_pos _).le
        _ = P_M_fn ℓ C_M_nat L_log *
              (Real.exp ((ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2) *
                Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2))) := by ring
        _ ≤ P_M_fn ℓ C_M_nat L_log * (S_exp_val ℓ * (m : ℝ) ^ (UL.u_search h x)) :=
            mul_le_mul_of_nonneg_left hexp_u hPM_nn
        _ = P_M_fn ℓ C_M_nat L_log * S_exp_val ℓ * (m : ℝ) ^ (UL.u_search h x) := by ring
    have hm_u_ge1 : 1 ≤ (m : ℝ) ^ (UL.u_search h x) := Real.one_le_rpow hm_ge1 hu_ge0
    unfold K_u_fn
    calc (cap_u_of ℓ M₀ t_ideal : ℝ)
        ≤ 100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * t_ideal ^ 2 / 2)) + 1) + 2 := hceil_ub
      _ ≤ 100 * (P_M_fn ℓ C_M_nat L_log * S_exp_val ℓ * (m : ℝ) ^ (UL.u_search h x) +
            (m : ℝ) ^ (UL.u_search h x)) + 2 * (m : ℝ) ^ (UL.u_search h x) := by linarith
      _ = (m : ℝ) ^ (UL.u_search h x) * (100 * (P_M_fn ℓ C_M_nat L_log * S_exp_val ℓ + 1) + 2) := by
          ring
  have hcap_q_le_Kq : (cap_q_of ℓ M₀ x t_ideal : ℝ) ≤
      (m : ℝ) ^ (UL.q_search h x) * K_q_fn ℓ C_M_nat L_log := by
    have hceil_ub : (cap_q_of ℓ M₀ x t_ideal : ℝ) ≤
        100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) + 1) + 2 := by
      unfold cap_q_of; push_cast
      linarith [(Nat.ceil_lt_add_one (by positivity :
        0 ≤ 100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) + 1))).le]
    have hexp_q : Real.exp ((ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2) *
        Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) ≤
        (S_exp_val ℓ) ^ 2 * (m : ℝ) ^ (UL.q_search h x) := by
      rw [← Real.exp_add]
      have heq : (ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2 + -((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2) =
          UL.q_search h x * ((ℓ : ℝ) * t_ideal ^ 2 / 2) := by
        unfold UL.q_search; ring
      rw [heq]
      exact exp_mul_le_rpow (k := 2) hS_ge1 hm_ge1 hq_ge0 (by simpa using hq_le2) hexp_lt2_le_Sm
    have hprod_q : (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) ≤
        P_M_fn ℓ C_M_nat L_log * (S_exp_val ℓ) ^ 2 * (m : ℝ) ^ (UL.q_search h x) := by
      calc (M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2))
          ≤ (P_M_fn ℓ C_M_nat L_log * Real.exp ((ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2)) *
              Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) :=
            mul_le_mul_of_nonneg_right hM₀_pow_ub (Real.exp_pos _).le
        _ = P_M_fn ℓ C_M_nat L_log *
              (Real.exp ((ℓ : ℝ) * UL.I_h h x * t_ideal ^ 2 / 2) *
                Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2))) := by ring
        _ ≤ P_M_fn ℓ C_M_nat L_log * ((S_exp_val ℓ) ^ 2 * (m : ℝ) ^ (UL.q_search h x)) :=
            mul_le_mul_of_nonneg_left hexp_q hPM_nn
        _ = P_M_fn ℓ C_M_nat L_log * (S_exp_val ℓ) ^ 2 * (m : ℝ) ^ (UL.q_search h x) := by ring
    have hm_q_ge1 : 1 ≤ (m : ℝ) ^ (UL.q_search h x) := Real.one_le_rpow hm_ge1 hq_ge0
    unfold K_q_fn
    calc (cap_q_of ℓ M₀ x t_ideal : ℝ)
        ≤ 100 * ((M₀ : ℝ) ^ ℓ * Real.exp (-((ℓ : ℝ) * x ^ 2 * t_ideal ^ 2 / 2)) + 1) + 2 := hceil_ub
      _ ≤ 100 * (P_M_fn ℓ C_M_nat L_log * (S_exp_val ℓ) ^ 2 * (m : ℝ) ^ (UL.q_search h x) +
            (m : ℝ) ^ (UL.q_search h x)) + 2 * (m : ℝ) ^ (UL.q_search h x) := by linarith
      _ = (m : ℝ) ^ (UL.q_search h x) *
            (100 * (P_M_fn ℓ C_M_nat L_log * (S_exp_val ℓ) ^ 2 + 1) + 2) := by ring
  exact ⟨hM₀_le_2EM, hRlM₀_le_KI, hcap_u_le_Ku, hcap_q_le_Kq⟩

lemma part4_τq_bits
    {ℓ C_net_nat C_M_nat d L_log : ℕ}
    {x t_ideal : ℝ} (hx_nn : 0 ≤ x) (hx_le : x ≤ 1)
    (ht_ge1 : 1 ≤ t_ideal) (ht_le_Lp2 : t_ideal ≤ ((L_log + 2 : ℕ) : ℝ)) :
    UL.RatCoordBitBounded (B_prec_fn ℓ C_net_nat C_M_nat d L_log)
      (τ_q_of (b_fn ℓ C_net_nat C_M_nat d L_log) x t_ideal) := by
  set b := b_fn ℓ C_net_nat C_M_nat d L_log with hb_def
  set y_q : ℝ := x * t_ideal * ((2 ^ b : ℕ) : ℝ)
  have hy_nn : 0 ≤ y_q := by positivity
  have hy_ub : y_q ≤ (((L_log + 2) * 2 ^ b : ℕ) : ℝ) := by
    have hxt : x * t_ideal ≤ ((L_log + 2 : ℕ) : ℝ) := by
      calc x * t_ideal ≤ 1 * ((L_log + 2 : ℕ) : ℝ) :=
            mul_le_mul hx_le ht_le_Lp2 (by positivity) zero_le_one
        _ = ((L_log + 2 : ℕ) : ℝ) := one_mul _
    calc y_q ≤ ((L_log + 2 : ℕ) : ℝ) * ((2 ^ b : ℕ) : ℝ) :=
          mul_le_mul_of_nonneg_right hxt (by positivity)
      _ = (((L_log + 2) * 2 ^ b : ℕ) : ℝ) := by push_cast; ring
  set z_q : ℤ := ⌊y_q⌋
  have hzq_nn : 0 ≤ z_q := Int.floor_nonneg.mpr hy_nn
  have hzq_ub : z_q ≤ (((L_log + 2) * 2 ^ b : ℕ) : ℤ) :=
    Int.cast_le.mp ((Int.floor_le y_q).trans hy_ub)
  have hzq_abs : z_q.natAbs ≤ (L_log + 2) * 2 ^ b := by omega
  have hLp2_lt : L_log + 2 < 2 ^ (L_log + 2) := Nat.lt_two_pow_self
  have hzq_lt : z_q.natAbs < 2 ^ (B_prec_fn ℓ C_net_nat C_M_nat d L_log) := by
    calc z_q.natAbs
        ≤ (L_log + 2) * 2 ^ b := hzq_abs
      _ < 2 ^ (L_log + 2) * 2 ^ b := Nat.mul_lt_mul_of_pos_right hLp2_lt (by positivity)
      _ = 2 ^ (b + L_log + 2) := by rw [← pow_add]; congr 1; omega
      _ ≤ 2 ^ (B_prec_fn ℓ C_net_nat C_M_nat d L_log) :=
          Nat.pow_le_pow_right (by decide) (by unfold B_prec_fn; rw [← hb_def]; omega)
  have h2b_lt : 2 ^ b < 2 ^ (B_prec_fn ℓ C_net_nat C_M_nat d L_log) :=
    Nat.pow_lt_pow_right (by decide) (by unfold B_prec_fn; rw [← hb_def]; omega)
  exact ratCoordBitBounded_of_div
    (B_prec_fn_pos ℓ C_net_nat C_M_nat d L_log)
    (Nat.one_le_pow b 2 (by decide)) h2b_lt hzq_lt

lemma part4_det_bounds
    {ℓ C_net_nat C_M_nat d L_log R M₀ cap_u cap_q b : ℕ}
    (hℓ : 1 ≤ ℓ) (hCap_q_pos : 1 ≤ cap_q)
    (hR_eq : R = R_fn C_net_nat d L_log)
    {ι : Type} [DecidableEq ι] (gen : UL.SearchGeneration ι (d + 1))
    {x : ℝ} {τ_d τ_q : ℚ} (sampleCoord : (Fin b → Bool) → ℚ)
    (hRlM₀_le_KI : ((R * ℓ * M₀ : ℕ) : ℝ) ≤
      (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ)) * K_I_fn ℓ C_net_nat C_M_nat d L_log)
    (hcap_u_le_Ku : (cap_u : ℝ) ≤
      (gen.m : ℝ) ^ (UL.u_search gen.h x) * K_u_fn ℓ C_M_nat L_log)
    (hcap_q_le_Kq : (cap_q : ℝ) ≤
      (gen.m : ℝ) ^ (UL.q_search gen.h x) * K_q_fn ℓ C_M_nat L_log) :
    let poly_cap := poly_cap_fn ℓ C_net_nat C_M_nat
    ((R * ℓ * M₀ : ℕ) : ℝ) ≤
      (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ)) * poly_cap d L_log ∧
    (cap_u : ℝ) ≤
      (gen.m : ℝ) ^ (UL.u_search gen.h x) * poly_cap d L_log ∧
    (cap_q : ℝ) ≤
      (gen.m : ℝ) ^ (UL.q_search gen.h x) * poly_cap d L_log ∧
    (∀ ω : UL.ExplicitBitSeed R ℓ M₀ (d + 1) b,
      let F_disc : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
        fun idx => UL.ratPointToEuclidean (fun j =>
          sampleCoord (fun bitIdx => ω (idx, j, bitIdx)))
      (∀ i ∈ gen.P₀,
        (UL.explicitPointDataWork F_disc (τ_d : ℝ) cap_u gen.pts i : ℝ) ≤
          ((gen.m : ℝ) ^ (UL.u_search gen.h x) +
            (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log) ∧
      ((UL.explicitIndexSpace F_disc (τ_d : ℝ) cap_u gen : ℝ) ≤
        ((gen.m : ℝ) ^ (1 + UL.u_search gen.h x) +
          (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log) ∧
      (∀ (P : Finset ι) (q : UL.SearchQuery ι (d + 1)),
        gen.IsSurvivingSubset P →
        q.IsValidAnswer P
          (UL.explicitCappedQuery F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q) ∧
        (UL.explicitQueryWork F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q : ℝ) ≤
          ((gen.m : ℝ) ^ (UL.q_search gen.h x) +
            (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log)) := by
  intro poly_cap
  have hm_pos_r : (0 : ℝ) < (gen.m : ℝ) := by exact_mod_cast gen.nonempty.card_pos
  have hR_pos : 1 ≤ R := hR_eq ▸ R_fn_pos C_net_nat d L_log
  have hKI_nn : 0 ≤ K_I_fn ℓ C_net_nat C_M_nat d L_log := by unfold K_I_fn S_exp_val; positivity
  have hKu_nn : 0 ≤ K_u_fn ℓ C_M_nat L_log := by unfold K_u_fn P_M_fn S_exp_val; positivity
  have hKq_nn : 0 ≤ K_q_fn ℓ C_M_nat L_log := by unfold K_q_fn P_M_fn S_exp_val; positivity
  have hKI_dp1_le : K_I_fn ℓ C_net_nat C_M_nat d L_log * ((d : ℝ) + 1) ≤ poly_cap d L_log := by
    dsimp [poly_cap]; unfold poly_cap_fn
    have : 0 ≤ ((R_fn C_net_nat d L_log * (ℓ + 2) : ℕ) : ℝ) *
        (K_u_fn ℓ C_M_nat L_log + K_q_fn ℓ C_M_nat L_log) := by positivity
    linarith
  have hKI_le_pcap : K_I_fn ℓ C_net_nat C_M_nat d L_log ≤ poly_cap d L_log := by
    have : K_I_fn ℓ C_net_nat C_M_nat d L_log * 1 ≤
        K_I_fn ℓ C_net_nat C_M_nat d L_log * ((d : ℝ) + 1) :=
      mul_le_mul_of_nonneg_left (by linarith [Nat.cast_nonneg (α := ℝ) d]) hKI_nn
    linarith
  have hRlp2_ge1 : (1 : ℝ) ≤ ((R * (ℓ + 2) : ℕ) : ℝ) := by
    exact_mod_cast Nat.mul_pos hR_pos (by omega)
  have hRl_Ku_le : ((R * ℓ : ℕ) : ℝ) * K_u_fn ℓ C_M_nat L_log ≤ poly_cap d L_log := by
    dsimp [poly_cap]; unfold poly_cap_fn; rw [← hR_eq]
    have h1 : ((R * ℓ : ℕ) : ℝ) ≤ ((R * (ℓ + 2) : ℕ) : ℝ) := by
      exact_mod_cast Nat.mul_le_mul_left R (by omega : ℓ ≤ ℓ + 2)
    have h2 : K_u_fn ℓ C_M_nat L_log ≤ K_u_fn ℓ C_M_nat L_log + K_q_fn ℓ C_M_nat L_log := by
      linarith
    have hprod := mul_le_mul h1 h2 hKu_nn (by positivity)
    have : 0 ≤ K_I_fn ℓ C_net_nat C_M_nat d L_log * ((d : ℝ) + 1) := by positivity
    linarith
  have hKu_le_pcap : K_u_fn ℓ C_M_nat L_log ≤ poly_cap d L_log := by
    have h1 : 1 * K_u_fn ℓ C_M_nat L_log ≤ ((R * ℓ : ℕ) : ℝ) * K_u_fn ℓ C_M_nat L_log :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast Nat.mul_pos hR_pos hℓ) hKu_nn
    linarith
  have hRlp2_Kq_le : ((R * (ℓ + 2) : ℕ) : ℝ) * K_q_fn ℓ C_M_nat L_log ≤ poly_cap d L_log := by
    dsimp [poly_cap]; unfold poly_cap_fn; rw [← hR_eq]
    have h1 : K_q_fn ℓ C_M_nat L_log ≤ K_u_fn ℓ C_M_nat L_log + K_q_fn ℓ C_M_nat L_log := by
      linarith
    have hprod := mul_le_mul_of_nonneg_left h1 (by positivity : (0 : ℝ) ≤ ((R * (ℓ + 2) : ℕ) : ℝ))
    have : 0 ≤ K_I_fn ℓ C_net_nat C_M_nat d L_log * ((d : ℝ) + 1) := by positivity
    linarith
  have hKq_le_pcap : K_q_fn ℓ C_M_nat L_log ≤ poly_cap d L_log := by
    have h1 : 1 * K_q_fn ℓ C_M_nat L_log ≤ ((R * (ℓ + 2) : ℕ) : ℝ) * K_q_fn ℓ C_M_nat L_log :=
      mul_le_mul_of_nonneg_right hRlp2_ge1 hKq_nn
    linarith
  refine ⟨hRlM₀_le_KI.trans (mul_le_mul_of_nonneg_left hKI_le_pcap (Real.rpow_nonneg hm_pos_r.le _)),
    hcap_u_le_Ku.trans (mul_le_mul_of_nonneg_left hKu_le_pcap (Real.rpow_nonneg hm_pos_r.le _)),
    hcap_q_le_Kq.trans (mul_le_mul_of_nonneg_left hKq_le_pcap (Real.rpow_nonneg hm_pos_r.le _)),
    ?_⟩
  intro ω
  let F_disc : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
    fun idx => UL.ratPointToEuclidean (fun j => sampleCoord (fun bitIdx => ω (idx, j, bitIdx)))
  have hbase_term : ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) ≤
      (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ)) * poly_cap d L_log := by
    have h1 : ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) = ((R * ℓ * M₀ : ℕ) : ℝ) * ((d : ℝ) + 1) := by
      push_cast; ring
    rw [h1]
    calc ((R * ℓ * M₀ : ℕ) : ℝ) * ((d : ℝ) + 1)
        ≤ ((gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ)) * K_I_fn ℓ C_net_nat C_M_nat d L_log) *
            ((d : ℝ) + 1) := mul_le_mul_of_nonneg_right hRlM₀_le_KI (by positivity)
      _ = (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ)) *
            (K_I_fn ℓ C_net_nat C_M_nat d L_log * ((d : ℝ) + 1)) := by ring
      _ ≤ (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ)) * poly_cap d L_log :=
          mul_le_mul_of_nonneg_left hKI_dp1_le (Real.rpow_nonneg hm_pos_r.le _)
  have hcap_u_term : ((R * (cap_u * ℓ) : ℕ) : ℝ) ≤
      (gen.m : ℝ) ^ (UL.u_search gen.h x) * poly_cap d L_log := by
    have h1 : ((R * (cap_u * ℓ) : ℕ) : ℝ) = ((R * ℓ : ℕ) : ℝ) * (cap_u : ℝ) := by push_cast; ring
    rw [h1]
    calc ((R * ℓ : ℕ) : ℝ) * (cap_u : ℝ)
        ≤ ((R * ℓ : ℕ) : ℝ) * ((gen.m : ℝ) ^ (UL.u_search gen.h x) * K_u_fn ℓ C_M_nat L_log) :=
          mul_le_mul_of_nonneg_left hcap_u_le_Ku (by positivity)
      _ = (gen.m : ℝ) ^ (UL.u_search gen.h x) * (((R * ℓ : ℕ) : ℝ) * K_u_fn ℓ C_M_nat L_log) := by ring
      _ ≤ (gen.m : ℝ) ^ (UL.u_search gen.h x) * poly_cap d L_log :=
          mul_le_mul_of_nonneg_left hRl_Ku_le (Real.rpow_nonneg hm_pos_r.le _)
  refine ⟨?_, ?_, ?_⟩
  · intro i _
    have hw : (UL.explicitPointDataWork F_disc (τ_d : ℝ) cap_u gen.pts i : ℝ) ≤
        ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) + ((R * (cap_u * ℓ) : ℕ) : ℝ) := by
      exact_mod_cast explicitPointDataWork_le F_disc (τ_d : ℝ) cap_u gen.pts i
    linarith
  · have hs : (UL.explicitIndexSpace F_disc (τ_d : ℝ) cap_u gen : ℝ) ≤
        ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) + (gen.m : ℝ) * ((R * (cap_u * ℓ) : ℕ) : ℝ) := by
      exact_mod_cast explicitIndexSpace_le F_disc (τ_d : ℝ) cap_u gen
    have hm_u : (gen.m : ℝ) * ((R * (cap_u * ℓ) : ℕ) : ℝ) ≤
        (gen.m : ℝ) ^ (1 + UL.u_search gen.h x) * poly_cap d L_log := by
      calc (gen.m : ℝ) * ((R * (cap_u * ℓ) : ℕ) : ℝ)
          ≤ (gen.m : ℝ) * ((gen.m : ℝ) ^ (UL.u_search gen.h x) * poly_cap d L_log) :=
            mul_le_mul_of_nonneg_left hcap_u_term hm_pos_r.le
        _ = ((gen.m : ℝ) ^ (1 : ℝ) * (gen.m : ℝ) ^ (UL.u_search gen.h x)) * poly_cap d L_log := by
            rw [Real.rpow_one]; ring
        _ = (gen.m : ℝ) ^ (1 + UL.u_search gen.h x) * poly_cap d L_log := by
            rw [← Real.rpow_add hm_pos_r]
    linarith
  · intro P q _hP
    refine ⟨explicitCappedQuery_valid F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q, ?_⟩
    have hqw_nat : UL.explicitQueryWork F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q ≤
        R * (ℓ + 2) * cap_q + R * ℓ * M₀ * (d + 1) := by
      have h1 := explicitQueryWork_le F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q
      have h2 : cap_q * ℓ + (cap_q + 1) ≤ (ℓ + 2) * cap_q := by
        calc cap_q * ℓ + (cap_q + 1) ≤ cap_q * ℓ + (cap_q + cap_q) := by omega
          _ = (ℓ + 2) * cap_q := by ring
      have h3 : R * (cap_q * ℓ + (cap_q + 1)) ≤ R * ((ℓ + 2) * cap_q) := Nat.mul_le_mul_left R h2
      have h4 : R * ((ℓ + 2) * cap_q) = R * (ℓ + 2) * cap_q := (Nat.mul_assoc _ _ _).symm
      omega
    have hqw : (UL.explicitQueryWork F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q : ℝ) ≤
        ((R * (ℓ + 2) : ℕ) : ℝ) * (cap_q : ℝ) + ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) := by
      have : ((R * (ℓ + 2) * cap_q + R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) =
          ((R * (ℓ + 2) : ℕ) : ℝ) * (cap_q : ℝ) + ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) := by
        push_cast; ring
      rw [← this]
      exact_mod_cast hqw_nat
    have hq_term : ((R * (ℓ + 2) : ℕ) : ℝ) * (cap_q : ℝ) ≤
        (gen.m : ℝ) ^ (UL.q_search gen.h x) * poly_cap d L_log := by
      calc ((R * (ℓ + 2) : ℕ) : ℝ) * (cap_q : ℝ)
          ≤ ((R * (ℓ + 2) : ℕ) : ℝ) * ((gen.m : ℝ) ^ (UL.q_search gen.h x) * K_q_fn ℓ C_M_nat L_log) :=
            mul_le_mul_of_nonneg_left hcap_q_le_Kq (by positivity)
        _ = (gen.m : ℝ) ^ (UL.q_search gen.h x) * (((R * (ℓ + 2) : ℕ) : ℝ) * K_q_fn ℓ C_M_nat L_log) := by
            ring
        _ ≤ (gen.m : ℝ) ^ (UL.q_search gen.h x) * poly_cap d L_log :=
            mul_le_mul_of_nonneg_left hRlp2_Kq_le (Real.rpow_nonneg hm_pos_r.le _)
    linarith

lemma part4_bad_event_and_agree
    {ℓ C_net_nat C_M_nat d L_log R M₀ : ℕ}
    (hR_eq : R = R_fn C_net_nat d L_log)
    (hM₀_le_2EM : (M₀ : ℝ) ≤ (2 : ℝ) ^ (E_M_fn C_M_nat L_log))
    {ι : Type} [DecidableEq ι] (gen : UL.SearchGeneration ι (d + 1))
    {x ε₀ t_ideal : ℝ} (hε₀_pos : 0 < ε₀)
    {τ_d τ_q : ℚ} (ht_d_eq : (τ_d : ℝ) = t_ideal)
    (hτ_q_eq : τ_q = τ_q_of (b_fn ℓ C_net_nat C_M_nat d L_log) x t_ideal)
    (hm_2 : (gen.m : ℝ) ≤ (2 : ℝ) ^ (2 * L_log))
    (h4_div_eps_le : 4 / ε₀ ≤ (2 : ℝ) ^ (2 * L_log + 1))
    (Q_net : List (EuclideanSpace ℝ (Fin (d + 1))))
    (hQ_unit : ∀ z ∈ Q_net, UL.IsUnitVec z)
    (hQ_pow2 : (Q_net.length : ℝ) ≤ (2 : ℝ) ^ (2 * (C_net_nat * d * (d + L_log)))) :
    ∃ B_bad : Set (UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1))),
      MeasurableSet B_bad ∧
      (Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ =>
        UL.stdGaussianMeasure (d + 1))).real B_bad ≤ ε₀ / 2 ∧
      (∀ ω_c ∈ B_badᶜ, ∀ idx : UL.ExplicitCapIdx R ℓ M₀,
        let G_disc := UL.ratPointToEuclidean (fun j =>
          sampleCoord1D (b_fn ℓ C_net_nat C_M_nat d L_log) (T_fn ℓ C_net_nat C_M_nat d L_log)
            (fun bitIdx =>
              projBitsMap (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1)
                (b_fn_pos ℓ C_net_nat C_M_nat d L_log) ω_c (idx, j, bitIdx)))
        (∀ i ∈ gen.P₀,
          UL.gaussianDataTest (τ_d : ℝ) G_disc (gen.pts i) ↔
            UL.gaussianDataTest t_ideal (ω_c idx) (gen.pts i)) ∧
        (∀ z ∈ Q_net,
          UL.gaussianDataTest (τ_q : ℝ) G_disc z ↔
            UL.gaussianQueryTest x t_ideal (ω_c idx) z)) := by
  let Ω_cpl : Type := UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1))
  let μ_cpl : Measure Ω_cpl :=
    Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure (d + 1))
  have hb_pos : 1 ≤ b_fn ℓ C_net_nat C_M_nat d L_log := b_fn_pos ℓ C_net_nat C_M_nat d L_log
  set K_tail := K_tail_fn ℓ C_net_nat C_M_nat d L_log with hK_def
  set T := T_fn ℓ C_net_nat C_M_nat d L_log with hT_def
  set p_bits := p_bits_fn ℓ C_net_nat C_M_nat d L_log with hpb_def
  set p_coord := p_coord_fn ℓ C_net_nat C_M_nat d L_log with hpc_def
  set b := b_fn ℓ C_net_nat C_M_nat d L_log with hb_def
  let B_box : Set Ω_cpl :=
    {ω_c | ∃ (idx : UL.ExplicitCapIdx R ℓ M₀) (j : Fin (d + 1)),
      (T : ℝ) < |UL.euclideanCoord (ω_c idx) j|}
  have hB_box_meas : MeasurableSet B_box := by
    have heq : B_box = ⋃ idx : UL.ExplicitCapIdx R ℓ M₀, ⋃ j : Fin (d + 1),
        {ω_c : Ω_cpl | (T : ℝ) < |UL.euclideanCoord (ω_c idx) j|} := by
      ext ω_c; simp [B_box]
    rw [heq]
    refine MeasurableSet.iUnion fun idx => MeasurableSet.iUnion fun j => ?_
    exact measurableSet_lt measurable_const
      (continuous_abs.measurable.comp ((measurable_euclideanCoord j).comp (measurable_pi_apply idx)))
  have hB_box_prob : μ_cpl.real B_box ≤ ε₀ / 4 := by
    have h1 := pi_coord_abs_gt_prob_le (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1) T
    refine h1.trans ?_
    have hprod_le : ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) * 2 * (4 / ε₀) ≤ (2 : ℝ) ^ K_tail := by
      push_cast
      have hR_2 : (R : ℝ) ≤ (2 : ℝ) ^ R := UL.Proof_lem_6_3.nat_cast_le_two_pow R
      have hl_2 : (ℓ : ℝ) ≤ (2 : ℝ) ^ ℓ := UL.Proof_lem_6_3.nat_cast_le_two_pow ℓ
      have hd_2 : ((d : ℝ) + 1) ≤ (2 : ℝ) ^ (d + 1) := by
        exact_mod_cast (Nat.lt_two_pow_self (n := d + 1)).le
      calc (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((d : ℝ) + 1) * 2 * (4 / ε₀)
          ≤ (2 : ℝ) ^ R * (2 : ℝ) ^ ℓ * (2 : ℝ) ^ (E_M_fn C_M_nat L_log) * (2 : ℝ) ^ (d + 1) *
              (2 : ℝ) ^ 1 * (2 : ℝ) ^ (2 * L_log + 1) := by
            have p1 := mul_le_mul hR_2 hl_2 (by positivity) (by positivity)
            have p2 := mul_le_mul p1 hM₀_le_2EM (by positivity) (by positivity)
            have p3 := mul_le_mul p2 hd_2 (by positivity) (by positivity)
            have p4 : (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((d : ℝ) + 1) * 2 ≤
                (2 : ℝ) ^ R * (2 : ℝ) ^ ℓ * (2 : ℝ) ^ (E_M_fn C_M_nat L_log) *
                  (2 : ℝ) ^ (d + 1) * (2 : ℝ) ^ 1 := by
              simpa using mul_le_mul_of_nonneg_right p3 (by norm_num : (0 : ℝ) ≤ 2)
            exact mul_le_mul p4 h4_div_eps_le (by positivity) (by positivity)
        _ = (2 : ℝ) ^ K_tail := by
            rw [hR_eq, hK_def]; unfold K_tail_fn
            simp only [← pow_add]
            congr 1; omega
    have hexp_T : (2 : ℝ) ^ K_tail * Real.exp (-((T : ℝ) ^ 2 / 2)) ≤ 1 := by
      have h2K : (2 : ℝ) ^ K_tail ≤ Real.exp (K_tail : ℝ) := by
        calc (2 : ℝ) ^ K_tail ≤ (Real.exp 1) ^ K_tail :=
              pow_le_pow_left₀ (by norm_num) UL.Proof_lem_6_3.two_le_exp_one K_tail
          _ = Real.exp (K_tail : ℝ) := by simp [← Real.exp_nat_mul]
      have hKT2 : (K_tail : ℝ) ≤ (T : ℝ) ^ 2 / 2 := by
        have hnat : 2 * K_tail ≤ T ^ 2 := by
          rw [hT_def]; unfold T_fn; rw [← hK_def]
          exact two_mul_le_add_two_sq K_tail
        have hreal : (2 : ℝ) * (K_tail : ℝ) ≤ (T : ℝ) ^ 2 := by exact_mod_cast hnat
        linarith
      calc (2 : ℝ) ^ K_tail * Real.exp (-((T : ℝ) ^ 2 / 2))
          ≤ Real.exp ((T : ℝ) ^ 2 / 2) * Real.exp (-((T : ℝ) ^ 2 / 2)) :=
            mul_le_mul_of_nonneg_right (h2K.trans (Real.exp_le_exp.mpr hKT2)) (Real.exp_pos _).le
        _ = 1 := by rw [← Real.exp_add, add_neg_cancel, Real.exp_zero]
    have hle1 := (mul_le_mul_of_nonneg_right hprod_le (Real.exp_pos (-((T : ℝ) ^ 2 / 2))).le).trans hexp_T
    have hmul_eps := mul_le_mul_of_nonneg_left hle1 (by positivity : 0 ≤ ε₀ / 4)
    have hsimp : (ε₀ / 4) * (((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) * 2 * (4 / ε₀) *
        Real.exp (-((T : ℝ) ^ 2 / 2))) =
        ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) * (2 * Real.exp (-((T : ℝ) ^ 2 / 2))) := by
      field_simp
    linarith
  set Δ : ℝ := (2 : ℝ) ^ (-(p_bits : ℤ)) with hΔ_def
  have hΔ_pos : 0 < Δ := by positivity
  let idx_list : List (UL.ExplicitCapIdx R ℓ M₀) := Finset.univ.toList
  let uz_list : List (EuclideanSpace ℝ (Fin (d + 1)) × ℝ) :=
    (gen.P₀.toList.map (fun i => (gen.pts i, t_ideal))) ++
      (Q_net.map (fun z => (z, x * t_ideal)))
  let cmps : List (UL.ExplicitCapIdx R ℓ M₀ × EuclideanSpace ℝ (Fin (d + 1)) × ℝ) :=
    idx_list.flatMap (fun idx => uz_list.map (fun uz => (idx, uz.1, uz.2)))
  have hcmps_unit : ∀ c ∈ cmps, UL.IsUnitVec c.2.1 := by
    intro c hc
    rcases List.mem_flatMap.mp hc with ⟨idx, _, hc_map⟩
    rcases List.mem_map.mp hc_map with ⟨uz, huz, rfl⟩
    rcases List.mem_append.mp huz with huz_d | huz_q
    · rcases List.mem_map.mp huz_d with ⟨i, hi_l, rfl⟩
      exact gen.unit_pts i (Finset.mem_toList.mp hi_l)
    · rcases List.mem_map.mp huz_q with ⟨z, hz_Q, rfl⟩
      exact hQ_unit z hz_Q
  have hcmps_len : cmps.length = (R * ℓ * M₀) * (gen.m + Q_net.length) := by
    dsimp [cmps]
    rw [length_flatMap_map]
    have h1 : idx_list.length = R * ℓ * M₀ := by simp [idx_list, UL.ExplicitCapIdx, mul_assoc]
    have h2 : uz_list.length = gen.m + Q_net.length := by simp [uz_list, UL.SearchGeneration.m]
    rw [h1, h2]
  let B_cmps : Set Ω_cpl :=
    {ω_c | ∃ c ∈ cmps, inner ℝ (ω_c c.1) c.2.1 ∈ Set.Icc (c.2.2 - Δ) (c.2.2 + Δ)}
  have hB_cmps_meas : MeasurableSet B_cmps := by
    refine measurableSet_exists_mem_list cmps
      (fun c => {ω_c : Ω_cpl | inner ℝ (ω_c c.1) c.2.1 ∈ Set.Icc (c.2.2 - Δ) (c.2.2 + Δ)}) ?_
    intro c _
    exact measurableSet_Icc.preimage
      (((continuous_id.inner continuous_const).measurable).comp (measurable_pi_apply c.1))
  have hB_cmps_prob : μ_cpl.real B_cmps ≤ ε₀ / 4 := by
    have h1 : μ_cpl.real B_cmps ≤ (cmps.length : ℝ) * Δ :=
      measureReal_exists_mem_list_le μ_cpl cmps _ hΔ_pos.le
        (fun c hc => pi_coord_inner_Icc_le_delta c.1 c.2.1 (hcmps_unit c hc) c.2.2 Δ hΔ_pos.le)
    refine h1.trans ?_
    rw [hcmps_len]
    push_cast
    let E_mQ := 2 * L_log + 2 * (C_net_nat * d * (d + L_log))
    have hmQ_2 : (gen.m : ℝ) + (Q_net.length : ℝ) ≤ (2 : ℝ) ^ (E_mQ + 1) := by
      have ha : (2 : ℝ) ^ (2 * L_log) ≤ (2 : ℝ) ^ E_mQ :=
        pow_le_pow_right₀ (by norm_num) (by dsimp [E_mQ]; omega)
      have hb2 : (2 : ℝ) ^ (2 * (C_net_nat * d * (d + L_log))) ≤ (2 : ℝ) ^ E_mQ :=
        pow_le_pow_right₀ (by norm_num) (by dsimp [E_mQ]; omega)
      calc (gen.m : ℝ) + (Q_net.length : ℝ)
          ≤ (2 : ℝ) ^ E_mQ + (2 : ℝ) ^ E_mQ := add_le_add (hm_2.trans ha) (hQ_pow2.trans hb2)
        _ = (2 : ℝ) ^ (E_mQ + 1) := by rw [pow_succ]; ring
    have hprod_p : (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((gen.m : ℝ) + (Q_net.length : ℝ)) * (4 / ε₀) ≤
        (2 : ℝ) ^ p_bits := by
      have hR_2 : (R : ℝ) ≤ (2 : ℝ) ^ R := UL.Proof_lem_6_3.nat_cast_le_two_pow R
      have hl_2 : (ℓ : ℝ) ≤ (2 : ℝ) ^ ℓ := UL.Proof_lem_6_3.nat_cast_le_two_pow ℓ
      calc (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((gen.m : ℝ) + (Q_net.length : ℝ)) * (4 / ε₀)
          ≤ (2 : ℝ) ^ R * (2 : ℝ) ^ ℓ * (2 : ℝ) ^ (E_M_fn C_M_nat L_log) *
              (2 : ℝ) ^ (E_mQ + 1) * (2 : ℝ) ^ (2 * L_log + 1) := by
            have p1 := mul_le_mul hR_2 hl_2 (by positivity) (by positivity)
            have p2 := mul_le_mul p1 hM₀_le_2EM (by positivity) (by positivity)
            have p3 := mul_le_mul p2 hmQ_2 (by positivity) (by positivity)
            exact mul_le_mul p3 h4_div_eps_le (by positivity) (by positivity)
        _ = (2 : ℝ) ^ p_bits := by
            rw [hR_eq, hpb_def]; unfold p_bits_fn
            dsimp only [E_mQ]
            simp only [← pow_add]
            congr 1; ring
    have hcancel : (2 : ℝ) ^ p_bits * Δ = 1 := by
      rw [hΔ_def, ← zpow_natCast, ← zpow_add₀ (by norm_num), add_neg_cancel, zpow_zero]
    have hmul1 := (mul_le_mul_of_nonneg_right hprod_p hΔ_pos.le).trans_eq hcancel
    have hmul2 := mul_le_mul_of_nonneg_left hmul1 (by positivity : 0 ≤ ε₀ / 4)
    have hsimp : (ε₀ / 4) * ((R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) *
        ((gen.m : ℝ) + (Q_net.length : ℝ)) * (4 / ε₀) * Δ) =
        (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((gen.m : ℝ) + (Q_net.length : ℝ)) * Δ := by
      field_simp
    linarith
  let B_bad : Set Ω_cpl := B_box ∪ B_cmps
  have hB_bad_meas : MeasurableSet B_bad := hB_box_meas.union hB_cmps_meas
  have hB_bad_prob : μ_cpl.real B_bad ≤ ε₀ / 2 := by
    have := UL.Proof_lem_6_3.measureReal_union_le_add μ_cpl B_box B_cmps
    linarith
  refine ⟨B_bad, hB_bad_meas, hB_bad_prob, ?_⟩
  intro ω_c hω idx
  have hnot_box : ω_c ∉ B_box := fun h => hω (Or.inl h)
  have hnot_cmps : ω_c ∉ B_cmps := fun h => hω (Or.inr h)
  set G_disc := UL.ratPointToEuclidean (fun j =>
    sampleCoord1D b T (fun bitIdx =>
      projBitsMap (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1)
        (b_fn_pos ℓ C_net_nat C_M_nat d L_log) ω_c (idx, j, bitIdx))) with hG_def
  have hnorm_diff : ‖G_disc - ω_c idx‖ ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := by
    have hcoord : ∀ j : Fin (d + 1),
        |UL.euclideanCoord G_disc j - UL.euclideanCoord (ω_c idx) j| ≤
          (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) := by
      intro j
      have hj_box : |UL.euclideanCoord (ω_c idx) j| ≤ (T : ℝ) := by
        by_contra hgt; push_neg at hgt; exact hnot_box ⟨idx, j, hgt⟩
      have heq_c : UL.euclideanCoord G_disc j =
          ((sampleCoord1D b T (encode1D b hb_pos (UL.euclideanCoord (ω_c idx) j)) : ℚ) : ℝ) := by
        rw [hG_def, euclideanCoord_ratPointToEuclidean]
        rfl
      rw [heq_c]
      exact sampleCoord_fn_approx_on_box (b_fn_pos ℓ C_net_nat C_M_nat d L_log) hj_box
    have h1 := euclidean_norm_sub_le_of_coord (by positivity) hcoord
    refine h1.trans ?_
    have hdp1 : ((d + 1 : ℕ) : ℝ) ≤ (2 : ℝ) ^ ((d + 1 : ℕ) : ℤ) := by
      rw [zpow_natCast]; exact UL.Proof_lem_6_3.nat_cast_le_two_pow (d + 1)
    calc ((d + 1 : ℕ) : ℝ) * (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ))
        ≤ (2 : ℝ) ^ ((d + 1 : ℕ) : ℤ) * (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) :=
          mul_le_mul_of_nonneg_right hdp1 (by positivity)
      _ = (2 : ℝ) ^ (((d + 1 : ℕ) : ℤ) + -((p_coord + 1 : ℕ) : ℤ)) :=
          (zpow_add₀ (by norm_num) _ _).symm
      _ ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) :=
          zpow_le_zpow_right₀ (by norm_num)
            (by rw [hpc_def]; unfold p_coord_fn; rw [← hpb_def]; omega)
  have hτq_err : |(τ_q : ℝ) - x * t_ideal| ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := by
    have h2b_pos : (0 : ℝ) < ((2 ^ b : ℕ) : ℝ) := by positivity
    have htq_eq : (τ_q : ℝ) = (⌊x * t_ideal * ((2 ^ b : ℕ) : ℝ)⌋ : ℝ) / ((2 ^ b : ℕ) : ℝ) := by
      rw [hτ_q_eq, τ_q_of]; push_cast; rfl
    have hhi : (τ_q : ℝ) ≤ x * t_ideal := by
      rw [htq_eq, div_le_iff₀ h2b_pos]; exact Int.floor_le _
    have hlo : x * t_ideal - (((2 ^ b : ℕ) : ℝ))⁻¹ ≤ (τ_q : ℝ) := by
      rw [htq_eq, ← one_div, le_div_iff₀ h2b_pos]
      have := (Int.sub_one_lt_floor (x * t_ideal * ((2 ^ b : ℕ) : ℝ))).le
      have hmul : (x * t_ideal - 1 / ((2 ^ b : ℕ) : ℝ)) * ((2 ^ b : ℕ) : ℝ) =
          x * t_ideal * ((2 ^ b : ℕ) : ℝ) - 1 := by field_simp
      linarith
    have habs : |(τ_q : ℝ) - x * t_ideal| ≤ (2 : ℝ) ^ (-(b : ℤ)) := by
      have h2b_inv : (((2 ^ b : ℕ) : ℝ))⁻¹ = (2 : ℝ) ^ (-(b : ℤ)) := by
        rw [zpow_neg, zpow_natCast]; push_cast; rfl
      rw [← h2b_inv, abs_le]
      exact ⟨by linarith, by linarith [inv_nonneg.mpr h2b_pos.le]⟩
    exact habs.trans (zpow_le_zpow_right₀ (by norm_num)
      (by rw [hb_def]; unfold b_fn p_coord_fn; rw [← hpb_def]; omega))
  have hhalf_Δ : (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) + (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) = Δ := by
    rw [hΔ_def]
    have heq : -(p_bits : ℤ) = -((p_bits + 1 : ℕ) : ℤ) + 1 := by omega
    rw [heq, zpow_add₀ (by norm_num), zpow_one]; ring
  have hidx_mem : idx ∈ idx_list := Finset.mem_toList.mpr (Finset.mem_univ idx)
  refine ⟨?_, ?_⟩
  · intro i hi
    have h_in_cmps : (idx, gen.pts i, t_ideal) ∈ cmps := by
      refine List.mem_flatMap.mpr ⟨idx, hidx_mem, List.mem_map.mpr ⟨(gen.pts i, t_ideal), ?_, rfl⟩⟩
      exact List.mem_append_left _ (List.mem_map.mpr ⟨i, Finset.mem_toList.mpr hi, rfl⟩)
    have hnot_Icc : inner ℝ (ω_c idx) (gen.pts i) ∉ Set.Icc (t_ideal - Δ) (t_ideal + Δ) :=
      fun hmem => hnot_cmps ⟨(idx, gen.pts i, t_ideal), h_in_cmps, hmem⟩
    have hcs : |inner ℝ (G_disc - ω_c idx) (gen.pts i)| ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := by
      calc |inner ℝ (G_disc - ω_c idx) (gen.pts i)|
          ≤ ‖G_disc - ω_c idx‖ * ‖gen.pts i‖ := abs_real_inner_le_norm _ _
        _ = ‖G_disc - ω_c idx‖ := by rw [gen.unit_pts i hi, mul_one]
        _ ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := hnorm_diff
    have hdiff : |(τ_d : ℝ) - t_ideal| + |inner ℝ (G_disc - ω_c idx) (gen.pts i)| ≤ Δ := by
      have ht0 : |(τ_d : ℝ) - t_ideal| = 0 := by rw [ht_d_eq, sub_self, abs_zero]
      rw [ht0]
      linarith [(by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)))]
    exact test_iff_of_two_sided_margin hdiff hnot_Icc
  · intro z hz
    have h_in_cmps : (idx, z, x * t_ideal) ∈ cmps := by
      refine List.mem_flatMap.mpr ⟨idx, hidx_mem, List.mem_map.mpr ⟨(z, x * t_ideal), ?_, rfl⟩⟩
      exact List.mem_append_right _ (List.mem_map.mpr ⟨z, hz, rfl⟩)
    have hnot_Icc : inner ℝ (ω_c idx) z ∉ Set.Icc (x * t_ideal - Δ) (x * t_ideal + Δ) :=
      fun hmem => hnot_cmps ⟨(idx, z, x * t_ideal), h_in_cmps, hmem⟩
    have hcs : |inner ℝ (G_disc - ω_c idx) z| ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := by
      calc |inner ℝ (G_disc - ω_c idx) z|
          ≤ ‖G_disc - ω_c idx‖ * ‖z‖ := abs_real_inner_le_norm _ _
        _ = ‖G_disc - ω_c idx‖ := by rw [hQ_unit z hz, mul_one]
        _ ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := hnorm_diff
    have hdiff : |(τ_q : ℝ) - x * t_ideal| + |inner ℝ (G_disc - ω_c idx) z| ≤ Δ := by
      linarith
    exact test_iff_of_two_sided_margin hdiff hnot_Icc

lemma part4_prob_assembly
    {ℓ d R M₀ cap_u cap_q b : ℕ}
    (hℓ : 1 ≤ ℓ) (hM₀_pos : 1 ≤ M₀) (hCap_u_pos : 1 ≤ cap_u) (hCap_q_pos : 1 ≤ cap_q)
    (hb_pos : 1 ≤ b)
    {ι : Type} [DecidableEq ι] (gen : UL.SearchGeneration ι (d + 1))
    {x ε₀ t_ideal p_u p_q p₁ p₂ : ℝ}
    {τ_d τ_q : ℚ} (sampleCoord : (Fin b → Bool) → ℚ)
    (hprobs : UL.IsGaussianFilterProbs (d + 1) gen.h x t_ideal p_u p_q p₁ p₂)
    (hp₁_pos : 0 < p₁)
    (hp₁_M : Real.log (100 * (ℓ : ℝ)) ≤ p₁ * (M₀ : ℝ))
    (hCap_u : 100 * ((M₀ : ℝ) ^ ℓ * p_u ^ ℓ + 1) ≤ (cap_u : ℝ))
    (hCap_q : 100 * ((M₀ : ℝ) ^ ℓ * p_q ^ ℓ + 1) ≤ (cap_q : ℝ))
    (hCap_bad : 100 * ((gen.m : ℝ) * (M₀ : ℝ) ^ ℓ * p₂ ^ ℓ + 1) ≤ (cap_q : ℝ))
    (Q_net : List (EuclideanSpace ℝ (Fin (d + 1))))
    (hQ_unit : ∀ z ∈ Q_net, UL.IsUnitVec z)
    (h10R_le : (gen.m : ℝ) * (Q_net.length : ℝ) * (1 / 10 : ℝ) ^ R ≤ ε₀ / 2)
    {B_bad : Set (UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)))}
    (hB_bad_meas : MeasurableSet B_bad)
    (hB_bad_prob : (Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ =>
      UL.stdGaussianMeasure (d + 1))).real B_bad ≤ ε₀ / 2)
    (h_agree_on_good : ∀ ω_c ∈ B_badᶜ, ∀ idx : UL.ExplicitCapIdx R ℓ M₀,
      let G_disc := UL.ratPointToEuclidean (fun j =>
        sampleCoord (fun bitIdx =>
          projBitsMap (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1) hb_pos ω_c (idx, j, bitIdx)))
      (∀ i ∈ gen.P₀,
        UL.gaussianDataTest (τ_d : ℝ) G_disc (gen.pts i) ↔
          UL.gaussianDataTest t_ideal (ω_c idx) (gen.pts i)) ∧
      (∀ z ∈ Q_net,
        UL.gaussianDataTest (τ_q : ℝ) G_disc z ↔
          UL.gaussianQueryTest x t_ideal (ω_c idx) z)) :
    (∃ (Ω_cpl : Type) (mΩ : MeasurableSpace Ω_cpl)
       (μ_cpl : @MeasureTheory.Measure Ω_cpl mΩ)
       (proj_bits : Ω_cpl → UL.ExplicitBitSeed R ℓ M₀ (d + 1) b)
       (proj_gauss :
         Ω_cpl → (UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)))),
      @MeasureTheory.IsProbabilityMeasure Ω_cpl mΩ μ_cpl ∧
      @Measurable _ _ mΩ inferInstance proj_bits ∧
      @Measurable _ _ mΩ inferInstance proj_gauss ∧
      @MeasureTheory.Measure.map _ _ mΩ inferInstance proj_bits μ_cpl =
        (PMF.uniformOfFintype (UL.ExplicitBitSeed R ℓ M₀ (d + 1) b)).toMeasure ∧
      @MeasureTheory.Measure.map _ _ mΩ inferInstance proj_gauss μ_cpl =
        MeasureTheory.Measure.pi
          (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure (d + 1)) ∧
      1 - ε₀ / 2 ≤ (@MeasureTheory.Measure.real Ω_cpl mΩ μ_cpl) {ω_c : Ω_cpl |
        ∀ idx : UL.ExplicitCapIdx R ℓ M₀,
          let G_disc := UL.ratPointToEuclidean (fun j =>
            sampleCoord (fun bitIdx => proj_bits ω_c (idx, j, bitIdx)))
          let G_id := proj_gauss ω_c idx
          (∀ i ∈ gen.P₀,
            UL.gaussianDataTest (τ_d : ℝ) G_disc (gen.pts i) ↔
              UL.gaussianDataTest t_ideal G_id (gen.pts i)) ∧
          (∀ z ∈ Q_net,
            UL.gaussianDataTest (τ_q : ℝ) G_disc z ↔
              UL.gaussianQueryTest x t_ideal G_id z)}) ∧
    (∃ E_good : Set (UL.ExplicitBitSeed R ℓ M₀ (d + 1) b),
      1 - ε₀ ≤
        ((PMF.uniformOfFintype
          (UL.ExplicitBitSeed R ℓ M₀ (d + 1) b)).toMeasure).real E_good ∧
      ∀ ω ∈ E_good,
        let F_disc : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
          fun idx => UL.ratPointToEuclidean (fun j =>
            sampleCoord (fun bitIdx => ω (idx, j, bitIdx)))
        ∀ (P : Finset ι) (q : UL.SearchQuery ι (d + 1)),
          gen.IsSurvivingSubset P →
          q.z ∈ Q_net →
          gen.IsCompatible P q →
          gen.IsCorrectAnswer P q
            (UL.explicitCappedQuery F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q)) := by
  let Ω_cpl : Type := UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1))
  let μ_cpl : Measure Ω_cpl :=
    Measure.pi (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure (d + 1))
  let proj_bits : Ω_cpl → UL.ExplicitBitSeed R ℓ M₀ (d + 1) b :=
    projBitsMap (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1) hb_pos
  rcases idealGoodEvent_exists (R := R) hℓ hM₀_pos hCap_u_pos hCap_q_pos gen hprobs
    hp₁_pos hp₁_M hCap_u hCap_q hCap_bad Q_net hQ_unit
    with ⟨E_ideal, hE_id_meas, hE_id_prob0, hE_id_corr⟩
  have hE_id_prob : 1 - ε₀ / 2 ≤ μ_cpl.real E_ideal := by linarith
  refine ⟨?_, ?_⟩
  · refine ⟨Ω_cpl, inferInstance, μ_cpl, proj_bits, id,
      inferInstance, measurable_projBitsMap hb_pos, measurable_id,
      map_projBitsMap_eq_uniform hb_pos, Measure.map_id, ?_⟩
    have hcompl : μ_cpl.real B_badᶜ = 1 - μ_cpl.real B_bad :=
      UL.Proof_lem_6_3.probReal_compl_eq μ_cpl hB_bad_meas
    have hmono : μ_cpl.real B_badᶜ ≤ μ_cpl.real {ω_c : Ω_cpl |
        ∀ idx : UL.ExplicitCapIdx R ℓ M₀,
          let G_disc := UL.ratPointToEuclidean (fun j =>
            sampleCoord (fun bitIdx => proj_bits ω_c (idx, j, bitIdx)))
          let G_id := (id : Ω_cpl → Ω_cpl) ω_c idx
          (∀ i ∈ gen.P₀,
            UL.gaussianDataTest (τ_d : ℝ) G_disc (gen.pts i) ↔
              UL.gaussianDataTest t_ideal G_id (gen.pts i)) ∧
          (∀ z ∈ Q_net,
            UL.gaussianDataTest (τ_q : ℝ) G_disc z ↔
              UL.gaussianQueryTest x t_ideal G_id z)} :=
      MeasureTheory.measureReal_mono h_agree_on_good
    linarith
  · let E_good : Set (UL.ExplicitBitSeed R ℓ M₀ (d + 1) b) :=
      {ω |
        let F_disc : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
          fun idx => UL.ratPointToEuclidean (fun j => sampleCoord (fun bitIdx => ω (idx, j, bitIdx)))
        ∀ (P : Finset ι) (q : UL.SearchQuery ι (d + 1)),
          gen.IsSurvivingSubset P →
          q.z ∈ Q_net →
          gen.IsCompatible P q →
          gen.IsCorrectAnswer P q
            (UL.explicitCappedQuery F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q)}
    refine ⟨E_good, ?_, fun _ hω => hω⟩
    let B_tot : Set Ω_cpl := B_bad ∪ E_idealᶜ
    have hB_tot_meas : MeasurableSet B_tot := hB_bad_meas.union hE_id_meas.compl
    have hEid_c_prob : μ_cpl.real E_idealᶜ ≤ ε₀ / 2 := by
      have := UL.Proof_lem_6_3.probReal_compl_eq μ_cpl hE_id_meas
      linarith
    have hB_tot_prob : μ_cpl.real B_tot ≤ ε₀ := by
      have := UL.Proof_lem_6_3.measureReal_union_le_add μ_cpl B_bad E_idealᶜ
      linarith
    have hB_tot_compl : 1 - ε₀ ≤ μ_cpl.real B_totᶜ := by
      have := UL.Proof_lem_6_3.probReal_compl_eq μ_cpl hB_tot_meas
      linarith
    have hsub_good : B_totᶜ ⊆ proj_bits ⁻¹' E_good := by
      intro ω_c hω_c
      have hnot_bad : ω_c ∈ B_badᶜ := fun h => hω_c (Or.inl h)
      have hin_ideal : ω_c ∈ E_ideal := by
        by_contra hnot; exact hω_c (Or.inr hnot)
      intro P q hP hqz hcompat
      exact hE_id_corr ω_c
        (fun idx => UL.ratPointToEuclidean (fun j =>
          sampleCoord (fun bitIdx => proj_bits ω_c (idx, j, bitIdx))))
        (τ_d : ℝ) (τ_q : ℝ) hin_ideal (h_agree_on_good ω_c hnot_bad) P q hP hqz hcompat
    have hmap_eq : ((PMF.uniformOfFintype (UL.ExplicitBitSeed R ℓ M₀ (d + 1) b)).toMeasure).real E_good =
        μ_cpl.real (proj_bits ⁻¹' E_good) := by
      rw [← map_projBitsMap_eq_uniform (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1) hb_pos]
      simp only [MeasureTheory.measureReal_def]
      rw [Measure.map_apply (measurable_projBitsMap hb_pos) MeasurableSet.of_discrete]
    rw [hmap_eq]
    exact hB_tot_compl.trans (MeasureTheory.measureReal_mono hsub_good)

/-! ### 5. Top-level assembly of Part 4 of `S_clm_6_1_precision` -/

theorem part4_proof
    {h_min h_max : ℝ} (_hh_min : 0 < h_min) (_hh_le : h_min ≤ h_max) (_hh_max : h_max < 1)
    {ℓ : ℕ} (hℓ : 1 ≤ ℓ)
    (h_lem_6_2_inst :
      ∃ c_h : ℝ, 0 < c_h ∧
        ∀ (d : ℕ), 1 ≤ d →
          ∀ (h x t : ℝ), h_min ≤ h → h ≤ h_max → h ≤ x → x ≤ 1 → 1 ≤ t →
            ∃ p_u p_q p₁ p₂ : ℝ,
              UL.IsGaussianFilterProbs d h x t p_u p_q p₁ p₂ ∧
              p_u ≤ Real.exp (-(t ^ 2 / 2)) ∧
              p_q ≤ Real.exp (-(x ^ 2 * t ^ 2 / 2)) ∧
              c_h * t ^ (-2 : ℤ) * Real.exp (-(UL.I_h h x * t ^ 2 / 2)) ≤ p₁ ∧
              p₂ ≤ Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))) :
    ∀ (C_net : ℝ), 0 ≤ C_net →
      ∃ (poly_prec poly_cap : ℕ → ℕ → ℝ),
        UL.IsBoundedByPoly2 poly_prec ∧
        UL.IsBoundedByPoly2 poly_cap ∧
        ∀ (d : ℕ), 1 ≤ d →
        ∀ (ι : Type) [DecidableEq ι] (gen : UL.SearchGeneration ι (d + 1)),
          h_min ≤ gen.h → gen.h ≤ h_max →
          ∀ (x η ε₀ : ℝ),
            gen.h ≤ x → x ≤ 1 →
            0 < η → η ≤ 1 →
            0 < ε₀ → ε₀ < 1 →
            ∀ (Q_net : List (EuclideanSpace ℝ (Fin (d + 1)))),
              (∀ z ∈ Q_net, UL.IsUnitVec z) →
              (Q_net.length : ℝ) ≤
                Real.exp (C_net * (d : ℝ) * Real.log (2 * (d : ℝ) / η)) →
              let L_log : ℕ :=
                Nat.ceil (Real.log (2 * (gen.m : ℝ) / ε₀) + Real.log (2 / η))
              ∃ (R M₀ cap_u cap_q b B_prec : ℕ) (t_ideal : ℝ) (τ_d τ_q : ℚ)
                (sampleCoord : (Fin b → Bool) → ℚ),
                1 ≤ R ∧ 1 ≤ M₀ ∧ 1 ≤ b ∧ 1 ≤ B_prec ∧ 1 ≤ t_ideal ∧
                (b : ℝ) ≤ poly_prec d L_log ∧
                (B_prec : ℝ) ≤ poly_prec d L_log ∧
                UL.RatCoordBitBounded B_prec τ_d ∧
                UL.RatCoordBitBounded B_prec τ_q ∧
                (∀ bits : Fin b → Bool, UL.RatCoordBitBounded B_prec (sampleCoord bits)) ∧
                ((R * ℓ * M₀ : ℕ) : ℝ) ≤
                  (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ)) * poly_cap d L_log ∧
                (cap_u : ℝ) ≤
                  (gen.m : ℝ) ^ (UL.u_search gen.h x) * poly_cap d L_log ∧
                (cap_q : ℝ) ≤
                  (gen.m : ℝ) ^ (UL.q_search gen.h x) * poly_cap d L_log ∧
                (∀ ω : UL.ExplicitBitSeed R ℓ M₀ (d + 1) b,
                  let F_disc : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
                    fun idx => UL.ratPointToEuclidean (fun j =>
                      sampleCoord (fun bitIdx => ω (idx, j, bitIdx)))
                  (∀ i ∈ gen.P₀,
                    (UL.explicitPointDataWork F_disc (τ_d : ℝ) cap_u gen.pts i : ℝ) ≤
                      ((gen.m : ℝ) ^ (UL.u_search gen.h x) +
                        (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log) ∧
                  ((UL.explicitIndexSpace F_disc (τ_d : ℝ) cap_u gen : ℝ) ≤
                    ((gen.m : ℝ) ^ (1 + UL.u_search gen.h x) +
                      (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log) ∧
                  (∀ (P : Finset ι) (q : UL.SearchQuery ι (d + 1)),
                    gen.IsSurvivingSubset P →
                    q.IsValidAnswer P
                      (UL.explicitCappedQuery F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q) ∧
                    (UL.explicitQueryWork F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q : ℝ) ≤
                      ((gen.m : ℝ) ^ (UL.q_search gen.h x) +
                        (gen.m : ℝ) ^ (UL.I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log)) ∧
                (∃ (Ω_cpl : Type) (mΩ : MeasurableSpace Ω_cpl)
                   (μ_cpl : @MeasureTheory.Measure Ω_cpl mΩ)
                   (proj_bits : Ω_cpl → UL.ExplicitBitSeed R ℓ M₀ (d + 1) b)
                   (proj_gauss :
                     Ω_cpl → (UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)))),
                  @MeasureTheory.IsProbabilityMeasure Ω_cpl mΩ μ_cpl ∧
                  @Measurable _ _ mΩ inferInstance proj_bits ∧
                  @Measurable _ _ mΩ inferInstance proj_gauss ∧
                  @MeasureTheory.Measure.map _ _ mΩ inferInstance proj_bits μ_cpl =
                    (PMF.uniformOfFintype (UL.ExplicitBitSeed R ℓ M₀ (d + 1) b)).toMeasure ∧
                  @MeasureTheory.Measure.map _ _ mΩ inferInstance proj_gauss μ_cpl =
                    MeasureTheory.Measure.pi
                      (fun _ : UL.ExplicitCapIdx R ℓ M₀ => UL.stdGaussianMeasure (d + 1)) ∧
                  1 - ε₀ / 2 ≤ (@MeasureTheory.Measure.real Ω_cpl mΩ μ_cpl) {ω_c : Ω_cpl |
                    ∀ idx : UL.ExplicitCapIdx R ℓ M₀,
                      let G_disc := UL.ratPointToEuclidean (fun j =>
                        sampleCoord (fun bitIdx => proj_bits ω_c (idx, j, bitIdx)))
                      let G_id := proj_gauss ω_c idx
                      (∀ i ∈ gen.P₀,
                        UL.gaussianDataTest (τ_d : ℝ) G_disc (gen.pts i) ↔
                          UL.gaussianDataTest t_ideal G_id (gen.pts i)) ∧
                      (∀ z ∈ Q_net,
                        UL.gaussianDataTest (τ_q : ℝ) G_disc z ↔
                          UL.gaussianQueryTest x t_ideal G_id z)}) ∧
                (∃ E_good : Set (UL.ExplicitBitSeed R ℓ M₀ (d + 1) b),
                  1 - ε₀ ≤
                    ((PMF.uniformOfFintype
                      (UL.ExplicitBitSeed R ℓ M₀ (d + 1) b)).toMeasure).real E_good ∧
                  ∀ ω ∈ E_good,
                    let F_disc : UL.ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
                      fun idx => UL.ratPointToEuclidean (fun j =>
                        sampleCoord (fun bitIdx => ω (idx, j, bitIdx)))
                    ∀ (P : Finset ι) (q : UL.SearchQuery ι (d + 1)),
                      gen.IsSurvivingSubset P →
                      q.z ∈ Q_net →
                      gen.IsCompatible P q →
                      gen.IsCorrectAnswer P q
                        (UL.explicitCappedQuery F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P q)) := by
  rcases h_lem_6_2_inst with ⟨c_h, hc_h_pos, h_lem_6_2_spec⟩
  intro C_net _hC_net
  have hCnet_le : C_net ≤ ((Nat.ceil C_net + 1 : ℕ) : ℝ) := by
    push_cast; linarith [Nat.le_ceil C_net]
  have hCM_ge : Real.log (100 * (ℓ : ℝ)) / c_h ≤
      ((Nat.ceil (Real.log (100 * (ℓ : ℝ)) / c_h) + 1 : ℕ) : ℝ) := by
    push_cast; linarith [Nat.le_ceil (Real.log (100 * (ℓ : ℝ)) / c_h)]
  set C_net_nat : ℕ := Nat.ceil C_net + 1
  clear_value C_net_nat
  set C_M_nat : ℕ := Nat.ceil (Real.log (100 * (ℓ : ℝ)) / c_h) + 1
  clear_value C_M_nat
  refine ⟨fun d L => (B_prec_fn ℓ C_net_nat C_M_nat d L : ℝ),
    poly_cap_fn ℓ C_net_nat C_M_nat,
    (nonnegPoly2_B_prec_fn ℓ C_net_nat C_M_nat).2,
    (nonnegPoly2_poly_cap_fn ℓ C_net_nat C_M_nat).2, ?_⟩
  intro d hd ι _instDec gen hh_ge hh_le_max x η ε₀ hx_ge hx_le hη_pos hη_le hε₀_pos hε₀_lt Q_net hQ_unit hQ_len L_log_let
  have hL_eq_let : L_log_let = Nat.ceil (Real.log (2 * (gen.m : ℝ) / ε₀) + Real.log (2 / η)) := rfl
  clear_value L_log_let
  have hm_pos : 1 ≤ gen.m := gen.nonempty.card_pos
  rcases part4_L_and_Q_bounds hd hm_pos hCnet_le hη_pos hη_le hε₀_pos hε₀_lt hQ_len hL_eq_let
    with ⟨_hL_pos, hm_2, hlog_m_le_L, h4_div_eps_le, hQ_pow2, h10R_le⟩
  rcases part4_threshold_bounds (C_net_nat := C_net_nat) (C_M_nat := C_M_nat) (d := d)
    hℓ hm_pos hlog_m_le_L
    with ⟨ht_ge1, ht_le_Lp2, hm_le_exp_lt2, hexp_lt2_le_Sm, hτ_d_bits⟩
  set τ_d : ℚ := τ_d_of ℓ gen.m L_log_let
  clear_value τ_d
  set t_ideal : ℝ := (τ_d : ℝ) with ht_d_eq_symm
  have ht_d_eq : (τ_d : ℝ) = t_ideal := ht_d_eq_symm.symm
  clear_value t_ideal
  rcases h_lem_6_2_spec (d + 1) (by omega) gen.h x t_ideal hh_ge hh_le_max hx_ge hx_le ht_ge1
    with ⟨p_u, p_q, p₁, p₂, hprobs, hp_u, hp_q, hp₁, hp₂⟩
  rcases gen.nonempty with ⟨i₀, hi₀⟩
  have hp_u_nn : 0 ≤ p_u := by
    rw [← hprobs.2.1 (gen.pts i₀) (gen.unit_pts i₀ hi₀)]
    exact MeasureTheory.measureReal_nonneg
  have hp_q_nn : 0 ≤ p_q := by
    rw [← hprobs.2.2.1 (gen.pts i₀) (gen.unit_pts i₀ hi₀)]
    exact MeasureTheory.measureReal_nonneg
  have hp₂_nn : 0 ≤ p₂ := by
    have hu0 : UL.IsUnitVec (gen.pts i₀) := gen.unit_pts i₀ hi₀
    have hu_neg : UL.IsUnitVec (-gen.pts i₀) := by
      unfold UL.IsUnitVec at hu0 ⊢; rw [norm_neg]; exact hu0
    have hneg_inner : inner ℝ (gen.pts i₀) (-gen.pts i₀) ≤ 0 := by
      rw [inner_neg_right, real_inner_self_eq_norm_sq, hu0]; norm_num
    exact MeasureTheory.measureReal_nonneg.trans
      (hprobs.2.2.2.2 (gen.pts i₀) (-gen.pts i₀) hu0 hu_neg hneg_inner)
  rcases part4_prob_cap_reqs hℓ hm_pos hc_h_pos hCM_ge ht_ge1 hm_le_exp_lt2
    hp_u_nn hp_q_nn hp₂_nn hp_u hp_q hp₁ hp₂
    with ⟨hp₁_pos, hp₁_M, hCap_u, hCap_q, hCap_bad⟩
  rcases part4_size_and_M0_bounds (C_net_nat := C_net_nat) (d := d)
    hℓ hm_pos gen.h_pos gen.h_lt_one hx_ge hx_le ht_ge1 ht_le_Lp2 hexp_lt2_le_Sm
    with ⟨hM₀_le_2EM, hRlM₀_le_KI, hcap_u_le_Ku, hcap_q_le_Kq⟩
  have hτ_q_bits : UL.RatCoordBitBounded (B_prec_fn ℓ C_net_nat C_M_nat d L_log_let)
      (τ_q_of (b_fn ℓ C_net_nat C_M_nat d L_log_let) x t_ideal) :=
    part4_τq_bits (le_trans gen.h_pos.le hx_ge) hx_le ht_ge1 ht_le_Lp2
  have hM₀_pos : 1 ≤ M₀_of C_M_nat gen.h x t_ideal := M₀_of_pos C_M_nat gen.h x t_ideal
  have hCap_u_pos : 1 ≤ cap_u_of ℓ (M₀_of C_M_nat gen.h x t_ideal) t_ideal :=
    cap_u_of_pos ℓ _ t_ideal
  have hCap_q_pos : 1 ≤ cap_q_of ℓ (M₀_of C_M_nat gen.h x t_ideal) x t_ideal :=
    cap_q_of_pos ℓ _ x t_ideal
  set M₀ : ℕ := M₀_of C_M_nat gen.h x t_ideal
  clear_value M₀
  set cap_u : ℕ := cap_u_of ℓ M₀ t_ideal
  clear_value cap_u
  set cap_q : ℕ := cap_q_of ℓ M₀ x t_ideal
  clear_value cap_q
  set τ_q : ℚ := τ_q_of (b_fn ℓ C_net_nat C_M_nat d L_log_let) x t_ideal with hτ_q_eq
  clear_value τ_q
  have hR_pos : 1 ≤ R_fn C_net_nat d L_log_let := R_fn_pos C_net_nat d L_log_let
  set R : ℕ := R_fn C_net_nat d L_log_let with hR_eq
  clear_value R
  rcases part4_det_bounds hℓ hCap_q_pos hR_eq gen (τ_d := τ_d) (τ_q := τ_q)
    (sampleCoord1D (b_fn ℓ C_net_nat C_M_nat d L_log_let) (T_fn ℓ C_net_nat C_M_nat d L_log_let))
    hRlM₀_le_KI hcap_u_le_Ku hcap_q_le_Kq
    with ⟨hRlM₀_le_pcap, hcap_u_le_pcap, hcap_q_le_pcap, h_det_all⟩
  rcases part4_bad_event_and_agree hR_eq hM₀_le_2EM gen hε₀_pos ht_d_eq hτ_q_eq
    hm_2 h4_div_eps_le Q_net hQ_unit hQ_pow2
    with ⟨B_bad, hB_bad_meas, hB_bad_prob, h_agree_on_good⟩
  rcases part4_prob_assembly hℓ hM₀_pos hCap_u_pos hCap_q_pos
    (b_fn_pos ℓ C_net_nat C_M_nat d L_log_let) gen
    (sampleCoord1D (b_fn ℓ C_net_nat C_M_nat d L_log_let) (T_fn ℓ C_net_nat C_M_nat d L_log_let))
    hprobs hp₁_pos hp₁_M hCap_u hCap_q hCap_bad Q_net hQ_unit h10R_le
    hB_bad_meas hB_bad_prob h_agree_on_good
    with ⟨h_cpl_exists, h_good_exists⟩
  exact ⟨R, M₀, cap_u, cap_q,
    b_fn ℓ C_net_nat C_M_nat d L_log_let,
    B_prec_fn ℓ C_net_nat C_M_nat d L_log_let,
    t_ideal, τ_d, τ_q,
    sampleCoord1D (b_fn ℓ C_net_nat C_M_nat d L_log_let) (T_fn ℓ C_net_nat C_M_nat d L_log_let),
    hR_pos, hM₀_pos,
    b_fn_pos ℓ C_net_nat C_M_nat d L_log_let,
    B_prec_fn_pos ℓ C_net_nat C_M_nat d L_log_let,
    ht_ge1,
    Nat.cast_le.mpr (b_fn_le_B_prec_fn ℓ C_net_nat C_M_nat d L_log_let),
    le_rfl,
    hτ_d_bits, hτ_q_bits,
    sampleCoord_fn_bitBounded ℓ C_net_nat C_M_nat d L_log_let,
    hRlM₀_le_pcap, hcap_u_le_pcap, hcap_q_le_pcap,
    h_det_all, h_cpl_exists, h_good_exists⟩

end UL.Proof_clm_6_1_precision_RaceV30
