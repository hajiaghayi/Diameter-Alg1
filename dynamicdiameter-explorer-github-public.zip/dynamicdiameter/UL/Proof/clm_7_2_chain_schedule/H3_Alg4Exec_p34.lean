import UL.Stmt.clm_7_2_chain_schedule
import UL.Stmt.claim_C_2_space_reclaim
import UL.Proof.clm_7_2_chain_schedule.H1_PolyAndSchedule

set_option autoImplicit false

namespace UL.Proof_clm_7_2_chain_schedule

open UL

def JobAtMostOneUnready {d : ℕ} {ι : Type} (job : Alg4PendingJob d ι) : Prop :=
  (job.completedPrefix.filter (fun lv => !lv.backgroundReady)).length ≤ 1

def StateAtMostOneUnready {d : ℕ} {ι : Type} (st : Alg4State d ι) : Prop :=
  ∀ sn ∈ st.servingNodes, ∀ job : Alg4PendingJob d ι,
    sn.ownedJob = some job → JobAtMostOneUnready job

private lemma filter_not_eq_nil_of_all {α : Type} (p : α → Bool) :
    ∀ xs : List α, xs.all p = true → xs.filter (fun x => !p x) = []
  | [], _ => rfl
  | x :: xs, hall => by
    simp only [List.all_cons, Bool.and_eq_true] at hall
    simp [List.filter, hall.1, filter_not_eq_nil_of_all p xs hall.2]

private lemma filter_cons_length_le {α : Type} (p : α → Bool) (a : α) (xs : List α) :
    ((a :: xs).filter p).length ≤ (xs.filter p).length + 1 := by
  simp only [List.filter_cons]
  split_ifs <;> simp

private lemma filter_cons_length_eq_of_eq {α : Type} (p : α → Bool) (a b : α) (xs ys : List α)
    (hab : p a = p b) (hxy : (xs.filter p).length = (ys.filter p).length) :
    ((a :: xs).filter p).length = ((b :: ys).filter p).length := by
  simp only [List.filter_cons, hab]
  split_ifs <;> simp [hxy]

open Classical in
private lemma line1Aux_preserves_unready {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    ∀ (activeEv : Option (PoolUpdateEvent ι)) (nodes : List (Alg4ServingNode d ι))
      (qList : List (NodeMatchingQueryAnswers ι)) (mHints : List (Option ι)),
      (∀ sn ∈ nodes, ∀ job, sn.ownedJob = some job → JobAtMostOneUnready job) →
      ∀ p ∈ (alg4Line1Aux pts mode activeEv nodes qList mHints).1,
        ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job
  | _, [], _, _, _, _, hp, _, _ => by simp [alg4Line1Aux] at hp
  | activeEv, sn :: rest, qList, mHints, hnodes, p, hp, job, hjob => by
    unfold alg4Line1Aux at hp
    dsimp only at hp
    rcases List.mem_cons.mp hp with hpeq | hrest
    · rw [hpeq] at hjob
      dsimp only at hjob
      have hjob' : sn.ownedJob = some job := by
        revert hjob
        cases activeEv.getD .unaffected <;> exact id
      exact hnodes sn List.mem_cons_self job hjob'
    · exact line1Aux_preserves_unready pts mode _ rest (qList.drop 1) (mHints.drop 1)
        (fun s hs => hnodes s (List.mem_cons_of_mem _ hs)) p hrest job hjob

open Classical in
private lemma line3Aux_filter_unready_len {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    ∀ (activeEv : Option (PoolUpdateEvent ι)) (pref : List (Alg4OpenedLevel d ι))
      (qList : List (NodeMatchingQueryAnswers ι)) (mHints : List (Option ι)),
      (((alg4Line3RoutePrefixAux pts mode activeEv pref qList mHints).1).filter
        (fun lv => !lv.backgroundReady)).length =
      (pref.filter (fun lv => !lv.backgroundReady)).length
  | _, [], _, _ => rfl
  | activeEv, lv :: rest, qList, mHints => by
    unfold alg4Line3RoutePrefixAux
    dsimp only
    apply filter_cons_length_eq_of_eq
    · cases activeEv.getD .unaffected <;> rfl
    · exact line3Aux_filter_unready_len pts mode _ rest (qList.drop 1) (mHints.drop 1)

open Classical in
private lemma stepPrefixConstruction_filter_unready_le {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    ∀ (S_lv : Finset ι) (pref : List (Alg4OpenedLevel d ι))
      (bSteps : List (PendingLevelBudgetChoices ι)),
      ((stepPrefixConstruction pts mode S_lv pref bSteps).filter
        (fun lv => !lv.backgroundReady)).length ≤
      (pref.filter (fun lv => !lv.backgroundReady)).length
  | _, [], _ => le_rfl
  | S_lv, lv :: rest, bSteps => by
    unfold stepPrefixConstruction
    dsimp only
    have ih := stepPrefixConstruction_filter_unready_le pts mode
      (lv.ball.residual pts S_lv) rest (bSteps.drop 1)
    by_cases hbr : lv.backgroundReady = true
    · simp only [hbr, ↓reduceIte, List.filter_cons, Bool.not_true, Bool.false_eq_true]
      exact ih
    · have hbr_f : lv.backgroundReady = false := Bool.eq_false_iff.mpr hbr
      have hrhs :
          ((lv :: rest).filter (fun x => !x.backgroundReady)).length =
            (rest.filter (fun x => !x.backgroundReady)).length + 1 := by
        simp [List.filter_cons, hbr_f]
      rw [hrhs]
      exact le_trans (filter_cons_length_le _ _ _) (Nat.add_le_add_right ih 1)

open Classical in
private lemma line5_preserves_unready {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (job : Alg4PendingJob d ι) (jc : PendingJobStepChoices d ι)
    (hjob : JobAtMostOneUnready job) :
    JobAtMostOneUnready (alg4Line5LateOpeningGate pts mode α L job jc) := by
  unfold alg4Line5LateOpeningGate
  by_cases hc : job.closedAsLeaf = true
  · simp [hc, hjob]
  · rw [if_neg hc]
    by_cases hall : job.completedPrefix.all (fun lv => lv.backgroundReady) = true
    · have hnot_all : (!(job.completedPrefix.all (fun lv => lv.backgroundReady))) = false := by
        simp [hall]
      rw [if_neg (by simp [hnot_all])]
      cases residualScheduleStep α L job.remainingTicks job.currentResidual.card with
      | wait => exact hjob
      | closeAsLeaf => exact hjob
      | openBallLevel =>
        by_cases hNE : job.currentResidual.Nonempty
        · rw [dif_pos hNE]
          unfold JobAtMostOneUnready
          dsimp only
          rw [List.filter_append, filter_not_eq_nil_of_all _ _ hall]
          simp
        · rw [dif_neg hNE]
          exact hjob
    · have hnot_all : (!(job.completedPrefix.all (fun lv => lv.backgroundReady))) = true := by
        cases h : job.completedPrefix.all (fun lv => lv.backgroundReady)
        · rfl
        · exact absurd h hall
      rw [if_pos hnot_all]
      exact hjob

open Classical in
private lemma lines2To6_preserves_unready {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ) :
    ∀ (S_cur' : Finset ι) (nodes1 : List (Alg4ServingNode d ι × PoolUpdateEvent ι))
      (jChoices : List (PendingJobStepChoices d ι)),
      (∀ p ∈ nodes1, ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job) →
      ∀ p ∈ alg4Lines2To6StepPendingJobs pts mode α L S_cur' nodes1 jChoices,
        ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job
  | _, [], _, _, _, hp, _, _ => by simp [alg4Lines2To6StepPendingJobs] at hp
  | S_cur', (sn, ev) :: rest, jChoices, hnodes, p, hp, job, hjob => by
    unfold alg4Lines2To6StepPendingJobs at hp
    dsimp only at hp
    rcases List.mem_cons.mp hp with hpeq | hrest
    · rw [hpeq] at hjob
      dsimp only at hjob
      by_cases htick : ev.isClockTick = true
      · rw [if_pos htick] at hjob
        cases hown : sn.ownedJob with
        | none =>
          rw [hown] at hjob
          simp [hown] at hjob
        | some job₀ =>
          rw [hown] at hjob
          simp only [Option.some.injEq] at hjob
          subst hjob
          let jc : PendingJobStepChoices d ι :=
            jChoices.head?.getD
              { prefixRouteQueries := []
                prefixRouteMaxHints := []
                prefixBudgetSteps := []
                openSampledCenter := .infeasible
                openFallbackBirthId := none
                leafHint := none }
          have hj₀ : JobAtMostOneUnready job₀ :=
            hnodes (sn, ev) List.mem_cons_self job₀ hown
          have hj₁ : JobAtMostOneUnready
              (alg4Line3RouteThroughPrefix pts mode job₀ ev S_cur' jc) := by
            unfold JobAtMostOneUnready alg4Line3RouteThroughPrefix
            dsimp only
            rw [line3Aux_filter_unready_len]
            exact hj₀
          have hj₂ : JobAtMostOneUnready
              (alg4Line4AdvanceClockAndBuild pts mode
                (alg4Line3RouteThroughPrefix pts mode job₀ ev S_cur' jc) S_cur' jc.prefixBudgetSteps) := by
            unfold JobAtMostOneUnready alg4Line4AdvanceClockAndBuild
            dsimp only
            exact le_trans (stepPrefixConstruction_filter_unready_le pts mode S_cur' _ _) hj₁
          exact line5_preserves_unready pts mode α L _ jc hj₂
      · rw [if_neg htick] at hjob
        exact hnodes (sn, ev) List.mem_cons_self job hjob
    · exact lines2To6_preserves_unready pts mode α L _ rest (jChoices.drop 1)
        (fun q hq => hnodes q (List.mem_cons_of_mem _ hq)) p hrest job hjob

open Classical in
private lemma lines7To8_preserves_unready {d : ℕ} {ι : Type} :
    ∀ (nodes26 : List (Alg4ServingNode d ι × Bool))
      (leaf : Finset ι) (leafAns : Option (ι × ι)) (leafSq : ℝ) (leafCh : Bool),
      (∀ p ∈ nodes26, ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job) →
      ∀ p ∈ (alg4Lines7To8InstallCompletedJobs nodes26 leaf leafAns leafSq leafCh).1,
        ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job
  | [], _, _, _, _, _, _, hp, _, _ => by simp [alg4Lines7To8InstallCompletedJobs] at hp
  | (sn, aff) :: rest, leaf, leafAns, leafSq, leafCh, hnodes, p, hp, job, hjob => by
    unfold alg4Lines7To8InstallCompletedJobs at hp
    cases hown : sn.ownedJob with
    | none =>
      rw [hown] at hp
      dsimp only at hp
      rcases List.mem_cons.mp hp with hpeq | hrest
      · rw [hpeq] at hjob
        exact hnodes (sn, aff) List.mem_cons_self job hjob
      · exact lines7To8_preserves_unready rest leaf leafAns leafSq leafCh
          (fun q hq => hnodes q (List.mem_cons_of_mem _ hq)) p hrest job hjob
    | some job₀ =>
      rw [hown] at hp
      dsimp only at hp
      by_cases hrdy : job₀.IsReadyToInstall
      · rw [if_pos hrdy] at hp
        dsimp only at hp
        rcases List.mem_map.mp hp with ⟨lv, _, hpeq⟩
        rw [← hpeq] at hjob
        simp [installOpenedLevelAsServingNode] at hjob
      · rw [if_neg hrdy] at hp
        dsimp only at hp
        rcases List.mem_cons.mp hp with hpeq | hrest
        · rw [hpeq] at hjob
          exact hnodes (sn, aff) List.mem_cons_self job hjob
        · exact lines7To8_preserves_unready rest leaf leafAns leafSq leafCh
            (fun q hq => hnodes q (List.mem_cons_of_mem _ hq)) p hrest job hjob

open Classical in
private lemma startDueJobs_preserves_unready {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (α : ℝ) (L : ℕ) :
    ∀ (S_cur : Finset ι) (nodes : List (Alg4ServingNode d ι × Bool))
      (leaf : Finset ι) (leafAns : Option (ι × ι)) (leafSq : ℝ) (leafCh : Bool),
      (∀ p ∈ nodes, ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job) →
      ∀ p ∈ (startDueServingJobsAux pts α L S_cur nodes leaf leafAns leafSq leafCh).1,
        ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job
  | _, [], _, _, _, _, _, _, hp, _, _ => by simp [startDueServingJobsAux] at hp
  | S_cur, (sn, nr) :: rest, leaf, leafAns, leafSq, leafCh, hnodes, p, hp, job, hjob => by
    unfold startDueServingJobsAux at hp
    by_cases hdue : sn.ownedJob.isNone ∧ jobStartAge α sn.birthSnapshot.card ≤ sn.age
    · rw [if_pos hdue] at hp
      cases hsched : scheduleJobStart α L S_cur.card with
      | startPendingJob _ =>
        rw [hsched] at hp
        dsimp only at hp
        rcases List.mem_cons.mp hp with hpeq | hrest
        · rw [hpeq] at hjob
          simp only [Option.some.injEq] at hjob
          subst hjob
          unfold JobAtMostOneUnready Alg4PendingJob.init
          simp
        · exact startDueJobs_preserves_unready pts α L _ rest leaf leafAns leafSq leafCh
            (fun q hq => hnodes q (List.mem_cons_of_mem _ hq)) p hrest job hjob
      | replaceImmediatelyByExactLeaf =>
        rw [hsched] at hp
        simp at hp
    · rw [if_neg hdue] at hp
      dsimp only at hp
      rcases List.mem_cons.mp hp with hpeq | hrest
      · rw [hpeq] at hjob
        exact hnodes (sn, nr) List.mem_cons_self job hjob
      · exact startDueJobs_preserves_unready pts α L _ rest leaf leafAns leafSq leafCh
          (fun q hq => hnodes q (List.mem_cons_of_mem _ hq)) p hrest job hjob

open Classical in
private lemma rebuildOversizedLeaf_ownedJob_none {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ) :
    ∀ (fuel : ℕ) (S_cur : Finset ι) (choices : List (LeafRebuildLevelChoices d ι))
      (p : Alg4ServingNode d ι × Bool),
      p ∈ (rebuildOversizedLeafAux pts mode α L fuel S_cur choices).1 →
      p.1.ownedJob = none
  | 0, _, _, _, hp => by simp [rebuildOversizedLeafAux] at hp
  | k + 1, S_cur, choices, p, hp => by
    unfold rebuildOversizedLeafAux at hp
    by_cases hleaf : IsResidualLeafSize L S_cur.card
    · simp [hleaf] at hp
    · rw [if_neg hleaf] at hp
      by_cases hNE : S_cur.Nonempty
      · rw [dif_pos hNE] at hp
        dsimp only at hp
        rcases List.mem_cons.mp hp with hpeq | hrest
        · rw [hpeq]
        · exact rebuildOversizedLeaf_ownedJob_none pts mode α L k _ (choices.drop 1) p hrest
      · rw [dif_neg hNE] at hp
        simp at hp

open Classical in
private lemma line10_preserves_unready {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    ∀ (S_cur : Finset ι) (nodes : List (Alg4ServingNode d ι × Bool))
      (samps : List (List ι)) (hints : List (Option ShellConfig)),
      (∀ p ∈ nodes, ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job) →
      ∀ sn ∈ alg4Line10RefreshAffectedCaches pts mode S_cur nodes samps hints,
        ∀ job, sn.ownedJob = some job → JobAtMostOneUnready job
  | _, [], _, _, _, _, hsn, _, _ => by simp [alg4Line10RefreshAffectedCaches] at hsn
  | S_cur, (sn, nr) :: rest, samps, hints, hnodes, sn', hsn', job, hjob => by
    unfold alg4Line10RefreshAffectedCaches at hsn'
    dsimp only at hsn'
    rcases List.mem_cons.mp hsn' with hsneq | hrest
    · rw [hsneq] at hjob
      have hjob' : sn.ownedJob = some job := by
        revert hjob
        cases nr <;> exact id
      exact hnodes (sn, nr) List.mem_cons_self job hjob'
    · exact line10_preserves_unready pts mode _ rest (samps.drop 1) (hints.drop 1)
        (fun q hq => hnodes q (List.mem_cons_of_mem _ hq)) sn' hrest job hjob

open Classical in
theorem alg4Step_preserves_unready {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ)
    (st : Alg4State d ι) (upd : Alg4PointUpdate d ι) (choices : Alg4StepChoices d ι)
    (hst : StateAtMostOneUnready st) :
    StateAtMostOneUnready (alg4Step mode α L reclaimMult st upd choices).1 := by
  unfold alg4Step StateAtMostOneUnready
  dsimp only
  set P' := applyAlg4PointSetUpdate st.activeSet upd
  set pts' := updateAlg4Coords st.coords upd
  set l1 := alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
  set nodes26 := alg4Lines2To6StepPendingJobs pts' mode α L P' l1.1 choices.pendingJobChoices
  set res78 := alg4Lines7To8InstallCompletedJobs nodes26 l1.2.1
      st.terminalLeafAnswer st.terminalLeafDistSq l1.2.2
  have h1 : ∀ p ∈ l1.1, ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job := by
    dsimp only [l1, alg4Line1ApplyToServingChain]
    exact line1Aux_preserves_unready pts' mode _ st.servingNodes _ _ hst
  have h26 := lines2To6_preserves_unready pts' mode α L P' l1.1 choices.pendingJobChoices h1
  have h78 := lines7To8_preserves_unready nodes26 l1.2.1
    st.terminalLeafAnswer st.terminalLeafDistSq l1.2.2 h26
  have h9 : ∀ p ∈ (alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
      res78.1 res78.2.1 res78.2.2.1 res78.2.2.2.1 res78.2.2.2.2.1
      choices.leafRebuildChoices choices.terminalLeafHint).1,
      ∀ job, p.1.ownedJob = some job → JobAtMostOneUnready job := by
    unfold alg4Line9StartDueJobsAndHandleLeaves
    dsimp only
    have hdue := startDueJobs_preserves_unready pts' α L P'
      res78.1 res78.2.1 res78.2.2.1 res78.2.2.2.1 res78.2.2.2.2.1 h78
    split_ifs with hgt hch
    · intro p hp job hjob
      rcases List.mem_append.mp hp with hp1 | hp2
      · exact hdue p hp1 job hjob
      · have hnone := rebuildOversizedLeaf_ownedJob_none pts' mode α L _ _
          choices.leafRebuildChoices p hp2
        rw [hnone] at hjob
        cases hjob
    · exact hdue
    · exact hdue
  exact line10_preserves_unready pts' mode P' _ choices.baselineSamples choices.matchingMaxHints h9

private lemma sum_map_le_length_mul {α : Type} (f : α → ℕ) (B : ℕ) :
    ∀ (xs : List α), (∀ x ∈ xs, f x ≤ B) → (xs.map f).sum ≤ xs.length * B
  | [], _ => by simp
  | x :: xs, h => by
    simp only [List.map_cons, List.sum_cons, List.length_cons]
    have hx : f x ≤ B := h x List.mem_cons_self
    have hxs : (xs.map f).sum ≤ xs.length * B :=
      sum_map_le_length_mul f B xs (fun y hy => h y (List.mem_cons_of_mem _ hy))
    calc f x + (xs.map f).sum
      _ ≤ B + xs.length * B := Nat.add_le_add hx hxs
      _ = (xs.length + 1) * B := by ring

theorem extract_reclaim_constants (h_reclaim : S_claim_C_2_space_reclaim) :
    ∃ (C_depth₀ C_batch₀ : ℝ),
      0 < C_depth₀ ∧ 0 < C_batch₀ ∧
      (∀ (d n : ℕ) (ι : Type) (mode : Alg4Mode)
         (α C : ℝ) (K₀ L reclaimMult D_out T : ℕ),
        2 ≤ n → 0 < α → α ≤ 1 → 0 ≤ C →
        SatisfiesLeafCutoffEq10 d n α C K₀ L →
        1 ≤ reclaimMult → 1 ≤ D_out →
          let D₀_orig : ℕ := ⌈C_depth₀ * α⁻¹ * Real.log (n : ℝ)⌉₊
          (∀ (upd : Fin T → Alg4PointUpdate d ι)
             (baseChoices : Fin T → Alg4StepChoices d ι),
            ∃ (choices : Fin T → Alg4StepChoices d ι)
              (st : Fin (T + 1) → Alg4State d ι)
              (ans : Fin T → Option (ι × ι) × ℝ),
              st 0 = Alg4State.empty d ι ∧
              (∀ t : Fin T,
                Alg4StepChoicesAgreeExceptScanBudgets (baseChoices t) (choices t) ∧
                Alg4ChoicesRespectScanBatchCap
                  ⌈C_batch₀ * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ (choices t) ∧
                alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
                  (st t.succ, ans t)) ∧
              ((∀ t : Fin T, IsValidAlg4PointUpdate n (st t.castSucc) (upd t)) →
                ∀ t : Fin T,
                  Alg4StepSatisfiesEq11Completion mode α L
                    (st t.castSucc) (upd t) (choices t))) ∧
          (∀ (st : Fin (T + 1) → Alg4State d ι)
             (ans : Fin T → Option (ι × ι) × ℝ)
             (upd : Fin T → Alg4PointUpdate d ι)
             (choices : Fin T → Alg4StepChoices d ι),
            st 0 = Alg4State.empty d ι →
            (∀ t : Fin T,
              IsValidAlg4PointUpdate n (st t.castSucc) (upd t) ∧
              Alg4StepSatisfiesEq11Completion mode α L (st t.castSucc) (upd t) (choices t) ∧
              (∀ r ∈ (choices t).stepExtraRetired, r.HasBoundedOutdegree D_out) ∧
              alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
                (st t.succ, ans t)) →
              ∀ s : Fin (T + 1),
                (st s).WellFormed n mode α L D_out ∧
                (∀ sn ∈ (st s).servingNodes,
                  IsValidServingNodeAge α sn.birthSnapshot.card sn.age ∧
                  sn.trueAge ≤ sn.age) ∧
                (st s).servingNodes.length ≤ D₀_orig ∧
                (st s).owningJobNodeCount ≤ D₀_orig ∧
                (∀ sn ∈ (st s).servingNodes, ∀ job : Alg4PendingJob d ι,
                  sn.ownedJob = some job → job.completedPrefix.length ≤ D₀_orig))) := by
  have hp1 : IsBoundedByPoly2 (fun _ _ => 1) :=
    ⟨1, 0, zero_le_one, fun _ _ => by norm_num⟩
  rcases h_reclaim (fun _ _ => 1) (fun _ _ => 1) (fun _ _ => 1) hp1 hp1 hp1 with
    ⟨C_depth₀, _, C_batch₀, _, _, _, hCd₀, _, hCb₀, _, _, _, _, _, _, _, _, _, _, hPart3⟩
  refine ⟨C_depth₀, C_batch₀, hCd₀, hCb₀, ?_⟩
  intro d n ι mode α C K₀ L reclaimMult D_out T hn hα_pos hα_le hC hEq10 hRec hDout
  have h3 := hPart3 d n ι mode α C 0 1 K₀ L reclaimMult D_out 0 T
    hn hα_pos hα_le hC hEq10 le_rfl le_rfl hRec hDout
  rcases h3 with ⟨_, _, hAch, hTraj⟩
  refine ⟨hAch, ?_⟩
  intro st ans upd choices hst0 hsteps s
  rcases hTraj st ans upd choices hst0 hsteps s with
    ⟨hwf, hage, hlen, hown, hpref, _, _, _, _, _⟩
  exact ⟨hwf, hage, hlen, hown, hpref⟩

open Classical in
theorem prove_part5
    {F_C F_K₀ F_L F_loc : ℕ → ℝ → List ℝ → ℝ}
    {C_depth₀ C_batch₀ : ℝ}
    (hCd₀ : 0 < C_depth₀) (hCb₀ : 0 < C_batch₀)
    (hReclaim3 :
      ∀ (d n : ℕ) (ι : Type) (mode : Alg4Mode)
         (α C : ℝ) (K₀ L reclaimMult D_out T : ℕ),
        2 ≤ n → 0 < α → α ≤ 1 → 0 ≤ C →
        SatisfiesLeafCutoffEq10 d n α C K₀ L →
        1 ≤ reclaimMult → 1 ≤ D_out →
          let D₀_orig : ℕ := ⌈C_depth₀ * α⁻¹ * Real.log (n : ℝ)⌉₊
          (∀ (upd : Fin T → Alg4PointUpdate d ι)
             (baseChoices : Fin T → Alg4StepChoices d ι),
            ∃ (choices : Fin T → Alg4StepChoices d ι)
              (st : Fin (T + 1) → Alg4State d ι)
              (ans : Fin T → Option (ι × ι) × ℝ),
              st 0 = Alg4State.empty d ι ∧
              (∀ t : Fin T,
                Alg4StepChoicesAgreeExceptScanBudgets (baseChoices t) (choices t) ∧
                Alg4ChoicesRespectScanBatchCap
                  ⌈C_batch₀ * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ (choices t) ∧
                alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
                  (st t.succ, ans t)) ∧
              ((∀ t : Fin T, IsValidAlg4PointUpdate n (st t.castSucc) (upd t)) →
                ∀ t : Fin T,
                  Alg4StepSatisfiesEq11Completion mode α L
                    (st t.castSucc) (upd t) (choices t))) ∧
          (∀ (st : Fin (T + 1) → Alg4State d ι)
             (ans : Fin T → Option (ι × ι) × ℝ)
             (upd : Fin T → Alg4PointUpdate d ι)
             (choices : Fin T → Alg4StepChoices d ι),
            st 0 = Alg4State.empty d ι →
            (∀ t : Fin T,
              IsValidAlg4PointUpdate n (st t.castSucc) (upd t) ∧
              Alg4StepSatisfiesEq11Completion mode α L (st t.castSucc) (upd t) (choices t) ∧
              (∀ r ∈ (choices t).stepExtraRetired, r.HasBoundedOutdegree D_out) ∧
              alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
                (st t.succ, ans t)) →
              ∀ s : Fin (T + 1),
                (st s).WellFormed n mode α L D_out ∧
                (∀ sn ∈ (st s).servingNodes,
                  IsValidServingNodeAge α sn.birthSnapshot.card sn.age ∧
                  sn.trueAge ≤ sn.age) ∧
                (st s).servingNodes.length ≤ D₀_orig ∧
                (st s).owningJobNodeCount ≤ D₀_orig ∧
                (∀ sn ∈ (st s).servingNodes, ∀ job : Alg4PendingJob d ι,
                  sn.ownedJob = some job → job.completedPrefix.length ≤ D₀_orig)))
    {d n : ℕ} {ι : Type} {α C : ℝ} {K₀ L : ℕ}
    (hn : 2 ≤ n) (hα_pos : 0 < α) (hα_lt : α < 1) (hC : 0 ≤ C)
    (hEq10 : SatisfiesLeafCutoffEq10 d n α C K₀ L) :
    let C_depth : ℝ := max 1 C_depth₀
    let C_batch : ℝ := max 1 C_batch₀
    let jobBudgetMult : ℝ := 256
    let P_nodes := mkPNodes C_depth
    let P_workFactor := mkPWorkFactor C_depth jobBudgetMult F_C F_K₀ F_L F_loc
    let D₀ : ℕ := ⌈C_depth * α⁻¹ * Real.log (2 * (n : ℝ))⌉₊
    ∀ (mode : Alg4Mode) (reclaimMult D_out T : ℕ),
      1 ≤ reclaimMult →
      1 ≤ D_out →
        (∀ (upd : Fin T → Alg4PointUpdate d ι)
           (baseChoices : Fin T → Alg4StepChoices d ι),
          ∃ (choices : Fin T → Alg4StepChoices d ι)
            (st : Fin (T + 1) → Alg4State d ι)
            (ans : Fin T → Option (ι × ι) × ℝ),
            st 0 = Alg4State.empty d ι ∧
            (∀ t : Fin T,
              ChainSchedChoicesAgreeOnNonBudget (baseChoices t) (choices t) ∧
              ChainSchedScanBatchCap
                ⌈C_batch * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ (choices t) ∧
              alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
                (st t.succ, ans t)) ∧
            ((∀ t : Fin T, IsValidAlg4PointUpdate n (st t.castSucc) (upd t)) →
              ∀ t : Fin T,
                ChainSchedEq11Step mode α L (st t.castSucc) (upd t) (choices t))) ∧
        (∀ (st : Fin (T + 1) → Alg4State d ι)
           (ans : Fin T → Option (ι × ι) × ℝ)
           (upd : Fin T → Alg4PointUpdate d ι)
           (choices : Fin T → Alg4StepChoices d ι),
          st 0 = Alg4State.empty d ι →
          (∀ t : Fin T,
            IsValidAlg4PointUpdate n (st t.castSucc) (upd t) ∧
            ChainSchedEq11Step mode α L (st t.castSucc) (upd t) (choices t) ∧
            (∀ r ∈ (choices t).stepExtraRetired, r.HasBoundedOutdegree D_out) ∧
            alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
              (st t.succ, ans t)) →
            ∀ s : Fin (T + 1),
              (st s).WellFormed n mode α L D_out ∧
              (∀ idx : Fin (st s).servingNodes.length,
                let sn := (st s).servingNodes[idx]
                let S_cur := (st s).servingInputAt idx.val
                IsValidServingNodeAge α sn.birthSnapshot.card sn.age ∧
                HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
                sn.trueAge ≤ sn.age ∧
                (sn.age < jobStartAge α sn.birthSnapshot.card → sn.ownedJob = none) ∧
                (∀ job : Alg4PendingJob d ι,
                  sn.ownedJob = some job →
                    job.completedPrefix.length ≤ D₀ ∧
                    (job.completedPrefix.filter (fun lv => !lv.backgroundReady)).length ≤ 1)) ∧
              (st s).servingNodes.length ≤ D₀ ∧
              (st s).owningReplacementJobCount ≤ D₀ ∧
              (st s).totalServingAndPendingNodes ≤ D₀ + D₀ ^ 2 ∧
              (∀ (logs : List ℝ) (A_n P_loc : ℝ),
                Real.log (2 * (n : ℝ)) ≤ 1 + (logs.map (max 0)).sum →
                C ≤ F_C d α logs →
                (K₀ : ℝ) ≤ F_K₀ d α logs →
                (L : ℝ) ≤ F_L d α logs →
                1 ≤ A_n →
                1 ≤ P_loc →
                P_loc ≤ F_loc d α logs →
                  ((D₀ : ℝ) ≤ P_nodes d α logs ∧
                   ((st s).totalServingAndPendingNodes : ℝ) ≤ P_nodes d α logs) ∧
                  (let perServingNodeBudget : ℝ :=
                     ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((K₀ : ℝ) + 1) + A_n * P_loc
                   let perPendingJobTickBudget : ℝ :=
                     prescribedJobTickBudget jobBudgetMult α (A_n * P_loc)
                   let levelOpenBudget : ℝ :=
                     C + ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((L : ℝ) + 1) + A_n * P_loc
                   let leafHandleAndRebuildBudget : ℝ :=
                     ((d : ℝ) + 1) * (((6 * L + 1 : ℕ) : ℝ) ^ 2) +
                       ((6 * L + 1 : ℕ) : ℝ) * (C + A_n * P_loc)
                   perServingNodeBudget + perPendingJobTickBudget +
                     levelOpenBudget + leafHandleAndRebuildBudget +
                     ((D₀ + 1 : ℕ) : ℝ) *
                       (perServingNodeBudget + perPendingJobTickBudget + levelOpenBudget) ≤
                       A_n * P_workFactor d α logs))) := by
  dsimp only
  intro mode reclaimMult D_out T hRec hDout
  set C_depth : ℝ := max 1 C_depth₀
  set C_batch : ℝ := max 1 C_batch₀
  set D₀ : ℕ := ⌈C_depth * α⁻¹ * Real.log (2 * (n : ℝ))⌉₊
  set D₀_orig : ℕ := ⌈C_depth₀ * α⁻¹ * Real.log (n : ℝ)⌉₊
  have hCd_ge1 : 1 ≤ C_depth := le_max_left 1 C_depth₀
  have hCd_ge0 : C_depth₀ ≤ C_depth := le_max_right 1 C_depth₀
  have hCb_ge0 : C_batch₀ ≤ C_batch := le_max_right 1 C_batch₀
  have hn_cast : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have hlog_nn : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg (by linarith)
  have hlog_le : Real.log (n : ℝ) ≤ Real.log (2 * (n : ℝ)) :=
    Real.log_le_log (by linarith) (by linarith)
  have hα_inv_nn : 0 ≤ α⁻¹ := inv_nonneg.mpr (le_of_lt hα_pos)
  have hD₀_le : D₀_orig ≤ D₀ := by
    apply Nat.ceil_mono
    have h1 : C_depth₀ * α⁻¹ ≤ C_depth * α⁻¹ :=
      mul_le_mul_of_nonneg_right hCd_ge0 hα_inv_nn
    exact mul_le_mul h1 hlog_le hlog_nn (by positivity)
  have hBatch_le :
      ⌈C_batch₀ * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ ≤
        ⌈C_batch * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ := by
    apply Nat.ceil_mono
    have hcs : (0 : ℝ) ≤ (scheduleCStar : ℝ) := by unfold scheduleCStar; norm_num
    have ha2 : 0 ≤ (α ^ 2)⁻¹ := by positivity
    exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hCb_ge0 hcs) ha2
  rcases hReclaim3 d n ι mode α C K₀ L reclaimMult D_out T
      hn hα_pos (le_of_lt hα_lt) hC hEq10 hRec hDout with ⟨hAch, hTraj⟩
  refine ⟨?_, ?_⟩
  · intro upd baseChoices
    rcases hAch upd baseChoices with ⟨choices, st, ans, hst0, hstep_c, heq11⟩
    refine ⟨choices, st, ans, hst0, ?_, heq11⟩
    intro t
    rcases hstep_c t with ⟨hagr, hcap, hst_eq⟩
    refine ⟨hagr, ?_, hst_eq⟩
    intro jc hjc bStep hbStep
    rcases hcap jc hjc bStep hbStep with ⟨hc1, hc2⟩
    exact ⟨le_trans hc1 hBatch_le, le_trans hc2 hBatch_le⟩
  · intro st ans upd choices hst0 hsteps
    have hUnready : ∀ s : Fin (T + 1), StateAtMostOneUnready (st s) := by
      refine Fin.induction ?_ ?_
      · rw [hst0]
        intro sn hsn
        simp [Alg4State.empty] at hsn
      · intro t ih
        have hst_eq : (alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t)).1 =
            st t.succ := by
          rw [(hsteps t).2.2.2]
        rw [← hst_eq]
        exact alg4Step_preserves_unready mode α L reclaimMult (st t.castSucc) (upd t) (choices t) ih
    intro s
    rcases hTraj st ans upd choices hst0 hsteps s with
      ⟨hwf, hage_all, hlen_orig, hown_orig, hpref_orig⟩
    have hlen_D₀ : (st s).servingNodes.length ≤ D₀ := le_trans hlen_orig hD₀_le
    have hown_D₀ : (st s).owningReplacementJobCount ≤ D₀ := le_trans hown_orig hD₀_le
    have htot_D₀ : (st s).totalServingAndPendingNodes ≤ D₀ + D₀ ^ 2 := by
      unfold Alg4State.totalServingAndPendingNodes
      have hmap_le : ((st s).servingNodes.map (fun sn =>
          match sn.ownedJob with
          | none => 0
          | some job => job.completedPrefix.length)).sum ≤
            (st s).servingNodes.length * D₀ := by
        apply sum_map_le_length_mul
        intro sn hsn
        cases hown : sn.ownedJob with
        | none => exact Nat.zero_le D₀
        | some job => exact le_trans (hpref_orig sn hsn job hown) hD₀_le
      have hmul_le : (st s).servingNodes.length * D₀ ≤ D₀ ^ 2 := by
        rw [sq]
        exact Nat.mul_le_mul_right D₀ hlen_D₀
      exact Nat.add_le_add hlen_D₀ (le_trans hmap_le hmul_le)
    refine ⟨hwf, ?_, hlen_D₀, hown_D₀, htot_D₀, ?_⟩
    · intro idx
      set sn := (st s).servingNodes[idx]
      set S_cur := (st s).servingInputAt idx.val
      have hsn_mem : sn ∈ (st s).servingNodes := List.getElem_mem idx.isLt
      have hsn_wf : sn.WellFormed mode α L (st s).coords S_cur := hwf.2.2.2.2.1 idx
      rcases hage_all sn hsn_mem with ⟨hvalid_age, htrue_le⟩
      have hhas_age : HasNodeAge sn.birthSnapshot S_cur sn.trueAge := hsn_wf.2.2.1
      have hno_job : sn.age < jobStartAge α sn.birthSnapshot.card → sn.ownedJob = none := by
        intro hlt
        have hsched := hsn_wf.1.2.2.2
        dsimp only [Alg4ServingNode.toServingNodeState] at hsched
        rw [if_pos hlt] at hsched
        cases hown : sn.ownedJob with
        | none => rfl
        | some j => simp [hown] at hsched
      refine ⟨hvalid_age, hhas_age, htrue_le, hno_job, ?_⟩
      intro job hjob
      exact ⟨le_trans (hpref_orig sn hsn_mem job hjob) hD₀_le,
        hUnready s sn hsn_mem job hjob⟩
    · intro logs A_n P_loc hlog hC_le hK_le hL_le hAn hPloc_ge hPloc_le
      have hD_le_bnd : (D₀ : ℝ) ≤ mkDBound C_depth d α logs :=
        ceil_depth_le_mkDBound hCd_ge1 hn hα_pos hlog
      have h1_bnd : 1 ≤ mkDBound C_depth d α logs :=
        one_le_mkDBound hCd_ge1 d α logs
      have hD_nn : (0 : ℝ) ≤ (D₀ : ℝ) := Nat.cast_nonneg D₀
      have hD_le_Pnodes : (D₀ : ℝ) ≤ mkPNodes C_depth d α logs := by
        unfold mkPNodes
        nlinarith
      have htot_le_Pnodes : ((st s).totalServingAndPendingNodes : ℝ) ≤
          mkPNodes C_depth d α logs := by
        have hcast : ((st s).totalServingAndPendingNodes : ℝ) ≤ (D₀ : ℝ) + (D₀ : ℝ) ^ 2 := by
          exact_mod_cast htot_D₀
        unfold mkPNodes
        nlinarith
      have hwork := work_budget_le_mkPWorkFactor hCd_ge1 (by norm_num : (0 : ℝ) < 256)
        hn hα_pos hC hlog hC_le hK_le hL_le hAn hPloc_ge hPloc_le
      exact ⟨⟨hD_le_Pnodes, htot_le_Pnodes⟩, hwork⟩

end UL.Proof_clm_7_2_chain_schedule
