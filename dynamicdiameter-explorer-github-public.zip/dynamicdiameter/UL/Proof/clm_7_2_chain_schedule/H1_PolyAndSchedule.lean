import UL.Stmt.clm_7_2_chain_schedule
import UL.Proof.lem_C_2.H1
set_option autoImplicit false

namespace UL.Proof_clm_7_2_chain_schedule

open UL

noncomputable section

/-! ### 1. Closure algebra for `IsPolyInAlphaInvDimLogs` -/

lemma logsMaxSum_nonneg (logs : List ℝ) : 0 ≤ (logs.map (max 0)).sum := by
  apply List.sum_nonneg
  intro x hx
  rcases List.mem_map.mp hx with ⟨a, _, rfl⟩
  exact le_max_left 0 a

private def polyBase (d : ℕ) (α : ℝ) (logs : List ℝ) : ℝ :=
  (α⁻¹ + 1) * (d + 1 : ℝ) * (1 + (logs.map (max 0)).sum)

private lemma polyBase_pow_eq (C : ℝ) (d deg : ℕ) (α : ℝ) (logs : List ℝ) :
    C * ((α⁻¹ + 1) ^ deg) * ((d + 1 : ℝ) ^ deg) * ((1 + (logs.map (max 0)).sum) ^ deg) =
      C * (polyBase d α logs) ^ deg := by
  unfold polyBase
  rw [mul_pow, mul_pow]
  ring

private lemma one_le_polyBase (d : ℕ) {α : ℝ} (hα : 0 < α) (logs : List ℝ) :
    1 ≤ polyBase d α logs := by
  unfold polyBase
  have h1 : 1 ≤ α⁻¹ + 1 := by
    have : 0 < α⁻¹ := inv_pos.mpr hα
    linarith
  have h2 : 1 ≤ (d + 1 : ℝ) := by
    have : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
    linarith
  have h3 : 1 ≤ 1 + (logs.map (max 0)).sum := by
    have := logsMaxSum_nonneg logs
    linarith
  have h12 : 1 ≤ (α⁻¹ + 1) * (d + 1 : ℝ) := by nlinarith
  nlinarith

private lemma one_le_polyBase_pow (d deg : ℕ) {α : ℝ} (hα : 0 < α) (logs : List ℝ) :
    1 ≤ (polyBase d α logs) ^ deg :=
  one_le_pow₀ (one_le_polyBase d hα logs)

lemma isPoly_const (c : ℝ) : IsPolyInAlphaInvDimLogs (fun _ _ _ => c) := by
  refine ⟨max 0 c, 0, le_max_left 0 c, fun d α logs _ _ => ?_⟩
  simp [le_max_right 0 c]

lemma isPoly_max_zero {F : ℕ → ℝ → List ℝ → ℝ} (hF : IsPolyInAlphaInvDimLogs F) :
    IsPolyInAlphaInvDimLogs (fun d α logs => max 0 (F d α logs)) := by
  rcases hF with ⟨CF, deg, hCF, hFb⟩
  refine ⟨CF, deg, hCF, fun d α logs hα_pos hα_lt => ?_⟩
  rw [polyBase_pow_eq]
  have hb := hFb d α logs hα_pos hα_lt
  rw [polyBase_pow_eq] at hb
  have h0 : 0 ≤ CF * (polyBase d α logs) ^ deg :=
    mul_nonneg hCF (le_trans zero_le_one (one_le_polyBase_pow d deg hα_pos logs))
  exact max_le h0 hb

lemma isPoly_max_one {F : ℕ → ℝ → List ℝ → ℝ} (hF : IsPolyInAlphaInvDimLogs F) :
    IsPolyInAlphaInvDimLogs (fun d α logs => max 1 (F d α logs)) := by
  rcases hF with ⟨CF, deg, _, hFb⟩
  refine ⟨max 1 CF, deg, by positivity, fun d α logs hα_pos hα_lt => ?_⟩
  rw [polyBase_pow_eq]
  have hb := hFb d α logs hα_pos hα_lt
  rw [polyBase_pow_eq] at hb
  have hpow := one_le_polyBase_pow d deg hα_pos logs
  have h1 : 1 ≤ max 1 CF * (polyBase d α logs) ^ deg := by
    have : (1 : ℝ) ≤ max 1 CF := le_max_left 1 CF
    nlinarith
  have h2 : CF * (polyBase d α logs) ^ deg ≤ max 1 CF * (polyBase d α logs) ^ deg :=
    mul_le_mul_of_nonneg_right (le_max_right 1 CF) (by linarith)
  exact max_le h1 (hb.trans h2)

lemma isPoly_add {F G : ℕ → ℝ → List ℝ → ℝ}
    (hF : IsPolyInAlphaInvDimLogs F) (hG : IsPolyInAlphaInvDimLogs G) :
    IsPolyInAlphaInvDimLogs (fun d α logs => F d α logs + G d α logs) := by
  rcases hF with ⟨CF, dF, hCF, hFb⟩
  rcases hG with ⟨CG, dG, hCG, hGb⟩
  refine ⟨CF + CG, max dF dG, add_nonneg hCF hCG, fun d α logs hα_pos hα_lt => ?_⟩
  rw [polyBase_pow_eq]
  have hbF := hFb d α logs hα_pos hα_lt
  have hbG := hGb d α logs hα_pos hα_lt
  rw [polyBase_pow_eq] at hbF hbG
  have hbase := one_le_polyBase d hα_pos logs
  have hpF : (polyBase d α logs) ^ dF ≤ (polyBase d α logs) ^ max dF dG :=
    pow_le_pow_right₀ hbase (le_max_left dF dG)
  have hpG : (polyBase d α logs) ^ dG ≤ (polyBase d α logs) ^ max dF dG :=
    pow_le_pow_right₀ hbase (le_max_right dF dG)
  have hF' : F d α logs ≤ CF * (polyBase d α logs) ^ max dF dG :=
    hbF.trans (mul_le_mul_of_nonneg_left hpF hCF)
  have hG' : G d α logs ≤ CG * (polyBase d α logs) ^ max dF dG :=
    hbG.trans (mul_le_mul_of_nonneg_left hpG hCG)
  linarith

lemma isPoly_mul {F G : ℕ → ℝ → List ℝ → ℝ}
    (hF : IsPolyInAlphaInvDimLogs F) (hG : IsPolyInAlphaInvDimLogs G)
    (hF_nn : ∀ d α logs, 0 < α → α < 1 → 0 ≤ F d α logs)
    (hG_nn : ∀ d α logs, 0 < α → α < 1 → 0 ≤ G d α logs) :
    IsPolyInAlphaInvDimLogs (fun d α logs => F d α logs * G d α logs) := by
  rcases hF with ⟨CF, dF, hCF, hFb⟩
  rcases hG with ⟨CG, dG, hCG, hGb⟩
  refine ⟨CF * CG, dF + dG, mul_nonneg hCF hCG, fun d α logs hα_pos hα_lt => ?_⟩
  rw [polyBase_pow_eq, pow_add]
  have hbF := hFb d α logs hα_pos hα_lt
  have hbG := hGb d α logs hα_pos hα_lt
  rw [polyBase_pow_eq] at hbF hbG
  have hR_nn : 0 ≤ CG * (polyBase d α logs) ^ dG :=
    mul_nonneg hCG (le_trans zero_le_one (one_le_polyBase_pow d dG hα_pos logs))
  have hmul := mul_le_mul hbF hbG (hG_nn d α logs hα_pos hα_lt)
    (le_trans (hF_nn d α logs hα_pos hα_lt) hbF)
  linarith [show (CF * (polyBase d α logs) ^ dF) * (CG * (polyBase d α logs) ^ dG) =
    CF * CG * ((polyBase d α logs) ^ dF * (polyBase d α logs) ^ dG) by ring]

lemma isPoly_alphaInv : IsPolyInAlphaInvDimLogs (fun _ α _ => max 0 α⁻¹) := by
  refine ⟨1, 1, zero_le_one, fun d α logs hα_pos _ => ?_⟩
  simp only [pow_one, one_mul]
  have h0 : 0 ≤ α⁻¹ := inv_nonneg.mpr (le_of_lt hα_pos)
  rw [max_eq_right h0]
  have h1 : α⁻¹ ≤ α⁻¹ + 1 := by linarith
  have h2 : 1 ≤ (d + 1 : ℝ) := by
    have : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
    linarith
  have h3 : 1 ≤ 1 + (logs.map (max 0)).sum := by
    have := logsMaxSum_nonneg logs
    linarith
  have h23 : 1 ≤ (d + 1 : ℝ) * (1 + (logs.map (max 0)).sum) := by nlinarith
  have hprod : (α⁻¹ + 1) * 1 ≤ (α⁻¹ + 1) * ((d + 1 : ℝ) * (1 + (logs.map (max 0)).sum)) :=
    mul_le_mul_of_nonneg_left h23 (by linarith)
  linarith [show (α⁻¹ + 1) * ((d + 1 : ℝ) * (1 + (logs.map (max 0)).sum)) =
    (α⁻¹ + 1) * (d + 1 : ℝ) * (1 + (logs.map (max 0)).sum) by ring]

lemma isPoly_dim : IsPolyInAlphaInvDimLogs (fun d _ _ => (d : ℝ) + 1) := by
  refine ⟨1, 1, zero_le_one, fun d α logs hα_pos _ => ?_⟩
  simp only [pow_one, one_mul]
  have h1 : 1 ≤ α⁻¹ + 1 := by
    have : 0 < α⁻¹ := inv_pos.mpr hα_pos
    linarith
  have h2 : 0 ≤ (d + 1 : ℝ) := by positivity
  have h3 : 1 ≤ 1 + (logs.map (max 0)).sum := by
    have := logsMaxSum_nonneg logs
    linarith
  have h13 : 1 ≤ (α⁻¹ + 1) * (1 + (logs.map (max 0)).sum) := by nlinarith
  have hprod : (d + 1 : ℝ) * 1 ≤ (d + 1 : ℝ) * ((α⁻¹ + 1) * (1 + (logs.map (max 0)).sum)) :=
    mul_le_mul_of_nonneg_left h13 h2
  linarith [show (d + 1 : ℝ) * ((α⁻¹ + 1) * (1 + (logs.map (max 0)).sum)) =
    (α⁻¹ + 1) * (d + 1 : ℝ) * (1 + (logs.map (max 0)).sum) by ring]

lemma isPoly_logsSum : IsPolyInAlphaInvDimLogs (fun _ _ logs => 1 + (logs.map (max 0)).sum) := by
  refine ⟨1, 1, zero_le_one, fun d α logs hα_pos _ => ?_⟩
  simp only [pow_one, one_mul]
  have h1 : 1 ≤ α⁻¹ + 1 := by
    have : 0 < α⁻¹ := inv_pos.mpr hα_pos
    linarith
  have h2 : 1 ≤ (d + 1 : ℝ) := by
    have : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
    linarith
  have h3 : 0 ≤ 1 + (logs.map (max 0)).sum := by
    have := logsMaxSum_nonneg logs
    linarith
  have h12 : 1 ≤ (α⁻¹ + 1) * (d + 1 : ℝ) := by nlinarith
  have hprod : 1 * (1 + (logs.map (max 0)).sum) ≤
      ((α⁻¹ + 1) * (d + 1 : ℝ)) * (1 + (logs.map (max 0)).sum) :=
    mul_le_mul_of_nonneg_right h12 h3
  linarith

/-! ### 2. Explicit `P_nodes` and `P_workFactor` families -/

def mkDBound (C_depth : ℝ) (_d : ℕ) (α : ℝ) (logs : List ℝ) : ℝ :=
  C_depth * max 0 α⁻¹ * (1 + (logs.map (max 0)).sum) + 1

def mkPNodes (C_depth : ℝ) (d : ℕ) (α : ℝ) (logs : List ℝ) : ℝ :=
  mkDBound C_depth d α logs + mkDBound C_depth d α logs * mkDBound C_depth d α logs

lemma one_le_mkDBound {C_depth : ℝ} (hCd : 1 ≤ C_depth) (d : ℕ) (α : ℝ) (logs : List ℝ) :
    1 ≤ mkDBound C_depth d α logs := by
  unfold mkDBound
  have h1 : 0 ≤ C_depth := by linarith
  have h2 : 0 ≤ max 0 α⁻¹ := le_max_left 0 α⁻¹
  have h3 : 0 ≤ 1 + (logs.map (max 0)).sum := by
    have := logsMaxSum_nonneg logs
    linarith
  have hprod : 0 ≤ C_depth * max 0 α⁻¹ * (1 + (logs.map (max 0)).sum) := by positivity
  linarith

lemma mkDBound_isPoly {C_depth : ℝ} (hCd : 1 ≤ C_depth) :
    IsPolyInAlphaInvDimLogs (mkDBound C_depth) := by
  unfold mkDBound
  have hp1 := isPoly_mul (isPoly_const C_depth) isPoly_alphaInv
    (fun _ _ _ _ _ => by linarith) (fun _ _ _ _ _ => le_max_left 0 _)
  have hp2 := isPoly_mul hp1 isPoly_logsSum
    (fun _ _ _ _ _ => mul_nonneg (by linarith) (le_max_left 0 _))
    (fun _ _ logs _ _ => by have := logsMaxSum_nonneg logs; linarith)
  exact isPoly_add hp2 (isPoly_const 1)

lemma one_le_mkPNodes {C_depth : ℝ} (hCd : 1 ≤ C_depth) (d : ℕ) (α : ℝ) (logs : List ℝ) :
    1 ≤ mkPNodes C_depth d α logs := by
  unfold mkPNodes
  have hD := one_le_mkDBound hCd d α logs
  nlinarith

lemma mkPNodes_isPoly {C_depth : ℝ} (hCd : 1 ≤ C_depth) :
    IsPolyInAlphaInvDimLogs (mkPNodes C_depth) := by
  unfold mkPNodes
  have hD := mkDBound_isPoly hCd
  have hnn : ∀ d α logs, 0 < α → α < 1 → 0 ≤ mkDBound C_depth d α logs :=
    fun d α logs _ _ => le_trans zero_le_one (one_le_mkDBound hCd d α logs)
  exact isPoly_add hD (isPoly_mul hD hD hnn hnn)

lemma ceil_depth_le_mkDBound {C_depth α : ℝ} {n d : ℕ} {logs : List ℝ}
    (hCd : 1 ≤ C_depth) (hn : 2 ≤ n) (hα : 0 < α)
    (hlog : Real.log (2 * (n : ℝ)) ≤ 1 + (logs.map (max 0)).sum) :
    ((⌈C_depth * α⁻¹ * Real.log (2 * (n : ℝ))⌉₊ : ℕ) : ℝ) ≤ mkDBound C_depth d α logs := by
  have hn_cast : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have hlog_nn : 0 ≤ Real.log (2 * (n : ℝ)) := Real.log_nonneg (by linarith)
  have hα_inv_nn : 0 ≤ α⁻¹ := inv_nonneg.mpr (le_of_lt hα)
  have hx_nn : 0 ≤ C_depth * α⁻¹ * Real.log (2 * (n : ℝ)) := by positivity
  have hceil : ((⌈C_depth * α⁻¹ * Real.log (2 * (n : ℝ))⌉₊ : ℕ) : ℝ) ≤
      C_depth * α⁻¹ * Real.log (2 * (n : ℝ)) + 1 :=
    le_of_lt (Nat.ceil_lt_add_one hx_nn)
  unfold mkDBound
  rw [max_eq_right hα_inv_nn]
  have hmul : C_depth * α⁻¹ * Real.log (2 * (n : ℝ)) ≤
      C_depth * α⁻¹ * (1 + (logs.map (max 0)).sum) :=
    mul_le_mul_of_nonneg_left hlog (by positivity)
  linarith

noncomputable def mkPWorkFactor
    (C_depth jobBudgetMult : ℝ)
    (F_C F_K₀ F_L F_loc : ℕ → ℝ → List ℝ → ℝ)
    (d : ℕ) (α : ℝ) (logs : List ℝ) : ℝ :=
  let dimLog : ℝ := ((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)
  let gC : ℝ := max 0 (F_C d α logs)
  let gK : ℝ := max 0 (F_K₀ d α logs)
  let gL : ℝ := max 0 (F_L d α logs)
  let gLoc : ℝ := max 1 (F_loc d α logs)
  let aInv : ℝ := max 0 α⁻¹
  let sixL : ℝ := 6 * gL + 1
  let wServ : ℝ := dimLog * (gK + 1) + gLoc
  let wPend : ℝ := jobBudgetMult * (scheduleCStar : ℝ) * (aInv * aInv) * gLoc
  let wOpen : ℝ := gC + dimLog * (gL + 1) + gLoc
  let wLeaf : ℝ := ((d : ℝ) + 1) * (sixL * sixL) + sixL * (gC + gLoc)
  let dBnd : ℝ := mkDBound C_depth d α logs
  wServ + wPend + wOpen + wLeaf + (dBnd + 1) * (wServ + wPend + wOpen)

lemma one_le_mkPWorkFactor
    {C_depth jobBudgetMult : ℝ}
    (hCd : 1 ≤ C_depth) (hjb : 0 < jobBudgetMult)
    (F_C F_K₀ F_L F_loc : ℕ → ℝ → List ℝ → ℝ)
    (d : ℕ) (α : ℝ) (logs : List ℝ) :
    1 ≤ mkPWorkFactor C_depth jobBudgetMult F_C F_K₀ F_L F_loc d α logs := by
  unfold mkPWorkFactor
  dsimp only
  have hdim : 0 ≤ ((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum) := by
    have := logsMaxSum_nonneg logs
    positivity
  have hgC : 0 ≤ max 0 (F_C d α logs) := le_max_left 0 _
  have hgK : 0 ≤ max 0 (F_K₀ d α logs) := le_max_left 0 _
  have hgL : 0 ≤ max 0 (F_L d α logs) := le_max_left 0 _
  have hgLoc : 1 ≤ max 1 (F_loc d α logs) := le_max_left 1 _
  have haInv : 0 ≤ max 0 α⁻¹ := le_max_left 0 _
  have hdBnd : 1 ≤ mkDBound C_depth d α logs := one_le_mkDBound hCd d α logs
  have hwServ : 1 ≤ (((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) *
      (max 0 (F_K₀ d α logs) + 1) + max 1 (F_loc d α logs) := by
    have : 0 ≤ (((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) *
        (max 0 (F_K₀ d α logs) + 1) := by positivity
    linarith
  have hwPend : 0 ≤ jobBudgetMult * (scheduleCStar : ℝ) *
      (max 0 α⁻¹ * max 0 α⁻¹) * max 1 (F_loc d α logs) := by
    unfold scheduleCStar; positivity
  have hwOpen : 0 ≤ max 0 (F_C d α logs) +
      (((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) * (max 0 (F_L d α logs) + 1) +
      max 1 (F_loc d α logs) := by positivity
  have hwLeaf : 0 ≤ ((d : ℝ) + 1) *
      ((6 * max 0 (F_L d α logs) + 1) * (6 * max 0 (F_L d α logs) + 1)) +
      (6 * max 0 (F_L d α logs) + 1) * (max 0 (F_C d α logs) + max 1 (F_loc d α logs)) := by
    positivity
  have hprod : 0 ≤ (mkDBound C_depth d α logs + 1) *
      ((((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) * (max 0 (F_K₀ d α logs) + 1) +
        max 1 (F_loc d α logs) +
       jobBudgetMult * (scheduleCStar : ℝ) * (max 0 α⁻¹ * max 0 α⁻¹) *
        max 1 (F_loc d α logs) +
       (max 0 (F_C d α logs) +
        (((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) * (max 0 (F_L d α logs) + 1) +
        max 1 (F_loc d α logs))) := by positivity
  linarith

lemma mkPWorkFactor_isPoly
    {C_depth jobBudgetMult : ℝ}
    (hCd : 1 ≤ C_depth) (hjb : 0 < jobBudgetMult)
    {F_C F_K₀ F_L F_loc : ℕ → ℝ → List ℝ → ℝ}
    (hFC : IsPolyInAlphaInvDimLogs F_C)
    (hFK : IsPolyInAlphaInvDimLogs F_K₀)
    (hFL : IsPolyInAlphaInvDimLogs F_L)
    (hFloc : IsPolyInAlphaInvDimLogs F_loc) :
    IsPolyInAlphaInvDimLogs (mkPWorkFactor C_depth jobBudgetMult F_C F_K₀ F_L F_loc) := by
  have hdimLog : IsPolyInAlphaInvDimLogs
      (fun d _ logs => ((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) :=
    isPoly_add isPoly_dim isPoly_logsSum
  have hgC := isPoly_max_zero hFC
  have hgK := isPoly_max_zero hFK
  have hgL := isPoly_max_zero hFL
  have hgLoc := isPoly_max_one hFloc
  have haInv := isPoly_alphaInv
  have hsixL : IsPolyInAlphaInvDimLogs (fun d α logs => 6 * max 0 (F_L d α logs) + 1) :=
    isPoly_add (isPoly_mul (isPoly_const 6) hgL
      (fun _ _ _ _ _ => by norm_num) (fun _ _ _ _ _ => le_max_left 0 _)) (isPoly_const 1)
  have hwServ : IsPolyInAlphaInvDimLogs (fun d α logs =>
      (((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) * (max 0 (F_K₀ d α logs) + 1) +
      max 1 (F_loc d α logs)) := by
    refine isPoly_add (isPoly_mul hdimLog (isPoly_add hgK (isPoly_const 1)) ?_ ?_) hgLoc
    · intro d _ logs _ _; have := logsMaxSum_nonneg logs; positivity
    · intro d α logs _ _; have : 0 ≤ max 0 (F_K₀ d α logs) := le_max_left 0 _; linarith
  have haSq : IsPolyInAlphaInvDimLogs (fun _ α _ => max 0 α⁻¹ * max 0 α⁻¹) :=
    isPoly_mul haInv haInv (fun _ _ _ _ _ => le_max_left 0 _) (fun _ _ _ _ _ => le_max_left 0 _)
  have hwPend : IsPolyInAlphaInvDimLogs (fun d α logs =>
      jobBudgetMult * (scheduleCStar : ℝ) * (max 0 α⁻¹ * max 0 α⁻¹) *
        max 1 (F_loc d α logs)) := by
    have hc : IsPolyInAlphaInvDimLogs (fun _ _ _ => jobBudgetMult * (scheduleCStar : ℝ)) :=
      isPoly_const _
    have h1 := isPoly_mul hc haSq
      (fun _ _ _ _ _ => by unfold scheduleCStar; positivity)
      (fun _ _ _ _ _ => mul_nonneg (le_max_left 0 _) (le_max_left 0 _))
    exact isPoly_mul h1 hgLoc
      (fun _ α _ _ _ => by
        have : (0 : ℝ) ≤ max 0 α⁻¹ * max 0 α⁻¹ := mul_nonneg (le_max_left 0 _) (le_max_left 0 _)
        unfold scheduleCStar; positivity)
      (fun _ _ _ _ _ => le_trans zero_le_one (le_max_left 1 _))
  have hwOpen : IsPolyInAlphaInvDimLogs (fun d α logs =>
      max 0 (F_C d α logs) +
      (((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) * (max 0 (F_L d α logs) + 1) +
      max 1 (F_loc d α logs)) := by
    refine isPoly_add (isPoly_add hgC (isPoly_mul hdimLog (isPoly_add hgL (isPoly_const 1)) ?_ ?_))
      hgLoc
    · intro d _ logs _ _; have := logsMaxSum_nonneg logs; positivity
    · intro d α logs _ _; have : 0 ≤ max 0 (F_L d α logs) := le_max_left 0 _; linarith
  have hsixLSq : IsPolyInAlphaInvDimLogs (fun d α logs =>
      (6 * max 0 (F_L d α logs) + 1) * (6 * max 0 (F_L d α logs) + 1)) :=
    isPoly_mul hsixL hsixL
      (fun d α logs _ _ => by have : 0 ≤ max 0 (F_L d α logs) := le_max_left 0 _; linarith)
      (fun d α logs _ _ => by have : 0 ≤ max 0 (F_L d α logs) := le_max_left 0 _; linarith)
  have hwLeaf : IsPolyInAlphaInvDimLogs (fun d α logs =>
      ((d : ℝ) + 1) * ((6 * max 0 (F_L d α logs) + 1) * (6 * max 0 (F_L d α logs) + 1)) +
      (6 * max 0 (F_L d α logs) + 1) * (max 0 (F_C d α logs) + max 1 (F_loc d α logs))) := by
    refine isPoly_add (isPoly_mul isPoly_dim hsixLSq ?_ ?_)
      (isPoly_mul hsixL (isPoly_add hgC hgLoc) ?_ ?_)
    · intro d _ _ _ _; positivity
    · intro d α logs _ _; have : 0 ≤ max 0 (F_L d α logs) := le_max_left 0 _; nlinarith
    · intro d α logs _ _; have : 0 ≤ max 0 (F_L d α logs) := le_max_left 0 _; linarith
    · intro d α logs _ _
      have h1 : 0 ≤ max 0 (F_C d α logs) := le_max_left 0 _
      have h2 : 1 ≤ max 1 (F_loc d α logs) := le_max_left 1 _
      linarith
  have hdBnd1 : IsPolyInAlphaInvDimLogs (fun d α logs => mkDBound C_depth d α logs + 1) :=
    isPoly_add (mkDBound_isPoly hCd) (isPoly_const 1)
  have hwSum3 := isPoly_add (isPoly_add hwServ hwPend) hwOpen
  have hprod : IsPolyInAlphaInvDimLogs (fun d α logs =>
      (mkDBound C_depth d α logs + 1) *
        ((((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) * (max 0 (F_K₀ d α logs) + 1) +
          max 1 (F_loc d α logs) +
         jobBudgetMult * (scheduleCStar : ℝ) * (max 0 α⁻¹ * max 0 α⁻¹) *
          max 1 (F_loc d α logs) +
         (max 0 (F_C d α logs) +
          (((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)) * (max 0 (F_L d α logs) + 1) +
          max 1 (F_loc d α logs)))) := by
    refine isPoly_mul hdBnd1 hwSum3 ?_ ?_
    · intro d α logs _ _; have := one_le_mkDBound hCd d α logs; linarith
    · intro d α logs _ _
      have hdim : 0 ≤ ((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum) := by
        have := logsMaxSum_nonneg logs; positivity
      have hgC0 : 0 ≤ max 0 (F_C d α logs) := le_max_left 0 _
      have hgK0 : 0 ≤ max 0 (F_K₀ d α logs) := le_max_left 0 _
      have hgL0 : 0 ≤ max 0 (F_L d α logs) := le_max_left 0 _
      have hgLoc0 : 1 ≤ max 1 (F_loc d α logs) := le_max_left 1 _
      have haInv0 : 0 ≤ max 0 α⁻¹ := le_max_left 0 _
      unfold scheduleCStar
      positivity
  exact isPoly_add (isPoly_add hwSum3 hwLeaf) hprod

lemma work_budget_le_mkPWorkFactor
    {C_depth jobBudgetMult : ℝ} {d n K₀ L : ℕ} {α C A_n P_loc : ℝ}
    {F_C F_K₀ F_L F_loc : ℕ → ℝ → List ℝ → ℝ} {logs : List ℝ}
    (hCd : 1 ≤ C_depth) (hjb : 0 < jobBudgetMult)
    (hn : 2 ≤ n) (hα : 0 < α) (hC_nn : 0 ≤ C)
    (hlog : Real.log (2 * (n : ℝ)) ≤ 1 + (logs.map (max 0)).sum)
    (hC_le : C ≤ F_C d α logs)
    (hK_le : (K₀ : ℝ) ≤ F_K₀ d α logs)
    (hL_le : (L : ℝ) ≤ F_L d α logs)
    (hAn : 1 ≤ A_n)
    (hPloc_ge : 1 ≤ P_loc)
    (hPloc_le : P_loc ≤ F_loc d α logs) :
    let D₀ : ℕ := ⌈C_depth * α⁻¹ * Real.log (2 * (n : ℝ))⌉₊
    let perServingNodeBudget : ℝ :=
      ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((K₀ : ℝ) + 1) + A_n * P_loc
    let perPendingJobTickBudget : ℝ :=
      prescribedJobTickBudget jobBudgetMult α (A_n * P_loc)
    let levelOpenBudget : ℝ :=
      C + ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((L : ℝ) + 1) + A_n * P_loc
    let leafHandleAndRebuildBudget : ℝ :=
      ((d : ℝ) + 1) * (((6 * L + 1 : ℕ) : ℝ) ^ 2) +
        ((6 * L + 1 : ℕ) : ℝ) * (C + A_n * P_loc)
    perServingNodeBudget + perPendingJobTickBudget +
      levelOpenBudget + leafHandleAndRebuildBudget +
      ((D₀ + 1 : ℕ) : ℝ) *
        (perServingNodeBudget + perPendingJobTickBudget + levelOpenBudget) ≤
        A_n * mkPWorkFactor C_depth jobBudgetMult F_C F_K₀ F_L F_loc d α logs := by
  dsimp only
  unfold mkPWorkFactor prescribedJobTickBudget
  dsimp only
  set dimLog : ℝ := ((d : ℝ) + 1) + (1 + (logs.map (max 0)).sum)
  set gC : ℝ := max 0 (F_C d α logs)
  set gK : ℝ := max 0 (F_K₀ d α logs)
  set gL : ℝ := max 0 (F_L d α logs)
  set gLoc : ℝ := max 1 (F_loc d α logs)
  set aInv : ℝ := max 0 α⁻¹
  set sixL : ℝ := 6 * gL + 1
  set dBnd : ℝ := mkDBound C_depth d α logs
  have hn_cast : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have hlog_n_nn : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg (by linarith)
  have hlog_n_le : Real.log (n : ℝ) ≤ 1 + (logs.map (max 0)).sum :=
    (Real.log_le_log (by linarith) (by linarith)).trans hlog
  have hdim_le : (d : ℝ) + 1 + Real.log (n : ℝ) ≤ dimLog := by
    dsimp [dimLog]; linarith
  have hdim_nn : 0 ≤ (d : ℝ) + 1 + Real.log (n : ℝ) := by positivity
  have hC_g : C ≤ gC := le_max_of_le_right hC_le
  have hK_g : (K₀ : ℝ) ≤ gK := le_max_of_le_right hK_le
  have hL_g : (L : ℝ) ≤ gL := le_max_of_le_right hL_le
  have hLoc_g : P_loc ≤ gLoc := le_max_of_le_right hPloc_le
  have hgC_nn : 0 ≤ gC := le_max_left 0 _
  have hgK_nn : 0 ≤ gK := le_max_left 0 _
  have hgL_nn : 0 ≤ gL := le_max_left 0 _
  have hgLoc_ge : 1 ≤ gLoc := le_max_left 1 _
  have hAn_nn : 0 ≤ A_n := by linarith
  have hdimLog_nn : 0 ≤ dimLog := le_trans hdim_nn hdim_le
  have haInv_eq : aInv = α⁻¹ := max_eq_right (inv_nonneg.mpr (le_of_lt hα))
  have haSq_eq : (α ^ 2)⁻¹ = aInv * aInv := by
    rw [haInv_eq, ← sq, ← inv_pow]
  -- 1. perServingNodeBudget ≤ A_n * wServ
  have h_serv_1 : ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((K₀ : ℝ) + 1) ≤ dimLog * (gK + 1) :=
    mul_le_mul hdim_le (by linarith) (by positivity) hdimLog_nn
  have h_serv : ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((K₀ : ℝ) + 1) + A_n * P_loc ≤
      A_n * (dimLog * (gK + 1) + gLoc) := by
    have h1 : 1 * (dimLog * (gK + 1)) ≤ A_n * (dimLog * (gK + 1)) :=
      mul_le_mul_of_nonneg_right hAn (mul_nonneg hdimLog_nn (by linarith))
    have h2 : A_n * P_loc ≤ A_n * gLoc := mul_le_mul_of_nonneg_left hLoc_g hAn_nn
    linarith
  -- 2. perPendingJobTickBudget ≤ A_n * wPend
  have h_pend : jobBudgetMult * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ * (A_n * P_loc) ≤
      A_n * (jobBudgetMult * (scheduleCStar : ℝ) * (aInv * aInv) * gLoc) := by
    rw [haSq_eq]
    have hcoeff_nn : 0 ≤ jobBudgetMult * (scheduleCStar : ℝ) * (aInv * aInv) := by
      rw [haInv_eq]; unfold scheduleCStar; positivity
    have hmul := mul_le_mul_of_nonneg_left hLoc_g (mul_nonneg hAn_nn hcoeff_nn)
    linarith [show jobBudgetMult * (scheduleCStar : ℝ) * (aInv * aInv) * (A_n * P_loc) =
      (A_n * (jobBudgetMult * (scheduleCStar : ℝ) * (aInv * aInv))) * P_loc by ring,
      show (A_n * (jobBudgetMult * (scheduleCStar : ℝ) * (aInv * aInv))) * gLoc =
      A_n * (jobBudgetMult * (scheduleCStar : ℝ) * (aInv * aInv) * gLoc) by ring]
  -- 3. levelOpenBudget ≤ A_n * wOpen
  have h_open_1 : ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((L : ℝ) + 1) ≤ dimLog * (gL + 1) :=
    mul_le_mul hdim_le (by linarith) (by positivity) hdimLog_nn
  have h_open : C + ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((L : ℝ) + 1) + A_n * P_loc ≤
      A_n * (gC + dimLog * (gL + 1) + gLoc) := by
    have h1 : 1 * (gC + dimLog * (gL + 1)) ≤ A_n * (gC + dimLog * (gL + 1)) :=
      mul_le_mul_of_nonneg_right hAn (add_nonneg hgC_nn (mul_nonneg hdimLog_nn (by linarith)))
    have h2 : A_n * P_loc ≤ A_n * gLoc := mul_le_mul_of_nonneg_left hLoc_g hAn_nn
    linarith
  -- 4. leafHandleAndRebuildBudget ≤ A_n * wLeaf
  have hsix_eq : ((6 * L + 1 : ℕ) : ℝ) = 6 * (L : ℝ) + 1 := by push_cast; ring
  have hsix_le : 6 * (L : ℝ) + 1 ≤ sixL := by linarith
  have hsix_nn : 0 ≤ 6 * (L : ℝ) + 1 := by positivity
  have hsixL_nn : 0 ≤ sixL := le_trans hsix_nn hsix_le
  have hsix_sq : (6 * (L : ℝ) + 1) ^ 2 ≤ sixL * sixL := by
    rw [sq]
    exact mul_le_mul hsix_le hsix_le hsix_nn hsixL_nn
  have h_leaf_1 : ((d : ℝ) + 1) * (((6 * L + 1 : ℕ) : ℝ) ^ 2) ≤
      A_n * (((d : ℝ) + 1) * (sixL * sixL)) := by
    rw [hsix_eq]
    have hd1 : 0 ≤ (d : ℝ) + 1 := by positivity
    have hmul1 : ((d : ℝ) + 1) * ((6 * (L : ℝ) + 1) ^ 2) ≤ ((d : ℝ) + 1) * (sixL * sixL) :=
      mul_le_mul_of_nonneg_left hsix_sq hd1
    have hmul2 : 1 * (((d : ℝ) + 1) * (sixL * sixL)) ≤ A_n * (((d : ℝ) + 1) * (sixL * sixL)) :=
      mul_le_mul_of_nonneg_right hAn (mul_nonneg hd1 (mul_nonneg hsixL_nn hsixL_nn))
    linarith
  have h_leaf_2 : ((6 * L + 1 : ℕ) : ℝ) * (C + A_n * P_loc) ≤
      A_n * (sixL * (gC + gLoc)) := by
    rw [hsix_eq]
    have hC_A : 1 * gC ≤ A_n * gC := mul_le_mul_of_nonneg_right hAn hgC_nn
    have hLoc_A : A_n * P_loc ≤ A_n * gLoc := mul_le_mul_of_nonneg_left hLoc_g hAn_nn
    have hCA : C + A_n * P_loc ≤ A_n * (gC + gLoc) := by linarith
    have hmul := mul_le_mul hsix_le hCA (by positivity) hsixL_nn
    linarith [show sixL * (A_n * (gC + gLoc)) = A_n * (sixL * (gC + gLoc)) by ring]
  have h_leaf : ((d : ℝ) + 1) * (((6 * L + 1 : ℕ) : ℝ) ^ 2) +
      ((6 * L + 1 : ℕ) : ℝ) * (C + A_n * P_loc) ≤
      A_n * (((d : ℝ) + 1) * (sixL * sixL) + sixL * (gC + gLoc)) := by
    linarith
  -- 5. Combine with (D₀ + 1) ≤ dBnd + 1
  have hD0_le : ((⌈C_depth * α⁻¹ * Real.log (2 * (n : ℝ))⌉₊ + 1 : ℕ) : ℝ) ≤ dBnd + 1 := by
    push_cast
    linarith [ceil_depth_le_mkDBound (d := d) hCd hn hα hlog]
  set sum3_lhs : ℝ :=
    (((d : ℝ) + 1 + Real.log (n : ℝ)) * ((K₀ : ℝ) + 1) + A_n * P_loc) +
    jobBudgetMult * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ * (A_n * P_loc) +
    (C + ((d : ℝ) + 1 + Real.log (n : ℝ)) * ((L : ℝ) + 1) + A_n * P_loc)
  set sum3_rhs : ℝ :=
    (dimLog * (gK + 1) + gLoc) +
    jobBudgetMult * (scheduleCStar : ℝ) * (aInv * aInv) * gLoc +
    (gC + dimLog * (gL + 1) + gLoc)
  have hsum3_le : sum3_lhs ≤ A_n * sum3_rhs := by dsimp [sum3_lhs, sum3_rhs]; linarith
  have hsum3_lhs_nn : 0 ≤ sum3_lhs := by
    dsimp [sum3_lhs]; unfold scheduleCStar; positivity
  have hA_sum3_nn : 0 ≤ A_n * sum3_rhs := le_trans hsum3_lhs_nn hsum3_le
  have hdBnd1_nn : 0 ≤ dBnd + 1 := by
    have := one_le_mkDBound hCd d α logs; dsimp [dBnd]; linarith
  have hprod_le : ((⌈C_depth * α⁻¹ * Real.log (2 * (n : ℝ))⌉₊ + 1 : ℕ) : ℝ) * sum3_lhs ≤
      (dBnd + 1) * (A_n * sum3_rhs) :=
    mul_le_mul hD0_le hsum3_le hsum3_lhs_nn hdBnd1_nn
  linarith [show (dBnd + 1) * (A_n * sum3_rhs) = A_n * ((dBnd + 1) * sum3_rhs) by ring]

/-! ### 3. Part (1): Late-opening gate and `O(α^2 m)` tick completion bound -/

theorem prove_part1 {d n K₀ L : ℕ} {ι : Type} {α C : ℝ}
    (hα_pos : 0 < α) (hα_lt : α < 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L) :
    let C_ticks : ℝ := 1 / (64 * 4096)
    let jobBudgetMult : ℝ := 256
    ((∀ (r m : ℕ),
        (CanOpenResidualLevel α r m ↔ (r : ℝ) ≤ α * (m : ℝ) / 4096) ∧
        (residualScheduleStep α L r m ≠ .wait ↔ (r : ℝ) ≤ α * (m : ℝ) / 4096)) ∧
      (∀ (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
         (job : Alg4PendingJob d ι) (jc : PendingJobStepChoices d ι),
        alg4Line5LateOpeningGate pts mode α L job jc ≠ job →
          job.closedAsLeaf = false ∧
          (∀ lv ∈ job.completedPrefix, lv.backgroundReady = true) ∧
          (job.remainingTicks : ℝ) ≤ α * (job.currentResidual.card : ℝ) / 4096) ∧
      (∀ m : ℕ,
        IsLargeResidualLevel L m →
          let b := maxLevelBuildTicks α m
          1 ≤ b ∧
          (b : ℝ) ≤ C_ticks * α ^ 2 * (m : ℝ) ∧
          (∀ (A_n P_loc : ℝ), 1 ≤ A_n → 1 ≤ P_loc →
            ((m : ℝ) + (b : ℝ)) * A_n * P_loc ≤
              (b : ℝ) * prescribedJobTickBudget jobBudgetMult α (A_n * P_loc)))) := by
  dsimp only
  have hgate_iff : ∀ r m : ℕ, CanOpenResidualLevel α r m ↔ (r : ℝ) ≤ α * (m : ℝ) / 4096 := by
    intro r m
    unfold CanOpenResidualLevel scheduleCStar
    norm_num
  refine ⟨?_, ?_, ?_⟩
  · intro r m
    refine ⟨hgate_iff r m, ?_⟩
    unfold residualScheduleStep
    by_cases hc : CanOpenResidualLevel α r m
    · rw [if_pos hc]
      split_ifs <;> simp [(hgate_iff r m).mp hc]
    · rw [if_neg hc]
      simp [(hgate_iff r m).not.mp hc]
  · intro pts mode job jc hne
    unfold alg4Line5LateOpeningGate at hne
    by_cases hcl : job.closedAsLeaf = true
    · rw [if_pos hcl] at hne; exact False.elim (hne rfl)
    · have hcl_f : job.closedAsLeaf = false := Bool.eq_false_iff.mpr hcl
      rw [hcl_f] at hne
      simp only [Bool.false_eq_true, ↓reduceIte] at hne
      by_cases hall : job.completedPrefix.all (fun lv => lv.backgroundReady) = true
      · rw [hall] at hne
        simp only [Bool.not_true, ↓reduceIte] at hne
        have hstep_ne : residualScheduleStep α L job.remainingTicks job.currentResidual.card ≠ .wait := by
          intro hw
          rw [hw] at hne
          exact hne rfl
        have hcan : CanOpenResidualLevel α job.remainingTicks job.currentResidual.card := by
          unfold residualScheduleStep at hstep_ne
          by_cases hc : CanOpenResidualLevel α job.remainingTicks job.currentResidual.card
          · exact hc
          · rw [if_neg hc] at hstep_ne; exact False.elim (hstep_ne rfl)
        exact ⟨hcl_f, List.all_eq_true.mp hall, (hgate_iff _ _).mp hcan⟩
      · have hall_f : job.completedPrefix.all (fun lv => lv.backgroundReady) = false :=
          Bool.eq_false_iff.mpr hall
        rw [hall_f] at hne
        simp at hne
  · intro m hlarge
    set b := maxLevelBuildTicks α m
    have hm_ge_L : (L : ℝ) ≤ (m : ℝ) := by
      unfold IsLargeResidualLevel at hlarge
      exact_mod_cast (show L ≤ m by omega)
    have hcut := UL.Proof.lem_C_2.H1.cutoff_alpha_sq_lb hα_pos hL
    have hα2m_lb : (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) ≤ α ^ 2 * (m : ℝ) := by
      have := mul_le_mul_of_nonneg_left hm_ge_L (sq_nonneg α)
      linarith
    set x : ℝ := α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ))
    have hx_ge : (16384 : ℝ) ≤ x := by
      dsimp [x]
      unfold scheduleCStar at hα2m_lb ⊢
      norm_num at hα2m_lb ⊢
      linarith
    have hb_le_x : (b : ℝ) ≤ x := Nat.floor_le (by linarith)
    have hx_sub_lt_b : x - 1 < (b : ℝ) := Nat.sub_one_lt_floor x
    have hb_ge_one : 1 ≤ b := by
      have : (1 : ℝ) ≤ (b : ℝ) := by linarith
      exact_mod_cast this
    have hb_ub : (b : ℝ) ≤ (1 / (64 * 4096) : ℝ) * α ^ 2 * (m : ℝ) := by
      have hx_eq : x = (1 / (64 * 4096) : ℝ) * α ^ 2 * (m : ℝ) := by
        dsimp [x]; unfold scheduleCStar; ring
      linarith
    refine ⟨hb_ge_one, hb_ub, ?_⟩
    intro A_n P_loc hAn hPloc
    unfold prescribedJobTickBudget
    have hα2_pos : 0 < α ^ 2 := sq_pos_of_pos hα_pos
    have hα2_le1 : α ^ 2 ≤ 1 := by nlinarith
    have hb_le_m : (b : ℝ) ≤ (m : ℝ) := by
      have : α ^ 2 * (m : ℝ) ≤ 1 * (m : ℝ) :=
        mul_le_mul_of_nonneg_right hα2_le1 (Nat.cast_nonneg m)
      dsimp [x] at hb_le_x
      unfold scheduleCStar at hb_le_x
      norm_num at hb_le_x
      linarith
    have hb_ge_half : x / 2 ≤ (b : ℝ) := by linarith
    have hmul_b : 2 * (m : ℝ) ≤ (b : ℝ) * (256 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹) := by
      have hpos_fac : 0 ≤ 256 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ := by
        unfold scheduleCStar; positivity
      have h1 := mul_le_mul_of_nonneg_right hb_ge_half hpos_fac
      have hcancel : (x / 2) * (256 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹) = 2 * (m : ℝ) := by
        dsimp [x]
        unfold scheduleCStar
        field_simp [ne_of_gt hα2_pos]
        ring
      linarith
    have hAP_nn : 0 ≤ A_n * P_loc := by positivity
    have h2 : ((m : ℝ) + (b : ℝ)) * (A_n * P_loc) ≤
        ((b : ℝ) * (256 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹)) * (A_n * P_loc) :=
      mul_le_mul_of_nonneg_right (by linarith) hAP_nn
    linarith [show ((m : ℝ) + (b : ℝ)) * A_n * P_loc = ((m : ℝ) + (b : ℝ)) * (A_n * P_loc) by ring,
      show ((b : ℝ) * (256 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹)) * (A_n * P_loc) =
        (b : ℝ) * (256 * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ * (A_n * P_loc)) by ring]

/-! ### 4. Part (2): Birth-core check and child gate-slack after level build -/

theorem prove_part2 {d n K₀ L : ℕ} {ι : Type} {α C : ℝ}
    (hα_pos : 0 < α) (hα_lt : α < 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L) :
    let c_core : ℝ := 1 / 2
    ∀ (pts : ι → EuclideanSpace ℝ (Fin d)) (S_birth : Finset ι)
       (bId : ι) (res : SampledCenterResult d),
      bId ∈ S_birth →
        let ball := selectOpenedLevelBall α pts S_birth bId res
        PassesBirthCoreCheck α pts ball S_birth ∧
        c_core * α * (S_birth.card : ℝ) ≤ ((ball.core pts S_birth).card : ℝ) ∧
        ((ball.residual pts S_birth).card : ℝ) ≤ (1 - c_core * α) * (S_birth.card : ℝ) ∧
        (∀ (r b trueAge : ℕ) (S_after : Finset ι),
          IsLargeResidualLevel L S_birth.card →
          α * (S_birth.card : ℝ) / 4096 - 2 < (r : ℝ) →
          (r : ℝ) ≤ α * (S_birth.card : ℝ) / 4096 →
          1 ≤ b → b ≤ maxLevelBuildTicks α S_birth.card →
          trueAge ≤ b →
          HasNodeAge S_birth S_after trueAge →
            let m' := (ball.residual pts S_after).card
            b < r ∧
            (m' : ℝ) ≤ (1 - α / 4) * ((S_birth.card + b : ℕ) : ℝ) ∧
            ¬ CanOpenResidualLevel α (r - b) m') := by
  dsimp only
  intro pts S_birth bId res hbId
  have hα_le : α ≤ 1 := le_of_lt hα_lt
  have hprov : IsProvisionalCenter pts S_birth res (provisionalCenter pts bId res) := by
    cases res with
    | infeasible =>
      exact ⟨bId, hbId, rfl⟩
    | candidate o V =>
      unfold IsProvisionalCenter provisionalCenter
      by_cases hV : 0 ≤ V
      · simp [hV]
      · simp only [hV, ↓reduceDIte]
        exact ⟨bId, hbId, rfl⟩
  have hvalid : IsValidOpenedLevelBall α pts S_birth res
      (selectOpenedLevelBall α pts S_birth bId res) :=
    ⟨provisionalCenter pts bId res, hprov, rfl⟩
  have hcore : PassesBirthCoreCheck α pts (selectOpenedLevelBall α pts S_birth bId res) S_birth :=
    UL.Proof.lem_C_2.H1.applyBirthCoreFallback_passes hα_le pts S_birth res _ hvalid
  have hcore_lb : (1 / 2 : ℝ) * α * (S_birth.card : ℝ) ≤
      (((selectOpenedLevelBall α pts S_birth bId res).core pts S_birth).card : ℝ) := by
    unfold PassesBirthCoreCheck at hcore
    linarith
  have hres_ub : (((selectOpenedLevelBall α pts S_birth bId res).residual pts S_birth).card : ℝ) ≤
      (1 - (1 / 2 : ℝ) * α) * (S_birth.card : ℝ) := by
    have := UL.Proof.lem_C_2.H1.birth_residual_card_le pts _ S_birth hcore
    linarith
  refine ⟨hcore, hcore_lb, hres_ub, ?_⟩
  intro r b trueAge S_after hlarge hr_lb _ _ hb_le hage_le hage
  set ball := selectOpenedLevelBall α pts S_birth bId res
  have hm_ge_L : (L : ℝ) ≤ (S_birth.card : ℝ) := by
    unfold IsLargeResidualLevel at hlarge
    exact_mod_cast (show L ≤ S_birth.card by omega)
  have hcut := UL.Proof.lem_C_2.H1.cutoff_alpha_sq_lb hα_pos hL
  have hα2m_lb : (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) ≤ α ^ 2 * (S_birth.card : ℝ) := by
    have := mul_le_mul_of_nonneg_left hm_ge_L (sq_nonneg α)
    linarith
  have hb_cast_le : (b : ℝ) ≤ α ^ 2 * (S_birth.card : ℝ) / (64 * (scheduleCStar : ℝ)) := by
    have h1 : (b : ℝ) ≤ (maxLevelBuildTicks α S_birth.card : ℝ) := by exact_mod_cast hb_le
    have h2 : (maxLevelBuildTicks α S_birth.card : ℝ) ≤
        α ^ 2 * (S_birth.card : ℝ) / (64 * (scheduleCStar : ℝ)) :=
      Nat.floor_le (by unfold scheduleCStar; positivity)
    exact h1.trans h2
  have hα2_le_α : α ^ 2 * (S_birth.card : ℝ) ≤ α * (S_birth.card : ℝ) := by
    have : α ^ 2 ≤ α := by nlinarith
    exact mul_le_mul_of_nonneg_right this (Nat.cast_nonneg _)
  have hb_lt_r : b < r := by
    have hlt_real : (b : ℝ) < (r : ℝ) := by
      unfold scheduleCStar at hα2m_lb hb_cast_le
      norm_num at hα2m_lb hb_cast_le
      linarith
    exact_mod_cast hlt_real
  have hb_le_m : (b : ℝ) ≤ (S_birth.card : ℝ) := by
    have : α ^ 2 * (S_birth.card : ℝ) ≤ 1 * (S_birth.card : ℝ) :=
      mul_le_mul_of_nonneg_right (by nlinarith) (Nat.cast_nonneg _)
    unfold scheduleCStar at hb_cast_le
    norm_num at hb_cast_le
    linarith
  have hm'_aged := UL.Proof.lem_C_2.H1.aged_residual_card_le pts ball S_birth S_after hcore hage
  have htrue_le_b : (trueAge : ℝ) ≤ (b : ℝ) := by exact_mod_cast hage_le
  have hm'_bound : ((ball.residual pts S_after).card : ℝ) ≤
      (1 - α / 4) * ((S_birth.card + b : ℕ) : ℝ) := by
    push_cast
    nlinarith
  have hr_lb' : α * (S_birth.card : ℝ) / (scheduleCStar : ℝ) - 2 < (r : ℝ) := by
    unfold scheduleCStar; exact hr_lb
  have hsub_eq : r - (r - b) = b := by omega
  have hgate_closed : ¬ CanOpenResidualLevel α (r - b) (ball.residual pts S_after).card :=
    UL.Proof.lem_C_2.H1.gate_closed_during_build (trueAge := trueAge)
      hα_pos hα_le hL pts ball S_birth S_after
      hlarge hcore hr_lb' (Nat.sub_le r b)
      (by rwa [hsub_eq]) (by rwa [hsub_eq]) hage
  exact ⟨hb_lt_r, hm'_bound, hgate_closed⟩

/-! ### 5. Part (3): Job-start rule, serving-node age `< α M / 16`, and installation -/

open Classical in
theorem prove_part3 {d n K₀ L : ℕ} {ι : Type} {α C : ℝ}
    (hα_pos : 0 < α) (hα_lt : α < 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L) :
    (∀ m₀ : ℕ,
        scheduleJobStart α L m₀ =
          if NeedsScheduledReplacement L m₀ then
            .startPendingJob (jobDeadlineTicks α m₀)
          else
            .replaceImmediatelyByExactLeaf) ∧
    (∀ (M m₀ startAge elapsed : ℕ) (S_birth S_start : Finset ι),
      IsLargeResidualLevel L M →
      S_birth.card = M →
      S_start.card = m₀ →
      startAge ≤ jobStartAge α M →
      HasNodeAge S_birth S_start startAge →
      NeedsScheduledReplacement L m₀ →
      elapsed ≤ jobDeadlineTicks α m₀ →
        IsValidServingNodeAge α M (jobStartAge α M + elapsed)) ∧
    (∀ lv : Alg4OpenedLevel d ι,
      let sn := installOpenedLevelAsServingNode lv
      sn.birthSnapshot = lv.birthSnapshot ∧
      sn.node = lv.ball ∧
      sn.trueAge = lv.trueInputAge ∧
      sn.age = lv.elapsedRootTicks ∧
      sn.ownedJob = none ∧
      (IsLargeResidualLevel L lv.birthSnapshot.card →
        (lv.elapsedRootTicks : ℝ) ≤ α * (lv.birthSnapshot.card : ℝ) / 4096 →
          sn.age < jobStartAge α sn.birthSnapshot.card ∧
          IsValidServingNodeAge α sn.birthSnapshot.card sn.age)) := by
  refine ⟨?_, ?_, ?_⟩
  · intro m₀
    unfold scheduleJobStart NeedsScheduledReplacement
    split_ifs <;> rfl
  · intro M m₀ startAge elapsed S_birth S_start hlarge hM hm₀ hstart_le hage _ helapsed
    unfold IsValidServingNodeAge
    have hM_pos : 1 ≤ M := by unfold IsLargeResidualLevel at hlarge; omega
    have hM_cast_pos : (0 : ℝ) < (M : ℝ) := by exact_mod_cast hM_pos
    have hαM_pos : 0 < α * (M : ℝ) := mul_pos hα_pos hM_cast_pos
    have hm₀_nat : m₀ ≤ M + startAge := by
      have hcard := (UL.Proof.lem_C_2.H1.hasNodeAge_card_bounds hage).2.2
      omega
    have hj_ub : (jobStartAge α M : ℝ) ≤ α * (M : ℝ) / 64 :=
      Nat.floor_le (by positivity)
    have hstart_ub : (startAge : ℝ) ≤ α * (M : ℝ) / 64 :=
      (show (startAge : ℝ) ≤ (jobStartAge α M : ℝ) by exact_mod_cast hstart_le).trans hj_ub
    have hm₀_ub : (m₀ : ℝ) ≤ (65 / 64 : ℝ) * (M : ℝ) := by
      have hm₀_c : (m₀ : ℝ) ≤ (M : ℝ) + (startAge : ℝ) := by exact_mod_cast hm₀_nat
      have hαM_le_M : α * (M : ℝ) ≤ 1 * (M : ℝ) :=
        mul_le_mul_of_nonneg_right (le_of_lt hα_lt) (le_of_lt hM_cast_pos)
      linarith
    have hel_ub : (elapsed : ℝ) ≤ α * (m₀ : ℝ) / 4096 := by
      have h1 : (elapsed : ℝ) ≤ (jobDeadlineTicks α m₀ : ℝ) := by exact_mod_cast helapsed
      have h2 : (jobDeadlineTicks α m₀ : ℝ) ≤ α * (m₀ : ℝ) / 4096 := by
        unfold jobDeadlineTicks scheduleCStar
        exact Nat.floor_le (by positivity)
      exact h1.trans h2
    have hel_M : (elapsed : ℝ) ≤ (65 / (64 * 4096) : ℝ) * (α * (M : ℝ)) := by
      have := mul_le_mul_of_nonneg_left hm₀_ub (le_of_lt hα_pos)
      linarith
    push_cast
    linarith
  · intro lv
    refine ⟨rfl, rfl, rfl, rfl, rfl, ?_⟩
    intro hlarge hel
    dsimp [installOpenedLevelAsServingNode]
    set M := lv.birthSnapshot.card
    have hM_ge_L : (L : ℝ) ≤ (M : ℝ) := by
      unfold IsLargeResidualLevel at hlarge
      exact_mod_cast (show L ≤ M by omega)
    have hcut := UL.Proof.lem_C_2.H1.cutoff_alpha_sq_lb hα_pos hL
    have hα2M_lb : (2 : ℝ) ^ 20 * 4096 ≤ α ^ 2 * (M : ℝ) := by
      unfold scheduleCStar at hcut
      norm_num at hcut
      have := mul_le_mul_of_nonneg_left hM_ge_L (sq_nonneg α)
      linarith
    have hαM_lb : (2 : ℝ) ^ 20 * 4096 ≤ α * (M : ℝ) := by
      have : α ^ 2 * (M : ℝ) ≤ α * (M : ℝ) :=
        mul_le_mul_of_nonneg_right (by nlinarith) (Nat.cast_nonneg M)
      linarith
    have hj_lb : α * (M : ℝ) / 64 - 1 < (jobStartAge α M : ℝ) :=
      Nat.sub_one_lt_floor (α * (M : ℝ) / 64)
    have hlt_j : lv.elapsedRootTicks < jobStartAge α M := by
      have : (lv.elapsedRootTicks : ℝ) < (jobStartAge α M : ℝ) := by
        norm_num at hαM_lb
        linarith
      exact_mod_cast this
    have hvalid_age : IsValidServingNodeAge α M lv.elapsedRootTicks := by
      unfold IsValidServingNodeAge
      norm_num at hαM_lb
      linarith
    exact ⟨hlt_j, hvalid_age⟩

end

end UL.Proof_clm_7_2_chain_schedule
