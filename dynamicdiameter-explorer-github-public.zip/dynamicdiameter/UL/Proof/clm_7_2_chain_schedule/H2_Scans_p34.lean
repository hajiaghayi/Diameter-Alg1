import UL.Stmt.clm_7_2_chain_schedule
import UL.Proof.claim_C_2_space_reclaim.H2a_DataStructs


set_option autoImplicit false

namespace UL.Proof_clm_7_2_chain_schedule

open UL
open UL.Proof.claim_C_2_space_reclaim

private lemma poolUpdateEvent_ticks_le_one {ι : Type} (ev : PoolUpdateEvent ι) :
    ev.ticks ≤ 1 := by
  unfold PoolUpdateEvent.ticks
  split_ifs <;> omega

open Classical in
private lemma hasNodeAge_step {ι : Type} {P₀ S S' : Finset ι} {a : ℕ}
    (hage : HasNodeAge P₀ S a) (hchg : IsInputChange S S') :
    HasNodeAge P₀ S' (a + 1) := by
  rcases hage with ⟨seq, h0, hlast, hsteps⟩
  refine ⟨fun i => if h : i.val ≤ a then seq ⟨i.val, Nat.lt_succ_of_le h⟩ else S', ?_, ?_, ?_⟩
  · simp [h0]
  · simp [Fin.last]
  · intro r
    by_cases hr : r.val < a
    · have h1 : r.castSucc.val ≤ a := Nat.le_of_lt hr
      have h2 : r.succ.val ≤ a := hr
      simp only [h1, h2, ↓reduceDIte]
      exact hsteps ⟨r.val, hr⟩
    · have hreq : r.val = a := by omega
      have h1 : r.castSucc.val ≤ a := by simp [hreq]
      have h2 : ¬ (r.succ.val ≤ a) := by simp [hreq]
      simp only [h1, h2, ↓reduceDIte]
      have heq_last : (⟨r.castSucc.val, Nat.lt_succ_of_le h1⟩ : Fin (a + 1)) = Fin.last a := by
        ext
        simp [hreq, Fin.last]
      rw [heq_last, hlast]
      exact hchg

open Classical in
private lemma hasNodeAge_of_validPoolUpdateEvent {ι : Type}
    {P₀ S S' : Finset ι} {a : ℕ} {ev : PoolUpdateEvent ι}
    (hage : HasNodeAge P₀ S a) (hev : IsValidPoolUpdateEvent S S' ev) :
    HasNodeAge P₀ S' (a + ev.ticks) := by
  cases ev with
  | externalInsert p =>
    rcases hev with ⟨hp, hS'⟩
    simpa [PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick] using
      hasNodeAge_step hage (Or.inl ⟨p, hp, hS'⟩)
  | externalDelete p =>
    rcases hev with ⟨hp, hS'⟩
    simpa [PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick] using
      hasNodeAge_step hage (Or.inr ⟨p, hp, hS'⟩)
  | virtualValueDelete =>
    subst hev
    simpa [PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick] using hage
  | unaffected =>
    subst hev
    simpa [PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick] using hage

private lemma filter_length_le_one_of_nodup {α : Type} {l : List α} (hnodup : l.Nodup)
    (P : α → Bool) (huniq : ∀ a ∈ l, ∀ b ∈ l, P a = true → P b = true → a = b) :
    (l.filter P).length ≤ 1 := by
  have hfn : (l.filter P).Nodup := hnodup.filter P
  match h : l.filter P with
  | [] => simp
  | [_] => simp
  | a :: b :: rest =>
    rw [h] at hfn
    have ha : a ∈ l.filter P := by simp [h]
    have hb : b ∈ l.filter P := by simp [h]
    rcases List.mem_filter.mp ha with ⟨hal, hPa⟩
    rcases List.mem_filter.mp hb with ⟨hbl, hPb⟩
    have hab : a = b := huniq a hal b hbl hPa hPb
    exact False.elim ((List.nodup_cons.mp hfn).1 (by simp [hab]))

open Classical in
private lemma arrival_step_props {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    {S₀ S S' : Finset ι} {lv : Alg4OpenedLevel d ι} {ev : PoolUpdateEvent ι}
    (qAns : NodeMatchingQueryAnswers ι) (mHint : Option ι)
    (hball : lv.ball = ball)
    (hbirth : lv.birthSnapshot = S₀)
    (hscan2 : lv.scan2Snapshot = S₀)
    (hheap_eq : lv.heapIndexedIds = lv.radiusDict.indexedIds)
    (hheap_sub : lv.heapIndexedIds ⊆ S)
    (hcls_sub : lv.classifiedIds ⊆ S)
    (hpost_heap : S \ S₀ ⊆ lv.heapIndexedIds)
    (hpost_cls : S \ S₀ ⊆ lv.classifiedIds)
    (hwf_rad : lv.radiusDict.WellFormedOn pts ball.o lv.heapIndexedIds)
    (hval_lm : ValidNodeMatchingsOn pts mode ball lv.classifiedIds lv.localMatchings)
    (hage : HasNodeAge S₀ S lv.trueInputAge)
    (hready : lv.backgroundReady = true → lv.heapIndexedIds = S ∧ lv.classifiedIds = S)
    (hev : IsValidPoolUpdateEvent S S' ev) :
    let lv_arr := applyOpenedLevelArrival pts mode lv ev qAns mHint
    lv_arr.ball = ball ∧
    lv_arr.birthSnapshot = S₀ ∧
    lv_arr.scan2Snapshot = S₀ ∧
    lv_arr.backgroundReady = lv.backgroundReady ∧
    lv_arr.elapsedRootTicks = lv.elapsedRootTicks ∧
    lv_arr.trueInputAge = lv.trueInputAge + ev.ticks ∧
    lv_arr.heapIndexedIds = lv_arr.radiusDict.indexedIds ∧
    lv_arr.heapIndexedIds ⊆ S' ∧
    lv_arr.classifiedIds ⊆ S' ∧
    S' \ S₀ ⊆ lv_arr.heapIndexedIds ∧
    S' \ S₀ ⊆ lv_arr.classifiedIds ∧
    lv_arr.radiusDict.WellFormedOn pts ball.o lv_arr.heapIndexedIds ∧
    ValidNodeMatchingsOn pts mode ball lv_arr.classifiedIds lv_arr.localMatchings ∧
    HasNodeAge S₀ S' lv_arr.trueInputAge ∧
    (lv_arr.backgroundReady = true → lv_arr.heapIndexedIds = S' ∧ lv_arr.classifiedIds = S') ∧
    (∀ x ∈ S', x ∈ lv.heapIndexedIds → x ∈ lv_arr.heapIndexedIds) ∧
    (∀ x ∈ S', x ∈ lv.classifiedIds → x ∈ lv_arr.classifiedIds) ∧
    (∀ p : ι, ev = .externalInsert p →
      p ∉ lv.heapIndexedIds ∧ p ∉ lv.classifiedIds ∧
      p ∈ lv_arr.heapIndexedIds ∧ p ∈ lv_arr.classifiedIds) ∧
    (∀ p : ι, ev = .externalDelete p →
      p ∉ lv_arr.heapIndexedIds ∧ p ∉ lv_arr.classifiedIds) := by
  have hage' := hasNodeAge_of_validPoolUpdateEvent hage hev
  cases ev with
  | externalInsert p =>
    rcases hev with ⟨hpS, rfl⟩
    have hp_not_heap : p ∉ lv.heapIndexedIds := fun hm => hpS (hheap_sub hm)
    have hp_not_cls : p ∉ lv.classifiedIds := fun hm => hpS (hcls_sub hm)
    dsimp only [applyOpenedLevelArrival, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick,
      ↓reduceIte]
    rw [hball]
    have hwf' := updateRadiusDictOnEvent_wellFormed_insert pts ball.o hwf_rad p mHint
    have hidx' :
        (updateRadiusDictOnEvent pts ball.o lv.radiusDict (.externalInsert p) mHint).indexedIds =
          insert p lv.heapIndexedIds := hwf'.1
    have hval' := applyNodeMatchingInsert_valid pts mode ball hp_not_cls qAns hval_lm
    refine ⟨rfl, hbirth, hscan2, rfl, rfl, rfl, rfl, ?_, ?_, ?_, ?_, ?_, hval', hage', ?_,
      ?_, ?_, ?_, ?_⟩
    · rw [hidx']
      exact Finset.insert_subset_insert p hheap_sub
    · exact Finset.insert_subset_insert p hcls_sub
    · rw [hidx']
      intro x hx
      rcases Finset.mem_sdiff.mp hx with ⟨hx_ins, hx_not0⟩
      rcases Finset.mem_insert.mp hx_ins with rfl | hxS
      · exact Finset.mem_insert_self x _
      · exact Finset.mem_insert_of_mem (hpost_heap (Finset.mem_sdiff.mpr ⟨hxS, hx_not0⟩))
    · intro x hx
      rcases Finset.mem_sdiff.mp hx with ⟨hx_ins, hx_not0⟩
      rcases Finset.mem_insert.mp hx_ins with rfl | hxS
      · exact Finset.mem_insert_self x _
      · exact Finset.mem_insert_of_mem (hpost_cls (Finset.mem_sdiff.mpr ⟨hxS, hx_not0⟩))
    · rw [hidx']
      exact hwf'
    · intro hr
      rcases hready hr with ⟨hh, hc⟩
      rw [hidx', hh, hc]
      exact ⟨rfl, rfl⟩
    · rw [hidx']
      intro x _ hx
      exact Finset.mem_insert_of_mem hx
    · intro x _ hx
      exact Finset.mem_insert_of_mem hx
    · intro q hq
      cases hq
      rw [hidx']
      exact ⟨hp_not_heap, hp_not_cls, Finset.mem_insert_self p _, Finset.mem_insert_self p _⟩
    · intro q hq
      cases hq
  | externalDelete p =>
    rcases hev with ⟨hpS, rfl⟩
    dsimp only [applyOpenedLevelArrival, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick,
      ↓reduceIte]
    rw [hball]
    have hwf' := updateRadiusDictOnEvent_wellFormed_delete pts ball.o hwf_rad p mHint
    have hidx' :
        (updateRadiusDictOnEvent pts ball.o lv.radiusDict (.externalDelete p) mHint).indexedIds =
          lv.heapIndexedIds.erase p := hwf'.1
    have hval' : ValidNodeMatchingsOn pts mode ball (lv.classifiedIds.erase p)
        (if p ∈ lv.classifiedIds then
          applyNodeMatchingDelete pts mode ball lv.localMatchings p qAns
        else lv.localMatchings) := by
      split_ifs with hp_cls
      · exact applyNodeMatchingDelete_valid pts mode ball p qAns hval_lm
      · have her : lv.classifiedIds.erase p = lv.classifiedIds := by
          ext z; simp only [Finset.mem_erase, ne_eq]
          exact ⟨fun h => h.2, fun hz => ⟨fun hzp => hp_cls (hzp ▸ hz), hz⟩⟩
        rw [her]
        exact hval_lm
    refine ⟨rfl, hbirth, hscan2, rfl, rfl, rfl, rfl, ?_, ?_, ?_, ?_, ?_, hval', hage', ?_,
      ?_, ?_, ?_, ?_⟩
    · rw [hidx']
      exact Finset.erase_subset_erase p hheap_sub
    · exact Finset.erase_subset_erase p hcls_sub
    · rw [hidx']
      intro x hx
      rcases Finset.mem_sdiff.mp hx with ⟨hx_er, hx_not0⟩
      rcases Finset.mem_erase.mp hx_er with ⟨hxp, hxS⟩
      exact Finset.mem_erase.mpr ⟨hxp, hpost_heap (Finset.mem_sdiff.mpr ⟨hxS, hx_not0⟩)⟩
    · intro x hx
      rcases Finset.mem_sdiff.mp hx with ⟨hx_er, hx_not0⟩
      rcases Finset.mem_erase.mp hx_er with ⟨hxp, hxS⟩
      exact Finset.mem_erase.mpr ⟨hxp, hpost_cls (Finset.mem_sdiff.mpr ⟨hxS, hx_not0⟩)⟩
    · rw [hidx']
      exact hwf'
    · intro hr
      rcases hready hr with ⟨hh, hc⟩
      rw [hidx', hh, hc]
      exact ⟨rfl, rfl⟩
    · rw [hidx']
      intro x hxS' hx
      exact Finset.mem_erase.mpr ⟨(Finset.mem_erase.mp hxS').1, hx⟩
    · intro x hxS' hx
      exact Finset.mem_erase.mpr ⟨(Finset.mem_erase.mp hxS').1, hx⟩
    · intro q hq
      cases hq
    · intro q hq
      cases hq
      rw [hidx']
      exact ⟨by simp, by simp⟩
  | virtualValueDelete =>
    subst hev
    dsimp only [applyOpenedLevelArrival, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick,
      Bool.false_eq_true, ↓reduceIte, Nat.add_zero]
    exact ⟨hball, hbirth, hscan2, rfl, rfl, rfl, hheap_eq, hheap_sub, hcls_sub, hpost_heap,
      hpost_cls, hwf_rad, hval_lm, hage, hready, fun _ _ hx => hx, fun _ _ hx => hx,
      (fun _ h => by cases h), (fun _ h => by cases h)⟩
  | unaffected =>
    subst hev
    dsimp only [applyOpenedLevelArrival, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick,
      Bool.false_eq_true, ↓reduceIte, Nat.add_zero]
    exact ⟨hball, hbirth, hscan2, rfl, rfl, rfl, hheap_eq, hheap_sub, hcls_sub, hpost_heap,
      hpost_cls, hwf_rad, hval_lm, hage, hready, fun _ _ hx => hx, fun _ _ hx => hx,
      (fun _ h => by cases h), (fun _ h => by cases h)⟩

open Classical in
private lemma build_step_props {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    {S₀ S' : Finset ι} {lv : Alg4OpenedLevel d ι} (bChoice : PendingLevelBudgetChoices ι)
    (hball : lv.ball = ball)
    (hbirth : lv.birthSnapshot = S₀)
    (hscan2 : lv.scan2Snapshot = S₀)
    (hheap_eq : lv.heapIndexedIds = lv.radiusDict.indexedIds)
    (hheap_sub : lv.heapIndexedIds ⊆ S')
    (hcls_sub : lv.classifiedIds ⊆ S')
    (hwf_rad : lv.radiusDict.WellFormedOn pts ball.o lv.heapIndexedIds)
    (hval_lm : ValidNodeMatchingsOn pts mode ball lv.classifiedIds lv.localMatchings)
    (hready : lv.backgroundReady = true → lv.heapIndexedIds = S' ∧ lv.classifiedIds = S') :
    let lv' := stepOpenedLevelBuild pts mode S' lv bChoice
    lv'.ball = ball ∧
    lv'.birthSnapshot = S₀ ∧
    lv'.scan2Snapshot = S₀ ∧
    lv'.trueInputAge = lv.trueInputAge ∧
    lv'.elapsedRootTicks = lv.elapsedRootTicks + 1 ∧
    lv'.heapIndexedIds = lv'.radiusDict.indexedIds ∧
    lv'.heapIndexedIds ⊆ S' ∧
    lv'.classifiedIds ⊆ S' ∧
    lv.heapIndexedIds ⊆ lv'.heapIndexedIds ∧
    lv.classifiedIds ⊆ lv'.classifiedIds ∧
    lv'.radiusDict.WellFormedOn pts ball.o lv'.heapIndexedIds ∧
    ValidNodeMatchingsOn pts mode ball lv'.classifiedIds lv'.localMatchings ∧
    (lv'.backgroundReady = true → lv'.heapIndexedIds = S' ∧ lv'.classifiedIds = S') ∧
    (∀ x ∈ S₀, x ∈ S' → x ∈ bChoice.scan1Batch → x ∈ lv'.heapIndexedIds) ∧
    (∀ x ∈ S₀, x ∈ S' → x ∈ bChoice.scan2Steps.map Prod.fst → x ∈ lv'.classifiedIds) := by
  unfold stepOpenedLevelBuild
  by_cases hbr : lv.backgroundReady = true
  · rw [if_pos hbr]
    rcases hready hbr with ⟨hh_eq, hc_eq⟩
    refine ⟨hball, hbirth, hscan2, rfl, rfl, hheap_eq, hheap_sub, hcls_sub,
      Finset.Subset.refl _, Finset.Subset.refl _, hwf_rad, hval_lm, hready, ?_, ?_⟩
    · intro x _ hxS' _
      rw [hh_eq]
      exact hxS'
    · intro x _ hxS' _
      rw [hc_eq]
      exact hxS'
  · rw [if_neg hbr]
    dsimp only
    rw [hball, hbirth, hscan2]
    have hs1 := scan1RadiusDictBatch_wellFormed pts ball.o hwf_rad hheap_sub
      (bChoice.scan1Batch ∩ S₀) bChoice.scanMaxHint
    rcases hs1 with ⟨hs1_eq, hs1_sub, hs1_wf, hs1_diff⟩
    have hs2 := applyScan2Batch_valid pts mode ball S' S₀ lv.classifiedIds lv.localMatchings
      bChoice.scan2Steps hcls_sub hval_lm
    rcases hs2 with ⟨hs2_sub, hs2_val, hs2_diff⟩
    have hheap_mono : lv.heapIndexedIds ⊆
        (scan1RadiusDictBatch pts ball.o S' lv.radiusDict
          (bChoice.scan1Batch ∩ S₀) bChoice.scanMaxHint).indexedIds := by
      rw [hs1_eq]
      exact Finset.subset_union_left
    have hcls_mono : lv.classifiedIds ⊆
        (applyScan2Batch pts mode ball S' S₀ lv.classifiedIds lv.localMatchings
          bChoice.scan2Steps).1 := by
      intro x hx
      by_contra hx_not
      have hx_sdiff : x ∈ S' \ (applyScan2Batch pts mode ball S' S₀ lv.classifiedIds
          lv.localMatchings bChoice.scan2Steps).1 :=
        Finset.mem_sdiff.mpr ⟨hcls_sub hx, hx_not⟩
      rw [hs2_diff] at hx_sdiff
      exact (Finset.mem_sdiff.mp (Finset.mem_sdiff.mp hx_sdiff).1).2 hx
    refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, hs1_sub, hs2_sub, hheap_mono, hcls_mono,
      hs1_wf, hs2_val, ?_, ?_, ?_⟩
    · intro hr'
      simp only [Bool.and_eq_true, decide_eq_true_eq] at hr'
      exact ⟨ Finset.Subset.antisymm hs1_sub hr'.1.1,
              Finset.Subset.antisymm hs2_sub hr'.1.2 ⟩
    · intro x hx0 hxS' hxB
      rw [hs1_eq]
      by_cases hxH : x ∈ lv.heapIndexedIds
      · exact Finset.mem_union_left _ hxH
      · exact Finset.mem_union_right _
          (Finset.mem_sdiff.mpr ⟨Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨hxB, hx0⟩, hxS'⟩, hxH⟩)
    · intro x hx0 hxS' hxB
      by_contra hx_not
      have hx_sdiff : x ∈ S' \ (applyScan2Batch pts mode ball S' S₀ lv.classifiedIds
          lv.localMatchings bChoice.scan2Steps).1 :=
        Finset.mem_sdiff.mpr ⟨hxS', hx_not⟩
      rw [hs2_diff] at hx_sdiff
      exact (Finset.mem_sdiff.mp hx_sdiff).2
        (Finset.mem_inter.mpr ⟨List.mem_toFinset.mpr hxB, hx0⟩)

open Classical in
private lemma exists_insert_between {ι : Type} {T : ℕ}
    (S_lv : Fin (T + 1) → Finset ι) (ev : Fin T → PoolUpdateEvent ι)
    (hev : ∀ t : Fin T, IsValidPoolUpdateEvent (S_lv t.castSucc) (S_lv t.succ) (ev t))
    {x : ι} :
    ∀ {s₁ s₂ : Fin (T + 1)}, s₁ ≤ s₂ → x ∉ S_lv s₁ → x ∈ S_lv s₂ →
      ∃ v : Fin T, s₁ ≤ v.castSucc ∧ v.succ ≤ s₂ ∧ ev v = .externalInsert x := by
  intro s₁ s₂
  refine Fin.induction ?_ ?_ s₂
  · intro hs₁ hnot hmem
    have h0 : s₁ = 0 := Fin.le_zero_iff.mp hs₁
    subst h0
    exact absurd hmem hnot
  · intro t ih hs₁ hnot hmem
    rcases eq_or_lt_of_le hs₁ with rfl | hlt
    · exact absurd hmem hnot
    · have hs₁_le : s₁ ≤ t.castSucc := Nat.le_of_lt_succ hlt
      by_cases hx_prev : x ∈ S_lv t.castSucc
      · rcases ih hs₁_le hnot hx_prev with ⟨v, hv1, hv2, hvev⟩
        exact ⟨v, hv1, le_trans hv2 (Fin.castSucc_le_succ t), hvev⟩
      · have hvt := hev t
        cases h_ev : ev t with
        | externalInsert p =>
          rw [h_ev] at hvt
          rcases hvt with ⟨_, hS'⟩
          rw [hS'] at hmem
          rcases Finset.mem_insert.mp hmem with rfl | hx_old
          · exact ⟨t, hs₁_le, le_rfl, h_ev⟩
          · exact absurd hx_old hx_prev
        | externalDelete p =>
          rw [h_ev] at hvt
          rcases hvt with ⟨_, hS'⟩
          rw [hS'] at hmem
          exact absurd (Finset.mem_of_mem_erase hmem) hx_prev
        | virtualValueDelete =>
          rw [h_ev] at hvt
          rw [hvt] at hmem
          exact absurd hmem hx_prev
        | unaffected =>
          rw [h_ev] at hvt
          rw [hvt] at hmem
          exact absurd hmem hx_prev

open Classical in
private lemma exists_drop_between {ι : Type} {T : ℕ}
    (A S_lv : Fin (T + 1) → Finset ι) {x : ι}
    (hdrop : ∀ t : Fin T, x ∈ A t.castSucc → x ∉ A t.succ → x ∉ S_lv t.succ) :
    ∀ {s₁ s₂ : Fin (T + 1)}, s₁ ≤ s₂ → x ∈ A s₁ → x ∉ A s₂ →
      ∃ u : Fin T, s₁ ≤ u.castSucc ∧ u.succ ≤ s₂ ∧ x ∉ S_lv u.succ := by
  intro s₁ s₂
  refine Fin.induction ?_ ?_ s₂
  · intro hs₁ hmem hnot
    have h0 : s₁ = 0 := Fin.le_zero_iff.mp hs₁
    subst h0
    exact absurd hmem hnot
  · intro t ih hs₁ hmem hnot
    rcases eq_or_lt_of_le hs₁ with rfl | hlt
    · exact absurd hmem hnot
    · have hs₁_le : s₁ ≤ t.castSucc := Nat.le_of_lt_succ hlt
      by_cases hx_prev : x ∈ A t.castSucc
      · exact ⟨t, hs₁_le, le_rfl, hdrop t hx_prev hnot⟩
      · rcases ih hs₁_le hmem hx_prev with ⟨u, hu1, hu2, hnotS⟩
        exact ⟨u, hu1, le_trans hu2 (Fin.castSucc_le_succ t), hnotS⟩

open Classical in
theorem prove_part4 {d : ℕ} {ι : Type} :
    ∀ (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
       (T : ℕ)
       (S_lv : Fin (T + 1) → Finset ι)
       (ev : Fin T → PoolUpdateEvent ι)
       (rootTick : Fin T → Bool)
       (qAns : Fin T → NodeMatchingQueryAnswers ι)
       (mHint : Fin T → Option ι)
       (bChoice : Fin T → PendingLevelBudgetChoices ι)
       (st_lv : Fin (T + 1) → Alg4OpenedLevel d ι),
      st_lv 0 = initAlg4OpenedLevel mode (S_lv 0) ball →
      (∀ t : Fin T,
        IsValidPoolUpdateEvent (S_lv t.castSucc) (S_lv t.succ) (ev t) ∧
        ((ev t).isClockTick = true → rootTick t = true) ∧
        let lv_arr :=
          applyOpenedLevelArrival pts mode (st_lv t.castSucc) (ev t) (qAns t) (mHint t)
        st_lv t.succ =
          if rootTick t = true then
            stepOpenedLevelBuild pts mode (S_lv t.succ) lv_arr (bChoice t)
          else
            lv_arr) →
        (∀ s : Fin (T + 1),
          (st_lv s).birthSnapshot = S_lv 0 ∧
          (st_lv s).scan2Snapshot = S_lv 0 ∧
          (st_lv s).heapIndexedIds = (st_lv s).radiusDict.indexedIds ∧
          (st_lv s).heapIndexedIds ⊆ S_lv s ∧
          (st_lv s).classifiedIds ⊆ S_lv s ∧
          S_lv s \ S_lv 0 ⊆ (st_lv s).heapIndexedIds ∧
          S_lv s \ S_lv 0 ⊆ (st_lv s).classifiedIds ∧
          (st_lv s).radiusDict.WellFormedOn pts ball.o (st_lv s).heapIndexedIds ∧
          ValidNodeMatchingsOn pts mode ball (st_lv s).classifiedIds (st_lv s).localMatchings ∧
          HasNodeAge (S_lv 0) (S_lv s) (st_lv s).trueInputAge ∧
          (st_lv s).trueInputAge ≤ (st_lv s).elapsedRootTicks ∧
          ((st_lv s).backgroundReady = true →
            (st_lv s).heapIndexedIds = S_lv s ∧ (st_lv s).classifiedIds = S_lv s) ∧
          ((∀ x ∈ S_lv 0,
              (∃ t : Fin T, t.succ ≤ s ∧ rootTick t = true ∧ x ∈ (bChoice t).scan1Batch) ∧
              (∃ t : Fin T, t.succ ≤ s ∧ rootTick t = true ∧
                x ∈ ((bChoice t).scan2Steps.map Prod.fst))) →
            (st_lv s).heapIndexedIds = S_lv s ∧ (st_lv s).classifiedIds = S_lv s)) ∧
        (∀ t : Fin T, ∀ p : ι,
          (ev t = .externalInsert p →
            p ∉ (st_lv t.castSucc).heapIndexedIds ∧
            p ∉ (st_lv t.castSucc).classifiedIds ∧
            p ∈ (st_lv t.succ).heapIndexedIds ∧
            p ∈ (st_lv t.succ).classifiedIds) ∧
          (ev t = .externalDelete p →
            p ∉ (st_lv t.succ).heapIndexedIds ∧
            p ∉ (st_lv t.succ).classifiedIds)) ∧
        ((∀ (t₁ t₂ : Fin T) (p : ι),
            ev t₁ = .externalInsert p →
              p ∉ S_lv 0 ∧ (ev t₂ = .externalInsert p → t₁ = t₂)) →
          ∀ x : ι,
            ((List.finRange T).filter (fun t =>
              decide (x ∉ (st_lv t.castSucc).heapIndexedIds ∧
                x ∈ (st_lv t.succ).heapIndexedIds))).length ≤ 1 ∧
            ((List.finRange T).filter (fun t =>
              decide (x ∉ (st_lv t.castSucc).classifiedIds ∧
                x ∈ (st_lv t.succ).classifiedIds))).length ≤ 1) := by
  intro pts mode ball T S_lv ev rootTick qAns mHint bChoice st_lv hst0 hstep
  have hInv : ∀ s : Fin (T + 1),
      (st_lv s).ball = ball ∧
      (st_lv s).birthSnapshot = S_lv 0 ∧
      (st_lv s).scan2Snapshot = S_lv 0 ∧
      (st_lv s).heapIndexedIds = (st_lv s).radiusDict.indexedIds ∧
      (st_lv s).heapIndexedIds ⊆ S_lv s ∧
      (st_lv s).classifiedIds ⊆ S_lv s ∧
      S_lv s \ S_lv 0 ⊆ (st_lv s).heapIndexedIds ∧
      S_lv s \ S_lv 0 ⊆ (st_lv s).classifiedIds ∧
      (st_lv s).radiusDict.WellFormedOn pts ball.o (st_lv s).heapIndexedIds ∧
      ValidNodeMatchingsOn pts mode ball (st_lv s).classifiedIds (st_lv s).localMatchings ∧
      HasNodeAge (S_lv 0) (S_lv s) (st_lv s).trueInputAge ∧
      (st_lv s).trueInputAge ≤ (st_lv s).elapsedRootTicks ∧
      ((st_lv s).backgroundReady = true →
        (st_lv s).heapIndexedIds = S_lv s ∧ (st_lv s).classifiedIds = S_lv s) ∧
      (∀ x ∈ S_lv 0,
        (∃ t : Fin T, t.succ ≤ s ∧ rootTick t = true ∧ x ∈ (bChoice t).scan1Batch) →
        x ∈ S_lv s → x ∈ (st_lv s).heapIndexedIds) ∧
      (∀ x ∈ S_lv 0,
        (∃ t : Fin T, t.succ ≤ s ∧ rootTick t = true ∧
          x ∈ ((bChoice t).scan2Steps.map Prod.fst)) →
        x ∈ S_lv s → x ∈ (st_lv s).classifiedIds) := by
    refine Fin.induction ?_ ?_
    · rw [hst0]
      dsimp only [initAlg4OpenedLevel]
      refine ⟨rfl, rfl, rfl, rfl, Finset.empty_subset _, Finset.empty_subset _, ?_, ?_,
        empty_radiusDict_wellFormed pts ball.o, empty_validNodeMatchingsOn pts mode ball,
        ⟨fun _ => S_lv 0, rfl, rfl, fun r => Fin.elim0 r⟩, le_rfl,
        (fun h => by cases h), ?_, ?_⟩
      · simp
      · simp
      · rintro x _ ⟨t, hle, _, _⟩
        exact absurd hle (Nat.not_succ_le_zero t.val)
      · rintro x _ ⟨t, hle, _, _⟩
        exact absurd hle (Nat.not_succ_le_zero t.val)
    · intro t ih
      rcases ih with ⟨hb, hbirth, hscan2, hheq, hhsub, hcsub, hph, hpc, hwf, hval,
        hage, hle_ticks, hready, hcov1, hcov2⟩
      rcases hstep t with ⟨hev, htick_imp, hst_succ⟩
      have harr := arrival_step_props pts mode ball (qAns t) (mHint t)
        hb hbirth hscan2 hheq hhsub hcsub hph hpc hwf hval hage hready hev
      set lv_arr := applyOpenedLevelArrival pts mode (st_lv t.castSucc) (ev t) (qAns t) (mHint t)
      rcases harr with ⟨hb_a, hbirth_a, hscan2_a, hbr_a, hel_a, hage_eq_a, hheq_a,
        hhsub_a, hcsub_a, hph_a, hpc_a, hwf_a, hval_a, hage_a, hready_a,
        hkeep_h, hkeep_c, _, _⟩
      have hcov1_arr : ∀ x ∈ S_lv 0,
          (∃ t₀ : Fin T, t₀.succ ≤ t.castSucc ∧ rootTick t₀ = true ∧
            x ∈ (bChoice t₀).scan1Batch) →
          x ∈ S_lv t.succ → x ∈ lv_arr.heapIndexedIds := by
        intro x hx0 hex hxS'
        cases h_ev : ev t with
        | externalInsert p =>
          have hev' := hev; rw [h_ev] at hev'
          rcases hev' with ⟨_, hS'⟩
          by_cases hxp : x = p
          · subst hxp
            dsimp only [lv_arr, applyOpenedLevelArrival]
            rw [h_ev]
            have hw := updateRadiusDictOnEvent_wellFormed_insert pts (st_lv t.castSucc).ball.o
              (by rw [hb]; exact hwf) x (mHint t)
            rw [hw.1]
            exact Finset.mem_insert_self x _
          · have hx_old : x ∈ S_lv t.castSucc := by
              rw [hS'] at hxS'
              exact (Finset.mem_insert.mp hxS').resolve_left hxp
            exact hkeep_h x hxS' (hcov1 x hx0 hex hx_old)
        | externalDelete p =>
          have hev' := hev; rw [h_ev] at hev'
          rcases hev' with ⟨_, hS'⟩
          have hx_old : x ∈ S_lv t.castSucc := by
            rw [hS'] at hxS'
            exact Finset.mem_of_mem_erase hxS'
          exact hkeep_h x hxS' (hcov1 x hx0 hex hx_old)
        | virtualValueDelete =>
          have hev' := hev; rw [h_ev] at hev'
          have hx_old : x ∈ S_lv t.castSucc := by rwa [← hev']
          exact hkeep_h x hxS' (hcov1 x hx0 hex hx_old)
        | unaffected =>
          have hev' := hev; rw [h_ev] at hev'
          have hx_old : x ∈ S_lv t.castSucc := by rwa [← hev']
          exact hkeep_h x hxS' (hcov1 x hx0 hex hx_old)
      have hcov2_arr : ∀ x ∈ S_lv 0,
          (∃ t₀ : Fin T, t₀.succ ≤ t.castSucc ∧ rootTick t₀ = true ∧
            x ∈ ((bChoice t₀).scan2Steps.map Prod.fst)) →
          x ∈ S_lv t.succ → x ∈ lv_arr.classifiedIds := by
        intro x hx0 hex hxS'
        cases h_ev : ev t with
        | externalInsert p =>
          have hev' := hev; rw [h_ev] at hev'
          rcases hev' with ⟨_, hS'⟩
          by_cases hxp : x = p
          · subst hxp
            dsimp only [lv_arr, applyOpenedLevelArrival]
            rw [h_ev]
            exact Finset.mem_insert_self x _
          · have hx_old : x ∈ S_lv t.castSucc := by
              rw [hS'] at hxS'
              exact (Finset.mem_insert.mp hxS').resolve_left hxp
            exact hkeep_c x hxS' (hcov2 x hx0 hex hx_old)
        | externalDelete p =>
          have hev' := hev; rw [h_ev] at hev'
          rcases hev' with ⟨_, hS'⟩
          have hx_old : x ∈ S_lv t.castSucc := by
            rw [hS'] at hxS'
            exact Finset.mem_of_mem_erase hxS'
          exact hkeep_c x hxS' (hcov2 x hx0 hex hx_old)
        | virtualValueDelete =>
          have hev' := hev; rw [h_ev] at hev'
          have hx_old : x ∈ S_lv t.castSucc := by rwa [← hev']
          exact hkeep_c x hxS' (hcov2 x hx0 hex hx_old)
        | unaffected =>
          have hev' := hev; rw [h_ev] at hev'
          have hx_old : x ∈ S_lv t.castSucc := by rwa [← hev']
          exact hkeep_c x hxS' (hcov2 x hx0 hex hx_old)
      rw [hst_succ]
      by_cases hrt : rootTick t = true
      · rw [if_pos hrt]
        have hbld := build_step_props pts mode ball (bChoice t)
          hb_a hbirth_a hscan2_a hheq_a hhsub_a hcsub_a hwf_a hval_a hready_a
        rcases hbld with ⟨hb_b, hbirth_b, hscan2_b, hage_eq_b, hel_b, hheq_b,
          hhsub_b, hcsub_b, hmono_h, hmono_c, hwf_b, hval_b, hready_b, hs1_b, hs2_b⟩
        have hticks_le1 : (ev t).ticks ≤ 1 := poolUpdateEvent_ticks_le_one (ev t)
        refine ⟨hb_b, hbirth_b, hscan2_b, hheq_b, hhsub_b, hcsub_b,
          Finset.Subset.trans hph_a hmono_h, Finset.Subset.trans hpc_a hmono_c,
          hwf_b, hval_b, ?_, ?_, hready_b, ?_, ?_⟩
        · rwa [hage_eq_b]
        · rw [hage_eq_b, hage_eq_a, hel_b, hel_a]
          omega
        · rintro x hx0 ⟨t₀, ht₀_le, hrt₀, hxB⟩ hxS'
          have hval_le : t₀.val ≤ t.val := Nat.le_of_succ_le_succ ht₀_le
          rcases eq_or_lt_of_le hval_le with hval_eq | hval_lt
          · have ht_eq : t₀ = t := Fin.ext hval_eq
            subst ht_eq
            exact hs1_b x hx0 hxS' hxB
          · exact hmono_h (hcov1_arr x hx0 ⟨t₀, hval_lt, hrt₀, hxB⟩ hxS')
        · rintro x hx0 ⟨t₀, ht₀_le, hrt₀, hxB⟩ hxS'
          have hval_le : t₀.val ≤ t.val := Nat.le_of_succ_le_succ ht₀_le
          rcases eq_or_lt_of_le hval_le with hval_eq | hval_lt
          · have ht_eq : t₀ = t := Fin.ext hval_eq
            subst ht_eq
            exact hs2_b x hx0 hxS' hxB
          · exact hmono_c (hcov2_arr x hx0 ⟨t₀, hval_lt, hrt₀, hxB⟩ hxS')
      · rw [if_neg hrt]
        have hnot_tick : (ev t).isClockTick = false := by
          cases hct : (ev t).isClockTick
          · rfl
          · exact absurd (htick_imp hct) hrt
        have hticks0 : (ev t).ticks = 0 := by
          unfold PoolUpdateEvent.ticks
          simp [hnot_tick]
        refine ⟨hb_a, hbirth_a, hscan2_a, hheq_a, hhsub_a, hcsub_a, hph_a, hpc_a,
          hwf_a, hval_a, hage_a, ?_, hready_a, ?_, ?_⟩
        · rw [hage_eq_a, hticks0, hel_a, Nat.add_zero]
          exact hle_ticks
        · rintro x hx0 ⟨t₀, ht₀_le, hrt₀, hxB⟩ hxS'
          have hval_le : t₀.val ≤ t.val := Nat.le_of_succ_le_succ ht₀_le
          rcases eq_or_lt_of_le hval_le with hval_eq | hval_lt
          · have ht_eq : t₀ = t := Fin.ext hval_eq
            subst ht_eq
            exact absurd hrt₀ hrt
          · exact hcov1_arr x hx0 ⟨t₀, hval_lt, hrt₀, hxB⟩ hxS'
        · rintro x hx0 ⟨t₀, ht₀_le, hrt₀, hxB⟩ hxS'
          have hval_le : t₀.val ≤ t.val := Nat.le_of_succ_le_succ ht₀_le
          rcases eq_or_lt_of_le hval_le with hval_eq | hval_lt
          · have ht_eq : t₀ = t := Fin.ext hval_eq
            subst ht_eq
            exact absurd hrt₀ hrt
          · exact hcov2_arr x hx0 ⟨t₀, hval_lt, hrt₀, hxB⟩ hxS'
  have hPartA : ∀ s : Fin (T + 1),
      (st_lv s).birthSnapshot = S_lv 0 ∧
      (st_lv s).scan2Snapshot = S_lv 0 ∧
      (st_lv s).heapIndexedIds = (st_lv s).radiusDict.indexedIds ∧
      (st_lv s).heapIndexedIds ⊆ S_lv s ∧
      (st_lv s).classifiedIds ⊆ S_lv s ∧
      S_lv s \ S_lv 0 ⊆ (st_lv s).heapIndexedIds ∧
      S_lv s \ S_lv 0 ⊆ (st_lv s).classifiedIds ∧
      (st_lv s).radiusDict.WellFormedOn pts ball.o (st_lv s).heapIndexedIds ∧
      ValidNodeMatchingsOn pts mode ball (st_lv s).classifiedIds (st_lv s).localMatchings ∧
      HasNodeAge (S_lv 0) (S_lv s) (st_lv s).trueInputAge ∧
      (st_lv s).trueInputAge ≤ (st_lv s).elapsedRootTicks ∧
      ((st_lv s).backgroundReady = true →
        (st_lv s).heapIndexedIds = S_lv s ∧ (st_lv s).classifiedIds = S_lv s) ∧
      ((∀ x ∈ S_lv 0,
          (∃ t : Fin T, t.succ ≤ s ∧ rootTick t = true ∧ x ∈ (bChoice t).scan1Batch) ∧
          (∃ t : Fin T, t.succ ≤ s ∧ rootTick t = true ∧
            x ∈ ((bChoice t).scan2Steps.map Prod.fst))) →
        (st_lv s).heapIndexedIds = S_lv s ∧ (st_lv s).classifiedIds = S_lv s) := by
    intro s
    rcases hInv s with ⟨_, h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, hc1, hc2⟩
    refine ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, ?_⟩
    intro hcov
    refine ⟨Finset.Subset.antisymm h4 ?_, Finset.Subset.antisymm h5 ?_⟩
    · intro x hxS
      by_cases hx0 : x ∈ S_lv 0
      · exact hc1 x hx0 (hcov x hx0).1 hxS
      · exact h6 (Finset.mem_sdiff.mpr ⟨hxS, hx0⟩)
    · intro x hxS
      by_cases hx0 : x ∈ S_lv 0
      · exact hc2 x hx0 (hcov x hx0).2 hxS
      · exact h7 (Finset.mem_sdiff.mpr ⟨hxS, hx0⟩)
  have hStepEv : ∀ t : Fin T,
      (∀ x ∈ S_lv t.succ,
        (x ∈ (st_lv t.castSucc).heapIndexedIds → x ∈ (st_lv t.succ).heapIndexedIds) ∧
        (x ∈ (st_lv t.castSucc).classifiedIds → x ∈ (st_lv t.succ).classifiedIds)) ∧
      (∀ p : ι,
        (ev t = .externalInsert p →
          p ∉ (st_lv t.castSucc).heapIndexedIds ∧
          p ∉ (st_lv t.castSucc).classifiedIds ∧
          p ∈ (st_lv t.succ).heapIndexedIds ∧
          p ∈ (st_lv t.succ).classifiedIds) ∧
        (ev t = .externalDelete p →
          p ∉ (st_lv t.succ).heapIndexedIds ∧
          p ∉ (st_lv t.succ).classifiedIds)) := by
    intro t
    rcases hInv t.castSucc with ⟨hb, hbirth, hscan2, hheq, hhsub, hcsub, hph, hpc,
      hwf, hval, hage, _, hready, _, _⟩
    rcases hstep t with ⟨hev, _, hst_succ⟩
    have harr := arrival_step_props pts mode ball (qAns t) (mHint t)
      hb hbirth hscan2 hheq hhsub hcsub hph hpc hwf hval hage hready hev
    set lv_arr := applyOpenedLevelArrival pts mode (st_lv t.castSucc) (ev t) (qAns t) (mHint t)
    rcases harr with ⟨hb_a, hbirth_a, hscan2_a, _, _, _, hheq_a,
      hhsub_a, hcsub_a, _, _, hwf_a, hval_a, _, hready_a,
      hkeep_h, hkeep_c, hins_p, hdel_p⟩
    rw [hst_succ]
    by_cases hrt : rootTick t = true
    · rw [if_pos hrt]
      have hbld := build_step_props pts mode ball (bChoice t)
        hb_a hbirth_a hscan2_a hheq_a hhsub_a hcsub_a hwf_a hval_a hready_a
      rcases hbld with ⟨_, _, _, _, _, _, hhsub_b, hcsub_b, hmono_h, hmono_c, _, _, _, _, _⟩
      refine ⟨?_, ?_⟩
      · intro x hxS'
        exact ⟨fun hx => hmono_h (hkeep_h x hxS' hx), fun hx => hmono_c (hkeep_c x hxS' hx)⟩
      · intro p
        refine ⟨?_, ?_⟩
        · intro hins
          rcases hins_p p hins with ⟨h1, h2, h3, h4⟩
          exact ⟨h1, h2, hmono_h h3, hmono_c h4⟩
        · intro hdel
          have hev' := hev; rw [hdel] at hev'
          have hp_not_S' : p ∉ S_lv t.succ := by
            rw [hev'.2]
            simp
          exact ⟨fun hm => hp_not_S' (hhsub_b hm), fun hm => hp_not_S' (hcsub_b hm)⟩
    · rw [if_neg hrt]
      refine ⟨fun x hxS' => ⟨hkeep_h x hxS', hkeep_c x hxS'⟩,
        fun p => ⟨hins_p p, hdel_p p⟩⟩
  refine ⟨hPartA, fun t p => (hStepEv t).2 p, ?_⟩
  intro hFresh x
  have hev_all : ∀ t : Fin T, IsValidPoolUpdateEvent (S_lv t.castSucc) (S_lv t.succ) (ev t) :=
    fun t => (hstep t).1
  have single_bound : ∀ (A : Fin (T + 1) → Finset ι),
      (∀ s : Fin (T + 1), A s ⊆ S_lv s) →
      (∀ t : Fin T, x ∈ S_lv t.succ → x ∈ A t.castSucc → x ∈ A t.succ) →
      ((List.finRange T).filter (fun t => decide (x ∉ A t.castSucc ∧ x ∈ A t.succ))).length ≤ 1 := by
    intro A hA_sub hA_keep
    have hdrop : ∀ t : Fin T, x ∈ A t.castSucc → x ∉ A t.succ → x ∉ S_lv t.succ := by
      intro t hmem hnot hS
      exact hnot (hA_keep t hS hmem)
    apply filter_length_le_one_of_nodup (List.nodup_finRange T)
    intro t₁ _ t₂ _ ht₁ ht₂
    simp only [decide_eq_true_eq] at ht₁ ht₂
    have hlt_false : ∀ a b : Fin T, a < b →
        (x ∉ A a.castSucc ∧ x ∈ A a.succ) →
        (x ∉ A b.castSucc ∧ x ∈ A b.succ) → False := by
      intro a b hab ha hb
      have hab_le : a.succ ≤ b.castSucc := hab
      have hex_u := exists_drop_between A S_lv hdrop hab_le ha.2 hb.1
      rcases hex_u with ⟨u, hu1, hu2, hnot_Su⟩
      have hu_le_b : u.succ ≤ b.succ := le_trans hu2 (Fin.castSucc_le_succ b)
      rcases exists_insert_between S_lv ev hev_all hu_le_b hnot_Su (hA_sub b.succ hb.2) with
        ⟨v, hv1, _, hv_ins⟩
      have hx_not0 : x ∉ S_lv 0 := (hFresh v v x hv_ins).1
      have h0_le : (0 : Fin (T + 1)) ≤ a.succ := Fin.zero_le _
      rcases exists_insert_between S_lv ev hev_all h0_le hx_not0 (hA_sub a.succ ha.2) with
        ⟨w, _, hw2, hw_ins⟩
      have hvw : v = w := (hFresh v w x hv_ins).2 hw_ins
      subst hvw
      have hw_le_a : v.val ≤ a.val := Nat.le_of_succ_le_succ hw2
      have ha_lt_v : a.val < v.val := by
        have h1 : a.val + 1 ≤ u.val := hu1
        have h2 : u.val + 1 ≤ v.val := hv1
        omega
      omega
    rcases lt_trichotomy t₁ t₂ with hlt | rfl | hgt
    · exact False.elim (hlt_false t₁ t₂ hlt ht₁ ht₂)
    · rfl
    · exact False.elim (hlt_false t₂ t₁ hgt ht₂ ht₁)
  exact ⟨single_bound (fun s => (st_lv s).heapIndexedIds)
          (fun s => (hPartA s).2.2.2.1) (fun t hxS => (hStepEv t).1 x hxS |>.1),
        single_bound (fun s => (st_lv s).classifiedIds)
          (fun s => (hPartA s).2.2.2.2.1) (fun t hxS => (hStepEv t).1 x hxS |>.2)⟩

end UL.Proof_clm_7_2_chain_schedule
