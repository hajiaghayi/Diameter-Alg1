import UL.Stmt.thm_1_2
import UL.Stmt.clm_7_3_las_vegas_endpoint
import UL.Stmt.lem_7_2
set_option autoImplicit false

namespace UL.Proof.thm_1_2.RaceV30

open UL

theorem prove_thm_1_2
    (h_clm_7_3_las_vegas_endpoint : S_clm_7_3_las_vegas_endpoint)
    (h_lem_7_2 : S_lem_7_2) : S_thm_1_2 :=
  ⟨h_lem_7_2, h_clm_7_3_las_vegas_endpoint.2.2.2⟩

end UL.Proof.thm_1_2.RaceV30
