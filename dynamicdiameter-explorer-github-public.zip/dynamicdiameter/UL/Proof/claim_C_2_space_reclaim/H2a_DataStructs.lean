import UL.Stmt.claim_C_2_space_reclaim
import UL.Proof.clm_5_2_config_gap
import UL.Proof.clm_5_3_matching_invariant.H1
import UL.Proof.claim_C_2_scans.H2a_Matching

set_option autoImplicit false

namespace UL.Proof.claim_C_2_space_reclaim

open UL
open UL.Proof_clm_5_3_matching_invariant

/-! ### 1. Coordinate-agreement congruence lemmas -/

theorem updateAlg4Coords_eq_of_not_insert {d : ℕ} {ι : Type*}
    (coords : ι → EuclideanSpace ℝ (Fin d)) (upd : Alg4PointUpdate d ι) (x : ι)
    (h : ∀ id pt, upd = .insert id pt → x ≠ id) :
    updateAlg4Coords coords upd x = coords x := by
  cases upd with
  | insert id pt =>
    classical
    simp [updateAlg4Coords, Function.update_of_ne (h id pt rfl)]
  | delete id =>
    rfl

open Classical in
theorem nodeCore_subset {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) :
    nodeCore pts o V S ⊆ S :=
  Finset.filter_subset _ _

open Classical in
theorem nodeResidual_subset {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) :
    N.residual pts S ⊆ S := by
  unfold ChainNode.residual nodeResidual
  exact Finset.sdiff_subset

theorem nodeCore_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    {S : Finset ι} (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    nodeCore pts₁ o V S = nodeCore pts₂ o V S := by
  ext x
  unfold nodeCore
  simp only [Finset.mem_filter]
  exact and_congr_right (fun hx => by rw [hpts x hx])

theorem nodeResidual_congr {d : ℕ} {ι : Type*}
    (N : ChainNode d) {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    {S : Finset ι} (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    N.residual pts₁ S = N.residual pts₂ S := by
  ext x
  unfold ChainNode.residual nodeResidual nodeCore
  simp only [Finset.mem_sdiff, Finset.mem_filter]
  exact and_congr_right (fun hx => not_congr (and_congr_right (fun _ => by rw [hpts x hx])))

theorem nodeEligible_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ)
    {S : Finset ι} (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    nodeEligible pts₁ o V K S = nodeEligible pts₂ o V K S := by
  ext x
  unfold nodeEligible
  simp only [Finset.mem_filter]
  exact and_congr_right (fun hx => by rw [hpts x hx])

theorem configLeftVertices_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) {S : Finset ι} (j : ℕ)
    (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    configLeftVertices pts₁ m0 o V S j = configLeftVertices pts₂ m0 o V S j := by
  ext x
  unfold configLeftVertices shellSubset nodeCore
  simp only [Finset.mem_filter]
  refine ⟨fun ⟨⟨hxS, hc⟩, hs⟩ => ?_, fun ⟨⟨hxS, hc⟩, hs⟩ => ?_⟩
  · rw [hpts x hxS] at hc hs; exact ⟨⟨hxS, hc⟩, hs⟩
  · rw [← hpts x hxS] at hc hs; exact ⟨⟨hxS, hc⟩, hs⟩

theorem configRightVertices_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (K : ℤ) {S : Finset ι} (k : ℕ)
    (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    configRightVertices pts₁ m0 o V K S k = configRightVertices pts₂ m0 o V K S k := by
  ext x
  unfold configRightVertices shellSubset nodeEligible
  simp only [Finset.mem_filter]
  refine ⟨fun ⟨⟨hxS, he⟩, hs⟩ => ?_, fun ⟨⟨hxS, he⟩, hs⟩ => ?_⟩
  · rw [hpts x hxS] at he hs; exact ⟨⟨hxS, he⟩, hs⟩
  · rw [← hpts x hxS] at he hs; exact ⟨⟨hxS, he⟩, hs⟩

theorem weakEdgesOn_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (m0 : ℕ) (lam : ℚ)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (ℓ : ℕ)
    {V_L V_R : Finset ι}
    (hL : ∀ x ∈ V_L, pts₁ x = pts₂ x) (hR : ∀ y ∈ V_R, pts₁ y = pts₂ y) :
    weakEdgesOn pts₁ m0 lam o V ℓ V_L V_R = weakEdgesOn pts₂ m0 lam o V ℓ V_L V_R := by
  ext xy
  unfold weakEdgesOn
  simp only [Finset.mem_filter, Finset.mem_product]
  exact and_congr_right (fun ⟨hx, hy⟩ => by rw [hL xy.1 hx, hR xy.2 hy])

theorem nodeMaxRadius_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (o : EuclideanSpace ℝ (Fin d))
    {S : Finset ι} (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    nodeMaxRadius pts₁ o S = nodeMaxRadius pts₂ o S := by
  unfold nodeMaxRadius
  split_ifs with hne
  · exact Finset.sup'_congr hne rfl (fun x hx => by rw [hpts x hx])
  · rfl

theorem isNodeMaxRadiusPoint_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (o : EuclideanSpace ℝ (Fin d))
    {S : Finset ι} (y : ι) (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    IsNodeMaxRadiusPoint pts₁ o S y ↔ IsNodeMaxRadiusPoint pts₂ o S y := by
  unfold IsNodeMaxRadiusPoint
  rw [nodeMaxRadius_congr o hpts]
  constructor <;> (rintro ⟨hy, hrad⟩; refine ⟨hy, ?_⟩; first | rwa [← hpts y hy] | rwa [hpts y hy])

theorem indexedEuclideanDiam_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} {S : Finset ι}
    (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    indexedEuclideanDiam S pts₁ = indexedEuclideanDiam S pts₂ := by
  unfold indexedEuclideanDiam
  split_ifs with hne
  · apply Finset.sup'_congr (hne.product hne) rfl
    intro xy hxy
    rcases Finset.mem_product.mp hxy with ⟨hx, hy⟩
    rw [hpts xy.1 hx, hpts xy.2 hy]
  · rfl

open Classical in
theorem foldl_residual_eq_filter {d : ℕ} {ι α : Type*}
    (ballOf : α → ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d))
    (xs : List α) (S : Finset ι) :
    xs.foldl (fun acc y => (ballOf y).residual pts acc) S =
      S.filter (fun z => ∀ y ∈ xs, pts z ∉ coreBall (ballOf y).o (ballOf y).V) := by
  induction xs generalizing S with
  | nil =>
    ext z; simp
  | cons x xs ih =>
    have hcons : (x :: xs).foldl (fun acc y => (ballOf y).residual pts acc) S =
        xs.foldl (fun acc y => (ballOf y).residual pts acc) ((ballOf x).residual pts S) := rfl
    rw [hcons, ih]
    ext z
    simp only [Finset.mem_filter, ChainNode.residual, nodeResidual, nodeCore,
      Finset.mem_sdiff, List.mem_cons, forall_eq_or_imp]
    tauto

theorem foldl_residual_subset {d : ℕ} {ι α : Type*}
    (ballOf : α → ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d))
    (xs : List α) (S : Finset ι) :
    xs.foldl (fun acc y => (ballOf y).residual pts acc) S ⊆ S := by
  classical
  rw [foldl_residual_eq_filter]
  exact Finset.filter_subset _ _

theorem foldl_residual_congr {d : ℕ} {ι α : Type*}
    (ballOf : α → ChainNode d) {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    (xs : List α) {S : Finset ι} (hpts : ∀ z ∈ S, pts₁ z = pts₂ z) :
    xs.foldl (fun acc y => (ballOf y).residual pts₁ acc) S =
      xs.foldl (fun acc y => (ballOf y).residual pts₂ acc) S := by
  classical
  rw [foldl_residual_eq_filter, foldl_residual_eq_filter]
  ext z
  simp only [Finset.mem_filter]
  refine and_congr_right (fun hz => forall_congr' (fun y => imp_congr_right (fun _ => ?_)))
  rw [hpts z hz]

open Classical in
theorem servingChainInputAt_subset {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : List (ServingNodeState d ι))
    (P : Finset ι) (idx : ℕ) :
    servingChainInputAt pts nodes P idx ⊆ P :=
  foldl_residual_subset ServingNodeState.node pts (nodes.take idx) P

open Classical in
theorem servingChainInputAt_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (nodes : List (ServingNodeState d ι))
    {P : Finset ι} (idx : ℕ) (hpts : ∀ x ∈ P, pts₁ x = pts₂ x) :
    servingChainInputAt pts₁ nodes P idx = servingChainInputAt pts₂ nodes P idx :=
  foldl_residual_congr ServingNodeState.node (nodes.take idx) hpts

open Classical in
theorem prefixResidual_subset {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (pref : List (OpenedJobLevel d ι)) (S : Finset ι) :
    prefixResidual pts pref S ⊆ S :=
  foldl_residual_subset OpenedJobLevel.ball pts pref S

open Classical in
theorem prefixResidual_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (pref : List (OpenedJobLevel d ι))
    {S : Finset ι} (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    prefixResidual pts₁ pref S = prefixResidual pts₂ pref S :=
  foldl_residual_congr OpenedJobLevel.ball pref hpts

open Classical in
theorem alg4PrefixInputAt_eq_prefixResidual {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (pref : List (Alg4OpenedLevel d ι)) (S_root : Finset ι) (j : ℕ) :
    alg4PrefixInputAt pts pref S_root j =
      prefixResidual pts ((pref.map Alg4OpenedLevel.toOpenedJobLevel).take j) S_root := by
  unfold alg4PrefixInputAt prefixResidual
  rw [← List.map_take]
  generalize pref.take j = xs
  induction xs generalizing S_root with
  | nil => rfl
  | cons lv lvs ih =>
    rw [List.map_cons, List.foldl_cons, List.foldl_cons]
    exact ih (lv.ball.residual pts S_root)

open Classical in
theorem alg4PrefixInputAt_subset {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (pref : List (Alg4OpenedLevel d ι)) (S_root : Finset ι) (j : ℕ) :
    alg4PrefixInputAt pts pref S_root j ⊆ S_root :=
  foldl_residual_subset Alg4OpenedLevel.ball pts (pref.take j) S_root

open Classical in
theorem alg4PrefixInputAt_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    (pref : List (Alg4OpenedLevel d ι)) {S_root : Finset ι} (j : ℕ)
    (hpts : ∀ x ∈ S_root, pts₁ x = pts₂ x) :
    alg4PrefixInputAt pts₁ pref S_root j = alg4PrefixInputAt pts₂ pref S_root j :=
  foldl_residual_congr Alg4OpenedLevel.ball (pref.take j) hpts

open Classical in
theorem passesBirthCoreCheck_congr {d : ℕ} {ι : Type*}
    (α : ℝ) {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (N : ChainNode d)
    {S_birth : Finset ι} (hpts : ∀ x ∈ S_birth, pts₁ x = pts₂ x) :
    PassesBirthCoreCheck α pts₁ N S_birth ↔ PassesBirthCoreCheck α pts₂ N S_birth := by
  unfold PassesBirthCoreCheck ChainNode.core
  rw [nodeCore_congr N.o N.V hpts]

theorem radiusDict_wellFormedOn_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (o : EuclideanSpace ℝ (Fin d))
    {target : Finset ι} (dict : RadiusDictState ι)
    (hpts : ∀ x ∈ target, pts₁ x = pts₂ x) :
    dict.WellFormedOn pts₁ o target ↔ dict.WellFormedOn pts₂ o target := by
  unfold RadiusDictState.WellFormedOn
  constructor <;> (
    rintro ⟨hid, hsq, hemp, hne⟩
    refine ⟨hid, ?_, hemp, ?_⟩
    · intro i hi
      have hiT : i ∈ target := hid ▸ hi
      first | (rw [← hpts i hiT]; exact hsq i hi) | (rw [hpts i hiT]; exact hsq i hi)
    · intro hne_idx
      rcases hne hne_idx with ⟨y, hmw, hmax, hdsq⟩
      have hpts_idx : ∀ x ∈ dict.indexedIds, pts₁ x = pts₂ x := fun x hx => hpts x (hid ▸ hx)
      have hyT : y ∈ target := hid ▸ hmax.1
      refine ⟨y, hmw, ?_, ?_⟩
      · first | exact (isNodeMaxRadiusPoint_congr o y hpts_idx).mp hmax
              | exact (isNodeMaxRadiusPoint_congr o y hpts_idx).mpr hmax
      · first | (rw [← hpts y hyT]; exact hdsq) | (rw [hpts y hyT]; exact hdsq))

theorem localMatchingState_wellFormed_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ι}
    (st : LocalMatchingState ι)
    (hL : ∀ x ∈ V_L, pts₁ x = pts₂ x) (hR : ∀ y ∈ V_R, pts₁ y = pts₂ y) :
    st.WellFormed pts₁ V_L V_R ↔ st.WellFormed pts₂ V_L V_R := by
  unfold LocalMatchingState.WellFormed
  constructor <;> (
    rintro ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9, h10⟩
    refine ⟨h1, h2, ?_, h4, h5, h6, h7, h8, h9, h10⟩
    intro e he
    rcases h3 e he with ⟨heL, heR, heD⟩
    refine ⟨heL, heR, ?_⟩
    first | (rw [← hL e.left heL, ← hR e.right heR]; exact heD)
          | (rw [hL e.left heL, hR e.right heR]; exact heD))

open Classical in
private theorem validNodeMatchingsOn_imp {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (mode : Alg4Mode) (ball : ChainNode d)
    {target : Finset ι} (states : ShellConfig → LocalMatchingState ι)
    (hpts : ∀ x ∈ target, pts₁ x = pts₂ x)
    (h : ValidNodeMatchingsOn pts₁ mode ball target states) :
    ValidNodeMatchingsOn pts₂ mode ball target states := by
  rcases h with ⟨hOut, hIn⟩
  refine ⟨hOut, ?_⟩
  cases mode with
  | endpointSqrt2 => exact trivial
  | subSqrt2 params =>
    intro cfg hcfg
    rcases hIn cfg hcfg with ⟨hwf, hsub⟩
    dsimp only [LocalScaleParams.leftVertices, LocalScaleParams.rightVertices,
      LocalScaleParams.weakEdges, configWeakEdges] at hwf hsub ⊢
    have hV_L_eq := configLeftVertices_congr params.m0 ball.o ball.V cfg.j hpts
    have hV_R_eq := configRightVertices_congr params.m0 ball.o ball.V params.K cfg.k hpts
    have hL1 : ∀ x ∈ configLeftVertices pts₁ params.m0 ball.o ball.V target cfg.j, pts₁ x = pts₂ x :=
      fun x hx => hpts x (nodeCore_subset _ _ _ _ (Finset.filter_subset _ _ hx))
    have hR1 : ∀ y ∈ configRightVertices pts₁ params.m0 ball.o ball.V params.K target cfg.k, pts₁ y = pts₂ y :=
      fun y hy => hpts y (Finset.filter_subset _ _ (Finset.filter_subset _ _ hy))
    have hW_eq := weakEdgesOn_congr params.m0 params.lam ball.o ball.V cfg.ℓ hL1 hR1
    have hwf2 : (states cfg).WellFormed pts₂
        (configLeftVertices pts₁ params.m0 ball.o ball.V target cfg.j)
        (configRightVertices pts₁ params.m0 ball.o ball.V params.K target cfg.k) :=
      (localMatchingState_wellFormed_congr (states cfg) hL1 hR1).mp hwf
    rw [hV_L_eq, hV_R_eq] at hwf2
    have hsub2 : (states cfg).matching ⊆
        weakEdgesOn pts₂ params.m0 params.lam ball.o ball.V cfg.ℓ
          (configLeftVertices pts₂ params.m0 ball.o ball.V target cfg.j)
          (configRightVertices pts₂ params.m0 ball.o ball.V params.K target cfg.k) := by
      rwa [← hV_L_eq, ← hV_R_eq, ← hW_eq]
    exact ⟨hwf2, hsub2⟩

open Classical in
theorem validNodeMatchingsOn_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (mode : Alg4Mode) (ball : ChainNode d)
    {target : Finset ι} (states : ShellConfig → LocalMatchingState ι)
    (hpts : ∀ x ∈ target, pts₁ x = pts₂ x) :
    ValidNodeMatchingsOn pts₁ mode ball target states ↔
      ValidNodeMatchingsOn pts₂ mode ball target states :=
  ⟨validNodeMatchingsOn_imp mode ball states hpts,
   validNodeMatchingsOn_imp mode ball states (fun x hx => (hpts x hx).symm)⟩

theorem isExactLeafAnswer_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} {S : Finset ι} (ans : Option (ι × ι))
    (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    IsExactLeafAnswer pts₁ S ans ↔ IsExactLeafAnswer pts₂ S ans := by
  unfold IsExactLeafAnswer
  split_ifs with hcard
  · rfl
  · rw [indexedEuclideanDiam_congr hpts]
    constructor <;> (
      rintro ⟨u, v, hans, hu, hv, hne, hd⟩
      refine ⟨u, v, hans, hu, hv, hne, ?_⟩
      first | rwa [← hpts u hu, ← hpts v hv] | rwa [hpts u hu, hpts v hv])

theorem baselinePairLength_congr_active {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} {S : Finset ι} {pair : Option (ι × ι)}
    (hact : IsActiveNodePair S pair) (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    baselinePairLength pts₁ pair = baselinePairLength pts₂ pair := by
  cases pair with
  | none => rfl
  | some uv =>
    rcases uv with ⟨u, v⟩
    rcases hact with ⟨hu, hv⟩
    simp [baselinePairLength, hpts u hu, hpts v hv]

theorem baselinePairLength_congr_exact {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} {S : Finset ι} {ans : Option (ι × ι)}
    (hex : IsExactLeafAnswer pts₁ S ans) (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    baselinePairLength pts₁ ans = baselinePairLength pts₂ ans := by
  unfold IsExactLeafAnswer at hex
  split_ifs at hex with hcard
  · subst hex; rfl
  · rcases hex with ⟨u, v, rfl, hu, hv, _, _⟩
    simp [baselinePairLength, hpts u hu, hpts v hv]

/-! ### 2. Radius dictionary (`RadiusDictState`) lemmas -/

theorem exists_isNodeMaxRadiusPoint {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {target : Finset ι} (hT : target.Nonempty) :
    ∃ z : ι, IsNodeMaxRadiusPoint pts o target z := by
  rcases Finset.exists_mem_eq_sup' hT (fun i => ‖pts i - o‖) with ⟨z, hz, heq⟩
  exact ⟨z, hz, by unfold nodeMaxRadius; rw [dif_pos hT]; exact heq.symm⟩

open Classical in
theorem chooseMaxRadiusWitness_none {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {target : Finset ι} (hT : ¬ target.Nonempty) (hint : Option ι) :
    chooseMaxRadiusWitness pts o target hint = none := by
  unfold chooseMaxRadiusWitness
  rw [dif_neg hT]

open Classical in
theorem chooseMaxRadiusWitness_some {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {target : Finset ι} (hT : target.Nonempty) (hint : Option ι) :
    ∃ y : ι,
      chooseMaxRadiusWitness pts o target hint = some y ∧
      IsNodeMaxRadiusPoint pts o target y := by
  have hEx : ∃ z : ι, IsNodeMaxRadiusPoint pts o target z := exists_isNodeMaxRadiusPoint pts o hT
  unfold chooseMaxRadiusWitness
  rw [dif_pos hT]
  cases hint with
  | none =>
    dsimp only
    rw [dif_pos hEx]
    exact ⟨Classical.choose hEx, rfl, Classical.choose_spec hEx⟩
  | some y =>
    dsimp only
    by_cases hy : IsNodeMaxRadiusPoint pts o target y
    · rw [if_pos hy]
      exact ⟨y, rfl, hy⟩
    · rw [if_neg hy, dif_pos hEx]
      exact ⟨Classical.choose hEx, rfl, Classical.choose_spec hEx⟩

open Classical in
theorem buildRadiusDictOn_wellFormed {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (target : Finset ι) (hint : Option ι) :
    (buildRadiusDictOn pts o target hint).WellFormedOn pts o target := by
  unfold buildRadiusDictOn RadiusDictState.WellFormedOn
  dsimp only
  refine ⟨rfl, fun _ _ => rfl, ?_, ?_⟩
  · intro hemp
    have hnot : ¬ target.Nonempty := by rw [hemp]; exact Finset.not_nonempty_empty
    rw [chooseMaxRadiusWitness_none pts o hnot hint]
    exact ⟨rfl, rfl⟩
  · intro hT
    rcases chooseMaxRadiusWitness_some pts o hT hint with ⟨y, hmw, hmax⟩
    rw [hmw]
    exact ⟨y, rfl, hmax, rfl⟩

theorem empty_radiusDict_wellFormed {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) :
    (RadiusDictState.empty ι).WellFormedOn pts o ∅ := by
  unfold RadiusDictState.empty RadiusDictState.WellFormedOn
  exact ⟨rfl, fun _ hi => False.elim (Finset.notMem_empty _ hi),
    fun _ => ⟨rfl, rfl⟩, fun h => False.elim (Finset.not_nonempty_empty h)⟩

open Classical in
theorem updateRadiusDictOnEvent_wellFormed_insert {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {A : Finset ι} {dict : RadiusDictState ι}
    (hwf : dict.WellFormedOn pts o A) (p : ι) (maxHint : Option ι) :
    (updateRadiusDictOnEvent pts o dict (.externalInsert p) maxHint).WellFormedOn
      pts o (insert p A) := by
  unfold updateRadiusDictOnEvent
  rw [hwf.1]
  exact buildRadiusDictOn_wellFormed pts o (insert p A) _

open Classical in
theorem updateRadiusDictOnEvent_wellFormed_delete {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {A : Finset ι} {dict : RadiusDictState ι}
    (hwf : dict.WellFormedOn pts o A) (p : ι) (maxHint : Option ι) :
    (updateRadiusDictOnEvent pts o dict (.externalDelete p) maxHint).WellFormedOn
      pts o (A.erase p) := by
  unfold updateRadiusDictOnEvent
  dsimp only
  by_cases hp : p ∈ dict.indexedIds
  · rw [if_pos hp, hwf.1]
    exact buildRadiusDictOn_wellFormed pts o (A.erase p) maxHint
  · rw [if_neg hp]
    have hpA : p ∉ A := by rwa [← hwf.1]
    rwa [Finset.erase_eq_of_notMem hpA]

open Classical in
theorem updateRadiusDictOnEvent_complete {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {S S' : Finset ι} {ev : PoolUpdateEvent ι} {dict : RadiusDictState ι}
    (hev : IsValidPoolUpdateEvent S S' ev)
    (hcomp : dict.IsComplete pts o S) (maxHint : Option ι) :
    (updateRadiusDictOnEvent pts o dict ev maxHint).IsComplete pts o S' := by
  unfold RadiusDictState.IsComplete at hcomp ⊢
  cases ev with
  | externalInsert p =>
    rcases hev with ⟨_, rfl⟩
    exact updateRadiusDictOnEvent_wellFormed_insert pts o hcomp p maxHint
  | externalDelete p =>
    rcases hev with ⟨_, rfl⟩
    exact updateRadiusDictOnEvent_wellFormed_delete pts o hcomp p maxHint
  | virtualValueDelete =>
    subst hev
    exact hcomp
  | unaffected =>
    subst hev
    exact hcomp

open Classical in
theorem scan1RadiusDictBatch_wellFormed {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {S_cur H : Finset ι} {dict : RadiusDictState ι}
    (hwf : dict.WellFormedOn pts o H) (hsub : H ⊆ S_cur)
    (B : Finset ι) (maxHint : Option ι) :
    let dict' := scan1RadiusDictBatch pts o S_cur dict B maxHint
    dict'.indexedIds = H ∪ ((B ∩ S_cur) \ H) ∧
    dict'.indexedIds ⊆ S_cur ∧
    dict'.WellFormedOn pts o dict'.indexedIds ∧
    S_cur \ dict'.indexedIds = (S_cur \ H) \ B := by
  dsimp only [scan1RadiusDictBatch]
  rw [hwf.1]
  set T := H ∪ ((B ∩ S_cur) \ H)
  have hbwf := buildRadiusDictOn_wellFormed pts o T (maxHint.or dict.maxWitness)
  have hidx : (buildRadiusDictOn pts o T (maxHint.or dict.maxWitness)).indexedIds = T := hbwf.1
  have hT_sub : T ⊆ S_cur := by
    intro x hx
    rcases Finset.mem_union.mp hx with hxH | hxN
    · exact hsub hxH
    · exact (Finset.mem_inter.mp (Finset.mem_sdiff.mp hxN).1).2
  have hdiff : S_cur \ T = (S_cur \ H) \ B := by
    ext x
    simp only [T, Finset.mem_sdiff, Finset.mem_union, Finset.mem_inter]
    tauto
  rw [hidx]
  exact ⟨rfl, hT_sub, hbwf, hdiff⟩

/-! ### 3. Checked local matchings (`ValidNodeMatchingsOn`) lemmas -/

private theorem distScale_pos_of_pos {lam : ℚ} {V : ℝ} (hlam : 1 < lam) (hV : 0 < V) (ℓ : ℕ) :
    0 < distScale lam V ℓ := by
  unfold distScale
  have hlam_pos : (0 : ℝ) < (lam : ℝ) := by exact_mod_cast (lt_trans zero_lt_one hlam)
  positivity

open Classical in
private theorem exists_big_gamma_strongEdges_empty {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (m0 : ℕ) {lam : ℚ}
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (ℓ : ℕ)
    (hlam : 1 < lam) (hV : 0 < V) (A B : Finset ι) :
    ∃ γ_big : ℚ, 1 < γ_big ∧
      ∀ U ⊆ A, ∀ W ⊆ B, strongEdgesOn pts m0 γ_big lam o V ℓ U W = ∅ := by
  have hds : 0 < distScale lam V ℓ := distScale_pos_of_pos hlam hV ℓ
  let bound : ℝ :=
    if hAB : (A ×ˢ B).Nonempty then
      (A ×ˢ B).sup' hAB (fun xy => ‖inwardRound m0 o V (pts xy.1) - inwardRound m0 o V (pts xy.2)‖)
    else 0
  rcases exists_rat_gt (max 1 ((bound + 1) / distScale lam V ℓ)) with ⟨γ_big, hγ_gt⟩
  have hγ1 : 1 < γ_big := by
    have : (1 : ℝ) < (γ_big : ℝ) := lt_of_le_of_lt (le_max_left _ _) hγ_gt
    exact_mod_cast this
  have hγ_bnd : (bound + 1) / distScale lam V ℓ < (γ_big : ℝ) :=
    lt_of_le_of_lt (le_max_right _ _) hγ_gt
  have hmul : bound + 1 < (γ_big : ℝ) * distScale lam V ℓ :=
    (div_lt_iff₀ hds).mp hγ_bnd
  refine ⟨γ_big, hγ1, ?_⟩
  intro U hU W hW
  rw [Finset.eq_empty_iff_forall_notMem]
  intro xy hxy
  unfold strongEdgesOn IsStrongRoundedPair at hxy
  rcases Finset.mem_filter.mp hxy with ⟨hUW, hlt⟩
  have hAB_mem : xy ∈ A ×ˢ B := Finset.product_subset_product hU hW hUW
  have hAB_ne : (A ×ˢ B).Nonempty := ⟨xy, hAB_mem⟩
  have hle_bound : ‖inwardRound m0 o V (pts xy.1) - inwardRound m0 o V (pts xy.2)‖ ≤ bound := by
    dsimp only [bound]
    rw [dif_pos hAB_ne]
    exact Finset.le_sup' (fun z : ι × ι => ‖inwardRound m0 o V (pts z.1) - inwardRound m0 o V (pts z.2)‖) hAB_mem
  linarith

open Classical in
private theorem satisfiesInvariant_iff_of_strong_empty {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {U W E_weak E_strong : Finset _}
    (hE : E_strong = ∅) (st : LocalMatchingState ι) :
    st.SatisfiesInvariant pts U W E_weak E_strong ↔
      (st.WellFormed pts U W ∧ st.matching ⊆ E_weak) := by
  subst hE
  unfold LocalMatchingState.SatisfiesInvariant SatisfiesLocalMatchingInvariant
  constructor
  · rintro ⟨hwf, hsub, _, _⟩
    exact ⟨hwf, hsub⟩
  · rintro ⟨hwf, hsub⟩
    exact ⟨hwf, hsub, bipartiteMatching_of_wellFormed hwf, Finset.disjoint_left.mpr (fun _ hx => False.elim (Finset.notMem_empty _ hx))⟩

private theorem radialCorrelation_symm' {d : ℕ} (o x y : EuclideanSpace ℝ (Fin d)) :
    radialCorrelation o x y = radialCorrelation o y x := by
  unfold radialCorrelation
  rw [inner_neg_left, inner_neg_left, real_inner_comm]

open Classical in
private theorem mem_retainedConfigs_mode_subSqrt2 {params : LocalScaleParams} {V : ℝ}
    {cfg : ShellConfig} (hcfg : cfg ∈ (Alg4Mode.subSqrt2 params).retainedConfigs V) :
    0 < V ∧ IsRetainedConfig params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ := by
  unfold Alg4Mode.retainedConfigs at hcfg
  split_ifs at hcfg with hV
  · refine ⟨hV, ?_⟩
    unfold LocalScaleParams.retainedConfigs retainedConfigs allShellConfigs allShellConfigTriples at hcfg
    rw [Finset.mem_filter, Finset.mem_map] at hcfg
    rcases hcfg with ⟨⟨⟨j, k, ℓ⟩, hmem, heq⟩, hret⟩
    dsimp only [Function.Embedding.coeFn_mk] at heq
    subst heq
    simp only [Finset.mem_product, Finset.mem_Icc] at hmem
    rcases hmem with ⟨⟨hj1, hj2⟩, ⟨hk1, hk2⟩, ⟨_, hℓ2⟩⟩
    refine ⟨⟨hj1, hj2, hk1, ?_, hℓ2⟩, hret⟩
    unfold maxShellIndex at hk2
    have hc : 0 < params.c - 1 := sub_pos.mpr params.one_lt_c
    have hdiv : 0 < 2 / (params.c - 1) := div_pos (by norm_num) hc
    have hK_pos : (0 : ℝ) < (params.K : ℝ) := lt_of_lt_of_le hdiv params.K_ge
    have hK0 : 0 ≤ params.K := le_of_lt (Int.cast_pos.mp hK_pos)
    have hcast : ((params.K.toNat * shellSubdiv params.e : ℕ) : ℤ) =
        params.K * (shellSubdiv params.e : ℤ) := by
      rw [Nat.cast_mul, Int.toNat_of_nonneg hK0]
    have hk_z : (k : ℤ) ≤ ((params.K.toNat * shellSubdiv params.e : ℕ) : ℤ) := by
      exact_mod_cast hk2
    rwa [hcast] at hk_z
  · exact False.elim (Finset.notMem_empty _ hcfg)

open Classical in
private theorem sanitizeConfigAttachAnswer_validEdgeStep {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (params : LocalScaleParams)
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} {cfg : ShellConfig}
    (hV : 0 < V)
    (hret : IsRetainedConfig params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ)
    {S U W : Finset ι}
    (hU : U ⊆ configLeftVertices pts params.m0 o V S cfg.j)
    (hW : W ⊆ configRightVertices pts params.m0 o V params.K S cfg.k)
    {γ_big : ℚ}
    (hStrongEmpty : strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ U W = ∅)
    {st : LocalMatchingState ι} {v : CopyVertex ι}
    (hpre : IsAttachPrecond U W st v)
    (hwf₀ :
      let U₀ := if v.side = .left then U.erase v.id else U
      let W₀ := if v.side = .right then W.erase v.id else W
      st.WellFormed pts U₀ W₀)
    (rawAns : Option ι) :
    let checked := sanitizeConfigAttachAnswer pts params o V cfg st v rawAns
    ValidAttachEdgeStep pts U W
      (weakEdgesOn pts params.m0 params.lam o V cfg.ℓ U W)
      (strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ U W)
      st v (attachStep pts st v checked) := by
  dsimp only
  set checked := sanitizeConfigAttachAnswer pts params o V cfg st v rawAns
  refine ⟨hpre, checked, ?_, rfl⟩
  have hgap := (P_clm_5_2_config_gap params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ
    params.e_pos params.one_lt_γ params.one_lt_lam hV hret).1 d
  have hshellL : ∀ x ∈ U, shellIndex params.m0 o V (pts x) = cfg.j := fun x hx =>
    (Finset.mem_filter.mp (hU hx)).2
  have hshellR : ∀ y ∈ W, shellIndex params.m0 o V (pts y) = cfg.k := fun y hy =>
    (Finset.mem_filter.mp (hW hy)).2
  rcases v with ⟨side, vid⟩
  cases side with
  | left =>
    dsimp only at hwf₀
    rw [if_pos rfl, if_neg (by intro h; cases h)] at hwf₀
    have hrset : st.rightIndexSet = unmatchedRight W st.matching := hwf₀.2.2.2.2.2.2.1
    cases hchk : checked with
    | none =>
      dsimp only [SatisfiesEdgeSearchPromise]
      rw [hStrongEmpty]
      intro w _; exact Finset.notMem_empty _
    | some w =>
      dsimp only [SatisfiesEdgeSearchPromise, LocalMatchingState.oppositeIndexSet]
      have hsan : checked = sanitizeConfigAttachAnswer pts params o V cfg st ⟨.left, vid⟩ rawAns := rfl
      rw [hchk] at hsan
      unfold sanitizeConfigAttachAnswer at hsan
      cases rawAns with
      | none => cases hsan
      | some w₀ =>
        dsimp only at hsan
        split_ifs at hsan with hcond
        · injection hsan with hw_eq
          subst hw_eq
          rcases hcond with ⟨hw_opp, hcorr⟩
          dsimp only [LocalMatchingState.oppositeIndexSet] at hw_opp
          have hw_W : w ∈ W := (Finset.mem_filter.mp (hrset ▸ hw_opp)).1
          have hweak : IsWeakRoundedPair params.m0 params.lam o V cfg.ℓ (pts vid) (pts w) :=
            (hgap o (pts vid) (pts w) (hshellL vid hpre.1) (hshellR w hw_W)).2.mpr hcorr
          exact ⟨hw_opp, Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hpre.1, hw_W⟩, hweak⟩⟩
  | right =>
    dsimp only at hwf₀
    rw [if_neg (by intro h; cases h), if_pos rfl] at hwf₀
    have hlset : st.leftIndexSet = unmatchedLeft U st.matching := hwf₀.2.2.2.2.1
    cases hchk : checked with
    | none =>
      dsimp only [SatisfiesEdgeSearchPromise]
      rw [hStrongEmpty]
      intro w _; exact Finset.notMem_empty _
    | some w =>
      dsimp only [SatisfiesEdgeSearchPromise, LocalMatchingState.oppositeIndexSet]
      have hsan : checked = sanitizeConfigAttachAnswer pts params o V cfg st ⟨.right, vid⟩ rawAns := rfl
      rw [hchk] at hsan
      unfold sanitizeConfigAttachAnswer at hsan
      cases rawAns with
      | none => cases hsan
      | some w₀ =>
        dsimp only at hsan
        split_ifs at hsan with hcond
        · injection hsan with hw_eq
          subst hw_eq
          rcases hcond with ⟨hw_opp, hcorr⟩
          dsimp only [LocalMatchingState.oppositeIndexSet] at hw_opp
          have hw_U : w ∈ U := (Finset.mem_filter.mp (hlset ▸ hw_opp)).1
          unfold attachAcceptsCorrelation at hcorr
          rw [radialCorrelation_symm'] at hcorr
          have hweak : IsWeakRoundedPair params.m0 params.lam o V cfg.ℓ (pts w) (pts vid) :=
            (hgap o (pts w) (pts vid) (hshellL w hw_U) (hshellR vid hpre.1)).2.mpr hcorr
          exact ⟨hw_opp, Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hw_U, hpre.1⟩, hweak⟩⟩

open Classical in
theorem empty_validNodeMatchingsOn {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d) :
    ValidNodeMatchingsOn pts mode ball ∅ (fun _ => LocalMatchingState.empty ι) := by
  refine ⟨fun _ _ => rfl, ?_⟩
  cases mode with
  | endpointSqrt2 => exact trivial
  | subSqrt2 params =>
    intro cfg _
    have hemp := empty_satisfiesInvariant pts params ball.o ball.V cfg
    exact ⟨hemp.1, hemp.2.1⟩

open Classical in
private theorem not_matched_not_inIndex_left {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ι}
    {st : LocalMatchingState ι} (hwf : st.WellFormed pts V_L V_R) {p : ι} (hp : p ∉ V_L) :
    ¬ st.isCopyMatched ⟨.left, p⟩ ∧ ¬ st.isCopyInIndex ⟨.left, p⟩ := by
  rcases hwf with ⟨_, _, hEdges, _, hLeftSet, _⟩
  refine ⟨?_, ?_⟩
  · rintro ⟨e, he, rfl⟩; exact hp (hEdges e he).1
  · rintro ⟨e, he, rfl⟩
    have hmem : e.id ∈ st.leftIndexSet := List.mem_toFinset.mpr (List.mem_map_of_mem he)
    rw [hLeftSet] at hmem
    exact hp (Finset.mem_of_mem_filter e.id hmem)

open Classical in
private theorem not_matched_not_inIndex_right {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ι}
    {st : LocalMatchingState ι} (hwf : st.WellFormed pts V_L V_R) {p : ι} (hp : p ∉ V_R) :
    ¬ st.isCopyMatched ⟨.right, p⟩ ∧ ¬ st.isCopyInIndex ⟨.right, p⟩ := by
  rcases hwf with ⟨_, _, hEdges, _, _, _, hRightSet, _⟩
  refine ⟨?_, ?_⟩
  · rintro ⟨e, he, rfl⟩; exact hp (hEdges e he).2.1
  · rintro ⟨e, he, rfl⟩
    have hmem : e.id ∈ st.rightIndexSet := List.mem_toFinset.mpr (List.mem_map_of_mem he)
    rw [hRightSet] at hmem
    exact hp (Finset.mem_of_mem_filter e.id hmem)

open Classical in
theorem applyNodeMatchingInsert_valid {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    {target : Finset ι} {states : ShellConfig → LocalMatchingState ι}
    {p : ι} (hp : p ∉ target) (qAns : NodeMatchingQueryAnswers ι)
    (hval : ValidNodeMatchingsOn pts mode ball target states) :
    ValidNodeMatchingsOn pts mode ball (insert p target)
      (applyNodeMatchingInsert pts mode ball states p qAns) := by
  cases mode with
  | endpointSqrt2 =>
    exact ⟨fun _ _ => rfl, trivial⟩
  | subSqrt2 params =>
    refine ⟨fun cfg hnot => by simp [applyNodeMatchingInsert, hnot], ?_⟩
    intro cfg hcfg
    dsimp only [applyNodeMatchingInsert]
    rw [if_pos hcfg]
    rcases mem_retainedConfigs_mode_subSqrt2 hcfg with ⟨hV, hret⟩
    rcases hval.2 cfg hcfg with ⟨hwf, hsub⟩
    set S' := insert p target
    set V_L := configLeftVertices pts params.m0 ball.o ball.V target cfg.j
    set V_R := configRightVertices pts params.m0 ball.o ball.V params.K target cfg.k
    set V_L' := configLeftVertices pts params.m0 ball.o ball.V S' cfg.j
    set V_R' := configRightVertices pts params.m0 ball.o ball.V params.K S' cfg.k
    have hVL_sub : V_L ⊆ V_L' := by
      intro x hx
      simp only [V_L, V_L', S', configLeftVertices, shellSubset, nodeCore, Finset.mem_filter] at hx ⊢
      exact ⟨⟨Finset.mem_insert_of_mem hx.1.1, hx.1.2⟩, hx.2⟩
    have hVR_sub : V_R ⊆ V_R' := by
      intro x hx
      simp only [V_R, V_R', S', configRightVertices, shellSubset, nodeEligible, Finset.mem_filter] at hx ⊢
      exact ⟨⟨Finset.mem_insert_of_mem hx.1.1, hx.1.2⟩, hx.2⟩
    have hVL_erase : V_L'.erase p = V_L := by
      ext x
      simp only [V_L', V_L, S', configLeftVertices, shellSubset, nodeCore,
        Finset.mem_erase, Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨hne, ⟨hmem | hmem, hcore⟩, hsh⟩
        · exact False.elim (hne hmem)
        · exact ⟨⟨hmem, hcore⟩, hsh⟩
      · rintro ⟨⟨hmem, hcore⟩, hsh⟩
        exact ⟨fun hEq => hp (hEq ▸ hmem), ⟨Or.inr hmem, hcore⟩, hsh⟩
    have hVR_erase : V_R'.erase p = V_R := by
      ext x
      simp only [V_R', V_R, S', configRightVertices, shellSubset, nodeEligible,
        Finset.mem_erase, Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨hne, ⟨hmem | hmem, helig⟩, hsh⟩
        · exact False.elim (hne hmem)
        · exact ⟨⟨hmem, helig⟩, hsh⟩
      · rintro ⟨⟨hmem, helig⟩, hsh⟩
        exact ⟨fun hEq => hp (hEq ▸ hmem), ⟨Or.inr hmem, helig⟩, hsh⟩
    have hp_not_VL : p ∉ V_L := fun h => hp (nodeCore_subset _ _ _ _ (Finset.filter_subset _ _ h))
    have hp_not_VR : p ∉ V_R := fun h => hp (Finset.filter_subset _ _ (Finset.filter_subset _ _ h))
    rcases exists_big_gamma_strongEdges_empty pts params.m0 ball.o cfg.ℓ
      params.one_lt_lam hV V_L' V_R' with ⟨γ_big, _, hStrongEmpty⟩
    have hInv₀ : (states cfg).SatisfiesInvariant pts V_L V_R
        (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L V_R)
        (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ V_L V_R) :=
      (satisfiesInvariant_iff_of_strong_empty (hStrongEmpty V_L hVL_sub V_R hVR_sub) (states cfg)).mpr
        ⟨hwf, hsub⟩
    unfold checkedConfigInsertOriginal
    set st₁ :=
      if hasApplicableLeftCopy params.m0 ball.o ball.V cfg.j (pts p) then
        attachStep pts (states cfg) ⟨.left, p⟩
          (sanitizeConfigAttachAnswer pts params ball.o ball.V cfg (states cfg) ⟨.left, p⟩
            (qAns.insertLeftAns cfg))
      else states cfg
    have hInv₁ : st₁.SatisfiesInvariant pts V_L' V_R
        (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L' V_R)
        (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ V_L' V_R) := by
      by_cases hAppL : hasApplicableLeftCopy params.m0 ball.o ball.V cfg.j (pts p)
      · have hst1_eq : st₁ = attachStep pts (states cfg) ⟨.left, p⟩
            (sanitizeConfigAttachAnswer pts params ball.o ball.V cfg (states cfg) ⟨.left, p⟩
              (qAns.insertLeftAns cfg)) := if_pos hAppL
        rw [hst1_eq]
        have hp_VL' : p ∈ V_L' := by
          unfold V_L' configLeftVertices shellSubset nodeCore
          unfold hasApplicableLeftCopy at hAppL
          simp [S', hAppL.1, hAppL.2]
        rcases not_matched_not_inIndex_left hwf hp_not_VL with ⟨hnm, hni⟩
        have hpre : IsAttachPrecond V_L' V_R (states cfg) ⟨.left, p⟩ := ⟨hp_VL', hnm, hni⟩
        have hinv_pre :
            let U₀ := if (CopyVertex.mk .left p).side = .left then V_L'.erase p else V_L'
            let W₀ := if (CopyVertex.mk .left p).side = .right then V_R.erase p else V_R
            (states cfg).SatisfiesInvariant pts U₀ W₀
              (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ U₀ W₀)
              (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ U₀ W₀) := by
          dsimp only
          rw [if_pos rfl, if_neg (by intro h; cases h), hVL_erase]
          exact hInv₀
        have hedge := sanitizeConfigAttachAnswer_validEdgeStep pts params ball.o hV hret
          (Finset.Subset.rfl) hVR_sub (hStrongEmpty V_L' Finset.Subset.rfl V_R hVR_sub)
          hpre hinv_pre.1 (qAns.insertLeftAns cfg)
        exact attach_edge_preserves_invariant pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ
          V_L' V_R (states cfg) ⟨.left, p⟩ _ hinv_pre hedge
      · have hst1_eq : st₁ = states cfg := if_neg hAppL
        have hVL'_eq : V_L' = V_L := by
          ext x
          by_cases hxp : x = p
          · subst hxp
            constructor
            · intro hx
              unfold V_L' configLeftVertices shellSubset nodeCore at hx
              simp only [Finset.mem_filter] at hx
              exact False.elim (hAppL ⟨hx.1.2, hx.2⟩)
            · intro hx; exact False.elim (hp_not_VL hx)
          · rw [← hVL_erase, Finset.mem_erase]
            exact ⟨fun hx => ⟨hxp, hx⟩, fun hx => hx.2⟩
        rw [hst1_eq, hVL'_eq]
        exact hInv₀
    have hInv₂ :
        (if hasApplicableRightCopy params.m0 ball.o ball.V params.K cfg.k (pts p) then
          attachStep pts st₁ ⟨.right, p⟩
            (sanitizeConfigAttachAnswer pts params ball.o ball.V cfg st₁ ⟨.right, p⟩
              (qAns.insertRightAns cfg))
        else st₁).SatisfiesInvariant pts V_L' V_R'
          (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L' V_R')
          (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ V_L' V_R') := by
      by_cases hAppR : hasApplicableRightCopy params.m0 ball.o ball.V params.K cfg.k (pts p)
      · rw [if_pos hAppR]
        have hp_VR' : p ∈ V_R' := by
          unfold V_R' configRightVertices shellSubset nodeEligible
          unfold hasApplicableRightCopy at hAppR
          simp [S', hAppR.1, hAppR.2]
        rcases not_matched_not_inIndex_right hInv₁.1 hp_not_VR with ⟨hnm, hni⟩
        have hpre : IsAttachPrecond V_L' V_R' st₁ ⟨.right, p⟩ := ⟨hp_VR', hnm, hni⟩
        have hinv_pre :
            let U₀ := if (CopyVertex.mk .right p).side = .left then V_L'.erase p else V_L'
            let W₀ := if (CopyVertex.mk .right p).side = .right then V_R'.erase p else V_R'
            st₁.SatisfiesInvariant pts U₀ W₀
              (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ U₀ W₀)
              (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ U₀ W₀) := by
          dsimp only
          rw [if_neg (by intro h; cases h), if_pos rfl, hVR_erase]
          exact hInv₁
        have hedge := sanitizeConfigAttachAnswer_validEdgeStep pts params ball.o hV hret
          (Finset.Subset.rfl) (Finset.Subset.rfl)
          (hStrongEmpty V_L' Finset.Subset.rfl V_R' Finset.Subset.rfl)
          hpre hinv_pre.1 (qAns.insertRightAns cfg)
        exact attach_edge_preserves_invariant pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ
          V_L' V_R' st₁ ⟨.right, p⟩ _ hinv_pre hedge
      · rw [if_neg hAppR]
        have hVR'_eq : V_R' = V_R := by
          ext x
          by_cases hxp : x = p
          · subst hxp
            constructor
            · intro hx
              unfold V_R' configRightVertices shellSubset nodeEligible at hx
              simp only [Finset.mem_filter] at hx
              exact False.elim (hAppR ⟨hx.1.2, hx.2⟩)
            · intro hx; exact False.elim (hp_not_VR hx)
          · rw [← hVR_erase, Finset.mem_erase]
            exact ⟨fun hx => ⟨hxp, hx⟩, fun hx => hx.2⟩
        rw [hVR'_eq]
        exact hInv₁
    exact (satisfiesInvariant_iff_of_strong_empty
      (hStrongEmpty V_L' Finset.Subset.rfl V_R' Finset.Subset.rfl) _).mp hInv₂

open Classical in
private theorem checkedRepairFormerPartners_preserves {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (params : LocalScaleParams)
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} {cfg : ShellConfig}
    (hV : 0 < V)
    (hret : IsRetainedConfig params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ)
    (S' : Finset ι) {γ_big : ℚ}
    (hStrongEmpty : ∀ U ⊆ configLeftVertices pts params.m0 o V S' cfg.j,
      ∀ W ⊆ configRightVertices pts params.m0 o V params.K S' cfg.k,
      strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ U W = ∅) :
    let V_L' := configLeftVertices pts params.m0 o V S' cfg.j
    let V_R' := configRightVertices pts params.m0 o V params.K S' cfg.k
    ∀ (F : List (CopyVertex ι)) (cur : LocalMatchingState ι) (rawAnswers : List (Option ι)),
      F.Nodup →
      (∀ u ∈ F, isCopyActive V_L' V_R' u) →
      cur.SatisfiesInvariant pts (remLeft F V_L') (remRight F V_R')
        (weakEdgesOn pts params.m0 params.lam o V cfg.ℓ (remLeft F V_L') (remRight F V_R'))
        (strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ (remLeft F V_L') (remRight F V_R')) →
      (checkedRepairFormerPartners pts params o V cfg cur F rawAnswers).SatisfiesInvariant
        pts V_L' V_R'
        (weakEdgesOn pts params.m0 params.lam o V cfg.ℓ V_L' V_R')
        (strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ V_L' V_R') := by
  dsimp only
  set V_L' := configLeftVertices pts params.m0 o V S' cfg.j
  set V_R' := configRightVertices pts params.m0 o V params.K S' cfg.k
  intro F
  induction F with
  | nil =>
    intro cur rawAnswers _ _ hinv
    unfold checkedRepairFormerPartners
    have hL : remLeft [] V_L' = V_L' := by ext x; simp [remLeft]
    have hR : remRight [] V_R' = V_R' := by ext y; simp [remRight]
    rwa [hL, hR] at hinv
  | cons u us ih =>
    intro cur rawAnswers hnd hact hinv
    rw [List.nodup_cons] at hnd
    rcases hnd with ⟨hu_not_us, hnd_us⟩
    have hu_absent : ¬ (cur.isCopyMatched u ∨ cur.isCopyInIndex u) := by
      rcases hinv.1 with ⟨_, _, hedges, _, hlset, _, hrset, _⟩
      rcases u with ⟨side, uid⟩
      cases side with
      | left =>
        have huid_not : uid ∉ remLeft (⟨.left, uid⟩ :: us) V_L' := by simp [remLeft]
        dsimp only [LocalMatchingState.isCopyMatched, LocalMatchingState.isCopyInIndex]
        rintro (⟨e, he, hel⟩ | ⟨e, he, heid⟩)
        · subst hel; exact huid_not (hedges e he).1
        · have hmem : uid ∈ cur.leftIndexSet :=
            List.mem_toFinset.mpr (List.mem_map.mpr ⟨e, he, heid⟩)
          rw [hlset] at hmem
          exact huid_not (Finset.mem_filter.mp hmem).1
      | right =>
        have huid_not : uid ∉ remRight (⟨.right, uid⟩ :: us) V_R' := by simp [remRight]
        dsimp only [LocalMatchingState.isCopyMatched, LocalMatchingState.isCopyInIndex]
        rintro (⟨e, he, her⟩ | ⟨e, he, heid⟩)
        · subst her; exact huid_not (hedges e he).2.1
        · have hmem : uid ∈ cur.rightIndexSet :=
            List.mem_toFinset.mpr (List.mem_map.mpr ⟨e, he, heid⟩)
          rw [hrset] at hmem
          exact huid_not (Finset.mem_filter.mp hmem).1
    unfold checkedRepairFormerPartners
    rw [if_neg hu_absent]
    let A_next := remLeft us V_L'
    let B_next := remRight us V_R'
    have hA_sub : A_next ⊆ V_L' := Finset.filter_subset _ _
    have hB_sub : B_next ⊆ V_R' := Finset.filter_subset _ _
    have hu_act_next : isCopyActive A_next B_next u := by
      have hu_act := hact u List.mem_cons_self
      rcases u with ⟨side, uid⟩
      cases side <;> exact Finset.mem_filter.mpr ⟨hu_act, hu_not_us⟩
    have hpre : IsAttachPrecond A_next B_next cur u := by
      rw [not_or] at hu_absent
      exact ⟨hu_act_next, hu_absent.1, hu_absent.2⟩
    have hA0_eq : (if u.side = .left then A_next.erase u.id else A_next) = remLeft (u :: us) V_L' := by
      rcases u with ⟨side, uid⟩
      cases side with
      | left =>
        dsimp only; rw [if_pos rfl]; ext x; simp [A_next, remLeft]; tauto
      | right =>
        dsimp only; rw [if_neg (by intro h; cases h)]; ext x; simp [A_next, remLeft]
    have hB0_eq : (if u.side = .right then B_next.erase u.id else B_next) = remRight (u :: us) V_R' := by
      rcases u with ⟨side, uid⟩
      cases side with
      | left =>
        dsimp only; rw [if_neg (by intro h; cases h)]; ext y; simp [B_next, remRight]
      | right =>
        dsimp only; rw [if_pos rfl]; ext y; simp [B_next, remRight]; tauto
    have hinv_pre :
        let U₀ := if u.side = .left then A_next.erase u.id else A_next
        let W₀ := if u.side = .right then B_next.erase u.id else B_next
        cur.SatisfiesInvariant pts U₀ W₀
          (weakEdgesOn pts params.m0 params.lam o V cfg.ℓ U₀ W₀)
          (strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ U₀ W₀) := by
      dsimp only
      rwa [hA0_eq, hB0_eq]
    have hedge := sanitizeConfigAttachAnswer_validEdgeStep pts params o hV hret
      hA_sub hB_sub (hStrongEmpty A_next hA_sub B_next hB_sub)
      hpre hinv_pre.1 rawAnswers.head?.join
    have hInvNext := attach_edge_preserves_invariant pts params.m0 γ_big params.lam o V cfg.ℓ
      A_next B_next cur u _ hinv_pre hedge
    exact ih _ (rawAnswers.drop 1) hnd_us (fun v hv => hact v (List.mem_cons_of_mem u hv)) hInvNext

open Classical in
theorem applyNodeMatchingDelete_valid {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    {target : Finset ι} {states : ShellConfig → LocalMatchingState ι}
    (p : ι) (qAns : NodeMatchingQueryAnswers ι)
    (hval : ValidNodeMatchingsOn pts mode ball target states) :
    ValidNodeMatchingsOn pts mode ball (target.erase p)
      (applyNodeMatchingDelete pts mode ball states p qAns) := by
  cases mode with
  | endpointSqrt2 =>
    exact ⟨fun _ _ => rfl, trivial⟩
  | subSqrt2 params =>
    refine ⟨fun cfg hnot => by simp [applyNodeMatchingDelete, hnot], ?_⟩
    intro cfg hcfg
    dsimp only [applyNodeMatchingDelete]
    rw [if_pos hcfg]
    rcases mem_retainedConfigs_mode_subSqrt2 hcfg with ⟨hV, hret⟩
    rcases hval.2 cfg hcfg with ⟨hwf, hsub⟩
    set S' := target.erase p
    set V_L := configLeftVertices pts params.m0 ball.o ball.V target cfg.j
    set V_R := configRightVertices pts params.m0 ball.o ball.V params.K target cfg.k
    set V_L' := configLeftVertices pts params.m0 ball.o ball.V S' cfg.j
    set V_R' := configRightVertices pts params.m0 ball.o ball.V params.K S' cfg.k
    have hVL_erase : V_L.erase p = V_L' := by
      ext x
      simp only [V_L, V_L', S', configLeftVertices, shellSubset, nodeCore,
        Finset.mem_erase, Finset.mem_filter]
      tauto
    have hVR_erase : V_R.erase p = V_R' := by
      ext x
      simp only [V_R, V_R', S', configRightVertices, shellSubset, nodeEligible,
        Finset.mem_erase, Finset.mem_filter]
      tauto
    have hVL'_sub : V_L' ⊆ V_L := hVL_erase ▸ Finset.erase_subset p V_L
    have hVR'_sub : V_R' ⊆ V_R := hVR_erase ▸ Finset.erase_subset p V_R
    rcases exists_big_gamma_strongEdges_empty pts params.m0 ball.o cfg.ℓ
      params.one_lt_lam hV V_L V_R with ⟨γ_big, _, hStrongEmpty⟩
    have hInv₀ : (states cfg).SatisfiesInvariant pts V_L V_R
        (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L V_R)
        (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ V_L V_R) :=
      (satisfiesInvariant_iff_of_strong_empty
        (hStrongEmpty V_L Finset.Subset.rfl V_R Finset.Subset.rfl) (states cfg)).mpr ⟨hwf, hsub⟩
    have hRem := removeCopies_satisfies_invariant pts params.m0 γ_big params.lam
      ball.o ball.V cfg.ℓ V_L V_R (states cfg) p hInv₀
    dsimp only at hRem
    rw [hVL_erase, hVR_erase] at hRem
    set F := survivingFormerPartners (states cfg) p
    have hF_nd : F.Nodup := List.nodup_dedup _
    have hF_act : ∀ u ∈ F, isCopyActive V_L' V_R' u := by
      intro u hu
      rw [← hVL_erase, ← hVR_erase]
      exact surviving_partners_active hwf p hu
    unfold checkedConfigDeleteOriginal
    have hRep := checkedRepairFormerPartners_preserves pts params ball.o hV hret S'
      (fun U hU W hW => hStrongEmpty U (hU.trans hVL'_sub) W (hW.trans hVR'_sub))
      F (removeCopiesFromState (states cfg) p) (qAns.deleteRepairAns cfg) hF_nd hF_act hRem
    exact (satisfiesInvariant_iff_of_strong_empty
      (hStrongEmpty V_L' hVL'_sub V_R' hVR'_sub) _).mp hRep

open Classical in
theorem applyScan2Batch_valid {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (ball : ChainNode d) (S_lv scan2Snap : Finset ι) :
    ∀ (cls : Finset ι) (lm : ShellConfig → LocalMatchingState ι)
      (steps : List (ι × NodeMatchingQueryAnswers ι)),
      cls ⊆ S_lv →
      ValidNodeMatchingsOn pts mode ball cls lm →
      let out := applyScan2Batch pts mode ball S_lv scan2Snap cls lm steps
      out.1 ⊆ S_lv ∧
      ValidNodeMatchingsOn pts mode ball out.1 out.2 ∧
      S_lv \ out.1 = (S_lv \ cls) \ ((steps.map Prod.fst).toFinset ∩ scan2Snap) := by
  intro cls lm steps
  induction steps generalizing cls lm with
  | nil =>
    intro hsub hval
    simp [applyScan2Batch, hsub, hval]
  | cons step rest ih =>
    rcases step with ⟨q, qAns⟩
    intro hsub hval
    unfold applyScan2Batch
    split_ifs with hcond
    · rcases hcond with ⟨hq_snap, hq_S, hq_not_cls⟩
      have hsub' : insert q cls ⊆ S_lv := Finset.insert_subset_iff.mpr ⟨hq_S, hsub⟩
      have hval' := applyNodeMatchingInsert_valid pts mode ball hq_not_cls qAns hval
      rcases ih (insert q cls) _ hsub' hval' with ⟨h1, h2, h3⟩
      refine ⟨h1, h2, ?_⟩
      rw [h3]
      ext x
      simp only [Finset.mem_sdiff, Finset.mem_insert, Finset.mem_inter, List.map_cons,
        List.toFinset_cons]
      constructor
      · rintro ⟨⟨hxS, hxq_or⟩, hnot⟩
        rw [not_or] at hxq_or
        refine ⟨⟨hxS, hxq_or.2⟩, ?_⟩
        rintro ⟨hx_q | hx_rest, hx_snap⟩
        · exact hxq_or.1 hx_q
        · exact hnot ⟨hx_rest, hx_snap⟩
      · rintro ⟨⟨hxS, hxcls⟩, hnot⟩
        refine ⟨⟨hxS, ?_⟩, ?_⟩
        · rintro (rfl | hxcls')
          · exact hnot ⟨Or.inl rfl, hq_snap⟩
          · exact hxcls hxcls'
        · rintro ⟨hx_rest, hx_snap⟩
          exact hnot ⟨Or.inr hx_rest, hx_snap⟩
    · rcases ih cls lm hsub hval with ⟨h1, h2, h3⟩
      refine ⟨h1, h2, ?_⟩
      rw [h3]
      ext x
      simp only [Finset.mem_sdiff, Finset.mem_inter, List.map_cons, List.toFinset_cons,
        Finset.mem_insert]
      constructor
      · rintro ⟨⟨hxS, hxcls⟩, hnot⟩
        refine ⟨⟨hxS, hxcls⟩, ?_⟩
        rintro ⟨rfl | hx_rest, hx_snap⟩
        · exact hcond ⟨hx_snap, hxS, hxcls⟩
        · exact hnot ⟨hx_rest, hx_snap⟩
      · rintro ⟨⟨hxS, hxcls⟩, hnot⟩
        exact ⟨⟨hxS, hxcls⟩, fun h => hnot ⟨Or.inr h.1, h.2⟩⟩

open Classical in
theorem buildSyncNodeMatchings_valid {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (ball : ChainNode d) (S_cur : Finset ι)
    (insertSteps : List (ι × NodeMatchingQueryAnswers ι)) :
    ValidNodeMatchingsOn pts mode ball S_cur
      (buildSyncNodeMatchings pts mode ball S_cur insertSteps) := by
  unfold buildSyncNodeMatchings
  let stepFn (acc : Finset ι × (ShellConfig → LocalMatchingState ι))
      (pq : ι × NodeMatchingQueryAnswers ι) :=
    if pq.1 ∈ S_cur ∧ pq.1 ∉ acc.1 then
      (insert pq.1 acc.1, applyNodeMatchingInsert pts mode ball acc.2 pq.1 pq.2)
    else acc
  have hfold1 : ∀ (steps : List (ι × NodeMatchingQueryAnswers ι))
      (cov : Finset ι) (lm : ShellConfig → LocalMatchingState ι),
      cov ⊆ S_cur →
      ValidNodeMatchingsOn pts mode ball cov lm →
      let res := steps.foldl stepFn (cov, lm)
      res.1 ⊆ S_cur ∧ ValidNodeMatchingsOn pts mode ball res.1 res.2 := by
    intro steps
    induction steps with
    | nil =>
      intro cov lm hsub hval
      exact ⟨hsub, hval⟩
    | cons pq rest ih =>
      intro cov lm hsub hval
      dsimp only [List.foldl_cons, stepFn]
      split_ifs with hcond
      · exact ih (insert pq.1 cov) _
          (Finset.insert_subset_iff.mpr ⟨hcond.1, hsub⟩)
          (applyNodeMatchingInsert_valid pts mode ball hcond.2 pq.2 hval)
      · exact ih cov lm hsub hval
  rcases hfold1 insertSteps ∅ (fun _ => LocalMatchingState.empty ι)
      (Finset.empty_subset _) (empty_validNodeMatchingsOn pts mode ball) with
    ⟨hcov_sub, hlm1_val⟩
  set res1 := insertSteps.foldl stepFn (∅, fun _ => LocalMatchingState.empty ι)
  have hfold2 : ∀ (rem : List ι) (cov : Finset ι) (lm : ShellConfig → LocalMatchingState ι),
      rem.Nodup →
      (∀ x ∈ rem, x ∉ cov) →
      ValidNodeMatchingsOn pts mode ball cov lm →
      ValidNodeMatchingsOn pts mode ball (cov ∪ rem.toFinset)
        (rem.foldl (fun acc p => applyNodeMatchingInsert pts mode ball acc p
          (NodeMatchingQueryAnswers.empty ι)) lm) := by
    intro rem
    induction rem with
    | nil =>
      intro cov lm _ _ hval
      simpa using hval
    | cons p ps ih =>
      intro cov lm hnd hdisj hval
      rw [List.nodup_cons] at hnd
      have hp_not_cov : p ∉ cov := hdisj p List.mem_cons_self
      have hval' := applyNodeMatchingInsert_valid pts mode ball hp_not_cov
        (NodeMatchingQueryAnswers.empty ι) hval
      have hdisj' : ∀ x ∈ ps, x ∉ insert p cov := by
        intro x hx hmem
        rcases Finset.mem_insert.mp hmem with rfl | hxcov
        · exact hnd.1 hx
        · exact hdisj x (List.mem_cons_of_mem p hx) hxcov
      have hres := ih (insert p cov) _ hnd.2 hdisj' hval'
      have hunion : insert p cov ∪ ps.toFinset = cov ∪ (p :: ps).toFinset := by
        ext x
        simp only [Finset.mem_union, Finset.mem_insert, List.toFinset_cons]
        tauto
      rwa [hunion] at hres
  have hrem_nd : (S_cur \ res1.1).toList.Nodup := Finset.nodup_toList _
  have hrem_disj : ∀ x ∈ (S_cur \ res1.1).toList, x ∉ res1.1 := by
    intro x hx
    exact (Finset.mem_sdiff.mp (Finset.mem_toList.mp hx)).2
  have htot := hfold2 (S_cur \ res1.1).toList res1.1 res1.2 hrem_nd hrem_disj hlm1_val
  have hunion_eq : res1.1 ∪ (S_cur \ res1.1).toList.toFinset = S_cur := by
    ext x
    simp only [Finset.mem_union, List.mem_toFinset, Finset.mem_toList, Finset.mem_sdiff]
    exact ⟨fun h => h.elim (fun hx => hcov_sub hx) (fun hx => hx.1),
      fun hx => if hc : x ∈ res1.1 then Or.inl hc else Or.inr ⟨hx, hc⟩⟩
  rwa [hunion_eq] at htot

/-! ### 4. Cache & answer selection lemmas -/

theorem pickMaxByReal_mem_and_ge {α : Type*} (f : α → ℝ) (best : α) (xs : List α) :
    pickMaxByReal f best xs ∈ best :: xs ∧
    ∀ z ∈ best :: xs, f z ≤ f (pickMaxByReal f best xs) := by
  induction xs generalizing best with
  | nil =>
    simp [pickMaxByReal]
  | cons x xs ih =>
    unfold pickMaxByReal
    split_ifs with hlt
    · rcases ih x with ⟨hmem, hge⟩
      refine ⟨List.mem_cons_of_mem best hmem, ?_⟩
      intro z hz
      rcases List.mem_cons.mp hz with rfl | hz'
      · exact le_of_lt (lt_of_lt_of_le hlt (hge x List.mem_cons_self))
      · exact hge z hz'
    · rcases ih best with ⟨hmem, hge⟩
      have hmem' : pickMaxByReal f best xs ∈ best :: x :: xs := by
        rcases List.mem_cons.mp hmem with heq | hxs
        · rw [heq]; exact List.mem_cons_self
        · exact List.mem_cons_of_mem best (List.mem_cons_of_mem x hxs)
      refine ⟨hmem', ?_⟩
      intro z hz
      rcases List.mem_cons.mp hz with rfl | hz'
      · exact hge z List.mem_cons_self
      · rcases List.mem_cons.mp hz' with rfl | hxs
        · exact le_trans (not_lt.mp hlt) (hge best List.mem_cons_self)
        · exact hge z (List.mem_cons_of_mem best hxs)

open Classical in
theorem refreshBaselineFromSamples_spec {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S : Finset ι) (dict : RadiusDictState ι) (samples : List ι) :
    let out := refreshBaselineFromSamples pts o S dict samples
    IsActiveNodePair S out.1 ∧
    out.2 = (baselinePairLength pts out.1) ^ 2 := by
  dsimp only [refreshBaselineFromSamples]
  by_cases hS : S.Nonempty
  · rcases chooseMaxRadiusWitness_some pts o hS dict.maxWitness with ⟨y, hmw, hmax⟩
    rw [hmw]
    dsimp only
    cases hsamps : samples.filter (fun p => decide (p ∈ S)) with
    | nil =>
      dsimp only [IsActiveNodePair, baselinePairLength, euclideanDistSq]
      exact ⟨⟨hmax.1, hmax.1⟩, rfl⟩
    | cons s ss =>
      dsimp only [IsActiveNodePair, baselinePairLength, euclideanDistSq]
      have hm := (pickMaxByReal_mem_and_ge (fun p => euclideanDistSq (pts p) (pts y)) s ss).1
      have hmem_filt : pickMaxByReal (fun p => euclideanDistSq (pts p) (pts y)) s ss ∈
          samples.filter (fun p => decide (p ∈ S)) := by
        rwa [hsamps]
      have hpS : pickMaxByReal (fun p => euclideanDistSq (pts p) (pts y)) s ss ∈ S := by
        simpa using (List.mem_filter.mp hmem_filt).2
      exact ⟨⟨hmax.1, hpS⟩, rfl⟩
  · rw [chooseMaxRadiusWitness_none pts o hS dict.maxWitness]
    dsimp only [IsActiveNodePair, baselinePairLength]
    exact ⟨Finset.not_nonempty_iff_eq_empty.mp hS, by ring⟩

open Classical in
theorem storedEdge_of_validNodeMatchingsOn {d : ℕ} {ι : Type*}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode} {ball : ChainNode d}
    {S : Finset ι} {states : ShellConfig → LocalMatchingState ι}
    (hval : ValidNodeMatchingsOn pts mode ball S states)
    {cfg : ShellConfig} (hcfg : cfg ∈ mode.retainedConfigs ball.V)
    {u v : ι} (hst : (states cfg).storedEdge = some (u, v)) :
    u ∈ S ∧ v ∈ S ∧ u ≠ v := by
  cases mode with
  | endpointSqrt2 =>
    exact False.elim (Finset.notMem_empty _ hcfg)
  | subSqrt2 params =>
    rcases mem_retainedConfigs_mode_subSqrt2 hcfg with ⟨hV, _⟩
    rcases hval.2 cfg hcfg with ⟨_, hM_sub⟩
    unfold LocalMatchingState.storedEdge at hst
    cases hhd : (states cfg).matchingList.head? with
    | none => rw [hhd] at hst; cases hst
    | some e =>
      rw [hhd] at hst
      dsimp only [Option.map, MatchingEdge.pair] at hst
      injection hst with heq
      have he_mem : e ∈ (states cfg).matchingList := List.mem_of_head? hhd
      have hpair_mem : (u, v) ∈ (states cfg).matching := by
        rw [← heq]
        exact List.mem_toFinset.mpr (List.mem_map_of_mem he_mem)
      have hw := hM_sub hpair_mem
      unfold LocalScaleParams.weakEdges configWeakEdges weakEdgesOn at hw
      rcases Finset.mem_filter.mp hw with ⟨hprod, hweak⟩
      rcases Finset.mem_product.mp hprod with ⟨huL, hvR⟩
      have huS : u ∈ S := nodeCore_subset _ _ _ _ (Finset.filter_subset _ _ huL)
      have hvS : v ∈ S := Finset.filter_subset _ _ (Finset.filter_subset _ _ hvR)
      have hne : u ≠ v := by
        intro hEq
        subst hEq
        unfold IsWeakRoundedPair at hweak
        rw [sub_self, norm_zero] at hweak
        linarith [distScale_pos_of_pos params.one_lt_lam hV cfg.ℓ]
      exact ⟨huS, hvS, hne⟩

open Classical in
theorem refreshMaxMatchingWitness_spec {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (ball : ChainNode d)
    {S : Finset ι} {states : ShellConfig → LocalMatchingState ι}
    (hval : ValidNodeMatchingsOn pts mode ball S states)
    (hintCfg : Option ShellConfig) :
    let out := refreshMaxMatchingWitness pts mode ball states hintCfg
    match out.1 with
    | none =>
        out.2 = 0 ∧
        ∀ cfg ∈ mode.retainedConfigs ball.V, (states cfg).storedEdge = none
    | some (x, y) =>
        x ∈ S ∧ y ∈ S ∧ x ≠ y ∧
        out.2 = euclideanDistSq (pts x) (pts y) ∧
        (∃ cfg ∈ mode.retainedConfigs ball.V, (states cfg).storedEdge = some (x, y)) ∧
        (∀ cfg ∈ mode.retainedConfigs ball.V, ∀ u v : ι,
          (states cfg).storedEdge = some (u, v) →
            euclideanDistSq (pts u) (pts v) ≤ out.2) := by
  dsimp only [refreshMaxMatchingWitness]
  set nonemptyCfgs :=
    (mode.retainedConfigs ball.V).filter (fun cfg => ((states cfg).storedEdge).isSome)
  by_cases hNE : nonemptyCfgs.Nonempty
  · rw [dif_pos hNE]
    set edgeSq : ShellConfig → ℝ := fun cfg =>
      match (states cfg).storedEdge with
      | none => 0
      | some (x, y) => euclideanDistSq (pts x) (pts y)
    set bestSq := nonemptyCfgs.sup' hNE edgeSq
    set isBest : ShellConfig → Prop := fun cfg => cfg ∈ nonemptyCfgs ∧ edgeSq cfg = bestSq
    have hEx : ∃ c', isBest c' := by
      rcases Finset.exists_mem_eq_sup' hNE edgeSq with ⟨c', hc', heq⟩
      exact ⟨c', hc', heq.symm⟩
    set chosenCfg : ShellConfig :=
      match hintCfg with
      | some c =>
          if isBest c then c
          else if hEx' : ∃ c', isBest c' then Classical.choose hEx'
          else hNE.choose
      | none =>
          if hEx' : ∃ c', isBest c' then Classical.choose hEx'
          else hNE.choose
    have hBest : isBest chosenCfg := by
      dsimp only [chosenCfg]
      cases hintCfg with
      | none =>
        rw [dif_pos hEx]
        exact Classical.choose_spec hEx
      | some c =>
        dsimp only
        by_cases hc : isBest c
        · rw [if_pos hc]
          exact hc
        · rw [if_neg hc, dif_pos hEx]
          exact Classical.choose_spec hEx
    rcases hBest with ⟨hc_mem, hc_sq⟩
    rcases Finset.mem_filter.mp hc_mem with ⟨hc_ret, hc_some⟩
    change (let out := match (states chosenCfg).storedEdge with
              | none => (none, 0)
              | some (x, y) => (some (x, y), euclideanDistSq (pts x) (pts y));
            match out.1 with
            | none =>
                out.2 = 0 ∧
                ∀ cfg ∈ mode.retainedConfigs ball.V, (states cfg).storedEdge = none
            | some (x, y) =>
                x ∈ S ∧ y ∈ S ∧ x ≠ y ∧
                out.2 = euclideanDistSq (pts x) (pts y) ∧
                (∃ cfg ∈ mode.retainedConfigs ball.V, (states cfg).storedEdge = some (x, y)) ∧
                (∀ cfg ∈ mode.retainedConfigs ball.V, ∀ u v : ι,
                  (states cfg).storedEdge = some (u, v) →
                    euclideanDistSq (pts u) (pts v) ≤ out.2))
    cases hst : (states chosenCfg).storedEdge with
    | none => rw [hst] at hc_some; cases hc_some
    | some xy =>
      rcases xy with ⟨x, y⟩
      dsimp only
      rcases storedEdge_of_validNodeMatchingsOn hval hc_ret hst with ⟨hxS, hyS, hne⟩
      have hbest_eq : euclideanDistSq (pts x) (pts y) = bestSq := by
        dsimp only [edgeSq] at hc_sq
        rwa [hst] at hc_sq
      refine ⟨hxS, hyS, hne, rfl, ⟨chosenCfg, hc_ret, hst⟩, ?_⟩
      intro cfg hcfg u v huv
      have hcfg_ne : cfg ∈ nonemptyCfgs := by
        apply Finset.mem_filter.mpr
        rw [huv]
        exact ⟨hcfg, rfl⟩
      have hle : edgeSq cfg ≤ bestSq := Finset.le_sup' edgeSq hcfg_ne
      dsimp only [edgeSq] at hle
      rw [huv] at hle
      rwa [hbest_eq]
  · rw [dif_neg hNE]
    refine ⟨rfl, ?_⟩
    intro cfg hcfg
    cases hst : (states cfg).storedEdge with
    | none => rfl
    | some uv =>
      exfalso
      apply hNE
      refine ⟨cfg, Finset.mem_filter.mpr ⟨hcfg, ?_⟩⟩
      rw [hst]; rfl

open Classical in
theorem computeExactLeafAnswer_spec {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) (hint : Option (ι × ι)) :
    let out := computeExactLeafAnswer pts S hint
    IsExactLeafAnswer pts S out.1 ∧
    out.2 = (baselinePairLength pts out.1) ^ 2 := by
  unfold computeExactLeafAnswer IsExactLeafAnswer
  split_ifs with hcard
  · exact ⟨rfl, by simp [baselinePairLength]⟩
  · have hgt1 : 1 < S.card := Nat.lt_of_not_ge hcard
    have hS_ne : S.Nonempty := Finset.card_pos.mp (by omega)
    let isExact (uv : ι × ι) : Prop :=
      uv.1 ∈ S ∧ uv.2 ∈ S ∧ uv.1 ≠ uv.2 ∧ ‖pts uv.1 - pts uv.2‖ = indexedEuclideanDiam S pts
    have hEx : ∃ uv', isExact uv' := by
      rcases Finset.exists_mem_eq_sup' (hS_ne.product hS_ne)
          (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) with ⟨⟨x, y⟩, hxy_mem, hxy_sup⟩
      rcases Finset.mem_product.mp hxy_mem with ⟨hxS, hyS⟩
      have hdiam_eq : indexedEuclideanDiam S pts = ‖pts x - pts y‖ := by
        unfold indexedEuclideanDiam
        rw [dif_pos hS_ne]
        exact hxy_sup
      by_cases hne : x ≠ y
      · exact ⟨(x, y), hxS, hyS, hne, hdiam_eq.symm⟩
      · push_neg at hne
        subst hne
        rw [sub_self, norm_zero] at hdiam_eq
        rcases Finset.one_lt_card.mp hgt1 with ⟨u, huS, v, hvS, huv⟩
        have hle0 : ‖pts u - pts v‖ ≤ 0 := by
          have huv_mem : (u, v) ∈ S ×ˢ S := Finset.mem_product.mpr ⟨huS, hvS⟩
          have hle := Finset.le_sup' (f := fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) huv_mem
          have hsup0 : (S ×ˢ S).sup' (hS_ne.product hS_ne)
              (fun xy : ι × ι => ‖pts xy.1 - pts xy.2‖) = 0 := by
            unfold indexedEuclideanDiam at hdiam_eq
            rwa [dif_pos hS_ne] at hdiam_eq
          linarith
        have hnorm0 : ‖pts u - pts v‖ = 0 := le_antisymm hle0 (norm_nonneg _)
        exact ⟨(u, v), huS, hvS, huv, hnorm0.trans hdiam_eq.symm⟩
    let chosen : Option (ι × ι) :=
      match hint with
      | some uv =>
          if isExact uv then some uv
          else if hEx' : ∃ uv', isExact uv' then some (Classical.choose hEx')
          else none
      | none =>
          if hEx' : ∃ uv', isExact uv' then some (Classical.choose hEx')
          else none
    have hChosen : ∃ u v : ι, chosen = some (u, v) ∧ isExact (u, v) := by
      dsimp only [chosen]
      cases hint with
      | none =>
        rw [dif_pos hEx]
        rcases hc : Classical.choose hEx with ⟨u, v⟩
        have hspec := Classical.choose_spec hEx
        rw [hc] at hspec
        exact ⟨u, v, rfl, hspec⟩
      | some uv =>
        rcases uv with ⟨u, v⟩
        dsimp only
        by_cases huv : isExact (u, v)
        · rw [if_pos huv]
          exact ⟨u, v, rfl, huv⟩
        · rw [if_neg huv, dif_pos hEx]
          rcases hc : Classical.choose hEx with ⟨u, v⟩
          have hspec := Classical.choose_spec hEx
          rw [hc] at hspec
          exact ⟨u, v, rfl, hspec⟩
    rcases hChosen with ⟨u, v, hch_eq, huS, hvS, huv, hdiam⟩
    change (let out := match chosen with
              | none => (none, 0)
              | some (u, v) => (some (u, v), euclideanDistSq (pts u) (pts v));
            (∃ u v : ι, out.1 = some (u, v) ∧ u ∈ S ∧ v ∈ S ∧ u ≠ v ∧
              ‖pts u - pts v‖ = indexedEuclideanDiam S pts) ∧
            out.2 = (baselinePairLength pts out.1) ^ 2)
    rw [hch_eq]
    exact ⟨⟨u, v, rfl, huS, hvS, huv, hdiam⟩, rfl⟩

open Classical in
theorem updateDistinctFallbackPair_spec {ι : Type*}
    (P' : Finset ι) (prevFallback hint : Option (ι × ι)) :
    let out := updateDistinctFallbackPair P' prevFallback hint
    if P'.card ≤ 1 then
      out = none
    else
      ∃ d₁ d₂ : ι, out = some (d₁, d₂) ∧ d₁ ∈ P' ∧ d₂ ∈ P' ∧ d₁ ≠ d₂ := by
  unfold updateDistinctFallbackPair
  split_ifs with hcard
  · rfl
  · have hgt1 : 1 < P'.card := Nat.lt_of_not_ge hcard
    rcases Finset.one_lt_card.mp hgt1 with ⟨a, ha, b, hb, hab⟩
    let valid (uv : ι × ι) : Prop := uv.1 ∈ P' ∧ uv.2 ∈ P' ∧ uv.1 ≠ uv.2
    have hEx : ∃ w : ι × ι, valid w := ⟨(a, b), ha, hb, hab⟩
    have hHint : ∀ h : Option (ι × ι),
        ∃ d₁ d₂ : ι,
          (match h with
           | some uv' =>
               if valid uv' then some uv'
               else if hEx' : ∃ w : ι × ι, valid w then some (Classical.choose hEx')
               else none
           | none =>
               if hEx' : ∃ w : ι × ι, valid w then some (Classical.choose hEx')
               else none) = some (d₁, d₂) ∧ valid (d₁, d₂) := by
      intro h
      cases h with
      | none =>
        rw [dif_pos hEx]
        rcases hc : Classical.choose hEx with ⟨d₁, d₂⟩
        have hs := Classical.choose_spec hEx
        rw [hc] at hs
        exact ⟨d₁, d₂, rfl, hs⟩
      | some uv' =>
        rcases uv' with ⟨d₁, d₂⟩
        dsimp only
        by_cases hv : valid (d₁, d₂)
        · rw [if_pos hv]
          exact ⟨d₁, d₂, rfl, hv⟩
        · rw [if_neg hv, dif_pos hEx]
          rcases hc : Classical.choose hEx with ⟨d₁, d₂⟩
          have hs := Classical.choose_spec hEx
          rw [hc] at hs
          exact ⟨d₁, d₂, rfl, hs⟩
    cases prevFallback with
    | none =>
      rcases hHint hint with ⟨d₁, d₂, heq, hd₁, hd₂, hne⟩
      exact ⟨d₁, d₂, heq, hd₁, hd₂, hne⟩
    | some uv =>
      rcases uv with ⟨u, v⟩
      dsimp only
      by_cases huv : u ∈ P' ∧ v ∈ P' ∧ u ≠ v
      · rw [if_pos huv]
        exact ⟨u, v, rfl, huv.1, huv.2.1, huv.2.2⟩
      · rw [if_neg huv]
        rcases hHint hint with ⟨d₁, d₂, heq, hd₁, hd₂, hne⟩
        exact ⟨d₁, d₂, heq, hd₁, hd₂, hne⟩

open Classical in
theorem alg4Line12SelectCachedAnswer_spec {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (P' : Finset ι)
    (servingNodes : List (Alg4ServingNode d ι))
    (leafAns : Option (ι × ι)) (leafSq : ℝ)
    (fallback : Option (ι × ι))
    (hNodes : ∀ sn ∈ servingNodes,
      (∀ u v, sn.baselinePair = some (u, v) →
        u ∈ P' ∧ v ∈ P' ∧ sn.baselineDistSq = euclideanDistSq (pts u) (pts v)) ∧
      (∀ u v, sn.maxMatchingPair = some (u, v) →
        u ∈ P' ∧ v ∈ P' ∧ sn.maxMatchingDistSq = euclideanDistSq (pts u) (pts v)))
    (hLeaf : ∀ u v, leafAns = some (u, v) →
      u ∈ P' ∧ v ∈ P' ∧ leafSq = euclideanDistSq (pts u) (pts v))
    (hFallback : if P'.card ≤ 1 then fallback = none
      else ∃ d₁ d₂ : ι, fallback = some (d₁, d₂) ∧ d₁ ∈ P' ∧ d₂ ∈ P' ∧ d₁ ≠ d₂) :
    let ans := alg4Line12SelectCachedAnswer pts P' servingNodes leafAns leafSq fallback
    if P'.card ≤ 1 then
      ans = (none, 0)
    else
      ∃ u v : ι,
        ans.1 = some (u, v) ∧ u ∈ P' ∧ v ∈ P' ∧ u ≠ v ∧
        ans.2 = euclideanDistSq (pts u) (pts v) := by
  unfold alg4Line12SelectCachedAnswer
  split_ifs with hcard
  · rfl
  · rw [if_neg hcard] at hFallback
    rcases hFallback with ⟨d₁, d₂, hfb_eq, hd₁, hd₂, hd_ne⟩
    have hcands_valid : ∀ cand ∈ collectCachedCandidatePairs servingNodes leafAns leafSq,
        cand.1.1 ∈ P' ∧ cand.1.2 ∈ P' ∧ cand.2 = euclideanDistSq (pts cand.1.1) (pts cand.1.2) := by
      intro cand hmem
      unfold collectCachedCandidatePairs at hmem
      rw [List.mem_append] at hmem
      rcases hmem with hnode | hlf
      · rw [List.mem_flatMap] at hnode
        rcases hnode with ⟨sn, hsn, hfrom⟩
        rcases hNodes sn hsn with ⟨hB, hM⟩
        rw [List.mem_append] at hfrom
        rcases hfrom with hb | hm
        · cases hbp : sn.baselinePair with
          | none => rw [hbp] at hb; cases hb
          | some uv =>
            rw [hbp, List.mem_singleton] at hb
            subst hb
            exact hB uv.1 uv.2 hbp
        · cases hmp : sn.maxMatchingPair with
          | none => rw [hmp] at hm; cases hm
          | some uv =>
            rw [hmp, List.mem_singleton] at hm
            subst hm
            exact hM uv.1 uv.2 hmp
      · cases hla : leafAns with
        | none => rw [hla] at hlf; cases hlf
        | some uv =>
          rw [hla, List.mem_singleton] at hlf
          subst hlf
          exact hLeaf uv.1 uv.2 hla
    cases hcands : collectCachedCandidatePairs servingNodes leafAns leafSq with
    | nil =>
      dsimp only
      rw [hfb_eq]
      exact ⟨d₁, d₂, rfl, hd₁, hd₂, hd_ne, rfl⟩
    | cons c cs =>
      dsimp only
      set best := pickMaxByReal Prod.snd c cs
      have hbest_mem : best ∈ collectCachedCandidatePairs servingNodes leafAns leafSq := by
        rw [hcands]
        exact (pickMaxByReal_mem_and_ge Prod.snd c cs).1
      rcases hcands_valid best hbest_mem with ⟨hb1, hb2, hbsq⟩
      rcases best with ⟨⟨u, v⟩, sq⟩
      dsimp only at hb1 hb2 hbsq ⊢
      split_ifs with hpos
      · have huv_ne : u ≠ v := by
          intro hEq
          subst hEq
          unfold euclideanDistSq at hbsq
          rw [sub_self, norm_zero, zero_pow two_ne_zero] at hbsq
          linarith
        exact ⟨u, v, rfl, hb1, hb2, huv_ne, hbsq⟩
      · rw [hfb_eq]
        exact ⟨d₁, d₂, rfl, hd₁, hd₂, hd_ne, rfl⟩

end UL.Proof.claim_C_2_space_reclaim
