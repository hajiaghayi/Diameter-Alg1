import UL.Stmt.claim_C_2_space_reclaim
import UL.Proof.lem_C_2.H1
import UL.Proof.claim_C_2_space_reclaim.H1_Reclaim
import UL.Proof.claim_C_2_space_reclaim.H2a_DataStructs

set_option autoImplicit false

namespace UL.Proof.claim_C_2_space_reclaim.RacerP44

open UL
open UL.Proof.lem_C_2.H1
open UL.Proof.claim_C_2_space_reclaim

/-! ### 1. Live-retained handle subsets & coordinate stability -/

open Classical in
theorem init_subset_foldl_union {ι α : Type} (f : α → Finset ι) :
    ∀ (xs : List α) (init : Finset ι),
      init ⊆ xs.foldl (fun acc x => acc ∪ f x) init
  | [], init => Finset.Subset.refl init
  | x :: xs, init =>
      Finset.Subset.trans Finset.subset_union_left (init_subset_foldl_union f xs (init ∪ f x))

open Classical in
theorem mem_subset_foldl_union {ι α : Type} (f : α → Finset ι) :
    ∀ {xs : List α} {x : α} (init : Finset ι),
      x ∈ xs → f x ⊆ xs.foldl (fun acc y => acc ∪ f y) init
  | [], _, _, hmem => by cases hmem
  | y :: ys, x, init, hmem => by
      rcases List.mem_cons.mp hmem with hxy | hys
      · rw [hxy]
        exact Finset.Subset.trans Finset.subset_union_right
          (init_subset_foldl_union f ys (init ∪ f y))
      · exact mem_subset_foldl_union f (init ∪ f y) hys

open Classical in
theorem foldl_union2_subsets {ι α : Type} (f g : α → Finset ι) :
    ∀ (xs : List α) (init : Finset ι),
      init ⊆ xs.foldl (fun acc x => acc ∪ f x ∪ g x) init ∧
      ∀ x ∈ xs,
        f x ⊆ xs.foldl (fun acc y => acc ∪ f y ∪ g y) init ∧
        g x ⊆ xs.foldl (fun acc y => acc ∪ f y ∪ g y) init
  | [], init =>
      ⟨Finset.Subset.refl init, fun _ h => by cases h⟩
  | y :: ys, init => by
      rcases foldl_union2_subsets f g ys (init ∪ f y ∪ g y) with ⟨hinit, hmem⟩
      refine ⟨Finset.Subset.trans
        (Finset.Subset.trans Finset.subset_union_left Finset.subset_union_left) hinit, ?_⟩
      intro x hx
      rcases List.mem_cons.mp hx with rfl | htl
      · exact ⟨Finset.Subset.trans
            (Finset.Subset.trans Finset.subset_union_right Finset.subset_union_left) hinit,
          Finset.Subset.trans Finset.subset_union_right hinit⟩
      · exact hmem x htl

open Classical in
theorem activeSet_subset_liveRetainedIds {d : ℕ} {ι : Type} (st : Alg4State d ι) :
    st.activeSet ⊆ st.liveRetainedIds := by
  unfold Alg4State.liveRetainedIds
  dsimp only
  have h1 := (foldl_union2_subsets
    (fun sn : Alg4ServingNode d ι => sn.birthSnapshot)
    (fun sn : Alg4ServingNode d ι =>
      match sn.ownedJob with
      | none => ∅
      | some job =>
          job.completedPrefix.foldl
            (fun acc lv => acc ∪ lv.birthSnapshot ∪ lv.scan2Snapshot)
            job.currentResidual)
    st.servingNodes st.activeSet).1
  exact Finset.Subset.trans h1
    (init_subset_foldl_union RetiredRecord.referencedIds st.retirementQueue _)

open Classical in
theorem servingNode_subsets_liveRetainedIds {d : ℕ} {ι : Type}
    (st : Alg4State d ι) {sn : Alg4ServingNode d ι} (hsn : sn ∈ st.servingNodes) :
    sn.birthSnapshot ⊆ st.liveRetainedIds ∧
    (∀ job : Alg4PendingJob d ι, sn.ownedJob = some job →
      job.currentResidual ⊆ st.liveRetainedIds ∧
      ∀ lv ∈ job.completedPrefix,
        lv.birthSnapshot ⊆ st.liveRetainedIds ∧ lv.scan2Snapshot ⊆ st.liveRetainedIds) := by
  unfold Alg4State.liveRetainedIds
  dsimp only
  have houter := init_subset_foldl_union RetiredRecord.referencedIds st.retirementQueue
    (st.servingNodes.foldl
      (fun acc s => acc ∪ s.birthSnapshot ∪
        match s.ownedJob with
        | none => ∅
        | some job =>
            job.completedPrefix.foldl
              (fun acc lv => acc ∪ lv.birthSnapshot ∪ lv.scan2Snapshot)
              job.currentResidual)
      st.activeSet)
  have hsn_both := (foldl_union2_subsets
    (fun s : Alg4ServingNode d ι => s.birthSnapshot)
    (fun s : Alg4ServingNode d ι =>
      match s.ownedJob with
      | none => ∅
      | some job =>
          job.completedPrefix.foldl
            (fun acc lv => acc ∪ lv.birthSnapshot ∪ lv.scan2Snapshot)
            job.currentResidual)
    st.servingNodes st.activeSet).2 sn hsn
  refine ⟨Finset.Subset.trans hsn_both.1 houter, ?_⟩
  intro job hjob
  have hfj : (match sn.ownedJob with
      | none => ∅
      | some job =>
          job.completedPrefix.foldl
            (fun acc lv => acc ∪ lv.birthSnapshot ∪ lv.scan2Snapshot)
            job.currentResidual) ⊆ st.liveRetainedIds :=
    Finset.Subset.trans hsn_both.2 houter
  rw [hjob] at hfj
  dsimp only at hfj
  have hpfx := foldl_union2_subsets
    (fun lv : Alg4OpenedLevel d ι => lv.birthSnapshot)
    (fun lv : Alg4OpenedLevel d ι => lv.scan2Snapshot)
    job.completedPrefix job.currentResidual
  refine ⟨Finset.Subset.trans hpfx.1 hfj, ?_⟩
  intro lv hlv
  have hlv_both := hpfx.2 lv hlv
  exact ⟨Finset.Subset.trans hlv_both.1 hfj, Finset.Subset.trans hlv_both.2 hfj⟩

open Classical in
theorem updateAlg4Coords_eq_on_liveRetainedIds {d : ℕ} {ι : Type}
    {n : ℕ} {st : Alg4State d ι} {upd : Alg4PointUpdate d ι}
    (hupd : IsValidAlg4PointUpdate n st upd)
    {x : ι} (hx : x ∈ st.liveRetainedIds) :
    updateAlg4Coords st.coords upd x = st.coords x := by
  apply updateAlg4Coords_eq_of_not_insert
  intro id pt hEq
  subst hEq
  rcases hupd with ⟨hid_not, _⟩
  intro hxeq
  subst hxeq
  exact hid_not hx

open Classical in
theorem validAlg4PointUpdate_activeSet {d : ℕ} {ι : Type}
    {n : ℕ} {st : Alg4State d ι} {upd : Alg4PointUpdate d ι}
    (hupd : IsValidAlg4PointUpdate n st upd) :
    let P' := applyAlg4PointSetUpdate st.activeSet upd
    let rootEv : PoolUpdateEvent ι :=
      match upd with
      | .insert p _ => .externalInsert p
      | .delete p => .externalDelete p
    IsValidPoolUpdateEvent st.activeSet P' rootEv ∧
    (st.activeSet.card ≤ n → P'.card ≤ n) ∧
    (∀ p : ι, upd = .delete p → p ∉ P') := by
  cases upd with
  | insert p pt =>
    rcases hupd with ⟨hp_not_live, hcard_le⟩
    have hp_not_act : p ∉ st.activeSet :=
      fun hp => hp_not_live (activeSet_subset_liveRetainedIds st hp)
    dsimp only [applyAlg4PointSetUpdate, IsValidPoolUpdateEvent]
    refine ⟨⟨hp_not_act, rfl⟩, ?_, ?_⟩
    · intro _
      have hc := Finset.card_insert_le p st.activeSet
      omega
    · intro q hq; cases hq
  | delete p =>
    have hp_act : p ∈ st.activeSet := hupd
    dsimp only [applyAlg4PointSetUpdate, IsValidPoolUpdateEvent]
    refine ⟨⟨hp_act, rfl⟩, ?_, ?_⟩
    · intro hle
      exact le_trans Finset.card_erase_le hle
    · intro q hq
      injection hq with hqp
      subst hqp
      exact Finset.notMem_erase p st.activeSet

/-! ### 2. Pool-update routing across fixed balls & retirement outdegree helpers -/

theorem poolUpdateEvent_ticks_le_one {ι : Type} (ev : PoolUpdateEvent ι) :
    ev.ticks ≤ 1 := by
  unfold PoolUpdateEvent.ticks
  split_ifs <;> omega

open Classical in
theorem hasNodeAge_of_validPoolUpdateEvent {ι : Type}
    {P₀ S S' : Finset ι} {a : ℕ} {ev : PoolUpdateEvent ι}
    (hage : HasNodeAge P₀ S a) (hev : IsValidPoolUpdateEvent S S' ev) :
    HasNodeAge P₀ S' (a + ev.ticks) := by
  cases ev with
  | externalInsert id =>
    rcases hev with ⟨hid_not, rfl⟩
    change HasNodeAge P₀ (insert id S) (a + 1)
    exact hasNodeAge_step hage (Or.inl ⟨id, hid_not, rfl⟩)
  | externalDelete id =>
    rcases hev with ⟨hid_in, rfl⟩
    change HasNodeAge P₀ (S.erase id) (a + 1)
    exact hasNodeAge_step hage (Or.inr ⟨id, hid_in, rfl⟩)
  | virtualValueDelete =>
    subst hev
    simpa [PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick] using hage
  | unaffected =>
    subst hev
    simpa [PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick] using hage

open Classical in
noncomputable def nextRoutedPoolEvent {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (ball : ChainNode d)
    (ev : PoolUpdateEvent ι) : Option (PoolUpdateEvent ι) :=
  match ev with
  | .externalInsert p =>
      if pts p ∈ coreBall ball.o ball.V then none else some (.externalInsert p)
  | .externalDelete p =>
      if pts p ∈ coreBall ball.o ball.V then none else some (.externalDelete p)
  | .virtualValueDelete => none
  | .unaffected => none

open Classical in
theorem residual_validPoolUpdateEvent {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (ball : ChainNode d)
    {S S' : Finset ι} {ev : PoolUpdateEvent ι}
    (hev : IsValidPoolUpdateEvent S S' ev) :
    IsValidPoolUpdateEvent (ball.residual pts S) (ball.residual pts S')
      ((nextRoutedPoolEvent pts ball ev).getD .unaffected) := by
  cases ev with
  | externalInsert p =>
    rcases hev with ⟨hp_not, rfl⟩
    dsimp only [nextRoutedPoolEvent]
    by_cases hc : pts p ∈ coreBall ball.o ball.V
    · rw [if_pos hc]
      dsimp only [Option.getD, IsValidPoolUpdateEvent]
      ext x
      simp only [ChainNode.residual, nodeResidual, nodeCore,
        Finset.mem_sdiff, Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨hmem | hmem, hnot⟩
        · subst hmem
          exact False.elim (hnot ⟨Or.inl rfl, hc⟩)
        · exact ⟨hmem, fun ⟨_, hcx⟩ => hnot ⟨Or.inr hmem, hcx⟩⟩
      · rintro ⟨hmem, hnot⟩
        refine ⟨Or.inr hmem, ?_⟩
        rintro ⟨_, hcx⟩
        exact hnot ⟨hmem, hcx⟩
    · rw [if_neg hc]
      dsimp only [Option.getD, IsValidPoolUpdateEvent]
      refine ⟨fun hpR => hp_not (nodeResidual_subset ball pts S hpR), ?_⟩
      ext x
      simp only [ChainNode.residual, nodeResidual, nodeCore,
        Finset.mem_sdiff, Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨hmem | hmem, hnot⟩
        · exact Or.inl hmem
        · exact Or.inr ⟨hmem, fun ⟨_, hcx⟩ => hnot ⟨Or.inr hmem, hcx⟩⟩
      · rintro (rfl | ⟨hmem, hnot⟩)
        · exact ⟨Or.inl rfl, fun ⟨_, hcp⟩ => hc hcp⟩
        · refine ⟨Or.inr hmem, ?_⟩
          rintro ⟨_, hcx⟩
          exact hnot ⟨hmem, hcx⟩
  | externalDelete p =>
    rcases hev with ⟨hp_in, rfl⟩
    dsimp only [nextRoutedPoolEvent]
    by_cases hc : pts p ∈ coreBall ball.o ball.V
    · rw [if_pos hc]
      dsimp only [Option.getD, IsValidPoolUpdateEvent]
      ext x
      simp only [ChainNode.residual, nodeResidual, nodeCore,
        Finset.mem_sdiff, Finset.mem_filter, Finset.mem_erase]
      constructor
      · rintro ⟨⟨hne, hmem⟩, hnot⟩
        exact ⟨hmem, fun ⟨_, hcx⟩ => hnot ⟨⟨hne, hmem⟩, hcx⟩⟩
      · rintro ⟨hmem, hnot⟩
        have hne : x ≠ p := by
          rintro rfl
          exact hnot ⟨hmem, hc⟩
        exact ⟨⟨hne, hmem⟩, fun ⟨_, hcx⟩ => hnot ⟨hmem, hcx⟩⟩
    · rw [if_neg hc]
      dsimp only [Option.getD, IsValidPoolUpdateEvent]
      have hp_res : p ∈ ball.residual pts S := by
        simp only [ChainNode.residual, nodeResidual, nodeCore, Finset.mem_sdiff, Finset.mem_filter]
        exact ⟨hp_in, fun ⟨_, hcp⟩ => hc hcp⟩
      refine ⟨hp_res, ?_⟩
      ext x
      simp only [ChainNode.residual, nodeResidual, nodeCore,
        Finset.mem_sdiff, Finset.mem_filter, Finset.mem_erase]
      constructor
      · rintro ⟨⟨hne, hmem⟩, hnot⟩
        exact ⟨hne, hmem, fun ⟨_, hcx⟩ => hnot ⟨⟨hne, hmem⟩, hcx⟩⟩
      · rintro ⟨hne, hmem, hnot⟩
        exact ⟨⟨hne, hmem⟩, fun ⟨_, hcx⟩ => hnot ⟨hmem, hcx⟩⟩
  | virtualValueDelete =>
    subst hev
    simp [nextRoutedPoolEvent, IsValidPoolUpdateEvent]
  | unaffected =>
    subst hev
    simp [nextRoutedPoolEvent, IsValidPoolUpdateEvent]

theorem retireServingNodeRecords_bounded {d : ℕ} {ι : Type}
    {D_out : ℕ} (hD : 1 ≤ D_out) (sn : Alg4ServingNode d ι) :
    ∀ r ∈ retireServingNodeRecords sn, r.HasBoundedOutdegree D_out := by
  intro r hr
  unfold retireServingNodeRecords at hr
  dsimp only at hr
  rcases List.mem_cons.mp hr with rfl | hjob
  · exact ⟨Nat.zero_le D_out, trivial⟩
  · cases hown : sn.ownedJob with
    | none => rw [hown] at hjob; cases hjob
    | some job =>
      rw [hown] at hjob
      rcases List.mem_cons.mp hjob with rfl | hpfx
      · exact ⟨Nat.zero_le D_out, trivial⟩
      · rcases List.mem_map.mp hpfx with ⟨lv, _, rfl⟩
        exact ⟨hD, ⟨Nat.zero_le D_out, trivial⟩, trivial⟩

/-! ### 3. Center selection, Line 3 prefix routing, Line 4 scans, and Line 5 gate -/

open Classical in
theorem chooseBirthPointIn_mem {ι : Type}
    (S_birth : Finset ι) (hNE : S_birth.Nonempty) (hint : Option ι) :
    chooseBirthPointIn S_birth hNE hint ∈ S_birth := by
  unfold chooseBirthPointIn
  cases hint with
  | none => exact hNE.choose_spec
  | some b =>
    dsimp only
    by_cases hb : b ∈ S_birth
    · rw [if_pos hb]; exact hb
    · rw [if_neg hb]; exact hNE.choose_spec

open Classical in
theorem selectOpenedLevelBall_passes {d : ℕ} {ι : Type}
    {α : ℝ} (hα_le : α ≤ 1)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (S_birth : Finset ι) {bId : ι} (hb : bId ∈ S_birth)
    (res : SampledCenterResult d) :
    PassesBirthCoreCheck α pts (selectOpenedLevelBall α pts S_birth bId res) S_birth := by
  apply applyBirthCoreFallback_passes hα_le pts S_birth res
  refine ⟨provisionalCenter pts bId res, ?_, rfl⟩
  unfold provisionalCenter IsProvisionalCenter
  cases res with
  | infeasible =>
    exact ⟨bId, hb, rfl⟩
  | candidate o V =>
    dsimp only
    by_cases hV : 0 ≤ V
    · simp [hV]
    · refine ?_
      rw [dif_neg hV]
      exact ⟨bId, hb, by simp [hV]⟩

open Classical in
theorem alg4OpenedLevel_wellFormed_congr {d : ℕ} {ι : Type}
    {mode : Alg4Mode} {α : ℝ} {L : ℕ}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    {lv : Alg4OpenedLevel d ι} {S_lv : Finset ι}
    (hwf : lv.WellFormed mode α L pts₁ S_lv)
    (hpts_S : ∀ x ∈ S_lv, pts₂ x = pts₁ x)
    (hpts_B : ∀ x ∈ lv.birthSnapshot, pts₂ x = pts₁ x) :
    lv.WellFormed mode α L pts₂ S_lv := by
  rcases hwf with ⟨hmode, hlarge, hcore, hage_le, hage, hheap_sub, hcls_sub, hdict, hlm, hrdy⟩
  have hpts_B' : ∀ x ∈ lv.birthSnapshot, pts₁ x = pts₂ x := fun x hx => (hpts_B x hx).symm
  have hpts_H : ∀ x ∈ lv.heapIndexedIds, pts₁ x = pts₂ x :=
    fun x hx => (hpts_S x (hheap_sub hx)).symm
  have hpts_C : ∀ x ∈ lv.classifiedIds, pts₁ x = pts₂ x :=
    fun x hx => (hpts_S x (hcls_sub hx)).symm
  exact ⟨hmode, hlarge,
    (passesBirthCoreCheck_congr α lv.ball hpts_B').mp hcore,
    hage_le, hage, hheap_sub, hcls_sub,
    (radiusDict_wellFormedOn_congr lv.ball.o lv.radiusDict hpts_H).mp hdict,
    (validNodeMatchingsOn_congr mode lv.ball lv.localMatchings hpts_C).mp hlm,
    hrdy⟩

def PendingJobDataWF {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_root : Finset ι)
    (job : Alg4PendingJob d ι) : Prop :=
  job.currentResidual =
    prefixResidual pts (job.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_root ∧
  (∀ j : Fin job.completedPrefix.length,
    (job.completedPrefix[j]).WellFormed mode α L pts
      (alg4PrefixInputAt pts job.completedPrefix S_root j.val)) ∧
  (if job.closedAsLeaf then
    IsExactLeafAnswer pts job.currentResidual job.closedLeafAnswer ∧
    job.closedLeafDistSq = (baselinePairLength pts job.closedLeafAnswer) ^ 2
  else
    job.closedLeafAnswer = none ∧ job.closedLeafDistSq = 0)

theorem pendingJobDataWF_of_wellFormed {d : ℕ} {ι : Type}
    {mode : Alg4Mode} {α : ℝ} {L : ℕ}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {S_root : Finset ι}
    {job : Alg4PendingJob d ι}
    (hwf : job.WellFormed mode α L pts S_root) :
    PendingJobDataWF mode α L pts S_root job :=
  ⟨hwf.1.2.1, fun j => (hwf.2.1 j).2, hwf.2.2⟩

open Classical in
theorem pendingJobDataWF_congr {d : ℕ} {ι : Type}
    {mode : Alg4Mode} {α : ℝ} {L : ℕ}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    {S_root : Finset ι} {job : Alg4PendingJob d ι}
    (hdwf : PendingJobDataWF mode α L pts₁ S_root job)
    (hpts_S : ∀ x ∈ S_root, pts₂ x = pts₁ x)
    (hpts_B : ∀ lv ∈ job.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts₂ x = pts₁ x) :
    PendingJobDataWF mode α L pts₂ S_root job := by
  rcases hdwf with ⟨hres, hpfx, hleaf⟩
  have hpts_S' : ∀ x ∈ S_root, pts₁ x = pts₂ x := fun x hx => (hpts_S x hx).symm
  have hres2 : job.currentResidual =
      prefixResidual pts₂ (job.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_root := by
    rw [hres]
    exact prefixResidual_congr _ hpts_S'
  refine ⟨hres2, ?_, ?_⟩
  · intro j
    have heq_in : alg4PrefixInputAt pts₁ job.completedPrefix S_root j.val =
        alg4PrefixInputAt pts₂ job.completedPrefix S_root j.val :=
      alg4PrefixInputAt_congr job.completedPrefix j.val hpts_S'
    have hsub : alg4PrefixInputAt pts₂ job.completedPrefix S_root j.val ⊆ S_root :=
      alg4PrefixInputAt_subset pts₂ job.completedPrefix S_root j.val
    have hwf1 := hpfx j
    rw [heq_in] at hwf1
    exact alg4OpenedLevel_wellFormed_congr hwf1
      (fun x hx => hpts_S x (hsub hx))
      (hpts_B (job.completedPrefix[j]) (List.getElem_mem _))
  · by_cases hcl : job.closedAsLeaf = true
    · rw [if_pos hcl] at hleaf ⊢
      have hsub_res : job.currentResidual ⊆ S_root := by
        rw [hres2]
        exact prefixResidual_subset pts₂ _ S_root
      have hpts_res : ∀ x ∈ job.currentResidual, pts₁ x = pts₂ x :=
        fun x hx => (hpts_S x (hsub_res hx)).symm
      have hex2 : IsExactLeafAnswer pts₂ job.currentResidual job.closedLeafAnswer :=
        (isExactLeafAnswer_congr job.closedLeafAnswer hpts_res).mp hleaf.1
      have hlen_eq : baselinePairLength pts₁ job.closedLeafAnswer =
          baselinePairLength pts₂ job.closedLeafAnswer :=
        baselinePairLength_congr_exact hleaf.1 hpts_res
      exact ⟨hex2, hleaf.2.trans (by rw [hlen_eq])⟩
    · rw [if_neg hcl] at hleaf ⊢
      exact hleaf

open Classical in
theorem alg4PrefixInputAt_zero {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (pref : List (Alg4OpenedLevel d ι)) (S_root : Finset ι) :
    alg4PrefixInputAt pts pref S_root 0 = S_root := by
  simp [alg4PrefixInputAt]

open Classical in
theorem alg4PrefixInputAt_cons_succ {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (lv : Alg4OpenedLevel d ι) (rest : List (Alg4OpenedLevel d ι))
    (S_root : Finset ι) (j : ℕ) :
    alg4PrefixInputAt pts (lv :: rest) S_root (j + 1) =
      alg4PrefixInputAt pts rest (lv.ball.residual pts S_root) j := by
  simp [alg4PrefixInputAt]

open Classical in
theorem alg4Line3RoutePrefixAux_spec {d : ℕ} {ι : Type}
    (pts₀ pts' : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ) :
    ∀ (pref : List (Alg4OpenedLevel d ι))
      (S S' : Finset ι) (activeEv : Option (PoolUpdateEvent ι))
      (qList : List (NodeMatchingQueryAnswers ι)) (mHints : List (Option ι)),
      (∀ x ∈ S, pts' x = pts₀ x) →
      (∀ lv ∈ pref, ∀ x ∈ lv.birthSnapshot, pts' x = pts₀ x) →
      IsValidPoolUpdateEvent S S' (activeEv.getD .unaffected) →
      (∀ j : Fin pref.length,
        (pref[j]).WellFormed mode α L pts₀ (alg4PrefixInputAt pts₀ pref S j.val)) →
      let (pref', resEv) := alg4Line3RoutePrefixAux pts' mode activeEv pref qList mHints
      ∃ hLen : pref'.length = pref.length,
        IsValidPoolUpdateEvent
          (prefixResidual pts₀ (pref.map Alg4OpenedLevel.toOpenedJobLevel) S)
          (prefixResidual pts' (pref'.map Alg4OpenedLevel.toOpenedJobLevel) S')
          resEv ∧
        ∀ j : Fin pref.length,
          let lv := pref[j]
          let lv₁ := pref'[j.val]' (by omega)
          let S_lv := alg4PrefixInputAt pts₀ pref S j.val
          let S_lv' := alg4PrefixInputAt pts' pref' S' j.val
          lv₁.birthSnapshot = lv.birthSnapshot ∧
          lv₁.scan2Snapshot = lv.scan2Snapshot ∧
          lv₁.ball = lv.ball ∧
          lv₁.indexMode = lv.indexMode ∧
          lv₁.backgroundReady = lv.backgroundReady ∧
          lv₁.elapsedRootTicks = lv.elapsedRootTicks ∧
          lv₁.heapIndexedIds = lv₁.radiusDict.indexedIds ∧
          (∃ ev_j : PoolUpdateEvent ι,
            IsValidPoolUpdateEvent S_lv S_lv' ev_j ∧
            ev_j.ticks ≤ 1 ∧
            lv₁.trueInputAge = lv.trueInputAge + ev_j.ticks ∧
            HasNodeAge lv₁.birthSnapshot S_lv' lv₁.trueInputAge ∧
            lv₁.radiusDict.IsScanValid pts' lv.ball.o S_lv' ∧
            lv₁.classifiedIds ⊆ S_lv' ∧
            ValidNodeMatchingsOn pts' mode lv.ball lv₁.classifiedIds lv₁.localMatchings ∧
            (lv₁.backgroundReady = true →
              lv₁.heapIndexedIds = S_lv' ∧ lv₁.classifiedIds = S_lv') ∧
            S_lv' \ lv₁.radiusDict.indexedIds ⊆ S_lv \ lv.radiusDict.indexedIds ∧
            S_lv' \ lv₁.classifiedIds ⊆ S_lv \ lv.classifiedIds)
  | [], S, S', activeEv, qList, mHints, _, _, hev, _ => by
      refine ⟨rfl, ?_, fun j => Fin.elim0 j⟩
      simpa [alg4Line3RoutePrefixAux, prefixResidual] using hev
  | lv :: rest, S, S', activeEv, qList, mHints, hpts_S, hpts_B, hev, hpfx => by
      set ev := activeEv.getD .unaffected
      set qAns := qList.head?.getD (NodeMatchingQueryAnswers.empty ι)
      set mHint := mHints.head?.join
      have hwf0_0 : lv.WellFormed mode α L pts₀ S := by
        simpa [alg4PrefixInputAt_zero] using hpfx ⟨0, Nat.zero_lt_succ _⟩
      have hwf0 : lv.WellFormed mode α L pts' S :=
        alg4OpenedLevel_wellFormed_congr hwf0_0 hpts_S (hpts_B lv List.mem_cons_self)
      rcases hwf0 with ⟨hmode, hlarge, hcore, hage_le, hage, hheap_sub, hcls_sub, hdict, hlm, hrdy⟩
      have hdict_id : lv.radiusDict.indexedIds = lv.heapIndexedIds := hdict.1
      let stepLv (e : PoolUpdateEvent ι) : Alg4OpenedLevel d ι :=
        match e with
        | .externalInsert p =>
            let rDict' := updateRadiusDictOnEvent pts' lv.ball.o lv.radiusDict e mHint
            let cls' := insert p lv.classifiedIds
            let lm' := applyNodeMatchingInsert pts' mode lv.ball lv.localMatchings p qAns
            { lv with
              trueInputAge := lv.trueInputAge + 1
              heapIndexedIds := rDict'.indexedIds
              classifiedIds := cls'
              radiusDict := rDict'
              localMatchings := lm' }
        | .externalDelete p =>
            let rDict' := updateRadiusDictOnEvent pts' lv.ball.o lv.radiusDict e mHint
            let cls' := lv.classifiedIds.erase p
            let lm' :=
              if p ∈ lv.classifiedIds then
                applyNodeMatchingDelete pts' mode lv.ball lv.localMatchings p qAns
              else
                lv.localMatchings
            { lv with
              trueInputAge := lv.trueInputAge + 1
              heapIndexedIds := rDict'.indexedIds
              classifiedIds := cls'
              radiusDict := rDict'
              localMatchings := lm' }
        | .virtualValueDelete => lv
        | .unaffected => lv
      have hlv'_gen : ∀ (e : PoolUpdateEvent ι),
          IsValidPoolUpdateEvent S S' e →
          (stepLv e).birthSnapshot = lv.birthSnapshot ∧
          (stepLv e).scan2Snapshot = lv.scan2Snapshot ∧
          (stepLv e).ball = lv.ball ∧
          (stepLv e).indexMode = lv.indexMode ∧
          (stepLv e).backgroundReady = lv.backgroundReady ∧
          (stepLv e).elapsedRootTicks = lv.elapsedRootTicks ∧
          (stepLv e).heapIndexedIds = (stepLv e).radiusDict.indexedIds ∧
          (stepLv e).trueInputAge = lv.trueInputAge + e.ticks ∧
          HasNodeAge (stepLv e).birthSnapshot S' (stepLv e).trueInputAge ∧
          (stepLv e).radiusDict.IsScanValid pts' lv.ball.o S' ∧
          (stepLv e).classifiedIds ⊆ S' ∧
          ValidNodeMatchingsOn pts' mode lv.ball (stepLv e).classifiedIds (stepLv e).localMatchings ∧
          ((stepLv e).backgroundReady = true →
            (stepLv e).heapIndexedIds = S' ∧ (stepLv e).classifiedIds = S') ∧
          S' \ (stepLv e).radiusDict.indexedIds ⊆ S \ lv.radiusDict.indexedIds ∧
          S' \ (stepLv e).classifiedIds ⊆ S \ lv.classifiedIds := by
        intro e hev_e
        cases e with
        | externalInsert p =>
          rcases hev_e with ⟨hp_not_S, rfl⟩
          have hp_not_cls : p ∉ lv.classifiedIds := fun hp => hp_not_S (hcls_sub hp)
          dsimp only [stepLv, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick, ↓reduceIte]
          have hrd : (updateRadiusDictOnEvent pts' lv.ball.o lv.radiusDict
              (.externalInsert p) mHint).WellFormedOn pts' lv.ball.o (insert p lv.heapIndexedIds) :=
            updateRadiusDictOnEvent_wellFormed_insert pts' lv.ball.o hdict p mHint
          have hrd_id : (updateRadiusDictOnEvent pts' lv.ball.o lv.radiusDict
              (.externalInsert p) mHint).indexedIds = insert p lv.heapIndexedIds := hrd.1
          have hsub_rd : insert p lv.heapIndexedIds ⊆ insert p S :=
            Finset.insert_subset_insert p hheap_sub
          have hsub_cls : insert p lv.classifiedIds ⊆ insert p S :=
            Finset.insert_subset_insert p hcls_sub
          have hlm' := applyNodeMatchingInsert_valid pts' mode lv.ball hp_not_cls qAns hlm
          have hage' : HasNodeAge lv.birthSnapshot (insert p S) (lv.trueInputAge + 1) :=
            hasNodeAge_step hage (Or.inl ⟨p, hp_not_S, rfl⟩)
          refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl,
            hage', ⟨hrd_id ▸ hsub_rd, hrd_id ▸ hrd⟩,
            hsub_cls, hlm', ?_, ?_, ?_⟩
          · intro hb
            rcases hrdy hb with ⟨hH_eq, hC_eq⟩
            exact ⟨by rw [hrd_id, hH_eq], by rw [hC_eq]⟩
          · rw [hrd_id, hdict_id]
            intro x hx
            simp only [Finset.mem_sdiff, Finset.mem_insert] at hx ⊢
            exact ⟨hx.1.resolve_left (fun hxp => hx.2 (Or.inl hxp)),
              fun hxH => hx.2 (Or.inr hxH)⟩
          · intro x hx
            simp only [Finset.mem_sdiff, Finset.mem_insert] at hx ⊢
            exact ⟨hx.1.resolve_left (fun hxp => hx.2 (Or.inl hxp)),
              fun hxC => hx.2 (Or.inr hxC)⟩
        | externalDelete p =>
          rcases hev_e with ⟨hp_in_S, rfl⟩
          dsimp only [stepLv, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick, ↓reduceIte]
          have hrd : (updateRadiusDictOnEvent pts' lv.ball.o lv.radiusDict
              (.externalDelete p) mHint).WellFormedOn pts' lv.ball.o (lv.heapIndexedIds.erase p) :=
            updateRadiusDictOnEvent_wellFormed_delete pts' lv.ball.o hdict p mHint
          have hrd_id : (updateRadiusDictOnEvent pts' lv.ball.o lv.radiusDict
              (.externalDelete p) mHint).indexedIds = lv.heapIndexedIds.erase p := hrd.1
          have hsub_rd : lv.heapIndexedIds.erase p ⊆ S.erase p :=
            Finset.erase_subset_erase p hheap_sub
          have hsub_cls : lv.classifiedIds.erase p ⊆ S.erase p :=
            Finset.erase_subset_erase p hcls_sub
          have hlm' : ValidNodeMatchingsOn pts' mode lv.ball (lv.classifiedIds.erase p)
              (if p ∈ lv.classifiedIds then
                applyNodeMatchingDelete pts' mode lv.ball lv.localMatchings p qAns
              else lv.localMatchings) := by
            by_cases hpC : p ∈ lv.classifiedIds
            · rw [if_pos hpC]
              exact applyNodeMatchingDelete_valid pts' mode lv.ball p qAns hlm
            · rw [if_neg hpC, Finset.erase_eq_of_notMem hpC]
              exact hlm
          have hage' : HasNodeAge lv.birthSnapshot (S.erase p) (lv.trueInputAge + 1) :=
            hasNodeAge_step hage (Or.inr ⟨p, hp_in_S, rfl⟩)
          refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl,
            hage', ⟨hrd_id ▸ hsub_rd, hrd_id ▸ hrd⟩,
            hsub_cls, hlm', ?_, ?_, ?_⟩
          · intro hb
            rcases hrdy hb with ⟨hH_eq, hC_eq⟩
            exact ⟨by rw [hrd_id, hH_eq], by rw [hC_eq]⟩
          · rw [hrd_id, hdict_id]
            intro x hx
            simp only [Finset.mem_sdiff, Finset.mem_erase] at hx ⊢
            exact ⟨hx.1.2, fun hxH => hx.2 ⟨hx.1.1, hxH⟩⟩
          · intro x hx
            simp only [Finset.mem_sdiff, Finset.mem_erase] at hx ⊢
            exact ⟨hx.1.2, fun hxC => hx.2 ⟨hx.1.1, hxC⟩⟩
        | virtualValueDelete =>
          subst hev_e
          dsimp only [stepLv, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick, Bool.false_eq_true, ↓reduceIte]
          refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, hdict_id.symm, (Nat.add_zero _).symm, hage,
            ⟨hdict_id ▸ hheap_sub, hdict_id ▸ hdict⟩,
            hcls_sub, hlm, hrdy, Finset.Subset.refl _, Finset.Subset.refl _⟩
        | unaffected =>
          subst hev_e
          dsimp only [stepLv, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick, Bool.false_eq_true, ↓reduceIte]
          refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, hdict_id.symm, (Nat.add_zero _).symm, hage,
            ⟨hdict_id ▸ hheap_sub, hdict_id ▸ hdict⟩,
            hcls_sub, hlm, hrdy, Finset.Subset.refl _, Finset.Subset.refl _⟩
      set lv' : Alg4OpenedLevel d ι := stepLv ev
      have hlv'_head := hlv'_gen ev hev
      have hres_congr : lv.ball.residual pts₀ S = lv.ball.residual pts' S :=
        nodeResidual_congr lv.ball (fun x hx => (hpts_S x hx).symm)
      let nextEv := nextRoutedPoolEvent pts' lv.ball ev
      have hev_next : IsValidPoolUpdateEvent (lv.ball.residual pts₀ S) (lv.ball.residual pts' S')
          (nextEv.getD .unaffected) := by
        rw [hres_congr]
        exact residual_validPoolUpdateEvent pts' lv.ball hev
      have hpts_R : ∀ x ∈ lv.ball.residual pts₀ S, pts' x = pts₀ x :=
        fun x hx => hpts_S x (nodeResidual_subset lv.ball pts₀ S hx)
      have hpts_B_rest : ∀ l ∈ rest, ∀ x ∈ l.birthSnapshot, pts' x = pts₀ x :=
        fun l hl => hpts_B l (List.mem_cons_of_mem lv hl)
      have hpfx_rest : ∀ j : Fin rest.length,
          (rest[j]).WellFormed mode α L pts₀
            (alg4PrefixInputAt pts₀ rest (lv.ball.residual pts₀ S) j.val) := by
        intro j
        simpa [alg4PrefixInputAt_cons_succ] using hpfx ⟨j.val + 1, Nat.succ_lt_succ j.isLt⟩
      have hroute_unfold :
          alg4Line3RoutePrefixAux pts' mode activeEv (lv :: rest) qList mHints =
            (lv' :: (alg4Line3RoutePrefixAux pts' mode nextEv rest (qList.drop 1) (mHints.drop 1)).1,
             (alg4Line3RoutePrefixAux pts' mode nextEv rest (qList.drop 1) (mHints.drop 1)).2) := by
        conv_lhs => unfold alg4Line3RoutePrefixAux
        dsimp only [ev, qAns, mHint, lv', stepLv, nextEv, nextRoutedPoolEvent]
        generalize activeEv.getD .unaffected = e0
        cases e0 <;> rfl
      rcases hrec_route : alg4Line3RoutePrefixAux pts' mode nextEv rest (qList.drop 1) (mHints.drop 1)
        with ⟨rest', resEv⟩
      have hspec_rest := alg4Line3RoutePrefixAux_spec pts₀ pts' mode α L rest
        (lv.ball.residual pts₀ S) (lv.ball.residual pts' S') nextEv
        (qList.drop 1) (mHints.drop 1) hpts_R hpts_B_rest hev_next hpfx_rest
      rw [hrec_route] at hspec_rest hroute_unfold
      rcases hspec_rest with ⟨hLen_rest, hres_ev, hrest_j⟩
      change (let p := alg4Line3RoutePrefixAux pts' mode activeEv (lv :: rest) qList mHints; _)
      rw [hroute_unfold]
      dsimp only
      have hball_eq : lv'.ball = lv.ball := hlv'_head.2.2.1
      refine ⟨by simp [hLen_rest], ?_, ?_⟩
      · simpa [prefixResidual, Alg4OpenedLevel.toOpenedJobLevel, hball_eq] using hres_ev
      · intro j
        rcases j with ⟨_ | j, hj⟩
        · dsimp only [List.getElem_cons_zero]
          rw [alg4PrefixInputAt_zero, alg4PrefixInputAt_zero]
          rcases hlv'_head with ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9, h10, h11, h12, h13, h14, h15⟩
          exact ⟨h1, h2, h3, h4, h5, h6, h7,
            ⟨ev, hev, poolUpdateEvent_ticks_le_one ev, h8, h9, h10, h11, h12, h13, h14, h15⟩⟩
        · have hj' : j < rest.length := Nat.lt_of_succ_lt_succ hj
          dsimp only [List.getElem_cons_succ]
          rw [alg4PrefixInputAt_cons_succ, alg4PrefixInputAt_cons_succ, hball_eq]
          exact hrest_j ⟨j, hj'⟩

/-! ### 4. Combined Lines 3 + 4 (`stepPrefixConstruction`) and Line 5 (`alg4Line5LateOpeningGate`) -/

open Classical in
theorem stepPrefixConstruction_length {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    ∀ (pref₁ : List (Alg4OpenedLevel d ι)) (S' : Finset ι)
      (bSteps : List (PendingLevelBudgetChoices ι)),
      (stepPrefixConstruction pts' mode S' pref₁ bSteps).length = pref₁.length
  | [], _, _ => rfl
  | lv :: rest, S', bSteps => by
      dsimp only [stepPrefixConstruction, List.length_cons]
      rw [stepPrefixConstruction_length pts' mode rest (lv.ball.residual pts' S') (bSteps.drop 1)]

open Classical in
theorem stepPrefixConstruction_spec {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ) :
    ∀ (pref₁ : List (Alg4OpenedLevel d ι)) (S' : Finset ι)
      (bSteps : List (PendingLevelBudgetChoices ι)),
      (∀ j : Fin pref₁.length,
        let lv₁ := pref₁[j]
        let S_lv' := alg4PrefixInputAt pts' pref₁ S' j.val
        lv₁.indexMode = mode.backgroundIndexMode ∧
        IsLargeResidualLevel L lv₁.birthSnapshot.card ∧
        PassesBirthCoreCheck α pts' lv₁.ball lv₁.birthSnapshot ∧
        lv₁.trueInputAge ≤ lv₁.elapsedRootTicks + 1 ∧
        HasNodeAge lv₁.birthSnapshot S_lv' lv₁.trueInputAge ∧
        lv₁.heapIndexedIds = lv₁.radiusDict.indexedIds ∧
        lv₁.radiusDict.IsScanValid pts' lv₁.ball.o S_lv' ∧
        lv₁.classifiedIds ⊆ S_lv' ∧
        ValidNodeMatchingsOn pts' mode lv₁.ball lv₁.classifiedIds lv₁.localMatchings ∧
        (lv₁.backgroundReady = true →
          lv₁.heapIndexedIds = S_lv' ∧ lv₁.classifiedIds = S_lv')) →
      let pref₂ := stepPrefixConstruction pts' mode S' pref₁ bSteps
      pref₂.map (fun lv => lv.ball) = pref₁.map (fun lv => lv.ball) ∧
      ∀ j : Fin pref₁.length,
        let lv₁ := pref₁[j]
        let lv₂ := pref₂[j.val]'(by rw [stepPrefixConstruction_length]; exact j.isLt)
        let S_lv' := alg4PrefixInputAt pts' pref₂ S' j.val
        let bChoice := (bSteps.drop j.val).head?.getD
          { scan1Batch := ∅, scan2Steps := [], scanMaxHint := none, backgroundIndexesReady := false }
        S_lv' = alg4PrefixInputAt pts' pref₁ S' j.val ∧
        lv₂.birthSnapshot = lv₁.birthSnapshot ∧
        lv₂.scan2Snapshot = lv₁.scan2Snapshot ∧
        lv₂.ball = lv₁.ball ∧
        lv₂.elapsedRootTicks = lv₁.elapsedRootTicks + 1 ∧
        lv₂.trueInputAge = lv₁.trueInputAge ∧
        (lv₁.backgroundReady = true → lv₂.backgroundReady = true) ∧
        lv₂.WellFormed mode α L pts' S_lv' ∧
        (lv₁.backgroundReady = false →
          S_lv' \ lv₂.heapIndexedIds =
            (S_lv' \ lv₁.heapIndexedIds) \ (bChoice.scan1Batch ∩ lv₁.birthSnapshot) ∧
          S_lv' \ lv₂.classifiedIds =
            (S_lv' \ lv₁.classifiedIds) \
              ((bChoice.scan2Steps.map Prod.fst).toFinset ∩ lv₁.scan2Snapshot) ∧
          (S_lv' \ lv₂.heapIndexedIds = ∅ →
            S_lv' \ lv₂.classifiedIds = ∅ →
            bChoice.backgroundIndexesReady = true →
            lv₂.backgroundReady = true))
  | [], S', bSteps, _ =>
      ⟨rfl, fun j => Fin.elim0 j⟩
  | lv₁ :: rest, S', bSteps, hinv => by
      dsimp only [stepPrefixConstruction]
      have h0 := hinv ⟨0, Nat.zero_lt_succ _⟩
      rw [Fin.getElem_fin, alg4PrefixInputAt_zero] at h0
      dsimp only [List.getElem_cons_zero] at h0
      rcases h0 with ⟨hmode, hlarge, hcore, hage_le, hage, hhid, hscan1, hcls_sub, hlm, hrdy⟩
      set bChoice := bSteps.head?.getD
        { scan1Batch := ∅, scan2Steps := [], scanMaxHint := none, backgroundIndexesReady := false }
      have hrest_inv : ∀ j : Fin rest.length,
          let lv := rest[j]
          let S_lv := alg4PrefixInputAt pts' rest (lv₁.ball.residual pts' S') j.val
          lv.indexMode = mode.backgroundIndexMode ∧
          IsLargeResidualLevel L lv.birthSnapshot.card ∧
          PassesBirthCoreCheck α pts' lv.ball lv.birthSnapshot ∧
          lv.trueInputAge ≤ lv.elapsedRootTicks + 1 ∧
          HasNodeAge lv.birthSnapshot S_lv lv.trueInputAge ∧
          lv.heapIndexedIds = lv.radiusDict.indexedIds ∧
          lv.radiusDict.IsScanValid pts' lv.ball.o S_lv ∧
          lv.classifiedIds ⊆ S_lv ∧
          ValidNodeMatchingsOn pts' mode lv.ball lv.classifiedIds lv.localMatchings ∧
          (lv.backgroundReady = true → lv.heapIndexedIds = S_lv ∧ lv.classifiedIds = S_lv) := by
        intro j
        simpa [alg4PrefixInputAt_cons_succ] using hinv ⟨j.val + 1, Nat.succ_lt_succ j.isLt⟩
      rcases stepPrefixConstruction_spec pts' mode α L rest (lv₁.ball.residual pts' S')
          (bSteps.drop 1) hrest_inv with ⟨hballs_rest, hrest_j⟩
      refine ⟨?_, ?_⟩
      · dsimp only [List.map_cons]
        by_cases hr : lv₁.backgroundReady = true <;> simp only [hr, ↓reduceIte, Bool.false_eq_true] <;>
          exact congrArg (lv₁.ball :: ·) hballs_rest
      · intro j
        rcases j with ⟨_ | j, hj⟩
        · rw [Fin.getElem_fin]
          dsimp only [List.getElem_cons_zero, List.drop_zero]
          rw [alg4PrefixInputAt_zero, alg4PrefixInputAt_zero]
          by_cases hr : lv₁.backgroundReady = true
          · rw [if_pos hr]
            dsimp only
            refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, fun _ => hr, ?_, fun hf => absurd hr (by simp [hf])⟩
            exact ⟨hmode, hlarge, hcore, hage_le, hage,
              hhid ▸ hscan1.1, hcls_sub, hhid ▸ hscan1.2, hlm, hrdy⟩
          · have hrf : lv₁.backgroundReady = false := Bool.eq_false_iff.mpr hr
            rw [if_neg hr]
            dsimp only
            have hs1 := scan1RadiusDictBatch_wellFormed pts' lv₁.ball.o
              (hhid ▸ hscan1.2) (hhid ▸ hscan1.1)
              (bChoice.scan1Batch ∩ lv₁.birthSnapshot) bChoice.scanMaxHint
            have hs2 := applyScan2Batch_valid pts' mode lv₁.ball S' lv₁.scan2Snapshot
              lv₁.classifiedIds lv₁.localMatchings bChoice.scan2Steps hcls_sub hlm
            refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, fun ht => absurd ht hr, ?_, ?_⟩
            · refine ⟨hmode, hlarge, hcore, hage_le, hage, hs1.2.1, hs2.1, hs1.2.2.1, hs2.2.1, ?_⟩
              intro hb2
              simp only [Bool.and_eq_true, decide_eq_true_eq] at hb2
              exact ⟨Finset.Subset.antisymm hs1.2.1 hb2.1.1, Finset.Subset.antisymm hs2.1 hb2.1.2⟩
            · intro _
              dsimp only [bChoice] at hs1 hs2 ⊢
              refine ⟨hs1.2.2.2, hs2.2.2, ?_⟩
              intro he1 he2 hbi
              have hsub1 := Finset.sdiff_eq_empty_iff_subset.mp he1
              have hsub2 := Finset.sdiff_eq_empty_iff_subset.mp he2
              simp [hsub1, hsub2, hbi]
        · have hj' : j < rest.length := Nat.lt_of_succ_lt_succ hj
          rw [Fin.getElem_fin]
          dsimp only [List.getElem_cons_succ]
          have hdrop : bSteps.drop (j + 1) = (bSteps.drop 1).drop j := by
            rw [Nat.add_comm j 1, ← List.drop_drop]
          have hhd_ball : (if lv₁.backgroundReady = true then
              { lv₁ with elapsedRootTicks := lv₁.elapsedRootTicks + 1 }
            else
              let rDict' := scan1RadiusDictBatch pts' lv₁.ball.o S' lv₁.radiusDict
                (bChoice.scan1Batch ∩ lv₁.birthSnapshot) bChoice.scanMaxHint
              let p := applyScan2Batch pts' mode lv₁.ball S' lv₁.scan2Snapshot
                lv₁.classifiedIds lv₁.localMatchings bChoice.scan2Steps
              { lv₁ with
                elapsedRootTicks := lv₁.elapsedRootTicks + 1
                heapIndexedIds := rDict'.indexedIds
                classifiedIds := p.1
                radiusDict := rDict'
                localMatchings := p.2
                backgroundReady :=
                  (decide (S' ⊆ rDict'.indexedIds) && decide (S' ⊆ p.1)) &&
                    bChoice.backgroundIndexesReady }).ball = lv₁.ball := by
            split_ifs <;> rfl
          rw [alg4PrefixInputAt_cons_succ, alg4PrefixInputAt_cons_succ, hhd_ball, hdrop]
          simpa [Fin.getElem_fin] using hrest_j ⟨j, hj'⟩

theorem prefixResidual_map_eq_of_balls {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {p₁ p₂ : List (Alg4OpenedLevel d ι)} (S : Finset ι)
    (hballs : p₂.map (fun lv => lv.ball) = p₁.map (fun lv => lv.ball)) :
    prefixResidual pts (p₂.map Alg4OpenedLevel.toOpenedJobLevel) S =
      prefixResidual pts (p₁.map Alg4OpenedLevel.toOpenedJobLevel) S := by
  have hlen : (p₁.map Alg4OpenedLevel.toOpenedJobLevel).length =
      (p₂.map Alg4OpenedLevel.toOpenedJobLevel).length := by
    have := congrArg List.length hballs
    simp only [List.length_map] at this ⊢
    omega
  symm
  apply prefixResidual_eq_of_balls_eq pts _ _ S hlen
  intro i h₁ h₂
  have hi1 : i < p₁.length := by simpa using h₁
  have hi2 : i < p₂.length := by simpa using h₂
  have hget := congrArg (fun l => l[i]?) hballs
  simp only [List.getElem?_map, List.getElem?_eq_getElem hi1, List.getElem?_eq_getElem hi2,
    Option.map_some, Option.some.injEq] at hget
  simpa [Alg4OpenedLevel.toOpenedJobLevel] using hget

open Classical in
theorem alg4PrefixInputAt_append_singleton {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (pref : List (Alg4OpenedLevel d ι)) (newLv : Alg4OpenedLevel d ι)
    (S_root : Finset ι) :
    (∀ j : ℕ, j ≤ pref.length →
      alg4PrefixInputAt pts (pref ++ [newLv]) S_root j =
        alg4PrefixInputAt pts pref S_root j) ∧
    alg4PrefixInputAt pts pref S_root pref.length =
      prefixResidual pts (pref.map Alg4OpenedLevel.toOpenedJobLevel) S_root := by
  refine ⟨?_, ?_⟩
  · intro j hj
    unfold alg4PrefixInputAt
    rw [List.take_append_of_le_length hj]
  · rw [alg4PrefixInputAt_eq_prefixResidual]
    have hlen : pref.length = (pref.map Alg4OpenedLevel.toOpenedJobLevel).length := by simp
    rw [hlen, List.take_length]

open Classical in
theorem alg4Line5LateOpeningGate_dataWF {d : ℕ} {ι : Type}
    {pts' : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode} {α : ℝ} {L : ℕ}
    (hα_le : α ≤ 1) {S' : Finset ι} {job₂ : Alg4PendingJob d ι}
    (hdwf : PendingJobDataWF mode α L pts' S' job₂)
    (jc : PendingJobStepChoices d ι) :
    let job₃ := alg4Line5LateOpeningGate pts' mode α L job₂ jc
    PendingJobDataWF mode α L pts' S' job₃ ∧
    job₃.deadlineTicks = job₂.deadlineTicks ∧
    job₃.remainingTicks = job₂.remainingTicks := by
  dsimp only [alg4Line5LateOpeningGate]
  by_cases hcl : job₂.closedAsLeaf = true
  · rw [if_pos hcl]
    exact ⟨hdwf, rfl, rfl⟩
  · rw [if_neg hcl]
    by_cases hnotall : (!(job₂.completedPrefix.all (fun lv => lv.backgroundReady))) = true
    · rw [if_pos hnotall]
      exact ⟨hdwf, rfl, rfl⟩
    · rw [if_neg hnotall]
      unfold residualScheduleStep
      by_cases hopen : CanOpenResidualLevel α job₂.remainingTicks job₂.currentResidual.card
      · rw [if_pos hopen]
        by_cases hleaf : IsResidualLeafSize L job₂.currentResidual.card
        · rw [if_pos hleaf]
          dsimp only
          rcases hdwf with ⟨hres, hpfx, _⟩
          have hex := computeExactLeafAnswer_spec pts' job₂.currentResidual jc.leafHint
          refine ⟨⟨hres, hpfx, ?_⟩, rfl, rfl⟩
          simp only [↓reduceIte]
          exact hex
        · rw [if_neg hleaf]
          dsimp only
          have hlarge : IsLargeResidualLevel L job₂.currentResidual.card := by
            unfold IsLargeResidualLevel IsResidualLeafSize at *
            omega
          have hNE : job₂.currentResidual.Nonempty := by
            unfold IsLargeResidualLevel at hlarge
            exact Finset.card_pos.mp (by omega)
          rw [dif_pos hNE]
          rcases hdwf with ⟨hres, hpfx, hcl_ans⟩
          set bId := chooseBirthPointIn job₂.currentResidual hNE jc.openFallbackBirthId
          set ball := selectOpenedLevelBall α pts' job₂.currentResidual bId jc.openSampledCenter
          set newLv : Alg4OpenedLevel d ι :=
            { birthSnapshot := job₂.currentResidual
              ball := ball
              indexMode := mode.backgroundIndexMode
              backgroundReady := false
              trueInputAge := 0
              elapsedRootTicks := 0
              scan2Snapshot := job₂.currentResidual
              heapIndexedIds := ∅
              classifiedIds := ∅
              radiusDict := RadiusDictState.empty ι
              localMatchings := fun _ => LocalMatchingState.empty ι }
          rcases alg4PrefixInputAt_append_singleton pts' job₂.completedPrefix newLv S' with
            ⟨hpref_le, hpref_end⟩
          refine ⟨⟨?_, ?_, ?_⟩, rfl, rfl⟩
          · dsimp only
            rw [List.map_append, List.map_cons, List.map_nil, prefixResidual_append,
              prefixResidual_singleton, ← hres]
            rfl
          · intro j
            dsimp only at j ⊢
            rw [Fin.getElem_fin]
            by_cases hj_lt : j.val < job₂.completedPrefix.length
            · rw [List.getElem_append_left hj_lt, hpref_le j.val (le_of_lt hj_lt)]
              exact hpfx ⟨j.val, hj_lt⟩
            · have hj_eq : j.val = job₂.completedPrefix.length := by
                have := j.isLt
                simp only [List.length_append, List.length_singleton] at this
                omega
              have hget : (job₂.completedPrefix ++ [newLv])[j.val]'(j.isLt) = newLv := by
                rw [List.getElem_append_right (by omega)]
                simp [hj_eq]
              rw [hget, hj_eq, hpref_le _ le_rfl, hpref_end, ← hres]
              exact ⟨rfl, hlarge,
                selectOpenedLevelBall_passes hα_le pts' job₂.currentResidual
                  (chooseBirthPointIn_mem _ hNE _) jc.openSampledCenter,
                le_rfl, hasNodeAge_refl _, Finset.empty_subset _, Finset.empty_subset _,
                empty_radiusDict_wellFormed pts' ball.o,
                empty_validNodeMatchingsOn pts' mode ball,
                fun h => by cases h⟩
          · rw [if_neg hcl] at hcl_ans
            dsimp only
            rw [if_neg hcl]
            exact hcl_ans
      · rw [if_neg hopen]
        exact ⟨hdwf, rfl, rfl⟩

end UL.Proof.claim_C_2_space_reclaim.RacerP44
