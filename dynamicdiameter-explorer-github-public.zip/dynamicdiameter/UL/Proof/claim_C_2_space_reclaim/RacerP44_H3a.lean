import UL.Proof.claim_C_2_space_reclaim.RacerP44_H2b2

set_option autoImplicit false

namespace UL.Proof.claim_C_2_space_reclaim.RacerP44

open Classical
open UL
open UL.Proof.lem_C_2.H1
open UL.Proof.claim_C_2_space_reclaim

/-! ### 1. Equation (10) Cutoff, Age, and Gate Bounds -/

theorem cutoff_sixty_four_le_alpha_L {d n : ℕ} {α C : ℝ} {K₀ L : ℕ}
    (h2n : 2 ≤ n) (hα_pos : 0 < α) (hC : 0 ≤ C)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L) :
    64 * α⁻¹ ≤ (L : ℝ) ∧ 64 ≤ α * (L : ℝ) := by
  have h2 := hL.2
  have hn1 : (1 : ℝ) ≤ (n : ℝ) := by
    have : 1 ≤ n := by omega
    exact_mod_cast this
  have hlog_nn : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg hn1
  have hd_nn : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d
  have hK_nn : (0 : ℝ) ≤ (K₀ : ℝ) := Nat.cast_nonneg K₀
  have hprod_nn : 0 ≤ ((d : ℝ) + Real.log (n : ℝ)) * (K₀ : ℝ) :=
    mul_nonneg (by linarith) hK_nn
  have h64_inv : 64 * α⁻¹ ≤ (L : ℝ) := by linarith
  refine ⟨h64_inv, ?_⟩
  have hmul := mul_le_mul_of_nonneg_left h64_inv (le_of_lt hα_pos)
  have ha_ne : α ≠ 0 := ne_of_gt hα_pos
  have hlhs : α * (64 * α⁻¹) = 64 := by field_simp [ha_ne]
  linarith

theorem large_level_alpha_m_lb {d n : ℕ} {α C : ℝ} {K₀ L m : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (hlarge : IsLargeResidualLevel L m) :
    2 * (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) ≤ α ^ 2 * (m : ℝ) ∧
    2 * (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) ≤ α * (m : ℝ) := by
  have hcut := cutoff_alpha_sq_lb hα_pos hL
  unfold IsLargeResidualLevel at hlarge
  have hm_ge : 2 * (L : ℝ) ≤ (m : ℝ) := by
    have : 2 * L ≤ m := by omega
    exact_mod_cast this
  have h1 : 2 * (2 : ℝ) ^ 20 * (scheduleCStar : ℝ) ≤ α ^ 2 * (m : ℝ) := by
    have hmul := mul_le_mul_of_nonneg_left hm_ge (sq_nonneg α)
    linarith
  have h2 : α ^ 2 * (m : ℝ) ≤ α * (m : ℝ) := by
    have ha2 : α ^ 2 ≤ α := by nlinarith
    exact mul_le_mul_of_nonneg_right ha2 (Nat.cast_nonneg m)
  exact ⟨h1, le_trans h1 h2⟩

theorem jobStartAge_ge_two {d n : ℕ} {α C : ℝ} {K₀ L m : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (hlarge : IsLargeResidualLevel L m) :
    2 ≤ jobStartAge α m := by
  have hlb := (large_level_alpha_m_lb hα_pos hα_le hL hlarge).2
  unfold jobStartAge
  rw [Nat.le_floor_iff (by positivity)]
  unfold scheduleCStar at hlb
  norm_num at hlb ⊢
  linarith

theorem installed_age_lt_jobStartAge {d n : ℕ} {α C : ℝ} {K₀ L m e : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (hlarge : IsLargeResidualLevel L m)
    (he : (e : ℝ) ≤ α * (m : ℝ) / (scheduleCStar : ℝ)) :
    e < jobStartAge α m := by
  have hlb := (large_level_alpha_m_lb hα_pos hα_le hL hlarge).2
  have hlt_floor := Nat.sub_one_lt_floor (α * (m : ℝ) / 64)
  change _ < (jobStartAge α m : ℝ) at hlt_floor
  unfold scheduleCStar at hlb he
  norm_num at hlb he
  have hlt_r : (e : ℝ) < (jobStartAge α m : ℝ) := by linarith
  exact Nat.cast_lt.mp hlt_r

theorem jobDeadlineTicks_pos_of_needsReplacement {d n : ℕ} {α C : ℝ} {K₀ L m₀ : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (hneeds : NeedsScheduledReplacement L m₀) :
    1 ≤ jobDeadlineTicks α m₀ := by
  have hlarge : IsLargeResidualLevel L m₀ := by
    have hL1 := cutoff_L_pos hα_pos hα_le hL
    unfold NeedsScheduledReplacement IsLargeResidualLevel at *
    omega
  have hlb := (large_level_alpha_m_lb hα_pos hα_le hL hlarge).2
  unfold jobDeadlineTicks
  rw [Nat.le_floor_iff (by unfold scheduleCStar; positivity)]
  unfold scheduleCStar at hlb ⊢
  norm_num at hlb ⊢
  linarith

theorem validServingNodeAge_of_wellFormed {d : ℕ} {ι : Type}
    {α : ℝ} {L : ℕ} (hα_pos : 0 < α) (hα_le : α ≤ 1)
    {pts : ι → EuclideanSpace ℝ (Fin d)} {S_cur : Finset ι}
    {sn : ServingNodeState d ι}
    (hwf : sn.WellFormed α L pts S_cur) :
    IsValidServingNodeAge α sn.birthSnapshot.card sn.age := by
  rcases hwf with ⟨hlarge, _, _, hsched⟩
  unfold IsValidServingNodeAge
  set M := sn.birthSnapshot.card
  have hM_pos : (0 : ℝ) < (M : ℝ) := by
    unfold IsLargeResidualLevel at hlarge
    have : 0 < M := by omega
    exact_mod_cast this
  have hαM_pos : 0 < α * (M : ℝ) := mul_pos hα_pos hM_pos
  set startAge := jobStartAge α M
  have hstart_le : (startAge : ℝ) ≤ α * (M : ℝ) / 64 :=
    Nat.floor_le (by positivity)
  by_cases hlt : sn.age < startAge
  · have hage_lt : (sn.age : ℝ) < (startAge : ℝ) := Nat.cast_lt.mpr hlt
    linarith
  · rw [if_neg hlt] at hsched
    rcases hsched with ⟨S_start, ⟨a0, ha0_le, hage0⟩, _, _, job, _, hH_eq, hclock, _⟩
    have hcard_S : S_start.card ≤ M + startAge := by
      have hb := (hasNodeAge_card_bounds hage0).2.2
      omega
    have hcard_S_r : (S_start.card : ℝ) ≤ (M : ℝ) + (startAge : ℝ) := by exact_mod_cast hcard_S
    have hαS : α * (S_start.card : ℝ) ≤ α * ((M : ℝ) + (startAge : ℝ)) :=
      mul_le_mul_of_nonneg_left hcard_S_r (le_of_lt hα_pos)
    have hstart_M : (startAge : ℝ) ≤ (M : ℝ) / 64 := by
      have : α * (M : ℝ) ≤ 1 * (M : ℝ) := mul_le_mul_of_nonneg_right hα_le (le_of_lt hM_pos)
      linarith
    have hH_le : (job.deadlineTicks : ℝ) ≤ α * (S_start.card : ℝ) / (scheduleCStar : ℝ) := by
      rw [hH_eq]
      exact Nat.floor_le (by unfold scheduleCStar; positivity)
    have hage_le_nat : sn.age ≤ startAge + job.deadlineTicks := by omega
    have hage_le_r : (sn.age : ℝ) ≤ (startAge : ℝ) + (job.deadlineTicks : ℝ) := by
      exact_mod_cast hage_le_nat
    have hα_st : α * (startAge : ℝ) ≤ 1 * (startAge : ℝ) :=
      mul_le_mul_of_nonneg_right hα_le (Nat.cast_nonneg _)
    unfold scheduleCStar at hH_le
    norm_num at hH_le
    linarith

theorem gate_closed_during_build_minus3 {d n : ℕ} {ι : Type}
    {α C : ℝ} {K₀ L : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (ball : ChainNode d) (P₀ S : Finset ι)
    {r_open r_now trueAge : ℕ}
    (hlarge : IsLargeResidualLevel L P₀.card)
    (hcore : PassesBirthCoreCheck α pts ball P₀)
    (hr_lb : α * (P₀.card : ℝ) / (scheduleCStar : ℝ) - 3 < (r_open : ℝ))
    (hr_le : r_now ≤ r_open)
    (hΔ_le : ((r_open - r_now : ℕ) : ℝ) ≤
      α ^ 2 * (P₀.card : ℝ) / (64 * (scheduleCStar : ℝ)))
    (hage_le : trueAge ≤ r_open - r_now)
    (hage : HasNodeAge P₀ S trueAge) :
    ¬ CanOpenResidualLevel α r_now (ball.residual pts S).card := by
  unfold CanOpenResidualLevel
  set Δr : ℕ := r_open - r_now
  have hr_sub : (r_now : ℝ) = (r_open : ℝ) - (Δr : ℝ) := by
    have hnat : r_now + Δr = r_open := Nat.add_sub_of_le hr_le
    have hcast : (r_now : ℝ) + (Δr : ℝ) = (r_open : ℝ) := by exact_mod_cast hnat
    linarith
  have hα2m_lb := (large_level_alpha_m_lb hα_pos hα_le hL hlarge).1
  have hm'_le := aged_residual_card_le pts ball P₀ S hcore hage
  have htrue_le : (trueAge : ℝ) ≤ (Δr : ℝ) := by exact_mod_cast hage_le
  have hm'_Δ : ((ball.residual pts S).card : ℝ) ≤ (1 - α / 2) * (P₀.card : ℝ) + (Δr : ℝ) := by
    linarith
  have hα_mul : α * ((ball.residual pts S).card : ℝ) ≤
      α * ((1 - α / 2) * (P₀.card : ℝ) + (Δr : ℝ)) :=
    mul_le_mul_of_nonneg_left hm'_Δ (le_of_lt hα_pos)
  have hαΔ : α * (Δr : ℝ) ≤ 1 * (Δr : ℝ) :=
    mul_le_mul_of_nonneg_right hα_le (Nat.cast_nonneg Δr)
  have h_expand : α * ((1 - α / 2) * (P₀.card : ℝ) + (Δr : ℝ)) =
      α * (P₀.card : ℝ) - (α ^ 2 * (P₀.card : ℝ)) / 2 + α * (Δr : ℝ) := by ring
  unfold scheduleCStar at hr_lb hΔ_le hα2m_lb ⊢
  norm_num at hr_lb hΔ_le hα2m_lb ⊢
  linarith

/-! ### 2. Markovian Job Schedule Invariant (`Alg4JobSchedInv`) -/

def Alg4JobSchedInv {d : ℕ} {ι : Type}
    (n : ℕ) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_root : Finset ι)
    (job : Alg4PendingJob d ι) : Prop :=
  1 ≤ job.remainingTicks ∧
  (∀ (j : ℕ) (lv : Alg4OpenedLevel d ι),
    job.completedPrefix[j]? = some lv →
      let S_lv := alg4PrefixInputAt pts job.completedPrefix S_root j
      let r_open := job.remainingTicks + lv.elapsedRootTicks
      lv.birthSnapshot.card ≤ n ∧
      lv.scan2Snapshot = lv.birthSnapshot ∧
      S_lv \ lv.heapIndexedIds ⊆ lv.birthSnapshot ∧
      S_lv \ lv.classifiedIds ⊆ lv.scan2Snapshot ∧
      α * (lv.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ) - 3 < (r_open : ℝ) ∧
      (r_open : ℝ) ≤ α * (lv.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ) ∧
      (j + 1 < job.completedPrefix.length → lv.backgroundReady = true) ∧
      (∀ (i : ℕ) (lv_prev : Alg4OpenedLevel d ι),
        j = i + 1 → job.completedPrefix[i]? = some lv_prev →
          (lv.birthSnapshot.card : ℝ) ≤ (1 - α / 4) * (lv_prev.birthSnapshot.card : ℝ))) ∧
  (if job.closedAsLeaf = true then
    (∀ lv ∈ job.completedPrefix, lv.backgroundReady = true) ∧
    job.currentResidual.card + job.remainingTicks ≤ 3 * L + 2
  else
    (job.remainingTicks = job.deadlineTicks ∧
     job.completedPrefix = [] ∧
     NeedsScheduledReplacement L job.currentResidual.card ∧
     job.deadlineTicks = jobDeadlineTicks α job.currentResidual.card) ∨
    ¬ CanOpenResidualLevel α job.remainingTicks job.currentResidual.card)

theorem alg4JobSchedInv_congr {d : ℕ} {ι : Type}
    {n : ℕ} {α : ℝ} {L : ℕ}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    {S_root : Finset ι} {job : Alg4PendingJob d ι}
    (hinv : Alg4JobSchedInv n α L pts₁ S_root job)
    (hpts : ∀ x ∈ S_root, pts₂ x = pts₁ x) :
    Alg4JobSchedInv n α L pts₂ S_root job := by
  rcases hinv with ⟨hr1, hpfx, hres⟩
  have hpts' : ∀ x ∈ S_root, pts₁ x = pts₂ x := fun x hx => (hpts x hx).symm
  refine ⟨hr1, ?_, hres⟩
  intro j lv hget
  have heq := alg4PrefixInputAt_congr job.completedPrefix j hpts'
  have hj := hpfx j lv hget
  dsimp only at hj ⊢
  rwa [← heq]

theorem alg4JobSchedInv_init {d n : ℕ} {ι : Type}
    {α C : ℝ} {K₀ L : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_cur : Finset ι)
    (hneeds : NeedsScheduledReplacement L S_cur.card) :
    (Alg4PendingJob.init (d := d) α S_cur).WellFormed .endpointSqrt2 α L pts S_cur ∧
    (∀ mode : Alg4Mode, (Alg4PendingJob.init (d := d) α S_cur).WellFormed mode α L pts S_cur) ∧
    Alg4JobSchedInv n α L pts S_cur (Alg4PendingJob.init (d := d) α S_cur) := by
  have hw_mode : ∀ mode : Alg4Mode,
      (Alg4PendingJob.init (d := d) α S_cur).WellFormed mode α L pts S_cur := by
    intro mode
    refine ⟨⟨le_rfl, rfl, fun _ h => by cases h⟩, fun j => Fin.elim0 j, ?_⟩
    simp [Alg4PendingJob.init]
  refine ⟨hw_mode .endpointSqrt2, hw_mode, ?_⟩
  refine ⟨jobDeadlineTicks_pos_of_needsReplacement hα_pos hα_le hL hneeds,
    fun _ _ h => by simp [Alg4PendingJob.init] at h, ?_⟩
  dsimp only [Alg4PendingJob.init]
  rw [if_neg (by decide)]
  exact Or.inl ⟨rfl, rfl, hneeds, rfl⟩

theorem prefixResidual_last_step {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (pref : List (Alg4OpenedLevel d ι)) (S_root : Finset ι)
    {k : ℕ} (hk : pref.length = k + 1) :
    prefixResidual pts (pref.map Alg4OpenedLevel.toOpenedJobLevel) S_root =
      (pref[k]'(by omega)).ball.residual pts (alg4PrefixInputAt pts pref S_root k) := by
  have hsplit : pref = pref.take k ++ [pref[k]'(by omega)] := by
    have ht := List.take_append_drop k pref
    have hd : pref.drop k = [pref[k]'(by omega)] := by
      rw [List.drop_eq_getElem_cons (by omega)]
      have hdrop_end : pref.drop (k + 1) = [] := List.drop_eq_nil_of_le (by omega)
      rw [hdrop_end]
    rw [hd] at ht
    exact ht.symm
  conv_lhs => rw [hsplit]
  rw [List.map_append, List.map_cons, List.map_nil, prefixResidual_append,
    prefixResidual_singleton, alg4PrefixInputAt_eq_prefixResidual, List.map_take]
  rfl

set_option maxHeartbeats 800000 in
theorem stepSinglePendingJob_sched {d n : ℕ} {ι : Type}
    {pts₀ pts' : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode}
    {α C : ℝ} {K₀ L : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    {S_before S_after : Finset ι} {ev : PoolUpdateEvent ι}
    {job : Alg4PendingJob d ι} (jc : PendingJobStepChoices d ι)
    (hS_after_le : S_after.card ≤ n)
    (hpts_S : ∀ x ∈ S_before, pts' x = pts₀ x)
    (hpts_B : ∀ lv ∈ job.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts' x = pts₀ x)
    (hev : IsValidPoolUpdateEvent S_before S_after ev)
    (hwf0 : job.WellFormed mode α L pts₀ S_before)
    (hsched0 : Alg4JobSchedInv n α L pts₀ S_before job)
    (heq11 :
      let job₁ := alg4Line3RouteThroughPrefix pts' mode job ev S_after jc
      let job₂ := alg4Line4AdvanceClockAndBuild pts' mode job₁ S_after jc.prefixBudgetSteps
      let job₃ := alg4Line5LateOpeningGate pts' mode α L job₂ jc
      ∀ lv ∈ job₃.completedPrefix,
        maxLevelBuildTicks α lv.birthSnapshot.card ≤ lv.elapsedRootTicks →
          lv.backgroundReady = true) :
    let job₁ := alg4Line3RouteThroughPrefix pts' mode job ev S_after jc
    let job₂ := alg4Line4AdvanceClockAndBuild pts' mode job₁ S_after jc.prefixBudgetSteps
    let job₃ := alg4Line5LateOpeningGate pts' mode α L job₂ jc
    job₃.WellFormed mode α L pts' S_after ∧
    job₃.deadlineTicks = job.deadlineTicks ∧
    job₃.remainingTicks = job.remainingTicks - 1 ∧
    (job₃.remainingTicks = 0 →
      job₃.IsReadyToInstall ∧
      job₃.currentResidual.card ≤ 3 * L + 2 ∧
      ∀ lv ∈ job₃.completedPrefix,
        lv.birthSnapshot.card ≤ n ∧
        (lv.elapsedRootTicks : ℝ) ≤ α * (lv.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ)) ∧
    (1 ≤ job₃.remainingTicks →
      ¬ job₃.IsReadyToInstall ∧
      Alg4JobSchedInv n α L pts' S_after job₃) := by
  have hdwf0 := pendingJobDataWF_of_wellFormed hwf0
  have hdwf3 := stepSinglePendingJob_dataWF hα_le jc hpts_S hpts_B hev hdwf0
  dsimp only at heq11 hdwf3 ⊢
  obtain ⟨job₁, hjob1_def⟩ : ∃ x, x = alg4Line3RouteThroughPrefix pts' mode job ev S_after jc := ⟨_, rfl⟩
  rw [← hjob1_def] at heq11 hdwf3 ⊢
  obtain ⟨job₂, hjob2_def⟩ : ∃ x, x = alg4Line4AdvanceClockAndBuild pts' mode job₁ S_after jc.prefixBudgetSteps := ⟨_, rfl⟩
  rw [← hjob2_def] at heq11 hdwf3 ⊢
  obtain ⟨job₃, hjob3_def⟩ : ∃ x, x = alg4Line5LateOpeningGate pts' mode α L job₂ jc := ⟨_, rfl⟩
  rw [← hjob3_def] at heq11 hdwf3 ⊢
  rcases hsched0 with ⟨hr1, hpfx0, hres_state0⟩
  -- Step 1: Unpack prefix invariance from `job` to `job₂`
  rcases alg4Line3RoutePrefixAux_spec pts₀ pts' mode α L job.completedPrefix
      S_before S_after (some ev) jc.prefixRouteQueries jc.prefixRouteMaxHints
      hpts_S hpts_B hev hdwf0.2.1 with ⟨hLen1, _, hroute_j⟩
  have hpref1_eq : job₁.completedPrefix =
      (alg4Line3RoutePrefixAux pts' mode (some ev) job.completedPrefix
        jc.prefixRouteQueries jc.prefixRouteMaxHints).1 := by
    rw [hjob1_def]; rfl
  have hpref2_eq : job₂.completedPrefix =
      stepPrefixConstruction pts' mode S_after job₁.completedPrefix jc.prefixBudgetSteps := by
    rw [hjob2_def]; rfl
  have hstep4_in : ∀ j : Fin job₁.completedPrefix.length,
      let lv₁ := job₁.completedPrefix[j]
      let S_lv' := alg4PrefixInputAt pts' job₁.completedPrefix S_after j.val
      lv₁.indexMode = mode.backgroundIndexMode ∧
      IsLargeResidualLevel L lv₁.birthSnapshot.card ∧
      PassesBirthCoreCheck α pts' lv₁.ball lv₁.birthSnapshot ∧
      lv₁.trueInputAge ≤ lv₁.elapsedRootTicks + 1 ∧
      HasNodeAge lv₁.birthSnapshot S_lv' lv₁.trueInputAge ∧
      lv₁.heapIndexedIds = lv₁.radiusDict.indexedIds ∧
      lv₁.radiusDict.IsScanValid pts' lv₁.ball.o S_lv' ∧
      lv₁.classifiedIds ⊆ S_lv' ∧
      ValidNodeMatchingsOn pts' mode lv₁.ball lv₁.classifiedIds lv₁.localMatchings ∧
      (lv₁.backgroundReady = true →
        lv₁.heapIndexedIds = S_lv' ∧ lv₁.classifiedIds = S_lv') := by
    intro j
    have hj0 : j.val < job.completedPrefix.length := by rw [← hpref1_eq] at hLen1; omega
    have hwf_j := hdwf0.2.1 ⟨j.val, hj0⟩
    have hr := hroute_j ⟨j.val, hj0⟩
    dsimp only at hr hwf_j
    simp only [Fin.getElem_fin] at hr hwf_j
    rcases hr with ⟨hb_eq, _, hball_eq, hmode_eq, _, hel_eq, hhid_eq,
      ev_j, _, ht_le, hage_eq, hage_j, hscan_j, hcls_j, hlm_j, hrdy_j, _, _⟩
    have hpts_Bj : ∀ x ∈ (job.completedPrefix[j.val]'hj0).birthSnapshot, pts₀ x = pts' x :=
      fun x hx => (hpts_B _ (List.getElem_mem _) x hx).symm
    dsimp only
    rw [Fin.getElem_fin]
    simp only [hpref1_eq]
    rw [hb_eq, hball_eq, hmode_eq]
    rw [hb_eq] at hage_j
    refine ⟨hwf_j.1, hwf_j.2.1, (passesBirthCoreCheck_congr α _ hpts_Bj).mp hwf_j.2.2.1,
      ?_, hage_j, hhid_eq, hscan_j, hcls_j, hlm_j, hrdy_j⟩
    have := hwf_j.2.2.2.1
    omega
  have hLen2 := stepPrefixConstruction_length pts' mode job₁.completedPrefix S_after jc.prefixBudgetSteps
  rcases stepPrefixConstruction_spec pts' mode α L job₁.completedPrefix S_after
      jc.prefixBudgetSteps hstep4_in with ⟨hballs2, hstep4_j⟩
  have hLen20 : job₂.completedPrefix.length = job.completedPrefix.length := by
    rw [hpref2_eq, hLen2, hpref1_eq, hLen1]
  have hjob2_rem : job₂.remainingTicks = job.remainingTicks - 1 := by
    rw [hjob2_def, hjob1_def]; rfl
  have hjob2_dl : job₂.deadlineTicks = job.deadlineTicks := by
    rw [hjob2_def, hjob1_def]; rfl
  have hpfx2_props : ∀ (j : ℕ) (hj2 : j < job₂.completedPrefix.length),
      let hj0 : j < job.completedPrefix.length := by omega
      let lv0 := job.completedPrefix[j]'hj0
      let lv2 := job₂.completedPrefix[j]'hj2
      let S_lv' := alg4PrefixInputAt pts' job₂.completedPrefix S_after j
      let r_open := job₂.remainingTicks + lv2.elapsedRootTicks
      lv2.birthSnapshot = lv0.birthSnapshot ∧
      lv2.scan2Snapshot = lv2.birthSnapshot ∧
      lv2.ball = lv0.ball ∧
      lv2.elapsedRootTicks = lv0.elapsedRootTicks + 1 ∧
      lv2.elapsedRootTicks ≤ job₂.deadlineTicks - job₂.remainingTicks ∧
      lv2.WellFormed mode α L pts' S_lv' ∧
      lv2.birthSnapshot.card ≤ n ∧
      S_lv' \ lv2.heapIndexedIds ⊆ lv2.birthSnapshot ∧
      S_lv' \ lv2.classifiedIds ⊆ lv2.scan2Snapshot ∧
      r_open = job.remainingTicks + lv0.elapsedRootTicks ∧
      α * (lv2.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ) - 3 < (r_open : ℝ) ∧
      (r_open : ℝ) ≤ α * (lv2.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ) ∧
      (lv0.backgroundReady = true → lv2.backgroundReady = true) ∧
      (j + 1 < job₂.completedPrefix.length → lv2.backgroundReady = true) ∧
      (∀ (i : ℕ) (lv_prev : Alg4OpenedLevel d ι),
        j = i + 1 → job₂.completedPrefix[i]? = some lv_prev →
          (lv2.birthSnapshot.card : ℝ) ≤ (1 - α / 4) * (lv_prev.birthSnapshot.card : ℝ)) := by
    intro j hj2
    have hj0 : j < job.completedPrefix.length := by omega
    have hj1 : j < job₁.completedPrefix.length := by rw [hpref1_eq, hLen1]; exact hj0
    have hr := hroute_j ⟨j, hj0⟩
    have hs4 := hstep4_j ⟨j, hj1⟩
    dsimp only at hr hs4
    simp only [Fin.getElem_fin] at hr hs4
    have hget1 : job₁.completedPrefix[j]'hj1 =
        (alg4Line3RoutePrefixAux pts' mode (some ev) job.completedPrefix
          jc.prefixRouteQueries jc.prefixRouteMaxHints).1[j]'(by omega) := by
      have hopt : job₁.completedPrefix[j]? =
          (alg4Line3RoutePrefixAux pts' mode (some ev) job.completedPrefix
            jc.prefixRouteQueries jc.prefixRouteMaxHints).1[j]? := by rw [hpref1_eq]
      rw [List.getElem?_eq_getElem hj1, List.getElem?_eq_getElem (by omega)] at hopt
      exact Option.some.inj hopt
    have hget2 : job₂.completedPrefix[j]'hj2 =
        (stepPrefixConstruction pts' mode S_after job₁.completedPrefix
          jc.prefixBudgetSteps)[j]'(by omega) := by
      have hopt : job₂.completedPrefix[j]? =
          (stepPrefixConstruction pts' mode S_after job₁.completedPrefix
            jc.prefixBudgetSteps)[j]? := by rw [hpref2_eq]
      rw [List.getElem?_eq_getElem hj2, List.getElem?_eq_getElem (by omega)] at hopt
      exact Option.some.inj hopt
    rw [← hget1, ← hpref1_eq] at hr
    rw [← hget2, ← hpref2_eq] at hs4
    rcases hr with ⟨hb1, hs2_1, hball1, _, hrdy1, hel1, hhid1,
      _, _, _, _, _, _, _, _, _, hsdiff_h1, hsdiff_c1⟩
    rcases hs4 with ⟨hSin_eq, hb2, hs2_2, hball2, hel2, _, hrdy12, hwf_lv2, hfalse_s4⟩
    have h0_el : (job.completedPrefix[j]'hj0).elapsedRootTicks ≤ job.deadlineTicks - job.remainingTicks := by
      simpa [Fin.getElem_fin] using (hwf0.2.1 ⟨j, hj0⟩).1
    have h0_wf : (job.completedPrefix[j]'hj0).WellFormed mode α L pts₀
        (alg4PrefixInputAt pts₀ job.completedPrefix S_before j) := by
      simpa [Fin.getElem_fin] using (hwf0.2.1 ⟨j, hj0⟩).2
    have h0_dict_id : (job.completedPrefix[j]'hj0).radiusDict.indexedIds =
        (job.completedPrefix[j]'hj0).heapIndexedIds := h0_wf.2.2.2.2.2.2.2.1.1
    have h0_sc := hpfx0 j (job.completedPrefix[j]'hj0) (List.getElem?_eq_getElem hj0)
    rcases h0_sc with ⟨hb_le_n, hs2_0, hsdiff_h0, hsdiff_c0, hropen_lb, hropen_ub, hrdy_lt, hcontr0⟩
    have hb20 : (job₂.completedPrefix[j]'hj2).birthSnapshot =
        (job.completedPrefix[j]'hj0).birthSnapshot := hb2.trans hb1
    have hs2_20 : (job₂.completedPrefix[j]'hj2).scan2Snapshot =
        (job₂.completedPrefix[j]'hj2).birthSnapshot := by
      rw [hs2_2, hs2_1, hs2_0, hb20]
    have hball20 : (job₂.completedPrefix[j]'hj2).ball =
        (job.completedPrefix[j]'hj0).ball := hball2.trans hball1
    have hel20 : (job₂.completedPrefix[j]'hj2).elapsedRootTicks =
        (job.completedPrefix[j]'hj0).elapsedRootTicks + 1 := hel2.trans (by rw [hel1])
    have hdl_le : job.remainingTicks ≤ job.deadlineTicks := hwf0.1.1
    have hel_dl : (job₂.completedPrefix[j]'hj2).elapsedRootTicks ≤
        job₂.deadlineTicks - job₂.remainingTicks := by
      rw [hel20, hjob2_dl, hjob2_rem]
      omega
    have hsdiff_h2 : alg4PrefixInputAt pts' job₂.completedPrefix S_after j \
        (job₂.completedPrefix[j]'hj2).heapIndexedIds ⊆
        (job₂.completedPrefix[j]'hj2).birthSnapshot := by
      rw [hb20]
      by_cases hr1_b : (job₁.completedPrefix[j]'hj1).backgroundReady = true
      · have hfull := (hwf_lv2.2.2.2.2.2.2.2.2.2 (hrdy12 hr1_b)).1
        rw [hfull, Finset.sdiff_self]
        exact Finset.empty_subset _
      · have hr1_f : (job₁.completedPrefix[j]'hj1).backgroundReady = false :=
          Bool.eq_false_iff.mpr hr1_b
        have hs4_diff := (hfalse_s4 hr1_f).1
        rw [hs4_diff]
        refine Finset.Subset.trans Finset.sdiff_subset ?_
        rw [hSin_eq, hhid1]
        refine Finset.Subset.trans hsdiff_h1 ?_
        rw [h0_dict_id]
        exact hsdiff_h0
    have hsdiff_c2 : alg4PrefixInputAt pts' job₂.completedPrefix S_after j \
        (job₂.completedPrefix[j]'hj2).classifiedIds ⊆
        (job₂.completedPrefix[j]'hj2).scan2Snapshot := by
      rw [hs2_20, hb20]
      by_cases hr1_b : (job₁.completedPrefix[j]'hj1).backgroundReady = true
      · have hfull := (hwf_lv2.2.2.2.2.2.2.2.2.2 (hrdy12 hr1_b)).2
        rw [hfull, Finset.sdiff_self]
        exact Finset.empty_subset _
      · have hr1_f : (job₁.completedPrefix[j]'hj1).backgroundReady = false :=
          Bool.eq_false_iff.mpr hr1_b
        have hs4_diff := (hfalse_s4 hr1_f).2.1
        rw [hs4_diff]
        refine Finset.Subset.trans Finset.sdiff_subset ?_
        rw [hSin_eq]
        refine Finset.Subset.trans hsdiff_c1 ?_
        rw [← hs2_0]
        exact hsdiff_c0
    have hropen_eq : job₂.remainingTicks + (job₂.completedPrefix[j]'hj2).elapsedRootTicks =
        job.remainingTicks + (job.completedPrefix[j]'hj0).elapsedRootTicks := by
      rw [hjob2_rem, hel20]; omega
    refine ⟨hb20, hs2_20, hball20, hel20, hel_dl, hwf_lv2, hb20 ▸ hb_le_n,
      hsdiff_h2, hsdiff_c2, hropen_eq,
      by rw [hb20, hropen_eq]; exact hropen_lb,
      by rw [hb20, hropen_eq]; exact hropen_ub,
      fun hb0 => hrdy12 (hrdy1.trans hb0),
      fun hj_lt => hrdy12 (hrdy1.trans (hrdy_lt (by omega))),
      ?_⟩
    intro i lv_prev hji hget_i
    have hi2 : i < job₂.completedPrefix.length := by omega
    have hi0 : i < job.completedPrefix.length := by omega
    have hi1 : i < job₁.completedPrefix.length := by omega
    rw [List.getElem?_eq_getElem hi2] at hget_i
    injection hget_i with hprev_eq
    subst hprev_eq
    have hb_i1 := (hroute_j ⟨i, hi0⟩).1
    have hb_i2 := (hstep4_j ⟨i, hi1⟩).2.1
    dsimp only at hb_i1 hb_i2
    simp only [Fin.getElem_fin] at hb_i1 hb_i2
    have hgi1 : job₁.completedPrefix[i]'hi1 =
        (alg4Line3RoutePrefixAux pts' mode (some ev) job.completedPrefix
          jc.prefixRouteQueries jc.prefixRouteMaxHints).1[i]'(by omega) := by
      have hopt : job₁.completedPrefix[i]? =
          (alg4Line3RoutePrefixAux pts' mode (some ev) job.completedPrefix
            jc.prefixRouteQueries jc.prefixRouteMaxHints).1[i]? := by rw [hpref1_eq]
      rw [List.getElem?_eq_getElem hi1, List.getElem?_eq_getElem (by omega)] at hopt
      exact Option.some.inj hopt
    have hgi2 : job₂.completedPrefix[i]'hi2 =
        (stepPrefixConstruction pts' mode S_after job₁.completedPrefix
          jc.prefixBudgetSteps)[i]'(by omega) := by
      have hopt : job₂.completedPrefix[i]? =
          (stepPrefixConstruction pts' mode S_after job₁.completedPrefix
            jc.prefixBudgetSteps)[i]? := by rw [hpref2_eq]
      rw [List.getElem?_eq_getElem hi2, List.getElem?_eq_getElem (by omega)] at hopt
      exact Option.some.inj hopt
    rw [← hgi1] at hb_i1
    rw [← hgi2] at hb_i2
    have hb_i20 : (job₂.completedPrefix[i]'hi2).birthSnapshot =
        (job.completedPrefix[i]'hi0).birthSnapshot := hb_i2.trans hb_i1
    rw [hb20, hb_i20]
    exact hcontr0 i (job.completedPrefix[i]'hi0) hji (List.getElem?_eq_getElem hi0)
  -- Residual card change `≤ 1` across the root event `ev`
  have hres2_eq_pfx0 : job₂.currentResidual =
      prefixResidual pts' (job.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_after := by
    have hballs10 : job₁.completedPrefix.map (fun lv => lv.ball) =
        job.completedPrefix.map (fun lv => lv.ball) := by
      apply List.ext_getElem
      · simp [hpref1_eq, hLen1]
      · intro i hi1 hi0
        simp only [List.length_map] at hi1 hi0
        have hr := (hroute_j ⟨i, hi0⟩).2.2.1
        dsimp only at hr
        simp only [Fin.getElem_fin] at hr
        simpa [hpref1_eq] using hr
    rw [hjob2_def, hjob1_def]
    dsimp only [alg4Line4AdvanceClockAndBuild, alg4Line3RouteThroughPrefix]
    rw [← hpref1_eq]
    exact prefixResidual_map_eq_of_balls pts' S_after hballs10
  have hres0_pts' : job.currentResidual =
      prefixResidual pts' (job.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_before := by
    rw [hdwf0.1]
    exact prefixResidual_congr _ (fun x hx => (hpts_S x hx).symm)
  have hres_card_step : job₂.currentResidual.card ≤ job.currentResidual.card + 1 := by
    rw [hres2_eq_pfx0, hres0_pts', prefixResidual_eq_filter, prefixResidual_eq_filter]
    have hf := (filter_validPoolUpdateEvent
      (inPrefixRes pts' (job.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel)) hev).2.1
    have ht := poolUpdateEvent_ticks_le_one ev
    omega
  -- Helper: `job₂.WellFormed` holds right now
  have hwf2 : job₂.WellFormed mode α L pts' S_after := by
    have hdwf2 : PendingJobDataWF mode α L pts' S_after job₂ := by
      refine ⟨?_, ?_, ?_⟩
      · rw [hpref2_eq]
        have hres21 : job₂.currentResidual =
            prefixResidual pts' (job₁.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_after := by
          rw [hjob2_def, hjob1_def]; rfl
        rw [hres21]
        exact (prefixResidual_map_eq_of_balls pts' S_after hballs2).symm
      · intro j
        exact (hpfx2_props j.val j.isLt).2.2.2.2.2.1
      · rw [hjob2_def, hjob1_def]
        dsimp only [alg4Line4AdvanceClockAndBuild, alg4Line3RouteThroughPrefix]
        by_cases hcl : job.closedAsLeaf = true
        · simp only [hcl, ↓reduceIte]
          exact computeExactLeafAnswer_spec pts' _ jc.leafHint
        · simp [hcl]
    refine ⟨⟨?_, hdwf2.1, ?_⟩, ?_, hdwf2.2.2⟩
    · dsimp only [Alg4PendingJob.toPendingReplacementJob]
      rw [hjob2_rem, hjob2_dl]
      have h0_le : job.remainingTicks ≤ job.deadlineTicks := hwf0.1.1
      omega
    · intro lv hlv
      rcases List.mem_map.mp hlv with ⟨alv, halv, rfl⟩
      rcases List.mem_iff_getElem.mp halv with ⟨j, hj, rfl⟩
      have hjw := (hpfx2_props j hj).2.2.2.2.2.1
      exact ⟨hjw.2.1, hjw.2.2.1⟩
    · intro j
      rw [Fin.getElem_fin]
      exact ⟨(hpfx2_props j.val j.isLt).2.2.2.2.1, (hpfx2_props j.val j.isLt).2.2.2.2.2.1⟩
  -- Helper: any `lv ∈ job₂.completedPrefix` is in `job₃.completedPrefix`
  have hmem2_in_3 : ∀ lv ∈ job₂.completedPrefix, lv ∈ job₃.completedPrefix := by
    intro lv hlv
    rw [hjob3_def]
    dsimp only [alg4Line5LateOpeningGate]
    by_cases h1 : job₂.closedAsLeaf = true
    · rw [if_pos h1]; exact hlv
    · rw [if_neg h1]
      by_cases h2 : (!(job₂.completedPrefix.all (fun lv => lv.backgroundReady))) = true
      · rw [if_pos h2]; exact hlv
      · rw [if_neg h2]
        cases residualScheduleStep α L job₂.remainingTicks job₂.currentResidual.card with
        | wait => exact hlv
        | closeAsLeaf => exact hlv
        | openBallLevel =>
          dsimp only
          by_cases hNE : job₂.currentResidual.Nonempty
          · rw [dif_pos hNE]; exact List.mem_append_left _ hlv
          · rw [dif_neg hNE]; exact hlv
  -- Step 2: Case split on `alg4Line5LateOpeningGate`
  have hcl2_eq : job₂.closedAsLeaf = job.closedAsLeaf := by
    rw [hjob2_def, hjob1_def]; rfl
  by_cases hcl : job.closedAsLeaf = true
  · -- Subcase A: `job.closedAsLeaf = true`
    have hcl2 : job₂.closedAsLeaf = true := hcl2_eq.trans hcl
    have hjob3_eq : job₃ = job₂ := by
      rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
      rw [if_pos hcl2]
    rw [hjob3_eq]
    rw [if_pos hcl] at hres_state0
    rcases hres_state0 with ⟨hall_rdy0, hlyap0⟩
    have hall_rdy2 : ∀ lv ∈ job₂.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel,
        lv.backgroundReady = true := by
      intro lv hlv
      rcases List.mem_map.mp hlv with ⟨alv, halv, rfl⟩
      rcases List.mem_iff_getElem.mp halv with ⟨j, hj2, rfl⟩
      have hj0 : j < job.completedPrefix.length := by omega
      have hb0 : (job.completedPrefix[j]'hj0).backgroundReady = true :=
        hall_rdy0 _ (List.getElem_mem hj0)
      exact (hpfx2_props j hj2).2.2.2.2.2.2.2.2.2.2.2.2.1 hb0
    have hall_rdy2_alg4 : ∀ lv ∈ job₂.completedPrefix, lv.backgroundReady = true := by
      intro lv hlv
      exact hall_rdy2 lv.toOpenedJobLevel (List.mem_map_of_mem hlv)
    have hlyap2 : job₂.currentResidual.card + job₂.remainingTicks ≤ 3 * L + 2 := by
      rw [hjob2_rem]; omega
    refine ⟨hwf2, hjob2_dl, hjob2_rem, ?_, ?_⟩
    · intro hr0
      refine ⟨⟨hr0, hcl2, hall_rdy2⟩, by omega, ?_⟩
      intro lv hlv
      rcases List.mem_iff_getElem.mp hlv with ⟨j, hj2, rfl⟩
      have hp := hpfx2_props j hj2
      refine ⟨hp.2.2.2.2.2.2.1, ?_⟩
      have hropen_ub := hp.2.2.2.2.2.2.2.2.2.2.2.1
      have : job₂.remainingTicks + (job₂.completedPrefix[j]'hj2).elapsedRootTicks =
          (job₂.completedPrefix[j]'hj2).elapsedRootTicks := by omega
      rw [this] at hropen_ub
      exact hropen_ub
    · intro hr_pos
      refine ⟨fun hrdy => by have := hrdy.1; change job₂.remainingTicks = 0 at this; omega, ?_⟩
      refine ⟨hr_pos, ?_, ?_⟩
      · intro j lv hget
        have hj2 : j < job₂.completedPrefix.length := by
          by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
        rw [List.getElem?_eq_getElem hj2] at hget
        injection hget with hget_eq; subst hget_eq
        have hp := hpfx2_props j hj2
        exact ⟨hp.2.2.2.2.2.2.1, hp.2.1, hp.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.1,
          hp.2.2.2.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.2.2.2.1,
          hp.2.2.2.2.2.2.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.2.2.2.2.2.2⟩
      · rw [if_pos hcl2]
        exact ⟨hall_rdy2_alg4, hlyap2⟩
  · -- Subcase B: `job.closedAsLeaf = false`
    have hcl_f : job.closedAsLeaf = false := Bool.eq_false_iff.mpr hcl
    have hcl2_f : job₂.closedAsLeaf = false := hcl2_eq.trans hcl_f
    have hcl2_neg : ¬ job₂.closedAsLeaf = true := by rw [hcl2_f]; decide
    rw [if_neg hcl] at hres_state0
    by_cases hnotall : (!(job₂.completedPrefix.all (fun lv => lv.backgroundReady))) = true
    · -- Subcase B1: last prefix level still building
      have hjob3_eq : job₃ = job₂ := by
        rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
        rw [if_neg hcl2_neg, if_pos hnotall]
      rw [hjob3_eq]
      have hex_not_rdy : ∃ j : Fin job₂.completedPrefix.length,
          (job₂.completedPrefix[j]).backgroundReady = false := by
        simp only [Bool.not_eq_true', List.all_eq_false] at hnotall
        rcases hnotall with ⟨lv, hlv_mem, hlv_nr⟩
        rcases List.mem_iff_getElem.mp hlv_mem with ⟨j, hj, rfl⟩
        exact ⟨⟨j, hj⟩, by rw [Fin.getElem_fin]; simpa using hlv_nr⟩
      rcases hex_not_rdy with ⟨j_nr, hj_nr_f⟩
      rw [Fin.getElem_fin] at hj_nr_f
      have hlen_pos : 1 ≤ job₂.completedPrefix.length := by have := j_nr.isLt; omega
      set k := job₂.completedPrefix.length - 1
      have hk_lt : k < job₂.completedPrefix.length := by omega
      have hj_eq_k : j_nr.val = k := by
        by_contra hne
        have hlt_k : j_nr.val + 1 < job₂.completedPrefix.length := by
          have := j_nr.isLt; omega
        have hrdy_t := (hpfx2_props j_nr.val j_nr.isLt).2.2.2.2.2.2.2.2.2.2.2.2.2.1 hlt_k
        rw [hrdy_t] at hj_nr_f; cases hj_nr_f
      have hk_nr_f : (job₂.completedPrefix[k]'hk_lt).backgroundReady = false := by
        have hopt : job₂.completedPrefix[k]? = job₂.completedPrefix[j_nr.val]? := by rw [hj_eq_k]
        rw [List.getElem?_eq_getElem hk_lt, List.getElem?_eq_getElem j_nr.isLt] at hopt
        rw [Option.some.inj hopt]; exact hj_nr_f
      set lv_k := job₂.completedPrefix[k]'hk_lt
      have hel_lt_max : lv_k.elapsedRootTicks < maxLevelBuildTicks α lv_k.birthSnapshot.card := by
        by_contra hge
        have hrdy_t := heq11 lv_k (hmem2_in_3 lv_k (List.getElem_mem hk_lt)) (Nat.le_of_not_lt hge)
        rw [hrdy_t] at hk_nr_f; cases hk_nr_f
      have hpk := hpfx2_props k hk_lt
      have hlv_k_wf := hpk.2.2.2.2.2.1
      have hlarge_k : IsLargeResidualLevel L lv_k.birthSnapshot.card := hlv_k_wf.2.1
      have hel_ub_r : (lv_k.elapsedRootTicks : ℝ) ≤
          α ^ 2 * (lv_k.birthSnapshot.card : ℝ) / (64 * (scheduleCStar : ℝ)) := by
        have hlt_fl : (lv_k.elapsedRootTicks : ℝ) < (maxLevelBuildTicks α lv_k.birthSnapshot.card : ℝ) :=
          Nat.cast_lt.mpr hel_lt_max
        have hfl_le : (maxLevelBuildTicks α lv_k.birthSnapshot.card : ℝ) ≤
            α ^ 2 * (lv_k.birthSnapshot.card : ℝ) / (64 * (scheduleCStar : ℝ)) :=
          Nat.floor_le (by unfold scheduleCStar; positivity)
        linarith
      have hrem2_pos : 1 ≤ job₂.remainingTicks := by
        by_contra hrem0
        have hr_zero : job₂.remainingTicks = 0 := by omega
        have hropen_lb := hpk.2.2.2.2.2.2.2.2.2.2.1
        rw [hr_zero, Nat.zero_add] at hropen_lb
        have hαm_lb := (large_level_alpha_m_lb hα_pos hα_le hL hlarge_k).2
        have hα2_le : α ^ 2 * (lv_k.birthSnapshot.card : ℝ) ≤ α * (lv_k.birthSnapshot.card : ℝ) := by
          have : α ^ 2 ≤ α := by nlinarith
          exact mul_le_mul_of_nonneg_right this (Nat.cast_nonneg _)
        unfold scheduleCStar at hropen_lb hel_ub_r hαm_lb
        norm_num at hropen_lb hel_ub_r hαm_lb
        linarith
      have hres2_last : job₂.currentResidual =
          lv_k.ball.residual pts' (alg4PrefixInputAt pts' job₂.completedPrefix S_after k) := by
        have hdwf2_res : job₂.currentResidual =
            prefixResidual pts' (job₂.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_after :=
          hwf2.1.2.1
        have hk_len : job₂.completedPrefix.length = k + 1 := by dsimp only [k]; omega
        rw [hdwf2_res, prefixResidual_last_step pts' job₂.completedPrefix S_after hk_len]
      have hnot_open2 : ¬ CanOpenResidualLevel α job₂.remainingTicks job₂.currentResidual.card := by
        rw [hres2_last]
        have hropen_sub : job₂.remainingTicks + lv_k.elapsedRootTicks - job₂.remainingTicks =
            lv_k.elapsedRootTicks := Nat.add_sub_cancel_left _ _
        apply gate_closed_during_build_minus3 hα_pos hα_le hL pts' lv_k.ball
          lv_k.birthSnapshot (alg4PrefixInputAt pts' job₂.completedPrefix S_after k)
          hlarge_k hlv_k_wf.2.2.1 hpk.2.2.2.2.2.2.2.2.2.2.1
          (Nat.le_add_right _ _)
          (by rw [hropen_sub]; exact hel_ub_r)
          (by rw [hropen_sub]; exact hlv_k_wf.2.2.2.1)
          hlv_k_wf.2.2.2.2.1
      refine ⟨hwf2, hjob2_dl, hjob2_rem, fun hr0 => by omega, ?_⟩
      intro _
      refine ⟨fun hrdy => by have := hrdy.1; change job₂.remainingTicks = 0 at this; omega, ?_⟩
      refine ⟨hrem2_pos, ?_, ?_⟩
      · intro j lv hget
        have hj2 : j < job₂.completedPrefix.length := by
          by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
        rw [List.getElem?_eq_getElem hj2] at hget
        injection hget with hget_eq; subst hget_eq
        have hp := hpfx2_props j hj2
        exact ⟨hp.2.2.2.2.2.2.1, hp.2.1, hp.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.1,
          hp.2.2.2.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.2.2.2.1,
          hp.2.2.2.2.2.2.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.2.2.2.2.2.2⟩
      · rw [if_neg hcl2_neg]
        exact Or.inr hnot_open2
    · -- Subcase B2: all prefix levels in `job₂` have `backgroundReady = true`
      have hall_rdy2 : ∀ lv ∈ job₂.completedPrefix, lv.backgroundReady = true := by
        simp only [Bool.not_eq_true', Bool.not_eq_false, List.all_eq_true] at hnotall
        exact hnotall
      by_cases hopen : CanOpenResidualLevel α job₂.remainingTicks job₂.currentResidual.card
      · -- Gate opens! Establish pre-tick lower bound `- 3 < job₂.remainingTicks`
        have hr_lb_new :
            α * (job₂.currentResidual.card : ℝ) / (scheduleCStar : ℝ) - 3 <
              (job₂.remainingTicks : ℝ) := by
          rcases hres_state0 with ⟨hr_eq_dl, _, _, hdl_eq⟩ | hnot_open0
          · have hr_old : job.remainingTicks = job₂.remainingTicks + 1 := by omega
            have hfl : α * (job.currentResidual.card : ℝ) / (scheduleCStar : ℝ) - 1 <
                ((jobDeadlineTicks α job.currentResidual.card : ℕ) : ℝ) :=
              Nat.sub_one_lt_floor _
            rw [← hdl_eq, ← hr_eq_dl, hr_old] at hfl
            push_cast at hfl
            have hm_le_r : (job₂.currentResidual.card : ℝ) ≤ (job.currentResidual.card : ℝ) + 1 := by
              exact_mod_cast hres_card_step
            have hαm : α * (job₂.currentResidual.card : ℝ) - α ≤ α * (job.currentResidual.card : ℝ) := by
              have := mul_le_mul_of_nonneg_left (show (job₂.currentResidual.card : ℝ) - 1 ≤ (job.currentResidual.card : ℝ) by linarith) (le_of_lt hα_pos)
              linarith
            unfold scheduleCStar at hfl ⊢
            norm_num at hfl ⊢
            linarith
          · have hlb2 := pre_tick_gate_lb hα_pos hα_le
              (r_old := job.remainingTicks) (r_pre := job₂.remainingTicks)
              (m_old := job.currentResidual.card) (m_pre := job₂.currentResidual.card)
              (by omega) hres_card_step hnot_open0
            linarith
        by_cases hleaf : IsResidualLeafSize L job₂.currentResidual.card
        · -- Subcase B2b-i: `.closeAsLeaf`
          have hjob3_eq : job₃ =
              (let p := computeExactLeafAnswer pts' job₂.currentResidual jc.leafHint
               { job₂ with closedAsLeaf := true, closedLeafAnswer := p.1, closedLeafDistSq := p.2 }) := by
            rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
            rw [if_neg hcl2_neg, if_neg hnotall]
            unfold residualScheduleStep
            rw [if_pos hopen, if_pos hleaf]
          have hlyap3 : job₂.currentResidual.card + job₂.remainingTicks ≤ 3 * L + 2 :=
            leaf_close_lyapunov hα_le hleaf hopen
          have hwf3 : job₃.WellFormed mode α L pts' S_after := by
            refine ⟨⟨?_, hdwf3.1, ?_⟩, ?_, hdwf3.2.2⟩
            · rw [hjob3_eq]; exact hwf2.1.1
            · rw [hjob3_eq]; exact hwf2.1.2.2
            · intro j
              let jv : ℕ := j.val
              have hcp3 : job₃.completedPrefix = job₂.completedPrefix := by rw [hjob3_eq]
              have hj3_lt : jv < job₃.completedPrefix.length := j.isLt
              have hj2 : jv < job₂.completedPrefix.length := by rwa [hcp3] at hj3_lt
              have h1 : (job₂.completedPrefix[jv]'hj2).elapsedRootTicks ≤
                  job₂.deadlineTicks - job₂.remainingTicks := by
                simpa [Fin.getElem_fin] using (hwf2.2.1 ⟨jv, hj2⟩).1
              have h2 := hdwf3.2.1 j
              refine ⟨?_, h2⟩
              rw [Fin.getElem_fin]
              have heq_el : (job₃.completedPrefix[jv]'hj3_lt).elapsedRootTicks =
                  (job₂.completedPrefix[jv]'hj2).elapsedRootTicks := by
                have hopt : job₃.completedPrefix[jv]? = job₂.completedPrefix[jv]? := by rw [hcp3]
                rw [List.getElem?_eq_getElem hj3_lt, List.getElem?_eq_getElem hj2] at hopt
                exact congrArg Alg4OpenedLevel.elapsedRootTicks (Option.some.inj hopt)
              have heq_dl : job₃.deadlineTicks - job₃.remainingTicks =
                  job₂.deadlineTicks - job₂.remainingTicks := by rw [hjob3_eq]
              rw [heq_el, heq_dl]
              exact h1
          have hdl3 : job₃.deadlineTicks = job.deadlineTicks := by rw [hjob3_eq]; exact hjob2_dl
          have hrem3 : job₃.remainingTicks = job.remainingTicks - 1 := by rw [hjob3_eq]; exact hjob2_rem
          refine ⟨hwf3, hdl3, hrem3, ?_, ?_⟩
          · intro hr0
            refine ⟨⟨hr0, by dsimp only [Alg4PendingJob.toPendingReplacementJob]; rw [hjob3_eq], ?_⟩, ?_, ?_⟩
            · intro lv hlv
              rw [hjob3_eq] at hlv
              rcases List.mem_map.mp hlv with ⟨alv, halv, rfl⟩
              exact hall_rdy2 alv halv
            · rw [hjob3_eq] at hr0 ⊢
              dsimp only at hr0 ⊢
              omega
            · intro lv hlv
              rw [hjob3_eq] at hlv
              rcases List.mem_iff_getElem.mp hlv with ⟨j, hj2, rfl⟩
              have hp := hpfx2_props j hj2
              refine ⟨hp.2.2.2.2.2.2.1, ?_⟩
              have hub := hp.2.2.2.2.2.2.2.2.2.2.2.1
              have hr0' : job₂.remainingTicks = 0 := by rw [hjob3_eq] at hr0; exact hr0
              rw [hr0', Nat.zero_add] at hub
              exact hub
          · intro hr_pos
            refine ⟨fun hrdy => by have := hrdy.1; change job₃.remainingTicks = 0 at this; omega, ?_⟩
            rw [hjob3_eq] at hr_pos ⊢
            refine ⟨hr_pos, ?_, ?_⟩
            · intro j lv hget
              dsimp only at hget ⊢
              have hj2 : j < job₂.completedPrefix.length := by
                by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
              rw [List.getElem?_eq_getElem hj2] at hget
              injection hget with hget_eq; subst hget_eq
              have hp := hpfx2_props j hj2
              exact ⟨hp.2.2.2.2.2.2.1, hp.2.1, hp.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.1,
                hp.2.2.2.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.2.2.2.1,
                hp.2.2.2.2.2.2.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.2.2.2.2.2.2⟩
            · dsimp only
              simp only [↓reduceIte]
              exact ⟨hall_rdy2, hlyap3⟩
        · -- Subcase B2b-ii: `.openBallLevel`
          have hlarge_new : IsLargeResidualLevel L job₂.currentResidual.card := by
            unfold IsLargeResidualLevel IsResidualLeafSize at *; omega
          have hNE : job₂.currentResidual.Nonempty := by
            unfold IsLargeResidualLevel at hlarge_new
            exact Finset.card_pos.mp (by omega)
          have hrem2_pos : 1 ≤ job₂.remainingTicks := by
            by_contra hrem0
            have hr_zero : job₂.remainingTicks = 0 := by omega
            rw [hr_zero, Nat.cast_zero] at hr_lb_new
            have hαm_lb := (large_level_alpha_m_lb hα_pos hα_le hL hlarge_new).2
            unfold scheduleCStar at hr_lb_new hαm_lb
            norm_num at hr_lb_new hαm_lb
            linarith
          set bId := chooseBirthPointIn job₂.currentResidual hNE jc.openFallbackBirthId
          obtain ⟨ball, hball_def⟩ : ∃ x, x = selectOpenedLevelBall α pts' job₂.currentResidual bId jc.openSampledCenter := ⟨_, rfl⟩
          set newLv : Alg4OpenedLevel d ι :=
            { birthSnapshot := job₂.currentResidual
              ball := ball
              indexMode := mode.backgroundIndexMode
              backgroundReady := false
              trueInputAge := 0
              elapsedRootTicks := 0
              scan2Snapshot := job₂.currentResidual
              heapIndexedIds := ∅
              classifiedIds := ∅
              radiusDict := RadiusDictState.empty ι
              localMatchings := fun _ => LocalMatchingState.empty ι }
          have hjob3_eq : job₃ =
              { job₂ with
                completedPrefix := job₂.completedPrefix ++ [newLv]
                currentResidual := ball.residual pts' job₂.currentResidual } := by
            rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
            rw [if_neg hcl2_neg, if_neg hnotall]
            unfold residualScheduleStep
            rw [if_pos hopen, if_neg hleaf]
            dsimp only
            rw [dif_pos hNE, ← hball_def]
          have hcore_new : PassesBirthCoreCheck α pts' ball job₂.currentResidual := by
            rw [hball_def]
            exact selectOpenedLevelBall_passes hα_le pts' job₂.currentResidual
              (chooseBirthPointIn_mem _ hNE _) jc.openSampledCenter
          have hwf2_res : job₂.currentResidual =
              prefixResidual pts' (job₂.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_after :=
            hwf2.1.2.1
          have hm_new_le_n : job₂.currentResidual.card ≤ n := by
            have hsub : job₂.currentResidual ⊆ S_after := by
              rw [hwf2_res]
              exact prefixResidual_subset _ _ _
            exact le_trans (Finset.card_le_card hsub) hS_after_le
          have hwf3 : job₃.WellFormed mode α L pts' S_after := by
            refine ⟨⟨by dsimp only [Alg4PendingJob.toPendingReplacementJob]; rw [hjob3_eq]; exact hwf2.1.1, hdwf3.1, ?_⟩, ?_, hdwf3.2.2⟩
            · intro lv hlv
              rcases List.mem_map.mp hlv with ⟨alv, halv, rfl⟩
              rcases List.mem_iff_getElem.mp halv with ⟨j, hj, rfl⟩
              have hjw := hdwf3.2.1 ⟨j, hj⟩
              rw [Fin.getElem_fin] at hjw
              exact ⟨hjw.2.1, hjw.2.2.1⟩
            · intro j
              let jv : ℕ := j.val
              have hcp3 : job₃.completedPrefix = job₂.completedPrefix ++ [newLv] := by rw [hjob3_eq]
              have hj3_lt : jv < job₃.completedPrefix.length := j.isLt
              have hj_len : jv < (job₂.completedPrefix ++ [newLv]).length := by rwa [hcp3] at hj3_lt
              have h2 := hdwf3.2.1 j
              refine ⟨?_, h2⟩
              rw [Fin.getElem_fin]
              have heq_dl : job₃.deadlineTicks - job₃.remainingTicks =
                  job₂.deadlineTicks - job₂.remainingTicks := by rw [hjob3_eq]
              rw [heq_dl]
              have hget_eq : (job₃.completedPrefix[jv]'hj3_lt) =
                  (job₂.completedPrefix ++ [newLv])[jv]'hj_len := by
                have hopt : job₃.completedPrefix[jv]? = (job₂.completedPrefix ++ [newLv])[jv]? := by
                  rw [hcp3]
                rw [List.getElem?_eq_getElem hj3_lt, List.getElem?_eq_getElem hj_len] at hopt
                exact Option.some.inj hopt
              rw [hget_eq]
              by_cases hj_lt : jv < job₂.completedPrefix.length
              · rw [List.getElem_append_left hj_lt]
                exact (hpfx2_props jv hj_lt).2.2.2.2.1
              · have hj_eq : jv = job₂.completedPrefix.length := by
                  simp only [List.length_append, List.length_singleton] at hj_len; omega
                rw [List.getElem_append_right (by omega)]
                simp [hj_eq, newLv]
          have hdl3 : job₃.deadlineTicks = job.deadlineTicks := by rw [hjob3_eq]; exact hjob2_dl
          have hrem3 : job₃.remainingTicks = job.remainingTicks - 1 := by rw [hjob3_eq]; exact hjob2_rem
          have hrem3_pos : 1 ≤ job₃.remainingTicks := by rw [hjob3_eq]; exact hrem2_pos
          refine ⟨hwf3, hdl3, hrem3, fun hr0 => by omega, ?_⟩
          intro _
          refine ⟨fun hrdy => by have := hrdy.1; change job₃.remainingTicks = 0 at this; omega, ?_⟩
          rw [hjob3_eq]
          refine ⟨hrem2_pos, ?_, ?_⟩
          · intro j lv hget
            dsimp only at hget ⊢
            rcases alg4PrefixInputAt_append_singleton pts' job₂.completedPrefix newLv S_after with
              ⟨hpref_le, hpref_end⟩
            by_cases hj_lt : j < job₂.completedPrefix.length
            · rw [List.getElem?_append_left hj_lt, List.getElem?_eq_getElem hj_lt] at hget
              injection hget with hget_eq; subst hget_eq
              rw [hpref_le j (le_of_lt hj_lt)]
              have hp := hpfx2_props j hj_lt
              refine ⟨hp.2.2.2.2.2.2.1, hp.2.1, hp.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.1,
                hp.2.2.2.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.2.2.2.1,
                fun _ => hall_rdy2 _ (List.getElem_mem hj_lt), ?_⟩
              intro i lv_prev hji hget_i
              have hi_lt : i < job₂.completedPrefix.length := by omega
              rw [List.getElem?_append_left hi_lt] at hget_i
              exact hp.2.2.2.2.2.2.2.2.2.2.2.2.2.2 i lv_prev hji hget_i
            · have hge : job₂.completedPrefix.length ≤ j := Nat.le_of_not_lt hj_lt
              rw [List.getElem?_append_right hge] at hget
              by_cases hj_eq : j = job₂.completedPrefix.length
              · subst hj_eq
                simp only [Nat.sub_self, List.getElem?_cons_zero, Option.some.injEq] at hget
                subst hget
                rw [hpref_le _ le_rfl, hpref_end, ← hwf2_res]
                dsimp only [newLv]
                rw [Nat.add_zero, Finset.sdiff_empty]
                refine ⟨hm_new_le_n, rfl, Finset.Subset.refl _, Finset.Subset.refl _,
                  hr_lb_new, hopen,
                  fun hlt_end => by simp at hlt_end, ?_⟩
                intro i lv_prev hi_eq hget_i
                have hi_lt : i < job₂.completedPrefix.length := by omega
                rw [List.getElem?_append_left hi_lt, List.getElem?_eq_getElem hi_lt] at hget_i
                injection hget_i with hgeti_eq; subst hgeti_eq
                have hres_last : job₂.currentResidual =
                    (job₂.completedPrefix[i]'hi_lt).ball.residual pts'
                      (alg4PrefixInputAt pts' job₂.completedPrefix S_after i) := by
                  rw [hwf2_res, prefixResidual_last_step pts' job₂.completedPrefix S_after hi_eq]
                rw [hres_last]
                have hpi := hpfx2_props i hi_lt
                have hwfi := hpi.2.2.2.2.2.1
                have htrue_le_el : (job₂.completedPrefix[i]'hi_lt).trueInputAge ≤
                    job₂.remainingTicks + (job₂.completedPrefix[i]'hi_lt).elapsedRootTicks := by
                  have := hwfi.2.2.2.1; omega
                have htrue_ub : ((job₂.completedPrefix[i]'hi_lt).trueInputAge : ℝ) ≤
                    α * ((job₂.completedPrefix[i]'hi_lt).birthSnapshot.card : ℝ) /
                      (scheduleCStar : ℝ) := by
                  have h1 : ((job₂.completedPrefix[i]'hi_lt).trueInputAge : ℝ) ≤
                      ((job₂.remainingTicks + (job₂.completedPrefix[i]'hi_lt).elapsedRootTicks : ℕ) : ℝ) :=
                    Nat.cast_le.mpr htrue_le_el
                  exact le_trans h1 hpi.2.2.2.2.2.2.2.2.2.2.2.1
                exact birth_to_birth_contraction hα_pos pts'
                  (job₂.completedPrefix[i]'hi_lt).ball
                  (job₂.completedPrefix[i]'hi_lt).birthSnapshot
                  (alg4PrefixInputAt pts' job₂.completedPrefix S_after i)
                  hwfi.2.2.1 hwfi.2.2.2.2.1 htrue_ub
              · have hgt : 1 ≤ j - job₂.completedPrefix.length := by omega
                have hlen1 : [newLv].length ≤ j - job₂.completedPrefix.length := by simp; omega
                rw [List.getElem?_eq_none hlen1] at hget; cases hget
          · dsimp only
            rw [if_neg hcl2_neg]
            refine Or.inr ?_
            exact gate_closed_during_build_minus3 hα_pos hα_le hL pts' ball
              job₂.currentResidual job₂.currentResidual
              (r_open := job₂.remainingTicks) (r_now := job₂.remainingTicks) (trueAge := 0)
              hlarge_new hcore_new hr_lb_new le_rfl
              (by rw [Nat.sub_self, Nat.cast_zero]
                  exact div_nonneg (mul_nonneg (sq_nonneg α) (Nat.cast_nonneg _))
                    (by unfold scheduleCStar; norm_num))
              (Nat.zero_le _) (hasNodeAge_refl _)
      · -- Subcase B2a: Gate remains closed (`¬ CanOpenResidualLevel`)
        have hjob3_eq : job₃ = job₂ := by
          rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
          rw [if_neg hcl2_neg, if_neg hnotall]
          unfold residualScheduleStep
          rw [if_neg hopen]
        rw [hjob3_eq]
        have hrem2_pos : 1 ≤ job₂.remainingTicks := by
          by_contra hrem0
          have hr_zero : job₂.remainingTicks = 0 := by omega
          apply hopen
          rw [hr_zero]
          unfold CanOpenResidualLevel scheduleCStar
          simp only [Nat.cast_zero]
          positivity
        refine ⟨hwf2, hjob2_dl, hjob2_rem, fun hr0 => by omega, ?_⟩
        intro _
        refine ⟨fun hrdy => by have := hrdy.1; change job₂.remainingTicks = 0 at this; omega, ?_⟩
        refine ⟨hrem2_pos, ?_, ?_⟩
        · intro j lv hget
          have hj2 : j < job₂.completedPrefix.length := by
            by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
          rw [List.getElem?_eq_getElem hj2] at hget
          injection hget with hget_eq; subst hget_eq
          have hp := hpfx2_props j hj2
          exact ⟨hp.2.2.2.2.2.2.1, hp.2.1, hp.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.1,
            hp.2.2.2.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.2.2.2.1,
            hp.2.2.2.2.2.2.2.2.2.2.2.2.2.1, hp.2.2.2.2.2.2.2.2.2.2.2.2.2.2⟩
        · rw [if_neg hcl2_neg]
          exact Or.inr hopen

/-! ### 3. Full Reachable State Invariant (`ReachableAlg4Inv`) & Trajectory Induction -/

def ReachableAlg4Inv {d : ℕ} {ι : Type}
    (n : ℕ) (mode : Alg4Mode) (α : ℝ) (L D_out : ℕ)
    (st : Alg4State d ι) : Prop :=
  st.WellFormed n mode α L D_out ∧
  ∀ (idx : ℕ) (sn : Alg4ServingNode d ι),
    st.servingNodes[idx]? = some sn →
      sn.birthSnapshot.card ≤ n ∧
      ∀ job : Alg4PendingJob d ι,
        sn.ownedJob = some job →
          Alg4JobSchedInv n α L st.coords (st.servingInputAt idx) job

theorem reachableAlg4Inv_empty {d n : ℕ} (ι : Type) (mode : Alg4Mode) (α : ℝ) (L D_out : ℕ) :
    ReachableAlg4Inv n mode α L D_out (Alg4State.empty d ι) := by
  unfold ReachableAlg4Inv Alg4State.WellFormed ScheduledServingChain.WellFormed
  simp [Alg4State.empty, Alg4State.toScheduledServingChain, servingChainInputAt,
    IsExactLeafAnswer, baselinePairLength, alg4Line12SelectCachedAnswer]

/-- Pre-Line-9 serving-node schedule invariant (holding after Lines 7–8, before Line 9 starts due
jobs at `sn.age = jobStartAge α M`). -/
def PreLine9NodeInv {d : ℕ} {ι : Type}
    (n : ℕ) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_cur : Finset ι)
    (p : Alg4ServingNode d ι × Bool) : Prop :=
  let sn := p.1
  let startAge := jobStartAge α sn.birthSnapshot.card
  TaggedNodeDataWF mode pts S_cur p ∧
  sn.birthSnapshot.card ≤ n ∧
  IsLargeResidualLevel L sn.birthSnapshot.card ∧
  PassesBirthCoreCheck α pts sn.node sn.birthSnapshot ∧
  sn.trueAge ≤ sn.age ∧
  HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
  ((sn.age < startAge ∧ sn.ownedJob = none) ∨
   (sn.age = startAge ∧ sn.ownedJob = none) ∨
   (startAge ≤ sn.age ∧
    ∃ (S_start : Finset ι) (job : Alg4PendingJob d ι),
      (∃ actualStartAge ≤ startAge, HasNodeAge sn.birthSnapshot S_start actualStartAge) ∧
      HasNodeAge S_start S_cur (sn.age - startAge) ∧
      NeedsScheduledReplacement L S_start.card ∧
      sn.ownedJob = some job ∧
      job.deadlineTicks = jobDeadlineTicks α S_start.card ∧
      (sn.age - startAge) + job.remainingTicks = job.deadlineTicks ∧
      job.WellFormed mode α L pts S_cur ∧
      Alg4JobSchedInv n α L pts S_cur job))

/-- Post-Line-9 serving-node schedule invariant (before Line 10 refreshes caches). -/
def PostLine9NodeInv {d : ℕ} {ι : Type}
    (n : ℕ) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_cur : Finset ι)
    (p : Alg4ServingNode d ι × Bool) : Prop :=
  let sn := p.1
  TaggedNodeDataWF mode pts S_cur p ∧
  sn.birthSnapshot.card ≤ n ∧
  sn.toServingNodeState.WellFormed α L pts S_cur ∧
  sn.trueAge ≤ sn.age ∧
  HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
  ∀ job : Alg4PendingJob d ι,
    sn.ownedJob = some job →
      job.WellFormed mode α L pts S_cur ∧
      Alg4JobSchedInv n α L pts S_cur job

theorem installCompletedJobs_preLine9 {d n : ℕ} {ι : Type}
    {pts' : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode}
    {α C : ℝ} {K₀ L D_out : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L) :
    ∀ (nodes26 : List (Alg4ServingNode d ι × Bool))
      (S_cur leaf1 : Finset ι) (leafAns0 : Option (ι × ι)) (leafSq0 : ℝ) (leafTicked : Bool),
      leaf1 = servingChainInputAt pts'
        (nodes26.map (fun p => p.1.toServingNodeState)) S_cur nodes26.length →
      leaf1.card ≤ 6 * L + 1 →
      (leafTicked = false →
        leaf1.card ≤ 6 * L ∧
        IsExactLeafAnswer pts' leaf1 leafAns0 ∧
        leafSq0 = (baselinePairLength pts' leafAns0) ^ 2) →
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes26[idx]? = some p →
        let S_idx := servingChainInputAt pts'
          (nodes26.map (fun q => q.1.toServingNodeState)) S_cur idx
        (∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
          job.IsReadyToInstall →
            job.WellFormed mode α L pts' S_idx ∧
            job.currentResidual.card ≤ 3 * L + 2 ∧
            ∀ lv ∈ job.completedPrefix,
              lv.birthSnapshot.card ≤ n ∧
              (lv.elapsedRootTicks : ℝ) ≤ α * (lv.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ)) ∧
        ((∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job → ¬ job.IsReadyToInstall) →
          PreLine9NodeInv n mode α L pts' S_idx p)) →
      let (nodes78, leaf78, leafAns78, leafSq78, leafCh78, retired78) :=
        alg4Lines7To8InstallCompletedJobs nodes26 leaf1 leafAns0 leafSq0 leafTicked
      leaf78 = servingChainInputAt pts'
        (nodes78.map (fun p => p.1.toServingNodeState)) S_cur nodes78.length ∧
      leaf78.card ≤ 6 * L + 1 ∧
      (leafCh78 = false →
        leaf78.card ≤ 6 * L ∧
        IsExactLeafAnswer pts' leaf78 leafAns78 ∧
        leafSq78 = (baselinePairLength pts' leafAns78) ^ 2) ∧
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes78[idx]? = some p →
        PreLine9NodeInv n mode α L pts'
          (servingChainInputAt pts' (nodes78.map (fun q => q.1.toServingNodeState)) S_cur idx)
          p) ∧
      (1 ≤ D_out → ∀ r ∈ retired78, r.HasBoundedOutdegree D_out)
  | [], S_cur, leaf1, leafAns0, leafSq0, leafTicked, hleaf1, hcard1, hlt, _ => by
      dsimp only [alg4Lines7To8InstallCompletedJobs]
      exact ⟨hleaf1, hcard1, hlt, fun _ _ h => by simp at h, fun _ _ h => by cases h⟩
  | (sn, affected) :: rest, S_cur, leaf1, leafAns0, leafSq0, leafTicked, hleaf1, hcard1, hlt, hinv => by
      dsimp only [alg4Lines7To8InstallCompletedJobs]
      have h0 := hinv 0 (sn, affected) rfl
      rw [List.map_cons, servingChainInputAt_zero] at h0
      have hleaf1_rest : leaf1 = servingChainInputAt pts'
          (rest.map (fun p => p.1.toServingNodeState)) (sn.node.residual pts' S_cur) rest.length := by
        simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf1
      have hinv_rest : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
          rest[idx]? = some p →
          let S_idx := servingChainInputAt pts'
            (rest.map (fun q => q.1.toServingNodeState)) (sn.node.residual pts' S_cur) idx
          (∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
            job.IsReadyToInstall →
              job.WellFormed mode α L pts' S_idx ∧
              job.currentResidual.card ≤ 3 * L + 2 ∧
              ∀ lv ∈ job.completedPrefix,
                lv.birthSnapshot.card ≤ n ∧
                (lv.elapsedRootTicks : ℝ) ≤ α * (lv.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ)) ∧
          ((∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job → ¬ job.IsReadyToInstall) →
            PreLine9NodeInv n mode α L pts' S_idx p) := by
        intro idx p hp
        simpa [List.map_cons, servingChainInputAt_cons_succ] using hinv (idx + 1) p hp
      cases hown : sn.ownedJob with
      | none =>
        dsimp only
        have hpre0 := h0.2 (fun j hj => by rw [hown] at hj; cases hj)
        have ih := installCompletedJobs_preLine9 (D_out := D_out) hα_pos hα_le hL
          rest (sn.node.residual pts' S_cur) leaf1 leafAns0 leafSq0 leafTicked
          hleaf1_rest hcard1 hlt hinv_rest
        rcases h78 : alg4Lines7To8InstallCompletedJobs rest leaf1 leafAns0 leafSq0 leafTicked with
          ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
        rw [h78] at ih
        rcases ih with ⟨hleaf_ih, hcard_ih, hlt_ih, hpre_ih, hret_ih⟩
        refine ⟨?_, hcard_ih, hlt_ih, ?_, hret_ih⟩
        · simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf_ih
        · intro idx p hp
          cases idx with
          | zero =>
            simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
            subst hp
            rw [List.map_cons, servingChainInputAt_zero]
            exact hpre0
          | succ idx =>
            simp only [List.getElem?_cons_succ] at hp
            rw [List.map_cons, servingChainInputAt_cons_succ]
            exact hpre_ih idx p hp
      | some job =>
        dsimp only
        by_cases hrdy : job.IsReadyToInstall
        · rw [if_pos hrdy]
          dsimp only
          have hL1 := cutoff_L_pos hα_pos hα_le hL
          rcases h0.1 job hown hrdy with ⟨hjwf, hjres_le, hjlv⟩
          rcases prefixInputAt_eq_installed_servingInputAt pts' job.completedPrefix S_cur with
            ⟨hinst_in, hinst_end⟩
          refine ⟨?_, by omega, fun hf : true = false => Bool.noConfusion hf, ?_, ?_⟩
          · simp only [List.length_map]
            rw [hinst_end]
            exact hjwf.1.2.1
          · intro idx p hp
            rw [List.getElem?_map] at hp
            cases hget : job.completedPrefix[idx]? with
            | none => rw [hget] at hp; simp at hp
            | some lv =>
              rw [hget] at hp
              simp only [Option.map_some, Option.some.injEq] at hp
              subst hp
              have hj : idx < job.completedPrefix.length := by
                by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
              have hlv_eq : job.completedPrefix[idx]'hj = lv := by
                rw [List.getElem?_eq_getElem hj] at hget; exact Option.some.inj hget
              rw [hinst_in idx (le_of_lt hj)]
              have hlv_wf := (hjwf.2.1 ⟨idx, hj⟩).2
              dsimp only at hlv_wf
              rw [Fin.getElem_fin, hlv_eq] at hlv_wf
              have hlv_mem : lv ∈ job.completedPrefix := hlv_eq ▸ List.getElem_mem hj
              have hlv_rdy : lv.backgroundReady = true :=
                hrdy.2.2 lv.toOpenedJobLevel (by
                  dsimp only [Alg4PendingJob.toPendingReplacementJob]
                  exact List.mem_map_of_mem hlv_mem)
              rcases hlv_wf.2.2.2.2.2.2.2.2.2 hlv_rdy with ⟨hH_eq, hC_eq⟩
              rcases hjlv lv hlv_mem with ⟨hb_le_n, hel_ub⟩
              have hlt_start : lv.elapsedRootTicks < jobStartAge α lv.birthSnapshot.card :=
                installed_age_lt_jobStartAge hα_pos hα_le hL hlv_wf.2.1 hel_ub
              refine ⟨⟨⟨?_, ?_⟩, fun hf : true = false => Bool.noConfusion hf⟩,
                hb_le_n, hlv_wf.2.1, hlv_wf.2.2.1, hlv_wf.2.2.2.1, hlv_wf.2.2.2.2.1,
                Or.inl ⟨hlt_start, rfl⟩⟩
              · dsimp only [installOpenedLevelAsServingNode, RadiusDictState.IsComplete]
                rw [← hH_eq]; exact hlv_wf.2.2.2.2.2.2.2.1
              · dsimp only [installOpenedLevelAsServingNode]
                rw [← hC_eq]; exact hlv_wf.2.2.2.2.2.2.2.2.1
          · intro hD r hr
            rcases List.mem_cons.mp hr with rfl | hr1
            · exact ⟨Nat.zero_le D_out, trivial⟩
            · rcases List.mem_append.mp hr1 with hscan | hnodes
              · rcases List.mem_map.mp hscan with ⟨lv, _, rfl⟩
                exact ⟨Nat.zero_le D_out, trivial⟩
              · rcases List.mem_flatMap.mp hnodes with ⟨s, _, hrs⟩
                exact retireServingNodeRecords_bounded hD s r hrs
        · rw [if_neg hrdy]
          have hpre0 := h0.2 (fun j hj => by rw [hown] at hj; injection hj with hjeq; subst hjeq; exact hrdy)
          have ih := installCompletedJobs_preLine9 (D_out := D_out) hα_pos hα_le hL
            rest (sn.node.residual pts' S_cur) leaf1 leafAns0 leafSq0 leafTicked
            hleaf1_rest hcard1 hlt hinv_rest
          rcases h78 : alg4Lines7To8InstallCompletedJobs rest leaf1 leafAns0 leafSq0 leafTicked with
            ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
          rw [h78] at ih
          rcases ih with ⟨hleaf_ih, hcard_ih, hlt_ih, hpre_ih, hret_ih⟩
          refine ⟨?_, hcard_ih, hlt_ih, ?_, hret_ih⟩
          · simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf_ih
          · intro idx p hp
            cases idx with
            | zero =>
              simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
              subst hp
              rw [List.map_cons, servingChainInputAt_zero]
              exact hpre0
            | succ idx =>
              simp only [List.getElem?_cons_succ] at hp
              rw [List.map_cons, servingChainInputAt_cons_succ]
              exact hpre_ih idx p hp

theorem startDueServingJobsAux_postLine9 {d n : ℕ} {ι : Type}
    {pts' : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode}
    {α C : ℝ} {K₀ L D_out : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L) :
    ∀ (nodes : List (Alg4ServingNode d ι × Bool))
      (S_cur leaf : Finset ι) (leafAns : Option (ι × ι)) (leafSq : ℝ) (leafCh : Bool),
      leaf = servingChainInputAt pts'
        (nodes.map (fun p => p.1.toServingNodeState)) S_cur nodes.length →
      leaf.card ≤ 6 * L + 1 →
      (leafCh = false →
        leaf.card ≤ 6 * L ∧
        IsExactLeafAnswer pts' leaf leafAns ∧
        leafSq = (baselinePairLength pts' leafAns) ^ 2) →
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes[idx]? = some p →
        PreLine9NodeInv n mode α L pts'
          (servingChainInputAt pts' (nodes.map (fun q => q.1.toServingNodeState)) S_cur idx)
          p) →
      let (nodes₁, leaf₁, leafAns₁, leafSq₁, leafCh₁, retired₁) :=
        startDueServingJobsAux pts' α L S_cur nodes leaf leafAns leafSq leafCh
      leaf₁ = servingChainInputAt pts'
        (nodes₁.map (fun p => p.1.toServingNodeState)) S_cur nodes₁.length ∧
      leaf₁.card ≤ 6 * L + 1 ∧
      (leafCh₁ = false →
        leaf₁.card ≤ 6 * L ∧
        IsExactLeafAnswer pts' leaf₁ leafAns₁ ∧
        leafSq₁ = (baselinePairLength pts' leafAns₁) ^ 2) ∧
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes₁[idx]? = some p →
        PostLine9NodeInv n mode α L pts'
          (servingChainInputAt pts' (nodes₁.map (fun q => q.1.toServingNodeState)) S_cur idx)
          p) ∧
      (1 ≤ D_out → ∀ r ∈ retired₁, r.HasBoundedOutdegree D_out)
  | [], S_cur, leaf, leafAns, leafSq, leafCh, hleaf, hcard, hlch, _ => by
      dsimp only [startDueServingJobsAux]
      exact ⟨hleaf, hcard, hlch, fun _ _ h => by simp at h, fun _ _ h => by cases h⟩
  | (sn, needRefresh) :: rest, S_cur, leaf, leafAns, leafSq, leafCh, hleaf, hcard, hlch, hpre => by
      dsimp only [startDueServingJobsAux]
      have h0 := hpre 0 (sn, needRefresh) rfl
      rw [List.map_cons, servingChainInputAt_zero] at h0
      dsimp only [PreLine9NodeInv] at h0
      rcases h0 with ⟨htag0, hb_le0, hlarge0, hcore0, hage_le0, hage0, hsched_cases0⟩
      have hleaf_rest : leaf = servingChainInputAt pts'
          (rest.map (fun p => p.1.toServingNodeState)) (sn.node.residual pts' S_cur) rest.length := by
        simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf
      have hpre_rest : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
          rest[idx]? = some p →
          PreLine9NodeInv n mode α L pts'
            (servingChainInputAt pts' (rest.map (fun q => q.1.toServingNodeState))
              (sn.node.residual pts' S_cur) idx)
            p := by
        intro idx p hp
        simpa [List.map_cons, servingChainInputAt_cons_succ] using hpre (idx + 1) p hp
      by_cases hdue : sn.ownedJob.isNone ∧ jobStartAge α sn.birthSnapshot.card ≤ sn.age
      · rw [if_pos hdue]
        have hage_eq_start : sn.age = jobStartAge α sn.birthSnapshot.card := by
          rcases hsched_cases0 with ⟨hlt, _⟩ | ⟨heq, _⟩ | ⟨_, _, job, _, _, _, hown, _⟩
          · omega
          · exact heq
          · have := hdue.1; rw [hown] at this; simp at this
        unfold scheduleJobStart
        by_cases hm_gt : 4 * L < S_cur.card
        · rw [if_pos hm_gt]
          dsimp only
          have hneeds : NeedsScheduledReplacement L S_cur.card := hm_gt
          have hinit := alg4JobSchedInv_init (n := n) hα_pos hα_le hL pts' S_cur hneeds
          have ih := startDueServingJobsAux_postLine9 (D_out := D_out) hα_pos hα_le hL
            rest (sn.node.residual pts' S_cur) leaf leafAns leafSq leafCh
            hleaf_rest hcard hlch hpre_rest
          rcases hrec : startDueServingJobsAux pts' α L (sn.node.residual pts' S_cur)
              rest leaf leafAns leafSq leafCh with
            ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
          rw [hrec] at ih
          rcases ih with ⟨hleaf_ih, hcard_ih, hlch_ih, hpost_ih, hret_ih⟩
          refine ⟨?_, hcard_ih, hlch_ih, ?_, hret_ih⟩
          · simpa [List.map_cons, servingChainInputAt_cons_succ,
              Alg4ServingNode.toServingNodeState] using hleaf_ih
          · intro idx p hp
            cases idx with
            | zero =>
              simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
              subst hp
              rw [List.map_cons, servingChainInputAt_zero]
              refine ⟨htag0, hb_le0, ?_, hage_le0, hage0, ?_⟩
              · refine ⟨hlarge0, hcore0, ⟨sn.trueAge, hage_le0, hage0⟩, ?_⟩
                dsimp only [Alg4ServingNode.toServingNodeState]
                rw [if_neg (by omega)]
                refine ⟨S_cur, ⟨sn.trueAge, by omega, hage0⟩,
                  by rw [hage_eq_start, Nat.sub_self]; exact hasNodeAge_refl S_cur,
                  hneeds, (Alg4PendingJob.init α S_cur).toPendingReplacementJob,
                  rfl, rfl, by rw [hage_eq_start, Nat.sub_self, Nat.zero_add]; rfl,
                  (hinit.2.1 mode).1⟩
              · intro job hjob
                dsimp only at hjob
                injection hjob with hjob_eq; subst hjob_eq
                exact ⟨hinit.2.1 mode, hinit.2.2⟩
            | succ idx =>
              simp only [List.getElem?_cons_succ] at hp
              rw [List.map_cons, servingChainInputAt_cons_succ]
              simpa [Alg4ServingNode.toServingNodeState] using hpost_ih idx p hp
        · rw [if_neg hm_gt]
          dsimp only
          refine ⟨by simp [servingChainInputAt], by omega,
            fun hf : true = false => Bool.noConfusion hf,
            fun _ _ h => by simp at h, ?_⟩
          intro hD r hr
          rcases List.mem_cons.mp hr with rfl | htl
          · exact ⟨Nat.zero_le D_out, trivial⟩
          · rcases List.mem_flatMap.mp htl with ⟨s, _, hrs⟩
            exact retireServingNodeRecords_bounded hD s r hrs
      · rw [if_neg hdue]
        have hpost0 : PostLine9NodeInv n mode α L pts' S_cur (sn, needRefresh) := by
          rcases hsched_cases0 with ⟨hlt, hown_n⟩ | ⟨heq, hown_n⟩ |
            ⟨hge, S_start, job, hstart_age, hage_after, hneeds, hown_j, hdl, hclk, hjwf, hjsched⟩
          · refine ⟨htag0, hb_le0, ⟨hlarge0, hcore0, ⟨sn.trueAge, hage_le0, hage0⟩, ?_⟩,
              hage_le0, hage0, fun j hj => by rw [hown_n] at hj; cases hj⟩
            dsimp only [Alg4ServingNode.toServingNodeState]
            rw [if_pos hlt, hown_n]; rfl
          · exfalso
            apply hdue
            exact ⟨by simp [hown_n], by omega⟩
          · refine ⟨htag0, hb_le0, ⟨hlarge0, hcore0, ⟨sn.trueAge, hage_le0, hage0⟩, ?_⟩,
              hage_le0, hage0, ?_⟩
            · dsimp only [Alg4ServingNode.toServingNodeState]
              rw [if_neg (by omega)]
              exact ⟨S_start, hstart_age, hage_after, hneeds,
                job.toPendingReplacementJob, by simp [hown_j], hdl, hclk, hjwf.1⟩
            · intro j hj
              rw [hown_j] at hj; injection hj with hj_eq; subst hj_eq
              exact ⟨hjwf, hjsched⟩
        have ih := startDueServingJobsAux_postLine9 (D_out := D_out) hα_pos hα_le hL
          rest (sn.node.residual pts' S_cur) leaf leafAns leafSq leafCh
          hleaf_rest hcard hlch hpre_rest
        rcases hrec : startDueServingJobsAux pts' α L (sn.node.residual pts' S_cur)
            rest leaf leafAns leafSq leafCh with
          ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
        rw [hrec] at ih
        rcases ih with ⟨hleaf_ih, hcard_ih, hlch_ih, hpost_ih, hret_ih⟩
        refine ⟨?_, hcard_ih, hlch_ih, ?_, hret_ih⟩
        · simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf_ih
        · intro idx p hp
          cases idx with
          | zero =>
            simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
            subst hp
            rw [List.map_cons, servingChainInputAt_zero]
            exact hpost0
          | succ idx =>
            simp only [List.getElem?_cons_succ] at hp
            rw [List.map_cons, servingChainInputAt_cons_succ]
            exact hpost_ih idx p hp

theorem reachableAlg4Inv_step {d n : ℕ} {ι : Type}
    {mode : Alg4Mode} {α C : ℝ} {K₀ L reclaimMult D_out : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (hD_out : 1 ≤ D_out)
    {st : Alg4State d ι} {upd : Alg4PointUpdate d ι} {choices : Alg4StepChoices d ι}
    (hinv : ReachableAlg4Inv n mode α L D_out st)
    (hupd : IsValidAlg4PointUpdate n st upd)
    (heq11 : Alg4StepSatisfiesEq11Completion mode α L st upd choices)
    (hextra_ret : ∀ r ∈ choices.stepExtraRetired, r.HasBoundedOutdegree D_out) :
    ReachableAlg4Inv n mode α L D_out (alg4Step mode α L reclaimMult st upd choices).1 := by
  have hL_pos := cutoff_L_pos hα_pos hα_le hL
  rcases hinv with ⟨hwf, hreach_nodes⟩
  rcases hwf with ⟨hact_le_n, hchain_wf, hleaf_le_6L, hleaf_sq, hnodes_wf, _, hret_q_wf, _⟩
  set P' := applyAlg4PointSetUpdate st.activeSet upd
  set pts' := updateAlg4Coords st.coords upd
  have hact_upd := validAlg4PointUpdate_activeSet hupd
  have hP'_le_n : P'.card ≤ n := hact_upd.2.1 hact_le_n
  have hpts_act : ∀ x ∈ st.activeSet, pts' x = st.coords x :=
    fun x hx => updateAlg4Coords_eq_on_liveRetainedIds hupd (activeSet_subset_liveRetainedIds st hx)
  let rootEv : PoolUpdateEvent ι := alg4RootEvent upd
  have hroot_ev : IsValidPoolUpdateEvent st.activeSet P' rootEv := by
    cases upd with
    | insert p pt => exact ⟨fun hp => hupd.1 (activeSet_subset_liveRetainedIds st hp), rfl⟩
    | delete p => exact ⟨hupd, rfl⟩
  have hl1_in : ∀ (idx : ℕ) (sn : Alg4ServingNode d ι),
      st.servingNodes[idx]? = some sn →
      let S_cur := servingChainInputAt st.coords
        (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet idx
      sn.trueAge ≤ sn.age ∧
      HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
      ServingNodePreRefreshWF mode st.coords S_cur sn ∧
      ServingNodeCacheWF mode st.coords S_cur sn := by
    intro idx sn hget
    have hlt : idx < st.servingNodes.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
    have hsn_eq : st.servingNodes[idx]'hlt = sn := by
      rw [List.getElem?_eq_getElem hlt] at hget; exact Option.some.inj hget
    have hwfi := hnodes_wf ⟨idx, hlt⟩
    dsimp only at hwfi
    rw [Fin.getElem_fin, hsn_eq] at hwfi
    rcases servingNodePreRefresh_and_cache_of_wellFormed hwfi with ⟨hpre, hcache⟩
    exact ⟨hwfi.2.1, hwfi.2.2.1, hpre, hcache⟩
  have hl1 := alg4Line1Aux_spec st.coords pts' mode st.servingNodes st.activeSet P' (some rootEv)
    choices.servingRouteQueries choices.servingRadiusMaxHints hpts_act hroot_ev hl1_in
  rcases hl1_eq : alg4Line1Aux pts' mode (some rootEv) st.servingNodes
      choices.servingRouteQueries choices.servingRadiusMaxHints with ⟨nodesLine1, leafEv⟩
  rw [hl1_eq] at hl1
  rcases hl1 with ⟨hLen1, _, hleaf_ev, hidx1⟩
  have hleaf_eq : st.terminalLeaf = servingChainInputAt st.coords
      (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet
      st.servingNodes.length := by
    simpa [Alg4State.toScheduledServingChain] using hchain_wf.2.1
  rw [← hleaf_eq] at hleaf_ev
  let leafLine1 : Finset ι := applyLeafPoolEvent st.terminalLeaf leafEv
  have hl1_apply_eq :
      alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
        choices.servingRouteQueries choices.servingRadiusMaxHints =
        (nodesLine1, leafLine1, leafEv.isClockTick) := by
    have h := alg4Line1ApplyToServingChain_eq pts' mode st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
    dsimp only [rootEv] at hl1_eq
    rw [hl1_eq] at h
    dsimp only at h
    exact h
  have hleafLine1_eq : leafLine1 = servingChainInputAt pts'
      (nodesLine1.map (fun p => p.1.toServingNodeState)) P' nodesLine1.length := by
    cases leafEv with
    | externalInsert p => exact hleaf_ev.2.symm
    | externalDelete p => exact hleaf_ev.2.symm
    | virtualValueDelete => exact hleaf_ev.symm
    | unaffected => exact hleaf_ev.symm
  have hleafLine1_card : leafLine1.card ≤ 6 * L + 1 := by
    cases leafEv with
    | externalInsert p =>
      have := Finset.card_insert_le p st.terminalLeaf
      dsimp only [leafLine1, applyLeafPoolEvent]; omega
    | externalDelete p =>
      have := Finset.card_erase_le (s := st.terminalLeaf) (a := p)
      dsimp only [leafLine1, applyLeafPoolEvent]; omega
    | virtualValueDelete => dsimp only [leafLine1, applyLeafPoolEvent]; omega
    | unaffected => dsimp only [leafLine1, applyLeafPoolEvent]; omega
  have hleafTick_false : leafEv.isClockTick = false →
      leafLine1.card ≤ 6 * L ∧
      IsExactLeafAnswer pts' leafLine1 st.terminalLeafAnswer ∧
      st.terminalLeafDistSq = (baselinePairLength pts' st.terminalLeafAnswer) ^ 2 := by
    intro hltf
    have hl_same : leafLine1 = st.terminalLeaf := by
      cases leafEv <;> simp [PoolUpdateEvent.isClockTick] at hltf <;> rfl
    rw [hl_same]
    have hsub_leaf : st.terminalLeaf ⊆ st.activeSet := by
      rw [hleaf_eq]; exact servingChainInputAt_subset _ _ _ _
    have hpts_leaf : ∀ x ∈ st.terminalLeaf, st.coords x = pts' x :=
      fun x hx => (hpts_act x (hsub_leaf hx)).symm
    have hex0 : IsExactLeafAnswer st.coords st.terminalLeaf st.terminalLeafAnswer :=
      hchain_wf.2.2
    exact ⟨hleaf_le_6L,
      (isExactLeafAnswer_congr st.terminalLeafAnswer hpts_leaf).mp hex0,
      hleaf_sq.trans (by rw [baselinePairLength_congr_exact hex0 hpts_leaf])⟩
  -- Unpack Equation (11) on `nodes26`
  rcases alg4Lines2To6StepPendingJobs_basic pts' mode α L nodesLine1 P'
      choices.pendingJobChoices with ⟨hLen26, hballs26, hidx26⟩
  set nodes26 := alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
  have heq11_26 : ∀ p ∈ nodes26, ∀ job : Alg4PendingJob d ι,
      p.1.ownedJob = some job →
      ∀ lv ∈ job.completedPrefix,
        maxLevelBuildTicks α lv.birthSnapshot.card ≤ lv.elapsedRootTicks →
          lv.backgroundReady = true := by
    unfold Alg4StepSatisfiesEq11Completion at heq11
    dsimp only at heq11
    rw [hl1_apply_eq] at heq11
    exact heq11
  have hleafLine1_26 : leafLine1 = servingChainInputAt pts'
      (nodes26.map (fun p => p.1.toServingNodeState)) P' nodes26.length := by
    rw [hleafLine1_eq, ← hLen26]
    symm
    apply servingChainInputAt_eq_of_take_balls
    rw [List.map_take, List.map_take, hballs26]
  -- Establish the Pre-Line-7/8 condition on `nodes26`
  have h26_pre : ∀ (idx : ℕ) (p26 : Alg4ServingNode d ι × Bool),
      nodes26[idx]? = some p26 →
      let S_idx := servingChainInputAt pts'
        (nodes26.map (fun q => q.1.toServingNodeState)) P' idx
      (∀ job : Alg4PendingJob d ι, p26.1.ownedJob = some job →
        job.IsReadyToInstall →
          job.WellFormed mode α L pts' S_idx ∧
          job.currentResidual.card ≤ 3 * L + 2 ∧
          ∀ lv ∈ job.completedPrefix,
            lv.birthSnapshot.card ≤ n ∧
            (lv.elapsedRootTicks : ℝ) ≤ α * (lv.birthSnapshot.card : ℝ) / (scheduleCStar : ℝ)) ∧
      ((∀ job : Alg4PendingJob d ι, p26.1.ownedJob = some job → ¬ job.IsReadyToInstall) →
        PreLine9NodeInv n mode α L pts' S_idx p26) := by
    intro idx p26 hp26
    have hi_lt26 : idx < nodes26.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hp26; cases hp26
    have hi_lt1 : idx < nodesLine1.length := by omega
    have hi_lt0 : idx < st.servingNodes.length := by omega
    have hp26_mem : p26 ∈ nodes26 := by
      have : nodes26[idx]'hi_lt26 = p26 := by
        rw [List.getElem?_eq_getElem hi_lt26] at hp26; exact Option.some.inj hp26
      rw [← this]; exact List.getElem_mem hi_lt26
    have hS_eq : servingChainInputAt pts'
        (nodes26.map (fun q => q.1.toServingNodeState)) P' idx =
        servingChainInputAt pts'
        (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx := by
      apply servingChainInputAt_eq_of_take_balls
      rw [List.map_take, List.map_take, hballs26]
    rcases hidx1 idx (st.servingNodes[idx]'hi_lt0) (nodesLine1[idx]'hi_lt1)
      (List.getElem?_eq_getElem hi_lt0) (List.getElem?_eq_getElem hi_lt1) with
      ⟨hev1, hticks1, hbirth1, hnode1, hown1, htage1, hage1, htle1, hhna1, hpre1, hfalse1⟩
    have hi26 := hidx26 idx (nodesLine1[idx]'hi_lt1) p26
      (List.getElem?_eq_getElem hi_lt1) hp26
    have hwfi := hnodes_wf ⟨idx, hi_lt0⟩
    dsimp only at hwfi
    rw [Fin.getElem_fin] at hwfi
    rcases hreach_nodes idx (st.servingNodes[idx]'hi_lt0) (List.getElem?_eq_getElem hi_lt0) with
      ⟨hb_le_n0, hsched_own0⟩
    have hpts_B_sn : ∀ x ∈ (st.servingNodes[idx]'hi_lt0).birthSnapshot,
        st.coords x = pts' x := by
      intro x hx
      have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi_lt0)
      exact (updateAlg4Coords_eq_on_liveRetainedIds hupd (hsn_live.1 hx)).symm
    have hpts_S : ∀ x ∈ st.servingInputAt idx, pts' x = st.coords x :=
      fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
    have hlarge_p26 : IsLargeResidualLevel L p26.1.birthSnapshot.card := by
      rw [hi26.2.1, hbirth1]; exact hwfi.1.1
    have hcore_p26 : PassesBirthCoreCheck α pts' p26.1.node p26.1.birthSnapshot := by
      rw [hi26.2.1, hbirth1, hi26.2.2.1, hnode1]
      exact (passesBirthCoreCheck_congr α _ hpts_B_sn).mp hwfi.1.2.1
    have htag_p26 : TaggedNodeDataWF mode pts'
        (servingChainInputAt pts' (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx) p26 := by
      refine ⟨⟨?_, ?_⟩, ?_⟩
      · unfold RadiusDictState.IsComplete
        rw [hi26.2.2.1, hi26.2.2.2.2.2.1]; exact hpre1.1
      · rw [hi26.2.2.1, hi26.2.2.2.2.2.2.1]; exact hpre1.2
      · intro hp2f
        rw [hi26.1] at hp2f
        rw [hi26.2.2.2.2.2.2.2.2.2.2.2.1 hp2f]
        exact (hfalse1 hp2f).2.2
    have hS_after_le_n : (servingChainInputAt pts'
        (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx).card ≤ n :=
      le_trans (Finset.card_le_card (servingChainInputAt_subset _ _ _ _)) hP'_le_n
    dsimp only
    rw [hS_eq]
    -- Split on whether `ev1` is a clock tick and whether `sn0` owned a job
    set sn0 := st.servingNodes[idx]'hi_lt0
    set startAge := jobStartAge α sn0.birthSnapshot.card
    have hstart_p26 : jobStartAge α p26.1.birthSnapshot.card = startAge := by
      rw [hi26.2.1, hbirth1]
    have hsched_sn0 := hwfi.1.2.2.2
    dsimp only [Alg4ServingNode.toServingNodeState] at hsched_sn0
    by_cases hlt_age0 : sn0.age < startAge
    · -- `sn0.age < startAge`, so `sn0.ownedJob = none`
      rw [if_pos hlt_age0] at hsched_sn0
      have hown0_none : sn0.ownedJob = none := by
        cases h : sn0.ownedJob with
        | none => rfl
        | some j => rw [h] at hsched_sn0; simp at hsched_sn0
      have hp26_own_none : p26.1.ownedJob = none := by
        by_cases hct : (nodesLine1[idx]'hi_lt1).2.isClockTick = true
        · have hstep := hi26.2.2.2.2.2.2.2.2.2.2.2.2 hct
          rw [hown1, hown0_none] at hstep
          rw [hstep, hown1, hown0_none]
        · have hctf : (nodesLine1[idx]'hi_lt1).2.isClockTick = false := Bool.eq_false_iff.mpr hct
          rw [hi26.2.2.2.2.2.2.2.2.2.2.2.1 hctf, hown1, hown0_none]
      refine ⟨fun j hj _ => (by rw [hp26_own_none] at hj; cases hj), ?_⟩
      intro _
      refine ⟨htag_p26, by rw [hi26.2.1, hbirth1]; exact hb_le_n0,
        hlarge_p26, hcore_p26,
        by rw [hi26.2.2.2.1, hi26.2.2.2.2.1]; exact htle1,
        by rw [hi26.2.1, hi26.2.2.2.1]; exact hhna1, ?_⟩
      rw [hstart_p26, hi26.2.2.2.2.1, hage1]
      have hle_start : sn0.age + (nodesLine1[idx]'hi_lt1).2.ticks ≤ startAge := by omega
      by_cases hlt_new : sn0.age + (nodesLine1[idx]'hi_lt1).2.ticks < startAge
      · exact Or.inl ⟨hlt_new, hp26_own_none⟩
      · exact Or.inr (Or.inl ⟨by omega, hp26_own_none⟩)
    · -- `startAge ≤ sn0.age`, so `sn0` already owns a scheduled job `job0`
      rw [if_neg hlt_age0] at hsched_sn0
      rcases hsched_sn0 with ⟨S_start, hstart_age, hage_after0, hneeds_start,
        pjob0, hpjob0_eq, hdl0, hclk0, _⟩
      cases hown0_eq : sn0.ownedJob with
      | none => rw [hown0_eq] at hpjob0_eq; simp at hpjob0_eq
      | some job0 =>
        rw [hown0_eq] at hpjob0_eq
        simp only [Option.map_some, Option.some.injEq] at hpjob0_eq
        subst hpjob0_eq
        dsimp only [Alg4PendingJob.toPendingReplacementJob] at hdl0 hclk0
        have hjwf0 : job0.WellFormed mode α L st.coords (st.servingInputAt idx) := by
          have h9 := hwfi.2.2.2.2.2.2.2.2
          rw [hown0_eq] at h9; exact h9
        have hjsched0 : Alg4JobSchedInv n α L st.coords (st.servingInputAt idx) job0 :=
          hsched_own0 job0 hown0_eq
        by_cases hct : (nodesLine1[idx]'hi_lt1).2.isClockTick = true
        · -- Clock tick on `sn0`: `job0` steps to `job₃`
          have hstep := hi26.2.2.2.2.2.2.2.2.2.2.2.2 hct
          rw [hown1, hown0_eq] at hstep
          dsimp only at hstep
          set jc := (choices.pendingJobChoices.drop idx).head?.getD
            { prefixRouteQueries := [], prefixRouteMaxHints := [], prefixBudgetSteps := [],
              openSampledCenter := .infeasible, openFallbackBirthId := none, leafHint := none }
          set job₃ := alg4Line5LateOpeningGate pts' mode α L
            (alg4Line4AdvanceClockAndBuild pts' mode
              (alg4Line3RouteThroughPrefix pts' mode job0 (nodesLine1[idx]'hi_lt1).2
                (servingChainInputAt pts' (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx) jc)
              (servingChainInputAt pts' (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx)
              jc.prefixBudgetSteps) jc
          have hp26_own : p26.1.ownedJob = some job₃ := by rw [hstep]
          have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi_lt0)
          have hpts_B : ∀ lv ∈ job0.completedPrefix, ∀ x ∈ lv.birthSnapshot,
              pts' x = st.coords x :=
            fun lv hlv x hx =>
              updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job0 hown0_eq).2 lv hlv).1 hx)
          have heq11_j3 : ∀ lv ∈ job₃.completedPrefix,
              maxLevelBuildTicks α lv.birthSnapshot.card ≤ lv.elapsedRootTicks →
                lv.backgroundReady = true :=
            heq11_26 p26 hp26_mem job₃ hp26_own
          rcases stepSinglePendingJob_sched hα_pos hα_le hL jc hS_after_le_n
              hpts_S hpts_B hev1 hjwf0 hjsched0 heq11_j3 with
            ⟨hwf3, hdl3, hrem3, hwhen0, hwhen_pos⟩
          refine ⟨?_, ?_⟩
          · intro j hj hrdy_j
            rw [hp26_own] at hj; injection hj with hj_eq; subst hj_eq
            have hr0 : job₃.remainingTicks = 0 := hrdy_j.1
            rcases hwhen0 hr0 with ⟨_, hres_le, hlv_b⟩
            exact ⟨hwf3, hres_le, hlv_b⟩
          · intro hnot_rdy
            have hnr3 : ¬ job₃.IsReadyToInstall := hnot_rdy job₃ hp26_own
            have hrem3_pos : 1 ≤ job₃.remainingTicks := by
              by_contra h0
              have hz : job₃.remainingTicks = 0 := by omega
              exact hnr3 (hwhen0 hz).1
            have hsched3 := (hwhen_pos hrem3_pos).2
            have hticks_eq1 : (nodesLine1[idx]'hi_lt1).2.ticks = 1 := by
              unfold PoolUpdateEvent.ticks; rw [if_pos hct]
            have hage_p26 : p26.1.age = sn0.age + 1 := by
              rw [hi26.2.2.2.2.1, hage1, hticks_eq1]
            have hage_after' : HasNodeAge S_start
                (servingChainInputAt pts' (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx)
                (p26.1.age - startAge) := by
              have hstep_age := hasNodeAge_of_validPoolUpdateEvent hage_after0 hev1
              rw [hticks_eq1] at hstep_age
              have heq_sub : sn0.age - startAge + 1 = p26.1.age - startAge := by omega
              rwa [heq_sub] at hstep_age
            have hrem0_pos : 1 ≤ job0.remainingTicks := hjsched0.1
            have hclk3 : (p26.1.age - startAge) + job₃.remainingTicks = job₃.deadlineTicks := by
              rw [hdl3, hrem3]
              omega
            refine ⟨htag_p26, by rw [hi26.2.1, hbirth1]; exact hb_le_n0,
              hlarge_p26, hcore_p26,
              by rw [hi26.2.2.2.1, hi26.2.2.2.2.1]; exact htle1,
              by rw [hi26.2.1, hi26.2.2.2.1]; exact hhna1, ?_⟩
            rw [hstart_p26]
            refine Or.inr (Or.inr ⟨by omega, S_start, job₃,
              by rw [hi26.2.1, hbirth1]; exact hstart_age, hage_after',
              hneeds_start, hp26_own, hdl3.trans hdl0, hclk3, hwf3, hsched3⟩)
        · -- Unaffected step on `sn0`: `p26.1 = sn0` and `S_after = S_before`
          have hctf : (nodesLine1[idx]'hi_lt1).2.isClockTick = false := Bool.eq_false_iff.mpr hct
          have hp26_eq_sn0 : p26.1 = sn0 :=
            (hi26.2.2.2.2.2.2.2.2.2.2.2.1 hctf).trans (hfalse1 hctf).1
          have hS_same : servingChainInputAt pts'
              (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx =
              st.servingInputAt idx := (hfalse1 hctf).2.1
          have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi_lt0)
          have hpts_B : ∀ lv ∈ job0.completedPrefix, ∀ x ∈ lv.birthSnapshot,
              pts' x = st.coords x :=
            fun lv hlv x hx =>
              updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job0 hown0_eq).2 lv hlv).1 hx)
          have hjwf0' : job0.WellFormed mode α L pts' (st.servingInputAt idx) := by
            have hdwf0' := pendingJobDataWF_congr (pendingJobDataWF_of_wellFormed hjwf0) hpts_S hpts_B
            refine ⟨⟨hjwf0.1.1, hdwf0'.1, ?_⟩, ?_, hdwf0'.2.2⟩
            · intro lv hlv
              rcases List.mem_map.mp hlv with ⟨alv, halv, rfl⟩
              rcases List.mem_iff_getElem.mp halv with ⟨j, hj, rfl⟩
              have hjw := hdwf0'.2.1 ⟨j, hj⟩
              rw [Fin.getElem_fin] at hjw
              exact ⟨hjw.2.1, hjw.2.2.1⟩
            · intro j
              exact ⟨(hjwf0.2.1 j).1, hdwf0'.2.1 j⟩
          have hjsched0' : Alg4JobSchedInv n α L pts' (st.servingInputAt idx) job0 :=
            alg4JobSchedInv_congr hjsched0 hpts_S
          have hrem0_pos : 1 ≤ job0.remainingTicks := hjsched0.1
          refine ⟨?_, ?_⟩
          · intro j hj hrdy_j
            rw [hp26_eq_sn0, hown0_eq] at hj; injection hj with hj_eq; subst hj_eq
            have : job0.remainingTicks = 0 := hrdy_j.1
            omega
          · intro _
            rw [hS_same]
            refine ⟨hS_same ▸ htag_p26, by rw [hp26_eq_sn0]; exact hb_le_n0,
              hlarge_p26, hcore_p26,
              by rw [hp26_eq_sn0]; exact hwfi.2.1,
              by rw [hp26_eq_sn0]; exact hwfi.2.2.1, ?_⟩
            rw [hstart_p26, hp26_eq_sn0]
            exact Or.inr (Or.inr ⟨by omega, S_start, job0, hstart_age, hage_after0,
              hneeds_start, hown0_eq, hdl0, hclk0, hjwf0', hjsched0'⟩)
  -- Lines 7–8
  have h78 := installCompletedJobs_preLine9 (D_out := D_out) hα_pos hα_le hL
    nodes26 P' leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick
    hleafLine1_26 hleafLine1_card hleafTick_false h26_pre
  rcases h78_eq : alg4Lines7To8InstallCompletedJobs nodes26
      leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick with
    ⟨nodes78, leaf78, leafAns78, leafSq78, leafCh78, retired78⟩
  rw [h78_eq] at h78
  rcases h78 with ⟨hleaf78, hcard78, hlch78, hpre78, hret78⟩
  -- Line 9: `startDueServingJobsAux` + optional oversized-leaf rebuild
  have hs9 := startDueServingJobsAux_postLine9 (D_out := D_out) hα_pos hα_le hL
    nodes78 P' leaf78 leafAns78 leafSq78 leafCh78 hleaf78 hcard78 hlch78 hpre78
  rcases hs9_eq : startDueServingJobsAux pts' α L P' nodes78 leaf78 leafAns78 leafSq78 leafCh78 with
    ⟨nodes9_due, leaf9_due, leafAns9_due, leafSq9_due, leafCh9_due, retired9_due⟩
  rw [hs9_eq] at hs9
  rcases hs9 with ⟨hleaf9_due, hcard9_due, hlch9_due, hpost9_due, hret9_due⟩
  -- Complete `alg4Line9StartDueJobsAndHandleLeaves`
  have h9_full :
      let (nodes9, finalLeaf, finalLeafAns, finalLeafSq, retiredDue) :=
        alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
          nodes78 leaf78 leafAns78 leafSq78 leafCh78
          choices.leafRebuildChoices choices.terminalLeafHint
      finalLeaf = servingChainInputAt pts'
        (nodes9.map (fun p => p.1.toServingNodeState)) P' nodes9.length ∧
      finalLeaf.card ≤ 6 * L ∧
      IsExactLeafAnswer pts' finalLeaf finalLeafAns ∧
      finalLeafSq = (baselinePairLength pts' finalLeafAns) ^ 2 ∧
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes9[idx]? = some p →
        PostLine9NodeInv n mode α L pts'
          (servingChainInputAt pts' (nodes9.map (fun q => q.1.toServingNodeState)) P' idx)
          p) ∧
      (∀ r ∈ retiredDue, r.HasBoundedOutdegree D_out) := by
    dsimp only [alg4Line9StartDueJobsAndHandleLeaves]
    rw [hs9_eq]
    dsimp only
    by_cases hgt : 6 * L < leaf9_due.card
    · rw [if_pos hgt]
      have hreb := rebuildOversizedLeafAux_fuel (pts' := pts') (mode := mode)
        hα_pos hα_le hL_pos leaf9_due.card leaf9_due choices.leafRebuildChoices le_rfl
      rcases hreb_eq : rebuildOversizedLeafAux pts' mode α L leaf9_due.card leaf9_due
          choices.leafRebuildChoices with ⟨rebuiltNodes, finalLeaf⟩
      rw [hreb_eq] at hreb
      rcases hreb with ⟨hfin_sz, hfin_eq, _, _, htag_reb, hp_reb⟩
      have hex := computeExactLeafAnswer_spec pts' finalLeaf choices.terminalLeafHint
      rcases servingChainInputAt_append pts'
          (nodes9_due.map (fun p => p.1.toServingNodeState))
          (rebuiltNodes.map (fun p => p.1.toServingNodeState)) P' with
        ⟨happ_left, happ_right⟩
      have hleaf9_le_n : leaf9_due.card ≤ n := by
        have hsub : leaf9_due ⊆ P' := by rw [hleaf9_due]; exact servingChainInputAt_subset _ _ _ _
        exact le_trans (Finset.card_le_card hsub) hP'_le_n
      dsimp only
      refine ⟨?_, by unfold IsResidualLeafSize at hfin_sz; omega, hex.1, hex.2, ?_, ?_⟩
      · rw [List.map_append, List.length_append]
        have hlen1 : (nodes9_due.map (fun p => p.1.toServingNodeState)).length = nodes9_due.length := by simp
        have hlen2 : (rebuiltNodes.map (fun p => p.1.toServingNodeState)).length = rebuiltNodes.length := by simp
        rw [← hlen1, ← hlen2, happ_right, hlen1, ← hleaf9_due, hlen2]
        exact hfin_eq
      · intro idx p hp
        rw [List.map_append]
        by_cases hlt_idx : idx < nodes9_due.length
        · rw [List.getElem?_append_left hlt_idx] at hp
          have hle_map : idx ≤ (nodes9_due.map (fun q => q.1.toServingNodeState)).length := by simp; omega
          rw [happ_left idx hle_map]
          exact hpost9_due idx p hp
        · have hge : nodes9_due.length ≤ idx := Nat.le_of_not_lt hlt_idx
          rw [List.getElem?_append_right hge] at hp
          have heq_idx : idx =
              (nodes9_due.map (fun q => q.1.toServingNodeState)).length + (idx - nodes9_due.length) := by
            simp; omega
          rw [heq_idx, happ_right]
          simp only [List.length_map, ← hleaf9_due]
          set j := idx - nodes9_due.length
          have hj_lt : j < rebuiltNodes.length := by
            by_contra hge_j; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge_j)] at hp; cases hp
          have hp_mem : p ∈ rebuiltNodes := by
            have : rebuiltNodes[j]'hj_lt = p := by
              rw [List.getElem?_eq_getElem hj_lt] at hp; exact Option.some.inj hp
            rw [← this]; exact List.getElem_mem hj_lt
          have htag_j := htag_reb j p hp
          rcases hp_reb p hp_mem with ⟨_, hlarge_p, hb_le_leaf, hcore_p, ht0, ha0, hown_n, hrd_c, _⟩
          have hS_eq_birth : p.1.birthSnapshot =
              servingChainInputAt pts' (rebuiltNodes.map (fun q => q.1.toServingNodeState)) leaf9_due j :=
            hrd_c.1.symm.trans htag_j.1.1.1
          have hstart_ge2 := jobStartAge_ge_two hα_pos hα_le hL hlarge_p
          refine ⟨htag_j, le_trans hb_le_leaf hleaf9_le_n, ?_,
            by rw [ht0, ha0], ?_,
            fun job hjob => by rw [hown_n] at hjob; cases hjob⟩
          · refine ⟨hlarge_p, hcore_p, ⟨0, Nat.zero_le _, ?_⟩, ?_⟩
            · rw [← hS_eq_birth]; exact hasNodeAge_refl _
            · dsimp only [Alg4ServingNode.toServingNodeState]
              rw [if_pos (by rw [ha0]; omega), hown_n]; rfl
          · rw [ht0, ← hS_eq_birth]; exact hasNodeAge_refl _
      · intro r hr
        rcases List.mem_append.mp hr with hr1 | hr2
        · exact hret9_due hD_out r hr1
        · rcases List.mem_singleton.mp hr2 with rfl
          exact ⟨Nat.zero_le D_out, trivial⟩
    · rw [if_neg hgt]
      have hcard_le_6L : leaf9_due.card ≤ 6 * L := Nat.le_of_not_gt hgt
      by_cases hch : leafCh9_due = true
      · rw [if_pos hch]
        have hex := computeExactLeafAnswer_spec pts' leaf9_due choices.terminalLeafHint
        exact ⟨hleaf9_due, hcard_le_6L, hex.1, hex.2, hpost9_due, hret9_due hD_out⟩
      · rw [if_neg hch]
        have hch_f : leafCh9_due = false := Bool.eq_false_iff.mpr hch
        rcases hlch9_due hch_f with ⟨_, hex9, hsq9⟩
        exact ⟨hleaf9_due, hcard_le_6L, hex9, hsq9, hpost9_due, hret9_due hD_out⟩
  rcases h9_eq : alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
      nodes78 leaf78 leafAns78 leafSq78 leafCh78
      choices.leafRebuildChoices choices.terminalLeafHint with
    ⟨nodes9, finalLeaf, finalLeafAns, finalLeafSq, retiredDue⟩
  rw [h9_eq] at h9_full
  rcases h9_full with ⟨hfinalLeaf, hfinalCard, hfinalExact, hfinalSq, hpost9, hret_due⟩
  -- Line 10: `alg4Line10RefreshAffectedCaches`
  have htag9 : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
      nodes9[idx]? = some p →
      TaggedNodeDataWF mode pts'
        (servingChainInputAt pts' (nodes9.map (fun q => q.1.toServingNodeState)) P' idx) p :=
    fun idx p hp => (hpost9 idx p hp).1
  rcases alg4Line10RefreshAffectedCaches_spec pts' mode nodes9 P'
      choices.baselineSamples choices.matchingMaxHints htag9 with
    ⟨hLen10, hballs10, hidx10⟩
  set finalNodes := alg4Line10RefreshAffectedCaches pts' mode P' nodes9
    choices.baselineSamples choices.matchingMaxHints
  -- Line 11: `alg4Line11PerformRetirementWork`
  set allNewRetired := retired78 ++ retiredDue ++ choices.stepExtraRetired
  have hall_new_ret : ∀ r ∈ allNewRetired, r.HasBoundedOutdegree D_out := by
    intro r hr
    rcases List.mem_append.mp hr with hr12 | hr3
    · rcases List.mem_append.mp hr12 with hr1 | hr2
      · exact hret78 hD_out r hr1
      · exact hret_due r hr2
    · exact hextra_ret r hr3
  have hret11 := (alg4Line11PerformRetirementWork_spec ι D_out reclaimMult
    choices.stepAllocatedRecords st.retirementQueue allNewRetired hret_q_wf hall_new_ret).1
  -- Line 12: `updateDistinctFallbackPair` + `alg4Line12SelectCachedAnswer`
  set nextFallback := updateDistinctFallbackPair P' st.distinctFallbackPair choices.distinctPairHint
  have hfb := updateDistinctFallbackPair_spec P' st.distinctFallbackPair choices.distinctPairHint
  -- Assemble `nextState` equality
  have hstep_eq : (alg4Step mode α L reclaimMult st upd choices).1 =
      { activeSet := P'
        coords := pts'
        servingNodes := finalNodes
        terminalLeaf := finalLeaf
        terminalLeafAnswer := finalLeafAns
        terminalLeafDistSq := finalLeafSq
        distinctFallbackPair := nextFallback
        retirementQueue :=
          (alg4Line11PerformRetirementWork reclaimMult choices.stepAllocatedRecords
            st.retirementQueue allNewRetired).1
        cachedAnswer :=
          alg4Line12SelectCachedAnswer pts' P' finalNodes finalLeafAns finalLeafSq nextFallback } := by
    unfold alg4Step
    dsimp only
    rw [hl1_apply_eq]
    dsimp only
    rw [show alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices = nodes26 from rfl]
    rw [h78_eq]
    dsimp only
    rw [h9_eq]
  rw [hstep_eq]
  have hfinalLeaf_10 : finalLeaf = servingChainInputAt pts'
      (finalNodes.map Alg4ServingNode.toServingNodeState) P' finalNodes.length := by
    rw [hfinalLeaf, ← hLen10]
    symm
    apply servingChainInputAt_eq_of_take_balls
    rw [List.map_take, List.map_take, hballs10]
  have hfinal_nodes_all : ∀ (idx : ℕ) (hi : idx < finalNodes.length),
      let sn_out := finalNodes[idx]'hi
      let S_idx := servingChainInputAt pts'
        (finalNodes.map Alg4ServingNode.toServingNodeState) P' idx
      sn_out.WellFormed mode α L pts' S_idx ∧
      sn_out.birthSnapshot.card ≤ n ∧
      (∀ job : Alg4PendingJob d ι, sn_out.ownedJob = some job →
        Alg4JobSchedInv n α L pts' S_idx job) := by
    intro idx hi
    have hi9 : idx < nodes9.length := by omega
    have h10 := hidx10 idx (nodes9[idx]'hi9) (finalNodes[idx]'hi)
      (List.getElem?_eq_getElem hi9) (List.getElem?_eq_getElem hi)
    rcases h10 with ⟨hS_eq10, hb_eq10, hn_eq10, hta_eq10, ha_eq10, hown_eq10, hpre10, hcache10⟩
    have hp9 := hpost9 idx (nodes9[idx]'hi9) (List.getElem?_eq_getElem hi9)
    rcases hp9 with ⟨_, hb_le9, hs_wf9, hta_le9, hhna9, hjob9⟩
    have hs_eq_state : (finalNodes[idx]'hi).toServingNodeState =
        (nodes9[idx]'hi9).1.toServingNodeState := by
      unfold Alg4ServingNode.toServingNodeState
      rw [hb_eq10, hn_eq10, ha_eq10, hown_eq10]
    dsimp only
    refine ⟨?_, hb_eq10 ▸ hb_le9, ?_⟩
    · refine ⟨by rw [hs_eq_state, hS_eq10]; exact hs_wf9,
        by rw [hta_eq10, ha_eq10]; exact hta_le9,
        by rw [hb_eq10, hta_eq10, hS_eq10]; exact hhna9,
        hpre10.1, hpre10.2, hcache10.1, hcache10.2.1, hcache10.2.2, ?_⟩
      cases hown_f : (finalNodes[idx]'hi).ownedJob with
      | none => trivial
      | some job =>
        rw [hown_eq10] at hown_f
        rw [hS_eq10]
        exact (hjob9 job hown_f).1
    · intro job hjob
      rw [hown_eq10] at hjob
      rw [hS_eq10]
      exact (hjob9 job hjob).2
  refine ⟨?_, ?_⟩
  · refine ⟨hP'_le_n, ?_, hfinalCard, hfinalSq, ?_, hfb, hret11, rfl⟩
    · refine ⟨?_, by simpa [Alg4State.toScheduledServingChain] using hfinalLeaf_10, hfinalExact⟩
      intro idx
      have hi_fn : idx.val < finalNodes.length := by simpa [Alg4State.toScheduledServingChain] using idx.isLt
      change ((finalNodes.map Alg4ServingNode.toServingNodeState)[idx.val]'(by simp [hi_fn])).WellFormed
        α L pts' (servingChainInputAt pts' (finalNodes.map Alg4ServingNode.toServingNodeState) P' idx.val)
      simp only [List.getElem_map]
      exact (hfinal_nodes_all idx.val hi_fn).1.1
    · intro idx
      dsimp only [Alg4State.servingInputAt]
      rw [Fin.getElem_fin]
      exact (hfinal_nodes_all idx.val idx.isLt).1
  · intro idx sn hget
    have hi_fn : idx < finalNodes.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
    rw [List.getElem?_eq_getElem hi_fn] at hget
    injection hget with hget_eq; subst hget_eq
    have hf := hfinal_nodes_all idx hi_fn
    exact ⟨hf.2.1, hf.2.2⟩

theorem reachableAlg4Inv_trajectory {d n T : ℕ} {ι : Type}
    {mode : Alg4Mode} {α C : ℝ} {K₀ L reclaimMult D_out : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (hD_out : 1 ≤ D_out)
    (st : Fin (T + 1) → Alg4State d ι)
    (ans : Fin T → Option (ι × ι) × ℝ)
    (upd : Fin T → Alg4PointUpdate d ι)
    (choices : Fin T → Alg4StepChoices d ι)
    (hst0 : st 0 = Alg4State.empty d ι)
    (hsteps : ∀ t : Fin T,
      IsValidAlg4PointUpdate n (st t.castSucc) (upd t) ∧
      Alg4StepSatisfiesEq11Completion mode α L (st t.castSucc) (upd t) (choices t) ∧
      (∀ r ∈ (choices t).stepExtraRetired, r.HasBoundedOutdegree D_out) ∧
      alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) = (st t.succ, ans t)) :
    ∀ s : Fin (T + 1), ReachableAlg4Inv n mode α L D_out (st s) := by
  rintro ⟨k, hk⟩
  induction k with
  | zero =>
    have h0 : (⟨0, hk⟩ : Fin (T + 1)) = 0 := rfl
    rw [h0, hst0]
    exact reachableAlg4Inv_empty ι mode α L D_out
  | succ k ih =>
    have hk_T : k < T := Nat.lt_of_succ_lt_succ hk
    let t : Fin T := ⟨k, hk_T⟩
    have hcs : st t.castSucc = st ⟨k, Nat.lt_of_succ_lt hk⟩ := rfl
    have hsc : st t.succ = st ⟨k + 1, hk⟩ := rfl
    rcases hsteps t with ⟨hupd_t, heq11_t, hextra_t, hstep_t⟩
    have hinv_prev := ih (Nat.lt_of_succ_lt hk)
    rw [← hcs] at hinv_prev
    have hinv_next := reachableAlg4Inv_step (reclaimMult := reclaimMult) hα_pos hα_le hL hD_out hinv_prev hupd_t heq11_t hextra_t
    have hfst : (alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t)).1 = st t.succ :=
      congrArg Prod.fst hstep_t
    rw [hfst, hsc] at hinv_next
    exact hinv_next

end UL.Proof.claim_C_2_space_reclaim.RacerP44
