import UL.Proof.claim_C_2_space_reclaim.RacerP44_H3a

set_option autoImplicit false

namespace UL.Proof.claim_C_2_space_reclaim.RacerP44

open Classical
open UL
open UL.Proof.lem_C_2.H1
open UL.Proof.claim_C_2_space_reclaim

/-! ### 1. Finite Batch-Extraction Helpers (`takeBatchFinset`) -/

theorem nodup_take_local {ι : Type} :
    ∀ (k : ℕ) {l : List ι}, l.Nodup → (l.take k).Nodup
  | 0, _, _ => List.nodup_nil
  | _ + 1, [], _ => List.nodup_nil
  | k + 1, a :: l, h => by
      dsimp only [List.take]
      rw [List.nodup_cons] at h ⊢
      exact ⟨fun hm => h.1 (List.mem_of_mem_take hm), nodup_take_local k h.2⟩

theorem toFinset_card_of_nodup_local {ι : Type} :
    ∀ {l : List ι}, l.Nodup → l.toFinset.card = l.length
  | [], _ => rfl
  | a :: l, h => by
      rw [List.nodup_cons] at h
      have hnot : a ∉ l.toFinset := by simpa using h.1
      rw [List.toFinset_cons]
      simp [hnot, toFinset_card_of_nodup_local h.2]

noncomputable def takeBatchFinset {ι : Type} (K : ℕ) (S : Finset ι) : Finset ι :=
  (S.toList.take K).toFinset

theorem takeBatchFinset_subset {ι : Type} (K : ℕ) (S : Finset ι) :
    takeBatchFinset K S ⊆ S := by
  intro x hx
  unfold takeBatchFinset at hx
  rw [List.mem_toFinset] at hx
  exact Finset.mem_toList.mp (List.mem_of_mem_take hx)

theorem takeBatchFinset_card {ι : Type} (K : ℕ) (S : Finset ι) :
    (takeBatchFinset K S).card = min K S.card := by
  unfold takeBatchFinset
  have hnd : (S.toList.take K).Nodup := nodup_take_local K (Finset.nodup_toList S)
  rw [toFinset_card_of_nodup_local hnd, List.length_take, Finset.length_toList]

theorem takeBatchFinset_card_le {ι : Type} (K : ℕ) (S : Finset ι) :
    (takeBatchFinset K S).card ≤ K := by
  rw [takeBatchFinset_card]
  exact Nat.min_le_left K S.card

theorem takeBatchFinset_sdiff_card {ι : Type} (K : ℕ) (S : Finset ι) :
    (S \ takeBatchFinset K S).card = S.card - K := by
  have hadd := Finset.card_sdiff_add_card_eq_card (takeBatchFinset_subset K S)
  have hc := takeBatchFinset_card K S
  omega

/-! ### 2. `maxLevelBuildTicks * K_batch` Coverage Bound -/

theorem maxLevelBuildTicks_pos_and_cover {d n : ℕ} {α C : ℝ} {K₀ L m : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (hlarge : IsLargeResidualLevel L m) :
    let K_batch := ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊
    1 ≤ maxLevelBuildTicks α m ∧
    m ≤ maxLevelBuildTicks α m * K_batch := by
  dsimp only
  set K_batch := ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊
  have hcut := (large_level_alpha_m_lb hα_pos hα_le hL hlarge).1
  set X : ℝ := α ^ 2 * (m : ℝ) / (64 * (scheduleCStar : ℝ))
  have hX_lb : 32768 ≤ X := by
    dsimp only [X]
    unfold scheduleCStar at hcut ⊢
    norm_num at hcut ⊢
    linarith
  have hfl_gt : X - 1 < (maxLevelBuildTicks α m : ℝ) :=
    Nat.sub_one_lt_floor X
  have hmax_pos : 1 ≤ maxLevelBuildTicks α m := by
    have h1 : (1 : ℝ) < (maxLevelBuildTicks α m : ℝ) := by linarith
    have : 1 < maxLevelBuildTicks α m := by exact_mod_cast h1
    omega
  refine ⟨hmax_pos, ?_⟩
  have hhalf_le : X / 2 ≤ (maxLevelBuildTicks α m : ℝ) := by linarith
  have hK_lb : cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ ≤ (K_batch : ℝ) :=
    Nat.le_ceil _
  have hK_nn : 0 ≤ cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹ := by
    unfold cBatchVal scheduleCStar; positivity
  have hX2_nn : 0 ≤ X / 2 := by linarith
  have hprod_le : (X / 2) * (cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹) ≤
      (maxLevelBuildTicks α m : ℝ) * (K_batch : ℝ) :=
    mul_le_mul hhalf_le hK_lb hK_nn (by positivity)
  have ha_ne : α ≠ 0 := ne_of_gt hα_pos
  have hlhs_eq : (X / 2) * (cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹) = 2 * (m : ℝ) := by
    dsimp only [X]
    unfold cBatchVal scheduleCStar
    field_simp [ha_ne]
    ring
  have hm_le_r : (m : ℝ) ≤ ((maxLevelBuildTicks α m * K_batch : ℕ) : ℝ) := by
    push_cast
    linarith
  exact_mod_cast hm_le_r

/-! ### 3. Greedy Per-Tick Scan-Budget Builder & Structural Properties -/

def defaultJobStepChoices (d : ℕ) (ι : Type) : PendingJobStepChoices d ι :=
  { prefixRouteQueries := []
    prefixRouteMaxHints := []
    prefixBudgetSteps := []
    openSampledCenter := .infeasible
    openFallbackBirthId := none
    leafHint := none }

noncomputable def mkGreedyLevelBudgets {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (K_batch : ℕ)
    (pref₁ : List (Alg4OpenedLevel d ι)) (S_root' : Finset ι) :
    List (PendingLevelBudgetChoices ι) :=
  (List.range pref₁.length).map (fun j =>
    match pref₁[j]? with
    | none =>
        { scan1Batch := ∅
          scan2Steps := []
          scanMaxHint := none
          backgroundIndexesReady := true }
    | some lv₁ =>
        let S_lv' := alg4PrefixInputAt pts' pref₁ S_root' j
        let U₁ := S_lv' \ lv₁.heapIndexedIds
        let U₂ := S_lv' \ lv₁.classifiedIds
        { scan1Batch := takeBatchFinset K_batch U₁
          scan2Steps := (U₂.toList.take K_batch).map (fun q => (q, NodeMatchingQueryAnswers.empty ι))
          scanMaxHint := none
          backgroundIndexesReady := true })

theorem mkGreedyLevelBudgets_cap {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (K_batch : ℕ)
    (pref₁ : List (Alg4OpenedLevel d ι)) (S_root' : Finset ι) :
    ∀ bStep ∈ mkGreedyLevelBudgets pts' K_batch pref₁ S_root',
      bStep.scan1Batch.card ≤ K_batch ∧ bStep.scan2Steps.length ≤ K_batch := by
  intro bStep hb
  unfold mkGreedyLevelBudgets at hb
  rcases List.mem_map.mp hb with ⟨j, _, rfl⟩
  cases pref₁[j]? with
  | none => simp
  | some lv₁ =>
    dsimp only
    refine ⟨takeBatchFinset_card_le _ _, ?_⟩
    simp [List.length_take]

noncomputable def mkGreedyChoices {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (K_batch : ℕ)
    (st : Alg4State d ι) (upd : Alg4PointUpdate d ι)
    (base : Alg4StepChoices d ι) : Alg4StepChoices d ι :=
  let P' := applyAlg4PointSetUpdate st.activeSet upd
  let pts' := updateAlg4Coords st.coords upd
  let (nodesLine1, _, _) :=
    alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
      base.servingRouteQueries base.servingRadiusMaxHints
  let len := max base.pendingJobChoices.length nodesLine1.length
  let pChoices := (List.range len).map (fun idx =>
    let baseJc := (base.pendingJobChoices.drop idx).head?.getD (defaultJobStepChoices d ι)
    let bSteps :=
      match nodesLine1[idx]? with
      | some (sn, ev) =>
          if ev.isClockTick then
            match sn.ownedJob with
            | some job =>
                let S_idx' :=
                  servingChainInputAt pts' (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx
                let job₁ := alg4Line3RouteThroughPrefix pts' mode job ev S_idx' baseJc
                mkGreedyLevelBudgets pts' K_batch job₁.completedPrefix S_idx'
            | none => []
          else []
      | none => []
    { baseJc with prefixBudgetSteps := bSteps })
  { base with pendingJobChoices := pChoices }

theorem drop_head_getD_eq_getElem {α : Type} (xs : List α) (d : α) {i : ℕ} (hi : i < xs.length) :
    (xs.drop i).head?.getD d = xs[i]'hi := by
  rw [List.drop_eq_getElem_cons hi]
  rfl

theorem mkGreedyChoices_agree {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (K_batch : ℕ)
    (st : Alg4State d ι) (upd : Alg4PointUpdate d ι)
    (base : Alg4StepChoices d ι) :
    Alg4StepChoicesAgreeExceptScanBudgets base (mkGreedyChoices mode K_batch st upd base) := by
  refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, ?_⟩
  intro i
  have hi_len : i.val < max base.pendingJobChoices.length
      (alg4Line1ApplyToServingChain (updateAlg4Coords st.coords upd) mode st.servingNodes
        st.terminalLeaf upd base.servingRouteQueries base.servingRadiusMaxHints).1.length :=
    lt_of_lt_of_le i.isLt (Nat.le_max_left _ _)
  unfold mkGreedyChoices
  dsimp only
  rw [List.getElem?_map, List.getElem?_range hi_len]
  dsimp only [Option.map_some]
  refine ⟨_, rfl, ?_⟩
  rw [drop_head_getD_eq_getElem _ _ i.isLt, Fin.getElem_fin]
  exact ⟨rfl, rfl, rfl, rfl, rfl⟩

theorem mkGreedyChoices_cap {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (K_batch : ℕ)
    (st : Alg4State d ι) (upd : Alg4PointUpdate d ι)
    (base : Alg4StepChoices d ι) :
    Alg4ChoicesRespectScanBatchCap K_batch (mkGreedyChoices mode K_batch st upd base) := by
  intro jc hjc bStep hb
  unfold mkGreedyChoices at hjc
  dsimp only at hjc
  rcases List.mem_map.mp hjc with ⟨idx, _, rfl⟩
  dsimp only at hb
  set nl1 := (alg4Line1ApplyToServingChain (updateAlg4Coords st.coords upd) mode st.servingNodes
    st.terminalLeaf upd base.servingRouteQueries base.servingRadiusMaxHints).1
  cases hnl : nl1[idx]? with
  | none => rw [hnl] at hb; simp at hb
  | some p =>
    rcases p with ⟨sn, ev⟩
    rw [hnl] at hb
    dsimp only at hb
    by_cases hct : ev.isClockTick = true
    · rw [if_pos hct] at hb
      cases hown : sn.ownedJob with
      | none => rw [hown] at hb; simp at hb
      | some job => rw [hown] at hb; dsimp only at hb; exact mkGreedyLevelBudgets_cap _ _ _ _ bStep hb
    · rw [if_neg hct] at hb; simp at hb

/-! ### 4. Scan-Progress Invariant & Single-Step Equation (11) Proof -/

def GreedyJobScanInv {d : ℕ} {ι : Type}
    (K_batch : ℕ) (α : ℝ)
    (pts : ι → EuclideanSpace ℝ (Fin d)) (S_root : Finset ι)
    (job : Alg4PendingJob d ι) : Prop :=
  ∀ (j : ℕ) (lv : Alg4OpenedLevel d ι),
    job.completedPrefix[j]? = some lv →
    lv.backgroundReady = false →
      let S_lv := alg4PrefixInputAt pts job.completedPrefix S_root j
      lv.elapsedRootTicks < maxLevelBuildTicks α lv.birthSnapshot.card ∧
      (S_lv \ lv.heapIndexedIds).card ≤ lv.birthSnapshot.card - lv.elapsedRootTicks * K_batch ∧
      (S_lv \ lv.classifiedIds).card ≤ lv.birthSnapshot.card - lv.elapsedRootTicks * K_batch

theorem greedyJobScanInv_congr {d : ℕ} {ι : Type}
    {K_batch : ℕ} {α : ℝ}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    {S_root : Finset ι} {job : Alg4PendingJob d ι}
    (hinv : GreedyJobScanInv K_batch α pts₁ S_root job)
    (hpts : ∀ x ∈ S_root, pts₂ x = pts₁ x) :
    GreedyJobScanInv K_batch α pts₂ S_root job := by
  intro j lv hget hnr
  have hpts' : ∀ x ∈ S_root, pts₁ x = pts₂ x := fun x hx => (hpts x hx).symm
  have heq := alg4PrefixInputAt_congr job.completedPrefix j hpts'
  have hj := hinv j lv hget hnr
  dsimp only at hj ⊢
  rwa [← heq]

def GreedyStateScanInv {d : ℕ} {ι : Type}
    (K_batch : ℕ) (α : ℝ) (st : Alg4State d ι) : Prop :=
  ∀ (idx : ℕ) (sn : Alg4ServingNode d ι),
    st.servingNodes[idx]? = some sn →
    ∀ job : Alg4PendingJob d ι,
      sn.ownedJob = some job →
        GreedyJobScanInv K_batch α st.coords (st.servingInputAt idx) job

theorem greedyStateScanInv_empty {d : ℕ} (ι : Type) (K_batch : ℕ) (α : ℝ) :
    GreedyStateScanInv K_batch α (Alg4State.empty d ι) :=
  fun _ _ h => by simp [Alg4State.empty] at h

set_option maxHeartbeats 800000 in
theorem stepGreedyPendingJob_eq11_and_scan {d n : ℕ} {ι : Type}
    {pts₀ pts' : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode}
    {α C : ℝ} {K₀ L : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    {S_before S_after : Finset ι} {ev : PoolUpdateEvent ι}
    {job : Alg4PendingJob d ι} (baseJc : PendingJobStepChoices d ι)
    (hpts_S : ∀ x ∈ S_before, pts' x = pts₀ x)
    (hpts_B : ∀ lv ∈ job.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts' x = pts₀ x)
    (hev : IsValidPoolUpdateEvent S_before S_after ev)
    (hwf0 : job.WellFormed mode α L pts₀ S_before)
    (hsched0 : Alg4JobSchedInv n α L pts₀ S_before job)
    (hscan0 : GreedyJobScanInv ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ α pts₀ S_before job) :
    let K_batch := ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊
    let job₁_base := alg4Line3RouteThroughPrefix pts' mode job ev S_after baseJc
    let jc := { baseJc with prefixBudgetSteps := mkGreedyLevelBudgets pts' K_batch job₁_base.completedPrefix S_after }
    let job₁ := alg4Line3RouteThroughPrefix pts' mode job ev S_after jc
    let job₂ := alg4Line4AdvanceClockAndBuild pts' mode job₁ S_after jc.prefixBudgetSteps
    let job₃ := alg4Line5LateOpeningGate pts' mode α L job₂ jc
    (∀ lv ∈ job₃.completedPrefix,
      maxLevelBuildTicks α lv.birthSnapshot.card ≤ lv.elapsedRootTicks →
        lv.backgroundReady = true) ∧
    GreedyJobScanInv K_batch α pts' S_after job₃ := by
  dsimp only
  set K_batch := ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊
  set job₁_base := alg4Line3RouteThroughPrefix pts' mode job ev S_after baseJc
  set jc : PendingJobStepChoices d ι :=
    { baseJc with prefixBudgetSteps := mkGreedyLevelBudgets pts' K_batch job₁_base.completedPrefix S_after }
  have hj1_eq : alg4Line3RouteThroughPrefix pts' mode job ev S_after jc = job₁_base := rfl
  rw [hj1_eq]
  obtain ⟨job₁, hjob1_def⟩ : ∃ x, x = job₁_base := ⟨_, rfl⟩
  rw [← hjob1_def]
  have hjc_steps : jc.prefixBudgetSteps = mkGreedyLevelBudgets pts' K_batch job₁.completedPrefix S_after := by
    dsimp only [jc]; rw [hjob1_def]
  obtain ⟨job₂, hjob2_def⟩ : ∃ x, x = alg4Line4AdvanceClockAndBuild pts' mode job₁ S_after
      (mkGreedyLevelBudgets pts' K_batch job₁.completedPrefix S_after) := ⟨_, rfl⟩
  rw [← hjob2_def]
  rw [← hjc_steps] at hjob2_def
  obtain ⟨job₃, hjob3_def⟩ : ∃ x, x = alg4Line5LateOpeningGate pts' mode α L job₂ jc := ⟨_, rfl⟩
  rw [← hjob3_def]
  have hdwf0 := pendingJobDataWF_of_wellFormed hwf0
  rcases alg4Line3RoutePrefixAux_spec pts₀ pts' mode α L job.completedPrefix
      S_before S_after (some ev) jc.prefixRouteQueries jc.prefixRouteMaxHints
      hpts_S hpts_B hev hdwf0.2.1 with ⟨hLen1, _, hroute_j⟩
  have hpref1_eq : job₁.completedPrefix =
      (alg4Line3RoutePrefixAux pts' mode (some ev) job.completedPrefix
        jc.prefixRouteQueries jc.prefixRouteMaxHints).1 := by
    rw [hjob1_def]; rfl
  have hpref2_eq : job₂.completedPrefix =
      stepPrefixConstruction pts' mode S_after job₁.completedPrefix jc.prefixBudgetSteps := by
    rw [hjob2_def]; rfl
  have hstep4_in : ∀ j : Fin job₁.completedPrefix.length,
      let lv₁ := job₁.completedPrefix[j]
      let S_lv' := alg4PrefixInputAt pts' job₁.completedPrefix S_after j.val
      lv₁.indexMode = mode.backgroundIndexMode ∧
      IsLargeResidualLevel L lv₁.birthSnapshot.card ∧
      PassesBirthCoreCheck α pts' lv₁.ball lv₁.birthSnapshot ∧
      lv₁.trueInputAge ≤ lv₁.elapsedRootTicks + 1 ∧
      HasNodeAge lv₁.birthSnapshot S_lv' lv₁.trueInputAge ∧
      lv₁.heapIndexedIds = lv₁.radiusDict.indexedIds ∧
      lv₁.radiusDict.IsScanValid pts' lv₁.ball.o S_lv' ∧
      lv₁.classifiedIds ⊆ S_lv' ∧
      ValidNodeMatchingsOn pts' mode lv₁.ball lv₁.classifiedIds lv₁.localMatchings ∧
      (lv₁.backgroundReady = true →
        lv₁.heapIndexedIds = S_lv' ∧ lv₁.classifiedIds = S_lv') := by
    intro j
    have hj0 : j.val < job.completedPrefix.length := by rw [← hpref1_eq] at hLen1; omega
    have hwf_j := hdwf0.2.1 ⟨j.val, hj0⟩
    have hr := hroute_j ⟨j.val, hj0⟩
    dsimp only at hr hwf_j
    simp only [Fin.getElem_fin] at hr hwf_j
    rcases hr with ⟨hb_eq, _, hball_eq, hmode_eq, _, _, hhid_eq,
      _, _, _, _, hage_j, hscan_j, hcls_j, hlm_j, hrdy_j, _, _⟩
    have hpts_Bj : ∀ x ∈ (job.completedPrefix[j.val]'hj0).birthSnapshot, pts₀ x = pts' x :=
      fun x hx => (hpts_B _ (List.getElem_mem _) x hx).symm
    dsimp only
    rw [Fin.getElem_fin]
    simp only [hpref1_eq]
    rw [hb_eq, hball_eq, hmode_eq]
    rw [hb_eq] at hage_j
    refine ⟨hwf_j.1, hwf_j.2.1, (passesBirthCoreCheck_congr α _ hpts_Bj).mp hwf_j.2.2.1,
      ?_, hage_j, hhid_eq, hscan_j, hcls_j, hlm_j, hrdy_j⟩
    have := hwf_j.2.2.2.1
    omega
  have hLen2 := stepPrefixConstruction_length pts' mode job₁.completedPrefix S_after jc.prefixBudgetSteps
  rcases stepPrefixConstruction_spec pts' mode α L job₁.completedPrefix S_after
      jc.prefixBudgetSteps hstep4_in with ⟨_, hstep4_j⟩
  have hLen20 : job₂.completedPrefix.length = job.completedPrefix.length := by
    rw [hpref2_eq, hLen2, hpref1_eq, hLen1]
  -- Per-level Equation (11) & `GreedyJobScanInv` on `job₂`
  have hpfx2_scan : ∀ (j : ℕ) (hj2 : j < job₂.completedPrefix.length),
      let lv2 := job₂.completedPrefix[j]'hj2
      let S_lv' := alg4PrefixInputAt pts' job₂.completedPrefix S_after j
      (maxLevelBuildTicks α lv2.birthSnapshot.card ≤ lv2.elapsedRootTicks →
        lv2.backgroundReady = true) ∧
      (lv2.backgroundReady = false →
        lv2.elapsedRootTicks < maxLevelBuildTicks α lv2.birthSnapshot.card ∧
        (S_lv' \ lv2.heapIndexedIds).card ≤ lv2.birthSnapshot.card - lv2.elapsedRootTicks * K_batch ∧
        (S_lv' \ lv2.classifiedIds).card ≤ lv2.birthSnapshot.card - lv2.elapsedRootTicks * K_batch) := by
    intro j hj2
    have hj0 : j < job.completedPrefix.length := by omega
    have hj1 : j < job₁.completedPrefix.length := by rw [hpref1_eq, hLen1]; exact hj0
    have hr := hroute_j ⟨j, hj0⟩
    have hs4 := hstep4_j ⟨j, hj1⟩
    dsimp only at hr hs4
    simp only [Fin.getElem_fin] at hr hs4
    have hget1 : job₁.completedPrefix[j]'hj1 =
        (alg4Line3RoutePrefixAux pts' mode (some ev) job.completedPrefix
          jc.prefixRouteQueries jc.prefixRouteMaxHints).1[j]'(by omega) := by
      have hopt : job₁.completedPrefix[j]? =
          (alg4Line3RoutePrefixAux pts' mode (some ev) job.completedPrefix
            jc.prefixRouteQueries jc.prefixRouteMaxHints).1[j]? := by rw [hpref1_eq]
      rw [List.getElem?_eq_getElem hj1, List.getElem?_eq_getElem (by omega)] at hopt
      exact Option.some.inj hopt
    have hget2 : job₂.completedPrefix[j]'hj2 =
        (stepPrefixConstruction pts' mode S_after job₁.completedPrefix
          jc.prefixBudgetSteps)[j]'(by omega) := by
      have hopt : job₂.completedPrefix[j]? =
          (stepPrefixConstruction pts' mode S_after job₁.completedPrefix
            jc.prefixBudgetSteps)[j]? := by rw [hpref2_eq]
      rw [List.getElem?_eq_getElem hj2, List.getElem?_eq_getElem (by omega)] at hopt
      exact Option.some.inj hopt
    rw [← hget1, ← hpref1_eq] at hr
    rw [← hget2, ← hpref2_eq] at hs4
    rcases hr with ⟨hb1, hs2_1, _, _, hrdy1, hel1, hhid1,
      _, _, _, _, _, _, _, _, _, hsdiff_h1, hsdiff_c1⟩
    rcases hs4 with ⟨hSin_eq, hb2, hs2_2, _, hel2, _, hrdy12, hwf_lv2, hfalse_s4⟩
    have h0_wf : (job.completedPrefix[j]'hj0).WellFormed mode α L pts₀
        (alg4PrefixInputAt pts₀ job.completedPrefix S_before j) := by
      simpa [Fin.getElem_fin] using (hwf0.2.1 ⟨j, hj0⟩).2
    have h0_dict_id : (job.completedPrefix[j]'hj0).radiusDict.indexedIds =
        (job.completedPrefix[j]'hj0).heapIndexedIds := h0_wf.2.2.2.2.2.2.2.1.1
    have h0_sc := hsched0.2.1 j (job.completedPrefix[j]'hj0) (List.getElem?_eq_getElem hj0)
    rcases h0_sc with ⟨_, hs2_0, hsdiff_h0, hsdiff_c0, _, _, _, _⟩
    by_cases hr1_b : (job₁.completedPrefix[j]'hj1).backgroundReady = true
    · have hr2_t : (job₂.completedPrefix[j]'hj2).backgroundReady = true := hrdy12 hr1_b
      exact ⟨fun _ => hr2_t, fun hnr => by rw [hr2_t] at hnr; cases hnr⟩
    · have hr1_f : (job₁.completedPrefix[j]'hj1).backgroundReady = false := Bool.eq_false_iff.mpr hr1_b
      have hr0_f : (job.completedPrefix[j]'hj0).backgroundReady = false := hrdy1.symm.trans hr1_f
      rcases hscan0 j (job.completedPrefix[j]'hj0) (List.getElem?_eq_getElem hj0) hr0_f with
        ⟨_, hcard_h0, hcard_c0⟩
      -- Unpack `bChoice` at index `j`
      have hbSteps_len : j < jc.prefixBudgetSteps.length := by
        rw [hjc_steps]; simp [mkGreedyLevelBudgets, hj1]
      have hbChoice_eq : (jc.prefixBudgetSteps.drop j).head?.getD
          { scan1Batch := ∅, scan2Steps := [], scanMaxHint := none, backgroundIndexesReady := false } =
          jc.prefixBudgetSteps[j]'hbSteps_len :=
        drop_head_getD_eq_getElem _ _ hbSteps_len
      have hbElem : jc.prefixBudgetSteps[j]'hbSteps_len =
          (let S_lv1 := alg4PrefixInputAt pts' job₁.completedPrefix S_after j
           let U₁ := S_lv1 \ (job₁.completedPrefix[j]'hj1).heapIndexedIds
           let U₂ := S_lv1 \ (job₁.completedPrefix[j]'hj1).classifiedIds
           { scan1Batch := takeBatchFinset K_batch U₁
             scan2Steps := (U₂.toList.take K_batch).map (fun q => (q, NodeMatchingQueryAnswers.empty ι))
             scanMaxHint := none
             backgroundIndexesReady := true }) := by
        have hopt : jc.prefixBudgetSteps[j]? = (mkGreedyLevelBudgets pts' K_batch job₁.completedPrefix S_after)[j]? := by
          rw [hjc_steps]
        rw [List.getElem?_eq_getElem hbSteps_len] at hopt
        unfold mkGreedyLevelBudgets at hopt
        rw [List.getElem?_map, List.getElem?_range hj1, Option.map_some, List.getElem?_eq_getElem hj1] at hopt
        exact Option.some.inj hopt
      have hb_all := hfalse_s4 hr1_f
      rw [hbChoice_eq, hbElem] at hb_all
      dsimp only at hb_all
      rcases hb_all with ⟨hdiff_h2, hdiff_c2, hdone_imp⟩
      -- Show `U₁ ⊆ lv₁.birthSnapshot` and `U₂ ⊆ lv₁.scan2Snapshot`
      set S_lv2 := alg4PrefixInputAt pts' job₂.completedPrefix S_after j
      have hU1_sub_B : S_lv2 \ (job₁.completedPrefix[j]'hj1).heapIndexedIds ⊆
          (job₁.completedPrefix[j]'hj1).birthSnapshot := by
        rw [hSin_eq, hhid1, hb1]
        refine Finset.Subset.trans hsdiff_h1 ?_
        rw [h0_dict_id]; exact hsdiff_h0
      have hU2_sub_B : S_lv2 \ (job₁.completedPrefix[j]'hj1).classifiedIds ⊆
          (job₁.completedPrefix[j]'hj1).scan2Snapshot := by
        rw [hSin_eq, hs2_1, hs2_0]
        refine Finset.Subset.trans hsdiff_c1 ?_
        rw [← hs2_0]; exact hsdiff_c0
      have hU1_card_le : (S_lv2 \ (job₁.completedPrefix[j]'hj1).heapIndexedIds).card ≤
          (job.completedPrefix[j]'hj0).birthSnapshot.card -
            (job.completedPrefix[j]'hj0).elapsedRootTicks * K_batch := by
        have hsub : S_lv2 \ (job₁.completedPrefix[j]'hj1).heapIndexedIds ⊆
            alg4PrefixInputAt pts₀ job.completedPrefix S_before j \
              (job.completedPrefix[j]'hj0).heapIndexedIds := by
          rw [hSin_eq, hhid1, ← h0_dict_id]; exact hsdiff_h1
        exact le_trans (Finset.card_le_card hsub) hcard_h0
      have hU2_card_le : (S_lv2 \ (job₁.completedPrefix[j]'hj1).classifiedIds).card ≤
          (job.completedPrefix[j]'hj0).birthSnapshot.card -
            (job.completedPrefix[j]'hj0).elapsedRootTicks * K_batch := by
        have hsub : S_lv2 \ (job₁.completedPrefix[j]'hj1).classifiedIds ⊆
            alg4PrefixInputAt pts₀ job.completedPrefix S_before j \
              (job.completedPrefix[j]'hj0).classifiedIds := by
          rw [hSin_eq]; exact hsdiff_c1
        exact le_trans (Finset.card_le_card hsub) hcard_c0
      -- Simplify `B₁ ∩ birthSnapshot = B₁` and `B₂ ∩ scan2Snapshot = B₂`
      rw [← hSin_eq] at hdiff_h2 hdiff_c2
      have hinter1 : takeBatchFinset K_batch (S_lv2 \ (job₁.completedPrefix[j]'hj1).heapIndexedIds) ∩
          (job₁.completedPrefix[j]'hj1).birthSnapshot =
          takeBatchFinset K_batch (S_lv2 \ (job₁.completedPrefix[j]'hj1).heapIndexedIds) :=
        Finset.inter_eq_left.mpr (Finset.Subset.trans (takeBatchFinset_subset _ _) hU1_sub_B)
      have hmap_fst : (((S_lv2 \ (job₁.completedPrefix[j]'hj1).classifiedIds).toList.take K_batch).map
          (fun q => (q, NodeMatchingQueryAnswers.empty ι))).map Prod.fst =
          (S_lv2 \ (job₁.completedPrefix[j]'hj1).classifiedIds).toList.take K_batch := by
        simp [Function.comp_def]
      rw [hmap_fst] at hdiff_c2
      change S_lv2 \ (job₂.completedPrefix[j]'hj2).classifiedIds =
          (S_lv2 \ (job₁.completedPrefix[j]'hj1).classifiedIds) \
            (takeBatchFinset K_batch (S_lv2 \ (job₁.completedPrefix[j]'hj1).classifiedIds) ∩
              (job₁.completedPrefix[j]'hj1).scan2Snapshot) at hdiff_c2
      have hinter2 : takeBatchFinset K_batch (S_lv2 \ (job₁.completedPrefix[j]'hj1).classifiedIds) ∩
          (job₁.completedPrefix[j]'hj1).scan2Snapshot =
          takeBatchFinset K_batch (S_lv2 \ (job₁.completedPrefix[j]'hj1).classifiedIds) :=
        Finset.inter_eq_left.mpr (Finset.Subset.trans (takeBatchFinset_subset _ _) hU2_sub_B)
      rw [hinter1] at hdiff_h2
      rw [hinter2] at hdiff_c2
      have hcard_h2 : (S_lv2 \ (job₂.completedPrefix[j]'hj2).heapIndexedIds).card ≤
          (job₂.completedPrefix[j]'hj2).birthSnapshot.card -
            (job₂.completedPrefix[j]'hj2).elapsedRootTicks * K_batch := by
        rw [hdiff_h2, takeBatchFinset_sdiff_card, hb2, hb1, hel2, hel1, Nat.add_mul, Nat.one_mul]
        omega
      have hcard_c2 : (S_lv2 \ (job₂.completedPrefix[j]'hj2).classifiedIds).card ≤
          (job₂.completedPrefix[j]'hj2).birthSnapshot.card -
            (job₂.completedPrefix[j]'hj2).elapsedRootTicks * K_batch := by
        rw [hdiff_c2, takeBatchFinset_sdiff_card, hb2, hb1, hel2, hel1, Nat.add_mul, Nat.one_mul]
        omega
      have hlarge2 : IsLargeResidualLevel L (job₂.completedPrefix[j]'hj2).birthSnapshot.card :=
        hwf_lv2.2.1
      have hcov := (maxLevelBuildTicks_pos_and_cover hα_pos hα_le hL hlarge2).2
      have hmax_imp : maxLevelBuildTicks α (job₂.completedPrefix[j]'hj2).birthSnapshot.card ≤
          (job₂.completedPrefix[j]'hj2).elapsedRootTicks →
          (job₂.completedPrefix[j]'hj2).backgroundReady = true := by
        intro hge_max
        have hmul_ge : (job₂.completedPrefix[j]'hj2).birthSnapshot.card ≤
            (job₂.completedPrefix[j]'hj2).elapsedRootTicks * K_batch :=
          le_trans hcov (Nat.mul_le_mul_right K_batch hge_max)
        have hh_zero : (S_lv2 \ (job₂.completedPrefix[j]'hj2).heapIndexedIds).card = 0 := by omega
        have hc_zero : (S_lv2 \ (job₂.completedPrefix[j]'hj2).classifiedIds).card = 0 := by omega
        exact hdone_imp (Finset.card_eq_zero.mp hh_zero) (Finset.card_eq_zero.mp hc_zero) rfl
      refine ⟨hmax_imp, ?_⟩
      intro hnr2
      refine ⟨?_, hcard_h2, hcard_c2⟩
      by_contra hge
      have hrt := hmax_imp (Nat.le_of_not_lt hge)
      rw [hrt] at hnr2; cases hnr2
  -- Propagate from `job₂` to `job₃` across `alg4Line5LateOpeningGate`
  have hpass_unchanged : job₃.completedPrefix = job₂.completedPrefix →
      (∀ lv ∈ job₃.completedPrefix,
        maxLevelBuildTicks α lv.birthSnapshot.card ≤ lv.elapsedRootTicks →
          lv.backgroundReady = true) ∧
      GreedyJobScanInv K_batch α pts' S_after job₃ := by
    intro hcp_eq
    refine ⟨?_, ?_⟩
    · intro lv hlv hge
      rw [hcp_eq] at hlv
      rcases List.mem_iff_getElem.mp hlv with ⟨j, hj2, rfl⟩
      exact (hpfx2_scan j hj2).1 hge
    · intro j lv hget hnr
      dsimp only
      rw [hcp_eq] at hget ⊢
      have hj2 : j < job₂.completedPrefix.length := by
        by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
      rw [List.getElem?_eq_getElem hj2] at hget
      injection hget with hget_eq; subst hget_eq
      exact (hpfx2_scan j hj2).2 hnr
  by_cases hcl2 : job₂.closedAsLeaf = true
  · apply hpass_unchanged
    rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
    rw [if_pos hcl2]
  · by_cases hnotall : (!(job₂.completedPrefix.all (fun lv => lv.backgroundReady))) = true
    · apply hpass_unchanged
      rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
      rw [if_neg hcl2, if_pos hnotall]
    · cases hact : residualScheduleStep α L job₂.remainingTicks job₂.currentResidual.card with
      | wait =>
        apply hpass_unchanged
        rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
        rw [if_neg hcl2, if_neg hnotall, hact]
      | closeAsLeaf =>
        apply hpass_unchanged
        rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
        rw [if_neg hcl2, if_neg hnotall, hact]
      | openBallLevel =>
        by_cases hNE : job₂.currentResidual.Nonempty
        · have hleaf_f : ¬ IsResidualLeafSize L job₂.currentResidual.card := by
            unfold residualScheduleStep at hact
            by_cases ho : CanOpenResidualLevel α job₂.remainingTicks job₂.currentResidual.card
            · rw [if_pos ho] at hact
              by_cases hl : IsResidualLeafSize L job₂.currentResidual.card
              · rw [if_pos hl] at hact; cases hact
              · exact hl
            · rw [if_neg ho] at hact; cases hact
          have hlarge_new : IsLargeResidualLevel L job₂.currentResidual.card := by
            unfold IsLargeResidualLevel IsResidualLeafSize at *; omega
          have hmax_pos_new := (maxLevelBuildTicks_pos_and_cover hα_pos hα_le hL hlarge_new).1
          -- Residual equality on `job₂`
          have hdwf3 := stepSinglePendingJob_dataWF hα_le jc hpts_S hpts_B hev hdwf0
          have hres2_eq : job₂.currentResidual =
              prefixResidual pts' (job₂.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_after := by
            rcases stepPrefixConstruction_spec pts' mode α L job₁.completedPrefix S_after
                jc.prefixBudgetSteps hstep4_in with ⟨hballs2, _⟩
            have hres21 : job₂.currentResidual =
                prefixResidual pts' (job₁.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_after := by
              rw [hjob2_def, hjob1_def]; rfl
            rw [hres21, hpref2_eq]
            exact (prefixResidual_map_eq_of_balls pts' S_after hballs2).symm
          set bId := chooseBirthPointIn job₂.currentResidual hNE jc.openFallbackBirthId
          obtain ⟨ball, hball_def⟩ : ∃ x, x = selectOpenedLevelBall α pts' job₂.currentResidual bId jc.openSampledCenter := ⟨_, rfl⟩
          set newLv : Alg4OpenedLevel d ι :=
            { birthSnapshot := job₂.currentResidual
              ball := ball
              indexMode := mode.backgroundIndexMode
              backgroundReady := false
              trueInputAge := 0
              elapsedRootTicks := 0
              scan2Snapshot := job₂.currentResidual
              heapIndexedIds := ∅
              classifiedIds := ∅
              radiusDict := RadiusDictState.empty ι
              localMatchings := fun _ => LocalMatchingState.empty ι }
          have hcp3 : (alg4Line5LateOpeningGate pts' mode α L job₂ jc).completedPrefix =
              job₂.completedPrefix ++ [newLv] := by
            dsimp only [alg4Line5LateOpeningGate]
            rw [if_neg hcl2, if_neg hnotall, hact]
            dsimp only
            rw [dif_pos hNE, ← hball_def]
          rw [hjob3_def]
          refine ⟨?_, ?_⟩
          · intro lv hlv hge
            rw [hcp3] at hlv
            rcases List.mem_append.mp hlv with hlv2 | hnew
            · rcases List.mem_iff_getElem.mp hlv2 with ⟨j, hj2, rfl⟩
              exact (hpfx2_scan j hj2).1 hge
            · rcases List.mem_singleton.mp hnew with rfl
              dsimp only [newLv] at hge
              omega
          · intro j lv hget hnr
            dsimp only
            rw [hcp3] at hget ⊢
            rcases alg4PrefixInputAt_append_singleton pts' job₂.completedPrefix newLv S_after with
              ⟨hpref_le, hpref_end⟩
            by_cases hj_lt : j < job₂.completedPrefix.length
            · rw [List.getElem?_append_left hj_lt, List.getElem?_eq_getElem hj_lt] at hget
              injection hget with hget_eq; subst hget_eq
              rw [hpref_le j (le_of_lt hj_lt)]
              exact (hpfx2_scan j hj_lt).2 hnr
            · have hge : job₂.completedPrefix.length ≤ j := Nat.le_of_not_lt hj_lt
              rw [List.getElem?_append_right hge] at hget
              by_cases hj_eq : j = job₂.completedPrefix.length
              · subst hj_eq
                simp only [Nat.sub_self, List.getElem?_cons_zero, Option.some.injEq] at hget
                subst hget
                rw [hpref_le _ le_rfl, hpref_end, ← hres2_eq]
                dsimp only [newLv]
                rw [Finset.sdiff_empty, Nat.zero_mul, Nat.sub_zero]
                exact ⟨by omega, le_rfl, le_rfl⟩
              · have hlen1 : [newLv].length ≤ j - job₂.completedPrefix.length := by simp; omega
                rw [List.getElem?_eq_none hlen1] at hget; cases hget
        · apply hpass_unchanged
          rw [hjob3_def]; dsimp only [alg4Line5LateOpeningGate]
          rw [if_neg hcl2, if_neg hnotall, hact]
          dsimp only
          rw [dif_neg hNE]

/-! ### 5. Propagating `GreedyStateScanInv` Across Lines 7–10 & Full Trajectory -/

theorem installCompletedJobs_scanInv {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (K_batch : ℕ) (α : ℝ) :
    ∀ (nodes26 : List (Alg4ServingNode d ι × Bool)) (S_cur leaf1 : Finset ι)
      (leafAns0 : Option (ι × ι)) (leafSq0 : ℝ) (leafTicked : Bool),
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes26[idx]? = some p →
        ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
          GreedyJobScanInv K_batch α pts'
            (servingChainInputAt pts' (nodes26.map (fun q => q.1.toServingNodeState)) S_cur idx)
            job) →
      let (nodes78, _, _, _, _, _) :=
        alg4Lines7To8InstallCompletedJobs nodes26 leaf1 leafAns0 leafSq0 leafTicked
      ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes78[idx]? = some p →
        ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
          GreedyJobScanInv K_batch α pts'
            (servingChainInputAt pts' (nodes78.map (fun q => q.1.toServingNodeState)) S_cur idx)
            job
  | [], _, _, _, _, _, _ => fun _ _ h => by simp at h
  | (sn, aff) :: rest, S_cur, leaf1, leafAns0, leafSq0, leafTicked, hinv => by
      dsimp only [alg4Lines7To8InstallCompletedJobs]
      have h0 := hinv 0 (sn, aff) rfl
      rw [List.map_cons, servingChainInputAt_zero] at h0
      have hrest : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
          rest[idx]? = some p →
          ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
            GreedyJobScanInv K_batch α pts'
              (servingChainInputAt pts' (rest.map (fun q => q.1.toServingNodeState))
                (sn.node.residual pts' S_cur) idx)
              job := by
        intro idx p hp
        simpa [List.map_cons, servingChainInputAt_cons_succ] using hinv (idx + 1) p hp
      cases hown : sn.ownedJob with
      | none =>
        dsimp only
        have ih := installCompletedJobs_scanInv pts' K_batch α rest
          (sn.node.residual pts' S_cur) leaf1 leafAns0 leafSq0 leafTicked hrest
        rcases h78 : alg4Lines7To8InstallCompletedJobs rest leaf1 leafAns0 leafSq0 leafTicked with
          ⟨rest', _, _, _, _, _⟩
        rw [h78] at ih
        intro idx p hp job hjob
        cases idx with
        | zero =>
          simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
          subst hp; rw [hown] at hjob; cases hjob
        | succ idx =>
          simp only [List.getElem?_cons_succ] at hp
          rw [List.map_cons, servingChainInputAt_cons_succ]
          exact ih idx p hp job hjob
      | some j0 =>
        dsimp only
        by_cases hrdy : j0.IsReadyToInstall
        · rw [if_pos hrdy]
          dsimp only
          intro idx p hp job hjob
          rw [List.getElem?_map] at hp
          cases hget : j0.completedPrefix[idx]? with
          | none => rw [hget] at hp; simp at hp
          | some lv =>
            rw [hget] at hp
            simp only [Option.map_some, Option.some.injEq] at hp
            subst hp
            simp [installOpenedLevelAsServingNode] at hjob
        · rw [if_neg hrdy]
          dsimp only
          have ih := installCompletedJobs_scanInv pts' K_batch α rest
            (sn.node.residual pts' S_cur) leaf1 leafAns0 leafSq0 leafTicked hrest
          rcases h78 : alg4Lines7To8InstallCompletedJobs rest leaf1 leafAns0 leafSq0 leafTicked with
            ⟨rest', _, _, _, _, _⟩
          rw [h78] at ih
          intro idx p hp job hjob
          cases idx with
          | zero =>
            simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
            subst hp
            rw [List.map_cons, servingChainInputAt_zero]
            exact h0 job hjob
          | succ idx =>
            simp only [List.getElem?_cons_succ] at hp
            rw [List.map_cons, servingChainInputAt_cons_succ]
            exact ih idx p hp job hjob

theorem startDueServingJobsAux_scanInv {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (K_batch : ℕ) (α : ℝ) (L : ℕ) :
    ∀ (nodes : List (Alg4ServingNode d ι × Bool)) (S_cur leaf : Finset ι)
      (leafAns : Option (ι × ι)) (leafSq : ℝ) (leafCh : Bool),
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes[idx]? = some p →
        ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
          GreedyJobScanInv K_batch α pts'
            (servingChainInputAt pts' (nodes.map (fun q => q.1.toServingNodeState)) S_cur idx)
            job) →
      let (nodes₁, _, _, _, _, _) :=
        startDueServingJobsAux pts' α L S_cur nodes leaf leafAns leafSq leafCh
      ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes₁[idx]? = some p →
        ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
          GreedyJobScanInv K_batch α pts'
            (servingChainInputAt pts' (nodes₁.map (fun q => q.1.toServingNodeState)) S_cur idx)
            job
  | [], _, _, _, _, _, _ => fun _ _ h => by simp at h
  | (sn, nr) :: rest, S_cur, leaf, leafAns, leafSq, leafCh, hinv => by
      dsimp only [startDueServingJobsAux]
      have h0 := hinv 0 (sn, nr) rfl
      rw [List.map_cons, servingChainInputAt_zero] at h0
      have hrest : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
          rest[idx]? = some p →
          ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
            GreedyJobScanInv K_batch α pts'
              (servingChainInputAt pts' (rest.map (fun q => q.1.toServingNodeState))
                (sn.node.residual pts' S_cur) idx)
              job := by
        intro idx p hp
        simpa [List.map_cons, servingChainInputAt_cons_succ] using hinv (idx + 1) p hp
      by_cases hdue : sn.ownedJob.isNone ∧ jobStartAge α sn.birthSnapshot.card ≤ sn.age
      · rw [if_pos hdue]
        unfold scheduleJobStart
        by_cases hm_gt : 4 * L < S_cur.card
        · rw [if_pos hm_gt]
          dsimp only
          have ih := startDueServingJobsAux_scanInv pts' K_batch α L rest
            (sn.node.residual pts' S_cur) leaf leafAns leafSq leafCh hrest
          rcases hrec : startDueServingJobsAux pts' α L (sn.node.residual pts' S_cur)
              rest leaf leafAns leafSq leafCh with
            ⟨rest', _, _, _, _, _⟩
          rw [hrec] at ih
          intro idx p hp job hjob
          cases idx with
          | zero =>
            simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
            subst hp
            dsimp only at hjob
            injection hjob with hjob_eq; subst hjob_eq
            intro j lv hget
            simp [Alg4PendingJob.init] at hget
          | succ idx =>
            simp only [List.getElem?_cons_succ] at hp
            rw [List.map_cons, servingChainInputAt_cons_succ]
            simpa [Alg4ServingNode.toServingNodeState] using ih idx p hp job hjob
        · rw [if_neg hm_gt]
          intro _ _ h; simp at h
      · rw [if_neg hdue]
        have ih := startDueServingJobsAux_scanInv pts' K_batch α L rest
          (sn.node.residual pts' S_cur) leaf leafAns leafSq leafCh hrest
        rcases hrec : startDueServingJobsAux pts' α L (sn.node.residual pts' S_cur)
            rest leaf leafAns leafSq leafCh with
          ⟨rest', _, _, _, _, _⟩
        rw [hrec] at ih
        intro idx p hp job hjob
        cases idx with
        | zero =>
          simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
          subst hp
          rw [List.map_cons, servingChainInputAt_zero]
          exact h0 job hjob
        | succ idx =>
          simp only [List.getElem?_cons_succ] at hp
          rw [List.map_cons, servingChainInputAt_cons_succ]
          exact ih idx p hp job hjob

theorem greedyStateScanInv_step {d n : ℕ} {ι : Type}
    {mode : Alg4Mode} {α C : ℝ} {K₀ L reclaimMult D_out : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    {st : Alg4State d ι} {upd : Alg4PointUpdate d ι}
    (base : Alg4StepChoices d ι)
    (hinv : ReachableAlg4Inv n mode α L D_out st)
    (hscan : GreedyStateScanInv ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ α st)
    (hupd : IsValidAlg4PointUpdate n st upd) :
    let K_batch := ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊
    let choices := mkGreedyChoices mode K_batch st upd base
    Alg4StepSatisfiesEq11Completion mode α L st upd choices ∧
    GreedyStateScanInv K_batch α (alg4Step mode α L reclaimMult st upd choices).1 := by
  dsimp only
  set K_batch := ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊
  set choices := mkGreedyChoices mode K_batch st upd base
  have hL_pos : 1 ≤ L := cutoff_L_pos hα_pos hα_le hL
  rcases hinv with ⟨hwf_st, hreach_nodes⟩
  rcases hwf_st with ⟨_, hchain_wf, _, hleafSq_wf, hnodes_wf, _, _, _⟩
  set P' := applyAlg4PointSetUpdate st.activeSet upd
  set pts' := updateAlg4Coords st.coords upd
  have hpts_act : ∀ x ∈ st.activeSet, pts' x = st.coords x :=
    fun x hx => updateAlg4Coords_eq_on_liveRetainedIds hupd (activeSet_subset_liveRetainedIds st hx)
  let rootEv : PoolUpdateEvent ι := alg4RootEvent upd
  have hroot_ev : IsValidPoolUpdateEvent st.activeSet P' rootEv := by
    cases upd with
    | insert p pt => exact ⟨fun hp => hupd.1 (activeSet_subset_liveRetainedIds st hp), rfl⟩
    | delete p => exact ⟨hupd, rfl⟩
  have hl1_in : ∀ (idx : ℕ) (sn : Alg4ServingNode d ι),
      st.servingNodes[idx]? = some sn →
      let S_cur := servingChainInputAt st.coords
        (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet idx
      sn.trueAge ≤ sn.age ∧
      HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
      ServingNodePreRefreshWF mode st.coords S_cur sn ∧
      ServingNodeCacheWF mode st.coords S_cur sn := by
    intro idx sn hget
    have hi : idx < st.servingNodes.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
    rw [List.getElem?_eq_getElem hi] at hget
    injection hget with hget_eq; subst hget_eq
    have hwfi := hnodes_wf ⟨idx, hi⟩
    rw [Fin.getElem_fin] at hwfi
    rcases servingNodePreRefresh_and_cache_of_wellFormed hwfi with ⟨hpre, hcache⟩
    exact ⟨hwfi.2.1, hwfi.2.2.1, hpre, hcache⟩
  have hl1 := alg4Line1Aux_spec st.coords pts' mode st.servingNodes
    st.activeSet P' (some rootEv) choices.servingRouteQueries choices.servingRadiusMaxHints
    hpts_act hroot_ev hl1_in
  rcases hl1_eq : alg4Line1Aux pts' mode (some rootEv) st.servingNodes
      choices.servingRouteQueries choices.servingRadiusMaxHints with ⟨nodesLine1, leafEv⟩
  rw [hl1_eq] at hl1
  rcases hl1 with ⟨hLen1, _, hleaf_ev, hidx1⟩
  have hleaf_eq : st.terminalLeaf = servingChainInputAt st.coords
      (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet
      st.servingNodes.length := by
    simpa [Alg4State.toScheduledServingChain] using hchain_wf.2.1
  rw [← hleaf_eq] at hleaf_ev
  let leafLine1 : Finset ι := applyLeafPoolEvent st.terminalLeaf leafEv
  have hl1_apply_eq :
      alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
        choices.servingRouteQueries choices.servingRadiusMaxHints =
        (nodesLine1, leafLine1, leafEv.isClockTick) := by
    have h := alg4Line1ApplyToServingChain_eq pts' mode st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
    dsimp only [rootEv] at hl1_eq
    rw [hl1_eq] at h
    dsimp only at h
    exact h
  have hl1_base_eq :
      alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
        base.servingRouteQueries base.servingRadiusMaxHints =
        (nodesLine1, leafLine1, leafEv.isClockTick) := hl1_apply_eq
  rcases alg4Lines2To6StepPendingJobs_basic pts' mode α L nodesLine1 P' choices.pendingJobChoices with
    ⟨hLen26, hballs26, hidx26⟩
  set nodes26 := alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
  -- Prove Equation (11) & `GreedyJobScanInv` on every node in `nodes26`
  have h26_eq11_and_scan : ∀ (idx : ℕ) (p26 : Alg4ServingNode d ι × Bool),
      nodes26[idx]? = some p26 →
      ∀ job_out : Alg4PendingJob d ι, p26.1.ownedJob = some job_out →
        (∀ lv ∈ job_out.completedPrefix,
          maxLevelBuildTicks α lv.birthSnapshot.card ≤ lv.elapsedRootTicks →
            lv.backgroundReady = true) ∧
        GreedyJobScanInv K_batch α pts'
          (servingChainInputAt pts' (nodes26.map (fun q => q.1.toServingNodeState)) P' idx)
          job_out := by
    intro idx p26 hp26 job_out hjob_out
    have hi26 : idx < nodes26.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hp26; cases hp26
    have hi1 : idx < nodesLine1.length := by omega
    have hi0 : idx < st.servingNodes.length := by omega
    have hS_eq : servingChainInputAt pts'
        (nodes26.map (fun q => q.1.toServingNodeState)) P' idx =
        servingChainInputAt pts'
        (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx := by
      apply servingChainInputAt_eq_of_take_balls
      rw [List.map_take, List.map_take, hballs26]
    rw [hS_eq]
    rcases hidx1 idx (st.servingNodes[idx]'hi0) (nodesLine1[idx]'hi1)
      (List.getElem?_eq_getElem hi0) (List.getElem?_eq_getElem hi1) with
      ⟨hev1, _, _, _, hown1, _, _, _, _, _, hfalse1⟩
    have hs26 := hidx26 idx (nodesLine1[idx]'hi1) p26
      (List.getElem?_eq_getElem hi1) hp26
    by_cases hct : (nodesLine1[idx]'hi1).2.isClockTick = true
    · have hstep := hs26.2.2.2.2.2.2.2.2.2.2.2.2 hct
      cases hown0 : (st.servingNodes[idx]'hi0).ownedJob with
      | none =>
        rw [hown1, hown0] at hstep
        rw [hstep, hown1, hown0] at hjob_out; cases hjob_out
      | some job0 =>
        rw [hown1, hown0] at hstep
        dsimp only at hstep
        rw [hstep] at hjob_out
        injection hjob_out with hjob_eq; subst hjob_eq
        -- Show `(choices.pendingJobChoices.drop idx).head?.getD ...` equals the greedy choice!
        have hi_pjc : idx < choices.pendingJobChoices.length := by
          dsimp only [choices, mkGreedyChoices]
          rw [hl1_base_eq]
          simp only [List.length_map, List.length_range]
          exact lt_of_lt_of_le hi1 (Nat.le_max_right _ _)
        have hjc_drop : (choices.pendingJobChoices.drop idx).head?.getD
            { prefixRouteQueries := [], prefixRouteMaxHints := [], prefixBudgetSteps := [],
              openSampledCenter := .infeasible, openFallbackBirthId := none, leafHint := none } =
            choices.pendingJobChoices[idx]'hi_pjc :=
          drop_head_getD_eq_getElem _ _ hi_pjc
        set baseJc := (base.pendingJobChoices.drop idx).head?.getD (defaultJobStepChoices d ι)
        set S_idx' := servingChainInputAt pts' (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx
        have hjc_elem : choices.pendingJobChoices[idx]'hi_pjc =
            { baseJc with
              prefixBudgetSteps :=
                mkGreedyLevelBudgets pts' K_batch
                  (alg4Line3RouteThroughPrefix pts' mode job0 (nodesLine1[idx]'hi1).2 S_idx' baseJc).completedPrefix
                  S_idx' } := by
          have hopt : (mkGreedyChoices mode K_batch st upd base).pendingJobChoices[idx]? =
              some { baseJc with
                prefixBudgetSteps :=
                  mkGreedyLevelBudgets pts' K_batch
                    (alg4Line3RouteThroughPrefix pts' mode job0 (nodesLine1[idx]'hi1).2 S_idx' baseJc).completedPrefix
                    S_idx' } := by
            unfold mkGreedyChoices
            dsimp only
            rw [hl1_base_eq]
            dsimp only
            have hi_max : idx < max base.pendingJobChoices.length nodesLine1.length :=
              lt_of_lt_of_le hi1 (Nat.le_max_right _ _)
            rw [List.getElem?_map, List.getElem?_range hi_max, Option.map_some,
              List.getElem?_eq_getElem hi1, ← Prod.eta (nodesLine1[idx]'hi1)]
            dsimp only
            rw [if_pos hct, hown1, hown0]
          change choices.pendingJobChoices[idx]? = _ at hopt
          rw [List.getElem?_eq_getElem hi_pjc] at hopt
          exact Option.some.inj hopt
        rw [hjc_drop, hjc_elem]
        have hjwf0 : job0.WellFormed mode α L st.coords (st.servingInputAt idx) := by
          have h9 := (hnodes_wf ⟨idx, hi0⟩).2.2.2.2.2.2.2.2
          rw [Fin.getElem_fin, hown0] at h9; exact h9
        have hjsched0 := (hreach_nodes idx (st.servingNodes[idx]'hi0) (List.getElem?_eq_getElem hi0)).2 job0 hown0
        have hjscan0 := hscan idx (st.servingNodes[idx]'hi0) (List.getElem?_eq_getElem hi0) job0 hown0
        have hpts_S : ∀ x ∈ st.servingInputAt idx, pts' x = st.coords x :=
          fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
        have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi0)
        have hpts_B : ∀ lv ∈ job0.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts' x = st.coords x :=
          fun lv hlv x hx =>
            updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job0 hown0).2 lv hlv).1 hx)
        exact stepGreedyPendingJob_eq11_and_scan hα_pos hα_le hL baseJc
          hpts_S hpts_B hev1 hjwf0 hjsched0 hjscan0
    · have hctf : (nodesLine1[idx]'hi1).2.isClockTick = false := Bool.eq_false_iff.mpr hct
      have hp26_eq : p26.1 = st.servingNodes[idx]'hi0 :=
        (hs26.2.2.2.2.2.2.2.2.2.2.2.1 hctf).trans (hfalse1 hctf).1
      have hS_same : servingChainInputAt pts'
          (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx =
          st.servingInputAt idx := (hfalse1 hctf).2.1
      rw [hp26_eq] at hjob_out
      rw [hS_same]
      have hjscan0 := hscan idx (st.servingNodes[idx]'hi0) (List.getElem?_eq_getElem hi0) job_out hjob_out
      have hpts_S : ∀ x ∈ st.servingInputAt idx, pts' x = st.coords x :=
        fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
      have hjscan0' := greedyJobScanInv_congr hjscan0 hpts_S
      refine ⟨?_, hjscan0'⟩
      intro lv hlv hge
      rcases List.mem_iff_getElem.mp hlv with ⟨j, hj, rfl⟩
      by_cases hrdy : (job_out.completedPrefix[j]'hj).backgroundReady = true
      · exact hrdy
      · have hrdy_f : (job_out.completedPrefix[j]'hj).backgroundReady = false := Bool.eq_false_iff.mpr hrdy
        have hlt := (hjscan0' j (job_out.completedPrefix[j]'hj) (List.getElem?_eq_getElem hj) hrdy_f).1
        omega
  have heq11_out : Alg4StepSatisfiesEq11Completion mode α L st upd choices := by
    unfold Alg4StepSatisfiesEq11Completion
    dsimp only
    rw [show applyAlg4PointSetUpdate st.activeSet upd = P' from rfl,
      show updateAlg4Coords st.coords upd = pts' from rfl, hl1_apply_eq]
    dsimp only
    intro p26 hp26 job_out hjob_out lv hlv hge
    rcases List.mem_iff_getElem.mp hp26 with ⟨idx, hi26, rfl⟩
    exact (h26_eq11_and_scan idx (nodes26[idx]'hi26) (List.getElem?_eq_getElem hi26) job_out hjob_out).1 lv hlv hge
  refine ⟨heq11_out, ?_⟩
  -- Propagate `GreedyJobScanInv` through Lines 7–8, Line 9, and Line 10
  have h26_scan : ∀ (idx : ℕ) (p26 : Alg4ServingNode d ι × Bool),
      nodes26[idx]? = some p26 →
      ∀ job_out : Alg4PendingJob d ι, p26.1.ownedJob = some job_out →
        GreedyJobScanInv K_batch α pts'
          (servingChainInputAt pts' (nodes26.map (fun q => q.1.toServingNodeState)) P' idx)
          job_out :=
    fun idx p26 hp26 job_out hjob_out => (h26_eq11_and_scan idx p26 hp26 job_out hjob_out).2
  have hleafLine1_eq : leafLine1 = servingChainInputAt pts'
      (nodesLine1.map (fun p => p.1.toServingNodeState)) P' nodesLine1.length := by
    cases leafEv with
    | externalInsert p => exact hleaf_ev.2.symm
    | externalDelete p => exact hleaf_ev.2.symm
    | virtualValueDelete => exact hleaf_ev.symm
    | unaffected => exact hleaf_ev.symm
  have hleafLine1_26 : leafLine1 = servingChainInputAt pts'
      (nodes26.map (fun p => p.1.toServingNodeState)) P' nodes26.length := by
    rw [hleafLine1_eq, ← hLen26]
    symm
    apply servingChainInputAt_eq_of_take_balls
    rw [List.map_take, List.map_take, hballs26]
  have hleafTick_false : leafEv.isClockTick = false →
      IsExactLeafAnswer pts' leafLine1 st.terminalLeafAnswer ∧
      st.terminalLeafDistSq = (baselinePairLength pts' st.terminalLeafAnswer) ^ 2 := by
    intro hltf
    have hl_same : leafLine1 = st.terminalLeaf := by
      cases leafEv <;> simp [PoolUpdateEvent.isClockTick] at hltf <;> rfl
    rw [hl_same]
    have hsub_leaf : st.terminalLeaf ⊆ st.activeSet := by
      rw [hleaf_eq]; exact servingChainInputAt_subset _ _ _ _
    have hpts_leaf : ∀ x ∈ st.terminalLeaf, st.coords x = pts' x :=
      fun x hx => (hpts_act x (hsub_leaf hx)).symm
    have hex0 : IsExactLeafAnswer st.coords st.terminalLeaf st.terminalLeafAnswer :=
      hchain_wf.2.2
    exact ⟨(isExactLeafAnswer_congr st.terminalLeafAnswer hpts_leaf).mp hex0,
      hleafSq_wf.trans (by rw [baselinePairLength_congr_exact hex0 hpts_leaf])⟩
  have h26_dwf : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
      nodes26[idx]? = some p →
      let S_idx := servingChainInputAt pts'
        (nodes26.map (fun q => q.1.toServingNodeState)) P' idx
      TaggedNodeDataWF mode pts' S_idx p ∧
      ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
        PendingJobDataWF mode α L pts' S_idx job := by
    intro idx p26 hp26
    have hi26 : idx < nodes26.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hp26; cases hp26
    have hi1 : idx < nodesLine1.length := by omega
    have hi0 : idx < st.servingNodes.length := by omega
    have hS_eq : servingChainInputAt pts'
        (nodes26.map (fun q => q.1.toServingNodeState)) P' idx =
        servingChainInputAt pts'
        (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx := by
      apply servingChainInputAt_eq_of_take_balls
      rw [List.map_take, List.map_take, hballs26]
    rcases hidx1 idx (st.servingNodes[idx]'hi0) (nodesLine1[idx]'hi1)
      (List.getElem?_eq_getElem hi0) (List.getElem?_eq_getElem hi1) with
      ⟨hev1, _, _, _, hown1, _, _, _, _, hpre1, hfalse1⟩
    have hs26 := hidx26 idx (nodesLine1[idx]'hi1) p26
      (List.getElem?_eq_getElem hi1) hp26
    dsimp only
    rw [hS_eq]
    refine ⟨⟨⟨?_, ?_⟩, ?_⟩, ?_⟩
    · unfold RadiusDictState.IsComplete
      rw [hs26.2.2.1, hs26.2.2.2.2.2.1]; exact hpre1.1
    · rw [hs26.2.2.1, hs26.2.2.2.2.2.2.1]; exact hpre1.2
    · intro hp2f
      rw [hs26.1] at hp2f
      rw [hs26.2.2.2.2.2.2.2.2.2.2.2.1 hp2f]
      exact (hfalse1 hp2f).2.2
    · intro job' hjob'
      by_cases hct : (nodesLine1[idx]'hi1).2.isClockTick = true
      · have hstep := hs26.2.2.2.2.2.2.2.2.2.2.2.2 hct
        cases hown_l1 : (nodesLine1[idx]'hi1).1.ownedJob with
        | none => rw [hown_l1] at hstep; rw [hstep, hown_l1] at hjob'; cases hjob'
        | some job0 =>
          rw [hown_l1] at hstep; rw [hstep] at hjob'
          dsimp only at hjob'
          injection hjob' with hj_eq; subst hj_eq
          have hown0 : (st.servingNodes[idx]'hi0).ownedJob = some job0 := by rw [← hown1]; exact hown_l1
          have hjob_wf := (hnodes_wf ⟨idx, hi0⟩).2.2.2.2.2.2.2.2
          rw [Fin.getElem_fin, hown0] at hjob_wf
          have hpts_S : ∀ x ∈ st.servingInputAt idx, pts' x = st.coords x :=
            fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
          have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi0)
          have hpts_B : ∀ lv ∈ job0.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts' x = st.coords x :=
            fun lv hlv x hx =>
              updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job0 hown0).2 lv hlv).1 hx)
          exact stepSinglePendingJob_dataWF hα_le _ hpts_S hpts_B hev1 (pendingJobDataWF_of_wellFormed hjob_wf)
      · have hctf : (nodesLine1[idx]'hi1).2.isClockTick = false := Bool.eq_false_iff.mpr hct
        have hsn_eq : p26.1 = st.servingNodes[idx]'hi0 :=
          (hs26.2.2.2.2.2.2.2.2.2.2.2.1 hctf).trans (hfalse1 hctf).1
        have hS_same : servingChainInputAt pts'
            (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx =
            st.servingInputAt idx := (hfalse1 hctf).2.1
        rw [hsn_eq] at hjob'
        rw [hS_same]
        have hjob_wf := (hnodes_wf ⟨idx, hi0⟩).2.2.2.2.2.2.2.2
        rw [Fin.getElem_fin, hjob'] at hjob_wf
        have hpts_S : ∀ x ∈ st.servingInputAt idx, pts' x = st.coords x :=
          fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
        have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi0)
        have hpts_B : ∀ lv ∈ job'.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts' x = st.coords x :=
          fun lv hlv x hx =>
            updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job' hjob').2 lv hlv).1 hx)
        exact pendingJobDataWF_congr (pendingJobDataWF_of_wellFormed hjob_wf) hpts_S hpts_B
  have h78_dwf := alg4Lines7To8InstallCompletedJobs_dataWF pts' mode α L D_out
    nodes26 P' leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick
    hleafLine1_26 hleafTick_false h26_dwf
  have h78_scan := installCompletedJobs_scanInv pts' K_batch α nodes26 P'
    leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick h26_scan
  rcases h78_eq : alg4Lines7To8InstallCompletedJobs nodes26
      leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick with
    ⟨nodes78, leaf78, leafAns78, leafSq78, leafCh78, retired78⟩
  rw [h78_eq] at h78_dwf h78_scan
  rcases h78_dwf with ⟨hleaf78, hlch78, htag78, _⟩
  have h9_dwf := alg4Line9StartDueJobsAndHandleLeaves_dataWF (D_out := D_out)
    hα_pos hα_le hL_pos P' nodes78 leaf78 leafAns78 leafSq78 leafCh78
    choices.leafRebuildChoices choices.terminalLeafHint hleaf78 hlch78 htag78
  have h9_scan :
      let (nodes9, _, _, _, _) :=
        alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
          nodes78 leaf78 leafAns78 leafSq78 leafCh78
          choices.leafRebuildChoices choices.terminalLeafHint
      ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes9[idx]? = some p →
        ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
          GreedyJobScanInv K_batch α pts'
            (servingChainInputAt pts' (nodes9.map (fun q => q.1.toServingNodeState)) P' idx)
            job := by
    dsimp only [alg4Line9StartDueJobsAndHandleLeaves]
    have hs_due := startDueServingJobsAux_scanInv pts' K_batch α L
      nodes78 P' leaf78 leafAns78 leafSq78 leafCh78 h78_scan
    have hs_dwf := startDueServingJobsAux_dataWF pts' mode α L D_out
      nodes78 P' leaf78 leafAns78 leafSq78 leafCh78 hleaf78 hlch78 htag78
    rcases hdue_eq : startDueServingJobsAux pts' α L P' nodes78 leaf78 leafAns78 leafSq78 leafCh78 with
      ⟨nodes₁, leaf₁, leafAns₁, leafSq₁, leafCh₁, retired₁⟩
    rw [hdue_eq] at hs_due hs_dwf
    by_cases hgt : 6 * L < leaf₁.card
    · rw [if_pos hgt]
      have hreb := rebuildOversizedLeafAux_fuel (pts' := pts') (mode := mode)
        hα_pos hα_le hL_pos leaf₁.card leaf₁ choices.leafRebuildChoices le_rfl
      rcases hreb_eq : rebuildOversizedLeafAux pts' mode α L leaf₁.card leaf₁ choices.leafRebuildChoices with
        ⟨rebuiltNodes, finalLeaf⟩
      rw [hreb_eq] at hreb
      rcases servingChainInputAt_append pts'
          (nodes₁.map (fun p => p.1.toServingNodeState))
          (rebuiltNodes.map (fun p => p.1.toServingNodeState)) P' with
        ⟨happ_left, _⟩
      dsimp only
      intro idx p hp job hjob
      rw [List.map_append]
      by_cases hlt_idx : idx < nodes₁.length
      · rw [List.getElem?_append_left hlt_idx] at hp
        rw [happ_left idx (by simp; omega)]
        exact hs_due idx p hp job hjob
      · rw [List.getElem?_append_right (Nat.le_of_not_lt hlt_idx)] at hp
        have hmem_reb : p ∈ rebuiltNodes := List.mem_of_getElem? hp
        have hown_none := (hreb.2.2.2.2.2 p hmem_reb).2.2.2.2.2.2.1
        rw [hown_none] at hjob; cases hjob
    · rw [if_neg hgt]
      by_cases hch : leafCh₁ = true
      · rw [if_pos hch]; exact hs_due
      · rw [if_neg hch]; exact hs_due
  rcases h9_eq : alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
      nodes78 leaf78 leafAns78 leafSq78 leafCh78
      choices.leafRebuildChoices choices.terminalLeafHint with
    ⟨nodes9, finalLeaf, finalLeafAns, finalLeafSq, retiredDue⟩
  rw [h9_eq] at h9_dwf h9_scan
  rcases alg4Line10RefreshAffectedCaches_spec pts' mode nodes9 P'
      choices.baselineSamples choices.matchingMaxHints h9_dwf.2.2.2.1 with
    ⟨hLen10, _, hidx10⟩
  set finalNodes := alg4Line10RefreshAffectedCaches pts' mode P' nodes9
    choices.baselineSamples choices.matchingMaxHints
  have hstep_fields :
      (alg4Step mode α L reclaimMult st upd choices).1.activeSet = P' ∧
      (alg4Step mode α L reclaimMult st upd choices).1.coords = pts' ∧
      (alg4Step mode α L reclaimMult st upd choices).1.servingNodes = finalNodes := by
    unfold alg4Step
    dsimp only
    rw [show applyAlg4PointSetUpdate st.activeSet upd = P' from rfl,
      show updateAlg4Coords st.coords upd = pts' from rfl, hl1_apply_eq]
    dsimp only
    rw [show alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices = nodes26 from rfl]
    rw [h78_eq]
    dsimp only
    rw [h9_eq]
    exact ⟨rfl, rfl, rfl⟩
  intro idx sn_out hget_out job hjob_out
  rw [hstep_fields.2.2] at hget_out
  unfold Alg4State.servingInputAt
  rw [hstep_fields.1, hstep_fields.2.1, hstep_fields.2.2]
  have hi_fn : idx < finalNodes.length := by
    by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget_out; cases hget_out
  have hi9 : idx < nodes9.length := by omega
  rw [List.getElem?_eq_getElem hi_fn] at hget_out
  injection hget_out with hout_eq; subst hout_eq
  rcases hidx10 idx (nodes9[idx]'hi9) (finalNodes[idx]'hi_fn)
    (List.getElem?_eq_getElem hi9) (List.getElem?_eq_getElem hi_fn) with
    ⟨hS_eq10, _, _, _, _, hown_eq10, _, _⟩
  rw [hown_eq10] at hjob_out
  rw [hS_eq10]
  exact h9_scan idx (nodes9[idx]'hi9) (List.getElem?_eq_getElem hi9) job hjob_out

/-! ### 6. Maximum Outdegree Witness & Full Trajectory Existence (`exists_greedy_eq11_trajectory`) -/

def retiredChildrenMaxDeg {ι : Type} : RetiredRecord ι → ℕ
  | .leaf _ => 0
  | .consChild c tail =>
      max (max c.children.length (retiredChildrenMaxDeg c)) (retiredChildrenMaxDeg tail)

def retiredRecordMaxDeg {ι : Type} (r : RetiredRecord ι) : ℕ :=
  max r.children.length (retiredChildrenMaxDeg r)

def retiredListMaxDeg {ι : Type} : List (RetiredRecord ι) → ℕ
  | [] => 0
  | r :: rs => max (retiredRecordMaxDeg r) (retiredListMaxDeg rs)

theorem childrenBounded_mono {ι : Type} {D₁ D₂ : ℕ} (hle : D₁ ≤ D₂) :
    ∀ r : RetiredRecord ι, r.childrenBounded D₁ → r.childrenBounded D₂
  | .leaf _, _ => trivial
  | .consChild c tail, ⟨⟨hc_len, hc_b⟩, htail⟩ =>
      ⟨⟨le_trans hc_len hle, childrenBounded_mono hle c hc_b⟩,
        childrenBounded_mono hle tail htail⟩

theorem hasBoundedOutdegree_mono {ι : Type} {D₁ D₂ : ℕ} (hle : D₁ ≤ D₂)
    (r : RetiredRecord ι) (hr : r.HasBoundedOutdegree D₁) :
    r.HasBoundedOutdegree D₂ :=
  ⟨le_trans hr.1 hle, childrenBounded_mono hle r hr.2⟩

theorem childrenBounded_self {ι : Type} :
    ∀ r : RetiredRecord ι, r.childrenBounded (retiredChildrenMaxDeg r)
  | .leaf _ => trivial
  | .consChild c tail =>
      ⟨hasBoundedOutdegree_mono (Nat.le_max_left _ _) c
          ⟨Nat.le_max_left _ _,
            childrenBounded_mono (Nat.le_max_right _ _) c (childrenBounded_self c)⟩,
        childrenBounded_mono (Nat.le_max_right _ _) tail (childrenBounded_self tail)⟩

theorem hasBoundedOutdegree_self {ι : Type} (r : RetiredRecord ι) :
    r.HasBoundedOutdegree (retiredRecordMaxDeg r) :=
  ⟨Nat.le_max_left _ _,
    childrenBounded_mono (Nat.le_max_right _ _) r (childrenBounded_self r)⟩

theorem mem_retiredListMaxDeg_bounded {ι : Type} :
    ∀ (rs : List (RetiredRecord ι)) {D : ℕ},
      retiredListMaxDeg rs ≤ D → ∀ r ∈ rs, r.HasBoundedOutdegree D
  | [], _, _, _, hr => by cases hr
  | r₀ :: rs, D, hle, r, hr => by
      dsimp only [retiredListMaxDeg] at hle
      rcases List.mem_cons.mp hr with rfl | hmem
      · exact hasBoundedOutdegree_mono (le_trans (Nat.le_max_left _ _) hle) r (hasBoundedOutdegree_self r)
      · exact mem_retiredListMaxDeg_bounded rs (le_trans (Nat.le_max_right _ _) hle) r hmem

noncomputable def runGreedyAux {d T : ℕ} {ι : Type}
    (mode : Alg4Mode) (α : ℝ) (L reclaimMult K_batch : ℕ)
    (upd : Fin T → Alg4PointUpdate d ι)
    (baseChoices : Fin T → Alg4StepChoices d ι) :
    ℕ → Alg4State d ι
  | 0 => Alg4State.empty d ι
  | k + 1 =>
      if hk : k < T then
        let st_k := runGreedyAux mode α L reclaimMult K_batch upd baseChoices k
        let ch_k := mkGreedyChoices mode K_batch st_k (upd ⟨k, hk⟩) (baseChoices ⟨k, hk⟩)
        (alg4Step mode α L reclaimMult st_k (upd ⟨k, hk⟩) ch_k).1
      else
        Alg4State.empty d ι

theorem le_list_sum_of_mem : ∀ {xs : List ℕ} {x : ℕ}, x ∈ xs → x ≤ xs.sum
  | [], _, h => by cases h
  | y :: ys, x, h => by
      rcases List.mem_cons.mp h with rfl | hmem
      · simp
      · have := le_list_sum_of_mem hmem; simp; omega

theorem exists_greedy_eq11_trajectory {d n T : ℕ} {ι : Type}
    {mode : Alg4Mode} {α C : ℝ} {K₀ L reclaimMult : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (upd : Fin T → Alg4PointUpdate d ι)
    (baseChoices : Fin T → Alg4StepChoices d ι) :
    ∃ (choices : Fin T → Alg4StepChoices d ι)
      (st : Fin (T + 1) → Alg4State d ι)
      (ans : Fin T → Option (ι × ι) × ℝ),
      st 0 = Alg4State.empty d ι ∧
      (∀ t : Fin T,
        Alg4StepChoicesAgreeExceptScanBudgets (baseChoices t) (choices t) ∧
        Alg4ChoicesRespectScanBatchCap
          ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊ (choices t) ∧
        alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t) =
          (st t.succ, ans t)) ∧
      ((∀ t : Fin T, IsValidAlg4PointUpdate n (st t.castSucc) (upd t)) →
        ∀ t : Fin T,
          Alg4StepSatisfiesEq11Completion mode α L
            (st t.castSucc) (upd t) (choices t)) := by
  set K_batch := ⌈cBatchVal * (scheduleCStar : ℝ) * (α ^ 2)⁻¹⌉₊
  let st : Fin (T + 1) → Alg4State d ι :=
    fun s => runGreedyAux mode α L reclaimMult K_batch upd baseChoices s.val
  let choices : Fin T → Alg4StepChoices d ι :=
    fun t => mkGreedyChoices mode K_batch (st t.castSucc) (upd t) (baseChoices t)
  let ans : Fin T → Option (ι × ι) × ℝ :=
    fun t => (alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t)).2
  refine ⟨choices, st, ans, rfl, ?_, ?_⟩
  · intro t
    refine ⟨mkGreedyChoices_agree _ _ _ _ _, mkGreedyChoices_cap _ _ _ _ _, ?_⟩
    apply Prod.ext
    · dsimp only [st, Fin.val_succ, runGreedyAux]
      rw [dif_pos t.isLt]
      rfl
    · rfl
  · intro hvalid
    set D_traj : ℕ :=
      1 + ((List.finRange T).map (fun t => retiredListMaxDeg (baseChoices t).stepExtraRetired)).sum
    have hD_pos : 1 ≤ D_traj := by omega
    have hextra_bounded : ∀ t : Fin T, ∀ r ∈ (choices t).stepExtraRetired,
        r.HasBoundedOutdegree D_traj := by
      intro t r hr
      have hmem : retiredListMaxDeg (baseChoices t).stepExtraRetired ∈
          (List.finRange T).map (fun x => retiredListMaxDeg (baseChoices x).stepExtraRetired) :=
        List.mem_map_of_mem (List.mem_finRange t)
      have hle_sum := le_list_sum_of_mem hmem
      have hle_D : retiredListMaxDeg (baseChoices t).stepExtraRetired ≤ D_traj := by omega
      exact mem_retiredListMaxDeg_bounded _ hle_D r hr
    have htraj_inv : ∀ k : ℕ, (hk : k ≤ T) →
        ReachableAlg4Inv n mode α L D_traj (st ⟨k, Nat.lt_succ_of_le hk⟩) ∧
        GreedyStateScanInv K_batch α (st ⟨k, Nat.lt_succ_of_le hk⟩) := by
      intro k
      induction k with
      | zero =>
        intro _
        exact ⟨reachableAlg4Inv_empty ι mode α L D_traj, greedyStateScanInv_empty ι K_batch α⟩
      | succ k ih =>
        intro hk
        have hk_lt : k < T := hk
        let t : Fin T := ⟨k, hk_lt⟩
        rcases ih (le_of_lt hk_lt) with ⟨hreach_k, hscan_k⟩
        have hcs_eq : st t.castSucc = st ⟨k, Nat.lt_succ_of_le (le_of_lt hk_lt)⟩ := rfl
        rw [← hcs_eq] at hreach_k hscan_k
        rcases greedyStateScanInv_step (reclaimMult := reclaimMult) hα_pos hα_le hL
            (baseChoices t) hreach_k hscan_k (hvalid t) with ⟨heq11_t, hscan_next⟩
        have hreach_next := reachableAlg4Inv_step (reclaimMult := reclaimMult)
          hα_pos hα_le hL hD_pos hreach_k (hvalid t) heq11_t (hextra_bounded t)
        have hsucc_eq : (alg4Step mode α L reclaimMult (st t.castSucc) (upd t) (choices t)).1 =
            st ⟨k + 1, Nat.lt_succ_of_le hk⟩ := by
          dsimp only [st, runGreedyAux]
          rw [dif_pos hk_lt]
          rfl
        rw [hsucc_eq] at hreach_next hscan_next
        exact ⟨hreach_next, hscan_next⟩
    intro t
    rcases htraj_inv t.val (le_of_lt t.isLt) with ⟨hreach_t, hscan_t⟩
    exact (greedyStateScanInv_step (reclaimMult := reclaimMult) hα_pos hα_le hL
      (baseChoices t) hreach_t hscan_t (hvalid t)).1

end UL.Proof.claim_C_2_space_reclaim.RacerP44
