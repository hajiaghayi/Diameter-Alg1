import UL.Proof.claim_C_2_space_reclaim.RacerP44_H3a

set_option autoImplicit false

namespace UL.Proof.claim_C_2_space_reclaim.RacerP44

open Classical
open UL
open UL.Proof.lem_C_2.H1
open UL.Proof.claim_C_2_space_reclaim

/-! ### 1. Logarithmic, `D₀`, and `L_log` Bounds -/

theorem alpha_inv_ge_one {α : ℝ} (hα_pos : 0 < α) (hα_le : α ≤ 1) :
    1 ≤ α⁻¹ := by
  have h := mul_le_mul_of_nonneg_right hα_le (inv_nonneg.mpr (le_of_lt hα_pos))
  rwa [mul_inv_cancel₀ (ne_of_gt hα_pos), one_mul] at h

theorem d0_and_llog_bounds {n : ℕ} {α : ℝ}
    (h2n : 2 ≤ n) (hα_pos : 0 < α) (hα_le : α ≤ 1) :
    let L_log : ℕ := Nat.clog 2 (2 * n)
    let D₀ : ℕ := ⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊
    1 ≤ D₀ ∧
    12 ≤ D₀ ∧
    (D₀ : ℝ) ≤ (cDepthVal + 2) * α⁻¹ * Real.log (n : ℝ) ∧
    L_log + 1 ≤ D₀ ∧
    (∀ (P_α : ℕ → ℕ → ℝ) (d : ℕ),
      α⁻¹ ≤ P_α d L_log → (D₀ : ℝ) ≤ mkDBound P_α d L_log) := by
  dsimp only
  set L_log : ℕ := Nat.clog 2 (2 * n)
  set D₀ : ℕ := ⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊
  have ha_inv : 1 ≤ α⁻¹ := alpha_inv_ge_one hα_pos hα_le
  have hn_pos : (0 : ℝ) < (n : ℝ) := by
    have : 0 < n := by omega
    exact_mod_cast this
  have h2_le_n : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast h2n
  have hlog2_gt := Real.log_two_gt_d9
  have hlog2_lt := Real.log_two_lt_d9
  have hlog2_le_n : Real.log 2 ≤ Real.log (n : ℝ) := Real.log_le_log (by norm_num) h2_le_n
  have hlog_n_lb : 0.69 < Real.log (n : ℝ) := by linarith
  have hprod_lb : 16 * Real.log (n : ℝ) ≤ cDepthVal * α⁻¹ * Real.log (n : ℝ) := by
    unfold cDepthVal
    have h16 : (16 : ℝ) * 1 ≤ 16 * α⁻¹ := by linarith
    have hmul := mul_le_mul_of_nonneg_right h16 (le_of_lt (by linarith : 0 < Real.log (n : ℝ)))
    linarith
  have hD0_r_lb : 16 * Real.log (n : ℝ) ≤ (D₀ : ℝ) :=
    le_trans hprod_lb (Nat.le_ceil _)
  have hD0_gt_11 : (11 : ℝ) < (D₀ : ℝ) := by linarith
  have h12_le : 12 ≤ D₀ := by
    have : 11 < D₀ := by exact_mod_cast hD0_gt_11
    omega
  have h1_le : 1 ≤ D₀ := by omega
  have hD0_ub : (D₀ : ℝ) ≤ (cDepthVal + 2) * α⁻¹ * Real.log (n : ℝ) := by
    have hceil_lt : (D₀ : ℝ) < cDepthVal * α⁻¹ * Real.log (n : ℝ) + 1 :=
      Nat.ceil_lt_add_one (by unfold cDepthVal; positivity)
    have h1_le_2 : 1 ≤ 2 * α⁻¹ * Real.log (n : ℝ) := by
      have : 1 * (0.69 : ℝ) ≤ α⁻¹ * Real.log (n : ℝ) :=
        mul_le_mul ha_inv (le_of_lt hlog_n_lb) (by norm_num) (by linarith)
      linarith
    linarith
  -- Upper bound `Real.log n ≤ L_log`
  have hpow_clog : 2 * n ≤ 2 ^ L_log := Nat.le_pow_clog (by omega) (2 * n)
  have hn_le_pow : (n : ℝ) ≤ (2 : ℝ) ^ L_log := by
    have : n ≤ 2 ^ L_log := by omega
    exact_mod_cast this
  have hlog_le_Llog : Real.log (n : ℝ) ≤ (L_log : ℝ) := by
    have h1 := Real.log_le_log hn_pos hn_le_pow
    rw [Real.log_pow] at h1
    have hL_nn : (0 : ℝ) ≤ (L_log : ℝ) := Nat.cast_nonneg _
    have h2 : (L_log : ℝ) * Real.log 2 ≤ (L_log : ℝ) * 1 :=
      mul_le_mul_of_nonneg_left (by linarith) hL_nn
    linarith
  -- Lower bound `L_log + 1 ≤ D₀` via `2 * n ≤ 2 ^ (D₀ - 1)`
  have hLlog_succ_le : L_log + 1 ≤ D₀ := by
    have hclog_le : L_log ≤ D₀ - 1 := by
      rw [Nat.clog_le_iff_le_pow (by omega)]
      have hsub_cast : ((D₀ - 1 : ℕ) : ℝ) = (D₀ : ℝ) - 1 := by rw [Nat.cast_sub h1_le, Nat.cast_one]
      have hlog_lhs : Real.log (2 * (n : ℝ)) = Real.log 2 + Real.log (n : ℝ) :=
        Real.log_mul (by norm_num) (ne_of_gt hn_pos)
      have hlog_rhs : Real.log ((2 : ℝ) ^ (D₀ - 1)) = ((D₀ - 1 : ℕ) : ℝ) * Real.log 2 :=
        Real.log_pow 2 (D₀ - 1)
      have hlt_log : Real.log (2 * (n : ℝ)) < Real.log ((2 : ℝ) ^ (D₀ - 1)) := by
        rw [hlog_lhs, hlog_rhs, hsub_cast]
        have hD1_nn : 0 ≤ (D₀ : ℝ) - 1 := by linarith
        have hmul_log2 : ((D₀ : ℝ) - 1) * 0.69 ≤ ((D₀ : ℝ) - 1) * Real.log 2 :=
          mul_le_mul_of_nonneg_left (by linarith) hD1_nn
        linarith
      have hlt_pow : 2 * (n : ℝ) < (2 : ℝ) ^ (D₀ - 1) :=
        (Real.log_lt_log_iff (by positivity) (by positivity)).mp hlt_log
      have hle_pow_r : ((2 * n : ℕ) : ℝ) ≤ (((2 ^ (D₀ - 1) : ℕ)) : ℝ) := by
        push_cast
        exact le_of_lt hlt_pow
      exact Nat.cast_le.mp hle_pow_r
    omega
  refine ⟨h1_le, h12_le, hD0_ub, hLlog_succ_le, ?_⟩
  intro P_α d hPα
  unfold mkDBound
  have h18 : cDepthVal + 2 = 18 := by unfold cDepthVal; norm_num
  rw [h18] at hD0_ub
  have hmax_α : α⁻¹ ≤ max 1 (P_α d L_log) := le_trans hPα (le_max_right 1 _)
  have hlog_succ : Real.log (n : ℝ) ≤ ((L_log + 1 : ℕ) : ℝ) := by
    push_cast; linarith
  have hm1 : α⁻¹ * Real.log (n : ℝ) ≤ max 1 (P_α d L_log) * ((L_log + 1 : ℕ) : ℝ) :=
    mul_le_mul hmax_α hlog_succ (by linarith) (le_trans (by norm_num) (le_max_left 1 _))
  linarith

/-! ### 2. Geometric Contraction List Lemmas (Length `≤ D₀` & Telescoping Sum `≤ 4 n α⁻¹`) -/

theorem contraction_list_getElem_le {α : ℝ} (hα_le : α ≤ 1)
    (xs : List ℕ)
    (hstep : ∀ (i x y : ℕ), xs[i]? = some x → xs[i + 1]? = some y →
      (y : ℝ) ≤ ((1 : ℝ) - α / 4) * (x : ℝ)) :
    ∀ (i : ℕ) (hi : i < xs.length),
      ((xs[i]'hi : ℕ) : ℝ) ≤ ((1 : ℝ) - α / 4) ^ i * ((xs[0]'(by omega) : ℕ) : ℝ)
  | 0, _ => by simp
  | i + 1, hi => by
      have hi0 : i < xs.length := Nat.lt_of_succ_lt hi
      have ih := contraction_list_getElem_le hα_le xs hstep i hi0
      have hst := hstep i (xs[i]'hi0) (xs[i + 1]'hi)
        (List.getElem?_eq_getElem hi0) (List.getElem?_eq_getElem hi)
      have h1_nn : 0 ≤ (1 : ℝ) - α / 4 := by linarith
      have hmul := mul_le_mul_of_nonneg_left ih h1_nn
      exact le_trans hst (by rw [pow_succ', mul_assoc]; exact hmul)

theorem contraction_list_length_le {n : ℕ} {α : ℝ}
    (h2n : 2 ≤ n) (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (xs : List ℕ)
    (h0 : ∀ x : ℕ, xs[0]? = some x → x ≤ n)
    (hlast : ∀ k : ℕ, (hk_len : xs.length = k + 1) → 2 < ((xs[k]'(by omega) : ℕ) : ℝ))
    (hstep : ∀ (i x y : ℕ), xs[i]? = some x → xs[i + 1]? = some y →
      (y : ℝ) ≤ (1 - α / 4) * (x : ℝ)) :
    xs.length ≤ ⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊ := by
  cases hlen : xs.length with
  | zero => exact Nat.zero_le _
  | succ k =>
    have hk : k < xs.length := by omega
    have h0_lt : 0 < xs.length := by omega
    have hx0_le_n : xs[0]'h0_lt ≤ n := h0 (xs[0]'h0_lt) (List.getElem?_eq_getElem h0_lt)
    have hx0_r : ((xs[0]'h0_lt : ℕ) : ℝ) ≤ (n : ℝ) := Nat.cast_le.mpr hx0_le_n
    have hxk_gt : 2 < ((xs[k]'hk : ℕ) : ℝ) := hlast k hlen
    have hxk_ub := contraction_list_getElem_le hα_le xs hstep k hk
    have hbase_nn : 0 ≤ 1 - α / 4 := by linarith
    have hexp_one : 1 - α / 4 ≤ Real.exp (-(α / 4)) := by
      have := Real.add_one_le_exp (-(α / 4)); linarith
    have hpow_le : (1 - α / 4) ^ k ≤ (Real.exp (-(α / 4))) ^ k :=
      pow_le_pow_left₀ hbase_nn hexp_one k
    have hpow_exp : (Real.exp (-(α / 4))) ^ k = Real.exp ((k : ℝ) * (-(α / 4))) :=
      (Real.exp_nat_mul (-(α / 4)) k).symm
    have h2_lt_exp : 2 < Real.exp ((k : ℝ) * (-(α / 4))) * (n : ℝ) := by
      have hm1 := mul_le_mul_of_nonneg_left hx0_r (pow_nonneg hbase_nn k)
      have hm2 := mul_le_mul_of_nonneg_right hpow_le (Nat.cast_nonneg n)
      rw [hpow_exp] at hm2
      linarith
    have hexp_pos : 0 < Real.exp ((k : ℝ) * (α / 4)) := Real.exp_pos _
    have hmul_exp : Real.exp ((k : ℝ) * (α / 4)) * 2 < (n : ℝ) := by
      have hm := mul_lt_mul_of_pos_left h2_lt_exp hexp_pos
      have hcancel : Real.exp ((k : ℝ) * (α / 4)) * (Real.exp ((k : ℝ) * (-(α / 4))) * (n : ℝ)) =
          (n : ℝ) := by
        rw [← mul_assoc, ← Real.exp_add]
        have : (k : ℝ) * (α / 4) + (k : ℝ) * (-(α / 4)) = 0 := by ring
        rw [this, Real.exp_zero, one_mul]
      rwa [hcancel] at hm
    have hn_pos : (0 : ℝ) < (n : ℝ) := by
      have : 0 < n := by omega
      exact_mod_cast this
    have hlog_lt : Real.log (Real.exp ((k : ℝ) * (α / 4)) * 2) < Real.log (n : ℝ) :=
      (Real.log_lt_log_iff (by positivity) hn_pos).mpr hmul_exp
    rw [Real.log_mul (Real.exp_ne_zero _) (by norm_num), Real.log_exp] at hlog_lt
    have hlog2_gt := Real.log_two_gt_d9
    have hsucc_lt : ((k + 1 : ℕ) : ℝ) * (α / 4) < Real.log (n : ℝ) := by
      push_cast
      linarith
    have h4inv_pos : 0 < 4 * α⁻¹ := by positivity
    have hmul_inv := mul_lt_mul_of_pos_right hsucc_lt h4inv_pos
    have ha_ne : α ≠ 0 := ne_of_gt hα_pos
    have hlhs_eq : ((k + 1 : ℕ) : ℝ) * (α / 4) * (4 * α⁻¹) = ((k + 1 : ℕ) : ℝ) := by
      field_simp [ha_ne]
    rw [hlhs_eq] at hmul_inv
    have hlog_pos : 0 < Real.log (n : ℝ) := by
      have : Real.log 2 ≤ Real.log (n : ℝ) := Real.log_le_log (by norm_num) (by exact_mod_cast h2n)
      linarith
    have h4_le_16 : Real.log (n : ℝ) * (4 * α⁻¹) ≤ cDepthVal * α⁻¹ * Real.log (n : ℝ) := by
      unfold cDepthVal
      have h12 : 0 ≤ 12 * α⁻¹ * Real.log (n : ℝ) := by positivity
      linarith
    have hlt_ceil : ((k + 1 : ℕ) : ℝ) < (⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊ : ℝ) :=
      lt_of_lt_of_le (lt_of_lt_of_le hmul_inv h4_le_16) (Nat.le_ceil _)
    exact le_of_lt (Nat.cast_lt.mp hlt_ceil)

theorem contraction_list_sum_aux {α : ℝ} (hα_pos : 0 < α) (hα_le : α ≤ 1) :
    ∀ (xs : List ℕ),
      (∀ (i x y : ℕ), xs[i]? = some x → xs[i + 1]? = some y →
        (y : ℝ) ≤ (1 - α / 4) * (x : ℝ)) →
      (α / 4) * ((xs.sum : ℕ) : ℝ) ≤ ((xs.headD 0 : ℕ) : ℝ)
  | [], _ => by simp
  | [x], _ => by
      simp only [List.sum_cons, List.sum_nil, Nat.add_zero, List.headD_cons]
      have hx : (0 : ℝ) ≤ (x : ℝ) := Nat.cast_nonneg x
      have hmul : (α / 4) * (x : ℝ) ≤ 1 * (x : ℝ) :=
        mul_le_mul_of_nonneg_right (by linarith) hx
      linarith
  | x :: y :: rest, hstep => by
      have hrest : ∀ (i u v : ℕ), (y :: rest)[i]? = some u → (y :: rest)[i + 1]? = some v →
          (v : ℝ) ≤ (1 - α / 4) * (u : ℝ) :=
        fun i u v hu hv => hstep (i + 1) u v hu hv
      have ih := contraction_list_sum_aux hα_pos hα_le (y :: rest) hrest
      have h01 := hstep 0 x y rfl rfl
      simp only [List.headD_cons] at ih ⊢
      have hsum : (((x :: y :: rest).sum : ℕ) : ℝ) = (x : ℝ) + (((y :: rest).sum : ℕ) : ℝ) := by
        simp [List.sum_cons]
      rw [hsum, mul_add]
      have hexp : (1 - α / 4) * (x : ℝ) = (x : ℝ) - (α / 4) * (x : ℝ) := by ring
      linarith

theorem contraction_list_sum_le {n : ℕ} {α : ℝ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (xs : List ℕ)
    (h0 : ∀ x : ℕ, xs[0]? = some x → x ≤ n)
    (hstep : ∀ (i x y : ℕ), xs[i]? = some x → xs[i + 1]? = some y →
      (y : ℝ) ≤ (1 - α / 4) * (x : ℝ)) :
    ((xs.sum : ℕ) : ℝ) ≤ 4 * (n : ℝ) * α⁻¹ := by
  have haux := contraction_list_sum_aux hα_pos hα_le xs hstep
  have hhd_le : xs.headD 0 ≤ n := by
    cases xs with
    | nil => exact Nat.zero_le n
    | cons x rest => exact h0 x rfl
  have hhd_r : ((xs.headD 0 : ℕ) : ℝ) ≤ (n : ℝ) := Nat.cast_le.mpr hhd_le
  have hle_n : (α / 4) * ((xs.sum : ℕ) : ℝ) ≤ (n : ℝ) := le_trans haux hhd_r
  have h4inv_nn : 0 ≤ 4 * α⁻¹ := by positivity
  have hmul := mul_le_mul_of_nonneg_left hle_n h4inv_nn
  have ha_ne : α ≠ 0 := ne_of_gt hα_pos
  have hlhs : (4 * α⁻¹) * ((α / 4) * ((xs.sum : ℕ) : ℝ)) = ((xs.sum : ℕ) : ℝ) := by
    field_simp [ha_ne]
  rw [hlhs] at hmul
  linarith

/-! ### 3. Serving-Node Contraction & `ReachableAlg4Inv` State Bounds -/

theorem servingNode_contraction_step {d : ℕ} {ι : Type}
    {mode : Alg4Mode} {α : ℝ} {L : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1) (hL_pos : 1 ≤ L)
    {pts : ι → EuclideanSpace ℝ (Fin d)} {S_cur : Finset ι}
    {sn : Alg4ServingNode d ι}
    (hwf : sn.WellFormed mode α L pts S_cur) :
    IsValidServingNodeAge α sn.birthSnapshot.card sn.age ∧
    sn.trueAge ≤ sn.age ∧
    (15 / 16 : ℝ) * (sn.birthSnapshot.card : ℝ) ≤ (S_cur.card : ℝ) ∧
    (1 - α / 16) * (sn.birthSnapshot.card : ℝ) ≤ (S_cur.card : ℝ) ∧
    2 < (S_cur.card : ℝ) ∧
    ((sn.node.residual pts S_cur).card : ℝ) ≤ (1 - α / 4) * (S_cur.card : ℝ) := by
  have hvalid_age : IsValidServingNodeAge α sn.birthSnapshot.card sn.age :=
    validServingNodeAge_of_wellFormed hα_pos hα_le hwf.1
  have htrue_le : sn.trueAge ≤ sn.age := hwf.2.1
  set M := sn.birthSnapshot.card
  have hlarge : IsLargeResidualLevel L M := hwf.1.1
  have hM_ge4 : 4 ≤ M := by
    unfold IsLargeResidualLevel at hlarge; omega
  have hage_lt : (sn.age : ℝ) < α * (M : ℝ) / 16 := hvalid_age
  have htrue_lt : (sn.trueAge : ℝ) < α * (M : ℝ) / 16 := by
    have : (sn.trueAge : ℝ) ≤ (sn.age : ℝ) := Nat.cast_le.mpr htrue_le
    linarith
  -- Card lower bound on `S_cur`
  have hsub_union : sn.birthSnapshot ⊆ (sn.birthSnapshot \ S_cur) ∪ S_cur := by
    intro x hx
    by_cases hxs : x ∈ S_cur
    · exact Finset.mem_union_right _ hxs
    · exact Finset.mem_union_left _ (Finset.mem_sdiff.mpr ⟨hx, hxs⟩)
  have hcard_u : M ≤ (sn.birthSnapshot \ S_cur).card + S_cur.card :=
    le_trans (Finset.card_le_card hsub_union) (Finset.card_union_le _ _)
  have hsdiff_le : (sn.birthSnapshot \ S_cur).card ≤ sn.trueAge :=
    (hasNodeAge_card_bounds hwf.2.2.1).2.1
  have hM_le_sum : (M : ℝ) ≤ (sn.trueAge : ℝ) + (S_cur.card : ℝ) := by
    have : M ≤ sn.trueAge + S_cur.card := by omega
    exact_mod_cast this
  have hS_lb : (1 - α / 16) * (M : ℝ) ≤ (S_cur.card : ℝ) := by linarith
  have h15_lb : (15 / 16 : ℝ) * (M : ℝ) ≤ (S_cur.card : ℝ) := by
    have hM_nn : (0 : ℝ) ≤ (M : ℝ) := Nat.cast_nonneg M
    have : (15 / 16 : ℝ) * (M : ℝ) ≤ (1 - α / 16) * (M : ℝ) :=
      mul_le_mul_of_nonneg_right (by linarith) hM_nn
    linarith
  have h2_lt_S : 2 < (S_cur.card : ℝ) := by
    have : (4 : ℝ) ≤ (M : ℝ) := by exact_mod_cast hM_ge4
    linarith
  -- Residual contraction `≤ (1 - α / 4) * S_cur.card`
  have hres_ub := aged_residual_card_le pts sn.node sn.birthSnapshot S_cur hwf.1.2.1 hwf.2.2.1
  have hres_7_16 : ((sn.node.residual pts S_cur).card : ℝ) ≤ (1 - 7 * α / 16) * (M : ℝ) := by
    linarith
  have hprod_ge : (1 - 7 * α / 16) * (M : ℝ) ≤ (1 - α / 4) * ((1 - α / 16) * (M : ℝ)) := by
    have hdiff_nn : 0 ≤ (2 * α / 16 + α ^ 2 / 64) * (M : ℝ) := by positivity
    have hid : (1 - α / 4) * ((1 - α / 16) * (M : ℝ)) - (1 - 7 * α / 16) * (M : ℝ) =
        (2 * α / 16 + α ^ 2 / 64) * (M : ℝ) := by ring
    linarith
  have hmul_S : (1 - α / 4) * ((1 - α / 16) * (M : ℝ)) ≤ (1 - α / 4) * (S_cur.card : ℝ) :=
    mul_le_mul_of_nonneg_left hS_lb (by linarith)
  exact ⟨hvalid_age, htrue_le, h15_lb, hS_lb, h2_lt_S, by linarith⟩

theorem servingChainInputAt_succ_local {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d)) :
    ∀ (nodes : List (ServingNodeState d ι)) (P : Finset ι) {i : ℕ} (hi : i < nodes.length),
      servingChainInputAt pts nodes P (i + 1) =
        (nodes[i]'hi).node.residual pts (servingChainInputAt pts nodes P i)
  | [], _, _, hi => by cases hi
  | sn :: rest, P, 0, _ => by
      simp [servingChainInputAt]
  | sn :: rest, P, i + 1, hi => by
      have hi_rest : i < rest.length := Nat.lt_of_succ_lt_succ hi
      rw [servingChainInputAt_cons_succ, servingChainInputAt_cons_succ]
      exact servingChainInputAt_succ_local pts rest (sn.node.residual pts P) hi_rest

theorem list_sum_real_le_length_mul : ∀ {xs : List ℕ} {B : ℝ},
    0 ≤ B → (∀ x ∈ xs, (x : ℝ) ≤ B) → ((xs.sum : ℕ) : ℝ) ≤ (xs.length : ℝ) * B
  | [], _, _, _ => by simp
  | x :: xs, B, hB, h => by
      have hx : (x : ℝ) ≤ B := h x List.mem_cons_self
      have hxs : ((xs.sum : ℕ) : ℝ) ≤ (xs.length : ℝ) * B :=
        list_sum_real_le_length_mul hB (fun y hy => h y (List.mem_cons_of_mem _ hy))
      simp only [List.sum_cons, List.length_cons, Nat.cast_add, Nat.cast_one]
      linarith

theorem list_flatMap_length_le {α β : Type} :
    ∀ (xs : List α) (f : α → List β) (B : ℕ),
      (∀ x ∈ xs, (f x).length ≤ B) → (xs.flatMap f).length ≤ xs.length * B
  | [], _, _, _ => by simp
  | x :: xs, f, B, h => by
      have hx : (f x).length ≤ B := h x List.mem_cons_self
      have hxs : (xs.flatMap f).length ≤ xs.length * B :=
        list_flatMap_length_le xs f B (fun y hy => h y (List.mem_cons_of_mem _ hy))
      simp only [List.flatMap_cons, List.length_append, List.length_cons, Nat.add_mul, Nat.one_mul]
      omega

theorem list_sum_map_le_sum_map_real {α : Type} :
    ∀ (xs : List α) (f g : α → ℝ),
      (∀ x ∈ xs, f x ≤ g x) → (xs.map f).sum ≤ (xs.map g).sum
  | [], _, _, _ => by simp
  | x :: xs, f, g, h => by
      have hx := h x List.mem_cons_self
      have hxs := list_sum_map_le_sum_map_real xs f g (fun y hy => h y (List.mem_cons_of_mem _ hy))
      simp only [List.map_cons, List.sum_cons]
      linarith

theorem list_sum_map_const_mul_real {α : Type} :
    ∀ (xs : List α) (f : α → ℝ) (c : ℝ),
      (xs.map (fun x => c * f x)).sum = c * (xs.map f).sum
  | [], _, _ => by simp
  | x :: xs, f, c => by
      simp only [List.map_cons, List.sum_cons, list_sum_map_const_mul_real xs f c]
      ring

theorem list_sum_map_const_mul_nat :
    ∀ (xs : List ℕ) (c : ℝ),
      (xs.map (fun m : ℕ => c * (m : ℝ))).sum = c * ((xs.sum : ℕ) : ℝ)
  | [], _ => by simp
  | x :: xs, c => by
      simp only [List.map_cons, List.sum_cons, Nat.cast_add,
        list_sum_map_const_mul_nat xs c]
      ring

theorem list_sum_nat_cast_eq :
    ∀ (xs : List ℕ), ((xs.sum : ℕ) : ℝ) = (xs.map (fun m : ℕ => (m : ℝ))).sum
  | [] => by simp
  | x :: xs => by
      simp [list_sum_nat_cast_eq xs]

theorem flatMap_pair_sum_eq {α : Type} :
    ∀ (xs : List α) (f : α → ℕ),
      (xs.flatMap (fun x => [f x, f x])).sum = 2 * (xs.map f).sum
  | [], _ => by simp
  | x :: xs, f => by
      simp only [List.flatMap_cons, List.cons_append, List.nil_append,
        List.sum_cons, List.map_cons, flatMap_pair_sum_eq xs f]
      omega

theorem reachableState_chain_bounds {d n : ℕ} {ι : Type}
    {mode : Alg4Mode} {α C : ℝ} {K₀ L D_out : ℕ}
    (h2n : 2 ≤ n) (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    {st : Alg4State d ι}
    (hinv : ReachableAlg4Inv n mode α L D_out st) :
    let D₀ : ℕ := ⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊
    (∀ sn ∈ st.servingNodes,
      IsValidServingNodeAge α sn.birthSnapshot.card sn.age ∧
      sn.trueAge ≤ sn.age) ∧
    st.servingNodes.length ≤ D₀ ∧
    st.owningJobNodeCount ≤ D₀ ∧
    (∀ sn ∈ st.servingNodes, ∀ job : Alg4PendingJob d ι,
      sn.ownedJob = some job → job.completedPrefix.length ≤ D₀) ∧
    (∀ m ∈ st.retainedChainSnapshotCards, m ≤ n) ∧
    st.retainedChainSnapshotCards.sum ≤ (2 + 2 * D₀ + 2 * D₀ ^ 2) * n ∧
    ((st.retainedChainSnapshotCards.sum : ℕ) : ℝ) ≤ 16 * (n : ℝ) * (D₀ : ℝ) * α⁻¹ ∧
    st.liveSnapRecords ≤ 1 + D₀ * (2 + 2 * D₀) := by
  dsimp only
  set D₀ : ℕ := ⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊
  have hL_pos : 1 ≤ L := cutoff_L_pos hα_pos hα_le hL
  have hD0_pos : 1 ≤ D₀ := (d0_and_llog_bounds h2n hα_pos hα_le).1
  have ha_inv : 1 ≤ α⁻¹ := alpha_inv_ge_one hα_pos hα_le
  rcases hinv with ⟨hwf, hreach_nodes⟩
  rcases hwf with ⟨hact_le_n, hchain_wf, _, _, hnodes_wf, _, _, _⟩
  -- 1. Age validity on every serving node
  have hsn_ages : ∀ sn ∈ st.servingNodes,
      IsValidServingNodeAge α sn.birthSnapshot.card sn.age ∧ sn.trueAge ≤ sn.age := by
    intro sn hsn
    rcases List.mem_iff_getElem.mp hsn with ⟨idx, hi, rfl⟩
    have hwfi := hnodes_wf ⟨idx, hi⟩
    rw [Fin.getElem_fin] at hwfi
    have hc := servingNode_contraction_step hα_pos hα_le hL_pos hwfi
    exact ⟨hc.1, hc.2.1⟩
  -- 2. Input list for serving chain contraction
  set inCards : List ℕ := (List.range st.servingNodes.length).map (fun i => (st.servingInputAt i).card)
  have hinCards_0 : ∀ x : ℕ, inCards[0]? = some x → x ≤ n := by
    intro x hx
    dsimp only [inCards] at hx
    rw [List.getElem?_map] at hx
    cases hr : (List.range st.servingNodes.length)[0]? with
    | none => rw [hr] at hx; simp at hx
    | some i0 =>
      rw [hr] at hx
      simp only [Option.map_some, Option.some.injEq] at hx
      have hi0_eq : i0 = 0 := by
        have hlt : 0 < st.servingNodes.length := by
          by_contra hge
          have h0 : st.servingNodes.length = 0 := by omega
          rw [h0] at hr; simp at hr
        rw [List.getElem?_range hlt] at hr
        exact (Option.some.inj hr).symm
      subst hi0_eq hx
      simpa [Alg4State.servingInputAt, servingChainInputAt] using hact_le_n
  have hinCards_step : ∀ (i x y : ℕ), inCards[i]? = some x → inCards[i + 1]? = some y →
      (y : ℝ) ≤ (1 - α / 4) * (x : ℝ) := by
    intro i x y hx hy
    have hi1 : i + 1 < inCards.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hy; cases hy
    have hi_sn : i + 1 < st.servingNodes.length := by simpa [inCards] using hi1
    have hi0_sn : i < st.servingNodes.length := by omega
    dsimp only [inCards] at hx hy
    rw [List.getElem?_map, List.getElem?_range hi0_sn, Option.map_some, Option.some.injEq] at hx
    rw [List.getElem?_map, List.getElem?_range hi_sn, Option.map_some, Option.some.injEq] at hy
    subst hx hy
    have hwfi := hnodes_wf ⟨i, hi0_sn⟩
    rw [Fin.getElem_fin] at hwfi
    have hc := servingNode_contraction_step hα_pos hα_le hL_pos hwfi
    have hnext_eq : st.servingInputAt (i + 1) =
        (st.servingNodes[i]'hi0_sn).node.residual st.coords (st.servingInputAt i) := by
      unfold Alg4State.servingInputAt
      have hlen_map : i < (st.servingNodes.map Alg4ServingNode.toServingNodeState).length := by
        simp [hi0_sn]
      rw [servingChainInputAt_succ_local _ _ _ hlen_map]
      simp [Alg4ServingNode.toServingNodeState]
    rw [hnext_eq]
    exact hc.2.2.2.2.2
  have hinCards_last : ∀ k : ℕ, (hk_len : inCards.length = k + 1) →
      2 < ((inCards[k]'(by omega) : ℕ) : ℝ) := by
    intro k hk_len
    have hk_sn : k < st.servingNodes.length := by
      have : inCards.length = st.servingNodes.length := by simp [inCards]
      omega
    have hget_k : inCards[k]'(by omega) = (st.servingInputAt k).card := by
      simp [inCards]
    rw [hget_k]
    have hwfk := hnodes_wf ⟨k, hk_sn⟩
    rw [Fin.getElem_fin] at hwfk
    exact (servingNode_contraction_step hα_pos hα_le hL_pos hwfk).2.2.2.2.1
  have hserv_len : st.servingNodes.length ≤ D₀ := by
    have h := contraction_list_length_le h2n hα_pos hα_le inCards hinCards_0 hinCards_last hinCards_step
    simpa [inCards] using h
  have hown_cnt : st.owningJobNodeCount ≤ D₀ :=
    le_trans (List.length_filter_le _ _) hserv_len
  -- 3. Every owned job's `completedPrefix.length ≤ D₀` and telescoping sum `≤ 4 * n * α⁻¹`
  have hjob_pfx_bounds : ∀ (idx : ℕ) (sn : Alg4ServingNode d ι),
      st.servingNodes[idx]? = some sn →
      ∀ job : Alg4PendingJob d ι, sn.ownedJob = some job →
        job.completedPrefix.length ≤ D₀ ∧
        (((job.completedPrefix.map (fun lv => lv.birthSnapshot.card)).sum : ℕ) : ℝ) ≤
          4 * (n : ℝ) * α⁻¹ := by
    intro idx sn hget job hjob
    have hi : idx < st.servingNodes.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
    rw [List.getElem?_eq_getElem hi] at hget
    injection hget with hsn_eq; subst hsn_eq
    have hjwf : job.WellFormed mode α L st.coords (st.servingInputAt idx) := by
      have h9 := (hnodes_wf ⟨idx, hi⟩).2.2.2.2.2.2.2.2
      rw [Fin.getElem_fin, hjob] at h9; exact h9
    have hjsched := (hreach_nodes idx (st.servingNodes[idx]'hi) (List.getElem?_eq_getElem hi)).2 job hjob
    set pCards := job.completedPrefix.map (fun lv => lv.birthSnapshot.card)
    have hp0 : ∀ x : ℕ, pCards[0]? = some x → x ≤ n := by
      intro x hx
      dsimp only [pCards] at hx
      rw [List.getElem?_map] at hx
      cases hl0 : job.completedPrefix[0]? with
      | none => rw [hl0] at hx; simp at hx
      | some lv0 =>
        rw [hl0] at hx
        simp only [Option.map_some, Option.some.injEq] at hx
        subst hx
        exact (hjsched.2.1 0 lv0 hl0).1
    have hp_step : ∀ (i x y : ℕ), pCards[i]? = some x → pCards[i + 1]? = some y →
        (y : ℝ) ≤ (1 - α / 4) * (x : ℝ) := by
      intro i x y hx hy
      dsimp only [pCards] at hx hy
      rw [List.getElem?_map] at hx hy
      cases hli : job.completedPrefix[i]? with
      | none => rw [hli] at hx; simp at hx
      | some lvi =>
        rw [hli, Option.map_some, Option.some.injEq] at hx
        cases hli1 : job.completedPrefix[i + 1]? with
        | none => rw [hli1] at hy; simp at hy
        | some lvi1 =>
          rw [hli1, Option.map_some, Option.some.injEq] at hy
          subst hx hy
          exact (hjsched.2.1 (i + 1) lvi1 hli1).2.2.2.2.2.2.2 i lvi rfl hli
    have hp_last : ∀ k : ℕ, (hk_len : pCards.length = k + 1) →
        2 < ((pCards[k]'(by omega) : ℕ) : ℝ) := by
      intro k hk_len
      have hk_p : k < job.completedPrefix.length := by
        have : pCards.length = job.completedPrefix.length := by simp [pCards]
        omega
      have hget_k : pCards[k]'(by omega) = (job.completedPrefix[k]'hk_p).birthSnapshot.card := by
        simp [pCards]
      rw [hget_k]
      have hlvk_wf := (hjwf.2.1 ⟨k, hk_p⟩).2
      rw [Fin.getElem_fin] at hlvk_wf
      have hlarge_k : IsLargeResidualLevel L (job.completedPrefix[k]'hk_p).birthSnapshot.card :=
        hlvk_wf.2.1
      have hge4 : 4 ≤ (job.completedPrefix[k]'hk_p).birthSnapshot.card := by
        unfold IsLargeResidualLevel at hlarge_k; omega
      have : (4 : ℝ) ≤ ((job.completedPrefix[k]'hk_p).birthSnapshot.card : ℝ) := by exact_mod_cast hge4
      linarith
    refine ⟨?_, contraction_list_sum_le hα_pos hα_le pCards hp0 hp_step⟩
    have hlen := contraction_list_length_le h2n hα_pos hα_le pCards hp0 hp_last hp_step
    simpa [pCards] using hlen
  have hpfx_len_all : ∀ sn ∈ st.servingNodes, ∀ job : Alg4PendingJob d ι,
      sn.ownedJob = some job → job.completedPrefix.length ≤ D₀ := by
    intro sn hsn job hjob
    rcases List.mem_iff_getElem.mp hsn with ⟨idx, hi, rfl⟩
    exact (hjob_pfx_bounds idx (st.servingNodes[idx]'hi) (List.getElem?_eq_getElem hi) job hjob).1
  -- 4. Every `m ∈ st.retainedChainSnapshotCards` satisfies `m ≤ n`, and length/sum bounds
  have hcards_le_n : ∀ m ∈ st.retainedChainSnapshotCards, m ≤ n := by
    intro m hm
    unfold Alg4State.retainedChainSnapshotCards at hm
    rcases List.mem_cons.mp hm with rfl | hm1
    · exact hact_le_n
    · rcases List.mem_cons.mp hm1 with rfl | hm2
      · have hsub : st.terminalLeaf ⊆ st.activeSet := by
          have hleaf_eq : st.terminalLeaf = servingChainInputAt st.coords
              (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet
              st.servingNodes.length := by
            simpa [Alg4State.toScheduledServingChain] using hchain_wf.2.1
          rw [hleaf_eq]; exact servingChainInputAt_subset _ _ _ _
        exact le_trans (Finset.card_le_card hsub) hact_le_n
      · rcases List.mem_flatMap.mp hm2 with ⟨sn, hsn_mem, hm_sn⟩
        rcases List.mem_iff_getElem.mp hsn_mem with ⟨idx, hi, rfl⟩
        rcases hreach_nodes idx (st.servingNodes[idx]'hi) (List.getElem?_eq_getElem hi) with
          ⟨hb_le, hjob_inv⟩
        unfold Alg4ServingNode.retainedSnapshotCards at hm_sn
        rcases List.mem_cons.mp hm_sn with rfl | hm_own
        · exact hb_le
        · cases hown : (st.servingNodes[idx]'hi).ownedJob with
          | none => rw [hown] at hm_own; cases hm_own
          | some job =>
            rw [hown] at hm_own
            rcases List.mem_cons.mp hm_own with rfl | hm_lv
            · have hjwf : job.WellFormed mode α L st.coords (st.servingInputAt idx) := by
                have h9 := (hnodes_wf ⟨idx, hi⟩).2.2.2.2.2.2.2.2
                rw [Fin.getElem_fin, hown] at h9; exact h9
              have hres_eq : job.currentResidual =
                  prefixResidual st.coords (job.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel)
                    (st.servingInputAt idx) := hjwf.1.2.1
              have hsub1 : job.currentResidual ⊆ st.servingInputAt idx := by
                rw [hres_eq]; exact prefixResidual_subset _ _ _
              have hsub2 : st.servingInputAt idx ⊆ st.activeSet :=
                servingChainInputAt_subset _ _ _ _
              exact le_trans (Finset.card_le_card (Finset.Subset.trans hsub1 hsub2)) hact_le_n
            · rcases List.mem_flatMap.mp hm_lv with ⟨lv, hlv_mem, hm_pair⟩
              rcases List.mem_iff_getElem.mp hlv_mem with ⟨j, hj, rfl⟩
              have hsc_j := (hjob_inv job hown).2.1 j (job.completedPrefix[j]'hj)
                (List.getElem?_eq_getElem hj)
              simp only [List.mem_cons, List.not_mem_nil, or_false] at hm_pair
              rcases hm_pair with rfl | rfl
              · exact hsc_j.1
              · rw [hsc_j.2.1]; exact hsc_j.1
  have hsn_cards_len : ∀ sn ∈ st.servingNodes, sn.retainedSnapshotCards.length ≤ 2 + 2 * D₀ := by
    intro sn hsn
    unfold Alg4ServingNode.retainedSnapshotCards
    cases hown : sn.ownedJob with
    | none => simp; omega
    | some job =>
      have hp_le := hpfx_len_all sn hsn job hown
      have hfm : (job.completedPrefix.flatMap (fun lv => [lv.birthSnapshot.card, lv.scan2Snapshot.card])).length ≤
          job.completedPrefix.length * 2 :=
        list_flatMap_length_le _ _ 2 (fun _ _ => le_rfl)
      simp only [List.length_cons]
      omega
  have hcards_len : st.retainedChainSnapshotCards.length ≤ 2 + 2 * D₀ + 2 * D₀ ^ 2 := by
    unfold Alg4State.retainedChainSnapshotCards
    have hfm := list_flatMap_length_le st.servingNodes Alg4ServingNode.retainedSnapshotCards
      (2 + 2 * D₀) hsn_cards_len
    have hmul : st.servingNodes.length * (2 + 2 * D₀) ≤ D₀ * (2 + 2 * D₀) :=
      Nat.mul_le_mul_right _ hserv_len
    simp only [List.length_cons]
    have hring : D₀ * (2 + 2 * D₀) = 2 * D₀ + 2 * D₀ ^ 2 := by ring
    omega
  have hcards_sum_poly : st.retainedChainSnapshotCards.sum ≤ (2 + 2 * D₀ + 2 * D₀ ^ 2) * n :=
    le_trans (list_sum_le_length_mul hcards_le_n) (Nat.mul_le_mul_right n hcards_len)
  -- 5. `liveSnapRecords` bound `≤ 1 + D₀ * (2 + 2 * D₀)`
  have hlive_bound : st.liveSnapRecords ≤ 1 + D₀ * (2 + 2 * D₀) := by
    unfold Alg4State.liveSnapRecords
    have hmem_le : ∀ x ∈ st.servingNodes.map Alg4ServingNode.liveSnapRecords, x ≤ 2 + 2 * D₀ := by
      intro x hx
      rcases List.mem_map.mp hx with ⟨sn, hsn, rfl⟩
      unfold Alg4ServingNode.liveSnapRecords
      cases hown : sn.ownedJob with
      | none => dsimp only; omega
      | some job =>
        dsimp only
        have := hpfx_len_all sn hsn job hown
        omega
    have hsum_le := list_sum_le_length_mul hmem_le
    simp only [List.length_map] at hsum_le
    have hmul : st.servingNodes.length * (2 + 2 * D₀) ≤ D₀ * (2 + 2 * D₀) :=
      Nat.mul_le_mul_right _ hserv_len
    omega
  -- 6. Sharp geometric telescoping sum `((st.retainedChainSnapshotCards.sum : ℕ) : ℝ) ≤ 16 * n * D₀ * α⁻¹`
  have hcards_sum_tele : ((st.retainedChainSnapshotCards.sum : ℕ) : ℝ) ≤
      16 * (n : ℝ) * (D₀ : ℝ) * α⁻¹ := by
    have hin_sum : ((inCards.sum : ℕ) : ℝ) ≤ 4 * (n : ℝ) * α⁻¹ :=
      contraction_list_sum_le hα_pos hα_le inCards hinCards_0 hinCards_step
    -- Sum of `sn.birthSnapshot.card` across `st.servingNodes` is `≤ (16 / 15) * inCards.sum ≤ 5 * n * α⁻¹`
    have hserv_birth_sum :
        (((st.servingNodes.map (fun sn => sn.birthSnapshot.card)).sum : ℕ) : ℝ) ≤
          5 * (n : ℝ) * α⁻¹ := by
      have hlhs_eq : st.servingNodes.map (fun sn => sn.birthSnapshot.card) =
          (List.range st.servingNodes.length).map
            (fun i => ((st.servingNodes[i]?).map (fun sn => sn.birthSnapshot.card)).getD 0) := by
        apply List.ext_getElem
        · simp
        · intro i hi1 hi2
          simp only [List.length_map] at hi1
          rw [List.getElem_map, List.getElem_map, List.getElem_range, List.getElem?_eq_getElem hi1]; rfl
      rw [list_sum_nat_cast_eq, hlhs_eq, List.map_map]
      dsimp only [Function.comp_def]
      rw [list_sum_nat_cast_eq] at hin_sum
      dsimp only [inCards] at hin_sum
      rw [List.map_map] at hin_sum
      dsimp only [Function.comp_def] at hin_sum
      have hptwise : ∀ i ∈ List.range st.servingNodes.length,
          ((fun x => ((((st.servingNodes[x]?).map (fun sn => sn.birthSnapshot.card)).getD 0 : ℕ) : ℝ)) i) ≤
            ((fun x => (16 / 15 : ℝ) * ((st.servingInputAt x).card : ℝ)) i) := by
        intro i hi_mem
        have hi : i < st.servingNodes.length := List.mem_range.mp hi_mem
        dsimp only
        rw [List.getElem?_eq_getElem hi]
        dsimp only [Option.map_some, Option.getD_some]
        have hwfi := hnodes_wf ⟨i, hi⟩
        rw [Fin.getElem_fin] at hwfi
        have h15 := (servingNode_contraction_step hα_pos hα_le hL_pos hwfi).2.2.1
        linarith
      have hle1 := list_sum_map_le_sum_map_real (List.range st.servingNodes.length) _ _ hptwise
      have hfactor :
          ((List.range st.servingNodes.length).map
            (fun x => (16 / 15 : ℝ) * ((st.servingInputAt x).card : ℝ))).sum =
          (16 / 15 : ℝ) *
            ((List.range st.servingNodes.length).map
              (fun x => ((st.servingInputAt x).card : ℝ))).sum :=
        list_sum_map_const_mul_real _ _ _
      rw [hfactor] at hle1
      have hn_nn : 0 ≤ (n : ℝ) * α⁻¹ := by positivity
      linarith
    -- Split `st.servingNodes.flatMap retainedSnapshotCards` into `sn.birthSnapshot.card` + owned-job part
    have hflat_split : ∀ (ns : List (Alg4ServingNode d ι)),
        (ns.flatMap Alg4ServingNode.retainedSnapshotCards).sum =
        (ns.map (fun sn => sn.birthSnapshot.card)).sum +
        (ns.map (fun sn =>
          match sn.ownedJob with
          | none => 0
          | some job =>
              job.currentResidual.card +
                (job.completedPrefix.flatMap (fun lv => [lv.birthSnapshot.card, lv.scan2Snapshot.card])).sum)).sum := by
      intro ns
      induction ns with
      | nil => simp
      | cons sn rest ih =>
        simp only [List.flatMap_cons, List.sum_append, List.map_cons, List.sum_cons, ih]
        unfold Alg4ServingNode.retainedSnapshotCards
        cases sn.ownedJob <;> simp <;> omega
    -- Bound each serving node's owned-job part by `9 * n * α⁻¹`
    have hjob_part_each : ∀ (x : ℕ), x ∈ st.servingNodes.map (fun sn : Alg4ServingNode d ι =>
        match sn.ownedJob with
        | none => 0
        | some job =>
            job.currentResidual.card +
              (job.completedPrefix.flatMap (fun lv => [lv.birthSnapshot.card, lv.scan2Snapshot.card])).sum) →
        (x : ℝ) ≤ 9 * (n : ℝ) * α⁻¹ := by
      intro x hx
      rcases List.mem_map.mp hx with ⟨sn, hsn_mem, rfl⟩
      rcases List.mem_iff_getElem.mp hsn_mem with ⟨idx, hi, rfl⟩
      cases hown : (st.servingNodes[idx]'hi).ownedJob with
      | none =>
        dsimp only
        rw [Nat.cast_zero]
        positivity
      | some job =>
        dsimp only
        have hres_le_n : job.currentResidual.card ≤ n := by
          apply hcards_le_n
          unfold Alg4State.retainedChainSnapshotCards
          apply List.mem_cons_of_mem _ (List.mem_cons_of_mem _ _)
          rw [List.mem_flatMap]
          refine ⟨st.servingNodes[idx]'hi, List.getElem_mem hi, ?_⟩
          unfold Alg4ServingNode.retainedSnapshotCards
          rw [hown]
          exact List.mem_cons_of_mem _ (List.mem_cons_self)
        have hp_sum := (hjob_pfx_bounds idx (st.servingNodes[idx]'hi)
          (List.getElem?_eq_getElem hi) job hown).2
        have hsched_j := (hreach_nodes idx (st.servingNodes[idx]'hi)
          (List.getElem?_eq_getElem hi)).2 job hown
        have hpair_eq : job.completedPrefix.flatMap (fun lv => [lv.birthSnapshot.card, lv.scan2Snapshot.card]) =
            job.completedPrefix.flatMap (fun lv => [lv.birthSnapshot.card, lv.birthSnapshot.card]) := by
          apply List.flatMap_congr
          intro lv hlv
          rcases List.mem_iff_getElem.mp hlv with ⟨j, hj, rfl⟩
          have hs2 := (hsched_j.2.1 j (job.completedPrefix[j]'hj) (List.getElem?_eq_getElem hj)).2.1
          rw [hs2]
        rw [hpair_eq, flatMap_pair_sum_eq]
        set s_pfx : ℕ := (job.completedPrefix.map (fun lv => lv.birthSnapshot.card)).sum
        have hp_sum' : (s_pfx : ℝ) ≤ 4 * (n : ℝ) * α⁻¹ := hp_sum
        have hcast_eq : ((job.currentResidual.card + 2 * s_pfx : ℕ) : ℝ) =
            (job.currentResidual.card : ℝ) + 2 * (s_pfx : ℝ) := by push_cast; ring
        rw [hcast_eq]
        have hres_r : (job.currentResidual.card : ℝ) ≤ (n : ℝ) * α⁻¹ := by
          have h1 : (job.currentResidual.card : ℝ) ≤ (n : ℝ) := Nat.cast_le.mpr hres_le_n
          have h2 : (n : ℝ) * 1 ≤ (n : ℝ) * α⁻¹ := mul_le_mul_of_nonneg_left ha_inv (Nat.cast_nonneg n)
          linarith
        linarith
    have hjob_part_sum :
        (((st.servingNodes.map (fun sn =>
          match sn.ownedJob with
          | none => 0
          | some job =>
              job.currentResidual.card +
                (job.completedPrefix.flatMap
                  (fun lv => [lv.birthSnapshot.card, lv.scan2Snapshot.card])).sum)).sum : ℕ) : ℝ) ≤
          9 * (D₀ : ℝ) * (n : ℝ) * α⁻¹ := by
      have h1 := list_sum_real_le_length_mul (by positivity) hjob_part_each
      simp only [List.length_map] at h1
      have hlen_r : (st.servingNodes.length : ℝ) ≤ (D₀ : ℝ) := Nat.cast_le.mpr hserv_len
      have h2 : (st.servingNodes.length : ℝ) * (9 * (n : ℝ) * α⁻¹) ≤
          (D₀ : ℝ) * (9 * (n : ℝ) * α⁻¹) :=
        mul_le_mul_of_nonneg_right hlen_r (by positivity)
      linarith
    have hact_r : (st.activeSet.card : ℝ) ≤ (n : ℝ) * α⁻¹ := by
      have h1 : (st.activeSet.card : ℝ) ≤ (n : ℝ) := Nat.cast_le.mpr hact_le_n
      have h2 : (n : ℝ) * 1 ≤ (n : ℝ) * α⁻¹ := mul_le_mul_of_nonneg_left ha_inv (Nat.cast_nonneg n)
      linarith
    have hleaf_le_n : st.terminalLeaf.card ≤ n :=
      hcards_le_n st.terminalLeaf.card (List.mem_cons_of_mem _ (List.mem_cons_self))
    have hleaf_r : (st.terminalLeaf.card : ℝ) ≤ (n : ℝ) * α⁻¹ := by
      have h1 : (st.terminalLeaf.card : ℝ) ≤ (n : ℝ) := Nat.cast_le.mpr hleaf_le_n
      have h2 : (n : ℝ) * 1 ≤ (n : ℝ) * α⁻¹ := mul_le_mul_of_nonneg_left ha_inv (Nat.cast_nonneg n)
      linarith
    have hD0_r1 : (1 : ℝ) ≤ (D₀ : ℝ) := Nat.one_le_cast.mpr hD0_pos
    have h7_le : 7 * ((n : ℝ) * α⁻¹) ≤ 7 * (D₀ : ℝ) * ((n : ℝ) * α⁻¹) := by
      have : (n : ℝ) * α⁻¹ ≤ (D₀ : ℝ) * ((n : ℝ) * α⁻¹) := by
        have := mul_le_mul_of_nonneg_right hD0_r1 (show 0 ≤ (n : ℝ) * α⁻¹ by positivity)
        linarith
      linarith
    unfold Alg4State.retainedChainSnapshotCards
    simp only [List.sum_cons, hflat_split, Nat.cast_add]
    linarith
  exact ⟨hsn_ages, hserv_len, hown_cnt, hpfx_len_all, hcards_le_n,
    hcards_sum_poly, hcards_sum_tele, hlive_bound⟩

/-! ### 4. Step Retirement Bridge (`alg4StepNewRetired`), Endpoint Space, & General Space -/

theorem alg4StepNewRetired_bounded_and_queue_eq {d n : ℕ} {ι : Type}
    {mode : Alg4Mode} {α C : ℝ} {K₀ L reclaimMult D_out : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (hD_out : 1 ≤ D_out)
    {st : Alg4State d ι} {upd : Alg4PointUpdate d ι} {choices : Alg4StepChoices d ι}
    (hwf : st.WellFormed n mode α L D_out)
    (hupd : IsValidAlg4PointUpdate n st upd)
    (hextra : ∀ r ∈ choices.stepExtraRetired, r.HasBoundedOutdegree D_out) :
    (∀ r ∈ alg4StepNewRetired mode α L st upd choices, r.HasBoundedOutdegree D_out) ∧
    (alg4Step mode α L reclaimMult st upd choices).1.retirementQueue =
      (alg4Line11PerformRetirementWork reclaimMult choices.stepAllocatedRecords
        st.retirementQueue (alg4StepNewRetired mode α L st upd choices)).1 := by
  have hL_pos := cutoff_L_pos hα_pos hα_le hL
  rcases hwf with ⟨_, hchain_wf, _, hleaf_sq, hnodes_wf, _, _, _⟩
  set P' := applyAlg4PointSetUpdate st.activeSet upd
  set pts' := updateAlg4Coords st.coords upd
  have hpts_act : ∀ x ∈ st.activeSet, pts' x = st.coords x :=
    fun x hx => updateAlg4Coords_eq_on_liveRetainedIds hupd (activeSet_subset_liveRetainedIds st hx)
  let rootEv : PoolUpdateEvent ι := alg4RootEvent upd
  have hroot_ev : IsValidPoolUpdateEvent st.activeSet P' rootEv := by
    cases upd with
    | insert p pt => exact ⟨fun hp => hupd.1 (activeSet_subset_liveRetainedIds st hp), rfl⟩
    | delete p => exact ⟨hupd, rfl⟩
  have hl1_in : ∀ (idx : ℕ) (sn : Alg4ServingNode d ι),
      st.servingNodes[idx]? = some sn →
      let S_cur := servingChainInputAt st.coords
        (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet idx
      sn.trueAge ≤ sn.age ∧
      HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
      ServingNodePreRefreshWF mode st.coords S_cur sn ∧
      ServingNodeCacheWF mode st.coords S_cur sn := by
    intro idx sn hget
    have hi : idx < st.servingNodes.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
    rw [List.getElem?_eq_getElem hi] at hget
    injection hget with hget_eq; subst hget_eq
    have hwfi := hnodes_wf ⟨idx, hi⟩
    rw [Fin.getElem_fin] at hwfi
    rcases servingNodePreRefresh_and_cache_of_wellFormed hwfi with ⟨hpre, hcache⟩
    exact ⟨hwfi.2.1, hwfi.2.2.1, hpre, hcache⟩
  have hl1 := alg4Line1Aux_spec st.coords pts' mode st.servingNodes st.activeSet P' (some rootEv)
    choices.servingRouteQueries choices.servingRadiusMaxHints hpts_act hroot_ev hl1_in
  rcases hl1_eq : alg4Line1Aux pts' mode (some rootEv) st.servingNodes
      choices.servingRouteQueries choices.servingRadiusMaxHints with ⟨nodesLine1, leafEv⟩
  rw [hl1_eq] at hl1
  rcases hl1 with ⟨_, _, hleaf_ev, hidx1⟩
  have hleaf_eq : st.terminalLeaf = servingChainInputAt st.coords
      (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet
      st.servingNodes.length := by
    simpa [Alg4State.toScheduledServingChain] using hchain_wf.2.1
  rw [← hleaf_eq] at hleaf_ev
  let leafLine1 : Finset ι := applyLeafPoolEvent st.terminalLeaf leafEv
  have hl1_apply_eq :
      alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
        choices.servingRouteQueries choices.servingRadiusMaxHints =
        (nodesLine1, leafLine1, leafEv.isClockTick) := by
    have h := alg4Line1ApplyToServingChain_eq pts' mode st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
    dsimp only [rootEv] at hl1_eq
    rw [hl1_eq] at h; dsimp only at h; exact h
  have hleafLine1_eq : leafLine1 = servingChainInputAt pts'
      (nodesLine1.map (fun p => p.1.toServingNodeState)) P' nodesLine1.length := by
    cases leafEv with
    | externalInsert p => exact hleaf_ev.2.symm
    | externalDelete p => exact hleaf_ev.2.symm
    | virtualValueDelete => exact hleaf_ev.symm
    | unaffected => exact hleaf_ev.symm
  rcases alg4Lines2To6StepPendingJobs_basic pts' mode α L nodesLine1 P' choices.pendingJobChoices with
    ⟨hLen26, hballs26, hidx26⟩
  set nodes26 := alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
  have hleafLine1_26 : leafLine1 = servingChainInputAt pts'
      (nodes26.map (fun p => p.1.toServingNodeState)) P' nodes26.length := by
    rw [hleafLine1_eq, ← hLen26]
    symm
    apply servingChainInputAt_eq_of_take_balls
    rw [List.map_take, List.map_take, hballs26]
  have hleafTick_false : leafEv.isClockTick = false →
      IsExactLeafAnswer pts' leafLine1 st.terminalLeafAnswer ∧
      st.terminalLeafDistSq = (baselinePairLength pts' st.terminalLeafAnswer) ^ 2 := by
    intro hltf
    have hl_same : leafLine1 = st.terminalLeaf := by
      cases leafEv <;> simp [PoolUpdateEvent.isClockTick] at hltf <;> rfl
    rw [hl_same]
    have hsub_leaf : st.terminalLeaf ⊆ st.activeSet := by
      rw [hleaf_eq]; exact servingChainInputAt_subset _ _ _ _
    have hpts_leaf : ∀ x ∈ st.terminalLeaf, st.coords x = pts' x :=
      fun x hx => (hpts_act x (hsub_leaf hx)).symm
    have hex0 : IsExactLeafAnswer st.coords st.terminalLeaf st.terminalLeafAnswer :=
      hchain_wf.2.2
    exact ⟨(isExactLeafAnswer_congr st.terminalLeafAnswer hpts_leaf).mp hex0,
      hleaf_sq.trans (by rw [baselinePairLength_congr_exact hex0 hpts_leaf])⟩
  have h26_dwf : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
      nodes26[idx]? = some p →
      let S_idx := servingChainInputAt pts'
        (nodes26.map (fun q => q.1.toServingNodeState)) P' idx
      TaggedNodeDataWF mode pts' S_idx p ∧
      ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
        PendingJobDataWF mode α L pts' S_idx job := by
    intro idx p26 hp26
    have hi26 : idx < nodes26.length := by
      by_contra hge; rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hp26; cases hp26
    have hi1 : idx < nodesLine1.length := by omega
    have hi0 : idx < st.servingNodes.length := by omega
    have hS_eq : servingChainInputAt pts'
        (nodes26.map (fun q => q.1.toServingNodeState)) P' idx =
        servingChainInputAt pts'
        (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx := by
      apply servingChainInputAt_eq_of_take_balls
      rw [List.map_take, List.map_take, hballs26]
    rcases hidx1 idx (st.servingNodes[idx]'hi0) (nodesLine1[idx]'hi1)
      (List.getElem?_eq_getElem hi0) (List.getElem?_eq_getElem hi1) with
      ⟨hev1, _, _, _, hown1, _, _, _, _, hpre1, hfalse1⟩
    have hs26 := hidx26 idx (nodesLine1[idx]'hi1) p26
      (List.getElem?_eq_getElem hi1) hp26
    dsimp only
    rw [hS_eq]
    refine ⟨⟨⟨?_, ?_⟩, ?_⟩, ?_⟩
    · unfold RadiusDictState.IsComplete
      rw [hs26.2.2.1, hs26.2.2.2.2.2.1]; exact hpre1.1
    · rw [hs26.2.2.1, hs26.2.2.2.2.2.2.1]; exact hpre1.2
    · intro hp2f
      rw [hs26.1] at hp2f
      rw [hs26.2.2.2.2.2.2.2.2.2.2.2.1 hp2f]
      exact (hfalse1 hp2f).2.2
    · intro job' hjob'
      by_cases hct : (nodesLine1[idx]'hi1).2.isClockTick = true
      · have hstep := hs26.2.2.2.2.2.2.2.2.2.2.2.2 hct
        cases hown_l1 : (nodesLine1[idx]'hi1).1.ownedJob with
        | none => rw [hown_l1] at hstep; rw [hstep, hown_l1] at hjob'; cases hjob'
        | some job0 =>
          rw [hown_l1] at hstep; rw [hstep] at hjob'
          dsimp only at hjob'
          injection hjob' with hj_eq; subst hj_eq
          have hown0 : (st.servingNodes[idx]'hi0).ownedJob = some job0 := by rw [← hown1]; exact hown_l1
          have hjob_wf := (hnodes_wf ⟨idx, hi0⟩).2.2.2.2.2.2.2.2
          rw [Fin.getElem_fin, hown0] at hjob_wf
          have hpts_S : ∀ x ∈ st.servingInputAt idx, pts' x = st.coords x :=
            fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
          have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi0)
          have hpts_B : ∀ lv ∈ job0.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts' x = st.coords x :=
            fun lv hlv x hx =>
              updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job0 hown0).2 lv hlv).1 hx)
          exact stepSinglePendingJob_dataWF hα_le _ hpts_S hpts_B hev1 (pendingJobDataWF_of_wellFormed hjob_wf)
      · have hctf : (nodesLine1[idx]'hi1).2.isClockTick = false := Bool.eq_false_iff.mpr hct
        have hsn_eq : p26.1 = st.servingNodes[idx]'hi0 :=
          (hs26.2.2.2.2.2.2.2.2.2.2.2.1 hctf).trans (hfalse1 hctf).1
        have hS_same : servingChainInputAt pts'
            (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx =
            st.servingInputAt idx := (hfalse1 hctf).2.1
        rw [hsn_eq] at hjob'; rw [hS_same]
        have hjob_wf := (hnodes_wf ⟨idx, hi0⟩).2.2.2.2.2.2.2.2
        rw [Fin.getElem_fin, hjob'] at hjob_wf
        have hpts_S : ∀ x ∈ st.servingInputAt idx, pts' x = st.coords x :=
          fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
        have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi0)
        have hpts_B : ∀ lv ∈ job'.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts' x = st.coords x :=
          fun lv hlv x hx =>
            updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job' hjob').2 lv hlv).1 hx)
        exact pendingJobDataWF_congr (pendingJobDataWF_of_wellFormed hjob_wf) hpts_S hpts_B
  have h78 := alg4Lines7To8InstallCompletedJobs_dataWF pts' mode α L D_out
    nodes26 P' leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick
    hleafLine1_26 hleafTick_false h26_dwf
  rcases h78_eq : alg4Lines7To8InstallCompletedJobs nodes26
      leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick with
    ⟨nodes78, leaf78, leafAns78, leafSq78, leafCh78, retired78⟩
  rw [h78_eq] at h78
  rcases h78 with ⟨hleaf78, hlch78, htag78, hret78⟩
  have h9 := alg4Line9StartDueJobsAndHandleLeaves_dataWF (D_out := D_out)
    hα_pos hα_le hL_pos P' nodes78 leaf78 leafAns78 leafSq78 leafCh78
    choices.leafRebuildChoices choices.terminalLeafHint hleaf78 hlch78 htag78
  rcases h9_eq : alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
      nodes78 leaf78 leafAns78 leafSq78 leafCh78
      choices.leafRebuildChoices choices.terminalLeafHint with
    ⟨nodes9, finalLeaf, finalLeafAns, finalLeafSq, retiredDue⟩
  rw [h9_eq] at h9
  rcases h9 with ⟨_, _, _, _, hret9⟩
  have hnew_eq : alg4StepNewRetired mode α L st upd choices =
      retired78 ++ retiredDue ++ choices.stepExtraRetired := by
    unfold alg4StepNewRetired
    dsimp only
    rw [show applyAlg4PointSetUpdate st.activeSet upd = P' from rfl,
      show updateAlg4Coords st.coords upd = pts' from rfl, hl1_apply_eq]
    dsimp only
    rw [show alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices = nodes26 from rfl]
    rw [h78_eq]; dsimp only; rw [h9_eq]
  refine ⟨?_, ?_⟩
  · rw [hnew_eq]
    intro r hr
    rcases List.mem_append.mp hr with hr12 | hr3
    · rcases List.mem_append.mp hr12 with hr1 | hr2
      · exact hret78 hD_out r hr1
      · exact hret9 hD_out r hr2
    · exact hextra r hr3
  · rw [hnew_eq]
    unfold alg4Step
    dsimp only
    rw [show applyAlg4PointSetUpdate st.activeSet upd = P' from rfl,
      show updateAlg4Coords st.coords upd = pts' from rfl, hl1_apply_eq]
    dsimp only
    rw [show alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices = nodes26 from rfl]
    rw [h78_eq]; dsimp only; rw [h9_eq]

theorem endpoint_space_bound_of_reachable {d n : ℕ} {ι : Type}
    {mode : Alg4Mode} {α C : ℝ} {K₀ L D_out : ℕ}
    (h2n : 2 ≤ n) (hα_pos : 0 < α) (hα_le : α ≤ 1) (hC : 0 ≤ C)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    {st : Alg4State d ι}
    (hinv : ReachableAlg4Inv n mode α L D_out st)
    (hq_bound : retirementQueueRecordCount st.retirementQueue ≤
      (⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊ + 1) ^ 2 * (L + 1) ^ 2) :
    let L_log : ℕ := Nat.clog 2 (2 * n)
    let D₀ : ℕ := ⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊
    (((st.activeSet.card * (d + 1) +
      st.retainedChainSnapshotCards.sum * (L_log + 1) +
      (D₀ + D₀ ^ 2) * L +
      st.terminalLeaf.card ^ 2 +
      retirementQueueRecordCount st.retirementQueue * (D_out + 1) : ℕ) : ℝ) ≤
      cEndSpaceVal * (n : ℝ) * ((d + 1 : ℝ)) * ((D₀ : ℝ) ^ 2) *
        ((L + 1 : ℝ) ^ 2) * ((D_out + 1 : ℝ))) := by
  dsimp only
  set L_log : ℕ := Nat.clog 2 (2 * n)
  set D₀ : ℕ := ⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊
  rcases d0_and_llog_bounds h2n hα_pos hα_le with ⟨hD0_pos, _, _, hLlog_le_D0, _⟩
  rcases reachableState_chain_bounds h2n hα_pos hα_le hL hinv with
    ⟨_, _, _, _, _, _, hcards_tele, _⟩
  have hact_le_n : st.activeSet.card ≤ n := hinv.1.1
  have hleaf_le_6L : st.terminalLeaf.card ≤ 6 * L := hinv.1.2.2.1
  have h64_inv : 64 * α⁻¹ ≤ (L : ℝ) := (cutoff_sixty_four_le_alpha_L h2n hα_pos hC hL).1
  set R : ℝ := (n : ℝ) * (d + 1 : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ)
  have hn_ge2 : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast h2n
  have hd_ge1 : (1 : ℝ) ≤ (d + 1 : ℝ) := by
    have : (0 : ℝ) ≤ (d : ℝ) := Nat.cast_nonneg d; linarith
  have hD0_ge1 : (1 : ℝ) ≤ (D₀ : ℝ) := Nat.one_le_cast.mpr hD0_pos
  have hD0_sq_ge1 : (1 : ℝ) ≤ (D₀ : ℝ) ^ 2 := by
    have := mul_le_mul hD0_ge1 hD0_ge1 (by norm_num) (by linarith); linarith
  have hL_ge0 : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  have hL1_ge1 : (1 : ℝ) ≤ (L + 1 : ℝ) := by linarith
  have hL1_sq_ge1 : (1 : ℝ) ≤ (L + 1 : ℝ) ^ 2 := by
    have := mul_le_mul hL1_ge1 hL1_ge1 (by norm_num) (by linarith); linarith
  have hDout1_ge1 : (1 : ℝ) ≤ (D_out + 1 : ℝ) := by
    have : (0 : ℝ) ≤ (D_out : ℝ) := Nat.cast_nonneg D_out; linarith
  have hR_nn : 0 ≤ R := by dsimp only [R]; positivity
  -- Helper: `(n : ℝ) * (d + 1 : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ)` dominates subproducts
  have hdom_nd : (n : ℝ) * (d + 1 : ℝ) ≤ R := by
    have hprod1 : (1 : ℝ) ≤ ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ) := by
      have h12 := mul_le_mul hD0_sq_ge1 hL1_sq_ge1 (by norm_num) (by positivity)
      have h123 := mul_le_mul h12 hDout1_ge1 (by norm_num) (by positivity)
      linarith
    have hm := mul_le_mul_of_nonneg_left hprod1 (show 0 ≤ (n : ℝ) * (d + 1 : ℝ) by positivity)
    dsimp only [R]; linarith
  have hdom_nD2L2 : (n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) ≤ R := by
    have hprod1 : (1 : ℝ) ≤ (d + 1 : ℝ) * (D_out + 1 : ℝ) := by
      have := mul_le_mul hd_ge1 hDout1_ge1 (by norm_num) (by positivity); linarith
    have hm := mul_le_mul_of_nonneg_left hprod1
      (show 0 ≤ (n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) by positivity)
    have heq : (n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * ((d + 1 : ℝ) * (D_out + 1 : ℝ)) = R := by
      dsimp only [R]; ring
    linarith
  have hdom_nD2L2Dout : (n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ) ≤ R := by
    have hm := mul_le_mul_of_nonneg_right hd_ge1
      (show 0 ≤ (n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ) by positivity)
    have heq : (d + 1 : ℝ) * ((n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ)) = R := by
      dsimp only [R]; ring
    linarith
  -- Bound each of the 5 terms
  have ht1 : ((st.activeSet.card * (d + 1) : ℕ) : ℝ) ≤ R := by
    push_cast
    have h1 : (st.activeSet.card : ℝ) * (d + 1 : ℝ) ≤ (n : ℝ) * (d + 1 : ℝ) :=
      mul_le_mul_of_nonneg_right (Nat.cast_le.mpr hact_le_n) (by positivity)
    linarith
  have ht2 : ((st.retainedChainSnapshotCards.sum * (L_log + 1) : ℕ) : ℝ) ≤ R := by
    have hcast : ((st.retainedChainSnapshotCards.sum * (L_log + 1) : ℕ) : ℝ) =
        ((st.retainedChainSnapshotCards.sum : ℕ) : ℝ) * ((L_log + 1 : ℕ) : ℝ) := Nat.cast_mul _ _
    rw [hcast]
    have hLlog_r : ((L_log + 1 : ℕ) : ℝ) ≤ (D₀ : ℝ) := Nat.cast_le.mpr hLlog_le_D0
    have hm1 : ((st.retainedChainSnapshotCards.sum : ℕ) : ℝ) * ((L_log + 1 : ℕ) : ℝ) ≤
        (16 * (n : ℝ) * (D₀ : ℝ) * α⁻¹) * (D₀ : ℝ) :=
      mul_le_mul hcards_tele hLlog_r (Nat.cast_nonneg _) (by positivity)
    have h16_le_L2 : 16 * α⁻¹ ≤ (L + 1 : ℝ) ^ 2 := by
      have hL_le_sq : (L : ℝ) ≤ (L + 1 : ℝ) ^ 2 := by
        have hsq : (L + 1 : ℝ) ^ 2 = (L : ℝ) ^ 2 + 2 * (L : ℝ) + 1 := by ring
        have : 0 ≤ (L : ℝ) ^ 2 := sq_nonneg (L : ℝ)
        linarith
      have : 16 * α⁻¹ ≤ 64 * α⁻¹ := by
        have : 0 ≤ α⁻¹ := by positivity
        linarith
      linarith
    have hm2 : (16 * α⁻¹) * ((n : ℝ) * ((D₀ : ℝ) ^ 2)) ≤
        ((L + 1 : ℝ) ^ 2) * ((n : ℝ) * ((D₀ : ℝ) ^ 2)) :=
      mul_le_mul_of_nonneg_right h16_le_L2 (by positivity)
    have heq1 : (16 * (n : ℝ) * (D₀ : ℝ) * α⁻¹) * (D₀ : ℝ) =
        (16 * α⁻¹) * ((n : ℝ) * ((D₀ : ℝ) ^ 2)) := by ring
    have heq2 : ((L + 1 : ℝ) ^ 2) * ((n : ℝ) * ((D₀ : ℝ) ^ 2)) =
        (n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) := by ring
    linarith
  have ht3 : (((D₀ + D₀ ^ 2) * L : ℕ) : ℝ) ≤ R := by
    push_cast
    have hD_le_D2 : (D₀ : ℝ) ≤ (D₀ : ℝ) ^ 2 := by
      have := mul_le_mul_of_nonneg_right hD0_ge1 (show 0 ≤ (D₀ : ℝ) by positivity)
      have heq : (D₀ : ℝ) * (D₀ : ℝ) = (D₀ : ℝ) ^ 2 := by ring
      linarith
    have hL_le_sq : (L : ℝ) ≤ (L + 1 : ℝ) ^ 2 := by
      have hsq : (L + 1 : ℝ) ^ 2 = (L : ℝ) ^ 2 + 2 * (L : ℝ) + 1 := by ring
      have : 0 ≤ (L : ℝ) ^ 2 := sq_nonneg (L : ℝ)
      linarith
    have hm1 : ((D₀ : ℝ) + (D₀ : ℝ) ^ 2) * (L : ℝ) ≤ (2 * (D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) :=
      mul_le_mul (by linarith) hL_le_sq hL_ge0 (by positivity)
    have hm2 : 2 * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2)) ≤
        (n : ℝ) * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2)) :=
      mul_le_mul_of_nonneg_right hn_ge2 (by positivity)
    have heq1 : (2 * (D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) =
        2 * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2)) := by ring
    have heq2 : (n : ℝ) * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2)) =
        (n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) := by ring
    linarith
  have ht4 : ((st.terminalLeaf.card ^ 2 : ℕ) : ℝ) ≤ 18 * R := by
    have hleaf_sq_nat : st.terminalLeaf.card ^ 2 ≤ (6 * L) ^ 2 :=
      Nat.pow_le_pow_left hleaf_le_6L 2
    have hleaf_sq_r : ((st.terminalLeaf.card ^ 2 : ℕ) : ℝ) ≤ 36 * (L : ℝ) ^ 2 := by
      have h1 : ((st.terminalLeaf.card ^ 2 : ℕ) : ℝ) ≤ (((6 * L) ^ 2 : ℕ) : ℝ) :=
        Nat.cast_le.mpr hleaf_sq_nat
      have h2 : (((6 * L) ^ 2 : ℕ) : ℝ) = 36 * (L : ℝ) ^ 2 := by push_cast; ring
      rwa [h2] at h1
    have hL2_le : (L : ℝ) ^ 2 ≤ (L + 1 : ℝ) ^ 2 :=
      pow_le_pow_left₀ hL_ge0 (by linarith) 2
    have hm1 : 36 * (L : ℝ) ^ 2 ≤ 18 * (2 * ((L + 1 : ℝ) ^ 2)) := by linarith
    have hm2 : 2 * ((L + 1 : ℝ) ^ 2) ≤ (n : ℝ) * (1 * ((L + 1 : ℝ) ^ 2)) := by
      have := mul_le_mul_of_nonneg_right hn_ge2 (show 0 ≤ (L + 1 : ℝ) ^ 2 by positivity)
      linarith
    have hm3 : (n : ℝ) * (1 * ((L + 1 : ℝ) ^ 2)) ≤ (n : ℝ) * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2)) := by
      have hsub := mul_le_mul_of_nonneg_right hD0_sq_ge1 (show 0 ≤ (L + 1 : ℝ) ^ 2 by positivity)
      exact mul_le_mul_of_nonneg_left hsub (by positivity)
    have heq : (n : ℝ) * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2)) =
        (n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) := by ring
    linarith
  have ht5 : ((retirementQueueRecordCount st.retirementQueue * (D_out + 1) : ℕ) : ℝ) ≤ 2 * R := by
    have hq_nat : retirementQueueRecordCount st.retirementQueue ≤ 4 * D₀ ^ 2 * (L + 1) ^ 2 := by
      have hd1 : (D₀ + 1) ^ 2 ≤ (2 * D₀) ^ 2 := Nat.pow_le_pow_left (by omega) 2
      have heq : (2 * D₀) ^ 2 = 4 * D₀ ^ 2 := by ring
      exact le_trans hq_bound (Nat.mul_le_mul_right ((L + 1) ^ 2) (by omega))
    have hq_r : (retirementQueueRecordCount st.retirementQueue : ℝ) * (D_out + 1 : ℝ) ≤
        4 * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ) := by
      have h1 : (retirementQueueRecordCount st.retirementQueue : ℝ) ≤
          ((4 * D₀ ^ 2 * (L + 1) ^ 2 : ℕ) : ℝ) := Nat.cast_le.mpr hq_nat
      push_cast at h1
      exact mul_le_mul_of_nonneg_right h1 (by positivity)
    have hm2 : 2 * (2 * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ))) ≤
        2 * ((n : ℝ) * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ))) := by
      have hsub := mul_le_mul_of_nonneg_right hn_ge2
        (show 0 ≤ ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ) by positivity)
      linarith
    have heq1 : 4 * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ) =
        2 * (2 * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ))) := by ring
    have heq2 : (n : ℝ) * (((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ)) =
        (n : ℝ) * ((D₀ : ℝ) ^ 2) * ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ) := by ring
    push_cast
    linarith
  have hcast_sum :
      (((st.activeSet.card * (d + 1) +
        st.retainedChainSnapshotCards.sum * (L_log + 1) +
        (D₀ + D₀ ^ 2) * L +
        st.terminalLeaf.card ^ 2 +
        retirementQueueRecordCount st.retirementQueue * (D_out + 1) : ℕ)) : ℝ) =
      ((st.activeSet.card * (d + 1) : ℕ) : ℝ) +
      ((st.retainedChainSnapshotCards.sum * (L_log + 1) : ℕ) : ℝ) +
      (((D₀ + D₀ ^ 2) * L : ℕ) : ℝ) +
      ((st.terminalLeaf.card ^ 2 : ℕ) : ℝ) +
      ((retirementQueueRecordCount st.retirementQueue * (D_out + 1) : ℕ) : ℝ) := by
    push_cast; ring
  rw [hcast_sum]
  have hRHS_eq : cEndSpaceVal * (n : ℝ) * (d + 1 : ℝ) * ((D₀ : ℝ) ^ 2) *
      ((L + 1 : ℝ) ^ 2) * (D_out + 1 : ℝ) = 128 * R := by
    unfold cEndSpaceVal; dsimp only [R]; ring
  rw [hRHS_eq]
  linarith

theorem general_cards_and_space_of_reachable {d n : ℕ} {ι : Type}
    {mode : Alg4Mode} {α C σ P_space : ℝ} {K₀ L D_out : ℕ}
    (P_α P_cfg P_int : ℕ → ℕ → ℝ)
    (h2n : 2 ≤ n) (hα_pos : 0 < α) (hα_le : α ≤ 1)
    (hL : SatisfiesLeafCutoffEq10 d n α C K₀ L)
    (hσ : 0 ≤ σ) (hP_space : 1 ≤ P_space)
    {st : Alg4State d ι}
    (hinv : ReachableAlg4Inv n mode α L D_out st)
    (numIntervalLevels : ℕ) (localGenCards : List ℕ)
    (hPα : α⁻¹ ≤ P_α d (Nat.clog 2 (2 * n)))
    (hPcfg : ∀ V : ℝ, ((mode.retainedConfigs V).card : ℝ) ≤ P_cfg d (Nat.clog 2 (2 * n)))
    (hPint : (numIntervalLevels : ℝ) ≤ P_int d (Nat.clog 2 (2 * n)))
    (hlocal : IsValidLocalFrozenGenCards n numIntervalLevels mode st localGenCards) :
    let L_log : ℕ := Nat.clog 2 (2 * n)
    let allCards : List ℕ := st.retainedChainSnapshotCards ++ localGenCards
    ((allCards.sum : ℕ) : ℝ) ≤ (n : ℝ) * mkPCard P_α P_cfg P_int d L_log ∧
    (∀ qSpace : ℝ,
      qSpace ≤ 2 * (n : ℝ) ^ (1 + σ) * P_space * mkPCard P_α P_cfg P_int d L_log →
        ((allCards.map (fun m => birthPoolSpaceBound m σ P_space)).sum + qSpace) ≤
          (n : ℝ) ^ (1 + σ) * P_space * mkPSpaceTot P_α P_cfg P_int d L_log) := by
  dsimp only
  set L_log : ℕ := Nat.clog 2 (2 * n)
  set D₀ : ℕ := ⌈cDepthVal * α⁻¹ * Real.log (n : ℝ)⌉₊
  rcases d0_and_llog_bounds h2n hα_pos hα_le with ⟨_, _, _, _, hD0_le_mkD⟩
  have hBD : (D₀ : ℝ) ≤ mkDBound P_α d L_log := hD0_le_mkD P_α d hPα
  rcases reachableState_chain_bounds h2n hα_pos hα_le hL hinv with
    ⟨_, hserv_len, _, hpfx_len_all, hchain_le_n, hchain_sum_poly, _, _⟩
  set B_D : ℝ := mkDBound P_α d L_log
  set B_cfg : ℝ := max 1 (P_cfg d L_log)
  set B_int : ℝ := max 1 (P_int d L_log)
  have hBD_nn : 0 ≤ B_D := le_trans (Nat.cast_nonneg D₀) hBD
  have hBcfg_ge1 : 1 ≤ B_cfg := le_max_left 1 _
  have hBint_ge1 : 1 ≤ B_int := le_max_left 1 _
  -- 1. Chain part `≤ n * (2 + 2 * B_D + 2 * B_D ^ 2)`
  have hchain_r : ((st.retainedChainSnapshotCards.sum : ℕ) : ℝ) ≤
      (n : ℝ) * (2 + 2 * B_D + 2 * B_D ^ 2) := by
    have h1 : ((st.retainedChainSnapshotCards.sum : ℕ) : ℝ) ≤
        (((2 + 2 * D₀ + 2 * D₀ ^ 2) * n : ℕ) : ℝ) := Nat.cast_le.mpr hchain_sum_poly
    have h2 : (((2 + 2 * D₀ + 2 * D₀ ^ 2) * n : ℕ) : ℝ) =
        (n : ℝ) * (2 + 2 * (D₀ : ℝ) + 2 * (D₀ : ℝ) ^ 2) := by push_cast; ring
    rw [h2] at h1
    have hD2 : (D₀ : ℝ) ^ 2 ≤ B_D ^ 2 := pow_le_pow_left₀ (Nat.cast_nonneg D₀) hBD 2
    have hpoly_le : 2 + 2 * (D₀ : ℝ) + 2 * (D₀ : ℝ) ^ 2 ≤ 2 + 2 * B_D + 2 * B_D ^ 2 := by linarith
    exact le_trans h1 (mul_le_mul_of_nonneg_left hpoly_le (Nat.cast_nonneg n))
  -- 2. Local frozen generations part `≤ n * (8 * B_int * (B_D + B_D ^ 2) * B_cfg)`
  rcases hlocal with ⟨hloc_le_n, hloc_mode⟩
  have hloc_len_r : (localGenCards.length : ℝ) ≤ 8 * B_int * (B_D + B_D ^ 2) * B_cfg := by
    cases mode with
    | endpointSqrt2 =>
      dsimp only at hloc_mode
      rw [hloc_mode]
      simp only [List.length_nil, Nat.cast_zero]
      positivity
    | subSqrt2 params =>
      dsimp only at hloc_mode
      have hloc_nat : (localGenCards.length : ℝ) ≤
          ((8 * numIntervalLevels *
            (st.servingNodes.map (fun sn =>
              ((Alg4Mode.subSqrt2 params).retainedConfigs sn.node.V).card +
                match sn.ownedJob with
                | none => 0
                | some job =>
                    (job.completedPrefix.map (fun lv =>
                      ((Alg4Mode.subSqrt2 params).retainedConfigs lv.ball.V).card)).sum)).sum : ℕ) : ℝ) :=
        Nat.cast_le.mpr hloc_mode
      push_cast at hloc_nat
      -- Bound each serving node's config count by `(1 + D₀) * B_cfg`
      have hsn_cfg_each : ∀ x ∈ st.servingNodes.map (fun sn =>
          ((Alg4Mode.subSqrt2 params).retainedConfigs sn.node.V).card +
            match sn.ownedJob with
            | none => 0
            | some job =>
                (job.completedPrefix.map (fun lv =>
                  ((Alg4Mode.subSqrt2 params).retainedConfigs lv.ball.V).card)).sum),
          (x : ℝ) ≤ (1 + (D₀ : ℝ)) * B_cfg := by
        intro x hx
        rcases List.mem_map.mp hx with ⟨sn, hsn_mem, rfl⟩
        have htop : (((Alg4Mode.subSqrt2 params).retainedConfigs sn.node.V).card : ℝ) ≤ B_cfg :=
          le_trans (hPcfg sn.node.V) (le_max_right 1 _)
        cases hown : sn.ownedJob with
        | none =>
          simp only [Nat.add_zero]
          have h1 : 1 * B_cfg ≤ (1 + (D₀ : ℝ)) * B_cfg :=
            mul_le_mul_of_nonneg_right (by have : (0 : ℝ) ≤ (D₀ : ℝ) := Nat.cast_nonneg D₀; linarith) (by linarith)
          linarith
        | some job =>
          simp only [Nat.cast_add]
          have hp_each : ∀ y ∈ job.completedPrefix.map (fun lv =>
              ((Alg4Mode.subSqrt2 params).retainedConfigs lv.ball.V).card),
              (y : ℝ) ≤ B_cfg := by
            intro y hy
            rcases List.mem_map.mp hy with ⟨lv, _, rfl⟩
            exact le_trans (hPcfg lv.ball.V) (le_max_right 1 _)
          have hp_sum := list_sum_real_le_length_mul (by linarith) hp_each
          simp only [List.length_map] at hp_sum
          have hp_len_r : (job.completedPrefix.length : ℝ) ≤ (D₀ : ℝ) :=
            Nat.cast_le.mpr (hpfx_len_all sn hsn_mem job hown)
          have hm := mul_le_mul_of_nonneg_right hp_len_r (show 0 ≤ B_cfg by linarith)
          linarith
      have hcfg_sum := list_sum_real_le_length_mul (by positivity) hsn_cfg_each
      simp only [List.length_map] at hcfg_sum
      have hserv_r : (st.servingNodes.length : ℝ) ≤ B_D :=
        le_trans (Nat.cast_le.mpr hserv_len) hBD
      have h1D_le : 1 + (D₀ : ℝ) ≤ 1 + B_D := by linarith
      have hprod_D : (st.servingNodes.length : ℝ) * ((1 + (D₀ : ℝ)) * B_cfg) ≤
          (B_D + B_D ^ 2) * B_cfg := by
        have hm1 : (st.servingNodes.length : ℝ) * (1 + (D₀ : ℝ)) ≤ B_D * (1 + B_D) :=
          mul_le_mul hserv_r h1D_le (by positivity) hBD_nn
        have hm2 := mul_le_mul_of_nonneg_right hm1 (show 0 ≤ B_cfg by linarith)
        have heq1 : (st.servingNodes.length : ℝ) * (1 + (D₀ : ℝ)) * B_cfg =
            (st.servingNodes.length : ℝ) * ((1 + (D₀ : ℝ)) * B_cfg) := by ring
        have heq2 : B_D * (1 + B_D) * B_cfg = (B_D + B_D ^ 2) * B_cfg := by ring
        linarith
      have hint_le : (numIntervalLevels : ℝ) ≤ B_int := le_trans hPint (le_max_right 1 _)
      set S_cfg_nat : ℕ := (st.servingNodes.map (fun sn =>
        ((Alg4Mode.subSqrt2 params).retainedConfigs sn.node.V).card +
          match sn.ownedJob with
          | none => 0
          | some job =>
              (job.completedPrefix.map (fun lv =>
                ((Alg4Mode.subSqrt2 params).retainedConfigs lv.ball.V).card)).sum)).sum
      have hloc_nat' : (localGenCards.length : ℝ) ≤ (8 * (numIntervalLevels : ℝ)) * (S_cfg_nat : ℝ) := by
        have h1 : (localGenCards.length : ℝ) ≤ ((8 * numIntervalLevels * S_cfg_nat : ℕ) : ℝ) :=
          Nat.cast_le.mpr hloc_mode
        have h2 : ((8 * numIntervalLevels * S_cfg_nat : ℕ) : ℝ) =
            (8 * (numIntervalLevels : ℝ)) * (S_cfg_nat : ℝ) := by push_cast; ring
        rwa [h2] at h1
      have hcfg_le_B : (S_cfg_nat : ℝ) ≤ (B_D + B_D ^ 2) * B_cfg := le_trans hcfg_sum hprod_D
      have hm_final : (8 * (numIntervalLevels : ℝ)) * (S_cfg_nat : ℝ) ≤
          (8 * B_int) * ((B_D + B_D ^ 2) * B_cfg) :=
        mul_le_mul (mul_le_mul_of_nonneg_left hint_le (by norm_num : (0 : ℝ) ≤ 8))
          hcfg_le_B (Nat.cast_nonneg _) (by positivity)
      have heq_rhs : (8 * B_int) * ((B_D + B_D ^ 2) * B_cfg) =
          8 * B_int * (B_D + B_D ^ 2) * B_cfg := by ring
      rw [heq_rhs] at hm_final
      exact le_trans hloc_nat' hm_final
  have hloc_sum_r : ((localGenCards.sum : ℕ) : ℝ) ≤
      (n : ℝ) * (8 * B_int * (B_D + B_D ^ 2) * B_cfg) := by
    have h1 : ((localGenCards.sum : ℕ) : ℝ) ≤ ((localGenCards.length * n : ℕ) : ℝ) :=
      Nat.cast_le.mpr (list_sum_le_length_mul hloc_le_n)
    have h2 : ((localGenCards.length * n : ℕ) : ℝ) = (n : ℝ) * (localGenCards.length : ℝ) := by
      push_cast; ring
    rw [h2] at h1
    exact le_trans h1 (mul_le_mul_of_nonneg_left hloc_len_r (Nat.cast_nonneg n))
  set allCards : List ℕ := st.retainedChainSnapshotCards ++ localGenCards
  have hall_sum_r : ((allCards.sum : ℕ) : ℝ) ≤ (n : ℝ) * mkPCard P_α P_cfg P_int d L_log := by
    have hsum_app : ((allCards.sum : ℕ) : ℝ) =
        ((st.retainedChainSnapshotCards.sum : ℕ) : ℝ) + ((localGenCards.sum : ℕ) : ℝ) := by
      simp [allCards]
    rw [hsum_app]
    unfold mkPCard
    have heq : (n : ℝ) * ((2 + 2 * B_D + 2 * B_D ^ 2) + 8 * B_int * (B_D + B_D ^ 2) * B_cfg) =
        (n : ℝ) * (2 + 2 * B_D + 2 * B_D ^ 2) +
          (n : ℝ) * (8 * B_int * (B_D + B_D ^ 2) * B_cfg) := by ring
    dsimp only [B_D, B_cfg, B_int] at heq hchain_r hloc_sum_r
    linarith
  refine ⟨hall_sum_r, ?_⟩
  -- 3. Power-space bound across `allCards` + `qSpace`
  intro qSpace hqSpace
  have hall_le_n : ∀ m ∈ allCards, m ≤ n := by
    intro m hm
    rcases List.mem_append.mp hm with hc | hl
    · exact hchain_le_n m hc
    · exact hloc_le_n m hl
  have hP_nn : 0 ≤ P_space := by linarith
  have hptwise_sp : ∀ m ∈ allCards,
      birthPoolSpaceBound m σ P_space ≤ ((n : ℝ) ^ σ * P_space) * (m : ℝ) := by
    intro m hm
    unfold birthPoolSpaceBound
    have hp := power_space_ineq_all m n σ (hall_le_n m hm) hσ
    have hm_sp := mul_le_mul_of_nonneg_right hp hP_nn
    linarith
  have hsp_sum1 := list_sum_map_le_sum_map_real allCards _ _ hptwise_sp
  rw [list_sum_map_const_mul_nat] at hsp_sum1
  have hn_pos : (0 : ℝ) < (n : ℝ) := by
    have : 0 < n := by omega
    exact_mod_cast this
  have hnsig_nn : 0 ≤ (n : ℝ) ^ σ * P_space :=
    mul_nonneg (Real.rpow_nonneg (le_of_lt hn_pos) σ) hP_nn
  have hsp_sum2 : ((n : ℝ) ^ σ * P_space) * ((allCards.sum : ℕ) : ℝ) ≤
      ((n : ℝ) ^ σ * P_space) * ((n : ℝ) * mkPCard P_α P_cfg P_int d L_log) :=
    mul_le_mul_of_nonneg_left hall_sum_r hnsig_nn
  have hrpow_combine : (n : ℝ) ^ σ * (n : ℝ) = (n : ℝ) ^ (1 + σ) := by
    rw [Real.rpow_add hn_pos 1 σ, Real.rpow_one, mul_comm]
  have hrhs_sp : ((n : ℝ) ^ σ * P_space) * ((n : ℝ) * mkPCard P_α P_cfg P_int d L_log) =
      (n : ℝ) ^ (1 + σ) * P_space * mkPCard P_α P_cfg P_int d L_log := by
    calc
      ((n : ℝ) ^ σ * P_space) * ((n : ℝ) * mkPCard P_α P_cfg P_int d L_log)
        = ((n : ℝ) ^ σ * (n : ℝ)) * P_space * mkPCard P_α P_cfg P_int d L_log := by ring
      _ = (n : ℝ) ^ (1 + σ) * P_space * mkPCard P_α P_cfg P_int d L_log := by rw [hrpow_combine]
  unfold mkPSpaceTot
  linarith

end UL.Proof.claim_C_2_space_reclaim.RacerP44
