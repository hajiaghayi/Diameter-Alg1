import UL.Proof.claim_C_2_space_reclaim.RacerP44_H2b1

set_option autoImplicit false

namespace UL.Proof.claim_C_2_space_reclaim.RacerP44

open UL
open UL.Proof.lem_C_2.H1
open UL.Proof.claim_C_2_space_reclaim

/-! ### 1. `servingChainInputAt` & Serving-Node Data/Cache Invariants -/

open Classical in
theorem servingChainInputAt_zero {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (nodes : List (ServingNodeState d ι)) (P : Finset ι) :
    servingChainInputAt pts nodes P 0 = P := by
  simp [servingChainInputAt]

open Classical in
theorem servingChainInputAt_cons_succ {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (sn : ServingNodeState d ι) (rest : List (ServingNodeState d ι))
    (P : Finset ι) (idx : ℕ) :
    servingChainInputAt pts (sn :: rest) P (idx + 1) =
      servingChainInputAt pts rest (sn.node.residual pts P) idx := by
  simp [servingChainInputAt]

open Classical in
theorem servingChainInputAt_eq_of_take_balls {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {n₁ n₂ : List (ServingNodeState d ι)} (P : Finset ι) (idx : ℕ)
    (h : (n₁.take idx).map ServingNodeState.node = (n₂.take idx).map ServingNodeState.node) :
    servingChainInputAt pts n₁ P idx = servingChainInputAt pts n₂ P idx := by
  unfold servingChainInputAt
  have h1 : (n₁.take idx).foldl (fun S st => st.node.residual pts S) P =
      ((n₁.take idx).map ServingNodeState.node).foldl (fun S b => b.residual pts S) P := by
    rw [List.foldl_map]
  have h2 : (n₂.take idx).foldl (fun S st => st.node.residual pts S) P =
      ((n₂.take idx).map ServingNodeState.node).foldl (fun S b => b.residual pts S) P := by
    rw [List.foldl_map]
  rw [h1, h2, h]

open Classical in
theorem servingChainInputAt_append {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (n₁ n₂ : List (ServingNodeState d ι)) (P : Finset ι) :
    (∀ idx : ℕ, idx ≤ n₁.length →
      servingChainInputAt pts (n₁ ++ n₂) P idx = servingChainInputAt pts n₁ P idx) ∧
    (∀ j : ℕ,
      servingChainInputAt pts (n₁ ++ n₂) P (n₁.length + j) =
        servingChainInputAt pts n₂ (servingChainInputAt pts n₁ P n₁.length) j) := by
  refine ⟨?_, ?_⟩
  · intro idx hle
    unfold servingChainInputAt
    rw [List.take_append_of_le_length hle]
  · intro j
    unfold servingChainInputAt
    rw [List.take_append, List.take_of_length_le (Nat.le_add_right n₁.length j),
      Nat.add_sub_cancel_left, List.take_length, List.foldl_append]

def ServingNodePreRefreshWF {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S : Finset ι) (sn : Alg4ServingNode d ι) : Prop :=
  sn.radiusDict.IsComplete pts sn.node.o S ∧
  ValidNodeMatchingsOn pts mode sn.node S sn.localMatchings

def ServingNodeCacheWF {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S : Finset ι) (sn : Alg4ServingNode d ι) : Prop :=
  IsActiveNodePair S sn.baselinePair ∧
  sn.baselineDistSq = (baselinePairLength pts sn.baselinePair) ^ 2 ∧
  (match sn.maxMatchingPair with
  | none =>
      sn.maxMatchingDistSq = 0 ∧
      ∀ cfg ∈ mode.retainedConfigs sn.node.V, (sn.localMatchings cfg).storedEdge = none
  | some (x, y) =>
      x ∈ S ∧ y ∈ S ∧ x ≠ y ∧
      sn.maxMatchingDistSq = euclideanDistSq (pts x) (pts y) ∧
      (∃ cfg ∈ mode.retainedConfigs sn.node.V,
        (sn.localMatchings cfg).storedEdge = some (x, y)) ∧
      (∀ cfg ∈ mode.retainedConfigs sn.node.V, ∀ u v : ι,
        (sn.localMatchings cfg).storedEdge = some (u, v) →
          euclideanDistSq (pts u) (pts v) ≤ sn.maxMatchingDistSq))

def TaggedNodeDataWF {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (pts : ι → EuclideanSpace ℝ (Fin d))
    (S : Finset ι) (p : Alg4ServingNode d ι × Bool) : Prop :=
  ServingNodePreRefreshWF mode pts S p.1 ∧
  (p.2 = false → ServingNodeCacheWF mode pts S p.1)

theorem servingNodePreRefresh_and_cache_of_wellFormed {d : ℕ} {ι : Type}
    {mode : Alg4Mode} {α : ℝ} {L : ℕ}
    {pts : ι → EuclideanSpace ℝ (Fin d)} {S : Finset ι}
    {sn : Alg4ServingNode d ι}
    (hwf : sn.WellFormed mode α L pts S) :
    ServingNodePreRefreshWF mode pts S sn ∧ ServingNodeCacheWF mode pts S sn := by
  rcases hwf with ⟨_, _, _, hrd, hlm, hb1, hb2, hmax, _⟩
  exact ⟨⟨hrd, hlm⟩, ⟨hb1, hb2, hmax⟩⟩

theorem servingNodePreRefreshWF_congr {d : ℕ} {ι : Type}
    {mode : Alg4Mode} {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    {S : Finset ι} {sn : Alg4ServingNode d ι}
    (hpre : ServingNodePreRefreshWF mode pts₁ S sn)
    (hpts : ∀ x ∈ S, pts₂ x = pts₁ x) :
    ServingNodePreRefreshWF mode pts₂ S sn := by
  have hpts' : ∀ x ∈ S, pts₁ x = pts₂ x := fun x hx => (hpts x hx).symm
  exact ⟨(radiusDict_wellFormedOn_congr sn.node.o sn.radiusDict hpts').mp hpre.1,
    (validNodeMatchingsOn_congr mode sn.node sn.localMatchings hpts').mp hpre.2⟩

theorem servingNodeCacheWF_congr {d : ℕ} {ι : Type}
    {mode : Alg4Mode} {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    {S : Finset ι} {sn : Alg4ServingNode d ι}
    (hval : ValidNodeMatchingsOn pts₁ mode sn.node S sn.localMatchings)
    (hcache : ServingNodeCacheWF mode pts₁ S sn)
    (hpts : ∀ x ∈ S, pts₂ x = pts₁ x) :
    ServingNodeCacheWF mode pts₂ S sn := by
  have hpts' : ∀ x ∈ S, pts₁ x = pts₂ x := fun x hx => (hpts x hx).symm
  rcases hcache with ⟨hb_act, hb_sq, hmax⟩
  have hb_len := baselinePairLength_congr_active hb_act hpts'
  refine ⟨hb_act, hb_sq.trans (by rw [hb_len]), ?_⟩
  cases hm : sn.maxMatchingPair with
  | none =>
    rw [hm] at hmax
    exact hmax
  | some xy =>
    rcases xy with ⟨x, y⟩
    rw [hm] at hmax
    rcases hmax with ⟨hxS, hyS, hne, hmsq, hex, hle⟩
    refine ⟨hxS, hyS, hne, ?_, hex, ?_⟩
    · rw [hmsq, hpts x hxS, hpts y hyS]
    · intro cfg hcfg u v hst
      rcases storedEdge_of_validNodeMatchingsOn hval hcfg hst with ⟨huS, hvS, _⟩
      rw [hpts u huS, hpts v hvS]
      exact hle cfg hcfg u v hst

/-! ### 2. Line 1 (`alg4Line1Aux` and `alg4Line1ApplyToServingChain`) -/

open Classical in
theorem alg4Line1Aux_spec {d : ℕ} {ι : Type}
    (pts₀ pts' : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    ∀ (nodes : List (Alg4ServingNode d ι))
      (S S' : Finset ι) (activeEv : Option (PoolUpdateEvent ι))
      (qList : List (NodeMatchingQueryAnswers ι)) (mHints : List (Option ι)),
      (∀ x ∈ S, pts' x = pts₀ x) →
      IsValidPoolUpdateEvent S S' (activeEv.getD .unaffected) →
      (∀ (idx : ℕ) (sn : Alg4ServingNode d ι),
        nodes[idx]? = some sn →
        let S_cur := servingChainInputAt pts₀ (nodes.map Alg4ServingNode.toServingNodeState) S idx
        sn.trueAge ≤ sn.age ∧
        HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
        ServingNodePreRefreshWF mode pts₀ S_cur sn ∧
        ServingNodeCacheWF mode pts₀ S_cur sn) →
      let (nodes1, leafEv) := alg4Line1Aux pts' mode activeEv nodes qList mHints
      nodes1.length = nodes.length ∧
      (nodes1.map (fun p => p.1.toServingNodeState)).map ServingNodeState.node =
        (nodes.map Alg4ServingNode.toServingNodeState).map ServingNodeState.node ∧
      IsValidPoolUpdateEvent
        (servingChainInputAt pts₀ (nodes.map Alg4ServingNode.toServingNodeState) S nodes.length)
        (servingChainInputAt pts' (nodes1.map (fun p => p.1.toServingNodeState)) S' nodes1.length)
        leafEv ∧
      ∀ (idx : ℕ) (sn : Alg4ServingNode d ι) (p1 : Alg4ServingNode d ι × PoolUpdateEvent ι),
        nodes[idx]? = some sn →
        nodes1[idx]? = some p1 →
        let sn₁ := p1.1
        let ev := p1.2
        let S_before := servingChainInputAt pts₀
          (nodes.map Alg4ServingNode.toServingNodeState) S idx
        let S_after := servingChainInputAt pts'
          (nodes1.map (fun p => p.1.toServingNodeState)) S' idx
        IsValidPoolUpdateEvent S_before S_after ev ∧
        ev.ticks ≤ 1 ∧
        sn₁.birthSnapshot = sn.birthSnapshot ∧
        sn₁.node = sn.node ∧
        sn₁.ownedJob = sn.ownedJob ∧
        sn₁.trueAge = sn.trueAge + ev.ticks ∧
        sn₁.age = sn.age + ev.ticks ∧
        sn₁.trueAge ≤ sn₁.age ∧
        HasNodeAge sn₁.birthSnapshot S_after sn₁.trueAge ∧
        ServingNodePreRefreshWF mode pts' S_after sn₁ ∧
        (ev.isClockTick = false →
          sn₁ = sn ∧ S_after = S_before ∧ ServingNodeCacheWF mode pts' S_after sn₁)
  | [], S, S', activeEv, qList, mHints, _, hev, _ => by
      refine ⟨rfl, rfl, ?_, fun idx sn _ h => by simp at h⟩
      simpa [alg4Line1Aux, servingChainInputAt] using hev
  | sn :: rest, S, S', activeEv, qList, mHints, hpts_S, hev, hinv => by
      set ev := activeEv.getD .unaffected
      set qAns := qList.head?.getD (NodeMatchingQueryAnswers.empty ι)
      set mHint := mHints.head?.join
      have h0 := hinv 0 sn rfl
      rw [List.map_cons, servingChainInputAt_zero] at h0
      rcases h0 with ⟨hage_le0, hage0, hpre0, hcache0⟩
      have hpre' : ServingNodePreRefreshWF mode pts' S sn :=
        servingNodePreRefreshWF_congr hpre0 hpts_S
      have hcache' : ServingNodeCacheWF mode pts' S sn :=
        servingNodeCacheWF_congr hpre0.2 hcache0 hpts_S
      let stepSn (e : PoolUpdateEvent ι) : Alg4ServingNode d ι :=
        match e with
        | .externalInsert p =>
            { sn with
              trueAge := sn.trueAge + 1
              age := sn.age + 1
              radiusDict := updateRadiusDictOnEvent pts' sn.node.o sn.radiusDict e mHint
              localMatchings := applyNodeMatchingInsert pts' mode sn.node sn.localMatchings p qAns }
        | .externalDelete p =>
            { sn with
              trueAge := sn.trueAge + 1
              age := sn.age + 1
              radiusDict := updateRadiusDictOnEvent pts' sn.node.o sn.radiusDict e mHint
              localMatchings := applyNodeMatchingDelete pts' mode sn.node sn.localMatchings p qAns }
        | .virtualValueDelete => sn
        | .unaffected => sn
      have hhead_gen : ∀ (e : PoolUpdateEvent ι),
          IsValidPoolUpdateEvent S S' e →
          (stepSn e).birthSnapshot = sn.birthSnapshot ∧
          (stepSn e).node = sn.node ∧
          (stepSn e).ownedJob = sn.ownedJob ∧
          (stepSn e).trueAge = sn.trueAge + e.ticks ∧
          (stepSn e).age = sn.age + e.ticks ∧
          (stepSn e).trueAge ≤ (stepSn e).age ∧
          HasNodeAge (stepSn e).birthSnapshot S' (stepSn e).trueAge ∧
          ServingNodePreRefreshWF mode pts' S' (stepSn e) ∧
          (e.isClockTick = false →
            stepSn e = sn ∧ S' = S ∧ ServingNodeCacheWF mode pts' S' (stepSn e)) := by
        intro e hev_e
        cases e with
        | externalInsert p =>
          have hev_save := hev_e
          rcases hev_e with ⟨hp_not, rfl⟩
          dsimp only [stepSn, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick, ↓reduceIte]
          refine ⟨rfl, rfl, rfl, rfl, rfl, Nat.succ_le_succ hage_le0,
            hasNodeAge_step hage0 (Or.inl ⟨p, hp_not, rfl⟩),
            ⟨updateRadiusDictOnEvent_complete pts' sn.node.o hev_save hpre'.1 mHint,
              applyNodeMatchingInsert_valid pts' mode sn.node hp_not qAns hpre'.2⟩,
            fun h => by cases h⟩
        | externalDelete p =>
          have hev_save := hev_e
          rcases hev_e with ⟨hp_in, rfl⟩
          dsimp only [stepSn, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick, ↓reduceIte]
          refine ⟨rfl, rfl, rfl, rfl, rfl, Nat.succ_le_succ hage_le0,
            hasNodeAge_step hage0 (Or.inr ⟨p, hp_in, rfl⟩),
            ⟨updateRadiusDictOnEvent_complete pts' sn.node.o hev_save hpre'.1 mHint,
              applyNodeMatchingDelete_valid pts' mode sn.node p qAns hpre'.2⟩,
            fun h => by cases h⟩
        | virtualValueDelete =>
          subst hev_e
          dsimp only [stepSn, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick,
            Bool.false_eq_true, ↓reduceIte]
          exact ⟨rfl, rfl, rfl, (Nat.add_zero _).symm, (Nat.add_zero _).symm, hage_le0, hage0, hpre',
            fun _ => ⟨rfl, rfl, hcache'⟩⟩
        | unaffected =>
          subst hev_e
          dsimp only [stepSn, PoolUpdateEvent.ticks, PoolUpdateEvent.isClockTick,
            Bool.false_eq_true, ↓reduceIte]
          exact ⟨rfl, rfl, rfl, (Nat.add_zero _).symm, (Nat.add_zero _).symm, hage_le0, hage0, hpre',
            fun _ => ⟨rfl, rfl, hcache'⟩⟩
      set sn' := stepSn ev
      have hhead := hhead_gen ev hev
      have hnode_eq : sn'.node = sn.node := hhead.2.1
      have hres_congr : sn.node.residual pts₀ S = sn.node.residual pts' S :=
        nodeResidual_congr sn.node (fun x hx => (hpts_S x hx).symm)
      let nextEv := nextRoutedPoolEvent pts' sn.node ev
      have hev_next : IsValidPoolUpdateEvent (sn.node.residual pts₀ S) (sn.node.residual pts' S')
          (nextEv.getD .unaffected) := by
        rw [hres_congr]
        exact residual_validPoolUpdateEvent pts' sn.node hev
      have hpts_R : ∀ x ∈ sn.node.residual pts₀ S, pts' x = pts₀ x :=
        fun x hx => hpts_S x (nodeResidual_subset sn.node pts₀ S hx)
      have hinv_rest : ∀ (idx : ℕ) (r : Alg4ServingNode d ι),
          rest[idx]? = some r →
          let S_cur := servingChainInputAt pts₀
            (rest.map Alg4ServingNode.toServingNodeState) (sn.node.residual pts₀ S) idx
          r.trueAge ≤ r.age ∧
          HasNodeAge r.birthSnapshot S_cur r.trueAge ∧
          ServingNodePreRefreshWF mode pts₀ S_cur r ∧
          ServingNodeCacheWF mode pts₀ S_cur r := by
        intro idx r hr
        simpa [List.map_cons, servingChainInputAt_cons_succ, Alg4ServingNode.toServingNodeState]
          using hinv (idx + 1) r hr
      have hl1_unfold :
          alg4Line1Aux pts' mode activeEv (sn :: rest) qList mHints =
            ((sn', ev) :: (alg4Line1Aux pts' mode nextEv rest (qList.drop 1) (mHints.drop 1)).1,
             (alg4Line1Aux pts' mode nextEv rest (qList.drop 1) (mHints.drop 1)).2) := by
        conv_lhs => unfold alg4Line1Aux
        dsimp only [ev, qAns, mHint, sn', stepSn, nextEv, nextRoutedPoolEvent]
        generalize activeEv.getD .unaffected = e0
        cases e0 <;> rfl
      rcases hrec_l1 : alg4Line1Aux pts' mode nextEv rest (qList.drop 1) (mHints.drop 1)
        with ⟨rest', leafEv⟩
      have hspec_l1 := alg4Line1Aux_spec pts₀ pts' mode rest
        (sn.node.residual pts₀ S) (sn.node.residual pts' S') nextEv
        (qList.drop 1) (mHints.drop 1) hpts_R hev_next hinv_rest
      rw [hrec_l1] at hspec_l1 hl1_unfold
      rcases hspec_l1 with ⟨hLen_rest, hballs_rest, hleaf_ev, hrest_idx⟩
      rw [hl1_unfold]
      dsimp only
      refine ⟨by simp [hLen_rest], ?_, ?_, ?_⟩
      · simp only [List.map_cons]
        have hhd_n : sn'.toServingNodeState.node = sn.toServingNodeState.node := hnode_eq
        rw [hhd_n, hballs_rest]
      · simpa [List.map_cons, servingChainInputAt_cons_succ,
          Alg4ServingNode.toServingNodeState, hnode_eq] using hleaf_ev
      · intro idx s0 p1 hs0 hp1
        cases idx with
        | zero =>
          simp only [List.getElem?_cons_zero, Option.some.injEq] at hs0 hp1
          subst hs0 hp1
          rw [List.map_cons, servingChainInputAt_zero, List.map_cons, servingChainInputAt_zero]
          exact ⟨hev, poolUpdateEvent_ticks_le_one ev,
            hhead.1, hhead.2.1, hhead.2.2.1, hhead.2.2.2.1, hhead.2.2.2.2.1,
            hhead.2.2.2.2.2.1, hhead.2.2.2.2.2.2.1, hhead.2.2.2.2.2.2.2.1,
            hhead.2.2.2.2.2.2.2.2⟩
        | succ idx =>
          simp only [List.getElem?_cons_succ] at hs0 hp1
          rw [List.map_cons, servingChainInputAt_cons_succ,
              List.map_cons, servingChainInputAt_cons_succ]
          simpa [Alg4ServingNode.toServingNodeState, hnode_eq] using hrest_idx idx s0 p1 hs0 hp1

/-! ### 3. Lines 2–6 (`alg4Lines2To6StepPendingJobs`) -/

open Classical in
theorem alg4Lines2To6StepPendingJobs_basic {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ) :
    ∀ (nodes1 : List (Alg4ServingNode d ι × PoolUpdateEvent ι))
      (S' : Finset ι) (jChoices : List (PendingJobStepChoices d ι)),
      let nodes26 := alg4Lines2To6StepPendingJobs pts' mode α L S' nodes1 jChoices
      nodes26.length = nodes1.length ∧
      (nodes26.map (fun p => p.1.toServingNodeState)).map ServingNodeState.node =
        (nodes1.map (fun p => p.1.toServingNodeState)).map ServingNodeState.node ∧
      ∀ (idx : ℕ) (p1 : Alg4ServingNode d ι × PoolUpdateEvent ι)
        (p26 : Alg4ServingNode d ι × Bool),
        nodes1[idx]? = some p1 →
        nodes26[idx]? = some p26 →
        let S_idx := servingChainInputAt pts'
          (nodes1.map (fun p => p.1.toServingNodeState)) S' idx
        let jc := (jChoices.drop idx).head?.getD
          { prefixRouteQueries := [], prefixRouteMaxHints := [], prefixBudgetSteps := [],
            openSampledCenter := .infeasible, openFallbackBirthId := none, leafHint := none }
        p26.2 = p1.2.isClockTick ∧
        p26.1.birthSnapshot = p1.1.birthSnapshot ∧
        p26.1.node = p1.1.node ∧
        p26.1.trueAge = p1.1.trueAge ∧
        p26.1.age = p1.1.age ∧
        p26.1.radiusDict = p1.1.radiusDict ∧
        p26.1.localMatchings = p1.1.localMatchings ∧
        p26.1.baselinePair = p1.1.baselinePair ∧
        p26.1.baselineDistSq = p1.1.baselineDistSq ∧
        p26.1.maxMatchingPair = p1.1.maxMatchingPair ∧
        p26.1.maxMatchingDistSq = p1.1.maxMatchingDistSq ∧
        (p1.2.isClockTick = false → p26.1 = p1.1) ∧
        (p1.2.isClockTick = true →
          match p1.1.ownedJob with
          | none => p26.1 = p1.1
          | some job =>
              let job₁ := alg4Line3RouteThroughPrefix pts' mode job p1.2 S_idx jc
              let job₂ := alg4Line4AdvanceClockAndBuild pts' mode job₁ S_idx jc.prefixBudgetSteps
              let job₃ := alg4Line5LateOpeningGate pts' mode α L job₂ jc
              p26.1 = { p1.1 with ownedJob := some job₃ })
  | [], S', jChoices =>
      ⟨rfl, rfl, fun idx _ _ h _ => by simp at h⟩
  | (sn, ev) :: rest, S', jChoices => by
      let jc0 := jChoices.head?.getD
        { prefixRouteQueries := [], prefixRouteMaxHints := [], prefixBudgetSteps := [],
          openSampledCenter := .infeasible, openFallbackBirthId := none, leafHint := none }
      let sn' : Alg4ServingNode d ι :=
        if ev.isClockTick then
          match sn.ownedJob with
          | none => sn
          | some job =>
              let job₁ := alg4Line3RouteThroughPrefix pts' mode job ev S' jc0
              let job₂ := alg4Line4AdvanceClockAndBuild pts' mode job₁ S' jc0.prefixBudgetSteps
              let job₃ := alg4Line5LateOpeningGate pts' mode α L job₂ jc0
              { sn with ownedJob := some job₃ }
        else sn
      have hcons_26 :
          alg4Lines2To6StepPendingJobs pts' mode α L S' ((sn, ev) :: rest) jChoices =
            (sn', ev.isClockTick) ::
              alg4Lines2To6StepPendingJobs pts' mode α L (sn'.node.residual pts' S') rest (jChoices.drop 1) := rfl
      have hsn'_node : sn'.node = sn.node := by
        dsimp only [sn']
        split_ifs
        · cases sn.ownedJob <;> rfl
        · rfl
      rcases alg4Lines2To6StepPendingJobs_basic pts' mode α L rest
          (sn'.node.residual pts' S') (jChoices.drop 1) with ⟨hLen_rest, hballs_rest, hrest⟩
      rw [hcons_26]
      refine ⟨by dsimp only [List.length_cons]; rw [hLen_rest], ?_, ?_⟩
      · simp only [List.map_cons]
        have hhd_s : sn'.toServingNodeState.node = sn.toServingNodeState.node := hsn'_node
        rw [hhd_s, hballs_rest]
      · intro idx p1 p26 hp1 hp26
        cases idx with
        | zero =>
          simp only [List.getElem?_cons_zero, Option.some.injEq] at hp1 hp26
          subst hp1 hp26
          dsimp only [List.drop_zero]
          rw [List.map_cons, servingChainInputAt_zero]
          dsimp only [sn', jc0]
          by_cases hct : ev.isClockTick = true
          · rw [if_pos hct]
            cases sn.ownedJob with
            | none =>
              exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl,
                fun hf => absurd hct (by simp [hf]), fun _ => rfl⟩
            | some job =>
              exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl,
                fun hf => absurd hct (by simp [hf]), fun _ => rfl⟩
          · rw [if_neg hct]
            exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl,
              fun _ => rfl, fun ht => absurd ht hct⟩
        | succ idx =>
          simp only [List.getElem?_cons_succ] at hp1 hp26
          have hdrop : jChoices.drop (idx + 1) = (jChoices.drop 1).drop idx := by
            rw [Nat.add_comm idx 1, ← List.drop_drop]
          rw [List.map_cons, servingChainInputAt_cons_succ, hdrop]
          have hih := hrest idx p1 p26 hp1 hp26
          rw [hsn'_node] at hih
          exact hih

open Classical in
theorem stepSinglePendingJob_dataWF {d : ℕ} {ι : Type}
    {pts₀ pts' : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode} {α : ℝ} {L : ℕ}
    (hα_le : α ≤ 1)
    {S_before S_after : Finset ι} {ev : PoolUpdateEvent ι}
    {job : Alg4PendingJob d ι} (jc : PendingJobStepChoices d ι)
    (hpts_S : ∀ x ∈ S_before, pts' x = pts₀ x)
    (hpts_B : ∀ lv ∈ job.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts' x = pts₀ x)
    (hev : IsValidPoolUpdateEvent S_before S_after ev)
    (hdwf : PendingJobDataWF mode α L pts₀ S_before job) :
    let job₁ := alg4Line3RouteThroughPrefix pts' mode job ev S_after jc
    let job₂ := alg4Line4AdvanceClockAndBuild pts' mode job₁ S_after jc.prefixBudgetSteps
    let job₃ := alg4Line5LateOpeningGate pts' mode α L job₂ jc
    PendingJobDataWF mode α L pts' S_after job₃ := by
  rcases alg4Line3RoutePrefixAux_spec pts₀ pts' mode α L job.completedPrefix
      S_before S_after (some ev) jc.prefixRouteQueries jc.prefixRouteMaxHints
      hpts_S hpts_B hev hdwf.2.1 with ⟨hLen1, _, hroute_j⟩
  set job₁ := alg4Line3RouteThroughPrefix pts' mode job ev S_after jc
  have hpref1_eq : job₁.completedPrefix =
      (alg4Line3RoutePrefixAux pts' mode (some ev) job.completedPrefix
        jc.prefixRouteQueries jc.prefixRouteMaxHints).1 := rfl
  have hstep4_in : ∀ j : Fin job₁.completedPrefix.length,
      let lv₁ := job₁.completedPrefix[j]
      let S_lv' := alg4PrefixInputAt pts' job₁.completedPrefix S_after j.val
      lv₁.indexMode = mode.backgroundIndexMode ∧
      IsLargeResidualLevel L lv₁.birthSnapshot.card ∧
      PassesBirthCoreCheck α pts' lv₁.ball lv₁.birthSnapshot ∧
      lv₁.trueInputAge ≤ lv₁.elapsedRootTicks + 1 ∧
      HasNodeAge lv₁.birthSnapshot S_lv' lv₁.trueInputAge ∧
      lv₁.heapIndexedIds = lv₁.radiusDict.indexedIds ∧
      lv₁.radiusDict.IsScanValid pts' lv₁.ball.o S_lv' ∧
      lv₁.classifiedIds ⊆ S_lv' ∧
      ValidNodeMatchingsOn pts' mode lv₁.ball lv₁.classifiedIds lv₁.localMatchings ∧
      (lv₁.backgroundReady = true →
        lv₁.heapIndexedIds = S_lv' ∧ lv₁.classifiedIds = S_lv') := by
    intro j
    have hj0 : j.val < job.completedPrefix.length := by rw [← hpref1_eq] at hLen1; omega
    have hwf0 := hdwf.2.1 ⟨j.val, hj0⟩
    rw [Fin.getElem_fin] at hwf0
    have hpts_Bj : ∀ x ∈ (job.completedPrefix[j.val]'hj0).birthSnapshot, pts₀ x = pts' x :=
      fun x hx => (hpts_B _ (List.getElem_mem _) x hx).symm
    have hr := hroute_j ⟨j.val, hj0⟩
    dsimp only at hr hwf0
    simp only [Fin.getElem_fin] at hr hwf0
    rcases hr with ⟨hb_eq, hs2_eq, hball_eq, hmode_eq, hrdy_eq, hel_eq, hhid_eq,
      ev_j, _, ht_le, hage_eq, hage_j, hscan_j, hcls_j, hlm_j, hrdy_j, _, _⟩
    dsimp only
    rw [Fin.getElem_fin]
    simp only [hpref1_eq]
    rw [hb_eq, hball_eq, hmode_eq]
    rw [hb_eq] at hage_j
    refine ⟨hwf0.1, hwf0.2.1,
      (passesBirthCoreCheck_congr α _ hpts_Bj).mp hwf0.2.2.1,
      ?_, hage_j, hhid_eq, hscan_j, hcls_j, hlm_j, hrdy_j⟩
    have hle0 := hwf0.2.2.2.1
    omega
  have hLen2 := stepPrefixConstruction_length pts' mode job₁.completedPrefix S_after jc.prefixBudgetSteps
  rcases stepPrefixConstruction_spec pts' mode α L job₁.completedPrefix S_after
      jc.prefixBudgetSteps hstep4_in with ⟨hballs2, hstep4_j⟩
  set job₂ := alg4Line4AdvanceClockAndBuild pts' mode job₁ S_after jc.prefixBudgetSteps
  have hdwf2 : PendingJobDataWF mode α L pts' S_after job₂ := by
    refine ⟨?_, ?_, ?_⟩
    · dsimp only [job₂, alg4Line4AdvanceClockAndBuild, job₁, alg4Line3RouteThroughPrefix]
      exact (prefixResidual_map_eq_of_balls pts' S_after hballs2).symm
    · intro j
      have hj1 : j.val < job₁.completedPrefix.length := by
        have hlt := j.isLt
        dsimp only [job₂, alg4Line4AdvanceClockAndBuild] at hlt
        omega
      simpa [Fin.getElem_fin] using (hstep4_j ⟨j.val, hj1⟩).2.2.2.2.2.2.2.1
    · dsimp only [job₂, alg4Line4AdvanceClockAndBuild, job₁, alg4Line3RouteThroughPrefix]
      by_cases hcl : job.closedAsLeaf = true
      · simp only [hcl, ↓reduceIte]
        exact computeExactLeafAnswer_spec pts' _ jc.leafHint
      · simp [hcl]
  exact (alg4Line5LateOpeningGate_dataWF hα_le hdwf2 jc).1

/-! ### 4. Lines 7–8 (`alg4Lines7To8InstallCompletedJobs`) -/

open Classical in
theorem alg4Lines7To8InstallCompletedJobs_conj2 {d : ℕ} {ι : Type}
    (mode : Alg4Mode) (α : ℝ) (L : ℕ) :
    ∀ (nodes26 : List (Alg4ServingNode d ι × Bool))
      (leaf1 : Finset ι) (leafAns0 : Option (ι × ι)) (leafSq0 : ℝ) (leafTicked : Bool),
      let (nodes78, leaf78, _, _, _, retired78) :=
        alg4Lines7To8InstallCompletedJobs nodes26 leaf1 leafAns0 leafSq0 leafTicked
      ((∀ p ∈ nodes26, ∀ job, p.1.ownedJob = some job → ¬ job.IsReadyToInstall) →
        nodes78 = nodes26 ∧ leaf78 = leaf1 ∧ retired78 = []) ∧
      (∀ (idx₀ : Fin nodes26.length) (job₀ : Alg4PendingJob d ι),
        (nodes26[idx₀]).1.ownedJob = some job₀ →
        job₀.IsReadyToInstall →
        (∀ i : Fin nodes26.length, i < idx₀ →
          ∀ j, (nodes26[i]).1.ownedJob = some j → ¬ j.IsReadyToInstall) →
          nodes78.take idx₀.val = nodes26.take idx₀.val ∧
          nodes78 =
            (nodes26.take idx₀.val) ++
              job₀.completedPrefix.map (fun lv => (installOpenedLevelAsServingNode lv, true)) ∧
          leaf78 = job₀.currentResidual ∧
          (∀ (pts' : ι → EuclideanSpace ℝ (Fin d)) (P' : Finset ι),
            servingChainInputAt pts'
              (nodes78.map (fun p => p.1.toServingNodeState)) P' idx₀.val =
            servingChainInputAt pts'
              (nodes26.map (fun p => p.1.toServingNodeState)) P' idx₀.val) ∧
          (∀ lv ∈ job₀.completedPrefix,
            let sn_new := installOpenedLevelAsServingNode lv
            sn_new.birthSnapshot = lv.birthSnapshot ∧
            sn_new.trueAge = lv.trueInputAge ∧
            sn_new.age = lv.elapsedRootTicks ∧
            sn_new.ownedJob = none ∧
            (∀ (pts' : ι → EuclideanSpace ℝ (Fin d)) (S_lv : Finset ι),
              lv.WellFormed mode α L pts' S_lv →
                sn_new.trueAge ≤ sn_new.age ∧
                HasNodeAge sn_new.birthSnapshot S_lv sn_new.trueAge)))
  | [], leaf1, leafAns0, leafSq0, leafTicked => by
      dsimp only [alg4Lines7To8InstallCompletedJobs]
      exact ⟨fun _ => ⟨rfl, rfl, rfl⟩, fun idx₀ => Fin.elim0 idx₀⟩
  | (sn, affected) :: rest, leaf1, leafAns0, leafSq0, leafTicked => by
      rcases alg4Lines7To8InstallCompletedJobs_conj2 mode α L rest leaf1 leafAns0 leafSq0 leafTicked
        with ⟨hnone_rest, hsome_rest⟩
      dsimp only [alg4Lines7To8InstallCompletedJobs]
      cases hown : sn.ownedJob with
      | none =>
        dsimp only
        rcases h78 : alg4Lines7To8InstallCompletedJobs rest leaf1 leafAns0 leafSq0 leafTicked with
          ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
        rw [h78] at hnone_rest hsome_rest
        dsimp only at hnone_rest hsome_rest ⊢
        refine ⟨?_, ?_⟩
        · intro hall
          have hr := hnone_rest (fun p hp job hjob => hall p (List.mem_cons_of_mem _ hp) job hjob)
          exact ⟨congrArg ((sn, affected) :: ·) hr.1, hr.2.1, hr.2.2⟩
        · intro idx₀ job₀ hjob₀ hrdy₀ hprev
          rcases idx₀ with ⟨_ | k, hk⟩
          · rw [Fin.getElem_fin] at hjob₀
            dsimp only [List.getElem_cons_zero] at hjob₀
            rw [hown] at hjob₀; cases hjob₀
          · have hk' : k < rest.length := Nat.lt_of_succ_lt_succ hk
            rw [Fin.getElem_fin] at hjob₀
            dsimp only [List.getElem_cons_succ] at hjob₀
            have hprev_rest : ∀ i : Fin rest.length, i < ⟨k, hk'⟩ →
                ∀ j, (rest[i]).1.ownedJob = some j → ¬ j.IsReadyToInstall := by
              intro i hi j hj
              exact hprev ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩ (Nat.succ_lt_succ hi) j hj
            rcases hsome_rest ⟨k, hk'⟩ job₀ hjob₀ hrdy₀ hprev_rest with
              ⟨htake, heq, hleaf, hchain, hlv⟩
            refine ⟨by simp [htake], by simp [heq], hleaf, ?_, hlv⟩
            intro pts' P'
            rw [List.map_cons, servingChainInputAt_cons_succ,
                List.map_cons, servingChainInputAt_cons_succ]
            exact hchain pts' _
      | some job =>
        dsimp only
        by_cases hrdy : job.IsReadyToInstall
        · rw [if_pos hrdy]
          dsimp only
          refine ⟨?_, ?_⟩
          · intro hall
            exact False.elim (hall (sn, affected) List.mem_cons_self job hown hrdy)
          · intro idx₀ job₀ hjob₀ hrdy₀ hprev
            rcases idx₀ with ⟨_ | k, hk⟩
            · rw [Fin.getElem_fin] at hjob₀
              dsimp only [List.getElem_cons_zero] at hjob₀
              rw [hown] at hjob₀
              injection hjob₀ with hjeq
              subst hjeq
              refine ⟨rfl, rfl, rfl, ?_, ?_⟩
              · intro pts' P'
                simp [servingChainInputAt_zero]
              · intro lv _
                dsimp only [installOpenedLevelAsServingNode]
                exact ⟨rfl, rfl, rfl, rfl, fun _ _ hwf => ⟨hwf.2.2.2.1, hwf.2.2.2.2.1⟩⟩
            · exfalso
              exact hprev ⟨0, Nat.zero_lt_succ _⟩ (Nat.zero_lt_succ k) job hown hrdy
        · rw [if_neg hrdy]
          rcases h78 : alg4Lines7To8InstallCompletedJobs rest leaf1 leafAns0 leafSq0 leafTicked with
            ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
          rw [h78] at hnone_rest hsome_rest
          dsimp only at hnone_rest hsome_rest ⊢
          refine ⟨?_, ?_⟩
          · intro hall
            have hr := hnone_rest (fun p hp j hj => hall p (List.mem_cons_of_mem _ hp) j hj)
            exact ⟨congrArg ((sn, affected) :: ·) hr.1, hr.2.1, hr.2.2⟩
          · intro idx₀ job₀ hjob₀ hrdy₀ hprev
            rcases idx₀ with ⟨_ | k, hk⟩
            · rw [Fin.getElem_fin] at hjob₀
              dsimp only [List.getElem_cons_zero] at hjob₀
              rw [hown] at hjob₀
              injection hjob₀ with hjeq
              subst hjeq
              exact False.elim (hrdy hrdy₀)
            · have hk' : k < rest.length := Nat.lt_of_succ_lt_succ hk
              rw [Fin.getElem_fin] at hjob₀
              dsimp only [List.getElem_cons_succ] at hjob₀
              have hprev_rest : ∀ i : Fin rest.length, i < ⟨k, hk'⟩ →
                  ∀ j, (rest[i]).1.ownedJob = some j → ¬ j.IsReadyToInstall := by
                intro i hi j hj
                exact hprev ⟨i.val + 1, Nat.succ_lt_succ i.isLt⟩ (Nat.succ_lt_succ hi) j hj
              rcases hsome_rest ⟨k, hk'⟩ job₀ hjob₀ hrdy₀ hprev_rest with
                ⟨htake, heq, hleaf, hchain, hlv⟩
              refine ⟨by simp [htake], by simp [heq], hleaf, ?_, hlv⟩
              intro pts' P'
              rw [List.map_cons, servingChainInputAt_cons_succ,
                  List.map_cons, servingChainInputAt_cons_succ]
              exact hchain pts' _

open Classical in
theorem prefixInputAt_eq_installed_servingInputAt {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d))
    (pref : List (Alg4OpenedLevel d ι)) (S_root : Finset ι) :
    (∀ j : ℕ, j ≤ pref.length →
      servingChainInputAt pts'
        ((pref.map (fun lv => (installOpenedLevelAsServingNode lv, true))).map
          (fun p => p.1.toServingNodeState))
        S_root j =
        alg4PrefixInputAt pts' pref S_root j) ∧
    servingChainInputAt pts'
      ((pref.map (fun lv => (installOpenedLevelAsServingNode lv, true))).map
        (fun p => p.1.toServingNodeState))
      S_root pref.length =
      prefixResidual pts' (pref.map Alg4OpenedLevel.toOpenedJobLevel) S_root := by
  have h1 : ∀ j : ℕ, j ≤ pref.length →
      servingChainInputAt pts'
        ((pref.map (fun lv => (installOpenedLevelAsServingNode lv, true))).map
          (fun p => p.1.toServingNodeState))
        S_root j =
        alg4PrefixInputAt pts' pref S_root j := by
    intro j _
    unfold servingChainInputAt alg4PrefixInputAt
    rw [List.map_map, ← List.map_take]
    have hfold : ∀ (xs : List (Alg4OpenedLevel d ι)) (A : Finset ι),
        (xs.map ((fun p : Alg4ServingNode d ι × Bool => p.1.toServingNodeState) ∘
          fun lv => (installOpenedLevelAsServingNode lv, true))).foldl
          (fun S st => st.node.residual pts' S) A =
        xs.foldl (fun S lv => lv.ball.residual pts' S) A := by
      intro xs A
      rw [List.foldl_map]
      rfl
    exact hfold (pref.take j) S_root
  refine ⟨h1, ?_⟩
  rw [h1 pref.length le_rfl]
  exact (alg4PrefixInputAt_append_singleton pts' pref
    { birthSnapshot := ∅, ball := { o := 0, V := 0, V_nonneg := le_rfl },
      indexMode := .radiusDictOnly, backgroundReady := false, trueInputAge := 0,
      elapsedRootTicks := 0, scan2Snapshot := ∅, heapIndexedIds := ∅, classifiedIds := ∅,
      radiusDict := RadiusDictState.empty ι, localMatchings := fun _ => LocalMatchingState.empty ι }
    S_root).2

open Classical in
theorem alg4Lines7To8InstallCompletedJobs_dataWF {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L D_out : ℕ) :
    ∀ (nodes26 : List (Alg4ServingNode d ι × Bool))
      (S' leaf1 : Finset ι) (leafAns0 : Option (ι × ι)) (leafSq0 : ℝ) (leafTicked : Bool),
      leaf1 = servingChainInputAt pts'
        (nodes26.map (fun p => p.1.toServingNodeState)) S' nodes26.length →
      (leafTicked = false →
        IsExactLeafAnswer pts' leaf1 leafAns0 ∧
        leafSq0 = (baselinePairLength pts' leafAns0) ^ 2) →
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes26[idx]? = some p →
        let S_idx := servingChainInputAt pts'
          (nodes26.map (fun p => p.1.toServingNodeState)) S' idx
        TaggedNodeDataWF mode pts' S_idx p ∧
        ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
          PendingJobDataWF mode α L pts' S_idx job) →
      let (nodes78, leaf78, leafAns78, leafSq78, leafCh78, retired78) :=
        alg4Lines7To8InstallCompletedJobs nodes26 leaf1 leafAns0 leafSq0 leafTicked
      leaf78 = servingChainInputAt pts'
        (nodes78.map (fun p => p.1.toServingNodeState)) S' nodes78.length ∧
      (leafCh78 = false →
        IsExactLeafAnswer pts' leaf78 leafAns78 ∧
        leafSq78 = (baselinePairLength pts' leafAns78) ^ 2) ∧
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes78[idx]? = some p →
        TaggedNodeDataWF mode pts'
          (servingChainInputAt pts' (nodes78.map (fun q => q.1.toServingNodeState)) S' idx)
          p) ∧
      (1 ≤ D_out → ∀ r ∈ retired78, r.HasBoundedOutdegree D_out)
  | [], S', leaf1, leafAns0, leafSq0, leafTicked, hleaf1, hlt, _ => by
      dsimp only [alg4Lines7To8InstallCompletedJobs]
      exact ⟨hleaf1, hlt, fun _ _ h => by simp at h, fun _ _ h => by cases h⟩
  | (sn, affected) :: rest, S', leaf1, leafAns0, leafSq0, leafTicked, hleaf1, hlt, hinv => by
      dsimp only [alg4Lines7To8InstallCompletedJobs]
      have h0 := hinv 0 (sn, affected) rfl
      rw [List.map_cons, servingChainInputAt_zero] at h0
      have hinv_rest : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
          rest[idx]? = some p →
          let S_idx := servingChainInputAt pts'
            (rest.map (fun p => p.1.toServingNodeState)) (sn.node.residual pts' S') idx
          TaggedNodeDataWF mode pts' S_idx p ∧
          ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
            PendingJobDataWF mode α L pts' S_idx job := by
        intro idx p hp
        simpa [List.map_cons, servingChainInputAt_cons_succ]
          using hinv (idx + 1) p hp
      have hleaf1_rest : leaf1 = servingChainInputAt pts'
          (rest.map (fun p => p.1.toServingNodeState)) (sn.node.residual pts' S') rest.length := by
        simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf1
      cases hown : sn.ownedJob with
      | none =>
        dsimp only
        have ih := alg4Lines7To8InstallCompletedJobs_dataWF pts' mode α L D_out
          rest (sn.node.residual pts' S') leaf1 leafAns0 leafSq0 leafTicked
          hleaf1_rest hlt hinv_rest
        rcases h78 : alg4Lines7To8InstallCompletedJobs rest leaf1 leafAns0 leafSq0 leafTicked with
          ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
        rw [h78] at ih
        rcases ih with ⟨hleaf_ih, hlt_ih, htag_ih, hret_ih⟩
        refine ⟨?_, hlt_ih, ?_, hret_ih⟩
        · simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf_ih
        · intro idx p hp
          cases idx with
          | zero =>
            simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
            subst hp
            rw [List.map_cons, servingChainInputAt_zero]
            exact h0.1
          | succ idx =>
            simp only [List.getElem?_cons_succ] at hp
            rw [List.map_cons, servingChainInputAt_cons_succ]
            exact htag_ih idx p hp
      | some job =>
        dsimp only
        by_cases hrdy : job.IsReadyToInstall
        · rw [if_pos hrdy]
          dsimp only
          have hdwf := h0.2 job hown
          rcases prefixInputAt_eq_installed_servingInputAt pts' job.completedPrefix S' with
            ⟨hinst_in, hinst_end⟩
          refine ⟨?_, fun hf : true = false => Bool.noConfusion hf, ?_, ?_⟩
          · simp only [List.length_map]
            rw [hinst_end]
            exact hdwf.1
          · intro idx p hp
            rw [List.getElem?_map] at hp
            cases hget : job.completedPrefix[idx]? with
            | none => rw [hget] at hp; simp at hp
            | some lv =>
              rw [hget] at hp
              simp only [Option.map_some, Option.some.injEq] at hp
              subst hp
              have hj : idx < job.completedPrefix.length := by
                by_contra hge
                rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget
                cases hget
              have hlv_eq : job.completedPrefix[idx]'hj = lv := by
                rw [List.getElem?_eq_getElem hj] at hget
                exact Option.some.inj hget
              rw [hinst_in idx (le_of_lt hj)]
              have hlv_wf := hdwf.2.1 ⟨idx, hj⟩
              rw [Fin.getElem_fin, hlv_eq] at hlv_wf
              have hlv_rdy : lv.backgroundReady = true := by
                have hmem : lv.toOpenedJobLevel ∈ job.toPendingReplacementJob.completedPrefix := by
                  dsimp only [Alg4PendingJob.toPendingReplacementJob]
                  rw [← hlv_eq]
                  exact List.mem_map_of_mem (List.getElem_mem _)
                exact hrdy.2.2 _ hmem
              rcases hlv_wf.2.2.2.2.2.2.2.2.2 hlv_rdy with ⟨hH_eq, hC_eq⟩
              refine ⟨⟨?_, ?_⟩, fun hf : true = false => Bool.noConfusion hf⟩
              · dsimp only [installOpenedLevelAsServingNode, RadiusDictState.IsComplete]
                rw [← hH_eq]
                exact hlv_wf.2.2.2.2.2.2.2.1
              · dsimp only [installOpenedLevelAsServingNode]
                rw [← hC_eq]
                exact hlv_wf.2.2.2.2.2.2.2.2.1
          · intro hD r hr
            rcases List.mem_cons.mp hr with rfl | hr1
            · exact ⟨Nat.zero_le D_out, trivial⟩
            · rcases List.mem_append.mp hr1 with hscan | hnodes
              · rcases List.mem_map.mp hscan with ⟨lv, _, rfl⟩
                exact ⟨Nat.zero_le D_out, trivial⟩
              · rcases List.mem_flatMap.mp hnodes with ⟨s, _, hrs⟩
                exact retireServingNodeRecords_bounded hD s r hrs
        · rw [if_neg hrdy]
          have ih := alg4Lines7To8InstallCompletedJobs_dataWF pts' mode α L D_out
            rest (sn.node.residual pts' S') leaf1 leafAns0 leafSq0 leafTicked
            hleaf1_rest hlt hinv_rest
          rcases h78 : alg4Lines7To8InstallCompletedJobs rest leaf1 leafAns0 leafSq0 leafTicked with
            ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
          rw [h78] at ih
          rcases ih with ⟨hleaf_ih, hlt_ih, htag_ih, hret_ih⟩
          refine ⟨?_, hlt_ih, ?_, hret_ih⟩
          · simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf_ih
          · intro idx p hp
            cases idx with
            | zero =>
              simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
              subst hp
              rw [List.map_cons, servingChainInputAt_zero]
              exact h0.1
            | succ idx =>
              simp only [List.getElem?_cons_succ] at hp
              rw [List.map_cons, servingChainInputAt_cons_succ]
              exact htag_ih idx p hp

/-! ### 5. Leaf Rebuild (`rebuildOversizedLeafAux`) and Line 9 + Line 10 -/

open Classical in
theorem rebuildOversizedLeafAux_fuel {d : ℕ} {ι : Type}
    {pts' : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode} {α : ℝ} {L : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1) (hL_pos : 1 ≤ L) :
    ∀ (fuel : ℕ) (S_cur : Finset ι) (choices : List (LeafRebuildLevelChoices d ι)),
      S_cur.card ≤ fuel →
      let (rebuiltNodes, finalLeaf) :=
        rebuildOversizedLeafAux pts' mode α L fuel S_cur choices
      IsResidualLeafSize L finalLeaf.card ∧
      finalLeaf = servingChainInputAt pts'
        (rebuiltNodes.map (fun p => p.1.toServingNodeState)) S_cur rebuiltNodes.length ∧
      rebuiltNodes.length ≤ S_cur.card ∧
      (rebuiltNodes.length : ℝ) * (α * (L : ℝ)) ≤ (S_cur.card : ℝ) - (finalLeaf.card : ℝ) ∧
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        rebuiltNodes[idx]? = some p →
        TaggedNodeDataWF mode pts'
          (servingChainInputAt pts'
            (rebuiltNodes.map (fun q => q.1.toServingNodeState)) S_cur idx)
          p) ∧
      (∀ p ∈ rebuiltNodes,
        p.2 = true ∧
        IsLargeResidualLevel L p.1.birthSnapshot.card ∧
        p.1.birthSnapshot.card ≤ S_cur.card ∧
        PassesBirthCoreCheck α pts' p.1.node p.1.birthSnapshot ∧
        p.1.trueAge = 0 ∧
        p.1.age = 0 ∧
        p.1.ownedJob = none ∧
        p.1.radiusDict.IsComplete pts' p.1.node.o p.1.birthSnapshot ∧
        ValidNodeMatchingsOn pts' mode p.1.node p.1.birthSnapshot p.1.localMatchings)
  | 0, S_cur, choices, hfuel => by
      have h0 : S_cur.card = 0 := Nat.eq_zero_of_le_zero hfuel
      dsimp only [rebuildOversizedLeafAux]
      refine ⟨?_, ?_, Nat.zero_le _, ?_, fun _ _ h => by simp at h, fun _ h => by cases h⟩
      · unfold IsResidualLeafSize; omega
      · simp [servingChainInputAt]
      · simp
  | k + 1, S_cur, choices, hfuel => by
      dsimp only [rebuildOversizedLeafAux]
      by_cases hres_sz : IsResidualLeafSize L S_cur.card
      · rw [if_pos hres_sz]
        refine ⟨hres_sz, by simp [servingChainInputAt], Nat.zero_le _, by simp,
          fun _ _ h => by simp at h, fun _ h => by cases h⟩
      · rw [if_neg hres_sz]
        have hlarge : IsLargeResidualLevel L S_cur.card := by
          unfold IsLargeResidualLevel IsResidualLeafSize at *; omega
        have hNE : S_cur.Nonempty := by
          unfold IsLargeResidualLevel at hlarge
          exact Finset.card_pos.mp (by omega)
        rw [dif_pos hNE]
        set ch := choices.head?.getD
          { sampledCenter := .infeasible, fallbackBirthId := none,
            radiusMaxHint := none, pointInsertOrder := [] }
        set bId := chooseBirthPointIn S_cur hNE ch.fallbackBirthId
        set ball := selectOpenedLevelBall α pts' S_cur bId ch.sampledCenter
        set rDict := buildRadiusDictOn pts' ball.o S_cur ch.radiusMaxHint
        set lm := buildSyncNodeMatchings pts' mode ball S_cur ch.pointInsertOrder
        set sn : Alg4ServingNode d ι :=
          { birthSnapshot := S_cur, node := ball, trueAge := 0, age := 0,
            radiusDict := rDict, localMatchings := lm,
            baselinePair := none, baselineDistSq := 0,
            maxMatchingPair := none, maxMatchingDistSq := 0, ownedJob := none }
        set S_next := ball.residual pts' S_cur
        have hcore_pass : PassesBirthCoreCheck α pts' ball S_cur :=
          selectOpenedLevelBall_passes hα_le pts' S_cur (chooseBirthPointIn_mem S_cur hNE _)
            ch.sampledCenter
        have hpart : S_next.card + (ball.core pts' S_cur).card = S_cur.card :=
          Finset.card_sdiff_add_card_eq_card (nodeCore_subset pts' ball.o ball.V S_cur)
        have hcore_lb : α * (L : ℝ) < ((ball.core pts' S_cur).card : ℝ) := by
          unfold PassesBirthCoreCheck at hcore_pass
          unfold IsLargeResidualLevel at hlarge
          have hgt : 2 * (L : ℝ) < (S_cur.card : ℝ) := by
            have : 2 * L < S_cur.card := by omega
            exact_mod_cast this
          have hmul : α * (2 * (L : ℝ)) < α * (S_cur.card : ℝ) :=
            mul_lt_mul_of_pos_left hgt hα_pos
          linarith
        have hL_real_pos : (0 : ℝ) < (L : ℝ) := by exact_mod_cast hL_pos
        have hcore_pos : 1 ≤ (ball.core pts' S_cur).card := by
          have hpos_r : (0 : ℝ) < ((ball.core pts' S_cur).card : ℝ) :=
            lt_trans (mul_pos hα_pos hL_real_pos) hcore_lb
          have : 0 < (ball.core pts' S_cur).card := Nat.cast_pos.mp hpos_r
          omega
        have hS_next_fuel : S_next.card ≤ k := by omega
        have ih := rebuildOversizedLeafAux_fuel (pts' := pts') (mode := mode) hα_pos hα_le hL_pos k S_next (choices.drop 1)
          hS_next_fuel
        rcases hrec : rebuildOversizedLeafAux pts' mode α L k S_next (choices.drop 1) with
          ⟨tailNodes, finalLeaf⟩
        rw [hrec] at ih
        rcases ih with ⟨hfin_sz, hfin_eq, hlen_le, hstep_sum, htag_tail, hmem_tail⟩
        have hrd_wf : rDict.IsComplete pts' ball.o S_cur :=
          buildRadiusDictOn_wellFormed pts' ball.o S_cur ch.radiusMaxHint
        have hlm_wf : ValidNodeMatchingsOn pts' mode ball S_cur lm :=
          buildSyncNodeMatchings_valid pts' mode ball S_cur ch.pointInsertOrder
        refine ⟨hfin_sz, ?_, by simp; omega, ?_, ?_, ?_⟩
        · simpa [List.map_cons, servingChainInputAt_cons_succ,
            Alg4ServingNode.toServingNodeState, sn, S_next] using hfin_eq
        · have hpart_r : (S_next.card : ℝ) + ((ball.core pts' S_cur).card : ℝ) = (S_cur.card : ℝ) := by
            exact_mod_cast hpart
          simp only [List.length_cons, Nat.cast_add, Nat.cast_one]
          nlinarith
        · intro idx p hp
          cases idx with
          | zero =>
            simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
            subst hp
            rw [List.map_cons, servingChainInputAt_zero]
            exact ⟨⟨hrd_wf, hlm_wf⟩, fun hf : true = false => Bool.noConfusion hf⟩
          | succ idx =>
            simp only [List.getElem?_cons_succ] at hp
            rw [List.map_cons, servingChainInputAt_cons_succ]
            exact htag_tail idx p hp
        · intro p hp
          rcases List.mem_cons.mp hp with rfl | htl
          · exact ⟨rfl, hlarge, le_rfl, hcore_pass, rfl, rfl, rfl, hrd_wf, hlm_wf⟩
          · rcases hmem_tail p htl with ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9⟩
            exact ⟨h1, h2, le_trans h3 (by omega), h4, h5, h6, h7, h8, h9⟩

open Classical in
theorem list_sum_le_length_mul {xs : List ℕ} {B : ℕ}
    (h : ∀ m ∈ xs, m ≤ B) :
    xs.sum ≤ xs.length * B := by
  induction xs with
  | nil => simp
  | cons x rest ih =>
    simp only [List.sum_cons, List.length_cons]
    have hx := h x List.mem_cons_self
    have hr := ih (fun m hm => h m (List.mem_cons_of_mem _ hm))
    calc
      x + rest.sum ≤ B + rest.length * B := Nat.add_le_add hx hr
      _ = (rest.length + 1) * B := by ring

open Classical in
theorem rebuildOversizedLeafAux_conj2 {d : ℕ} {ι : Type}
    {pts' : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode} {α : ℝ} {L : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1) (hL_pos : 1 ≤ L)
    (leaf₁ : Finset ι) (rebuildChoices : List (LeafRebuildLevelChoices d ι))
    (_hgt : 6 * L < leaf₁.card) (hle : leaf₁.card ≤ 6 * L + 1) :
    let (rebuiltNodes, finalLeaf) :=
      rebuildOversizedLeafAux pts' mode α L leaf₁.card leaf₁ rebuildChoices
    IsResidualLeafSize L finalLeaf.card ∧
    (rebuiltNodes.length : ℝ) ≤ cLeafVal * α⁻¹ ∧
    rebuiltNodes.length ≤ 6 * L + 1 ∧
    ((rebuiltNodes.map (fun p => p.1.birthSnapshot.card)).sum + finalLeaf.card ^ 2 : ℝ) ≤
      cLeafVal * α⁻¹ * ((L + 1 : ℝ) ^ 2) ∧
    (∀ p ∈ rebuiltNodes,
      p.2 = true ∧
      IsLargeResidualLevel L p.1.birthSnapshot.card ∧
      p.1.birthSnapshot.card ≤ 6 * L + 1 ∧
      PassesBirthCoreCheck α pts' p.1.node p.1.birthSnapshot ∧
      p.1.trueAge = 0 ∧
      p.1.age = 0 ∧
      p.1.ownedJob = none ∧
      p.1.radiusDict.IsComplete pts' p.1.node.o p.1.birthSnapshot ∧
      ValidNodeMatchingsOn pts' mode p.1.node p.1.birthSnapshot p.1.localMatchings) := by
  have hf := rebuildOversizedLeafAux_fuel (pts' := pts') (mode := mode) hα_pos hα_le hL_pos
    leaf₁.card leaf₁ rebuildChoices le_rfl
  rcases hrec : rebuildOversizedLeafAux pts' mode α L leaf₁.card leaf₁ rebuildChoices with
    ⟨rebuiltNodes, finalLeaf⟩
  rw [hrec] at hf
  rcases hf with ⟨hfin_sz, _, hlen_card, hprod_le, _, hp_all⟩
  have hL_r : (1 : ℝ) ≤ (L : ℝ) := by exact_mod_cast hL_pos
  have hcard_r : (leaf₁.card : ℝ) ≤ 7 * (L : ℝ) := by
    have hcast : (leaf₁.card : ℝ) ≤ 6 * (L : ℝ) + 1 := by exact_mod_cast hle
    linarith
  have hlen_7 : (rebuiltNodes.length : ℝ) ≤ 7 * α⁻¹ := by
    have hmul : (rebuiltNodes.length : ℝ) * (α * (L : ℝ)) ≤ (7 * α⁻¹) * (α * (L : ℝ)) := by
      have ha_ne : α ≠ 0 := ne_of_gt hα_pos
      have hrhs : (7 * α⁻¹) * (α * (L : ℝ)) = 7 * (L : ℝ) := by
        field_simp [ha_ne]
      rw [hrhs]
      have h0 : (0 : ℝ) ≤ (finalLeaf.card : ℝ) := Nat.cast_nonneg _
      linarith
    exact le_of_mul_le_mul_right hmul (mul_pos hα_pos (by linarith))
  have hainv_ge1 : (1 : ℝ) ≤ α⁻¹ := by
    rw [one_le_inv₀ hα_pos]
    exact hα_le
  have hlen_cleaf : (rebuiltNodes.length : ℝ) ≤ cLeafVal * α⁻¹ := by
    unfold cLeafVal
    linarith
  have hsum_nat : (rebuiltNodes.map (fun p => p.1.birthSnapshot.card)).sum ≤
      rebuiltNodes.length * (6 * L + 1) := by
    have hall_le : ∀ m ∈ rebuiltNodes.map (fun p => p.1.birthSnapshot.card), m ≤ 6 * L + 1 := by
      intro m hm
      rcases List.mem_map.mp hm with ⟨p, hp, rfl⟩
      exact le_trans (hp_all p hp).2.2.1 hle
    simpa using list_sum_le_length_mul hall_le
  have hfin_le : (finalLeaf.card : ℝ) ≤ 2 * ((L : ℝ) + 1) := by
    unfold IsResidualLeafSize at hfin_sz
    have : (finalLeaf.card : ℝ) ≤ 2 * (L : ℝ) + 1 := by exact_mod_cast hfin_sz
    linarith
  have hwork_nat :
      (rebuiltNodes.map (fun p => p.1.birthSnapshot.card)).sum + finalLeaf.card ^ 2 ≤
        rebuiltNodes.length * (6 * L + 1) + (2 * L + 1) ^ 2 := by
    have hsq_nat : finalLeaf.card ^ 2 ≤ (2 * L + 1) ^ 2 :=
      Nat.pow_le_pow_left hfin_sz 2
    exact Nat.add_le_add hsum_nat hsq_nat
  have hwork_bound :
      ((rebuiltNodes.map (fun p => p.1.birthSnapshot.card)).sum + finalLeaf.card ^ 2 : ℝ) ≤
        cLeafVal * α⁻¹ * ((L + 1 : ℝ) ^ 2) := by
    have h2 : (rebuiltNodes.length : ℝ) * (6 * (L : ℝ) + 1) ≤
        (42 * α⁻¹) * ((L : ℝ) + 1) := by
      have ha : (rebuiltNodes.length : ℝ) * (6 * (L : ℝ) + 1) ≤
          (rebuiltNodes.length : ℝ) * (6 * ((L : ℝ) + 1)) :=
        mul_le_mul_of_nonneg_left (by linarith) (Nat.cast_nonneg _)
      have hb : (rebuiltNodes.length : ℝ) * (6 * ((L : ℝ) + 1)) ≤
          (7 * α⁻¹) * (6 * ((L : ℝ) + 1)) :=
        mul_le_mul_of_nonneg_right hlen_7 (by linarith)
      have hc : (7 * α⁻¹) * (6 * ((L : ℝ) + 1)) = (42 * α⁻¹) * ((L : ℝ) + 1) := by ring
      linarith
    have h3 : (42 * α⁻¹) * ((L : ℝ) + 1) ≤ (42 * α⁻¹) * (((L : ℝ) + 1) ^ 2) :=
      mul_le_mul_of_nonneg_left (by nlinarith) (by positivity)
    have h4 : (2 * (L : ℝ) + 1) ^ 2 ≤ 4 * (((L : ℝ) + 1) ^ 2) := by nlinarith
    have h5 : 4 * (((L : ℝ) + 1) ^ 2) ≤ (4 * α⁻¹) * (((L : ℝ) + 1) ^ 2) :=
      mul_le_mul_of_nonneg_right (by linarith) (by positivity)
    have h64 : (46 * α⁻¹) * (((L : ℝ) + 1) ^ 2) ≤ (64 * α⁻¹) * (((L : ℝ) + 1) ^ 2) :=
      mul_le_mul_of_nonneg_right (by linarith) (sq_nonneg _)
    have h_rhs : cLeafVal * α⁻¹ * ((L + 1 : ℝ) ^ 2) = (64 * α⁻¹) * (((L : ℝ) + 1) ^ 2) := by
      unfold cLeafVal; ring
    calc
      ((rebuiltNodes.map (fun p => p.1.birthSnapshot.card)).sum + finalLeaf.card ^ 2 : ℝ)
        = (((rebuiltNodes.map (fun p => p.1.birthSnapshot.card)).sum + finalLeaf.card ^ 2 : ℕ) : ℝ) := by
            push_cast; rfl
      _ ≤ ((rebuiltNodes.length * (6 * L + 1) + (2 * L + 1) ^ 2 : ℕ) : ℝ) := by
            exact_mod_cast hwork_nat
      _ = (rebuiltNodes.length : ℝ) * (6 * (L : ℝ) + 1) + (2 * (L : ℝ) + 1) ^ 2 := by
            push_cast; ring
      _ ≤ (42 * α⁻¹) * (((L : ℝ) + 1) ^ 2) + (4 * α⁻¹) * (((L : ℝ) + 1) ^ 2) := by linarith
      _ = (46 * α⁻¹) * (((L : ℝ) + 1) ^ 2) := by ring
      _ ≤ cLeafVal * α⁻¹ * ((L + 1 : ℝ) ^ 2) := by rw [h_rhs]; exact h64
  refine ⟨hfin_sz, hlen_cleaf, le_trans hlen_card hle, hwork_bound, ?_⟩
  intro p hp
  rcases hp_all p hp with ⟨h1, h2, h3, h4, h5, h6, h7, h8, h9⟩
  exact ⟨h1, h2, le_trans h3 hle, h4, h5, h6, h7, h8, h9⟩

open Classical in
theorem startDueServingJobsAux_dataWF {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L D_out : ℕ) :
    ∀ (nodes : List (Alg4ServingNode d ι × Bool))
      (S_cur leaf : Finset ι) (leafAns : Option (ι × ι)) (leafSq : ℝ) (leafCh : Bool),
      leaf = servingChainInputAt pts'
        (nodes.map (fun p => p.1.toServingNodeState)) S_cur nodes.length →
      (leafCh = false →
        IsExactLeafAnswer pts' leaf leafAns ∧
        leafSq = (baselinePairLength pts' leafAns) ^ 2) →
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes[idx]? = some p →
        TaggedNodeDataWF mode pts'
          (servingChainInputAt pts' (nodes.map (fun q => q.1.toServingNodeState)) S_cur idx)
          p) →
      let (nodes₁, leaf₁, leafAns₁, leafSq₁, leafCh₁, retired₁) :=
        startDueServingJobsAux pts' α L S_cur nodes leaf leafAns leafSq leafCh
      leaf₁ = servingChainInputAt pts'
        (nodes₁.map (fun p => p.1.toServingNodeState)) S_cur nodes₁.length ∧
      (leafCh₁ = false →
        IsExactLeafAnswer pts' leaf₁ leafAns₁ ∧
        leafSq₁ = (baselinePairLength pts' leafAns₁) ^ 2) ∧
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes₁[idx]? = some p →
        TaggedNodeDataWF mode pts'
          (servingChainInputAt pts' (nodes₁.map (fun q => q.1.toServingNodeState)) S_cur idx)
          p) ∧
      (1 ≤ D_out → ∀ r ∈ retired₁, r.HasBoundedOutdegree D_out)
  | [], S_cur, leaf, leafAns, leafSq, leafCh, hleaf, hlch, _ => by
      dsimp only [startDueServingJobsAux]
      exact ⟨hleaf, hlch, fun _ _ h => by simp at h, fun _ _ h => by cases h⟩
  | (sn, needRefresh) :: rest, S_cur, leaf, leafAns, leafSq, leafCh, hleaf, hlch, htag => by
      dsimp only [startDueServingJobsAux]
      have h0 := htag 0 (sn, needRefresh) rfl
      rw [List.map_cons, servingChainInputAt_zero] at h0
      have hleaf_rest : leaf = servingChainInputAt pts'
          (rest.map (fun p => p.1.toServingNodeState)) (sn.node.residual pts' S_cur) rest.length := by
        simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf
      have htag_rest : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
          rest[idx]? = some p →
          TaggedNodeDataWF mode pts'
            (servingChainInputAt pts' (rest.map (fun q => q.1.toServingNodeState))
              (sn.node.residual pts' S_cur) idx)
            p := by
        intro idx p hp
        simpa [List.map_cons, servingChainInputAt_cons_succ]
          using htag (idx + 1) p hp
      by_cases hdue : sn.ownedJob.isNone ∧ jobStartAge α sn.birthSnapshot.card ≤ sn.age
      · rw [if_pos hdue]
        cases hact : scheduleJobStart α L S_cur.card with
        | startPendingJob _ =>
          dsimp only
          have ih := startDueServingJobsAux_dataWF pts' mode α L D_out
            rest (sn.node.residual pts' S_cur) leaf leafAns leafSq leafCh
            hleaf_rest hlch htag_rest
          rcases hrec : startDueServingJobsAux pts' α L (sn.node.residual pts' S_cur)
              rest leaf leafAns leafSq leafCh with
            ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
          rw [hrec] at ih
          rcases ih with ⟨hleaf_ih, hlch_ih, htag_ih, hret_ih⟩
          refine ⟨?_, hlch_ih, ?_, hret_ih⟩
          · simpa [List.map_cons, servingChainInputAt_cons_succ,
              Alg4ServingNode.toServingNodeState] using hleaf_ih
          · intro idx p hp
            cases idx with
            | zero =>
              simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
              subst hp
              rw [List.map_cons, servingChainInputAt_zero]
              exact h0
            | succ idx =>
              simp only [List.getElem?_cons_succ] at hp
              rw [List.map_cons, servingChainInputAt_cons_succ]
              simpa [Alg4ServingNode.toServingNodeState] using htag_ih idx p hp
        | replaceImmediatelyByExactLeaf =>
          dsimp only
          refine ⟨by simp [servingChainInputAt], fun hf : true = false => Bool.noConfusion hf,
            fun _ _ h => by simp at h, ?_⟩
          intro hD r hr
          rcases List.mem_cons.mp hr with rfl | htl
          · exact ⟨Nat.zero_le D_out, trivial⟩
          · rcases List.mem_flatMap.mp htl with ⟨s, _, hrs⟩
            exact retireServingNodeRecords_bounded hD s r hrs
      · rw [if_neg hdue]
        have ih := startDueServingJobsAux_dataWF pts' mode α L D_out
          rest (sn.node.residual pts' S_cur) leaf leafAns leafSq leafCh
          hleaf_rest hlch htag_rest
        rcases hrec : startDueServingJobsAux pts' α L (sn.node.residual pts' S_cur)
            rest leaf leafAns leafSq leafCh with
          ⟨rest', leaf', leafAns', leafSq', leafCh', retired⟩
        rw [hrec] at ih
        rcases ih with ⟨hleaf_ih, hlch_ih, htag_ih, hret_ih⟩
        refine ⟨?_, hlch_ih, ?_, hret_ih⟩
        · simpa [List.map_cons, servingChainInputAt_cons_succ] using hleaf_ih
        · intro idx p hp
          cases idx with
          | zero =>
            simp only [List.getElem?_cons_zero, Option.some.injEq] at hp
            subst hp
            rw [List.map_cons, servingChainInputAt_zero]
            exact h0
          | succ idx =>
            simp only [List.getElem?_cons_succ] at hp
            rw [List.map_cons, servingChainInputAt_cons_succ]
            exact htag_ih idx p hp

open Classical in
theorem alg4Line9StartDueJobsAndHandleLeaves_dataWF {d : ℕ} {ι : Type}
    {pts' : ι → EuclideanSpace ℝ (Fin d)} {mode : Alg4Mode} {α : ℝ} {L D_out : ℕ}
    (hα_pos : 0 < α) (hα_le : α ≤ 1) (hL_pos : 1 ≤ L)
    (P' : Finset ι)
    (nodes : List (Alg4ServingNode d ι × Bool))
    (leaf : Finset ι) (leafAns : Option (ι × ι)) (leafSq : ℝ) (leafCh : Bool)
    (rebuildChoices : List (LeafRebuildLevelChoices d ι))
    (leafHint : Option (ι × ι))
    (hleaf : leaf = servingChainInputAt pts'
      (nodes.map (fun p => p.1.toServingNodeState)) P' nodes.length)
    (hlch : leafCh = false →
      IsExactLeafAnswer pts' leaf leafAns ∧
      leafSq = (baselinePairLength pts' leafAns) ^ 2)
    (htag : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
      nodes[idx]? = some p →
      TaggedNodeDataWF mode pts'
        (servingChainInputAt pts' (nodes.map (fun q => q.1.toServingNodeState)) P' idx)
        p) :
    let (nodes9, finalLeaf, finalAns, finalSq, retiredDue) :=
      alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
        nodes leaf leafAns leafSq leafCh rebuildChoices leafHint
    finalLeaf = servingChainInputAt pts'
      (nodes9.map (fun p => p.1.toServingNodeState)) P' nodes9.length ∧
    IsExactLeafAnswer pts' finalLeaf finalAns ∧
    finalSq = (baselinePairLength pts' finalAns) ^ 2 ∧
    (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
      nodes9[idx]? = some p →
      TaggedNodeDataWF mode pts'
        (servingChainInputAt pts' (nodes9.map (fun q => q.1.toServingNodeState)) P' idx)
        p) ∧
    (1 ≤ D_out → ∀ r ∈ retiredDue, r.HasBoundedOutdegree D_out) := by
  dsimp only [alg4Line9StartDueJobsAndHandleLeaves]
  have hs := startDueServingJobsAux_dataWF pts' mode α L D_out
    nodes P' leaf leafAns leafSq leafCh hleaf hlch htag
  rcases hdue_eq : startDueServingJobsAux pts' α L P' nodes leaf leafAns leafSq leafCh with
    ⟨nodes₁, leaf₁, leafAns₁, leafSq₁, leafCh₁, retired₁⟩
  rw [hdue_eq] at hs
  rcases hs with ⟨hleaf₁, hlch₁, htag₁, hret₁⟩
  by_cases hgt : 6 * L < leaf₁.card
  · rw [if_pos hgt]
    have hreb := rebuildOversizedLeafAux_fuel (pts' := pts') (mode := mode)
      hα_pos hα_le hL_pos leaf₁.card leaf₁ rebuildChoices le_rfl
    rcases hreb_eq : rebuildOversizedLeafAux pts' mode α L leaf₁.card leaf₁ rebuildChoices with
      ⟨rebuiltNodes, finalLeaf⟩
    rw [hreb_eq] at hreb
    rcases hreb with ⟨_, hfin_eq, _, _, htag_reb, _⟩
    have hex := computeExactLeafAnswer_spec pts' finalLeaf leafHint
    rcases servingChainInputAt_append pts'
        (nodes₁.map (fun p => p.1.toServingNodeState))
        (rebuiltNodes.map (fun p => p.1.toServingNodeState)) P' with
      ⟨happ_left, happ_right⟩
    dsimp only
    refine ⟨?_, hex.1, hex.2, ?_, ?_⟩
    · rw [List.map_append, List.length_append]
      have hlen1 : (nodes₁.map (fun p => p.1.toServingNodeState)).length = nodes₁.length := by simp
      have hlen2 : (rebuiltNodes.map (fun p => p.1.toServingNodeState)).length =
          rebuiltNodes.length := by simp
      rw [← hlen1, ← hlen2, happ_right, hlen1, ← hleaf₁, hlen2]
      exact hfin_eq
    · intro idx p hp
      rw [List.map_append]
      by_cases hlt_idx : idx < nodes₁.length
      · rw [List.getElem?_append_left hlt_idx] at hp
        have hle_map : idx ≤ (nodes₁.map (fun q => q.1.toServingNodeState)).length := by
          simp; omega
        rw [happ_left idx hle_map]
        exact htag₁ idx p hp
      · have hge : nodes₁.length ≤ idx := Nat.le_of_not_lt hlt_idx
        rw [List.getElem?_append_right hge] at hp
        have heq_idx : idx =
            (nodes₁.map (fun q => q.1.toServingNodeState)).length + (idx - nodes₁.length) := by
          simp; omega
        rw [heq_idx, happ_right]
        simp only [List.length_map, ← hleaf₁]
        exact htag_reb (idx - nodes₁.length) p hp
    · intro hD r hr
      rcases List.mem_append.mp hr with hr1 | hr2
      · exact hret₁ hD r hr1
      · rcases List.mem_singleton.mp hr2 with rfl
        exact ⟨Nat.zero_le D_out, trivial⟩
  · rw [if_neg hgt]
    by_cases hch : leafCh₁ = true
    · rw [if_pos hch]
      have hex := computeExactLeafAnswer_spec pts' leaf₁ leafHint
      exact ⟨hleaf₁, hex.1, hex.2, htag₁, hret₁⟩
    · rw [if_neg hch]
      have hch_f : leafCh₁ = false := Bool.eq_false_iff.mpr hch
      rcases hlch₁ hch_f with ⟨hex₁, hsq₁⟩
      exact ⟨hleaf₁, hex₁, hsq₁, htag₁, hret₁⟩

open Classical in
theorem alg4Line10RefreshAffectedCaches_spec {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) :
    ∀ (nodes9 : List (Alg4ServingNode d ι × Bool))
      (S_cur : Finset ι)
      (sampLists : List (List ι)) (cfgHints : List (Option ShellConfig)),
      (∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes9[idx]? = some p →
        TaggedNodeDataWF mode pts'
          (servingChainInputAt pts' (nodes9.map (fun q => q.1.toServingNodeState)) S_cur idx)
          p) →
      let finalNodes := alg4Line10RefreshAffectedCaches pts' mode S_cur nodes9 sampLists cfgHints
      finalNodes.length = nodes9.length ∧
      (finalNodes.map Alg4ServingNode.toServingNodeState).map ServingNodeState.node =
        (nodes9.map (fun p => p.1.toServingNodeState)).map ServingNodeState.node ∧
      ∀ (idx : ℕ) (p_in : Alg4ServingNode d ι × Bool) (sn_out : Alg4ServingNode d ι),
        nodes9[idx]? = some p_in →
        finalNodes[idx]? = some sn_out →
        let sn_in := p_in.1
        let S_idx := servingChainInputAt pts'
          (finalNodes.map Alg4ServingNode.toServingNodeState) S_cur idx
        S_idx = servingChainInputAt pts'
          (nodes9.map (fun p => p.1.toServingNodeState)) S_cur idx ∧
        sn_out.birthSnapshot = sn_in.birthSnapshot ∧
        sn_out.node = sn_in.node ∧
        sn_out.trueAge = sn_in.trueAge ∧
        sn_out.age = sn_in.age ∧
        sn_out.ownedJob = sn_in.ownedJob ∧
        ServingNodePreRefreshWF mode pts' S_idx sn_out ∧
        ServingNodeCacheWF mode pts' S_idx sn_out
  | [], S_cur, sampLists, cfgHints, _ =>
      ⟨rfl, rfl, fun _ _ _ h _ => by simp at h⟩
  | (sn, needRefresh) :: rest, S_cur, sampLists, cfgHints, htag => by
      have h0 := htag 0 (sn, needRefresh) rfl
      rw [List.map_cons, servingChainInputAt_zero] at h0
      let samps := sampLists.head?.getD []
      let cHint := cfgHints.head?.join
      let sn' : Alg4ServingNode d ι :=
        if needRefresh then
          let (bPair, bSq) := refreshBaselineFromSamples pts' sn.node.o S_cur sn.radiusDict samps
          let (mPair, mSq) := refreshMaxMatchingWitness pts' mode sn.node sn.localMatchings cHint
          { sn with
            baselinePair := bPair, baselineDistSq := bSq,
            maxMatchingPair := mPair, maxMatchingDistSq := mSq }
        else sn
      have hcons_10 :
          alg4Line10RefreshAffectedCaches pts' mode S_cur ((sn, needRefresh) :: rest) sampLists cfgHints =
            sn' :: alg4Line10RefreshAffectedCaches pts' mode (sn'.node.residual pts' S_cur) rest
              (sampLists.drop 1) (cfgHints.drop 1) := rfl
      have hhd_node : sn'.node = sn.node := by
        dsimp only [sn']; split_ifs <;> rfl
      have htag_rest : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
          rest[idx]? = some p →
          TaggedNodeDataWF mode pts'
            (servingChainInputAt pts' (rest.map (fun q => q.1.toServingNodeState))
              (sn'.node.residual pts' S_cur) idx)
            p := by
        rw [hhd_node]
        intro idx p hp
        simpa [List.map_cons, servingChainInputAt_cons_succ]
          using htag (idx + 1) p hp
      rcases alg4Line10RefreshAffectedCaches_spec pts' mode rest
          (sn'.node.residual pts' S_cur) (sampLists.drop 1) (cfgHints.drop 1) htag_rest with
        ⟨hLen_rest, hballs_rest, hrest_idx⟩
      rw [hcons_10]
      refine ⟨by dsimp only [List.length_cons]; rw [hLen_rest], ?_, ?_⟩
      · simp only [List.map_cons]
        have hhd_s : sn'.toServingNodeState.node = sn.toServingNodeState.node := hhd_node
        rw [hhd_s, hballs_rest]
      · intro idx p_in sn_out hp_in hsn_out
        cases idx with
        | zero =>
          simp only [List.getElem?_cons_zero, Option.some.injEq] at hp_in hsn_out
          subst hp_in
          rw [← hsn_out, List.map_cons, servingChainInputAt_zero, List.map_cons, servingChainInputAt_zero]
          dsimp only [sn']
          by_cases hnr : needRefresh = true
          · rw [if_pos hnr]
            have hb := refreshBaselineFromSamples_spec pts' sn.node.o S_cur sn.radiusDict samps
            have hm := refreshMaxMatchingWitness_spec pts' mode sn.node h0.1.2 cHint
            exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, h0.1, ⟨hb.1, hb.2, hm⟩⟩
          · rw [if_neg hnr]
            have hnr_f : needRefresh = false := Bool.eq_false_iff.mpr hnr
            exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, h0.1, h0.2 hnr_f⟩
        | succ idx =>
          simp only [List.getElem?_cons_succ] at hp_in hsn_out
          rw [List.map_cons, servingChainInputAt_cons_succ,
              List.map_cons, servingChainInputAt_cons_succ]
          have hih := hrest_idx idx p_in sn_out hp_in hsn_out
          simpa [Alg4ServingNode.toServingNodeState, hhd_node] using hih

/-! ### 6. Full Conjunct (2) of `S_claim_C_2_space_reclaim` -/

def alg4RootEvent {d : ℕ} {ι : Type} : Alg4PointUpdate d ι → PoolUpdateEvent ι
  | .insert p _ => .externalInsert p
  | .delete p => .externalDelete p

open Classical in
noncomputable def applyLeafPoolEvent {ι : Type} (leaf : Finset ι) : PoolUpdateEvent ι → Finset ι
  | .externalInsert p => insert p leaf
  | .externalDelete p => leaf.erase p
  | .virtualValueDelete => leaf
  | .unaffected => leaf

open Classical in
theorem alg4Line1ApplyToServingChain_eq {d : ℕ} {ι : Type}
    (pts' : ι → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (nodes : List (Alg4ServingNode d ι)) (terminalLeaf : Finset ι)
    (upd : Alg4PointUpdate d ι)
    (qList : List (NodeMatchingQueryAnswers ι)) (mHints : List (Option ι)) :
    let (nodes1, leafEv) := alg4Line1Aux pts' mode (some (alg4RootEvent upd)) nodes qList mHints
    alg4Line1ApplyToServingChain pts' mode nodes terminalLeaf upd qList mHints =
      (nodes1,
       applyLeafPoolEvent terminalLeaf leafEv,
       leafEv.isClockTick) := by
  cases upd <;> rfl

open Classical in
theorem conjunct2_step_invariants :
    ∀ (d n : ℕ) (ι : Type) (mode : Alg4Mode) (α : ℝ) (L reclaimMult D_out : ℕ)
      (st : Alg4State d ι) (upd : Alg4PointUpdate d ι) (choices : Alg4StepChoices d ι),
      (st.WellFormed n mode α L D_out →
       IsValidAlg4PointUpdate n st upd →
        let P' := applyAlg4PointSetUpdate st.activeSet upd
        let pts' := updateAlg4Coords st.coords upd
        let (nodesLine1, leafLine1, _) :=
          alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
            choices.servingRouteQueries choices.servingRadiusMaxHints
        let nodesLines2To6 :=
          alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
        ∃ hLen1 : nodesLine1.length = st.servingNodes.length,
        ∃ hLen26 : nodesLines2To6.length = st.servingNodes.length,
          leafLine1 =
            servingChainInputAt pts'
              (nodesLine1.map (fun p => p.1.toServingNodeState)) P' st.servingNodes.length ∧
          (∀ idx : Fin st.servingNodes.length,
            let p1 := nodesLine1[idx.val]'(by omega)
            let sn₁ := p1.1
            let ev := p1.2
            let S_before := st.servingInputAt idx.val
            let S_after :=
              servingChainInputAt pts'
                (nodesLine1.map (fun p => p.1.toServingNodeState)) P' idx.val
            IsValidPoolUpdateEvent S_before S_after ev ∧
            ev.ticks ≤ 1 ∧
            (ev.isClockTick = false →
              (nodesLines2To6[idx.val]'(by omega)).1 = st.servingNodes[idx]) ∧
            (ev.isClockTick = true →
              ∀ (job : Alg4PendingJob d ι) (jc : PendingJobStepChoices d ι),
                sn₁.ownedJob = some job →
                  let job₁ := alg4Line3RouteThroughPrefix pts' mode job ev S_after jc
                  ∃ hPrefLen : job₁.completedPrefix.length = job.completedPrefix.length,
                    job₁.currentResidual =
                      prefixResidual pts'
                        (job₁.completedPrefix.map Alg4OpenedLevel.toOpenedJobLevel) S_after ∧
                    ∀ j : Fin job.completedPrefix.length,
                      let lv := job.completedPrefix[j]
                      let lv₁ := job₁.completedPrefix[j.val]'(by omega)
                      let S_lv := alg4PrefixInputAt st.coords job.completedPrefix S_before j.val
                      let S_lv' := alg4PrefixInputAt pts' job₁.completedPrefix S_after j.val
                      ∃ ev_j : PoolUpdateEvent ι,
                        IsValidPoolUpdateEvent S_lv S_lv' ev_j ∧
                        ev_j.ticks ≤ 1 ∧
                        lv₁.trueInputAge = lv.trueInputAge + ev_j.ticks ∧
                        lv₁.radiusDict.IsScanValid pts' lv.ball.o S_lv' ∧
                        lv₁.classifiedIds ⊆ S_lv' ∧
                        ValidNodeMatchingsOn pts' mode lv.ball lv₁.classifiedIds
                          lv₁.localMatchings))) ∧
      (∀ (nodes26 : List (Alg4ServingNode d ι × Bool))
         (leaf1 : Finset ι) (leafAns0 : Option (ι × ι)) (leafSq0 : ℝ) (leafTicked : Bool),
        let (nodes78, leaf78, _, _, _, retired78) :=
          alg4Lines7To8InstallCompletedJobs nodes26 leaf1 leafAns0 leafSq0 leafTicked
        ((∀ p ∈ nodes26, ∀ job, p.1.ownedJob = some job → ¬ job.IsReadyToInstall) →
          nodes78 = nodes26 ∧ leaf78 = leaf1 ∧ retired78 = []) ∧
        (∀ (idx₀ : Fin nodes26.length) (job₀ : Alg4PendingJob d ι),
          (nodes26[idx₀]).1.ownedJob = some job₀ →
          job₀.IsReadyToInstall →
          (∀ i : Fin nodes26.length, i < idx₀ →
            ∀ j, (nodes26[i]).1.ownedJob = some j → ¬ j.IsReadyToInstall) →
            nodes78.take idx₀.val = nodes26.take idx₀.val ∧
            nodes78 =
              (nodes26.take idx₀.val) ++
                job₀.completedPrefix.map (fun lv => (installOpenedLevelAsServingNode lv, true)) ∧
            leaf78 = job₀.currentResidual ∧
            (∀ (pts' : ι → EuclideanSpace ℝ (Fin d)) (P' : Finset ι),
              servingChainInputAt pts'
                (nodes78.map (fun p => p.1.toServingNodeState)) P' idx₀.val =
              servingChainInputAt pts'
                (nodes26.map (fun p => p.1.toServingNodeState)) P' idx₀.val) ∧
            (∀ lv ∈ job₀.completedPrefix,
              let sn_new := installOpenedLevelAsServingNode lv
              sn_new.birthSnapshot = lv.birthSnapshot ∧
              sn_new.trueAge = lv.trueInputAge ∧
              sn_new.age = lv.elapsedRootTicks ∧
              sn_new.ownedJob = none ∧
              (∀ (pts' : ι → EuclideanSpace ℝ (Fin d)) (S_lv : Finset ι),
                lv.WellFormed mode α L pts' S_lv →
                  sn_new.trueAge ≤ sn_new.age ∧
                  HasNodeAge sn_new.birthSnapshot S_lv sn_new.trueAge)))) ∧
      (0 < α → α ≤ 1 → 1 ≤ L →
       st.WellFormed n mode α L D_out →
       IsValidAlg4PointUpdate n st upd →
        let (nextState, ans) := alg4Step mode α L reclaimMult st upd choices
        nextState.cachedAnswer = ans ∧
        IsExactLeafAnswer nextState.coords nextState.terminalLeaf
          nextState.terminalLeafAnswer ∧
        (∀ idx : Fin nextState.servingNodes.length,
          let sn' := nextState.servingNodes[idx]
          let S' := nextState.servingInputAt idx.val
          IsActiveNodePair S' sn'.baselinePair ∧
          (∀ x y : ι, sn'.maxMatchingPair = some (x, y) → x ∈ S' ∧ y ∈ S' ∧ x ≠ y)) ∧
        (if nextState.activeSet.card ≤ 1 then
          ans = (none, 0)
        else
          ∃ u v : ι,
            u ∈ nextState.activeSet ∧
            v ∈ nextState.activeSet ∧
            u ≠ v ∧
            ans = (some (u, v), euclideanDistSq (nextState.coords u) (nextState.coords v))) ∧
        (∀ p : ι, ∀ _hDel : upd = .delete p,
          p ∉ nextState.activeSet ∧
          (∀ u v : ι, ans.1 = some (u, v) → u ≠ p ∧ v ≠ p) ∧
          (∀ idx : Fin nextState.servingNodes.length,
            (∀ u v : ι, (nextState.servingNodes[idx]).baselinePair = some (u, v) →
              u ≠ p ∧ v ≠ p) ∧
            (∀ u v : ι, (nextState.servingNodes[idx]).maxMatchingPair = some (u, v) →
              u ≠ p ∧ v ≠ p)))) ∧
      (0 < α → α ≤ 1 → 1 ≤ L →
        ∀ (pts' : ι → EuclideanSpace ℝ (Fin d)) (leaf₁ : Finset ι)
          (rebuildChoices : List (LeafRebuildLevelChoices d ι)),
          6 * L < leaf₁.card →
          leaf₁.card ≤ 6 * L + 1 →
            let (rebuiltNodes, finalLeaf) :=
              rebuildOversizedLeafAux pts' mode α L leaf₁.card leaf₁ rebuildChoices
            IsResidualLeafSize L finalLeaf.card ∧
            (rebuiltNodes.length : ℝ) ≤ cLeafVal * α⁻¹ ∧
            rebuiltNodes.length ≤ 6 * L + 1 ∧
            ((rebuiltNodes.map (fun p => p.1.birthSnapshot.card)).sum + finalLeaf.card ^ 2 : ℝ) ≤
              cLeafVal * α⁻¹ * ((L + 1 : ℝ) ^ 2) ∧
            (∀ p ∈ rebuiltNodes,
              p.2 = true ∧
              IsLargeResidualLevel L p.1.birthSnapshot.card ∧
              p.1.birthSnapshot.card ≤ 6 * L + 1 ∧
              PassesBirthCoreCheck α pts' p.1.node p.1.birthSnapshot ∧
              p.1.trueAge = 0 ∧
              p.1.age = 0 ∧
              p.1.ownedJob = none ∧
              p.1.radiusDict.IsComplete pts' p.1.node.o p.1.birthSnapshot ∧
              ValidNodeMatchingsOn pts' mode p.1.node p.1.birthSnapshot p.1.localMatchings)) := by
  intro d n ι mode α L reclaimMult D_out st upd choices
  refine ⟨?_, alg4Lines7To8InstallCompletedJobs_conj2 mode α L, ?_, ?_⟩
  · -- Part 2.1
    intro hwf hupd
    rcases hwf with ⟨_, hchain_wf, _, _, hnodes_wf, _, _, _⟩
    set P' := applyAlg4PointSetUpdate st.activeSet upd
    set pts' := updateAlg4Coords st.coords upd
    have hpts_act : ∀ x ∈ st.activeSet, pts' x = st.coords x :=
      fun x hx => updateAlg4Coords_eq_on_liveRetainedIds hupd (activeSet_subset_liveRetainedIds st hx)
    let rootEv : PoolUpdateEvent ι := alg4RootEvent upd
    have hroot_ev : IsValidPoolUpdateEvent st.activeSet P' rootEv := by
      cases upd with
      | insert p pt =>
        exact ⟨fun hp => hupd.1 (activeSet_subset_liveRetainedIds st hp), rfl⟩
      | delete p =>
        exact ⟨hupd, rfl⟩
    have hl1_in : ∀ (idx : ℕ) (sn : Alg4ServingNode d ι),
        st.servingNodes[idx]? = some sn →
        let S_cur := servingChainInputAt st.coords
          (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet idx
        sn.trueAge ≤ sn.age ∧
        HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
        ServingNodePreRefreshWF mode st.coords S_cur sn ∧
        ServingNodeCacheWF mode st.coords S_cur sn := by
      intro idx sn hget
      have hlt : idx < st.servingNodes.length := by
        by_contra hge
        rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
      have hsn_eq : st.servingNodes[idx]'hlt = sn := by
        rw [List.getElem?_eq_getElem hlt] at hget; exact Option.some.inj hget
      have hwfi := hnodes_wf ⟨idx, hlt⟩
      dsimp only at hwfi
      rw [Fin.getElem_fin, hsn_eq] at hwfi
      rcases servingNodePreRefresh_and_cache_of_wellFormed hwfi with ⟨hpre, hcache⟩
      exact ⟨hwfi.2.1, hwfi.2.2.1, hpre, hcache⟩
    have hl1 := alg4Line1Aux_spec st.coords pts' mode st.servingNodes st.activeSet P' (some rootEv)
      choices.servingRouteQueries choices.servingRadiusMaxHints hpts_act hroot_ev hl1_in
    rcases hl1_eq : alg4Line1Aux pts' mode (some rootEv) st.servingNodes
        choices.servingRouteQueries choices.servingRadiusMaxHints with ⟨nodesLine1, leafEv⟩
    rw [hl1_eq] at hl1
    rcases hl1 with ⟨hLen1, _, hleaf_ev, hidx1⟩
    rcases alg4Lines2To6StepPendingJobs_basic pts' mode α L nodesLine1 P'
        choices.pendingJobChoices with ⟨hLen26, _, hidx26⟩
    have hleaf_eq : st.terminalLeaf = servingChainInputAt st.coords
        (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet
        st.servingNodes.length := by
      simpa [Alg4State.toScheduledServingChain] using hchain_wf.2.1
    rw [← hleaf_eq, hLen1] at hleaf_ev
    let leafLine1 : Finset ι := applyLeafPoolEvent st.terminalLeaf leafEv
    have hnext_leaf : leafLine1 =
        servingChainInputAt pts'
          (nodesLine1.map (fun p => p.1.toServingNodeState)) P' st.servingNodes.length := by
      cases leafEv with
      | externalInsert p => exact hleaf_ev.2.symm
      | externalDelete p => exact hleaf_ev.2.symm
      | virtualValueDelete => exact hleaf_ev.symm
      | unaffected => exact hleaf_ev.symm
    have hl1_apply_eq :
        alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
          choices.servingRouteQueries choices.servingRadiusMaxHints =
          (nodesLine1, leafLine1, leafEv.isClockTick) := by
      have h := alg4Line1ApplyToServingChain_eq pts' mode st.servingNodes st.terminalLeaf upd
        choices.servingRouteQueries choices.servingRadiusMaxHints
      dsimp only [rootEv] at hl1_eq
      rw [hl1_eq] at h
      dsimp only at h
      exact h
    dsimp only
    rw [hl1_apply_eq]
    dsimp only
    refine ⟨hLen1, hLen26.trans hLen1, hnext_leaf, ?_⟩
    intro idx
    have hi1_lt : idx.val < nodesLine1.length := by omega
    have hi26_lt : idx.val < (alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices).length := by omega
    rcases hidx1 idx.val (st.servingNodes[idx]) (nodesLine1[idx.val]'hi1_lt)
      (by rw [List.getElem?_eq_getElem idx.isLt, Fin.getElem_fin])
      (List.getElem?_eq_getElem hi1_lt) with
      ⟨hev1, hticks1, _, _, hown1, _, _, _, _, _, hfalse1⟩
    have hi26 := hidx26 idx.val (nodesLine1[idx.val]'hi1_lt)
      ((alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices)[idx.val]'hi26_lt)
      (List.getElem?_eq_getElem hi1_lt)
      (List.getElem?_eq_getElem hi26_lt)
    refine ⟨hev1, hticks1, ?_, ?_⟩
    · intro hf
      exact (hi26.2.2.2.2.2.2.2.2.2.2.2.1 hf).trans (hfalse1 hf).1
    · intro _ job jc hjob
      rw [hown1] at hjob
      have hjob_wf := (hnodes_wf idx).2.2.2.2.2.2.2.2
      rw [hjob] at hjob_wf
      have hdwf : PendingJobDataWF mode α L st.coords (st.servingInputAt idx.val) job :=
        pendingJobDataWF_of_wellFormed hjob_wf
      have hpts_S : ∀ x ∈ st.servingInputAt idx.val, pts' x = st.coords x :=
        fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
      have hsn_live := servingNode_subsets_liveRetainedIds st (sn := st.servingNodes[idx]) (by rw [Fin.getElem_fin]; exact List.getElem_mem idx.isLt)
      have hpts_B : ∀ lv ∈ job.completedPrefix, ∀ x ∈ lv.birthSnapshot, pts' x = st.coords x :=
        fun lv hlv x hx =>
          updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job hjob).2 lv hlv).1 hx)
      rcases alg4Line3RoutePrefixAux_spec st.coords pts' mode α L job.completedPrefix
          (st.servingInputAt idx.val)
          (servingChainInputAt pts' (nodesLine1.map (fun p : Alg4ServingNode d ι × PoolUpdateEvent ι => p.1.toServingNodeState)) P' idx.val)
          (some (nodesLine1[idx.val]'hi1_lt).2)
          jc.prefixRouteQueries jc.prefixRouteMaxHints hpts_S hpts_B hev1 hdwf.2.1 with
        ⟨hPrefLen, _, hroute_j⟩
      refine ⟨hPrefLen, rfl, ?_⟩
      intro j
      rcases hroute_j j with ⟨_, _, _, _, _, _, _, ev_j, hev_j, ht_j, hage_eq, _, hscan_j, hcls_j, hlm_j, _, _, _⟩
      exact ⟨ev_j, hev_j, ht_j, hage_eq, hscan_j, hcls_j, hlm_j⟩
  · -- Part 2.3
    intro hα_pos hα_le hL_pos hwf hupd
    rcases hwf with ⟨_, hchain_wf, _, hleaf_sq, hnodes_wf, _, _, _⟩
    set P' := applyAlg4PointSetUpdate st.activeSet upd
    set pts' := updateAlg4Coords st.coords upd
    have hact := validAlg4PointUpdate_activeSet hupd
    have hpts_act : ∀ x ∈ st.activeSet, pts' x = st.coords x :=
      fun x hx => updateAlg4Coords_eq_on_liveRetainedIds hupd (activeSet_subset_liveRetainedIds st hx)
    let rootEv : PoolUpdateEvent ι := alg4RootEvent upd
    have hroot_ev : IsValidPoolUpdateEvent st.activeSet P' rootEv := by
      cases upd with
      | insert p pt =>
        exact ⟨fun hp => hupd.1 (activeSet_subset_liveRetainedIds st hp), rfl⟩
      | delete p =>
        exact ⟨hupd, rfl⟩
    have hl1_in : ∀ (idx : ℕ) (sn : Alg4ServingNode d ι),
        st.servingNodes[idx]? = some sn →
        let S_cur := servingChainInputAt st.coords
          (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet idx
        sn.trueAge ≤ sn.age ∧
        HasNodeAge sn.birthSnapshot S_cur sn.trueAge ∧
        ServingNodePreRefreshWF mode st.coords S_cur sn ∧
        ServingNodeCacheWF mode st.coords S_cur sn := by
      intro idx sn hget
      have hlt : idx < st.servingNodes.length := by
        by_contra hge
        rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hget; cases hget
      have hsn_eq : st.servingNodes[idx]'hlt = sn := by
        rw [List.getElem?_eq_getElem hlt] at hget; exact Option.some.inj hget
      have hwfi := hnodes_wf ⟨idx, hlt⟩
      dsimp only at hwfi
      rw [Fin.getElem_fin, hsn_eq] at hwfi
      rcases servingNodePreRefresh_and_cache_of_wellFormed hwfi with ⟨hpre, hcache⟩
      exact ⟨hwfi.2.1, hwfi.2.2.1, hpre, hcache⟩
    have hl1 := alg4Line1Aux_spec st.coords pts' mode st.servingNodes st.activeSet P' (some rootEv)
      choices.servingRouteQueries choices.servingRadiusMaxHints hpts_act hroot_ev hl1_in
    rcases hl1_eq : alg4Line1Aux pts' mode (some rootEv) st.servingNodes
        choices.servingRouteQueries choices.servingRadiusMaxHints with ⟨nodesLine1, leafEv⟩
    rw [hl1_eq] at hl1
    rcases hl1 with ⟨hLen1, _, hleaf_ev, hidx1⟩
    have hleaf_eq : st.terminalLeaf = servingChainInputAt st.coords
        (st.servingNodes.map Alg4ServingNode.toServingNodeState) st.activeSet
        st.servingNodes.length := by
      simpa [Alg4State.toScheduledServingChain] using hchain_wf.2.1
    rw [← hleaf_eq] at hleaf_ev
    let leafLine1 : Finset ι := applyLeafPoolEvent st.terminalLeaf leafEv
    have hleafLine1_eq : leafLine1 = servingChainInputAt pts'
        (nodesLine1.map (fun p => p.1.toServingNodeState)) P' nodesLine1.length := by
      cases leafEv with
      | externalInsert p => exact hleaf_ev.2.symm
      | externalDelete p => exact hleaf_ev.2.symm
      | virtualValueDelete => exact hleaf_ev.symm
      | unaffected => exact hleaf_ev.symm
    have hleafTick_false : leafEv.isClockTick = false →
        IsExactLeafAnswer pts' leafLine1 st.terminalLeafAnswer ∧
        st.terminalLeafDistSq = (baselinePairLength pts' st.terminalLeafAnswer) ^ 2 := by
      intro hltf
      have hl_same : leafLine1 = st.terminalLeaf := by
        cases leafEv <;> simp [PoolUpdateEvent.isClockTick] at hltf <;> rfl
      rw [hl_same]
      have hsub_leaf : st.terminalLeaf ⊆ st.activeSet := by
        rw [hleaf_eq]
        exact servingChainInputAt_subset _ _ _ _
      have hpts_leaf : ∀ x ∈ st.terminalLeaf, st.coords x = pts' x :=
        fun x hx => (hpts_act x (hsub_leaf hx)).symm
      have hex0 : IsExactLeafAnswer st.coords st.terminalLeaf st.terminalLeafAnswer :=
        hchain_wf.2.2
      exact ⟨(isExactLeafAnswer_congr st.terminalLeafAnswer hpts_leaf).mp hex0,
        hleaf_sq.trans (by rw [baselinePairLength_congr_exact hex0 hpts_leaf])⟩
    rcases alg4Lines2To6StepPendingJobs_basic pts' mode α L nodesLine1 P'
        choices.pendingJobChoices with ⟨hLen26, hballs26, hidx26⟩
    set nodes26 := alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
    have h26_wf : ∀ (idx : ℕ) (p : Alg4ServingNode d ι × Bool),
        nodes26[idx]? = some p →
        let S_idx := servingChainInputAt pts'
          (nodes26.map (fun q => q.1.toServingNodeState)) P' idx
        TaggedNodeDataWF mode pts' S_idx p ∧
        ∀ job : Alg4PendingJob d ι, p.1.ownedJob = some job →
          PendingJobDataWF mode α L pts' S_idx job := by
      intro idx p26 hp26
      have hi_lt26 : idx < nodes26.length := by
        by_contra hge
        rw [List.getElem?_eq_none (Nat.le_of_not_lt hge)] at hp26; cases hp26
      have hi_lt1 : idx < nodesLine1.length := by omega
      have hi_lt0 : idx < st.servingNodes.length := by omega
      have hS_eq : servingChainInputAt pts'
          (nodes26.map (fun q => q.1.toServingNodeState)) P' idx =
          servingChainInputAt pts'
          (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx := by
        apply servingChainInputAt_eq_of_take_balls
        rw [List.map_take, List.map_take, hballs26]
      rcases hidx1 idx (st.servingNodes[idx]'hi_lt0) (nodesLine1[idx]'hi_lt1)
        (List.getElem?_eq_getElem hi_lt0) (List.getElem?_eq_getElem hi_lt1) with
        ⟨hev1, _, _, _, hown1, _, _, _, _, hpre1, hfalse1⟩
      have hi26 := hidx26 idx (nodesLine1[idx]'hi_lt1) p26
        (List.getElem?_eq_getElem hi_lt1) hp26
      dsimp only
      rw [hS_eq]
      have hpre26 : ServingNodePreRefreshWF mode pts'
          (servingChainInputAt pts' (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx)
          p26.1 := by
        rcases hpre1 with ⟨hrd, hlm⟩
        refine ⟨?_, ?_⟩
        · unfold RadiusDictState.IsComplete
          rw [hi26.2.2.1, hi26.2.2.2.2.2.1]
          exact hrd
        · rw [hi26.2.2.1, hi26.2.2.2.2.2.2.1]
          exact hlm
      refine ⟨⟨hpre26, ?_⟩, ?_⟩
      · intro hp2f
        rw [hi26.1] at hp2f
        have hsn_eq := hi26.2.2.2.2.2.2.2.2.2.2.2.1 hp2f
        rw [hsn_eq]
        exact (hfalse1 hp2f).2.2
      · intro job' hjob'
        by_cases hct : (nodesLine1[idx]'hi_lt1).2.isClockTick = true
        · have hstep := hi26.2.2.2.2.2.2.2.2.2.2.2.2 hct
          cases hown_l1 : (nodesLine1[idx]'hi_lt1).1.ownedJob with
          | none =>
            rw [hown_l1] at hstep
            rw [hstep, hown_l1] at hjob'
            cases hjob'
          | some job0 =>
            rw [hown_l1] at hstep
            rw [hstep] at hjob'
            dsimp only at hjob'
            injection hjob' with hj_eq
            subst hj_eq
            have hown0 : (st.servingNodes[idx]'hi_lt0).ownedJob = some job0 := by
              rw [← hown1]; exact hown_l1
            have hjob_wf := (hnodes_wf ⟨idx, hi_lt0⟩).2.2.2.2.2.2.2.2
            rw [Fin.getElem_fin] at hjob_wf
            dsimp only at hjob_wf
            rw [hown0] at hjob_wf
            have hdwf0 := pendingJobDataWF_of_wellFormed hjob_wf
            have hpts_S : ∀ x ∈ st.servingInputAt idx, pts' x = st.coords x :=
              fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
            have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi_lt0)
            have hpts_B : ∀ lv ∈ job0.completedPrefix, ∀ x ∈ lv.birthSnapshot,
                pts' x = st.coords x :=
              fun lv hlv x hx =>
                updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job0 hown0).2 lv hlv).1 hx)
            exact stepSinglePendingJob_dataWF hα_le _ hpts_S hpts_B hev1 hdwf0
        · have hctf : (nodesLine1[idx]'hi_lt1).2.isClockTick = false :=
            Bool.eq_false_iff.mpr hct
          have hsn_eq : p26.1 = st.servingNodes[idx]'hi_lt0 :=
            (hi26.2.2.2.2.2.2.2.2.2.2.2.1 hctf).trans (hfalse1 hctf).1
          have hS_same : servingChainInputAt pts'
              (nodesLine1.map (fun q => q.1.toServingNodeState)) P' idx =
              st.servingInputAt idx :=
            (hfalse1 hctf).2.1
          rw [hsn_eq] at hjob'
          rw [hS_same]
          have hjob_wf := (hnodes_wf ⟨idx, hi_lt0⟩).2.2.2.2.2.2.2.2
          rw [Fin.getElem_fin] at hjob_wf
          dsimp only at hjob_wf
          rw [hjob'] at hjob_wf
          have hdwf0 := pendingJobDataWF_of_wellFormed hjob_wf
          have hpts_S : ∀ x ∈ st.servingInputAt idx, pts' x = st.coords x :=
            fun x hx => hpts_act x (servingChainInputAt_subset _ _ _ _ hx)
          have hsn_live := servingNode_subsets_liveRetainedIds st (List.getElem_mem hi_lt0)
          have hpts_B : ∀ lv ∈ job'.completedPrefix, ∀ x ∈ lv.birthSnapshot,
              pts' x = st.coords x :=
            fun lv hlv x hx =>
              updateAlg4Coords_eq_on_liveRetainedIds hupd (((hsn_live.2 job' hjob').2 lv hlv).1 hx)
          exact pendingJobDataWF_congr hdwf0 hpts_S hpts_B
    have hleafLine1_26 : leafLine1 = servingChainInputAt pts'
        (nodes26.map (fun p => p.1.toServingNodeState)) P' nodes26.length := by
      rw [hleafLine1_eq, ← hLen26]
      symm
      apply servingChainInputAt_eq_of_take_balls
      rw [List.map_take, List.map_take, hballs26]
    have h78 := alg4Lines7To8InstallCompletedJobs_dataWF pts' mode α L D_out
      nodes26 P' leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick
      hleafLine1_26 hleafTick_false h26_wf
    rcases h78_eq : alg4Lines7To8InstallCompletedJobs nodes26
        leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick with
      ⟨nodes78, leaf78, leafAns78, leafSq78, leafCh78, retired78⟩
    rw [h78_eq] at h78
    rcases h78 with ⟨hleaf78, hlch78, htag78, _⟩
    have h9 := alg4Line9StartDueJobsAndHandleLeaves_dataWF (D_out := D_out)
      hα_pos hα_le hL_pos P' nodes78 leaf78 leafAns78 leafSq78 leafCh78
      choices.leafRebuildChoices choices.terminalLeafHint hleaf78 hlch78 htag78
    rcases h9_eq : alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
        nodes78 leaf78 leafAns78 leafSq78 leafCh78
        choices.leafRebuildChoices choices.terminalLeafHint with
      ⟨nodes9, finalLeaf, finalLeafAns, finalLeafSq, retiredDue⟩
    rw [h9_eq] at h9
    rcases h9 with ⟨hfinalLeaf, hfinalExact, hfinalSq, htag9, _⟩
    rcases alg4Line10RefreshAffectedCaches_spec pts' mode nodes9 P'
        choices.baselineSamples choices.matchingMaxHints htag9 with
      ⟨hLen10, hballs10, hidx10⟩
    set finalNodes := alg4Line10RefreshAffectedCaches pts' mode P' nodes9
      choices.baselineSamples choices.matchingMaxHints
    set nextFallback := updateDistinctFallbackPair P' st.distinctFallbackPair choices.distinctPairHint
    have hfb := updateDistinctFallbackPair_spec P' st.distinctFallbackPair choices.distinctPairHint
    have hNodes_cand : ∀ sn ∈ finalNodes,
        (∀ u v, sn.baselinePair = some (u, v) →
          u ∈ P' ∧ v ∈ P' ∧ sn.baselineDistSq = euclideanDistSq (pts' u) (pts' v)) ∧
        (∀ u v, sn.maxMatchingPair = some (u, v) →
          u ∈ P' ∧ v ∈ P' ∧ sn.maxMatchingDistSq = euclideanDistSq (pts' u) (pts' v)) := by
      intro sn hsn
      rcases List.mem_iff_getElem.mp hsn with ⟨i, hi, rfl⟩
      have hi9 : i < nodes9.length := by omega
      have h10 := hidx10 i (nodes9[i]'hi9) (finalNodes[i]'hi)
        (List.getElem?_eq_getElem hi9) (List.getElem?_eq_getElem hi)
      have hsub : servingChainInputAt pts'
          (finalNodes.map Alg4ServingNode.toServingNodeState) P' i ⊆ P' :=
        servingChainInputAt_subset _ _ _ _
      rcases h10.2.2.2.2.2.2.2 with ⟨hb_act, hb_sq, hmax⟩
      refine ⟨?_, ?_⟩
      · intro u v huv
        rw [huv] at hb_act hb_sq
        exact ⟨hsub hb_act.1, hsub hb_act.2,
          hb_sq.trans (by simp [baselinePairLength, euclideanDistSq])⟩
      · intro u v huv
        rw [huv] at hmax
        exact ⟨hsub hmax.1, hsub hmax.2.1, hmax.2.2.2.1⟩
    have hLeaf_cand : ∀ u v, finalLeafAns = some (u, v) →
        u ∈ P' ∧ v ∈ P' ∧ finalLeafSq = euclideanDistSq (pts' u) (pts' v) := by
      intro u v huv
      have hsub_fl : finalLeaf ⊆ P' := by
        rw [hfinalLeaf]
        exact servingChainInputAt_subset _ _ _ _
      unfold IsExactLeafAnswer at hfinalExact
      by_cases hc : finalLeaf.card ≤ 1
      · rw [if_pos hc] at hfinalExact
        rw [hfinalExact] at huv; cases huv
      · rw [if_neg hc] at hfinalExact
        rcases hfinalExact with ⟨u', v', heq, hu', hv', _, _⟩
        rw [huv] at heq
        injection heq with hpair
        injection hpair with hu hv
        subst hu hv
        exact ⟨hsub_fl hu', hsub_fl hv',
          hfinalSq.trans (by rw [huv]; simp [baselinePairLength, euclideanDistSq])⟩
    have hans_spec := alg4Line12SelectCachedAnswer_spec pts' P' finalNodes
      finalLeafAns finalLeafSq nextFallback hNodes_cand hLeaf_cand hfb
    set ans := alg4Line12SelectCachedAnswer pts' P' finalNodes finalLeafAns finalLeafSq nextFallback
    have hl1_apply_eq :
        alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
          choices.servingRouteQueries choices.servingRadiusMaxHints =
          (nodesLine1, leafLine1, leafEv.isClockTick) := by
      have h := alg4Line1ApplyToServingChain_eq pts' mode st.servingNodes st.terminalLeaf upd
        choices.servingRouteQueries choices.servingRadiusMaxHints
      dsimp only [rootEv] at hl1_eq
      rw [hl1_eq] at h
      dsimp only at h
      exact h
    have hstep_unfold :
        let (nextState, outAns) := alg4Step mode α L reclaimMult st upd choices
        nextState.activeSet = P' ∧
        nextState.coords = pts' ∧
        nextState.servingNodes = finalNodes ∧
        nextState.terminalLeaf = finalLeaf ∧
        nextState.terminalLeafAnswer = finalLeafAns ∧
        nextState.cachedAnswer = outAns ∧
        outAns = ans := by
      unfold alg4Step
      dsimp only
      rw [hl1_apply_eq]
      dsimp only
      change (let r78 := alg4Lines7To8InstallCompletedJobs nodes26
                leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafEv.isClockTick
              _)
      rw [h78_eq]
      dsimp only
      change (let r9 := alg4Line9StartDueJobsAndHandleLeaves pts' mode α L P'
                nodes78 leaf78 leafAns78 leafSq78 leafCh78
                choices.leafRebuildChoices choices.terminalLeafHint
              _)
      rw [h9_eq]
      exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩
    rcases hstep : alg4Step mode α L reclaimMult st upd choices with ⟨nextState, outAns⟩
    rw [hstep] at hstep_unfold
    rcases hstep_unfold with ⟨hns_P, hns_pts, hns_nodes, hns_leaf, hns_lans, hns_cans, hout_eq⟩
    dsimp only
    refine ⟨hns_cans, ?_, ?_, ?_, ?_⟩
    · rw [hns_pts, hns_leaf, hns_lans]
      exact hfinalExact
    · intro idx
      have hi_fn : idx.val < finalNodes.length := by rw [← hns_nodes]; exact idx.isLt
      have hi9 : idx.val < nodes9.length := by omega
      have h10 := hidx10 idx.val (nodes9[idx.val]'hi9) (finalNodes[idx.val]'hi_fn)
        (List.getElem?_eq_getElem hi9) (List.getElem?_eq_getElem hi_fn)
      have hS_eq : ∀ k : ℕ, nextState.servingInputAt k =
          servingChainInputAt pts' (finalNodes.map Alg4ServingNode.toServingNodeState) P' k := by
        intro k
        unfold Alg4State.servingInputAt
        rw [hns_pts, hns_nodes, hns_P]
      have hnode_eq : nextState.servingNodes[idx] = finalNodes[idx.val]'hi_fn := by
        cases nextState; dsimp only at hns_nodes; subst hns_nodes; rfl
      show IsActiveNodePair (nextState.servingInputAt idx.val) (nextState.servingNodes[idx]).baselinePair ∧ _
      rw [hS_eq idx.val, hnode_eq]
      rcases h10.2.2.2.2.2.2.2 with ⟨hb_act, _, hmax⟩
      refine ⟨hb_act, ?_⟩
      intro x y hxy
      rw [hxy] at hmax
      exact ⟨hmax.1, hmax.2.1, hmax.2.2.1⟩
    · rw [hns_P, hns_pts, hout_eq]
      by_cases hc : P'.card ≤ 1
      · rw [if_pos hc] at hans_spec ⊢
        exact hans_spec
      · rw [if_neg hc] at hans_spec ⊢
        rcases hans_spec with ⟨u, v, ha1, hu, hv, hne, ha2⟩
        exact ⟨u, v, hu, hv, hne, Prod.ext ha1 ha2⟩
    · intro p hDel
      have hp_not_P' : p ∉ P' := hact.2.2 p hDel
      rw [hns_P, hout_eq]
      refine ⟨hp_not_P', ?_, ?_⟩
      · intro u v huv
        by_cases hc : P'.card ≤ 1
        · rw [if_pos hc] at hans_spec
          rw [hans_spec] at huv; cases huv
        · rw [if_neg hc] at hans_spec
          rcases hans_spec with ⟨u', v', ha1, hu', hv', _, _⟩
          rw [huv] at ha1
          injection ha1 with hp_eq
          injection hp_eq with hu hv
          subst hu hv
          exact ⟨fun h => hp_not_P' (h ▸ hu'), fun h => hp_not_P' (h ▸ hv')⟩
      · intro idx
        have hi_fn : idx.val < finalNodes.length := by rw [← hns_nodes]; exact idx.isLt
        have hnode_eq : nextState.servingNodes[idx] = finalNodes[idx.val]'hi_fn := by
          cases nextState; dsimp only at hns_nodes; subst hns_nodes; rfl
        rw [hnode_eq]
        have hcand := hNodes_cand (finalNodes[idx.val]'hi_fn) (List.getElem_mem _)
        refine ⟨?_, ?_⟩
        · intro u v huv
          rcases hcand.1 u v huv with ⟨hu, hv, _⟩
          exact ⟨fun h => hp_not_P' (h ▸ hu), fun h => hp_not_P' (h ▸ hv)⟩
        · intro u v huv
          rcases hcand.2 u v huv with ⟨hu, hv, _⟩
          exact ⟨fun h => hp_not_P' (h ▸ hu), fun h => hp_not_P' (h ▸ hv)⟩
  · -- Part 2.4
    intro hα_pos hα_le hL_pos pts' leaf₁ rebuildChoices hgt hle
    exact rebuildOversizedLeafAux_conj2 hα_pos hα_le hL_pos leaf₁ rebuildChoices hgt hle

end UL.Proof.claim_C_2_space_reclaim.RacerP44
