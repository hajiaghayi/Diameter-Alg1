import UL.Stmt.claim_C_2_space_reclaim
set_option autoImplicit false

namespace UL.Proof.claim_C_2_space_reclaim

open UL

/-! ### 1. Pinned constants and `IsBoundedByPoly2` polynomial witnesses -/

def cDepthVal : ℝ := 16
def cLeafVal : ℝ := 64
def cBatchVal : ℝ := 256
def cEndSpaceVal : ℝ := 128

noncomputable def mkDBound (P_α : ℕ → ℕ → ℝ) (d L : ℕ) : ℝ :=
  18 * max 1 (P_α d L) * ((L + 1 : ℕ) : ℝ)

noncomputable def mkPCard (P_α P_cfg P_int : ℕ → ℕ → ℝ) (d L : ℕ) : ℝ :=
  (2 + 2 * mkDBound P_α d L + 2 * (mkDBound P_α d L) ^ 2) +
    8 * max 1 (P_int d L) * (mkDBound P_α d L + (mkDBound P_α d L) ^ 2) * max 1 (P_cfg d L)

noncomputable def mkPSpaceTot (P_α P_cfg P_int : ℕ → ℕ → ℝ) (d L : ℕ) : ℝ :=
  3 * mkPCard P_α P_cfg P_int d L

theorem poly2_const (c : ℝ) (hc : 0 ≤ c) : IsBoundedByPoly2 (fun _ _ => c) :=
  ⟨c, 0, hc, fun _ _ => by simp⟩

theorem poly2_L_succ : IsBoundedByPoly2 (fun _ L => ((L + 1 : ℕ) : ℝ)) := by
  refine ⟨1, 1, by norm_num, fun d L => ?_⟩
  have hd : (1 : ℝ) ≤ (d + 1 : ℝ) := by exact_mod_cast Nat.succ_pos d
  have hL : (0 : ℝ) ≤ ((L + 1 : ℕ) : ℝ) := Nat.cast_nonneg _
  push_cast
  nlinarith

theorem poly2_max_one {f : ℕ → ℕ → ℝ} (hf : IsBoundedByPoly2 f) :
    IsBoundedByPoly2 (fun d L => max 1 (f d L)) := by
  rcases hf with ⟨C, deg, hC, hbound⟩
  refine ⟨C + 1, deg, by linarith, fun d L => ?_⟩
  have hd1 : (1 : ℝ) ≤ (d + 1 : ℝ) := by exact_mod_cast Nat.succ_pos d
  have hL1 : (1 : ℝ) ≤ (L + 1 : ℝ) := by exact_mod_cast Nat.succ_pos L
  have hpow_d : (1 : ℝ) ≤ (d + 1 : ℝ) ^ deg := one_le_pow₀ hd1
  have hpow_L : (1 : ℝ) ≤ (L + 1 : ℝ) ^ deg := one_le_pow₀ hL1
  have hprod1 : (1 : ℝ) ≤ ((d + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg) := by nlinarith
  apply max_le
  · nlinarith
  · have hfdL := hbound d L
    nlinarith

theorem poly2_add {f g : ℕ → ℕ → ℝ} (hf : IsBoundedByPoly2 f) (hg : IsBoundedByPoly2 g) :
    IsBoundedByPoly2 (fun d L => f d L + g d L) := by
  rcases hf with ⟨Cf, degf, hCf, hbf⟩
  rcases hg with ⟨Cg, degg, hCg, hbg⟩
  refine ⟨Cf + Cg, max degf degg, by linarith, fun d L => ?_⟩
  have hd1 : (1 : ℝ) ≤ (d + 1 : ℝ) := by exact_mod_cast Nat.succ_pos d
  have hL1 : (1 : ℝ) ≤ (L + 1 : ℝ) := by exact_mod_cast Nat.succ_pos L
  have hdf : (d + 1 : ℝ) ^ degf ≤ (d + 1 : ℝ) ^ (max degf degg) :=
    pow_le_pow_right₀ hd1 (le_max_left _ _)
  have hLf : (L + 1 : ℝ) ^ degf ≤ (L + 1 : ℝ) ^ (max degf degg) :=
    pow_le_pow_right₀ hL1 (le_max_left _ _)
  have hdg : (d + 1 : ℝ) ^ degg ≤ (d + 1 : ℝ) ^ (max degf degg) :=
    pow_le_pow_right₀ hd1 (le_max_right _ _)
  have hLg : (L + 1 : ℝ) ^ degg ≤ (L + 1 : ℝ) ^ (max degf degg) :=
    pow_le_pow_right₀ hL1 (le_max_right _ _)
  have h1 : f d L ≤ Cf * ((d + 1 : ℝ) ^ max degf degg) * ((L + 1 : ℝ) ^ max degf degg) := by
    have hmul : ((d + 1 : ℝ) ^ degf) * ((L + 1 : ℝ) ^ degf) ≤
        ((d + 1 : ℝ) ^ max degf degg) * ((L + 1 : ℝ) ^ max degf degg) :=
      mul_le_mul hdf hLf (by positivity) (by positivity)
    linarith [hbf d L, mul_le_mul_of_nonneg_left hmul hCf]
  have h2 : g d L ≤ Cg * ((d + 1 : ℝ) ^ max degf degg) * ((L + 1 : ℝ) ^ max degf degg) := by
    have hmul : ((d + 1 : ℝ) ^ degg) * ((L + 1 : ℝ) ^ degg) ≤
        ((d + 1 : ℝ) ^ max degf degg) * ((L + 1 : ℝ) ^ max degf degg) :=
      mul_le_mul hdg hLg (by positivity) (by positivity)
    linarith [hbg d L, mul_le_mul_of_nonneg_left hmul hCg]
  linarith

theorem poly2_mul {f g : ℕ → ℕ → ℝ}
    (hf0 : ∀ d L, 0 ≤ f d L) (hg0 : ∀ d L, 0 ≤ g d L)
    (hf : IsBoundedByPoly2 f) (hg : IsBoundedByPoly2 g) :
    IsBoundedByPoly2 (fun d L => f d L * g d L) := by
  rcases hf with ⟨Cf, degf, hCf, hbf⟩
  rcases hg with ⟨Cg, degg, hCg, hbg⟩
  refine ⟨Cf * Cg, degf + degg, mul_nonneg hCf hCg, fun d L => ?_⟩
  have hmul := mul_le_mul (hbf d L) (hbg d L) (hg0 d L) (by positivity)
  calc
    f d L * g d L
      ≤ (Cf * (d + 1 : ℝ) ^ degf * (L + 1 : ℝ) ^ degf) *
          (Cg * (d + 1 : ℝ) ^ degg * (L + 1 : ℝ) ^ degg) := hmul
    _ = (Cf * Cg) * ((d + 1 : ℝ) ^ degf * (d + 1 : ℝ) ^ degg) *
          ((L + 1 : ℝ) ^ degf * (L + 1 : ℝ) ^ degg) := by ring
    _ = (Cf * Cg) * ((d + 1 : ℝ) ^ (degf + degg)) * ((L + 1 : ℝ) ^ (degf + degg)) := by
          rw [← pow_add, ← pow_add]

theorem mkDBound_ge_eighteen (P_α : ℕ → ℕ → ℝ) (d L : ℕ) :
    18 ≤ mkDBound P_α d L := by
  unfold mkDBound
  have h1 : (1 : ℝ) ≤ max 1 (P_α d L) := le_max_left _ _
  have h2 : (1 : ℝ) ≤ ((L + 1 : ℕ) : ℝ) := by exact_mod_cast Nat.succ_pos L
  nlinarith

theorem mkDBound_poly2 {P_α : ℕ → ℕ → ℝ} (hP_α : IsBoundedByPoly2 P_α) :
    IsBoundedByPoly2 (mkDBound P_α) := by
  unfold mkDBound
  apply poly2_mul
  · intro d L
    have : (1 : ℝ) ≤ max 1 (P_α d L) := le_max_left _ _
    linarith
  · intro _ _; positivity
  · exact poly2_mul (fun _ _ => by norm_num) (fun _ _ => le_trans zero_le_one (le_max_left _ _))
      (poly2_const 18 (by norm_num)) (poly2_max_one hP_α)
  · exact poly2_L_succ

theorem mkPCard_one_le (P_α P_cfg P_int : ℕ → ℕ → ℝ) (d L : ℕ) :
    1 ≤ mkPCard P_α P_cfg P_int d L := by
  unfold mkPCard
  have hD : 0 ≤ mkDBound P_α d L := le_trans (by norm_num) (mkDBound_ge_eighteen P_α d L)
  have hI : (1 : ℝ) ≤ max 1 (P_int d L) := le_max_left _ _
  have hC : (1 : ℝ) ≤ max 1 (P_cfg d L) := le_max_left _ _
  have hprod : 0 ≤ 8 * max 1 (P_int d L) * (mkDBound P_α d L + (mkDBound P_α d L) ^ 2) *
      max 1 (P_cfg d L) := by positivity
  nlinarith

theorem mkPCard_poly2 {P_α P_cfg P_int : ℕ → ℕ → ℝ}
    (hP_α : IsBoundedByPoly2 P_α)
    (hP_cfg : IsBoundedByPoly2 P_cfg)
    (hP_int : IsBoundedByPoly2 P_int) :
    IsBoundedByPoly2 (mkPCard P_α P_cfg P_int) := by
  have hD := mkDBound_poly2 hP_α
  have hD0 : ∀ d L, 0 ≤ mkDBound P_α d L :=
    fun d L => le_trans (by norm_num) (mkDBound_ge_eighteen P_α d L)
  have hDsq : IsBoundedByPoly2 (fun d L => (mkDBound P_α d L) ^ 2) := by
    simpa [sq] using poly2_mul hD0 hD0 hD hD
  have hTerm1 : IsBoundedByPoly2 (fun d L =>
      2 + 2 * mkDBound P_α d L + 2 * (mkDBound P_α d L) ^ 2) :=
    poly2_add
      (poly2_add (poly2_const 2 (by norm_num))
        (poly2_mul (fun _ _ => by norm_num) hD0 (poly2_const 2 (by norm_num)) hD))
      (poly2_mul (fun _ _ => by norm_num) (fun _ _ => sq_nonneg _)
        (poly2_const 2 (by norm_num)) hDsq)
  have hI := poly2_max_one hP_int
  have hC := poly2_max_one hP_cfg
  have h8I : IsBoundedByPoly2 (fun d L => 8 * max 1 (P_int d L)) :=
    poly2_mul (fun _ _ => by norm_num) (fun _ _ => le_trans zero_le_one (le_max_left _ _))
      (poly2_const 8 (by norm_num)) hI
  have hDsum : IsBoundedByPoly2 (fun d L => mkDBound P_α d L + (mkDBound P_α d L) ^ 2) :=
    poly2_add hD hDsq
  have h8ID : IsBoundedByPoly2 (fun d L =>
      8 * max 1 (P_int d L) * (mkDBound P_α d L + (mkDBound P_α d L) ^ 2)) :=
    poly2_mul
      (fun d L => by have := le_max_left 1 (P_int d L); positivity)
      (fun d L => by have := hD0 d L; positivity)
      h8I hDsum
  have hTerm2 : IsBoundedByPoly2 (fun d L =>
      8 * max 1 (P_int d L) * (mkDBound P_α d L + (mkDBound P_α d L) ^ 2) * max 1 (P_cfg d L)) :=
    poly2_mul
      (fun d L => by
        have := le_max_left 1 (P_int d L)
        have := hD0 d L
        positivity)
      (fun _ _ => le_trans zero_le_one (le_max_left _ _))
      h8ID hC
  exact poly2_add hTerm1 hTerm2

theorem mkPSpaceTot_one_le (P_α P_cfg P_int : ℕ → ℕ → ℝ) (d L : ℕ) :
    1 ≤ mkPSpaceTot P_α P_cfg P_int d L := by
  unfold mkPSpaceTot
  linarith [mkPCard_one_le P_α P_cfg P_int d L]

theorem mkPSpaceTot_poly2 {P_α P_cfg P_int : ℕ → ℕ → ℝ}
    (hP_α : IsBoundedByPoly2 P_α)
    (hP_cfg : IsBoundedByPoly2 P_cfg)
    (hP_int : IsBoundedByPoly2 P_int) :
    IsBoundedByPoly2 (mkPSpaceTot P_α P_cfg P_int) := by
  unfold mkPSpaceTot
  exact poly2_mul (fun _ _ => by norm_num)
    (fun d L => le_trans zero_le_one (mkPCard_one_le P_α P_cfg P_int d L))
    (poly2_const 3 (by norm_num))
    (mkPCard_poly2 hP_α hP_cfg hP_int)

/-! ### 2. Conjunct (1): Power inequality and incremental record reclamation -/

theorem power_space_ineq_all (m n : ℕ) (σ : ℝ) (hmn : m ≤ n) (hσ : 0 ≤ σ) :
    (m : ℝ) ^ (1 + σ) ≤ (n : ℝ) ^ σ * (m : ℝ) := by
  rcases eq_or_ne m 0 with rfl | hm0
  · have h1σ : (1 : ℝ) + σ ≠ 0 := by linarith
    simp [Real.zero_rpow h1σ]
  · have hm_pos : (0 : ℝ) < (m : ℝ) := Nat.cast_pos.mpr (Nat.pos_of_ne_zero hm0)
    have hmn_real : (m : ℝ) ≤ (n : ℝ) := Nat.cast_le.mpr hmn
    rw [Real.rpow_add hm_pos, Real.rpow_one, mul_comm ((n : ℝ) ^ σ) (m : ℝ)]
    exact mul_le_mul_of_nonneg_left (Real.rpow_le_rpow hm_pos.le hmn_real hσ) hm_pos.le

theorem retiredChildrenHaveBoundedOutdegree_iff {ι : Type*} (D_out : ℕ) :
    ∀ cs : List (RetiredRecord ι),
      retiredChildrenHaveBoundedOutdegree D_out cs ↔ ∀ r ∈ cs, r.HasBoundedOutdegree D_out
  | [] => by simp [retiredChildrenHaveBoundedOutdegree]
  | c :: cs => by
      simp [retiredChildrenHaveBoundedOutdegree, retiredChildrenHaveBoundedOutdegree_iff D_out cs]

theorem retirementQueueRecordCount_append {ι : Type*} :
    ∀ q₁ q₂ : List (RetiredRecord ι),
      retirementQueueRecordCount (q₁ ++ q₂) =
        retirementQueueRecordCount q₁ + retirementQueueRecordCount q₂
  | [], q₂ => by simp [retirementQueueRecordCount]
  | r :: rs, q₂ => by
      simp [retirementQueueRecordCount, retirementQueueRecordCount_append rs q₂]
      omega

theorem reclaimOneRecord_spec (ι : Type) (D_out : ℕ) (q : List (RetiredRecord ι))
    (hq : ∀ r ∈ q, r.HasBoundedOutdegree D_out) :
    let (q', w) := reclaimOneRecord q
    (∀ r' ∈ q', r'.HasBoundedOutdegree D_out) ∧
    w ≤ 1 + D_out ∧
    (∀ ids children rest,
      q = .node ids children :: rest →
        q' = rest ++ children ∧
        w = 1 + children.length ∧
        retirementQueueRecordCount q' + 1 = retirementQueueRecordCount q) := by
  cases q with
  | nil =>
      dsimp only [reclaimOneRecord]
      refine ⟨?_, by omega, ?_⟩
      · intro r' hr'; cases hr'
      · intro _ _ _ h; cases h
  | cons hd rest =>
      rcases (⟨hd.retainedIds, hd.children, (RetiredRecord.node_eta hd).symm⟩ : ∃ ids children, hd = RetiredRecord.node ids children) with ⟨ids, children, rfl⟩
      simp only [reclaimOneRecord_node]
      have hhd : (RetiredRecord.node ids children).HasBoundedOutdegree D_out :=
        hq _ (by simp)
      rw [RetiredRecord.hasBoundedOutdegree_node] at hhd
      rcases hhd with ⟨hlen, hchild⟩
      have hchild_mem : ∀ r ∈ children, r.HasBoundedOutdegree D_out :=
        (retiredChildrenHaveBoundedOutdegree_iff D_out children).mp hchild
      refine ⟨?_, by omega, ?_⟩
      · intro r' hr'
        rcases List.mem_append.mp hr' with hrest | hch
        · exact hq r' (List.mem_cons_of_mem _ hrest)
        · exact hchild_mem r' hch
      · intro ids' children' rest' heq
        injection heq with hnode hrest_eq
        rcases RetiredRecord.node_inj.mp hnode with ⟨_, hch_eq⟩
        subst hrest_eq hch_eq
        refine ⟨rfl, rfl, ?_⟩
        simp only [retirementQueueRecordCount, RetiredRecord.totalRecords_node,
          retirementQueueRecordCount_append]
        omega

theorem performRetirementSteps_spec {ι : Type} (D_out : ℕ) :
    ∀ (k : ℕ) (q : List (RetiredRecord ι)),
      (∀ r ∈ q, r.HasBoundedOutdegree D_out) →
        (∀ r' ∈ (performRetirementSteps k q).1, r'.HasBoundedOutdegree D_out) ∧
        (performRetirementSteps k q).2 ≤ (1 + D_out) * k ∧
        retirementQueueRecordCount (performRetirementSteps k q).1 =
          retirementQueueRecordCount q - k
  | 0, q, hq => by
      simp only [performRetirementSteps, mul_zero, le_rfl, Nat.sub_zero]
      exact ⟨hq, trivial, trivial⟩
  | k + 1, [], _ => by
      simp [performRetirementSteps, retirementQueueRecordCount]
  | k + 1, hd :: rest, hq => by
      rcases (⟨hd.retainedIds, hd.children, (RetiredRecord.node_eta hd).symm⟩ : ∃ ids children, hd = RetiredRecord.node ids children) with ⟨ids, children, rfl⟩
      have h1 := reclaimOneRecord_spec ι D_out (.node ids children :: rest) hq
      rw [reclaimOneRecord_node] at h1
      rcases h1 with ⟨hq1, hw1, hnode1⟩
      rcases hnode1 ids children rest rfl with ⟨_, _, hcnt1⟩
      have h2 := performRetirementSteps_spec D_out k (rest ++ children) hq1
      rcases h2 with ⟨hq2, hw2, hcnt2⟩
      rw [performRetirementSteps_succ_node]
      dsimp only
      refine ⟨hq2, ?_, ?_⟩
      · calc
          (1 + children.length) + (performRetirementSteps k (rest ++ children)).2
            ≤ (1 + D_out) + (1 + D_out) * k := Nat.add_le_add hw1 hw2
          _ = (1 + D_out) * (k + 1) := by ring
      · omega

theorem alg4Line11PerformRetirementWork_spec
    (ι : Type) (D_out reclaimMult stepAlloc : ℕ)
    (prevQueue newRetired : List (RetiredRecord ι))
    (hprev : ∀ r ∈ prevQueue, r.HasBoundedOutdegree D_out)
    (hnew : ∀ r ∈ newRetired, r.HasBoundedOutdegree D_out) :
    let (nextQueue, work) :=
      alg4Line11PerformRetirementWork reclaimMult stepAlloc prevQueue newRetired
    (∀ r ∈ nextQueue, r.HasBoundedOutdegree D_out) ∧
    work ≤ (1 + D_out) * reclaimMult * max 1 stepAlloc ∧
    retirementQueueRecordCount nextQueue =
      retirementQueueRecordCount prevQueue + retirementQueueRecordCount newRetired -
        reclaimMult * max 1 stepAlloc := by
  have hall : ∀ r ∈ prevQueue ++ newRetired, r.HasBoundedOutdegree D_out := by
    intro r hr
    rcases List.mem_append.mp hr with hp | hn
    · exact hprev r hp
    · exact hnew r hn
  have h := performRetirementSteps_spec D_out (reclaimMult * max 1 stepAlloc)
    (prevQueue ++ newRetired) hall
  rcases h with ⟨hq', hw', hcnt'⟩
  rcases hres : alg4Line11PerformRetirementWork reclaimMult stepAlloc prevQueue newRetired with
    ⟨nextQueue, work⟩
  have hdef : (nextQueue, work) =
      performRetirementSteps (reclaimMult * max 1 stepAlloc) (prevQueue ++ newRetired) := by
    rw [← hres]
    rfl
  have hfst : nextQueue =
      (performRetirementSteps (reclaimMult * max 1 stepAlloc) (prevQueue ++ newRetired)).1 :=
    congrArg Prod.fst hdef
  have hsnd : work =
      (performRetirementSteps (reclaimMult * max 1 stepAlloc) (prevQueue ++ newRetired)).2 :=
    congrArg Prod.snd hdef
  dsimp only
  rw [hfst, hsnd]
  refine ⟨hq', ?_, ?_⟩
  · simpa [Nat.mul_assoc] using hw'
  · rw [hcnt', retirementQueueRecordCount_append]

theorem retirement_trajectory_bound
    (ι : Type) (D_out reclaimMult B_live B_alloc T : ℕ)
    (liveRecs : Fin (T + 1) → ℕ)
    (allocRecs : Fin T → ℕ)
    (newRetired : Fin T → List (RetiredRecord ι))
    (queue : Fin (T + 1) → List (RetiredRecord ι))
    (hmult : 1 ≤ reclaimMult)
    (hq0 : queue 0 = [])
    (hlive : ∀ s : Fin (T + 1), liveRecs s ≤ B_live)
    (hstep : ∀ t : Fin T,
      allocRecs t ≤ B_alloc ∧
      (∀ r ∈ newRetired t, r.HasBoundedOutdegree D_out) ∧
      liveRecs t.succ + retirementQueueRecordCount (newRetired t) ≤
        liveRecs t.castSucc + allocRecs t ∧
      queue t.succ =
        (alg4Line11PerformRetirementWork reclaimMult (allocRecs t)
          (queue t.castSucc) (newRetired t)).1) :
    (∀ s : Fin (T + 1),
      (∀ r ∈ queue s, r.HasBoundedOutdegree D_out) ∧
      retirementQueueRecordCount (queue s) + liveRecs s ≤ B_live) ∧
    (∀ t : Fin T,
      retirementQueueRecordCount (queue t.castSucc ++ newRetired t) + liveRecs t.succ ≤
        B_live + B_alloc) := by
  have hmain : ∀ s : Fin (T + 1),
      (∀ r ∈ queue s, r.HasBoundedOutdegree D_out) ∧
      retirementQueueRecordCount (queue s) + liveRecs s ≤ B_live := by
    rintro ⟨k, hk⟩
    induction k with
    | zero =>
        have hs0 : (⟨0, hk⟩ : Fin (T + 1)) = 0 := rfl
        rw [hs0, hq0]
        refine ⟨?_, ?_⟩
        · intro r hr; cases hr
        · simpa [retirementQueueRecordCount] using hlive 0
    | succ k ih =>
        have hk_lt : k < T := Nat.lt_of_succ_lt_succ hk
        let t : Fin T := ⟨k, hk_lt⟩
        have hcs : t.castSucc = ⟨k, Nat.lt_succ_of_lt hk_lt⟩ := rfl
        have hsc : t.succ = ⟨k + 1, hk⟩ := rfl
        rcases ih (Nat.lt_succ_of_lt hk_lt) with ⟨hq_k, hsum_k⟩
        rw [← hcs] at hq_k hsum_k
        rcases hstep t with ⟨_, hnew_t, hbal_t, hq_next⟩
        have hall : ∀ r ∈ queue t.castSucc ++ newRetired t, r.HasBoundedOutdegree D_out := by
          intro r hr
          rcases List.mem_append.mp hr with hp | hn
          · exact hq_k r hp
          · exact hnew_t r hn
        have hps := performRetirementSteps_spec D_out (reclaimMult * max 1 (allocRecs t))
          (queue t.castSucc ++ newRetired t) hall
        rcases hps with ⟨hq_out, _, hcnt_out⟩
        rw [retirementQueueRecordCount_append] at hcnt_out
        change queue t.succ =
          (performRetirementSteps (reclaimMult * max 1 (allocRecs t))
            (queue t.castSucc ++ newRetired t)).1 at hq_next
        rw [← hsc, hq_next]
        refine ⟨hq_out, ?_⟩
        have hbud_ge : allocRecs t ≤ reclaimMult * max 1 (allocRecs t) := by
          calc
            allocRecs t = 1 * allocRecs t := (Nat.one_mul _).symm
            _ ≤ reclaimMult * max 1 (allocRecs t) :=
                Nat.mul_le_mul hmult (Nat.le_max_right 1 (allocRecs t))
        have hlive_succ := hlive t.succ
        rw [hcnt_out]
        omega
  refine ⟨hmain, ?_⟩
  intro t
  have hsum_cs := (hmain t.castSucc).2
  rcases hstep t with ⟨halloc_t, _, hbal_t, _⟩
  rw [retirementQueueRecordCount_append]
  omega

end UL.Proof.claim_C_2_space_reclaim
