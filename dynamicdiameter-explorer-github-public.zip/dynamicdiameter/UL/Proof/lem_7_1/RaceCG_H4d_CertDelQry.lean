import Mathlib
import UL.Stmt.lem_7_1
import UL.Proof.lem_7_1.RaceV31_H1_Coins
import UL.Proof.lem_7_1.RaceV31_H2_Dyadic
import UL.Proof.lem_7_1.RaceV31_H4a_Pot
import UL.Proof.lem_7_1.RaceV31_H4b_CertStep
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. Combinatorial & List Helpers for Certified `.delete` and `.query` -/

theorem injOn_of_card_image_eq_cg {α β : Type} [DecidableEq α] [DecidableEq β]
    {A : Finset α} {f : α → β} (hcard : (A.image f).card = A.card)
    {x y : α} (hx : x ∈ A) (hy : y ∈ A) (hfx : f x = f y) : x = y := by
  by_contra hne
  let A' := A.erase x
  have hy' : y ∈ A' := Finset.mem_erase.mpr ⟨Ne.symm hne, hy⟩
  have hfx_mem : f x ∈ A'.image f := Finset.mem_image.mpr ⟨y, hy', hfx.symm⟩
  have himg_eq : A.image f = A'.image f := by
    have h1 : A = insert x A' := (Finset.insert_erase hx).symm
    conv_lhs => rw [h1, Finset.image_insert]
    exact Finset.insert_eq_of_mem hfx_mem
  have hle1 : (A'.image f).card ≤ A'.card := Finset.card_image_le
  have hpos : 1 ≤ A.card := Finset.card_pos.mpr ⟨x, hx⟩
  have herase : A'.card = A.card - 1 := Finset.card_erase_of_mem hx
  have hce : (A.image f).card = (A'.image f).card := congrArg Finset.card himg_eq
  omega

theorem table_space_le_of_slots_cg {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n M_slots : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hn : 2 ≤ n) (hσ : 0 ≤ σ) (hfacs : facs.Valid)
    {tbl : UL.HostedCertTable ι d_s B P}
    (hact : tbl.activeLifetimes.card ≤ n)
    (hlen : tbl.slots.length ≤ M_slots)
    (hslots : ∀ sl ∈ tbl.slots, CertSlotInv n pts h σ facs mkCert sl) :
    (tbl.currentSpace : ℝ) ≤ (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ := by
  unfold UL.HostedCertTable.currentSpace
  rw [Nat.cast_add]
  have hn_le_sp : (n : ℝ) ≤ facs.spaceBound n σ := by
    unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
    have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
    have hrpow : (n : ℝ) ^ (1 : ℝ) ≤ (n : ℝ) ^ (1 + σ) :=
      Real.rpow_le_rpow_of_exponent_le hn1 (by linarith)
    rw [Real.rpow_one] at hrpow
    have hPs : 1 ≤ facs.P_space := hfacs.2.1
    nlinarith [Real.rpow_nonneg (by positivity : (0 : ℝ) ≤ n) (1 + σ)]
  have hact_le : (tbl.activeLifetimes.card : ℝ) ≤ facs.spaceBound n σ :=
    (by exact_mod_cast hact : (tbl.activeLifetimes.card : ℝ) ≤ n).trans hn_le_sp
  have hsum_le : ∀ l : List (UL.HostedCertSlot ι d_s B P),
      (∀ sl ∈ l, (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ) →
      (((l.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
        (l.length : ℝ) * (2 * facs.spaceBound n σ) := by
    intro l
    induction l with
    | nil => intro _; simp
    | cons sl tl ih =>
      intro hall
      have h1 : (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := hall sl List.mem_cons_self
      have h2 : (((tl.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
          (tl.length : ℝ) * (2 * facs.spaceBound n σ) :=
        ih fun x hx => hall x (List.mem_cons_of_mem sl hx)
      calc
        ((((sl :: tl).map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ)
            = (sl.spaceAlloc : ℝ) + (((tl.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) := by
              simp [List.map_cons, List.sum_cons, Nat.cast_add]
        _ ≤ 2 * facs.spaceBound n σ + (tl.length : ℝ) * (2 * facs.spaceBound n σ) :=
              add_le_add h1 h2
        _ = ((sl :: tl).length : ℝ) * (2 * facs.spaceBound n σ) := by
              simp [List.length_cons, Nat.cast_add]
              ring
  have hslots_sp := hsum_le tbl.slots (fun sl hsl => (hslots sl hsl).2.2.2.2.2.1)
  have hlen_le : (tbl.slots.length : ℝ) ≤ (M_slots : ℝ) := by exact_mod_cast hlen
  have hsp_nn : 0 ≤ facs.spaceBound n σ := by linarith [spaceBound_ge_one hn hσ hfacs]
  have hslots_sp2 :
      (((tbl.slots.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
        (M_slots : ℝ) * (2 * facs.spaceBound n σ) :=
    hslots_sp.trans (mul_le_mul_of_nonneg_right hlen_le (by linarith))
  linarith

theorem binSlice_erase_eq_cg {ι : Type} [DecidableEq ι]
    (A : Finset (ι × ℕ)) (rec₀ : ι × ℕ) (H k : ℕ) :
    (binSlice A H k).erase rec₀ = binSlice (A.erase rec₀) H k := by
  ext p
  simp only [binSlice, Finset.mem_erase, Finset.mem_filter]
  tauto

theorem slotPot_replace_split_cg {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (tbl : UL.HostedCertTable ι d_s B P)
    (hnd : (tbl.slots.map UL.HostedCertSlot.slotId).Nodup)
    {sl : UL.HostedCertSlot ι d_s B P} (hsl : sl ∈ tbl.slots) :
    ∃ restPot : ENNReal,
      slotPot mkCert tbl =
        restPot + remCopyWork (mkCert sl.gen) sl.bState sl.surviving sl.phase ∧
      ∀ sl' : UL.HostedCertSlot ι d_s B P,
        slotPot mkCert
          { tbl with slots := tbl.slots.map (fun s => if s.slotId = sl.slotId then sl' else s) } =
          restPot + remCopyWork (mkCert sl'.gen) sl'.bState sl'.surviving sl'.phase := by
  unfold slotPot
  have haux : ∀ l : List (UL.HostedCertSlot ι d_s B P),
      (l.map UL.HostedCertSlot.slotId).Nodup → sl ∈ l →
      ∃ restPot : ENNReal,
        (l.map (fun s => remCopyWork (mkCert s.gen) s.bState s.surviving s.phase)).sum =
          restPot + remCopyWork (mkCert sl.gen) sl.bState sl.surviving sl.phase ∧
        ∀ sl' : UL.HostedCertSlot ι d_s B P,
          ((l.map (fun s => if s.slotId = sl.slotId then sl' else s)).map
            (fun s => remCopyWork (mkCert s.gen) s.bState s.surviving s.phase)).sum =
            restPot + remCopyWork (mkCert sl'.gen) sl'.bState sl'.surviving sl'.phase := by
    intro l
    induction l with
    | nil => intro _ hm; simp at hm
    | cons hd tl ih =>
      rw [List.map_cons, List.nodup_cons]
      rintro ⟨hhd_not, hnd_tl⟩ hm
      rcases List.mem_cons.mp hm with heq_sl | htl
      · subst heq_sl
        refine ⟨(tl.map (fun s => remCopyWork (mkCert s.gen) s.bState s.surviving s.phase)).sum, ?_, ?_⟩
        · simp [add_comm]
        · intro sl'
          have htl_id : tl.map (fun s => if s.slotId = sl.slotId then sl' else s) = tl := by
            have hc : tl.map (fun s => if s.slotId = sl.slotId then sl' else s) = tl.map id := by
              refine List.map_congr_left fun s hs => ?_
              have hne : s.slotId ≠ sl.slotId := fun heq =>
                hhd_not (heq ▸ List.mem_map_of_mem hs)
              simp [hne]
            simpa using hc
          simp only [List.map_cons, ↓reduceIte, htl_id, List.sum_cons, add_comm]
      · have hne_hd : hd.slotId ≠ sl.slotId := fun heq =>
          hhd_not (heq ▸ List.mem_map_of_mem htl)
        rcases ih hnd_tl htl with ⟨rPot, hr1, hr2⟩
        refine ⟨remCopyWork (mkCert hd.gen) hd.bState hd.surviving hd.phase + rPot, ?_, ?_⟩
        · simp only [List.map_cons, List.sum_cons, hr1, add_assoc]
        · intro sl'
          simp only [List.map_cons, if_neg hne_hd, List.sum_cons, hr2 sl', add_assoc]
  exact haux tbl.slots hnd hsl

/-! ### 2. Certified `.delete` Queue Execution & `certStep_delete_spec` -/

def CertDelRel {ι : Type} [DecidableEq ι] {d_s : ℕ} {B P : Type}
    (rec₀ : ι × ℕ) (pairs : List (ℕ × (ι × ℕ)))
    (sl₀ sl : UL.HostedCertSlot ι d_s B P) : Prop :=
  sl.slotId = sl₀.slotId ∧
  sl.gen = sl₀.gen ∧
  sl.bState = sl₀.bState ∧
  if sl.slotId ∈ pairs.map Prod.fst then
    sl.surviving = sl₀.surviving ∧ rec₀ ∈ sl.surviving
  else
    sl.surviving = sl₀.surviving.erase rec₀

theorem forall₂_certDelRel_nil_props {ι : Type} [DecidableEq ι] {d_s : ℕ} {B P : Type}
    {rec₀ : ι × ℕ} {l₀ l : List (UL.HostedCertSlot ι d_s B P)}
    (hrel : List.Forall₂ (CertDelRel rec₀ []) l₀ l) :
    l.map UL.HostedCertSlot.slotId = l₀.map UL.HostedCertSlot.slotId ∧
    (∀ sid : ℕ,
      (l.find? (fun s => s.slotId = sid)).map UL.HostedCertSlot.bState =
        (l₀.find? (fun s => s.slotId = sid)).map UL.HostedCertSlot.bState) ∧
    (∀ sl ∈ l, ∃ sl₀ ∈ l₀,
      sl.slotId = sl₀.slotId ∧ sl.gen = sl₀.gen ∧ sl.bState = sl₀.bState ∧
      sl.surviving = sl₀.surviving.erase rec₀) := by
  induction hrel with
  | nil => simp
  | @cons s₀ s tl₀ tl hh _ ih =>
    rcases hh with ⟨hid, hgen, hb, hsurv⟩
    simp only [List.map_nil, List.not_mem_nil, ↓reduceIte] at hsurv
    rcases ih with ⟨hmap, hfind, hmem⟩
    refine ⟨by simp [hid, hmap], ?_, ?_⟩
    · intro sid
      by_cases heq : s₀.slotId = sid
      · simp [List.find?_cons, hid, heq, hb]
      · simp [List.find?_cons, hid, heq, hfind sid]
    · intro x hx
      rcases List.mem_cons.mp hx with rfl | hxtl
      · exact ⟨s₀, List.mem_cons_self, hid, hgen, hb, hsurv⟩
      · rcases hmem x hxtl with ⟨y₀, hy₀, hp⟩
        exact ⟨y₀, List.mem_cons_of_mem s₀ hy₀, hp⟩

theorem badGroupCount_eq_of_certDelRel_nil {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (N : Finset (EuclideanSpace ℝ (Fin d_s))) (cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (groups : List (CertGroupMeta ι d_s))
    {rec₀ : ι × ℕ} {tbl₀ tbl : UL.HostedCertTable ι d_s B P}
    (hrel : List.Forall₂ (CertDelRel rec₀ []) tbl₀.slots tbl.slots) :
    badGroupCount N cap mkCert groups tbl = badGroupCount N cap mkCert groups tbl₀ := by
  rcases forall₂_certDelRel_nil_props hrel with ⟨_, hfind, _⟩
  have hgs : ∀ sids : List ℕ,
      (groupSlots tbl sids).map UL.HostedCertSlot.bState =
        (groupSlots tbl₀ sids).map UL.HostedCertSlot.bState := by
    intro sids
    unfold groupSlots
    induction sids with
    | nil => rfl
    | cons sid tl ih =>
      have hf := hfind sid
      cases h1 : tbl.slots.find? (fun s => s.slotId = sid) <;>
        cases h2 : tbl₀.slots.find? (fun s => s.slotId = sid) <;>
        simp [h1, h2] at hf ⊢
      · exact ih
      · simp [hf, ih]
  unfold badGroupCount
  congr 1
  refine List.filter_congr fun g _ => ?_
  rw [hgs g.sids]

open Classical in
theorem runCertDelFinish_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n M_slots R cap : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound : ℝ}
    (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    (extHist : UL.ExecutionHistory d)
    (id₀ : ι) (rec₀ : ι × ℕ)
    (groups : List (CertGroupMeta ι d_s))
    (slots₀ : List (UL.HostedCertSlot ι d_s B P)) :
    ∀ (pairs : List (ℕ × (ι × ℕ))) (restFuel : ℕ)
      (tbl : UL.HostedCertTable ι d_s B P) (accW peakSp : ℕ),
      rec₀ ∉ tbl.activeLifetimes →
      tbl.activeLifetimes.card ≤ n →
      tbl.slots.length ≤ M_slots →
      tbl.currentSpace ≤ peakSp →
      (peakSp : ℝ) ≤ (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ →
      (pairs.map Prod.fst).Nodup →
      (∀ pair ∈ pairs, pair.2 = rec₀ ∧ pair.1 ∈ tbl.slots.map UL.HostedCertSlot.slotId) →
      (tbl.slots.map UL.HostedCertSlot.slotId).Nodup →
      (∀ sl ∈ tbl.slots, sl.slotId < tbl.nextSlotId) →
      (∀ sl ∈ tbl.slots, CertSlotInv n pts h σ facs mkCert sl) →
      List.Forall₂ (CertDelRel rec₀ pairs) slots₀ tbl.slots →
      let f_run := fun bs =>
        UL.runCertHostedStepFuel n pts h mkCert
          (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
          extHist (.delete id₀) (pairs.length + 1 + restFuel)
          { groups := groups,
            queue := some ((pairs.map fun pair => PlannedCertCmd.deleteCertSlot pair.1 pair.2) ++
              [PlannedCertCmd.finishCertUpdate]) }
          tbl bs accW peakSp
      haltProb f_run = 1 ∧
      (∀ bs out, f_run bs = some out →
        out.nextState.1 = { groups := groups, queue := none } ∧
        out.queryAnswer = none ∧
        out.nextState.2.activeLifetimes = tbl.activeLifetimes ∧
        out.nextState.2.nextLifetime = tbl.nextLifetime ∧
        (out.nextState.2.slots.map UL.HostedCertSlot.slotId).Nodup ∧
        (∀ sl ∈ out.nextState.2.slots, sl.slotId < out.nextState.2.nextSlotId) ∧
        (∀ sl ∈ out.nextState.2.slots, CertSlotInv n pts h σ facs mkCert sl) ∧
        List.Forall₂ (CertDelRel rec₀ []) slots₀ out.nextState.2.slots ∧
        (out.peakSpace : ℝ) ≤ (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ) ∧
      expWithBits f_run (fun out => (out.work : ENNReal) + slotPot mkCert out.nextState.2) ≤
        ((accW + pairs.length + 1 : ℕ) : ENNReal) + slotPot mkCert tbl := by
  intro pairs
  induction pairs with
  | nil =>
    intro restFuel tbl accW peakSp _ _ _ hsp_le hpeak_real _ _ hsl_nd hsl_lt hsl_inv hrel
    dsimp only []
    have hval : ValidCertTable n h mkCert tbl := by
      intro sl hsl
      rcases hsl_inv sl hsl with ⟨_, hgm, hgh, _, hsub, _, hacc⟩
      exact ⟨hgm, hgh, hsub, hacc⟩
    have hfuel : ([] : List (ℕ × (ι × ℕ))).length + 1 + restFuel = restFuel + 1 := by simp; omega
    let out₀ : UL.DynamicSearchStepOutcome (CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P) ι :=
      { nextState := ({ groups := groups, queue := none }, tbl)
        queryAnswer := none
        work := accW + 1
        peakSpace := max peakSp tbl.currentSpace }
    have hfeq :
        (fun bs =>
          UL.runCertHostedStepFuel n pts h mkCert
            (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
            extHist (.delete id₀) (([] : List (ℕ × (ι × ℕ))).length + 1 + restFuel)
            { groups := groups,
              queue := some ((([] : List (ℕ × (ι × ℕ))).map fun pair =>
                PlannedCertCmd.deleteCertSlot pair.1 pair.2) ++
                [PlannedCertCmd.finishCertUpdate]) }
            tbl bs accW peakSp) = endWithEmpty out₀ := by
      simp only [List.map_nil, List.nil_append]
      rw [hfuel]
      exact runCertFinishUpdate_eq n pts h h_pos h_lt_one R cap mkCert extHist (.delete id₀)
        trivial restFuel groups tbl accW peakSp hval
    refine ⟨by rw [hfeq]; exact haltProb_endWithEmpty out₀, ?_, ?_⟩
    · intro bs out hout
      have hout' : endWithEmpty out₀ bs = some out := congrFun hfeq bs ▸ hout
      rcases endWithEmpty_eq_some_iff.mp hout' with ⟨_, rfl⟩
      have hmax : max peakSp tbl.currentSpace = peakSp := max_eq_left hsp_le
      refine ⟨rfl, rfl, rfl, rfl, hsl_nd, hsl_lt, hsl_inv, hrel, ?_⟩
      dsimp only [out₀]
      rw [hmax]
      exact hpeak_real
    · rw [hfeq, expWithBits_endWithEmpty]
      simp [out₀]
  | cons hd rest ih =>
    rcases hd with ⟨sid, r_hd⟩
    intro restFuel tbl accW peakSp hrec_not hact_le hlen_M hsp_le hpeak_real
      hpairs_nd hpairs_mem hsl_nd hsl_lt hsl_inv hrel
    dsimp only []
    have hval : ValidCertTable n h mkCert tbl := by
      intro sl hsl
      rcases hsl_inv sl hsl with ⟨_, hgm, hgh, _, hsub, _, hacc⟩
      exact ⟨hgm, hgh, hsub, hacc⟩
    rw [List.map_cons, List.nodup_cons] at hpairs_nd
    rcases hpairs_nd with ⟨hsid_not_rest, hrest_nd⟩
    rcases hpairs_mem (sid, r_hd) List.mem_cons_self with ⟨hr_eq, hsid_in⟩
    dsimp only [] at hr_eq
    subst r_hd
    rcases List.mem_map.mp hsid_in with ⟨sl, hsl_mem, hsl_id_eq⟩
    have hfind : tbl.slots.find? (fun s => s.slotId = sid) = some sl := by
      have hf := list_find?_eq_some_of_mem_nodup tbl.slots UL.HostedCertSlot.slotId hsl_nd hsl_mem
      rwa [hsl_id_eq] at hf
    have hrec_in_sl : rec₀ ∈ sl.surviving := by
      have haux : ∀ l₀ l, List.Forall₂ (CertDelRel rec₀ ((sid, rec₀) :: rest)) l₀ l →
          sl ∈ l → rec₀ ∈ sl.surviving := by
        intro l₀ l hr hsl_l
        induction hr with
        | nil => simp at hsl_l
        | @cons s₀ s _ _ hh _ ihr =>
          rcases List.mem_cons.mp hsl_l with rfl | htl
          · have hmem_p : sl.slotId ∈ ((sid, rec₀) :: rest).map Prod.fst := by simp [hsl_id_eq]
            have hs_rel := hh.2.2.2
            simp only [hmem_p, ↓reduceIte] at hs_rel
            exact hs_rel.2
          · exact ihr htl
      exact haux slots₀ tbl.slots hrel hsl_mem
    rcases hsl_inv sl hsl_mem with
      ⟨hsl_m1, hsl_mn, hsl_gh, hsl_pts, hsl_sub, hsl_sp, birthHist, hsl_accB, hsl_accP⟩
    rcases hCert sl.gen hsl_mn hsl_gh with ⟨hmk_gen, _, hcert_all⟩
    have hcert_hist := hcert_all birthHist
    have hsurv_inst : (mkCert sl.gen).gen.IsSurvivingSubset sl.surviving := by
      unfold UL.SearchGeneration.IsSurvivingSubset
      rwa [hmk_gen]
    rcases hcert_hist.2.2.2.2.2.2.2.1 extHist sl.bState sl.surviving sl.phase rec₀
        hsl_accB hsurv_inst hsl_accP hrec_in_sl with
      ⟨hpf_del_raw, hhalt_del_raw, hd_caps⟩
    let f_del := (mkCert sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.phase rec₀
    have hpf_del : IsPrefixFree f_del := hpf_del_raw
    have hhalt_del : haltProb f_del = 1 := hhalt_del_raw
    let mkSl' := fun (dOut : UL.CertifiedDeleteOutcome P) =>
      ({ sl with
         surviving := sl.surviving.erase rec₀
         phase := dOut.nextPhase
         spaceAlloc := max sl.spaceAlloc dOut.peakSpace } : UL.HostedCertSlot ι d_s B P)
    let mkTbl' := fun (dOut : UL.CertifiedDeleteOutcome P) =>
      ({ tbl with
         slots := tbl.slots.map (fun s => if s.slotId = sid then mkSl' dOut else s) } :
        UL.HostedCertTable ι d_s B P)
    let remCmds : List (PlannedCertCmd ι d_s) :=
      (rest.map fun pair => PlannedCertCmd.deleteCertSlot pair.1 pair.2) ++
      [PlannedCertCmd.finishCertUpdate]
    let g_cont := fun (dOut : UL.CertifiedDeleteOutcome P) (rem' : List Bool) =>
      UL.runCertHostedStepFuel n pts h mkCert
        (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
        extHist (.delete id₀) (rest.length + 1 + restFuel)
        { groups := groups, queue := some remCmds }
        (mkTbl' dOut) rem' (accW + dOut.work + 1) (max peakSp (mkTbl' dOut).currentSpace)
    have hfuel : ((sid, rec₀) :: rest).length + 1 + restFuel = (rest.length + 1 + restFuel) + 1 := by
      simp only [List.length_cons]
      omega
    have hfeq :
        (fun bs =>
          UL.runCertHostedStepFuel n pts h mkCert
            (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
            extHist (.delete id₀) (((sid, rec₀) :: rest).length + 1 + restFuel)
            { groups := groups,
              queue := some ((((sid, rec₀) :: rest).map fun pair =>
                PlannedCertCmd.deleteCertSlot pair.1 pair.2) ++
                [PlannedCertCmd.finishCertUpdate]) }
            tbl bs accW peakSp) = seqConsume f_del g_cont := by
      funext bs
      rw [hfuel]
      conv_lhs => unfold UL.runCertHostedStepFuel
      have hcond : rec₀ ∈ sl.surviving ∧ rec₀ ∉ tbl.activeLifetimes := ⟨hrec_in_sl, hrec_not⟩
      simp only [certStepCtrl, if_pos hval, List.map_cons, List.cons_append, dispatchCertQueue,
        hfind, if_pos hcond, seqConsume]
      cases UL.consumePrefixBits f_del bs <;> rfl
    have hstep_dOut : ∀ bs₁ dOut, f_del bs₁ = some dOut →
        (mkTbl' dOut).slots.length ≤ M_slots ∧
        ((mkTbl' dOut).slots.map UL.HostedCertSlot.slotId).Nodup ∧
        (∀ s ∈ (mkTbl' dOut).slots, s.slotId < (mkTbl' dOut).nextSlotId) ∧
        (∀ s ∈ (mkTbl' dOut).slots, CertSlotInv n pts h σ facs mkCert s) ∧
        List.Forall₂ (CertDelRel rec₀ rest) slots₀ (mkTbl' dOut).slots ∧
        ((max peakSp (mkTbl' dOut).currentSpace : ℕ) : ℝ) ≤
          (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ ∧
        (∀ pair ∈ rest, pair.2 = rec₀ ∧ pair.1 ∈ (mkTbl' dOut).slots.map UL.HostedCertSlot.slotId) := by
      intro bs₁ dOut hd₁
      rcases hd_caps bs₁ dOut hd₁ with ⟨hph', hsp_dOut⟩
      have hmap_id : (mkTbl' dOut).slots.map UL.HostedCertSlot.slotId =
          tbl.slots.map UL.HostedCertSlot.slotId := by
        dsimp only [mkTbl']
        rw [List.map_map]
        refine List.map_congr_left fun s _ => ?_
        by_cases heq : s.slotId = sid
        · simp [heq, mkSl', hsl_id_eq]
        · simp [heq]
      have hsl_inv' : CertSlotInv n pts h σ facs mkCert (mkSl' dOut) := by
        refine ⟨hsl_m1, hsl_mn, hsl_gh, hsl_pts, (Finset.erase_subset _ _).trans hsl_sub, ?_,
          birthHist, hsl_accB, hph'⟩
        have hsp_m : (dOut.peakSpace : ℝ) ≤ facs.spaceBound sl.gen.m σ := by
          have hmk_m : (mkCert sl.gen).gen.m = sl.gen.m := congrArg UL.SearchGeneration.m hmk_gen
          rwa [hmk_m] at hsp_dOut
        have hsp_n : facs.spaceBound sl.gen.m σ ≤ facs.spaceBound n σ :=
          spaceBound_mono_le hsl_mn hσθ.2.1 hfacs
        have hsp_nn : 0 ≤ facs.spaceBound n σ := by
          linarith [spaceBound_ge_one hσθ.1 hσθ.2.1 hfacs]
        have hsp2 : (dOut.peakSpace : ℝ) ≤ 2 * facs.spaceBound n σ := by linarith
        dsimp only [mkSl']
        rw [Nat.cast_max]
        exact max_le hsl_sp hsp2
      have hall_inv' : ∀ s ∈ (mkTbl' dOut).slots, CertSlotInv n pts h σ facs mkCert s := by
        intro s hs
        rcases List.mem_map.mp hs with ⟨s₀, hs₀, rfl⟩
        by_cases heq : s₀.slotId = sid
        · simp [heq, hsl_inv']
        · simp [heq, hsl_inv s₀ hs₀]
      have hall_lt' : ∀ s ∈ (mkTbl' dOut).slots, s.slotId < (mkTbl' dOut).nextSlotId := by
        intro s hs
        rcases List.mem_map.mp hs with ⟨s₀, hs₀, rfl⟩
        by_cases heq : s₀.slotId = sid
        · simp [mkTbl', heq, mkSl', hsl_lt sl hsl_mem]
        · simp [mkTbl', heq, hsl_lt s₀ hs₀]
      have hlen' : (mkTbl' dOut).slots.length ≤ M_slots := by
        simpa [mkTbl'] using hlen_M
      have hcur_sp' : ((mkTbl' dOut).currentSpace : ℝ) ≤
          (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ :=
        table_space_le_of_slots_cg hσθ.1 hσθ.2.1 hfacs hact_le hlen' hall_inv'
      have hmax_sp' : ((max peakSp (mkTbl' dOut).currentSpace : ℕ) : ℝ) ≤
          (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ := by
        rw [Nat.cast_max]
        exact max_le hpeak_real hcur_sp'
      have hrel' : List.Forall₂ (CertDelRel rec₀ rest) slots₀ (mkTbl' dOut).slots := by
        have haux : ∀ l₀ l,
            (l.map UL.HostedCertSlot.slotId).Nodup →
            (∀ s ∈ l, s.slotId = sid → s = sl) →
            List.Forall₂ (CertDelRel rec₀ ((sid, rec₀) :: rest)) l₀ l →
            List.Forall₂ (CertDelRel rec₀ rest) l₀
              (l.map (fun s => if s.slotId = sid then mkSl' dOut else s)) := by
          intro l₀ l hnd_l huniq hr
          induction hr with
          | nil => exact List.Forall₂.nil
          | @cons s₀ s tl₀ tl hh hhr ihr =>
            rw [List.map_cons, List.nodup_cons] at hnd_l
            rcases hnd_l with ⟨hs_not, hnd_tl⟩
            have ihr' := ihr hnd_tl (fun x hx => huniq x (List.mem_cons_of_mem s hx))
            simp only [List.map_cons]
            by_cases heq : s.slotId = sid
            · have hs_eq : s = sl := huniq s List.mem_cons_self heq
              subst s
              simp only [heq, ↓reduceIte]
              rcases hh with ⟨hid0, hgen0, hb0, hsurv0⟩
              have hmem_head : sl.slotId ∈ ((sid, rec₀) :: rest).map Prod.fst := by simp [heq]
              simp only [hmem_head, ↓reduceIte] at hsurv0
              have hnot_rest : (mkSl' dOut).slotId ∉ rest.map Prod.fst := by
                simpa [mkSl', heq] using hsid_not_rest
              refine List.Forall₂.cons ⟨by simp [mkSl', hid0], by simp [mkSl', hgen0],
                by simp [mkSl', hb0], ?_⟩ ihr'
              simp [hnot_rest, mkSl', hsurv0.1]
            · simp only [heq, ↓reduceIte]
              rcases hh with ⟨hid0, hgen0, hb0, hsurv0⟩
              refine List.Forall₂.cons ⟨hid0, hgen0, hb0, ?_⟩ ihr'
              by_cases hm_rest : s.slotId ∈ rest.map Prod.fst <;>
                simp [heq, hm_rest] at hsurv0 ⊢ <;> exact hsurv0
        have huniq_sl : ∀ s ∈ tbl.slots, s.slotId = sid → s = sl := by
          intro s hs heq
          have hf_s := list_find?_eq_some_of_mem_nodup tbl.slots UL.HostedCertSlot.slotId hsl_nd hs
          rw [heq, hfind] at hf_s
          exact (Option.some.inj hf_s).symm
        exact haux slots₀ tbl.slots hsl_nd huniq_sl hrel
      have hpairs_rest : ∀ pair ∈ rest,
          pair.2 = rec₀ ∧ pair.1 ∈ (mkTbl' dOut).slots.map UL.HostedCertSlot.slotId := by
        intro pair hp
        rw [hmap_id]
        exact hpairs_mem pair (List.mem_cons_of_mem (sid, rec₀) hp)
      exact ⟨hlen', hmap_id ▸ hsl_nd, hall_lt', hall_inv', hrel', hmax_sp', hpairs_rest⟩
    refine ⟨?_, ?_, ?_⟩
    · rw [hfeq]
      refine haltProb_seqConsume hpf_del hhalt_del fun bs₁ dOut hd₁ => ?_
      rcases hstep_dOut bs₁ dOut hd₁ with ⟨hlen', hnd', hlt', hinv', hrel', hmax_sp', hpairs'⟩
      exact (ih restFuel (mkTbl' dOut) (accW + dOut.work + 1)
        (max peakSp (mkTbl' dOut).currentSpace)
        hrec_not hact_le hlen' (le_max_right _ _) hmax_sp'
        hrest_nd hpairs' hnd' hlt' hinv' hrel').1
    · intro bs out hout
      have hout' : seqConsume f_del g_cont bs = some out := congrFun hfeq bs ▸ hout
      rcases (seqConsume_eq_some_iff hpf_del).mp hout' with ⟨bs₁, bs₂, dOut, rfl, hd₁, hg₂⟩
      rcases hstep_dOut bs₁ dOut hd₁ with ⟨hlen', hnd', hlt', hinv', hrel', hmax_sp', hpairs'⟩
      exact (ih restFuel (mkTbl' dOut) (accW + dOut.work + 1)
        (max peakSp (mkTbl' dOut).currentSpace)
        hrec_not hact_le hlen' (le_max_right _ _) hmax_sp'
        hrest_nd hpairs' hnd' hlt' hinv' hrel').2.1 bs₂ out hg₂
    · rw [hfeq, expWithBits_seqConsume hpf_del]
      rcases slotPot_replace_split_cg mkCert tbl hsl_nd hsl_mem with ⟨restPot, hpot_tbl, hpot_rep⟩
      have hmono :
          expWithBits f_del (fun dOut =>
            expWithBits (g_cont dOut) (fun out =>
              (out.work : ENNReal) + slotPot mkCert out.nextState.2)) ≤
          expWithBits f_del (fun dOut =>
            (((accW + rest.length + 2 : ℕ) : ENNReal) + restPot) +
              ((dOut.work : ENNReal) +
                remCopyWork (mkCert sl.gen) sl.bState (sl.surviving.erase rec₀) dOut.nextPhase)) := by
        refine expWithBits_mono fun bs₁ dOut hd₁ => ?_
        rcases hstep_dOut bs₁ dOut hd₁ with ⟨hlen', hnd', hlt', hinv', hrel', hmax_sp', hpairs'⟩
        have h_ih := (ih restFuel (mkTbl' dOut) (accW + dOut.work + 1)
          (max peakSp (mkTbl' dOut).currentSpace)
          hrec_not hact_le hlen' (le_max_right _ _) hmax_sp'
          hrest_nd hpairs' hnd' hlt' hinv' hrel').2.2
        have hpot_dOut : slotPot mkCert (mkTbl' dOut) =
            restPot +
              remCopyWork (mkCert sl.gen) sl.bState (sl.surviving.erase rec₀) dOut.nextPhase := by
          have hr := hpot_rep (mkSl' dOut)
          simpa [mkTbl', hsl_id_eq, mkSl'] using hr
        refine h_ih.trans (le_of_eq ?_)
        rw [hpot_dOut]
        push_cast
        ring
      refine hmono.trans ?_
      rw [expWithBits_const_add_of_haltProb_one hhalt_del]
      have hdel_le :
          expWithBits f_del (fun dOut =>
            (dOut.work : ENNReal) +
              remCopyWork (mkCert sl.gen) sl.bState (sl.surviving.erase rec₀) dOut.nextPhase) ≤
          remCopyWork (mkCert sl.gen) sl.bState sl.surviving sl.phase :=
        delete_remCopyWork_le hcert_hist extHist hsl_accB hsurv_inst hsl_accP hrec_in_sl
      calc
        (((accW + rest.length + 2 : ℕ) : ENNReal) + restPot) +
          expWithBits f_del (fun dOut =>
            (dOut.work : ENNReal) +
              remCopyWork (mkCert sl.gen) sl.bState (sl.surviving.erase rec₀) dOut.nextPhase)
            ≤ (((accW + rest.length + 2 : ℕ) : ENNReal) + restPot) +
                remCopyWork (mkCert sl.gen) sl.bState sl.surviving sl.phase :=
              add_le_add le_rfl hdel_le
        _ = ((accW + ((sid, rec₀) :: rest).length + 1 : ℕ) : ENNReal) + slotPot mkCert tbl := by
              rw [hpot_tbl]
              simp only [List.length_cons]
              push_cast
              ring

open Classical in
theorem certStep_delete_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound P_life : ℝ}
    (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    (extHist : UL.ExecutionHistory d)
    {admissibleQuery : Finset ι → UL.SearchQuery ι d_s → Prop}
    {S : Finset ι} {ctrl : CertCtrlState ι d_s} {tbl0 : UL.HostedCertTable ι d_s B P}
    (hinv : CertTableInv n maxOps (certGroupCopies n P_life netLogBound)
      pts h σ facs mkCert S ctrl tbl0)
    (hS_le : S.card ≤ n)
    {id₀ : ι}
    (hleg : UL.IsLegalDynamicSearchOp n pts admissibleQuery S (.delete id₀)) :
    let L_max := Nat.log 2 maxOps + 1
    let R := certGroupCopies n P_life netLogBound
    let cap := certCap n θ facs
    let dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
      n pts h mkCert
    let stepFn := UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀)
    UL.singleDynamicSearchStepHaltProb dynIdx extHist S (ctrl, tbl0) (.delete id₀) = 1 ∧
    (∀ bs S' out, stepFn bs = some (S', out) →
      S' = S.erase id₀ ∧
      out.queryAnswer = none ∧
      out.nextState.2.nextLifetime = tbl0.nextLifetime ∧
      CertTableInv n maxOps R pts h σ facs mkCert S' out.nextState.1 out.nextState.2 ∧
      (out.peakSpace : ℝ) ≤ (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ) ∧
    (∀ rem : ℕ,
      expWithBits stepFn (fun res =>
        (res.2.work : ENNReal) +
          certPhi L_max R n θ facs N cap mkCert rem res.2.nextState.1.groups res.2.nextState.2) ≤
      certPhi L_max R n θ facs N cap mkCert (rem + 1) ctrl.groups tbl0 +
        ((L_max * R + 2 : ℕ) : ENNReal)) := by
  dsimp only []
  set L_max := Nat.log 2 maxOps + 1
  set R := certGroupCopies n P_life netLogBound
  set cap := certCap n θ facs
  set dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
    n pts h mkCert
  have hid₀_S : id₀ ∈ S := hleg
  have hid₀_img : id₀ ∈ tbl0.activeLifetimes.image Prod.fst := hinv.img_eq ▸ hid₀_S
  rcases Finset.mem_image.mp hid₀_img with ⟨rec₀, hrec₀_mem, hrec₀_fst⟩
  have hinj_fst : ∀ r₁ ∈ tbl0.activeLifetimes, ∀ r₂ ∈ tbl0.activeLifetimes,
      r₁.1 = r₂.1 → r₁ = r₂ := by
    have hce : (tbl0.activeLifetimes.image Prod.fst).card = tbl0.activeLifetimes.card := by
      rw [hinv.img_eq, hinv.card_eq]
    exact fun _ hr₁ _ hr₂ heq => injOn_of_card_image_eq_cg hce hr₁ hr₂ heq
  let tbl1 : UL.HostedCertTable ι d_s B P :=
    { tbl0 with activeLifetimes := tbl0.activeLifetimes.filter (fun p => p.1 ≠ id₀) }
  have hact1_eq : tbl1.activeLifetimes = tbl0.activeLifetimes.erase rec₀ := by
    ext p
    simp only [tbl1, Finset.mem_filter, Finset.mem_erase]
    constructor
    · rintro ⟨hp, hne⟩
      exact ⟨fun heq => hne (heq ▸ hrec₀_fst), hp⟩
    · rintro ⟨hne, hp⟩
      exact ⟨hp, fun hfst => hne (hinj_fst p hp rec₀ hrec₀_mem (hfst.trans hrec₀_fst.symm))⟩
  have himg1 : tbl1.activeLifetimes.image Prod.fst = S.erase id₀ := by
    rw [hact1_eq]
    ext x
    simp only [Finset.mem_image, Finset.mem_erase]
    constructor
    · rintro ⟨p, ⟨hne, hp⟩, rfl⟩
      refine ⟨?_, hinv.img_eq ▸ Finset.mem_image.mpr ⟨p, hp, rfl⟩⟩
      intro hxeq
      exact hne (hinj_fst p hp rec₀ hrec₀_mem (hxeq.trans hrec₀_fst.symm))
    · rintro ⟨hxne, hxS⟩
      rcases Finset.mem_image.mp (hinv.img_eq ▸ hxS) with ⟨p, hp, rfl⟩
      refine ⟨p, ⟨fun heq => hxne (heq ▸ hrec₀_fst), hp⟩, rfl⟩
  have hcard1 : tbl1.activeLifetimes.card = (S.erase id₀).card := by
    rw [hact1_eq, Finset.card_erase_of_mem hrec₀_mem, Finset.card_erase_of_mem hid₀_S, hinv.card_eq]
  have hact1_le_n : tbl1.activeLifetimes.card ≤ n := by
    rw [hcard1]
    exact (Finset.card_erase_le).trans hS_le
  have hsp1_le_0 : tbl1.currentSpace ≤ tbl0.currentSpace := by
    unfold UL.HostedCertTable.currentSpace
    dsimp only [tbl1]
    have hc : (tbl0.activeLifetimes.filter (fun p => p.1 ≠ id₀)).card ≤
        tbl0.activeLifetimes.card := Finset.card_filter_le _ _
    omega
  have hmax01 : max tbl0.currentSpace tbl1.currentSpace = tbl0.currentSpace :=
    max_eq_left hsp1_le_0
  have hsp0_real : (tbl0.currentSpace : ℝ) ≤
      (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ :=
    hinv.currentSpace_le hσθ.1 hσθ.2.1 hfacs hS_le
  have hsl_sub_act0 : ∀ sl ∈ tbl0.slots, sl.surviving ⊆ tbl0.activeLifetimes := by
    intro sl hsl
    have hsid_mem : sl.slotId ∈ ctrl.groups.flatMap CertGroupMeta.sids := by
      rw [← hinv.slotIds_eq]
      exact List.mem_map_of_mem hsl
    rcases List.mem_flatMap.mp hsid_mem with ⟨g, hg, hsid_g⟩
    have hsurv_eq := ((hinv.groups_inv g hg).2.2.2.2.2.2 sl.slotId hsid_g sl hsl rfl).2
    rw [hsurv_eq]
    exact Finset.filter_subset _ _
  let pairFn : UL.HostedCertSlot ι d_s B P → Option (ℕ × (ι × ℕ)) := fun sl =>
    let filt := sl.surviving.filter (fun p => p.1 = id₀)
    if hne : filt.Nonempty then some (sl.slotId, hne.choose) else none
  let delPairs : List (ℕ × (ι × ℕ)) := tbl1.slots.filterMap pairFn
  have hpairFn_spec : ∀ sl ∈ tbl0.slots,
      (pairFn sl = some (sl.slotId, rec₀) ∧ rec₀ ∈ sl.surviving) ∨
      (pairFn sl = none ∧ rec₀ ∉ sl.surviving) := by
    intro sl hsl
    dsimp only [pairFn]
    by_cases hrec_in : rec₀ ∈ sl.surviving
    · left
      have hfilt_ne : (sl.surviving.filter (fun p => p.1 = id₀)).Nonempty :=
        ⟨rec₀, Finset.mem_filter.mpr ⟨hrec_in, hrec₀_fst⟩⟩
      have hch_mem := hfilt_ne.choose_spec
      rcases Finset.mem_filter.mp hch_mem with ⟨hch_surv, hch_fst⟩
      have hch_eq : hfilt_ne.choose = rec₀ :=
        hinj_fst _ (hsl_sub_act0 sl hsl hch_surv) rec₀ hrec₀_mem (hch_fst.trans hrec₀_fst.symm)
      simp [hfilt_ne, hch_eq, hrec_in]
    · right
      have hnot_ne : ¬ (sl.surviving.filter (fun p => p.1 = id₀)).Nonempty := by
        rintro ⟨p, hp⟩
        rcases Finset.mem_filter.mp hp with ⟨hp_surv, hp_fst⟩
        have hp_eq : p = rec₀ :=
          hinj_fst p (hsl_sub_act0 sl hsl hp_surv) rec₀ hrec₀_mem (hp_fst.trans hrec₀_fst.symm)
        exact hrec_in (hp_eq ▸ hp_surv)
      simp [hnot_ne, hrec_in]
  have hpairs_len : delPairs.length ≤ L_max * R := by
    have h1 : delPairs.length ≤ tbl1.slots.length := List.length_filterMap_le _ _
    exact h1.trans hinv.slots_length_le
  have hpairs_nd_mem :
      (delPairs.map Prod.fst).Nodup ∧
      (∀ pair ∈ delPairs, pair.2 = rec₀ ∧ pair.1 ∈ tbl1.slots.map UL.HostedCertSlot.slotId) ∧
      (∀ sl ∈ tbl0.slots, sl.slotId ∈ delPairs.map Prod.fst ↔ rec₀ ∈ sl.surviving) := by
    have haux : ∀ l : List (UL.HostedCertSlot ι d_s B P),
        (∀ sl ∈ l, sl ∈ tbl0.slots) →
        (l.map UL.HostedCertSlot.slotId).Nodup →
        ((l.filterMap pairFn).map Prod.fst).Nodup ∧
        (∀ pair ∈ l.filterMap pairFn, pair.2 = rec₀ ∧ pair.1 ∈ l.map UL.HostedCertSlot.slotId) ∧
        (∀ sl ∈ l, sl.slotId ∈ (l.filterMap pairFn).map Prod.fst ↔ rec₀ ∈ sl.surviving) := by
      intro l
      induction l with
      | nil => simp
      | cons hd tl ih =>
        intro hsub hnd_l
        rw [List.map_cons, List.nodup_cons] at hnd_l
        rcases hnd_l with ⟨hhd_not, hnd_tl⟩
        rcases ih (fun x hx => hsub x (List.mem_cons_of_mem hd hx)) hnd_tl with
          ⟨hnd_ih, hmem_ih, hiff_ih⟩
        rcases hpairFn_spec hd (hsub hd List.mem_cons_self) with ⟨hp_eq, hrec_in⟩ | ⟨hp_eq, hrec_not_in⟩
        · simp only [List.filterMap_cons, hp_eq, List.map_cons]
          have hhd_not_fm : hd.slotId ∉ (tl.filterMap pairFn).map Prod.fst := by
            intro hm
            rcases List.mem_map.mp hm with ⟨pair, hp, hfst⟩
            exact hhd_not (hfst ▸ (hmem_ih pair hp).2)
          refine ⟨List.nodup_cons.mpr ⟨hhd_not_fm, hnd_ih⟩, ?_, ?_⟩
          · intro pair hp
            rcases List.mem_cons.mp hp with rfl | hptl
            · exact ⟨rfl, List.mem_cons_self⟩
            · rcases hmem_ih pair hptl with ⟨h2, h1⟩
              exact ⟨h2, List.mem_cons_of_mem _ h1⟩
          · intro sl hsl
            rcases List.mem_cons.mp hsl with rfl | hstl
            · simp [hrec_in]
            · have hne : sl.slotId ≠ hd.slotId := fun heq =>
                hhd_not (heq ▸ List.mem_map_of_mem hstl)
              simp [hne, hiff_ih sl hstl]
        · simp only [List.filterMap_cons, hp_eq, List.map_cons]
          refine ⟨hnd_ih, ?_, ?_⟩
          · intro pair hp
            rcases hmem_ih pair hp with ⟨h2, h1⟩
            exact ⟨h2, List.mem_cons_of_mem _ h1⟩
          · intro sl hsl
            rcases List.mem_cons.mp hsl with rfl | hstl
            · refine ⟨fun hm => ?_, fun hr => absurd hr hrec_not_in⟩
              rcases List.mem_map.mp hm with ⟨pair, hp, hfst⟩
              exact absurd (hfst ▸ (hmem_ih pair hp).2) hhd_not
            · exact hiff_ih sl hstl
    exact haux tbl0.slots (fun _ hx => hx) hinv.slotIds_nodup
  rcases hpairs_nd_mem with ⟨hpairs_nd, hpairs_mem, hpairs_iff⟩
  have hrel0 : List.Forall₂ (CertDelRel rec₀ delPairs) tbl0.slots tbl1.slots := by
    have haux : ∀ l : List (UL.HostedCertSlot ι d_s B P),
        (∀ sl ∈ l, sl ∈ tbl0.slots) →
        List.Forall₂ (CertDelRel rec₀ delPairs) l l := by
      intro l hsub
      induction l with
      | nil => exact List.Forall₂.nil
      | cons hd tl ih =>
        refine List.Forall₂.cons ⟨rfl, rfl, rfl, ?_⟩
          (ih fun x hx => hsub x (List.mem_cons_of_mem hd hx))
        by_cases hm : hd.slotId ∈ delPairs.map Prod.fst
        · simp [hm, (hpairs_iff hd (hsub hd List.mem_cons_self)).mp hm]
        · have hnot_r : rec₀ ∉ hd.surviving := fun hr =>
            hm ((hpairs_iff hd (hsub hd List.mem_cons_self)).mpr hr)
          simp [hm, Finset.erase_eq_of_notMem hnot_r]
    exact haux tbl0.slots (fun _ hx => hx)
  have hval1 : ValidCertTable n h mkCert tbl1 := hinv.toValid
  let cmds : List (PlannedCertCmd ι d_s) :=
    (delPairs.map fun pair => PlannedCertCmd.deleteCertSlot pair.1 pair.2) ++
    [PlannedCertCmd.finishCertUpdate]
  have hplan : planCertStep pts h h_pos h_lt_one R cap (.delete id₀) ctrl.groups tbl1 =
      (ctrl.groups, cmds) := rfl
  let restFuel := certFuelBound L_max R tbl1.nextLifetime - (delPairs.length + 1)
  have hfuel_eq : certFuelBound L_max R tbl1.nextLifetime = delPairs.length + 1 + restFuel := by
    dsimp only [restFuel]
    unfold certFuelBound
    have hmul_le : L_max * R ≤ (L_max + 2) * R := Nat.mul_le_mul_right R (by omega)
    omega
  let f_del_run := fun bs =>
    UL.runCertHostedStepFuel n pts h mkCert
      (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
      extHist (.delete id₀) (delPairs.length + 1 + restFuel)
      { groups := ctrl.groups, queue := some cmds }
      tbl1 bs 1 tbl0.currentSpace
  have hrec_not1 : rec₀ ∉ tbl1.activeLifetimes := by
    rw [hact1_eq]
    exact Finset.notMem_erase _ _
  rcases runCertDelFinish_spec hσθ hfacs hCert extHist id₀ rec₀ ctrl.groups tbl0.slots
      delPairs restFuel tbl1 1 tbl0.currentSpace
      hrec_not1 hact1_le_n hinv.slots_length_le hsp1_le_0 hsp0_real
      hpairs_nd hpairs_mem hinv.slotIds_nodup hinv.slotIds_lt hinv.slots_inv hrel0 with
    ⟨hhalt_run, hpath_run, hexp_run⟩
  have hstepWithBits_eq : ∀ bs,
      dynIdx.stepWithBits extHist S (ctrl, tbl0) (.delete id₀) bs = f_del_run bs := by
    intro bs
    have hcond : tbl0.activeLifetimes.image Prod.fst = S ∧ tbl0.activeLifetimes.card = S.card :=
      ⟨hinv.img_eq, hinv.card_eq⟩
    change (if tbl0.activeLifetimes.image Prod.fst = S ∧ tbl0.activeLifetimes.card = S.card then
        UL.runCertHostedStepFuel n pts h mkCert
          (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
          extHist (.delete id₀) (certFuelBound L_max R tbl1.nextLifetime)
          ctrl tbl1 bs 1 (max tbl0.currentSpace tbl1.currentSpace)
      else none) = f_del_run bs
    rw [if_pos hcond, hmax01, hfuel_eq]
    have hctrl_eq : ctrl = { groups := ctrl.groups, queue := none } := by
      cases ctrl
      simp only [CertCtrlState.mk.injEq, true_and]
      exact hinv.queue_none
    conv_lhs => rw [hctrl_eq]
    have hpos_fuel : delPairs.length + 1 + restFuel = (delPairs.length + restFuel) + 1 := by omega
    conv_lhs => rw [hpos_fuel]
    refine (runCertHostedStepFuel_plan_eq n pts h h_pos h_lt_one R cap mkCert
      extHist (.delete id₀) (delPairs.length + restFuel) ctrl.groups ctrl.groups cmds
      tbl1 bs 1 tbl0.currentSpace hval1 hplan).trans ?_
    dsimp only [f_del_run]
    rw [← hpos_fuel]
  have hstepFn_eq : ∀ bs,
      UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀) bs =
        (f_del_run bs).map (fun out => (S.erase id₀, out)) := by
    intro bs
    unfold UL.runSingleDynamicSearchStep
    rw [hstepWithBits_eq bs]
    cases hfr : f_del_run bs with
    | none => rfl
    | some out =>
      have hqa := (hpath_run bs out hfr).2.1
      simp [hqa, UL.applyDynamicSearchSetOp]
  have hhalt_run' : haltProb f_del_run = 1 := hhalt_run
  refine ⟨?_, ?_, ?_⟩
  · unfold UL.singleDynamicSearchStepHaltProb
    rw [← hhalt_run']
    unfold haltProb
    refine tsum_congr fun bs => ?_
    rw [hstepFn_eq bs]
    cases f_del_run bs <;> rfl
  · intro bs S' out hstep
    rw [hstepFn_eq bs] at hstep
    cases hfr : f_del_run bs with
    | none => simp [hfr] at hstep
    | some out' =>
      rw [hfr] at hstep
      simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq] at hstep
      rcases hstep with ⟨hS_eq, hout_eq⟩
      subst S'
      subst out'
      rcases hpath_run bs out hfr with
        ⟨hctrl', hqa', hact', hnl', hnd', hlt', hsl_inv', hrel_nil, hsp'⟩
      rcases forall₂_certDelRel_nil_props hrel_nil with ⟨hmap_id_eq, _, hmem_rel⟩
      refine ⟨rfl, hqa', hnl', ?_, hsp'⟩
      refine
        { queue_none := by rw [hctrl']
          img_eq := by rw [hact']; exact himg1
          card_eq := by rw [hact']; exact hcard1
          lt_next := by
            rw [hact', hnl', hact1_eq]
            intro p hp
            exact hinv.lt_next p (Finset.mem_of_mem_erase hp)
          unit_active := by
            rw [hact', hact1_eq]
            intro p hp
            exact hinv.unit_active p (Finset.mem_of_mem_erase hp)
          life_le_max := by rw [hnl']; exact hinv.life_le_max
          levels_nodup := by rw [hctrl']; exact hinv.levels_nodup
          level_mem_iff := by rw [hctrl', hnl']; exact hinv.level_mem_iff
          slotIds_eq := by rw [hctrl', hmap_id_eq]; exact hinv.slotIds_eq
          slotIds_nodup := hnd'
          slotIds_lt := hlt'
          slots_inv := hsl_inv'
          groups_inv := by
            rw [hctrl', hact', hnl']
            intro g hg
            rcases hinv.groups_inv g hg with
              ⟨hg_nd, hg_len, hg_m1, hg_mn, hg_h, hg_pts, hg_sl⟩
            refine ⟨hg_nd, hg_len, hg_m1, hg_mn, hg_h, hg_pts, ?_⟩
            intro sid hsid sl hsl hid
            rcases hmem_rel sl hsl with ⟨sl₀, hsl₀, hid0, hgen0, _, hsurv0⟩
            have hid_sl₀ : sl₀.slotId = sid := hid0.symm.trans hid
            rcases hg_sl sid hsid sl₀ hsl₀ hid_sl₀ with ⟨hgen_g, hsurv_g⟩
            refine ⟨hgen0.trans hgen_g, ?_⟩
            rw [hsurv0, hsurv_g, hact1_eq, binSlice_erase_eq_cg] }
  · intro rem
    let C_fixed : ENNReal :=
      ((rem * (n + 1) : ℕ) : ENNReal) * (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) +
      (elemCredit L_max tbl1.activeLifetimes tbl0.nextLifetime : ENNReal) *
        ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2))
    have hexp_eq :
        expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀))
          (fun res =>
          (res.2.work : ENNReal) +
            certPhi L_max R n θ facs N cap mkCert rem res.2.nextState.1.groups res.2.nextState.2) =
        expWithBits f_del_run (fun out =>
          ((out.work : ENNReal) + slotPot mkCert out.nextState.2) + C_fixed) := by
      unfold expWithBits
      refine tsum_congr fun bs => ?_
      rw [hstepFn_eq bs]
      cases hfr : f_del_run bs with
      | none => rfl
      | some out =>
        rcases hpath_run bs out hfr with ⟨hctrl', _, hact', hnl', _, _, _, hrel_nil, _⟩
        have hbg : badGroupCount N cap mkCert out.nextState.1.groups out.nextState.2 =
            badGroupCount N cap mkCert ctrl.groups tbl0 := by
          rw [hctrl']
          exact badGroupCount_eq_of_certDelRel_nil N cap mkCert ctrl.groups hrel_nil
        simp only [Option.map_some, certPhi, hbg, hact', hnl', C_fixed]
        ring
    rw [hexp_eq, expWithBits_add_const_of_haltProb_one hhalt_run]
    have hbad_mono :
        ((rem * (n + 1) : ℕ) : ENNReal) * (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) ≤
          (((rem + 1) * (n + 1) : ℕ) : ENNReal) *
            (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) := by
      gcongr
      omega
    have helem_mono :
        (elemCredit L_max tbl1.activeLifetimes tbl0.nextLifetime : ENNReal) *
          ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2)) ≤
        (elemCredit L_max tbl0.activeLifetimes tbl0.nextLifetime : ENNReal) *
          ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2)) := by
      gcongr
      exact_mod_cast elemCredit_subset L_max tbl0.nextLifetime
        (hact1_eq ▸ Finset.erase_subset rec₀ tbl0.activeLifetimes)
    have hC_le : C_fixed ≤
        (((rem + 1) * (n + 1) : ℕ) : ENNReal) *
          (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) +
        (elemCredit L_max tbl0.activeLifetimes tbl0.nextLifetime : ENNReal) *
          ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2)) :=
      add_le_add hbad_mono helem_mono
    have hlen_le : ((1 + delPairs.length + 1 : ℕ) : ENNReal) ≤ ((L_max * R + 2 : ℕ) : ENNReal) := by
      exact_mod_cast (by omega : 1 + delPairs.length + 1 ≤ L_max * R + 2)
    calc
      expWithBits f_del_run (fun out => (out.work : ENNReal) + slotPot mkCert out.nextState.2) +
          C_fixed
          ≤ (((1 + delPairs.length + 1 : ℕ) : ENNReal) + slotPot mkCert tbl1) + C_fixed :=
            add_le_add hexp_run le_rfl
      _ ≤ ((L_max * R + 2 : ℕ) : ENNReal) + slotPot mkCert tbl0 +
            ((((rem + 1) * (n + 1) : ℕ) : ENNReal) *
              (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) +
            (elemCredit L_max tbl0.activeLifetimes tbl0.nextLifetime : ENNReal) *
              ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2))) := by
            have hpot01 : slotPot mkCert tbl1 = slotPot mkCert tbl0 := rfl
            rw [hpot01]
            exact add_le_add (add_le_add hlen_le le_rfl) hC_le
      _ = certPhi L_max R n θ facs N cap mkCert (rem + 1) ctrl.groups tbl0 +
            ((L_max * R + 2 : ℕ) : ENNReal) := by
            unfold certPhi
            ring

/-! ### 3. Certified `.query` Step Helpers & `certStep_query_spec` -/

theorem option_mapM_map_eq_some_cg {α β γ : Type}
    (l : List α) (m : α → β) (f : β → Option γ) (k : α → γ)
    (hf : ∀ a ∈ l, f (m a) = some (k a)) :
    (l.map m).mapM f = some (l.map k) := by
  induction l with
  | nil => rfl
  | cons a tl ih =>
    have ha := hf a List.mem_cons_self
    have htl := ih fun x hx => hf x (List.mem_cons_of_mem a hx)
    simp [List.map_cons, ha, htl]

theorem mem_foldr_union_of_mem_cg {α β : Type} [DecidableEq β]
    (l : List α) (f : α → Finset β) {a : α} (ha : a ∈ l) {x : β} (hx : x ∈ f a) :
    x ∈ l.foldr (fun g acc => f g ∪ acc) ∅ := by
  induction l with
  | nil => simp at ha
  | cons hd tl ih =>
    simp only [List.foldr_cons, Finset.mem_union]
    rcases List.mem_cons.mp ha with rfl | htl
    · exact Or.inl hx
    · exact Or.inr (ih htl)

theorem foldl_max_le_cg {α : Type} (l : List α) (f : α → ℕ) (m₀ : ℕ) (B : ℝ)
    (hm₀ : (m₀ : ℝ) ≤ B) (hl : ∀ x ∈ l, (f x : ℝ) ≤ B) :
    ((l.foldl (fun m x => max m (f x)) m₀ : ℕ) : ℝ) ≤ B := by
  induction l generalizing m₀ with
  | nil => exact hm₀
  | cons hd tl ih =>
    simp only [List.foldl_cons]
    refine ih (max m₀ (f hd)) ?_ (fun x hx => hl x (List.mem_cons_of_mem hd hx))
    rw [Nat.cast_max]
    exact max_le hm₀ (hl hd List.mem_cons_self)

theorem sum_le_mul_add_filter_cg {α : Type}
    (l : List α) (w : α → ℕ) (bad : α → Bool) (A B : ℕ)
    (hw : ∀ g ∈ l, w g ≤ A + (if bad g = true then B else 0)) :
    (l.map w).sum ≤ l.length * A + B * (l.filter bad).length := by
  induction l with
  | nil => simp
  | cons hd tl ih =>
    have h1 := hw hd List.mem_cons_self
    have h2 := ih fun g hg => hw g (List.mem_cons_of_mem hd hg)
    cases hbad : bad hd with
    | false =>
      simp only [hbad, Bool.false_eq_true, ↓reduceIte, add_zero] at h1
      simp only [List.map_cons, List.sum_cons, List.length_cons, List.filter_cons, hbad,
        Bool.false_eq_true, ↓reduceIte]
      calc
        w hd + (tl.map w).sum
            ≤ A + (tl.length * A + B * (tl.filter bad).length) := add_le_add h1 h2
        _ = (tl.length + 1) * A + B * (tl.filter bad).length := by ring
    | true =>
      simp only [hbad, ↓reduceIte] at h1
      simp only [List.map_cons, List.sum_cons, List.length_cons, List.filter_cons, hbad, ↓reduceIte,
        List.length_cons]
      calc
        w hd + (tl.map w).sum
            ≤ (A + B) + (tl.length * A + B * (tl.filter bad).length) := add_le_add h1 h2
        _ = (tl.length + 1) * A + B * ((tl.filter bad).length + 1) := by ring

open Classical in
theorem certStep_query_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound P_life : ℝ}
    (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hPlife : 1 ≤ P_life) (hnet0 : 0 ≤ netLogBound)
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    (extHist : UL.ExecutionHistory d)
    {S : Finset ι} {ctrl : CertCtrlState ι d_s} {tbl0 : UL.HostedCertTable ι d_s B P}
    (hinv : CertTableInv n maxOps (certGroupCopies n P_life netLogBound)
      pts h σ facs mkCert S ctrl tbl0)
    (hS_le : S.card ≤ n)
    (q : UL.SearchQuery ι d_s)
    (hq_adm : q.z ∈ N ∧
      ((δ_margin = 0 ∧ UL.IsCompatibleTest pts S q.z q.accept) ∨
        UL.IsMarginCompatibleTest pts S δ_margin q.z q.accept)) :
    let L_max := Nat.log 2 maxOps + 1
    let R := certGroupCopies n P_life netLogBound
    let cap := certCap n θ facs
    let dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
      n pts h mkCert
    let stepFn := UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.query q)
    UL.singleDynamicSearchStepHaltProb dynIdx extHist S (ctrl, tbl0) (.query q) = 1 ∧
    (∀ bs S' out, stepFn bs = some (S', out) →
      S' = S ∧
      out.nextState.2.nextLifetime = tbl0.nextLifetime ∧
      CertTableInv n maxOps R pts h σ facs mkCert S' out.nextState.1 out.nextState.2 ∧
      (out.peakSpace : ℝ) ≤ (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ ∧
      ∃ ans : Option ι,
        out.queryAnswer = some ans ∧
        UL.IsCorrectSearchAnswer pts S h q.z q.accept ans) ∧
    (∀ rem : ℕ,
      expWithBits stepFn (fun res =>
        (res.2.work : ENNReal) +
          certPhi L_max R n θ facs N cap mkCert rem res.2.nextState.1.groups res.2.nextState.2) ≤
      certPhi L_max R n θ facs N cap mkCert (rem + 1) ctrl.groups tbl0 +
        ((L_max * R * (cap + 1) + 2 : ℕ) : ENNReal)) := by
  dsimp only []
  set L_max := Nat.log 2 maxOps + 1
  set R := certGroupCopies n P_life netLogBound
  set cap := certCap n θ facs
  set dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
    n pts h mkCert
  have hR_ge3 : 3 ≤ R := certGroupCopies_ge_three hσθ.1 hPlife hnet0
  let H := tbl0.nextLifetime
  let qLifted := UL.liftQueryToLifetimes q
  let raceGroups := ctrl.groups.map (fun g => (g.sids, cap))
  let fResolve : List ℕ × ℕ →
      Option (Finset (ι × ℕ) × List (UL.HostedCertSlot ι d_s B P) × ℕ) :=
    fun (sids, c) =>
      let sls := sids.filterMap (fun sid => tbl0.slots.find? (fun s => s.slotId = sid))
      match sls with
      | [] => none
      | sl₀ :: _ =>
          if sids.Nodup ∧ sls.length = sids.length ∧
              sl₀.surviving ⊆ tbl0.activeLifetimes ∧
              (∀ sl ∈ sls, sl.surviving = sl₀.surviving) then
            some (sl₀.surviving, sls, c)
          else
            none
  let grpTuple := fun g : CertGroupMeta ι d_s =>
    (binSlice tbl0.activeLifetimes H g.level, groupSlots tbl0 g.sids, cap)
  have hfResolve_spec : ∀ g ∈ ctrl.groups, fResolve (g.sids, cap) = some (grpTuple g) := by
    intro g hg
    rcases groupSlots_spec_of_inv hinv hg with ⟨_, hsls_len, hsls_mem⟩
    rcases hinv.groups_inv g hg with ⟨hg_nd, hg_len, _⟩
    change (let sls := groupSlots tbl0 g.sids
      match sls with
      | [] => none
      | sl₀ :: _ =>
          if g.sids.Nodup ∧ sls.length = g.sids.length ∧
              sl₀.surviving ⊆ tbl0.activeLifetimes ∧
              (∀ sl ∈ sls, sl.surviving = sl₀.surviving) then
            some (sl₀.surviving, sls, cap)
          else
            none) = some (binSlice tbl0.activeLifetimes H g.level, groupSlots tbl0 g.sids, cap)
    generalize hsls_cases : groupSlots tbl0 g.sids = sls0
    cases sls0 with
    | nil =>
      rw [hsls_cases, List.length_nil] at hsls_len
      omega
    | cons sl₀ tl =>
      dsimp only []
      have hsl₀_in : sl₀ ∈ groupSlots tbl0 g.sids := hsls_cases ▸ List.mem_cons_self
      have hsl₀_surv : sl₀.surviving = binSlice tbl0.activeLifetimes H g.level :=
        (hsls_mem sl₀ hsl₀_in).2.2
      have hcond : g.sids.Nodup ∧ (sl₀ :: tl).length = g.sids.length ∧
          sl₀.surviving ⊆ tbl0.activeLifetimes ∧
          (∀ sl ∈ sl₀ :: tl, sl.surviving = sl₀.surviving) := by
        refine ⟨hg_nd, hsls_cases ▸ hsls_len, hsl₀_surv ▸ Finset.filter_subset _ _, ?_⟩
        intro sl hsl
        have hsl_in : sl ∈ groupSlots tbl0 g.sids := hsls_cases ▸ hsl
        rw [(hsls_mem sl hsl_in).2.2, hsl₀_surv]
      rw [if_pos hcond, hsl₀_surv]
  let grps := ctrl.groups.map grpTuple
  have hresolved : raceGroups.mapM fResolve = some grps :=
    option_mapM_map_eq_some_cg ctrl.groups (fun g => (g.sids, cap)) fResolve grpTuple hfResolve_spec
  have hcover : tbl0.activeLifetimes ⊆ grps.foldr (fun g acc => g.1 ∪ acc) ∅ := by
    intro p hp
    have hp_lt_H : p.2 < H := hinv.lt_next p hp
    have hH_lt_pow : H < 2 ^ L_max :=
      lt_of_le_of_lt hinv.life_le_max (lt_two_pow_log_succ maxOps)
    rcases binInterval_exists_unique hH_lt_pow hp_lt_H with ⟨k, ⟨_, hk_bit, hk_lo, hk_hi⟩, _⟩
    rcases List.mem_map.mp ((hinv.level_mem_iff k).mpr hk_bit) with ⟨g, hg, rfl⟩
    have hp_slice : p ∈ (grpTuple g).1 := Finset.mem_filter.mpr ⟨hp, hk_lo, hk_hi⟩
    have hfold_eq : grps.foldr (fun x acc => x.1 ∪ acc) ∅ =
        ctrl.groups.foldr (fun g' acc => (grpTuple g').1 ∪ acc) ∅ := by
      dsimp only [grps]
      rw [List.foldr_map]
    rw [hfold_eq]
    exact mem_foldr_union_of_mem_cg ctrl.groups (fun g' => (grpTuple g').1) hg hp_slice
  let evalGroup := fun (S_grp : Finset (ι × ℕ))
      (sls : List (UL.HostedCertSlot ι d_s B P))
      (c : ℕ) =>
    let cOuts := sls.map (fun sl =>
      (sl.slotId, (mkCert sl.gen).runQueryCapped sl.bState sl.surviving sl.phase qLifted c))
    let raceWork := (cOuts.map (fun x => x.2.work + 1)).sum
    let completed := cOuts.filterMap (fun x => x.2.completedAnswer)
    match completed with
    | ans :: _ =>
        let hit : Option ι :=
          match ans with
          | some p => if p ∈ S_grp ∧ q.accept p.1 then some p.1 else none
          | none => none
        (hit, raceWork, cOuts)
    | [] =>
        let hit : Option ι :=
          if hex : ∃ p ∈ S_grp, q.accept p.1 then
            some (Classical.choose hex).1
          else
            none
        (hit, raceWork + S_grp.card + 1, cOuts)
  let grpResults := grps.map (fun (S_grp, sls, c) => evalGroup S_grp sls c)
  let totalQWork := (grpResults.map (fun r => r.2.1)).sum
  let allCOuts := (grpResults.map (fun r => r.2.2)).flatten
  let slots' := tbl0.slots.map (fun sl =>
    let sp := (allCOuts.filter (fun x => x.1 = sl.slotId)).foldl
      (fun m x => max m x.2.peakSpace) sl.spaceAlloc
    { sl with spaceAlloc := sp })
  let tbl' : UL.HostedCertTable ι d_s B P := { tbl0 with slots := slots' }
  let hits := grpResults.filterMap (fun r => r.1)
  let out_q : UL.DynamicSearchStepOutcome (CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P) ι :=
    { nextState := ({ groups := ctrl.groups, queue := none }, tbl')
      queryAnswer := some hits.head?
      work := 1 + totalQWork + 1
      peakSpace := max tbl0.currentSpace tbl'.currentSpace }
  have hstepWithBits_eq : ∀ bs,
      dynIdx.stepWithBits extHist S (ctrl, tbl0) (.query q) bs = endWithEmpty out_q bs := by
    intro bs
    have hcond : tbl0.activeLifetimes.image Prod.fst = S ∧ tbl0.activeLifetimes.card = S.card :=
      ⟨hinv.img_eq, hinv.card_eq⟩
    have hval0 : ValidCertTable n h mkCert tbl0 := hinv.toValid
    have hfuel : certFuelBound L_max R tbl0.nextLifetime =
        ((L_max + 2) * R + 4) + 1 := rfl
    change (if tbl0.activeLifetimes.image Prod.fst = S ∧ tbl0.activeLifetimes.card = S.card then
        UL.runCertHostedStepFuel n pts h mkCert
          (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
          extHist (.query q) (certFuelBound L_max R tbl0.nextLifetime)
          ctrl tbl0 bs 1 (max tbl0.currentSpace tbl0.currentSpace)
      else none) = endWithEmpty out_q bs
    rw [if_pos hcond, max_self, hfuel]
    conv_lhs => unfold UL.runCertHostedStepFuel
    simp only [certStepCtrl, if_pos hval0, hinv.queue_none, planCertStep, dispatchCertQueue]
    cases bs with
    | nil =>
      change (if ([] : List Bool).isEmpty then
          match raceGroups.mapM fResolve with
          | none => none
          | some grps' =>
              if tbl0.activeLifetimes ⊆ grps'.foldr (fun g acc => g.1 ∪ acc) ∅ then
                let grpResults' := grps'.map (fun (S_grp, sls, c) => evalGroup S_grp sls c)
                let totalQWork' := (grpResults'.map (fun r => r.2.1)).sum
                let allCOuts' := (grpResults'.map (fun r => r.2.2)).flatten
                let slots'' := tbl0.slots.map (fun sl =>
                  let sp := (allCOuts'.filter (fun x => x.1 = sl.slotId)).foldl
                    (fun m x => max m x.2.peakSpace) sl.spaceAlloc
                  { sl with spaceAlloc := sp })
                let tbl'' : UL.HostedCertTable ι d_s B P := { tbl0 with slots := slots'' }
                let hits' := grpResults'.filterMap (fun r => r.1)
                some
                  { nextState := ({ groups := ctrl.groups, queue := none }, tbl'')
                    queryAnswer := some hits'.head?
                    work := 1 + totalQWork' + 1
                    peakSpace := max tbl0.currentSpace tbl''.currentSpace }
              else none
        else none) = endWithEmpty out_q []
      have hempty : ([] : List Bool).isEmpty = true := rfl
      rw [if_pos hempty, hresolved]
      dsimp only []
      rw [if_pos hcover]
      rfl
    | cons _ _ =>
      simp [endWithEmpty]
  have hstepFn_eq :
      UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.query q) =
        endWithEmpty (S, out_q) := by
    funext bs
    unfold UL.runSingleDynamicSearchStep
    rw [hstepWithBits_eq bs]
    cases bs <;> rfl
  -- Per-group correctness, space, and work + bad-group analysis
  let resOf := fun g : CertGroupMeta ι d_s =>
    evalGroup (binSlice tbl0.activeLifetimes H g.level) (groupSlots tbl0 g.sids) cap
  have hgrpResults_eq : grpResults = ctrl.groups.map resOf := by
    dsimp only [grpResults, grps]
    rw [List.map_map]
    rfl
  have heval_spec : ∀ g ∈ ctrl.groups,
      let S_grp := binSlice tbl0.activeLifetimes H g.level
      let sls := groupSlots tbl0 g.sids
      let res := resOf g
      (∀ i, res.1 = some i → i ∈ S ∧ q.accept i) ∧
      (res.1 = none → ∀ p ∈ S_grp, ¬ (h ≤ inner ℝ (pts p.1) q.z)) ∧
      (∀ x ∈ res.2.2, (x.2.peakSpace : ℝ) ≤ 2 * facs.spaceBound n σ) ∧
      res.2.1 ≤ R * (cap + 1) +
        (if decide (IsBadGroup (mkCert g.gen) N cap (sls.map UL.HostedCertSlot.bState)) = true
          then n + 1 else 0) := by
    intro g hg
    dsimp only []
    set S_grp := binSlice tbl0.activeLifetimes H g.level
    set sls := groupSlots tbl0 g.sids
    have hS_grp_sub : S_grp ⊆ tbl0.activeLifetimes := Finset.filter_subset _ _
    rcases groupSlots_spec_of_inv hinv hg with ⟨_, hsls_len, hsls_mem⟩
    rcases hinv.groups_inv g hg with ⟨_, hg_len, _⟩
    have hsls_len_R : sls.length = R := hsls_len.trans hg_len
    have hsl_qspec : ∀ sl ∈ sls,
        let qOut := (mkCert sl.gen).runQuery sl.bState sl.surviving sl.phase qLifted
        (mkCert sl.gen).gen = sl.gen ∧
        sl.gen = g.gen ∧
        sl.surviving = S_grp ∧
        sl.surviving ⊆ sl.gen.P₀ ∧
        sl.gen.m ≤ n ∧
        sl.gen.IsCorrectAnswer S_grp qLifted qOut.answer ∧
        (qOut.peakSpace : ℝ) ≤ 2 * facs.spaceBound n σ ∧
        (qOut.work : ℝ) ≤ (mkCert g.gen).birthVar sl.bState q.z := by
      intro sl hsl
      rcases hsls_mem sl hsl with ⟨hsl_tbl, hsl_gen, hsl_surv⟩
      rcases hinv.slots_inv sl hsl_tbl with
        ⟨_, hsl_mn, hsl_gh, hsl_pts, hsl_sub, _, birthHist, hsl_accB, hsl_accP⟩
      rcases hCert sl.gen hsl_mn hsl_gh with ⟨hmk_gen, hmk_δ, hcert_all⟩
      have hcert_hist := hcert_all birthHist
      have hsurv_inst : (mkCert sl.gen).gen.IsSurvivingSubset sl.surviving := by
        unfold UL.SearchGeneration.IsSurvivingSubset
        rwa [hmk_gen]
      have hcomp : UL.IsCertifiedCompatible (mkCert sl.gen).gen (mkCert sl.gen).δ
          sl.surviving qLifted :=
        liftQuery_certifiedCompatible hinv.img_eq hmk_gen hmk_δ hsl_pts
          (hsl_surv ▸ hS_grp_sub) hsl_sub hq_adm.2
      rcases hcert_hist.2.2.2.2.2.2.2.2.2.1 sl.bState sl.surviving sl.phase qLifted
          hsl_accB hsurv_inst hsl_accP hcomp with ⟨hcorr_raw, hsp_raw⟩
      have hwork_raw := hcert_hist.2.2.2.2.2.2.2.2.2.2.2.2 sl.bState sl.surviving sl.phase qLifted
        hsl_accB hsurv_inst hsl_accP hcomp hq_adm.1
      have hcorr : sl.gen.IsCorrectAnswer S_grp qLifted
          ((mkCert sl.gen).runQuery sl.bState sl.surviving sl.phase qLifted).answer := by
        generalize ((mkCert sl.gen).runQuery sl.bState sl.surviving sl.phase qLifted).answer = ans0 at hcorr_raw ⊢
        rwa [hmk_gen, hsl_surv] at hcorr_raw
      have hsp_le2 : (((mkCert sl.gen).runQuery sl.bState sl.surviving sl.phase qLifted).peakSpace : ℝ) ≤
          2 * facs.spaceBound n σ := by
        have hmk_m : (mkCert sl.gen).gen.m = sl.gen.m := congrArg UL.SearchGeneration.m hmk_gen
        rw [hmk_m] at hsp_raw
        have hsp_n := spaceBound_mono_le hsl_mn hσθ.2.1 hfacs
        have hsp_nn : 0 ≤ facs.spaceBound n σ := by
          linarith [spaceBound_ge_one hσθ.1 hσθ.2.1 hfacs]
        linarith
      have hwork_bv : (((mkCert sl.gen).runQuery sl.bState sl.surviving sl.phase qLifted).work : ℝ) ≤
          (mkCert g.gen).birthVar sl.bState q.z := by
        rw [← hsl_gen]
        exact hwork_raw
      exact ⟨hmk_gen, hsl_gen, hsl_surv, hsl_sub, hsl_mn, hcorr, hsp_le2, hwork_bv⟩
    let cOuts := sls.map (fun sl =>
      (sl.slotId, (mkCert sl.gen).runQueryCapped sl.bState sl.surviving sl.phase qLifted cap))
    let raceWork := (cOuts.map (fun x => x.2.work + 1)).sum
    have hraceWork_le : raceWork ≤ R * (cap + 1) := by
      have haux : ∀ l : List (UL.HostedCertSlot ι d_s B P),
          ((l.map (fun sl =>
            ((mkCert sl.gen).runQueryCapped sl.bState sl.surviving sl.phase qLifted cap).work + 1)).sum) ≤
          l.length * (cap + 1) := by
        intro l
        induction l with
        | nil => simp
        | cons sl tl ih =>
          have hcw : ((mkCert sl.gen).runQueryCapped sl.bState sl.surviving sl.phase qLifted cap).work ≤ cap := by
            unfold UL.CertifiedSearchGeneration.runQueryCapped
            dsimp only []
            split_ifs with hle
            · exact hle
            · exact le_rfl
          simp only [List.map_cons, List.sum_cons, List.length_cons]
          calc
            ((mkCert sl.gen).runQueryCapped sl.bState sl.surviving sl.phase qLifted cap).work + 1 +
              (tl.map _).sum
                ≤ (cap + 1) + tl.length * (cap + 1) := add_le_add (by omega) ih
            _ = (tl.length + 1) * (cap + 1) := by ring
      have h1 := haux sls
      dsimp only [raceWork, cOuts]
      rw [ List.map_map ]
      exact h1.trans (by rw [hsls_len_R])
    have hcOuts_sp : ∀ x ∈ cOuts, (x.2.peakSpace : ℝ) ≤ 2 * facs.spaceBound n σ := by
      intro x hx
      rcases List.mem_map.mp hx with ⟨sl, hsl, rfl⟩
      have hsp_q := (hsl_qspec sl hsl).2.2.2.2.2.2.1
      unfold UL.CertifiedSearchGeneration.runQueryCapped
      dsimp only []
      split_ifs <;> exact hsp_q
    dsimp only [resOf, evalGroup]
    change (let completed := cOuts.filterMap (fun x => x.2.completedAnswer)
      let res := match completed with
        | ans :: _ =>
            (match ans with
              | some p => if p ∈ S_grp ∧ q.accept p.1 then some p.1 else none
              | none => none, raceWork, cOuts)
        | [] =>
            (if hex : ∃ p ∈ S_grp, q.accept p.1 then some (Classical.choose hex).1 else none,
              raceWork + S_grp.card + 1, cOuts)
      (∀ i, res.1 = some i → i ∈ S ∧ q.accept i) ∧
      (res.1 = none → ∀ p ∈ S_grp, ¬ (h ≤ inner ℝ (pts p.1) q.z)) ∧
      (∀ x ∈ res.2.2, (x.2.peakSpace : ℝ) ≤ 2 * facs.spaceBound n σ) ∧
      res.2.1 ≤ R * (cap + 1) +
        (if decide (IsBadGroup (mkCert g.gen) N cap (sls.map UL.HostedCertSlot.bState)) = true
          then n + 1 else 0))
    cases hcomp_list : cOuts.filterMap (fun x => x.2.completedAnswer) with
    | cons ans _ =>
      have hans_mem : ans ∈ cOuts.filterMap (fun x => x.2.completedAnswer) := by
        rw [hcomp_list]; exact List.mem_cons_self
      rcases List.mem_filterMap.mp hans_mem with ⟨x, hx_in, hx_ans⟩
      rcases List.mem_map.mp hx_in with ⟨sl, hsl_in, rfl⟩
      have hans_eq : ans = ((mkCert sl.gen).runQuery sl.bState sl.surviving sl.phase qLifted).answer := by
        unfold UL.CertifiedSearchGeneration.runQueryCapped at hx_ans
        dsimp only [] at hx_ans
        split_ifs at hx_ans with hle
        · exact (Option.some.inj hx_ans).symm
      rcases hsl_qspec sl hsl_in with ⟨_, _, _, _, _, hcorr_sl, _, _⟩
      rw [← hans_eq] at hcorr_sl
      rcases (hsls_mem sl hsl_in) with ⟨hsl_tbl, _, _⟩
      rcases hinv.slots_inv sl hsl_tbl with ⟨_, _, hsl_gh, hsl_pts, hsl_sub, _, _⟩
      refine ⟨?_, ?_, hcOuts_sp, hraceWork_le.trans (Nat.le_add_right _ _)⟩
      · intro i hi
        cases ans with
        | none => simp at hi
        | some p =>
          dsimp only [] at hi
          split_ifs at hi with hp_ok
          simp only [Option.some.injEq] at hi
          subst hi
          exact ⟨hinv.img_eq ▸ Finset.mem_image.mpr ⟨p, hS_grp_sub hp_ok.1, rfl⟩, hp_ok.2⟩
      · intro hnone p hp_grp
        cases ans with
        | some p' =>
          have hp'_valid : p' ∈ S_grp ∧ q.accept p'.1 := by
            simpa [UL.SearchGeneration.IsCorrectAnswer, UL.IsCorrectSearchAnswer,
              UL.IsValidSearchAnswer, UL.liftQueryToLifetimes] using hcorr_sl.1
          simp [hp'_valid] at hnone
        | none =>
          have hno_tgt := hcorr_sl.2 rfl
          intro hge
          apply hno_tgt
          refine ⟨p, hp_grp, ?_⟩
          have hp_P0 : p ∈ sl.gen.P₀ := hsl_sub ((hsls_mem sl hsl_in).2.2 ▸ hp_grp)
          simpa [hsl_gh, hsl_pts p hp_P0, UL.liftQueryToLifetimes] using hge
    | nil =>
      have hbad : IsBadGroup (mkCert g.gen) N cap (sls.map UL.HostedCertSlot.bState) := by
        refine ⟨q.z, hq_adm.1, ?_⟩
        intro b hb
        rcases List.mem_map.mp hb with ⟨sl, hsl_in, rfl⟩
        have hcOut_in : (sl.slotId,
            (mkCert sl.gen).runQueryCapped sl.bState sl.surviving sl.phase qLifted cap) ∈ cOuts :=
          List.mem_map_of_mem hsl_in
        have hca_none :
            ((mkCert sl.gen).runQueryCapped sl.bState sl.surviving sl.phase qLifted cap).completedAnswer =
              none := by
          cases hca : ((mkCert sl.gen).runQueryCapped sl.bState sl.surviving sl.phase qLifted cap).completedAnswer with
          | none => rfl
          | some a =>
            have ha_mem : a ∈ cOuts.filterMap (fun x => x.2.completedAnswer) :=
              List.mem_filterMap.mpr ⟨_, hcOut_in, hca⟩
            rw [hcomp_list] at ha_mem
            simp at ha_mem
        have hgt_cap : cap < ((mkCert sl.gen).runQuery sl.bState sl.surviving sl.phase qLifted).work := by
          unfold UL.CertifiedSearchGeneration.runQueryCapped at hca_none
          dsimp only [] at hca_none
          split_ifs at hca_none with hle
          omega
        have hgt_real : (cap : ℝ) <
            (((mkCert sl.gen).runQuery sl.bState sl.surviving sl.phase qLifted).work : ℝ) := by
          exact_mod_cast hgt_cap
        exact lt_of_lt_of_le hgt_real (hsl_qspec sl hsl_in).2.2.2.2.2.2.2
      have hcard_grp_le : S_grp.card ≤ n := by
        cases hsls_eq : sls with
        | nil => rw [hsls_eq, List.length_nil] at hsls_len_R; omega
        | cons sl₀ _ =>
          have hsl₀_in : sl₀ ∈ sls := hsls_eq ▸ List.mem_cons_self
          rcases hsl_qspec sl₀ hsl₀_in with ⟨_, _, hsurv0, hsub0, hmn0, _⟩
          have hc1 : S_grp.card ≤ sl₀.gen.P₀.card :=
            hsurv0 ▸ Finset.card_le_card hsub0
          exact hc1.trans hmn0
      refine ⟨?_, ?_, hcOuts_sp, ?_⟩
      · intro i hi
        dsimp only [] at hi
        split_ifs at hi with hex
        simp only [Option.some.injEq] at hi
        subst hi
        rcases Classical.choose_spec hex with ⟨hp_grp, hp_acc⟩
        exact ⟨hinv.img_eq ▸ Finset.mem_image.mpr ⟨_, hS_grp_sub hp_grp, rfl⟩, hp_acc⟩
      · intro hnone p hp_grp
        dsimp only [] at hnone
        have hno_acc : ¬ ∃ p' ∈ S_grp, q.accept p'.1 := by
          intro hex
          simp [hex] at hnone
        exact no_target_on_slice_of_no_accepted h_pos hinv.img_eq hS_grp_sub hq_adm.2 hno_acc hp_grp
      · simp only [decide_eq_true_eq.mpr hbad, ↓reduceIte]
        omega
  -- Global answer correctness on `hits.head?`
  have hcorr_global : UL.IsCorrectSearchAnswer pts S h q.z q.accept hits.head? := by
    unfold UL.IsCorrectSearchAnswer
    have hhits_eq : hits = (ctrl.groups.map resOf).filterMap (fun r => r.1) := by
      dsimp only [hits]
      rw [hgrpResults_eq]
    cases hhead : hits.head? with
    | some i =>
      have hi_mem : i ∈ hits := by
        cases hhits_c : hits with
        | nil => rw [hhits_c] at hhead; simp at hhead
        | cons hd _ =>
          rw [hhits_c] at hhead
          simp only [List.head?_cons, Option.some.injEq] at hhead
          subst hhead
          exact List.mem_cons_self
      rw [hhits_eq] at hi_mem
      rcases List.mem_filterMap.mp hi_mem with ⟨r, hr_in, hr_some⟩
      rcases List.mem_map.mp hr_in with ⟨g, hg, rfl⟩
      exact ⟨(heval_spec g hg).1 i hr_some, fun hnone => by simp at hnone⟩
    | none =>
      refine ⟨trivial, fun _ => ?_⟩
      rintro ⟨i, hi_S, hi_ge⟩
      rcases Finset.mem_image.mp (hinv.img_eq ▸ hi_S) with ⟨p, hp_act, rfl⟩
      have hp_lt_H : p.2 < H := hinv.lt_next p hp_act
      have hH_lt_pow : H < 2 ^ L_max :=
        lt_of_le_of_lt hinv.life_le_max (lt_two_pow_log_succ maxOps)
      rcases binInterval_exists_unique hH_lt_pow hp_lt_H with ⟨k, ⟨_, hk_bit, hk_lo, hk_hi⟩, _⟩
      rcases List.mem_map.mp ((hinv.level_mem_iff k).mpr hk_bit) with ⟨g, hg, rfl⟩
      have hp_grp : p ∈ binSlice tbl0.activeLifetimes H g.level :=
        Finset.mem_filter.mpr ⟨hp_act, hk_lo, hk_hi⟩
      have hres_none : (resOf g).1 = none := by
        cases hr1 : (resOf g).1 with
        | none => rfl
        | some j =>
          have hj_hits : j ∈ hits := by
            rw [hhits_eq]
            exact List.mem_filterMap.mpr ⟨resOf g, List.mem_map_of_mem hg, hr1⟩
          cases hhits_cases : hits with
          | nil => rw [hhits_cases] at hj_hits; simp at hj_hits
          | cons hd _ => rw [hhits_cases] at hhead; simp at hhead
      exact (heval_spec g hg).2.1 hres_none p hp_grp hi_ge
  -- Space & Invariant on `tbl'`
  have hallCOuts_sp : ∀ x ∈ allCOuts, (x.2.peakSpace : ℝ) ≤ 2 * facs.spaceBound n σ := by
    intro x hx
    dsimp only [allCOuts] at hx
    rw [hgrpResults_eq, List.map_map] at hx
    rcases List.mem_flatten.mp hx with ⟨l, hl_in, hx_l⟩
    rcases List.mem_map.mp hl_in with ⟨g, hg, rfl⟩
    exact (heval_spec g hg).2.2.1 x hx_l
  have hslots'_inv : ∀ sl' ∈ tbl'.slots, CertSlotInv n pts h σ facs mkCert sl' := by
    intro sl' hsl'
    rcases List.mem_map.mp hsl' with ⟨sl, hsl, rfl⟩
    rcases hinv.slots_inv sl hsl with
      ⟨hm1, hmn, hgh, hpts, hsub, hsp0, hacc⟩
    refine ⟨hm1, hmn, hgh, hpts, hsub, ?_, hacc⟩
    refine foldl_max_le_cg (allCOuts.filter (fun x => x.1 = sl.slotId))
      (fun x : ℕ × UL.CappedCertifiedQueryOutcome (ι × ℕ) => x.2.peakSpace)
      sl.spaceAlloc (2 * facs.spaceBound n σ) hsp0 ?_
    intro x hx
    exact hallCOuts_sp x (List.mem_of_mem_filter hx)
  have hmap_id' : tbl'.slots.map UL.HostedCertSlot.slotId = tbl0.slots.map UL.HostedCertSlot.slotId := by
    dsimp only [tbl', slots']
    rw [List.map_map]
    rfl
  have hinv' : CertTableInv n maxOps R pts h σ facs mkCert S
      { groups := ctrl.groups, queue := none } tbl' :=
    { queue_none := rfl
      img_eq := hinv.img_eq
      card_eq := hinv.card_eq
      lt_next := hinv.lt_next
      unit_active := hinv.unit_active
      life_le_max := hinv.life_le_max
      levels_nodup := hinv.levels_nodup
      level_mem_iff := hinv.level_mem_iff
      slotIds_eq := hmap_id'.trans hinv.slotIds_eq
      slotIds_nodup := hmap_id' ▸ hinv.slotIds_nodup
      slotIds_lt := by
        intro sl' hsl'
        rcases List.mem_map.mp hsl' with ⟨sl, hsl, rfl⟩
        exact hinv.slotIds_lt sl hsl
      slots_inv := hslots'_inv
      groups_inv := by
        intro g hg
        rcases hinv.groups_inv g hg with ⟨hg_nd, hg_len, hg_m1, hg_mn, hg_h, hg_pts, hg_sl⟩
        refine ⟨hg_nd, hg_len, hg_m1, hg_mn, hg_h, hg_pts, ?_⟩
        intro sid hsid sl' hsl' hid
        rcases List.mem_map.mp hsl' with ⟨sl, hsl, rfl⟩
        exact hg_sl sid hsid sl hsl hid }
  have hsp0_le : (tbl0.currentSpace : ℝ) ≤
      (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ :=
    hinv.currentSpace_le hσθ.1 hσθ.2.1 hfacs hS_le
  have hsp'_le : (tbl'.currentSpace : ℝ) ≤
      (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ :=
    hinv'.currentSpace_le hσθ.1 hσθ.2.1 hfacs hS_le
  have hpeak_le : (out_q.peakSpace : ℝ) ≤
      (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ := by
    dsimp only [out_q]
    rw [Nat.cast_max]
    exact max_le hsp0_le hsp'_le
  refine ⟨?_, ?_, ?_⟩
  · unfold UL.singleDynamicSearchStepHaltProb
    rw [← haltProb_endWithEmpty (S, out_q)]
    unfold haltProb
    refine tsum_congr fun bs => ?_
    rw [congrFun hstepFn_eq bs]
  · intro bs S' out hstep
    rw [congrFun hstepFn_eq bs] at hstep
    rcases endWithEmpty_eq_some_iff.mp hstep with ⟨_, heq⟩
    rcases Prod.mk.injEq _ _ _ _ |>.mp heq.symm with ⟨rfl, rfl⟩
    exact ⟨rfl, rfl, hinv', hpeak_le, hits.head?, rfl, hcorr_global⟩
  · intro rem
    rw [hstepFn_eq, expWithBits_endWithEmpty]
    have hpot_eq : slotPot mkCert tbl' = slotPot mkCert tbl0 := by
      unfold slotPot
      dsimp only [tbl', slots']
      rw [List.map_map]
      rfl
    have hbg_eq : badGroupCount N cap mkCert ctrl.groups tbl' =
        badGroupCount N cap mkCert ctrl.groups tbl0 :=
      badGroupCount_map_congr N cap mkCert ctrl.groups tbl0 _ (fun _ _ => ⟨rfl, rfl⟩)
    have htotW_le : totalQWork ≤
        L_max * (R * (cap + 1)) + (n + 1) * badGroupCount N cap mkCert ctrl.groups tbl0 := by
      have htot_eq : totalQWork = (ctrl.groups.map (fun g => (resOf g).2.1)).sum := by
        dsimp only [totalQWork]
        rw [hgrpResults_eq, List.map_map]
        rfl
      rw [htot_eq]
      have hsum1 := sum_le_mul_add_filter_cg ctrl.groups
        (fun g => (resOf g).2.1)
        (fun g => decide (IsBadGroup (mkCert g.gen) N cap
          ((groupSlots tbl0 g.sids).map UL.HostedCertSlot.bState)))
        (R * (cap + 1)) (n + 1)
        (fun g hg => (heval_spec g hg).2.2.2)
      have hlen_g : ctrl.groups.length ≤ L_max := hinv.groups_length_le
      have hmul_le : ctrl.groups.length * (R * (cap + 1)) ≤ L_max * (R * (cap + 1)) :=
        Nat.mul_le_mul_right _ hlen_g
      unfold badGroupCount
      omega
    have houtW_le : ((out_q.work : ENNReal)) ≤
        ((L_max * R * (cap + 1) + 2 : ℕ) : ENNReal) +
          (((n + 1) * badGroupCount N cap mkCert ctrl.groups tbl0 : ℕ) : ENNReal) := by
      have hw_nat : out_q.work ≤
          (L_max * R * (cap + 1) + 2) +
            (n + 1) * badGroupCount N cap mkCert ctrl.groups tbl0 := by
        dsimp only [out_q]
        have hassoc : L_max * (R * (cap + 1)) = L_max * R * (cap + 1) := by ring
        omega
      exact_mod_cast hw_nat
    dsimp only [out_q]
    unfold certPhi
    rw [hpot_eq, hbg_eq]
    have hact_eq : tbl'.activeLifetimes = tbl0.activeLifetimes := rfl
    have hnl_eq : tbl'.nextLifetime = tbl0.nextLifetime := rfl
    rw [hact_eq, hnl_eq]
    have hrem_split :
        (((n + 1) * badGroupCount N cap mkCert ctrl.groups tbl0 : ℕ) : ENNReal) +
          ((rem * (n + 1) : ℕ) : ENNReal) *
            (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) =
        (((rem + 1) * (n + 1) : ℕ) : ENNReal) *
          (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) := by
      push_cast
      ring
    calc
      ((1 + totalQWork + 1 : ℕ) : ENNReal) +
        (slotPot mkCert tbl0 +
          ((rem * (n + 1) : ℕ) : ENNReal) *
            (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) +
          (elemCredit L_max tbl0.activeLifetimes tbl0.nextLifetime : ENNReal) *
            ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2)))
          ≤ (((L_max * R * (cap + 1) + 2 : ℕ) : ENNReal) +
              (((n + 1) * badGroupCount N cap mkCert ctrl.groups tbl0 : ℕ) : ENNReal)) +
            (slotPot mkCert tbl0 +
              ((rem * (n + 1) : ℕ) : ENNReal) *
                (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) +
              (elemCredit L_max tbl0.activeLifetimes tbl0.nextLifetime : ENNReal) *
                ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2))) :=
            add_le_add houtW_le le_rfl
      _ = slotPot mkCert tbl0 +
            ((((n + 1) * badGroupCount N cap mkCert ctrl.groups tbl0 : ℕ) : ENNReal) +
              ((rem * (n + 1) : ℕ) : ENNReal) *
                (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal)) +
            (elemCredit L_max tbl0.activeLifetimes tbl0.nextLifetime : ENNReal) *
              ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2)) +
            ((L_max * R * (cap + 1) + 2 : ℕ) : ENNReal) := by ring
      _ = (slotPot mkCert tbl0 +
            (((rem + 1) * (n + 1) : ℕ) : ENNReal) *
              (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) +
            (elemCredit L_max tbl0.activeLifetimes tbl0.nextLifetime : ENNReal) *
              ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2))) +
            ((L_max * R * (cap + 1) + 2 : ℕ) : ENNReal) := by rw [hrem_split]

end UL.Proof_lem_7_1_RaceV31
