import Mathlib
import UL.Stmt.lem_7_1
import UL.Proof.lem_7_1.RaceV31_H1_Coins
import UL.Proof.lem_7_1.RaceV31_H2_Dyadic
import UL.Proof.lem_7_1.RaceV31_H3a_MCStep
import UL.Proof.lem_7_1.RaceV31_H3b_MCIns
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. Injectivity on `Prod.fst` and `Forall₂` Membership Helpers -/

theorem injOn_of_card_image_eq {α β : Type*} [DecidableEq α] [DecidableEq β]
    {A : Finset α} {f : α → β} (hcard : (A.image f).card = A.card)
    {x y : α} (hx : x ∈ A) (hy : y ∈ A) (hfx : f x = f y) : x = y := by
  by_contra hne
  let A' := A.erase x
  have hy' : y ∈ A' := Finset.mem_erase.mpr ⟨Ne.symm hne, hy⟩
  have hfx_mem : f x ∈ A'.image f := Finset.mem_image.mpr ⟨y, hy', hfx.symm⟩
  have himg_eq : A.image f = A'.image f := by
    have h1 : A = insert x A' := (Finset.insert_erase hx).symm
    conv_lhs => rw [h1, Finset.image_insert]
    exact Finset.insert_eq_of_mem hfx_mem
  have hle1 : (A'.image f).card ≤ A'.card := Finset.card_image_le
  have hpos : 1 ≤ A.card := Finset.card_pos.mpr ⟨x, hx⟩
  have herase : A'.card = A.card - 1 := Finset.card_erase_of_mem hx
  have hce : (A.image f).card = (A'.image f).card := congrArg Finset.card himg_eq
  omega

theorem forall₂_mem_right {α β : Type*} {R : α → β → Prop}
    {as : List α} {bs : List β} (hrel : List.Forall₂ R as bs)
    {b : β} (hb : b ∈ bs) : ∃ a ∈ as, R a b := by
  induction hrel with
  | nil => simp at hb
  | @cons a₀ b₀ _ _ hh _ ih =>
    rcases List.mem_cons.mp hb with rfl | htl
    · exact ⟨a₀, by simp, hh⟩
    · rcases ih htl with ⟨a, ha, hr⟩
      exact ⟨a, by simp [ha], hr⟩

theorem forall₂_mem_left {α β : Type*} {R : α → β → Prop}
    {as : List α} {bs : List β} (hrel : List.Forall₂ R as bs)
    {a : α} (ha : a ∈ as) : ∃ b ∈ bs, R a b := by
  induction hrel with
  | nil => simp at ha
  | @cons a₀ b₀ _ _ hh _ ih =>
    rcases List.mem_cons.mp ha with rfl | htl
    · exact ⟨b₀, by simp, hh⟩
    · rcases ih htl with ⟨b, hb, hr⟩
      exact ⟨b, by simp [hb], hr⟩

/-! ### 2. Deletion Queue Execution & `.delete` Step Specification -/

def DelStageSlotInv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h σ θ : ℝ)
    (facs : UL.BirthPoolPolyFactors)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I)
    (A₀ A₁ : Finset (ι × ℕ)) (tc : ℕ) (id₀ : ι)
    (pairs : List (ℕ × (ι × ℕ)))
    (m : MCSlotMeta) (sl : UL.HostedMCSlot ι d_s B I) : Prop :=
  m.slotId = sl.slotId ∧
  1 ≤ sl.gen.m ∧ sl.gen.m ≤ n ∧
  sl.gen.h = h ∧
  (∀ p ∈ sl.gen.P₀, sl.gen.pts p = pts p.1) ∧
  (if sl.slotId ∈ pairs.map Prod.fst then
    ∃ rec, (sl.slotId, rec) ∈ pairs ∧ rec ∈ sl.surviving ∧ rec.1 = id₀ ∧
      sl.surviving = A₀.filter (fun p => m.j * 2 ^ m.k ≤ p.2 ∧ p.2 < (m.j + 1) * 2 ^ m.k)
   else
    sl.surviving = A₁.filter (fun p => m.j * 2 ^ m.k ≤ p.2 ∧ p.2 < (m.j + 1) * 2 ^ m.k)) ∧
  sl.surviving ⊆ sl.gen.P₀ ∧
  (∃ birthHist, (mkMC sl.gen).IsValidState birthHist sl.bState sl.surviving sl.idxState) ∧
  sl.unpaidWork ≤ ((m.j + 2) * 2 ^ m.k - tc) * unitBuildBudget n θ facs ∧
  (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ

theorem validMCTable_of_delStage {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)} {h σ θ : ℝ}
    {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    {A₀ A₁ : Finset (ι × ℕ)} {tc : ℕ} {id₀ : ι}
    {pairs : List (ℕ × (ι × ℕ))} {ms : List MCSlotMeta}
    {tbl : UL.HostedMCTable ι d_s B I}
    (hrel : List.Forall₂ (DelStageSlotInv n pts h σ θ facs mkMC A₀ A₁ tc id₀ pairs) ms tbl.slots) :
    ValidMCTable n h mkMC tbl := by
  intro sl hsl
  rcases forall₂_mem_right hrel hsl with ⟨_, _, hh⟩
  exact ⟨hh.2.2.1, hh.2.2.2.1, hh.2.2.2.2.2.2.1, hh.2.2.2.2.2.2.2.1⟩

theorem delStage_nil_iff_mcSlotInv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)} {h σ θ : ℝ}
    {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    {A₀ A₁ : Finset (ι × ℕ)} {tc : ℕ} {id₀ : ι}
    (m : MCSlotMeta) (sl : UL.HostedMCSlot ι d_s B I) :
    DelStageSlotInv n pts h σ θ facs mkMC A₀ A₁ tc id₀ [] m sl ↔
      MCSlotInv n pts h σ θ facs mkMC A₁ tc m sl := by
  unfold DelStageSlotInv MCSlotInv
  simp

theorem runDelFinish_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n K : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    (extHist : UL.ExecutionHistory d)
    {A₀ : Finset (ι × ℕ)}
    (hinj_fst : ∀ r₁ ∈ A₀, ∀ r₂ ∈ A₀, r₁.1 = r₂.1 → r₁ = r₂)
    (id₀ : ι) (metas : List MCSlotMeta) :
    ∀ (pairs : List (ℕ × (ι × ℕ))) (fuel : ℕ)
      (tbl : UL.HostedMCTable ι d_s B I) (accWork peakSp : ℕ),
      tbl.activeLifetimes = A₀.filter (fun p => p.1 ≠ id₀) →
      tbl.activeLifetimes.card ≤ n →
      metas.length ≤ K →
      (pairs.map Prod.fst).Nodup →
      (∀ sid ∈ pairs.map Prod.fst, sid ∈ tbl.slots.map UL.HostedMCSlot.slotId) →
      List.Forall₂
        (DelStageSlotInv n pts h σ θ facs mkMC A₀ tbl.activeLifetimes (tbl.nextLifetime + 1) id₀ pairs)
        metas tbl.slots →
      (tbl.slots.map UL.HostedMCSlot.slotId).Nodup →
      (∀ sl ∈ tbl.slots, sl.slotId < tbl.nextSlotId) →
      tbl.currentSpace ≤ peakSp →
      (peakSp : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ →
      haltProb (fun bs =>
        UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
          extHist (.delete id₀) (2 * pairs.length + 1 + fuel)
          { metas := metas, queue := some
              ((pairs.flatMap fun pair =>
                [PlannedMCCmd.deleteFromSlot pair.1 pair.2,
                 PlannedMCCmd.payWork pair.1 (delBudget n θ facs)]) ++
               [PlannedMCCmd.finishUpdate]) }
          tbl bs accWork peakSp) = 1 ∧
      (∀ bs out,
        UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
          extHist (.delete id₀) (2 * pairs.length + 1 + fuel)
          { metas := metas, queue := some
              ((pairs.flatMap fun pair =>
                [PlannedMCCmd.deleteFromSlot pair.1 pair.2,
                 PlannedMCCmd.payWork pair.1 (delBudget n θ facs)]) ++
               [PlannedMCCmd.finishUpdate]) }
          tbl bs accWork peakSp = some out →
        out.queryAnswer = none ∧
        out.nextState.1 = { metas := metas, queue := none } ∧
        out.nextState.2.activeLifetimes = tbl.activeLifetimes ∧
        out.nextState.2.nextLifetime = tbl.nextLifetime ∧
        (out.nextState.2.slots.map UL.HostedMCSlot.slotId).Nodup ∧
        (∀ sl ∈ out.nextState.2.slots, sl.slotId < out.nextState.2.nextSlotId) ∧
        List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl.activeLifetimes (tbl.nextLifetime + 1))
          metas out.nextState.2.slots ∧
        out.work ≤ accWork + pairs.length * (delBudget n θ facs + 2) + 1 ∧
        (out.peakSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ ∧
        (AllSlotsGood mkMC tbl → AllSlotsGood mkMC out.nextState.2)) := by
  intro pairs
  induction pairs with
  | nil =>
    intro fuel tbl accWork peakSp _ _ _ _ _ hrel hnodup hsid_lt hsp_le hpeak_real
    have hv : ValidMCTable n h mkMC tbl := validMCTable_of_delStage hrel
    have hfuel : 2 * ([] : List (ℕ × (ι × ℕ))).length + 1 + fuel = fuel + 1 := by simp; omega
    let out₀ : UL.DynamicSearchStepOutcome (MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I) ι :=
      { nextState := ({ metas := metas, queue := none }, tbl)
        queryAnswer := none
        work := accWork + 1
        peakSpace := peakSp }
    have hfun_eq :
        (fun bs =>
          UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
            extHist (.delete id₀) (2 * ([] : List (ℕ × (ι × ℕ))).length + 1 + fuel)
            { metas := metas, queue := some
                ((([] : List (ℕ × (ι × ℕ))).flatMap fun pair =>
                  [PlannedMCCmd.deleteFromSlot pair.1 pair.2,
                   PlannedMCCmd.payWork pair.1 (delBudget n θ facs)]) ++
                 [PlannedMCCmd.finishUpdate]) }
            tbl bs accWork peakSp) = endWithEmpty out₀ := by
      funext bs
      simp only [List.flatMap_nil, List.nil_append]
      rw [hfuel]
      exact runFinishUpdate_eq extHist (.delete id₀) trivial metas fuel tbl bs accWork peakSp hv hsp_le
    refine ⟨by rw [hfun_eq]; exact haltProb_endWithEmpty out₀, ?_⟩
    intro bs out hout
    have hout' : endWithEmpty out₀ bs = some out := by
      rw [← hfun_eq]
      exact hout
    rcases (endWithEmpty_eq_some_iff.mp hout') with ⟨_, rfl⟩
    have hrel_mc : List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl.activeLifetimes (tbl.nextLifetime + 1))
        metas tbl.slots := by
      have haux : ∀ ms sls,
          List.Forall₂ (DelStageSlotInv n pts h σ θ facs mkMC A₀ tbl.activeLifetimes (tbl.nextLifetime + 1) id₀ []) ms sls →
          List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl.activeLifetimes (tbl.nextLifetime + 1)) ms sls := by
        intro ms sls hr
        induction hr with
        | nil => exact List.Forall₂.nil
        | @cons m sl _ _ hh _ ihr =>
          exact List.Forall₂.cons ((delStage_nil_iff_mcSlotInv m sl).mp hh) ihr
      exact haux metas tbl.slots hrel
    exact ⟨rfl, rfl, rfl, rfl, hnodup, hsid_lt, hrel_mc, by simp [out₀], hpeak_real, fun hg => hg⟩
  | cons hd pairs ih =>
    rcases hd with ⟨sid, rec⟩
    intro fuel tbl accWork peakSp hA1_eq hact_le hlen_K hnod_pairs hpairs_mem hrel hnodup hsid_lt hsp_le hpeak_real
    let dBud := delBudget n θ facs
    let remCmds : List (PlannedMCCmd ι d_s) :=
      (pairs.flatMap fun pair =>
        [PlannedMCCmd.deleteFromSlot pair.1 pair.2,
         PlannedMCCmd.payWork pair.1 dBud]) ++
      [PlannedMCCmd.finishUpdate]
    rw [List.map_cons, List.nodup_cons] at hnod_pairs
    rcases hnod_pairs with ⟨hsid_notin_pairs, hnod_pairs_tl⟩
    have hsid_in_slots : sid ∈ tbl.slots.map UL.HostedMCSlot.slotId :=
      hpairs_mem sid (by simp)
    rcases List.mem_map.mp hsid_in_slots with ⟨sl, hsl_mem, hsl_id⟩
    rcases forall₂_mem_right hrel hsl_mem with ⟨m₀, _, hslot_inv⟩
    rcases hslot_inv with ⟨_, hm1, hmn, hh_eq, hpts_s, hsurv_branch, hsub_P0, ⟨birthHist, hval⟩, hun_s, hsp_s⟩
    have hsl_in_hd : sl.slotId ∈ ((sid, rec) :: pairs).map Prod.fst := by simp [hsl_id]
    rw [if_pos hsl_in_hd] at hsurv_branch
    rcases hsurv_branch with ⟨rec', hrec'_mem, hrec'_surv, hrec'_id, _⟩
    have hrec_eq : rec' = rec := by
      rcases List.mem_cons.mp hrec'_mem with heq | htl
      · exact (Prod.mk.inj heq).2
      · exfalso
        have hmem_fst : sl.slotId ∈ pairs.map Prod.fst := List.mem_map_of_mem htl
        rw [hsl_id] at hmem_fst
        exact hsid_notin_pairs hmem_fst
    subst rec'
    have hrec_not_A1 : rec ∉ tbl.activeLifetimes := by
      rw [hA1_eq, Finset.mem_filter]
      intro hmem
      exact hmem.2 hrec'_id
    have hv_tbl : ValidMCTable n h mkMC tbl := validMCTable_of_delStage hrel
    rcases hMC sl.gen hmn hh_eq with ⟨hgen_eq, hunif_all⟩
    have hunif := hunif_all birthHist
    have hsurv_sub : (mkMC sl.gen).gen.IsSurvivingSubset sl.surviving := by
      unfold UL.SearchGeneration.IsSurvivingSubset
      rwa [hgen_eq]
    rcases ((hunif.2.2.1).2.2.2.2.2.1 extHist sl.bState sl.surviving sl.idxState rec hsurv_sub hval hrec'_surv) with
      ⟨hpf_del_raw, hhalt_del, hd_caps⟩
    have hpf_del : IsPrefixFree ((mkMC sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.idxState rec) :=
      hpf_del_raw
    let mkSl₁ := fun (dOut : UL.MCDeleteOutcome I) =>
      ({ sl with
         surviving := sl.surviving.erase rec
         idxState := dOut.nextState
         unpaidWork := sl.unpaidWork + dOut.work
         spaceAlloc := max sl.spaceAlloc dOut.peakSpace } : UL.HostedMCSlot ι d_s B I)
    let mkTbl₁ := fun (dOut : UL.MCDeleteOutcome I) =>
      ({ tbl with
         slots := open Classical in tbl.slots.map (fun s => if s.slotId = sid then mkSl₁ dOut else s) } :
        UL.HostedMCTable ι d_s B I)
    let mkPaid := fun (dOut : UL.MCDeleteOutcome I) =>
      min dBud (sl.unpaidWork + dOut.work)
    let mkSl₂ := fun (dOut : UL.MCDeleteOutcome I) =>
      ({ mkSl₁ dOut with
         unpaidWork := (sl.unpaidWork + dOut.work) - mkPaid dOut } : UL.HostedMCSlot ι d_s B I)
    let mkTbl₂ := fun (dOut : UL.MCDeleteOutcome I) =>
      ({ tbl with
         slots := open Classical in (mkTbl₁ dOut).slots.map (fun s => if s.slotId = sid then mkSl₂ dOut else s) } :
        UL.HostedMCTable ι d_s B I)
    let mkPeak₁ := fun (dOut : UL.MCDeleteOutcome I) =>
      max peakSp (mkTbl₁ dOut).currentSpace
    let mkPeak₂ := fun (dOut : UL.MCDeleteOutcome I) =>
      max (mkPeak₁ dOut) (mkTbl₂ dOut).currentSpace
    let g := fun (dOut : UL.MCDeleteOutcome I) (rem' : List Bool) =>
      UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
        extHist (.delete id₀) (2 * pairs.length + 1 + fuel)
        { metas := metas, queue := some remCmds }
        (mkTbl₂ dOut) rem' (accWork + 1 + mkPaid dOut + 1) (mkPeak₂ dOut)
    have hfind0 : (open Classical in tbl.slots.find? (fun s => s.slotId = sid)) = some sl := by
      refine find?_slotId_of_nodup hnodup hsl_mem _ (fun s _ => ?_)
      rw [decide_eq_true_eq, hsl_id]
    have hf_eq :
        (fun bs =>
          UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
            extHist (.delete id₀) (2 * ((sid, rec) :: pairs).length + 1 + fuel)
            { metas := metas, queue := some
                ((((sid, rec) :: pairs).flatMap fun pair =>
                  [PlannedMCCmd.deleteFromSlot pair.1 pair.2,
                   PlannedMCCmd.payWork pair.1 dBud]) ++
                 [PlannedMCCmd.finishUpdate]) }
            tbl bs accWork peakSp) =
        seqConsume ((mkMC sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.idxState rec) g := by
      funext bs
      have hfuel2 : 2 * ((sid, rec) :: pairs).length + 1 + fuel =
          ((2 * pairs.length + 1 + fuel) + 1) + 1 := by simp; omega
      rw [hfuel2]
      conv_lhs => unfold UL.runMCHostedStepFuel
      have hcmd1 : mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC (.delete id₀)
          { metas := metas, queue := some
              ((((sid, rec) :: pairs).flatMap fun pair =>
                [PlannedMCCmd.deleteFromSlot pair.1 pair.2,
                 PlannedMCCmd.payWork pair.1 dBud]) ++
               [PlannedMCCmd.finishUpdate]) } tbl =
          .deleteFromSlot sid rec
            { metas := metas, queue := some (PlannedMCCmd.payWork sid dBud :: remCmds) } := by
        unfold mcStepCtrl
        simp [hv_tbl, dispatchMCQueue, remCmds, dBud]
      rw [hcmd1]
      dsimp only []
      rw [hfind0]
      dsimp only []
      rw [if_pos ⟨hrec'_surv, hrec_not_A1⟩]
      unfold seqConsume
      cases hc : UL.consumePrefixBits
          ((mkMC sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.idxState rec) bs with
      | none => rfl
      | some pair =>
        rcases pair with ⟨dOut, rem'⟩
        rcases (consumePrefixBits_eq_some_iff hpf_del).mp hc with ⟨u, _, hdel_u⟩
        rcases hd_caps u dOut hdel_u with ⟨hd_val, _, _⟩
        have hv1 : ValidMCTable n h mkMC (mkTbl₁ dOut) := by
          intro s' hs'
          rcases List.mem_map.mp hs' with ⟨s, hs, hs'_eq⟩
          classical
          by_cases heq : s.slotId = sid
          · rw [if_pos heq] at hs'_eq
            subst hs'_eq
            exact ⟨hmn, hh_eq, (Finset.erase_subset _ _).trans hsub_P0, ⟨birthHist, hd_val⟩⟩
          · rw [if_neg heq] at hs'_eq
            subst hs'_eq
            exact hv_tbl s hs
        have hnod1 : ((mkTbl₁ dOut).slots.map UL.HostedMCSlot.slotId).Nodup := by
          have hmap1 : (mkTbl₁ dOut).slots.map UL.HostedMCSlot.slotId =
              tbl.slots.map UL.HostedMCSlot.slotId := by
            dsimp only [mkTbl₁]
            rw [List.map_map]
            apply List.map_congr_left
            intro s _
            dsimp only [Function.comp]
            classical
            by_cases heq : s.slotId = sid
            · simp [heq, mkSl₁, hsl_id]
            · simp [heq]
          rwa [hmap1]
        have hsl1_mem : mkSl₁ dOut ∈ (mkTbl₁ dOut).slots := by
          dsimp only [mkTbl₁]
          refine List.mem_map.mpr ⟨sl, hsl_mem, ?_⟩
          classical
          simp [hsl_id]
        have hfind1 : (open Classical in (mkTbl₁ dOut).slots.find? (fun s => s.slotId = sid)) =
            some (mkSl₁ dOut) := by
          refine find?_slotId_of_nodup hnod1 hsl1_mem _ (fun s _ => ?_)
          rw [decide_eq_true_eq]
          dsimp only [mkSl₁]
          rw [hsl_id]
        change UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
          extHist (.delete id₀) ((2 * pairs.length + 1 + fuel) + 1)
          { metas := metas, queue := some (PlannedMCCmd.payWork sid dBud :: remCmds) }
          (mkTbl₁ dOut) rem' (accWork + 1) (mkPeak₁ dOut) = g dOut rem'
        conv_lhs => unfold UL.runMCHostedStepFuel
        have hcmd2 : mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC (.delete id₀)
            { metas := metas, queue := some (PlannedMCCmd.payWork sid dBud :: remCmds) }
            (mkTbl₁ dOut) =
            .payWork sid dBud { metas := metas, queue := some remCmds } := by
          unfold mcStepCtrl
          simp [hv1, dispatchMCQueue]
        rw [hcmd2]
        dsimp only []
        rw [hfind1]
    have h_ih : ∀ bs₁ dOut,
        (mkMC sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.idxState rec bs₁ = some dOut →
        haltProb (g dOut) = 1 ∧
        (∀ bs₂ out, g dOut bs₂ = some out →
          out.queryAnswer = none ∧
          out.nextState.1 = { metas := metas, queue := none } ∧
          out.nextState.2.activeLifetimes = tbl.activeLifetimes ∧
          out.nextState.2.nextLifetime = tbl.nextLifetime ∧
          (out.nextState.2.slots.map UL.HostedMCSlot.slotId).Nodup ∧
          (∀ s ∈ out.nextState.2.slots, s.slotId < out.nextState.2.nextSlotId) ∧
          List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl.activeLifetimes (tbl.nextLifetime + 1))
            metas out.nextState.2.slots ∧
          out.work ≤ (accWork + 1 + mkPaid dOut + 1) + pairs.length * (dBud + 2) + 1 ∧
          (out.peakSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ ∧
          (AllSlotsGood mkMC tbl → AllSlotsGood mkMC out.nextState.2)) := by
      intro bs₁ dOut hdel
      rcases hd_caps bs₁ dOut hdel with ⟨hd_val, hd_work, hd_sp_raw⟩
      have hd_sp : (dOut.peakSpace : ℝ) ≤ facs.spaceBound sl.gen.m σ := by
        rwa [hgen_eq] at hd_sp_raw
      have hslots2_eq : (mkTbl₂ dOut).slots =
          open Classical in tbl.slots.map (fun s => if s.slotId = sid then mkSl₂ dOut else s) := by
        dsimp only [mkTbl₂, mkTbl₁]
        rw [List.map_map]
        apply List.map_congr_left
        intro s _
        dsimp only [Function.comp]
        classical
        by_cases heq : s.slotId = sid
        · simp [heq, mkSl₁, hsl_id]
        · simp [heq]
      have hmap2_id : (mkTbl₂ dOut).slots.map UL.HostedMCSlot.slotId =
          tbl.slots.map UL.HostedMCSlot.slotId := by
        rw [hslots2_eq, List.map_map]
        apply List.map_congr_left
        intro s _
        dsimp only [Function.comp]
        classical
        by_cases heq : s.slotId = sid
        · simp [heq, mkSl₂, mkSl₁, hsl_id]
        · simp [heq]
      have hnodup2 : ((mkTbl₂ dOut).slots.map UL.HostedMCSlot.slotId).Nodup := by
        rwa [hmap2_id]
      have hsid_lt2 : ∀ s ∈ (mkTbl₂ dOut).slots, s.slotId < (mkTbl₂ dOut).nextSlotId := by
        intro s hs
        have hmem_id : s.slotId ∈ (mkTbl₂ dOut).slots.map UL.HostedMCSlot.slotId := List.mem_map_of_mem hs
        rw [hmap2_id] at hmem_id
        rcases List.mem_map.mp hmem_id with ⟨s0, hs0, hid0⟩
        rw [← hid0]
        exact hsid_lt s0 hs0
      have hd_work_nat : dOut.work ≤ dBud := by
        have hlt : facs.deleteWorkBound n θ ≤ (Nat.ceil (facs.deleteWorkBound n θ) : ℝ) := Nat.le_ceil _
        have hle_real : (dOut.work : ℝ) ≤ (dBud : ℝ) := by
          dsimp only [dBud]
          unfold delBudget
          push_cast
          linarith
        exact_mod_cast hle_real
      have hsl2_unpaid : (mkSl₂ dOut).unpaidWork ≤ sl.unpaidWork := by
        dsimp only [mkSl₂, mkSl₁, mkPaid]
        omega
      have hsl2_sp : ((mkSl₂ dOut).spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := by
        dsimp only [mkSl₂, mkSl₁]
        rw [Nat.cast_max]
        refine max_le hsp_s ?_
        have hsp_m : facs.spaceBound sl.gen.m σ ≤ facs.spaceBound n σ :=
          spaceBound_mono_le hmn hσθ.2.1 hfacs
        have hsp_nn : 0 ≤ facs.spaceBound n σ :=
          le_trans zero_le_one (spaceBound_ge_one hσθ.1 hσθ.2.1 hfacs)
        linarith
      have hrel2 : List.Forall₂
          (DelStageSlotInv n pts h σ θ facs mkMC A₀ (mkTbl₂ dOut).activeLifetimes
            ((mkTbl₂ dOut).nextLifetime + 1) id₀ pairs)
          metas (mkTbl₂ dOut).slots := by
        rw [hslots2_eq]
        have haux : ∀ ms sls,
            (∀ s ∈ sls, s ∈ tbl.slots) →
            List.Forall₂
              (DelStageSlotInv n pts h σ θ facs mkMC A₀ tbl.activeLifetimes
                (tbl.nextLifetime + 1) id₀ ((sid, rec) :: pairs)) ms sls →
            List.Forall₂
              (DelStageSlotInv n pts h σ θ facs mkMC A₀ tbl.activeLifetimes
                (tbl.nextLifetime + 1) id₀ pairs) ms
              (open Classical in sls.map (fun s => if s.slotId = sid then mkSl₂ dOut else s)) := by
          intro ms sls hsls_sub hr
          induction hr with
          | nil => exact List.Forall₂.nil
          | @cons m s ms' sls' hh _ ihr =>
            simp only [List.map_cons]
            refine List.Forall₂.cons ?_ (ihr (fun s' hs' => hsls_sub s' (by simp [hs'])))
            classical
            by_cases heq : s.slotId = sid
            · simp only [if_pos heq]
              have hs_eq : s = sl :=
                eq_of_mem_of_slotId_eq hnodup (hsls_sub s (by simp)) hsl_mem (heq.trans hsl_id.symm)
              rcases hh with ⟨hmid, _, _, _, _, hbr, _, _, hun_m, _⟩
              rw [hs_eq] at hmid hbr hun_m
              rw [if_pos hsl_in_hd] at hbr
              rcases hbr with ⟨_, _, _, _, hsurv_m⟩
              have herase_m : sl.surviving.erase rec =
                  tbl.activeLifetimes.filter (fun p => m.j * 2 ^ m.k ≤ p.2 ∧ p.2 < (m.j + 1) * 2 ^ m.k) := by
                rw [hA1_eq]
                ext p
                simp only [Finset.mem_erase, Finset.mem_filter]
                constructor
                · rintro ⟨hne, hp_surv⟩
                  rw [hsurv_m, Finset.mem_filter] at hp_surv
                  refine ⟨⟨hp_surv.1, fun hp_id => hne ?_⟩, hp_surv.2⟩
                  have hrec_A0 : rec ∈ A₀ := by
                    rw [hsurv_m, Finset.mem_filter] at hrec'_surv
                    exact hrec'_surv.1
                  exact hinj_fst p hp_surv.1 rec hrec_A0 (hp_id.trans hrec'_id.symm)
                · rintro ⟨⟨hp_A0, hp_ne⟩, hb⟩
                  refine ⟨fun heq_p => hp_ne (heq_p ▸ hrec'_id), ?_⟩
                  rw [hsurv_m, Finset.mem_filter]
                  exact ⟨hp_A0, hb⟩
              refine ⟨hmid, hm1, hmn, hh_eq, hpts_s, ?_,
                (Finset.erase_subset _ _).trans hsub_P0, ⟨birthHist, hd_val⟩,
                hsl2_unpaid.trans hun_m, hsl2_sp⟩
              dsimp only [mkSl₂, mkSl₁]
              rw [hsl_id, if_neg hsid_notin_pairs]
              exact herase_m
            · simp only [if_neg heq]
              rcases hh with ⟨hmid, hm1', hmn', hh_eq', hpts', hbr, hsub', hval', hun', hsp'⟩
              refine ⟨hmid, hm1', hmn', hh_eq', hpts', ?_, hsub', hval', hun', hsp'⟩
              by_cases hmem_tl : s.slotId ∈ pairs.map Prod.fst
              · have hmem_cons : s.slotId ∈ ((sid, rec) :: pairs).map Prod.fst := by simp [hmem_tl]
                rw [if_pos hmem_cons] at hbr
                rw [if_pos hmem_tl]
                rcases hbr with ⟨r0, hr0_mem, hr0_surv, hr0_id, hsurv0⟩
                refine ⟨r0, ?_, hr0_surv, hr0_id, hsurv0⟩
                rcases List.mem_cons.mp hr0_mem with hr0_hd | hr0_tl
                · exfalso
                  exact heq (congrArg Prod.fst hr0_hd)
                · exact hr0_tl
              · have hnmem_cons : s.slotId ∉ ((sid, rec) :: pairs).map Prod.fst := by
                  simp [heq, hmem_tl]
                rw [if_neg hnmem_cons] at hbr
                rw [if_neg hmem_tl]
                exact hbr
        exact haux metas tbl.slots (fun _ hs => hs) hrel
      -- Space bounds on `mkTbl₁ dOut` and `mkTbl₂ dOut`
      have hlen_slots : tbl.slots.length ≤ K := by
        rw [← hrel.length_eq]
        exact hlen_K
      have halloc_tbl : ∀ s ∈ tbl.slots, (s.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := by
        intro s hs
        rcases forall₂_mem_right hrel hs with ⟨_, _, hh⟩
        exact hh.2.2.2.2.2.2.2.2.2
      have hsp_tbl1 : ((mkTbl₁ dOut).currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ := by
        refine currentSpace_le_of_slot_bounds hσθ.1 hσθ.2.1 hfacs hact_le
          (by dsimp [mkTbl₁]; rw [List.length_map]; exact hlen_slots) (fun s' hs' => ?_)
        rcases List.mem_map.mp hs' with ⟨s, hs, hs'_eq⟩
        classical
        by_cases heq : s.slotId = sid
        · rw [if_pos heq] at hs'_eq; subst hs'_eq; exact hsl2_sp
        · rw [if_neg heq] at hs'_eq; subst hs'_eq; exact halloc_tbl s hs
      have hsp_tbl2 : ((mkTbl₂ dOut).currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ := by
        refine currentSpace_le_of_slot_bounds hσθ.1 hσθ.2.1 hfacs hact_le
          (by rw [hslots2_eq, List.length_map]; exact hlen_slots) (fun s' hs' => ?_)
        rw [hslots2_eq] at hs'
        rcases List.mem_map.mp hs' with ⟨s, hs, hs'_eq⟩
        classical
        by_cases heq : s.slotId = sid
        · rw [if_pos heq] at hs'_eq; subst hs'_eq; exact hsl2_sp
        · rw [if_neg heq] at hs'_eq; subst hs'_eq; exact halloc_tbl s hs
      have hpeak2_real : ((mkPeak₂ dOut : ℕ) : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ := by
        dsimp only [mkPeak₂, mkPeak₁]
        rw [Nat.cast_max, Nat.cast_max]
        exact max_le (max_le hpeak_real hsp_tbl1) hsp_tbl2
      have hpairs_mem2 : ∀ sid' ∈ pairs.map Prod.fst, sid' ∈ (mkTbl₂ dOut).slots.map UL.HostedMCSlot.slotId := by
        intro sid' hsid'
        rw [hmap2_id]
        exact hpairs_mem sid' (by simp [hsid'])
      rcases ih fuel (mkTbl₂ dOut) (accWork + 1 + mkPaid dOut + 1) (mkPeak₂ dOut)
          hA1_eq hact_le hlen_K hnod_pairs_tl hpairs_mem2 hrel2 hnodup2 hsid_lt2
          (Nat.le_max_right _ _) hpeak2_real with
        ⟨hhalt2, hpath2⟩
      refine ⟨hhalt2, fun bs₂ out hout => ?_⟩
      rcases hpath2 bs₂ out hout with
        ⟨hqa, hst1, hact_o, hlife_o, hnod_o, hsid_o, hrel_o, hw_o, hsp_o, hgood_imp⟩
      refine ⟨hqa, hst1, hact_o, hlife_o, hnod_o, hsid_o, hrel_o, hw_o, hsp_o, fun hg_tbl => ?_⟩
      apply hgood_imp
      intro s' hs'
      rw [hslots2_eq] at hs'
      rcases List.mem_map.mp hs' with ⟨s, hs, hs'_eq⟩
      classical
      by_cases heq : s.slotId = sid
      · rw [if_pos heq] at hs'_eq
        subst hs'_eq
        rcases hg_tbl sl hsl_mem with ⟨bh_g, hbs_g, hval_g⟩
        have hsurv_sub_g : (mkMC sl.gen).gen.IsSurvivingSubset sl.surviving := hsurv_sub
        rcases ((hunif_all bh_g).2.2.1.2.2.2.2.2.1 extHist sl.bState sl.surviving sl.idxState rec
            hsurv_sub_g hval_g hrec'_surv).2.2 bs₁ dOut hdel with ⟨hd_val_g, _, _⟩
        exact ⟨bh_g, hbs_g, hd_val_g⟩
      · rw [if_neg heq] at hs'_eq
        subst hs'_eq
        exact hg_tbl s hs
    refine ⟨?_, ?_⟩
    · rw [hf_eq]
      exact haltProb_seqConsume hpf_del hhalt_del (fun bs₁ dOut hdel => (h_ih bs₁ dOut hdel).1)
    · intro bs out hout
      have hout' : seqConsume ((mkMC sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.idxState rec) g bs = some out := by
        rw [← hf_eq]
        exact hout
      rcases (seqConsume_eq_some_iff hpf_del).mp hout' with ⟨bs₁, bs₂, dOut, rfl, hdel, hg_out⟩
      rcases (h_ih bs₁ dOut hdel).2 bs₂ out hg_out with
        ⟨hqa, hst1, hact_o, hlife_o, hnod_o, hsid_o, hrel_o, hw_o, hsp_o, hgood_o⟩
      refine ⟨hqa, hst1, hact_o, hlife_o, hnod_o, hsid_o, hrel_o, ?_, hsp_o, hgood_o⟩
      have hpaid_le : mkPaid dOut ≤ dBud := Nat.min_le_left _ _
      dsimp only [dBud] at hw_o hpaid_le ⊢
      simp only [List.length_cons]
      calc out.work
        _ ≤ (accWork + 1 + mkPaid dOut + 1) + pairs.length * (delBudget n θ facs + 2) + 1 := hw_o
        _ ≤ accWork + (delBudget n θ facs + 2) + pairs.length * (delBudget n θ facs + 2) + 1 := by omega
        _ = accWork + (pairs.length + 1) * (delBudget n θ facs + 2) + 1 := by ring

theorem mcStep_delete_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    (extHist : UL.ExecutionHistory d)
    {S : Finset ι} {ctrl : MCCtrlState ι d_s} {tbl0 : UL.HostedMCTable ι d_s B I}
    (hinv : MCTableInv n pts h σ θ facs mkMC S ctrl tbl0)
    (hH_le : tbl0.nextLifetime ≤ maxOps)
    {id₀ : ι} :
    let dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
    let L := Nat.log 2 maxOps + 1
    let stepFn := UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀)
    UL.singleDynamicSearchStepHaltProb dynIdx extHist S (ctrl, tbl0) (.delete id₀) = 1 ∧
    (∀ bs S' out, stepFn bs = some (S', out) →
      S' = S.erase id₀ ∧
      out.queryAnswer = none ∧
      out.nextState.2.nextLifetime = tbl0.nextLifetime ∧
      MCTableInv n pts h σ θ facs mkMC S' out.nextState.1 out.nextState.2 ∧
      (out.work : ℝ) ≤
        50 * (L : ℝ) * (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) ∧
      (out.peakSpace : ℝ) ≤ 7 * (L : ℝ) * facs.spaceBound n σ ∧
      (AllSlotsGood mkMC tbl0 → AllSlotsGood mkMC out.nextState.2)) := by
  dsimp only []
  let dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
  let H := tbl0.nextLifetime
  let L := Nat.log 2 maxOps + 1
  let K := 3 * L
  have hL_ge0 : Nat.log 2 H + 1 ≤ L := Nat.add_le_add_right (Nat.log_mono_right hH_le) 1
  have hinj_fst : ∀ r₁ ∈ tbl0.activeLifetimes, ∀ r₂ ∈ tbl0.activeLifetimes, r₁.1 = r₂.1 → r₁ = r₂ := by
    have hce : (tbl0.activeLifetimes.image Prod.fst).card = tbl0.activeLifetimes.card := by
      rw [hinv.img_eq, hinv.card_eq]
    exact fun _ hr₁ _ hr₂ heq => injOn_of_card_image_eq hce hr₁ hr₂ heq
  let tbl1 : UL.HostedMCTable ι d_s B I :=
    { tbl0 with activeLifetimes := tbl0.activeLifetimes.filter (fun p => p.1 ≠ id₀) }
  have hA1_img : tbl1.activeLifetimes.image Prod.fst = S.erase id₀ := by
    change (tbl0.activeLifetimes.filter (fun p => p.1 ≠ id₀)).image Prod.fst = S.erase id₀
    ext x
    simp only [Finset.mem_image, Finset.mem_filter, Finset.mem_erase]
    constructor
    · rintro ⟨p, ⟨hp, hne⟩, rfl⟩
      refine ⟨hne, ?_⟩
      rw [← hinv.img_eq]
      exact Finset.mem_image.mpr ⟨p, hp, rfl⟩
    · rintro ⟨hne, hxS⟩
      rw [← hinv.img_eq] at hxS
      rcases Finset.mem_image.mp hxS with ⟨p, hp, rfl⟩
      exact ⟨p, ⟨hp, hne⟩, rfl⟩
  have hA1_card_eq : tbl1.activeLifetimes.card = (S.erase id₀).card := by
    rw [← hA1_img]
    symm
    refine Finset.card_image_of_injOn (fun r₁ hr₁ r₂ hr₂ heq => ?_)
    exact hinj_fst r₁ (Finset.mem_filter.mp hr₁).1 r₂ (Finset.mem_filter.mp hr₂).1 heq
  have hA1_card_le : tbl1.activeLifetimes.card ≤ n :=
    hA1_card_eq.trans_le ((Finset.card_erase_le).trans hinv.card_le_n)
  let dBud := delBudget n θ facs
  let delPairs : List (ℕ × (ι × ℕ)) :=
    open Classical in
    tbl1.slots.filterMap fun sl =>
      let filt := sl.surviving.filter (fun p => p.1 = id₀)
      if hne : filt.Nonempty then some (sl.slotId, hne.choose) else none
  let cmds : List (PlannedMCCmd ι d_s) :=
    (delPairs.flatMap fun pair =>
      [PlannedMCCmd.deleteFromSlot pair.1 pair.2,
       PlannedMCCmd.payWork pair.1 dBud]) ++
    [PlannedMCCmd.finishUpdate]
  have hplan : planMCStep n pts h h_pos h_lt_one θ facs (.delete id₀) ctrl.metas tbl1 =
      (ctrl.metas, cmds) := by
    unfold planMCStep
    rfl
  -- Properties of `delPairs`
  have hpairs_sub : (delPairs.map Prod.fst).Sublist (tbl1.slots.map UL.HostedMCSlot.slotId) := by
    classical
    dsimp only [delPairs]
    have haux : ∀ l : List (UL.HostedMCSlot ι d_s B I),
        ((l.filterMap fun sl =>
          let filt := sl.surviving.filter (fun p => p.1 = id₀)
          if hne : filt.Nonempty then some (sl.slotId, hne.choose) else none).map Prod.fst).Sublist
          (l.map UL.HostedMCSlot.slotId) := by
      intro l
      induction l with
      | nil => exact List.Sublist.slnil
      | cons sl tl ih =>
        simp only [List.filterMap_cons, List.map_cons]
        split_ifs
        · simp only [List.map_cons]
          exact List.Sublist.cons₂ _ ih
        · exact List.Sublist.cons _ ih
    exact haux tbl1.slots
  have hpairs_nodup : (delPairs.map Prod.fst).Nodup :=
    hinv.sid_nodup.sublist hpairs_sub
  have hpairs_mem : ∀ sid ∈ delPairs.map Prod.fst, sid ∈ tbl1.slots.map UL.HostedMCSlot.slotId :=
    fun _ h => hpairs_sub.subset h
  have hold_len_H : ctrl.metas.length ≤ 3 * (Nat.log 2 H + 1) :=
    metas_length_le_of_live hinv.kj_nodup (fun k j hm => (hinv.kj_live k j).mp hm)
  have hold_len : ctrl.metas.length ≤ K :=
    hold_len_H.trans (Nat.mul_le_mul_left 3 hL_ge0)
  have hpairs_len_H : delPairs.length ≤ 3 * (Nat.log 2 H + 1) := by
    have h2 : delPairs.length ≤ tbl1.slots.length := by simpa using hpairs_sub.length_le
    have h3 : tbl1.slots.length = ctrl.metas.length := hinv.slots_rel.length_eq.symm
    exact h2.trans (h3.trans_le hold_len_H)
  have hpairs_len_L : delPairs.length ≤ 3 * L :=
    hpairs_len_H.trans (Nat.mul_le_mul_left 3 hL_ge0)
  have hfuel_le : 2 * delPairs.length + 1 ≤ mcFuelBound H := by
    let x := Nat.log 2 H + 1
    have hp : delPairs.length ≤ 3 * x := hpairs_len_H
    change 2 * delPairs.length + 1 ≤ 10 * x + 5
    omega
  let fuel_rem := mcFuelBound H - (2 * delPairs.length + 1)
  have hfuel_split : mcFuelBound H = 2 * delPairs.length + 1 + fuel_rem :=
    (Nat.add_sub_of_le hfuel_le).symm
  -- Initial `DelStageSlotInv` on `delPairs`
  have hrel_del0 : List.Forall₂
      (DelStageSlotInv n pts h σ θ facs mkMC tbl0.activeLifetimes tbl1.activeLifetimes (H + 1) id₀ delPairs)
      ctrl.metas tbl1.slots := by
    have haux : ∀ ms sls,
        (∀ s ∈ sls, s ∈ tbl1.slots) →
        List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl0.activeLifetimes (H + 1)) ms sls →
        List.Forall₂ (DelStageSlotInv n pts h σ θ facs mkMC tbl0.activeLifetimes tbl1.activeLifetimes (H + 1) id₀ delPairs) ms sls := by
      intro ms sls hsls_sub hr
      induction hr with
      | nil => exact List.Forall₂.nil
      | @cons m sl _ _ hh _ ihr =>
        refine List.Forall₂.cons ?_ (ihr (fun s hs => hsls_sub s (by simp [hs])))
        rcases hh with ⟨hid, hm1, hmn, hh_eq, hpts_s, hsurv, hsub, hval, hun, hsp_s⟩
        refine ⟨hid, hm1, hmn, hh_eq, hpts_s, ?_, hsub, hval, hun, hsp_s⟩
        classical
        let filt := sl.surviving.filter (fun p => p.1 = id₀)
        by_cases hne : filt.Nonempty
        · have hmem_dp : (sl.slotId, hne.choose) ∈ delPairs := by
            dsimp only [delPairs]
            refine List.mem_filterMap.mpr ⟨sl, hsls_sub sl (by simp), ?_⟩
            simp [filt, hne]
          have hsid_dp : sl.slotId ∈ delPairs.map Prod.fst :=
            List.mem_map.mpr ⟨(sl.slotId, hne.choose), hmem_dp, rfl⟩
          rw [if_pos hsid_dp]
          have hch := hne.choose_spec
          rw [Finset.mem_filter] at hch
          exact ⟨hne.choose, hmem_dp, hch.1, hch.2, hsurv⟩
        · have hnmem_dp : sl.slotId ∉ delPairs.map Prod.fst := by
            intro hmem_id
            rcases List.mem_map.mp hmem_id with ⟨pair, hpair, hpair_id⟩
            dsimp only [delPairs] at hpair
            rcases List.mem_filterMap.mp hpair with ⟨s', hs', hs'_opt⟩
            split_ifs at hs'_opt with hne'
            simp only [Option.some.injEq] at hs'_opt
            have hs'_id : s'.slotId = sl.slotId := by rw [← hpair_id, ← hs'_opt]
            have hs'_eq : s' = sl :=
              eq_of_mem_of_slotId_eq hinv.sid_nodup hs' (hsls_sub sl (by simp)) hs'_id
            subst hs'_eq
            exact hne hne'
          rw [if_neg hnmem_dp]
          rw [hsurv]
          dsimp only [tbl1]
          ext p
          simp only [Finset.mem_filter]
          constructor
          · rintro ⟨hp0, hb⟩
            refine ⟨⟨hp0, fun heq => hne ⟨p, ?_⟩⟩, hb⟩
            rw [Finset.mem_filter, hsurv, Finset.mem_filter]
            exact ⟨⟨hp0, hb⟩, heq⟩
          · rintro ⟨⟨hp0, _⟩, hb⟩
            exact ⟨hp0, hb⟩
    exact haux ctrl.metas tbl1.slots (fun _ hs => hs) hinv.slots_rel
  -- Space bounds on `tbl0` and `tbl1`
  have halloc0 : ∀ sl ∈ tbl0.slots, (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := by
    intro sl hsl
    rcases forall₂_mem_right hinv.slots_rel hsl with ⟨_, _, hh⟩
    exact hh.2.2.2.2.2.2.2.2.2
  have hslots0_len : tbl0.slots.length ≤ K := by
    rw [← hinv.slots_rel.length_eq]; exact hold_len
  have hsp0_bound : (tbl0.currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ :=
    currentSpace_le_of_slot_bounds hσθ.1 hσθ.2.1 hfacs
      (hinv.card_eq.trans_le hinv.card_le_n) hslots0_len halloc0
  have hsp1_bound : (tbl1.currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ :=
    currentSpace_le_of_slot_bounds hσθ.1 hσθ.2.1 hfacs hA1_card_le hslots0_len halloc0
  let peak0 := max tbl0.currentSpace tbl1.currentSpace
  have hpeak0_real : (peak0 : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ := by
    dsimp only [peak0]; rw [Nat.cast_max]; exact max_le hsp0_bound hsp1_bound
  have hv1 : ValidMCTable n h mkMC tbl1 := validMCTable_of_forall₂ hinv.slots_rel
  let f_del := fun bs =>
    UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
      extHist (.delete id₀) (2 * delPairs.length + 1 + fuel_rem)
      { metas := ctrl.metas, queue := some cmds }
      tbl1 bs 1 peak0
  have hstep_eq_fdel : ∀ bs,
      dynIdx.stepWithBits extHist S (ctrl, tbl0) (.delete id₀) bs = f_del bs := by
    intro bs
    dsimp only [dynIdx, UL.MCHostedController.toDynamicSearchIndex, mcController]
    rw [if_pos ⟨hinv.img_eq, hinv.card_eq⟩]
    change UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
      extHist (.delete id₀) (mcFuelBound H) ctrl tbl1 bs 1 peak0 = f_del bs
    have hmc_pos : ∃ f0, mcFuelBound H = f0 + 1 := ⟨mcFuelBound H - 1, by unfold mcFuelBound; omega⟩
    rcases hmc_pos with ⟨f0, hf0⟩
    rw [hf0, runMCHostedStepFuel_plan_eq extHist (.delete id₀) f0 ctrl tbl1 bs 1 peak0
      hinv.queue_none hv1 hplan, ← hf0, hfuel_split]
  rcases runDelFinish_spec hσθ hfacs hMC extHist hinj_fst id₀ ctrl.metas
      delPairs fuel_rem tbl1 1 peak0 rfl hA1_card_le hold_len hpairs_nodup hpairs_mem
      hrel_del0 hinv.sid_nodup hinv.sid_lt (Nat.le_max_right _ _) hpeak0_real with
    ⟨hhalt_del, hpath_del⟩
  have hstepFn_eq : ∀ bs,
      UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀) bs =
      (f_del bs).map (fun out => (S.erase id₀, out)) := by
    intro bs
    unfold UL.runSingleDynamicSearchStep
    rw [hstep_eq_fdel bs]
    cases hfd : f_del bs with
    | none => rfl
    | some out =>
      have hqa := (hpath_del bs out hfd).1
      simp [hqa, UL.applyDynamicSearchSetOp]
  refine ⟨?_, ?_⟩
  · unfold UL.singleDynamicSearchStepHaltProb
    rw [← hhalt_del]
    unfold haltProb
    refine tsum_congr fun bs => ?_
    change (if (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀) bs).isSome
      then UL.bitListProb bs else 0) =
      (if (f_del bs).isSome then UL.bitListProb bs else 0)
    rw [hstepFn_eq bs]
    cases f_del bs <;> rfl
  · intro bs S' out hstep
    rw [hstepFn_eq bs] at hstep
    cases hfd : f_del bs with
    | none => rw [hfd] at hstep; simp at hstep
    | some out' =>
      rw [hfd] at hstep
      simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq] at hstep
      rcases hstep with ⟨rfl, rfl⟩
      rcases hpath_del bs out' hfd with
        ⟨hqa, hst1, hact_o, hlife_o, hnod_o, hsid_o, hrel_o, hw_o, hsp_o, hgood_o⟩
      have hm_eq : out'.nextState.1.metas = ctrl.metas := by rw [hst1]
      have hA1_life : ∀ r ∈ tbl1.activeLifetimes, r.2 < H ∧ UL.IsUnitVec (pts r.1) :=
        fun r hr => hinv.life_valid r (Finset.mem_filter.mp hr).1
      have hA1_inj : ∀ r₁ ∈ tbl1.activeLifetimes, ∀ r₂ ∈ tbl1.activeLifetimes, r₁.2 = r₂.2 → r₁ = r₂ :=
        fun r₁ hr₁ r₂ hr₂ heq =>
          hinv.inj_snd r₁ (Finset.mem_filter.mp hr₁).1 r₂ (Finset.mem_filter.mp hr₂).1 heq
      have hinv_out : MCTableInv n pts h σ θ facs mkMC (S.erase id₀)
          out'.nextState.1 out'.nextState.2 :=
        { queue_none := by rw [hst1]
          img_eq := by rw [hact_o]; exact hA1_img
          card_eq := by rw [hact_o]; exact hA1_card_eq
          card_le_n := (Finset.card_erase_le).trans hinv.card_le_n
          life_valid := by rw [hact_o, hlife_o]; exact hA1_life
          inj_snd := by rw [hact_o]; exact hA1_inj
          sid_lt := hsid_o
          sid_nodup := hnod_o
          kj_nodup := by rw [hm_eq]; exact hinv.kj_nodup
          kj_live := by rw [hm_eq, hlife_o]; exact hinv.kj_live
          slots_rel := by rw [hm_eq, hact_o, hlife_o]; exact hrel_o }
      refine ⟨rfl, hqa, hlife_o, hinv_out, ?_, ?_, hgood_o⟩
      · -- Work bound `≤ 50 * L * n^θ * P_time * (P_build + P_del + P_query)`
        have hB1_nn : 0 ≤ facs.buildWorkBound 1 n θ :=
          le_trans zero_le_one (buildWorkBound_one_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs)
        have hD1_ge1 : 1 ≤ facs.deleteWorkBound n θ :=
          deleteWorkBound_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs
        have hQ1_nn : 0 ≤ facs.queryWorkBound n θ :=
          le_trans zero_le_one (queryWorkBound_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs)
        have hd_real : (dBud + 2 : ℝ) ≤ 5 * facs.deleteWorkBound n θ := by
          dsimp only [dBud]
          unfold delBudget
          have hlt : (Nat.ceil (facs.deleteWorkBound n θ) : ℝ) ≤ facs.deleteWorkBound n θ + 1 :=
            (Nat.ceil_lt_add_one (by linarith)).le
          push_cast
          linarith
        have hw_nat : out'.work ≤ 2 + 3 * L * (dBud + 2) := by
          have hmul : delPairs.length * (dBud + 2) ≤ (3 * L) * (dBud + 2) :=
            Nat.mul_le_mul_right _ hpairs_len_L
          dsimp only [dBud] at hmul ⊢
          omega
        have hw_cast : (out'.work : ℝ) ≤ 2 + 3 * (L : ℝ) * (dBud + 2 : ℝ) := by
          have h1 : (out'.work : ℝ) ≤ ((2 + 3 * L * (dBud + 2) : ℕ) : ℝ) := by exact_mod_cast hw_nat
          push_cast at h1
          exact h1
        have hL_ge1 : (1 : ℝ) ≤ (L : ℝ) := by dsimp [L]; push_cast; linarith
        have hsum_fac : facs.deleteWorkBound n θ ≤
            (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) := by
          have hexp : (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) =
              facs.buildWorkBound 1 n θ + facs.deleteWorkBound n θ + facs.queryWorkBound n θ := by
            unfold UL.BirthPoolPolyFactors.buildWorkBound UL.BirthPoolPolyFactors.deleteWorkBound
              UL.BirthPoolPolyFactors.queryWorkBound UL.BirthPoolPolyFactors.targetTime
              UL.birthPoolBuildWorkBound UL.birthPoolDeleteWorkBound UL.birthPoolQueryWorkBound
              UL.birthPoolTargetTime
            push_cast
            ring
          linarith
        nlinarith
      · -- Space bound
        have hsp_nn : 0 ≤ facs.spaceBound n σ :=
          le_trans zero_le_one (spaceBound_ge_one hσθ.1 hσθ.2.1 hfacs)
        have hL_ge1 : (1 : ℝ) ≤ (L : ℝ) := by dsimp [L]; push_cast; linarith
        have hK_eq : (K : ℝ) = 3 * (L : ℝ) := by dsimp [K]; push_cast; ring
        rw [hK_eq] at hsp_o
        nlinarith

/-! ### 3. Query Execution & `.query` Step Specification -/

theorem mem_foldr_surviving_iff {ι : Type} [DecidableEq ι] {d_s : ℕ} {B I : Type}
    (r : ι × ℕ) :
    ∀ l : List (UL.HostedMCSlot ι d_s B I),
      r ∈ l.foldr (fun sl acc => sl.surviving ∪ acc) ∅ ↔ ∃ sl ∈ l, r ∈ sl.surviving
  | [] => by simp
  | sl :: tl => by
    simp only [List.foldr_cons, Finset.mem_union, mem_foldr_surviving_iff r tl, List.mem_cons]
    constructor
    · rintro (hr | ⟨s, hs, hrs⟩)
      · exact ⟨sl, Or.inl rfl, hr⟩
      · exact ⟨s, Or.inr hs, hrs⟩
    · rintro ⟨s, rfl | hs, hrs⟩
      · exact Or.inl hrs
      · exact Or.inr ⟨s, hs, hrs⟩

theorem filterMap_find_slots_of_forall₂ {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)} {h σ θ : ℝ}
    {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    {active : Finset (ι × ℕ)} {tc : ℕ}
    {ms : List MCSlotMeta} {slots : List (UL.HostedMCSlot ι d_s B I)}
    (hrel : List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC active tc) ms slots)
    (hnodup : (slots.map UL.HostedMCSlot.slotId).Nodup) :
    ∀ sub : List MCSlotMeta,
      (∀ m ∈ sub, m ∈ ms) →
      let picked := open Classical in
        (sub.map MCSlotMeta.slotId).filterMap (fun sid => slots.find? (fun s => s.slotId = sid))
      picked.length = sub.length ∧
      List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC active tc) sub picked ∧
      (∀ sl ∈ picked, sl ∈ slots) := by
  intro sub
  induction sub with
  | nil =>
    intro _
    exact ⟨rfl, List.Forall₂.nil, fun _ h => by simp at h⟩
  | cons m sub' ih =>
    intro hsub
    rcases forall₂_mem_left hrel (hsub m (by simp)) with ⟨sl, hsl_mem, hslot_inv⟩
    have hfind : (open Classical in slots.find? (fun s => s.slotId = m.slotId)) = some sl := by
      refine find?_slotId_of_nodup hnodup hsl_mem _ (fun s _ => ?_)
      rw [decide_eq_true_eq, hslot_inv.1]
    rcases ih (fun m' hm' => hsub m' (by simp [hm'])) with ⟨hlen', hrel', hmem'⟩
    dsimp only []
    rw [List.map_cons, List.filterMap_cons, hfind]
    dsimp only []
    refine ⟨congrArg Nat.succ hlen', List.Forall₂.cons hslot_inv hrel', ?_⟩
    intro s hs
    rcases List.mem_cons.mp hs with rfl | htl
    · exact hsl_mem
    · exact hmem' s htl

theorem mcStep_query_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    (extHist : UL.ExecutionHistory d)
    {S : Finset ι} {ctrl : MCCtrlState ι d_s} {tbl0 : UL.HostedMCTable ι d_s B I}
    (hinv : MCTableInv n pts h σ θ facs mkMC S ctrl tbl0)
    (hH_le : tbl0.nextLifetime ≤ maxOps)
    (q : UL.SearchQuery ι d_s) :
    let dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
    let L := Nat.log 2 maxOps + 1
    let stepFn := UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.query q)
    UL.singleDynamicSearchStepHaltProb dynIdx extHist S (ctrl, tbl0) (.query q) = 1 ∧
    (∀ bs S' out, stepFn bs = some (S', out) →
      S' = S ∧
      out.nextState.2.nextLifetime = tbl0.nextLifetime ∧
      MCTableInv n pts h σ θ facs mkMC S' out.nextState.1 out.nextState.2 ∧
      (out.work : ℝ) ≤
        50 * (L : ℝ) * (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) ∧
      (out.peakSpace : ℝ) ≤ 7 * (L : ℝ) * facs.spaceBound n σ ∧
      (AllSlotsGood mkMC tbl0 → AllSlotsGood mkMC out.nextState.2) ∧
      ∃ ans : Option ι,
        out.queryAnswer = some ans ∧
        UL.IsValidSearchAnswer S q.accept ans ∧
        (AllSlotsGood mkMC tbl0 →
          UL.IsCompatibleTest pts S q.z q.accept →
          UL.IsCorrectSearchAnswer pts S h q.z q.accept ans)) := by
  dsimp only []
  classical
  let dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
  let H := tbl0.nextLifetime
  let L := Nat.log 2 maxOps + 1
  let K := 3 * L
  have hL_ge0 : Nat.log 2 H + 1 ≤ L := Nat.add_le_add_right (Nat.log_mono_right hH_le) 1
  let sMetas := open Classical in ctrl.metas.filter (fun m => decide (ServingMC H m.k m.j))
  let sids := sMetas.map MCSlotMeta.slotId
  have hplan : planMCStep n pts h h_pos h_lt_one θ facs (.query q) ctrl.metas tbl0 =
      (ctrl.metas, [PlannedMCCmd.finishQuery sids]) := by
    unfold planMCStep
    rfl
  have hv0 : ValidMCTable n h mkMC tbl0 := validMCTable_of_forall₂ hinv.slots_rel
  have hsids_nodup : sids.Nodup := by
    have hms_nodup : (ctrl.metas.map MCSlotMeta.slotId).Nodup := by
      rw [forall₂_map_slotId_eq hinv.slots_rel]
      exact hinv.sid_nodup
    exact hms_nodup.sublist (List.filter_sublist.map _)
  let picked := open Classical in sids.filterMap (fun sid => tbl0.slots.find? (fun s => s.slotId = sid))
  rcases filterMap_find_slots_of_forall₂ hinv.slots_rel hinv.sid_nodup sMetas
      (fun _ hm => List.mem_of_mem_filter hm) with
    ⟨hpicked_len_sub, hpicked_rel, hpicked_sub_slots⟩
  have hpicked_len : picked.length = sids.length := by
    rw [hpicked_len_sub]
    simp [sids]
  have hpicked_ready : ∀ sl ∈ picked, sl.unpaidWork = 0 ∧ sl.surviving ⊆ tbl0.activeLifetimes := by
    intro sl hsl
    rcases forall₂_mem_right hpicked_rel hsl with ⟨m, hm, hh⟩
    classical
    have hserv : ServingMC H m.k m.j := decide_eq_true_eq.mp (List.mem_filter.mp hm).2
    have hready : ReadyMC H m.k m.j := hserv.1
    have hun_le := hh.2.2.2.2.2.2.2.2.1
    have hsub_zero : (m.j + 2) * 2 ^ m.k - (H + 1) = 0 := by
      unfold ReadyMC at hready
      omega
    have hun0 : sl.unpaidWork = 0 := by
      rw [hsub_zero, zero_mul] at hun_le
      omega
    have hsurv_sub : sl.surviving ⊆ tbl0.activeLifetimes := by
      rw [hh.2.2.2.2.2.1]
      exact Finset.filter_subset _ _
    exact ⟨hun0, hsurv_sub⟩
  have hpicked_cover : tbl0.activeLifetimes ⊆ picked.foldr (fun sl acc => sl.surviving ∪ acc) ∅ := by
    intro r hr
    rw [mem_foldr_surviving_iff]
    have hr_lt : r.2 < H := (hinv.life_valid r hr).1
    rcases serveMC_exists_unique hr_lt with ⟨⟨k, j⟩, ⟨hserv, hlo, hhi⟩, _⟩
    have hlive : LiveMC H k j := servingMC_imp_liveMC hserv
    have hmem_kj := (hinv.kj_live k j).mpr hlive
    rcases List.mem_map.mp hmem_kj with ⟨m, hm, hpair⟩
    rcases Prod.mk.inj hpair with ⟨rfl, rfl⟩
    have hm_serv : m ∈ sMetas := by
      classical
      dsimp only [sMetas]
      rw [List.mem_filter]
      exact ⟨hm, decide_eq_true_eq.mpr hserv⟩
    rcases forall₂_mem_left hpicked_rel hm_serv with ⟨sl, hsl_picked, hh⟩
    refine ⟨sl, hsl_picked, ?_⟩
    rw [hh.2.2.2.2.2.1, Finset.mem_filter]
    exact ⟨hr, hlo, hhi⟩
  -- Define `qOuts`, `slots'`, `tbl'`, `validHits`, `out_q`
  let qLifted := UL.liftQueryToLifetimes q
  let qOuts := picked.map (fun sl =>
    (sl.slotId, sl.surviving, (mkMC sl.gen).runQuery sl.bState sl.surviving sl.idxState qLifted))
  let qWork := (qOuts.map (fun x => x.2.2.work + 1)).sum
  let slots' := open Classical in tbl0.slots.map (fun sl =>
    match qOuts.find? (fun x => x.1 = sl.slotId) with
    | some (_, _, qOut) => { sl with spaceAlloc := max sl.spaceAlloc qOut.peakSpace }
    | none => sl)
  let tbl' : UL.HostedMCTable ι d_s B I := { tbl0 with slots := slots' }
  let validHits := open Classical in qOuts.filterMap (fun (_, surv, qOut) =>
    match qOut.answer with
    | some p => if p ∈ surv ∧ q.accept p.1 then some p.1 else none
    | none => none)
  let out_q : UL.DynamicSearchStepOutcome (MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I) ι :=
    { nextState := ({ metas := ctrl.metas, queue := none }, tbl')
      queryAnswer := some validHits.head?
      work := 1 + qWork + 1
      peakSpace := max tbl0.currentSpace tbl'.currentSpace }
  have hstep_eq_end : ∀ bs,
      dynIdx.stepWithBits extHist S (ctrl, tbl0) (.query q) bs = endWithEmpty out_q bs := by
    intro bs
    dsimp only [dynIdx, UL.MCHostedController.toDynamicSearchIndex, mcController]
    rw [if_pos ⟨hinv.img_eq, hinv.card_eq⟩]
    have hmax0 : max tbl0.currentSpace tbl0.currentSpace = tbl0.currentSpace := max_self _
    rw [hmax0]
    have hmc_pos : ∃ f0, mcFuelBound H = f0 + 1 := ⟨mcFuelBound H - 1, by unfold mcFuelBound; omega⟩
    rcases hmc_pos with ⟨f0, hf0⟩
    rw [hf0, runMCHostedStepFuel_plan_eq extHist (.query q) f0 ctrl tbl0 bs 1 tbl0.currentSpace
      hinv.queue_none hv0 hplan]
    conv_lhs => unfold UL.runMCHostedStepFuel
    have hcmd : mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC (.query q)
        { metas := ctrl.metas, queue := some [PlannedMCCmd.finishQuery sids] } tbl0 =
        .finishQuery sids { metas := ctrl.metas, queue := none } := by
      unfold mcStepCtrl
      simp [hv0, dispatchMCQueue]
    rw [hcmd]
    dsimp only []
    cases bs with
    | nil =>
      classical
      have hg1 : ([] : List Bool).isEmpty ∧ sids.Nodup := ⟨rfl, hsids_nodup⟩
      have hg2 : picked.length = sids.length ∧
          (∀ sl ∈ picked, sl.unpaidWork = 0 ∧ sl.surviving ⊆ tbl0.activeLifetimes) ∧
          tbl0.activeLifetimes ⊆ picked.foldr (fun sl acc => sl.surviving ∪ acc) ∅ :=
        ⟨hpicked_len, hpicked_ready, hpicked_cover⟩
      rw [if_pos hg1, if_pos hg2]
      rfl
    | cons b bs' =>
      classical
      have hg1 : ¬ ((b :: bs').isEmpty ∧ sids.Nodup) := by simp
      rw [if_neg hg1]
      rfl
  have hstepFn_eq : ∀ bs,
      UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.query q) bs =
      endWithEmpty (S, out_q) bs := by
    intro bs
    unfold UL.runSingleDynamicSearchStep
    rw [hstep_eq_end bs]
    cases bs <;> rfl
  -- Bounds on `qOuts` work & space
  have hqout_bounds : ∀ x ∈ qOuts,
      (x.2.2.work : ℝ) ≤ facs.queryWorkBound n θ ∧
      (x.2.2.peakSpace : ℝ) ≤ 2 * facs.spaceBound n σ := by
    intro x hx
    rcases List.mem_map.mp hx with ⟨sl, hsl_picked, rfl⟩
    have hsl_slots := hpicked_sub_slots sl hsl_picked
    rcases hv0 sl hsl_slots with ⟨hmn, hh_eq, hsub_P0, ⟨bh, hval⟩⟩
    rcases hMC sl.gen hmn hh_eq with ⟨hgen_eq, hunif_all⟩
    have hsurv_sub : (mkMC sl.gen).gen.IsSurvivingSubset sl.surviving := by
      unfold UL.SearchGeneration.IsSurvivingSubset; rwa [hgen_eq]
    rcases ((hunif_all bh).2.2.1.2.2.2.2.2.2.1 sl.bState sl.surviving sl.idxState qLifted
        hsurv_sub hval) with ⟨hq_w, hq_sp_raw⟩
    have hq_sp : ((mkMC sl.gen).runQuery sl.bState sl.surviving sl.idxState qLifted).peakSpace ≤
        facs.spaceBound sl.gen.m σ := by rwa [hgen_eq] at hq_sp_raw
    have hsp_m : facs.spaceBound sl.gen.m σ ≤ facs.spaceBound n σ :=
      spaceBound_mono_le hmn hσθ.2.1 hfacs
    have hsp_nn : 0 ≤ facs.spaceBound n σ :=
      le_trans zero_le_one (spaceBound_ge_one hσθ.1 hσθ.2.1 hfacs)
    exact ⟨hq_w, by linarith⟩
  -- `slots'` preserves `MCSlotInv`, `slotId`, and `AllSlotsGood`
  have hrel_out : List.Forall₂
      (MCSlotInv n pts h σ θ facs mkMC tbl0.activeLifetimes (H + 1)) ctrl.metas slots' := by
    have haux : ∀ ms sls,
        List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl0.activeLifetimes (H + 1)) ms sls →
        List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl0.activeLifetimes (H + 1)) ms
          (open Classical in sls.map fun sl =>
            match qOuts.find? (fun x => x.1 = sl.slotId) with
            | some (_, _, qOut) => { sl with spaceAlloc := max sl.spaceAlloc qOut.peakSpace }
            | none => sl) := by
      intro ms sls hr
      induction hr with
      | nil => exact List.Forall₂.nil
      | @cons m sl _ _ hh _ ihr =>
        simp only [List.map_cons]
        refine List.Forall₂.cons ?_ ihr
        classical
        cases hf : qOuts.find? (fun x => x.1 = sl.slotId) with
        | none => exact hh
        | some triple =>
          rcases triple with ⟨sid', surv', qOut⟩
          have hmem_q : (sid', surv', qOut) ∈ qOuts := List.mem_of_find?_eq_some hf
          have hq_sp2 : (qOut.peakSpace : ℝ) ≤ 2 * facs.spaceBound n σ := (hqout_bounds _ hmem_q).2
          rcases hh with ⟨hid, hm1, hmn, hh_eq, hpts_s, hsurv, hsub, hval, hun, hsp_s⟩
          refine ⟨hid, hm1, hmn, hh_eq, hpts_s, hsurv, hsub, hval, hun, ?_⟩
          dsimp only []
          rw [Nat.cast_max]
          exact max_le hsp_s hq_sp2
    exact haux ctrl.metas tbl0.slots hinv.slots_rel
  have hmap_id_out : slots'.map UL.HostedMCSlot.slotId = tbl0.slots.map UL.HostedMCSlot.slotId := by
    dsimp only [slots']
    rw [List.map_map]
    apply List.map_congr_left
    intro sl _
    dsimp only [Function.comp]
    classical
    cases qOuts.find? (fun x => x.1 = sl.slotId) with
    | none => rfl
    | some triple => rcases triple with ⟨_, _, _⟩; rfl
  refine ⟨?_, ?_⟩
  · unfold UL.singleDynamicSearchStepHaltProb
    have hhalt1 : haltProb (endWithEmpty (S, out_q)) = 1 := haltProb_endWithEmpty _
    rw [← hhalt1]
    unfold haltProb
    refine tsum_congr fun bs => ?_
    change (if (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.query q) bs).isSome
      then UL.bitListProb bs else 0) = _
    rw [hstepFn_eq bs]
  · intro bs S' out hstep
    rw [hstepFn_eq bs] at hstep
    rcases (endWithEmpty_eq_some_iff.mp hstep) with ⟨_, hpair_eq⟩
    rcases Prod.mk.inj hpair_eq with ⟨hS_eq, hout_eq⟩
    subst S'
    subst out
    have hnod_out : (slots'.map UL.HostedMCSlot.slotId).Nodup := by
      rw [hmap_id_out]; exact hinv.sid_nodup
    have hsid_lt_out : ∀ sl ∈ slots', sl.slotId < tbl0.nextSlotId := by
      intro sl hsl
      have hm : sl.slotId ∈ slots'.map UL.HostedMCSlot.slotId := List.mem_map_of_mem hsl
      rw [hmap_id_out] at hm
      rcases List.mem_map.mp hm with ⟨s0, hs0, hid0⟩
      rw [← hid0]
      exact hinv.sid_lt s0 hs0
    have hinv_out : MCTableInv n pts h σ θ facs mkMC S
        out_q.nextState.1 out_q.nextState.2 :=
      { queue_none := rfl
        img_eq := hinv.img_eq
        card_eq := hinv.card_eq
        card_le_n := hinv.card_le_n
        life_valid := hinv.life_valid
        inj_snd := hinv.inj_snd
        sid_lt := hsid_lt_out
        sid_nodup := hnod_out
        kj_nodup := hinv.kj_nodup
        kj_live := hinv.kj_live
        slots_rel := hrel_out }
    -- Space bound
    have hold_len : ctrl.metas.length ≤ K := by
      have hle0 := metas_length_le_of_live hinv.kj_nodup (fun k j hm => (hinv.kj_live k j).mp hm)
      exact hle0.trans (Nat.mul_le_mul_left 3 hL_ge0)
    have halloc0 : ∀ sl ∈ tbl0.slots, (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := by
      intro sl hsl
      rcases forall₂_mem_right hinv.slots_rel hsl with ⟨_, _, hh⟩
      exact hh.2.2.2.2.2.2.2.2.2
    have halloc' : ∀ sl ∈ slots', (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := by
      intro sl hsl
      rcases forall₂_mem_right hrel_out hsl with ⟨_, _, hh⟩
      exact hh.2.2.2.2.2.2.2.2.2
    have hsp0_b : (tbl0.currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ :=
      currentSpace_le_of_slot_bounds hσθ.1 hσθ.2.1 hfacs
        (hinv.card_eq.trans_le hinv.card_le_n)
        (by rw [← hinv.slots_rel.length_eq]; exact hold_len) halloc0
    have hsp'_b : (tbl'.currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ :=
      currentSpace_le_of_slot_bounds hσθ.1 hσθ.2.1 hfacs
        (hinv.card_eq.trans_le hinv.card_le_n)
        (by dsimp [tbl', slots']; rw [List.length_map, ← hinv.slots_rel.length_eq]; exact hold_len)
        halloc'
    refine ⟨rfl, rfl, hinv_out, ?_, ?_, ?_, validHits.head?, rfl, ?_, ?_⟩
    · -- Work bound `≤ 50 * L * n^θ * P_time * (P_build + P_del + P_query)`
      have hB1_nn : 0 ≤ facs.buildWorkBound 1 n θ :=
        le_trans zero_le_one (buildWorkBound_one_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs)
      have hD1_nn : 0 ≤ facs.deleteWorkBound n θ :=
        le_trans zero_le_one (deleteWorkBound_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs)
      have hQ1_ge1 : 1 ≤ facs.queryWorkBound n θ :=
        queryWorkBound_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs
      have hqWork_le : (qWork : ℝ) ≤ (qOuts.length : ℝ) * (2 * facs.queryWorkBound n θ) := by
        dsimp only [qWork]
        have hlen_m : (qOuts.map (fun x => x.2.2.work + 1)).length = qOuts.length := List.length_map _
        rw [← hlen_m]
        refine list_sum_le_length_mul _ _ (fun y hy => ?_) (by linarith)
        rcases List.mem_map.mp hy with ⟨x, hx, rfl⟩
        have hxw := (hqout_bounds x hx).1
        push_cast
        linarith
      have hqOuts_len : (qOuts.length : ℝ) ≤ 3 * (L : ℝ) := by
        have hl : qOuts.length ≤ 3 * L := by
          dsimp only [qOuts]
          rw [List.length_map, hpicked_len]
          dsimp only [sids]
          rw [List.length_map]
          exact (List.length_filter_le _ _).trans hold_len
        have hl_r : (qOuts.length : ℝ) ≤ ((3 * L : ℕ) : ℝ) := by exact_mod_cast hl
        push_cast at hl_r
        exact hl_r
      have hout_w : (out_q.work : ℝ) = (qWork : ℝ) + 2 := by
        dsimp only [out_q]; push_cast; ring
      have hL_ge1 : (1 : ℝ) ≤ (L : ℝ) := by dsimp [L]; push_cast; linarith
      have hsum_fac : facs.queryWorkBound n θ ≤
          (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) := by
        have hexp : (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) =
            facs.buildWorkBound 1 n θ + facs.deleteWorkBound n θ + facs.queryWorkBound n θ := by
          unfold UL.BirthPoolPolyFactors.buildWorkBound UL.BirthPoolPolyFactors.deleteWorkBound
            UL.BirthPoolPolyFactors.queryWorkBound UL.BirthPoolPolyFactors.targetTime
            UL.birthPoolBuildWorkBound UL.birthPoolDeleteWorkBound UL.birthPoolQueryWorkBound
            UL.birthPoolTargetTime
          push_cast
          ring
        linarith
      nlinarith
    · -- Space bound
      have hsp_max : (out_q.peakSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ := by
        dsimp only [out_q]
        rw [Nat.cast_max]
        exact max_le hsp0_b hsp'_b
      have hsp_nn : 0 ≤ facs.spaceBound n σ :=
        le_trans zero_le_one (spaceBound_ge_one hσθ.1 hσθ.2.1 hfacs)
      have hL_ge1 : (1 : ℝ) ≤ (L : ℝ) := by dsimp [L]; push_cast; linarith
      have hK_eq : (K : ℝ) = 3 * (L : ℝ) := by dsimp [K]; push_cast; ring
      rw [hK_eq] at hsp_max
      nlinarith
    · -- `AllSlotsGood` preserved
      intro hg0 sl' hsl'
      dsimp only [out_q, tbl', slots'] at hsl'
      rcases List.mem_map.mp hsl' with ⟨sl, hsl, hsl'_eq⟩
      have hgood_sl := hg0 sl hsl
      revert hsl'_eq
      cases qOuts.find? (fun x => x.1 = sl.slotId) with
      | none => intro he; subst sl'; exact hgood_sl
      | some tr =>
        rcases tr with ⟨_, _, _⟩
        intro he; subst sl'; exact hgood_sl
    · -- Unconditional `IsValidSearchAnswer S q.accept validHits.head?`
      have hvalid_ans : UL.IsValidSearchAnswer S q.accept validHits.head? := by
        cases hvh : validHits with
        | nil => trivial
        | cons i tl =>
          have hi_mem : i ∈ validHits := by rw [hvh]; simp
          dsimp only [validHits] at hi_mem
          classical
          rcases List.mem_filterMap.mp hi_mem with ⟨⟨sid', surv', qOut⟩, hq_mem, hopt⟩
          rcases List.mem_map.mp hq_mem with ⟨sl, hsl_picked, htr_eq⟩
          rcases Prod.mk.inj htr_eq with ⟨_, htr_eq2⟩
          rcases Prod.mk.inj htr_eq2 with ⟨rfl, _⟩
          cases hqa : qOut.answer with
          | none => rw [hqa] at hopt; simp at hopt
          | some p =>
            rw [hqa] at hopt
            dsimp only [] at hopt
            split_ifs at hopt with hp_ok
            simp only [Option.some.injEq] at hopt
            subst hopt
            have hp_A0 : p ∈ tbl0.activeLifetimes := (hpicked_ready sl hsl_picked).2 hp_ok.1
            have hp_S : p.1 ∈ S := by
              rw [← hinv.img_eq]
              exact Finset.mem_image.mpr ⟨p, hp_A0, rfl⟩
            exact ⟨hp_S, hp_ok.2⟩
      exact hvalid_ans
    · -- Conditional `IsCorrectSearchAnswer` when `AllSlotsGood` and `IsCompatibleTest`
      intro hg0 hcompat
      refine ⟨?_, ?_⟩
      · -- Repeat `IsValidSearchAnswer`
        cases hvh : validHits with
        | nil => trivial
        | cons i tl =>
          have hi_mem : i ∈ validHits := by rw [hvh]; simp
          dsimp only [validHits] at hi_mem
          classical
          rcases List.mem_filterMap.mp hi_mem with ⟨⟨sid', surv', qOut⟩, hq_mem, hopt⟩
          rcases List.mem_map.mp hq_mem with ⟨sl, hsl_picked, htr_eq⟩
          rcases Prod.mk.inj htr_eq with ⟨_, htr_eq2⟩
          rcases Prod.mk.inj htr_eq2 with ⟨rfl, _⟩
          cases hqa : qOut.answer with
          | none => rw [hqa] at hopt; simp at hopt
          | some p =>
            rw [hqa] at hopt
            dsimp only [] at hopt
            split_ifs at hopt with hp_ok
            simp only [Option.some.injEq] at hopt
            subst hopt
            have hp_A0 : p ∈ tbl0.activeLifetimes := (hpicked_ready sl hsl_picked).2 hp_ok.1
            have hp_S : p.1 ∈ S := by
              rw [← hinv.img_eq]
              exact Finset.mem_image.mpr ⟨p, hp_A0, rfl⟩
            exact ⟨hp_S, hp_ok.2⟩
      · intro hhead_none htarget
        have hvh_nil : validHits = [] := by
          cases hvh : validHits with
          | nil => rfl
          | cons _ _ => rw [hvh] at hhead_none; simp at hhead_none
        rcases htarget with ⟨i, hi_S, hi_ip⟩
        rw [← hinv.img_eq] at hi_S
        rcases Finset.mem_image.mp hi_S with ⟨p, hp_A0, hp_fst⟩
        have hp_cov := hpicked_cover hp_A0
        rw [mem_foldr_surviving_iff] at hp_cov
        rcases hp_cov with ⟨sl, hsl_picked, hp_surv⟩
        have hsl_slots := hpicked_sub_slots sl hsl_picked
        rcases forall₂_mem_right hinv.slots_rel hsl_slots with ⟨m, _, hslot_inv⟩
        rcases hslot_inv with ⟨_, _, hmn, hh_eq, hpts_s, _, hsub_P0, _, _, _⟩
        rcases hg0 sl hsl_slots with ⟨bh, hbs, hval⟩
        rcases hMC sl.gen hmn hh_eq with ⟨hgen_eq, hunif_all⟩
        have hsurv_sub : (mkMC sl.gen).gen.IsSurvivingSubset sl.surviving := by
          unfold UL.SearchGeneration.IsSurvivingSubset; rwa [hgen_eq]
        have hcompat_lift : (mkMC sl.gen).gen.IsCompatible sl.surviving qLifted := by
          rw [hgen_eq]
          intro r hr hrej
          have hr_A0 : r ∈ tbl0.activeLifetimes := (hpicked_ready sl hsl_picked).2 hr
          have hr_S : r.1 ∈ S := by
            rw [← hinv.img_eq]
            exact Finset.mem_image.mpr ⟨r, hr_A0, rfl⟩
          rw [hpts_s r (hsub_P0 hr)]
          exact hcompat r.1 hr_S hrej
        have hcorr_raw := ((hunif_all bh).2.2.1.2.2.2.2.2.2.2 sl.bState sl.surviving sl.idxState qLifted
          hbs hsurv_sub hval hcompat_lift)
        have hcorr : UL.IsCorrectSearchAnswer sl.gen.pts sl.surviving sl.gen.h qLifted.z qLifted.accept
            ((mkMC sl.gen).runQuery sl.bState sl.surviving sl.idxState qLifted).answer := by
          unfold UL.SearchGeneration.IsCorrectAnswer at hcorr_raw
          rwa [hgen_eq] at hcorr_raw
        let qOut := (mkMC sl.gen).runQuery sl.bState sl.surviving sl.idxState qLifted
        have hp_target : UL.HasSearchTarget sl.gen.pts sl.surviving sl.gen.h qLifted.z := by
          refine ⟨p, hp_surv, ?_⟩
          rw [hpts_s p (hsub_P0 hp_surv), hp_fst, hh_eq]
          exact hi_ip
        cases hqa : qOut.answer with
        | none =>
          exact hcorr.2 hqa hp_target
        | some p' =>
          have hval_p' : UL.IsValidSearchAnswer sl.surviving qLifted.accept (some p') := by
            rw [← hqa]; exact hcorr.1
          rcases hval_p' with ⟨hp'_surv, hp'_acc⟩
          have hmem_vh : p'.1 ∈ validHits := by
            dsimp only [validHits]
            classical
            refine List.mem_filterMap.mpr ⟨(sl.slotId, sl.surviving, qOut), ?_, ?_⟩
            · exact List.mem_map_of_mem hsl_picked
            · rw [hqa]
              dsimp only []
              have hacc' : q.accept p'.1 := hp'_acc
              rw [if_pos ⟨hp'_surv, hacc'⟩]
          rw [hvh_nil] at hmem_vh
          simp at hmem_vh

end UL.Proof_lem_7_1_RaceV31
