import Mathlib
import UL.Stmt.lem_7_1
import UL.Proof.lem_7_1.RaceV31_H1_Coins
import UL.Proof.lem_7_1.RaceV31_H2_Dyadic
import UL.Proof.lem_7_1.RaceV31_H4a_Pot
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. Certified Wrapper Controller Types & Definitions -/

structure CertGroupMeta (ι : Type) (d_s : ℕ) : Type where
  level : ℕ
  gen : UL.SearchGeneration (ι × ℕ) d_s
  sids : List ℕ

inductive PlannedCertCmd (ι : Type) (d_s : ℕ) : Type
  | openCertSlot (gen : UL.SearchGeneration (ι × ℕ) d_s)
  | deleteCertSlot (slotId : ℕ) (rec : ι × ℕ)
  | retireCertSlot (slotId : ℕ)
  | finishCertUpdate
  | finishCertQuery (raceGroups : List (List ℕ × ℕ))

structure CertCtrlState (ι : Type) (d_s : ℕ) : Type where
  groups : List (CertGroupMeta ι d_s)
  queue : Option (List (PlannedCertCmd ι d_s))

/-- Classical table validity guard ensuring every hosted slot satisfies the domain hypotheses
required for `deleteWithBits` prefix-freeness, even on arbitrary unreachable states. -/
def ValidCertTable {ι : Type} {d d_s : ℕ} {B P : Type}
    (n : ℕ) (h : ℝ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (tbl : UL.HostedCertTable ι d_s B P) : Prop :=
  ∀ sl ∈ tbl.slots,
    sl.gen.m ≤ n ∧ sl.gen.h = h ∧ sl.surviving ⊆ sl.gen.P₀ ∧
    ∃ birthHist,
      (mkCert sl.gen).IsAcceptedBirth birthHist sl.bState ∧
      (mkCert sl.gen).IsAcceptedPhase birthHist sl.bState sl.surviving sl.phase

open Classical in
/-- Pre-plan the finite micro-command list and updated `groups` for one dynamic operation. -/
noncomputable def planCertStep {ι : Type} [DecidableEq ι] {d_s : ℕ} {B P : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (R cap : ℕ)
    (op : UL.DynamicSearchOp ι d_s) (oldGroups : List (CertGroupMeta ι d_s))
    (tbl1 : UL.HostedCertTable ι d_s B P) :
    List (CertGroupMeta ι d_s) × List (PlannedCertCmd ι d_s) :=
  match op with
  | .insert _ =>
      let H1 := tbl1.nextLifetime
      let k₀ := carryLevel (H1 - 1)
      let toRetire := oldGroups.filter (fun g => decide (g.level < k₀))
      let keptGroups := oldGroups.filter (fun g => decide (k₀ ≤ g.level))
      let P₀ := binSlice tbl1.activeLifetimes H1 k₀
      if hP : P₀.Nonempty ∧ ∀ p ∈ P₀, UL.IsUnitVec (pts p.1) then
        let gen : UL.SearchGeneration (ι × ℕ) d_s :=
          { P₀ := P₀
            pts := fun p => pts p.1
            nonempty := hP.1
            unit_pts := hP.2
            h := h
            h_pos := h_pos
            h_lt_one := h_lt_one }
        let newSids := (List.range R).map (fun j => tbl1.nextSlotId + j)
        let newGrp : CertGroupMeta ι d_s :=
          { level := k₀, gen := gen, sids := newSids }
        let nextGroups := keptGroups ++ [newGrp]
        let cmds : List (PlannedCertCmd ι d_s) :=
          ((toRetire.flatMap CertGroupMeta.sids).map PlannedCertCmd.retireCertSlot) ++
          List.replicate R (PlannedCertCmd.openCertSlot gen) ++
          [PlannedCertCmd.finishCertUpdate]
        (nextGroups, cmds)
      else
        (oldGroups, [])
  | .delete id =>
      let delPairs : List (ℕ × (ι × ℕ)) :=
        tbl1.slots.filterMap fun sl =>
          let filt := sl.surviving.filter (fun p => p.1 = id)
          if hne : filt.Nonempty then some (sl.slotId, hne.choose) else none
      let cmds : List (PlannedCertCmd ι d_s) :=
        (delPairs.map fun pair => PlannedCertCmd.deleteCertSlot pair.1 pair.2) ++
        [PlannedCertCmd.finishCertUpdate]
      (oldGroups, cmds)
  | .query _ =>
      let raceGroups := oldGroups.map (fun g => (g.sids, cap))
      (oldGroups, [PlannedCertCmd.finishCertQuery raceGroups])

/-- Intentionally mismatched terminal command causing `runCertHostedStepFuel` to return `none`. -/
def abortCertCmd {ι : Type} {d_s : ℕ}
    (op : UL.DynamicSearchOp ι d_s) (groups : List (CertGroupMeta ι d_s)) :
    UL.CertWrapperCmd ι d_s (CertCtrlState ι d_s) :=
  match op with
  | .query _ => .finishCertUpdate { groups := groups, queue := none }
  | _ => .finishCertQuery [] { groups := groups, queue := none }

def dispatchCertQueue {ι : Type} {d_s : ℕ}
    (op : UL.DynamicSearchOp ι d_s) (groups : List (CertGroupMeta ι d_s)) :
    List (PlannedCertCmd ι d_s) → UL.CertWrapperCmd ι d_s (CertCtrlState ι d_s)
  | [] => abortCertCmd op groups
  | .openCertSlot gen :: rest => .openCertSlot gen { groups := groups, queue := some rest }
  | .deleteCertSlot sid rec :: rest => .deleteCertSlot sid rec { groups := groups, queue := some rest }
  | .retireCertSlot sid :: rest => .retireCertSlot sid { groups := groups, queue := some rest }
  | .finishCertUpdate :: _ => .finishCertUpdate { groups := groups, queue := none }
  | .finishCertQuery rgs :: _ => .finishCertQuery rgs { groups := groups, queue := none }

open Classical in
noncomputable def certStepCtrl {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (R cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (op : UL.DynamicSearchOp ι d_s) (ctrl : CertCtrlState ι d_s)
    (tbl : UL.HostedCertTable ι d_s B P) :
    UL.CertWrapperCmd ι d_s (CertCtrlState ι d_s) :=
  if ValidCertTable n h mkCert tbl then
    match ctrl.queue with
    | some cmds => dispatchCertQueue op ctrl.groups cmds
    | none =>
        let (nextGroups, cmds) := planCertStep pts h h_pos h_lt_one R cap op ctrl.groups tbl
        dispatchCertQueue op nextGroups cmds
  else
    abortCertCmd op ctrl.groups

def certFuelBound (L_max R : ℕ) (_ : ℕ) : ℕ :=
  (L_max + 2) * R + 5

noncomputable def certController {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (L_max R cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P) :
    UL.CertHostedController ι d_s B P (CertCtrlState ι d_s) where
  initCtrl := { groups := [], queue := none }
  fuelBound := certFuelBound L_max R
  stepCtrl := certStepCtrl n pts h h_pos h_lt_one R cap mkCert

/-! ### 2. Universal Prefix-Freeness (Including Unreachable States) -/

theorem runCertHostedStepFuel_abort_eq_none {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h : ℝ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (stepCtrl : UL.DynamicSearchOp ι d_s → CertCtrlState ι d_s →
      UL.HostedCertTable ι d_s B P → UL.CertWrapperCmd ι d_s (CertCtrlState ι d_s))
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s)
    (fuel : ℕ) (ctrl : CertCtrlState ι d_s) (tbl : UL.HostedCertTable ι d_s B P)
    (bs : List Bool) (accW peakSp : ℕ)
    (habort : stepCtrl op ctrl tbl = abortCertCmd op ctrl.groups) :
    UL.runCertHostedStepFuel n pts h mkCert stepCtrl extHist op (fuel + 1)
      ctrl tbl bs accW peakSp = none := by
  conv_lhs => unfold UL.runCertHostedStepFuel
  rw [habort]
  cases op <;> rfl

theorem isPrefixFree_runCertHostedStepFuel {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound : ℝ} {facs : UL.BirthPoolPolyFactors}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {R cap : ℕ}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s) :
    ∀ (fuel : ℕ) (ctrl : CertCtrlState ι d_s) (tbl : UL.HostedCertTable ι d_s B P)
      (accW peakSp : ℕ),
      IsPrefixFree (fun bs =>
        UL.runCertHostedStepFuel n pts h mkCert
          (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
          extHist op fuel ctrl tbl bs accW peakSp) := by
  intro fuel
  induction fuel with
  | zero =>
    intro ctrl tbl accW peakSp bs₁ bs₂ out₁ out₂ h₁ _ _
    simp [UL.runCertHostedStepFuel] at h₁
  | succ fuel ih =>
    intro ctrl tbl accW peakSp bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
    let stepCtrl := certStepCtrl n pts h h_pos h_lt_one R cap mkCert
    by_cases hval : ValidCertTable n h mkCert tbl
    · conv at h₁ => unfold UL.runCertHostedStepFuel
      conv at h₂ => unfold UL.runCertHostedStepFuel
      cases hcmd : stepCtrl op ctrl tbl with
      | openCertSlot gen ctrl' =>
        simp only [stepCtrl, hcmd] at h₁ h₂
        split_ifs at h₁ h₂ with hguard
        rcases hguard with ⟨hgm, hgh, _, _⟩
        have hpf_build : IsPrefixFree ((mkCert gen).buildWithBits extHist) :=
          ((hCert gen hgm hgh).2.2 extHist).2.2.2.2.1
        cases hc₁ : UL.consumePrefixBits ((mkCert gen).buildWithBits extHist) bs₁ with
        | none => simp [hc₁] at h₁
        | some p₁ =>
          cases hc₂ : UL.consumePrefixBits ((mkCert gen).buildWithBits extHist) bs₂ with
          | none => simp [hc₂] at h₂
          | some p₂ =>
            rcases p₁ with ⟨bOut₁, rem₁⟩
            rcases p₂ with ⟨bOut₂, rem₂⟩
            simp only [hc₁] at h₁
            simp only [hc₂] at h₂
            rcases (consumePrefixBits_eq_some_iff hpf_build).mp hc₁ with ⟨u₁, rfl, hu₁⟩
            rcases (consumePrefixBits_eq_some_iff hpf_build).mp hc₂ with ⟨u₂, rfl, hu₂⟩
            rcases hpref with ⟨w, hw⟩
            rw [List.append_assoc] at hw
            rcases prefixFree_split_unique hpf_build hw.symm hu₂ hu₁ with ⟨rfl, hrem, rfl⟩
            rw [ih ctrl' _ _ _ rem₁ rem₂ out₁ out₂ h₁ h₂ ⟨w, hrem.symm⟩]
      | deleteCertSlot sid rec ctrl' =>
        simp only [stepCtrl, hcmd] at h₁ h₂
        cases hf : tbl.slots.find? (fun s => s.slotId = sid) with
        | none => simp [hf] at h₁
        | some sl =>
          simp only [hf] at h₁ h₂
          split_ifs at h₁ h₂ with hguard
          have hsl_mem : sl ∈ tbl.slots := List.mem_of_find?_eq_some hf
          rcases hval sl hsl_mem with ⟨hgm, hgh, hsub, birthHist, hbirth, hph⟩
          rcases hCert sl.gen hgm hgh with ⟨hgen_eq, _, hcert_all⟩
          have hsurv : (mkCert sl.gen).gen.IsSurvivingSubset sl.surviving := by
            unfold UL.SearchGeneration.IsSurvivingSubset
            rwa [hgen_eq]
          have hpf_del : IsPrefixFree
              ((mkCert sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.phase rec) :=
            ((hcert_all birthHist).2.2.2.2.2.2.2.1 extHist sl.bState sl.surviving sl.phase rec
              hbirth hsurv hph hguard.1).1
          cases hc₁ : UL.consumePrefixBits
              ((mkCert sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.phase rec) bs₁ with
          | none => simp [hc₁] at h₁
          | some p₁ =>
            cases hc₂ : UL.consumePrefixBits
                ((mkCert sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.phase rec) bs₂ with
            | none => simp [hc₂] at h₂
            | some p₂ =>
              rcases p₁ with ⟨dOut₁, rem₁⟩
              rcases p₂ with ⟨dOut₂, rem₂⟩
              simp only [hc₁] at h₁
              simp only [hc₂] at h₂
              rcases (consumePrefixBits_eq_some_iff hpf_del).mp hc₁ with ⟨u₁, rfl, hu₁⟩
              rcases (consumePrefixBits_eq_some_iff hpf_del).mp hc₂ with ⟨u₂, rfl, hu₂⟩
              rcases hpref with ⟨w, hw⟩
              rw [List.append_assoc] at hw
              rcases prefixFree_split_unique hpf_del hw.symm hu₂ hu₁ with ⟨rfl, hrem, rfl⟩
              rw [ih ctrl' _ _ _ rem₁ rem₂ out₁ out₂ h₁ h₂ ⟨w, hrem.symm⟩]
      | retireCertSlot sid ctrl' =>
        simp only [stepCtrl, hcmd] at h₁ h₂
        exact ih ctrl' _ _ _ bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
      | finishCertUpdate ctrl' =>
        simp only [stepCtrl, hcmd] at h₁ h₂
        cases op with
        | query _ => simp at h₁
        | insert _ =>
          split_ifs at h₁ h₂ with he₁ he₂
          have hb₁ : bs₁ = [] := List.isEmpty_iff.mp he₁
          have hb₂ : bs₂ = [] := List.isEmpty_iff.mp he₂
          rw [hb₁, hb₂]
        | delete _ =>
          split_ifs at h₁ h₂ with he₁ he₂
          have hb₁ : bs₁ = [] := List.isEmpty_iff.mp he₁
          have hb₂ : bs₂ = [] := List.isEmpty_iff.mp he₂
          rw [hb₁, hb₂]
      | finishCertQuery rgs ctrl' =>
        simp only [stepCtrl, hcmd] at h₁ h₂
        cases op with
        | insert _ => simp at h₁
        | delete _ => simp at h₁
        | query q =>
          simp only [] at h₁ h₂
          split_ifs at h₁ h₂ with he₁ he₂
          have hb₁ : bs₁ = [] := List.isEmpty_iff.mp he₁
          have hb₂ : bs₂ = [] := List.isEmpty_iff.mp he₂
          rw [hb₁, hb₂]
    · dsimp only [] at h₁
      have habort : stepCtrl op ctrl tbl = abortCertCmd op ctrl.groups := by
        simp [stepCtrl, certStepCtrl, hval]
      rw [runCertHostedStepFuel_abort_eq_none n pts h mkCert stepCtrl extHist op fuel
        ctrl tbl bs₁ accW peakSp habort] at h₁
      simp at h₁

theorem isPrefixFree_certDynIdx {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound : ℝ} {facs : UL.BirthPoolPolyFactors}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {L_max R cap : ℕ}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    (extHist : UL.ExecutionHistory d) (S : Finset ι)
    (st : CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P)
    (op : UL.DynamicSearchOp ι d_s) :
    IsPrefixFree
      (((certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
          n pts h mkCert).stepWithBits extHist S st op) := by
  intro bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
  dsimp [UL.CertHostedController.toDynamicSearchIndex, certController] at h₁ h₂
  split_ifs at h₁ h₂ with hact
  exact isPrefixFree_runCertHostedStepFuel hCert extHist op _ _ _ _ _ bs₁ bs₂ out₁ out₂ h₁ h₂ hpref

/-! ### 3. Reachable Table Invariant (`CertTableInv`) & Wrapper Potential (`certPhi`) -/

def groupSlots {ι : Type} {d_s : ℕ} {B P : Type}
    (tbl : UL.HostedCertTable ι d_s B P) (sids : List ℕ) :
    List (UL.HostedCertSlot ι d_s B P) :=
  sids.filterMap (fun sid => tbl.slots.find? (fun s => s.slotId = sid))

def CertSlotInv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h σ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (sl : UL.HostedCertSlot ι d_s B P) : Prop :=
  1 ≤ sl.gen.m ∧ sl.gen.m ≤ n ∧ sl.gen.h = h ∧
  (∀ p ∈ sl.gen.P₀, sl.gen.pts p = pts p.1) ∧
  sl.surviving ⊆ sl.gen.P₀ ∧
  (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ ∧
  ∃ birthHist,
    (mkCert sl.gen).IsAcceptedBirth birthHist sl.bState ∧
    (mkCert sl.gen).IsAcceptedPhase birthHist sl.bState sl.surviving sl.phase

structure CertTableInv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n maxOps R : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h σ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (S : Finset ι) (ctrl : CertCtrlState ι d_s) (tbl : UL.HostedCertTable ι d_s B P) : Prop where
  queue_none : ctrl.queue = none
  img_eq : tbl.activeLifetimes.image Prod.fst = S
  card_eq : tbl.activeLifetimes.card = S.card
  lt_next : ∀ p ∈ tbl.activeLifetimes, p.2 < tbl.nextLifetime
  unit_active : ∀ p ∈ tbl.activeLifetimes, UL.IsUnitVec (pts p.1)
  life_le_max : tbl.nextLifetime ≤ maxOps
  levels_nodup : (ctrl.groups.map CertGroupMeta.level).Nodup
  level_mem_iff : ∀ k : ℕ, k ∈ ctrl.groups.map CertGroupMeta.level ↔ BitActive tbl.nextLifetime k
  slotIds_eq : tbl.slots.map UL.HostedCertSlot.slotId = ctrl.groups.flatMap CertGroupMeta.sids
  slotIds_nodup : (tbl.slots.map UL.HostedCertSlot.slotId).Nodup
  slotIds_lt : ∀ sl ∈ tbl.slots, sl.slotId < tbl.nextSlotId
  slots_inv : ∀ sl ∈ tbl.slots, CertSlotInv n pts h σ facs mkCert sl
  groups_inv : ∀ g ∈ ctrl.groups,
    g.sids.Nodup ∧
    g.sids.length = R ∧
    1 ≤ g.gen.m ∧ g.gen.m ≤ n ∧ g.gen.h = h ∧
    (∀ p ∈ g.gen.P₀, g.gen.pts p = pts p.1) ∧
    (∀ sid ∈ g.sids, ∀ sl ∈ tbl.slots, sl.slotId = sid →
      sl.gen = g.gen ∧ sl.surviving = binSlice tbl.activeLifetimes tbl.nextLifetime g.level)

theorem CertTableInv.toValid {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps R : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    {S : Finset ι} {ctrl : CertCtrlState ι d_s} {tbl : UL.HostedCertTable ι d_s B P}
    (hinv : CertTableInv n maxOps R pts h σ facs mkCert S ctrl tbl) :
    ValidCertTable n h mkCert tbl := by
  intro sl hsl
  rcases hinv.slots_inv sl hsl with ⟨_, hgm, hgh, _, hsub, _, hacc⟩
  exact ⟨hgm, hgh, hsub, hacc⟩

theorem certTableInv_empty {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n maxOps R : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h σ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P) :
    CertTableInv n maxOps R pts h σ facs mkCert ∅
      { groups := [], queue := none } (UL.HostedCertTable.empty ι d_s B P) where
  queue_none := rfl
  img_eq := by simp [UL.HostedCertTable.empty]
  card_eq := by simp [UL.HostedCertTable.empty]
  lt_next := by simp [UL.HostedCertTable.empty]
  unit_active := by simp [UL.HostedCertTable.empty]
  life_le_max := Nat.zero_le maxOps
  levels_nodup := by simp
  level_mem_iff := by
    intro k
    simp [UL.HostedCertTable.empty, BitActive]
  slotIds_eq := rfl
  slotIds_nodup := by simp [UL.HostedCertTable.empty]
  slotIds_lt := by simp [UL.HostedCertTable.empty]
  slots_inv := by simp [UL.HostedCertTable.empty]
  groups_inv := by simp

theorem lt_two_pow_log_succ (M : ℕ) : M < 2 ^ (Nat.log 2 M + 1) := by
  by_cases h0 : M = 0
  · subst h0; simp
  · exact Nat.lt_pow_succ_log_self (by norm_num) M

theorem bitActive_lt_log_succ {H maxOps k : ℕ} (hH : H ≤ maxOps) (hb : BitActive H k) :
    k < Nat.log 2 maxOps + 1 := by
  by_contra hge
  have hle : Nat.log 2 maxOps + 1 ≤ k := by omega
  have hpow : 2 ^ (Nat.log 2 maxOps + 1) ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hle
  have hlt : H < 2 ^ k := lt_of_le_of_lt hH (lt_of_lt_of_le (lt_two_pow_log_succ maxOps) hpow)
  unfold BitActive at hb
  rw [Nat.div_eq_of_lt hlt] at hb
  omega

theorem flatMap_length_le_mul {α β : Type*} (l : List α) (f : α → List β) (R : ℕ)
    (hR : ∀ a ∈ l, (f a).length ≤ R) :
    (l.flatMap f).length ≤ l.length * R := by
  induction l with
  | nil => simp
  | cons a tl ih =>
    simp only [List.flatMap_cons, List.length_append, List.length_cons]
    have ha : (f a).length ≤ R := hR a (List.mem_cons_self)
    have htl : (tl.flatMap f).length ≤ tl.length * R :=
      ih fun x hx => hR x (List.mem_cons_of_mem a hx)
    calc
      (f a).length + (tl.flatMap f).length ≤ R + tl.length * R := add_le_add ha htl
      _ = (tl.length + 1) * R := by ring

theorem CertTableInv.groups_length_le {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps R : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    {S : Finset ι} {ctrl : CertCtrlState ι d_s} {tbl : UL.HostedCertTable ι d_s B P}
    (hinv : CertTableInv n maxOps R pts h σ facs mkCert S ctrl tbl) :
    ctrl.groups.length ≤ Nat.log 2 maxOps + 1 := by
  let L_max := Nat.log 2 maxOps + 1
  have hsub : (ctrl.groups.map CertGroupMeta.level).Subperm (List.range L_max) := by
    rw [List.subperm_iff_count]
    intro k
    by_cases hk : k ∈ ctrl.groups.map CertGroupMeta.level
    · have hc1 : (ctrl.groups.map CertGroupMeta.level).count k = 1 :=
        List.count_eq_one_of_mem hinv.levels_nodup hk
      have hk_lt : k < L_max :=
        bitActive_lt_log_succ hinv.life_le_max ((hinv.level_mem_iff k).mp hk)
      have hc2 : (List.range L_max).count k = 1 :=
        List.count_eq_one_of_mem List.nodup_range (List.mem_range.mpr hk_lt)
      omega
    · rw [List.count_eq_zero_of_not_mem hk]
      exact Nat.zero_le _
  have hlen := hsub.length_le
  simpa using hlen

theorem CertTableInv.slots_length_le {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps R : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    {S : Finset ι} {ctrl : CertCtrlState ι d_s} {tbl : UL.HostedCertTable ι d_s B P}
    (hinv : CertTableInv n maxOps R pts h σ facs mkCert S ctrl tbl) :
    tbl.slots.length ≤ (Nat.log 2 maxOps + 1) * R := by
  have heq : tbl.slots.length = (ctrl.groups.flatMap CertGroupMeta.sids).length := by
    have := congrArg List.length hinv.slotIds_eq
    simpa using this
  rw [heq]
  have h1 : (ctrl.groups.flatMap CertGroupMeta.sids).length ≤ ctrl.groups.length * R :=
    flatMap_length_le_mul ctrl.groups CertGroupMeta.sids R
      (fun g hg => (hinv.groups_inv g hg).2.1.le)
  exact h1.trans (Nat.mul_le_mul_right R hinv.groups_length_le)

theorem CertTableInv.currentSpace_le {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps R : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    {S : Finset ι} {ctrl : CertCtrlState ι d_s} {tbl : UL.HostedCertTable ι d_s B P}
    (hn : 2 ≤ n) (hσ : 0 ≤ σ) (hfacs : facs.Valid) (hS_le : S.card ≤ n)
    (hinv : CertTableInv n maxOps R pts h σ facs mkCert S ctrl tbl) :
    (tbl.currentSpace : ℝ) ≤
      (1 + 2 * (((Nat.log 2 maxOps + 1) * R : ℕ) : ℝ)) * facs.spaceBound n σ := by
  unfold UL.HostedCertTable.currentSpace
  rw [Nat.cast_add, hinv.card_eq]
  have hn_le_sp : (n : ℝ) ≤ facs.spaceBound n σ := by
    unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
    have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
    have hrpow : (n : ℝ) ^ (1 : ℝ) ≤ (n : ℝ) ^ (1 + σ) :=
      Real.rpow_le_rpow_of_exponent_le hn1 (by linarith)
    rw [Real.rpow_one] at hrpow
    have hPs : 1 ≤ facs.P_space := hfacs.2.1
    nlinarith [Real.rpow_nonneg (by positivity : (0 : ℝ) ≤ n) (1 + σ)]
  have hact_le : (S.card : ℝ) ≤ facs.spaceBound n σ :=
    (by exact_mod_cast hS_le : (S.card : ℝ) ≤ n).trans hn_le_sp
  have hsum_le : ∀ l : List (UL.HostedCertSlot ι d_s B P),
      (∀ sl ∈ l, (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ) →
      (((l.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
        (l.length : ℝ) * (2 * facs.spaceBound n σ) := by
    intro l
    induction l with
    | nil => intro _; simp
    | cons sl tl ih =>
      intro hall
      have h1 : (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := hall sl List.mem_cons_self
      have h2 : (((tl.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
          (tl.length : ℝ) * (2 * facs.spaceBound n σ) :=
        ih fun x hx => hall x (List.mem_cons_of_mem sl hx)
      calc
        ((((sl :: tl).map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ)
            = (sl.spaceAlloc : ℝ) + (((tl.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) := by
              simp [List.map_cons, List.sum_cons, Nat.cast_add]
        _ ≤ 2 * facs.spaceBound n σ + (tl.length : ℝ) * (2 * facs.spaceBound n σ) :=
              add_le_add h1 h2
        _ = ((sl :: tl).length : ℝ) * (2 * facs.spaceBound n σ) := by
              simp [List.length_cons, Nat.cast_add]
              ring
  have hslots_sp := hsum_le tbl.slots (fun sl hsl => (hinv.slots_inv sl hsl).2.2.2.2.2.1)
  have hlen_le : (tbl.slots.length : ℝ) ≤ (((Nat.log 2 maxOps + 1) * R : ℕ) : ℝ) := by
    exact_mod_cast hinv.slots_length_le
  have hsp_nn : 0 ≤ facs.spaceBound n σ := by linarith [spaceBound_ge_one hn hσ hfacs]
  have hslots_sp2 :
      (((tbl.slots.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
        (((Nat.log 2 maxOps + 1) * R : ℕ) : ℝ) * (2 * facs.spaceBound n σ) :=
    hslots_sp.trans (mul_le_mul_of_nonneg_right hlen_le (by linarith))
  linarith

noncomputable def slotPot {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (tbl : UL.HostedCertTable ι d_s B P) : ENNReal :=
  (tbl.slots.map (fun sl => remCopyWork (mkCert sl.gen) sl.bState sl.surviving sl.phase)).sum

open Classical in
noncomputable def badGroupCount {ι : Type} {d d_s : ℕ} {B P : Type}
    (N : Finset (EuclideanSpace ℝ (Fin d_s))) (cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (groups : List (CertGroupMeta ι d_s))
    (tbl : UL.HostedCertTable ι d_s B P) : ℕ :=
  (groups.filter (fun g =>
    decide (IsBadGroup (mkCert g.gen) N cap ((groupSlots tbl g.sids).map UL.HostedCertSlot.bState)))).length

noncomputable def certPhi {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (L_max R n : ℕ) (θ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (N : Finset (EuclideanSpace ℝ (Fin d_s))) (cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (rem : ℕ) (groups : List (CertGroupMeta ι d_s))
    (tbl : UL.HostedCertTable ι d_s B P) : ENNReal :=
  slotPot mkCert tbl +
  ((rem * (n + 1) : ℕ) : ENNReal) * (badGroupCount N cap mkCert groups tbl : ENNReal) +
  (elemCredit L_max tbl.activeLifetimes tbl.nextLifetime : ENNReal) *
    ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2))

theorem certPhi_empty {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (L_max R n : ℕ) (θ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (N : Finset (EuclideanSpace ℝ (Fin d_s))) (cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (rem : ℕ) :
    certPhi L_max R n θ facs N cap mkCert rem [] (UL.HostedCertTable.empty ι d_s B P) = 0 := by
  simp [certPhi, slotPot, badGroupCount, UL.HostedCertTable.empty, elemCredit_empty]

/-! ### 4. List Lookup, Filter, Map, and Micro-Queue Lemmas -/

theorem list_find?_eq_some_of_mem_nodup {α : Type*} (l : List α) (idOf : α → ℕ)
    (hnd : (l.map idOf).Nodup) {x : α} (hx : x ∈ l) :
    l.find? (fun s => decide (idOf s = idOf x)) = some x := by
  induction l with
  | nil => simp at hx
  | cons hd tl ih =>
    rw [List.map_cons, List.nodup_cons] at hnd
    rcases List.mem_cons.mp hx with rfl | htl
    · simp [List.find?]
    · have hne : idOf hd ≠ idOf x := by
        intro heq
        exact hnd.1 (heq ▸ List.mem_map_of_mem htl)
      have hdec : decide (idOf hd = idOf x) = false := decide_eq_false hne
      simp [List.find?, hdec, ih hnd.2 htl]

theorem list_find?_filter_of_imp {α : Type*} (l : List α) (p q : α → Bool)
    (himp : ∀ a ∈ l, p a = true → q a = true) :
    (l.filter q).find? p = l.find? p := by
  induction l with
  | nil => rfl
  | cons hd tl ih =>
    have htl := ih fun a ha => himp a (List.mem_cons_of_mem hd ha)
    by_cases hp : p hd = true
    · have hq : q hd = true := himp hd List.mem_cons_self hp
      simp [List.filter_cons, hq, List.find?, hp]
    · have hpf : p hd = false := Bool.eq_false_iff.mpr hp
      cases hq : q hd <;> simp [List.filter_cons, hq, List.find?, hpf, htl]

theorem list_find?_map_congr {α β : Type*} (l : List α) (f : α → β)
    (p₁ : α → Bool) (p₂ : β → Bool)
    (hpred : ∀ a ∈ l, p₂ (f a) = p₁ a) :
    (l.map f).find? p₂ = (l.find? p₁).map f := by
  induction l with
  | nil => rfl
  | cons hd tl ih =>
    simp only [List.map_cons, List.find?]
    rw [hpred hd List.mem_cons_self]
    cases p₁ hd with
    | true => rfl
    | false => exact ih fun a ha => hpred a (List.mem_cons_of_mem hd ha)

theorem groupSlots_bState_map_congr {ι : Type} {d_s : ℕ} {B P : Type}
    (tbl : UL.HostedCertTable ι d_s B P)
    (f : UL.HostedCertSlot ι d_s B P → UL.HostedCertSlot ι d_s B P)
    (hf : ∀ sl ∈ tbl.slots, (f sl).slotId = sl.slotId ∧ (f sl).bState = sl.bState)
    (sids : List ℕ) :
    (groupSlots { tbl with slots := tbl.slots.map f } sids).map UL.HostedCertSlot.bState =
      (groupSlots tbl sids).map UL.HostedCertSlot.bState := by
  unfold groupSlots
  induction sids with
  | nil => rfl
  | cons sid tl ih =>
    have hfind :
        (tbl.slots.map f).find? (fun s => s.slotId = sid) =
          (tbl.slots.find? (fun s => s.slotId = sid)).map f := by
      refine list_find?_map_congr tbl.slots f _ _ fun sl hsl => ?_
      simp [(hf sl hsl).1]
    simp only [List.filterMap_cons, hfind]
    cases h0 : tbl.slots.find? (fun s => s.slotId = sid) with
    | none => exact ih
    | some sl =>
      have hsl : sl ∈ tbl.slots := List.mem_of_find?_eq_some h0
      simp only [Option.map_some, List.map_cons, (hf sl hsl).2, ih]

theorem badGroupCount_map_congr {ι : Type} {d d_s : ℕ} {B P : Type}
    (N : Finset (EuclideanSpace ℝ (Fin d_s))) (cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (groups : List (CertGroupMeta ι d_s))
    (tbl : UL.HostedCertTable ι d_s B P)
    (f : UL.HostedCertSlot ι d_s B P → UL.HostedCertSlot ι d_s B P)
    (hf : ∀ sl ∈ tbl.slots, (f sl).slotId = sl.slotId ∧ (f sl).bState = sl.bState) :
    badGroupCount N cap mkCert groups { tbl with slots := tbl.slots.map f } =
      badGroupCount N cap mkCert groups tbl := by
  unfold badGroupCount
  congr 1
  refine List.filter_congr fun g _ => ?_
  rw [groupSlots_bState_map_congr tbl f hf g.sids]

theorem groupSlots_spec_of_inv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps R : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    {S : Finset ι} {ctrl : CertCtrlState ι d_s} {tbl : UL.HostedCertTable ι d_s B P}
    (hinv : CertTableInv n maxOps R pts h σ facs mkCert S ctrl tbl)
    {g : CertGroupMeta ι d_s} (hg : g ∈ ctrl.groups) :
    (groupSlots tbl g.sids).map UL.HostedCertSlot.slotId = g.sids ∧
    (groupSlots tbl g.sids).length = g.sids.length ∧
    ∀ sl ∈ groupSlots tbl g.sids,
      sl ∈ tbl.slots ∧
      sl.gen = g.gen ∧
      sl.surviving = binSlice tbl.activeLifetimes tbl.nextLifetime g.level := by
  have hsub_sids : ∀ sid ∈ g.sids, ∃ sl ∈ tbl.slots, sl.slotId = sid := by
    intro sid hsid
    have hmem_flat : sid ∈ ctrl.groups.flatMap CertGroupMeta.sids :=
      List.mem_flatMap.mpr ⟨g, hg, hsid⟩
    rw [← hinv.slotIds_eq] at hmem_flat
    exact List.mem_map.mp hmem_flat
  have hfind_all : ∀ sid ∈ g.sids,
      ∃ sl, tbl.slots.find? (fun s => s.slotId = sid) = some sl ∧
        sl ∈ tbl.slots ∧ sl.slotId = sid := by
    intro sid hsid
    rcases hsub_sids sid hsid with ⟨sl, hsl, hid⟩
    have hf := list_find?_eq_some_of_mem_nodup tbl.slots UL.HostedCertSlot.slotId hinv.slotIds_nodup hsl
    rw [hid] at hf
    exact ⟨sl, hf, hsl, hid⟩
  have hgs_eq :
      ∀ l : List ℕ, (∀ sid ∈ l, sid ∈ g.sids) →
        (groupSlots tbl l).map UL.HostedCertSlot.slotId = l ∧
        ∀ sl ∈ groupSlots tbl l, sl ∈ tbl.slots ∧ sl.slotId ∈ l := by
    intro l
    induction l with
    | nil => intro _; simp [groupSlots]
    | cons sid tl ih =>
      intro hsub
      rcases hfind_all sid (hsub sid List.mem_cons_self) with ⟨sl, hf, hsl_mem, hsl_id⟩
      rcases ih (fun x hx => hsub x (List.mem_cons_of_mem sid hx)) with ⟨hmap_tl, hmem_tl⟩
      unfold groupSlots at *
      simp only [List.filterMap_cons, hf, List.map_cons, hsl_id, hmap_tl, true_and]
      intro x hx
      rcases List.mem_cons.mp hx with rfl | hxtl
      · exact ⟨hsl_mem, hsl_id ▸ List.mem_cons_self⟩
      · rcases hmem_tl x hxtl with ⟨hm1, hm2⟩
        exact ⟨hm1, List.mem_cons_of_mem sid hm2⟩
  rcases hgs_eq g.sids (fun _ hx => hx) with ⟨hmap_id, hmem_gs⟩
  refine ⟨hmap_id, ?_, ?_⟩
  · have := congrArg List.length hmap_id
    simpa using this
  · intro sl hsl
    rcases hmem_gs sl hsl with ⟨hsl_tbl, hid_in⟩
    rcases (hinv.groups_inv g hg).2.2.2.2.2.2 sl.slotId hid_in sl hsl_tbl rfl with ⟨hgen, hsurv⟩
    exact ⟨hsl_tbl, hgen, hsurv⟩

theorem runCertHostedStepFuel_plan_eq {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (R cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s)
    (fuel : ℕ) (oldGroups nextGroups : List (CertGroupMeta ι d_s))
    (cmds : List (PlannedCertCmd ι d_s))
    (tbl1 : UL.HostedCertTable ι d_s B P) (bs : List Bool) (accW peakSp : ℕ)
    (hval : ValidCertTable n h mkCert tbl1)
    (hplan : planCertStep pts h h_pos h_lt_one R cap op oldGroups tbl1 = (nextGroups, cmds)) :
    UL.runCertHostedStepFuel n pts h mkCert
      (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
      extHist op (fuel + 1) { groups := oldGroups, queue := none } tbl1 bs accW peakSp =
    UL.runCertHostedStepFuel n pts h mkCert
      (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
      extHist op (fuel + 1) { groups := nextGroups, queue := some cmds } tbl1 bs accW peakSp := by
  conv_lhs => unfold UL.runCertHostedStepFuel
  conv_rhs => unfold UL.runCertHostedStepFuel
  simp only [certStepCtrl, if_pos hval, hplan]

def applyCertRetireIds {ι : Type} {d_s : ℕ} {B P : Type}
    (rids : List ℕ) (tbl : UL.HostedCertTable ι d_s B P) : UL.HostedCertTable ι d_s B P :=
  { tbl with slots := tbl.slots.filter (fun s => decide (s.slotId ∉ rids)) }

theorem validCertTable_filter {ι : Type} {d d_s : ℕ} {B P : Type}
    {n : ℕ} {h : ℝ}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    {tbl : UL.HostedCertTable ι d_s B P} (hval : ValidCertTable n h mkCert tbl)
    (p : UL.HostedCertSlot ι d_s B P → Bool) :
    ValidCertTable n h mkCert { tbl with slots := tbl.slots.filter p } := by
  intro sl hsl
  exact hval sl (List.mem_of_mem_filter hsl)

theorem currentSpace_certFilter_le {ι : Type} {d_s : ℕ} {B P : Type}
    (tbl : UL.HostedCertTable ι d_s B P) (p : UL.HostedCertSlot ι d_s B P → Bool) :
    ({ tbl with slots := tbl.slots.filter p } : UL.HostedCertTable ι d_s B P).currentSpace ≤
      tbl.currentSpace := by
  unfold UL.HostedCertTable.currentSpace
  apply Nat.add_le_add_left
  have haux : ∀ l : List (UL.HostedCertSlot ι d_s B P),
      ((l.filter p).map UL.HostedCertSlot.spaceAlloc).sum ≤
        (l.map UL.HostedCertSlot.spaceAlloc).sum := by
    intro l
    induction l with
    | nil => simp
    | cons a tl ih =>
      simp only [List.filter_cons, List.map_cons, List.sum_cons]
      cases p a <;> simp [ih] <;> omega
  exact haux tbl.slots

theorem slotPot_filter_le {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (tbl : UL.HostedCertTable ι d_s B P) (p : UL.HostedCertSlot ι d_s B P → Bool) :
    slotPot mkCert { tbl with slots := tbl.slots.filter p } ≤ slotPot mkCert tbl := by
  unfold slotPot
  have haux : ∀ (l : List (UL.HostedCertSlot ι d_s B P))
      (f : UL.HostedCertSlot ι d_s B P → ENNReal),
      ((l.filter p).map f).sum ≤ (l.map f).sum := by
    intro l f
    induction l with
    | nil => simp
    | cons a tl ih =>
      cases hp : p a with
      | true =>
        simp only [List.filter_cons, hp, ↓reduceIte, List.map_cons, List.sum_cons]
        exact add_le_add le_rfl ih
      | false =>
        simp only [List.filter_cons, hp, Bool.false_eq_true, ↓reduceIte, List.map_cons, List.sum_cons]
        exact ih.trans le_add_self
  exact haux tbl.slots _

theorem runCertRetireQueue_eq {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (R cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s)
    (groups : List (CertGroupMeta ι d_s)) (rest : List (PlannedCertCmd ι d_s)) :
    ∀ (rids : List ℕ) (restFuel : ℕ) (tbl : UL.HostedCertTable ι d_s B P)
      (bs : List Bool) (accW peakSp : ℕ),
      ValidCertTable n h mkCert tbl →
      tbl.currentSpace ≤ peakSp →
      UL.runCertHostedStepFuel n pts h mkCert
        (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
        extHist op (rids.length + restFuel)
        { groups := groups, queue := some ((rids.map PlannedCertCmd.retireCertSlot) ++ rest) }
        tbl bs accW peakSp =
      UL.runCertHostedStepFuel n pts h mkCert
        (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
        extHist op restFuel
        { groups := groups, queue := some rest }
        (applyCertRetireIds rids tbl) bs (accW + rids.length) peakSp := by
  intro rids
  induction rids with
  | nil =>
    intro restFuel tbl bs accW peakSp _ _
    simp [applyCertRetireIds]
  | cons rid tl ih =>
    intro restFuel tbl bs accW peakSp hval hsp_le
    have hfuel : (rid :: tl).length + restFuel = (tl.length + restFuel) + 1 := by
      simp [Nat.add_right_comm, Nat.add_assoc]
    rw [hfuel]
    conv_lhs => unfold UL.runCertHostedStepFuel
    simp only [certStepCtrl, if_pos hval, List.map_cons, List.cons_append, dispatchCertQueue]
    let tbl' : UL.HostedCertTable ι d_s B P :=
      { tbl with slots := tbl.slots.filter (fun s => s.slotId ≠ rid) }
    have hval' : ValidCertTable n h mkCert tbl' := validCertTable_filter hval _
    have hsp' : tbl'.currentSpace ≤ peakSp :=
      (currentSpace_certFilter_le tbl _).trans hsp_le
    have hmax : max peakSp tbl'.currentSpace = peakSp := max_eq_left hsp'
    change UL.runCertHostedStepFuel n pts h mkCert
        (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
        extHist op (tl.length + restFuel)
        { groups := groups, queue := some ((tl.map PlannedCertCmd.retireCertSlot) ++ rest) }
        tbl' bs (accW + 1) (max peakSp tbl'.currentSpace) = _
    rw [hmax, ih restFuel tbl' bs (accW + 1) peakSp hval' hsp']
    have happly : applyCertRetireIds tl tbl' = applyCertRetireIds (rid :: tl) tbl := by
      unfold applyCertRetireIds
      dsimp only [tbl']
      congr 1
      rw [List.filter_filter]
      refine List.filter_congr fun s _ => ?_
      simp [Bool.and_comm]
    rw [happly]
    congr 1
    omega

theorem runCertFinishUpdate_eq {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (R cap : ℕ)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s)
    (hop : match op with | .query _ => False | _ => True)
    (fuel : ℕ) (groups : List (CertGroupMeta ι d_s))
    (tbl : UL.HostedCertTable ι d_s B P) (accW peakSp : ℕ)
    (hval : ValidCertTable n h mkCert tbl) :
    (fun bs =>
      UL.runCertHostedStepFuel n pts h mkCert
        (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
        extHist op (fuel + 1)
        { groups := groups, queue := some [PlannedCertCmd.finishCertUpdate] }
        tbl bs accW peakSp) =
    endWithEmpty
      { nextState := ({ groups := groups, queue := none }, tbl)
        queryAnswer := none
        work := accW + 1
        peakSpace := max peakSp tbl.currentSpace } := by
  funext bs
  conv_lhs => unfold UL.runCertHostedStepFuel
  simp only [certStepCtrl, if_pos hval, dispatchCertQueue]
  cases op with
  | query _ => contradiction
  | insert _ =>
    cases bs <;> rfl
  | delete _ =>
    cases bs <;> rfl

end UL.Proof_lem_7_1_RaceV31
