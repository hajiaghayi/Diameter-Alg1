import Mathlib
import UL.Stmt.lem_7_1
import UL.Stmt.lem_C_3
import UL.Proof.lem_7_1.RaceV31_H1_Coins
import UL.Proof.lem_7_1.RaceV31_H2_Dyadic
import UL.Proof.lem_7_1.RaceV31_H3_MC
import UL.Proof.lem_7_1.RaceV31_H4a_Pot
import UL.Proof.lem_7_1.RaceV31_H4b_CertStep
import UL.Proof.lem_7_1.RaceV31_H4c_CertIns
import UL.Proof.lem_7_1.RaceCG_H4d_CertDelQry
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. Unified Certified Single-Step Specification (`certStep_any_spec`) -/

noncomputable def certUnitAmortBudget (L_max R n : ℕ) (θ : ℝ) (facs : UL.BirthPoolPolyFactors) : ℝ :=
  10 * (L_max : ℝ) * (R : ℝ) *
    (facs.buildWorkBound 1 n θ + facs.deleteWorkBound n θ + facs.queryWorkBound n θ)

theorem certUnitAmortBudget_nonneg {L_max R n : ℕ} {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hn : 2 ≤ n) (hθ : 0 ≤ θ) (hfacs : facs.Valid) :
    0 ≤ certUnitAmortBudget L_max R n θ facs := by
  unfold certUnitAmortBudget
  have hb := buildWorkBound_one_ge_one hn hθ hfacs
  have hd := deleteWorkBound_ge_one hn hθ hfacs
  have hq := queryWorkBound_ge_one hn hθ hfacs
  have hsum : 0 ≤ facs.buildWorkBound 1 n θ + facs.deleteWorkBound n θ + facs.queryWorkBound n θ := by
    linarith
  have hLR : 0 ≤ 10 * (L_max : ℝ) * (R : ℝ) := by positivity
  exact mul_nonneg hLR hsum

theorem certStep_any_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound P_life : ℝ}
    (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hPlife : 1 ≤ P_life) (hnet0 : 0 ≤ netLogBound)
    (hmaxOps : (maxOps : ℝ) ≤ (n : ℝ) * P_life)
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    (hN_net : UL.IsValidImplicitDirectionNet N netLogBound)
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    (extHist : UL.ExecutionHistory d)
    {S : Finset ι} {ctrl : CertCtrlState ι d_s} {tbl0 : UL.HostedCertTable ι d_s B P}
    (hinv : CertTableInv n maxOps (certGroupCopies n P_life netLogBound)
      pts h σ facs mkCert S ctrl tbl0)
    (hS_le : S.card ≤ n)
    (hH_lt : tbl0.nextLifetime < maxOps)
    {op : UL.DynamicSearchOp ι d_s}
    (hleg : UL.IsLegalDynamicSearchOp n pts
      (fun S' q =>
        q.z ∈ N ∧
        ((δ_margin = 0 ∧ UL.IsCompatibleTest pts S' q.z q.accept) ∨
          UL.IsMarginCompatibleTest pts S' δ_margin q.z q.accept))
      S op) :
    let L_max := Nat.log 2 maxOps + 1
    let R := certGroupCopies n P_life netLogBound
    let cap := certCap n θ facs
    let dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
      n pts h mkCert
    let stepFn := UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) op
    UL.singleDynamicSearchStepHaltProb dynIdx extHist S (ctrl, tbl0) op = 1 ∧
    (∀ bs S' out, stepFn bs = some (S', out) →
      S'.card ≤ n ∧
      out.nextState.2.nextLifetime ≤ tbl0.nextLifetime + 1 ∧
      CertTableInv n maxOps R pts h σ facs mkCert S' out.nextState.1 out.nextState.2 ∧
      (out.peakSpace : ℝ) ≤ (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ ∧
      (∀ q ans, op = .query q → out.queryAnswer = some ans →
        UL.IsCorrectSearchAnswer pts S h q.z q.accept ans)) ∧
    (∀ rem : ℕ, rem ≤ maxOps →
      expWithBits stepFn (fun res =>
        (res.2.work : ENNReal) +
          certPhi L_max R n θ facs N cap mkCert rem res.2.nextState.1.groups res.2.nextState.2) ≤
      certPhi L_max R n θ facs N cap mkCert (rem + 1) ctrl.groups tbl0 +
        ENNReal.ofReal (certUnitAmortBudget L_max R n θ facs)) := by
  dsimp only []
  set L_max := Nat.log 2 maxOps + 1
  set R := certGroupCopies n P_life netLogBound
  set cap := certCap n θ facs
  have hθ_nn : 0 ≤ θ := hσθ.2.1.trans hσθ.2.2
  have hb_ge1 := buildWorkBound_one_ge_one hσθ.1 hθ_nn hfacs
  have hd_ge1 := deleteWorkBound_ge_one hσθ.1 hθ_nn hfacs
  have hq_ge1 := queryWorkBound_ge_one hσθ.1 hθ_nn hfacs
  have hL_ge1 : (1 : ℝ) ≤ (L_max : ℝ) := by
    dsimp only [L_max]
    exact_mod_cast (by omega : 1 ≤ Nat.log 2 maxOps + 1)
  have hR_ge3_nat : 3 ≤ R := certGroupCopies_ge_three hσθ.1 hPlife hnet0
  have hR_ge3 : (3 : ℝ) ≤ (R : ℝ) := by exact_mod_cast hR_ge3_nat
  set LR : ℝ := (L_max : ℝ) * (R : ℝ)
  have hLR_ge3 : 3 ≤ LR := by dsimp [LR]; nlinarith
  have hbud_eq : certUnitAmortBudget L_max R n θ facs =
      10 * LR * (facs.buildWorkBound 1 n θ + facs.deleteWorkBound n θ + facs.queryWorkBound n θ) := by
    unfold certUnitAmortBudget
    dsimp [LR]
    ring
  cases op with
  | insert id₀ =>
    rcases certStep_insert_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hPlife hnet0 hmaxOps hN_net hCert extHist hinv hH_lt hleg with
      ⟨hhalt, hpath, hexp⟩
    refine ⟨hhalt, ?_, ?_⟩
    · intro bs S' out hs
      rcases hpath bs S' out hs with ⟨hS', _, hnl, hinv', hsp'⟩
      refine ⟨hS' ▸ hleg.2.1, by omega, hinv', hsp', fun _ _ hop _ => by cases hop⟩
    · intro rem hrem_le
      refine (hexp rem hrem_le).trans (add_le_add le_rfl (ENNReal.ofReal_le_ofReal ?_))
      have hlhs : 7 * (L_max : ℝ) * (R : ℝ) * facs.buildWorkBound 1 n θ =
          7 * LR * facs.buildWorkBound 1 n θ := by dsimp [LR]; ring
      rw [hlhs, hbud_eq]
      nlinarith
  | delete id₀ =>
    rcases certStep_delete_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hCert extHist hinv hS_le hleg with
      ⟨hhalt, hpath, hexp⟩
    refine ⟨hhalt, ?_, ?_⟩
    · intro bs S' out hs
      rcases hpath bs S' out hs with ⟨hS', _, hnl, hinv', hsp'⟩
      refine ⟨hS' ▸ (Finset.card_erase_le.trans hS_le), by omega, hinv', hsp',
        fun _ _ hop _ => by cases hop⟩
    · intro rem _
      have hcast : ((L_max * R + 2 : ℕ) : ENNReal) = ENNReal.ofReal ((L_max * R + 2 : ℕ) : ℝ) :=
        (ENNReal.ofReal_natCast _).symm
      refine (hexp rem).trans ?_
      rw [hcast]
      refine add_le_add le_rfl (ENNReal.ofReal_le_ofReal ?_)
      have hlhs : ((L_max * R + 2 : ℕ) : ℝ) = LR + 2 := by dsimp [LR]; push_cast; ring
      rw [hlhs, hbud_eq]
      nlinarith
  | query q =>
    rcases certStep_query_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hPlife hnet0 hCert extHist hinv hS_le q hleg with
      ⟨hhalt, hpath, hexp⟩
    refine ⟨hhalt, ?_, ?_⟩
    · intro bs S' out hs
      rcases hpath bs S' out hs with ⟨hS', hnl, hinv', hsp', ans, hqa, hcorr⟩
      refine ⟨hS' ▸ hS_le, by omega, hinv', hsp', ?_⟩
      intro q' ans' hop hqa'
      cases hop
      rw [hqa] at hqa'
      cases hqa'
      exact hcorr
    · intro rem _
      have hcast : ((L_max * R * (cap + 1) + 2 : ℕ) : ENNReal) =
          ENNReal.ofReal ((L_max * R * (cap + 1) + 2 : ℕ) : ℝ) :=
        (ENNReal.ofReal_natCast _).symm
      refine (hexp rem).trans ?_
      rw [hcast]
      refine add_le_add le_rfl (ENNReal.ofReal_le_ofReal ?_)
      have hcap5 : (cap : ℝ) ≤ 5 * facs.queryWorkBound n θ :=
        certCap_le_five_query hσθ.1 hθ_nn hfacs
      have hlhs : ((L_max * R * (cap + 1) + 2 : ℕ) : ℝ) = LR * ((cap : ℝ) + 1) + 2 := by
        dsimp [LR]; push_cast; ring
      rw [hlhs, hbud_eq]
      nlinarith

/-! ### 2. Reachable Prefix Invariant & Inductive Expected Amortized Work -/

structure CertReachableInv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    (n maxOps R : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h σ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P)
    (S_cap : ℝ)
    (cur : UL.DynamicSearchPrefixState ι d d_s (CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P)) :
    Prop where
  tbl_inv : CertTableInv n maxOps R pts h σ facs mkCert cur.activeSet cur.dynState.1 cur.dynState.2
  card_le_n : cur.activeSet.card ≤ n
  life_le_hist : cur.dynState.2.nextLifetime ≤ cur.history.length
  qrecs_ok : ∀ rec ∈ cur.queryRecords,
    UL.IsCorrectSearchAnswer pts rec.1 h rec.2.1.z rec.2.1.accept rec.2.2
  space_le : (cur.maxSpace : ℝ) ≤ S_cap

theorem certRunStepsFrom_inv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound P_life : ℝ}
    (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hPlife : 1 ≤ P_life) (hnet0 : 0 ≤ netLogBound)
    (hmaxOps : (maxOps : ℝ) ≤ (n : ℝ) * P_life)
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    (hN_net : UL.IsValidImplicitDirectionNet N netLogBound)
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    {S_cap : ℝ}
    (hS_cap :
      (1 + 2 * (((Nat.log 2 maxOps + 1) * certGroupCopies n P_life netLogBound : ℕ) : ℝ)) *
        facs.spaceBound n σ ≤ S_cap)
    (adv : UL.DynamicSearchAdversary ι d d_s)
    (hadv : UL.IsValidBoundedDynamicSearchAdversary n maxOps pts
      (fun S' q =>
        q.z ∈ N ∧
        ((δ_margin = 0 ∧ UL.IsCompatibleTest pts S' q.z q.accept) ∨
          UL.IsMarginCompatibleTest pts S' δ_margin q.z q.accept))
      ((certController n pts h h_pos h_lt_one (Nat.log 2 maxOps + 1)
          (certGroupCopies n P_life netLogBound) (certCap n θ facs) mkCert).toDynamicSearchIndex
        n pts h mkCert)
      adv) :
    ∀ (restTrace pastTrace : List (List Bool))
      (cur out : UL.DynamicSearchPrefixState ι d d_s
        (CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P)),
      UL.runDynamicSearchSteps
        ((certController n pts h h_pos h_lt_one (Nat.log 2 maxOps + 1)
            (certGroupCopies n P_life netLogBound) (certCap n θ facs) mkCert).toDynamicSearchIndex
          n pts h mkCert)
        adv pastTrace = some cur →
      cur.history.length = pastTrace.length →
      CertReachableInv n maxOps (certGroupCopies n P_life netLogBound)
        pts h σ facs mkCert S_cap cur →
      (pastTrace ++ restTrace).length ≤ maxOps →
      UL.runDynamicSearchStepsFrom
        ((certController n pts h h_pos h_lt_one (Nat.log 2 maxOps + 1)
            (certGroupCopies n P_life netLogBound) (certCap n θ facs) mkCert).toDynamicSearchIndex
          n pts h mkCert)
        adv cur restTrace = some out →
      UL.runDynamicSearchSteps
        ((certController n pts h h_pos h_lt_one (Nat.log 2 maxOps + 1)
            (certGroupCopies n P_life netLogBound) (certCap n θ facs) mkCert).toDynamicSearchIndex
          n pts h mkCert)
        adv (pastTrace ++ restTrace) = some out ∧
      out.history.length = (pastTrace ++ restTrace).length ∧
      CertReachableInv n maxOps (certGroupCopies n P_life netLogBound)
        pts h σ facs mkCert S_cap out := by
  set L_max := Nat.log 2 maxOps + 1
  set R := certGroupCopies n P_life netLogBound
  set cap := certCap n θ facs
  set dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
    n pts h mkCert
  intro restTrace
  induction restTrace with
  | nil =>
    intro pastTrace cur out hrun_past hlen hinv _ hrun_rest
    simp only [UL.runDynamicSearchStepsFrom, Option.some.injEq] at hrun_rest
    subst hrun_rest
    simp [hrun_past, hlen, hinv]
  | cons bs rest ih =>
    intro pastTrace cur out hrun_past hlen hinv htot_le hrun_rest
    have hpast_lt : pastTrace.length < maxOps := by
      simp only [List.length_append, List.length_cons] at htot_le
      omega
    have hH_lt : cur.dynState.2.nextLifetime < maxOps := by
      have := hinv.life_le_hist
      omega
    have hleg := hadv pastTrace hpast_lt cur hrun_past
    rcases certStep_any_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hPlife hnet0 hmaxOps hN_net hCert (adv cur.history).1
        hinv.tbl_inv hinv.card_le_n hH_lt hleg with
      ⟨_, hpath, _⟩
    simp only [UL.runDynamicSearchStepsFrom] at hrun_rest
    cases hs : UL.runSingleDynamicSearchStep dynIdx (adv cur.history).1
        cur.activeSet cur.dynState (adv cur.history).2 bs with
    | none => simp [hs] at hrun_rest
    | some pair =>
      rcases pair with ⟨S', stepOut⟩
      simp only [hs] at hrun_rest
      rcases hpath bs S' stepOut hs with ⟨hcard', hlife', htbl', hsp', hqok⟩
      let entry : UL.DynamicSearchHistoryEntry ι d d_s :=
        { extHistory := (adv cur.history).1
          operation := (adv cur.history).2
          randomBits := bs
          queryAnswer := stepOut.queryAnswer }
      let qRecs :=
        match (adv cur.history).2, stepOut.queryAnswer with
        | .query q, some ans => cur.queryRecords ++ [(cur.activeSet, q, ans)]
        | _, _ => cur.queryRecords
      let next : UL.DynamicSearchPrefixState ι d d_s
          (CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P) :=
        { activeSet := S'
          dynState := stepOut.nextState
          history := cur.history ++ [entry]
          queryRecords := qRecs
          stepWorks := cur.stepWorks ++ [stepOut.work]
          totalWork := cur.totalWork + stepOut.work
          maxSpace := max cur.maxSpace stepOut.peakSpace }
      have hrun_one : UL.runDynamicSearchStepsFrom dynIdx adv cur [bs] = some next := by
        simp only [UL.runDynamicSearchStepsFrom, hs]; rfl
      have hrun_past' : UL.runDynamicSearchSteps dynIdx adv (pastTrace ++ [bs]) = some next := by
        unfold UL.runDynamicSearchSteps at hrun_past ⊢
        rw [runDynamicSearchStepsFrom_append dynIdx adv pastTrace [bs] _ cur hrun_past]
        exact hrun_one
      have hlen' : next.history.length = (pastTrace ++ [bs]).length := by
        dsimp only [next]; simp [hlen]
      have hinv' : CertReachableInv n maxOps R pts h σ facs mkCert S_cap next :=
        { tbl_inv := htbl'
          card_le_n := hcard'
          life_le_hist := by
            dsimp only [next]; simp only [List.length_append, List.length_singleton]
            have := hinv.life_le_hist
            omega
          qrecs_ok := by
            intro rec hrec
            dsimp only [next, qRecs] at hrec
            cases hop : (adv cur.history).2 with
            | insert _ =>
              rw [hop] at hrec
              exact hinv.qrecs_ok rec hrec
            | delete _ =>
              rw [hop] at hrec
              exact hinv.qrecs_ok rec hrec
            | query q =>
              rw [hop] at hrec
              cases hqa : stepOut.queryAnswer with
              | none =>
                rw [hqa] at hrec
                exact hinv.qrecs_ok rec hrec
              | some ans =>
                rw [hqa] at hrec
                rcases List.mem_append.mp hrec with h0 | h1
                · exact hinv.qrecs_ok rec h0
                · simp only [List.mem_singleton] at h1
                  subst h1
                  exact hqok q ans hop hqa
          space_le := by
            dsimp only [next]
            rw [Nat.cast_max]
            exact max_le hinv.space_le (hsp'.trans hS_cap) }
      have htot_le' : ((pastTrace ++ [bs]) ++ rest).length ≤ maxOps := by
        simpa [List.append_assoc] using htot_le
      rcases ih (pastTrace ++ [bs]) next out hrun_past' hlen' hinv' htot_le' hrun_rest with
        ⟨hr1, hr2, hr3⟩
      simpa [List.append_assoc] using And.intro hr1 (And.intro hr2 hr3)

theorem certExpWorkFrom_le {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound P_life : ℝ}
    (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hPlife : 1 ≤ P_life) (hnet0 : 0 ≤ netLogBound)
    (hmaxOps : (maxOps : ℝ) ≤ (n : ℝ) * P_life)
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    (hN_net : UL.IsValidImplicitDirectionNet N netLogBound)
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    {S_cap : ℝ}
    (hS_cap :
      (1 + 2 * (((Nat.log 2 maxOps + 1) * certGroupCopies n P_life netLogBound : ℕ) : ℝ)) *
        facs.spaceBound n σ ≤ S_cap)
    (adv : UL.DynamicSearchAdversary ι d d_s)
    (hadv : UL.IsValidBoundedDynamicSearchAdversary n maxOps pts
      (fun S' q =>
        q.z ∈ N ∧
        ((δ_margin = 0 ∧ UL.IsCompatibleTest pts S' q.z q.accept) ∨
          UL.IsMarginCompatibleTest pts S' δ_margin q.z q.accept))
      ((certController n pts h h_pos h_lt_one (Nat.log 2 maxOps + 1)
          (certGroupCopies n P_life netLogBound) (certCap n θ facs) mkCert).toDynamicSearchIndex
        n pts h mkCert)
      adv) :
    let L_max := Nat.log 2 maxOps + 1
    let R := certGroupCopies n P_life netLogBound
    let cap := certCap n θ facs
    let dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
      n pts h mkCert
    let U_step := ENNReal.ofReal (certUnitAmortBudget L_max R n θ facs)
    ∀ (k : ℕ) (pastTrace : List (List Bool))
      (cur : UL.DynamicSearchPrefixState ι d d_s
        (CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P)),
      UL.runDynamicSearchSteps dynIdx adv pastTrace = some cur →
      cur.history.length = pastTrace.length →
      CertReachableInv n maxOps R pts h σ facs mkCert S_cap cur →
      pastTrace.length + k ≤ maxOps →
      (∑' tr : Fin k → List Bool,
        match UL.runDynamicSearchStepsFrom dynIdx adv cur (List.ofFn tr) with
        | some out =>
            UL.prefixTraceProb tr *
              ((out.totalWork : ENNReal) +
                certPhi L_max R n θ facs N cap mkCert 0 out.dynState.1.groups out.dynState.2)
        | none => 0) ≤
      (cur.totalWork : ENNReal) +
        certPhi L_max R n θ facs N cap mkCert k cur.dynState.1.groups cur.dynState.2 +
        (k : ENNReal) * U_step := by
  dsimp only []
  set L_max := Nat.log 2 maxOps + 1
  set R := certGroupCopies n P_life netLogBound
  set cap := certCap n θ facs
  set dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
    n pts h mkCert
  set U_step := ENNReal.ofReal (certUnitAmortBudget L_max R n θ facs)
  intro k
  induction k with
  | zero =>
    intro pastTrace cur _ _ _ _
    rw [tsum_fin_zero]
    simp [ofFn_fin_zero, UL.runDynamicSearchStepsFrom, prefixTraceProb_zero]
  | succ m ih =>
    intro pastTrace cur hrun_past hlen hinv htot_le
    have hpast_lt : pastTrace.length < maxOps := by omega
    have hm_le : m ≤ maxOps := by omega
    have hH_lt : cur.dynState.2.nextLifetime < maxOps := by
      have := hinv.life_le_hist
      omega
    have hleg := hadv pastTrace hpast_lt cur hrun_past
    rcases certStep_any_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hPlife hnet0 hmaxOps hN_net hCert (adv cur.history).1
        hinv.tbl_inv hinv.card_le_n hH_lt hleg with
      ⟨hhalt_step, _, hexp_step⟩
    have hhalt_step' :
        haltProb (UL.runSingleDynamicSearchStep dynIdx (adv cur.history).1
          cur.activeSet cur.dynState (adv cur.history).2) = 1 :=
      hhalt_step
    rw [tsum_fin_succ]
    let stepFn := UL.runSingleDynamicSearchStep dynIdx (adv cur.history).1
      cur.activeSet cur.dynState (adv cur.history).2
    let C_cur : ENNReal := (cur.totalWork : ENNReal) + (m : ENNReal) * U_step
    have hinner_le : ∀ bs : List Bool,
        (∑' rest : Fin m → List Bool,
          match UL.runDynamicSearchStepsFrom dynIdx adv cur (List.ofFn (Fin.cons bs rest)) with
          | some out =>
              UL.prefixTraceProb (Fin.cons bs rest) *
                ((out.totalWork : ENNReal) +
                  certPhi L_max R n θ facs N cap mkCert 0 out.dynState.1.groups out.dynState.2)
          | none => 0) ≤
        match stepFn bs with
        | some res =>
            UL.bitListProb bs *
              (C_cur +
                ((res.2.work : ENNReal) +
                  certPhi L_max R n θ facs N cap mkCert m
                    res.2.nextState.1.groups res.2.nextState.2))
        | none => 0 := by
      intro bs
      cases hs : stepFn bs with
      | none =>
        have h0 : ∀ rest : Fin m → List Bool,
            (match UL.runDynamicSearchStepsFrom dynIdx adv cur (List.ofFn (Fin.cons bs rest)) with
             | some out =>
                 UL.prefixTraceProb (Fin.cons bs rest) *
                   ((out.totalWork : ENNReal) +
                     certPhi L_max R n θ facs N cap mkCert 0 out.dynState.1.groups out.dynState.2)
             | none => 0) = 0 := by
          intro rest
          rw [ofFn_fin_cons]
          dsimp only [stepFn] at hs
          simp [UL.runDynamicSearchStepsFrom, hs]
        simp_rw [h0, tsum_zero]
        exact le_rfl
      | some res =>
        rcases res with ⟨S', stepOut⟩
        dsimp only []
        let entry : UL.DynamicSearchHistoryEntry ι d d_s :=
          { extHistory := (adv cur.history).1
            operation := (adv cur.history).2
            randomBits := bs
            queryAnswer := stepOut.queryAnswer }
        let qRecs :=
          match (adv cur.history).2, stepOut.queryAnswer with
          | .query q, some ans => cur.queryRecords ++ [(cur.activeSet, q, ans)]
          | _, _ => cur.queryRecords
        let next : UL.DynamicSearchPrefixState ι d d_s
            (CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P) :=
          { activeSet := S'
            dynState := stepOut.nextState
            history := cur.history ++ [entry]
            queryRecords := qRecs
            stepWorks := cur.stepWorks ++ [stepOut.work]
            totalWork := cur.totalWork + stepOut.work
            maxSpace := max cur.maxSpace stepOut.peakSpace }
        have hrun_one : UL.runDynamicSearchStepsFrom dynIdx adv cur [bs] = some next := by
          dsimp only [stepFn] at hs
          simp only [UL.runDynamicSearchStepsFrom, hs]
          rfl
        have hpast_le1 : (pastTrace ++ [bs]).length ≤ maxOps := by
          simp only [List.length_append, List.length_singleton]
          omega
        rcases certRunStepsFrom_inv (h_pos := h_pos) (h_lt_one := h_lt_one)
            hσθ hfacs hPlife hnet0 hmaxOps hN_net hCert hS_cap adv hadv
            [bs] pastTrace cur next hrun_past hlen hinv hpast_le1 hrun_one with
          ⟨hrun_past', hlen', hinv'⟩
        have htot_le' : (pastTrace ++ [bs]).length + m ≤ maxOps := by
          simp only [List.length_append, List.length_singleton]
          omega
        have hrew : ∀ rest : Fin m → List Bool,
            (match UL.runDynamicSearchStepsFrom dynIdx adv cur (List.ofFn (Fin.cons bs rest)) with
             | some out =>
                 UL.prefixTraceProb (Fin.cons bs rest) *
                   ((out.totalWork : ENNReal) +
                     certPhi L_max R n θ facs N cap mkCert 0 out.dynState.1.groups out.dynState.2)
             | none => 0) =
            UL.bitListProb bs *
              (match UL.runDynamicSearchStepsFrom dynIdx adv next (List.ofFn rest) with
               | some out =>
                   UL.prefixTraceProb rest *
                     ((out.totalWork : ENNReal) +
                       certPhi L_max R n θ facs N cap mkCert 0 out.dynState.1.groups out.dynState.2)
               | none => 0) := by
          intro rest
          have hcons_app : List.ofFn (Fin.cons bs rest) = [bs] ++ List.ofFn rest := by
            rw [ofFn_fin_cons, List.singleton_append]
          rw [hcons_app, prefixTraceProb_cons,
              runDynamicSearchStepsFrom_append dynIdx adv [bs] (List.ofFn rest) cur next hrun_one]
          cases UL.runDynamicSearchStepsFrom dynIdx adv next (List.ofFn rest) <;> simp [mul_assoc]
        simp_rw [hrew]
        rw [ENNReal.tsum_mul_left]
        refine mul_le_mul_of_nonneg_left ?_ (zero_le _)
        refine (ih (pastTrace ++ [bs]) next hrun_past' hlen' hinv' htot_le').trans (le_of_eq ?_)
        dsimp only [next, C_cur]
        push_cast
        ring
    have hsum_le :
        (∑' bs : List Bool,
          ∑' rest : Fin m → List Bool,
            match UL.runDynamicSearchStepsFrom dynIdx adv cur (List.ofFn (Fin.cons bs rest)) with
            | some out =>
                UL.prefixTraceProb (Fin.cons bs rest) *
                  ((out.totalWork : ENNReal) +
                    certPhi L_max R n θ facs N cap mkCert 0 out.dynState.1.groups out.dynState.2)
            | none => 0) ≤
        expWithBits stepFn (fun res =>
          C_cur +
            ((res.2.work : ENNReal) +
              certPhi L_max R n θ facs N cap mkCert m
                res.2.nextState.1.groups res.2.nextState.2)) := by
      unfold expWithBits
      refine ENNReal.tsum_le_tsum fun bs => (hinner_le bs).trans ?_
      cases stepFn bs <;> rfl
    refine hsum_le.trans ?_
    dsimp only [stepFn]
    rw [expWithBits_const_add_of_haltProb_one hhalt_step']
    calc
      C_cur +
        expWithBits
          (UL.runSingleDynamicSearchStep dynIdx (adv cur.history).1
            cur.activeSet cur.dynState (adv cur.history).2)
          (fun res =>
            (res.2.work : ENNReal) +
              certPhi L_max R n θ facs N cap mkCert m
                res.2.nextState.1.groups res.2.nextState.2)
          ≤ C_cur +
              (certPhi L_max R n θ facs N cap mkCert (m + 1)
                cur.dynState.1.groups cur.dynState.2 + U_step) :=
            add_le_add le_rfl (hexp_step m hm_le)
      _ = (cur.totalWork : ENNReal) +
            certPhi L_max R n θ facs N cap mkCert (m + 1)
              cur.dynState.1.groups cur.dynState.2 +
            ((m + 1 : ℕ) : ENNReal) * U_step := by
            dsimp only [C_cur]
            push_cast
            ring

/-! ### 3. Complete Part 2 Certified Wrapper Theorem (`part2_cert_wrapper`) & `P_lem_7_1` -/

theorem part2_cert_wrapper
    {C_wrap : ℝ} {deg_log : ℕ}
    (hC : 1000 ≤ C_wrap) (hdeg : 2 ≤ deg_log)
    (d d_s n : ℕ) (ι : Type) [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (σ θ : ℝ) (hσθ : UL.ValidBirthPoolExponents n σ θ)
    (facs : UL.BirthPoolPolyFactors) (hfacs : facs.Valid)
    (P_life : ℝ) (hPlife : 1 ≤ P_life)
    (maxOps : ℕ) (hmaxOps : (maxOps : ℝ) ≤ (n : ℝ) * P_life)
    (δ_margin netLogBound : ℝ) (_hδ0 : 0 ≤ δ_margin) (hnet0 : 0 ≤ netLogBound)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (hN_net : UL.IsValidImplicitDirectionNet N netLogBound)
    (CertBirthState CertPhaseState : Type)
    (mkCert : UL.SearchGeneration (ι × ℕ) d_s →
      UL.CertifiedSearchGeneration (ι × ℕ) d d_s CertBirthState CertPhaseState)
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen)) :
    let certAdmissible : Finset ι → UL.SearchQuery ι d_s → Prop := fun S q =>
      q.z ∈ N ∧
      ((δ_margin = 0 ∧ UL.IsCompatibleTest pts S q.z q.accept) ∨
        UL.IsMarginCompatibleTest pts S δ_margin q.z q.accept)
    let logFacCert : ℝ :=
      (1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound) ^ deg_log
    let amortWorkBound : ℝ :=
      C_wrap * logFacCert * (n : ℝ) ^ θ * facs.P_time *
        (facs.P_build + facs.P_del + facs.P_query)
    let spaceBoundCert : ℝ :=
      C_wrap * logFacCert * (n : ℝ) ^ (1 + σ) * facs.P_space
    ∃ (CtrlState : Type)
      (ctrl : UL.CertHostedController ι d_s CertBirthState CertPhaseState CtrlState),
      let dynIdx := ctrl.toDynamicSearchIndex (d := d) n pts h mkCert
      (∀ extHist S st op bs₁ bs₂ out₁ out₂,
        dynIdx.stepWithBits extHist S st op bs₁ = some out₁ →
        dynIdx.stepWithBits extHist S st op bs₂ = some out₂ →
        bs₁ <+: bs₂ → bs₁ = bs₂) ∧
      (dynIdx.initSpace : ℝ) ≤ spaceBoundCert ∧
      (∀ adv : UL.DynamicSearchAdversary ι d d_s,
        UL.IsValidBoundedDynamicSearchAdversary n maxOps pts certAdmissible dynIdx adv →
          (∀ bitTrace : List (List Bool), bitTrace.length < maxOps →
            ∀ prefSt,
              UL.runDynamicSearchSteps dynIdx adv bitTrace = some prefSt →
                let (extHist, op) := adv prefSt.history
                UL.singleDynamicSearchStepHaltProb dynIdx extHist
                  prefSt.activeSet prefSt.dynState op = 1) ∧
          (∀ T : ℕ, T ≤ maxOps → ∀ trace : Fin T → List Bool, ∀ out,
            UL.runDynamicSearchPrefix dynIdx adv T trace = some out →
              (∀ rec ∈ out.queryRecords,
                UL.IsCorrectSearchAnswer pts rec.1 h rec.2.1.z rec.2.1.accept rec.2.2) ∧
              (out.maxSpace : ℝ) ≤ spaceBoundCert) ∧
          (∀ T : ℕ, 1 ≤ T → T ≤ maxOps →
            UL.dynamicSearchPrefixExpectedWork dynIdx adv T ≠ ⊤ ∧
            (UL.dynamicSearchPrefixExpectedWork dynIdx adv T).toReal / (T : ℝ) ≤
              amortWorkBound)) := by
  dsimp only []
  let certAdmissible : Finset ι → UL.SearchQuery ι d_s → Prop := fun S q =>
    q.z ∈ N ∧
    ((δ_margin = 0 ∧ UL.IsCompatibleTest pts S q.z q.accept) ∨
      UL.IsMarginCompatibleTest pts S δ_margin q.z q.accept)
  let B_cert : ℝ := 1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound
  let logFacCert : ℝ := B_cert ^ deg_log
  let amortWorkBound : ℝ :=
    C_wrap * logFacCert * (n : ℝ) ^ θ * facs.P_time *
      (facs.P_build + facs.P_del + facs.P_query)
  let spaceBoundCert : ℝ :=
    C_wrap * logFacCert * (n : ℝ) ^ (1 + σ) * facs.P_space
  let L_max := Nat.log 2 maxOps + 1
  let R := certGroupCopies n P_life netLogBound
  let cap := certCap n θ facs
  let ctrl := certController n pts h h_pos h_lt_one L_max R cap mkCert
  let dynIdx := ctrl.toDynamicSearchIndex (d := d) n pts h mkCert
  have hlog_nn : 0 ≤ Real.log (2 * (n : ℝ) * P_life) :=
    log_two_n_Plife_nonneg hσθ.1 hPlife
  have hB_ge1 : 1 ≤ B_cert := by dsimp [B_cert]; linarith
  have hB2_le_logFac : B_cert ^ 2 ≤ logFacCert :=
    pow_le_pow_right₀ hB_ge1 hdeg
  have hB2_ge1 : 1 ≤ B_cert ^ 2 := by
    have := mul_le_mul hB_ge1 hB_ge1 zero_le_one (by linarith)
    linarith
  have hlogFac_ge1 : 1 ≤ logFacCert := hB2_ge1.trans hB2_le_logFac
  have hL_le : (L_max : ℝ) ≤ 2 * B_cert := by
    have h1 : (Nat.log 2 maxOps + 1 : ℝ) ≤ 2 * (1 + Real.log (2 * (n : ℝ) * P_life)) :=
      log_succ_le_two_one_add_log hσθ.1 hPlife hmaxOps
    dsimp [L_max, B_cert]
    push_cast
    linarith
  have hR_le : (R : ℝ) ≤ 6 * B_cert :=
    certGroupCopies_le_six_base hσθ.1 hPlife hnet0
  have hLR_le : (L_max : ℝ) * (R : ℝ) ≤ 12 * B_cert ^ 2 := by
    have hmul := mul_le_mul hL_le hR_le (Nat.cast_nonneg R) (by linarith)
    have h12 : (2 * B_cert) * (6 * B_cert) = 12 * B_cert ^ 2 := by ring
    linarith
  have hθ_nn : 0 ≤ θ := hσθ.2.1.trans hσθ.2.2
  have ht_ge1 : 1 ≤ (n : ℝ) ^ θ * facs.P_time :=
    targetTime_ge_one hσθ.1 hθ_nn hfacs
  have hPsum_ge1 : 1 ≤ facs.P_build + facs.P_del + facs.P_query := by
    have := hfacs.2.2.1; have := hfacs.2.2.2.1; have := hfacs.2.2.2.2
    linarith
  have hsp_ge1 : 1 ≤ (n : ℝ) ^ (1 + σ) * facs.P_space :=
    spaceBound_ge_one hσθ.1 hσθ.2.1 hfacs
  have hC_mul_log : 1000 * B_cert ^ 2 ≤ C_wrap * logFacCert :=
    mul_le_mul hC hB2_le_logFac (by positivity) (by linarith)
  have hclog : 1 ≤ C_wrap * logFacCert := by linarith
  have hS_cap :
      (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ ≤ spaceBoundCert := by
    have hcoeff : 1 + 2 * ((L_max * R : ℕ) : ℝ) ≤ C_wrap * logFacCert := by
      push_cast
      linarith
    have hsp_nn : 0 ≤ (n : ℝ) ^ (1 + σ) * facs.P_space := by linarith
    calc
      (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ
          = (1 + 2 * ((L_max * R : ℕ) : ℝ)) * ((n : ℝ) ^ (1 + σ) * facs.P_space) := by
              unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
              ring
      _ ≤ (C_wrap * logFacCert) * ((n : ℝ) ^ (1 + σ) * facs.P_space) :=
            mul_le_mul_of_nonneg_right hcoeff hsp_nn
      _ = spaceBoundCert := by dsimp [spaceBoundCert]; ring
  have hW_cap : certUnitAmortBudget L_max R n θ facs + 1 ≤ amortWorkBound := by
    have hsum_eq :
        facs.buildWorkBound 1 n θ + facs.deleteWorkBound n θ + facs.queryWorkBound n θ =
          (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) := by
      unfold UL.BirthPoolPolyFactors.buildWorkBound UL.birthPoolBuildWorkBound
        UL.BirthPoolPolyFactors.deleteWorkBound UL.birthPoolDeleteWorkBound
        UL.BirthPoolPolyFactors.queryWorkBound UL.birthPoolQueryWorkBound
        UL.BirthPoolPolyFactors.targetTime UL.birthPoolTargetTime
      simp only [Nat.cast_one, one_mul]
      ring
    set Tail := (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query)
    have hTail_ge1 : 1 ≤ Tail := by
      dsimp [Tail]
      have := mul_le_mul ht_ge1 hPsum_ge1 zero_le_one (by linarith)
      linarith
    have h1 : certUnitAmortBudget L_max R n θ facs = 10 * ((L_max : ℝ) * (R : ℝ)) * Tail := by
      unfold certUnitAmortBudget
      rw [hsum_eq]
      ring
    have h2 : 10 * ((L_max : ℝ) * (R : ℝ)) * Tail + 1 ≤ (C_wrap * logFacCert) * Tail := by
      have hmul_LR : 10 * ((L_max : ℝ) * (R : ℝ)) * Tail ≤ 120 * B_cert ^ 2 * Tail := by
        have := mul_le_mul_of_nonneg_right hLR_le (by linarith : 0 ≤ Tail)
        linarith
      have h1_le : 1 ≤ B_cert ^ 2 * Tail := by
        have := mul_le_mul hB2_ge1 hTail_ge1 zero_le_one (by linarith)
        linarith
      have h121 : 121 * B_cert ^ 2 ≤ C_wrap * logFacCert := by linarith
      have hmul_C : 121 * B_cert ^ 2 * Tail ≤ (C_wrap * logFacCert) * Tail :=
        mul_le_mul_of_nonneg_right h121 (by linarith : 0 ≤ Tail)
      linarith
    calc
      certUnitAmortBudget L_max R n θ facs + 1
          = 10 * ((L_max : ℝ) * (R : ℝ)) * Tail + 1 := by rw [h1]
      _ ≤ (C_wrap * logFacCert) * Tail := h2
      _ = amortWorkBound := by dsimp [amortWorkBound, Tail]; ring
  have hinitS_le : (dynIdx.initSpace : ℝ) ≤ spaceBoundCert := by
    have his : dynIdx.initSpace = 1 := rfl
    rw [his, Nat.cast_one]
    have hmul_init := mul_le_mul hclog hsp_ge1 zero_le_one (by linarith)
    calc
      (1 : ℝ) ≤ (C_wrap * logFacCert) * ((n : ℝ) ^ (1 + σ) * facs.P_space) := by linarith
      _ = spaceBoundCert := by dsimp [spaceBoundCert]; ring
  have hinit_inv : CertReachableInv n maxOps R pts h σ facs mkCert spaceBoundCert
      (UL.initDynamicSearchPrefixState dynIdx) :=
    { tbl_inv := certTableInv_empty n maxOps R pts h σ facs mkCert
      card_le_n := Nat.zero_le n
      life_le_hist := by
        have hnl0 : (UL.initDynamicSearchPrefixState dynIdx).dynState.2.nextLifetime = 0 := rfl
        rw [hnl0]
        exact Nat.zero_le _
      qrecs_ok := by
        intro rec hrec
        have hqr0 : (UL.initDynamicSearchPrefixState dynIdx).queryRecords = [] := rfl
        rw [hqr0] at hrec
        cases hrec
      space_le := hinitS_le }
  refine ⟨CertCtrlState ι d_s, ctrl, ?_, hinitS_le, ?_⟩
  · intro extHist S st op bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
    exact isPrefixFree_certDynIdx hCert extHist S st op bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
  · intro adv hadv
    refine ⟨?_, ?_, ?_⟩
    · -- (a) Almost-sure halting at every reachable prefix `< maxOps`
      intro bitTrace hlen_lt prefSt hrun
      have hrun_empty : UL.runDynamicSearchSteps dynIdx adv [] =
          some (UL.initDynamicSearchPrefixState dynIdx) := rfl
      have hhist0 : (UL.initDynamicSearchPrefixState dynIdx).history.length = ([] : List (List Bool)).length := rfl
      rcases certRunStepsFrom_inv (h_pos := h_pos) (h_lt_one := h_lt_one)
          hσθ hfacs hPlife hnet0 hmaxOps hN_net hCert hS_cap adv hadv
          bitTrace [] (UL.initDynamicSearchPrefixState dynIdx) prefSt
          hrun_empty hhist0 hinit_inv (by simpa using Nat.le_of_lt hlen_lt) hrun with
        ⟨_, hhist_len, hpref_inv⟩
      have hH_lt : prefSt.dynState.2.nextLifetime < maxOps := by
        have := hpref_inv.life_le_hist
        simp only [List.nil_append] at hhist_len
        omega
      have hleg := hadv bitTrace hlen_lt prefSt hrun
      exact (certStep_any_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hPlife hnet0 hmaxOps hN_net hCert (adv prefSt.history).1
        hpref_inv.tbl_inv hpref_inv.card_le_n hH_lt hleg).1
    · -- (b) Zero-error query answers & deterministic `maxSpace` cap on every path
      intro T hT_le trace out hrun_pref
      have hrun_empty : UL.runDynamicSearchSteps dynIdx adv [] =
          some (UL.initDynamicSearchPrefixState dynIdx) := rfl
      have hhist0 : (UL.initDynamicSearchPrefixState dynIdx).history.length = ([] : List (List Bool)).length := rfl
      have hlen_ofFn : (([] : List (List Bool)) ++ List.ofFn trace).length ≤ maxOps := by
        simpa using hT_le
      rcases certRunStepsFrom_inv (h_pos := h_pos) (h_lt_one := h_lt_one)
          hσθ hfacs hPlife hnet0 hmaxOps hN_net hCert hS_cap adv hadv
          (List.ofFn trace) [] (UL.initDynamicSearchPrefixState dynIdx) out
          hrun_empty hhist0 hinit_inv hlen_ofFn hrun_pref with
        ⟨_, _, hout_inv⟩
      exact ⟨hout_inv.qrecs_ok, hout_inv.space_le⟩
    · -- (c) Expected amortized work bound over `1 ≤ T ≤ maxOps`
      intro T hT_pos hT_le
      have hrun_empty : UL.runDynamicSearchSteps dynIdx adv [] =
          some (UL.initDynamicSearchPrefixState dynIdx) := rfl
      have hhist0 : (UL.initDynamicSearchPrefixState dynIdx).history.length = ([] : List (List Bool)).length := rfl
      have hexp_bound := certExpWorkFrom_le (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hPlife hnet0 hmaxOps hN_net hCert hS_cap adv hadv
        T [] (UL.initDynamicSearchPrefixState dynIdx)
        hrun_empty hhist0 hinit_inv (by simpa using hT_le)
      have hphi_init :
          certPhi L_max R n θ facs N cap mkCert T
            (UL.initDynamicSearchPrefixState dynIdx).dynState.1.groups
            (UL.initDynamicSearchPrefixState dynIdx).dynState.2 = 0 :=
        certPhi_empty L_max R n θ facs N cap mkCert T
      have htot_init : (UL.initDynamicSearchPrefixState dynIdx).totalWork = 1 := rfl
      let U_real := certUnitAmortBudget L_max R n θ facs
      have hU_nn : 0 ≤ U_real := certUnitAmortBudget_nonneg hσθ.1 hθ_nn hfacs
      have hexp_le_ofReal :
          UL.dynamicSearchPrefixExpectedWork dynIdx adv T ≤
            ENNReal.ofReal (1 + (T : ℝ) * U_real) := by
        refine (le_trans ?_ hexp_bound).trans (le_of_eq ?_)
        · unfold UL.dynamicSearchPrefixExpectedWork UL.runDynamicSearchPrefix UL.runDynamicSearchSteps
          refine ENNReal.tsum_le_tsum fun tr => ?_
          dsimp only [dynIdx, ctrl, L_max, R, cap]
          cases UL.runDynamicSearchStepsFrom
              ((certController n pts h h_pos h_lt_one (Nat.log 2 maxOps + 1)
                  (certGroupCopies n P_life netLogBound) (certCap n θ facs) mkCert).toDynamicSearchIndex
                n pts h mkCert)
              adv (UL.initDynamicSearchPrefixState dynIdx) (List.ofFn tr) with
          | none => exact le_rfl
          | some out =>
            dsimp only []
            exact mul_le_mul_of_nonneg_left le_self_add (zero_le _)
        · dsimp only [U_real]
          rw [htot_init, hphi_init, Nat.cast_one, add_zero]
          have hT_cast : (T : ENNReal) = ENNReal.ofReal (T : ℝ) :=
            (ENNReal.ofReal_natCast T).symm
          rw [hT_cast, ← ENNReal.ofReal_mul (Nat.cast_nonneg T),
              ← ENNReal.ofReal_one,
              ← ENNReal.ofReal_add zero_le_one (mul_nonneg (Nat.cast_nonneg T) hU_nn)]
      have hne_top : UL.dynamicSearchPrefixExpectedWork dynIdx adv T ≠ ⊤ :=
        ne_of_lt (lt_of_le_of_lt hexp_le_ofReal ENNReal.ofReal_lt_top)
      refine ⟨hne_top, ?_⟩
      have htoReal_le :
          (UL.dynamicSearchPrefixExpectedWork dynIdx adv T).toReal ≤ 1 + (T : ℝ) * U_real := by
        have h1 := ENNReal.toReal_mono ENNReal.ofReal_ne_top hexp_le_ofReal
        rwa [ENNReal.toReal_ofReal (by positivity)] at h1
      have hT_ge1 : (1 : ℝ) ≤ (T : ℝ) := by exact_mod_cast hT_pos
      have hT_pos_real : (0 : ℝ) < (T : ℝ) := by linarith
      rw [div_le_iff₀ hT_pos_real]
      calc
        (UL.dynamicSearchPrefixExpectedWork dynIdx adv T).toReal
            ≤ 1 + (T : ℝ) * U_real := htoReal_le
        _ ≤ (T : ℝ) + (T : ℝ) * U_real := by linarith
        _ = (U_real + 1) * (T : ℝ) := by ring
        _ ≤ amortWorkBound * (T : ℝ) := mul_le_mul_of_nonneg_right hW_cap (by positivity)

end UL.Proof_lem_7_1_RaceV31

