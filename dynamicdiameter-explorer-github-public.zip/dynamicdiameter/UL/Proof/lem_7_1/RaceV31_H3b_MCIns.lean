import Mathlib
import UL.Stmt.lem_7_1
import UL.Proof.lem_7_1.RaceV31_H1_Coins
import UL.Proof.lem_7_1.RaceV31_H2_Dyadic
import UL.Proof.lem_7_1.RaceV31_H3a_MCStep
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. Queue Initialization & Retirement Helpers -/

theorem runMCHostedStepFuel_plan_eq {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s)
    (fuel : ℕ) (ctrl : MCCtrlState ι d_s) (tbl : UL.HostedMCTable ι d_s B I)
    (bs : List Bool) (accWork peakSp : ℕ)
    {nextMetas : List MCSlotMeta} {cmds : List (PlannedMCCmd ι d_s)}
    (hq : ctrl.queue = none)
    (hv : ValidMCTable n h mkMC tbl)
    (hplan : planMCStep n pts h h_pos h_lt_one θ facs op ctrl.metas tbl = (nextMetas, cmds)) :
    UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
      extHist op (fuel + 1) ctrl tbl bs accWork peakSp =
    UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
      extHist op (fuel + 1) { metas := nextMetas, queue := some cmds } tbl bs accWork peakSp := by
  have hcmd :
      mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC op ctrl tbl =
      mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC op
        { metas := nextMetas, queue := some cmds } tbl := by
    unfold mcStepCtrl
    rw [if_pos hv, if_pos hv, hq]
    dsimp only []
    rw [hplan]
  conv_lhs => unfold UL.runMCHostedStepFuel
  conv_rhs => unfold UL.runMCHostedStepFuel
  rw [hcmd]

theorem list_filter_filter {α : Type*} (p q : α → Bool) :
    ∀ l : List α, (l.filter p).filter q = l.filter (fun x => p x && q x)
  | [] => rfl
  | x :: xs => by
    cases hpx : p x
    · simp only [List.filter_cons, hpx, Bool.false_and]
      exact list_filter_filter p q xs
    · simp only [List.filter_cons, hpx, Bool.true_and]
      cases hqx : q x <;> simp [List.filter_cons, hqx, list_filter_filter p q xs]

theorem list_filter_congr {α : Type*} {p q : α → Bool} :
    ∀ {l : List α}, (∀ x ∈ l, p x = q x) → l.filter p = l.filter q
  | [], _ => rfl
  | x :: xs, h => by
    have hx : p x = q x := h x (by simp)
    have ih : xs.filter p = xs.filter q :=
      list_filter_congr (fun y hy => h y (by simp [hy]))
    simp only [List.filter_cons, hx, ih]

theorem applyRetireIds_eq_filter {ι : Type} {d_s : ℕ} {B I : Type} :
    ∀ (rids : List ℕ) (sls : List (UL.HostedMCSlot ι d_s B I)),
      applyRetireIds rids sls = open Classical in sls.filter (fun s => decide (s.slotId ∉ rids))
  | [], sls => by
    classical
    symm
    exact (list_filter_congr (q := fun _ => true) (fun s _ => by simp)).trans (List.filter_true _)
  | rid :: rids, sls => by
    classical
    unfold applyRetireIds
    rw [applyRetireIds_eq_filter rids]
    rw [list_filter_filter]
    refine list_filter_congr (fun s _ => ?_)
    by_cases h1 : s.slotId = rid <;> by_cases h2 : s.slotId ∈ rids <;> simp [h1, h2]

theorem forall₂_filter_lockstep {α β : Type*} {R : α → β → Prop}
    {pm : α → Bool} {ps : β → Bool}
    {ms : List α} {sls : List β}
    (hrel : List.Forall₂ R ms sls)
    (hp : ∀ m sl, m ∈ ms → sl ∈ sls → R m sl → pm m = ps sl) :
    List.Forall₂ R (ms.filter pm) (sls.filter ps) := by
  induction hrel with
  | nil => exact List.Forall₂.nil
  | @cons m sl ms' sls' hhd _ ih =>
    simp only [List.filter_cons]
    have heq : pm m = ps sl := hp m sl (by simp) (by simp) hhd
    rw [← heq]
    cases pm m
    · exact ih (fun m' sl' hm' hsl' hr => hp m' sl' (by simp [hm']) (by simp [hsl']) hr)
    · exact List.Forall₂.cons hhd
        (ih (fun m' sl' hm' hsl' hr => hp m' sl' (by simp [hm']) (by simp [hsl']) hr))

theorem forall₂_append_one {α β : Type*} {R : α → β → Prop}
    {as : List α} {bs : List β} {a : α} {b : β}
    (hrel : List.Forall₂ R as bs) (hab : R a b) :
    List.Forall₂ R (as ++ [a]) (bs ++ [b]) := by
  induction hrel with
  | nil => exact List.Forall₂.cons hab List.Forall₂.nil
  | cons hh _ ih => exact List.Forall₂.cons hh ih

theorem forall₂_map_slotId_eq {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)} {h σ θ : ℝ}
    {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    {active : Finset (ι × ℕ)} {tc : ℕ}
    {ms : List MCSlotMeta} {sls : List (UL.HostedMCSlot ι d_s B I)}
    (hrel : List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC active tc) ms sls) :
    ms.map MCSlotMeta.slotId = sls.map UL.HostedMCSlot.slotId := by
  induction hrel with
  | nil => rfl
  | cons hh _ ih => simp [hh.1, ih]

theorem eq_meta_of_mem_of_slotId_eq
    {ms : List MCSlotMeta} (hnodup : (ms.map MCSlotMeta.slotId).Nodup)
    {m₁ m₂ : MCSlotMeta} (h₁ : m₁ ∈ ms) (h₂ : m₂ ∈ ms) (heq : m₁.slotId = m₂.slotId) :
    m₁ = m₂ := by
  induction ms with
  | nil => simp at h₁
  | cons hd tl ih =>
    rw [List.map_cons, List.nodup_cons] at hnodup
    rcases List.mem_cons.mp h₁ with e₁ | e₁ <;> rcases List.mem_cons.mp h₂ with e₂ | e₂
    · exact e₁.trans e₂.symm
    · exfalso; subst e₁; exact hnodup.1 (heq ▸ List.mem_map_of_mem e₂)
    · exfalso; subst e₂; exact hnodup.1 (heq.symm ▸ List.mem_map_of_mem e₁)
    · exact ih hnodup.2 e₁ e₂

theorem nodup_of_map_comp {α β γ : Type*} (f : α → β) (g : β → γ) :
    ∀ {l : List α}, (l.map (g ∘ f)).Nodup → (l.map f).Nodup
  | [], _ => List.nodup_nil
  | x :: xs, h => by
    rw [List.map_cons, List.nodup_cons] at h ⊢
    refine ⟨fun hmem => h.1 ?_, nodup_of_map_comp f g h.2⟩
    rcases List.mem_map.mp hmem with ⟨y, hy, hfy⟩
    exact List.mem_map.mpr ⟨y, hy, by dsimp [Function.comp]; rw [hfy]⟩

/-! ### 2. Properties of `buildOpenSpecs` -/

def OpenSpecEntryInv {ι : Type} [DecidableEq ι] {d_s : ℕ}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h : ℝ)
    (A₁ : Finset (ι × ℕ)) (H1 : ℕ)
    (sp : MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s) : Prop :=
  (sp.1.j + 1) * 2 ^ sp.1.k = H1 ∧
  sp.2.P₀ = A₁.filter (fun p => sp.1.j * 2 ^ sp.1.k ≤ p.2 ∧ p.2 < (sp.1.j + 1) * 2 ^ sp.1.k) ∧
  1 ≤ sp.2.m ∧ sp.2.m ≤ 2 ^ sp.1.k ∧ sp.2.m ≤ n ∧
  sp.2.h = h ∧
  (∀ p ∈ sp.2.P₀, sp.2.pts p = pts p.1)

theorem buildOpenSpecs_spec {ι : Type} [DecidableEq ι] {d_s : ℕ}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {A₁ : Finset (ι × ℕ)} {H : ℕ} {id₀ : ι}
    (hid_mem : (id₀, H) ∈ A₁)
    (hcard : A₁.card ≤ n)
    (hunit : ∀ p ∈ A₁, UL.IsUnitVec (pts p.1))
    (hinj : ∀ r₁ ∈ A₁, ∀ r₂ ∈ A₁, r₁.2 = r₂.2 → r₁ = r₂) :
    ∀ (ks : List ℕ) (startSid : ℕ),
      (∀ k ∈ ks, 2 ^ k ∣ (H + 1)) →
      ∃ specs : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s),
        buildOpenSpecs pts h h_pos h_lt_one A₁ (H + 1) startSid ks = some specs ∧
        specs.map (fun sp => sp.1.k) = ks ∧
        specs.map (fun sp => sp.1.slotId) = (List.range ks.length).map (startSid + ·) ∧
        (∀ sp ∈ specs, OpenSpecEntryInv n pts h A₁ (H + 1) sp) := by
  intro ks
  induction ks with
  | nil =>
    intro startSid _
    exact ⟨[], rfl, rfl, rfl, fun _ h => by simp at h⟩
  | cons k ks ih =>
    intro startSid hdiv
    have hk_div : 2 ^ k ∣ (H + 1) := hdiv k (by simp)
    have hpow_pos : 0 < 2 ^ k := Nat.two_pow_pos k
    have hq_pos : 1 ≤ (H + 1) / 2 ^ k := Nat.div_pos (Nat.le_of_dvd (by omega) hk_div) hpow_pos
    let j := (H + 1) / 2 ^ k - 1
    have hj_eq : (j + 1) * 2 ^ k = H + 1 := by
      have hj1 : j + 1 = (H + 1) / 2 ^ k := by omega
      rw [hj1]
      exact Nat.div_mul_cancel hk_div
    let P₀ := A₁.filter (fun p => j * 2 ^ k ≤ p.2 ∧ p.2 < H + 1)
    have hid_P₀ : (id₀, H) ∈ P₀ := by
      rw [Finset.mem_filter]
      refine ⟨hid_mem, ?_, by omega⟩
      have hpow1 : 1 ≤ 2 ^ k := Nat.one_le_two_pow
      have h1 : j * 2 ^ k + 2 ^ k = H + 1 := by
        calc j * 2 ^ k + 2 ^ k = (j + 1) * 2 ^ k := by ring
        _ = H + 1 := hj_eq
      omega
    have hP : P₀.Nonempty ∧ ∀ p ∈ P₀, UL.IsUnitVec (pts p.1) :=
      ⟨⟨(id₀, H), hid_P₀⟩, fun p hp => hunit p (Finset.mem_of_mem_filter p hp)⟩
    rcases ih (startSid + 1) (fun k' hk' => hdiv k' (by simp [hk'])) with
      ⟨rest, hrest, hks_eq, hsids_eq, hinv_rest⟩
    let gen : UL.SearchGeneration (ι × ℕ) d_s :=
      { P₀ := P₀
        pts := fun p => pts p.1
        nonempty := hP.1
        unit_pts := hP.2
        h := h
        h_pos := h_pos
        h_lt_one := h_lt_one }
    let hd : MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s :=
      ({ slotId := startSid, k := k, j := j }, gen)
    refine ⟨hd :: rest, ?_, ?_, ?_, ?_⟩
    · unfold buildOpenSpecs
      classical
      dsimp only []
      rw [dif_pos hP, hrest]
    · simp [hd, hks_eq]
    · simp only [List.map_cons, hd, hsids_eq, List.length_cons, List.range_succ_eq_map,
        List.map_map]
      congr 1
      apply List.map_congr_left
      intro i _
      dsimp only [Function.comp]
      omega
    · intro sp hsp
      rcases List.mem_cons.mp hsp with rfl | htl
      · refine ⟨hj_eq, ?_, ?_, ?_, ?_, rfl, fun _ _ => rfl⟩
        · dsimp only [hd, gen, P₀]
          rw [hj_eq]
        · exact Finset.card_pos.mpr hP.1
        · dsimp only [hd, gen, UL.SearchGeneration.m, P₀]
          have hc := card_filter_lt_le_of_injOn_snd A₁ hinj (j * 2 ^ k) (H + 1)
          have hsub : H + 1 - j * 2 ^ k = 2 ^ k := by
            have h1 : j * 2 ^ k + 2 ^ k = H + 1 := by
              calc j * 2 ^ k + 2 ^ k = (j + 1) * 2 ^ k := by ring
              _ = H + 1 := hj_eq
            omega
          omega
        · dsimp only [hd, gen, UL.SearchGeneration.m]
          exact (Finset.card_le_card (Finset.filter_subset _ _)).trans hcard
      · exact hinv_rest sp htl

theorem openLevels_length_le_log_succ {H1 : ℕ} (hpos : 0 < H1) :
    (openLevels H1).length ≤ Nat.log 2 H1 + 1 := by
  have hnodup : (openLevels H1).Nodup := nodup_openLevels H1
  have hsub : (openLevels H1).toFinset ⊆ Finset.range (Nat.log 2 H1 + 1) := by
    intro k hk
    rw [List.mem_toFinset, mem_openLevels_iff hpos] at hk
    rw [Finset.mem_range]
    have hpow : 2 ^ k ≤ H1 := Nat.le_of_dvd hpos hk
    have hle : k ≤ Nat.log 2 H1 := Nat.le_log_of_pow_le (by norm_num) hpow
    omega
  calc
    (openLevels H1).length = (openLevels H1).toFinset.card :=
      (List.toFinset_card_of_nodup hnodup).symm
    _ ≤ (Finset.range (Nat.log 2 H1 + 1)).card := Finset.card_le_card hsub
    _ = Nat.log 2 H1 + 1 := Finset.card_range _

/-! ### 3. Opening Queue + Payment + FinishUpdate Execution -/

theorem nat_sub_mul_sub_self (D H1 u : ℕ) :
    (D - H1) * u - u = (D - (H1 + 1)) * u := by
  by_cases h : H1 < D
  · have h1 : D - H1 = (D - (H1 + 1)) + 1 := by omega
    rw [h1, add_one_mul]
    omega
  · have h1 : D - H1 = 0 := by omega
    have h2 : D - (H1 + 1) = 0 := by omega
    rw [h1, h2]
    simp

theorem build_unpaidWork_le {n m k : ℕ} {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hm_pow : m ≤ 2 ^ k)
    {bWork : ℕ} (hb : (bWork : ℝ) ≤ facs.buildWorkBound m n θ) :
    bWork + m ≤ 2 ^ k * unitBuildBudget n θ facs := by
  have hceil : facs.buildWorkBound 1 n θ ≤ (Nat.ceil (facs.buildWorkBound 1 n θ) : ℝ) :=
    Nat.le_ceil _
  have hu : facs.buildWorkBound 1 n θ + 1 ≤ (unitBuildBudget n θ facs : ℝ) := by
    unfold unitBuildBudget
    push_cast
    linarith
  have hm_nn : (0 : ℝ) ≤ (m : ℝ) := Nat.cast_nonneg m
  have hb_eq : facs.buildWorkBound m n θ = (m : ℝ) * facs.buildWorkBound 1 n θ :=
    buildWorkBound_eq_mul_one facs m n θ
  have hreal : ((bWork + m : ℕ) : ℝ) ≤ ((m * unitBuildBudget n θ facs : ℕ) : ℝ) := by
    push_cast
    calc (bWork : ℝ) + (m : ℝ)
      _ ≤ (m : ℝ) * facs.buildWorkBound 1 n θ + (m : ℝ) := by linarith
      _ = (m : ℝ) * (facs.buildWorkBound 1 n θ + 1) := by ring
      _ ≤ (m : ℝ) * (unitBuildBudget n θ facs : ℝ) := mul_le_mul_of_nonneg_left hu hm_nn
  have hnat : bWork + m ≤ m * unitBuildBudget n θ facs := by exact_mod_cast hreal
  exact hnat.trans (Nat.mul_le_mul_right _ hm_pow)

theorem forall₂_slotInv_after_payAll {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)} {h σ θ : ℝ}
    {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    {active : Finset (ι × ℕ)} {tc : ℕ}
    {pids : List ℕ}
    {ms : List MCSlotMeta} {sls sls' : List (UL.HostedMCSlot ι d_s B I)}
    (hrel1 : List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC active tc) ms sls)
    (hrel2 : List.Forall₂ (PaySlotRel pids (unitBuildBudget n θ facs)) sls sls')
    (hall : ∀ m ∈ ms, m.slotId ∈ pids) :
    List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC active (tc + 1)) ms sls' := by
  induction hrel1 generalizing sls' with
  | nil =>
    cases hrel2
    exact List.Forall₂.nil
  | @cons m sl ms₀ sls₀ hh₁ _ ih =>
    cases hrel2 with
    | @cons _ sl' _ sls'₀ hh₂ htl₂ =>
      refine List.Forall₂.cons ?_ (ih htl₂ (fun m' hm' => hall m' (by simp [hm'])))
      rcases hh₁ with ⟨hid, hm1, hmn, hh_eq, hpts, hsurv, hsub, hval, hun, hsp⟩
      rcases hh₂ with ⟨hid₂, hgen₂, hb₂, hsurv₂, hidx₂, hsp₂, _, hpay⟩
      have hm_in : sl.slotId ∈ pids := by
        rw [← hid]
        exact hall m (by simp)
      have hun' : sl'.unpaidWork ≤
          ((m.j + 2) * 2 ^ m.k - (tc + 1)) * unitBuildBudget n θ facs := by
        calc sl'.unpaidWork
          _ ≤ sl.unpaidWork - unitBuildBudget n θ facs := hpay hm_in
          _ ≤ ((m.j + 2) * 2 ^ m.k - tc) * unitBuildBudget n θ facs - unitBuildBudget n θ facs :=
              Nat.sub_le_sub_right hun _
          _ = ((m.j + 2) * 2 ^ m.k - (tc + 1)) * unitBuildBudget n θ facs :=
              nat_sub_mul_sub_self _ _ _
      refine ⟨hid.trans hid₂.symm, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hun', ?_⟩
      · rwa [hgen₂]
      · rwa [hgen₂]
      · rwa [hgen₂]
      · rwa [hgen₂]
      · rwa [hsurv₂]
      · rwa [hsurv₂, hgen₂]
      · rwa [hgen₂, hb₂, hsurv₂, hidx₂]
      · rwa [hsp₂]

theorem birthSuccessProb_eq_expWithBits {ι : Type} {d d_s : ℕ} {B I : Type}
    (inst : UL.MonteCarloSearchGeneration ι d d_s B I)
    (birthHist : UL.ExecutionHistory d) :
    expWithBits (inst.buildWithBits birthHist)
      (fun bOut => open Classical in if inst.IsBirthSuccess birthHist bOut.birthState then 1 else 0) =
      inst.birthSuccessProb birthHist := by
  unfold expWithBits UL.MonteCarloSearchGeneration.birthSuccessProb
  refine tsum_congr fun bs => ?_
  cases inst.buildWithBits birthHist bs with
  | none => rfl
  | some bOut =>
    classical
    by_cases hs : inst.IsBirthSuccess birthHist bOut.birthState <;> simp [hs]

theorem runOpenPayFinish_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n K : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hδ0 : 0 ≤ δ_fail)
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    (extHist : UL.ExecutionHistory d) (id₀ : ι) :
    ∀ (specs : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s))
      (accMetas : List MCSlotMeta) (fuel : ℕ)
      (tbl : UL.HostedMCTable ι d_s B I) (accWork peakSp : ℕ),
      let nextMetas := accMetas ++ specs.map Prod.fst
      let uBud := unitBuildBudget n θ facs
      let payCmds := nextMetas.map (fun m => PlannedMCCmd.payWork m.slotId uBud)
      let cmds := (specs.map (fun sp => PlannedMCCmd.openSlot sp.2)) ++ payCmds ++ [PlannedMCCmd.finishUpdate]
      let f_run := fun bs =>
        UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
          extHist (.insert id₀) (specs.length + nextMetas.length + 1 + fuel)
          { metas := nextMetas, queue := some cmds } tbl bs accWork peakSp
      tbl.activeLifetimes.card ≤ n →
      nextMetas.length ≤ K →
      List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl.activeLifetimes tbl.nextLifetime)
        accMetas tbl.slots →
      (tbl.slots.map UL.HostedMCSlot.slotId).Nodup →
      (∀ sl ∈ tbl.slots, sl.slotId < tbl.nextSlotId) →
      specs.map (fun sp => sp.1.slotId) = (List.range specs.length).map (tbl.nextSlotId + ·) →
      (∀ sp ∈ specs, OpenSpecEntryInv n pts h tbl.activeLifetimes tbl.nextLifetime sp) →
      tbl.currentSpace ≤ peakSp →
      (peakSp : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ →
      haltProb f_run = 1 ∧
      (∀ bs out, f_run bs = some out →
        out.queryAnswer = none ∧
        out.nextState.1 = { metas := nextMetas, queue := none } ∧
        out.nextState.2.activeLifetimes = tbl.activeLifetimes ∧
        out.nextState.2.nextLifetime = tbl.nextLifetime ∧
        (out.nextState.2.slots.map UL.HostedMCSlot.slotId).Nodup ∧
        (∀ sl ∈ out.nextState.2.slots, sl.slotId < out.nextState.2.nextSlotId) ∧
        List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl.activeLifetimes (tbl.nextLifetime + 1))
          nextMetas out.nextState.2.slots ∧
        out.work ≤ accWork + specs.length + nextMetas.length * (uBud + 1) + 1 ∧
        (out.peakSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ) ∧
      (AllSlotsGood mkMC tbl →
        ENNReal.ofReal (1 - (specs.length : ℝ) * δ_fail) ≤
          expWithBits f_run (fun out =>
            open Classical in if AllSlotsGood mkMC out.nextState.2 then 1 else 0)) := by
  intro specs
  induction specs with
  | nil =>
    intro accMetas fuel tbl accWork peakSp
    dsimp only []
    intro hact_le hlen_K hrel_acc hnodup hsid_lt _ _ hsp_le hpeak_real
    let nextMetas := accMetas ++ ([] : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s)).map Prod.fst
    let uBud := unitBuildBudget n θ facs
    let pids := nextMetas.map MCSlotMeta.slotId
    have hnext_eq : nextMetas = accMetas := List.append_nil _
    have hv : ValidMCTable n h mkMC tbl := validMCTable_of_forall₂ hrel_acc
    have hmap_eq : pids = tbl.slots.map UL.HostedMCSlot.slotId := by
      dsimp only [pids]; rw [hnext_eq]; exact forall₂_map_slotId_eq hrel_acc
    have hpids_mem : ∀ sid ∈ pids, sid ∈ tbl.slots.map UL.HostedMCSlot.slotId := by
      rw [hmap_eq]; exact fun _ hm => hm
    have hfuel_eq : 0 + nextMetas.length + 1 + fuel = pids.length + (fuel + 1) := by
      simp [pids]; omega
    rcases runPayQueue_exists extHist (.insert id₀) nextMetas uBud pids [PlannedMCCmd.finishUpdate]
        (fuel + 1) tbl [] accWork peakSp hv hnodup hsp_le hpids_mem with
      ⟨paidWork, slots', hpaid_le, hrel_pay, hrun_nil⟩
    let tbl_fin : UL.HostedMCTable ι d_s B I := { tbl with slots := slots' }
    let out₀ : UL.DynamicSearchStepOutcome (MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I) ι :=
      { nextState := ({ metas := nextMetas, queue := none }, tbl_fin)
        queryAnswer := none
        work := accWork + paidWork + 1
        peakSpace := peakSp }
    have hv_fin : ValidMCTable n h mkMC tbl_fin := forall₂_paySlotRel_valid hv hrel_pay
    have hsp_fin : tbl_fin.currentSpace ≤ peakSp := by
      have heq : tbl_fin.currentSpace = tbl.currentSpace := by
        unfold UL.HostedMCTable.currentSpace
        change tbl.activeLifetimes.card + (slots'.map UL.HostedMCSlot.spaceAlloc).sum = _
        rw [forall₂_paySlotRel_map_spaceAlloc hrel_pay]
      rwa [heq]
    have hfun_eq :
        (fun bs =>
          UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
            extHist (.insert id₀)
            (([] : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s)).length +
              (accMetas ++ ([] : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s)).map Prod.fst).length + 1 + fuel)
            { metas := accMetas ++ ([] : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s)).map Prod.fst,
              queue := some
                (((([] : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s)).map (fun sp => PlannedMCCmd.openSlot sp.2)) ++
                  ((accMetas ++ ([] : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s)).map Prod.fst).map
                    (fun m => PlannedMCCmd.payWork m.slotId uBud)) ++
                  [PlannedMCCmd.finishUpdate])) }
            tbl bs accWork peakSp) = endWithEmpty out₀ := by
      funext bs
      have hpay_map :
          (accMetas ++ ([] : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s)).map Prod.fst).map
            (fun m => (PlannedMCCmd.payWork m.slotId uBud : PlannedMCCmd ι d_s)) =
          pids.map (fun sid => (PlannedMCCmd.payWork sid uBud : PlannedMCCmd ι d_s)) := by
        dsimp only [pids, nextMetas, uBud]
        rw [List.map_map]
        rfl
      change UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
        extHist (.insert id₀) (0 + nextMetas.length + 1 + fuel)
        { metas := nextMetas,
          queue := some (([] : List (PlannedMCCmd ι d_s)) ++
            ((accMetas ++ ([] : List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s)).map Prod.fst).map
              (fun m => (PlannedMCCmd.payWork m.slotId uBud : PlannedMCCmd ι d_s))) ++
            [PlannedMCCmd.finishUpdate]) }
        tbl bs accWork peakSp = endWithEmpty out₀ bs
      rw [hpay_map]
      simp only [List.nil_append]
      rw [hfuel_eq]
      cases bs with
      | nil =>
        rw [hrun_nil]
        exact runFinishUpdate_eq extHist (.insert id₀) trivial nextMetas fuel tbl_fin []
          (accWork + paidWork) peakSp hv_fin hsp_fin
      | cons b bs' =>
        rcases runPayQueue_exists extHist (.insert id₀) nextMetas uBud pids [PlannedMCCmd.finishUpdate]
            (fuel + 1) tbl (b :: bs') accWork peakSp hv hnodup hsp_le hpids_mem with
          ⟨pw_b, sls_b, _, hrel_b, hrun_b⟩
        rw [hrun_b]
        have hv_b : ValidMCTable n h mkMC { tbl with slots := sls_b } :=
          forall₂_paySlotRel_valid hv hrel_b
        have hsp_b : ({ tbl with slots := sls_b } : UL.HostedMCTable ι d_s B I).currentSpace ≤ peakSp := by
          have heq : ({ tbl with slots := sls_b } : UL.HostedMCTable ι d_s B I).currentSpace = tbl.currentSpace := by
            unfold UL.HostedMCTable.currentSpace
            change tbl.activeLifetimes.card + (sls_b.map UL.HostedMCSlot.spaceAlloc).sum = _
            rw [forall₂_paySlotRel_map_spaceAlloc hrel_b]
          rwa [heq]
        rw [runFinishUpdate_eq extHist (.insert id₀) trivial nextMetas fuel
          { tbl with slots := sls_b } (b :: bs') (accWork + pw_b) peakSp hv_b hsp_b]
        rfl
    refine ⟨?_, ?_, ?_⟩
    · dsimp only []
      rw [hfun_eq]
      exact haltProb_endWithEmpty out₀
    · intro bs out hout
      have hout' : endWithEmpty out₀ bs = some out := by
        rw [← hfun_eq]
        exact hout
      rcases (endWithEmpty_eq_some_iff.mp hout') with ⟨_, rfl⟩
      have hmap_fin : slots'.map UL.HostedMCSlot.slotId = tbl.slots.map UL.HostedMCSlot.slotId :=
        forall₂_paySlotRel_map_slotId hrel_pay
      refine ⟨rfl, rfl, rfl, rfl, ?_, ?_, ?_, ?_, hpeak_real⟩
      · change (slots'.map UL.HostedMCSlot.slotId).Nodup
        rwa [hmap_fin]
      · intro sl' hsl'
        have hsid_in : sl'.slotId ∈ slots'.map UL.HostedMCSlot.slotId := List.mem_map_of_mem hsl'
        rw [hmap_fin] at hsid_in
        rcases List.mem_map.mp hsid_in with ⟨sl, hsl, hid_eq⟩
        rw [← hid_eq]
        exact hsid_lt sl hsl
      · simp only [List.map_nil, List.append_nil]
        exact forall₂_slotInv_after_payAll hrel_acc hrel_pay (fun m hm => by
          dsimp only [pids, nextMetas]; simp only [List.map_nil, List.append_nil]
          exact List.mem_map_of_mem hm)
      · dsimp only [out₀, pids, nextMetas, uBud] at hpaid_le ⊢
        simp only [List.length_nil, List.map_nil, List.append_nil, List.length_map] at hpaid_le ⊢
        omega
    · intro hgood
      rw [hfun_eq, expWithBits_endWithEmpty]
      have hgood_fin : AllSlotsGood mkMC tbl_fin := forall₂_paySlotRel_allGood hgood hrel_pay
      classical
      simp [out₀, hgood_fin]
  | cons sp specs ih =>
    intro accMetas fuel tbl accWork peakSp
    dsimp only []
    intro hact_le hlen_K hrel_acc hnodup hsid_lt hsids_eq hsp_inv hsp_le hpeak_real
    rcases sp with ⟨m, gen⟩
    let nextMetas := accMetas ++ (m :: specs.map Prod.fst)
    let accMetas' := accMetas ++ [m]
    have hnext_assoc : accMetas' ++ specs.map Prod.fst = nextMetas := by
      simp [accMetas', nextMetas]
    let uBud := unitBuildBudget n θ facs
    let payCmds : List (PlannedMCCmd ι d_s) :=
      nextMetas.map (fun m' => PlannedMCCmd.payWork m'.slotId uBud)
    let remCmds : List (PlannedMCCmd ι d_s) :=
      (specs.map (fun sp' => PlannedMCCmd.openSlot sp'.2)) ++ payCmds ++ [PlannedMCCmd.finishUpdate]
    have hsp_hd : OpenSpecEntryInv n pts h tbl.activeLifetimes tbl.nextLifetime (m, gen) :=
      hsp_inv (m, gen) (by simp)
    rcases hsp_hd with ⟨hj_eq, hP0_eq, hm_pos, hm_pow, hm_le_n, hh_eq, hpts_eq⟩
    rcases hMC gen hm_le_n hh_eq with ⟨hgen_eq, hunif_all⟩
    have hunif := hunif_all extHist
    rcases hunif.2.2.1 with ⟨_, _, hpf_build_raw, hhalt_build, hb_caps, _, _, _⟩
    have hpf_build : IsPrefixFree ((mkMC gen).buildWithBits extHist) := hpf_build_raw
    have hv_tbl : ValidMCTable n h mkMC tbl := validMCTable_of_forall₂ hrel_acc
    have hguard : gen.m ≤ n ∧ gen.h = h ∧ gen.P₀ ⊆ tbl.activeLifetimes ∧
        (∀ p ∈ gen.P₀, gen.pts p = pts p.1) := by
      refine ⟨hm_le_n, hh_eq, ?_, hpts_eq⟩
      rw [hP0_eq]
      exact Finset.filter_subset _ _
    have hm_sid : m.slotId = tbl.nextSlotId := by
      have h1 := congrArg List.head? hsids_eq
      simp only [List.map_cons, List.length_cons, List.range_succ_eq_map, List.head?_cons] at h1
      have h2 := Option.some.inj h1
      omega
    have hsids_tl : specs.map (fun sp' => sp'.1.slotId) =
        (List.range specs.length).map (tbl.nextSlotId + 1 + ·) := by
      have h1 := congrArg List.tail hsids_eq
      simp only [List.map_cons, List.length_cons, List.range_succ_eq_map, List.tail_cons,
        List.map_map] at h1
      rw [h1]
      apply List.map_congr_left
      intro i _
      dsimp only [Function.comp]
      omega
    let mkNewSlot := fun (bOut : UL.MCBirthOutcome B I) =>
      ({ slotId := tbl.nextSlotId
         gen := gen
         bState := bOut.birthState
         surviving := gen.P₀
         idxState := bOut.initState
         unpaidWork := bOut.work + gen.m
         spaceAlloc := gen.m + bOut.peakSpace } : UL.HostedMCSlot ι d_s B I)
    let mkTbl' := fun (bOut : UL.MCBirthOutcome B I) =>
      ({ tbl with
         nextSlotId := tbl.nextSlotId + 1
         slots := tbl.slots ++ [mkNewSlot bOut] } : UL.HostedMCTable ι d_s B I)
    let g := fun (bOut : UL.MCBirthOutcome B I) (rem' : List Bool) =>
      UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
        extHist (.insert id₀) (specs.length + (accMetas' ++ specs.map Prod.fst).length + 1 + fuel)
        { metas := accMetas' ++ specs.map Prod.fst, queue := some
            ((specs.map (fun sp' => PlannedMCCmd.openSlot sp'.2)) ++
             ((accMetas' ++ specs.map Prod.fst).map (fun m' => PlannedMCCmd.payWork m'.slotId uBud)) ++
             [PlannedMCCmd.finishUpdate]) }
        (mkTbl' bOut) rem' (accWork + 1) (max peakSp (mkTbl' bOut).currentSpace)
    have hf_eq :
        (fun bs =>
          UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
            extHist (.insert id₀) (((m, gen) :: specs).length + nextMetas.length + 1 + fuel)
            { metas := nextMetas, queue := some
                ((((m, gen) :: specs).map (fun sp' => PlannedMCCmd.openSlot sp'.2)) ++
                 payCmds ++ [PlannedMCCmd.finishUpdate]) }
            tbl bs accWork peakSp) =
        seqConsume ((mkMC gen).buildWithBits extHist) g := by
      funext bs
      have hfuel1 : ((m, gen) :: specs).length + nextMetas.length + 1 + fuel =
          (specs.length + (accMetas' ++ specs.map Prod.fst).length + 1 + fuel) + 1 := by
        rw [hnext_assoc]; simp; omega
      rw [hfuel1]
      conv_lhs => unfold UL.runMCHostedStepFuel
      have hcmd : mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC (.insert id₀)
          { metas := nextMetas, queue := some
              ((((m, gen) :: specs).map (fun sp' => PlannedMCCmd.openSlot sp'.2)) ++
               payCmds ++ [PlannedMCCmd.finishUpdate]) } tbl =
          .openSlot gen { metas := nextMetas, queue := some remCmds } := by
        unfold mcStepCtrl
        simp [hv_tbl, dispatchMCQueue, remCmds]
      rw [hcmd]
      dsimp only []
      rw [if_pos hguard]
      unfold seqConsume
      cases UL.consumePrefixBits ((mkMC gen).buildWithBits extHist) bs with
      | none => rfl
      | some pair =>
        rcases pair with ⟨bOut, rem'⟩
        dsimp only [g, remCmds, payCmds]
        rw [hnext_assoc]
    -- Apply IH for every valid `bOut`
    have h_ih : ∀ bs₁ bOut, (mkMC gen).buildWithBits extHist bs₁ = some bOut →
        let tbl' := mkTbl' bOut
        (MCSlotInv n pts h σ θ facs mkMC tbl.activeLifetimes tbl.nextLifetime m (mkNewSlot bOut)) ∧
        (haltProb (g bOut) = 1 ∧
        (∀ bs₂ out, g bOut bs₂ = some out →
          out.queryAnswer = none ∧
          out.nextState.1 = { metas := accMetas' ++ specs.map Prod.fst, queue := none } ∧
          out.nextState.2.activeLifetimes = tbl'.activeLifetimes ∧
          out.nextState.2.nextLifetime = tbl'.nextLifetime ∧
          (out.nextState.2.slots.map UL.HostedMCSlot.slotId).Nodup ∧
          (∀ sl ∈ out.nextState.2.slots, sl.slotId < out.nextState.2.nextSlotId) ∧
          List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl'.activeLifetimes (tbl'.nextLifetime + 1))
            (accMetas' ++ specs.map Prod.fst) out.nextState.2.slots ∧
          out.work ≤ (accWork + 1) + specs.length + (accMetas' ++ specs.map Prod.fst).length * (uBud + 1) + 1 ∧
          (out.peakSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ) ∧
        (AllSlotsGood mkMC tbl' →
          ENNReal.ofReal (1 - (specs.length : ℝ) * δ_fail) ≤
            expWithBits (g bOut) (fun out =>
              open Classical in if AllSlotsGood mkMC out.nextState.2 then 1 else 0))) := by
      intro bs₁ bOut hb
      rcases hb_caps bs₁ bOut hb with ⟨hb_val_raw, hb_work_raw, hb_sp_raw⟩
      have hb_val : (mkMC gen).IsValidState extHist bOut.birthState gen.P₀ bOut.initState := by
        rwa [hgen_eq] at hb_val_raw
      have hb_work : (bOut.work : ℝ) ≤ facs.buildWorkBound gen.m n θ := by
        rwa [hgen_eq] at hb_work_raw
      have hb_sp : (bOut.peakSpace : ℝ) ≤ facs.spaceBound gen.m σ := by
        rwa [hgen_eq] at hb_sp_raw
      have hnew_sp : ((mkNewSlot bOut).spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := by
        dsimp only [mkNewSlot]
        push_cast
        have hsp_m : facs.spaceBound gen.m σ ≤ facs.spaceBound n σ :=
          spaceBound_mono_le hm_le_n hσθ.2.1 hfacs
        have hn_le_sp : (n : ℝ) ≤ facs.spaceBound n σ := by
          unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
          have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by have := hσθ.1; omega : 1 ≤ n)
          have hrp : (n : ℝ) ^ (1 : ℝ) ≤ (n : ℝ) ^ (1 + σ) :=
            Real.rpow_le_rpow_of_exponent_le hn1 (by have := hσθ.2.1; linarith)
          rw [Real.rpow_one] at hrp
          have hPs : 1 ≤ facs.P_space := hfacs.2.1
          nlinarith
        have hm_real : (gen.m : ℝ) ≤ (n : ℝ) := by exact_mod_cast hm_le_n
        linarith
      have hnew_unpaid : (mkNewSlot bOut).unpaidWork ≤
          ((m.j + 2) * 2 ^ m.k - tbl.nextLifetime) * uBud := by
        have hj_eq' : (m.j + 1) * 2 ^ m.k = tbl.nextLifetime := hj_eq
        have hsub_eq : (m.j + 2) * 2 ^ m.k - tbl.nextLifetime = 2 ^ m.k := by
          have h1 : (m.j + 2) * 2 ^ m.k = (m.j + 1) * 2 ^ m.k + 2 ^ m.k := by ring
          rw [h1, hj_eq']
          exact Nat.add_sub_cancel_left tbl.nextLifetime (2 ^ m.k)
        rw [hsub_eq]
        exact build_unpaidWork_le hm_pow hb_work
      have hslot_new : MCSlotInv n pts h σ θ facs mkMC tbl.activeLifetimes tbl.nextLifetime
          m (mkNewSlot bOut) :=
        ⟨hm_sid, hm_pos, hm_le_n, hh_eq, hpts_eq, hP0_eq, subset_rfl, ⟨extHist, hb_val⟩,
          hnew_unpaid, hnew_sp⟩
      let tbl' := mkTbl' bOut
      have hrel' : List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl'.activeLifetimes tbl'.nextLifetime)
          accMetas' tbl'.slots := forall₂_append_one hrel_acc hslot_new
      have hnodup' : (tbl'.slots.map UL.HostedMCSlot.slotId).Nodup := by
        change ((tbl.slots ++ [mkNewSlot bOut]).map UL.HostedMCSlot.slotId).Nodup
        rw [List.map_append, List.nodup_append]
        refine ⟨hnodup, List.nodup_singleton _, ?_⟩
        intro x hx y hy
        simp only [List.mem_map, List.mem_singleton] at hx hy
        rcases hx with ⟨sl, hsl, rfl⟩
        rcases hy with ⟨sl2, rfl, rfl⟩
        have hlt := hsid_lt sl hsl
        dsimp only [mkNewSlot]
        omega
      have hsid_lt' : ∀ sl ∈ tbl'.slots, sl.slotId < tbl'.nextSlotId := by
        intro sl hsl
        rcases List.mem_append.mp hsl with hsl0 | hsl1
        · have := hsid_lt sl hsl0
          dsimp only [tbl', mkTbl']
          omega
        · simp only [List.mem_singleton] at hsl1
          subst hsl1
          dsimp only [tbl', mkTbl', mkNewSlot]
          omega
      have hlen_K' : (accMetas' ++ specs.map Prod.fst).length ≤ K := by
        rwa [hnext_assoc]
      have htbl'_sp : (tbl'.currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ := by
        refine currentSpace_le_of_slot_bounds hσθ.1 hσθ.2.1 hfacs hact_le ?_ ?_
        · have hlen_eq : tbl'.slots.length = accMetas'.length := hrel'.length_eq.symm
          have hsub_len : accMetas'.length ≤ (accMetas' ++ specs.map Prod.fst).length := by simp
          omega
        · intro sl hsl
          have haux : ∀ ms sls,
              List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl'.activeLifetimes tbl'.nextLifetime) ms sls →
              ∀ s ∈ sls, (s.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := by
            intro ms sls hr
            induction hr with
            | nil => intro _ h; simp at h
            | cons hh _ ihr =>
              intro s hs
              rcases List.mem_cons.mp hs with rfl | htl
              · exact hh.2.2.2.2.2.2.2.2.2
              · exact ihr s htl
          exact haux accMetas' tbl'.slots hrel' sl hsl
      have hpeak' : ((max peakSp tbl'.currentSpace : ℕ) : ℝ) ≤
          (1 + 2 * (K : ℝ)) * facs.spaceBound n σ := by
        rw [Nat.cast_max]
        exact max_le hpeak_real htbl'_sp
      refine ⟨hslot_new, ih accMetas' fuel tbl' (accWork + 1) (max peakSp tbl'.currentSpace)
        hact_le hlen_K' hrel' hnodup' hsid_lt' hsids_tl
        (fun sp' hsp' => hsp_inv sp' (by simp [hsp'])) (Nat.le_max_right _ _) hpeak'⟩
    refine ⟨?_, ?_, ?_⟩
    · refine (congrArg haltProb hf_eq).trans ?_
      exact haltProb_seqConsume hpf_build hhalt_build (fun bs₁ bOut hb => (h_ih bs₁ bOut hb).2.1)
    · intro bs out hout
      have hout' : seqConsume ((mkMC gen).buildWithBits extHist) g bs = some out := by
        rw [← hf_eq]
        exact hout
      rcases (seqConsume_eq_some_iff hpf_build).mp hout' with ⟨bs₁, bs₂, bOut, rfl, hb, hg_out⟩
      rcases (h_ih bs₁ bOut hb).2.2.1 bs₂ out hg_out with
        ⟨hqans, hst1, hact_eq, hlife_eq, hnod_out, hsid_out, hrel_out, hw_out, hsp_out⟩
      dsimp only [nextMetas, uBud] at hnext_assoc hw_out ⊢
      simp only [List.map_cons] at hst1 hrel_out hw_out ⊢
      rw [hnext_assoc] at hst1 hrel_out hw_out
      refine ⟨hqans, hst1, hact_eq, hlife_eq, hnod_out, hsid_out, hrel_out, ?_, hsp_out⟩
      simp only [List.length_cons] at hw_out ⊢
      omega
    · intro hgood_tbl
      classical
      have hexp_eq :
          expWithBits
            (fun bs =>
              UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
                extHist (.insert id₀) (((m, gen) :: specs).length + nextMetas.length + 1 + fuel)
                { metas := nextMetas, queue := some
                    ((((m, gen) :: specs).map (fun sp' => PlannedMCCmd.openSlot sp'.2)) ++
                     payCmds ++ [PlannedMCCmd.finishUpdate]) }
                tbl bs accWork peakSp)
            (fun out => if AllSlotsGood mkMC out.nextState.2 then 1 else 0) =
          expWithBits (seqConsume ((mkMC gen).buildWithBits extHist) g)
            (fun out => if AllSlotsGood mkMC out.nextState.2 then 1 else 0) :=
        congrArg (fun f => expWithBits f (fun out => if AllSlotsGood mkMC out.nextState.2 then 1 else 0)) hf_eq
      refine le_trans ?_ (le_of_eq hexp_eq.symm)
      let P : UL.MCBirthOutcome B I → Prop :=
        fun bOut => (mkMC gen).IsBirthSuccess extHist bOut.birthState
      have hC_nn : 0 ≤ (specs.length : ℝ) * δ_fail := mul_nonneg (Nat.cast_nonneg _) hδ0
      have hP_prob : ENNReal.ofReal (1 - δ_fail) ≤
          expWithBits ((mkMC gen).buildWithBits extHist) (fun bOut => if P bOut then 1 else 0) := by
        rw [birthSuccessProb_eq_expWithBits]
        exact hunif.2.2.2
      have hstep_prob := expWithBits_seqConsume_ge_of_event (g := g) hpf_build P
        (fun out => if AllSlotsGood mkMC out.nextState.2 then 1 else 0)
        hδ0 hC_nn hP_prob (fun bs₁ bOut hb hP_ok => by
          rcases hb_caps bs₁ bOut hb with ⟨hb_val_raw, _, _⟩
          have hb_val : (mkMC gen).IsValidState extHist bOut.birthState gen.P₀ bOut.initState := by
            rwa [hgen_eq] at hb_val_raw
          have hgood_new : GoodMCSlot mkMC (mkNewSlot bOut) := ⟨extHist, hP_ok, hb_val⟩
          have hgood' : AllSlotsGood mkMC (mkTbl' bOut) := by
            intro sl hsl
            rcases List.mem_append.mp hsl with hsl0 | hsl1
            · exact hgood_tbl sl hsl0
            · simp only [List.mem_singleton] at hsl1
              subst hsl1
              exact hgood_new
          exact (h_ih bs₁ bOut hb).2.2.2 hgood')
      have hlen_mul : (((m, gen) :: specs).length : ℝ) * δ_fail = δ_fail + (specs.length : ℝ) * δ_fail := by
        simp only [List.length_cons, Nat.cast_add, Nat.cast_one]
        ring
      rw [hlen_mul]
      exact hstep_prob

/-! ### 4. Complete Single-Step Specification for `.insert` -/

theorem mcStep_insert_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hδ0 : 0 ≤ δ_fail)
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    (extHist : UL.ExecutionHistory d)
    {S : Finset ι} {ctrl : MCCtrlState ι d_s} {tbl0 : UL.HostedMCTable ι d_s B I}
    (hinv : MCTableInv n pts h σ θ facs mkMC S ctrl tbl0)
    (hH_lt : tbl0.nextLifetime < maxOps)
    {id₀ : ι}
    (hleg : UL.IsLegalDynamicSearchOp n pts (fun _ _ => True) S (.insert id₀)) :
    let dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
    let L := Nat.log 2 maxOps + 1
    let stepFn := UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀)
    UL.singleDynamicSearchStepHaltProb dynIdx extHist S (ctrl, tbl0) (.insert id₀) = 1 ∧
    (∀ bs S' out, stepFn bs = some (S', out) →
      S' = insert id₀ S ∧
      out.queryAnswer = none ∧
      out.nextState.2.nextLifetime = tbl0.nextLifetime + 1 ∧
      MCTableInv n pts h σ θ facs mkMC S' out.nextState.1 out.nextState.2 ∧
      (out.work : ℝ) ≤
        50 * (L : ℝ) * (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) ∧
      (out.peakSpace : ℝ) ≤ 7 * (L : ℝ) * facs.spaceBound n σ) ∧
    (AllSlotsGood mkMC tbl0 →
      ENNReal.ofReal (1 - ((openLevels (tbl0.nextLifetime + 1)).length : ℝ) * δ_fail) ≤
        expWithBits stepFn (fun res =>
          open Classical in if AllSlotsGood mkMC res.2.nextState.2 then 1 else 0)) := by
  dsimp only []
  let dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
  let H := tbl0.nextLifetime
  let H1 := H + 1
  let L := Nat.log 2 maxOps + 1
  let K := 3 * L
  have hH1_le : H1 ≤ maxOps := hH_lt
  have hL_ge : Nat.log 2 H1 + 1 ≤ L := Nat.add_le_add_right (Nat.log_mono_right hH1_le) 1
  have hL_ge0 : Nat.log 2 H + 1 ≤ L :=
    Nat.add_le_add_right (Nat.log_mono_right (by omega : H ≤ maxOps)) 1
  rcases hleg with ⟨hid_not_mem, hcard_ins, hunit_id⟩
  have hnmem_pair : (id₀, H) ∉ tbl0.activeLifetimes := by
    intro hm
    apply hid_not_mem
    rw [← hinv.img_eq]
    exact Finset.mem_image.mpr ⟨(id₀, H), hm, rfl⟩
  let tbl1 : UL.HostedMCTable ι d_s B I :=
    { tbl0 with
      activeLifetimes := insert (id₀, H) tbl0.activeLifetimes
      nextLifetime := H1 }
  have hA1_img : tbl1.activeLifetimes.image Prod.fst = insert id₀ S := by
    change (insert (id₀, H) tbl0.activeLifetimes).image Prod.fst = insert id₀ S
    rw [Finset.image_insert, hinv.img_eq]
  have hA1_card_eq : tbl1.activeLifetimes.card = (insert id₀ S).card := by
    change (insert (id₀, H) tbl0.activeLifetimes).card = (insert id₀ S).card
    rw [Finset.card_insert_of_notMem hnmem_pair, Finset.card_insert_of_notMem hid_not_mem,
      hinv.card_eq]
  have hA1_card_le : tbl1.activeLifetimes.card ≤ n := hA1_card_eq.trans_le hcard_ins
  have hA1_life : ∀ r ∈ tbl1.activeLifetimes, r.2 < H1 ∧ UL.IsUnitVec (pts r.1) := by
    intro r hr
    rcases Finset.mem_insert.mp hr with rfl | hr0
    · exact ⟨by omega, hunit_id⟩
    · rcases hinv.life_valid r hr0 with ⟨hlt, hu⟩
      exact ⟨by omega, hu⟩
  have hA1_inj : ∀ r₁ ∈ tbl1.activeLifetimes, ∀ r₂ ∈ tbl1.activeLifetimes, r₁.2 = r₂.2 → r₁ = r₂ := by
    intro r₁ hr₁ r₂ hr₂ heq
    rcases Finset.mem_insert.mp hr₁ with rfl | hr₁₀ <;> rcases Finset.mem_insert.mp hr₂ with rfl | hr₂₀
    · rfl
    · exfalso; have := (hinv.life_valid r₂ hr₂₀).1; dsimp at heq; omega
    · exfalso; have := (hinv.life_valid r₁ hr₁₀).1; dsimp at heq; omega
    · exact hinv.inj_snd r₁ hr₁₀ r₂ hr₂₀ heq
  -- `buildOpenSpecs` succeeds on `openLevels H1`
  have hdiv_ks : ∀ k ∈ openLevels H1, 2 ^ k ∣ H1 := fun k hk =>
    (mem_openLevels_iff (by omega) k).mp hk
  rcases buildOpenSpecs_spec (n := n) (h := h) (h_pos := h_pos) (h_lt_one := h_lt_one)
      (Finset.mem_insert_self (id₀, H) tbl0.activeLifetimes) hA1_card_le
      (fun p hp => (hA1_life p hp).2) hA1_inj (openLevels H1) tbl1.nextSlotId hdiv_ks with
    ⟨openSpecs, hbuild_eq, hks_eq, hsids_open_eq, hopen_inv⟩
  let toRetire := open Classical in ctrl.metas.filter (fun m => !decide (LiveMC H1 m.k m.j))
  let keptMetas := open Classical in ctrl.metas.filter (fun m => decide (LiveMC H1 m.k m.j))
  let nextMetas := keptMetas ++ openSpecs.map Prod.fst
  let uBud := unitBuildBudget n θ facs
  let rids := toRetire.map MCSlotMeta.slotId
  let cmds :=
    (rids.map PlannedMCCmd.retireSlot) ++
    (openSpecs.map (fun sp => PlannedMCCmd.openSlot sp.2)) ++
    (nextMetas.map (fun m => PlannedMCCmd.payWork m.slotId uBud)) ++
    [PlannedMCCmd.finishUpdate]
  have hplan : planMCStep n pts h h_pos h_lt_one θ facs (.insert id₀) ctrl.metas tbl1 =
      (nextMetas, cmds) := by
    unfold planMCStep
    classical
    dsimp only []
    change (match buildOpenSpecs pts h h_pos h_lt_one tbl1.activeLifetimes H1 tbl1.nextSlotId
        (openLevels H1) with | none => _ | some _ => _) = _
    rw [hbuild_eq]
    simp only [List.map_map, rids, toRetire, keptMetas, nextMetas, uBud, cmds]
    rfl
  -- Check `nextMetas` `(k, j)` properties and length `≤ K = 3 * L`
  have hnext_kj_nodup : (nextMetas.map (fun m => (m.k, m.j))).Nodup := by
    dsimp only [nextMetas]
    rw [List.map_append, List.nodup_append]
    refine ⟨?_, ?_, ?_⟩
    · have hsub : (keptMetas.map (fun m => (m.k, m.j))).Sublist
          (ctrl.metas.map (fun m => (m.k, m.j))) := List.filter_sublist.map _
      exact hinv.kj_nodup.sublist hsub
    · have hmap_k : ((openSpecs.map Prod.fst).map (Prod.fst ∘ fun m : MCSlotMeta => (m.k, m.j))).Nodup := by
        have heq : (openSpecs.map Prod.fst).map (Prod.fst ∘ fun m : MCSlotMeta => (m.k, m.j)) = openLevels H1 := by
          rw [List.map_map]
          exact hks_eq
        rw [heq]
        exact nodup_openLevels H1
      exact nodup_of_map_comp (fun m : MCSlotMeta => (m.k, m.j)) Prod.fst hmap_k
    · intro p₁ hp₁ p₂ hp₂ heq
      rcases List.mem_map.mp hp₁ with ⟨m₁, hm₁, rfl⟩
      rcases List.mem_map.mp hp₂ with ⟨m₂, hm₂, hp₂_eq⟩
      rcases List.mem_map.mp hm₂ with ⟨sp, hsp, rfl⟩
      have hm₁_mem : m₁ ∈ ctrl.metas := List.mem_of_mem_filter hm₁
      have hlive0 : LiveMC H m₁.k m₁.j :=
        (hinv.kj_live m₁.k m₁.j).mp (List.mem_map_of_mem hm₁_mem)
      have hnot_live0 : ¬ LiveMC H sp.1.k sp.1.j :=
        (newSlot_liveMC (hopen_inv sp hsp).1).2
      have hpair_eq : (m₁.k, m₁.j) = (sp.1.k, sp.1.j) := heq.trans hp₂_eq.symm
      rcases Prod.mk.inj hpair_eq with ⟨hk_e, hj_e⟩
      rw [← hk_e, ← hj_e] at hnot_live0
      exact hnot_live0 hlive0
  have hnext_kj_live : ∀ k j, (k, j) ∈ nextMetas.map (fun m => (m.k, m.j)) ↔ LiveMC H1 k j := by
    intro k j
    dsimp only [nextMetas]
    rw [List.map_append, List.mem_append]
    constructor
    · rintro (hkept | hopen)
      · rcases List.mem_map.mp hkept with ⟨m, hm, hpair⟩
        rcases Prod.mk.inj hpair with ⟨rfl, rfl⟩
        classical
        have hd := (List.mem_filter.mp hm).2
        simpa using hd
      · rcases List.mem_map.mp hopen with ⟨m, hm, hpair⟩
        rcases List.mem_map.mp hm with ⟨sp, hsp, rfl⟩
        rcases Prod.mk.inj hpair with ⟨rfl, rfl⟩
        exact (newSlot_liveMC (hopen_inv sp hsp).1).1
    · intro hlive1
      rcases (liveMC_succ_iff H k j).mp hlive1 with ⟨hlive0, _⟩ | hnew_eq
      · left
        have hmem0 := (hinv.kj_live k j).mpr hlive0
        rcases List.mem_map.mp hmem0 with ⟨m, hm, hpair⟩
        rcases Prod.mk.inj hpair with ⟨rfl, rfl⟩
        refine List.mem_map_of_mem ?_
        classical
        rw [List.mem_filter]
        exact ⟨hm, by simpa using hlive1⟩
      · right
        have hdiv_k : 2 ^ k ∣ H1 := ⟨j + 1, by dsimp [H1]; linarith⟩
        have hk_mem : k ∈ openSpecs.map (fun sp => sp.1.k) := by
          rw [hks_eq, mem_openLevels_iff (by omega)]
          exact hdiv_k
        rcases List.mem_map.mp hk_mem with ⟨sp, hsp, rfl⟩
        have hjeq1 := (hopen_inv sp hsp).1
        have hpow_pos : 0 < 2 ^ sp.1.k := Nat.two_pow_pos _
        have hmul_eq : (sp.1.j + 1) * 2 ^ sp.1.k = (j + 1) * 2 ^ sp.1.k := hjeq1.trans hnew_eq.symm
        have hj_same : sp.1.j = j := by
          have := Nat.eq_of_mul_eq_mul_right hpow_pos hmul_eq
          omega
        refine List.mem_map.mpr ⟨sp.1, List.mem_map_of_mem hsp, ?_⟩
        rw [hj_same]
  have hnext_len : nextMetas.length ≤ K := by
    have hle1 := metas_length_le_of_live hnext_kj_nodup (fun k j hm => (hnext_kj_live k j).mp hm)
    dsimp only [K]
    exact hle1.trans (Nat.mul_le_mul_left 3 hL_ge)
  -- Fuel bound check
  have hold_len : ctrl.metas.length ≤ K := by
    have hle0 := metas_length_le_of_live hinv.kj_nodup (fun k j hm => (hinv.kj_live k j).mp hm)
    dsimp only [K]
    exact hle0.trans (Nat.mul_le_mul_left 3 hL_ge0)
  have hret_len : rids.length ≤ 3 * L := by
    dsimp only [rids]
    rw [List.length_map]
    exact (List.length_filter_le _ _).trans hold_len
  have hopen_len : openSpecs.length ≤ L := by
    have h1 : openSpecs.length = (openLevels H1).length := by
      have := congrArg List.length hks_eq
      simpa using this
    rw [h1]
    exact (openLevels_length_le_log_succ (by omega)).trans hL_ge
  have hfuel_total : rids.length + (openSpecs.length + nextMetas.length + 1) ≤ mcFuelBound H1 := by
    unfold mcFuelBound
    have h1 : rids.length ≤ 3 * L := hret_len
    have h2 : openSpecs.length ≤ L := hopen_len
    have h3 : nextMetas.length ≤ 3 * L := hnext_len
    -- Wait: `mcFuelBound H1 = 10 * (Nat.log 2 H1 + 1) + 5`!
    -- Wait: `rids.length ≤ 3 * (Nat.log 2 H + 1) ≤ 3 * (Nat.log 2 H1 + 1)`!
    have hret_H1 : rids.length ≤ 3 * (Nat.log 2 H1 + 1) := by
      dsimp only [rids]
      rw [List.length_map]
      have hle0 := metas_length_le_of_live hinv.kj_nodup (fun k j hm => (hinv.kj_live k j).mp hm)
      have hlog_mono : Nat.log 2 H + 1 ≤ Nat.log 2 H1 + 1 :=
        Nat.add_le_add_right (Nat.log_mono_right (by omega : H ≤ H1)) 1
      exact (List.length_filter_le _ _).trans (hle0.trans (Nat.mul_le_mul_left 3 hlog_mono))
    have hopen_H1 : openSpecs.length ≤ Nat.log 2 H1 + 1 := by
      have h1' : openSpecs.length = (openLevels H1).length := by
        have := congrArg List.length hks_eq; simpa using this
      rw [h1']
      exact openLevels_length_le_log_succ (by omega)
    have hnext_H1 : nextMetas.length ≤ 3 * (Nat.log 2 H1 + 1) :=
      metas_length_le_of_live hnext_kj_nodup (fun k j hm => (hnext_kj_live k j).mp hm)
    omega
  let fuel_rem := mcFuelBound H1 - (rids.length + (openSpecs.length + nextMetas.length + 1))
  have hfuel_split : mcFuelBound H1 =
      rids.length + (openSpecs.length + nextMetas.length + 1 + fuel_rem) := by omega
  -- Initial space bounds on `tbl0` and `tbl1`
  have halloc0 : ∀ sl ∈ tbl0.slots, (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := by
    have haux : ∀ ms sls,
        List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl0.activeLifetimes H1) ms sls →
        ∀ s ∈ sls, (s.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := by
      intro ms sls hr
      induction hr with
      | nil => intro _ h; simp at h
      | cons hh _ ihr =>
        intro s hs
        rcases List.mem_cons.mp hs with rfl | htl
        · exact hh.2.2.2.2.2.2.2.2.2
        · exact ihr s htl
    exact haux ctrl.metas tbl0.slots hinv.slots_rel
  have hslots0_len : tbl0.slots.length ≤ K := by
    rw [← hinv.slots_rel.length_eq]
    exact hold_len
  have hsp0_bound : (tbl0.currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ :=
    currentSpace_le_of_slot_bounds hσθ.1 hσθ.2.1 hfacs
      (hinv.card_eq.trans_le hinv.card_le_n) hslots0_len halloc0
  have hsp1_bound : (tbl1.currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ :=
    currentSpace_le_of_slot_bounds hσθ.1 hσθ.2.1 hfacs hA1_card_le hslots0_len halloc0
  let peak0 := max tbl0.currentSpace tbl1.currentSpace
  have hpeak0_real : (peak0 : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ := by
    dsimp only [peak0]
    rw [Nat.cast_max]
    exact max_le hsp0_bound hsp1_bound
  -- After retirement: `tbl_ret := { tbl1 with slots := applyRetireIds rids tbl1.slots }`
  let tbl_ret : UL.HostedMCTable ι d_s B I :=
    { tbl1 with slots := applyRetireIds rids tbl1.slots }
  have hv1 : ValidMCTable n h mkMC tbl1 := validMCTable_of_forall₂ hinv.slots_rel
  -- Lift `MCSlotInv` on `tbl0.slots` from `tbl0.activeLifetimes` to `tbl1.activeLifetimes`
  have hrel_tbl1 : List.Forall₂
      (MCSlotInv n pts h σ θ facs mkMC tbl1.activeLifetimes H1) ctrl.metas tbl1.slots := by
    have hlive_all := hinv.kj_live
    have hrel0 := hinv.slots_rel
    have haux : ∀ ms sls,
        (∀ m ∈ ms, LiveMC H m.k m.j) →
        List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl0.activeLifetimes H1) ms sls →
        List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl1.activeLifetimes H1) ms sls := by
      intro ms sls hml hr
      induction hr with
      | nil => exact List.Forall₂.nil
      | @cons m sl ms' sls' hh _ ihr =>
        refine List.Forall₂.cons ?_ (ihr (fun m' hm' => hml m' (by simp [hm'])))
        rcases hh with ⟨hid, hm1, hmn, hh_eq, hpts_s, hsurv, hsub, hval, hun, hsp_s⟩
        have hlive_m : LiveMC H m.k m.j := hml m (by simp)
        have hsurv1 : sl.surviving =
            tbl1.activeLifetimes.filter (fun p => m.j * 2 ^ m.k ≤ p.2 ∧ p.2 < (m.j + 1) * 2 ^ m.k) := by
          rw [hsurv]
          dsimp only [tbl1]
          ext p
          simp only [Finset.mem_filter, Finset.mem_insert]
          constructor
          · rintro ⟨hp0, hb⟩
            exact ⟨Or.inr hp0, hb⟩
          · rintro ⟨ rfl | hp0, hb ⟩
            · exfalso
              have := hlive_m.1
              dsimp at hb
              omega
            · exact ⟨hp0, hb⟩
        exact ⟨hid, hm1, hmn, hh_eq, hpts_s, hsurv1, hsub, hval, hun, hsp_s⟩
    exact haux ctrl.metas tbl0.slots
      (fun m hm => (hlive_all m.k m.j).mp (List.mem_map_of_mem hm)) hrel0
  have hms_sid_nodup : (ctrl.metas.map MCSlotMeta.slotId).Nodup := by
    rw [forall₂_map_slotId_eq hinv.slots_rel]
    exact hinv.sid_nodup
  have hrel_ret : List.Forall₂
      (MCSlotInv n pts h σ θ facs mkMC tbl_ret.activeLifetimes tbl_ret.nextLifetime)
      keptMetas tbl_ret.slots := by
    change List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC tbl1.activeLifetimes H1)
      keptMetas (applyRetireIds rids tbl1.slots)
    rw [applyRetireIds_eq_filter]
    refine forall₂_filter_lockstep hrel_tbl1 (fun m sl hm _ hr => ?_)
    classical
    have hid_eq : m.slotId = sl.slotId := hr.1
    rw [← hid_eq]
    apply Bool.eq_iff_iff.mpr
    simp only [decide_eq_true_eq]
    constructor
    · intro hlive1 hmem_rids
      rcases List.mem_map.mp hmem_rids with ⟨m', hm', hm'_id⟩
      have heq_m : m' = m := eq_meta_of_mem_of_slotId_eq hms_sid_nodup
        (List.mem_of_mem_filter hm') hm hm'_id
      subst heq_m
      have hcond := (List.mem_filter.mp hm').2
      simp [hlive1] at hcond
    · intro hnmem
      by_contra hnot
      apply hnmem
      refine List.mem_map_of_mem ?_
      rw [List.mem_filter]
      exact ⟨hm, by simp [hnot]⟩
  have hret_nodup : (tbl_ret.slots.map UL.HostedMCSlot.slotId).Nodup := by
    dsimp only [tbl_ret]
    rw [applyRetireIds_eq_filter]
    have hsub : ((open Classical in tbl1.slots.filter (fun s => decide (s.slotId ∉ rids))).map
        UL.HostedMCSlot.slotId).Sublist (tbl1.slots.map UL.HostedMCSlot.slotId) :=
      List.filter_sublist.map _
    exact hinv.sid_nodup.sublist hsub
  have hret_sid_lt : ∀ sl ∈ tbl_ret.slots, sl.slotId < tbl_ret.nextSlotId := by
    intro sl hsl
    have hsl1 : sl ∈ tbl1.slots := (mem_applyRetireIds_iff rids tbl1.slots sl).mp hsl |>.1
    exact hinv.sid_lt sl hsl1
  have hret_sp_le : tbl_ret.currentSpace ≤ peak0 := by
    have hle1 : tbl_ret.currentSpace ≤ tbl1.currentSpace := by
      dsimp only [tbl_ret]
      rw [applyRetireIds_eq_filter]
      unfold UL.HostedMCTable.currentSpace
      exact Nat.add_le_add_left (list_sum_map_filter_le _ _ tbl1.slots) _
    exact hle1.trans (Nat.le_max_right _ _)
  -- Rewrite `dynIdx.stepWithBits` to `f_open`
  let f_open := fun bs =>
    UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
      extHist (.insert id₀) (openSpecs.length + nextMetas.length + 1 + fuel_rem)
      { metas := nextMetas, queue := some
          ((openSpecs.map (fun sp => PlannedMCCmd.openSlot sp.2)) ++
           (nextMetas.map (fun m => PlannedMCCmd.payWork m.slotId uBud)) ++
           [PlannedMCCmd.finishUpdate]) }
      tbl_ret bs (1 + rids.length) peak0
  have hstep_eq_fopen : ∀ bs,
      dynIdx.stepWithBits extHist S (ctrl, tbl0) (.insert id₀) bs = f_open bs := by
    intro bs
    dsimp only [dynIdx, UL.MCHostedController.toDynamicSearchIndex, mcController]
    rw [if_pos ⟨hinv.img_eq, hinv.card_eq⟩]
    change UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
      extHist (.insert id₀) (mcFuelBound H1) ctrl tbl1 bs 1 peak0 = f_open bs
    have hmc_pos : ∃ f0, mcFuelBound H1 = f0 + 1 := ⟨mcFuelBound H1 - 1, by unfold mcFuelBound; omega⟩
    rcases hmc_pos with ⟨f0, hf0⟩
    rw [hf0, runMCHostedStepFuel_plan_eq extHist (.insert id₀) f0 ctrl tbl1 bs 1 peak0
      hinv.queue_none hv1 hplan, ← hf0, hfuel_split]
    have hcmds_assoc : cmds = (rids.map PlannedMCCmd.retireSlot) ++
        ((openSpecs.map (fun sp => PlannedMCCmd.openSlot sp.2)) ++
         (nextMetas.map (fun m => PlannedMCCmd.payWork m.slotId uBud)) ++
         [PlannedMCCmd.finishUpdate]) := by
      simp [cmds, List.append_assoc]
    rw [hcmds_assoc]
    exact runRetireQueue_eq extHist (.insert id₀) nextMetas rids _ _ tbl1 bs 1 peak0
      hv1 (Nat.le_max_right _ _)
  -- Invoke `runOpenPayFinish_spec` on `f_open`
  have hsids_open_eq' :
      openSpecs.map (fun sp => sp.1.slotId) =
        (List.range openSpecs.length).map (tbl_ret.nextSlotId + ·) := by
    have hl : openSpecs.length = (openLevels H1).length := by
      have := congrArg List.length hks_eq; simpa using this
    rw [hl]
    exact hsids_open_eq
  rcases runOpenPayFinish_spec hσθ hfacs hδ0 hMC extHist id₀
      openSpecs keptMetas fuel_rem tbl_ret (1 + rids.length) peak0
      hA1_card_le hnext_len hrel_ret hret_nodup hret_sid_lt hsids_open_eq' hopen_inv
      hret_sp_le hpeak0_real with
    ⟨hhalt_open, hpath_open, hprob_open⟩
  -- Relate `stepFn` (`runSingleDynamicSearchStep`) to `f_open`
  have hstepFn_eq : ∀ bs,
      UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀) bs =
      (f_open bs).map (fun out => (insert id₀ S, out)) := by
    intro bs
    unfold UL.runSingleDynamicSearchStep
    rw [hstep_eq_fopen bs]
    cases hfo : f_open bs with
    | none => rfl
    | some out =>
      have hqa := (hpath_open bs out hfo).1
      simp [hqa, UL.applyDynamicSearchSetOp]
  refine ⟨?_, ?_, ?_⟩
  · -- Halt prob = 1
    unfold UL.singleDynamicSearchStepHaltProb
    have heq_isSome : ∀ bs,
        (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀) bs).isSome =
        (f_open bs).isSome := by
      intro bs
      rw [hstepFn_eq bs]
      cases f_open bs <;> rfl
    rw [← hhalt_open]
    unfold haltProb
    refine tsum_congr fun bs => ?_
    change (if (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀) bs).isSome
      then UL.bitListProb bs else 0) = _
    rw [heq_isSome bs]
  · -- Deterministic path properties
    intro bs S' out hstep
    rw [hstepFn_eq bs] at hstep
    cases hfo : f_open bs with
    | none => rw [hfo] at hstep; simp at hstep
    | some out' =>
      rw [hfo] at hstep
      simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq] at hstep
      rcases hstep with ⟨rfl, rfl⟩
      rcases hpath_open bs out' hfo with
        ⟨hqa, hst1, hact_out, hlife_out, hnod_out, hsid_out, hrel_out, hw_out, hsp_out⟩
      have hm_eq_next : out'.nextState.1.metas = nextMetas := by rw [hst1]
      have hinv_out : MCTableInv n pts h σ θ facs mkMC (insert id₀ S)
          out'.nextState.1 out'.nextState.2 :=
        { queue_none := by rw [hst1]
          img_eq := by rw [hact_out]; exact hA1_img
          card_eq := by rw [hact_out]; exact hA1_card_eq
          card_le_n := hcard_ins
          life_valid := by rw [hact_out, hlife_out]; exact hA1_life
          inj_snd := by rw [hact_out]; exact hA1_inj
          sid_lt := hsid_out
          sid_nodup := hnod_out
          kj_nodup := by rw [hm_eq_next]; exact hnext_kj_nodup
          kj_live := by rw [hm_eq_next, hlife_out]; exact hnext_kj_live
          slots_rel := by rw [hm_eq_next, hact_out, hlife_out]; exact hrel_out }
      refine ⟨rfl, hqa, hlife_out, hinv_out, ?_, ?_⟩
      · -- Work bound `≤ 50 * L * n^θ * P_time * (P_build + P_del + P_query)`
        have hB1_ge1 : 1 ≤ facs.buildWorkBound 1 n θ :=
          buildWorkBound_one_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs
        have hD1_nn : 0 ≤ facs.deleteWorkBound n θ :=
          le_trans zero_le_one (deleteWorkBound_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs)
        have hQ1_nn : 0 ≤ facs.queryWorkBound n θ :=
          le_trans zero_le_one (queryWorkBound_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs)
        have hu_real : (uBud + 1 : ℝ) ≤ 5 * facs.buildWorkBound 1 n θ := by
          dsimp only [uBud]
          unfold unitBuildBudget
          have hlt : (Nat.ceil (facs.buildWorkBound 1 n θ) : ℝ) ≤ facs.buildWorkBound 1 n θ + 1 :=
            (Nat.ceil_lt_add_one (by linarith)).le
          push_cast
          linarith
        have hw_nat : out'.work ≤ 2 + 4 * L + 3 * L * (uBud + 1) := by
          have hw_out' : out'.work ≤ (1 + rids.length) + openSpecs.length + nextMetas.length * (uBud + 1) + 1 :=
            hw_out
          have := hret_len
          have := hopen_len
          have hmul : nextMetas.length * (uBud + 1) ≤ (3 * L) * (uBud + 1) :=
            Nat.mul_le_mul_right _ hnext_len
          omega
        have hw_cast : (out'.work : ℝ) ≤ 2 + 4 * (L : ℝ) + 3 * (L : ℝ) * (uBud + 1 : ℝ) := by
          have h1 : (out'.work : ℝ) ≤ ((2 + 4 * L + 3 * L * (uBud + 1) : ℕ) : ℝ) := by
            exact_mod_cast hw_nat
          push_cast at h1
          exact h1
        have hL_ge1 : (1 : ℝ) ≤ (L : ℝ) := by dsimp [L]; push_cast; linarith
        have hsum_fac : facs.buildWorkBound 1 n θ ≤
            (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) := by
          have hexp : (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) =
              facs.buildWorkBound 1 n θ + facs.deleteWorkBound n θ + facs.queryWorkBound n θ := by
            unfold UL.BirthPoolPolyFactors.buildWorkBound UL.BirthPoolPolyFactors.deleteWorkBound
              UL.BirthPoolPolyFactors.queryWorkBound UL.BirthPoolPolyFactors.targetTime
              UL.birthPoolBuildWorkBound UL.birthPoolDeleteWorkBound UL.birthPoolQueryWorkBound
              UL.birthPoolTargetTime
            push_cast
            ring
          linarith
        nlinarith
      · -- Space bound `≤ 7 * L * spaceBound n σ`
        have hsp_nn : 0 ≤ facs.spaceBound n σ :=
          le_trans zero_le_one (spaceBound_ge_one hσθ.1 hσθ.2.1 hfacs)
        have hL_ge1 : (1 : ℝ) ≤ (L : ℝ) := by dsimp [L]; push_cast; linarith
        have hK_eq : (K : ℝ) = 3 * (L : ℝ) := by dsimp [K]; push_cast; ring
        rw [hK_eq] at hsp_out
        nlinarith
  · -- Probabilistic `AllSlotsGood` preservation
    intro hgood0
    have hgood_ret : AllSlotsGood mkMC tbl_ret := by
      intro sl hsl
      have hsl1 : sl ∈ tbl1.slots := (mem_applyRetireIds_iff rids tbl1.slots sl).mp hsl |>.1
      exact hgood0 sl hsl1
    have h1 := hprob_open hgood_ret
    have hopen_len_eq : (openSpecs.length : ℝ) = ((openLevels H1).length : ℝ) := by
      have hl : openSpecs.length = (openLevels H1).length := by
        have := congrArg List.length hks_eq; simpa using this
      exact_mod_cast hl
    have h1' : ENNReal.ofReal (1 - ((openLevels H1).length : ℝ) * δ_fail) ≤
        expWithBits f_open (fun out =>
          open Classical in if AllSlotsGood mkMC out.nextState.2 then 1 else 0) := by
      rw [← hopen_len_eq]
      exact h1
    refine h1'.trans (le_of_eq ?_)
    unfold expWithBits
    refine tsum_congr fun bs => ?_
    rw [hstepFn_eq bs]
    cases f_open bs <;> rfl

end UL.Proof_lem_7_1_RaceV31
