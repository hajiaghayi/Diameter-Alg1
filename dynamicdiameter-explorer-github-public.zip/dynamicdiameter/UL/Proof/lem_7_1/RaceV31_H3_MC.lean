import Mathlib
import UL.Stmt.lem_7_1
import UL.Proof.lem_7_1.RaceV31_H1_Coins
import UL.Proof.lem_7_1.RaceV31_H2_Dyadic
import UL.Proof.lem_7_1.RaceV31_H3a_MCStep
import UL.Proof.lem_7_1.RaceV31_H3b_MCIns
import UL.Proof.lem_7_1.RaceV31_H3c_MCDelQry
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. General Prefix-Execution Helpers (`runDynamicSearchStepsFrom`) -/

theorem ofFn_fin_zero {α : Type*} (tr : Fin 0 → α) :
    List.ofFn tr = [] := by
  simp

theorem ofFn_fin_cons {α : Type*} {k : ℕ} (x : α) (rest : Fin k → α) :
    List.ofFn (Fin.cons x rest) = x :: List.ofFn rest := by
  rw [List.ofFn_succ]
  simp

theorem runDynamicSearchStepsFrom_append {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (idx : UL.DynamicSearchIndex ι d d_s DynState)
    (adv : UL.DynamicSearchAdversary ι d d_s) :
    ∀ (tr₁ tr₂ : List (List Bool))
      (cur mid : UL.DynamicSearchPrefixState ι d d_s DynState),
      UL.runDynamicSearchStepsFrom idx adv cur tr₁ = some mid →
      UL.runDynamicSearchStepsFrom idx adv cur (tr₁ ++ tr₂) =
        UL.runDynamicSearchStepsFrom idx adv mid tr₂ := by
  intro tr₁
  induction tr₁ with
  | nil =>
    intro tr₂ cur mid h1
    simp only [UL.runDynamicSearchStepsFrom, Option.some.injEq] at h1
    subst h1
    rfl
  | cons bs rest ih =>
    intro tr₂ cur mid h1
    simp only [List.cons_append, UL.runDynamicSearchStepsFrom] at h1 ⊢
    cases hs : UL.runSingleDynamicSearchStep idx (adv cur.history).1 cur.activeSet cur.dynState
        (adv cur.history).2 bs with
    | none => simp [hs] at h1
    | some pair =>
      simp only [hs] at h1 ⊢
      exact ih tr₂ _ mid h1

/-! ### 2. Unified Single-Step Specification (`mcStep_any_spec`) -/

theorem singleStepHaltProb_eq_haltProb {ι : Type} [DecidableEq ι] {d d_s : ℕ} {DynState : Type}
    (idx : UL.DynamicSearchIndex ι d d_s DynState)
    (extHist : UL.ExecutionHistory d) (S : Finset ι) (st : DynState)
    (op : UL.DynamicSearchOp ι d_s) :
    haltProb (UL.runSingleDynamicSearchStep idx extHist S st op) =
      UL.singleDynamicSearchStepHaltProb idx extHist S st op :=
  rfl

theorem mcStep_any_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hδ0 : 0 ≤ δ_fail)
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    (extHist : UL.ExecutionHistory d)
    {S : Finset ι} {ctrl : MCCtrlState ι d_s} {tbl0 : UL.HostedMCTable ι d_s B I}
    (hinv : MCTableInv n pts h σ θ facs mkMC S ctrl tbl0)
    (hH_lt : tbl0.nextLifetime < maxOps)
    {op : UL.DynamicSearchOp ι d_s}
    (hleg : UL.IsLegalDynamicSearchOp n pts (fun _ _ => True) S op) :
    let dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
    let L := Nat.log 2 maxOps + 1
    let stepFn := UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) op
    UL.singleDynamicSearchStepHaltProb dynIdx extHist S (ctrl, tbl0) op = 1 ∧
    (∀ bs S' out, stepFn bs = some (S', out) →
      MCTableInv n pts h σ θ facs mkMC S' out.nextState.1 out.nextState.2 ∧
      out.nextState.2.nextLifetime ≤ tbl0.nextLifetime + 1 ∧
      (out.work : ℝ) ≤
        50 * (L : ℝ) * (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) ∧
      (out.peakSpace : ℝ) ≤ 7 * (L : ℝ) * facs.spaceBound n σ ∧
      (∀ q ans, op = .query q → out.queryAnswer = some ans →
           UL.IsValidSearchAnswer S q.accept ans ∧
           (AllSlotsGood mkMC tbl0 →
             UL.IsCompatibleTest pts S q.z q.accept →
             UL.IsCorrectSearchAnswer pts S h q.z q.accept ans))) ∧
    (∀ rem : ℕ, AllSlotsGood mkMC tbl0 →
      ENNReal.ofReal (1 - (remSlotBudget (rem + 1) tbl0.nextLifetime : ℝ) * δ_fail) ≤
        expWithBits stepFn (fun res =>
          open Classical in
          if AllSlotsGood mkMC res.2.nextState.2 then
            ENNReal.ofReal (1 - (remSlotBudget rem res.2.nextState.2.nextLifetime : ℝ) * δ_fail)
          else 0)) := by
  dsimp only []
  let dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
  cases op with
  | insert id₀ =>
    rcases mcStep_insert_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hδ0 hMC extHist hinv hH_lt hleg with
      ⟨hhalt, hpath, hprob⟩
    refine ⟨hhalt, ?_, ?_⟩
    · intro bs S' out hstep
      rcases hpath bs S' out hstep with ⟨_, hqa, hlife, hinv', hw, hsp⟩
      exact ⟨hinv', by omega, hw, hsp, fun _ _ hop => by cases hop⟩
    · intro rem hgood0
      classical
      let H := tbl0.nextLifetime
      let C : ℝ := (remSlotBudget rem (H + 1) : ℝ) * δ_fail
      have hC_nn : 0 ≤ C := mul_nonneg (Nat.cast_nonneg _) hδ0
      have hd_nn : 0 ≤ ((openLevels (H + 1)).length : ℝ) * δ_fail :=
        mul_nonneg (Nat.cast_nonneg _) hδ0
      have hbud_eq : (remSlotBudget (rem + 1) H : ℝ) * δ_fail =
          ((openLevels (H + 1)).length : ℝ) * δ_fail + C := by
        dsimp only [C]
        rw [← remSlotBudget_insert rem H]
        push_cast
        ring
      rw [hbud_eq]
      calc
        ENNReal.ofReal (1 - (((openLevels (H + 1)).length : ℝ) * δ_fail + C))
            ≤ ENNReal.ofReal (1 - ((openLevels (H + 1)).length : ℝ) * δ_fail) *
                ENNReal.ofReal (1 - C) :=
              ofReal_one_sub_add_le_mul hd_nn hC_nn
        _ ≤ expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀))
              (fun res => if AllSlotsGood mkMC res.2.nextState.2 then 1 else 0) *
              ENNReal.ofReal (1 - C) :=
              mul_le_mul_of_nonneg_right (hprob hgood0) (zero_le _)
        _ = expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀))
              (fun res =>
                (if AllSlotsGood mkMC res.2.nextState.2 then (1 : ENNReal) else 0) *
                  ENNReal.ofReal (1 - C)) :=
              (expWithBits_mul_const _ _ _).symm
        _ ≤ expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀))
              (fun res =>
                if AllSlotsGood mkMC res.2.nextState.2 then
                  ENNReal.ofReal (1 - (remSlotBudget rem res.2.nextState.2.nextLifetime : ℝ) * δ_fail)
                else 0) := by
              refine expWithBits_mono fun bs res hstep => ?_
              have hlife := (hpath bs res.1 res.2 hstep).2.2.1
              rw [hlife]
              by_cases hg : AllSlotsGood mkMC res.2.nextState.2 <;> simp [hg, C, H]
  | delete id₀ =>
    rcases mcStep_delete_spec (h_pos := h_pos) (h_lt_one := h_lt_one) (δ_fail := δ_fail)
        hσθ hfacs hMC extHist hinv (Nat.le_of_lt hH_lt) (id₀ := id₀) with
      ⟨hhalt, hpath⟩
    refine ⟨hhalt, ?_, ?_⟩
    · intro bs S' out hstep
      rcases hpath bs S' out hstep with ⟨_, hqa, hlife, hinv', hw, hsp, _⟩
      exact ⟨hinv', by omega, hw, hsp, fun _ _ hop => by cases hop⟩
    · intro rem hgood0
      classical
      let H := tbl0.nextLifetime
      have hle_bud : (remSlotBudget rem H : ℝ) * δ_fail ≤
          (remSlotBudget (rem + 1) H : ℝ) * δ_fail := by
        have hnat : remSlotBudget rem H ≤ remSlotBudget (rem + 1) H := remSlotBudget_nonInsert rem H
        exact mul_le_mul_of_nonneg_right (by exact_mod_cast hnat) hδ0
      have hle_ofReal :
          ENNReal.ofReal (1 - (remSlotBudget (rem + 1) H : ℝ) * δ_fail) ≤
            ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail) :=
        ENNReal.ofReal_le_ofReal (by linarith)
      have hconst_eq :
          expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀))
            (fun res =>
              if AllSlotsGood mkMC res.2.nextState.2 then
                ENNReal.ofReal (1 - (remSlotBudget rem res.2.nextState.2.nextLifetime : ℝ) * δ_fail)
              else 0) =
          ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail) := by
        calc
          expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀))
              (fun res =>
                if AllSlotsGood mkMC res.2.nextState.2 then
                  ENNReal.ofReal (1 - (remSlotBudget rem res.2.nextState.2.nextLifetime : ℝ) * δ_fail)
                else 0)
              = expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀))
                  (fun _ => ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail)) := by
                refine expWithBits_congr (fun _ => rfl) fun bs res hstep => ?_
                rcases hpath bs res.1 res.2 hstep with ⟨_, _, hlife, _, _, _, hg_imp⟩
                rw [hlife, if_pos (hg_imp hgood0)]
          _ = haltProb (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.delete id₀)) *
                ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail) :=
                expWithBits_const _ _
          _ = ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail) := by
                rw [singleStepHaltProb_eq_haltProb, hhalt, one_mul]
      rw [hconst_eq]
      exact hle_ofReal
  | query q =>
    rcases mcStep_query_spec (h_pos := h_pos) (h_lt_one := h_lt_one) (δ_fail := δ_fail)
        hσθ hfacs hMC extHist hinv (Nat.le_of_lt hH_lt) q with
      ⟨hhalt, hpath⟩
    refine ⟨hhalt, ?_, ?_⟩
    · intro bs S' out hstep
      rcases hpath bs S' out hstep with ⟨_, hlife, hinv', hw, hsp, _, ans, hqa, hval, hcorr⟩
      refine ⟨hinv', by omega, hw, hsp, ?_⟩
      rintro q' ans' hop' hqa'
      cases hop'
      rw [hqa] at hqa'
      cases hqa'
      exact ⟨hval, hcorr⟩
    · intro rem hgood0
      classical
      let H := tbl0.nextLifetime
      have hle_bud : (remSlotBudget rem H : ℝ) * δ_fail ≤
          (remSlotBudget (rem + 1) H : ℝ) * δ_fail := by
        have hnat : remSlotBudget rem H ≤ remSlotBudget (rem + 1) H := remSlotBudget_nonInsert rem H
        exact mul_le_mul_of_nonneg_right (by exact_mod_cast hnat) hδ0
      have hle_ofReal :
          ENNReal.ofReal (1 - (remSlotBudget (rem + 1) H : ℝ) * δ_fail) ≤
            ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail) :=
        ENNReal.ofReal_le_ofReal (by linarith)
      have hconst_eq :
          expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.query q))
            (fun res =>
              if AllSlotsGood mkMC res.2.nextState.2 then
                ENNReal.ofReal (1 - (remSlotBudget rem res.2.nextState.2.nextLifetime : ℝ) * δ_fail)
              else 0) =
          ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail) := by
        calc
          expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.query q))
              (fun res =>
                if AllSlotsGood mkMC res.2.nextState.2 then
                  ENNReal.ofReal (1 - (remSlotBudget rem res.2.nextState.2.nextLifetime : ℝ) * δ_fail)
                else 0)
              = expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.query q))
                  (fun _ => ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail)) := by
                refine expWithBits_congr (fun _ => rfl) fun bs res hstep => ?_
                rcases hpath bs res.1 res.2 hstep with ⟨_, hlife, _, _, _, hg_imp, _⟩
                rw [hlife, if_pos (hg_imp hgood0)]
          _ = haltProb (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.query q)) *
                ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail) :=
                expWithBits_const _ _
          _ = ENNReal.ofReal (1 - (remSlotBudget rem H : ℝ) * δ_fail) := by
                rw [singleStepHaltProb_eq_haltProb, hhalt, one_mul]
      rw [hconst_eq]
      exact hle_ofReal

/-! ### 3. Reachable Prefix Invariant & Adaptive Correctness Induction -/

structure MCReachableInv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h σ θ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I)
    (W_cap S_cap : ℝ)
    (cur : UL.DynamicSearchPrefixState ι d d_s (MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I)) :
    Prop where
  tbl_inv : MCTableInv n pts h σ θ facs mkMC cur.activeSet cur.dynState.1 cur.dynState.2
  life_le_hist : cur.dynState.2.nextLifetime ≤ cur.history.length
  works_le : ∀ w ∈ cur.stepWorks, (w : ℝ) ≤ W_cap
  space_le : (cur.maxSpace : ℝ) ≤ S_cap

def GoodPrefixState {ι : Type} {d d_s : ℕ} {B I : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h : ℝ)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I)
    (cur : UL.DynamicSearchPrefixState ι d d_s (MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I)) :
    Prop :=
  AllSlotsGood mkMC cur.dynState.2 ∧ UL.AllDynamicQueryAnswersCorrect pts h cur

theorem mcRunStepsFrom_inv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hδ0 : 0 ≤ δ_fail)
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    {W_cap S_cap : ℝ}
    (hW_cap : 50 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) * (n : ℝ) ^ θ * facs.P_time *
        (facs.P_build + facs.P_del + facs.P_query) ≤ W_cap)
    (hS_cap : 7 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) * facs.spaceBound n σ ≤ S_cap)
    (adv : UL.DynamicSearchAdversary ι d d_s)
    (hadv : UL.IsValidBoundedDynamicSearchAdversary n maxOps pts (fun _ _ => True)
      ((mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC) adv) :
    ∀ (restTrace pastTrace : List (List Bool))
      (cur out : UL.DynamicSearchPrefixState ι d d_s
        (MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I)),
      UL.runDynamicSearchSteps
        ((mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC)
        adv pastTrace = some cur →
      cur.history.length = pastTrace.length →
      MCReachableInv n pts h σ θ facs mkMC W_cap S_cap cur →
      (pastTrace ++ restTrace).length ≤ maxOps →
      UL.runDynamicSearchStepsFrom
        ((mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC)
        adv cur restTrace = some out →
      UL.runDynamicSearchSteps
        ((mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC)
        adv (pastTrace ++ restTrace) = some out ∧
      out.history.length = (pastTrace ++ restTrace).length ∧
      MCReachableInv n pts h σ θ facs mkMC W_cap S_cap out := by
  set dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
  intro restTrace
  induction restTrace with
  | nil =>
    intro pastTrace cur out hrun_past hlen hinv _ hrun_rest
    simp only [UL.runDynamicSearchStepsFrom, Option.some.injEq] at hrun_rest
    subst hrun_rest
    simp [hrun_past, hlen, hinv]
  | cons bs rest ih =>
    intro pastTrace cur out hrun_past hlen hinv htot_le hrun_rest
    have hpast_lt : pastTrace.length < maxOps := by
      simp only [List.length_append, List.length_cons] at htot_le
      omega
    have hH_lt : cur.dynState.2.nextLifetime < maxOps := by
      have := hinv.life_le_hist
      omega
    have hleg : UL.IsLegalDynamicSearchOp n pts (fun _ _ => True) cur.activeSet
        (adv cur.history).2 :=
      hadv pastTrace hpast_lt cur hrun_past
    rcases mcStep_any_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hδ0 hMC (adv cur.history).1 hinv.tbl_inv hH_lt hleg with
      ⟨_, hpath, _⟩
    simp only [UL.runDynamicSearchStepsFrom] at hrun_rest
    cases hs : UL.runSingleDynamicSearchStep dynIdx (adv cur.history).1
        cur.activeSet cur.dynState (adv cur.history).2 bs with
    | none => simp [hs] at hrun_rest
    | some pair =>
      rcases pair with ⟨S', stepOut⟩
      simp only [hs] at hrun_rest
      rcases hpath bs S' stepOut hs with ⟨htbl', hlife', hw', hsp', _⟩
      let entry : UL.DynamicSearchHistoryEntry ι d d_s :=
        { extHistory := (adv cur.history).1
          operation := (adv cur.history).2
          randomBits := bs
          queryAnswer := stepOut.queryAnswer }
      let qRecs :=
        match (adv cur.history).2, stepOut.queryAnswer with
        | .query q, some ans => cur.queryRecords ++ [(cur.activeSet, q, ans)]
        | _, _ => cur.queryRecords
      let next : UL.DynamicSearchPrefixState ι d d_s
          (MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I) :=
        { activeSet := S'
          dynState := stepOut.nextState
          history := cur.history ++ [entry]
          queryRecords := qRecs
          stepWorks := cur.stepWorks ++ [stepOut.work]
          totalWork := cur.totalWork + stepOut.work
          maxSpace := max cur.maxSpace stepOut.peakSpace }
      have hrun_one : UL.runDynamicSearchStepsFrom dynIdx adv cur [bs] = some next := by
        simp only [UL.runDynamicSearchStepsFrom, hs]; rfl
      have hrun_past' : UL.runDynamicSearchSteps dynIdx adv (pastTrace ++ [bs]) = some next := by
        unfold UL.runDynamicSearchSteps at hrun_past ⊢
        rw [runDynamicSearchStepsFrom_append dynIdx adv pastTrace [bs] _ cur hrun_past]
        exact hrun_one
      have hlen' : next.history.length = (pastTrace ++ [bs]).length := by
        dsimp only [next]; simp [hlen]
      have hinv' : MCReachableInv n pts h σ θ facs mkMC W_cap S_cap next :=
        { tbl_inv := htbl'
          life_le_hist := by
            dsimp only [next]; simp only [List.length_append, List.length_singleton]
            have := hinv.life_le_hist
            omega
          works_le := by
            intro w hw_mem
            dsimp only [next] at hw_mem
            rcases List.mem_append.mp hw_mem with hw0 | hw1
            · exact hinv.works_le w hw0
            · simp only [List.mem_singleton] at hw1
              subst hw1
              exact le_trans hw' hW_cap
          space_le := by
            dsimp only [next]
            rw [Nat.cast_max]
            exact max_le hinv.space_le (le_trans hsp' hS_cap) }
      have htot_le' : ((pastTrace ++ [bs]) ++ rest).length ≤ maxOps := by
        simpa [List.append_assoc] using htot_le
      rcases ih (pastTrace ++ [bs]) next out hrun_past' hlen' hinv' htot_le' hrun_rest with
        ⟨hr1, hr2, hr3⟩
      simpa [List.append_assoc] using And.intro hr1 (And.intro hr2 hr3)

open Classical in
theorem mcProbGoodFrom_ge {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hδ0 : 0 ≤ δ_fail)
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    {W_cap S_cap : ℝ}
    (hW_cap : 50 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) * (n : ℝ) ^ θ * facs.P_time *
        (facs.P_build + facs.P_del + facs.P_query) ≤ W_cap)
    (hS_cap : 7 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) * facs.spaceBound n σ ≤ S_cap)
    (adv : UL.DynamicSearchAdversary ι d d_s)
    (hadv : UL.IsValidBoundedDynamicSearchAdversary n maxOps pts (fun _ _ => True)
      ((mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC) adv) :
    ∀ (rem : ℕ) (pastTrace : List (List Bool))
      (cur : UL.DynamicSearchPrefixState ι d d_s
        (MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I)),
      UL.runDynamicSearchSteps
        ((mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC)
        adv pastTrace = some cur →
      cur.history.length = pastTrace.length →
      MCReachableInv n pts h σ θ facs mkMC W_cap S_cap cur →
      GoodPrefixState pts h mkMC cur →
      pastTrace.length + rem ≤ maxOps →
      ENNReal.ofReal (1 - (remSlotBudget rem cur.dynState.2.nextLifetime : ℝ) * δ_fail) ≤
        ∑' tr : Fin rem → List Bool,
          match UL.runDynamicSearchStepsFrom
            ((mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC)
            adv cur (List.ofFn tr) with
          | some out => if GoodPrefixState pts h mkMC out then UL.prefixTraceProb tr else 0
          | none => 0 := by
  set dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
  intro rem
  induction rem with
  | zero =>
    intro pastTrace cur _ _ _ hgood _
    rw [tsum_fin_zero, ofFn_fin_zero]
    simp only [UL.runDynamicSearchStepsFrom, if_pos hgood, prefixTraceProb_zero]
    have hnn : 0 ≤ (remSlotBudget 0 cur.dynState.2.nextLifetime : ℝ) * δ_fail :=
      mul_nonneg (Nat.cast_nonneg _) hδ0
    calc
      ENNReal.ofReal (1 - (remSlotBudget 0 cur.dynState.2.nextLifetime : ℝ) * δ_fail)
          ≤ ENNReal.ofReal 1 := ENNReal.ofReal_le_ofReal (by linarith)
      _ = 1 := ENNReal.ofReal_one
  | succ r ih =>
    intro pastTrace cur hrun_past hlen hinv hgood htot_le
    have hpast_lt : pastTrace.length < maxOps := by omega
    have hH_lt : cur.dynState.2.nextLifetime < maxOps := by
      have := hinv.life_le_hist
      omega
    have hleg : UL.IsLegalDynamicSearchOp n pts (fun _ _ => True) cur.activeSet
        (adv cur.history).2 :=
      hadv pastTrace hpast_lt cur hrun_past
    rcases mcStep_any_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hδ0 hMC (adv cur.history).1 hinv.tbl_inv hH_lt hleg with
      ⟨_, hpath, hprob_step⟩
    rw [tsum_fin_succ]
    refine (hprob_step r hgood.1).trans ?_
    unfold expWithBits
    refine ENNReal.tsum_le_tsum fun bs => ?_
    cases hs : UL.runSingleDynamicSearchStep dynIdx (adv cur.history).1
        cur.activeSet cur.dynState (adv cur.history).2 bs with
    | none =>
      exact zero_le _
    | some pair =>
      rcases pair with ⟨S', stepOut⟩
      dsimp only []
      by_cases hg_next : AllSlotsGood mkMC stepOut.nextState.2
      · rw [if_pos hg_next]
        rcases hpath bs S' stepOut hs with ⟨htbl', hlife', hw', hsp', hq_corr⟩
        let entry : UL.DynamicSearchHistoryEntry ι d d_s :=
          { extHistory := (adv cur.history).1
            operation := (adv cur.history).2
            randomBits := bs
            queryAnswer := stepOut.queryAnswer }
        let qRecs :=
          match (adv cur.history).2, stepOut.queryAnswer with
          | .query q, some ans => cur.queryRecords ++ [(cur.activeSet, q, ans)]
          | _, _ => cur.queryRecords
        let next : UL.DynamicSearchPrefixState ι d d_s
            (MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I) :=
          { activeSet := S'
            dynState := stepOut.nextState
            history := cur.history ++ [entry]
            queryRecords := qRecs
            stepWorks := cur.stepWorks ++ [stepOut.work]
            totalWork := cur.totalWork + stepOut.work
            maxSpace := max cur.maxSpace stepOut.peakSpace }
        have hrun_one : UL.runDynamicSearchStepsFrom dynIdx adv cur [bs] = some next := by
          simp only [UL.runDynamicSearchStepsFrom, hs]; rfl
        have hrun_past' : UL.runDynamicSearchSteps dynIdx adv (pastTrace ++ [bs]) = some next := by
          unfold UL.runDynamicSearchSteps at hrun_past ⊢
          rw [runDynamicSearchStepsFrom_append dynIdx adv pastTrace [bs] _ cur hrun_past]
          exact hrun_one
        have hlen' : next.history.length = (pastTrace ++ [bs]).length := by
          dsimp only [next]; simp [hlen]
        have hinv' : MCReachableInv n pts h σ θ facs mkMC W_cap S_cap next :=
          { tbl_inv := htbl'
            life_le_hist := by
              dsimp only [next]; simp only [List.length_append, List.length_singleton]
              have := hinv.life_le_hist
              omega
            works_le := by
              intro w hw_mem
              dsimp only [next] at hw_mem
              rcases List.mem_append.mp hw_mem with hw0 | hw1
              · exact hinv.works_le w hw0
              · simp only [List.mem_singleton] at hw1
                subst hw1
                exact le_trans hw' hW_cap
            space_le := by
              dsimp only [next]
              rw [Nat.cast_max]
              exact max_le hinv.space_le (le_trans hsp' hS_cap) }
        have hqrec_next : UL.AllDynamicQueryAnswersCorrect pts h next := by
          intro rec hrec
          dsimp only [next, qRecs] at hrec
          cases hop : (adv cur.history).2 with
          | insert _ =>
            rw [hop] at hrec
            exact hgood.2 rec hrec
          | delete _ =>
            rw [hop] at hrec
            exact hgood.2 rec hrec
          | query q =>
            rw [hop] at hrec
            cases hqa : stepOut.queryAnswer with
            | none =>
              rw [hqa] at hrec
              exact hgood.2 rec hrec
            | some ans =>
              rw [hqa] at hrec
              rcases List.mem_append.mp hrec with hrec0 | hrec1
              · exact hgood.2 rec hrec0
              · simp only [List.mem_singleton] at hrec1
                subst hrec1
                rcases hq_corr q ans hop hqa with ⟨hval, hcorr⟩
                exact ⟨hval, hcorr hgood.1⟩
        have hgood_next : GoodPrefixState pts h mkMC next := ⟨hg_next, hqrec_next⟩
        have htot_le' : (pastTrace ++ [bs]).length + r ≤ maxOps := by
          simp only [List.length_append, List.length_singleton]
          omega
        have h_ih := ih (pastTrace ++ [bs]) next hrun_past' hlen' hinv' hgood_next htot_le'
        have hinner_eq :
            (∑' rest : Fin r → List Bool,
              match UL.runDynamicSearchStepsFrom dynIdx adv cur
                  (List.ofFn (Fin.cons bs rest)) with
              | some out =>
                  if GoodPrefixState pts h mkMC out then
                    UL.prefixTraceProb (Fin.cons bs rest)
                  else 0
              | none => 0) =
            UL.bitListProb bs *
              (∑' rest : Fin r → List Bool,
                match UL.runDynamicSearchStepsFrom dynIdx adv next (List.ofFn rest) with
                | some out => if GoodPrefixState pts h mkMC out then UL.prefixTraceProb rest else 0
                | none => 0) := by
          rw [← ENNReal.tsum_mul_left]
          refine tsum_congr fun rest => ?_
          rw [ofFn_fin_cons, prefixTraceProb_cons]
          simp only [UL.runDynamicSearchStepsFrom, hs]
          change (match UL.runDynamicSearchStepsFrom dynIdx adv next (List.ofFn rest) with
            | some out =>
                if GoodPrefixState pts h mkMC out then
                  UL.bitListProb bs * UL.prefixTraceProb rest
                else 0
            | none => 0) = _
          cases UL.runDynamicSearchStepsFrom dynIdx adv next (List.ofFn rest) with
          | none => simp
          | some out => dsimp only []; split_ifs <;> simp
        rw [hinner_eq]
        exact mul_le_mul_of_nonneg_left h_ih (zero_le _)
      · rw [if_neg hg_next, mul_zero]
        exact zero_le _

/-! ### 4. Complete Part 1 Wrapper Theorem (`part1_mc_wrapper`) -/

theorem part1_mc_wrapper
    {C_wrap : ℝ} {deg_log : ℕ}
    (hC : 100 ≤ C_wrap) (hdeg : 1 ≤ deg_log)
    (d d_s n : ℕ) (ι : Type) [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (σ θ : ℝ) (hσθ : UL.ValidBirthPoolExponents n σ θ)
    (facs : UL.BirthPoolPolyFactors) (hfacs : facs.Valid)
    (P_life : ℝ) (hPlife : 1 ≤ P_life)
    (maxOps : ℕ) (hmaxOps : (maxOps : ℝ) ≤ (n : ℝ) * P_life)
    (δ_fail : ℝ) (hδ0 : 0 ≤ δ_fail) (_hδ1 : δ_fail < 1)
    (MCBirthState MCIndexState : Type)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s →
      UL.MonteCarloSearchGeneration (ι × ℕ) d d_s MCBirthState MCIndexState)
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen)) :
    let logFac : ℝ := (1 + Real.log (2 * (n : ℝ) * P_life)) ^ deg_log
    let stepWorkBound : ℝ :=
      C_wrap * logFac * (n : ℝ) ^ θ * facs.P_time *
        (facs.P_build + facs.P_del + facs.P_query)
    let spaceBound : ℝ :=
      C_wrap * logFac * (n : ℝ) ^ (1 + σ) * facs.P_space
    ∃ (CtrlState : Type)
      (ctrl : UL.MCHostedController ι d_s MCBirthState MCIndexState CtrlState),
      let dynIdx := ctrl.toDynamicSearchIndex (d := d) n pts h mkMC
      (∀ extHist S st op bs₁ bs₂ out₁ out₂,
        dynIdx.stepWithBits extHist S st op bs₁ = some out₁ →
        dynIdx.stepWithBits extHist S st op bs₂ = some out₂ →
        bs₁ <+: bs₂ → bs₁ = bs₂) ∧
      (dynIdx.initWork : ℝ) ≤ stepWorkBound ∧
      (dynIdx.initSpace : ℝ) ≤ spaceBound ∧
      (∀ adv : UL.DynamicSearchAdversary ι d d_s,
        UL.IsValidBoundedDynamicSearchAdversary n maxOps pts (fun _ _ => True) dynIdx adv →
          (∀ bitTrace : List (List Bool), bitTrace.length < maxOps →
            ∀ prefSt,
              UL.runDynamicSearchSteps dynIdx adv bitTrace = some prefSt →
                let (extHist, op) := adv prefSt.history
                UL.singleDynamicSearchStepHaltProb dynIdx extHist
                  prefSt.activeSet prefSt.dynState op = 1) ∧
          (∀ T : ℕ, T ≤ maxOps → ∀ trace : Fin T → List Bool, ∀ out,
            UL.runDynamicSearchPrefix dynIdx adv T trace = some out →
              (∀ w ∈ out.stepWorks, (w : ℝ) ≤ stepWorkBound) ∧
              (out.maxSpace : ℝ) ≤ spaceBound) ∧
          (∀ T : ℕ, T ≤ maxOps →
            ENNReal.ofReal (1 - 2 * (T : ℝ) * δ_fail) ≤
              UL.dynamicSearchPrefixEventProb dynIdx adv T
                (UL.AllDynamicQueryAnswersCorrect pts h))) := by
  dsimp only []
  let logFac : ℝ := (1 + Real.log (2 * (n : ℝ) * P_life)) ^ deg_log
  let stepWorkBound : ℝ :=
    C_wrap * logFac * (n : ℝ) ^ θ * facs.P_time *
      (facs.P_build + facs.P_del + facs.P_query)
  let spaceBound : ℝ :=
    C_wrap * logFac * (n : ℝ) ^ (1 + σ) * facs.P_space
  let ctrl := mcController n pts h h_pos h_lt_one θ facs mkMC
  let dynIdx := ctrl.toDynamicSearchIndex (d := d) n pts h mkMC
  have hlog_nn : 0 ≤ Real.log (2 * (n : ℝ) * P_life) :=
    log_two_n_Plife_nonneg hσθ.1 hPlife
  have hB_ge1 : 1 ≤ 1 + Real.log (2 * (n : ℝ) * P_life) := by linarith
  have hlogFac_ge_B : 1 + Real.log (2 * (n : ℝ) * P_life) ≤ logFac := by
    calc
      1 + Real.log (2 * (n : ℝ) * P_life)
          = (1 + Real.log (2 * (n : ℝ) * P_life)) ^ 1 := (pow_one _).symm
      _ ≤ (1 + Real.log (2 * (n : ℝ) * P_life)) ^ deg_log :=
          pow_le_pow_right₀ hB_ge1 hdeg
  have hlogFac_ge1 : 1 ≤ logFac := hB_ge1.trans hlogFac_ge_B
  have hL_le : ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) ≤ 2 * logFac := by
    have h1 : (Nat.log 2 maxOps + 1 : ℝ) ≤ 2 * (1 + Real.log (2 * (n : ℝ) * P_life)) :=
      log_succ_le_two_one_add_log hσθ.1 hPlife hmaxOps
    push_cast
    linarith
  have hθ_nn : 0 ≤ θ := hσθ.2.1.trans hσθ.2.2
  have ht_ge1 : 1 ≤ (n : ℝ) ^ θ * facs.P_time :=
    targetTime_ge_one hσθ.1 hθ_nn hfacs
  have hPsum_ge1 : 1 ≤ facs.P_build + facs.P_del + facs.P_query := by
    have := hfacs.2.2.1; have := hfacs.2.2.2.1; have := hfacs.2.2.2.2
    linarith
  have hsp_ge1 : 1 ≤ (n : ℝ) ^ (1 + σ) * facs.P_space :=
    spaceBound_ge_one hσθ.1 hσθ.2.1 hfacs
  have hW_cap : 50 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) * (n : ℝ) ^ θ * facs.P_time *
      (facs.P_build + facs.P_del + facs.P_query) ≤ stepWorkBound := by
    have hcoeff : 50 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) ≤ C_wrap * logFac := by nlinarith
    have htail_nn : 0 ≤ (n : ℝ) ^ θ * facs.P_time *
        (facs.P_build + facs.P_del + facs.P_query) := by nlinarith
    calc
      50 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) * (n : ℝ) ^ θ * facs.P_time *
          (facs.P_build + facs.P_del + facs.P_query)
          = (50 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ)) *
              ((n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query)) := by ring
      _ ≤ (C_wrap * logFac) *
            ((n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query)) :=
          mul_le_mul_of_nonneg_right hcoeff htail_nn
      _ = stepWorkBound := by dsimp [stepWorkBound]; ring
  have hS_cap : 7 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) * facs.spaceBound n σ ≤ spaceBound := by
    have hcoeff : 7 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) ≤ C_wrap * logFac := by nlinarith
    have htail_nn : 0 ≤ (n : ℝ) ^ (1 + σ) * facs.P_space := by linarith
    calc
      7 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ) * facs.spaceBound n σ
          = (7 * ((Nat.log 2 maxOps + 1 : ℕ) : ℝ)) * ((n : ℝ) ^ (1 + σ) * facs.P_space) := by
              unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
              ring
      _ ≤ (C_wrap * logFac) * ((n : ℝ) ^ (1 + σ) * facs.P_space) :=
          mul_le_mul_of_nonneg_right hcoeff htail_nn
      _ = spaceBound := by dsimp [spaceBound]; ring
  have hinitW_le : (dynIdx.initWork : ℝ) ≤ stepWorkBound := by
    simp only [dynIdx, UL.MCHostedController.toDynamicSearchIndex, Nat.cast_one]
    have hclog : 1 ≤ C_wrap * logFac := by nlinarith
    have htail : 1 ≤ (n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query) := by
      nlinarith
    calc
      (1 : ℝ) ≤ (C_wrap * logFac) *
          ((n : ℝ) ^ θ * facs.P_time * (facs.P_build + facs.P_del + facs.P_query)) := by nlinarith
      _ = stepWorkBound := by dsimp [stepWorkBound]; ring
  have hinitS_le : (dynIdx.initSpace : ℝ) ≤ spaceBound := by
    simp only [dynIdx, UL.MCHostedController.toDynamicSearchIndex, Nat.cast_one]
    have hclog : 1 ≤ C_wrap * logFac := by nlinarith
    calc
      (1 : ℝ) ≤ (C_wrap * logFac) * ((n : ℝ) ^ (1 + σ) * facs.P_space) := by nlinarith
      _ = spaceBound := by dsimp [spaceBound]; ring
  have hinit_inv : MCReachableInv n pts h σ θ facs mkMC stepWorkBound spaceBound
      (UL.initDynamicSearchPrefixState dynIdx) :=
    { tbl_inv := mcTableInv_empty n pts h σ θ facs mkMC
      life_le_hist := by simp [UL.initDynamicSearchPrefixState, dynIdx, ctrl, mcController,
        UL.MCHostedController.toDynamicSearchIndex, UL.HostedMCTable.empty]
      works_le := by simp [UL.initDynamicSearchPrefixState]
      space_le := hinitS_le }
  refine ⟨MCCtrlState ι d_s, ctrl, ?_, hinitW_le, hinitS_le, ?_⟩
  · intro extHist S st op bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
    exact isPrefixFree_mcDynIdx hMC extHist S st op bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
  · intro adv hadv
    refine ⟨?_, ?_, ?_⟩
    · -- (a) Almost-sure halting at every reachable prefix `< maxOps`
      intro bitTrace hlen_lt prefSt hrun
      have hrun_empty : UL.runDynamicSearchSteps dynIdx adv [] =
          some (UL.initDynamicSearchPrefixState dynIdx) := rfl
      rcases mcRunStepsFrom_inv (h_pos := h_pos) (h_lt_one := h_lt_one)
          hσθ hfacs hδ0 hMC hW_cap hS_cap adv hadv bitTrace []
          (UL.initDynamicSearchPrefixState dynIdx) prefSt
          hrun_empty rfl hinit_inv (by simpa using Nat.le_of_lt hlen_lt) hrun with
        ⟨_, hhist_len, hpref_inv⟩
      have hH_lt : prefSt.dynState.2.nextLifetime < maxOps := by
        have := hpref_inv.life_le_hist
        simp only [List.nil_append] at hhist_len
        omega
      have hleg := hadv bitTrace hlen_lt prefSt hrun
      exact (mcStep_any_spec (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hδ0 hMC (adv prefSt.history).1 hpref_inv.tbl_inv hH_lt hleg).1
    · -- (b) Deterministic worst-case per-step work & maxSpace bounds
      intro T hT_le trace out hrun_pref
      have hrun_empty : UL.runDynamicSearchSteps dynIdx adv [] =
          some (UL.initDynamicSearchPrefixState dynIdx) := rfl
      have hlen_ofFn : (([] : List (List Bool)) ++ List.ofFn trace).length ≤ maxOps := by
        simpa using hT_le
      rcases mcRunStepsFrom_inv (h_pos := h_pos) (h_lt_one := h_lt_one)
          hσθ hfacs hδ0 hMC hW_cap hS_cap adv hadv (List.ofFn trace) []
          (UL.initDynamicSearchPrefixState dynIdx) out
          hrun_empty rfl hinit_inv hlen_ofFn hrun_pref with
        ⟨_, _, hout_inv⟩
      exact ⟨hout_inv.works_le, hout_inv.space_le⟩
    · -- (c) Simultaneous adaptive query correctness probability `≥ 1 - 2 * T * δ_fail`
      intro T hT_le
      have hrun_empty : UL.runDynamicSearchSteps dynIdx adv [] =
          some (UL.initDynamicSearchPrefixState dynIdx) := rfl
      have hgood_init : GoodPrefixState pts h mkMC (UL.initDynamicSearchPrefixState dynIdx) := by
        refine ⟨?_, ?_⟩
        · intro sl hsl
          simp [UL.initDynamicSearchPrefixState, dynIdx, ctrl, mcController,
            UL.MCHostedController.toDynamicSearchIndex, UL.HostedMCTable.empty] at hsl
        · intro rec hrec
          simp [UL.initDynamicSearchPrefixState] at hrec
      have hprob := mcProbGoodFrom_ge (h_pos := h_pos) (h_lt_one := h_lt_one)
        hσθ hfacs hδ0 hMC hW_cap hS_cap adv hadv T []
        (UL.initDynamicSearchPrefixState dynIdx)
        hrun_empty rfl hinit_inv hgood_init (by simpa using hT_le)
      have hbud0 : remSlotBudget T
          (UL.initDynamicSearchPrefixState dynIdx).dynState.2.nextLifetime = 2 * T := by
        have hnl0 : (UL.initDynamicSearchPrefixState dynIdx).dynState.2.nextLifetime = 0 := rfl
        rw [hnl0]
        simp [remSlotBudget, popcount]
      rw [hbud0] at hprob
      have hcast_eq : ((2 * T : ℕ) : ℝ) * δ_fail = 2 * (T : ℝ) * δ_fail := by
        push_cast; ring
      rw [hcast_eq] at hprob
      refine hprob.trans ?_
      unfold UL.dynamicSearchPrefixEventProb UL.runDynamicSearchPrefix UL.runDynamicSearchSteps
      refine ENNReal.tsum_le_tsum fun tr => ?_
      classical
      cases UL.runDynamicSearchStepsFrom dynIdx adv (UL.initDynamicSearchPrefixState dynIdx)
          (List.ofFn tr) with
      | none => exact le_rfl
      | some out =>
        dsimp only []
        by_cases hg : GoodPrefixState pts h mkMC out
        · rw [if_pos hg, if_pos hg.2]
        · rw [if_neg hg]; exact zero_le _

end UL.Proof_lem_7_1_RaceV31
