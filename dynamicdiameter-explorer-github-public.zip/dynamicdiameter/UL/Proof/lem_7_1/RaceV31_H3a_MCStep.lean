import Mathlib
import UL.Stmt.lem_7_1
import UL.Proof.lem_7_1.RaceV31_H1_Coins
import UL.Proof.lem_7_1.RaceV31_H2_Dyadic
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. Scheduled Monte Carlo Controller Types & Definitions -/

structure MCSlotMeta where
  slotId : ℕ
  k : ℕ
  j : ℕ

inductive PlannedMCCmd (ι : Type) (d_s : ℕ) : Type
  | openSlot (gen : UL.SearchGeneration (ι × ℕ) d_s)
  | deleteFromSlot (slotId : ℕ) (rec : ι × ℕ)
  | payWork (slotId : ℕ) (budget : ℕ)
  | retireSlot (slotId : ℕ)
  | finishUpdate
  | finishQuery (servingSlotIds : List ℕ)

structure MCCtrlState (ι : Type) (d_s : ℕ) : Type where
  metas : List MCSlotMeta
  queue : Option (List (PlannedMCCmd ι d_s))

/-- Classical table validity guard ensuring every hosted slot satisfies the domain hypotheses
required for `deleteWithBits` prefix-freeness, even on arbitrary unreachable states. -/
def ValidMCTable {ι : Type} {d d_s : ℕ} {B I : Type}
    (n : ℕ) (h : ℝ)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I)
    (tbl : UL.HostedMCTable ι d_s B I) : Prop :=
  ∀ sl ∈ tbl.slots,
    sl.gen.m ≤ n ∧ sl.gen.h = h ∧ sl.surviving ⊆ sl.gen.P₀ ∧
    ∃ birthHist, (mkMC sl.gen).IsValidState birthHist sl.bState sl.surviving sl.idxState

/-- A hosted slot is "good" when a single `birthHist` witnesses both `IsBirthSuccess` and
`IsValidState` on its current surviving set and index state. -/
def GoodMCSlot {ι : Type} {d d_s : ℕ} {B I : Type}
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I)
    (sl : UL.HostedMCSlot ι d_s B I) : Prop :=
  ∃ birthHist,
    (mkMC sl.gen).IsBirthSuccess birthHist sl.bState ∧
    (mkMC sl.gen).IsValidState birthHist sl.bState sl.surviving sl.idxState

def AllSlotsGood {ι : Type} {d d_s : ℕ} {B I : Type}
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I)
    (tbl : UL.HostedMCTable ι d_s B I) : Prop :=
  ∀ sl ∈ tbl.slots, GoodMCSlot mkMC sl

noncomputable def unitBuildBudget (n : ℕ) (θ : ℝ) (facs : UL.BirthPoolPolyFactors) : ℕ :=
  Nat.ceil (facs.buildWorkBound 1 n θ) + 2

noncomputable def delBudget (n : ℕ) (θ : ℝ) (facs : UL.BirthPoolPolyFactors) : ℕ :=
  Nat.ceil (facs.deleteWorkBound n θ) + 1

/-- Build `(MCSlotMeta, SearchGeneration)` pairs in lockstep with `nextSlotId` for `ks`. -/
noncomputable def buildOpenSpecs {ι : Type} [DecidableEq ι] {d_s : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (activeLifetimes : Finset (ι × ℕ)) (H1 : ℕ) :
    ℕ → List ℕ → Option (List (MCSlotMeta × UL.SearchGeneration (ι × ℕ) d_s))
  | _, [] => some []
  | nextSid, k :: ks =>
      open Classical in
      let j := H1 / 2 ^ k - 1
      let P₀ := activeLifetimes.filter (fun p => j * 2 ^ k ≤ p.2 ∧ p.2 < H1)
      if hP : P₀.Nonempty ∧ ∀ p ∈ P₀, UL.IsUnitVec (pts p.1) then
        match buildOpenSpecs pts h h_pos h_lt_one activeLifetimes H1 (nextSid + 1) ks with
        | none => none
        | some rest =>
            let gen : UL.SearchGeneration (ι × ℕ) d_s :=
              { P₀ := P₀
                pts := fun p => pts p.1
                nonempty := hP.1
                unit_pts := hP.2
                h := h
                h_pos := h_pos
                h_lt_one := h_lt_one }
            some (({ slotId := nextSid, k := k, j := j }, gen) :: rest)
      else
        none

/-- Pre-plan the finite micro-command list and updated `metas` for one dynamic operation. -/
noncomputable def planMCStep {ι : Type} [DecidableEq ι] {d_s : ℕ} {B I : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (θ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (op : UL.DynamicSearchOp ι d_s) (oldMetas : List MCSlotMeta)
    (tbl1 : UL.HostedMCTable ι d_s B I) :
    List MCSlotMeta × List (PlannedMCCmd ι d_s) :=
  open Classical in
  match op with
  | .insert _ =>
      let H1 := tbl1.nextLifetime
      let toRetire := oldMetas.filter (fun m => !decide (LiveMC H1 m.k m.j))
      let keptMetas := oldMetas.filter (fun m => decide (LiveMC H1 m.k m.j))
      let ks := openLevels H1
      match buildOpenSpecs pts h h_pos h_lt_one tbl1.activeLifetimes H1 tbl1.nextSlotId ks with
      | none => (oldMetas, [])
      | some openSpecs =>
          let nextMetas := keptMetas ++ openSpecs.map Prod.fst
          let uBud := unitBuildBudget n θ facs
          let cmds :=
            (toRetire.map (fun m => PlannedMCCmd.retireSlot m.slotId)) ++
            (openSpecs.map (fun sp => PlannedMCCmd.openSlot sp.2)) ++
            (nextMetas.map (fun m => PlannedMCCmd.payWork m.slotId uBud)) ++
            [PlannedMCCmd.finishUpdate]
          (nextMetas, cmds)
  | .delete id =>
      let dBud := delBudget n θ facs
      let delPairs : List (ℕ × (ι × ℕ)) :=
        tbl1.slots.filterMap fun sl =>
          let filt := sl.surviving.filter (fun p => p.1 = id)
          if hne : filt.Nonempty then some (sl.slotId, hne.choose) else none
      let cmds :=
        (delPairs.flatMap fun pair =>
          [PlannedMCCmd.deleteFromSlot pair.1 pair.2,
           PlannedMCCmd.payWork pair.1 dBud]) ++
        [PlannedMCCmd.finishUpdate]
      (oldMetas, cmds)
  | .query _ =>
      let H := tbl1.nextLifetime
      let sids := (oldMetas.filter (fun m => decide (ServingMC H m.k m.j))).map MCSlotMeta.slotId
      (oldMetas, [PlannedMCCmd.finishQuery sids])

/-- Intentionally mismatched terminal command causing `runMCHostedStepFuel` to return `none`. -/
def abortMCCmd {ι : Type} {d_s : ℕ}
    (op : UL.DynamicSearchOp ι d_s) (metas : List MCSlotMeta) :
    UL.MCWrapperCmd ι d_s (MCCtrlState ι d_s) :=
  match op with
  | .query _ => .finishUpdate { metas := metas, queue := none }
  | _ => .finishQuery [] { metas := metas, queue := none }

def dispatchMCQueue {ι : Type} {d_s : ℕ}
    (op : UL.DynamicSearchOp ι d_s) (metas : List MCSlotMeta) :
    List (PlannedMCCmd ι d_s) → UL.MCWrapperCmd ι d_s (MCCtrlState ι d_s)
  | [] => abortMCCmd op metas
  | .openSlot gen :: rest => .openSlot gen { metas := metas, queue := some rest }
  | .deleteFromSlot sid rec :: rest => .deleteFromSlot sid rec { metas := metas, queue := some rest }
  | .payWork sid budget :: rest => .payWork sid budget { metas := metas, queue := some rest }
  | .retireSlot sid :: rest => .retireSlot sid { metas := metas, queue := some rest }
  | .finishUpdate :: _ => .finishUpdate { metas := metas, queue := none }
  | .finishQuery sids :: _ => .finishQuery sids { metas := metas, queue := none }

noncomputable def mcStepCtrl {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (θ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I)
    (op : UL.DynamicSearchOp ι d_s) (ctrl : MCCtrlState ι d_s)
    (tbl : UL.HostedMCTable ι d_s B I) :
    UL.MCWrapperCmd ι d_s (MCCtrlState ι d_s) :=
  open Classical in
  if ValidMCTable n h mkMC tbl then
    match ctrl.queue with
    | some cmds => dispatchMCQueue op ctrl.metas cmds
    | none =>
        let (nextMetas, cmds) := planMCStep n pts h h_pos h_lt_one θ facs op ctrl.metas tbl
        dispatchMCQueue op nextMetas cmds
  else
    abortMCCmd op ctrl.metas

def mcFuelBound (M : ℕ) : ℕ :=
  10 * (Nat.log 2 M + 1) + 5

noncomputable def mcController {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s))
    (h : ℝ) (h_pos : 0 < h) (h_lt_one : h < 1)
    (θ : ℝ) (facs : UL.BirthPoolPolyFactors)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I) :
    UL.MCHostedController ι d_s B I (MCCtrlState ι d_s) where
  initCtrl := { metas := [], queue := none }
  fuelBound := mcFuelBound
  stepCtrl := mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC

/-! ### 2. Universal Prefix-Freeness (Including Unreachable States) -/

theorem isPrefixFree_runMCHostedStepFuel {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s) :
    ∀ (fuel : ℕ) (ctrl : MCCtrlState ι d_s) (tbl : UL.HostedMCTable ι d_s B I) (accWork peakSp : ℕ),
      IsPrefixFree (fun bs =>
        UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
          extHist op fuel ctrl tbl bs accWork peakSp) := by
  intro fuel
  induction fuel with
  | zero =>
    intro _ _ _ _
    exact isPrefixFree_none
  | succ fuel ih =>
    intro ctrl tbl accWork peakSp
    by_cases hv : ValidMCTable n h mkMC tbl
    · unfold UL.runMCHostedStepFuel
      cases hcmd : mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC op ctrl tbl with
      | openSlot gen ctrl' =>
        dsimp only []
        split_ifs with hguard
        · rcases hguard with ⟨hm, hh, _, _⟩
          have hpf_build : IsPrefixFree ((mkMC gen).buildWithBits extHist) :=
            ((hMC gen hm hh).2 extHist).2.2.1.2.2.1
          intro bs₁ bs₂ o₁ o₂ h₁ h₂ hpref
          dsimp only [] at h₁ h₂
          cases hc₁ : UL.consumePrefixBits ((mkMC gen).buildWithBits extHist) bs₁ with
          | none => rw [hc₁] at h₁; simp at h₁
          | some p₁ =>
            rcases p₁ with ⟨bOut₁, rem₁⟩
            rw [hc₁] at h₁
            cases hc₂ : UL.consumePrefixBits ((mkMC gen).buildWithBits extHist) bs₂ with
            | none => rw [hc₂] at h₂; simp at h₂
            | some p₂ =>
              rcases p₂ with ⟨bOut₂, rem₂⟩
              rw [hc₂] at h₂
              rcases (consumePrefixBits_eq_some_iff hpf_build).mp hc₁ with ⟨u₁, rfl, hu₁⟩
              rcases (consumePrefixBits_eq_some_iff hpf_build).mp hc₂ with ⟨u₂, rfl, hu₂⟩
              rcases hpref with ⟨w, hw⟩
              rw [List.append_assoc] at hw
              rcases prefixFree_split_unique hpf_build hw.symm hu₂ hu₁ with ⟨rfl, hrem, rfl⟩
              rw [ih ctrl' _ _ _ rem₁ rem₂ o₁ o₂ h₁ h₂ ⟨w, hrem.symm⟩]
        · exact isPrefixFree_none
      | deleteFromSlot sid rec ctrl' =>
        dsimp only []
        cases hfind : tbl.slots.find? _ with
        | none => exact isPrefixFree_none
        | some sl =>
          dsimp only []
          have hsl_mem : sl ∈ tbl.slots := List.mem_of_find?_eq_some hfind
          split_ifs with hguard
          · rcases hv sl hsl_mem with ⟨hm, hh, _, ⟨birthHist, hval⟩⟩
            rcases hMC sl.gen hm hh with ⟨hgen_eq, hunif⟩
            have hsurv : (mkMC sl.gen).gen.IsSurvivingSubset sl.surviving := by
              unfold UL.SearchGeneration.IsSurvivingSubset
              rwa [hgen_eq]
            have hpf_del : IsPrefixFree
                ((mkMC sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.idxState rec) :=
              ((hunif birthHist).2.2.1.2.2.2.2.2.1
                extHist sl.bState sl.surviving sl.idxState rec hsurv hval hguard.1).1
            intro bs₁ bs₂ o₁ o₂ h₁ h₂ hpref
            dsimp only [] at h₁ h₂
            cases hc₁ : UL.consumePrefixBits
                ((mkMC sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.idxState rec) bs₁ with
            | none => rw [hc₁] at h₁; simp at h₁
            | some p₁ =>
              rcases p₁ with ⟨dOut₁, rem₁⟩
              rw [hc₁] at h₁
              cases hc₂ : UL.consumePrefixBits
                  ((mkMC sl.gen).deleteWithBits extHist sl.bState sl.surviving sl.idxState rec) bs₂ with
              | none => rw [hc₂] at h₂; simp at h₂
              | some p₂ =>
                rcases p₂ with ⟨dOut₂, rem₂⟩
                rw [hc₂] at h₂
                rcases (consumePrefixBits_eq_some_iff hpf_del).mp hc₁ with ⟨u₁, rfl, hu₁⟩
                rcases (consumePrefixBits_eq_some_iff hpf_del).mp hc₂ with ⟨u₂, rfl, hu₂⟩
                rcases hpref with ⟨w, hw⟩
                rw [List.append_assoc] at hw
                rcases prefixFree_split_unique hpf_del hw.symm hu₂ hu₁ with ⟨rfl, hrem, rfl⟩
                rw [ih ctrl' _ _ _ rem₁ rem₂ o₁ o₂ h₁ h₂ ⟨w, hrem.symm⟩]
          · exact isPrefixFree_none
      | payWork sid budget ctrl' =>
        dsimp only []
        cases tbl.slots.find? _ with
        | none => exact isPrefixFree_none
        | some _ => exact ih ctrl' _ _ _
      | retireSlot sid ctrl' =>
        exact ih ctrl' _ _ _
      | finishUpdate ctrl' =>
        intro bs₁ bs₂ o₁ o₂ h₁ h₂ _
        cases op <;> simp at h₁ h₂
        all_goals
          have e₁ : bs₁ = [] := by
            cases bs₁ with
            | nil => rfl
            | cons _ _ => simp at h₁
          have e₂ : bs₂ = [] := by
            cases bs₂ with
            | nil => rfl
            | cons _ _ => simp at h₂
          rw [e₁, e₂]
      | finishQuery sids ctrl' =>
        intro bs₁ bs₂ o₁ o₂ h₁ h₂ _
        cases op with
        | insert _ => simp at h₁
        | delete _ => simp at h₁
        | query q =>
          dsimp only [] at h₁ h₂
          have e₁ : bs₁ = [] := by
            cases bs₁ with
            | nil => rfl
            | cons _ _ => simp at h₁
          have e₂ : bs₂ = [] := by
            cases bs₂ with
            | nil => rfl
            | cons _ _ => simp at h₂
          rw [e₁, e₂]
    · have habort : mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC op ctrl tbl =
          abortMCCmd op ctrl.metas := by
        unfold mcStepCtrl
        simp [hv]
      intro bs₁ bs₂ o₁ o₂ h₁ _ _
      unfold UL.runMCHostedStepFuel at h₁
      rw [habort] at h₁
      cases op <;> simp [abortMCCmd] at h₁

theorem isPrefixFree_mcDynIdx {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_fail : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (hMC : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkMC gen).gen = gen ∧
        UL.SatisfiesMonteCarloBirthPoolUniform n σ θ δ_fail facs (mkMC gen))
    (extHist : UL.ExecutionHistory d) (S : Finset ι)
    (st : MCCtrlState ι d_s × UL.HostedMCTable ι d_s B I)
    (op : UL.DynamicSearchOp ι d_s) :
    let dynIdx := (mcController n pts h h_pos h_lt_one θ facs mkMC).toDynamicSearchIndex n pts h mkMC
    ∀ bs₁ bs₂ out₁ out₂,
      dynIdx.stepWithBits extHist S st op bs₁ = some out₁ →
      dynIdx.stepWithBits extHist S st op bs₂ = some out₂ →
      bs₁ <+: bs₂ → bs₁ = bs₂ := by
  dsimp only [UL.MCHostedController.toDynamicSearchIndex, mcController]
  split_ifs
  · intro bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
    exact isPrefixFree_runMCHostedStepFuel hMC extHist op _ _ _ _ _ bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
  · intro _ _ _ _ h₁; simp at h₁

/-! ### 3. Slot Lookup, Space Bounds, and Table Invariant -/

theorem find?_slotId_of_nodup {ι : Type} {d_s : ℕ} {B I : Type}
    {slots : List (UL.HostedMCSlot ι d_s B I)}
    (hnodup : (slots.map UL.HostedMCSlot.slotId).Nodup)
    {sl : UL.HostedMCSlot ι d_s B I} (hmem : sl ∈ slots)
    (p : UL.HostedMCSlot ι d_s B I → Bool)
    (hp : ∀ s ∈ slots, (p s = true ↔ s.slotId = sl.slotId)) :
    slots.find? p = some sl := by
  induction slots with
  | nil => simp at hmem
  | cons hd tl ih =>
    rw [List.map_cons, List.nodup_cons] at hnodup
    rcases List.mem_cons.mp hmem with h_eq | htl
    · subst h_eq
      have hpt : p sl = true := (hp sl (by simp)).mpr rfl
      simp [hpt]
    · have hne : hd.slotId ≠ sl.slotId := fun heq =>
        hnodup.1 (heq ▸ List.mem_map_of_mem htl)
      have hpf : p hd = false := Bool.eq_false_iff.mpr fun ht =>
        hne ((hp hd (by simp)).mp ht)
      simp only [List.find?_cons, hpf]
      exact ih hnodup.2 htl (fun s hs => hp s (by simp [hs]))

theorem eq_of_mem_of_slotId_eq {ι : Type} {d_s : ℕ} {B I : Type}
    {slots : List (UL.HostedMCSlot ι d_s B I)}
    (hnodup : (slots.map UL.HostedMCSlot.slotId).Nodup)
    {s₁ s₂ : UL.HostedMCSlot ι d_s B I} (h₁ : s₁ ∈ slots) (h₂ : s₂ ∈ slots)
    (heq : s₁.slotId = s₂.slotId) : s₁ = s₂ := by
  induction slots with
  | nil => simp at h₁
  | cons hd tl ih =>
    rw [List.map_cons, List.nodup_cons] at hnodup
    rcases List.mem_cons.mp h₁ with h1 | h1 <;> rcases List.mem_cons.mp h₂ with h2 | h2
    · exact h1.trans h2.symm
    · exfalso
      subst h1
      exact hnodup.1 (heq ▸ List.mem_map_of_mem h2)
    · exfalso
      subst h2
      exact hnodup.1 (heq.symm ▸ List.mem_map_of_mem h1)
    · exact ih hnodup.2 h1 h2

/-- Per-slot invariant at active set `active` and target scheduled clock `targetClock`. -/
def MCSlotInv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h σ θ : ℝ)
    (facs : UL.BirthPoolPolyFactors)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I)
    (active : Finset (ι × ℕ)) (targetClock : ℕ)
    (m : MCSlotMeta) (sl : UL.HostedMCSlot ι d_s B I) : Prop :=
  m.slotId = sl.slotId ∧
  1 ≤ sl.gen.m ∧ sl.gen.m ≤ n ∧
  sl.gen.h = h ∧
  (∀ p ∈ sl.gen.P₀, sl.gen.pts p = pts p.1) ∧
  sl.surviving = active.filter (fun p => m.j * 2 ^ m.k ≤ p.2 ∧ p.2 < (m.j + 1) * 2 ^ m.k) ∧
  sl.surviving ⊆ sl.gen.P₀ ∧
  (∃ birthHist, (mkMC sl.gen).IsValidState birthHist sl.bState sl.surviving sl.idxState) ∧
  sl.unpaidWork ≤ ((m.j + 2) * 2 ^ m.k - targetClock) * unitBuildBudget n θ facs ∧
  (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ

/-- Quiescent invariant on `(S, st = (ctrl, tbl))` between dynamic operations. -/
structure MCTableInv {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h σ θ : ℝ)
    (facs : UL.BirthPoolPolyFactors)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I)
    (S : Finset ι) (ctrl : MCCtrlState ι d_s) (tbl : UL.HostedMCTable ι d_s B I) : Prop where
  queue_none : ctrl.queue = none
  img_eq : tbl.activeLifetimes.image Prod.fst = S
  card_eq : tbl.activeLifetimes.card = S.card
  card_le_n : S.card ≤ n
  life_valid : ∀ r ∈ tbl.activeLifetimes, r.2 < tbl.nextLifetime ∧ UL.IsUnitVec (pts r.1)
  inj_snd : ∀ r₁ ∈ tbl.activeLifetimes, ∀ r₂ ∈ tbl.activeLifetimes, r₁.2 = r₂.2 → r₁ = r₂
  sid_lt : ∀ sl ∈ tbl.slots, sl.slotId < tbl.nextSlotId
  sid_nodup : (tbl.slots.map UL.HostedMCSlot.slotId).Nodup
  kj_nodup : (ctrl.metas.map (fun m => (m.k, m.j))).Nodup
  kj_live : ∀ k j, (k, j) ∈ ctrl.metas.map (fun m => (m.k, m.j)) ↔ LiveMC tbl.nextLifetime k j
  slots_rel :
    List.Forall₂
      (MCSlotInv n pts h σ θ facs mkMC tbl.activeLifetimes (tbl.nextLifetime + 1))
      ctrl.metas tbl.slots

theorem mcTableInv_empty {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    (n : ℕ) (pts : ι → EuclideanSpace ℝ (Fin d_s)) (h σ θ : ℝ)
    (facs : UL.BirthPoolPolyFactors)
    (mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I) :
    MCTableInv n pts h σ θ facs mkMC ∅
      { metas := [], queue := none }
      (UL.HostedMCTable.empty ι d_s B I) where
  queue_none := rfl
  img_eq := by simp [UL.HostedMCTable.empty]
  card_eq := by simp [UL.HostedMCTable.empty]
  card_le_n := Nat.zero_le n
  life_valid := by simp [UL.HostedMCTable.empty]
  inj_snd := by simp [UL.HostedMCTable.empty]
  sid_lt := by simp [UL.HostedMCTable.empty]
  sid_nodup := by simp [UL.HostedMCTable.empty]
  kj_nodup := by simp
  kj_live := by
    intro k j
    simp only [List.map_nil, List.not_mem_nil, false_iff, UL.HostedMCTable.empty]
    intro hlive
    have := liveMC_imp_two_pow_le hlive
    have hpos := Nat.two_pow_pos k
    omega
  slots_rel := List.Forall₂.nil

theorem validMCTable_of_forall₂ {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)} {h σ θ : ℝ}
    {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    {active : Finset (ι × ℕ)} {tc : ℕ} {metas : List MCSlotMeta}
    {tbl : UL.HostedMCTable ι d_s B I}
    (hrel : List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC active tc) metas tbl.slots) :
    ValidMCTable n h mkMC tbl := by
  have haux : ∀ (ms : List MCSlotMeta) (sls : List (UL.HostedMCSlot ι d_s B I)),
      List.Forall₂ (MCSlotInv n pts h σ θ facs mkMC active tc) ms sls →
      ∀ sl ∈ sls,
        sl.gen.m ≤ n ∧ sl.gen.h = h ∧ sl.surviving ⊆ sl.gen.P₀ ∧
        ∃ birthHist, (mkMC sl.gen).IsValidState birthHist sl.bState sl.surviving sl.idxState := by
    intro ms sls hr
    induction hr with
    | nil => intro _ h; simp at h
    | cons hhead _ ih =>
      intro sl hsl
      rcases List.mem_cons.mp hsl with h_eq | htl
      · subst h_eq
        exact ⟨hhead.2.2.1, hhead.2.2.2.1, hhead.2.2.2.2.2.2.1, hhead.2.2.2.2.2.2.2.1⟩
      · exact ih sl htl
  exact haux metas tbl.slots hrel

theorem metas_length_le_of_live {metas : List MCSlotMeta} {H : ℕ}
    (hnodup : (metas.map (fun m => (m.k, m.j))).Nodup)
    (hlive : ∀ k j, (k, j) ∈ metas.map (fun m => (m.k, m.j)) → LiveMC H k j) :
    metas.length ≤ 3 * (Nat.log 2 H + 1) := by
  let pairs := metas.map (fun m => (m.k, m.j))
  have hsub : pairs.toFinset ⊆ livePairsMC H := by
    intro p hp
    rw [List.mem_toFinset] at hp
    rw [← Prod.eta p, mem_livePairsMC_iff]
    exact hlive p.1 p.2 (by rw [Prod.eta]; exact hp)
  calc
    metas.length = pairs.length := (List.length_map _).symm
    _ = pairs.toFinset.card := (List.toFinset_card_of_nodup hnodup).symm
    _ ≤ (livePairsMC H).card := Finset.card_le_card hsub
    _ ≤ 3 * (Nat.log 2 H + 1) := card_livePairsMC_le H

theorem list_sum_le_length_mul :
    ∀ (l : List ℕ) (B : ℝ), (∀ x ∈ l, (x : ℝ) ≤ B) → 0 ≤ B →
      ((l.sum : ℕ) : ℝ) ≤ (l.length : ℝ) * B
  | [], _, _, _ => by simp
  | x :: xs, B, hx, hB => by
    simp only [List.sum_cons, List.length_cons, Nat.cast_add, Nat.cast_one]
    have h1 : (x : ℝ) ≤ B := hx x (by simp)
    have h2 : ((xs.sum : ℕ) : ℝ) ≤ (xs.length : ℝ) * B :=
      list_sum_le_length_mul xs B (fun y hy => hx y (by simp [hy])) hB
    linarith

theorem currentSpace_le_of_slot_bounds {ι : Type} {d_s : ℕ} {B I : Type}
    {n K : ℕ} {σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hn : 2 ≤ n) (hσ : 0 ≤ σ) (hfacs : facs.Valid)
    {tbl : UL.HostedMCTable ι d_s B I}
    (hact : tbl.activeLifetimes.card ≤ n)
    (hslots_len : tbl.slots.length ≤ K)
    (halloc : ∀ sl ∈ tbl.slots, (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ) :
    (tbl.currentSpace : ℝ) ≤ (1 + 2 * (K : ℝ)) * facs.spaceBound n σ := by
  unfold UL.HostedMCTable.currentSpace
  rw [Nat.cast_add]
  have hsp_ge1 : 1 ≤ facs.spaceBound n σ := spaceBound_ge_one hn hσ hfacs
  have hn_le_sp : (n : ℝ) ≤ facs.spaceBound n σ := by
    unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
    have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
    have hrp : (n : ℝ) ^ (1 : ℝ) ≤ (n : ℝ) ^ (1 + σ) :=
      Real.rpow_le_rpow_of_exponent_le hn1 (by linarith)
    rw [Real.rpow_one] at hrp
    have hPs : 1 ≤ facs.P_space := hfacs.2.1
    nlinarith
  have hact_real : (tbl.activeLifetimes.card : ℝ) ≤ facs.spaceBound n σ :=
    (by exact_mod_cast hact : (tbl.activeLifetimes.card : ℝ) ≤ (n : ℝ)).trans hn_le_sp
  have hsum_real : (((tbl.slots.map UL.HostedMCSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
      (tbl.slots.length : ℝ) * (2 * facs.spaceBound n σ) := by
    have hlen : (tbl.slots.map UL.HostedMCSlot.spaceAlloc).length = tbl.slots.length :=
      List.length_map _
    rw [← hlen]
    refine list_sum_le_length_mul _ _ (fun x hx => ?_) (by linarith)
    rcases List.mem_map.mp hx with ⟨sl, hsl, rfl⟩
    exact halloc sl hsl
  have hK_real : (tbl.slots.length : ℝ) ≤ (K : ℝ) := by exact_mod_cast hslots_len
  nlinarith

theorem list_sum_map_filter_le {α : Type*} (f : α → ℕ) (p : α → Bool) :
    ∀ l : List α, ((l.filter p).map f).sum ≤ (l.map f).sum
  | [] => le_rfl
  | x :: xs => by
    simp only [List.filter_cons, List.map_cons, List.sum_cons]
    split_ifs
    · simp only [List.map_cons, List.sum_cons]
      exact Nat.add_le_add_left (list_sum_map_filter_le f p xs) _
    · exact (list_sum_map_filter_le f p xs).trans (Nat.le_add_left _ _)

/-! ### 4. Deterministic Retirement & Work-Payment Queue Execution -/

noncomputable def applyRetireIds {ι : Type} {d_s : ℕ} {B I : Type} :
    List ℕ → List (UL.HostedMCSlot ι d_s B I) → List (UL.HostedMCSlot ι d_s B I)
  | [], sls => sls
  | rid :: rids, sls =>
      open Classical in
      applyRetireIds rids (sls.filter (fun s => s.slotId ≠ rid))

theorem mem_applyRetireIds_iff {ι : Type} {d_s : ℕ} {B I : Type} :
    ∀ (rids : List ℕ) (sls : List (UL.HostedMCSlot ι d_s B I)) (sl : UL.HostedMCSlot ι d_s B I),
      sl ∈ applyRetireIds rids sls ↔ sl ∈ sls ∧ sl.slotId ∉ rids
  | [], sls, sl => by simp [applyRetireIds]
  | rid :: rids, sls, sl => by
    simp only [applyRetireIds, mem_applyRetireIds_iff rids, List.mem_filter, List.mem_cons, not_or]
    constructor
    · rintro ⟨⟨hsl, hne⟩, hnmem⟩
      exact ⟨hsl, by simpa using hne, hnmem⟩
    · rintro ⟨hsl, hne, hnmem⟩
      exact ⟨⟨hsl, by simpa using hne⟩, hnmem⟩

theorem runRetireQueue_eq {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s)
    (metas : List MCSlotMeta) :
    ∀ (rids : List ℕ) (rest : List (PlannedMCCmd ι d_s)) (fuel : ℕ)
      (tbl : UL.HostedMCTable ι d_s B I) (bs : List Bool) (accWork peakSp : ℕ),
      ValidMCTable n h mkMC tbl →
      tbl.currentSpace ≤ peakSp →
      UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
        extHist op (rids.length + fuel)
        { metas := metas, queue := some ((rids.map PlannedMCCmd.retireSlot) ++ rest) }
        tbl bs accWork peakSp =
      UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
        extHist op fuel
        { metas := metas, queue := some rest }
        { tbl with slots := applyRetireIds rids tbl.slots }
        bs (accWork + rids.length) peakSp := by
  intro rids
  induction rids with
  | nil =>
    intro rest fuel tbl bs accWork peakSp _ _
    simp [applyRetireIds]
  | cons rid rids ih =>
    intro rest fuel tbl bs accWork peakSp hv hsp
    have hlen : (rid :: rids).length + fuel = (rids.length + fuel) + 1 := by simp; omega
    rw [hlen]
    conv_lhs => unfold UL.runMCHostedStepFuel
    have hcmd : mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC op
        { metas := metas, queue := some ((rid :: rids).map PlannedMCCmd.retireSlot ++ rest) } tbl =
        .retireSlot rid { metas := metas, queue := some (rids.map PlannedMCCmd.retireSlot ++ rest) } := by
      unfold mcStepCtrl
      simp [hv, dispatchMCQueue]
    rw [hcmd]
    dsimp only []
    set tbl' : UL.HostedMCTable ι d_s B I :=
      open Classical in { tbl with slots := tbl.slots.filter (fun s => s.slotId ≠ rid) }
    have hv' : ValidMCTable n h mkMC tbl' := by
      intro sl hsl
      exact hv sl (List.mem_of_mem_filter hsl)
    have hsp_le : tbl'.currentSpace ≤ tbl.currentSpace := by
      unfold UL.HostedMCTable.currentSpace
      exact Nat.add_le_add_left (list_sum_map_filter_le _ _ tbl.slots) _
    have hmax : max peakSp tbl'.currentSpace = peakSp :=
      Nat.max_eq_left (hsp_le.trans hsp)
    rw [hmax, ih rest fuel tbl' bs (accWork + 1) peakSp hv' (hsp_le.trans hsp)]
    have hacc : accWork + 1 + rids.length = accWork + (rid :: rids).length := by simp; omega
    rw [hacc]
    rfl

/-- Slot-by-slot relation after running a `payWork` queue with budget `budget` on `pids`. -/
def PaySlotRel {ι : Type} {d_s : ℕ} {B I : Type}
    (pids : List ℕ) (budget : ℕ)
    (sl sl' : UL.HostedMCSlot ι d_s B I) : Prop :=
  sl'.slotId = sl.slotId ∧
  sl'.gen = sl.gen ∧
  sl'.bState = sl.bState ∧
  sl'.surviving = sl.surviving ∧
  sl'.idxState = sl.idxState ∧
  sl'.spaceAlloc = sl.spaceAlloc ∧
  sl'.unpaidWork ≤ sl.unpaidWork ∧
  (sl.slotId ∈ pids → sl'.unpaidWork ≤ sl.unpaidWork - budget)

theorem forall₂_paySlotRel_map_slotId {ι : Type} {d_s : ℕ} {B I : Type}
    {pids : List ℕ} {budget : ℕ}
    {sls sls' : List (UL.HostedMCSlot ι d_s B I)}
    (hrel : List.Forall₂ (PaySlotRel pids budget) sls sls') :
    sls'.map UL.HostedMCSlot.slotId = sls.map UL.HostedMCSlot.slotId := by
  induction hrel with
  | nil => rfl
  | cons hh _ ih => simp [hh.1, ih]

theorem forall₂_paySlotRel_map_spaceAlloc {ι : Type} {d_s : ℕ} {B I : Type}
    {pids : List ℕ} {budget : ℕ}
    {sls sls' : List (UL.HostedMCSlot ι d_s B I)}
    (hrel : List.Forall₂ (PaySlotRel pids budget) sls sls') :
    sls'.map UL.HostedMCSlot.spaceAlloc = sls.map UL.HostedMCSlot.spaceAlloc := by
  induction hrel with
  | nil => rfl
  | cons hh _ ih => simp [hh.2.2.2.2.2.1, ih]

theorem forall₂_paySlotRel_valid {ι : Type} {d d_s : ℕ} {B I : Type}
    {n : ℕ} {h : ℝ}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    {pids : List ℕ} {budget : ℕ}
    {tbl : UL.HostedMCTable ι d_s B I} {sls' : List (UL.HostedMCSlot ι d_s B I)}
    (hv : ValidMCTable n h mkMC tbl)
    (hrel : List.Forall₂ (PaySlotRel pids budget) tbl.slots sls') :
    ValidMCTable n h mkMC { tbl with slots := sls' } := by
  have haux : ∀ (sls sls' : List (UL.HostedMCSlot ι d_s B I)),
      List.Forall₂ (PaySlotRel pids budget) sls sls' →
      (∀ s ∈ sls, s.gen.m ≤ n ∧ s.gen.h = h ∧ s.surviving ⊆ s.gen.P₀ ∧
        ∃ birthHist, (mkMC s.gen).IsValidState birthHist s.bState s.surviving s.idxState) →
      ∀ sl' ∈ sls',
        sl'.gen.m ≤ n ∧ sl'.gen.h = h ∧ sl'.surviving ⊆ sl'.gen.P₀ ∧
        ∃ birthHist, (mkMC sl'.gen).IsValidState birthHist sl'.bState sl'.surviving sl'.idxState := by
    intro sls sls' hr
    induction hr with
    | nil => intro _ _ h; simp at h
    | @cons s₀ s₀' _ _ hh _ ih =>
      intro hv_cur sl' hsl'
      rcases List.mem_cons.mp hsl' with h_eq | htl
      · subst h_eq
        rcases hv_cur s₀ (by simp) with ⟨hm, hh_eq, hsub, hb⟩
        rcases hh with ⟨_, hgen, hbS, hsurv, hidx, _, _, _⟩
        rw [hgen, hbS, hsurv, hidx]
        exact ⟨hm, hh_eq, hsub, hb⟩
      · exact ih (fun s hs => hv_cur s (by simp [hs])) _ htl
  exact haux tbl.slots sls' hrel hv

theorem forall₂_paySlotRel_allGood {ι : Type} {d d_s : ℕ} {B I : Type}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    {pids : List ℕ} {budget : ℕ}
    {tbl : UL.HostedMCTable ι d_s B I} {sls' : List (UL.HostedMCSlot ι d_s B I)}
    (hg : AllSlotsGood mkMC tbl)
    (hrel : List.Forall₂ (PaySlotRel pids budget) tbl.slots sls') :
    AllSlotsGood mkMC { tbl with slots := sls' } := by
  have haux : ∀ (sls sls' : List (UL.HostedMCSlot ι d_s B I)),
      List.Forall₂ (PaySlotRel pids budget) sls sls' →
      (∀ s ∈ sls, GoodMCSlot mkMC s) →
      ∀ sl' ∈ sls', GoodMCSlot mkMC sl' := by
    intro sls sls' hr
    induction hr with
    | nil => intro _ _ h; simp at h
    | @cons s₀ s₀' _ _ hh _ ih =>
      intro hg_cur sl' hsl'
      rcases List.mem_cons.mp hsl' with h_eq | htl
      · subst h_eq
        rcases hg_cur s₀ (by simp) with ⟨bh, hbs, hval⟩
        rcases hh with ⟨_, hgen, hbS, hsurv, hidx, _, _, _⟩
        unfold GoodMCSlot
        rw [hgen, hbS, hsurv, hidx]
        exact ⟨bh, hbs, hval⟩
      · exact ih (fun s hs => hg_cur s (by simp [hs])) _ htl
  exact haux tbl.slots sls' hrel hg

theorem runPayQueue_exists {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s)
    (metas : List MCSlotMeta) (budget : ℕ) :
    ∀ (pids : List ℕ) (rest : List (PlannedMCCmd ι d_s)) (fuel : ℕ)
      (tbl : UL.HostedMCTable ι d_s B I) (bs : List Bool) (accWork peakSp : ℕ),
      ValidMCTable n h mkMC tbl →
      (tbl.slots.map UL.HostedMCSlot.slotId).Nodup →
      tbl.currentSpace ≤ peakSp →
      (∀ sid ∈ pids, sid ∈ tbl.slots.map UL.HostedMCSlot.slotId) →
      ∃ (paidWork : ℕ) (slots' : List (UL.HostedMCSlot ι d_s B I)),
        paidWork ≤ pids.length * (budget + 1) ∧
        List.Forall₂ (PaySlotRel pids budget) tbl.slots slots' ∧
        UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
          extHist op (pids.length + fuel)
          { metas := metas, queue := some ((pids.map (fun sid => PlannedMCCmd.payWork sid budget)) ++ rest) }
          tbl bs accWork peakSp =
        UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
          extHist op fuel
          { metas := metas, queue := some rest }
          { tbl with slots := slots' }
          bs (accWork + paidWork) peakSp := by
  intro pids
  induction pids with
  | nil =>
    intro rest fuel tbl bs accWork peakSp _ _ _ _
    refine ⟨0, tbl.slots, by simp, ?_, by simp⟩
    suffices hrefl : ∀ l : List (UL.HostedMCSlot ι d_s B I),
        List.Forall₂ (PaySlotRel [] budget) l l from hrefl tbl.slots
    intro l
    induction l with
    | nil => exact List.Forall₂.nil
    | cons x xs ihx =>
      exact List.Forall₂.cons ⟨rfl, rfl, rfl, rfl, rfl, rfl, le_rfl, fun h => by simp at h⟩ ihx
  | cons pid pids ih =>
    intro rest fuel tbl bs accWork peakSp hv hnodup hsp hmem_pids
    rcases List.mem_map.mp (hmem_pids pid (by simp)) with ⟨sl, hsl_mem, hsl_id⟩
    have hcmd : mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC op
        { metas := metas, queue := some (((pid :: pids).map (fun sid => PlannedMCCmd.payWork sid budget)) ++ rest) } tbl =
        .payWork pid budget
          { metas := metas, queue := some ((pids.map (fun sid => PlannedMCCmd.payWork sid budget)) ++ rest) } := by
      unfold mcStepCtrl
      simp [hv, dispatchMCQueue]
    have hfind : (open Classical in tbl.slots.find? (fun s => s.slotId = pid)) = some sl := by
      refine find?_slotId_of_nodup hnodup hsl_mem _ (fun s _ => ?_)
      rw [decide_eq_true_eq, hsl_id]
    let paid := min budget sl.unpaidWork
    let sl₁ : UL.HostedMCSlot ι d_s B I := { sl with unpaidWork := sl.unpaidWork - paid }
    let slots₁ : List (UL.HostedMCSlot ι d_s B I) :=
      open Classical in tbl.slots.map (fun s => if s.slotId = pid then sl₁ else s)
    let tbl₁ : UL.HostedMCTable ι d_s B I := { tbl with slots := slots₁ }
    have hrel₁ : List.Forall₂ (PaySlotRel [pid] budget) tbl.slots slots₁ := by
      suffices haux : ∀ l : List (UL.HostedMCSlot ι d_s B I),
          (∀ s ∈ l, s ∈ tbl.slots) →
          List.Forall₂ (PaySlotRel [pid] budget) l
            (open Classical in l.map (fun s => if s.slotId = pid then sl₁ else s)) from
        haux tbl.slots (fun _ hs => hs)
      intro l hl
      induction l with
      | nil => exact List.Forall₂.nil
      | cons hd tl ihl =>
        simp only [List.map_cons]
        refine List.Forall₂.cons ?_ (ihl (fun s hs => hl s (by simp [hs])))
        classical
        by_cases heq : hd.slotId = pid
        · simp only [if_pos heq]
          have hhd_eq : hd = sl :=
            eq_of_mem_of_slotId_eq hnodup (hl hd (by simp)) hsl_mem (heq.trans hsl_id.symm)
          dsimp only [PaySlotRel, sl₁, paid]
          rw [hhd_eq]
          refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, Nat.sub_le _ _, fun _ => ?_⟩
          omega
        · simp only [if_neg heq]
          exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, le_rfl, fun hm => absurd (by simpa using hm) heq⟩
    have hv₁ : ValidMCTable n h mkMC tbl₁ := forall₂_paySlotRel_valid hv hrel₁
    have hmap_id₁ : tbl₁.slots.map UL.HostedMCSlot.slotId = tbl.slots.map UL.HostedMCSlot.slotId :=
      forall₂_paySlotRel_map_slotId hrel₁
    have hnodup₁ : (tbl₁.slots.map UL.HostedMCSlot.slotId).Nodup := by rwa [hmap_id₁]
    have hsp_eq₁ : tbl₁.currentSpace = tbl.currentSpace := by
      unfold UL.HostedMCTable.currentSpace
      change tbl.activeLifetimes.card + (slots₁.map UL.HostedMCSlot.spaceAlloc).sum = _
      rw [forall₂_paySlotRel_map_spaceAlloc hrel₁]
    have hmax₁ : max peakSp tbl₁.currentSpace = peakSp := by
      rw [hsp_eq₁]
      exact Nat.max_eq_left hsp
    have hstep₁ :
        UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
          extHist op ((pid :: pids).length + fuel)
          { metas := metas, queue := some (((pid :: pids).map (fun sid => PlannedMCCmd.payWork sid budget)) ++ rest) }
          tbl bs accWork peakSp =
        UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
          extHist op (pids.length + fuel)
          { metas := metas, queue := some ((pids.map (fun sid => PlannedMCCmd.payWork sid budget)) ++ rest) }
          tbl₁ bs (accWork + paid + 1) peakSp := by
      have hlen : (pid :: pids).length + fuel = (pids.length + fuel) + 1 := by simp; omega
      rw [hlen]
      conv_lhs => unfold UL.runMCHostedStepFuel
      rw [hcmd]
      dsimp only []
      rw [hfind]
      dsimp only []
      rw [hmax₁]
    have hmem_pids₁ : ∀ sid ∈ pids, sid ∈ tbl₁.slots.map UL.HostedMCSlot.slotId := by
      intro sid hsid
      rw [hmap_id₁]
      exact hmem_pids sid (by simp [hsid])
    rcases ih rest fuel tbl₁ bs (accWork + paid + 1) peakSp hv₁ hnodup₁
        (by rw [hsp_eq₁]; exact hsp) hmem_pids₁ with
      ⟨paidRest, slots', hpaid_le, hrel₂, hrun⟩
    refine ⟨paid + 1 + paidRest, slots', ?_, ?_, ?_⟩
    · have hp_le : paid ≤ budget := Nat.min_le_left _ _
      simp only [List.length_cons]
      calc paid + 1 + paidRest
        _ ≤ budget + 1 + pids.length * (budget + 1) := by omega
        _ = (pids.length + 1) * (budget + 1) := by ring
    · have hcomp : ∀ (l₀ l₁ l₂ : List (UL.HostedMCSlot ι d_s B I)),
          List.Forall₂ (PaySlotRel [pid] budget) l₀ l₁ →
          List.Forall₂ (PaySlotRel pids budget) l₁ l₂ →
          List.Forall₂ (PaySlotRel (pid :: pids) budget) l₀ l₂ := by
        intro l₀ l₁ l₂ hr₁ hr₂
        induction hr₁ generalizing l₂ with
        | nil =>
          cases hr₂
          exact List.Forall₂.nil
        | cons hh₁ _ ih_rel =>
          cases hr₂ with
          | cons hh₂ htl₂ =>
            refine List.Forall₂.cons ?_ (ih_rel _ htl₂)
            rcases hh₁ with ⟨hid₁, hg₁, hb₁, hs₁, hi₁, hsp₁, hun₁, hmem₁⟩
            rcases hh₂ with ⟨hid₂, hg₂, hb₂, hs₂, hi₂, hsp₂, hun₂, hmem₂⟩
            refine ⟨hid₂.trans hid₁, hg₂.trans hg₁, hb₂.trans hb₁, hs₂.trans hs₁,
              hi₂.trans hi₁, hsp₂.trans hsp₁, hun₂.trans hun₁, fun hm => ?_⟩
            rcases List.mem_cons.mp hm with h_eq | h_tl
            · exact hun₂.trans (hmem₁ (by simp [h_eq]))
            · have hsub := hmem₂ (by rwa [hid₁])
              omega
      exact hcomp tbl.slots slots₁ slots' hrel₁ hrel₂
    · rw [hstep₁, hrun]
      have hacc : accWork + paid + 1 + paidRest = accWork + (paid + 1 + paidRest) := by omega
      rw [hacc]

theorem runFinishUpdate_eq {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B I : Type}
    {n : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkMC : UL.SearchGeneration (ι × ℕ) d_s → UL.MonteCarloSearchGeneration (ι × ℕ) d d_s B I}
    (extHist : UL.ExecutionHistory d) (op : UL.DynamicSearchOp ι d_s)
    (hop : match op with | .query _ => False | _ => True)
    (metas : List MCSlotMeta) (fuel : ℕ)
    (tbl : UL.HostedMCTable ι d_s B I) (bs : List Bool) (accWork peakSp : ℕ)
    (hv : ValidMCTable n h mkMC tbl)
    (hsp : tbl.currentSpace ≤ peakSp) :
    UL.runMCHostedStepFuel n pts h mkMC (mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC)
      extHist op (fuel + 1)
      { metas := metas, queue := some [PlannedMCCmd.finishUpdate] }
      tbl bs accWork peakSp =
    endWithEmpty
      { nextState := ({ metas := metas, queue := none }, tbl)
        queryAnswer := none
        work := accWork + 1
        peakSpace := peakSp } bs := by
  unfold UL.runMCHostedStepFuel
  have hcmd : mcStepCtrl n pts h h_pos h_lt_one θ facs mkMC op
      { metas := metas, queue := some [PlannedMCCmd.finishUpdate] } tbl =
      .finishUpdate { metas := metas, queue := none } := by
    unfold mcStepCtrl
    simp [hv, dispatchMCQueue]
  rw [hcmd]
  have hmax : max peakSp tbl.currentSpace = peakSp := Nat.max_eq_left hsp
  cases op with
  | query _ => exact False.elim hop
  | insert _ => simp [endWithEmpty, hmax]
  | delete _ => simp [endWithEmpty, hmax]

end UL.Proof_lem_7_1_RaceV31
