import Mathlib
import UL.Stmt.lem_7_1
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. `bitListProb`, `prefixTraceProb`, and `Fin` `tsum` splitting -/

@[simp]
theorem bitListProb_nil : UL.bitListProb [] = 1 := by
  simp [UL.bitListProb]

theorem bitListProb_cons (b : Bool) (bs : List Bool) :
    UL.bitListProb (b :: bs) = (2 : ENNReal)⁻¹ * UL.bitListProb bs := by
  simp [UL.bitListProb, pow_succ, mul_comm]

theorem bitListProb_append (bs₁ bs₂ : List Bool) :
    UL.bitListProb (bs₁ ++ bs₂) = UL.bitListProb bs₁ * UL.bitListProb bs₂ := by
  simp [UL.bitListProb, pow_add]

theorem bitListProb_ne_zero (bs : List Bool) : UL.bitListProb bs ≠ 0 := by
  unfold UL.bitListProb
  exact pow_ne_zero _ (by simp)

theorem bitListProb_ne_top (bs : List Bool) : UL.bitListProb bs ≠ ⊤ := by
  unfold UL.bitListProb
  exact ENNReal.pow_ne_top (by simp)

theorem prefixTraceProb_zero (tr : Fin 0 → List Bool) : UL.prefixTraceProb tr = 1 := by
  simp [UL.prefixTraceProb]

theorem prefixTraceProb_cons {k : ℕ} (bs : List Bool) (tr : Fin k → List Bool) :
    UL.prefixTraceProb (Fin.cons bs tr) = UL.bitListProb bs * UL.prefixTraceProb tr := by
  unfold UL.prefixTraceProb
  rw [Fin.prod_univ_succ]
  simp

def finConsEquiv (k : ℕ) (α : Type*) : (α × (Fin k → α)) ≃ (Fin (k + 1) → α) where
  toFun p := Fin.cons p.1 p.2
  invFun f := (f 0, Fin.tail f)
  left_inv p := by ext <;> simp
  right_inv f := by simp

theorem tsum_fin_zero {α : Type*} (F : (Fin 0 → α) → ENNReal) :
    (∑' tr : Fin 0 → α, F tr) = F Fin.elim0 := by
  refine tsum_eq_single Fin.elim0 (fun f hf => ?_)
  exfalso
  apply hf
  funext i
  exact Fin.elim0 i

theorem tsum_fin_succ {k : ℕ} {α : Type*} (F : (Fin (k + 1) → α) → ENNReal) :
    (∑' tr : Fin (k + 1) → α, F tr) =
      ∑' x : α, ∑' rest : Fin k → α, F (Fin.cons x rest) := by
  rw [← (finConsEquiv k α).tsum_eq, ENNReal.tsum_prod']
  rfl

def finFunCongr {n m : ℕ} (h : n = m) (α : Type*) : (Fin n → α) ≃ (Fin m → α) where
  toFun f := f ∘ Fin.cast h.symm
  invFun g := g ∘ Fin.cast h
  left_inv f := by funext i; simp
  right_inv g := by funext i; simp

theorem prefixTraceProb_cast {n m : ℕ} (h : n = m) (tr : Fin n → List Bool) :
    UL.prefixTraceProb (finFunCongr h (List Bool) tr) = UL.prefixTraceProb tr := by
  subst h
  rfl

/-! ### 2. `IsPrefixFree`, `haltProb`, and `expWithBits` -/

def IsPrefixFree {α : Type*} (f : List Bool → Option α) : Prop :=
  ∀ bs₁ bs₂ : List Bool, ∀ a₁ a₂ : α,
    f bs₁ = some a₁ → f bs₂ = some a₂ → bs₁ <+: bs₂ → bs₁ = bs₂

theorem isPrefixFree_none {α : Type*} : IsPrefixFree (fun _ : List Bool => (none : Option α)) := by
  intro _ _ _ _ h; simp at h

noncomputable def haltProb {α : Type*} (f : List Bool → Option α) : ENNReal :=
  ∑' bs : List Bool, if (f bs).isSome then UL.bitListProb bs else 0

noncomputable def expWithBits {α : Type*} (f : List Bool → Option α) (W : α → ENNReal) : ENNReal :=
  ∑' bs : List Bool,
    match f bs with
    | some a => UL.bitListProb bs * W a
    | none => 0

theorem isPrefixFree_finset_sum_le_one :
    ∀ (N : ℕ) (s : Finset (List Bool)),
      (∀ bs ∈ s, bs.length ≤ N) →
      (∀ x ∈ s, ∀ y ∈ s, x <+: y → x = y) →
      ∑ bs ∈ s, UL.bitListProb bs ≤ 1 := by
  intro N
  induction N with
  | zero =>
    intro s hlen _
    have hsub : s ⊆ {[]} := by
      intro bs hbs
      have h0 : bs.length = 0 := Nat.eq_zero_of_le_zero (hlen bs hbs)
      rw [List.length_eq_zero_iff] at h0
      simp [h0]
    calc
      ∑ bs ∈ s, UL.bitListProb bs ≤ ∑ bs ∈ ({[]} : Finset (List Bool)), UL.bitListProb bs :=
        Finset.sum_le_sum_of_subset hsub
      _ = 1 := by simp [bitListProb_nil]
  | succ N ih =>
    intro s hlen hpf
    by_cases hnil : ([] : List Bool) ∈ s
    · have hsub : s ⊆ {[]} := by
        intro bs hbs
        have heq : [] = bs := hpf [] hnil bs hbs List.nil_prefix
        simp [heq.symm]
      calc
        ∑ bs ∈ s, UL.bitListProb bs ≤ ∑ bs ∈ ({[]} : Finset (List Bool)), UL.bitListProb bs :=
          Finset.sum_le_sum_of_subset hsub
        _ = 1 := by simp [bitListProb_nil]
    · let sF : Finset (List Bool) :=
        (s.filter (fun bs => bs.head? = some false)).image List.tail
      let sT : Finset (List Bool) :=
        (s.filter (fun bs => bs.head? = some true)).image List.tail
      have hsub_union : s ⊆ sF.image (List.cons false) ∪ sT.image (List.cons true) := by
        intro bs hbs
        cases bs with
        | nil => exact absurd hbs hnil
        | cons b tl =>
          cases b
          · apply Finset.mem_union_left
            exact Finset.mem_image.mpr ⟨tl,
              Finset.mem_image.mpr ⟨false :: tl, Finset.mem_filter.mpr ⟨hbs, rfl⟩, rfl⟩, rfl⟩
          · apply Finset.mem_union_right
            exact Finset.mem_image.mpr ⟨tl,
              Finset.mem_image.mpr ⟨true :: tl, Finset.mem_filter.mpr ⟨hbs, rfl⟩, rfl⟩, rfl⟩
      have hs_mem : ∀ (b : Bool), ∀ tl ∈ (s.filter (fun bs => bs.head? = some b)).image List.tail,
          (b :: tl) ∈ s := by
        intro b tl htl
        rcases Finset.mem_image.mp htl with ⟨bs, hbs, rfl⟩
        rcases Finset.mem_filter.mp hbs with ⟨hbs_s, hhead⟩
        cases bs with
        | nil => simp at hhead
        | cons b' tl' =>
          simp at hhead
          subst hhead
          exact hbs_s
      have hF_le : ∑ tl ∈ sF, UL.bitListProb tl ≤ 1 := by
        refine ih sF (fun tl htl => ?_) (fun x hx y hy hxy => ?_)
        · have := hlen (false :: tl) (hs_mem false tl htl); simpa using this
        · have := hpf (false :: x) (hs_mem false x hx) (false :: y) (hs_mem false y hy)
            (List.cons_prefix_cons.mpr ⟨rfl, hxy⟩)
          simpa using this
      have hT_le : ∑ tl ∈ sT, UL.bitListProb tl ≤ 1 := by
        refine ih sT (fun tl htl => ?_) (fun x hx y hy hxy => ?_)
        · have := hlen (true :: tl) (hs_mem true tl htl); simpa using this
        · have := hpf (true :: x) (hs_mem true x hx) (true :: y) (hs_mem true y hy)
            (List.cons_prefix_cons.mpr ⟨rfl, hxy⟩)
          simpa using this
      have hinj : ∀ b : Bool, Function.Injective (List.cons b) := fun _ _ _ h => by injection h
      calc
        ∑ bs ∈ s, UL.bitListProb bs
            ≤ ∑ bs ∈ sF.image (List.cons false) ∪ sT.image (List.cons true), UL.bitListProb bs :=
              Finset.sum_le_sum_of_subset hsub_union
        _ = (∑ bs ∈ sF.image (List.cons false), UL.bitListProb bs) +
              (∑ bs ∈ sT.image (List.cons true), UL.bitListProb bs) := by
              refine Finset.sum_union (Finset.disjoint_left.mpr fun z hzF hzT => ?_)
              rcases Finset.mem_image.mp hzF with ⟨_, _, rfl⟩
              rcases Finset.mem_image.mp hzT with ⟨_, _, hcontra⟩
              simp at hcontra
        _ = (2 : ENNReal)⁻¹ * ∑ tl ∈ sF, UL.bitListProb tl +
              (2 : ENNReal)⁻¹ * ∑ tl ∈ sT, UL.bitListProb tl := by
              rw [Finset.sum_image (fun _ _ _ _ h => hinj false h),
                  Finset.sum_image (fun _ _ _ _ h => hinj true h)]
              simp only [bitListProb_cons, Finset.mul_sum]
        _ ≤ (2 : ENNReal)⁻¹ * 1 + (2 : ENNReal)⁻¹ * 1 := by gcongr
        _ = 1 := by rw [mul_one, ENNReal.inv_two_add_inv_two]

theorem IsPrefixFree.haltProb_le_one {α : Type*} {f : List Bool → Option α}
    (hf : IsPrefixFree f) : haltProb f ≤ 1 := by
  unfold haltProb
  rw [ENNReal.tsum_eq_iSup_sum]
  refine iSup_le fun s => ?_
  classical
  let s' := s.filter (fun bs => (f bs).isSome)
  have heq : (∑ bs ∈ s, if (f bs).isSome then UL.bitListProb bs else 0) =
      ∑ bs ∈ s', UL.bitListProb bs := by
    rw [Finset.sum_filter]
  rw [heq]
  let N := s'.sup List.length
  refine isPrefixFree_finset_sum_le_one N s' (fun bs hbs => Finset.le_sup (f := List.length) hbs) ?_
  intro x hx y hy hxy
  rcases Option.isSome_iff_exists.mp (Finset.mem_filter.mp hx).2 with ⟨ax, hfx⟩
  rcases Option.isSome_iff_exists.mp (Finset.mem_filter.mp hy).2 with ⟨ay, hfy⟩
  exact hf x y ax ay hfx hfy hxy

theorem prefixFree_split_unique {α : Type*} {f : List Bool → Option α} (hf : IsPrefixFree f)
    {bs₁ bs₂ cs₁ cs₂ : List Bool} {a₁ a₂ : α}
    (heq : bs₁ ++ bs₂ = cs₁ ++ cs₂) (h₁ : f bs₁ = some a₁) (h₂ : f cs₁ = some a₂) :
    bs₁ = cs₁ ∧ bs₂ = cs₂ ∧ a₁ = a₂ := by
  have hbs_eq : bs₁ = cs₁ := by
    rcases List.append_eq_append_iff.mp heq with ⟨as, hcs, _⟩ | ⟨as, hbs, _⟩
    · exact hf bs₁ cs₁ a₁ a₂ h₁ h₂ ⟨as, hcs.symm⟩
    · exact (hf cs₁ bs₁ a₂ a₁ h₂ h₁ ⟨as, hbs.symm⟩).symm
  subst hbs_eq
  have hbs₂ : bs₂ = cs₂ := List.append_cancel_left heq
  subst hbs₂
  rw [h₁] at h₂
  injection h₂ with ha
  exact ⟨rfl, rfl, ha⟩

theorem expWithBits_congr {α : Type*} {f₁ f₂ : List Bool → Option α}
    (hf : ∀ bs, f₁ bs = f₂ bs) {W₁ W₂ : α → ENNReal}
    (hW : ∀ bs a, f₂ bs = some a → W₁ a = W₂ a) :
    expWithBits f₁ W₁ = expWithBits f₂ W₂ := by
  unfold expWithBits
  refine tsum_congr fun bs => ?_
  rw [hf bs]
  cases h : f₂ bs with
  | none => rfl
  | some a => dsimp only; rw [hW bs a h]

theorem expWithBits_mono {α : Type*} {f : List Bool → Option α} {W₁ W₂ : α → ENNReal}
    (hW : ∀ bs a, f bs = some a → W₁ a ≤ W₂ a) :
    expWithBits f W₁ ≤ expWithBits f W₂ := by
  unfold expWithBits
  refine ENNReal.tsum_le_tsum fun bs => ?_
  cases h : f bs with
  | none => exact le_rfl
  | some a => exact mul_le_mul_of_nonneg_left (hW bs a h) (zero_le _)

theorem expWithBits_zero {α : Type*} (f : List Bool → Option α) :
    expWithBits f (fun _ => 0) = 0 := by
  unfold expWithBits
  have : (fun bs => match f bs with | some _ => UL.bitListProb bs * 0 | none => (0 : ENNReal)) =
      fun _ => 0 := by ext bs; cases f bs <;> simp
  rw [this, tsum_zero]

theorem expWithBits_one_eq_haltProb {α : Type*} (f : List Bool → Option α) :
    expWithBits f (fun _ => 1) = haltProb f := by
  unfold expWithBits haltProb
  refine tsum_congr fun bs => ?_
  cases f bs <;> simp

theorem expWithBits_add {α : Type*} (f : List Bool → Option α) (W₁ W₂ : α → ENNReal) :
    expWithBits f (fun a => W₁ a + W₂ a) = expWithBits f W₁ + expWithBits f W₂ := by
  unfold expWithBits
  rw [← ENNReal.tsum_add]
  refine tsum_congr fun bs => ?_
  cases f bs with
  | none => simp
  | some _ => dsimp only; ring

theorem expWithBits_mul_const {α : Type*} (f : List Bool → Option α)
    (W : α → ENNReal) (C : ENNReal) :
    expWithBits f (fun a => W a * C) = expWithBits f W * C := by
  unfold expWithBits
  rw [← ENNReal.tsum_mul_right]
  refine tsum_congr fun bs => ?_
  cases f bs <;> simp [mul_assoc]

theorem expWithBits_const {α : Type*} (f : List Bool → Option α) (C : ENNReal) :
    expWithBits f (fun _ => C) = haltProb f * C := by
  have h1 : (fun _ : α => C) = fun _ => (1 : ENNReal) * C := by ext; simp
  rw [h1, expWithBits_mul_const, expWithBits_one_eq_haltProb]

theorem expWithBits_const_add_of_haltProb_one {α : Type*}
    {f : List Bool → Option α} (hf1 : haltProb f = 1) (C : ENNReal) (W : α → ENNReal) :
    expWithBits f (fun a => C + W a) = C + expWithBits f W := by
  rw [expWithBits_add, expWithBits_const, hf1, one_mul]

theorem expWithBits_add_const_of_haltProb_one {α : Type*}
    {f : List Bool → Option α} (hf1 : haltProb f = 1) (W : α → ENNReal) (C : ENNReal) :
    expWithBits f (fun a => W a + C) = expWithBits f W + C := by
  rw [expWithBits_add, expWithBits_const, hf1, one_mul]

/-! ### 3. `endWithEmpty`, `consumePrefixBits`, and `seqConsume` -/

def endWithEmpty {α : Type} (v : α) (bs : List Bool) : Option α :=
  if bs.isEmpty then some v else none

theorem endWithEmpty_eq_some_iff {α : Type} {v w : α} {bs : List Bool} :
    endWithEmpty v bs = some w ↔ bs = [] ∧ v = w := by
  unfold endWithEmpty
  cases bs <;> simp

theorem isPrefixFree_endWithEmpty {α : Type} (v : α) : IsPrefixFree (endWithEmpty v) := by
  intro bs₁ bs₂ w₁ w₂ h₁ h₂ _
  rw [(endWithEmpty_eq_some_iff.mp h₁).1, (endWithEmpty_eq_some_iff.mp h₂).1]

theorem expWithBits_endWithEmpty {α : Type} (v : α) (W : α → ENNReal) :
    expWithBits (endWithEmpty v) W = W v := by
  unfold expWithBits
  rw [tsum_eq_single []]
  · simp [endWithEmpty]
  · intro bs hbs
    cases bs with
    | nil => exact absurd rfl hbs
    | cons _ _ => simp [endWithEmpty]

theorem haltProb_endWithEmpty {α : Type} (v : α) : haltProb (endWithEmpty v) = 1 := by
  rw [← expWithBits_one_eq_haltProb, expWithBits_endWithEmpty]

private theorem filterMap_head?_of_unique {β : Type} (g : ℕ → Option β) (y : β) :
    ∀ (l : List ℕ) (k₀ : ℕ),
      k₀ ∈ l →
      g k₀ = some y →
      (∀ k ∈ l, k ≠ k₀ → g k = none) →
      (l.filterMap g).head? = some y := by
  intro l
  induction l with
  | nil =>
    intro _ hmem _ _
    simp at hmem
  | cons hd tl ih =>
    intro k₀ hmem hgk₀ hother
    by_cases hne : hd = k₀
    · subst hne
      simp [List.filterMap_cons, hgk₀]
    · have hnone : g hd = none := hother hd (by simp) hne
      have hmem_tl : k₀ ∈ tl := by
        rcases List.mem_cons.mp hmem with rfl | htl
        · exact absurd rfl hne
        · exact htl
      simp only [List.filterMap_cons, hnone]
      exact ih k₀ hmem_tl hgk₀ (fun k hk => hother k (by simp [hk]))

theorem consumePrefixBits_append_of_prefixFree {α : Type} {f : List Bool → Option α}
    (hf : IsPrefixFree f) {bs₁ rem : List Bool} {a : α} (hfa : f bs₁ = some a) :
    UL.consumePrefixBits f (bs₁ ++ rem) = some (a, rem) := by
  unfold UL.consumePrefixBits
  dsimp only
  let full := bs₁ ++ rem
  let g : ℕ → Option (α × List Bool) := fun k =>
    match f (full.take k) with
    | some v => some (v, full.drop k)
    | none => none
  change ((List.range (full.length + 1)).filterMap g).head? = some (a, rem)
  refine filterMap_head?_of_unique g (a, rem) (List.range (full.length + 1)) bs₁.length ?_ ?_ ?_
  · rw [List.mem_range]
    have : full.length = bs₁.length + rem.length := List.length_append
    omega
  · dsimp only [g, full]
    rw [List.take_append_of_le_length le_rfl, List.take_length,
        List.drop_append_of_le_length le_rfl, List.drop_length, List.nil_append, hfa]
  · intro k hk hne
    rw [List.mem_range] at hk
    dsimp only [g]
    cases hfk : f (full.take k) with
    | none => rfl
    | some v =>
      exfalso
      have hfull_len : full.length = bs₁.length + rem.length := List.length_append
      have hlen_take : (full.take k).length = k := List.length_take_of_le (by omega)
      rcases Nat.lt_or_gt_of_ne hne with hlt | hgt
      · have hpref : full.take k <+: bs₁ := by
          have h1 : full.take k = bs₁.take k := List.take_append_of_le_length (by omega)
          rw [h1]
          exact List.take_prefix k bs₁
        have heq := hf (full.take k) bs₁ v a hfk hfa hpref
        have := congrArg List.length heq
        omega
      · have hpref : bs₁ <+: full.take k := by
          have h1 : bs₁ = (full.take k).take bs₁.length := by
            rw [List.take_take, Nat.min_eq_left (by omega)]
            simp [full]
          rw [h1]
          exact List.take_prefix bs₁.length (full.take k)
        have heq := hf bs₁ (full.take k) a v hfa hfk hpref
        have := congrArg List.length heq
        omega

theorem consumePrefixBits_eq_some_iff {α : Type} {f : List Bool → Option α}
    (hf : IsPrefixFree f) {bs rem : List Bool} {a : α} :
    UL.consumePrefixBits f bs = some (a, rem) ↔
      ∃ bs₁ : List Bool, bs = bs₁ ++ rem ∧ f bs₁ = some a := by
  constructor
  · intro h
    unfold UL.consumePrefixBits at h
    dsimp only at h
    set g : ℕ → Option (α × List Bool) := fun k =>
      match f (bs.take k) with
      | some v => some (v, bs.drop k)
      | none => none
    change ((List.range (bs.length + 1)).filterMap g).head? = some (a, rem) at h
    cases hlist : (List.range (bs.length + 1)).filterMap g with
    | nil =>
      rw [hlist] at h
      simp at h
    | cons hd tl =>
      rw [hlist, List.head?_cons, Option.some.injEq] at h
      have hmem : (a, rem) ∈ (List.range (bs.length + 1)).filterMap g := by
        rw [hlist, ← h]
        simp
      rcases List.mem_filterMap.mp hmem with ⟨k, _, hk⟩
      dsimp only [g] at hk
      cases hfk : f (bs.take k) with
      | none => simp [hfk] at hk
      | some v =>
        simp only [hfk, Option.some.injEq, Prod.mk.injEq] at hk
        rcases hk with ⟨rfl, rfl⟩
        exact ⟨bs.take k, (List.take_append_drop k bs).symm, hfk⟩
  · rintro ⟨bs₁, rfl, hfa⟩
    exact consumePrefixBits_append_of_prefixFree hf hfa

noncomputable def seqConsume {α β : Type}
    (f : List Bool → Option α) (g : α → List Bool → Option β) (bs : List Bool) : Option β :=
  match UL.consumePrefixBits f bs with
  | none => none
  | some (a, rem') => g a rem'

theorem seqConsume_eq_some_iff {α β : Type} {f : List Bool → Option α}
    (hf : IsPrefixFree f) {g : α → List Bool → Option β} {bs : List Bool} {b : β} :
    seqConsume f g bs = some b ↔
      ∃ bs₁ bs₂ a, bs = bs₁ ++ bs₂ ∧ f bs₁ = some a ∧ g a bs₂ = some b := by
  unfold seqConsume
  constructor
  · intro h
    cases hc : UL.consumePrefixBits f bs with
    | none => simp [hc] at h
    | some pair =>
      rcases pair with ⟨a, rem'⟩
      simp only [hc] at h
      rcases (consumePrefixBits_eq_some_iff hf).mp hc with ⟨bs₁, rfl, hfa⟩
      exact ⟨bs₁, rem', a, rfl, hfa, h⟩
  · rintro ⟨bs₁, bs₂, a, rfl, hfa, hgb⟩
    rw [consumePrefixBits_append_of_prefixFree hf hfa]
    exact hgb

theorem isPrefixFree_seqConsume {α β : Type} {f : List Bool → Option α}
    {g : α → List Bool → Option β}
    (hf : IsPrefixFree f) (hg : ∀ bs₁ a, f bs₁ = some a → IsPrefixFree (g a)) :
    IsPrefixFree (seqConsume f g) := by
  intro u v b₁ b₂ hu hv huv
  rcases (seqConsume_eq_some_iff hf).mp hu with ⟨bs₁, bs₂, a₁, rfl, hfa₁, hgb₁⟩
  rcases (seqConsume_eq_some_iff hf).mp hv with ⟨cs₁, cs₂, a₂, rfl, hfa₂, hgb₂⟩
  rcases huv with ⟨w, hw⟩
  have hw' : bs₁ ++ (bs₂ ++ w) = cs₁ ++ cs₂ := by simpa [List.append_assoc] using hw
  rcases prefixFree_split_unique hf hw' hfa₁ hfa₂ with ⟨rfl, htail, rfl⟩
  have hbs₂ := hg bs₁ a₁ hfa₁ bs₂ cs₂ b₁ b₂ hgb₁ hgb₂ ⟨w, htail⟩
  rw [hbs₂]

theorem expWithBits_seqConsume {α β : Type} {f : List Bool → Option α}
    (hf : IsPrefixFree f) (g : α → List Bool → Option β) (W : β → ENNReal) :
    expWithBits (seqConsume f g) W = expWithBits f (fun a => expWithBits (g a) W) := by
  let θ : List Bool → ENNReal := fun bs =>
    match seqConsume f g bs with
    | some b => UL.bitListProb bs * W b
    | none => 0
  let ψ : List Bool × List Bool → ENNReal := fun p =>
    match f p.1 with
    | some a =>
        match g a p.2 with
        | some b => UL.bitListProb p.1 * (UL.bitListProb p.2 * W b)
        | none => 0
    | none => 0
  have hrhs : expWithBits f (fun a => expWithBits (g a) W) = ∑' p : List Bool × List Bool, ψ p := by
    rw [ENNReal.tsum_prod']
    unfold expWithBits
    congr 1
    ext bs₁
    cases hfb : f bs₁ with
    | none =>
      dsimp
      have : (fun bs₂ : List Bool => ψ (bs₁, bs₂)) = fun _ => 0 := by ext bs₂; simp [ψ, hfb]
      rw [this, tsum_zero]
    | some a =>
      dsimp
      rw [← ENNReal.tsum_mul_left]
      congr 1
      ext bs₂
      cases hg : g a bs₂ <;> simp [ψ, hfb, hg]
  rw [hrhs]
  change ∑' bs, θ bs = ∑' p, ψ p
  refine tsum_eq_tsum_of_ne_zero_bij (fun p : Function.support ψ => p.1.1 ++ p.1.2) ?_ ?_ ?_
  · rintro ⟨⟨bs₁, bs₂⟩, hp⟩ ⟨⟨cs₁, cs₂⟩, hq⟩ heq
    dsimp at heq
    have hp' : ψ (bs₁, bs₂) ≠ 0 := hp
    have hq' : ψ (cs₁, cs₂) ≠ 0 := hq
    cases hfb : f bs₁ with
    | none => simp [ψ, hfb] at hp'
    | some a₁ =>
      cases hfc : f cs₁ with
      | none => simp [ψ, hfc] at hq'
      | some a₂ =>
        rcases prefixFree_split_unique hf heq hfb hfc with ⟨rfl, rfl, _⟩
        rfl
  · intro bs hbs
    have hbs' : θ bs ≠ 0 := hbs
    cases hsc : seqConsume f g bs with
    | none => simp [θ, hsc] at hbs'
    | some b =>
      rcases (seqConsume_eq_some_iff hf).mp hsc with ⟨bs₁, bs₂, a, rfl, hfa, hgb⟩
      have hψ_eq : ψ (bs₁, bs₂) = θ (bs₁ ++ bs₂) := by
        simp [ψ, θ, hfa, hgb, hsc, bitListProb_append, mul_assoc]
      refine ⟨⟨(bs₁, bs₂), ?_⟩, rfl⟩
      rw [Function.mem_support, hψ_eq]
      exact hbs'
  · rintro ⟨⟨bs₁, bs₂⟩, hp⟩
    have hp' : ψ (bs₁, bs₂) ≠ 0 := hp
    cases hfa : f bs₁ with
    | none => simp [ψ, hfa] at hp'
    | some a =>
      cases hgb : g a bs₂ with
      | none => simp [ψ, hfa, hgb] at hp'
      | some b =>
        have hsc : seqConsume f g (bs₁ ++ bs₂) = some b :=
          (seqConsume_eq_some_iff hf).mpr ⟨bs₁, bs₂, a, rfl, hfa, hgb⟩
        simp [θ, ψ, hfa, hgb, hsc, bitListProb_append, mul_assoc]

theorem haltProb_seqConsume {α β : Type} {f : List Bool → Option α}
    {g : α → List Bool → Option β}
    (hf : IsPrefixFree f) (hf1 : haltProb f = 1)
    (hg1 : ∀ bs₁ a, f bs₁ = some a → haltProb (g a) = 1) :
    haltProb (seqConsume f g) = 1 := by
  rw [← expWithBits_one_eq_haltProb, expWithBits_seqConsume hf]
  have hcongr : expWithBits f (fun a => expWithBits (g a) (fun _ => 1)) =
      expWithBits f (fun _ => 1) := by
    refine expWithBits_congr (fun _ => rfl) fun bs₁ a hfa => ?_
    rw [expWithBits_one_eq_haltProb]
    exact hg1 bs₁ a hfa
  rw [hcongr, expWithBits_one_eq_haltProb, hf1]

/-! ### 4. Event Lower Bound & `iSup` Swap Combinators -/

theorem ofReal_one_sub_add_le_mul {δ C : ℝ} (hδ : 0 ≤ δ) (hC : 0 ≤ C) :
    ENNReal.ofReal (1 - (δ + C)) ≤ ENNReal.ofReal (1 - δ) * ENNReal.ofReal (1 - C) := by
  by_cases h1 : 1 ≤ δ + C
  · rw [ENNReal.ofReal_eq_zero.mpr (by linarith)]
    exact zero_le _
  · push_neg at h1
    rw [← ENNReal.ofReal_mul (by linarith)]
    exact ENNReal.ofReal_le_ofReal (by nlinarith)

theorem expWithBits_seqConsume_ge_of_event {α β : Type}
    {f : List Bool → Option α} (hf : IsPrefixFree f)
    {g : α → List Bool → Option β}
    (P : α → Prop) [DecidablePred P] (W : β → ENNReal)
    {δ C : ℝ} (hδ : 0 ≤ δ) (hC : 0 ≤ C)
    (hP : ENNReal.ofReal (1 - δ) ≤ expWithBits f (fun a => if P a then 1 else 0))
    (hg : ∀ bs₁ a, f bs₁ = some a → P a → ENNReal.ofReal (1 - C) ≤ expWithBits (g a) W) :
    ENNReal.ofReal (1 - (δ + C)) ≤ expWithBits (seqConsume f g) W := by
  rw [expWithBits_seqConsume hf]
  calc
    ENNReal.ofReal (1 - (δ + C))
        ≤ ENNReal.ofReal (1 - δ) * ENNReal.ofReal (1 - C) := ofReal_one_sub_add_le_mul hδ hC
    _ ≤ expWithBits f (fun a => if P a then 1 else 0) * ENNReal.ofReal (1 - C) :=
        mul_le_mul_of_nonneg_right hP (zero_le _)
    _ = expWithBits f (fun a => (if P a then 1 else 0) * ENNReal.ofReal (1 - C)) :=
        (expWithBits_mul_const _ _ _).symm
    _ ≤ expWithBits f (fun a => expWithBits (g a) W) := by
        refine expWithBits_mono fun bs₁ a hfa => ?_
        by_cases hpa : P a
        · simp only [hpa, ↓reduceIte, one_mul]
          exact hg bs₁ a hfa hpa
        · simp [hpa]

theorem ennreal_le_of_forall_pos_le_add {x y : ENNReal}
    (h : ∀ ε : ℝ, 0 < ε → x ≤ y + ENNReal.ofReal ε) : x ≤ y := by
  by_cases hy : y = ⊤
  · rw [hy]; exact le_top
  · by_contra hlt
    push_neg at hlt
    by_cases hx : x = ⊤
    · have h1 := h 1 zero_lt_one
      rw [hx] at h1
      have hne : y + ENNReal.ofReal 1 ≠ ⊤ := ENNReal.add_ne_top.mpr ⟨hy, ENNReal.ofReal_ne_top⟩
      exact hne (top_le_iff.mp h1)
    · have hpos : 0 < (x - y).toReal :=
        ENNReal.toReal_pos (tsub_pos_iff_lt.mpr hlt).ne' (ENNReal.sub_ne_top hx)
      let ε := (x - y).toReal / 2
      have hε : 0 < ε := half_pos hpos
      have hle := h ε hε
      have hreal := ENNReal.toReal_mono (ENNReal.add_ne_top.mpr ⟨hy, ENNReal.ofReal_ne_top⟩) hle
      rw [ENNReal.toReal_add hy ENNReal.ofReal_ne_top, ENNReal.toReal_ofReal hε.le] at hreal
      have hsub : (x - y).toReal = x.toReal - y.toReal :=
        ENNReal.toReal_sub_of_le hlt.le hx
      dsimp only [ε] at hreal
      linarith

theorem tsum_add_iSup_le {α : Type*} {f : List Bool → Option α}
    (hf : IsPrefixFree f)
    (c : α → ENNReal)
    {ι : α → Type*} [h_ne : ∀ a, Nonempty (ι a)]
    (Φ : (a : α) → ι a → ENNReal) :
    (∑' bs : List Bool,
      match f bs with
      | some a => UL.bitListProb bs * (c a + ⨆ x : ι a, Φ a x)
      | none => 0) ≤
    ⨆ (ch : List Bool → (a : α) → ι a),
      ∑' bs : List Bool,
        match f bs with
        | some a => UL.bitListProb bs * (c a + Φ a (ch bs a))
        | none => 0 := by
  classical
  let R_fn : (List Bool → (a : α) → ι a) → ENNReal := fun ch =>
    ∑' bs : List Bool,
      match f bs with
      | some a => UL.bitListProb bs * (c a + Φ a (ch bs a))
      | none => 0
  let R : ENNReal := ⨆ ch, R_fn ch
  change _ ≤ R
  by_cases hR_top : R = ⊤
  · rw [hR_top]; exact le_top
  · refine ennreal_le_of_forall_pos_le_add fun ε hε => ?_
    let δ : ENNReal := ENNReal.ofReal ε
    have hδ_pos : 0 < δ := ENNReal.ofReal_pos.mpr hε
    have hex_choice : ∀ (bs : List Bool) (a : α),
        f bs = some a → ∃ x : ι a, ⨆ x' : ι a, Φ a x' ≤ Φ a x + δ := by
      intro bs a hfa
      set M := ⨆ x' : ι a, Φ a x'
      have hM_ne_top : M ≠ ⊤ := by
        intro hM_top
        have hgt : R / UL.bitListProb bs < M := by
          rw [hM_top]
          exact lt_top_iff_ne_top.mpr (ENNReal.div_ne_top hR_top (bitListProb_ne_zero bs))
        obtain ⟨x₀, hx₀⟩ := lt_iSup_iff.mp hgt
        let ch₀ : List Bool → (a' : α) → ι a' := fun _ a' =>
          if h : a' = a then h ▸ x₀ else Classical.choice (h_ne a')
        have hval : ch₀ bs a = x₀ := dif_pos rfl
        have hsingle : UL.bitListProb bs * (c a + Φ a x₀) ≤ R := by
          calc
            UL.bitListProb bs * (c a + Φ a x₀)
                = (match f bs with
                   | some a' => UL.bitListProb bs * (c a' + Φ a' (ch₀ bs a'))
                   | none => 0) := by simp [hfa, hval]
            _ ≤ R_fn ch₀ := ENNReal.le_tsum bs
            _ ≤ R := le_iSup R_fn ch₀
        have h1 : UL.bitListProb bs * Φ a x₀ ≤ R :=
          (mul_le_mul_of_nonneg_left le_add_self (zero_le _)).trans hsingle
        have h2 : Φ a x₀ ≤ R / UL.bitListProb bs :=
          (ENNReal.le_div_iff_mul_le (Or.inl (bitListProb_ne_zero bs))
            (Or.inl (bitListProb_ne_top bs))).mpr (by simpa [mul_comm] using h1)
        exact not_lt_of_ge h2 hx₀
      by_cases hM0 : M = 0
      · obtain ⟨x₀⟩ := h_ne a
        exact ⟨x₀, by simp [hM0]⟩
      · have hsub_lt : M - δ < M :=
          ENNReal.sub_lt_self hM_ne_top hM0 hδ_pos.ne'
        obtain ⟨x₀, hx₀⟩ := lt_iSup_iff.mp hsub_lt
        exact ⟨x₀, tsub_le_iff_right.mp hx₀.le⟩
    let ch : List Bool → (a : α) → ι a := fun bs a =>
      if hfa : f bs = some a then Classical.choose (hex_choice bs a hfa)
      else Classical.choice (h_ne a)
    have hch_spec : ∀ bs a, f bs = some a → ⨆ x' : ι a, Φ a x' ≤ Φ a (ch bs a) + δ := by
      intro bs a hfa
      simpa [ch, hfa] using Classical.choose_spec (hex_choice bs a hfa)
    have hterm_le : ∀ bs : List Bool,
        (match f bs with
        | some a => UL.bitListProb bs * (c a + ⨆ x : ι a, Φ a x)
        | none => 0) ≤
        (match f bs with
        | some a => UL.bitListProb bs * (c a + Φ a (ch bs a))
        | none => 0) +
        (if (f bs).isSome then UL.bitListProb bs else 0) * δ := by
      intro bs
      cases h : f bs with
      | none => simp
      | some a =>
        dsimp only
        simp only [Option.isSome_some, ↓reduceIte]
        calc
          UL.bitListProb bs * (c a + ⨆ x : ι a, Φ a x)
              ≤ UL.bitListProb bs * (c a + (Φ a (ch bs a) + δ)) := by
                gcongr; exact hch_spec bs a h
          _ = UL.bitListProb bs * (c a + Φ a (ch bs a)) + UL.bitListProb bs * δ := by
                ring
    calc
      (∑' bs : List Bool,
        match f bs with
        | some a => UL.bitListProb bs * (c a + ⨆ x : ι a, Φ a x)
        | none => 0)
          ≤ ∑' bs : List Bool,
              ((match f bs with
                | some a => UL.bitListProb bs * (c a + Φ a (ch bs a))
                | none => 0) +
               (if (f bs).isSome then UL.bitListProb bs else 0) * δ) :=
            ENNReal.tsum_le_tsum hterm_le
      _ = R_fn ch + haltProb f * δ := by
            rw [ENNReal.tsum_add, ENNReal.tsum_mul_right]; rfl
      _ ≤ R + 1 * δ := by
            gcongr
            · exact le_iSup R_fn ch
            · exact hf.haltProb_le_one
      _ = R + ENNReal.ofReal ε := by simp [δ]

end UL.Proof_lem_7_1_RaceV31
