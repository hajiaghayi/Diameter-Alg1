import Mathlib
import UL.Stmt.lem_7_1
set_option autoImplicit false

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. Scheduled Dyadic Intervals (Part 1: Monte Carlo Wrapper) -/

/-- A scheduled dyadic block `[j * 2^k, (j + 1) * 2^k)` is ready at insertion clock `H`
once `(j + 2) * 2^k ≤ H + 1` (for `k = 0`, immediately at `j + 1 ≤ H`). -/
abbrev ReadyMC (H k j : ℕ) : Prop :=
  (j + 2) * 2 ^ k ≤ H + 1

/-- Block `(k, j)` is actively serving queries at clock `H` when it is ready and its
parent `(k + 1, j / 2)` is not yet ready. -/
abbrev ServingMC (H k j : ℕ) : Prop :=
  ReadyMC H k j ∧ ¬ ReadyMC H (k + 1) (j / 2)

/-- Block `(k, j)` is live in the table at clock `H` (either building or serving) when
its interval `[j * 2^k, (j + 1) * 2^k)` has completed (`(j + 1) * 2^k ≤ H`) and its
parent `(k + 1, j / 2)` is not yet ready (`H + 1 < (j / 2 + 2) * 2^(k + 1)`). -/
abbrev LiveMC (H k j : ℕ) : Prop :=
  (j + 1) * 2 ^ k ≤ H ∧ H + 1 < (j / 2 + 2) * 2 ^ (k + 1)

theorem readyMC_zero (H j : ℕ) : ReadyMC H 0 j ↔ j + 1 ≤ H := by
  simp only [ReadyMC, pow_zero, mul_one]
  omega

theorem readyMC_imp_end_le {H k j : ℕ} (h : ReadyMC H k j) : (j + 1) * 2 ^ k ≤ H := by
  have hpow : 1 ≤ 2 ^ k := Nat.one_le_two_pow
  have h1 : (j + 1) * 2 ^ k + 2 ^ k = (j + 2) * 2 ^ k := by ring
  unfold ReadyMC at h
  omega

theorem readyMC_parent_imp_child {H k j : ℕ} (h : ReadyMC H (k + 1) (j / 2)) :
    ReadyMC H k j := by
  unfold ReadyMC at h ⊢
  have h1 : (j / 2 + 2) * 2 ^ (k + 1) = (2 * (j / 2) + 4) * 2 ^ k := by
    rw [pow_succ]
    ring
  have hj : j + 2 ≤ 2 * (j / 2) + 4 := by omega
  calc
    (j + 2) * 2 ^ k ≤ (2 * (j / 2) + 4) * 2 ^ k := Nat.mul_le_mul_right _ hj
    _ = (j / 2 + 2) * 2 ^ (k + 1) := h1.symm
    _ ≤ H + 1 := h

theorem div_two_pow_div_two (t k : ℕ) : (t / 2 ^ k) / 2 = t / 2 ^ (k + 1) := by
  rw [Nat.div_div_eq_div_mul, ← pow_succ]

theorem readyMC_antimono_level {H t k₁ k₂ : ℕ} (hle : k₁ ≤ k₂)
    (h : ReadyMC H k₂ (t / 2 ^ k₂)) : ReadyMC H k₁ (t / 2 ^ k₁) := by
  induction k₂, hle using Nat.le_induction with
  | base => exact h
  | succ m _ ih =>
    apply ih
    have hp : ReadyMC H (m + 1) ((t / 2 ^ m) / 2) := by
      rwa [div_two_pow_div_two]
    exact readyMC_parent_imp_child hp

theorem servingMC_imp_liveMC {H k j : ℕ} (h : ServingMC H k j) : LiveMC H k j := by
  refine ⟨readyMC_imp_end_le h.1, ?_⟩
  have hnr := h.2
  unfold ReadyMC at hnr
  omega

theorem liveMC_imp_two_pow_le {H k j : ℕ} (h : LiveMC H k j) : 2 ^ k ≤ H := by
  calc
    2 ^ k = 1 * 2 ^ k := (one_mul _).symm
    _ ≤ (j + 1) * 2 ^ k := Nat.mul_le_mul_right _ (by omega)
    _ ≤ H := h.1

theorem liveMC_imp_k_lt_log_succ {H k j : ℕ} (h : LiveMC H k j) :
    k < Nat.log 2 H + 1 := by
  have hpow : 2 ^ k ≤ H := liveMC_imp_two_pow_le h
  have hpos : 0 < H := lt_of_lt_of_le (Nat.two_pow_pos k) hpow
  have hk : k ≤ Nat.log 2 H := Nat.le_log_of_pow_le (by norm_num) hpow
  omega

theorem div_eq_of_mem_dyadic {t k j : ℕ}
    (hlo : j * 2 ^ k ≤ t) (hhi : t < (j + 1) * 2 ^ k) : t / 2 ^ k = j := by
  have hpos : 0 < 2 ^ k := Nat.two_pow_pos k
  apply le_antisymm
  · exact Nat.le_of_lt_succ ((Nat.div_lt_iff_lt_mul hpos).mpr hhi)
  · exact (Nat.le_div_iff_mul_le hpos).mpr hlo

theorem serveMC_exists_unique {H t : ℕ} (ht : t < H) :
    ∃! p : ℕ × ℕ, ServingMC H p.1 p.2 ∧ p.2 * 2 ^ p.1 ≤ t ∧ t < (p.2 + 1) * 2 ^ p.1 := by
  classical
  have hex_not : ∃ m : ℕ, ¬ ReadyMC H m (t / 2 ^ m) := by
    refine ⟨Nat.log 2 H + 1, fun hr => ?_⟩
    have hle : 2 ^ (Nat.log 2 H + 1) ≤ H :=
      calc
        2 ^ (Nat.log 2 H + 1) ≤ (t / 2 ^ (Nat.log 2 H + 1) + 1) * 2 ^ (Nat.log 2 H + 1) :=
          Nat.le_mul_of_pos_left _ (Nat.succ_pos _)
        _ ≤ H := readyMC_imp_end_le hr
    exact absurd hle (not_le_of_gt (Nat.lt_pow_succ_log_self (by norm_num) H))
  let m₀ := Nat.find hex_not
  have hm₀_spec : ¬ ReadyMC H m₀ (t / 2 ^ m₀) := Nat.find_spec hex_not
  have hm₀_pos : 0 < m₀ := by
    by_contra h0
    have hz : m₀ = 0 := by omega
    rw [hz, pow_zero, Nat.div_one, readyMC_zero] at hm₀_spec
    omega
  let k₀ := m₀ - 1
  have hk₀_succ : k₀ + 1 = m₀ := by omega
  have hr_k₀ : ReadyMC H k₀ (t / 2 ^ k₀) := by
    have hlt : k₀ < m₀ := by omega
    exact of_not_not (Nat.find_min hex_not hlt)
  have hnr_k₀ : ¬ ReadyMC H (k₀ + 1) ((t / 2 ^ k₀) / 2) := by
    rw [div_two_pow_div_two, hk₀_succ]
    exact hm₀_spec
  let j₀ := t / 2 ^ k₀
  have hj₀_lo : j₀ * 2 ^ k₀ ≤ t := Nat.div_mul_le_self t (2 ^ k₀)
  have hj₀_hi : t < (j₀ + 1) * 2 ^ k₀ := by
    rw [← Nat.div_lt_iff_lt_mul (Nat.two_pow_pos k₀)]
    dsimp [j₀]
    omega
  refine ⟨(k₀, j₀), ⟨⟨hr_k₀, hnr_k₀⟩, hj₀_lo, hj₀_hi⟩, ?_⟩
  rintro ⟨k₁, j₁⟩ ⟨hserv₁, hlo₁, hhi₁⟩
  dsimp only at hserv₁ hlo₁ hhi₁
  have hj₁ : j₁ = t / 2 ^ k₁ := (div_eq_of_mem_dyadic hlo₁ hhi₁).symm
  have hk_eq : k₁ = k₀ := by
    rcases lt_trichotomy k₁ k₀ with hlt | rfl | hgt
    · exfalso
      apply hserv₁.2
      rw [hj₁, div_two_pow_div_two]
      exact readyMC_antimono_level (by omega : k₁ + 1 ≤ k₀) hr_k₀
    · rfl
    · exfalso
      apply hnr_k₀
      rw [div_two_pow_div_two]
      have hr₁ : ReadyMC H k₁ (t / 2 ^ k₁) := by simpa [hj₁] using hserv₁.1
      exact readyMC_antimono_level (by omega : k₀ + 1 ≤ k₁) hr₁
  subst hk_eq
  simp [j₀, hj₁]

/-- Candidate indices `j` that can be live at level `k` and clock `H` (at most 3). -/
def liveJCandidates (H k : ℕ) : Finset ℕ :=
  {H / 2 ^ k - 3, H / 2 ^ k - 2, H / 2 ^ k - 1}

private theorem card_triple_le {α : Type*} [DecidableEq α] (a b c : α) :
    ({a, b, c} : Finset α).card ≤ 3 :=
  (Finset.card_insert_le a {b, c}).trans
    (Nat.succ_le_succ ((Finset.card_insert_le b {c}).trans (by simp)))

theorem card_liveJCandidates_le (H k : ℕ) : (liveJCandidates H k).card ≤ 3 :=
  card_triple_le _ _ _

/-- Computable `Finset` of all `(k, j)` pairs satisfying `LiveMC H k j`. -/
def livePairsMC (H : ℕ) : Finset (ℕ × ℕ) :=
  ((Finset.range (Nat.log 2 H + 1)).biUnion fun k =>
    (liveJCandidates H k).image fun j => (k, j)).filter fun p => LiveMC H p.1 p.2

theorem liveMC_imp_mem_liveJCandidates {H k j : ℕ} (h : LiveMC H k j) :
    j ∈ liveJCandidates H k := by
  have hpos : 0 < 2 ^ k := Nat.two_pow_pos k
  have hq_ge : j + 1 ≤ H / 2 ^ k := (Nat.le_div_iff_mul_le hpos).mpr h.1
  have h1 : (j / 2 + 2) * 2 ^ (k + 1) ≤ (j + 4) * 2 ^ k := by
    rw [pow_succ]
    have hj : 2 * (j / 2 + 2) ≤ j + 4 := by omega
    calc
      (j / 2 + 2) * (2 ^ k * 2) = (2 * (j / 2 + 2)) * 2 ^ k := by ring
      _ ≤ (j + 4) * 2 ^ k := Nat.mul_le_mul_right _ hj
  have hlt : H < (j + 4) * 2 ^ k := lt_of_lt_of_le (by omega : H < H + 1) (le_trans (le_of_lt h.2) h1)
  have hq_lt : H / 2 ^ k < j + 4 := (Nat.div_lt_iff_lt_mul hpos).mpr hlt
  unfold liveJCandidates
  simp only [Finset.mem_insert, Finset.mem_singleton]
  omega

theorem mem_livePairsMC_iff (H k j : ℕ) :
    (k, j) ∈ livePairsMC H ↔ LiveMC H k j := by
  unfold livePairsMC
  simp only [Finset.mem_filter, Finset.mem_biUnion, Finset.mem_range, Finset.mem_image,
    Prod.mk.injEq, and_iff_right_iff_imp]
  intro h
  exact ⟨k, liveMC_imp_k_lt_log_succ h, j, liveMC_imp_mem_liveJCandidates h, rfl, rfl⟩

theorem card_livePairsMC_le (H : ℕ) :
    (livePairsMC H).card ≤ 3 * (Nat.log 2 H + 1) := by
  unfold livePairsMC
  calc
    (((Finset.range (Nat.log 2 H + 1)).biUnion fun k =>
        (liveJCandidates H k).image fun j => (k, j)).filter fun p => LiveMC H p.1 p.2).card
        ≤ ((Finset.range (Nat.log 2 H + 1)).biUnion fun k =>
            (liveJCandidates H k).image fun j => (k, j)).card :=
          Finset.card_filter_le _ _
    _ ≤ ∑ k ∈ Finset.range (Nat.log 2 H + 1),
          ((liveJCandidates H k).image fun j => (k, j)).card :=
          Finset.card_biUnion_le
    _ ≤ ∑ _k ∈ Finset.range (Nat.log 2 H + 1), 3 := by
          refine Finset.sum_le_sum fun k _ => ?_
          exact Finset.card_image_le.trans (card_liveJCandidates_le H k)
    _ = 3 * (Nat.log 2 H + 1) := by
          simp [mul_comm]

theorem newSlot_liveMC {H k j : ℕ} (heq : (j + 1) * 2 ^ k = H + 1) :
    LiveMC (H + 1) k j ∧ ¬ LiveMC H k j := by
  refine ⟨⟨by omega, ?_⟩, fun h => by have := h.1; omega⟩
  have hpow : 1 ≤ 2 ^ k := Nat.one_le_two_pow
  have hj : j + 2 < 2 * (j / 2 + 2) := by omega
  have hlt : (j + 2) * 2 ^ k < (2 * (j / 2 + 2)) * 2 ^ k :=
    Nat.mul_lt_mul_of_pos_right hj (Nat.two_pow_pos k)
  have hlhs : H + 1 + 1 ≤ (j + 2) * 2 ^ k := by
    have h1 : (j + 1) * 2 ^ k + 2 ^ k = (j + 2) * 2 ^ k := by ring
    omega
  have hrhs : (2 * (j / 2 + 2)) * 2 ^ k = (j / 2 + 2) * 2 ^ (k + 1) := by
    rw [pow_succ]; ring
  omega

theorem liveMC_succ_iff (H k j : ℕ) :
    LiveMC (H + 1) k j ↔
      (LiveMC H k j ∧ H + 2 < (j / 2 + 2) * 2 ^ (k + 1)) ∨ (j + 1) * 2 ^ k = H + 1 := by
  constructor
  · intro h
    rcases Nat.lt_or_eq_of_le h.1 with hlt | heq
    · exact Or.inl ⟨⟨by omega, by omega⟩, h.2⟩
    · exact Or.inr heq
  · rintro (⟨h, hhi⟩ | heq)
    · exact ⟨by omega, hhi⟩
    · exact (newSlot_liveMC heq).1

theorem card_filter_lt_le_of_injOn_snd {ι : Type*} [DecidableEq ι]
    (A : Finset (ι × ℕ))
    (hinj : ∀ r₁ ∈ A, ∀ r₂ ∈ A, r₁.2 = r₂.2 → r₁ = r₂)
    (lo hi : ℕ) :
    (A.filter (fun r => lo ≤ r.2 ∧ r.2 < hi)).card ≤ hi - lo := by
  let F := A.filter (fun r => lo ≤ r.2 ∧ r.2 < hi)
  have hinjF : Set.InjOn Prod.snd (F : Set (ι × ℕ)) := by
    intro r₁ hr₁ r₂ hr₂ heq
    exact hinj r₁ (Finset.mem_filter.mp hr₁).1 r₂ (Finset.mem_filter.mp hr₂).1 heq
  have hsub : F.image Prod.snd ⊆ Finset.Ico lo hi := by
    intro t ht
    rcases Finset.mem_image.mp ht with ⟨r, hr, rfl⟩
    have hb := (Finset.mem_filter.mp hr).2
    exact Finset.mem_Ico.mpr hb
  calc
    F.card = (F.image Prod.snd).card := (Finset.card_image_of_injOn hinjF).symm
    _ ≤ (Finset.Ico lo hi).card := Finset.card_le_card hsub
    _ = hi - lo := Nat.card_Ico lo hi

/-! ### 2. `openLevels` and `popcount` Credit Identity (Part 1 Union Bound) -/

/-- Binary popcount of `n`. -/
def popcount (n : ℕ) : ℕ :=
  if n = 0 then 0 else (n % 2) + popcount (n / 2)
termination_by n

/-- List of levels `k` such that `2 ^ k ∣ n` (empty when `n = 0`). -/
def openLevels (n : ℕ) : List ℕ :=
  if n = 0 then []
  else if n % 2 = 1 then [0]
  else 0 :: (openLevels (n / 2)).map (· + 1)
termination_by n

theorem nodup_openLevels (n : ℕ) : (openLevels n).Nodup := by
  induction n using Nat.strongRecOn with
  | ind n ih =>
    unfold openLevels
    split_ifs with h0 hodd
    · simp
    · simp
    · rw [List.nodup_cons]
      refine ⟨?_, ?_⟩
      · simp
      · refine List.Nodup.map (fun a b h => by omega) ?_
        exact ih (n / 2) (Nat.div_lt_self (by omega) (by norm_num))

theorem mem_openLevels_iff {n : ℕ} (hn : 0 < n) (k : ℕ) :
    k ∈ openLevels n ↔ 2 ^ k ∣ n := by
  induction n using Nat.strongRecOn generalizing k with
  | ind n ih =>
    rw [openLevels]
    have h0 : n ≠ 0 := by omega
    simp only [h0, ↓reduceIte]
    split_ifs with hodd
    · simp only [List.mem_singleton]
      constructor
      · rintro rfl; simp
      · intro hdvd
        cases k with
        | zero => rfl
        | succ k' =>
          exfalso
          have h2 : 2 ∣ 2 ^ (k' + 1) := ⟨2 ^ k', by rw [pow_succ, mul_comm]⟩
          have h2n : 2 ∣ n := dvd_trans h2 hdvd
          omega
    · have heven : n = 2 * (n / 2) := by omega
      have hdiv_pos : 0 < n / 2 := by omega
      cases k with
      | zero => simp
      | succ k' =>
        simp only [List.mem_cons, Nat.succ_ne_zero, false_or, List.mem_map, Nat.add_right_cancel_iff,
          exists_eq_right]
        rw [ih (n / 2) (Nat.div_lt_self hn (by norm_num)) hdiv_pos k']
        conv_rhs => rw [pow_succ', heven]
        exact (mul_dvd_mul_iff_left (by norm_num : (2 : ℕ) ≠ 0)).symm

theorem length_openLevels_add_popcount (H : ℕ) :
    (openLevels (H + 1)).length + popcount (H + 1) = popcount H + 2 := by
  induction H using Nat.strongRecOn with
  | ind H ih =>
    by_cases heven : H % 2 = 0
    · -- `H = 2 * q`, `H + 1` is odd
      have hodd1 : (H + 1) % 2 = 1 := by omega
      have hdiv1 : (H + 1) / 2 = H / 2 := by omega
      rw [openLevels]
      simp only [Nat.succ_ne_zero, ↓reduceIte, hodd1, List.length_singleton]
      rw [popcount]
      simp only [Nat.succ_ne_zero, ↓reduceIte, hodd1, hdiv1]
      by_cases hH0 : H = 0
      · subst hH0; simp [popcount]
      · conv_rhs => rw [popcount]
        simp only [hH0, ↓reduceIte, heven]
        omega
    · -- `H = 2 * q + 1`, `H + 1 = 2 * (q + 1)` is even
      have hH_odd : H % 2 = 1 := by omega
      have hH_ne : H ≠ 0 := by omega
      have h1_even : (H + 1) % 2 ≠ 1 := by omega
      have h1_mod0 : (H + 1) % 2 = 0 := by omega
      have hdiv_eq : (H + 1) / 2 = H / 2 + 1 := by omega
      have hlt : H / 2 < H := Nat.div_lt_self (by omega) (by norm_num)
      have hrec := ih (H / 2) hlt
      rw [openLevels]
      simp only [Nat.succ_ne_zero, ↓reduceIte, h1_even, List.length_cons, List.length_map, hdiv_eq]
      rw [popcount]
      simp only [Nat.succ_ne_zero, ↓reduceIte, h1_mod0, hdiv_eq]
      conv_rhs => rw [popcount]
      simp only [hH_ne, ↓reduceIte, hH_odd]
      omega

/-- Remaining-slot budget `2 * rem + popcount H` pays `(openLevels (H + 1)).length` on `.insert`. -/
def remSlotBudget (rem H : ℕ) : ℕ :=
  2 * rem + popcount H

theorem remSlotBudget_insert (r H : ℕ) :
    (openLevels (H + 1)).length + remSlotBudget r (H + 1) = remSlotBudget (r + 1) H := by
  unfold remSlotBudget
  have := length_openLevels_add_popcount H
  omega

theorem remSlotBudget_nonInsert (r H : ℕ) :
    remSlotBudget r H ≤ remSlotBudget (r + 1) H := by
  unfold remSlotBudget
  omega

/-! ### 3. Binary-Counter Dyadic Intervals (Part 2: Certified Wrapper) -/

/-- Level `k` is active in the binary expansion of `H` when bit `k` of `H` is `1`. -/
abbrev BitActive (H k : ℕ) : Prop :=
  (H / 2 ^ k) % 2 = 1

/-- Prefix boundary `(H / 2^k) * 2^k` (clearing the lowest `k` bits of `H`). -/
def prefixEnd (H k : ℕ) : ℕ :=
  (H / 2 ^ k) * 2 ^ k

theorem prefixEnd_zero (H : ℕ) : prefixEnd H 0 = H := by
  simp [prefixEnd]

theorem prefixEnd_of_lt_pow {H K : ℕ} (h : H < 2 ^ K) : prefixEnd H K = 0 := by
  unfold prefixEnd
  rw [Nat.div_eq_of_lt h, zero_mul]

theorem prefixEnd_step (H k : ℕ) :
    prefixEnd H k = prefixEnd H (k + 1) + (if BitActive H k then 2 ^ k else 0) := by
  unfold prefixEnd BitActive
  have hdiv : H / 2 ^ k = 2 * (H / 2 ^ (k + 1)) + (H / 2 ^ k) % 2 := by
    rw [← div_two_pow_div_two H k]
    omega
  have hrem : (H / 2 ^ k) % 2 = 0 ∨ (H / 2 ^ k) % 2 = 1 := by omega
  rcases hrem with h0 | h1
  · simp only [h0, Nat.zero_ne_one, ↓reduceIte, add_zero]
    rw [hdiv, h0, add_zero, pow_succ]
    ring
  · simp only [h1, ↓reduceIte]
    rw [hdiv, h1, pow_succ]
    ring

theorem prefixEnd_le_succ_step (H k : ℕ) : prefixEnd H (k + 1) ≤ prefixEnd H k := by
  rw [prefixEnd_step H k]
  omega

theorem prefixEnd_antimono {H k₁ k₂ : ℕ} (hle : k₁ ≤ k₂) :
    prefixEnd H k₂ ≤ prefixEnd H k₁ := by
  induction k₂, hle using Nat.le_induction with
  | base => exact le_rfl
  | succ m _ ih => exact (prefixEnd_le_succ_step H m).trans ih

theorem prefixEnd_le_self (H k : ℕ) : prefixEnd H k ≤ H := by
  simpa [prefixEnd_zero] using prefixEnd_antimono (Nat.zero_le k)

theorem binInterval_exists_unique {H K t : ℕ} (hHK : H < 2 ^ K) (ht : t < H) :
    ∃! k : ℕ, k < K ∧ BitActive H k ∧ prefixEnd H (k + 1) ≤ t ∧ t < prefixEnd H k := by
  -- Induction on `K` for arbitrary `H < 2^K`? Even simpler: telescoping `prefixEnd H k`!
  classical
  have hex : ∃ m : ℕ, prefixEnd H m ≤ t := ⟨K, by rw [prefixEnd_of_lt_pow hHK]; omega⟩
  let m₀ := Nat.find hex
  have hm₀_le : prefixEnd H m₀ ≤ t := Nat.find_spec hex
  have hm₀_pos : 0 < m₀ := by
    by_contra h0
    have hz : m₀ = 0 := by omega
    rw [hz, prefixEnd_zero] at hm₀_le
    omega
  have hm₀_le_K : m₀ ≤ K := Nat.find_min' hex (by rw [prefixEnd_of_lt_pow hHK]; omega)
  let k₀ := m₀ - 1
  have hk₀_succ : k₀ + 1 = m₀ := by omega
  have hk₀_lt : t < prefixEnd H k₀ := by
    have hlt : k₀ < m₀ := by omega
    exact not_le.mp (Nat.find_min hex hlt)
  have hk₀_lo : prefixEnd H (k₀ + 1) ≤ t := by rwa [hk₀_succ]
  have hk₀_bit : BitActive H k₀ := by
    by_contra hnb
    have hstep := prefixEnd_step H k₀
    simp only [hnb, ↓reduceIte, add_zero] at hstep
    omega
  refine ⟨k₀, ⟨by omega, hk₀_bit, hk₀_lo, hk₀_lt⟩, ?_⟩
  intro k₁ ⟨_, _, hlo₁, hhi₁⟩
  rcases lt_trichotomy k₁ k₀ with hlt | rfl | hgt
  · exact absurd (lt_of_lt_of_le hk₀_lt (prefixEnd_antimono (by omega : k₁ + 1 ≤ k₀))) (not_lt_of_ge hlo₁)
  · rfl
  · exact absurd (lt_of_lt_of_le hhi₁ (prefixEnd_antimono (by omega : k₀ + 1 ≤ k₁))) (not_lt_of_ge hk₀_lo)

/-- Lowest `0`-bit index of `H` (carry propagation level when incrementing `H → H + 1`). -/
def carryLevel (H : ℕ) : ℕ :=
  if H % 2 = 0 then 0 else carryLevel (H / 2) + 1
termination_by H

private theorem bitActive_two_mul_succ (q m : ℕ) :
    BitActive (2 * q + 1) (m + 1) ↔ BitActive q m := by
  unfold BitActive
  have h1 : (2 * q + 1) / 2 ^ (m + 1) = q / 2 ^ m := by
    rw [pow_succ', ← Nat.div_div_eq_div_mul]
    have : (2 * q + 1) / 2 = q := by omega
    rw [this]
  rw [h1]

private theorem bitActive_two_mul (q m : ℕ) :
    BitActive (2 * q) (m + 1) ↔ BitActive q m := by
  unfold BitActive
  have h1 : (2 * q) / 2 ^ (m + 1) = q / 2 ^ m := by
    rw [pow_succ', ← Nat.div_div_eq_div_mul, Nat.mul_div_right q (by norm_num)]
  rw [h1]

private theorem prefixEnd_two_mul_succ (q m : ℕ) :
    prefixEnd (2 * q + 1) (m + 1) = 2 * prefixEnd q m := by
  unfold prefixEnd
  have h1 : (2 * q + 1) / 2 ^ (m + 1) = q / 2 ^ m := by
    rw [pow_succ', ← Nat.div_div_eq_div_mul]
    have : (2 * q + 1) / 2 = q := by omega
    rw [this]
  rw [h1, pow_succ']
  ring

private theorem prefixEnd_two_mul (q m : ℕ) :
    prefixEnd (2 * q) (m + 1) = 2 * prefixEnd q m := by
  unfold prefixEnd
  have h1 : (2 * q) / 2 ^ (m + 1) = q / 2 ^ m := by
    rw [pow_succ', ← Nat.div_div_eq_div_mul, Nat.mul_div_right q (by norm_num)]
  rw [h1, pow_succ']
  ring

theorem carryLevel_spec (H : ℕ) :
    (∀ k < carryLevel H, BitActive H k ∧ ¬ BitActive (H + 1) k) ∧
    (¬ BitActive H (carryLevel H) ∧ BitActive (H + 1) (carryLevel H)) ∧
    (prefixEnd (H + 1) (carryLevel H) = H + 1 ∧
     prefixEnd (H + 1) (carryLevel H + 1) = prefixEnd H (carryLevel H) ∧
     prefixEnd H (carryLevel H) + 2 ^ carryLevel H = H + 1) ∧
    (∀ k, carryLevel H < k →
      (BitActive (H + 1) k ↔ BitActive H k) ∧
      prefixEnd (H + 1) k = prefixEnd H k) := by
  induction H using Nat.strongRecOn with
  | ind H ih =>
    by_cases heven : H % 2 = 0
    · obtain ⟨q, rfl⟩ : ∃ q, H = 2 * q := ⟨H / 2, by omega⟩
      have hcl : carryLevel (2 * q) = 0 := by rw [carryLevel]; simp
      rw [hcl]
      refine ⟨fun k hk => by omega, ?_, ?_, ?_⟩
      · unfold BitActive
        simp only [pow_zero, Nat.div_one]
        omega
      · refine ⟨by simp [prefixEnd], ?_, by simp [prefixEnd]⟩
        rw [prefixEnd_two_mul_succ, prefixEnd_zero, prefixEnd_zero]
      · intro k hk
        obtain ⟨m, rfl⟩ : ∃ m, k = m + 1 := ⟨k - 1, by omega⟩
        rw [bitActive_two_mul_succ, bitActive_two_mul,
            prefixEnd_two_mul_succ, prefixEnd_two_mul]
        exact ⟨Iff.rfl, rfl⟩
    · obtain ⟨q, rfl⟩ : ∃ q, H = 2 * q + 1 := ⟨H / 2, by omega⟩
      have hcl : carryLevel (2 * q + 1) = carryLevel q + 1 := by
        rw [carryLevel]
        have hmod : (2 * q + 1) % 2 ≠ 0 := by omega
        have hdiv : (2 * q + 1) / 2 = q := by omega
        simp [hmod, hdiv]
      rw [hcl]
      have hlt : q < 2 * q + 1 := by omega
      have hsucc : 2 * q + 1 + 1 = 2 * (q + 1) := by omega
      rw [hsucc]
      rcases ih q hlt with ⟨h_lt, h_eq, ⟨hp1, hp2, hp3⟩, h_gt⟩
      refine ⟨?_, ?_, ?_, ?_⟩
      · intro k hk
        cases k with
        | zero =>
          unfold BitActive
          simp only [pow_zero, Nat.div_one]
          omega
        | succ m =>
          rw [bitActive_two_mul_succ, bitActive_two_mul]
          exact h_lt m (by omega)
      · rw [bitActive_two_mul_succ, bitActive_two_mul]
        exact h_eq
      · rw [prefixEnd_two_mul, prefixEnd_two_mul, prefixEnd_two_mul_succ, pow_succ']
        refine ⟨by omega, by omega, by omega⟩
      · intro k hk
        obtain ⟨m, rfl⟩ : ∃ m, k = m + 1 := ⟨k - 1, by omega⟩
        rw [bitActive_two_mul_succ, bitActive_two_mul,
            prefixEnd_two_mul_succ, prefixEnd_two_mul]
        rcases h_gt m (by omega) with ⟨hb, hp⟩
        exact ⟨hb, by omega⟩

theorem carryLevel_lt_log_succ {H maxOps : ℕ} (hmax : H + 1 ≤ maxOps) :
    carryLevel H < Nat.log 2 maxOps + 1 := by
  have hpow_eq := (carryLevel_spec H).2.2.1.2.2
  have hpow_le : 2 ^ carryLevel H ≤ maxOps := by omega
  have hpos : 0 < maxOps := by omega
  have hle : carryLevel H ≤ Nat.log 2 maxOps := Nat.le_log_of_pow_le (by norm_num) hpow_le
  omega

/-- Slice of lifetime-tagged active records `S` belonging to binary-counter level `k` at clock `H`. -/
def binSlice {ι : Type*} (S : Finset (ι × ℕ)) (H k : ℕ) : Finset (ι × ℕ) :=
  S.filter (fun r => prefixEnd H (k + 1) ≤ r.2 ∧ r.2 < prefixEnd H k)

theorem binSlice_eq_empty_of_not_bitActive {ι : Type*} (S : Finset (ι × ℕ)) {H k : ℕ}
    (hnb : ¬ BitActive H k) : binSlice S H k = ∅ := by
  have heq : prefixEnd H k = prefixEnd H (k + 1) := by
    have := prefixEnd_step H k
    simpa [hnb] using this
  ext r
  simp only [binSlice, Finset.mem_filter, Finset.notMem_empty, iff_false, not_and]
  intro _ hlo hhi
  omega

theorem disjoint_binSlice {ι : Type*} (S : Finset (ι × ℕ)) (H : ℕ) {k₁ k₂ : ℕ} (hne : k₁ ≠ k₂) :
    Disjoint (binSlice S H k₁) (binSlice S H k₂) := by
  rw [Finset.disjoint_left]
  intro r hr₁ hr₂
  have hb₁ := (Finset.mem_filter.mp hr₁).2
  have hb₂ := (Finset.mem_filter.mp hr₂).2
  rcases Nat.lt_or_gt_of_ne hne with hlt | hgt
  · have hle : prefixEnd H k₂ ≤ prefixEnd H (k₁ + 1) := prefixEnd_antimono (by omega)
    omega
  · have hle : prefixEnd H k₁ ≤ prefixEnd H (k₂ + 1) := prefixEnd_antimono (by omega)
    omega

theorem biUnion_range_binSlice {ι : Type*} [DecidableEq ι] (S : Finset (ι × ℕ)) (H k₀ : ℕ) :
    (Finset.range k₀).biUnion (fun k => binSlice S H k) =
      S.filter (fun r => prefixEnd H k₀ ≤ r.2 ∧ r.2 < H) := by
  induction k₀ with
  | zero =>
    ext r
    simp [prefixEnd_zero]
  | succ m ih =>
    rw [Finset.range_add_one, Finset.biUnion_insert, ih]
    ext r
    simp only [Finset.mem_union, binSlice, Finset.mem_filter]
    have hle1 : prefixEnd H (m + 1) ≤ prefixEnd H m := prefixEnd_le_succ_step H m
    have hle2 : prefixEnd H m ≤ H := prefixEnd_le_self H m
    constructor
    · rintro (⟨hr, hlo, hhi⟩ | ⟨hr, hlo, hhi⟩) <;> exact ⟨hr, by omega, by omega⟩
    · rintro ⟨hr, hlo, hhi⟩
      by_cases hlt : r.2 < prefixEnd H m
      · exact Or.inl ⟨hr, hlo, hlt⟩
      · exact Or.inr ⟨hr, by omega, hhi⟩

/-- Element-level potential credit `∑_{k < L_max} (L_max - 1 - k) * |binSlice S H k|`. -/
def elemCredit {ι : Type*} (L_max : ℕ) (S : Finset (ι × ℕ)) (H : ℕ) : ℕ :=
  ∑ k ∈ Finset.range L_max, (L_max - 1 - k) * (binSlice S H k).card

theorem elemCredit_empty {ι : Type*} (L_max H : ℕ) :
    elemCredit L_max (∅ : Finset (ι × ℕ)) H = 0 := by
  simp [elemCredit, binSlice]

theorem elemCredit_subset {ι : Type*} (L_max H : ℕ) {S₁ S₂ : Finset (ι × ℕ)} (hsub : S₁ ⊆ S₂) :
    elemCredit L_max S₁ H ≤ elemCredit L_max S₂ H := by
  unfold elemCredit
  refine Finset.sum_le_sum fun k _ => Nat.mul_le_mul_left _ ?_
  unfold binSlice
  exact Finset.card_le_card (Finset.filter_subset_filter _ hsub)

theorem binSlice_insert_carryLevel {ι : Type*} [DecidableEq ι]
    (S₀ : Finset (ι × ℕ)) (rec : ι × ℕ) (H : ℕ)
    (hS₀ : ∀ r ∈ S₀, r.2 < H) (hrec : rec.2 = H) :
    let k₀ := carryLevel H
    let S₁ := insert rec S₀
    rec ∈ binSlice S₁ (H + 1) k₀ ∧
    (binSlice S₁ (H + 1) k₀).card = 1 + ∑ k ∈ Finset.range k₀, (binSlice S₀ H k).card ∧
    (∀ k < k₀, binSlice S₁ (H + 1) k = ∅) ∧
    (∀ k, k₀ < k → binSlice S₁ (H + 1) k = binSlice S₀ H k) := by
  dsimp only
  rcases carryLevel_spec H with ⟨h_lt, ⟨hnb_H, hb_H1⟩, ⟨hp_hi, hp_lo, _⟩, h_gt⟩
  set k₀ := carryLevel H
  set S₁ := insert rec S₀
  have hrec_not_mem : rec ∉ S₀ := fun hm => by have := hS₀ rec hm; omega
  have hrec_in : rec ∈ binSlice S₁ (H + 1) k₀ := by
    rw [binSlice, Finset.mem_filter]
    refine ⟨Finset.mem_insert_self _ _, ?_, ?_⟩
    · rw [hp_lo, hrec]; exact prefixEnd_le_self H k₀
    · rw [hp_hi, hrec]; omega
  have hslice_eq : binSlice S₁ (H + 1) k₀ =
      insert rec ((Finset.range k₀).biUnion (fun k => binSlice S₀ H k)) := by
    rw [biUnion_range_binSlice]
    ext r
    simp only [binSlice, S₁, Finset.mem_filter, Finset.mem_insert, hp_lo, hp_hi]
    constructor
    · rintro ⟨rfl | hrS, hlo, hhi⟩
      · exact Or.inl rfl
      · exact Or.inr ⟨hrS, hlo, hS₀ r hrS⟩
    · rintro (rfl | ⟨hrS, hlo, hhi⟩)
      · exact ⟨Or.inl rfl, by rw [hrec]; exact prefixEnd_le_self H k₀, by omega⟩
      · exact ⟨Or.inr hrS, hlo, by omega⟩
  have hrec_not_biUnion : rec ∉ (Finset.range k₀).biUnion (fun k => binSlice S₀ H k) := by
    rw [biUnion_range_binSlice, Finset.mem_filter]
    rintro ⟨_, _, hlt⟩
    omega
  have hcard : (binSlice S₁ (H + 1) k₀).card =
      1 + ∑ k ∈ Finset.range k₀, (binSlice S₀ H k).card := by
    rw [hslice_eq, Finset.card_insert_of_notMem hrec_not_biUnion, add_comm 1,
        Finset.card_biUnion (fun k₁ _ k₂ _ hne => disjoint_binSlice S₀ H hne)]
  refine ⟨hrec_in, hcard, ?_, ?_⟩
  · intro k hk
    exact binSlice_eq_empty_of_not_bitActive S₁ (h_lt k hk).2
  · intro k hk
    have hpe_k : prefixEnd (H + 1) k = prefixEnd H k := (h_gt k hk).2
    have hpe_k1 : prefixEnd (H + 1) (k + 1) = prefixEnd H (k + 1) := (h_gt (k + 1) (by omega)).2
    have hpe_le_H : prefixEnd H k ≤ H := prefixEnd_le_self H k
    ext r
    simp only [binSlice, S₁, Finset.mem_filter, Finset.mem_insert, hpe_k, hpe_k1]
    constructor
    · rintro ⟨rfl | hrS, hlo, hhi⟩
      · omega
      · exact ⟨hrS, hlo, hhi⟩
    · rintro ⟨hrS, hlo, hhi⟩
      exact ⟨Or.inr hrS, hlo, hhi⟩

theorem elemCredit_insert_bound {ι : Type*} [DecidableEq ι]
    {L_max H : ℕ} (S₀ : Finset (ι × ℕ)) (rec : ι × ℕ)
    (hS₀ : ∀ r ∈ S₀, r.2 < H) (hrec : rec.2 = H)
    (hk₀_lt : carryLevel H < L_max) :
    (binSlice (insert rec S₀) (H + 1) (carryLevel H)).card +
      elemCredit L_max (insert rec S₀) (H + 1) ≤
    L_max + elemCredit L_max S₀ H := by
  rcases binSlice_insert_carryLevel S₀ rec H hS₀ hrec with ⟨_, hcard_k₀, h_lt_empty, h_gt_eq⟩
  set k₀ := carryLevel H
  set S₁ := insert rec S₀
  have hnb_k₀ : ¬ BitActive H k₀ := (carryLevel_spec H).2.1.1
  have hk₀_old_zero : (binSlice S₀ H k₀).card = 0 := by
    rw [binSlice_eq_empty_of_not_bitActive S₀ hnb_k₀, Finset.card_empty]
  -- Split `Finset.range L_max` into `< k₀`, `= k₀`, and `> k₀` via `L_max = (k₀ + 1) + (L_max - 1 - k₀)`
  have hsplit : ∀ f : ℕ → ℕ,
      ∑ k ∈ Finset.range L_max, f k =
        (∑ k ∈ Finset.range k₀, f k) + f k₀ +
          ∑ k ∈ (Finset.range L_max).filter (fun k => k₀ < k), f k := by
    intro f
    have hpart1 : Finset.range L_max =
        Finset.range (k₀ + 1) ∪ (Finset.range L_max).filter (fun k => k₀ < k) := by
      ext k
      simp only [Finset.mem_range, Finset.mem_union, Finset.mem_filter]
      omega
    have hdisj1 : Disjoint (Finset.range (k₀ + 1))
        ((Finset.range L_max).filter (fun k => k₀ < k)) := by
      rw [Finset.disjoint_left]
      intro k hk1 hk2
      simp only [Finset.mem_range, Finset.mem_filter] at hk1 hk2
      omega
    calc
      ∑ k ∈ Finset.range L_max, f k
          = ∑ k ∈ Finset.range (k₀ + 1) ∪ (Finset.range L_max).filter (fun k => k₀ < k), f k := by
              conv_lhs => rw [hpart1]
      _ = (∑ k ∈ Finset.range (k₀ + 1), f k) +
            ∑ k ∈ (Finset.range L_max).filter (fun k => k₀ < k), f k :=
              Finset.sum_union hdisj1
      _ = (∑ k ∈ Finset.range k₀, f k) + f k₀ +
            ∑ k ∈ (Finset.range L_max).filter (fun k => k₀ < k), f k := by
              rw [Finset.sum_range_succ]
  unfold elemCredit
  rw [hsplit (fun k => (L_max - 1 - k) * (binSlice S₁ (H + 1) k).card),
      hsplit (fun k => (L_max - 1 - k) * (binSlice S₀ H k).card)]
  have h_lt_sum_zero : ∑ k ∈ Finset.range k₀, (L_max - 1 - k) * (binSlice S₁ (H + 1) k).card = 0 := by
    refine Finset.sum_eq_zero fun k hk => ?_
    rw [h_lt_empty k (Finset.mem_range.mp hk), Finset.card_empty, mul_zero]
  have h_gt_sum_eq :
      ∑ k ∈ (Finset.range L_max).filter (fun k => k₀ < k),
          (L_max - 1 - k) * (binSlice S₁ (H + 1) k).card =
      ∑ k ∈ (Finset.range L_max).filter (fun k => k₀ < k),
          (L_max - 1 - k) * (binSlice S₀ H k).card := by
    refine Finset.sum_congr rfl fun k hk => ?_
    rw [h_gt_eq k (Finset.mem_filter.mp hk).2]
  rw [h_lt_sum_zero, zero_add, hk₀_old_zero, mul_zero, add_zero, h_gt_sum_eq]
  set M := (binSlice S₁ (H + 1) k₀).card
  set tail := ∑ k ∈ (Finset.range L_max).filter (fun k => k₀ < k),
      (L_max - 1 - k) * (binSlice S₀ H k).card
  have hcomb : M + (L_max - 1 - k₀) * M = (L_max - k₀) * M := by
    have h1 : 1 + (L_max - 1 - k₀) = L_max - k₀ := by omega
    calc
      M + (L_max - 1 - k₀) * M = (1 + (L_max - 1 - k₀)) * M := by ring
      _ = (L_max - k₀) * M := by rw [h1]
  have hsum_ge :
      (L_max - k₀) * (∑ k ∈ Finset.range k₀, (binSlice S₀ H k).card) ≤
        ∑ k ∈ Finset.range k₀, (L_max - 1 - k) * (binSlice S₀ H k).card := by
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum fun k hk => ?_
    have hk_lt : k < k₀ := Finset.mem_range.mp hk
    exact Nat.mul_le_mul_right _ (by omega)
  have hmain : M + (L_max - 1 - k₀) * M ≤
      L_max + ∑ k ∈ Finset.range k₀, (L_max - 1 - k) * (binSlice S₀ H k).card := by
    rw [hcomb]
    have hM_eq : M = 1 + ∑ k ∈ Finset.range k₀, (binSlice S₀ H k).card := hcard_k₀
    rw [hM_eq, mul_add, mul_one]
    exact add_le_add (by omega) hsum_ge
  omega

/-! ### 4. Real, Log, Exponential, and `BirthPoolPolyFactors` Bounds -/

theorem exp_half_le_two : Real.exp (1 / 2) ≤ 2 := by
  have h1 : (- (1 / 2 : ℝ)) + 1 ≤ Real.exp (- (1 / 2 : ℝ)) := Real.add_one_le_exp _
  have hpos : 0 < Real.exp (1 / 2) := Real.exp_pos _
  have hmul : (-(1 / 2 : ℝ) + 1) * (2 * Real.exp (1 / 2)) ≤
      Real.exp (- (1 / 2 : ℝ)) * (2 * Real.exp (1 / 2)) :=
    mul_le_mul_of_nonneg_right h1 (by positivity)
  have hlhs : (-(1 / 2 : ℝ) + 1) * (2 * Real.exp (1 / 2)) = Real.exp (1 / 2) := by ring
  have hrhs : Real.exp (- (1 / 2 : ℝ)) * (2 * Real.exp (1 / 2)) = 2 := by
    calc
      Real.exp (- (1 / 2 : ℝ)) * (2 * Real.exp (1 / 2))
          = 2 * (Real.exp (- (1 / 2 : ℝ)) * Real.exp (1 / 2)) := by ring
      _ = 2 * Real.exp (- (1 / 2 : ℝ) + 1 / 2) := by rw [← Real.exp_add]
      _ = 2 := by norm_num
  linarith

theorem half_le_log_two : (1 / 2 : ℝ) ≤ Real.log 2 := by
  have h := Real.log_le_log (Real.exp_pos (1 / 2)) exp_half_le_two
  rwa [Real.log_exp] at h

theorem exp_one_le_four : Real.exp 1 ≤ 4 := by
  have h := exp_half_le_two
  have hpos : 0 ≤ Real.exp (1 / 2) := (Real.exp_pos _).le
  calc
    Real.exp 1 = Real.exp (1 / 2 + 1 / 2) := by norm_num
    _ = Real.exp (1 / 2) * Real.exp (1 / 2) := Real.exp_add _ _
    _ ≤ 2 * 2 := mul_le_mul h h hpos (by norm_num)
    _ = 4 := by norm_num

theorem quarter_pow_le_exp_neg (k : ℕ) : (1 / 4 : ℝ) ^ k ≤ Real.exp (- (k : ℝ)) := by
  have h1 : (1 / 4 : ℝ) ≤ Real.exp (-1) := by
    rw [Real.exp_neg]
    have h4 : Real.exp 1 ≤ 4 := exp_one_le_four
    have hepos : 0 < Real.exp 1 := Real.exp_pos 1
    rw [one_div, inv_le_inv₀ (by norm_num) hepos]
    exact h4
  calc
    (1 / 4 : ℝ) ^ k ≤ (Real.exp (-1)) ^ k := pow_le_pow_left₀ (by norm_num) h1 k
    _ = Real.exp ((k : ℝ) * (-1)) := (Real.exp_nat_mul (-1) k).symm
    _ = Real.exp (- (k : ℝ)) := by ring_nf

theorem log_two_n_Plife_nonneg {n : ℕ} {P_life : ℝ} (hn : 2 ≤ n) (hP : 1 ≤ P_life) :
    0 ≤ Real.log (2 * (n : ℝ) * P_life) := by
  apply Real.log_nonneg
  have hn' : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  nlinarith

theorem log_succ_le_two_one_add_log {M n : ℕ} {P_life : ℝ}
    (hn : 2 ≤ n) (hP : 1 ≤ P_life) (hM : (M : ℝ) ≤ (n : ℝ) * P_life) :
    (Nat.log 2 M + 1 : ℝ) ≤ 2 * (1 + Real.log (2 * (n : ℝ) * P_life)) := by
  have hlog_nn := log_two_n_Plife_nonneg hn hP
  by_cases hM0 : M = 0
  · subst hM0
    simp only [Nat.log_zero_right, CharP.cast_eq_zero, zero_add]
    linarith
  · have hpow_nat : 2 ^ Nat.log 2 M ≤ M := Nat.pow_log_le_self 2 hM0
    have hpow_real : (2 : ℝ) ^ Nat.log 2 M ≤ 2 * (n : ℝ) * P_life := by
      have h1 : (2 : ℝ) ^ Nat.log 2 M ≤ (M : ℝ) := by exact_mod_cast hpow_nat
      have hn' : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
      linarith
    have hlog_le : Real.log ((2 : ℝ) ^ Nat.log 2 M) ≤ Real.log (2 * (n : ℝ) * P_life) :=
      Real.log_le_log (by positivity) hpow_real
    rw [Real.log_pow] at hlog_le
    have hhalf := half_le_log_two
    have hl_nn : (0 : ℝ) ≤ (Nat.log 2 M : ℝ) := Nat.cast_nonneg _
    have hmul : (Nat.log 2 M : ℝ) * (1 / 2) ≤ (Nat.log 2 M : ℝ) * Real.log 2 :=
      mul_le_mul_of_nonneg_left hhalf hl_nn
    linarith

theorem badGroup_prob_scaled_le_one {rem maxOps n Ncard : ℕ} {P_life netLogBound : ℝ}
    (hn : 2 ≤ n) (hP : 1 ≤ P_life) (hnet : 0 ≤ netLogBound)
    (hN : Real.log ((Ncard : ℝ) + 1) ≤ netLogBound)
    (hmax : (maxOps : ℝ) ≤ (n : ℝ) * P_life)
    (hrem : rem ≤ maxOps) :
    (rem * (n + 1) : ℝ) *
      ((Ncard : ℝ) *
        (1 / 4 : ℝ) ^ (3 * Nat.ceil (1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound))) ≤ 1 := by
  set B : ℝ := 1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound
  set R : ℕ := 3 * Nat.ceil B
  have hn_real : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have h2nP_pos : 0 < 2 * (n : ℝ) * P_life := by positivity
  have hB_le_ceil : B ≤ (Nat.ceil B : ℝ) := Nat.le_ceil B
  have h3B_le_R : 3 * B ≤ (R : ℝ) := by
    dsimp [R]
    push_cast
    linarith
  have hN_le_exp : (Ncard : ℝ) ≤ Real.exp netLogBound := by
    have hexp := Real.exp_le_exp.mpr hN
    rw [Real.exp_log (by positivity)] at hexp
    linarith
  have hpow_le : (1 / 4 : ℝ) ^ R ≤ ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ * Real.exp (- netLogBound) := by
    calc
      (1 / 4 : ℝ) ^ R ≤ Real.exp (- (R : ℝ)) := quarter_pow_le_exp_neg R
      _ ≤ Real.exp (- (3 * B)) := Real.exp_le_exp.mpr (by linarith)
      _ ≤ Real.exp (- (3 : ℝ) * Real.log (2 * (n : ℝ) * P_life) - netLogBound) := by
            apply Real.exp_le_exp.mpr
            dsimp [B]
            linarith
      _ = Real.exp (- ((3 : ℕ) * Real.log (2 * (n : ℝ) * P_life))) * Real.exp (- netLogBound) := by
            rw [sub_eq_add_neg, Real.exp_add]
            norm_num
      _ = ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ * Real.exp (- netLogBound) := by
            rw [Real.exp_neg, Real.exp_nat_mul, Real.exp_log h2nP_pos]
  have hN_pow_le : (Ncard : ℝ) * (1 / 4 : ℝ) ^ R ≤ ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ := by
    calc
      (Ncard : ℝ) * (1 / 4 : ℝ) ^ R
          ≤ Real.exp netLogBound * (((2 * (n : ℝ) * P_life) ^ 3)⁻¹ * Real.exp (- netLogBound)) :=
            mul_le_mul hN_le_exp hpow_le (by positivity) (Real.exp_pos _).le
      _ = ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ * (Real.exp netLogBound * Real.exp (- netLogBound)) := by
            ring
      _ = ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ := by
            rw [← Real.exp_add, add_neg_cancel, Real.exp_zero, mul_one]
  have hrem_le : (rem * (n + 1) : ℝ) ≤ (2 * (n : ℝ) * P_life) ^ 3 := by
    have hr1 : (rem : ℝ) ≤ (maxOps : ℝ) := by exact_mod_cast hrem
    have hr2 : (rem : ℝ) ≤ (n : ℝ) * P_life := hr1.trans hmax
    have hn1 : (n + 1 : ℝ) ≤ 2 * (n : ℝ) := by
      push_cast
      linarith
    have hmul1 : (rem : ℝ) * (n + 1 : ℝ) ≤ ((n : ℝ) * P_life) * (2 * (n : ℝ)) :=
      mul_le_mul hr2 hn1 (by positivity) (by positivity)
    have hcube : ((n : ℝ) * P_life) * (2 * (n : ℝ)) ≤ (2 * (n : ℝ) * P_life) ^ 3 := by
      have h1 : 1 ≤ 4 * (n : ℝ) * P_life ^ 2 := by nlinarith
      calc
        ((n : ℝ) * P_life) * (2 * (n : ℝ)) = (2 * (n : ℝ) ^ 2 * P_life) * 1 := by ring
        _ ≤ (2 * (n : ℝ) ^ 2 * P_life) * (4 * (n : ℝ) * P_life ^ 2) :=
              mul_le_mul_of_nonneg_left h1 (by positivity)
        _ = (2 * (n : ℝ) * P_life) ^ 3 := by ring
    push_cast at hmul1 ⊢
    linarith
  calc
    (rem * (n + 1) : ℝ) * ((Ncard : ℝ) * (1 / 4 : ℝ) ^ R)
        ≤ ((2 * (n : ℝ) * P_life) ^ 3) * ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ :=
          mul_le_mul hrem_le hN_pow_le (by positivity) (by positivity)
    _ = 1 := mul_inv_cancel₀ (pow_ne_zero 3 h2nP_pos.ne')

theorem targetTime_ge_one {n : ℕ} {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hn : 2 ≤ n) (hθ : 0 ≤ θ) (hfacs : facs.Valid) :
    1 ≤ facs.targetTime n θ := by
  unfold UL.BirthPoolPolyFactors.targetTime UL.birthPoolTargetTime
  have hn1 : (1 : ℝ) ≤ (n : ℝ) ^ θ := Real.one_le_rpow (by exact_mod_cast (by omega : 1 ≤ n)) hθ
  have hPt : 1 ≤ facs.P_time := hfacs.1
  nlinarith

theorem spaceBound_mono_le {m n : ℕ} {σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hmn : m ≤ n) (hσ : 0 ≤ σ) (hfacs : facs.Valid) :
    facs.spaceBound m σ ≤ facs.spaceBound n σ := by
  unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
  have hPs : 0 ≤ facs.P_space := by linarith [hfacs.2.1]
  have hrp : (m : ℝ) ^ (1 + σ) ≤ (n : ℝ) ^ (1 + σ) :=
    Real.rpow_le_rpow (Nat.cast_nonneg m) (by exact_mod_cast hmn) (by linarith)
  exact mul_le_mul_of_nonneg_right hrp hPs

theorem spaceBound_ge_one {n : ℕ} {σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hn : 2 ≤ n) (hσ : 0 ≤ σ) (hfacs : facs.Valid) :
    1 ≤ facs.spaceBound n σ := by
  unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
  have hrp : (1 : ℝ) ≤ (n : ℝ) ^ (1 + σ) :=
    Real.one_le_rpow (by exact_mod_cast (by omega : 1 ≤ n)) (by linarith)
  have hPs : 1 ≤ facs.P_space := hfacs.2.1
  nlinarith

theorem buildWorkBound_eq_mul_one (facs : UL.BirthPoolPolyFactors) (m n : ℕ) (θ : ℝ) :
    facs.buildWorkBound m n θ = (m : ℝ) * facs.buildWorkBound 1 n θ := by
  unfold UL.BirthPoolPolyFactors.buildWorkBound UL.birthPoolBuildWorkBound
  simp [mul_assoc]

theorem buildWorkBound_one_ge_one {n : ℕ} {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hn : 2 ≤ n) (hθ : 0 ≤ θ) (hfacs : facs.Valid) :
    1 ≤ facs.buildWorkBound 1 n θ := by
  unfold UL.BirthPoolPolyFactors.buildWorkBound UL.birthPoolBuildWorkBound
  have ht := targetTime_ge_one hn hθ hfacs
  have hPb : 1 ≤ facs.P_build := hfacs.2.2.1
  simp only [Nat.cast_one, one_mul]
  nlinarith

theorem deleteWorkBound_ge_one {n : ℕ} {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hn : 2 ≤ n) (hθ : 0 ≤ θ) (hfacs : facs.Valid) :
    1 ≤ facs.deleteWorkBound n θ := by
  unfold UL.BirthPoolPolyFactors.deleteWorkBound UL.birthPoolDeleteWorkBound
  have ht := targetTime_ge_one hn hθ hfacs
  have hPd : 1 ≤ facs.P_del := hfacs.2.2.2.1
  nlinarith

theorem queryWorkBound_ge_one {n : ℕ} {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hn : 2 ≤ n) (hθ : 0 ≤ θ) (hfacs : facs.Valid) :
    1 ≤ facs.queryWorkBound n θ := by
  unfold UL.BirthPoolPolyFactors.queryWorkBound UL.birthPoolQueryWorkBound
  have ht := targetTime_ge_one hn hθ hfacs
  have hPq : 1 ≤ facs.P_query := hfacs.2.2.2.2
  nlinarith

end UL.Proof_lem_7_1_RaceV31
