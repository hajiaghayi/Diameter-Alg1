import Mathlib
import UL.Stmt.lem_7_1
import UL.Proof.lem_7_1.RaceV31_H1_Coins
import UL.Proof.lem_7_1.RaceV31_H2_Dyadic
import UL.Proof.lem_7_1.RaceV31_H4a_Pot
import UL.Proof.lem_7_1.RaceV31_H4b_CertStep
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. Combinatorial List Helpers for Disjoint Retire/Keep & `groupSlots` -/

theorem filter_disjoint_flatMap_of_nodup {α β : Type*} [DecidableEq β]
    (l : List α) (f : α → List β) (p : α → Bool)
    (hnd : (l.flatMap f).Nodup)
    {x : α} (hx : x ∈ l.filter p) {b : β} (hb : b ∈ f x) :
    b ∉ (l.filter (fun y => !p y)).flatMap f := by
  induction l with
  | nil => simp at hx
  | cons hd tl ih =>
    rw [List.flatMap_cons, List.nodup_append] at hnd
    rcases hnd with ⟨_, hnd_tl, hdisj⟩
    cases hp : p hd with
    | true =>
      simp only [List.filter_cons, hp, ↓reduceIte, Bool.not_true] at hx ⊢
      rcases List.mem_cons.mp hx with rfl | hxtl
      · intro hmem
        have hmem_tl : b ∈ tl.flatMap f := by
          rcases List.mem_flatMap.mp hmem with ⟨y, hy, hby⟩
          exact List.mem_flatMap.mpr ⟨y, List.mem_of_mem_filter hy, hby⟩
        exact hdisj b hb b hmem_tl rfl
      · exact ih hnd_tl hxtl
    | false =>
      simp only [List.filter_cons, hp, Bool.false_eq_true, ↓reduceIte, Bool.not_false,
        List.flatMap_cons, List.mem_append, not_or] at hx ⊢
      refine ⟨?_, ih hnd_tl hx⟩
      intro hb_hd
      have hb_tl : b ∈ tl.flatMap f :=
        List.mem_flatMap.mpr ⟨x, List.mem_of_mem_filter hx, hb⟩
      exact hdisj b hb_hd b hb_tl rfl

theorem filter_filter_length_le {α : Type*} (l : List α) (p q : α → Bool) :
    ((l.filter p).filter q).length ≤ (l.filter q).length := by
  induction l with
  | nil => simp
  | cons a tl ih =>
    cases hp : p a <;> cases hq : q a <;> simp only [List.filter_cons, hp, hq, ↓reduceIte, Bool.false_eq_true, List.length_cons] <;> omega

theorem groupSlots_of_sublist_nodup {ι : Type} {d_s : ℕ} {B P : Type}
    (tbl : UL.HostedCertTable ι d_s B P)
    (hnd : (tbl.slots.map UL.HostedCertSlot.slotId).Nodup)
    (sub : List (UL.HostedCertSlot ι d_s B P))
    (hsub : ∀ sl ∈ sub, sl ∈ tbl.slots) :
    groupSlots tbl (sub.map UL.HostedCertSlot.slotId) = sub := by
  unfold groupSlots
  induction sub with
  | nil => rfl
  | cons sl tl ih =>
    have hsl : sl ∈ tbl.slots := hsub sl List.mem_cons_self
    have hf := list_find?_eq_some_of_mem_nodup tbl.slots UL.HostedCertSlot.slotId hnd hsl
    have htl := ih fun x hx => hsub x (List.mem_cons_of_mem sl hx)
    simp only [List.map_cons, List.filterMap_cons, hf, htl]

theorem table_space_le_of_slots {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n M_slots : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h σ : ℝ} {facs : UL.BirthPoolPolyFactors}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hn : 2 ≤ n) (hσ : 0 ≤ σ) (hfacs : facs.Valid)
    {tbl : UL.HostedCertTable ι d_s B P}
    (hact : tbl.activeLifetimes.card ≤ n)
    (hlen : tbl.slots.length ≤ M_slots)
    (hslots : ∀ sl ∈ tbl.slots, CertSlotInv n pts h σ facs mkCert sl) :
    (tbl.currentSpace : ℝ) ≤ (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ := by
  unfold UL.HostedCertTable.currentSpace
  rw [Nat.cast_add]
  have hn_le_sp : (n : ℝ) ≤ facs.spaceBound n σ := by
    unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
    have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
    have hrpow : (n : ℝ) ^ (1 : ℝ) ≤ (n : ℝ) ^ (1 + σ) :=
      Real.rpow_le_rpow_of_exponent_le hn1 (by linarith)
    rw [Real.rpow_one] at hrpow
    have hPs : 1 ≤ facs.P_space := hfacs.2.1
    nlinarith [Real.rpow_nonneg (by positivity : (0 : ℝ) ≤ n) (1 + σ)]
  have hact_le : (tbl.activeLifetimes.card : ℝ) ≤ facs.spaceBound n σ :=
    (by exact_mod_cast hact : (tbl.activeLifetimes.card : ℝ) ≤ n).trans hn_le_sp
  have hsum_le : ∀ l : List (UL.HostedCertSlot ι d_s B P),
      (∀ sl ∈ l, (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ) →
      (((l.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
        (l.length : ℝ) * (2 * facs.spaceBound n σ) := by
    intro l
    induction l with
    | nil => intro _; simp
    | cons sl tl ih =>
      intro hall
      have h1 : (sl.spaceAlloc : ℝ) ≤ 2 * facs.spaceBound n σ := hall sl List.mem_cons_self
      have h2 : (((tl.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
          (tl.length : ℝ) * (2 * facs.spaceBound n σ) :=
        ih fun x hx => hall x (List.mem_cons_of_mem sl hx)
      calc
        ((((sl :: tl).map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ)
            = (sl.spaceAlloc : ℝ) + (((tl.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) := by
              simp [List.map_cons, List.sum_cons, Nat.cast_add]
        _ ≤ 2 * facs.spaceBound n σ + (tl.length : ℝ) * (2 * facs.spaceBound n σ) :=
              add_le_add h1 h2
        _ = ((sl :: tl).length : ℝ) * (2 * facs.spaceBound n σ) := by
              simp [List.length_cons, Nat.cast_add]
              ring
  have hslots_sp := hsum_le tbl.slots (fun sl hsl => (hslots sl hsl).2.2.2.2.2.1)
  have hlen_r : (tbl.slots.length : ℝ) ≤ (M_slots : ℝ) := by exact_mod_cast hlen
  have hsp_nn : 0 ≤ facs.spaceBound n σ := by linarith [spaceBound_ge_one hn hσ hfacs]
  have hslots_sp2 :
      (((tbl.slots.map UL.HostedCertSlot.spaceAlloc).sum : ℕ) : ℝ) ≤
        (M_slots : ℝ) * (2 * facs.spaceBound n σ) :=
    hslots_sp.trans (mul_le_mul_of_nonneg_right hlen_r (by linarith))
  linarith

/-! ### 2. Sequential `r`-Copy Group Opening + Finish Specification (`runCertOpenFinish_spec`) -/

open Classical in
theorem runCertOpenFinish_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n M_slots R : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound : ℝ} (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    (extHist : UL.ExecutionHistory d) (id₀ : ι)
    (groups : List (CertGroupMeta ι d_s))
    (gen : UL.SearchGeneration (ι × ℕ) d_s)
    (hgen_m1 : 1 ≤ gen.m) (hgen_mn : gen.m ≤ n) (hgen_h : gen.h = h)
    (hgen_pts : ∀ p ∈ gen.P₀, gen.pts p = pts p.1)
    (restFuel : ℕ) :
    ∀ (r : ℕ) (tbl : UL.HostedCertTable ι d_s B P) (accW peakSp : ℕ),
      gen.P₀ ⊆ tbl.activeLifetimes →
      tbl.activeLifetimes.card ≤ n →
      tbl.slots.length + r ≤ M_slots →
      (peakSp : ℝ) ≤ (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ →
      (∀ sl ∈ tbl.slots, sl.slotId < tbl.nextSlotId) →
      (tbl.slots.map UL.HostedCertSlot.slotId).Nodup →
      (∀ sl ∈ tbl.slots, CertSlotInv n pts h σ facs mkCert sl) →
      let cap := certCap n θ facs
      let f_open := fun bs =>
        UL.runCertHostedStepFuel n pts h mkCert
          (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
          extHist (.insert id₀) (r + (restFuel + 1))
          { groups := groups,
            queue := some (List.replicate r (PlannedCertCmd.openCertSlot gen) ++
              [PlannedCertCmd.finishCertUpdate]) }
          tbl bs accW peakSp
      haltProb f_open = 1 ∧
      (∀ bs out, f_open bs = some out →
        out.nextState.1 = { groups := groups, queue := none } ∧
        out.queryAnswer = none ∧
        out.nextState.2.activeLifetimes = tbl.activeLifetimes ∧
        out.nextState.2.nextLifetime = tbl.nextLifetime ∧
        out.nextState.2.nextSlotId = tbl.nextSlotId + r ∧
        (out.nextState.2.slots.map UL.HostedCertSlot.slotId).Nodup ∧
        (∀ sl ∈ out.nextState.2.slots, sl.slotId < out.nextState.2.nextSlotId) ∧
        (∀ sl ∈ out.nextState.2.slots, CertSlotInv n pts h σ facs mkCert sl) ∧
        (out.peakSpace : ℝ) ≤ (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ ∧
        ∃ newSlots : List (UL.HostedCertSlot ι d_s B P),
          out.nextState.2.slots = tbl.slots ++ newSlots ∧
          newSlots.map UL.HostedCertSlot.slotId =
            (List.range r).map (fun j => tbl.nextSlotId + j) ∧
          (∀ sl ∈ newSlots, sl.gen = gen ∧ sl.surviving = gen.P₀)) ∧
      expWithBits f_open (fun out => (out.work : ENNReal) + slotPot mkCert out.nextState.2) ≤
        ((accW + 1 : ℕ) : ENNReal) + slotPot mkCert tbl +
          (r : ENNReal) * ENNReal.ofReal (facs.buildWorkBound gen.m n θ + (gen.m : ℝ) + 1) ∧
      (∀ z ∈ N,
        expWithBits f_open (fun out =>
          if (∀ b ∈ (out.nextState.2.slots.drop tbl.slots.length).map UL.HostedCertSlot.bState,
                (cap : ℝ) < (mkCert gen).birthVar b z)
          then (1 : ENNReal) else 0) ≤
        ENNReal.ofReal ((1 / 4 : ℝ) ^ r)) := by
  intro r
  induction r with
  | zero =>
    intro tbl accW peakSp hP_sub hact_le hlen_le hpeak_le hsl_lt hsl_nd hsl_inv
    dsimp only []
    set cap := certCap n θ facs
    have hval : ValidCertTable n h mkCert tbl := by
      intro sl hsl
      rcases hsl_inv sl hsl with ⟨_, h1, h2, _, h3, _, h4⟩
      exact ⟨h1, h2, h3, h4⟩
    have hfuel0 : 0 + (restFuel + 1) = restFuel + 1 := Nat.zero_add _
    let out₀ : UL.DynamicSearchStepOutcome
        (CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P) ι :=
      { nextState := ({ groups := groups, queue := none }, tbl)
        queryAnswer := none
        work := accW + 1
        peakSpace := max peakSp tbl.currentSpace }
    have hf_eq :
        (fun bs =>
          UL.runCertHostedStepFuel n pts h mkCert
            (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
            extHist (.insert id₀) (0 + (restFuel + 1))
            { groups := groups,
              queue := some (List.replicate 0 (PlannedCertCmd.openCertSlot gen) ++
                [PlannedCertCmd.finishCertUpdate]) }
            tbl bs accW peakSp) =
        endWithEmpty out₀ := by
      simp only [hfuel0, List.replicate_zero, List.nil_append]
      exact runCertFinishUpdate_eq n pts h h_pos h_lt_one R cap mkCert
        extHist (.insert id₀) trivial restFuel groups tbl accW peakSp hval
    refine ⟨?_, ?_, ?_, ?_⟩
    · rw [hf_eq]
      exact haltProb_endWithEmpty out₀
    · intro bs out hout
      have hout' : endWithEmpty out₀ bs = some out := by
        rw [← congrFun hf_eq bs]
        exact hout
      rcases (endWithEmpty_eq_some_iff.mp hout') with ⟨_, rfl⟩
      have hcur_sp : (tbl.currentSpace : ℝ) ≤ (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ :=
        table_space_le_of_slots hσθ.1 hσθ.2.1 hfacs hact_le (by omega) hsl_inv
      refine ⟨rfl, rfl, rfl, rfl, by simp [out₀], hsl_nd, ?_, hsl_inv, ?_, [], by simp [out₀], by simp, by simp⟩
      · simpa [out₀] using hsl_lt
      · dsimp only [out₀]
        rw [Nat.cast_max]
        exact max_le hpeak_le hcur_sp
    · rw [hf_eq, expWithBits_endWithEmpty]
      simp [out₀]
    · intro z _
      rw [hf_eq, expWithBits_endWithEmpty]
      dsimp only [out₀]
      simp [List.drop_length]
  | succ r ih =>
    intro tbl accW peakSp hP_sub hact_le hlen_le hpeak_le hsl_lt hsl_nd hsl_inv
    dsimp only []
    set cap := certCap n θ facs
    have hval : ValidCertTable n h mkCert tbl := by
      intro sl hsl
      rcases hsl_inv sl hsl with ⟨_, h1, h2, _, h3, _, h4⟩
      exact ⟨h1, h2, h3, h4⟩
    rcases hCert gen hgen_mn hgen_h with ⟨hmk_gen, _, hmk_all⟩
    have hcert_hist := hmk_all extHist
    have hpf_build : IsPrefixFree ((mkCert gen).buildWithBits extHist) :=
      hcert_hist.2.2.2.2.1
    have hhalt_build : haltProb ((mkCert gen).buildWithBits extHist) = 1 :=
      hcert_hist.2.2.2.2.2.1
    have hb_caps := hcert_hist.2.2.2.2.2.2.1
    have hguard : gen.m ≤ n ∧ gen.h = h ∧ gen.P₀ ⊆ tbl.activeLifetimes ∧
        (∀ p ∈ gen.P₀, gen.pts p = pts p.1) :=
      ⟨hgen_mn, hgen_h, hP_sub, hgen_pts⟩
    let mkNewSlot (bOut : UL.CertifiedBirthOutcome B P) : UL.HostedCertSlot ι d_s B P :=
      { slotId := tbl.nextSlotId
        gen := gen
        bState := bOut.birthState
        surviving := gen.P₀
        phase := bOut.initPhase
        spaceAlloc := gen.m + bOut.peakSpace }
    let mkTbl' (bOut : UL.CertifiedBirthOutcome B P) : UL.HostedCertTable ι d_s B P :=
      { tbl with
        nextSlotId := tbl.nextSlotId + 1
        slots := tbl.slots ++ [mkNewSlot bOut] }
    let f_rest (bOut : UL.CertifiedBirthOutcome B P) : List Bool →
        Option (UL.DynamicSearchStepOutcome
          (CertCtrlState ι d_s × UL.HostedCertTable ι d_s B P) ι) :=
      fun rem' =>
        UL.runCertHostedStepFuel n pts h mkCert
          (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
          extHist (.insert id₀) (r + (restFuel + 1))
          { groups := groups,
            queue := some (List.replicate r (PlannedCertCmd.openCertSlot gen) ++
              [PlannedCertCmd.finishCertUpdate]) }
          (mkTbl' bOut) rem' (accW + bOut.work + gen.m + 1)
          (max peakSp (mkTbl' bOut).currentSpace)
    have hf_seq :
        (fun bs =>
          UL.runCertHostedStepFuel n pts h mkCert
            (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
            extHist (.insert id₀) ((r + 1) + (restFuel + 1))
            { groups := groups,
              queue := some (List.replicate (r + 1) (PlannedCertCmd.openCertSlot gen) ++
                [PlannedCertCmd.finishCertUpdate]) }
            tbl bs accW peakSp) =
        seqConsume ((mkCert gen).buildWithBits extHist) f_rest := by
      funext bs
      have hfuel_eq : (r + 1) + (restFuel + 1) = (r + (restFuel + 1)) + 1 := by omega
      rw [hfuel_eq]
      conv_lhs => unfold UL.runCertHostedStepFuel
      simp only [certStepCtrl, if_pos hval, List.replicate_succ, List.cons_append,
        dispatchCertQueue, if_pos hguard]
      unfold seqConsume
      cases UL.consumePrefixBits ((mkCert gen).buildWithBits extHist) bs <;> rfl
    have hstep_bOut : ∀ bs₁ bOut, (mkCert gen).buildWithBits extHist bs₁ = some bOut →
        CertSlotInv n pts h σ facs mkCert (mkNewSlot bOut) ∧
        (∀ sl ∈ (mkTbl' bOut).slots, sl.slotId < (mkTbl' bOut).nextSlotId) ∧
        ((mkTbl' bOut).slots.map UL.HostedCertSlot.slotId).Nodup ∧
        (∀ sl ∈ (mkTbl' bOut).slots, CertSlotInv n pts h σ facs mkCert sl) ∧
        ((max peakSp (mkTbl' bOut).currentSpace : ℕ) : ℝ) ≤
          (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ := by
      intro bs₁ bOut hb₁
      rcases hb_caps bs₁ bOut hb₁ with ⟨hbirth, hph_init, hsp_bOut⟩
      have hph_gen : (mkCert gen).IsAcceptedPhase extHist bOut.birthState gen.P₀ bOut.initPhase := by
        rwa [hmk_gen] at hph_init
      have hsp_bOut_n : (bOut.peakSpace : ℝ) ≤ facs.spaceBound n σ := by
        rw [hmk_gen] at hsp_bOut
        exact hsp_bOut.trans (spaceBound_mono_le hgen_mn hσθ.2.1 hfacs)
      have hm_le_sp : (gen.m : ℝ) ≤ facs.spaceBound n σ := by
        unfold UL.BirthPoolPolyFactors.spaceBound UL.birthPoolSpaceBound
        have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
        have hrpow : (n : ℝ) ^ (1 : ℝ) ≤ (n : ℝ) ^ (1 + σ) :=
          Real.rpow_le_rpow_of_exponent_le hn1 (by linarith [hσθ.2.1])
        rw [Real.rpow_one] at hrpow
        have hm_n : (gen.m : ℝ) ≤ (n : ℝ) := by exact_mod_cast hgen_mn
        have hPs : 1 ≤ facs.P_space := hfacs.2.1
        nlinarith [Real.rpow_nonneg (by positivity : (0 : ℝ) ≤ n) (1 + σ)]
      have hnew_inv : CertSlotInv n pts h σ facs mkCert (mkNewSlot bOut) := by
        refine ⟨hgen_m1, hgen_mn, hgen_h, hgen_pts, subset_rfl, ?_, ⟨extHist, hbirth, hph_gen⟩⟩
        dsimp only [mkNewSlot]
        rw [Nat.cast_add]
        linarith
      have hsl_lt' : ∀ sl ∈ (mkTbl' bOut).slots, sl.slotId < (mkTbl' bOut).nextSlotId := by
        intro sl hsl
        dsimp only [mkTbl'] at hsl ⊢
        rcases List.mem_append.mp hsl with h0 | h1
        · have := hsl_lt sl h0; omega
        · simp only [List.mem_singleton] at h1
          subst h1
          dsimp only [mkNewSlot]
          omega
      have hsl_nd' : ((mkTbl' bOut).slots.map UL.HostedCertSlot.slotId).Nodup := by
        dsimp only [mkTbl', mkNewSlot]
        rw [List.map_append, List.map_singleton, List.nodup_append]
        refine ⟨hsl_nd, List.nodup_singleton _, ?_⟩
        intro a ha b hb
        simp only [List.mem_singleton] at hb
        subst hb
        rcases List.mem_map.mp ha with ⟨sl, hsl, rfl⟩
        exact (hsl_lt sl hsl).ne
      have hsl_inv' : ∀ sl ∈ (mkTbl' bOut).slots, CertSlotInv n pts h σ facs mkCert sl := by
        intro sl hsl
        dsimp only [mkTbl'] at hsl
        rcases List.mem_append.mp hsl with h0 | h1
        · exact hsl_inv sl h0
        · simp only [List.mem_singleton] at h1
          subst h1
          exact hnew_inv
      have hcur_sp' : ((mkTbl' bOut).currentSpace : ℝ) ≤
          (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ := by
        refine table_space_le_of_slots hσθ.1 hσθ.2.1 hfacs hact_le ?_ hsl_inv'
        dsimp only [mkTbl']
        rw [List.length_append, List.length_singleton]
        omega
      have hmax_sp' : ((max peakSp (mkTbl' bOut).currentSpace : ℕ) : ℝ) ≤
          (1 + 2 * (M_slots : ℝ)) * facs.spaceBound n σ := by
        rw [Nat.cast_max]
        exact max_le hpeak_le hcur_sp'
      exact ⟨hnew_inv, hsl_lt', hsl_nd', hsl_inv', hmax_sp'⟩
    refine ⟨?_, ?_, ?_, ?_⟩
    · -- (1) `haltProb = 1`
      rw [hf_seq]
      refine haltProb_seqConsume hpf_build hhalt_build fun bs₁ bOut hb₁ => ?_
      rcases hstep_bOut bs₁ bOut hb₁ with ⟨_, hsl_lt', hsl_nd', hsl_inv', hmax_sp'⟩
      have hlen' : (mkTbl' bOut).slots.length + r ≤ M_slots := by
        dsimp only [mkTbl']
        rw [List.length_append, List.length_singleton]
        omega
      exact (ih (mkTbl' bOut) (accW + bOut.work + gen.m + 1)
        (max peakSp (mkTbl' bOut).currentSpace)
        hP_sub hact_le hlen' hmax_sp' hsl_lt' hsl_nd' hsl_inv').1
    · -- (2) Pathwise structural & space invariants
      intro bs out hout
      have hout' : seqConsume ((mkCert gen).buildWithBits extHist) f_rest bs = some out := by
        rw [← congrFun hf_seq bs]
        exact hout
      rcases (seqConsume_eq_some_iff hpf_build).mp hout' with ⟨bs₁, rem', bOut, rfl, hb₁, hrest⟩
      rcases hstep_bOut bs₁ bOut hb₁ with ⟨_, hsl_lt', hsl_nd', hsl_inv', hmax_sp'⟩
      have hlen' : (mkTbl' bOut).slots.length + r ≤ M_slots := by
        dsimp only [mkTbl']
        rw [List.length_append, List.length_singleton]
        omega
      rcases (ih (mkTbl' bOut) (accW + bOut.work + gen.m + 1)
        (max peakSp (mkTbl' bOut).currentSpace)
        hP_sub hact_le hlen' hmax_sp' hsl_lt' hsl_nd' hsl_inv').2.1 rem' out hrest with
        ⟨hctrl_out, hqa_out, hact_out, hnl_out, hnsid_out, hnd_out, hlt_out, hinv_out, hsp_out,
         restSlots, hslots_eq, hrest_ids, hrest_gen⟩
      refine ⟨hctrl_out, hqa_out, hact_out, hnl_out, ?_, hnd_out, hlt_out, hinv_out, hsp_out,
        mkNewSlot bOut :: restSlots, ?_, ?_, ?_⟩
      · dsimp only [mkTbl'] at hnsid_out
        omega
      · dsimp only [mkTbl'] at hslots_eq
        simpa [List.append_assoc] using hslots_eq
      · dsimp only [mkTbl'] at hrest_ids
        simp only [List.range_succ_eq_map, List.map_cons, List.map_map, mkNewSlot, Nat.add_zero, List.cons.injEq, true_and]
        rw [hrest_ids]
        refine List.map_congr_left fun j _ => ?_
        dsimp only [Function.comp]
        omega
      · intro sl hsl
        rcases List.mem_cons.mp hsl with rfl | htl
        · exact ⟨rfl, rfl⟩
        · exact hrest_gen sl htl
    · -- (3) Expected work + `slotPot` bound
      rw [hf_seq, expWithBits_seqConsume hpf_build]
      let B_step : ℝ := facs.buildWorkBound gen.m n θ + (gen.m : ℝ) + 1
      have hB_nn : 0 ≤ facs.buildWorkBound gen.m n θ := by
        rw [buildWorkBound_eq_mul_one]
        have h1 := buildWorkBound_one_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs
        exact mul_nonneg (Nat.cast_nonneg _) (by linarith)
      have hmono :
          expWithBits ((mkCert gen).buildWithBits extHist)
            (fun bOut => expWithBits (f_rest bOut)
              (fun out => (out.work : ENNReal) + slotPot mkCert out.nextState.2)) ≤
          expWithBits ((mkCert gen).buildWithBits extHist)
            (fun bOut =>
              (((accW + 1 : ℕ) : ENNReal) + slotPot mkCert tbl +
                ((gen.m + 1 : ℕ) : ENNReal) + (r : ENNReal) * ENNReal.ofReal B_step) +
              ((bOut.work : ENNReal) +
                remCopyWork (mkCert gen) bOut.birthState (mkCert gen).gen.P₀ bOut.initPhase)) := by
        refine expWithBits_mono fun bs₁ bOut hb₁ => ?_
        rcases hstep_bOut bs₁ bOut hb₁ with ⟨_, hsl_lt', hsl_nd', hsl_inv', hmax_sp'⟩
        have hlen' : (mkTbl' bOut).slots.length + r ≤ M_slots := by
          dsimp only [mkTbl']
          rw [List.length_append, List.length_singleton]
          omega
        have h_ih := (ih (mkTbl' bOut) (accW + bOut.work + gen.m + 1)
          (max peakSp (mkTbl' bOut).currentSpace)
          hP_sub hact_le hlen' hmax_sp' hsl_lt' hsl_nd' hsl_inv').2.2.1
        have hpot_eq : slotPot mkCert (mkTbl' bOut) =
            slotPot mkCert tbl +
              remCopyWork (mkCert gen) bOut.birthState (mkCert gen).gen.P₀ bOut.initPhase := by
          unfold slotPot
          dsimp only [mkTbl', mkNewSlot]
          rw [List.map_append, List.map_singleton, List.sum_append, List.sum_singleton, hmk_gen]
        refine h_ih.trans (le_of_eq ?_)
        rw [hpot_eq]
        dsimp only [B_step]
        push_cast
        ring
      refine hmono.trans ?_
      rw [expWithBits_const_add_of_haltProb_one hhalt_build]
      have hbirth_le :
          expWithBits ((mkCert gen).buildWithBits extHist)
            (fun bOut =>
              (bOut.work : ENNReal) +
                remCopyWork (mkCert gen) bOut.birthState (mkCert gen).gen.P₀ bOut.initPhase) ≤
          ENNReal.ofReal (facs.buildWorkBound gen.m n θ) := by
        have hb := birth_remCopyWork_le hcert_hist
        have hmk_m : (mkCert gen).gen.m = gen.m := congrArg UL.SearchGeneration.m hmk_gen
        rwa [hmk_m] at hb
      have hcombine :
          ((gen.m + 1 : ℕ) : ENNReal) + ENNReal.ofReal (facs.buildWorkBound gen.m n θ) =
            ENNReal.ofReal B_step := by
        dsimp only [B_step]
        have hgm1 : ((gen.m + 1 : ℕ) : ENNReal) = ENNReal.ofReal ((gen.m : ℝ) + 1) := by
          rw [Nat.cast_add, Nat.cast_one, ENNReal.ofReal_add (Nat.cast_nonneg _) zero_le_one,
            ENNReal.ofReal_natCast, ENNReal.ofReal_one]
        rw [hgm1, ← ENNReal.ofReal_add (by positivity) hB_nn]
        congr 1
        ring
      calc
        (((accW + 1 : ℕ) : ENNReal) + slotPot mkCert tbl +
            ((gen.m + 1 : ℕ) : ENNReal) + (r : ENNReal) * ENNReal.ofReal B_step) +
          expWithBits ((mkCert gen).buildWithBits extHist)
            (fun bOut =>
              (bOut.work : ENNReal) +
                remCopyWork (mkCert gen) bOut.birthState (mkCert gen).gen.P₀ bOut.initPhase)
            ≤ (((accW + 1 : ℕ) : ENNReal) + slotPot mkCert tbl +
                ((gen.m + 1 : ℕ) : ENNReal) + (r : ENNReal) * ENNReal.ofReal B_step) +
              ENNReal.ofReal (facs.buildWorkBound gen.m n θ) :=
              add_le_add le_rfl hbirth_le
        _ = ((accW + 1 : ℕ) : ENNReal) + slotPot mkCert tbl +
              (((gen.m + 1 : ℕ) : ENNReal) + ENNReal.ofReal (facs.buildWorkBound gen.m n θ)) +
              (r : ENNReal) * ENNReal.ofReal B_step := by ring
        _ = ((accW + 1 : ℕ) : ENNReal) + slotPot mkCert tbl +
              ((r + 1 : ℕ) : ENNReal) * ENNReal.ofReal B_step := by
              rw [hcombine]
              push_cast
              ring
    · -- (4) Slow-copy directional bound `≤ (1 / 4) ^ (r + 1)`
      intro z hz
      rw [hf_seq, expWithBits_seqConsume hpf_build]
      have hinner_le :
          expWithBits ((mkCert gen).buildWithBits extHist)
            (fun bOut => expWithBits (f_rest bOut) (fun out =>
              if (∀ b ∈ (out.nextState.2.slots.drop tbl.slots.length).map UL.HostedCertSlot.bState,
                    (cap : ℝ) < (mkCert gen).birthVar b z)
              then (1 : ENNReal) else 0)) ≤
          expWithBits ((mkCert gen).buildWithBits extHist)
            (fun bOut =>
              (if (cap : ℝ) < (mkCert gen).birthVar bOut.birthState z then (1 : ENNReal) else 0) *
                ENNReal.ofReal ((1 / 4 : ℝ) ^ r)) := by
        refine expWithBits_mono fun bs₁ bOut hb₁ => ?_
        rcases hstep_bOut bs₁ bOut hb₁ with ⟨_, hsl_lt', hsl_nd', hsl_inv', hmax_sp'⟩
        have hlen' : (mkTbl' bOut).slots.length + r ≤ M_slots := by
          dsimp only [mkTbl']
          rw [List.length_append, List.length_singleton]
          omega
        have ih_bOut := ih (mkTbl' bOut) (accW + bOut.work + gen.m + 1)
          (max peakSp (mkTbl' bOut).currentSpace)
          hP_sub hact_le hlen' hmax_sp' hsl_lt' hsl_nd' hsl_inv'
        have hpath_bOut := ih_bOut.2.1
        have hz_ih := ih_bOut.2.2.2 z hz
        by_cases hslow0 : (cap : ℝ) < (mkCert gen).birthVar bOut.birthState z
        · rw [if_pos hslow0, one_mul]
          refine (expWithBits_congr (fun _ => rfl) fun rem' out hrest => ?_).le.trans hz_ih
          rcases (hpath_bOut rem' out hrest).2.2.2.2.2.2.2.2.2 with ⟨restSlots, hslots_eq, _, _⟩
          have hdrop1 : out.nextState.2.slots.drop tbl.slots.length =
              mkNewSlot bOut :: restSlots := by
            have heq : out.nextState.2.slots = tbl.slots ++ (mkNewSlot bOut :: restSlots) := by
              dsimp only [mkTbl'] at hslots_eq
              simpa [List.append_assoc] using hslots_eq
            rw [heq, List.drop_left]
          have hdrop2 : out.nextState.2.slots.drop (mkTbl' bOut).slots.length = restSlots := by
            rw [hslots_eq, List.drop_left]
          rw [hdrop1, hdrop2]
          simp only [List.map_cons, List.forall_mem_cons, mkNewSlot, hslow0, true_and]
        · rw [if_neg hslow0, zero_mul]
          have hzero :
              expWithBits (f_rest bOut) (fun out =>
                if (∀ b ∈ (out.nextState.2.slots.drop tbl.slots.length).map UL.HostedCertSlot.bState,
                      (cap : ℝ) < (mkCert gen).birthVar b z)
                then (1 : ENNReal) else 0) =
              expWithBits (f_rest bOut) (fun _ => 0) := by
            refine expWithBits_congr (fun _ => rfl) fun rem' out hrest => ?_
            rcases (hpath_bOut rem' out hrest).2.2.2.2.2.2.2.2.2 with ⟨restSlots, hslots_eq, _, _⟩
            have hdrop1 : out.nextState.2.slots.drop tbl.slots.length =
                mkNewSlot bOut :: restSlots := by
              have heq : out.nextState.2.slots = tbl.slots ++ (mkNewSlot bOut :: restSlots) := by
                dsimp only [mkTbl'] at hslots_eq
                simpa [List.append_assoc] using hslots_eq
              rw [heq, List.drop_left]
            rw [hdrop1]
            simp only [List.map_cons, List.forall_mem_cons, mkNewSlot, hslow0, false_and, ↓reduceIte]
          rw [hzero, expWithBits_zero]
      refine hinner_le.trans ?_
      rw [expWithBits_mul_const]
      have hq1 :
          expWithBits ((mkCert gen).buildWithBits extHist)
            (fun bOut =>
              if (cap : ℝ) < (mkCert gen).birthVar bOut.birthState z then (1 : ENNReal) else 0) ≤
          ENNReal.ofReal (1 / 4) :=
        copy_slow_prob_le_quarter hcert_hist hz
      calc
        expWithBits ((mkCert gen).buildWithBits extHist)
            (fun bOut =>
              if (cap : ℝ) < (mkCert gen).birthVar bOut.birthState z then (1 : ENNReal) else 0) *
          ENNReal.ofReal ((1 / 4 : ℝ) ^ r)
            ≤ ENNReal.ofReal (1 / 4) * ENNReal.ofReal ((1 / 4 : ℝ) ^ r) :=
              mul_le_mul_of_nonneg_right hq1 (zero_le _)
        _ = ENNReal.ofReal ((1 / 4 : ℝ) ^ (r + 1)) := by
              rw [← ENNReal.ofReal_mul (by norm_num), pow_succ']

/-! ### 3. Full `.insert` Step Specification (`certStep_insert_spec`) -/

open Classical in
theorem certStep_insert_spec {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {n maxOps : ℕ} {pts : ι → EuclideanSpace ℝ (Fin d_s)}
    {h : ℝ} {h_pos : 0 < h} {h_lt_one : h < 1}
    {σ θ δ_margin netLogBound P_life : ℝ}
    (hσθ : UL.ValidBirthPoolExponents n σ θ)
    {facs : UL.BirthPoolPolyFactors} (hfacs : facs.Valid)
    (hPlife : 1 ≤ P_life) (hnet0 : 0 ≤ netLogBound)
    (hmaxOps : (maxOps : ℝ) ≤ (n : ℝ) * P_life)
    {N : Finset (EuclideanSpace ℝ (Fin d_s))}
    (hN_net : UL.IsValidImplicitDirectionNet N netLogBound)
    {mkCert : UL.SearchGeneration (ι × ℕ) d_s → UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hCert : ∀ gen : UL.SearchGeneration (ι × ℕ) d_s,
      gen.m ≤ n → gen.h = h →
        (mkCert gen).gen = gen ∧
        (mkCert gen).δ = δ_margin ∧
        ∀ birthHist : UL.ExecutionHistory d,
          UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N
            birthHist (mkCert gen))
    (extHist : UL.ExecutionHistory d)
    {admissibleQuery : Finset ι → UL.SearchQuery ι d_s → Prop}
    {S : Finset ι} {ctrl : CertCtrlState ι d_s} {tbl0 : UL.HostedCertTable ι d_s B P}
    (hinv : CertTableInv n maxOps (certGroupCopies n P_life netLogBound)
      pts h σ facs mkCert S ctrl tbl0)
    (hH_lt : tbl0.nextLifetime < maxOps)
    {id₀ : ι}
    (hleg : UL.IsLegalDynamicSearchOp n pts admissibleQuery S (.insert id₀)) :
    let L_max := Nat.log 2 maxOps + 1
    let R := certGroupCopies n P_life netLogBound
    let cap := certCap n θ facs
    let dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
      n pts h mkCert
    let stepFn := UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀)
    UL.singleDynamicSearchStepHaltProb dynIdx extHist S (ctrl, tbl0) (.insert id₀) = 1 ∧
    (∀ bs S' out, stepFn bs = some (S', out) →
      S' = insert id₀ S ∧
      out.queryAnswer = none ∧
      out.nextState.2.nextLifetime = tbl0.nextLifetime + 1 ∧
      CertTableInv n maxOps R pts h σ facs mkCert S' out.nextState.1 out.nextState.2 ∧
      (out.peakSpace : ℝ) ≤ (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ) ∧
    (∀ rem : ℕ, rem ≤ maxOps →
      expWithBits stepFn (fun res =>
        (res.2.work : ENNReal) +
          certPhi L_max R n θ facs N cap mkCert rem res.2.nextState.1.groups res.2.nextState.2) ≤
      certPhi L_max R n θ facs N cap mkCert (rem + 1) ctrl.groups tbl0 +
        ENNReal.ofReal (7 * (L_max : ℝ) * (R : ℝ) * facs.buildWorkBound 1 n θ)) := by
  dsimp only []
  set L_max := Nat.log 2 maxOps + 1
  set R := certGroupCopies n P_life netLogBound
  set cap := certCap n θ facs
  set dynIdx := (certController n pts h h_pos h_lt_one L_max R cap mkCert).toDynamicSearchIndex
    n pts h mkCert
  have hR_ge3 : 3 ≤ R := certGroupCopies_ge_three hσθ.1 hPlife hnet0
  rcases hleg with ⟨hid₀_not_S, hScard_le, hunit_id₀⟩
  let H := tbl0.nextLifetime
  have hH1_le : H + 1 ≤ maxOps := by omega
  let k₀ := carryLevel H
  have hk₀_lt : k₀ < L_max := carryLevel_lt_log_succ hH1_le
  let tbl1 : UL.HostedCertTable ι d_s B P :=
    { tbl0 with
      activeLifetimes := insert (id₀, H) tbl0.activeLifetimes
      nextLifetime := H + 1 }
  have hid₀_not_act : (id₀, H) ∉ tbl0.activeLifetimes := by
    intro hm
    exact hid₀_not_S (hinv.img_eq ▸ Finset.mem_image.mpr ⟨(id₀, H), hm, rfl⟩)
  have himg1 : tbl1.activeLifetimes.image Prod.fst = insert id₀ S := by
    dsimp only [tbl1]
    rw [Finset.image_insert, hinv.img_eq]
  have hcard1 : tbl1.activeLifetimes.card = (insert id₀ S).card := by
    dsimp only [tbl1]
    rw [Finset.card_insert_of_notMem hid₀_not_act, Finset.card_insert_of_notMem hid₀_not_S,
      hinv.card_eq]
  have hact1_le_n : tbl1.activeLifetimes.card ≤ n := by
    rw [hcard1]
    exact hScard_le
  have hunit1 : ∀ p ∈ tbl1.activeLifetimes, UL.IsUnitVec (pts p.1) := by
    intro p hp
    rcases Finset.mem_insert.mp hp with rfl | hp0
    · exact hunit_id₀
    · exact hinv.unit_active p hp0
  rcases binSlice_insert_carryLevel tbl0.activeLifetimes (id₀, H) H hinv.lt_next rfl with
    ⟨hrec_in_P0, hP0_card, hslice_lt, hslice_gt⟩
  let P₀ := binSlice tbl1.activeLifetimes (H + 1) k₀
  have hP0_guard : P₀.Nonempty ∧ ∀ p ∈ P₀, UL.IsUnitVec (pts p.1) := by
    refine ⟨⟨(id₀, H), hrec_in_P0⟩, fun p hp => ?_⟩
    exact hunit1 p (Finset.mem_of_mem_filter p hp)
  let gen : UL.SearchGeneration (ι × ℕ) d_s :=
    { P₀ := P₀
      pts := fun p => pts p.1
      nonempty := hP0_guard.1
      unit_pts := hP0_guard.2
      h := h
      h_pos := h_pos
      h_lt_one := h_lt_one }
  have hgen_m1 : 1 ≤ gen.m := Finset.card_pos.mpr hP0_guard.1
  have hgen_mn : gen.m ≤ n := by
    have hsub : P₀ ⊆ tbl1.activeLifetimes := Finset.filter_subset _ _
    exact (Finset.card_le_card hsub).trans hact1_le_n
  let oldGroups := ctrl.groups
  have hctrl_eq : ctrl = { groups := oldGroups, queue := none } := by
    cases ctrl with | mk g q =>
      have hq : q = none := hinv.queue_none
      subst hq; rfl
  let toRetire := oldGroups.filter (fun g => decide (g.level < k₀))
  let keptGroups := oldGroups.filter (fun g => decide (k₀ ≤ g.level))
  let rids := toRetire.flatMap CertGroupMeta.sids
  let newSids := (List.range R).map (fun j => tbl1.nextSlotId + j)
  let newGrp : CertGroupMeta ι d_s := { level := k₀, gen := gen, sids := newSids }
  let nextGroups := keptGroups ++ [newGrp]
  let cmds : List (PlannedCertCmd ι d_s) :=
    (rids.map PlannedCertCmd.retireCertSlot) ++
    List.replicate R (PlannedCertCmd.openCertSlot gen) ++
    [PlannedCertCmd.finishCertUpdate]
  have hplan : planCertStep pts h h_pos h_lt_one R cap (.insert id₀) oldGroups tbl1 =
      (nextGroups, cmds) := by
    unfold planCertStep
    exact dif_pos hP0_guard
  have hrids_le : rids.length ≤ L_max * R := by
    have h1 : rids.length ≤ toRetire.length * R :=
      flatMap_length_le_mul toRetire CertGroupMeta.sids R
        (fun g hg => (hinv.groups_inv g (List.mem_of_mem_filter hg)).2.1.le)
    have h2 : toRetire.length ≤ oldGroups.length := List.length_filter_le _ _
    exact h1.trans (Nat.mul_le_mul_right R (h2.trans hinv.groups_length_le))
  let restFuel := (L_max + 2) * R + 4 - (rids.length + R)
  have hfuel_split : certFuelBound L_max R (H + 1) = rids.length + (R + (restFuel + 1)) := by
    unfold certFuelBound
    dsimp only [restFuel]
    have hmul : (L_max + 2) * R = L_max * R + R + R := by ring
    omega
  have hval1 : ValidCertTable n h mkCert tbl1 := hinv.toValid
  let peakSp₀ := max tbl0.currentSpace tbl1.currentSpace
  let tbl_ret := applyCertRetireIds rids tbl1
  let f_open := fun bs =>
    UL.runCertHostedStepFuel n pts h mkCert
      (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
      extHist (.insert id₀) (R + (restFuel + 1))
      { groups := nextGroups,
        queue := some (List.replicate R (PlannedCertCmd.openCertSlot gen) ++
          [PlannedCertCmd.finishCertUpdate]) }
      tbl_ret bs (1 + rids.length) peakSp₀
  have hstepWithBits_eq :
      dynIdx.stepWithBits extHist S (ctrl, tbl0) (.insert id₀) = f_open := by
    funext bs
    have hact_ok : tbl0.activeLifetimes.image Prod.fst = S ∧ tbl0.activeLifetimes.card = S.card :=
      ⟨hinv.img_eq, hinv.card_eq⟩
    dsimp only [dynIdx, UL.CertHostedController.toDynamicSearchIndex, certController]
    rw [if_pos hact_ok]
    change UL.runCertHostedStepFuel n pts h mkCert
      (certStepCtrl n pts h h_pos h_lt_one R cap mkCert)
      extHist (.insert id₀) (certFuelBound L_max R (H + 1)) ctrl tbl1 bs 1 peakSp₀ = f_open bs
    have hfuel_pos : certFuelBound L_max R (H + 1) = (certFuelBound L_max R (H + 1) - 1) + 1 := by
      unfold certFuelBound; omega
    rw [hctrl_eq, hfuel_pos,
        runCertHostedStepFuel_plan_eq n pts h h_pos h_lt_one R cap mkCert
          extHist (.insert id₀) _ oldGroups nextGroups cmds tbl1 bs 1 peakSp₀ hval1 hplan,
        ← hfuel_pos, hfuel_split]
    have hcmds_assoc : cmds = (rids.map PlannedCertCmd.retireCertSlot) ++
        (List.replicate R (PlannedCertCmd.openCertSlot gen) ++ [PlannedCertCmd.finishCertUpdate]) := by
      simp [cmds, List.append_assoc]
    rw [hcmds_assoc]
    exact runCertRetireQueue_eq n pts h h_pos h_lt_one R cap mkCert
      extHist (.insert id₀) nextGroups _ rids (R + (restFuel + 1)) tbl1 bs 1 peakSp₀
      hval1 (Nat.le_max_right _ _)
  -- Relate `tbl_ret.slots` to `keptGroups` so `tbl_ret.slots.length + R ≤ L_max * R`!
  have hdisj_kept : ∀ g ∈ keptGroups, ∀ sid ∈ g.sids, sid ∉ rids := by
    intro g hg sid hsid
    have hnd_flat : (oldGroups.flatMap CertGroupMeta.sids).Nodup := by
      rw [← hinv.slotIds_eq]
      exact hinv.slotIds_nodup
    have hrew : toRetire = oldGroups.filter (fun y => !decide (k₀ ≤ y.level)) := by
      refine List.filter_congr fun y _ => ?_
      by_cases hlt : y.level < k₀
      · have hnle : ¬ (k₀ ≤ y.level) := by omega
        simp [hlt, hnle]
      · have hle : k₀ ≤ y.level := by omega
        simp [hlt, hle]
    dsimp only [rids]
    rw [hrew]
    exact filter_disjoint_flatMap_of_nodup oldGroups CertGroupMeta.sids
      (fun y => decide (k₀ ≤ y.level)) hnd_flat hg hsid
  have hret_ids_eq : tbl_ret.slots.map UL.HostedCertSlot.slotId =
      keptGroups.flatMap CertGroupMeta.sids := by
    dsimp only [tbl_ret, applyCertRetireIds, tbl1]
    have hcomp_eq :
        (tbl0.slots.filter (fun s => decide (s.slotId ∉ rids))).map UL.HostedCertSlot.slotId =
          (tbl0.slots.map UL.HostedCertSlot.slotId).filter (fun sid => decide (sid ∉ rids)) := by
      have := List.filter_map (f := UL.HostedCertSlot.slotId)
        (p := fun sid => decide (sid ∉ rids)) (l := tbl0.slots)
      exact this.symm
    rw [hcomp_eq]
    rw [hinv.slotIds_eq]
    have hgen_split :
        ∀ l : List (CertGroupMeta ι d_s),
          (l.flatMap CertGroupMeta.sids).Nodup →
          (l.flatMap CertGroupMeta.sids).filter (fun sid => decide (sid ∉
            (l.filter (fun g => decide (g.level < k₀))).flatMap CertGroupMeta.sids)) =
          (l.filter (fun g => decide (k₀ ≤ g.level))).flatMap CertGroupMeta.sids := by
      intro l
      induction l with
      | nil => intro _; simp
      | cons g tl ih =>
        intro hnd_l
        rw [List.flatMap_cons, List.nodup_append] at hnd_l
        rcases hnd_l with ⟨_, hnd_tl, hdisj_l⟩
        by_cases hlt : g.level < k₀
        · have hnle : ¬ (k₀ ≤ g.level) := by omega
          simp only [List.filter_cons, decide_eq_true_eq, hlt, ↓reduceIte, hnle,
            List.flatMap_cons, List.filter_append]
          have hg_empty : g.sids.filter (fun sid => decide (sid ∉
              g.sids ++ (tl.filter (fun x => decide (x.level < k₀))).flatMap CertGroupMeta.sids)) = [] := by
            rw [List.filter_eq_nil_iff]
            intro sid hsid
            simp [List.mem_append, hsid]
          have htl_same : (tl.flatMap CertGroupMeta.sids).filter (fun sid => decide (sid ∉
              g.sids ++ (tl.filter (fun x => decide (x.level < k₀))).flatMap CertGroupMeta.sids)) =
            (tl.flatMap CertGroupMeta.sids).filter (fun sid => decide (sid ∉
              (tl.filter (fun x => decide (x.level < k₀))).flatMap CertGroupMeta.sids)) := by
            refine List.filter_congr fun sid hsid => ?_
            have hnot_g : sid ∉ g.sids := fun hg_in => hdisj_l sid hg_in sid hsid rfl
            simp [List.mem_append, hnot_g]
          rw [hg_empty, List.nil_append, htl_same, ih hnd_tl]
        · have hle : k₀ ≤ g.level := by omega
          simp only [List.filter_cons, decide_eq_true_eq, hlt, ↓reduceIte, hle,
            List.flatMap_cons, List.filter_append]
          have hg_all : g.sids.filter (fun sid => decide (sid ∉
              (tl.filter (fun x => decide (x.level < k₀))).flatMap CertGroupMeta.sids)) = g.sids := by
            rw [List.filter_eq_self]
            intro sid hsid
            simp only [decide_eq_true_eq]
            intro hmem_tl
            rcases List.mem_flatMap.mp hmem_tl with ⟨y, hy, hsid_y⟩
            exact hdisj_l sid hsid sid
              (List.mem_flatMap.mpr ⟨y, List.mem_of_mem_filter hy, hsid_y⟩) rfl
          rw [hg_all, ih hnd_tl]
    have hnd_old : (oldGroups.flatMap CertGroupMeta.sids).Nodup := by
      rw [← hinv.slotIds_eq]; exact hinv.slotIds_nodup
    exact hgen_split oldGroups hnd_old
  have hkept_len_lt : keptGroups.length + 1 ≤ L_max := by
    have hk₀_not_old : k₀ ∉ oldGroups.map CertGroupMeta.level := by
      rw [hinv.level_mem_iff]
      exact (carryLevel_spec H).2.1.1
    have hsub : (keptGroups.map CertGroupMeta.level ++ [k₀]).Subperm (List.range L_max) := by
      have hnd_new : (keptGroups.map CertGroupMeta.level ++ [k₀]).Nodup := by
        rw [List.nodup_append]
        have hnd_kept : (keptGroups.map CertGroupMeta.level).Nodup := by
          have hsub_f : (keptGroups.map CertGroupMeta.level).Sublist
              (oldGroups.map CertGroupMeta.level) :=
            (List.filter_sublist).map _
          exact hinv.levels_nodup.sublist hsub_f
        refine ⟨hnd_kept, List.nodup_singleton _, ?_⟩
        intro a ha b hb heq
        simp only [List.mem_singleton] at hb
        rcases List.mem_map.mp ha with ⟨g, hg, hgl⟩
        have hgk : g.level = k₀ := hgl.trans (heq.trans hb)
        exact hk₀_not_old (hgk ▸ List.mem_map_of_mem (List.mem_of_mem_filter hg))
      rw [List.subperm_iff_count]
      intro m
      by_cases hm : m ∈ keptGroups.map CertGroupMeta.level ++ [k₀]
      · have hc1 := List.count_eq_one_of_mem hnd_new hm
        have hm_lt : m < L_max := by
          rcases List.mem_append.mp hm with hm_k | hm_0
          · rcases List.mem_map.mp hm_k with ⟨g, hg, rfl⟩
            have hg_old : g ∈ oldGroups := List.mem_of_mem_filter hg
            exact bitActive_lt_log_succ hinv.life_le_max
              ((hinv.level_mem_iff g.level).mp (List.mem_map_of_mem hg_old))
          · simp only [List.mem_singleton] at hm_0
            subst hm_0
            exact hk₀_lt
        have hc2 := List.count_eq_one_of_mem List.nodup_range (List.mem_range.mpr hm_lt)
        omega
      · rw [List.count_eq_zero_of_not_mem hm]
        exact Nat.zero_le _
    have hlen := hsub.length_le
    simpa using hlen
  have hret_len_R : tbl_ret.slots.length + R ≤ L_max * R := by
    have heq_len : tbl_ret.slots.length = (keptGroups.flatMap CertGroupMeta.sids).length := by
      have := congrArg List.length hret_ids_eq
      simpa using this
    rw [heq_len]
    have h1 : (keptGroups.flatMap CertGroupMeta.sids).length ≤ keptGroups.length * R :=
      flatMap_length_le_mul keptGroups CertGroupMeta.sids R
        (fun g hg => (hinv.groups_inv g (List.mem_of_mem_filter hg)).2.1.le)
    calc
      (keptGroups.flatMap CertGroupMeta.sids).length + R
          ≤ keptGroups.length * R + R := Nat.add_le_add_right h1 R
      _ = (keptGroups.length + 1) * R := by ring
      _ ≤ L_max * R := Nat.mul_le_mul_right R hkept_len_lt
  have hpeakSp₀_le : (peakSp₀ : ℝ) ≤ (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ := by
    dsimp only [peakSp₀]
    rw [Nat.cast_max]
    have hS0_le : S.card ≤ n :=
      (Finset.card_le_card (Finset.subset_insert id₀ S)).trans hScard_le
    have hsp0 : (tbl0.currentSpace : ℝ) ≤ (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ :=
      hinv.currentSpace_le hσθ.1 hσθ.2.1 hfacs hS0_le
    have hsp1 : (tbl1.currentSpace : ℝ) ≤ (1 + 2 * ((L_max * R : ℕ) : ℝ)) * facs.spaceBound n σ :=
      table_space_le_of_slots hσθ.1 hσθ.2.1 hfacs hact1_le_n hinv.slots_length_le hinv.slots_inv
    exact max_le hsp0 hsp1
  have hret_lt : ∀ sl ∈ tbl_ret.slots, sl.slotId < tbl_ret.nextSlotId := by
    intro sl hsl
    exact hinv.slotIds_lt sl (List.mem_of_mem_filter hsl)
  have hret_nd : (tbl_ret.slots.map UL.HostedCertSlot.slotId).Nodup := by
    rw [hret_ids_eq]
    rw [← hret_ids_eq]
    dsimp only [tbl_ret, applyCertRetireIds, tbl1]
    exact hinv.slotIds_nodup.sublist ((List.filter_sublist).map _)
  have hret_inv : ∀ sl ∈ tbl_ret.slots, CertSlotInv n pts h σ facs mkCert sl := by
    intro sl hsl
    exact hinv.slots_inv sl (List.mem_of_mem_filter hsl)
  rcases runCertOpenFinish_spec (R := R) hσθ hfacs hCert extHist id₀ nextGroups gen
      hgen_m1 hgen_mn rfl (fun _ _ => rfl) restFuel R tbl_ret (1 + rids.length) peakSp₀
      (Finset.filter_subset _ _) hact1_le_n hret_len_R hpeakSp₀_le hret_lt hret_nd hret_inv with
    ⟨hhalt_open, hpath_open, hwork_open, hslow_open⟩
  have hstepFn_eq :
      UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀) =
        fun bs => (f_open bs).map (fun out => (insert id₀ S, out)) := by
    funext bs
    unfold UL.runSingleDynamicSearchStep
    rw [congrFun hstepWithBits_eq bs]
    cases hfo : f_open bs with
    | none => rfl
    | some out =>
      have hqa := (hpath_open bs out hfo).2.1
      simp [hqa, UL.applyDynamicSearchSetOp]
  have hhalt_open' : haltProb f_open = 1 := hhalt_open
  refine ⟨?_, ?_, ?_⟩
  · -- (1) Halting probability = 1
    unfold UL.singleDynamicSearchStepHaltProb
    change haltProb (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀)) = 1
    rw [← hhalt_open']
    unfold haltProb
    refine tsum_congr fun bs => ?_
    rw [congrFun hstepFn_eq bs]
    cases f_open bs <;> rfl
  · -- (2) Pathwise `CertTableInv` & `peakSpace` bound
    intro bs S' out hstep
    rw [congrFun hstepFn_eq bs] at hstep
    cases hfo : f_open bs with
    | none => simp [hfo] at hstep
    | some out' =>
      rw [hfo] at hstep
      simp only [Option.map_some, Option.some.injEq, Prod.mk.injEq] at hstep
      have hS_eq : S' = insert id₀ S := hstep.1.symm
      have hout_eq : out' = out := hstep.2
      subst hS_eq
      rw [hout_eq] at hfo
      rcases hpath_open bs out hfo with
        ⟨hctrl', hqa', hact', hnl', hnsid', hnd', hlt', hinv_sl', hsp',
         newSlots, hslots_eq, hnew_ids, hnew_gen⟩
      refine ⟨rfl, hqa', hnl', ?_, hsp'⟩
      have hact_eq1 : out.nextState.2.activeLifetimes = insert (id₀, H) tbl0.activeLifetimes :=
        hact'
      have hnl_eq1 : out.nextState.2.nextLifetime = H + 1 := hnl'
      have hk₀_not_old : k₀ ∉ oldGroups.map CertGroupMeta.level := by
        rw [hinv.level_mem_iff]
        exact (carryLevel_spec H).2.1.1
      refine
        { queue_none := by rw [hctrl']
          img_eq := by rw [hact_eq1]; exact himg1
          card_eq := by rw [hact_eq1]; exact hcard1
          lt_next := by
            rw [hact_eq1, hnl_eq1]
            intro p hp
            rcases Finset.mem_insert.mp hp with rfl | hp0
            · omega
            · have := hinv.lt_next p hp0; omega
          unit_active := by rw [hact_eq1]; exact hunit1
          life_le_max := by rw [hnl_eq1]; exact hH1_le
          levels_nodup := by
            rw [hctrl']
            dsimp only [nextGroups, newGrp]
            rw [List.map_append, List.map_singleton, List.nodup_append]
            have hnd_kept : (keptGroups.map CertGroupMeta.level).Nodup :=
              hinv.levels_nodup.sublist ((List.filter_sublist).map _)
            refine ⟨hnd_kept, List.nodup_singleton _, ?_⟩
            intro a ha b hb
            simp only [List.mem_singleton] at hb
            subst hb
            intro heq
            subst heq
            rcases List.mem_map.mp ha with ⟨g, hg, hgl⟩
            exact hk₀_not_old (hgl ▸ List.mem_map_of_mem (List.mem_of_mem_filter hg))
          level_mem_iff := by
            rw [hctrl', hnl_eq1]
            dsimp only [nextGroups, newGrp]
            intro k
            rw [List.map_append, List.map_singleton, List.mem_append, List.mem_singleton]
            rcases carryLevel_spec H with ⟨hc_lt, ⟨hc_nbH, hc_bH1⟩, _, hc_gt⟩
            rcases lt_trichotomy k k₀ with hlt_k | rfl | hgt_k
            · constructor
              · rintro (hk_in | rfl)
                · rcases List.mem_map.mp hk_in with ⟨g, hg, rfl⟩
                  have hge : k₀ ≤ g.level := by
                    simpa [keptGroups] using (List.mem_filter.mp hg).2
                  omega
                · omega
              · intro hb1
                exact absurd hb1 (hc_lt k hlt_k).2
            · exact ⟨fun _ => hc_bH1, fun _ => Or.inr rfl⟩
            · constructor
              · rintro (hk_in | rfl)
                · rcases List.mem_map.mp hk_in with ⟨g, hg, rfl⟩
                  have hg_old : g ∈ oldGroups := List.mem_of_mem_filter hg
                  exact (hc_gt g.level hgt_k).1.mpr
                    ((hinv.level_mem_iff g.level).mp (List.mem_map_of_mem hg_old))
                · omega
              · intro hb1
                have hb0 : BitActive H k := (hc_gt k hgt_k).1.mp hb1
                rcases List.mem_map.mp ((hinv.level_mem_iff k).mpr hb0) with ⟨g, hg_old, rfl⟩
                refine Or.inl (List.mem_map_of_mem ?_)
                exact List.mem_filter.mpr ⟨hg_old, by simp [(by omega : k₀ ≤ g.level)]⟩
          slotIds_eq := by
            rw [hctrl', hslots_eq, List.map_append, hret_ids_eq, hnew_ids]
            dsimp only [nextGroups, newGrp, newSids, tbl_ret, applyCertRetireIds]
            rw [List.flatMap_append, List.flatMap_singleton]
          slotIds_nodup := hnd'
          slotIds_lt := hlt'
          slots_inv := hinv_sl'
          groups_inv := by
            rw [hctrl', hact_eq1, hnl_eq1]
            intro g hg
            rcases List.mem_append.mp hg with hg_kept | hg_new
            · have hg_old : g ∈ oldGroups := List.mem_of_mem_filter hg_kept
              have hge_k₀ : k₀ ≤ g.level := by
                simpa [keptGroups] using (List.mem_filter.mp hg_kept).2
              have hne_k₀ : g.level ≠ k₀ := by
                intro heq
                exact hk₀_not_old (heq ▸ List.mem_map_of_mem hg_old)
              have hgt_k₀ : k₀ < g.level := by omega
              rcases hinv.groups_inv g hg_old with
                ⟨hnd_g, hlen_g, hm1_g, hmn_g, hh_g, hpts_g, hsl_g⟩
              refine ⟨hnd_g, hlen_g, hm1_g, hmn_g, hh_g, hpts_g, ?_⟩
              intro sid hsid sl hsl hid
              rw [hslots_eq] at hsl
              rcases List.mem_append.mp hsl with hsl_ret | hsl_new
              · have hsl_0 : sl ∈ tbl0.slots := List.mem_of_mem_filter hsl_ret
                rcases hsl_g sid hsid sl hsl_0 hid with ⟨hgen_sl, hsurv_sl⟩
                refine ⟨hgen_sl, ?_⟩
                rw [hsurv_sl, (hslice_gt g.level hgt_k₀).symm]
              · exfalso
                have hid_new : sid ∈ newSlots.map UL.HostedCertSlot.slotId :=
                  hid ▸ List.mem_map_of_mem hsl_new
                rw [hnew_ids] at hid_new
                rcases List.mem_map.mp hid_new with ⟨j, _, hj_eq⟩
                have hsid_in_0 : sid ∈ tbl0.slots.map UL.HostedCertSlot.slotId := by
                  rw [hinv.slotIds_eq]
                  exact List.mem_flatMap.mpr ⟨g, hg_old, hsid⟩
                rcases List.mem_map.mp hsid_in_0 with ⟨sl₀, hsl₀, hid₀_eq⟩
                have hlt0 := hinv.slotIds_lt sl₀ hsl₀
                dsimp only [tbl_ret, applyCertRetireIds, tbl1] at hj_eq
                omega
            · simp only [List.mem_singleton] at hg_new
              subst hg_new
              dsimp only [newGrp]
              have hnd_newSids : newSids.Nodup :=
                List.Nodup.map (fun a b hab => by omega) List.nodup_range
              refine ⟨hnd_newSids, by simp [newSids], hgen_m1, hgen_mn, rfl, fun _ _ => rfl, ?_⟩
              intro sid hsid sl hsl hid
              rw [hslots_eq] at hsl
              rcases List.mem_append.mp hsl with hsl_ret | hsl_new
              · exfalso
                have hlt0 := hret_lt sl hsl_ret
                rcases List.mem_map.mp hsid with ⟨j, _, hj_eq⟩
                dsimp only [tbl_ret, applyCertRetireIds, tbl1] at hlt0 hj_eq
                omega
              · exact hnew_gen sl hsl_new }
  · -- (3) Potential + amortized work inequality
    intro rem hrem_le
    have hexp_map :
        expWithBits (UL.runSingleDynamicSearchStep dynIdx extHist S (ctrl, tbl0) (.insert id₀))
          (fun res =>
            (res.2.work : ENNReal) +
              certPhi L_max R n θ facs N cap mkCert rem res.2.nextState.1.groups res.2.nextState.2) =
        expWithBits f_open
          (fun out =>
            (out.work : ENNReal) +
              certPhi L_max R n θ facs N cap mkCert rem out.nextState.1.groups out.nextState.2) := by
      unfold expWithBits
      refine tsum_congr fun bs => ?_
      rw [congrFun hstepFn_eq bs]
      cases f_open bs <;> rfl
    rw [hexp_map]
    let U_elem : ENNReal := ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2))
    let C_elem1 : ENNReal := (elemCredit L_max tbl1.activeLifetimes (H + 1) : ENNReal) * U_elem
    let C_bad0 : ENNReal :=
      ((rem * (n + 1) : ℕ) : ENNReal) * (badGroupCount N cap mkCert oldGroups tbl0 : ENNReal)
    -- Pointwise decompose `certPhi` on every halting outcome of `f_open`
    have hpointwise :
        expWithBits f_open
          (fun out =>
            (out.work : ENNReal) +
              certPhi L_max R n θ facs N cap mkCert rem out.nextState.1.groups out.nextState.2) ≤
        expWithBits f_open
          (fun out =>
            ((out.work : ENNReal) + slotPot mkCert out.nextState.2) +
            (C_bad0 +
              ((rem * (n + 1) : ℕ) : ENNReal) *
                (if IsBadGroup (mkCert gen) N cap
                      ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                        UL.HostedCertSlot.bState)
                 then (1 : ENNReal) else 0)) +
            C_elem1) := by
      refine expWithBits_mono fun bs out hfo => ?_
      rcases hpath_open bs out hfo with
        ⟨hctrl', _, hact', hnl', _, hnd', _, _, _, newSlots, hslots_eq, hnew_ids, _⟩
      unfold certPhi
      rw [hctrl', hact', hnl']
      have hbad_split :
          badGroupCount N cap mkCert nextGroups out.nextState.2 ≤
            badGroupCount N cap mkCert oldGroups tbl0 +
              (if IsBadGroup (mkCert gen) N cap
                    ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                      UL.HostedCertSlot.bState)
               then 1 else 0) := by
        unfold badGroupCount
        dsimp only [nextGroups]
        rw [List.filter_append, List.length_append]
        have hkept_gs :
            keptGroups.filter (fun g =>
              decide (IsBadGroup (mkCert g.gen) N cap
                ((groupSlots out.nextState.2 g.sids).map UL.HostedCertSlot.bState))) =
            keptGroups.filter (fun g =>
              decide (IsBadGroup (mkCert g.gen) N cap
                ((groupSlots tbl0 g.sids).map UL.HostedCertSlot.bState))) := by
          refine List.filter_congr fun g hg => ?_
          have hg_old : g ∈ oldGroups := List.mem_of_mem_filter hg
          have hgs_eq : groupSlots out.nextState.2 g.sids = groupSlots tbl0 g.sids := by
            rcases groupSlots_spec_of_inv hinv hg_old with ⟨hgs_id, _, hgs_mem⟩
            have hsub_out : ∀ sl ∈ groupSlots tbl0 g.sids, sl ∈ out.nextState.2.slots := by
              intro sl hsl
              have hsl0 : sl ∈ tbl0.slots := (hgs_mem sl hsl).1
              have hid_in : sl.slotId ∈ g.sids := hgs_id ▸ List.mem_map_of_mem hsl
              have hnot_ret : sl.slotId ∉ rids := hdisj_kept g hg sl.slotId hid_in
              have hsl_ret : sl ∈ tbl_ret.slots :=
                List.mem_filter.mpr ⟨hsl0, by simp [hnot_ret]⟩
              rw [hslots_eq]
              exact List.mem_append_left _ hsl_ret
            have h1 := groupSlots_of_sublist_nodup out.nextState.2 hnd'
              (groupSlots tbl0 g.sids) hsub_out
            rwa [hgs_id] at h1
          rw [hgs_eq]
        rw [hkept_gs]
        have hkept_le :
            (keptGroups.filter (fun g =>
              decide (IsBadGroup (mkCert g.gen) N cap
                ((groupSlots tbl0 g.sids).map UL.HostedCertSlot.bState)))).length ≤
            (oldGroups.filter (fun g =>
              decide (IsBadGroup (mkCert g.gen) N cap
                ((groupSlots tbl0 g.sids).map UL.HostedCertSlot.bState)))).length :=
          filter_filter_length_le oldGroups _ _
        have hnew_gs : groupSlots out.nextState.2 newGrp.sids = newSlots := by
          have hsub_new : ∀ sl ∈ newSlots, sl ∈ out.nextState.2.slots := by
            intro sl hsl
            rw [hslots_eq]
            exact List.mem_append_right _ hsl
          have h1 := groupSlots_of_sublist_nodup out.nextState.2 hnd' newSlots hsub_new
          have hid_eq : newSlots.map UL.HostedCertSlot.slotId = newGrp.sids := hnew_ids
          rwa [hid_eq] at h1
        have hdrop_eq : out.nextState.2.slots.drop tbl_ret.slots.length = newSlots := by
          rw [hslots_eq, List.drop_left]
        dsimp only [newGrp] at hnew_gs ⊢
        rw [List.filter_singleton, hnew_gs, hdrop_eq]
        split_ifs with hbad_new <;> simp [hbad_new] <;> omega
      have hbad_enn :
          ((rem * (n + 1) : ℕ) : ENNReal) *
            (badGroupCount N cap mkCert nextGroups out.nextState.2 : ENNReal) ≤
          C_bad0 +
            ((rem * (n + 1) : ℕ) : ENNReal) *
              (if IsBadGroup (mkCert gen) N cap
                    ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                      UL.HostedCertSlot.bState)
               then (1 : ENNReal) else 0) := by
        dsimp only [C_bad0]
        rw [← mul_add]
        refine mul_le_mul_of_nonneg_left ?_ (zero_le _)
        have hcast :
            ((badGroupCount N cap mkCert oldGroups tbl0 +
              (if IsBadGroup (mkCert gen) N cap
                    ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                      UL.HostedCertSlot.bState)
               then 1 else 0) : ℕ) : ENNReal) =
            (badGroupCount N cap mkCert oldGroups tbl0 : ENNReal) +
              (if IsBadGroup (mkCert gen) N cap
                    ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                      UL.HostedCertSlot.bState)
               then (1 : ENNReal) else 0) := by
          split_ifs <;> simp
        rw [← hcast]
        exact Nat.cast_le.mpr hbad_split
      have hcelem_eq :
          (elemCredit L_max tbl_ret.activeLifetimes tbl_ret.nextLifetime : ENNReal) *
            ENNReal.ofReal ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2)) = C_elem1 := rfl
      dsimp only [CertCtrlState.groups]
      rw [hcelem_eq]
      calc
        (out.work : ENNReal) +
            (slotPot mkCert out.nextState.2 +
              ((rem * (n + 1) : ℕ) : ENNReal) *
                (badGroupCount N cap mkCert nextGroups out.nextState.2 : ENNReal) +
              C_elem1)
            = ((out.work : ENNReal) + slotPot mkCert out.nextState.2) +
                ((rem * (n + 1) : ℕ) : ENNReal) *
                  (badGroupCount N cap mkCert nextGroups out.nextState.2 : ENNReal) +
                C_elem1 := by ring
        _ ≤ ((out.work : ENNReal) + slotPot mkCert out.nextState.2) +
              (C_bad0 +
                ((rem * (n + 1) : ℕ) : ENNReal) *
                  (if IsBadGroup (mkCert gen) N cap
                        ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                          UL.HostedCertSlot.bState)
                   then (1 : ENNReal) else 0)) +
              C_elem1 :=
            add_le_add (add_le_add le_rfl hbad_enn) le_rfl
    refine hpointwise.trans ?_
    rw [expWithBits_add_const_of_haltProb_one hhalt_open' _ C_elem1,
        expWithBits_add f_open,
        expWithBits_const_add_of_haltProb_one hhalt_open' C_bad0]
    -- Bound the new group's scaled bad-group expectation by `1`!
    have hbad_new_exp :
        expWithBits f_open
          (fun out =>
            ((rem * (n + 1) : ℕ) : ENNReal) *
              (if IsBadGroup (mkCert gen) N cap
                    ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                      UL.HostedCertSlot.bState)
               then (1 : ENNReal) else 0)) ≤ 1 := by
      rw [expWithBits_const_mul]
      have hdir_sum :
          expWithBits f_open
            (fun out =>
              if IsBadGroup (mkCert gen) N cap
                    ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                      UL.HostedCertSlot.bState)
              then (1 : ENNReal) else 0) ≤
          ∑ z ∈ N, ENNReal.ofReal ((1 / 4 : ℝ) ^ R) := by
        calc
          expWithBits f_open
              (fun out =>
                if IsBadGroup (mkCert gen) N cap
                      ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                        UL.HostedCertSlot.bState)
                then (1 : ENNReal) else 0)
              ≤ expWithBits f_open
                  (fun out =>
                    ∑ z ∈ N,
                      if (∀ b ∈ (out.nextState.2.slots.drop tbl_ret.slots.length).map
                            UL.HostedCertSlot.bState,
                            (cap : ℝ) < (mkCert gen).birthVar b z)
                      then (1 : ENNReal) else 0) :=
                expWithBits_mono fun _ out _ => isBadGroup_le_sum_dirs (mkCert gen) N cap _
          _ = ∑ z ∈ N,
                expWithBits f_open (fun out =>
                  if (∀ b ∈ (out.nextState.2.slots.drop tbl_ret.slots.length).map
                        UL.HostedCertSlot.bState,
                        (cap : ℝ) < (mkCert gen).birthVar b z)
                  then (1 : ENNReal) else 0) :=
                expWithBits_finset_sum f_open N _
          _ ≤ ∑ _z ∈ N, ENNReal.ofReal ((1 / 4 : ℝ) ^ R) :=
                Finset.sum_le_sum fun z hz => hslow_open z hz
      rw [Finset.sum_const, nsmul_eq_mul] at hdir_sum
      have hN_pos : 1 ≤ N.card := Finset.card_pos.mpr hN_net.1
      have hscaled_r := badGroup_prob_scaled_le_one_net hσθ.1 hPlife hnet0
        hN_pos hN_net.2.2.2 hmaxOps hrem_le
      calc
        ((rem * (n + 1) : ℕ) : ENNReal) *
          expWithBits f_open
            (fun out =>
              if IsBadGroup (mkCert gen) N cap
                    ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                      UL.HostedCertSlot.bState)
              then (1 : ENNReal) else 0)
            ≤ ((rem * (n + 1) : ℕ) : ENNReal) *
                ((N.card : ENNReal) * ENNReal.ofReal ((1 / 4 : ℝ) ^ R)) :=
              mul_le_mul_of_nonneg_left hdir_sum (zero_le _)
        _ = ENNReal.ofReal ((rem * (n + 1) : ℝ) * ((N.card : ℝ) * (1 / 4 : ℝ) ^ R)) := by
              have hcast_rn : (rem * (n + 1) : ℝ) = ((rem * (n + 1) : ℕ) : ℝ) := by
                push_cast; ring
              rw [hcast_rn,
                  ENNReal.ofReal_mul (Nat.cast_nonneg (rem * (n + 1))),
                  ENNReal.ofReal_mul (Nat.cast_nonneg N.card),
                  ENNReal.ofReal_natCast, ENNReal.ofReal_natCast]
        _ ≤ ENNReal.ofReal 1 := ENNReal.ofReal_le_ofReal hscaled_r
        _ = 1 := ENNReal.ofReal_one
    -- Bound the open + retire + `elemCredit` terms!
    have hpot_ret : slotPot mkCert tbl_ret ≤ slotPot mkCert tbl0 :=
      slotPot_filter_le mkCert tbl0 _
    have hB1_ge1 : 1 ≤ facs.buildWorkBound 1 n θ :=
      buildWorkBound_one_ge_one hσθ.1 (hσθ.2.1.trans hσθ.2.2) hfacs
    have hopen_scaled :
        (R : ENNReal) * ENNReal.ofReal (facs.buildWorkBound gen.m n θ + (gen.m : ℝ) + 1) ≤
          (gen.m : ENNReal) * U_elem := by
      dsimp only [U_elem]
      have hR_ofR : (R : ENNReal) = ENNReal.ofReal (R : ℝ) := (ENNReal.ofReal_natCast R).symm
      have hgm_ofR : (gen.m : ENNReal) = ENNReal.ofReal (gen.m : ℝ) :=
        (ENNReal.ofReal_natCast gen.m).symm
      rw [hR_ofR, hgm_ofR, ← ENNReal.ofReal_mul (Nat.cast_nonneg R),
          ← ENNReal.ofReal_mul (Nat.cast_nonneg gen.m)]
      apply ENNReal.ofReal_le_ofReal
      rw [buildWorkBound_eq_mul_one]
      have hm1_r : (1 : ℝ) ≤ (gen.m : ℝ) := by exact_mod_cast hgen_m1
      have hR_nn : (0 : ℝ) ≤ (R : ℝ) := Nat.cast_nonneg R
      nlinarith
    have helem_tele :
        (gen.m : ENNReal) * U_elem + C_elem1 ≤
          (L_max : ENNReal) * U_elem +
            (elemCredit L_max tbl0.activeLifetimes H : ENNReal) * U_elem := by
      dsimp only [C_elem1, tbl1]
      rw [← add_mul, ← add_mul]
      refine mul_le_mul_of_nonneg_right ?_ (zero_le _)
      have hnat := elemCredit_insert_bound tbl0.activeLifetimes (id₀, H)
        hinv.lt_next rfl hk₀_lt
      exact_mod_cast hnat
    have hC_bad_mono :
        C_bad0 ≤ (((rem + 1) * (n + 1) : ℕ) : ENNReal) *
          (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) := by
      dsimp only [C_bad0, oldGroups]
      refine mul_le_mul_of_nonneg_right ?_ (zero_le _)
      exact Nat.cast_le.mpr (Nat.mul_le_mul_right (n + 1) (Nat.le_succ rem))
    have hoverhead :
        ((1 + rids.length + 1 : ℕ) : ENNReal) + (1 : ENNReal) + (L_max : ENNReal) * U_elem ≤
          ENNReal.ofReal (7 * (L_max : ℝ) * (R : ℝ) * facs.buildWorkBound 1 n θ) := by
      have hrids_1 : 1 + rids.length + 1 ≤ L_max * R + 2 := by omega
      have hcast1 : ((1 + rids.length + 1 : ℕ) : ENNReal) + (1 : ENNReal) ≤
          ENNReal.ofReal (((L_max * R : ℕ) : ℝ) + 3) := by
        have hle_n : ((1 + rids.length + 1 : ℕ) : ENNReal) + 1 ≤ ((L_max * R + 3 : ℕ) : ENNReal) := by
          norm_cast; omega
        refine hle_n.trans (le_of_eq ?_)
        rw [← ENNReal.ofReal_natCast]
        push_cast; rfl
      have hcast2 : (L_max : ENNReal) * U_elem =
          ENNReal.ofReal ((L_max : ℝ) * ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2))) := by
        dsimp only [U_elem]
        rw [← ENNReal.ofReal_natCast L_max, ← ENNReal.ofReal_mul (Nat.cast_nonneg L_max)]
      calc
        ((1 + rids.length + 1 : ℕ) : ENNReal) + 1 + (L_max : ENNReal) * U_elem
            ≤ ENNReal.ofReal (((L_max * R : ℕ) : ℝ) + 3) +
                ENNReal.ofReal ((L_max : ℝ) * ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2))) :=
              add_le_add hcast1 (le_of_eq hcast2)
        _ = ENNReal.ofReal ((((L_max * R : ℕ) : ℝ) + 3) +
              (L_max : ℝ) * ((R : ℝ) * (facs.buildWorkBound 1 n θ + 2))) := by
              rw [← ENNReal.ofReal_add (by positivity) (by positivity)]
        _ ≤ ENNReal.ofReal (7 * (L_max : ℝ) * (R : ℝ) * facs.buildWorkBound 1 n θ) := by
              apply ENNReal.ofReal_le_ofReal
              have hL1 : (1 : ℝ) ≤ (L_max : ℝ) := by
                dsimp only [L_max]; push_cast; linarith
              have hR3 : (3 : ℝ) ≤ (R : ℝ) := by exact_mod_cast hR_ge3
              have hLR3 : (3 : ℝ) ≤ (L_max : ℝ) * (R : ℝ) := by nlinarith
              push_cast
              nlinarith
    calc
      expWithBits f_open (fun out => (out.work : ENNReal) + slotPot mkCert out.nextState.2) +
          (C_bad0 +
            expWithBits f_open (fun out =>
              ((rem * (n + 1) : ℕ) : ENNReal) *
                (if IsBadGroup (mkCert gen) N cap
                      ((out.nextState.2.slots.drop tbl_ret.slots.length).map
                        UL.HostedCertSlot.bState)
                 then (1 : ENNReal) else 0))) +
          C_elem1
          ≤ (((1 + rids.length + 1 : ℕ) : ENNReal) + slotPot mkCert tbl0 +
              (gen.m : ENNReal) * U_elem) +
            (C_bad0 + 1) + C_elem1 := by
            refine add_le_add (add_le_add ?_ (add_le_add le_rfl hbad_new_exp)) le_rfl
            exact hwork_open.trans (add_le_add (add_le_add le_rfl hpot_ret) hopen_scaled)
      _ = slotPot mkCert tbl0 + C_bad0 + ((gen.m : ENNReal) * U_elem + C_elem1) +
            (((1 + rids.length + 1 : ℕ) : ENNReal) + 1) := by ring
      _ ≤ slotPot mkCert tbl0 +
            (((rem + 1) * (n + 1) : ℕ) : ENNReal) *
              (badGroupCount N cap mkCert ctrl.groups tbl0 : ENNReal) +
            ((L_max : ENNReal) * U_elem +
              (elemCredit L_max tbl0.activeLifetimes H : ENNReal) * U_elem) +
            (((1 + rids.length + 1 : ℕ) : ENNReal) + 1) :=
            add_le_add (add_le_add (add_le_add le_rfl hC_bad_mono) helem_tele) le_rfl
      _ = certPhi L_max R n θ facs N cap mkCert (rem + 1) ctrl.groups tbl0 +
            (((1 + rids.length + 1 : ℕ) : ENNReal) + 1 + (L_max : ENNReal) * U_elem) := by
            unfold certPhi; dsimp only [H, U_elem]; ring
      _ ≤ certPhi L_max R n θ facs N cap mkCert (rem + 1) ctrl.groups tbl0 +
            ENNReal.ofReal (7 * (L_max : ℝ) * (R : ℝ) * facs.buildWorkBound 1 n θ) :=
            add_le_add le_rfl hoverhead

end UL.Proof_lem_7_1_RaceV31
