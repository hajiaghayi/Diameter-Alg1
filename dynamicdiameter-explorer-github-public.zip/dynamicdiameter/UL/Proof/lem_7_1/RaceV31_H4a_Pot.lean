import Mathlib
import UL.Stmt.lem_7_1
import UL.Proof.lem_7_1.RaceV31_H1_Coins
import UL.Proof.lem_7_1.RaceV31_H2_Dyadic
set_option autoImplicit false

open scoped ENNReal

namespace UL.Proof_lem_7_1_RaceV31

/-! ### 1. Finite-Trace Reindexing & `expWithBits` Summation Helpers -/

theorem ofFn_finFunCongr {n m : ℕ} (h : n = m) {α : Type*} (f : Fin n → α) :
    List.ofFn (finFunCongr h α f) = List.ofFn f := by
  subst h
  rfl

theorem expWithBits_const_mul {α : Type*} (f : List Bool → Option α)
    (C : ENNReal) (W : α → ENNReal) :
    expWithBits f (fun a => C * W a) = C * expWithBits f W := by
  unfold expWithBits
  rw [← ENNReal.tsum_mul_left]
  refine tsum_congr fun bs => ?_
  cases f bs with
  | none => simp
  | some a =>
    dsimp only []
    ring

theorem expWithBits_finset_sum {α β : Type*} [DecidableEq β]
    (f : List Bool → Option α) (S : Finset β) (W : β → α → ENNReal) :
    expWithBits f (fun a => ∑ x ∈ S, W x a) = ∑ x ∈ S, expWithBits f (W x) := by
  induction S using Finset.induction_on with
  | empty =>
    simpa using expWithBits_zero f
  | @insert x₀ S₀ hx₀ ih =>
    have h1 : (fun a => ∑ x ∈ insert x₀ S₀, W x a) =
        (fun a => W x₀ a + ∑ x ∈ S₀, W x a) := by
      funext a
      exact Finset.sum_insert hx₀
    rw [h1, expWithBits_add, ih, Finset.sum_insert hx₀]

/-! ### 2. Certified Copy Remaining Deletion/Rebuild Work Potential (`remCopyWork`) -/

abbrev SuffixDelPolicy (ι : Type) (d : ℕ) (PhaseState : Type) : Type :=
  Finset ι → PhaseState → List (ι × List Bool) → Option (UL.ExecutionHistory d × ι)

def ValidSuffixPol (ι : Type) (d : ℕ) (PhaseState : Type) : Type :=
  { pol : SuffixDelPolicy ι d PhaseState //
    ∀ S ph relLog sh i, pol S ph relLog = some (sh, i) → i ∈ S }

instance instNonemptyValidSuffixPol (ι : Type) (d : ℕ) (PhaseState : Type) :
    Nonempty (ValidSuffixPol ι d PhaseState) :=
  ⟨⟨fun _ _ _ => none, fun _ _ _ _ _ h => by simp at h⟩⟩

noncomputable def runSuffixDelSteps {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (pol : ValidSuffixPol ι d PhaseState)
    (S : Finset ι) (ph : PhaseState) (relLog : List (ι × List Bool)) :
    List (List Bool) → Option ℕ
  | [] => some 0
  | bs :: rest =>
      match pol.val S ph relLog with
      | none =>
          match bs with
          | [] => runSuffixDelSteps inst bState pol S ph relLog rest
          | _ :: _ => none
      | some (stepHist, i) =>
          if i ∈ S then
            match inst.deleteWithBits stepHist bState S ph i bs with
            | none => none
            | some dOut =>
                match runSuffixDelSteps inst bState pol (S.erase i) dOut.nextPhase
                    (relLog ++ [(i, bs)]) rest with
                | none => none
                | some wRest => some (dOut.work + wRest)
          else
            none

theorem runSuffixDelSteps_shift_log {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState)
    {pol₁ pol₂ : ValidSuffixPol ι d PhaseState}
    (pref : List (ι × List Bool))
    (hshift : ∀ S' ph' tailLog, pol₁.val S' ph' (pref ++ tailLog) = pol₂.val S' ph' tailLog) :
    ∀ (tr : List (List Bool)) (S : Finset ι) (ph : PhaseState) (tailLog : List (ι × List Bool)),
      runSuffixDelSteps inst bState pol₁ S ph (pref ++ tailLog) tr =
        runSuffixDelSteps inst bState pol₂ S ph tailLog tr := by
  intro tr
  induction tr with
  | nil => intro _ _ _; rfl
  | cons bs rest ih =>
    intro S ph tailLog
    unfold runSuffixDelSteps
    rw [hshift S ph tailLog]
    cases pol₂.val S ph tailLog with
    | none =>
      cases bs with
      | nil => exact ih S ph tailLog
      | cons _ _ => rfl
    | some pair =>
      rcases pair with ⟨stepHist, i⟩
      dsimp only []
      split_ifs with hi
      · cases inst.deleteWithBits stepHist bState S ph i bs with
        | none => rfl
        | some dOut =>
          dsimp only []
          have hassoc : (pref ++ tailLog) ++ [(i, bs)] = pref ++ (tailLog ++ [(i, bs)]) :=
            List.append_assoc pref tailLog [(i, bs)]
          rw [hassoc, ih (S.erase i) dOut.nextPhase (tailLog ++ [(i, bs)])]
      · rfl

theorem runSuffixDelSteps_eq_certifiedSteps {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (delAdv : UL.CertifiedDeletionAdversary ι d BirthState PhaseState)
    (pol : ValidSuffixPol ι d PhaseState)
    (bs₀ : List Bool)
    (hadv_eq : ∀ st : UL.CertifiedDeletionState ι BirthState PhaseState,
      st.birthCoins = bs₀ →
        delAdv st = pol.val st.survivingSet st.phaseState st.deletionLog) :
    ∀ (tr : List (List Bool)) (cur : UL.CertifiedDeletionState ι BirthState PhaseState),
      cur.birthCoins = bs₀ →
      (UL.runCertifiedDeletionStepsFrom inst delAdv cur tr).map
          UL.CertifiedDeletionState.totalWork =
        (runSuffixDelSteps inst cur.birthState pol cur.survivingSet cur.phaseState
          cur.deletionLog tr).map (cur.totalWork + ·) := by
  intro tr
  induction tr with
  | nil =>
    intro cur _
    simp [UL.runCertifiedDeletionStepsFrom, runSuffixDelSteps]
  | cons bs rest ih =>
    intro cur hcoins
    unfold UL.runCertifiedDeletionStepsFrom runSuffixDelSteps
    rw [hadv_eq cur hcoins]
    cases pol.val cur.survivingSet cur.phaseState cur.deletionLog with
    | none =>
      cases bs with
      | nil => exact ih cur hcoins
      | cons _ _ => rfl
    | some pair =>
      rcases pair with ⟨stepHist, i⟩
      dsimp only []
      split_ifs with hi
      · cases inst.deleteWithBits stepHist cur.birthState cur.survivingSet cur.phaseState i bs with
        | none => rfl
        | some dOut =>
          dsimp only []
          let next : UL.CertifiedDeletionState ι BirthState PhaseState :=
            { birthState := cur.birthState
              birthCoins := cur.birthCoins
              survivingSet := cur.survivingSet.erase i
              phaseState := dOut.nextPhase
              deletionLog := cur.deletionLog ++ [(i, bs)]
              totalWork := cur.totalWork + dOut.work
              maxSpace := max cur.maxSpace dOut.peakSpace }
          have hrec := ih next hcoins
          dsimp only [next] at hrec ⊢
          rw [hrec]
          cases runSuffixDelSteps inst cur.birthState pol (cur.survivingSet.erase i)
              dOut.nextPhase (cur.deletionLog ++ [(i, bs)]) rest with
          | none => rfl
          | some wRest =>
            simp [Nat.add_assoc]
      · rfl

theorem runSuffixDelSteps_haltProb_one {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    {n : ℕ} {σ θ netLogBound : ℝ} {facs : UL.BirthPoolPolyFactors}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))} {birthHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hcert : UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N birthHist inst)
    {bState : BirthState} (hbirth : inst.IsAcceptedBirth birthHist bState)
    (pol : ValidSuffixPol ι d PhaseState) :
    ∀ (k : ℕ) (S : Finset ι) (ph : PhaseState) (relLog : List (ι × List Bool)),
      inst.gen.IsSurvivingSubset S →
      inst.IsAcceptedPhase birthHist bState S ph →
      (∑' tr : Fin k → List Bool,
        if (runSuffixDelSteps inst bState pol S ph relLog (List.ofFn tr)).isSome then
          UL.prefixTraceProb tr
        else 0) = 1 := by
  have hdel_all := hcert.2.2.2.2.2.2.2.1
  intro k
  induction k with
  | zero =>
    intro S ph relLog _ _
    rw [tsum_fin_zero]
    have h0 : List.ofFn (Fin.elim0 : Fin 0 → List Bool) = [] := by simp
    rw [h0, prefixTraceProb_zero]
    simp [runSuffixDelSteps]
  | succ r ih =>
    intro S ph relLog hsurv hph
    rw [tsum_fin_succ]
    have hcons_fn : ∀ (bs : List Bool) (rest : Fin r → List Bool),
        List.ofFn (Fin.cons bs rest) = bs :: List.ofFn rest := by
      intro bs rest; rw [List.ofFn_succ]; simp
    cases hpol : pol.val S ph relLog with
    | none =>
      rw [tsum_eq_single ([] : List Bool)]
      · simp_rw [hcons_fn, prefixTraceProb_cons, bitListProb_nil, one_mul]
        have heq : ∀ rest : Fin r → List Bool,
            (runSuffixDelSteps inst bState pol S ph relLog ([] :: List.ofFn rest)).isSome =
            (runSuffixDelSteps inst bState pol S ph relLog (List.ofFn rest)).isSome := by
          intro rest
          simp [runSuffixDelSteps, hpol]
        simp_rw [heq]
        exact ih S ph relLog hsurv hph
      · intro bs hbs_ne
        cases bs with
        | nil => exact absurd rfl hbs_ne
        | cons b bs' =>
          have h0 : ∀ rest : Fin r → List Bool,
              (if (runSuffixDelSteps inst bState pol S ph relLog
                  (List.ofFn (Fin.cons (b :: bs') rest))).isSome then
                UL.prefixTraceProb (Fin.cons (b :: bs') rest) else 0) = 0 := by
            intro rest
            rw [hcons_fn]
            simp [runSuffixDelSteps, hpol]
          simp_rw [h0, tsum_zero]
    | some pair =>
      rcases pair with ⟨stepHist, i⟩
      have hi : i ∈ S := pol.2 S ph relLog stepHist i hpol
      rcases hdel_all stepHist bState S ph i hbirth hsurv hph hi with
        ⟨_, hhalt_del, hd_caps⟩
      rw [← hhalt_del]
      unfold UL.CertifiedSearchGeneration.deleteHaltProb
      refine tsum_congr fun bs => ?_
      cases hdb : inst.deleteWithBits stepHist bState S ph i bs with
      | none =>
        have h0 : ∀ rest : Fin r → List Bool,
            (if (runSuffixDelSteps inst bState pol S ph relLog
                (List.ofFn (Fin.cons bs rest))).isSome then
              UL.prefixTraceProb (Fin.cons bs rest) else 0) = 0 := by
          intro rest
          rw [hcons_fn]
          simp [runSuffixDelSteps, hpol, hi, hdb]
        simp_rw [h0, tsum_zero]
        simp [hdb]
      | some dOut =>
        rcases hd_caps bs dOut hdb with ⟨hph', _⟩
        have hsurv' : inst.gen.IsSurvivingSubset (S.erase i) :=
          (Finset.erase_subset i S).trans hsurv
        have hinner :
            (∑' rest : Fin r → List Bool,
              if (runSuffixDelSteps inst bState pol S ph relLog
                  (List.ofFn (Fin.cons bs rest))).isSome then
                UL.prefixTraceProb (Fin.cons bs rest) else 0) =
            UL.bitListProb bs *
              (∑' rest : Fin r → List Bool,
                if (runSuffixDelSteps inst bState pol (S.erase i) dOut.nextPhase
                    (relLog ++ [(i, bs)]) (List.ofFn rest)).isSome then
                  UL.prefixTraceProb rest else 0) := by
          rw [← ENNReal.tsum_mul_left]
          refine tsum_congr fun rest => ?_
          rw [hcons_fn, prefixTraceProb_cons]
          simp only [runSuffixDelSteps, hpol, hi, ↓reduceIte, hdb]
          cases runSuffixDelSteps inst bState pol (S.erase i) dOut.nextPhase
              (relLog ++ [(i, bs)]) (List.ofFn rest) <;> simp
        rw [hinner, ih (S.erase i) dOut.nextPhase (relLog ++ [(i, bs)]) hsurv' hph']
        simp [hdb]

theorem tsum_runSuffixDelSteps_add_const {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    {n : ℕ} {σ θ netLogBound : ℝ} {facs : UL.BirthPoolPolyFactors}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))} {birthHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hcert : UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N birthHist inst)
    {bState : BirthState} (hbirth : inst.IsAcceptedBirth birthHist bState)
    (pol : ValidSuffixPol ι d PhaseState)
    (k : ℕ) {S : Finset ι} {ph : PhaseState} (relLog : List (ι × List Bool))
    (hsurv : inst.gen.IsSurvivingSubset S)
    (hph : inst.IsAcceptedPhase birthHist bState S ph)
    (c : ℕ) :
    (∑' tr : Fin k → List Bool,
      match runSuffixDelSteps inst bState pol S ph relLog (List.ofFn tr) with
      | some w => UL.prefixTraceProb tr * ((c + w : ℕ) : ENNReal)
      | none => 0) =
    (c : ENNReal) +
      (∑' tr : Fin k → List Bool,
        match runSuffixDelSteps inst bState pol S ph relLog (List.ofFn tr) with
        | some w => UL.prefixTraceProb tr * (w : ENNReal)
        | none => 0) := by
  have hsplit : ∀ tr : Fin k → List Bool,
      (match runSuffixDelSteps inst bState pol S ph relLog (List.ofFn tr) with
       | some w => UL.prefixTraceProb tr * ((c + w : ℕ) : ENNReal)
       | none => 0) =
      (if (runSuffixDelSteps inst bState pol S ph relLog (List.ofFn tr)).isSome then
         UL.prefixTraceProb tr else 0) * (c : ENNReal) +
      (match runSuffixDelSteps inst bState pol S ph relLog (List.ofFn tr) with
       | some w => UL.prefixTraceProb tr * (w : ENNReal)
       | none => 0) := by
    intro tr
    cases runSuffixDelSteps inst bState pol S ph relLog (List.ofFn tr) with
    | none => simp
    | some w =>
      simp only [Option.isSome_some, ↓reduceIte, Nat.cast_add]
      ring
  simp_rw [hsplit]
  rw [ENNReal.tsum_add, ENNReal.tsum_mul_right,
      runSuffixDelSteps_haltProb_one hcert hbirth pol k S ph relLog hsurv hph, one_mul]

/-- Remaining deletion/rebuild work potential of a live certified copy `(bState, S, ph)`. -/
noncomputable def remCopyWork {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState)
    (bState : BirthState) (S : Finset ι) (ph : PhaseState) : ENNReal :=
  ⨆ (pol : ValidSuffixPol ι d PhaseState),
    ∑' tr : Fin S.card → List Bool,
      match runSuffixDelSteps inst bState pol S ph [] (List.ofFn tr) with
      | some w => UL.prefixTraceProb tr * (w : ENNReal)
      | none => 0

theorem birth_remCopyWork_le {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    {n : ℕ} {σ θ netLogBound : ℝ} {facs : UL.BirthPoolPolyFactors}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))} {birthHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hcert : UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N birthHist inst) :
    expWithBits (inst.buildWithBits birthHist)
      (fun bOut =>
        (bOut.work : ENNReal) +
          remCopyWork inst bOut.birthState inst.gen.P₀ bOut.initPhase) ≤
    ENNReal.ofReal (facs.buildWorkBound inst.gen.m n θ) := by
  have hparams := hcert.1
  have hfacs_v := hcert.2.1
  have hpf_build : IsPrefixFree (inst.buildWithBits birthHist) := hcert.2.2.2.2.1
  have hb_caps := hcert.2.2.2.2.2.2.1
  have htot_work := hcert.2.2.2.2.2.2.2.2.1
  unfold expWithBits remCopyWork
  refine (tsum_add_iSup_le hpf_build (fun bOut => (bOut.work : ENNReal))
    (fun bOut (pol : ValidSuffixPol ι d PhaseState) =>
      ∑' tr : Fin inst.gen.P₀.card → List Bool,
        match runSuffixDelSteps inst bOut.birthState pol inst.gen.P₀ bOut.initPhase []
            (List.ofFn tr) with
        | some w => UL.prefixTraceProb tr * (w : ENNReal)
        | none => 0)).trans ?_
  refine iSup_le fun ch => ?_
  let delAdv : UL.CertifiedDeletionAdversary ι d BirthState PhaseState := fun st =>
    match inst.buildWithBits birthHist st.birthCoins with
    | some bOut => (ch st.birthCoins bOut).val st.survivingSet st.phaseState st.deletionLog
    | none => none
  have hvalid : UL.IsValidCertifiedDeletionAdversary inst birthHist delAdv := by
    intro _ _ _ st _ stepHist i hadv
    dsimp only [delAdv] at hadv
    cases hbb : inst.buildWithBits birthHist st.birthCoins with
    | none => rw [hbb] at hadv; simp at hadv
    | some bOut =>
      rw [hbb] at hadv
      exact (ch st.birthCoins bOut).2 st.survivingSet st.phaseState st.deletionLog stepHist i hadv
  rcases htot_work delAdv hvalid inst.gen.P₀.card with ⟨hne_top, htoReal_le⟩
  have hB_nn : 0 ≤ facs.buildWorkBound inst.gen.m n θ := by
    rw [buildWorkBound_eq_mul_one]
    have h1 := buildWorkBound_one_ge_one hparams.1 (hparams.2.2.2.1.trans hparams.2.2.2.2) hfacs_v
    exact mul_nonneg (Nat.cast_nonneg _) (by linarith)
  have hexp_le : inst.expectedTotalBuildAndRebuildWork birthHist delAdv inst.gen.P₀.card ≤
      ENNReal.ofReal (facs.buildWorkBound inst.gen.m n θ) :=
    (ENNReal.le_ofReal_iff_toReal_le hne_top hB_nn).mpr htoReal_le
  refine le_trans (le_of_eq ?_) hexp_le
  unfold UL.CertifiedSearchGeneration.expectedTotalBuildAndRebuildWork
  refine tsum_congr fun bs₀ => ?_
  unfold UL.runCertifiedDeletionTrajectory
  cases hb₀ : inst.buildWithBits birthHist bs₀ with
  | none => simp
  | some bOut =>
    dsimp only []
    rcases hb_caps bs₀ bOut hb₀ with ⟨hbirth, hph₀, _⟩
    have hsurv₀ : inst.gen.IsSurvivingSubset inst.gen.P₀ := subset_rfl
    let init : UL.CertifiedDeletionState ι BirthState PhaseState :=
      { birthState := bOut.birthState
        birthCoins := bs₀
        survivingSet := inst.gen.P₀
        phaseState := bOut.initPhase
        deletionLog := []
        totalWork := bOut.work
        maxSpace := bOut.peakSpace }
    have hadv_bs₀ : ∀ st : UL.CertifiedDeletionState ι BirthState PhaseState,
        st.birthCoins = bs₀ →
          delAdv st = (ch bs₀ bOut).val st.survivingSet st.phaseState st.deletionLog := by
      intro st hst
      simp [delAdv, hst, hb₀]
    have hterm_eq :
        (∑' delTrace : Fin inst.gen.P₀.card → List Bool,
          match UL.runCertifiedDeletionStepsFrom inst delAdv init (List.ofFn delTrace) with
          | some out => UL.bitListProb bs₀ * UL.prefixTraceProb delTrace * (out.totalWork : ENNReal)
          | none => 0) =
        UL.bitListProb bs₀ *
          (∑' delTrace : Fin inst.gen.P₀.card → List Bool,
            match runSuffixDelSteps inst bOut.birthState (ch bs₀ bOut) inst.gen.P₀
                bOut.initPhase [] (List.ofFn delTrace) with
            | some w => UL.prefixTraceProb delTrace * ((bOut.work + w : ℕ) : ENNReal)
            | none => 0) := by
      rw [← ENNReal.tsum_mul_left]
      refine tsum_congr fun delTrace => ?_
      have hmap := runSuffixDelSteps_eq_certifiedSteps inst delAdv (ch bs₀ bOut) bs₀
        hadv_bs₀ (List.ofFn delTrace) init rfl
      dsimp only [init] at hmap
      cases hc : UL.runCertifiedDeletionStepsFrom inst delAdv init (List.ofFn delTrace) with
      | none =>
        rw [hc] at hmap
        cases hs : runSuffixDelSteps inst bOut.birthState (ch bs₀ bOut) inst.gen.P₀
            bOut.initPhase [] (List.ofFn delTrace) with
        | none => simp
        | some w => rw [hs] at hmap; simp at hmap
      | some out =>
        rw [hc] at hmap
        cases hs : runSuffixDelSteps inst bOut.birthState (ch bs₀ bOut) inst.gen.P₀
            bOut.initPhase [] (List.ofFn delTrace) with
        | none => rw [hs] at hmap; simp at hmap
        | some w =>
          rw [hs] at hmap
          simp only [Option.map_some, Option.some.injEq] at hmap
          dsimp only []
          rw [hmap]
          ring
    exact (hterm_eq.trans (by
      rw [tsum_runSuffixDelSteps_add_const hcert hbirth (ch bs₀ bOut)
            inst.gen.P₀.card [] hsurv₀ hph₀ bOut.work])).symm

theorem delete_remCopyWork_le {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    {n : ℕ} {σ θ netLogBound : ℝ} {facs : UL.BirthPoolPolyFactors}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))} {birthHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hcert : UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N birthHist inst)
    (stepHist : UL.ExecutionHistory d)
    {bState : BirthState} {S : Finset ι} {ph : PhaseState} {i : ι}
    (hbirth : inst.IsAcceptedBirth birthHist bState)
    (hsurv : inst.gen.IsSurvivingSubset S)
    (hph : inst.IsAcceptedPhase birthHist bState S ph)
    (hi : i ∈ S) :
    expWithBits (inst.deleteWithBits stepHist bState S ph i)
      (fun dOut =>
        (dOut.work : ENNReal) +
          remCopyWork inst bState (S.erase i) dOut.nextPhase) ≤
    remCopyWork inst bState S ph := by
  rcases hcert.2.2.2.2.2.2.2.1 stepHist bState S ph i hbirth hsurv hph hi with
    ⟨hpf_del_raw, _, hd_caps⟩
  have hpf_del : IsPrefixFree (inst.deleteWithBits stepHist bState S ph i) := hpf_del_raw
  unfold expWithBits remCopyWork
  refine (tsum_add_iSup_le hpf_del (fun dOut => (dOut.work : ENNReal))
    (fun dOut (pol : ValidSuffixPol ι d PhaseState) =>
      ∑' tr : Fin (S.erase i).card → List Bool,
        match runSuffixDelSteps inst bState pol (S.erase i) dOut.nextPhase []
            (List.ofFn tr) with
        | some w => UL.prefixTraceProb tr * (w : ENNReal)
        | none => 0)).trans (iSup_le fun ch => ?_)
  let pol₀ : ValidSuffixPol ι d PhaseState :=
    ⟨fun S_cur ph_cur relLog =>
      match relLog with
      | [] => if i ∈ S_cur then some (stepHist, i) else none
      | (_, bs₁) :: restLog =>
          match inst.deleteWithBits stepHist bState S ph i bs₁ with
          | some dOut => (ch bs₁ dOut).val S_cur ph_cur restLog
          | none => none,
     by
       intro S_cur ph_cur relLog sh j hpol
       cases relLog with
       | nil =>
         dsimp only [] at hpol
         split_ifs at hpol with hi_cur
         simp only [Option.some.injEq, Prod.mk.injEq] at hpol
         rcases hpol with ⟨_, rfl⟩
         exact hi_cur
       | cons hd restLog =>
         dsimp only [] at hpol
         cases hdb : inst.deleteWithBits stepHist bState S ph i hd.2 with
         | none => rw [hdb] at hpol; simp at hpol
         | some dOut =>
           rw [hdb] at hpol
           exact (ch hd.2 dOut).2 S_cur ph_cur restLog sh j hpol⟩
  refine le_trans ?_ (le_iSup (fun pol : ValidSuffixPol ι d PhaseState =>
    ∑' tr : Fin S.card → List Bool,
      match runSuffixDelSteps inst bState pol S ph [] (List.ofFn tr) with
      | some w => UL.prefixTraceProb tr * (w : ENNReal)
      | none => 0) pol₀)
  have hcard : (S.erase i).card + 1 = S.card := Finset.card_erase_add_one hi
  rw [← (finFunCongr hcard (List Bool)).tsum_eq]
  simp_rw [ofFn_finFunCongr hcard, prefixTraceProb_cast hcard]
  rw [tsum_fin_succ]
  refine le_of_eq ?_
  refine tsum_congr fun bs₁ => ?_
  have hcons_fn : ∀ rest : Fin (S.erase i).card → List Bool,
      List.ofFn (Fin.cons bs₁ rest) = bs₁ :: List.ofFn rest := by
    intro rest; rw [List.ofFn_succ]; simp
  cases hdb₁ : inst.deleteWithBits stepHist bState S ph i bs₁ with
  | none =>
    have h0 : ∀ rest : Fin (S.erase i).card → List Bool,
        (match runSuffixDelSteps inst bState pol₀ S ph []
            (List.ofFn (Fin.cons bs₁ rest)) with
         | some w => UL.prefixTraceProb (Fin.cons bs₁ rest) * (w : ENNReal)
         | none => 0) = 0 := by
      intro rest
      rw [hcons_fn]
      simp [runSuffixDelSteps, pol₀, hi, hdb₁]
    simp_rw [h0, tsum_zero]
  | some dOut =>
    dsimp only []
    rcases hd_caps bs₁ dOut hdb₁ with ⟨hph', _⟩
    have hsurv' : inst.gen.IsSurvivingSubset (S.erase i) :=
      (Finset.erase_subset i S).trans hsurv
    have hshift : ∀ S' ph' tailLog,
        pol₀.val S' ph' ([(i, bs₁)] ++ tailLog) =
          (ch bs₁ dOut).val S' ph' tailLog := by
      intro S' ph' tailLog
      simp [pol₀, hdb₁]
    have hrhs_eq :
        (∑' rest : Fin (S.erase i).card → List Bool,
          match runSuffixDelSteps inst bState pol₀ S ph []
              (List.ofFn (Fin.cons bs₁ rest)) with
          | some w => UL.prefixTraceProb (Fin.cons bs₁ rest) * (w : ENNReal)
          | none => 0) =
        UL.bitListProb bs₁ *
          (∑' rest : Fin (S.erase i).card → List Bool,
            match runSuffixDelSteps inst bState (ch bs₁ dOut) (S.erase i)
                dOut.nextPhase [] (List.ofFn rest) with
            | some w => UL.prefixTraceProb rest * ((dOut.work + w : ℕ) : ENNReal)
            | none => 0) := by
      rw [← ENNReal.tsum_mul_left]
      refine tsum_congr fun rest => ?_
      rw [hcons_fn, prefixTraceProb_cons]
      have hstep0 :
          runSuffixDelSteps inst bState pol₀ S ph [] (bs₁ :: List.ofFn rest) =
          match runSuffixDelSteps inst bState pol₀ (S.erase i) dOut.nextPhase
              ([(i, bs₁)] ++ []) (List.ofFn rest) with
          | none => none
          | some wRest => some (dOut.work + wRest) := by
        simp [runSuffixDelSteps, pol₀, hi, hdb₁]
      rw [hstep0,
          runSuffixDelSteps_shift_log inst bState [(i, bs₁)] hshift
            (List.ofFn rest) (S.erase i) dOut.nextPhase []]
      cases runSuffixDelSteps inst bState (ch bs₁ dOut) (S.erase i)
          dOut.nextPhase [] (List.ofFn rest) with
      | none => simp
      | some wRest =>
        dsimp only []
        ring
    rw [hrhs_eq,
        tsum_runSuffixDelSteps_add_const hcert hbirth (ch bs₁ dOut)
          (S.erase i).card [] hsurv' hph' dOut.work]

/-! ### 3. Markov's Inequality, `R`-Copy Racing, and Direction-Net Union Bound -/

noncomputable def certCap (n : ℕ) (θ : ℝ) (facs : UL.BirthPoolPolyFactors) : ℕ :=
  Nat.ceil (4 * facs.queryWorkBound n θ)

theorem certCap_ge_four_query (n : ℕ) (θ : ℝ) (facs : UL.BirthPoolPolyFactors) :
    4 * facs.queryWorkBound n θ ≤ (certCap n θ facs : ℝ) :=
  Nat.le_ceil _

theorem certCap_le_five_query {n : ℕ} {θ : ℝ} {facs : UL.BirthPoolPolyFactors}
    (hn : 2 ≤ n) (hθ : 0 ≤ θ) (hfacs : facs.Valid) :
    (certCap n θ facs : ℝ) ≤ 5 * facs.queryWorkBound n θ := by
  have hQ1 : 1 ≤ facs.queryWorkBound n θ := queryWorkBound_ge_one hn hθ hfacs
  unfold certCap
  have hlt : (Nat.ceil (4 * facs.queryWorkBound n θ) : ℝ) ≤
      4 * facs.queryWorkBound n θ + 1 :=
    (Nat.ceil_lt_add_one (by linarith)).le
  linarith

open Classical in
theorem birthVar_nonneg_of_accepted {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    {n : ℕ} {σ θ netLogBound : ℝ} {facs : UL.BirthPoolPolyFactors}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))} {birthHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hcert : UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N birthHist inst)
    {bState : BirthState} (hbirth : inst.IsAcceptedBirth birthHist bState)
    {z : EuclideanSpace ℝ (Fin d_s)} (hz : z ∈ N) :
    0 ≤ inst.birthVar bState z := by
  rcases hcert.2.2.2.2.2.2.2.2.2.2.1 bState z hbirth hz with ⟨hql, hinc⟩
  unfold UL.CertifiedSearchGeneration.birthVar
    UL.CertifiedSearchGeneration.rejectedBirthPoolIncidenceCost
  have hsum : 0 ≤ ∑ i ∈
      inst.gen.P₀.filter (fun i => inner ℝ (inst.gen.pts i) z ≤ -inst.δ),
      inst.birthPointIncidenceCost bState z i :=
    Finset.sum_nonneg fun i hi => hinc i (Finset.mem_of_mem_filter i hi)
  linarith

open Classical in
theorem copy_slow_prob_le_quarter {ι : Type} [DecidableEq ι] {d d_s : ℕ}
    {BirthState PhaseState : Type}
    {n : ℕ} {σ θ netLogBound : ℝ} {facs : UL.BirthPoolPolyFactors}
    {N : Finset (EuclideanSpace ℝ (Fin d_s))} {birthHist : UL.ExecutionHistory d}
    {inst : UL.CertifiedSearchGeneration ι d d_s BirthState PhaseState}
    (hcert : UL.SatisfiesCertifiedBirthPoolFactorsAtHistory n σ θ netLogBound facs N birthHist inst)
    {z : EuclideanSpace ℝ (Fin d_s)} (hz : z ∈ N) :
    expWithBits (inst.buildWithBits birthHist)
      (fun bOut =>
        if (certCap n θ facs : ℝ) < inst.birthVar bOut.birthState z then 1 else 0) ≤
    ENNReal.ofReal (1 / 4) := by
  have hparams := hcert.1
  have hfacs_v := hcert.2.1
  have hb_caps := hcert.2.2.2.2.2.2.1
  rcases hcert.2.2.2.2.2.2.2.2.2.2.2.1 z hz with ⟨hbv_ne_top, hbv_le⟩
  let Q := facs.queryWorkBound n θ
  have hQ_ge1 : 1 ≤ Q := queryWorkBound_ge_one hparams.1 (hparams.2.2.2.1.trans hparams.2.2.2.2) hfacs_v
  have h4Q_pos : 0 < 4 * Q := by linarith
  have h4Q_ne0 : ENNReal.ofReal (4 * Q) ≠ 0 := (ENNReal.ofReal_pos.mpr h4Q_pos).ne'
  have h4Q_netop : ENNReal.ofReal (4 * Q) ≠ ⊤ := ENNReal.ofReal_ne_top
  refine (ENNReal.mul_le_mul_left h4Q_ne0 h4Q_netop).mp ?_
  rw [← expWithBits_const_mul]
  have hmarkov :
      expWithBits (inst.buildWithBits birthHist)
        (fun bOut =>
          ENNReal.ofReal (4 * Q) *
            (if (certCap n θ facs : ℝ) < inst.birthVar bOut.birthState z then 1 else 0)) ≤
      inst.birthVarExpected birthHist z := by
    have hbve_eq : inst.birthVarExpected birthHist z =
        expWithBits (inst.buildWithBits birthHist)
          (fun bOut => ENNReal.ofReal (inst.birthVar bOut.birthState z)) := by
      unfold UL.CertifiedSearchGeneration.birthVarExpected expWithBits
      refine tsum_congr fun bs => ?_
      cases inst.buildWithBits birthHist bs <;> rfl
    rw [hbve_eq]
    refine expWithBits_mono fun bs bOut hb => ?_
    by_cases hgt : (certCap n θ facs : ℝ) < inst.birthVar bOut.birthState z
    · rw [if_pos hgt, mul_one]
      have hcap := certCap_ge_four_query n θ facs
      exact ENNReal.ofReal_le_ofReal (by dsimp [Q]; linarith)
    · rw [if_neg hgt, mul_zero]
      exact zero_le _
  have hbve_bound : inst.birthVarExpected birthHist z ≤
      ENNReal.ofReal (4 * Q) * ENNReal.ofReal (1 / 4) := by
    have hle1 : inst.birthVarExpected birthHist z ≤ ENNReal.ofReal Q :=
      (ENNReal.le_ofReal_iff_toReal_le hbv_ne_top (by linarith)).mpr hbv_le
    have hmul_eq : ENNReal.ofReal (4 * Q) * ENNReal.ofReal (1 / 4) = ENNReal.ofReal Q := by
      rw [← ENNReal.ofReal_mul (by linarith)]
      congr 1
      ring
    rwa [hmul_eq]
  exact hmarkov.trans hbve_bound

def IsBadGroup {ι : Type} {d d_s : ℕ} {B P : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s B P)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (cap : ℕ) (bStates : List B) : Prop :=
  ∃ z ∈ N, ∀ b ∈ bStates, (cap : ℝ) < inst.birthVar b z

open Classical in
theorem isBadGroup_le_sum_dirs {ι : Type} {d d_s : ℕ} {B P : Type}
    (inst : UL.CertifiedSearchGeneration ι d d_s B P)
    (N : Finset (EuclideanSpace ℝ (Fin d_s)))
    (cap : ℕ) (bStates : List B) :
    (if IsBadGroup inst N cap bStates then (1 : ENNReal) else 0) ≤
      ∑ z ∈ N,
        if (∀ b ∈ bStates, (cap : ℝ) < inst.birthVar b z) then (1 : ENNReal) else 0 := by
  by_cases hbad : IsBadGroup inst N cap bStates
  · rw [if_pos hbad]
    rcases hbad with ⟨z₀, hz₀, hall₀⟩
    have h1 : (1 : ENNReal) =
        if (∀ b ∈ bStates, (cap : ℝ) < inst.birthVar b z₀) then (1 : ENNReal) else 0 := by
      rw [if_pos hall₀]
    conv_lhs => rw [h1]
    exact Finset.single_le_sum
      (f := fun z => if (∀ b ∈ bStates, (cap : ℝ) < inst.birthVar b z) then (1 : ENNReal) else 0)
      (fun _ _ => zero_le _) hz₀
  · rw [if_neg hbad]
    exact zero_le _

noncomputable def certGroupCopies (n : ℕ) (P_life netLogBound : ℝ) : ℕ :=
  3 * Nat.ceil (1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound)

theorem certGroupCopies_ge_three {n : ℕ} {P_life netLogBound : ℝ}
    (hn : 2 ≤ n) (hP : 1 ≤ P_life) (hnet : 0 ≤ netLogBound) :
    3 ≤ certGroupCopies n P_life netLogBound := by
  unfold certGroupCopies
  have hlog_nn := log_two_n_Plife_nonneg hn hP
  have hpos : 0 < 1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound := by linarith
  have hc1 : 1 ≤ Nat.ceil (1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound) :=
    Nat.one_le_iff_ne_zero.mpr (Nat.ceil_pos.mpr hpos).ne'
  omega

theorem certGroupCopies_le_six_base {n : ℕ} {P_life netLogBound : ℝ}
    (hn : 2 ≤ n) (hP : 1 ≤ P_life) (hnet : 0 ≤ netLogBound) :
    (certGroupCopies n P_life netLogBound : ℝ) ≤
      6 * (1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound) := by
  set B : ℝ := 1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound
  have hlog_nn := log_two_n_Plife_nonneg hn hP
  have hB_ge1 : 1 ≤ B := by dsimp [B]; linarith
  unfold certGroupCopies
  have hlt : (Nat.ceil B : ℝ) ≤ B + 1 := (Nat.ceil_lt_add_one (by linarith)).le
  push_cast
  linarith

theorem badGroup_prob_scaled_le_one_net {rem maxOps n Ncard : ℕ} {P_life netLogBound : ℝ}
    (hn : 2 ≤ n) (hP : 1 ≤ P_life) (hnet : 0 ≤ netLogBound)
    (hN_pos : 1 ≤ Ncard)
    (hN : Real.log (Ncard : ℝ) ≤ netLogBound)
    (hmax : (maxOps : ℝ) ≤ (n : ℝ) * P_life)
    (hrem : rem ≤ maxOps) :
    (rem * (n + 1) : ℝ) *
      ((Ncard : ℝ) * (1 / 4 : ℝ) ^ certGroupCopies n P_life netLogBound) ≤ 1 := by
  set B : ℝ := 1 + Real.log (2 * (n : ℝ) * P_life) + netLogBound
  set R : ℕ := certGroupCopies n P_life netLogBound
  have hn_real : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have h2nP_pos : 0 < 2 * (n : ℝ) * P_life := by positivity
  have hN_real_pos : (0 : ℝ) < (Ncard : ℝ) := by exact_mod_cast hN_pos
  have hB_le_ceil : B ≤ (Nat.ceil B : ℝ) := Nat.le_ceil B
  have h3B_le_R : 3 * B ≤ (R : ℝ) := by
    dsimp [R, certGroupCopies, B]
    push_cast
    linarith
  have hN_le_exp : (Ncard : ℝ) ≤ Real.exp netLogBound := by
    have hexp := Real.exp_le_exp.mpr hN
    rwa [Real.exp_log hN_real_pos] at hexp
  have hpow_le : (1 / 4 : ℝ) ^ R ≤ ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ * Real.exp (- netLogBound) := by
    calc
      (1 / 4 : ℝ) ^ R ≤ Real.exp (- (R : ℝ)) := quarter_pow_le_exp_neg R
      _ ≤ Real.exp (- (3 * B)) := Real.exp_le_exp.mpr (by linarith)
      _ ≤ Real.exp (- (3 : ℝ) * Real.log (2 * (n : ℝ) * P_life) - netLogBound) := by
            apply Real.exp_le_exp.mpr
            dsimp [B]
            linarith
      _ = Real.exp (- ((3 : ℕ) * Real.log (2 * (n : ℝ) * P_life))) * Real.exp (- netLogBound) := by
            rw [sub_eq_add_neg, Real.exp_add]
            norm_num
      _ = ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ * Real.exp (- netLogBound) := by
            rw [Real.exp_neg, Real.exp_nat_mul, Real.exp_log h2nP_pos]
  have hN_pow_le : (Ncard : ℝ) * (1 / 4 : ℝ) ^ R ≤ ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ := by
    calc
      (Ncard : ℝ) * (1 / 4 : ℝ) ^ R
          ≤ Real.exp netLogBound * (((2 * (n : ℝ) * P_life) ^ 3)⁻¹ * Real.exp (- netLogBound)) :=
            mul_le_mul hN_le_exp hpow_le (by positivity) (Real.exp_pos _).le
      _ = ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ * (Real.exp netLogBound * Real.exp (- netLogBound)) := by
            ring
      _ = ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ := by
            rw [← Real.exp_add, add_neg_cancel, Real.exp_zero, mul_one]
  have hrem_le : (rem * (n + 1) : ℝ) ≤ (2 * (n : ℝ) * P_life) ^ 3 := by
    have hr1 : (rem : ℝ) ≤ (maxOps : ℝ) := by exact_mod_cast hrem
    have hr2 : (rem : ℝ) ≤ (n : ℝ) * P_life := hr1.trans hmax
    have hn1 : (n + 1 : ℝ) ≤ 2 * (n : ℝ) := by
      push_cast
      linarith
    have hmul1 : (rem : ℝ) * (n + 1 : ℝ) ≤ ((n : ℝ) * P_life) * (2 * (n : ℝ)) :=
      mul_le_mul hr2 hn1 (by positivity) (by positivity)
    have hcube : ((n : ℝ) * P_life) * (2 * (n : ℝ)) ≤ (2 * (n : ℝ) * P_life) ^ 3 := by
      have h1 : 1 ≤ 4 * (n : ℝ) * P_life ^ 2 := by nlinarith
      calc
        ((n : ℝ) * P_life) * (2 * (n : ℝ)) = (2 * (n : ℝ) ^ 2 * P_life) * 1 := by ring
        _ ≤ (2 * (n : ℝ) ^ 2 * P_life) * (4 * (n : ℝ) * P_life ^ 2) :=
              mul_le_mul_of_nonneg_left h1 (by positivity)
        _ = (2 * (n : ℝ) * P_life) ^ 3 := by ring
    push_cast at hmul1 ⊢
    linarith
  calc
    (rem * (n + 1) : ℝ) * ((Ncard : ℝ) * (1 / 4 : ℝ) ^ R)
        ≤ ((2 * (n : ℝ) * P_life) ^ 3) * ((2 * (n : ℝ) * P_life) ^ 3)⁻¹ :=
          mul_le_mul hrem_le hN_pow_le (by positivity) (by positivity)
    _ = 1 := mul_inv_cancel₀ (pow_ne_zero 3 h2nP_pos.ne')

/-! ### 4. Lifted Query Compatibility & Zero-Error Group Answer Lemma -/

theorem liftQuery_certifiedCompatible {ι : Type} [DecidableEq ι] {d d_s : ℕ} {B P : Type}
    {pts : ι → EuclideanSpace ℝ (Fin d_s)} {δ_margin : ℝ}
    {S : Finset ι} {active : Finset (ι × ℕ)} (himg : active.image Prod.fst = S)
    {gen : UL.SearchGeneration (ι × ℕ) d_s}
    {inst : UL.CertifiedSearchGeneration (ι × ℕ) d d_s B P}
    (hgen : inst.gen = gen) (hδ : inst.δ = δ_margin)
    (hpts : ∀ p ∈ gen.P₀, gen.pts p = pts p.1)
    {S_grp : Finset (ι × ℕ)} (hsub_act : S_grp ⊆ active) (hsub_P0 : S_grp ⊆ gen.P₀)
    {q : UL.SearchQuery ι d_s}
    (hadm : (δ_margin = 0 ∧ UL.IsCompatibleTest pts S q.z q.accept) ∨
      UL.IsMarginCompatibleTest pts S δ_margin q.z q.accept) :
    UL.IsCertifiedCompatible inst.gen inst.δ S_grp (UL.liftQueryToLifetimes q) := by
  unfold UL.IsCertifiedCompatible
  rw [hgen, hδ]
  rcases hadm with ⟨hδ0, hcomp⟩ | ⟨hδ_pos, hmarg⟩
  · refine Or.inl ⟨hδ0, ?_⟩
    intro p hp hnacc
    have hp_S : p.1 ∈ S := by
      rw [← himg]
      exact Finset.mem_image.mpr ⟨p, hsub_act hp, rfl⟩
    have hle := hcomp p.1 hp_S hnacc
    simpa [UL.liftQueryToLifetimes, hpts p (hsub_P0 hp)] using hle
  · refine Or.inr ⟨hδ_pos, ?_⟩
    intro p hp hnacc
    have hp_S : p.1 ∈ S := by
      rw [← himg]
      exact Finset.mem_image.mpr ⟨p, hsub_act hp, rfl⟩
    have hle := hmarg p.1 hp_S hnacc
    simpa [UL.liftQueryToLifetimes, hpts p (hsub_P0 hp)] using hle

theorem no_target_on_slice_of_no_accepted {ι : Type} [DecidableEq ι] {d_s : ℕ}
    {pts : ι → EuclideanSpace ℝ (Fin d_s)} {h δ_margin : ℝ} (h_pos : 0 < h)
    {S : Finset ι} {active : Finset (ι × ℕ)} (himg : active.image Prod.fst = S)
    {S_grp : Finset (ι × ℕ)} (hsub_act : S_grp ⊆ active)
    {q : UL.SearchQuery ι d_s}
    (hadm : (δ_margin = 0 ∧ UL.IsCompatibleTest pts S q.z q.accept) ∨
      UL.IsMarginCompatibleTest pts S δ_margin q.z q.accept)
    (hno_acc : ¬ ∃ p ∈ S_grp, q.accept p.1)
    {p : ι × ℕ} (hp : p ∈ S_grp) : ¬ (h ≤ inner ℝ (pts p.1) q.z) := by
  intro hge
  have hnacc : ¬ q.accept p.1 := fun hacc => hno_acc ⟨p, hp, hacc⟩
  have hp_S : p.1 ∈ S := by
    rw [← himg]
    exact Finset.mem_image.mpr ⟨p, hsub_act hp, rfl⟩
  rcases hadm with ⟨_, hcomp⟩ | ⟨hδ_pos, hmarg⟩
  · have hle := hcomp p.1 hp_S hnacc
    linarith
  · have hle := hmarg p.1 hp_S hnacc
    linarith

end UL.Proof_lem_7_1_RaceV31
