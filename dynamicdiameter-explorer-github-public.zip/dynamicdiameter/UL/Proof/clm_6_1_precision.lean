import UL.Stmt.clm_6_1_precision
import UL.Stmt.lem_5_6
import UL.Stmt.clm_5_4_queries_and_caps
import UL.Stmt.lem_6_2
import UL.Stmt.lem_6_3
import UL.Stmt.clm_6_1_adaptive
import UL.Proof.clm_6_1_precision.RaceV30_H1
import UL.Proof.clm_6_1_precision.RaceV30_H4
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_6_1_precision (h_lem_5_6 : S_lem_5_6) (h_clm_5_4_queries_and_caps : S_clm_5_4_queries_and_caps) (h_lem_6_2 : S_lem_6_2) (h_lem_6_3 : S_lem_6_3) (h_clm_6_1_adaptive : S_clm_6_1_adaptive) : S_clm_6_1_precision := by
  unfold S_clm_6_1_precision
  unfold S_lem_6_2 at h_lem_6_2
  intro h_min h_max hh_min hh_le hh_max ℓ hℓ
  exact ⟨UL.Proof_clm_6_1_precision_RaceV30.part1_proof,
    UL.Proof_clm_6_1_precision_RaceV30.part2_proof,
    UL.Proof_clm_6_1_precision_RaceV30.part3_proof,
    UL.Proof_clm_6_1_precision_RaceV30.part4_proof hh_min hh_le hh_max hℓ
      (h_lem_6_2 h_min h_max hh_min hh_le hh_max)⟩

end UL
