import UL.Stmt.cit_hw87_halfspace_net
import UL.Proof.cit_hw87_halfspace_net.H1
import UL.Proof.cit_hw87_halfspace_net.H2
import UL.Proof.cit_hw87_halfspace_net.H3
import UL.Proof.cit_hw87_halfspace_net.H4
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_cit_hw87_halfspace_net : S_cit_hw87_halfspace_net := by
  unfold S_cit_hw87_halfspace_net
  classical
  refine ⟨64, by norm_num, ?_⟩
  intro D hD ι _ _ P α hα0 hα1 δ hδ0 hδ1 s hs
  obtain ⟨hαs, hDs, h_tail⟩ :=
    Proof_cit_hw87_halfspace_net.hw87_analytic_bound D hD α hα0 hα1 δ hδ0 hδ1 s hs
  let 𝒜 : Finset (Finset ι) :=
    Finset.univ.filter (fun A : Finset ι =>
      ∃ H : Set (EuclideanSpace ℝ (Fin D)),
        IsClosedHalfspace H ∧ A = Finset.univ.filter (fun i : ι => P i ∈ H))
  let M : ℝ := (Real.exp 1 * (2 * (s : ℝ)) / ((D : ℝ) + 1)) ^ (D + 1)
  have h_card_sum : Fintype.card (Fin s ⊕ Fin s) = 2 * s := by
    simp [Fintype.card_sum, Fintype.card_fin, two_mul]
  have hM : ∀ xy : (Fin s → ι) × (Fin s → ι),
      ((𝒜.image (fun A : Finset ι =>
        Finset.univ.filter (fun u : Fin s ⊕ Fin s => Sum.elim xy.1 xy.2 u ∈ A))).card : ℝ) ≤ M := by
    intro xy
    let ℬ : Finset (Finset (Fin s ⊕ Fin s)) :=
      𝒜.image (fun A : Finset ι =>
        Finset.univ.filter (fun u : Fin s ⊕ Fin s => Sum.elim xy.1 xy.2 u ∈ A))
    have hℬ : ∀ B ∈ ℬ, ∃ H : Set (EuclideanSpace ℝ (Fin D)),
        IsClosedHalfspace H ∧
        B = Finset.univ.filter (fun u : Fin s ⊕ Fin s => P (Sum.elim xy.1 xy.2 u) ∈ H) := by
      intro B hB
      rcases Finset.mem_image.mp hB with ⟨A, hA, rfl⟩
      rcases (Finset.mem_filter.mp hA).2 with ⟨H, hH, rfl⟩
      refine ⟨H, hH, ?_⟩
      ext u
      simp
    have hm : D + 1 ≤ Fintype.card (Fin s ⊕ Fin s) := by
      omega
    have h_tr :=
      Proof_cit_hw87_halfspace_net.card_halfspace_traces_le
        (Q := fun u : Fin s ⊕ Fin s => P (Sum.elim xy.1 xy.2 u)) ℬ hℬ hm
    simpa only [ℬ, M, h_card_sum, Nat.cast_mul, Nat.cast_ofNat] using h_tr
  have h_bad_le :
      ((Finset.univ.filter (fun x : Fin s → ι =>
          ∃ A ∈ 𝒜, α * (Fintype.card ι : ℝ) ≤ (A.card : ℝ) ∧ ∀ j : Fin s, x j ∉ A)).card : ℝ) /
        (Fintype.card (Fin s → ι) : ℝ) ≤ δ :=
    (Proof_cit_hw87_halfspace_net.double_sampling_bad_bound 𝒜 α s M hαs hM).trans h_tail
  have h_not_net_iff : ∀ x : Fin s → ι,
      (¬ IsIndexedHalfspaceNet α P x) ↔
        (∃ A ∈ 𝒜, α * (Fintype.card ι : ℝ) ≤ (A.card : ℝ) ∧ ∀ j : Fin s, x j ∉ A) := by
    intro x
    unfold IsIndexedHalfspaceNet pointCount
    push_neg
    constructor
    · rintro ⟨H, hH, h_cnt, hx⟩
      let A : Finset ι := Finset.univ.filter (fun i : ι => P i ∈ H)
      refine ⟨A, Finset.mem_filter.mpr ⟨Finset.mem_univ _, ⟨H, hH, rfl⟩⟩, h_cnt, ?_⟩
      intro j
      simp [A, hx j]
    · rintro ⟨A, hA, h_cnt, hx⟩
      rcases (Finset.mem_filter.mp hA).2 with ⟨H, hH, rfl⟩
      refine ⟨H, hH, h_cnt, ?_⟩
      intro j
      have hxj := hx j
      simpa using hxj
  have h_indexed :
      1 - δ ≤ ((Finset.univ.filter (fun sample : Fin s → ι =>
          IsIndexedHalfspaceNet α P sample)).card : ℝ) /
        (Fintype.card (Fin s → ι) : ℝ) := by
    let Good := Finset.univ.filter (fun sample : Fin s → ι => IsIndexedHalfspaceNet α P sample)
    let Bad := Finset.univ.filter (fun x : Fin s → ι =>
      ∃ A ∈ 𝒜, α * (Fintype.card ι : ℝ) ≤ (A.card : ℝ) ∧ ∀ j : Fin s, x j ∉ A)
    have hBad_eq : Bad = Finset.univ.filter (fun sample : Fin s → ι =>
        ¬ IsIndexedHalfspaceNet α P sample) := by
      ext x
      simp [Bad, h_not_net_iff x]
    have h_part : Good.card + Bad.card = Fintype.card (Fin s → ι) := by
      rw [hBad_eq, ← Finset.card_univ]
      exact Finset.filter_card_add_filter_neg_card_eq_card (s := Finset.univ)
        (p := fun sample : Fin s → ι => IsIndexedHalfspaceNet α P sample)
    have hN_pos : (0 : ℝ) < (Fintype.card (Fin s → ι) : ℝ) := by
      exact Nat.cast_pos.mpr Fintype.card_pos
    have h_part_real : (Good.card : ℝ) + (Bad.card : ℝ) = (Fintype.card (Fin s → ι) : ℝ) := by
      exact_mod_cast h_part
    have h_div : (Good.card : ℝ) / (Fintype.card (Fin s → ι) : ℝ) +
        (Bad.card : ℝ) / (Fintype.card (Fin s → ι) : ℝ) = 1 := by
      rw [← add_div, h_part_real, div_self hN_pos.ne']
    have h_bad_le' : (Bad.card : ℝ) / (Fintype.card (Fin s → ι) : ℝ) ≤ δ := h_bad_le
    -- Need to match the Classical.decPred filter in S_cit_hw87_halfspace_net:
    change 1 - δ ≤ (Good.card : ℝ) / (Fintype.card (Fin s → ι) : ℝ)
    linarith
  refine ⟨h_indexed, ?_⟩
  intro hs_le
  have h_coup :=
    Proof_cit_hw87_halfspace_net.halfspaceNet_powersetCard_prob_ge_indexed α P s hs_le
  exact h_indexed.trans h_coup

end UL
