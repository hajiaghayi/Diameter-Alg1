import UL.Stmt.lem_5_6
import UL.Stmt.clm_5_2_config_gap
import UL.Proof.lem_5_6.H1_Math
import UL.Proof.lem_5_6.H3_Prog
set_option autoImplicit false

namespace UL

open UL.Proof_lem_5_6

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_5_6 (h_clm_5_2_config_gap : S_clm_5_2_config_gap) : S_lem_5_6 := by
  have _ := h_clm_5_2_config_gap
  unfold S_lem_5_6
  refine ⟨l56ProgBit, l56ProgArith, 1000000, 3, ?_⟩
  intro a b g e hb0 hba ha1 hg0 hg_gap he0 he_le
  intro L_b L_e bound inpBit inpArith
  have hb1 : b ≤ 1 := hba.le.trans ha1
  have hb0_r : (0 : ℝ) ≤ (b : ℝ) := by exact_mod_cast hb0
  have ha1_r : (a : ℝ) ≤ 1 := by exact_mod_cast ha1
  have hg1 : g ≤ 1 := by
    have : 0 ≤ (1 + g) * (b : ℝ) := mul_nonneg (by linarith) hb0_r
    linarith
  have he16 : (e : ℝ) ≤ 1 / 16 := by linarith
  obtain ⟨outBit, outArith, hrunB, huB, hbB, hpcB, hpbB,
    hrunA, huA, hpcA, hB0, hB1, hB2, hB3, hA0_w, hA1_w, hA2_w, hA3_w⟩ :=
    l56_ram_exec_spec hb0 hb1 he0 he16
  obtain ⟨hAn1, hAn_le, hBn1, hBn_le, hBd_eq_Ad, hAd_lt_pow,
    hAd_pos, hBd_pos, hA_pos, hB_nn, hAB_sq, hpad⟩ :=
    l56ComputeAB_math_spec hb0 hba ha1 hg0 hg_gap he0 he_le
  set res := l56ComputeAB (Nat.ceil (1 / e)) b.num.toNat b.den
  refine ⟨outBit, outArith, hrunB, huB, hbB, hpcB, hpbB, hrunA, huA, hpcA, ?_⟩
  dsimp only
  have hS_le_S3 : L_b + L_e + 1 ≤ (L_b + L_e + 1) ^ 3 :=
    Nat.le_self_pow (by decide) (L_b + L_e + 1)
  have h27_bound : 2 * (4 * L_e + 12) + 3 ≤ bound := by
    have h1 : 2 * (4 * L_e + 12) + 3 ≤ 27 * (L_b + L_e + 1) := by omega
    have h2 : 27 * (L_b + L_e + 1) ≤ 1000000 * (L_b + L_e + 1) ^ 3 := by omega
    exact h1.trans h2
  have hib_An : intBitLength (res.1 : ℤ) ≤ bound := by
    have hlt : (res.1 : ℤ).natAbs < 2 ^ (4 * L_e + 12) := by
      rw [Int.natAbs_natCast]
      exact lt_of_le_of_lt hAn_le hAd_lt_pow
    exact (intBitLength_le_of_abs_lt_two_pow hlt).trans (by omega)
  have hib_Ad : intBitLength (res.2.1 : ℤ) ≤ bound := by
    have hlt : (res.2.1 : ℤ).natAbs < 2 ^ (4 * L_e + 12) := by
      rw [Int.natAbs_natCast]
      exact hAd_lt_pow
    exact (intBitLength_le_of_abs_lt_two_pow hlt).trans (by omega)
  have hib_Bn : intBitLength (res.2.2.1 : ℤ) ≤ bound := by
    have hlt : (res.2.2.1 : ℤ).natAbs < 2 ^ (4 * L_e + 12) := by
      rw [Int.natAbs_natCast]
      exact lt_of_le_of_lt (hBn_le.trans_eq hBd_eq_Ad) hAd_lt_pow
    exact (intBitLength_le_of_abs_lt_two_pow hlt).trans (by omega)
  have hib_Bd : intBitLength (res.2.2.2 : ℤ) ≤ bound := by
    rw [hBd_eq_Ad]
    exact hib_Ad
  have hrb_A : ratBitLength ((res.1 : ℚ) / (res.2.1 : ℚ)) ≤ bound :=
    (ratBitLength_div_nat_le hAn1 hAn_le hAd_lt_pow).trans h27_bound
  have hrb_B : ratBitLength ((res.2.2.1 : ℚ) / (res.2.2.2 : ℚ)) ≤ bound := by
    have hBd_lt : res.2.2.2 < 2 ^ (4 * L_e + 12) := hBd_eq_Ad.symm ▸ hAd_lt_pow
    exact (ratBitLength_div_nat_le hBn1 hBn_le hBd_lt).trans h27_bound
  rw [hB0, hB1, hB2, hB3, hA0_w, hA1_w, hA2_w, hA3_w]
  simp only [Int.cast_natCast]
  exact ⟨trivial, trivial, trivial, trivial, hAd_pos, hBd_pos,
    hib_An, hib_Ad, hib_Bn, hib_Bd, hrb_A, hrb_B,
    hA_pos, hB_nn, hAB_sq, hpad⟩

end UL
