import UL.Stmt.clm_5_1_mc_baseline
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_chain_contraction
set_option autoImplicit false

namespace UL

namespace Proof_clm_5_1_mc_baseline

open Classical in
private lemma pointCount_subtype_eq_card_filter {d : ℕ} {ι : Type*} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d)) (A : Finset ι)
    (T : Set (EuclideanSpace ℝ (Fin d))) :
    pointCount (fun i : ↥A => pts i.1) T = (A.filter (fun i => pts i ∈ T)).card := by
  unfold pointCount
  rw [← Finset.card_map ⟨Subtype.val, Subtype.val_injective⟩]
  apply congrArg Finset.card
  ext x
  simp [and_comm]

private lemma hasNodeAge_to_ops {ι : Type*} [DecidableEq ι]
    {P₀ S : Finset ι} {age : ℕ} (h : HasNodeAge P₀ S age) :
    ∃ ops : List (ι ⊕ ι),
      (ops.filter Sum.isRight).length ≤ age ∧
      ops.foldl (fun acc op =>
        match op with
        | Sum.inl j => insert j acc
        | Sum.inr j => acc.erase j) P₀ = S := by
  induction age generalizing S with
  | zero =>
    rcases h with ⟨seq, h0, hlast, _⟩
    have hEq : P₀ = S := by
      have : (0 : Fin 1) = Fin.last 0 := rfl
      rw [← h0, ← hlast, this]
    subst hEq
    exact ⟨[], by simp, rfl⟩
  | succ t ih =>
    rcases h with ⟨seq, h0, hlast, hstep⟩
    let seq' : Fin (t + 1) → Finset ι := fun j => seq j.castSucc
    let S_mid : Finset ι := seq (Fin.last t).castSucc
    have hmid : HasNodeAge P₀ S_mid t := by
      refine ⟨seq', h0, rfl, fun r => ?_⟩
      have hsucc : (r.succ : Fin (t + 1)).castSucc = r.castSucc.succ := by
        ext
        simp
      dsimp only [seq']
      rw [hsucc]
      exact hstep r.castSucc
    rcases ih hmid with ⟨ops_mid, hfilt_mid, hfold_mid⟩
    have hlast_step : IsInputChange S_mid S := by
      have hlast_eq : (Fin.last t).succ = Fin.last (t + 1) := by
        ext
        simp
      have hs := hstep (Fin.last t)
      rwa [hlast_eq, hlast] at hs
    rcases hlast_step with ⟨j, _, hS_eq⟩ | ⟨j, _, hS_eq⟩
    · have hS_ins : S = insert j S_mid := by
        rw [hS_eq]
        ext x
        simp
      refine ⟨ops_mid ++ [Sum.inl j], ?_, ?_⟩
      · simp only [List.filter_append]
        have hnil : ([Sum.inl j] : List (ι ⊕ ι)).filter Sum.isRight = [] := rfl
        rw [hnil, List.append_nil]
        omega
      · simp [List.foldl_append, hfold_mid, hS_ins]
    · have hS_era : S = S_mid.erase j := by
        rw [hS_eq]
        ext x
        simp
      refine ⟨ops_mid ++ [Sum.inr j], ?_, ?_⟩
      · simp only [List.filter_append]
        have hcons : ([Sum.inr j] : List (ι ⊕ ι)).filter Sum.isRight = [Sum.inr j] := rfl
        rw [hcons, List.length_append, List.length_singleton]
        omega
      · simp [List.foldl_append, hfold_mid, hS_era]

open Classical in
private lemma witness_count_lb
    (h_lem_5_1 : S_lem_5_1)
    {d : ℕ} {ι : Type} [DecidableEq ι]
    (pts : ι → EuclideanSpace ℝ (Fin d))
    {α : ℝ} (hα0 : 0 < α)
    (P₀ S : Finset ι) (hm : 1 ≤ P₀.card)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s))
    (age : ℕ) (hage : HasNodeAge P₀ S age)
    (q : EuclideanSpace ℝ (Fin d)) :
    α * (P₀.card : ℝ) - (age : ℝ) ≤
      ((S.filter (fun p => IsVarianceWitness o (liftVariance o s) q (pts p))).card : ℝ) := by
  rcases hasNodeAge_to_ops hage with ⟨ops, hfilt, rfl⟩
  set S_cur := ops.foldl (fun acc op =>
    match op with
    | Sum.inl j => insert j acc
    | Sum.inr j => acc.erase j) P₀
  unfold S_lem_5_1 at h_lem_5_1
  have hdepth : α * (P₀.card : ℝ) ≤
      (halfspaceDepth (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) : ℝ) := by
    unfold IsCenterpoint at hcp
    rwa [Fintype.card_coe] at hcp
  have h51 := (h_lem_5_1 d ι pts P₀ hm α hα0 o s hdepth).2.2 age ops hfilt
  dsimp only at h51
  have hwit_pc : α * (P₀.card : ℝ) - (age : ℝ) ≤
      (pointCount (fun i : ↥S_cur => pts i.1)
        {x | IsVarianceWitness o (liftVariance o s) q x} : ℝ) :=
    h51.2.2.2.2.2 q
  rw [pointCount_subtype_eq_card_filter] at hwit_pc
  simpa only [Set.mem_setOf_eq] using hwit_pc

private lemma ceil_sample_bound {α ψ : ℝ}
    (hα0 : 0 < α) (hα1 : α ≤ 1) (hψ0 : 0 < ψ) (hψ1 : ψ < 1) :
    let k := Nat.ceil (2 * α⁻¹ * Real.log (1 / ψ))
    1 ≤ k ∧ (1 - α / 2) ^ k ≤ ψ := by
  intro k
  have h1ψ : 1 < 1 / ψ := one_lt_one_div hψ0 hψ1
  have hlog_pos : 0 < Real.log (1 / ψ) := Real.log_pos h1ψ
  have hinv_pos : 0 < α⁻¹ := inv_pos.mpr hα0
  have hx_pos : 0 < 2 * α⁻¹ * Real.log (1 / ψ) :=
    mul_pos (mul_pos (by norm_num) hinv_pos) hlog_pos
  have hk_pos : 0 < k := Nat.ceil_pos.mpr hx_pos
  refine ⟨by omega, ?_⟩
  have hk_ge : 2 * α⁻¹ * Real.log (1 / ψ) ≤ (k : ℝ) := Nat.le_ceil _
  have hbase_nonneg : 0 ≤ 1 - α / 2 := by linarith
  have hexp_step : 1 - α / 2 ≤ Real.exp (-(α / 2)) := by
    have h := Real.add_one_le_exp (-(α / 2))
    linarith
  have hpow_le : (1 - α / 2) ^ k ≤ (Real.exp (-(α / 2))) ^ k :=
    pow_le_pow_left₀ hbase_nonneg hexp_step k
  rw [← Real.exp_nat_mul] at hpow_le
  have hmul_ge : (α / 2) * (2 * α⁻¹ * Real.log (1 / ψ)) ≤ (α / 2) * (k : ℝ) :=
    mul_le_mul_of_nonneg_left hk_ge (by linarith)
  have hα_ne : α ≠ 0 := ne_of_gt hα0
  have hlhs_eq : (α / 2) * (2 * α⁻¹ * Real.log (1 / ψ)) = -Real.log ψ := by
    rw [one_div, Real.log_inv]
    calc
      (α / 2) * (2 * α⁻¹ * -Real.log ψ) = (α * α⁻¹) * (-Real.log ψ) := by ring
      _ = 1 * (-Real.log ψ) := by rw [mul_inv_cancel₀ hα_ne]
      _ = -Real.log ψ := one_mul _
  rw [hlhs_eq] at hmul_ge
  have hexp_arg : (k : ℝ) * -(α / 2) ≤ Real.log ψ := by linarith
  have hexp_le : Real.exp ((k : ℝ) * -(α / 2)) ≤ ψ := by
    calc
      Real.exp ((k : ℝ) * -(α / 2)) ≤ Real.exp (Real.log ψ) := Real.exp_le_exp.mpr hexp_arg
      _ = ψ := Real.exp_log hψ0
  exact hpow_le.trans hexp_le

open Classical in
private lemma sample_fail_ratio_le {ι : Type*} [DecidableEq ι]
    (k : ℕ) (S : Finset ι) (hS_ne : S.Nonempty)
    (P : ι → Prop) (farthest : (Fin k → ι) → ι)
    {α ψ : ℝ} (hα0 : 0 < α) (hα1 : α ≤ 1)
    (hα_frac : (α / 2) * (S.card : ℝ) ≤ ((S.filter P).card : ℝ))
    (hpow_ψ : (1 - α / 2) ^ k ≤ ψ)
    (hmono : ∀ samp ∈ Fintype.piFinset (fun _ : Fin k => S),
      (∃ j : Fin k, P (samp j)) → P (farthest samp)) :
    let samples := Fintype.piFinset (fun _ : Fin k => S)
    (((samples.filter (fun samp => ¬ P (farthest samp))).card : ℝ) /
      (samples.card : ℝ)) ≤ ψ := by
  intro samples
  let W := S.filter P
  let bad := samples.filter (fun samp => ¬ P (farthest samp))
  let miss := Fintype.piFinset (fun _ : Fin k => S \ W)
  have hsub : bad ⊆ miss := by
    intro samp hsamp
    rcases Finset.mem_filter.mp hsamp with ⟨hsamp_mem, hnotP⟩
    rw [Fintype.mem_piFinset]
    intro j
    have hjS : samp j ∈ S := Fintype.mem_piFinset.mp hsamp_mem j
    refine Finset.mem_sdiff.mpr ⟨hjS, ?_⟩
    intro hjW
    have hjP : P (samp j) := (Finset.mem_filter.mp hjW).2
    exact hnotP (hmono samp hsamp_mem ⟨j, hjP⟩)
  have hbad_le_miss_nat : bad.card ≤ miss.card := Finset.card_le_card hsub
  have hmiss_card : miss.card = (S \ W).card ^ k := by
    simp [miss, Fintype.card_piFinset]
  have hsamples_card : samples.card = S.card ^ k := by
    simp [samples, Fintype.card_piFinset]
  have hS_pos_nat : 0 < S.card := Finset.card_pos.mpr hS_ne
  have hS_pos : (0 : ℝ) < (S.card : ℝ) := by exact_mod_cast hS_pos_nat
  have hsamples_pos : (0 : ℝ) < (samples.card : ℝ) := by
    rw [hsamples_card]
    push_cast
    exact pow_pos hS_pos k
  have hbad_le_miss : (bad.card : ℝ) ≤ ((S \ W).card : ℝ) ^ k := by
    have h1 : (bad.card : ℝ) ≤ (miss.card : ℝ) := by exact_mod_cast hbad_le_miss_nat
    rw [hmiss_card] at h1
    push_cast at h1
    exact h1
  have hdiv_le : (bad.card : ℝ) / (samples.card : ℝ) ≤
      (((S \ W).card : ℝ) / (S.card : ℝ)) ^ k := by
    calc
      (bad.card : ℝ) / (samples.card : ℝ)
          ≤ ((S \ W).card : ℝ) ^ k / (samples.card : ℝ) :=
            div_le_div_of_nonneg_right hbad_le_miss (le_of_lt hsamples_pos)
      _ = ((S \ W).card : ℝ) ^ k / (S.card : ℝ) ^ k := by
            rw [hsamples_card]
            push_cast
            rfl
      _ = (((S \ W).card : ℝ) / (S.card : ℝ)) ^ k := (div_pow _ _ _).symm
  have hsdiff_add : (S \ W).card + W.card = S.card :=
    Finset.card_sdiff_add_card_eq_card (Finset.filter_subset P S)
  have hsdiff_add_real : ((S \ W).card : ℝ) + (W.card : ℝ) = (S.card : ℝ) := by
    exact_mod_cast hsdiff_add
  have hsdiff_le : ((S \ W).card : ℝ) ≤ (1 - α / 2) * (S.card : ℝ) := by linarith
  have hratio_le : ((S \ W).card : ℝ) / (S.card : ℝ) ≤ 1 - α / 2 :=
    (div_le_iff₀ hS_pos).mpr hsdiff_le
  have hratio_nonneg : 0 ≤ ((S \ W).card : ℝ) / (S.card : ℝ) := by positivity
  have _ := hα0
  have _ := hα1
  have hpow_ratio : (((S \ W).card : ℝ) / (S.card : ℝ)) ^ k ≤ (1 - α / 2) ^ k :=
    pow_le_pow_left₀ hratio_nonneg hratio_le k
  exact hdiv_le.trans (hpow_ratio.trans hpow_ψ)

open Classical in
private theorem main (h_lem_5_1 : S_lem_5_1)
    (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction) :
    S_clm_5_1_mc_baseline := by
  unfold S_clm_5_1_mc_baseline
  have h_cc_raw := h_clm_5_1_chain_contraction
  unfold S_clm_5_1_chain_contraction at h_cc_raw
  rcases h_cc_raw with ⟨c₁, C_nodes, _, _, h_cc⟩
  refine ⟨2, by norm_num, ?_⟩
  intro α ψ hα0 hα1 hψ0 hψ1
  let k := Nat.ceil (2 * α⁻¹ * Real.log (1 / ψ))
  rcases ceil_sample_bound hα0 hα1 hψ0 hψ1 with ⟨hk_ge_one, hpow_ψ⟩
  refine ⟨k, hk_ge_one, le_rfl, ?_⟩
  intro d ι _ pts Hist P₀ S age o s
  have hpart1 :
      ∀ (y : Hist → EuclideanSpace ℝ (Fin d))
        (farthest : Hist → (Fin k → ι) → ι)
        (hist : Hist),
        1 ≤ (P₀ hist).card →
        IsCenterpoint α (paraboloidLiftSet (fun i : P₀ hist => pts i.1))
          (liftedPoint (o hist) (s hist)) →
        HasNodeAge (P₀ hist) (S hist) (age hist) →
        (age hist : ℝ) ≤ α * ((P₀ hist).card : ℝ) / 16 →
        let V := liftVariance (o hist) (s hist)
        let samples := Fintype.piFinset (fun _ : Fin k => S hist)
        (∀ samp ∈ samples,
          (∃ j : Fin k, farthest hist samp = samp j) ∧
          ∀ j : Fin k, ‖pts (samp j) - y hist‖ ≤ ‖pts (farthest hist samp) - y hist‖) →
        (S hist).Nonempty ∧
        (α / 2) * ((S hist).card : ℝ) ≤
          (((S hist).filter (fun p =>
            IsVarianceWitness (o hist) V (y hist) (pts p))).card : ℝ) ∧
        (((samples.filter (fun samp =>
            ¬ IsVarianceWitness (o hist) V (y hist)
                (pts (farthest hist samp)))).card : ℝ) /
          (samples.card : ℝ)) ≤ ψ := by
    dsimp only
    intro y farthest hist hm hcp hage hage_le hfarthest
    have hS_le : ((S hist).card : ℝ) ≤ (1 + α / 16) * ((P₀ hist).card : ℝ) :=
      ((h_cc d ι pts α hα0 hα1).1 (P₀ hist) (S hist) hm (o hist) (s hist) hcp
        (age hist) hage hage_le).2.1
    have hwit_pc := witness_count_lb h_lem_5_1 pts hα0 (P₀ hist) (S hist) hm
      (o hist) (s hist) hcp (age hist) hage (y hist)
    let V := liftVariance (o hist) (s hist)
    let W := (S hist).filter (fun p => IsVarianceWitness (o hist) V (y hist) (pts p))
    change α * ((P₀ hist).card : ℝ) - (age hist : ℝ) ≤ (W.card : ℝ) at hwit_pc
    have hm_real : (1 : ℝ) ≤ ((P₀ hist).card : ℝ) := by exact_mod_cast hm
    have hαm_pos : 0 < α * ((P₀ hist).card : ℝ) := mul_pos hα0 (by linarith)
    have hW_pos_real : (0 : ℝ) < (W.card : ℝ) := by linarith
    have hW_pos_nat : 0 < W.card := by exact_mod_cast hW_pos_real
    have hS_ne : (S hist).Nonempty :=
      (Finset.card_pos.mp hW_pos_nat).mono (Finset.filter_subset _ (S hist))
    have hS_le17 : ((S hist).card : ℝ) ≤ (17 / 16 : ℝ) * ((P₀ hist).card : ℝ) := by
      have h17 : 1 + α / 16 ≤ (17 / 16 : ℝ) := by linarith
      exact hS_le.trans (mul_le_mul_of_nonneg_right h17 (by linarith))
    have hα_frac : (α / 2) * ((S hist).card : ℝ) ≤ (W.card : ℝ) := by
      have hmul_S : (α / 2) * ((S hist).card : ℝ) ≤
          (α / 2) * ((17 / 16 : ℝ) * ((P₀ hist).card : ℝ)) :=
        mul_le_mul_of_nonneg_left hS_le17 (by linarith)
      linarith
    have hfail := sample_fail_ratio_le k (S hist) hS_ne
      (fun p => IsVarianceWitness (o hist) V (y hist) (pts p))
      (farthest hist) hα0 hα1 hα_frac hpow_ψ ?_
    · exact ⟨hS_ne, hα_frac, hfail⟩
    · intro samp hsamp hex
      rcases hex with ⟨j, hj⟩
      have hle_norm : ‖pts (samp j) - y hist‖ ≤ ‖pts (farthest hist samp) - y hist‖ :=
        (hfarthest samp hsamp).2 j
      have hle_sq : ‖pts (samp j) - y hist‖ ^ 2 ≤ ‖pts (farthest hist samp) - y hist‖ ^ 2 :=
        pow_le_pow_left₀ (norm_nonneg _) hle_norm 2
      unfold IsVarianceWitness at hj ⊢
      linarith
  refine ⟨hpart1, ?_⟩
  dsimp only
  intro y farthest hist hm hcp hage hage_le hy_max hfarthest
  have hp1 := (hpart1 (fun h => pts (y h)) farthest hist hm hcp hage hage_le hfarthest).2.2
  let V := liftVariance (o hist) (s hist)
  let samples := Fintype.piFinset (fun _ : Fin k => S hist)
  have hfilt_eq :
      samples.filter (fun samp =>
        ¬ IsNodeBaselinePair pts (o hist) V (S hist) (y hist) (farthest hist samp)) =
      samples.filter (fun samp =>
        ¬ IsVarianceWitness (o hist) V (pts (y hist)) (pts (farthest hist samp))) := by
    refine Finset.filter_congr (fun samp hsamp => ?_)
    apply not_congr
    rcases (hfarthest samp hsamp).1 with ⟨j, hj⟩
    have hjS : samp j ∈ S hist := Fintype.mem_piFinset.mp hsamp j
    have hfS : farthest hist samp ∈ S hist := by rwa [hj]
    rcases hy_max with ⟨hyS, hyR⟩
    unfold IsNodeBaselinePair IsVarianceWitness
    rw [norm_sub_rev (pts (y hist)) (pts (farthest hist samp)), ← hyR]
    exact ⟨fun h => h.2.2, fun h => ⟨hyS, hfS, h⟩⟩
  change (((samples.filter (fun samp =>
      ¬ IsNodeBaselinePair pts (o hist) V (S hist) (y hist) (farthest hist samp))).card : ℝ) /
    (samples.card : ℝ)) ≤ ψ
  rw [hfilt_eq]
  exact hp1

end Proof_clm_5_1_mc_baseline

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_5_1_mc_baseline (h_lem_5_1 : S_lem_5_1) (h_clm_5_1_chain_contraction : S_clm_5_1_chain_contraction) : S_clm_5_1_mc_baseline :=
  Proof_clm_5_1_mc_baseline.main h_lem_5_1 h_clm_5_1_chain_contraction

end UL
