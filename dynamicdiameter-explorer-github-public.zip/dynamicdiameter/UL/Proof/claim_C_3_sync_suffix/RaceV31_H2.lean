import Mathlib
import UL.Stmt.claim_C_3_sync_suffix
import UL.Stmt.clm_5_1_chain_contraction
import UL.Proof.claim_C_3_sync_suffix.RaceV31_H1
set_option autoImplicit false

namespace UL.Proof_claim_C_3_sync_suffix_v31

open scoped ENNReal

/-! ### 1. `HasNodeAge`, `nodeResidual`, and `chainInput` structural lemmas -/

lemma hasNodeAge_refl {ι : Type*} (S : Finset ι) : HasNodeAge S S 0 :=
  ⟨fun _ => S, rfl, rfl, fun r => Fin.elim0 r⟩

lemma hasNodeAge_step {ι : Type*} {P₀ S S' : Finset ι} {age : ℕ}
    (h : HasNodeAge P₀ S age) (hchg : IsInputChange S S') :
    HasNodeAge P₀ S' (age + 1) := by
  rcases h with ⟨seq, h0, hlast, hstep⟩
  refine ⟨Fin.snoc seq S', ?_, ?_, ?_⟩
  · simpa [Fin.snoc] using h0
  · simp [Fin.snoc_last]
  · intro r
    refine Fin.lastCases ?_ ?_ r
    · have hcast : (Fin.last age).castSucc = Fin.castSucc (Fin.last age) := rfl
      have hsucc : (Fin.last age).succ = Fin.last (age + 1) := by ext; simp
      rw [hsucc, Fin.snoc_last, Fin.snoc_castSucc, hlast]
      exact hchg
    · intro j
      have hsucc : (j.castSucc).succ = j.succ.castSucc := by ext; simp
      rw [hsucc, Fin.snoc_castSucc, Fin.snoc_castSucc]
      exact hstep j

open Classical in
lemma hasNodeAge_card_le {ι : Type*} {P₀ S : Finset ι} {age : ℕ}
    (h : HasNodeAge P₀ S age) : S.card ≤ P₀.card + age := by
  induction age generalizing S with
  | zero =>
      rcases h with ⟨seq, h0, hlast, _⟩
      have hEq : P₀ = S := by
        have : (0 : Fin 1) = Fin.last 0 := rfl
        rw [← h0, ← hlast, this]
      subst hEq
      omega
  | succ t ih =>
      rcases h with ⟨seq, h0, hlast, hstep⟩
      let S_mid := seq (Fin.last t).castSucc
      have hmid : HasNodeAge P₀ S_mid t := by
        refine ⟨fun j => seq j.castSucc, h0, rfl, fun r => ?_⟩
        have hsucc : (r.succ : Fin (t + 1)).castSucc = r.castSucc.succ := by ext; simp
        dsimp only
        rw [hsucc]
        exact hstep r.castSucc
      have hcard_mid := ih hmid
      have hlast_step : IsInputChange S_mid S := by
        have hlast_eq : (Fin.last t).succ = Fin.last (t + 1) := by ext; simp
        have hs := hstep (Fin.last t)
        rwa [hlast_eq, hlast] at hs
      rcases hlast_step with ⟨j, _, hS_eq⟩ | ⟨j, _, hS_eq⟩
      · subst hS_eq
        have h1 : (insert j S_mid).card ≤ S_mid.card + 1 := Finset.card_insert_le j S_mid
        omega
      · subst hS_eq
        have h1 : (S_mid.erase j).card ≤ S_mid.card := Finset.card_erase_le
        omega

open Classical in
lemma nodeResidual_eq_filter {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) :
    nodeResidual pts o V S = S.filter (fun i => pts i ∉ coreBall o V) := by
  ext x
  simp [nodeResidual, nodeCore]
  tauto

lemma nodeResidual_subset {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ι) :
    nodeResidual pts o V S ⊆ S := by
  classical
  exact Finset.sdiff_subset

lemma nodeResidual_congr {d : ℕ} {ι : Type*}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)} (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    {S : Finset ι} (hpts : ∀ x ∈ S, pts₁ x = pts₂ x) :
    nodeResidual pts₁ o V S = nodeResidual pts₂ o V S := by
  classical
  rw [nodeResidual_eq_filter, nodeResidual_eq_filter]
  refine Finset.filter_congr fun x hx => ?_
  rw [hpts x hx]

open Classical in
lemma filter_inputChange_or_eq {ι : Type*} (p : ι → Prop) [DecidablePred p]
    {S S' : Finset ι} (h : S' = S ∨ IsInputChange S S') :
    S'.filter p = S.filter p ∨ IsInputChange (S.filter p) (S'.filter p) := by
  rcases h with rfl | (⟨j, hj, rfl⟩ | ⟨j, hj, rfl⟩)
  · exact Or.inl rfl
  · rw [Finset.filter_insert]
    by_cases hp : p j
    · rw [if_pos hp]
      refine Or.inr (Or.inl ⟨j, ?_, rfl⟩)
      simp [hj]
    · rw [if_neg hp]
      exact Or.inl rfl
  · rw [Finset.filter_erase]
    by_cases hp : p j
    · refine Or.inr (Or.inr ⟨j, ?_, rfl⟩)
      exact Finset.mem_filter.mpr ⟨hj, hp⟩
    · refine Or.inl ?_
      refine Finset.erase_eq_of_notMem ?_
      simp [hp]

lemma chainInput_zero {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι) :
    chainInput pts nodes P 0 = P := rfl

lemma chainInput_succ {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (i : Fin k) :
    chainInput pts nodes P i.succ = (nodes i).residual pts (chainInput pts nodes P i.castSucc) :=
  rfl

lemma chainInput_subset {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ι)
    (j : Fin (k + 1)) :
    chainInput pts nodes P j ⊆ P := by
  induction j using Fin.induction with
  | zero => exact Finset.Subset.refl P
  | succ i ih =>
      rw [chainInput_succ]
      exact (nodeResidual_subset _ _ _ _).trans ih

lemma chainInput_congr {d : ℕ} {ι : Type*} {k : ℕ}
    {pts₁ pts₂ : ι → EuclideanSpace ℝ (Fin d)}
    {nodes₁ nodes₂ : Fin k → ChainNode d} {P : Finset ι}
    (hpts : ∀ x ∈ P, pts₁ x = pts₂ x)
    (hnodes : ∀ i : Fin k, nodes₁ i = nodes₂ i)
    (j : Fin (k + 1)) :
    chainInput pts₁ nodes₁ P j = chainInput pts₂ nodes₂ P j := by
  induction j using Fin.induction with
  | zero => rfl
  | succ i ih =>
      rw [chainInput_succ, chainInput_succ, ih, hnodes i]
      refine nodeResidual_congr _ _ fun x hx => hpts x ?_
      exact chainInput_subset pts₂ nodes₂ P i.castSucc hx

lemma chainInput_inputChange_or_eq {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d)
    {P P' : Finset ι} (h : P' = P ∨ IsInputChange P P') (j : Fin (k + 1)) :
    chainInput pts nodes P' j = chainInput pts nodes P j ∨
      IsInputChange (chainInput pts nodes P j) (chainInput pts nodes P' j) := by
  classical
  induction j using Fin.induction with
  | zero => exact h
  | succ i ih =>
      rw [chainInput_succ, chainInput_succ]
      unfold ChainNode.residual
      rw [nodeResidual_eq_filter, nodeResidual_eq_filter]
      exact filter_inputChange_or_eq (fun i_1 => pts i_1 ∉ coreBall (nodes i).o (nodes i).V) ih

lemma chainInput_append_left {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (L₁ L₂ : List (ChainNode d)) (P : Finset ι)
    (m : ℕ) (hm : m ≤ L₁.length) :
    chainInput pts (fun i : Fin (L₁ ++ L₂).length => (L₁ ++ L₂).get i) P
      ⟨m, Nat.lt_succ_of_le (by simp; omega)⟩ =
    chainInput pts (fun i : Fin L₁.length => L₁.get i) P
      ⟨m, Nat.lt_succ_of_le hm⟩ := by
  induction m with
  | zero => rfl
  | succ m' ih =>
      have hm' : m' < L₁.length := Nat.lt_of_succ_le hm
      have hL : m' < (L₁ ++ L₂).length := by simp; omega
      have hsucc₁ : (⟨m' + 1, Nat.lt_succ_of_le (by simp; omega)⟩ : Fin ((L₁ ++ L₂).length + 1)) =
          (⟨m', hL⟩ : Fin (L₁ ++ L₂).length).succ := rfl
      have hsucc₂ : (⟨m' + 1, Nat.lt_succ_of_le hm⟩ : Fin (L₁.length + 1)) =
          (⟨m', hm'⟩ : Fin L₁.length).succ := rfl
      rw [hsucc₁, hsucc₂, chainInput_succ, chainInput_succ]
      have hget : (L₁ ++ L₂).get ⟨m', hL⟩ = L₁.get ⟨m', hm'⟩ := by
        simp [List.get_eq_getElem, List.getElem_append_left hm']
      rw [hget]
      congr 1
      exact ih (Nat.le_of_lt hm')

lemma chainInput_append_right {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (L₁ L₂ : List (ChainNode d)) (P : Finset ι)
    (r : ℕ) (hr : r ≤ L₂.length) :
    chainInput pts (fun i : Fin (L₁ ++ L₂).length => (L₁ ++ L₂).get i) P
      ⟨L₁.length + r, Nat.lt_succ_of_le (by simp [hr])⟩ =
    chainInput pts (fun i : Fin L₂.length => L₂.get i)
      (chainInput pts (fun i : Fin L₁.length => L₁.get i) P (Fin.last L₁.length))
      ⟨r, Nat.lt_succ_of_le hr⟩ := by
  induction r with
  | zero =>
      simp only [Nat.add_zero]
      exact chainInput_append_left pts L₁ L₂ P L₁.length le_rfl
  | succ r' ih =>
      have hr' : r' < L₂.length := Nat.lt_of_succ_le hr
      have hL : L₁.length + r' < (L₁ ++ L₂).length := by simp [hr']
      have hsucc₁ :
          (⟨L₁.length + (r' + 1), Nat.lt_succ_of_le (by simp [hr])⟩ :
            Fin ((L₁ ++ L₂).length + 1)) =
          (⟨L₁.length + r', hL⟩ : Fin (L₁ ++ L₂).length).succ := by
        ext; simp [Nat.add_assoc]
      have hsucc₂ :
          (⟨r' + 1, Nat.lt_succ_of_le hr⟩ : Fin (L₂.length + 1)) =
          (⟨r', hr'⟩ : Fin L₂.length).succ := rfl
      rw [hsucc₁, hsucc₂, chainInput_succ, chainInput_succ]
      have hget : (L₁ ++ L₂).get ⟨L₁.length + r', hL⟩ = L₂.get ⟨r', hr'⟩ := by
        simp [List.get_eq_getElem, List.getElem_append_right (Nat.le_add_right L₁.length r')]
      rw [hget]
      congr 1
      exact ih (Nat.le_of_lt hr')

/-! ### 2. Conditional suffix reconstruction (`runSyncSuffixFuel` and `runSyncSuffixBuild`) -/

inductive IsValidBuiltSuffixChain {d : ℕ} {NodeAux : Type}
    (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)) :
    Finset ℕ → List (SyncSuffixPrefixEntry d NodeAux) → Finset ℕ → Prop
  | nil (R : Finset ℕ) : IsValidBuiltSuffixChain ltCoords R [] R
  | cons (R : Finset ℕ) (e : SyncSuffixPrefixEntry d NodeAux)
      (rest : List (SyncSuffixPrefixEntry d NodeAux)) (term : Finset ℕ) :
      e.birthPool = R →
      IsValidBuiltSuffixChain ltCoords (e.built.node.residual ltCoords R) rest term →
      IsValidBuiltSuffixChain ltCoords R (e :: rest) term

lemma chainInput_cons {d : ℕ} {ι : Type*} {k : ℕ}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (head : ChainNode d) (tail : Fin k → ChainNode d) (P : Finset ι)
    (m : Fin (k + 1)) :
    chainInput pts (Fin.cons head tail) P m.succ =
      chainInput pts tail (head.residual pts P) m := by
  induction m using Fin.induction with
  | zero => rfl
  | succ j ih =>
      have h1 : (j.succ).succ = (j.succ).succ := rfl
      rw [chainInput_succ, chainInput_succ]
      have hcs : j.succ.castSucc = j.castSucc.succ := by ext; simp
      rw [hcs, ih]
      simp [Fin.cons_succ]

lemma builtSuffixChain_inputs {d : ℕ} {NodeAux : Type}
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {R : Finset ℕ} {entries : List (SyncSuffixPrefixEntry d NodeAux)} {term : Finset ℕ}
    (hchain : IsValidBuiltSuffixChain ltCoords R entries term) :
    let vec : Fin entries.length → ChainNode d := fun i => (entries.get i).built.node
    (∀ i : Fin entries.length,
      chainInput ltCoords vec R i.castSucc = (entries.get i).birthPool) ∧
    chainInput ltCoords vec R (Fin.last entries.length) = term := by
  induction hchain with
  | nil R =>
      refine ⟨fun i => Fin.elim0 i, rfl⟩
  | cons R e rest term he hrest ih =>
      rcases ih with ⟨ih_in, ih_term⟩
      let tailVec : Fin rest.length → ChainNode d := fun i => (rest.get i).built.node
      have hvec :
          ∀ j : Fin ((e :: rest).length + 1),
            chainInput ltCoords (fun i : Fin (e :: rest).length => ((e :: rest).get i).built.node) R j =
              chainInput ltCoords (Fin.cons e.built.node tailVec) R j := by
        intro j
        refine chainInput_congr (fun _ _ => rfl) (fun i => ?_) j
        refine Fin.cases ?_ ?_ i
        · rfl
        · intro r; rfl
      constructor
      · intro i
        refine Fin.cases ?_ ?_ i
        · simp [chainInput_zero, he]
        · intro j
          rw [hvec]
          have hcs : j.succ.castSucc = j.castSucc.succ := by ext; simp
          rw [hcs, chainInput_cons]
          exact ih_in j
      · rw [hvec]
        have hlast : Fin.last (e :: rest).length = (Fin.last rest.length).succ := by ext; simp
        rw [hlast, chainInput_cons]
        exact ih_term

lemma sync_node_step_contraction
    {d : ℕ} {c₁ C_nodes : ℝ}
    (h51 : ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2)))
    {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {α : ℝ} (hα_pos : 0 < α) (hα_le1 : α ≤ 1)
    {R : Finset ℕ} (hR1 : 1 ≤ R.card)
    {N : ChainNode d} {s : ℝ}
    (hV : N.V = liftVariance N.o s)
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun i : R => ltCoords i.1)) (liftedPoint N.o s)) :
    (N.residual ltCoords R ⊆ R) ∧
    ((N.residual ltCoords R).card < R.card) ∧
    (((N.residual ltCoords R).card : ℝ) ≤ (1 - c₁ * α) * (R.card : ℝ)) ∧
    (0 ≤ 1 - c₁ * α) := by
  classical
  have h1 := (h51 d ℕ ltCoords α hα_pos hα_le1).1 R R hR1 N.o s hcp 0
    (hasNodeAge_refl R) (by simp; positivity)
  rcases h1 with ⟨hcore, _, hchild⟩
  have hres_eq : N.residual ltCoords R = nodeResidual ltCoords N.o (liftVariance N.o s) R := by
    simp [ChainNode.residual, hV]
  have hsub : N.residual ltCoords R ⊆ R := nodeResidual_subset _ _ _ _
  have hR_pos : (0 : ℝ) < (R.card : ℝ) := by exact_mod_cast (Nat.lt_of_lt_of_le Nat.zero_lt_one hR1)
  have hcore_pos : (0 : ℝ) < ((R ∩ nodeCore ltCoords N.o (liftVariance N.o s) R).card : ℝ) := by
    have : 0 < 15 * α * (R.card : ℝ) / 16 := by positivity
    linarith
  have hcore_card_pos : 0 < (R ∩ nodeCore ltCoords N.o (liftVariance N.o s) R).card := by
    exact_mod_cast hcore_pos
  rcases Finset.card_pos.mp hcore_card_pos with ⟨x, hx⟩
  rcases Finset.mem_inter.mp hx with ⟨hxR, hxCore⟩
  have hx_not_res : x ∉ N.residual ltCoords R := by
    rw [hres_eq]
    simp [nodeResidual, hxCore]
  have hlt : (N.residual ltCoords R).card < R.card := by
    refine Finset.card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨hsub, ?_⟩)
    intro heq
    rw [heq] at hx_not_res
    exact hx_not_res hxR
  rw [← hres_eq] at hchild
  have hchild_nn : (0 : ℝ) ≤ ((N.residual ltCoords R).card : ℝ) := Nat.cast_nonneg _
  have h1mc_nn : 0 ≤ 1 - c₁ * α := by
    by_contra hneg
    push_neg at hneg
    have : (1 - c₁ * α) * (R.card : ℝ) < 0 := mul_neg_of_neg_of_pos hneg hR_pos
    linarith
  exact ⟨hsub, hlt, hchild, h1mc_nn⟩

/-- Master fuel-induction theorem for `runSyncSuffixFuel`. -/
theorem runSyncSuffixFuel_props
    {d : ℕ} {NodeAux : Type}
    {c₁ C_nodes : ℝ} (hc₁_pos : 0 < c₁)
    (h51 : ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2)))
    {n L_leaf : ℕ} {α A_n P_node : ℝ}
    (hα_pos : 0 < α) (hα_le1 : α ≤ 1)
    (hA_nn : 0 ≤ A_n) (hP_nn : 0 ≤ P_node)
    {admissiblePts : Set (EuclideanSpace ℝ (Fin d))}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    (hctor : IsValidSyncNodeConstructor n L_leaf α A_n P_node admissiblePts ctor)
    (hist : ExecutionHistory d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)) :
    ∀ (fuel : ℕ) (acc : List (SyncSuffixPrefixEntry d NodeAux)) (R : Finset ℕ) (accWork : ℕ),
      R.card ≤ fuel → R.card ≤ n → (∀ lt ∈ R, ltCoords lt ∈ admissiblePts) →
        IsPrefixFree (runSyncSuffixFuel ctor L_leaf hist ltCoords fuel acc R accWork) ∧
        haltProb (runSyncSuffixFuel ctor L_leaf hist ltCoords fuel acc R accWork) = 1 ∧
        (∀ bs sufOut,
          runSyncSuffixFuel ctor L_leaf hist ltCoords fuel acc R accWork bs = some sufOut →
            ∃ newEntries : List (SyncSuffixPrefixEntry d NodeAux),
              sufOut.entries = acc ++ newEntries ∧
              sufOut.terminalLeaf.card ≤ L_leaf ∧
              sufOut.terminalLeaf ⊆ R ∧
              IsValidBuiltSuffixChain ltCoords R newEntries sufOut.terminalLeaf ∧
              ((newEntries.map (fun e => (e.birthPool.card : ℝ))).sum) ≤
                (1 / c₁) * ((R.card : ℝ) / α) ∧
              (∀ e ∈ newEntries,
                e.birthPool ⊆ R ∧
                L_leaf < e.birthPool.card ∧
                e.built.node.V = liftVariance e.built.node.o e.built.s ∧
                IsCenterpoint α (paraboloidLiftSet (fun i : e.birthPool => ltCoords i.1))
                  (liftedPoint e.built.node.o e.built.s))) ∧
        expVal (runSyncSuffixFuel ctor L_leaf hist ltCoords fuel acc R accWork)
            (fun out => (out.totalWork : ENNReal)) ≤
          (accWork : ENNReal) + ENNReal.ofReal (((R.card : ℝ) / (c₁ * α)) * A_n * P_node)
  | 0, acc, R, accWork, hfuel, _, _ => by
      have hR0 : R.card = 0 := Nat.eq_zero_of_le_zero hfuel
      have hR_le : R.card ≤ L_leaf := by omega
      have hfn :
          runSyncSuffixFuel ctor L_leaf hist ltCoords 0 acc R accWork =
            haltAtEmpty { entries := acc, terminalLeaf := R, totalWork := accWork } := by
        ext bs
        simp [runSyncSuffixFuel, haltAtEmpty, hR_le]
      rw [hfn]
      refine ⟨isPrefixFree_haltAtEmpty _, haltProb_haltAtEmpty _, ?_, ?_⟩
      · intro bs sufOut hsuf
        unfold haltAtEmpty at hsuf
        split_ifs at hsuf with hbs
        injection hsuf with hEq
        subst hEq
        refine ⟨[], by simp, hR_le, Finset.Subset.refl R, IsValidBuiltSuffixChain.nil R, ?_, ?_⟩
        · simp
          positivity
        · intro e he; cases he
      · rw [expVal_haltAtEmpty]
        exact le_self_add
  | fuel + 1, acc, R, accWork, hfuel, hRn, hadm => by
      by_cases hR_le : R.card ≤ L_leaf
      · have hfn :
            runSyncSuffixFuel ctor L_leaf hist ltCoords (fuel + 1) acc R accWork =
              haltAtEmpty { entries := acc, terminalLeaf := R, totalWork := accWork } := by
          ext bs
          simp [runSyncSuffixFuel, haltAtEmpty, hR_le]
        rw [hfn]
        refine ⟨isPrefixFree_haltAtEmpty _, haltProb_haltAtEmpty _, ?_, ?_⟩
        · intro bs sufOut hsuf
          unfold haltAtEmpty at hsuf
          split_ifs at hsuf with hbs
          injection hsuf with hEq
          subst hEq
          refine ⟨[], by simp, hR_le, Finset.Subset.refl R, IsValidBuiltSuffixChain.nil R, ?_, ?_⟩
          · simp
            positivity
          · intro e he; cases he
        · rw [expVal_haltAtEmpty]
          exact le_self_add
      · have hR_gt : L_leaf < R.card := Nat.lt_of_not_ge hR_le
        have hR1 : 1 ≤ R.card := by omega
        rcases hctor hist acc ltCoords R hR_gt hRn hadm with
          ⟨hpf_ctor, hhalt_ctor, hvalid_ctor, hexp_ne_top, hexp_le⟩
        let f := ctor.buildWithBits hist acc ltCoords R
        have hhalt_f : haltProb f = 1 := hhalt_ctor
        let g : List Bool → SyncBuiltNode d NodeAux → List Bool → Option (SyncSuffixOutcome d NodeAux) :=
          fun bs₁ out =>
            runSyncSuffixFuel ctor L_leaf hist ltCoords fuel
              (acc ++ [{ birthPool := R, coins := bs₁, built := out }])
              (out.node.residual ltCoords R) (accWork + out.work)
        have hfn :
            runSyncSuffixFuel ctor L_leaf hist ltCoords (fuel + 1) acc R accWork =
              seqWithCoins f g := by
          ext bs
          simp [runSyncSuffixFuel, hR_le, seqWithCoins, f, g]
        rw [hfn]
        have hstep_ih :
            ∀ bs₁ out, f bs₁ = some out →
              let R' := out.node.residual ltCoords R
              (R' ⊆ R ∧ R'.card < R.card ∧
                (R'.card : ℝ) ≤ (1 - c₁ * α) * (R.card : ℝ) ∧ 0 ≤ 1 - c₁ * α) ∧
              IsPrefixFree (g bs₁ out) ∧
              haltProb (g bs₁ out) = 1 ∧
              (∀ bs₂ sufOut, g bs₁ out bs₂ = some sufOut →
                ∃ rest : List (SyncSuffixPrefixEntry d NodeAux),
                  sufOut.entries = (acc ++ [{ birthPool := R, coins := bs₁, built := out }]) ++ rest ∧
                  sufOut.terminalLeaf.card ≤ L_leaf ∧
                  sufOut.terminalLeaf ⊆ R' ∧
                  IsValidBuiltSuffixChain ltCoords R' rest sufOut.terminalLeaf ∧
                  ((rest.map (fun e => (e.birthPool.card : ℝ))).sum) ≤
                    (1 / c₁) * ((R'.card : ℝ) / α) ∧
                  (∀ e ∈ rest,
                    e.birthPool ⊆ R' ∧
                    L_leaf < e.birthPool.card ∧
                    e.built.node.V = liftVariance e.built.node.o e.built.s ∧
                    IsCenterpoint α (paraboloidLiftSet (fun i : e.birthPool => ltCoords i.1))
                      (liftedPoint e.built.node.o e.built.s))) ∧
              expVal (g bs₁ out) (fun o => (o.totalWork : ENNReal)) ≤
                ((accWork + out.work : ℕ) : ENNReal) +
                  ENNReal.ofReal (((R'.card : ℝ) / (c₁ * α)) * A_n * P_node) := by
          intro bs₁ out hout
          rcases hvalid_ctor bs₁ out hout with ⟨hV, hcp⟩
          have hcontr := sync_node_step_contraction h51 hα_pos hα_le1 hR1 hV hcp
          rcases hcontr with ⟨hsub', hlt', hcard', h1mc_nn⟩
          have hfuel' : (out.node.residual ltCoords R).card ≤ fuel := by omega
          have hRn' : (out.node.residual ltCoords R).card ≤ n := (Nat.le_of_lt hlt').trans hRn
          have hadm' : ∀ lt ∈ out.node.residual ltCoords R, ltCoords lt ∈ admissiblePts :=
            fun lt hlt_mem => hadm lt (hsub' hlt_mem)
          have ih := runSyncSuffixFuel_props hc₁_pos h51 hα_pos hα_le1 hA_nn hP_nn hctor
            hist ltCoords fuel (acc ++ [{ birthPool := R, coins := bs₁, built := out }])
            (out.node.residual ltCoords R) (accWork + out.work) hfuel' hRn' hadm'
          exact ⟨⟨hsub', hlt', hcard', h1mc_nn⟩, ih.1, ih.2.1, ih.2.2.1, ih.2.2.2⟩
        have hpf_seq : IsPrefixFree (seqWithCoins f g) :=
          isPrefixFree_seqWithCoins hpf_ctor (fun bs₁ out hout => (hstep_ih bs₁ out hout).2.1)
        have hhalt_seq : haltProb (seqWithCoins f g) = 1 :=
          haltProb_seqWithCoins hpf_ctor hhalt_f
            (fun bs₁ out hout => (hstep_ih bs₁ out hout).2.2.1)
        refine ⟨hpf_seq, hhalt_seq, ?_, ?_⟩
        · intro bs sufOut hsuf
          rcases (seqWithCoins_eq_some_iff hpf_ctor).mp hsuf with ⟨bs₁, bs₂, out, rfl, hout, hgout⟩
          rcases hvalid_ctor bs₁ out hout with ⟨hV, hcp⟩
          have hst := hstep_ih bs₁ out hout
          rcases hst.1 with ⟨hsub', _, hcard', _⟩
          rcases hst.2.2.2.1 bs₂ sufOut hgout with
            ⟨rest, hent, hterm_card, hterm_sub, hchain_rest, hsum_rest, hrest_props⟩
          let e₀ : SyncSuffixPrefixEntry d NodeAux :=
            { birthPool := R, coins := bs₁, built := out }
          refine ⟨e₀ :: rest, ?_, hterm_card, hterm_sub.trans hsub', ?_, ?_, ?_⟩
          · simpa [List.append_assoc, e₀] using hent
          · exact IsValidBuiltSuffixChain.cons R e₀ rest sufOut.terminalLeaf rfl hchain_rest
          · simp only [List.map_cons, List.sum_cons, e₀]
            have hc₁α_pos : 0 < c₁ * α := mul_pos hc₁_pos hα_pos
            have hstep_sum :
                (1 / c₁) * (((out.node.residual ltCoords R).card : ℝ) / α) ≤
                  (1 / c₁) * (((1 - c₁ * α) * (R.card : ℝ)) / α) := by
              have hdiv : ((out.node.residual ltCoords R).card : ℝ) / α ≤
                  ((1 - c₁ * α) * (R.card : ℝ)) / α :=
                div_le_div_of_nonneg_right hcard' hα_pos.le
              exact mul_le_mul_of_nonneg_left hdiv (by positivity)
            have htel :
                (R.card : ℝ) + (1 / c₁) * (((1 - c₁ * α) * (R.card : ℝ)) / α) =
                  (1 / c₁) * ((R.card : ℝ) / α) := by
              have hc₁_ne : c₁ ≠ 0 := ne_of_gt hc₁_pos
              have hα_ne : α ≠ 0 := ne_of_gt hα_pos
              field_simp
              ring
            linarith
          · intro e he
            rcases List.mem_cons.mp he with rfl | he_rest
            · exact ⟨Finset.Subset.refl R, hR_gt, hV, hcp⟩
            · rcases hrest_props e he_rest with ⟨h1, h2, h3, h4⟩
              exact ⟨h1.trans hsub', h2, h3, h4⟩
        · rw [expVal_seqWithCoins hpf_ctor]
          -- Obtain `0 ≤ 1 - c₁ * α` from any halting coin string of `f` (since `haltProb f = 1`)
          have hex_out : ∃ bs₀ out₀, f bs₀ = some out₀ := by
            by_contra hnone
            push_neg at hnone
            have hz : haltProb f = 0 := by
              unfold haltProb
              have : (fun bs => if (f bs).isSome then bitListProb bs else (0 : ENNReal)) =
                  fun _ => 0 := by
                ext bs
                cases hfb : f bs with
                | none => simp
                | some o => exact (hnone bs o hfb).elim
              rw [this, tsum_zero]
            rw [hhalt_f] at hz
            exact one_ne_zero hz
          rcases hex_out with ⟨bs₀, out₀, hout₀⟩
          have h1mc_nn : 0 ≤ 1 - c₁ * α := (hstep_ih bs₀ out₀ hout₀).1.2.2.2
          let tailReal : ℝ := (((1 - c₁ * α) * (R.card : ℝ)) / (c₁ * α)) * A_n * P_node
          have htail_nn : 0 ≤ tailReal := by
            dsimp only [tailReal]
            positivity
          have hpoint :
              ∀ bs₁ out, f bs₁ = some out →
                expVal (g bs₁ out) (fun o => (o.totalWork : ENNReal)) ≤
                  ((accWork : ENNReal) + ENNReal.ofReal tailReal) + (out.work : ENNReal) := by
            intro bs₁ out hout
            have hst := hstep_ih bs₁ out hout
            have hcard' := hst.1.2.2.1
            have hexp' := hst.2.2.2.2
            have hmono_tail :
                (((out.node.residual ltCoords R).card : ℝ) / (c₁ * α)) * A_n * P_node ≤ tailReal := by
              dsimp only [tailReal]
              have hdiv : ((out.node.residual ltCoords R).card : ℝ) / (c₁ * α) ≤
                  ((1 - c₁ * α) * (R.card : ℝ)) / (c₁ * α) :=
                div_le_div_of_nonneg_right hcard' (mul_pos hc₁_pos hα_pos).le
              exact mul_le_mul_of_nonneg_right
                (mul_le_mul_of_nonneg_right hdiv hA_nn) hP_nn
            calc expVal (g bs₁ out) (fun o => (o.totalWork : ENNReal))
                ≤ ((accWork + out.work : ℕ) : ENNReal) +
                    ENNReal.ofReal ((((out.node.residual ltCoords R).card : ℝ) / (c₁ * α)) * A_n * P_node) := hexp'
              _ ≤ ((accWork : ENNReal) + (out.work : ENNReal)) + ENNReal.ofReal tailReal := by
                  rw [Nat.cast_add]
                  exact add_le_add le_rfl (ENNReal.ofReal_le_ofReal hmono_tail)
              _ = ((accWork : ENNReal) + ENNReal.ofReal tailReal) + (out.work : ENNReal) := by
                  ring
          have hexp_f_le :
              expVal f (fun out => (out.work : ENNReal)) ≤
                ENNReal.ofReal ((R.card : ℝ) * A_n * P_node) := by
            have hE : _ ≤ ENNReal.ofReal ((R.card : ℝ) * A_n * P_node) :=
              (ENNReal.ofReal_toReal hexp_ne_top) ▸ ENNReal.ofReal_le_ofReal hexp_le
            refine le_trans (le_of_eq ?_) hE
            unfold expVal
            congr 1
            ext bs
            dsimp only [f]
            cases ctor.buildWithBits hist acc ltCoords R bs <;> rfl
          have hhead_nn : 0 ≤ (R.card : ℝ) * A_n * P_node := by positivity
          have htel_real :
              tailReal + (R.card : ℝ) * A_n * P_node =
                ((R.card : ℝ) / (c₁ * α)) * A_n * P_node := by
            dsimp only [tailReal]
            have hc₁_ne : c₁ ≠ 0 := ne_of_gt hc₁_pos
            have hα_ne : α ≠ 0 := ne_of_gt hα_pos
            field_simp
            ring
          refine le_trans
            (b := expVal f (fun out =>
              ((accWork : ENNReal) + ENNReal.ofReal tailReal) + (out.work : ENNReal))) ?_ ?_
          · conv_rhs => unfold expVal
            dsimp only [f] at hpoint ⊢
            refine ENNReal.tsum_le_tsum fun bs₁ => ?_
            cases hfb : ctor.buildWithBits hist acc ltCoords R bs₁ with
            | none => simp
            | some out =>
                dsimp only
                exact mul_le_mul_of_nonneg_left (hpoint bs₁ out hfb) (zero_le _)
          · rw [expVal_add, expVal_const, hhalt_f, one_mul]
            calc ((accWork : ENNReal) + ENNReal.ofReal tailReal) +
                  expVal f (fun out => (out.work : ENNReal))
                ≤ ((accWork : ENNReal) + ENNReal.ofReal tailReal) +
                    ENNReal.ofReal ((R.card : ℝ) * A_n * P_node) :=
                  add_le_add le_rfl hexp_f_le
              _ = (accWork : ENNReal) +
                    (ENNReal.ofReal tailReal + ENNReal.ofReal ((R.card : ℝ) * A_n * P_node)) := by
                  ring
              _ = (accWork : ENNReal) +
                    ENNReal.ofReal (((R.card : ℝ) / (c₁ * α)) * A_n * P_node) := by
                  rw [← ENNReal.ofReal_add htail_nn hhead_nn, htel_real]

end UL.Proof_claim_C_3_sync_suffix_v31
