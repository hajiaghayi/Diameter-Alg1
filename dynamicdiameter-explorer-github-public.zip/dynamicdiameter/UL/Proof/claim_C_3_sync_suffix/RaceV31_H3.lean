import Mathlib
import UL.Stmt.claim_C_3_sync_suffix
import UL.Stmt.clm_5_1_chain_contraction
import UL.Proof.claim_C_3_sync_suffix.RaceV31_H1
import UL.Proof.claim_C_3_sync_suffix.RaceV31_H2
set_option autoImplicit false

namespace UL.Proof_claim_C_3_sync_suffix_v31

open scoped ENNReal

/-! ### 1. List filtering and `getD` helpers -/

lemma filter_length_eq_filter_map {γ : Type*} (xs : List γ) (f : γ → Bool) :
    (xs.filter f).length = ((xs.map f).filter id).length := by
  induction xs with
  | nil => rfl
  | cons x xs ih => cases fx : f x <;> simp [fx, ih]

lemma filter_length_eq_of_map_eq {α β : Type*} {L₁ : List α} {L₂ : List β}
    {p : α → Bool} {q : β → Bool} (hmap : L₁.map p = L₂.map q) :
    (L₁.filter p).length = (L₂.filter q).length := by
  rw [filter_length_eq_filter_map L₁ p, filter_length_eq_filter_map L₂ q, hmap]

lemma map_ofFn_eq_map {α β γ : Type*} :
    ∀ (L : List α) (g : Fin L.length → β) (p : α → γ) (q : β → γ),
      (∀ i : Fin L.length, q (g i) = p (L.get i)) →
      (List.ofFn g).map q = L.map p
  | [], _, _, _, _ => rfl
  | x :: xs, g, p, q, h => by
      dsimp only [List.length_cons] at g h
      rw [List.ofFn_succ, List.map_cons, List.map_cons]
      have h0 : q (g 0) = p x := h 0
      rw [h0]
      congr 1
      exact map_ofFn_eq_map xs (fun i => g i.succ) p q (fun i => h i.succ)

lemma filter_take_length_add_get {α : Type*} (p : α → Bool) :
    ∀ (L : List α) (j : ℕ) (hj : j < L.length),
      ((L.take j).filter p).length + (if p (L.get ⟨j, hj⟩) = true then 1 else 0) ≤
        (L.filter p).length
  | [], _, hj => absurd hj (Nat.not_lt_zero _)
  | x :: xs, 0, _ => by
      cases hpx : p x <;> simp [hpx]
  | x :: xs, j + 1, hj => by
      have hj' : j < xs.length := Nat.lt_of_succ_lt_succ hj
      have ih := filter_take_length_add_get p xs j hj'
      have htake : (x :: xs).take (j + 1) = x :: xs.take j := rfl
      have hget : (x :: xs).get ⟨j + 1, hj⟩ = xs.get ⟨j, hj'⟩ := rfl
      rw [htake, hget]
      cases hpx : p x <;> cases hpj : p (xs.get ⟨j, hj'⟩) <;>
        simp only [List.filter_cons, hpx, hpj, Bool.false_eq_true, ↓reduceIte, List.length_cons] at ih ⊢ <;>
        omega

lemma getD_append_singleton_lt (xs : List ℕ) (a i : ℕ) (hi : i < xs.length) :
    (xs ++ [a]).getD i 0 = xs.getD i 0 := by
  simp [List.getD, List.getElem?_append_left hi]

lemma getD_append_singleton_eq (xs : List ℕ) (a : ℕ) :
    (xs ++ [a]).getD xs.length 0 = a := by
  simp [List.getD]

lemma list_sum_le_of_forall_le {α : Type*} (L : List α) (f g : α → ℝ)
    (h : ∀ x ∈ L, f x ≤ g x) :
    (L.map f).sum ≤ (L.map g).sum := by
  induction L with
  | nil => simp
  | cons x xs ih =>
      simp only [List.map_cons, List.sum_cons]
      exact add_le_add (h x List.mem_cons_self)
        (ih fun y hy => h y (List.mem_cons_of_mem x hy))

lemma coe_list_map_id_eq {α : Type*} (L : List α) (f : α → ℕ) :
    ((L.map f).map (fun m => (m : ℝ))) = L.map (fun e => (f e : ℝ)) := by
  induction L with
  | nil => rfl
  | cons x xs ih => exact congrArg ((f x : ℝ) :: ·) ih

lemma list_sum_mul_const {α : Type*} (L : List α) (c : ℝ) (f : α → ℝ) :
    (L.map (fun x => c * f x)).sum = c * (L.map f).sum := by
  induction L with
  | nil => simp
  | cons x xs ih =>
      simp only [List.map_cons, List.sum_cons, ih]
      ring

/-! ### 2. `applyDynamicUpdate` legality and active-lifetime transition -/

def stepRetHandle {d : ℕ} (alloc : Finset ℕ → ℕ) (activeHandles : Finset ℕ) :
    DynamicUpdate d → Option ℕ
  | .insert _ _ _ => some (alloc activeHandles)
  | .delete _ => none

noncomputable def stepLtCoords {d : ℕ} (ltCoords : ℕ → EuclideanSpace ℝ (Fin d))
    (nextLt : ℕ) : DynamicUpdate d → ℕ → EuclideanSpace ℝ (Fin d)
  | .insert _ _ pt => Function.update ltCoords nextLt pt
  | .delete _ => ltCoords

lemma applyDynamicUpdate_legal {d n : ℕ}
    {admissiblePts : Set (EuclideanSpace ℝ (Fin d))}
    {curP : DynamicPointSet d} {ltCoords : ℕ → EuclideanSpace ℝ (Fin d)}
    {alloc : Finset ℕ → ℕ} {op : DynamicUpdate d}
    (hwf : curP.WellFormed n)
    (hleg : IsLegalUpdate n admissiblePts curP op)
    (halloc : ∀ activeH : Finset ℕ, alloc activeH ∉ activeH)
    (hact : ∀ lt ∈ curP.activeIds.image curP.lifetimeOfId,
      lt < curP.nextLifetime ∧ ltCoords lt ∈ admissiblePts) :
    ∃ P' : DynamicPointSet d,
      applyDynamicUpdate curP op (stepRetHandle alloc curP.activeHandles op) = some P' ∧
      P'.WellFormed n ∧
      curP.nextLifetime ≤ P'.nextLifetime ∧
      (∀ lt < curP.nextLifetime,
        stepLtCoords ltCoords curP.nextLifetime op lt = ltCoords lt) ∧
      (∀ lt ∈ P'.activeIds.image P'.lifetimeOfId,
        lt < P'.nextLifetime ∧
        stepLtCoords ltCoords curP.nextLifetime op lt ∈ admissiblePts) ∧
      IsInputChange
        (curP.activeIds.image curP.lifetimeOfId)
        (P'.activeIds.image P'.lifetimeOfId) := by
  rcases hwf with ⟨hcard_le, hid_to_h, hh_to_id, hlt_lt, hlt_inj⟩
  cases op with
  | insert pid extName pt =>
      rcases hleg with ⟨hid_not, hcard_ins, hpt_adm⟩
      let h := alloc curP.activeHandles
      have hh_not : h ∉ curP.activeHandles := halloc curP.activeHandles
      let P' : DynamicPointSet d :=
        { activeIds := insert pid curP.activeIds
          coords := Function.update curP.coords pid pt
          activeHandles := insert h curP.activeHandles
          handleOfId := Function.update curP.handleOfId pid h
          idOfHandle := Function.update curP.idOfHandle h pid
          nextLifetime := curP.nextLifetime + 1
          lifetimeOfId := Function.update curP.lifetimeOfId pid curP.nextLifetime }
      refine ⟨P', ?_, ?_, Nat.le_succ _, ?_, ?_, ?_⟩
      · simp [stepRetHandle, applyDynamicUpdate, hid_not, hh_not, P', h]
      · refine ⟨?_, ?_, ?_, ?_, ?_⟩
        · rw [Finset.card_insert_of_notMem hid_not]
          exact hcard_ins
        · intro x hx
          rcases Finset.mem_insert.mp hx with hx_eq | hx_old
          · rw [hx_eq]
            dsimp only [P']
            rw [Function.update_self, Function.update_self]
            exact ⟨Finset.mem_insert_self h curP.activeHandles, rfl⟩
          · have hx_ne : x ≠ pid := fun heq => hid_not (heq ▸ hx_old)
            rcases hid_to_h x hx_old with ⟨hhx, hinvx⟩
            have hhx_ne : curP.handleOfId x ≠ h := fun heq => hh_not (heq ▸ hhx)
            dsimp only [P']
            rw [Function.update_of_ne hx_ne, Function.update_of_ne hhx_ne]
            exact ⟨Finset.mem_insert_of_mem hhx, hinvx⟩
        · intro y hy
          rcases Finset.mem_insert.mp hy with hy_eq | hy_old
          · rw [hy_eq]
            dsimp only [P']
            rw [Function.update_self, Function.update_self]
            exact ⟨Finset.mem_insert_self pid curP.activeIds, rfl⟩
          · have hy_ne : y ≠ h := fun heq => hh_not (heq ▸ hy_old)
            rcases hh_to_id y hy_old with ⟨hidy, hinvy⟩
            have hidy_ne : curP.idOfHandle y ≠ pid := fun heq => hid_not (heq ▸ hidy)
            dsimp only [P']
            rw [Function.update_of_ne hy_ne, Function.update_of_ne hidy_ne]
            exact ⟨Finset.mem_insert_of_mem hidy, hinvy⟩
        · intro x hx
          rcases Finset.mem_insert.mp hx with hx_eq | hx_old
          · rw [hx_eq]
            dsimp only [P']
            simp
          · have hx_ne : x ≠ pid := fun heq => hid_not (heq ▸ hx_old)
            have := hlt_lt x hx_old
            dsimp only [P']
            simp [hx_ne]
            omega
        · intro x₁ hx₁ x₂ hx₂ heq
          rcases Finset.mem_insert.mp hx₁ with hx₁_eq | hx₁_old
          · rcases Finset.mem_insert.mp hx₂ with hx₂_eq | hx₂_old
            · exact hx₁_eq.trans hx₂_eq.symm
            · have hx₂_ne : x₂ ≠ pid := fun h0 => hid_not (h0 ▸ hx₂_old)
              dsimp only [P'] at heq
              rw [hx₁_eq, Function.update_self, Function.update_of_ne hx₂_ne] at heq
              have hlt2 := hlt_lt x₂ hx₂_old
              rw [← heq] at hlt2
              exact absurd hlt2 (lt_irrefl _)
          · have hx₁_ne : x₁ ≠ pid := fun h0 => hid_not (h0 ▸ hx₁_old)
            rcases Finset.mem_insert.mp hx₂ with hx₂_eq | hx₂_old
            · dsimp only [P'] at heq
              rw [hx₂_eq, Function.update_self, Function.update_of_ne hx₁_ne] at heq
              have hlt1 := hlt_lt x₁ hx₁_old
              rw [heq] at hlt1
              exact absurd hlt1 (lt_irrefl _)
            · have hx₂_ne : x₂ ≠ pid := fun h0 => hid_not (h0 ▸ hx₂_old)
              dsimp only [P'] at heq
              rw [Function.update_of_ne hx₁_ne, Function.update_of_ne hx₂_ne] at heq
              exact hlt_inj x₁ hx₁_old x₂ hx₂_old heq
      · intro lt hlt
        dsimp only [stepLtCoords]
        exact Function.update_of_ne (ne_of_lt hlt) pt ltCoords
      · intro lt hlt_mem
        dsimp only [stepLtCoords]
        rcases Finset.mem_image.mp hlt_mem with ⟨x, hx, rfl⟩
        rcases Finset.mem_insert.mp hx with hx_eq | hx_old
        · rw [hx_eq]
          dsimp only [P']
          rw [Function.update_self, Function.update_self]
          exact ⟨Nat.lt_succ_self _, hpt_adm⟩
        · have hx_ne : x ≠ pid := fun h0 => hid_not (h0 ▸ hx_old)
          have hmem_old : curP.lifetimeOfId x ∈ curP.activeIds.image curP.lifetimeOfId :=
            Finset.mem_image_of_mem _ hx_old
          rcases hact _ hmem_old with ⟨hlt_bound, hadm_old⟩
          have hne_lt : curP.lifetimeOfId x ≠ curP.nextLifetime := ne_of_lt hlt_bound
          simp [P', hx_ne, hne_lt, hadm_old]
          omega
      · left
        refine ⟨curP.nextLifetime, ?_, ?_⟩
        · intro hmem
          rcases hact _ hmem with ⟨hlt_bound, _⟩
          exact lt_irrefl _ hlt_bound
        · ext lt
          simp only [P', Finset.mem_image, Finset.mem_insert]
          constructor
          · rintro ⟨x, hx_eq | hx_old, rfl⟩
            · rw [hx_eq, Function.update_self]
              exact Or.inl rfl
            · have hx_ne : x ≠ pid := fun h0 => hid_not (h0 ▸ hx_old)
              simp only [Function.update_of_ne hx_ne]
              exact Or.inr ⟨x, hx_old, rfl⟩
          · rintro (rfl | ⟨x, hx_old, rfl⟩)
            · exact ⟨pid, Or.inl rfl, by simp⟩
            · have hx_ne : x ≠ pid := fun h0 => hid_not (h0 ▸ hx_old)
              exact ⟨x, Or.inr hx_old, by simp [hx_ne]⟩
  | delete pid =>
      have hid_mem : pid ∈ curP.activeIds := hleg
      let h := curP.handleOfId pid
      let P' : DynamicPointSet d :=
        { activeIds := curP.activeIds.erase pid
          coords := Function.update curP.coords pid 0
          activeHandles := curP.activeHandles.erase h
          handleOfId := Function.update curP.handleOfId pid 0
          idOfHandle := Function.update curP.idOfHandle h 0
          nextLifetime := curP.nextLifetime
          lifetimeOfId := Function.update curP.lifetimeOfId pid 0 }
      have himg :
          P'.activeIds.image P'.lifetimeOfId =
            (curP.activeIds.image curP.lifetimeOfId).erase (curP.lifetimeOfId pid) := by
        ext lt
        simp only [P', Finset.mem_image, Finset.mem_erase]
        constructor
        · rintro ⟨x, ⟨hx_ne, hx_mem⟩, rfl⟩
          simp only [Function.update_of_ne hx_ne]
          refine ⟨?_, x, hx_mem, rfl⟩
          intro heq
          exact hx_ne (hlt_inj x hx_mem pid hid_mem heq)
        · rintro ⟨hlt_ne, x, hx_mem, rfl⟩
          have hx_ne : x ≠ pid := fun h0 => hlt_ne (by rw [h0])
          exact ⟨x, ⟨hx_ne, hx_mem⟩, by simp [hx_ne]⟩
      refine ⟨P', ?_, ?_, le_rfl, fun _ _ => rfl, ?_, ?_⟩
      · simp [stepRetHandle, applyDynamicUpdate, hid_mem, P', h]
      · refine ⟨Finset.card_erase_le.trans hcard_le, ?_, ?_, ?_, ?_⟩
        · intro x hx
          rcases Finset.mem_erase.mp hx with ⟨hx_ne, hx_mem⟩
          rcases hid_to_h x hx_mem with ⟨hhx, hinvx⟩
          have hhx_ne : curP.handleOfId x ≠ h := by
            intro heq
            have := congrArg curP.idOfHandle heq
            rw [hinvx, (hid_to_h pid hid_mem).2] at this
            exact hx_ne this
          simp [P', hx_ne, hhx_ne, hhx, hinvx]
        · intro y hy
          rcases Finset.mem_erase.mp hy with ⟨hy_ne, hy_mem⟩
          rcases hh_to_id y hy_mem with ⟨hidy, hinvy⟩
          have hidy_ne : curP.idOfHandle y ≠ pid := by
            intro heq
            have := congrArg curP.handleOfId heq
            rw [hinvy] at this
            exact hy_ne this
          simp [P', hy_ne, hidy_ne, hidy, hinvy]
        · intro x hx
          rcases Finset.mem_erase.mp hx with ⟨hx_ne, hx_mem⟩
          simpa [P', hx_ne] using hlt_lt x hx_mem
        · intro x₁ hx₁ x₂ hx₂ heq
          rcases Finset.mem_erase.mp hx₁ with ⟨hx₁_ne, hx₁_mem⟩
          rcases Finset.mem_erase.mp hx₂ with ⟨hx₂_ne, hx₂_mem⟩
          simp [P', hx₁_ne, hx₂_ne] at heq
          exact hlt_inj x₁ hx₁_mem x₂ hx₂_mem heq
      · intro lt hlt_mem
        dsimp only [stepLtCoords]
        rw [himg] at hlt_mem
        exact hact lt (Finset.mem_of_mem_erase hlt_mem)
      · right
        refine ⟨curP.lifetimeOfId pid, Finset.mem_image_of_mem _ hid_mem, ?_⟩
        ext lt
        rw [himg]
        simp

/-! ### 3. Part (1) wrapper (`runSyncSuffixBuild_all`) -/

theorem runSyncSuffixBuild_all
    {d : ℕ} {NodeAux : Type}
    {c₁ C_nodes : ℝ} (hc₁_pos : 0 < c₁)
    (h51 : ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2)))
    {n L_leaf : ℕ} {α A_n P_α_d P_node_val : ℝ}
    (hα_pos : 0 < α) (hα_le1 : α ≤ 1)
    (hPα_ge1 : 1 ≤ P_α_d) (hbound_α : 1 / P_α_d ≤ α)
    (hA_nn : 0 ≤ A_n) (hPn_nn : 0 ≤ P_node_val)
    {admissiblePts : Set (EuclideanSpace ℝ (Fin d))}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    (hctor : IsValidSyncNodeConstructor n L_leaf α A_n P_node_val admissiblePts ctor)
    (hist : ExecutionHistory d) (ltCoords : ℕ → EuclideanSpace ℝ (Fin d)) (S : Finset ℕ)
    (hSn : S.card ≤ n) (hadm : ∀ lt ∈ S, ltCoords lt ∈ admissiblePts) :
    let C_sum : ℝ := max 1 (1 / c₁)
    let P_suf_val : ℝ := (1 / c₁) * P_α_d * P_node_val
    IsPrefixFree (runSyncSuffixBuild ctor L_leaf hist ltCoords S) ∧
    syncSuffixHaltProb ctor L_leaf hist ltCoords S = 1 ∧
    (∀ bs sufOut,
      runSyncSuffixBuild ctor L_leaf hist ltCoords S bs = some sufOut →
        sufOut.terminalLeaf.card ≤ L_leaf ∧
        sufOut.terminalLeaf ⊆ S ∧
        IsValidBuiltSuffixChain ltCoords S sufOut.entries sufOut.terminalLeaf ∧
        ((sufOut.entries.map (fun e => (e.birthPool.card : ℝ))).sum) ≤
          C_sum * ((S.card : ℝ) / α) ∧
        (∀ e ∈ sufOut.entries,
          e.birthPool ⊆ S ∧
          L_leaf < e.birthPool.card ∧
          e.built.node.V = liftVariance e.built.node.o e.built.s ∧
          IsCenterpoint α (paraboloidLiftSet (fun i : e.birthPool => ltCoords i.1))
            (liftedPoint e.built.node.o e.built.s))) ∧
    syncSuffixExpectedWork ctor L_leaf hist ltCoords S ≤
      ENNReal.ofReal ((S.card : ℝ) * A_n * P_suf_val) ∧
    syncSuffixExpectedWork ctor L_leaf hist ltCoords S ≠ ⊤ ∧
    (syncSuffixExpectedWork ctor L_leaf hist ltCoords S).toReal ≤
      (S.card : ℝ) * A_n * P_suf_val := by
  dsimp only
  have hmain := runSyncSuffixFuel_props hc₁_pos h51 hα_pos hα_le1 hA_nn hPn_nn hctor
    hist ltCoords S.card [] S 0 le_rfl hSn hadm
  rcases hmain with ⟨hpf, hhalt, hout, hexp⟩
  have hinv : α⁻¹ ≤ P_α_d := @inv_alpha_le_P_alpha (fun _ => P_α_d) 0 α hα_pos hbound_α hPα_ge1
  have hexp_eq :
      syncSuffixExpectedWork ctor L_leaf hist ltCoords S =
        expVal (runSyncSuffixFuel ctor L_leaf hist ltCoords S.card [] S 0)
          (fun out => (out.totalWork : ENNReal)) := by
    unfold syncSuffixExpectedWork expVal runSyncSuffixBuild
    congr 1
    ext bs
    cases runSyncSuffixFuel ctor L_leaf hist ltCoords S.card [] S 0 bs <;> rfl
  have hexp_bound :
      syncSuffixExpectedWork ctor L_leaf hist ltCoords S ≤
        ENNReal.ofReal ((S.card : ℝ) * A_n * ((1 / c₁) * P_α_d * P_node_val)) := by
    rw [hexp_eq]
    rw [Nat.cast_zero, zero_add] at hexp
    refine hexp.trans (ENNReal.ofReal_le_ofReal ?_)
    have h1 : (S.card : ℝ) / (c₁ * α) = (S.card : ℝ) * (1 / c₁) * α⁻¹ := by ring
    rw [h1]
    have h2 : (S.card : ℝ) * (1 / c₁) * α⁻¹ ≤ (S.card : ℝ) * (1 / c₁) * P_α_d :=
      mul_le_mul_of_nonneg_left hinv (by positivity)
    have h3 :
        (S.card : ℝ) * (1 / c₁) * α⁻¹ * A_n * P_node_val ≤
          (S.card : ℝ) * (1 / c₁) * P_α_d * A_n * P_node_val :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right h2 hA_nn) hPn_nn
    linarith
  have hB_nn : 0 ≤ (S.card : ℝ) * A_n * ((1 / c₁) * P_α_d * P_node_val) := by
    have : 0 ≤ P_α_d := by linarith
    positivity
  refine ⟨hpf, hhalt, ?_, hexp_bound,
    ne_top_of_le_ne_top ENNReal.ofReal_ne_top hexp_bound,
    ENNReal.toReal_le_of_le_ofReal hB_nn hexp_bound⟩
  intro bs sufOut hsuf
  rcases hout bs sufOut hsuf with ⟨newEnts, hent, hterm_le, hterm_sub, hchain, hsum, hprops⟩
  simp only [List.nil_append] at hent
  subst hent
  refine ⟨hterm_le, hterm_sub, hchain, ?_, hprops⟩
  refine hsum.trans ?_
  exact mul_le_mul_of_nonneg_right (le_max_right 1 (1 / c₁)) (by positivity)

/-! ### 4. Reachable schedule state invariant, charging potential, and step transition -/

def pastChargedCount {d : ℕ} {NodeAux : Type}
    (cur : SyncSchedulePrefixState d NodeAux) (u₀ : ℕ) : ℕ :=
  (cur.triggeredSuffixes.filter (fun rec => u₀ ∈ rec.chargedUpdateSteps)).length

def liveCount {d : ℕ} {NodeAux : Type} (cur : SyncSchedulePrefixState d NodeAux) (u₀ : ℕ) : ℕ :=
  (cur.nodes.filter (fun v => u₀ ∈ v.ageUpdateSteps)).length +
    if u₀ ∈ cur.leafAgeUpdateSteps then 1 else 0

def rootBirthSum {d : ℕ} {NodeAux : Type} (cur : SyncSchedulePrefixState d NodeAux) : ℝ :=
  (cur.triggeredSuffixes.map (fun rec => (rec.rootBirthCard : ℝ))).sum

lemma rootBirthSum_nonneg {d : ℕ} {NodeAux : Type} (cur : SyncSchedulePrefixState d NodeAux) :
    0 ≤ rootBirthSum cur := by
  unfold rootBirthSum
  induction cur.triggeredSuffixes with
  | nil => simp
  | cons r rs ih =>
      simp only [List.map_cons, List.sum_cons]
      have : (0 : ℝ) ≤ (r.rootBirthCard : ℝ) := Nat.cast_nonneg _
      linarith

def SyncStateInv {d : ℕ} {NodeAux : Type}
    (n L_leaf : ℕ) (c_chg C_sum C_charge α c : ℝ)
    (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
    (cur : SyncSchedulePrefixState d NodeAux) : Prop :=
  let u : ℕ := cur.history.length
  let k : ℕ := cur.nodes.length
  let vecNodes : Fin k → ChainNode d := fun i => (cur.nodes.get i).built.node
  let act : Finset ℕ := cur.pointSet.activeIds.image cur.pointSet.lifetimeOfId
  cur.pointSet.WellFormed n ∧
  (∀ lt ∈ act, lt < cur.pointSet.nextLifetime ∧ cur.ltCoords lt ∈ admissiblePts) ∧
  (∀ i : Fin k,
    let v := cur.nodes.get i
    (∀ lt ∈ v.birthPool, lt < cur.pointSet.nextLifetime ∧ cur.ltCoords lt ∈ admissiblePts) ∧
    1 ≤ v.birthPool.card ∧
    v.built.node.V = liftVariance v.built.node.o v.built.s ∧
    IsCenterpoint α (paraboloidLiftSet (fun j : v.birthPool => cur.ltCoords j.1))
      (liftedPoint v.built.node.o v.built.s) ∧
    HasNodeAge v.birthPool (chainInput cur.ltCoords vecNodes act i.castSucc)
      v.ageUpdateSteps.card ∧
    (v.ageUpdateSteps.card : ℝ) ≤ α * (v.birthPool.card : ℝ) / 16 ∧
    (∀ x ∈ v.ageUpdateSteps, x < u)) ∧
  cur.leafBirthPool.card ≤ L_leaf ∧
  HasNodeAge cur.leafBirthPool (chainInput cur.ltCoords vecNodes act (Fin.last k))
    cur.leafAgeUpdateSteps.card ∧
  (∀ x ∈ cur.leafAgeUpdateSteps, x < u) ∧
  (∀ snap ∈ cur.snapshots, IsValidFactorCAnswer c snap.1 snap.2) ∧
  (∀ rec ∈ cur.triggeredSuffixes,
    c_chg * α * (rec.rootBirthCard : ℝ) ≤ (rec.chargedUpdateSteps.card : ℝ) ∧
    (rec.chainBirthCards.map (fun m => (m : ℝ))).sum ≤
      C_sum * ((rec.rootBirthCard : ℝ) / α) ∧
    rec.triggerStep < u ∧
    ∀ u₀ ∈ rec.chargedUpdateSteps, u₀ ≤ rec.triggerStep) ∧
  cur.chainSlotCounts.length = u ∧
  (∀ u₀ < u,
    (cur.chainSlotCounts.getD u₀ 0 : ℝ) ≤ C_charge * α⁻¹ * Real.log (2 * (n : ℝ))) ∧
  (∀ u₀ : ℕ,
    pastChargedCount cur u₀ + liveCount cur u₀ ≤
      if u₀ < u then cur.chainSlotCounts.getD u₀ 0 else 0)

lemma syncStateInv_init {d n L_leaf : ℕ} {NodeAux : Type}
    {c_chg C_sum C_charge α c : ℝ}
    {admissiblePts : Set (EuclideanSpace ℝ (Fin d))} :
    SyncStateInv n L_leaf c_chg C_sum C_charge α c admissiblePts
      (initSyncSchedulePrefixState d NodeAux) := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, rfl, ?_, ?_⟩
  · simp [initSyncSchedulePrefixState, DynamicPointSet.WellFormed, DynamicPointSet.empty]
  · simp [initSyncSchedulePrefixState, DynamicPointSet.empty]
  · intro i; exact Fin.elim0 i
  · simp [initSyncSchedulePrefixState]
  · simpa [initSyncSchedulePrefixState, DynamicPointSet.empty] using hasNodeAge_refl (∅ : Finset ℕ)
  · simp [initSyncSchedulePrefixState]
  · simp [initSyncSchedulePrefixState]
  · simp [initSyncSchedulePrefixState]
  · intro u₀ hu₀; simp [initSyncSchedulePrefixState] at hu₀
  · intro u₀
    simp [initSyncSchedulePrefixState, pastChargedCount, liveCount]

lemma syncState_chain_len_bound {d n L_leaf : ℕ} {NodeAux : Type}
    {c₁ C_nodes c_chg C_sum α c : ℝ}
    (h51 : ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2)))
    (hCn_pos : 0 < C_nodes)
    (hn : 2 ≤ n) (hα_pos : 0 < α) (hα_le1 : α ≤ 1)
    {admissiblePts : Set (EuclideanSpace ℝ (Fin d))}
    {cur : SyncSchedulePrefixState d NodeAux}
    (hinv : SyncStateInv n L_leaf c_chg C_sum (C_nodes + 1) α c admissiblePts cur) :
    ((cur.nodes.length + 1 : ℕ) : ℝ) ≤ (C_nodes + 1) * α⁻¹ * Real.log (2 * (n : ℝ)) := by
  rcases hinv with ⟨hwf, _, hnodes, _⟩
  let k := cur.nodes.length
  let act := cur.pointSet.activeIds.image cur.pointSet.lifetimeOfId
  have hact_le : act.card ≤ n := Finset.card_image_le.trans hwf.1
  let vecNodes : Fin k → ChainNode d := fun i => (cur.nodes.get i).built.node
  have hk_bound := ((h51 d ℕ cur.ltCoords α hα_pos hα_le1).2 n act hact_le).1
    k vecNodes
    (fun i => (cur.nodes.get i).birthPool)
    (fun i => (cur.nodes.get i).built.node.o)
    (fun i => (cur.nodes.get i).built.s)
    (fun i => (cur.nodes.get i).ageUpdateSteps.card)
    (fun i => by
      rcases hnodes i with ⟨_, h1, hV, hcp, hage, hage_le, _⟩
      exact ⟨rfl, hV, h1, hcp, hage, hage_le⟩)
  have hk : (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) := hk_bound.2.2
  have hlog1 : Real.log ((n : ℝ) + 1) ≤ Real.log (2 * (n : ℝ)) := log_add_one_le_log_two_mul hn
  have hlog_ge1 : 1 ≤ Real.log (2 * (n : ℝ)) := one_le_log_two_mul hn
  have hinv_ge1 : 1 ≤ α⁻¹ := (one_le_inv₀ hα_pos).mpr hα_le1
  have h1_le : 1 ≤ α⁻¹ * Real.log (2 * (n : ℝ)) := by
    calc (1 : ℝ) = 1 * 1 := by ring
      _ ≤ α⁻¹ * Real.log (2 * (n : ℝ)) := mul_le_mul hinv_ge1 hlog_ge1 zero_le_one (by positivity)
  have hk' : (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log (2 * (n : ℝ)) :=
    hk.trans (mul_le_mul_of_nonneg_left hlog1 (by positivity))
  push_cast
  calc (k : ℝ) + 1
      ≤ C_nodes * α⁻¹ * Real.log (2 * (n : ℝ)) + α⁻¹ * Real.log (2 * (n : ℝ)) :=
        add_le_add hk' h1_le
    _ = (C_nodes + 1) * α⁻¹ * Real.log (2 * (n : ℝ)) := by ring

open Classical in
set_option maxHeartbeats 800000 in
/-- Single-step invariant preservation, halting probability 1, and conditional expected work bound. -/
theorem runSingleSyncScheduleStep_props
    {d n L_leaf : ℕ} {NodeAux : Type}
    {c₁ C_nodes : ℝ} (hc₁_pos : 0 < c₁) (hCn_pos : 0 < C_nodes)
    (h51 : ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2)))
    (hn : 2 ≤ n)
    {α c A_n P_α_d P_node_val : ℝ}
    (hα_pos : 0 < α) (hα_le1 : α ≤ 1)
    (hPα_ge1 : 1 ≤ P_α_d) (hbound_α : 1 / P_α_d ≤ α)
    (hA_nn : 0 ≤ A_n) (hPn_nn : 0 ≤ P_node_val)
    {admissiblePts : Set (EuclideanSpace ℝ (Fin d))}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    {ansPol : SyncCheckedAnswerPolicy d NodeAux}
    (hctor : IsValidSyncNodeConstructor n L_leaf α A_n P_node_val admissiblePts ctor)
    (hans : IsValidSyncCheckedAnswerPolicy n c ansPol)
    {cur : SyncSchedulePrefixState d NodeAux}
    (hinv : SyncStateInv n L_leaf (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) α c admissiblePts cur)
    {op : DynamicUpdate d}
    (hleg : IsLegalUpdate n admissiblePts cur.pointSet op) :
    let P_suf_val : ℝ := (1 / c₁) * P_α_d * P_node_val
    syncSingleStepHaltProb L_leaf α ctor ansPol cur op = 1 ∧
    (∀ bs next,
      runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs = some next →
        SyncStateInv n L_leaf (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) α c admissiblePts next ∧
        next.history.length = cur.history.length + 1 ∧
        rootBirthSum cur ≤ rootBirthSum next) ∧
    expVal (runSingleSyncScheduleStep L_leaf α ctor ansPol cur op)
        (fun next => (next.totalRebuildWork : ENNReal)) ≤
      expVal (runSingleSyncScheduleStep L_leaf α ctor ansPol cur op)
        (fun next =>
          (cur.totalRebuildWork : ENNReal) +
            ENNReal.ofReal ((rootBirthSum next - rootBirthSum cur) * A_n * P_suf_val)) := by
  open Classical in
  dsimp only
  have hk_slot_bound :
      ((cur.nodes.length + 1 : ℕ) : ℝ) ≤ (C_nodes + 1) * α⁻¹ * Real.log (2 * (n : ℝ)) :=
    syncState_chain_len_bound h51 hCn_pos hn hα_pos hα_le1 hinv
  rcases hinv with ⟨hwf, hact, hnodes, hleaf_card, hleaf_age, hleaf_u,
    hsnaps, hrecs, hslot_len, hslot_bound, hpot⟩
  rcases applyDynamicUpdate_legal hwf hleg hans.1 hact with
    ⟨P', happly, hwf', hnextLt_le, hltCoords_eq, hact', hchg_act⟩
  let u : ℕ := cur.history.length
  have hu_def : u = cur.history.length := rfl
  let retHandle : Option ℕ := stepRetHandle ansPol.allocHandle cur.pointSet.activeHandles op
  let ltCoords' : ℕ → EuclideanSpace ℝ (Fin d) := stepLtCoords cur.ltCoords cur.pointSet.nextLifetime op
  let k : ℕ := cur.nodes.length
  have hk_def : k = cur.nodes.length := rfl
  let vecNodes : Fin k → ChainNode d := fun i => (cur.nodes.get i).built.node
  let oldAct : Finset ℕ := cur.pointSet.activeIds.image cur.pointSet.lifetimeOfId
  let newAct : Finset ℕ := P'.activeIds.image P'.lifetimeOfId
  let S_old : Fin (k + 1) → Finset ℕ := chainInput ltCoords' vecNodes oldAct
  let S_new : Fin (k + 1) → Finset ℕ := chainInput ltCoords' vecNodes newAct
  have hS_old_eq : ∀ j : Fin (k + 1), S_old j = chainInput cur.ltCoords vecNodes oldAct j := by
    intro j
    refine chainInput_congr (fun lt hlt => hltCoords_eq lt (hact lt hlt).1) (fun _ => rfl) j
  have hS_step : ∀ j : Fin (k + 1), S_new j = S_old j ∨ IsInputChange (S_old j) (S_new j) :=
    chainInput_inputChange_or_eq ltCoords' vecNodes (Or.inr hchg_act)
  let updatedNodes : List (SyncLiveChainNode d NodeAux) :=
    List.ofFn (fun i : Fin k =>
      let v := cur.nodes.get i
      let age' := if S_new i.castSucc ≠ S_old i.castSucc then insert u v.ageUpdateSteps else v.ageUpdateSteps
      { v with ageUpdateSteps := age' })
  let leafAge' : Finset ℕ :=
    if S_new (Fin.last k) ≠ S_old (Fin.last k) then
      insert u cur.leafAgeUpdateSteps
    else
      cur.leafAgeUpdateSteps
  have hupd_age :
      ∀ i : Fin k,
        let vOld := cur.nodes.get i
        let ageSet := if S_new i.castSucc ≠ S_old i.castSucc then insert u vOld.ageUpdateSteps else vOld.ageUpdateSteps
        HasNodeAge vOld.birthPool (S_new i.castSucc) ageSet.card ∧
        (∀ x ∈ ageSet, x < u + 1) ∧
        (∀ x ∈ ageSet, x ≤ u) := by
    intro i
    dsimp only
    rcases hnodes i with ⟨_, _, _, _, hage_i, _, hu_i⟩
    rw [← hS_old_eq i.castSucc] at hage_i
    by_cases hneq : S_new i.castSucc ≠ S_old i.castSucc
    · rw [if_pos hneq]
      have hu_not : u ∉ (cur.nodes.get i).ageUpdateSteps := fun hm => lt_irrefl u (hu_i u hm)
      have hchg_i : IsInputChange (S_old i.castSucc) (S_new i.castSucc) :=
        (hS_step i.castSucc).resolve_left hneq
      rw [Finset.card_insert_of_notMem hu_not]
      refine ⟨hasNodeAge_step hage_i hchg_i, ?_, ?_⟩
      · intro x hx
        rcases Finset.mem_insert.mp hx with rfl | hx'
        · omega
        · have := hu_i x hx'; omega
      · intro x hx
        rcases Finset.mem_insert.mp hx with rfl | hx'
        · exact le_rfl
        · exact Nat.le_of_lt (hu_i x hx')
    · rw [if_neg hneq]
      push_neg at hneq
      rw [hneq]
      exact ⟨hage_i, fun x hx => Nat.lt_succ_of_lt (hu_i x hx),
        fun x hx => Nat.le_of_lt (hu_i x hx)⟩
  have hleaf_upd_age :
      HasNodeAge cur.leafBirthPool (S_new (Fin.last k)) leafAge'.card ∧
      (∀ x ∈ leafAge', x < u + 1) ∧
      (∀ x ∈ leafAge', x ≤ u) := by
    dsimp only [leafAge']
    have hage_l := hleaf_age
    rw [← hS_old_eq (Fin.last k)] at hage_l
    by_cases hneq : S_new (Fin.last k) ≠ S_old (Fin.last k)
    · rw [if_pos hneq]
      have hu_not : u ∉ cur.leafAgeUpdateSteps := fun hm => lt_irrefl u (hleaf_u u hm)
      have hchg_l : IsInputChange (S_old (Fin.last k)) (S_new (Fin.last k)) :=
        (hS_step (Fin.last k)).resolve_left hneq
      rw [Finset.card_insert_of_notMem hu_not]
      refine ⟨hasNodeAge_step hage_l hchg_l, ?_, ?_⟩
      · intro x hx
        rcases Finset.mem_insert.mp hx with rfl | hx'
        · omega
        · have := hleaf_u x hx'; omega
      · intro x hx
        rcases Finset.mem_insert.mp hx with rfl | hx'
        · exact le_rfl
        · exact Nat.le_of_lt (hleaf_u x hx')
    · rw [if_neg hneq]
      push_neg at hneq
      rw [hneq]
      exact ⟨hage_l, fun x hx => Nat.lt_succ_of_lt (hleaf_u x hx),
        fun x hx => Nat.le_of_lt (hleaf_u x hx)⟩
  let slotTriggers : ℕ → Prop := fun j =>
    if hj : j < k then
      let vOld := cur.nodes.get ⟨j, hj⟩
      let ageCard :=
        (if S_new ⟨j, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨j, Nat.lt_succ_of_lt hj⟩ then
          insert u vOld.ageUpdateSteps
        else
          vOld.ageUpdateSteps).card
      α * (vOld.birthPool.card : ℝ) / 16 < (ageCard : ℝ)
    else
      j = k ∧ 2 * L_leaf < (S_new (Fin.last k)).card
  have hmap_upd_ne :
      ∀ {u₀ : ℕ}, u₀ ≠ u →
        updatedNodes.map (fun v => decide (u₀ ∈ v.ageUpdateSteps)) =
          cur.nodes.map (fun v => decide (u₀ ∈ v.ageUpdateSteps)) := by
    intro u₀ hne
    refine map_ofFn_eq_map cur.nodes _ _ _ fun i => ?_
    dsimp only
    by_cases hc : S_new i.castSucc ≠ S_old i.castSucc
    · simp [hc, hne]
    · simp [hc]
  have hpot_u_zero : pastChargedCount cur u = 0 := by
    have hpu := hpot u
    rw [if_neg (by omega)] at hpu
    omega
  by_cases hTrig : ∃ j : ℕ, j ≤ k ∧ slotTriggers j
  · -- TRIGGERED BRANCH
    let jStar : ℕ := Nat.find hTrig
    have hjSpec := Nat.find_spec hTrig
    have hjLe : jStar ≤ k := hjSpec.1
    have hjTrig : slotTriggers jStar := hjSpec.2
    let jFin : Fin (k + 1) := ⟨jStar, Nat.lt_succ_of_le hjLe⟩
    let S_trig : Finset ℕ := S_new jFin
    let charged : Finset ℕ :=
      if hj : jStar < k then
        let vOld := cur.nodes.get ⟨jStar, hj⟩
        if S_new ⟨jStar, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨jStar, Nat.lt_succ_of_lt hj⟩ then
          insert u vOld.ageUpdateSteps
        else
          vOld.ageUpdateSteps
      else
        leafAge'
    have hStrig_sub : S_trig ⊆ newAct := chainInput_subset ltCoords' vecNodes newAct jFin
    have hStrig_n : S_trig.card ≤ n :=
      (Finset.card_le_card hStrig_sub).trans (Finset.card_image_le.trans hwf'.1)
    have hStrig_adm : ∀ lt ∈ S_trig, ltCoords' lt ∈ admissiblePts :=
      fun lt hlt => (hact' lt (hStrig_sub hlt)).2
    have hsuf_all := runSyncSuffixBuild_all hc₁_pos h51 hα_pos hα_le1 hPα_ge1 hbound_α
      hA_nn hPn_nn hctor cur.history ltCoords' S_trig hStrig_n hStrig_adm
    rcases hsuf_all with ⟨_, hhalt_suf, hout_suf, hexp_suf, _, _⟩
    have hstep_eq :
        ∀ bs : List Bool,
          runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs =
            Option.map (fun sufOut =>
              let newSuffixNodes : List (SyncLiveChainNode d NodeAux) :=
                sufOut.entries.map (fun e =>
                  { built := e.built, birthPool := e.birthPool, ageUpdateSteps := ∅ })
              let finalNodes := updatedNodes.take jStar ++ newSuffixNodes
              let ans := ansPol.checkedAnswer P' finalNodes
              let entry : StepHistoryEntry d :=
                { operation := op
                  randomBits := bs
                  returnedHandle := retHandle
                  answer := ans
                  resolvedIds := resolveAnswerIdentities P' ans }
              let recEntry : SyncTriggeredSuffixRecord :=
                { triggerStep := u
                  triggerDepth := jStar
                  canceledDescendants := k - jStar
                  rootBirthCard := S_trig.card
                  chainBirthCards := sufOut.entries.map (fun e => e.birthPool.card)
                  chargedUpdateSteps := charged
                  rebuildWork := sufOut.totalWork }
              { pointSet := P'
                ltCoords := ltCoords'
                nodes := finalNodes
                leafBirthPool := sufOut.terminalLeaf
                leafAgeUpdateSteps := ∅
                history := cur.history ++ [entry]
                snapshots := cur.snapshots ++ [(P', ans)]
                triggeredSuffixes := cur.triggeredSuffixes ++ [recEntry]
                chainSlotCounts := cur.chainSlotCounts ++ [k + 1]
                totalRebuildWork := cur.totalRebuildWork + sufOut.totalWork })
            (runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig bs) := by
      intro bs
      cases op <;>
        (have hTrig0 := hTrig
         unfold runSingleSyncScheduleStep
         dsimp only [retHandle, stepRetHandle] at happly
         dsimp only [k, slotTriggers, u, S_new, S_old, ltCoords', stepLtCoords,
           vecNodes, oldAct, newAct] at hTrig0
         dsimp only
         rw [happly]
         dsimp only
         rw [dif_pos hTrig0]
         rcases hs : runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig bs with _ | sufOut <;>
           (dsimp only [u, retHandle, stepRetHandle, ltCoords', stepLtCoords, k, vecNodes,
              oldAct, newAct, S_old, S_new, updatedNodes, leafAge', slotTriggers,
              jStar, jFin, S_trig, charged] at hs ⊢
            rw [hs]
            rfl))
    have hhalt_step : syncSingleStepHaltProb L_leaf α ctor ansPol cur op = 1 := by
      unfold syncSingleStepHaltProb
      have hcongr :
          (fun bs => if (runSingleSyncScheduleStep L_leaf α ctor ansPol cur op bs).isSome then bitListProb bs else 0) =
            (fun bs => if (runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig bs).isSome then bitListProb bs else 0) := by
        ext bs
        rw [hstep_eq bs]
        cases runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig bs <;> rfl
      rw [hcongr]
      exact hhalt_suf
    have hchg_bounds :
        (1 / 17 : ℝ) * α * (S_trig.card : ℝ) ≤ (charged.card : ℝ) ∧
        (∀ u₀ ∈ charged, u₀ ≤ u) := by
      by_cases hj : jStar < k
      · dsimp only [charged]
        rw [dif_pos hj]
        have htrig_j : slotTriggers jStar := hjTrig
        dsimp only [slotTriggers] at htrig_j
        rw [dif_pos hj] at htrig_j
        have hupd_j := hupd_age ⟨jStar, hj⟩
        dsimp only at hupd_j
        have hcard_le : S_trig.card ≤ (cur.nodes.get ⟨jStar, hj⟩).birthPool.card +
            (if S_new ⟨jStar, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨jStar, Nat.lt_succ_of_lt hj⟩ then
              insert u (cur.nodes.get ⟨jStar, hj⟩).ageUpdateSteps
            else
              (cur.nodes.get ⟨jStar, hj⟩).ageUpdateSteps).card :=
          hasNodeAge_card_le hupd_j.1
        refine ⟨?_, hupd_j.2.2⟩
        set A : ℕ :=
          (if S_new ⟨jStar, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨jStar, Nat.lt_succ_of_lt hj⟩ then
            insert u (cur.nodes.get ⟨jStar, hj⟩).ageUpdateSteps
          else
            (cur.nodes.get ⟨jStar, hj⟩).ageUpdateSteps).card
        set B₀ : ℕ := (cur.nodes.get ⟨jStar, hj⟩).birthPool.card
        have hcard_r : (S_trig.card : ℝ) ≤ (B₀ : ℝ) + (A : ℝ) := by exact_mod_cast hcard_le
        have hA_nn : (0 : ℝ) ≤ (A : ℝ) := Nat.cast_nonneg A
        have hαA : α * (A : ℝ) ≤ (A : ℝ) := by nlinarith
        nlinarith
      · dsimp only [charged]
        rw [dif_neg hj]
        have hjk : jStar = k := by omega
        have htrig_k : slotTriggers jStar := hjTrig
        dsimp only [slotTriggers] at htrig_k
        rw [dif_neg hj] at htrig_k
        have h2L : 2 * L_leaf < (S_new (Fin.last k)).card := htrig_k.2
        have hStrig_last : S_trig = S_new (Fin.last k) := by
          dsimp only [S_trig, jFin]
          congr 1
          ext
          exact hjk
        rw [hStrig_last]
        have hcard_le : (S_new (Fin.last k)).card ≤ cur.leafBirthPool.card + leafAge'.card :=
          hasNodeAge_card_le hleaf_upd_age.1
        have hM_le_2A : (S_new (Fin.last k)).card ≤ 2 * leafAge'.card := by omega
        have hM_r : ((S_new (Fin.last k)).card : ℝ) ≤ 2 * (leafAge'.card : ℝ) := by
          exact_mod_cast hM_le_2A
        refine ⟨?_, hleaf_upd_age.2.2⟩
        have hA_nn : (0 : ℝ) ≤ (leafAge'.card : ℝ) := Nat.cast_nonneg _
        nlinarith
    refine ⟨hhalt_step, ?_, ?_⟩
    · -- (B) State invariant on `next`
      intro bs next hnext
      rw [hstep_eq bs] at hnext
      cases hsuf : runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig bs with
      | none => simp [hsuf] at hnext
      | some sufOut =>
          simp only [hsuf, Option.map_some] at hnext
          injection hnext with hnext_eq
          subst hnext_eq
          rcases hout_suf bs sufOut hsuf with
            ⟨hterm_le, hterm_sub, hchain_suf, hsum_suf, hent_props⟩
          rcases builtSuffixChain_inputs hchain_suf with ⟨hchain_in, hchain_term⟩
          let newSuffixNodes : List (SyncLiveChainNode d NodeAux) :=
            sufOut.entries.map (fun e =>
              { built := e.built, birthPool := e.birthPool, ageUpdateSteps := ∅ })
          let finalNodes := updatedNodes.take jStar ++ newSuffixNodes
          have hupd_len : updatedNodes.length = k := by
            dsimp only [updatedNodes]
            rw [List.length_ofFn, hk_def]
          have htake_len : (updatedNodes.take jStar).length = jStar := by
            rw [List.length_take, hupd_len]
            exact Nat.min_eq_left hjLe
          let L₁_nodes : List (ChainNode d) := (updatedNodes.take jStar).map (fun v => v.built.node)
          let L₂_nodes : List (ChainNode d) := newSuffixNodes.map (fun v => v.built.node)
          have hL₁_len : L₁_nodes.length = jStar := by
            dsimp only [L₁_nodes]
            rw [List.length_map, htake_len]
          have hL₂_len : L₂_nodes.length = sufOut.entries.length := by
            dsimp only [L₂_nodes, newSuffixNodes]
            rw [List.length_map, List.length_map]
          have hmap_all : finalNodes.map (fun v => v.built.node) = L₁_nodes ++ L₂_nodes := by
            dsimp only [finalNodes, L₁_nodes, L₂_nodes]
            exact List.map_append
          have hfin_eq_L : finalNodes.length = (L₁_nodes ++ L₂_nodes).length := by
            rw [← List.length_map (f := fun v : SyncLiveChainNode d NodeAux => v.built.node), hmap_all]
          have hfin_eq_L_succ : finalNodes.length + 1 = (L₁_nodes ++ L₂_nodes).length + 1 :=
            congrArg (· + 1) hfin_eq_L
          have hfin_len : finalNodes.length = jStar + sufOut.entries.length := by
            rw [hfin_eq_L, List.length_append, hL₁_len, hL₂_len]
          have hL₁_inputs :
              ∀ m (hm : m ≤ jStar),
                chainInput ltCoords' (fun i : Fin L₁_nodes.length => L₁_nodes.get i) newAct
                  ⟨m, Nat.lt_succ_of_le (by omega)⟩ =
                S_new ⟨m, Nat.lt_succ_of_le (hm.trans hjLe)⟩ := by
            intro m hm
            induction m with
            | zero => rfl
            | succ m' ihm =>
                have hm'_lt : m' < jStar := Nat.lt_of_succ_le hm
                have hm'_k : m' < k := Nat.lt_of_lt_of_le hm'_lt hjLe
                have hs1 : (⟨m' + 1, Nat.lt_succ_of_le (by omega)⟩ : Fin (L₁_nodes.length + 1)) =
                    (⟨m', by omega⟩ : Fin L₁_nodes.length).succ := rfl
                have hs2 : (⟨m' + 1, Nat.lt_succ_of_le (hm.trans hjLe)⟩ : Fin (k + 1)) =
                    (⟨m', hm'_k⟩ : Fin k).succ := rfl
                have hcs1 : (⟨m', by omega⟩ : Fin L₁_nodes.length).castSucc =
                    ⟨m', Nat.lt_succ_of_le (by omega)⟩ := rfl
                have hcs2 : (⟨m', hm'_k⟩ : Fin k).castSucc =
                    ⟨m', Nat.lt_succ_of_le ((Nat.le_of_lt hm'_lt).trans hjLe)⟩ := rfl
                rw [hs1, hs2]
                have hih := ihm (Nat.le_of_lt hm'_lt)
                dsimp only [S_new] at hih ⊢
                rw [chainInput_succ, chainInput_succ, hcs1, hcs2, hih]
                have hnode_eq : L₁_nodes.get ⟨m', by omega⟩ = vecNodes ⟨m', hm'_k⟩ := by
                  dsimp only [L₁_nodes, updatedNodes, vecNodes]
                  simp [List.get_eq_getElem]
                rw [hnode_eq]
          have hL₁_last :
              chainInput ltCoords' (fun i : Fin L₁_nodes.length => L₁_nodes.get i) newAct
                (Fin.last L₁_nodes.length) = S_trig := by
            have h := hL₁_inputs jStar le_rfl
            convert h using 2
            ext
            exact hL₁_len
          have hL₂_inputs :
              ∀ r (hr : r ≤ sufOut.entries.length),
                chainInput ltCoords' (fun i : Fin L₂_nodes.length => L₂_nodes.get i) S_trig
                  ⟨r, Nat.lt_succ_of_le (by omega)⟩ =
                chainInput ltCoords' (fun i : Fin sufOut.entries.length => (sufOut.entries.get i).built.node) S_trig
                  ⟨r, Nat.lt_succ_of_le hr⟩ := by
            intro r hr
            induction r with
            | zero => rfl
            | succ r' ihr =>
                have hr' : r' < sufOut.entries.length := Nat.lt_of_succ_le hr
                have hs1 : (⟨r' + 1, Nat.lt_succ_of_le (by omega)⟩ : Fin (L₂_nodes.length + 1)) =
                    (⟨r', by omega⟩ : Fin L₂_nodes.length).succ := rfl
                have hs2 : (⟨r' + 1, Nat.lt_succ_of_le hr⟩ : Fin (sufOut.entries.length + 1)) =
                    (⟨r', hr'⟩ : Fin sufOut.entries.length).succ := rfl
                have hcs1 : (⟨r', by omega⟩ : Fin L₂_nodes.length).castSucc =
                    ⟨r', Nat.lt_succ_of_le (by omega)⟩ := rfl
                have hcs2 : (⟨r', hr'⟩ : Fin sufOut.entries.length).castSucc =
                    ⟨r', Nat.lt_succ_of_le (Nat.le_of_lt hr')⟩ := rfl
                rw [hs1, hs2, chainInput_succ, chainInput_succ, hcs1, hcs2, ihr (Nat.le_of_lt hr')]
                dsimp only [L₂_nodes, newSuffixNodes]
                simp [List.get_eq_getElem]
          have hfinal_vec_eq :
              ∀ j : Fin (finalNodes.length + 1),
                chainInput ltCoords' (fun i : Fin finalNodes.length => (finalNodes.get i).built.node) newAct j =
                chainInput ltCoords'
                  (fun i : Fin (L₁_nodes ++ L₂_nodes).length => (L₁_nodes ++ L₂_nodes).get i) newAct
                  (j.cast hfin_eq_L_succ) := by
            intro j
            induction j using Fin.induction with
            | zero => rfl
            | succ i ih =>
                have hcast_succ :
                    (i.succ).cast hfin_eq_L_succ = (i.cast hfin_eq_L).succ := by
                  ext; rfl
                rw [hcast_succ, chainInput_succ, chainInput_succ]
                have hcs : (i.cast hfin_eq_L).castSucc = (i.castSucc).cast hfin_eq_L_succ := by
                  ext; rfl
                rw [hcs, ih]
                have hget_eq :
                    (finalNodes.get i).built.node =
                      (L₁_nodes ++ L₂_nodes).get (i.cast hfin_eq_L) := by
                  simp [← hmap_all, List.get_eq_getElem]
                rw [hget_eq]
          refine ⟨?_, by simp, ?_⟩
          · refine ⟨hwf', hact', ?_, hterm_le, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
            · -- Clause 3: Internal nodes of `finalNodes`
              intro i
              by_cases hi : i.val < jStar
              · have hi_k : i.val < k := Nat.lt_of_lt_of_le hi hjLe
                have hv_eq : finalNodes.get i = updatedNodes.get ⟨i.val, by omega⟩ := by
                  simp [finalNodes, List.get_eq_getElem,
                    List.getElem_append_left (by omega : i.val < (updatedNodes.take jStar).length)]
                dsimp only
                rw [hv_eq]
                have hv_upd :
                    updatedNodes.get ⟨i.val, by omega⟩ =
                      let v := cur.nodes.get ⟨i.val, hi_k⟩
                      { v with ageUpdateSteps :=
                          if S_new ⟨i.val, Nat.lt_succ_of_lt hi_k⟩ ≠ S_old ⟨i.val, Nat.lt_succ_of_lt hi_k⟩ then
                            insert u v.ageUpdateSteps
                          else
                            v.ageUpdateSteps } := by
                  simp [updatedNodes]
                rw [hv_upd]
                rcases hnodes ⟨i.val, hi_k⟩ with ⟨hbp_lt, hbp_1, hV_i, hcp_i, _, _, _⟩
                have hbp_lt' :
                    ∀ lt ∈ (cur.nodes.get ⟨i.val, hi_k⟩).birthPool,
                      lt < P'.nextLifetime ∧ ltCoords' lt ∈ admissiblePts := by
                  intro lt hlt
                  rcases hbp_lt lt hlt with ⟨h1, h2⟩
                  refine ⟨Nat.lt_of_lt_of_le h1 hnextLt_le, ?_⟩
                  have hlt_eq : ltCoords' lt = cur.ltCoords lt := hltCoords_eq lt h1
                  rw [hlt_eq]
                  exact h2
                have hcp_i' :
                    IsCenterpoint α
                      (paraboloidLiftSet (fun j : (cur.nodes.get ⟨i.val, hi_k⟩).birthPool => ltCoords' j.1))
                      (liftedPoint (cur.nodes.get ⟨i.val, hi_k⟩).built.node.o
                        (cur.nodes.get ⟨i.val, hi_k⟩).built.s) := by
                  have hfn_eq :
                      (fun j : (cur.nodes.get ⟨i.val, hi_k⟩).birthPool => ltCoords' j.1) =
                        (fun j : (cur.nodes.get ⟨i.val, hi_k⟩).birthPool => cur.ltCoords j.1) :=
                    funext fun j => hltCoords_eq j.1 (hbp_lt j.1 j.2).1
                  rw [hfn_eq]
                  exact hcp_i
                have hci_eq :
                    chainInput ltCoords' (fun q : Fin finalNodes.length => (finalNodes.get q).built.node)
                      newAct i.castSucc = S_new ⟨i.val, Nat.lt_succ_of_lt hi_k⟩ := by
                  rw [hfinal_vec_eq i.castSucc]
                  have hleft := chainInput_append_left ltCoords' L₁_nodes L₂_nodes newAct
                    i.val (by omega)
                  have hLL_len : (L₁_nodes ++ L₂_nodes).length = jStar + sufOut.entries.length := by
                    rw [List.length_append, hL₁_len, hL₂_len]
                  have hi_le_LL : i.val ≤ (L₁_nodes ++ L₂_nodes).length := by omega
                  have hcast_eq :
                      (i.castSucc).cast hfin_eq_L_succ =
                        ⟨i.val, Nat.lt_succ_of_le hi_le_LL⟩ := by
                    ext; rfl
                  rw [hcast_eq, hleft]
                  exact hL₁_inputs i.val (Nat.le_of_lt hi)
                rw [hci_eq]
                have hupd_i := hupd_age ⟨i.val, hi_k⟩
                dsimp only at hupd_i
                have hnot_trig : ¬ slotTriggers i.val := by
                  intro hst_i
                  exact Nat.find_min hTrig hi ⟨Nat.le_of_lt hi_k, hst_i⟩
                dsimp only [slotTriggers] at hnot_trig
                rw [dif_pos hi_k] at hnot_trig
                have hage_le_i :
                    ((if S_new ⟨i.val, Nat.lt_succ_of_lt hi_k⟩ ≠ S_old ⟨i.val, Nat.lt_succ_of_lt hi_k⟩ then
                      insert u (cur.nodes.get ⟨i.val, hi_k⟩).ageUpdateSteps
                    else
                      (cur.nodes.get ⟨i.val, hi_k⟩).ageUpdateSteps).card : ℝ) ≤
                    α * ((cur.nodes.get ⟨i.val, hi_k⟩).birthPool.card : ℝ) / 16 :=
                  le_of_not_gt hnot_trig
                refine ⟨hbp_lt', hbp_1, hV_i, hcp_i', hupd_i.1, hage_le_i, ?_⟩
                intro x hx
                simpa using hupd_i.2.1 x hx
              · -- Newly built suffix node `jStar ≤ i.val`
                have hj_le_i : jStar ≤ i.val := Nat.le_of_not_lt hi
                let r : ℕ := i.val - jStar
                have hr_def : r = i.val - jStar := rfl
                have hi_lt_fin : i.val < jStar + sufOut.entries.length :=
                  Nat.lt_of_lt_of_eq i.isLt hfin_len
                have hr_lt : r < sufOut.entries.length := by omega
                have hi_eq : i.val = jStar + r := by omega
                have hv_eq :
                    finalNodes.get i =
                      { built := (sufOut.entries.get ⟨r, hr_lt⟩).built
                        birthPool := (sufOut.entries.get ⟨r, hr_lt⟩).birthPool
                        ageUpdateSteps := ∅ } := by
                  have hge : (updatedNodes.take jStar).length ≤ i.val := by omega
                  dsimp only [finalNodes, newSuffixNodes]
                  simp [List.get_eq_getElem, List.getElem_append_right hge, htake_len, hr_def]
                dsimp only
                rw [hv_eq]
                let e := sufOut.entries.get ⟨r, hr_lt⟩
                have he_mem : e ∈ sufOut.entries := List.get_mem _ _
                rcases hent_props e he_mem with ⟨he_sub, he_gt, he_V, he_cp⟩
                have he_bp_lt :
                    ∀ lt ∈ e.birthPool, lt < P'.nextLifetime ∧ ltCoords' lt ∈ admissiblePts :=
                  fun lt hlt => hact' lt (hStrig_sub (he_sub hlt))
                have he_1 : 1 ≤ e.birthPool.card := by omega
                have hci_eq :
                    chainInput ltCoords' (fun q : Fin finalNodes.length => (finalNodes.get q).built.node)
                      newAct i.castSucc = e.birthPool := by
                  rw [hfinal_vec_eq i.castSucc]
                  have hright := chainInput_append_right ltCoords' L₁_nodes L₂_nodes newAct
                    r (by omega)
                  have hr_le_LL : L₁_nodes.length + r ≤ (L₁_nodes ++ L₂_nodes).length := by
                    rw [List.length_append, hL₂_len]
                    omega
                  have hcast_eq :
                      (i.castSucc).cast hfin_eq_L_succ =
                        ⟨L₁_nodes.length + r, Nat.lt_succ_of_le hr_le_LL⟩ := by
                    ext
                    simp [hL₁_len, hi_eq]
                  rw [hcast_eq, hright, hL₁_last, hL₂_inputs r (Nat.le_of_lt hr_lt)]
                  exact hchain_in ⟨r, hr_lt⟩
                rw [hci_eq]
                refine ⟨he_bp_lt, he_1, he_V, he_cp, ?_, ?_, ?_⟩
                · simpa using hasNodeAge_refl e.birthPool
                · change ((∅ : Finset ℕ).card : ℝ) ≤ α * (e.birthPool.card : ℝ) / 16
                  rw [Finset.card_empty, Nat.cast_zero]
                  exact div_nonneg (mul_nonneg hα_pos.le (Nat.cast_nonneg _)) (by norm_num)
                · simp
            · -- Clause 4b: Terminal leaf `HasNodeAge`
              have hci_last :
                  chainInput ltCoords' (fun q : Fin finalNodes.length => (finalNodes.get q).built.node)
                    newAct (Fin.last finalNodes.length) = sufOut.terminalLeaf := by
                rw [hfinal_vec_eq (Fin.last finalNodes.length)]
                have hright := chainInput_append_right ltCoords' L₁_nodes L₂_nodes newAct
                  sufOut.entries.length (by omega)
                have hlast_le_LL : L₁_nodes.length + sufOut.entries.length ≤ (L₁_nodes ++ L₂_nodes).length := by
                  rw [List.length_append, hL₂_len]
                have hcast_eq :
                    (Fin.last finalNodes.length).cast hfin_eq_L_succ =
                      ⟨L₁_nodes.length + sufOut.entries.length, Nat.lt_succ_of_le hlast_le_LL⟩ := by
                  ext
                  dsimp only
                  rw [Fin.val_cast, Fin.val_last, hfin_len, hL₁_len]
                rw [hcast_eq, hright, hL₁_last, hL₂_inputs sufOut.entries.length le_rfl]
                exact hchain_term
              rw [hci_last]
              simpa using hasNodeAge_refl sufOut.terminalLeaf
            · simp
            · -- Clause 5: Snapshots
              intro snap hsnap
              rcases List.mem_append.mp hsnap with h_old | h_new
              · exact hsnaps snap h_old
              · simp only [List.mem_singleton] at h_new
                subst h_new
                exact hans.2 P' finalNodes hwf'
            · -- Clause 6: Triggered suffixes
              intro rec hrec
              rcases List.mem_append.mp hrec with h_old | h_new
              · rcases hrecs rec h_old with ⟨h1, h2, h3, h4⟩
                refine ⟨h1, h2, ?_, h4⟩
                simp; omega
              · simp only [List.mem_singleton] at h_new
                subst h_new
                refine ⟨hchg_bounds.1, ?_, ?_, hchg_bounds.2⟩
                · dsimp only
                  rw [coe_list_map_id_eq sufOut.entries (fun e => e.birthPool.card)]
                  exact hsum_suf
                · dsimp only
                  rw [List.length_append, List.length_singleton, ← hu_def]
                  exact Nat.lt_succ_self u
            · simp [hslot_len]
            · -- Clause 7b: Slot count upper bound
              intro u₀ hu₀
              simp only [List.length_append, List.length_singleton] at hu₀
              rcases Nat.lt_succ_iff_lt_or_eq.mp hu₀ with hu_lt | rfl
              · rw [getD_append_singleton_lt _ _ _ (hslot_len ▸ hu_lt)]
                exact hslot_bound u₀ hu_lt
              · rw [← hslot_len, getD_append_singleton_eq]
                exact hk_slot_bound
            · -- Clause 7c: Charging potential `Φ(next, u₀)`
              intro u₀
              have hlive_new_zero :
                  (newSuffixNodes.filter (fun v => decide (u₀ ∈ v.ageUpdateSteps))).length = 0 := by
                have hnil : newSuffixNodes.filter (fun v => decide (u₀ ∈ v.ageUpdateSteps)) = [] := by
                  rw [List.filter_eq_nil_iff]
                  intro v hv
                  rcases List.mem_map.mp hv with ⟨e, _, rfl⟩
                  simp
                rw [hnil]; rfl
              have hlive_eq :
                  (finalNodes.filter (fun v => decide (u₀ ∈ v.ageUpdateSteps))).length =
                    ((updatedNodes.take jStar).filter (fun v => decide (u₀ ∈ v.ageUpdateSteps))).length := by
                simp [finalNodes, List.filter_append, hlive_new_zero]
              let newRec : SyncTriggeredSuffixRecord :=
                { triggerStep := u
                  triggerDepth := jStar
                  canceledDescendants := k - jStar
                  rootBirthCard := S_trig.card
                  chainBirthCards := sufOut.entries.map (fun e => e.birthPool.card)
                  chargedUpdateSteps := charged
                  rebuildWork := sufOut.totalWork }
              have hpast_eq :
                  ((cur.triggeredSuffixes ++ [newRec]).filter
                      (fun rec => decide (u₀ ∈ rec.chargedUpdateSteps))).length =
                    pastChargedCount cur u₀ + (if u₀ ∈ charged then 1 else 0) := by
                unfold pastChargedCount
                dsimp only [newRec]
                by_cases huc : u₀ ∈ charged <;> simp [List.filter_append, huc]
              dsimp only [pastChargedCount, liveCount]
              rw [hpast_eq, hlive_eq]
              simp only [Finset.notMem_empty, ↓reduceIte, Nat.add_zero,
                List.length_append, List.length_singleton]
              by_cases hu_eq : u₀ = u
              · subst hu_eq
                have hlt_succ : u < cur.history.length + 1 := Nat.lt_succ_self u
                rw [if_pos hlt_succ, hpot_u_zero, Nat.zero_add, hu_def, ← hslot_len, getD_append_singleton_eq]
                have hfilt_le :
                    ((updatedNodes.take jStar).filter (fun v => decide (cur.chainSlotCounts.length ∈ v.ageUpdateSteps))).length ≤ k :=
                  (List.length_filter_le _ _).trans (by rw [htake_len]; exact hjLe)
                by_cases huc : cur.chainSlotCounts.length ∈ charged
                · rw [if_pos huc]; omega
                · rw [if_neg huc]; omega
              · -- `u₀ ≠ u`
                have htake_map :
                    (updatedNodes.take jStar).map (fun v => decide (u₀ ∈ v.ageUpdateSteps)) =
                      (cur.nodes.take jStar).map (fun v => decide (u₀ ∈ v.ageUpdateSteps)) := by
                  rw [List.map_take, List.map_take, hmap_upd_ne hu_eq]
                have htake_filt_eq :
                    ((updatedNodes.take jStar).filter (fun v => decide (u₀ ∈ v.ageUpdateSteps))).length =
                      ((cur.nodes.take jStar).filter (fun v => decide (u₀ ∈ v.ageUpdateSteps))).length :=
                  filter_length_eq_of_map_eq htake_map
                rw [htake_filt_eq]
                have hdrop_bound :
                    (if u₀ ∈ charged then 1 else 0) +
                      ((cur.nodes.take jStar).filter (fun v => decide (u₀ ∈ v.ageUpdateSteps))).length ≤
                    liveCount cur u₀ := by
                  unfold liveCount
                  by_cases hj : jStar < k
                  · have hchg_iff : u₀ ∈ charged ↔ u₀ ∈ (cur.nodes.get ⟨jStar, hj⟩).ageUpdateSteps := by
                      dsimp only [charged]
                      rw [dif_pos hj]
                      by_cases hc : S_new ⟨jStar, Nat.lt_succ_of_lt hj⟩ ≠ S_old ⟨jStar, Nat.lt_succ_of_lt hj⟩ <;>
                        simp [hc, hu_eq]
                    have hft := filter_take_length_add_get
                      (fun v : SyncLiveChainNode d NodeAux => decide (u₀ ∈ v.ageUpdateSteps))
                      cur.nodes jStar hj
                    have hif_eq :
                        (if decide (u₀ ∈ (cur.nodes.get ⟨jStar, hj⟩).ageUpdateSteps) = true then 1 else 0) =
                          (if u₀ ∈ charged then 1 else 0) := by
                      by_cases hm : u₀ ∈ charged
                      · rw [if_pos (decide_eq_true (hchg_iff.mp hm)), if_pos hm]
                      · have hm' : u₀ ∉ (cur.nodes.get ⟨jStar, hj⟩).ageUpdateSteps :=
                          fun h0 => hm (hchg_iff.mpr h0)
                        rw [if_neg (fun hd => hm' (of_decide_eq_true hd)), if_neg hm]
                    rw [hif_eq] at hft
                    omega
                  · have hjk : jStar = cur.nodes.length := by omega
                    have htake_all : cur.nodes.take jStar = cur.nodes := by
                      rw [hjk]; exact List.take_length
                    rw [htake_all]
                    have hchg_iff : u₀ ∈ charged ↔ u₀ ∈ cur.leafAgeUpdateSteps := by
                      dsimp only [charged, leafAge', k]
                      rw [dif_neg hj]
                      by_cases hc : S_new (Fin.last cur.nodes.length) ≠ S_old (Fin.last cur.nodes.length) <;>
                        simp [hc, hu_eq]
                    by_cases hm : u₀ ∈ cur.leafAgeUpdateSteps
                    · rw [if_pos (hchg_iff.mpr hm), if_pos hm]; omega
                    · have hm' : u₀ ∉ charged := fun h0 => hm (hchg_iff.mp h0)
                      rw [if_neg hm', if_neg hm]; omega
                have hpot_cur := hpot u₀
                have hiff_lt : u₀ < cur.history.length + 1 ↔ u₀ < cur.history.length := by omega
                by_cases hlt_u : u₀ < cur.history.length
                · rw [if_pos (hiff_lt.mpr hlt_u),
                    getD_append_singleton_lt _ _ _ (hslot_len ▸ hlt_u)]
                  rw [if_pos hlt_u] at hpot_cur
                  omega
                · rw [if_neg (fun h0 => hlt_u (hiff_lt.mp h0))]
                  rw [if_neg hlt_u] at hpot_cur
                  omega
          · unfold rootBirthSum
            simp only [List.map_append, List.sum_append, List.map_singleton, List.sum_singleton]
            have : (0 : ℝ) ≤ (S_trig.card : ℝ) := Nat.cast_nonneg _
            linarith
    · -- (C) Expected step work inequality
      let stepF := runSingleSyncScheduleStep L_leaf α ctor ansPol cur op
      let sufF := runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig
      let P_suf_val : ℝ := (1 / c₁) * P_α_d * P_node_val
      have hhalt_suf' : haltProb sufF = 1 := hhalt_suf
      have hhalt_step' : haltProb stepF = 1 := hhalt_step
      have hLHS :
          expVal stepF (fun next => (next.totalRebuildWork : ENNReal)) =
            (cur.totalRebuildWork : ENNReal) + syncSuffixExpectedWork ctor L_leaf cur.history ltCoords' S_trig := by
        have heq1 :
            expVal stepF (fun next => (next.totalRebuildWork : ENNReal)) =
              expVal sufF (fun sufOut => (cur.totalRebuildWork : ENNReal) + (sufOut.totalWork : ENNReal)) := by
          unfold expVal
          congr 1
          ext bs
          dsimp only [stepF, sufF]
          rw [hstep_eq bs]
          cases runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig bs with
          | none => rfl
          | some sufOut => simp [Nat.cast_add]
        rw [heq1, expVal_add, expVal_const, hhalt_suf', one_mul]
        congr 1
        unfold expVal syncSuffixExpectedWork
        congr 1
        ext bs
        dsimp only [sufF]
        cases runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig bs <;> rfl
      have hRHS :
          expVal stepF (fun next =>
              (cur.totalRebuildWork : ENNReal) +
                ENNReal.ofReal ((rootBirthSum next - rootBirthSum cur) * A_n * P_suf_val)) =
            (cur.totalRebuildWork : ENNReal) +
              ENNReal.ofReal ((S_trig.card : ℝ) * A_n * P_suf_val) := by
        have hcongr_rhs :
            expVal stepF (fun next =>
                (cur.totalRebuildWork : ENNReal) +
                  ENNReal.ofReal ((rootBirthSum next - rootBirthSum cur) * A_n * P_suf_val)) =
              expVal stepF (fun _ =>
                (cur.totalRebuildWork : ENNReal) +
                  ENNReal.ofReal ((S_trig.card : ℝ) * A_n * P_suf_val)) := by
          refine expVal_congr stepF fun bs next hnext => ?_
          dsimp only [stepF] at hnext
          rw [hstep_eq bs] at hnext
          cases hsuf : runSyncSuffixBuild ctor L_leaf cur.history ltCoords' S_trig bs with
          | none => simp [hsuf] at hnext
          | some sufOut =>
              simp only [hsuf, Option.map_some, Option.some.injEq] at hnext
              rw [← hnext]
              simp [rootBirthSum, List.map_append, List.sum_append]
        rw [hcongr_rhs, expVal_const, hhalt_step', one_mul]
      dsimp only [stepF] at hLHS hRHS
      rw [hLHS, hRHS]
      exact add_le_add le_rfl hexp_suf
  · -- NON-TRIGGERED BRANCH
    let ans := ansPol.checkedAnswer P' updatedNodes
    let entry : StepHistoryEntry d :=
      { operation := op
        randomBits := []
        returnedHandle := retHandle
        answer := ans
        resolvedIds := resolveAnswerIdentities P' ans }
    let next₀ : SyncSchedulePrefixState d NodeAux :=
      { pointSet := P'
        ltCoords := ltCoords'
        nodes := updatedNodes
        leafBirthPool := cur.leafBirthPool
        leafAgeUpdateSteps := leafAge'
        history := cur.history ++ [entry]
        snapshots := cur.snapshots ++ [(P', ans)]
        triggeredSuffixes := cur.triggeredSuffixes
        chainSlotCounts := cur.chainSlotCounts ++ [k + 1]
        totalRebuildWork := cur.totalRebuildWork }
    have hstep_eq :
        runSingleSyncScheduleStep L_leaf α ctor ansPol cur op = haltAtEmpty next₀ := by
      ext bs
      cases op <;>
        (have hTrig0 := hTrig
         unfold runSingleSyncScheduleStep haltAtEmpty
         dsimp only [retHandle, stepRetHandle] at happly
         dsimp only [k, slotTriggers, u, S_new, S_old, ltCoords', stepLtCoords,
           vecNodes, oldAct, newAct] at hTrig0
         dsimp only
         rw [happly]
         dsimp only
         rw [dif_neg hTrig0]
         rfl)
    have hhalt_step : syncSingleStepHaltProb L_leaf α ctor ansPol cur op = 1 := by
      unfold syncSingleStepHaltProb
      change haltProb (runSingleSyncScheduleStep L_leaf α ctor ansPol cur op) = 1
      rw [hstep_eq]
      exact haltProb_haltAtEmpty next₀
    refine ⟨hhalt_step, ?_, ?_⟩
    · intro bs next hnext
      rw [hstep_eq] at hnext
      unfold haltAtEmpty at hnext
      split_ifs at hnext with hbs
      injection hnext with hEq
      subst hEq
      have hupd_len : updatedNodes.length = k := by
        dsimp only [updatedNodes]
        rw [List.length_ofFn, hk_def]
      have hupd_len_succ : updatedNodes.length + 1 = k + 1 := congrArg (· + 1) hupd_len
      have hvec_upd_eq :
          ∀ j : Fin (updatedNodes.length + 1),
            chainInput ltCoords' (fun i : Fin updatedNodes.length => (updatedNodes.get i).built.node) newAct j =
              S_new (j.cast hupd_len_succ) := by
        intro j
        induction j using Fin.induction with
        | zero => rfl
        | succ i ih =>
            have hcs : (i.succ).cast hupd_len_succ = (i.cast hupd_len).succ := by ext; rfl
            have hcs2 : (i.cast hupd_len).castSucc = (i.castSucc).cast hupd_len_succ := by ext; rfl
            rw [hcs]
            dsimp only [S_new] at ih ⊢
            rw [chainInput_succ, chainInput_succ, hcs2, ih]
            dsimp only [updatedNodes, vecNodes]
            simp [List.get_eq_getElem]
      refine ⟨?_, by simp [next₀], le_rfl⟩
      refine ⟨hwf', hact', ?_, hleaf_card, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · intro i
        have hi_k : i.val < k := hupd_len ▸ i.isLt
        have hv_upd :
            updatedNodes.get i =
              let v := cur.nodes.get ⟨i.val, hi_k⟩
              { v with ageUpdateSteps :=
                  if S_new ⟨i.val, Nat.lt_succ_of_lt hi_k⟩ ≠ S_old ⟨i.val, Nat.lt_succ_of_lt hi_k⟩ then
                    insert u v.ageUpdateSteps
                  else
                    v.ageUpdateSteps } := by
          simp [updatedNodes]
        dsimp only [next₀]
        rw [hv_upd]
        rcases hnodes ⟨i.val, hi_k⟩ with ⟨hbp_lt, hbp_1, hV_i, hcp_i, _, _, _⟩
        have hbp_lt' :
            ∀ lt ∈ (cur.nodes.get ⟨i.val, hi_k⟩).birthPool,
              lt < P'.nextLifetime ∧ ltCoords' lt ∈ admissiblePts := by
          intro lt hlt
          rcases hbp_lt lt hlt with ⟨h1, h2⟩
          refine ⟨Nat.lt_of_lt_of_le h1 hnextLt_le, ?_⟩
          have hlt_eq : ltCoords' lt = cur.ltCoords lt := hltCoords_eq lt h1
          rw [hlt_eq]
          exact h2
        have hcp_i' :
            IsCenterpoint α
              (paraboloidLiftSet (fun j : (cur.nodes.get ⟨i.val, hi_k⟩).birthPool => ltCoords' j.1))
              (liftedPoint (cur.nodes.get ⟨i.val, hi_k⟩).built.node.o
                (cur.nodes.get ⟨i.val, hi_k⟩).built.s) := by
          have hfn_eq :
              (fun j : (cur.nodes.get ⟨i.val, hi_k⟩).birthPool => ltCoords' j.1) =
                (fun j : (cur.nodes.get ⟨i.val, hi_k⟩).birthPool => cur.ltCoords j.1) :=
            funext fun j => hltCoords_eq j.1 (hbp_lt j.1 j.2).1
          rw [hfn_eq]
          exact hcp_i
        have hci_eq :
            chainInput ltCoords' (fun q : Fin updatedNodes.length => (updatedNodes.get q).built.node)
              newAct i.castSucc = S_new ⟨i.val, Nat.lt_succ_of_lt hi_k⟩ := by
          rw [hvec_upd_eq i.castSucc]
          rfl
        rw [hci_eq]
        have hupd_i := hupd_age ⟨i.val, hi_k⟩
        dsimp only at hupd_i
        have hnot_trig : ¬ slotTriggers i.val := by
          intro hst_i
          exact hTrig ⟨i.val, Nat.le_of_lt hi_k, hst_i⟩
        dsimp only [slotTriggers] at hnot_trig
        rw [dif_pos hi_k] at hnot_trig
        refine ⟨hbp_lt', hbp_1, hV_i, hcp_i', hupd_i.1, le_of_not_gt hnot_trig, ?_⟩
        intro x hx
        simpa using hupd_i.2.1 x hx
      · dsimp only [next₀]
        rw [hvec_upd_eq (Fin.last updatedNodes.length)]
        have hcast_last :
            (Fin.last updatedNodes.length).cast hupd_len_succ = Fin.last k := by
          ext; exact hupd_len
        rw [hcast_last]
        exact hleaf_upd_age.1
      · intro x hx
        simpa [next₀] using hleaf_upd_age.2.1 x hx
      · intro snap hsnap
        rcases List.mem_append.mp hsnap with h_old | h_new
        · exact hsnaps snap h_old
        · simp only [List.mem_singleton] at h_new
          subst h_new
          exact hans.2 P' updatedNodes hwf'
      · intro rec hrec
        rcases hrecs rec hrec with ⟨h1, h2, h3, h4⟩
        refine ⟨h1, h2, ?_, h4⟩
        simp [next₀]; omega
      · simp [next₀, hslot_len]
      · intro u₀ hu₀
        simp only [next₀, List.length_append, List.length_singleton] at hu₀
        rcases Nat.lt_succ_iff_lt_or_eq.mp hu₀ with hu_lt | rfl
        · rw [getD_append_singleton_lt _ _ _ (hslot_len ▸ hu_lt)]
          exact hslot_bound u₀ hu_lt
        · rw [← hslot_len, getD_append_singleton_eq]
          exact hk_slot_bound
      · intro u₀
        dsimp only [next₀, pastChargedCount, liveCount]
        simp only [List.length_append, List.length_singleton]
        by_cases hu_eq : u₀ = u
        · subst hu_eq
          have hlt_succ : u < cur.history.length + 1 := Nat.lt_succ_self u
          have hp0 : (cur.triggeredSuffixes.filter (fun rec => decide (u ∈ rec.chargedUpdateSteps))).length = 0 :=
            hpot_u_zero
          rw [if_pos hlt_succ, hp0, Nat.zero_add, hu_def, ← hslot_len, getD_append_singleton_eq]
          have hfilt_le :
              (updatedNodes.filter (fun v => decide (cur.chainSlotCounts.length ∈ v.ageUpdateSteps))).length ≤ k :=
            (List.length_filter_le _ _).trans (le_of_eq hupd_len)
          by_cases hul : cur.chainSlotCounts.length ∈ leafAge'
          · rw [if_pos hul]; omega
          · rw [if_neg hul]; omega
        · have hfilt_eq :
              (updatedNodes.filter (fun v => decide (u₀ ∈ v.ageUpdateSteps))).length =
                (cur.nodes.filter (fun v => decide (u₀ ∈ v.ageUpdateSteps))).length :=
            filter_length_eq_of_map_eq (hmap_upd_ne hu_eq)
          have hleaf_iff : u₀ ∈ leafAge' ↔ u₀ ∈ cur.leafAgeUpdateSteps := by
            dsimp only [leafAge']
            by_cases hc : S_new (Fin.last k) ≠ S_old (Fin.last k) <;> simp [hc, hu_eq]
          have hlive_same :
              (updatedNodes.filter (fun v => decide (u₀ ∈ v.ageUpdateSteps))).length +
                  (if u₀ ∈ leafAge' then 1 else 0) = liveCount cur u₀ := by
            unfold liveCount
            rw [hfilt_eq]
            by_cases hm : u₀ ∈ cur.leafAgeUpdateSteps
            · simp [hm, hleaf_iff.mpr hm]
            · have hm' : u₀ ∉ leafAge' := fun h0 => hm (hleaf_iff.mp h0)
              simp [hm, hm']
          rw [hlive_same]
          have hpot_cur := hpot u₀
          unfold pastChargedCount at hpot_cur
          have hiff_lt : u₀ < cur.history.length + 1 ↔ u₀ < cur.history.length := by omega
          by_cases hlt_u : u₀ < cur.history.length
          · rw [if_pos (hiff_lt.mpr hlt_u),
              getD_append_singleton_lt _ _ _ (hslot_len ▸ hlt_u)]
            rwa [if_pos hlt_u] at hpot_cur
          · rw [if_neg (fun h0 => hlt_u (hiff_lt.mp h0))]
            rwa [if_neg hlt_u] at hpot_cur
    · rw [hstep_eq, expVal_haltAtEmpty, expVal_haltAtEmpty]
      have hrb : rootBirthSum next₀ = rootBirthSum cur := rfl
      simp [next₀, hrb]

/-! ### 5. Multi-step induction and prefix expectation bound -/

lemma runSyncScheduleStepsFrom_append {d : ℕ} {NodeAux : Type}
    (L_leaf : ℕ) (α : ℝ)
    (ctor : SyncCertifiedNodeConstructor d NodeAux)
    (ansPol : SyncCheckedAnswerPolicy d NodeAux)
    (adv : AdaptiveAdversary d)
    (cur : SyncSchedulePrefixState d NodeAux)
    (xs : List (List Bool)) (bs : List Bool) :
    runSyncScheduleStepsFrom L_leaf α ctor ansPol adv cur (xs ++ [bs]) =
      match runSyncScheduleStepsFrom L_leaf α ctor ansPol adv cur xs with
      | none => none
      | some mid => runSingleSyncScheduleStep L_leaf α ctor ansPol mid (adv mid.history) bs := by
  induction xs generalizing cur with
  | nil =>
      simp only [List.nil_append, runSyncScheduleStepsFrom]
      cases runSingleSyncScheduleStep L_leaf α ctor ansPol cur (adv cur.history) bs <;> rfl
  | cons x xs ih =>
      simp only [List.cons_append, runSyncScheduleStepsFrom]
      cases runSingleSyncScheduleStep L_leaf α ctor ansPol cur (adv cur.history) x with
      | none => rfl
      | some nxt => exact ih nxt

theorem runSyncScheduleSteps_invariant
    {d n L_leaf : ℕ} {NodeAux : Type}
    {c₁ C_nodes : ℝ} (hc₁_pos : 0 < c₁) (hCn_pos : 0 < C_nodes)
    (h51 : ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2)))
    (hn : 2 ≤ n)
    {α c A_n P_α_d P_node_val : ℝ}
    (hα_pos : 0 < α) (hα_le1 : α ≤ 1)
    (hPα_ge1 : 1 ≤ P_α_d) (hbound_α : 1 / P_α_d ≤ α)
    (hA_nn : 0 ≤ A_n) (hPn_nn : 0 ≤ P_node_val)
    {admissiblePts : Set (EuclideanSpace ℝ (Fin d))}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    {ansPol : SyncCheckedAnswerPolicy d NodeAux}
    (hctor : IsValidSyncNodeConstructor n L_leaf α A_n P_node_val admissiblePts ctor)
    (hans : IsValidSyncCheckedAnswerPolicy n c ansPol)
    {adv : AdaptiveAdversary d}
    (hadv : IsValidSyncAdaptiveAdversary n L_leaf α admissiblePts ctor ansPol adv) :
    ∀ (bitTrace : List (List Bool)) (prefSt : SyncSchedulePrefixState d NodeAux),
      runSyncScheduleSteps L_leaf α ctor ansPol adv bitTrace = some prefSt →
        SyncStateInv n L_leaf (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) α c admissiblePts prefSt ∧
        prefSt.history.length = bitTrace.length ∧
        syncSingleStepHaltProb L_leaf α ctor ansPol prefSt (adv prefSt.history) = 1 := by
  intro bitTrace
  induction bitTrace using List.reverseRecOn with
  | nil =>
      intro prefSt hrun
      simp only [runSyncScheduleSteps, runSyncScheduleStepsFrom] at hrun
      injection hrun with hEq
      subst hEq
      have hinv0 : SyncStateInv n L_leaf (1 / 17) (max 1 (1 / c₁)) (C_nodes + 1) α c admissiblePts
          (initSyncSchedulePrefixState d NodeAux) := syncStateInv_init
      have hleg0 : IsLegalUpdate n admissiblePts (initSyncSchedulePrefixState d NodeAux).pointSet
          (adv (initSyncSchedulePrefixState d NodeAux).history) :=
        hadv [] _ rfl
      have hst0 := runSingleSyncScheduleStep_props hc₁_pos hCn_pos h51 hn hα_pos hα_le1
        hPα_ge1 hbound_α hA_nn hPn_nn hctor hans hinv0 hleg0
      exact ⟨hinv0, rfl, hst0.1⟩
  | append_singleton xs bs ih =>
      intro prefSt hrun
      have hrun' := hrun
      unfold runSyncScheduleSteps at hrun'
      rw [runSyncScheduleStepsFrom_append] at hrun'
      cases hmid : runSyncScheduleStepsFrom L_leaf α ctor ansPol adv
          (initSyncSchedulePrefixState d NodeAux) xs with
      | none => simp [hmid] at hrun'
      | some mid =>
          simp only [hmid] at hrun'
          rcases ih mid hmid with ⟨hinv_mid, hlen_mid, _⟩
          have hleg_mid : IsLegalUpdate n admissiblePts mid.pointSet (adv mid.history) :=
            hadv xs mid hmid
          have hst_mid := runSingleSyncScheduleStep_props hc₁_pos hCn_pos h51 hn hα_pos hα_le1
            hPα_ge1 hbound_α hA_nn hPn_nn hctor hans hinv_mid hleg_mid
          rcases hst_mid.2.1 bs prefSt hrun' with ⟨hinv_next, hlen_next, _⟩
          have hleg_next : IsLegalUpdate n admissiblePts prefSt.pointSet (adv prefSt.history) :=
            hadv (xs ++ [bs]) prefSt hrun
          have hst_next := runSingleSyncScheduleStep_props hc₁_pos hCn_pos h51 hn hα_pos hα_le1
            hPα_ge1 hbound_α hA_nn hPn_nn hctor hans hinv_next hleg_next
          refine ⟨hinv_next, ?_, hst_next.1⟩
          simp [hlen_next, hlen_mid]

/-- Forward induction over `s` steps for prefix halting probability and expected rebuild work. -/
theorem syncPrefix_prob_and_work
    {d n L_leaf : ℕ} {NodeAux : Type}
    {c₁ C_nodes : ℝ} (hc₁_pos : 0 < c₁) (hCn_pos : 0 < C_nodes)
    (h51 : ∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ), 0 < α → α ≤ 1 →
      (∀ (P₀ S : Finset ι), 1 ≤ P₀.card →
        ∀ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
          IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
          ∀ (age : ℕ), HasNodeAge P₀ S age →
            (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
            let V := liftVariance o s
            let C := nodeCore pts o V S
            let child := nodeResidual pts o V S
            let m : ℝ := P₀.card
            15 * α * m / 16 ≤ ((P₀ ∩ C).card : ℝ) ∧
            (S.card : ℝ) ≤ (1 + α / 16) * m ∧
            (child.card : ℝ) ≤ (1 - c₁ * α) * (S.card : ℝ)) ∧
      (∀ (n : ℕ) (P : Finset ι), P.card ≤ n →
        (∀ (k : ℕ) (nodes : Fin k → ChainNode d)
            (P₀ : Fin k → Finset ι)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ)
            (age : Fin k → ℕ),
          (∀ i : Fin k,
            (nodes i).o = o i ∧
            (nodes i).V = liftVariance (o i) (s i) ∧
            1 ≤ (P₀ i).card ∧
            IsCenterpoint α (paraboloidLiftSet (fun j : P₀ i => pts j.1)) (liftedPoint (o i) (s i)) ∧
            HasNodeAge (P₀ i) (chainInput pts nodes P i.castSucc) (age i) ∧
            (age i : ℝ) ≤ α * ((P₀ i).card : ℝ) / 16) →
          (∀ j : Fin (k + 1),
            ((chainInput pts nodes P j).card : ℝ) ≤ (1 - c₁ * α) ^ (j : ℕ) * (P.card : ℝ)) ∧
          ((chainTerminal pts nodes P).card : ℝ) ≤ (1 - c₁ * α) ^ k * (P.card : ℝ) ∧
          (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1)) ∧
        (∀ (L_leaf : ℕ),
          (∀ S : Finset ι, S ⊆ P → L_leaf < S.card →
            ∃ (o : EuclideanSpace ℝ (Fin d)) (s : ℝ),
              IsCenterpoint α (paraboloidLiftSet (fun j : S => pts j.1)) (liftedPoint o s)) →
          ∃ (k : ℕ) (nodes : Fin k → ChainNode d)
            (o : Fin k → EuclideanSpace ℝ (Fin d)) (s : Fin k → ℝ),
            (k : ℝ) ≤ C_nodes * α⁻¹ * Real.log ((n : ℝ) + 1) ∧
            (∀ i : Fin k,
              L_leaf < (chainInput pts nodes P i.castSucc).card ∧
              (nodes i).o = o i ∧
              (nodes i).V = liftVariance (o i) (s i) ∧
              IsCenterpoint α
                (paraboloidLiftSet (fun j : chainInput pts nodes P i.castSucc => pts j.1))
                (liftedPoint (o i) (s i))) ∧
            (chainTerminal pts nodes P).card ≤ L_leaf ∧
            (chainTerminal pts nodes P ×ˢ chainTerminal pts nodes P).card ≤ L_leaf ^ 2)))
    (hn : 2 ≤ n)
    {α c A_n P_α_d P_node_val : ℝ}
    (hα_pos : 0 < α) (hα_le1 : α ≤ 1)
    (hPα_ge1 : 1 ≤ P_α_d) (hbound_α : 1 / P_α_d ≤ α)
    (hA_nn : 0 ≤ A_n) (hPn_nn : 0 ≤ P_node_val)
    {admissiblePts : Set (EuclideanSpace ℝ (Fin d))}
    {ctor : SyncCertifiedNodeConstructor d NodeAux}
    {ansPol : SyncCheckedAnswerPolicy d NodeAux}
    (hctor : IsValidSyncNodeConstructor n L_leaf α A_n P_node_val admissiblePts ctor)
    (hans : IsValidSyncCheckedAnswerPolicy n c ansPol)
    {adv : AdaptiveAdversary d}
    (hadv : IsValidSyncAdaptiveAdversary n L_leaf α admissiblePts ctor ansPol adv) :
    let P_suf_val : ℝ := (1 / c₁) * P_α_d * P_node_val
    ∀ s : ℕ,
      (∑' tr : Fin s → List Bool,
        if (runSyncSchedulePrefix L_leaf α ctor ansPol adv s tr).isSome then
          prefixTraceProb tr
        else
          0) = 1 ∧
      syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv s ≤
        ∑' tr : Fin s → List Bool,
          Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv s tr) 0
            (fun out => prefixTraceProb tr * ENNReal.ofReal (rootBirthSum out * A_n * P_suf_val)) := by
  dsimp only
  let P_suf_val : ℝ := (1 / c₁) * P_α_d * P_node_val
  have hPsuf_nn : 0 ≤ P_suf_val := by
    have : 0 ≤ P_α_d := by linarith
    dsimp only [P_suf_val]
    positivity
  have hwork_elim :
      ∀ u : ℕ,
        syncPrefixExpectedRebuildWork L_leaf α ctor ansPol adv u =
          ∑' tr : Fin u → List Bool,
            Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv u tr) 0
              (fun out => prefixTraceProb tr * (out.totalRebuildWork : ENNReal)) := by
    intro u
    unfold syncPrefixExpectedRebuildWork
    congr 1
    ext tr
    cases runSyncSchedulePrefix L_leaf α ctor ansPol adv u tr <;> rfl
  intro s
  induction s with
  | zero =>
      have huniq : Unique (Fin 0 → List Bool) := inferInstance
      constructor
      · rw [tsum_fintype]
        simp [Finset.univ_unique, runSyncSchedulePrefix, runSyncScheduleSteps,
          runSyncScheduleStepsFrom, prefixTraceProb]
      · rw [hwork_elim 0, tsum_fintype, tsum_fintype]
        simp [Finset.univ_unique, runSyncSchedulePrefix, runSyncScheduleSteps,
          runSyncScheduleStepsFrom, initSyncSchedulePrefixState, prefixTraceProb, rootBirthSum]
  | succ s ih =>
      rcases ih with ⟨ih_prob, ih_work⟩
      rw [hwork_elim s] at ih_work
      have hstep_snoc :
          ∀ (init : Fin s → List Bool) (bs : List Bool),
            runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs) =
              Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv s init) none
                (fun mid => runSingleSyncScheduleStep L_leaf α ctor ansPol mid (adv mid.history) bs) := by
        intro init bs
        unfold runSyncSchedulePrefix runSyncScheduleSteps
        rw [ofFn_snocTrace, runSyncScheduleStepsFrom_append]
        cases runSyncScheduleStepsFrom L_leaf α ctor ansPol adv
          (initSyncSchedulePrefixState d NodeAux) (List.ofFn init) <;> rfl
      constructor
      · rw [tsum_fin_succ_trace]
        have hinner :
            ∀ init : Fin s → List Bool,
              (∑' bs : List Bool,
                if (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs)).isSome then
                  prefixTraceProb (Fin.snoc init bs)
                else
                  0) =
              if (runSyncSchedulePrefix L_leaf α ctor ansPol adv s init).isSome then
                prefixTraceProb init
              else
                0 := by
          intro init
          cases hmid : runSyncSchedulePrefix L_leaf α ctor ansPol adv s init with
          | none =>
              have hz :
                  (fun bs : List Bool =>
                    if (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs)).isSome then
                      prefixTraceProb (Fin.snoc init bs)
                    else (0 : ENNReal)) = fun _ => 0 := by
                ext bs
                rw [hstep_snoc, hmid]
                rfl
              rw [hz, tsum_zero]
              simp
          | some mid =>
              have hinv_all := runSyncScheduleSteps_invariant hc₁_pos hCn_pos h51 hn hα_pos hα_le1
                hPα_ge1 hbound_α hA_nn hPn_nn hctor hans hadv (List.ofFn init) mid hmid
              have hcongr :
                  (fun bs : List Bool =>
                    if (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs)).isSome then
                      prefixTraceProb (Fin.snoc init bs)
                    else (0 : ENNReal)) =
                  (fun bs : List Bool =>
                    prefixTraceProb init *
                      if (runSingleSyncScheduleStep L_leaf α ctor ansPol mid (adv mid.history) bs).isSome then
                        bitListProb bs
                      else 0) := by
                ext bs
                rw [hstep_snoc, hmid, prefixTraceProb_snoc]
                dsimp only [Option.elim_some]
                split_ifs <;> simp
              rw [hcongr, ENNReal.tsum_mul_left]
              change prefixTraceProb init *
                  syncSingleStepHaltProb L_leaf α ctor ansPol mid (adv mid.history) = _
              rw [hinv_all.2.2, mul_one]
              simp
        simp_rw [hinner]
        exact ih_prob
      · rw [hwork_elim (s + 1), tsum_fin_succ_trace, tsum_fin_succ_trace]
        -- Step 1: bound inner sum over `bs` for each `init`
        have hinner_work :
            ∀ init : Fin s → List Bool,
              (∑' bs : List Bool,
                Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs)) 0
                  (fun out => prefixTraceProb (Fin.snoc init bs) * (out.totalRebuildWork : ENNReal))) ≤
              Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv s init) 0
                (fun mid => prefixTraceProb init * (mid.totalRebuildWork : ENNReal)) +
              (∑' bs : List Bool,
                Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs)) 0
                  (fun out =>
                    Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv s init) 0
                      (fun mid =>
                        prefixTraceProb (Fin.snoc init bs) *
                          ENNReal.ofReal ((rootBirthSum out - rootBirthSum mid) * A_n * P_suf_val)))) := by
          intro init
          cases hmid : runSyncSchedulePrefix L_leaf α ctor ansPol adv s init with
          | none =>
              have hz1 :
                  (fun bs : List Bool =>
                    Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs)) 0
                      (fun out => prefixTraceProb (Fin.snoc init bs) * (out.totalRebuildWork : ENNReal))) =
                    fun _ => 0 := by
                ext bs; rw [hstep_snoc, hmid]; rfl
              rw [hz1, tsum_zero]
              exact zero_le _
          | some mid =>
              simp only [Option.elim_some]
              have hinv_mid := runSyncScheduleSteps_invariant hc₁_pos hCn_pos h51 hn hα_pos hα_le1
                hPα_ge1 hbound_α hA_nn hPn_nn hctor hans hadv (List.ofFn init) mid hmid
              have hleg_mid : IsLegalUpdate n admissiblePts mid.pointSet (adv mid.history) :=
                hadv (List.ofFn init) mid hmid
              have hst := runSingleSyncScheduleStep_props hc₁_pos hCn_pos h51 hn hα_pos hα_le1
                hPα_ge1 hbound_α hA_nn hPn_nn hctor hans hinv_mid.1 hleg_mid
              let stepF := runSingleSyncScheduleStep L_leaf α ctor ansPol mid (adv mid.history)
              have hhalt_mid : haltProb stepF = 1 := hst.1
              have hlhs_eq :
                  (∑' bs : List Bool,
                    Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs)) 0
                      (fun out => prefixTraceProb (Fin.snoc init bs) * (out.totalRebuildWork : ENNReal))) =
                  prefixTraceProb init * expVal stepF (fun out => (out.totalRebuildWork : ENNReal)) := by
                unfold expVal
                rw [← ENNReal.tsum_mul_left]
                congr 1
                ext bs
                rw [hstep_snoc, hmid, prefixTraceProb_snoc]
                dsimp only [stepF, Option.elim_some]
                cases runSingleSyncScheduleStep L_leaf α ctor ansPol mid (adv mid.history) bs <;>
                  simp [mul_assoc]
              have hrhs_eq :
                  prefixTraceProb init * (mid.totalRebuildWork : ENNReal) +
                  (∑' bs : List Bool,
                    Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs)) 0
                      (fun out =>
                        prefixTraceProb (Fin.snoc init bs) *
                          ENNReal.ofReal ((rootBirthSum out - rootBirthSum mid) * A_n * P_suf_val))) =
                  prefixTraceProb init *
                    expVal stepF (fun out =>
                      (mid.totalRebuildWork : ENNReal) +
                        ENNReal.ofReal ((rootBirthSum out - rootBirthSum mid) * A_n * P_suf_val)) := by
                rw [expVal_add, expVal_const, hhalt_mid, one_mul, mul_add]
                congr 1
                unfold expVal
                rw [← ENNReal.tsum_mul_left]
                congr 1
                ext bs
                rw [hstep_snoc, hmid, prefixTraceProb_snoc]
                dsimp only [stepF, Option.elim_some]
                cases runSingleSyncScheduleStep L_leaf α ctor ansPol mid (adv mid.history) bs <;>
                  simp [mul_assoc]
              rw [hlhs_eq, hrhs_eq]
              exact mul_le_mul_of_nonneg_left hst.2.2 (zero_le _)
        -- Sum `hinner_work` over `init` and combine with `ih_work`
        have hsum1 := ENNReal.tsum_le_tsum hinner_work
        rw [ENNReal.tsum_add] at hsum1
        refine hsum1.trans (le_trans (add_le_add ih_work le_rfl) ?_)
        rw [← ENNReal.tsum_add]
        refine ENNReal.tsum_le_tsum fun init => ?_
        cases hmid : runSyncSchedulePrefix L_leaf α ctor ansPol adv s init with
        | none =>
            have hz2 :
                (fun bs : List Bool =>
                  Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs)) 0
                    (fun out =>
                      Option.elim (none : Option (SyncSchedulePrefixState d NodeAux)) (0 : ENNReal)
                        (fun mid =>
                          prefixTraceProb (Fin.snoc init bs) *
                            ENNReal.ofReal ((rootBirthSum out - rootBirthSum mid) * A_n * P_suf_val)))) =
                  fun _ => 0 := by
              ext bs; cases runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs) <;> rfl
            rw [hz2, tsum_zero]
            simp
        | some mid =>
            simp only [Option.elim_some]
            have hinv_mid := runSyncScheduleSteps_invariant hc₁_pos hCn_pos h51 hn hα_pos hα_le1
              hPα_ge1 hbound_α hA_nn hPn_nn hctor hans hadv (List.ofFn init) mid hmid
            have hleg_mid : IsLegalUpdate n admissiblePts mid.pointSet (adv mid.history) :=
              hadv (List.ofFn init) mid hmid
            have hst := runSingleSyncScheduleStep_props hc₁_pos hCn_pos h51 hn hα_pos hα_le1
              hPα_ge1 hbound_α hA_nn hPn_nn hctor hans hinv_mid.1 hleg_mid
            let stepF := runSingleSyncScheduleStep L_leaf α ctor ansPol mid (adv mid.history)
            have hhalt_mid : haltProb stepF = 1 := hst.1
            have hbase_expand :
                prefixTraceProb init * ENNReal.ofReal (rootBirthSum mid * A_n * P_suf_val) =
                  ∑' bs : List Bool,
                    Option.elim (runSyncSchedulePrefix L_leaf α ctor ansPol adv (s + 1) (Fin.snoc init bs))
                      (0 : ENNReal)
                      (fun _ =>
                        prefixTraceProb (Fin.snoc init bs) *
                          ENNReal.ofReal (rootBirthSum mid * A_n * P_suf_val)) := by
              have hc := expVal_const stepF (ENNReal.ofReal (rootBirthSum mid * A_n * P_suf_val))
              rw [hhalt_mid, one_mul] at hc
              conv_lhs => rw [← hc]
              unfold expVal
              rw [← ENNReal.tsum_mul_left]
              congr 1
              ext bs
              rw [hstep_snoc, hmid]
              simp only [Option.elim_some]
              dsimp only [stepF]
              cases runSingleSyncScheduleStep L_leaf α ctor ansPol mid (adv mid.history) bs with
              | none => simp
              | some val =>
                  simp only [Option.elim_some, prefixTraceProb_snoc, mul_assoc]
            rw [hbase_expand, ← ENNReal.tsum_add]
            refine ENNReal.tsum_le_tsum fun bs => ?_
            rw [hstep_snoc, hmid]
            dsimp only [Option.elim_some]
            cases hout_bs : runSingleSyncScheduleStep L_leaf α ctor ansPol mid (adv mid.history) bs with
            | none => simp
            | some out =>
                simp only [Option.elim_some]
                rw [← mul_add]
                refine mul_le_mul_of_nonneg_left ?_ (zero_le _)
                have hrb_mid_nn : 0 ≤ rootBirthSum mid * A_n * P_suf_val := by
                  have := rootBirthSum_nonneg mid
                  positivity
                have hrb_le : rootBirthSum mid ≤ rootBirthSum out :=
                  (hst.2.1 bs out hout_bs).2.2
                have hrb_diff_nn : 0 ≤ (rootBirthSum out - rootBirthSum mid) * A_n * P_suf_val := by
                  have : 0 ≤ rootBirthSum out - rootBirthSum mid := sub_nonneg.mpr hrb_le
                  positivity
                rw [← ENNReal.ofReal_add hrb_mid_nn hrb_diff_nn]
                have hring :
                    rootBirthSum mid * A_n * P_suf_val +
                      (rootBirthSum out - rootBirthSum mid) * A_n * P_suf_val =
                    rootBirthSum out * A_n * P_suf_val := by ring
                rw [hring]

end UL.Proof_claim_C_3_sync_suffix_v31
