import Mathlib
import UL.Stmt.claim_C_3_sync_suffix
set_option autoImplicit false

namespace UL.Proof_claim_C_3_sync_suffix_v31

open scoped ENNReal

/-! ### 1. Prefix-free randomized computations on `List Bool` -/

def IsPrefixFree {α : Type*} (f : List Bool → Option α) : Prop :=
  ∀ bs₁ bs₂ : List Bool, ∀ a₁ a₂ : α,
    f bs₁ = some a₁ → f bs₂ = some a₂ → bs₁ <+: bs₂ → bs₁ = bs₂

noncomputable def haltProb {α : Type*} (f : List Bool → Option α) : ENNReal :=
  ∑' bs : List Bool, if (f bs).isSome then bitListProb bs else 0

noncomputable def expVal {α : Type*} (f : List Bool → Option α) (Φ : α → ENNReal) : ENNReal :=
  ∑' bs : List Bool, match f bs with
    | some a => bitListProb bs * Φ a
    | none => 0

lemma bitListProb_nil : bitListProb [] = 1 := by
  simp [bitListProb]

lemma bitListProb_append (bs₁ bs₂ : List Bool) :
    bitListProb (bs₁ ++ bs₂) = bitListProb bs₁ * bitListProb bs₂ := by
  simp [bitListProb, pow_add]

lemma haltProb_eq_expVal_one {α : Type*} (f : List Bool → Option α) :
    haltProb f = expVal f (fun _ => 1) := by
  unfold haltProb expVal
  congr 1
  ext bs
  cases f bs <;> simp

lemma expVal_mono {α : Type*} (f : List Bool → Option α) {Φ Ψ : α → ENNReal}
    (h : ∀ bs a, f bs = some a → Φ a ≤ Ψ a) :
    expVal f Φ ≤ expVal f Ψ := by
  unfold expVal
  refine ENNReal.tsum_le_tsum fun bs => ?_
  cases hfb : f bs with
  | none => exact le_rfl
  | some a => exact mul_le_mul_of_nonneg_left (h bs a hfb) (zero_le _)

lemma expVal_congr {α : Type*} (f : List Bool → Option α) {Φ Ψ : α → ENNReal}
    (h : ∀ bs a, f bs = some a → Φ a = Ψ a) :
    expVal f Φ = expVal f Ψ :=
  le_antisymm (expVal_mono f fun bs a hfb => (h bs a hfb).le)
    (expVal_mono f fun bs a hfb => (h bs a hfb).ge)

lemma expVal_add {α : Type*} (f : List Bool → Option α) (Φ Ψ : α → ENNReal) :
    expVal f (fun a => Φ a + Ψ a) = expVal f Φ + expVal f Ψ := by
  unfold expVal
  rw [← ENNReal.tsum_add]
  congr 1
  ext bs
  cases f bs with
  | none => simp
  | some a => simp [mul_add]

lemma expVal_const {α : Type*} (f : List Bool → Option α) (c : ENNReal) :
    expVal f (fun _ => c) = haltProb f * c := by
  rw [haltProb_eq_expVal_one]
  unfold expVal
  rw [← ENNReal.tsum_mul_right]
  congr 1
  ext bs
  cases f bs <;> simp

lemma prefixFree_split_unique {α : Type*} {f : List Bool → Option α} (hf : IsPrefixFree f)
    {bs₁ bs₂ cs₁ cs₂ : List Bool} {a₁ a₂ : α}
    (heq : bs₁ ++ bs₂ = cs₁ ++ cs₂) (h₁ : f bs₁ = some a₁) (h₂ : f cs₁ = some a₂) :
    bs₁ = cs₁ ∧ bs₂ = cs₂ ∧ a₁ = a₂ := by
  have hbs_eq : bs₁ = cs₁ := by
    rcases List.append_eq_append_iff.mp heq with ⟨as, hcs, _⟩ | ⟨as, hbs, _⟩
    · exact hf bs₁ cs₁ a₁ a₂ h₁ h₂ ⟨as, hcs.symm⟩
    · exact (hf cs₁ bs₁ a₂ a₁ h₂ h₁ ⟨as, hbs.symm⟩).symm
  subst hbs_eq
  have hbs₂ : bs₂ = cs₂ := List.append_cancel_left heq
  subst hbs₂
  rw [h₁] at h₂
  injection h₂ with ha
  exact ⟨rfl, rfl, ha⟩

/-- Deterministic halting consuming `[]` bits. -/
def haltAtEmpty {α : Type*} (x : α) (bs : List Bool) : Option α :=
  if bs.isEmpty then some x else none

lemma isPrefixFree_haltAtEmpty {α : Type*} (x : α) : IsPrefixFree (haltAtEmpty x) := by
  intro bs₁ bs₂ a₁ a₂ h₁ h₂ _
  unfold haltAtEmpty at h₁ h₂
  cases bs₁ <;> cases bs₂ <;> simp at h₁ h₂ ⊢

lemma haltProb_haltAtEmpty {α : Type*} (x : α) : haltProb (haltAtEmpty x) = 1 := by
  unfold haltProb haltAtEmpty
  rw [tsum_eq_single ([] : List Bool)]
  · simp [bitListProb_nil]
  · intro bs hbs
    cases bs with
    | nil => exact (hbs rfl).elim
    | cons _ _ => simp

lemma expVal_haltAtEmpty {α : Type*} (x : α) (Φ : α → ENNReal) :
    expVal (haltAtEmpty x) Φ = Φ x := by
  unfold expVal haltAtEmpty
  rw [tsum_eq_single ([] : List Bool)]
  · simp [bitListProb_nil]
  · intro bs hbs
    cases bs with
    | nil => exact (hbs rfl).elim
    | cons _ _ => simp

/-- Sequential bit-list composition passing both the consumed prefix `bs₁` and outcome `out`. -/
noncomputable def seqWithCoins {α β : Type*}
    (f : List Bool → Option α)
    (g : List Bool → α → List Bool → Option β)
    (bs : List Bool) : Option β :=
  open Classical in
  if hStep : ∃ (bs₁ bs₂ : List Bool) (out : α),
      bs = bs₁ ++ bs₂ ∧ f bs₁ = some out then
    let bs₁ := Classical.choose hStep
    let h₂ := Classical.choose_spec hStep
    let bs₂ := Classical.choose h₂
    let h₃ := Classical.choose_spec h₂
    let out := Classical.choose h₃
    g bs₁ out bs₂
  else
    none

lemma seqWithCoins_append_of_prefixFree {α β : Type*} {f : List Bool → Option α}
    (hf : IsPrefixFree f) (g : List Bool → α → List Bool → Option β)
    {bs₁ bs₂ : List Bool} {a : α} (h₁ : f bs₁ = some a) :
    seqWithCoins f g (bs₁ ++ bs₂) = g bs₁ a bs₂ := by
  classical
  unfold seqWithCoins
  have hex : ∃ cs₁ cs₂ out, bs₁ ++ bs₂ = cs₁ ++ cs₂ ∧ f cs₁ = some out :=
    ⟨bs₁, bs₂, a, rfl, h₁⟩
  rw [dif_pos hex]
  let cs₁ := Classical.choose hex
  let h₂ := Classical.choose_spec hex
  let cs₂ := Classical.choose h₂
  let h₃ := Classical.choose_spec h₂
  let out := Classical.choose h₃
  have h₄ := Classical.choose_spec h₃
  rcases prefixFree_split_unique hf h₄.1 h₁ h₄.2 with ⟨hcs₁, hcs₂, hout⟩
  change g cs₁ out cs₂ = g bs₁ a bs₂
  have h12 : g cs₁ out = g bs₁ a := congrArg₂ g hcs₁.symm hout.symm
  exact congrFun h12 cs₂ |>.trans (congrArg (g bs₁ a) hcs₂.symm)

lemma seqWithCoins_eq_some_iff {α β : Type*} {f : List Bool → Option α}
    (hf : IsPrefixFree f) {g : List Bool → α → List Bool → Option β}
    {bs : List Bool} {b : β} :
    seqWithCoins f g bs = some b ↔
      ∃ bs₁ bs₂ a, bs = bs₁ ++ bs₂ ∧ f bs₁ = some a ∧ g bs₁ a bs₂ = some b := by
  classical
  constructor
  · intro hb
    unfold seqWithCoins at hb
    split_ifs at hb with hex
    · dsimp only at hb
      let bs₁ := Classical.choose hex
      let h₂ := Classical.choose_spec hex
      let bs₂ := Classical.choose h₂
      let h₃ := Classical.choose_spec h₂
      let out := Classical.choose h₃
      have h₄ := Classical.choose_spec h₃
      exact ⟨bs₁, bs₂, out, h₄.1, h₄.2, hb⟩
  · rintro ⟨bs₁, bs₂, a, rfl, hfa, hgb⟩
    rwa [seqWithCoins_append_of_prefixFree hf g hfa]

lemma isPrefixFree_seqWithCoins {α β : Type*} {f : List Bool → Option α}
    {g : List Bool → α → List Bool → Option β}
    (hf : IsPrefixFree f)
    (hg : ∀ bs₁ a, f bs₁ = some a → IsPrefixFree (g bs₁ a)) :
    IsPrefixFree (seqWithCoins f g) := by
  intro u v b₁ b₂ hu hv huv
  rcases (seqWithCoins_eq_some_iff hf).mp hu with ⟨bs₁, bs₂, a₁, rfl, hfa₁, hgb₁⟩
  rcases (seqWithCoins_eq_some_iff hf).mp hv with ⟨cs₁, cs₂, a₂, rfl, hfa₂, hgb₂⟩
  rcases huv with ⟨w, hw⟩
  have hw' : bs₁ ++ (bs₂ ++ w) = cs₁ ++ cs₂ := by simpa [List.append_assoc] using hw
  rcases prefixFree_split_unique hf hw' hfa₁ hfa₂ with ⟨rfl, htail, rfl⟩
  have hbs₂_eq : bs₂ = cs₂ := hg bs₁ a₁ hfa₁ bs₂ cs₂ b₁ b₂ hgb₁ hgb₂ ⟨w, htail⟩
  rw [hbs₂_eq]

theorem expVal_seqWithCoins {α β : Type*} {f : List Bool → Option α}
    (hf : IsPrefixFree f)
    (g : List Bool → α → List Bool → Option β) (Φ : β → ENNReal) :
    expVal (seqWithCoins f g) Φ =
      ∑' bs₁ : List Bool,
        match f bs₁ with
        | some a => bitListProb bs₁ * expVal (g bs₁ a) Φ
        | none => 0 := by
  let θ : List Bool → ENNReal := fun bs =>
    match seqWithCoins f g bs with
    | some b => bitListProb bs * Φ b
    | none => 0
  let ψ : List Bool × List Bool → ENNReal := fun p =>
    match f p.1 with
    | some a =>
        match g p.1 a p.2 with
        | some b => bitListProb p.1 * (bitListProb p.2 * Φ b)
        | none => 0
    | none => 0
  have hrhs :
      (∑' bs₁ : List Bool,
        match f bs₁ with
        | some a => bitListProb bs₁ * expVal (g bs₁ a) Φ
        | none => 0) = ∑' p : List Bool × List Bool, ψ p := by
    rw [ENNReal.tsum_prod']
    congr 1
    ext bs₁
    cases hfb : f bs₁ with
    | none =>
        dsimp only
        have : (fun bs₂ : List Bool => ψ (bs₁, bs₂)) = fun _ => 0 := by
          ext bs₂; simp [ψ, hfb]
        rw [this, tsum_zero]
    | some a =>
        dsimp only
        unfold expVal
        rw [← ENNReal.tsum_mul_left]
        congr 1
        ext bs₂
        cases hg : g bs₁ a bs₂ <;> simp [ψ, hfb, hg]
  rw [hrhs]
  change ∑' bs, θ bs = ∑' p, ψ p
  refine tsum_eq_tsum_of_ne_zero_bij (fun p : Function.support ψ => p.1.1 ++ p.1.2) ?_ ?_ ?_
  · rintro ⟨⟨bs₁, bs₂⟩, hp⟩ ⟨⟨cs₁, cs₂⟩, hq⟩ heq
    dsimp at heq
    have hp' : ψ (bs₁, bs₂) ≠ 0 := hp
    have hq' : ψ (cs₁, cs₂) ≠ 0 := hq
    cases hfb : f bs₁ with
    | none => simp [ψ, hfb] at hp'
    | some a₁ =>
        cases hfc : f cs₁ with
        | none => simp [ψ, hfc] at hq'
        | some a₂ =>
            rcases prefixFree_split_unique hf heq hfb hfc with ⟨rfl, rfl, _⟩
            rfl
  · intro bs hbs
    have hbs' : θ bs ≠ 0 := hbs
    cases hbind : seqWithCoins f g bs with
    | none => simp [θ, hbind] at hbs'
    | some b =>
        rcases (seqWithCoins_eq_some_iff hf).mp hbind with ⟨bs₁, bs₂, a, rfl, hfa, hgb⟩
        have hψ_eq : ψ (bs₁, bs₂) = θ (bs₁ ++ bs₂) := by
          simp [ψ, θ, hfa, hgb, hbind, bitListProb_append, mul_assoc]
        refine ⟨⟨(bs₁, bs₂), ?_⟩, rfl⟩
        rw [Function.mem_support, hψ_eq]
        exact hbs'
  · rintro ⟨⟨bs₁, bs₂⟩, hp⟩
    have hp' : ψ (bs₁, bs₂) ≠ 0 := hp
    cases hfa : f bs₁ with
    | none => simp [ψ, hfa] at hp'
    | some a =>
        cases hgb : g bs₁ a bs₂ with
        | none => simp [ψ, hfa, hgb] at hp'
        | some b =>
            have hbind : seqWithCoins f g (bs₁ ++ bs₂) = some b := by
              rw [seqWithCoins_append_of_prefixFree hf g hfa, hgb]
            simp [θ, ψ, hfa, hgb, hbind, bitListProb_append, mul_assoc]

theorem haltProb_seqWithCoins {α β : Type*} {f : List Bool → Option α}
    {g : List Bool → α → List Bool → Option β}
    (hf : IsPrefixFree f) (hf1 : haltProb f = 1)
    (hg1 : ∀ bs₁ a, f bs₁ = some a → haltProb (g bs₁ a) = 1) :
    haltProb (seqWithCoins f g) = 1 := by
  rw [haltProb_eq_expVal_one, expVal_seqWithCoins hf]
  have hcongr :
      (∑' bs₁ : List Bool,
        match f bs₁ with
        | some a => bitListProb bs₁ * expVal (g bs₁ a) (fun _ => 1)
        | none => 0) = haltProb f := by
    unfold haltProb
    congr 1
    ext bs₁
    cases hfa : f bs₁ with
    | none => simp
    | some a =>
        dsimp only
        have h1 : expVal (g bs₁ a) (fun _ => 1) = 1 := by
          rw [← haltProb_eq_expVal_one]
          exact hg1 bs₁ a hfa
        simp [h1]
  rw [hcongr, hf1]

/-! ### 2. `Fin s → List Bool` trace `snoc` equivalence -/

def snocTraceEquiv (s : ℕ) : ((Fin s → List Bool) × List Bool) ≃ (Fin (s + 1) → List Bool) where
  toFun p := Fin.snoc p.1 p.2
  invFun tr := (Fin.init tr, tr (Fin.last s))
  left_inv p := by
    rcases p with ⟨init, bs⟩
    ext i
    · simp [Fin.init, Fin.snoc_castSucc]
    · simp [Fin.snoc_last]
  right_inv tr := by
    ext i
    refine Fin.lastCases ?_ ?_ i
    · simp [Fin.snoc_last]
    · intro j
      simp [Fin.init, Fin.snoc_castSucc]

lemma ofFn_snocTrace {s : ℕ} (init : Fin s → List Bool) (bs : List Bool) :
    List.ofFn (Fin.snoc init bs) = List.ofFn init ++ [bs] := by
  rw [List.ofFn_succ']
  simp [Fin.init, Fin.snoc_castSucc, Fin.snoc_last]

lemma prefixTraceProb_snoc {s : ℕ} (init : Fin s → List Bool) (bs : List Bool) :
    prefixTraceProb (Fin.snoc init bs) = prefixTraceProb init * bitListProb bs := by
  unfold prefixTraceProb
  rw [Fin.prod_univ_castSucc]
  simp [Fin.snoc_castSucc, Fin.snoc_last]

lemma tsum_fin_succ_trace {s : ℕ} (H : (Fin (s + 1) → List Bool) → ENNReal) :
    (∑' tr : Fin (s + 1) → List Bool, H tr) =
      ∑' init : Fin s → List Bool, ∑' bs : List Bool, H (Fin.snoc init bs) := by
  rw [← (snocTraceEquiv s).tsum_eq, ENNReal.tsum_prod']
  rfl

/-! ### 3. Polynomial bounds, logarithms, and double counting -/

lemma inv_alpha_le_P_alpha {P_α : ℕ → ℝ} {d : ℕ} {α : ℝ}
    (hα_pos : 0 < α) (hbound : 1 / P_α d ≤ α) (hP1 : 1 ≤ P_α d) :
    α⁻¹ ≤ P_α d := by
  have hP_pos : 0 < P_α d := by linarith
  have h1 : 1 ≤ α * P_α d := (div_le_iff₀ hP_pos).mp hbound
  exact (inv_le_iff_one_le_mul₀' hα_pos).mpr (by linarith)

lemma log_add_one_le_log_two_mul {n : ℕ} (hn : 2 ≤ n) :
    Real.log ((n : ℝ) + 1) ≤ Real.log (2 * (n : ℝ)) := by
  have hn_real : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  exact Real.log_le_log (by linarith) (by linarith)

lemma one_le_log_two_mul {n : ℕ} (hn : 2 ≤ n) :
    1 ≤ Real.log (2 * (n : ℝ)) := by
  have hn_real : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have hexp : Real.exp 1 ≤ 2 * (n : ℝ) := by
    have he := Real.exp_one_lt_d9
    linarith
  calc (1 : ℝ) = Real.log (Real.exp 1) := (Real.log_exp 1).symm
    _ ≤ Real.log (2 * (n : ℝ)) := Real.log_le_log (Real.exp_pos 1) hexp

lemma log_two_mul_le_clog_add_one {n : ℕ} (hn : 2 ≤ n) :
    Real.log (2 * (n : ℝ)) ≤ ((Nat.clog 2 (2 * n) : ℝ) + 1) := by
  let L := Nat.clog 2 (2 * n)
  have hpow_nat : 2 * n ≤ 2 ^ L := Nat.le_pow_clog (by norm_num) (2 * n)
  have hpow_real : 2 * (n : ℝ) ≤ (2 : ℝ) ^ L := by exact_mod_cast hpow_nat
  have hn_real : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have hlog : Real.log (2 * (n : ℝ)) ≤ Real.log ((2 : ℝ) ^ L) :=
    Real.log_le_log (by linarith) hpow_real
  rw [Real.log_pow] at hlog
  have hlog2 : Real.log 2 ≤ 1 := by
    have h2 := Real.log_two_lt_d9
    linarith
  have hL_nonneg : (0 : ℝ) ≤ (L : ℝ) := Nat.cast_nonneg L
  calc Real.log (2 * (n : ℝ))
      ≤ (L : ℝ) * Real.log 2 := hlog
    _ ≤ (L : ℝ) * 1 := mul_le_mul_of_nonneg_left hlog2 hL_nonneg
    _ ≤ (L : ℝ) + 1 := by linarith

lemma isBoundedByPoly3_P_suf {P_α : ℕ → ℝ} {P_node : ℕ → ℕ → ℕ → ℝ} {K : ℝ}
    (hK : 0 ≤ K)
    (hP_α : IsBoundedByPoly1 P_α) (hP_α_ge : ∀ d, 1 ≤ P_α d)
    (hP_node : IsBoundedByPoly3 P_node) (hP_node_nn : ∀ d B L, 0 ≤ P_node d B L) :
    IsBoundedByPoly3 (fun d B L => K * P_α d * P_node d B L) := by
  rcases hP_α with ⟨C₁, deg₁, hC₁, hb₁⟩
  rcases hP_node with ⟨C₂, deg₂, hC₂, hb₂⟩
  refine ⟨K * C₁ * C₂, deg₁ + deg₂, by positivity, fun d B L => ?_⟩
  have hPα_nn : 0 ≤ P_α d := by linarith [hP_α_ge d]
  have hPn_nn : 0 ≤ P_node d B L := hP_node_nn d B L
  have hB1 : (1 : ℝ) ≤ (B + 1 : ℝ) := by exact_mod_cast Nat.le_add_left 1 B
  have hL1 : (1 : ℝ) ≤ (L + 1 : ℝ) := by exact_mod_cast Nat.le_add_left 1 L
  have hB_pow : ((B + 1 : ℝ) ^ deg₂) ≤ ((B + 1 : ℝ) ^ (deg₁ + deg₂)) :=
    pow_le_pow_right₀ hB1 (Nat.le_add_left _ _)
  have hL_pow : ((L + 1 : ℝ) ^ deg₂) ≤ ((L + 1 : ℝ) ^ (deg₁ + deg₂)) :=
    pow_le_pow_right₀ hL1 (Nat.le_add_left _ _)
  calc K * P_α d * P_node d B L
      ≤ K * (C₁ * ((d + 1 : ℝ) ^ deg₁)) *
          (C₂ * ((d + 1 : ℝ) ^ deg₂) * ((B + 1 : ℝ) ^ deg₂) * ((L + 1 : ℝ) ^ deg₂)) := by
        have h1 : P_α d ≤ C₁ * ((d + 1 : ℝ) ^ deg₁) := hb₁ d
        have h2 : P_node d B L ≤
            C₂ * ((d + 1 : ℝ) ^ deg₂) * ((B + 1 : ℝ) ^ deg₂) * ((L + 1 : ℝ) ^ deg₂) := hb₂ d B L
        have h1' : K * P_α d ≤ K * (C₁ * ((d + 1 : ℝ) ^ deg₁)) :=
          mul_le_mul_of_nonneg_left h1 hK
        exact mul_le_mul h1' h2 hPn_nn (by positivity)
    _ = K * C₁ * C₂ * ((d + 1 : ℝ) ^ (deg₁ + deg₂)) *
          ((B + 1 : ℝ) ^ deg₂) * ((L + 1 : ℝ) ^ deg₂) := by
        rw [pow_add]
        ring
    _ ≤ K * C₁ * C₂ * ((d + 1 : ℝ) ^ (deg₁ + deg₂)) *
          ((B + 1 : ℝ) ^ (deg₁ + deg₂)) * ((L + 1 : ℝ) ^ (deg₁ + deg₂)) := by
        gcongr

lemma isBoundedByPoly2_B_card {P_α : ℕ → ℝ} {K : ℝ}
    (hK : 0 ≤ K)
    (hP_α : IsBoundedByPoly1 P_α) (hP_α_ge : ∀ d, 1 ≤ P_α d) :
    IsBoundedByPoly2 (fun d L => K * (P_α d) ^ 3 * ((L + 1 : ℝ))) := by
  rcases hP_α with ⟨C₁, deg₁, hC₁, hb₁⟩
  let deg := 3 * deg₁ + 1
  refine ⟨K * C₁ ^ 3, deg, by positivity, fun d L => ?_⟩
  have hPα_nn : 0 ≤ P_α d := by linarith [hP_α_ge d]
  have hpow3 : (P_α d) ^ 3 ≤ (C₁ * ((d + 1 : ℝ) ^ deg₁)) ^ 3 :=
    pow_le_pow_left₀ hPα_nn (hb₁ d) 3
  have hd1 : (1 : ℝ) ≤ (d + 1 : ℝ) := by exact_mod_cast Nat.le_add_left 1 d
  have hL1 : (1 : ℝ) ≤ (L + 1 : ℝ) := by exact_mod_cast Nat.le_add_left 1 L
  have hd_pow : ((d + 1 : ℝ) ^ (3 * deg₁)) ≤ ((d + 1 : ℝ) ^ deg) :=
    pow_le_pow_right₀ hd1 (Nat.le_add_right _ _)
  have hL_pow : ((L + 1 : ℝ) ^ 1) ≤ ((L + 1 : ℝ) ^ deg) :=
    pow_le_pow_right₀ hL1 (Nat.le_add_left 1 (3 * deg₁))
  calc K * (P_α d) ^ 3 * ((L + 1 : ℝ))
      ≤ K * (C₁ * ((d + 1 : ℝ) ^ deg₁)) ^ 3 * ((L + 1 : ℝ) ^ 1) := by
        rw [pow_one]
        exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hpow3 hK) (by positivity)
    _ = K * C₁ ^ 3 * ((d + 1 : ℝ) ^ (3 * deg₁)) * ((L + 1 : ℝ) ^ 1) := by
        rw [mul_pow, ← pow_mul]
        ring
    _ ≤ K * C₁ ^ 3 * ((d + 1 : ℝ) ^ deg) * ((L + 1 : ℝ) ^ deg) := by
        gcongr

lemma isBoundedByPoly3_mul_poly2_poly3 {F : ℕ → ℕ → ℝ} {G : ℕ → ℕ → ℕ → ℝ}
    (hF : IsBoundedByPoly2 F) (hF_nn : ∀ d L, 0 ≤ F d L)
    (hG : IsBoundedByPoly3 G) (hG_nn : ∀ d B L, 0 ≤ G d B L) :
    IsBoundedByPoly3 (fun d B L => F d L * G d B L) := by
  rcases hF with ⟨C₁, deg₁, hC₁, hb₁⟩
  rcases hG with ⟨C₂, deg₂, hC₂, hb₂⟩
  refine ⟨C₁ * C₂, deg₁ + deg₂, by positivity, fun d B L => ?_⟩
  have hB1 : (1 : ℝ) ≤ (B + 1 : ℝ) := by exact_mod_cast Nat.le_add_left 1 B
  have hB_pow : ((B + 1 : ℝ) ^ deg₂) ≤ ((B + 1 : ℝ) ^ (deg₁ + deg₂)) :=
    pow_le_pow_right₀ hB1 (Nat.le_add_left _ _)
  calc F d L * G d B L
      ≤ (C₁ * ((d + 1 : ℝ) ^ deg₁) * ((L + 1 : ℝ) ^ deg₁)) *
          (C₂ * ((d + 1 : ℝ) ^ deg₂) * ((B + 1 : ℝ) ^ deg₂) * ((L + 1 : ℝ) ^ deg₂)) :=
        mul_le_mul (hb₁ d L) (hb₂ d B L) (hG_nn d B L) (by positivity)
    _ = C₁ * C₂ * ((d + 1 : ℝ) ^ (deg₁ + deg₂)) *
          ((B + 1 : ℝ) ^ deg₂) * ((L + 1 : ℝ) ^ (deg₁ + deg₂)) := by
        rw [pow_add, pow_add]
        ring
    _ ≤ C₁ * C₂ * ((d + 1 : ℝ) ^ (deg₁ + deg₂)) *
          ((B + 1 : ℝ) ^ (deg₁ + deg₂)) * ((L + 1 : ℝ) ^ (deg₁ + deg₂)) := by
        gcongr

open Classical in
lemma list_sum_finset_card_eq_range_sum {α : Type*} (recs : List α) (S : α → Finset ℕ) (t : ℕ)
    (hsub : ∀ r ∈ recs, ∀ u ∈ S r, u < t) :
    (recs.map (fun r => (S r).card)).sum =
      ∑ u ∈ Finset.range t, (recs.filter (fun r => decide (u ∈ S r))).length := by
  induction recs with
  | nil => simp
  | cons r rs ih =>
      have hrs : ∀ r' ∈ rs, ∀ u ∈ S r', u < t :=
        fun r' hr' => hsub r' (List.mem_cons_of_mem r hr')
      have hr_sub : S r ⊆ Finset.range t := by
        intro u hu
        exact Finset.mem_range.mpr (hsub r List.mem_cons_self u hu)
      simp only [List.map_cons, List.sum_cons, List.filter_cons]
      have hpoint :
          ∀ u ∈ Finset.range t,
            (if decide (u ∈ S r) = true then r :: List.filter (fun r' => decide (u ∈ S r')) rs
             else List.filter (fun r' => decide (u ∈ S r')) rs).length =
              (if u ∈ S r then 1 else 0) + (rs.filter (fun r' => decide (u ∈ S r'))).length := by
        intro u _
        by_cases hu : u ∈ S r <;> simp [hu, Nat.add_comm]
      rw [Finset.sum_congr rfl hpoint, Finset.sum_add_distrib, ← ih hrs]
      congr 1
      rw [← Finset.card_filter, Finset.filter_mem_eq_inter, Finset.inter_eq_right.mpr hr_sub]

end UL.Proof_claim_C_3_sync_suffix_v31
