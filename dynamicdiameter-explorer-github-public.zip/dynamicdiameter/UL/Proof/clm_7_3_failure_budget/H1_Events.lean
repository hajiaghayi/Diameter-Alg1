import UL.Stmt.clm_7_3_failure_budget
set_option autoImplicit false

namespace UL.Proof_clm_7_3_failure_budget

open UL
open Classical

private lemma list_map_sum_le {α : Type*} (l : List α) (f : α → ℕ) (B : ℕ)
    (h : ∀ x ∈ l, f x ≤ B) : (l.map f).sum ≤ l.length * B := by
  induction l with
  | nil => simp
  | cons hd tl ih =>
    simp only [List.map_cons, List.sum_cons, List.length_cons]
    have h1 : f hd ≤ B := h hd List.mem_cons_self
    have h2 : (tl.map f).sum ≤ tl.length * B :=
      ih (fun x hx => h x (List.mem_cons_of_mem _ hx))
    calc
      f hd + (tl.map f).sum ≤ B + tl.length * B := Nat.add_le_add h1 h2
      _ = (tl.length + 1) * B := by ring

private lemma residual_card_le {d : ℕ} {ι : Type*}
    (N : ChainNode d) (pts : ι → EuclideanSpace ℝ (Fin d)) (S : Finset ι) :
    (N.residual pts S).card ≤ S.card := by
  unfold ChainNode.residual nodeResidual
  exact Finset.card_le_card Finset.sdiff_subset

private lemma prefixResidual_card_le {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d)) :
    ∀ (pref : List (OpenedJobLevel d ι)) (S_root : Finset ι),
      (prefixResidual pts pref S_root).card ≤ S_root.card
  | [], S_root => le_rfl
  | lv :: tl, S_root => by
    unfold prefixResidual
    simp only [List.foldl_cons]
    exact (prefixResidual_card_le pts tl (lv.ball.residual pts S_root)).trans
      (residual_card_le lv.ball pts S_root)

private lemma card_insert_le_any {α : Type*} (inst : DecidableEq α) (a : α) (s : Finset α) :
    (@insert α (Finset α) (@Finset.instInsert α inst) a s).card ≤ s.card + 1 := by
  letI := inst
  exact Finset.card_insert_le a s

private lemma card_erase_le_any {α : Type*} (inst : DecidableEq α) (a : α) (s : Finset α) :
    (@Finset.erase α inst s a).card ≤ s.card := by
  letI := inst
  exact Finset.card_erase_le

private lemma applyAlg4PointSetUpdate_card_le {d : ℕ} {n : ℕ}
    {st : Alg4State d ℕ} {upd : Alg4PointUpdate d ℕ}
    (hact : st.activeSet.card ≤ n)
    (hupd : IsValidAlg4PointUpdate n st upd) :
    (applyAlg4PointSetUpdate st.activeSet upd).card ≤ n := by
  cases upd with
  | insert p pt =>
    rcases hupd with ⟨_, hcap⟩
    simp only [applyAlg4PointSetUpdate]
    exact (card_insert_le_any _ p st.activeSet).trans hcap
  | delete p =>
    simp only [applyAlg4PointSetUpdate]
    exact (card_erase_le_any _ p st.activeSet).trans hact

private lemma alg4Line1Aux_spec {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (nodes : List (Alg4ServingNode d ℕ)) :
    ∀ (activeEv : Option (PoolUpdateEvent ℕ))
      (qList : List (NodeMatchingQueryAnswers ℕ))
      (mHints : List (Option ℕ)),
      let res := alg4Line1Aux pts mode activeEv nodes qList mHints
      res.1.length = nodes.length ∧
      (∀ pair ∈ res.1, ∃ sn ∈ nodes, pair.1.ownedJob = sn.ownedJob) := by
  induction nodes with
  | nil =>
    intro activeEv qList mHints
    simp [alg4Line1Aux]
  | cons sn rest ih =>
    intro activeEv qList mHints
    unfold alg4Line1Aux
    dsimp only
    refine ⟨?_, ?_⟩
    · rw [List.length_cons, (ih _ (qList.drop 1) (mHints.drop 1)).1]
      rfl
    · intro pair hmem
      rcases List.mem_cons.mp hmem with rfl | htl
      · refine ⟨sn, List.mem_cons_self, ?_⟩
        dsimp only
        cases activeEv.getD .unaffected <;> rfl
      · rcases (ih _ (qList.drop 1) (mHints.drop 1)).2 pair htl with ⟨sn₀, hsn₀, hjob⟩
        exact ⟨sn₀, List.mem_cons_of_mem _ hsn₀, hjob⟩

private lemma alg4Line1ApplyToServingChain_spec {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (nodes : List (Alg4ServingNode d ℕ)) (terminalLeaf : Finset ℕ)
    (upd : Alg4PointUpdate d ℕ)
    (qList : List (NodeMatchingQueryAnswers ℕ)) (mHints : List (Option ℕ)) :
    let l1 := alg4Line1ApplyToServingChain pts mode nodes terminalLeaf upd qList mHints
    l1.1.length = nodes.length ∧
    (∀ pair ∈ l1.1, ∃ sn ∈ nodes, pair.1.ownedJob = sn.ownedJob) ∧
    l1.2.1.card ≤ terminalLeaf.card + 1 := by
  unfold alg4Line1ApplyToServingChain
  cases upd with
  | insert p0 pt0 =>
    dsimp only
    have haux := alg4Line1Aux_spec pts mode nodes (some (.externalInsert p0)) qList mHints
    refine ⟨haux.1, haux.2, ?_⟩
    cases (alg4Line1Aux pts mode (some (.externalInsert p0)) nodes qList mHints).2 with
    | externalInsert p => exact card_insert_le_any _ p terminalLeaf
    | externalDelete p => exact (card_erase_le_any _ p terminalLeaf).trans (Nat.le_succ _)
    | virtualValueDelete => exact Nat.le_succ _
    | unaffected => exact Nat.le_succ _
  | delete p0 =>
    dsimp only
    have haux := alg4Line1Aux_spec pts mode nodes (some (.externalDelete p0)) qList mHints
    refine ⟨haux.1, haux.2, ?_⟩
    cases (alg4Line1Aux pts mode (some (.externalDelete p0)) nodes qList mHints).2 with
    | externalInsert p => exact card_insert_le_any _ p terminalLeaf
    | externalDelete p => exact (card_erase_le_any _ p terminalLeaf).trans (Nat.le_succ _)
    | virtualValueDelete => exact Nat.le_succ _
    | unaffected => exact Nat.le_succ _

private lemma alg4Line3RoutePrefixAux_length {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (pref : List (Alg4OpenedLevel d ℕ)) :
    ∀ (activeEv : Option (PoolUpdateEvent ℕ))
      (qList : List (NodeMatchingQueryAnswers ℕ))
      (mHints : List (Option ℕ)),
      (alg4Line3RoutePrefixAux pts mode activeEv pref qList mHints).1.length = pref.length := by
  induction pref with
  | nil =>
    intro activeEv qList mHints
    simp [alg4Line3RoutePrefixAux]
  | cons lv rest ih =>
    intro activeEv qList mHints
    unfold alg4Line3RoutePrefixAux
    dsimp only
    rw [List.length_cons, ih _ (qList.drop 1) (mHints.drop 1)]
    rfl

private lemma stepPrefixConstruction_length {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (pref : List (Alg4OpenedLevel d ℕ)) :
    ∀ (S_lv : Finset ℕ) (bSteps : List (PendingLevelBudgetChoices ℕ)),
      (stepPrefixConstruction pts mode S_lv pref bSteps).length = pref.length := by
  induction pref with
  | nil =>
    intro S_lv bSteps
    simp [stepPrefixConstruction]
  | cons lv rest ih =>
    intro S_lv bSteps
    unfold stepPrefixConstruction
    dsimp only
    rw [List.length_cons, ih _ (bSteps.drop 1)]
    rfl

private lemma alg4Line5LateOpeningGate_spec {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    {n k : ℕ} (job : Alg4PendingJob d ℕ) (jc : PendingJobStepChoices d ℕ)
    (hres : job.currentResidual.card ≤ n)
    (hlen : job.completedPrefix.length ≤ k) :
    let job' := alg4Line5LateOpeningGate pts mode α L job jc
    job'.currentResidual.card ≤ n ∧ job'.completedPrefix.length ≤ k + 1 := by
  unfold alg4Line5LateOpeningGate
  dsimp only
  by_cases h1 : job.closedAsLeaf = true
  · rw [if_pos h1]
    exact ⟨hres, by omega⟩
  · rw [if_neg h1]
    by_cases h2 : (!(job.completedPrefix.all (fun lv => lv.backgroundReady))) = true
    · rw [if_pos h2]
      exact ⟨hres, by omega⟩
    · rw [if_neg h2]
      cases residualScheduleStep α L job.remainingTicks job.currentResidual.card with
      | wait => dsimp only; exact ⟨hres, by omega⟩
      | closeAsLeaf => dsimp only; exact ⟨hres, by omega⟩
      | openBallLevel =>
        dsimp only
        by_cases hNE : job.currentResidual.Nonempty
        · rw [dif_pos hNE]
          dsimp only
          refine ⟨(residual_card_le _ pts job.currentResidual).trans hres, ?_⟩
          rw [List.length_append, List.length_singleton]
          omega
        · rw [dif_neg hNE]
          exact ⟨hres, by omega⟩

private lemma alg4Lines2To6StepPendingJobs_spec {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    {n k : ℕ}
    (nodesLine1 : List (Alg4ServingNode d ℕ × PoolUpdateEvent ℕ)) :
    ∀ (S_cur' : Finset ℕ)
      (jChoices : List (PendingJobStepChoices d ℕ)),
      S_cur'.card ≤ n →
      (∀ pair ∈ nodesLine1, ∀ job : Alg4PendingJob d ℕ,
        pair.1.ownedJob = some job →
          job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k) →
      let out := alg4Lines2To6StepPendingJobs pts mode α L S_cur' nodesLine1 jChoices
      out.length = nodesLine1.length ∧
      (∀ pair ∈ out, ∀ job : Alg4PendingJob d ℕ,
        pair.1.ownedJob = some job →
          job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k + 1) := by
  induction nodesLine1 with
  | nil =>
    intro S_cur' jChoices _ _
    simp [alg4Lines2To6StepPendingJobs]
  | cons hd rest ih =>
    rcases hd with ⟨sn, ev⟩
    intro S_cur' jChoices hS hnodes
    unfold alg4Lines2To6StepPendingJobs
    dsimp only
    generalize hjc : jChoices.head?.getD
      { prefixRouteQueries := []
        prefixRouteMaxHints := []
        prefixBudgetSteps := []
        openSampledCenter := .infeasible
        openFallbackBirthId := none
        leafHint := none } = jc
    have hS_next : (sn.node.residual pts S_cur').card ≤ n :=
      (residual_card_le _ pts S_cur').trans hS
    have hrest_nodes : ∀ pair ∈ rest, ∀ job : Alg4PendingJob d ℕ,
        pair.1.ownedJob = some job →
          job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k :=
      fun p hp => hnodes p (List.mem_cons_of_mem _ hp)
    by_cases htick : ev.isClockTick = true
    · rw [if_pos htick]
      rcases hown : sn.ownedJob with _ | job
      · dsimp only
        have hrec := ih (sn.node.residual pts S_cur') (jChoices.drop 1) hS_next hrest_nodes
        dsimp only at hrec
        refine ⟨by rw [List.length_cons, hrec.1]; rfl, ?_⟩
        intro pair hmem
        rcases List.mem_cons.mp hmem with rfl | htl
        · intro job' hjob'
          rw [hown] at hjob'; cases hjob'
        · exact hrec.2 pair htl
      · dsimp only
        have hrec := ih (sn.node.residual pts S_cur') (jChoices.drop 1) hS_next hrest_nodes
        dsimp only at hrec
        refine ⟨by rw [List.length_cons, hrec.1]; rfl, ?_⟩
        intro pair hmem
        rcases List.mem_cons.mp hmem with rfl | htl
        · intro job' hjob'
          dsimp only at hjob'
          injection hjob' with hjob_eq
          subst hjob_eq
          rcases hnodes (sn, ev) List.mem_cons_self job hown with ⟨_, hlen0⟩
          let job₁ := alg4Line3RouteThroughPrefix pts mode job ev S_cur' jc
          have hjob₁_res : job₁.currentResidual.card ≤ n := by
            dsimp only [job₁, alg4Line3RouteThroughPrefix]
            exact (prefixResidual_card_le pts _ S_cur').trans hS
          have hjob₁_len : job₁.completedPrefix.length ≤ k := by
            dsimp only [job₁, alg4Line3RouteThroughPrefix]
            rw [alg4Line3RoutePrefixAux_length]
            exact hlen0
          let job₂ := alg4Line4AdvanceClockAndBuild pts mode job₁ S_cur' jc.prefixBudgetSteps
          have hjob₂_res : job₂.currentResidual.card ≤ n := hjob₁_res
          have hjob₂_len : job₂.completedPrefix.length ≤ k := by
            dsimp only [job₂, alg4Line4AdvanceClockAndBuild]
            rw [stepPrefixConstruction_length]
            exact hjob₁_len
          exact alg4Line5LateOpeningGate_spec pts mode α L job₂ jc hjob₂_res hjob₂_len
        · exact hrec.2 pair htl
    · rw [if_neg htick]
      have hrec := ih (sn.node.residual pts S_cur') (jChoices.drop 1) hS_next hrest_nodes
      dsimp only at hrec
      refine ⟨by rw [List.length_cons, hrec.1]; rfl, ?_⟩
      intro pair hmem
      rcases List.mem_cons.mp hmem with rfl | htl
      · intro job' hjob'
        rcases hnodes (sn, ev) List.mem_cons_self job' hjob' with ⟨hr, hl⟩
        exact ⟨hr, by omega⟩
      · exact hrec.2 pair htl

private lemma alg4Lines7To8InstallCompletedJobs_spec {d : ℕ} {n k M : ℕ} (hnM : n ≤ M)
    (nodes : List (Alg4ServingNode d ℕ × Bool)) :
    ∀ (leaf : Finset ℕ) (leafAns : Option (ℕ × ℕ)) (leafSq : ℝ) (leafCh : Bool),
      leaf.card ≤ M →
      (∀ pair ∈ nodes, ∀ job : Alg4PendingJob d ℕ,
        pair.1.ownedJob = some job →
          job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k + 1) →
      let out := alg4Lines7To8InstallCompletedJobs nodes leaf leafAns leafSq leafCh
      out.1.length ≤ nodes.length + (k + 1) ∧
      out.2.1.card ≤ M ∧
      (∀ pair ∈ out.1, ∀ job : Alg4PendingJob d ℕ,
        pair.1.ownedJob = some job →
          job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k + 1) := by
  induction nodes with
  | nil =>
    intro leaf leafAns leafSq leafCh hleaf _
    simp [alg4Lines7To8InstallCompletedJobs, hleaf]
  | cons hd rest ih =>
    rcases hd with ⟨sn, affected⟩
    intro leaf leafAns leafSq leafCh hleaf hnodes
    unfold alg4Lines7To8InstallCompletedJobs
    rcases hown : sn.ownedJob with _ | job
    · dsimp only
      have hrec := ih leaf leafAns leafSq leafCh hleaf
        (fun p hp => hnodes p (List.mem_cons_of_mem _ hp))
      dsimp only at hrec
      refine ⟨by rw [List.length_cons, List.length_cons]; have := hrec.1; omega, hrec.2.1, ?_⟩
      intro pair hmem
      rcases List.mem_cons.mp hmem with rfl | htl
      · intro job' hj'; rw [hown] at hj'; cases hj'
      · exact hrec.2.2 pair htl
    · dsimp only
      by_cases hready : job.IsReadyToInstall
      · rw [if_pos hready]
        dsimp only
        rcases hnodes (sn, affected) List.mem_cons_self job hown with ⟨hres, hlen⟩
        refine ⟨?_, hres.trans hnM, ?_⟩
        · rw [List.length_map, List.length_cons]
          omega
        · intro pair hmem job' hj'
          rcases List.mem_map.mp hmem with ⟨lv, _, rfl⟩
          simp [installOpenedLevelAsServingNode] at hj'
      · rw [if_neg hready]
        dsimp only
        have hrec := ih leaf leafAns leafSq leafCh hleaf
          (fun p hp => hnodes p (List.mem_cons_of_mem _ hp))
        dsimp only at hrec
        refine ⟨by rw [List.length_cons, List.length_cons]; have := hrec.1; omega, hrec.2.1, ?_⟩
        intro pair hmem
        rcases List.mem_cons.mp hmem with rfl | htl
        · exact hnodes (sn, affected) List.mem_cons_self
        · exact hrec.2.2 pair htl

private lemma startDueServingJobsAux_spec {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (α : ℝ) (L : ℕ)
    {n k M : ℕ} (hnM : n ≤ M)
    (nodes : List (Alg4ServingNode d ℕ × Bool)) :
    ∀ (S_cur : Finset ℕ)
      (leaf : Finset ℕ) (leafAns : Option (ℕ × ℕ)) (leafSq : ℝ) (leafCh : Bool),
      S_cur.card ≤ n →
      leaf.card ≤ M →
      (∀ pair ∈ nodes, ∀ job : Alg4PendingJob d ℕ,
        pair.1.ownedJob = some job →
          job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k + 1) →
      let out := startDueServingJobsAux pts α L S_cur nodes leaf leafAns leafSq leafCh
      out.1.length ≤ nodes.length ∧
      out.2.1.card ≤ M ∧
      (∀ pair ∈ out.1, ∀ job : Alg4PendingJob d ℕ,
        pair.1.ownedJob = some job →
          job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k + 1) := by
  induction nodes with
  | nil =>
    intro S_cur leaf _ _ _ _ hleaf _
    simp [startDueServingJobsAux, hleaf]
  | cons hd rest ih =>
    rcases hd with ⟨sn, needRefresh⟩
    intro S_cur leaf leafAns leafSq leafCh hS hleaf hnodes
    unfold startDueServingJobsAux
    by_cases hdue : sn.ownedJob.isNone ∧ jobStartAge α sn.birthSnapshot.card ≤ sn.age
    · rw [if_pos hdue]
      rcases hsched : scheduleJobStart α L S_cur.card with _ | H
      · dsimp only
        exact ⟨by simp, hS.trans hnM, by intro _ h; simp at h⟩
      · dsimp only
        have hS_next : (sn.node.residual pts S_cur).card ≤ n :=
          (residual_card_le sn.node pts S_cur).trans hS
        have hrec := ih (sn.node.residual pts S_cur) leaf leafAns leafSq leafCh hS_next hleaf
          (fun p hp => hnodes p (List.mem_cons_of_mem _ hp))
        dsimp only at hrec
        refine ⟨by rw [List.length_cons, List.length_cons]; exact Nat.succ_le_succ hrec.1, hrec.2.1, ?_⟩
        intro pair hmem
        rcases List.mem_cons.mp hmem with rfl | htl
        · intro job hj
          dsimp only at hj
          injection hj with hjeq
          subst hjeq
          simp [Alg4PendingJob.init, hS]
        · exact hrec.2.2 pair htl
    · rw [if_neg hdue]
      dsimp only
      have hS_next : (sn.node.residual pts S_cur).card ≤ n :=
        (residual_card_le sn.node pts S_cur).trans hS
      have hrec := ih (sn.node.residual pts S_cur) leaf leafAns leafSq leafCh hS_next hleaf
        (fun p hp => hnodes p (List.mem_cons_of_mem _ hp))
      dsimp only at hrec
      refine ⟨by rw [List.length_cons, List.length_cons]; exact Nat.succ_le_succ hrec.1, hrec.2.1, ?_⟩
      intro pair hmem
      rcases List.mem_cons.mp hmem with rfl | htl
      · exact hnodes (sn, needRefresh) List.mem_cons_self
      · exact hrec.2.2 pair htl

private lemma rebuildOversizedLeafAux_spec {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode) (α : ℝ) (L : ℕ)
    (fuel : ℕ) :
    ∀ (S_cur : Finset ℕ) (choices : List (LeafRebuildLevelChoices d ℕ)),
      let out := rebuildOversizedLeafAux pts mode α L fuel S_cur choices
      out.1.length ≤ fuel ∧
      out.2.card ≤ S_cur.card ∧
      (∀ pair ∈ out.1, pair.1.ownedJob = none) := by
  induction fuel with
  | zero =>
    intro S_cur _
    simp [rebuildOversizedLeafAux]
  | succ fuel ih =>
    intro S_cur choices
    unfold rebuildOversizedLeafAux
    dsimp only
    by_cases hleaf : IsResidualLeafSize L S_cur.card
    · rw [if_pos hleaf]
      simp
    · rw [if_neg hleaf]
      by_cases hNE : S_cur.Nonempty
      · rw [dif_pos hNE]
        dsimp only
        let ch : LeafRebuildLevelChoices d ℕ := choices.head?.getD
          { sampledCenter := .infeasible
            fallbackBirthId := none
            radiusMaxHint := none
            pointInsertOrder := [] }
        let bId := chooseBirthPointIn S_cur hNE ch.fallbackBirthId
        let ball := selectOpenedLevelBall α pts S_cur bId ch.sampledCenter
        have hrec := ih (ball.residual pts S_cur) (choices.drop 1)
        dsimp only at hrec
        refine ⟨by rw [List.length_cons]; exact Nat.succ_le_succ hrec.1,
          hrec.2.1.trans (residual_card_le _ pts S_cur), ?_⟩
        intro pair hmem
        rcases List.mem_cons.mp hmem with rfl | htl
        · rfl
        · exact hrec.2.2 pair htl
      · rw [dif_neg hNE]
        simp

private lemma alg4Line10RefreshAffectedCaches_spec {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mode : Alg4Mode)
    (nodes : List (Alg4ServingNode d ℕ × Bool)) :
    ∀ (S_cur : Finset ℕ)
      (sampLists : List (List ℕ))
      (cfgHints : List (Option ShellConfig)),
      let out := alg4Line10RefreshAffectedCaches pts mode S_cur nodes sampLists cfgHints
      out.length = nodes.length ∧
      (∀ sn' ∈ out, ∃ pair ∈ nodes, sn'.ownedJob = pair.1.ownedJob) := by
  induction nodes with
  | nil =>
    intro S_cur sampLists cfgHints
    simp [alg4Line10RefreshAffectedCaches]
  | cons hd rest ih =>
    rcases hd with ⟨sn, needRefresh⟩
    intro S_cur sampLists cfgHints
    unfold alg4Line10RefreshAffectedCaches
    dsimp only
    let sn' : Alg4ServingNode d ℕ :=
      if needRefresh then
        let (bPair, bSq) :=
          refreshBaselineFromSamples pts sn.node.o S_cur sn.radiusDict (sampLists.head?.getD [])
        let (mPair, mSq) :=
          refreshMaxMatchingWitness pts mode sn.node sn.localMatchings cfgHints.head?.join
        { sn with
          baselinePair := bPair
          baselineDistSq := bSq
          maxMatchingPair := mPair
          maxMatchingDistSq := mSq }
      else
        sn
    have hrec := ih (sn'.node.residual pts S_cur) (sampLists.drop 1) (cfgHints.drop 1)
    dsimp only at hrec
    refine ⟨by rw [List.length_cons, List.length_cons, hrec.1], ?_⟩
    intro x hx
    rcases List.mem_cons.mp hx with rfl | htl
    · refine ⟨(sn, needRefresh), List.mem_cons_self, ?_⟩
      split_ifs <;> rfl
    · rcases hrec.2 x htl with ⟨p0, hp0, hj⟩
      exact ⟨p0, List.mem_cons_of_mem _ hp0, hj⟩

/-- Size invariant maintained along `k` valid updates starting from `Alg4State.empty`. -/
def BoundedAlg4State {d : ℕ} (n k : ℕ) (st : Alg4State d ℕ) : Prop :=
  st.activeSet.card ≤ n ∧
  st.terminalLeaf.card ≤ n + k ∧
  st.servingNodes.length ≤ 2 * k * (n + k + 1) ∧
  (∀ sn ∈ st.servingNodes, ∀ job : Alg4PendingJob d ℕ,
    sn.ownedJob = some job →
      job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k)

private lemma boundedAlg4State_empty (d n : ℕ) :
    BoundedAlg4State n 0 (Alg4State.empty d ℕ) := by
  refine ⟨by simp [Alg4State.empty], by simp [Alg4State.empty],
    by simp [Alg4State.empty], ?_⟩
  intro sn hsn
  simp [Alg4State.empty] at hsn

private lemma serving_len_step_le (n k len9 len0 : ℕ)
    (hlen0 : len0 ≤ 2 * k * (n + k + 1))
    (hlen9 : len9 ≤ len0 + (k + 1) + (n + (k + 1))) :
    len9 ≤ 2 * (k + 1) * (n + (k + 1) + 1) := by
  nlinarith

private lemma serving_len_le_two_S_sq {n k S len : ℕ}
    (hlen : len ≤ 2 * k * (n + k + 1))
    (hkS : k ≤ S) (hnkS : n + k + 1 ≤ S) :
    len ≤ 2 * S ^ 2 := by
  have h1 : 2 * k ≤ 2 * S := Nat.mul_le_mul_left 2 hkS
  have h2 : (2 * k) * (n + k + 1) ≤ (2 * S) * S := Nat.mul_le_mul h1 hnkS
  have h3 : (2 * S) * S = 2 * S ^ 2 := by ring
  exact hlen.trans (h3 ▸ h2)

private lemma alg4Step_preserves_bounded {d n k : ℕ}
    (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ)
    (st : Alg4State d ℕ) (upd : Alg4PointUpdate d ℕ) (choices : Alg4StepChoices d ℕ)
    (hbnd : BoundedAlg4State n k st)
    (hupd : IsValidAlg4PointUpdate n st upd) :
    BoundedAlg4State n (k + 1) (alg4Step mode α L reclaimMult st upd choices).1 ∧
    (let P' := applyAlg4PointSetUpdate st.activeSet upd
     let pts' := updateAlg4Coords st.coords upd
     let (nodesLine1, leafLine1, leafTicked) :=
       alg4Line1ApplyToServingChain pts' mode st.servingNodes st.terminalLeaf upd
         choices.servingRouteQueries choices.servingRadiusMaxHints
     let nodesLines2To6 :=
       alg4Lines2To6StepPendingJobs pts' mode α L P' nodesLine1 choices.pendingJobChoices
     let (nodesLines7To8, leafLines7To8, leafAns7To8, leafSq7To8, leafChanged7To8, _) :=
       alg4Lines7To8InstallCompletedJobs nodesLines2To6
         leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafTicked
     let (_, leaf₁, _, _, _, _) :=
       startDueServingJobsAux pts' α L P' nodesLines7To8 leafLines7To8
         leafAns7To8 leafSq7To8 leafChanged7To8
     leaf₁.card ≤ n + (k + 1)) := by
  rcases hbnd with ⟨hact, hleaf, hlen, hjobs⟩
  have hP' : (applyAlg4PointSetUpdate st.activeSet upd).card ≤ n :=
    applyAlg4PointSetUpdate_card_le hact hupd
  have hl1 := alg4Line1ApplyToServingChain_spec (updateAlg4Coords st.coords upd) mode
    st.servingNodes st.terminalLeaf upd
    choices.servingRouteQueries choices.servingRadiusMaxHints
  dsimp only at hl1
  unfold alg4Step
  dsimp only
  rcases hl1_eq :
    alg4Line1ApplyToServingChain (updateAlg4Coords st.coords upd) mode
      st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints with ⟨nodesLine1, leafLine1, leafTicked⟩
  rw [hl1_eq] at hl1
  dsimp only at hl1
  rcases hl1 with ⟨hl1_len, hl1_own, hl1_leaf0⟩
  have hl1_leaf : leafLine1.card ≤ n + (k + 1) := by omega
  have hl1_jobs : ∀ pair ∈ nodesLine1, ∀ job : Alg4PendingJob d ℕ,
      pair.1.ownedJob = some job →
        job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k := by
    intro pair hp job hj
    rcases hl1_own pair hp with ⟨sn, hsn, heq⟩
    exact hjobs sn hsn job (heq ▸ hj)
  have hl26 := alg4Lines2To6StepPendingJobs_spec (updateAlg4Coords st.coords upd) mode α L
    nodesLine1 (applyAlg4PointSetUpdate st.activeSet upd) choices.pendingJobChoices hP' hl1_jobs
  dsimp only at hl26
  generalize hl26_eq :
    alg4Lines2To6StepPendingJobs (updateAlg4Coords st.coords upd) mode α L
      (applyAlg4PointSetUpdate st.activeSet upd) nodesLine1 choices.pendingJobChoices = nodes26
      at hl26 ⊢
  have hl78 := alg4Lines7To8InstallCompletedJobs_spec (M := n + (k + 1)) (by omega)
    nodes26 leafLine1 st.terminalLeafAnswer st.terminalLeafDistSq leafTicked
    hl1_leaf hl26.2
  dsimp only at hl78
  rcases hl78_eq :
    alg4Lines7To8InstallCompletedJobs nodes26 leafLine1
      st.terminalLeafAnswer st.terminalLeafDistSq leafTicked with ⟨n78, l78, a78, s78, c78, r78⟩
  rw [hl78_eq] at hl78
  dsimp only at hl78
  have hdue := startDueServingJobsAux_spec (updateAlg4Coords st.coords upd) α L
    (M := n + (k + 1)) (by omega) n78
    (applyAlg4PointSetUpdate st.activeSet upd) l78 a78 s78 c78
    hP' hl78.2.1 hl78.2.2
  dsimp only at hdue
  rcases hdue_eq :
    startDueServingJobsAux (updateAlg4Coords st.coords upd) α L
      (applyAlg4PointSetUpdate st.activeSet upd) n78 l78 a78 s78 c78
      with ⟨nDue, leaf₁, aDue, sDue, cDue, rDue⟩
  rw [hdue_eq] at hdue
  dsimp only at hdue
  have hleaf₁ : leaf₁.card ≤ n + (k + 1) := hdue.2.1
  dsimp only
  refine ⟨?_, hleaf₁⟩
  have hl9_spec :
      let l9 := alg4Line9StartDueJobsAndHandleLeaves (updateAlg4Coords st.coords upd) mode α L
        (applyAlg4PointSetUpdate st.activeSet upd) n78 l78 a78 s78 c78
        choices.leafRebuildChoices choices.terminalLeafHint
      l9.1.length ≤ nDue.length + leaf₁.card ∧
      l9.2.1.card ≤ n + (k + 1) ∧
      (∀ pair ∈ l9.1, ∀ job : Alg4PendingJob d ℕ,
        pair.1.ownedJob = some job →
          job.currentResidual.card ≤ n ∧ job.completedPrefix.length ≤ k + 1) := by
    unfold alg4Line9StartDueJobsAndHandleLeaves
    dsimp only
    rw [hdue_eq]
    dsimp only
    by_cases hgt : 6 * L < leaf₁.card
    · rw [if_pos hgt]
      dsimp only
      have hreb := rebuildOversizedLeafAux_spec (updateAlg4Coords st.coords upd) mode α L
        leaf₁.card leaf₁ choices.leafRebuildChoices
      dsimp only at hreb
      refine ⟨?_, hreb.2.1.trans hleaf₁, ?_⟩
      · rw [List.length_append]
        exact Nat.add_le_add_left hreb.1 _
      · intro pair hmem job hj
        rcases List.mem_append.mp hmem with h1 | h2
        · exact hdue.2.2 pair h1 job hj
        · rw [hreb.2.2 pair h2] at hj; cases hj
    · rw [if_neg hgt]
      by_cases hch : cDue = true
      · rw [if_pos hch]
        exact ⟨Nat.le_add_right _ _, hleaf₁, hdue.2.2⟩
      · rw [if_neg hch]
        exact ⟨Nat.le_add_right _ _, hleaf₁, hdue.2.2⟩
  dsimp only at hl9_spec
  rcases hl9_eq :
    alg4Line9StartDueJobsAndHandleLeaves (updateAlg4Coords st.coords upd) mode α L
      (applyAlg4PointSetUpdate st.activeSet upd) n78 l78 a78 s78 c78
      choices.leafRebuildChoices choices.terminalLeafHint with ⟨nodes9, leaf9, rest9⟩
  rw [hl9_eq] at hl9_spec
  dsimp only at hl9_spec
  have hl10 := alg4Line10RefreshAffectedCaches_spec (updateAlg4Coords st.coords upd) mode
    nodes9 (applyAlg4PointSetUpdate st.activeSet upd)
    choices.baselineSamples choices.matchingMaxHints
  dsimp only at hl10
  generalize hl10_eq :
    alg4Line10RefreshAffectedCaches (updateAlg4Coords st.coords upd) mode
      (applyAlg4PointSetUpdate st.activeSet upd) nodes9
      choices.baselineSamples choices.matchingMaxHints = nodes10 at hl10 ⊢
  dsimp only
  refine ⟨hP', hl9_spec.2.1, ?_, ?_⟩
  · have hlen_chain : nodes9.length ≤ st.servingNodes.length + (k + 1) + (n + (k + 1)) := by
      have h1 := hl9_spec.1
      have h2 := hdue.1
      have h3 := hl78.1
      have h4 : nodes26.length = st.servingNodes.length := hl26.1.trans hl1_len
      omega
    rw [hl10.1]
    exact serving_len_step_le n k nodes9.length st.servingNodes.length hlen hlen_chain
  · intro sn' hsn' job hj
    rcases hl10.2 sn' hsn' with ⟨pair, hpair, heq⟩
    exact hl9_spec.2.2 pair hpair job (heq ▸ hj)

private lemma poly_arith_helper
    {S : ℕ} {C_sched : ℝ} {deg_sched : ℕ}
    (hCS : 0 ≤ C_sched) (hS5 : 5 ≤ S)
    (centers pendingLevels stLen line9Opened leafCard samples : ℕ)
    (caps : CappedScheduleEventBounds)
    (hpoly : caps.IsPolyBoundedInScale C_sched deg_sched S)
    (hcenters_le : centers ≤ 3 * S ^ 2)
    (hpend_le : pendingLevels ≤ 2 * S ^ 3)
    (hst_le : stLen ≤ 2 * S ^ 2)
    (hl9_le : line9Opened ≤ S)
    (hleaf_le : leafCard ≤ S)
    (hsamp_le : samples ≤ 2 * S ^ 2 * caps.K0) :
    let filters := (centers + pendingLevels) * (1 + caps.retainedConfigCap) * caps.filtersPerLevelConfig
    let verifs :=
      centers +
        (stLen + pendingLevels * (1 + caps.scan2BatchCap) + line9Opened * leafCard) *
          (1 + caps.retainedConfigCap) +
        (centers + pendingLevels) * (1 + caps.retainedConfigCap) * caps.verificationsPerLevelConfig
    let ev : ExecutionEventCounts :=
      { centerConstructions := centers
        filterConstructions := filters
        verificationAttempts := verifs
        witnessSamples := samples }
    let B : ℝ := 23 * ((1 + C_sched) ^ 2) * ((S : ℝ) ^ (3 + 2 * deg_sched))
    (ev.centerConstructions : ℝ) ≤ B ∧
    (ev.filterConstructions : ℝ) ≤ B ∧
    (ev.verificationAttempts : ℝ) ≤ B ∧
    (ev.witnessSamples : ℝ) ≤ B ∧
    (ev.total : ℝ) ≤ B := by
  dsimp only
  rcases hpoly with ⟨hK0, hretCap, hscanCap, hfiltCap, hverCap⟩
  generalize hQ_def : (1 + C_sched) * ((S : ℝ) ^ deg_sched) = Q
  have hS_real1 : (1 : ℝ) ≤ (S : ℝ) := by
    have : 1 ≤ S := by omega
    exact_mod_cast this
  have hS_nonneg : (0 : ℝ) ≤ (S : ℝ) := by linarith
  have hSpow1 : (1 : ℝ) ≤ (S : ℝ) ^ deg_sched := one_le_pow₀ hS_real1
  have hQ1 : 1 ≤ Q := by
    rw [← hQ_def]
    calc
      (1 : ℝ) = 1 * 1 := by ring
      _ ≤ (1 + C_sched) * ((S : ℝ) ^ deg_sched) := by gcongr; linarith
  have hQ_nonneg : 0 ≤ Q := by linarith
  have h1_add_le : ∀ m : ℕ, (m : ℝ) ≤ C_sched * ((S : ℝ) ^ deg_sched) →
      ((1 + m : ℕ) : ℝ) ≤ Q := by
    intro m hm
    push_cast
    rw [← hQ_def]
    calc
      1 + (m : ℝ) ≤ 1 + C_sched * ((S : ℝ) ^ deg_sched) := by linarith
      _ ≤ (S : ℝ) ^ deg_sched + C_sched * ((S : ℝ) ^ deg_sched) := by linarith
      _ = (1 + C_sched) * ((S : ℝ) ^ deg_sched) := by ring
  have hcap_le_Q : ∀ m : ℕ, (m : ℝ) ≤ C_sched * ((S : ℝ) ^ deg_sched) →
      (m : ℝ) ≤ Q := by
    intro m hm
    have h1 := h1_add_le m hm
    push_cast at h1
    linarith
  have hS2_le_S3 : (S : ℝ) ^ 2 ≤ (S : ℝ) ^ 3 := by
    have : S ^ 2 ≤ S ^ 3 := Nat.pow_le_pow_right (by omega) (by omega)
    exact_mod_cast this
  have hQ_le_Q2 : Q ≤ Q ^ 2 := by
    calc
      Q = Q * 1 := by ring
      _ ≤ Q * Q := by gcongr
      _ = Q ^ 2 := by ring
  have hQ2_ge1 : 1 ≤ Q ^ 2 := hQ1.trans hQ_le_Q2
  have hcent_R : (centers : ℝ) ≤ 3 * (S : ℝ) ^ 3 * Q ^ 2 := by
    have hc : (centers : ℝ) ≤ 3 * (S : ℝ) ^ 2 := by exact_mod_cast hcenters_le
    calc
      (centers : ℝ) ≤ 3 * (S : ℝ) ^ 2 := hc
      _ ≤ 3 * (S : ℝ) ^ 3 := by linarith
      _ = 3 * (S : ℝ) ^ 3 * 1 := by ring
      _ ≤ 3 * (S : ℝ) ^ 3 * Q ^ 2 := by gcongr
  have hcp_R : ((centers + pendingLevels : ℕ) : ℝ) ≤ 5 * (S : ℝ) ^ 3 := by
    have hcp_nat : centers + pendingLevels ≤ 5 * S ^ 3 := by
      have : S ^ 2 ≤ S ^ 3 := Nat.pow_le_pow_right (by omega) (by omega)
      omega
    exact_mod_cast hcp_nat
  have hfilt_R :
      (((centers + pendingLevels) * (1 + caps.retainedConfigCap) *
          caps.filtersPerLevelConfig : ℕ) : ℝ) ≤
        5 * (S : ℝ) ^ 3 * Q ^ 2 := by
    have h1 := h1_add_le caps.retainedConfigCap hretCap
    have h2 := hcap_le_Q caps.filtersPerLevelConfig hfiltCap
    calc
      (((centers + pendingLevels) * (1 + caps.retainedConfigCap) *
          caps.filtersPerLevelConfig : ℕ) : ℝ)
          = ((centers + pendingLevels : ℕ) : ℝ) *
              ((1 + caps.retainedConfigCap : ℕ) : ℝ) *
              (caps.filtersPerLevelConfig : ℝ) := by push_cast; ring
      _ ≤ (5 * (S : ℝ) ^ 3) * Q * Q := by gcongr
      _ = 5 * (S : ℝ) ^ 3 * Q ^ 2 := by ring
  have hverif_R :
      ((centers +
        (stLen + pendingLevels * (1 + caps.scan2BatchCap) +
          line9Opened * leafCard) * (1 + caps.retainedConfigCap) +
        (centers + pendingLevels) * (1 + caps.retainedConfigCap) *
          caps.verificationsPerLevelConfig : ℕ) : ℝ) ≤
        13 * (S : ℝ) ^ 3 * Q ^ 2 := by
    have h_stR : (stLen : ℝ) ≤ 2 * (S : ℝ) ^ 2 := by exact_mod_cast hst_le
    have h_pendR : (pendingLevels : ℝ) ≤ 2 * (S : ℝ) ^ 3 := by exact_mod_cast hpend_le
    have h_l9leaf : ((line9Opened * leafCard : ℕ) : ℝ) ≤ (S : ℝ) ^ 2 := by
      have : line9Opened * leafCard ≤ S * S := Nat.mul_le_mul hl9_le hleaf_le
      have hcast : ((line9Opened * leafCard : ℕ) : ℝ) ≤ (S : ℝ) * (S : ℝ) := by
        exact_mod_cast this
      linarith [show (S : ℝ) * (S : ℝ) = (S : ℝ) ^ 2 by ring]
    have h_scanQ := h1_add_le caps.scan2BatchCap hscanCap
    have h_retQ := h1_add_le caps.retainedConfigCap hretCap
    have h_verQ := hcap_le_Q caps.verificationsPerLevelConfig hverCap
    have h_mid1 :
        ((stLen + pendingLevels * (1 + caps.scan2BatchCap) +
          line9Opened * leafCard : ℕ) : ℝ) ≤ 5 * (S : ℝ) ^ 3 * Q := by
      have h_eq :
          ((stLen + pendingLevels * (1 + caps.scan2BatchCap) +
            line9Opened * leafCard : ℕ) : ℝ) =
          (stLen : ℝ) +
            (pendingLevels : ℝ) * ((1 + caps.scan2BatchCap : ℕ) : ℝ) +
            ((line9Opened * leafCard : ℕ) : ℝ) := by push_cast; ring
      rw [h_eq]
      have hpQ : (pendingLevels : ℝ) * ((1 + caps.scan2BatchCap : ℕ) : ℝ) ≤
          (2 * (S : ℝ) ^ 3) * Q := by gcongr
      have h3S3 : 3 * (S : ℝ) ^ 3 = 3 * (S : ℝ) ^ 3 * 1 := by ring
      have h3S3Q : 3 * (S : ℝ) ^ 3 ≤ 3 * (S : ℝ) ^ 3 * Q := by
        calc
          3 * (S : ℝ) ^ 3 = 3 * (S : ℝ) ^ 3 * 1 := h3S3
          _ ≤ 3 * (S : ℝ) ^ 3 * Q := by gcongr
      linarith [h_stR, h_l9leaf, hS2_le_S3, hpQ, h3S3Q]
    have h_mid :
        (((stLen + pendingLevels * (1 + caps.scan2BatchCap) +
          line9Opened * leafCard) * (1 + caps.retainedConfigCap) : ℕ) : ℝ) ≤
        5 * (S : ℝ) ^ 3 * Q ^ 2 := by
      calc
        (((stLen + pendingLevels * (1 + caps.scan2BatchCap) +
            line9Opened * leafCard) * (1 + caps.retainedConfigCap) : ℕ) : ℝ)
            = ((stLen + pendingLevels * (1 + caps.scan2BatchCap) +
                line9Opened * leafCard : ℕ) : ℝ) *
              ((1 + caps.retainedConfigCap : ℕ) : ℝ) := by push_cast; ring
        _ ≤ (5 * (S : ℝ) ^ 3 * Q) * Q := by gcongr
        _ = 5 * (S : ℝ) ^ 3 * Q ^ 2 := by ring
    have h_tail :
        (((centers + pendingLevels) * (1 + caps.retainedConfigCap) *
          caps.verificationsPerLevelConfig : ℕ) : ℝ) ≤
        5 * (S : ℝ) ^ 3 * Q ^ 2 := by
      calc
        (((centers + pendingLevels) * (1 + caps.retainedConfigCap) *
            caps.verificationsPerLevelConfig : ℕ) : ℝ)
            = ((centers + pendingLevels : ℕ) : ℝ) *
                ((1 + caps.retainedConfigCap : ℕ) : ℝ) *
                (caps.verificationsPerLevelConfig : ℝ) := by push_cast; ring
        _ ≤ (5 * (S : ℝ) ^ 3) * Q * Q := by gcongr
        _ = 5 * (S : ℝ) ^ 3 * Q ^ 2 := by ring
    have h_sum_eq :
        ((centers +
          (stLen + pendingLevels * (1 + caps.scan2BatchCap) +
            line9Opened * leafCard) * (1 + caps.retainedConfigCap) +
          (centers + pendingLevels) * (1 + caps.retainedConfigCap) *
            caps.verificationsPerLevelConfig : ℕ) : ℝ) =
        (centers : ℝ) +
          (((stLen + pendingLevels * (1 + caps.scan2BatchCap) +
            line9Opened * leafCard) * (1 + caps.retainedConfigCap) : ℕ) : ℝ) +
          (((centers + pendingLevels) * (1 + caps.retainedConfigCap) *
            caps.verificationsPerLevelConfig : ℕ) : ℝ) := by push_cast; ring
    linarith [h_sum_eq, hcent_R, h_mid, h_tail]
  have hsamp_R : (samples : ℝ) ≤ 2 * (S : ℝ) ^ 3 * Q ^ 2 := by
    have h1 : (samples : ℝ) ≤ (2 * (S : ℝ) ^ 2) * (caps.K0 : ℝ) := by exact_mod_cast hsamp_le
    have h2 := hcap_le_Q caps.K0 hK0
    calc
      (samples : ℝ) ≤ (2 * (S : ℝ) ^ 2) * (caps.K0 : ℝ) := h1
      _ ≤ (2 * (S : ℝ) ^ 3) * Q := by gcongr
      _ ≤ 2 * (S : ℝ) ^ 3 * Q ^ 2 := by gcongr
  have hB_eq :
      23 * ((1 + C_sched) ^ 2) * ((S : ℝ) ^ (3 + 2 * deg_sched)) =
        23 * (S : ℝ) ^ 3 * Q ^ 2 := by
    rw [← hQ_def, pow_add, pow_mul]
    ring
  rw [hB_eq]
  have hSQ_nonneg : 0 ≤ (S : ℝ) ^ 3 * Q ^ 2 := by positivity
  refine ⟨by linarith, by linarith, by linarith, by linarith, ?_⟩
  unfold ExecutionEventCounts.total
  dsimp only
  rw [Nat.cast_add, Nat.cast_add, Nat.cast_add]
  linarith

private lemma step_event_counts_poly_bound {d n k S : ℕ} {C_sched : ℝ} {deg_sched : ℕ}
    (hCS : 0 ≤ C_sched) (hS5 : 5 ≤ S)
    (hkS : n + (k + 1) + 1 ≤ S)
    (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ)
    (caps : CappedScheduleEventBounds)
    (st : Alg4State d ℕ) (upd : Alg4PointUpdate d ℕ) (choices : Alg4StepChoices d ℕ)
    (hpoly : caps.IsPolyBoundedInScale C_sched deg_sched S)
    (hbnd : BoundedAlg4State n k st)
    (hupd : IsValidAlg4PointUpdate n st upd)
    (hcap : choices.IsScheduleCapped caps) :
    let ev := alg4StepEventCounts mode α L reclaimMult caps st upd choices
    let B : ℝ := 23 * ((1 + C_sched) ^ 2) * ((S : ℝ) ^ (3 + 2 * deg_sched))
    (ev.centerConstructions : ℝ) ≤ B ∧
    (ev.filterConstructions : ℝ) ≤ B ∧
    (ev.verificationAttempts : ℝ) ≤ B ∧
    (ev.witnessSamples : ℝ) ≤ B ∧
    (ev.total : ℝ) ≤ B := by
  have hstep := alg4Step_preserves_bounded mode α L reclaimMult st upd choices hbnd hupd
  rcases hbnd with ⟨_, _, hlen, hjobs⟩
  rcases hstep with ⟨⟨_, _, hnext_len, _⟩, hleaf₁_le⟩
  dsimp only at hleaf₁_le
  have hl1_spec := alg4Line1ApplyToServingChain_spec (updateAlg4Coords st.coords upd) mode
    st.servingNodes st.terminalLeaf upd
    choices.servingRouteQueries choices.servingRadiusMaxHints
  dsimp only at hl1_spec
  have hst_S : st.servingNodes.length ≤ 2 * S ^ 2 :=
    serving_len_le_two_S_sq hlen (by omega) (by omega)
  dsimp only
  unfold alg4StepEventCounts
  dsimp only
  generalize hnext_eq : (alg4Step mode α L reclaimMult st upd choices).1 = nextSt at hnext_len ⊢
  clear hnext_eq
  have hnext_S : nextSt.servingNodes.length ≤ 2 * S ^ 2 :=
    serving_len_le_two_S_sq hnext_len (by omega) hkS
  rcases hl1_eq :
    alg4Line1ApplyToServingChain (updateAlg4Coords st.coords upd) mode
      st.servingNodes st.terminalLeaf upd
      choices.servingRouteQueries choices.servingRadiusMaxHints
      with ⟨nodesLine1, leafLine1, leafTicked⟩
  rw [hl1_eq] at hl1_spec hleaf₁_le
  dsimp only at hl1_spec hleaf₁_le ⊢
  clear hl1_eq
  generalize hl26_eq :
    alg4Lines2To6StepPendingJobs (updateAlg4Coords st.coords upd) mode α L
      (applyAlg4PointSetUpdate st.activeSet upd) nodesLine1 choices.pendingJobChoices = nodes26
      at hleaf₁_le ⊢
  clear hl26_eq
  rcases hl78_eq :
    alg4Lines7To8InstallCompletedJobs nodes26 leafLine1
      st.terminalLeafAnswer st.terminalLeafDistSq leafTicked
      with ⟨n78, l78, a78, s78, c78, r78⟩
  rw [hl78_eq] at hleaf₁_le
  dsimp only at hleaf₁_le ⊢
  clear hl78_eq
  rcases hdue_eq :
    startDueServingJobsAux (updateAlg4Coords st.coords upd) α L
      (applyAlg4PointSetUpdate st.activeSet upd) n78 l78 a78 s78 c78
      with ⟨nDue, leaf₁, aDue, sDue, cDue, rDue⟩
  rw [hdue_eq] at hleaf₁_le
  dsimp only at hleaf₁_le ⊢
  clear hdue_eq
  have hleaf₁_S : leaf₁.card ≤ S := hleaf₁_le.trans (by omega)
  have hreb_bound :
      (if 6 * L < leaf₁.card then
        (rebuildOversizedLeafAux (updateAlg4Coords st.coords upd) mode α L
          leaf₁.card leaf₁ choices.leafRebuildChoices).1.length
      else 0) ≤ S := by
    by_cases hgt : 6 * L < leaf₁.card
    · rw [if_pos hgt]
      have hreb := (rebuildOversizedLeafAux_spec (updateAlg4Coords st.coords upd) mode α L
        leaf₁.card leaf₁ choices.leafRebuildChoices).1
      exact hreb.trans hleaf₁_S
    · rw [if_neg hgt]
      exact Nat.zero_le _
  generalize hl9_eq :
    (if 6 * L < leaf₁.card then
      (rebuildOversizedLeafAux (updateAlg4Coords st.coords upd) mode α L
        leaf₁.card leaf₁ choices.leafRebuildChoices).1.length
    else 0) = line9Opened at hreb_bound ⊢
  clear hl9_eq
  have hpend_le :
      (nodesLine1.map (fun pair =>
        match pair.1.ownedJob with
        | none => 0
        | some job => job.completedPrefix.length)).sum ≤ 2 * S ^ 3 := by
    have hsum :
        (nodesLine1.map (fun pair =>
          match pair.1.ownedJob with
          | none => 0
          | some job => job.completedPrefix.length)).sum ≤ nodesLine1.length * k := by
      refine list_map_sum_le nodesLine1 _ k (fun pair hp => ?_)
      rcases hl1_spec.2.1 pair hp with ⟨sn, hsn, heq⟩
      rw [heq]
      cases hown : sn.ownedJob with
      | none => simp
      | some job => exact (hjobs sn hsn job hown).2
    rw [hl1_spec.1] at hsum
    have hk_S : k ≤ S := by omega
    have hmul : st.servingNodes.length * k ≤ (2 * S ^ 2) * S := Nat.mul_le_mul hst_S hk_S
    have hmul2 : (2 * S ^ 2) * S = 2 * S ^ 3 := by ring
    exact hsum.trans (hmul2 ▸ hmul)
  have hsamp_le :
      ((choices.baselineSamples.take nextSt.servingNodes.length).map List.length).sum ≤
        2 * S ^ 2 * caps.K0 := by
    have h1 :
        ((choices.baselineSamples.take nextSt.servingNodes.length).map List.length).sum ≤
          (choices.baselineSamples.take nextSt.servingNodes.length).length * caps.K0 := by
      refine list_map_sum_le _ _ caps.K0 (fun samps hs => ?_)
      exact hcap.1 samps (List.mem_of_mem_take hs)
    have h2 : (choices.baselineSamples.take nextSt.servingNodes.length).length ≤
        nextSt.servingNodes.length := List.length_take_le _ _
    exact h1.trans (Nat.mul_le_mul_right caps.K0 (h2.trans hnext_S))
  have hline5_le :
      (List.zip nodesLine1 nodes26).countP (fun pair =>
        match pair.1.1.ownedJob, pair.2.1.ownedJob with
        | some jBefore, some jAfter =>
            decide (jBefore.completedPrefix.length < jAfter.completedPrefix.length)
        | _, _ => false) ≤ 2 * S ^ 2 := by
    refine List.countP_le_length.trans ?_
    rw [List.length_zip]
    exact (Nat.min_le_left _ _).trans (hl1_spec.1.le.trans hst_S)
  have hcenters_le :
      (List.zip nodesLine1 nodes26).countP (fun pair =>
        match pair.1.1.ownedJob, pair.2.1.ownedJob with
        | some jBefore, some jAfter =>
            decide (jBefore.completedPrefix.length < jAfter.completedPrefix.length)
        | _, _ => false) + line9Opened ≤ 3 * S ^ 2 := by
    have hS_le_S2 : S ≤ S ^ 2 := Nat.le_self_pow (by omega) S
    have hsum2 : 2 * S ^ 2 + S ≤ 3 * S ^ 2 := by omega
    exact (Nat.add_le_add hline5_le hreb_bound).trans hsum2
  exact poly_arith_helper hCS hS5 _ _
    st.servingNodes.length line9Opened leaf₁.card _ caps hpoly
    hcenters_le hpend_le hst_S hreb_bound hleaf₁_S hsamp_le

private lemma event_counts_step_arith (len : ℕ) (B : ℝ) (c1 c2 : ExecutionEventCounts)
    (h1 : (c1.centerConstructions : ℝ) ≤ B ∧ (c1.filterConstructions : ℝ) ≤ B ∧
          (c1.verificationAttempts : ℝ) ≤ B ∧ (c1.witnessSamples : ℝ) ≤ B ∧ (c1.total : ℝ) ≤ B)
    (h2 : (c2.centerConstructions : ℝ) ≤ (len : ℝ) * B ∧
          (c2.filterConstructions : ℝ) ≤ (len : ℝ) * B ∧
          (c2.verificationAttempts : ℝ) ≤ (len : ℝ) * B ∧
          (c2.witnessSamples : ℝ) ≤ (len : ℝ) * B ∧ (c2.total : ℝ) ≤ (len : ℝ) * B) :
    let c := ExecutionEventCounts.add c1 c2
    (c.centerConstructions : ℝ) ≤ ((len + 1 : ℕ) : ℝ) * B ∧
    (c.filterConstructions : ℝ) ≤ ((len + 1 : ℕ) : ℝ) * B ∧
    (c.verificationAttempts : ℝ) ≤ ((len + 1 : ℕ) : ℝ) * B ∧
    (c.witnessSamples : ℝ) ≤ ((len + 1 : ℕ) : ℝ) * B ∧
    (c.total : ℝ) ≤ ((len + 1 : ℕ) : ℝ) * B := by
  dsimp only
  unfold ExecutionEventCounts.add
  unfold ExecutionEventCounts.total at h1 h2 ⊢
  dsimp only at h1 h2 ⊢
  push_cast at h1 h2 ⊢
  exact ⟨by linarith, by linarith, by linarith, by linarith, by linarith⟩

private lemma totalAlg4EventCounts_aux {d n S : ℕ} {C_sched : ℝ} {deg_sched : ℕ}
    (hCS : 0 ≤ C_sched) (hS5 : 5 ≤ S)
    (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ)
    (caps : CappedScheduleEventBounds)
    (hpoly : caps.IsPolyBoundedInScale C_sched deg_sched S)
    (steps : List (Alg4PointUpdate d ℕ × Alg4StepChoices d ℕ)) :
    ∀ (k : ℕ) (cur : Alg4State d ℕ),
      n + k + steps.length + 1 ≤ S →
      BoundedAlg4State n k cur →
      ValidAlg4UpdateList n mode α L reclaimMult cur steps →
      (∀ pair ∈ steps, pair.2.IsScheduleCapped caps) →
      let counts := totalAlg4EventCounts mode α L reclaimMult caps cur steps
      let B_step : ℝ := 23 * ((1 + C_sched) ^ 2) * ((S : ℝ) ^ (3 + 2 * deg_sched))
      (counts.centerConstructions : ℝ) ≤ (steps.length : ℝ) * B_step ∧
      (counts.filterConstructions : ℝ) ≤ (steps.length : ℝ) * B_step ∧
      (counts.verificationAttempts : ℝ) ≤ (steps.length : ℝ) * B_step ∧
      (counts.witnessSamples : ℝ) ≤ (steps.length : ℝ) * B_step ∧
      (counts.total : ℝ) ≤ (steps.length : ℝ) * B_step := by
  induction steps with
  | nil =>
    intro _ cur _ _ _ _
    simp [totalAlg4EventCounts, ExecutionEventCounts.total]
  | cons hd rest ih =>
    rcases hd with ⟨upd, ch⟩
    intro k cur hkS hbnd hval hcap
    rcases hval with ⟨hupd, hval_rest⟩
    simp only [List.length_cons] at hkS
    have hstep_bnd := (alg4Step_preserves_bounded mode α L reclaimMult cur upd ch hbnd hupd).1
    have hone := step_event_counts_poly_bound hCS hS5 (by omega) mode α L reclaimMult
      caps cur upd ch hpoly hbnd hupd (hcap (upd, ch) List.mem_cons_self)
    have hrec := ih (k + 1) (alg4Step mode α L reclaimMult cur upd ch).1
      (by omega) hstep_bnd hval_rest (fun p hp => hcap p (List.mem_cons_of_mem _ hp))
    dsimp only at hone hrec ⊢
    unfold totalAlg4EventCounts
    dsimp only [List.length_cons]
    exact event_counts_step_arith rest.length _ _ _ hone hrec

theorem part1_failure_budget :
    ((∀ (n t d B : ℕ) (δ : ℝ),
        2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
          execFailureScaleArith n t d δ = execFailureScaleBit n t d 0 δ ∧
          5 ≤ execFailureScaleBit n t d B δ) ∧
      ∀ (C_sched : ℝ) (deg_sched : ℕ), 0 ≤ C_sched →
        ∃ (C_ev : ℝ) (deg_ev : ℕ), 0 ≤ C_ev ∧
          ∀ (d n t B : ℕ) (δ : ℝ),
            2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
              let S := execFailureScaleBit n t d B δ
              ∀ (mode : Alg4Mode) (α : ℝ) (L reclaimMult : ℕ)
                (caps : CappedScheduleEventBounds)
                (steps : List (Alg4PointUpdate d ℕ × Alg4StepChoices d ℕ)),
                caps.IsPolyBoundedInScale C_sched deg_sched S →
                (∀ V : ℝ, (mode.retainedConfigs V).card ≤ caps.retainedConfigCap) →
                steps.length ≤ t →
                ValidAlg4UpdateList n mode α L reclaimMult (Alg4State.empty d ℕ) steps →
                (∀ pair ∈ steps, pair.2.IsScheduleCapped caps) →
                  let counts :=
                    totalAlg4EventCounts mode α L reclaimMult caps (Alg4State.empty d ℕ) steps
                  (counts.centerConstructions : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) ∧
                  (counts.filterConstructions : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) ∧
                  (counts.verificationAttempts : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) ∧
                  (counts.witnessSamples : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) ∧
                  (counts.total : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev)) := by
  refine ⟨?_, ?_⟩
  · intro n t d B δ hn ht _ _
    unfold execFailureScaleArith execFailureScaleBit
    omega
  · intro C_sched deg_sched hCS
    refine ⟨23 * ((1 + C_sched) ^ 2), 4 + 2 * deg_sched, by positivity, ?_⟩
    intro d n t B δ hn ht _ _
    dsimp only
    set S := execFailureScaleBit n t d B δ
    have hS_def : S = n + t + d + B + Nat.ceil (Real.log (2 / δ)) + 2 := rfl
    have hS5 : 5 ≤ S := by omega
    intro mode α L reclaimMult caps steps hpoly _ hsteps_t hval hcap
    have haux := totalAlg4EventCounts_aux hCS hS5 mode α L reclaimMult caps hpoly
      steps 0 (Alg4State.empty d ℕ) (by omega) (boundedAlg4State_empty d n) hval hcap
    dsimp only at haux ⊢
    set B_step : ℝ := 23 * ((1 + C_sched) ^ 2) * ((S : ℝ) ^ (3 + 2 * deg_sched))
    have hB_nonneg : 0 ≤ B_step := by positivity
    have hlen_le_S : (steps.length : ℝ) ≤ (S : ℝ) := by
      have : steps.length ≤ S := by omega
      exact_mod_cast this
    have hmul : (steps.length : ℝ) * B_step ≤
        (23 * ((1 + C_sched) ^ 2)) * ((S : ℝ) ^ (4 + 2 * deg_sched)) := by
      calc
        (steps.length : ℝ) * B_step ≤ (S : ℝ) * B_step := by gcongr
        _ = (23 * ((1 + C_sched) ^ 2)) * ((S : ℝ) * (S : ℝ) ^ (3 + 2 * deg_sched)) := by
          dsimp only [B_step]; ring
        _ = (23 * ((1 + C_sched) ^ 2)) * ((S : ℝ) ^ (4 + 2 * deg_sched)) := by
          have hexp : 4 + 2 * deg_sched = (3 + 2 * deg_sched) + 1 := by omega
          rw [hexp, pow_succ]
          ring
    exact ⟨haux.1.trans hmul, haux.2.1.trans hmul, haux.2.2.1.trans hmul,
      haux.2.2.2.1.trans hmul, haux.2.2.2.2.trans hmul⟩

end UL.Proof_clm_7_3_failure_budget
