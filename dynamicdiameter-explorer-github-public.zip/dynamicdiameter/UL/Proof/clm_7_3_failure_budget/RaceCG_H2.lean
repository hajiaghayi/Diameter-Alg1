import UL.Stmt.clm_7_3_failure_budget
import UL.Proof.lem_7_1.RaceV31_H1_Coins
set_option autoImplicit false

namespace UL.Proof_clm_7_3_failure_budget_cg_H2

open scoped ENNReal BigOperators
open UL.Proof_lem_7_1_RaceV31

/-! ### 1. Equivalence of Prefix-Free Formulations & `seqConsumeCoin` -/

lemma isPrefixFree_iff_append_none {α : Type*} (f : List Bool → Option α) :
    IsPrefixFree f ↔ ∀ u v : List Bool, (f u).isSome → v ≠ [] → f (u ++ v) = none := by
  constructor
  · intro hf u v hu hv
    rcases Option.isSome_iff_exists.mp hu with ⟨a₁, h₁⟩
    cases h₂ : f (u ++ v) with
    | none => rfl
    | some a₂ =>
        have hEq := hf u (u ++ v) a₁ a₂ h₁ h₂ ⟨v, rfl⟩
        have hLen := congrArg List.length hEq
        rw [List.length_append] at hLen
        have hv0 : v.length = 0 := by omega
        exact False.elim (hv (List.length_eq_zero_iff.mp hv0))
  · intro h bs₁ bs₂ a₁ a₂ h₁ h₂ hpref
    rcases hpref with ⟨w, rfl⟩
    by_cases hw : w = []
    · simp [hw]
    · have hnone := h bs₁ w (by simp [h₁]) hw
      rw [h₂] at hnone
      cases hnone

private theorem filterMap_head?_unique {β : Type*} (g : ℕ → Option β) (y : β) :
    ∀ (l : List ℕ) (k₀ : ℕ),
      k₀ ∈ l →
      g k₀ = some y →
      (∀ k ∈ l, k ≠ k₀ → g k = none) →
      (l.filterMap g).head? = some y
  | [], _, hmem, _, _ => by simp at hmem
  | hd :: tl, k₀, hmem, hgk₀, hother => by
      by_cases hne : hd = k₀
      · subst hne
        simp [List.filterMap_cons, hgk₀]
      · have hnone : g hd = none := hother hd List.mem_cons_self hne
        have hmem_tl : k₀ ∈ tl := by
          rcases List.mem_cons.mp hmem with rfl | htl
          · exact absurd rfl hne
          · exact htl
        simp only [List.filterMap_cons, hnone]
        exact filterMap_head?_unique g y tl k₀ hmem_tl hgk₀
          (fun k hk => hother k (List.mem_cons_of_mem _ hk))

lemma consumePrefixCoinList_append_of_prefixFree {Out : Type} {f : List Bool → Option Out}
    (hf : IsPrefixFree f) {bs₁ rem : List Bool} {a : Out} (hfa : f bs₁ = some a) :
    consumePrefixCoinList f (bs₁ ++ rem) = some (a, rem) := by
  unfold consumePrefixCoinList
  dsimp only
  let full := bs₁ ++ rem
  let g : ℕ → Option (Out × List Bool) := fun k =>
    match f (full.take k) with
    | some v => some (v, full.drop k)
    | none => none
  change ((List.range (full.length + 1)).filterMap g).head? = some (a, rem)
  refine filterMap_head?_unique g (a, rem) (List.range (full.length + 1)) bs₁.length ?_ ?_ ?_
  · rw [List.mem_range]
    have : full.length = bs₁.length + rem.length := List.length_append
    omega
  · dsimp only [g, full]
    rw [List.take_append_of_le_length le_rfl, List.take_length,
        List.drop_append_of_le_length le_rfl, List.drop_length, List.nil_append, hfa]
  · intro k hk hne
    rw [List.mem_range] at hk
    dsimp only [g]
    cases hfk : f (full.take k) with
    | none => rfl
    | some v =>
        exfalso
        have hfull_len : full.length = bs₁.length + rem.length := List.length_append
        have hlen_take : (full.take k).length = k := List.length_take_of_le (by omega)
        rcases Nat.lt_or_gt_of_ne hne with hlt | hgt
        · have hpref : full.take k <+: bs₁ := by
            have h1 : full.take k = bs₁.take k := List.take_append_of_le_length (by omega)
            rw [h1]
            exact List.take_prefix k bs₁
          have heq := hf (full.take k) bs₁ v a hfk hfa hpref
          have := congrArg List.length heq
          omega
        · have hpref : bs₁ <+: full.take k := by
            have h1 : bs₁ = (full.take k).take bs₁.length := by
              rw [List.take_take, Nat.min_eq_left (by omega)]
              simp [full]
            rw [h1]
            exact List.take_prefix bs₁.length (full.take k)
          have heq := hf bs₁ (full.take k) a v hfa hfk hpref
          have := congrArg List.length heq
          omega

lemma consumePrefixCoinList_eq_some_iff {Out : Type} {f : List Bool → Option Out}
    (hf : IsPrefixFree f) {bs rem : List Bool} {a : Out} :
    consumePrefixCoinList f bs = some (a, rem) ↔
      ∃ bs₁ : List Bool, bs = bs₁ ++ rem ∧ f bs₁ = some a := by
  constructor
  · intro h
    unfold consumePrefixCoinList at h
    dsimp only at h
    set g : ℕ → Option (Out × List Bool) := fun k =>
      match f (bs.take k) with
      | some v => some (v, bs.drop k)
      | none => none
    change ((List.range (bs.length + 1)).filterMap g).head? = some (a, rem) at h
    cases hlist : (List.range (bs.length + 1)).filterMap g with
    | nil => rw [hlist] at h; simp at h
    | cons hd tl =>
        rw [hlist, List.head?_cons, Option.some.injEq] at h
        have hmem : (a, rem) ∈ (List.range (bs.length + 1)).filterMap g := by
          rw [hlist, ← h]; simp
        rcases List.mem_filterMap.mp hmem with ⟨k, _, hk⟩
        dsimp only [g] at hk
        cases hfk : f (bs.take k) with
        | none => simp [hfk] at hk
        | some v =>
            simp only [hfk, Option.some.injEq, Prod.mk.injEq] at hk
            rcases hk with ⟨rfl, rfl⟩
            exact ⟨bs.take k, (List.take_append_drop k bs).symm, hfk⟩
  · rintro ⟨bs₁, rfl, hfa⟩
    exact consumePrefixCoinList_append_of_prefixFree hf hfa

noncomputable def seqConsumeCoin {α β : Type}
    (f : List Bool → Option α) (g : α → List Bool → Option β) (bs : List Bool) : Option β :=
  match consumePrefixCoinList f bs with
  | none => none
  | some (a, rem') => g a rem'

lemma seqConsumeCoin_eq_seqConsume {α β : Type} {f : List Bool → Option α}
    (hf : IsPrefixFree f) (g : α → List Bool → Option β) (bs : List Bool) :
    seqConsumeCoin f g bs = seqConsume f g bs := by
  unfold seqConsumeCoin seqConsume
  cases hc1 : consumePrefixCoinList f bs with
  | none =>
      cases hc2 : UL.consumePrefixBits f bs with
      | none => rfl
      | some p =>
          rcases (consumePrefixBits_eq_some_iff hf).mp hc2 with ⟨bs₁, rfl, hfa⟩
          rw [consumePrefixCoinList_append_of_prefixFree hf hfa] at hc1
          cases hc1
  | some p =>
      rcases p with ⟨a, rem⟩
      rcases (consumePrefixCoinList_eq_some_iff hf).mp hc1 with ⟨bs₁, rfl, hfa⟩
      rw [consumePrefixBits_append_of_prefixFree hf hfa]

/-! ### 2. Conjunct (3a) & (3b): `C₁` Selection and `runRepeatedCappedAttempts` -/

private lemma nat_cast_le_two_pow : ∀ m : ℕ, (m : ℝ) ≤ (2 : ℝ) ^ m
  | 0 => by norm_num
  | m + 1 => by
      have ih := nat_cast_le_two_pow m
      have h1 : (1 : ℝ) ≤ (2 : ℝ) ^ m := one_le_pow₀ (by norm_num)
      push_cast
      rw [pow_succ]
      linarith

lemma fb_conj3a :
    ∀ (C_ev : ℝ) (deg_ev : ℕ), 0 ≤ C_ev →
      ∃ C₁ : ℕ, 1 ≤ C₁ ∧
        ∀ (d n t B : ℕ) (δ : ℝ),
          2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
            let S := execFailureScaleBit n t d B δ
            let φ := perEventFailureBudget S C₁ δ
            0 < φ ∧ φ < δ ∧
            (C_ev * ((S : ℝ) ^ deg_ev)) * φ ≤ δ := by
  intro C_ev deg_ev hC_ev
  let k : ℕ := Nat.ceil C_ev
  refine ⟨deg_ev + k + 1, by omega, ?_⟩
  intro d n t B δ hn ht hδ0 _ S φ
  have hS5_nat : 5 ≤ S := by unfold S execFailureScaleBit; omega
  have hS5 : (5 : ℝ) ≤ (S : ℝ) := by exact_mod_cast hS5_nat
  have hS_gt1 : (1 : ℝ) < (S : ℝ) := by linarith
  have hSpow_gt1 : (1 : ℝ) < (S : ℝ) ^ (deg_ev + k + 1) :=
    one_lt_pow₀ hS_gt1 (by omega)
  have hSpow_pos : (0 : ℝ) < (S : ℝ) ^ (deg_ev + k + 1) := by linarith
  have hφ_pos : 0 < φ := div_pos hδ0 hSpow_pos
  have hφ_lt : φ < δ := div_lt_self hδ0 hSpow_gt1
  have hC_le_k : C_ev ≤ (k : ℝ) := Nat.le_ceil C_ev
  have hk_le_2k : (k : ℝ) ≤ (2 : ℝ) ^ k := nat_cast_le_two_pow k
  have h2k_le_Sk : (2 : ℝ) ^ k ≤ (S : ℝ) ^ k :=
    pow_le_pow_left₀ (by norm_num) (by linarith) k
  have hC_le_Sk : C_ev ≤ (S : ℝ) ^ k := (hC_le_k.trans hk_le_2k).trans h2k_le_Sk
  have hProd_le : C_ev * ((S : ℝ) ^ deg_ev) ≤ (S : ℝ) ^ (deg_ev + k + 1) := by
    calc
      C_ev * ((S : ℝ) ^ deg_ev) ≤ (S : ℝ) ^ k * (S : ℝ) ^ deg_ev :=
        mul_le_mul_of_nonneg_right hC_le_Sk (by positivity)
      _ = (S : ℝ) ^ (deg_ev + k) * 1 := by rw [← pow_add, add_comm, mul_one]
      _ ≤ (S : ℝ) ^ (deg_ev + k) * (S : ℝ) :=
        mul_le_mul_of_nonneg_left (by linarith) (by positivity)
      _ = (S : ℝ) ^ (deg_ev + k + 1) := by rw [← pow_succ]
  refine ⟨hφ_pos, hφ_lt, ?_⟩
  dsimp [φ, perEventFailureBudget]
  rw [← mul_div_assoc, div_le_iff₀ hSpow_pos]
  nlinarith

private lemma repeatedAttempts_ind {Out : Type}
    (attempt : List Bool → Option (Out × ℕ × ℕ))
    (isGood : Out → Prop) (fallback : Out) (W_cap Sp_cap : ℕ)
    (q : ENNReal)
    (hPF : IsPrefixFree attempt)
    (hHalt : haltProb attempt = 1)
    (hCap : ∀ (u : List Bool) (val : Out) (w sp : ℕ),
      attempt u = some (val, w, sp) → w ≤ W_cap ∧ sp ≤ Sp_cap)
    (hFail1 : expWithBits attempt (fun vws => open Classical in if ¬ isGood vws.1 then 1 else 0) ≤ q) :
    ∀ (k accW maxSp : ℕ),
      let boosted := runRepeatedCappedAttempts attempt isGood fallback k accW maxSp
      IsPrefixFree boosted ∧
      haltProb boosted = 1 ∧
      (∀ (u : List Bool) (val : Out) (ok : Bool) (w sp : ℕ),
        boosted u = some (val, ok, w, sp) →
          w ≤ accW + k * W_cap ∧ sp ≤ max maxSp Sp_cap ∧ (ok = true → isGood val)) ∧
      expWithBits boosted (fun out => if out.2.1 = false then 1 else 0) ≤ q ^ k
  | 0, accW, maxSp => by
      have hEq : runRepeatedCappedAttempts attempt isGood fallback 0 accW maxSp =
          endWithEmpty (fallback, false, accW, maxSp) := by
        funext bs
        cases bs <;> rfl
      refine ⟨?_, ?_, ?_, ?_⟩
      · rw [hEq]; exact isPrefixFree_endWithEmpty _
      · rw [hEq]; exact haltProb_endWithEmpty _
      · intro u val ok w sp hu
        rw [hEq, endWithEmpty_eq_some_iff] at hu
        rcases hu with ⟨_, hEqTup⟩
        injection hEqTup with _ h2
        injection h2 with hOk h3
        injection h3 with hW hSp
        subst hOk hW hSp
        exact ⟨by omega, le_max_left _ _, fun h => by cases h⟩
      · rw [hEq, expWithBits_endWithEmpty]
        simp
  | k + 1, accW, maxSp => by
      classical
      let g : (Out × ℕ × ℕ) → List Bool → Option (Out × Bool × ℕ × ℕ) :=
        fun vws rem =>
          if isGood vws.1 then
            endWithEmpty (vws.1, true, accW + vws.2.1, max maxSp vws.2.2) rem
          else
            runRepeatedCappedAttempts attempt isGood fallback k (accW + vws.2.1) (max maxSp vws.2.2) rem
      have hEq : runRepeatedCappedAttempts attempt isGood fallback (k + 1) accW maxSp =
          seqConsume attempt g := by
        funext bs
        rw [← seqConsumeCoin_eq_seqConsume hPF g bs]
        unfold runRepeatedCappedAttempts seqConsumeCoin g
        cases consumePrefixCoinList attempt bs with
        | none => rfl
        | some pair =>
            rcases pair with ⟨⟨v, w, sp⟩, rem⟩
            dsimp only
            unfold endWithEmpty
            split_ifs <;> rfl
      have hIH_all : ∀ (w sp : ℕ),
          let bk := runRepeatedCappedAttempts attempt isGood fallback k (accW + w) (max maxSp sp)
          IsPrefixFree bk ∧
          haltProb bk = 1 ∧
          (∀ (u : List Bool) (val : Out) (ok : Bool) (w' sp' : ℕ),
            bk u = some (val, ok, w', sp') →
              w' ≤ (accW + w) + k * W_cap ∧ sp' ≤ max (max maxSp sp) Sp_cap ∧ (ok = true → isGood val)) ∧
          expWithBits bk (fun out => if out.2.1 = false then 1 else 0) ≤ q ^ k :=
        fun w sp => repeatedAttempts_ind attempt isGood fallback W_cap Sp_cap q
          hPF hHalt hCap hFail1 k (accW + w) (max maxSp sp)
      have hgPF : ∀ bs₁ vws, attempt bs₁ = some vws → IsPrefixFree (g vws) := by
        intro bs₁ ⟨v, w, sp⟩ _
        dsimp [g]
        split_ifs
        · exact isPrefixFree_endWithEmpty _
        · exact (hIH_all w sp).1
      have hgHalt : ∀ bs₁ vws, attempt bs₁ = some vws → haltProb (g vws) = 1 := by
        intro bs₁ ⟨v, w, sp⟩ _
        dsimp [g]
        split_ifs
        · exact haltProb_endWithEmpty _
        · exact (hIH_all w sp).2.1
      refine ⟨?_, ?_, ?_, ?_⟩
      · rw [hEq]; exact isPrefixFree_seqConsume hPF hgPF
      · rw [hEq]; exact haltProb_seqConsume hPF hHalt hgHalt
      · intro u val ok w' sp' hu
        rw [hEq, seqConsume_eq_some_iff hPF] at hu
        rcases hu with ⟨bs₁, bs₂, ⟨v, w, sp⟩, _, hatt, hg⟩
        obtain ⟨hwCap, hspCap⟩ := hCap bs₁ v w sp hatt
        dsimp [g] at hg
        split_ifs at hg with hgv
        · rw [endWithEmpty_eq_some_iff] at hg
          rcases hg with ⟨_, hTup⟩
          injection hTup with hV h2
          injection h2 with hOk h3
          injection h3 with hW hSp
          subst hV hOk hW hSp
          refine ⟨?_, ?_, fun _ => hgv⟩
          · calc accW + w ≤ accW + W_cap := by omega
              _ ≤ accW + (k + 1) * W_cap := by nlinarith
          · exact max_le_max le_rfl hspCap
        · obtain ⟨hw_ih, hsp_ih, hok_ih⟩ := (hIH_all w sp).2.2.1 bs₂ val ok w' sp' hg
          refine ⟨?_, ?_, hok_ih⟩
          · calc w' ≤ (accW + w) + k * W_cap := hw_ih
              _ ≤ (accW + W_cap) + k * W_cap := by omega
              _ = accW + (k + 1) * W_cap := by ring
          · calc sp' ≤ max (max maxSp sp) Sp_cap := hsp_ih
              _ = max maxSp (max sp Sp_cap) := max_assoc _ _ _
              _ = max maxSp Sp_cap := by rw [max_eq_right hspCap]
      · rw [hEq, expWithBits_seqConsume hPF]
        calc
          expWithBits attempt (fun vws => expWithBits (g vws) (fun out => if out.2.1 = false then 1 else 0))
              ≤ expWithBits attempt (fun vws => (if ¬ isGood vws.1 then (1 : ENNReal) else 0) * q ^ k) := by
                refine expWithBits_mono fun bs₁ ⟨v, w, sp⟩ _ => ?_
                dsimp [g]
                split_ifs with hgv
                · rw [expWithBits_endWithEmpty]; simp
                · simp only [hgv, not_false_eq_true, ↓reduceIte, one_mul]
                  exact (hIH_all w sp).2.2.2
          _ = expWithBits attempt (fun vws => if ¬ isGood vws.1 then 1 else 0) * q ^ k :=
                expWithBits_mul_const _ _ _
          _ ≤ q * q ^ k := mul_le_mul_of_nonneg_right hFail1 (zero_le _)
          _ = q ^ (k + 1) := by rw [pow_succ']

open Classical in
lemma fb_conj3b :
    ∀ (p₀ : ℝ) (C₁ : ℕ), 0 < p₀ → p₀ ≤ 1 → 1 ≤ C₁ →
      ∃ C_try : ℝ, 0 < C_try ∧
        ∀ (d n t B : ℕ) (δ : ℝ),
          2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
            let S := execFailureScaleBit n t d B δ
            let φ := perEventFailureBudget S C₁ δ
            ∃ K_try : ℕ,
              1 ≤ K_try ∧
              (K_try : ℝ) ≤ C_try * Real.log ((S : ℝ) / δ) ∧
              (1 - p₀) ^ K_try ≤ φ ∧
              ∀ (Out : Type) (attempt : List Bool → Option (Out × ℕ × ℕ))
                (isGood : Out → Prop) (fallback : Out) (W_cap Sp_cap : ℕ),
                (∀ u v : List Bool, (attempt u).isSome → v ≠ [] → attempt (u ++ v) = none) →
                (∑' u : List Bool, if (attempt u).isSome then bitListProb u else 0) = 1 →
                (∀ (u : List Bool) (val : Out) (w sp : ℕ),
                  attempt u = some (val, w, sp) → w ≤ W_cap ∧ sp ≤ Sp_cap) →
                ENNReal.ofReal p₀ ≤
                  (open Classical in
                    ∑' u : List Bool,
                      match attempt u with
                      | some (val, _, _) => if isGood val then bitListProb u else 0
                      | none => 0) →
                let boosted := runRepeatedCappedAttempts attempt isGood fallback K_try 0 0
                (∀ u v : List Bool, (boosted u).isSome → v ≠ [] → boosted (u ++ v) = none) ∧
                (∑' u : List Bool, if (boosted u).isSome then bitListProb u else 0) = 1 ∧
                (∀ (u : List Bool) (val : Out) (ok : Bool) (w sp : ℕ),
                  boosted u = some (val, ok, w, sp) →
                    w ≤ K_try * W_cap ∧ sp ≤ Sp_cap ∧ (ok = true → isGood val)) ∧
                (∑' u : List Bool,
                  match boosted u with
                  | some (_, ok, _, _) => if ok = false then bitListProb u else 0
                  | none => 0) ≤ ENNReal.ofReal φ := by
  intro p₀ C₁ hp₀0 hp₀1 hC₁
  let C₀ : ℝ := (C₁ : ℝ) / p₀
  have hC₀_pos : 0 < C₀ := div_pos (by exact_mod_cast (show 0 < C₁ by omega)) hp₀0
  refine ⟨C₀ + 1, by linarith, ?_⟩
  intro d n t B δ hn ht hδ0 hδ1 S φ
  have hS5_nat : 5 ≤ S := by unfold S execFailureScaleBit; omega
  have hS5 : (5 : ℝ) ≤ (S : ℝ) := by exact_mod_cast hS5_nat
  have hSdiv_ge10 : (10 : ℝ) ≤ (S : ℝ) / δ := by
    rw [le_div_iff₀ hδ0]
    linarith
  have hexp1_le : Real.exp 1 ≤ (S : ℝ) / δ := by
    have hexp3 : Real.exp 1 < 3 := Real.exp_one_lt_d9.trans (by norm_num)
    linarith
  have hlog_ge1 : 1 ≤ Real.log ((S : ℝ) / δ) := by
    have h1 := Real.log_le_log (Real.exp_pos 1) hexp1_le
    rwa [Real.log_exp] at h1
  let K_try : ℕ := Nat.ceil (C₀ * Real.log ((S : ℝ) / δ))
  have hK_pos : 1 ≤ K_try := by
    exact Nat.ceil_pos.mpr (mul_pos hC₀_pos (by linarith))
  have hK_ub : (K_try : ℝ) ≤ (C₀ + 1) * Real.log ((S : ℝ) / δ) := by
    have hceil : (K_try : ℝ) ≤ C₀ * Real.log ((S : ℝ) / δ) + 1 :=
      (Nat.ceil_lt_add_one (by positivity)).le
    linarith
  have hPow_le : (1 - p₀) ^ K_try ≤ φ := by
    have h1mp_nn : 0 ≤ 1 - p₀ := by linarith
    have h1mp_exp : 1 - p₀ ≤ Real.exp (-p₀) := by
      have := Real.add_one_le_exp (-p₀)
      linarith
    have hpow1 : (1 - p₀) ^ K_try ≤ (Real.exp (-p₀)) ^ K_try :=
      pow_le_pow_left₀ h1mp_nn h1mp_exp K_try
    rw [← Real.exp_nat_mul] at hpow1
    have hpK_lb : (C₁ : ℝ) * Real.log ((S : ℝ) / δ) ≤ p₀ * (K_try : ℝ) := by
      have hc : C₀ * Real.log ((S : ℝ) / δ) ≤ (K_try : ℝ) := Nat.le_ceil _
      have hpC : p₀ * C₀ = (C₁ : ℝ) := by dsimp [C₀]; field_simp
      nlinarith
    have hlog_S_pos : 0 < Real.log (S : ℝ) := Real.log_pos (by linarith)
    have hinv_gt1 : 1 < 1 / δ := by rw [lt_div_iff₀ hδ0]; linarith
    have hlog_inv_pos : 0 < Real.log (1 / δ) := Real.log_pos hinv_gt1
    have hC₁_ge1 : (1 : ℝ) ≤ (C₁ : ℝ) := by exact_mod_cast hC₁
    have hlog_split : Real.log ((S : ℝ) / δ) = Real.log (S : ℝ) + Real.log (1 / δ) := by
      have hEq : (S : ℝ) / δ = (S : ℝ) * (1 / δ) := by ring
      rw [hEq, Real.log_mul (by linarith) (by positivity)]
    have hTarget_lb : Real.log (((S : ℝ) ^ C₁) / δ) ≤ (C₁ : ℝ) * Real.log ((S : ℝ) / δ) := by
      have hEq : ((S : ℝ) ^ C₁) / δ = ((S : ℝ) ^ C₁) * (1 / δ) := by ring
      rw [hEq, Real.log_mul (by positivity) (by positivity), Real.log_pow, hlog_split]
      nlinarith
    have hNeg : Real.log (((S : ℝ) ^ C₁) / δ) ≤ p₀ * (K_try : ℝ) :=
      hTarget_lb.trans hpK_lb
    have hExp_le : Real.exp ((K_try : ℝ) * (-p₀)) ≤ φ := by
      have hφ_pos : 0 < φ := by dsimp [φ, perEventFailureBudget]; positivity
      have hinvφ : 1 / φ = ((S : ℝ) ^ C₁) / δ := by
        dsimp [φ, perEventFailureBudget]
        field_simp
      have hlogφ : -Real.log (((S : ℝ) ^ C₁) / δ) = Real.log φ := by
        rw [← hinvφ, one_div, Real.log_inv, neg_neg]
      rw [← Real.exp_log hφ_pos]
      apply Real.exp_le_exp.mpr
      rw [← hlogφ]
      linarith
    exact hpow1.trans hExp_le
  refine ⟨K_try, hK_pos, hK_ub, hPow_le, ?_⟩
  intro Out attempt isGood fallback W_cap Sp_cap hAttPF_raw hAttHalt hAttCap hAttGood
  classical
  have hAttPF : IsPrefixFree attempt := (isPrefixFree_iff_append_none attempt).mpr hAttPF_raw
  have hGoodEq :
      (∑' u : List Bool,
        match attempt u with
        | some (val, _, _) => if isGood val then bitListProb u else 0
        | none => 0) =
      expWithBits attempt (fun vws => if isGood vws.1 then 1 else 0) := by
    unfold expWithBits
    refine tsum_congr fun u => ?_
    cases attempt u with
    | none => rfl
    | some vws =>
        rcases vws with ⟨val, w, sp⟩
        dsimp only
        split_ifs <;> simp
  rw [hGoodEq] at hAttGood
  have hSum1 :
      expWithBits attempt (fun vws => if isGood vws.1 then 1 else 0) +
      expWithBits attempt (fun vws => if ¬ isGood vws.1 then 1 else 0) = 1 := by
    rw [← expWithBits_add]
    have h1 : (fun vws : Out × ℕ × ℕ =>
        (if isGood vws.1 then (1 : ENNReal) else 0) + (if ¬ isGood vws.1 then 1 else 0)) =
        fun _ => 1 := by
      ext vws; by_cases h : isGood vws.1 <;> simp [h]
    rw [h1, expWithBits_one_eq_haltProb]
    exact hAttHalt
  have hFail1 :
      expWithBits attempt (fun vws => if ¬ isGood vws.1 then 1 else 0) ≤
        ENNReal.ofReal (1 - p₀) := by
    have hAdd1 : ENNReal.ofReal p₀ + ENNReal.ofReal (1 - p₀) = 1 := by
      rw [← ENNReal.ofReal_add hp₀0.le (by linarith)]
      norm_num
    have hIneq :
        ENNReal.ofReal p₀ + expWithBits attempt (fun vws => if ¬ isGood vws.1 then 1 else 0) ≤
        ENNReal.ofReal p₀ + ENNReal.ofReal (1 - p₀) := by
      calc
        ENNReal.ofReal p₀ + expWithBits attempt (fun vws => if ¬ isGood vws.1 then 1 else 0)
            ≤ expWithBits attempt (fun vws => if isGood vws.1 then 1 else 0) +
                expWithBits attempt (fun vws => if ¬ isGood vws.1 then 1 else 0) :=
              by gcongr
        _ = 1 := hSum1
        _ = ENNReal.ofReal p₀ + ENNReal.ofReal (1 - p₀) := hAdd1.symm
    exact (ENNReal.add_le_add_iff_left ENNReal.ofReal_ne_top).mp hIneq
  have hInd := repeatedAttempts_ind attempt isGood fallback W_cap Sp_cap
    (ENNReal.ofReal (1 - p₀)) hAttPF hAttHalt hAttCap hFail1 K_try 0 0
  rcases hInd with ⟨hbPF, hbHalt, hbBounds, hbFail⟩
  refine ⟨(isPrefixFree_iff_append_none _).mp hbPF, hbHalt, ?_, ?_⟩
  · intro u val ok w sp hu
    obtain ⟨hw, hsp, hok⟩ := hbBounds u val ok w sp hu
    exact ⟨by omega, by simpa using hsp, hok⟩
  · have hbFailEq :
        (∑' u : List Bool,
          match runRepeatedCappedAttempts attempt isGood fallback K_try 0 0 u with
          | some (_, ok, _, _) => if ok = false then bitListProb u else 0
          | none => 0) =
        expWithBits (runRepeatedCappedAttempts attempt isGood fallback K_try 0 0)
          (fun out => if out.2.1 = false then 1 else 0) := by
      unfold expWithBits
      refine tsum_congr fun u => ?_
      cases runRepeatedCappedAttempts attempt isGood fallback K_try 0 0 u with
      | none => rfl
      | some out =>
          rcases out with ⟨val, ok, w, sp⟩
          dsimp only
          split_ifs <;> simp
    rw [hbFailEq]
    calc
      expWithBits (runRepeatedCappedAttempts attempt isGood fallback K_try 0 0)
          (fun out => if out.2.1 = false then 1 else 0)
          ≤ (ENNReal.ofReal (1 - p₀)) ^ K_try := hbFail
      _ = ENNReal.ofReal ((1 - p₀) ^ K_try) := by
            rw [ENNReal.ofReal_pow (by linarith)]
      _ ≤ ENNReal.ofReal φ := ENNReal.ofReal_le_ofReal hPow_le

/-! ### 3. Conjunct (3c): `uniformRankSampleTrial` -/

private def foldBits (acc : ℕ) (bs : List Bool) : ℕ :=
  bs.foldl (fun a b => 2 * a + if b then 1 else 0) acc

private lemma tsum_list_bool_cons (G : List Bool → ENNReal) (b : Bool) :
    (∑' bs : List Bool, if bs.head? = some b then G bs else 0) =
      ∑' tl : List Bool, G (b :: tl) := by
  let F : List Bool → ENNReal := fun bs => if bs.head? = some b then G bs else 0
  let H : List Bool → ENNReal := fun tl => G (b :: tl)
  change (∑' bs : List Bool, F bs) = ∑' tl : List Bool, H tl
  refine tsum_eq_tsum_of_ne_zero_bij (fun p : Function.support H => b :: p.1) ?_ ?_ ?_
  · rintro ⟨tl₁, _⟩ ⟨tl₂, _⟩ h
    exact Subtype.ext (List.cons.inj h).2
  · intro bs hbs
    have hbs' : F bs ≠ 0 := hbs
    cases bs with
    | nil => simp [F] at hbs'
    | cons b' tl =>
        by_cases hb : b' = b
        · subst hb
          simp only [F, List.head?_cons, ↓reduceIte] at hbs'
          exact ⟨⟨tl, hbs'⟩, rfl⟩
        · simp [F, hb] at hbs'
  · rintro ⟨tl, _⟩
    simp [F, H]

private lemma tsum_list_bool_split (G : List Bool → ENNReal) :
    (∑' bs : List Bool, G bs) =
      G [] + (∑' tl : List Bool, G (false :: tl)) + (∑' tl : List Bool, G (true :: tl)) := by
  have hSplit : ∀ bs : List Bool,
      G bs =
        ((if bs = [] then G [] else 0) +
         (if bs.head? = some false then G bs else 0)) +
        (if bs.head? = some true then G bs else 0) := by
    rintro (_ | ⟨_ | _, tl⟩) <;> simp
  have hNil : (∑' bs : List Bool, if bs = [] then G [] else 0) = G [] := by
    rw [tsum_eq_single []]
    · simp
    · intro bs hbs; exact if_neg hbs
  rw [tsum_congr hSplit, ENNReal.tsum_add, ENNReal.tsum_add,
      hNil, tsum_list_bool_cons G false, tsum_list_bool_cons G true]

private lemma tsum_fixed_len_foldBits :
    ∀ (k acc : ℕ) (F : ℕ → ENNReal),
      (∑' bs : List Bool, if bs.length = k then bitListProb bs * F (foldBits acc bs) else 0) =
        ((2 : ENNReal)⁻¹) ^ k * ∑ j ∈ Finset.range (2 ^ k), F (acc * 2 ^ k + j)
  | 0, acc, F => by
      rw [tsum_eq_single []]
      · simp [foldBits]
      · intro bs hbs
        cases bs with
        | nil => exact absurd rfl hbs
        | cons _ _ => simp
  | k + 1, acc, F => by
      rw [tsum_list_bool_split]
      have hNil : (if ([] : List Bool).length = k + 1 then
          bitListProb [] * F (foldBits acc []) else 0) = 0 := by simp
      have hFalse :
          (∑' tl : List Bool,
            if (false :: tl).length = k + 1 then
              bitListProb (false :: tl) * F (foldBits acc (false :: tl))
            else 0) =
          (2 : ENNReal)⁻¹ *
            (∑' tl : List Bool,
              if tl.length = k then bitListProb tl * F (foldBits (2 * acc) tl) else 0) := by
        rw [← ENNReal.tsum_mul_left]
        refine tsum_congr fun tl => ?_
        simp only [List.length_cons, Nat.add_right_cancel_iff, bitListProb_cons, foldBits,
          List.foldl_cons, Bool.false_eq_true, ↓reduceIte, add_zero]
        split_ifs <;> ring
      have hTrue :
          (∑' tl : List Bool,
            if (true :: tl).length = k + 1 then
              bitListProb (true :: tl) * F (foldBits acc (true :: tl))
            else 0) =
          (2 : ENNReal)⁻¹ *
            (∑' tl : List Bool,
              if tl.length = k then bitListProb tl * F (foldBits (2 * acc + 1) tl) else 0) := by
        rw [← ENNReal.tsum_mul_left]
        refine tsum_congr fun tl => ?_
        simp only [List.length_cons, Nat.add_right_cancel_iff, bitListProb_cons, foldBits,
          List.foldl_cons, ↓reduceIte]
        split_ifs <;> ring
      rw [hNil, zero_add, hFalse, hTrue,
          tsum_fixed_len_foldBits k (2 * acc) F,
          tsum_fixed_len_foldBits k (2 * acc + 1) F]
      have hPow : (2 : ENNReal)⁻¹ * ((2 : ENNReal)⁻¹) ^ k = ((2 : ENNReal)⁻¹) ^ (k + 1) := by
        rw [pow_succ']
      have hSumEq :
          (∑ j ∈ Finset.range (2 ^ (k + 1)), F (acc * 2 ^ (k + 1) + j)) =
          (∑ j ∈ Finset.range (2 ^ k), F (2 * acc * 2 ^ k + j)) +
          (∑ j ∈ Finset.range (2 ^ k), F ((2 * acc + 1) * 2 ^ k + j)) := by
        have h2pow : 2 ^ (k + 1) = 2 ^ k + 2 ^ k := by ring
        rw [h2pow, Finset.sum_range_add]
        congr 1
        · refine Finset.sum_congr rfl fun j _ => ?_
          congr 1; ring
        · refine Finset.sum_congr rfl fun j _ => ?_
          congr 1; ring
      rw [hSumEq, mul_add]
      simp only [← mul_assoc, hPow]

lemma fb_conj3c :
    ∀ (m : ℕ) (hm : 1 ≤ m),
      let trial := uniformRankSampleTrial m hm
      (∀ u v : List Bool, (trial u).isSome → v ≠ [] → trial (u ++ v) = none) ∧
      (∑' u : List Bool, if (trial u).isSome then bitListProb u else 0) = 1 ∧
      ENNReal.ofReal (1 / 2 : ℝ) ≤
        (∑' u : List Bool,
          match trial u with
          | some (optIdx, _, _) => if optIdx.isSome then bitListProb u else 0
          | none => 0) ∧
      ∀ r₁ r₂ : Fin m,
        (∑' u : List Bool,
          match trial u with
          | some (some r, _, _) => if r = r₁ then bitListProb u else 0
          | _ => 0) =
        (∑' u : List Bool,
          match trial u with
          | some (some r, _, _) => if r = r₂ then bitListProb u else 0
          | _ => 0) := by
  intro m hm trial
  let bLen := Nat.clog 2 m
  have hm_le_pow : m ≤ 2 ^ bLen := Nat.le_pow_clog (by decide) m
  have hpow_le_2m : 2 ^ bLen ≤ 2 * m := by
    by_cases hm1 : m = 1
    · subst hm1; simp [bLen]
    · have hm_gt1 : 1 < m := by omega
      have hb_pos : 0 < bLen := Nat.clog_pos (by decide) hm_gt1
      have hlt : 2 ^ (bLen - 1) < m := Nat.pow_pred_clog_lt_self (by decide) hm_gt1
      have hEq : 2 ^ bLen = 2 * 2 ^ (bLen - 1) := by
        conv_lhs => rw [← Nat.sub_add_cancel hb_pos, pow_succ']
      omega
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro u v hu hv
    unfold trial uniformRankSampleTrial at hu ⊢
    dsimp only at hu ⊢
    have hlen : u.length = Nat.clog 2 m := by
      by_contra hne
      rw [if_neg hne] at hu
      simp at hu
    have hv_pos : 0 < v.length := List.length_pos_iff.mpr hv
    have hlen_app : (u ++ v).length ≠ Nat.clog 2 m := by
      rw [List.length_append]
      omega
    exact if_neg hlen_app
  · have hHaltEq :
        (∑' u : List Bool, if (trial u).isSome then bitListProb u else 0) =
        (∑' u : List Bool, if u.length = bLen then bitListProb u * 1 else 0) := by
      refine tsum_congr fun u => ?_
      unfold trial uniformRankSampleTrial
      dsimp only
      by_cases h1 : u.length = bLen
      · dsimp [bLen] at h1
        rw [if_pos h1, if_pos h1]
        by_cases h2 : decodeBitsNat u < m <;> simp [h2]
      · dsimp [bLen] at h1
        simp [h1, bLen]
    rw [hHaltEq, tsum_fixed_len_foldBits bLen 0 (fun _ => 1)]
    simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, mul_one]
    rw [Nat.cast_pow, Nat.cast_ofNat, ← mul_pow, ENNReal.inv_mul_cancel (by norm_num) (by simp), one_pow]
  · have hAccEq :
        (∑' u : List Bool,
          match trial u with
          | some (optIdx, _, _) => if optIdx.isSome then bitListProb u else 0
          | none => 0) =
        (∑' u : List Bool,
          if u.length = bLen then
            bitListProb u * (if foldBits 0 u < m then 1 else 0)
          else 0) := by
      refine tsum_congr fun u => ?_
      unfold trial uniformRankSampleTrial
      dsimp only
      by_cases h1 : u.length = bLen
      · dsimp [bLen] at h1
        rw [if_pos h1, if_pos h1]
        change (match if hlt : foldBits 0 u < m then some (some (⟨foldBits 0 u, hlt⟩ : Fin m), bLen + 1, bLen + 1)
                  else some (none, bLen + 1, bLen + 1) with
                | some (optIdx, _, _) => if optIdx.isSome then bitListProb u else 0
                | none => 0) = _
        by_cases h2 : foldBits 0 u < m <;> simp [h2]
      · dsimp [bLen] at h1
        simp [h1, bLen]
    rw [hAccEq, tsum_fixed_len_foldBits bLen 0 (fun j => if j < m then 1 else 0)]
    simp only [zero_mul, zero_add]
    have hSubSum :
        (∑ j ∈ Finset.range (2 ^ bLen), if j < m then (1 : ENNReal) else 0) = (m : ENNReal) := by
      rw [← Finset.sum_filter]
      have hFilt : (Finset.range (2 ^ bLen)).filter (fun j => j < m) = Finset.range m := by
        ext j
        simp only [Finset.mem_filter, Finset.mem_range]
        omega
      rw [hFilt, Finset.sum_const, Finset.card_range, nsmul_eq_mul, mul_one]
    rw [hSubSum]
    have hHalf : ENNReal.ofReal (1 / 2 : ℝ) = (2 : ENNReal)⁻¹ := by
      rw [one_div, ENNReal.ofReal_inv_of_pos (by norm_num), ENNReal.ofReal_ofNat]
    rw [hHalf]
    have h2pow_ne0 : ((2 : ENNReal) ^ bLen) ≠ 0 := pow_ne_zero _ (by norm_num)
    have h2pow_top : ((2 : ENNReal) ^ bLen) ≠ ⊤ := ENNReal.pow_ne_top (by simp)
    have hInvPow : ((2 : ENNReal)⁻¹) ^ bLen = ((2 : ENNReal) ^ bLen)⁻¹ := ENNReal.inv_pow.symm
    rw [hInvPow]
    -- Show `2⁻¹ ≤ (2^bLen)⁻¹ * m` by multiplying by `2 * 2^bLen`
    have hIneqNat : 2 ^ bLen ≤ 2 * m := hpow_le_2m
    have hIneqENN : ((2 : ENNReal) ^ bLen) ≤ 2 * (m : ENNReal) := by exact_mod_cast hIneqNat
    calc
      (2 : ENNReal)⁻¹
          = (2 : ENNReal)⁻¹ * (((2 : ENNReal) ^ bLen)⁻¹ * ((2 : ENNReal) ^ bLen)) := by
              rw [ENNReal.inv_mul_cancel h2pow_ne0 h2pow_top, mul_one]
      _ ≤ (2 : ENNReal)⁻¹ * (((2 : ENNReal) ^ bLen)⁻¹ * (2 * (m : ENNReal))) := by
              gcongr
      _ = (2 : ENNReal)⁻¹ * 2 * (((2 : ENNReal) ^ bLen)⁻¹ * (m : ENNReal)) := by ring
      _ = ((2 : ENNReal) ^ bLen)⁻¹ * (m : ENNReal) := by
              rw [ENNReal.inv_mul_cancel (by norm_num) (by simp), one_mul]
  · intro r₁ r₂
    have hSingle : ∀ r : Fin m,
        (∑' u : List Bool,
          match trial u with
          | some (some r', _, _) => if r' = r then bitListProb u else 0
          | _ => 0) = ((2 : ENNReal)⁻¹) ^ bLen := by
      intro r
      have hEqR :
          (∑' u : List Bool,
            match trial u with
            | some (some r', _, _) => if r' = r then bitListProb u else 0
            | _ => 0) =
          (∑' u : List Bool,
            if u.length = bLen then
              bitListProb u * (if foldBits 0 u = r.val then 1 else 0)
            else 0) := by
        refine tsum_congr fun u => ?_
        unfold trial uniformRankSampleTrial
        dsimp only
        by_cases hlen : u.length = bLen
        · dsimp [bLen] at hlen
          rw [if_pos hlen, if_pos hlen]
          change (match if hlt : foldBits 0 u < m then some (some (⟨foldBits 0 u, hlt⟩ : Fin m), bLen + 1, bLen + 1)
                    else some (none, bLen + 1, bLen + 1) with
                  | some (some r', _, _) => if r' = r then bitListProb u else 0
                  | _ => 0) = _
          by_cases hlt : foldBits 0 u < m
          · rw [dif_pos hlt]
            dsimp only
            by_cases hEqVal : foldBits 0 u = r.val
            · have hEqFin : (⟨foldBits 0 u, hlt⟩ : Fin m) = r := Fin.ext hEqVal
              rw [hEqFin]
              simp [hEqVal]
            · have hNeFin : (⟨foldBits 0 u, hlt⟩ : Fin m) ≠ r := fun h => hEqVal (congrArg Fin.val h)
              simp [hEqVal, hNeFin]
          · rw [dif_neg hlt]
            have hNeVal : foldBits 0 u ≠ r.val := fun h => hlt (h ▸ r.isLt)
            simp [hNeVal]
        · dsimp [bLen] at hlen
          simp [hlen, bLen]
      rw [hEqR, tsum_fixed_len_foldBits bLen 0 (fun j => if j = r.val then 1 else 0)]
      simp only [zero_mul, zero_add]
      have hr_mem : r.val ∈ Finset.range (2 ^ bLen) := Finset.mem_range.mpr (r.isLt.trans_le hm_le_pow)
      rw [Finset.sum_ite_eq' (Finset.range (2 ^ bLen)) r.val (fun _ => (1 : ENNReal)),
          if_pos hr_mem, mul_one]
    rw [hSingle r₁, hSingle r₂]

open Classical in
theorem fb_conj3 :
    (∀ (C_ev : ℝ) (deg_ev : ℕ), 0 ≤ C_ev →
      ∃ C₁ : ℕ, 1 ≤ C₁ ∧
        ∀ (d n t B : ℕ) (δ : ℝ),
          2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
            let S := execFailureScaleBit n t d B δ
            let φ := perEventFailureBudget S C₁ δ
            0 < φ ∧ φ < δ ∧
            (C_ev * ((S : ℝ) ^ deg_ev)) * φ ≤ δ) ∧
    (∀ (p₀ : ℝ) (C₁ : ℕ), 0 < p₀ → p₀ ≤ 1 → 1 ≤ C₁ →
      ∃ C_try : ℝ, 0 < C_try ∧
        ∀ (d n t B : ℕ) (δ : ℝ),
          2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
            let S := execFailureScaleBit n t d B δ
            let φ := perEventFailureBudget S C₁ δ
            ∃ K_try : ℕ,
              1 ≤ K_try ∧
              (K_try : ℝ) ≤ C_try * Real.log ((S : ℝ) / δ) ∧
              (1 - p₀) ^ K_try ≤ φ ∧
              ∀ (Out : Type) (attempt : List Bool → Option (Out × ℕ × ℕ))
                (isGood : Out → Prop) (fallback : Out) (W_cap Sp_cap : ℕ),
                (∀ u v : List Bool, (attempt u).isSome → v ≠ [] → attempt (u ++ v) = none) →
                (∑' u : List Bool, if (attempt u).isSome then bitListProb u else 0) = 1 →
                (∀ (u : List Bool) (val : Out) (w sp : ℕ),
                  attempt u = some (val, w, sp) → w ≤ W_cap ∧ sp ≤ Sp_cap) →
                ENNReal.ofReal p₀ ≤
                  (open Classical in
                    ∑' u : List Bool,
                      match attempt u with
                      | some (val, _, _) => if isGood val then bitListProb u else 0
                      | none => 0) →
                let boosted := runRepeatedCappedAttempts attempt isGood fallback K_try 0 0
                (∀ u v : List Bool, (boosted u).isSome → v ≠ [] → boosted (u ++ v) = none) ∧
                (∑' u : List Bool, if (boosted u).isSome then bitListProb u else 0) = 1 ∧
                (∀ (u : List Bool) (val : Out) (ok : Bool) (w sp : ℕ),
                  boosted u = some (val, ok, w, sp) →
                    w ≤ K_try * W_cap ∧ sp ≤ Sp_cap ∧ (ok = true → isGood val)) ∧
                (∑' u : List Bool,
                  match boosted u with
                  | some (_, ok, _, _) => if ok = false then bitListProb u else 0
                  | none => 0) ≤ ENNReal.ofReal φ) ∧
    (∀ (m : ℕ) (hm : 1 ≤ m),
      let trial := uniformRankSampleTrial m hm
      (∀ u v : List Bool, (trial u).isSome → v ≠ [] → trial (u ++ v) = none) ∧
      (∑' u : List Bool, if (trial u).isSome then bitListProb u else 0) = 1 ∧
      ENNReal.ofReal (1 / 2 : ℝ) ≤
        (∑' u : List Bool,
          match trial u with
          | some (optIdx, _, _) => if optIdx.isSome then bitListProb u else 0
          | none => 0) ∧
      ∀ r₁ r₂ : Fin m,
        (∑' u : List Bool,
          match trial u with
          | some (some r, _, _) => if r = r₁ then bitListProb u else 0
          | _ => 0) =
        (∑' u : List Bool,
          match trial u with
          | some (some r, _, _) => if r = r₂ then bitListProb u else 0
          | _ => 0)) :=
  ⟨fb_conj3a, fb_conj3b, fb_conj3c⟩

/-! ### 4. Conjunct (4): `SequentialBirthController` Conditional Union Bound -/

private lemma map_isPrefixFree {α β : Type} {f : List Bool → Option α}
    (hf : IsPrefixFree f) (h : α → β) :
    IsPrefixFree (fun bs => (f bs).map h) := by
  intro u v b₁ b₂ hu hv huv
  simp only [Option.map_eq_some_iff] at hu hv
  rcases hu with ⟨a₁, hfa₁, _⟩
  rcases hv with ⟨a₂, hfa₂, _⟩
  exact hf u v a₁ a₂ hfa₁ hfa₂ huv

private lemma map_haltProb {α β : Type} (f : List Bool → Option α) (h : α → β) :
    haltProb (fun bs => (f bs).map h) = haltProb f := by
  unfold haltProb
  refine tsum_congr fun bs => ?_
  dsimp only
  cases f bs <;> rfl

private lemma map_expWithBits {α β : Type} (f : List Bool → Option α) (h : α → β) (W : β → ENNReal) :
    expWithBits (fun bs => (f bs).map h) W = expWithBits f (fun a => W (h a)) := by
  unfold expWithBits
  refine tsum_congr fun bs => ?_
  dsimp only
  cases f bs <;> rfl

private lemma seqBirth_ind {d : ℕ} {BirthOut StepRes : Type}
    {φ : ℝ} (hφ : 0 ≤ φ) :
    ∀ (ctrl : SequentialBirthController d BirthOut StepRes),
      ctrl.ValidAtBudget φ →
        let run := runSequentialBirthController ctrl
        IsPrefixFree run ∧
        haltProb run = 1 ∧
        expWithBits run (fun out => if out.2.1 = false then 1 else 0) ≤
          expWithBits run (fun out => ENNReal.ofReal ((out.2.2 : ℝ) * φ))
  | .done res, _ => by
      have hEq : runSequentialBirthController (.done res : SequentialBirthController d BirthOut StepRes) =
          endWithEmpty (res, true, 0) := by
        funext bs; cases bs <;> rfl
      refine ⟨?_, ?_, ?_⟩
      · rw [hEq]; exact isPrefixFree_endWithEmpty _
      · rw [hEq]; exact haltProb_endWithEmpty _
      · rw [hEq, expWithBits_endWithEmpty, expWithBits_endWithEmpty]; simp
  | .birth draw isSuccess next, hValid => by
      classical
      rcases hValid with ⟨hDrawPF_raw, hDrawHalt, hDrawFail, hNextValid⟩
      have hDrawPF : IsPrefixFree draw := (isPrefixFree_iff_append_none draw).mpr hDrawPF_raw
      let g : BirthOut → List Bool → Option (StepRes × Bool × ℕ) :=
        fun out rem =>
          (runSequentialBirthController (next out) rem).map
            (fun r => (r.1, decide (isSuccess out) && r.2.1, 1 + r.2.2))
      have hEq : runSequentialBirthController (.birth draw isSuccess next) = seqConsume draw g := by
        funext bs
        rw [← seqConsumeCoin_eq_seqConsume hDrawPF g bs]
        unfold runSequentialBirthController seqConsumeCoin g
        cases consumePrefixCoinList draw bs with
        | none => rfl
        | some pair =>
            rcases pair with ⟨out, rem⟩
            dsimp only
            cases runSequentialBirthController (next out) rem <;> rfl
      have hIH : ∀ out : BirthOut,
          let rn := runSequentialBirthController (next out)
          IsPrefixFree rn ∧
          haltProb rn = 1 ∧
          expWithBits rn (fun r => if r.2.1 = false then 1 else 0) ≤
            expWithBits rn (fun r => ENNReal.ofReal ((r.2.2 : ℝ) * φ)) :=
        fun out => seqBirth_ind hφ (next out) (hNextValid out)
      have hgPF : ∀ bs₁ out, draw bs₁ = some out → IsPrefixFree (g out) :=
        fun _ out _ => map_isPrefixFree (hIH out).1 _
      have hgHalt : ∀ bs₁ out, draw bs₁ = some out → haltProb (g out) = 1 := by
        intro _ out _
        dsimp [g]
        rw [map_haltProb]
        exact (hIH out).2.1
      refine ⟨?_, ?_, ?_⟩
      · rw [hEq]; exact isPrefixFree_seqConsume hDrawPF hgPF
      · rw [hEq]; exact haltProb_seqConsume hDrawPF hDrawHalt hgHalt
      · rw [hEq, expWithBits_seqConsume hDrawPF, expWithBits_seqConsume hDrawPF]
        have hDrawFailExp :
            expWithBits draw (fun out => if ¬ isSuccess out then 1 else 0) ≤ ENNReal.ofReal φ := by
          have hSame :
              expWithBits draw (fun out => if ¬ isSuccess out then 1 else 0) =
              (∑' u : List Bool,
                match draw u with
                | some out => if ¬ isSuccess out then bitListProb u else 0
                | none => 0) := by
            unfold expWithBits
            refine tsum_congr fun u => ?_
            cases draw u with
            | none => rfl
            | some out => dsimp only; split_ifs <;> simp
          rw [hSame]; exact hDrawFail
        calc
          expWithBits draw (fun out => expWithBits (g out) (fun r => if r.2.1 = false then 1 else 0))
              ≤ expWithBits draw (fun out =>
                  (if ¬ isSuccess out then (1 : ENNReal) else 0) +
                  expWithBits (runSequentialBirthController (next out))
                    (fun r => ENNReal.ofReal ((r.2.2 : ℝ) * φ))) := by
                refine expWithBits_mono fun bs₁ out _ => ?_
                dsimp [g]
                rw [map_expWithBits]
                by_cases hs : isSuccess out
                · simp only [hs, decide_true, Bool.true_and, not_true_eq_false, ↓reduceIte, zero_add]
                  exact (hIH out).2.2
                · simp only [hs, decide_false, Bool.false_and, ↓reduceIte, not_false_eq_true]
                  rw [expWithBits_const, (hIH out).2.1, one_mul]
                  exact le_add_right le_rfl
          _ = expWithBits draw (fun out => if ¬ isSuccess out then 1 else 0) +
              expWithBits draw (fun out =>
                expWithBits (runSequentialBirthController (next out))
                  (fun r => ENNReal.ofReal ((r.2.2 : ℝ) * φ))) :=
                expWithBits_add _ _ _
          _ ≤ ENNReal.ofReal φ +
              expWithBits draw (fun out =>
                expWithBits (runSequentialBirthController (next out))
                  (fun r => ENNReal.ofReal ((r.2.2 : ℝ) * φ))) :=
                by gcongr
          _ = expWithBits draw (fun out =>
                ENNReal.ofReal φ +
                expWithBits (runSequentialBirthController (next out))
                  (fun r => ENNReal.ofReal ((r.2.2 : ℝ) * φ))) :=
                (expWithBits_const_add_of_haltProb_one hDrawHalt _ _).symm
          _ = expWithBits draw (fun out =>
                expWithBits (g out) (fun r => ENNReal.ofReal ((r.2.2 : ℝ) * φ))) := by
                refine expWithBits_congr (fun _ => rfl) fun _ out _ => ?_
                dsimp [g]
                rw [map_expWithBits, ← expWithBits_const_add_of_haltProb_one (hIH out).2.1]
                refine expWithBits_congr (fun _ => rfl) fun _ r _ => ?_
                have hAddReal : φ + (r.2.2 : ℝ) * φ = ((1 + r.2.2 : ℕ) : ℝ) * φ := by
                  push_cast; ring
                rw [← ENNReal.ofReal_add hφ (by positivity), hAddReal]

theorem fb_conj4 :
    open Classical in
    ∀ (d : ℕ) (BirthOut StepRes : Type) (φ : ℝ)
      (ctrl : SequentialBirthController d BirthOut StepRes),
      0 ≤ φ →
      ctrl.ValidAtBudget φ →
        let run := runSequentialBirthController ctrl
        (∀ u v : List Bool, (run u).isSome → v ≠ [] → run (u ++ v) = none) ∧
        (∑' u : List Bool, if (run u).isSome then bitListProb u else 0) = 1 ∧
        (∑' u : List Bool,
          match run u with
          | some (_, ok, _) => if ok = false then bitListProb u else 0
          | none => 0) ≤
        (∑' u : List Bool,
          match run u with
          | some (_, _, cnt) => bitListProb u * ENNReal.ofReal ((cnt : ℝ) * φ)
          | none => 0) := by
  classical
  intro d BirthOut StepRes φ ctrl hφ hValid
  obtain ⟨hPF, hHalt, hBound⟩ := seqBirth_ind hφ ctrl hValid
  refine ⟨(isPrefixFree_iff_append_none _).mp hPF, hHalt, ?_⟩
  have hLHS :
      (∑' u : List Bool,
        match runSequentialBirthController ctrl u with
        | some (_, ok, _) => if ok = false then bitListProb u else 0
        | none => 0) =
      expWithBits (runSequentialBirthController ctrl) (fun out => if out.2.1 = false then 1 else 0) := by
    unfold expWithBits
    refine tsum_congr fun u => ?_
    cases runSequentialBirthController ctrl u with
    | none => rfl
    | some out =>
        rcases out with ⟨res, ok, cnt⟩
        dsimp only
        split_ifs <;> simp
  have hRHS :
      (∑' u : List Bool,
        match runSequentialBirthController ctrl u with
        | some (_, _, cnt) => bitListProb u * ENNReal.ofReal ((cnt : ℝ) * φ)
        | none => 0) =
      expWithBits (runSequentialBirthController ctrl)
        (fun out => ENNReal.ofReal ((out.2.2 : ℝ) * φ)) := by
    unfold expWithBits
    refine tsum_congr fun u => ?_
    cases runSequentialBirthController ctrl u with
    | none => rfl
    | some out => rcases out with ⟨res, ok, cnt⟩; rfl
  rw [hLHS, hRHS]
  exact hBound

end UL.Proof_clm_7_3_failure_budget_cg_H2
