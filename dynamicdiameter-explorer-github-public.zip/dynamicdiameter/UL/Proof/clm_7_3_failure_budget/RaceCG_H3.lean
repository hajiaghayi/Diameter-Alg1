import UL.Stmt.clm_7_3_failure_budget
import UL.Proof.claim_C_3_sync_suffix.RaceV31_H1
set_option autoImplicit false

namespace UL.Proof_clm_7_3_failure_budget_cg_H3

open scoped ENNReal BigOperators
open UL.Proof_claim_C_3_sync_suffix_v31

/-! ### Part 5: Horizon-`t` Adaptive Conditional Union Bound & Failure-Safe Work/Space Budgets -/

private lemma runAdaptiveStepsFrom_append {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d) :
    ∀ (xs ys : List (List Bool)) (cur : AdaptivePrefixState d State),
      runAdaptiveStepsFrom alg adv cur (xs ++ ys) =
        match runAdaptiveStepsFrom alg adv cur xs with
        | none => none
        | some mid => runAdaptiveStepsFrom alg adv mid ys
  | [], ys, cur => rfl
  | b :: tail, ys, cur => by
      simp only [List.cons_append, runAdaptiveStepsFrom]
      cases runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) b with
      | none => rfl
      | some pair =>
          rcases pair with ⟨P', out⟩
          dsimp only
          exact runAdaptiveStepsFrom_append alg adv tail ys _

private lemma adaptiveStepsTotalEvents_append {d : ℕ} {State : Type}
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d)
    (stepEventCount :
      DynamicPointSet d → ExecutionHistory d → State → DynamicUpdate d → List Bool → ℕ) :
    ∀ (xs ys : List (List Bool)) (cur mid : AdaptivePrefixState d State),
      runAdaptiveStepsFrom alg adv cur xs = some mid →
      adaptiveStepsTotalEvents alg adv stepEventCount cur (xs ++ ys) =
        adaptiveStepsTotalEvents alg adv stepEventCount cur xs +
          adaptiveStepsTotalEvents alg adv stepEventCount mid ys
  | [], ys, cur, mid, hRun => by
      simp only [runAdaptiveStepsFrom, Option.some.injEq] at hRun
      subst hRun
      simp [adaptiveStepsTotalEvents]
  | b :: tail, ys, cur, mid, hRun => by
      simp only [runAdaptiveStepsFrom] at hRun
      cases hStep : runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) b with
      | none => rw [hStep] at hRun; simp at hRun
      | some pair =>
          rcases pair with ⟨P', out⟩
          rw [hStep] at hRun
          dsimp only at hRun
          simp only [List.cons_append, adaptiveStepsTotalEvents, hStep]
          rw [adaptiveStepsTotalEvents_append alg adv stepEventCount tail ys _ mid hRun]
          omega

private lemma work_and_space_ind {d : ℕ} {State : Type}
    (t : ℕ) (stepWorkBound spaceBound : ℝ)
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d)
    (hStepWS : ∀ (bitTrace : List (List Bool)) (prefSt : AdaptivePrefixState d State),
      bitTrace.length < t →
      runAdaptiveSteps alg adv bitTrace = some prefSt →
        ∀ (bs : List Bool) (P' : DynamicPointSet d) (out : DynamicStepOutcome State),
          runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState (adv prefSt.history) bs =
            some (P', out) →
            (out.work : ℝ) ≤ stepWorkBound ∧ (out.peakSpace : ℝ) ≤ spaceBound) :
    ∀ (xs acc : List (List Bool)) (cur outSt : AdaptivePrefixState d State),
      acc.length + xs.length ≤ t →
      runAdaptiveSteps alg adv acc = some cur →
      (∀ w ∈ cur.stepWorks, (w : ℝ) ≤ stepWorkBound) →
      (cur.maxSpace : ℝ) ≤ spaceBound →
      runAdaptiveStepsFrom alg adv cur xs = some outSt →
        (∀ w ∈ outSt.stepWorks, (w : ℝ) ≤ stepWorkBound) ∧
        (outSt.maxSpace : ℝ) ≤ spaceBound
  | [], _, cur, outSt, _, _, hW, hSp, hOut => by
      simp only [runAdaptiveStepsFrom, Option.some.injEq] at hOut
      subst hOut
      exact ⟨hW, hSp⟩
  | b :: tail, acc, cur, outSt, hLen, hAcc, hW, hSp, hOut => by
      simp only [List.length_cons] at hLen
      simp only [runAdaptiveStepsFrom] at hOut
      cases hStep : runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) b with
      | none => rw [hStep] at hOut; simp at hOut
      | some pair =>
          rcases pair with ⟨P', stepOut⟩
          rw [hStep] at hOut
          dsimp only at hOut
          obtain ⟨hw_step, hsp_step⟩ := hStepWS acc cur (by omega) hAcc b P' stepOut hStep
          let entry : StepHistoryEntry d :=
            { operation := adv cur.history
              randomBits := b
              returnedHandle := stepOut.returnedHandle
              answer := stepOut.storedAnswer
              resolvedIds := resolveAnswerIdentities P' stepOut.storedAnswer }
          let next : AdaptivePrefixState d State :=
            { pointSet := P'
              algState := stepOut.nextState
              history := cur.history ++ [entry]
              snapshots := cur.snapshots ++ [(P', stepOut.storedAnswer)]
              stepWorks := cur.stepWorks ++ [stepOut.work]
              totalWork := cur.totalWork + stepOut.work
              maxSpace := max cur.maxSpace stepOut.peakSpace }
          have hAccNext : runAdaptiveSteps alg adv (acc ++ [b]) = some next := by
            unfold runAdaptiveSteps at hAcc ⊢
            rw [runAdaptiveStepsFrom_append, hAcc]
            simp [runAdaptiveStepsFrom, hStep, next, entry]
          have hW_next : ∀ w ∈ next.stepWorks, (w : ℝ) ≤ stepWorkBound := by
            intro w hw
            simp only [next, List.mem_append, List.mem_singleton] at hw
            rcases hw with hw0 | rfl
            · exact hW w hw0
            · exact hw_step
          have hSp_next : (next.maxSpace : ℝ) ≤ spaceBound := by
            dsimp [next]
            rw [Nat.cast_max]
            exact max_le hSp hsp_step
          exact work_and_space_ind t stepWorkBound spaceBound alg adv hStepWS
            tail (acc ++ [b]) next outSt (by simp; omega) hAccNext hW_next hSp_next hOut

private lemma fin0_trace_unique (tr : Fin 0 → List Bool) : tr = Fin.elim0 := by
  funext i; exact Fin.elim0 i

open Classical in
private lemma mc_prefix_ind {d : ℕ} {State : Type}
    (t : ℕ) (c φ : ℝ) (hφ_nn : 0 ≤ φ)
    (alg : DynamicDiameterStructure d State) (adv : AdaptiveAdversary d)
    (GoodState : DynamicPointSet d → ExecutionHistory d → State → Prop)
    (stepEventCount :
      DynamicPointSet d → ExecutionHistory d → State → DynamicUpdate d → List Bool → ℕ)
    (hInitGood : GoodState (DynamicPointSet.empty d) [] alg.initState)
    (hStep : ∀ (bitTrace : List (List Bool)) (prefSt : AdaptivePrefixState d State),
      bitTrace.length < t →
      runAdaptiveSteps alg adv bitTrace = some prefSt →
        let op := adv prefSt.history
        singleStepValidHaltProb alg prefSt.pointSet prefSt.algState op = 1 ∧
        (GoodState prefSt.pointSet prefSt.history prefSt.algState →
          (∀ (bs : List Bool) (P' : DynamicPointSet d) (out : DynamicStepOutcome State),
            runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs = some (P', out) →
              let entry : StepHistoryEntry d :=
                { operation := op
                  randomBits := bs
                  returnedHandle := out.returnedHandle
                  answer := out.storedAnswer
                  resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
              GoodState P' (prefSt.history ++ [entry]) out.nextState →
                IsValidFactorCAnswer c P' out.storedAnswer) ∧
          (∑' bs : List Bool,
            match runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs with
            | some (P', out) =>
                let entry : StepHistoryEntry d :=
                  { operation := op
                    randomBits := bs
                    returnedHandle := out.returnedHandle
                    answer := out.storedAnswer
                    resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
                if ¬ GoodState P' (prefSt.history ++ [entry]) out.nextState then
                  bitListProb bs
                else 0
            | none => 0) ≤
          (∑' bs : List Bool,
            if (runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs).isSome then
              bitListProb bs *
                ENNReal.ofReal
                  ((stepEventCount prefSt.pointSet prefSt.history prefSt.algState op bs : ℝ) * φ)
            else 0))) :
    ∀ (s : ℕ), s ≤ t →
      let GoodPrefix (out : AdaptivePrefixState d State) : Prop :=
        GoodState out.pointSet out.history out.algState ∧ AllPrefixAnswersValid c out
      (∑' tr : Fin s → List Bool,
        if (runAdaptivePrefix alg adv s tr).isSome then prefixTraceProb tr else 0) = 1 ∧
      (∑' tr : Fin s → List Bool,
        match runAdaptivePrefix alg adv s tr with
        | some out => if ¬ GoodPrefix out then prefixTraceProb tr else 0
        | none => 0) ≤
      (∑' tr : Fin s → List Bool,
        match runAdaptivePrefix alg adv s tr with
        | some out =>
            prefixTraceProb tr *
              ENNReal.ofReal
                ((adaptiveStepsTotalEvents alg adv stepEventCount
                  (initAdaptivePrefixState alg) (List.ofFn tr) : ℝ) * φ)
        | none => 0)
  | 0, _ => by
      dsimp only
      have hRun0 : runAdaptivePrefix alg adv 0 Fin.elim0 = some (initAdaptivePrefixState alg) := rfl
      have hGood0 : GoodState (initAdaptivePrefixState alg).pointSet
          (initAdaptivePrefixState alg).history (initAdaptivePrefixState alg).algState ∧
          AllPrefixAnswersValid c (initAdaptivePrefixState alg) :=
        ⟨hInitGood, fun _ h => by simp [initAdaptivePrefixState] at h⟩
      refine ⟨?_, ?_⟩
      · rw [tsum_eq_single Fin.elim0]
        · simp [hRun0, prefixTraceProb]
        · intro tr hne; exact False.elim (hne (fin0_trace_unique tr))
      · rw [tsum_eq_single Fin.elim0]
        · simp [hRun0, hGood0]
        · intro tr hne; exact False.elim (hne (fin0_trace_unique tr))
  | s + 1, hs1 => by
      dsimp only
      let GoodPrefix (out : AdaptivePrefixState d State) : Prop :=
        GoodState out.pointSet out.history out.algState ∧ AllPrefixAnswersValid c out
      obtain ⟨ihHalt, ihBad⟩ := mc_prefix_ind t c φ hφ_nn alg adv GoodState stepEventCount
        hInitGood hStep s (by omega)
      dsimp only at ihHalt ihBad
      have hRunSnoc : ∀ (init : Fin s → List Bool) (bs : List Bool),
          runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs) =
            match runAdaptivePrefix alg adv s init with
            | none => none
            | some mid =>
                match runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs with
                | none => none
                | some (P', out) =>
                    let entry : StepHistoryEntry d :=
                      { operation := adv mid.history
                        randomBits := bs
                        returnedHandle := out.returnedHandle
                        answer := out.storedAnswer
                        resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
                    some
                      { pointSet := P'
                        algState := out.nextState
                        history := mid.history ++ [entry]
                        snapshots := mid.snapshots ++ [(P', out.storedAnswer)]
                        stepWorks := mid.stepWorks ++ [out.work]
                        totalWork := mid.totalWork + out.work
                        maxSpace := max mid.maxSpace out.peakSpace } := by
        intro init bs
        unfold runAdaptivePrefix runAdaptiveSteps
        rw [ofFn_snocTrace, runAdaptiveStepsFrom_append]
        cases runAdaptiveStepsFrom alg adv (initAdaptivePrefixState alg) (List.ofFn init) with
        | none => rfl
        | some mid =>
            simp only [runAdaptiveStepsFrom]
            cases runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs <;> rfl
      refine ⟨?_, ?_⟩
      · -- (A) Halting probability = 1
        rw [tsum_fin_succ_trace]
        have hInner : ∀ init : Fin s → List Bool,
            (∑' bs : List Bool,
              if (runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs)).isSome then
                prefixTraceProb (Fin.snoc init bs)
              else 0) =
            if (runAdaptivePrefix alg adv s init).isSome then prefixTraceProb init else 0 := by
          intro init
          cases hMid : runAdaptivePrefix alg adv s init with
          | none =>
              have hZero : (fun bs : List Bool =>
                  if (runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs)).isSome then
                    prefixTraceProb (Fin.snoc init bs)
                  else 0) = fun _ => 0 := by
                ext bs; rw [hRunSnoc, hMid]; simp
              rw [hZero, tsum_zero]; simp
          | some mid =>
              have hLen : (List.ofFn init).length < t := by simp; omega
              have hHalt1 := (hStep (List.ofFn init) mid hLen hMid).1
              have hCongr :
                  (∑' bs : List Bool,
                    if (runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs)).isSome then
                      prefixTraceProb (Fin.snoc init bs)
                    else 0) =
                  prefixTraceProb init *
                    (∑' bs : List Bool,
                      if (runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs).isSome then
                        bitListProb bs
                      else 0) := by
                rw [← ENNReal.tsum_mul_left]
                refine tsum_congr fun bs => ?_
                rw [hRunSnoc, hMid, prefixTraceProb_snoc]
                dsimp only
                cases hS : runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs with
                | none => simp
                | some pair => rcases pair with ⟨P', out⟩; simp
              rw [hCongr]
              change prefixTraceProb init * singleStepValidHaltProb alg mid.pointSet mid.algState (adv mid.history) = _
              rw [hHalt1, mul_one]; simp
        simp_rw [hInner]
        exact ihHalt
      · -- (B) Failure probability union bound
        rw [tsum_fin_succ_trace, tsum_fin_succ_trace]
        -- Decompose each inner sum over `bs` into `(¬ GoodPrefix mid)` part + `(GoodPrefix mid)` part
        have hInnerLe : ∀ init : Fin s → List Bool,
            (∑' bs : List Bool,
              match runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs) with
              | some next => if ¬ GoodPrefix next then prefixTraceProb (Fin.snoc init bs) else 0
              | none => 0) ≤
            (match runAdaptivePrefix alg adv s init with
              | some mid => if ¬ GoodPrefix mid then prefixTraceProb init else 0
              | none => 0) +
            (match runAdaptivePrefix alg adv s init with
              | some mid =>
                  prefixTraceProb init *
                    (∑' bs : List Bool,
                      if (runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs).isSome then
                        bitListProb bs *
                          ENNReal.ofReal
                            ((stepEventCount mid.pointSet mid.history mid.algState (adv mid.history) bs : ℝ) * φ)
                      else 0)
              | none => 0) := by
          intro init
          cases hMid : runAdaptivePrefix alg adv s init with
          | none =>
              have hZero : (fun bs : List Bool =>
                  match runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs) with
                  | some next => if ¬ GoodPrefix next then prefixTraceProb (Fin.snoc init bs) else 0
                  | none => (0 : ENNReal)) = fun _ => 0 := by
                ext bs; rw [hRunSnoc, hMid]
              rw [hZero, tsum_zero]; simp
          | some mid =>
              have hLen : (List.ofFn init).length < t := by simp; omega
              obtain ⟨hHalt1, hCondGood⟩ := hStep (List.ofFn init) mid hLen hMid
              by_cases hGM : GoodPrefix mid
              · -- `GoodPrefix mid` holds: `¬ GoodPrefix next` implies `¬ GoodState next`!
                simp only [hGM, not_true_eq_false, ↓reduceIte, zero_add]
                obtain ⟨hAnsValid, hFailStep⟩ := hCondGood hGM.1
                calc
                  (∑' bs : List Bool,
                    match runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs) with
                    | some next => if ¬ GoodPrefix next then prefixTraceProb (Fin.snoc init bs) else 0
                    | none => 0)
                      ≤ prefixTraceProb init *
                          (∑' bs : List Bool,
                            match runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs with
                            | some (P', out) =>
                                let entry : StepHistoryEntry d :=
                                  { operation := adv mid.history
                                    randomBits := bs
                                    returnedHandle := out.returnedHandle
                                    answer := out.storedAnswer
                                    resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
                                if ¬ GoodState P' (mid.history ++ [entry]) out.nextState then
                                  bitListProb bs
                                else 0
                            | none => 0) := by
                        rw [← ENNReal.tsum_mul_left]
                        refine ENNReal.tsum_le_tsum fun bs => ?_
                        rw [hRunSnoc, hMid, prefixTraceProb_snoc]
                        dsimp only
                        cases hS : runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs with
                        | none => simp
                        | some pair =>
                            rcases pair with ⟨P', out⟩
                            dsimp only
                            by_cases hGS_next :
                                GoodState P' (mid.history ++ [{
                                  operation := adv mid.history
                                  randomBits := bs
                                  returnedHandle := out.returnedHandle
                                  answer := out.storedAnswer
                                  resolvedIds := resolveAnswerIdentities P' out.storedAnswer }]) out.nextState
                            · have hAns := hAnsValid bs P' out hS hGS_next
                              have hGP_next : GoodPrefix {
                                  pointSet := P'
                                  algState := out.nextState
                                  history := mid.history ++ [{
                                    operation := adv mid.history
                                    randomBits := bs
                                    returnedHandle := out.returnedHandle
                                    answer := out.storedAnswer
                                    resolvedIds := resolveAnswerIdentities P' out.storedAnswer }]
                                  snapshots := mid.snapshots ++ [(P', out.storedAnswer)]
                                  stepWorks := mid.stepWorks ++ [out.work]
                                  totalWork := mid.totalWork + out.work
                                  maxSpace := max mid.maxSpace out.peakSpace } := by
                                refine ⟨hGS_next, ?_⟩
                                intro snap hsnap
                                simp only [List.mem_append, List.mem_singleton] at hsnap
                                rcases hsnap with hs0 | rfl
                                · exact hGM.2 snap hs0
                                · exact hAns
                              simp [hGP_next, hGS_next]
                            · simp only [hGS_next, not_false_eq_true, ↓reduceIte]
                              by_cases hGPN : GoodPrefix {
                                  pointSet := P'
                                  algState := out.nextState
                                  history := mid.history ++ [{
                                    operation := adv mid.history
                                    randomBits := bs
                                    returnedHandle := out.returnedHandle
                                    answer := out.storedAnswer
                                    resolvedIds := resolveAnswerIdentities P' out.storedAnswer }]
                                  snapshots := mid.snapshots ++ [(P', out.storedAnswer)]
                                  stepWorks := mid.stepWorks ++ [out.work]
                                  totalWork := mid.totalWork + out.work
                                  maxSpace := max mid.maxSpace out.peakSpace } <;> simp [hGPN]
                  _ ≤ prefixTraceProb init *
                        (∑' bs : List Bool,
                          if (runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs).isSome then
                            bitListProb bs *
                              ENNReal.ofReal
                                ((stepEventCount mid.pointSet mid.history mid.algState (adv mid.history) bs : ℝ) * φ)
                          else 0) :=
                        mul_le_mul_of_nonneg_left hFailStep (zero_le _)
              · -- `¬ GoodPrefix mid`: bound LHS by `prefixTraceProb init * 1 = prefixTraceProb init`
                simp only [hGM, not_false_eq_true, ↓reduceIte]
                have hLe1 :
                    (∑' bs : List Bool,
                      match runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs) with
                      | some next => if ¬ GoodPrefix next then prefixTraceProb (Fin.snoc init bs) else 0
                      | none => 0) ≤ prefixTraceProb init := by
                  calc
                    (∑' bs : List Bool,
                      match runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs) with
                      | some next => if ¬ GoodPrefix next then prefixTraceProb (Fin.snoc init bs) else 0
                      | none => 0)
                        ≤ prefixTraceProb init *
                            (∑' bs : List Bool,
                              if (runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs).isSome then
                                bitListProb bs
                              else 0) := by
                          rw [← ENNReal.tsum_mul_left]
                          refine ENNReal.tsum_le_tsum fun bs => ?_
                          rw [hRunSnoc, hMid, prefixTraceProb_snoc]
                          dsimp only
                          cases runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs with
                          | none => simp
                          | some pair =>
                              rcases pair with ⟨P', out⟩
                              dsimp only
                              by_cases hGPN : GoodPrefix {
                                  pointSet := P'
                                  algState := out.nextState
                                  history := mid.history ++ [{
                                    operation := adv mid.history
                                    randomBits := bs
                                    returnedHandle := out.returnedHandle
                                    answer := out.storedAnswer
                                    resolvedIds := resolveAnswerIdentities P' out.storedAnswer }]
                                  snapshots := mid.snapshots ++ [(P', out.storedAnswer)]
                                  stepWorks := mid.stepWorks ++ [out.work]
                                  totalWork := mid.totalWork + out.work
                                  maxSpace := max mid.maxSpace out.peakSpace } <;> simp [hGPN]
                    _ = prefixTraceProb init * 1 := by
                          change prefixTraceProb init * singleStepValidHaltProb alg mid.pointSet mid.algState (adv mid.history) = _
                          rw [hHalt1]
                    _ = prefixTraceProb init := mul_one _
                exact hLe1.trans (le_add_right le_rfl)
        calc
          (∑' init : Fin s → List Bool, ∑' bs : List Bool,
            match runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs) with
            | some next => if ¬ GoodPrefix next then prefixTraceProb (Fin.snoc init bs) else 0
            | none => 0)
              ≤ ∑' init : Fin s → List Bool,
                  ((match runAdaptivePrefix alg adv s init with
                    | some mid => if ¬ GoodPrefix mid then prefixTraceProb init else 0
                    | none => 0) +
                  (match runAdaptivePrefix alg adv s init with
                    | some mid =>
                        prefixTraceProb init *
                          (∑' bs : List Bool,
                            if (runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs).isSome then
                              bitListProb bs *
                                ENNReal.ofReal
                                  ((stepEventCount mid.pointSet mid.history mid.algState (adv mid.history) bs : ℝ) * φ)
                            else 0)
                    | none => 0)) := ENNReal.tsum_le_tsum hInnerLe
          _ = (∑' init : Fin s → List Bool,
                match runAdaptivePrefix alg adv s init with
                | some mid => if ¬ GoodPrefix mid then prefixTraceProb init else 0
                | none => 0) +
              (∑' init : Fin s → List Bool,
                match runAdaptivePrefix alg adv s init with
                | some mid =>
                    prefixTraceProb init *
                      (∑' bs : List Bool,
                        if (runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs).isSome then
                          bitListProb bs *
                            ENNReal.ofReal
                              ((stepEventCount mid.pointSet mid.history mid.algState (adv mid.history) bs : ℝ) * φ)
                        else 0)
                | none => 0) := ENNReal.tsum_add
          _ ≤ (∑' init : Fin s → List Bool,
                match runAdaptivePrefix alg adv s init with
                | some mid =>
                    prefixTraceProb init *
                      ENNReal.ofReal
                        ((adaptiveStepsTotalEvents alg adv stepEventCount
                          (initAdaptivePrefixState alg) (List.ofFn init) : ℝ) * φ)
                | none => 0) +
              (∑' init : Fin s → List Bool,
                match runAdaptivePrefix alg adv s init with
                | some mid =>
                    prefixTraceProb init *
                      (∑' bs : List Bool,
                        if (runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs).isSome then
                          bitListProb bs *
                            ENNReal.ofReal
                              ((stepEventCount mid.pointSet mid.history mid.algState (adv mid.history) bs : ℝ) * φ)
                        else 0)
                | none => 0) := by gcongr
          _ = ∑' init : Fin s → List Bool, ∑' bs : List Bool,
                match runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs) with
                | some next =>
                    prefixTraceProb (Fin.snoc init bs) *
                      ENNReal.ofReal
                        ((adaptiveStepsTotalEvents alg adv stepEventCount
                          (initAdaptivePrefixState alg) (List.ofFn (Fin.snoc init bs)) : ℝ) * φ)
                | none => 0 := by
                rw [← ENNReal.tsum_add]
                refine tsum_congr fun init => ?_
                cases hMid : runAdaptivePrefix alg adv s init with
                | none =>
                    have hZ : (fun bs : List Bool =>
                        match runAdaptivePrefix alg adv (s + 1) (Fin.snoc init bs) with
                        | some next =>
                            prefixTraceProb (Fin.snoc init bs) *
                              ENNReal.ofReal
                                ((adaptiveStepsTotalEvents alg adv stepEventCount
                                  (initAdaptivePrefixState alg) (List.ofFn (Fin.snoc init bs)) : ℝ) * φ)
                        | none => (0 : ENNReal)) = fun _ => 0 := by
                      ext bs; rw [hRunSnoc, hMid]
                    rw [hZ, tsum_zero]; simp
                | some mid =>
                    dsimp only
                    have hLen : (List.ofFn init).length < t := by simp; omega
                    have hHalt1 := (hStep (List.ofFn init) mid hLen hMid).1
                    let E_init := adaptiveStepsTotalEvents alg adv stepEventCount
                      (initAdaptivePrefixState alg) (List.ofFn init)
                    have hRewrite1 :
                        ENNReal.ofReal ((E_init : ℝ) * φ) =
                        ∑' bs : List Bool,
                          if (runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs).isSome then
                            bitListProb bs * ENNReal.ofReal ((E_init : ℝ) * φ)
                          else 0 := by
                      conv_lhs =>
                        rw [← one_mul (ENNReal.ofReal ((E_init : ℝ) * φ)), ← hHalt1]
                      unfold singleStepValidHaltProb
                      rw [← ENNReal.tsum_mul_right]
                      refine tsum_congr fun bs => ?_
                      split_ifs <;> simp
                    rw [hRewrite1, ← mul_add, ← ENNReal.tsum_add, ← ENNReal.tsum_mul_left]
                    refine tsum_congr fun bs => ?_
                    rw [hRunSnoc, hMid, prefixTraceProb_snoc, ofFn_snocTrace]
                    dsimp only
                    cases hS : runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) bs with
                    | none => simp
                    | some pair =>
                        rcases pair with ⟨P', out⟩
                        have hEvApp := adaptiveStepsTotalEvents_append alg adv stepEventCount
                          (List.ofFn init) [bs] (initAdaptivePrefixState alg) mid hMid
                        simp only [adaptiveStepsTotalEvents, hS] at hEvApp
                        dsimp only
                        simp only [Option.isSome_some, ↓reduceIte]
                        rw [hEvApp, ← mul_add, ← ENNReal.ofReal_add (by positivity) (by positivity)]
                        have hAddReal :
                            (E_init : ℝ) * φ +
                              (stepEventCount mid.pointSet mid.history mid.algState (adv mid.history) bs : ℝ) * φ =
                            ((E_init + (stepEventCount mid.pointSet mid.history mid.algState (adv mid.history) bs + 0) : ℕ) : ℝ) * φ := by
                          push_cast; ring
                        rw [hAddReal]
                        ring

open Classical in
theorem fb_conj5 :
    ∀ (d n t B : ℕ) (δ c stepWorkBound spaceBound C_ev : ℝ) (deg_ev C₁ M_max : ℕ)
      (admissiblePts : Set (EuclideanSpace ℝ (Fin d)))
      (State : Type) (alg : DynamicDiameterStructure d State)
      (GoodState : DynamicPointSet d → ExecutionHistory d → State → Prop)
      (stepEventCount :
        DynamicPointSet d → ExecutionHistory d → State → DynamicUpdate d → List Bool → ℕ),
      2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
      let S := execFailureScaleBit n t d B δ
      let φ := perEventFailureBudget S C₁ δ
      (M_max : ℝ) ≤ C_ev * ((S : ℝ) ^ deg_ev) →
      (C_ev * ((S : ℝ) ^ deg_ev)) * φ ≤ δ →
      (alg.initWork : ℝ) ≤ stepWorkBound →
      (alg.initSpace : ℝ) ≤ spaceBound →
      GoodState (DynamicPointSet.empty d) [] alg.initState →
      (∀ adv : AdaptiveAdversary d,
        IsValidBoundedAdversary n t admissiblePts alg adv →
        (∀ (T : ℕ) (trace : Fin T → List Bool),
          T ≤ t →
          (runAdaptivePrefix alg adv T trace).isSome →
            adaptiveStepsTotalEvents alg adv stepEventCount
              (initAdaptivePrefixState alg) (List.ofFn trace) ≤ M_max) ∧
        (∀ (bitTrace : List (List Bool)) (prefSt : AdaptivePrefixState d State),
          bitTrace.length < t →
          runAdaptiveSteps alg adv bitTrace = some prefSt →
            let op := adv prefSt.history
            singleStepValidHaltProb alg prefSt.pointSet prefSt.algState op = 1 ∧
            (∀ (bs : List Bool) (P' : DynamicPointSet d) (out : DynamicStepOutcome State),
              runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs = some (P', out) →
                (out.work : ℝ) ≤ stepWorkBound ∧ (out.peakSpace : ℝ) ≤ spaceBound) ∧
            (GoodState prefSt.pointSet prefSt.history prefSt.algState →
              (∀ (bs : List Bool) (P' : DynamicPointSet d) (out : DynamicStepOutcome State),
                runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs = some (P', out) →
                  let entry : StepHistoryEntry d :=
                    { operation := op
                      randomBits := bs
                      returnedHandle := out.returnedHandle
                      answer := out.storedAnswer
                      resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
                  GoodState P' (prefSt.history ++ [entry]) out.nextState →
                    IsValidFactorCAnswer c P' out.storedAnswer) ∧
              (open Classical in
                ∑' bs : List Bool,
                  match runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs with
                  | some (P', out) =>
                      let entry : StepHistoryEntry d :=
                        { operation := op
                          randomBits := bs
                          returnedHandle := out.returnedHandle
                          answer := out.storedAnswer
                          resolvedIds := resolveAnswerIdentities P' out.storedAnswer }
                      if ¬ GoodState P' (prefSt.history ++ [entry]) out.nextState then
                        bitListProb bs
                      else
                        0
                  | none => 0) ≤
              (∑' bs : List Bool,
                if (runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState op bs).isSome then
                  bitListProb bs *
                    ENNReal.ofReal
                      ((stepEventCount prefSt.pointSet prefSt.history prefSt.algState op bs : ℝ) * φ)
                else
                  0)))) →
        SatisfiesMonteCarloGuarantee n t δ c admissiblePts alg ∧
        SatisfiesBoundedWorstCaseUpdateWorkBound n t admissiblePts alg stepWorkBound ∧
        SatisfiesBoundedSpaceBound n t admissiblePts alg spaceBound := by
  classical
  intro d n t B δ c stepWorkBound spaceBound C_ev deg_ev C₁ M_max admissiblePts State alg
    GoodState stepEventCount hn ht hδ0 hδ1 S φ hM_ub hC_ub hInitW hInitSp hInitGood hAdvAll
  have hS5_nat : 5 ≤ S := by unfold S execFailureScaleBit; omega
  have hS_pos : (0 : ℝ) < (S : ℝ) := by
    have : (5 : ℝ) ≤ (S : ℝ) := by exact_mod_cast hS5_nat
    linarith
  have hφ_nn : 0 ≤ φ := by
    dsimp [φ, perEventFailureBudget]
    positivity
  have hMφ_le_δ : (M_max : ℝ) * φ ≤ δ :=
    (mul_le_mul_of_nonneg_right hM_ub hφ_nn).trans hC_ub
  refine ⟨⟨hδ0, hδ1, ?_⟩, ⟨hInitW, ?_⟩, ⟨hInitSp, ?_⟩⟩
  · -- SatisfiesMonteCarloGuarantee
    intro adv hValidAdv
    obtain ⟨hCapEv, hStepAll⟩ := hAdvAll adv hValidAdv
    refine ⟨fun bitTrace hLen prefSt hRun => (hStepAll bitTrace prefSt hLen hRun).1, ?_⟩
    intro T hTt
    obtain ⟨hHaltT, hBadT⟩ := mc_prefix_ind t c φ hφ_nn alg adv GoodState stepEventCount
      hInitGood (fun bt ps hl hr => ⟨(hStepAll bt ps hl hr).1, (hStepAll bt ps hl hr).2.2⟩) T hTt
    dsimp only at hHaltT hBadT
    let GoodPrefix (out : AdaptivePrefixState d State) : Prop :=
      GoodState out.pointSet out.history out.algState ∧ AllPrefixAnswersValid c out
    have hBad_le_δ :
        (∑' tr : Fin T → List Bool,
          match runAdaptivePrefix alg adv T tr with
          | some out => if ¬ GoodPrefix out then prefixTraceProb tr else 0
          | none => 0) ≤ ENNReal.ofReal δ := by
      calc
        (∑' tr : Fin T → List Bool,
          match runAdaptivePrefix alg adv T tr with
          | some out => if ¬ GoodPrefix out then prefixTraceProb tr else 0
          | none => 0)
            ≤ ∑' tr : Fin T → List Bool,
                match runAdaptivePrefix alg adv T tr with
                | some out =>
                    prefixTraceProb tr *
                      ENNReal.ofReal
                        ((adaptiveStepsTotalEvents alg adv stepEventCount
                          (initAdaptivePrefixState alg) (List.ofFn tr) : ℝ) * φ)
                | none => 0 := hBadT
        _ ≤ ∑' tr : Fin T → List Bool,
              (if (runAdaptivePrefix alg adv T tr).isSome then prefixTraceProb tr else 0) *
                ENNReal.ofReal δ := by
              refine ENNReal.tsum_le_tsum fun tr => ?_
              cases hR : runAdaptivePrefix alg adv T tr with
              | none => simp
              | some out =>
                  dsimp only
                  simp only [Option.isSome_some, ↓reduceIte]
                  apply mul_le_mul_of_nonneg_left _ (zero_le _)
                  apply ENNReal.ofReal_le_ofReal
                  have hEvM : adaptiveStepsTotalEvents alg adv stepEventCount
                      (initAdaptivePrefixState alg) (List.ofFn tr) ≤ M_max :=
                    hCapEv T tr hTt (by simp [hR])
                  have hEvR : (adaptiveStepsTotalEvents alg adv stepEventCount
                      (initAdaptivePrefixState alg) (List.ofFn tr) : ℝ) ≤ (M_max : ℝ) := by
                    exact_mod_cast hEvM
                  exact (mul_le_mul_of_nonneg_right hEvR hφ_nn).trans hMφ_le_δ
        _ = (∑' tr : Fin T → List Bool,
              if (runAdaptivePrefix alg adv T tr).isSome then prefixTraceProb tr else 0) *
                ENNReal.ofReal δ := ENNReal.tsum_mul_right
        _ = 1 * ENNReal.ofReal δ := by rw [hHaltT]
        _ = ENNReal.ofReal δ := one_mul _
    have hPartition :
        (∑' tr : Fin T → List Bool,
          match runAdaptivePrefix alg adv T tr with
          | some out => if GoodPrefix out then prefixTraceProb tr else 0
          | none => 0) +
        (∑' tr : Fin T → List Bool,
          match runAdaptivePrefix alg adv T tr with
          | some out => if ¬ GoodPrefix out then prefixTraceProb tr else 0
          | none => 0) = 1 := by
      rw [← ENNReal.tsum_add, ← hHaltT]
      refine tsum_congr fun tr => ?_
      cases runAdaptivePrefix alg adv T tr with
      | none => simp
      | some out =>
          dsimp only
          by_cases hG : GoodPrefix out <;> simp [hG]
    have hGood_le_Ans :
        (∑' tr : Fin T → List Bool,
          match runAdaptivePrefix alg adv T tr with
          | some out => if GoodPrefix out then prefixTraceProb tr else 0
          | none => 0) ≤
        adaptivePrefixEventProb alg adv T (AllPrefixAnswersValid c) := by
      unfold adaptivePrefixEventProb
      refine ENNReal.tsum_le_tsum fun tr => ?_
      cases runAdaptivePrefix alg adv T tr with
      | none => exact le_rfl
      | some out =>
          dsimp only
          by_cases hG : GoodPrefix out
          · simp [hG, hG.2]
          · simp [hG]
    have hSum1 : ENNReal.ofReal (1 - δ) + ENNReal.ofReal δ = 1 := by
      rw [← ENNReal.ofReal_add (by linarith) hδ0.le]
      norm_num
    have hIneq :
        ENNReal.ofReal (1 - δ) + ENNReal.ofReal δ ≤
          adaptivePrefixEventProb alg adv T (AllPrefixAnswersValid c) + ENNReal.ofReal δ := by
      calc
        ENNReal.ofReal (1 - δ) + ENNReal.ofReal δ = 1 := hSum1
        _ = (∑' tr : Fin T → List Bool,
              match runAdaptivePrefix alg adv T tr with
              | some out => if GoodPrefix out then prefixTraceProb tr else 0
              | none => 0) +
            (∑' tr : Fin T → List Bool,
              match runAdaptivePrefix alg adv T tr with
              | some out => if ¬ GoodPrefix out then prefixTraceProb tr else 0
              | none => 0) := hPartition.symm
        _ ≤ adaptivePrefixEventProb alg adv T (AllPrefixAnswersValid c) + ENNReal.ofReal δ :=
              add_le_add hGood_le_Ans hBad_le_δ
    exact (ENNReal.add_le_add_iff_right ENNReal.ofReal_ne_top).mp hIneq
  · -- SatisfiesBoundedWorstCaseUpdateWorkBound
    intro adv hValidAdv T hTt trace outSt hRun
    obtain ⟨_, hStepAll⟩ := hAdvAll adv hValidAdv
    have hWS := work_and_space_ind t stepWorkBound spaceBound alg adv
      (fun bt ps hl hr => (hStepAll bt ps hl hr).2.1)
      (List.ofFn trace) [] (initAdaptivePrefixState alg) outSt
      (by simp [hTt]) rfl (fun _ h => by simp [initAdaptivePrefixState] at h) hInitSp hRun
    exact hWS.1
  · -- SatisfiesBoundedSpaceBound
    intro adv hValidAdv T hTt trace outSt hRun
    obtain ⟨_, hStepAll⟩ := hAdvAll adv hValidAdv
    have hWS := work_and_space_ind t stepWorkBound spaceBound alg adv
      (fun bt ps hl hr => (hStepAll bt ps hl hr).2.1)
      (List.ofFn trace) [] (initAdaptivePrefixState alg) outSt
      (by simp [hTt]) rfl (fun _ h => by simp [initAdaptivePrefixState] at h) hInitSp hRun
    exact hWS.2

end UL.Proof_clm_7_3_failure_budget_cg_H3
