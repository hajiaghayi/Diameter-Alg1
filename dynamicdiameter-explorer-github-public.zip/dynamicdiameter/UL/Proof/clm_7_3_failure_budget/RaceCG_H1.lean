import UL.Stmt.clm_7_3_failure_budget
import UL.Proof.lem_C_2.H1
import UL.Proof.clm_5_2_config_gap
import UL.Proof.clm_5_3_matching_invariant.H1
set_option autoImplicit false

namespace UL.Proof_clm_7_3_failure_budget_cg_H1

open scoped BigOperators
open UL.Proof_clm_5_3_matching_invariant

private lemma radialCorrelation_symm {d : ℕ} (o x y : EuclideanSpace ℝ (Fin d)) :
    radialCorrelation o x y = radialCorrelation o y x := by
  unfold radialCorrelation
  rw [inner_neg_left, inner_neg_left, real_inner_comm]

private lemma params_K_pos (params : LocalScaleParams) : 0 < params.K := by
  have hc : 0 < 2 / (params.c - 1) := div_pos zero_lt_two (sub_pos.mpr params.one_lt_c)
  have hKr : (0 : ℝ) < (params.K : ℝ) := lt_of_lt_of_le hc params.K_ge
  exact_mod_cast hKr

private lemma retainedConfigs_valid (params : LocalScaleParams) {V : ℝ} {cfg : ShellConfig}
    (hcfg : cfg ∈ params.retainedConfigs V) :
    IsRetainedConfig params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ := by
  classical
  unfold LocalScaleParams.retainedConfigs UL.retainedConfigs at hcfg
  rw [Finset.mem_filter] at hcfg
  rcases hcfg with ⟨hall, hret⟩
  unfold allShellConfigs allShellConfigTriples at hall
  rw [Finset.mem_map] at hall
  rcases hall with ⟨⟨j, k, ℓ⟩, hmem, hEq⟩
  simp only [Function.Embedding.coeFn_mk] at hEq
  subst hEq
  simp only [Finset.mem_product, Finset.mem_Icc, zero_le, true_and] at hmem
  rcases hmem with ⟨⟨hj1, hjm⟩, ⟨hk1, hkm⟩, hℓJ⟩
  have hKpos : 0 ≤ params.K := le_of_lt (params_K_pos params)
  have hk_int : (k : ℤ) ≤ params.K * (shellSubdiv params.e : ℤ) := by
    unfold maxShellIndex at hkm
    have h1 : (k : ℤ) ≤ ((params.K.toNat * shellSubdiv params.e : ℕ) : ℤ) := by
      exact_mod_cast hkm
    simpa [Int.toNat_of_nonneg hKpos] using h1
  exact ⟨⟨hj1, hjm, hk1, hk_int, hℓJ⟩, hret⟩

open Classical in
private lemma checkedRepair_take {d : ℕ} {ι : Type*}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) :
    ∀ (F : List (CopyVertex ι)) (k : ℕ) (st : LocalMatchingState ι)
      (rawAnswers : List (Option ι)),
      F.length ≤ k →
      checkedRepairFormerPartners pts params o V cfg st F rawAnswers =
        checkedRepairFormerPartners pts params o V cfg st F (rawAnswers.take k)
  | [], _, st, _ => fun _ => rfl
  | u :: us, k, st, rawAnswers => fun hlen => by
      cases k with
      | zero => simp at hlen
      | succ m =>
          simp only [List.length_cons] at hlen
          unfold checkedRepairFormerPartners
          split_ifs with hcond
          · exact checkedRepair_take pts params o V cfg us (m + 1) st rawAnswers (by omega)
          · have hhead : (rawAnswers.take (m + 1)).head? = rawAnswers.head? := by
              cases rawAnswers <;> rfl
            have hdrop : (rawAnswers.take (m + 1)).drop 1 = (rawAnswers.drop 1).take m := by
              cases rawAnswers <;> simp
            dsimp only
            rw [hhead, hdrop]
            exact checkedRepair_take pts params o V cfg us m _ (rawAnswers.drop 1) (by omega)

open Classical in
private lemma exists_gamma_empty_strong {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (m0 : ℕ) (lam : ℚ) (hlam : 1 < lam)
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (hV : 0 < V) (ℓ : ℕ)
    (T : Finset ι) :
    ∃ γ_big : ℚ, ∀ (A B : Finset ι), A ⊆ T → B ⊆ T →
      strongEdgesOn pts m0 γ_big lam o V ℓ A B = ∅ := by
  by_cases hNE : T.Nonempty
  · have hR_pos : 0 < distScale lam V ℓ := by
      unfold distScale
      have hsqrt : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
      have hlam_pos : (0 : ℝ) < (lam : ℝ) := by
        have h1 : (1 : ℝ) < (lam : ℝ) := by exact_mod_cast hlam
        linarith
      exact div_pos (mul_pos (pow_pos hlam_pos ℓ) hsqrt) zero_lt_two
    let g : ι × ι → ℝ := fun xy =>
      ‖inwardRound m0 o V (pts xy.1) - inwardRound m0 o V (pts xy.2)‖
    have hPNE : (T ×ˢ T).Nonempty := hNE.product hNE
    let B_max : ℝ := (T ×ˢ T).sup' hPNE g + 1
    obtain ⟨γ_big, hγ_gt⟩ := exists_rat_gt (B_max / distScale lam V ℓ)
    refine ⟨γ_big, fun A B hA hB => ?_⟩
    rw [Finset.eq_empty_iff_forall_notMem]
    intro xy hxy
    unfold strongEdgesOn at hxy
    rw [Finset.mem_filter, Finset.mem_product] at hxy
    rcases hxy with ⟨⟨hxA, hyB⟩, hStrong⟩
    unfold IsStrongRoundedPair at hStrong
    have hxyT : xy ∈ T ×ˢ T := Finset.mem_product.mpr ⟨hA hxA, hB hyB⟩
    have hTerm_le : g xy ≤ (T ×ˢ T).sup' hPNE g := Finset.le_sup' g hxyT
    have hB_lt : B_max < (γ_big : ℝ) * distScale lam V ℓ :=
      (div_lt_iff₀ hR_pos).mp hγ_gt
    change (γ_big : ℝ) * distScale lam V ℓ < g xy at hStrong
    change (T ×ˢ T).sup' hPNE g + 1 < (γ_big : ℝ) * distScale lam V ℓ at hB_lt
    linarith
  · have hTeq : T = ∅ := Finset.not_nonempty_iff_eq_empty.mp hNE
    refine ⟨2, fun A B hA _ => ?_⟩
    have hAe : A = ∅ := Finset.subset_empty.mp (hTeq ▸ hA)
    subst hAe
    unfold strongEdgesOn
    simp

open Classical in
private lemma sanitize_edge_promise_gamma_big {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (γ_big : ℚ) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (hV : 0 < V) (cfg : ShellConfig) (hcfg : cfg ∈ params.retainedConfigs V)
    (T A B : Finset ι)
    (hAL : A ⊆ params.leftVertices pts o V T cfg.j)
    (hBR : B ⊆ params.rightVertices pts o V T cfg.k)
    (hStrongEmpty : strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ A B = ∅)
    (st : LocalMatchingState ι)
    (v : CopyVertex ι)
    (hvAct : isCopyActive A B v)
    (hU_sub : match v.side with
      | .left => st.rightIndexSet ⊆ B
      | .right => st.leftIndexSet ⊆ A)
    (rawAns : Option ι) :
    SatisfiesEdgeSearchPromise
      (weakEdgesOn pts params.m0 params.lam o V cfg.ℓ A B)
      (strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ A B)
      (st.oppositeIndexSet v.side) v
      (sanitizeConfigAttachAnswer pts params o V cfg st v rawAns) := by
  have hret := retainedConfigs_valid params hcfg
  have hpair := (P_clm_5_2_config_gap params.e params.γ params.lam params.K V cfg.j cfg.k cfg.ℓ
    params.e_pos params.one_lt_γ params.one_lt_lam hV hret).1 d
  have hShL : ∀ x ∈ A, shellIndex params.m0 o V (pts x) = cfg.j := by
    intro x hx
    have hx' := hAL hx
    unfold LocalScaleParams.leftVertices configLeftVertices shellSubset at hx'
    exact (Finset.mem_filter.mp hx').2
  have hShR : ∀ y ∈ B, shellIndex params.m0 o V (pts y) = cfg.k := by
    intro y hy
    have hy' := hBR hy
    unfold LocalScaleParams.rightVertices configRightVertices shellSubset at hy'
    exact (Finset.mem_filter.mp hy').2
  cases rawAns with
  | none =>
      rw [hStrongEmpty]
      unfold sanitizeConfigAttachAnswer SatisfiesEdgeSearchPromise
      rcases v with ⟨_ | _, vid⟩ <;> simp
  | some w =>
      unfold sanitizeConfigAttachAnswer
      dsimp only
      split_ifs with hcond
      · rcases hcond with ⟨hw_opp, hacc⟩
        unfold attachAcceptsCorrelation LocalScaleParams.thresholdB at hacc
        rcases v with ⟨_ | _, vid⟩
        · dsimp [SatisfiesEdgeSearchPromise]
          dsimp [LocalMatchingState.oppositeIndexSet] at hw_opp
          have hwB : w ∈ B := hU_sub hw_opp
          have hweak := (hpair o (pts vid) (pts w) (hShL vid hvAct) (hShR w hwB)).2.mpr hacc
          refine ⟨hw_opp, ?_⟩
          unfold weakEdgesOn
          exact Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hvAct, hwB⟩, hweak⟩
        · dsimp [SatisfiesEdgeSearchPromise]
          dsimp [LocalMatchingState.oppositeIndexSet] at hw_opp
          have hwA : w ∈ A := hU_sub hw_opp
          rw [radialCorrelation_symm o (pts vid) (pts w)] at hacc
          have hweak := (hpair o (pts w) (pts vid) (hShL w hwA) (hShR vid hvAct)).2.mpr hacc
          refine ⟨hw_opp, ?_⟩
          unfold weakEdgesOn
          exact Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hwA, hvAct⟩, hweak⟩
      · rw [hStrongEmpty]
        unfold SatisfiesEdgeSearchPromise
        rcases v with ⟨_ | _, vid⟩ <;> simp

open Classical in
private lemma repair_preserves_gamma_big {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (γ_big : ℚ) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (hV : 0 < V) (cfg : ShellConfig) (hcfg : cfg ∈ params.retainedConfigs V)
    (T : Finset ι)
    (V_L' V_R' : Finset ι)
    (hVL' : V_L' = params.leftVertices pts o V T cfg.j)
    (hVR' : V_R' = params.rightVertices pts o V T cfg.k)
    (hStrongAll : ∀ (A B : Finset ι), A ⊆ T → B ⊆ T →
      strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ A B = ∅) :
    ∀ (L : List (CopyVertex ι)) (cur : LocalMatchingState ι) (rawAnswers : List (Option ι)),
      L.Nodup →
      (∀ u ∈ L, isCopyActive V_L' V_R' u) →
      cur.SatisfiesInvariant pts (remLeft L V_L') (remRight L V_R')
        (weakEdgesOn pts params.m0 params.lam o V cfg.ℓ (remLeft L V_L') (remRight L V_R'))
        (strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ (remLeft L V_L') (remRight L V_R')) →
      (checkedRepairFormerPartners pts params o V cfg cur L rawAnswers).SatisfiesInvariant pts
        V_L' V_R'
        (weakEdgesOn pts params.m0 params.lam o V cfg.ℓ V_L' V_R')
        (strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ V_L' V_R')
  | [], cur, _, _, _, hinv => by
      have hL : remLeft [] V_L' = V_L' := by ext x; simp [remLeft]
      have hR : remRight [] V_R' = V_R' := by ext y; simp [remRight]
      unfold checkedRepairFormerPartners
      rwa [hL, hR] at hinv
  | u :: us, cur, rawAnswers, hnd, hact, hinv => by
      rw [List.nodup_cons] at hnd
      rcases hnd with ⟨hu_not_us, hnd_us⟩
      rcases hinv.1 with ⟨_, _, hedges, _, hlset, _, hrset, _⟩
      have hu_absent : ¬ (cur.isCopyMatched u ∨ cur.isCopyInIndex u) := by
        rcases u with ⟨_ | _, uid⟩
        · have huid_not : uid ∉ remLeft (⟨.left, uid⟩ :: us) V_L' := by simp [remLeft]
          dsimp only [LocalMatchingState.isCopyMatched, LocalMatchingState.isCopyInIndex]
          rintro (⟨e, he, hel⟩ | ⟨e, he, heid⟩)
          · subst hel; exact huid_not (hedges e he).1
          · have hmem : uid ∈ cur.leftIndexSet := by
              simp only [LocalMatchingState.leftIndexSet, List.mem_toFinset, List.mem_map]
              exact ⟨e, he, heid⟩
            rw [hlset] at hmem
            exact huid_not (Finset.mem_filter.mp hmem).1
        · have huid_not : uid ∉ remRight (⟨.right, uid⟩ :: us) V_R' := by simp [remRight]
          dsimp only [LocalMatchingState.isCopyMatched, LocalMatchingState.isCopyInIndex]
          rintro (⟨e, he, her⟩ | ⟨e, he, heid⟩)
          · subst her; exact huid_not (hedges e he).2.1
          · have hmem : uid ∈ cur.rightIndexSet := by
              simp only [LocalMatchingState.rightIndexSet, List.mem_toFinset, List.mem_map]
              exact ⟨e, he, heid⟩
            rw [hrset] at hmem
            exact huid_not (Finset.mem_filter.mp hmem).1
      unfold checkedRepairFormerPartners
      rw [if_neg hu_absent]
      dsimp only
      let A_next := remLeft us V_L'
      let B_next := remRight us V_R'
      have hA_sub_VL : A_next ⊆ V_L' := Finset.filter_subset _ _
      have hB_sub_VR : B_next ⊆ V_R' := Finset.filter_subset _ _
      have hVL'_sub_T : V_L' ⊆ T := by
        rw [hVL']; intro x hx
        unfold LocalScaleParams.leftVertices configLeftVertices shellSubset nodeCore at hx
        exact (Finset.mem_filter.mp (Finset.mem_filter.mp hx).1).1
      have hVR'_sub_T : V_R' ⊆ T := by
        rw [hVR']; intro y hy
        unfold LocalScaleParams.rightVertices configRightVertices shellSubset nodeEligible at hy
        exact (Finset.mem_filter.mp (Finset.mem_filter.mp hy).1).1
      have hu_act_next : isCopyActive A_next B_next u := by
        have hu_act := hact u List.mem_cons_self
        rcases u with ⟨_ | _, uid⟩ <;> exact Finset.mem_filter.mpr ⟨hu_act, hu_not_us⟩
      have hA0_eq : (if u.side = .left then A_next.erase u.id else A_next) =
          remLeft (u :: us) V_L' := by
        rcases u with ⟨_ | _, uid⟩
        · dsimp only; rw [if_pos rfl]; ext x; simp [A_next, remLeft]; tauto
        · dsimp only; rw [if_neg (by intro h; cases h)]; ext x; simp [A_next, remLeft]
      have hB0_eq : (if u.side = .right then B_next.erase u.id else B_next) =
          remRight (u :: us) V_R' := by
        rcases u with ⟨_ | _, uid⟩
        · dsimp only; rw [if_neg (by intro h; cases h)]; ext y; simp [B_next, remRight]
        · dsimp only; rw [if_pos rfl]; ext y; simp [B_next, remRight]; tauto
      have hU_sub : match u.side with
          | .left => cur.rightIndexSet ⊆ B_next
          | .right => cur.leftIndexSet ⊆ A_next := by
        cases hSide : u.side
        · rw [hrset]
          have hB0 : remRight (u :: us) V_R' ⊆ B_next := by
            rw [← hB0_eq, hSide, if_neg (by intro h; cases h)]
          exact (Finset.filter_subset _ _).trans hB0
        · rw [hlset]
          have hA0 : remLeft (u :: us) V_L' ⊆ A_next := by
            rw [← hA0_eq, hSide, if_neg (by intro h; cases h)]
          exact (Finset.filter_subset _ _).trans hA0
      let cAns := sanitizeConfigAttachAnswer pts params o V cfg cur u rawAnswers.head?.join
      have hprom := sanitize_edge_promise_gamma_big pts params γ_big o V hV cfg hcfg T
        A_next B_next (hVL' ▸ hA_sub_VL) (hVR' ▸ hB_sub_VR)
        (hStrongAll A_next B_next (hA_sub_VL.trans hVL'_sub_T) (hB_sub_VR.trans hVR'_sub_T))
        cur u hu_act_next hU_sub rawAnswers.head?.join
      have hnot := not_or.mp hu_absent
      have hstep : ValidAttachEdgeStep pts A_next B_next
          (weakEdgesOn pts params.m0 params.lam o V cfg.ℓ A_next B_next)
          (strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ A_next B_next)
          cur u (attachStep pts cur u cAns) := ⟨⟨hu_act_next, hnot.1, hnot.2⟩, cAns, hprom, rfl⟩
      have hinv_pre :
          (let V_L₀ := if u.side = .left then A_next.erase u.id else A_next
           let V_R₀ := if u.side = .right then B_next.erase u.id else B_next
           cur.SatisfiesInvariant pts V_L₀ V_R₀
             (weakEdgesOn pts params.m0 params.lam o V cfg.ℓ V_L₀ V_R₀)
             (strongEdgesOn pts params.m0 γ_big params.lam o V cfg.ℓ V_L₀ V_R₀)) := by
        dsimp only; rwa [hA0_eq, hB0_eq]
      have hinv1 := attach_edge_preserves_invariant pts params.m0 γ_big params.lam o V cfg.ℓ
        A_next B_next cur u (attachStep pts cur u cAns) hinv_pre hstep
      exact repair_preserves_gamma_big pts params γ_big o V hV cfg hcfg T V_L' V_R' hVL' hVR'
        hStrongAll us (attachStep pts cur u cAns) (rawAnswers.drop 1) hnd_us
        (fun w hw => hact w (List.mem_cons_of_mem _ hw)) hinv1

open Classical in
private lemma fb_conj2b_classical {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (params : LocalScaleParams) (ball : ChainNode d)
    (S : Finset ι) (states : ShellConfig → LocalMatchingState ι)
    (hValid : ValidNodeMatchingsOn pts (.subSqrt2 params) ball S states) :
    (∀ (p : ι) (qAns : NodeMatchingQueryAnswers ι),
      p ∉ S →
        ValidNodeMatchingsOn pts (.subSqrt2 params) ball (insert p S)
          (applyNodeMatchingInsert pts (.subSqrt2 params) ball states p qAns)) ∧
    (∀ (p : ι) (qAns : NodeMatchingQueryAnswers ι),
      p ∈ S →
        ValidNodeMatchingsOn pts (.subSqrt2 params) ball (S.erase p)
          (applyNodeMatchingDelete pts (.subSqrt2 params) ball states p qAns) ∧
        ∀ cfg ∈ (Alg4Mode.subSqrt2 params).retainedConfigs ball.V,
          (survivingFormerPartners (states cfg) p).length ≤ 2 ∧
          checkedConfigDeleteOriginal pts params ball.o ball.V cfg (states cfg) p
              (qAns.deleteRepairAns cfg) =
            checkedConfigDeleteOriginal pts params ball.o ball.V cfg (states cfg) p
              ((qAns.deleteRepairAns cfg).take 2)) := by
  rcases hValid with ⟨_, hIn⟩
  dsimp only at hIn
  refine ⟨?_, ?_⟩
  · intro p qAns hpNotS
    refine ⟨fun cfg hcfg => by unfold applyNodeMatchingInsert; simp [hcfg], ?_⟩
    intro cfg hcfg
    unfold applyNodeMatchingInsert
    dsimp only
    rw [if_pos hcfg]
    have hVpos_and_cfg : 0 < ball.V ∧ cfg ∈ params.retainedConfigs ball.V := by
      unfold Alg4Mode.retainedConfigs at hcfg
      split_ifs at hcfg with hV
      · exact ⟨hV, hcfg⟩
      · simp at hcfg
    rcases hVpos_and_cfg with ⟨hV, hcfg_p⟩
    obtain ⟨hwf, hweak⟩ := hIn cfg hcfg
    rcases hwf with ⟨hndL0, hndR0, hedges0, hndLi0, hlset0, hndRi0, hrset0, hrest0⟩
    have hwf_full : (states cfg).WellFormed pts
        (params.leftVertices pts ball.o ball.V S cfg.j)
        (params.rightVertices pts ball.o ball.V S cfg.k) :=
      ⟨hndL0, hndR0, hedges0, hndLi0, hlset0, hndRi0, hrset0, hrest0⟩
    have hbip := bipartiteMatching_of_wellFormed hwf_full
    let T := insert p S
    obtain ⟨γ_big, hStrongAll⟩ := exists_gamma_empty_strong pts params.m0 params.lam
      params.one_lt_lam ball.o ball.V hV cfg.ℓ T
    let V_L := params.leftVertices pts ball.o ball.V S cfg.j
    let V_R := params.rightVertices pts ball.o ball.V S cfg.k
    let V_L' := params.leftVertices pts ball.o ball.V T cfg.j
    let V_R' := params.rightVertices pts ball.o ball.V T cfg.k
    have hVL'_sub_T : V_L' ⊆ T := by
      intro z hz
      unfold V_L' LocalScaleParams.leftVertices configLeftVertices shellSubset nodeCore at hz
      exact (Finset.mem_filter.mp (Finset.mem_filter.mp hz).1).1
    have hVR'_sub_T : V_R' ⊆ T := by
      intro z hz
      unfold V_R' LocalScaleParams.rightVertices configRightVertices shellSubset nodeEligible at hz
      exact (Finset.mem_filter.mp (Finset.mem_filter.mp hz).1).1
    have hSubL : V_L ⊆ V_L' := by
      intro z hz
      simp only [V_L, V_L', T, LocalScaleParams.leftVertices, configLeftVertices, shellSubset,
        nodeCore, Finset.mem_filter, Finset.mem_insert] at hz ⊢
      exact ⟨⟨Or.inr hz.1.1, hz.1.2⟩, hz.2⟩
    have hSubR : V_R ⊆ V_R' := by
      intro z hz
      simp only [V_R, V_R', T, LocalScaleParams.rightVertices, configRightVertices, shellSubset,
        nodeEligible, Finset.mem_filter, Finset.mem_insert] at hz ⊢
      exact ⟨⟨Or.inr hz.1.1, hz.1.2⟩, hz.2⟩
    have hEraseL : V_L'.erase p = V_L := by
      ext z
      simp only [V_L, V_L', T, LocalScaleParams.leftVertices, configLeftVertices, shellSubset,
        nodeCore, Finset.mem_erase, Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨hne, ⟨rfl | hzS, hzC⟩, hzSh⟩
        · exact False.elim (hne rfl)
        · exact ⟨⟨hzS, hzC⟩, hzSh⟩
      · rintro ⟨⟨hzS, hzC⟩, hzSh⟩
        exact ⟨fun hEq => hpNotS (hEq ▸ hzS), ⟨Or.inr hzS, hzC⟩, hzSh⟩
    have hEraseR : V_R'.erase p = V_R := by
      ext z
      simp only [V_R, V_R', T, LocalScaleParams.rightVertices, configRightVertices, shellSubset,
        nodeEligible, Finset.mem_erase, Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨hne, ⟨rfl | hzS, hzE⟩, hzSh⟩
        · exact False.elim (hne rfl)
        · exact ⟨⟨hzS, hzE⟩, hzSh⟩
      · rintro ⟨⟨hzS, hzE⟩, hzSh⟩
        exact ⟨fun hEq => hpNotS (hEq ▸ hzS), ⟨Or.inr hzS, hzE⟩, hzSh⟩
    have hp_iff_L : p ∈ V_L' ↔ hasApplicableLeftCopy params.m0 ball.o ball.V cfg.j (pts p) := by
      simp [V_L', T, LocalScaleParams.leftVertices, configLeftVertices, shellSubset, nodeCore,
        hasApplicableLeftCopy]
    have hp_iff_R : p ∈ V_R' ↔ hasApplicableRightCopy params.m0 ball.o ball.V params.K cfg.k (pts p) := by
      simp [V_R', T, LocalScaleParams.rightVertices, configRightVertices, shellSubset, nodeEligible,
        hasApplicableRightCopy]
    have hpNotVL : p ∉ V_L := by rw [← hEraseL]; simp
    have hpNotVR : p ∉ V_R := by rw [← hEraseR]; simp
    have hInv0 : (states cfg).SatisfiesInvariant pts V_L V_R
        (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L V_R)
        (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ V_L V_R) := by
      rw [hStrongAll V_L V_R (hSubL.trans hVL'_sub_T) (hSubR.trans hVR'_sub_T)]
      exact ⟨hwf_full, hweak, hbip, Finset.disjoint_empty_left _⟩
    let st₁ :=
      if hasApplicableLeftCopy params.m0 ball.o ball.V cfg.j (pts p) then
        attachStep pts (states cfg) ⟨.left, p⟩
          (sanitizeConfigAttachAnswer pts params ball.o ball.V cfg (states cfg) ⟨.left, p⟩
            (qAns.insertLeftAns cfg))
      else states cfg
    have hInv1 : st₁.SatisfiesInvariant pts V_L' V_R
        (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L' V_R)
        (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ V_L' V_R) := by
      dsimp [st₁]
      split_ifs with hAppL
      · have hpVL' : p ∈ V_L' := hp_iff_L.mpr hAppL
        have hnoM : ¬ (states cfg).isCopyMatched ⟨.left, p⟩ := by
          rintro ⟨e, he, hEq⟩
          dsimp only at hEq
          subst hEq
          exact hpNotVL (hedges0 e he).1
        have hnoI : ¬ (states cfg).isCopyInIndex ⟨.left, p⟩ := by
          rintro ⟨e, he, hEq⟩
          have hm : p ∈ (states cfg).leftIndexSet := by
            simp only [LocalMatchingState.leftIndexSet, List.mem_toFinset, List.mem_map]
            exact ⟨e, he, hEq⟩
          rw [hlset0] at hm
          exact hpNotVL (Finset.mem_filter.mp hm).1
        have hU_sub : (states cfg).rightIndexSet ⊆ V_R := by
          rw [hrset0]; exact Finset.filter_subset _ _
        have hpromL := sanitize_edge_promise_gamma_big pts params γ_big ball.o ball.V hV cfg hcfg_p
          T V_L' V_R (Finset.Subset.refl _) hSubR
          (hStrongAll V_L' V_R hVL'_sub_T (hSubR.trans hVR'_sub_T))
          (states cfg) ⟨.left, p⟩ hpVL' hU_sub (qAns.insertLeftAns cfg)
        refine attach_edge_preserves_invariant pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ
          V_L' V_R (states cfg) ⟨.left, p⟩ _ ?_ ⟨⟨hpVL', hnoM, hnoI⟩, _, hpromL, rfl⟩
        dsimp only
        rw [if_pos rfl, if_neg (by intro h; cases h), hEraseL]
        exact hInv0
      · have hVLeq : V_L' = V_L := by
          rw [← hEraseL]
          exact (Finset.erase_eq_of_notMem (fun hp => hAppL (hp_iff_L.mp hp))).symm
        rwa [hVLeq]
    rcases hInv1.1 with ⟨_, _, hedges1, _, hlset1, _, hrset1, _⟩
    have hInv2 : (checkedConfigInsertOriginal pts params ball.o ball.V cfg (states cfg) p
        (qAns.insertLeftAns cfg) (qAns.insertRightAns cfg)).SatisfiesInvariant pts V_L' V_R'
        (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L' V_R')
        (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ V_L' V_R') := by
      unfold checkedConfigInsertOriginal
      change (if hasApplicableRightCopy params.m0 ball.o ball.V params.K cfg.k (pts p) then
          attachStep pts st₁ ⟨.right, p⟩
            (sanitizeConfigAttachAnswer pts params ball.o ball.V cfg st₁ ⟨.right, p⟩
              (qAns.insertRightAns cfg))
        else st₁).SatisfiesInvariant pts V_L' V_R' _ _
      split_ifs with hAppR
      · have hpVR' : p ∈ V_R' := hp_iff_R.mpr hAppR
        have hnoM : ¬ st₁.isCopyMatched ⟨.right, p⟩ := by
          rintro ⟨e, he, hEq⟩
          dsimp only at hEq
          subst hEq
          exact hpNotVR (hedges1 e he).2.1
        have hnoI : ¬ st₁.isCopyInIndex ⟨.right, p⟩ := by
          rintro ⟨e, he, hEq⟩
          have hm : p ∈ st₁.rightIndexSet := by
            simp only [LocalMatchingState.rightIndexSet, List.mem_toFinset, List.mem_map]
            exact ⟨e, he, hEq⟩
          rw [hrset1] at hm
          exact hpNotVR (Finset.mem_filter.mp hm).1
        have hU_sub : st₁.leftIndexSet ⊆ V_L' := by
          rw [hlset1]; exact Finset.filter_subset _ _
        have hpromR := sanitize_edge_promise_gamma_big pts params γ_big ball.o ball.V hV cfg hcfg_p
          T V_L' V_R' (Finset.Subset.refl _) (Finset.Subset.refl _)
          (hStrongAll V_L' V_R' hVL'_sub_T hVR'_sub_T)
          st₁ ⟨.right, p⟩ hpVR' hU_sub (qAns.insertRightAns cfg)
        refine attach_edge_preserves_invariant pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ
          V_L' V_R' st₁ ⟨.right, p⟩ _ ?_ ⟨⟨hpVR', hnoM, hnoI⟩, _, hpromR, rfl⟩
        dsimp only
        rw [if_neg (by intro h; cases h), if_pos rfl, hEraseR]
        exact hInv1
      · have hVReq : V_R' = V_R := by
          rw [← hEraseR]
          exact (Finset.erase_eq_of_notMem (fun hp => hAppR (hp_iff_R.mp hp))).symm
        rwa [hVReq]
    exact ⟨hInv2.1, hInv2.2.1⟩
  · intro p qAns hpS
    have hDelValid : ValidNodeMatchingsOn pts (.subSqrt2 params) ball (S.erase p)
        (applyNodeMatchingDelete pts (.subSqrt2 params) ball states p qAns) := by
      refine ⟨fun cfg hcfg => by unfold applyNodeMatchingDelete; simp [hcfg], ?_⟩
      intro cfg hcfg
      unfold applyNodeMatchingDelete
      dsimp only
      rw [if_pos hcfg]
      have hVpos_and_cfg : 0 < ball.V ∧ cfg ∈ params.retainedConfigs ball.V := by
        unfold Alg4Mode.retainedConfigs at hcfg
        split_ifs at hcfg with hV
        · exact ⟨hV, hcfg⟩
        · simp at hcfg
      rcases hVpos_and_cfg with ⟨hV, hcfg_p⟩
      obtain ⟨hwf, hweak⟩ := hIn cfg hcfg
      have hbip := bipartiteMatching_of_wellFormed hwf
      obtain ⟨γ_big, hStrongAll⟩ := exists_gamma_empty_strong pts params.m0 params.lam
        params.one_lt_lam ball.o ball.V hV cfg.ℓ S
      let V_L := params.leftVertices pts ball.o ball.V S cfg.j
      let V_R := params.rightVertices pts ball.o ball.V S cfg.k
      let V_L' := params.leftVertices pts ball.o ball.V (S.erase p) cfg.j
      let V_R' := params.rightVertices pts ball.o ball.V (S.erase p) cfg.k
      have hVL_sub_S : V_L ⊆ S := by
        intro z hz
        unfold V_L LocalScaleParams.leftVertices configLeftVertices shellSubset nodeCore at hz
        exact (Finset.mem_filter.mp (Finset.mem_filter.mp hz).1).1
      have hVR_sub_S : V_R ⊆ S := by
        intro z hz
        unfold V_R LocalScaleParams.rightVertices configRightVertices shellSubset nodeEligible at hz
        exact (Finset.mem_filter.mp (Finset.mem_filter.mp hz).1).1
      have hVLeq : V_L.erase p = V_L' := by
        ext z
        simp only [V_L, V_L', LocalScaleParams.leftVertices, configLeftVertices, shellSubset,
          nodeCore, Finset.mem_erase, Finset.mem_filter]
        tauto
      have hVReq : V_R.erase p = V_R' := by
        ext z
        simp only [V_R, V_R', LocalScaleParams.rightVertices, configRightVertices, shellSubset,
          nodeEligible, Finset.mem_erase, Finset.mem_filter]
        tauto
      have hInv0 : (states cfg).SatisfiesInvariant pts V_L V_R
          (weakEdgesOn pts params.m0 params.lam ball.o ball.V cfg.ℓ V_L V_R)
          (strongEdgesOn pts params.m0 γ_big params.lam ball.o ball.V cfg.ℓ V_L V_R) := by
        rw [hStrongAll V_L V_R hVL_sub_S hVR_sub_S]
        exact ⟨hwf, hweak, hbip, Finset.disjoint_empty_left _⟩
      have hRem := removeCopies_satisfies_invariant pts params.m0 γ_big params.lam
        ball.o ball.V cfg.ℓ V_L V_R (states cfg) p hInv0
      dsimp only at hRem
      rw [hVLeq, hVReq] at hRem
      have hF_nd : (survivingFormerPartners (states cfg) p).Nodup := by
        unfold survivingFormerPartners
        exact List.nodup_dedup _
      have hActF : ∀ u ∈ survivingFormerPartners (states cfg) p, isCopyActive V_L' V_R' u := by
        intro u hu
        have ha := surviving_partners_active hwf p hu
        rwa [hVLeq, hVReq] at ha
      have hRep := repair_preserves_gamma_big pts params γ_big ball.o ball.V hV cfg hcfg_p
        (S.erase p) V_L' V_R' rfl rfl
        (fun A B hA hB => hStrongAll A B
          (hA.trans (Finset.erase_subset p S)) (hB.trans (Finset.erase_subset p S)))
        (survivingFormerPartners (states cfg) p)
        (removeCopiesFromState (states cfg) p) (qAns.deleteRepairAns cfg) hF_nd hActF hRem
      exact ⟨hRep.1, hRep.2.1⟩
    refine ⟨hDelValid, ?_⟩
    intro cfg hcfg
    obtain ⟨hwf, _⟩ := hIn cfg hcfg
    have hBounds := surviving_partners_bounds hwf p
    refine ⟨hBounds.2, ?_⟩
    unfold checkedConfigDeleteOriginal
    exact checkedRepair_take pts params ball.o ball.V cfg
      (survivingFormerPartners (states cfg) p) 2
      (removeCopiesFromState (states cfg) p) (qAns.deleteRepairAns cfg) hBounds.2

open Classical in
private lemma fb_conj2a_classical {d : ℕ} {ι : Type}
    (pts : ι → EuclideanSpace ℝ (Fin d))
    (α : ℝ) (S_birth : Finset ι) (bId : ι) (res : SampledCenterResult d)
    (hα0 : 0 < α) (hα1 : α ≤ 1) (hbId : bId ∈ S_birth) :
    let ball := selectOpenedLevelBall α pts S_birth bId res
    PassesBirthCoreCheck α pts ball S_birth ∧
    (ball.residual pts S_birth).card < S_birth.card := by
  let ball := selectOpenedLevelBall α pts S_birth bId res
  have hProv : IsProvisionalCenter pts S_birth res (provisionalCenter pts bId res) := by
    cases res with
    | infeasible => exact ⟨bId, hbId, rfl⟩
    | candidate o V =>
        by_cases hV : 0 ≤ V
        · simp [IsProvisionalCenter, provisionalCenter, hV]
        · simp only [IsProvisionalCenter, provisionalCenter, hV, ↓reduceDIte]
          exact ⟨bId, hbId, rfl⟩
  have hValidBall : IsValidOpenedLevelBall α pts S_birth res ball :=
    ⟨provisionalCenter pts bId res, hProv, rfl⟩
  have hPass : PassesBirthCoreCheck α pts ball S_birth :=
    UL.Proof.lem_C_2.H1.applyBirthCoreFallback_passes hα1 pts S_birth res ball hValidBall
  refine ⟨hPass, ?_⟩
  have hCardPos : 1 ≤ S_birth.card := Finset.card_pos.mpr ⟨bId, hbId⟩
  have hCoreCardPos : 0 < ((ball.core pts S_birth).card : ℝ) := by
    unfold PassesBirthCoreCheck at hPass
    have hSpos : (0 : ℝ) < (S_birth.card : ℝ) := by exact_mod_cast hCardPos
    linarith [mul_pos hα0 hSpos]
  have hCoreNE : (ball.core pts S_birth).Nonempty := by
    rw [← Finset.card_pos]
    exact_mod_cast hCoreCardPos
  rcases hCoreNE with ⟨x, hxCore⟩
  have hxInS : x ∈ S_birth := by
    unfold ChainNode.core nodeCore at hxCore
    exact (Finset.mem_filter.mp hxCore).1
  have hSub : ball.residual pts S_birth ⊆ S_birth := by
    unfold ChainNode.residual nodeResidual
    exact Finset.sdiff_subset
  refine Finset.card_lt_card ⟨hSub, fun hRev => ?_⟩
  have hxRes : x ∈ ball.residual pts S_birth := hRev hxInS
  unfold ChainNode.residual nodeResidual at hxRes
  exact (Finset.mem_sdiff.mp hxRes).2 hxCore

open Classical in
theorem fb_conj2 :
    (∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (α : ℝ) (S_birth : Finset ι) (bId : ι) (res : SampledCenterResult d),
      0 < α → α ≤ 1 → bId ∈ S_birth →
        let ball := selectOpenedLevelBall α pts S_birth bId res
        PassesBirthCoreCheck α pts ball S_birth ∧
        (ball.residual pts S_birth).card < S_birth.card) ∧
    (∀ (d : ℕ) (ι : Type) [DecidableEq ι]
      (pts : ι → EuclideanSpace ℝ (Fin d))
      (params : LocalScaleParams) (ball : ChainNode d)
      (S : Finset ι) (states : ShellConfig → LocalMatchingState ι),
      ValidNodeMatchingsOn pts (.subSqrt2 params) ball S states →
        (∀ (p : ι) (qAns : NodeMatchingQueryAnswers ι),
          p ∉ S →
            ValidNodeMatchingsOn pts (.subSqrt2 params) ball (insert p S)
              (applyNodeMatchingInsert pts (.subSqrt2 params) ball states p qAns)) ∧
        (∀ (p : ι) (qAns : NodeMatchingQueryAnswers ι),
          p ∈ S →
            ValidNodeMatchingsOn pts (.subSqrt2 params) ball (S.erase p)
              (applyNodeMatchingDelete pts (.subSqrt2 params) ball states p qAns) ∧
            ∀ cfg ∈ (Alg4Mode.subSqrt2 params).retainedConfigs ball.V,
              (survivingFormerPartners (states cfg) p).length ≤ 2 ∧
              checkedConfigDeleteOriginal pts params ball.o ball.V cfg (states cfg) p
                  (qAns.deleteRepairAns cfg) =
                checkedConfigDeleteOriginal pts params ball.o ball.V cfg (states cfg) p
                  ((qAns.deleteRepairAns cfg).take 2))) := by
  refine ⟨?_, ?_⟩
  · intro d ι _ pts α S_birth bId res hα0 hα1 hbId
    exact fb_conj2a_classical pts α S_birth bId res hα0 hα1 hbId
  · intro d ι _ pts params ball S states hValid
    obtain ⟨hInsCls, hDelCls⟩ := fb_conj2b_classical pts params ball S states hValid
    refine ⟨?_, ?_⟩
    · intro p qAns hpNotS
      have h1 := hInsCls p qAns hpNotS
      convert h1 using 1
      ext z; simp
    · intro p qAns hpS
      obtain ⟨h1, h2⟩ := hDelCls p qAns hpS
      refine ⟨?_, h2⟩
      convert h1 using 1
      ext z; simp

end UL.Proof_clm_7_3_failure_budget_cg_H1
