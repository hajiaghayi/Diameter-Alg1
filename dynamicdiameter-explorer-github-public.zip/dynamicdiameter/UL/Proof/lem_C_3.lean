import Mathlib
import UL.Stmt.lem_C_3
import UL.Stmt.clm_5_4_queries_and_caps
import UL.Stmt.claim_C_3_sync_suffix
import UL.Proof.lem_C_3.RacerCG_H3
set_option autoImplicit false

namespace UL.Proof.lem_C_3.RacerCG

theorem isBoundedByPoly3_add {f g : ℕ → ℕ → ℕ → ℝ}
    (hf : UL.IsBoundedByPoly3 f) (hg : UL.IsBoundedByPoly3 g) :
    UL.IsBoundedByPoly3 (fun d B L => f d B L + g d B L) := by
  rcases hf with ⟨Cf, df, hCf, hfb⟩
  rcases hg with ⟨Cg, dg, hCg, hgb⟩
  refine ⟨Cf + Cg, max df dg, add_nonneg hCf hCg, fun d B L => ?_⟩
  have hd1 : (1 : ℝ) ≤ (d + 1 : ℝ) := by linarith [Nat.cast_nonneg (α := ℝ) d]
  have hB1 : (1 : ℝ) ≤ (B + 1 : ℝ) := by linarith [Nat.cast_nonneg (α := ℝ) B]
  have hL1 : (1 : ℝ) ≤ (L + 1 : ℝ) := by linarith [Nat.cast_nonneg (α := ℝ) L]
  have hpf : (d + 1 : ℝ) ^ df * (B + 1 : ℝ) ^ df * (L + 1 : ℝ) ^ df ≤
      (d + 1 : ℝ) ^ (max df dg) * (B + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg) :=
    mul_le_mul
      (mul_le_mul (pow_le_pow_right₀ hd1 (le_max_left _ _))
        (pow_le_pow_right₀ hB1 (le_max_left _ _)) (by positivity) (by positivity))
      (pow_le_pow_right₀ hL1 (le_max_left _ _)) (by positivity) (by positivity)
  have hpg : (d + 1 : ℝ) ^ dg * (B + 1 : ℝ) ^ dg * (L + 1 : ℝ) ^ dg ≤
      (d + 1 : ℝ) ^ (max df dg) * (B + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg) :=
    mul_le_mul
      (mul_le_mul (pow_le_pow_right₀ hd1 (le_max_right _ _))
        (pow_le_pow_right₀ hB1 (le_max_right _ _)) (by positivity) (by positivity))
      (pow_le_pow_right₀ hL1 (le_max_right _ _)) (by positivity) (by positivity)
  calc
    f d B L + g d B L
        ≤ Cf * ((d + 1 : ℝ) ^ df * (B + 1 : ℝ) ^ df * (L + 1 : ℝ) ^ df) +
          Cg * ((d + 1 : ℝ) ^ dg * (B + 1 : ℝ) ^ dg * (L + 1 : ℝ) ^ dg) := by
          linarith [hfb d B L, hgb d B L]
    _ ≤ Cf * ((d + 1 : ℝ) ^ (max df dg) * (B + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg)) +
          Cg * ((d + 1 : ℝ) ^ (max df dg) * (B + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg)) :=
          add_le_add (mul_le_mul_of_nonneg_left hpf hCf) (mul_le_mul_of_nonneg_left hpg hCg)
    _ = (Cf + Cg) * (d + 1 : ℝ) ^ (max df dg) * (B + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg) := by
          ring

theorem isBoundedByPoly3_mul {f g : ℕ → ℕ → ℕ → ℝ}
    (hf : UL.IsBoundedByPoly3 f) (hf_nn : ∀ d B L, 0 ≤ f d B L)
    (hg : UL.IsBoundedByPoly3 g) (hg_nn : ∀ d B L, 0 ≤ g d B L) :
    UL.IsBoundedByPoly3 (fun d B L => f d B L * g d B L) := by
  rcases hf with ⟨Cf, df, hCf, hfb⟩
  rcases hg with ⟨Cg, dg, hCg, hgb⟩
  refine ⟨Cf * Cg, df + dg, mul_nonneg hCf hCg, fun d B L => ?_⟩
  have h1 := mul_le_mul (hfb d B L) (hgb d B L) (hg_nn d B L) (by positivity)
  refine h1.trans (le_of_eq ?_)
  simp only [pow_add]
  ring

theorem isBoundedByPoly3_const {c : ℝ} (hc : 0 ≤ c) :
    UL.IsBoundedByPoly3 (fun _ _ _ => c) :=
  ⟨c, 0, hc, fun _ _ _ => by simp⟩

theorem isPolyDBLogNBounded_c3_P_out
    {P_fac netLogBound : ℕ → ℕ → ℕ → ℝ}
    {B_birth : ℕ → ℕ → ℝ}
    {Q_poly : ℕ → ℕ → ℕ → ℝ}
    (hP_fac : UL.IsPolyDBLogNBounded P_fac)
    (hNet : UL.IsPolyDBLogNBounded netLogBound)
    (hBirth : UL.IsPolyDLogNBounded B_birth)
    (hQuery : UL.IsPolyDBLogNBounded Q_poly) :
    UL.IsPolyDBLogNBounded (c3_P_out P_fac netLogBound B_birth Q_poly) := by
  rcases hP_fac with ⟨FP, hFP_poly, hFP_le⟩
  rcases hNet with ⟨FN, hFN_poly, hFN_le⟩
  rcases hBirth with ⟨FB, hFB_poly, hFB_le⟩
  rcases hQuery with ⟨FQ, hFQ_poly, hFQ_le⟩
  -- Lift non-negative majorants `max 0 (F ...)` or note `0 ≤ P_fac ≤ FP` => `0 ≤ FP` on `L = clog`!
  -- Even cleaner: directly construct `(C, deg)` from `(hFP_poly, hFN_poly, hFB_poly, hFQ_poly)`!
  rcases hFP_poly with ⟨CP, dP, hCP, hCP_b⟩
  rcases hFN_poly with ⟨CN, dN, hCN, hCN_b⟩
  rcases hFB_poly with ⟨CB, dB, hCB, hCB_b⟩
  rcases hFQ_poly with ⟨CQ, dQ, hCQ, hCQ_b⟩
  let fB : ℕ → ℕ → ℕ → ℝ := fun d B L => 6 * CB * (d + 1 : ℝ) ^ dB * (B + 1 : ℝ) ^ dB * (L + 1 : ℝ) ^ dB
  let fQ : ℕ → ℕ → ℕ → ℝ := fun d B L => 4 * CQ * (d + 1 : ℝ) ^ dQ * (B + 1 : ℝ) ^ dQ * (L + 1 : ℝ) ^ dQ
  let fR : ℕ → ℕ → ℕ → ℝ := fun d B L => CN * (d + 1 : ℝ) ^ dN * (B + 1 : ℝ) ^ dN * (L + 1 : ℝ) ^ dN + 3
  let fP : ℕ → ℕ → ℕ → ℝ := fun d B L => CP * (d + 1 : ℝ) ^ dP * (B + 1 : ℝ) ^ dP * (L + 1 : ℝ) ^ dP
  have hfB_poly : UL.IsBoundedByPoly3 fB := ⟨6 * CB, dB, by positivity, fun _ _ _ => le_rfl⟩
  have hfQ_poly : UL.IsBoundedByPoly3 fQ := ⟨4 * CQ, dQ, by positivity, fun _ _ _ => le_rfl⟩
  have hfR_poly : UL.IsBoundedByPoly3 fR :=
    isBoundedByPoly3_add ⟨CN, dN, hCN, fun _ _ _ => le_rfl⟩ (isBoundedByPoly3_const (by norm_num))
  have hfP_poly : UL.IsBoundedByPoly3 fP := ⟨CP, dP, hCP, fun _ _ _ => le_rfl⟩
  let F_out : ℕ → ℕ → ℕ → ℝ := fun d B L => (fB d B L + fQ d B L) * fR d B L * fP d B L
  have hF_out_poly : UL.IsBoundedByPoly3 F_out :=
    isBoundedByPoly3_mul
      (isBoundedByPoly3_mul (isBoundedByPoly3_add hfB_poly hfQ_poly)
        (fun d B L => by dsimp only [fB, fQ]; positivity)
        hfR_poly
        (fun d B L => by dsimp only [fR]; positivity))
      (fun d B L => by dsimp only [fB, fQ, fR]; positivity)
      hfP_poly
      (fun d B L => by dsimp only [fP]; positivity)
  refine ⟨F_out, hF_out_poly, fun d B n => ?_⟩
  let L := Nat.clog 2 (2 * n)
  obtain ⟨hP0, hP1⟩ := hFP_le d B n
  obtain ⟨hN0, hN1⟩ := hFN_le d B n
  obtain ⟨hB0, hB1⟩ := hFB_le d n
  obtain ⟨hQ0, hQ1⟩ := hFQ_le d B n
  have hB_le_fB : 6 * B_birth d n ≤ fB d B L := by
    have h1B : (1 : ℝ) ≤ (B + 1 : ℝ) ^ dB := one_le_pow₀ (by linarith [Nat.zero_le B])
    have h2 : B_birth d n ≤ CB * (d + 1 : ℝ) ^ dB * (L + 1 : ℝ) ^ dB :=
      hB1.trans (hCB_b d L)
    calc
      6 * B_birth d n ≤ 6 * (CB * (d + 1 : ℝ) ^ dB * (L + 1 : ℝ) ^ dB) := by linarith
      _ = (6 * CB * (d + 1 : ℝ) ^ dB * (L + 1 : ℝ) ^ dB) * 1 := by ring
      _ ≤ (6 * CB * (d + 1 : ℝ) ^ dB * (L + 1 : ℝ) ^ dB) * (B + 1 : ℝ) ^ dB :=
            mul_le_mul_of_nonneg_left h1B (by positivity)
      _ = fB d B L := by dsimp only [fB]; ring
  have hQ_le_fQ : 4 * Q_poly d B n ≤ fQ d B L := by
    have h2 : Q_poly d B n ≤ CQ * (d + 1 : ℝ) ^ dQ * (B + 1 : ℝ) ^ dQ * (L + 1 : ℝ) ^ dQ :=
      hQ1.trans (hCQ_b d B L)
    dsimp only [fQ]
    linarith
  have hR_le_fR : (c3_R_of (netLogBound d B n) : ℝ) ≤ fR d B L := by
    have hceil : (Nat.ceil (netLogBound d B n) : ℝ) < netLogBound d B n + 1 :=
      Nat.ceil_lt_add_one hN0
    have hR_val : (c3_R_of (netLogBound d B n) : ℝ) = (Nat.ceil (netLogBound d B n) : ℝ) + 2 := by
      unfold c3_R_of
      push_cast
      ring
    have h2 : netLogBound d B n ≤ CN * (d + 1 : ℝ) ^ dN * (B + 1 : ℝ) ^ dN * (L + 1 : ℝ) ^ dN :=
      hN1.trans (hCN_b d B L)
    dsimp only [fR]
    linarith
  have hP_le_fP : P_fac d B n ≤ fP d B L := hP1.trans (hCP_b d B L)
  refine ⟨by unfold c3_P_out; positivity, ?_⟩
  unfold c3_P_out F_out
  have hsum_le : 6 * B_birth d n + 4 * Q_poly d B n ≤ fB d B L + fQ d B L := by linarith
  have hm1 : (6 * B_birth d n + 4 * Q_poly d B n) * (c3_R_of (netLogBound d B n) : ℝ) ≤
      (fB d B L + fQ d B L) * fR d B L :=
    mul_le_mul hsum_le hR_le_fR (by positivity) (by dsimp only [fB, fQ]; positivity)
  exact mul_le_mul hm1 hP_le_fP hP0 (by dsimp only [fB, fQ, fR]; positivity)

end UL.Proof.lem_C_3.RacerCG

namespace UL

open UL.Proof.lem_C_3.RacerCG

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_C_3 (h_clm_5_4_queries_and_caps : S_clm_5_4_queries_and_caps) (h_claim_C_3_sync_suffix : S_claim_C_3_sync_suffix) : S_lem_C_3 := by
  have _ := h_clm_5_4_queries_and_caps
  have _ := h_claim_C_3_sync_suffix
  unfold S_lem_C_3
  intro P_fac netLogBound B_birth Q_poly hP_fac hNet hBirth hQuery
  refine ⟨c3_R_of, c3_cap_of, c3_P_out P_fac netLogBound B_birth Q_poly,
    fun nb _ => one_le_c3_R_of nb,
    isPolyDBLogNBounded_c3_P_out hP_fac hNet hBirth hQuery, ?_⟩
  intro d d_s B n ι _ BirthState PhaseState σ A_n ctrl _hd _hB _hn _hσ hA R cap hValid
  rcases hValid with ⟨netOfBirth, hCtrl⟩
  have hP_nn : 0 ≤ P_fac d B n := by
    rcases hP_fac with ⟨_, _, h⟩
    exact (h d B n).1
  have hB_nn : 0 ≤ B_birth d n := by
    rcases hBirth with ⟨_, _, h⟩
    exact (h d n).1
  have hQ_nn : 0 ≤ Q_poly d B n := by
    rcases hQuery with ⟨_, _, h⟩
    exact (h d B n).1
  refine ⟨?_, ?_⟩
  · intro bitTrace prefSt hpref
    obtain ⟨_, hval_pref⟩ := runCompiledSearchSteps_valid hA hP_nn hB_nn hQ_nn hCtrl bitTrace prefSt hpref
    have hstep := runSingleCompiledSearchStep_props hA hP_nn hB_nn hQ_nn hCtrl ⟨bitTrace, hpref⟩ hval_pref
    exact ⟨fun bs₁ bs₂ out₁ out₂ h1 h2 hp => hstep.1 bs₁ bs₂ out₁ out₂ h1 h2 hp, hstep.2.1⟩
  · intro t _ht
    exact compiledPrefix_props hA hP_nn hB_nn hQ_nn hCtrl t

end UL
