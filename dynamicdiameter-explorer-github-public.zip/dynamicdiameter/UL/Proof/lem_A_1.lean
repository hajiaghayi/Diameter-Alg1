import UL.Stmt.lem_A_1
import UL.Stmt.cit_centerpoint_thm
import UL.Stmt.cit_hw87_halfspace_net
import UL.Stmt.cit_vc71_halfspace_uc
import UL.Stmt.cit_gls88_rational_lp
import UL.Proof.lem_A_1.H1_Params
import UL.Proof.lem_A_1.H2_GeomProb
import UL.Proof.lem_A_1.H3b_Stage
import UL.Proof.lem_A_1.H3c_Center
set_option autoImplicit false

namespace UL

open UL.Proof_lem_A_1

private noncomputable def algConst (K C_LP deg_LP : ℕ) : ℝ :=
  1000 * (9000000 * (K : ℝ) ^ 7 + ((C_LP : ℝ) + 1) * (70000 * (K : ℝ) ^ 5) ^ deg_LP) ^ 3

private def algDeg (deg_LP : ℕ) : ℕ :=
  3 * (15 + 10 * deg_LP)

private theorem algConst_pos {K : ℕ} (hK : 1 ≤ K) (C_LP deg_LP : ℕ) :
    0 < algConst K C_LP deg_LP := by
  unfold algConst
  have hK0 : (0 : ℝ) < (K : ℝ) := by exact_mod_cast hK
  positivity

private theorem wCube_le_polyBound {K C_LP deg_LP D B k s r M boundLP W : ℕ} {φ : ℝ}
    (hK : 1 ≤ K) (hD : 1 ≤ D) (hB : 1 ≤ B)
    (hlog_pos : 0 < Real.log (1 / φ))
    (hk_up : (k : ℝ) + 1 ≤ 2 * (Real.log (1 / φ) + 1))
    (hs_eq : s = sVal K D k)
    (hr_eq : r = rVal K D k)
    (hM_eq : M = mVal K D k)
    (hbLP_eq : boundLP = C_LP * (D + r + s + B + 1) ^ deg_LP)
    (hW_eq : W = M * D + B + boundLP + 2 * D + 10) :
    M ≤ 1000 * (W + 5) ^ 3 ∧
    300 * (M + B + 10) ^ 2 ≤ 1000 * (W + 5) ^ 3 ∧
    ((1000 * (W + 5) ^ 3 : ℕ) : ℝ) ≤
      algConst K C_LP deg_LP * ((D : ℝ) + 1) ^ (algDeg deg_LP) *
        ((B : ℝ) + 1) ^ (algDeg deg_LP) * (Real.log (1 / φ) + 1) ^ (algDeg deg_LP) := by
  have hMD : M ≤ M * D := Nat.le_mul_of_pos_right M hD
  have hMW : M + B + 10 ≤ W + 5 := by omega
  have hW1 : 1 ≤ W + 5 := by omega
  have hW_cu : W + 5 ≤ (W + 5) ^ 3 := by
    have h2 : W + 5 ≤ (W + 5) ^ 2 := Nat.le_self_pow (by omega) _
    calc
      W + 5 ≤ (W + 5) ^ 2 := h2
      _ = (W + 5) ^ 2 * 1 := (Nat.mul_one _).symm
      _ ≤ (W + 5) ^ 2 * (W + 5) := Nat.mul_le_mul_left _ hW1
      _ = (W + 5) ^ 3 := by ring
  have hM_nat : M ≤ 1000 * (W + 5) ^ 3 := by omega
  have h300_nat : 300 * (M + B + 10) ^ 2 ≤ 1000 * (W + 5) ^ 3 := by
    have hsq : (M + B + 10) ^ 2 ≤ (W + 5) ^ 2 := Nat.pow_le_pow_left hMW 2
    have hcu : (W + 5) ^ 2 ≤ (W + 5) ^ 3 := by
      calc
        (W + 5) ^ 2 = (W + 5) ^ 2 * 1 := (Nat.mul_one _).symm
        _ ≤ (W + 5) ^ 2 * (W + 5) := Nat.mul_le_mul_left _ hW1
        _ = (W + 5) ^ 3 := by ring
    omega
  refine ⟨hM_nat, h300_nat, ?_⟩
  generalize hX_eq : ((D : ℝ) + 1) * ((B : ℝ) + 1) * (Real.log (1 / φ) + 1) = X
  have hX_def : X = ((D : ℝ) + 1) * ((B : ℝ) + 1) * (Real.log (1 / φ) + 1) := hX_eq.symm
  have hD1 : (1 : ℝ) ≤ (D : ℝ) + 1 := by
    have : (1 : ℝ) ≤ (D : ℝ) := by exact_mod_cast hD
    linarith
  have hB1 : (1 : ℝ) ≤ (B : ℝ) + 1 := by
    have : (1 : ℝ) ≤ (B : ℝ) := by exact_mod_cast hB
    linarith
  have hL1 : (1 : ℝ) ≤ Real.log (1 / φ) + 1 := by linarith
  have hK1 : (1 : ℝ) ≤ (K : ℝ) := by exact_mod_cast hK
  have hX1 : (1 : ℝ) ≤ X := by
    rw [hX_def]
    exact one_le_mul_of_one_le_of_one_le (one_le_mul_of_one_le_of_one_le hD1 hB1) hL1
  have hX_nn : (0 : ℝ) ≤ X := by linarith
  have hDX : (D : ℝ) + 1 ≤ X := by
    rw [hX_def]
    exact (le_mul_of_one_le_right (by positivity) hB1).trans
      (le_mul_of_one_le_right (by positivity) hL1)
  have hBX : (B : ℝ) + 1 ≤ X := by
    rw [hX_def]
    have h1 : (B : ℝ) + 1 ≤ ((D : ℝ) + 1) * ((B : ℝ) + 1) :=
      le_mul_of_one_le_left (by positivity) hD1
    exact h1.trans (le_mul_of_one_le_right (by positivity) hL1)
  have hLX : Real.log (1 / φ) + 1 ≤ X := by
    rw [hX_def]
    exact le_mul_of_one_le_left (by positivity) (one_le_mul_of_one_le_of_one_le hD1 hB1)
  have hkX : (k : ℝ) + 1 ≤ 2 * X := by linarith
  -- Bound s <= 128 * K^2 * X^4
  have hs_le : (s : ℝ) ≤ 128 * (K : ℝ) ^ 2 * X ^ 4 := by
    have hs_cast : (s : ℝ) = 64 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3 * ((k : ℝ) + 1) := by
      rw [hs_eq, sVal]; push_cast; ring
    rw [hs_cast]
    have hD3 : ((D : ℝ) + 1) ^ 3 ≤ X ^ 3 := pow_le_pow_left₀ (by positivity) hDX 3
    have h1 : 64 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3 ≤ 64 * (K : ℝ) ^ 2 * X ^ 3 :=
      mul_le_mul_of_nonneg_left hD3 (by positivity)
    have h2 : (64 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3) * ((k : ℝ) + 1) ≤
        (64 * (K : ℝ) ^ 2 * X ^ 3) * (2 * X) :=
      mul_le_mul h1 hkX (by positivity) (by positivity)
    calc
      64 * (K : ℝ) ^ 2 * ((D : ℝ) + 1) ^ 3 * ((k : ℝ) + 1)
          ≤ (64 * (K : ℝ) ^ 2 * X ^ 3) * (2 * X) := h2
      _ = 128 * (K : ℝ) ^ 2 * X ^ 4 := by ring
  -- Bound r <= 65536 * K^5 * X^10
  have hr_le : (r : ℝ) ≤ 65536 * (K : ℝ) ^ 5 * X ^ 10 := by
    have hr_cast : (r : ℝ) = 2 * (K : ℝ) * ((D : ℝ) + 1) * (s : ℝ) ^ 2 * ((k : ℝ) + 1) := by
      rw [hr_eq, rVal, ← hs_eq]; push_cast; ring
    rw [hr_cast]
    have hs2 : (s : ℝ) ^ 2 ≤ (128 * (K : ℝ) ^ 2 * X ^ 4) ^ 2 :=
      pow_le_pow_left₀ (Nat.cast_nonneg s) hs_le 2
    have hp1 : 2 * (K : ℝ) * ((D : ℝ) + 1) ≤ 2 * (K : ℝ) * X :=
      mul_le_mul_of_nonneg_left hDX (by positivity)
    have hp2 : (2 * (K : ℝ) * ((D : ℝ) + 1)) * (s : ℝ) ^ 2 ≤
        (2 * (K : ℝ) * X) * (128 * (K : ℝ) ^ 2 * X ^ 4) ^ 2 :=
      mul_le_mul hp1 hs2 (by positivity) (by positivity)
    have hp3 : ((2 * (K : ℝ) * ((D : ℝ) + 1)) * (s : ℝ) ^ 2) * ((k : ℝ) + 1) ≤
        ((2 * (K : ℝ) * X) * (128 * (K : ℝ) ^ 2 * X ^ 4) ^ 2) * (2 * X) :=
      mul_le_mul hp2 hkX (by positivity) (by positivity)
    calc
      2 * (K : ℝ) * ((D : ℝ) + 1) * (s : ℝ) ^ 2 * ((k : ℝ) + 1)
          ≤ ((2 * (K : ℝ) * X) * (128 * (K : ℝ) ^ 2 * X ^ 4) ^ 2) * (2 * X) := hp3
      _ = 65536 * (K : ℝ) ^ 5 * X ^ 10 := by ring
  -- Bound M <= 8388608 * K^7 * X^14
  have hM_le : (M : ℝ) ≤ 8388608 * (K : ℝ) ^ 7 * X ^ 14 := by
    have hM_cast : (M : ℝ) = (r : ℝ) * (s : ℝ) := by
      rw [hM_eq, mVal, ← hr_eq, ← hs_eq]; push_cast; rfl
    rw [hM_cast]
    calc
      (r : ℝ) * (s : ℝ) ≤ (65536 * (K : ℝ) ^ 5 * X ^ 10) * (128 * (K : ℝ) ^ 2 * X ^ 4) :=
        mul_le_mul hr_le hs_le (Nat.cast_nonneg s) (by positivity)
      _ = 8388608 * (K : ℝ) ^ 7 * X ^ 14 := by ring
  -- Bound boundLP
  let dW : ℕ := 15 + 10 * deg_LP
  have hDrsB : ((D + r + s + B + 1 : ℕ) : ℝ) ≤ 70000 * (K : ℝ) ^ 5 * X ^ 10 := by
    push_cast
    have hK5 : (1 : ℝ) ≤ (K : ℝ) ^ 5 := one_le_pow₀ hK1
    have hK25 : (K : ℝ) ^ 2 ≤ (K : ℝ) ^ 5 := pow_le_pow_right₀ hK1 (by omega)
    have hX10 : X ≤ X ^ 10 := le_self_pow₀ hX1 (by omega)
    have hX4_10 : X ^ 4 ≤ X ^ 10 := pow_le_pow_right₀ hX1 (by omega)
    have hs_10 : (s : ℝ) ≤ 128 * (K : ℝ) ^ 5 * X ^ 10 := by
      calc
        (s : ℝ) ≤ 128 * (K : ℝ) ^ 2 * X ^ 4 := hs_le
        _ ≤ 128 * (K : ℝ) ^ 5 * X ^ 4 :=
            mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hK25 (by norm_num)) (by positivity)
        _ ≤ 128 * (K : ℝ) ^ 5 * X ^ 10 :=
            mul_le_mul_of_nonneg_left hX4_10 (by positivity)
    have hDB1 : (D : ℝ) + (B : ℝ) + 1 ≤ 2 * (K : ℝ) ^ 5 * X ^ 10 := by
      have h1 : (D : ℝ) + (B : ℝ) + 1 ≤ 2 * X := by linarith
      have h2 : 2 * X ≤ 2 * X ^ 10 := mul_le_mul_of_nonneg_left hX10 (by norm_num)
      have h3 : 2 * X ^ 10 ≤ 2 * (K : ℝ) ^ 5 * X ^ 10 := by
        have : (1 : ℝ) * (2 * X ^ 10) ≤ (K : ℝ) ^ 5 * (2 * X ^ 10) :=
          mul_le_mul_of_nonneg_right hK5 (by positivity)
        linarith
      linarith
    linarith
  have hbLP_le : (boundLP : ℝ) ≤
      ((C_LP : ℝ) + 1) * (70000 * (K : ℝ) ^ 5) ^ deg_LP * X ^ dW := by
    have hb_cast : (boundLP : ℝ) = (C_LP : ℝ) * ((D + r + s + B + 1 : ℕ) : ℝ) ^ deg_LP := by
      rw [hbLP_eq]; push_cast; rfl
    rw [hb_cast]
    have hpow1 : ((D + r + s + B + 1 : ℕ) : ℝ) ^ deg_LP ≤
        (70000 * (K : ℝ) ^ 5 * X ^ 10) ^ deg_LP :=
      pow_le_pow_left₀ (Nat.cast_nonneg _) hDrsB deg_LP
    have hpow_eq : (70000 * (K : ℝ) ^ 5 * X ^ 10) ^ deg_LP =
        (70000 * (K : ℝ) ^ 5) ^ deg_LP * X ^ (10 * deg_LP) := by
      rw [mul_pow, ← pow_mul]
    rw [hpow_eq] at hpow1
    have hX_dW : X ^ (10 * deg_LP) ≤ X ^ dW := pow_le_pow_right₀ hX1 (by dsimp [dW]; omega)
    have hC_le : (C_LP : ℝ) ≤ (C_LP : ℝ) + 1 := by linarith
    calc
      (C_LP : ℝ) * ((D + r + s + B + 1 : ℕ) : ℝ) ^ deg_LP
          ≤ ((C_LP : ℝ) + 1) * ((70000 * (K : ℝ) ^ 5) ^ deg_LP * X ^ (10 * deg_LP)) :=
            mul_le_mul hC_le hpow1 (by positivity) (by positivity)
      _ ≤ ((C_LP : ℝ) + 1) * ((70000 * (K : ℝ) ^ 5) ^ deg_LP * X ^ dW) :=
            mul_le_mul_of_nonneg_left
              (mul_le_mul_of_nonneg_left hX_dW (by positivity)) (by positivity)
      _ = ((C_LP : ℝ) + 1) * (70000 * (K : ℝ) ^ 5) ^ deg_LP * X ^ dW := by ring
  -- Bound W + 5
  generalize hCW_eq :
    9000000 * (K : ℝ) ^ 7 + ((C_LP : ℝ) + 1) * (70000 * (K : ℝ) ^ 5) ^ deg_LP = CW
  have hCW_nn : 0 ≤ CW := by rw [← hCW_eq]; positivity
  have hW5_le : ((W + 5 : ℕ) : ℝ) ≤ CW * X ^ dW := by
    have hW_cast : ((W + 5 : ℕ) : ℝ) = (M : ℝ) * (D : ℝ) + (B : ℝ) + (boundLP : ℝ) + 2 * (D : ℝ) + 15 := by
      rw [hW_eq]; push_cast; ring
    rw [hW_cast]
    have hD_le_X : (D : ℝ) ≤ X := by linarith
    have hMD_le : (M : ℝ) * (D : ℝ) ≤ 8388608 * (K : ℝ) ^ 7 * X ^ dW := by
      have h1 : (M : ℝ) * (D : ℝ) ≤ (8388608 * (K : ℝ) ^ 7 * X ^ 14) * X :=
        mul_le_mul hM_le hD_le_X (Nat.cast_nonneg D) (by positivity)
      have h2 : (8388608 * (K : ℝ) ^ 7 * X ^ 14) * X = 8388608 * (K : ℝ) ^ 7 * X ^ 15 := by ring
      have h3 : X ^ 15 ≤ X ^ dW := pow_le_pow_right₀ hX1 (by dsimp [dW]; omega)
      exact (h1.trans_eq h2).trans (mul_le_mul_of_nonneg_left h3 (by positivity))
    have hrem_le : (B : ℝ) + 2 * (D : ℝ) + 15 ≤ 20 * (K : ℝ) ^ 7 * X ^ dW := by
      have h1 : (B : ℝ) + 2 * (D : ℝ) + 15 ≤ 20 * X := by linarith
      have hXdW : X ≤ X ^ dW := le_self_pow₀ hX1 (by dsimp [dW]; omega)
      have hK7 : (1 : ℝ) ≤ (K : ℝ) ^ 7 := one_le_pow₀ hK1
      have h2 : 20 * X ≤ 20 * X ^ dW := mul_le_mul_of_nonneg_left hXdW (by norm_num)
      have h3 : 20 * X ^ dW ≤ 20 * (K : ℝ) ^ 7 * X ^ dW := by
        have : (1 : ℝ) * (20 * X ^ dW) ≤ (K : ℝ) ^ 7 * (20 * X ^ dW) :=
          mul_le_mul_of_nonneg_right hK7 (by positivity)
        linarith
      linarith
    have hsum : 8388608 * (K : ℝ) ^ 7 * X ^ dW + 20 * (K : ℝ) ^ 7 * X ^ dW +
        ((C_LP : ℝ) + 1) * (70000 * (K : ℝ) ^ 5) ^ deg_LP * X ^ dW ≤ CW * X ^ dW := by
      rw [← hCW_eq]
      have hc_le : (8388628 : ℝ) ≤ 9000000 := by norm_num
      have hmul1 : 8388628 * ((K : ℝ) ^ 7 * X ^ dW) ≤ 9000000 * ((K : ℝ) ^ 7 * X ^ dW) :=
        mul_le_mul_of_nonneg_right hc_le (by positivity)
      linarith
    linarith
  -- Cube and finish
  have hcube : ((1000 * (W + 5) ^ 3 : ℕ) : ℝ) ≤ 1000 * (CW * X ^ dW) ^ 3 := by
    rw [Nat.cast_mul, Nat.cast_pow, Nat.cast_ofNat]
    exact mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (Nat.cast_nonneg (W + 5)) hW5_le 3) (by norm_num)
  have hrhs_eq :
      1000 * (CW * X ^ dW) ^ 3 =
        algConst K C_LP deg_LP * ((D : ℝ) + 1) ^ (algDeg deg_LP) *
          ((B : ℝ) + 1) ^ (algDeg deg_LP) * (Real.log (1 / φ) + 1) ^ (algDeg deg_LP) := by
    have halgC : 1000 * CW ^ 3 = algConst K C_LP deg_LP := by
      unfold algConst; rw [hCW_eq]
    have halgD : dW * 3 = algDeg deg_LP := by
      unfold algDeg; dsimp only [dW]; omega
    rw [mul_pow, ← pow_mul, halgD, hX_def, mul_pow, mul_pow]
    calc
      1000 * (CW ^ 3 * (((D : ℝ) + 1) ^ algDeg deg_LP * ((B : ℝ) + 1) ^ algDeg deg_LP *
          (Real.log (1 / φ) + 1) ^ algDeg deg_LP))
          = (1000 * CW ^ 3) * ((D : ℝ) + 1) ^ algDeg deg_LP *
              ((B : ℝ) + 1) ^ algDeg deg_LP * (Real.log (1 / φ) + 1) ^ algDeg deg_LP := by
            ring
      _ = algConst K C_LP deg_LP * ((D : ℝ) + 1) ^ algDeg deg_LP *
            ((B : ℝ) + 1) ^ algDeg deg_LP * (Real.log (1 / φ) + 1) ^ algDeg deg_LP := by
            rw [halgC]
  exact hcube.trans_eq hrhs_eq

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_A_1 (h_cit_centerpoint_thm : S_cit_centerpoint_thm) (h_cit_hw87_halfspace_net : S_cit_hw87_halfspace_net) (h_cit_vc71_halfspace_uc : S_cit_vc71_halfspace_uc) (h_cit_gls88_rational_lp : S_cit_gls88_rational_lp) : S_lem_A_1 := by
  classical
  unfold S_lem_A_1
  rcases h_cit_hw87_halfspace_net with ⟨C_HW, hCHW0, h_hw⟩
  rcases h_cit_vc71_halfspace_uc with ⟨C₀, hC0_pos, h_vc⟩
  rcases h_cit_gls88_rational_lp.2.1 with ⟨progHull, C_LP, deg_LP, h_hull⟩
  let K : ℕ := max 1 (max (Nat.ceil C_HW) (Nat.ceil C₀))
  have hK : 1 ≤ K := le_max_left _ _
  have hCHW_K : C_HW ≤ (K : ℝ) := by
    have h1 : Nat.ceil C_HW ≤ K := (le_max_left _ _).trans (le_max_right _ _)
    exact (Nat.le_ceil C_HW).trans (by exact_mod_cast h1)
  have hC0_K : C₀ ≤ (K : ℝ) := by
    have h1 : Nat.ceil C₀ ≤ K := (le_max_right _ _).trans (le_max_right _ _)
    exact (Nat.le_ceil C₀).trans (by exact_mod_cast h1)
  have hK_pos_real : (0 : ℝ) < (K : ℝ) := by exact_mod_cast hK
  refine ⟨sizeProg K, centerProg K progHull, alphaVal K,
    256 * (K : ℝ) ^ 2, 3, algConst K C_LP deg_LP, algDeg deg_LP,
    by positivity, algConst_pos hK C_LP deg_LP, ?_, ?_⟩
  · intro D hD φ hφ0 hφ1
    exact alphaVal_props hK hD hφ0 hφ1
  · intro D B hD hB φ hφ0 hφ1
    dsimp only
    obtain ⟨hk_pos, hlog_pos, _, hk_up⟩ := ceil_logb_bounds hφ0 hφ1
    generalize hk_eq : Nat.ceil (Real.logb 2 (1 / φ)) = k at hk_pos hk_up ⊢
    let s : ℕ := sVal K D k
    let r : ℕ := rVal K D k
    let M : ℕ := mVal K D k
    let boundLP : ℕ := C_LP * (D + r + s + B + 1) ^ deg_LP
    let W : ℕ := M * D + B + boundLP + 2 * D + 10
    obtain ⟨hM_le_W3, h300_le_W3, hW3_le_poly⟩ :=
      wCube_le_polyBound hK hD hB hlog_pos hk_up
        (s := s) (r := r) (M := M) (boundLP := boundLP) (W := W) rfl rfl rfl rfl rfl
    have hM_le_poly : (M : ℝ) ≤
        algConst K C_LP deg_LP * ((D : ℝ) + 1) ^ (algDeg deg_LP) *
          ((B : ℝ) + 1) ^ (algDeg deg_LP) * (Real.log (1 / φ) + 1) ^ (algDeg deg_LP) :=
      (by exact_mod_cast hM_le_W3 : (M : ℝ) ≤ ((1000 * (W + 5) ^ 3 : ℕ) : ℝ)).trans hW3_le_poly
    have h300_le_poly : ((300 * (M + B + 10) ^ 2 : ℕ) : ℝ) ≤
        algConst K C_LP deg_LP * ((D : ℝ) + 1) ^ (algDeg deg_LP) *
          ((B : ℝ) + 1) ^ (algDeg deg_LP) * (Real.log (1 / φ) + 1) ^ (algDeg deg_LP) :=
      (by exact_mod_cast h300_le_W3 : ((300 * (M + B + 10) ^ 2 : ℕ) : ℝ) ≤ _).trans hW3_le_poly
    obtain ⟨sizeOut, hsizeRun, hsizeRead, hsizeU, hsizeB, hsizePC, hsizePB⟩ :=
      sizeProg_spec (D := D) (B := B) (k := k) hK
    have h300_pos : 300 ≤ 300 * (M + B + 10) ^ 2 :=
      Nat.le_mul_of_pos_right 300 (Nat.one_le_pow 2 _ (by omega))
    refine ⟨M, sizeOut, hsizeRun, hsizeRead, mVal_pos hK, hM_le_poly,
      (by exact_mod_cast (hsizeU.trans h300_pos) : (sizeOut.unitCost : ℝ) ≤ _).trans h300_le_poly,
      (by exact_mod_cast hsizeB : (sizeOut.bitCost : ℝ) ≤ _).trans h300_le_poly,
      (by exact_mod_cast (hsizePC.trans h300_pos) : (sizeOut.peakCellSpace : ℝ) ≤ _).trans h300_le_poly,
      (by exact_mod_cast hsizePB : (sizeOut.peakBitSpace : ℝ) ≤ _).trans h300_le_poly,
      ?_⟩
    intro ι _ _ P hP
    let sampleInp : (Fin M → ι) → BitRAMInput D := fun ω =>
      { intParams := [(B : ℤ), (k : ℤ), (M : ℤ)]
        activeHandles := Finset.range M
        activeRatCoords := fun j => if hj : j < M then P (ω ⟨j, hj⟩) else fun _ => 0
        extraRats := [] }
    have hrsM : r * s = M := rfl
    have hspec_all : ∀ ω : Fin M → ι,
        ∃ (out : BitRAMExecOutcome) (zRat : Fin D → ℚ),
          runBitRAMWithBits (centerProg K progHull) (sampleInp ω) WordStore.empty [] = some out ∧
          out.unitCost ≤ 1000 * (W + 5) ^ 3 ∧
          out.bitCost ≤ 1000 * (W + 5) ^ 3 ∧
          out.peakCellSpace ≤ 1000 * (W + 5) ^ 3 ∧
          out.peakBitSpace ≤ 1000 * (W + 5) ^ 3 ∧
          (∀ c : Fin D,
            let zNum := out.words.read (.heap 1 (2 * (c.val : ℤ)))
            let zDen := out.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
            0 < zDen ∧
            zRat c = (zNum : ℚ) / (zDen : ℚ) ∧
            intBitLength zNum ≤ 1000 * (W + 5) ^ 3 ∧
            intBitLength zDen ≤ 1000 * (W + 5) ^ 3 ∧
            ratBitLength (zRat c) ≤ 1000 * (W + 5) ^ 3) ∧
          (∑ c : Fin D, ratBitLength (zRat c)) ≤ 1000 * (W + 5) ^ 3 ∧
          ((∃ z : EuclideanSpace ℝ (Fin D),
              ∀ i : Fin r,
                HasConvexHullCert
                  (fun j : Fin s => ratPointToEuclidean (P (ω (blockIdx i j)))) z) →
            ∀ i : Fin r,
              HasConvexHullCert
                (fun j : Fin s => ratPointToEuclidean (P (ω (blockIdx i j))))
                (ratPointToEuclidean zRat)) := by
      intro ω
      let pts : Fin r → Fin s → Fin D → ℚ := fun i j => P (ω (blockIdx i j))
      obtain ⟨outHull, hHullRun, huH, hbH, hpcH, hpbH, hfl01, hfl_iff, hfl_sol⟩ :=
        h_hull D r s B pts (fun i j => hP _)
      exact centerProg_spec hK hD hB rfl rfl rfl (W := W) le_rfl
        P hP ω (sampleInp ω) rfl rfl rfl rfl progHull outHull hrsM
        hHullRun huH hbH hpcH hpbH hfl01 hfl_iff
        (fun h1 => by
          obtain ⟨_, hz_coords, _, hz_certs⟩ := hfl_sol h1
          exact ⟨hz_coords, fun i => ⟨_, hz_certs i⟩⟩)
    constructor
    · intro ω
      obtain ⟨out, zRat, hrun, hu, hb, hpc, hpb, hcoords, hsum, _⟩ := hspec_all ω
      refine ⟨out, zRat, hrun,
        (by exact_mod_cast hu : (out.unitCost : ℝ) ≤ _).trans hW3_le_poly,
        (by exact_mod_cast hb : (out.bitCost : ℝ) ≤ _).trans hW3_le_poly,
        (by exact_mod_cast hpc : (out.peakCellSpace : ℝ) ≤ _).trans hW3_le_poly,
        (by exact_mod_cast hpb : (out.peakBitSpace : ℝ) ≤ _).trans hW3_le_poly,
        fun c => ?_,
        (by exact_mod_cast hsum : ((∑ c : Fin D, ratBitLength (zRat c)) : ℝ) ≤ _).trans hW3_le_poly⟩
      obtain ⟨hden0, hz_eq, hbn, hbd, hbr⟩ := hcoords c
      exact ⟨hden0, hz_eq,
        (by exact_mod_cast hbn : (intBitLength _ : ℝ) ≤ _).trans hW3_le_poly,
        (by exact_mod_cast hbd : (intBitLength _ : ℝ) ≤ _).trans hW3_le_poly,
        (by exact_mod_cast hbr : (ratBitLength _ : ℝ) ≤ _).trans hW3_le_poly⟩
    · -- Probability bound >= 1 - φ
      let Q : ι → EuclideanSpace ℝ (Fin D) := fun i => ratPointToEuclidean (P i)
      have hprob := goodCenterSample_prob_ge h_cit_centerpoint_thm hCHW0 h_hw h_vc
        hK hCHW_K hC0_K hD hφ0 hφ1 Q
      dsimp only at hprob
      rw [hk_eq] at hprob
      have hα_eq : alphaVal K D φ = 1 / (2 * (s : ℝ)) := by
        unfold alphaVal
        rw [hk_eq]
      have hsub :
          Finset.univ.filter (fun ω : Fin M → ι => IsGoodCenterSample Q ω) ⊆
          Finset.univ.filter (fun ω : Fin M → ι =>
            ∃ (out : BitRAMExecOutcome) (zRat : Fin D → ℚ),
              runBitRAMWithBits (centerProg K progHull) (sampleInp ω) WordStore.empty [] = some out ∧
              (∀ c : Fin D,
                let zNum := out.words.read (.heap 1 (2 * (c.val : ℤ)))
                let zDen := out.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
                0 < zDen ∧ zRat c = (zNum : ℚ) / (zDen : ℚ)) ∧
              IsCenterpoint (alphaVal K D φ) Q (ratPointToEuclidean zRat)) := by
        intro ω hω
        obtain ⟨hex_z, hall_cp⟩ := (Finset.mem_filter.mp hω).2
        obtain ⟨out, zRat, hrun, _, _, _, _, hcoords, _, himp_cert⟩ := hspec_all ω
        refine Finset.mem_filter.mpr ⟨Finset.mem_univ ω, ⟨out, zRat, hrun, ?_, ?_⟩⟩
        · intro c
          exact ⟨(hcoords c).1, (hcoords c).2.1⟩
        · rw [hα_eq]
          exact hall_cp (ratPointToEuclidean zRat) (himp_cert hex_z)
      have hcard_le :
          ((Finset.univ.filter (fun ω : Fin M → ι => IsGoodCenterSample Q ω)).card : ℝ) ≤
          ((Finset.univ.filter (fun ω : Fin M → ι =>
            ∃ (out : BitRAMExecOutcome) (zRat : Fin D → ℚ),
              runBitRAMWithBits (centerProg K progHull) (sampleInp ω) WordStore.empty [] = some out ∧
              (∀ c : Fin D,
                let zNum := out.words.read (.heap 1 (2 * (c.val : ℤ)))
                let zDen := out.words.read (.heap 1 (2 * (c.val : ℤ) + 1))
                0 < zDen ∧ zRat c = (zNum : ℚ) / (zDen : ℚ)) ∧
              IsCenterpoint (alphaVal K D φ) Q (ratPointToEuclidean zRat))).card : ℝ) := by
        exact_mod_cast Finset.card_le_card hsub
      have hN_nn : (0 : ℝ) ≤ (Fintype.card (Fin M → ι) : ℝ) := Nat.cast_nonneg _
      exact hprob.trans (div_le_div_of_nonneg_right hcard_le hN_nn)

end UL
