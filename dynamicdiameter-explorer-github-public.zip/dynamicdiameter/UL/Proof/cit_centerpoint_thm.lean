import UL.Stmt.cit_centerpoint_thm
set_option autoImplicit false

namespace UL

private theorem convex_compl_of_isClosedHalfspace {D : ℕ}
    {H : Set (EuclideanSpace ℝ (Fin D))} (hH : IsClosedHalfspace H) :
    Convex ℝ Hᶜ := by
  rcases hH with ⟨v, _, β, rfl⟩
  intro x hx y hy a b ha hb hab
  simp only [Set.mem_compl_iff, Set.mem_setOf_eq, not_le] at hx hy ⊢
  rw [inner_add_right, inner_smul_right, inner_smul_right]
  rcases ha.eq_or_lt with rfl | ha_pos
  · simp only [zero_add] at hab
    subst hab
    linarith
  · have hax : a * β < a * inner ℝ v x := mul_lt_mul_of_pos_left hx ha_pos
    have hby : b * β ≤ b * inner ℝ v y := mul_le_mul_of_nonneg_left hy.le hb
    have habβ : a * β + b * β = β := by rw [← add_mul, hab, one_mul]
    linarith

private theorem exists_closedHalfspace_mem {D : ℕ} (hD : 1 ≤ D)
    (z : EuclideanSpace ℝ (Fin D)) :
    ∃ H : Set (EuclideanSpace ℝ (Fin D)), IsClosedHalfspace H ∧ z ∈ H := by
  let i₀ : Fin D := ⟨0, by omega⟩
  let v₀ : EuclideanSpace ℝ (Fin D) := EuclideanSpace.single i₀ (1 : ℝ)
  have hv₀ : v₀ ≠ 0 := by simp [v₀]
  exact ⟨{x | inner ℝ v₀ x ≤ inner ℝ v₀ z}, ⟨v₀, hv₀, inner ℝ v₀ z, rfl⟩,
    Set.mem_setOf.mpr le_rfl⟩

private theorem exists_point_forall_halfspace_pointCount_ge
    (D : ℕ) (ι : Type) [Fintype ι] [Nonempty ι]
    (P : ι → EuclideanSpace ℝ (Fin D)) :
    ∃ z_star : EuclideanSpace ℝ (Fin D),
      ∀ H : Set (EuclideanSpace ℝ (Fin D)),
        IsClosedHalfspace H → z_star ∈ H →
        (Fintype.card ι : ℝ) / ((D : ℝ) + 1) ≤ (pointCount P H : ℝ) := by
  classical
  let s : Finset (Finset ι) :=
    Finset.univ.filter (fun Q : Finset ι => (D + 1) * (Finset.univ \ Q).card < Fintype.card ι)
  let F : Finset ι → Set (EuclideanSpace ℝ (Fin D)) :=
    fun Q => convexHull ℝ (P '' (Q : Set ι))
  have h_finrank : Module.finrank ℝ (EuclideanSpace ℝ (Fin D)) = D :=
    finrank_euclideanSpace_fin
  have h_inter : ∀ I ⊆ s, I.card ≤ Module.finrank ℝ (EuclideanSpace ℝ (Fin D)) + 1 →
      (⋂ Q ∈ I, F Q).Nonempty := by
    intro I hI_sub hI_card
    rw [h_finrank] at hI_card
    rcases I.eq_empty_or_nonempty with rfl | hI_ne
    · exact ⟨0, by simp⟩
    · have h_sum_lt :
        ∑ Q ∈ I, (D + 1) * (Finset.univ \ Q).card < ∑ _Q ∈ I, Fintype.card ι := by
        apply Finset.sum_lt_sum_of_nonempty hI_ne
        intro Q hQ
        exact (Finset.mem_filter.mp (hI_sub hQ)).2
      rw [← Finset.mul_sum, Finset.sum_const, smul_eq_mul] at h_sum_lt
      have h_sum_le : I.card * Fintype.card ι ≤ (D + 1) * Fintype.card ι :=
        Nat.mul_le_mul_right (Fintype.card ι) hI_card
      have h_sum_card_lt : ∑ Q ∈ I, (Finset.univ \ Q).card < Fintype.card ι := by
        have h1 : (D + 1) * ∑ Q ∈ I, (Finset.univ \ Q).card < (D + 1) * Fintype.card ι :=
          lt_of_lt_of_le h_sum_lt h_sum_le
        exact Nat.lt_of_mul_lt_mul_left h1
      let U : Finset ι := I.biUnion (fun Q => Finset.univ \ Q)
      have hU_card : U.card < (Finset.univ : Finset ι).card := by
        rw [Finset.card_univ]
        exact lt_of_le_of_lt Finset.card_biUnion_le h_sum_card_lt
      have h_diff_ne : (Finset.univ \ U).Nonempty := by
        rw [Finset.nonempty_iff_ne_empty]
        intro h_emp
        have h_sub : (Finset.univ : Finset ι) ⊆ U := Finset.sdiff_eq_empty_iff_subset.mp h_emp
        exact (not_le_of_gt hU_card) (Finset.card_le_card h_sub)
      obtain ⟨i₀, hi₀⟩ := h_diff_ne
      have hi₀_not_U : i₀ ∉ U := (Finset.mem_sdiff.mp hi₀).2
      refine ⟨P i₀, Set.mem_biInter (fun Q hQ => ?_)⟩
      have hi₀_Q : i₀ ∈ Q := by
        by_contra hi₀_not_Q
        apply hi₀_not_U
        exact Finset.mem_biUnion.mpr ⟨Q, hQ, Finset.mem_sdiff.mpr ⟨Finset.mem_univ i₀, hi₀_not_Q⟩⟩
      exact subset_convexHull ℝ _ ⟨i₀, hi₀_Q, rfl⟩
  obtain ⟨z_star, hz_star⟩ :=
    Convex.helly_theorem' (𝕜 := ℝ) (F := F) (s := s)
      (fun Q _ => convex_convexHull ℝ _) h_inter
  refine ⟨z_star, fun H hH hzH => ?_⟩
  by_contra! h_lt
  have hD1_pos : (0 : ℝ) < (D : ℝ) + 1 := by positivity
  have h_mul_lt_real : ((D : ℝ) + 1) * (pointCount P H : ℝ) < (Fintype.card ι : ℝ) := by
    have := (lt_div_iff₀ hD1_pos).mp h_lt
    linarith
  have h_mul_lt_nat : (D + 1) * pointCount P H < Fintype.card ι := by
    exact_mod_cast h_mul_lt_real
  let Q : Finset ι := Finset.univ.filter (fun i : ι => P i ∉ H)
  have hsdiff_eq : Finset.univ \ Q = Finset.univ.filter (fun i : ι => P i ∈ H) := by
    ext i
    simp [Q]
  have h_card_sdiff : (Finset.univ \ Q).card = pointCount P H := by
    rw [hsdiff_eq]
    unfold pointCount
    congr 1
  have hQ_mem_s : Q ∈ s := by
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ Q, ?_⟩
    rwa [h_card_sdiff]
  simp only [Set.mem_iInter] at hz_star
  have hz_mem_FQ : z_star ∈ F Q := hz_star Q hQ_mem_s
  have hFQ_sub_Hc : F Q ⊆ Hᶜ := by
    refine convexHull_min ?_ (convex_compl_of_isClosedHalfspace hH)
    rintro x ⟨i, hiQ, rfl⟩
    exact (Finset.mem_filter.mp hiQ).2
  exact hFQ_sub_Hc hz_mem_FQ hzH

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_cit_centerpoint_thm : S_cit_centerpoint_thm := by
  unfold S_cit_centerpoint_thm
  intro D hD ι _ _ P
  obtain ⟨z_star, hz_half⟩ := exists_point_forall_halfspace_pointCount_ge D ι P
  obtain ⟨H₀, hH₀_closed, hzH₀⟩ := exists_closedHalfspace_mem hD z_star
  refine ⟨z_star, ?_, ?_⟩
  · let A : Set ℕ := {n : ℕ | ∃ H : Set (EuclideanSpace ℝ (Fin D)),
      IsClosedHalfspace H ∧ z_star ∈ H ∧ n = pointCount P H}
    have hA_ne : A.Nonempty := ⟨pointCount P H₀, H₀, hH₀_closed, hzH₀, rfl⟩
    have hsInf_mem : halfspaceDepth P z_star ∈ A := Nat.sInf_mem hA_ne
    rcases hsInf_mem with ⟨H₁, hH₁_closed, hzH₁, h_eq⟩
    rw [h_eq]
    exact hz_half H₁ hH₁_closed hzH₁
  · intro S hS
    have hH₀_cnt : (1 / ((D : ℝ) + 1)) * (Fintype.card ι : ℝ) ≤ (pointCount P H₀ : ℝ) := by
      rw [one_div_mul_eq_div]
      exact hz_half H₀ hH₀_closed hzH₀
    obtain ⟨i₀, hi₀S, _⟩ := hS H₀ hH₀_closed hH₀_cnt
    let K : Set (EuclideanSpace ℝ (Fin D)) := convexHull ℝ (P '' (S : Set ι))
    change z_star ∈ K
    by_contra hz_not_K
    have hK_conv : Convex ℝ K := convex_convexHull ℝ _
    have hK_closed : IsClosed K := ((S.finite_toSet).image P).isClosed_convexHull
    obtain ⟨f, u, hf_z, hf_K⟩ := geometric_hahn_banach_point_closed hK_conv hK_closed hz_not_K
    have hPi₀_K : P i₀ ∈ K := subset_convexHull ℝ _ ⟨i₀, hi₀S, rfl⟩
    have hf_ne : f ≠ 0 := by
      intro hf0
      rw [hf0] at hf_z hf_K
      have h1 : (0 : ℝ) < u := by simpa using hf_z
      have h2 : u < (0 : ℝ) := by simpa using hf_K (P i₀) hPi₀_K
      linarith
    let v : EuclideanSpace ℝ (Fin D) :=
      (InnerProductSpace.toDual ℝ (EuclideanSpace ℝ (Fin D))).symm f
    have hv_ne : v ≠ 0 := by
      simpa [v] using hf_ne
    let H : Set (EuclideanSpace ℝ (Fin D)) := {x | inner ℝ v x ≤ u}
    have hH_closed : IsClosedHalfspace H := ⟨v, hv_ne, u, rfl⟩
    have hzH : z_star ∈ H := by
      simp only [H, Set.mem_setOf_eq, v, InnerProductSpace.toDual_symm_apply]
      exact hf_z.le
    have hH_cnt : (1 / ((D : ℝ) + 1)) * (Fintype.card ι : ℝ) ≤ (pointCount P H : ℝ) := by
      rw [one_div_mul_eq_div]
      exact hz_half H hH_closed hzH
    obtain ⟨j, hjS, hjH⟩ := hS H hH_closed hH_cnt
    have hPj_le : f (P j) ≤ u := by
      simpa [H, v, InnerProductSpace.toDual_symm_apply] using hjH
    have hPj_gt : u < f (P j) := hf_K (P j) (subset_convexHull ℝ _ ⟨j, hjS, rfl⟩)
    linarith

end UL
