import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.cit_hpj19_thm18
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_mc_baseline
import UL.Stmt.lem_5_5
import UL.Stmt.clm_5_3_global_factor_c
import UL.Stmt.lem_5_6
import UL.Stmt.clm_5_4_queries_and_caps
import UL.Stmt.lem_6_1
import UL.Stmt.lem_6_2
import UL.Stmt.lem_6_3
import UL.Stmt.clm_6_1_adaptive
import UL.Stmt.clm_6_1_precision
import UL.Stmt.lem_7_1
import UL.Stmt.lem_C_2
import UL.Stmt.claim_C_2_space_reclaim
import UL.Stmt.clm_7_2_chain_schedule
import UL.Stmt.clm_7_3_global_approx
import UL.Stmt.clm_7_3_failure_budget
import UL.Stmt.lem_9_1
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Final
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_clm_9_1_explicit_tradeoff (h_cit_hpj19_thm18 : S_cit_hpj19_thm18) (h_lem_5_1 : S_lem_5_1) (h_clm_5_1_mc_baseline : S_clm_5_1_mc_baseline) (h_lem_5_5 : S_lem_5_5) (h_clm_5_3_global_factor_c : S_clm_5_3_global_factor_c) (h_lem_5_6 : S_lem_5_6) (h_clm_5_4_queries_and_caps : S_clm_5_4_queries_and_caps) (h_lem_6_1 : S_lem_6_1) (h_lem_6_2 : S_lem_6_2) (h_lem_6_3 : S_lem_6_3) (h_clm_6_1_adaptive : S_clm_6_1_adaptive) (h_clm_6_1_precision : S_clm_6_1_precision) (h_lem_7_1 : S_lem_7_1) (h_lem_C_2 : S_lem_C_2) (h_claim_C_2_space_reclaim : S_claim_C_2_space_reclaim) (h_clm_7_2_chain_schedule : S_clm_7_2_chain_schedule) (h_clm_7_3_global_approx : S_clm_7_3_global_approx) (h_clm_7_3_failure_budget : S_clm_7_3_failure_budget) (h_lem_9_1 : S_lem_9_1) : S_clm_9_1_explicit_tradeoff := by
  exact UL.Proof.clm_9_1_explicit_tradeoff.CG20.clm_9_1_proved
    h_lem_5_1 h_clm_5_1_mc_baseline h_lem_6_2
    h_clm_6_1_adaptive h_clm_6_1_precision h_clm_7_3_global_approx h_lem_9_1

end UL
