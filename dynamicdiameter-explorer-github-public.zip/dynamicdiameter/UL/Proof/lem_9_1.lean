import UL.Stmt.lem_9_1
import UL.Stmt.clm_5_2_config_gap
import UL.Stmt.lem_5_6
import UL.Stmt.lem_6_1
import UL.Proof.lem_9_1.H1
import UL.Proof.lem_9_1.H2
set_option autoImplicit false

namespace UL

-- [UL:SIGNATURE] fixed by ul.py: keep this header exactly (name, hypotheses, type).
theorem P_lem_9_1 (h_clm_5_2_config_gap : S_clm_5_2_config_gap) (h_lem_5_6 : S_lem_5_6) (h_lem_6_1 : S_lem_6_1) : S_lem_9_1 := by
  let _ := h_lem_6_1
  unfold S_lem_9_1
  intro c hc_gt hc_lt
  let C_shell := Proof_lem_9_1.C_shell_val c
  let C_cfg := Proof_lem_9_1.C_cfg_val c
  let C_h := Proof_lem_9_1.C_h_val
  let C_q := Proof_lem_9_1.C_q_val c C_h
  let h_min := Proof_lem_9_1.h_min_val c
  have hCshell_nn : 0 ≤ C_shell := by dsimp [C_shell, Proof_lem_9_1.C_shell_val]; positivity
  have hCcfg_nn : 0 ≤ C_cfg := by dsimp [C_cfg, Proof_lem_9_1.C_cfg_val]; positivity
  have hCh_nn : 0 ≤ C_h := by dsimp [C_h, Proof_lem_9_1.C_h_val]; norm_num
  have hCq_nn : 0 ≤ C_q := by dsimp [C_q, Proof_lem_9_1.C_q_val]; positivity
  have hhmin_pos : 0 < h_min := by dsimp [h_min, Proof_lem_9_1.h_min_val]; linarith
  have hhmin_le : h_min ≤ g_c c := by
    dsimp [h_min, Proof_lem_9_1.h_min_val, g_c]
    have hmul : (c - 1) * 2 ≤ (c - 1) * (c + 1) :=
      mul_le_mul_of_nonneg_left (by linarith) (by linarith)
    have hexp : (c - 1) * (c + 1) = c ^ 2 - 1 := by ring
    linarith
  refine ⟨C_shell, C_cfg, C_h, C_q, h_min,
    hCshell_nn, hCcfg_nn, hCh_nn, hCq_nn, hhmin_pos, hhmin_le, ?_⟩
  intro n hn L σ hσ_lo hσ_hi
  rcases Proof_lem_9_1.exists_geom_params h_clm_5_2_config_gap h_lem_5_6 c hc_gt hc_lt n hn with
    ⟨params, h, hpc, hm0, hmaxS, hJ1, hallC, hretC, he_g16, hh_eq, hh_min, hh_gc, hgc_sub, hpad⟩
  have hh_pos : 0 < (h : ℝ) := lt_of_lt_of_le hhmin_pos hh_min
  have hL_ge1 : 1 ≤ L := Proof_lem_9_1.one_le_L_n hn
  rcases Proof_lem_9_1.exists_filter_param c hc_gt hc_lt L hL_ge1 C_h hCh_nn
      h hh_pos hh_gc hgc_sub σ hσ_lo hσ_hi with
    ⟨x, hx_lo, hx_hi, hu_le, hq_le⟩
  exact ⟨params, h, x, hpc, hm0, hmaxS, hJ1, hallC, hretC, he_g16, hh_eq, hh_min, hh_gc, hgc_sub,
    hpad, hx_lo, hx_hi, hu_le, hq_le⟩

end UL
