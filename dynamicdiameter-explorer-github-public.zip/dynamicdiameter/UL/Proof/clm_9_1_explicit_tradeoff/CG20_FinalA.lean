import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_CP
import UL.Proof.clm_9_1_explicit_tradeoff.CG15_ParamsB
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Stage4
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG15
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge

/-! ### 1. Generic 4-Stage Composition into `StepChainRAMSpec` -/

/-- Interface packaging deterministic RAM statements and `ExecDet` specs for Stages 1, 2, and 3
over `ops : NodeAndHPJRAMOps cp`, ready to compose with `CG20.stepStage4Stmt ops mops`. -/
structure Stage123RAMBundle {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) where
  s1 : ArithRAMStmt
  s2 : ArithRAMStmt
  s3 : ArithRAMStmt
  C1 : ℕ
  C2 : ℕ
  C3 : ℕ
  hzr1 : ZeroRandStmt s1
  hzr2 : ZeroRandStmt s2
  hzr3 : ZeroRandStmt s3
  exec1 :
    ∀ {P : DynamicPointSet d} {op : DynamicUpdate d}
      {st : ChainEngineState cp} {bits : Fin cp.B_STEP → Bool} {m₀ : ArithRAMMemory},
      P.WellFormed cp.n →
      IsLegalUpdate cp.n Set.univ P op →
      ChainEngineWF cp P st →
      InFootprint ops.TW ops.BW ops.TR ops.BR m₀ →
      EncChainEngine ops st m₀ →
      MemHasStepCoins cp bits m₀ →
      let uop := toInternalUpdate P op
      let inp := mkUpdateInp cp.n P uop
      let ω₁ := (bitsToStepCoinBundle cp bits).1
      let res := stepStage1 cp st uop ω₁
      ExecDet ops.TW ops.BW ops.TR ops.BR inp s1 m₀
        (fun m₁ =>
          EncChainEngine ops res.1 m₁ ∧
          MemHasStepCoins cp bits m₁ ∧
          (∀ h_new, res.2 = some h_new →
            ArithRAMDynamicProgram.readReturnedHandle m₁ = some h_new))
        C1
  exec2 :
    ∀ (inp : ArithRAMInput d) {P' : DynamicPointSet d}
      {st₁ : ChainEngineState cp} {bits : Fin cp.B_STEP → Bool} {m₁ : ArithRAMMemory},
      P'.WellFormed cp.n →
      PostStage1WF cp P' st₁ →
      InFootprint ops.TW ops.BW ops.TR ops.BR m₁ →
      EncChainEngine ops st₁ m₁ →
      MemHasStepCoins cp bits m₁ →
      let ω₂ := (bitsToStepCoinBundle cp bits).2.1
      let st₂ := stepStage2 cp st₁ ω₂
      ExecDet ops.TW ops.BW ops.TR ops.BR inp s2 m₁
        (fun m₂ =>
          EncChainEngine ops st₂ m₂ ∧
          MemHasStepCoins cp bits m₂ ∧
          wRead m₂ 0 0 = wRead m₁ 0 0)
        C2
  exec3 :
    ∀ (inp : ArithRAMInput d) {P' : DynamicPointSet d}
      {st₂ : ChainEngineState cp} {bits : Fin cp.B_STEP → Bool} {m₂ : ArithRAMMemory},
      P'.WellFormed cp.n →
      PostStage2WF cp P' st₂ →
      InFootprint ops.TW ops.BW ops.TR ops.BR m₂ →
      EncChainEngine ops st₂ m₂ →
      MemHasStepCoins cp bits m₂ →
      let st₃ := stepStage3 cp st₂
      ExecDet ops.TW ops.BW ops.TR ops.BR inp s3 m₂
        (fun m₃ =>
          EncChainEngine ops st₃ m₃ ∧
          MemHasStepCoins cp bits m₃ ∧
          wRead m₃ 0 0 = wRead m₂ 0 0)
        C3

theorem readReturnedHandle_eq_of_wRead_0_0 {m₁ m₂ : ArithRAMMemory}
    (h00 : wRead m₂ 0 0 = wRead m₁ 0 0) :
    ArithRAMDynamicProgram.readReturnedHandle m₂ =
      ArithRAMDynamicProgram.readReturnedHandle m₁ := by
  have h : m₂.words.read (.heap 0 0) = m₁.words.read (.heap 0 0) := h00
  unfold ArithRAMDynamicProgram.readReturnedHandle
  rw [h]

/-- Compose Stages 1, 2, 3, and 4 into a complete `StepChainRAMSpec cp` (`initStmt = .skip`,
`initCost = 1`, `detCost = s123.C1 + s123.C2 + s123.C3 + stepStage4Cost ops mops`). -/
def mkStepChainRAMSpec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1) (hh0 : 0 < h) (hh1 : h < 1)
    (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops)
    (s123 : Stage123RAMBundle ops) :
    StepChainRAMSpec cp :=
  StepChainRAMSpec.ofEmptyInit
    ops.TW ops.BW ops.TR ops.BR coinTbl engScrTbl
    (by have := ops.hTW; unfold coinTbl; omega)
    (by have := ops.hTW; unfold engScrTbl; omega)
    (by decide)
    (by have := ops.hBW_coins; omega)
    (by have := ops.hBW_scr; unfold M_slots at this; omega)
    (EncChainEngine ops)
    (encChainEngine_empty ops)
    (fun st m₀ m₁ henc hw hr _ => encChainEngine_frame_coins ops st m₀ m₁ henc hw hr)
    (.seq s123.s1 (.seq s123.s2 (.seq s123.s3 (stepStage4Stmt ops mops))))
    (s123.C1 + s123.C2 + s123.C3 + stepStage4Cost ops mops)
    (.seq s123.hzr1 (.seq s123.hzr2 (.seq s123.hzr3 (zeroRand_stepStage4Stmt ops mops))))
    (by
      intro P op st bits m₀ hP hleg hwf hfp₀ henc₀ hcoins₀
      let uop := toInternalUpdate P op
      let inp := mkUpdateInp cp.n P uop
      let coins := bitsToStepCoinBundle cp bits
      rcases stepStage1_spec h_clm_7_3 hd he1 cp hh0 hh1 hP hleg hwf coins.1
        with ⟨P', happ, hwf₁, _⟩
      have hP' : P'.WellFormed cp.n := applyDynamicUpdate_wellFormed hP hleg happ
      let res1 := stepStage1 cp st uop coins.1
      rcases stepStage2_spec h_lem_5_1 h_clm_7_3 hd he1 cp hh0 hh1 hP' hwf₁ coins.2.1
        with ⟨hwf₂, _⟩
      let st₂ := stepStage2 cp res1.1 coins.2.1
      rcases stepStage3_spec cp hh0 hh1 hwf₂ with ⟨hwf₃, _⟩
      let st₃ := stepStage3 cp st₂
      refine ExecDet.seq' (s123.C2 + s123.C3 + stepStage4Cost ops mops)
        (s123.exec1 hP hleg hwf hfp₀ henc₀ hcoins₀)
        (by omega) ?_
      intro m₁ ⟨henc₁, hcoins₁, hret₁⟩ hfp₁
      refine ExecDet.seq' (s123.C3 + stepStage4Cost ops mops)
        (s123.exec2 inp hP' hwf₁ hfp₁ henc₁ hcoins₁)
        (by omega) ?_
      intro m₂ ⟨henc₂, hcoins₂, hw21⟩ hfp₂
      refine ExecDet.seq' (stepStage4Cost ops mops)
        (s123.exec3 inp hP' hwf₂ hfp₂ henc₂ hcoins₂)
        (by omega) ?_
      intro m₃ ⟨henc₃, hcoins₃, hw32⟩ hfp₃
      refine (exec_stepStage4Stmt ops mops inp bits hwf₃ hfp₃ henc₃ hcoins₃).mono ?_ le_rfl
      intro m₄ ⟨henc₄, hw43, hans₄⟩ _
      have hw41 : wRead m₄ 0 0 = wRead m₁ 0 0 := hw43.trans (hw32.trans hw21)
      have hrh41 := readReturnedHandle_eq_of_wRead_0_0 hw41
      refine ⟨henc₄, fun h_new hrh => ?_, hans₄⟩
      rw [hrh41]
      exact hret₁ h_new hrh)

/-! ### 2. Top-Level Bridge from Uniform Polynomial RAM Builder to `S_clm_9_1_explicit_tradeoff` -/

theorem prove_clm_9_1_from_ram_builder
    (h_lem_5_1 : S_lem_5_1)
    (h_clm_5_1_mc_baseline : S_clm_5_1_mc_baseline)
    (h_lem_6_2 : S_lem_6_2)
    (h_clm_6_1_adaptive : S_clm_6_1_adaptive)
    (h_clm_6_1_precision : S_clm_6_1_precision)
    (h_clm_7_3_global_approx : S_clm_7_3_global_approx)
    (h_lem_9_1 : S_lem_9_1)
    (mkUniformRAM :
      ∀ {c σ : ℝ} (csp : CurveStaticParams c σ),
        ∃ (C₀ k C_sp k_sp : ℕ),
          ∀ (d n t : ℕ) (δ : ℝ)
            (hd : 1 ≤ d) (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2),
            M_cutoff c σ < n → M_cutoff c σ < t →
            let inst := mkConcreteChainInst csp d n t δ hd hn ht hδ0 hδ1
            Nonempty { ram : StepChainRAMSpec inst.cp //
              ram.initCost ≤ 5 + 10 * inst.cp.B_STEP +
                C₀ * (masterPolyParamNat inst) ^ k * masterWorkFactorNat inst.cp ∧
              ram.detCost ≤ C₀ * (masterPolyParamNat inst) ^ k * masterWorkFactorNat inst.cp ∧
              ram.TW * ram.BW + ram.TR * ram.BR ≤
                C_sp * (masterPolyParamNat inst) ^ k_sp * masterSpaceFactorNat inst.cp }) :
    S_clm_9_1_explicit_tradeoff := by
  refine prove_clm_9_1_from_sublinear h_lem_6_2 h_clm_6_1_adaptive h_clm_6_1_precision ?_
  intro c hc_gt hc_lt σ hσ0 hσ_hi
  obtain ⟨csp⟩ := exists_curveStaticParams h_lem_9_1 h_lem_6_2 h_clm_5_1_mc_baseline
    hc_gt hc_lt hσ0 hσ_hi
  obtain ⟨C₀, k, C_sp, k_sp, hRAM⟩ := mkUniformRAM csp
  exact ⟨mkSublinearCurveSpec h_lem_5_1 h_clm_7_3_global_approx csp C₀ k C_sp k_sp
    (fun d n t δ hd hn ht hδ0 hδ1 hMn hMt =>
      Classical.choice (hRAM d n t δ hd hn ht hδ0 hδ1 hMn hMt))⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
