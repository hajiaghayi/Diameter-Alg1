import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Stage1C
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 6. Localized `EncJobSlot` Frame & Per-Slot Stage-1 Statements -/

theorem jobUsedSlots_stage1_eq {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (st : ChainEngineState cp)
    (uop : InternalUpdate d) (ω₁ : Stage1Coins cp)
    (r : Fin cp.D_max) (rSlots : List ℕ) (cSlot : ℕ) :
    jobUsedSlots ((stepStage1 cp st uop ω₁).1.jobs r) rSlots cSlot =
      jobUsedSlots (st.jobs r) rSlots cSlot := by
  unfold stepStage1 jobUsedSlots
  dsimp only
  cases st.jobs r with
  | none => rfl
  | some jb =>
      rcases jb with ⟨ready, cs | bs⟩ <;> dsimp only <;> split_ifs <;> rfl

lemma stride_off_bounds {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r c z : ℕ) (hc_lo : 2 ≤ c) (hc_hi : c ≤ 5) (hz : z < S_stride cp) :
    (((2 + 4 * r) * S_stride cp : ℕ) : ℤ) ≤ (((c + 4 * r) * S_stride cp : ℕ) : ℤ) + (z : ℤ) ∧
    (((c + 4 * r) * S_stride cp : ℕ) : ℤ) + (z : ℤ) < (((6 + 4 * r) * S_stride cp : ℕ) : ℤ) := by
  have h1 : (2 + 4 * r) * S_stride cp ≤ (c + 4 * r) * S_stride cp :=
    Nat.mul_le_mul_right _ (by omega)
  have h2 : (c + 4 * r) * S_stride cp + z < (6 + 4 * r) * S_stride cp :=
    calc (c + 4 * r) * S_stride cp + z
      _ < (c + 4 * r) * S_stride cp + S_stride cp := by omega
      _ = ((c + 1) + 4 * r) * S_stride cp := by ring
      _ ≤ (6 + 4 * r) * S_stride cp := Nat.mul_le_mul_right _ (by omega)
  exact ⟨by exact_mod_cast h1.trans (Nat.le_add_right _ _), by exact_mod_cast h2⟩

theorem encJobSlot_frame_local {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {r : Fin cp.D_max} {jbOpt : Option (SuffixJob cp)} {rSlots : List ℕ} {cSlot : ℕ}
    {m₀ m₁ : ArithRAMMemory}
    (hj : EncJobSlot ops r jbOpt rSlots cSlot m₀)
    (hw_base : ∀ off : ℤ, 0 ≤ off → off < 8 →
      wRead m₁ engMetaTbl (jobMetaBase cp r.val + off) =
        wRead m₀ engMetaTbl (jobMetaBase cp r.val + off))
    (hw_rslots : ∀ q < cp.D_max,
      wRead m₁ engMetaTbl (readySlotOff cp r.val q) =
        wRead m₀ engMetaTbl (readySlotOff cp r.val q))
    (hw_arr : ∀ i : ℤ,
      (((2 + 4 * r.val) * S_stride cp : ℕ) : ℤ) ≤ i →
      i < (((6 + 4 * r.val) * S_stride cp : ℕ) : ℤ) →
      wRead m₁ engArrTbl i = wRead m₀ engArrTbl i)
    (hnd : ∀ mn s, s ∈ jobUsedSlots jbOpt rSlots cSlot →
      ops.EncNode mn s m₀ → ops.EncNode mn s m₁) :
    EncJobSlot ops r jbOpt rSlots cSlot m₁ := by
  have hS_gt : cp.n < S_stride cp := by unfold S_stride; omega
  cases jbOpt with
  | none =>
      exact ⟨hj.1, by simpa using (hw_base 0 (by omega) (by omega)).trans hj.2⟩
  | some jb =>
      rcases hj with ⟨hact, hrle, hrlen, hwlen, hready, hph⟩
      refine ⟨by simpa using (hw_base 0 (by omega) (by omega)).trans hact,
        hrle, hrlen,
        (hw_base 1 (by omega) (by omega)).trans hwlen,
        fun q hq hqs => ⟨(hw_rslots q (lt_of_lt_of_le hq hrle)).trans (hready q hq hqs).1,
          hnd _ _ ?_ (hready q hq hqs).2⟩, ?_⟩
      · dsimp only [jobUsedSlots]
        cases jb.phase
        · exact List.getElem_mem hqs
        · exact List.mem_append_left _ (List.getElem_mem hqs)
      · cases hjp : jb.phase with
        | copy cs =>
            simp only [hjp] at hph
            rcases hph with ⟨hp2, hp3, hp4, hsp⟩
            have hsp_len : cs.snapArr.length ≤ cp.n := hsp.length_le
            refine ⟨(hw_base 2 (by omega) (by omega)).trans hp2,
              (hw_base 3 (by omega) (by omega)).trans hp3,
              (hw_base 4 (by omega) (by omega)).trans hp4,
              hsp.ext (hw_base 5 (by omega) (by omega))
                (fun k hk => by
                  have hb := stride_off_bounds cp r.val 2 k (by decide) (by decide) (by omega)
                  exact hw_arr _ (by unfold snapElemOff; exact hb.1) (by unfold snapElemOff; exact hb.2))
                (fun y hy => by
                  have hy_lt : y < cp.n := hsp.2.1 y hy
                  have hb := stride_off_bounds cp r.val 3 y (by decide) (by decide) (by omega)
                  exact hw_arr _ (by unfold snapPosOff; exact hb.1) (by unfold snapPosOff; exact hb.2))⟩
        | build bs =>
            simp only [hjp] at hph
            rcases hph with ⟨hp2, hp3, hp4, hsp, hdsp, hcslot, hcenc⟩
            have hsp_len : bs.snapArr.length ≤ cp.n := hsp.length_le
            have hdsp_len : bs.delSnapArr.length ≤ cp.n := hdsp.length_le
            have hc_in : cSlot ∈ jobUsedSlots (some jb) rSlots cSlot := by
              simp [jobUsedSlots, hjp]
            refine ⟨(hw_base 2 (by omega) (by omega)).trans hp2,
              (hw_base 3 (by omega) (by omega)).trans hp3,
              (hw_base 4 (by omega) (by omega)).trans hp4,
              hsp.ext (hw_base 5 (by omega) (by omega))
                (fun k hk => by
                  have hb := stride_off_bounds cp r.val 2 k (by decide) (by decide) (by omega)
                  exact hw_arr _ (by unfold snapElemOff; exact hb.1) (by unfold snapElemOff; exact hb.2))
                (fun y hy => by
                  have hy_lt : y < cp.n := hsp.2.1 y hy
                  have hb := stride_off_bounds cp r.val 3 y (by decide) (by decide) (by omega)
                  exact hw_arr _ (by unfold snapPosOff; exact hb.1) (by unfold snapPosOff; exact hb.2)),
              hdsp.ext (hw_base 6 (by omega) (by omega))
                (fun k hk => by
                  have hb := stride_off_bounds cp r.val 4 k (by decide) (by decide) (by omega)
                  exact hw_arr _ (by unfold delSnapElemOff; exact hb.1) (by unfold delSnapElemOff; exact hb.2))
                (fun y hy => by
                  have hy_lt : y < cp.n := hdsp.2.1 y hy
                  have hb := stride_off_bounds cp r.val 5 y (by decide) (by decide) (by omega)
                  exact hw_arr _ (by unfold delSnapPosOff; exact hb.1) (by unfold delSnapPosOff; exact hb.2)),
              (hw_base 7 (by omega) (by omega)).trans hcslot,
              hnd _ _ hc_in hcenc⟩

def passPrefixStepStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .ite (.and (.intLt (.readHeap engScrTbl (.lit 20)) (.readHeap engScrTbl (.lit 22)))
              (.intEq (.readHeap engScrTbl (.lit 23)) (.lit 1)))
    (.seq (.writeWordHeap engScrTbl (.lit 15)
            (.readHeap engMetaTbl (.add (.lit 16) (.readHeap engScrTbl (.lit 20)))))
    (.seq (ops.inCoreBallStmt 15 2 17)
          (.writeWordHeap engScrTbl (.lit 23)
            (.sub (.lit 1) (.readHeap engScrTbl (.lit 17))))))
    .skip

theorem zeroRand_passPrefixStepStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (passPrefixStepStmt ops) :=
  .ite (.seq (.writeWordHeap _ _ _)
        (.seq (ops.zeroRand_inCoreBall 15 2 17) (.writeWordHeap _ _ _)))
       .skip

theorem exec_passPrefixStepStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    {pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {serv₀ serv₁ : List (MNode cp)} {servSlots : List ℕ}
    {k h_op : ℕ}
    (hhop_lt : h_op < cp.n)
    (hlen1 : serv₁.length = serv₀.length)
    (hslen : servSlots.length = serv₀.length)
    (hsl_lt : ∀ s ∈ servSlots, s < M_slots cp)
    (hov_eq : ∀ q (hq1 : q < serv₁.length) (hq0 : q < serv₀.length),
      (serv₁[q]'hq1).nd.o = (serv₀[q]'hq0).nd.o ∧
      (serv₁[q]'hq1).nd.V = (serv₀[q]'hq0).nd.V)
    (hserv_enc : ∀ q (hq1 : q < serv₁.length) (hqs : q < servSlots.length),
      wRead m₀ engMetaTbl (servSlotOff q) = (servSlots[q]'hqs : ℤ) ∧
      ops.EncNode (serv₁[q]'hq1) (servSlots[q]'hqs) m₀)
    (hpts_hop : ∀ c : Fin d,
      rRead m₀ ptsRTbl (((h_op * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts' h_op) c)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hr2 : wRead m₀ engScrTbl 2 = (h_op : ℤ))
    (hr20 : wRead m₀ engScrTbl 20 = (k : ℤ))
    (hr22 : wRead m₀ engScrTbl 22 = (serv₀.length : ℤ))
    (hr23 : wRead m₀ engScrTbl 23 = (if passesNodes pts' h_op (serv₀.take k) then 1 else 0)) :
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (passPrefixStepStmt ops) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        wRead m₁ engScrTbl 23 = (if passesNodes pts' h_op (serv₀.take (k + 1)) then 1 else 0) ∧
        (∀ mn' s', s' < M_slots cp → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 15 → i ≠ 17 → i ≠ 23 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (ops.C_ball + 50) := by
  have hTW := ops.hTW
  have hBW_s := ops_hBW_scr64 ops
  let pk := passesNodes pts' h_op (serv₀.take k)
  have hcond : (evalArithCond inp 0 m₀
      (.and (.intLt (.readHeap engScrTbl (.lit 20)) (.readHeap engScrTbl (.lit 22)))
            (.intEq (.readHeap engScrTbl (.lit 23)) (.lit 1)))).1 =
      (decide (k < serv₀.length) && pk) := by
    simp only [evalArithCond, evalIntExpr]
    change (decide (wRead m₀ engScrTbl 20 < wRead m₀ engScrTbl 22) &&
            decide (wRead m₀ engScrTbl 23 = 1)) = _
    rw [hr20, hr22, hr23]
    congr 1
    · exact decide_eq_decide.mpr Int.ofNat_lt
    · dsimp only [pk]; generalize passesNodes pts' h_op (serv₀.take k) = b; cases b <;> rfl
  unfold passPrefixStepStmt
  refine ExecDet.ite' (C_c := 16) (C_b := ops.C_ball + 34) _ _ _ hcond
    (by simp [condExprOps, intExprOps]) (fun hgo => ?_) (fun hskip => ?_)
  · rcases Bool.and_eq_true_iff.mp hgo with ⟨hk_lt_b, hpk_t⟩
    have hk0 : k < serv₀.length := of_decide_eq_true hk_lt_b
    have hk1 : k < serv₁.length := hlen1 ▸ hk0
    have hks : k < servSlots.length := hslen ▸ hk0
    let slot_k := servSlots[k]'hks
    have hsl_k_lt : slot_k < M_slots cp := hsl_lt slot_k (List.getElem_mem hks)
    refine ExecDet.seq' (ops.C_ball + 16)
      (ExecDet.wWrite (C := 16) inp engScrTbl (.lit 15)
        (.readHeap engMetaTbl (.add (.lit 16) (.readHeap engScrTbl (.lit 20))))
        15 (slot_k : ℤ) hfp₀ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
        (by simp only [evalIntExpr]
            change wRead m₀ engMetaTbl (16 + wRead m₀ engScrTbl 20) = _
            rw [hr20]; exact (hserv_enc k hk1 hks).1)
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro mA hmA hfpA; subst hmA
    set m_A := H3a.wWrite m₀ engScrTbl 15 (slot_k : ℤ)
    have hndA : ∀ mn' s', ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m_A :=
      fun mn' s' he => ops.encNode_ext mn' s' m₀ m_A he
        (fun t ht9 _ i => wRead_wWrite_of_ne m₀ _ (Or.inl (by dsimp [engScrTbl]; omega)))
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
    refine ExecDet.seq' 16
      (ops.inCoreBall_spec inp m_A (serv₁[k]'hk1) slot_k h_op (pts' h_op) 15 2 17
        hsl_k_lt hhop_lt (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
        hfpA
        (ops.slotsReady_ext m₀ m_A hsr₀
          (fun t ht9 _ i => wRead_wWrite_of_ne m₀ _ (Or.inl (by dsimp [engScrTbl]; omega)))
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
        (hndA _ _ (hserv_enc k hk1 hks).2)
        (wRead_wWrite_self _ _ _ _)
        ((wRead_wWrite_of_ne m₀ _ (Or.inr (by decide))).trans hr2)
        (fun c => (rRead_wWrite _ _ _ _ _ _).trans (hpts_hop c)))
      (by omega) ?_
    intro mB ⟨hsrB, hcbB, hndB, hwB_t, hwB_scr, hrB⟩ hfpB
    rcases hov_eq k hk1 hk0 with ⟨ho_eq, hV_eq⟩
    have hpk1_eq : passesNodes pts' h_op (serv₀.take (k + 1)) =
        !inCoreBall (serv₁[k]'hk1).nd.o (serv₁[k]'hk1).nd.V (pts' h_op) := by
      have htake : serv₀.take (k + 1) = serv₀.take k ++ [serv₀[k]'hk0] := by
        rw [List.take_add_one, List.getElem?_eq_getElem hk0, Option.toList_some]
      rw [htake, passesNodes_snoc, show passesNodes pts' h_op (serv₀.take k) = true from hpk_t,
          Bool.true_and, ho_eq, hV_eq]
    refine ExecDet.wWrite (C := 16) inp engScrTbl (.lit 23)
      (.sub (.lit 1) (.readHeap engScrTbl (.lit 17)))
      23 (if passesNodes pts' h_op (serv₀.take (k + 1)) then 1 else 0)
      hfpB (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change 1 - wRead mB engScrTbl 17 = _
          rw [hcbB, hpk1_eq]
          cases inCoreBall (serv₁[k]'hk1).nd.o (serv₁[k]'hk1).nd.V (pts' h_op) <;> rfl)
      (by simp [intExprOps]) ?_
    set mC := H3a.wWrite mB engScrTbl 23 (if passesNodes pts' h_op (serv₀.take (k + 1)) then 1 else 0)
    have hndBC : ∀ mn' s', ops.EncNode mn' s' mB → ops.EncNode mn' s' mC :=
      fun mn' s' he => ops.encNode_ext mn' s' mB mC he
        (fun t ht9 _ i => wRead_wWrite_of_ne mB _ (Or.inl (by dsimp [engScrTbl]; omega)))
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
    exact ⟨ops.slotsReady_ext mB mC hsrB
        (fun t ht9 _ i => wRead_wWrite_of_ne mB _ (Or.inl (by dsimp [engScrTbl]; omega)))
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      wRead_wWrite_self _ _ _ _,
      fun mn' s' hs' he0 => hndBC _ _ (hndB mn' s' hs' (hndA mn' s' he0)),
      fun t ht9 ht8 i => (wRead_wWrite_of_ne mB _ (Or.inl ht8)).trans
        ((hwB_t t ht9 ht8 i).trans (wRead_wWrite_of_ne m₀ _ (Or.inl ht8))),
      fun i h15 h17 h23 => (wRead_wWrite_of_ne mB _ (Or.inr h23)).trans
        ((hwB_scr i h17).trans (wRead_wWrite_of_ne m₀ _ (Or.inr h15))),
      fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans ((hrB t ht3 i).trans (rRead_wWrite _ _ _ _ _ _))⟩
  · refine ExecDet.skip inp hfp₀ ?_ (by omega)
    have hpk1_eq : passesNodes pts' h_op (serv₀.take (k + 1)) = pk := by
      by_cases hk0 : k < serv₀.length
      · have hpk_f : pk = false := by simp only [hk0, decide_true, Bool.true_and] at hskip; exact hskip
        have htake : serv₀.take (k + 1) = serv₀.take k ++ [serv₀[k]'hk0] := by
          rw [List.take_add_one, List.getElem?_eq_getElem hk0, Option.toList_some]
        rw [htake, passesNodes_snoc, show passesNodes pts' h_op (serv₀.take k) = false from hpk_f,
            Bool.false_and, hpk_f]
      · have hge : serv₀.length ≤ k := Nat.le_of_not_lt hk0
        dsimp [pk]
        rw [List.take_of_length_le (by omega), List.take_of_length_le hge]
    exact ⟨hsr₀, by rw [hpk1_eq]; exact hr23,
      fun _ _ _ h => h, fun _ _ _ _ => rfl, fun _ _ _ _ => rfl, fun _ _ _ => rfl⟩


theorem serving_age_le_birthSize {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {P : DynamicPointSet d} {st : ChainEngineState cp}
    (hwf : ChainEngineWF cp P st) :
    ∀ mn ∈ st.serving, mn.nd.age ≤ mn.nd.birthSize := by
  have hK : 36 ≤ K_alpha d := K_alpha_ge_36 d
  rcases hwf with ⟨_, _, hserv_le, hserv_cl, hjobs_wf, _⟩
  intro mn hmem
  rcases List.mem_iff_getElem.mp hmem with ⟨i, hi, rfl⟩
  let r : Fin cp.D_max := ⟨i, lt_of_lt_of_le hi hserv_le⟩
  have hr_lt : r.val < st.serving.length := hi
  have hslot := hjobs_wf r
  simp only [hr_lt, ↓reduceDIte] at hslot
  cases hj : st.jobs r with
  | none =>
      simp only [hj] at hslot
      have : (st.serving[i]'hi).nd.age ≤ 64 * K_alpha d * (st.serving[i]'hi).nd.age := by
        simpa using Nat.mul_le_mul_right (st.serving[i]'hi).nd.age (by omega : 1 ≤ 64 * K_alpha d)
      exact le_of_lt (lt_of_le_of_lt this hslot)
  | some jb =>
      simp only [hj] at hslot
      have hMr : cp.B_scan < (st.serving[i]'hi).nd.birthSize :=
        (chainListInv_mem_birthSize P.activeHandles st.serving hserv_cl _ (List.getElem_mem hi)).1
      have h16 := (suffixJobInvSlack_bounds (Nat.zero_le _) hMr hslot).2.1
      have : (st.serving[i]'hi).nd.age ≤ 16 * K_alpha d * (st.serving[i]'hi).nd.age := by
        simpa using Nat.mul_le_mul_right (st.serving[i]'hi).nd.age (by omega : 1 ≤ 16 * K_alpha d)
      omega

theorem encJobSlot_after_handleStep {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {P : DynamicPointSet d} {st : ChainEngineState cp}
    {r : Fin cp.D_max} {rSlots : List ℕ} {cSlot : ℕ}
    {m₀ m₁ : ArithRAMMemory}
    (hwf : ChainEngineWF cp P st)
    (hj₀ : EncJobSlot ops r (st.jobs r) rSlots cSlot m₀)
    (hw6 : ∀ i, wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i)
    (hw7 : ∀ i, wRead m₁ engArrTbl i = wRead m₀ engArrTbl i)
    (hnd : ∀ mn s, mn.nd.curSet ⊆ P.activeHandles → ops.EncNode mn s m₀ → ops.EncNode mn s m₁) :
    EncJobSlot ops r (st.jobs r) rSlots cSlot m₁ := by
  rcases hwf with ⟨_, _, _, hserv_cl, hjobs_wf, _⟩
  by_cases hr : r.val < st.serving.length
  · have hslot := hjobs_wf r
    simp only [hr, ↓reduceDIte] at hslot
    cases hj : st.jobs r with
    | none =>
        simp only [hj] at hj₀ ⊢
        exact ⟨hj₀.1, (hw6 _).trans hj₀.2⟩
    | some jb =>
        simp only [hj] at hslot hj₀ ⊢
        rcases hj₀ with ⟨hact, hrle, hrlen, hwlen, hready, hph⟩
        let S_anc := foldResiduals st.hp.coords P.activeHandles (st.serving.take r.val)
        have hS_anc_sub : S_anc ⊆ P.activeHandles :=
          (chainListInv_getElem P.activeHandles st.serving (Finset.Subset.refl _) hserv_cl).2 r.val hr |>.1
        have hcl_ready : ChainListInv cp P.activeHandles st.hp.coords st.gt S_anc jb.ready :=
          hslot.2.1
        refine ⟨(hw6 _).trans hact, hrle, hrlen, (hw6 _).trans hwlen,
          fun q hq hqs => ⟨(hw6 _).trans (hready q hq hqs).1, ?_⟩, ?_⟩
        · rcases (chainListInv_getElem S_anc jb.ready hS_anc_sub hcl_ready).2 q hq with ⟨hSq_sub, hln_q⟩
          exact hnd _ _ (hln_q.1 ▸ hSq_sub) (hready q hq hqs).2
        · cases hjp : jb.phase with
          | copy cs =>
              simp only [hjp] at hph
              rcases hph with ⟨hp2, hp3, hp4, hsp⟩
              exact ⟨(hw6 _).trans hp2, (hw6 _).trans hp3, (hw6 _).trans hp4,
                hsp.ext (hw6 _) (fun _ _ => hw7 _) (fun _ _ => hw7 _)⟩
          | build bs =>
              simp only [hjp] at hph
              rcases hph with ⟨hp2, hp3, hp4, hsp, hdsp, hcslot, hcenc⟩
              let T_end := foldResiduals st.hp.coords S_anc jb.ready
              have hT_sub : T_end ⊆ P.activeHandles :=
                (chainListInv_getElem S_anc jb.ready hS_anc_sub hcl_ready).1
              have hbs_inv : BuildStateInv cp st.hp.coords st.gt T_end bs := by
                dsimp [SuffixJobInv, SuffixJobInvSlack] at hslot
                have hph_inv := hslot.2.2.2.2
                simp only [hjp] at hph_inv
                exact hph_inv.2.2.2.2
              have hcur_sub : bs.curNode.nd.curSet ⊆ P.activeHandles :=
                (hbs_inv.2.2.2.2.2.2.2.2.1 ▸ Finset.subset_union_left).trans hT_sub
              exact ⟨(hw6 _).trans hp2, (hw6 _).trans hp3, (hw6 _).trans hp4,
                hsp.ext (hw6 _) (fun _ _ => hw7 _) (fun _ _ => hw7 _),
                hdsp.ext (hw6 _) (fun _ _ => hw7 _) (fun _ _ => hw7 _),
                (hw6 _).trans hcslot,
                hnd _ _ hcur_sub hcenc⟩
  · have hnone : st.jobs r = none := by
      have hslot := hjobs_wf r
      simp only [hr, ↓reduceDIte] at hslot
      exact hslot
    simp only [hnone] at hj₀ ⊢
    exact ⟨hj₀.1, (hw6 _).trans hj₀.2⟩


end UL.Proof.clm_9_1_explicit_tradeoff.CG19
