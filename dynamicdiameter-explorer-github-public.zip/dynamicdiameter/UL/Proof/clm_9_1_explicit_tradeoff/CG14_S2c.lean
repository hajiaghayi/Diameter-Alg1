import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_S2b
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.C14d2

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1

/-! ### 4. Stage-3 Specification (`stepStage3_spec`) -/

def Stage3MidWF {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (P' : DynamicPointSet d) (k : ℕ) (cur : ChainEngineState cp) : Prop :=
  let actH := P'.activeHandles
  let pts := cur.hp.coords
  cur.hp.WellFormed P' ∧
  GhostTrackerWF actH pts cur.gt ∧
  cur.serving.length ≤ cp.D_max ∧
  ChainListInv cp actH pts cur.gt actH cur.serving ∧
  (∀ r : Fin cp.D_max,
    if hr : r.val < cur.serving.length then
      let mn := cur.serving[r.val]'hr
      match cur.jobs r with
      | none =>
          if r.val < k then
            64 * K_alpha d * mn.nd.age < mn.nd.birthSize
          else
            64 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize + 64 * K_alpha d
      | some jb =>
          SuffixJobInv cp actH pts cur.gt
            (foldResiduals pts actH (cur.serving.take r.val)) mn r.val jb
    else
      cur.jobs r = none) ∧
  (cur.leafOverflow = false →
    cur.leafArr.Nodup ∧
    cur.leafArr.toFinset = foldResiduals pts actH cur.serving ∧
    cur.leafArr.length ≤ cp.B_scan)

theorem stage3At_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {P' : DynamicPointSet d} {cur : ChainEngineState cp} (r : Fin cp.D_max)
    (hmid : Stage3MidWF cp P' r.val cur) :
    let nxt := stage3At cp cur r
    Stage3MidWF cp P' (r.val + 1) nxt ∧
    (ChainEngineGood cp hh0 hh1 cur → ChainEngineGood cp hh0 hh1 nxt) := by
  intro nxt; dsimp only [nxt]
  rcases hmid with ⟨hhp, hgt, hserv_len, hserv_cl, hjobs_wf, hleaf_wf⟩
  let actH := P'.activeHandles
  let pts := cur.hp.coords
  unfold stage3At
  by_cases hr : r.val < cur.serving.length
  · rw [dif_pos hr]
    cases hjb_r : cur.jobs r with
    | some jb_r =>
        dsimp only
        refine ⟨⟨hhp, hgt, hserv_len, hserv_cl, fun rr => ?_, hleaf_wf⟩, id⟩
        have hs := hjobs_wf rr
        by_cases hrr : rr.val < cur.serving.length
        · rw [dif_pos hrr] at hs ⊢; dsimp only at hs ⊢
          cases hjb_rr : cur.jobs rr with
          | some jb' => rw [hjb_rr] at hs; exact hs
          | none =>
              rw [hjb_rr] at hs
              have hne : rr.val ≠ r.val := by
                intro heq; have hrr_eq : rr = r := Fin.ext heq
                rw [hrr_eq, hjb_r] at hjb_rr; cases hjb_rr
              by_cases hlt : rr.val < r.val
              · rw [if_pos hlt] at hs; rw [if_pos (by omega)]; exact hs
              · rw [if_neg hlt] at hs; rw [if_neg (by omega)]; exact hs
        · rw [dif_neg hrr] at hs ⊢; exact hs
    | none =>
        dsimp only
        set mn := cur.serving[r.val]'hr
        have hslot_r := hjobs_wf r
        rw [dif_pos hr] at hslot_r; dsimp only at hslot_r
        rw [hjb_r, if_neg (Nat.lt_irrefl r.val)] at hslot_r
        rcases (chainListInv_getElem actH cur.serving (Finset.Subset.refl _) hserv_cl).2 r.val hr
          with ⟨hS_sub, hmn_ln⟩
        by_cases haged : mn.nd.birthSize ≤ 64 * K_alpha d * mn.nd.age
        · rw [if_pos haged]
          by_cases hsmall : mn.nd.denseArr.length ≤ cp.B_scan
          · -- Truncate chain to `cur.serving.take r.val`!
            rw [if_pos hsmall]
            have htake_len : (cur.serving.take r.val).length = r.val :=
              List.length_take_of_le (Nat.le_of_lt hr)
            refine ⟨⟨hhp, hgt, by rw [htake_len]; omega,
              chainListInv_take r.val actH cur.serving hserv_cl, ?_, ?_⟩,
              fun hgd => ⟨rfl, fun u hu => hgd.2.1 u (List.mem_of_mem_take hu), ?_⟩⟩
            · intro rr
              by_cases hrr_tk : rr.val < (cur.serving.take r.val).length
              · rw [dif_pos hrr_tk]; dsimp only
                have hrr_lt_r : rr.val < r.val := by rwa [htake_len] at hrr_tk
                rw [if_pos hrr_lt_r]
                have hrr_serv : rr.val < cur.serving.length := lt_trans hrr_lt_r hr
                have hs := hjobs_wf rr
                rw [dif_pos hrr_serv] at hs; dsimp only at hs
                have hget_tk : (cur.serving.take r.val)[rr.val]'hrr_tk = cur.serving[rr.val]'hrr_serv :=
                  List.getElem_take
                have htk_tk : (cur.serving.take r.val).take rr.val = cur.serving.take rr.val := by
                  rw [List.take_take, Nat.min_eq_left (Nat.le_of_lt hrr_lt_r)]
                rw [hget_tk, htk_tk]
                cases hj_rr : cur.jobs rr with
                | none =>
                    rw [hj_rr] at hs
                    rw [if_pos hrr_lt_r] at hs
                    rw [if_pos (by omega)]
                    exact hs
                | some jb' => rw [hj_rr] at hs; exact hs
              · rw [dif_neg hrr_tk]; dsimp only
                have hnot_lt : ¬ rr.val < r.val := by rwa [htake_len] at hrr_tk
                rw [if_neg hnot_lt]
            · intro _
              exact ⟨hmn_ln.2.2.2.2.2.2.2.1.1, hmn_ln.1, hsmall⟩
            · intro rr hrr_tk jb' hjb'
              dsimp only at hjb'
              rw [htake_len] at hrr_tk
              rw [if_pos hrr_tk] at hjb'
              exact hgd.2.2 rr (lt_trans hrr_tk hr) jb' hjb'
          · -- Open new `.copy` job at `r`!
            rw [if_neg hsmall]
            have hgt_B_d : cp.B_scan < mn.nd.denseArr.length := by omega
            have hhist_gt_B : cp.B_scan < mn.histArr.length := by
              have h1 : mn.nd.denseArr.length = mn.nd.curSet.card :=
                (List.toFinset_card_of_nodup hmn_ln.2.2.2.2.2.2.2.1.1).symm
              have h2 : mn.nd.curSet.card ≤ mn.histArr.toFinset.card :=
                Finset.card_le_card hmn_ln.2.2.2.2.2.2.2.2.2.2
              have h3 : mn.histArr.toFinset.card ≤ mn.histArr.length := List.toFinset_card_le _
              omega
            have hhist_le_2 : mn.histArr.length ≤ 2 * mn.nd.birthSize := by
              have hB1 := cp.sched_bounds.1
              have hB_m : cp.B_scan < mn.nd.birthSize := hmn_ln.2.2.1
              have hK := K_alpha_ge_36 d
              have hage_lt_m : mn.nd.age < mn.nd.birthSize := by
                have h64 : 64 * K_alpha d * mn.nd.age < 2 * mn.nd.birthSize := by dsimp only [mn] at *; omega
                have h2 : 2 * mn.nd.age ≤ 64 * K_alpha d * mn.nd.age :=
                  Nat.mul_le_mul_right _ (by omega)
                omega
              have h1 := hmn_ln.2.2.2.2.2.1
              dsimp only [mn] at *
              omega
            have hjb_new_inv : SuffixJobInv cp actH pts cur.gt
                (foldResiduals pts actH (cur.serving.take r.val)) mn r.val
                { ready := [], phase := .copy (CopyState.init mn.histArr.length) } := by
              dsimp only [SuffixJobInv, SuffixJobInvSlack, List.length_nil, List.getLast?_nil,
                JobPhase.lvlProg, CopyState.init, foldResiduals]
              refine ⟨by omega, trivial, fun _ hq => absurd hq (Nat.not_lt_zero _), ?_,
                by omega, hhist_le_2, ?_⟩
              · simp only [Nat.zero_mul, Nat.add_zero]
                have hm := Nat.mul_le_mul_left cp.B_scan hslot_r
                linarith only [hm]
              · apply copyState_init_spec
                rw [← hmn_ln.1]; exact hmn_ln.2.2.2.2.2.2.2.2.2.2
            refine ⟨⟨hhp, hgt, hserv_len, hserv_cl, fun rr => ?_, hleaf_wf⟩, fun hgd => ⟨hgd.1, hgd.2.1, ?_⟩⟩
            · by_cases hrr_eq : rr = r
              · subst hrr_eq
                rw [dif_pos hr]; dsimp only
                rw [Function.update_self]
                exact hjb_new_inv
              · have hne_val : rr.val ≠ r.val := fun hv => hrr_eq (Fin.ext hv)
                have hs := hjobs_wf rr
                by_cases hrr : rr.val < cur.serving.length
                · rw [dif_pos hrr] at hs ⊢; dsimp only at hs ⊢
                  rw [Function.update_of_ne hrr_eq]
                  cases hj_rr : cur.jobs rr with
                  | some jb' => rw [hj_rr] at hs; exact hs
                  | none =>
                      rw [hj_rr] at hs
                      by_cases hlt : rr.val < r.val
                      · rw [if_pos hlt] at hs; rw [if_pos (by omega)]; exact hs
                      · rw [if_neg hlt] at hs; rw [if_neg (by omega)]; exact hs
                · rw [dif_neg hrr] at hs ⊢; dsimp only
                  rw [Function.update_of_ne hrr_eq]; exact hs
            · intro rr hrr jb' hjb'
              dsimp only at hjb'
              by_cases hrr_eq : rr = r
              · subst hrr_eq
                rw [Function.update_self] at hjb'
                injection hjb' with heq; subst heq
                exact ⟨fun _ hm => absurd hm List.not_mem_nil, trivial⟩
              · rw [Function.update_of_ne hrr_eq] at hjb'
                exact hgd.2.2 rr hrr jb' hjb'
        · -- `64 * K_alpha d * mn.nd.age < mn.nd.birthSize` already holds!
          rw [if_neg haged]
          have hlt_64 : 64 * K_alpha d * mn.nd.age < mn.nd.birthSize := by omega
          refine ⟨⟨hhp, hgt, hserv_len, hserv_cl, fun rr => ?_, hleaf_wf⟩, id⟩
          by_cases hrr_eq : rr = r
          · subst hrr_eq
            rw [dif_pos hr]; dsimp only
            rw [hjb_r, if_pos (Nat.lt_succ_self _)]
            exact hlt_64
          · have hne_val : rr.val ≠ r.val := fun hv => hrr_eq (Fin.ext hv)
            have hs := hjobs_wf rr
            by_cases hrr : rr.val < cur.serving.length
            · rw [dif_pos hrr] at hs ⊢; dsimp only at hs ⊢
              cases hj_rr : cur.jobs rr with
              | some jb' => rw [hj_rr] at hs; exact hs
              | none =>
                  rw [hj_rr] at hs
                  by_cases hlt : rr.val < r.val
                  · rw [if_pos hlt] at hs; rw [if_pos (by omega)]; exact hs
                  · rw [if_neg hlt] at hs; rw [if_neg (by omega)]; exact hs
            · rw [dif_neg hrr] at hs ⊢; exact hs
  · rw [dif_neg hr]
    refine ⟨⟨hhp, hgt, hserv_len, hserv_cl, fun rr => ?_, hleaf_wf⟩, id⟩
    have hs := hjobs_wf rr
    by_cases hrr : rr.val < cur.serving.length
    · rw [dif_pos hrr] at hs ⊢; dsimp only at hs ⊢
      have hne_val : rr.val ≠ r.val := by omega
      cases hj_rr : cur.jobs rr with
      | some jb' => rw [hj_rr] at hs; exact hs
      | none =>
          rw [hj_rr] at hs
          by_cases hlt : rr.val < r.val
          · rw [if_pos hlt] at hs; rw [if_pos (by omega)]; exact hs
          · rw [if_neg hlt] at hs; rw [if_neg (by omega)]; exact hs
    · rw [dif_neg hrr] at hs ⊢; exact hs

theorem stepStage3_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {P' : DynamicPointSet d} {st₂ : ChainEngineState cp}
    (hwf₂ : PostStage2WF cp P' st₂) :
    let st₃ := stepStage3 cp st₂
    ChainEngineWF cp P' st₃ ∧
    (ChainEngineGood cp hh0 hh1 st₂ → ChainEngineGood cp hh0 hh1 st₃) := by
  intro st₃; dsimp only [st₃]
  have hmid0 : Stage3MidWF cp P' 0 st₂ := by
    rcases hwf₂ with ⟨h1, h2, h3, h4, h5, h6⟩
    refine ⟨h1, h2, h3, h4, fun r => ?_, h6⟩
    have hs := h5 r
    by_cases hr : r.val < st₂.serving.length
    · rw [dif_pos hr] at hs ⊢; dsimp only at hs ⊢
      cases hj : st₂.jobs r with
      | none => rw [hj] at hs; rw [if_neg (Nat.not_lt_zero _)]; exact hs
      | some _ => rw [hj] at hs; exact hs
    · rw [dif_neg hr] at hs ⊢; exact hs
  have hfold_step : ∀ (k : ℕ) (hk : k ≤ cp.D_max),
      let cur := ((List.finRange cp.D_max).take k).foldl (stage3At cp) st₂
      Stage3MidWF cp P' k cur ∧
      (ChainEngineGood cp hh0 hh1 st₂ → ChainEngineGood cp hh0 hh1 cur) := by
    intro k hk cur; dsimp only [cur]
    induction k with
    | zero =>
        simp only [List.take_zero, List.foldl_nil]
        exact ⟨hmid0, id⟩
    | succ m ih =>
        have hm_lt : m < cp.D_max := Nat.lt_of_succ_le hk
        have hm_lt_fr : m < (List.finRange cp.D_max).length := by simp [hm_lt]
        rcases ih (Nat.le_of_succ_le hk) with ⟨hmid_m, hgd_m⟩
        have htk_eq : (List.finRange cp.D_max).take (m + 1) =
            (List.finRange cp.D_max).take m ++ [(List.finRange cp.D_max)[m]'hm_lt_fr] :=
          List.take_succ_eq_append_getElem hm_lt_fr
        have hfr_m : (List.finRange cp.D_max)[m]'hm_lt_fr = ⟨m, hm_lt⟩ := by simp
        rw [htk_eq, hfr_m, List.foldl_append, List.foldl_cons, List.foldl_nil]
        rcases stage3At_spec cp hh0 hh1 ⟨m, hm_lt⟩ hmid_m with ⟨hmid_next, hgd_next⟩
        exact ⟨hmid_next, fun hg => hgd_next (hgd_m hg)⟩
  rcases hfold_step cp.D_max le_rfl with ⟨hmidD, hgdD⟩
  have htk_all : (List.finRange cp.D_max).take cp.D_max = List.finRange cp.D_max := by
    apply List.take_of_length_le; simp
  rw [htk_all] at hmidD hgdD
  change Stage3MidWF cp P' cp.D_max (stepStage3 cp st₂) at hmidD
  rcases hmidD with ⟨h1, h2, h3, h4, h5, h6⟩
  refine ⟨⟨h1, h2, h3, h4, fun r => ?_, h6⟩, hgdD⟩
  have hs := h5 r
  by_cases hr : r.val < (stepStage3 cp st₂).serving.length
  · rw [dif_pos hr] at hs ⊢; dsimp only at hs ⊢
    cases hj : (stepStage3 cp st₂).jobs r with
    | none => rw [hj] at hs; rw [if_pos r.isLt] at hs; exact hs
    | some _ => rw [hj] at hs; exact hs
  · rw [dif_neg hr] at hs ⊢; exact hs

/-! ### 5. Stage-4 Specification (`stepStage4_spec`) & Full `stepChainEngine_spec` -/

def GoodStage4Coins {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st₃ : ChainEngineState cp) (ω₄ : Stage4Coins cp) : Prop :=
  ∀ i : Fin cp.D_max,
    ∀ hi : i.val < st₃.serving.length,
      let mn := st₃.serving[i.val]'hi
      SatisfiesNodeBaselineCond st₃.hp.coords mn.nd.o mn.nd.V mn.nd.curSet
        (evalBaselinePair cp.hk_base cp.T_pow st₃.hp.coords mn.nd.o mn.nd.denseArr (ω₄ i))

def GoodStepCoins {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (st : ChainEngineState cp) (uop : InternalUpdate d) (coins : StepCoinBundle cp) : Prop :=
  let (st₁, _) := stepStage1 cp st uop coins.1
  let st₂ := stepStage2 cp st₁ coins.2.1
  let st₃ := stepStage3 cp st₂
  GoodStage1Coins cp hh0 hh1 st coins.1 ∧
  GoodStage2Coins cp hh0 hh1 st₁ coins.2.1 ∧
  GoodStage4Coins cp st₃ coins.2.2

private lemma storedEdge_isStoredMatchingEdge {ι : Type*} [DecidableEq ι] (st : LocalMatchingState ι) :
    IsStoredMatchingEdge st.matching st.storedEdge := by
  unfold LocalMatchingState.storedEdge LocalMatchingState.matching
  cases hml : st.matchingList with
  | nil => simp [IsStoredMatchingEdge]
  | cons hd tl =>
      simp only [List.head?_cons, Option.map_some, IsStoredMatchingEdge, List.map_cons,
        List.toFinset_cons, Finset.mem_insert_self]

private lemma indexedDiam_congr_pts {d : ℕ} {P : Finset ℕ}
    {pts₁ pts₂ : ℕ → EuclideanSpace ℝ (Fin d)}
    (heq : ∀ x ∈ P, pts₁ x = pts₂ x) :
    indexedEuclideanDiam P pts₁ = indexedEuclideanDiam P pts₂ := by
  unfold indexedEuclideanDiam
  by_cases hne : P.Nonempty
  · rw [dif_pos hne, dif_pos hne]
    refine Finset.sup'_congr (hne.product hne) rfl (fun xy hxy => ?_)
    rcases Finset.mem_product.mp hxy with ⟨hx, hy⟩
    rw [heq xy.1 hx, heq xy.2 hy]
  · rw [dif_neg hne, dif_neg hne]

private lemma dist_le_indexedDiam {d : ℕ} {P : Finset ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) {x y : ℕ} (hx : x ∈ P) (hy : y ∈ P) :
    ‖pts x - pts y‖ ≤ indexedEuclideanDiam P pts := by
  unfold indexedEuclideanDiam
  have hne : P.Nonempty := ⟨x, hx⟩
  rw [dif_pos hne]
  exact Finset.le_sup' (f := fun xy : ℕ × ℕ => ‖pts xy.1 - pts xy.2‖) (b := (x, y)) (Finset.mem_product.mpr ⟨hx, hy⟩)

theorem stepStage4_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hc_pos : 0 < params.c)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {P' : DynamicPointSet d} (hP' : P'.WellFormed cp.n)
    {st₃ : ChainEngineState cp} (hwf₃ : ChainEngineWF cp P' st₃)
    (ω₄ : Stage4Coins cp) :
    let st₄ := stepStage4 cp st₃ ω₄
    ChainEngineWF cp P' st₄ ∧
    (ChainEngineGood cp hh0 hh1 st₃ →
     GoodStage4Coins cp st₃ ω₄ →
     ChainEngineGood cp hh0 hh1 st₄ ∧
     IsValidFactorCAnswer params.c P' st₄.cachedAns) := by
  intro st₄; dsimp only [st₄]
  have hwf₄ : ChainEngineWF cp P' (stepStage4 cp st₃ ω₄) := hwf₃
  refine ⟨hwf₄, fun hgd₃ hcoins₄ => ⟨hgd₃, ?_⟩⟩
  rcases hwf₃ with ⟨hhp, hgt, hserv_len, hserv_cl, _, hleaf_wf⟩
  rcases hhp with ⟨_, hact_nd, _, hact_set, _, _, _, hcoords⟩
  let actH := P'.activeHandles
  let pts := st₃.hp.coords
  let leafPair : Option (ℕ × ℕ) :=
    if !st₃.leafOverflow && decide (st₃.leafArr.length ≤ cp.B_scan) then
      evalExactLeafPair pts st₃.leafArr
    else
      none
  let nodeCands : List (Option (ℕ × ℕ)) :=
    (List.finRange cp.D_max).flatMap (fun i =>
      if hi : i.val < st₃.serving.length then
        let mn := st₃.serving[i.val]'hi
        let bp := evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr (ω₄ i)
        let ses := (List.finRange cp.N_cfg).map (fun c => (mn.nd.cfgs c).st.storedEdge)
        bp :: ses
      else
        [])
  let cands := leafPair :: nodeCands
  rcases evalBestGlobalAnswer_spec pts hact_nd hact_set cands with ⟨hle1_ans, hge2_ans⟩
  have hans_eq : (stepStage4 cp st₃ ω₄).cachedAns = evalBestGlobalAnswer pts st₃.hp.actList cands := rfl
  rw [hans_eq]
  apply validFactorCAnswer_of_handles hP' hle1_ans
  intro hge2
  rcases hge2_ans hge2 with ⟨h₁, h₂, hdh, hne12, hh₁, hh₂, hcsq, hbest_ge⟩
  have hdiam_eq : indexedEuclideanDiam actH P'.handleCoords = indexedEuclideanDiam actH pts :=
    (indexedDiam_congr_pts hcoords).symm
  have hnorm12_eq : ‖P'.handleCoords h₁ - P'.handleCoords h₂‖ = ‖pts h₁ - pts h₂‖ := by
    rw [← hcoords h₁ hh₁, ← hcoords h₂ hh₂]
  refine ⟨h₁, h₂, hdh, hne12, by rw [hcsq, hnorm12_eq], hh₁, hh₂, hne12, ?_, ?_⟩
  · -- Prove `indexedEuclideanDiam actH P'.handleCoords / params.c ≤ ‖P'.handleCoords h₁ - P'.handleCoords h₂‖`
    rw [hdiam_eq, hnorm12_eq]
    by_cases hdiam_pos : 0 < indexedEuclideanDiam actH pts
    · -- Non-degenerate positive diameter -> apply `S_clm_7_3_global_approx.2.2.1`!
      let k := st₃.serving.length
      let nodes : Fin k → ChainNode d := fun i => (st₃.serving[i.val]'i.isLt).nd.toChainNode
      let basePairs : Fin k → Option (ℕ × ℕ) := fun i =>
        let mn := st₃.serving[i.val]'i.isLt
        evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr
          (ω₄ ⟨i.val, lt_of_lt_of_le i.isLt hserv_len⟩)
      let M_fn : Fin k → ShellConfig → Finset (ℕ × ℕ) := fun i cfg =>
        open Classical in
        if hmem : cfg ∈ params.retainedConfigs 1 then
          ((st₃.serving[i.val]'i.isLt).nd.cfgs (Classical.choose (cp.hspecs_surj cfg hmem))).st.matching
        else
          ∅
      let stored_fn : Fin k → ShellConfig → Option (ℕ × ℕ) := fun i cfg =>
        open Classical in
        if hmem : cfg ∈ params.retainedConfigs 1 then
          ((st₃.serving[i.val]'i.isLt).nd.cfgs (Classical.choose (cp.hspecs_surj cfg hmem))).st.storedEdge
        else
          none
      -- Check Hypothesis 1: `SatisfiesBaselineCond`
      have hbase_ok : ∀ i : Fin k,
          (nodes i).SatisfiesBaselineCond pts (chainInput pts nodes actH i.castSucc) (basePairs i) := by
        intro i
        have hln_i := (chainListInv_getElem actH st₃.serving (Finset.Subset.refl _) hserv_cl).2 i.val i.isLt |>.2
        have hci_eq : chainInput pts nodes actH i.castSucc = (st₃.serving[i.val]'i.isLt).nd.curSet := by
          dsimp only [nodes, Fin.castSucc, Fin.castAdd, Fin.castLE]
          rw [← foldResiduals_take_eq_chainInput pts actH st₃.serving i.val (Nat.le_of_lt i.isLt), hln_i.1]
        dsimp only [ChainNode.SatisfiesBaselineCond]
        rw [hci_eq]
        dsimp only [nodes, basePairs, NodeInst.toChainNode]
        exact hcoins₄ ⟨i.val, lt_of_lt_of_le i.isLt hserv_len⟩ i.isLt
      -- Check Hypothesis 2: `SatisfiesMatchingInvariant ∧ IsStoredMatchingEdge`
      have hmat_ok : ∀ i : Fin k,
          0 < (nodes i).V →
          ∀ cfg ∈ params.retainedConfigs (nodes i).V,
            params.SatisfiesMatchingInvariant pts (nodes i).o (nodes i).V
              (chainInput pts nodes actH i.castSucc) cfg.j cfg.k cfg.ℓ (M_fn i cfg) ∧
            IsStoredMatchingEdge (M_fn i cfg) (stored_fn i cfg) := by
        intro i hVi cfg hcfg_V
        have hmem1 : cfg ∈ params.retainedConfigs 1 := by
          rwa [retainedConfigs_eq_one params hVi] at hcfg_V
        let idx_c := Classical.choose (cp.hspecs_surj cfg hmem1)
        have hspec_cfg : (cp.specs idx_c).cfg = cfg := Classical.choose_spec (cp.hspecs_surj cfg hmem1)
        have hln_i := (chainListInv_getElem actH st₃.serving (Finset.Subset.refl _) hserv_cl).2 i.val i.isLt |>.2
        have hci_eq : chainInput pts nodes actH i.castSucc = (st₃.serving[i.val]'i.isLt).nd.curSet := by
          dsimp only [nodes, Fin.castSucc, Fin.castAdd, Fin.castLE]
          rw [← foldResiduals_take_eq_chainInput pts actH st₃.serving i.val (Nat.le_of_lt i.isLt), hln_i.1]
        have hgd_i := (hgd₃.2.1 _ (List.getElem_mem i.isLt)).2 hVi idx_c
        dsimp only [M_fn, stored_fn]
        rw [dif_pos hmem1, dif_pos hmem1]
        refine ⟨?_, storedEdge_isStoredMatchingEdge _⟩
        have hinv_c := hgd_i.1.2
        rw [hspec_cfg] at hinv_c
        dsimp only [LocalScaleParams.SatisfiesMatchingInvariant]
        rw [hci_eq]
        dsimp only [nodes, NodeInst.toChainNode]
        exact hinv_c
      -- Check Hypothesis 3: `IsExactLeafAnswer`
      rcases hleaf_wf hgd₃.1 with ⟨hlf_nd, hlf_set, hlf_len⟩
      have hlp_eq : leafPair = evalExactLeafPair pts st₃.leafArr := by
        dsimp only [leafPair]; rw [if_pos (by simp [hgd₃.1, hlf_len])]
      have hleaf_ok : IsExactLeafAnswer pts (chainTerminal pts nodes actH) leafPair := by
        dsimp only [nodes]
        rw [hlp_eq, ← foldResiduals_eq_chainTerminal pts actH st₃.serving, ← hlf_set]
        exact evalExactLeafPair_spec pts hlf_nd
      rcases h_clm_7_3.2.2.1 d ℕ pts params actH k nodes basePairs M_fn stored_fn leafPair
        hbase_ok hmat_ok hleaf_ok with ⟨_, _, hW_icc, _, hge2_clm⟩
      rcases hge2_clm hge2 with ⟨u, v, huv_diam, hW_cand⟩
      have hW_pos : 0 < (Finset.univ : Finset (Fin (k + 1))).sup' Finset.univ_nonempty
          (Fin.lastCases (baselinePairLength pts leafPair) (fun i =>
            params.nodeRetainedEstimate pts (nodes i).V
              (baselinePairLength pts (basePairs i)) (stored_fn i))) := by
        have hdiv_pos : 0 < indexedEuclideanDiam actH pts / params.c := div_pos hdiam_pos hc_pos
        exact lt_of_lt_of_le hdiv_pos hW_icc.1
      rcases hW_cand hW_pos with ⟨_, hcand_src⟩
      -- Show `some (u, v) ∈ cands`!
      have huv_mem_cands : some (u, v) ∈ cands := by
        dsimp only [cands]
        rcases hcand_src with hlp_uv | ⟨i, hbp_uv⟩ | ⟨i, _, cfg, hcfg_V, hst_uv⟩
        · rw [← hlp_uv]; exact List.mem_cons_self
        · apply List.mem_cons_of_mem
          let iD : Fin cp.D_max := ⟨i.val, lt_of_lt_of_le i.isLt hserv_len⟩
          dsimp only [nodeCands]
          rw [List.mem_flatMap]
          refine ⟨iD, List.mem_finRange iD, ?_⟩
          rw [dif_pos i.isLt, ← hbp_uv]
          exact List.mem_cons_self
        · apply List.mem_cons_of_mem
          let iD : Fin cp.D_max := ⟨i.val, lt_of_lt_of_le i.isLt hserv_len⟩
          have hVi : 0 < (nodes i).V := by assumption
          have hmem1 : cfg ∈ params.retainedConfigs 1 := by
            rwa [retainedConfigs_eq_one params hVi] at hcfg_V
          dsimp only [stored_fn] at hst_uv
          rw [dif_pos hmem1] at hst_uv
          let idx_c := Classical.choose (cp.hspecs_surj cfg hmem1)
          dsimp only [nodeCands]
          rw [List.mem_flatMap]
          refine ⟨iD, List.mem_finRange iD, ?_⟩
          rw [dif_pos i.isLt]
          apply List.mem_cons_of_mem
          rw [← hst_uv]
          exact List.mem_map.mpr ⟨idx_c, List.mem_finRange idx_c, rfl⟩
      rcases huv_diam with ⟨hu_in, hv_in, huv_ne, huv_lb, _⟩
      exact huv_lb.trans (hbest_ge u v huv_mem_cands huv_ne hu_in hv_in)
    · -- Degenerate zero diameter: `indexedEuclideanDiam actH pts ≤ 0`!
      have hle0 : indexedEuclideanDiam actH pts ≤ 0 := not_lt.mp hdiam_pos
      have hdiv_le0 : indexedEuclideanDiam actH pts / params.c ≤ 0 :=
        div_nonpos_of_nonpos_of_nonneg hle0 hc_pos.le
      exact hdiv_le0.trans (norm_nonneg _)
  · rw [hdiam_eq, hnorm12_eq]
    exact dist_le_indexedDiam pts hh₁ hh₂

/-- Complete 4-stage `stepChainEngine` theorem combining worst-case `ChainEngineWF` preservation,
good-event `ChainEngineGood` preservation, and `IsValidFactorCAnswer`! -/
theorem stepChainEngine_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1) (hc_pos : 0 < params.c)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {P : DynamicPointSet d} (hP : P.WellFormed cp.n)
    {op : DynamicUpdate d} (hleg : IsLegalUpdate cp.n Set.univ P op)
    {st : ChainEngineState cp} (hwf : ChainEngineWF cp P st)
    (coins : StepCoinBundle cp) :
    let res := stepChainEngine cp st (toInternalUpdate P op) coins
    ∃ P' : DynamicPointSet d,
      applyDynamicUpdate P op res.2 = some P' ∧
      ChainEngineWF cp P' res.1 ∧
      (ChainEngineGood cp hh0 hh1 st →
       GoodStepCoins cp hh0 hh1 st (toInternalUpdate P op) coins →
       ChainEngineGood cp hh0 hh1 res.1 ∧
       IsValidFactorCAnswer params.c P' res.1.cachedAns) := by
  intro res; dsimp only [res]
  rcases stepStage1_spec h_clm_7_3 hd he1 cp hh0 hh1 hP hleg hwf coins.1
    with ⟨P', happ, hwf₁, hgd₁_imp⟩
  have hP' : P'.WellFormed cp.n := applyDynamicUpdate_wellFormed hP hleg happ
  let st₁ := (stepStage1 cp st (toInternalUpdate P op) coins.1).1
  rcases stepStage2_spec h_lem_5_1 h_clm_7_3 hd he1 cp hh0 hh1 hP' hwf₁ coins.2.1
    with ⟨hwf₂, hgd₂_imp⟩
  let st₂ := stepStage2 cp st₁ coins.2.1
  rcases stepStage3_spec cp hh0 hh1 hwf₂ with ⟨hwf₃, hgd₃_imp⟩
  let st₃ := stepStage3 cp st₂
  rcases stepStage4_spec h_clm_7_3 hc_pos cp hh0 hh1 hP' hwf₃ coins.2.2
    with ⟨hwf₄, hgd₄_imp⟩
  refine ⟨P', happ, hwf₄, fun hgd0 ⟨hc1, hc2, hc4⟩ => ?_⟩
  have hgd₁ := hgd₁_imp hgd0 hc1
  have hgd₂ := hgd₂_imp hgd₁ hc2
  have hgd₃ := hgd₃_imp hgd₂
  exact hgd₄_imp hgd₃ hc4

end UL.Proof.clm_9_1_explicit_tradeoff.C14d2
