import UL.Proof.clm_9_1_explicit_tradeoff.CG02_SideQuery0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot optNatToInt findSome_finRange_eq_foldl
  slotWStride slotRStride slotQryWStride slotQryRStride)

/-! ### 1. Pure Fold Characterization & Frame Helpers -/

def qryOptOr (a b : Option ℕ) : Option ℕ :=
  match a with
  | some w => some w
  | none => b

lemma qry_wne {m : ArithRAMMemory} {t : ℕ} {i j v : ℤ} (h : j ≠ i) :
    wRead (wWrite m t i v) t j = wRead m t j :=
  wRead_wWrite_of_ne m v (Or.inr h)

lemma qry_wne_t {m : ArithRAMMemory} {t₁ t₂ : ℕ} {i j v : ℤ} (h : t₂ ≠ t₁) :
    wRead (wWrite m t₁ i v) t₂ j = wRead m t₂ j :=
  wRead_wWrite_of_ne m v (Or.inl h)

lemma qry_det_wLit {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (t : ℕ) (idx : ℤ) (valE : IntExpr) (v : ℤ) (C : ℕ)
    (hv : iValAt 0 inp m valE = v) (hC : intExprOps (.lit idx) + intExprOps valE + 1 ≤ C) :
    DetExec inp (.writeWordHeap t (.lit idx) valE) m (wWrite m t idx v) C :=
  DetExecAt.writeWordHeap 0 inp m t (.lit idx) valE rfl hv hC

noncomputable def dyadicSideScaleOpt {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (M_lat : ℕ) (A B_rat τ_q : ℚ) (b_thr : ℝ) (cap_q : ℕ)
    (o p_v : EuclideanSpace ℝ (Fin d))
    (idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b) (s : Fin L_p2) : Option ℕ :=
  open Classical in
  let H := 2 ^ s.val
  let B := 2 * H
  let q := idx.t_ins / B
  let off := idx.t_ins % B
  let r1 : Option ℕ :=
    if 1 ≤ q ∧ H ≤ off then
      let sl : Fin 2 := H4b.mod2Fin (q - 1)
      ((idx.slots s sl).query hM₀ M_lat A B_rat τ_q b_thr cap_q
        idx.entryPt o p_v idx.entryAlive).map idx.entryHandle
    else
      none
  match r1 with
  | some w => some w
  | none =>
      if 2 ≤ q then
        let sl : Fin 2 := H4b.mod2Fin (q - 2)
        ((idx.slots s sl).query hM₀ M_lat A B_rat τ_q b_thr cap_q
          idx.entryPt o p_v idx.entryAlive).map idx.entryHandle
      else
        none

private lemma foldl_qryOptOr_some :
    ∀ (k : ℕ) (f : Fin k → Option ℕ) (w : ℕ),
      Fin.foldl k (fun acc i => qryOptOr acc (f i)) (some w) = some w
  | 0, _, _ => by rw [Fin.foldl_zero]
  | k + 1, f, w => by
      rw [Fin.foldl_succ_last, foldl_qryOptOr_some k (fun j => f j.castSucc) w]; rfl

lemma dyadicSide_query_eq_foldl {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (M_lat : ℕ) (A B_rat τ_q : ℚ) (b_thr : ℝ) (cap_q : ℕ)
    (o p_v : EuclideanSpace ℝ (Fin d))
    (idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b) :
    Fin.foldl L_p2 (fun acc (s : Fin L_p2) =>
      qryOptOr acc (dyadicSideScaleOpt hM₀ M_lat A B_rat τ_q b_thr cap_q o p_v idx s))
      (qryOptOr (dyadicSideTailOpt b_thr o p_v idx 1) (dyadicSideTailOpt b_thr o p_v idx 2)) =
      idx.query hM₀ M_lat A B_rat τ_q b_thr cap_q o p_v := by
  unfold H4b.DyadicSideIndex.query dyadicSideTailOpt
  dsimp only
  by_cases ht1 : 1 ≤ idx.t_ins ∧ idx.entryAlive (idx.t_ins - 1) = true ∧
      b_thr < radialCorrelation o p_v (idx.entryPt (idx.t_ins - 1))
  · simp only [if_pos ht1]
    exact foldl_qryOptOr_some L_p2 _ _
  · simp only [if_neg ht1]
    change Fin.foldl L_p2 _ (if 2 ≤ idx.t_ins ∧ idx.entryAlive (idx.t_ins - 2) = true ∧
        b_thr < radialCorrelation o p_v (idx.entryPt (idx.t_ins - 2)) then
        some (idx.entryHandle (idx.t_ins - 2)) else none) = _
    by_cases ht2 : 2 ≤ idx.t_ins ∧ idx.entryAlive (idx.t_ins - 2) = true ∧
        b_thr < radialCorrelation o p_v (idx.entryPt (idx.t_ins - 2))
    · simp only [if_pos ht2]
      exact foldl_qryOptOr_some L_p2 _ _
    · simp only [if_neg ht2]
      change Fin.foldl L_p2 _ none = (List.finRange L_p2).findSome? _
      rw [findSome_finRange_eq_foldl]
      congr 1
      funext acc s
      cases acc <;> rfl

private lemma outside_zero (b i : ℤ) : i < b ∨ b + 0 ≤ i := by
  rcases lt_or_ge i b with h | h
  · exact Or.inl h
  · exact Or.inr (by omega)

private lemma rfo_zero_wRead {scrW scrR tblW tblR t : ℕ} {bW bR : ℤ} {m₀ m₁ : ArithRAMMemory}
    (hfr : RadFrameOutside scrW scrR tblW bW 0 tblR bR 0 m₀ m₁) (ht : t ≠ scrW) (i : ℤ) :
    wRead m₁ t i = wRead m₀ t i :=
  hfr.1 t i ht (Or.inr (outside_zero bW i))

private lemma rfo_zero_rRead {scrW scrR tblW tblR t : ℕ} {bW bR : ℤ} {m₀ m₁ : ArithRAMMemory}
    (hfr : RadFrameOutside scrW scrR tblW bW 0 tblR bR 0 m₀ m₁) (ht : t ≠ scrR) (i : ℤ) :
    rRead m₁ t i = rRead m₀ t i :=
  hfr.2 t i ht (Or.inr (outside_zero bR i))

theorem EncH4DyadicSide.mono_pvStage {scrW scrR tblW : ℕ} {sideBaseW : ℤ}
    {tblR : ℕ} {sideBaseR : ℤ}
    {n L_p2 R ℓ M₀ d b cap_u : ℕ}
    {U : Finset ℕ} {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b} {m₀ m₁ : ArithRAMMemory}
    (henc : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀)
    (hfr : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR (d : ℤ) m₀ m₁)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) :
    EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₁ := by
  have hkW : ∀ i : ℤ, wRead m₁ tblW i = wRead m₀ tblW i := fun i =>
    hfr.1 tblW i hneW (Or.inr (outside_zero sideBaseW i))
  have hkR : ∀ i : ℤ, sideBaseR + (d : ℤ) ≤ i → rRead m₁ tblR i = rRead m₀ tblR i := fun i hi =>
    hfr.2 tblR i hneR (Or.inr (Or.inr hi))
  rcases henc with ⟨ht_le, ep_side, liveSlots, hep1, hep_r, ht_r,
    hhand, hal_le, hal_iff, hact, hpt, hslots, hcur⟩
  refine ⟨ht_le, ep_side, liveSlots, hep1,
    (hkW sideBaseW).trans hep_r, (hkW (sideBaseW + 1)).trans ht_r,
    fun eid heid => (hkW _).trans (hhand eid heid),
    fun eid heid => by rw [hkW]; exact hal_le eid heid,
    fun eid heid => by rw [hkW]; exact hal_iff eid heid,
    fun u hu => (hkW _).trans (hact u hu),
    fun eid heid c =>
      (hkR _ (sideEntryPt_bounds (L_p2 := L_p2) sideBaseR (lt_of_lt_of_le heid ht_le) c).1).trans
        (hpt eid heid c),
    fun s sl => ?_, hcur⟩
  rcases hslots s sl with ⟨htr_s, henc_s⟩
  have hbr := sideSlotBaseR_bounds (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
    sideBaseR (sideSlotIdx_lt s sl)
  exact ⟨htr_s, henc_s.mono_frame
    (hfr.mono_range
      (bW₂ := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx s sl)) (lW₂ := 0)
      (bR₂ := sideBaseR) (lR₂ := (d : ℤ))
      (Or.inl rfl) (Or.inr ⟨le_rfl, le_rfl⟩))
    hneW hneR (Or.inr (Or.inr (add_zero _).le)) (Or.inr (Or.inr (by omega)))⟩

private lemma encH4_of_rfo_zero {scrW scrR tblW tblR : ℕ} {sideBaseW sideBaseR : ℤ}
    {n L_p2 R ℓ M₀ d b cap_u : ℕ} {U : Finset ℕ}
    {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b} {m₀ m₁ : ArithRAMMemory}
    (henc : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀)
    (hfr : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m₁)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) :
    EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₁ :=
  henc.mono_pvStage
    (hfr.mono_range (bW₂ := sideBaseW) (lW₂ := 0) (bR₂ := sideBaseR) (lR₂ := (d : ℤ))
      (Or.inl rfl) (Or.inl rfl)) hneW hneR

/-! ### 2. Single-Scale Query Step & Shared Execution Context -/

def dyadicSideScaleQueryStepStmt (scrW scrR tblW tblR tblO : ℕ)
    (wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) : ArithRAMStmt :=
  let wT := wScr + 1
  let wH := wScr + 4
  let wB := wScr + 5
  let wQ := wScr + 6
  let wOff := wScr + 7
  let wSl := wScr + 8
  .ite (.intLt (.readHeap scrW (.lit wAnsOut)) (.lit 0))
    (.seq (.writeWordHeap scrW (.lit wB) (.mul (.lit 2) (.readHeap scrW (.lit wH))))
    (.seq (.writeWordHeap scrW (.lit wQ)
            (.div (.readHeap scrW (.lit wT)) (.readHeap scrW (.lit wB))))
    (.seq (.writeWordHeap scrW (.lit wOff)
            (.mod (.readHeap scrW (.lit wT)) (.readHeap scrW (.lit wB))))
    (.seq (.ite (.and (.intLe (.lit 1) (.readHeap scrW (.lit wQ)))
                      (.intLe (.readHeap scrW (.lit wH)) (.readHeap scrW (.lit wOff))))
            (.seq (.writeWordHeap scrW (.lit wSl)
                    (.mod (.sub (.readHeap scrW (.lit wQ)) (.lit 1)) (.lit 2)))
                  (dyadicSideSlotSubQueryStmt scrW scrR tblW tblR tblO
                    wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr
                    n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q A B_rat τ_q b_rat))
            .skip)
          (.ite (.intLe (.lit 2) (.readHeap scrW (.lit wQ)))
            (.seq (.writeWordHeap scrW (.lit wSl)
                    (.mod (.sub (.readHeap scrW (.lit wQ)) (.lit 2)) (.lit 2)))
                  (dyadicSideSlotSubQueryStmt scrW scrR tblW tblR tblO
                    wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr
                    n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q A B_rat τ_q b_rat))
            .skip)))))
    .skip

def dyadicSideScaleQueryStepCost (R ℓ M₀ d S_lat cap_q : ℕ) : ℕ :=
  200 + 2 * dyadicSideSlotSubQueryCost R ℓ M₀ d S_lat cap_q

section QryCtx

structure QryEnv (d TW BW TR BR scrW scrR tblW tblR tblO : ℕ)
    (wBW wBR wOffO wAns wScr rScr bW bR offO : ℤ)
    (n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q : ℕ)
    (hM₀ : 1 ≤ M₀) (A B_rat τ_d τ_q b_rat : ℚ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (U : Finset ℕ) (idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b) (m_st : ArithRAMMemory) : Prop where
  hS_lat : 2 * M_lat + 1 ≤ 2 ^ S_lat
  hpv_ne : p_v ≠ o
  hwf : H4b.DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx
  hscrW : scrW < TW
  hscrR : scrR < TR
  hneW : tblW ≠ scrW
  hneR : tblR ≠ scrR
  hneO : tblO ≠ scrR
  hwAns : 0 ≤ wAns ∧ wAns < (BW : ℤ)
  hwScr : 0 ≤ wScr ∧ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ (BW : ℤ)
  hrScr : 0 ≤ rScr ∧ rScr + dyadicSideQueryRStride d ≤ (BR : ℤ)
  hdisjBW : wBW < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wBW
  hdisjBR : wBR < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wBR
  hdisjO : wOffO < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wOffO
  hdisjAns : wAns < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wAns
  hneAns : wAns ≠ wBW ∧ wAns ≠ wBR ∧ wAns ≠ wOffO
  ho_st : ∀ c : Fin d, rRead m_st tblO (offO + (c.val : ℤ)) = euclideanCoord o c
  hpv_st : ∀ c : Fin d, rRead m_st tblR (bR + (c.val : ℤ)) = euclideanCoord p_v c
  henc_st : EncH4DyadicSide tblW bW tblR bR n L_p2 R ℓ M₀ d b cap_u U idx m_st

variable {d TW BW TR BR scrW scrR tblW tblR tblO : ℕ}
  {wBW wBR wOffO wAns wScr rScr bW bR offO : ℤ}
  {n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q : ℕ}
  {hM₀ : 1 ≤ M₀} {A B_rat τ_d τ_q b_rat : ℚ}
  {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o p_v : EuclideanSpace ℝ (Fin d)}
  {U : Finset ℕ} {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b} {m_st : ArithRAMMemory}

structure QrySt
    (_E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO wBW wBR wOffO wAns wScr rScr bW bR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st)
    (m : ArithRAMMemory) : Prop where
  hfp : InFootprint TW BW TR BR m
  hbW : wRead m scrW wBW = bW
  hbR : wRead m scrW wBR = bR
  hoffO : wRead m scrW wOffO = offO
  hfr : RadFrameOutside scrW scrR tblW bW 0 tblR bR 0 m_st m

lemma QrySt.ho
    (E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO wBW wBR wOffO wAns wScr rScr bW bR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st)
    {m : ArithRAMMemory} (hst : QrySt E m) (c : Fin d) :
    rRead m tblO (offO + (c.val : ℤ)) = euclideanCoord o c :=
  (rfo_zero_rRead hst.hfr E.hneO _).trans (E.ho_st c)

lemma QrySt.hpv
    (E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO wBW wBR wOffO wAns wScr rScr bW bR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st)
    {m : ArithRAMMemory} (hst : QrySt E m) (c : Fin d) :
    rRead m tblR (bR + (c.val : ℤ)) = euclideanCoord p_v c :=
  (rfo_zero_rRead hst.hfr E.hneR _).trans (E.hpv_st c)

lemma QrySt.enc
    (E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO wBW wBR wOffO wAns wScr rScr bW bR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st)
    {m : ArithRAMMemory} (hst : QrySt E m) :
    EncH4DyadicSide tblW bW tblR bR n L_p2 R ℓ M₀ d b cap_u U idx m :=
  encH4_of_rfo_zero E.henc_st hst.hfr E.hneW E.hneR

lemma QrySt.wScrWrite
    (E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO wBW wBR wOffO wAns wScr rScr bW bR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st)
    {m : ArithRAMMemory} (hst : QrySt E m) (j v : ℤ)
    (hlo : wScr ≤ j) (hhi : j < wScr + dyadicSideQueryWStride ℓ M₀ cap_q) :
    QrySt E (wWrite m scrW j v) := by
  have hw1 := E.hwScr.1
  have hw2 := E.hwScr.2
  exact ⟨InFootprint.wWrite hst.hfp E.hscrW (by omega) (by omega),
    (qry_wne (by rcases E.hdisjBW with h | h <;> omega)).trans hst.hbW,
    (qry_wne (by rcases E.hdisjBR with h | h <;> omega)).trans hst.hbR,
    (qry_wne (by rcases E.hdisjO with h | h <;> omega)).trans hst.hoffO,
    hst.hfr.trans (RadFrameOutside.wWrite_scr scrW scrR tblW bW 0 tblR bR 0 m j v)⟩

lemma QrySt.stepK
    (E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO wBW wBR wOffO wAns wScr rScr bW bR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st)
    {m m' : ArithRAMMemory} (hst : QrySt E m) {k : ℤ} (hk : 0 ≤ k)
    (hfp' : InFootprint TW BW TR BR m')
    (hfr' : RadFrameOutside scrW scrR tblW bW 0 tblR bR 0 m m')
    (hkW : ∀ w, w ≠ wAns → (w < wScr + k ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
      wRead m' scrW w = wRead m scrW w) :
    QrySt E m' := by
  have wid : ∀ {w}, w < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w →
      w < wScr + k ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w := by
    intro w hw; rcases hw with h | h; exact Or.inl (by omega); exact Or.inr h
  exact ⟨hfp',
    (hkW wBW E.hneAns.1.symm (wid E.hdisjBW)).trans hst.hbW,
    (hkW wBR E.hneAns.2.1.symm (wid E.hdisjBR)).trans hst.hbR,
    (hkW wOffO E.hneAns.2.2.symm (wid E.hdisjO)).trans hst.hoffO,
    hst.hfr.trans hfr'⟩

theorem qry_exec_tailStep (inp : ArithRAMInput d)
    (E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO wBW wBR wOffO wAns wScr rScr bW bR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st)
    {m₀ : ArithRAMMemory} (hst : QrySt E m₀) (delta : ℕ) (hdel : 1 ≤ delta) (prevAns : Option ℕ)
    (hep_r : wRead m₀ scrW wScr = wRead m_st tblW bW)
    (ht_r : wRead m₀ scrW (wScr + 1) = (idx.t_ins : ℤ))
    (hepB_r : wRead m₀ scrW (wScr + 2) = sideEntryPtOff d bR)
    (hans₀ : wRead m₀ scrW wAns = optNatToInt prevAns) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (dyadicSideTailCheckStmt scrW scrR tblW tblO tblR
        wBW wBR wOffO wAns wScr rScr L_p2 d delta b_rat) m₀ m₁ (dyadicSideTailCheckCost d) ∧
      QrySt E m₁ ∧
      wRead m₁ scrW wScr = wRead m_st tblW bW ∧
      wRead m₁ scrW (wScr + 1) = (idx.t_ins : ℤ) ∧
      wRead m₁ scrW (wScr + 2) = sideEntryPtOff d bR ∧
      wRead m₁ scrW wAns = optNatToInt (qryOptOr prevAns (dyadicSideTailOpt (b_rat : ℝ) o p_v idx delta)) ∧
      (∀ w, w ≠ wAns → (w < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) := by
  have hge44 := dyadicSideQueryWStride_ge_44 ℓ M₀ cap_q
  have hdisjA := E.hdisjAns
  obtain ⟨m₁, hd, hfp₁, hans₁, hkW, hfr⟩ :=
    exec_dyadicSideTailCheckStmt (cap_q := cap_q) inp wBW wBR wOffO wAns wScr rScr bW bR offO
      hM₀ hdel b_rat E.hpv_ne E.hwf prevAns
      hst.hfp E.hscrW E.hscrR E.hneW E.hneR E.hneO E.hwAns E.hwScr E.hrScr
      E.hdisjBW E.hdisjBR E.hdisjO E.hdisjAns hst.hbW hst.hbR hst.hoffO
      (hep_r.trans (rfo_zero_wRead hst.hfr E.hneW bW).symm) ht_r hepB_r hans₀
      (hst.ho E) (hst.hpv E) (hst.enc E)
  have hkW' : ∀ w, w ≠ wAns → (w < wScr + 0 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
      wRead m₁ scrW w = wRead m₀ scrW w := by
    intro w hne hw
    exact hkW w hne (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr (by omega))
  refine ⟨m₁, hd, hst.stepK E le_rfl hfp₁ hfr hkW',
    (hkW wScr (by rcases hdisjA with h | h <;> omega) (Or.inl (by omega))).trans hep_r,
    (hkW (wScr + 1) (by rcases hdisjA with h | h <;> omega) (Or.inl (by omega))).trans ht_r,
    (hkW (wScr + 2) (by rcases hdisjA with h | h <;> omega) (Or.inl (by omega))).trans hepB_r,
    by cases prevAns <;> exact hans₁,
    fun w hne hw => hkW' w hne (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr h)⟩

private theorem exec_condSlotSubQuery (inp : ArithRAMInput d)
    (E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO wBW wBR wOffO wAns wScr rScr bW bR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st)
    {m₀ : ArithRAMMemory} (hst : QrySt E m₀)
    (condE : ArithCondExpr) (slE : IntExpr) (condP : Prop) [Decidable condP]
    (s : Fin L_p2) (sl : Fin 2) (prevAns : Option ℕ)
    (hc_eval : cValAt 0 inp m₀ condE = decide condP)
    (hc_ops : condExprOps condE ≤ 20)
    (hsl_ops : intExprOps (.lit (wScr + 8)) + intExprOps slE + 1 ≤ 25)
    (hsl_val : condP → iValAt 0 inp m₀ slE = (sl.val : ℤ))
    (hblk : ∀ ls : Fin L_p2 → Fin 2 → LiveSlot R ℓ M₀ d,
      ((1 ≤ idx.t_ins / (2 * 2 ^ s.val) → 2 ^ s.val ≤ idx.t_ins % (2 * 2 ^ s.val) →
          0 ≤ (ls s (H4b.mod2Fin (idx.t_ins / (2 * 2 ^ s.val) - 1))).blkId) ∧
        (2 ≤ idx.t_ins / (2 * 2 ^ s.val) →
          0 ≤ (ls s (H4b.mod2Fin (idx.t_ins / (2 * 2 ^ s.val) - 2))).blkId)) →
      condP → 0 ≤ (ls s sl).blkId)
    (hepB_r : wRead m₀ scrW (wScr + 2) = sideEntryPtOff d bR)
    (hs_r : wRead m₀ scrW (wScr + 3) = (s.val : ℤ))
    (hans₀ : wRead m₀ scrW wAns = optNatToInt prevAns) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (.ite condE
          (.seq (.writeWordHeap scrW (.lit (wScr + 8)) slE)
                (dyadicSideSlotSubQueryStmt scrW scrR tblW tblR tblO
                  wBW wBR wOffO wAns wScr rScr
                  n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q A B_rat τ_q b_rat))
          .skip)
        m₀ m₁ (50 + dyadicSideSlotSubQueryCost R ℓ M₀ d S_lat cap_q) ∧
      QrySt E m₁ ∧
      wRead m₁ scrW wAns = optNatToInt (qryOptOr prevAns
        (if condP then
          ((idx.slots s sl).query hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q
            idx.entryPt o p_v idx.entryAlive).map idx.entryHandle
        else none)) ∧
      (∀ w, w ≠ wAns → (w < wScr + 8 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) := by
  have hge44 := dyadicSideQueryWStride_ge_44 ℓ M₀ cap_q
  have hdisjA := E.hdisjAns
  by_cases hc : condP
  · have hc_t : cValAt 0 inp m₀ condE = true := hc_eval.trans (decide_eq_true hc)
    have hd_sl := qry_det_wLit inp m₀ scrW (wScr + 8) slE (sl.val : ℤ) 25 (hsl_val hc) hsl_ops
    have hst_sl := hst.wScrWrite E (wScr + 8) (sl.val : ℤ) (by omega) (by omega)
    rcases hst_sl.enc E with ⟨_, _, ls, _, _, _, hhand, _, _, _, hpt, hslots, hcur⟩
    obtain ⟨m₁, hd_q, hfp₁, hans₁, hkW₁, hfr_q⟩ :=
      exec_dyadicSideSlotSubQueryStmt (cap_q := cap_q) inp
        wBW wBR wOffO wAns wScr rScr bW bR offO
        hM₀ E.hS_lat τ_q b_rat E.hpv_ne E.hwf s sl prevAns
        hst_sl.hfp E.hscrW E.hscrR E.hneW E.hneR E.hneO E.hwAns E.hwScr E.hrScr
        E.hdisjBW E.hdisjBR E.hdisjO E.hdisjAns
        hst_sl.hbW hst_sl.hbR hst_sl.hoffO
        ((qry_wne (by omega)).trans hepB_r) ((qry_wne (by omega)).trans hs_r)
        (wRead_wWrite_self _ _ _ _) ((qry_wne (by rcases hdisjA with h | h <;> omega)).trans hans₀)
        (hst_sl.ho E) (hst_sl.hpv E)
        (hblk ls ⟨(hcur s).2.1, (hcur s).2.2⟩ hc) (hslots s sl).1 (hslots s sl).2 hhand hpt
    refine ⟨m₁,
      (DetExecAt.ite_true (C_c := 20) hc_t hc_ops (hd_sl.seq hd_q)).mono_cost (by omega),
      hst_sl.stepK E (by omega) hfp₁ hfr_q hkW₁,
      by rw [if_pos hc]; cases prevAns <;> exact hans₁,
      fun w hw_ne hw_out => by
        have hw9 : w < wScr + 9 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w := by
          rcases hw_out with h | h
          · exact Or.inl (by omega)
          · exact Or.inr h
        rw [hkW₁ w hw_ne hw9, qry_wne (by rcases hw_out with h | h <;> omega)]⟩
  · have hc_f : cValAt 0 inp m₀ condE = false := hc_eval.trans (decide_eq_false hc)
    exact ⟨m₀,
      (DetExecAt.ite_false (C_c := 20) hc_f hc_ops (DetExecAt.skip 0 inp m₀)).mono_cost (by omega),
      hst, by rw [if_neg hc]; cases prevAns <;> exact hans₀, fun _ _ _ => rfl⟩

theorem qry_exec_scaleQueryStepStmt (inp : ArithRAMInput d)
    (E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO wBW wBR wOffO wAns wScr rScr bW bR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st)
    {m₀ : ArithRAMMemory} (hst : QrySt E m₀) (s : Fin L_p2) (prevAns : Option ℕ)
    (ht_r : wRead m₀ scrW (wScr + 1) = (idx.t_ins : ℤ))
    (hepB_r : wRead m₀ scrW (wScr + 2) = sideEntryPtOff d bR)
    (hs_r : wRead m₀ scrW (wScr + 3) = (s.val : ℤ))
    (hh_r : wRead m₀ scrW (wScr + 4) = ((2 ^ s.val : ℕ) : ℤ))
    (hans₀ : wRead m₀ scrW wAns = optNatToInt prevAns) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (dyadicSideScaleQueryStepStmt scrW scrR tblW tblR tblO
          wBW wBR wOffO wAns wScr rScr
          n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q A B_rat τ_q b_rat)
        m₀ m₁ (dyadicSideScaleQueryStepCost R ℓ M₀ d S_lat cap_q) ∧
      QrySt E m₁ ∧
      wRead m₁ scrW wAns = optNatToInt
        (qryOptOr prevAns (dyadicSideScaleOpt hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q o p_v idx s)) ∧
      (∀ w, w ≠ wAns → (w < wScr + 5 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) := by
  classical
  have hge44 := dyadicSideQueryWStride_ge_44 ℓ M₀ cap_q
  have hdisjA := E.hdisjAns
  cases prevAns with
  | some w_prev =>
      have hc_ans : cValAt 0 inp m₀ (.intLt (.readHeap scrW (.lit wAns)) (.lit 0)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (wRead m₀ scrW wAns < 0) = false
        rw [hans₀]; simp [optNatToInt]
      exact ⟨m₀,
        (DetExecAt.ite_false (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
          (DetExecAt.skip 0 inp m₀)).mono_cost (by unfold dyadicSideScaleQueryStepCost; omega),
        hst, hans₀, fun _ _ _ => rfl⟩
  | none =>
      have hc_ans : cValAt 0 inp m₀ (.intLt (.readHeap scrW (.lit wAns)) (.lit 0)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (wRead m₀ scrW wAns < 0) = true
        rw [hans₀]; simp [optNatToInt]
      let H : ℕ := 2 ^ s.val
      let B : ℕ := 2 * H
      let q : ℕ := idx.t_ins / B
      let off : ℕ := idx.t_ins % B
      let m1 := wWrite m₀ scrW (wScr + 5) (B : ℤ)
      let m2 := wWrite m1 scrW (wScr + 6) (q : ℤ)
      let m3 := wWrite m2 scrW (wScr + 7) (off : ℤ)
      have hd1 := qry_det_wLit inp m₀ scrW (wScr + 5)
        (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 4)))) (B : ℤ) 20
        (by change 2 * wRead m₀ scrW (wScr + 4) = (B : ℤ); rw [hh_r]; dsimp [B, H])
        (by dsimp [intExprOps]; omega)
      have hd2 := qry_det_wLit inp m1 scrW (wScr + 6)
        (.div (.readHeap scrW (.lit (wScr + 1))) (.readHeap scrW (.lit (wScr + 5)))) (q : ℤ) 20
        (by change wRead m1 scrW (wScr + 1) / wRead m1 scrW (wScr + 5) = (q : ℤ)
            rw [qry_wne (by omega), ht_r, wRead_wWrite_self]
            exact (Int.natCast_ediv idx.t_ins B).symm)
        (by dsimp [intExprOps]; omega)
      have hd3 := qry_det_wLit inp m2 scrW (wScr + 7)
        (.mod (.readHeap scrW (.lit (wScr + 1))) (.readHeap scrW (.lit (wScr + 5)))) (off : ℤ) 20
        (by change wRead m2 scrW (wScr + 1) % wRead m2 scrW (wScr + 5) = (off : ℤ)
            rw [qry_wne (by omega), qry_wne (by omega), ht_r, qry_wne (by omega), wRead_wWrite_self]
            exact (Int.natCast_emod idx.t_ins B).symm)
        (by dsimp [intExprOps]; omega)
      have hst3 : QrySt E m3 :=
        ((hst.wScrWrite E (wScr + 5) (B : ℤ) (by omega) (by omega)).wScrWrite
          E (wScr + 6) (q : ℤ) (by omega) (by omega)).wScrWrite E (wScr + 7) (off : ℤ) (by omega) (by omega)
      have hkW03 : ∀ w, (w < wScr + 5 ∨ wScr + 8 ≤ w) → wRead m3 scrW w = wRead m₀ scrW w := by
        intro w _; rw [qry_wne (by omega), qry_wne (by omega), qry_wne (by omega)]
      have hq3 : wRead m3 scrW (wScr + 6) = (q : ℤ) := by
        rw [qry_wne (by omega)]; exact wRead_wWrite_self _ _ _ _
      have hoff3 : wRead m3 scrW (wScr + 7) = (off : ℤ) := wRead_wWrite_self _ _ _ _
      have hh3 : wRead m3 scrW (wScr + 4) = (H : ℤ) := (hkW03 _ (Or.inl (by omega))).trans hh_r
      let sl₁ : Fin 2 := H4b.mod2Fin (q - 1)
      let sl₂ : Fin 2 := H4b.mod2Fin (q - 2)
      obtain ⟨m4, hd_r1, hst4, hans4, hkW34⟩ :=
        exec_condSlotSubQuery inp E hst3
          (.and (.intLe (.lit 1) (.readHeap scrW (.lit (wScr + 6))))
                (.intLe (.readHeap scrW (.lit (wScr + 4))) (.readHeap scrW (.lit (wScr + 7)))))
          (.mod (.sub (.readHeap scrW (.lit (wScr + 6))) (.lit 1)) (.lit 2))
          (1 ≤ q ∧ H ≤ off) s sl₁ none
          (by simp only [cValAt, evalArithCond, evalIntExpr]
              change (decide (1 ≤ wRead m3 scrW (wScr + 6)) &&
                      decide (wRead m3 scrW (wScr + 4) ≤ wRead m3 scrW (wScr + 7))) =
                     decide (1 ≤ q ∧ H ≤ off)
              rw [hq3, hh3, hoff3]
              by_cases hc : 1 ≤ q ∧ H ≤ off
              · rw [decide_eq_true hc, Bool.and_eq_true, decide_eq_true_eq, decide_eq_true_eq]
                exact ⟨by exact_mod_cast hc.1, by exact_mod_cast hc.2⟩
              · rw [decide_eq_false hc]
                by_contra htr
                have ht := Bool.eq_true_of_not_eq_false htr
                simp only [Bool.and_eq_true, decide_eq_true_eq] at ht
                exact hc ⟨by omega, by omega⟩)
          (by dsimp [condExprOps, intExprOps]; omega)
          (by dsimp [intExprOps]; omega)
          (fun hc1 => by
            change (wRead m3 scrW (wScr + 6) - 1) % 2 = (sl₁.val : ℤ)
            have hq1 := hc1.1
            rw [hq3]; dsimp [sl₁, H4b.mod2Fin]; omega)
          (fun _ h hc1 => h.1 hc1.1 hc1.2)
          ((hkW03 _ (Or.inl (by omega))).trans hepB_r)
          ((hkW03 _ (Or.inl (by omega))).trans hs_r)
          ((hkW03 _ (by rcases hdisjA with h | h; exact Or.inl (by omega); exact Or.inr (by omega))).trans hans₀)
      have hkW04 : ∀ w, w ≠ wAns →
          (w < wScr + 5 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
          wRead m4 scrW w = wRead m₀ scrW w := by
        intro w hw_ne hw_out
        have hw8 : w < wScr + 8 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w := by
          rcases hw_out with h | h
          · exact Or.inl (by omega)
          · exact Or.inr h
        have hw58 : w < wScr + 5 ∨ wScr + 8 ≤ w := by
          rcases hw_out with h | h
          · exact Or.inl h
          · exact Or.inr (by omega)
        rw [hkW34 w hw_ne hw8, hkW03 w hw58]
      have hq4 : wRead m4 scrW (wScr + 6) = (q : ℤ) :=
        (hkW34 _ (by rcases hdisjA with h | h <;> omega) (Or.inl (by omega))).trans hq3
      let r1 : Option ℕ :=
        if 1 ≤ q ∧ H ≤ off then
          ((idx.slots s sl₁).query hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q
            idx.entryPt o p_v idx.entryAlive).map idx.entryHandle
        else none
      obtain ⟨m5, hd_r2, hst5, hans5, hkW45⟩ :=
        exec_condSlotSubQuery inp E hst4
          (.intLe (.lit 2) (.readHeap scrW (.lit (wScr + 6))))
          (.mod (.sub (.readHeap scrW (.lit (wScr + 6))) (.lit 2)) (.lit 2))
          (2 ≤ q) s sl₂ r1
          (by simp only [cValAt, evalArithCond, evalIntExpr]
              change decide (2 ≤ wRead m4 scrW (wScr + 6)) = decide (2 ≤ q)
              rw [hq4]
              by_cases hc : 2 ≤ q
              · rw [decide_eq_true hc, decide_eq_true_eq]; exact_mod_cast hc
              · rw [decide_eq_false hc, decide_eq_false_iff_not]; omega)
          (by dsimp [condExprOps, intExprOps]; omega)
          (by dsimp [intExprOps]; omega)
          (fun hc2 => by
            change (wRead m4 scrW (wScr + 6) - 2) % 2 = (sl₂.val : ℤ)
            rw [hq4]; dsimp [sl₂, H4b.mod2Fin]; omega)
          (fun _ h hc2 => h.2 hc2)
          ((hkW04 _ (by rcases hdisjA with h | h <;> omega) (Or.inl (by omega))).trans hepB_r)
          ((hkW04 _ (by rcases hdisjA with h | h <;> omega) (Or.inl (by omega))).trans hs_r)
          hans4
      refine ⟨m5,
        (DetExecAt.ite_true (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
          (hd1.seq (hd2.seq (hd3.seq (hd_r1.seq hd_r2))))).mono_cost
          (by unfold dyadicSideScaleQueryStepCost; omega),
        hst5, hans5,
        fun w hw_ne hw_out => by
          have hw8 : w < wScr + 8 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w := by
            rcases hw_out with h | h
            · exact Or.inl (by omega)
            · exact Or.inr h
          rw [hkW45 w hw_ne hw8, hkW04 w hw_ne hw_out]⟩

end QryCtx

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
