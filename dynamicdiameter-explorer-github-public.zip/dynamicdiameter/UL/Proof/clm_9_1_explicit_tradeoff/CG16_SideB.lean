import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideB3

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot slotWStride slotRStride slotWStride_ge_four
  seedCoordCount seedBitCount slotInsWStride slotInsRStride
  evalCopyTuplesCost liveSlotInsertCopyCost liveSlotInsertRecordCost)

private theorem wNe (m : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℤ)
    (h : t₁ ≠ t₂ ∨ i₁ ≠ i₂) : wRead (wWrite m t₂ i₂ v) t₁ i₁ = wRead m t₁ i₁ :=
  wRead_wWrite_of_ne m v h

private theorem rws (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) (idx val : ℤ) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (wWrite m scrW idx val) :=
  RadFrameOutside.wWrite_scr scrW scrR tblW baseW lenW tblR baseR lenR m idx val

private theorem rtz {scrW scrR tW1 tW2 : ℕ} {bW1 bW2 lW2 : ℤ}
    {tR1 tR2 : ℕ} {bR1 bR2 lR2 : ℤ} {m₀ m₁ : ArithRAMMemory}
    (h : RadFrameOutside scrW scrR tW1 bW1 0 tR1 bR1 0 m₀ m₁) :
    RadFrameOutside scrW scrR tW2 bW2 lW2 tR2 bR2 lR2 m₀ m₁ :=
  ⟨fun t i hs _ => h.1 t i hs (by rcases lt_or_ge i bW1 with h1 | h1; exact Or.inr (Or.inl h1); exact Or.inr (Or.inr (by omega))),
   fun t i hs _ => h.2 t i hs (by rcases lt_or_ge i bR1 with h1 | h1; exact Or.inr (Or.inl h1); exact Or.inr (Or.inr (by omega)))⟩

/-! ### 1. `dyadicSideInsertStmt` & `exec_h4_dyadicSideInsertStmt` -/

noncomputable def dyadicSideInsertStmt (scrW scrR tblW tblR tblO tblPt coinTbl : ℕ)
    (wSideBaseW wSideBaseR wOffO wOffPt wHNew wSeedBaseOff wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d b T p_coord cap_u : ℕ) (A B_rat τ_d : ℚ) : ArithRAMStmt :=
  .seq (dyadicSideInsertHeaderStmt scrW tblW tblPt tblR wSideBaseW wSideBaseR wOffPt wHNew wScr n L_p2 d)
       (.repeatN (.lit (L_p2 : ℤ))
         (dyadicSideInsertScaleStepStmt scrW scrR tblW tblR tblO coinTbl
           wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d))

def dyadicSideInsertCost (L_p2 R ℓ M₀ d b T p_coord cap_u : ℕ) : ℕ :=
  320 + 35 * d + L_p2 * dyadicSideInsertScaleStepCost R ℓ M₀ d b T p_coord cap_u

theorem zeroRand_dyadicSideInsertStmt (scrW scrR tblW tblR tblO tblPt coinTbl : ℕ)
    (wSideBaseW wSideBaseR wOffO wOffPt wHNew wSeedBaseOff wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d b T p_coord cap_u : ℕ) (A B_rat τ_d : ℚ) :
    H3a.ZeroRandStmt (dyadicSideInsertStmt scrW scrR tblW tblR tblO tblPt coinTbl
      wSideBaseW wSideBaseR wOffO wOffPt wHNew wSeedBaseOff wScr rScr
      n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d) :=
  .seq (zeroRand_dyadicSideInsertHeaderStmt _ _ _ _ _ _ _ _ _ _ _ _)
       (.repeatN (zeroRand_dyadicSideInsertScaleStepStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _))

theorem exec_h4_dyadicSideInsertStmt {d TW BW TR BR scrW scrR tblW tblR tblO tblPt coinTbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wOffO wOffPt wHNew wSeedBaseOff wScr rScr
      sideBaseW sideBaseR offO offPt seedBaseOff : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord cap_u : ℕ}
    (hn : 1 ≤ n) (hM₀ : 1 ≤ M₀)
    (A B_rat τ_d : ℚ)
    (o pt : EuclideanSpace ℝ (Fin d))
    {U : Finset ℕ} {h_new : ℕ}
    (hmod_disj : ∀ u ∈ U, u % n ≠ h_new % n)
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b}
    (ht_lt : idx.t_ins < 2 ^ L_p2)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR) (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneO : tblO ≠ scrR) (hneCoinScr : coinTbl ≠ scrW)
    (hsideW : 0 ≤ sideBaseW ∧ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ (BW : ℤ))
    (hsideR : 0 ≤ sideBaseR ∧ sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ (BR : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + dyadicSideInsertRStride d ≤ (BR : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSideBaseW)
    (hdisjBR : wSideBaseR < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSideBaseR)
    (hdisjO : wOffO < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wOffO)
    (hdisjPt : wOffPt < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wOffPt)
    (hdisjH : wHNew < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wHNew)
    (hdisjSeed : wSeedBaseOff < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSeedBaseOff)
    (hdisjCoinW : coinTbl ≠ tblW ∨
      seedBaseOff + ((sideSeedStride L_p2 R ℓ M₀ d b : ℕ) : ℤ) ≤ sideBaseW ∨
      sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ seedBaseOff)
    (hdisjPt_R : tblPt ≠ tblR ∨
      offPt + (d : ℤ) ≤ sideEntryPtOff d sideBaseR ∨
      sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ offPt)
    (hdisjO_R : tblO ≠ tblR ∨
      offO + (d : ℤ) ≤ sideEntryPtOff d sideBaseR ∨
      sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ offO)
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hbR : wRead m₀ scrW wSideBaseR = sideBaseR)
    (hoffO : wRead m₀ scrW wOffO = offO)
    (hoffPt : wRead m₀ scrW wOffPt = offPt)
    (hhNew : wRead m₀ scrW wHNew = (h_new : ℤ))
    (hseedOff : wRead m₀ scrW wSeedBaseOff = seedBaseOff)
    (ho : ∀ c : Fin d, rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpt_in : ∀ c : Fin d, rRead m₀ tblPt (offPt + (c.val : ℤ)) = euclideanCoord pt c)
    (hseed₀ : EncSideStepSeed coinTbl seedBaseOff ω_step m₀)
    (henc₀ : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (dyadicSideInsertStmt scrW scrR tblW tblR tblO tblPt coinTbl
          wSideBaseW wSideBaseR wOffO wOffPt wHNew wSeedBaseOff wScr rScr
          n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d)
        m₀ m₁ (dyadicSideInsertCost L_p2 R ℓ M₀ d b T p_coord cap_u) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u
        (Insert.insert h_new U)
        (idx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o pt h_new ω_step) m₁ ∧
      (∀ w, (w < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) ∧
      (∀ r, (r < rScr ∨ rScr + dyadicSideInsertRStride d ≤ r) →
        rRead m₁ scrR r = rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR
        tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
        tblR (sideBaseR + (d : ℤ)) (dyadicSideRStride L_p2 R ℓ M₀ d - (d : ℤ)) m₀ m₁ := by
  classical
  have hw_ge := dyadicSideInsertWStride_ge_44 ℓ M₀ cap_u
  have hs_ge := slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2)
  have hr_nn := slotRStride_nonneg R ℓ M₀ d
  have hhdr_end := dyadicSideWStride_ge_hdrEnd n L_p2 R ℓ M₀ cap_u
  have hent_end := dyadicSideRStride_ge_entryEnd L_p2 R ℓ M₀ d
  let t := idx.t_ins
  let B_max := 2 ^ L_p2
  let idx' := idx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o pt h_new ω_step
  let hdrLen : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  let dstPt : ℤ := sideEntryPtOff d sideBaseR + (t : ℤ) * (d : ℤ)
  have hdst_lo : sideBaseR + (d : ℤ) ≤ dstPt := by
    dsimp only [dstPt, sideEntryPtOff]
    have h0 : (0 : ℤ) ≤ (t : ℤ) * (d : ℤ) := mul_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _)
    linarith
  have hdst_hi : dstPt + (d : ℤ) ≤ sideBaseR + (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ) := by
    have hmul : (t + 1) * d ≤ (2 ^ L_p2) * d := Nat.mul_le_mul_right d ht_lt
    have hmulZ : (((t + 1) * d : ℕ) : ℤ) ≤ (((2 ^ L_p2) * d : ℕ) : ℤ) := by exact_mod_cast hmul
    have hlin : (t : ℤ) * (d : ℤ) + (d : ℤ) = (((t + 1) * d : ℕ) : ℤ) := by push_cast; ring
    dsimp only [dstPt, sideEntryPtOff]; linarith
  rcases henc₀ with ⟨_, ep₀, liveSlots₀, hep1, hep0_r, ht0_r,
    hhand0, hal_le0, hal_iff0, hact0, hpt0, hslots0, hcur0⟩
  obtain ⟨mA, hd_hdr, hfpA, hep_A, ht_A, hs_A, hh_A, hmA_ep, hmA_t,
    hmA_hand, hmA_al_le, hmA_al_iff, hmA_act, hmA_pt, hmA_o, hmA_seed,
    hmA_slots, hkW0A, hkR0A, hfr0A⟩ :=
    exec_dyadicSideInsertHeaderStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
      inp wSideBaseW wSideBaseR wOffPt wHNew wScr rScr sideBaseW sideBaseR offO offPt seedBaseOff
      hn hM₀ A B_rat τ_d o pt hmod_disj ω_step idx ht_lt liveSlots₀
      hfp₀ hscrW htblW htblR hneW hneR hneO hneCoinScr
      hsideW hsideR hwScr hdisjBW hdisjBR hdisjPt hdisjH hdisjCoinW hdisjPt_R hdisjO_R
      hbW hbR hoffPt hhNew hep0_r ht0_r hhand0 hal_le0 hal_iff0 hact0 hpt0 hslots0 ho hpt_in hseed₀
  let sBase0 := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW 0
  let rBase0 := sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR 0
  let sStr := slotWStride R ℓ M₀ cap_u B_max
  let rStr := slotRStride R ℓ M₀ d
  have hs_sStr : 4 ≤ sStr := slotWStride_ge_four R ℓ M₀ cap_u B_max
  have hs0_eq : sBase0 = sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ) := by
    simp [sBase0, sideSlotBaseW]
  have hr0_eq : rBase0 = sideBaseR + (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ) := by
    simp [rBase0, sideSlotBaseR]
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    InFootprint TW BW TR BR m ∧
    wRead m scrW wScr = (ep₀ : ℤ) ∧
    wRead m scrW (wScr + 1) = (t : ℤ) ∧
    wRead m scrW (wScr + 4) = (k : ℤ) ∧
    wRead m scrW (wScr + 5) = ((2 ^ k : ℕ) : ℤ) ∧
    (∀ w, (w < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ w) →
      wRead m scrW w = wRead m₀ scrW w) ∧
    (∀ r, (r < rScr ∨ rScr + dyadicSideInsertRStride d ≤ r) →
      rRead m scrR r = rRead m₀ scrR r) ∧
    RadFrameOutside scrW scrR tblW sBase0 (((2 * k : ℕ) : ℤ) * sStr)
      tblR rBase0 (((2 * k : ℕ) : ℤ) * rStr) mA m ∧
    ∃ liveSlots : Fin L_p2 → Fin 2 → LiveSlot R ℓ M₀ d,
      (∀ s : Fin L_p2, s.val < k →
        (∀ sl : Fin 2,
          LiveSlotTrackedH4 cap_u B_max (t + 1) idx'.entryAlive (idx'.slots s sl) (liveSlots s sl) ∧
          EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx s sl))
            tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx s sl))
            R ℓ M₀ d cap_u B_max (liveSlots s sl) m) ∧
        (let H := 2 ^ s.val
         let B := 2 * H
         let q' := (t + 1) / B
         let off' := (t + 1) % B
         (1 ≤ q' → 1 ≤ off' → off' < H →
           (liveSlots s (H4b.mod2Fin (q' - 1))).blkId = (((q' - 1) * B : ℕ) : ℤ) ∧
           (liveSlots s (H4b.mod2Fin (q' - 1))).builtCnt = 2 * off') ∧
         (1 ≤ q' → H ≤ off' → 0 ≤ (liveSlots s (H4b.mod2Fin (q' - 1))).blkId) ∧
         (2 ≤ q' → 0 ≤ (liveSlots s (H4b.mod2Fin (q' - 2))).blkId))) ∧
      (∀ s : Fin L_p2, k ≤ s.val →
        liveSlots s = liveSlots₀ s ∧
        ∀ sl : Fin 2,
          EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx s sl))
            tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx s sl))
            R ℓ M₀ d cap_u B_max (liveSlots₀ s sl) m)
  have hInv0 : Inv 0 mA :=
    ⟨hfpA, hep_A, ht_A, hs_A, hh_A, hkW0A, hkR0A,
      by simp only [Nat.mul_zero, Nat.cast_zero, zero_mul]
         exact RadFrameOutside.refl scrW scrR tblW sBase0 0 tblR rBase0 0 mA,
      liveSlots₀, fun _ h => by omega, fun s _ => ⟨rfl, fun sl => (hmA_slots s sl).2⟩⟩
  let stepBody := dyadicSideInsertScaleStepStmt scrW scrR tblW tblR tblO coinTbl
    wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d
  let C_step := dyadicSideInsertScaleStepCost R ℓ M₀ d b T p_coord cap_u
  obtain ⟨m_end, hInvEnd, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (L_p2 : ℤ)) stepBody L_p2 5 C_step
    Inv hInv0 rfl (by dsimp [intExprOps]; omega) (fun k hk m hIm => by
      rcases hIm with ⟨hfp_m, hep_m, ht_m, hs_m, hh_m, hkW_m, hkR_m, hfr_m, liveSlots_m, hdone_m, htodo_m⟩
      let sFin : Fin L_p2 := ⟨k, hk⟩
      have h2k_hiW : sBase0 + ((2 * k : ℕ) : ℤ) * sStr ≤ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u := by
        have hm : ((2 * k : ℕ) : ℤ) * sStr ≤ ((2 * L_p2 : ℕ) : ℤ) * sStr :=
          mul_le_mul_of_nonneg_right (by exact_mod_cast (by omega : 2 * k ≤ 2 * L_p2)) (by omega)
        rw [hs0_eq]; dsimp only [sStr, B_max]; unfold dyadicSideWStride; linarith
      have h2k_hiR : rBase0 + ((2 * k : ℕ) : ℤ) * rStr ≤ sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d := by
        have hm : ((2 * k : ℕ) : ℤ) * rStr ≤ ((2 * L_p2 : ℕ) : ℤ) * rStr :=
          mul_le_mul_of_nonneg_right (by exact_mod_cast (by omega : 2 * k ≤ 2 * L_p2)) hr_nn
        rw [hr0_eq]; dsimp only [rStr]; unfold dyadicSideRStride; linarith
      have hal_m : ∀ eid < t + 1,
          wRead m tblW (sideAliveEpOff L_p2 sideBaseW eid) = (ep₀ : ℤ) ↔
            (Function.update idx.entryAlive t true) eid = true := by
        intro eid heid
        have heidZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (lt_of_lt_of_le heid ht_lt)
        have hlt_s0 : sideAliveEpOff L_p2 sideBaseW eid < sBase0 := by
          rw [hs0_eq]; unfold sideAliveEpOff; omega
        rw [hfr_m.1 tblW _ hneW (Or.inr (Or.inl hlt_s0))]
        exact hmA_al_iff eid heid
      have ho_m : ∀ c : Fin d, rRead m tblO (offO + (c.val : ℤ)) = euclideanCoord o c := by
        intro c; have hc := c.isLt
        refine (hfr_m.2 tblO _ hneO ?_).trans (hmA_o c)
        rcases hdisjO_R with ht | h1 | h2
        · exact Or.inl ht
        · exact Or.inr (Or.inl (by rw [hr0_eq]; unfold sideEntryPtOff at h1; omega))
        · exact Or.inr (Or.inr (by have : (0 : ℤ) ≤ (c.val : ℤ) := Nat.cast_nonneg _; linarith [h2k_hiR, h2]))
      have hpt_m : ∀ eid < t, ∀ c : Fin d,
          rRead m tblR (sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
            euclideanCoord (idx.entryPt eid) c := by
        intro eid heid c
        have hb := sideEntryPt_bounds (L_p2 := L_p2) sideBaseR (lt_trans heid ht_lt) c
        have hlt_r0 : sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ) < rBase0 := by
          rw [hr0_eq]; exact hb.2
        rw [hfr_m.2 tblR _ hneR (Or.inr (Or.inl hlt_r0)), hmA_pt eid (by omega) c]
        dsimp only [idx', H4b.DyadicSideIndex.insertHandle]
        rw [Function.update_of_ne (by omega)]
      have hseed_m : EncSideStepSeed coinTbl seedBaseOff ω_step m := by
        refine hmA_seed.mono_frame hfr_m hneCoinScr ?_
        rcases hdisjCoinW with ht | h1 | h2
        · exact Or.inl ht
        · exact Or.inr (Or.inl (by rw [hs0_eq]; omega))
        · exact Or.inr (Or.inr (by linarith [h2k_hiW, h2]))
      have hdisjO_R0 : tblO ≠ tblR ∨ offO + (d : ℤ) ≤ rBase0 ∨
          sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ offO := by
        rcases hdisjO_R with ht | h1 | h2
        · exact Or.inl ht
        · exact Or.inr (Or.inl (by rw [hr0_eq]; unfold sideEntryPtOff at h1; omega))
        · exact Or.inr (Or.inr h2)
      obtain ⟨m', S_new, hd_s, hfp_s, hs_s, hh_s, hslots_s, hcur_s, hkW_s, hkR_s, hfr_s⟩ :=
        exec_dyadicSideInsertScaleStepStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
          inp wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr sideBaseW sideBaseR offO seedBaseOff
          hk hn hM₀ A B_rat τ_d o pt h_new ω_step idx ht_lt (liveSlots₀ sFin)
          hfp_m hscrW hscrR htblW htblR hneW hneR hneO hneCoinScr
          hsideW hsideR hwScr hrScr hdisjBW hdisjBR hdisjO hdisjSeed hdisjCoinW hdisjO_R0
          ((hkW_m _ hdisjBW).trans hbW) ((hkW_m _ hdisjBR).trans hbR)
          ((hkW_m _ hdisjO).trans hoffO) ((hkW_m _ hdisjSeed).trans hseedOff)
          hep_m ht_m hs_m hh_m hal_m ho_m hpt_m (hseed_m sFin)
          (fun sl => (hmA_slots sFin sl).1) ((htodo_m sFin le_rfl).2) (hcur0 sFin)
      have hscW_eq : sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (2 * k) =
          sBase0 + ((2 * k : ℕ) : ℤ) * sStr := by
        rw [hs0_eq]; dsimp only [sStr, B_max]; unfold sideSlotBaseW; push_cast; ring
      have hscR_eq : sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (2 * k) =
          rBase0 + ((2 * k : ℕ) : ℤ) * rStr := by
        rw [hr0_eq]; dsimp only [rStr]; unfold sideSlotBaseR; push_cast; ring
      have hlenW_eq : ((2 * (k + 1) : ℕ) : ℤ) * sStr = ((2 * k : ℕ) : ℤ) * sStr + 2 * sStr := by
        push_cast; ring
      have hlenR_eq : ((2 * (k + 1) : ℕ) : ℤ) * rStr = ((2 * k : ℕ) : ℤ) * rStr + 2 * rStr := by
        push_cast; ring
      have h2k_nn : 0 ≤ ((2 * k : ℕ) : ℤ) * sStr := mul_nonneg (Nat.cast_nonneg _) (by omega)
      have h2k_rnn : 0 ≤ ((2 * k : ℕ) : ℤ) * rStr := mul_nonneg (Nat.cast_nonneg _) hr_nn
      have hfr_next : RadFrameOutside scrW scrR tblW sBase0 (((2 * (k + 1) : ℕ) : ℤ) * sStr)
          tblR rBase0 (((2 * (k + 1) : ℕ) : ℤ) * rStr) mA m' :=
        (hfr_m.mono_range
          (Or.inr ⟨le_rfl, by rw [hlenW_eq]; omega⟩)
          (Or.inr ⟨le_rfl, by rw [hlenR_eq]; linarith⟩)).trans
        (hfr_s.mono_range
          (Or.inr ⟨by rw [hscW_eq]; omega, by rw [hscW_eq, hlenW_eq]; linarith⟩)
          (Or.inr ⟨by rw [hscR_eq]; omega, by rw [hscR_eq, hlenR_eq]; linarith⟩))
      let liveSlots' : Fin L_p2 → Fin 2 → LiveSlot R ℓ M₀ d :=
        fun s => if s = sFin then S_new else liveSlots_m s
      refine ⟨m', hd_s, hfp_s,
        (hkW_s _ (Or.inl (by omega))).trans hep_m,
        (hkW_s _ (Or.inl (by omega))).trans ht_m,
        hs_s, hh_s,
        fun w hw => (hkW_s w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr h)).trans (hkW_m w hw),
        fun r hr => (hkR_s r hr).trans (hkR_m r hr),
        hfr_next, liveSlots', ?_, ?_⟩
      · intro s hs_lt
        dsimp only [liveSlots']
        by_cases hse : s = sFin
        · subst hse; rw [if_pos rfl]; exact ⟨hslots_s, hcur_s⟩
        · rw [if_neg hse]
          have hs_lt_k : s.val < k := by
            have hne_v : s.val ≠ k := fun hv => hse (Fin.ext hv)
            omega
          rcases hdone_m s hs_lt_k with ⟨hsl_prev, hcur_prev⟩
          refine ⟨fun sl => ⟨(hsl_prev sl).1, ?_⟩, hcur_prev⟩
          have hidx_lt : sideSlotIdx s sl < 2 * k := by
            have := sl.isLt; unfold sideSlotIdx; omega
          have hdisjW_s : sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx s sl) + sStr ≤
              sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (2 * k) := by
            have hm : ((sideSlotIdx s sl : ℤ) + 1) * sStr ≤ ((2 * k : ℕ) : ℤ) * sStr :=
              mul_le_mul_of_nonneg_right (by exact_mod_cast hidx_lt) (by omega)
            dsimp only [sStr, B_max] at hm ⊢; unfold sideSlotBaseW; linarith
          have hdisjR_s : sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx s sl) + rStr ≤
              sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (2 * k) := by
            have hm : ((sideSlotIdx s sl : ℤ) + 1) * rStr ≤ ((2 * k : ℕ) : ℤ) * rStr :=
              mul_le_mul_of_nonneg_right (by exact_mod_cast hidx_lt) hr_nn
            dsimp only [rStr] at hm ⊢; unfold sideSlotBaseR; linarith
          exact (hsl_prev sl).2.mono_frame hfr_s hneW hneR (Or.inr (Or.inl hdisjW_s)) (Or.inr (Or.inl hdisjR_s))
      · intro s hs_ge
        have hse : s ≠ sFin := fun h => by subst h; dsimp only [sFin] at hs_ge; omega
        dsimp only [liveSlots']
        rw [if_neg hse]
        rcases htodo_m s (by omega) with ⟨heq_s, henc_s⟩
        refine ⟨heq_s, fun sl => ?_⟩
        have hidx_ge : 2 * k + 2 ≤ sideSlotIdx s sl := by unfold sideSlotIdx; omega
        have hdisjW_s : sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (2 * k) + 2 * sStr ≤
            sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx s sl) := by
          have hm : (((2 * k : ℕ) : ℤ) + 2) * sStr ≤ (sideSlotIdx s sl : ℤ) * sStr :=
            mul_le_mul_of_nonneg_right (by exact_mod_cast hidx_ge) (by omega)
          dsimp only [sStr, B_max] at hm ⊢; unfold sideSlotBaseW; linarith
        have hdisjR_s : sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (2 * k) + 2 * rStr ≤
            sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx s sl) := by
          have hm : (((2 * k : ℕ) : ℤ) + 2) * rStr ≤ (sideSlotIdx s sl : ℤ) * rStr :=
            mul_le_mul_of_nonneg_right (by exact_mod_cast hidx_ge) hr_nn
          dsimp only [rStr] at hm ⊢; unfold sideSlotBaseR; linarith
        exact (henc_s sl).mono_frame hfr_s hneW hneR (Or.inr (Or.inr hdisjW_s)) (Or.inr (Or.inr hdisjR_s)))
  rcases hInvEnd with ⟨hfp_e, _, _, _, _, hkW_e, hkR_e, hfr_Ae, liveSlots_e, hdone_e, _⟩
  have hfr_tot : RadFrameOutside scrW scrR
      tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
      tblR (sideBaseR + (d : ℤ)) (dyadicSideRStride L_p2 R ℓ M₀ d - (d : ℤ)) m₀ m_end :=
    (hfr0A.mono_range
      (Or.inr ⟨le_rfl, by linarith [hhdr_end]⟩)
      (Or.inr ⟨hdst_lo, by linarith [hdst_hi, hent_end]⟩)).trans
    (hfr_Ae.mono_range
      (Or.inr ⟨by rw [hs0_eq]; omega,
               by rw [hs0_eq]; dsimp only [sStr, B_max]; unfold dyadicSideWStride; linarith⟩)
      (Or.inr ⟨by rw [hr0_eq]; omega,
               by rw [hr0_eq]; dsimp only [rStr]; unfold dyadicSideRStride; linarith⟩))
  refine ⟨m_end,
    (hd_hdr.seq hd_loop).mono_cost (by unfold dyadicSideInsertCost; dsimp only [C_step]; omega),
    hfp_e,
    ⟨ht_lt, ep₀, liveSlots_e, hep1,
      (hfr_Ae.1 tblW _ hneW (Or.inr (Or.inl (by rw [hs0_eq]; omega)))).trans hmA_ep,
      (hfr_Ae.1 tblW _ hneW (Or.inr (Or.inl (by rw [hs0_eq]; omega)))).trans hmA_t,
      fun eid heid => ?_,
      fun eid heid => ?_,
      fun eid heid => ?_,
      fun u hu => ?_,
      fun eid heid c => ?_,
      fun s sl => (hdone_e s s.isLt).1 sl,
      fun s => (hdone_e s s.isLt).2⟩,
    hkW_e, hkR_e, hfr_tot⟩
  · have heZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by
      dsimp only [idx', H4b.DyadicSideIndex.insertHandle] at heid
      exact_mod_cast (lt_of_lt_of_le heid ht_lt)
    rw [hfr_Ae.1 tblW _ hneW (Or.inr (Or.inl (by rw [hs0_eq]; unfold sideHandleOff; omega)))]
    exact hmA_hand eid heid
  · have heZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast heid
    rw [hfr_Ae.1 tblW _ hneW (Or.inr (Or.inl (by rw [hs0_eq]; unfold sideAliveEpOff; omega)))]
    exact hmA_al_le eid heid
  · have heZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by
      dsimp only [idx', H4b.DyadicSideIndex.insertHandle] at heid
      exact_mod_cast (lt_of_lt_of_le heid ht_lt)
    rw [hfr_Ae.1 tblW _ hneW (Or.inr (Or.inl (by rw [hs0_eq]; unfold sideAliveEpOff; omega)))]
    exact hmA_al_iff eid heid
  · have humZ : (u % n : ℤ) < (n : ℤ) := by exact_mod_cast (Nat.mod_lt u hn)
    rw [hfr_Ae.1 tblW _ hneW (Or.inr (Or.inl (by rw [hs0_eq]; unfold sideActiveOff; omega)))]
    exact hmA_act u hu
  · dsimp only [idx', H4b.DyadicSideIndex.insertHandle] at heid
    have hb := sideEntryPt_bounds (L_p2 := L_p2) sideBaseR (lt_of_lt_of_le heid ht_lt) c
    rw [hfr_Ae.2 tblR _ hneR (Or.inr (Or.inl (by rw [hr0_eq]; exact hb.2)))]
    exact hmA_pt eid heid c

/-! ### 2. Direct UID Wrapper (`dyadicSideInsertUidStmt`) for `SideRAMOps` -/

def dyadicSideInsertUidWStride (ℓ M₀ cap_u : ℕ) : ℤ :=
  1 + dyadicSideInsertWStride ℓ M₀ cap_u

def dyadicSideInsertUidCost (L_p2 R ℓ M₀ d b T p_coord cap_u : ℕ) : ℕ :=
  25 + dyadicSideInsertCost L_p2 R ℓ M₀ d b T p_coord cap_u

noncomputable def dyadicSideInsertUidStmt (scrW scrR tblW tblR coinTbl : ℕ)
    (wSideBaseW wSideBaseR wOffO wUid wSeedBaseOff wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d b T p_coord cap_u : ℕ) (A B_rat τ_d : ℚ) : ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit wScr) (.mul (.readHeap scrW (.lit wUid)) (.lit (d : ℤ))))
       (dyadicSideInsertStmt scrW scrR tblW tblR tblR 1 coinTbl
         wSideBaseW wSideBaseR wOffO wScr wUid wSeedBaseOff (wScr + 1) rScr
         n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d)

theorem zeroRand_dyadicSideInsertUidStmt (scrW scrR tblW tblR coinTbl : ℕ)
    (wSideBaseW wSideBaseR wOffO wUid wSeedBaseOff wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d b T p_coord cap_u : ℕ) (A B_rat τ_d : ℚ) :
    H3a.ZeroRandStmt (dyadicSideInsertUidStmt scrW scrR tblW tblR coinTbl
      wSideBaseW wSideBaseR wOffO wUid wSeedBaseOff wScr rScr
      n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d) :=
  .seq (.writeWordHeap _ _ _)
       (zeroRand_dyadicSideInsertStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _)

theorem exec_h4_dyadicSideInsertUidStmt {d TW BW TR BR scrW scrR tblW tblR coinTbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wOffO wUid wSeedBaseOff wScr rScr
      sideBaseW sideBaseR offO seedBaseOff : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord cap_u : ℕ}
    (hn : 1 ≤ n) (hM₀ : 1 ≤ M₀)
    (A B_rat τ_d : ℚ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {U : Finset ℕ} {h₀ : ℕ}
    (hh0_not : h₀ ∉ U) (hh0_lt : h₀ < n) (hU_lt : ∀ x ∈ U, x < n)
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b}
    (ht_lt : idx.t_ins < 2 ^ L_p2)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR) (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneCoinScr : coinTbl ≠ scrW)
    (hneCoinW : coinTbl ≠ tblW) (hne1R : 1 ≠ tblR)
    (hsideW : 0 ≤ sideBaseW ∧ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ (BW : ℤ))
    (hsideR : 0 ≤ sideBaseR ∧ sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ (BR : ℤ))
    (hoffO_R : offO + (d : ℤ) ≤ sideBaseR + (d : ℤ))
    (hwBW : wSideBaseW < wScr) (hwBR : wSideBaseR < wScr) (hwO : wOffO < wScr)
    (hwU : wUid < wScr) (hwSeed : wSeedBaseOff < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideInsertUidWStride ℓ M₀ cap_u ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + dyadicSideInsertRStride d ≤ (BR : ℤ))
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hbR : wRead m₀ scrW wSideBaseR = sideBaseR)
    (hoffO : wRead m₀ scrW wOffO = offO)
    (huid : wRead m₀ scrW wUid = (h₀ : ℤ))
    (hseedOff : wRead m₀ scrW wSeedBaseOff = seedBaseOff)
    (ho : ∀ c : Fin d, rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpt : ∀ c : Fin d, rRead m₀ 1 (((h₀ * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts h₀) c)
    (hseed₀ : EncSideStepSeed coinTbl seedBaseOff ω_step m₀)
    (henc₀ : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (dyadicSideInsertUidStmt scrW scrR tblW tblR coinTbl
          wSideBaseW wSideBaseR wOffO wUid wSeedBaseOff wScr rScr
          n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d)
        m₀ m₁ (dyadicSideInsertUidCost L_p2 R ℓ M₀ d b T p_coord cap_u) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u
        (Insert.insert h₀ U)
        (idx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o (pts h₀) h₀ ω_step) m₁ ∧
      (∀ w, w < wScr → wRead m₁ scrW w = wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR
        tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
        tblR sideBaseR (dyadicSideRStride L_p2 R ℓ M₀ d) m₀ m₁ := by
  have hw_ge := dyadicSideInsertWStride_ge_44 ℓ M₀ cap_u
  have hr_ge_d := dyadicSideRStride_ge_d L_p2 R ℓ M₀ d
  let offPt : ℤ := ((h₀ * d : ℕ) : ℤ)
  let m_p := wWrite m₀ scrW wScr offPt
  have hd_p : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.mul (.readHeap scrW (.lit wUid)) (.lit (d : ℤ)))) m₀ m_p 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wScr) _ rfl
      (by change wRead m₀ scrW wUid * (d : ℤ) = offPt
          rw [huid]; dsimp only [offPt]; push_cast; ring)
      (by dsimp [intExprOps]; omega)
  have hfp_p : InFootprint TW BW TR BR m_p :=
    InFootprint.wWrite hfp₀ hscrW hwScr.1 (by unfold dyadicSideInsertUidWStride at hwScr; omega)
  have hfr_p : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m_p :=
    rws scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ _ _
  have hmod_disj : ∀ u ∈ U, u % n ≠ h₀ % n := by
    intro u hu
    rw [Nat.mod_eq_of_lt (hU_lt u hu), Nat.mod_eq_of_lt hh0_lt]
    exact fun heq => hh0_not (heq ▸ hu)
  obtain ⟨m₁, hd_ins, hfp₁, henc₁, hkW₁, _, hfr₁⟩ :=
    exec_h4_dyadicSideInsertStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
      inp wSideBaseW wSideBaseR wOffO wScr wUid wSeedBaseOff (wScr + 1) rScr
      sideBaseW sideBaseR offO offPt seedBaseOff
      hn hM₀ A B_rat τ_d o (pts h₀) hmod_disj ω_step ht_lt
      hfp_p hscrW hscrR htblW htblR hneW hneR hneR hneCoinScr
      hsideW hsideR
      ⟨by omega, by unfold dyadicSideInsertUidWStride at hwScr; omega⟩ hrScr
      (Or.inl (by omega)) (Or.inl (by omega)) (Or.inl (by omega))
      (Or.inl (by omega)) (Or.inl (by omega)) (Or.inl (by omega))
      (Or.inl hneCoinW) (Or.inl hne1R)
      (Or.inr (Or.inl (by unfold sideEntryPtOff; omega)))
      ((wNe _ _ (Or.inr (by omega))).trans hbW)
      ((wNe _ _ (Or.inr (by omega))).trans hbR)
      ((wNe _ _ (Or.inr (by omega))).trans hoffO)
      (wRead_wWrite_self _ _ _ _)
      ((wNe _ _ (Or.inr (by omega))).trans huid)
      ((wNe _ _ (Or.inr (by omega))).trans hseedOff)
      (fun c => by rw [rRead_wWrite]; exact ho c)
      (fun c => by
        rw [rRead_wWrite]
        have haddr : offPt + (c.val : ℤ) = ((h₀ * d + c.val : ℕ) : ℤ) := by
          dsimp only [offPt]; push_cast; ring
        rw [haddr]; exact hpt c)
      (hseed₀.mono_frame hfr_p hneCoinScr (Or.inl hneCoinW))
      (henc₀.mono_frame hn hfr_p hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega))))
  have hfr_tot : RadFrameOutside scrW scrR
      tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
      tblR sideBaseR (dyadicSideRStride L_p2 R ℓ M₀ d) m₀ m₁ :=
    (rtz hfr_p).trans
      (hfr₁.mono_range (Or.inr ⟨le_rfl, le_rfl⟩) (Or.inr ⟨by omega, by omega⟩))
  refine ⟨m₁, (hd_p.seq hd_ins).mono_cost (by unfold dyadicSideInsertUidCost; omega),
    hfp₁, henc₁, ?_, hfr_tot⟩
  intro w hw
  exact (hkW₁ w (Or.inl (by omega))).trans (wNe _ _ (Or.inr (by omega)))

/-! ### 3. Polynomial/Sublinear Cost & Space Bounds -/

private lemma le_of_add_eq {a b c : ℕ} (h : a + c = b) : a ≤ b := by
  rw [← h]; exact Nat.le_add_right a c

theorem slotInitFromCoinTblCost_le (R ℓ M₀ d b T p_coord : ℕ) :
    slotInitFromCoinTblCost R ℓ M₀ d b T p_coord ≤
      (1 + R * ℓ * M₀) *
        ((d + 1) * (460 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b))) := by
  let Q := 300 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b)
  have hlhs : slotInitFromCoinTblCost R ℓ M₀ d b T p_coord = 160 + (R * ℓ * M₀) * ((d + 1) * Q) := by
    unfold slotInitFromCoinTblCost seedCoordCount; dsimp only [Q]; ring
  have hrhs : 460 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b) = 160 + Q := by
    dsimp only [Q]; omega
  rw [hlhs, hrhs]
  exact le_of_add_eq (c := Q + d * (160 + Q) + (R * ℓ * M₀) * ((d + 1) * 160)) (by ring)

theorem dyadicSideInsertCost_le (L_p2 R ℓ M₀ d b T p_coord cap_u cap_q : ℕ) :
    dyadicSideInsertCost L_p2 R ℓ M₀ d b T p_coord cap_u ≤
      (1 + cap_u + cap_q + R * ℓ * M₀) *
        ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) *
          (2200 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b))) := by
  let Q1 := 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b)
  let P1 := (R + 1) * (ℓ + 1) * (d + 1)
  have hP1_ge_d : d + 1 ≤ P1 :=
    le_of_add_eq (c := (R * ℓ + R + ℓ) * (d + 1)) (by dsimp only [P1]; ring)
  have hP1_pos : 1 ≤ P1 := le_trans (Nat.succ_pos d) hP1_ge_d
  have hone : dyadicSideInsertOneEidCost R ℓ M₀ d cap_u ≤
      (1 + cap_u + cap_q + R * ℓ * M₀) * (P1 * 600) := by
    unfold dyadicSideInsertOneEidCost liveSlotInsertRecordCost liveSlotInsertCopyCost evalCopyTuplesCost
    let X := R * ℓ * M₀
    have hbase : 80 + (150 + 40 * d + R * (100 + (200 + ℓ * (250 + M₀ * (350 + 80 * d)) + cap_u * (110 + 130 * ℓ)) + cap_u * 450 + 30)) =
        (230 + 40 * d + 330 * R + 250 * R * ℓ) + cap_u * (560 * R + 130 * R * ℓ) + X * (350 + 80 * d) := by
      dsimp only [X]; ring
    rw [hbase]
    have ht1 : 230 + 40 * d + 330 * R + 250 * R * ℓ ≤ 1 * (P1 * 600) :=
      le_of_add_eq (c := 370 + 560 * d + 270 * R + 600 * ℓ + 350 * R * ℓ + 600 * R * d + 600 * ℓ * d + 600 * R * ℓ * d)
        (by dsimp only [P1]; ring)
    have ht2 : cap_u * (560 * R + 130 * R * ℓ) ≤ cap_u * (P1 * 600) :=
      Nat.mul_le_mul_left cap_u
        (le_of_add_eq (c := 600 + 40 * R + 600 * ℓ + 470 * R * ℓ + 600 * (R + 1) * (ℓ + 1) * d)
          (by dsimp only [P1]; ring))
    have ht3 : X * (350 + 80 * d) ≤ X * (P1 * 600) :=
      Nat.mul_le_mul_left X
        (le_of_add_eq (c := 250 + 520 * d + 600 * (R * ℓ + R + ℓ) * (d + 1))
          (by dsimp only [P1]; ring))
    have ht0 : 0 ≤ cap_q * (P1 * 600) := Nat.zero_le _
    calc (230 + 40 * d + 330 * R + 250 * R * ℓ) + cap_u * (560 * R + 130 * R * ℓ) + X * (350 + 80 * d)
        ≤ (1 * (P1 * 600) + cap_u * (P1 * 600) + cap_q * (P1 * 600)) + X * (P1 * 600) :=
          Nat.add_le_add (le_trans (Nat.add_le_add ht1 ht2) (Nat.le_add_right _ _)) ht3
      _ = (1 + cap_u + cap_q + R * ℓ * M₀) * (P1 * 600) := by dsimp only [X]; ring
  have hinit : slotInitFromCoinTblCost R ℓ M₀ d b T p_coord ≤
      (1 + cap_u + cap_q + R * ℓ * M₀) * (P1 * (460 + Q1)) := by
    let X := R * ℓ * M₀
    have hl : slotInitFromCoinTblCost R ℓ M₀ d b T p_coord = 160 + X * ((d + 1) * (300 + Q1)) := by
      unfold slotInitFromCoinTblCost seedCoordCount; dsimp only [X, Q1]; ring
    rw [hl]
    have hi1 : 160 ≤ 1 * (P1 * (460 + Q1)) := by
      have h460 : 460 ≤ 460 + Q1 := Nat.le_add_right _ _
      have hp : 460 + Q1 ≤ P1 * (460 + Q1) := Nat.le_mul_of_pos_left _ hP1_pos
      omega
    have hi2 : X * ((d + 1) * (300 + Q1)) ≤ X * (P1 * (460 + Q1)) :=
      Nat.mul_le_mul_left X (Nat.mul_le_mul hP1_ge_d (by omega))
    calc 160 + X * ((d + 1) * (300 + Q1))
        ≤ (1 * (P1 * (460 + Q1)) + (cap_u + cap_q) * (P1 * (460 + Q1))) + X * (P1 * (460 + Q1)) :=
          Nat.add_le_add (le_trans hi1 (Nat.le_add_right _ _)) hi2
      _ = (1 + cap_u + cap_q + R * ℓ * M₀) * (P1 * (460 + Q1)) := by dsimp only [X]; ring
  have hstep : dyadicSideInsertScaleStepCost R ℓ M₀ d b T p_coord cap_u ≤
      (1 + cap_u + cap_q + R * ℓ * M₀) * (P1 * (2200 + Q1)) := by
    unfold dyadicSideInsertScaleStepCost
    let C := 1 + cap_u + cap_q + R * ℓ * M₀
    have hc_pos : 1 ≤ C := by dsimp only [C]; omega
    have h350 : 350 ≤ C * (P1 * 540) := by
      have hp : 540 ≤ P1 * 540 := Nat.le_mul_of_pos_left 540 hP1_pos
      have hc : P1 * 540 ≤ C * (P1 * 540) := Nat.le_mul_of_pos_left _ hc_pos
      omega
    calc 350 + slotInitFromCoinTblCost R ℓ M₀ d b T p_coord + 2 * dyadicSideInsertOneEidCost R ℓ M₀ d cap_u
        ≤ C * (P1 * 540) + C * (P1 * (460 + Q1)) + 2 * (C * (P1 * 600)) :=
          Nat.add_le_add (Nat.add_le_add h350 hinit) (Nat.mul_le_mul_left 2 hone)
      _ = (1 + cap_u + cap_q + R * ℓ * M₀) * (P1 * (2200 + Q1)) := by dsimp only [C]; ring
  unfold dyadicSideInsertCost
  let C := 1 + cap_u + cap_q + R * ℓ * M₀
  have hhdr : 320 + 35 * d ≤ C * (P1 * (2200 + Q1)) := by
    have h1 : 320 + 35 * d ≤ (d + 1) * 2200 := by omega
    have h2 : (d + 1) * 2200 ≤ P1 * (2200 + Q1) := Nat.mul_le_mul hP1_ge_d (Nat.le_add_right _ _)
    have h3 : P1 * (2200 + Q1) ≤ C * (P1 * (2200 + Q1)) :=
      Nat.le_mul_of_pos_left _ (by dsimp only [C]; omega)
    exact le_trans h1 (le_trans h2 h3)
  have hloop : L_p2 * dyadicSideInsertScaleStepCost R ℓ M₀ d b T p_coord cap_u ≤
      L_p2 * (C * (P1 * (2200 + Q1))) := Nat.mul_le_mul_left L_p2 hstep
  calc 320 + 35 * d + L_p2 * dyadicSideInsertScaleStepCost R ℓ M₀ d b T p_coord cap_u
      ≤ C * (P1 * (2200 + Q1)) + L_p2 * (C * (P1 * (2200 + Q1))) := Nat.add_le_add hhdr hloop
    _ = C * ((L_p2 + 1) * P1 * (2200 + Q1)) := by ring
    _ = (1 + cap_u + cap_q + R * ℓ * M₀) *
          ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) *
            (2200 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b))) := by
        dsimp only [C, P1, Q1]; ring

theorem dyadicSideInsertUidCost_le (L_p2 R ℓ M₀ d b T p_coord cap_u cap_q : ℕ) :
    dyadicSideInsertUidCost L_p2 R ℓ M₀ d b T p_coord cap_u ≤
      (1 + cap_u + cap_q + R * ℓ * M₀) *
        ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) *
          (2250 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b))) := by
  unfold dyadicSideInsertUidCost
  have h1 := dyadicSideInsertCost_le L_p2 R ℓ M₀ d b T p_coord cap_u cap_q
  let Q1 := 2200 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b)
  let M := (1 + cap_u + cap_q + R * ℓ * M₀) * ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1))
  have hM_pos : 1 ≤ M := by
    dsimp only [M]
    exact Nat.mul_pos (by omega)
      (Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.succ_pos _) (Nat.succ_pos _)) (Nat.succ_pos _)) (Nat.succ_pos _))
  have h25 : 25 ≤ M * 50 := le_trans (by decide : 25 ≤ 50) (Nat.le_mul_of_pos_left 50 hM_pos)
  have h1' : dyadicSideInsertCost L_p2 R ℓ M₀ d b T p_coord cap_u ≤ M * Q1 := by
    calc dyadicSideInsertCost L_p2 R ℓ M₀ d b T p_coord cap_u
        ≤ (1 + cap_u + cap_q + R * ℓ * M₀) * ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * Q1) := h1
      _ = M * Q1 := by dsimp only [M]; ring
  calc 25 + dyadicSideInsertCost L_p2 R ℓ M₀ d b T p_coord cap_u
      ≤ M * 50 + M * Q1 := Nat.add_le_add h25 h1'
    _ = (1 + cap_u + cap_q + R * ℓ * M₀) *
          ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) *
            (2250 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b))) := by
        dsimp only [M, Q1]; ring

theorem dyadicSideWStride_le (n L_p2 R ℓ M₀ cap_u : ℕ) :
    dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤
      (((2 + 2 * 2 ^ L_p2 + n + 2 * L_p2 * (4 + 2 * R * M₀ ^ ℓ + 5 * 2 ^ L_p2 * R * cap_u)) : ℕ) : ℤ) := by
  unfold dyadicSideWStride slotWStride
  push_cast
  linarith

theorem dyadicSideRStride_le (L_p2 R ℓ M₀ d : ℕ) :
    dyadicSideRStride L_p2 R ℓ M₀ d ≤
      (((d + 2 ^ L_p2 * d + 2 * L_p2 * (R * ℓ * M₀ * (d + 1))) : ℕ) : ℤ) := by
  unfold dyadicSideRStride slotRStride seedCoordCount
  push_cast
  linarith

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
