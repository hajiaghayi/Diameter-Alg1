import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2A
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2A1
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B0s
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B1a
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_FinalA
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

/-! ### 1. Single-Job Tick Interface (`TickJobRAMSpec`) Matching `CG09_Stage2B.exec_tickRebuildJobStmt` -/

/-- Exact 1-to-1 interface for `CG09_Stage2B.tickRebuildJobStmt`. -/
structure TickJobRAMSpec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) where
  stmt : Fin cp.D_max → ArithRAMStmt
  cost : ℕ
  zeroRand : ∀ r : Fin cp.D_max, ZeroRandStmt (stmt r)
  exec :
    ∀ (inp : ArithRAMInput d) (r : Fin cp.D_max)
      {actH S_anc : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
      {anc : MNode cp} {jb : SuffixJob cp}
      {servLen : ℕ} {servSlots : List ℕ}
      {curJobs : Fin cp.D_max → Option (SuffixJob cp)}
      {readySlots : Fin cp.D_max → List ℕ}
      {curSlots : Fin cp.D_max → ℕ}
      {bits : Fin cp.B_STEP → Bool}
      {m₀ : ArithRAMMemory},
      curJobs r = some jb →
      servLen ≤ cp.D_max →
      servSlots.length = servLen →
      (hr_serv : r.val < servSlots.length) →
      S_anc ⊆ actH →
      (∀ x ∈ actH, x < cp.n) →
      (∀ x ∈ actH, ∀ c : Fin d,
        rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) →
      LiveNodeInv cp actH pts gt S_anc anc →
      SuffixJobInvSlack cp cp.B_scan actH pts gt S_anc anc r.val jb →
      InFootprint ops.TW ops.BW ops.TR ops.BR m₀ →
      ops.SlotsReady m₀ →
      wRead m₀ engMetaTbl 0 = (servLen : ℤ) →
      (∀ i (his : i < servSlots.length),
        wRead m₀ engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ)) →
      ops.EncNode anc (servSlots[r.val]'hr_serv) m₀ →
      (∀ r' : Fin cp.D_max,
        EncJobSlot ops r' (curJobs r') (readySlots r') (curSlots r') m₀) →
      (servSlots ++ (List.finRange cp.D_max).flatMap
        (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r'))).Nodup →
      (∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap
        (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')), s < M_slots cp) →
      MemHasStepCoins cp bits m₀ →
      let ω₂ := (bitsToStepCoinBundle cp bits).2.1
      let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
        ω₂.1 ⟨r.val * cp.B_scan + j.val, by
          have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
            calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan := Nat.add_lt_add_left j.isLt _
              _ = (r.val + 1) * cp.B_scan := by ring
              _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
          exact Nat.lt_add_right _ this⟩
      let ctrSeed : CenterSeed cp := ω₂.2 r.castSucc
      let advRes := advanceOneJob cp pts gt anc r jb bSeeds ctrSeed
      ExecDet ops.TW ops.BW ops.TR ops.BR inp (stmt r) m₀
        (TickJobResultPost ops r servSlots curJobs readySlots curSlots advRes m₀)
        cost

/-! ### 2. `O(1)` Job-Slot Cancellation (`cancelJobSlotStage2Stmt`) -/

def cancelJobSlotStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) : ArithRAMStmt :=
  .writeWordHeap engMetaTbl (.lit (jobMetaBase cp r.val)) (.lit 0)

theorem zeroRand_cancelJobSlotStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) :
    ZeroRandStmt (cancelJobSlotStage2Stmt cp r) :=
  .writeWordHeap _ _ _

theorem exec_cancelJobSlotStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {servSlots : List ℕ}
    {curJobs : Fin cp.D_max → Option (SuffixJob cp)}
    {readySlots : Fin cp.D_max → List ℕ}
    {curSlots : Fin cp.D_max → ℕ}
    {m₀ : ArithRAMMemory}
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hjobs_enc : ∀ r' : Fin cp.D_max,
      EncJobSlot ops r' (curJobs r') (readySlots r') (curSlots r') m₀)
    (hall_nd : (servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r'))).Nodup)
    (hall_lt : ∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')), s < M_slots cp) :
    let curJobs' := Function.update curJobs r none
    let readySlots' := Function.update readySlots r []
    let curSlots' := Function.update curSlots r 0
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (cancelJobSlotStage2Stmt cp r) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        (∀ r' : Fin cp.D_max, EncJobSlot ops r' (curJobs' r') (readySlots' r') (curSlots' r') m₁) ∧
        (servSlots ++ (List.finRange cp.D_max).flatMap
          (fun r' => jobUsedSlots (curJobs' r') (readySlots' r') (curSlots' r'))).Nodup ∧
        (∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap
          (fun r' => jobUsedSlots (curJobs' r') (readySlots' r') (curSlots' r')), s < M_slots cp) ∧
        (∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁) ∧
        (∀ t, t ≠ engMetaTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ jobMetaBase cp r.val → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      12 := by
  intro curJobs' readySlots' curSlots'
  have hTW := ops.hTW
  have hBW_meta := ops.hBW_meta
  have hr_lt := r.isLt
  have hD2 : 0 ≤ cp.D_max * cp.D_max := Nat.zero_le _
  refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (jobMetaBase cp r.val)) (.lit 0)
    (jobMetaBase cp r.val) 0 hfp₀
    (by unfold engMetaTbl; omega)
    (by unfold jobMetaBase; omega)
    (by unfold jobMetaBase; nlinarith [hr_lt, hBW_meta, hD2])
    rfl rfl (by simp [intExprOps]) ?_
  set m₁ := H3a.wWrite m₀ engMetaTbl (jobMetaBase cp r.val) 0
  have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m₁ t i = wRead m₀ t i :=
    fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))
  have hnd : ∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁ :=
    fun mn s _ he0 => ops.encNode_ext mn s m₀ m₁ he0 hw9
      (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
      (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
  have hall' := allSlots_nodup_update_sub (D := cp.D_max) (M := M_slots cp)
    (servSlots := servSlots)
    (U := fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r'))
    (U' := fun r' => jobUsedSlots (curJobs' r') (readySlots' r') (curSlots' r'))
    r hall_nd hall_lt
    (fun r' hne => by simp [curJobs', readySlots', curSlots', Function.update_of_ne hne])
    (by simp [curJobs', readySlots', curSlots', jobUsedSlots])
    (fun s hs => by simp [curJobs', readySlots', curSlots', jobUsedSlots] at hs)
  have hfm_reg : ∀ i, ¬ InJobMetaRegion cp r.val i → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i := by
    intro i hnot
    refine wRead_wWrite_of_ne _ _ (Or.inr (fun heq => hnot ?_))
    exact Or.inl ⟨by omega, by omega⟩
  refine ⟨ops.slotsReady_ext m₀ m₁ hsr₀ hw9 (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
    fun r' => ?_, hall'.1, hall'.2, hnd,
    fun t ht i => wRead_wWrite_of_ne _ _ (Or.inl ht),
    fun i hne => wRead_wWrite_of_ne _ _ (Or.inr hne),
    fun t i => rRead_wWrite _ _ _ _ _ _⟩
  by_cases heq : r' = r
  · subst heq
    dsimp only [curJobs', readySlots', curSlots']
    simp only [Function.update_self, EncJobSlot]
    exact ⟨trivial, wRead_wWrite_self _ _ _ _⟩
  · simp only [curJobs', readySlots', curSlots', Function.update_of_ne heq]
    exact encJobSlot_other_of_frame heq (hjobs_enc r')
      (fun s hs => hall_lt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r', hs⟩)))
      hfm_reg (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
      (fun mn' s hs _ he0 => hnd mn' s hs he0)

/-! ### 3. Earliest-Commit Splice & Leaf Dispatch (`commitJobStage2Stmt`) -/

def commitLeafDispatchStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  .ite (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 1))
    (.seq (copySnapToLeafStmt cp r)
          (.writeWordHeap engMetaTbl (.lit 1) (.lit 0)))
    (.ite (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 2))
      (.seq (.writeWordHeap engScrTbl (.lit 11)
              (.readHeap engMetaTbl (.lit (jobMetaBase cp r.val + 7))))
        (.seq (copyNodeResToLeafStmt ops 11)
              (.writeWordHeap engMetaTbl (.lit 1) (.lit 0))))
      (.seq (.writeWordHeap engMetaTbl (.lit 2) (.lit 0))
            (.writeWordHeap engMetaTbl (.lit 1) (.lit 1))))

theorem zeroRand_commitLeafDispatchStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (commitLeafDispatchStage2Stmt ops r) :=
  .ite (.seq (zeroRand_copySnapToLeafStmt cp r) (.writeWordHeap _ _ _))
    (.ite (.seq (.writeWordHeap _ _ _)
            (.seq (zeroRand_copyNodeResToLeafStmt ops 11) (.writeWordHeap _ _ _)))
          (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))

def commitJobStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 0) (.lit 1))
    (.seq (commitLeafDispatchStage2Stmt ops r)
      (.seq (spliceReadyToServStmt cp r)
            (cancelJobSlotStage2Stmt cp r)))

theorem zeroRand_commitJobStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (commitJobStage2Stmt ops r) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_commitLeafDispatchStage2Stmt ops r)
      (.seq (zeroRand_spliceReadyToServStmt cp r)
            (zeroRand_cancelJobSlotStage2Stmt cp r)))

def commitJobStage2Cost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  220 + ops.C_read + cp.B_scan * (ops.C_read + 130) + cp.D_max * 30

theorem exec_commitJobStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {servBefore : List (MNode cp)} {servSlots : List ℕ}
    {curJobs : Fin cp.D_max → Option (SuffixJob cp)}
    {readySlots : Fin cp.D_max → List ℕ}
    {curSlots : Fin cp.D_max → ℕ}
    {outJb : SuffixJob cp} {rSlots' : List ℕ} {cSlot' : ℕ}
    {newSuf : List (MNode cp)} {newLeaf : List ℕ} {newOv : Bool}
    {m₀ : ArithRAMMemory}
    (hr_serv : r.val ≤ servBefore.length)
    (hslen : servSlots.length = servBefore.length)
    (hr_sum : r.val + newSuf.length ≤ cp.D_max)
    (hleaf_spec : newOv = false →
      newLeaf.Nodup ∧ (∀ x ∈ newLeaf, x < cp.n) ∧ newLeaf.length ≤ cp.B_scan)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hserv_pre : ∀ i (hi : i < r.val),
      wRead m₀ engMetaTbl (servSlotOff i) =
        (servSlots[i]'(lt_of_lt_of_le hi (hslen ▸ hr_serv)) : ℤ) ∧
      ops.EncNode (servBefore[i]'(lt_of_lt_of_le hi hr_serv))
        (servSlots[i]'(lt_of_lt_of_le hi (hslen ▸ hr_serv))) m₀)
    (hused_eq : jobUsedSlots (some outJb) rSlots' cSlot' = rSlots')
    (hrlen_eq : rSlots'.length = newSuf.length)
    (hw_rlen : wRead m₀ engMetaTbl (jobMetaBase cp r.val + 1) = (newSuf.length : ℤ))
    (hready_enc : ∀ q (hq : q < newSuf.length) (hqs : q < rSlots'.length),
      wRead m₀ engMetaTbl (readySlotOff cp r.val q) = (rSlots'[q]'hqs : ℤ) ∧
      ops.EncNode (newSuf[q]'hq) (rSlots'[q]'hqs) m₀)
    (hjobs_enc : ∀ r' : Fin cp.D_max,
      EncJobSlot ops r' (Function.update curJobs r (some outJb) r')
        (Function.update readySlots r rSlots' r')
        (Function.update curSlots r cSlot' r') m₀)
    (hall_nd : (servSlots ++ (List.finRange cp.D_max).flatMap (fun r' =>
      jobUsedSlots (Function.update curJobs r (some outJb) r')
        (Function.update readySlots r rSlots' r')
        (Function.update curSlots r cSlot' r'))).Nodup)
    (hall_lt : ∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap (fun r' =>
      jobUsedSlots (Function.update curJobs r (some outJb) r')
        (Function.update readySlots r rSlots' r')
        (Function.update curSlots r cSlot' r')), s < M_slots cp)
    (hcode :
      (wRead m₀ engScrTbl 10 = 1 ∧ newOv = false ∧
        EncSparseSet cp.n (jobMetaBase cp r.val + 5)
          (snapElemOff cp r.val) (snapPosOff cp r.val) newLeaf m₀) ∨
      (wRead m₀ engScrTbl 10 = 2 ∧ newOv = false ∧
        ∃ (u_done : MNode cp) (uSlot : ℕ),
          uSlot < M_slots cp ∧
          wRead m₀ engMetaTbl (jobMetaBase cp r.val + 7) = (uSlot : ℤ) ∧
          ops.EncNode u_done uSlot m₀ ∧
          u_done.resArr = newLeaf) ∨
      (wRead m₀ engScrTbl 10 = 3 ∧ newOv = true ∧ newLeaf = [])) :
    let serving₂ := servBefore.take r.val ++ newSuf
    let servSlots₂ := servSlots.take r.val ++ rSlots'
    let jobs₂ := Function.update curJobs r none
    let rSlots₂ := Function.update readySlots r []
    let cSlots₂ := Function.update curSlots r 0
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (commitJobStage2Stmt ops r) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        wRead m₁ engScrTbl 0 = 1 ∧
        wRead m₁ engMetaTbl 1 = (if newOv then 1 else 0) ∧
        newLeaf.length ≤ cp.B_scan + 1 ∧
        EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) newLeaf m₁ ∧
        serving₂.length ≤ cp.D_max ∧
        wRead m₁ engMetaTbl 0 = (serving₂.length : ℤ) ∧
        servSlots₂.length = serving₂.length ∧
        (∀ i (hi : i < serving₂.length) (his : i < servSlots₂.length),
          wRead m₁ engMetaTbl (servSlotOff i) = (servSlots₂[i]'his : ℤ) ∧
          ops.EncNode (serving₂[i]'hi) (servSlots₂[i]'his) m₁) ∧
        (∀ r' : Fin cp.D_max, EncJobSlot ops r' (jobs₂ r') (rSlots₂ r') (cSlots₂ r') m₁) ∧
        (servSlots₂ ++ (List.finRange cp.D_max).flatMap
          (fun r' => jobUsedSlots (jobs₂ r') (rSlots₂ r') (cSlots₂ r'))).Nodup ∧
        (∀ s ∈ servSlots₂ ++ (List.finRange cp.D_max).flatMap
          (fun r' => jobUsedSlots (jobs₂ r') (rSlots₂ r') (cSlots₂ r')), s < M_slots cp) ∧
        (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i : ℤ, (i = 3 ∨ i = 4 ∨ i = 5) → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (commitJobStage2Cost ops) := by
  intro serving₂ servSlots₂ jobs₂ rSlots₂ cSlots₂
  have hTW := ops.hTW
  have hBW_meta := ops.hBW_meta
  have hBW_scr := ops.hBW_scr
  let C_disp : ℕ := 130 + ops.C_read + cp.B_scan * (ops.C_read + 130)
  let C_spl : ℕ := 60 + cp.D_max * 30
  unfold commitJobStage2Stmt commitJobStage2Cost
  refine ExecDet.seq' (C_disp + C_spl + 12)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 0) (.lit 1) 0 1 hfp₀
      (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
      rfl rfl (by simp [intExprOps]) rfl)
    (by dsimp only [C_disp, C_spl]; omega) ?_
  intro mA hmA hfpA; subst hmA
  set mA_st := H3a.wWrite m₀ engScrTbl 0 1
  have hw9_A : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mA_st t i = wRead m₀ t i :=
    fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
  have hr_A : ∀ t i, rRead mA_st t i = rRead m₀ t i := fun _ _ => rRead_wWrite _ _ _ _ _ _
  have hsrA : ops.SlotsReady mA_st := ops.slotsReady_ext m₀ mA_st hsr₀ hw9_A (fun t _ _ i => hr_A t i)
  have hndA : ∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s mA_st :=
    fun mn s _ he => ops.encNode_ext mn s m₀ mA_st he hw9_A (fun t _ _ i => hr_A t i)
      (fun _ _ _ _ => hr_A ptsRTbl _)
  have hr10_A : wRead mA_st engScrTbl 10 = wRead m₀ engScrTbl 10 :=
    wRead_wWrite_of_ne _ _ (Or.inr (by decide))
  let PostLeaf (mB : ArithRAMMemory) : Prop :=
    ops.SlotsReady mB ∧
    wRead mB engScrTbl 0 = 1 ∧
    wRead mB engMetaTbl 1 = (if newOv then 1 else 0) ∧
    newLeaf.length ≤ cp.B_scan + 1 ∧
    EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) newLeaf mB ∧
    (∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s mB) ∧
    (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead mB t i = wRead m₀ t i) ∧
    (∀ i, i ≠ 1 → i ≠ 2 → wRead mB engMetaTbl i = wRead m₀ engMetaTbl i) ∧
    (∀ i, 2 * (S_stride cp : ℤ) ≤ i → wRead mB engArrTbl i = wRead m₀ engArrTbl i) ∧
    (∀ t < 3, ∀ i, rRead mB t i = rRead m₀ t i)
  have hDisp : ExecDet ops.TW ops.BW ops.TR ops.BR inp (commitLeafDispatchStage2Stmt ops r)
      mA_st PostLeaf C_disp := by
    unfold commitLeafDispatchStage2Stmt
    rcases hcode with ⟨hc1, hnov, hsnap⟩ | ⟨hc2, hnov, u_done, uSlot, huM, hw7, henc_u, hres_eq⟩ | ⟨hc3, hov, hnil⟩
    · have hcond1 : (evalArithCond inp 0 mA_st (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 1))).1 = true := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mA_st engScrTbl 10 = 1) = true
        rw [hr10_A, hc1]; decide
      refine ExecDet.ite' (C_c := 8) (C_b := (80 + cp.B_scan * 130) + 12) _ _ _ hcond1
        (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
        (by dsimp only [C_disp]; have := Nat.mul_le_mul_left cp.B_scan (show 130 ≤ ops.C_read + 130 by omega); have := Nat.mul_le_mul_left cp.B_scan (show ops.C_read + 120 ≤ ops.C_read + 130 by omega); omega)
      have hsnapA : EncSparseSet cp.n (jobMetaBase cp r.val + 5) (snapElemOff cp r.val) (snapPosOff cp r.val)
          newLeaf mA_st :=
        hsnap.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
      refine ExecDet.seq (C₂ := 12)
        (exec_copySnapToLeafStmt ops inp r hfpA hsrA hsnapA (hleaf_spec hnov).2.2) ?_
      intro mC ⟨hsrC, hlfC, hndC, hftC, hfmC, hfaC, hfsC, hfrC⟩ hfpC
      refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 1) (.lit 0) 1 0 hfpC
        (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) ?_
      set mB := H3a.wWrite mC engMetaTbl 1 0
      have hw9_BC : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mB t i = wRead mC t i :=
        fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))
      refine ⟨ops.slotsReady_ext mC mB hsrC hw9_BC (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
        (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfsC 0 (by omega)).trans (wRead_wWrite_self _ _ _ _)),
        by rw [hnov]; exact wRead_wWrite_self _ _ _ _,
        by have := (hleaf_spec hnov).2.2; omega,
        hlfC.ext (wRead_wWrite_of_ne _ _ (Or.inr (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide))),
        fun mn s hs he0 => ops.encNode_ext mn s mC mB (hndC mn s hs (hndA mn s hs he0))
          hw9_BC (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
        fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht1)).trans
          ((hftC t ht1 ht2 ht3 i).trans (wRead_wWrite_of_ne _ _ (Or.inl ht3))),
        fun i hi1 hi2 => (wRead_wWrite_of_ne _ _ (Or.inr hi1)).trans
          ((hfmC i hi2).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))),
        fun i hi => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfaC i hi).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))),
        fun t _ i => (rRead_wWrite _ _ _ _ _ _).trans ((hfrC t i).trans (hr_A t i))⟩
    · have hcond1 : (evalArithCond inp 0 mA_st (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 1))).1 = false := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mA_st engScrTbl 10 = 1) = false
        rw [hr10_A, hc2]; decide
      refine ExecDet.ite' (C_c := 8) (C_b := 12 + (80 + ops.C_read + cp.B_scan * (ops.C_read + 120)) + 20)
        _ _ _ hcond1 (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
        (by dsimp only [C_disp]; have := Nat.mul_le_mul_left cp.B_scan (show 130 ≤ ops.C_read + 130 by omega); have := Nat.mul_le_mul_left cp.B_scan (show ops.C_read + 120 ≤ ops.C_read + 130 by omega); omega)
      have hcond2 : (evalArithCond inp 0 mA_st (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 2))).1 = true := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mA_st engScrTbl 10 = 2) = true
        rw [hr10_A, hc2]; decide
      refine ExecDet.ite' (C_c := 8) (C_b := 12 + (80 + ops.C_read + cp.B_scan * (ops.C_read + 120)) + 12)
        _ _ _ hcond2 (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
        (by omega)
      have hw7_A : wRead mA_st engMetaTbl (jobMetaBase cp r.val + 7) = (uSlot : ℤ) :=
        (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hw7
      refine ExecDet.seq' ((80 + ops.C_read + cp.B_scan * (ops.C_read + 120)) + 12)
        (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 11)
          (.readHeap engMetaTbl (.lit (jobMetaBase cp r.val + 7))) 11 (uSlot : ℤ) hfpA
          (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
          rfl (by simp only [evalIntExpr]; exact hw7_A) (by simp [intExprOps]) rfl)
        (by omega) ?_
      intro mD hmD hfpD; subst hmD
      set mD_st := H3a.wWrite mA_st engScrTbl 11 (uSlot : ℤ)
      have hw9_D : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mD_st t i = wRead mA_st t i :=
        fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
      have hsrD : ops.SlotsReady mD_st :=
        ops.slotsReady_ext mA_st mD_st hsrA hw9_D (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
      have hndD : ∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s mD_st :=
        fun mn s hs he0 => ops.encNode_ext mn s mA_st mD_st (hndA mn s hs he0) hw9_D
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
      rcases hleaf_spec hnov with ⟨hnd_lf, hlt_lf, hlen_lf⟩
      refine ExecDet.seq (C₂ := 12)
        (exec_copyNodeResToLeafStmt ops inp 11 (by omega) (by omega) huM hfpD hsrD
          (hndD u_done uSlot huM henc_u) (wRead_wWrite_self _ _ _ _)
          (hres_eq ▸ hnd_lf) (hres_eq ▸ hlt_lf) (hres_eq ▸ hlen_lf)) ?_
      intro mC ⟨hsrC, hlfC, hndC, hftC, hfmC, hfaC, hfsC, hfrC⟩ hfpC
      rw [hres_eq] at hlfC
      refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 1) (.lit 0) 1 0 hfpC
        (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) ?_
      set mB := H3a.wWrite mC engMetaTbl 1 0
      have hw9_BC : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mB t i = wRead mC t i :=
        fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))
      refine ⟨ops.slotsReady_ext mC mB hsrC hw9_BC (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
        (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfsC 0 (by omega)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
            (wRead_wWrite_self _ _ _ _))),
        by rw [hnov]; exact wRead_wWrite_self _ _ _ _,
        by omega,
        hlfC.ext (wRead_wWrite_of_ne _ _ (Or.inr (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide))),
        fun mn s hs he0 => ops.encNode_ext mn s mC mB (hndC mn s hs (hndD mn s hs he0))
          hw9_BC (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
        fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht1)).trans
          ((hftC t ht9 ht1 ht2 ht3 i).trans ((wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans
            (wRead_wWrite_of_ne _ _ (Or.inl ht3)))),
        fun i hi1 hi2 => (wRead_wWrite_of_ne _ _ (Or.inr hi1)).trans
          ((hfmC i hi2).trans ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
            (wRead_wWrite_of_ne _ _ (Or.inl (by decide))))),
        fun i hi => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfaC i hi).trans ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
            (wRead_wWrite_of_ne _ _ (Or.inl (by decide))))),
        fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans
          ((hfrC t ht3 i).trans ((rRead_wWrite _ _ _ _ _ _).trans (hr_A t i)))⟩
    · have hcond1 : (evalArithCond inp 0 mA_st (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 1))).1 = false := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mA_st engScrTbl 10 = 1) = false
        rw [hr10_A, hc3]; decide
      refine ExecDet.ite' (C_c := 8) (C_b := 32) _ _ _ hcond1
        (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
        (by dsimp only [C_disp]; omega)
      have hcond2 : (evalArithCond inp 0 mA_st (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 2))).1 = false := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mA_st engScrTbl 10 = 2) = false
        rw [hr10_A, hc3]; decide
      refine ExecDet.ite' (C_c := 8) (C_b := 24) _ _ _ hcond2
        (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_) (by omega)
      refine ExecDet.seq' 12
        (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 2) (.lit 0) 2 0 hfpA
          (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
        (by omega) ?_
      intro mC hmC hfpC; subst hmC
      refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 1) (.lit 1) 1 1 hfpC
        (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) ?_
      set mB := H3a.wWrite (H3a.wWrite mA_st engMetaTbl 2 0) engMetaTbl 1 1
      have hw9_B : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mB t i = wRead mA_st t i :=
        fun t ht9 _ i => (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))).trans
          (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega)))
      refine ⟨ops.slotsReady_ext mA_st mB hsrA hw9_B (fun _ _ _ _ =>
          (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _)),
        (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (wRead_wWrite_self _ _ _ _)),
        by rw [hov]; exact wRead_wWrite_self _ _ _ _,
        by simp [hnil],
        hnil ▸ encSparseSet_empty_of_zero
          ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _)),
        fun mn s hs he0 => ops.encNode_ext mn s mA_st mB (hndA mn s hs he0) hw9_B
          (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
          (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _)),
        fun t _ ht1 _ ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht1)).trans
          ((wRead_wWrite_of_ne _ _ (Or.inl ht1)).trans (wRead_wWrite_of_ne _ _ (Or.inl ht3))),
        fun i hi1 hi2 => (wRead_wWrite_of_ne _ _ (Or.inr hi1)).trans
          ((wRead_wWrite_of_ne _ _ (Or.inr hi2)).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))),
        fun i _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))),
        fun t _ i => (rRead_wWrite _ _ _ _ _ _).trans ((rRead_wWrite _ _ _ _ _ _).trans (hr_A t i))⟩
  refine ExecDet.seq' (C_spl + 12) hDisp (by omega) ?_
  intro mB ⟨hsrB, hr0B, hovB, hlf_leB, hlf_spB, hndB, hftB, hfmB, hfaB, hfrB⟩ hfpB
  have hr_serv_sl : r.val ≤ servSlots.length := hslen ▸ hr_serv
  refine ExecDet.seq (C₂ := 12)
    (exec_spliceReadyToServStmt ops inp r hfpB hsrB hr_serv_sl (hrlen_eq ▸ hr_sum)
      ((hfmB (jobMetaBase cp r.val + 1) (by unfold jobMetaBase; omega) (by unfold jobMetaBase; omega)).trans
        (hrlen_eq.symm ▸ hw_rlen))
      (fun i hi => (hfmB (servSlotOff i) (by unfold servSlotOff; omega) (by unfold servSlotOff; omega)).trans
        (hserv_pre i hi).1)
      (fun q hq => by
        have hnn : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) := by positivity
        exact (hfmB (readySlotOff cp r.val q)
          (by unfold readySlotOff; omega) (by unfold readySlotOff; omega)).trans
          (hready_enc q (hrlen_eq ▸ hq) hq).1)) ?_
  intro mS ⟨hsrS, hslenS, hw0S, hservS, hndS, hftS, hfmS, hfsS, hfrS⟩ hfpS
  let midJobs := Function.update curJobs r (some outJb)
  let midRSlots := Function.update readySlots r rSlots'
  let midCSlots := Function.update curSlots r cSlot'
  have hjobs_enc_S : ∀ r' : Fin cp.D_max,
      EncJobSlot ops r' (midJobs r') (midRSlots r') (midCSlots r') mS := by
    intro r'
    refine (hjobs_enc r') |> fun hj0 => ?_
    -- Preserve `EncJobSlot` across `m₀ → mB → mS` for all `r'`
    have hw6_r' : ∀ k : ℤ, 0 ≤ k → k < 8 →
        wRead mS engMetaTbl (jobMetaBase cp r'.val + k) =
          wRead m₀ engMetaTbl (jobMetaBase cp r'.val + k) := fun k hk0 hk8 =>
      (hfmS _ (by unfold jobMetaBase; omega) (by unfold jobMetaBase; omega)).trans
        (hfmB _ (by unfold jobMetaBase; omega) (by unfold jobMetaBase; omega))
    have hw_rd_r' : ∀ q < cp.D_max,
        wRead mS engMetaTbl (readySlotOff cp r'.val q) =
          wRead m₀ engMetaTbl (readySlotOff cp r'.val q) := fun q hq => by
      have hnn : 0 ≤ (r'.val : ℤ) * (cp.D_max : ℤ) := by positivity
      exact (hfmS _ (by unfold readySlotOff; omega) (by unfold readySlotOff; omega)).trans
        (hfmB _ (by unfold readySlotOff; omega) (by unfold readySlotOff; omega))
    have hw_arr_S : ∀ b : ℕ, 2 ≤ b → ∀ k : ℤ, 0 ≤ k → k < (cp.n : ℤ) →
        wRead mS engArrTbl (((b * S_stride cp : ℕ) : ℤ) + k) =
          wRead m₀ engArrTbl (((b * S_stride cp : ℕ) : ℤ) + k) := by
      intro b hb2 k hk0 _
      have hm : 2 * S_stride cp ≤ b * S_stride cp := Nat.mul_le_mul_right _ hb2
      have hmZ : 2 * (S_stride cp : ℤ) ≤ ((b * S_stride cp : ℕ) : ℤ) := by exact_mod_cast hm
      exact (hftS engArrTbl (by decide) (by decide) _).trans (hfaB _ (by omega))
    have hu_lt_r' : ∀ s ∈ jobUsedSlots (midJobs r') (midRSlots r') (midCSlots r'), s < M_slots cp :=
      fun s hs => hall_lt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r', hs⟩))
    dsimp only [midJobs, midRSlots, midCSlots] at hj0 hu_lt_r' ⊢
    cases hmj : Function.update curJobs r (some outJb) r' with
    | none =>
        simp only [EncJobSlot, hmj] at hj0 ⊢
        exact ⟨hj0.1, (hw6_r' 0 (by omega) (by omega)).trans hj0.2⟩
    | some jb' =>
        simp only [EncJobSlot, hmj] at hj0 ⊢
        rcases hj0 with ⟨ha0, hrle0, hrlen0, hw1_0, hrd0, hph0⟩
        refine ⟨(hw6_r' 0 (by omega) (by omega)).trans ha0, hrle0, hrlen0,
          (hw6_r' 1 (by omega) (by omega)).trans hw1_0,
          fun q hq hqs => ⟨(hw_rd_r' q (lt_of_lt_of_le hq hrle0)).trans (hrd0 q hq hqs).1,
            hndS _ _ (hu_lt_r' _ (by
              simp only [jobUsedSlots, hmj]
              cases jb'.phase with
              | copy _ => exact List.getElem_mem hqs
              | build _ => exact List.mem_append_left _ (List.getElem_mem hqs)))
              (hndB _ _ (hu_lt_r' _ (by
                simp only [jobUsedSlots, hmj]
                cases jb'.phase with
                | copy _ => exact List.getElem_mem hqs
                | build _ => exact List.mem_append_left _ (List.getElem_mem hqs)))
                (hrd0 q hq hqs).2)⟩, ?_⟩
        cases hjp' : jb'.phase with
        | copy cs =>
            simp only [hjp'] at hph0 ⊢
            rcases hph0 with ⟨hp2, hp3, hp4, hsp⟩
            exact ⟨(hw6_r' 2 (by omega) (by omega)).trans hp2,
              (hw6_r' 3 (by omega) (by omega)).trans hp3,
              (hw6_r' 4 (by omega) (by omega)).trans hp4,
              hsp.ext (hw6_r' 5 (by omega) (by omega))
                (fun k hk => hw_arr_S (2 + 4 * r'.val) (by omega) (k : ℤ) (by positivity)
                  (Int.ofNat_lt.mpr (lt_of_lt_of_le hk hsp.length_le)))
                (fun y hy => hw_arr_S (3 + 4 * r'.val) (by omega) (y : ℤ) (by positivity)
                  (Int.ofNat_lt.mpr (hsp.2.1 y hy)))⟩
        | build bs =>
            simp only [hjp'] at hph0 ⊢
            rcases hph0 with ⟨hp2, hp3, hp4, hsp, hdsp, hc7, hcenc⟩
            have hc_lt : Function.update curSlots r cSlot' r' < M_slots cp := hu_lt_r' _ (by
              simp [jobUsedSlots, hmj, hjp'])
            exact ⟨(hw6_r' 2 (by omega) (by omega)).trans hp2,
              (hw6_r' 3 (by omega) (by omega)).trans hp3,
              (hw6_r' 4 (by omega) (by omega)).trans hp4,
              hsp.ext (hw6_r' 5 (by omega) (by omega))
                (fun k hk => hw_arr_S (2 + 4 * r'.val) (by omega) (k : ℤ) (by positivity)
                  (Int.ofNat_lt.mpr (lt_of_lt_of_le hk hsp.length_le)))
                (fun y hy => hw_arr_S (3 + 4 * r'.val) (by omega) (y : ℤ) (by positivity)
                  (Int.ofNat_lt.mpr (hsp.2.1 y hy))),
              hdsp.ext (hw6_r' 6 (by omega) (by omega))
                (fun k hk => hw_arr_S (4 + 4 * r'.val) (by omega) (k : ℤ) (by positivity)
                  (Int.ofNat_lt.mpr (lt_of_lt_of_le hk hdsp.length_le)))
                (fun y hy => hw_arr_S (5 + 4 * r'.val) (by omega) (y : ℤ) (by positivity)
                  (Int.ofNat_lt.mpr (hdsp.2.1 y hy))),
              (hw6_r' 7 (by omega) (by omega)).trans hc7,
              hndS _ _ hc_lt (hndB _ _ hc_lt hcenc)⟩
  have hall₂ := allSlots_nodup_commit (D := cp.D_max) (M := M_slots cp)
    (servSlots := servSlots)
    (U := fun r' => jobUsedSlots (midJobs r') (midRSlots r') (midCSlots r'))
    (U' := fun r' => jobUsedSlots (jobs₂ r') (rSlots₂ r') (cSlots₂ r'))
    r hall_nd hall_lt
    (fun r' hne => by simp [midJobs, midRSlots, midCSlots, jobs₂, rSlots₂, cSlots₂, Function.update_of_ne hne])
    (by simp [jobs₂, rSlots₂, cSlots₂, jobUsedSlots])
  have hU_r_eq : jobUsedSlots (midJobs r) (midRSlots r) (midCSlots r) = rSlots' := by
    simpa [midJobs, midRSlots, midCSlots] using hused_eq
  dsimp only at hall₂
  rw [hU_r_eq] at hall₂
  have hr_lt := r.isLt
  have hD2 : 0 ≤ cp.D_max * cp.D_max := Nat.zero_le _
  unfold cancelJobSlotStage2Stmt
  refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (jobMetaBase cp r.val)) (.lit 0)
    (jobMetaBase cp r.val) 0 hfpS
    (by unfold engMetaTbl; omega) (by unfold jobMetaBase; omega)
    (by unfold jobMetaBase; nlinarith [hr_lt, hBW_meta, hD2])
    rfl rfl (by simp [intExprOps]) ?_
  set m₁ := H3a.wWrite mS engMetaTbl (jobMetaBase cp r.val) 0
  have hw9_1S : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m₁ t i = wRead mS t i :=
    fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))
  have hnd_10 : ∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁ :=
    fun mn s hs he0 => ops.encNode_ext mn s mS m₁ (hndS mn s hs (hndB mn s hs he0))
      hw9_1S (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
  have hserv2_len : serving₂.length = r.val + newSuf.length := by
    simp [serving₂, List.length_take_of_le hr_serv]
  have hslen2_eq : servSlots₂.length = serving₂.length := by
    rw [hslenS, hserv2_len, hrlen_eq]
  refine ⟨ops.slotsReady_ext mS m₁ hsrS hw9_1S (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
    (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans ((hfsS 0 (by omega)).trans hr0B),
    (wRead_wWrite_of_ne _ _ (Or.inr (by unfold jobMetaBase; omega))).trans
      ((hfmS 1 (by decide) (by omega)).trans hovB),
    hlf_leB,
    hlf_spB.ext
      ((wRead_wWrite_of_ne _ _ (Or.inr (by unfold jobMetaBase; omega))).trans
        (hfmS 2 (by decide) (by omega)))
      (fun _ _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hftS engArrTbl (by decide) (by decide) _))
      (fun _ _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hftS engArrTbl (by decide) (by decide) _)),
    hserv2_len ▸ hr_sum,
    (wRead_wWrite_of_ne _ _ (Or.inr (by unfold jobMetaBase; omega))).trans
      (by rw [hw0S, hserv2_len, hrlen_eq]),
    hslen2_eq,
    fun i hi his => ?_,
    fun r' => ?_,
    hall₂.1, hall₂.2,
    fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht1)).trans
      ((hftS t ht1 ht3 i).trans (hftB t ht9 ht1 ht2 ht3 i)),
    fun i hi345 => (wRead_wWrite_of_ne _ _ (Or.inr (by unfold jobMetaBase; omega))).trans
      ((hfmS i (by omega) (by omega)).trans (hfmB i (by omega) (by omega))),
    fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans ((hfrS t i).trans (hfrB t ht3 i))⟩
  · have hw_si : wRead m₁ engMetaTbl (servSlotOff i) = (servSlots₂[i]'his : ℤ) :=
      (wRead_wWrite_of_ne _ _ (Or.inr (by
        have hiD : i < cp.D_max := lt_of_lt_of_le hi (hserv2_len ▸ hr_sum)
        unfold servSlotOff jobMetaBase; omega))).trans (hservS i his)
    refine ⟨hw_si, ?_⟩
    have htk_len : (servBefore.take r.val).length = r.val := List.length_take_of_le hr_serv
    have htk_sl : (servSlots.take r.val).length = r.val := List.length_take_of_le hr_serv_sl
    by_cases hi_r : i < r.val
    · have hi_tk1 : i < (servBefore.take r.val).length := by omega
      have hi_tk2 : i < (servSlots.take r.val).length := by omega
      have hg1 : serving₂[i]'hi = servBefore[i]'(lt_of_lt_of_le hi_r hr_serv) := by
        dsimp only [serving₂]; rw [List.getElem_append_left hi_tk1, List.getElem_take]
      have hg2 : servSlots₂[i]'his = servSlots[i]'(lt_of_lt_of_le hi_r hr_serv_sl) := by
        dsimp only [servSlots₂]; rw [List.getElem_append_left hi_tk2, List.getElem_take]
      have hs_lt : servSlots[i]'(lt_of_lt_of_le hi_r hr_serv_sl) < M_slots cp :=
        hall_lt _ (List.mem_append_left _ (List.getElem_mem _))
      rw [hg1, hg2]
      exact hnd_10 _ _ hs_lt (hserv_pre i hi_r).2
    · have hq_lt : i - r.val < newSuf.length := by rw [hserv2_len] at hi; omega
      have hqs_lt : i - r.val < rSlots'.length := hrlen_eq ▸ hq_lt
      have hg1 : serving₂[i]'hi = newSuf[i - r.val]'hq_lt := by
        dsimp only [serving₂]; rw [List.getElem_append_right (by omega)]; congr 1; omega
      have hg2 : servSlots₂[i]'his = rSlots'[i - r.val]'hqs_lt := by
        dsimp only [servSlots₂]; rw [List.getElem_append_right (by omega)]; congr 1; omega
      have hs_lt : rSlots'[i - r.val]'hqs_lt < M_slots cp := by
        apply hall_lt
        apply List.mem_append_right
        refine flatMap_mem_iff_finRange.mpr ⟨r, ?_⟩
        rw [hU_r_eq]; exact List.getElem_mem hqs_lt
      rw [hg1, hg2]
      exact hnd_10 _ _ hs_lt (hready_enc (i - r.val) hq_lt hqs_lt).2
  · by_cases heq : r' = r
    · subst heq
      dsimp only [jobs₂, rSlots₂, cSlots₂]
      simp only [Function.update_self, EncJobSlot]
      exact ⟨trivial, wRead_wWrite_self _ _ _ _⟩
    · have hjS := hjobs_enc_S r'
      have hupd_j : jobs₂ r' = midJobs r' := by simp [jobs₂, midJobs, Function.update_of_ne heq]
      have hupd_r : rSlots₂ r' = midRSlots r' := by simp [rSlots₂, midRSlots, Function.update_of_ne heq]
      have hupd_c : cSlots₂ r' = midCSlots r' := by simp [cSlots₂, midCSlots, Function.update_of_ne heq]
      rw [hupd_j, hupd_r, hupd_c]
      have hfm_1S : ∀ i, ¬ InJobMetaRegion cp r.val i → wRead m₁ engMetaTbl i = wRead mS engMetaTbl i := by
        intro i hnot
        exact wRead_wWrite_of_ne _ _ (Or.inr (fun h0 => hnot (Or.inl ⟨by omega, by omega⟩)))
      exact encJobSlot_other_of_frame heq hjS
        (fun s hs => hall_lt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r', hs⟩)))
        hfm_1S
        (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun mn' s hs _ heS => ops.encNode_ext mn' s mS m₁ heS hw9_1S
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))

end UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage2
