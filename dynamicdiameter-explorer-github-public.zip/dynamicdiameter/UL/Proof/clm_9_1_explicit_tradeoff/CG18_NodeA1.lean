import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Proof.lem_7_2.RacerP33_H1_RAM
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
import UL.Proof.clm_9_1_explicit_tradeoff.H3b2_GaussRAM
import UL.Proof.clm_9_1_explicit_tradeoff.H4b_DyadicMatching
import UL.Proof.clm_9_1_explicit_tradeoff.H4c1_NodePrim
import UL.Proof.clm_9_1_explicit_tradeoff.H4c2_ChainSched
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3b_JobStep
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3c_ChainEngine
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H1_Bridge
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H2b_SwapPool
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H2c_RadTree

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

/-! ### 1. `ZeroRandStmt` Bridge & Combinators -/

theorem hzr_to_zeroRand {s : ArithRAMStmt} (h : HeapZeroRandStmt s) : ZeroRandStmt s := by
  induction h with
  | skip => exact .skip
  | writeWordHeap t idx val => exact .writeWordHeap t idx val
  | writeRealHeap t idx val => exact .writeRealHeap t idx val
  | seq _ _ ih₁ ih₂ => exact .seq ih₁ ih₂
  | ite _ _ ih₁ ih₂ => exact .ite ih₁ ih₂
  | repeatN _ ih => exact .repeatN ih

theorem zeroRand_forLoopStmt (t : ℕ) (idx : ℤ) (N : ℕ) {b : ArithRAMStmt}
    (hb : ZeroRandStmt b) : ZeroRandStmt (forLoopStmt t idx N b) :=
  .seq (.writeWordHeap _ _ _) (.repeatN (.seq hb (.writeWordHeap _ _ _)))

theorem hzr_swapPoolClearStmt (tbl : ℕ) (baseE newEpE : IntExpr) :
    HeapZeroRandStmt (swapPoolClearStmt tbl baseE newEpE) := by
  unfold swapPoolClearStmt
  exact .seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)

theorem hzr_swapPoolMemStmt (scrW tbl : ℕ) (wPoolBase wUid wScr wOut : ℤ) (n : ℕ) :
    HeapZeroRandStmt (swapPoolMemStmt scrW tbl wPoolBase wUid wScr wOut n) := by
  unfold swapPoolMemStmt
  repeat' constructor

theorem hzr_swapPoolInsertStmt (scrW tbl : ℕ) (wPoolBase wUid wScr : ℤ) (n : ℕ) :
    HeapZeroRandStmt (swapPoolInsertStmt scrW tbl wPoolBase wUid wScr n) := by
  unfold swapPoolInsertStmt
  refine .seq (hzr_swapPoolMemStmt _ _ _ _ _ _ _) (.seq (.writeWordHeap _ _ _) (.ite .skip ?_))
  repeat' constructor

theorem hzr_swapPoolDeleteStmt (scrW tbl : ℕ) (wPoolBase wUid wScr : ℤ) (n : ℕ) :
    HeapZeroRandStmt (swapPoolDeleteStmt scrW tbl wPoolBase wUid wScr n) := by
  unfold swapPoolDeleteStmt
  refine .seq (hzr_swapPoolMemStmt _ _ _ _ _ _ _) (.ite ?_ .skip)
  repeat' constructor

theorem hzr_radTreeClearStmt (tblW : ℕ) (baseWE newEpE : IntExpr) :
    HeapZeroRandStmt (radTreeClearStmt tblW baseWE newEpE) :=
  .writeWordHeap _ _ _

theorem hzr_radTreeReadNodeStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wNode wHas wUid rSq : ℤ) :
    HeapZeroRandStmt (radTreeReadNodeStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHas wUid rSq) := by
  unfold radTreeReadNodeStmt
  repeat' constructor

theorem hzr_radTreeWriteNodeStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wNode wHas wUid rSq : ℤ) :
    HeapZeroRandStmt (radTreeWriteNodeStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHas wUid rSq) := by
  unfold radTreeWriteNodeStmt
  repeat' constructor

theorem hzr_radTreePrepLeafStmt (scrW scrR tblO : ℕ)
    (wOffO wUid wIns wScr rScr : ℤ) (d : ℕ) :
    HeapZeroRandStmt (radTreePrepLeafStmt scrW scrR tblO wOffO wUid wIns wScr rScr d) := by
  unfold radTreePrepLeafStmt
  repeat' constructor

theorem hzr_radTreePullStepStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wScr rScr : ℤ) :
    HeapZeroRandStmt (radTreePullStepStmt scrW scrR tblW tblR wBaseW wBaseR wScr rScr) := by
  unfold radTreePullStepStmt combineRadRegsStmt
  refine .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (hzr_radTreeReadNodeStmt _ _ _ _ _ _ _ _ _ _)
    (.seq (.writeWordHeap _ _ _)
    (.seq (hzr_radTreeReadNodeStmt _ _ _ _ _ _ _ _ _ _)
    (.seq ?_ (.seq (.writeWordHeap _ _ _) (hzr_radTreeWriteNodeStmt _ _ _ _ _ _ _ _ _ _)))))))
  repeat' constructor

theorem hzr_radTreeUpdateLeafStmt (scrW scrR tblW tblR tblO : ℕ)
    (wBaseW wBaseR wOffO wUid wIns wScr rScr : ℤ) (K_seg n d : ℕ) :
    HeapZeroRandStmt (radTreeUpdateLeafStmt scrW scrR tblW tblR tblO
      wBaseW wBaseR wOffO wUid wIns wScr rScr K_seg n d) := by
  unfold radTreeUpdateLeafStmt
  exact .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (hzr_radTreePrepLeafStmt _ _ _ _ _ _ _ _ _)
    (.seq (hzr_radTreeWriteNodeStmt _ _ _ _ _ _ _ _ _ _)
          (.repeatN (hzr_radTreePullStepStmt _ _ _ _ _ _ _ _))))))

theorem hzr_radTreeQueryRootStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wNode wHas wUid rSq : ℤ) :
    HeapZeroRandStmt (radTreeQueryRootStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHas wUid rSq) :=
  .seq (.writeWordHeap _ _ _) (hzr_radTreeReadNodeStmt _ _ _ _ _ _ _ _ _ _)

/-! ### 2. Exact `List ℕ` Semantics of `SwapPool` (`denseInsert` / `denseDelete`) & `SwapPoolReady` -/

def swapPoolToList (P : SwapPool) : List ℕ :=
  List.ofFn (fun i : Fin P.sz => P.arr i.val)

@[simp] theorem length_swapPoolToList (P : SwapPool) : (swapPoolToList P).length = P.sz := by
  simp [swapPoolToList]

@[simp] theorem getElem_swapPoolToList (P : SwapPool) (i : ℕ) (hi : i < (swapPoolToList P).length) :
    (swapPoolToList P)[i]'hi = P.arr i := by
  simp [swapPoolToList]

theorem swapPoolToList_clear (newEp : ℕ) (P : SwapPool) :
    swapPoolToList (P.clear newEp) = [] := by
  simp [swapPoolToList, SwapPool.clear]

theorem swapPoolToList_nodup_and_toFinset {n : ℕ} {S : Finset ℕ} {P : SwapPool}
    (hwf : P.WF n S) :
    (swapPoolToList P).Nodup ∧ (swapPoolToList P).toFinset = S ∧ (swapPoolToList P).length = S.card := by
  have hwf₀ := hwf
  obtain ⟨_, _, hsz, _, _, harr, hinjA, _⟩ := hwf₀
  refine ⟨?_, ?_, by simp [hsz]⟩
  · rw [List.nodup_iff_injective_getElem]
    intro i j heq
    have hi : i.val < P.sz := by simpa using i.isLt
    have hj : j.val < P.sz := by simpa using j.isLt
    simp only [getElem_swapPoolToList] at heq
    exact Fin.ext (hinjA i.val hi j.val hj heq)
  · ext x
    simp only [List.mem_toFinset, swapPoolToList, List.mem_ofFn]
    constructor
    · rintro ⟨i, rfl⟩
      exact (harr i.val i.isLt).1
    · intro hxS
      let r := (P.enum hwf).symm ⟨x, hxS⟩
      have hr : P.arr r.val = x := congrArg Subtype.val ((P.enum hwf).apply_symm_apply ⟨x, hxS⟩)
      exact ⟨⟨r.val, by omega⟩, hr⟩

theorem swapPoolToList_insert {n : ℕ} (hn : 1 ≤ n) {S : Finset ℕ} {P : SwapPool}
    {arr : List ℕ} (hwf : P.WF n S) (hlist : swapPoolToList P = arr)
    {p : ℕ} (hp_lt : p < n) (hp_not : p ∉ S) (hcap : S.card + 1 ≤ n)
    (hS_lt : ∀ x ∈ S, x < n) :
    (P.insert n p).WF n (Insert.insert p S) ∧
    swapPoolToList (P.insert n p) = denseInsert p arr := by
  have hfresh : ∀ x ∈ S, x % n ≠ p % n := by
    intro x hx heq
    rw [Nat.mod_eq_of_lt (hS_lt x hx), Nat.mod_eq_of_lt hp_lt] at heq
    exact hp_not (heq ▸ hx)
  have hwf' := P.wf_insert hn hwf hp_not hcap hfresh
  refine ⟨hwf', ?_⟩
  subst hlist
  have hnmem : ¬ P.memPred n p := fun hm => hp_not ((P.memPred_iff hn hwf p).mp hm)
  have hnle : ¬ n ≤ P.sz := by have := hwf.2.2.1; omega
  have hcond : ¬ (P.memPred n p ∨ n ≤ P.sz) := by tauto
  have hins_eq : P.insert n p =
      { ep := P.ep, sz := P.sz + 1,
        hEp := Function.update P.hEp (p % n) P.ep,
        pos := Function.update P.pos (p % n) P.sz,
        arr := Function.update P.arr P.sz p } := by
    unfold SwapPool.insert; rw [if_neg hcond]
  rw [hins_eq]
  unfold denseInsert
  apply List.ext_getElem
  · simp [swapPoolToList]
  · intro i hi₁ hi₂
    simp only [getElem_swapPoolToList]
    rcases Nat.lt_succ_iff_lt_or_eq.mp (by simpa [swapPoolToList] using hi₁ : i < P.sz + 1) with hlt | rfl
    · rw [Function.update_of_ne (by omega), List.getElem_append_left (by simpa using hlt)]
      simp
    · rw [Function.update_self, List.getElem_append_right (by simp)]
      simp

theorem swapPoolToList_delete {n : ℕ} (hn : 1 ≤ n) {S : Finset ℕ} {P : SwapPool}
    {arr : List ℕ} (hwf : P.WF n S) (hlist : swapPoolToList P = arr)
    {p : ℕ} (hp_lt : p < n) :
    (P.delete n p).WF n (S.erase p) ∧
    swapPoolToList (P.delete n p) = denseDelete p arr := by
  have hwf' := P.wf_delete hn hwf p
  refine ⟨hwf', ?_⟩
  obtain ⟨_, hfs, _⟩ := swapPoolToList_nodup_and_toFinset hwf
  subst hlist
  by_cases hmem : P.memPred n p
  · have hpS : p ∈ S := (P.memPred_iff hn hwf p).mp hmem
    have hp_in_l : p ∈ swapPoolToList P := List.mem_toFinset.mp (hfs.symm ▸ hpS)
    have hidx_lt_l : (swapPoolToList P).idxOf p < (swapPoolToList P).length :=
      List.idxOf_lt_length_of_mem hp_in_l
    have hidx_lt : (swapPoolToList P).idxOf p < P.sz := by simpa using hidx_lt_l
    have harr_idx : P.arr ((swapPoolToList P).idxOf p) = p := by
      rw [← getElem_swapPoolToList P _ hidx_lt_l]
      exact List.getElem_idxOf hidx_lt_l
    have hpos_eq : P.pos (p % n) = (swapPoolToList P).idxOf p := by
      have hp_arr := (hwf.2.2.2.2.2.1 ((swapPoolToList P).idxOf p) hidx_lt).2.2
      rwa [harr_idx] at hp_arr
    unfold SwapPool.delete denseDelete
    rw [if_pos hmem]
    dsimp only
    rw [dif_pos hidx_lt_l, hpos_eq]
    by_cases hlast : (swapPoolToList P).idxOf p = P.sz - 1
    · have hlast_l : (swapPoolToList P).idxOf p = (swapPoolToList P).length - 1 := by
        simpa using hlast
      rw [if_pos hlast, if_pos hlast_l]
      apply List.ext_getElem
      · simp [swapPoolToList]
      · intro i hi₁ hi₂
        simp [swapPoolToList]
    · have hlast_l : (swapPoolToList P).idxOf p ≠ (swapPoolToList P).length - 1 := by
        simpa using hlast
      rw [if_neg hlast, if_neg hlast_l]
      apply List.ext_getElem
      · simp [swapPoolToList]
      · intro i hi₁ hi₂
        simp only [getElem_swapPoolToList, List.getElem_set, List.getElem_take]
        by_cases hip : i = (swapPoolToList P).idxOf p
        · subst hip
          rw [Function.update_self, if_pos rfl]
          simp [swapPoolToList]
        · have hpi : ¬ (swapPoolToList P).idxOf p = i := fun h => hip h.symm
          rw [Function.update_of_ne hip, if_neg hpi]
  · have hp_notS : p ∉ S := fun hm => hmem ((P.memPred_iff hn hwf p).mpr hm)
    have hp_not_l : p ∉ swapPoolToList P := fun hm => hp_notS (hfs ▸ List.mem_toFinset.mpr hm)
    have hnot_lt : ¬ (swapPoolToList P).idxOf p < (swapPoolToList P).length := by
      intro hlt
      exact hp_not_l (List.getElem_idxOf hlt ▸ List.getElem_mem hlt)
    unfold SwapPool.delete denseDelete
    rw [if_neg hmem]
    dsimp only
    rw [dif_neg hnot_lt]

/-- Zero-init & reuse readiness predicate for an epoch-stamped `SwapPool` slice. -/
def SwapPoolReady (tbl : ℕ) (base : ℤ) (n : ℕ) (m : ArithRAMMemory) : Prop :=
  ∃ ep₀ : ℕ,
    H3a.wRead m tbl base = (ep₀ : ℤ) ∧
    ∀ (h : ℕ), h < n →
      0 ≤ H3a.wRead m tbl (base + 4 + (h : ℤ)) ∧
      H3a.wRead m tbl (base + 4 + (h : ℤ)) ≤ (ep₀ : ℤ) ∧
      0 ≤ H3a.wRead m tbl (base + 4 + (n : ℤ) + (h : ℤ))

theorem SwapPoolReady.of_zero {tbl : ℕ} {base : ℤ} {n : ℕ} {m : ArithRAMMemory}
    (hz : ∀ j : ℤ, 0 ≤ j → j < swapPoolStride n → H3a.wRead m tbl (base + j) = 0) :
    SwapPoolReady tbl base n m := by
  refine ⟨0, by simpa using hz 0 le_rfl (by dsimp [swapPoolStride]; omega), fun h hh => ?_⟩
  have h1 := hz (4 + (h : ℤ)) (by omega) (by dsimp [swapPoolStride]; omega)
  have h2 := hz (4 + (n : ℤ) + (h : ℤ)) (by omega) (by dsimp [swapPoolStride]; omega)
  have ha1 : base + 4 + (h : ℤ) = base + (4 + (h : ℤ)) := by ring
  have ha2 : base + 4 + (n : ℤ) + (h : ℤ) = base + (4 + (n : ℤ) + (h : ℤ)) := by ring
  rw [ha1, h1, ha2, h2]
  exact ⟨le_rfl, le_rfl, le_rfl⟩

theorem SwapPoolReady.of_enc {tbl : ℕ} {base : ℤ} {n : ℕ} {S : Finset ℕ} {P : SwapPool}
    {m : ArithRAMMemory} (hwf : P.WF n S) (henc : EncSwapPool tbl base n P m) :
    SwapPoolReady tbl base n m := by
  refine ⟨P.ep, henc.1, fun h hh => ?_⟩
  rw [henc.2.2.1 h hh, henc.2.2.2.1 h hh]
  exact ⟨Nat.cast_nonneg _, Nat.cast_le.mpr (hwf.2.1 h hh), Nat.cast_nonneg _⟩

theorem SwapPoolReady.mono_slice {tbl : ℕ} {base : ℤ} {n : ℕ} {m₀ m₁ : ArithRAMMemory}
    (hrdy : SwapPoolReady tbl base n m₀)
    (heq : ∀ i : ℤ, base ≤ i → i < base + swapPoolStride n → H3a.wRead m₁ tbl i = H3a.wRead m₀ tbl i) :
    SwapPoolReady tbl base n m₁ := by
  rcases hrdy with ⟨ep₀, hep, hh⟩
  refine ⟨ep₀, (heq base le_rfl (by dsimp [swapPoolStride]; omega)).trans hep, fun h hlt => ?_⟩
  rw [heq (base + 4 + (h : ℤ)) (by omega) (by dsimp [swapPoolStride]; omega),
      heq (base + 4 + (n : ℤ) + (h : ℤ)) (by omega) (by dsimp [swapPoolStride]; omega)]
  exact hh h hlt

def swapPoolBumpClearStmt (scrW tbl : ℕ) (wPoolBase : ℤ) : ArithRAMStmt :=
  let bE := IntExpr.readHeap scrW (.lit wPoolBase)
  swapPoolClearStmt tbl bE (.add (.readHeap tbl bE) (.lit 1))

theorem hzr_swapPoolBumpClearStmt (scrW tbl : ℕ) (wPoolBase : ℤ) :
    HeapZeroRandStmt (swapPoolBumpClearStmt scrW tbl wPoolBase) :=
  hzr_swapPoolClearStmt _ _ _

theorem exec_swapPoolBumpClearStmt {d TW BW TR BR scrW scrR tbl tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wPoolBase base : ℤ) (n : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : tbl < TW) (hneW : tbl ≠ scrW)
    (hbase : 0 ≤ base ∧ base + swapPoolStride n ≤ (BW : ℤ))
    (hb_r : H3a.wRead m₀ scrW wPoolBase = base)
    (hrdy : SwapPoolReady tbl base n m₀) :
    ∃ (P' : SwapPool) (m₁ : ArithRAMMemory),
      DetExec inp (swapPoolBumpClearStmt scrW tbl wPoolBase) m₀ m₁ 50 ∧
      InFootprint TW BW TR BR m₁ ∧
      P'.WF n ∅ ∧
      swapPoolToList P' = [] ∧
      EncSwapPool tbl base n P' m₁ ∧
      (∀ w, H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tbl base (swapPoolStride n) tblR 0 0 m₀ m₁ := by
  rcases hrdy with ⟨ep₀, hep, hh⟩
  let P₀ : SwapPool :=
    { ep := ep₀
      sz := 0
      hEp := fun h => if h < n then (H3a.wRead m₀ tbl (base + 4 + (h : ℤ))).toNat else 0
      pos := fun h => if h < n then (H3a.wRead m₀ tbl (base + 4 + (n : ℤ) + (h : ℤ))).toNat else 0
      arr := fun _ => 0 }
  let m_a := H3a.wWrite m₀ tbl base ((ep₀ + 1 : ℕ) : ℤ)
  let m₁ := H3a.wWrite m_a tbl (base + 1) 0
  have hd1 : DetExec inp (.writeWordHeap tbl (.readHeap scrW (.lit wPoolBase))
      (.add (.readHeap tbl (.readHeap scrW (.lit wPoolBase))) (.lit 1))) m₀ m_a 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ tbl _ _
      (by change H3a.wRead m₀ scrW wPoolBase = base; exact hb_r)
      (by change H3a.wRead m₀ tbl (H3a.wRead m₀ scrW wPoolBase) + 1 = ((ep₀ + 1 : ℕ) : ℤ)
          rw [hb_r, hep]; push_cast; ring)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfpa : InFootprint TW BW TR BR m_a :=
    InFootprint.wWrite hfp₀ htbl hbase.1 (by dsimp [swapPoolStride] at hbase; omega)
  have hb_ma : H3a.wRead m_a scrW wPoolBase = base := by
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hb_r]
  have hd2 : DetExec inp (.writeWordHeap tbl (.add (.readHeap scrW (.lit wPoolBase)) (.lit 1)) (.lit 0))
      m_a m₁ 25 :=
    DetExecAt.writeWordHeap 0 inp m_a tbl _ _
      (by change H3a.wRead m_a scrW wPoolBase + 1 = base + 1; rw [hb_ma])
      rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp₁ : InFootprint TW BW TR BR m₁ :=
    InFootprint.wWrite hfpa htbl (by omega) (by dsimp [swapPoolStride] at hbase; omega)
  let P' := P₀.clear (ep₀ + 1)
  have hwf' : P'.WF n ∅ := by
    unfold SwapPool.WF
    dsimp only [P', P₀, SwapPool.clear]
    refine ⟨by omega, fun h hlt => ?_, rfl, Nat.zero_le n,
      fun _ hx => by simp at hx, fun _ hr => by omega, fun _ hr => by omega,
      fun h hlt heq => ?_⟩
    · rw [if_pos hlt]
      have ⟨h0, hle, _⟩ := hh h hlt
      have hto : ((H3a.wRead m₀ tbl (base + 4 + (h : ℤ))).toNat : ℤ) =
          H3a.wRead m₀ tbl (base + 4 + (h : ℤ)) := Int.toNat_of_nonneg h0
      omega
    · rw [if_pos hlt] at heq
      have ⟨h0, hle, _⟩ := hh h hlt
      have hto : ((H3a.wRead m₀ tbl (base + 4 + (h : ℤ))).toNat : ℤ) =
          H3a.wRead m₀ tbl (base + 4 + (h : ℤ)) := Int.toNat_of_nonneg h0
      omega
  have henc' : EncSwapPool tbl base n P' m₁ := by
    unfold EncSwapPool
    dsimp only [P', P₀, SwapPool.clear]
    refine ⟨?_, wRead_wWrite_self _ _ _ _, fun h hlt => ?_, fun h hlt => ?_, fun _ hr => by omega⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
    · rw [if_pos hlt, wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact (Int.toNat_of_nonneg (hh h hlt).1).symm
    · rw [if_pos hlt, wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact (Int.toNat_of_nonneg (hh h hlt).2.2).symm
  refine ⟨P', m₁, (DetExecAt.seq hd1 hd2).mono_cost (by omega), hfp₁, hwf',
    swapPoolToList_clear (ep₀ + 1) P₀, henc', ?_, fun _ => rfl, ?_⟩
  · intro w
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
  · refine ⟨fun t i _ hout => ?_, fun _ _ _ _ => rfl⟩
    rcases hout with ht | hlt | hge
    · rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    · dsimp [swapPoolStride] at hge
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]

/-! ### 3. Exact Tie-Broken `RadTreeExactWF` (`maxRadiusHandle`) & `RadTreeReady` -/

noncomputable def liftRadOpt {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) : Option ℕ → Option (ℕ × ℝ) :=
  Option.map (fun u => (u, ‖pts u - o‖ ^ 2))

theorem combineRadOpt_lift {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (a b : Option ℕ) :
    combineRadOpt (liftRadOpt pts o a) (liftRadOpt pts o b) =
      liftRadOpt pts o (pickBetter pts o a b) := by
  cases a with
  | none => rfl
  | some u₁ =>
      cases b with
      | none => rfl
      | some u₂ =>
          dsimp [liftRadOpt, combineRadOpt, pickBetter]
          split_ifs <;> rfl

noncomputable def expectedRadAt {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (S : Finset ℕ) :
    ℕ → ℕ → Option (ℕ × ℝ)
  | 0, idx =>
      open Classical in
      if idx ∈ S then some (idx, ‖pts idx - o‖ ^ 2) else none
  | lvl + 1, idx =>
      combineRadOpt (expectedRadAt pts o S lvl (2 * idx))
                    (expectedRadAt pts o S lvl (2 * idx + 1))

private lemma foldl_pickBetter_shift {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (f : ℕ → Option ℕ) :
    ∀ (len : ℕ) (acc₀ : Option ℕ),
      (List.range len).foldl (fun acc k => pickBetter pts o acc (f k)) acc₀ =
        pickBetter pts o acc₀ ((List.range len).foldl (fun acc k => pickBetter pts o acc (f k)) none)
  | 0, acc₀ => by cases acc₀ <;> rfl
  | len + 1, acc₀ => by
      rw [List.range_succ, List.foldl_append, List.foldl_append, List.foldl_cons, List.foldl_nil,
          List.foldl_cons, List.foldl_nil]
      rw [foldl_pickBetter_shift pts o f len acc₀, pickBetter_assoc]

noncomputable def foldRadRange {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (S : Finset ℕ) (start len : ℕ) : Option ℕ :=
  open Classical in
  (List.range len).foldl
    (fun acc k => pickBetter pts o acc (if start + k ∈ S then some (start + k) else none)) none

private lemma foldRadRange_add {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (S : Finset ℕ) (start L₁ L₂ : ℕ) :
    foldRadRange pts o S start (L₁ + L₂) =
      pickBetter pts o (foldRadRange pts o S start L₁) (foldRadRange pts o S (start + L₁) L₂) := by
  classical
  unfold foldRadRange
  rw [List.range_add, List.foldl_append, List.foldl_map]
  have hfun : (fun acc (x : ℕ) => pickBetter pts o acc (if start + (L₁ + x) ∈ S then some (start + (L₁ + x)) else none)) =
      (fun acc (x : ℕ) => pickBetter pts o acc (if (start + L₁) + x ∈ S then some ((start + L₁) + x) else none)) := by
    funext acc x; rw [Nat.add_assoc]
  rw [hfun, foldl_pickBetter_shift]

theorem expectedRadAt_eq_foldRadRange {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (S : Finset ℕ) :
    ∀ (lvl idx : ℕ),
      expectedRadAt pts o S lvl idx = liftRadOpt pts o (foldRadRange pts o S (idx * 2 ^ lvl) (2 ^ lvl))
  | 0, idx => by
      classical
      unfold expectedRadAt foldRadRange liftRadOpt
      rw [Nat.pow_zero, Nat.mul_one]
      change (if idx ∈ S then some (idx, ‖pts idx - o‖ ^ 2) else none) =
        Option.map (fun u => (u, ‖pts u - o‖ ^ 2)) (pickBetter pts o none (if idx + 0 ∈ S then some (idx + 0) else none))
      rw [Nat.add_zero]
      split_ifs <;> rfl
  | lvl + 1, idx => by
      dsimp only [expectedRadAt]
      rw [expectedRadAt_eq_foldRadRange pts o S lvl (2 * idx),
          expectedRadAt_eq_foldRadRange pts o S lvl (2 * idx + 1),
          combineRadOpt_lift]
      have h1 : (2 * idx) * 2 ^ lvl = idx * 2 ^ (lvl + 1) := by rw [pow_succ]; ring
      have h2 : (2 * idx + 1) * 2 ^ lvl = idx * 2 ^ (lvl + 1) + 2 ^ lvl := by rw [pow_succ]; ring
      have h3 : 2 ^ (lvl + 1) = 2 ^ lvl + 2 ^ lvl := by rw [pow_succ]; ring
      rw [h1, h2, ← foldRadRange_add, ← h3]

theorem expectedRadAt_empty {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) :
    ∀ (lvl idx : ℕ), expectedRadAt pts o ∅ lvl idx = none
  | 0, _ => by simp [expectedRadAt]
  | lvl + 1, idx => by
      simp [expectedRadAt, expectedRadAt_empty pts o lvl (2 * idx),
            expectedRadAt_empty pts o lvl (2 * idx + 1), combineRadOpt]

theorem expectedRadAt_congr_outside {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) {S S' : Finset ℕ} {h : ℕ}
    (hdiff : ∀ x, x ≠ h → (x ∈ S' ↔ x ∈ S)) :
    ∀ (lvl idx : ℕ), idx ≠ h / 2 ^ lvl →
      expectedRadAt pts o S' lvl idx = expectedRadAt pts o S lvl idx
  | 0, idx, hne => by
      classical
      have hne0 : idx ≠ h := by simpa using hne
      unfold expectedRadAt
      by_cases hm : idx ∈ S'
      · rw [if_pos hm, if_pos ((hdiff idx hne0).mp hm)]
      · have hmS : idx ∉ S := fun hs => hm ((hdiff idx hne0).mpr hs)
        rw [if_neg hm, if_neg hmS]
  | lvl + 1, idx, hne => by
      have hneL : 2 * idx ≠ h / 2 ^ lvl := by
        intro heq
        apply hne
        rw [pow_succ, ← Nat.div_div_eq_div_mul, ← heq]
        omega
      have hneR : 2 * idx + 1 ≠ h / 2 ^ lvl := by
        intro heq
        apply hne
        rw [pow_succ, ← Nat.div_div_eq_div_mul, ← heq]
        omega
      dsimp [expectedRadAt]
      rw [expectedRadAt_congr_outside pts o hdiff lvl (2 * idx) hneL,
          expectedRadAt_congr_outside pts o hdiff lvl (2 * idx + 1) hneR]

theorem expectedRadAt_pts_congr {d : ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    (o : EuclideanSpace ℝ (Fin d)) {S : Finset ℕ} (heq : ∀ x ∈ S, pts' x = pts x) :
    ∀ (lvl idx : ℕ), expectedRadAt pts' o S lvl idx = expectedRadAt pts o S lvl idx
  | 0, idx => by
      classical
      dsimp [expectedRadAt]
      by_cases hm : idx ∈ S
      · rw [if_pos hm, if_pos hm, heq idx hm]
      · rw [if_neg hm, if_neg hm]
  | lvl + 1, idx => by
      dsimp [expectedRadAt]
      rw [expectedRadAt_pts_congr o heq lvl (2 * idx),
          expectedRadAt_pts_congr o heq lvl (2 * idx + 1)]

/-- Strengthened exact tie-broken tournament invariant for `EpochRadTree`. -/
def RadTreeExactWF {d : ℕ} (K_seg : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S : Finset ℕ) (T : EpochRadTree) : Prop :=
  1 ≤ T.ep ∧
  (∀ v < 2 * 2 ^ K_seg, T.nEp v ≤ T.ep) ∧
  ∀ lvl ≤ K_seg, ∀ idx < 2 ^ (K_seg - lvl),
    T.effVal (2 ^ (K_seg - lvl) + idx) = expectedRadAt pts o S lvl idx

theorem maxRadiusHandle_eq_of_ge {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) {S : Finset ℕ} {n : ℕ} (hS : ∀ x ∈ S, x < n) :
    ∀ {M : ℕ}, n ≤ M → maxRadiusHandle M pts o S = maxRadiusHandle n pts o S := by
  classical
  intro M hle
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hle
  induction k with
  | zero => simp
  | succ k ih =>
      rw [Nat.add_succ, maxRadiusHandle, List.range_succ, List.foldl_append, List.foldl_cons, List.foldl_nil]
      have hnot : n + k ∉ S := fun hm => by have := hS _ hm; omega
      rw [if_neg hnot]
      have hnone : ∀ opt : Option ℕ, pickBetter pts o opt none = opt := by
        intro opt; cases opt <;> rfl
      rw [hnone]
      exact ih (Nat.le_add_right n k)

theorem radTreeExactWF_root {d : ℕ} {K_seg n T_pow : ℕ}
    (hn_T : n ≤ T_pow) (hn_K : n ≤ 2 ^ K_seg)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} (hS : ∀ x ∈ S, x < n) {T : EpochRadTree}
    (hwf : RadTreeExactWF K_seg pts o S T) :
    (T.effVal 1).map Prod.fst = maxRadiusHandle T_pow pts o S := by
  have hroot := hwf.2.2 K_seg le_rfl 0 (by simp)
  simp only [Nat.sub_self, Nat.pow_zero, Nat.add_zero] at hroot
  rw [hroot, expectedRadAt_eq_foldRadRange, Nat.zero_mul]
  have hfold_eq : foldRadRange pts o S 0 (2 ^ K_seg) = maxRadiusHandle (2 ^ K_seg) pts o S := by
    classical
    unfold foldRadRange maxRadiusHandle
    simp only [Nat.zero_add]
  rw [hfold_eq, maxRadiusHandle_eq_of_ge pts o hS hn_K, maxRadiusHandle_eq_of_ge pts o hS hn_T]
  cases maxRadiusHandle n pts o S <;> rfl

theorem radTreeExactWF_pts_congr {d : ℕ} {K_seg : ℕ}
    {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} (heq : ∀ x ∈ S, pts' x = pts x) {T : EpochRadTree}
    (hwf : RadTreeExactWF K_seg pts o S T) :
    RadTreeExactWF K_seg pts' o S T :=
  ⟨hwf.1, hwf.2.1, fun lvl hlvl idx hidx =>
    (hwf.2.2 lvl hlvl idx hidx).trans (expectedRadAt_pts_congr o heq lvl idx).symm⟩

private lemma node_lvl_idx_inj {K_seg lvl₁ idx₁ lvl₂ idx₂ : ℕ}
    (h1 : lvl₁ ≤ K_seg) (hi1 : idx₁ < 2 ^ (K_seg - lvl₁))
    (h2 : lvl₂ ≤ K_seg) (hi2 : idx₂ < 2 ^ (K_seg - lvl₂))
    (heq : 2 ^ (K_seg - lvl₁) + idx₁ = 2 ^ (K_seg - lvl₂) + idx₂) :
    lvl₁ = lvl₂ ∧ idx₁ = idx₂ := by
  have hne_lvl : ¬ lvl₁ < lvl₂ ∧ ¬ lvl₂ < lvl₁ := by
    constructor
    · intro hlt
      have hpow : 2 * 2 ^ (K_seg - lvl₂) ≤ 2 ^ (K_seg - lvl₁) := by
        calc 2 * 2 ^ (K_seg - lvl₂) = 2 ^ (K_seg - lvl₂ + 1) := by rw [pow_succ']
          _ ≤ 2 ^ (K_seg - lvl₁) := Nat.pow_le_pow_right (by omega) (by omega)
      omega
    · intro hlt
      have hpow : 2 * 2 ^ (K_seg - lvl₁) ≤ 2 ^ (K_seg - lvl₂) := by
        calc 2 * 2 ^ (K_seg - lvl₁) = 2 ^ (K_seg - lvl₁ + 1) := by rw [pow_succ']
          _ ≤ 2 ^ (K_seg - lvl₂) := Nat.pow_le_pow_right (by omega) (by omega)
      omega
  have hl : lvl₁ = lvl₂ := by omega
  subst hl
  exact ⟨rfl, by omega⟩

private lemma writeNode_nEp_le {K_seg : ℕ} {T : EpochRadTree}
    (hep : ∀ v < 2 * 2 ^ K_seg, T.nEp v ≤ T.ep) (w : ℕ) (opt : Option (ℕ × ℝ)) :
    ∀ v < 2 * 2 ^ K_seg, (T.writeNode w opt).nEp v ≤ (T.writeNode w opt).ep := by
  intro v hv
  cases opt with
  | none =>
      dsimp [EpochRadTree.writeNode]
      by_cases hvw : v = w
      · subst hvw; simp
      · rw [Function.update_of_ne hvw]; exact hep v hv
  | some ur =>
      rcases ur with ⟨u, r⟩
      dsimp [EpochRadTree.writeNode]
      by_cases hvw : v = w
      · subst hvw; simp
      · rw [Function.update_of_ne hvw]; exact hep v hv

theorem radTreeExactWF_updateLeaf {d : ℕ} {K_seg : ℕ}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S S' : Finset ℕ} {T : EpochRadTree} (hwf : RadTreeExactWF K_seg pts o S T)
    {h : ℕ} (hh : h < 2 ^ K_seg) (opt : Option (ℕ × ℝ))
    (hopt : opt = expectedRadAt pts o S' 0 h)
    (hdiff : ∀ x, x ≠ h → (x ∈ S' ↔ x ∈ S)) :
    RadTreeExactWF K_seg pts o S' (T.updateLeaf K_seg h opt) := by
  let v₀ := 2 ^ K_seg + h
  let st : ℕ → ℕ × EpochRadTree := fun t =>
    (EpochRadTree.updatePathStep)^[t] (v₀, T.writeNode v₀ opt)
  have hstep_inv : ∀ t ≤ K_seg,
      (st t).1 = (2 ^ K_seg + h) / 2 ^ t ∧
      1 ≤ (st t).2.ep ∧
      (∀ v < 2 * 2 ^ K_seg, (st t).2.nEp v ≤ (st t).2.ep) ∧
      (∀ lvl ≤ K_seg, ∀ idx < 2 ^ (K_seg - lvl),
        (lvl ≤ t ∨ idx ≠ h / 2 ^ lvl) →
        (st t).2.effVal (2 ^ (K_seg - lvl) + idx) = expectedRadAt pts o S' lvl idx) := by
    intro t
    induction t with
    | zero =>
        intro _
        dsimp [st]
        have hep0 : (T.writeNode v₀ opt).ep = T.ep := by cases opt <;> rfl
        refine ⟨by simp [v₀], hep0 ▸ hwf.1, writeNode_nEp_le hwf.2.1 v₀ opt, ?_⟩
        intro lvl hlvl idx hidx hcond
        cases lvl with
        | zero =>
            simp only [Nat.sub_zero] at hidx ⊢
            by_cases hih : idx = h
            · subst hih
              rw [EpochRadTree.effVal_writeNode_self, hopt]
            · have hne_v : 2 ^ K_seg + idx ≠ v₀ := by dsimp [v₀]; omega
              have h0_wf := hwf.2.2 0 hlvl idx (by simpa using hidx)
              simp only [Nat.sub_zero] at h0_wf
              rw [EpochRadTree.effVal_writeNode_of_ne _ hne_v, h0_wf,
                  expectedRadAt_congr_outside pts o hdiff 0 idx (by simpa using hih)]
        | succ lvl' =>
            have hne_idx : idx ≠ h / 2 ^ (lvl' + 1) := by
              rcases hcond with hle0 | hne
              · omega
              · exact hne
            have hlt_pow : 2 ^ (K_seg - (lvl' + 1)) + idx < 2 ^ K_seg := by
              have h2 : 2 * 2 ^ (K_seg - (lvl' + 1)) ≤ 2 ^ K_seg := by
                calc 2 * 2 ^ (K_seg - (lvl' + 1)) = 2 ^ (K_seg - (lvl' + 1) + 1) := by rw [pow_succ']
                  _ ≤ 2 ^ K_seg := Nat.pow_le_pow_right (by omega) (by omega)
              omega
            have hne_v : 2 ^ (K_seg - (lvl' + 1)) + idx ≠ v₀ := by dsimp [v₀]; omega
            rw [EpochRadTree.effVal_writeNode_of_ne _ hne_v,
                hwf.2.2 (lvl' + 1) hlvl idx hidx,
                expectedRadAt_congr_outside pts o hdiff (lvl' + 1) idx hne_idx]
    | succ t ih =>
        intro ht1
        rcases ih (by omega) with ⟨hfst, hep_t, hnep_t, heff_t⟩
        have hst_succ : st (t + 1) = EpochRadTree.updatePathStep (st t) :=
          Function.iterate_succ_apply' EpochRadTree.updatePathStep t _
        rw [hst_succ]
        dsimp only [EpochRadTree.updatePathStep, EpochRadTree.pullParent]
        have hp_eq : (st t).1 / 2 = (2 ^ K_seg + h) / 2 ^ (t + 1) := by
          rw [hfst, Nat.div_div_eq_div_mul, ← pow_succ]
        let q := h / 2 ^ (t + 1)
        have hq_lt : q < 2 ^ (K_seg - (t + 1)) := by
          dsimp [q]
          rw [Nat.div_lt_iff_lt_mul (Nat.two_pow_pos (t + 1)), ← pow_add,
              show K_seg - (t + 1) + (t + 1) = K_seg by omega]
          exact hh
        have hp_split : (st t).1 / 2 = 2 ^ (K_seg - (t + 1)) + q := by
          rw [hp_eq]
          have hk_split : 2 ^ K_seg = 2 ^ (t + 1) * 2 ^ (K_seg - (t + 1)) := by
            rw [← pow_add, show t + 1 + (K_seg - (t + 1)) = K_seg by omega]
          rw [hk_split, Nat.mul_add_div (Nat.two_pow_pos (t + 1))]
        set p := (st t).1 / 2
        have h2p : 2 * p = 2 ^ (K_seg - t) + 2 * q := by
          rw [hp_split, Nat.mul_add, ← pow_succ', show K_seg - (t + 1) + 1 = K_seg - t by omega]
        have h2p1 : 2 * p + 1 = 2 ^ (K_seg - t) + (2 * q + 1) := by omega
        have h2q_lt : 2 * q < 2 ^ (K_seg - t) := by
          have : 2 ^ (K_seg - t) = 2 * 2 ^ (K_seg - (t + 1)) := by
            rw [← pow_succ', show K_seg - (t + 1) + 1 = K_seg - t by omega]
          omega
        have h2q1_lt : 2 * q + 1 < 2 ^ (K_seg - t) := by
          have : 2 ^ (K_seg - t) = 2 * 2 ^ (K_seg - (t + 1)) := by
            rw [← pow_succ', show K_seg - (t + 1) + 1 = K_seg - t by omega]
          omega
        have heffL : (st t).2.effVal (2 * p) = expectedRadAt pts o S' t (2 * q) := by
          rw [h2p]; exact heff_t t (by omega) (2 * q) h2q_lt (Or.inl le_rfl)
        have heffR : (st t).2.effVal (2 * p + 1) = expectedRadAt pts o S' t (2 * q + 1) := by
          rw [h2p1]; exact heff_t t (by omega) (2 * q + 1) h2q1_lt (Or.inl le_rfl)
        have hcomb : combineRadOpt ((st t).2.effVal (2 * p)) ((st t).2.effVal (2 * p + 1)) =
            expectedRadAt pts o S' (t + 1) q := by
          rw [heffL, heffR]; rfl
        set newOpt := combineRadOpt ((st t).2.effVal (2 * p)) ((st t).2.effVal (2 * p + 1))
        have hep_w : ((st t).2.writeNode p newOpt).ep = (st t).2.ep := by cases newOpt <;> rfl
        refine ⟨hp_eq, hep_w ▸ hep_t, writeNode_nEp_le hnep_t p newOpt, ?_⟩
        intro lvl hlvl idx hidx hcond
        by_cases hvp : 2 ^ (K_seg - lvl) + idx = p
        · obtain ⟨rfl, rfl⟩ := node_lvl_idx_inj hlvl hidx ht1 hq_lt (hvp.trans hp_split)
          rw [← hp_split, EpochRadTree.effVal_writeNode_self]
          exact hcomb
        · rw [EpochRadTree.effVal_writeNode_of_ne _ hvp]
          apply heff_t lvl hlvl idx hidx
          rcases hcond with hle | hne
          · by_cases heq_t1 : lvl = t + 1
            · subst heq_t1
              exact Or.inr (fun hiq => hvp (by rw [hp_split, hiq]))
            · exact Or.inl (by omega)
          · exact Or.inr hne
  rcases hstep_inv K_seg le_rfl with ⟨_, hep_K, hnep_K, heff_K⟩
  exact ⟨hep_K, hnep_K, fun lvl hlvl idx hidx => heff_K lvl hlvl idx hidx (Or.inl hlvl)⟩

theorem radTreeExactWF_insert {d : ℕ} {K_seg n : ℕ}
    (hn_K : n ≤ 2 ^ K_seg)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {T : EpochRadTree} (hwf : RadTreeExactWF K_seg pts o S T)
    {p : ℕ} (hp_lt : p < n) :
    RadTreeExactWF K_seg pts o (Insert.insert p S)
      (T.updateLeaf K_seg (p % n) (some (p, ‖pts p - o‖ ^ 2))) := by
  have hmod : p % n = p := Nat.mod_eq_of_lt hp_lt
  rw [hmod]
  refine radTreeExactWF_updateLeaf hwf (lt_of_lt_of_le hp_lt hn_K) _ ?_ ?_
  · classical
    dsimp [expectedRadAt]
    rw [if_pos (Finset.mem_insert_self p S)]
  · intro x hne
    simp [Finset.mem_insert, hne]

theorem radTreeExactWF_delete {d : ℕ} {K_seg n : ℕ}
    (hn_K : n ≤ 2 ^ K_seg)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {T : EpochRadTree} (hwf : RadTreeExactWF K_seg pts o S T)
    {p : ℕ} (hp_lt : p < n) :
    RadTreeExactWF K_seg pts o (S.erase p) (T.updateLeaf K_seg (p % n) none) := by
  have hmod : p % n = p := Nat.mod_eq_of_lt hp_lt
  rw [hmod]
  refine radTreeExactWF_updateLeaf hwf (lt_of_lt_of_le hp_lt hn_K) none ?_ ?_
  · classical
    dsimp [expectedRadAt]
    rw [if_neg (Finset.notMem_erase p S)]
  · intro x hne
    simp [Finset.mem_erase, hne]

/-- Zero-init & reuse readiness predicate for an `EpochRadTree` word slice. -/
def RadTreeReady (tblW : ℕ) (baseW : ℤ) (K_seg : ℕ) (m : ArithRAMMemory) : Prop :=
  ∃ ep₀ : ℕ,
    H3a.wRead m tblW baseW = (ep₀ : ℤ) ∧
    ∀ (v : ℕ), v < 2 * 2 ^ K_seg →
      0 ≤ H3a.wRead m tblW (baseW + 4 + 3 * (v : ℤ)) ∧
      H3a.wRead m tblW (baseW + 4 + 3 * (v : ℤ)) ≤ (ep₀ : ℤ) ∧
      (H3a.wRead m tblW (baseW + 4 + 3 * (v : ℤ) + 1) = 0 ∨
       H3a.wRead m tblW (baseW + 4 + 3 * (v : ℤ) + 1) = 1) ∧
      0 ≤ H3a.wRead m tblW (baseW + 4 + 3 * (v : ℤ) + 2)

theorem RadTreeReady.of_zero {tblW : ℕ} {baseW : ℤ} {K_seg : ℕ} {m : ArithRAMMemory}
    (hz : ∀ j : ℤ, 0 ≤ j → j < radTreeWStride K_seg → H3a.wRead m tblW (baseW + j) = 0) :
    RadTreeReady tblW baseW K_seg m := by
  have hge4 := radTreeWStride_ge_four K_seg
  refine ⟨0, by simpa using hz 0 le_rfl (by omega), fun v hv => ?_⟩
  have hv_bnd := radTreeWStride_gt_node hv
  have h1 := hz (4 + 3 * (v : ℤ)) (by omega) (by omega)
  have h2 := hz (4 + 3 * (v : ℤ) + 1) (by omega) (by omega)
  have h3 := hz (4 + 3 * (v : ℤ) + 2) (by omega) (by omega)
  have ha1 : baseW + 4 + 3 * (v : ℤ) = baseW + (4 + 3 * (v : ℤ)) := by ring
  have ha2 : baseW + 4 + 3 * (v : ℤ) + 1 = baseW + (4 + 3 * (v : ℤ) + 1) := by ring
  have ha3 : baseW + 4 + 3 * (v : ℤ) + 2 = baseW + (4 + 3 * (v : ℤ) + 2) := by ring
  rw [ha3, h3, ha2, h2, ha1, h1]
  exact ⟨le_rfl, le_rfl, Or.inl rfl, le_rfl⟩

theorem RadTreeReady.of_enc {d : ℕ} {tblW : ℕ} {baseW : ℤ} {tblR : ℕ} {baseR : ℤ}
    {K_seg : ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {T : EpochRadTree} {m : ArithRAMMemory}
    (hwf : RadTreeExactWF K_seg pts o S T) (henc : EncEpochRadTree tblW baseW tblR baseR K_seg T m) :
    RadTreeReady tblW baseW K_seg m := by
  refine ⟨T.ep, henc.1, fun v hv => ?_⟩
  obtain ⟨h1, h2, h3, _⟩ := henc.2 v hv
  rw [h1, h2, h3]
  exact ⟨Nat.cast_nonneg _, Nat.cast_le.mpr (hwf.2.1 v hv),
    by cases T.nPres v <;> simp, Nat.cast_nonneg _⟩

theorem RadTreeReady.mono_slice {tblW : ℕ} {baseW : ℤ} {K_seg : ℕ} {m₀ m₁ : ArithRAMMemory}
    (hrdy : RadTreeReady tblW baseW K_seg m₀)
    (heq : ∀ i : ℤ, baseW ≤ i → i < baseW + radTreeWStride K_seg →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i) :
    RadTreeReady tblW baseW K_seg m₁ := by
  have hge4 := radTreeWStride_ge_four K_seg
  rcases hrdy with ⟨ep₀, hep, hv_all⟩
  refine ⟨ep₀, (heq baseW le_rfl (by omega)).trans hep, fun v hv => ?_⟩
  have hv_bnd := radTreeWStride_gt_node hv
  rw [heq (baseW + 4 + 3 * (v : ℤ)) (by omega) (by omega),
      heq (baseW + 4 + 3 * (v : ℤ) + 1) (by omega) (by omega),
      heq (baseW + 4 + 3 * (v : ℤ) + 2) (by omega) (by omega)]
  exact hv_all v hv

def radTreeBumpClearStmt (scrW tblW : ℕ) (wRadBaseW : ℤ) : ArithRAMStmt :=
  let bE := IntExpr.readHeap scrW (.lit wRadBaseW)
  radTreeClearStmt tblW bE (.add (.readHeap tblW bE) (.lit 1))

theorem hzr_radTreeBumpClearStmt (scrW tblW : ℕ) (wRadBaseW : ℤ) :
    HeapZeroRandStmt (radTreeBumpClearStmt scrW tblW wRadBaseW) :=
  hzr_radTreeClearStmt _ _ _

theorem exec_radTreeBumpClearStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wRadBaseW baseW baseR : ℤ) (K_seg : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htblW : tblW < TW) (hneW : tblW ≠ scrW)
    (hbaseW : 0 ≤ baseW ∧ baseW + radTreeWStride K_seg ≤ (BW : ℤ))
    (hb_r : H3a.wRead m₀ scrW wRadBaseW = baseW)
    (hrdy : RadTreeReady tblW baseW K_seg m₀) :
    ∃ (T' : EpochRadTree) (m₁ : ArithRAMMemory),
      DetExec inp (radTreeBumpClearStmt scrW tblW wRadBaseW) m₀ m₁ 25 ∧
      InFootprint TW BW TR BR m₁ ∧
      RadTreeExactWF K_seg pts o ∅ T' ∧
      EncEpochRadTree tblW baseW tblR baseR K_seg T' m₁ ∧
      (∀ w, H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR 0 m₀ m₁ := by
  have hge4 := radTreeWStride_ge_four K_seg
  rcases hrdy with ⟨ep₀, hep, hv_all⟩
  let T₀ : EpochRadTree :=
    { ep := ep₀
      nEp := fun v => if v < 2 * 2 ^ K_seg then (H3a.wRead m₀ tblW (baseW + 4 + 3 * (v : ℤ))).toNat else 0
      nPres := fun v => decide (H3a.wRead m₀ tblW (baseW + 4 + 3 * (v : ℤ) + 1) = 1)
      nUid := fun v => if v < 2 * 2 ^ K_seg then (H3a.wRead m₀ tblW (baseW + 4 + 3 * (v : ℤ) + 2)).toNat else 0
      nRadSq := fun v => H3a.rRead m₀ tblR (baseR + (v : ℤ)) }
  let m₁ := H3a.wWrite m₀ tblW baseW ((ep₀ + 1 : ℕ) : ℤ)
  have hd : DetExec inp (radTreeBumpClearStmt scrW tblW wRadBaseW) m₀ m₁ 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW _ _
      (by change H3a.wRead m₀ scrW wRadBaseW = baseW; exact hb_r)
      (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wRadBaseW) + 1 = ((ep₀ + 1 : ℕ) : ℤ)
          rw [hb_r, hep]; push_cast; ring)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp₁ : InFootprint TW BW TR BR m₁ :=
    InFootprint.wWrite hfp₀ htblW hbaseW.1 (by omega)
  let T' := T₀.clear (ep₀ + 1)
  have hwf' : RadTreeExactWF K_seg pts o ∅ T' := by
    refine ⟨by dsimp [T', T₀, EpochRadTree.clear]; omega, fun v hv => ?_, fun lvl hlvl idx hidx => ?_⟩
    · dsimp [T', T₀, EpochRadTree.clear]
      rw [if_pos hv]
      have ⟨h0, hle, _, _⟩ := hv_all v hv
      have hto := Int.toNat_of_nonneg h0
      omega
    · have hv_lt : 2 ^ (K_seg - lvl) + idx < 2 * 2 ^ K_seg := by
        have hpow : 2 ^ (K_seg - lvl) ≤ 2 ^ K_seg := Nat.pow_le_pow_right (by omega) (by omega)
        omega
      dsimp [T', T₀, EpochRadTree.clear, EpochRadTree.effVal]
      rw [if_pos hv_lt]
      have ⟨h0, hle, _, _⟩ := hv_all (2 ^ (K_seg - lvl) + idx) hv_lt
      have hto := Int.toNat_of_nonneg h0
      have hne : (H3a.wRead m₀ tblW (baseW + 4 + 3 * ((2 ^ (K_seg - lvl) + idx : ℕ) : ℤ))).toNat ≠ ep₀ + 1 := by omega
      rw [if_neg (by tauto), expectedRadAt_empty]
  have henc' : EncEpochRadTree tblW baseW tblR baseR K_seg T' m₁ := by
    refine ⟨wRead_wWrite_self _ _ _ _, fun v hv => ?_⟩
    dsimp [T', T₀, EpochRadTree.clear]
    obtain ⟨h0, _, h01, hu0⟩ := hv_all v hv
    refine ⟨?_, ?_, ?_, rRead_wWrite _ _ _ _ _ _⟩
    · rw [if_pos hv, wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact (Int.toNat_of_nonneg h0).symm
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      rcases h01 with h_z | h_o
      · rw [h_z]; rfl
      · rw [h_o]; rfl
    · rw [if_pos hv, wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact (Int.toNat_of_nonneg hu0).symm
  refine ⟨T', m₁, hd, hfp₁, hwf', henc',
    fun _ => wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), fun _ => rfl, ?_⟩
  refine ⟨fun t i _ hout => ?_, fun _ _ _ _ => rfl⟩
  rcases hout with ht | hlt | hge
  · exact wRead_wWrite_of_ne _ _ (Or.inl ht)
  · exact wRead_wWrite_of_ne _ _ (Or.inr (by omega))
  · exact wRead_wWrite_of_ne _ _ (Or.inr (by omega))

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
