import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_S2c
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.C14e

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2

noncomputable instance instFintypeNodeOpSeed (N_cfg L_p2 R ℓ M₀ D b : ℕ) :
    Fintype ((Fin N_cfg × Bool × Fin L_p2) →
      (((Fin R × Fin ℓ × Fin M₀) × Fin D × Fin b) → Bool)) :=
  inferInstance

noncomputable instance instFintypeHPJCoin (N_samp q_idx B_walk : ℕ) :
    Fintype ((Fin N_samp → Fin (2 ^ q_idx)) × (Fin B_walk → Bool)) :=
  inferInstance

noncomputable instance instFintypeFinNodeOpSeed (K N_cfg L_p2 R ℓ M₀ D b : ℕ) :
    Fintype (Fin K → (Fin N_cfg × Bool × Fin L_p2) →
      (((Fin R × Fin ℓ × Fin M₀) × Fin D × Fin b) → Bool)) :=
  inferInstance

attribute [local instance 10] Classical.propDecidable

lemma of_mem_filter_any {α : Type*} {p : α → Prop} {inst : DecidablePred p}
    {s : Finset α} {x : α} (h : x ∈ @Finset.filter α p inst s) : p x :=
  ((@Finset.mem_filter α p inst s x).mp h).2

lemma mem_filter_univ_any {α : Type*} [Fintype α] {p : α → Prop} {inst : DecidablePred p}
    {x : α} (hp : p x) : x ∈ @Finset.filter α p inst Finset.univ :=
  (@Finset.mem_filter α p inst Finset.univ x).mpr ⟨Finset.mem_univ x, hp⟩

lemma true_good_card_ge (α : Type*) [Fintype α] :
    open Classical in
    (1 - (0 : ℝ)) * (Fintype.card α : ℝ) ≤ (((Finset.univ : Finset α).filter (fun _ => True)).card : ℝ) := by
  rw [sub_zero, one_mul, Finset.filter_true_of_mem (fun _ _ => trivial), Finset.card_univ]

theorem goodStage1Coins_card_ge {d : ℕ} {params : LocalScaleParams} {h ε₀ : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (hε0 : 0 ≤ ε₀) (hε1 : ε₀ ≤ 1)
    (hδ_op_le1 : (2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀ ≤ 1)
    (hgen_card : ∀ (i : Fin cp.N_cfg) (gen : SearchGeneration (Fin (2 ^ cp.L_p2)) (d + 1)),
      gen.m = 2 ^ cp.L_p2 → gen.h = h →
      open Classical in
      (1 - ε₀) * (Fintype.card (ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b) : ℝ) ≤
        ((Finset.univ.filter (fun ω : ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b =>
          IsOrderIndepGoodFilter (polyFDisc cp.T_cdf cp.p_coord ω) (cp.τ_d : ℝ) (cp.τ_q : ℝ)
            cp.cap_u cp.cap_q gen (paddedLatNet (M_lat_of d params.e) (cp.specs i).A (cp.specs i).B))).card : ℝ))
    (st : ChainEngineState cp) :
    let δ_op : ℝ := (2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀
    open Classical in
    (1 - (cp.N_op_s1 : ℝ) * δ_op) * (Fintype.card (Stage1Coins cp) : ℝ) ≤
      ((Finset.univ.filter (GoodStage1Coins cp hh0 hh1 st)).card : ℝ) := by
  intro δ_op
  have hδ_op0 : 0 ≤ δ_op := by positivity
  have hvacuous : ∀ (P : OpSeed cp → Prop), (∀ ω, P ω) →
      (1 - δ_op) * (Fintype.card (OpSeed cp) : ℝ) ≤
        (((Finset.univ : Finset (OpSeed cp)).filter P).card : ℝ) := by
    intro P hall
    have hfeq : (Finset.univ : Finset (OpSeed cp)).filter P = Finset.univ :=
      Finset.filter_true_of_mem (fun ω _ => hall ω)
    rw [hfeq, Finset.card_univ]
    have h1 : 1 - δ_op ≤ 1 := by linarith only [hδ_op0]
    simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)
  have hnode : ∀ nd,
      (1 - δ_op) * (Fintype.card (OpSeed cp) : ℝ) ≤
        (((Finset.univ : Finset (OpSeed cp)).filter (fun ω =>
          NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
            cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q nd ω)).card : ℝ) :=
    fun nd => nodeOpSeedGood_card_ge cp.specs hh0 hh1 hε0 hε1 nd hgen_card
  have hslot : ∀ k : Fin cp.N_op_s1,
      (1 - δ_op) * (Fintype.card (OpSeed cp) : ℝ) ≤
        (((Finset.univ : Finset (OpSeed cp)).filter (s1SlotGood cp hh0 hh1 st k)).card : ℝ) := by
    intro k
    by_cases hk1 : k.val < cp.D_max
    · by_cases hks : k.val < st.serving.length
      · refine (hnode (st.serving[k.val]'hks).nd).trans (Nat.cast_le.mpr (Finset.card_le_card (fun ω hω => ?_)))
        have hgd := of_mem_filter_any hω
        refine mem_filter_univ_any ?_
        unfold s1SlotGood; dsimp only; rw [if_pos hk1]
        intro hks'
        have : hks' = hks := Subsingleton.elim _ _; rwa [this]
      · refine hvacuous _ (fun ω => ?_)
        unfold s1SlotGood; dsimp only; rw [if_pos hk1]
        exact fun hks' => absurd hks' hks
    · by_cases hk2 : k.val < cp.D_max + cp.D_max * cp.D_max
      · let r := (k.val - cp.D_max) / cp.D_max
        let q := (k.val - cp.D_max) % cp.D_max
        by_cases hcond : ∃ (hr : r < cp.D_max) (jb : SuffixJob cp) (_ : st.jobs ⟨r, hr⟩ = some jb),
            q < jb.ready.length
        · rcases hcond with ⟨hr, jb, hjb, hq⟩
          refine (hnode (jb.ready[q]'hq).nd).trans (Nat.cast_le.mpr (Finset.card_le_card (fun ω hω => ?_)))
          have hgd := of_mem_filter_any hω
          refine mem_filter_univ_any ?_
          unfold s1SlotGood; dsimp only; rw [if_neg hk1, if_pos hk2]
          intro hr' jb' hjb' hq'
          have hrr : (⟨r, hr'⟩ : Fin cp.D_max) = ⟨r, hr⟩ := rfl
          rw [hrr, hjb] at hjb'
          injection hjb' with heq; subst heq
          exact hgd
        · refine hvacuous _ (fun ω => ?_)
          unfold s1SlotGood; dsimp only; rw [if_neg hk1, if_pos hk2]
          exact fun hr' jb' hjb' hq' => absurd ⟨hr', jb', hjb', hq'⟩ hcond
      · let r := k.val - (cp.D_max + cp.D_max * cp.D_max)
        by_cases hcond : ∃ (hr : r < cp.D_max) (jb : SuffixJob cp) (bs : BuildState cp),
            st.jobs ⟨r, hr⟩ = some jb ∧ jb.phase = .build bs
        · rcases hcond with ⟨hr, jb, bs, hjb, hbs⟩
          refine (hnode bs.curNode.nd).trans (Nat.cast_le.mpr (Finset.card_le_card (fun ω hω => ?_)))
          have hgd := of_mem_filter_any hω
          refine mem_filter_univ_any ?_
          unfold s1SlotGood; dsimp only; rw [if_neg hk1, if_neg hk2]
          intro hr' jb' bs' hjb' hbs'
          have hrr : (⟨r, hr'⟩ : Fin cp.D_max) = ⟨r, hr⟩ := rfl
          rw [hrr, hjb] at hjb'
          injection hjb' with heq; subst heq
          rw [hbs] at hbs'
          injection hbs' with hb_eq; subst hb_eq
          exact hgd
        · refine hvacuous _ (fun ω => ?_)
          unfold s1SlotGood; dsimp only; rw [if_neg hk1, if_neg hk2]
          exact fun hr' jb' bs' hjb' hbs' => absurd ⟨hr', jb', bs', hjb', hbs'⟩ hcond
  have hpi := pi_good_card_ge (s1SlotGood cp hh0 hh1 st) hδ_op0 hδ_op_le1 hslot
  rw [Fintype.card_fin] at hpi
  refine hpi.trans (Nat.cast_le.mpr (Finset.card_le_card (fun ω₁ hω₁ => ?_)))
  exact mem_filter_univ_any (of_mem_filter_any hω₁)


abbrev JobSliceB {d : ℕ} {params : LocalScaleParams} {h : ℝ} (B : ℕ) (cp : ChainParams d params h) : Type :=
  (Fin B → OpSeed cp) × CenterSeed cp

abbrev LeafSliceB {d : ℕ} {params : LocalScaleParams} {h : ℝ} (B : ℕ) (cp : ChainParams d params h) : Type :=
  (Fin (B + 1) → OpSeed cp) × CenterSeed cp

abbrev Stage2CoinsB {d : ℕ} {params : LocalScaleParams} {h : ℝ} (D B : ℕ) (cp : ChainParams d params h) : Type :=
  (Fin (D * B + (B + 1)) → OpSeed cp) × (Fin (D + 1) → CenterSeed cp)

def stage2ToSlicesB {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (D B : ℕ) (cp : ChainParams d params h) (ω₂ : Stage2CoinsB D B cp) :
    (Fin D → JobSliceB B cp) × LeafSliceB B cp :=
  (fun r =>
    (fun j => ω₂.1 ⟨r.val * B + j.val, by
      have : r.val * B + j.val < D * B := by
        calc r.val * B + j.val < r.val * B + B := Nat.add_lt_add_left j.isLt _
          _ = (r.val + 1) * B := by ring
          _ ≤ D * B := Nat.mul_le_mul_right _ r.isLt
      exact Nat.lt_add_right _ this⟩,
     ω₂.2 r.castSucc),
   (fun j => ω₂.1 ⟨D * B + j.val, Nat.add_lt_add_left j.isLt _⟩,
    ω₂.2 (Fin.last D)))

noncomputable def slicesToStage2B {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (D B : ℕ) (hB_pos : 0 < B) (cp : ChainParams d params h)
    (sl : (Fin D → JobSliceB B cp) × LeafSliceB B cp) : Stage2CoinsB D B cp :=
  (fun idx =>
    if hlt : idx.val < D * B then
      let r : Fin D := ⟨idx.val / B, (Nat.div_lt_iff_lt_mul hB_pos).mpr hlt⟩
      let j : Fin B := ⟨idx.val % B, Nat.mod_lt _ hB_pos⟩
      (sl.1 r).1 j
    else
      let j : Fin (B + 1) := ⟨idx.val - D * B, by
        have hidx : idx.val < D * B + (B + 1) := idx.isLt
        omega⟩
      sl.2.1 j,
   Fin.lastCases sl.2.2 (fun r => (sl.1 r).2))

noncomputable def stage2SliceEquivB {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (D B : ℕ) (hB_pos : 0 < B) (cp : ChainParams d params h) :
    Stage2CoinsB D B cp ≃ ((Fin D → JobSliceB B cp) × LeafSliceB B cp) where
  toFun := stage2ToSlicesB D B cp
  invFun := slicesToStage2B D B hB_pos cp
  left_inv := fun ω₂ => by
    apply Prod.ext
    · funext idx
      dsimp only [slicesToStage2B, stage2ToSlicesB]
      by_cases hlt : idx.val < D * B
      · rw [dif_pos hlt]
        apply congrArg ω₂.1
        ext; dsimp only
        rw [Nat.mul_comm _ B, Nat.div_add_mod]
      · rw [dif_neg hlt]
        apply congrArg ω₂.1
        ext; dsimp only; omega
    · funext idx
      refine Fin.lastCases ?_ (fun r => ?_) idx
      · dsimp only [slicesToStage2B, stage2ToSlicesB]; exact Fin.lastCases_last
      · dsimp only [slicesToStage2B, stage2ToSlicesB]; exact Fin.lastCases_castSucc r
  right_inv := fun ⟨js, ls⟩ => by
    apply Prod.ext
    · funext r
      apply Prod.ext
      · funext j
        dsimp only [stage2ToSlicesB, slicesToStage2B]
        have hlt : r.val * B + j.val < D * B := by
          calc r.val * B + j.val < r.val * B + B := Nat.add_lt_add_left j.isLt _
            _ = (r.val + 1) * B := by ring
            _ ≤ D * B := Nat.mul_le_mul_right _ r.isLt
        rw [dif_pos hlt]
        have hdiv : (r.val * B + j.val) / B = r.val := by
          rw [Nat.add_comm, Nat.add_mul_div_right _ _ hB_pos, Nat.div_eq_of_lt j.isLt, zero_add]
        have hmod : (r.val * B + j.val) % B = j.val := by
          rw [Nat.add_comm, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt j.isLt]
        have hr_eq : (⟨(r.val * B + j.val) / B, (Nat.div_lt_iff_lt_mul hB_pos).mpr hlt⟩ : Fin D) = r := by
          ext; dsimp only; exact hdiv
        have hj_eq : (⟨(r.val * B + j.val) % B, Nat.mod_lt _ hB_pos⟩ : Fin B) = j := by
          ext; dsimp only; exact hmod
        rw [hr_eq, hj_eq]
      · dsimp only [stage2ToSlicesB, slicesToStage2B]; exact Fin.lastCases_castSucc r
    · apply Prod.ext
      · funext j
        dsimp only [stage2ToSlicesB, slicesToStage2B]
        have hnot : ¬ D * B + j.val < D * B := by omega
        rw [dif_neg hnot]
        have hj_eq : (⟨D * B + j.val - D * B, by omega⟩ : Fin (B + 1)) = j := by
          ext; dsimp only; omega
        rw [hj_eq]
      · dsimp only [stage2ToSlicesB, slicesToStage2B]; exact Fin.lastCases_last

def s2JobGoodAtB {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (B : ℕ) (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (gt : GhostTracker d)
    (anchorNode : MNode cp) (jb : SuffixJob cp)
    (bSeeds : Fin B → OpSeed cp) (ctrSeed : CenterSeed cp) : Prop :=
  let (srcHist, tgtArr) : List ℕ × List ℕ :=
    match jb.ready.getLast? with
    | none => (anchorNode.histArr, anchorNode.nd.denseArr)
    | some u_last => (u_last.histArr, u_last.resArr)
  match jb.phase with
  | .copy cs =>
      let steps := min (cs.L_hist - cs.copyCur) B
      let cs' := advanceCopyLoop srcHist tgtArr steps cs
      ¬ (cs'.copyCur < cs'.L_hist) → ¬ (cs'.snapArr.length ≤ B) →
        let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts cs'.snapArr ctrSeed
        let P₀_uid := cs'.snapArr.toFinset.image gt.uidOf
        IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => gt.ghostPts u.1))
          (liftedPoint os.1 os.2)
  | .build bs =>
      let steps := min (bs.snapArr.length - bs.insCur) B
      SeqGood (advanceBuildStep cp pts)
        (fun st_b ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)
        steps bs (fun j => bSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩)

def s2LeafGoodB {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (B : ℕ) (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (st₁ : ChainEngineState cp)
    (leafSeeds : Fin (B + 1) → OpSeed cp) (leafCtr : CenterSeed cp) : Prop :=
  st₁.leafOverflow = false →
  B < st₁.leafArr.length →
  st₁.serving.length < cp.D_max →
  st₁.leafArr.length ≤ B + 1 →
    let pts := st₁.hp.coords
    let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts st₁.leafArr leafCtr
    let P₀_uid := st₁.leafArr.toFinset.image st₁.gt.uidOf
    IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => st₁.gt.ghostPts u.1))
      (liftedPoint os.1 os.2) ∧
    SeqGood (advanceBuildStep cp pts)
      (fun st_b ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
        cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)
      (min st₁.leafArr.length (B + 1))
      (BuildState.init cp st₁.leafArr.length st₁.leafArr os.1 os.2 P₀_uid)
      (fun j => leafSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩)

def GoodStage2CoinsB {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (D B : ℕ) (hD_le : D ≤ cp.D_max) (hh0 : 0 < h) (hh1 : h < 1)
    (st₁ : ChainEngineState cp) (ω₂ : Stage2CoinsB D B cp) : Prop :=
  (∀ r : Fin D,
    ∀ (hr : r.val < st₁.serving.length) (jb : SuffixJob cp),
      st₁.jobs ⟨r.val, lt_of_lt_of_le r.isLt hD_le⟩ = some jb →
      s2JobGoodAtB B cp hh0 hh1 st₁.hp.coords st₁.gt (st₁.serving[r.val]'hr) jb
        (fun j => ω₂.1 ⟨r.val * B + j.val, by
          have : r.val * B + j.val < D * B := by
            calc r.val * B + j.val < r.val * B + B := Nat.add_lt_add_left j.isLt _
              _ = (r.val + 1) * B := by ring
              _ ≤ D * B := Nat.mul_le_mul_right _ r.isLt
          exact Nat.lt_add_right _ this⟩)
        (ω₂.2 r.castSucc)) ∧
  s2LeafGoodB B cp hh0 hh1 st₁
    (fun j => ω₂.1 ⟨D * B + j.val, Nat.add_lt_add_left j.isLt _⟩)
    (ω₂.2 (Fin.last D))

def s2JobSlicePredB {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (B : ℕ) (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (st₁ : ChainEngineState cp) (r : Fin cp.D_max) (sl : JobSliceB B cp) : Prop :=
  ∀ (hr : r.val < st₁.serving.length) (jb : SuffixJob cp),
    st₁.jobs r = some jb →
    s2JobGoodAtB B cp hh0 hh1 st₁.hp.coords st₁.gt (st₁.serving[r.val]'hr) jb sl.1 sl.2

def s2LeafSlicePredB {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (B : ℕ) (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (st₁ : ChainEngineState cp) (sl : LeafSliceB B cp) : Prop :=
  s2LeafGoodB B cp hh0 hh1 st₁ sl.1 sl.2

private theorem seqGood_pad_card_ge {d : ℕ} {params : LocalScaleParams} {h δ_op : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (hδ_op0 : 0 ≤ δ_op) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (hnode : ∀ st_b : BuildState cp,
      open Classical in
      (1 - δ_op) * (Fintype.card (OpSeed cp) : ℝ) ≤
        (((Finset.univ : Finset (OpSeed cp)).filter (fun ω =>
          NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
            cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)).card : ℝ))
    (K steps : ℕ) (hsk : steps ≤ K) (bs0 : BuildState cp) :
    open Classical in
    (1 - (K : ℝ) * δ_op) * (Fintype.card (Fin K → OpSeed cp) : ℝ) ≤
      (((Finset.univ : Finset (Fin K → OpSeed cp)).filter (fun bSeeds =>
        SeqGood (advanceBuildStep cp pts)
          (fun st_b ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
            cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)
          steps bs0 (fun j : Fin steps => bSeeds ⟨j.val, lt_of_lt_of_le j.isLt hsk⟩))).card : ℝ) := by
  let splitEq : (Fin K → OpSeed cp) ≃ ((Fin steps → OpSeed cp) × (Fin (K - steps) → OpSeed cp)) :=
    { toFun := fun f => (fun j => f ⟨j.val, lt_of_lt_of_le j.isLt hsk⟩,
                         fun j => f ⟨steps + j.val, by omega⟩)
      invFun := fun ⟨f1, f2⟩ idx =>
        if hlt : idx.val < steps then f1 ⟨idx.val, hlt⟩ else f2 ⟨idx.val - steps, by omega⟩
      left_inv := fun f => by
        funext idx; dsimp only
        by_cases hlt : idx.val < steps
        · rw [dif_pos hlt]
        · rw [dif_neg hlt]; congr 1; ext; dsimp only; omega
      right_inv := fun ⟨f1, f2⟩ => by
        apply Prod.ext
        · funext j; dsimp only; rw [dif_pos j.isLt]
        · funext j; dsimp only
          have hnot : ¬ steps + j.val < steps := by omega
          rw [dif_neg hnot]; congr 1; ext; dsimp only; omega }
  have hseq := seq_good_card_ge (advanceBuildStep cp pts)
    (fun st_b ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
      cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)
    hδ_op0 hnode steps bs0
  have hfub := fubini_good_card_ge
    (PA := fun ωs : Fin steps → OpSeed cp =>
      SeqGood (advanceBuildStep cp pts)
        (fun st_b ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)
        steps bs0 ωs)
    (PAB := fun _ (_ : Fin (K - steps) → OpSeed cp) => True)
    (φ₁ := (steps : ℝ) * δ_op) (φ₂ := 0)
    (mul_nonneg (Nat.cast_nonneg _) hδ_op0) le_rfl hseq (fun _ _ => true_good_card_ge _)
  rw [add_zero] at hfub
  have hcard_eq : (Fintype.card ((Fin steps → OpSeed cp) × (Fin (K - steps) → OpSeed cp)) : ℝ) =
      (Fintype.card (Fin K → OpSeed cp) : ℝ) := by
    exact_mod_cast (Fintype.card_congr splitEq).symm
  rw [hcard_eq] at hfub
  have hst_le : 1 - (K : ℝ) * δ_op ≤ 1 - (steps : ℝ) * δ_op := by
    have hm : (steps : ℝ) * δ_op ≤ (K : ℝ) * δ_op :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast hsk) hδ_op0
    linarith only [hm]
  refine (mul_le_mul_of_nonneg_right hst_le (Nat.cast_nonneg _)).trans (hfub.trans ?_)
  apply Nat.cast_le.mpr
  rw [← Finset.card_map splitEq.symm.toEmbedding]
  refine Finset.card_le_card (fun f hf => ?_)
  rcases Finset.mem_map.mp hf with ⟨⟨f1, f2⟩, hmem, hf_eq⟩
  rw [← hf_eq]; dsimp only [Equiv.coe_toEmbedding]
  have hg1 := (of_mem_filter_any hmem).1
  refine mem_filter_univ_any ?_
  have hfun_eq : (fun j : Fin steps => splitEq.symm (f1, f2) ⟨j.val, lt_of_lt_of_le j.isLt hsk⟩) = f1 := by
    funext j; dsimp only [splitEq, Equiv.coe_fn_symm_mk]; rw [dif_pos j.isLt]
  rwa [hfun_eq]

private theorem hpjArr_good_card_ge {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h)
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp} (hwf₁ : PostStage1WF cp P' st₁)
    (arr : List ℕ) (hsz : 1 ≤ arr.length) (hnd : arr.Nodup) (hsub : arr.toFinset ⊆ P'.activeHandles) :
    open Classical in
    (1 - ((cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)))) *
        (Fintype.card (CenterSeed cp) : ℝ) ≤
      (((Finset.univ : Finset (CenterSeed cp)).filter (fun cw =>
        let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN st₁.hp.coords arr cw
        let P₀_uid := arr.toFinset.image st₁.gt.uidOf
        IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => st₁.gt.ghostPts u.1))
          (liftedPoint os.1 os.2))).card : ℝ) := by
  let δ_ctr : ℝ := (cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
  rcases hwf₁ with ⟨hhp, hgt, _, _, _, _⟩
  have hact_n : P'.activeHandles.card ≤ cp.n := by
    rcases hhp with ⟨_, hact_nd, _, hact_set, _, _, _, _⟩
    rw [← hact_set, List.toFinset_card_of_nodup hact_nd]; omega
  have hlen_le_n : arr.length ≤ cp.n := by
    rw [← List.toFinset_card_of_nodup hnd]
    exact (Finset.card_le_card hsub).trans hact_n
  have hbase := hpjCenter_good_via_ghost (q_idx := cp.q_idx) hgt cp.hφ0 cp.hφ1 cp.hP_hpj cp.hmN hsz hnd hsub
  have hmul_le : ((cp.N_samp * arr.length : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) ≤
      ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by
    refine mul_le_mul_of_nonneg_right ?_ (by positivity)
    exact_mod_cast Nat.mul_le_mul_left cp.N_samp hlen_le_n
  have h1 : 1 - δ_ctr ≤
      1 - (cp.phiRat : ℝ) - ((cp.N_samp * arr.length : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by
    dsimp only [δ_ctr]; linarith only [hmul_le]
  exact (mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)).trans hbase

private theorem s2JobSlice_copy_card_ge {d : ℕ} {params : LocalScaleParams} {h δ_op : ℝ}
    (B : ℕ) (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (hδ_op0 : 0 ≤ δ_op)
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp} (hwf₁ : PostStage1WF cp P' st₁)
    (r : Fin cp.D_max) (hr : r.val < st₁.serving.length)
    (jb : SuffixJob cp) (hjb : st₁.jobs r = some jb)
    (cs : CopyState) (hphase : jb.phase = .copy cs) :
    let δ_ctr : ℝ := (cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    let δ_job : ℝ := δ_ctr + (B : ℝ) * δ_op
    open Classical in
    (1 - δ_job) * (Fintype.card (JobSliceB B cp) : ℝ) ≤
      (((Finset.univ : Finset (JobSliceB B cp)).filter (s2JobSlicePredB B cp hh0 hh1 st₁ r)).card : ℝ) := by
  intro δ_ctr δ_job
  have hδ_ctr0 : 0 ≤ δ_ctr := by
    have h1 := cp.hφ0.le
    have h2 : (0 : ℝ) ≤ ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by positivity
    linarith only [h1, h2]
  have hδ_job0 : 0 ≤ δ_job := add_nonneg hδ_ctr0 (mul_nonneg (Nat.cast_nonneg _) hδ_op0)
  have hslot := hwf₁.2.2.2.2.1 r
  rw [dif_pos hr] at hslot; dsimp only at hslot; rw [hjb] at hslot
  rcases (chainListInv_getElem P'.activeHandles st₁.serving (Finset.Subset.refl _) hwf₁.2.2.2.1).2 r.val hr
    with ⟨hS_anc, hanc_ln⟩
  dsimp only [SuffixJobInvSlack] at hslot
  rcases hslot with ⟨_, hcl_r, _, _, hph⟩
  have hTend_sub : foldResiduals st₁.hp.coords (foldResiduals st₁.hp.coords P'.activeHandles (st₁.serving.take r.val)) jb.ready ⊆ P'.activeHandles :=
    (chainListInv_getElem _ jb.ready hS_anc hcl_r).1
  rw [hphase] at hph
  rcases hph with ⟨_, _, hcs_inv⟩
  set anc := st₁.serving[r.val]'hr
  let srcHist : List ℕ := (match jb.ready.getLast? with | none => anc | some u => u).histArr
  let tgtArr : List ℕ := match jb.ready.getLast? with | none => anc.nd.denseArr | some u => u.resArr
  have htgt_set : tgtArr.toFinset = foldResiduals st₁.hp.coords (foldResiduals st₁.hp.coords P'.activeHandles (st₁.serving.take r.val)) jb.ready := by
    dsimp only [tgtArr]
    cases hgl : jb.ready.getLast? with
    | none =>
        have hemp : jb.ready = [] := by cases hlr : jb.ready <;> [rfl; (simp [hlr] at hgl)]
        rw [hemp]; dsimp only [foldResiduals]; exact hanc_ln.1
    | some u_last => exact (chainListInv_getLast hS_anc hcl_r hgl).2.1
  let steps := min (cs.L_hist - cs.copyCur) B
  set cs' := advanceCopyLoop srcHist tgtArr steps cs
  rcases advanceCopyLoop_spec htgt_set steps (by dsimp only [steps]; omega) hcs_inv
    with ⟨_, _, hcs_inv', hdone_snap⟩
  by_cases hc_trig : ¬ (cs'.copyCur < cs'.L_hist) ∧ ¬ (cs'.snapArr.length ≤ B)
  · rcases hc_trig with ⟨hnot_lt, hnot_le⟩
    have hcur_eq : cs'.copyCur = cs'.L_hist := le_antisymm hcs_inv'.1 (Nat.not_lt.mp hnot_lt)
    have hsnap_sub : cs'.snapArr.toFinset ⊆ P'.activeHandles := (hdone_snap hcur_eq) ▸ hTend_sub
    have hsz1 : 1 ≤ cs'.snapArr.length := by omega
    have hctr_b : (1 - δ_ctr) * (Fintype.card (CenterSeed cp) : ℝ) ≤ _ :=
      hpjArr_good_card_ge cp hwf₁ cs'.snapArr hsz1 hcs_inv'.2.2.1 hsnap_sub
    have hfub := fubini_good_card_ge
      (PA := fun _ : Fin B → OpSeed cp => True)
      (PAB := fun _ cw =>
        let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN st₁.hp.coords cs'.snapArr cw
        let P₀_uid := cs'.snapArr.toFinset.image st₁.gt.uidOf
        IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => st₁.gt.ghostPts u.1))
          (liftedPoint os.1 os.2))
      (φ₁ := 0) (φ₂ := δ_ctr)
      le_rfl hδ_ctr0 (true_good_card_ge _) (fun _ _ => hctr_b)
    rw [zero_add] at hfub
    have hle_j : 1 - δ_job ≤ 1 - δ_ctr := by
      dsimp only [δ_job]; have : 0 ≤ (B : ℝ) * δ_op := mul_nonneg (Nat.cast_nonneg _) hδ_op0
      linarith only [this]
    refine (mul_le_mul_of_nonneg_right hle_j (Nat.cast_nonneg _)).trans (hfub.trans ?_)
    apply Nat.cast_le.mpr
    refine Finset.card_le_card (fun sl hsl => ?_)
    have hcp_cw := (of_mem_filter_any hsl).2
    refine mem_filter_univ_any (fun hr' jb' hjb' => ?_)
    rw [hjb] at hjb'; injection hjb' with heq; subst heq
    unfold s2JobGoodAtB
    have hhr_eq : hr' = hr := Subsingleton.elim _ _
    rw [hhr_eq, hphase]
    have hp_eq : (match jb.ready.getLast? with
      | none => (anc.histArr, anc.nd.denseArr)
      | some u_last => (u_last.histArr, u_last.resArr)) = (srcHist, tgtArr) := by
      dsimp only [srcHist, tgtArr]; cases jb.ready.getLast? <;> rfl
    dsimp only; rw [hp_eq]
    exact fun _ _ => hcp_cw
  · have hall : (Finset.univ : Finset (JobSliceB B cp)).filter (s2JobSlicePredB B cp hh0 hh1 st₁ r) = Finset.univ := by
      apply Finset.filter_true_of_mem
      intro sl _ hr' jb' hjb'
      rw [hjb] at hjb'; injection hjb' with heq; subst heq
      have hhr_eq : hr' = hr := Subsingleton.elim _ _
      unfold s2JobGoodAtB; rw [hhr_eq, hphase]
      have hp_eq : (match jb.ready.getLast? with
        | none => (anc.histArr, anc.nd.denseArr)
        | some u_last => (u_last.histArr, u_last.resArr)) = (srcHist, tgtArr) := by
        dsimp only [srcHist, tgtArr]; cases jb.ready.getLast? <;> rfl
      dsimp only; rw [hp_eq]
      intro h1 h2; exact absurd ⟨h1, h2⟩ hc_trig
    rw [hall, Finset.card_univ]
    have h1 : 1 - δ_job ≤ 1 := by linarith only [hδ_job0]
    simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)

private theorem s2JobSlice_good_card_ge {d : ℕ} {params : LocalScaleParams} {h δ_op : ℝ}
    (B : ℕ) (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (hδ_op0 : 0 ≤ δ_op)
    (hnode : ∀ st_b : BuildState cp,
      open Classical in
      (1 - δ_op) * (Fintype.card (OpSeed cp) : ℝ) ≤
        (((Finset.univ : Finset (OpSeed cp)).filter (fun ω =>
          NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
            cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)).card : ℝ))
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp} (hwf₁ : PostStage1WF cp P' st₁)
    (r : Fin cp.D_max) :
    let δ_ctr : ℝ := (cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    let δ_job : ℝ := δ_ctr + (B : ℝ) * δ_op
    open Classical in
    (1 - δ_job) * (Fintype.card (JobSliceB B cp) : ℝ) ≤
      (((Finset.univ : Finset (JobSliceB B cp)).filter (s2JobSlicePredB B cp hh0 hh1 st₁ r)).card : ℝ) := by
  intro δ_ctr δ_job
  have hδ_ctr0 : 0 ≤ δ_ctr := by
    have h1 := cp.hφ0.le
    have h2 : (0 : ℝ) ≤ ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by positivity
    linarith only [h1, h2]
  have hδ_job0 : 0 ≤ δ_job := add_nonneg hδ_ctr0 (mul_nonneg (Nat.cast_nonneg _) hδ_op0)
  by_cases hr : r.val < st₁.serving.length
  · by_cases hjb_none : st₁.jobs r = none
    · have hall : (Finset.univ : Finset (JobSliceB B cp)).filter (s2JobSlicePredB B cp hh0 hh1 st₁ r) = Finset.univ :=
        Finset.filter_true_of_mem (fun _ _ _ jb h => by rw [hjb_none] at h; cases h)
      rw [hall, Finset.card_univ]
      have h1 : 1 - δ_job ≤ 1 := by linarith only [hδ_job0]
      simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)
    · obtain ⟨jb, hjb⟩ := Option.ne_none_iff_exists'.mp hjb_none
      cases hphase : jb.phase with
      | copy cs =>
          exact s2JobSlice_copy_card_ge B cp hh0 hh1 hδ_op0 hwf₁ r hr jb hjb cs hphase
      | build bs =>
          let steps := min (bs.snapArr.length - bs.insCur) B
          have hseq_b := seqGood_pad_card_ge cp hh0 hh1 hδ_op0 st₁.hp.coords hnode B steps (Nat.min_le_right _ _) bs
          have hfub := fubini_good_card_ge
            (PA := fun bSeeds : Fin B → OpSeed cp =>
              SeqGood (advanceBuildStep cp st₁.hp.coords)
                (fun st_b ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
                  cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)
                steps bs (fun j => bSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩))
            (PAB := fun _ (_ : CenterSeed cp) => True)
            (φ₁ := (B : ℝ) * δ_op) (φ₂ := 0)
            (mul_nonneg (Nat.cast_nonneg _) hδ_op0) le_rfl hseq_b (fun _ _ => true_good_card_ge _)
          rw [add_zero] at hfub
          have hle_j : 1 - δ_job ≤ 1 - (B : ℝ) * δ_op := by
            dsimp only [δ_job]; linarith only [hδ_ctr0]
          refine (mul_le_mul_of_nonneg_right hle_j (Nat.cast_nonneg _)).trans (hfub.trans ?_)
          apply Nat.cast_le.mpr
          refine Finset.card_le_card (fun sl hsl => ?_)
          have hsq := (of_mem_filter_any hsl).1
          refine mem_filter_univ_any (fun hr' jb' hjb' => ?_)
          rw [hjb] at hjb'; injection hjb' with heq; subst heq
          unfold s2JobGoodAtB; rw [hphase]; exact hsq
  · have hall : (Finset.univ : Finset (JobSliceB B cp)).filter (s2JobSlicePredB B cp hh0 hh1 st₁ r) = Finset.univ :=
      Finset.filter_true_of_mem (fun _ _ hr' => absurd hr' hr)
    rw [hall, Finset.card_univ]
    have h1 : 1 - δ_job ≤ 1 := by linarith only [hδ_job0]
    simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)

private theorem s2LeafSlice_good_card_ge {d : ℕ} {params : LocalScaleParams} {h δ_op : ℝ}
    (B : ℕ) (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (hδ_op0 : 0 ≤ δ_op)
    (hnode : ∀ st_b : BuildState cp,
      open Classical in
      (1 - δ_op) * (Fintype.card (OpSeed cp) : ℝ) ≤
        (((Finset.univ : Finset (OpSeed cp)).filter (fun ω =>
          NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
            cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)).card : ℝ))
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp} (hwf₁ : PostStage1WF cp P' st₁) :
    let δ_ctr : ℝ := (cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    let δ_leaf : ℝ := δ_ctr + ((B + 1 : ℕ) : ℝ) * δ_op
    open Classical in
    (1 - δ_leaf) * (Fintype.card (LeafSliceB B cp) : ℝ) ≤
      (((Finset.univ : Finset (LeafSliceB B cp)).filter (s2LeafSlicePredB B cp hh0 hh1 st₁)).card : ℝ) := by
  intro δ_ctr δ_leaf
  have hδ_ctr0 : 0 ≤ δ_ctr := by
    have h1 := cp.hφ0.le
    have h2 : (0 : ℝ) ≤ ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by positivity
    linarith only [h1, h2]
  have hδ_leaf0 : 0 ≤ δ_leaf := add_nonneg hδ_ctr0 (mul_nonneg (Nat.cast_nonneg _) hδ_op0)
  by_cases hcond : st₁.leafOverflow = false ∧ B < st₁.leafArr.length ∧
      st₁.serving.length < cp.D_max ∧ st₁.leafArr.length ≤ B + 1
  · rcases hcond with ⟨hov, hgt_B, _, _⟩
    rcases hwf₁.2.2.2.2.2 hov with ⟨hlf_nd, hlf_set, _⟩
    have hlf_sub : st₁.leafArr.toFinset ⊆ P'.activeHandles :=
      hlf_set ▸ (chainListInv_getElem P'.activeHandles st₁.serving (Finset.Subset.refl _) hwf₁.2.2.2.1).1
    have hctr_lf : (1 - δ_ctr) * (Fintype.card (CenterSeed cp) : ℝ) ≤ _ :=
      hpjArr_good_card_ge cp hwf₁ st₁.leafArr (by omega) hlf_nd hlf_sub
    let steps := min st₁.leafArr.length (B + 1)
    let P₀_uid := st₁.leafArr.toFinset.image st₁.gt.uidOf
    have hfub := fubini_good_card_ge
      (PA := fun cw : CenterSeed cp =>
        let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN st₁.hp.coords st₁.leafArr cw
        IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => st₁.gt.ghostPts u.1))
          (liftedPoint os.1 os.2))
      (PAB := fun cw (lSeeds : Fin (B + 1) → OpSeed cp) =>
        let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN st₁.hp.coords st₁.leafArr cw
        SeqGood (advanceBuildStep cp st₁.hp.coords)
          (fun st_b ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
            cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)
          steps (BuildState.init cp st₁.leafArr.length st₁.leafArr os.1 os.2 P₀_uid)
          (fun j => lSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩))
      (φ₁ := δ_ctr) (φ₂ := ((B + 1 : ℕ) : ℝ) * δ_op)
      hδ_ctr0 (mul_nonneg (Nat.cast_nonneg _) hδ_op0) hctr_lf
      (fun cw _ => seqGood_pad_card_ge cp hh0 hh1 hδ_op0 st₁.hp.coords hnode (B + 1) steps (Nat.min_le_right _ _) _)
    have hcomm_card : (Fintype.card (CenterSeed cp × (Fin (B + 1) → OpSeed cp)) : ℝ) =
        (Fintype.card (LeafSliceB B cp) : ℝ) := by
      exact_mod_cast Fintype.card_congr (Equiv.prodComm _ _)
    rw [hcomm_card] at hfub
    refine hfub.trans (Nat.cast_le.mpr ?_)
    rw [← Finset.card_map (Equiv.prodComm (CenterSeed cp) (Fin (B + 1) → OpSeed cp)).toEmbedding]
    refine Finset.card_le_card (fun sl hsl => ?_)
    rcases Finset.mem_map.mp hsl with ⟨⟨cw, lSeeds⟩, hmem, hsl_eq⟩
    rw [← hsl_eq]; dsimp only [Equiv.coe_toEmbedding, Equiv.prodComm_apply, s2LeafSlicePredB]
    rcases of_mem_filter_any hmem with ⟨hcp_cw, hsq_ls⟩
    exact mem_filter_univ_any (fun _ _ _ _ => ⟨hcp_cw, hsq_ls⟩)
  · have hall : (Finset.univ : Finset (LeafSliceB B cp)).filter (s2LeafSlicePredB B cp hh0 hh1 st₁) = Finset.univ :=
      Finset.filter_true_of_mem (fun _ _ h1 h2 h3 h4 => absurd ⟨h1, h2, h3, h4⟩ hcond)
    rw [hall, Finset.card_univ]
    have h1 : 1 - δ_leaf ≤ 1 := by linarith only [hδ_leaf0]
    simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)

private theorem goodStage2Coins_card_ge_B {d : ℕ} {params : LocalScaleParams} {h ε₀ : ℝ}
    (cp : ChainParams d params h) (D B : ℕ) (hD_le : D ≤ cp.D_max) (hB_pos : 0 < B)
    (hh0 : 0 < h) (hh1 : h < 1)
    (hε0 : 0 ≤ ε₀) (hε1 : ε₀ ≤ 1)
    (hgen_card : ∀ (i : Fin cp.N_cfg) (gen : SearchGeneration (Fin (2 ^ cp.L_p2)) (d + 1)),
      gen.m = 2 ^ cp.L_p2 → gen.h = h →
      open Classical in
      (1 - ε₀) * (Fintype.card (ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b) : ℝ) ≤
        ((Finset.univ.filter (fun ω : ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b =>
          IsOrderIndepGoodFilter (polyFDisc cp.T_cdf cp.p_coord ω) (cp.τ_d : ℝ) (cp.τ_q : ℝ)
            cp.cap_u cp.cap_q gen (paddedLatNet (M_lat_of d params.e) (cp.specs i).A (cp.specs i).B))).card : ℝ))
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp} (hwf₁ : PostStage1WF cp P' st₁)
    (hjob_err_le1 : ((cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))) +
      (B : ℝ) * ((2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀) ≤ 1) :
    let δ_op : ℝ := (2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀
    let δ_ctr : ℝ := (cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    let δ_S2 : ℝ := ((D + 1 : ℕ) : ℝ) * δ_ctr + ((D * B + (B + 1) : ℕ) : ℝ) * δ_op
    open Classical in
    (1 - δ_S2) * (Fintype.card (Stage2CoinsB D B cp) : ℝ) ≤
      ((Finset.univ.filter (GoodStage2CoinsB cp D B hD_le hh0 hh1 st₁)).card : ℝ) := by
  intro δ_op δ_ctr δ_S2
  have hδ_op0 : 0 ≤ δ_op := by positivity
  have hδ_ctr0 : 0 ≤ δ_ctr := by
    have h1 := cp.hφ0.le
    have h2 : (0 : ℝ) ≤ ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by positivity
    linarith only [h1, h2]
  have hnode : ∀ st_b : BuildState cp,
      (1 - δ_op) * (Fintype.card (OpSeed cp) : ℝ) ≤
        (((Finset.univ : Finset (OpSeed cp)).filter (fun ω =>
          NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
            cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)).card : ℝ) :=
    fun st_b => nodeOpSeedGood_card_ge cp.specs hh0 hh1 hε0 hε1 st_b.curNode.nd hgen_card
  let δ_job : ℝ := δ_ctr + (B : ℝ) * δ_op
  let δ_leaf : ℝ := δ_ctr + ((B + 1 : ℕ) : ℝ) * δ_op
  have hδ_job0 : 0 ≤ δ_job := add_nonneg hδ_ctr0 (mul_nonneg (Nat.cast_nonneg _) hδ_op0)
  have hδ_leaf0 : 0 ≤ δ_leaf := add_nonneg hδ_ctr0 (mul_nonneg (Nat.cast_nonneg _) hδ_op0)
  let P_r : Fin D → JobSliceB B cp → Prop := fun r sl =>
    s2JobSlicePredB B cp hh0 hh1 st₁ ⟨r.val, lt_of_lt_of_le r.isLt hD_le⟩ sl
  have hjob_each : ∀ r : Fin D,
      (1 - δ_job) * (Fintype.card (JobSliceB B cp) : ℝ) ≤
        (((Finset.univ : Finset (JobSliceB B cp)).filter (P_r r)).card : ℝ) :=
    fun r => s2JobSlice_good_card_ge B cp hh0 hh1 hδ_op0 hnode hwf₁ ⟨r.val, lt_of_lt_of_le r.isLt hD_le⟩
  have hpi_jobs := pi_good_card_ge P_r hδ_job0 hjob_err_le1 hjob_each
  rw [Fintype.card_fin] at hpi_jobs
  have hleaf_bound : (1 - δ_leaf) * (Fintype.card (LeafSliceB B cp) : ℝ) ≤
      (((Finset.univ : Finset (LeafSliceB B cp)).filter (s2LeafSlicePredB B cp hh0 hh1 st₁)).card : ℝ) :=
    s2LeafSlice_good_card_ge B cp hh0 hh1 hδ_op0 hnode hwf₁
  have hid : (D : ℝ) * δ_job + δ_leaf = δ_S2 := by
    dsimp only [δ_job, δ_leaf, δ_S2]; push_cast; ring
  have hfub_tot := fubini_good_card_ge
    (PA := fun js : Fin D → JobSliceB B cp => ∀ r, P_r r (js r))
    (PAB := fun _ (ls : LeafSliceB B cp) => s2LeafSlicePredB B cp hh0 hh1 st₁ ls)
    (φ₁ := (D : ℝ) * δ_job) (φ₂ := δ_leaf)
    (mul_nonneg (Nat.cast_nonneg _) hδ_job0) hδ_leaf0
    (hpi_jobs.trans (Nat.cast_le.mpr (Finset.card_le_card (fun _ h => mem_filter_univ_any (of_mem_filter_any h)))))
    (fun _ _ => hleaf_bound)
  have hcard_eq : (Fintype.card ((Fin D → JobSliceB B cp) × LeafSliceB B cp) : ℝ) =
      (Fintype.card (Stage2CoinsB D B cp) : ℝ) := by
    exact_mod_cast (Fintype.card_congr (stage2SliceEquivB D B hB_pos cp)).symm
  rw [hid, hcard_eq] at hfub_tot
  refine hfub_tot.trans (Nat.cast_le.mpr ?_)
  rw [← Finset.card_map (stage2SliceEquivB D B hB_pos cp).symm.toEmbedding]
  refine Finset.card_le_card (fun ω₂ hω₂ => ?_)
  rcases Finset.mem_map.mp hω₂ with ⟨⟨js, ls⟩, hmem, hω_eq⟩
  rw [← hω_eq]; dsimp only [Equiv.coe_toEmbedding]
  rcases of_mem_filter_any hmem with ⟨hjs, hls⟩
  have hto : stage2ToSlicesB D B cp ((stage2SliceEquivB D B hB_pos cp).symm (js, ls)) = (js, ls) :=
    (stage2SliceEquivB D B hB_pos cp).apply_symm_apply (js, ls)
  have hjs_eq : (stage2ToSlicesB D B cp ((stage2SliceEquivB D B hB_pos cp).symm (js, ls))).1 = js :=
    congrArg Prod.fst hto
  have hls_eq : (stage2ToSlicesB D B cp ((stage2SliceEquivB D B hB_pos cp).symm (js, ls))).2 = ls :=
    congrArg Prod.snd hto
  refine mem_filter_univ_any ⟨fun r hr jb hjb => ?_, ?_⟩
  · have hr_sl := congrFun hjs_eq r
    dsimp only [stage2ToSlicesB] at hr_sl
    have h1 : (fun j : Fin B => ((stage2SliceEquivB D B hB_pos cp).symm (js, ls)).1 ⟨r.val * B + j.val, _⟩) = (js r).1 :=
      congrArg Prod.fst hr_sl
    have h2 : ((stage2SliceEquivB D B hB_pos cp).symm (js, ls)).2 r.castSucc = (js r).2 :=
      congrArg Prod.snd hr_sl
    rw [h1, h2]
    exact hjs r hr jb hjb
  · dsimp only [stage2ToSlicesB] at hls_eq
    have h1 := congrArg Prod.fst hls_eq
    have h2 := congrArg Prod.snd hls_eq
    dsimp only at h1 h2
    rw [h1, h2]
    exact hls

theorem goodStage2Coins_card_ge {d : ℕ} {params : LocalScaleParams} {h ε₀ : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (hε0 : 0 ≤ ε₀) (hε1 : ε₀ ≤ 1)
    (hgen_card : ∀ (i : Fin cp.N_cfg) (gen : SearchGeneration (Fin (2 ^ cp.L_p2)) (d + 1)),
      gen.m = 2 ^ cp.L_p2 → gen.h = h →
      open Classical in
      (1 - ε₀) * (Fintype.card (ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b) : ℝ) ≤
        ((Finset.univ.filter (fun ω : ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b =>
          IsOrderIndepGoodFilter (polyFDisc cp.T_cdf cp.p_coord ω) (cp.τ_d : ℝ) (cp.τ_q : ℝ)
            cp.cap_u cp.cap_q gen (paddedLatNet (M_lat_of d params.e) (cp.specs i).A (cp.specs i).B))).card : ℝ))
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp} (hwf₁ : PostStage1WF cp P' st₁)
    (hjob_err_le1 : ((cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))) +
      (cp.B_scan : ℝ) * ((2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀) ≤ 1) :
    let δ_op : ℝ := (2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀
    let δ_ctr : ℝ := (cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    let δ_S2 : ℝ := ((cp.D_max + 1 : ℕ) : ℝ) * δ_ctr + (cp.N_op_s2 : ℝ) * δ_op
    open Classical in
    (1 - δ_S2) * (Fintype.card (Stage2Coins cp) : ℝ) ≤
      ((Finset.univ.filter (GoodStage2Coins cp hh0 hh1 st₁)).card : ℝ) :=
  goodStage2Coins_card_ge_B cp cp.D_max cp.B_scan le_rfl (by have := cp.sched_bounds.1; omega)
    hh0 hh1 hε0 hε1 hgen_card hwf₁ hjob_err_le1

end UL.Proof.clm_9_1_explicit_tradeoff.C14e
