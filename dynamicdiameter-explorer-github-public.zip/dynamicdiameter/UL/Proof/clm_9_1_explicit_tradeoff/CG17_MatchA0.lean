import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeA

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 1. Decoupled `SideRAMOps` Interface Record for `H4b.DyadicSideIndex` -/

/-- Decoupled deterministic RAM operations package for a single `H4b.DyadicSideIndex` instance,
reading pre-drawn seed bits from `coinTbl` on `insertStmt`. -/
structure SideRAMOps
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) where
  sideWStride : ℤ
  sideRStride : ℤ
  hsideW_ge_two : 2 ≤ sideWStride
  hsideR_nonneg : 0 ≤ sideRStride
  sideWScrStride : ℤ
  sideRScrStride : ℤ
  hsideWScr_pos : 1 ≤ sideWScrStride
  hsideRScr_pos : 1 ≤ sideRScrStride
  zeroInitCost : ℕ
  clearCost : ℕ
  removeCost : ℕ
  insertCost : ℕ
  queryCost : ℕ

  EncSide : ℤ → ℤ → Finset ℕ → DyadicSideIndex L_p2 R ℓ M₀ d b → ArithRAMMemory → Prop

  encSide_ep_pos : ∀ {sideBaseW sideBaseR : ℤ} {U : Finset ℕ}
    {idx : DyadicSideIndex L_p2 R ℓ M₀ d b} {m : ArithRAMMemory},
    EncSide sideBaseW sideBaseR U idx m →
    1 ≤ H3a.wRead m tblW sideBaseW

  encSide_mono_slice : ∀ {sideBaseW sideBaseR : ℤ} {U : Finset ℕ}
    {idx : DyadicSideIndex L_p2 R ℓ M₀ d b} {m₀ m₁ : ArithRAMMemory},
    (∀ u ∈ U, u < n) →
    EncSide sideBaseW sideBaseR U idx m₀ →
    (∀ i : ℤ, sideBaseW ≤ i → i < sideBaseW + sideWStride →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i) →
    (∀ i : ℤ, sideBaseR ≤ i → i < sideBaseR + sideRStride →
      H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i) →
    EncSide sideBaseW sideBaseR U idx m₁

  zeroInitStmt : (wSideBaseW wSideBaseR wScr rScr : ℤ) → ArithRAMStmt
  clearStmt : (wSideBaseW wSideBaseR wScr rScr : ℤ) → ArithRAMStmt
  removeStmt : (wSideBaseW wSideBaseR wUid wScr rScr : ℤ) → ArithRAMStmt
  insertStmt : (A B_rat : ℚ) →
    (wSideBaseW wSideBaseR wOffO wUid wSeedBase wScr rScr : ℤ) → ArithRAMStmt
  queryStmt : (A B_rat b_rat : ℚ) →
    (wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr : ℤ) → ArithRAMStmt

  zeroRand_zeroInitStmt : ∀ wBW wBR wScr rScr,
    ZeroRandStmt (zeroInitStmt wBW wBR wScr rScr)
  zeroRand_clearStmt : ∀ wBW wBR wScr rScr,
    ZeroRandStmt (clearStmt wBW wBR wScr rScr)
  zeroRand_removeStmt : ∀ wBW wBR wUid wScr rScr,
    ZeroRandStmt (removeStmt wBW wBR wUid wScr rScr)
  zeroRand_insertStmt : ∀ A B_rat wBW wBR wOffO wUid wSeed wScr rScr,
    ZeroRandStmt (insertStmt A B_rat wBW wBR wOffO wUid wSeed wScr rScr)
  zeroRand_queryStmt : ∀ A B_rat b_rat wBW wBR wOffO wQry wAns wScr rScr,
    ZeroRandStmt (queryStmt A B_rat b_rat wBW wBR wOffO wQry wAns wScr rScr)

  exec_zeroInitStmt : ∀ {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wScr rScr sideBaseW sideBaseR : ℤ),
    InFootprint TW BW TR BR m₀ →
    ValidNodeTables TW TR scrW scrR tblW tblR coinTbl →
    (0 ≤ sideBaseW ∧ sideBaseW + sideWStride ≤ (BW : ℤ)) →
    (0 ≤ sideBaseR ∧ sideBaseR + sideRStride ≤ (BR : ℤ)) →
    (0 ≤ wSideBaseW ∧ wSideBaseW < wScr) →
    (0 ≤ wSideBaseR ∧ wSideBaseR < wScr) →
    (wSideBaseW ≠ wSideBaseR) →
    (0 ≤ wScr ∧ wScr + sideWScrStride ≤ (BW : ℤ)) →
    (0 ≤ rScr ∧ rScr + sideRScrStride ≤ (BR : ℤ)) →
    H3a.wRead m₀ scrW wSideBaseW = sideBaseW →
    H3a.wRead m₀ scrW wSideBaseR = sideBaseR →
    (∀ i : ℤ, sideBaseW ≤ i → i < sideBaseW + sideWStride → H3a.wRead m₀ tblW i = 0) →
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (zeroInitStmt wSideBaseW wSideBaseR wScr rScr) m₀ m₁ zeroInitCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncSide sideBaseW sideBaseR ∅ (DyadicSideIndex.empty L_p2 R ℓ M₀ d b T_cdf p_coord) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW sideBaseW sideWStride tblR sideBaseR sideRStride m₀ m₁

  exec_clearStmt : ∀ {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wScr rScr sideBaseW sideBaseR : ℤ)
    {U : Finset ℕ} {idx : DyadicSideIndex L_p2 R ℓ M₀ d b},
    InFootprint TW BW TR BR m₀ →
    ValidNodeTables TW TR scrW scrR tblW tblR coinTbl →
    (0 ≤ sideBaseW ∧ sideBaseW + sideWStride ≤ (BW : ℤ)) →
    (0 ≤ sideBaseR ∧ sideBaseR + sideRStride ≤ (BR : ℤ)) →
    (0 ≤ wSideBaseW ∧ wSideBaseW < wScr) →
    (0 ≤ wSideBaseR ∧ wSideBaseR < wScr) →
    (wSideBaseW ≠ wSideBaseR) →
    (0 ≤ wScr ∧ wScr + sideWScrStride ≤ (BW : ℤ)) →
    (0 ≤ rScr ∧ rScr + sideRScrStride ≤ (BR : ℤ)) →
    H3a.wRead m₀ scrW wSideBaseW = sideBaseW →
    H3a.wRead m₀ scrW wSideBaseR = sideBaseR →
    EncSide sideBaseW sideBaseR U idx m₀ →
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (clearStmt wSideBaseW wSideBaseR wScr rScr) m₀ m₁ clearCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncSide sideBaseW sideBaseR ∅ (DyadicSideIndex.empty L_p2 R ℓ M₀ d b T_cdf p_coord) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW sideBaseW sideWStride tblR sideBaseR sideRStride m₀ m₁

  exec_removeStmt : ∀ {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (hM₀ : 1 ≤ M₀) (_hn : 2 ≤ n) (_hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    {A B_rat : ℚ} (_hAB : A ^ 2 + B_rat ^ 2 = 1)
    (wSideBaseW wSideBaseR wUid wScr rScr sideBaseW sideBaseR : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {U : Finset ℕ} {h₀ : ℕ} (_hh0_lt : h₀ < n) (_hU_lt : ∀ x ∈ U, x < n)
    {idx : DyadicSideIndex L_p2 R ℓ M₀ d b}
    (_hwf : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o U idx),
    InFootprint TW BW TR BR m₀ →
    ValidNodeTables TW TR scrW scrR tblW tblR coinTbl →
    (0 ≤ sideBaseW ∧ sideBaseW + sideWStride ≤ (BW : ℤ)) →
    (0 ≤ sideBaseR ∧ sideBaseR + sideRStride ≤ (BR : ℤ)) →
    (0 ≤ wSideBaseW ∧ wSideBaseW < wScr) →
    (0 ≤ wSideBaseR ∧ wSideBaseR < wScr) →
    (0 ≤ wUid ∧ wUid < wScr) →
    (wSideBaseW ≠ wSideBaseR ∧ wSideBaseW ≠ wUid ∧ wSideBaseR ≠ wUid) →
    (0 ≤ wScr ∧ wScr + sideWScrStride ≤ (BW : ℤ)) →
    (0 ≤ rScr ∧ rScr + sideRScrStride ≤ (BR : ℤ)) →
    H3a.wRead m₀ scrW wSideBaseW = sideBaseW →
    H3a.wRead m₀ scrW wSideBaseR = sideBaseR →
    H3a.wRead m₀ scrW wUid = (h₀ : ℤ) →
    EncSide sideBaseW sideBaseR U idx m₀ →
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (removeStmt wSideBaseW wSideBaseR wUid wScr rScr) m₀ m₁ removeCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncSide sideBaseW sideBaseR (U.erase h₀) (idx.removeHandle h₀) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW sideBaseW sideWStride tblR sideBaseR sideRStride m₀ m₁

  exec_insertStmt : ∀ {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (hM₀ : 1 ≤ M₀) (_hn : 2 ≤ n) (_hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    (A B_rat : ℚ) (_hAB : A ^ 2 + B_rat ^ 2 = 1)
    (wSideBaseW wSideBaseR wOffO wUid wSeedBase wScr rScr
      sideBaseW sideBaseR offO seedBase : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {U : Finset ℕ} {h₀ : ℕ} (_hh0_not : h₀ ∉ U) (_hh0_lt : h₀ < n)
    (_hU_lt : ∀ x ∈ U, x < n) (_hne_o : pts h₀ ≠ o)
    (ω_side : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {idx : DyadicSideIndex L_p2 R ℓ M₀ d b}
    (_ht_lt : idx.t_ins + 1 < 2 ^ L_p2)
    (_hwf : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o U idx),
    InFootprint TW BW TR BR m₀ →
    ValidNodeTables TW TR scrW scrR tblW tblR coinTbl →
    (0 ≤ sideBaseW ∧ sideBaseW + sideWStride ≤ (BW : ℤ)) →
    (0 ≤ sideBaseR ∧ sideBaseR + sideRStride ≤ (BR : ℤ)) →
    (0 ≤ offO ∧ offO + (d : ℤ) ≤ sideBaseR) →
    (0 ≤ seedBase ∧
      seedBase + ((L_p2 * oneSeedBits R ℓ M₀ d b : ℕ) : ℤ) ≤ (BW : ℤ)) →
    (((n * d : ℕ) : ℤ) ≤ (BR : ℤ)) →
    (0 ≤ wSideBaseW ∧ wSideBaseW < wScr) →
    (0 ≤ wSideBaseR ∧ wSideBaseR < wScr) →
    (0 ≤ wOffO ∧ wOffO < wScr) →
    (0 ≤ wUid ∧ wUid < wScr) →
    (0 ≤ wSeedBase ∧ wSeedBase < wScr) →
    (wSideBaseW ≠ wSideBaseR ∧ wSideBaseW ≠ wOffO ∧ wSideBaseW ≠ wUid ∧ wSideBaseW ≠ wSeedBase ∧
      wSideBaseR ≠ wOffO ∧ wSideBaseR ≠ wUid ∧ wSideBaseR ≠ wSeedBase ∧
      wOffO ≠ wUid ∧ wOffO ≠ wSeedBase ∧ wUid ≠ wSeedBase) →
    (0 ≤ wScr ∧ wScr + sideWScrStride ≤ (BW : ℤ)) →
    (0 ≤ rScr ∧ rScr + sideRScrStride ≤ (BR : ℤ)) →
    H3a.wRead m₀ scrW wSideBaseW = sideBaseW →
    H3a.wRead m₀ scrW wSideBaseR = sideBaseR →
    H3a.wRead m₀ scrW wOffO = offO →
    H3a.wRead m₀ scrW wUid = (h₀ : ℤ) →
    H3a.wRead m₀ scrW wSeedBase = seedBase →
    (∀ c : Fin d, H3a.rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c) →
    (∀ x ∈ Insert.insert h₀ U, ∀ c : Fin d,
      H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) →
    (∀ s : Fin L_p2,
      EncOneSeedSlice coinTbl (seedBase + (s.val : ℤ) * (oneSeedBits R ℓ M₀ d b : ℤ))
        (ω_side s) m₀) →
    EncSide sideBaseW sideBaseR U idx m₀ →
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (insertStmt A B_rat wSideBaseW wSideBaseR wOffO wUid wSeedBase wScr rScr)
        m₀ m₁ insertCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncSide sideBaseW sideBaseR (Insert.insert h₀ U)
        (idx.insertHandle hM₀ T_cdf p_coord A B_rat τ_d cap_u o (pts h₀) h₀ ω_side) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW sideBaseW sideWStride tblR sideBaseR sideRStride m₀ m₁

  exec_queryStmt : ∀ {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (hM₀ : 1 ≤ M₀) (_hn : 2 ≤ n) (_hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    (A B_rat b_rat : ℚ) (_hAB : A ^ 2 + B_rat ^ 2 = 1)
    (wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr
      sideBaseW sideBaseR offO : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {U : Finset ℕ} {qUid : ℕ} (_hq_lt : qUid < n)
    (_hU_lt : ∀ x ∈ U, x < n) (_hq_ne_o : pts qUid ≠ o)
    {idx : DyadicSideIndex L_p2 R ℓ M₀ d b}
    (_ht_lt : idx.t_ins < 2 ^ L_p2)
    (_hwf : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o U idx),
    InFootprint TW BW TR BR m₀ →
    ValidNodeTables TW TR scrW scrR tblW tblR coinTbl →
    (0 ≤ sideBaseW ∧ sideBaseW + sideWStride ≤ (BW : ℤ)) →
    (0 ≤ sideBaseR ∧ sideBaseR + sideRStride ≤ (BR : ℤ)) →
    (0 ≤ offO ∧ offO + (d : ℤ) ≤ sideBaseR) →
    (((n * d : ℕ) : ℤ) ≤ (BR : ℤ)) →
    (0 ≤ wSideBaseW ∧ wSideBaseW < wScr) →
    (0 ≤ wSideBaseR ∧ wSideBaseR < wScr) →
    (0 ≤ wOffO ∧ wOffO < wScr) →
    (0 ≤ wQryUid ∧ wQryUid < wScr) →
    (0 ≤ wAnsOut ∧ wAnsOut < wScr) →
    (wSideBaseW ≠ wSideBaseR ∧ wSideBaseW ≠ wOffO ∧ wSideBaseW ≠ wQryUid ∧ wSideBaseW ≠ wAnsOut ∧
      wSideBaseR ≠ wOffO ∧ wSideBaseR ≠ wQryUid ∧ wSideBaseR ≠ wAnsOut ∧
      wOffO ≠ wQryUid ∧ wOffO ≠ wAnsOut ∧ wQryUid ≠ wAnsOut) →
    (0 ≤ wScr ∧ wScr + sideWScrStride ≤ (BW : ℤ)) →
    (0 ≤ rScr ∧ rScr + sideRScrStride ≤ (BR : ℤ)) →
    H3a.wRead m₀ scrW wSideBaseW = sideBaseW →
    H3a.wRead m₀ scrW wSideBaseR = sideBaseR →
    H3a.wRead m₀ scrW wOffO = offO →
    H3a.wRead m₀ scrW wQryUid = (qUid : ℤ) →
    (∀ c : Fin d, H3a.rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c) →
    (∀ x ∈ Insert.insert qUid U, ∀ c : Fin d,
      H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) →
    EncSide sideBaseW sideBaseR U idx m₀ →
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (queryStmt A B_rat b_rat wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr)
        m₀ m₁ queryCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncSide sideBaseW sideBaseR U idx m₁ ∧
      (match idx.query hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q o (pts qUid) with
       | none => H3a.wRead m₁ scrW wAnsOut = -1
       | some w => H3a.wRead m₁ scrW wAnsOut = (w : ℤ)) ∧
      (∀ w, w < wScr → w ≠ wAnsOut → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW sideBaseW sideWStride tblR sideBaseR sideRStride m₀ m₁

/-! ### 2. `RadFrameOutside` Combinators -/

theorem rfo_wWrite_scr (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) (idx val : ℤ) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (H3a.wWrite m scrW idx val) :=
  ⟨fun _ _ hs _ => wRead_wWrite_of_ne m val (Or.inl hs),
   fun t _ _ _ => rRead_wWrite m t scrW _ idx val⟩

theorem rfo_rWrite_scr (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) (idx : ℤ) (val : ℝ) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (H3a.rWrite m scrR idx val) :=
  ⟨fun t _ _ _ => wRead_rWrite m t scrR _ idx val,
   fun _ _ hs _ => rRead_rWrite_of_ne m val (Or.inl hs)⟩

theorem rfo_wWrite_in (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) {idx : ℤ} (val : ℤ)
    (hlo : baseW ≤ idx) (hhi : idx < baseW + lenW) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (H3a.wWrite m tblW idx val) := by
  refine ⟨fun t i _ ho => ?_, fun t _ _ _ => rRead_wWrite m t tblW _ idx val⟩
  rcases ho with ht | h1 | h2
  · exact wRead_wWrite_of_ne m val (Or.inl ht)
  · exact wRead_wWrite_of_ne m val (Or.inr (by omega))
  · exact wRead_wWrite_of_ne m val (Or.inr (by omega))

theorem rfo_mono_range {scrW scrR tblW : ℕ} {bW₁ lW₁ bW₂ lW₂ : ℤ}
    {tblR : ℕ} {bR₁ lR₁ bR₂ lR₂ : ℤ} {m₀ m₁ : ArithRAMMemory}
    (h : RadFrameOutside scrW scrR tblW bW₁ lW₁ tblR bR₁ lR₁ m₀ m₁)
    (hW : lW₁ = 0 ∨ (bW₂ ≤ bW₁ ∧ bW₁ + lW₁ ≤ bW₂ + lW₂))
    (hR : lR₁ = 0 ∨ (bR₂ ≤ bR₁ ∧ bR₁ + lR₁ ≤ bR₂ + lR₂)) :
    RadFrameOutside scrW scrR tblW bW₂ lW₂ tblR bR₂ lR₂ m₀ m₁ := by
  refine ⟨fun t i hs ho => h.1 t i hs ?_, fun t i hs ho => h.2 t i hs ?_⟩
  · rcases hW with h0 | ⟨hlo, hhi⟩
    · subst h0
      rcases le_or_gt bW₁ i with hge | hlt
      · exact Or.inr (Or.inr (by omega))
      · exact Or.inr (Or.inl hlt)
    · rcases ho with ht | hlt | hge
      · exact Or.inl ht
      · exact Or.inr (Or.inl (by omega))
      · exact Or.inr (Or.inr (by omega))
  · rcases hR with h0 | ⟨hlo, hhi⟩
    · subst h0
      rcases le_or_gt bR₁ i with hge | hlt
      · exact Or.inr (Or.inr (by omega))
      · exact Or.inr (Or.inl hlt)
    · rcases ho with ht | hlt | hge
      · exact Or.inl ht
      · exact Or.inr (Or.inl (by omega))
      · exact Or.inr (Or.inr (by omega))

/-! ### 3. Pure Geometry & Local Matching Lemmas -/

theorem shellIndex_eq_iff_inShellBySqCmp {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    (s : ℕ) (pt : EuclideanSpace ℝ (Fin d)) :
    shellIndex m0 o V pt = s ↔ InShellBySqCmp m0 o V s pt := by
  have hsqrt_pos : 0 < Real.sqrt V := Real.sqrt_pos.mpr hV
  have hsqrt_sq : Real.sqrt V ^ 2 = V := Real.sq_sqrt hV.le
  let q : ℝ := (m0 : ℝ) * ‖pt - o‖ / Real.sqrt V
  have hq_nn : 0 ≤ q := div_nonneg (mul_nonneg (Nat.cast_nonneg m0) (norm_nonneg _)) hsqrt_pos.le
  unfold shellIndex InShellBySqCmp
  rw [Nat.floor_eq_iff hq_nn]
  have hmul_eq : q * Real.sqrt V = (m0 : ℝ) * ‖pt - o‖ := div_mul_cancel₀ _ hsqrt_pos.ne'
  constructor
  · rintro ⟨hlo, hhi⟩
    have hlo' : (s : ℝ) * Real.sqrt V ≤ (m0 : ℝ) * ‖pt - o‖ := by
      have := mul_le_mul_of_nonneg_right hlo hsqrt_pos.le
      rwa [hmul_eq] at this
    have hhi' : (m0 : ℝ) * ‖pt - o‖ < ((s : ℝ) + 1) * Real.sqrt V := by
      have := mul_lt_mul_of_pos_right hhi hsqrt_pos
      rwa [hmul_eq] at this
    constructor
    · have hsq := pow_le_pow_left₀ (mul_nonneg (Nat.cast_nonneg s) hsqrt_pos.le) hlo' 2
      nlinarith [hsqrt_sq]
    · have hsq := pow_lt_pow_left₀ hhi' (mul_nonneg (Nat.cast_nonneg m0) (norm_nonneg _)) (by decide : (2 : ℕ) ≠ 0)
      push_cast
      nlinarith [hsqrt_sq]
  · rintro ⟨hlo, hhi⟩
    constructor
    · by_contra hnot
      push_neg at hnot
      have hlt' : (m0 : ℝ) * ‖pt - o‖ < (s : ℝ) * Real.sqrt V := by
        have := mul_lt_mul_of_pos_right hnot hsqrt_pos
        rwa [hmul_eq] at this
      have hsq := pow_lt_pow_left₀ hlt' (mul_nonneg (Nat.cast_nonneg m0) (norm_nonneg _)) (by decide : (2 : ℕ) ≠ 0)
      nlinarith [hsqrt_sq]
    · by_contra hnot
      push_neg at hnot
      have hle' : ((s : ℝ) + 1) * Real.sqrt V ≤ (m0 : ℝ) * ‖pt - o‖ := by
        have := mul_le_mul_of_nonneg_right hnot hsqrt_pos.le
        rwa [hmul_eq] at this
      have hsq := pow_le_pow_left₀ (by positivity) hle' 2
      push_cast at hhi
      nlinarith [hsqrt_sq]

theorem hasApplicableLeftCopy_iff_sq {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    (j : ℕ) (pt : EuclideanSpace ℝ (Fin d)) :
    hasApplicableLeftCopy m0 o V j pt ↔
      (‖pt - o‖ ^ 2 ≤ V ∧
       (j : ℝ) ^ 2 * V ≤ (m0 : ℝ) ^ 2 * ‖pt - o‖ ^ 2 ∧
       (m0 : ℝ) ^ 2 * ‖pt - o‖ ^ 2 < ((j + 1 : ℕ) : ℝ) ^ 2 * V) := by
  unfold hasApplicableLeftCopy
  rw [coreBall_iff_sq o pt hV.le, shellIndex_eq_iff_inShellBySqCmp m0 o hV j pt]
  rfl

theorem hasApplicableRightCopy_iff_sq {d : ℕ} (m0 : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    {K : ℤ} (hK : 0 ≤ K) (k : ℕ) (pt : EuclideanSpace ℝ (Fin d)) :
    hasApplicableRightCopy m0 o V K k pt ↔
      (‖pt - o‖ ^ 2 ≤ (K : ℝ) ^ 2 * V ∧
       (k : ℝ) ^ 2 * V ≤ (m0 : ℝ) ^ 2 * ‖pt - o‖ ^ 2 ∧
       (m0 : ℝ) ^ 2 * ‖pt - o‖ ^ 2 < ((k + 1 : ℕ) : ℝ) ^ 2 * V) := by
  unfold hasApplicableRightCopy
  rw [isEligiblePoint_iff_sq o pt hV.le hK, shellIndex_eq_iff_inShellBySqCmp m0 o hV k pt]
  rfl

theorem sanitize_eq_raw {L_p2 R ℓ M₀ d b : ℕ} (hM₀ : 1 ≤ M₀)
    {T_cdf p_coord : ℕ} (M_lat : ℕ) (params : LocalScaleParams)
    {A B_rat τ_d : ℚ} (τ_q : ℚ) {cap_u : ℕ} (cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {V : ℝ} (hV : 0 < V) (cfg : ShellConfig)
    (st : LocalMatchingState ℕ) (v : CopyVertex ℕ)
    {oppIdx : DyadicSideIndex L_p2 R ℓ M₀ d b}
    (hwf : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o
      (st.oppositeIndexSet v.side) oppIdx) :
    sanitizeConfigAttachAnswer pts params o V cfg st v
      (oppIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts v.id)) =
    oppIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts v.id) := by
  cases hraw : oppIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts v.id) with
  | none => rfl
  | some w =>
      obtain ⟨hw_mem, hcorr⟩ := dyadicSide_query_sound hM₀ M_lat τ_q (bRatCfg params cfg : ℝ)
        cap_q (pts v.id) hwf hraw
      unfold sanitizeConfigAttachAnswer
      dsimp only
      rw [if_pos]
      refine ⟨hw_mem, ?_⟩
      unfold attachAcceptsCorrelation
      rwa [thresholdB_eq_bRatCfg params hV cfg]

theorem isCopyInIndex_left_iff (st : LocalMatchingState ℕ) (u : ℕ) :
    st.isCopyInIndex ⟨.left, u⟩ ↔ u ∈ st.leftIndexSet := by
  classical
  simp [LocalMatchingState.isCopyInIndex, LocalMatchingState.leftIndexSet]

theorem isCopyInIndex_right_iff (st : LocalMatchingState ℕ) (u : ℕ) :
    st.isCopyInIndex ⟨.right, u⟩ ↔ u ∈ st.rightIndexSet := by
  classical
  simp [LocalMatchingState.isCopyInIndex, LocalMatchingState.rightIndexSet]

theorem leftIndexSet_attachStep_eq {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (st : LocalMatchingState ℕ) (v : CopyVertex ℕ) (ans : Option ℕ) :
    (attachStep pts st v ans).leftIndexSet =
      match v.side, ans with
      | .left, some _ => st.leftIndexSet
      | .left, none => Insert.insert v.id st.leftIndexSet
      | .right, some w => st.leftIndexSet.erase w
      | .right, none => st.leftIndexSet := by
  classical
  rcases v with ⟨side, uid⟩
  cases side <;> cases ans <;> ext x <;>
    simp [attachStep, LocalMatchingState.leftIndexSet] <;> aesop

theorem rightIndexSet_attachStep_eq {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (st : LocalMatchingState ℕ) (v : CopyVertex ℕ) (ans : Option ℕ) :
    (attachStep pts st v ans).rightIndexSet =
      match v.side, ans with
      | .left, some w => st.rightIndexSet.erase w
      | .left, none => st.rightIndexSet
      | .right, some _ => st.rightIndexSet
      | .right, none => Insert.insert v.id st.rightIndexSet := by
  classical
  rcases v with ⟨side, uid⟩
  cases side <;> cases ans <;> ext x <;>
    simp [attachStep, LocalMatchingState.rightIndexSet] <;> aesop

theorem leftIndexSet_removeCopies_eq (st : LocalMatchingState ℕ) (p : ℕ) :
    (removeCopiesFromState st p).leftIndexSet = st.leftIndexSet.erase p := by
  classical
  ext x
  simp [removeCopiesFromState, LocalMatchingState.leftIndexSet]
  aesop

theorem rightIndexSet_removeCopies_eq (st : LocalMatchingState ℕ) (p : ℕ) :
    (removeCopiesFromState st p).rightIndexSet = st.rightIndexSet.erase p := by
  classical
  ext x
  simp [removeCopiesFromState, LocalMatchingState.rightIndexSet]
  aesop

theorem leftVertices_subset {d : ℕ} (params : LocalScaleParams)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (V : ℝ) (S : Finset ℕ) (j : ℕ) :
    params.leftVertices pts o V S j ⊆ S := by
  classical
  intro x hx
  unfold LocalScaleParams.leftVertices configLeftVertices shellSubset nodeCore at hx
  exact Finset.mem_of_mem_filter x (Finset.mem_of_mem_filter x hx)

theorem rightVertices_subset {d : ℕ} (params : LocalScaleParams)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (V : ℝ) (S : Finset ℕ) (k : ℕ) :
    params.rightVertices pts o V S k ⊆ S := by
  classical
  intro x hx
  exact Finset.filter_subset _ _ (Finset.filter_subset _ _ hx)

theorem ne_center_of_mem_leftVertices {d : ℕ} (params : LocalScaleParams)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {V : ℝ} {S : Finset ℕ} {cfg : ShellConfig}
    (hmem : cfg ∈ params.retainedConfigs 1) {x : ℕ}
    (hx : x ∈ params.leftVertices pts o V S cfg.j) :
    pts x ≠ o := by
  classical
  have hj1 := (retainedConfig_shells_pos params hmem).1
  unfold LocalScaleParams.leftVertices configLeftVertices shellSubset at hx
  exact ne_center_of_shellIndex_pos hj1 (Finset.mem_filter.mp hx).2

theorem ne_center_of_mem_rightVertices {d : ℕ} (params : LocalScaleParams)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {V : ℝ} {S : Finset ℕ} {cfg : ShellConfig}
    (hmem : cfg ∈ params.retainedConfigs 1) {y : ℕ}
    (hy : y ∈ params.rightVertices pts o V S cfg.k) :
    pts y ≠ o := by
  classical
  have hk1 := (retainedConfig_shells_pos params hmem).2.2.1
  unfold LocalScaleParams.rightVertices configRightVertices shellSubset at hy
  exact ne_center_of_shellIndex_pos hk1 (Finset.mem_filter.mp hy).2

theorem unmatchedLeft_subset (V_L : Finset ℕ) (M : Finset (ℕ × ℕ)) :
    unmatchedLeft V_L M ⊆ V_L := by
  classical
  exact Finset.filter_subset _ _

theorem unmatchedRight_subset (V_R : Finset ℕ) (M : Finset (ℕ × ℕ)) :
    unmatchedRight V_R M ⊆ V_R := by
  classical
  exact Finset.filter_subset _ _

/-! ### 4. Memory Layout Offsets, `IsKeyDLL`, `EncLocalMatching`, `EncCfgDyn` & `CfgSlotReady` -/

def cfgHdrWStride (n : ℕ) : ℤ := 3 + 8 * (n : ℤ)

theorem cfgHdrWStride_ge_three (n : ℕ) : 3 ≤ cfgHdrWStride n := by
  unfold cfgHdrWStride; omega

def cfgEpOff (cfgBaseW : ℤ) : ℤ := cfgBaseW
def cfgHeadOff (cfgBaseW : ℤ) : ℤ := cfgBaseW + 1
def cfgTailOff (cfgBaseW : ℤ) : ℤ := cfgBaseW + 2
def cfgMateLEpOff (cfgBaseW : ℤ) (n u : ℕ) : ℤ := cfgBaseW + 3 + 0 * (n : ℤ) + (u : ℤ)
def cfgMateLValOff (cfgBaseW : ℤ) (n u : ℕ) : ℤ := cfgBaseW + 3 + 1 * (n : ℤ) + (u : ℤ)
def cfgMateREpOff (cfgBaseW : ℤ) (n u : ℕ) : ℤ := cfgBaseW + 3 + 2 * (n : ℤ) + (u : ℤ)
def cfgMateRValOff (cfgBaseW : ℤ) (n u : ℕ) : ℤ := cfgBaseW + 3 + 3 * (n : ℤ) + (u : ℤ)
def cfgInIdxLEpOff (cfgBaseW : ℤ) (n u : ℕ) : ℤ := cfgBaseW + 3 + 4 * (n : ℤ) + (u : ℤ)
def cfgInIdxREpOff (cfgBaseW : ℤ) (n u : ℕ) : ℤ := cfgBaseW + 3 + 5 * (n : ℤ) + (u : ℤ)
def cfgPrevOff (cfgBaseW : ℤ) (n u : ℕ) : ℤ := cfgBaseW + 3 + 6 * (n : ℤ) + (u : ℤ)
def cfgNextOff (cfgBaseW : ℤ) (n u : ℕ) : ℤ := cfgBaseW + 3 + 7 * (n : ℤ) + (u : ℤ)

def cfgLeftSideWOff (cfgBaseW : ℤ) (n : ℕ) : ℤ :=
  cfgBaseW + cfgHdrWStride n

def cfgRightSideWOff (cfgBaseW sideWStride : ℤ) (n : ℕ) : ℤ :=
  cfgBaseW + cfgHdrWStride n + sideWStride

def cfgLeftSideROff (cfgBaseR : ℤ) : ℤ := cfgBaseR
def cfgRightSideROff (cfgBaseR sideRStride : ℤ) : ℤ := cfgBaseR + sideRStride

def cfgTotalWStride (n : ℕ) (sideWStride : ℤ) : ℤ :=
  cfgHdrWStride n + 2 * sideWStride

def cfgTotalRStride (sideRStride : ℤ) : ℤ :=
  2 * sideRStride

/-- Intrusive doubly linked list on unique left-endpoint keys `L : List ℕ`. -/
def IsKeyDLL (L : List ℕ) (hd tl : ℤ) (prv nxt : ℕ → ℤ) : Prop :=
  (L = [] → hd = -1 ∧ tl = -1) ∧
  (∀ hne : L ≠ [],
    have hpos : 0 < L.length := List.length_pos_iff.mpr hne
    hd = (L[0]'hpos : ℤ) ∧
    tl = (L[L.length - 1]'(Nat.sub_lt hpos Nat.one_pos) : ℤ) ∧
    ∀ (i : ℕ) (hi : i < L.length),
      prv (L[i]'hi) = (if hi0 : i = 0 then -1 else (L[i - 1]'(by omega) : ℤ)) ∧
      nxt (L[i]'hi) = (if hi1 : i + 1 = L.length then -1 else (L[i + 1]'(by omega) : ℤ)))

theorem IsKeyDLL.nil (prv nxt : ℕ → ℤ) : IsKeyDLL [] (-1) (-1) prv nxt :=
  ⟨fun _ => ⟨rfl, rfl⟩, fun h => False.elim (h rfl)⟩

theorem IsKeyDLL.congr {L : List ℕ} {hd hd' tl tl' : ℤ} {prv prv' nxt nxt' : ℕ → ℤ}
    (hdll : IsKeyDLL L hd tl prv nxt)
    (hhd : hd' = hd) (htl : tl' = tl)
    (hprv : ∀ k ∈ L, prv' k = prv k)
    (hnxt : ∀ k ∈ L, nxt' k = nxt k) :
    IsKeyDLL L hd' tl' prv' nxt' := by
  subst hhd; subst htl
  refine ⟨hdll.1, fun hne => ?_⟩
  obtain ⟨h0, hlast, hstep⟩ := hdll.2 hne
  refine ⟨h0, hlast, fun i hi => ?_⟩
  have hmem : L[i]'hi ∈ L := List.getElem_mem hi
  rw [hprv _ hmem, hnxt _ hmem]
  exact hstep i hi

/-- Epoch-tagged + intrusive FIFO DLL representation of `LocalMatchingState ℕ`. -/
def EncLocalMatching (tblW : ℕ) (cfgBaseW : ℤ) (n : ℕ)
    (st : LocalMatchingState ℕ) (m : ArithRAMMemory) : Prop :=
  let pairs := st.matchingList.map MatchingEdge.pair
  let L_keys := pairs.map Prod.fst
  let R_keys := pairs.map Prod.snd
  ∃ ep : ℕ,
    1 ≤ ep ∧
    H3a.wRead m tblW (cfgEpOff cfgBaseW) = (ep : ℤ) ∧
    L_keys.Nodup ∧
    R_keys.Nodup ∧
    (∀ xy ∈ pairs, xy.1 < n ∧ xy.2 < n) ∧
    (∀ u ∈ st.leftIndexSet, u < n) ∧
    (∀ u ∈ st.rightIndexSet, u < n) ∧
    IsKeyDLL L_keys
      (H3a.wRead m tblW (cfgHeadOff cfgBaseW))
      (H3a.wRead m tblW (cfgTailOff cfgBaseW))
      (fun k => H3a.wRead m tblW (cfgPrevOff cfgBaseW n k))
      (fun k => H3a.wRead m tblW (cfgNextOff cfgBaseW n k)) ∧
    (∀ u < n, H3a.wRead m tblW (cfgMateLEpOff cfgBaseW n u) ≤ (ep : ℤ)) ∧
    (∀ u < n, H3a.wRead m tblW (cfgMateLEpOff cfgBaseW n u) = (ep : ℤ) →
      ∃ y, (u, y) ∈ pairs ∧ H3a.wRead m tblW (cfgMateLValOff cfgBaseW n u) = (y : ℤ)) ∧
    (∀ x y, (x, y) ∈ pairs →
      H3a.wRead m tblW (cfgMateLEpOff cfgBaseW n x) = (ep : ℤ) ∧
      H3a.wRead m tblW (cfgMateLValOff cfgBaseW n x) = (y : ℤ)) ∧
    (∀ u < n, H3a.wRead m tblW (cfgMateREpOff cfgBaseW n u) ≤ (ep : ℤ)) ∧
    (∀ u < n, H3a.wRead m tblW (cfgMateREpOff cfgBaseW n u) = (ep : ℤ) →
      ∃ x, (x, u) ∈ pairs ∧ H3a.wRead m tblW (cfgMateRValOff cfgBaseW n u) = (x : ℤ)) ∧
    (∀ x y, (x, y) ∈ pairs →
      H3a.wRead m tblW (cfgMateREpOff cfgBaseW n y) = (ep : ℤ) ∧
      H3a.wRead m tblW (cfgMateRValOff cfgBaseW n y) = (x : ℤ)) ∧
    (∀ u < n,
      H3a.wRead m tblW (cfgInIdxLEpOff cfgBaseW n u) ≤ (ep : ℤ) ∧
      (H3a.wRead m tblW (cfgInIdxLEpOff cfgBaseW n u) = (ep : ℤ) ↔ u ∈ st.leftIndexSet)) ∧
    (∀ u < n,
      H3a.wRead m tblW (cfgInIdxREpOff cfgBaseW n u) ≤ (ep : ℤ) ∧
      (H3a.wRead m tblW (cfgInIdxREpOff cfgBaseW n u) = (ep : ℤ) ↔ u ∈ st.rightIndexSet))

theorem EncLocalMatching.mono_slice {tblW : ℕ} {cfgBaseW : ℤ} {n : ℕ}
    {st : LocalMatchingState ℕ} {m₀ m₁ : ArithRAMMemory}
    (henc : EncLocalMatching tblW cfgBaseW n st m₀)
    (hkW : ∀ i : ℤ, cfgBaseW ≤ i → i < cfgBaseW + cfgHdrWStride n →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i) :
    EncLocalMatching tblW cfgBaseW n st m₁ := by
  rcases henc with ⟨ep, hep1, hep_r, hndL, hndR, hpairs_lt, hUL_lt, hUR_lt,
    hdll, hmL_le, hmL_to, hmL_of, hmR_le, hmR_to, hmR_of, hiL, hiR⟩
  have hge3 := cfgHdrWStride_ge_three n
  have hL_lt : ∀ k ∈ (st.matchingList.map MatchingEdge.pair).map Prod.fst, k < n := by
    intro k hk
    rcases List.mem_map.mp hk with ⟨xy, hxy, rfl⟩
    exact (hpairs_lt xy hxy).1
  refine ⟨ep, hep1,
    (hkW _ (by unfold cfgEpOff; omega) (by unfold cfgEpOff; omega)).trans hep_r,
    hndL, hndR, hpairs_lt, hUL_lt, hUR_lt,
    hdll.congr
      (hkW _ (by unfold cfgHeadOff; omega) (by unfold cfgHeadOff; omega))
      (hkW _ (by unfold cfgTailOff; omega) (by unfold cfgTailOff; omega))
      (fun k hk => by
        have hk_lt := hL_lt k hk
        exact hkW _ (by unfold cfgPrevOff; omega) (by unfold cfgPrevOff cfgHdrWStride; omega))
      (fun k hk => by
        have hk_lt := hL_lt k hk
        exact hkW _ (by unfold cfgNextOff; omega) (by unfold cfgNextOff cfgHdrWStride; omega)),
    fun u hu => by
      rw [hkW _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff cfgHdrWStride; omega)]
      exact hmL_le u hu,
    fun u hu h => by
      rw [hkW _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff cfgHdrWStride; omega)] at h
      rw [hkW _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff cfgHdrWStride; omega)]
      exact hmL_to u hu h,
    fun x y hxy => by
      have hx_lt := (hpairs_lt (x, y) hxy).1
      rw [hkW _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff cfgHdrWStride; omega),
          hkW _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff cfgHdrWStride; omega)]
      exact hmL_of x y hxy,
    fun u hu => by
      rw [hkW _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff cfgHdrWStride; omega)]
      exact hmR_le u hu,
    fun u hu h => by
      rw [hkW _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff cfgHdrWStride; omega)] at h
      rw [hkW _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff cfgHdrWStride; omega)]
      exact hmR_to u hu h,
    fun x y hxy => by
      have hy_lt := (hpairs_lt (x, y) hxy).2
      rw [hkW _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff cfgHdrWStride; omega),
          hkW _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff cfgHdrWStride; omega)]
      exact hmR_of x y hxy,
    fun u hu => by
      rw [hkW _ (by unfold cfgInIdxLEpOff; omega) (by unfold cfgInIdxLEpOff cfgHdrWStride; omega)]
      exact hiL u hu,
    fun u hu => by
      rw [hkW _ (by unfold cfgInIdxREpOff; omega) (by unfold cfgInIdxREpOff cfgHdrWStride; omega)]
      exact hiR u hu⟩

/-- Full RAM encoding of `ConfigDynamicState` combining `EncLocalMatching` and two `EncSide`s. -/
def EncCfgDyn {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (cfgBaseW cfgBaseR : ℤ)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) (m : ArithRAMMemory) : Prop :=
  EncLocalMatching tblW cfgBaseW n cs.st m ∧
  sops.EncSide (cfgLeftSideWOff cfgBaseW n) (cfgLeftSideROff cfgBaseR)
    cs.st.leftIndexSet cs.leftIdx m ∧
  sops.EncSide (cfgRightSideWOff cfgBaseW sops.sideWStride n)
    (cfgRightSideROff cfgBaseR sops.sideRStride)
    cs.st.rightIndexSet cs.rightIdx m

theorem EncCfgDyn.mono_slice {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    {cfgBaseW cfgBaseR : ℤ} {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    {m₀ m₁ : ArithRAMMemory}
    (henc : EncCfgDyn sops cfgBaseW cfgBaseR cs m₀)
    (hkW : ∀ i : ℤ, cfgBaseW ≤ i → i < cfgBaseW + cfgTotalWStride n sops.sideWStride →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i)
    (hkR : ∀ i : ℤ, cfgBaseR ≤ i → i < cfgBaseR + cfgTotalRStride sops.sideRStride →
      H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i) :
    EncCfgDyn sops cfgBaseW cfgBaseR cs m₁ := by
  have hw2 := sops.hsideW_ge_two
  have hr0 := sops.hsideR_nonneg
  have hhdr3 := cfgHdrWStride_ge_three n
  rcases henc with ⟨hm, hL, hR⟩
  have hUL_lt : ∀ u ∈ cs.st.leftIndexSet, u < n := by
    rcases hm with ⟨_, _, _, _, _, _, hUL, _⟩; exact hUL
  have hUR_lt : ∀ u ∈ cs.st.rightIndexSet, u < n := by
    rcases hm with ⟨_, _, _, _, _, _, _, hUR, _⟩; exact hUR
  refine ⟨hm.mono_slice (fun i hlo hhi => hkW i hlo (by unfold cfgTotalWStride; omega)),
    sops.encSide_mono_slice hUL_lt hL
      (fun i hlo hhi => hkW i (by unfold cfgLeftSideWOff at hlo; omega)
        (by unfold cfgLeftSideWOff at hhi; unfold cfgTotalWStride; omega))
      (fun i hlo hhi => hkR i (by unfold cfgLeftSideROff at hlo; omega)
        (by unfold cfgLeftSideROff at hhi; unfold cfgTotalRStride; omega)),
    sops.encSide_mono_slice hUR_lt hR
      (fun i hlo hhi => hkW i (by unfold cfgRightSideWOff at hlo; omega)
        (by unfold cfgRightSideWOff at hhi; unfold cfgTotalWStride; omega))
      (fun i hlo hhi => hkR i (by unfold cfgRightSideROff at hlo; omega)
        (by unfold cfgRightSideROff at hhi; unfold cfgTotalRStride; omega))⟩

/-- Slot readiness predicate supporting both all-zero word initialization (`ep = 0`) and
subsequent `O(log n)` epoch clears (`ep ≥ 1`). -/
def CfgSlotReady {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (cfgBaseW cfgBaseR : ℤ) (m : ArithRAMMemory) : Prop :=
  (H3a.wRead m tblW cfgBaseW = 0 ∧
    ∀ j : ℤ, 0 ≤ j → j < cfgTotalWStride n sops.sideWStride →
      H3a.wRead m tblW (cfgBaseW + j) = 0) ∨
  (1 ≤ H3a.wRead m tblW cfgBaseW ∧
    ∃ cs : ConfigDynamicState L_p2 R ℓ M₀ d b, EncCfgDyn sops cfgBaseW cfgBaseR cs m)

theorem cfgSlotReady_of_zero {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (cfgBaseW cfgBaseR : ℤ) (m : ArithRAMMemory)
    (hz : ∀ j : ℤ, 0 ≤ j → j < cfgTotalWStride n sops.sideWStride →
      H3a.wRead m tblW (cfgBaseW + j) = 0) :
    CfgSlotReady sops cfgBaseW cfgBaseR m := by
  have hw2 := sops.hsideW_ge_two
  have hhdr3 := cfgHdrWStride_ge_three n
  left
  refine ⟨?_, hz⟩
  simpa using hz 0 le_rfl (by unfold cfgTotalWStride; omega)

theorem cfgSlotReady_of_enc {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (cfgBaseW cfgBaseR : ℤ) (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) (m : ArithRAMMemory)
    (henc : EncCfgDyn sops cfgBaseW cfgBaseR cs m) :
    CfgSlotReady sops cfgBaseW cfgBaseR m := by
  right
  rcases henc.1 with ⟨ep, hep1, hep_r, _⟩
  exact ⟨by unfold cfgEpOff at hep_r; omega, ⟨cs, henc⟩⟩

theorem cfgSlotReady_mono_slice {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (cfgBaseW cfgBaseR : ℤ) (m₀ m₁ : ArithRAMMemory)
    (hrdy : CfgSlotReady sops cfgBaseW cfgBaseR m₀)
    (hkW : ∀ i : ℤ, cfgBaseW ≤ i → i < cfgBaseW + cfgTotalWStride n sops.sideWStride →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i)
    (hkR : ∀ i : ℤ, cfgBaseR ≤ i → i < cfgBaseR + cfgTotalRStride sops.sideRStride →
      H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i) :
    CfgSlotReady sops cfgBaseW cfgBaseR m₁ := by
  have hw2 := sops.hsideW_ge_two
  have hhdr3 := cfgHdrWStride_ge_three n
  rcases hrdy with ⟨hz0, hz⟩ | ⟨hep, cs, henc⟩
  · left
    refine ⟨(hkW cfgBaseW le_rfl (by unfold cfgTotalWStride; omega)).trans hz0, fun j hj0 hlt => ?_⟩
    exact (hkW (cfgBaseW + j) (by omega) (by omega)).trans (hz j hj0 hlt)
  · right
    refine ⟨?_, cs, henc.mono_slice sops hkW hkR⟩
    rw [hkW cfgBaseW le_rfl (by unfold cfgTotalWStride; omega)]
    exact hep

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
