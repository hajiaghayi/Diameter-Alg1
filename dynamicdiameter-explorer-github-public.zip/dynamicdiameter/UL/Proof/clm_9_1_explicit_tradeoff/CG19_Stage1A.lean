import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Layout
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 1. Pure Stage-1 Helpers, `liveUpdateChainList` Lemmas, & Slot Disjointness -/

theorem ops_hBW_n {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    cp.n + 8 ≤ ops.BW := by
  have h1 : cp.n + 8 ≤ S_stride cp := by unfold S_stride; omega
  have h2 : S_stride cp ≤ (2 + 4 * cp.D_max) * S_stride cp :=
    Nat.le_mul_of_pos_left _ (by omega)
  exact h1.trans (h2.trans (Nat.le_of_add_right_le ops.hBW_arr))

theorem ops_hBW_scr64 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    64 ≤ ops.BW := by
  have := ops.hBW_scr; omega

theorem managedNodeWF_pts_congr {L_p2 R ℓ M₀ d b N_cfg : ℕ} {hM₀ : 1 ≤ M₀}
    {T p_coord : ℕ} {params : LocalScaleParams}
    {h : ℝ} {specs : Fin N_cfg → ConfigStaticSpec d params h}
    {τ_d : ℚ} {cap_u : ℕ}
    {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg}
    (heq : ∀ x ∈ mn.nd.curSet, pts' x = pts x)
    (hwf : ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts mn) :
    ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts' mn := by
  refine ⟨⟨hwf.1.1, hwf.1.2.1, fun hV i => configDynamic_pts_congr heq (hwf.1.2.2 hV i)⟩,
    hwf.2.1, hwf.2.2.1.trans ?_, hwf.2.2.2⟩
  ext x
  unfold nodeResidual nodeCore
  simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter]
  constructor <;> (rintro ⟨hx, hnc⟩; refine ⟨hx, ?_⟩; rintro ⟨_, hcb⟩; apply hnc ⟨hx, ?_⟩)
  · rwa [← heq x hx]
  · rwa [heq x hx]

theorem mem_foldResiduals_of_passesNodes {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {x : ℕ} :
    ∀ (S₀ : Finset ℕ) (ls : List (MNode cp)),
      passesNodes pts x ls = true →
      x ∈ S₀ →
      x ∈ foldResiduals pts S₀ ls
  | S₀, [], _, hx => hx
  | S₀, mn :: rest, hpass, hx => by
      dsimp only [passesNodes] at hpass
      rcases Bool.and_eq_true_iff.mp hpass with ⟨hncb_b, hrest⟩
      have hcb_f : inCoreBall mn.nd.o mn.nd.V (pts x) = false := by
        cases h : inCoreBall mn.nd.o mn.nd.V (pts x) <;> simp_all
      have hnot_cb : pts x ∉ coreBall mn.nd.o mn.nd.V :=
        (inCoreBall_eq_false_iff mn.nd.o (le_max_left 0 _) (pts x)).mp hcb_f
      have hx_res : x ∈ nodeResidual pts mn.nd.o mn.nd.V S₀ := by
        unfold nodeResidual nodeCore
        simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter]
        exact ⟨hx, fun hh => hnot_cb hh.2⟩
      exact mem_foldResiduals_of_passesNodes _ rest hrest hx_res

theorem passesNodes_snoc {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    (pts' : ℕ → EuclideanSpace ℝ (Fin d)) (h_op : ℕ) :
    ∀ (xs : List (MNode cp)) (mn : MNode cp),
      passesNodes pts' h_op (xs ++ [mn]) =
        (passesNodes pts' h_op xs && !inCoreBall mn.nd.o mn.nd.V (pts' h_op))
  | [], mn => by simp [passesNodes]
  | hd :: tl, mn => by
      dsimp only [List.cons_append, passesNodes]
      rw [passesNodes_snoc pts' h_op tl mn, Bool.and_assoc]

theorem liveUpdateChainList_shift_gen {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ) (f : ℕ → OpSeed cp) (a : ℕ) :
    ∀ (b : ℕ) (xs : List (MNode cp)),
      liveUpdateChainList cp pts' isIns h_op (fun q => f (a + q)) b xs =
        liveUpdateChainList cp pts' isIns h_op f (a + b) xs
  | _, [] => rfl
  | b, mn :: rest => by
      dsimp only [liveUpdateChainList]
      by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = true
      · simp only [hcb, ↓reduceIte]
      · have hcb_f : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = false :=
          Bool.eq_false_iff.mpr hcb
        simp only [hcb_f, Bool.false_eq_true, ↓reduceIte]
        rw [liveUpdateChainList_shift_gen cp pts' isIns h_op f a (b + 1) rest,
            show a + (b + 1) = (a + b) + 1 by omega]

theorem liveUpdateChainList_length {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ) (seeds : ℕ → OpSeed cp) :
    ∀ (idx : ℕ) (xs : List (MNode cp)),
      (liveUpdateChainList cp pts' isIns h_op seeds idx xs).1.length = xs.length
  | _, [] => rfl
  | idx, mn :: rest => by
      dsimp only [liveUpdateChainList]
      by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = true
      · simp [hcb]
      · have hcb_f : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = false :=
          Bool.eq_false_iff.mpr hcb
        simp [hcb_f, liveUpdateChainList_length cp pts' isIns h_op seeds (idx + 1) rest]

noncomputable def liveStepSingleNode {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ) (ω : OpSeed cp) (mn : MNode cp) : MNode cp :=
  let M_lat := M_lat_of d params.e
  if isIns then
    (mn.insertMat cp.hM₀ cp.T_cdf cp.p_coord M_lat params cp.specs
      cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op ω).bumpAge
  else
    (mn.deleteMat cp.hM₀ cp.T_cdf cp.p_coord M_lat params cp.specs
      cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op ω).bumpAge

theorem liveStepSingleNode_o_V {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ) (ω : OpSeed cp) (mn : MNode cp) :
    (liveStepSingleNode cp pts' isIns h_op ω mn).nd.o = mn.nd.o ∧
    (liveStepSingleNode cp pts' isIns h_op ω mn).nd.V = mn.nd.V := by
  unfold liveStepSingleNode ManagedNode.bumpAge ManagedNode.insertMat ManagedNode.deleteMat
    NodeInst.insertMat NodeInst.deleteMat NodeInst.V
  split_ifs <;> exact ⟨rfl, rfl⟩

theorem liveUpdateChainList_getElem_o_V {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ) (seeds : ℕ → OpSeed cp) :
    ∀ (idx : ℕ) (xs : List (MNode cp)) (q : ℕ)
      (hq1 : q < (liveUpdateChainList cp pts' isIns h_op seeds idx xs).1.length)
      (hq0 : q < xs.length),
      ((liveUpdateChainList cp pts' isIns h_op seeds idx xs).1[q]'hq1).nd.o = (xs[q]'hq0).nd.o ∧
      ((liveUpdateChainList cp pts' isIns h_op seeds idx xs).1[q]'hq1).nd.V = (xs[q]'hq0).nd.V
  | _, [], _, _, hq0 => absurd hq0 (Nat.not_lt_zero _)
  | idx, mn :: rest, 0, hq1, _ => by
      have hov := liveStepSingleNode_o_V cp pts' isIns h_op (seeds idx) mn
      dsimp only [liveUpdateChainList] at hq1 ⊢
      by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = true
      · simp only [hcb, ↓reduceIte, List.getElem_cons_zero]
        exact hov
      · have hcb_f : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = false :=
          Bool.eq_false_iff.mpr hcb
        simp only [hcb_f, Bool.false_eq_true, ↓reduceIte, List.getElem_cons_zero]
        exact hov
  | idx, mn :: rest, q + 1, hq1, hq0 => by
      dsimp only [liveUpdateChainList] at hq1 ⊢
      by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = true
      · simp [hcb]
      · have hcb_f : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = false :=
          Bool.eq_false_iff.mpr hcb
        simp only [hcb_f, Bool.false_eq_true, ↓reduceIte] at hq1 ⊢
        exact liveUpdateChainList_getElem_o_V cp pts' isIns h_op seeds (idx + 1) rest q
          (Nat.lt_of_succ_lt_succ hq1) (Nat.lt_of_succ_lt_succ hq0)

theorem liveUpdateChainList_snoc {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ) (seeds : ℕ → OpSeed cp) :
    ∀ (idx : ℕ) (xs : List (MNode cp)) (mn : MNode cp),
      let r := liveUpdateChainList cp pts' isIns h_op seeds idx xs
      liveUpdateChainList cp pts' isIns h_op seeds idx (xs ++ [mn]) =
        if r.2 then
          (r.1 ++ [liveStepSingleNode cp pts' isIns h_op (seeds (idx + xs.length)) mn],
           !inCoreBall mn.nd.o mn.nd.V (pts' h_op))
        else
          (r.1 ++ [mn], false)
  | idx, [], mn => by
      dsimp only [liveUpdateChainList, List.nil_append, List.length_nil, Nat.add_zero,
        liveStepSingleNode]
      cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_op) <;> simp
  | idx, hd :: tl, mn => by
      dsimp only [liveUpdateChainList, List.cons_append, List.length_cons]
      by_cases hcb : inCoreBall hd.nd.o hd.nd.V (pts' h_op) = true
      · simp [hcb]
      · have hcb_f : inCoreBall hd.nd.o hd.nd.V (pts' h_op) = false :=
          Bool.eq_false_iff.mpr hcb
        simp only [hcb_f, Bool.false_eq_true, ↓reduceIte]
        have ih := liveUpdateChainList_snoc cp pts' isIns h_op seeds (idx + 1) tl mn
        dsimp only at ih
        rw [ih, show idx + 1 + tl.length = idx + (tl.length + 1) by omega]
        cases (liveUpdateChainList cp pts' isIns h_op seeds (idx + 1) tl).2 <;> simp

theorem nodup_flatMap_disjoint {α β : Type*} {l : List α} {f : α → List β}
    (hl : l.Nodup) (hnd : (l.flatMap f).Nodup) :
    (∀ a ∈ l, (f a).Nodup) ∧
    (∀ a₁ ∈ l, ∀ a₂ ∈ l, a₁ ≠ a₂ → ∀ x ∈ f a₁, x ∉ f a₂) := by
  induction l with
  | nil => exact ⟨fun _ h => absurd h List.not_mem_nil, fun _ h => absurd h List.not_mem_nil⟩
  | cons hd tl ih =>
      rw [List.nodup_cons] at hl
      rw [List.flatMap_cons, List.nodup_append] at hnd
      rcases ih hl.2 hnd.2.1 with ⟨ih_nd, ih_disj⟩
      refine ⟨fun a ha => ?_, fun a₁ ha₁ a₂ ha₂ hne x hx₁ hx₂ => ?_⟩
      · rcases List.mem_cons.mp ha with rfl | hatl
        · exact hnd.1
        · exact ih_nd a hatl
      · rcases List.mem_cons.mp ha₁ with rfl | h1tl
        · rcases List.mem_cons.mp ha₂ with rfl | h2tl
          · exact hne rfl
          · exact hnd.2.2 x hx₁ x (List.mem_flatMap.mpr ⟨a₂, h2tl, hx₂⟩) rfl
        · rcases List.mem_cons.mp ha₂ with rfl | h2tl
          · exact hnd.2.2 x hx₂ x (List.mem_flatMap.mpr ⟨a₁, h1tl, hx₁⟩) rfl
          · exact ih_disj a₁ h1tl a₂ h2tl hne x hx₁ hx₂

/-! ### 2. Step 1a: `applyHandleUpdateStmt` + Shadow Cached-Answer Restore + Op-Register Setup -/

private theorem handlePool_step_detail {d n : ℕ} {P : DynamicPointSet d} {hp : HandlePool d n}
    {op : DynamicUpdate d} (hP : P.WellFormed n) (hhp : hp.WellFormed P)
    (hleg : IsLegalUpdate n Set.univ P op) :
    let (hp', rh) := hp.step (toInternalUpdate P op)
    ∃ P' : DynamicPointSet d,
      applyDynamicUpdate P op rh = some P' ∧
      hp'.WellFormed P' ∧
      ((∃ h_new pt,
          toInternalUpdate P op = .insert pt ∧
          rh = some h_new ∧
          h_new ∉ P.activeHandles ∧
          P'.activeHandles = insert h_new P.activeHandles ∧
          hp'.coords h_new = pt ∧
          (∀ x ∈ P.activeHandles, hp'.coords x = hp.coords x)) ∨
       (∃ delH,
          toInternalUpdate P op = .delete delH ∧
          rh = none ∧
          delH ∈ P.activeHandles ∧
          P'.activeHandles = P.activeHandles.erase delH ∧
          hp'.coords = hp.coords)) := by
  rcases HandlePool.step_wellFormed hP hhp hleg with ⟨P', happ, hhp'⟩
  refine ⟨P', happ, hhp', ?_⟩
  cases op with
  | insert pid extName pt =>
      apply Or.inl
      dsimp only [toInternalUpdate, HandlePool.step] at happ ⊢
      cases hfl : hp.freeList with
      | cons h₀ rest =>
          rw [hfl] at happ
          dsimp only at happ
          unfold applyDynamicUpdate at happ
          dsimp only at happ
          split_ifs at happ with hcond
          injection happ with hP'_eq
          subst hP'_eq
          refine ⟨h₀, pt, rfl, rfl, hcond.2, rfl, by simp, fun x hx => ?_⟩
          have hne : x ≠ h₀ := by intro heq; subst heq; exact hcond.2 hx
          exact Function.update_of_ne hne pt hp.coords
      | nil =>
          rw [hfl] at happ
          dsimp only at happ
          unfold applyDynamicUpdate at happ
          dsimp only at happ
          split_ifs at happ with hcond
          injection happ with hP'_eq
          subst hP'_eq
          refine ⟨hp.nextFresh, pt, rfl, rfl, hcond.2, rfl, by simp, fun x hx => ?_⟩
          have hne : x ≠ hp.nextFresh := by intro heq; subst heq; exact hcond.2 hx
          exact Function.update_of_ne hne pt hp.coords
  | delete pid =>
      apply Or.inr
      dsimp only [toInternalUpdate, HandlePool.step] at happ ⊢
      unfold applyDynamicUpdate at happ
      dsimp only at happ
      split_ifs at happ with hid_in
      injection happ with hP'_eq
      subst hP'_eq
      exact ⟨P.handleOfId pid, rfl, rfl, (hP.2.1 pid hid_in).1, rfl, rfl⟩

def restoreCachedAnsStmt : ArithRAMStmt :=
  .seq (.writeWordHeap 0 (.lit 1) (.readHeap engMetaTbl (.lit 3)))
  (.seq (.writeWordHeap 0 (.lit 2) (.readHeap engMetaTbl (.lit 4)))
  (.seq (.writeWordHeap 0 (.lit 3) (.readHeap engMetaTbl (.lit 5)))
        (.writeRealHeap 0 (.lit 0) (.readRealHeap engRealTbl (.lit 0)))))

def stepHandleAndSetupStmt (d : ℕ) : ArithRAMStmt :=
  .seq (applyHandleUpdateStmt d)
  (.seq restoreCachedAnsStmt
  (.seq (.writeWordHeap engScrTbl (.lit 1) (.intParam (.lit 1)))
        (.ite (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))
          (.writeWordHeap engScrTbl (.lit 2) (.readHeap 0 (.lit 0)))
          (.writeWordHeap engScrTbl (.lit 2) (.intParam (.lit 2))))))

theorem zeroRand_stepHandleAndSetupStmt (d : ℕ) :
    ZeroRandStmt (stepHandleAndSetupStmt d) :=
  .seq (zeroRand_applyHandleUpdateStmt d)
  (.seq (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.writeRealHeap _ _ _))))
  (.seq (.writeWordHeap _ _ _)
    (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))

theorem exec_stepHandleAndSetupStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {st : ChainEngineState cp} {m₀ : ArithRAMMemory}
    (hP : P.WellFormed cp.n)
    (hleg : IsLegalUpdate cp.n Set.univ P op)
    (hhp_wf : st.hp.WellFormed P)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hhp₀ : EncHandlePool st.hp m₀)
    (hans₀ : EncCachedAns st.cachedAns m₀) :
    let uop := toInternalUpdate P op
    let inp := CG20_Bridge.mkUpdateInp cp.n P uop
    let (hp', rh) := st.hp.step uop
    let isIns : Bool := match uop with | .insert _ => true | .delete _ => false
    let h_op : ℕ := match uop with | .insert _ => rh.getD 0 | .delete delH => delH
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (stepHandleAndSetupStmt d) m₀
      (fun m₁ =>
        ∃ P' : DynamicPointSet d,
          applyDynamicUpdate P op rh = some P' ∧
          hp'.WellFormed P' ∧
          ops.SlotsReady m₁ ∧
          EncHandlePool hp' m₁ ∧
          EncCachedAns st.cachedAns m₁ ∧
          wRead m₁ engScrTbl 1 = (if isIns then 1 else 0) ∧
          wRead m₁ engScrTbl 2 = (h_op : ℤ) ∧
          h_op < cp.n ∧
          (isIns = true → h_op ∉ P.activeHandles ∧ ∀ x ∈ P.activeHandles, hp'.coords x = st.hp.coords x) ∧
          (isIns = false → h_op ∈ P.activeHandles ∧ hp'.coords = st.hp.coords) ∧
          (∀ x ∈ insert h_op P.activeHandles,
            x < cp.n ∧ ∀ c : Fin d,
              rRead m₁ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (hp'.coords x) c) ∧
          (∀ h_new, rh = some h_new → ArithRAMDynamicProgram.readReturnedHandle m₁ = some h_new) ∧
          (∀ mn s, mn.nd.curSet ⊆ P.activeHandles → ops.EncNode mn s m₀ → ops.EncNode mn s m₁) ∧
          (∀ t ≥ 5, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
          (∀ t ≥ 2, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (280 + 25 * d) := by
  have hTW := ops.hTW
  have hBW_n := ops_hBW_n ops
  have hBW_s := ops_hBW_scr64 ops
  have hTR := ops.hTR
  have hBR := ops.hBR_pts
  rcases handlePool_step_detail hP hhp_wf hleg with ⟨P', happ, hhp'_wf, hdic⟩
  unfold stepHandleAndSetupStmt
  refine ExecDet.seq' 80
    (exec_applyHandleUpdateStmt (by omega) hBW_n (by omega) hBR hP hhp_wf hleg hfp₀ hhp₀)
    (by omega) ?_
  intro mA ⟨hhpA, hretA, hwA, hrA⟩ hfpA
  let uop := toInternalUpdate P op
  let inp := CG20_Bridge.mkUpdateInp cp.n P uop
  have hrestore : ExecDet ops.TW ops.BW ops.TR ops.BR inp restoreCachedAnsStmt mA
      (fun m => m = H3a.rWrite
        (H3a.wWrite (H3a.wWrite (H3a.wWrite mA 0 1 (wRead mA engMetaTbl 3))
          0 2 (wRead mA engMetaTbl 4)) 0 3 (wRead mA engMetaTbl 5))
        0 0 (rRead mA engRealTbl 0)) 50 := by
    unfold restoreCachedAnsStmt
    refine ExecDet.seq' 38
      (ExecDet.wWrite (C := 12) inp 0 (.lit 1) (.readHeap engMetaTbl (.lit 3)) 1
        (wRead mA engMetaTbl 3) hfpA (by omega) (by omega) (by omega) rfl (by simp [evalIntExpr]; rfl)
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro mB₁ hmB₁ hfpB₁; subst hmB₁
    refine ExecDet.seq' 26
      (ExecDet.wWrite (C := 12) inp 0 (.lit 2) (.readHeap engMetaTbl (.lit 4)) 2
        (wRead mA engMetaTbl 4) hfpB₁ (by omega) (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; exact wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro mB₂ hmB₂ hfpB₂; subst hmB₂
    refine ExecDet.seq' 14
      (ExecDet.wWrite (C := 12) inp 0 (.lit 3) (.readHeap engMetaTbl (.lit 5)) 3
        (wRead mA engMetaTbl 5) hfpB₂ (by omega) (by omega) (by omega) rfl
        (by simp only [evalIntExpr]
            change wRead _ engMetaTbl 5 = _
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inl (by decide))])
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro mB₃ hmB₃ hfpB₃; subst hmB₃
    exact ExecDet.rWrite (C := 14) inp 0 (.lit 0) (.readRealHeap engRealTbl (.lit 0)) 0
      (rRead mA engRealTbl 0) hfpB₃ (by omega) (by omega) (by omega) rfl
      (by simp [evalRealExpr, evalIntExpr, rRead, rRead_wWrite]; rfl)
      (by simp [intExprOps, realExprOps]) rfl
  refine ExecDet.seq' 30 hrestore (by omega) ?_
  intro mB hmB hfpB; subst hmB
  set mR := H3a.rWrite
    (H3a.wWrite (H3a.wWrite (H3a.wWrite mA 0 1 (wRead mA engMetaTbl 3))
      0 2 (wRead mA engMetaTbl 4)) 0 3 (wRead mA engMetaTbl 5))
    0 0 (rRead mA engRealTbl 0)
  have hwR_ne0 : ∀ t ≠ 0, ∀ i, wRead mR t i = wRead mA t i := by
    intro t ht i; simp only [mR, wRead_rWrite]
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
  have hwR_0 : ∀ i, i ≠ 1 → i ≠ 2 → i ≠ 3 → wRead mR 0 i = wRead mA 0 i := by
    intro i h1 h2 h3; simp only [mR, wRead_rWrite]
    rw [wRead_wWrite_of_ne _ _ (Or.inr h3),
        wRead_wWrite_of_ne _ _ (Or.inr h2),
        wRead_wWrite_of_ne _ _ (Or.inr h1)]
  have hrR_ne0 : ∀ t ≠ 0, ∀ i, rRead mR t i = rRead mA t i := by
    intro t ht i
    simp only [mR]
    rw [rRead_rWrite_of_ne _ _ (Or.inl ht)]
    simp [rRead_wWrite]
  have hansR : EncCachedAns st.cachedAns mR := by
    rcases hans₀ with ⟨_, hr_sh0, hmatch0⟩
    have hw6_3 : wRead mA engMetaTbl 3 = wRead m₀ engMetaTbl 3 := hwA engMetaTbl (by decide) 3
    have hw6_4 : wRead mA engMetaTbl 4 = wRead m₀ engMetaTbl 4 := hwA engMetaTbl (by decide) 4
    have hw6_5 : wRead mA engMetaTbl 5 = wRead m₀ engMetaTbl 5 := hwA engMetaTbl (by decide) 5
    have hr2_0 : rRead mA engRealTbl 0 = rRead m₀ engRealTbl 0 := hrA engRealTbl (by decide) 0
    have h01 : mR.words.read (.heap 0 1) = wRead m₀ engMetaTbl 3 := by
      change wRead mR 0 1 = _
      simp only [mR, wRead_rWrite]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
          wRead_wWrite_self, hw6_3]
    have h02 : mR.words.read (.heap 0 2) = wRead m₀ engMetaTbl 4 := by
      change wRead mR 0 2 = _
      simp only [mR, wRead_rWrite]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self, hw6_4]
    have h03 : mR.words.read (.heap 0 3) = wRead m₀ engMetaTbl 5 := by
      change wRead mR 0 3 = _
      simp only [mR, wRead_rWrite, wRead_wWrite_self, hw6_5]
    have hr00 : mR.reals.read (.heap 0 0) = st.cachedAns.cachedDistSq := by
      change rRead mR 0 0 = _
      simp only [mR, rRead_rWrite_self, hr2_0, hr_sh0]
    refine ⟨?_, (hrR_ne0 engRealTbl (by decide) 0).trans (hr2_0.trans hr_sh0), ?_⟩
    · unfold ArithRAMDynamicProgram.readCachedAnswer
      rw [h01, h02, h03, hr00]
      cases hd_ans : st.cachedAns.diameterHandles with
      | none =>
          simp only [hd_ans] at hmatch0
          rw [hmatch0.1]; simp
      | some uv =>
          rcases uv with ⟨u, v⟩
          simp only [hd_ans] at hmatch0
          rw [hmatch0.1, hmatch0.2.1, hmatch0.2.2]
          simp [Int.natCast_nonneg]
    · cases hd_ans : st.cachedAns.diameterHandles with
      | none =>
          simp only [hd_ans] at hmatch0
          exact ⟨(hwR_ne0 engMetaTbl (by decide) 3).trans (hw6_3.trans hmatch0.1),
                 (hwR_ne0 engMetaTbl (by decide) 4).trans (hw6_4.trans hmatch0.2.1),
                 (hwR_ne0 engMetaTbl (by decide) 5).trans (hw6_5.trans hmatch0.2.2)⟩
      | some uv =>
          rcases uv with ⟨u, v⟩
          simp only [hd_ans] at hmatch0
          exact ⟨(hwR_ne0 engMetaTbl (by decide) 3).trans (hw6_3.trans hmatch0.1),
                 (hwR_ne0 engMetaTbl (by decide) 4).trans (hw6_4.trans hmatch0.2.1),
                 (hwR_ne0 engMetaTbl (by decide) 5).trans (hw6_5.trans hmatch0.2.2)⟩
  let isIns : Bool := match uop with | .insert _ => true | .delete _ => false
  let h_op : ℕ := match uop with | .insert _ => (st.hp.step uop).2.getD 0 | .delete delH => delH
  have hp1_val : (evalIntExpr inp.toWordView 0 mR.words (.intParam (.lit 1))).1 =
      (if isIns then 1 else 0) := by
    dsimp only [inp, isIns, uop]
    cases toInternalUpdate P op <;>
      rfl
  refine ExecDet.seq' 18
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 1) (.intParam (.lit 1)) 1
      (if isIns then 1 else 0) hfpB (by dsimp [engScrTbl]; omega) (by omega) (by omega)
      rfl hp1_val (by simp [intExprOps]) rfl) (by omega) ?_
  intro mC hmC hfpC; subst hmC
  set mC1 := H3a.wWrite mR engScrTbl 1 (if isIns then 1 else 0)
  have hcond_ins : (evalArithCond inp 0 mC1
      (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))).1 = isIns := by
    simp only [evalArithCond, evalIntExpr]
    change decide (wRead mC1 engScrTbl 1 = 1) = isIns
    simp only [mC1, wRead_wWrite_self]
    cases isIns <;> rfl
  have hfinish :
      let mF := H3a.wWrite mC1 engScrTbl 2 (h_op : ℤ)
      ∃ P' : DynamicPointSet d,
        applyDynamicUpdate P op (st.hp.step uop).2 = some P' ∧
        (st.hp.step uop).1.WellFormed P' ∧
        ops.SlotsReady mF ∧
        EncHandlePool (st.hp.step uop).1 mF ∧
        EncCachedAns st.cachedAns mF ∧
        wRead mF engScrTbl 1 = (if isIns then 1 else 0) ∧
        wRead mF engScrTbl 2 = (h_op : ℤ) ∧
        h_op < cp.n ∧
        (isIns = true → h_op ∉ P.activeHandles ∧
          ∀ x ∈ P.activeHandles, (st.hp.step uop).1.coords x = st.hp.coords x) ∧
        (isIns = false → h_op ∈ P.activeHandles ∧ (st.hp.step uop).1.coords = st.hp.coords) ∧
        (∀ x ∈ insert h_op P.activeHandles,
          x < cp.n ∧ ∀ c : Fin d,
            rRead mF ptsRTbl (((x * d + c.val : ℕ) : ℤ)) =
              euclideanCoord ((st.hp.step uop).1.coords x) c) ∧
        (∀ h_new, (st.hp.step uop).2 = some h_new →
          ArithRAMDynamicProgram.readReturnedHandle mF = some h_new) ∧
        (∀ mn s, mn.nd.curSet ⊆ P.activeHandles → ops.EncNode mn s m₀ → ops.EncNode mn s mF) ∧
        (∀ t ≥ 5, t ≠ engScrTbl → ∀ i, wRead mF t i = wRead m₀ t i) ∧
        (∀ t ≥ 2, ∀ i, rRead mF t i = rRead m₀ t i) := by
    intro mF
    have hwF_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead mF t i = wRead mR t i := by
      intro t ht i; simp only [mF, mC1]
      rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
    have hrF : ∀ t i, rRead mF t i = rRead mR t i := fun _ _ => by simp [mF, mC1, rRead_wWrite]
    have hwF_ge5 : ∀ t ≥ 5, t ≠ engScrTbl → ∀ i, wRead mF t i = wRead m₀ t i := by
      intro t ht5 ht8 i
      exact (hwF_ne8 t ht8 i).trans ((hwR_ne0 t (by omega) i).trans (hwA t ht5 i))
    have hrF_ge2 : ∀ t ≥ 2, ∀ i, rRead mF t i = rRead m₀ t i := by
      intro t ht2 i
      exact (hrF t i).trans ((hrR_ne0 t (by omega) i).trans (hrA t ht2 i))
    have hsrF : ops.SlotsReady mF :=
      ops.slotsReady_ext m₀ mF hsr₀
        (fun t ht9 _ i => hwF_ge5 t (by omega) (by dsimp [engScrTbl]; omega) i)
        (fun t ht3 _ i => hrF_ge2 t (by omega) i)
    have hhpF : EncHandlePool (st.hp.step uop).1 mF := by
      refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
      · exact (hwF_ne8 0 (by decide) 4).trans ((hwR_0 4 (by decide) (by decide) (by decide)).trans hhpA.1)
      · exact (hwF_ne8 0 (by decide) 5).trans ((hwR_0 5 (by decide) (by decide) (by decide)).trans hhpA.2.1)
      · exact (hwF_ne8 0 (by decide) 6).trans ((hwR_0 6 (by decide) (by decide) (by decide)).trans hhpA.2.2.1)
      · intro i hi
        exact (hwF_ne8 1 (by decide) _).trans ((hwR_ne0 1 (by decide) _).trans (hhpA.2.2.2.1 i hi))
      · intro i hi
        exact ⟨(hwF_ne8 2 (by decide) _).trans ((hwR_ne0 2 (by decide) _).trans (hhpA.2.2.2.2.1 i hi).1),
               (hwF_ne8 3 (by decide) _).trans ((hwR_ne0 3 (by decide) _).trans (hhpA.2.2.2.2.1 i hi).2)⟩
      · intro x hx c
        exact (hrF 1 _).trans ((hrR_ne0 1 (by decide) _).trans (hhpA.2.2.2.2.2 x hx c))
    have hansF : EncCachedAns st.cachedAns mF :=
      encCachedAns_ext hansR (hwF_ne8 0 (by decide)) (hwF_ne8 engMetaTbl (by decide)) (hrF 0 0) (hrF engRealTbl 0)
    have hwF_00 : mF.words.read (.heap 0 0) = mA.words.read (.heap 0 0) := by
      change wRead mF 0 0 = wRead mA 0 0
      exact (hwF_ne8 0 (by decide) 0).trans (hwR_0 0 (by decide) (by decide) (by decide))
    have hretF : ∀ h_new, (st.hp.step uop).2 = some h_new →
        ArithRAMDynamicProgram.readReturnedHandle mF = some h_new := by
      intro h_new hh
      unfold ArithRAMDynamicProgram.readReturnedHandle
      rw [hwF_00]
      exact hretA h_new hh
    have hact0_lt : ∀ x ∈ P.activeHandles, x < st.hp.nextFresh ∧ st.hp.nextFresh ≤ cp.n := by
      intro x hx
      have hmem : x ∈ st.hp.actList := List.mem_toFinset.mp (hhp_wf.2.2.2.1.symm ▸ hx)
      exact ⟨hhp_wf.2.2.2.2.1 x hmem, hhp_wf.1⟩
    have hact1_lt : ∀ x ∈ P'.activeHandles,
        x < (st.hp.step uop).1.nextFresh ∧ (st.hp.step uop).1.nextFresh ≤ cp.n := by
      intro x hx
      have hmem : x ∈ (st.hp.step uop).1.actList :=
        List.mem_toFinset.mp (hhp'_wf.2.2.2.1.symm ▸ hx)
      exact ⟨hhp'_wf.2.2.2.2.1 x hmem, hhp'_wf.1⟩
    have hprops :
        h_op < cp.n ∧
        (isIns = true → h_op ∉ P.activeHandles ∧
          ∀ x ∈ P.activeHandles, (st.hp.step uop).1.coords x = st.hp.coords x) ∧
        (isIns = false → h_op ∈ P.activeHandles ∧ (st.hp.step uop).1.coords = st.hp.coords) ∧
        (∀ x ∈ insert h_op P.activeHandles,
          x < cp.n ∧ ∀ c : Fin d,
            rRead mF ptsRTbl (((x * d + c.val : ℕ) : ℤ)) =
              euclideanCoord ((st.hp.step uop).1.coords x) c) := by
      rcases hdic with
        ⟨h_new, pt, huop_eq, hrh_eq, hnot_act, hact'_eq, _, hpts_old⟩ |
        ⟨delH, huop_eq, _, hdel_in, _, hpts_eq⟩
      · have his : isIns = true := by dsimp [isIns, uop]; rw [huop_eq]
        have hhop : h_op = h_new := by
          dsimp [h_op, uop]; rw [huop_eq]
          have : (st.hp.step (.insert pt)).2 = some h_new := huop_eq ▸ hrh_eq
          rw [this]; rfl
        have hins_sub : insert h_op P.activeHandles = P'.activeHandles := by
          rw [hhop, hact'_eq]
        have hhop_lt : h_op < cp.n := by
          have := hact1_lt h_op (hins_sub ▸ Finset.mem_insert_self _ _); omega
        refine ⟨hhop_lt, fun _ => ⟨hhop ▸ hnot_act, hpts_old⟩,
          fun hf => by simp [his] at hf, fun x hx => ?_⟩
        rcases hact1_lt x (hins_sub ▸ hx) with ⟨hx_nf, hnf_n⟩
        exact ⟨by omega, fun c => hhpF.2.2.2.2.2 x hx_nf c⟩
      · have his : isIns = false := by dsimp [isIns, uop]; rw [huop_eq]
        have hhop : h_op = delH := by dsimp [h_op, uop]; rw [huop_eq]
        have hnf_eq : (st.hp.step uop).1.nextFresh = st.hp.nextFresh := by
          dsimp [uop]; rw [huop_eq]; rfl
        have hhop_lt : h_op < cp.n := by
          have := hact0_lt h_op (hhop ▸ hdel_in); omega
        refine ⟨hhop_lt, fun ht => by simp [his] at ht,
          fun _ => ⟨hhop ▸ hdel_in, hpts_eq⟩, fun x hx => ?_⟩
        have hx_in0 : x ∈ P.activeHandles := by
          rcases Finset.mem_insert.mp hx with rfl | hxa
          · exact hhop ▸ hdel_in
          · exact hxa
        rcases hact0_lt x hx_in0 with ⟨hx_nf, hnf_n⟩
        have hx_nf1 : x < (st.hp.step uop).1.nextFresh := by omega
        exact ⟨by omega, fun c => hhpF.2.2.2.2.2 x hx_nf1 c⟩
    have hndF : ∀ mn s, mn.nd.curSet ⊆ P.activeHandles → ops.EncNode mn s m₀ → ops.EncNode mn s mF := by
      intro mn s hsub henc_mn
      refine ops.encNode_ext mn s m₀ mF henc_mn
        (fun t ht9 _ i => hwF_ge5 t (by omega) (by dsimp [engScrTbl]; omega) i)
        (fun t ht3 _ i => hrF_ge2 t (by omega) i)
        (fun x hx _ c => ?_)
      have hx_act : x ∈ P.activeHandles := hsub hx
      have hx_ins : x ∈ insert h_op P.activeHandles := Finset.mem_insert_of_mem hx_act
      have hr1 := (hprops.2.2.2 x hx_ins).2 c
      have hr0 := hhp₀.2.2.2.2.2 x (hact0_lt x hx_act).1 c
      have hcoord_eq : (st.hp.step uop).1.coords x = st.hp.coords x := by
        cases his : isIns
        · rw [(hprops.2.2.1 his).2]
        · exact (hprops.2.1 his).2 x hx_act
      exact hr1.trans (by rw [hcoord_eq]; exact hr0.symm)
    exact ⟨P', happ, hhp'_wf, hsrF, hhpF, hansF,
      by simp only [mF, mC1]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
      by simp only [mF, wRead_wWrite_self],
      hprops.1, hprops.2.1, hprops.2.2.1, hprops.2.2.2, hretF, hndF, hwF_ge5, hrF_ge2⟩
  refine ExecDet.ite' (C_c := 6) (C_b := 12) _ _ _ hcond_ins (by simp [condExprOps, intExprOps])
    (fun his_t => ?_) (fun his_f => ?_)
  · rcases hdic with ⟨h_new, pt, huop_eq, hrh_eq, _, _, _, _⟩ | ⟨delH, huop_eq, _, _, _, _⟩
    · have hret := hretA h_new hrh_eq
      unfold ArithRAMDynamicProgram.readReturnedHandle at hret
      dsimp only at hret
      have h00_A : mA.words.read (.heap 0 0) = (h_new : ℤ) := by
        split_ifs at hret with hnn
        injection hret with htn; omega
      have h00_C1 : wRead mC1 0 0 = (h_op : ℤ) := by
        have hhop : h_op = h_new := by
          dsimp [h_op, uop]; rw [huop_eq]
          have : (st.hp.step (.insert pt)).2 = some h_new := huop_eq ▸ hrh_eq
          rw [this]; rfl
        simp only [mC1, hhop]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            hwR_0 0 (by decide) (by decide) (by decide)]
        exact h00_A
      exact ExecDet.wWrite inp engScrTbl (.lit 2) (.readHeap 0 (.lit 0)) 2 (h_op : ℤ)
        hfpC (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; exact h00_C1) (by simp [intExprOps]) hfinish
    · exfalso; dsimp [isIns, uop] at his_t; rw [huop_eq] at his_t; cases his_t
  · rcases hdic with ⟨_, _, huop_eq, _, _, _, _, _⟩ | ⟨delH, huop_eq, _, _, _, _⟩
    · exfalso; dsimp [isIns, uop] at his_f; rw [huop_eq] at his_f; cases his_f
    · have hp2_val : (evalIntExpr inp.toWordView 0 mC1.words (.intParam (.lit 2))).1 = (h_op : ℤ) := by
        dsimp [inp, h_op, uop]; rw [huop_eq]
        simp [CG20_Bridge.mkUpdateInp, ArithRAMInput.toWordView, evalIntExpr, listGetIntD]
      exact ExecDet.wWrite inp engScrTbl (.lit 2) (.intParam (.lit 2)) 2 (h_op : ℤ)
        hfpC (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
        hp2_val (by simp [intExprOps]) hfinish

end UL.Proof.clm_9_1_explicit_tradeoff.CG19
