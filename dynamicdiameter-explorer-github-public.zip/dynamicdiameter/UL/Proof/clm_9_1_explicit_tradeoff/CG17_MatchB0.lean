import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB0b

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 4. `unlinkLeftKeyStmt`: `O(1)` DLL Unlink + Mate Zeroing -/

def unlinkLeftKeyCost : ℕ := 300

def unlinkLeftKeyStmt (scrW tblW n : ℕ)
    (wCfgBaseW wK wScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wCfgBaseW)
  let kE := IntExpr.readHeap scrW (.lit wK)
  let yE := IntExpr.readHeap scrW (.lit wScr)
  let pE := IntExpr.readHeap scrW (.lit (wScr + 1))
  let nxE := IntExpr.readHeap scrW (.lit (wScr + 2))
  .seq (.writeWordHeap scrW (.lit wScr) (.readHeap tblW (.add (.add bWE (.lit (3 + (n : ℤ)))) kE)))
  (.seq (.writeWordHeap scrW (.lit (wScr + 1)) (.readHeap tblW (.add (.add bWE (.lit (3 + 6 * (n : ℤ)))) kE)))
  (.seq (.writeWordHeap scrW (.lit (wScr + 2)) (.readHeap tblW (.add (.add bWE (.lit (3 + 7 * (n : ℤ)))) kE)))
  (.seq (.writeWordHeap tblW (.add (.add bWE (.lit 3)) kE) (.lit 0))
  (.seq (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 2 * (n : ℤ)))) yE) (.lit 0))
  (.seq (.ite (.intLt pE (.lit 0))
          (.writeWordHeap tblW (.add bWE (.lit 1)) nxE)
          (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 7 * (n : ℤ)))) pE) nxE))
        (.ite (.intLt nxE (.lit 0))
          (.writeWordHeap tblW (.add bWE (.lit 2)) pE)
          (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 6 * (n : ℤ)))) nxE) pE)))))))

theorem zeroRand_unlinkLeftKeyStmt (scrW tblW n : ℕ)
    (wCfgBaseW wK wScr : ℤ) :
    ZeroRandStmt (unlinkLeftKeyStmt scrW tblW n wCfgBaseW wK wScr) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
        (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))))

theorem exec_unlinkLeftKeyStmt {d n : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCfgBaseW wK wScr cfgBaseW cfgBaseR : ℤ)
    {k₀ y₀ : ℕ} {st st' : LocalMatchingState ℕ}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ cfgBaseW ∧ cfgBaseW + cfgHdrWStride n ≤ (BW : ℤ))
    (hwBW : 0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr)
    (hwK : 0 ≤ wK ∧ wK < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + 3 ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW)
    (hk_r : H3a.wRead m₀ scrW wK = (k₀ : ℤ))
    (hmem_pair : (k₀, y₀) ∈ st.matchingList.map MatchingEdge.pair)
    (hpairs' : st'.matchingList.map MatchingEdge.pair =
      (st.matchingList.map MatchingEdge.pair).filter (fun xy => decide (xy.1 ≠ k₀)))
    (hUL' : st'.leftIndexSet = st.leftIndexSet)
    (hUR' : st'.rightIndexSet = st.rightIndexSet)
    (henc : EncLocalMatching tblW cfgBaseW n st m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (unlinkLeftKeyStmt scrW tblW n wCfgBaseW wK wScr)
        m₀ m₁ unlinkLeftKeyCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLocalMatching tblW cfgBaseW n st' m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m₀ m₁ := by
  have hscrW : scrW < TW := hvt.1
  have htblW : tblW < TW := hvt.2.1
  have hneW : tblW ≠ scrW := hvt.2.2.2.2.2.2.1
  rcases henc with ⟨ep, hep1, hep_r, hndL, hndR, hpairs_lt, hUL_lt, hUR_lt,
    hdll, hmL_le, hmL_to, hmL_of, hmR_le, hmR_to, hmR_of, hiL, hiR⟩
  have hk_lt : k₀ < n := (hpairs_lt (k₀, y₀) hmem_pair).1
  have hy_lt : y₀ < n := (hpairs_lt (k₀, y₀) hmem_pair).2
  have hy_val : H3a.wRead m₀ tblW (cfgMateLValOff cfgBaseW n k₀) = (y₀ : ℤ) :=
    (hmL_of k₀ y₀ hmem_pair).2
  let L := (st.matchingList.map MatchingEdge.pair).map Prod.fst
  have hk_mem_L : k₀ ∈ L := List.mem_map_of_mem hmem_pair
  have hL_lt : ∀ k ∈ L, k < n := by
    intro k hk; rcases List.mem_map.mp hk with ⟨xy, hxy, rfl⟩; exact (hpairs_lt xy hxy).1
  have hnb := hdll.mem_neighbors hk_mem_L
  set pVal := H3a.wRead m₀ tblW (cfgPrevOff cfgBaseW n k₀)
  set nxVal := H3a.wRead m₀ tblW (cfgNextOff cfgBaseW n k₀)
  rcases hnb with ⟨_, hp_or, hnx_or⟩
  let m1 := H3a.wWrite m₀ scrW wScr (y₀ : ℤ)
  let m2 := H3a.wWrite m1 scrW (wScr + 1) pVal
  let m3 := H3a.wWrite m2 scrW (wScr + 2) nxVal
  let m4 := H3a.wWrite m3 tblW (cfgMateLEpOff cfgBaseW n k₀) 0
  let m5 := H3a.wWrite m4 tblW (cfgMateREpOff cfgBaseW n y₀) 0
  have hscr5 : ∀ w, w < wScr →
      H3a.wRead m1 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m5 scrW w = H3a.wRead m₀ scrW w := by
    intro w hw
    have s1 : H3a.wRead m1 scrW w = H3a.wRead m₀ scrW w := wRead_wWrite_of_ne _ _ (Or.inr (by omega))
    have s2 : H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans s1
    have s3 : H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans s2
    have s4 : H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans s3
    have s5 : H3a.wRead m5 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans s4
    exact ⟨s1, s2, s3, s4, s5⟩
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + (n : ℤ))))
                            (.readHeap scrW (.lit wK))))) m₀ m1 35 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wScr) _ rfl
      (by change H3a.wRead m₀ tblW ((H3a.wRead m₀ scrW wCfgBaseW + (3 + (n : ℤ))) + H3a.wRead m₀ scrW wK) = (y₀ : ℤ)
          rw [hbW, hk_r, show (cfgBaseW + (3 + (n : ℤ))) + (k₀ : ℤ) = cfgMateLValOff cfgBaseW n k₀ by unfold cfgMateLValOff; ring]
          exact hy_val)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
      (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 6 * (n : ℤ))))
                            (.readHeap scrW (.lit wK))))) m1 m2 35 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 1)) _ rfl
      (by change H3a.wRead m1 tblW ((H3a.wRead m1 scrW wCfgBaseW + (3 + 6 * (n : ℤ))) + H3a.wRead m1 scrW wK) = pVal
          rw [(hscr5 wCfgBaseW hwBW.2).1, (hscr5 wK hwK.2).1, hbW, hk_r,
              show (cfgBaseW + (3 + 6 * (n : ℤ))) + (k₀ : ℤ) = cfgPrevOff cfgBaseW n k₀ by unfold cfgPrevOff; ring,
              wRead_wWrite_of_ne _ _ (Or.inl hneW)])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2))
      (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 7 * (n : ℤ))))
                            (.readHeap scrW (.lit wK))))) m2 m3 35 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wScr + 2)) _ rfl
      (by change H3a.wRead m2 tblW ((H3a.wRead m2 scrW wCfgBaseW + (3 + 7 * (n : ℤ))) + H3a.wRead m2 scrW wK) = nxVal
          rw [(hscr5 wCfgBaseW hwBW.2).2.1, (hscr5 wK hwK.2).2.1, hbW, hk_r,
              show (cfgBaseW + (3 + 7 * (n : ℤ))) + (k₀ : ℤ) = cfgNextOff cfgBaseW n k₀ by unfold cfgNextOff; ring,
              wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd4 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 3)) (.readHeap scrW (.lit wK)))
      (.lit 0)) m3 m4 30 :=
    DetExecAt.writeWordHeap 0 inp m3 tblW _ (.lit 0)
      (by change (H3a.wRead m3 scrW wCfgBaseW + 3) + H3a.wRead m3 scrW wK = cfgMateLEpOff cfgBaseW n k₀
          rw [(hscr5 wCfgBaseW hwBW.2).2.2.1, (hscr5 wK hwK.2).2.2.1, hbW, hk_r]
          unfold cfgMateLEpOff; ring)
      rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd5 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 2 * (n : ℤ)))) (.readHeap scrW (.lit wScr)))
      (.lit 0)) m4 m5 30 :=
    DetExecAt.writeWordHeap 0 inp m4 tblW _ (.lit 0)
      (by change (H3a.wRead m4 scrW wCfgBaseW + (3 + 2 * (n : ℤ))) + H3a.wRead m4 scrW wScr = cfgMateREpOff cfgBaseW n y₀
          have hy4 : H3a.wRead m4 scrW wScr = (y₀ : ℤ) := by
            rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_self]
          rw [(hscr5 wCfgBaseW hwBW.2).2.2.2.1, hbW, hy4]
          unfold cfgMateREpOff; ring)
      rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp5 : InFootprint TW BW TR BR m5 := by
    unfold cfgHdrWStride at hbaseW
    exact InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite
      (InFootprint.wWrite hfp₀ hscrW hwScr.1 (by omega))
      hscrW (by omega) (by omega)) hscrW (by omega) (by omega))
      htblW (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega))
      htblW (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega)
  have hfr05 : RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m₀ m5 :=
    ((((rfo_wWrite_scr _ _ _ _ _ _ _ _ m₀ wScr (y₀ : ℤ)).trans
       (rfo_wWrite_scr _ _ _ _ _ _ _ _ m1 (wScr + 1) pVal)).trans
       (rfo_wWrite_scr _ _ _ _ _ _ _ _ m2 (wScr + 2) nxVal)).trans
       (rfo_wWrite_in _ _ _ _ _ _ _ _ m3 0 (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff cfgHdrWStride; omega))).trans
       (rfo_wWrite_in _ _ _ _ _ _ _ _ m4 0 (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff cfgHdrWStride; omega))
  have hp5 : H3a.wRead m5 scrW (wScr + 1) = pVal := by
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hnx5 : H3a.wRead m5 scrW (wScr + 2) = nxVal := by
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_self]
  -- Execute first `ite` (`pVal < 0`) producing `m6`
  have hstep6 : ∃ m6 : ArithRAMMemory,
      DetExec inp (.ite (.intLt (.readHeap scrW (.lit (wScr + 1))) (.lit 0))
        (.writeWordHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 1)) (.readHeap scrW (.lit (wScr + 2))))
        (.writeWordHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 7 * (n : ℤ))))
                                   (.readHeap scrW (.lit (wScr + 1)))) (.readHeap scrW (.lit (wScr + 2)))))
        m5 m6 55 ∧
      InFootprint TW BW TR BR m6 ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m5 m6 ∧
      (∀ w, H3a.wRead m6 scrW w = H3a.wRead m5 scrW w) ∧
      H3a.wRead m6 tblW (cfgEpOff cfgBaseW) = H3a.wRead m5 tblW (cfgEpOff cfgBaseW) ∧
      H3a.wRead m6 tblW (cfgTailOff cfgBaseW) = H3a.wRead m5 tblW (cfgTailOff cfgBaseW) ∧
      (∀ i : ℤ, cfgBaseW + 3 ≤ i → i < cfgBaseW + 3 + 7 * (n : ℤ) →
        H3a.wRead m6 tblW i = H3a.wRead m5 tblW i) ∧
      (if pVal < 0 then
         H3a.wRead m6 tblW (cfgHeadOff cfgBaseW) = nxVal ∧
         (∀ k ∈ L, k ≠ k₀ → H3a.wRead m6 tblW (cfgNextOff cfgBaseW n k) = H3a.wRead m₀ tblW (cfgNextOff cfgBaseW n k))
       else
         H3a.wRead m6 tblW (cfgHeadOff cfgBaseW) = H3a.wRead m₀ tblW (cfgHeadOff cfgBaseW) ∧
         (∀ a : ℕ, pVal = (a : ℤ) → H3a.wRead m6 tblW (cfgNextOff cfgBaseW n a) = nxVal) ∧
         (∀ k ∈ L, (k : ℤ) ≠ pVal → H3a.wRead m6 tblW (cfgNextOff cfgBaseW n k) = H3a.wRead m₀ tblW (cfgNextOff cfgBaseW n k))) := by
    have hm5_nxt : ∀ k < n, H3a.wRead m5 tblW (cfgNextOff cfgBaseW n k) = H3a.wRead m₀ tblW (cfgNextOff cfgBaseW n k) := by
      intro k hk
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgMateLEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    have hm5_hd : H3a.wRead m5 tblW (cfgHeadOff cfgBaseW) = H3a.wRead m₀ tblW (cfgHeadOff cfgBaseW) := by
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgMateLEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    rcases hp_or with hp_m1 | ⟨a, ha_L, hp_a⟩
    · have hc_t : cValAt 0 inp m5 (.intLt (.readHeap scrW (.lit (wScr + 1))) (.lit 0)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m5 scrW (wScr + 1) < 0) = true
        rw [hp5, hp_m1]; rfl
      let m6 := H3a.wWrite m5 tblW (cfgHeadOff cfgBaseW) nxVal
      have hd6 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 1))
          (.readHeap scrW (.lit (wScr + 2)))) m5 m6 30 :=
        DetExecAt.writeWordHeap 0 inp m5 tblW _ _
          (by change H3a.wRead m5 scrW wCfgBaseW + 1 = cfgHeadOff cfgBaseW
              rw [(hscr5 wCfgBaseW hwBW.2).2.2.2.2, hbW]; rfl)
          hnx5
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m6, (DetExecAt.ite_true (C_c := 15) hc_t
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd6).mono_cost (by omega),
        by unfold cfgHdrWStride at hbaseW
           exact InFootprint.wWrite hfp5 htblW (by unfold cfgHeadOff; omega) (by unfold cfgHeadOff; omega),
        rfo_wWrite_in _ _ _ _ _ _ _ _ m5 nxVal (by unfold cfgHeadOff; omega) (by unfold cfgHeadOff cfgHdrWStride; omega),
        fun w => wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgHeadOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgHeadOff; omega)),
        fun i hlo _ => wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff; omega)),
        ?_⟩
      rw [if_pos (by omega : pVal < 0)]
      refine ⟨wRead_wWrite_self _ _ _ _, fun k hk _ => ?_⟩
      have hk_lt' := hL_lt k hk
      exact (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgHeadOff; omega))).trans (hm5_nxt k hk_lt')
    · have ha_lt : a < n := hL_lt a ha_L
      have hc_f : cValAt 0 inp m5 (.intLt (.readHeap scrW (.lit (wScr + 1))) (.lit 0)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m5 scrW (wScr + 1) < 0) = false
        rw [hp5, hp_a]; exact decide_eq_false (by omega)
      let m6 := H3a.wWrite m5 tblW (cfgNextOff cfgBaseW n a) nxVal
      have hd6 : DetExec inp (.writeWordHeap tblW
          (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 7 * (n : ℤ))))
                (.readHeap scrW (.lit (wScr + 1))))
          (.readHeap scrW (.lit (wScr + 2)))) m5 m6 35 :=
        DetExecAt.writeWordHeap 0 inp m5 tblW _ _
          (by change (H3a.wRead m5 scrW wCfgBaseW + (3 + 7 * (n : ℤ))) + H3a.wRead m5 scrW (wScr + 1) =
                cfgNextOff cfgBaseW n a
              rw [(hscr5 wCfgBaseW hwBW.2).2.2.2.2, hbW, hp5, hp_a]
              unfold cfgNextOff; ring)
          hnx5
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m6, (DetExecAt.ite_false (C_c := 15) hc_f
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd6).mono_cost (by omega),
        by unfold cfgHdrWStride at hbaseW
           exact InFootprint.wWrite hfp5 htblW (by unfold cfgNextOff; omega) (by unfold cfgNextOff; omega),
        rfo_wWrite_in _ _ _ _ _ _ _ _ m5 nxVal (by unfold cfgNextOff; omega) (by unfold cfgNextOff cfgHdrWStride; omega),
        fun w => wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgNextOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgNextOff; omega)),
        fun i _ hhi => wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff; omega)),
        ?_⟩
      rw [if_neg (by rw [hp_a]; omega : ¬ pVal < 0)]
      refine ⟨(wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgNextOff; omega))).trans hm5_hd,
        fun a' ha' => by
          have heq : a' = a := Int.ofNat.inj (ha'.symm.trans hp_a)
          subst heq; exact wRead_wWrite_self _ _ _ _,
        fun k hk hne_p => by
          have hk_lt' := hL_lt k hk
          have hka : k ≠ a := fun heq => hne_p (heq ▸ hp_a.symm)
          exact (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff; omega))).trans (hm5_nxt k hk_lt')⟩
  obtain ⟨m6, hd6, hfp6, hfr56, hscr6, hep6, htl6, hlow6, hhd_prop6⟩ := hstep6
  -- Execute second `ite` (`nxVal < 0`) producing `m7`
  have hstep7 : ∃ m7 : ArithRAMMemory,
      DetExec inp (.ite (.intLt (.readHeap scrW (.lit (wScr + 2))) (.lit 0))
        (.writeWordHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 2)) (.readHeap scrW (.lit (wScr + 1))))
        (.writeWordHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 6 * (n : ℤ))))
                                   (.readHeap scrW (.lit (wScr + 2)))) (.readHeap scrW (.lit (wScr + 1)))))
        m6 m7 55 ∧
      InFootprint TW BW TR BR m7 ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m6 m7 ∧
      (∀ w, H3a.wRead m7 scrW w = H3a.wRead m6 scrW w) ∧
      H3a.wRead m7 tblW (cfgEpOff cfgBaseW) = H3a.wRead m6 tblW (cfgEpOff cfgBaseW) ∧
      H3a.wRead m7 tblW (cfgHeadOff cfgBaseW) = H3a.wRead m6 tblW (cfgHeadOff cfgBaseW) ∧
      (∀ i : ℤ, cfgBaseW + 3 ≤ i → i < cfgBaseW + 3 + 6 * (n : ℤ) →
        H3a.wRead m7 tblW i = H3a.wRead m6 tblW i) ∧
      (∀ k < n, H3a.wRead m7 tblW (cfgNextOff cfgBaseW n k) = H3a.wRead m6 tblW (cfgNextOff cfgBaseW n k)) ∧
      (if nxVal < 0 then
         H3a.wRead m7 tblW (cfgTailOff cfgBaseW) = pVal ∧
         (∀ k ∈ L, k ≠ k₀ → H3a.wRead m7 tblW (cfgPrevOff cfgBaseW n k) = H3a.wRead m₀ tblW (cfgPrevOff cfgBaseW n k))
       else
         H3a.wRead m7 tblW (cfgTailOff cfgBaseW) = H3a.wRead m₀ tblW (cfgTailOff cfgBaseW) ∧
         (∀ b : ℕ, nxVal = (b : ℤ) → H3a.wRead m7 tblW (cfgPrevOff cfgBaseW n b) = pVal) ∧
         (∀ k ∈ L, (k : ℤ) ≠ nxVal → H3a.wRead m7 tblW (cfgPrevOff cfgBaseW n k) = H3a.wRead m₀ tblW (cfgPrevOff cfgBaseW n k))) := by
    have hm6_prv : ∀ k < n, H3a.wRead m6 tblW (cfgPrevOff cfgBaseW n k) = H3a.wRead m₀ tblW (cfgPrevOff cfgBaseW n k) := by
      intro k hk
      rw [hlow6 _ (by unfold cfgPrevOff; omega) (by unfold cfgPrevOff; omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgMateLEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    have hm6_tl : H3a.wRead m6 tblW (cfgTailOff cfgBaseW) = H3a.wRead m₀ tblW (cfgTailOff cfgBaseW) := by
      rw [htl6, wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgMateLEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    rcases hnx_or with hnx_m1 | ⟨b, hb_L, hnx_b⟩
    · have hc_t : cValAt 0 inp m6 (.intLt (.readHeap scrW (.lit (wScr + 2))) (.lit 0)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m6 scrW (wScr + 2) < 0) = true
        rw [hscr6, hnx5, hnx_m1]; rfl
      let m7 := H3a.wWrite m6 tblW (cfgTailOff cfgBaseW) pVal
      have hd7 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 2))
          (.readHeap scrW (.lit (wScr + 1)))) m6 m7 30 :=
        DetExecAt.writeWordHeap 0 inp m6 tblW _ _
          (by change H3a.wRead m6 scrW wCfgBaseW + 2 = cfgTailOff cfgBaseW
              rw [hscr6, (hscr5 wCfgBaseW hwBW.2).2.2.2.2, hbW]; rfl)
          (by change H3a.wRead m6 scrW (wScr + 1) = pVal; rw [hscr6, hp5])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m7, (DetExecAt.ite_true (C_c := 15) hc_t
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd7).mono_cost (by omega),
        by unfold cfgHdrWStride at hbaseW
           exact InFootprint.wWrite hfp6 htblW (by unfold cfgTailOff; omega) (by unfold cfgTailOff; omega),
        rfo_wWrite_in _ _ _ _ _ _ _ _ m6 pVal (by unfold cfgTailOff; omega) (by unfold cfgTailOff cfgHdrWStride; omega),
        fun w => wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgTailOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgTailOff; omega)),
        fun i hlo _ => wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff; omega)),
        fun k _ => wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgTailOff; omega)),
        ?_⟩
      rw [if_pos (by omega : nxVal < 0)]
      refine ⟨wRead_wWrite_self _ _ _ _, fun k hk _ => ?_⟩
      exact (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgTailOff; omega))).trans (hm6_prv k (hL_lt k hk))
    · have hb_lt : b < n := hL_lt b hb_L
      have hc_f : cValAt 0 inp m6 (.intLt (.readHeap scrW (.lit (wScr + 2))) (.lit 0)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m6 scrW (wScr + 2) < 0) = false
        rw [hscr6, hnx5, hnx_b]; exact decide_eq_false (by omega)
      let m7 := H3a.wWrite m6 tblW (cfgPrevOff cfgBaseW n b) pVal
      have hd7 : DetExec inp (.writeWordHeap tblW
          (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 6 * (n : ℤ))))
                (.readHeap scrW (.lit (wScr + 2))))
          (.readHeap scrW (.lit (wScr + 1)))) m6 m7 35 :=
        DetExecAt.writeWordHeap 0 inp m6 tblW _ _
          (by change (H3a.wRead m6 scrW wCfgBaseW + (3 + 6 * (n : ℤ))) + H3a.wRead m6 scrW (wScr + 2) =
                cfgPrevOff cfgBaseW n b
              rw [hscr6, (hscr5 wCfgBaseW hwBW.2).2.2.2.2, hbW, hscr6, hnx5, hnx_b]
              unfold cfgPrevOff; ring)
          (by change H3a.wRead m6 scrW (wScr + 1) = pVal; rw [hscr6, hp5])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m7, (DetExecAt.ite_false (C_c := 15) hc_f
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd7).mono_cost (by omega),
        by unfold cfgHdrWStride at hbaseW
           exact InFootprint.wWrite hfp6 htblW (by unfold cfgPrevOff; omega) (by unfold cfgPrevOff; omega),
        rfo_wWrite_in _ _ _ _ _ _ _ _ m6 pVal (by unfold cfgPrevOff; omega) (by unfold cfgPrevOff cfgHdrWStride; omega),
        fun w => wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgPrevOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgPrevOff; omega)),
        fun i _ hhi => wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff; omega)),
        fun k hk => wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgPrevOff; omega)),
        ?_⟩
      rw [if_neg (by rw [hnx_b]; omega : ¬ nxVal < 0)]
      refine ⟨(wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgPrevOff; omega))).trans hm6_tl,
        fun b' hb' => by
          have heq : b' = b := Int.ofNat.inj (hb'.symm.trans hnx_b)
          subst heq; exact wRead_wWrite_self _ _ _ _,
        fun k hk hne_nx => by
          have hkb : k ≠ b := fun heq => hne_nx (heq ▸ hnx_b.symm)
          exact (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff; omega))).trans (hm6_prv k (hL_lt k hk))⟩
  obtain ⟨m7, hd7, hfp7, hfr67, hscr7, hep7, hhd7, hmid7, hnxt7, htl_prop7⟩ := hstep7
  have hd_all : DetExec inp (unlinkLeftKeyStmt scrW tblW n wCfgBaseW wK wScr)
      m₀ m7 unlinkLeftKeyCost :=
    (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq hd7)))))).mono_cost
      (by unfold unlinkLeftKeyCost; omega)
  -- Check `EncLocalMatching tblW cfgBaseW n st' m7`
  have hmid75 : ∀ i : ℤ, cfgBaseW + 3 ≤ i → i < cfgBaseW + 3 + 6 * (n : ℤ) →
      H3a.wRead m7 tblW i = H3a.wRead m5 tblW i :=
    fun i hlo hhi => (hmid7 i hlo hhi).trans (hlow6 i hlo (by omega))
  have hep70 : H3a.wRead m7 tblW (cfgEpOff cfgBaseW) = (ep : ℤ) := by
    rw [hep7, hep6,
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    exact hep_r
  have hfst_filt : (st'.matchingList.map MatchingEdge.pair).map Prod.fst =
      L.filter (fun x => decide (x ≠ k₀)) := by
    rw [hpairs']
    dsimp only [L]
    clear * -
    induction st.matchingList with
    | nil => rfl
    | cons e tl ih =>
        simp only [List.map_cons, List.filter_cons]
        split_ifs with h
        · simp only [List.map_cons, ih]
        · exact ih
  have hndL' : ((st'.matchingList.map MatchingEdge.pair).map Prod.fst).Nodup := by
    rw [hfst_filt]; exact hndL.filter _
  have hndR' : ((st'.matchingList.map MatchingEdge.pair).map Prod.snd).Nodup := by
    rw [hpairs']
    exact hndR.sublist (List.Sublist.map _ (List.filter_sublist))
  have hpairs_lt' : ∀ xy ∈ st'.matchingList.map MatchingEdge.pair, xy.1 < n ∧ xy.2 < n := by
    rw [hpairs']; intro xy hxy; exact hpairs_lt xy (List.mem_of_mem_filter hxy)
  have hdll7 : IsKeyDLL ((st'.matchingList.map MatchingEdge.pair).map Prod.fst)
      (H3a.wRead m7 tblW (cfgHeadOff cfgBaseW))
      (H3a.wRead m7 tblW (cfgTailOff cfgBaseW))
      (fun k => H3a.wRead m7 tblW (cfgPrevOff cfgBaseW n k))
      (fun k => H3a.wRead m7 tblW (cfgNextOff cfgBaseW n k)) := by
    rw [hfst_filt]
    refine hdll.unlink_of_nodup hndL hk_mem_L ?_ htl_prop7
    rw [hhd7]
    split_ifs with hp_lt0
    · rw [if_pos hp_lt0] at hhd_prop6
      exact ⟨hhd_prop6.1, fun k hk hne => (hnxt7 k (hL_lt k hk)).trans (hhd_prop6.2 k hk hne)⟩
    · rw [if_neg hp_lt0] at hhd_prop6
      refine ⟨hhd_prop6.1, fun a ha => ?_, fun k hk hne => (hnxt7 k (hL_lt k hk)).trans (hhd_prop6.2.2 k hk hne)⟩
      rcases hp_or with hp_m1 | ⟨a₀, ha₀_L, hp_a₀⟩
      · omega
      · have heq : a = a₀ := Int.ofNat.inj (ha.symm.trans hp_a₀)
        subst heq
        exact (hnxt7 a (hL_lt a ha₀_L)).trans (hhd_prop6.2.1 a ha)
  refine ⟨m7, hd_all, hfp7,
    ⟨ep, hep1, hep70, hndL', hndR', hpairs_lt', by rwa [hUL'], by rwa [hUR'], hdll7,
      ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩,
    fun w hw => by rw [hscr7, hscr6, (hscr5 w hw).2.2.2.2],
    hfr05.trans (hfr56.trans hfr67)⟩
  · -- `hmL_le`
    intro x hx
    rw [hmid75 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateREpOff; omega))]
    by_cases hxk : x = k₀
    · subst hxk; rw [wRead_wWrite_self]; omega
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      exact hmL_le x hx
  · -- `hmL_to`
    intro x hx h
    rw [hmid75 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateREpOff; omega))] at h
    have hxk : x ≠ k₀ := by
      intro heq; subst heq; rw [wRead_wWrite_self] at h; omega
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)] at h
    rw [hmid75 _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff; omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), hpairs']
    obtain ⟨y, hy, hval⟩ := hmL_to x hx h
    exact ⟨y, List.mem_filter.mpr ⟨hy, decide_eq_true hxk⟩, hval⟩
  · -- `hmL_of`
    intro x y hxy
    rw [hpairs'] at hxy
    rcases List.mem_filter.mp hxy with ⟨hxy0, hdec⟩
    have hxk : x ≠ k₀ := of_decide_eq_true hdec
    have hx := (hpairs_lt (x, y) hxy0).1
    rw [hmid75 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
        hmid75 _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff; omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    exact hmL_of x y hxy0
  · -- `hmR_le`
    intro y hy
    rw [hmid75 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega)]
    by_cases hyy : y = y₀
    · subst hyy; rw [wRead_wWrite_self]; omega
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateLEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      exact hmR_le y hy
  · -- `hmR_to`
    intro y hy h
    rw [hmid75 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega)] at h
    have hyy : y ≠ y₀ := by
      intro heq; subst heq; rw [wRead_wWrite_self] at h; omega
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)] at h
    rw [hmid75 _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff; omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), hpairs']
    obtain ⟨x, hx0, hval⟩ := hmR_to y hy h
    have hxk : x ≠ k₀ := fun heq => hyy (pairs_eq_of_fst_nodup hndL (heq ▸ hx0) hmem_pair)
    exact ⟨x, List.mem_filter.mpr ⟨hx0, decide_eq_true hxk⟩, hval⟩
  · -- `hmR_of`
    intro x y hxy
    rw [hpairs'] at hxy
    rcases List.mem_filter.mp hxy with ⟨hxy0, hdec⟩
    have hxk : x ≠ k₀ := of_decide_eq_true hdec
    have hyy : y ≠ y₀ := fun heq => hxk (pairs_eq_of_snd_nodup hndR (heq ▸ hxy0) hmem_pair)
    have hy := (hpairs_lt (x, y) hxy0).2
    rw [hmid75 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega),
        hmid75 _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff; omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    exact hmR_of x y hxy0
  · -- `hiL`
    intro x hx
    rw [hUL', hmid75 _ (by unfold cfgInIdxLEpOff; omega) (by unfold cfgInIdxLEpOff; omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    exact hiL x hx
  · -- `hiR`
    intro x hx
    rw [hUR', hmid75 _ (by unfold cfgInIdxREpOff; omega) (by unfold cfgInIdxREpOff; omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff cfgMateREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff cfgMateLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    exact hiR x hx

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
