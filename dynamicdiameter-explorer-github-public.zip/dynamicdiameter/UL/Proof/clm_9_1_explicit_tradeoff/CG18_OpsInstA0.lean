import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeRAM
import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Layout

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 1. Converse Bridge: `HeapZeroRandStmt` + `DetExec` → `ExecDet` -/

private lemma cellCount_mono_of_live_sub {m₁ m₂ : ArithRAMMemory}
    (hw : m₁.words.live ⊆ m₂.words.live) (hr : m₁.reals.live ⊆ m₂.reals.live) :
    m₁.cellCount ≤ m₂.cellCount := by
  unfold ArithRAMMemory.cellCount WordStore.cellCount RealStore.cellCount
  exact Nat.add_le_add (Finset.card_le_card hw) (Finset.card_le_card hr)

private lemma heapZeroRand_live_and_step {d : ℕ} {inp : ArithRAMInput d} :
    ∀ (f : ℕ) (stk : List ArithRAMCont) (m₀ : ArithRAMMemory) (u₀ sp₀ : ℕ)
      (out : ArithRAMExecOutcome),
      CleanMem m₀ →
      (∀ c ∈ stk, HeapZeroRandCont c) →
      runArithRAMFuel inp f stk
        { mem := m₀, frameDepth := 0, remainingBits := [],
          unitCost := u₀, peakCellSpace := sp₀ } = .halted out →
      m₀.words.live ⊆ out.mem.words.live ∧
      m₀.reals.live ⊆ out.mem.reals.live ∧
      u₀ ≤ out.unitCost ∧
      ∀ (rest : List ArithRAMCont) (uA spA : ℕ),
        ∃ (k uB spB : ℕ),
          uB = uA + (out.unitCost - u₀) ∧
          spB ≤ max spA (inp.inputCellSpace + out.mem.cellCount) ∧
          ∀ fuel : ℕ,
            runArithRAMFuel inp (fuel + k) (stk ++ rest)
              { mem := m₀, frameDepth := 0, remainingBits := [],
                unitCost := uA, peakCellSpace := spA } =
            runArithRAMFuel inp fuel rest
              { mem := out.mem, frameDepth := 0, remainingBits := [],
                unitCost := uB, peakCellSpace := spB }
  | 0, [], m₀, u₀, sp₀, out, hcm, _, hrun => by
      simp only [runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, ArithRAMRunStatus.halted.injEq] at hrun
      subst out
      dsimp only
      rw [show m₀.popDepth 0 = m₀ from hcm]
      exact ⟨Finset.Subset.refl _, Finset.Subset.refl _, le_rfl,
        fun _ uA spA => ⟨0, uA, spA, by omega, le_max_left _ _, fun _ => by simp⟩⟩
  | 0, _ :: _, _, _, _, _, _, _, hrun => by
      simp [runArithRAMFuel] at hrun
  | f + 1, [], m₀, u₀, sp₀, out, hcm, _, hrun => by
      simp only [runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, ArithRAMRunStatus.halted.injEq] at hrun
      subst out
      dsimp only
      rw [show m₀.popDepth 0 = m₀ from hcm]
      exact ⟨Finset.Subset.refl _, Finset.Subset.refl _, le_rfl,
        fun _ uA spA => ⟨0, uA, spA, by omega, le_max_left _ _, fun _ => by simp⟩⟩
  | f + 1, item :: tl, m₀, u₀, sp₀, out, hcm, hstk, hrun => by
      have hitem := hstk item List.mem_cons_self
      have htl : ∀ c ∈ tl, HeapZeroRandCont c := fun c hc => hstk c (List.mem_cons_of_mem _ hc)
      cases item with
      | popScope _ => cases hitem
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              obtain ⟨hw, hr, hle, hsh⟩ := heapZeroRand_live_and_step f tl m₀ u₀ sp₀ out hcm htl hrun
              refine ⟨hw, hr, hle, fun rest uA spA => ?_⟩
              obtain ⟨k, uB, spB, huB, hspB, hstep⟩ := hsh rest uA spA
              refine ⟨k + 1, uB, spB, huB, hspB, fun fuel => ?_⟩
              rw [show fuel + (k + 1) = (fuel + k) + 1 by omega]
              simpa [runArithRAMFuel] using hstep fuel
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt body :: .repeatLoop r body :: tl), HeapZeroRandCont c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc'
                · exact hitem
                · rcases List.mem_cons.mp hc' with rfl | hc''
                  · exact hitem
                  · exact htl c hc''
              obtain ⟨hw, hr, hle, hsh⟩ := heapZeroRand_live_and_step f _ m₀ u₀ sp₀ out hcm hstk' hrun
              refine ⟨hw, hr, hle, fun rest uA spA => ?_⟩
              obtain ⟨k, uB, spB, huB, hspB, hstep⟩ := hsh rest uA spA
              refine ⟨k + 1, uB, spB, huB, hspB, fun fuel => ?_⟩
              rw [show fuel + (k + 1) = (fuel + k) + 1 by omega]
              simpa [runArithRAMFuel] using hstep fuel
      | stmt s =>
          cases hitem with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              obtain ⟨hw, hr, hle, hsh⟩ := heapZeroRand_live_and_step f tl m₀ (u₀ + 1) sp₀ out hcm htl hrun
              refine ⟨hw, hr, by omega, fun rest uA spA => ?_⟩
              obtain ⟨k, uB, spB, huB, hspB, hstep⟩ := hsh rest (uA + 1) spA
              refine ⟨k + 1, uB, spB, by omega, hspB, fun fuel => ?_⟩
              rw [show fuel + (k + 1) = (fuel + k) + 1 by omega]
              simpa [runArithRAMFuel] using hstep fuel
          | writeWordHeap t idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m₀.words idxE
              let e2 := evalIntExpr inp.toWordView 0 m₀.words valE
              let m' := H3a.wWrite m₀ t e1.1 e2.1
              have hcm' : CleanMem m' := cleanMem_wWrite hcm t e1.1 e2.1
              obtain ⟨hw', hr', hle, hsh⟩ := heapZeroRand_live_and_step f tl m'
                (u₀ + e1.2.1 + e2.2.1 + 1) _ out hcm' htl hrun
              have hw0 : m₀.words.live ⊆ out.mem.words.live :=
                (Finset.subset_insert _ _).trans hw'
              have hcc : m'.cellCount ≤ out.mem.cellCount := cellCount_mono_of_live_sub hw' hr'
              refine ⟨hw0, hr', by omega, fun rest uA spA => ?_⟩
              obtain ⟨k, uB, spB, huB, hspB, hstep⟩ := hsh rest
                (uA + e1.2.1 + e2.2.1 + 1) (max spA (inp.inputCellSpace + m'.cellCount))
              refine ⟨k + 1, uB, spB, by omega, by omega, fun fuel => ?_⟩
              rw [show fuel + (k + 1) = (fuel + k) + 1 by omega]
              simpa [runArithRAMFuel, e1, e2, m', H3a.wWrite] using hstep fuel
          | writeRealHeap t idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m₀.words idxE
              let e2 := evalRealExpr inp 0 m₀ valE
              let m' := H3a.rWrite m₀ t e1.1 e2.1
              have hcm' : CleanMem m' := cleanMem_rWrite hcm t e1.1 e2.1
              obtain ⟨hw', hr', hle, hsh⟩ := heapZeroRand_live_and_step f tl m'
                (u₀ + e1.2.1 + e2.2 + 1) _ out hcm' htl hrun
              have hr0 : m₀.reals.live ⊆ out.mem.reals.live :=
                (Finset.subset_insert _ _).trans hr'
              have hcc : m'.cellCount ≤ out.mem.cellCount := cellCount_mono_of_live_sub hw' hr'
              refine ⟨hw', hr0, by omega, fun rest uA spA => ?_⟩
              obtain ⟨k, uB, spB, huB, hspB, hstep⟩ := hsh rest
                (uA + e1.2.1 + e2.2 + 1) (max spA (inp.inputCellSpace + m'.cellCount))
              refine ⟨k + 1, uB, spB, by omega, by omega, fun fuel => ?_⟩
              rw [show fuel + (k + 1) = (fuel + k) + 1 by omega]
              simpa [runArithRAMFuel, e1, e2, m', H3a.rWrite] using hstep fuel
          | @seq s₁ s₂ hs₁ hs₂ =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt s₁ :: .stmt s₂ :: tl), HeapZeroRandCont c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc'
                · exact hs₁
                · rcases List.mem_cons.mp hc' with rfl | hc''
                  · exact hs₂
                  · exact htl c hc''
              obtain ⟨hw, hr, hle, hsh⟩ := heapZeroRand_live_and_step f _ m₀ u₀ sp₀ out hcm hstk' hrun
              refine ⟨hw, hr, hle, fun rest uA spA => ?_⟩
              obtain ⟨k, uB, spB, huB, hspB, hstep⟩ := hsh rest uA spA
              refine ⟨k + 1, uB, spB, huB, hspB, fun fuel => ?_⟩
              rw [show fuel + (k + 1) = (fuel + k) + 1 by omega]
              simpa [runArithRAMFuel] using hstep fuel
          | @ite c tB fB htB hfB =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalArithCond inp 0 m₀ c
              have hbr : HeapZeroRandCont (.stmt (if ec.1 then tB else fB)) := by
                dsimp [HeapZeroRandCont]; split_ifs <;> assumption
              have hstk' : ∀ x ∈ (.stmt (if ec.1 then tB else fB) :: tl), HeapZeroRandCont x := by
                intro x hx
                rcases List.mem_cons.mp hx with rfl | hx'
                · exact hbr
                · exact htl x hx'
              obtain ⟨hw, hr, hle, hsh⟩ := heapZeroRand_live_and_step f _ m₀ (u₀ + ec.2) sp₀ out hcm hstk' hrun
              refine ⟨hw, hr, by omega, fun rest uA spA => ?_⟩
              obtain ⟨k, uB, spB, huB, hspB, hstep⟩ := hsh rest (uA + ec.2) spA
              refine ⟨k + 1, uB, spB, by omega, hspB, fun fuel => ?_⟩
              rw [show fuel + (k + 1) = (fuel + k) + 1 by omega]
              simpa [runArithRAMFuel, ec] using hstep fuel
          | @repeatN cntE b hb =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalIntExpr inp.toWordView 0 m₀.words cntE
              let n_it := if 0 ≤ ec.1 then ec.1.toNat else 0
              have hstk' : ∀ x ∈ (.repeatLoop n_it b :: tl), HeapZeroRandCont x := by
                intro x hx
                rcases List.mem_cons.mp hx with rfl | hx'
                · exact hb
                · exact htl x hx'
              obtain ⟨hw, hr, hle, hsh⟩ := heapZeroRand_live_and_step f _ m₀ (u₀ + ec.2.1) sp₀ out hcm hstk' hrun
              refine ⟨hw, hr, by omega, fun rest uA spA => ?_⟩
              obtain ⟨k, uB, spB, huB, hspB, hstep⟩ := hsh rest (uA + ec.2.1) spA
              refine ⟨k + 1, uB, spB, by omega, hspB, fun fuel => ?_⟩
              rw [show fuel + (k + 1) = (fuel + k) + 1 by omega]
              simpa [runArithRAMFuel, ec, n_it] using hstep fuel

theorem detExec_to_execDet {d TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    {s : ArithRAMStmt} (hzr : HeapZeroRandStmt s)
    {m₀ m₁ : ArithRAMMemory}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hfp₁ : InFootprint TW BW TR BR m₁)
    {C : ℕ} (hdet : DetExec inp s m₀ m₁ C)
    {Post : ArithRAMMemory → Prop} (hpost : Post m₁) :
    ExecDet TW BW TR BR inp s m₀ Post C := by
  obtain ⟨k₀, u₁, sp₁, hu₁, hf₀⟩ := hdet [] 0 0 []
  have hrun0 := hf₀ 0
  simp only [Nat.add_zero, List.singleton_append, runArithRAMFuel, List.isEmpty_nil, ↓reduceIte] at hrun0
  rw [show m₁.popDepth 0 = m₁ from hfp₁.1] at hrun0
  obtain ⟨_, _, _, hsh⟩ := heapZeroRand_live_and_step k₀ [.stmt s] m₀ 0 0
    { mem := m₁, unitCost := u₁, peakCellSpace := sp₁ } hfp₀.1
    (fun c hc => by simp at hc; subst hc; exact hzr) hrun0
  have hcc₁ : m₁.cellCount ≤ TW * BW + TR * BR := hfp₁.cellCount_le
  refine ⟨m₁, hpost, hfp₁, hfp₁.1, hcc₁, fun rest uA spA => ?_⟩
  obtain ⟨k, uB, spB, huB, hspB, hfuel⟩ := hsh rest uA spA
  exact ⟨k, uB, spB, by dsimp at huB; omega,
    by dsimp at hspB; omega,
    fun fuel => by simpa using hfuel fuel⟩

/-! ### 2. `HeapZeroRandStmt` Witnesses for `CG18` `ManagedNode` Statements -/

structure ConfigMatchHeapZeroRand
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : Prop where
  hzr_clearStmt : ∀ spec wBW wBR wScr rScr,
    HeapZeroRandStmt (ops.clearStmt spec wBW wBR wScr rScr)
  hzr_insertStmt : ∀ spec wBW wBR wOffO wOffV wUid wSeedOff wScr rScr,
    HeapZeroRandStmt (ops.insertStmt spec wBW wBR wOffO wOffV wUid wSeedOff wScr rScr)
  hzr_deleteStmt : ∀ spec wBW wBR wOffO wOffV wUid wSeedOff wScr rScr,
    HeapZeroRandStmt (ops.deleteStmt spec wBW wBR wOffO wOffV wUid wSeedOff wScr rScr)
  hzr_readEdgeStmt : ∀ spec wBW wOutHas wOutU wOutV wScr,
    HeapZeroRandStmt (ops.readEdgeStmt spec wBW wOutHas wOutU wOutV wScr)

private lemma hzr_seqFinCfgAux (N_cfg : ℕ) (f : Fin N_cfg → ArithRAMStmt)
    (hf : ∀ i : Fin N_cfg, HeapZeroRandStmt (f i)) :
    ∀ k : ℕ, HeapZeroRandStmt (seqFinCfgAux N_cfg f k)
  | 0 => .skip
  | k + 1 => by
      dsimp [seqFinCfgAux]
      split_ifs with hk
      · exact .seq (hf _) (hzr_seqFinCfgAux N_cfg f hf k)
      · exact .skip

theorem hzr_seqFinCfgStmt (N_cfg : ℕ) (f : Fin N_cfg → ArithRAMStmt)
    (hf : ∀ i : Fin N_cfg, HeapZeroRandStmt (f i)) :
    HeapZeroRandStmt (seqFinCfgStmt N_cfg f) :=
  hzr_seqFinCfgAux N_cfg f hf N_cfg

theorem hzr_managedNodeOpenEmptyStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    {ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    (hhzr : ConfigMatchHeapZeroRand ops)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (wNodeBaseW wNodeBaseR wBirthSz rInO wScr rScr : ℤ) :
    HeapZeroRandStmt (managedNodeOpenEmptyStmt ops specs cap_hist K_seg
      wNodeBaseW wNodeBaseR wBirthSz rInO wScr rScr) := by
  unfold managedNodeOpenEmptyStmt
  exact .seq (hzr_openNodeWriteCenterVarStmt _ _ _ _ _ _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (hzr_swapPoolBumpClearStmt _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (hzr_swapPoolBumpClearStmt _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (hzr_radTreeBumpClearStmt _ _ _)
          (hzr_seqFinCfgStmt N_cfg _ (fun i =>
            .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
                  (hhzr.hzr_clearStmt _ _ _ _ _))))))))))))))))

theorem hzr_managedNodeInsertMatStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    {ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    (hhzr : ConfigMatchHeapZeroRand ops)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr : ℤ) :
    HeapZeroRandStmt (managedNodeInsertMatStmt ops specs cap_hist K_seg
      wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr) := by
  unfold managedNodeInsertMatStmt managedNodeInsertCfgsStmt passesNodeStmt
  exact .seq (.writeWordHeap _ _ _)
    (.seq (hzr_swapPoolInsertStmt _ _ _ _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (hzr_radTreeUpdateLeafStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (hzr_coreBallTestStmt true _ _ _ _ _ _ _ _ _)
    (.seq (.ite (.seq (.writeWordHeap _ _ _) (hzr_swapPoolInsertStmt _ _ _ _ _ _)) .skip)
          (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
            (.ite (hzr_seqFinCfgStmt N_cfg _ (fun i =>
                    .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
                    (.seq (.writeWordHeap _ _ _)
                          (hhzr.hzr_insertStmt _ _ _ _ _ _ _ _ _)))))
                  .skip))))))))))))))

theorem hzr_managedNodeDeleteMatStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    {ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    (hhzr : ConfigMatchHeapZeroRand ops)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr : ℤ) :
    HeapZeroRandStmt (managedNodeDeleteMatStmt ops specs cap_hist K_seg
      wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr) := by
  unfold managedNodeDeleteMatStmt managedNodeDeleteCfgsStmt passesNodeStmt
  exact .seq (.writeWordHeap _ _ _)
    (.seq (hzr_swapPoolDeleteStmt _ _ _ _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (hzr_radTreeUpdateLeafStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _)
    (.seq (hzr_coreBallTestStmt true _ _ _ _ _ _ _ _ _)
    (.seq (.ite (.seq (.writeWordHeap _ _ _) (hzr_swapPoolDeleteStmt _ _ _ _ _ _)) .skip)
          (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
            (.ite (hzr_seqFinCfgStmt N_cfg _ (fun i =>
                    .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
                    (.seq (.writeWordHeap _ _ _)
                          (hhzr.hzr_deleteStmt _ _ _ _ _ _ _ _ _)))))
                  .skip)))))))))))

theorem hzr_managedNodeBumpAgeStmt (scrW tblW : ℕ) (wNodeBaseW : ℤ) :
    HeapZeroRandStmt (managedNodeBumpAgeStmt scrW tblW wNodeBaseW) :=
  .writeWordHeap _ _ _

theorem hzr_managedNodeContainsStmt (isRes : Bool) (scrW tblW : ℕ)
    (wNodeBaseW wUid wOut wScr : ℤ) (n : ℕ) :
    HeapZeroRandStmt (managedNodeContainsStmt isRes scrW tblW wNodeBaseW wUid wOut wScr n) :=
  .seq (.writeWordHeap _ _ _) (hzr_swapPoolMemStmt _ _ _ _ _ _ _)

theorem hzr_managedNodeReadCfgEdgeStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    {ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    (hhzr : ConfigMatchHeapZeroRand ops)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (i : Fin N_cfg)
    (wNodeBaseW wOutHas wOutU wOutV wScr : ℤ) :
    HeapZeroRandStmt (managedNodeReadCfgEdgeStmt ops specs cap_hist K_seg i
      wNodeBaseW wOutHas wOutU wOutV wScr) :=
  .seq (.writeWordHeap _ _ _) (hhzr.hzr_readEdgeStmt _ _ _ _ _ _)

theorem hzr_managedNodeReadMaxRadiusStmt (scrW scrR tblW tblR : ℕ)
    (wNodeBaseW wNodeBaseR wOutHas wOutUid rOutSq wScr : ℤ) (n cap_hist d : ℕ) :
    HeapZeroRandStmt (managedNodeReadMaxRadiusStmt scrW scrR tblW tblR
      wNodeBaseW wNodeBaseR wOutHas wOutUid rOutSq wScr n cap_hist d) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (hzr_radTreeQueryRootStmt _ _ _ _ _ _ _ _ _ _))

/-! ### 3. Canonical Coordinate Extraction from `ptsRTbl = 1` & Slot Disjointness -/

noncomputable def memPtsOf (d : ℕ) (m : ArithRAMMemory) (x : ℕ) : EuclideanSpace ℝ (Fin d) :=
  (WithLp.equiv 2 (Fin d → ℝ)).symm (fun c : Fin d => H3a.rRead m ptsRTbl (((x * d + c.val : ℕ) : ℤ)))

theorem euclideanCoord_memPtsOf {d : ℕ} (m : ArithRAMMemory) (x : ℕ) (c : Fin d) :
    euclideanCoord (memPtsOf d m x) c = H3a.rRead m ptsRTbl (((x * d + c.val : ℕ) : ℤ)) := by
  simp [memPtsOf, euclideanCoord]

theorem memPtsOf_eq_of_coords {d : ℕ} (m : ArithRAMMemory) (x : ℕ)
    (pt : EuclideanSpace ℝ (Fin d))
    (h : ∀ c : Fin d, H3a.rRead m ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord pt c) :
    memPtsOf d m x = pt := by
  apply (WithLp.equiv 2 (Fin d → ℝ)).injective
  ext c
  simpa [memPtsOf, euclideanCoord] using h c

theorem memPtsOf_congr (d : ℕ) {m₁ m₂ : ArithRAMMemory} {x : ℕ}
    (h : ∀ c : Fin d,
      H3a.rRead m₁ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) =
        H3a.rRead m₂ ptsRTbl (((x * d + c.val : ℕ) : ℤ))) :
    memPtsOf d m₁ x = memPtsOf d m₂ x := by
  apply (WithLp.equiv 2 (Fin d → ℝ)).injective
  ext c
  simpa [memPtsOf] using h c

theorem slotSlice_bounds {M stride slot : ℕ} (hs : slot < M) :
    0 ≤ ((slot * stride : ℕ) : ℤ) ∧
    ((slot * stride : ℕ) : ℤ) + (stride : ℤ) ≤ ((M * stride : ℕ) : ℤ) := by
  refine ⟨Nat.cast_nonneg _, ?_⟩
  have hnat : slot * stride + stride ≤ M * stride := by
    calc slot * stride + stride = (slot + 1) * stride := by ring
      _ ≤ M * stride := Nat.mul_le_mul_right stride hs
  exact_mod_cast hnat

theorem slotSlice_disj {stride s₁ s₂ : ℕ} (hne : s₁ ≠ s₂) (i : ℤ)
    (hlo : ((s₁ * stride : ℕ) : ℤ) ≤ i)
    (hhi : i < ((s₁ * stride : ℕ) : ℤ) + (stride : ℤ)) :
    i < ((s₂ * stride : ℕ) : ℤ) ∨ ((s₂ * stride : ℕ) : ℤ) + (stride : ℤ) ≤ i := by
  rcases lt_or_gt_of_ne hne with hlt | hgt
  · apply Or.inl
    have h1 : s₁ * stride + stride ≤ s₂ * stride := by
      calc s₁ * stride + stride = (s₁ + 1) * stride := by ring
        _ ≤ s₂ * stride := Nat.mul_le_mul_right stride hlt
    have h1z : ((s₁ * stride : ℕ) : ℤ) + (stride : ℤ) ≤ ((s₂ * stride : ℕ) : ℤ) := by
      exact_mod_cast h1
    omega
  · apply Or.inr
    have h1 : s₂ * stride + stride ≤ s₁ * stride := by
      calc s₂ * stride + stride = (s₂ + 1) * stride := by ring
        _ ≤ s₁ * stride := Nat.mul_le_mul_right stride hgt
    have h1z : ((s₂ * stride : ℕ) : ℤ) + (stride : ℤ) ≤ ((s₁ * stride : ℕ) : ℤ) := by
      exact_mod_cast h1
    omega

theorem curSet_card_le_of_lt {S : Finset ℕ} {n : ℕ} (hS : ∀ x ∈ S, x < n) :
    S.card ≤ n := by
  have hsub : S ⊆ Finset.range n := fun x hx => Finset.mem_range.mpr (hS x hx)
  exact (Finset.card_le_card hsub).trans (by simp)

theorem curSet_card_insert_le_of_lt {S : Finset ℕ} {p n : ℕ}
    (hp_not : p ∉ S) (hp_lt : p < n) (hS : ∀ x ∈ S, x < n) :
    S.card + 1 ≤ n := by
  have hsub : Insert.insert p S ⊆ Finset.range n := by
    intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hxS
    · exact Finset.mem_range.mpr hp_lt
    · exact Finset.mem_range.mpr (hS x hxS)
  have hc : (Insert.insert p S).card ≤ n := (Finset.card_le_card hsub).trans (by simp)
  rwa [Finset.card_insert_of_notMem hp_not] at hc

/-! ### 4. Helper: Copy `(o[0..d-1], s)` from `engRealTbl[16..16+d]` to `scrR[0..d]` -/

def copyCenterHeightStmt (scrW scrR : ℕ) (wCtr : ℤ) (d : ℕ) : ArithRAMStmt :=
  .seq (forLoopStmt scrW wCtr d
          (.writeRealHeap scrR (.readHeap scrW (.lit wCtr))
            (.readRealHeap engRealTbl (.add (.lit 16) (.readHeap scrW (.lit wCtr))))))
       (.writeRealHeap scrR (.lit (d : ℤ)) (.readRealHeap engRealTbl (.lit (16 + (d : ℤ)))))

theorem hzr_copyCenterHeightStmt (scrW scrR : ℕ) (wCtr : ℤ) (d : ℕ) :
    HeapZeroRandStmt (copyCenterHeightStmt scrW scrR wCtr d) := by
  unfold copyCenterHeightStmt forLoopStmt
  repeat' constructor

theorem exec_copyCenterHeightStmt {d TW BW TR BR scrW scrR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCtr : ℤ) (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hne2 : engRealTbl ≠ scrR)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (hd_BR : (d : ℤ) + 1 ≤ (BR : ℤ))
    (ho_in : ∀ c : Fin d, H3a.rRead m₀ engRealTbl (16 + (c.val : ℤ)) = euclideanCoord o c)
    (hs_in : H3a.rRead m₀ engRealTbl (16 + (d : ℤ)) = s) :
    ExecDet TW BW TR BR inp (copyCenterHeightStmt scrW scrR wCtr d) m₀
      (fun m₁ =>
        (∀ c : Fin d, H3a.rRead m₁ scrR (c.val : ℤ) = euclideanCoord o c) ∧
        H3a.rRead m₁ scrR (d : ℤ) = s ∧
        (∀ w, w ≠ wCtr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
        (∀ t, t ≠ scrW → ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ t, t ≠ scrR → ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      (35 + 35 * d) := by
  unfold copyCenterHeightStmt
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    (∀ c : Fin d, c.val < k → H3a.rRead m scrR (c.val : ℤ) = euclideanCoord o c) ∧
    (∀ w, w ≠ wCtr → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
    (∀ t, t ≠ scrW → ∀ i, H3a.wRead m t i = H3a.wRead m₀ t i) ∧
    (∀ t, t ≠ scrR → ∀ i, H3a.rRead m t i = H3a.rRead m₀ t i)
  refine ExecDet.seq' 15
    (ExecDet.forLoop scrW wCtr d _ Inv 25 hfp₀ hscrW hwCtr.1 hwCtr.2
      ⟨fun _ hc => absurd hc (Nat.not_lt_zero _),
       fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
       fun t ht _ => wRead_wWrite_of_ne _ _ (Or.inl ht),
       fun _ _ _ => rfl⟩
      (fun k hk m ⟨ho_k, hw_k, hwt_k, hrt_k⟩ hctr hfpm => ?_))
    (by omega)
    (fun ma ⟨ho_a, hw_a, hwt_a, hrt_a⟩ hfpa => ?_)
  · let ck : Fin d := ⟨k, hk⟩
    have ho_m : H3a.rRead m engRealTbl (16 + (k : ℤ)) = euclideanCoord o ck :=
      (hrt_k engRealTbl hne2 (16 + (k : ℤ))).trans (ho_in ck)
    refine ExecDet.rWrite inp scrR
      (.readHeap scrW (.lit wCtr))
      (.readRealHeap engRealTbl (.add (.lit 16) (.readHeap scrW (.lit wCtr))))
      (k : ℤ) (euclideanCoord o ck)
      hfpm hscrR (Nat.cast_nonneg _) (by omega)
      (by change H3a.wRead m scrW wCtr = (k : ℤ); exact hctr)
      (by change H3a.rRead m engRealTbl (16 + H3a.wRead m scrW wCtr) = _; rw [hctr]; exact ho_m)
      (by dsimp [intExprOps, realExprOps]; omega) ?_
    refine ⟨by rw [wRead_rWrite]; exact hctr,
      fun c hc => ?_,
      fun w hw => by rw [wRead_wWrite_of_ne _ _ (Or.inr hw), wRead_rWrite]; exact hw_k w hw,
      fun t ht i => by rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_rWrite]; exact hwt_k t ht i,
      fun t ht i => by rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl ht)]; exact hrt_k t ht i⟩
    rw [rRead_wWrite]
    rcases Nat.lt_succ_iff_lt_or_eq.mp hc with hlt | heq
    · exact (rRead_rWrite_of_ne _ _ (Or.inr (by omega))).trans (ho_k c hlt)
    · have hck : ck = c := Fin.ext heq.symm
      rw [← hck]; exact rRead_rWrite_self _ _ _ _
  · have hs_ma : H3a.rRead ma engRealTbl (16 + (d : ℤ)) = s :=
      (hrt_a engRealTbl hne2 (16 + (d : ℤ))).trans hs_in
    refine ExecDet.rWrite inp scrR (.lit (d : ℤ)) (.readRealHeap engRealTbl (.lit (16 + (d : ℤ))))
      (d : ℤ) s hfpa hscrR (Nat.cast_nonneg _) (by omega) rfl hs_ma
      (by dsimp [intExprOps, realExprOps]; omega) ?_
    refine ⟨fun c => ?_, rRead_rWrite_self _ _ _ _, hw_a, hwt_a,
      fun t ht i => (rRead_rWrite_of_ne _ _ (Or.inl ht)).trans (hrt_a t ht i)⟩
    have := c.isLt
    exact (rRead_rWrite_of_ne _ _ (Or.inr (by omega))).trans (ho_a c c.isLt)

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
