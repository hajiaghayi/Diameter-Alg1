import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B1a
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 8b. `.copy`-Phase Branch (`tickJobCopyBranchStmt`) & Full Proof -/

def tickJobCopyOpenBuildStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  let ctrCoinOff : ℤ := ((cp.B_S1 + cp.N_op_s2 * cp.B_op + r.val * cp.B_ctr : ℕ) : ℤ)
  .seq (allocFreshSlotStmt cp)
  (.seq (.writeWordHeap engScrTbl (.lit 21) (.lit (snapElemOff cp r.val)))
  (.seq (.writeWordHeap engScrTbl (.lit 22) (.readHeap engMetaTbl (.lit (base + 5))))
  (.seq (.writeWordHeap engScrTbl (.lit 26) (.lit ctrCoinOff))
  (.seq (ops.evalHPJCenterStmt engArrTbl 21 22 26)
  (.seq (ops.openEmptyStmt 39 22)
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 2)) (.lit 1))
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 4)) (.lit 0))
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 6)) (.lit 0))
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 7)) (.readHeap engScrTbl (.lit 39)))
        (.writeWordHeap engScrTbl (.lit 10) (.lit 0)))))))))))

def tickJobCopyBranchStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .seq (tickJobCopyRunLoopStmt ops r)
    (.ite (.intLt (.readHeap engMetaTbl (.lit (base + 4))) (.readHeap engMetaTbl (.lit (base + 3))))
      (.writeWordHeap engScrTbl (.lit 10) (.lit 0))
      (.ite (.intLe (.readHeap engMetaTbl (.lit (base + 5))) (.lit (cp.B_scan : ℤ)))
        (.writeWordHeap engScrTbl (.lit 10) (.lit 1))
        (tickJobCopyOpenBuildStmt ops r)))

theorem zeroRand_tickJobCopyBranchStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (tickJobCopyBranchStmt ops r) :=
  .seq (zeroRand_tickJobCopyRunLoopStmt ops r)
    (.ite (.writeWordHeap _ _ _)
      (.ite (.writeWordHeap _ _ _)
        (.seq (zeroRand_allocFreshSlotStmt cp)
        (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
        (.seq (ops.zeroRand_evalHPJCenter engArrTbl 21 22 26)
        (.seq (ops.zeroRand_openEmpty 39 22)
        (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))))))))))

def tickJobCopyCost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  (140 + cp.B_scan * (2 * ops.C_read + 260)) +
    (allocFreshSlotCost cp + ops.C_hpj + ops.C_open + 200)

theorem exec_tickJobCopyBranchStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {actH S_anc : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    {anc : MNode cp} {jb : SuffixJob cp} {cs : CopyState}
    {servLen : ℕ} {servSlots : List ℕ}
    {curJobs : Fin cp.D_max → Option (SuffixJob cp)}
    {readySlots : Fin cp.D_max → List ℕ}
    {curSlots : Fin cp.D_max → ℕ}
    {bits : Fin cp.B_STEP → Bool}
    {m₀ : ArithRAMMemory}
    (hphase : jb.phase = .copy cs)
    (hcur_r : curJobs r = some jb)
    (hserv_le : servLen ≤ cp.D_max)
    (hslen : servSlots.length = servLen)
    (hr_serv : r.val < servSlots.length)
    (hS_anc : S_anc ⊆ actH)
    (hact_n : ∀ x ∈ actH, x < cp.n)
    (hact_pts : ∀ x ∈ actH, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hanc_ln : LiveNodeInv cp actH pts gt S_anc anc)
    (hjb_inv : SuffixJobInvSlack cp cp.B_scan actH pts gt S_anc anc r.val jb)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hmeta0 : wRead m₀ engMetaTbl 0 = (servLen : ℤ))
    (hserv_slots : ∀ i (his : i < servSlots.length),
      wRead m₀ engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ))
    (henc_anc : ops.EncNode anc (servSlots[r.val]'hr_serv) m₀)
    (hjobs_enc : ∀ r' : Fin cp.D_max,
      EncJobSlot ops r' (curJobs r') (readySlots r') (curSlots r') m₀)
    (hall_nd : (servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r'))).Nodup)
    (hall_lt : ∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')), s < M_slots cp)
    (hcoins : MemHasStepCoins cp bits m₀) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
      ω₂.1 ⟨r.val * cp.B_scan + j.val, by
        have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
          calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan := Nat.add_lt_add_left j.isLt _
            _ = (r.val + 1) * cp.B_scan := by ring
            _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
        exact Nat.lt_add_right _ this⟩
    let ctrSeed : CenterSeed cp := ω₂.2 r.castSucc
    let advRes := advanceOneJob cp pts gt anc r jb bSeeds ctrSeed
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (tickJobCopyBranchStmt ops r) m₀
      (TickJobResultPost ops r servSlots curJobs readySlots curSlots advRes m₀)
      (tickJobCopyCost ops) := by
  intro ω₂ bSeeds ctrSeed advRes
  have hTW := ops.hTW; have hBW_meta := ops.hBW_meta
  have hBW_arr := ops.hBW_arr; have hBW_scr := ops.hBW_scr
  let base := jobMetaBase cp r.val
  have hmeta_b : 16 + cp.D_max + 8 * r.val + 8 ≤ ops.BW := by
    have hr_lt := r.isLt; have hD2 : 0 ≤ cp.D_max * cp.D_max := Nat.zero_le _
    nlinarith only [hr_lt, hBW_meta, hD2]
  have hj_r_enc : EncJobSlot ops r (some jb) (readySlots r) (curSlots r) m₀ := by
    simpa [hcur_r] using hjobs_enc r
  have hj_r := hj_r_enc
  simp only [EncJobSlot, hphase] at hj_r
  rcases hj_r with ⟨hact1, hr_le, hr_len, hw_rlen, hready_enc, hp2, hw_L, hw_cur, hsnap_enc⟩
  have hjb_inv' := hjb_inv
  dsimp only [SuffixJobInvSlack] at hjb_inv'
  rcases hjb_inv' with ⟨hrs_lt, hcl_r, _, _, hph_inv⟩
  rw [hphase] at hph_inv
  rcases hph_inv with ⟨hcur_lt_L, _, hcs_inv⟩
  set T_end := foldResiduals pts S_anc jb.ready
  have hTend_sub : T_end ⊆ actH := (chainListInv_getElem S_anc jb.ready hS_anc hcl_r).1
  have hTend_n : ∀ x ∈ T_end, x < cp.n := fun x hx => hact_n x (hTend_sub hx)
  let srcHist : List ℕ :=
    (match jb.ready.getLast? with | none => anc | some u_last => u_last).histArr
  let tgtArr : List ℕ :=
    match jb.ready.getLast? with | none => anc.nd.denseArr | some u_last => u_last.resArr
  set steps := min (cs.L_hist - cs.copyCur) cp.B_scan
  set cs' := advanceCopyLoop srcHist tgtArr steps cs
  have hadv_eq : advRes =
      (if cs'.copyCur < cs'.L_hist then
        Sum.inl { ready := jb.ready, phase := .copy cs' }
      else if cs'.snapArr.length ≤ cp.B_scan then
        Sum.inr (jb.ready, cs'.snapArr, false)
      else
        let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts cs'.snapArr ctrSeed
        let P₀_uid := cs'.snapArr.toFinset.image gt.uidOf
        Sum.inl { ready := jb.ready, phase := .build (BuildState.init cp cs'.L_hist cs'.snapArr os.1 os.2 P₀_uid) }) := by
    dsimp only [advRes, cs', steps, srcHist, tgtArr]
    unfold advanceOneJob; rw [hphase]
    cases jb.ready.getLast? <;> rfl
  -- Step 1: Run `tickJobCopyRunLoopStmt ops r`
  have hRunLoop := exec_tickJobCopyRunLoopStmt ops inp r hphase hcur_r hr_serv hS_anc hact_n
    hanc_ln hjb_inv hfp₀ hsr₀ hserv_slots henc_anc hj_r_enc hall_lt
  unfold tickJobCopyBranchStmt
  refine ExecDet.seq' (allocFreshSlotCost cp + ops.C_hpj + ops.C_open + 200) hRunLoop
    (by unfold tickJobCopyCost; omega) ?_
  intro mL ⟨hsrL, hwLL, hwcurL, hsnapL, hndL, hftL, hfmL, hfaL, hfsL, hfrL⟩ hfpL
  let jb_copy' : SuffixJob cp := { ready := jb.ready, phase := .copy cs' }
  have hfmL_job : ∀ i, ¬ InJobMetaRegion cp r.val i → wRead mL engMetaTbl i = wRead m₀ engMetaTbl i := by
    intro i hni
    exact hfmL i (fun he => hni (Or.inl ⟨by omega, by omega⟩))
                 (fun he => hni (Or.inl ⟨by omega, by omega⟩))
  have hfaL_job : ∀ i, ¬ InJobArrRegion cp r.val i → wRead mL engArrTbl i = wRead m₀ engArrTbl i := by
    intro i hni
    exact hfaL i (by unfold InJobArrRegion at hni; omega) (by unfold InJobArrRegion at hni; omega)
  have henc_jb_copy'_mL : EncJobSlot ops r (some jb_copy') (readySlots r) (curSlots r) mL := by
    simp only [EncJobSlot, jb_copy']
    refine ⟨(hfmL base (by omega) (by omega)).trans hact1, hr_le, hr_len,
      (hfmL (base + 1) (by omega) (by omega)).trans hw_rlen,
      fun q hq hqs => ?_,
      (hfmL (base + 2) (by omega) (by omega)).trans hp2, hwLL, hwcurL, hsnapL⟩
    have hnn_rD : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) := by exact_mod_cast Nat.zero_le (r.val * cp.D_max)
    have hrd_ne4 : readySlotOff cp r.val q ≠ base + 4 := by
      have := r.isLt; simp only [base, readySlotOff, jobMetaBase]; omega
    have hrd_ne5 : readySlotOff cp r.val q ≠ base + 5 := by
      have := r.isLt; simp only [base, readySlotOff, jobMetaBase]; omega
    have hq_M : (readySlots r)[q]'hqs < M_slots cp := hall_lt _
      (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, by
        simp only [hcur_r, jobUsedSlots, hphase]; exact List.getElem_mem hqs⟩))
    exact ⟨(hfmL _ hrd_ne4 hrd_ne5).trans (hready_enc q hq hqs).1,
      hndL _ _ hq_M (hready_enc q hq hqs).2⟩
  have hjobs_mL : ∀ r' : Fin cp.D_max,
      EncJobSlot ops r' (Function.update curJobs r (some jb_copy') r') (readySlots r') (curSlots r') mL := by
    intro r'
    by_cases heq : r' = r
    · subst heq; simpa using henc_jb_copy'_mL
    · rw [Function.update_of_ne heq]
      exact encJobSlot_other_of_frame heq (hjobs_enc r')
        (fun s hs => hall_lt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r', hs⟩)))
        hfmL_job hfaL_job (fun mn' s hs _ he0 => hndL mn' s hs he0)
  by_cases hstill : cs'.copyCur < cs'.L_hist
  · -- Case C1: `cs'.copyCur < cs'.L_hist` -> `engScrTbl[10] := 0`, continue `.copy cs'`!
    have hcondC1 : (evalArithCond inp 0 mL
        (.intLt (.readHeap engMetaTbl (.lit (base + 4))) (.readHeap engMetaTbl (.lit (base + 3))))).1 = true := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead mL engMetaTbl (base + 4) < wRead mL engMetaTbl (base + 3)) = true
      rw [hwcurL, hwLL]; exact decide_eq_true (by exact_mod_cast hstill)
    refine ExecDet.ite' (C_c := 12) (C_b := allocFreshSlotCost cp + ops.C_hpj + ops.C_open + 188) _ _ _ hcondC1
      (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
      (by clear * -; nlinarith)
    refine ExecDet.wWrite inp engScrTbl (.lit 10) (.lit 0) 10 0
      hfpL (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
      rfl rfl (by simp [intExprOps]) ?_
    set mF := H3a.wWrite mL engScrTbl 10 0
    have hw9_F : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead mL t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    have hadv_c1 : advRes = Sum.inl jb_copy' := by rw [hadv_eq, if_pos hstill]
    have hall_eq : (List.finRange cp.D_max).flatMap (fun r' =>
        jobUsedSlots (Function.update curJobs r (some jb_copy') r')
          (Function.update readySlots r (readySlots r) r')
          (Function.update curSlots r (curSlots r) r')) =
        (List.finRange cp.D_max).flatMap (fun r' =>
          jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) := by
      congr 1; ext r'
      by_cases heq : r' = r
      · subst heq; simp [Function.update_self, hcur_r, jb_copy', jobUsedSlots, hphase]
      · simp [Function.update_of_ne heq]
    refine ⟨ops.slotsReady_ext mL mF hsrL hw9_F (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans (hftL t ht9 ht1 ht2 ht3 i),
      fun i hni => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hfmL_job i hni),
      fun i hni => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hfaL_job i hni),
      fun i hi10 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hfsL i (by omega)),
      fun t ht2 i => (rRead_wWrite _ _ _ _ _ _).trans (hfrL t (by omega) i),
      (rRead_wWrite _ _ _ _ _ _).trans (hfrL engRealTbl (by decide) 0),
      fun mn' s hs _ he0 => ops.encNode_ext mn' s mL mF (hndL mn' s hs he0)
        hw9_F (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      jb_copy', readySlots r, curSlots r,
      encJobSlot_ext henc_jb_copy'_mL (fun _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun mn' s he => ops.encNode_ext mn' s mL mF he hw9_F
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)),
      fun r' => by
        simp only [Function.update_eq_self]
        exact encJobSlot_ext (hjobs_mL r') (fun _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun mn' s he => ops.encNode_ext mn' s mL mF he hw9_F
            (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)),
      by rwa [hall_eq],
      by rwa [hall_eq],
      by rw [hadv_c1]; exact ⟨wRead_wWrite_self _ _ _ _, rfl⟩⟩
  · -- `cs'.copyCur = cs'.L_hist`
    have hcondC1 : (evalArithCond inp 0 mL
        (.intLt (.readHeap engMetaTbl (.lit (base + 4))) (.readHeap engMetaTbl (.lit (base + 3))))).1 = false := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead mL engMetaTbl (base + 4) < wRead mL engMetaTbl (base + 3)) = false
      rw [hwcurL, hwLL]; exact decide_eq_false (by intro hc; apply hstill; exact_mod_cast hc)
    refine ExecDet.ite' (C_c := 12) (C_b := allocFreshSlotCost cp + ops.C_hpj + ops.C_open + 188) _ _ _ hcondC1
      (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
      (by clear * -; nlinarith)
    have hsteps_rem : cs.copyCur + steps ≤ cs.L_hist := by dsimp [steps]; omega
    have htgt_set : tgtArr.toFinset = T_end := by
      dsimp only [tgtArr, T_end]
      cases hgl : jb.ready.getLast? with
      | none =>
          have hemp : jb.ready = [] := by
            cases hlr : jb.ready with
            | nil => rfl
            | cons _ _ => simp [hlr] at hgl
          rw [hemp]; dsimp only [foldResiduals]; exact hanc_ln.1
      | some u_last => exact (chainListInv_getLast hS_anc hcl_r hgl).2.1
    rcases advanceCopyLoop_spec htgt_set steps hsteps_rem hcs_inv
      with ⟨_, _, hcs_inv', hdone_snap⟩
    have hcur_le_L : cs'.copyCur ≤ cs'.L_hist := hcs_inv'.1
    have hcur_eq_L : cs'.copyCur = cs'.L_hist := by omega
    have hsnap_Tend : cs'.snapArr.toFinset = T_end := hdone_snap hcur_eq_L
    by_cases hsmall : cs'.snapArr.length ≤ cp.B_scan
    · -- Case C2: `cs'.snapArr.length ≤ cp.B_scan` -> commit code `1`!
      have hcondC2 : (evalArithCond inp 0 mL
          (.intLe (.readHeap engMetaTbl (.lit (base + 5))) (.lit (cp.B_scan : ℤ)))).1 = true := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mL engMetaTbl (base + 5) ≤ (cp.B_scan : ℤ)) = true
        rw [hsnapL.2.2.1]; exact decide_eq_true (by exact_mod_cast hsmall)
      refine ExecDet.ite' (C_c := 12) (C_b := allocFreshSlotCost cp + ops.C_hpj + ops.C_open + 176) _ _ _ hcondC2
        (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
        (by clear * -; nlinarith)
      refine ExecDet.wWrite inp engScrTbl (.lit 10) (.lit 1) 10 1
        hfpL (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
        rfl rfl (by simp [intExprOps]) ?_
      set mF := H3a.wWrite mL engScrTbl 10 1
      have hw9_F : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead mL t i :=
        fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
      have hadv_c2 : advRes = Sum.inr (jb.ready, cs'.snapArr, false) := by
        rw [hadv_eq, if_neg hstill, if_pos hsmall]
      have hall_eq : (List.finRange cp.D_max).flatMap (fun r' =>
          jobUsedSlots (Function.update curJobs r (some jb_copy') r')
            (Function.update readySlots r (readySlots r) r')
            (Function.update curSlots r (curSlots r) r')) =
          (List.finRange cp.D_max).flatMap (fun r' =>
            jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) := by
        congr 1; ext r'
        by_cases heq : r' = r
        · subst heq; simp [Function.update_self, hcur_r, jb_copy', jobUsedSlots, hphase]
        · simp [Function.update_of_ne heq]
      have henc_r_F : EncJobSlot ops r (some jb_copy') (readySlots r) (curSlots r) mF :=
        encJobSlot_ext henc_jb_copy'_mL (fun _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun mn' s he => ops.encNode_ext mn' s mL mF he hw9_F
            (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
      refine ⟨ops.slotsReady_ext mL mF hsrL hw9_F (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
        fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans (hftL t ht9 ht1 ht2 ht3 i),
        fun i hni => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hfmL_job i hni),
        fun i hni => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hfaL_job i hni),
        fun i hi10 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hfsL i (by omega)),
        fun t ht2 i => (rRead_wWrite _ _ _ _ _ _).trans (hfrL t (by omega) i),
        (rRead_wWrite _ _ _ _ _ _).trans (hfrL engRealTbl (by decide) 0),
        fun mn' s hs _ he0 => ops.encNode_ext mn' s mL mF (hndL mn' s hs he0)
          hw9_F (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
        jb_copy', readySlots r, curSlots r, henc_r_F,
        fun r' => by
          simp only [Function.update_eq_self]
          exact encJobSlot_ext (hjobs_mL r') (fun _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
            (fun _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
            (fun mn' s he => ops.encNode_ext mn' s mL mF he hw9_F
              (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)),
        by rwa [hall_eq],
        by rwa [hall_eq],
        ?_⟩
      rw [hadv_c2]
      refine ⟨rfl, rfl, hr_len, henc_r_F.2.2.2.1, henc_r_F.2.2.2.2.1,
        Or.inl ⟨wRead_wWrite_self _ _ _ _, rfl,
          hsnapL.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
            (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
            (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))⟩⟩
    · -- Case C3: `cp.B_scan < cs'.snapArr.length` -> `tickJobCopyOpenBuildStmt ops r`!
      have hcondC2 : (evalArithCond inp 0 mL
          (.intLe (.readHeap engMetaTbl (.lit (base + 5))) (.lit (cp.B_scan : ℤ)))).1 = false := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mL engMetaTbl (base + 5) ≤ (cp.B_scan : ℤ)) = false
        rw [hsnapL.2.2.1]; exact decide_eq_false (by intro hc; apply hsmall; exact_mod_cast hc)
      refine ExecDet.ite' (C_c := 12) (C_b := allocFreshSlotCost cp + ops.C_hpj + ops.C_open + 176) _ _ _ hcondC2
        (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
        (by clear * -; nlinarith)
      unfold tickJobCopyOpenBuildStmt
      let curJobsL := Function.update curJobs r (some jb_copy')
      have hall_eq_L : (List.finRange cp.D_max).flatMap
          (fun r' => jobUsedSlots (curJobsL r') (readySlots r') (curSlots r')) =
          (List.finRange cp.D_max).flatMap
          (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) := by
        congr 1; ext r'
        by_cases heq : r' = r
        · subst heq; simp [curJobsL, hcur_r, jb_copy', jobUsedSlots, hphase]
        · simp [curJobsL, Function.update_of_ne heq]
      have hmeta0_L : wRead mL engMetaTbl 0 = (servLen : ℤ) :=
        (hfmL 0 (by simp only [base, jobMetaBase]; omega) (by simp only [base, jobMetaBase]; omega)).trans hmeta0
      have hserv_slots_L : ∀ i (his : i < servSlots.length),
          wRead mL engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ) := by
        intro i his
        have hi_D : i < cp.D_max := lt_of_lt_of_le (hslen ▸ his) hserv_le
        exact (hfmL _ (by simp only [base, servSlotOff, jobMetaBase]; omega)
          (by simp only [base, servSlotOff, jobMetaBase]; omega)).trans (hserv_slots i his)
      -- 1. `allocFreshSlotStmt cp`
      refine ExecDet.seq' (ops.C_hpj + ops.C_open + 176)
        (exec_allocFreshSlotStmt ops inp hfpL hsrL hserv_le hslen hmeta0_L
          hserv_slots_L hjobs_mL (by rwa [hall_eq_L]))
        (by clear * -; nlinarith) ?_
      intro mA ⟨hsrA, ⟨newCSlot, hns_M, hns_not_L, hw39_A⟩, hndA, hftA, hfsA, hfrA⟩ hfpA
      rw [hall_eq_L] at hns_not_L
      -- 2. Write `21, 22, 26` for `evalHPJCenterStmt`
      let ctrCoinOff : ℕ := cp.B_S1 + cp.N_op_s2 * cp.B_op + r.val * cp.B_ctr
      obtain ⟨ctrBits, hctr_eq, hctr_bnd, hctr_rd⟩ :=
        memHasStepCoins_stage2_ctr cp bits m₀ hcoins r.castSucc
      have hctrSeed_eq : ctrSeed = bitsToCenterSeedEquiv cp ctrBits := hctr_eq
      refine ExecDet.seq' (ops.C_hpj + ops.C_open + 164)
        (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 21) (.lit (snapElemOff cp r.val))
          21 (snapElemOff cp r.val) hfpA (by unfold engScrTbl; omega) (by omega)
          (by unfold M_slots at hBW_scr; omega) rfl rfl (by simp [intExprOps]) rfl)
        (by clear * -; nlinarith) ?_
      intro mA1 hmA1 hfpA1; subst hmA1
      refine ExecDet.seq' (ops.C_hpj + ops.C_open + 152)
        (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 22) (.readHeap engMetaTbl (.lit (base + 5)))
          22 (cs'.snapArr.length : ℤ) hfpA1 (by unfold engScrTbl; omega) (by omega)
          (by unfold M_slots at hBW_scr; omega) rfl
          (by simp only [evalIntExpr]
              change wRead (H3a.wWrite mA engScrTbl 21 (snapElemOff cp r.val)) engMetaTbl (base + 5) = _
              rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hftA engMetaTbl (by decide) _]
              exact hsnapL.2.2.1)
          (by simp [intExprOps]) rfl)
        (by clear * -; nlinarith) ?_
      intro mA2 hmA2 hfpA2; subst hmA2
      refine ExecDet.seq' (ops.C_hpj + ops.C_open + 140)
        (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 26) (.lit (ctrCoinOff : ℤ))
          26 (ctrCoinOff : ℤ) hfpA2 (by unfold engScrTbl; omega) (by omega)
          (by unfold M_slots at hBW_scr; omega) rfl rfl (by simp [intExprOps]) rfl)
        (by clear * -; nlinarith) ?_
      intro mA3 hmA3 hfpA3; subst hmA3
      set mP := H3a.wWrite (H3a.wWrite (H3a.wWrite mA engScrTbl 21 (snapElemOff cp r.val))
        engScrTbl 22 (cs'.snapArr.length : ℤ)) engScrTbl 26 (ctrCoinOff : ℤ)
      have hw9_PA : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mP t i = wRead mA t i := by
        intro t ht9 _ i; simp only [mP, wRead_wWrite_eq]
        have : t ≠ engScrTbl := by unfold engScrTbl; omega
        simp [this]
      have hlen_pos : 1 ≤ cs'.snapArr.length := by have := cp.B_scan_bounds.1; omega
      have hlen_n : cs'.snapArr.length ≤ cp.n := hsnapL.length_le
      have hsnap_arr_BW : snapElemOff cp r.val + (cs'.snapArr.length : ℤ) ≤ (ops.BW : ℤ) := by
        have hr_lt := r.isLt
        have h1 : (2 + 4 * r.val) * S_stride cp + cp.n ≤ ops.BW := by
          have ha : (3 + 4 * r.val) * S_stride cp ≤ (2 + 4 * cp.D_max) * S_stride cp :=
            Nat.mul_le_mul_right _ (by omega)
          have hb : cp.n ≤ S_stride cp := by unfold S_stride; omega
          nlinarith only [ha, hb, hBW_arr]
        unfold snapElemOff; omega
      -- 3. `ops.evalHPJCenterStmt engArrTbl 21 22 26`
      refine ExecDet.seq' (ops.C_open + 140)
        (ops.evalHPJCenter_spec inp mP pts cs'.snapArr engArrTbl (snapElemOff cp r.val)
          ctrCoinOff ctrBits 21 22 26
          (by decide) hlen_pos hlen_n
          (fun x hx => hTend_n x (hsnap_Tend ▸ List.mem_toFinset.mpr hx))
          (by unfold snapElemOff; omega) hsnap_arr_BW hctr_bnd
          (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
          hfpA3
          (ops.slotsReady_ext mA mP hsrA hw9_PA (fun _ _ _ _ => by simp [mP, rRead_wWrite]))
          (by simp [mP, wRead_wWrite_eq])
          (by simp [mP, wRead_wWrite_eq])
          (by simp [mP, wRead_wWrite_eq])
          (fun i hi => by
            simp only [mP, wRead_wWrite_eq]; simp [engArrTbl, engScrTbl]
            exact (hftA engArrTbl (by decide) _).trans (hsnapL.2.2.2 i hi).1)
          (fun x hx c => by
            simp only [mP, rRead_wWrite]
            exact (hfrA ptsRTbl _).trans ((hfrL ptsRTbl (by decide) _).trans
              (hact_pts x (hTend_sub (hsnap_Tend ▸ List.mem_toFinset.mpr hx)) c)))
          (fun k => by
            simp only [mP, wRead_wWrite_eq]; simp [coinTbl, engScrTbl]
            exact (hftA coinTbl (by decide) _).trans
              ((hftL coinTbl (by decide) (by decide) (by decide) (by decide) _).trans (hctr_rd k))))
        (by clear * -; nlinarith) ?_
      intro mH ⟨hsrH, hoH, hsH, hndH, hftH, hfrH, hr20H⟩ hfpH
      let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts cs'.snapArr ctrSeed
      have hos_eq : evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts cs'.snapArr
          (bitsToCenterSeedEquiv cp ctrBits) = os := by dsimp [os]; rw [hctrSeed_eq]
      rw [hos_eq] at hoH hsH
      -- 4. `ops.openEmptyStmt 39 22`
      let P₀_uid := cs'.snapArr.toFinset.image gt.uidOf
      let bs_new := BuildState.init cp cs'.L_hist cs'.snapArr os.1 os.2 P₀_uid
      have hr39_H : wRead mH engScrTbl 39 = (newCSlot : ℤ) := by
        rw [hftH engScrTbl (by decide) 39]; simp only [mP, wRead_wWrite_eq]; simp [hw39_A]
      have hr22_H : wRead mH engScrTbl 22 = (cs'.snapArr.length : ℤ) := by
        rw [hftH engScrTbl (by decide) 22]; simp [mP, wRead_wWrite_eq]
      refine ExecDet.seq' 140
        (ops.openEmpty_spec inp mH newCSlot cs'.snapArr.length os.1 os.2 P₀_uid 39 22
          hns_M hlen_n (by omega) (by omega) (by omega) (by omega)
          hfpH hsrH hr39_H hr22_H hoH hsH)
        (by clear * -; nlinarith) ?_
      intro mO ⟨hsrO, henc_bsO, hndO, hftO, hfrO⟩ hfpO
      have henc_bsO' : ops.EncNode bs_new.curNode newCSlot mO := henc_bsO
      -- 5. Write `base+2 := 1, base+4 := 0, base+6 := 0, base+7 := engScrTbl[39], engScrTbl[10] := 0`
      have hr39_O : wRead mO engScrTbl 39 = (newCSlot : ℤ) :=
        (hftO engScrTbl (by decide) 39).trans hr39_H
      refine ExecDet.seq' 120
        (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 2)) (.lit 1)
          (base + 2) 1 hfpO (by unfold engMetaTbl; omega) (by simp only [base, jobMetaBase]; omega)
          (by simp only [base, jobMetaBase]; omega) rfl rfl (by simp [intExprOps]) rfl) (by omega) ?_
      intro mO1 hmO1 hfpO1; subst hmO1
      refine ExecDet.seq' 100
        (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 4)) (.lit 0)
          (base + 4) 0 hfpO1 (by unfold engMetaTbl; omega) (by simp only [base, jobMetaBase]; omega)
          (by simp only [base, jobMetaBase]; omega) rfl rfl (by simp [intExprOps]) rfl) (by omega) ?_
      intro mO2 hmO2 hfpO2; subst hmO2
      refine ExecDet.seq' 80
        (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 6)) (.lit 0)
          (base + 6) 0 hfpO2 (by unfold engMetaTbl; omega) (by simp only [base, jobMetaBase]; omega)
          (by simp only [base, jobMetaBase]; omega) rfl rfl (by simp [intExprOps]) rfl) (by omega) ?_
      intro mO3 hmO3 hfpO3; subst hmO3
      refine ExecDet.seq' 50
        (ExecDet.wWrite (C := 16) inp engMetaTbl (.lit (base + 7)) (.readHeap engScrTbl (.lit 39))
          (base + 7) (newCSlot : ℤ) hfpO3 (by unfold engMetaTbl; omega)
          (by simp only [base, jobMetaBase]; omega) (by simp only [base, jobMetaBase]; omega) rfl
          (by simp only [evalIntExpr]
              change wRead _ engScrTbl 39 = _
              simp only [wRead_wWrite_eq]
              simp [engScrTbl, engMetaTbl, hr39_O])
          (by simp [intExprOps]) rfl) (by omega) ?_
      intro mO4 hmO4 hfpO4; subst hmO4
      refine ExecDet.wWrite inp engScrTbl (.lit 10) (.lit 0) 10 0
        hfpO4 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
        rfl rfl (by simp [intExprOps]) ?_
      set mF := H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite mO
        engMetaTbl (base + 2) 1) engMetaTbl (base + 4) 0) engMetaTbl (base + 6) 0)
        engMetaTbl (base + 7) (newCSlot : ℤ)) engScrTbl 10 0
      have hw9_FO : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead mO t i := by
        intro t ht9 _ i; simp only [mF, base, wRead_wWrite_eq]
        have : t ≠ engScrTbl ∧ t ≠ engMetaTbl := ⟨by unfold engScrTbl; omega, by unfold engMetaTbl; omega⟩
        simp [this]
      have hr_FO : ∀ t i, rRead mF t i = rRead mO t i := by intro t i; simp [mF, rRead_wWrite]
      have hw_lt8_OL : ∀ t < 8, ∀ i, wRead mO t i = wRead mL t i := by
        intro t ht8 i
        rw [hftO t (by omega) i, hftH t (by omega) i]
        simp only [mP, wRead_wWrite_eq]
        have : t ≠ engScrTbl := by unfold engScrTbl; omega
        simp [this, hftA t (by unfold engScrTbl; omega) i]
      have hscr10_OL : ∀ i, i < 10 → wRead mO engScrTbl i = wRead mL engScrTbl i := by
        intro i hi10
        rw [hftO engScrTbl (by decide) i, hftH engScrTbl (by decide) i]
        simp only [mP, wRead_wWrite_eq]
        have : i ≠ 26 ∧ i ≠ 22 ∧ i ≠ 21 := by omega
        simp [this, hfsA i (by omega)]
      have hnd_other_FO : ∀ mn' s, s < M_slots cp → s ≠ newCSlot →
          ops.EncNode mn' s m₀ → ops.EncNode mn' s mF := by
        intro mn' s hs hne he0
        have heA : ops.EncNode mn' s mA := hndA mn' s hs (hndL mn' s hs he0)
        have heP : ops.EncNode mn' s mP := ops.encNode_ext mn' s mA mP heA hw9_PA
          (fun _ _ _ _ => by simp [mP, rRead_wWrite]) (fun _ _ _ _ => by simp [mP, rRead_wWrite])
        have heO : ops.EncNode mn' s mO := hndO mn' s hs hne (hndH mn' s hs heP)
        exact ops.encNode_ext mn' s mO mF heO hw9_FO (fun t _ _ i => hr_FO t i) (fun _ _ _ _ => hr_FO ptsRTbl _)
      let jb_build : SuffixJob cp := { ready := jb.ready, phase := .build bs_new }
      have hadv_c3 : advRes = Sum.inl jb_build := by
        rw [hadv_eq, if_neg hstill, if_neg hsmall]
      have hfmF_job : ∀ i, ¬ InJobMetaRegion cp r.val i → wRead mF engMetaTbl i = wRead m₀ engMetaTbl i := by
        intro i hni
        have hnb : ¬ (base ≤ i ∧ i < base + 8) := fun hb => hni (Or.inl hb)
        simp only [mF, base, wRead_wWrite_eq]
        have : i ≠ base + 7 ∧ i ≠ base + 6 ∧ i ≠ base + 4 ∧ i ≠ base + 2 := by omega
        simp [base, engMetaTbl, engScrTbl, this, (hw_lt8_OL engMetaTbl (by decide) i).trans (hfmL_job i hni)]
      have hfaF_job : ∀ i, ¬ InJobArrRegion cp r.val i → wRead mF engArrTbl i = wRead m₀ engArrTbl i := by
        intro i hni
        simp only [mF, base, wRead_wWrite_eq]; simp [engArrTbl, engMetaTbl, engScrTbl]
        exact (hw_lt8_OL engArrTbl (by decide) i).trans (hfaL_job i hni)
      have henc_jb_build_F : EncJobSlot ops r (some jb_build) (readySlots r) newCSlot mF := by
        simp only [EncJobSlot, jb_build]
        refine ⟨?_, hr_le, hr_len, ?_, fun q hq hqs => ?_,
          by simp [mF, base, wRead_wWrite_eq, engMetaTbl, engScrTbl],
          ?_,
          by simp [mF, base, wRead_wWrite_eq, engMetaTbl, engScrTbl, bs_new, BuildState.init],
          ?_,
          encSparseSet_empty_of_zero (by simp [mF, base, wRead_wWrite_eq, engMetaTbl, engScrTbl]),
          by simp [mF, base, wRead_wWrite_eq, engMetaTbl, engScrTbl],
          ops.encNode_ext _ newCSlot mO mF henc_bsO' hw9_FO
            (fun t _ _ i => hr_FO t i) (fun _ _ _ _ => hr_FO ptsRTbl _)⟩
        · simp only [mF, base, wRead_wWrite_eq]
          have : base ≠ base + 7 ∧ base ≠ base + 6 ∧ base ≠ base + 4 ∧ base ≠ base + 2 := by omega
          simp [base, engMetaTbl, engScrTbl, this]
          exact (hw_lt8_OL engMetaTbl (by decide) base).trans ((hfmL base (by omega) (by omega)).trans hact1)
        · simp only [mF, base, wRead_wWrite_eq]
          have : base + 1 ≠ base + 7 ∧ base + 1 ≠ base + 6 ∧ base + 1 ≠ base + 4 ∧ base + 1 ≠ base + 2 := by omega
          simp [base, engMetaTbl, engScrTbl, this]
          exact (hw_lt8_OL engMetaTbl (by decide) (base + 1)).trans ((hfmL (base + 1) (by omega) (by omega)).trans hw_rlen)
        · have hnn_rD : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) := by exact_mod_cast Nat.zero_le (r.val * cp.D_max)
          have hrd_out : ¬ (base ≤ readySlotOff cp r.val q ∧ readySlotOff cp r.val q < base + 8) := by
            have := r.isLt; simp only [base, readySlotOff, jobMetaBase]; omega
          have hq_in_all : (readySlots r)[q]'hqs ∈ servSlots ++ (List.finRange cp.D_max).flatMap
              (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) :=
            List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, by
              simp only [hcur_r, jobUsedSlots, hphase]; exact List.getElem_mem hqs⟩)
          have hq_ne_ns : (readySlots r)[q]'hqs ≠ newCSlot := fun heq => hns_not_L (heq ▸ hq_in_all)
          refine ⟨?_, hnd_other_FO _ _ (hall_lt _ hq_in_all) hq_ne_ns (hready_enc q hq hqs).2⟩
          simp only [mF, base, wRead_wWrite_eq]
          have : readySlotOff cp r.val q ≠ base + 7 ∧ readySlotOff cp r.val q ≠ base + 6 ∧
                 readySlotOff cp r.val q ≠ base + 4 ∧ readySlotOff cp r.val q ≠ base + 2 := by omega
          simp [base, engMetaTbl, engScrTbl, this]
          exact (hw_lt8_OL engMetaTbl (by decide) _).trans
            ((hfmL _ (by omega) (by omega)).trans (hready_enc q hq hqs).1)
        · dsimp only [bs_new, BuildState.init]
          simp only [mF, base, wRead_wWrite_eq]
          have : base + 3 ≠ base + 7 ∧ base + 3 ≠ base + 6 ∧ base + 3 ≠ base + 4 ∧ base + 3 ≠ base + 2 := by omega
          simp [base, engMetaTbl, engScrTbl, this]
          exact (hw_lt8_OL engMetaTbl (by decide) (base + 3)).trans hwLL
        · dsimp only [bs_new, BuildState.init]
          refine hsnapL.ext ?_ (fun _ _ => ?_) (fun _ _ => ?_)
          · simp only [mF, base, wRead_wWrite_eq]
            have : base + 5 ≠ base + 7 ∧ base + 5 ≠ base + 6 ∧ base + 5 ≠ base + 4 ∧ base + 5 ≠ base + 2 := by omega
            simp [base, engMetaTbl, engScrTbl, this]
            exact hw_lt8_OL engMetaTbl (by decide) (base + 5)
          · simp only [mF, base, wRead_wWrite_eq]; simp [engArrTbl, engMetaTbl, engScrTbl]
            exact hw_lt8_OL engArrTbl (by decide) _
          · simp only [mF, base, wRead_wWrite_eq]; simp [engArrTbl, engMetaTbl, engScrTbl]
            exact hw_lt8_OL engArrTbl (by decide) _
      have hall_new := allSlots_nodup_update_append_fresh (D := cp.D_max) (M := M_slots cp)
        (servSlots := servSlots)
        (U := fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r'))
        (U' := fun r' => jobUsedSlots
          (Function.update curJobs r (some jb_build) r')
          (Function.update readySlots r (readySlots r) r')
          (Function.update curSlots r newCSlot r'))
        r hall_nd hall_lt hns_M hns_not_L
        (fun r' hne => by simp [Function.update_of_ne hne])
        (by simp [hcur_r, jb_build, jobUsedSlots, hphase])
      refine ⟨ops.slotsReady_ext mO mF hsrO hw9_FO (fun t _ _ i => hr_FO t i),
        fun t ht9 ht1 ht2 ht3 i => by
          have ht8 : t < 8 := by unfold engScrTbl at ht3; omega
          simp only [mF, base, wRead_wWrite_eq]; simp [ht1, ht3]
          exact (hw_lt8_OL t ht8 i).trans (hftL t ht9 ht1 ht2 ht3 i),
        hfmF_job, hfaF_job,
        fun i hi10 => by
          simp only [mF, base, wRead_wWrite_eq]
          have : i ≠ 10 := by omega
          simp [engScrTbl, engMetaTbl, this]
          exact (hscr10_OL i hi10).trans (hfsL i (by omega)),
        fun t ht2 i => (hr_FO t i).trans ((hfrO t (by omega) i).trans
          ((hfrH t ht2 i).trans (by simp only [mP, rRead_wWrite]; exact (hfrA t i).trans (hfrL t (by omega) i)))),
        (hr_FO engRealTbl 0).trans ((hfrO engRealTbl (by decide) 0).trans
          (hr20H.trans (by simp only [mP, rRead_wWrite]; exact (hfrA engRealTbl 0).trans (hfrL engRealTbl (by decide) 0)))),
        fun mn' s hs hmem_other he0 => by
          have hmem_all : s ∈ servSlots ++ (List.finRange cp.D_max).flatMap
              (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) := by
            rcases List.mem_append.mp hmem_other with hs1 | hs2
            · exact List.mem_append_left _ hs1
            · rcases flatMap_mem_iff_finRange.mp hs2 with ⟨r', hr'⟩
              by_cases heq : r' = r
              · subst heq; simp at hr'
              · simp only [if_neg heq] at hr'
                exact List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r', hr'⟩)
          exact hnd_other_FO mn' s hs (fun heq => hns_not_L (heq ▸ hmem_all)) he0,
        jb_build, readySlots r, newCSlot, henc_jb_build_F,
        fun r' => by
          simp only [Function.update_eq_self]
          by_cases heq : r' = r
          · subst heq; simpa using henc_jb_build_F
          · simp only [Function.update_of_ne heq]
            exact encJobSlot_other_of_frame heq (hjobs_enc r')
              (fun s hs => hall_lt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r', hs⟩)))
              hfmF_job hfaF_job (fun mn' s hs hmem_r' he0 =>
                hnd_other_FO mn' s hs (fun hns_eq => hns_not_L
                  (hns_eq ▸ List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r', hmem_r'⟩))) he0),
        hall_new.1, hall_new.2,
        by rw [hadv_c3]; exact ⟨wRead_wWrite_self _ _ _ _, rfl⟩⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
