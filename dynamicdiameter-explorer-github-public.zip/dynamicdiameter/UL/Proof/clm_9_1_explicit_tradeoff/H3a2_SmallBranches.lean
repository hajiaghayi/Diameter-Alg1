import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H3a2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a

/-! ### 1. Footprint-preserving `StepFP` & existential `ExecDet` Hoare combinators -/

def StepFP {d : ℕ} (TW BW TR BR : ℕ) (inp : ArithRAMInput d) (s : ArithRAMStmt)
    (m₀ m₁ : ArithRAMMemory) (r₀ r₁ : List Bool) (C : ℕ) : Prop :=
  InFootprint TW BW TR BR m₁ ∧
  StepTo inp s m₀ m₁ r₀ r₁ C (TW * BW + TR * BR)

theorem StepFP.mono {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {m₀ m₁ : ArithRAMMemory} {r₀ r₁ : List Bool} {C C' : ℕ}
    (h : StepFP TW BW TR BR inp s m₀ m₁ r₀ r₁ C) (hC : C ≤ C') :
    StepFP TW BW TR BR inp s m₀ m₁ r₀ r₁ C' :=
  ⟨h.1, h.2.mono hC le_rfl⟩

theorem StepFP.seq {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d} {s₁ s₂ : ArithRAMStmt}
    {m₀ m₁ m₂ : ArithRAMMemory} {r₀ r₁ r₂ : List Bool} {C₁ C₂ : ℕ}
    (h₁ : StepFP TW BW TR BR inp s₁ m₀ m₁ r₀ r₁ C₁)
    (h₂ : StepFP TW BW TR BR inp s₂ m₁ m₂ r₁ r₂ C₂) :
    StepFP TW BW TR BR inp (.seq s₁ s₂) m₀ m₂ r₀ r₂ (C₁ + C₂) :=
  ⟨h₂.1, h₁.2.seq h₂.2⟩

/-- Existential deterministic Hoare triple preserving `InFootprint TW BW TR BR`. -/
def ExecDet {d : ℕ} (TW BW TR BR : ℕ) (inp : ArithRAMInput d) (s : ArithRAMStmt)
    (m₀ : ArithRAMMemory) (Post : ArithRAMMemory → Prop) (C : ℕ) : Prop :=
  ∃ m₁, Post m₁ ∧ StepFP TW BW TR BR inp s m₀ m₁ [] [] C

theorem ExecDet.mono {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {m₀ : ArithRAMMemory} {P Q : ArithRAMMemory → Prop} {C C' : ℕ}
    (h : ExecDet TW BW TR BR inp s m₀ P C)
    (hPQ : ∀ m, P m → InFootprint TW BW TR BR m → Q m) (hC : C ≤ C') :
    ExecDet TW BW TR BR inp s m₀ Q C' := by
  obtain ⟨m₁, hp, hfp⟩ := h
  exact ⟨m₁, hPQ m₁ hp hfp.1, hfp.mono hC⟩

theorem ExecDet.skip {d : ℕ} {TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hfp : InFootprint TW BW TR BR m₀) (hP : Post m₀) (hC : 1 ≤ C) :
    ExecDet TW BW TR BR inp .skip m₀ Post C :=
  ⟨m₀, hP, hfp, (StepTo.skip inp [] hfp.1 hfp.cellCount_le).mono hC le_rfl⟩

theorem ExecDet.seq {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d} {s₁ s₂ : ArithRAMStmt}
    {m₀ : ArithRAMMemory} {Mid Post : ArithRAMMemory → Prop} {C₁ C₂ : ℕ}
    (h₁ : ExecDet TW BW TR BR inp s₁ m₀ Mid C₁)
    (h₂ : ∀ m₁, Mid m₁ → InFootprint TW BW TR BR m₁ → ExecDet TW BW TR BR inp s₂ m₁ Post C₂) :
    ExecDet TW BW TR BR inp (.seq s₁ s₂) m₀ Post (C₁ + C₂) := by
  obtain ⟨m₁, hmid, hfp₁⟩ := h₁
  obtain ⟨m₂, hpost, hfp₂⟩ := h₂ m₁ hmid hfp₁.1
  exact ⟨m₂, hpost, hfp₁.seq hfp₂⟩

theorem ExecDet.seq' {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d} {s₁ s₂ : ArithRAMStmt}
    {m₀ : ArithRAMMemory} {Mid Post : ArithRAMMemory → Prop} {C₁ : ℕ} (C₂ : ℕ) {C : ℕ}
    (h₁ : ExecDet TW BW TR BR inp s₁ m₀ Mid C₁)
    (hC : C₁ + C₂ ≤ C)
    (h₂ : ∀ m₁, Mid m₁ → InFootprint TW BW TR BR m₁ → ExecDet TW BW TR BR inp s₂ m₁ Post C₂) :
    ExecDet TW BW TR BR inp (.seq s₁ s₂) m₀ Post C :=
  (h₁.seq h₂).mono (fun _ hm _ => hm) hC

theorem ExecDet.wWrite {d : ℕ} {TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (tbl : ℕ) (idxE valE : IntExpr) (idx val : ℤ)
    {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : tbl < TW) (hi0 : 0 ≤ idx) (hiB : idx < (BW : ℤ))
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hval : (evalIntExpr inp.toWordView 0 m₀.words valE).1 = val)
    (hcost : intExprOps idxE + intExprOps valE + 1 ≤ C)
    (hPost : Post (H3a.wWrite m₀ tbl idx val)) :
    ExecDet TW BW TR BR inp (.writeWordHeap tbl idxE valE) m₀ Post C := by
  have hfp₁ : InFootprint TW BW TR BR (H3a.wWrite m₀ tbl idx val) :=
    hfp₀.wWrite htbl hi0 hiB
  exact ⟨_, hPost, hfp₁, StepTo.wWrite inp [] tbl idxE valE idx val hidx hval hcost hfp₁.1 hfp₁.cellCount_le⟩

theorem ExecDet.rWrite {d : ℕ} {TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (tbl : ℕ) (idxE : IntExpr) (valE : RealExpr) (idx : ℤ) (val : ℝ)
    {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : tbl < TR) (hi0 : 0 ≤ idx) (hiB : idx < (BR : ℤ))
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hval : (evalRealExpr inp 0 m₀ valE).1 = val)
    (hcost : intExprOps idxE + realExprOps valE + 1 ≤ C)
    (hPost : Post (H3a.rWrite m₀ tbl idx val)) :
    ExecDet TW BW TR BR inp (.writeRealHeap tbl idxE valE) m₀ Post C := by
  have hfp₁ : InFootprint TW BW TR BR (H3a.rWrite m₀ tbl idx val) :=
    hfp₀.rWrite htbl hi0 hiB
  exact ⟨_, hPost, hfp₁, StepTo.rWrite inp [] tbl idxE valE idx val hidx hval hcost hfp₁.1 hfp₁.cellCount_le⟩

theorem ExecDet.wWriteEq {d : ℕ} {TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (tbl : ℕ) (idxE valE : IntExpr) (idx val : ℤ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : tbl < TW) (hi0 : 0 ≤ idx) (hiB : idx < (BW : ℤ))
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hval : (evalIntExpr inp.toWordView 0 m₀.words valE).1 = val)
    (hcost : intExprOps idxE + intExprOps valE + 1 ≤ 12) :
    ExecDet TW BW TR BR inp (.writeWordHeap tbl idxE valE) m₀
      (fun m => m = H3a.wWrite m₀ tbl idx val) 12 :=
  ExecDet.wWrite inp tbl idxE valE idx val hfp₀ htbl hi0 hiB hidx hval hcost rfl

theorem ExecDet.ite {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (cond : ArithCondExpr) (tB fB : ArithRAMStmt)
    {m₀ : ArithRAMMemory} {Post : ArithRAMMemory → Prop} {C_c C_b : ℕ}
    (huc : condExprOps cond ≤ C_c)
    (ht : (evalArithCond inp 0 m₀ cond).1 = true → ExecDet TW BW TR BR inp tB m₀ Post C_b)
    (hf : (evalArithCond inp 0 m₀ cond).1 = false → ExecDet TW BW TR BR inp fB m₀ Post C_b) :
    ExecDet TW BW TR BR inp (.ite cond tB fB) m₀ Post (C_c + C_b) := by
  cases hc : (evalArithCond inp 0 m₀ cond).1
  · obtain ⟨m₁, hp, hfp₁, hst⟩ := hf hc
    exact ⟨m₁, hp, hfp₁, StepTo.ite_false cond tB fB hc huc hst⟩
  · obtain ⟨m₁, hp, hfp₁, hst⟩ := ht hc
    exact ⟨m₁, hp, hfp₁, StepTo.ite_true cond tB fB hc huc hst⟩

open Classical in
theorem ExecDet.forN {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (N : ℕ) (body : ArithRAMStmt) {m₀ : ArithRAMMemory}
    (Inv : ℕ → ArithRAMMemory → Prop) (C_b : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀) (hInv₀ : Inv 0 m₀)
    (hbody : ∀ i < N, ∀ m, Inv i m → InFootprint TW BW TR BR m →
      ExecDet TW BW TR BR inp body m (Inv (i + 1)) C_b) :
    ExecDet TW BW TR BR inp (.repeatN (.lit (N : ℤ)) body) m₀ (Inv N) (1 + N * C_b) := by
  let stepFn : ∀ (i : ℕ) (m : ArithRAMMemory), ArithRAMMemory := fun i m =>
    if h : i < N ∧ Inv i m ∧ InFootprint TW BW TR BR m then
      Classical.choose (hbody i h.1 m h.2.1 h.2.2)
    else m
  let mSeq : ℕ → ArithRAMMemory := fun k => Nat.recOn k m₀ stepFn
  have hmSeq_props : ∀ k ≤ N, Inv k (mSeq k) ∧ InFootprint TW BW TR BR (mSeq k) ∧
      (∀ i < k, StepFP TW BW TR BR inp body (mSeq i) (mSeq (i + 1)) [] [] C_b) := by
    intro k
    induction k with
    | zero =>
      intro _
      exact ⟨hInv₀, hfp₀, fun _ hi => absurd hi (Nat.not_lt_zero _)⟩
    | succ k ih =>
      intro hk_le
      obtain ⟨hIk, hfpk, hprev⟩ := ih (by omega)
      have hk_lt : k < N := by omega
      have hcond : k < N ∧ Inv k (mSeq k) ∧ InFootprint TW BW TR BR (mSeq k) := ⟨hk_lt, hIk, hfpk⟩
      have hnext_eq : mSeq (k + 1) = Classical.choose (hbody k hk_lt (mSeq k) hIk hfpk) := by
        show stepFn k (mSeq k) = _
        dsimp only [stepFn]
        rw [dif_pos hcond]
      obtain ⟨hIk1, hfp_step⟩ := Classical.choose_spec (hbody k hk_lt (mSeq k) hIk hfpk)
      rw [← hnext_eq] at hIk1 hfp_step
      refine ⟨hIk1, hfp_step.1, fun i hi => ?_⟩
      rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
      · exact hprev i hlt
      · exact hfp_step
  obtain ⟨hIN, hfpN, hsteps⟩ := hmSeq_props N le_rfl
  refine ⟨mSeq N, hIN, hfpN, ?_⟩
  exact StepTo.repeatN (.lit (N : ℤ)) body N 1 C_b (TW * BW + TR * BR) mSeq (fun _ => [])
    hfp₀.1 hfp₀.cellCount_le rfl le_rfl (fun i hi => (hsteps i hi).2)

/-- Indexed `for` loop storing loop index `0 .. N - 1` in `.heap ctrTbl ctrIdx`. -/
def forLoopStmt (ctrTbl : ℕ) (ctrIdx : ℤ) (N : ℕ) (body : ArithRAMStmt) : ArithRAMStmt :=
  .seq (.writeWordHeap ctrTbl (.lit ctrIdx) (.lit 0))
    (.repeatN (.lit (N : ℤ))
      (.seq body
        (.writeWordHeap ctrTbl (.lit ctrIdx)
          (.add (.readHeap ctrTbl (.lit ctrIdx)) (.lit 1)))))

theorem ExecDet.forLoop {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (ctrTbl : ℕ) (ctrIdx : ℤ) (N : ℕ) (body : ArithRAMStmt)
    {m₀ : ArithRAMMemory} (Inv : ℕ → ArithRAMMemory → Prop) (C_b : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hctrT : ctrTbl < TW) (hctr0 : 0 ≤ ctrIdx) (hctrB : ctrIdx < (BW : ℤ))
    (hInv₀ : Inv 0 (H3a.wWrite m₀ ctrTbl ctrIdx 0))
    (hbody : ∀ i < N, ∀ m, Inv i m → wRead m ctrTbl ctrIdx = (i : ℤ) →
      InFootprint TW BW TR BR m →
      ExecDet TW BW TR BR inp body m
        (fun m' => wRead m' ctrTbl ctrIdx = (i : ℤ) ∧
          Inv (i + 1) (H3a.wWrite m' ctrTbl ctrIdx ((i : ℤ) + 1))) C_b) :
    ExecDet TW BW TR BR inp (forLoopStmt ctrTbl ctrIdx N body) m₀ (Inv N)
      (4 + (1 + N * (C_b + 6))) := by
  unfold forLoopStmt
  let LoopInv : ℕ → ArithRAMMemory → Prop := fun i m =>
    Inv i m ∧ wRead m ctrTbl ctrIdx = (i : ℤ)
  have hinit : ExecDet TW BW TR BR inp (.writeWordHeap ctrTbl (.lit ctrIdx) (.lit 0))
      m₀ (LoopInv 0) 4 :=
    ExecDet.wWrite inp ctrTbl (.lit ctrIdx) (.lit 0) ctrIdx 0 hfp₀ hctrT hctr0 hctrB rfl rfl
      (by simp [intExprOps]) ⟨hInv₀, wRead_wWrite_self m₀ ctrTbl ctrIdx 0⟩
  refine ExecDet.seq hinit ?_
  intro m_init ⟨hI0, hread0⟩ hfp_init
  refine (ExecDet.forN N _ LoopInv (C_b + 6) hfp_init ⟨hI0, hread0⟩ ?_).mono
    (fun m hL _ => hL.1) le_rfl
  intro i hi m ⟨hIi, hri⟩ hfpm
  refine ExecDet.seq (hbody i hi m hIi hri hfpm) ?_
  intro m' ⟨hr', hI_next⟩ hfpm'
  refine ExecDet.wWrite inp ctrTbl (.lit ctrIdx)
    (.add (.readHeap ctrTbl (.lit ctrIdx)) (.lit 1)) ctrIdx ((i : ℤ) + 1)
    hfpm' hctrT hctr0 hctrB rfl ?_ (by simp [intExprOps]) ?_
  · simp [evalIntExpr, wRead] at hr' ⊢
    omega
  · refine ⟨hI_next, ?_⟩
    rw [wRead_wWrite_self]
    push_cast
    ring

/-! ### 2. Universal `drawCoinsStmt` exact-length & `StepFP` lemmas -/

theorem StepFP.drawCoins {d : ℕ} {TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (coinTbl scratchTbl B_coins : ℕ) (bits : Fin B_coins → Bool)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hcoinT : coinTbl < TW) (hscrT : scratchTbl < TW) (hneT : coinTbl ≠ scratchTbl)
    (hcoinB : B_coins ≤ BW) (hscrB : 1 ≤ BW) :
    ∃ m₁ : ArithRAMMemory,
      (∀ j : Fin B_coins, wRead m₁ coinTbl (j.val : ℤ) = if bits j then 1 else 0) ∧
      (∀ t i, t ≠ coinTbl → t ≠ scratchTbl → wRead m₁ t i = wRead m₀ t i) ∧
      (∀ t i, rRead m₁ t i = rRead m₀ t i) ∧
      StepFP TW BW TR BR inp (drawCoinsStmt coinTbl scratchTbl B_coins)
        m₀ m₁ (List.ofFn bits) [] (4 + (1 + B_coins * 10)) := by
  let mInit := H3a.wWrite m₀ scratchTbl 0 0
  let stepMem : ℕ → ArithRAMMemory → ArithRAMMemory := fun i m =>
    if hi : i < B_coins then
      let mA := H3a.wWrite m coinTbl (i : ℤ) (if bits ⟨i, hi⟩ then 1 else 0)
      H3a.wWrite mA scratchTbl 0 ((i : ℤ) + 1)
    else m
  let mSeq : ℕ → ArithRAMMemory := fun k => Nat.recOn k mInit stepMem
  let rSeq : ℕ → List Bool := fun k => (List.ofFn bits).drop k
  have hfp_init : InFootprint TW BW TR BR mInit :=
    hfp₀.wWrite hscrT le_rfl (by omega)
  have hmSeq_spec : ∀ k ≤ B_coins,
      InFootprint TW BW TR BR (mSeq k) ∧
      wRead (mSeq k) scratchTbl 0 = (k : ℤ) ∧
      (∀ j : Fin B_coins, j.val < k →
        wRead (mSeq k) coinTbl (j.val : ℤ) = if bits j then 1 else 0) ∧
      (∀ t i, t ≠ coinTbl → t ≠ scratchTbl → wRead (mSeq k) t i = wRead m₀ t i) ∧
      (∀ t i, rRead (mSeq k) t i = rRead m₀ t i) := by
    intro k
    induction k with
    | zero =>
      intro _
      refine ⟨hfp_init, wRead_wWrite_self _ _ _ _, fun j hj => absurd hj (Nat.not_lt_zero _),
        fun t i _ hts => wRead_wWrite_of_ne m₀ _ (Or.inl hts),
        fun t i => rfl⟩
    | succ k ih =>
      intro hk_le
      obtain ⟨hfpk, hscrk, hcoink, hotherk, hrealk⟩ := ih (by omega)
      have hk_lt : k < B_coins := by omega
      have hseq_eq : mSeq (k + 1) =
          H3a.wWrite (H3a.wWrite (mSeq k) coinTbl (k : ℤ) (if bits ⟨k, hk_lt⟩ then 1 else 0))
            scratchTbl 0 ((k : ℤ) + 1) := by
        show stepMem k (mSeq k) = _
        dsimp only [stepMem]
        rw [dif_pos hk_lt]
      rw [hseq_eq]
      have hfpA : InFootprint TW BW TR BR
          (H3a.wWrite (mSeq k) coinTbl (k : ℤ) (if bits ⟨k, hk_lt⟩ then 1 else 0)) :=
        hfpk.wWrite hcoinT (by omega) (by omega)
      have hfpB : InFootprint TW BW TR BR
          (H3a.wWrite (H3a.wWrite (mSeq k) coinTbl (k : ℤ) (if bits ⟨k, hk_lt⟩ then 1 else 0))
            scratchTbl 0 ((k : ℤ) + 1)) :=
        hfpA.wWrite hscrT le_rfl (by omega)
      refine ⟨hfpB, by rw [wRead_wWrite_self]; push_cast; ring, ?_, ?_, fun _ _ => hrealk _ _⟩
      · intro j hj
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneT)]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hj with hlt | heq
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          exact hcoink j hlt
        · have hjeq : j = ⟨k, hk_lt⟩ := Fin.ext heq
          subst hjeq
          exact wRead_wWrite_self _ _ _ _
      · intro t i htc hts
        rw [wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_wWrite_of_ne _ _ (Or.inl htc)]
        exact hotherk t i htc hts
  obtain ⟨hfpN, _, hcoinN, hotherN, hrealN⟩ := hmSeq_spec B_coins le_rfl
  refine ⟨mSeq B_coins, fun j => hcoinN j j.isLt, hotherN, hrealN, hfpN, ?_⟩
  unfold drawCoinsStmt
  have h1 : StepTo inp (.writeWordHeap scratchTbl (.lit 0) (.lit 0)) m₀ mInit
      (List.ofFn bits) (rSeq 0) 4 (TW * BW + TR * BR) :=
    StepTo.wWrite inp (List.ofFn bits) scratchTbl (.lit 0) (.lit 0) 0 0 rfl rfl (by simp [intExprOps])
      hfp_init.1 hfp_init.cellCount_le
  have hrN : rSeq B_coins = [] := by simp [rSeq]
  rw [← hrN]
  refine h1.seq (StepTo.repeatN (.lit (B_coins : ℤ)) _ B_coins 1 10 (TW * BW + TR * BR)
    mSeq rSeq hfp_init.1 hfp_init.cellCount_le rfl le_rfl ?_)
  intro i hi
  obtain ⟨hfpi, hscri, _, _, _⟩ := hmSeq_spec i hi.le
  have hr_cons : rSeq i = bits ⟨i, hi⟩ :: rSeq (i + 1) := by
    dsimp only [rSeq]
    rw [← List.cons_getElem_drop_succ (h := by simp [hi]), List.getElem_ofFn]
  have hseq_eq : mSeq (i + 1) =
      H3a.wWrite (H3a.wWrite (mSeq i) coinTbl (i : ℤ) (if bits ⟨i, hi⟩ then 1 else 0))
        scratchTbl 0 ((i : ℤ) + 1) := by
    show stepMem i (mSeq i) = _
    dsimp only [stepMem]
    rw [dif_pos hi]
  rw [hr_cons, hseq_eq]
  let mA := H3a.wWrite (mSeq i) coinTbl (i : ℤ) (if bits ⟨i, hi⟩ then 1 else 0)
  have hfpA : InFootprint TW BW TR BR mA := hfpi.wWrite hcoinT (by omega) (by omega)
  have hfpB : InFootprint TW BW TR BR (H3a.wWrite mA scratchTbl 0 ((i : ℤ) + 1)) :=
    hfpA.wWrite hscrT le_rfl (by omega)
  have hs1 : StepTo inp (.randBitHeap coinTbl (.readHeap scratchTbl (.lit 0)))
      (mSeq i) mA (bits ⟨i, hi⟩ :: rSeq (i + 1)) (rSeq (i + 1)) 4 (TW * BW + TR * BR) := by
    refine StepTo.randBitHeap inp (bits ⟨i, hi⟩) (rSeq (i + 1)) coinTbl
      (.readHeap scratchTbl (.lit 0)) (i : ℤ) ?_ (by simp [intExprOps]) hfpA.1 hfpA.cellCount_le
    simpa [evalIntExpr, wRead] using hscri
  have hs2 : StepTo inp (.writeWordHeap scratchTbl (.lit 0)
      (.add (.readHeap scratchTbl (.lit 0)) (.lit 1)))
      mA (H3a.wWrite mA scratchTbl 0 ((i : ℤ) + 1)) (rSeq (i + 1)) (rSeq (i + 1))
      6 (TW * BW + TR * BR) := by
    refine StepTo.wWrite inp (rSeq (i + 1)) scratchTbl (.lit 0)
      (.add (.readHeap scratchTbl (.lit 0)) (.lit 1)) 0 ((i : ℤ) + 1) rfl ?_ (by simp [intExprOps])
      hfpB.1 hfpB.cellCount_le
    have hscri' : wRead mA scratchTbl 0 = (i : ℤ) := by
      dsimp only [mA]
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneT.symm)]
      exact hscri
    simp [evalIntExpr, wRead] at hscri' ⊢
    omega
  exact hs1.seq hs2

/-- Universal exact-bit-length lemma: if `prog = .seq (drawCoinsStmt coinTbl scratchTbl B) body`
halts on `List.ofFn bits` for every `bits : Fin B → Bool`, then `prog` returns `none` on EVERY
`bs : List Bool` with `bs.length ≠ B`. -/
theorem drawCoins_seq_none_of_len_ne {d : ℕ} {inp : ArithRAMInput d}
    (coinTbl scratchTbl B : ℕ) (body : ArithRAMStmt)
    (initMem : ArithRAMMemory)
    (hSomeAll : ∀ bits : Fin B → Bool,
      (runArithRAMWithBits (.seq (drawCoinsStmt coinTbl scratchTbl B) body)
        inp initMem (List.ofFn bits)).isSome)
    {bs : List Bool} (hlen : bs.length ≠ B) :
    runArithRAMWithBits (.seq (drawCoinsStmt coinTbl scratchTbl B) body) inp initMem bs = none := by
  classical
  set prog := ArithRAMStmt.seq (drawCoinsStmt coinTbl scratchTbl B) body
  rcases lt_trichotomy bs.length B with hlt | heq | hgt
  · have hloop_need : ∀ (rem : ℕ) (m : ArithRAMMemory) (rbs : List Bool)
        (rest : List ArithRAMCont) (u sp : ℕ),
        rbs.length < rem →
        ∀ fuel : ℕ, ∀ out : ArithRAMExecOutcome,
          runArithRAMFuel inp fuel
            (.repeatLoop rem
              (.seq (.randBitHeap coinTbl (.readHeap scratchTbl (.lit 0)))
                (.writeWordHeap scratchTbl (.lit 0)
                  (.add (.readHeap scratchTbl (.lit 0)) (.lit 1)))) :: rest)
            { mem := m, frameDepth := 0, remainingBits := rbs, unitCost := u, peakCellSpace := sp } ≠
          .halted out := by
      intro rem
      induction rem with
      | zero => intro _ rbs _ _ _ h; omega
      | succ rem' ih =>
        intro m rbs rest u sp hrlen fuel out
        cases fuel with
        | zero => simp [runArithRAMFuel]
        | succ f1 =>
          simp only [runArithRAMFuel]
          cases f1 with
          | zero => simp [runArithRAMFuel]
          | succ f2 =>
            simp only [runArithRAMFuel]
            cases f2 with
            | zero => simp [runArithRAMFuel]
            | succ f3 =>
              cases rbs with
              | nil => simp [runArithRAMFuel]
              | cons b rbs' =>
                simp only [runArithRAMFuel]
                cases f3 with
                | zero => simp [runArithRAMFuel]
                | succ f4 =>
                  simp only [runArithRAMFuel]
                  exact ih _ rbs' rest _ _ (by simp at hrlen; omega) f4 out
    unfold runArithRAMWithBits
    dsimp only
    split_ifs with hex
    · exfalso
      obtain ⟨out, hf⟩ := Nat.find_spec hex
      set F := Nat.find hex
      have hf4 := runArithRAMFuel_mono hf (Nat.le_add_right F 4)
      rw [show F + 4 = (((F + 1) + 1) + 1) + 1 by omega] at hf4
      simp only [prog, drawCoinsStmt, runArithRAMFuel, evalIntExpr,
        Int.natCast_nonneg, ↓reduceIte, Int.toNat_natCast] at hf4
      exact hloop_need B _ bs [.stmt body] _ _ hlt F out hf4
    · rfl
  · exact absurd heq hlen
  · by_contra hsome
    obtain ⟨out_bs, hbs⟩ := Option.ne_none_iff_exists'.mp hsome
    let bits0 : Fin B → Bool := fun j => bs[j.val]'(by omega)
    have htake : List.ofFn bits0 = bs.take B :=
      List.ext_getElem (by simp [Nat.min_eq_left hgt.le]) (by simp [bits0])
    obtain ⟨out0, h0⟩ := Option.isSome_iff_exists.mp (hSomeAll bits0)
    rw [htake] at h0
    have heq_bs := runArithRAMWithBits_prefixFree prog inp initMem h0 hbs (List.take_prefix B bs)
    have hlen_take : (bs.take B).length = B := by simp [Nat.min_eq_left hgt.le]
    rw [heq_bs] at hlen_take
    exact hlen hlen_take

/-! ### 3. Reusable `O(1)` Handle Pool + Dense Active Array + Cached Coordinates -/

structure HandlePool (d n : ℕ) where
  nextFresh : ℕ
  freeList : List ℕ
  actList : List ℕ
  coords : ℕ → EuclideanSpace ℝ (Fin d)

def HandlePool.empty (d n : ℕ) : HandlePool d n :=
  { nextFresh := 0, freeList := [], actList := [], coords := fun _ => 0 }

def HandlePool.WellFormed {d n : ℕ} (P : DynamicPointSet d) (hp : HandlePool d n) : Prop :=
  hp.nextFresh ≤ n ∧
  hp.actList.Nodup ∧
  hp.freeList.Nodup ∧
  hp.actList.toFinset = P.activeHandles ∧
  (∀ h ∈ hp.actList, h < hp.nextFresh) ∧
  (∀ h ∈ hp.freeList, h < hp.nextFresh ∧ h ∉ hp.actList) ∧
  hp.actList.length + hp.freeList.length = hp.nextFresh ∧
  (∀ h ∈ P.activeHandles, hp.coords h = P.handleCoords h)

theorem HandlePool.empty_wellFormed (d n : ℕ) :
    (HandlePool.empty d n).WellFormed (DynamicPointSet.empty d) := by
  refine ⟨Nat.zero_le n, List.nodup_nil, List.nodup_nil, ?_, ?_, ?_, rfl, ?_⟩
  · simp [HandlePool.empty, DynamicPointSet.empty]
  · simp [HandlePool.empty]
  · simp [HandlePool.empty]
  · simp [DynamicPointSet.empty]

def EncHandlePool {d n : ℕ} (hp : HandlePool d n) (mem : ArithRAMMemory) : Prop :=
  wRead mem 0 4 = (hp.nextFresh : ℤ) ∧
  wRead mem 0 5 = (hp.freeList.length : ℤ) ∧
  wRead mem 0 6 = (hp.actList.length : ℤ) ∧
  (∀ i (hi : i < hp.freeList.length),
    wRead mem 1 (i : ℤ) = (hp.freeList.reverse[i]'(by simp [hi]) : ℤ)) ∧
  (∀ i (hi : i < hp.actList.length),
    wRead mem 2 (i : ℤ) = (hp.actList[i]'hi : ℤ) ∧
    wRead mem 3 (hp.actList[i]'hi : ℤ) = (i : ℤ)) ∧
  (∀ h < hp.nextFresh, ∀ c : Fin d,
    rRead mem 1 ((h * d + c.val : ℕ) : ℤ) = euclideanCoord (hp.coords h) c)

theorem encHandlePool_empty (d n : ℕ) :
    EncHandlePool (HandlePool.empty d n) ArithRAMMemory.empty := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp [HandlePool.empty, wRead, ArithRAMMemory.empty, WordStore.empty, WordStore.read]
  · simp [HandlePool.empty, wRead, ArithRAMMemory.empty, WordStore.empty, WordStore.read]
  · simp [HandlePool.empty, wRead, ArithRAMMemory.empty, WordStore.empty, WordStore.read]
  · intro i hi; simp [HandlePool.empty] at hi
  · intro i hi; simp [HandlePool.empty] at hi
  · intro h hh; simp [HandlePool.empty] at hh

def applyHandleUpdateStmt (d : ℕ) : ArithRAMStmt :=
  .ite (.intEq (.intParam (.lit 1)) (.lit 1))
    (.seq
      (.ite (.intLt (.lit 0) (.readHeap 0 (.lit 5)))
        (.seq
          (.writeWordHeap 0 (.lit 5) (.sub (.readHeap 0 (.lit 5)) (.lit 1)))
          (.writeWordHeap 0 (.lit 0) (.readHeap 1 (.readHeap 0 (.lit 5)))))
        (.seq
          (.writeWordHeap 0 (.lit 0) (.readHeap 0 (.lit 4)))
          (.writeWordHeap 0 (.lit 4) (.add (.readHeap 0 (.lit 4)) (.lit 1)))))
      (.seq
        (.seq
          (.writeWordHeap 2 (.readHeap 0 (.lit 6)) (.readHeap 0 (.lit 0)))
          (.seq
            (.writeWordHeap 3 (.readHeap 0 (.lit 0)) (.readHeap 0 (.lit 6)))
            (.writeWordHeap 0 (.lit 6) (.add (.readHeap 0 (.lit 6)) (.lit 1)))))
        (forLoopStmt 4 0 d
          (.writeRealHeap 1
            (.add (.mul (.readHeap 0 (.lit 0)) (.lit (d : ℤ))) (.readHeap 4 (.lit 0)))
            (.extraReal (.readHeap 4 (.lit 0)))))))
    (.seq
      (.writeWordHeap 4 (.lit 0) (.readHeap 3 (.intParam (.lit 2))))
      (.seq
        (.writeWordHeap 0 (.lit 6) (.sub (.readHeap 0 (.lit 6)) (.lit 1)))
        (.seq
          (.writeWordHeap 4 (.lit 1) (.readHeap 2 (.readHeap 0 (.lit 6))))
          (.seq
            (.writeWordHeap 2 (.readHeap 4 (.lit 0)) (.readHeap 4 (.lit 1)))
            (.seq
              (.writeWordHeap 3 (.readHeap 4 (.lit 1)) (.readHeap 4 (.lit 0)))
              (.seq
                (.writeWordHeap 1 (.readHeap 0 (.lit 5)) (.intParam (.lit 2)))
                (.writeWordHeap 0 (.lit 5) (.add (.readHeap 0 (.lit 5)) (.lit 1)))))))))

/-- Pure transition of `HandlePool` matching `applyHandleUpdateStmt`. -/
noncomputable def HandlePool.step {d n : ℕ} (hp : HandlePool d n) :
    InternalUpdate d → HandlePool d n × Option ℕ
  | .insert pt =>
      match hp.freeList with
      | h :: rest =>
          ({ nextFresh := hp.nextFresh
             freeList := rest
             actList := hp.actList ++ [h]
             coords := Function.update hp.coords h pt },
           some h)
      | [] =>
          let h := hp.nextFresh
          ({ nextFresh := hp.nextFresh + 1
             freeList := []
             actList := hp.actList ++ [h]
             coords := Function.update hp.coords h pt },
           some h)
  | .delete delH =>
      let pos := hp.actList.idxOf delH
      let newSz := hp.actList.length - 1
      let lastH := hp.actList.getD newSz 0
      ({ nextFresh := hp.nextFresh
         freeList := delH :: hp.freeList
         actList := (hp.actList.set pos lastH).dropLast
         coords := hp.coords },
       none)

private lemma list_swap_dropLast_props {α : Type*} [DecidableEq α] {l : List α} {x : α}
    (hnodup : l.Nodup) (hx : x ∈ l) :
    let pos := l.idxOf x
    let sz := l.length
    have _hsz : 1 ≤ sz := List.length_pos_of_mem hx
    let lastX := l[sz - 1]'(by omega)
    let l' := (l.set pos lastX).dropLast
    pos < sz ∧
    l[pos]'(List.idxOf_lt_length_of_mem hx) = x ∧
    l'.length = sz - 1 ∧
    l'.Nodup ∧
    l'.toFinset = l.toFinset.erase x ∧
    (∀ i (hi : i < sz - 1),
      l'[i]'(by simp [l']; omega) =
        if i = pos then lastX else l[i]'(by omega)) := by
  have hsz : 1 ≤ l.length := List.length_pos_of_mem hx
  let pos := l.idxOf x
  let sz := l.length
  let lastX := l[sz - 1]'(by omega)
  let l' := (l.set pos lastX).dropLast
  have hpos_lt : pos < sz := List.idxOf_lt_length_of_mem hx
  have hget_pos : l[pos]'hpos_lt = x := List.getElem_idxOf hpos_lt
  have hlen' : l'.length = sz - 1 := by simp [l', sz]
  have hinj : Function.Injective (fun idx : Fin l.length => l[idx.val]'idx.isLt) :=
    List.nodup_iff_injective_getElem.mp hnodup
  have hget' : ∀ (i : ℕ) (hi : i < sz - 1) (hiL : i < l'.length),
      l'[i]'hiL = if i = pos then lastX else l[i]'(by omega) := by
    intro i hi hiL
    have hdrop_eq : l' = (l.set pos lastX).take (sz - 1) := by
      dsimp only [l']; rw [List.dropLast_eq_take]; simp [sz]
    have htake_get : l'[i]'hiL = (l.set pos lastX)[i]'(by simp; omega) := by
      conv_lhs => simp only [hdrop_eq, List.getElem_take]
    rw [htake_get, List.getElem_set]
    by_cases hip : i = pos
    · subst hip; simp
    · have hpi : ¬ (pos = i) := fun h => hip h.symm
      simp [hip, hpi]
  refine ⟨hpos_lt, hget_pos, hlen', ?_, ?_, fun i hi => hget' i hi (by rw [hlen']; exact hi)⟩
  · rw [List.nodup_iff_injective_getElem]
    intro i j heq
    have hi' : i.val < sz - 1 := Nat.lt_of_lt_of_eq i.isLt hlen'
    have hj' : j.val < sz - 1 := Nat.lt_of_lt_of_eq j.isLt hlen'
    change l'[i.val]'(i.isLt) = l'[j.val]'(j.isLt) at heq
    rw [hget' i.val hi' i.isLt, hget' j.val hj' j.isLt] at heq
    split_ifs at heq with hip hjp hjp2
    · exact Fin.ext (hip.trans hjp.symm)
    · exfalso
      have hidx_eq : (⟨sz - 1, by omega⟩ : Fin l.length) = ⟨j.val, by omega⟩ := hinj heq
      have : sz - 1 = j.val := congrArg Fin.val hidx_eq
      omega
    · exfalso
      have hidx_eq : (⟨i.val, by omega⟩ : Fin l.length) = ⟨sz - 1, by omega⟩ := hinj heq
      have : i.val = sz - 1 := congrArg Fin.val hidx_eq
      omega
    · have hidx_eq : (⟨i.val, by omega⟩ : Fin l.length) = ⟨j.val, by omega⟩ := hinj heq
      exact Fin.ext (by simpa using congrArg Fin.val hidx_eq)
  · ext y
    simp only [List.mem_toFinset, Finset.mem_erase]
    constructor
    · intro hy
      obtain ⟨i, hi, rfl⟩ := List.getElem_of_mem hy
      have hi' : i < sz - 1 := by rw [← hlen']; exact hi
      rw [hget' i hi' hi]
      split_ifs with hip
      · subst hip
        refine ⟨?_, List.getElem_mem _⟩
        intro hlast_eq
        have hidx_eq : (⟨sz - 1, by omega⟩ : Fin l.length) = ⟨pos, hpos_lt⟩ := hinj (hlast_eq.trans hget_pos.symm)
        have : sz - 1 = pos := congrArg Fin.val hidx_eq
        omega
      · refine ⟨?_, List.getElem_mem _⟩
        intro hy_eq
        have hidx_eq : (⟨i, by omega⟩ : Fin l.length) = ⟨pos, hpos_lt⟩ := hinj (hy_eq.trans hget_pos.symm)
        exact hip (congrArg Fin.val hidx_eq)
    · rintro ⟨hne_x, hy_in⟩
      obtain ⟨i, hi, rfl⟩ := List.getElem_of_mem hy_in
      have hi_ne_pos : i ≠ pos := fun heq => hne_x (by subst heq; exact hget_pos)
      by_cases hi_last : i = sz - 1
      · subst hi_last
        have hpos_lt' : pos < sz - 1 := by omega
        have hpL : pos < l'.length := by rw [hlen']; omega
        have hmem_pos : l'[pos]'hpL ∈ l' := List.getElem_mem _
        rw [hget' pos hpos_lt' hpL, if_pos rfl] at hmem_pos
        exact hmem_pos
      · have hi_lt' : i < sz - 1 := by omega
        have hiL : i < l'.length := by rw [hlen']; omega
        have hmem_i : l'[i]'hiL ∈ l' := List.getElem_mem _
        rw [hget' i hi_lt' hiL, if_neg hi_ne_pos] at hmem_i
        exact hmem_i

theorem HandlePool.step_wellFormed {d n : ℕ} {P : DynamicPointSet d} {hp : HandlePool d n}
    {op : DynamicUpdate d} (hP : P.WellFormed n) (hhp : hp.WellFormed P)
    (hleg : IsLegalUpdate n Set.univ P op) :
    let (hp', rh) := hp.step (toInternalUpdate P op)
    ∃ P' : DynamicPointSet d,
      applyDynamicUpdate P op rh = some P' ∧
      hp'.WellFormed P' := by
  rcases hhp with ⟨hnf_le, hact_nd, hfree_nd, hact_set, hact_lt, hfree_lt, hsum, hcoords⟩
  have hcard_eq : P.activeHandles.card = P.activeIds.card := by
    refine Finset.card_bij (fun h _ => P.idOfHandle h)
      (fun h hh => (hP.2.2.1 h hh).1)
      (fun h₁ hh₁ h₂ hh₂ heq => by
        dsimp only at heq
        have e1 := (hP.2.2.1 h₁ hh₁).2
        have e2 := (hP.2.2.1 h₂ hh₂).2
        rw [← e1, ← e2, heq])
      (fun pid hpid => ⟨P.handleOfId pid, (hP.2.1 pid hpid).1, (hP.2.1 pid hpid).2⟩)
  have hact_len_eq : hp.actList.length = P.activeHandles.card := by
    rw [← hact_set, List.toFinset_card_of_nodup hact_nd]
  cases op with
  | insert pid extName pt =>
    rcases hleg with ⟨hpid_not, hcard_ins, _⟩
    have hact_lt_n : hp.actList.length < n := by
      rw [hact_len_eq, hcard_eq]; omega
    dsimp only [toInternalUpdate, HandlePool.step]
    cases hfl : hp.freeList with
    | cons h rest =>
      dsimp only
      have hh_mem : h ∈ hp.freeList := by rw [hfl]; exact List.mem_cons_self
      obtain ⟨hh_lt, hh_not_act⟩ := hfree_lt h hh_mem
      have hh_not_P : h ∉ P.activeHandles := by
        rw [← hact_set, List.mem_toFinset]; exact hh_not_act
      unfold applyDynamicUpdate; dsimp only
      rw [if_pos ⟨hpid_not, hh_not_P⟩]
      refine ⟨_, rfl, hnf_le, ?_, (List.nodup_cons.mp (hfl ▸ hfree_nd)).2, ?_, ?_, ?_, ?_, ?_⟩
      · rw [List.nodup_append]
        exact ⟨hact_nd, List.nodup_singleton h, fun a ha b hb heq => by
          rw [List.mem_singleton] at hb; subst hb; subst heq; exact hh_not_act ha⟩
      · ext x; simp [← hact_set, or_comm]
      · intro x hx
        rcases List.mem_append.mp hx with hx | hx
        · exact hact_lt x hx
        · rw [List.mem_singleton] at hx; subst hx; exact hh_lt
      · intro x hx
        have hx_fl : x ∈ hp.freeList := by rw [hfl]; exact List.mem_cons_of_mem _ hx
        have hne_xh : x ≠ h := fun heq =>
          (List.nodup_cons.mp (hfl ▸ hfree_nd)).1 (heq ▸ hx)
        refine ⟨(hfree_lt x hx_fl).1, ?_⟩
        intro hx_app
        rcases List.mem_append.mp hx_app with hx_a | hx_s
        · exact (hfree_lt x hx_fl).2 hx_a
        · rw [List.mem_singleton] at hx_s; exact hne_xh hx_s
      · rw [hfl] at hsum; simp at hsum ⊢; omega
      · intro x hx
        have hx' : x = h ∨ x ∈ P.activeHandles := Finset.mem_insert.mp hx
        rcases hx' with rfl | hold
        · change Function.update hp.coords x pt x =
            if x ∈ insert x P.activeHandles then
              Function.update P.coords pid pt (Function.update P.idOfHandle x pid x)
            else 0
          rw [Function.update_self, if_pos (Finset.mem_insert_self _ _),
              Function.update_self, Function.update_self]
        · have hne : x ≠ h := fun heq => hh_not_P (heq ▸ hold)
          have hne_id : P.idOfHandle x ≠ pid := fun hid => hpid_not (hid ▸ (hP.2.2.1 x hold).1)
          change Function.update hp.coords h pt x =
            if x ∈ insert h P.activeHandles then
              Function.update P.coords pid pt (Function.update P.idOfHandle h pid x)
            else 0
          rw [Function.update_of_ne hne, if_pos (Finset.mem_insert_of_mem hold),
              Function.update_of_ne hne, Function.update_of_ne hne_id,
              hcoords x hold, DynamicPointSet.handleCoords, if_pos hold]
    | nil =>
      dsimp only
      have hnf_eq_act : hp.nextFresh = hp.actList.length := by
        rw [hfl] at hsum; simpa using hsum.symm
      have hnf_lt_n : hp.nextFresh < n := hnf_eq_act ▸ hact_lt_n
      have hh_not_act : hp.nextFresh ∉ hp.actList := fun hin =>
        Nat.lt_irrefl _ (hact_lt _ hin)
      have hh_not_P : hp.nextFresh ∉ P.activeHandles := by
        rw [← hact_set, List.mem_toFinset]; exact hh_not_act
      unfold applyDynamicUpdate; dsimp only
      rw [if_pos ⟨hpid_not, hh_not_P⟩]
      refine ⟨_, rfl, by dsimp only; omega, ?_, List.nodup_nil, ?_, ?_, by simp, by simp [hnf_eq_act], ?_⟩
      · rw [List.nodup_append]
        exact ⟨hact_nd, List.nodup_singleton _, fun a ha b hb heq => by
          rw [List.mem_singleton] at hb; subst hb; subst heq; exact hh_not_act ha⟩
      · ext x; simp [← hact_set, or_comm]
      · intro x hx
        rcases List.mem_append.mp hx with hx | hx
        · exact Nat.lt_succ_of_lt (hact_lt x hx)
        · rw [List.mem_singleton] at hx; dsimp only; omega
      · intro x hx
        have hx' : x = hp.nextFresh ∨ x ∈ P.activeHandles := Finset.mem_insert.mp hx
        rcases hx' with rfl | hold
        · change Function.update hp.coords hp.nextFresh pt hp.nextFresh =
            if hp.nextFresh ∈ insert hp.nextFresh P.activeHandles then
              Function.update P.coords pid pt (Function.update P.idOfHandle hp.nextFresh pid hp.nextFresh)
            else 0
          rw [Function.update_self, if_pos (Finset.mem_insert_self _ _),
              Function.update_self, Function.update_self]
        · have hne : x ≠ hp.nextFresh := fun heq => hh_not_P (heq ▸ hold)
          have hne_id : P.idOfHandle x ≠ pid := fun hid => hpid_not (hid ▸ (hP.2.2.1 x hold).1)
          change Function.update hp.coords hp.nextFresh pt x =
            if x ∈ insert hp.nextFresh P.activeHandles then
              Function.update P.coords pid pt (Function.update P.idOfHandle hp.nextFresh pid x)
            else 0
          rw [Function.update_of_ne hne, if_pos (Finset.mem_insert_of_mem hold),
              Function.update_of_ne hne, Function.update_of_ne hne_id,
              hcoords x hold, DynamicPointSet.handleCoords, if_pos hold]
  | delete pid =>
    have hpid_in : pid ∈ P.activeIds := hleg
    let delH := P.handleOfId pid
    have hdel_P : delH ∈ P.activeHandles := (hP.2.1 pid hpid_in).1
    have hdel_act : delH ∈ hp.actList := by
      rwa [← hact_set, List.mem_toFinset] at hdel_P
    obtain ⟨hpos_lt, hget_pos, hlen', hnd', hset', hget'⟩ :=
      list_swap_dropLast_props hact_nd hdel_act
    have hsz1 : 1 ≤ hp.actList.length := List.length_pos_of_mem hdel_act
    have hgetD_eq : hp.actList.getD (hp.actList.length - 1) 0 =
        hp.actList[hp.actList.length - 1]'(by omega) :=
      List.getD_eq_getElem _ _ (by omega)
    dsimp only [toInternalUpdate, HandlePool.step]
    rw [hgetD_eq]
    unfold applyDynamicUpdate; dsimp only
    rw [if_pos hpid_in]
    refine ⟨_, rfl, hnf_le, hnd', ?_, ?_, ?_, ?_, ?_, ?_⟩
    · refine List.nodup_cons.mpr ⟨fun hin => (hfree_lt delH hin).2 hdel_act, hfree_nd⟩
    · rw [hset', hact_set]
    · intro x hx
      have hx_old : x ∈ hp.actList := by
        have hx_fs : x ∈ hp.actList.toFinset.erase delH := hset' ▸ List.mem_toFinset.mpr hx
        exact List.mem_toFinset.mp (Finset.erase_subset _ _ hx_fs)
      exact hact_lt x hx_old
    · intro x hx
      rcases List.mem_cons.mp hx with rfl | hold
      · refine ⟨hact_lt delH hdel_act, ?_⟩
        intro hin'
        have := List.mem_toFinset.mpr hin'
        rw [hset'] at this
        exact (Finset.mem_erase.mp this).1 rfl
      · refine ⟨(hfree_lt x hold).1, fun hin' => ?_⟩
        have hx_fs : x ∈ hp.actList.toFinset.erase delH := hset' ▸ List.mem_toFinset.mpr hin'
        exact (hfree_lt x hold).2 (List.mem_toFinset.mp (Finset.erase_subset _ _ hx_fs))
    · simp only [List.length_dropLast, List.length_set, List.length_cons]; omega
    · intro x hx
      have hx' : x ≠ delH ∧ x ∈ P.activeHandles := Finset.mem_erase.mp hx
      rcases hx' with ⟨hne_del, hold⟩
      have hne_id : P.idOfHandle x ≠ pid := by
        intro hid
        apply hne_del
        have e2 := (hP.2.2.1 x hold).2
        rw [hid] at e2
        exact e2.symm
      change hp.coords x =
        if x ∈ P.activeHandles.erase delH then
          Function.update P.coords pid 0 (Function.update P.idOfHandle delH 0 x)
        else 0
      rw [if_pos hx, Function.update_of_ne hne_del, Function.update_of_ne hne_id,
          hcoords x hold, DynamicPointSet.handleCoords, if_pos hold]

/-! ### 4. `ExecDet` simulation of `applyHandleUpdateStmt` -/

private lemma mul_add_inj_left {d h₁ h₂ c₁ c₂ : ℕ}
    (hc₁ : c₁ < d) (hc₂ : c₂ < d) (heq : h₁ * d + c₁ = h₂ * d + c₂) : h₁ = h₂ := by
  nlinarith

private lemma mul_add_lt_mul {h n k d : ℕ} (hh : h < n) (hk : k < d) : h * d + k < n * d :=
  calc h * d + k < h * d + d := Nat.add_lt_add_left hk (h * d)
    _ = (h + 1) * d := (Nat.succ_mul h d).symm
    _ ≤ n * d := Nat.mul_le_mul_right d hh

theorem exec_applyHandleUpdateStmt {d n TW BW TR BR : ℕ}
    {P : DynamicPointSet d} {hp : HandlePool d n} {op : DynamicUpdate d}
    {m₀ : ArithRAMMemory}
    (hTW : 5 ≤ TW) (hBW : n + 8 ≤ BW) (hTR : 2 ≤ TR) (hBR : n * d + 8 ≤ BR)
    (hP : P.WellFormed n) (hhp : hp.WellFormed P)
    (hleg : IsLegalUpdate n Set.univ P op)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (henc₀ : EncHandlePool hp m₀) :
    let uop := toInternalUpdate P op
    let inp : ArithRAMInput d :=
      match uop with
      | .insert pt =>
          { intParams := [(n : ℤ), 1, 0]
            activeHandles := P.activeHandles
            activeCoords := P.handleCoords
            extraReals := List.ofFn (fun c : Fin d => euclideanCoord pt c) }
      | .delete delH =>
          { intParams := [(n : ℤ), 0, (delH : ℤ)]
            activeHandles := P.activeHandles
            activeCoords := P.handleCoords
            extraReals := [] }
    let (hp', rh) := hp.step uop
    ExecDet TW BW TR BR inp (applyHandleUpdateStmt d) m₀
      (fun m₁ =>
        EncHandlePool hp' m₁ ∧
        (∀ h, rh = some h → ArithRAMDynamicProgram.readReturnedHandle m₁ = some h) ∧
        (∀ t ≥ 5, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ t ≥ 2, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (200 + 25 * d) := by
  rcases hhp with ⟨hnf_le, hact_nd, hfree_nd, hact_set, hact_lt, hfree_lt, hsum, hcoords⟩
  have hcard_eq : P.activeHandles.card = P.activeIds.card := by
    refine Finset.card_bij (fun h _ => P.idOfHandle h)
      (fun h hh => (hP.2.2.1 h hh).1)
      (fun h₁ hh₁ h₂ hh₂ heq => by
        dsimp only at heq
        rw [← (hP.2.2.1 h₁ hh₁).2, ← (hP.2.2.1 h₂ hh₂).2, heq])
      (fun pid hpid => ⟨P.handleOfId pid, (hP.2.1 pid hpid).1, (hP.2.1 pid hpid).2⟩)
  have hact_len_eq : hp.actList.length = P.activeHandles.card := by
    rw [← hact_set, List.toFinset_card_of_nodup hact_nd]
  rcases henc₀ with ⟨hw04, hw05, hw06, hstack, hact_enc, hpt_enc⟩
  cases op with
  | insert pid extName pt =>
    rcases hleg with ⟨hpid_not, hcard_ins, _⟩
    have hact_lt_n : hp.actList.length < n := by rw [hact_len_eq, hcard_eq]; omega
    dsimp only [toInternalUpdate]
    set inp : ArithRAMInput d :=
      { intParams := [(n : ℤ), 1, 0]
        activeHandles := P.activeHandles
        activeCoords := P.handleCoords
        extraReals := List.ofFn (fun c : Fin d => euclideanCoord pt c) }
    unfold applyHandleUpdateStmt
    refine (ExecDet.ite _ _ _ (C_c := 6) (C_b := 190 + 25 * d)
      (by simp [condExprOps, intExprOps]) ?_ (fun hf => by simp [evalArithCond, evalIntExpr, ArithRAMInput.toWordView, inp, listGetIntD] at hf)).mono
      (fun _ hm _ => hm) (by omega)
    intro _
    let allocPost : ℕ → List ℕ → ℕ → ArithRAMMemory → Prop := fun h rest nf mA =>
      h < nf ∧ nf ≤ n ∧ h ∉ hp.actList ∧
      wRead mA 0 0 = (h : ℤ) ∧
      wRead mA 0 4 = (nf : ℤ) ∧
      wRead mA 0 5 = (rest.length : ℤ) ∧
      wRead mA 0 6 = (hp.actList.length : ℤ) ∧
      (∀ i (hi : i < rest.length), wRead mA 1 (i : ℤ) = (rest.reverse[i]'(by simp [hi]) : ℤ)) ∧
      (∀ i (hi : i < hp.actList.length),
        wRead mA 2 (i : ℤ) = (hp.actList[i]'hi : ℤ) ∧
        wRead mA 3 (hp.actList[i]'hi : ℤ) = (i : ℤ)) ∧
      (∀ h' < nf, h' ≠ h → ∀ c : Fin d,
        rRead mA 1 ((h' * d + c.val : ℕ) : ℤ) = euclideanCoord (hp.coords h') c) ∧
      (∀ t ≥ 5, ∀ i, wRead mA t i = wRead m₀ t i) ∧
      (∀ t ≥ 2, ∀ i, rRead mA t i = rRead m₀ t i)
    have halloc_all : ∃ h rest nf,
        hp.step (.insert pt) =
          ({ nextFresh := nf
             freeList := rest
             actList := hp.actList ++ [h]
             coords := Function.update hp.coords h pt }, some h) ∧
        ExecDet TW BW TR BR inp
          (.ite (.intLt (.lit 0) (.readHeap 0 (.lit 5)))
            (.seq
              (.writeWordHeap 0 (.lit 5) (.sub (.readHeap 0 (.lit 5)) (.lit 1)))
              (.writeWordHeap 0 (.lit 0) (.readHeap 1 (.readHeap 0 (.lit 5)))))
            (.seq
              (.writeWordHeap 0 (.lit 0) (.readHeap 0 (.lit 4)))
              (.writeWordHeap 0 (.lit 4) (.add (.readHeap 0 (.lit 4)) (.lit 1)))))
          m₀ (allocPost h rest nf) 30 := by
      cases hfl : hp.freeList with
      | cons h rest =>
        refine ⟨h, rest, hp.nextFresh, by simp [HandlePool.step, hfl], ?_⟩
        have hh_mem : h ∈ hp.freeList := by rw [hfl]; exact List.mem_cons_self
        obtain ⟨hh_lt, hh_not_act⟩ := hfree_lt h hh_mem
        have hcond_fl : (evalArithCond inp 0 m₀ (.intLt (.lit 0) (.readHeap 0 (.lit 5)))).1 = true := by
          have hlen_pos : 0 < hp.freeList.length := by simp [hfl]
          simp [evalArithCond, evalIntExpr, wRead] at hw05 ⊢
          omega
        refine (ExecDet.ite _ _ _ (C_c := 6) (C_b := 24) (by simp [condExprOps, intExprOps])
          (fun _ => ?_) (fun hf => absurd hcond_fl (by simp [hf]))).mono (fun _ hm _ => hm) (by omega)
        refine ExecDet.seq' 12
          (ExecDet.wWriteEq inp 0 (.lit 5) (.sub (.readHeap 0 (.lit 5)) (.lit 1)) 5 (rest.length : ℤ)
            hfp₀ (by omega) (by omega) (by omega) rfl
            (by simp [evalIntExpr, wRead, hfl] at hw05 ⊢; omega) (by simp [intExprOps]))
          (by omega) ?_
        intro m1 hm1 hfp1
        subst hm1
        have htop_eq : hp.freeList.reverse[rest.length]'(by simp [hfl]) = h := by simp [hfl]
        have hread_h : wRead (H3a.wWrite m₀ 0 5 (rest.length : ℤ)) 1 (rest.length : ℤ) = (h : ℤ) := by
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), hstack rest.length (by simp [hfl]), htop_eq]
        refine ExecDet.wWrite (C := 12) inp 0 (.lit 0) (.readHeap 1 (.readHeap 0 (.lit 5))) 0 (h : ℤ)
          hfp1 (by omega) (by omega) (by omega) rfl
          (by change wRead (H3a.wWrite m₀ 0 5 (rest.length : ℤ)) 1
                (wRead (H3a.wWrite m₀ 0 5 (rest.length : ℤ)) 0 5) = (h : ℤ)
              rw [wRead_wWrite_self, hread_h])
          (by simp [intExprOps]) ?_
        refine ⟨hh_lt, hnf_le, hh_not_act, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          exact hw04
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          exact hw06
        · intro i hi
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
          have hi' : i < hp.freeList.length := by simp [hfl]; omega
          rw [hstack i hi']
          have hrev : hp.freeList.reverse = rest.reverse ++ [h] := by simp [hfl]
          have hget_rev : hp.freeList.reverse[i]'(by simp [hi']) = rest.reverse[i]'(by simp [hi]) := by
            simp only [hrev]
            exact List.getElem_append_left (by simpa using hi)
          exact_mod_cast hget_rev
        · intro i hi
          refine ⟨?_, ?_⟩
          · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
            exact (hact_enc i hi).1
          · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
            exact (hact_enc i hi).2
        · intro h' hh' _ c; exact hpt_enc h' hh' c
        · intro t ht idx
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
        · intro _ _ _; rfl
      | nil =>
        refine ⟨hp.nextFresh, [], hp.nextFresh + 1, by simp [HandlePool.step, hfl], ?_⟩
        have hnf_eq_act : hp.nextFresh = hp.actList.length := by rw [hfl] at hsum; simpa using hsum.symm
        have hnf_lt_n : hp.nextFresh < n := hnf_eq_act ▸ hact_lt_n
        have hh_not_act : hp.nextFresh ∉ hp.actList := fun hin => Nat.lt_irrefl _ (hact_lt _ hin)
        have hcond_fl : (evalArithCond inp 0 m₀ (.intLt (.lit 0) (.readHeap 0 (.lit 5)))).1 = false := by
          simp [evalArithCond, evalIntExpr, wRead, hfl] at hw05 ⊢
          omega
        refine (ExecDet.ite _ _ _ (C_c := 6) (C_b := 24) (by simp [condExprOps, intExprOps])
          (fun ht => absurd hcond_fl (by simp [ht])) (fun _ => ?_)).mono (fun _ hm _ => hm) (by omega)
        refine ExecDet.seq' 12
          (ExecDet.wWriteEq inp 0 (.lit 0) (.readHeap 0 (.lit 4)) 0 (hp.nextFresh : ℤ)
            hfp₀ (by omega) (by omega) (by omega) rfl
            (by simpa [evalIntExpr, wRead] using hw04) (by simp [intExprOps]))
          (by omega) ?_
        intro m1 hm1 hfp1
        subst hm1
        refine ExecDet.wWrite (C := 12) inp 0 (.lit 4) (.add (.readHeap 0 (.lit 4)) (.lit 1))
          4 (((hp.nextFresh + 1 : ℕ) : ℤ)) hfp1 (by omega) (by omega) (by omega) rfl
          (by change wRead (H3a.wWrite m₀ 0 0 (hp.nextFresh : ℤ)) 0 4 + 1 = _
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw04]; push_cast; ring)
          (by simp [intExprOps]) ?_
        refine ⟨by omega, by omega, hh_not_act, ?_, wRead_wWrite_self _ _ _ _, ?_, ?_,
          fun _ hi => absurd hi (Nat.not_lt_zero _), ?_, ?_, ?_, ?_⟩
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          simpa [hfl] using hw05
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          exact hw06
        · intro i hi
          refine ⟨?_, ?_⟩
          · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
            exact (hact_enc i hi).1
          · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
            exact (hact_enc i hi).2
        · intro h' hh' hne c
          exact hpt_enc h' (by omega) c
        · intro t ht idx
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
        · intro _ _ _; rfl
    obtain ⟨h, rest, nf, hstep_eq, halloc⟩ := halloc_all
    rw [hstep_eq]
    dsimp only
    refine ExecDet.seq' (160 + 25 * d) halloc (by omega) ?_
    intro mA ⟨hh_lt', hnf_le', hh_not_act', hwA00, hwA04, hwA05, hwA06, hstackA, hactA, hptA, hotwA, hotrA⟩ hfpA
    refine ExecDet.seq' (124 + 25 * d)
      (ExecDet.seq
        (ExecDet.wWriteEq inp 2 (.readHeap 0 (.lit 6)) (.readHeap 0 (.lit 0))
          (hp.actList.length : ℤ) (h : ℤ) hfpA (by omega) (by omega) (by omega)
          (by simpa [evalIntExpr, wRead] using hwA06)
          (by simpa [evalIntExpr, wRead] using hwA00) (by simp [intExprOps]))
        (fun mB hmB hfpB => by
          subst hmB
          refine ExecDet.seq
            (ExecDet.wWriteEq inp 3 (.readHeap 0 (.lit 0)) (.readHeap 0 (.lit 6))
              (h : ℤ) (hp.actList.length : ℤ) hfpB (by omega) (by omega) (by omega)
              (by change wRead _ 0 0 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), hwA00])
              (by change wRead _ 0 6 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), hwA06])
              (by simp [intExprOps]))
            (fun mC hmC hfpC => by
              subst hmC
              refine ExecDet.wWriteEq inp 0 (.lit 6) (.add (.readHeap 0 (.lit 6)) (.lit 1))
                6 ((hp.actList.length : ℤ) + 1) hfpC (by omega) (by omega) (by omega) rfl
                (by change wRead _ 0 6 + 1 = _
                    rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inl (by omega)), hwA06])
                (by simp [intExprOps]))))
      (by omega) ?_
    intro mD hmD hfpD
    subst hmD
    let CoordInv : ℕ → ArithRAMMemory → Prop := fun k m =>
      wRead m 0 0 = (h : ℤ) ∧
      wRead m 0 4 = (nf : ℤ) ∧
      wRead m 0 5 = (rest.length : ℤ) ∧
      wRead m 0 6 = ((hp.actList ++ [h]).length : ℤ) ∧
      (∀ i (hi : i < rest.length), wRead m 1 (i : ℤ) = (rest.reverse[i]'(by simp [hi]) : ℤ)) ∧
      (∀ i (hi : i < (hp.actList ++ [h]).length),
        wRead m 2 (i : ℤ) = ((hp.actList ++ [h])[i]'hi : ℤ) ∧
        wRead m 3 ((hp.actList ++ [h])[i]'hi : ℤ) = (i : ℤ)) ∧
      (∀ h' < nf, h' ≠ h → ∀ c : Fin d,
        rRead m 1 ((h' * d + c.val : ℕ) : ℤ) = euclideanCoord (hp.coords h') c) ∧
      (∀ c : Fin d, c.val < k →
        rRead m 1 ((h * d + c.val : ℕ) : ℤ) = euclideanCoord pt c) ∧
      (∀ t ≥ 5, ∀ idx, wRead m t idx = wRead m₀ t idx) ∧
      (∀ t ≥ 2, ∀ idx, rRead m t idx = rRead m₀ t idx)
    refine (ExecDet.forLoop 4 0 d _ CoordInv 18 hfpD (by omega) le_rfl (by omega) ?_ ?_).mono ?_ (by omega)
    · refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, fun _ hc => absurd hc (Nat.not_lt_zero _), ?_, ?_⟩
      · iterate 4 rw [wRead_wWrite_of_ne _ _ (by omega)]
        exact hwA00
      · iterate 4 rw [wRead_wWrite_of_ne _ _ (by omega)]
        exact hwA04
      · iterate 4 rw [wRead_wWrite_of_ne _ _ (by omega)]
        exact hwA05
      · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_self]; simp
      · intro i hi
        iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
        exact hstackA i hi
      · intro i hi
        have hi_le : i ≤ hp.actList.length := by simp at hi; omega
        rcases Nat.lt_or_eq_of_le hi_le with hlt | rfl
        · have hget_i : (hp.actList ++ [h])[i]'hi = hp.actList[i]'hlt :=
            List.getElem_append_left hlt
          rw [hget_i]
          have hne_ih : hp.actList[i]'hlt ≠ h := fun heq =>
            hh_not_act' (heq ▸ List.getElem_mem _)
          refine ⟨?_, ?_⟩
          · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
            exact (hactA i hlt).1
          · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hne_ih)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
            exact (hactA i hlt).2
        · have hget_last : (hp.actList ++ [h])[hp.actList.length]'hi = h := by simp
          rw [hget_last]
          refine ⟨?_, ?_⟩
          · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_self]
          · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_self]
      · intro h' hh' hne c; exact hptA h' hh' hne c
      · intro t ht idx
        iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
        exact hotwA t ht idx
      · intro t ht idx; exact hotrA t ht idx
    · intro k hk m ⟨hc00, hc04, hc05, hc06, hcst, hca, hcpt_ne, hcpt_h, hcotw, hcotr⟩ hctr hfpm
      have hidx_lt : h * d + k < n * d := mul_add_lt_mul (by omega) hk
      refine ExecDet.rWrite inp 1
        (.add (.mul (.readHeap 0 (.lit 0)) (.lit (d : ℤ))) (.readHeap 4 (.lit 0)))
        (.extraReal (.readHeap 4 (.lit 0)))
        ((h * d + k : ℕ) : ℤ) (euclideanCoord pt ⟨k, hk⟩)
        hfpm (by omega) (by omega) (by omega)
        (by change wRead m 0 0 * (d : ℤ) + wRead m 4 0 = _; rw [hc00, hctr]; push_cast; ring)
        (by change listGetIntD inp.extraReals (wRead m 4 0) 0 = _; rw [hctr]; simp [inp, listGetIntD, hk])
        (by simp [intExprOps, realExprOps]) ?_
      refine ⟨hctr, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_rWrite]; exact hc00
      · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_rWrite]; exact hc04
      · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_rWrite]; exact hc05
      · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_rWrite]; exact hc06
      · intro i hi; rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_rWrite]; exact hcst i hi
      · intro i hi
        refine ⟨?_, ?_⟩
        · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_rWrite]
          exact (hca i hi).1
        · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_rWrite]
          exact (hca i hi).2
      · intro h' hh' hne c
        rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr ?_)]
        · exact hcpt_ne h' hh' hne c
        · have hc_lt := c.isLt
          intro heq
          have heq_nat : h' * d + c.val = h * d + k := by exact_mod_cast heq
          exact hne (mul_add_inj_left hc_lt hk heq_nat)
      · intro c hc
        rw [rRead_wWrite]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hc with hlt | heq
        · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]
          exact hcpt_h c hlt
        · have hceq : c = ⟨k, hk⟩ := Fin.ext heq
          subst hceq
          exact rRead_rWrite_self _ _ _ _
      · intro t ht idx
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_rWrite]
        exact hcotw t ht idx
      · intro t ht idx
        rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl (by omega))]
        exact hcotr t ht idx
    · intro mF ⟨hc00, hc04, hc05, hc06, hcst, hca, hcpt_ne, hcpt_h, hcotw, hcotr⟩ _
      refine ⟨⟨hc04, hc05, hc06, hcst, hca, ?_⟩, ?_, hcotw, hcotr⟩
      · intro h' hh' c
        by_cases heq : h' = h
        · subst heq
          dsimp only
          rw [Function.update_self]
          exact hcpt_h c c.isLt
        · dsimp only
          rw [Function.update_of_ne heq]
          exact hcpt_ne h' hh' heq c
      · intro h_ret hh_ret
        cases hh_ret
        unfold ArithRAMDynamicProgram.readReturnedHandle
        change (let hv := wRead mF 0 0; if 0 ≤ hv then some hv.toNat else none) = some h
        simp [hc00]
  | delete pid =>
    have hpid_in : pid ∈ P.activeIds := hleg
    let delH := P.handleOfId pid
    have hdel_P : delH ∈ P.activeHandles := (hP.2.1 pid hpid_in).1
    have hdel_act : delH ∈ hp.actList := by rwa [← hact_set, List.mem_toFinset] at hdel_P
    obtain ⟨hpos_lt, hget_pos, hlen', hnd', hset', hget'⟩ :=
      list_swap_dropLast_props hact_nd hdel_act
    let pos := hp.actList.idxOf delH
    let sz := hp.actList.length
    have hsz1 : 1 ≤ sz := List.length_pos_of_mem hdel_act
    let lastH := hp.actList[sz - 1]'(by omega)
    have hlast_lt : lastH < n := (hact_lt lastH (List.getElem_mem _)).trans_le hnf_le
    have hdel_lt : delH < n := (hact_lt delH hdel_act).trans_le hnf_le
    have hfl_lt : hp.freeList.length < n := by omega
    have hgetD_eq : hp.actList.getD (sz - 1) 0 = lastH := List.getD_eq_getElem _ _ (by omega)
    dsimp only [toInternalUpdate, HandlePool.step]
    set inp : ArithRAMInput d :=
      { intParams := [(n : ℤ), 0, (delH : ℤ)]
        activeHandles := P.activeHandles
        activeCoords := P.handleCoords
        extraReals := [] }
    unfold applyHandleUpdateStmt
    refine (ExecDet.ite _ _ _ (C_c := 6) (C_b := 120) (by simp [condExprOps, intExprOps])
      (fun ht => by simp [evalArithCond, evalIntExpr, ArithRAMInput.toWordView, inp, listGetIntD] at ht) ?_).mono
      (fun _ hm _ => hm) (by omega)
    intro _
    have hpos_read : wRead m₀ 3 (delH : ℤ) = (pos : ℤ) := by
      have := (hact_enc pos hpos_lt).2
      rwa [hget_pos] at this
    have hlast_read : wRead m₀ 2 ((sz - 1 : ℕ) : ℤ) = (lastH : ℤ) :=
      (hact_enc (sz - 1) (by omega)).1
    refine ExecDet.seq' 100
      (ExecDet.wWriteEq inp 4 (.lit 0) (.readHeap 3 (.intParam (.lit 2))) 0 (pos : ℤ)
        hfp₀ (by omega) le_rfl (by omega) rfl
        (by simpa [evalIntExpr, ArithRAMInput.toWordView, inp, listGetIntD, wRead] using hpos_read) (by simp [intExprOps]))
      (by omega) ?_
    intro m1 hm1 hfp1; subst hm1
    refine ExecDet.seq' 84
      (ExecDet.wWriteEq inp 0 (.lit 6) (.sub (.readHeap 0 (.lit 6)) (.lit 1)) 6 ((sz - 1 : ℕ) : ℤ)
        hfp1 (by omega) (by omega) (by omega) rfl
        (by change wRead _ 0 6 - 1 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), hw06]; dsimp only [sz]; omega)
        (by simp [intExprOps]))
      (by omega) ?_
    intro m2 hm2 hfp2; subst hm2
    refine ExecDet.seq' 68
      (ExecDet.wWriteEq inp 4 (.lit 1) (.readHeap 2 (.readHeap 0 (.lit 6))) 1 (lastH : ℤ)
        hfp2 (by omega) (by omega) (by omega) rfl
        (by change wRead _ 2 (wRead _ 0 6) = _
            rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)), hlast_read])
        (by simp [intExprOps]))
      (by omega) ?_
    intro m3 hm3 hfp3; subst hm3
    refine ExecDet.seq' 52
      (ExecDet.wWriteEq inp 2 (.readHeap 4 (.lit 0)) (.readHeap 4 (.lit 1)) (pos : ℤ) (lastH : ℤ)
        hfp3 (by omega) (by omega) (by omega)
        (by change wRead _ 4 0 = _
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_self])
        (by change wRead _ 4 1 = _; rw [wRead_wWrite_self])
        (by simp [intExprOps]))
      (by omega) ?_
    intro m4 hm4 hfp4; subst hm4
    refine ExecDet.seq' 36
      (ExecDet.wWriteEq inp 3 (.readHeap 4 (.lit 1)) (.readHeap 4 (.lit 0)) (lastH : ℤ) (pos : ℤ)
        hfp4 (by omega) (by omega) (by omega)
        (by change wRead _ 4 1 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_self])
        (by change wRead _ 4 0 = _
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_self])
        (by simp [intExprOps]))
      (by omega) ?_
    intro m5 hm5 hfp5; subst hm5
    refine ExecDet.seq' 12
      (ExecDet.wWriteEq inp 1 (.readHeap 0 (.lit 5)) (.intParam (.lit 2)) (hp.freeList.length : ℤ) (delH : ℤ)
        hfp5 (by omega) (by omega) (by omega)
        (by change wRead _ 0 5 = _
            iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by omega)), hw05])
        (by simp [evalIntExpr, ArithRAMInput.toWordView, inp, listGetIntD])
        (by simp [intExprOps]))
      (by omega) ?_
    intro m6 hm6 hfp6; subst hm6
    refine ExecDet.wWrite (C := 12) inp 0 (.lit 5) (.add (.readHeap 0 (.lit 5)) (.lit 1))
      5 (((hp.freeList.length + 1 : ℕ) : ℤ)) hfp6 (by omega) (by omega) (by omega) rfl
      (by change wRead _ 0 5 + 1 = _
          iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl (by omega)), hw05]
          push_cast; ring)
      (by simp [intExprOps]) ?_
    rw [hgetD_eq]
    refine ⟨⟨?_, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, ?_⟩, (fun _ hh => by cases hh), ?_, fun _ _ _ => rfl⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inl (by omega)), hw04]
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
      rw [wRead_wWrite_self, hlen']
    · intro i hi
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
      have hi_le : i ≤ hp.freeList.length := by simp at hi; omega
      rcases Nat.lt_or_eq_of_le hi_le with hlt | rfl
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        iterate 5 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
        rw [hstack i hlt]
        have hget_rev : hp.freeList.reverse[i]'(by simp [hlt]) =
            (delH :: hp.freeList).reverse[i]'(by rw [List.length_reverse]; exact hi) := by
          simp only [List.reverse_cons]
          exact (List.getElem_append_left (by simpa using hlt)).symm
        exact_mod_cast hget_rev
      · rw [wRead_wWrite_self]
        have hlast_rev : (delH :: hp.freeList).reverse[hp.freeList.length]'(by simp) = delH := by
          simp only [List.reverse_cons]
          rw [List.getElem_append_right (by simp)]
          simp
        exact_mod_cast hlast_rev.symm
    · intro i hi
      have hi' : i < sz - 1 := by rwa [hlen'] at hi
      have hgi := hget' i hi'
      change wRead _ 2 (i : ℤ) = _ ∧ wRead _ 3 _ = _
      rw [hgi]
      split_ifs with hip
      · subst hip
        refine ⟨?_, ?_⟩
        · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_self]
        · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_self]
      · have hne_last : hp.actList[i]'(by omega) ≠ lastH := by
          intro heq
          have hinj := List.nodup_iff_injective_getElem.mp hact_nd
          have hidx : (⟨i, by omega⟩ : Fin hp.actList.length) = ⟨sz - 1, by omega⟩ := hinj heq
          have : i = sz - 1 := congrArg Fin.val hidx
          omega
        refine ⟨?_, ?_⟩
        · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
          exact (hact_enc i (by omega)).1
        · rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by exact_mod_cast hne_last))]
          iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
          exact (hact_enc i (by omega)).2
    · intro h' hh' c; exact hpt_enc h' hh' c
    · intro t ht idx
      iterate 7 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]

/-! ### 5. Handle-level factor-`c` diameter answer transfer & deterministic bridge -/

theorem indexedDiam_handles_eq {d n : ℕ} {P : DynamicPointSet d} (hP : P.WellFormed n) :
    indexedEuclideanDiam P.activeHandles P.handleCoords =
      indexedEuclideanDiam P.activeIds P.coords := by
  unfold indexedEuclideanDiam
  by_cases hne : P.activeHandles.Nonempty
  · have hne_id : P.activeIds.Nonempty := by
      obtain ⟨h, hh⟩ := hne
      exact ⟨P.idOfHandle h, (hP.2.2.1 h hh).1⟩
    rw [dif_pos hne, dif_pos hne_id]
    apply le_antisymm
    · refine Finset.sup'_le _ _ fun xy hxy => ?_
      rcases Finset.mem_product.mp hxy with ⟨hx, hy⟩
      have hx_id := (hP.2.2.1 xy.1 hx).1
      have hy_id := (hP.2.2.1 xy.2 hy).1
      have hmem_id : (P.idOfHandle xy.1, P.idOfHandle xy.2) ∈ P.activeIds ×ˢ P.activeIds :=
        Finset.mem_product.mpr ⟨hx_id, hy_id⟩
      have hle := Finset.le_sup' (fun uv : ℕ × ℕ => ‖P.coords uv.1 - P.coords uv.2‖) hmem_id
      simpa [DynamicPointSet.handleCoords, hx, hy] using hle
    · refine Finset.sup'_le _ _ fun uv huv => ?_
      rcases Finset.mem_product.mp huv with ⟨hu, hv⟩
      have hu_h := (hP.2.1 uv.1 hu).1
      have hv_h := (hP.2.1 uv.2 hv).1
      have hmem_h : (P.handleOfId uv.1, P.handleOfId uv.2) ∈ P.activeHandles ×ˢ P.activeHandles :=
        Finset.mem_product.mpr ⟨hu_h, hv_h⟩
      have hle := Finset.le_sup' (fun xy : ℕ × ℕ => ‖P.handleCoords xy.1 - P.handleCoords xy.2‖) hmem_h
      have e1 : P.handleCoords (P.handleOfId uv.1) = P.coords uv.1 := by
        simp [DynamicPointSet.handleCoords, hu_h, (hP.2.1 uv.1 hu).2]
      have e2 : P.handleCoords (P.handleOfId uv.2) = P.coords uv.2 := by
        simp [DynamicPointSet.handleCoords, hv_h, (hP.2.1 uv.2 hv).2]
      simpa [e1, e2] using hle
  · have hne_id : ¬ P.activeIds.Nonempty := by
      intro ⟨pid, hpid⟩
      exact hne ⟨P.handleOfId pid, (hP.2.1 pid hpid).1⟩
    rw [dif_neg hne, dif_neg hne_id]

theorem validFactorCAnswer_of_handles {d n : ℕ} {c : ℝ} {P : DynamicPointSet d}
    {ans : StoredDiameterAnswer} (hP : P.WellFormed n)
    (hle1 : P.activeHandles.card ≤ 1 → ans.diameterHandles = none ∧ ans.cachedDistSq = 0)
    (hge2 : 2 ≤ P.activeHandles.card →
      ∃ h₁ h₂ : ℕ,
        ans.diameterHandles = some (h₁, h₂) ∧
        h₁ ≠ h₂ ∧
        ans.cachedDistSq = ‖P.handleCoords h₁ - P.handleCoords h₂‖ ^ 2 ∧
        IsIndexedFactorCDiameterPair c P.activeHandles P.handleCoords h₁ h₂) :
    IsValidFactorCAnswer c P ans := by
  have hcard_eq : P.activeHandles.card = P.activeIds.card := by
    refine Finset.card_bij (fun h _ => P.idOfHandle h)
      (fun h hh => (hP.2.2.1 h hh).1)
      (fun h₁ hh₁ h₂ hh₂ heq => by
        dsimp only at heq
        rw [← (hP.2.2.1 h₁ hh₁).2, ← (hP.2.2.1 h₂ hh₂).2, heq])
      (fun pid hpid => ⟨P.handleOfId pid, (hP.2.1 pid hpid).1, (hP.2.1 pid hpid).2⟩)
  unfold IsValidFactorCAnswer
  split_ifs with h1
  · exact hle1 (by omega)
  · obtain ⟨h₁, h₂, hans_h, hne_h, hsq, hh₁, hh₂, _, hlo, hhi⟩ := hge2 (by omega)
    have hid₁ := (hP.2.2.1 h₁ hh₁).1
    have hid₂ := (hP.2.2.1 h₂ hh₂).1
    have hne_id : P.idOfHandle h₁ ≠ P.idOfHandle h₂ := fun heq =>
      hne_h (by rw [← (hP.2.2.1 h₁ hh₁).2, ← (hP.2.2.1 h₂ hh₂).2, heq])
    have hc1 : P.handleCoords h₁ = P.coords (P.idOfHandle h₁) := by
      simp [DynamicPointSet.handleCoords, hh₁]
    have hc2 : P.handleCoords h₂ = P.coords (P.idOfHandle h₂) := by
      simp [DynamicPointSet.handleCoords, hh₂]
    rw [indexedDiam_handles_eq hP, hc1, hc2] at hlo hhi
    rw [hc1, hc2] at hsq
    exact ⟨h₁, h₂, hans_h, hh₁, hh₂, hne_h, hsq, hid₁, hid₂, hne_id, hlo, hhi⟩

open Classical in
/-- Specialized deterministic (`B_STEP = 0`, `ZeroRandStmt`) bridge from `fixedCoinBridge`. -/
theorem deterministicRAMBridge {d n t : ℕ} {δ c stepWorkBound spaceBound : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (updStmt : ArithRAMStmt) (hzr : ZeroRandStmt updStmt)
    (ReachInv : DynamicPointSet d → ArithRAMMemory → Prop)
    (hWork1 : 1 ≤ stepWorkBound) (hSpace1 : 1 ≤ spaceBound)
    (hInitReach : ReachInv (DynamicPointSet.empty d) ArithRAMMemory.empty)
    (hStep : ∀ (P : DynamicPointSet d) (mem : ArithRAMMemory) (op : DynamicUpdate d),
      P.WellFormed n → ReachInv P mem → IsLegalUpdate n Set.univ P op →
      let prog : ArithRAMDynamicProgram := { initStmt := .skip, updateStmt := updStmt }
      let initOut : ArithRAMExecOutcome := { mem := ArithRAMMemory.empty, unitCost := 1, peakCellSpace := 1 }
      let alg := mkArithAlg (d := d) n prog initOut
      ∃ (P' : DynamicPointSet d) (out : DynamicStepOutcome ArithRAMMemory),
        runSingleAdaptiveStep alg P mem op [] = some (P', out) ∧
        ReachInv P' out.nextState ∧
        (out.work : ℝ) ≤ stepWorkBound ∧
        (out.peakSpace : ℝ) ≤ spaceBound ∧
        IsValidFactorCAnswer c P' out.storedAnswer) :
    let prog : ArithRAMDynamicProgram := { initStmt := .skip, updateStmt := updStmt }
    ∃ initOut : ArithRAMExecOutcome,
      prog.evalInit n d = some initOut ∧
      let alg := mkArithAlg (d := d) n prog initOut
      SatisfiesDynamicStorageAndQueryModel 4 1 alg ∧
      SatisfiesMonteCarloGuarantee n t δ c Set.univ alg ∧
      SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg stepWorkBound ∧
      SatisfiesBoundedSpaceBound n t Set.univ alg spaceBound := by
  intro prog
  let initOut : ArithRAMExecOutcome := { mem := ArithRAMMemory.empty, unitCost := 1, peakCellSpace := 1 }
  let alg := mkArithAlg (d := d) n prog initOut
  refine ⟨initOut, evalInit_skip n d updStmt, storageModel_of_empty_init n prog initOut rfl, ?_⟩
  refine fixedCoinBridge hn ht hδ0 hδ1 0 alg (fun _ P m => ReachInv P m) (fun _ _ _ => True)
    (by simpa [alg, mkArithAlg, initOut] using hWork1)
    (by simpa [alg, mkArithAlg, initOut] using hSpace1)
    hInitReach trivial ?_ ?_ ?_
  · intro _ P mem op bs _ _ _ _ hlen
    have hbs : bs ≠ [] := List.ne_nil_of_length_pos (by omega)
    unfold runSingleAdaptiveStep
    cases toInternalUpdate P op with
    | insert pt =>
      dsimp only [alg, mkArithAlg, ArithRAMDynamicProgram.evalUpdate]
      rw [zeroRand_none_of_nonempty hzr _ _ hbs]; rfl
    | delete delH =>
      dsimp only [alg, mkArithAlg, ArithRAMDynamicProgram.evalUpdate]
      rw [zeroRand_none_of_nonempty hzr _ _ hbs]; rfl
  · intro _ P mem op bits _ hP hR hleg
    have hnil : List.ofFn bits = [] := by simp
    rw [hnil]
    obtain ⟨P', out, hsome, hR', hw, hsp, hv⟩ := hStep P mem op hP hR hleg
    exact ⟨P', out, hsome, hR', hw, hsp, fun _ => hv⟩
  · intro _ P mem op _ hP hR _ hleg
    obtain ⟨P', out, hsome, _, _, _, _⟩ := hStep P mem op hP hR hleg
    refine le_trans (b := (0 : ℝ)) ?_ (by positivity)
    norm_cast
    refine Nat.le_zero.mpr (Finset.card_eq_zero.mpr (Finset.eq_empty_iff_forall_notMem.mpr fun bits hmem => ?_))
    have hpred := (Finset.mem_filter.mp hmem).2
    have hnil : List.ofFn bits = [] := by simp
    rw [hnil, hsome] at hpred
    exact hpred trivial

/-! ### 6. Branch 1 (`d = 0`): `O(1)` time, `O(n)` space dynamic diameter RAM program -/

def updateD0Stmt : ArithRAMStmt :=
  .seq (applyHandleUpdateStmt 0)
    (.ite (.intLe (.lit 2) (.readHeap 0 (.lit 6)))
      (.seq (.writeWordHeap 0 (.lit 1) (.lit 1))
        (.seq (.writeWordHeap 0 (.lit 2) (.readHeap 2 (.lit 0)))
          (.seq (.writeWordHeap 0 (.lit 3) (.readHeap 2 (.lit 1)))
            (.writeRealHeap 0 (.lit 0) (.ofInt (.lit 0))))))
      (.seq (.writeWordHeap 0 (.lit 1) (.lit 0))
        (.seq (.writeWordHeap 0 (.lit 2) (.lit 0))
          (.seq (.writeWordHeap 0 (.lit 3) (.lit 0))
            (.writeRealHeap 0 (.lit 0) (.ofInt (.lit 0)))))))

theorem branchD0_theorem {c : ℝ} (hc_gt : 1 < c) {n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    {stepWorkBound spaceBound : ℝ}
    (hWork : (300 : ℝ) ≤ stepWorkBound)
    (hSpace : ((10 * n + 64 : ℕ) : ℝ) ≤ spaceBound) :
    let prog : ArithRAMDynamicProgram := { initStmt := .skip, updateStmt := updateD0Stmt }
    ∃ initOut : ArithRAMExecOutcome,
      prog.evalInit n 0 = some initOut ∧
      let alg := mkArithAlg (d := 0) n prog initOut
      SatisfiesDynamicStorageAndQueryModel 4 1 alg ∧
      SatisfiesMonteCarloGuarantee n t δ c Set.univ alg ∧
      SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg stepWorkBound ∧
      SatisfiesBoundedSpaceBound n t Set.univ alg spaceBound := by
  have hzr : ZeroRandStmt updateD0Stmt := by
    unfold updateD0Stmt applyHandleUpdateStmt forLoopStmt
    repeat' constructor
  let TW := 5; let BW := n + 8; let TR := 2; let BR := 8
  let ReachInv : DynamicPointSet 0 → ArithRAMMemory → Prop := fun P mem =>
    InFootprint TW BW TR BR mem ∧ ∃ hp : HandlePool 0 n, hp.WellFormed P ∧ EncHandlePool hp mem
  refine deterministicRAMBridge hn ht hδ0 hδ1 updateD0Stmt hzr ReachInv
    (by linarith)
    (by have : (1 : ℝ) ≤ ((10 * n + 64 : ℕ) : ℝ) := by exact_mod_cast (by omega : 1 ≤ 10 * n + 64)
        linarith)
    ⟨InFootprint.empty TW BW TR BR, HandlePool.empty 0 n, HandlePool.empty_wellFormed 0 n, encHandlePool_empty 0 n⟩
    ?_
  intro P mem op hP ⟨hfp, hp, hhp, henc⟩ hleg
  have hwf_raw := HandlePool.step_wellFormed hP hhp hleg
  have hexec1 := exec_applyHandleUpdateStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
    le_rfl le_rfl le_rfl (by omega) hP hhp hleg hfp henc
  dsimp only at hwf_raw hexec1
  rcases hstep_eq : hp.step (toInternalUpdate P op) with ⟨hp', rh⟩
  rw [hstep_eq] at hwf_raw hexec1
  dsimp only at hwf_raw hexec1
  obtain ⟨P', happ, hhp'⟩ := hwf_raw
  let PostAns : ArithRAMMemory → Prop := fun mF =>
    EncHandlePool hp' mF ∧
    (∀ h, rh = some h → ArithRAMDynamicProgram.readReturnedHandle mF = some h) ∧
    IsValidFactorCAnswer c P'
      (let a := ArithRAMDynamicProgram.readCachedAnswer mF; { diameterHandles := a.1, cachedDistSq := a.2 })
  have hexec_full := ExecDet.seq' (s₂ := .ite (.intLe (.lit 2) (.readHeap 0 (.lit 6)))
      (.seq (.writeWordHeap 0 (.lit 1) (.lit 1))
        (.seq (.writeWordHeap 0 (.lit 2) (.readHeap 2 (.lit 0)))
          (.seq (.writeWordHeap 0 (.lit 3) (.readHeap 2 (.lit 1)))
            (.writeRealHeap 0 (.lit 0) (.ofInt (.lit 0))))))
      (.seq (.writeWordHeap 0 (.lit 1) (.lit 0))
        (.seq (.writeWordHeap 0 (.lit 2) (.lit 0))
          (.seq (.writeWordHeap 0 (.lit 3) (.lit 0))
            (.writeRealHeap 0 (.lit 0) (.ofInt (.lit 0)))))))
    (Post := PostAns) (C := 280) 70 hexec1 (by omega) (by
    intro m1 ⟨henc1, hret1, _, _⟩ hfp1
    have hw06 := henc1.2.2.1
    have hact1 := henc1.2.2.2.2.1
    refine (ExecDet.ite _ _ _ (C_c := 6) (C_b := 60) (by simp [condExprOps, intExprOps]) ?_ ?_).mono (fun _ hm _ => hm) (by omega)
    · intro hge2_b
      have hsz2 : 2 ≤ hp'.actList.length := by
        simp [evalArithCond, evalIntExpr, wRead] at hw06 hge2_b
        omega
      let h₁ := hp'.actList[0]'(by omega)
      let h₂ := hp'.actList[1]'(by omega)
      refine (ExecDet.seq
        (ExecDet.wWriteEq _ 0 (.lit 1) (.lit 1) 1 1 hfp1 (by omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) )
        fun m2 hm2 hfp2 => by
          subst hm2
          refine ExecDet.seq
            (ExecDet.wWriteEq _ 0 (.lit 2) (.readHeap 2 (.lit 0)) 2 (h₁ : ℤ) hfp2 (by omega) (by omega) (by omega) rfl
              (by change wRead _ 2 0 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]; simpa using (hact1 0 (by omega)).1)
              (by simp [intExprOps]) )
            fun m3 hm3 hfp3 => by
              subst hm3
              refine ExecDet.seq
                (ExecDet.wWriteEq _ 0 (.lit 3) (.readHeap 2 (.lit 1)) 3 (h₂ : ℤ) hfp3 (by omega) (by omega) (by omega) rfl
                  (by change wRead _ 2 1 = _
                      rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
                      simpa using (hact1 1 (by omega)).1)
                  (by simp [intExprOps]) )
                fun m4 hm4 hfp4 => by
                  subst hm4
                  refine ExecDet.rWrite (C := 12) _ 0 (.lit 0) (.ofInt (.lit 0)) 0 0 hfp4 (by omega) le_rfl (by omega) rfl
                    (by simp [evalRealExpr, evalIntExpr]) (by simp [intExprOps, realExprOps]) ?_
                  refine ⟨?_, ?_, ?_⟩
                  · refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
                    · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                      exact henc1.1
                    · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                      exact henc1.2.1
                    · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                      exact henc1.2.2.1
                    · intro i hi; rw [wRead_rWrite]
                      iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
                      exact henc1.2.2.2.1 i hi
                    · intro i hi
                      refine ⟨?_, ?_⟩
                      · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
                        exact (henc1.2.2.2.2.1 i hi).1
                      · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
                        exact (henc1.2.2.2.2.1 i hi).2
                    · intro _ _ c; exact Fin.elim0 c
                  · intro h hr
                    have := hret1 h hr
                    unfold ArithRAMDynamicProgram.readReturnedHandle at this ⊢
                    change (let hv := wRead _ 0 0; if 0 ≤ hv then some hv.toNat else none) = _
                    rw [wRead_rWrite]
                    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                    exact this
                  · have hP'_wf : P'.WellFormed n := applyDynamicUpdate_wellFormed hP hleg happ
                    have hcard_act : P'.activeHandles.card = hp'.actList.length := by
                      rw [← hhp'.2.2.2.1, List.toFinset_card_of_nodup hhp'.2.1]
                    apply validFactorCAnswer_of_handles hP'_wf
                    · intro _; omega
                    · intro _
                      have hh₁_in : h₁ ∈ P'.activeHandles := by
                        rw [← hhp'.2.2.2.1, List.mem_toFinset]; exact List.getElem_mem _
                      have hh₂_in : h₂ ∈ P'.activeHandles := by
                        rw [← hhp'.2.2.2.1, List.mem_toFinset]; exact List.getElem_mem _
                      have hne_12 : h₁ ≠ h₂ := by
                        intro heq
                        have hinj := List.nodup_iff_injective_getElem.mp hhp'.2.1
                        have : (⟨0, by omega⟩ : Fin hp'.actList.length) = ⟨1, by omega⟩ := hinj heq
                        simp at this
                      have hzero_vec : ∀ v : EuclideanSpace ℝ (Fin 0), v = 0 := fun v => by
                        ext i; exact Fin.elim0 i
                      have hdiam0 : indexedEuclideanDiam P'.activeHandles P'.handleCoords = 0 := by
                        unfold indexedEuclideanDiam
                        split_ifs with hne_p
                        · apply le_antisymm
                          · refine Finset.sup'_le _ _ fun xy _ => ?_
                            rw [hzero_vec (P'.handleCoords xy.1), hzero_vec (P'.handleCoords xy.2), sub_self, norm_zero]
                          · obtain ⟨a1, ha1⟩ := hne_p
                            have := Finset.le_sup' (f := fun xy : ℕ × ℕ => ‖P'.handleCoords xy.1 - P'.handleCoords xy.2‖)
                              (show (a1, a1) ∈ P'.activeHandles ×ˢ P'.activeHandles from Finset.mem_product.mpr ⟨ha1, ha1⟩)
                            simpa using this
                        · rfl
                      refine ⟨h₁, h₂, ?_, hne_12, ?_, hh₁_in, hh₂_in, hne_12, ?_, ?_⟩
                      · unfold ArithRAMDynamicProgram.readCachedAnswer
                        have e0 : wRead (H3a.rWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m1 0 1 1) 0 2 (h₁ : ℤ)) 0 3 (h₂ : ℤ)) 0 0 0) 0 1 = 1 := by
                          rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                        have e1 : wRead (H3a.rWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m1 0 1 1) 0 2 (h₁ : ℤ)) 0 3 (h₂ : ℤ)) 0 0 0) 0 2 = (h₁ : ℤ) := by
                          rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                        have e2 : wRead (H3a.rWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m1 0 1 1) 0 2 (h₁ : ℤ)) 0 3 (h₂ : ℤ)) 0 0 0) 0 3 = (h₂ : ℤ) := by
                          rw [wRead_rWrite, wRead_wWrite_self]
                        change (let hp0 := wRead _ 0 1; let a1 := wRead _ 0 2; let a2 := wRead _ 0 3;
                          if hp0 = 1 ∧ 0 ≤ a1 ∧ 0 ≤ a2 then some (a1.toNat, a2.toNat) else none) = some (h₁, h₂)
                        rw [e0, e1, e2]; simp
                      · unfold ArithRAMDynamicProgram.readCachedAnswer
                        change rRead _ 0 0 = _
                        rw [rRead_rWrite_self, hzero_vec (P'.handleCoords h₁), hzero_vec (P'.handleCoords h₂)]
                        simp
                      · rw [hdiam0, zero_div]; positivity
                      · rw [hdiam0, hzero_vec (P'.handleCoords h₁), hzero_vec (P'.handleCoords h₂), sub_self, norm_zero]).mono
        (fun _ hm _ => hm) (by omega)
    · intro hlt2_b
      have hsz1 : hp'.actList.length ≤ 1 := by
        simp [evalArithCond, evalIntExpr, wRead] at hw06 hlt2_b
        omega
      refine (ExecDet.seq
        (ExecDet.wWriteEq _ 0 (.lit 1) (.lit 0) 1 0 hfp1 (by omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) )
        fun m2 hm2 hfp2 => by
          subst hm2
          refine ExecDet.seq
            (ExecDet.wWriteEq _ 0 (.lit 2) (.lit 0) 2 0 hfp2 (by omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) )
            fun m3 hm3 hfp3 => by
              subst hm3
              refine ExecDet.seq
                (ExecDet.wWriteEq _ 0 (.lit 3) (.lit 0) 3 0 hfp3 (by omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) )
                fun m4 hm4 hfp4 => by
                  subst hm4
                  refine ExecDet.rWrite (C := 12) _ 0 (.lit 0) (.ofInt (.lit 0)) 0 0 hfp4 (by omega) le_rfl (by omega) rfl
                    (by simp [evalRealExpr, evalIntExpr]) (by simp [intExprOps, realExprOps]) ?_
                  refine ⟨?_, ?_, ?_⟩
                  · refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
                    · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                      exact henc1.1
                    · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                      exact henc1.2.1
                    · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                      exact henc1.2.2.1
                    · intro i hi; rw [wRead_rWrite]
                      iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
                      exact henc1.2.2.2.1 i hi
                    · intro i hi
                      refine ⟨?_, ?_⟩
                      · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
                        exact (henc1.2.2.2.2.1 i hi).1
                      · rw [wRead_rWrite]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by omega))]
                        exact (henc1.2.2.2.2.1 i hi).2
                    · intro _ _ c; exact Fin.elim0 c
                  · intro h hr
                    have := hret1 h hr
                    unfold ArithRAMDynamicProgram.readReturnedHandle at this ⊢
                    change (let hv := wRead _ 0 0; if 0 ≤ hv then some hv.toNat else none) = _
                    rw [wRead_rWrite]
                    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                    exact this
                  · have hP'_wf : P'.WellFormed n := applyDynamicUpdate_wellFormed hP hleg happ
                    have hcard_act : P'.activeHandles.card = hp'.actList.length := by
                      rw [← hhp'.2.2.2.1, List.toFinset_card_of_nodup hhp'.2.1]
                    apply validFactorCAnswer_of_handles hP'_wf
                    · intro _
                      unfold ArithRAMDynamicProgram.readCachedAnswer
                      refine ⟨?_, ?_⟩
                      · have e0 : wRead (H3a.rWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m1 0 1 0) 0 2 0) 0 3 0) 0 0 0) 0 1 = 0 := by
                          rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                        exact if_neg (fun h => by change wRead _ 0 1 = 1 ∧ _ at h; rw [e0] at h; omega)
                      · change rRead _ 0 0 = 0
                        exact rRead_rWrite_self _ _ _ _
                    · intro _; omega).mono
        (fun _ hm _ => hm) (by omega))
  change ExecDet TW BW TR BR _ updateD0Stmt mem PostAns 280 at hexec_full
  obtain ⟨mF, ⟨hencF, hretF, hvalidF⟩, hfpF, hstF⟩ := hexec_full
  obtain ⟨outR, hrunR, hmemR, hcostR, hspR⟩ := StepTo.to_runArithRAMWithBits hfp.1 hfp.cellCount_le hstF
  have hinp_card : P.activeHandles.card ≤ n := by
    have hcard_eq : P.activeHandles.card = P.activeIds.card := by
      refine Finset.card_bij (fun h _ => P.idOfHandle h)
        (fun h hh => (hP.2.2.1 h hh).1)
        (fun h₁ hh₁ h₂ hh₂ heq => by
          dsimp only at heq; rw [← (hP.2.2.1 h₁ hh₁).2, ← (hP.2.2.1 h₂ hh₂).2, heq])
        (fun pid hpid => ⟨P.handleOfId pid, (hP.2.1 pid hpid).1, (hP.2.1 pid hpid).2⟩)
    rw [hcard_eq]; exact hP.1
  cases op with
  | insert pid extName pt =>
    dsimp only [toInternalUpdate] at hrunR hspR hstep_eq
    have hrh_some : ∃ h, rh = some h := by
      have : (hp.step (.insert pt)).2 = rh := congrArg Prod.snd hstep_eq
      rw [← this]; dsimp [HandlePool.step]; cases hp.freeList <;> exact ⟨_, rfl⟩
    obtain ⟨h_new, hrh_eq⟩ := hrh_some
    have hret_eq : ArithRAMDynamicProgram.readReturnedHandle outR.mem = rh := by
      rw [hmemR, hrh_eq, hretF h_new hrh_eq]
    let ansOut := ArithRAMDynamicProgram.readCachedAnswer outR.mem
    let outStep : DynamicStepOutcome ArithRAMMemory :=
      { nextState := outR.mem
        returnedHandle := rh
        storedAnswer := { diameterHandles := ansOut.1, cachedDistSq := ansOut.2 }
        work := outR.unitCost
        peakSpace := outR.peakCellSpace }
    refine ⟨P', outStep, ?_, ⟨by dsimp [outStep]; rwa [hmemR], hp', hhp', by dsimp [outStep]; rwa [hmemR]⟩, ?_, ?_, ?_⟩
    · simp only [runSingleAdaptiveStep, toInternalUpdate, mkArithAlg,
        ArithRAMDynamicProgram.evalUpdate, ite_true, ite_false, Bool.false_eq_true]
      rw [hrunR]
      dsimp only [Option.map]
      rw [hret_eq, happ]
    · dsimp only [outStep]
      have : (outR.unitCost : ℝ) ≤ 300 := by exact_mod_cast (hcostR.trans (by omega))
      linarith
    · dsimp only [outStep]
      have hsp_nat : outR.peakCellSpace ≤ 10 * n + 64 := by
        refine hspR.trans ?_
        simp only [ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil, List.length_ofFn]
        dsimp only [TW, BW, TR, BR]
        omega
      exact (Nat.cast_le.mpr hsp_nat).trans hSpace
    · dsimp only [outStep, ansOut]; rw [hmemR]; exact hvalidF
  | delete pid =>
    dsimp only [toInternalUpdate] at hrunR hspR hstep_eq
    have hrh_none : rh = none := (congrArg Prod.snd hstep_eq).symm.trans rfl
    let ansOut := ArithRAMDynamicProgram.readCachedAnswer outR.mem
    let outStep : DynamicStepOutcome ArithRAMMemory :=
      { nextState := outR.mem
        returnedHandle := rh
        storedAnswer := { diameterHandles := ansOut.1, cachedDistSq := ansOut.2 }
        work := outR.unitCost
        peakSpace := outR.peakCellSpace }
    refine ⟨P', outStep, ?_, ⟨by dsimp [outStep]; rwa [hmemR], hp', hhp', by dsimp [outStep]; rwa [hmemR]⟩, ?_, ?_, ?_⟩
    · simp only [runSingleAdaptiveStep, toInternalUpdate, mkArithAlg,
        ArithRAMDynamicProgram.evalUpdate, ite_true, ite_false, Bool.false_eq_true]
      rw [hrunR]
      dsimp only [Option.map]
      rw [← hrh_none, happ]
    · dsimp only [outStep]
      have : (outR.unitCost : ℝ) ≤ 300 := by exact_mod_cast (hcostR.trans (by omega))
      linarith
    · dsimp only [outStep]
      have hsp_nat : outR.peakCellSpace ≤ 10 * n + 64 := by
        refine hspR.trans ?_
        simp only [ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil]
        dsimp only [TW, BW, TR, BR]
        omega
      exact (Nat.cast_le.mpr hsp_nat).trans hSpace
    · dsimp only [outStep, ansOut]; rw [hmemR]; exact hvalidF

end UL.Proof.clm_9_1_explicit_tradeoff.H3a2
