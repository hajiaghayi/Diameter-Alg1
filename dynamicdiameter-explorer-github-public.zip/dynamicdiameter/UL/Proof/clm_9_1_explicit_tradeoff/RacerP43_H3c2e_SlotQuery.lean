import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3c2c_EvalTuples

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt RandExec RandExecAt iValAt rValAt cValAt)

/-! ### 1. Option-to-`ℤ` Encoding & `findSome?` Fold Helper -/

def optNatToInt : Option ℕ → ℤ
  | none => -1
  | some x => (x : ℤ)

@[simp] lemma optNatToInt_nonneg_iff (o : Option ℕ) :
    (0 ≤ optNatToInt o) ↔ o.isSome = true := by
  cases o with
  | none => simp [optNatToInt]
  | some x =>
      simp only [optNatToInt, Option.isSome_some, iff_true]
      omega

lemma findSome_finRange_eq_foldl {α : Type} :
    ∀ {R : ℕ} (f : Fin R → Option α),
      (List.finRange R).findSome? f =
        Fin.foldl R (fun acc r => match acc with | some x => some x | none => f r) none
  | 0, _ => by simp
  | R + 1, f => by
      rw [List.finRange_succ_last, List.findSome?_append, List.findSome?_map,
          Fin.foldl_succ_last]
      have ih := findSome_finRange_eq_foldl (fun j : Fin R => f j.castSucc)
      change ((List.finRange R).findSome? (fun j : Fin R => f j.castSucc)).or
          ([Fin.last R].findSome? f) = _
      rw [ih]
      simp only [List.findSome?_cons, List.findSome?_nil]
      cases Fin.foldl R (fun acc (j : Fin R) =>
          match acc with | some x => some x | none => f j.castSucc) none <;>
        cases f (Fin.last R) <;> rfl

lemma latVec_coord_eq_floor {d : ℕ} (M_lat : ℕ) (z : EuclideanSpace ℝ (Fin d)) (i : Fin d) :
    ((Int.floor ((M_lat : ℝ) * euclideanCoord z i + 1 / 2) : ℤ) : ℝ) =
      euclideanCoord (latVec M_lat z) i := by
  dsimp [latVec, latRoundInt]
  rw [UL.Proof_clm_6_1_precision_RaceV30.euclideanCoord_ratPointToEuclidean]
  push_cast
  rfl

/-! ### 2. Single Step `liveSlotQueryStepStmt` of `queryCopyStep` -/

def slotQryWStride (ℓ M₀ cap_q : ℕ) : ℤ :=
  16 + evalWStride ℓ M₀ cap_q

def slotQryRStride (d : ℕ) : ℤ :=
  4 + 3 * (d : ℤ)

def liveSlotQueryStepStmt (scrW scrR tblW tblO tblPts : ℕ)
    (wBaseW wEntryPtBase wOffO wOffPv wQryBase rQryBase : ℤ)
    (R ℓ M₀ d : ℕ) (b_rat : ℚ) : ArithRAMStmt :=
  let N_bktZ : ℤ := ((R * M₀ ^ ℓ : ℕ) : ℤ)
  let wR := wQryBase
  let wTupIdx := wQryBase + 2
  let wInBkt := wQryBase + 3
  let wCurNd := wQryBase + 4
  let wRemRej := wQryBase + 5
  let wCopyAns := wQryBase + 6
  let wEp := wQryBase + 7
  let wTmpOff := wQryBase + 8
  let wEidTmp := wQryBase + 9
  let wSub0 := wQryBase + 10
  let wSub1 := wQryBase + 11
  let wSub2 := wQryBase + 12
  let wEvalBase := wQryBase + 16
  let wOutLen := wEvalBase + 11
  let codesBase := evalCodesOff ℓ M₀ wEvalBase
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  .ite (.or (.intLe (.lit 0) (.readHeap scrW (.lit wCopyAns)))
            (.intEq (.readHeap scrW (.lit wRemRej)) (.lit 0)))
    .skip
    (.ite (.intEq (.readHeap scrW (.lit wInBkt)) (.lit 1))
      (.ite (.intLt (.readHeap scrW (.lit wCurNd)) (.lit 0))
        (.seq (.writeWordHeap scrW (.lit wInBkt) (.lit 0))
              (.writeWordHeap scrW (.lit wCurNd) (.lit (-1))))
        (.seq (.writeWordHeap scrW (.lit wTmpOff)
                (.add (.add bW (.lit (4 + 2 * N_bktZ)))
                      (.mul (.lit 5) (.readHeap scrW (.lit wCurNd)))))
        (.seq (.writeWordHeap scrW (.lit wEidTmp)
                (.readHeap tblW (.add (.readHeap scrW (.lit wTmpOff)) (.lit 2))))
        (.seq (.writeWordHeap scrW (.lit wSub2)
                (.add (.readHeap scrW (.lit wEntryPtBase))
                      (.mul (.readHeap scrW (.lit wEidTmp)) (.lit (d : ℤ)))))
        (.seq (corrGtRegStmt scrW scrR tblO tblPts wSub0 wSub1 rQryBase wOffO wOffPv wSub2 d b_rat)
              (.ite (.intEq (.readHeap scrW (.lit wSub1)) (.lit 1))
                (.seq (.writeWordHeap scrW (.lit wInBkt) (.lit 0))
                (.seq (.writeWordHeap scrW (.lit wCurNd) (.lit (-1)))
                      (.writeWordHeap scrW (.lit wCopyAns) (.readHeap scrW (.lit wEidTmp)))))
                (.ite (.intEq (.sub (.readHeap scrW (.lit wRemRej)) (.lit 1)) (.lit 0))
                  (.seq (.writeWordHeap scrW (.lit wInBkt) (.lit 0))
                  (.seq (.writeWordHeap scrW (.lit wCurNd) (.lit (-1)))
                        (.writeWordHeap scrW (.lit wRemRej) (.lit 0))))
                  (.seq (.writeWordHeap scrW (.lit wCurNd)
                          (.readHeap tblW (.add (.readHeap scrW (.lit wTmpOff)) (.lit 4))))
                  (.seq (.writeWordHeap scrW (.lit wRemRej)
                          (.sub (.readHeap scrW (.lit wRemRej)) (.lit 1)))
                        (.ite (.intLe (.lit 0) (.readHeap scrW (.lit wCurNd)))
                          (.writeWordHeap scrW (.lit wInBkt) (.lit 1))
                          (.writeWordHeap scrW (.lit wInBkt) (.lit 0))))))))))))
      (.ite (.intLt (.readHeap scrW (.lit wTupIdx)) (.readHeap scrW (.lit wOutLen)))
        (.seq (.writeWordHeap scrW (.lit wTmpOff)
                (.add (.add bW (.lit 4))
                      (.mul (.lit 2)
                        (.add (.mul (.readHeap scrW (.lit wR)) (.lit ((M₀ ^ ℓ : ℕ) : ℤ)))
                              (.readHeap scrW (.add (.lit codesBase) (.readHeap scrW (.lit wTupIdx))))))))
        (.seq (.ite (.intEq (.readHeap tblW (.readHeap scrW (.lit wTmpOff)))
                            (.readHeap scrW (.lit wEp)))
                (.writeWordHeap scrW (.lit wCurNd)
                  (.readHeap tblW (.add (.readHeap scrW (.lit wTmpOff)) (.lit 1))))
                (.writeWordHeap scrW (.lit wCurNd) (.lit (-1))))
        (.seq (.writeWordHeap scrW (.lit wTupIdx)
                (.add (.readHeap scrW (.lit wTupIdx)) (.lit 1)))
              (.ite (.intLe (.lit 0) (.readHeap scrW (.lit wCurNd)))
                (.writeWordHeap scrW (.lit wInBkt) (.lit 1))
                (.writeWordHeap scrW (.lit wInBkt) (.lit 0))))))
        .skip))

private def EncQueryStepState (scrW : ℕ) (wQryBase : ℤ)
    (st : ℕ × Bool × ℤ × ℕ × Option ℕ) (m : ArithRAMMemory) : Prop :=
  H3a.wRead m scrW (wQryBase + 2) = (st.1 : ℤ) ∧
  H3a.wRead m scrW (wQryBase + 3) = (if st.2.1 then 1 else 0) ∧
  H3a.wRead m scrW (wQryBase + 4) = st.2.2.1 ∧
  H3a.wRead m scrW (wQryBase + 5) = (st.2.2.2.1 : ℤ) ∧
  H3a.wRead m scrW (wQryBase + 6) = optNatToInt st.2.2.2.2

def liveSlotQueryStepCost (d : ℕ) : ℕ :=
  450 + 130 * d

private theorem exec_liveSlotQueryStepStmt {d TW BW TR BR scrW scrR tblW tblR tblO tblPts : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wEntryPtBase wOffO wOffPv wQryBase rQryBase baseW baseR entryPtBase offO offPv : ℤ)
    {R ℓ M₀ cap_u cap_q B_max : ℕ} (r : Fin R) (b_rat : ℚ)
    (entryPt : ℕ → EuclideanSpace ℝ (Fin d))
    (entryAlive : ℕ → Bool)
    (o p_v : EuclideanSpace ℝ (Fin d)) (hpv_ne : p_v ≠ o)
    (S : LiveSlot R ℓ M₀ d)
    (codes : List (Fin (M₀ ^ ℓ))) (hlen_le : codes.length ≤ cap_q)
    (st : ℕ × Bool × ℤ × ℕ × Option ℕ)
    (hcur_valid : st.2.1 = true → 0 ≤ st.2.2.1 →
      st.2.2.1.toNat < B_max * (R * cap_u) ∧ entryAlive (S.nEid st.2.2.1.toNat) = true)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneW : tblW ≠ scrW) (hneO : tblO ≠ scrR) (hnePts : tblPts ≠ scrR)
    (hwQry : 0 ≤ wQryBase ∧ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ (BW : ℤ))
    (hrQry : 0 ≤ rQryBase ∧ rQryBase + 3 ≤ (BR : ℤ))
    (hdisjBW : wBaseW < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wBaseW)
    (hdisjEP : wEntryPtBase < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wEntryPtBase)
    (hdisjO : wOffO < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wOffO)
    (hdisjPv : wOffPv < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wOffPv)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hEP : H3a.wRead m₀ scrW wEntryPtBase = entryPtBase)
    (hoffO : H3a.wRead m₀ scrW wOffO = offO)
    (hoffPv : H3a.wRead m₀ scrW wOffPv = offPv)
    (hr_r : H3a.wRead m₀ scrW wQryBase = (r.val : ℤ))
    (hep_r : H3a.wRead m₀ scrW (wQryBase + 7) = (S.ep : ℤ))
    (hout_r : H3a.wRead m₀ scrW (wQryBase + 16 + 11) = (codes.length : ℤ))
    (hcodes_r : ∀ (idx : ℕ) (hidx : idx < codes.length),
      H3a.wRead m₀ scrW (evalCodesOff ℓ M₀ (wQryBase + 16) + (idx : ℤ)) =
        @Nat.cast ℤ _ (codes[idx]).val)
    (ho : ∀ c : Fin d, H3a.rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpv : ∀ c : Fin d, H3a.rRead m₀ tblPts (offPv + (c.val : ℤ)) = euclideanCoord p_v c)
    (hEntryPt : ∀ eid : ℕ, entryAlive eid = true →
      entryPt eid ≠ o ∧
      ∀ c : Fin d, H3a.rRead m₀ tblPts (entryPtBase + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
        euclideanCoord (entryPt eid) c)
    (hst : EncQueryStepState scrW wQryBase st m₀)
    (henc : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀) :
    let st' := queryCopyStep entryPt o p_v (b_rat : ℝ) S r codes st
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (liveSlotQueryStepStmt scrW scrR tblW tblO tblPts wBaseW wEntryPtBase wOffO wOffPv wQryBase rQryBase R ℓ M₀ d b_rat)
        m₀ m₁ (liveSlotQueryStepCost d) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncQueryStepState scrW wQryBase st' m₁ ∧
      (∀ w : ℤ,
        (w < wQryBase + 2 ∨ wQryBase + 16 ≤ w ∨ w = wQryBase + 7) →
        H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r_idx : ℤ,
        (r_idx < rQryBase ∨ rQryBase + 3 ≤ r_idx) →
        H3a.rRead m₁ scrR r_idx = H3a.rRead m₀ scrR r_idx) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  classical
  intro st'
  have hstride : slotQryWStride ℓ M₀ cap_q = 16 + evalWStride ℓ M₀ cap_q := rfl
  have heval_ge : 12 ≤ evalWStride ℓ M₀ cap_q := by unfold evalWStride; omega
  rcases st with ⟨tupIdx, inBkt, curNd, remRej, ans⟩
  rcases hst with ⟨htup₀, hinB₀, hcur₀, hrem₀, hans₀⟩
  have ⟨hep_s, _, _, _, hbkt_all, hnd_all⟩ := henc
  -- Outer guard: ans.isSome || decide (remRej = 0)
  by_cases hdone : (ans.isSome || decide (remRej = 0)) = true
  · have hc_done : cValAt 0 inp m₀
        (.or (.intLe (.lit 0) (.readHeap scrW (.lit (wQryBase + 6))))
             (.intEq (.readHeap scrW (.lit (wQryBase + 5))) (.lit 0))) = true := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change (decide (0 ≤ H3a.wRead m₀ scrW (wQryBase + 6)) ||
              decide (H3a.wRead m₀ scrW (wQryBase + 5) = 0)) = true
      rw [hans₀, hrem₀]
      rcases Bool.or_eq_true_iff.mp hdone with his | hr0
      · have h0le : 0 ≤ optNatToInt ans := (optNatToInt_nonneg_iff ans).mpr his
        rw [decide_eq_true h0le, Bool.true_or]
      · have hr0' : remRej = 0 := of_decide_eq_true hr0
        rw [hr0']; simp
    have hst'_eq : st' = (tupIdx, inBkt, curNd, remRej, ans) := by
      dsimp [st', queryCopyStep]
      rw [if_pos hdone]
    refine ⟨m₀,
      (DetExecAt.ite_true (C_c := 25) hc_done
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.skip 0 inp m₀)).mono_cost (by unfold liveSlotQueryStepCost; omega),
      hfp₀, ?_, fun _ _ => rfl, fun _ _ => rfl,
      RadFrameOutside.refl scrW scrR tblW baseW 0 tblR baseR 0 m₀⟩
    rw [hst'_eq]; exact ⟨htup₀, hinB₀, hcur₀, hrem₀, hans₀⟩
  · have hdone_f : (ans.isSome || decide (remRej = 0)) = false := Bool.eq_false_iff.mpr hdone
    have hans_none : ans = none := by
      cases ans with
      | none => rfl
      | some _ => simp at hdone
    have hrem_pos : remRej ≠ 0 := by
      intro hr0; subst hr0; simp at hdone
    have hc_done : cValAt 0 inp m₀
        (.or (.intLe (.lit 0) (.readHeap scrW (.lit (wQryBase + 6))))
             (.intEq (.readHeap scrW (.lit (wQryBase + 5))) (.lit 0))) = false := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change (decide (0 ≤ H3a.wRead m₀ scrW (wQryBase + 6)) ||
              decide (H3a.wRead m₀ scrW (wQryBase + 5) = 0)) = false
      rw [hans₀, hans_none, hrem₀]
      simp only [optNatToInt, decide_eq_false (by omega : ¬ (0 : ℤ) ≤ -1), Bool.false_or]
      exact decide_eq_false (by omega)
    cases inBkt with
    | true =>
        have hc_inB : cValAt 0 inp m₀ (.intEq (.readHeap scrW (.lit (wQryBase + 3))) (.lit 1)) = true := by
          simp only [cValAt, evalArithCond, evalIntExpr]
          change decide (H3a.wRead m₀ scrW (wQryBase + 3) = 1) = true
          rw [hinB₀]; simp
        by_cases hneg : curNd < 0
        · have hc_neg : cValAt 0 inp m₀ (.intLt (.readHeap scrW (.lit (wQryBase + 4))) (.lit 0)) = true := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m₀ scrW (wQryBase + 4) < 0) = true
            rw [hcur₀]; exact decide_eq_true hneg
          let m1 := H3a.wWrite m₀ scrW (wQryBase + 3) 0
          let m2 := H3a.wWrite m1 scrW (wQryBase + 4) (-1)
          have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0)) m₀ m1 10 :=
            DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wQryBase + 3)) (.lit 0) rfl rfl
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 4)) (.lit (-1))) m1 m2 10 :=
            DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wQryBase + 4)) (.lit (-1)) rfl rfl
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hfp2 : InFootprint TW BW TR BR m2 :=
            InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
          have hfr2 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m2 :=
            (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ _ _).trans
              (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m1 _ _)
          have hst'_eq : st' = (tupIdx, false, -1, remRej, ans) := by
            dsimp [st', queryCopyStep]
            rw [if_neg hdone, if_pos hneg]
          refine ⟨m2,
            (DetExecAt.ite_false (C_c := 25) hc_done
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.ite_true (C_c := 10) hc_inB
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                (DetExecAt.ite_true (C_c := 10) hc_neg
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                  (hd1.seq hd2)))).mono_cost (by unfold liveSlotQueryStepCost; omega),
            hfp2, ?_, ?_, fun _ _ => rfl, hfr2⟩
          · rw [hst'_eq]
            refine ⟨?_, ?_, wRead_wWrite_self _ _ _ _, ?_, ?_⟩
            · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact htup₀
            · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
            · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hrem₀
            · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hans₀
          · intro w hw
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        · have hcur_nonneg : 0 ≤ curNd := by omega
          obtain ⟨hnd_pool, halive_eid⟩ := hcur_valid rfl hcur_nonneg
          let nd := curNd.toNat
          have hcur_cast : (nd : ℤ) = curNd := Int.toNat_of_nonneg hcur_nonneg
          let eid := S.nEid nd
          obtain ⟨heid_ne_o, heid_coords⟩ := hEntryPt eid halive_eid
          rcases hnd_all nd hnd_pool with ⟨_, _, hnEid_nd, _, hnNext_nd⟩
          have hc_neg : cValAt 0 inp m₀ (.intLt (.readHeap scrW (.lit (wQryBase + 4))) (.lit 0)) = false := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m₀ scrW (wQryBase + 4) < 0) = false
            rw [hcur₀]; exact decide_eq_false hneg
          let offN := slotNodeOff R ℓ M₀ baseW nd
          let offCand : ℤ := entryPtBase + (eid : ℤ) * (d : ℤ)
          let m1 := H3a.wWrite m₀ scrW (wQryBase + 8) offN
          let m2 := H3a.wWrite m1 scrW (wQryBase + 9) (eid : ℤ)
          let m3 := H3a.wWrite m2 scrW (wQryBase + 12) offCand
          have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 8))
              (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))))
                    (.mul (.lit 5) (.readHeap scrW (.lit (wQryBase + 4)))))) m₀ m1 25 :=
            DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wQryBase + 8)) _ rfl
              (by change (H3a.wRead m₀ scrW wBaseW + (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))) +
                    5 * H3a.wRead m₀ scrW (wQryBase + 4) = offN
                  rw [hbW, hcur₀, ← hcur_cast]; dsimp [offN, slotNodeOff]; ring)
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 9))
              (.readHeap tblW (.add (.readHeap scrW (.lit (wQryBase + 8))) (.lit 2)))) m1 m2 20 :=
            DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wQryBase + 9)) _ rfl
              (by change H3a.wRead m1 tblW (H3a.wRead m1 scrW (wQryBase + 8) + 2) = (eid : ℤ)
                  rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl hneW), hnEid_nd])
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 12))
              (.add (.readHeap scrW (.lit wEntryPtBase))
                    (.mul (.readHeap scrW (.lit (wQryBase + 9))) (.lit (d : ℤ))))) m2 m3 25 :=
            DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wQryBase + 12)) _ rfl
              (by change H3a.wRead m2 scrW wEntryPtBase + H3a.wRead m2 scrW (wQryBase + 9) * (d : ℤ) = offCand
                  rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hEP, wRead_wWrite_self])
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hfp3 : InFootprint TW BW TR BR m3 :=
            InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW (by omega) (by omega))
              hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
          have hfr3 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m3 :=
            ((RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ _ _).trans
              (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m1 _ _)).trans
              (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m2 _ _)
          obtain ⟨m4, hd4, hfp4, hcmp4, hkW4, hkR4, hfr4⟩ :=
            exec_corrGtRegStmt (tblW := tblW) (tblR := tblR) inp
              (wQryBase + 10) (wQryBase + 11) rQryBase wOffO wOffPv (wQryBase + 12)
              offO offPv offCand baseW baseR b_rat o p_v (entryPt eid) hpv_ne heid_ne_o
              hfp3 hscrW hscrR ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ hrQry hneO hnePts
              ⟨by omega, by omega, by omega⟩
              (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hoffO)
              (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hoffPv)
              (wRead_wWrite_self _ _ _ _)
              (fun c => by rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]; exact ho c)
              (fun c => by rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]; exact hpv c)
              (fun c => by rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]; exact heid_coords c)
          have hfr04 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m4 := hfr3.trans hfr4
          have hk04_scr : ∀ w : ℤ,
              w ≠ wQryBase + 8 → w ≠ wQryBase + 9 → w ≠ wQryBase + 10 →
              w ≠ wQryBase + 11 → w ≠ wQryBase + 12 →
              H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w := by
            intro w h8 h9 h10 h11 h12
            rw [hkW4 w h10 h11,
                wRead_wWrite_of_ne _ _ (Or.inr h12),
                wRead_wWrite_of_ne _ _ (Or.inr h9),
                wRead_wWrite_of_ne _ _ (Or.inr h8)]
          let postCorrStmt : ArithRAMStmt :=
            .ite (.intEq (.readHeap scrW (.lit (wQryBase + 11))) (.lit 1))
              (.seq (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0))
              (.seq (.writeWordHeap scrW (.lit (wQryBase + 4)) (.lit (-1)))
                    (.writeWordHeap scrW (.lit (wQryBase + 6)) (.readHeap scrW (.lit (wQryBase + 9))))))
              (.ite (.intEq (.sub (.readHeap scrW (.lit (wQryBase + 5))) (.lit 1)) (.lit 0))
                (.seq (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0))
                (.seq (.writeWordHeap scrW (.lit (wQryBase + 4)) (.lit (-1)))
                      (.writeWordHeap scrW (.lit (wQryBase + 5)) (.lit 0))))
                (.seq (.writeWordHeap scrW (.lit (wQryBase + 4))
                        (.readHeap tblW (.add (.readHeap scrW (.lit (wQryBase + 8))) (.lit 4))))
                (.seq (.writeWordHeap scrW (.lit (wQryBase + 5))
                        (.sub (.readHeap scrW (.lit (wQryBase + 5))) (.lit 1)))
                      (.ite (.intLe (.lit 0) (.readHeap scrW (.lit (wQryBase + 4))))
                        (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 1))
                        (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0))))))
          have hpost : ∃ m5 : ArithRAMMemory,
              DetExec inp postCorrStmt m4 m5 100 ∧
              InFootprint TW BW TR BR m5 ∧
              EncQueryStepState scrW wQryBase st' m5 ∧
              (∀ w : ℤ,
                (w < wQryBase + 2 ∨ wQryBase + 16 ≤ w ∨ w = wQryBase + 7) →
                H3a.wRead m5 scrW w = H3a.wRead m₀ scrW w) ∧
              (∀ r_idx : ℤ,
                (r_idx < rQryBase ∨ rQryBase + 3 ≤ r_idx) →
                H3a.rRead m5 scrR r_idx = H3a.rRead m₀ scrR r_idx) ∧
              RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m5 := by
            by_cases hacc : (b_rat : ℝ) < radialCorrelation o p_v (entryPt eid)
            · have hc_acc : cValAt 0 inp m4 (.intEq (.readHeap scrW (.lit (wQryBase + 11))) (.lit 1)) = true := by
                simp only [cValAt, evalArithCond, evalIntExpr]
                change decide (H3a.wRead m4 scrW (wQryBase + 11) = 1) = true
                rw [hcmp4, if_pos hacc]; decide
              have heid_m4 : H3a.wRead m4 scrW (wQryBase + 9) = (eid : ℤ) := by
                rw [hkW4 _ (by omega) (by omega),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
              let m4a := H3a.wWrite m4 scrW (wQryBase + 3) 0
              let m4b := H3a.wWrite m4a scrW (wQryBase + 4) (-1)
              let m4c := H3a.wWrite m4b scrW (wQryBase + 6) (eid : ℤ)
              have hda : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0)) m4 m4a 10 :=
                DetExecAt.writeWordHeap 0 inp m4 scrW (.lit (wQryBase + 3)) (.lit 0) rfl rfl
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              have hdb : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 4)) (.lit (-1))) m4a m4b 10 :=
                DetExecAt.writeWordHeap 0 inp m4a scrW (.lit (wQryBase + 4)) (.lit (-1)) rfl rfl
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              have hdc : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 6))
                  (.readHeap scrW (.lit (wQryBase + 9)))) m4b m4c 15 :=
                DetExecAt.writeWordHeap 0 inp m4b scrW (.lit (wQryBase + 6)) _ rfl
                  (by change H3a.wRead m4b scrW (wQryBase + 9) = _
                      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact heid_m4)
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              have hst'_eq : st' = (tupIdx, false, -1, remRej, some eid) := by
                dsimp [st', queryCopyStep]
                rw [if_neg hdone, if_neg hneg, if_pos hacc]
              refine ⟨m4c,
                (DetExecAt.ite_true (C_c := 10) hc_acc
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                  (hda.seq (hdb.seq hdc))).mono_cost (by omega),
                InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp4 hscrW (by omega) (by omega))
                  hscrW (by omega) (by omega)) hscrW (by omega) (by omega),
                ?_, ?_, ?_,
                ((hfr04.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4 _ _)).trans
                  (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4a _ _)).trans
                  (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4b _ _)⟩
              · rw [hst'_eq]
                refine ⟨?_, ?_, ?_, ?_, wRead_wWrite_self _ _ _ _⟩
                · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      hk04_scr _ (by omega) (by omega) (by omega) (by omega) (by omega)]
                  exact htup₀
                · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
                · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      hk04_scr _ (by omega) (by omega) (by omega) (by omega) (by omega)]
                  exact hrem₀
              · intro w hw
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                exact hk04_scr w (by omega) (by omega) (by omega) (by omega) (by omega)
              · intro r_idx hr_out
                rw [rRead_wWrite, rRead_wWrite, rRead_wWrite, hkR4 r_idx hr_out]
                rfl
            · have hc_acc : cValAt 0 inp m4 (.intEq (.readHeap scrW (.lit (wQryBase + 11))) (.lit 1)) = false := by
                simp only [cValAt, evalArithCond, evalIntExpr]
                change decide (H3a.wRead m4 scrW (wQryBase + 11) = 1) = false
                rw [hcmp4, if_neg hacc]; decide
              have hrem_m4 : H3a.wRead m4 scrW (wQryBase + 5) = (remRej : ℤ) :=
                (hk04_scr _ (by omega) (by omega) (by omega) (by omega) (by omega)).trans hrem₀
              by_cases hr1 : remRej - 1 = 0
              · have hrem1 : remRej = 1 := by omega
                have hc_r1 : cValAt 0 inp m4
                    (.intEq (.sub (.readHeap scrW (.lit (wQryBase + 5))) (.lit 1)) (.lit 0)) = true := by
                  simp only [cValAt, evalArithCond, evalIntExpr]
                  change decide (H3a.wRead m4 scrW (wQryBase + 5) - 1 = 0) = true
                  rw [hrem_m4, hrem1]; decide
                let m4a := H3a.wWrite m4 scrW (wQryBase + 3) 0
                let m4b := H3a.wWrite m4a scrW (wQryBase + 4) (-1)
                let m4c := H3a.wWrite m4b scrW (wQryBase + 5) 0
                have hda : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0)) m4 m4a 10 :=
                  DetExecAt.writeWordHeap 0 inp m4 scrW (.lit (wQryBase + 3)) (.lit 0) rfl rfl
                    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                have hdb : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 4)) (.lit (-1))) m4a m4b 10 :=
                  DetExecAt.writeWordHeap 0 inp m4a scrW (.lit (wQryBase + 4)) (.lit (-1)) rfl rfl
                    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                have hdc : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 5)) (.lit 0)) m4b m4c 10 :=
                  DetExecAt.writeWordHeap 0 inp m4b scrW (.lit (wQryBase + 5)) (.lit 0) rfl rfl
                    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                have hst'_eq : st' = (tupIdx, false, -1, 0, none) := by
                  dsimp [st', queryCopyStep]
                  rw [if_neg hdone, if_neg hneg, if_neg hacc, if_pos hr1]
                refine ⟨m4c,
                  (DetExecAt.ite_false (C_c := 10) hc_acc
                    (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                    (DetExecAt.ite_true (C_c := 15) hc_r1
                      (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                      (hda.seq (hdb.seq hdc)))).mono_cost (by omega),
                  InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp4 hscrW (by omega) (by omega))
                    hscrW (by omega) (by omega)) hscrW (by omega) (by omega),
                  ?_, ?_, ?_,
                  ((hfr04.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4 _ _)).trans
                    (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4a _ _)).trans
                    (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4b _ _)⟩
                · rw [hst'_eq]
                  refine ⟨?_, ?_, ?_, wRead_wWrite_self _ _ _ _, ?_⟩
                  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        hk04_scr _ (by omega) (by omega) (by omega) (by omega) (by omega)]
                    exact htup₀
                  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
                  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        hk04_scr _ (by omega) (by omega) (by omega) (by omega) (by omega),
                        hans₀, hans_none]
                · intro w hw
                  rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                  exact hk04_scr w (by omega) (by omega) (by omega) (by omega) (by omega)
                · intro r_idx hr_out
                  rw [rRead_wWrite, rRead_wWrite, rRead_wWrite, hkR4 r_idx hr_out]
                  rfl
              · have hc_r1 : cValAt 0 inp m4
                    (.intEq (.sub (.readHeap scrW (.lit (wQryBase + 5))) (.lit 1)) (.lit 0)) = false := by
                  simp only [cValAt, evalArithCond, evalIntExpr]
                  change decide (H3a.wRead m4 scrW (wQryBase + 5) - 1 = 0) = false
                  rw [hrem_m4]; exact decide_eq_false (by omega)
                let nx := S.nNext nd
                have hoffN_m4 : H3a.wRead m4 scrW (wQryBase + 8) = offN := by
                  rw [hkW4 _ (by omega) (by omega),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                let m4a := H3a.wWrite m4 scrW (wQryBase + 4) nx
                let m4b := H3a.wWrite m4a scrW (wQryBase + 5) (((remRej - 1 : ℕ) : ℤ))
                have hda : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 4))
                    (.readHeap tblW (.add (.readHeap scrW (.lit (wQryBase + 8))) (.lit 4)))) m4 m4a 20 :=
                  DetExecAt.writeWordHeap 0 inp m4 scrW (.lit (wQryBase + 4)) _ rfl
                    (by change H3a.wRead m4 tblW (H3a.wRead m4 scrW (wQryBase + 8) + 4) = nx
                        rw [hoffN_m4, hfr04.1 tblW _ hneW (Or.inr (by omega))]; exact hnNext_nd)
                    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                have hdb : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 5))
                    (.sub (.readHeap scrW (.lit (wQryBase + 5))) (.lit 1))) m4a m4b 20 :=
                  DetExecAt.writeWordHeap 0 inp m4a scrW (.lit (wQryBase + 5)) _ rfl
                    (by change H3a.wRead m4a scrW (wQryBase + 5) - 1 = ((remRej - 1 : ℕ) : ℤ)
                        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hrem_m4]; omega)
                    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                let m4c := H3a.wWrite m4b scrW (wQryBase + 3) (if decide (0 ≤ nx) then 1 else 0)
                have hdc : DetExec inp
                    (.ite (.intLe (.lit 0) (.readHeap scrW (.lit (wQryBase + 4))))
                      (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 1))
                      (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0)))
                    m4b m4c 25 := by
                  by_cases hnx0 : 0 ≤ nx
                  · have hc_nx : cValAt 0 inp m4b (.intLe (.lit 0) (.readHeap scrW (.lit (wQryBase + 4)))) = true := by
                      simp only [cValAt, evalArithCond, evalIntExpr]
                      change decide (0 ≤ H3a.wRead m4b scrW (wQryBase + 4)) = true
                      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                      exact decide_eq_true hnx0
                    have hd_1 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 1)) m4b m4c 10 :=
                      DetExecAt.writeWordHeap 0 inp m4b scrW (.lit (wQryBase + 3)) (.lit 1) rfl
                        (by dsimp; rw [decide_eq_true hnx0]; rfl)
                        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                    exact (DetExecAt.ite_true (C_c := 10) hc_nx
                      (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                      hd_1).mono_cost (by omega)
                  · have hc_nx : cValAt 0 inp m4b (.intLe (.lit 0) (.readHeap scrW (.lit (wQryBase + 4)))) = false := by
                      simp only [cValAt, evalArithCond, evalIntExpr]
                      change decide (0 ≤ H3a.wRead m4b scrW (wQryBase + 4)) = false
                      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                      exact decide_eq_false hnx0
                    have hd_0 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0)) m4b m4c 10 :=
                      DetExecAt.writeWordHeap 0 inp m4b scrW (.lit (wQryBase + 3)) (.lit 0) rfl
                        (by dsimp; rw [decide_eq_false hnx0]; rfl)
                        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                    exact (DetExecAt.ite_false (C_c := 10) hc_nx
                      (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                      hd_0).mono_cost (by omega)
                have hst'_eq : st' = (tupIdx, decide (0 ≤ nx), nx, remRej - 1, none) := by
                  dsimp [st', queryCopyStep]
                  rw [if_neg hdone, if_neg hneg, if_neg hacc, if_neg hr1]
                refine ⟨m4c,
                  (DetExecAt.ite_false (C_c := 10) hc_acc
                    (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                    (DetExecAt.ite_false (C_c := 15) hc_r1
                      (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                      (hda.seq (hdb.seq hdc)))).mono_cost (by omega),
                  InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp4 hscrW (by omega) (by omega))
                    hscrW (by omega) (by omega)) hscrW (by omega) (by omega),
                  ?_, ?_, ?_,
                  ((hfr04.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4 _ _)).trans
                    (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4a _ _)).trans
                    (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4b _ _)⟩
                · rw [hst'_eq]
                  refine ⟨?_, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_⟩
                  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        hk04_scr _ (by omega) (by omega) (by omega) (by omega) (by omega)]
                    exact htup₀
                  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                        hk04_scr _ (by omega) (by omega) (by omega) (by omega) (by omega),
                        hans₀, hans_none]
                · intro w hw
                  rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                  exact hk04_scr w (by omega) (by omega) (by omega) (by omega) (by omega)
                · intro r_idx hr_out
                  rw [rRead_wWrite, rRead_wWrite, rRead_wWrite, hkR4 r_idx hr_out]
                  rfl
          obtain ⟨m5, hd5, hfp5, hst5, hkW5, hkR5, hfr5⟩ := hpost
          refine ⟨m5,
            (DetExecAt.ite_false (C_c := 25) hc_done
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.ite_true (C_c := 10) hc_inB
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                (DetExecAt.ite_false (C_c := 10) hc_neg
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                  (hd1.seq (hd2.seq (hd3.seq (hd4.seq hd5))))))).mono_cost
              (by unfold liveSlotQueryStepCost; omega),
            hfp5, hst5, hkW5, hkR5, hfr5⟩
    | false =>
        have hc_inB : cValAt 0 inp m₀ (.intEq (.readHeap scrW (.lit (wQryBase + 3))) (.lit 1)) = false := by
          simp only [cValAt, evalArithCond, evalIntExpr]
          change decide (H3a.wRead m₀ scrW (wQryBase + 3) = 1) = false
          rw [hinB₀]; simp
        by_cases hlt : tupIdx < codes.length
        · have hc_lt : cValAt 0 inp m₀
              (.intLt (.readHeap scrW (.lit (wQryBase + 2)))
                      (.readHeap scrW (.lit (wQryBase + 16 + 11)))) = true := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m₀ scrW (wQryBase + 2) < H3a.wRead m₀ scrW (wQryBase + 16 + 11)) = true
            rw [htup₀, hout_r]; exact decide_eq_true (by exact_mod_cast hlt)
          let code := codes[tupIdx]
          let bkt := r.val * M₀ ^ ℓ + code.val
          have hbkt_lt : bkt < R * M₀ ^ ℓ := by
            dsimp [bkt]
            calc r.val * M₀ ^ ℓ + code.val
                < r.val * M₀ ^ ℓ + M₀ ^ ℓ := by have := code.isLt; omega
              _ = (r.val + 1) * M₀ ^ ℓ := by ring
              _ ≤ R * M₀ ^ ℓ := Nat.mul_le_mul_right _ r.isLt
          rcases hbkt_all bkt hbkt_lt with ⟨hhEp_b, hhVal_b⟩
          let offH := slotBktOff baseW bkt
          let hd := S.effHead bkt
          let m1 := H3a.wWrite m₀ scrW (wQryBase + 8) offH
          have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 8))
              (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4))
                    (.mul (.lit 2)
                      (.add (.mul (.readHeap scrW (.lit wQryBase)) (.lit ((M₀ ^ ℓ : ℕ) : ℤ)))
                            (.readHeap scrW (.add (.lit (evalCodesOff ℓ M₀ (wQryBase + 16)))
                                                  (.readHeap scrW (.lit (wQryBase + 2)))))))))
              m₀ m1 45 :=
            DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wQryBase + 8)) _ rfl
              (by change (H3a.wRead m₀ scrW wBaseW + 4) +
                    2 * (H3a.wRead m₀ scrW wQryBase * ((M₀ ^ ℓ : ℕ) : ℤ) +
                      H3a.wRead m₀ scrW (evalCodesOff ℓ M₀ (wQryBase + 16) + H3a.wRead m₀ scrW (wQryBase + 2))) = offH
                  rw [hbW, hr_r, htup₀, hcodes_r tupIdx hlt]
                  dsimp [offH, slotBktOff, bkt, code])
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          let m2 := H3a.wWrite m1 scrW (wQryBase + 4) hd
          have hd2 : DetExec inp
              (.ite (.intEq (.readHeap tblW (.readHeap scrW (.lit (wQryBase + 8))))
                            (.readHeap scrW (.lit (wQryBase + 7))))
                (.writeWordHeap scrW (.lit (wQryBase + 4))
                  (.readHeap tblW (.add (.readHeap scrW (.lit (wQryBase + 8))) (.lit 1))))
                (.writeWordHeap scrW (.lit (wQryBase + 4)) (.lit (-1))))
              m1 m2 40 := by
            by_cases he : S.hEp bkt = S.ep
            · have hc_e : cValAt 0 inp m1
                  (.intEq (.readHeap tblW (.readHeap scrW (.lit (wQryBase + 8))))
                          (.readHeap scrW (.lit (wQryBase + 7)))) = true := by
                simp only [cValAt, evalArithCond, evalIntExpr]
                change decide (H3a.wRead m1 tblW (H3a.wRead m1 scrW (wQryBase + 8)) =
                  H3a.wRead m1 scrW (wQryBase + 7)) = true
                rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl hneW), hhEp_b,
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hep_r, he]
                exact decide_eq_true rfl
              have hhd_eq : hd = S.hVal bkt := by dsimp [hd, LiveSlot.effHead]; rw [if_pos he]
              have hd_t : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 4))
                  (.readHeap tblW (.add (.readHeap scrW (.lit (wQryBase + 8))) (.lit 1)))) m1 m2 20 :=
                DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wQryBase + 4)) _ rfl
                  (by change H3a.wRead m1 tblW (H3a.wRead m1 scrW (wQryBase + 8) + 1) = hd
                      rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl hneW), hhVal_b, hhd_eq])
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              exact (DetExecAt.ite_true (C_c := 15) hc_e
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                hd_t).mono_cost (by omega)
            · have hc_e : cValAt 0 inp m1
                  (.intEq (.readHeap tblW (.readHeap scrW (.lit (wQryBase + 8))))
                          (.readHeap scrW (.lit (wQryBase + 7)))) = false := by
                simp only [cValAt, evalArithCond, evalIntExpr]
                change decide (H3a.wRead m1 tblW (H3a.wRead m1 scrW (wQryBase + 8)) =
                  H3a.wRead m1 scrW (wQryBase + 7)) = false
                rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl hneW), hhEp_b,
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hep_r]
                exact decide_eq_false (by omega)
              have hhd_eq : hd = -1 := by dsimp [hd, LiveSlot.effHead]; rw [if_neg he]
              have hd_f : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 4)) (.lit (-1))) m1 m2 10 :=
                DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wQryBase + 4)) (.lit (-1)) rfl
                  (by change (-1 : ℤ) = hd; rw [hhd_eq])
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              exact (DetExecAt.ite_false (C_c := 15) hc_e
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                hd_f).mono_cost (by omega)
          let m3 := H3a.wWrite m2 scrW (wQryBase + 2) ((tupIdx + 1 : ℕ) : ℤ)
          have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 2))
              (.add (.readHeap scrW (.lit (wQryBase + 2))) (.lit 1))) m2 m3 20 :=
            DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wQryBase + 2)) _ rfl
              (by change H3a.wRead m2 scrW (wQryBase + 2) + 1 = _
                  rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htup₀]; push_cast; ring)
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          let m4 := H3a.wWrite m3 scrW (wQryBase + 3) (if decide (0 ≤ hd) then 1 else 0)
          have hd4 : DetExec inp
              (.ite (.intLe (.lit 0) (.readHeap scrW (.lit (wQryBase + 4))))
                (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 1))
                (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0)))
              m3 m4 25 := by
            by_cases hhd0 : 0 ≤ hd
            · have hc_hd : cValAt 0 inp m3 (.intLe (.lit 0) (.readHeap scrW (.lit (wQryBase + 4)))) = true := by
                simp only [cValAt, evalArithCond, evalIntExpr]
                change decide (0 ≤ H3a.wRead m3 scrW (wQryBase + 4)) = true
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                exact decide_eq_true hhd0
              have hd_1 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 1)) m3 m4 10 :=
                DetExecAt.writeWordHeap 0 inp m3 scrW (.lit (wQryBase + 3)) (.lit 1) rfl
                  (by dsimp; rw [decide_eq_true hhd0]; rfl)
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              exact (DetExecAt.ite_true (C_c := 10) hc_hd
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                hd_1).mono_cost (by omega)
            · have hc_hd : cValAt 0 inp m3 (.intLe (.lit 0) (.readHeap scrW (.lit (wQryBase + 4)))) = false := by
                simp only [cValAt, evalArithCond, evalIntExpr]
                change decide (0 ≤ H3a.wRead m3 scrW (wQryBase + 4)) = false
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                exact decide_eq_false hhd0
              have hd_0 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0)) m3 m4 10 :=
                DetExecAt.writeWordHeap 0 inp m3 scrW (.lit (wQryBase + 3)) (.lit 0) rfl
                  (by dsimp; rw [decide_eq_false hhd0]; rfl)
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              exact (DetExecAt.ite_false (C_c := 10) hc_hd
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                hd_0).mono_cost (by omega)
          have hfp4 : InFootprint TW BW TR BR m4 :=
            InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite
              (InFootprint.wWrite hfp₀ hscrW (by omega) (by omega))
              hscrW (by omega) (by omega)) hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
          have hfr4 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m4 :=
            (((RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ _ _).trans
              (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m1 _ _)).trans
              (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m2 _ _)).trans
              (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m3 _ _)
          have hst'_eq : st' = (tupIdx + 1, decide (0 ≤ hd), hd, remRej, none) := by
            dsimp [st', queryCopyStep]
            rw [if_neg hdone, dif_pos hlt]
          refine ⟨m4,
            (DetExecAt.ite_false (C_c := 25) hc_done
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.ite_false (C_c := 10) hc_inB
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                (DetExecAt.ite_true (fB := .skip) (C_c := 15) hc_lt
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                  (hd1.seq (hd2.seq (hd3.seq hd4)))))).mono_cost
              (by unfold liveSlotQueryStepCost; omega),
            hfp4, ?_, ?_, fun _ _ => rfl, hfr4⟩
          · rw [hst'_eq]
            refine ⟨?_, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_⟩
            · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
            · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
            · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hrem₀
            · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hans₀, hans_none]
          · intro w hw
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        · have hc_lt : cValAt 0 inp m₀
              (.intLt (.readHeap scrW (.lit (wQryBase + 2)))
                      (.readHeap scrW (.lit (wQryBase + 16 + 11)))) = false := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m₀ scrW (wQryBase + 2) < H3a.wRead m₀ scrW (wQryBase + 16 + 11)) = false
            rw [htup₀, hout_r]; exact decide_eq_false (by omega)
          have hst'_eq : st' = (tupIdx, false, curNd, remRej, ans) := by
            dsimp [st', queryCopyStep]
            rw [if_neg hdone, dif_neg hlt]
          refine ⟨m₀,
            (DetExecAt.ite_false (C_c := 25) hc_done
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.ite_false (C_c := 10) hc_inB
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                (DetExecAt.ite_false (C_c := 15) hc_lt
                  (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                  (DetExecAt.skip 0 inp m₀)))).mono_cost
              (by unfold liveSlotQueryStepCost; omega),
            hfp₀, ?_, fun _ _ => rfl, fun _ _ => rfl,
            RadFrameOutside.refl scrW scrR tblW baseW 0 tblR baseR 0 m₀⟩
          rw [hst'_eq]; exact ⟨htup₀, hinB₀, hcur₀, hrem₀, hans₀⟩

/-! ### 3. Full Copy Scan (`liveSlotQueryCopyStmt`) & Full Slot Query (`liveSlotQueryStmt`) -/

def copyVecToHeapStmt (scrW tblSrc tblDst : ℕ) (wCtr wOffSrc wOffDst : ℤ) (N : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit wCtr) (.lit 0))
    (.repeatN (.lit (N : ℤ))
      (.seq (.writeRealHeap tblDst
              (.add (.readHeap scrW (.lit wOffDst)) (.readHeap scrW (.lit wCtr)))
              (.readRealHeap tblSrc (.add (.readHeap scrW (.lit wOffSrc)) (.readHeap scrW (.lit wCtr)))))
            (.writeWordHeap scrW (.lit wCtr)
              (.add (.readHeap scrW (.lit wCtr)) (.lit 1)))))

theorem exec_copyVecToHeapStmt {d TW BW TR BR scrW scrR tblSrc tblDst tblW : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCtr wOffSrc wOffDst offSrc offDst baseW : ℤ) (N : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htblDst : tblDst < TR)
    (hneDstScr : tblDst ≠ scrR)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (hrDst : 0 ≤ offDst ∧ offDst + (N : ℤ) ≤ (BR : ℤ))
    (hneCtrSrc : wCtr ≠ wOffSrc) (hneCtrDst : wCtr ≠ wOffDst)
    (hdisjSrcDst : tblSrc ≠ tblDst ∨ offSrc + (N : ℤ) ≤ offDst ∨ offDst + (N : ℤ) ≤ offSrc)
    (hoffSrc : H3a.wRead m₀ scrW wOffSrc = offSrc)
    (hoffDst : H3a.wRead m₀ scrW wOffDst = offDst) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (copyVecToHeapStmt scrW tblSrc tblDst wCtr wOffSrc wOffDst N) m₀ m₁ (20 + 35 * N) ∧
      InFootprint TW BW TR BR m₁ ∧
      (∀ c : ℕ, c < N → H3a.rRead m₁ tblDst (offDst + (c : ℤ)) = H3a.rRead m₀ tblSrc (offSrc + (c : ℤ))) ∧
      (∀ w, w ≠ wCtr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblDst offDst (N : ℤ) m₀ m₁ := by
  let m_init := H3a.wWrite m₀ scrW wCtr 0
  have hd_init : DetExec inp (.writeWordHeap scrW (.lit wCtr) (.lit 0)) m₀ m_init 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wCtr) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_init : InFootprint TW BW TR BR m_init := InFootprint.wWrite hfp₀ hscrW hwCtr.1 hwCtr.2
  let Inv : ℕ → ArithRAMMemory → Prop := fun i m =>
    InFootprint TW BW TR BR m ∧
    H3a.wRead m scrW wCtr = (i : ℤ) ∧
    (∀ c < i, H3a.rRead m tblDst (offDst + (c : ℤ)) = H3a.rRead m₀ tblSrc (offSrc + (c : ℤ))) ∧
    (∀ w, w ≠ wCtr → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
    (∀ r, H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
    RadFrameOutside scrW scrR tblW baseW 0 tblDst offDst (N : ℤ) m₀ m
  have hInv0 : Inv 0 m_init :=
    ⟨hfp_init, wRead_wWrite_self _ _ _ _, fun _ hc => by omega,
     fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
     fun _ => rfl,
     RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblDst offDst (N : ℤ) m₀ _ _⟩
  obtain ⟨m_end, hInvN, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (N : ℤ)) _ N 5 35 Inv hInv0 rfl
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    (fun i hi m ⟨hfp_m, hctr_m, hcopied_m, hkW_m, hkR_m, hfr_m⟩ => by
      have hoffS_m : H3a.wRead m scrW wOffSrc = offSrc := (hkW_m wOffSrc hneCtrSrc.symm).trans hoffSrc
      have hoffD_m : H3a.wRead m scrW wOffDst = offDst := (hkW_m wOffDst hneCtrDst.symm).trans hoffDst
      have hsrc_m : H3a.rRead m tblSrc (offSrc + (i : ℤ)) = H3a.rRead m₀ tblSrc (offSrc + (i : ℤ)) := by
        by_cases hsR : tblSrc = scrR
        · subst hsR; exact hkR_m _
        · apply hfr_m.2 tblSrc (offSrc + (i : ℤ)) hsR
          rcases hdisjSrcDst with ht | h1 | h2
          · exact Or.inl ht
          · exact Or.inr (Or.inl (by omega))
          · exact Or.inr (Or.inr (by omega))
      let m' := H3a.rWrite m tblDst (offDst + (i : ℤ)) (H3a.rRead m₀ tblSrc (offSrc + (i : ℤ)))
      let m'' := H3a.wWrite m' scrW wCtr ((i + 1 : ℕ) : ℤ)
      have hd1 : DetExec inp (.writeRealHeap tblDst
          (.add (.readHeap scrW (.lit wOffDst)) (.readHeap scrW (.lit wCtr)))
          (.readRealHeap tblSrc (.add (.readHeap scrW (.lit wOffSrc)) (.readHeap scrW (.lit wCtr)))))
          m m' 25 :=
        DetExecAt.writeRealHeap 0 inp m tblDst _ _
          (by change H3a.wRead m scrW wOffDst + H3a.wRead m scrW wCtr = offDst + (i : ℤ)
              rw [hoffD_m, hctr_m])
          (by change H3a.rRead m tblSrc (H3a.wRead m scrW wOffSrc + H3a.wRead m scrW wCtr) = _
              rw [hoffS_m, hctr_m, hsrc_m])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit wCtr)
          (.add (.readHeap scrW (.lit wCtr)) (.lit 1))) m' m'' 10 :=
        DetExecAt.writeWordHeap 0 inp m' scrW (.lit wCtr) _ rfl
          (by change H3a.wRead m' scrW wCtr + 1 = _
              rw [wRead_rWrite, hctr_m]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp'' : InFootprint TW BW TR BR m'' :=
        InFootprint.wWrite (InFootprint.rWrite hfp_m htblDst (by omega) (by omega))
          hscrW hwCtr.1 hwCtr.2
      have hfr'' : RadFrameOutside scrW scrR tblW baseW 0 tblDst offDst (N : ℤ) m₀ m'' :=
        (hfr_m.trans (RadFrameOutside.rWrite_in scrW scrR tblW baseW 0 tblDst offDst (N : ℤ)
          m (idx := offDst + (i : ℤ)) _ (by omega) (by omega))).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblDst offDst (N : ℤ) m' _ _)
      refine ⟨m'', hd1.seq hd2, hfp'', wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, hfr''⟩
      · intro c hc
        rw [rRead_wWrite]
        by_cases he : c = i
        · subst he; exact rRead_rWrite_self _ _ _ _
        · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]
          exact hcopied_m c (by omega)
      · intro w hw
        rw [wRead_wWrite_of_ne _ _ (Or.inr hw), wRead_rWrite]
        exact hkW_m w hw
      · intro r
        rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hneDstScr.symm)]
        exact hkR_m r)
  rcases hInvN with ⟨hfp_end, _, hcopied_end, hkW_end, hkR_end, hfr_end⟩
  exact ⟨m_end, (hd_init.seq hd_loop).mono_cost (by omega),
    hfp_end, hcopied_end, hkW_end, hkR_end, hfr_end⟩

def liveSlotQueryCopyStmt (scrW scrR tblW tblR tblO tblPts : ℕ)
    (wBaseW wBaseR wEntryPtBase wOffO wOffPv wAnsOut wQryBase rQryBase : ℤ)
    (R ℓ M₀ d cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) : ArithRAMStmt :=
  let wR := wQryBase
  let wCapBaseR := wQryBase + 1
  let wTupIdx := wQryBase + 2
  let wInBkt := wQryBase + 3
  let wCurNd := wQryBase + 4
  let wRemRej := wQryBase + 5
  let wCopyAns := wQryBase + 6
  let wEvalBase := wQryBase + 16
  let rVlatBase := rQryBase + 4 + (d : ℤ)
  .ite (.intLe (.lit 0) (.readHeap scrW (.lit wAnsOut)))
    .skip
    (.seq (.writeWordHeap scrW (.lit wCapBaseR)
            (.add (.readHeap scrW (.lit wBaseR))
                  (.mul (.readHeap scrW (.lit wR))
                        (.lit ((((ℓ * M₀) * (d + 1) : ℕ) : ℤ))))))
    (.seq (evalCopyTuplesStmt scrW scrR tblR wCapBaseR wEvalBase rQryBase rVlatBase
            ℓ M₀ d cap_q false A (-B_rat) τ_q)
    (.seq (.writeWordHeap scrW (.lit wTupIdx) (.lit 0))
    (.seq (.writeWordHeap scrW (.lit wInBkt) (.lit 0))
    (.seq (.writeWordHeap scrW (.lit wCurNd) (.lit (-1)))
    (.seq (.writeWordHeap scrW (.lit wRemRej) (.lit ((cap_q + 1 : ℕ) : ℤ)))
    (.seq (.writeWordHeap scrW (.lit wCopyAns) (.lit (-1)))
    (.seq (.repeatN (.lit ((2 * cap_q + 2 : ℕ) : ℤ))
            (liveSlotQueryStepStmt scrW scrR tblW tblO tblPts wBaseW wEntryPtBase wOffO wOffPv wQryBase rQryBase R ℓ M₀ d b_rat))
          (.writeWordHeap scrW (.lit wAnsOut)
            (.readHeap scrW (.lit wCopyAns)))))))))))

def liveSlotQueryCopyCost (ℓ M₀ d cap_q : ℕ) : ℕ :=
  150 + evalCopyTuplesCost ℓ M₀ d cap_q + (2 * cap_q + 2) * liveSlotQueryStepCost d

def liveSlotQueryStmt (scrW scrR tblW tblR tblO tblPts : ℕ)
    (wBaseW wBaseR wEntryPtBase wOffO wOffPv wAnsOut wQryBase rQryBase : ℤ)
    (R ℓ M₀ d M_lat S_lat cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) : ArithRAMStmt :=
  let wR := wQryBase
  let wEp := wQryBase + 7
  let wSub0 := wQryBase + 10
  let rVlatBase := rQryBase + 4 + (d : ℤ)
  let rWqBase := rQryBase + 4 + 2 * (d : ℤ)
  .seq (.writeWordHeap scrW (.lit wAnsOut) (.lit (-1)))
  (.seq (.writeWordHeap scrW (.lit wEp) (.readHeap tblW (.readHeap scrW (.lit wBaseW))))
  (.seq (subVecToScrStmt scrW scrR tblO tblPts wSub0 wOffO wOffPv rWqBase d)
  (.seq (roundQueryLatStmt scrW scrR scrR wSub0 rQryBase rWqBase rVlatBase d M_lat S_lat)
  (.seq (.writeWordHeap scrW (.lit wR) (.lit 0))
        (.repeatN (.lit (R : ℤ))
          (.seq (liveSlotQueryCopyStmt scrW scrR tblW tblR tblO tblPts
                  wBaseW wBaseR wEntryPtBase wOffO wOffPv wAnsOut wQryBase rQryBase
                  R ℓ M₀ d cap_q A B_rat τ_q b_rat)
                (.writeWordHeap scrW (.lit wR)
                  (.add (.readHeap scrW (.lit wR)) (.lit 1)))))))))

def liveSlotQueryCost (R ℓ M₀ d S_lat cap_q : ℕ) : ℕ :=
  250 + 70 * d + d * (60 + 165 * S_lat) + R * (liveSlotQueryCopyCost ℓ M₀ d cap_q + 30)

theorem exec_liveSlotQueryStmt {d TW BW TR BR scrW scrR tblW tblR tblO tblPts : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBaseR wEntryPtBase wOffO wOffPv wAnsOut wQryBase rQryBase
      baseW baseR entryPtBase offO offPv : ℤ)
    {R ℓ M₀ M_lat S_lat cap_u cap_q B_max blkStart : ℕ} (hM₀ : 1 ≤ M₀)
    (hS_lat : 2 * M_lat + 1 ≤ 2 ^ S_lat)
    (A B_rat τ_q b_rat : ℚ)
    (entryPt : ℕ → EuclideanSpace ℝ (Fin d))
    (entryAlive : ℕ → Bool)
    (o p_v : EuclideanSpace ℝ (Fin d)) (hpv_ne : p_v ≠ o)
    {pSlot : PureFilterSlot R ℓ M₀ d} {S : LiveSlot R ℓ M₀ d}
    (hwf : S.WF cap_u B_max blkStart entryAlive pSlot)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneO : tblO ≠ scrR) (hnePts : tblPts ≠ scrR)
    (hwAns : 0 ≤ wAnsOut ∧ wAnsOut < (BW : ℤ))
    (hwQry : 0 ≤ wQryBase ∧ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ (BW : ℤ))
    (hrQry : 0 ≤ rQryBase ∧ rQryBase + slotQryRStride d ≤ (BR : ℤ))
    (hdisjBW : wBaseW < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wBaseW)
    (hdisjBR : wBaseR < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wBaseR)
    (hdisjEP : wEntryPtBase < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wEntryPtBase)
    (hdisjO : wOffO < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wOffO)
    (hdisjPv : wOffPv < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wOffPv)
    (hdisjAns : wAnsOut < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ wAnsOut)
    (hneAnsInputs : wAnsOut ≠ wBaseW ∧ wAnsOut ≠ wBaseR ∧ wAnsOut ≠ wEntryPtBase ∧
                    wAnsOut ≠ wOffO ∧ wAnsOut ≠ wOffPv)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hbR : H3a.wRead m₀ scrW wBaseR = baseR)
    (hEP : H3a.wRead m₀ scrW wEntryPtBase = entryPtBase)
    (hoffO : H3a.wRead m₀ scrW wOffO = offO)
    (hoffPv : H3a.wRead m₀ scrW wOffPv = offPv)
    (ho : ∀ c : Fin d, H3a.rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpv : ∀ c : Fin d, H3a.rRead m₀ tblPts (offPv + (c.val : ℤ)) = euclideanCoord p_v c)
    (hEntryPt : ∀ eid : ℕ, entryAlive eid = true →
      entryPt eid ≠ o ∧
      ∀ c : Fin d, H3a.rRead m₀ tblPts (entryPtBase + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
        euclideanCoord (entryPt eid) c)
    (henc₀ : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀) :
    let pureAns := pSlot.query hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q entryPt o p_v entryAlive
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (liveSlotQueryStmt scrW scrR tblW tblR tblO tblPts
          wBaseW wBaseR wEntryPtBase wOffO wOffPv wAnsOut wQryBase rQryBase
          R ℓ M₀ d M_lat S_lat cap_q A B_rat τ_q b_rat)
        m₀ m₁ (liveSlotQueryCost R ℓ M₀ d S_lat cap_q) ∧
      InFootprint TW BW TR BR m₁ ∧
      H3a.wRead m₁ scrW wAnsOut = optNatToInt pureAns ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₁ ∧
      (∀ w : ℤ,
        w ≠ wAnsOut →
        (w < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ w) →
        H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  classical
  intro pureAns
  have hstrideW : slotQryWStride ℓ M₀ cap_q = 16 + evalWStride ℓ M₀ cap_q := rfl
  have heval_ge : 12 ≤ evalWStride ℓ M₀ cap_q := by unfold evalWStride; omega
  have hstrideR : slotQryRStride d = 4 + 3 * (d : ℤ) := rfl
  have hcaps_eq : S.caps = pSlot.caps := hwf.2.1
  let w_q : EuclideanSpace ℝ (Fin d) := o - p_v
  have hwq_ne : w_q ≠ 0 := sub_ne_zero.mpr hpv_ne.symm
  let z_q : EuclideanSpace ℝ (Fin d) := ‖w_q‖⁻¹ • w_q
  let v_lat : EuclideanSpace ℝ (Fin d) := latVec M_lat z_q
  -- Step 1: wAnsOut := -1, wEp := S.ep
  let m1 := H3a.wWrite m₀ scrW wAnsOut (-1)
  let m2 := H3a.wWrite m1 scrW (wQryBase + 7) (S.ep : ℤ)
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wAnsOut) (.lit (-1))) m₀ m1 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wAnsOut) (.lit (-1)) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 7))
      (.readHeap tblW (.readHeap scrW (.lit wBaseW)))) m1 m2 20 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wQryBase + 7)) _ rfl
      (by change H3a.wRead m1 tblW (H3a.wRead m1 scrW wBaseW) = (S.ep : ℤ)
          rw [wRead_wWrite_of_ne _ _ (Or.inr hneAnsInputs.1.symm), hbW,
              wRead_wWrite_of_ne _ _ (Or.inl hneW), henc₀.1])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp2 : InFootprint TW BW TR BR m2 :=
    InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW hwAns.1 hwAns.2) hscrW (by omega) (by omega)
  have hfr02 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m2 :=
    (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ _ _).trans
      (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m1 _ _)
  -- Step 2: subVecToScrStmt (w_q = o - p_v into rQryBase + 4 + 2 * d)
  obtain ⟨m3, hd3, hfp3, hwq_m3, hkW3, _, hfr3⟩ :=
    exec_subVecToScrStmt (tblW := tblW) (tblR := tblR) inp
      (wQryBase + 10) wOffO wOffPv offO offPv (rQryBase + 4 + 2 * (d : ℤ)) baseW baseR o p_v
      hfp2 hscrW hscrR hneO hnePts ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by omega) (by omega)
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr hneAnsInputs.2.2.2.1.symm)]; exact hoffO)
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr hneAnsInputs.2.2.2.2.symm)]; exact hoffPv)
      (fun c => by rw [rRead_wWrite, rRead_wWrite]; exact ho c)
      (fun c => by rw [rRead_wWrite, rRead_wWrite]; exact hpv c)
  have hfr03 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m3 := hfr02.trans hfr3
  -- Step 3: roundQueryLatStmt (v_lat into rQryBase + 4 + d)
  have hex_lat := exec_roundQueryLatStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
    (scrW := scrW) (scrR := scrR) (tblW := scrR) inp
    (wQryBase + 10) rQryBase (rQryBase + 4 + 2 * (d : ℤ)) (rQryBase + 4 + (d : ℤ))
    M_lat S_lat hS_lat w_q hwq_ne hfp3 hscrW hscrR
    ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
    (Or.inl (by omega)) (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega))) hwq_m3
  obtain ⟨m4, hpr4, hvlat_floor, hfp4, hkW4, _, hd4⟩ :=
    execScratch_window_to_detExec
      (sw_roundQueryLatStmt scrW scrR scrR (wQryBase + 10) rQryBase
        (rQryBase + 4 + 2 * (d : ℤ)) (rQryBase + 4 + (d : ℤ)) d M_lat S_lat)
      hfp3 hex_lat
  have hfr4 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m3 m4 :=
    RadFrameOutside.of_preservesNonScratch _ _ _ _ _ _ hpr4
  have hfr04 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m4 := hfr03.trans hfr4
  have hvlat_m4 : ∀ i : Fin d,
      H3a.rRead m4 scrR ((rQryBase + 4 + (d : ℤ)) + (i.val : ℤ)) = euclideanCoord v_lat i := by
    intro i
    rw [hvlat_floor i]
    exact latVec_coord_eq_floor M_lat z_q i
  -- Step 4: wR := 0 and repeatN R
  let m5 := H3a.wWrite m4 scrW wQryBase 0
  have hd5 : DetExec inp (.writeWordHeap scrW (.lit wQryBase) (.lit 0)) m4 m5 10 :=
    DetExecAt.writeWordHeap 0 inp m4 scrW (.lit wQryBase) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp5 : InFootprint TW BW TR BR m5 := InFootprint.wWrite hfp4 hscrW hwQry.1 (by omega)
  have hfr05 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m5 :=
    hfr04.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m4 _ _)
  let copyFn : Fin R → Option ℕ := fun r =>
    scanCopyTuples pSlot.buckets r entryPt o p_v (b_rat : ℝ) entryAlive (cap_q + 1)
      (queryTupleCodeList hM₀ pSlot.caps A B_rat τ_q cap_q v_lat r)
  let accOf : ∀ k ≤ R, Option ℕ := fun k hk =>
    Fin.foldl k (fun acc (i : Fin k) =>
      match acc with
      | some x => some x
      | none => copyFn ⟨i.val, lt_of_lt_of_le i.isLt hk⟩) none
  let InvR : ℕ → ArithRAMMemory → Prop := fun r_idx m =>
    ∃ hr_le : r_idx ≤ R,
      InFootprint TW BW TR BR m ∧
      H3a.wRead m scrW wQryBase = (r_idx : ℤ) ∧
      H3a.wRead m scrW (wQryBase + 7) = (S.ep : ℤ) ∧
      H3a.wRead m scrW wAnsOut = optNatToInt (accOf r_idx hr_le) ∧
      (∀ i : Fin d,
        H3a.rRead m scrR ((rQryBase + 4 + (d : ℤ)) + (i.val : ℤ)) = euclideanCoord v_lat i) ∧
      (∀ w : ℤ,
        w ≠ wAnsOut →
        (w < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ w) →
        H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
  have hInvR0 : InvR 0 m5 := by
    have hacc0 : accOf 0 (Nat.zero_le R) = none := by dsimp [accOf]; rw [Fin.foldl_zero]
    refine ⟨Nat.zero_le R, hfp5, wRead_wWrite_self _ _ _ _, ?_, ?_,
      fun i => by rw [rRead_wWrite]; exact hvlat_m4 i,
      fun w hw_ans hw_out => ?_, hfr05⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          hkW4 _ (by omega), hkW3 _ (by omega), wRead_wWrite_self]
    · rw [hacc0, wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          hkW4 _ (by omega), hkW3 _ (by omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          hkW4 _ (by omega), hkW3 _ (by omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr hw_ans)]
  let C_r : ℕ := liveSlotQueryCopyCost ℓ M₀ d cap_q + 30
  obtain ⟨m_end, hInvEnd, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (R : ℤ)) _ R 10 C_r
    InvR hInvR0 rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    (fun r_idx hr m ⟨hr_le, hfp_m, hr_m, hep_m, hans_m, hvlat_m, hkW_m, hfr_m⟩ => by
      let rFin : Fin R := ⟨r_idx, hr⟩
      have henc_m : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m :=
        henc₀.mono_frame hfr_m hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
      have hcopy : ∃ m_c : ArithRAMMemory,
          DetExec inp
            (liveSlotQueryCopyStmt scrW scrR tblW tblR tblO tblPts
              wBaseW wBaseR wEntryPtBase wOffO wOffPv wAnsOut wQryBase rQryBase
              R ℓ M₀ d cap_q A B_rat τ_q b_rat)
            m m_c (liveSlotQueryCopyCost ℓ M₀ d cap_q) ∧
          InFootprint TW BW TR BR m_c ∧
          H3a.wRead m_c scrW wQryBase = (r_idx : ℤ) ∧
          H3a.wRead m_c scrW (wQryBase + 7) = (S.ep : ℤ) ∧
          H3a.wRead m_c scrW wAnsOut = optNatToInt (accOf (r_idx + 1) hr) ∧
          (∀ i : Fin d,
            H3a.rRead m_c scrR ((rQryBase + 4 + (d : ℤ)) + (i.val : ℤ)) = euclideanCoord v_lat i) ∧
          (∀ w : ℤ,
            w ≠ wAnsOut →
            (w < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ w) →
            H3a.wRead m_c scrW w = H3a.wRead m₀ scrW w) ∧
          RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_c := by
        have hacc_step : accOf (r_idx + 1) hr =
            match accOf r_idx hr_le with | some x => some x | none => copyFn rFin := by
          dsimp [accOf, rFin]; rw [Fin.foldl_succ_last]; rfl
        cases hprev : accOf r_idx hr_le with
        | some x =>
            have hc_some : cValAt 0 inp m (.intLe (.lit 0) (.readHeap scrW (.lit wAnsOut))) = true := by
              simp only [cValAt, evalArithCond, evalIntExpr]
              change decide (0 ≤ H3a.wRead m scrW wAnsOut) = true
              rw [hans_m, hprev, optNatToInt]; exact decide_eq_true (by omega)
            refine ⟨m,
              (DetExecAt.ite_true (C_c := 10) hc_some
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                (DetExecAt.skip 0 inp m)).mono_cost (by unfold liveSlotQueryCopyCost; omega),
              hfp_m, hr_m, hep_m,
              by rw [hans_m, hacc_step, hprev],
              hvlat_m, hkW_m, hfr_m⟩
        | none =>
            have hc_none : cValAt 0 inp m (.intLe (.lit 0) (.readHeap scrW (.lit wAnsOut))) = false := by
              simp only [cValAt, evalArithCond, evalIntExpr]
              change decide (0 ≤ H3a.wRead m scrW wAnsOut) = false
              rw [hans_m, hprev, optNatToInt]; decide
            let capBaseR : ℤ := baseR + (((rFin.val * ((ℓ * M₀) * (d + 1))) : ℕ) : ℤ)
            have hbR_m : H3a.wRead m scrW wBaseR = baseR :=
              (hkW_m wBaseR hneAnsInputs.2.1.symm hdisjBR).trans hbR
            let m_c1 := H3a.wWrite m scrW (wQryBase + 1) capBaseR
            have hdc1 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 1))
                (.add (.readHeap scrW (.lit wBaseR))
                      (.mul (.readHeap scrW (.lit wQryBase))
                            (.lit ((((ℓ * M₀) * (d + 1) : ℕ) : ℤ)))))) m m_c1 25 :=
              DetExecAt.writeWordHeap 0 inp m scrW (.lit (wQryBase + 1)) _ rfl
                (by change H3a.wRead m scrW wBaseR +
                      H3a.wRead m scrW wQryBase * (((ℓ * M₀) * (d + 1) : ℕ) : ℤ) = capBaseR
                    rw [hbR_m, hr_m]; dsimp [capBaseR, rFin])
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hfp_c1 : InFootprint TW BW TR BR m_c1 := InFootprint.wWrite hfp_m hscrW (by omega) (by omega)
            have hCaps_c1 : ∀ (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)),
                H3a.rRead m_c1 tblR (capBaseR + (((s.val * M₀ + k.val) * (d + 1) : ℕ) : ℤ) + (j.val : ℤ)) =
                  euclideanCoord (pSlot.caps (rFin, s, k)) j := by
              intro s k j
              rw [rRead_wWrite, ← hcaps_eq]
              have haddr : capBaseR + (((s.val * M₀ + k.val) * (d + 1) : ℕ) : ℤ) + (j.val : ℤ) =
                  baseR + (capCoordIdx rFin s k j : ℤ) := by
                dsimp [capBaseR, capCoordIdx]; push_cast; ring
              rw [haddr]
              exact henc_m.2.2.2.1 rFin s k j
            obtain ⟨m_c2, hdc2, hfp_c2, _, hout_c2, hcodes_c2, hkW_c2, hkR_c2, hfr_c2⟩ :=
              exec_evalCopyTuplesStmt (tblW := tblW) inp
                (wQryBase + 1) (wQryBase + 16) rQryBase (rQryBase + 4 + (d : ℤ)) capBaseR baseW baseR
                hM₀ cap_q false A (-B_rat) τ_q (fun s k => pSlot.caps (rFin, s, k)) v_lat
                hfp_c1 hscrW hscrR hneR ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
                (Or.inl le_rfl) (Or.inl (by omega))
                (wRead_wWrite_self _ _ _ _) hCaps_c1
                (fun i => by rw [rRead_wWrite]; exact hvlat_m i)
            let codes := queryTupleCodeList hM₀ pSlot.caps A B_rat τ_q cap_q v_lat rFin
            obtain ⟨hout_eq_len, hlen_le_q, hcode_vals⟩ :=
              queryTupleCodeList_from_eval hM₀ pSlot.caps A B_rat τ_q cap_q v_lat rFin
            have hout_c2' : H3a.wRead m_c2 scrW (wQryBase + 16 + 11) = (codes.length : ℤ) := by
              exact hout_c2.trans (congrArg Nat.cast hout_eq_len)
            have hcodes_c2' : ∀ (idx : ℕ) (hidx : idx < codes.length),
                H3a.wRead m_c2 scrW (evalCodesOff ℓ M₀ (wQryBase + 16) + (idx : ℤ)) =
                  @Nat.cast ℤ _ (codes[idx]).val := by
              intro idx hidx
              have hidx_out : idx < _ := hout_eq_len.symm ▸ hidx
              rw [hcodes_c2 idx hidx_out, hcode_vals idx hidx]
            -- Initialize 5 step registers
            let m_s1 := H3a.wWrite m_c2 scrW (wQryBase + 2) 0
            let m_s2 := H3a.wWrite m_s1 scrW (wQryBase + 3) 0
            let m_s3 := H3a.wWrite m_s2 scrW (wQryBase + 4) (-1)
            let m_s4 := H3a.wWrite m_s3 scrW (wQryBase + 5) ((cap_q + 1 : ℕ) : ℤ)
            let m_s5 := H3a.wWrite m_s4 scrW (wQryBase + 6) (-1)
            have hds1 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 2)) (.lit 0)) m_c2 m_s1 10 :=
              DetExecAt.writeWordHeap 0 inp m_c2 scrW (.lit (wQryBase + 2)) (.lit 0) rfl rfl
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hds2 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 3)) (.lit 0)) m_s1 m_s2 10 :=
              DetExecAt.writeWordHeap 0 inp m_s1 scrW (.lit (wQryBase + 3)) (.lit 0) rfl rfl
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hds3 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 4)) (.lit (-1))) m_s2 m_s3 10 :=
              DetExecAt.writeWordHeap 0 inp m_s2 scrW (.lit (wQryBase + 4)) (.lit (-1)) rfl rfl
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hds4 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 5)) (.lit ((cap_q + 1 : ℕ) : ℤ))) m_s3 m_s4 10 :=
              DetExecAt.writeWordHeap 0 inp m_s3 scrW (.lit (wQryBase + 5)) _ rfl rfl
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hds5 : DetExec inp (.writeWordHeap scrW (.lit (wQryBase + 6)) (.lit (-1))) m_s4 m_s5 10 :=
              DetExecAt.writeWordHeap 0 inp m_s4 scrW (.lit (wQryBase + 6)) (.lit (-1)) rfl rfl
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hfp_s5 : InFootprint TW BW TR BR m_s5 :=
              InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite
                (InFootprint.wWrite (InFootprint.wWrite hfp_c2 hscrW (by omega) (by omega))
                  hscrW (by omega) (by omega)) hscrW (by omega) (by omega))
                hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
            have hfr_s5 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_s5 :=
              (((((((hfr_m.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m _ _)).trans hfr_c2).trans
                (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_c2 _ _)).trans
                (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_s1 _ _)).trans
                (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_s2 _ _)).trans
                (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_s3 _ _)).trans
                (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_s4 _ _))
            obtain ⟨hq_complete, hq_valid⟩ :=
              queryCopyStep_complete hwf entryPt o p_v (b_rat : ℝ) cap_q rFin codes hlen_le_q
            let stOf : ℕ → ℕ × Bool × ℤ × ℕ × Option ℕ := fun t =>
              (queryCopyStep entryPt o p_v (b_rat : ℝ) S rFin codes)^[t] (0, false, -1, cap_q + 1, none)
            let InvT : ℕ → ArithRAMMemory → Prop := fun t m_t =>
              t ≤ 2 * cap_q + 2 ∧
              InFootprint TW BW TR BR m_t ∧
              EncQueryStepState scrW wQryBase (stOf t) m_t ∧
              H3a.wRead m_t scrW wQryBase = (r_idx : ℤ) ∧
              H3a.wRead m_t scrW (wQryBase + 7) = (S.ep : ℤ) ∧
              H3a.wRead m_t scrW (wQryBase + 16 + 11) = (codes.length : ℤ) ∧
              (∀ (idx : ℕ) (hidx : idx < codes.length),
                H3a.wRead m_t scrW (evalCodesOff ℓ M₀ (wQryBase + 16) + (idx : ℤ)) =
                  @Nat.cast ℤ _ (codes[idx]).val) ∧
              (∀ i : Fin d,
                H3a.rRead m_t scrR ((rQryBase + 4 + (d : ℤ)) + (i.val : ℤ)) = euclideanCoord v_lat i) ∧
              (∀ w : ℤ,
                w ≠ wAnsOut →
                (w < wQryBase ∨ wQryBase + slotQryWStride ℓ M₀ cap_q ≤ w) →
                H3a.wRead m_t scrW w = H3a.wRead m₀ scrW w) ∧
              RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_t
            have hkeep_s5 : ∀ w : ℤ, (w < wQryBase + 2 ∨ wQryBase + 7 ≤ w) →
                H3a.wRead m_s5 scrW w = H3a.wRead m_c2 scrW w := by
              intro w hw
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
            have hInvT0 : InvT 0 m_s5 := by
              refine ⟨Nat.zero_le _, hfp_s5, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hfr_s5⟩
              · refine ⟨?_, ?_, ?_, ?_, wRead_wWrite_self _ _ _ _⟩
                · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
                · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
                · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
                · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
              · rw [hkeep_s5 _ (Or.inl (by omega)), hkW_c2 _ (Or.inl (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hr_m
              · rw [hkeep_s5 _ (Or.inr le_rfl), hkW_c2 _ (Or.inl (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hep_m
              · rw [hkeep_s5 _ (Or.inr (by omega))]; exact hout_c2'
              · intro idx hidx
                rw [hkeep_s5 _ (Or.inr (by unfold evalCodesOff; omega))]
                exact hcodes_c2' idx hidx
              · intro i
                rw [rRead_wWrite, rRead_wWrite, rRead_wWrite, rRead_wWrite, rRead_wWrite,
                    hkR_c2 _ (Or.inr (by omega)), rRead_wWrite]
                exact hvlat_m i
              · intro w hw_ans hw_out
                rw [hkeep_s5 _ (by omega), hkW_c2 _ (by omega),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                exact hkW_m w hw_ans hw_out
            obtain ⟨m_st, hInvTEnd, hd_tloop⟩ := DetExecAt.repeatN_nat
              (.lit ((2 * cap_q + 2 : ℕ) : ℤ)) _ (2 * cap_q + 2) 10 (liveSlotQueryStepCost d)
              InvT hInvT0 rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (fun t ht m_t ⟨ht_le, hfp_t, hst_t, hr_t, hep_t, hout_t, hcodes_t, hvlat_t, hkW_t, hfr_t⟩ => by
                have henc_t : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m_t :=
                  henc₀.mono_frame hfr_t hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
                obtain ⟨m_tn, hd_tn, hfp_tn, hst_tn, hkW_tn, hkR_tn, hfr_tn⟩ :=
                  exec_liveSlotQueryStepStmt inp
                    wBaseW wEntryPtBase wOffO wOffPv wQryBase rQryBase baseW baseR entryPtBase offO offPv
                    rFin b_rat entryPt entryAlive o p_v hpv_ne S codes hlen_le_q (stOf t)
                    (hq_valid t ht_le) hfp_t hscrW hscrR hneW hneO hnePts hwQry ⟨hrQry.1, by omega⟩
                    hdisjBW hdisjEP hdisjO hdisjPv
                    ((hkW_t wBaseW hneAnsInputs.1.symm hdisjBW).trans hbW)
                    ((hkW_t wEntryPtBase hneAnsInputs.2.2.1.symm hdisjEP).trans hEP)
                    ((hkW_t wOffO hneAnsInputs.2.2.2.1.symm hdisjO).trans hoffO)
                    ((hkW_t wOffPv hneAnsInputs.2.2.2.2.symm hdisjPv).trans hoffPv)
                    hr_t hep_t hout_t hcodes_t
                    (fun c => by rw [hfr_t.2 tblO _ hneO (Or.inr (by omega))]; exact ho c)
                    (fun c => by rw [hfr_t.2 tblPts _ hnePts (Or.inr (by omega))]; exact hpv c)
                    (fun eid hal => ⟨(hEntryPt eid hal).1, fun c => by
                      rw [hfr_t.2 tblPts _ hnePts (Or.inr (by omega))]
                      exact (hEntryPt eid hal).2 c⟩)
                    hst_t henc_t
                have hst_succ : stOf (t + 1) = queryCopyStep entryPt o p_v (b_rat : ℝ) S rFin codes (stOf t) :=
                  Function.iterate_succ_apply' _ t _
                refine ⟨m_tn, hd_tn, ht, hfp_tn, by rw [hst_succ]; exact hst_tn,
                  (hkW_tn _ (Or.inl (by omega))).trans hr_t,
                  (hkW_tn _ (Or.inr (Or.inr rfl))).trans hep_t,
                  (hkW_tn _ (Or.inr (Or.inl (by omega)))).trans hout_t,
                  fun idx hidx => (hkW_tn _ (Or.inr (Or.inl (by unfold evalCodesOff; omega)))).trans (hcodes_t idx hidx),
                  fun i => (hkR_tn _ (Or.inr (by omega))).trans (hvlat_t i),
                  fun w hw_ans hw_out => (hkW_tn w (by omega)).trans (hkW_t w hw_ans hw_out),
                  hfr_t.trans hfr_tn⟩)
            rcases hInvTEnd with ⟨_, hfp_st, hst_end, hr_st, hep_st, _, _, hvlat_st, hkW_st, hfr_st⟩
            let m_out := H3a.wWrite m_st scrW wAnsOut (optNatToInt (copyFn rFin))
            have hd_out : DetExec inp (.writeWordHeap scrW (.lit wAnsOut)
                (.readHeap scrW (.lit (wQryBase + 6)))) m_st m_out 15 :=
              DetExecAt.writeWordHeap 0 inp m_st scrW (.lit wAnsOut) _ rfl
                (by change H3a.wRead m_st scrW (wQryBase + 6) = _; rw [hst_end.2.2.2.2, hq_complete])
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hfp_out : InFootprint TW BW TR BR m_out :=
              InFootprint.wWrite hfp_st hscrW hwAns.1 hwAns.2
            have hfr_out : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_out :=
              hfr_st.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_st _ _)
            refine ⟨m_out,
              (DetExecAt.ite_false (tB := .skip) (C_c := 10) hc_none
                (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                (hdc1.seq (hdc2.seq (hds1.seq (hds2.seq (hds3.seq (hds4.seq (hds5.seq (hd_tloop.seq hd_out))))))))).mono_cost
                (by unfold liveSlotQueryCopyCost; omega),
              hfp_out,
              by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hr_st,
              by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hep_st,
              by rw [wRead_wWrite_self, hacc_step, hprev],
              fun i => by rw [rRead_wWrite]; exact hvlat_st i,
              fun w hw_ans hw_out => by
                rw [wRead_wWrite_of_ne _ _ (Or.inr hw_ans)]
                exact hkW_st w hw_ans hw_out,
              hfr_out⟩
      obtain ⟨m_c, hd_c, hfp_c, hr_c, hep_c, hans_c, hvlat_c, hkW_c, hfr_c⟩ := hcopy
      let m_nx := H3a.wWrite m_c scrW wQryBase ((r_idx + 1 : ℕ) : ℤ)
      have hd_nx : DetExec inp (.writeWordHeap scrW (.lit wQryBase)
          (.add (.readHeap scrW (.lit wQryBase)) (.lit 1))) m_c m_nx 20 :=
        DetExecAt.writeWordHeap 0 inp m_c scrW (.lit wQryBase) _ rfl
          (by change H3a.wRead m_c scrW wQryBase + 1 = _; rw [hr_c]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_nx : InFootprint TW BW TR BR m_nx :=
        InFootprint.wWrite hfp_c hscrW hwQry.1 (by omega)
      have hfr_nx : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_nx :=
        hfr_c.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_c _ _)
      refine ⟨m_nx, (hd_c.seq hd_nx).mono_cost (by dsimp only [C_r]; omega),
        hr, hfp_nx, wRead_wWrite_self _ _ _ _,
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hep_c,
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hans_c,
        fun i => by rw [rRead_wWrite]; exact hvlat_c i,
        fun w hw_ans hw_out => by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          exact hkW_c w hw_ans hw_out,
        hfr_nx⟩)
  rcases hInvEnd with ⟨_, hfp_end, _, _, hans_end, _, hkW_end, hfr_end⟩
  have hacc_full : accOf R le_rfl = pureAns := by
    change Fin.foldl R (fun acc (i : Fin R) =>
      match acc with
      | some x => some x
      | none => copyFn ⟨i.val, lt_of_lt_of_le i.isLt le_rfl⟩) none =
      (List.finRange R).findSome? copyFn
    rw [findSome_finRange_eq_foldl]
    congr 1; funext acc i
    cases acc with
    | none => exact congrArg copyFn (Fin.ext rfl)
    | some _ => rfl
  have henc_end : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m_end :=
    henc₀.mono_frame hfr_end hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  have hcost_le : 10 + (20 + ((20 + 40 * d) + ((80 + 30 * d + d * (60 + 165 * S_lat)) + (10 + (10 + R * C_r))))) ≤
      liveSlotQueryCost R ℓ M₀ d S_lat cap_q := by
    unfold liveSlotQueryCost
    dsimp only [C_r]
    omega
  refine ⟨m_end, (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq hd_loop))))).mono_cost hcost_le,
    hfp_end, ?_, henc_end, hkW_end, hfr_end⟩
  rw [hans_end, hacc_full]

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
