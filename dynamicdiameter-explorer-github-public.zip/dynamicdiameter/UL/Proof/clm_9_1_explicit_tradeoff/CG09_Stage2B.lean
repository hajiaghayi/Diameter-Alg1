import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B2
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 9b. `.build`-Phase Branch (`tickJobBuildBranchStmt`) & Top-Level `tickRebuildJobStmt` -/

def tickJobBuildBranchStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .seq (.writeWordHeap engScrTbl (.lit 18) (.readHeap engMetaTbl (.lit (base + 7))))
  (.seq (advanceJobBuildLoopStmt ops r 18)
    (.ite (.intLt (.readHeap engMetaTbl (.lit (base + 4))) (.readHeap engMetaTbl (.lit (base + 5))))
      (.writeWordHeap engScrTbl (.lit 10) (.lit 0))
      (.seq (.writeWordHeap engMetaTbl
              (.add (.lit (readySlotOff cp r.val 0)) (.readHeap engMetaTbl (.lit (base + 1))))
              (.readHeap engScrTbl (.lit 18)))
      (.seq (.writeWordHeap engMetaTbl (.lit (base + 1))
              (.add (.readHeap engMetaTbl (.lit (base + 1))) (.lit 1)))
      (.seq (ops.readNodeScalarStmt .resLen 18 19)
        (.ite (.intLe (.readHeap engScrTbl (.lit 19)) (.lit (cp.B_scan : ℤ)))
          (finishBuildToCopyStmt cp r (.lit 0) 2)
          (.ite (.intLe (.lit (cp.D_max : ℤ))
                  (.add (.lit (r.val : ℤ)) (.readHeap engMetaTbl (.lit (base + 1)))))
            (finishBuildToCopyStmt cp r (.lit 0) 3)
            (.seq (ops.readNodeScalarStmt .histLen 18 19)
                  (finishBuildToCopyStmt cp r (.readHeap engScrTbl (.lit 19)) 0)))))))))

theorem zeroRand_tickJobBuildBranchStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (tickJobBuildBranchStmt ops r) :=
  .seq (.writeWordHeap _ _ _)
  (.seq (zeroRand_advanceJobBuildLoopStmt ops r 18)
    (.ite (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _)
      (.seq (ops.zeroRand_readNodeScalar .resLen 18 19)
        (.ite (zeroRand_finishBuildToCopyStmt cp r (.lit 0) 2)
          (.ite (zeroRand_finishBuildToCopyStmt cp r (.lit 0) 3)
            (.seq (ops.zeroRand_readNodeScalar .histLen 18 19)
                  (zeroRand_finishBuildToCopyStmt cp r (.readHeap engScrTbl (.lit 19)) 0)))))))))

def tickJobBuildCost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  (120 + cp.B_scan * (ops.C_ins + 180)) + (2 * ops.C_read + 220)

theorem exec_tickJobBuildBranchStmt
    (h_clm_7_3 : S_clm_7_3_global_approx)
    {d : ℕ} (hd : 1 ≤ d) {params : LocalScaleParams} (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1)
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {actH S_anc : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    {anc : MNode cp} {jb : SuffixJob cp} {bs : BuildState cp}
    {servSlots : List ℕ}
    {curJobs : Fin cp.D_max → Option (SuffixJob cp)}
    {readySlots : Fin cp.D_max → List ℕ}
    {curSlots : Fin cp.D_max → ℕ}
    {bits : Fin cp.B_STEP → Bool}
    {m₀ : ArithRAMMemory}
    (hphase : jb.phase = .build bs)
    (hcur_r : curJobs r = some jb)
    (hS_anc : S_anc ⊆ actH)
    (hact_n : ∀ x ∈ actH, x < cp.n)
    (hact_pts : ∀ x ∈ actH, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hanc_ln : LiveNodeInv cp actH pts gt S_anc anc)
    (hjb_inv : SuffixJobInvSlack cp cp.B_scan actH pts gt S_anc anc r.val jb)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hjobs_enc : ∀ r' : Fin cp.D_max,
      EncJobSlot ops r' (curJobs r') (readySlots r') (curSlots r') m₀)
    (hall_nd : (servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r'))).Nodup)
    (hall_lt : ∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')), s < M_slots cp)
    (hcoins : MemHasStepCoins cp bits m₀) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
      ω₂.1 ⟨r.val * cp.B_scan + j.val, by
        have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
          calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan := Nat.add_lt_add_left j.isLt _
            _ = (r.val + 1) * cp.B_scan := by ring
            _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
        exact Nat.lt_add_right _ this⟩
    let ctrSeed : CenterSeed cp := ω₂.2 r.castSucc
    let advRes := advanceOneJob cp pts gt anc r jb bSeeds ctrSeed
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (tickJobBuildBranchStmt ops r) m₀
      (TickJobResultPost ops r servSlots curJobs readySlots curSlots advRes m₀)
      (tickJobBuildCost ops) := by
  intro ω₂ bSeeds ctrSeed advRes
  have hTW := ops.hTW; have hBW_meta := ops.hBW_meta; have hBW_scr := ops.hBW_scr
  let base := jobMetaBase cp r.val
  let cSlot := curSlots r
  have hmeta_b : 16 + cp.D_max + 8 * r.val + 8 ≤ ops.BW := by
    have hr_lt := r.isLt; have hD2 : 0 ≤ cp.D_max * cp.D_max := Nat.zero_le _
    nlinarith only [hr_lt, hBW_meta, hD2]
  have hj_r := hjobs_enc r
  simp only [EncJobSlot, hcur_r, hphase] at hj_r
  rcases hj_r with ⟨hact1, hr_le, hr_len, hw_rlen, hready_enc, hp2, hw_L, hw_ins, hsnap_enc, hdel_enc, hw_cslot, hcur_enc⟩
  have hage_le : bs.curNode.nd.age ≤ bs.curNode.nd.birthSize :=
    (suffixJobInvSlack_bounds le_rfl hanc_ln.2.2.1 hjb_inv).2.2.2 bs hphase
  have hjb_inv' := hjb_inv
  dsimp only [SuffixJobInvSlack] at hjb_inv'
  rcases hjb_inv' with ⟨hrs_lt, hcl_r, _, _, hph_inv⟩
  rw [hphase] at hph_inv
  rcases hph_inv with ⟨_, _, _, _, hbs_inv⟩
  set T_end := foldResiduals pts S_anc jb.ready
  have hTend_sub : T_end ⊆ actH := (chainListInv_getElem S_anc jb.ready hS_anc hcl_r).1
  have hTend_n : ∀ x ∈ T_end, x < cp.n := fun x hx => hact_n x (hTend_sub hx)
  have hTend_pts : ∀ x ∈ T_end, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c :=
    fun x hx c => hact_pts x (hTend_sub hx) c
  have hnd_r_used : (readySlots r ++ [cSlot]).Nodup := by
    have hflat_nd := (nodup_append_disj.mp hall_nd).2.1
    have hr_nd := (nodup_finRange_flatMap_iff.mp hflat_nd).1 r
    simpa [hcur_r, jobUsedSlots, hphase] using hr_nd
  have hcSlot_M : cSlot < M_slots cp := hall_lt cSlot
    (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, by simp [cSlot, hcur_r, jobUsedSlots, hphase]⟩))
  have hq_ne_cSlot : ∀ q (hqs : q < (readySlots r).length), (readySlots r)[q]'hqs ≠ cSlot := by
    intro q hqs heq
    have hdisj := (nodup_append_disj.mp hnd_r_used).2.2
    exact hdisj cSlot (heq ▸ List.getElem_mem hqs) (List.mem_singleton_self _)
  have hother_ne_cSlot : ∀ s,
      s ∈ servSlots ++ (List.finRange cp.D_max).flatMap (fun r' =>
        if r' = r then [] else jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) →
      s ≠ cSlot := by
    intro s hs heq; subst heq
    rcases nodup_append_disj.mp hall_nd with ⟨_, hflat_nd, hserv_disj⟩
    rcases nodup_finRange_flatMap_iff.mp hflat_nd with ⟨_, hpair_disj⟩
    have hc_in_r : cSlot ∈ jobUsedSlots (curJobs r) (readySlots r) cSlot := by
      simp [hcur_r, jobUsedSlots, hphase]
    rcases List.mem_append.mp hs with hs1 | hs2
    · exact hserv_disj cSlot hs1 (flatMap_mem_iff_finRange.mpr ⟨r, hc_in_r⟩)
    · rcases flatMap_mem_iff_finRange.mp hs2 with ⟨r', hr'⟩
      by_cases heqr : r' = r
      · subst heqr; simp at hr'
      · simp only [if_neg heqr] at hr'
        exact hpair_disj r' r heqr cSlot hr' hc_in_r
  set steps := min (bs.snapArr.length - bs.insCur) cp.B_scan
  let ωs : Fin steps → OpSeed cp := fun j =>
    bSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩
  set bs' := advanceBuildLoop cp pts steps ωs bs
  have hadv_eq : advRes =
      (if bs'.insCur < bs'.snapArr.length then
        Sum.inl { ready := jb.ready, phase := .build bs' }
      else
        let u_done := bs'.curNode
        let newReady := jb.ready ++ [u_done]
        if u_done.resArr.length ≤ cp.B_scan then
          Sum.inr (newReady, u_done.resArr, false)
        else if r.val + newReady.length ≥ cp.D_max then
          Sum.inr (newReady, [], true)
        else
          Sum.inl { ready := newReady, phase := .copy (CopyState.init u_done.histArr.length) }) := by
    dsimp only [advRes, bs', ωs, steps]
    unfold advanceOneJob; rw [hphase]
  -- Phase 1: Write `engScrTbl[18] := cSlot` and run `advanceJobBuildLoopStmt ops r 18`
  unfold tickJobBuildBranchStmt
  refine ExecDet.seq' ((100 + cp.B_scan * (ops.C_ins + 180)) + (2 * ops.C_read + 220))
    (ExecDet.wWrite (C := 20) inp engScrTbl (.lit 18) (.readHeap engMetaTbl (.lit (base + 7)))
      18 (cSlot : ℤ) hfp₀ (by unfold engScrTbl; omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) rfl
      (by simp only [evalIntExpr]; exact hw_cslot) (by simp [intExprOps]) rfl)
    (by unfold tickJobBuildCost; omega) ?_
  intro m1 hm1 hfp1; subst hm1
  set m1_st := H3a.wWrite m₀ engScrTbl 18 (cSlot : ℤ)
  have hw9_1 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m1_st t i = wRead m₀ t i :=
    fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
  have hLoop := exec_advanceJobBuildLoopStmt h_clm_7_3 hd he1 hh0 hh1 ops inp r 18
    (pts := pts) (gt := gt) (T_end := T_end) (bits := bits) (bs := bs) (cSlot := cSlot) (m₀ := m1_st)
    (by omega) (by omega) hcSlot_M hage_le hbs_inv hTend_n
    (fun x hx c => (rRead_wWrite _ _ _ _ _ _).trans (hTend_pts x hx c))
    (fun k => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hcoins k))
    hfp1
    (ops.slotsReady_ext m₀ m1_st hsr₀ hw9_1 (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
    (ops.encNode_ext bs.curNode cSlot m₀ m1_st hcur_enc hw9_1
      (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
    (wRead_wWrite_self _ _ _ _)
    ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hw_L)
    ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hw_ins)
    (hsnap_enc.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
      (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
      (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide))))
    (hdel_enc.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
      (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
      (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide))))
  refine ExecDet.seq' (2 * ops.C_read + 220) hLoop (by omega) ?_
  intro mL ⟨hsrL, hwLL, hwinsL, hsnapL, hdelL, henc_uL, hndL_m1, hftL_m1, hfmL_m1, hfsL_m1, hfrL_m1⟩ hfpL
  have hftL : ∀ t < 9, t ≠ engMetaTbl → t ≠ engScrTbl → ∀ i, wRead mL t i = wRead m₀ t i :=
    fun t ht9 h1 h2 i => (hftL_m1 t ht9 h1 h2 i).trans (wRead_wWrite_of_ne _ _ (Or.inl h2))
  have hfmL : ∀ i, i ≠ base + 4 → wRead mL engMetaTbl i = wRead m₀ engMetaTbl i :=
    fun i h4 => (hfmL_m1 i h4).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
  have hfsL18 : wRead mL engScrTbl 18 = (cSlot : ℤ) :=
    (hfsL_m1 18 (by omega)).trans (wRead_wWrite_self _ _ _ _)
  have hfsL : ∀ i, i < 18 → wRead mL engScrTbl i = wRead m₀ engScrTbl i :=
    fun i hi18 => (hfsL_m1 i (by omega)).trans (wRead_wWrite_of_ne _ _ (Or.inr (by omega)))
  have hfrL : ∀ t < 3, ∀ i, rRead mL t i = rRead m₀ t i :=
    fun t ht3 i => (hfrL_m1 t ht3 i).trans (rRead_wWrite _ _ _ _ _ _)
  have hndL : ∀ mn' s, s < M_slots cp → s ≠ cSlot → ops.EncNode mn' s m₀ → ops.EncNode mn' s mL :=
    fun mn' s hs hne he0 => hndL_m1 mn' s hs hne
      (ops.encNode_ext mn' s m₀ m1_st he0 hw9_1
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
  -- Phase 2: Branch on `bs'.insCur < bs'.snapArr.length`
  by_cases hstill : bs'.insCur < bs'.snapArr.length
  · -- Case B1: Continue `.build bs'`, `engScrTbl[10] := 0`
    have hcondB1 : (evalArithCond inp 0 mL
        (.intLt (.readHeap engMetaTbl (.lit (base + 4))) (.readHeap engMetaTbl (.lit (base + 5))))).1 = true := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead mL engMetaTbl (base + 4) < wRead mL engMetaTbl (base + 5)) = true
      rw [hwinsL, hsnapL.2.2.1]; exact decide_eq_true (by exact_mod_cast hstill)
    refine ExecDet.ite' (C_c := 12) (C_b := 2 * ops.C_read + 208) _ _ _ hcondB1
      (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
      (by clear * -; nlinarith)
    refine ExecDet.wWrite inp engScrTbl (.lit 10) (.lit 0) 10 0
      hfpL (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
      rfl rfl (by simp [intExprOps]) ?_
    set mF := H3a.wWrite mL engScrTbl 10 0
    have hw9_F : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead mL t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    let jb_b' : SuffixJob cp := { ready := jb.ready, phase := .build bs' }
    have hadv_b1 : advRes = Sum.inl jb_b' := by rw [hadv_eq, if_pos hstill]
    have hfmF_job : ∀ i, ¬ InJobMetaRegion cp r.val i → wRead mF engMetaTbl i = wRead m₀ engMetaTbl i := by
      intro i hni
      exact (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
        (hfmL i (fun he => hni (Or.inl ⟨by omega, by omega⟩)))
    have hfaF_job : ∀ i, ¬ InJobArrRegion cp r.val i → wRead mF engArrTbl i = wRead m₀ engArrTbl i :=
      fun i _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hftL engArrTbl (by decide) (by decide) (by decide) i)
    have hall_eq : (List.finRange cp.D_max).flatMap (fun r' =>
        jobUsedSlots (Function.update curJobs r (some jb_b') r')
          (Function.update readySlots r (readySlots r) r')
          (Function.update curSlots r cSlot r')) =
        (List.finRange cp.D_max).flatMap (fun r' =>
          jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) := by
      congr 1; ext r'
      by_cases heq : r' = r
      · subst heq; simp [Function.update_self, hcur_r, jb_b', cSlot, jobUsedSlots, hphase]
      · simp [Function.update_of_ne heq]
    have henc_r_F : EncJobSlot ops r (some jb_b') (readySlots r) cSlot mF := by
      simp only [EncJobSlot, jb_b']
      have hnn_rD : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) := by exact_mod_cast Nat.zero_le (r.val * cp.D_max)
      refine ⟨(wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans ((hfmL base (by omega)).trans hact1),
        hr_le, hr_len,
        (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans ((hfmL (base + 1) (by omega)).trans hw_rlen),
        fun q hq hqs => ?_,
        (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans ((hfmL (base + 2) (by omega)).trans hp2),
        (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hwLL,
        (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hwinsL,
        hsnapL.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide))),
        hdelL.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
          (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide))),
        (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans ((hfmL (base + 7) (by omega)).trans hw_cslot),
        ops.encNode_ext _ cSlot mL mF henc_uL hw9_F
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)⟩
      have hrd_ne4 : readySlotOff cp r.val q ≠ base + 4 := by
        have := r.isLt; simp only [base, readySlotOff, jobMetaBase]; omega
      have hq_M : (readySlots r)[q]'hqs < M_slots cp := hall_lt _
        (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, by
          simp only [hcur_r, jobUsedSlots, hphase]; exact List.mem_append_left _ (List.getElem_mem hqs)⟩))
      exact ⟨(wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans ((hfmL _ hrd_ne4).trans (hready_enc q hq hqs).1),
        ops.encNode_ext _ _ mL mF (hndL _ _ hq_M (hq_ne_cSlot q hqs) (hready_enc q hq hqs).2)
          hw9_F (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)⟩
    refine ⟨ops.slotsReady_ext mL mF hsrL hw9_F (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun t ht9 ht1 _ ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans (hftL t ht9 ht1 ht3 i),
      hfmF_job, hfaF_job,
      fun i hi10 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hfsL i (by omega)),
      fun t ht2 i => (rRead_wWrite _ _ _ _ _ _).trans (hfrL t (by omega) i),
      (rRead_wWrite _ _ _ _ _ _).trans (hfrL engRealTbl (by decide) 0),
      fun mn' s hs hmem_other he0 => ops.encNode_ext mn' s mL mF
        (hndL mn' s hs (hother_ne_cSlot s hmem_other) he0) hw9_F
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      jb_b', readySlots r, cSlot, henc_r_F,
      fun r' => by
        by_cases heq : r' = r
        · subst heq; simp only [Function.update_self]; exact henc_r_F
        · simp only [Function.update_of_ne heq]
          exact encJobSlot_other_of_frame heq (hjobs_enc r')
            (fun s hs => hall_lt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r', hs⟩)))
            hfmF_job hfaF_job (fun mn' s hs hmem_r' he0 =>
              ops.encNode_ext mn' s mL mF
                (hndL mn' s hs (hother_ne_cSlot s (List.mem_append_right _
                  (flatMap_mem_iff_finRange.mpr ⟨r', by simp [if_neg heq, hmem_r']⟩))) he0)
                hw9_F (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)),
      by rwa [hall_eq],
      by rwa [hall_eq],
      by rw [hadv_b1]; exact ⟨wRead_wWrite_self _ _ _ _, rfl⟩⟩
  · -- Build finished (`bs'.insCur ≥ bs'.snapArr.length`): append `cSlot` to `readySlots r`!
    have hcondB1 : (evalArithCond inp 0 mL
        (.intLt (.readHeap engMetaTbl (.lit (base + 4))) (.readHeap engMetaTbl (.lit (base + 5))))).1 = false := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead mL engMetaTbl (base + 4) < wRead mL engMetaTbl (base + 5)) = false
      rw [hwinsL, hsnapL.2.2.1]; exact decide_eq_false (by intro hc; apply hstill; exact_mod_cast hc)
    refine ExecDet.ite' (C_c := 12) (C_b := 2 * ops.C_read + 208) _ _ _ hcondB1
      (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
      (by clear * -; nlinarith)
    let u_done := bs'.curNode
    let newReady := jb.ready ++ [u_done]
    let newRSlots := readySlots r ++ [cSlot]
    have hnew_len : newReady.length = jb.ready.length + 1 := by simp [newReady]
    have hnew_slen : newRSlots.length = newReady.length := by simp [newRSlots, newReady, hr_len]
    have hw_rlen_L : wRead mL engMetaTbl (base + 1) = (jb.ready.length : ℤ) :=
      (hfmL (base + 1) (by omega)).trans hw_rlen
    have hrslot_BW : readySlotOff cp r.val jb.ready.length < (ops.BW : ℤ) := by
      have hr_lt := r.isLt
      have h1 : (r.val + 1) * cp.D_max ≤ cp.D_max * cp.D_max := Nat.mul_le_mul_right _ hr_lt
      have h1Z : ((r.val : ℤ) + 1) * (cp.D_max : ℤ) ≤ (cp.D_max : ℤ) * (cp.D_max : ℤ) := by
        exact_mod_cast h1
      unfold readySlotOff; nlinarith only [h1Z, hrs_lt, hBW_meta]
    have hnn_rD : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) := by exact_mod_cast Nat.zero_le (r.val * cp.D_max)
    refine ExecDet.seq' (2 * ops.C_read + 188)
      (ExecDet.wWrite (C := 20) inp engMetaTbl
        (.add (.lit (readySlotOff cp r.val 0)) (.readHeap engMetaTbl (.lit (base + 1))))
        (.readHeap engScrTbl (.lit 18))
        (readySlotOff cp r.val jb.ready.length) (cSlot : ℤ)
        hfpL (by unfold engMetaTbl; omega) (by unfold readySlotOff; omega) hrslot_BW
        (by simp only [evalIntExpr]
            change readySlotOff cp r.val 0 + wRead mL engMetaTbl (base + 1) = _
            rw [hw_rlen_L]; unfold readySlotOff; omega)
        (by simp only [evalIntExpr]; exact hfsL18)
        (by simp [intExprOps]) rfl)
      (by clear * -; nlinarith) ?_
    intro mA1 hmA1 hfpA1; subst hmA1
    refine ExecDet.seq' (2 * ops.C_read + 168)
      (ExecDet.wWrite (C := 20) inp engMetaTbl (.lit (base + 1))
        (.add (.readHeap engMetaTbl (.lit (base + 1))) (.lit 1))
        (base + 1) ((newReady.length : ℕ) : ℤ)
        hfpA1 (by unfold engMetaTbl; omega) (by simp only [base, jobMetaBase]; omega)
        (by simp only [base, jobMetaBase]; omega) rfl
        (by simp only [evalIntExpr]
            change wRead (H3a.wWrite mL engMetaTbl (readySlotOff cp r.val jb.ready.length) (cSlot : ℤ))
              engMetaTbl (base + 1) + 1 = _
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by have := r.isLt; simp only [base, readySlotOff, jobMetaBase]; omega)),
                hw_rlen_L, hnew_len]
            push_cast; rfl)
        (by simp [intExprOps]) rfl)
      (by clear * -; nlinarith) ?_
    intro mA2 hmA2 hfpA2; subst hmA2
    set mA := H3a.wWrite (H3a.wWrite mL engMetaTbl (readySlotOff cp r.val jb.ready.length) (cSlot : ℤ))
      engMetaTbl (base + 1) ((newReady.length : ℕ) : ℤ)
    have hw9_AL : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mA t i = wRead mL t i := by
      intro t ht9 _ i; simp only [mA, base, wRead_wWrite_eq]
      have : t ≠ engMetaTbl := by unfold engMetaTbl; omega
      simp [this]
    refine ExecDet.seq' (ops.C_read + 168)
      (ops.readNodeScalar_spec inp mA u_done cSlot .resLen 18 19
        hcSlot_M (by omega) (by omega) (by omega) (by omega) hfpA2
        (ops.slotsReady_ext mL mA hsrL hw9_AL (fun _ _ _ _ => by simp [mA, rRead_wWrite]))
        (ops.encNode_ext u_done cSlot mL mA henc_uL hw9_AL
          (fun _ _ _ _ => by simp [mA, rRead_wWrite]) (fun _ _ _ _ => by simp [mA, rRead_wWrite]))
        (by simp [mA, base, wRead_wWrite_eq, engScrTbl, engMetaTbl, hfsL18]))
      (by clear * -; nlinarith) ?_
    intro mR ⟨hsrR, hr19_res, hndR, hftR, hfsR, hfrR⟩ hfpR
    by_cases hsmall : u_done.resArr.length ≤ cp.B_scan
    · -- Case B2: `u_done.resArr.length ≤ cp.B_scan` -> code `2`
      have hcondB2 : (evalArithCond inp 0 mR
          (.intLe (.readHeap engScrTbl (.lit 19)) (.lit (cp.B_scan : ℤ)))).1 = true := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mR engScrTbl 19 ≤ (cp.B_scan : ℤ)) = true
        rw [hr19_res]; exact decide_eq_true (by dsimp [evalNodeScalar]; exact_mod_cast hsmall)
      refine ExecDet.ite' (C_c := 12) (C_b := ops.C_read + 156) _ _ _ hcondB2
        (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
        (by clear * -; nlinarith)
      refine (exec_finishBuildToCopyStmt ops inp r (.lit 0) 0 2 mR hfpR rfl (by simp [intExprOps]) rfl).mono
        ?_ (by clear * -; nlinarith)
      intro mF hmF _; subst hmF
      rcases finishBuildToCopy_post ops r 0 2 hphase hcur_r hrs_lt hact1 hr_len hready_enc
          hw_cslot hjobs_enc hall_nd hall_lt hcSlot_M hq_ne_cSlot hother_ne_cSlot
          henc_uL hndL hftL hfmL hfsL hfrL hndR hftR hfsR hfrR
          hsrR (fun _ _ _ h => h) (fun _ _ _ _ => rfl) (fun _ _ => rfl) (fun _ _ _ => rfl)
        with ⟨hsrF, hftF, hfmF, hfaF, hfsF, hfrF, hr20F, hndF, henc_out, hjobsF, hnd_all, hlt_all, hcodeF, hb7F, huF⟩
      have hadv_b2 : advRes = Sum.inr (newReady, u_done.resArr, false) := by
        rw [hadv_eq, if_neg hstill]; dsimp only; rw [if_pos hsmall]
      refine ⟨hsrF, hftF, hfmF, hfaF, hfsF, hfrF, hr20F, hndF,
        { ready := newReady, phase := .copy (CopyState.init 0) }, newRSlots, 0,
        henc_out, hjobsF, hnd_all, hlt_all, ?_⟩
      rw [hadv_b2]
      exact ⟨rfl, rfl, hnew_slen, henc_out.2.2.2.1, henc_out.2.2.2.2.1,
        Or.inr (Or.inl ⟨hcodeF, rfl, u_done, cSlot, hcSlot_M, hb7F, huF, rfl⟩)⟩
    · -- `cp.B_scan < u_done.resArr.length`
      have hcondB2 : (evalArithCond inp 0 mR
          (.intLe (.readHeap engScrTbl (.lit 19)) (.lit (cp.B_scan : ℤ)))).1 = false := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mR engScrTbl 19 ≤ (cp.B_scan : ℤ)) = false
        rw [hr19_res]; exact decide_eq_false (by dsimp [evalNodeScalar]; intro hc; apply hsmall; exact_mod_cast hc)
      refine ExecDet.ite' (C_c := 12) (C_b := ops.C_read + 156) _ _ _ hcondB2
        (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
        (by clear * -; nlinarith)
      have hw_newlen_R : wRead mR engMetaTbl (base + 1) = (newReady.length : ℤ) := by
        rw [hftR engMetaTbl (by decide) (by decide) (base + 1)]
        simp [mA, base, wRead_wWrite_eq]
      by_cases hovf : cp.D_max ≤ r.val + newReady.length
      · -- Case B3: `cp.D_max ≤ r.val + newReady.length` -> overflow commit code `3`
        have hcondB3 : (evalArithCond inp 0 mR
            (.intLe (.lit (cp.D_max : ℤ))
              (.add (.lit (r.val : ℤ)) (.readHeap engMetaTbl (.lit (base + 1)))))).1 = true := by
          simp only [evalArithCond, evalIntExpr]
          change decide ((cp.D_max : ℤ) ≤ (r.val : ℤ) + wRead mR engMetaTbl (base + 1)) = true
          rw [hw_newlen_R]; exact decide_eq_true (by exact_mod_cast hovf)
        refine ExecDet.ite' (C_c := 12) (C_b := ops.C_read + 144) _ _ _ hcondB3
          (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
          (by clear * -; nlinarith)
        refine (exec_finishBuildToCopyStmt ops inp r (.lit 0) 0 3 mR hfpR rfl (by simp [intExprOps]) rfl).mono
          ?_ (by clear * -; nlinarith)
        intro mF hmF _; subst hmF
        rcases finishBuildToCopy_post ops r 0 3 hphase hcur_r hrs_lt hact1 hr_len hready_enc
            hw_cslot hjobs_enc hall_nd hall_lt hcSlot_M hq_ne_cSlot hother_ne_cSlot
            henc_uL hndL hftL hfmL hfsL hfrL hndR hftR hfsR hfrR
            hsrR (fun _ _ _ h => h) (fun _ _ _ _ => rfl) (fun _ _ => rfl) (fun _ _ _ => rfl)
          with ⟨hsrF, hftF, hfmF, hfaF, hfsF, hfrF, hr20F, hndF, henc_out, hjobsF, hnd_all, hlt_all, hcodeF, _, _⟩
        have hadv_b3 : advRes = Sum.inr (newReady, [], true) := by
          rw [hadv_eq, if_neg hstill]; dsimp only; rw [if_neg hsmall, if_pos hovf]
        refine ⟨hsrF, hftF, hfmF, hfaF, hfsF, hfrF, hr20F, hndF,
          { ready := newReady, phase := .copy (CopyState.init 0) }, newRSlots, 0,
          henc_out, hjobsF, hnd_all, hlt_all, ?_⟩
        rw [hadv_b3]
        exact ⟨rfl, rfl, hnew_slen, henc_out.2.2.2.1, henc_out.2.2.2.2.1,
          Or.inr (Or.inr ⟨hcodeF, rfl, rfl⟩)⟩
      · -- Case B4: `r.val + newReady.length < cp.D_max` -> read `histLen` & continue `.copy`, code `0`
        have hcondB3 : (evalArithCond inp 0 mR
            (.intLe (.lit (cp.D_max : ℤ))
              (.add (.lit (r.val : ℤ)) (.readHeap engMetaTbl (.lit (base + 1)))))).1 = false := by
          simp only [evalArithCond, evalIntExpr]
          change decide ((cp.D_max : ℤ) ≤ (r.val : ℤ) + wRead mR engMetaTbl (base + 1)) = false
          rw [hw_newlen_R]; exact decide_eq_false (by intro hc; apply hovf; exact_mod_cast hc)
        refine ExecDet.ite' (C_c := 12) (C_b := ops.C_read + 144) _ _ _ hcondB3
          (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
          (by clear * -; nlinarith)
        have hr18_R : wRead mR engScrTbl 18 = (cSlot : ℤ) := by
          rw [hfsR 18 (by omega)]; simp [mA, base, wRead_wWrite_eq, engScrTbl, engMetaTbl, hfsL18]
        refine ExecDet.seq' 80
          (ops.readNodeScalar_spec inp mR u_done cSlot .histLen 18 19
            hcSlot_M (by omega) (by omega) (by omega) (by omega) hfpR hsrR
            (hndR u_done cSlot hcSlot_M (ops.encNode_ext u_done cSlot mL mA henc_uL hw9_AL
              (fun _ _ _ _ => by simp [mA, rRead_wWrite]) (fun _ _ _ _ => by simp [mA, rRead_wWrite])))
            hr18_R)
          (by clear * -; nlinarith) ?_
        intro mH ⟨hsrH, hr19_hist, hndH, hftH, hfsH, hfrH⟩ hfpH
        have hr19_eval : (evalIntExpr inp.toWordView 0 mH.words (.readHeap engScrTbl (.lit 19))).1 =
            (u_done.histArr.length : ℤ) := by
          simp only [evalIntExpr]; exact hr19_hist
        have hr19_meta : (evalIntExpr inp.toWordView 0
            (H3a.wWrite mH engMetaTbl (base + 2) 0).words (.readHeap engScrTbl (.lit 19))).1 =
            (u_done.histArr.length : ℤ) := by
          simp only [evalIntExpr]
          change wRead (H3a.wWrite mH engMetaTbl (base + 2) 0) engScrTbl 19 = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]; exact hr19_hist
        refine (exec_finishBuildToCopyStmt ops inp r (.readHeap engScrTbl (.lit 19))
          u_done.histArr.length 0 mH hfpH hr19_eval (by simp [intExprOps]) hr19_meta).mono
          ?_ le_rfl
        intro mF hmF _; subst hmF
        rcases finishBuildToCopy_post ops r u_done.histArr.length 0 hphase hcur_r hrs_lt hact1 hr_len hready_enc
            hw_cslot hjobs_enc hall_nd hall_lt hcSlot_M hq_ne_cSlot hother_ne_cSlot
            henc_uL hndL hftL hfmL hfsL hfrL hndR hftR hfsR hfrR
            hsrH hndH hftH hfsH hfrH
          with ⟨hsrF, hftF, hfmF, hfaF, hfsF, hfrF, hr20F, hndF, henc_out, hjobsF, hnd_all, hlt_all, hcodeF, _, _⟩
        have hadv_b4 : advRes = Sum.inl { ready := newReady, phase := .copy (CopyState.init u_done.histArr.length) } := by
          rw [hadv_eq, if_neg hstill]; dsimp only; rw [if_neg hsmall, if_neg hovf]
        refine ⟨hsrF, hftF, hfmF, hfaF, hfsF, hfrF, hr20F, hndF,
          { ready := newReady, phase := .copy (CopyState.init u_done.histArr.length) }, newRSlots, 0,
          henc_out, hjobsF, hnd_all, hlt_all, ?_⟩
        rw [hadv_b4]; exact ⟨hcodeF, rfl⟩

/-! ### 10. Top-Level Single-Job Subroutine `tickRebuildJobStmt` -/

/-- Complete RAM subroutine advancing active rebuild job `r : Fin cp.D_max` by one Stage-2 tick
(`advanceOneJob`), writing status code `wRead m₁ engScrTbl 10 ∈ {0, 1, 2, 3}` and preserving
`EncJobSlot` and `allSlots'.Nodup` across all outcomes (`TickJobResultPost`). -/
def tickRebuildJobStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .ite (.intEq (.readHeap engMetaTbl (.lit (base + 2))) (.lit 0))
    (tickJobCopyBranchStmt ops r)
    (tickJobBuildBranchStmt ops r)

theorem zeroRand_tickRebuildJobStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (tickRebuildJobStmt ops r) :=
  .ite (zeroRand_tickJobCopyBranchStmt ops r) (zeroRand_tickJobBuildBranchStmt ops r)

def tickRebuildJobCost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  16 + tickJobCopyCost ops + tickJobBuildCost ops

theorem exec_tickRebuildJobStmt
    (h_clm_7_3 : S_clm_7_3_global_approx)
    {d : ℕ} (hd : 1 ≤ d) {params : LocalScaleParams} (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1)
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {actH S_anc : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    {anc : MNode cp} {jb : SuffixJob cp}
    {servLen : ℕ} {servSlots : List ℕ}
    {curJobs : Fin cp.D_max → Option (SuffixJob cp)}
    {readySlots : Fin cp.D_max → List ℕ}
    {curSlots : Fin cp.D_max → ℕ}
    {bits : Fin cp.B_STEP → Bool}
    {m₀ : ArithRAMMemory}
    (hcur_r : curJobs r = some jb)
    (hserv_le : servLen ≤ cp.D_max)
    (hslen : servSlots.length = servLen)
    (hr_serv : r.val < servSlots.length)
    (hS_anc : S_anc ⊆ actH)
    (hact_n : ∀ x ∈ actH, x < cp.n)
    (hact_pts : ∀ x ∈ actH, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hanc_ln : LiveNodeInv cp actH pts gt S_anc anc)
    (hjb_inv : SuffixJobInvSlack cp cp.B_scan actH pts gt S_anc anc r.val jb)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hmeta0 : wRead m₀ engMetaTbl 0 = (servLen : ℤ))
    (hserv_slots : ∀ i (his : i < servSlots.length),
      wRead m₀ engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ))
    (henc_anc : ops.EncNode anc (servSlots[r.val]'hr_serv) m₀)
    (hjobs_enc : ∀ r' : Fin cp.D_max,
      EncJobSlot ops r' (curJobs r') (readySlots r') (curSlots r') m₀)
    (hall_nd : (servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r'))).Nodup)
    (hall_lt : ∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')), s < M_slots cp)
    (hcoins : MemHasStepCoins cp bits m₀) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
      ω₂.1 ⟨r.val * cp.B_scan + j.val, by
        have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
          calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan := Nat.add_lt_add_left j.isLt _
            _ = (r.val + 1) * cp.B_scan := by ring
            _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
        exact Nat.lt_add_right _ this⟩
    let ctrSeed : CenterSeed cp := ω₂.2 r.castSucc
    let advRes := advanceOneJob cp pts gt anc r jb bSeeds ctrSeed
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (tickRebuildJobStmt ops r) m₀
      (TickJobResultPost ops r servSlots curJobs readySlots curSlots advRes m₀)
      (tickRebuildJobCost ops) := by
  intro ω₂ bSeeds ctrSeed advRes
  let base := jobMetaBase cp r.val
  have hj_r := hjobs_enc r
  simp only [EncJobSlot, hcur_r] at hj_r
  unfold tickRebuildJobStmt
  cases hph : jb.phase with
  | copy cs =>
      simp only [hph] at hj_r
      have hp2 : wRead m₀ engMetaTbl (base + 2) = 0 := hj_r.2.2.2.2.2.1
      have hcond : (evalArithCond inp 0 m₀
          (.intEq (.readHeap engMetaTbl (.lit (base + 2))) (.lit 0))).1 = true := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead m₀ engMetaTbl (base + 2) = 0) = true
        rw [hp2]; decide
      refine ExecDet.ite' (C_c := 16) (C_b := tickJobCopyCost ops + tickJobBuildCost ops) _ _ _ hcond
        (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
        (by unfold tickRebuildJobCost; omega)
      exact (exec_tickJobCopyBranchStmt ops inp r hph hcur_r hserv_le hslen hr_serv hS_anc
        hact_n hact_pts hanc_ln hjb_inv hfp₀ hsr₀ hmeta0 hserv_slots henc_anc hjobs_enc
        hall_nd hall_lt hcoins).mono (fun _ hm _ => hm) (by omega)
  | build bs =>
      simp only [hph] at hj_r
      have hp2 : wRead m₀ engMetaTbl (base + 2) = 1 := hj_r.2.2.2.2.2.1
      have hcond : (evalArithCond inp 0 m₀
          (.intEq (.readHeap engMetaTbl (.lit (base + 2))) (.lit 0))).1 = false := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead m₀ engMetaTbl (base + 2) = 0) = false
        rw [hp2]; decide
      refine ExecDet.ite' (C_c := 16) (C_b := tickJobCopyCost ops + tickJobBuildCost ops) _ _ _ hcond
        (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
        (by unfold tickRebuildJobCost; omega)
      exact (exec_tickJobBuildBranchStmt h_clm_7_3 hd he1 hh0 hh1 ops inp r hph hcur_r hS_anc
        hact_n hact_pts hanc_ln hjb_inv hfp₀ hsr₀ hjobs_enc hall_nd hall_lt hcoins).mono
        (fun _ hm _ => hm) (by omega)

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
