import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideA

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2 (forLoopStmt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof_cit_hpj19_thm18 (bitsFnToNat bitsFnToFin)
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot slotWStride slotRStride slotWStride_ge_four
  seedCoordCount seedBitCount capCoordIdx capCoordEquiv capCoordEquiv_val capCoordIdx_lt
  slotRStride_gt_coord slotBktOff_bounds slotNodeOff_bounds
  execScratch_window_to_detExec sw_polyQuantileStmt)

/-! ### 1. Pre-Drawn `coinTbl` Seed Slices & Bridge to `H4c3c.bitsToOpSeedEquiv` -/

/-- Total number of `0/1` coin words consumed by one `DyadicSideIndex.insertHandle` step across
all `L_p2` dyadic scales: `L_p2 * (((R * ℓ) * M₀) * (d + 1) * b)`. -/
def sideSeedStride (L_p2 R ℓ M₀ d b : ℕ) : ℕ :=
  L_p2 * seedBitCount R ℓ M₀ d b

/-- Encoding of a single scale's `ExplicitBitSeed R ℓ M₀ (d + 1) b` in `coinTbl` starting at
word offset `slotSeedOff`. -/
def EncSlotBitSeed (coinTbl : ℕ) (slotSeedOff : ℤ) {R ℓ M₀ d b : ℕ}
    (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b) (m : ArithRAMMemory) : Prop :=
  ∀ (r : Fin R) (a : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)) (bi : Fin b),
    wRead m coinTbl (slotSeedOff + ((capCoordIdx r a k j * b + bi.val : ℕ) : ℤ)) =
      if ω ((r, a, k), j, bi) then 1 else 0

/-- Encoding of an `L_p2`-scale step seed `ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b`
in `coinTbl` starting at word offset `seedBaseOff` (total length `sideSeedStride L_p2 R ℓ M₀ d b`). -/
def EncSideStepSeed (coinTbl : ℕ) (seedBaseOff : ℤ) {L_p2 R ℓ M₀ d b : ℕ}
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b) (m : ArithRAMMemory) : Prop :=
  ∀ s : Fin L_p2,
    EncSlotBitSeed coinTbl
      (seedBaseOff + ((s.val * seedBitCount R ℓ M₀ d b : ℕ) : ℤ))
      (ω_step s) m

theorem EncSlotBitSeed.mono_frame {scrW scrR tblW' coinTbl : ℕ} {baseW' lenW' slotSeedOff : ℤ}
    {tblR' : ℕ} {baseR' lenR' : ℤ} {R ℓ M₀ d b : ℕ}
    {ω : ExplicitBitSeed R ℓ M₀ (d + 1) b} {m₀ m₁ : ArithRAMMemory}
    (hseed : EncSlotBitSeed coinTbl slotSeedOff ω m₀)
    (hfr : RadFrameOutside scrW scrR tblW' baseW' lenW' tblR' baseR' lenR' m₀ m₁)
    (hneScr : coinTbl ≠ scrW)
    (hdisj : coinTbl ≠ tblW' ∨
      slotSeedOff + ((seedBitCount R ℓ M₀ d b : ℕ) : ℤ) ≤ baseW' ∨
      baseW' + lenW' ≤ slotSeedOff) :
    EncSlotBitSeed coinTbl slotSeedOff ω m₁ := by
  intro r a k j bi
  have hc_lt := capCoordIdx_lt r a k j
  have hbi_lt := bi.isLt
  have hidx_lt : capCoordIdx r a k j * b + bi.val < seedBitCount R ℓ M₀ d b := by
    calc capCoordIdx r a k j * b + bi.val
        < capCoordIdx r a k j * b + b := Nat.add_lt_add_left hbi_lt _
      _ = (capCoordIdx r a k j + 1) * b := by ring
      _ ≤ seedCoordCount R ℓ M₀ d * b := Nat.mul_le_mul_right b hc_lt
      _ = seedBitCount R ℓ M₀ d b := rfl
  have hidxZ : ((capCoordIdx r a k j * b + bi.val : ℕ) : ℤ) < ((seedBitCount R ℓ M₀ d b : ℕ) : ℤ) := by
    exact_mod_cast hidx_lt
  have hidx0 : (0 : ℤ) ≤ ((capCoordIdx r a k j * b + bi.val : ℕ) : ℤ) := Nat.cast_nonneg _
  refine (hfr.1 coinTbl _ hneScr ?_).trans (hseed r a k j bi)
  rcases hdisj with ht | h1 | h2
  · exact Or.inl ht
  · exact Or.inr (Or.inl (by omega))
  · exact Or.inr (Or.inr (by omega))

theorem EncSideStepSeed.mono_frame {scrW scrR tblW' coinTbl : ℕ} {baseW' lenW' seedBaseOff : ℤ}
    {tblR' : ℕ} {baseR' lenR' : ℤ} {L_p2 R ℓ M₀ d b : ℕ}
    {ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b} {m₀ m₁ : ArithRAMMemory}
    (hseed : EncSideStepSeed coinTbl seedBaseOff ω_step m₀)
    (hfr : RadFrameOutside scrW scrR tblW' baseW' lenW' tblR' baseR' lenR' m₀ m₁)
    (hneScr : coinTbl ≠ scrW)
    (hdisj : coinTbl ≠ tblW' ∨
      seedBaseOff + ((sideSeedStride L_p2 R ℓ M₀ d b : ℕ) : ℤ) ≤ baseW' ∨
      baseW' + lenW' ≤ seedBaseOff) :
    EncSideStepSeed coinTbl seedBaseOff ω_step m₁ := by
  intro s
  have hs_le : (s.val + 1) * seedBitCount R ℓ M₀ d b ≤ sideSeedStride L_p2 R ℓ M₀ d b :=
    Nat.mul_le_mul_right _ s.isLt
  have hs_add : s.val * seedBitCount R ℓ M₀ d b + seedBitCount R ℓ M₀ d b ≤
      sideSeedStride L_p2 R ℓ M₀ d b := by
    calc s.val * seedBitCount R ℓ M₀ d b + seedBitCount R ℓ M₀ d b
        = (s.val + 1) * seedBitCount R ℓ M₀ d b := by ring
      _ ≤ sideSeedStride L_p2 R ℓ M₀ d b := hs_le
  have hsZ : ((s.val * seedBitCount R ℓ M₀ d b : ℕ) : ℤ) + ((seedBitCount R ℓ M₀ d b : ℕ) : ℤ) ≤
      ((sideSeedStride L_p2 R ℓ M₀ d b : ℕ) : ℤ) := by exact_mod_cast hs_add
  have hs0 : (0 : ℤ) ≤ ((s.val * seedBitCount R ℓ M₀ d b : ℕ) : ℤ) := Nat.cast_nonneg _
  refine (hseed s).mono_frame hfr hneScr ?_
  rcases hdisj with ht | h1 | h2
  · exact Or.inl ht
  · exact Or.inr (Or.inl (by omega))
  · exact Or.inr (Or.inr (by omega))

/-- Direct bridge from an `OpSeed cp` block in `coinTbl` at `opBaseOff` (length `cp.B_op`) to
`EncSideStepSeed` for config `i : Fin cp.N_cfg` and side `side : Bool` (`false = left`, `true = right`). -/
theorem encSideStepSeed_of_opSeed {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : H4c3b.ChainParams d params h)
    (coinTbl : ℕ) (opBaseOff : ℤ)
    (opBits : Fin cp.B_op → Bool) (m : ArithRAMMemory)
    (hop : ∀ idx : Fin cp.B_op, wRead m coinTbl (opBaseOff + (idx.val : ℤ)) = if opBits idx then 1 else 0)
    (i : Fin cp.N_cfg) (side : Bool) :
    let sd : ℕ := if side then 1 else 0
    let seedBaseOff : ℤ :=
      opBaseOff + (((i.val * 2 + sd) * sideSeedStride cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b : ℕ) : ℤ)
    EncSideStepSeed coinTbl seedBaseOff
      (fun s => H4c3c.bitsToOpSeedEquiv cp opBits (i, side, s)) m := by
  intro sd seedBaseOff s r a k j bi
  obtain ⟨hflat, heq⟩ := H4c3c.bitsToOpSeedEquiv_apply cp opBits i side s r a k j bi
  dsimp only
  rw [heq]
  have hoff_eq :
      seedBaseOff + ((s.val * seedBitCount cp.R cp.ℓ cp.M₀ d cp.b : ℕ) : ℤ) +
        ((capCoordIdx r a k j * cp.b + bi.val : ℕ) : ℤ) =
      opBaseOff +
        ((((((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) *
            cp.M₀ + k.val) * (d + 1) + j.val) * cp.b + bi.val : ℕ) : ℤ) := by
    dsimp only [seedBaseOff, sideSeedStride, seedBitCount, seedCoordCount, capCoordIdx]
    push_cast
    ring
  rw [hoff_eq]
  exact hop ⟨_, hflat⟩

/-! ### 2. `ZeroRandStmt` Helpers for `forLoopStmt` and `polyQuantileStmt` -/

theorem zeroRand_forLoopStmt (scrW : ℕ) (idx : ℤ) (N : ℕ) {b : ArithRAMStmt}
    (hb : H3a.ZeroRandStmt b) : H3a.ZeroRandStmt (forLoopStmt scrW idx N b) :=
  .seq (.writeWordHeap _ _ _) (.repeatN (.seq hb (.writeWordHeap _ _ _)))

theorem zeroRand_polyQuantileStmt (scrW scrR : ℕ) (wK wBase rBase rOut : ℤ) (b T p_coord : ℕ) :
    H3a.ZeroRandStmt (polyQuantileStmt scrW scrR wK wBase rBase rOut b T p_coord) := by
  have hg : ∀ (wB : ℤ) (rY rT rA : ℤ) (K : ℕ),
      H3a.ZeroRandStmt (gaussIntPolyStmt scrW scrR wB rY rT rA K) := fun _ _ _ _ _ =>
    .seq (.writeRealHeap _ _ _)
      (.seq (.writeRealHeap _ _ _)
        (zeroRand_forLoopStmt _ _ _ (.seq (.writeRealHeap _ _ _) (.writeRealHeap _ _ _))))
  have hcdf : ∀ (wB : ℤ) (rX rY rT rA rO : ℤ) (K : ℕ) (cp : ℚ),
      H3a.ZeroRandStmt (polyCDFStmt scrW scrR wB rX rY rT rA rO K cp) := fun _ _ _ _ _ _ _ _ =>
    .ite (.seq (.writeRealHeap _ _ _) (.seq (hg _ _ _ _ _) (.writeRealHeap _ _ _)))
         (.seq (.writeRealHeap _ _ _) (.seq (hg _ _ _ _ _) (.writeRealHeap _ _ _)))
  unfold polyQuantileStmt
  exact .ite (.writeRealHeap _ _ _)
    (.seq (.writeRealHeap _ _ _)
    (.seq (zeroRand_forLoopStmt _ _ _ (.writeRealHeap _ _ _))
    (.seq (.writeRealHeap _ _ _)
    (.seq (.writeRealHeap _ _ _)
    (.seq (.writeRealHeap _ _ _)
    (.seq (zeroRand_forLoopStmt _ _ _
            (.seq (.writeRealHeap _ _ _)
              (.seq (hcdf _ _ _ _ _ _ _ _)
                (.ite (.writeRealHeap _ _ _) (.writeRealHeap _ _ _)))))
          (.writeRealHeap _ _ _)))))))

/-! ### 3. Deterministic `readBIntFromCoinTblStmt` & `slotInitFromCoinTblStmt` -/

def readBIntFromCoinTblStmt (scrW coinTbl : ℕ) (wBitCur wK : ℤ) (b : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit wK) (.lit 0))
    (.repeatN (.lit (b : ℤ))
      (.seq (.writeWordHeap scrW (.lit wK)
              (.add (.mul (.lit 2) (.readHeap scrW (.lit wK)))
                    (.readHeap coinTbl (.readHeap scrW (.lit wBitCur)))))
            (.writeWordHeap scrW (.lit wBitCur)
              (.add (.readHeap scrW (.lit wBitCur)) (.lit 1)))))

theorem zeroRand_readBIntFromCoinTblStmt (scrW coinTbl : ℕ) (wBitCur wK : ℤ) (b : ℕ) :
    H3a.ZeroRandStmt (readBIntFromCoinTblStmt scrW coinTbl wBitCur wK b) :=
  of_isZeroRandB rfl

private def bitPrefix {b : ℕ} (f : Fin b → Bool) : ℕ → ℕ
  | 0 => 0
  | k + 1 =>
      if hk : k < b then 2 * bitPrefix f k + (if f ⟨k, hk⟩ then 1 else 0) else bitPrefix f k

private lemma bitPrefix_eq_bitsFnToNat {b : ℕ} (f : Fin b → Bool) :
    ∀ (k : ℕ) (hk : k ≤ b),
      bitPrefix f k = bitsFnToNat k (fun j : Fin k => f ⟨j.val, lt_of_lt_of_le j.isLt hk⟩)
  | 0, _ => by simp [bitPrefix, bitsFnToNat]
  | k + 1, hk => by
      have hk_lt : k < b := by omega
      simp only [bitPrefix, dif_pos hk_lt, bitPrefix_eq_bitsFnToNat f k (by omega)]
      rfl

theorem exec_readBIntFromCoinTblStmt {d TW BW TR BR scrW scrR coinTbl tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBitCur wK bitOff baseW baseR : ℤ) {b : ℕ} (f : Fin b → Bool)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW)
    (hneCoinScr : coinTbl ≠ scrW)
    (hwCur : 0 ≤ wBitCur ∧ wBitCur < (BW : ℤ))
    (hwK : 0 ≤ wK ∧ wK < (BW : ℤ))
    (hneCurK : wBitCur ≠ wK)
    (hcur₀ : wRead m₀ scrW wBitCur = bitOff)
    (hbits : ∀ bi : Fin b, wRead m₀ coinTbl (bitOff + (bi.val : ℤ)) = if f bi then 1 else 0) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (readBIntFromCoinTblStmt scrW coinTbl wBitCur wK b) m₀ m₁ (20 + 35 * b) ∧
      InFootprint TW BW TR BR m₁ ∧
      wRead m₁ scrW wK = ((bitsFnToFin b f).val : ℤ) ∧
      wRead m₁ scrW wBitCur = bitOff + (b : ℤ) ∧
      (∀ w, w ≠ wK → w ≠ wBitCur → wRead m₁ scrW w = wRead m₀ scrW w) ∧
      (∀ t i, rRead m₁ t i = rRead m₀ t i) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  let m_init := wWrite m₀ scrW wK 0
  have hd_init : DetExec inp (.writeWordHeap scrW (.lit wK) (.lit 0)) m₀ m_init 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wK) (.lit 0) rfl rfl (by dsimp [intExprOps]; omega)
  have hfp_init : InFootprint TW BW TR BR m_init := InFootprint.wWrite hfp₀ hscrW hwK.1 hwK.2
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    InFootprint TW BW TR BR m ∧
    wRead m scrW wK = (bitPrefix f k : ℤ) ∧
    wRead m scrW wBitCur = bitOff + (k : ℤ) ∧
    (∀ w, w ≠ wK → w ≠ wBitCur → wRead m scrW w = wRead m₀ scrW w) ∧
    (∀ t i, rRead m t i = rRead m₀ t i) ∧
    RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
  have hInv0 : Inv 0 m_init :=
    ⟨hfp_init, wRead_wWrite_self _ _ _ _,
     by rw [wRead_wWrite_of_ne _ _ (Or.inr hneCurK), hcur₀]; ring,
     fun w hw1 _ => wRead_wWrite_of_ne _ _ (Or.inr hw1),
     fun _ _ => rfl,
     RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ wK 0⟩
  let body : ArithRAMStmt :=
    .seq (.writeWordHeap scrW (.lit wK)
            (.add (.mul (.lit 2) (.readHeap scrW (.lit wK)))
                  (.readHeap coinTbl (.readHeap scrW (.lit wBitCur)))))
          (.writeWordHeap scrW (.lit wBitCur)
            (.add (.readHeap scrW (.lit wBitCur)) (.lit 1)))
  obtain ⟨m₁, hInvB, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (b : ℤ)) body b 5 35 Inv hInv0 rfl
    (by dsimp [intExprOps]; omega) (fun i hi m hIm => by
      rcases hIm with ⟨hfp_m, hk_m, hcur_m, hkW_m, hkR_m, hfr_m⟩
      have hcoin_i : wRead m coinTbl (bitOff + (i : ℤ)) = if f ⟨i, hi⟩ then 1 else 0 := by
        have ho : coinTbl ≠ tblW ∨ bitOff + (i : ℤ) < baseW ∨ baseW + 0 ≤ bitOff + (i : ℤ) := by
          rcases lt_or_ge (bitOff + (i : ℤ)) baseW with h | h
          · exact Or.inr (Or.inl h)
          · exact Or.inr (Or.inr (by omega))
        exact (hfr_m.1 coinTbl _ hneCoinScr ho).trans (hbits ⟨i, hi⟩)
      have hpfx_succ : bitPrefix f (i + 1) = 2 * bitPrefix f i + (if f ⟨i, hi⟩ then 1 else 0) := by
        simp [bitPrefix, dif_pos hi]
      let m_a := wWrite m scrW wK (bitPrefix f (i + 1) : ℤ)
      let m_b := wWrite m_a scrW wBitCur (bitOff + ((i + 1 : ℕ) : ℤ))
      have hd_a : DetExec inp (.writeWordHeap scrW (.lit wK)
          (.add (.mul (.lit 2) (.readHeap scrW (.lit wK)))
                (.readHeap coinTbl (.readHeap scrW (.lit wBitCur))))) m m_a 20 :=
        DetExecAt.writeWordHeap 0 inp m scrW (.lit wK) _ rfl
          (by change 2 * wRead m scrW wK + wRead m coinTbl (wRead m scrW wBitCur) = _
              rw [hk_m, hcur_m, hcoin_i, hpfx_succ]
              split_ifs <;> push_cast <;> ring)
          (by dsimp [intExprOps]; omega)
      have hd_b : DetExec inp (.writeWordHeap scrW (.lit wBitCur)
          (.add (.readHeap scrW (.lit wBitCur)) (.lit 1))) m_a m_b 15 :=
        DetExecAt.writeWordHeap 0 inp m_a scrW (.lit wBitCur) _ rfl
          (by change wRead m_a scrW wBitCur + 1 = _
              rw [wRead_wWrite_of_ne _ _ (Or.inr hneCurK), hcur_m]; push_cast; ring)
          (by dsimp [intExprOps]; omega)
      have hfp_b : InFootprint TW BW TR BR m_b :=
        InFootprint.wWrite (InFootprint.wWrite hfp_m hscrW hwK.1 hwK.2) hscrW hwCur.1 hwCur.2
      refine ⟨m_b, hd_a.seq hd_b, hfp_b,
        (wRead_wWrite_of_ne _ _ (Or.inr hneCurK.symm)).trans (wRead_wWrite_self _ _ _ _),
        wRead_wWrite_self _ _ _ _,
        fun w hw1 hw2 => ?_,
        fun _ _ => hkR_m _ _,
        (hfr_m.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m _ _)).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_a _ _)⟩
      rw [wRead_wWrite_of_ne _ _ (Or.inr hw2), wRead_wWrite_of_ne _ _ (Or.inr hw1)]
      exact hkW_m w hw1 hw2)
  rcases hInvB with ⟨hfp₁, hk₁, hcur₁, hkW₁, hkR₁, hfr₁⟩
  have hpfx_b : bitPrefix f b = (bitsFnToFin b f).val :=
    bitPrefix_eq_bitsFnToNat f b le_rfl
  rw [hpfx_b] at hk₁
  exact ⟨m₁, (hd_init.seq hd_loop).mono_cost (by omega), hfp₁, hk₁, hcur₁, hkW₁, hkR₁, hfr₁⟩

noncomputable def slotInitFromCoinTblStmt (scrW scrR tblW tblR coinTbl : ℕ)
    (wBaseW wBaseR wNewBlk wSlotSeedOff wScrBase rScrBase : ℤ)
    (R ℓ M₀ d b T p_coord : ℕ) : ArithRAMStmt :=
  let N_cap := seedCoordCount R ℓ M₀ d
  let wCoordCtr := wScrBase
  let wBitCur := wScrBase + 1
  let wK := wScrBase + 2
  let wQBase := wScrBase + 3
  let rQBase := rScrBase
  let rQOut := rScrBase + 8
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  let bR := IntExpr.readHeap scrW (.lit wBaseR)
  .seq (.writeWordHeap tblW bW (.add (.readHeap tblW bW) (.lit 1)))
  (.seq (.writeWordHeap tblW (.add bW (.lit 1)) (.readHeap scrW (.lit wNewBlk)))
  (.seq (.writeWordHeap tblW (.add bW (.lit 2)) (.lit 0))
  (.seq (.writeWordHeap scrW (.lit wBitCur) (.readHeap scrW (.lit wSlotSeedOff)))
  (.seq (.writeWordHeap scrW (.lit wCoordCtr) (.lit 0))
        (.repeatN (.lit (N_cap : ℤ))
          (.seq (readBIntFromCoinTblStmt scrW coinTbl wBitCur wK b)
          (.seq (polyQuantileStmt scrW scrR wK wQBase rQBase rQOut b T p_coord)
          (.seq (.writeRealHeap tblR (.add bR (.readHeap scrW (.lit wCoordCtr)))
                  (.readRealHeap scrR (.lit rQOut)))
                (.writeWordHeap scrW (.lit wCoordCtr)
                  (.add (.readHeap scrW (.lit wCoordCtr)) (.lit 1)))))))))))

def slotInitFromCoinTblCost (R ℓ M₀ d b T p_coord : ℕ) : ℕ :=
  160 + seedCoordCount R ℓ M₀ d *
    (300 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b))

theorem zeroRand_slotInitFromCoinTblStmt (scrW scrR tblW tblR coinTbl : ℕ)
    (wBaseW wBaseR wNewBlk wSlotSeedOff wScrBase rScrBase : ℤ)
    (R ℓ M₀ d b T p_coord : ℕ) :
    H3a.ZeroRandStmt (slotInitFromCoinTblStmt scrW scrR tblW tblR coinTbl
      wBaseW wBaseR wNewBlk wSlotSeedOff wScrBase rScrBase R ℓ M₀ d b T p_coord) :=
  .seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
        (.repeatN
          (.seq (zeroRand_readBIntFromCoinTblStmt _ _ _ _ _)
          (.seq (zeroRand_polyQuantileStmt _ _ _ _ _ _ _ _ _)
          (.seq (.writeRealHeap _ _ _) (.writeWordHeap _ _ _)))))))))

theorem exec_slotInitFromCoinTblStmt {d TW BW TR BR scrW scrR tblW tblR coinTbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBaseR wNewBlk wSlotSeedOff wScrBase rScrBase baseW baseR newBlk slotSeedOff : ℤ)
    {R ℓ M₀ cap_u B_max : ℕ} (b T p_coord : ℕ)
    (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (S : LiveSlot R ℓ M₀ d)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneCoinScr : coinTbl ≠ scrW)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hbaseR : 0 ≤ baseR ∧ baseR + slotRStride R ℓ M₀ d ≤ (BR : ℤ))
    (hwScr : 0 ≤ wScrBase ∧ wScrBase + 5 ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScrBase ∧ rScrBase + 9 ≤ (BR : ℤ))
    (hdisjBW : wBaseW < wScrBase ∨ wScrBase + 5 ≤ wBaseW)
    (hdisjBR : wBaseR < wScrBase ∨ wScrBase + 5 ≤ wBaseR)
    (hdisjCoinW : coinTbl ≠ tblW ∨
      slotSeedOff + ((seedBitCount R ℓ M₀ d b : ℕ) : ℤ) ≤ baseW ∨
      baseW + slotWStride R ℓ M₀ cap_u B_max ≤ slotSeedOff)
    (hbW : wRead m₀ scrW wBaseW = baseW)
    (hbR : wRead m₀ scrW wBaseR = baseR)
    (hblk : wRead m₀ scrW wNewBlk = newBlk)
    (hseedOff : wRead m₀ scrW wSlotSeedOff = slotSeedOff)
    (hseed : EncSlotBitSeed coinTbl slotSeedOff ω m₀)
    (henc : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (slotInitFromCoinTblStmt scrW scrR tblW tblR coinTbl
          wBaseW wBaseR wNewBlk wSlotSeedOff wScrBase rScrBase R ℓ M₀ d b T p_coord)
        m₀ m₁ (slotInitFromCoinTblCost R ℓ M₀ d b T p_coord) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max
        (S.init (S.ep + 1) newBlk T p_coord ω) m₁ ∧
      (∀ w, (w < wScrBase ∨ wScrBase + 5 ≤ w) → wRead m₁ scrW w = wRead m₀ scrW w) ∧
      (∀ r, (r < rScrBase ∨ rScrBase + 9 ≤ r) → rRead m₁ scrR r = rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR
        tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
        tblR baseR (slotRStride R ℓ M₀ d) m₀ m₁ := by
  let _ := hdisjBW
  let N_cap := seedCoordCount R ℓ M₀ d
  let C_q := 200 + 25 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b)
  let C_iter := (20 + 35 * b) + C_q + 40
  have hge4 := slotWStride_ge_four R ℓ M₀ cap_u B_max
  rcases henc with ⟨hep₀, _, _, _, hbkt₀, hnd₀⟩
  let m1 := wWrite m₀ tblW baseW ((S.ep + 1 : ℕ) : ℤ)
  let m2 := wWrite m1 tblW (baseW + 1) newBlk
  let m3 := wWrite m2 tblW (baseW + 2) 0
  let m4 := wWrite m3 scrW (wScrBase + 1) slotSeedOff
  let m5 := wWrite m4 scrW wScrBase 0
  have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wBaseW))
      (.add (.readHeap tblW (.readHeap scrW (.lit wBaseW))) (.lit 1))) m₀ m1 30 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW _ _ hbW
      (by change wRead m₀ tblW (wRead m₀ scrW wBaseW) + 1 = _; rw [hbW, hep₀]; push_cast; ring)
      (by dsimp [intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 1))
      (.readHeap scrW (.lit wNewBlk))) m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 tblW _ _
      (by change wRead m1 scrW wBaseW + 1 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      (by change wRead m1 scrW wNewBlk = _; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hblk])
      (by dsimp [intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 2)) (.lit 0))
      m2 m3 25 :=
    DetExecAt.writeWordHeap 0 inp m2 tblW _ (.lit 0)
      (by change wRead m2 scrW wBaseW + 2 = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [intExprOps]; omega)
  have hd4 : DetExec inp (.writeWordHeap scrW (.lit (wScrBase + 1))
      (.readHeap scrW (.lit wSlotSeedOff))) m3 m4 15 :=
    DetExecAt.writeWordHeap 0 inp m3 scrW (.lit (wScrBase + 1)) _ rfl
      (by change wRead m3 scrW wSlotSeedOff = slotSeedOff
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
              wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
              wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hseedOff])
      (by dsimp [intExprOps]; omega)
  have hd5 : DetExec inp (.writeWordHeap scrW (.lit wScrBase) (.lit 0)) m4 m5 10 :=
    DetExecAt.writeWordHeap 0 inp m4 scrW (.lit wScrBase) (.lit 0) rfl rfl
      (by dsimp [intExprOps]; omega)
  have hfp5 : InFootprint TW BW TR BR m5 :=
    InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite
      (InFootprint.wWrite (InFootprint.wWrite hfp₀ htblW hbaseW.1 (by omega))
        htblW (by omega) (by omega)) htblW (by omega) (by omega))
        hscrW (by omega) (by omega)) hscrW hwScr.1 (by omega)
  have hfr5 : RadFrameOutside scrW scrR
      tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
      tblR baseR (slotRStride R ℓ M₀ d) m₀ m5 :=
    ((((RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m₀ (idx := baseW) ((S.ep + 1 : ℕ) : ℤ) le_rfl (by omega)).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m1 (idx := baseW + 1) newBlk (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m2 (idx := baseW + 2) 0 (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m3 (wScrBase + 1) slotSeedOff)).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m4 wScrBase 0)
  let chunkAt : ∀ idx, idx < N_cap → (Fin b → Bool) := fun idx hidx =>
    let p := (capCoordEquiv R ℓ M₀ d).symm ⟨idx, hidx⟩
    fun bi => ω (p.1, p.2, bi)
  let Inv : ℕ → ArithRAMMemory → Prop := fun i m =>
    InFootprint TW BW TR BR m ∧
    wRead m scrW wScrBase = (i : ℤ) ∧
    wRead m scrW (wScrBase + 1) = slotSeedOff + ((i * b : ℕ) : ℤ) ∧
    (∀ (idx : ℕ) (hidx : idx < N_cap), idx < i →
      rRead m tblR (baseR + (idx : ℤ)) =
        ((polySample1D b T p_coord (bitsFnToFin b (chunkAt idx hidx)) : ℚ) : ℝ)) ∧
    (∀ t idx, t ≠ scrW → wRead m t idx = wRead m5 t idx) ∧
    (∀ w, (w < wScrBase ∨ wScrBase + 5 ≤ w) → wRead m scrW w = wRead m₀ scrW w) ∧
    (∀ r, (r < rScrBase ∨ rScrBase + 9 ≤ r) → rRead m scrR r = rRead m₀ scrR r) ∧
    RadFrameOutside scrW scrR
      tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
      tblR baseR (slotRStride R ℓ M₀ d) m₀ m
  have hInv0 : Inv 0 m5 := by
    refine ⟨hfp5, wRead_wWrite_self _ _ _ _,
      by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; simp,
      fun _ _ h => by omega,
      fun _ _ _ => rfl, ?_, ?_, hfr5⟩
    · intro w hw
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
    · intro r _
      simp only [m5, m4, m3, m2, m1, rRead_wWrite]
  let loopBody : ArithRAMStmt :=
    .seq (readBIntFromCoinTblStmt scrW coinTbl (wScrBase + 1) (wScrBase + 2) b)
    (.seq (polyQuantileStmt scrW scrR (wScrBase + 2) (wScrBase + 3) rScrBase (rScrBase + 8) b T p_coord)
    (.seq (.writeRealHeap tblR (.add (.readHeap scrW (.lit wBaseR)) (.readHeap scrW (.lit wScrBase)))
            (.readRealHeap scrR (.lit (rScrBase + 8))))
          (.writeWordHeap scrW (.lit wScrBase)
            (.add (.readHeap scrW (.lit wScrBase)) (.lit 1)))))
  obtain ⟨m_end, hInvN, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (N_cap : ℤ)) loopBody N_cap 5 C_iter
    Inv hInv0 rfl (by dsimp [intExprOps]; omega) (fun i hi m hIm => by
      rcases hIm with ⟨hfp_m, hctr_m, hcur_m, hcaps_m, hw5_m, hkW_m, hkR_m, hfr_m⟩
      have hseed_m : EncSlotBitSeed coinTbl slotSeedOff ω m :=
        hseed.mono_frame hfr_m hneCoinScr hdisjCoinW
      let p_i := (capCoordEquiv R ℓ M₀ d).symm ⟨i, hi⟩
      have hp_idx : capCoordIdx p_i.1.1 p_i.1.2.1 p_i.1.2.2 p_i.2 = i := by
        have h1 := capCoordEquiv_val p_i.1.1 p_i.1.2.1 p_i.1.2.2 p_i.2
        have h2 : ((capCoordEquiv R ℓ M₀ d) p_i).val = i := by
          dsimp [p_i]; rw [Equiv.apply_symm_apply]
        exact h1.symm.trans h2
      have hbits_i : ∀ bi : Fin b,
          wRead m coinTbl ((slotSeedOff + ((i * b : ℕ) : ℤ)) + (bi.val : ℤ)) =
            if chunkAt i hi bi then 1 else 0 := by
        intro bi
        have hoff_eq : (slotSeedOff + ((i * b : ℕ) : ℤ)) + (bi.val : ℤ) =
            slotSeedOff + ((capCoordIdx p_i.1.1 p_i.1.2.1 p_i.1.2.2 p_i.2 * b + bi.val : ℕ) : ℤ) := by
          rw [hp_idx]; push_cast; ring
        rw [hoff_eq]
        exact hseed_m p_i.1.1 p_i.1.2.1 p_i.1.2.2 p_i.2 bi
      obtain ⟨m_s, hd_s, hfp_s, hk_s, hcur_s, hkW_s, hkR_s, hfr_s⟩ :=
        exec_readBIntFromCoinTblStmt (scrR := scrR) (tblW := tblW) (tblR := tblR)
          inp (wScrBase + 1) (wScrBase + 2) (slotSeedOff + ((i * b : ℕ) : ℤ)) baseW baseR
          (chunkAt i hi) hfp_m hscrW hneCoinScr
          ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ (by omega) hcur_m hbits_i
      let k_fin : Fin (2 ^ b) := bitsFnToFin b (chunkAt i hi)
      have hex_q := exec_polyQuantileStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
        (scrW := scrW) (scrR := scrR) inp (wScrBase + 2) (wScrBase + 3) rScrBase (rScrBase + 8)
        b T p_coord k_fin hfp_s hscrW hscrR ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
        (Or.inl (by omega)) ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ hk_s
      obtain ⟨m_q, hpr_q, hout_q, hfp_q, hkW_q, hkR_q, hd_q⟩ :=
        execScratch_window_to_detExec
          (sw_polyQuantileStmt scrW scrR (wScrBase + 2) (wScrBase + 3) rScrBase (rScrBase + 8) b T p_coord)
          hfp_s hex_q
      have hctr_q : wRead m_q scrW wScrBase = (i : ℤ) :=
        (hkW_q wScrBase (by omega)).trans ((hkW_s wScrBase (by omega) (by omega)).trans hctr_m)
      have hcur_q : wRead m_q scrW (wScrBase + 1) = slotSeedOff + (((i + 1) * b : ℕ) : ℤ) := by
        have h1 := (hkW_q (wScrBase + 1) (by omega)).trans hcur_s
        have hadd : slotSeedOff + ((i * b : ℕ) : ℤ) + (b : ℤ) = slotSeedOff + (((i + 1) * b : ℕ) : ℤ) := by
          push_cast; ring
        exact h1.trans hadd
      have hbR_q : wRead m_q scrW wBaseR = baseR :=
        (hkW_q wBaseR (by rcases hdisjBR with h | h <;> omega)).trans
          ((hkW_s wBaseR (by rcases hdisjBR with h | h <;> omega)
                         (by rcases hdisjBR with h | h <;> omega)).trans
            ((hkW_m wBaseR hdisjBR).trans hbR))
      let val_i : ℝ := ((polySample1D b T p_coord k_fin : ℚ) : ℝ)
      let m_w := rWrite m_q tblR (baseR + (i : ℤ)) val_i
      let m_n := wWrite m_w scrW wScrBase ((i + 1 : ℕ) : ℤ)
      have hd_w : DetExec inp (.writeRealHeap tblR
          (.add (.readHeap scrW (.lit wBaseR)) (.readHeap scrW (.lit wScrBase)))
          (.readRealHeap scrR (.lit (rScrBase + 8)))) m_q m_w 25 :=
        DetExecAt.writeRealHeap 0 inp m_q tblR _ _
          (by change wRead m_q scrW wBaseR + wRead m_q scrW wScrBase = _; rw [hbR_q, hctr_q])
          hout_q
          (by dsimp [intExprOps, realExprOps]; omega)
      have hd_n : DetExec inp (.writeWordHeap scrW (.lit wScrBase)
          (.add (.readHeap scrW (.lit wScrBase)) (.lit 1))) m_w m_n 15 :=
        DetExecAt.writeWordHeap 0 inp m_w scrW (.lit wScrBase) _ rfl
          (by change wRead m_w scrW wScrBase + 1 = _; rw [wRead_rWrite, hctr_q]; push_cast; ring)
          (by dsimp [intExprOps]; omega)
      have hi_lt_R : (i : ℤ) < slotRStride R ℓ M₀ d := slotRStride_gt_coord hi
      have hfp_w : InFootprint TW BW TR BR m_w := InFootprint.rWrite hfp_q htblR (by omega) (by omega)
      have hfp_n : InFootprint TW BW TR BR m_n := InFootprint.wWrite hfp_w hscrW hwScr.1 (by omega)
      have hfr_s_wide : RadFrameOutside scrW scrR
          tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
          tblR baseR (slotRStride R ℓ M₀ d) m m_s :=
        hfr_s.mono_range (Or.inl rfl) (Or.inl rfl)
      have hfr_q_wide : RadFrameOutside scrW scrR
          tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
          tblR baseR (slotRStride R ℓ M₀ d) m_s m_q :=
        RadFrameOutside.of_preservesNonScratch _ _ _ _ _ _ hpr_q
      have hfr_w : RadFrameOutside scrW scrR
          tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
          tblR baseR (slotRStride R ℓ M₀ d) m_q m_w :=
        RadFrameOutside.rWrite_in _ _ _ _ _ _ _ _ m_q (idx := baseR + (i : ℤ)) val_i (by omega) (by omega)
      have hfr_n : RadFrameOutside scrW scrR
          tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
          tblR baseR (slotRStride R ℓ M₀ d) m_w m_n :=
        RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_w wScrBase ((i + 1 : ℕ) : ℤ)
      refine ⟨m_n, (hd_s.seq (hd_q.seq (hd_w.seq hd_n))).mono_cost (by dsimp only [C_iter, C_q]; omega),
        hfp_n, wRead_wWrite_self _ _ _ _,
        (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (by rw [wRead_rWrite]; exact hcur_q),
        ?_, ?_, ?_, ?_,
        (((hfr_m.trans hfr_s_wide).trans hfr_q_wide).trans hfr_w).trans hfr_n⟩
      · intro idx hidx hlt
        rw [rRead_wWrite]
        by_cases he : idx = i
        · subst he; exact rRead_rWrite_self _ _ _ _
        · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega)),
              hpr_q.2 tblR hneR, hkR_s tblR _]
          exact hcaps_m idx hidx (by omega)
      · intro t idx ht
        rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_rWrite, hpr_q.1 t ht]
        have ho : t ≠ tblW ∨ idx < baseW ∨ baseW + 0 ≤ idx := by
          rcases lt_or_ge idx baseW with h | h
          · exact Or.inr (Or.inl h)
          · exact Or.inr (Or.inr (by omega))
        exact (hfr_s.1 t idx ht ho).trans (hw5_m t idx ht)
      · intro w hw
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite]
        exact (hkW_q w (by omega)).trans ((hkW_s w (by omega) (by omega)).trans (hkW_m w hw))
      · intro r hr
        rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hneR.symm)]
        exact (hkR_q r (by omega)).trans ((hkR_s scrR r).trans (hkR_m r hr)))
  rcases hInvN with ⟨hfp₁, _, _, hcaps₁, hw5₁, hkW₁, hkR₁, hfr₁⟩
  have hw_tbl : ∀ i, wRead m_end tblW i = wRead m5 tblW i := fun i => hw5₁ tblW i hneW
  have hm5_tbl : ∀ i, baseW + 4 ≤ i → wRead m5 tblW i = wRead m₀ tblW i := by
    intro i hlo
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  have hcost_tot : 30 + (25 + (25 + (15 + (10 + (5 + N_cap * C_iter))))) ≤
      slotInitFromCoinTblCost R ℓ M₀ d b T p_coord := by
    unfold slotInitFromCoinTblCost
    have hmul : N_cap * C_iter ≤
        N_cap * (300 + 60 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b)) :=
      Nat.mul_le_mul_left N_cap (by dsimp only [C_iter, C_q]; omega)
    dsimp only [N_cap] at hmul ⊢
    omega
  refine ⟨m_end, (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq hd_loop))))).mono_cost hcost_tot,
    hfp₁, ⟨?_, ?_, ?_, fun r s k j => ?_, fun bkt hb => ?_, fun nd hn => ?_⟩,
    hkW₁, hkR₁, hfr₁⟩
  · rw [hw_tbl, wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
  · rw [hw_tbl, wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
  · rw [hw_tbl, wRead_wWrite_of_ne _ _ (Or.inl hneW),
        wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_self]; rfl
  · let cIdx := capCoordIdx r s k j
    have hc_lt : cIdx < N_cap := capCoordIdx_lt r s k j
    rw [hcaps₁ cIdx hc_lt hc_lt]
    have hch_eq : chunkAt cIdx hc_lt = fun bi : Fin b => ω ((r, s, k), j, bi) := by
      funext bi
      dsimp only [chunkAt]
      have h_fin : (⟨cIdx, hc_lt⟩ : Fin N_cap) = capCoordEquiv R ℓ M₀ d ((r, s, k), j) :=
        Fin.ext (capCoordEquiv_val r s k j).symm
      rw [h_fin, Equiv.symm_apply_apply]
    rw [hch_eq]
    dsimp [LiveSlot.init, polyFDisc]
    rw [UL.Proof_clm_6_1_precision_RaceV30.euclideanCoord_ratPointToEuclidean]
  · have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hb
    rcases hbkt₀ bkt hb with ⟨h1, h2⟩
    exact ⟨(hw_tbl _).trans ((hm5_tbl _ (by omega)).trans h1),
           (hw_tbl _).trans ((hm5_tbl _ (by omega)).trans h2)⟩
  · have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hn
    have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
    rcases hnd₀ nd hn with ⟨h1, h2, h3, h4, h5⟩
    exact ⟨(hw_tbl _).trans ((hm5_tbl _ (by omega)).trans h1),
           (hw_tbl _).trans ((hm5_tbl _ (by omega)).trans h2),
           (hw_tbl _).trans ((hm5_tbl _ (by omega)).trans h3),
           (hw_tbl _).trans ((hm5_tbl _ (by omega)).trans h4),
           (hw_tbl _).trans ((hm5_tbl _ (by omega)).trans h5)⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
