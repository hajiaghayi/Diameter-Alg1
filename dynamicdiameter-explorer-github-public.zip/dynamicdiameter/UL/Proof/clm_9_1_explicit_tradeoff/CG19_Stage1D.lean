import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Stage1D1
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c


def jobSlotUpdateStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .ite (.and (.intEq (.readHeap engMetaTbl (.readHeap engScrTbl (.lit 21))) (.lit 1))
              (.and (.intLt (.readHeap engScrTbl (.lit 20)) (.readHeap engScrTbl (.lit 22)))
                    (.intEq (.readHeap engScrTbl (.lit 23)) (.lit 1))))
    (.seq (.writeWordHeap engScrTbl (.lit 11)
            (.add (.lit (16 + 9 * (cp.D_max : ℤ)))
                  (.mul (.readHeap engScrTbl (.lit 20)) (.lit (cp.D_max : ℤ)))))
    (.seq (.writeWordHeap engScrTbl (.lit 12)
            (.readHeap engMetaTbl (.add (.readHeap engScrTbl (.lit 21)) (.lit 1))))
    (.seq (.writeWordHeap engScrTbl (.lit 13)
            (.add (.lit (cp.D_max : ℤ))
                  (.mul (.readHeap engScrTbl (.lit 20)) (.lit (cp.D_max : ℤ)))))
    (.seq (liveUpdateListStmt ops)
          (.ite (.intEq (.readHeap engScrTbl (.lit 14)) (.lit 1))
            (.ite (.intEq (.readHeap engMetaTbl (.add (.readHeap engScrTbl (.lit 21)) (.lit 2))) (.lit 0))
              (copyLiveUpdateStmt cp)
              (buildLiveUpdateStmt ops))
            .skip)))))
    .skip

theorem zeroRand_jobSlotUpdateStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (jobSlotUpdateStage1Stmt ops) :=
  .ite
    (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_liveUpdateListStmt ops)
      (.ite (.ite (zeroRand_copyLiveUpdateStmt cp) (zeroRand_buildLiveUpdateStmt ops))
            .skip)))))
    .skip

def C_jobSlotUpdateStage1 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  C_liveList ops + max 380 (C_buildLive ops) + 120

lemma list_getElem_of_eq {α : Type*} {xs ys : List α} (h : xs = ys)
    (q : ℕ) (hq : q < xs.length) (hq' : q < ys.length) :
    xs[q]'hq = ys[q]'hq' := by
  subst h; rfl

private theorem stepStage1_jobs_eq {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp)
    (uop : InternalUpdate d) (ω₁ : Stage1Coins cp) (r : Fin cp.D_max)
    {isIns : Bool} {h_op : ℕ}
    (his_def : isIns = match uop with | .insert _ => true | .delete _ => false)
    (hhop_def : h_op = match uop with | .insert _ => (st.hp.step uop).2.getD 0 | .delete delH => delH) :
    (stepStage1 cp st uop ω₁).1.jobs r =
      match st.jobs r with
      | none => none
      | some jb =>
          if decide (r.val < st.serving.length) &&
              passesNodes (st.hp.step uop).1.coords h_op (st.serving.take r.val) then
            let readyBase := cp.D_max + r.val * cp.D_max
            let rRes := liveUpdateChainList cp (st.hp.step uop).1.coords isIns h_op
              (fun q => getS1Seed cp ω₁ (readyBase + q)) 0 jb.ready
            let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
            some { ready := rRes.1
                   phase := if rRes.2 then
                     match jb.phase with
                     | .copy cs => .copy (if isIns then cs.liveInsert h_op else cs.liveDelete h_op)
                     | .build bs => .build (if isIns then bs.liveInsert cp (st.hp.step uop).1.coords h_op (getS1Seed cp ω₁ curIdx)
                                            else bs.liveDelete cp (st.hp.step uop).1.coords h_op (getS1Seed cp ω₁ curIdx))
                   else jb.phase }
          else some jb := by
  subst his_def; subst hhop_def
  unfold stepStage1
  cases st.hp.step uop with
  | mk hp' rh =>
    cases uop <;> dsimp only <;> rcases st.jobs r with _ | ⟨ready, cs | bs⟩ <;> rfl

theorem exec_jobSlotUpdateStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    {actH : Finset ℕ} {P : DynamicPointSet d} {st : ChainEngineState cp}
    {uop : InternalUpdate d} {bits : Fin cp.B_STEP → Bool}
    (r : Fin cp.D_max) (rSlots : List ℕ) (cSlot : ℕ)
    {isIns : Bool} {h_op : ℕ}
    (hactH_eq : actH = P.activeHandles)
    (hwf_st : ChainEngineWF cp P st)
    (his_def : isIns = match uop with | .insert _ => true | .delete _ => false)
    (hhop_def : h_op = match uop with | .insert _ => (st.hp.step uop).2.getD 0 | .delete delH => delH)
    (hhop_lt : h_op < cp.n)
    (hact_lt : ∀ x ∈ actH, x < cp.n)
    (hslots_nd : (jobUsedSlots (st.jobs r) rSlots cSlot).Nodup)
    (hslots_lt : ∀ s ∈ jobUsedSlots (st.jobs r) rSlots cSlot, s < M_slots cp)
    (hins_case : isIns = true → h_op ∉ actH ∧ ∀ x ∈ actH, (st.hp.step uop).1.coords x = st.hp.coords x)
    (hdel_case : isIns = false → h_op ∈ actH ∧ (st.hp.step uop).1.coords = st.hp.coords)
    (hpts_mem : ∀ x ∈ insert h_op actH, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord ((st.hp.step uop).1.coords x) c)
    (hcoins : MemHasStepCoins cp bits m₀)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hj₀ : EncJobSlot ops r (st.jobs r) rSlots cSlot m₀)
    (hr1 : wRead m₀ engScrTbl 1 = (if isIns then 1 else 0))
    (hr2 : wRead m₀ engScrTbl 2 = (h_op : ℤ))
    (hr20 : wRead m₀ engScrTbl 20 = (r.val : ℤ))
    (hr21 : wRead m₀ engScrTbl 21 = jobMetaBase cp r.val)
    (hr22 : wRead m₀ engScrTbl 22 = (st.serving.length : ℤ))
    (hr23 : wRead m₀ engScrTbl 23 =
      (if passesNodes (st.hp.step uop).1.coords h_op (st.serving.take r.val) then 1 else 0)) :
    let ω₁ := (bitsToStepCoinBundle cp bits).1
    let jb1Opt := (stepStage1 cp st uop ω₁).1.jobs r
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (jobSlotUpdateStage1Stmt ops) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        EncJobSlot ops r jb1Opt rSlots cSlot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ∉ jobUsedSlots (st.jobs r) rSlots cSlot →
          ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ jobMetaBase cp r.val + 5 → i ≠ jobMetaBase cp r.val + 6 →
          wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, (i < (((2 + 4 * r.val) * S_stride cp : ℕ) : ℤ) ∨
               (((6 + 4 * r.val) * S_stride cp : ℕ) : ℤ) ≤ i) →
          wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, (i < 10 ∨ (20 ≤ i ∧ i < 30)) → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (C_jobSlotUpdateStage1 ops) := by
  have hTW := ops.hTW
  have hBW_s := ops_hBW_scr64 ops
  have hBW_m := ops.hBW_meta
  let pts := st.hp.coords
  let pts' := (st.hp.step uop).1.coords
  let ω₁ := (bitsToStepCoinBundle cp bits).1
  let isSomeJob : Bool := (st.jobs r).isSome
  have hw_active : wRead m₀ engMetaTbl (jobMetaBase cp r.val) = (if isSomeJob then 1 else 0) := by
    dsimp [isSomeJob]
    cases hj : st.jobs r
    · simp only [hj] at hj₀; exact hj₀.2
    · simp only [hj] at hj₀; exact hj₀.1
  let passPref := passesNodes pts' h_op (st.serving.take r.val)
  have hcond : (evalArithCond inp 0 m₀
      (.and (.intEq (.readHeap engMetaTbl (.readHeap engScrTbl (.lit 21))) (.lit 1))
            (.and (.intLt (.readHeap engScrTbl (.lit 20)) (.readHeap engScrTbl (.lit 22)))
                  (.intEq (.readHeap engScrTbl (.lit 23)) (.lit 1))))).1 =
      (isSomeJob && (decide (r.val < st.serving.length) && passPref)) := by
    simp only [evalArithCond, evalIntExpr]
    change (decide (wRead m₀ engMetaTbl (wRead m₀ engScrTbl 21) = 1) &&
            (decide (wRead m₀ engScrTbl 20 < wRead m₀ engScrTbl 22) &&
             decide (wRead m₀ engScrTbl 23 = 1))) = _
    rw [hr21, hw_active, hr20, hr22, hr23]
    congr 1
    · dsimp only [isSomeJob]; generalize (st.jobs r).isSome = b; cases b <;> rfl
    · congr 1
      · exact decide_eq_decide.mpr Int.ofNat_lt
      · dsimp only [passPref, pts']; generalize passesNodes (st.hp.step uop).1.coords h_op (st.serving.take r.val) = b; cases b <;> rfl
  unfold jobSlotUpdateStage1Stmt C_jobSlotUpdateStage1
  refine ExecDet.ite' (C_c := 24) (C_b := C_liveList ops + max 380 (C_buildLive ops) + 96)
    _ _ _ hcond (by simp [condExprOps, intExprOps]) (fun hgo => ?_) (fun hskip => ?_)
  · rcases Bool.and_eq_true_iff.mp hgo with ⟨hsome_t, hgo2⟩
    rcases Bool.and_eq_true_iff.mp hgo2 with ⟨hr_serv_b, hpass_t⟩
    have hr_serv : r.val < st.serving.length := of_decide_eq_true hr_serv_b
    cases hj_eq : st.jobs r with
    | none => simp [isSomeJob, hj_eq] at hsome_t
    | some jb =>
        simp only [hj_eq] at hj₀ hslots_nd hslots_lt
        rcases hj₀ with ⟨hact0, hrle, hrlen, hwlen, hready0, hph0⟩
        -- Extract SuffixJobInv from ChainEngineWF
        have hserv_cl : ChainListInv cp P.activeHandles pts st.gt P.activeHandles st.serving :=
          hwf_st.2.2.2.1
        have hjb_inv : SuffixJobInv cp P.activeHandles pts st.gt
            (foldResiduals pts P.activeHandles (st.serving.take r.val))
            (st.serving[r.val]'hr_serv) r.val jb := by
          have hslot := hwf_st.2.2.2.2.1 r
          simp only [hr_serv, ↓reduceDIte, hj_eq] at hslot
          exact hslot
        have hMr_gt : cp.B_scan < (st.serving[r.val]'hr_serv).nd.birthSize :=
          (chainListInv_mem_birthSize P.activeHandles st.serving hserv_cl _ (List.getElem_mem hr_serv)).1
        rcases suffixJobInvSlack_bounds (Nat.zero_le _) hMr_gt hjb_inv with
          ⟨hready_bds, _, _, hcur_age_bd⟩
        have hK_ge : 36 ≤ K_alpha d := K_alpha_ge_36 d
        have hready_age_le : ∀ mn ∈ jb.ready, mn.nd.age ≤ mn.nd.birthSize := by
          intro mn hm
          rcases List.mem_iff_getElem.mp hm with ⟨q, hq, rfl⟩
          have h128 := (hready_bds q hq).1
          have : (jb.ready[q]'hq).nd.age ≤ 128 * K_alpha d * (jb.ready[q]'hq).nd.age := by
            simpa using Nat.mul_le_mul_right (jb.ready[q]'hq).nd.age (by omega : 1 ≤ 128 * K_alpha d)
          omega
        let S_anc := foldResiduals pts P.activeHandles (st.serving.take r.val)
        have hS_anc_sub : S_anc ⊆ actH := by
          rw [hactH_eq]
          exact (chainListInv_getElem P.activeHandles st.serving (Finset.Subset.refl _) hserv_cl).2 r.val hr_serv |>.1
        have hcl_ready : ChainListInv cp actH pts st.gt S_anc jb.ready := by
          rw [hactH_eq]; exact hjb_inv.2.1
        have hdel_Sanc : isIns = false → h_op ∈ S_anc ∧ pts' = pts := by
          intro his_f
          rcases hdel_case his_f with ⟨hh_act, hpeq⟩
          have hpass_pts : passesNodes pts h_op (st.serving.take r.val) = true := by
            dsimp [pts]; rw [← hpeq]; exact hpass_t
          exact ⟨mem_foldResiduals_of_passesNodes P.activeHandles (st.serving.take r.val)
            hpass_pts (hactH_eq ▸ hh_act), hpeq⟩
        have hrSlots_nd : rSlots.Nodup := by
          dsimp [jobUsedSlots] at hslots_nd
          cases hph : jb.phase <;> simp only [hph] at hslots_nd
          · exact hslots_nd
          · exact (List.nodup_append.mp hslots_nd).1
        have hrSlots_lt : ∀ s ∈ rSlots, s < M_slots cp := by
          intro s hs; apply hslots_lt; dsimp [jobUsedSlots]
          cases jb.phase
          · exact hs
          · exact List.mem_append_left _ hs
        -- Set regs 11, 12, 13
        let readyOff0 := readySlotOff cp r.val 0
        let readyBase := cp.D_max + r.val * cp.D_max
        have hrD_ub : r.val * cp.D_max + jb.ready.length ≤ cp.D_max * cp.D_max :=
          calc r.val * cp.D_max + jb.ready.length
            _ ≤ r.val * cp.D_max + cp.D_max := Nat.add_le_add_left hrle _
            _ = (r.val + 1) * cp.D_max := by ring
            _ ≤ cp.D_max * cp.D_max := Nat.mul_le_mul_right _ r.isLt
        have hreadyBase_ub : readyBase + jb.ready.length ≤ cp.N_op_s1 := by
          dsimp [readyBase, ChainParams.N_op_s1]; omega
        have hreadyOff_ub : readyOff0 + (jb.ready.length : ℤ) ≤ (ops.BW : ℤ) := by
          dsimp [readyOff0, readySlotOff]
          have h1z : (r.val : ℤ) * (cp.D_max : ℤ) + (jb.ready.length : ℤ) ≤
              (cp.D_max : ℤ) * (cp.D_max : ℤ) := by exact_mod_cast hrD_ub
          omega
        refine ExecDet.seq' (C_liveList ops + max 380 (C_buildLive ops) + 78)
          (ExecDet.wWrite (C := 18) inp engScrTbl (.lit 11)
            (.add (.lit (16 + 9 * (cp.D_max : ℤ)))
                  (.mul (.readHeap engScrTbl (.lit 20)) (.lit (cp.D_max : ℤ))))
            11 readyOff0 hfp₀ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
            (by simp only [evalIntExpr]
                change (16 + 9 * (cp.D_max : ℤ)) + wRead m₀ engScrTbl 20 * (cp.D_max : ℤ) = _
                rw [hr20]; dsimp [readyOff0, readySlotOff]; ring)
            (by simp [intExprOps]) rfl) (by omega) ?_
        intro mA₁ hmA₁ hfpA₁; subst hmA₁
        refine ExecDet.seq' (C_liveList ops + max 380 (C_buildLive ops) + 60)
          (ExecDet.wWrite (C := 18) inp engScrTbl (.lit 12)
            (.readHeap engMetaTbl (.add (.readHeap engScrTbl (.lit 21)) (.lit 1)))
            12 (jb.ready.length : ℤ) hfpA₁ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
            (by simp only [evalIntExpr]
                change wRead _ engMetaTbl (wRead _ engScrTbl 21 + 1) = _
                rw [wRead_wWrite_of_ne m₀ _ (Or.inl (by decide)),
                    wRead_wWrite_of_ne m₀ _ (Or.inr (by decide)), hr21, hwlen])
            (by simp [intExprOps]) rfl) (by omega) ?_
        intro mA₂ hmA₂ hfpA₂; subst hmA₂
        refine ExecDet.seq' (C_liveList ops + max 380 (C_buildLive ops) + 42)
          (ExecDet.wWrite (C := 18) inp engScrTbl (.lit 13)
            (.add (.lit (cp.D_max : ℤ))
                  (.mul (.readHeap engScrTbl (.lit 20)) (.lit (cp.D_max : ℤ))))
            13 (readyBase : ℤ) hfpA₂ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
            (by simp only [evalIntExpr]
                change (cp.D_max : ℤ) + wRead _ engScrTbl 20 * (cp.D_max : ℤ) = _
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                    wRead_wWrite_of_ne m₀ _ (Or.inr (by decide)), hr20]
                dsimp [readyBase]; try (push_cast; try ring))
            (by simp [intExprOps]) rfl) (by omega) ?_
        intro mA₃ hmA₃ hfpA; subst hmA₃
        set mA := H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engScrTbl 11 readyOff0)
          engScrTbl 12 (jb.ready.length : ℤ)) engScrTbl 13 (readyBase : ℤ)
        have hwA_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead mA t i = wRead m₀ t i := by
          intro t ht i; simp only [mA]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
        have hwA_scr : ∀ i, (i < 10 ∨ 20 ≤ i) → wRead mA engScrTbl i = wRead m₀ engScrTbl i := by
          intro i hi; simp only [mA]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        have hrA : ∀ t i, rRead mA t i = rRead m₀ t i := fun _ _ => by simp [mA, rRead_wWrite]
        have hndA : ∀ mn' s', ops.EncNode mn' s' m₀ → ops.EncNode mn' s' mA :=
          fun mn' s' he => ops.encNode_ext mn' s' m₀ mA he
            (fun t ht9 _ i => hwA_ne8 t (by dsimp [engScrTbl]; omega) i)
            (fun _ _ _ _ => hrA _ _) (fun _ _ _ _ => hrA ptsRTbl _)
        refine ExecDet.seq' (max 380 (C_buildLive ops) + 42)
          (exec_liveUpdateListStmt ops inp hrle hrlen hrSlots_nd hrSlots_lt
            (by dsimp [readyOff0, readySlotOff]; have := Int.mul_nonneg (Int.natCast_nonneg r.val) (Int.natCast_nonneg cp.D_max); omega) hreadyOff_ub hreadyBase_ub
            hhop_lt hS_anc_sub hact_lt hready_age_le hcl_ready hins_case hdel_Sanc
            (fun x hx c => (hrA _ _).trans (hpts_mem x hx c))
            (fun j => (hwA_ne8 coinTbl (by decide) _).trans (hcoins j))
            hfpA
            (ops.slotsReady_ext m₀ mA hsr₀
              (fun t ht9 _ i => hwA_ne8 t (by dsimp [engScrTbl]; omega) i)
              (fun _ _ _ _ => hrA _ _))
            (fun q hq hqs => ⟨by
                have hoff_eq : readyOff0 + (q : ℤ) = readySlotOff cp r.val q := by
                  dsimp [readyOff0, readySlotOff]; ring
                rw [hoff_eq]
                exact (hwA_ne8 engMetaTbl (by decide) _).trans (hready0 q hq hqs).1,
              hndA _ _ (hready0 q hq hqs).2⟩)
            ((hwA_scr 1 (Or.inl (by omega))).trans hr1)
            ((hwA_scr 2 (Or.inl (by omega))).trans hr2)
            (by simp only [mA]
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
            (by simp only [mA]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
            (by simp [mA]))
          (by omega) ?_
        intro mB ⟨hsrB, hrlenB, hreadyB, hr14B, hndB_out, hwB_t, hwB_scr, hrB⟩ hfpB
        let rRes := liveUpdateChainList cp pts' isIns h_op
          (fun q => getS1Seed cp ω₁ (readyBase + q)) 0 jb.ready
        have hrRes_eq : rRes = liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) readyBase jb.ready := by
          dsimp [rRes]
          rw [liveUpdateChainList_shift_gen cp pts' isIns h_op (getS1Seed cp ω₁) readyBase 0 jb.ready,
              Nat.add_zero]
        have hjb1_eq : (stepStage1 cp st uop ω₁).1.jobs r =
            some { ready := rRes.1
                   phase := if rRes.2 then
                     match jb.phase with
                     | .copy cs => .copy (if isIns then cs.liveInsert h_op else cs.liveDelete h_op)
                     | .build bs =>
                         let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
                         .build (if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ω₁ curIdx)
                                 else bs.liveDelete cp pts' h_op (getS1Seed cp ω₁ curIdx))
                   else jb.phase } := by
          rw [stepStage1_jobs_eq cp st uop ω₁ r his_def hhop_def, hj_eq]
          dsimp only
          have hp_t : passesNodes (st.hp.step uop).1.coords h_op (st.serving.take r.val) = true := hpass_t
          rw [hr_serv_b, hp_t, Bool.true_and, if_pos rfl]
        have hcond_r2 : (evalArithCond inp 0 mB (.intEq (.readHeap engScrTbl (.lit 14)) (.lit 1))).1 = rRes.2 := by
          simp only [evalArithCond, evalIntExpr]
          change decide (wRead mB engScrTbl 14 = 1) = rRes.2
          rw [hr14B, ← hrRes_eq]; generalize rRes.2 = b; cases b <;> rfl
        have hw0B_t : ∀ t < 9, t ≠ engScrTbl → ∀ i, wRead mB t i = wRead m₀ t i :=
          fun t ht9 ht8 i => (hwB_t t ht9 ht8 i).trans (hwA_ne8 t ht8 i)
        have hw0B_scr : ∀ i, (i < 10 ∨ 20 ≤ i) → wRead mB engScrTbl i = wRead m₀ engScrTbl i :=
          fun i hi => (hwB_scr i hi).trans (hwA_scr i hi)
        have hr0B : ∀ t < 3, ∀ i, rRead mB t i = rRead m₀ t i :=
          fun t ht3 i => (hrB t ht3 i).trans (hrA t i)
        refine ExecDet.ite' (C_c := 8) (C_b := max 380 (C_buildLive ops) + 34)
          _ _ _ hcond_r2 (by simp [condExprOps, intExprOps]) (fun hr2_t => ?_) (fun hr2_f => ?_)
        · -- rRes.2 = true: branch on jb.phase (.copy vs .build)
          let isCopy : Bool := match jb.phase with | .copy _ => true | .build _ => false
          have hw_phB : wRead mB engMetaTbl (jobMetaBase cp r.val + 2) = (if isCopy then 0 else 1) := by
            rw [hw0B_t engMetaTbl (by decide) (by decide)]
            dsimp [isCopy]
            cases hjp : jb.phase
            · simp only [hjp] at hph0; exact hph0.1
            · simp only [hjp] at hph0; exact hph0.1
          have hcond_ph : (evalArithCond inp 0 mB
              (.intEq (.readHeap engMetaTbl (.add (.readHeap engScrTbl (.lit 21)) (.lit 2))) (.lit 0))).1 =
              isCopy := by
            simp only [evalArithCond, evalIntExpr]
            change decide (wRead mB engMetaTbl (wRead mB engScrTbl 21 + 2) = 0) = isCopy
            rw [(hw0B_scr 21 (Or.inr (by omega))).trans hr21, hw_phB]
            generalize (isCopy : Bool) = b; cases b <;> rfl
          refine ExecDet.ite' (C_c := 14) (C_b := max 380 (C_buildLive ops))
            _ _ _ hcond_ph (by simp [condExprOps, intExprOps]) (fun hcp_t => ?_) (fun hcp_f => ?_)
          · cases hjp : jb.phase with
            | build _ => simp [isCopy, hjp] at hcp_t
            | copy cs =>
                simp only [hjp] at hph0
                rcases hph0 with ⟨hp2, hp3, hp4, hsp0⟩
                have hspB : EncSparseSet cp.n (jobMetaBase cp r.val + 5) (snapElemOff cp r.val)
                    (snapPosOff cp r.val) cs.snapArr mB :=
                  hsp0.ext (hw0B_t engMetaTbl (by decide) (by decide) _)
                    (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _)
                    (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _)
                refine (exec_copyLiveUpdateStmt ops inp r cs hhop_lt hfpB hsrB hspB
                  ((hw0B_scr 1 (Or.inl (by omega))).trans hr1)
                  ((hw0B_scr 2 (Or.inl (by omega))).trans hr2)
                  ((hw0B_scr 20 (Or.inr (by omega))).trans hr20)
                  ((hw0B_scr 21 (Or.inr (by omega))).trans hr21)).mono ?_ (by omega)
                intro mC ⟨hsrC, hspC, hndBC, hwC_t, hwC_m, hwC_a, hwC_s, hrC⟩ _
                have hw0C_m : ∀ i, i ≠ jobMetaBase cp r.val + 5 → wRead mC engMetaTbl i = wRead m₀ engMetaTbl i :=
                  fun i hi => (hwC_m i hi).trans (hw0B_t engMetaTbl (by decide) (by decide) i)
                refine ⟨hsrC, ?_,
                  fun mn' s' hs' hns he0 => hndBC _ _ (hndB_out mn' s' hs'
                    (by dsimp [jobUsedSlots] at hns; rw [hjp] at hns; exact hns) (hndA mn' s' he0)),
                  fun t ht9 h6 h7 h8 i => (hwC_t t h6 h7 h8 i).trans (hw0B_t t ht9 h8 i),
                  fun i h5 _ => hw0C_m i h5,
                  fun i hi => (hwC_a i ?_).trans (hw0B_t engArrTbl (by decide) (by decide) i),
                  fun i hi => (hwC_s i (by omega)).trans (hw0B_scr i (by omega)),
                  fun t ht3 i => (hrC t i).trans (hr0B t ht3 i)⟩
                · rw [hjb1_eq, if_pos hr2_t]
                  simp only [hjp, EncJobSlot]
                  have hlen_eq : rRes.1.length = jb.ready.length := by
                    rw [hrRes_eq]; exact hrlenB
                  refine ⟨(hw0C_m _ (by omega)).trans hact0,
                    hlen_eq ▸ hrle, hrlen.trans hlen_eq.symm,
                    (hw0C_m _ (by omega)).trans (hlen_eq ▸ hwlen),
                    fun q hq hqs => ⟨(hw0C_m _ (by
                        unfold readySlotOff jobMetaBase
                        have := r.isLt
                        have := Int.mul_nonneg (Int.natCast_nonneg r.val) (Int.natCast_nonneg cp.D_max)
                        omega)).trans (hready0 q (hlen_eq ▸ hq) hqs).1,
                      by
                        have hq' : q < (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) readyBase jb.ready).1.length :=
                          hrRes_eq ▸ hq
                        have helem : rRes.1[q]'hq =
                            (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) readyBase jb.ready).1[q]'hq' := by
                          exact list_getElem_of_eq (congrArg Prod.fst hrRes_eq) q hq hq'
                        rw [helem]
                        exact hndBC _ _ (hreadyB q hq' hqs)⟩,
                    (hw0C_m _ (by omega)).trans hp2,
                    (hw0C_m _ (by omega)).trans (by cases isIns <;> exact hp3),
                    (hw0C_m _ (by omega)).trans (by cases isIns <;> exact hp4),
                    hspC⟩
                · rcases hi with hlt | hge
                  · left; exact hlt
                  · right
                    unfold snapPosOff
                    have : (3 + 4 * r.val) * S_stride cp + S_stride cp ≤ (6 + 4 * r.val) * S_stride cp :=
                      calc (3 + 4 * r.val) * S_stride cp + S_stride cp
                        _ = (4 + 4 * r.val) * S_stride cp := by ring
                        _ ≤ (6 + 4 * r.val) * S_stride cp := Nat.mul_le_mul_right _ (by omega)
                    have hz : (((3 + 4 * r.val) * S_stride cp : ℕ) : ℤ) + (S_stride cp : ℤ) ≤
                        (((6 + 4 * r.val) * S_stride cp : ℕ) : ℤ) := by exact_mod_cast this
                    omega
          · cases hjp : jb.phase with
            | copy _ => simp [isCopy, hjp] at hcp_f
            | build bs =>
                simp only [hjp] at hph0 hslots_nd hslots_lt
                rcases hph0 with ⟨hp2, hp3, hp4, hsp0, hdsp0, hcslot_rd0, hcenc0⟩
                have hcSlot_not_rSlots : cSlot ∉ rSlots := by
                  dsimp [jobUsedSlots] at hslots_nd; rw [hjp] at hslots_nd
                  exact fun hm => (List.nodup_append.mp hslots_nd).2.2 cSlot hm cSlot
                    (List.mem_singleton_self _) rfl
                have hcSlot_lt : cSlot < M_slots cp := by
                  apply hslots_lt; simp [jobUsedSlots, hjp]
                let T_end := foldResiduals pts S_anc jb.ready
                have hT_sub : T_end ⊆ actH := by
                  rw [hactH_eq]
                  exact (chainListInv_getElem S_anc jb.ready (hactH_eq ▸ hS_anc_sub)
                    (hactH_eq ▸ hcl_ready)).1
                have hbs_inv : BuildStateInv cp pts st.gt T_end bs := by
                  dsimp [SuffixJobInv, SuffixJobInvSlack] at hjb_inv
                  have hph_inv := hjb_inv.2.2.2.2
                  simp only [hjp] at hph_inv
                  exact hph_inv.2.2.2.2
                have hdel_Tend : isIns = false → h_op ∈ T_end ∧ pts' = pts := by
                  intro his_f
                  rcases hdel_Sanc his_f with ⟨hh_Sanc, hpeq⟩
                  have hpass_r : passesNodes pts h_op jb.ready = true := by
                    rw [← hpeq, ← liveUpdateChainList_snd_eq cp pts' isIns h_op (getS1Seed cp ω₁) readyBase jb.ready,
                        ← hrRes_eq]
                    exact hr2_t
                  exact ⟨mem_foldResiduals_of_passesNodes S_anc jb.ready hpass_r hh_Sanc, hpeq⟩
                have hdspB : EncSparseSet cp.n (jobMetaBase cp r.val + 6) (delSnapElemOff cp r.val)
                    (delSnapPosOff cp r.val) bs.delSnapArr mB :=
                  hdsp0.ext (hw0B_t engMetaTbl (by decide) (by decide) _)
                    (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _)
                    (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _)
                refine (exec_buildLiveUpdateStmt ops inp r bs cSlot hcSlot_lt hhop_lt hT_sub hact_lt
                  (hcur_age_bd bs hjp) hbs_inv hins_case hdel_Tend
                  (fun x hx c => (hr0B ptsRTbl (by decide) _).trans (hpts_mem x hx c))
                  (fun j => (hw0B_t coinTbl (by decide) (by decide) _).trans (hcoins j))
                  hfpB hsrB hdspB
                  ((hw0B_t engMetaTbl (by decide) (by decide) _).trans hcslot_rd0)
                  (hndB_out _ _ hcSlot_lt hcSlot_not_rSlots (hndA _ _ hcenc0))
                  ((hw0B_scr 1 (Or.inl (by omega))).trans hr1)
                  ((hw0B_scr 2 (Or.inl (by omega))).trans hr2)
                  ((hw0B_scr 20 (Or.inr (by omega))).trans hr20)
                  ((hw0B_scr 21 (Or.inr (by omega))).trans hr21)).mono ?_ (by omega)
                intro mC ⟨hsrC, hdspC, hcencC, hndBC_ne, hwC_t, hwC_m, hwC_a, hwC_s, hrC⟩ _
                have hw0C_m : ∀ i, i ≠ jobMetaBase cp r.val + 6 → wRead mC engMetaTbl i = wRead m₀ engMetaTbl i :=
                  fun i hi => (hwC_m i hi).trans (hw0B_t engMetaTbl (by decide) (by decide) i)
                have hsp_len : bs.snapArr.length ≤ cp.n := hsp0.length_le
                have hS_gt : cp.n < S_stride cp := by unfold S_stride; omega
                refine ⟨hsrC, ?_,
                  fun mn' s' hs' hns he0 => by
                    dsimp [jobUsedSlots] at hns; rw [hjp] at hns
                    have hns_r : s' ∉ rSlots := fun hm => hns (List.mem_append_left _ hm)
                    have hne_c : s' ≠ cSlot := fun heq => hns (List.mem_append_right _ (by simp [heq]))
                    exact hndBC_ne mn' s' hs' hne_c (hndB_out mn' s' hs' hns_r (hndA mn' s' he0)),
                  fun t ht9 h6 h7 h8 i => (hwC_t t ht9 h6 h7 h8 i).trans (hw0B_t t ht9 h8 i),
                  fun i _ h6 => hw0C_m i h6,
                  fun i hi => (hwC_a i ?_).trans (hw0B_t engArrTbl (by decide) (by decide) i),
                  fun i hi => (hwC_s i (by omega)).trans (hw0B_scr i (by omega)),
                  fun t ht3 i => (hrC t ht3 i).trans (hr0B t ht3 i)⟩
                · rw [hjb1_eq, if_pos hr2_t]
                  simp only [hjp, EncJobSlot]
                  have hlen_eq : rRes.1.length = jb.ready.length := by
                    rw [hrRes_eq]; exact hrlenB
                  have hbs1_fields :
                      (let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
                       if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ω₁ curIdx)
                       else bs.liveDelete cp pts' h_op (getS1Seed cp ω₁ curIdx)).L_hist = bs.L_hist ∧
                      (let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
                       if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ω₁ curIdx)
                       else bs.liveDelete cp pts' h_op (getS1Seed cp ω₁ curIdx)).insCur = bs.insCur ∧
                      (let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
                       if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ω₁ curIdx)
                       else bs.liveDelete cp pts' h_op (getS1Seed cp ω₁ curIdx)).snapArr = bs.snapArr := by
                    dsimp only
                    cases isIns
                    · simp only [Bool.false_eq_true, ↓reduceIte, BuildState.liveDelete]
                      split_ifs <;> exact ⟨rfl, rfl, rfl⟩
                    · exact ⟨rfl, rfl, rfl⟩
                  refine ⟨(hw0C_m _ (by omega)).trans hact0,
                    hlen_eq ▸ hrle, hrlen.trans hlen_eq.symm,
                    (hw0C_m _ (by omega)).trans (hlen_eq ▸ hwlen),
                    fun q hq hqs => ⟨(hw0C_m _ (by
                        unfold readySlotOff jobMetaBase
                        have := r.isLt
                        have := Int.mul_nonneg (Int.natCast_nonneg r.val) (Int.natCast_nonneg cp.D_max)
                        omega)).trans (hready0 q (hlen_eq ▸ hq) hqs).1,
                      by
                        have hq' : q < (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) readyBase jb.ready).1.length :=
                          hrRes_eq ▸ hq
                        have helem : rRes.1[q]'hq =
                            (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) readyBase jb.ready).1[q]'hq' := by
                          exact list_getElem_of_eq (congrArg Prod.fst hrRes_eq) q hq hq'
                        have hne_qc : rSlots[q]'hqs ≠ cSlot := fun heq =>
                          hcSlot_not_rSlots (heq ▸ List.getElem_mem hqs)
                        rw [helem]
                        exact hndBC_ne _ _ (hrSlots_lt _ (List.getElem_mem hqs)) hne_qc (hreadyB q hq' hqs)⟩,
                    (hw0C_m _ (by omega)).trans hp2,
                    by rw [hbs1_fields.1]; exact (hw0C_m _ (by omega)).trans hp3,
                    by rw [hbs1_fields.2.1]; exact (hw0C_m _ (by omega)).trans hp4,
                    by rw [hbs1_fields.2.2]
                       exact hsp0.ext (hw0C_m _ (by omega))
                         (fun k hk => (hwC_a _ (Or.inl (by
                           unfold snapElemOff delSnapElemOff
                           have hsp0_len : bs.snapArr.length ≤ cp.n := hsp0.length_le
                           have hS_gt : cp.n < S_stride cp := by unfold S_stride; omega
                           have : (2 + 4 * r.val) * S_stride cp + k < (4 + 4 * r.val) * S_stride cp :=
                             calc (2 + 4 * r.val) * S_stride cp + k
                               _ < (2 + 4 * r.val) * S_stride cp + S_stride cp := by omega
                               _ = (3 + 4 * r.val) * S_stride cp := by ring
                               _ ≤ (4 + 4 * r.val) * S_stride cp := Nat.mul_le_mul_right _ (by omega)
                           exact_mod_cast this))).trans (hw0B_t engArrTbl (by decide) (by decide) _))
                         (fun y hy => (hwC_a _ (Or.inl (by
                           unfold snapPosOff delSnapElemOff
                           have hy_lt : y < cp.n := hsp0.2.1 y hy
                           have hS_gt : cp.n < S_stride cp := by unfold S_stride; omega
                           have : (3 + 4 * r.val) * S_stride cp + y < (4 + 4 * r.val) * S_stride cp :=
                             calc (3 + 4 * r.val) * S_stride cp + y
                               _ < (3 + 4 * r.val) * S_stride cp + S_stride cp := by omega
                               _ = (4 + 4 * r.val) * S_stride cp := by ring
                           exact_mod_cast this))).trans (hw0B_t engArrTbl (by decide) (by decide) _)),
                    hdspC,
                    (hw0C_m _ (by omega)).trans hcslot_rd0,
                    hcencC⟩
                · rcases hi with hlt | hge
                  · left
                    unfold delSnapElemOff
                    have : (2 + 4 * r.val) * S_stride cp ≤ (4 + 4 * r.val) * S_stride cp := Nat.mul_le_mul_right _ (by omega)
                    have hz : (((2 + 4 * r.val) * S_stride cp : ℕ) : ℤ) ≤
                        (((4 + 4 * r.val) * S_stride cp : ℕ) : ℤ) := by exact_mod_cast this
                    omega
                  · right
                    unfold delSnapPosOff
                    have : (5 + 4 * r.val) * S_stride cp + S_stride cp = (6 + 4 * r.val) * S_stride cp := by ring
                    have hz : (((5 + 4 * r.val) * S_stride cp : ℕ) : ℤ) + (S_stride cp : ℤ) =
                        (((6 + 4 * r.val) * S_stride cp : ℕ) : ℤ) := by exact_mod_cast this
                    omega
        · -- rRes.2 = false: phase unchanged, only ready updated
          refine ExecDet.skip inp hfpB ?_ (by omega)
          have hlen_eq : rRes.1.length = jb.ready.length := by rw [hrRes_eq]; exact hrlenB
          refine ⟨hsrB, ?_,
            fun mn' s' hs' hns he0 => hndB_out mn' s' hs'
              (by dsimp [jobUsedSlots] at hns
                  cases hph : jb.phase <;> simp only [hph] at hns
                  · exact hns
                  · exact fun hm => hns (List.mem_append_left _ hm))
              (hndA mn' s' he0),
            fun t ht9 _ _ ht8 i => hw0B_t t ht9 ht8 i,
            fun i _ _ => hw0B_t engMetaTbl (by decide) (by decide) i,
            fun i _ => hw0B_t engArrTbl (by decide) (by decide) i,
            fun i hi => hw0B_scr i (by omega),
            hr0B⟩
          rw [hjb1_eq, if_neg (by simp [hr2_f])]
          simp only [EncJobSlot]
          refine ⟨(hw0B_t engMetaTbl (by decide) (by decide) _).trans hact0,
            hlen_eq ▸ hrle, hrlen.trans hlen_eq.symm,
            (hw0B_t engMetaTbl (by decide) (by decide) _).trans (hlen_eq ▸ hwlen),
            fun q hq hqs => ⟨(hw0B_t engMetaTbl (by decide) (by decide) _).trans
                (hready0 q (hlen_eq ▸ hq) hqs).1,
              by
                have hq' : q < (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) readyBase jb.ready).1.length :=
                  hrRes_eq ▸ hq
                have helem : rRes.1[q]'hq =
                    (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) readyBase jb.ready).1[q]'hq' := by
                  exact list_getElem_of_eq (congrArg Prod.fst hrRes_eq) q hq hq'
                rw [helem]; exact hreadyB q hq' hqs⟩, ?_⟩
          cases hjp : jb.phase with
          | copy cs =>
              simp only [hjp] at hph0
              rcases hph0 with ⟨hp2, hp3, hp4, hsp0⟩
              exact ⟨(hw0B_t engMetaTbl (by decide) (by decide) _).trans hp2,
                (hw0B_t engMetaTbl (by decide) (by decide) _).trans hp3,
                (hw0B_t engMetaTbl (by decide) (by decide) _).trans hp4,
                hsp0.ext (hw0B_t engMetaTbl (by decide) (by decide) _)
                  (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _)
                  (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _)⟩
          | build bs =>
              simp only [hjp] at hph0 hslots_nd hslots_lt
              rcases hph0 with ⟨hp2, hp3, hp4, hsp0, hdsp0, hcslot0, hcenc0⟩
              have hcSlot_not_rSlots : cSlot ∉ rSlots := by
                dsimp [jobUsedSlots] at hslots_nd; rw [hjp] at hslots_nd
                exact fun hm => (List.nodup_append.mp hslots_nd).2.2 cSlot hm cSlot
                  (List.mem_singleton_self _) rfl
              have hcSlot_lt : cSlot < M_slots cp := by apply hslots_lt; simp [jobUsedSlots, hjp]
              exact ⟨(hw0B_t engMetaTbl (by decide) (by decide) _).trans hp2,
                (hw0B_t engMetaTbl (by decide) (by decide) _).trans hp3,
                (hw0B_t engMetaTbl (by decide) (by decide) _).trans hp4,
                hsp0.ext (hw0B_t engMetaTbl (by decide) (by decide) _)
                  (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _)
                  (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _),
                hdsp0.ext (hw0B_t engMetaTbl (by decide) (by decide) _)
                  (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _)
                  (fun _ _ => hw0B_t engArrTbl (by decide) (by decide) _),
                (hw0B_t engMetaTbl (by decide) (by decide) _).trans hcslot0,
                hndB_out _ _ hcSlot_lt hcSlot_not_rSlots (hndA _ _ hcenc0)⟩
  · -- Skip branch: either st.jobs r = none, or r.val ≥ st.serving.length, or passPref = false
    refine ExecDet.skip inp hfp₀ ?_ (by omega)
    have hjb1_same : (stepStage1 cp st uop ω₁).1.jobs r = st.jobs r := by
      rw [stepStage1_jobs_eq cp st uop ω₁ r his_def hhop_def]
      cases hj : st.jobs r with
      | none => rfl
      | some jb =>
          dsimp only
          have hsome_t : isSomeJob = true := by simp [isSomeJob, hj]
          simp only [hsome_t, Bool.true_and] at hskip
          have hcond_f : (decide (r.val < st.serving.length) &&
              passesNodes (st.hp.step uop).1.coords h_op (st.serving.take r.val)) = false := hskip
          rw [hcond_f]
          rfl
    exact ⟨hsr₀, (by (try dsimp only); rw [hjb1_same]; exact hj₀),
      fun _ _ _ _ h => h, fun _ _ _ _ _ _ => rfl, fun _ _ _ => rfl, fun _ _ => rfl,
      fun _ _ => rfl, fun _ _ _ => rfl⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG19
