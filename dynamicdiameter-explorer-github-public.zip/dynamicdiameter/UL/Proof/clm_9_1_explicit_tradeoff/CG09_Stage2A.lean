import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2A1
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 4. Copy-to-Leaf-SparseSet Primitives (`copySnapToLeafStmt`, `copyNodeResToLeafStmt`) -/

def copySnapToLeafStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .seq (.writeWordHeap engMetaTbl (.lit 2) (.lit 0))
  (.seq (.writeWordHeap engScrTbl (.lit 20) (.lit 2))
  (.seq (.writeWordHeap engScrTbl (.lit 21) (.lit leafElemOff))
  (.seq (.writeWordHeap engScrTbl (.lit 22) (.lit (leafPosOff cp)))
  (.seq (.writeWordHeap engScrTbl (.lit 30) (.readHeap engMetaTbl (.lit (base + 5))))
        (dynForLoopStmt 27 30
          (.seq (.writeWordHeap engScrTbl (.lit 23)
                  (.readHeap engArrTbl
                    (.add (.lit (snapElemOff cp r.val)) (.readHeap engScrTbl (.lit 27)))))
                (sparseInsertFreshStmt 20 21 22 23)))))))

theorem zeroRand_copySnapToLeafStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) :
    ZeroRandStmt (copySnapToLeafStmt cp r) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (zeroRand_dynForLoopStmt 27 30
      (.seq (.writeWordHeap _ _ _) (zeroRand_sparseInsertFreshStmt 20 21 22 23)))))))

theorem exec_copySnapToLeafStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {m₀ : ArithRAMMemory} {snapArr : List ℕ}
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hsnap_enc : EncSparseSet cp.n (jobMetaBase cp r.val + 5)
      (snapElemOff cp r.val) (snapPosOff cp r.val) snapArr m₀)
    (hlen_B : snapArr.length ≤ cp.B_scan) :
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (copySnapToLeafStmt cp r) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) snapArr m₁ ∧
        (∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁) ∧
        (∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 2 → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, 2 * (S_stride cp : ℤ) ≤ i → wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, i < 20 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      (80 + cp.B_scan * 130) := by
  have hTW := ops.hTW; have hBW_meta := ops.hBW_meta
  have hBW_arr := ops.hBW_arr; have hBW_scr := ops.hBW_scr
  have hS_gt : cp.n < S_stride cp := by unfold S_stride; omega
  have hsnap_ge : 2 * (S_stride cp : ℤ) ≤ snapElemOff cp r.val := by
    unfold snapElemOff; push_cast; nlinarith
  have hbase5_ne2 : jobMetaBase cp r.val + 5 ≠ 2 := by unfold jobMetaBase; omega
  let FrameLeaf (m : ArithRAMMemory) : Prop :=
    (∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ i, i ≠ 2 → wRead m engMetaTbl i = wRead m₀ engMetaTbl i) ∧
    (∀ i, 2 * (S_stride cp : ℤ) ≤ i → wRead m engArrTbl i = wRead m₀ engArrTbl i) ∧
    (∀ i, i < 20 → wRead m engScrTbl i = wRead m₀ engScrTbl i) ∧
    (∀ t i, rRead m t i = rRead m₀ t i)
  unfold copySnapToLeafStmt
  -- 5 setup writes
  refine ExecDet.seq' (68 + cp.B_scan * 130)
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 2) (.lit 0) 2 0
      hfp₀ (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m1 hm1 hfp1; subst hm1
  refine ExecDet.seq' (56 + cp.B_scan * 130)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 20) (.lit 2) 20 2
      hfp1 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) rfl) (by nlinarith) ?_
  intro m2 hm2 hfp2; subst hm2
  refine ExecDet.seq' (44 + cp.B_scan * 130)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 21) (.lit leafElemOff) 21 leafElemOff
      hfp2 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) rfl) (by nlinarith) ?_
  intro m3 hm3 hfp3; subst hm3
  refine ExecDet.seq' (32 + cp.B_scan * 130)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 22) (.lit (leafPosOff cp)) 22 (leafPosOff cp)
      hfp3 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) rfl) (by nlinarith) ?_
  intro m4 hm4 hfp4; subst hm4
  have hr_len : wRead (H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engMetaTbl 2 0)
      engScrTbl 20 2) engScrTbl 21 leafElemOff) engScrTbl 22 (leafPosOff cp))
      engMetaTbl (jobMetaBase cp r.val + 5) = (snapArr.length : ℤ) := by
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
    rw [wRead_wWrite_of_ne _ _ (Or.inr hbase5_ne2)]
    exact hsnap_enc.2.2.1
  refine ExecDet.seq' (20 + cp.B_scan * 130)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 30)
      (.readHeap engMetaTbl (.lit (jobMetaBase cp r.val + 5))) 30 (snapArr.length : ℤ)
      hfp4 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
      (by simp only [evalIntExpr]; exact hr_len) (by simp [intExprOps]) rfl) (by omega) ?_
  intro m5 hm5 hfp5; subst hm5
  set m5_st := H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engMetaTbl 2 0)
    engScrTbl 20 2) engScrTbl 21 leafElemOff) engScrTbl 22 (leafPosOff cp))
    engScrTbl 30 (snapArr.length : ℤ)
  let Inv (k : ℕ) (m : ArithRAMMemory) : Prop :=
    FrameLeaf m ∧
    wRead m engScrTbl 20 = 2 ∧
    wRead m engScrTbl 21 = leafElemOff ∧
    wRead m engScrTbl 22 = leafPosOff cp ∧
    EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) (snapArr.take k) m
  have hInv0 : Inv 0 (H3a.wWrite m5_st engScrTbl 27 0) := by
    refine ⟨⟨fun t ht1 ht2 ht3 i => ?_, fun i hi2 => ?_, fun i hi_arr => ?_,
             fun i hi20 => ?_, fun t i => ?_⟩, ?_, ?_, ?_, ?_⟩
    · simp only [m5_st, wRead_wWrite_eq]; simp [ht1, ht3]
    · simp only [m5_st, wRead_wWrite_eq]; simp [engScrTbl, engMetaTbl, hi2]
    · simp only [m5_st, wRead_wWrite_eq]; simp [engScrTbl, engMetaTbl, engArrTbl]
    · simp only [m5_st, wRead_wWrite_eq]
      have : i ≠ 27 ∧ i ≠ 30 ∧ i ≠ 22 ∧ i ≠ 21 ∧ i ≠ 20 := by omega
      simp [engScrTbl, engMetaTbl, this]
    · simp [m5_st, rRead_wWrite]
    · simp [m5_st, wRead_wWrite_eq]
    · simp [m5_st, wRead_wWrite_eq]
    · simp [m5_st, wRead_wWrite_eq]
    · apply encSparseSet_empty_of_zero
      simp [m5_st, wRead_wWrite_eq, engScrTbl, engMetaTbl]
  refine (ExecDet.dynForLoop (N := snapArr.length) (N_max := cp.B_scan) (C_b := 112)
    27 30 _ Inv hfp5 (by omega) (by omega) (by unfold M_slots at hBW_scr; omega)
    (by decide) (wRead_wWrite_self _ _ _ _) hlen_B hInv0 ?_).mono
    (fun m ⟨⟨hft, hfm, hfa, hfs, hfr⟩, _, _, _, henc⟩ _ => ?_) (by omega)
  · intro k hk m ⟨hFL, hr20, hr21, hr22, henc_k⟩ hctr hfp
    let x := snapArr[k]'hk
    have hx_n : x < cp.n := hsnap_enc.2.1 x (List.getElem_mem hk)
    obtain ⟨hx_not, hdi_eq⟩ := denseInsert_take_succ hsnap_enc.1 hk
    have hread_x : wRead m engArrTbl (snapElemOff cp r.val + (k : ℤ)) = (x : ℤ) :=
      (hFL.2.2.1 _ (by omega)).trans (hsnap_enc.2.2.2 k hk).1
    refine ExecDet.seq' 100
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 23)
        (.readHeap engArrTbl (.add (.lit (snapElemOff cp r.val)) (.readHeap engScrTbl (.lit 27))))
        23 (x : ℤ) hfp (by unfold engScrTbl; omega) (by omega)
        (by unfold M_slots at hBW_scr; omega) rfl
        (by simp only [evalIntExpr]; change wRead m engArrTbl (snapElemOff cp r.val + wRead m engScrTbl 27) = _
            rw [hctr, hread_x])
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro mX hmX hfpX; subst hmX
    have henc_k' : EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) (snapArr.take k)
        (H3a.wWrite m engScrTbl 23 (x : ℤ)) :=
      henc_k.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
    have hD_pos := cp.D_max_pos
    refine (exec_sparseInsertFreshStmt inp 20 21 22 23
      (by omega) (by unfold M_slots at hBW_scr; omega)
      (by decide) (by decide) (by decide) (by decide)
      (by omega) (by omega)
      (by unfold leafElemOff; omega)
      (by have h2S : 2 * S_stride cp ≤ ops.BW := by nlinarith [ops.hBW_arr]
          unfold leafElemOff S_stride at *; omega)
      (by unfold leafPosOff; omega)
      (by have h2S : 2 * S_stride cp ≤ ops.BW := by nlinarith [ops.hBW_arr]
          unfold leafPosOff S_stride at *; omega)
      (Or.inl (by unfold leafElemOff leafPosOff S_stride; omega))
      hx_n hx_not hfpX henc_k'
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hr20)
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hr21)
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hr22)
      (wRead_wWrite_self _ _ _ _)).mono ?_ le_rfl
    intro mI ⟨henc_next, hftI, hfmI, hfaI, hfsI, hfrI⟩ _
    rw [hdi_eq] at henc_next
    refine ⟨(hfsI 27 (by omega)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hctr),
      ⟨⟨fun t ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans
          ((hftI t ht1 ht2 ht3 i).trans ((wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans (hFL.1 t ht1 ht2 ht3 i))),
        fun i hi2 => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfmI i hi2).trans ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hFL.2.1 i hi2))),
        fun i hi_arr => ?_,
        fun i hi20 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans
          ((hfsI i (by omega)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hFL.2.2.2.1 i hi20))),
        fun t i => (rRead_wWrite _ _ _ _ _ _).trans ((hfrI t i).trans
          ((rRead_wWrite _ _ _ _ _ _).trans (hFL.2.2.2.2 t i)))⟩,
       (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
         ((hfsI 20 (by omega)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr20)),
       (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
         ((hfsI 21 (by omega)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr21)),
       (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
         ((hfsI 22 (by omega)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr22)),
       henc_next.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
         (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
         (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))⟩⟩
    have hlen_tk : (snapArr.take k).length ≤ cp.n := by
      rw [List.length_take]; exact (Nat.min_le_right _ _).trans (hsnap_enc.length_le)
    have hne_e : i ≠ leafElemOff + ((snapArr.take k).length : ℤ) := by
      unfold leafElemOff; omega
    have hne_p : i ≠ leafPosOff cp + (x : ℤ) := by
      unfold leafPosOff; omega
    exact (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
      ((hfaI i hne_e hne_p).trans ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hFL.2.2.1 i hi_arr)))
  · rw [List.take_length] at henc
    have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m t i = wRead m₀ t i :=
      fun t ht9 _ i => hft t (by unfold engMetaTbl; omega) (by unfold engArrTbl; omega) (by unfold engScrTbl; omega) i
    exact ⟨ops.slotsReady_ext m₀ m hsr₀ hw9 (fun t _ _ i => hfr t i),
      henc,
      fun mn s _ he => ops.encNode_ext mn s m₀ m he hw9 (fun t _ _ i => hfr t i) (fun _ _ _ _ => hfr ptsRTbl _),
      hft, hfm, hfa, hfs, hfr⟩

def copyNodeResToLeafStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (cSlotR : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap engMetaTbl (.lit 2) (.lit 0))
  (.seq (.writeWordHeap engScrTbl (.lit 20) (.lit 2))
  (.seq (.writeWordHeap engScrTbl (.lit 21) (.lit leafElemOff))
  (.seq (.writeWordHeap engScrTbl (.lit 22) (.lit (leafPosOff cp)))
  (.seq (ops.readNodeScalarStmt .resLen cSlotR 30)
        (dynForLoopStmt 27 30
          (.seq (ops.readNodeArrElemStmt .res cSlotR 27 23)
                (sparseInsertFreshStmt 20 21 22 23)))))))

theorem zeroRand_copyNodeResToLeafStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (cSlotR : ℤ) :
    ZeroRandStmt (copyNodeResToLeafStmt ops cSlotR) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (ops.zeroRand_readNodeScalar .resLen cSlotR 30)
    (zeroRand_dynForLoopStmt 27 30
      (.seq (ops.zeroRand_readNodeArrElem .res cSlotR 27 23)
            (zeroRand_sparseInsertFreshStmt 20 21 22 23)))))))

theorem exec_copyNodeResToLeafStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (cSlotR : ℤ)
    {m₀ : ArithRAMMemory} {mn : MNode cp} {cSlot : ℕ}
    (hcR0 : 0 ≤ cSlotR) (hcR20 : cSlotR < 20)
    (hcSlot : cSlot < M_slots cp)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (henc_mn : ops.EncNode mn cSlot m₀)
    (hread_cR : wRead m₀ engScrTbl cSlotR = (cSlot : ℤ))
    (hnd_res : mn.resArr.Nodup)
    (hres_n : ∀ x ∈ mn.resArr, x < cp.n)
    (hlen_B : mn.resArr.length ≤ cp.B_scan) :
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (copyNodeResToLeafStmt ops cSlotR) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) mn.resArr m₁ ∧
        (∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m₁) ∧
        (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 2 → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, 2 * (S_stride cp : ℤ) ≤ i → wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, i < 20 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (80 + ops.C_read + cp.B_scan * (ops.C_read + 120)) := by
  have hTW := ops.hTW; have hBW_meta := ops.hBW_meta
  have hBW_arr := ops.hBW_arr; have hBW_scr := ops.hBW_scr
  have hS_gt : cp.n < S_stride cp := by unfold S_stride; omega
  let FrameRes (m : ArithRAMMemory) : Prop :=
    ops.SlotsReady m ∧
    (∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m) ∧
    (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ i, i ≠ 2 → wRead m engMetaTbl i = wRead m₀ engMetaTbl i) ∧
    (∀ i, 2 * (S_stride cp : ℤ) ≤ i → wRead m engArrTbl i = wRead m₀ engArrTbl i) ∧
    (∀ i, i < 20 → wRead m engScrTbl i = wRead m₀ engScrTbl i) ∧
    (∀ t < 3, ∀ i, rRead m t i = rRead m₀ t i)
  unfold copyNodeResToLeafStmt
  refine ExecDet.seq' (68 + ops.C_read + cp.B_scan * (ops.C_read + 120))
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 2) (.lit 0) 2 0
      hfp₀ (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m1 hm1 hfp1; subst hm1
  refine ExecDet.seq' (56 + ops.C_read + cp.B_scan * (ops.C_read + 120))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 20) (.lit 2) 20 2
      hfp1 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) rfl) (by nlinarith) ?_
  intro m2 hm2 hfp2; subst hm2
  refine ExecDet.seq' (44 + ops.C_read + cp.B_scan * (ops.C_read + 120))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 21) (.lit leafElemOff) 21 leafElemOff
      hfp2 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) rfl) (by nlinarith) ?_
  intro m3 hm3 hfp3; subst hm3
  refine ExecDet.seq' (32 + ops.C_read + cp.B_scan * (ops.C_read + 120))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 22) (.lit (leafPosOff cp)) 22 (leafPosOff cp)
      hfp3 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) rfl) (by nlinarith) ?_
  intro m4 hm4 hfp4; subst hm4
  set m4_st := H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engMetaTbl 2 0)
    engScrTbl 20 2) engScrTbl 21 leafElemOff) engScrTbl 22 (leafPosOff cp)
  have hw9_m4 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m4_st t i = wRead m₀ t i := by
    intro t ht9 _ i; dsimp [m4_st]
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))]
    exact wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))
  have hr_m4 : ∀ t i, rRead m4_st t i = rRead m₀ t i := by
    intro t i; simp [m4_st, rRead_wWrite]
  have hsr_m4 : ops.SlotsReady m4_st :=
    ops.slotsReady_ext m₀ m4_st hsr₀ hw9_m4 (fun t _ _ i => hr_m4 t i)
  have henc_m4 : ops.EncNode mn cSlot m4_st :=
    ops.encNode_ext mn cSlot m₀ m4_st henc_mn hw9_m4 (fun t _ _ i => hr_m4 t i) (fun _ _ _ _ => hr_m4 ptsRTbl _)
  have hcR_m4 : wRead m4_st engScrTbl cSlotR = (cSlot : ℤ) := by
    dsimp [m4_st]
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
    exact hread_cR
  refine ExecDet.seq' (32 + cp.B_scan * (ops.C_read + 120))
    (ops.readNodeScalar_spec inp m4_st mn cSlot .resLen cSlotR 30
      hcSlot hcR0 (by omega) (by omega) (by omega) hfp4 hsr_m4 henc_m4 hcR_m4) (by nlinarith) ?_
  intro m5 ⟨hsr5, hr30, hnd5, hft5, hfs5, hfr5⟩ hfp5
  dsimp [evalNodeScalar] at hr30
  let Inv (k : ℕ) (m : ArithRAMMemory) : Prop :=
    FrameRes m ∧
    wRead m engScrTbl 20 = 2 ∧
    wRead m engScrTbl 21 = leafElemOff ∧
    wRead m engScrTbl 22 = leafPosOff cp ∧
    EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) (mn.resArr.take k) m
  have hInv0 : Inv 0 (H3a.wWrite m5 engScrTbl 27 0) := by
    have hw9_27 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead (H3a.wWrite m5 engScrTbl 27 0) t i = wRead m5 t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    refine ⟨⟨ops.slotsReady_ext m5 _ hsr5 hw9_27 (fun t _ _ i => rRead_wWrite _ _ _ _ _ _),
      fun mn' s hs he0 => ops.encNode_ext mn' s m5 _
        (hnd5 mn' s hs (ops.encNode_ext mn' s m₀ m4_st he0 hw9_m4 (fun t _ _ i => hr_m4 t i) (fun _ _ _ _ => hr_m4 ptsRTbl _)))
        hw9_27 (fun t _ _ i => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun t ht9 ht1 ht2 ht3 i => by
        rw [wRead_wWrite_of_ne _ _ (Or.inl ht3), hft5 t ht9 ht3 i]
        simp only [m4_st, wRead_wWrite_eq]; simp [ht1, ht3],
      fun i hi2 => by
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hft5 engMetaTbl (by decide) (by decide) i]
        simp only [m4_st, wRead_wWrite_eq]; simp [engScrTbl, engMetaTbl, hi2],
      fun i _ => by
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hft5 engArrTbl (by decide) (by decide) i]
        simp only [m4_st, wRead_wWrite_eq]; simp [engScrTbl, engMetaTbl, engArrTbl],
      fun i hi20 => by
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hfs5 i (by omega)]
        simp only [m4_st, wRead_wWrite_eq]
        have : i ≠ 22 ∧ i ≠ 21 ∧ i ≠ 20 := by omega
        simp [engScrTbl, engMetaTbl, this],
      fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans ((hfr5 t ht3 i).trans (hr_m4 t i))⟩,
      by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hfs5 20 (by decide)]
         simp [m4_st, wRead_wWrite_eq],
      by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hfs5 21 (by decide)]
         simp [m4_st, wRead_wWrite_eq],
      by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hfs5 22 (by decide)]
         simp [m4_st, wRead_wWrite_eq],
      encSparseSet_empty_of_zero (by
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hft5 engMetaTbl (by decide) (by decide) 2]
        simp [m4_st, wRead_wWrite_eq, engScrTbl, engMetaTbl])⟩
  refine (ExecDet.dynForLoop (N := mn.resArr.length) (N_max := cp.B_scan) (C_b := ops.C_read + 100)
    27 30 _ Inv hfp5 (by omega) (by omega) (by unfold M_slots at hBW_scr; omega)
    (by decide) hr30 hlen_B hInv0 ?_).mono
    (fun m ⟨⟨hsrm, hndm, hftm, hfmm, hfam, hfsm, hfrm⟩, _, _, _, henc⟩ _ => ?_) (by nlinarith)
  · intro k hk m ⟨hFR, hr20, hr21, hr22, henc_k⟩ hctr hfp
    let x := mn.resArr[k]'hk
    have hx_n : x < cp.n := hres_n x (List.getElem_mem hk)
    obtain ⟨hx_not, hdi_eq⟩ := denseInsert_take_succ hnd_res hk
    have hcR_m : wRead m engScrTbl cSlotR = (cSlot : ℤ) := (hFR.2.2.2.2.2.1 cSlotR hcR20).trans hread_cR
    refine ExecDet.seq' 100
      (ops.readNodeArrElem_spec inp m mn cSlot k .res hk cSlotR 27 23
        hcSlot hcR0 (by omega) (by omega) (by omega) (by omega) (by omega)
        hfp hFR.1 (hFR.2.1 mn cSlot hcSlot henc_mn) hcR_m hctr) (by omega) ?_
    intro mX ⟨hsrX, hr23, hndX, hftX, hfsX, hfrX⟩ hfpX
    dsimp [evalNodeArr] at hr23
    have henc_k' : EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) (mn.resArr.take k) mX :=
      henc_k.ext (hftX engMetaTbl (by decide) (by decide) 2)
        (fun _ _ => hftX engArrTbl (by decide) (by decide) _)
        (fun _ _ => hftX engArrTbl (by decide) (by decide) _)
    have hD_pos := cp.D_max_pos
    refine (exec_sparseInsertFreshStmt inp 20 21 22 23
      (by omega) (by unfold M_slots at hBW_scr; omega)
      (by decide) (by decide) (by decide) (by decide)
      (by omega) (by omega)
      (by unfold leafElemOff; omega)
      (by have h2S : 2 * S_stride cp ≤ ops.BW := by nlinarith [ops.hBW_arr]
          unfold leafElemOff S_stride at *; omega)
      (by unfold leafPosOff; omega)
      (by have h2S : 2 * S_stride cp ≤ ops.BW := by nlinarith [ops.hBW_arr]
          unfold leafPosOff S_stride at *; omega)
      (Or.inl (by unfold leafElemOff leafPosOff S_stride; omega))
      hx_n hx_not hfpX henc_k'
      ((hfsX 20 (by decide)).trans hr20)
      ((hfsX 21 (by decide)).trans hr21)
      ((hfsX 22 (by decide)).trans hr22)
      hr23).mono ?_ le_rfl
    intro mI ⟨henc_next, hftI, hfmI, hfaI, hfsI, hfrI⟩ _
    rw [hdi_eq] at henc_next
    let mN := H3a.wWrite mI engScrTbl 27 ((k : ℤ) + 1)
    have hw9_N : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mN t i = wRead mX t i :=
      fun t ht9 _ i => (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))).trans
        (hftI t (by unfold engMetaTbl; omega) (by unfold engArrTbl; omega) (by unfold engScrTbl; omega) i)
    have hr_N : ∀ t i, rRead mN t i = rRead mX t i :=
      fun t i => (rRead_wWrite _ _ _ _ _ _).trans (hfrI t i)
    refine ⟨(hfsI 27 (by omega)).trans ((hfsX 27 (by decide)).trans hctr),
      ⟨⟨ops.slotsReady_ext mX mN hsrX hw9_N (fun t _ _ i => hr_N t i),
        fun mn' s hs he0 => ops.encNode_ext mn' s mX mN
          (hndX mn' s hs (hFR.2.1 mn' s hs he0)) hw9_N (fun t _ _ i => hr_N t i) (fun _ _ _ _ => hr_N ptsRTbl _),
        fun t ht9 ht1 ht2 ht3 i => (wRead_wWrite_of_ne _ _ (Or.inl ht3)).trans
          ((hftI t ht1 ht2 ht3 i).trans ((hftX t ht9 ht3 i).trans (hFR.2.2.1 t ht9 ht1 ht2 ht3 i))),
        fun i hi2 => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfmI i hi2).trans ((hftX engMetaTbl (by decide) (by decide) i).trans (hFR.2.2.2.1 i hi2))),
        fun i hi_arr => ?_,
        fun i hi20 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans
          ((hfsI i (by omega)).trans ((hfsX i (by omega)).trans (hFR.2.2.2.2.2.1 i hi20))),
        fun t ht3 i => (hr_N t i).trans ((hfrX t ht3 i).trans (hFR.2.2.2.2.2.2 t ht3 i))⟩,
       (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans ((hfsI 20 (by omega)).trans ((hfsX 20 (by decide)).trans hr20)),
       (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans ((hfsI 21 (by omega)).trans ((hfsX 21 (by decide)).trans hr21)),
       (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans ((hfsI 22 (by omega)).trans ((hfsX 22 (by decide)).trans hr22)),
       henc_next.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
         (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
         (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))⟩⟩
    have hlen_tk : (mn.resArr.take k).length ≤ cp.n := by
      rw [List.length_take]
      have hsub : mn.resArr.toFinset ⊆ Finset.range cp.n := fun y hy =>
        Finset.mem_range.mpr (hres_n y (List.mem_toFinset.mp hy))
      have hcard := Finset.card_le_card hsub
      rw [Finset.card_range, List.toFinset_card_of_nodup hnd_res] at hcard
      exact (Nat.min_le_right _ _).trans hcard
    have hne_e : i ≠ leafElemOff + ((mn.resArr.take k).length : ℤ) := by unfold leafElemOff; omega
    have hne_p : i ≠ leafPosOff cp + (x : ℤ) := by unfold leafPosOff; omega
    exact (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
      ((hfaI i hne_e hne_p).trans ((hftX engArrTbl (by decide) (by decide) i).trans (hFR.2.2.2.2.1 i hi_arr)))
  · rw [List.take_length] at henc
    exact ⟨hsrm, henc, hndm, hftm, hfmm, hfam, hfsm, hfrm⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
