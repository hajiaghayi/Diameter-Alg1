import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB3a0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 2. `configDynRemoveCopiesStmt`: Combine Header Removal + `2 × Side.removeStmt` -/

def configDynRemoveCopiesCost {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℕ :=
  500 + 2 * unlinkLeftKeyCost + 2 * sops.removeCost

def configDynRemoveCopiesStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (wCfgBaseW wCfgBaseR wUid wScr rScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wCfgBaseW)
  let bRE := IntExpr.readHeap scrW (.lit wCfgBaseR)
  let wSBW := wScr + 5
  let wSBR := wScr + 6
  let wP := wScr + 7
  let wSub := wScr + 8
  .seq (configDynRemoveHdrStmt scrW tblW n wCfgBaseW wUid wScr)
  (.seq (.writeWordHeap scrW (.lit wSBW) (.add bWE (.lit (cfgHdrWStride n))))
  (.seq (.writeWordHeap scrW (.lit wSBR) bRE)
  (.seq (sops.removeStmt wSBW wSBR wP wSub rScr)
  (.seq (.writeWordHeap scrW (.lit wSBW) (.add bWE (.lit (cfgHdrWStride n + sops.sideWStride))))
  (.seq (.writeWordHeap scrW (.lit wSBR) (.add bRE (.lit sops.sideRStride)))
        (sops.removeStmt wSBW wSBR wP wSub rScr))))))

theorem zeroRand_configDynRemoveCopiesStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (wCfgBaseW wCfgBaseR wUid wScr rScr : ℤ) :
    ZeroRandStmt (configDynRemoveCopiesStmt sops wCfgBaseW wCfgBaseR wUid wScr rScr) :=
  .seq (zeroRand_configDynRemoveHdrStmt _ _ _ _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (sops.zeroRand_removeStmt _ _ _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
        (sops.zeroRand_removeStmt _ _ _ _ _))))))

theorem exec_configDynRemoveCopiesStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (hM₀ : 1 ≤ M₀) (hn : 2 ≤ n) (hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    {A B_rat : ℚ} (hAB : A ^ 2 + B_rat ^ 2 = 1)
    (wCfgBaseW wCfgBaseR wUid wScr rScr cfgBaseW cfgBaseR : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {p : ℕ} (hp_lt : p < n)
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (hwfL : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.leftIndexSet cs.leftIdx)
    (hwfR : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.rightIndexSet cs.rightIdx)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ cfgBaseW ∧ cfgBaseW + cfgTotalWStride n sops.sideWStride ≤ (BW : ℤ))
    (hbaseR : 0 ≤ cfgBaseR ∧ cfgBaseR + cfgTotalRStride sops.sideRStride ≤ (BR : ℤ))
    (hwBW : 0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr)
    (hwBR : 0 ≤ wCfgBaseR ∧ wCfgBaseR < wScr)
    (hwUid : 0 ≤ wUid ∧ wUid < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + configDynOpWScr sops ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + configDynOpRScr sops ≤ (BR : ℤ))
    (hbW : H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW)
    (hbR : H3a.wRead m₀ scrW wCfgBaseR = cfgBaseR)
    (hp_r : H3a.wRead m₀ scrW wUid = (p : ℤ))
    (henc : EncCfgDyn sops cfgBaseW cfgBaseR cs m₀) :
    let cs₀ : ConfigDynamicState L_p2 R ℓ M₀ d b :=
      { st := removeCopiesFromState cs.st p
        leftIdx := cs.leftIdx.removeHandle p
        rightIdx := cs.rightIdx.removeHandle p }
    let pairs := cs.st.matchingList.map MatchingEdge.pair
    let rP := (cs.st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
      (fun e => CopyVertex.mk .right e.right)
    let lP := (cs.st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
      (fun e => CopyVertex.mk .left e.left)
    ∃ mf : ArithRAMMemory,
      DetExec inp (configDynRemoveCopiesStmt sops wCfgBaseW wCfgBaseR wUid wScr rScr)
        m₀ mf (configDynRemoveCopiesCost sops) ∧
      InFootprint TW BW TR BR mf ∧
      EncCfgDyn sops cfgBaseW cfgBaseR cs₀ mf ∧
      (∀ w, w < wScr → H3a.wRead mf scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgTotalWStride n sops.sideWStride)
        tblR cfgBaseR (cfgTotalRStride sops.sideRStride) m₀ mf ∧
      ((rP = [] ∧ H3a.wRead mf scrW (wScr + 1) = 0) ∨
       (∃ y₀ : ℕ, y₀ ≠ p ∧ (p, y₀) ∈ pairs ∧ rP = [⟨.right, y₀⟩] ∧
         H3a.wRead mf scrW (wScr + 1) = 1 ∧ H3a.wRead mf scrW (wScr + 2) = (y₀ : ℤ))) ∧
      ((lP = [] ∧ H3a.wRead mf scrW (wScr + 3) = 0) ∨
       (∃ x₀ : ℕ, x₀ ≠ p ∧ (x₀, p) ∈ pairs ∧ lP = [⟨.left, x₀⟩] ∧
         H3a.wRead mf scrW (wScr + 3) = 1 ∧ H3a.wRead mf scrW (wScr + 4) = (x₀ : ℤ))) := by
  intro cs₀ pairs rP lP
  have hw2 := sops.hsideW_ge_two
  have hr0 := sops.hsideR_nonneg
  have hwScr1 := sops.hsideWScr_pos
  have hrScr1 := sops.hsideRScr_pos
  have hhdr3 := cfgHdrWStride_ge_three n
  have hwScr' : 0 ≤ wScr ∧ wScr + (16 + sops.sideWScrStride) ≤ (BW : ℤ) := hwScr
  have hrScr' : 0 ≤ rScr ∧ rScr + (2 + sops.sideRScrStride) ≤ (BR : ℤ) := hrScr
  have hscrW : scrW < TW := hvt.1
  have hneW : tblW ≠ scrW := hvt.2.2.2.2.2.2.1
  have hneR : tblR ≠ scrR := hvt.2.2.2.2.2.2.2.2.2.1
  have hUL_lt0 : ∀ u ∈ cs.st.leftIndexSet, u < n := by
    rcases henc.1 with ⟨_, _, _, _, _, _, h, _⟩; exact h
  have hUR_lt0 : ∀ u ∈ cs.st.rightIndexSet, u < n := by
    rcases henc.1 with ⟨_, _, _, _, _, _, _, h, _⟩; exact h
  let totW := cfgTotalWStride n sops.sideWStride
  let totR := cfgTotalRStride sops.sideRStride
  let lBW := cfgLeftSideWOff cfgBaseW n
  let rBW := cfgRightSideWOff cfgBaseW sops.sideWStride n
  let lBR := cfgLeftSideROff cfgBaseR
  let rBR := cfgRightSideROff cfgBaseR sops.sideRStride
  let wSBW := wScr + 5
  let wSBR := wScr + 6
  let wP := wScr + 7
  let wSub := wScr + 8
  obtain ⟨md, hdd, hfpd, henc_hdrd, hscrd, hwPd, hfr0d_H, hrP_d, hlP_d⟩ :=
    exec_configDynRemoveHdrStmt (tblR := tblR) (coinTbl := coinTbl) inp
      wCfgBaseW wUid wScr cfgBaseW cfgBaseR hp_lt hfp₀ hvt
      ⟨hbaseW.1, by unfold cfgTotalWStride at hbaseW; omega⟩
      hwBW hwUid ⟨hwScr.1, by omega⟩ hbW hp_r henc.1
  have hfr0d : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m₀ md :=
    rfo_lift_hdr hw2 hr0 hfr0d_H
  let me1 := H3a.wWrite md scrW wSBW lBW
  let me2 := H3a.wWrite me1 scrW wSBR lBR
  have hde1 : DetExec inp (.writeWordHeap scrW (.lit wSBW)
      (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (cfgHdrWStride n)))) md me1 25 :=
    DetExecAt.writeWordHeap 0 inp md scrW (.lit wSBW) _ rfl
      (by change H3a.wRead md scrW wCfgBaseW + cfgHdrWStride n = lBW
          rw [hscrd wCfgBaseW hwBW.2, hbW]; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hde2 : DetExec inp (.writeWordHeap scrW (.lit wSBR) (.readHeap scrW (.lit wCfgBaseR))) me1 me2 20 :=
    DetExecAt.writeWordHeap 0 inp me1 scrW (.lit wSBR) _ rfl
      (by change H3a.wRead me1 scrW wCfgBaseR = lBR
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hscrd wCfgBaseR hwBR.2, hbR]; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfpe2 : InFootprint TW BW TR BR me2 :=
    InFootprint.wWrite (InFootprint.wWrite hfpd hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hencL_e2 : sops.EncSide lBW lBR cs.st.leftIndexSet cs.leftIdx me2 :=
    sops.encSide_mono_slice hUL_lt0 henc.2.1
      (fun i hlo _ => by
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
        exact hfr0d_H.1 tblW i hneW (Or.inr (Or.inr (by unfold lBW cfgLeftSideWOff at hlo; omega))))
      (fun i _ _ => by
        rw [rRead_wWrite, rRead_wWrite]
        exact hfr0d_H.2 tblR i hneR (Or.inr (by rcases lt_or_ge i cfgBaseR with h | h; exact Or.inl h; exact Or.inr (by omega))))
  obtain ⟨me, hde3, hfpe, hencL_e, hkWe, hfre_L⟩ :=
    sops.exec_removeStmt inp hM₀ hn hL_p2 hAB
      wSBW wSBR wP wSub rScr lBW lBR hp_lt hUL_lt0 hwfL hfpe2 hvt
      ⟨by unfold lBW cfgLeftSideWOff; omega,
       by unfold lBW cfgLeftSideWOff; unfold cfgTotalWStride at hbaseW; omega⟩
      ⟨by unfold lBR cfgLeftSideROff; omega,
       by unfold lBR cfgLeftSideROff; unfold cfgTotalRStride at hbaseR; omega⟩
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      ⟨by omega, by omega, by omega⟩
      ⟨by omega, by omega⟩ ⟨hrScr.1, by omega⟩
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
      (wRead_wWrite_self _ _ _ _)
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hwPd])
      hencL_e2
  have hscre : ∀ w, w < wScr + 5 → H3a.wRead me scrW w = H3a.wRead md scrW w := by
    intro w hw
    rw [hkWe w (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  let mf1 := H3a.wWrite me scrW wSBW rBW
  let mf2 := H3a.wWrite mf1 scrW wSBR rBR
  have hdf1 : DetExec inp (.writeWordHeap scrW (.lit wSBW)
      (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (cfgHdrWStride n + sops.sideWStride)))) me mf1 25 :=
    DetExecAt.writeWordHeap 0 inp me scrW (.lit wSBW) _ rfl
      (by change H3a.wRead me scrW wCfgBaseW + (cfgHdrWStride n + sops.sideWStride) = rBW
          rw [hscre wCfgBaseW (by omega), hscrd wCfgBaseW hwBW.2, hbW]
          unfold rBW cfgRightSideWOff; ring)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hdf2 : DetExec inp (.writeWordHeap scrW (.lit wSBR)
      (.add (.readHeap scrW (.lit wCfgBaseR)) (.lit sops.sideRStride))) mf1 mf2 25 :=
    DetExecAt.writeWordHeap 0 inp mf1 scrW (.lit wSBR) _ rfl
      (by change H3a.wRead mf1 scrW wCfgBaseR + sops.sideRStride = rBR
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hscre wCfgBaseR (by omega),
              hscrd wCfgBaseR hwBR.2, hbR]; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfpf2 : InFootprint TW BW TR BR mf2 :=
    InFootprint.wWrite (InFootprint.wWrite hfpe hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hencR_f2 : sops.EncSide rBW rBR cs.st.rightIndexSet cs.rightIdx mf2 :=
    sops.encSide_mono_slice hUR_lt0 henc.2.2
      (fun i hlo _ => by
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
            hfre_L.1 tblW i hneW (Or.inr (Or.inr (by
              unfold rBW cfgRightSideWOff at hlo; unfold lBW cfgLeftSideWOff; omega))),
            wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
        exact hfr0d_H.1 tblW i hneW (Or.inr (Or.inr (by unfold rBW cfgRightSideWOff at hlo; omega))))
      (fun i hlo _ => by
        rw [rRead_wWrite, rRead_wWrite,
            hfre_L.2 tblR i hneR (Or.inr (Or.inr (by
              unfold rBR cfgRightSideROff at hlo; unfold lBR cfgLeftSideROff; omega))),
            rRead_wWrite, rRead_wWrite]
        exact hfr0d_H.2 tblR i hneR (Or.inr (by rcases lt_or_ge i cfgBaseR with h | h; exact Or.inl h; exact Or.inr (by omega))))
  obtain ⟨mf, hdf3, hfpf, hencR_f, hkWf, hfrf_R⟩ :=
    sops.exec_removeStmt inp hM₀ hn hL_p2 hAB
      wSBW wSBR wP wSub rScr rBW rBR hp_lt hUR_lt0 hwfR hfpf2 hvt
      ⟨by unfold rBW cfgRightSideWOff; omega,
       by unfold rBW cfgRightSideWOff; unfold cfgTotalWStride at hbaseW; omega⟩
      ⟨by unfold rBR cfgRightSideROff; omega,
       by unfold rBR cfgRightSideROff; unfold cfgTotalRStride at hbaseR; omega⟩
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      ⟨by omega, by omega, by omega⟩
      ⟨by omega, by omega⟩ ⟨hrScr.1, by omega⟩
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
      (wRead_wWrite_self _ _ _ _)
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              hkWe wP (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hwPd])
      hencR_f2
  have hfr0f : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m₀ mf :=
    (((((hfr0d.trans (rfo_wWrite_scr _ _ _ _ _ _ _ _ md wSBW lBW)).trans
        (rfo_wWrite_scr _ _ _ _ _ _ _ _ me1 wSBR lBR)).trans
        (rfo_lift_left hw2 hr0 hfre_L)).trans
        (rfo_wWrite_scr _ _ _ _ _ _ _ _ me wSBW rBW)).trans
        (rfo_wWrite_scr _ _ _ _ _ _ _ _ mf1 wSBR rBR)).trans
        (rfo_lift_right hw2 hr0 hfrf_R)
  have hscrf_low : ∀ w, w < wScr + 5 → H3a.wRead mf scrW w = H3a.wRead md scrW w := by
    intro w hw
    rw [hkWf w (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hscre w hw]
  have henc_hdrf : EncLocalMatching tblW cfgBaseW n cs₀.st mf :=
    henc_hdrd.mono_slice (fun i _ hhi => by
      rw [hfrf_R.1 tblW i hneW (Or.inr (Or.inl (by unfold rBW cfgRightSideWOff; omega))),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          hfre_L.1 tblW i hneW (Or.inr (Or.inl (by unfold lBW cfgLeftSideWOff; omega))),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
  have hUL₀_eq : cs₀.st.leftIndexSet = cs.st.leftIndexSet.erase p :=
    leftIndexSet_removeCopies_eq cs.st p
  have hUR₀_eq : cs₀.st.rightIndexSet = cs.st.rightIndexSet.erase p :=
    rightIndexSet_removeCopies_eq cs.st p
  have hencL_f : sops.EncSide lBW lBR cs₀.st.leftIndexSet cs₀.leftIdx mf := by
    rw [hUL₀_eq]
    exact sops.encSide_mono_slice (fun u hu => hUL_lt0 u (Finset.mem_of_mem_erase hu)) hencL_e
      (fun i _ hhi => by
        rw [hfrf_R.1 tblW i hneW (Or.inr (Or.inl (by
              unfold lBW cfgLeftSideWOff at hhi; unfold rBW cfgRightSideWOff; omega))),
            wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
      (fun i _ hhi => by
        rw [hfrf_R.2 tblR i hneR (Or.inr (Or.inl (by
              unfold lBR cfgLeftSideROff at hhi; unfold rBR cfgRightSideROff; omega))),
            rRead_wWrite, rRead_wWrite])
  have hencR_f' : sops.EncSide rBW rBR cs₀.st.rightIndexSet cs₀.rightIdx mf := by
    rwa [hUR₀_eq]
  have hd_all : DetExec inp (configDynRemoveCopiesStmt sops wCfgBaseW wCfgBaseR wUid wScr rScr)
      m₀ mf (configDynRemoveCopiesCost sops) :=
    (hdd.seq (hde1.seq (hde2.seq (hde3.seq (hdf1.seq (hdf2.seq hdf3)))))).mono_cost
      (by unfold configDynRemoveCopiesCost configDynRemoveHdrCost; omega)
  refine ⟨mf, hd_all, hfpf, ⟨henc_hdrf, hencL_f, hencR_f'⟩,
    fun w hw => (hscrf_low w (by omega)).trans (hscrd w hw),
    hfr0f, ?_, ?_⟩
  · rcases hrP_d with ⟨hr, hh⟩ | ⟨y₀, hne, hmem, hr, hh, hy⟩
    · left; exact ⟨hr, (hscrf_low (wScr + 1) (by omega)).trans hh⟩
    · right
      exact ⟨y₀, hne, hmem, hr, (hscrf_low (wScr + 1) (by omega)).trans hh,
        (hscrf_low (wScr + 2) (by omega)).trans hy⟩
  · rcases hlP_d with ⟨hl, hh⟩ | ⟨x₀, hne, hmem, hl, hh, hx⟩
    · left; exact ⟨hl, (hscrf_low (wScr + 3) (by omega)).trans hh⟩
    · right
      exact ⟨x₀, hne, hmem, hl, (hscrf_low (wScr + 3) (by omega)).trans hh,
        (hscrf_low (wScr + 4) (by omega)).trans hx⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
