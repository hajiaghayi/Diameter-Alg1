import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Stage4Prim
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a3
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 1. Pure List Fold Decomposition for `stepStage4` -/

private theorem foldl_flatMap_step {α β γ : Type*} (f : α → γ → α) (g : β → List γ) :
    ∀ (xs : List β) (acc : α),
      (xs.flatMap g).foldl f acc = xs.foldl (fun a x => (g x).foldl f a) acc
  | [], _ => rfl
  | x :: tl, acc => by
      simp only [List.flatMap_cons, List.foldl_append, List.foldl_cons]
      exact foldl_flatMap_step f g tl _

/-! ### 2. Leaf Candidate Fold (`leafCandFoldStmt`) -/

def leafCandFoldStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ArithRAMStmt :=
  .seq
    (.ite (.and (.intEq (.readHeap engMetaTbl (.lit 1)) (.lit 0))
                (.intLe (.readHeap engMetaTbl (.lit 2)) (.lit (cp.B_scan : ℤ))))
      (evalExactLeafPairStmt cp.B_scan d)
      (.writeWordHeap engScrTbl (.lit 12) (.lit 0)))
    (foldCandStepStmt 12 13 14 d)

theorem zeroRand_leafCandFoldStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    ZeroRandStmt (leafCandFoldStmt cp) :=
  .seq (.ite (zeroRand_evalExactLeafPairStmt cp.B_scan d) (.writeWordHeap _ _ _))
    (zeroRand_foldCandStepStmt 12 13 14 d)

def leafCandCost (B_scan d : ℕ) : ℕ :=
  380 + 80 * d + B_scan * (60 + B_scan * (210 + 80 * d))

theorem exec_leafCandFoldStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ m : ArithRAMMemory}
    {P' : DynamicPointSet d} {st : ChainEngineState cp}
    (cur : ℕ × ℕ)
    (hwf : ChainEngineWF cp P' st)
    (henc₀ : EncChainEngine ops st m₀)
    (hfp : InFootprint ops.TW ops.BW ops.TR ops.BR m)
    (hnf : NodeMemFrame ops m₀ m)
    (hc10 : wRead m engScrTbl 10 = (cur.1 : ℤ))
    (hc11 : wRead m engScrTbl 11 = (cur.2 : ℤ))
    (hcsq : rRead m engRealTbl 1 = ‖st.hp.coords cur.1 - st.hp.coords cur.2‖ ^ 2) :
    let leafPair : Option (ℕ × ℕ) :=
      if !st.leafOverflow && decide (st.leafArr.length ≤ cp.B_scan) then
        evalExactLeafPair st.hp.coords st.leafArr
      else
        none
    let nxt := stepBestGlobal st.hp.coords st.hp.actList cur leafPair
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (leafCandFoldStmt cp) m
      (fun m' =>
        NodeMemFrame ops m₀ m' ∧
        wRead m' engScrTbl 10 = (nxt.1 : ℤ) ∧
        wRead m' engScrTbl 11 = (nxt.2 : ℤ) ∧
        rRead m' engRealTbl 1 = ‖st.hp.coords nxt.1 - st.hp.coords nxt.2‖ ^ 2)
      (leafCandCost cp.B_scan d) := by
  have hTW9 : 9 ≤ ops.TW := by have := ops.hTW; omega
  have hBW64 : 64 ≤ ops.BW := by have := ops.hBW_scr; unfold M_slots at this; omega
  have hBR16 : 16 ≤ ops.BR := by have := ops.hBR_eng; omega
  have hT_scr : engScrTbl < ops.TW := by show 8 < ops.TW; omega
  let leafPair : Option (ℕ × ℕ) :=
    if !st.leafOverflow && decide (st.leafArr.length ≤ cp.B_scan) then
      evalExactLeafPair st.hp.coords st.leafArr
    else
      none
  unfold leafCandFoldStmt leafCandCost
  have hov_m : wRead m engMetaTbl 1 = (if st.leafOverflow then 1 else 0) :=
    (hnf.2.2.1 engMetaTbl (by decide) (by decide) 1).trans henc₀.2.2.2.1
  have hlen_m : wRead m engMetaTbl 2 = (st.leafArr.length : ℤ) :=
    (hnf.2.2.1 engMetaTbl (by decide) (by decide) 2).trans henc₀.2.2.2.2.2.1.2.2.1
  have hhhp_m : EncHandlePool st.hp m :=
    ⟨(hnf.2.2.1 0 (by decide) (by decide) 4).trans henc₀.2.1.1,
     (hnf.2.2.1 0 (by decide) (by decide) 5).trans henc₀.2.1.2.1,
     (hnf.2.2.1 0 (by decide) (by decide) 6).trans henc₀.2.1.2.2.1,
     fun i hi => (hnf.2.2.1 1 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.1 i hi),
     fun i hi => ⟨(hnf.2.2.1 2 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.2.1 i hi).1,
                  (hnf.2.2.1 3 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.2.1 i hi).2⟩,
     fun x hx c => (hnf.2.2.2 ptsRTbl (by decide) _).trans (henc₀.2.1.2.2.2.2.2 x hx c)⟩
  have hStep1 : ExecDet ops.TW ops.BW ops.TR ops.BR inp
      (.ite (.and (.intEq (.readHeap engMetaTbl (.lit 1)) (.lit 0))
                  (.intLe (.readHeap engMetaTbl (.lit 2)) (.lit (cp.B_scan : ℤ))))
        (evalExactLeafPairStmt cp.B_scan d)
        (.writeWordHeap engScrTbl (.lit 12) (.lit 0)))
      m
      (fun mA =>
        NodeMemFrame ops m₀ mA ∧
        EncOptPair 12 13 14 leafPair mA ∧
        wRead mA engScrTbl 10 = (cur.1 : ℤ) ∧
        wRead mA engScrTbl 11 = (cur.2 : ℤ) ∧
        rRead mA engRealTbl 1 = ‖st.hp.coords cur.1 - st.hp.coords cur.2‖ ^ 2)
      (80 + cp.B_scan * (60 + cp.B_scan * (210 + 80 * d))) := by
    refine ExecDet.ite_le (C_c := 15)
      (C_b := 65 + cp.B_scan * (60 + cp.B_scan * (210 + 80 * d))) _ _ _
      (by simp [condExprOps, intExprOps])
      (fun htrue => ?_) (fun hfalse => ?_)
    · have hcond : (!st.leafOverflow && decide (st.leafArr.length ≤ cp.B_scan)) = true := by
        simp only [evalArithCond, evalIntExpr] at htrue
        change (decide (wRead m engMetaTbl 1 = 0) &&
                decide (wRead m engMetaTbl 2 ≤ (cp.B_scan : ℤ))) = true at htrue
        rw [hov_m, hlen_m] at htrue
        simp only [Bool.and_eq_true, decide_eq_true_eq] at htrue ⊢
        rcases htrue with ⟨h1, h2⟩
        refine ⟨?_, Int.ofNat_le.mp h2⟩
        cases hov : st.leafOverflow <;> rw [hov] at h1 <;> simp at h1 ⊢
      have hov_f : st.leafOverflow = false := by
        simp only [Bool.and_eq_true, Bool.not_eq_true'] at hcond; exact hcond.1
      have hB : st.leafArr.length ≤ cp.B_scan := by
        simp only [Bool.and_eq_true, decide_eq_true_eq] at hcond; exact hcond.2
      have hlp_eq : leafPair = evalExactLeafPair st.hp.coords st.leafArr := by
        dsimp only [leafPair]; rw [hcond]; rfl
      have hleaf_sub : st.leafArr.toFinset ⊆ P'.activeHandles := by
        rw [(hwf.2.2.2.2.2 hov_f).2.1]
        exact (chainListInv_getElem P'.activeHandles st.serving (Finset.Subset.refl _) hwf.2.2.2.1).1
      have hleaf_pts : ∀ x ∈ st.leafArr, ∀ c : Fin d,
          rRead m ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (st.hp.coords x) c := by
        intro x hx c
        have hx_act : x ∈ st.hp.actList :=
          List.mem_toFinset.mp (hwf.1.2.2.2.1.symm ▸ hleaf_sub (List.mem_toFinset.mpr hx))
        exact hhhp_m.2.2.2.2.2 x (hwf.1.2.2.2.2.1 x hx_act) c
      refine (exec_evalExactLeafPairStmt inp st.hp.coords cp.B_scan hTW9 hBW64 ops.hTR hBR16
        hB hfp hlen_m
        (fun i hi => (hnf.2.2.1 engArrTbl (by decide) (by decide) _).trans
          (henc₀.2.2.2.2.2.1.2.2.2 i hi).1)
        hleaf_pts).mono ?_ (by omega)
      intro mA ⟨hoptA, hwtA, hwrA, hrtA, hrrA⟩ _
      rw [← hlp_eq] at hoptA
      exact ⟨hnf.trans (NodeMemFrame.of_scr_real hnf.1 hwtA hrtA),
        hoptA,
        (hwrA 10 (by decide)).trans hc10,
        (hwrA 11 (by decide)).trans hc11,
        (hrrA 1 (by decide)).trans hcsq⟩
    · have hcond : (!st.leafOverflow && decide (st.leafArr.length ≤ cp.B_scan)) = false := by
        simp only [evalArithCond, evalIntExpr] at hfalse
        change (decide (wRead m engMetaTbl 1 = 0) &&
                decide (wRead m engMetaTbl 2 ≤ (cp.B_scan : ℤ))) = false at hfalse
        rw [hov_m, hlen_m] at hfalse
        apply Bool.eq_false_iff.mpr
        intro hc
        simp only [Bool.and_eq_true, Bool.not_eq_true', decide_eq_true_eq] at hc
        have h2z : (st.leafArr.length : ℤ) ≤ (cp.B_scan : ℤ) := Int.ofNat_le.mpr hc.2
        simp [hc.1, h2z] at hfalse
      have hlp_eq : leafPair = none := by
        dsimp only [leafPair]; rw [hcond]; rfl
      refine ExecDet.wWrite inp engScrTbl (.lit 12) (.lit 0) 12 0
        hfp hT_scr (by omega) (by omega) rfl rfl (by dsimp [intExprOps]; omega) ?_
      rw [hlp_eq]
      exact ⟨hnf.trans (NodeMemFrame.wWrite_scr hnf.1 12 0),
        wRead_wWrite_self _ _ _ _,
        (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hc10,
        (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hc11,
        hcsq⟩
  refine ExecDet.seq' (300 + 80 * d) hStep1 (by omega) ?_
  intro mA ⟨hnfA, hoptA, hc10A, hc11A, hcsqA⟩ hfpA
  have hhpA : EncHandlePool st.hp mA :=
    ⟨(hnfA.2.2.1 0 (by decide) (by decide) 4).trans henc₀.2.1.1,
     (hnfA.2.2.1 0 (by decide) (by decide) 5).trans henc₀.2.1.2.1,
     (hnfA.2.2.1 0 (by decide) (by decide) 6).trans henc₀.2.1.2.2.1,
     fun i hi => (hnfA.2.2.1 1 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.1 i hi),
     fun i hi => ⟨(hnfA.2.2.1 2 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.2.1 i hi).1,
                  (hnfA.2.2.1 3 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.2.1 i hi).2⟩,
     fun x hx c => (hnfA.2.2.2 ptsRTbl (by decide) _).trans (henc₀.2.1.2.2.2.2.2 x hx c)⟩
  refine (exec_foldCandStepStmt inp 12 13 14 hTW9 hBW64 ops.hTR hBR16
    ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega, by omega⟩
    hwf.1 hfpA hhpA hoptA hc10A hc11A hcsqA).mono ?_ le_rfl
  intro m' ⟨h10', h11', hsq', hwt', _, hrt', _⟩ _
  exact ⟨hnfA.trans (NodeMemFrame.of_scr_real hnfA.1 hwt' hrt'), h10', h11', hsq'⟩

/-! ### 3. Per-Node & Multi-Node Candidate Fold (`cfgCandFoldStmt`, `oneNodeCandFoldStmt`) -/

def cfgCandFoldStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  seqList (List.finRange cp.N_cfg) (fun c =>
    .seq (ops.readCfgStoredEdgeStmt 20 c 12 13 14)
         (foldCandStepStmt 12 13 14 d))

theorem zeroRand_cfgCandFoldStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (cfgCandFoldStmt ops) :=
  zeroRand_seqList _ _ (fun c _ =>
    .seq (ops.zeroRand_readCfgStoredEdge 20 c 12 13 14)
         (zeroRand_foldCandStepStmt 12 13 14 d))

theorem exec_cfgCandFoldStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ m : ArithRAMMemory}
    {P' : DynamicPointSet d} {st : ChainEngineState cp}
    (mn : MNode cp) {slot : ℕ} (cur : ℕ × ℕ)
    (hslot : slot < M_slots cp)
    (hwf_hp : st.hp.WellFormed P')
    (henc₀ : EncChainEngine ops st m₀)
    (hmn₀ : ops.EncNode mn slot m₀)
    (hfp : InFootprint ops.TW ops.BW ops.TR ops.BR m)
    (hnf : NodeMemFrame ops m₀ m)
    (hs20 : wRead m engScrTbl 20 = (slot : ℤ))
    (hc10 : wRead m engScrTbl 10 = (cur.1 : ℤ))
    (hc11 : wRead m engScrTbl 11 = (cur.2 : ℤ))
    (hcsq : rRead m engRealTbl 1 = ‖st.hp.coords cur.1 - st.hp.coords cur.2‖ ^ 2) :
    let ses := (List.finRange cp.N_cfg).map (fun c => (mn.nd.cfgs c).st.storedEdge)
    let nxt := ses.foldl (stepBestGlobal st.hp.coords st.hp.actList) cur
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (cfgCandFoldStmt ops) m
      (fun m' =>
        NodeMemFrame ops m₀ m' ∧
        wRead m' engScrTbl 10 = (nxt.1 : ℤ) ∧
        wRead m' engScrTbl 11 = (nxt.2 : ℤ) ∧
        rRead m' engRealTbl 1 = ‖st.hp.coords nxt.1 - st.hp.coords nxt.2‖ ^ 2)
      (1 + cp.N_cfg * (ops.C_read + 300 + 80 * d)) := by
  have hTW9 : 9 ≤ ops.TW := by have := ops.hTW; omega
  have hBW64 : 64 ≤ ops.BW := by have := ops.hBW_scr; unfold M_slots at this; omega
  have hBR16 : 16 ≤ ops.BR := by have := ops.hBR_eng; omega
  unfold cfgCandFoldStmt
  let stepC : (ℕ × ℕ) → Fin cp.N_cfg → (ℕ × ℕ) := fun b c =>
    stepBestGlobal st.hp.coords st.hp.actList b (mn.nd.cfgs c).st.storedEdge
  let Inv : (ℕ × ℕ) → ArithRAMMemory → Prop := fun b mx =>
    NodeMemFrame ops m₀ mx ∧
    wRead mx engScrTbl 20 = (slot : ℤ) ∧
    wRead mx engScrTbl 10 = (b.1 : ℤ) ∧
    wRead mx engScrTbl 11 = (b.2 : ℤ) ∧
    rRead mx engRealTbl 1 = ‖st.hp.coords b.1 - st.hp.coords b.2‖ ^ 2
  have hlen_fr : (List.finRange cp.N_cfg).length = cp.N_cfg := List.length_finRange
  refine (exec_seqList (List.finRange cp.N_cfg) _ stepC Inv
    (ops.C_read + 300 + 80 * d) hfp ⟨hnf, hs20, hc10, hc11, hcsq⟩ ?_).mono
    (fun m' ⟨hnf', _, h10', h11', hsq'⟩ _ => by
      rw [List.foldl_map]
      exact ⟨hnf', h10', h11', hsq'⟩)
    (by rw [hlen_fr])
  intro c _ b mx ⟨hnf_x, hs20_x, h10_x, h11_x, hsq_x⟩ hfp_x
  refine ExecDet.seq' (300 + 80 * d)
    (ops.readCfgStoredEdge_spec inp mx mn slot c 20 12 13 14
      hslot (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
      (by decide) (by decide) (by decide)
      hfp_x hnf_x.1 (hnf_x.2.1 mn slot hslot hmn₀) hs20_x)
    (by omega) ?_
  intro mA ⟨hsrA, hedgeA, hndA, hwtA, hwrA, hrrA⟩ hfpA
  have hnfA : NodeMemFrame ops m₀ mA :=
    hnf_x.trans ⟨hsrA, hndA, hwtA, fun t ht2 i => hrrA t (by omega) i⟩
  have hoptA : EncOptPair 12 13 14 (mn.nd.cfgs c).st.storedEdge mA := hedgeA
  have hhpA : EncHandlePool st.hp mA :=
    ⟨(hnfA.2.2.1 0 (by decide) (by decide) 4).trans henc₀.2.1.1,
     (hnfA.2.2.1 0 (by decide) (by decide) 5).trans henc₀.2.1.2.1,
     (hnfA.2.2.1 0 (by decide) (by decide) 6).trans henc₀.2.1.2.2.1,
     fun i hi => (hnfA.2.2.1 1 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.1 i hi),
     fun i hi => ⟨(hnfA.2.2.1 2 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.2.1 i hi).1,
                  (hnfA.2.2.1 3 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.2.1 i hi).2⟩,
     fun x hx ch => (hnfA.2.2.2 ptsRTbl (by decide) _).trans (henc₀.2.1.2.2.2.2.2 x hx ch)⟩
  refine (exec_foldCandStepStmt inp 12 13 14 hTW9 hBW64 ops.hTR hBR16
    ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega, by omega⟩
    hwf_hp hfpA hhpA hoptA
    ((hwrA 10 (by decide) (by decide) (by decide)).trans h10_x)
    ((hwrA 11 (by decide) (by decide) (by decide)).trans h11_x)
    ((hrrA engRealTbl (by decide) 1).trans hsq_x)).mono ?_ le_rfl
  intro mB ⟨h10B, h11B, hsqB, hwtB, hwrB, hrtB, _⟩ _
  exact ⟨hnfA.trans (NodeMemFrame.of_scr_real hnfA.1 hwtB hrtB),
    (hwrB 20 (by omega) (by decide) (by decide)).trans
      ((hwrA 20 (by decide) (by decide) (by decide)).trans hs20_x),
    h10B, h11B, hsqB⟩

def oneNodeCandFoldStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops)
    (i : Fin cp.D_max) : ArithRAMStmt :=
  .ite (.intLt (.lit (i.val : ℤ)) (.readHeap engMetaTbl (.lit 0)))
    (.seq (.writeWordHeap engScrTbl (.lit 20) (.readHeap engMetaTbl (.lit (servSlotOff i.val))))
    (.seq (evalBaselinePairStmt ops mops (cp.B_S1 + cp.B_S2 + i.val * cp.B_base))
    (.seq (foldCandStepStmt 12 13 14 d)
          (cfgCandFoldStmt ops))))
    .skip

theorem zeroRand_oneNodeCandFoldStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops)
    (i : Fin cp.D_max) :
    ZeroRandStmt (oneNodeCandFoldStmt ops mops i) :=
  .ite (.seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_evalBaselinePairStmt ops mops _)
    (.seq (zeroRand_foldCandStepStmt 12 13 14 d)
          (zeroRand_cfgCandFoldStmt ops)))) .skip

def oneNodeCandCost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops) : ℕ :=
  mops.C_maxRad + ops.C_read + 550 + 80 * d +
    cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d) +
    cp.N_cfg * (ops.C_read + 300 + 80 * d)

/-! ### 4. Complete `stepStage4Stmt` & `exec_stepStage4Stmt` -/

def allNodesCandFoldStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops) :
    ArithRAMStmt :=
  seqList (List.finRange cp.D_max) (oneNodeCandFoldStmt ops mops)

def stepStage4Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops) :
    ArithRAMStmt :=
  evalBestGlobalAnswerStmt d (.seq (leafCandFoldStmt cp) (allNodesCandFoldStmt ops mops))

theorem zeroRand_stepStage4Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops) :
    ZeroRandStmt (stepStage4Stmt ops mops) :=
  zeroRand_evalBestGlobalAnswerStmt d
    (.seq (zeroRand_leafCandFoldStmt cp)
      (zeroRand_seqList _ _ (fun i _ => zeroRand_oneNodeCandFoldStmt ops mops i)))

def stepStage4Cost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops) : ℕ :=
  290 + 80 * d + leafCandCost cp.B_scan d +
    cp.D_max * oneNodeCandCost ops mops

theorem exec_stepStage4Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    {P' : DynamicPointSet d} {st : ChainEngineState cp}
    (bits : Fin cp.B_STEP → Bool)
    (hwf : ChainEngineWF cp P' st)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops st m₀)
    (hcoins : MemHasStepCoins cp bits m₀) :
    let ω₄ := (bitsToStepCoinBundle cp bits).2.2
    let st₄ := stepStage4 cp st ω₄
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (stepStage4Stmt ops mops) m₀
      (fun m₁ =>
        EncChainEngine ops st₄ m₁ ∧
        wRead m₁ 0 0 = wRead m₀ 0 0 ∧
        (let a := ArithRAMDynamicProgram.readCachedAnswer m₁
         ({ diameterHandles := a.1, cachedDistSq := a.2 } : StoredDiameterAnswer) = st₄.cachedAns))
      (stepStage4Cost ops mops) := by
  have hTW9 : 9 ≤ ops.TW := by have := ops.hTW; omega
  have hBW64 : 64 ≤ ops.BW := by have := ops.hBW_scr; unfold M_slots at this; omega
  have hBR16 : 16 ≤ ops.BR := by have := ops.hBR_eng; omega
  have hT_scr : engScrTbl < ops.TW := by show 8 < ops.TW; omega
  let ω₄ := (bitsToStepCoinBundle cp bits).2.2
  let pts := st.hp.coords
  let leafPair : Option (ℕ × ℕ) :=
    if !st.leafOverflow && decide (st.leafArr.length ≤ cp.B_scan) then
      evalExactLeafPair pts st.leafArr
    else
      none
  let nodeListAt : Fin cp.D_max → List (Option (ℕ × ℕ)) := fun i =>
    if hi : i.val < st.serving.length then
      let mn := st.serving[i.val]'hi
      let bp := evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr (ω₄ i)
      let ses := (List.finRange cp.N_cfg).map (fun c => (mn.nd.cfgs c).st.storedEdge)
      bp :: ses
    else
      []
  let cands : List (Option (ℕ × ℕ)) := leafPair :: (List.finRange cp.D_max).flatMap nodeListAt
  rcases henc₀.2.2.2.2.2.2.2.2 with ⟨servSlots, readySlots, curSlots, hslen, hserv, _, _, hlt_all⟩
  unfold stepStage4Stmt stepStage4Cost
  refine (exec_evalBestGlobalAnswerStmt ops inp cands
    (.seq (leafCandFoldStmt cp) (allNodesCandFoldStmt ops mops))
    (leafCandCost cp.B_scan d + (1 + cp.D_max * oneNodeCandCost ops mops))
    hwf.1 hfp₀ henc₀ ?_).mono
    (fun m₁ ⟨henc₁, hw00⟩ _ => by
      have hst₄_eq : { st with cachedAns := evalBestGlobalAnswer pts st.hp.actList cands } =
          stepStage4 cp st ω₄ := rfl
      rw [hst₄_eq] at henc₁
      have hread_ans := henc₁.2.2.1.1
      refine ⟨henc₁, hw00, ?_⟩
      dsimp only
      rw [hread_ans])
    (by omega)
  intro init m hfp hnf hc10 hc11 hcsq
  refine ExecDet.seq' (1 + cp.D_max * oneNodeCandCost ops mops)
    (exec_leafCandFoldStmt ops inp init hwf henc₀ hfp hnf hc10 hc11 hcsq)
    (by omega) ?_
  intro mL ⟨hnfL, h10L, h11L, hsqL⟩ hfpL
  let stepN : (ℕ × ℕ) → Fin cp.D_max → (ℕ × ℕ) := fun b i =>
    (nodeListAt i).foldl (stepBestGlobal pts st.hp.actList) b
  let Inv : (ℕ × ℕ) → ArithRAMMemory → Prop := fun b mx =>
    NodeMemFrame ops m₀ mx ∧
    wRead mx engScrTbl 10 = (b.1 : ℤ) ∧
    wRead mx engScrTbl 11 = (b.2 : ℤ) ∧
    rRead mx engRealTbl 1 = ‖pts b.1 - pts b.2‖ ^ 2
  have hlen_D : (List.finRange cp.D_max).length = cp.D_max := List.length_finRange
  unfold allNodesCandFoldStmt
  refine (exec_seqList (List.finRange cp.D_max) (oneNodeCandFoldStmt ops mops) stepN Inv
    (oneNodeCandCost ops mops) hfpL ⟨hnfL, h10L, h11L, hsqL⟩ ?_).mono
    (fun m' ⟨hnf', h10', h11', hsq'⟩ _ => by
      have hfold_eq : cands.foldl (stepBestGlobal pts st.hp.actList) init =
          (List.finRange cp.D_max).foldl stepN
            (stepBestGlobal pts st.hp.actList init leafPair) := by
        dsimp only [cands, List.foldl_cons]
        exact foldl_flatMap_step (stepBestGlobal pts st.hp.actList) nodeListAt
          (List.finRange cp.D_max) _
      rw [hfold_eq]
      exact ⟨hnf', h10', h11', hsq'⟩)
    (by rw [hlen_D])
  intro i _ curB mx ⟨hnf_x, h10_x, h11_x, hsq_x⟩ hfp_x
  unfold oneNodeCandFoldStmt oneNodeCandCost
  have hserv0_x : wRead mx engMetaTbl 0 = (st.serving.length : ℤ) :=
    (hnf_x.2.2.1 engMetaTbl (by decide) (by decide) 0).trans henc₀.2.2.2.2.2.2.2.1
  refine ExecDet.ite_le (C_c := 10)
    (C_b := mops.C_maxRad + ops.C_read + 540 + 80 * d +
      cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d) +
      cp.N_cfg * (ops.C_read + 300 + 80 * d))
    _ _ _ (by simp [condExprOps, intExprOps])
    (fun hlt_b => ?_) (fun hge_b => ?_)
  · have hi : i.val < st.serving.length := by
      simp only [evalArithCond, evalIntExpr] at hlt_b
      change decide ((i.val : ℤ) < wRead mx engMetaTbl 0) = true at hlt_b
      rw [hserv0_x] at hlt_b
      exact Int.ofNat_lt.mp (of_decide_eq_true hlt_b)
    have his : i.val < servSlots.length := hslen ▸ hi
    let mn := st.serving[i.val]'hi
    let slot := servSlots[i.val]'his
    have hslot_lt : slot < M_slots cp :=
      hlt_all slot (List.mem_append_left _ (List.getElem_mem his))
    have hslot_meta : wRead mx engMetaTbl (servSlotOff i.val) = (slot : ℤ) :=
      (hnf_x.2.2.1 engMetaTbl (by decide) (by decide) _).trans (hserv i.val hi his).1
    have hmn₀ : ops.EncNode mn slot m₀ := (hserv i.val hi his).2
    rcases (chainListInv_getElem P'.activeHandles st.serving (Finset.Subset.refl _) hwf.2.2.2.1).2 i.val hi
      with ⟨hSi_sub, hcur_eq, _, _, _, _, _, _, hwf_mn⟩
    have hcur_act : mn.nd.curSet ⊆ P'.activeHandles := hcur_eq.symm ▸ hSi_sub
    have hcur_lt_nf : ∀ x ∈ mn.nd.curSet, x < st.hp.nextFresh := fun x hx =>
      hwf.1.2.2.2.2.1 x (List.mem_toFinset.mp (hwf.1.2.2.2.1.symm ▸ hcur_act hx))
    have hcur_lt_n : ∀ x ∈ mn.nd.curSet, x < cp.n := fun x hx =>
      lt_of_lt_of_le (hcur_lt_nf x hx) hwf.1.1
    obtain ⟨bBits, hω4_eq, _, hb_coins⟩ := memHasStepCoins_stage4_base cp bits m₀ hcoins i
    refine ExecDet.seq'
      (mops.C_maxRad + ops.C_read + 520 + 80 * d +
        cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d) +
        cp.N_cfg * (ops.C_read + 300 + 80 * d))
      (ExecDet.wWriteEq inp engScrTbl (.lit 20)
        (.readHeap engMetaTbl (.lit (servSlotOff i.val)))
        20 (slot : ℤ) hfp_x hT_scr (by omega) (by omega)
        rfl (by simp only [evalIntExpr]; exact hslot_meta) (by simp [intExprOps]))
      (by omega) ?_
    intro m1 hm1 hfp1; subst hm1
    have hnf1 : NodeMemFrame ops m₀ (H3a.wWrite mx engScrTbl 20 (slot : ℤ)) :=
      hnf_x.trans (NodeMemFrame.wWrite_scr hnf_x.1 20 (slot : ℤ))
    refine ExecDet.seq' (310 + 80 * d + cp.N_cfg * (ops.C_read + 300 + 80 * d))
      (exec_evalBaselinePairStmt ops mops inp pts mn bBits hslot_lt hcur_lt_n hwf_mn
        hfp1 hnf1.1 (hnf1.2.1 mn slot hslot_lt hmn₀)
        (wRead_wWrite_self _ _ _ _)
        (fun x hx c => (hnf1.2.2.2 ptsRTbl (by decide) _).trans
          (henc₀.2.1.2.2.2.2.2 x (hcur_lt_nf x hx) c))
        (fun k => (hnf1.2.2.1 coinTbl (by decide) (by decide) _).trans (hb_coins k)))
      (by omega) ?_
    intro m2 ⟨hnf12, hbp2, hwr2, hrr2⟩ hfp2
    have hnf2 : NodeMemFrame ops m₀ m2 := hnf1.trans hnf12
    have hbp_eq : evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr
        (bitsToBaseSeedEquiv cp bBits) =
        evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr (ω₄ i) := by
      rw [← hω4_eq]
    rw [hbp_eq] at hbp2
    have hhp2 : EncHandlePool st.hp m2 :=
      ⟨(hnf2.2.2.1 0 (by decide) (by decide) 4).trans henc₀.2.1.1,
       (hnf2.2.2.1 0 (by decide) (by decide) 5).trans henc₀.2.1.2.1,
       (hnf2.2.2.1 0 (by decide) (by decide) 6).trans henc₀.2.1.2.2.1,
       fun q hq => (hnf2.2.2.1 1 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.1 q hq),
       fun q hq => ⟨(hnf2.2.2.1 2 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.2.1 q hq).1,
                    (hnf2.2.2.1 3 (by decide) (by decide) _).trans (henc₀.2.1.2.2.2.2.1 q hq).2⟩,
       fun x hx c => (hnf2.2.2.2 ptsRTbl (by decide) _).trans (henc₀.2.1.2.2.2.2.2 x hx c)⟩
    have h10_2 : wRead m2 engScrTbl 10 = (curB.1 : ℤ) :=
      (hwr2 10 (Or.inl (by decide))).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans h10_x)
    have h11_2 : wRead m2 engScrTbl 11 = (curB.2 : ℤ) :=
      (hwr2 11 (Or.inl (by decide))).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans h11_x)
    have hsq_2 : rRead m2 engRealTbl 1 = ‖pts curB.1 - pts curB.2‖ ^ 2 :=
      (hrr2 1 (by decide)).trans hsq_x
    have hs20_2 : wRead m2 engScrTbl 20 = (slot : ℤ) :=
      (hwr2 20 (Or.inr rfl)).trans (wRead_wWrite_self _ _ _ _)
    refine ExecDet.seq' (1 + cp.N_cfg * (ops.C_read + 300 + 80 * d))
      (exec_foldCandStepStmt inp 12 13 14 hTW9 hBW64 ops.hTR hBR16
        ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega, by omega⟩
        hwf.1 hfp2 hhp2 hbp2 h10_2 h11_2 hsq_2)
      (by omega) ?_
    intro m3 ⟨h10_3, h11_3, hsq_3, hwt3, hwr3, hrt3, _⟩ hfp3
    have hnf3 : NodeMemFrame ops m₀ m3 :=
      hnf2.trans (NodeMemFrame.of_scr_real hnf2.1 hwt3 hrt3)
    have hs20_3 : wRead m3 engScrTbl 20 = (slot : ℤ) :=
      (hwr3 20 (by omega) (by decide) (by decide)).trans hs20_2
    have hstepN_eq : stepN curB i =
        ((List.finRange cp.N_cfg).map (fun c => (mn.nd.cfgs c).st.storedEdge)).foldl
          (stepBestGlobal pts st.hp.actList)
          (stepBestGlobal pts st.hp.actList curB
            (evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr (ω₄ i))) := by
      dsimp only [stepN, nodeListAt]
      rw [dif_pos hi, List.foldl_cons]
    rw [hstepN_eq]
    exact exec_cfgCandFoldStmt ops inp mn _ hslot_lt hwf.1 henc₀ hmn₀ hfp3 hnf3
      hs20_3 h10_3 h11_3 hsq_3
  · have hnot_i : ¬ i.val < st.serving.length := by
      simp only [evalArithCond, evalIntExpr] at hge_b
      change decide ((i.val : ℤ) < wRead mx engMetaTbl 0) = false at hge_b
      rw [hserv0_x] at hge_b
      intro hlt; exact of_decide_eq_false hge_b (Int.ofNat_lt.mpr hlt)
    have hstepN_eq : stepN curB i = curB := by
      dsimp only [stepN, nodeListAt]; rw [dif_neg hnot_i]; rfl
    refine ExecDet.skip inp hfp_x ?_ (by omega)
    rw [hstepN_eq]
    exact ⟨hnf_x, h10_x, h11_x, hsq_x⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
