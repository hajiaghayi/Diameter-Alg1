import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB3a

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 2. `configDynDeleteStmt`: Remove Copies + Coupled Former-Partner Repair -/

def configDynDeleteCost {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℕ :=
  560 + 2 * unlinkLeftKeyCost + 2 * sops.removeCost + 2 * attachCopyCost sops

def configDynDeleteStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wCfgBaseR wOffO _wOffV wUid wSeedOff wScr rScr : ℤ) : ArithRAMStmt :=
  let wHasRP := wScr + 1
  let wYRP := wScr + 2
  let wHasLP := wScr + 3
  let wXLP := wScr + 4
  let wSub := wScr + 8
  let b_rat := bRatCfg params spec.cfg
  .seq (configDynRemoveCopiesStmt sops wCfgBaseW wCfgBaseR wUid wScr rScr)
  (.seq (.ite (.intEq (.readHeap scrW (.lit wHasRP)) (.lit 1))
          (attachRightCopyStmt sops spec.A spec.B b_rat
            wCfgBaseW wCfgBaseR wOffO wYRP wSeedOff wSub rScr)
          .skip)
        (.ite (.intEq (.readHeap scrW (.lit wHasLP)) (.lit 1))
          (attachLeftCopyStmt sops spec.A spec.B b_rat
            wCfgBaseW wCfgBaseR wOffO wXLP wSeedOff wSub rScr)
          .skip))

theorem zeroRand_configDynDeleteStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr : ℤ) :
    ZeroRandStmt (configDynDeleteStmt sops spec
      wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr) :=
  .seq (zeroRand_configDynRemoveCopiesStmt sops _ _ _ _ _)
  (.seq (.ite (zeroRand_attachRightCopyStmt sops _ _ _ _ _ _ _ _ _ _) .skip)
        (.ite (zeroRand_attachLeftCopyStmt sops _ _ _ _ _ _ _ _ _ _) .skip))

theorem exec_configDynDeleteStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (hM₀ : 1 ≤ M₀) (hn : 2 ≤ n) (hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
      cfgBaseW cfgBaseR offO offV seedOff : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ} (hV : 0 < V)
    {S : Finset ℕ} {p : ℕ} (_hp_mem : p ∈ S) (hp_lt : p < n)
    (hS_lt : ∀ x ∈ S, x < n) (_hS_card : S.card ≤ n)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (htL : cs.leftIdx.t_ins + 1 < 2 ^ L_p2) (htR : cs.rightIdx.t_ins + 1 < 2 ^ L_p2)
    (hwf : ConfigDynamicWF hM₀ T_cdf p_coord params spec.A spec.B τ_d cap_u pts o V S spec.cfg cs)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ cfgBaseW ∧ cfgBaseW + cfgTotalWStride n sops.sideWStride ≤ (BW : ℤ))
    (hbaseR : 0 ≤ cfgBaseR ∧ cfgBaseR + cfgTotalRStride sops.sideRStride ≤ (BR : ℤ))
    (hoffO : 0 ≤ offO ∧ offO + (d : ℤ) ≤ cfgBaseR)
    (_hoffV : 0 ≤ offV ∧ offV < cfgBaseR)
    (hseedB : 0 ≤ seedOff ∧ seedOff + (cfgSeedBits L_p2 R ℓ M₀ d b : ℤ) ≤ (BW : ℤ))
    (hptsB : ((n * d : ℕ) : ℤ) ≤ (BR : ℤ))
    (hwBW : 0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr)
    (hwBR : 0 ≤ wCfgBaseR ∧ wCfgBaseR < wScr)
    (hwO : 0 ≤ wOffO ∧ wOffO < wScr)
    (_hwV : 0 ≤ wOffV ∧ wOffV < wScr)
    (hwUid : 0 ≤ wUid ∧ wUid < wScr)
    (hwSeed : 0 ≤ wSeedOff ∧ wSeedOff < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + configDynOpWScr sops ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + configDynOpRScr sops ≤ (BR : ℤ))
    (hbW : H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW)
    (hbR : H3a.wRead m₀ scrW wCfgBaseR = cfgBaseR)
    (ho_off : H3a.wRead m₀ scrW wOffO = offO)
    (_hv_off : H3a.wRead m₀ scrW wOffV = offV)
    (hp_r : H3a.wRead m₀ scrW wUid = (p : ℤ))
    (hseed_off : H3a.wRead m₀ scrW wSeedOff = seedOff)
    (ho_mem : ∀ c : Fin d, H3a.rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c)
    (_hv_mem : H3a.rRead m₀ tblR offV = V)
    (hpts : ∀ x ∈ S, ∀ c : Fin d,
      H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hseed : EncCfgSeedSlice coinTbl seedOff ω_L ω_R m₀)
    (henc : EncCfgDyn sops cfgBaseW cfgBaseR cs m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (configDynDeleteStmt sops spec
        wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr)
        m₀ m₁ (configDynDeleteCost sops) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncCfgDyn sops cfgBaseW cfgBaseR
        (cs.deleteOriginal hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg p ω_L ω_R) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgTotalWStride n sops.sideWStride)
        tblR cfgBaseR (cfgTotalRStride sops.sideRStride) m₀ m₁ := by
  have hwScr1 := sops.hsideWScr_pos
  have hrScr1 := sops.hsideRScr_pos
  have hwScr' : 0 ≤ wScr ∧ wScr + (16 + sops.sideWScrStride) ≤ (BW : ℤ) := hwScr
  have hrScr' : 0 ≤ rScr ∧ rScr + (2 + sops.sideRScrStride) ≤ (BR : ℤ) := hrScr
  obtain ⟨hpairs_sub, hUL_sub, hUR_sub⟩ := wellFormed_subsets hwf.1
  have hVL_S := leftVertices_subset params pts o V S spec.cfg.j
  have hVR_S := rightVertices_subset params pts o V S spec.cfg.k
  let totW := cfgTotalWStride n sops.sideWStride
  let totR := cfgTotalRStride sops.sideRStride
  let wHasRP := wScr + 1
  let wYRP := wScr + 2
  let wHasLP := wScr + 3
  let wXLP := wScr + 4
  let wSub := wScr + 8
  let cs₀ : ConfigDynamicState L_p2 R ℓ M₀ d b :=
    { st := removeCopiesFromState cs.st p
      leftIdx := cs.leftIdx.removeHandle p
      rightIdx := cs.rightIdx.removeHandle p }
  let pairs := cs.st.matchingList.map MatchingEdge.pair
  let rP := (cs.st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
    (fun e => CopyVertex.mk .right e.right)
  let lP := (cs.st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
    (fun e => CopyVertex.mk .left e.left)
  obtain ⟨mf, hdf, hfpf, henc_cs0, hscrf, hfr0f, hrP_f, hlP_f⟩ :=
    exec_configDynRemoveCopiesStmt sops inp hM₀ hn hL_p2 spec.hAB
      wCfgBaseW wCfgBaseR wUid wScr rScr cfgBaseW cfgBaseR hp_lt
      hwf.2.2.1 hwf.2.2.2 hfp₀ hvt hbaseW hbaseR hwBW hwBR hwUid hwScr hrScr
      hbW hbR hp_r henc
  have hdj₀ := IndexDisjoint.removeCopies p (IndexDisjoint.of_wellFormed hwf.1)
  have hremL := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q)
    spec.hAB (h := (1 / 2 : ℝ)) (by norm_num) (by norm_num) p hwf.2.2.1
  have hremR := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q)
    spec.hAB (h := (1 / 2 : ℝ)) (by norm_num) (by norm_num) p hwf.2.2.2
  have hUL₀_eq : cs₀.st.leftIndexSet = cs.st.leftIndexSet.erase p :=
    leftIndexSet_removeCopies_eq cs.st p
  have hUR₀_eq : cs₀.st.rightIndexSet = cs.st.rightIndexSet.erase p :=
    rightIndexSet_removeCopies_eq cs.st p
  have hwfL₀ : DyadicSideWF hM₀ T_cdf p_coord spec.A spec.B τ_d cap_u pts o cs₀.st.leftIndexSet cs₀.leftIdx := by
    rw [hUL₀_eq]; exact hremL.2.1
  have hwfR₀ : DyadicSideWF hM₀ T_cdf p_coord spec.A spec.B τ_d cap_u pts o cs₀.st.rightIndexSet cs₀.rightIdx := by
    rw [hUR₀_eq]; exact hremR.2.1
  have htL₀ : cs₀.leftIdx.t_ins = cs.leftIdx.t_ins := hremL.1
  have htR₀ : cs₀.rightIdx.t_ins = cs.rightIdx.t_ins := hremR.1
  have hUL₀_S : cs₀.st.leftIndexSet ⊆ S := fun x hx =>
    hVL_S (hUL_sub (Finset.mem_of_mem_erase (hUL₀_eq ▸ hx)))
  have hUR₀_S : cs₀.st.rightIndexSet ⊆ S := fun x hx =>
    hVR_S (hUR_sub (Finset.mem_of_mem_erase (hUR₀_eq ▸ hx)))
  obtain ⟨hof, h1_f, hseedf⟩ := rfo_preserves_env hvt hoffO hfr0f ho_mem hseed
  -- Phase 7: repair `rP` (`mf -> mg`)
  let rep1 := (coupledRepairList hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
    cap_u cap_q pts o V spec.cfg ω_L ω_R rP cs₀).1
  have hphase7 : ∃ mg : ArithRAMMemory,
      DetExec inp (.ite (.intEq (.readHeap scrW (.lit wHasRP)) (.lit 1))
        (attachRightCopyStmt sops spec.A spec.B (bRatCfg params spec.cfg)
          wCfgBaseW wCfgBaseR wOffO wYRP wSeedOff wSub rScr)
        .skip) mf mg (20 + attachCopyCost sops) ∧
      InFootprint TW BW TR BR mg ∧
      EncCfgDyn sops cfgBaseW cfgBaseR rep1 mg ∧
      (∀ w, w < wSub → H3a.wRead mg scrW w = H3a.wRead mf scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR mf mg ∧
      IndexDisjoint rep1.st ∧
      DyadicSideWF hM₀ T_cdf p_coord spec.A spec.B τ_d cap_u pts o rep1.st.leftIndexSet rep1.leftIdx ∧
      DyadicSideWF hM₀ T_cdf p_coord spec.A spec.B τ_d cap_u pts o rep1.st.rightIndexSet rep1.rightIdx ∧
      rep1.leftIdx.t_ins = cs₀.leftIdx.t_ins ∧
      rep1.rightIdx.t_ins ≤ cs₀.rightIdx.t_ins + 1 ∧
      rep1.st.leftIndexSet ⊆ S ∧
      rep1.st.rightIndexSet ⊆ S ∧
      (∀ x, x ∉ (cs₀.st.matchingList.map MatchingEdge.pair).map Prod.fst →
            x ∉ cs₀.st.leftIndexSet →
            x ∉ (rep1.st.matchingList.map MatchingEdge.pair).map Prod.fst ∧
            x ∉ rep1.st.leftIndexSet) := by
    rcases hrP_f with ⟨hrP_nil, hh0⟩ | ⟨y₀, _, hpy_mem, hrP_eq, hh1, hy_val⟩
    · have hcf : cValAt 0 inp mf (.intEq (.readHeap scrW (.lit wHasRP)) (.lit 1)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead mf scrW wHasRP = 1) = false
        rw [hh0]; exact decide_eq_false (by omega)
      have hrep1_eq : rep1 = cs₀ := by dsimp [rep1, rP]; rw [hrP_nil]; rfl
      rw [hrep1_eq]
      exact ⟨mf, (DetExecAt.ite_false (C_c := 15) hcf
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.skip 0 inp mf)).mono_cost (by omega),
        hfpf, henc_cs0, fun _ _ => rfl, RadFrameOutside.refl _ _ _ _ _ _ _ _ mf,
        hdj₀, hwfL₀, hwfR₀, rfl, Nat.le_succ _, hUL₀_S, hUR₀_S,
        fun _ h1 h2 => ⟨h1, h2⟩⟩
    · have hy_VR : y₀ ∈ params.rightVertices pts o V S spec.cfg.k := (hpairs_sub (p, y₀) hpy_mem).2
      have hy_S : y₀ ∈ S := hVR_S hy_VR
      have hy_lt : y₀ < n := hS_lt y₀ hy_S
      have hy_ne_o : pts y₀ ≠ o := ne_center_of_mem_rightVertices params spec.mem_one hy_VR
      obtain ⟨hy_not_m, hy_not_i⟩ := removeCopies_partner_right_absent hwf.1 hpy_mem
      have hnot_cond : ¬ (cs₀.st.isCopyMatched ⟨.right, y₀⟩ ∨ cs₀.st.isCopyInIndex ⟨.right, y₀⟩) := by
        rw [isCopyMatched_right_iff, isCopyInIndex_right_iff]
        exact not_or.mpr ⟨hy_not_m, hy_not_i⟩
      have hrep1_eq : rep1 = attachCopyStep hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg ⟨.right, y₀⟩ ω_L ω_R cs₀ := by
        dsimp [rep1, rP]; rw [hrP_eq]
        exact coupledRepairList_singleton_of_not hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg ω_L ω_R ⟨.right, y₀⟩ cs₀ hnot_cond
      have hct : cValAt 0 inp mf (.intEq (.readHeap scrW (.lit wHasRP)) (.lit 1)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead mf scrW wHasRP = 1) = true
        rw [hh1]; exact decide_eq_true rfl
      obtain ⟨mg, hdg, hfpg, hencg, hkWg, hfrfg⟩ :=
        exec_attachRightCopyStmt sops inp hM₀ hn hL_p2 params spec.cfg spec.hAB
          wCfgBaseW wCfgBaseR wOffO wYRP wSeedOff wSub rScr cfgBaseW cfgBaseR offO seedOff
          hV hy_lt hy_ne_o ω_L ω_R hdj₀ hy_not_m hy_not_i
          (by omega) (by omega) hwfL₀ hwfR₀ hfpf hvt hbaseW hbaseR hoffO hseedB hptsB
          ⟨hwBW.1, by omega⟩ ⟨hwBR.1, by omega⟩ ⟨hwO.1, by omega⟩
          ⟨by omega, by omega⟩ ⟨hwSeed.1, by omega⟩
          ⟨by omega, by unfold attachCopyWScr; omega⟩
          ⟨hrScr.1, by omega⟩
          ((hscrf wCfgBaseW hwBW.2).trans hbW)
          ((hscrf wCfgBaseR hwBR.2).trans hbR)
          ((hscrf wOffO hwO.2).trans ho_off)
          hy_val
          ((hscrf wSeedOff hwSeed.2).trans hseed_off)
          hof
          (fun x hx c => (h1_f _).trans (hpts x (by
            rcases Finset.mem_insert.mp hx with hxy | hx0; exact hxy ▸ hy_S; exact hUL₀_S hx0) c))
          (fun x hx c => (h1_f _).trans (hpts x (by
            rcases Finset.mem_insert.mp hx with hxy | hx0; exact hxy ▸ hy_S; exact hUR₀_S hx0) c))
          hseedf henc_cs0
      obtain ⟨hdj₁, hwfL₁, hwfR₁, htL₁, htR₁, hsubL₁, hsubR₁, hkeep_L⟩ :=
        attachCopyStep_right_props hM₀ T_cdf p_coord M_lat params spec.hAB τ_d τ_q cap_u cap_q
          pts o hV spec.cfg y₀ ω_L ω_R cs₀ hdj₀ hy_not_m hy_not_i hy_ne_o hwfL₀ hwfR₀
      rw [hrep1_eq]
      exact ⟨mg, (DetExecAt.ite_true (C_c := 15) hct
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hdg).mono_cost (by omega),
        hfpg, hencg, hkWg, hfrfg, hdj₁, hwfL₁, hwfR₁, htL₁, htR₁,
        fun x hx => hUL₀_S (hsubL₁ hx),
        fun x hx => by
          rcases Finset.mem_insert.mp (hsubR₁ hx) with hxy | hx0
          · exact hxy ▸ hy_S
          · exact hUR₀_S hx0,
        hkeep_L⟩
  obtain ⟨mg, hdg, hfpg, hencg, hkWg, hfrfg, hdj₁, hwfL₁, hwfR₁, htL₁, htR₁,
    hUL₁_S, hUR₁_S, hkeep_L⟩ := hphase7
  have hfr0g := hfr0f.trans hfrfg
  obtain ⟨hog, h1_g, hseedg⟩ := rfo_preserves_env hvt hoffO hfr0g ho_mem hseed
  -- Phase 8: repair `lP` (`mg -> mh`)
  let rep2 := (coupledRepairList hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
    cap_u cap_q pts o V spec.cfg ω_L ω_R lP rep1).1
  have hphase8 : ∃ mh : ArithRAMMemory,
      DetExec inp (.ite (.intEq (.readHeap scrW (.lit wHasLP)) (.lit 1))
        (attachLeftCopyStmt sops spec.A spec.B (bRatCfg params spec.cfg)
          wCfgBaseW wCfgBaseR wOffO wXLP wSeedOff wSub rScr)
        .skip) mg mh (20 + attachCopyCost sops) ∧
      InFootprint TW BW TR BR mh ∧
      EncCfgDyn sops cfgBaseW cfgBaseR rep2 mh ∧
      (∀ w, w < wSub → H3a.wRead mh scrW w = H3a.wRead mg scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR mg mh := by
    rcases hlP_f with ⟨hlP_nil, hh0⟩ | ⟨x₀, _, hxp_mem, hlP_eq, hh1, hx_val⟩
    · have hcf : cValAt 0 inp mg (.intEq (.readHeap scrW (.lit wHasLP)) (.lit 1)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead mg scrW wHasLP = 1) = false
        rw [hkWg wHasLP (by omega), hh0]; exact decide_eq_false (by omega)
      have hrep2_eq : rep2 = rep1 := by dsimp [rep2, lP]; rw [hlP_nil]; rfl
      rw [hrep2_eq]
      exact ⟨mg, (DetExecAt.ite_false (C_c := 15) hcf
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.skip 0 inp mg)).mono_cost (by omega),
        hfpg, hencg, fun _ _ => rfl, RadFrameOutside.refl _ _ _ _ _ _ _ _ mg⟩
    · have hx_VL : x₀ ∈ params.leftVertices pts o V S spec.cfg.j := (hpairs_sub (x₀, p) hxp_mem).1
      have hx_S : x₀ ∈ S := hVL_S hx_VL
      have hx_lt : x₀ < n := hS_lt x₀ hx_S
      have hx_ne_o : pts x₀ ≠ o := ne_center_of_mem_leftVertices params spec.mem_one hx_VL
      obtain ⟨hx_not_m0, hx_not_i0⟩ := removeCopies_partner_left_absent hwf.1 hxp_mem
      obtain ⟨hx_not_m1, hx_not_i1⟩ := hkeep_L x₀ hx_not_m0 hx_not_i0
      have hnot_cond : ¬ (rep1.st.isCopyMatched ⟨.left, x₀⟩ ∨ rep1.st.isCopyInIndex ⟨.left, x₀⟩) := by
        rw [isCopyMatched_left_iff, isCopyInIndex_left_iff]
        exact not_or.mpr ⟨hx_not_m1, hx_not_i1⟩
      have hrep2_eq : rep2 = attachCopyStep hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg ⟨.left, x₀⟩ ω_L ω_R rep1 := by
        dsimp [rep2, lP]; rw [hlP_eq]
        exact coupledRepairList_singleton_of_not hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg ω_L ω_R ⟨.left, x₀⟩ rep1 hnot_cond
      have hct : cValAt 0 inp mg (.intEq (.readHeap scrW (.lit wHasLP)) (.lit 1)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead mg scrW wHasLP = 1) = true
        rw [hkWg wHasLP (by omega), hh1]; exact decide_eq_true rfl
      obtain ⟨mh, hdh, hfph, hench, hkWh, hfrgh⟩ :=
        exec_attachLeftCopyStmt sops inp hM₀ hn hL_p2 params spec.cfg spec.hAB
          wCfgBaseW wCfgBaseR wOffO wXLP wSeedOff wSub rScr cfgBaseW cfgBaseR offO seedOff
          hV hx_lt hx_ne_o ω_L ω_R hdj₁ hx_not_m1 hx_not_i1
          (by omega) (by omega) hwfL₁ hwfR₁ hfpg hvt hbaseW hbaseR hoffO hseedB hptsB
          ⟨hwBW.1, by omega⟩ ⟨hwBR.1, by omega⟩ ⟨hwO.1, by omega⟩
          ⟨by omega, by omega⟩ ⟨hwSeed.1, by omega⟩
          ⟨by omega, by unfold attachCopyWScr; omega⟩
          ⟨hrScr.1, by omega⟩
          ((hkWg wCfgBaseW (by omega)).trans ((hscrf wCfgBaseW hwBW.2).trans hbW))
          ((hkWg wCfgBaseR (by omega)).trans ((hscrf wCfgBaseR hwBR.2).trans hbR))
          ((hkWg wOffO (by omega)).trans ((hscrf wOffO hwO.2).trans ho_off))
          ((hkWg wXLP (by omega)).trans hx_val)
          ((hkWg wSeedOff (by omega)).trans ((hscrf wSeedOff hwSeed.2).trans hseed_off))
          hog
          (fun x hx c => (h1_g _).trans (hpts x (by
            rcases Finset.mem_insert.mp hx with hxx | hx0; exact hxx ▸ hx_S; exact hUL₁_S hx0) c))
          (fun x hx c => (h1_g _).trans (hpts x (by
            rcases Finset.mem_insert.mp hx with hxx | hx0; exact hxx ▸ hx_S; exact hUR₁_S hx0) c))
          hseedg hencg
      rw [hrep2_eq]
      exact ⟨mh, (DetExecAt.ite_true (C_c := 15) hct
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hdh).mono_cost (by omega),
        hfph, hench, hkWh, hfrgh⟩
  obtain ⟨mh, hdh, hfph, hench, hkWh, hfrgh⟩ := hphase8
  have hF_eq := (survivingFormerPartners_eq_rP_lP hwf.1 p).1
  have hdel_eq : cs.deleteOriginal hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
      cap_u cap_q pts o V spec.cfg p ω_L ω_R = rep2 := by
    unfold ConfigDynamicState.deleteOriginal
    change (coupledRepairList hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
      cap_u cap_q pts o V spec.cfg ω_L ω_R (survivingFormerPartners cs.st p) cs₀).1 = rep2
    rw [hF_eq, coupledRepairList_fst_append]
  rw [hdel_eq]
  have hd_all : DetExec inp (configDynDeleteStmt sops spec
      wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr)
      m₀ mh (configDynDeleteCost sops) :=
    (hdf.seq (hdg.seq hdh)).mono_cost
      (by unfold configDynDeleteCost configDynRemoveCopiesCost; omega)
  exact ⟨mh, hd_all, hfph, hench,
    fun w hw => (hkWh w (by omega)).trans ((hkWg w (by omega)).trans (hscrf w hw)),
    hfr0g.trans hfrgh⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
