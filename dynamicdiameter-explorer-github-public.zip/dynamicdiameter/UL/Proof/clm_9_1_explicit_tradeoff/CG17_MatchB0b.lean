import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB0a

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 3. `appendEdgeStmt`: `O(1)` DLL Tail Append + Mate Array Updates -/

def appendEdgeCost : ℕ := 350

def appendEdgeStmt (scrW tblW n : ℕ)
    (wCfgBaseW wU wV wScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wCfgBaseW)
  let uE := IntExpr.readHeap scrW (.lit wU)
  let vE := IntExpr.readHeap scrW (.lit wV)
  let epE := IntExpr.readHeap scrW (.lit wScr)
  let tlE := IntExpr.readHeap scrW (.lit (wScr + 1))
  .seq (.writeWordHeap scrW (.lit wScr) (.readHeap tblW bWE))
  (.seq (.writeWordHeap scrW (.lit (wScr + 1)) (.readHeap tblW (.add bWE (.lit 2))))
  (.seq (.writeWordHeap tblW (.add (.add bWE (.lit 3)) uE) epE)
  (.seq (.writeWordHeap tblW (.add (.add bWE (.lit (3 + (n : ℤ)))) uE) vE)
  (.seq (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 2 * (n : ℤ)))) vE) epE)
  (.seq (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 3 * (n : ℤ)))) vE) uE)
  (.seq (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 6 * (n : ℤ)))) uE) tlE)
  (.seq (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 7 * (n : ℤ)))) uE) (.lit (-1)))
  (.seq (.writeWordHeap tblW (.add bWE (.lit 2)) uE)
        (.ite (.intLt tlE (.lit 0))
          (.writeWordHeap tblW (.add bWE (.lit 1)) uE)
          (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 7 * (n : ℤ)))) tlE) uE))))))))))

theorem zeroRand_appendEdgeStmt (scrW tblW n : ℕ)
    (wCfgBaseW wU wV wScr : ℤ) :
    ZeroRandStmt (appendEdgeStmt scrW tblW n wCfgBaseW wU wV wScr) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
        (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))))))))

theorem exec_appendEdgeStmt {d n : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCfgBaseW wU wV wScr cfgBaseW cfgBaseR : ℤ)
    {u v : ℕ} {st st' : LocalMatchingState ℕ}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ cfgBaseW ∧ cfgBaseW + cfgHdrWStride n ≤ (BW : ℤ))
    (hwBW : 0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr)
    (hwU : 0 ≤ wU ∧ wU < wScr)
    (hwV : 0 ≤ wV ∧ wV < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + 2 ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW)
    (hu_r : H3a.wRead m₀ scrW wU = (u : ℤ))
    (hv_r : H3a.wRead m₀ scrW wV = (v : ℤ))
    (hu_lt : u < n) (hv_lt : v < n)
    (hu_not : u ∉ (st.matchingList.map MatchingEdge.pair).map Prod.fst)
    (hv_not : v ∉ (st.matchingList.map MatchingEdge.pair).map Prod.snd)
    (hpairs' : st'.matchingList.map MatchingEdge.pair =
      st.matchingList.map MatchingEdge.pair ++ [(u, v)])
    (hUL' : st'.leftIndexSet = st.leftIndexSet)
    (hUR' : st'.rightIndexSet = st.rightIndexSet)
    (henc : EncLocalMatching tblW cfgBaseW n st m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (appendEdgeStmt scrW tblW n wCfgBaseW wU wV wScr)
        m₀ m₁ appendEdgeCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLocalMatching tblW cfgBaseW n st' m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m₀ m₁ := by
  have hscrW : scrW < TW := hvt.1
  have htblW : tblW < TW := hvt.2.1
  have hneW : tblW ≠ scrW := hvt.2.2.2.2.2.2.1
  rcases henc with ⟨ep, hep1, hep_r, hndL, hndR, hpairs_lt, hUL_lt, hUR_lt,
    hdll, hmL_le, hmL_to, hmL_of, hmR_le, hmR_to, hmR_of, hiL, hiR⟩
  let tlVal := H3a.wRead m₀ tblW (cfgTailOff cfgBaseW)
  let m1 := H3a.wWrite m₀ scrW wScr (ep : ℤ)
  let m2 := H3a.wWrite m1 scrW (wScr + 1) tlVal
  let m3 := H3a.wWrite m2 tblW (cfgMateLEpOff cfgBaseW n u) (ep : ℤ)
  let m4 := H3a.wWrite m3 tblW (cfgMateLValOff cfgBaseW n u) (v : ℤ)
  let m5 := H3a.wWrite m4 tblW (cfgMateREpOff cfgBaseW n v) (ep : ℤ)
  let m6 := H3a.wWrite m5 tblW (cfgMateRValOff cfgBaseW n v) (u : ℤ)
  let m7 := H3a.wWrite m6 tblW (cfgPrevOff cfgBaseW n u) tlVal
  let m8 := H3a.wWrite m7 tblW (cfgNextOff cfgBaseW n u) (-1)
  let m9 := H3a.wWrite m8 tblW (cfgTailOff cfgBaseW) (u : ℤ)
  have hscr_keep9 : ∀ w, w < wScr →
      H3a.wRead m1 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m5 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m6 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m7 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m8 scrW w = H3a.wRead m₀ scrW w ∧
      H3a.wRead m9 scrW w = H3a.wRead m₀ scrW w := by
    intro w hw
    have s1 : H3a.wRead m1 scrW w = H3a.wRead m₀ scrW w := wRead_wWrite_of_ne _ _ (Or.inr (by omega))
    have s2 : H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans s1
    have s3 : H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans s2
    have s4 : H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans s3
    have s5 : H3a.wRead m5 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans s4
    have s6 : H3a.wRead m6 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans s5
    have s7 : H3a.wRead m7 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans s6
    have s8 : H3a.wRead m8 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans s7
    have s9 : H3a.wRead m9 scrW w = H3a.wRead m₀ scrW w :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans s8
    exact ⟨s1, s2, s3, s4, s5, s6, s7, s8, s9⟩
  have hscr_ep : H3a.wRead m2 scrW wScr = (ep : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hscr_tl9 : H3a.wRead m9 scrW (wScr + 1) = tlVal := by
    simp only [m9, m8, m7, m6, m5, m4, m3, wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
    exact wRead_wWrite_self _ _ _ _
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.readHeap tblW (.readHeap scrW (.lit wCfgBaseW)))) m₀ m1 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wScr) _ rfl
      (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wCfgBaseW) = (ep : ℤ); rw [hbW]; exact hep_r)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
      (.readHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 2)))) m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 1)) _ rfl
      (by change H3a.wRead m1 tblW (H3a.wRead m1 scrW wCfgBaseW + 2) = tlVal
          rw [(hscr_keep9 wCfgBaseW hwBW.2).1, hbW, wRead_wWrite_of_ne _ _ (Or.inl hneW)]; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 3)) (.readHeap scrW (.lit wU)))
      (.readHeap scrW (.lit wScr))) m2 m3 35 :=
    DetExecAt.writeWordHeap 0 inp m2 tblW _ _
      (by change (H3a.wRead m2 scrW wCfgBaseW + 3) + H3a.wRead m2 scrW wU = cfgMateLEpOff cfgBaseW n u
          rw [(hscr_keep9 wCfgBaseW hwBW.2).2.1, (hscr_keep9 wU hwU.2).2.1, hbW, hu_r]
          unfold cfgMateLEpOff; ring)
      hscr_ep
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd4 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + (n : ℤ)))) (.readHeap scrW (.lit wU)))
      (.readHeap scrW (.lit wV))) m3 m4 35 :=
    DetExecAt.writeWordHeap 0 inp m3 tblW _ _
      (by change (H3a.wRead m3 scrW wCfgBaseW + (3 + (n : ℤ))) + H3a.wRead m3 scrW wU = cfgMateLValOff cfgBaseW n u
          rw [(hscr_keep9 wCfgBaseW hwBW.2).2.2.1, (hscr_keep9 wU hwU.2).2.2.1, hbW, hu_r]
          unfold cfgMateLValOff; ring)
      (by change H3a.wRead m3 scrW wV = (v : ℤ); rw [(hscr_keep9 wV hwV.2).2.2.1, hv_r])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd5 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 2 * (n : ℤ)))) (.readHeap scrW (.lit wV)))
      (.readHeap scrW (.lit wScr))) m4 m5 35 :=
    DetExecAt.writeWordHeap 0 inp m4 tblW _ _
      (by change (H3a.wRead m4 scrW wCfgBaseW + (3 + 2 * (n : ℤ))) + H3a.wRead m4 scrW wV = cfgMateREpOff cfgBaseW n v
          rw [(hscr_keep9 wCfgBaseW hwBW.2).2.2.2.1, (hscr_keep9 wV hwV.2).2.2.2.1, hbW, hv_r]
          unfold cfgMateREpOff; ring)
      (by change H3a.wRead m4 scrW wScr = (ep : ℤ)
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hscr_ep])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd6 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 3 * (n : ℤ)))) (.readHeap scrW (.lit wV)))
      (.readHeap scrW (.lit wU))) m5 m6 35 :=
    DetExecAt.writeWordHeap 0 inp m5 tblW _ _
      (by change (H3a.wRead m5 scrW wCfgBaseW + (3 + 3 * (n : ℤ))) + H3a.wRead m5 scrW wV = cfgMateRValOff cfgBaseW n v
          rw [(hscr_keep9 wCfgBaseW hwBW.2).2.2.2.2.1, (hscr_keep9 wV hwV.2).2.2.2.2.1, hbW, hv_r]
          unfold cfgMateRValOff; ring)
      (by change H3a.wRead m5 scrW wU = (u : ℤ); rw [(hscr_keep9 wU hwU.2).2.2.2.2.1, hu_r])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd7 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 6 * (n : ℤ)))) (.readHeap scrW (.lit wU)))
      (.readHeap scrW (.lit (wScr + 1)))) m6 m7 35 :=
    DetExecAt.writeWordHeap 0 inp m6 tblW _ _
      (by change (H3a.wRead m6 scrW wCfgBaseW + (3 + 6 * (n : ℤ))) + H3a.wRead m6 scrW wU = cfgPrevOff cfgBaseW n u
          rw [(hscr_keep9 wCfgBaseW hwBW.2).2.2.2.2.2.1, (hscr_keep9 wU hwU.2).2.2.2.2.2.1, hbW, hu_r]
          unfold cfgPrevOff; ring)
      (by change H3a.wRead m6 scrW (wScr + 1) = tlVal
          simp only [m6, m5, m4, m3, wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
          exact wRead_wWrite_self _ _ _ _)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd8 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 7 * (n : ℤ)))) (.readHeap scrW (.lit wU)))
      (.lit (-1))) m7 m8 35 :=
    DetExecAt.writeWordHeap 0 inp m7 tblW _ (.lit (-1))
      (by change (H3a.wRead m7 scrW wCfgBaseW + (3 + 7 * (n : ℤ))) + H3a.wRead m7 scrW wU = cfgNextOff cfgBaseW n u
          rw [(hscr_keep9 wCfgBaseW hwBW.2).2.2.2.2.2.2.1, (hscr_keep9 wU hwU.2).2.2.2.2.2.2.1, hbW, hu_r]
          unfold cfgNextOff; ring)
      rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd9 : DetExec inp (.writeWordHeap tblW
      (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 2)) (.readHeap scrW (.lit wU))) m8 m9 30 :=
    DetExecAt.writeWordHeap 0 inp m8 tblW _ _
      (by change H3a.wRead m8 scrW wCfgBaseW + 2 = cfgTailOff cfgBaseW
          rw [(hscr_keep9 wCfgBaseW hwBW.2).2.2.2.2.2.2.2.1, hbW]; rfl)
      (by change H3a.wRead m8 scrW wU = (u : ℤ); rw [(hscr_keep9 wU hwU.2).2.2.2.2.2.2.2.1, hu_r])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp9 : InFootprint TW BW TR BR m9 := by
    unfold cfgHdrWStride at hbaseW
    exact InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite
      (InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite
        (InFootprint.wWrite hfp₀ hscrW hwScr.1 (by omega))
        hscrW (by omega) (by omega))
        htblW (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega))
        htblW (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff; omega))
        htblW (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega))
        htblW (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff; omega))
        htblW (by unfold cfgPrevOff; omega) (by unfold cfgPrevOff; omega))
        htblW (by unfold cfgNextOff; omega) (by unfold cfgNextOff; omega))
        htblW (by unfold cfgTailOff; omega) (by unfold cfgTailOff; omega)
  have hfr09 : RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m₀ m9 := by
    have hge : 3 + 8 * (n : ℤ) = cfgHdrWStride n := rfl
    exact ((((((((rfo_wWrite_scr _ _ _ _ _ _ _ _ m₀ wScr (ep : ℤ)).trans
      (rfo_wWrite_scr _ _ _ _ _ _ _ _ m1 (wScr + 1) tlVal)).trans
      (rfo_wWrite_in _ _ _ _ _ _ _ _ m2 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff cfgHdrWStride; omega))).trans
      (rfo_wWrite_in _ _ _ _ _ _ _ _ m3 _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff cfgHdrWStride; omega))).trans
      (rfo_wWrite_in _ _ _ _ _ _ _ _ m4 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff cfgHdrWStride; omega))).trans
      (rfo_wWrite_in _ _ _ _ _ _ _ _ m5 _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff cfgHdrWStride; omega))).trans
      (rfo_wWrite_in _ _ _ _ _ _ _ _ m6 _ (by unfold cfgPrevOff; omega) (by unfold cfgPrevOff cfgHdrWStride; omega))).trans
      (rfo_wWrite_in _ _ _ _ _ _ _ _ m7 _ (by unfold cfgNextOff; omega) (by unfold cfgNextOff cfgHdrWStride; omega))).trans
      (rfo_wWrite_in _ _ _ _ _ _ _ _ m8 _ (by unfold cfgTailOff; omega) (by unfold cfgTailOff cfgHdrWStride; omega))
  -- Common mate/inIdx preservation on any `m10` that writes only to `cfgHeadOff` or `cfgNextOff`
  have hfinish : ∀ (m10 : ArithRAMMemory),
      H3a.wRead m10 tblW (cfgEpOff cfgBaseW) = H3a.wRead m9 tblW (cfgEpOff cfgBaseW) →
      (∀ i : ℤ, cfgBaseW + 3 ≤ i → i < cfgBaseW + 3 + 6 * (n : ℤ) →
        H3a.wRead m10 tblW i = H3a.wRead m9 tblW i) →
      IsKeyDLL ((st.matchingList.map MatchingEdge.pair).map Prod.fst ++ [u])
        (H3a.wRead m10 tblW (cfgHeadOff cfgBaseW))
        (H3a.wRead m10 tblW (cfgTailOff cfgBaseW))
        (fun k => H3a.wRead m10 tblW (cfgPrevOff cfgBaseW n k))
        (fun k => H3a.wRead m10 tblW (cfgNextOff cfgBaseW n k)) →
      EncLocalMatching tblW cfgBaseW n st' m10 := by
    intro m10 hep10 hmid10 hdll10
    have hm9_mid : ∀ i : ℤ, cfgBaseW + 3 ≤ i → i < cfgBaseW + 3 + 6 * (n : ℤ) →
        H3a.wRead m9 tblW i = H3a.wRead m6 tblW i := by
      intro i hlo hhi
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff; omega))]
    have hep9 : H3a.wRead m9 tblW (cfgEpOff cfgBaseW) = (ep : ℤ) := by
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgTailOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgNextOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgPrevOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgMateRValOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgMateLValOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgMateLEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      exact hep_r
    have hndL' : ((st'.matchingList.map MatchingEdge.pair).map Prod.fst).Nodup := by
      rw [hpairs', List.map_append, List.map_singleton]
      dsimp only
      rw [List.nodup_append]
      exact ⟨hndL, List.nodup_singleton u, fun a ha b hb heq => hu_not ((List.mem_singleton.mp hb ▸ heq) ▸ ha)⟩
    have hndR' : ((st'.matchingList.map MatchingEdge.pair).map Prod.snd).Nodup := by
      rw [hpairs', List.map_append, List.map_singleton]
      dsimp only
      rw [List.nodup_append]
      exact ⟨hndR, List.nodup_singleton v, fun a ha b hb heq => hv_not ((List.mem_singleton.mp hb ▸ heq) ▸ ha)⟩
    have hpairs_lt' : ∀ xy ∈ st'.matchingList.map MatchingEdge.pair, xy.1 < n ∧ xy.2 < n := by
      rw [hpairs']
      intro xy hxy
      rcases List.mem_append.mp hxy with hm | hm
      · exact hpairs_lt xy hm
      · rw [List.mem_singleton.mp hm]; exact ⟨hu_lt, hv_lt⟩
    refine ⟨ep, hep1, hep10.trans hep9, hndL', hndR', hpairs_lt',
      by rwa [hUL'], by rwa [hUR'],
      by rwa [hpairs', List.map_append, List.map_singleton],
      ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
    · -- `hmL_le`
      intro x hx
      rw [hmid10 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
          hm9_mid _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega)]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateRValOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateLValOff; omega))]
      by_cases hxu : x = u
      · subst hxu; rw [wRead_wWrite_self]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
        exact hmL_le x hx
    · -- `hmL_to`
      intro x hx h
      rw [hmid10 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
          hm9_mid _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateRValOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateLValOff; omega))] at h
      rw [hmid10 _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff; omega),
          hm9_mid _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff; omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateRValOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateREpOff; omega)), hpairs']
      by_cases hxu : x = u
      · subst hxu
        rw [wRead_wWrite_self]
        exact ⟨v, List.mem_append_right _ (List.mem_singleton_self _), rfl⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)] at h
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateLEpOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
        obtain ⟨y, hy, hval⟩ := hmL_to x hx h
        exact ⟨y, List.mem_append_left _ hy, hval⟩
    · -- `hmL_of`
      intro x y hxy
      have hx : x < n := (hpairs_lt' (x, y) hxy).1
      rw [hpairs'] at hxy
      rcases List.mem_append.mp hxy with hm | hm
      · have hxu : x ≠ u := fun heq => hu_not (heq ▸ List.mem_map_of_mem hm)
        constructor
        · rw [hmid10 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
              hm9_mid _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateRValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateREpOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateLValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
          exact (hmL_of x y hm).1
        · rw [hmid10 _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff; omega),
              hm9_mid _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff; omega),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateRValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateREpOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateLEpOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
          exact (hmL_of x y hm).2
      · rcases Prod.mk.inj (List.mem_singleton.mp hm) with ⟨rfl, rfl⟩
        constructor
        · rw [hmid10 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
              hm9_mid _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateRValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateREpOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgMateLValOff; omega)),
              wRead_wWrite_self]
        · rw [hmid10 _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff; omega),
              hm9_mid _ (by unfold cfgMateLValOff; omega) (by unfold cfgMateLValOff; omega),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateRValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgMateREpOff; omega)),
              wRead_wWrite_self]
    · -- `hmR_le`
      intro y hy
      rw [hmid10 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega),
          hm9_mid _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateRValOff; omega))]
      by_cases hyv : y = v
      · subst hyv; rw [wRead_wWrite_self]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateLValOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateLEpOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
        exact hmR_le y hy
    · -- `hmR_to`
      intro y hy h
      rw [hmid10 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega),
          hm9_mid _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateRValOff; omega))] at h
      rw [hmid10 _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff; omega),
          hm9_mid _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff; omega), hpairs']
      by_cases hyv : y = v
      · subst hyv
        rw [wRead_wWrite_self]
        exact ⟨u, List.mem_append_right _ (List.mem_singleton_self _), rfl⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateLValOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateLEpOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)] at h
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateREpOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateLValOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateLEpOff; omega)),
            wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
        obtain ⟨x, hx, hval⟩ := hmR_to y hy h
        exact ⟨x, List.mem_append_left _ hx, hval⟩
    · -- `hmR_of`
      intro x y hxy
      have hy : y < n := (hpairs_lt' (x, y) hxy).2
      rw [hpairs'] at hxy
      rcases List.mem_append.mp hxy with hm | hm
      · have hyv : y ≠ v := fun heq => hv_not (heq ▸ List.mem_map_of_mem hm)
        constructor
        · rw [hmid10 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega),
              hm9_mid _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateRValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateLValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateLEpOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
          exact (hmR_of x y hm).1
        · rw [hmid10 _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff; omega),
              hm9_mid _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff; omega),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateREpOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateLValOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgMateLEpOff; omega)),
              wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
          exact (hmR_of x y hm).2
      · rcases Prod.mk.inj (List.mem_singleton.mp hm) with ⟨rfl, rfl⟩
        constructor
        · rw [hmid10 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega),
              hm9_mid _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega),
              wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgMateRValOff; omega)),
              wRead_wWrite_self]
        · rw [hmid10 _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff; omega),
              hm9_mid _ (by unfold cfgMateRValOff; omega) (by unfold cfgMateRValOff; omega),
              wRead_wWrite_self]
    · -- `hiL`
      intro x hx
      rw [hUL', hmid10 _ (by unfold cfgInIdxLEpOff; omega) (by unfold cfgInIdxLEpOff; omega),
          hm9_mid _ (by unfold cfgInIdxLEpOff; omega) (by unfold cfgInIdxLEpOff; omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff cfgMateRValOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff cfgMateLValOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff cfgMateLEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      exact hiL x hx
    · -- `hiR`
      intro x hx
      rw [hUR', hmid10 _ (by unfold cfgInIdxREpOff; omega) (by unfold cfgInIdxREpOff; omega),
          hm9_mid _ (by unfold cfgInIdxREpOff; omega) (by unfold cfgInIdxREpOff; omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff cfgMateRValOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff cfgMateREpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff cfgMateLValOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff cfgMateLEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      exact hiR x hx
  -- Now branch on `L = []` vs `L ≠ []`
  let L := (st.matchingList.map MatchingEdge.pair).map Prod.fst
  have hL_lt : ∀ k ∈ L, k < n := by
    intro k hk; rcases List.mem_map.mp hk with ⟨xy, hxy, rfl⟩; exact (hpairs_lt xy hxy).1
  by_cases hL_empty : L = []
  · have htl_m1 : tlVal = -1 := (hdll.1 hL_empty).2
    have hc_t : cValAt 0 inp m9 (.intLt (.readHeap scrW (.lit (wScr + 1))) (.lit 0)) = true := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m9 scrW (wScr + 1) < 0) = true
      rw [hscr_tl9, htl_m1]; rfl
    let m10 := H3a.wWrite m9 tblW (cfgHeadOff cfgBaseW) (u : ℤ)
    have hd10 : DetExec inp (.writeWordHeap tblW
        (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 1)) (.readHeap scrW (.lit wU))) m9 m10 30 :=
      DetExecAt.writeWordHeap 0 inp m9 tblW _ _
        (by change H3a.wRead m9 scrW wCfgBaseW + 1 = cfgHeadOff cfgBaseW
            rw [(hscr_keep9 wCfgBaseW hwBW.2).2.2.2.2.2.2.2.2, hbW]; rfl)
        (by change H3a.wRead m9 scrW wU = (u : ℤ); rw [(hscr_keep9 wU hwU.2).2.2.2.2.2.2.2.2, hu_r])
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd_all : DetExec inp (appendEdgeStmt scrW tblW n wCfgBaseW wU wV wScr)
        m₀ m10 appendEdgeCost :=
      (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq (hd8.seq (hd9.seq
        (DetExecAt.ite_true (C_c := 15) hc_t
          (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          hd10)))))))))).mono_cost (by unfold appendEdgeCost; omega)
    have hfp10 : InFootprint TW BW TR BR m10 := by
      unfold cfgHdrWStride at hbaseW
      exact InFootprint.wWrite hfp9 htblW (by unfold cfgHeadOff; omega) (by unfold cfgHeadOff; omega)
    have hfr910 : RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m9 m10 :=
      rfo_wWrite_in _ _ _ _ _ _ _ _ m9 _ (by unfold cfgHeadOff; omega) (by unfold cfgHeadOff cfgHdrWStride; omega)
    have hdll10 : IsKeyDLL (L ++ [u])
        (H3a.wRead m10 tblW (cfgHeadOff cfgBaseW))
        (H3a.wRead m10 tblW (cfgTailOff cfgBaseW))
        (fun k => H3a.wRead m10 tblW (cfgPrevOff cfgBaseW n k))
        (fun k => H3a.wRead m10 tblW (cfgNextOff cfgBaseW n k)) := by
      rw [hL_empty]; simp only [List.nil_append]
      refine IsKeyDLL.congr
        (IsKeyDLL.append_empty
          (prv := fun k => H3a.wRead m10 tblW (cfgPrevOff cfgBaseW n k))
          (nxt := fun k => H3a.wRead m10 tblW (cfgNextOff cfgBaseW n k))
          (by dsimp only
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgHeadOff; omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgTailOff; omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgNextOff; omega)),
                  wRead_wWrite_self, htl_m1])
          (by dsimp only
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgHeadOff; omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgTailOff; omega)),
                  wRead_wWrite_self]))
        (wRead_wWrite_self _ _ _ _)
        (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgHeadOff; omega)), wRead_wWrite_self])
        (fun _ _ => rfl) (fun _ _ => rfl)
    refine ⟨m10, hd_all, hfp10, hfinish m10
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgHeadOff; omega)))
      (fun i hlo _ => wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff; omega)))
      hdll10,
      fun w hw => (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans (hscr_keep9 w hw).2.2.2.2.2.2.2.2,
      hfr09.trans hfr910⟩
  · have hpos : 0 < L.length := List.length_pos_iff.mpr hL_empty
    obtain ⟨hhd0, htl0, _⟩ := hdll.2 hL_empty
    let t_nat := L[L.length - 1]'(Nat.sub_lt hpos Nat.one_pos)
    have ht_lt : t_nat < n := hL_lt t_nat (List.getElem_mem _)
    have htl_eq : tlVal = (t_nat : ℤ) := htl0
    have htu_ne : t_nat ≠ u := fun heq => hu_not (heq ▸ List.getElem_mem _)
    have hc_f : cValAt 0 inp m9 (.intLt (.readHeap scrW (.lit (wScr + 1))) (.lit 0)) = false := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m9 scrW (wScr + 1) < 0) = false
      rw [hscr_tl9, htl_eq]; exact decide_eq_false (by omega)
    let m10 := H3a.wWrite m9 tblW (cfgNextOff cfgBaseW n t_nat) (u : ℤ)
    have hd10 : DetExec inp (.writeWordHeap tblW
        (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 7 * (n : ℤ))))
              (.readHeap scrW (.lit (wScr + 1))))
        (.readHeap scrW (.lit wU))) m9 m10 35 :=
      DetExecAt.writeWordHeap 0 inp m9 tblW _ _
        (by change (H3a.wRead m9 scrW wCfgBaseW + (3 + 7 * (n : ℤ))) + H3a.wRead m9 scrW (wScr + 1) =
              cfgNextOff cfgBaseW n t_nat
            rw [(hscr_keep9 wCfgBaseW hwBW.2).2.2.2.2.2.2.2.2, hbW, hscr_tl9, htl_eq]
            unfold cfgNextOff; ring)
        (by change H3a.wRead m9 scrW wU = (u : ℤ); rw [(hscr_keep9 wU hwU.2).2.2.2.2.2.2.2.2, hu_r])
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd_all : DetExec inp (appendEdgeStmt scrW tblW n wCfgBaseW wU wV wScr)
        m₀ m10 appendEdgeCost :=
      (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq (hd8.seq (hd9.seq
        (DetExecAt.ite_false (C_c := 15) hc_f
          (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          hd10)))))))))).mono_cost (by unfold appendEdgeCost; omega)
    have hfp10 : InFootprint TW BW TR BR m10 := by
      unfold cfgHdrWStride at hbaseW
      exact InFootprint.wWrite hfp9 htblW (by unfold cfgNextOff; omega) (by unfold cfgNextOff; omega)
    have hfr910 : RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m9 m10 :=
      rfo_wWrite_in _ _ _ _ _ _ _ _ m9 _ (by unfold cfgNextOff; omega) (by unfold cfgNextOff cfgHdrWStride; omega)
    have hdll10 : IsKeyDLL (L ++ [u])
        (H3a.wRead m10 tblW (cfgHeadOff cfgBaseW))
        (H3a.wRead m10 tblW (cfgTailOff cfgBaseW))
        (fun k => H3a.wRead m10 tblW (cfgPrevOff cfgBaseW n k))
        (fun k => H3a.wRead m10 tblW (cfgNextOff cfgBaseW n k)) := by
      refine IsKeyDLL.congr
        (hdll.append_nonempty hndL hL_empty hu_not
          (prv' := fun k => H3a.wRead m10 tblW (cfgPrevOff cfgBaseW n k))
          (nxt' := fun k => H3a.wRead m10 tblW (cfgNextOff cfgBaseW n k))
          (by dsimp only
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgNextOff; omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgTailOff; omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgNextOff; omega)),
                  wRead_wWrite_self])
          (fun k hk => by
            dsimp only
            have hk_lt := hL_lt k hk
            have hku : k ≠ u := fun heq => hu_not (heq ▸ hk)
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgNextOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgTailOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgNextOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgMateRValOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgMateREpOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgMateLValOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgMateLEpOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
          (by dsimp only
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff; omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgTailOff; omega)),
                  wRead_wWrite_self])
          (fun t' ht' => by
            dsimp only
            have hteq : t' = t_nat := Int.ofNat.inj (ht'.symm.trans htl_eq)
            subst hteq; exact wRead_wWrite_self _ _ _ _)
          (fun k hk hne_tl => by
            dsimp only
            have hk_lt := hL_lt k hk
            have hkt : k ≠ t_nat := fun heq => hne_tl (heq ▸ htl_eq.symm)
            have hku : k ≠ u := fun heq => hu_not (heq ▸ hk)
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgTailOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgPrevOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgMateRValOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgMateREpOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgMateLValOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgMateLEpOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]))
        (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgNextOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgTailOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgNextOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgPrevOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgMateRValOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgMateREpOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgMateLValOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgMateLEpOff; omega)),
                wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
        (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgNextOff; omega)),
                wRead_wWrite_self])
        (fun _ _ => rfl) (fun _ _ => rfl)
    refine ⟨m10, hd_all, hfp10, hfinish m10
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgNextOff; omega)))
      (fun i _ hhi => wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff; omega)))
      hdll10,
      fun w hw => (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans (hscr_keep9 w hw).2.2.2.2.2.2.2.2,
      hfr09.trans hfr910⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
