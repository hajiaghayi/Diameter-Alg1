import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeB0b

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

def managedNodeOpenEmptyWScr {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℤ :=
  4 + ops.opWScrStride

def managedNodeOpenEmptyRScr {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℤ :=
  1 + ops.opRScrStride

def managedNodeOpenEmptyCost {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) (N_cfg : ℕ) : ℕ :=
  400 + 55 * d + N_cfg * (ops.clearCost + 40)

def managedNodeOpenEmptyStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (wNodeBaseW wNodeBaseR wBirthSz rInO wScr rScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wNodeBaseW)
  let bRE := IntExpr.readHeap scrW (.lit wNodeBaseR)
  let wTmp := wScr
  let wCfgBW := wScr + 2
  let wCfgBR := wScr + 3
  let wOpScr := wScr + 4
  let histOffVal : ℤ := 8 + 2 * swapPoolStride n
  let radWOffVal : ℤ := histOffVal + (1 + (cap_hist : ℤ))
  let cfgsWOffVal : ℤ := radWOffVal + radTreeWStride K_seg
  let cfgsROffVal : ℤ := (d : ℤ) + 2 + radTreeRStride K_seg
  .seq (openNodeWriteCenterVarStmt scrW scrR tblR wNodeBaseR rInO wTmp rScr d)
  (.seq (.writeWordHeap tblW bWE (.readHeap scrW (.lit wBirthSz)))
  (.seq (.writeWordHeap tblW (.add bWE (.lit 1)) (.lit 0))
  (.seq (.writeWordHeap tblW (.add bWE (.lit 2)) (.lit 0))
  (.seq (.writeWordHeap tblW (.add bWE (.lit 3)) (.lit 0))
  (.seq (.writeWordHeap tblW (.add bWE (.lit 4)) (.lit 0))
  (.seq (.writeWordHeap tblW (.add bWE (.lit histOffVal)) (.lit 0))
  (.seq (.writeWordHeap scrW (.lit wTmp) (.add bWE (.lit 8)))
  (.seq (swapPoolBumpClearStmt scrW tblW wTmp)
  (.seq (.writeWordHeap scrW (.lit wTmp) (.add bWE (.lit (8 + swapPoolStride n))))
  (.seq (swapPoolBumpClearStmt scrW tblW wTmp)
  (.seq (.writeWordHeap scrW (.lit wTmp) (.add bWE (.lit radWOffVal)))
  (.seq (radTreeBumpClearStmt scrW tblW wTmp)
        (seqFinCfgStmt N_cfg (fun i =>
          .seq (.writeWordHeap scrW (.lit wCfgBW)
                  (.add bWE (.lit (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride))))
          (.seq (.writeWordHeap scrW (.lit wCfgBR)
                  (.add bRE (.lit (cfgsROffVal + (i.val : ℤ) * ops.cfgRStride))))
                (ops.clearStmt (specs i) wCfgBW wCfgBR wOpScr (rScr + 1)))))))))))))))))

theorem zeroRand_managedNodeOpenEmptyStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (wNodeBaseW wNodeBaseR wBirthSz rInO wScr rScr : ℤ) :
    ZeroRandStmt (managedNodeOpenEmptyStmt ops specs cap_hist K_seg
      wNodeBaseW wNodeBaseR wBirthSz rInO wScr rScr) := by
  unfold managedNodeOpenEmptyStmt
  refine .seq (hzr_to_zeroRand (hzr_openNodeWriteCenterVarStmt _ _ _ _ _ _ _ _))
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (hzr_to_zeroRand (hzr_swapPoolBumpClearStmt _ _ _))
    (.seq (.writeWordHeap _ _ _) (.seq (hzr_to_zeroRand (hzr_swapPoolBumpClearStmt _ _ _))
    (.seq (.writeWordHeap _ _ _) (.seq (hzr_to_zeroRand (hzr_radTreeBumpClearStmt _ _ _))
          (zeroRand_seqFinCfgStmt N_cfg _ (fun i =>
            .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
                  (ops.zeroRand_clearStmt _ _ _ _ _))))))))))))))))

theorem exec_managedNodeOpenEmptyStmt
    {d TW BW TR BR n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wNodeBaseW wNodeBaseR wBirthSz rInO wScr rScr nodeBaseW nodeBaseR : ℤ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (P₀ : Finset ℕ) (m₀_sz : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbls : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ nodeBaseW ∧
      nodeBaseW + managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride ≤ (BW : ℤ))
    (hbaseR : 0 ≤ nodeBaseR ∧
      nodeBaseR + managedNodeRStride d K_seg N_cfg ops.cfgRStride ≤ (BR : ℤ))
    (hwBW : 0 ≤ wNodeBaseW ∧ wNodeBaseW < wScr)
    (hwBR : 0 ≤ wNodeBaseR ∧ wNodeBaseR < wScr)
    (hwBS : 0 ≤ wBirthSz ∧ wBirthSz < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + managedNodeOpenEmptyWScr ops ≤ (BW : ℤ))
    (hrInO : 0 ≤ rInO ∧ rInO + (d : ℤ) + 1 ≤ rScr)
    (hrScr : 0 ≤ rScr ∧ rScr + managedNodeOpenEmptyRScr ops ≤ (BR : ℤ))
    (hbW : H3a.wRead m₀ scrW wNodeBaseW = nodeBaseW)
    (hbR : H3a.wRead m₀ scrW wNodeBaseR = nodeBaseR)
    (hbsz : H3a.wRead m₀ scrW wBirthSz = (m₀_sz : ℤ))
    (ho_in : ∀ c : Fin d, H3a.rRead m₀ scrR (rInO + (c.val : ℤ)) = euclideanCoord o c)
    (hs_in : H3a.rRead m₀ scrR (rInO + (d : ℤ)) = s)
    (hrdy : ManagedNodeSlotReady ops specs cap_hist K_seg nodeBaseW nodeBaseR m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (managedNodeOpenEmptyStmt ops specs cap_hist K_seg
        wNodeBaseW wNodeBaseR wBirthSz rInO wScr rScr)
        m₀ m₁ (managedNodeOpenEmptyCost ops N_cfg) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts
        (ManagedNode.openEmpty L_p2 R ℓ M₀ d b N_cfg T_cdf p_coord o s P₀ m₀_sz) none m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW nodeBaseW
        (managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride)
        tblR nodeBaseR (managedNodeRStride d K_seg N_cfg ops.cfgRStride) m₀ m₁ := by
  have hcfgW := ops.hcfgW_nonneg
  have hcfgR := ops.hcfgR_nonneg
  have hw_op := ops.hopWScr_pos
  have hr_op := ops.hopRScr_pos
  have hw21 := managedNodeWStride_ge_header n cap_hist K_seg N_cfg hcfgW
  have hrd2 := managedNodeRStride_ge_header d K_seg N_cfg hcfgR
  have hrad4 := radTreeWStride_ge_four K_seg
  have hradR := radTreeRStride_nonneg K_seg
  have hncfgW : 0 ≤ (N_cfg : ℤ) * ops.cfgWStride := mul_nonneg (Nat.cast_nonneg _) hcfgW
  have hncfgR : 0 ≤ (N_cfg : ℤ) * ops.cfgRStride := mul_nonneg (Nat.cast_nonneg _) hcfgR
  let W_tot := managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride
  let R_tot := managedNodeRStride d K_seg N_cfg ops.cfgRStride
  unfold managedNodeOpenEmptyWScr at hwScr
  unfold managedNodeOpenEmptyRScr at hrScr
  have hneW := htbls.2.2.2.2.2.2.1
  have hneR := htbls.2.2.2.2.2.2.2.2.2.1
  -- Step 1: Center & variance write
  obtain ⟨m1, hd1, hfp1, ho1, hs1, hV1, hw1, hfr1_sub⟩ :=
    exec_openNodeWriteCenterVarStmt (tblW := tblW) inp wNodeBaseR rInO wScr rScr nodeBaseR R_tot o s
      hfp₀ htbls.1 htbls.2.2.2.1 htbls.2.2.2.2.1 hneR hbaseR hrd2 hwBR ⟨hwScr.1, by omega⟩ hrInO
      ⟨hrScr.1, by omega⟩ hbR ho_in hs_in
  have hfr1 : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m₀ m1 :=
    RadFrameOutside_mono_range hfr1_sub (Or.inl rfl) (Or.inr ⟨le_rfl, by omega⟩)
  have hrdy1 : ManagedNodeSlotReady ops specs cap_hist K_seg nodeBaseW nodeBaseR m1 :=
    ⟨hrdy.1.mono_slice (fun i _ _ => hfr1_sub.1 tblW i hneW (Or.inr (by omega))),
     hrdy.2.1.mono_slice (fun i _ _ => hfr1_sub.1 tblW i hneW (Or.inr (by omega))),
     hrdy.2.2.1.mono_slice (fun i _ _ => hfr1_sub.1 tblW i hneW (Or.inr (by omega))),
     fun idx => ops.cfgReady_mono_slice (specs idx) _ _ m₀ m1 (hrdy.2.2.2 idx)
       (fun i _ _ => hfr1_sub.1 tblW i hneW (Or.inr (by omega)))
       (fun i hlo _ => by
         have hb := nodeCfgROff_bounds d K_seg hcfgR nodeBaseR idx
         exact hfr1_sub.2 tblR i hneR (Or.inr (Or.inr (by unfold nodeCfgsRBase nodeRadTreeROff at *; omega))))⟩
  have hbW1 : H3a.wRead m1 scrW wNodeBaseW = nodeBaseW := (hw1 wNodeBaseW hwBW.2).trans hbW
  have hbR1 : H3a.wRead m1 scrW wNodeBaseR = nodeBaseR := (hw1 wNodeBaseR hwBR.2).trans hbR
  have hbsz1 : H3a.wRead m1 scrW wBirthSz = (m₀_sz : ℤ) := (hw1 wBirthSz hwBS.2).trans hbsz
  -- Step 2: 6 header + histLen writes into tblW
  let histOffVal : ℤ := 8 + 2 * swapPoolStride n
  let m2a := H3a.wWrite m1 tblW nodeBaseW (m₀_sz : ℤ)
  let m2b := H3a.wWrite m2a tblW (nodeBaseW + 1) 0
  let m2c := H3a.wWrite m2b tblW (nodeBaseW + 2) 0
  let m2d := H3a.wWrite m2c tblW (nodeBaseW + 3) 0
  let m2e := H3a.wWrite m2d tblW (nodeBaseW + 4) 0
  let m2 := H3a.wWrite m2e tblW (nodeBaseW + histOffVal) 0
  have hscr_wWrite : ∀ (m : ArithRAMMemory) (idx v : ℤ) (w : ℤ),
      H3a.wRead (H3a.wWrite m tblW idx v) scrW w = H3a.wRead m scrW w :=
    fun m _ _ _ => wRead_wWrite_of_ne m _ (Or.inl hneW.symm)
  have hd2a : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wNodeBaseW))
      (.readHeap scrW (.lit wBirthSz))) m1 m2a 15 :=
    DetExecAt.writeWordHeap 0 inp m1 tblW _ _ hbW1 hbsz1 (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2b : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit 1)) (.lit 0)) m2a m2b 15 :=
    DetExecAt.writeWordHeap 0 inp m2a tblW _ _ (by change H3a.wRead m2a scrW wNodeBaseW + 1 = _; rw [hscr_wWrite, hbW1]) rfl
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2c : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit 2)) (.lit 0)) m2b m2c 15 :=
    DetExecAt.writeWordHeap 0 inp m2b tblW _ _ (by change H3a.wRead m2b scrW wNodeBaseW + 2 = _; rw [hscr_wWrite, hscr_wWrite, hbW1]) rfl
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2d : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit 3)) (.lit 0)) m2c m2d 15 :=
    DetExecAt.writeWordHeap 0 inp m2c tblW _ _ (by change H3a.wRead m2c scrW wNodeBaseW + 3 = _; simp only [m2c, m2b, m2a, hscr_wWrite, hbW1]) rfl
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2e : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit 4)) (.lit 0)) m2d m2e 15 :=
    DetExecAt.writeWordHeap 0 inp m2d tblW _ _ (by change H3a.wRead m2d scrW wNodeBaseW + 4 = _; simp only [m2d, m2c, m2b, m2a, hscr_wWrite, hbW1]) rfl
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2f : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit histOffVal)) (.lit 0)) m2e m2 15 :=
    DetExecAt.writeWordHeap 0 inp m2e tblW _ _ (by change H3a.wRead m2e scrW wNodeBaseW + histOffVal = _; simp only [m2e, m2d, m2c, m2b, m2a, hscr_wWrite, hbW1]) rfl
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hhist_lt : histOffVal < W_tot := by
    dsimp [histOffVal, W_tot]; unfold managedNodeWStride swapPoolStride; omega
  have hhist_ge : 8 ≤ histOffVal := by dsimp [histOffVal]; unfold swapPoolStride; omega
  have hfp2 : InFootprint TW BW TR BR m2 := by
    refine InFootprint.wWrite ?_ htbls.2.1 (by omega) (by omega)
    refine InFootprint.wWrite ?_ htbls.2.1 (by omega) (by omega)
    refine InFootprint.wWrite ?_ htbls.2.1 (by omega) (by omega)
    refine InFootprint.wWrite ?_ htbls.2.1 (by omega) (by omega)
    refine InFootprint.wWrite ?_ htbls.2.1 (by omega) (by omega)
    exact InFootprint.wWrite hfp1 htbls.2.1 (by omega) (by omega)
  have hm2_keepW : ∀ (t : ℕ) (i : ℤ),
      (t ≠ tblW ∨ (i ≠ nodeBaseW ∧ i ≠ nodeBaseW + 1 ∧ i ≠ nodeBaseW + 2 ∧
        i ≠ nodeBaseW + 3 ∧ i ≠ nodeBaseW + 4 ∧ i ≠ nodeBaseW + histOffVal)) →
      H3a.wRead m2 t i = H3a.wRead m1 t i := by
    intro t i hcond
    dsimp [m2, m2e, m2d, m2c, m2b, m2a]
    rcases hcond with ht | ⟨h0, h1, h2, h3, h4, hh⟩
    · repeat rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
    · rw [wRead_wWrite_of_ne _ _ (Or.inr hh), wRead_wWrite_of_ne _ _ (Or.inr h4),
          wRead_wWrite_of_ne _ _ (Or.inr h3), wRead_wWrite_of_ne _ _ (Or.inr h2),
          wRead_wWrite_of_ne _ _ (Or.inr h1), wRead_wWrite_of_ne _ _ (Or.inr h0)]
  have hm2_keepR : ∀ t i, H3a.rRead m2 t i = H3a.rRead m1 t i := fun _ _ => rfl
  have hfr2 : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m1 m2 := by
    refine ⟨fun t i _ hout => hm2_keepW t i ?_, fun _ _ _ _ => rfl⟩
    rcases hout with ht | hlt | hge
    · exact Or.inl ht
    · exact Or.inr ⟨by omega, by omega, by omega, by omega, by omega, by omega⟩
    · exact Or.inr ⟨by omega, by omega, by omega, by omega, by omega, by omega⟩
  have hbW2 : H3a.wRead m2 scrW wNodeBaseW = nodeBaseR - nodeBaseR + nodeBaseW := by
    rw [hm2_keepW scrW wNodeBaseW (Or.inl hneW.symm), hbW1]; ring
  have hbW2' : H3a.wRead m2 scrW wNodeBaseW = nodeBaseW := by linarith
  have hbR2 : H3a.wRead m2 scrW wNodeBaseR = nodeBaseR := by
    rw [hm2_keepW scrW wNodeBaseR (Or.inl hneW.symm), hbR1]
  -- Step 3: Bump-clear densePool, resPool, radTree
  let m3a := H3a.wWrite m2 scrW wScr (nodeDensePoolOff nodeBaseW)
  have hd3a : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit 8))) m2 m3a 15 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW _ _ rfl
      (by change H3a.wRead m2 scrW wNodeBaseW + 8 = nodeDensePoolOff nodeBaseW; rw [hbW2']; rfl)
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp3a : InFootprint TW BW TR BR m3a := InFootprint.wWrite hfp2 htbls.1 hwScr.1 (by omega)
  have hrdy_dense : SwapPoolReady tblW (nodeDensePoolOff nodeBaseW) n m3a :=
    hrdy1.1.mono_slice (fun i hlo hhi => by
      dsimp [m3a]; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      exact hm2_keepW tblW i (Or.inr (by
        unfold nodeDensePoolOff at hlo hhi; unfold swapPoolStride at hhi; dsimp [histOffVal]; unfold swapPoolStride; omega)))
  obtain ⟨Pd', m3b, hd3b, hfp3b, hPd'_wf, hPd'_l, hPd'_e, hw3b, _, hfr3b⟩ :=
    exec_swapPoolBumpClearStmt (scrR := scrR) (tblR := tblR) inp wScr (nodeDensePoolOff nodeBaseW) n
      hfp3a htbls.2.1 hneW
      ⟨by unfold nodeDensePoolOff; omega, by unfold nodeDensePoolOff; unfold managedNodeWStride swapPoolStride at *; omega⟩
      (wRead_wWrite_self _ _ _ _) hrdy_dense
  have hbW3b : H3a.wRead m3b scrW wNodeBaseW = nodeBaseW := by
    rw [hw3b, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbW2']
  let m4a := H3a.wWrite m3b scrW wScr (nodeResPoolOff n nodeBaseW)
  have hd4a : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (8 + swapPoolStride n)))) m3b m4a 15 :=
    DetExecAt.writeWordHeap 0 inp m3b scrW _ _ rfl
      (by change H3a.wRead m3b scrW wNodeBaseW + (8 + swapPoolStride n) = nodeResPoolOff n nodeBaseW
          rw [hbW3b]; unfold nodeResPoolOff; ring)
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp4a : InFootprint TW BW TR BR m4a := InFootprint.wWrite hfp3b htbls.1 hwScr.1 (by omega)
  have hrdy_res : SwapPoolReady tblW (nodeResPoolOff n nodeBaseW) n m4a :=
    hrdy1.2.1.mono_slice (fun i hlo hhi => by
      dsimp [m4a]; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
        hfr3b.1 tblW i hneW (Or.inr (Or.inr (by unfold nodeResPoolOff nodeDensePoolOff at *; omega))),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      exact hm2_keepW tblW i (Or.inr (by
        unfold nodeResPoolOff swapPoolStride at hlo hhi; dsimp [histOffVal]; unfold swapPoolStride; omega)))
  obtain ⟨Pr', m4b, hd4b, hfp4b, hPr'_wf, hPr'_l, hPr'_e, hw4b, hr4b, hfr4b⟩ :=
    exec_swapPoolBumpClearStmt (scrR := scrR) (tblR := tblR) inp wScr (nodeResPoolOff n nodeBaseW) n
      hfp4a htbls.2.1 hneW
      ⟨by unfold nodeResPoolOff swapPoolStride; omega, by unfold nodeResPoolOff; unfold managedNodeWStride swapPoolStride at *; omega⟩
      (wRead_wWrite_self _ _ _ _) hrdy_res
  have hbW4b : H3a.wRead m4b scrW wNodeBaseW = nodeBaseW := by
    rw [hw4b, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbW3b]
  let radWOffVal : ℤ := histOffVal + (1 + (cap_hist : ℤ))
  let m5a := H3a.wWrite m4b scrW wScr (nodeRadTreeWOff n cap_hist nodeBaseW)
  have hd5a : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit radWOffVal))) m4b m5a 15 :=
    DetExecAt.writeWordHeap 0 inp m4b scrW _ _ rfl
      (by change H3a.wRead m4b scrW wNodeBaseW + radWOffVal = nodeRadTreeWOff n cap_hist nodeBaseW
          rw [hbW4b]; unfold nodeRadTreeWOff nodeHistOff; dsimp [radWOffVal, histOffVal]; ring)
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp5a : InFootprint TW BW TR BR m5a := InFootprint.wWrite hfp4b htbls.1 hwScr.1 (by omega)
  have hrdy_rad : RadTreeReady tblW (nodeRadTreeWOff n cap_hist nodeBaseW) K_seg m5a :=
    hrdy1.2.2.1.mono_slice (fun i hlo hhi => by
      dsimp [m5a]; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
        hfr4b.1 tblW i hneW (Or.inr (Or.inr (by unfold nodeRadTreeWOff nodeHistOff nodeResPoolOff swapPoolStride at *; omega))),
        wRead_wWrite_of_ne _ _ (Or.inl hneW),
        hfr3b.1 tblW i hneW (Or.inr (Or.inr (by unfold nodeRadTreeWOff nodeHistOff nodeDensePoolOff swapPoolStride at *; omega))),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      exact hm2_keepW tblW i (Or.inr (by
        unfold nodeRadTreeWOff nodeHistOff swapPoolStride at hlo hhi; dsimp [histOffVal]; unfold swapPoolStride; omega)))
  obtain ⟨Tr', m5b, hd5b, hfp5b, hTr'_wf, hTr'_e, hw5b, hr5b, hfr5b⟩ :=
    exec_radTreeBumpClearStmt (scrR := scrR) inp wScr
      (nodeRadTreeWOff n cap_hist nodeBaseW) (nodeRadTreeROff d nodeBaseR) K_seg pts o
      hfp5a htbls.2.1 hneW
      ⟨by unfold nodeRadTreeWOff nodeHistOff swapPoolStride; omega,
       by unfold nodeRadTreeWOff nodeHistOff; unfold managedNodeWStride swapPoolStride at *; omega⟩
      (wRead_wWrite_self _ _ _ _) hrdy_rad
  -- Consolidate m2 -> m5b invariants
  have hw2_5b : ∀ w, w < wScr → H3a.wRead m5b scrW w = H3a.wRead m2 scrW w := by
    intro w hw
    rw [hw5b, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw4b,
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw3b,
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  have hfr2_5b : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m2 m5b := by
    have hf3a : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m2 m3a :=
      ⟨fun t i hs _ => wRead_wWrite_of_ne _ _ (Or.inl hs), fun _ _ _ _ => rfl⟩
    have hf3b : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m3a m3b :=
      RadFrameOutside_mono_range hfr3b (Or.inr ⟨by unfold nodeDensePoolOff; omega,
        by unfold nodeDensePoolOff; dsimp [W_tot]; unfold managedNodeWStride swapPoolStride; omega⟩) (Or.inl rfl)
    have hf4a : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m3b m4a :=
      ⟨fun t i hs _ => wRead_wWrite_of_ne _ _ (Or.inl hs), fun _ _ _ _ => rfl⟩
    have hf4b : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m4a m4b :=
      RadFrameOutside_mono_range hfr4b (Or.inr ⟨by unfold nodeResPoolOff swapPoolStride; omega,
        by unfold nodeResPoolOff; dsimp [W_tot]; unfold managedNodeWStride swapPoolStride; omega⟩) (Or.inl rfl)
    have hf5a : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m4b m5a :=
      ⟨fun t i hs _ => wRead_wWrite_of_ne _ _ (Or.inl hs), fun _ _ _ _ => rfl⟩
    have hf5b : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m5a m5b :=
      RadFrameOutside_mono_range hfr5b (Or.inr ⟨by unfold nodeRadTreeWOff nodeHistOff swapPoolStride; omega,
        by unfold nodeRadTreeWOff nodeHistOff; dsimp [W_tot]; unfold managedNodeWStride swapPoolStride; omega⟩) (Or.inl rfl)
    exact ((((hf3a.trans hf3b).trans hf4a).trans hf4b).trans hf5a).trans hf5b
  have hkeep_hdr_m5b : ∀ i : ℤ,
      (i < nodeDensePoolOff nodeBaseW ∨ i = nodeHistOff n nodeBaseW ∨ nodeCfgsWBase n cap_hist K_seg nodeBaseW ≤ i) →
      H3a.wRead m5b tblW i = H3a.wRead m2 tblW i := by
    intro i hi
    rw [hfr5b.1 tblW i hneW (Or.inr (by
          rcases hi with h1 | rfl | h3
          · exact Or.inl (by unfold nodeRadTreeWOff nodeHistOff nodeDensePoolOff swapPoolStride at *; omega)
          · exact Or.inl (by unfold nodeRadTreeWOff nodeHistOff; omega)
          · exact Or.inr (by unfold nodeCfgsWBase at h3; exact h3))),
        wRead_wWrite_of_ne _ _ (Or.inl hneW),
        hfr4b.1 tblW i hneW (Or.inr (by
          rcases hi with h1 | rfl | h3
          · exact Or.inl (by unfold nodeResPoolOff nodeDensePoolOff swapPoolStride at *; omega)
          · exact Or.inr (by unfold nodeHistOff nodeResPoolOff; omega)
          · exact Or.inr (by unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff nodeResPoolOff swapPoolStride at *; omega))),
        wRead_wWrite_of_ne _ _ (Or.inl hneW),
        hfr3b.1 tblW i hneW (Or.inr (by
          rcases hi with h1 | rfl | h3
          · exact Or.inl h1
          · exact Or.inr (by unfold nodeHistOff nodeDensePoolOff swapPoolStride; omega)
          · exact Or.inr (by unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff nodeDensePoolOff swapPoolStride at *; omega))),
        wRead_wWrite_of_ne _ _ (Or.inl hneW)]
  have hkeep_R_m5b : ∀ i : ℤ, H3a.rRead m5b tblR i = H3a.rRead m1 tblR i := by
    intro i
    rw [hfr5b.2 tblR i hneR (Or.inr (by omega)), rRead_wWrite,
        hfr4b.2 tblR i hneR (Or.inr (by omega)), rRead_wWrite,
        hfr3b.2 tblR i hneR (Or.inr (by omega)), rRead_wWrite]
    rfl
  have hPd'_m5b : EncSwapPool tblW (nodeDensePoolOff nodeBaseW) n Pd' m5b := by
    have h1 := hPd'_e.mono_frame (WordFrameOutside.wWrite_scr scrW tblW (nodeDensePoolOff nodeBaseW) 0 m3b wScr (nodeResPoolOff n nodeBaseW)) hneW (Or.inr (Or.inr (by omega))) hPd'_wf.2.2.2.1
    have h2 : WordFrameOutside scrW tblW (nodeResPoolOff n nodeBaseW) (swapPoolStride n) m4a m4b :=
      ⟨hfr4b.1, fun t i => by
        by_cases hs : t = scrR
        · subst hs; exact hr4b i
        · exact hfr4b.2 t i hs (Or.inr (by omega))⟩
    have h3 := h1.mono_frame h2 hneW (Or.inr (Or.inl (by unfold nodeDensePoolOff nodeResPoolOff; omega))) hPd'_wf.2.2.2.1
    have h4 := h3.mono_frame (WordFrameOutside.wWrite_scr scrW tblW (nodeDensePoolOff nodeBaseW) 0 m4b wScr (nodeRadTreeWOff n cap_hist nodeBaseW)) hneW (Or.inr (Or.inr (by omega))) hPd'_wf.2.2.2.1
    have h5 : WordFrameOutside scrW tblW (nodeRadTreeWOff n cap_hist nodeBaseW) (radTreeWStride K_seg) m5a m5b :=
      ⟨hfr5b.1, fun t i => by
        by_cases hs : t = scrR
        · subst hs; exact hr5b i
        · exact hfr5b.2 t i hs (Or.inr (by omega))⟩
    exact h4.mono_frame h5 hneW (Or.inr (Or.inl (by unfold nodeDensePoolOff nodeRadTreeWOff nodeHistOff swapPoolStride; omega))) hPd'_wf.2.2.2.1
  have hPr'_m5b : EncSwapPool tblW (nodeResPoolOff n nodeBaseW) n Pr' m5b := by
    have h1 := hPr'_e.mono_frame (WordFrameOutside.wWrite_scr scrW tblW (nodeResPoolOff n nodeBaseW) 0 m4b wScr (nodeRadTreeWOff n cap_hist nodeBaseW)) hneW (Or.inr (Or.inr (by omega))) hPr'_wf.2.2.2.1
    have h2 : WordFrameOutside scrW tblW (nodeRadTreeWOff n cap_hist nodeBaseW) (radTreeWStride K_seg) m5a m5b :=
      ⟨hfr5b.1, fun t i => by
        by_cases hs : t = scrR
        · subst hs; exact hr5b i
        · exact hfr5b.2 t i hs (Or.inr (by omega))⟩
    exact h1.mono_frame h2 hneW (Or.inr (Or.inl (by unfold nodeResPoolOff nodeRadTreeWOff nodeHistOff swapPoolStride; omega))) hPr'_wf.2.2.2.1
  -- Step 4: Loop `ops.clearStmt` across `i : Fin N_cfg`
  let V_val := max 0 (liftVariance o s)
  let cfgsWOffVal : ℤ := radWOffVal + radTreeWStride K_seg
  let cfgsROffVal : ℤ := (d : ℤ) + 2 + radTreeRStride K_seg
  let CfgLoopInv : ℕ → ArithRAMMemory → Prop := fun k m =>
    (∀ i : ℤ, i < nodeCfgsWBase n cap_hist K_seg nodeBaseW → H3a.wRead m tblW i = H3a.wRead m5b tblW i) ∧
    (∀ i : ℤ, i < nodeCfgsRBase d K_seg nodeBaseR → H3a.rRead m tblR i = H3a.rRead m5b tblR i) ∧
    (∀ idx : Fin N_cfg, idx.val < k →
      ops.EncCfg (specs idx)
        (nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW idx.val)
        (nodeCfgROff d K_seg ops.cfgRStride nodeBaseR idx.val)
        pts o V_val ∅ (ConfigDynamicState.empty L_p2 R ℓ M₀ d b T_cdf p_coord) m) ∧
    (∀ idx : Fin N_cfg, k ≤ idx.val →
      ops.CfgReady (specs idx)
        (nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW idx.val)
        (nodeCfgROff d K_seg ops.cfgRStride nodeBaseR idx.val) m)
  have hInv0 : CfgLoopInv 0 m5b := by
    refine ⟨fun _ _ => rfl, fun _ _ => rfl, fun _ h => absurd h (Nat.not_lt_zero _), fun idx _ => ?_⟩
    have hbW_i := nodeCfgWOff_bounds n cap_hist K_seg hcfgW nodeBaseW idx
    have hbR_i := nodeCfgROff_bounds d K_seg hcfgR nodeBaseR idx
    exact ops.cfgReady_mono_slice (specs idx) _ _ m1 m5b (hrdy1.2.2.2 idx)
      (fun j hj1 _ => (hkeep_hdr_m5b j (Or.inr (Or.inr (by omega)))).trans
        (hm2_keepW tblW j (Or.inr (by
          unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride at *; dsimp [histOffVal]; unfold swapPoolStride; omega))))
      (fun j _ _ => hkeep_R_m5b j)
  obtain ⟨m6, hd6, hfp6, ⟨hpreW6, hpreR6, hcfgs6, _⟩, hw6, hfr6⟩ :=
    exec_seqFinCfgStmt inp
      (fun i : Fin N_cfg =>
        .seq (.writeWordHeap scrW (.lit (wScr + 2))
                (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride))))
        (.seq (.writeWordHeap scrW (.lit (wScr + 3))
                (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit (cfgsROffVal + (i.val : ℤ) * ops.cfgRStride))))
              (ops.clearStmt (specs i) (wScr + 2) (wScr + 3) (wScr + 4) (rScr + 1))))
      CfgLoopInv wScr nodeBaseW W_tot nodeBaseR R_tot (ops.clearCost + 40)
      hfp5b hInv0
      (fun i m hfpm ⟨hpreWm, hpreRm, henc_lt, hrdy_ge⟩ hwm hfrm => by
        have hbW_m : H3a.wRead m scrW wNodeBaseW = nodeBaseW :=
          (hwm wNodeBaseW hwBW.2).trans ((hw2_5b wNodeBaseW hwBW.2).trans hbW2')
        have hbR_m : H3a.wRead m scrW wNodeBaseR = nodeBaseR :=
          (hwm wNodeBaseR hwBR.2).trans ((hw2_5b wNodeBaseR hwBR.2).trans hbR2)
        let cBW := nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val
        let cBR := nodeCfgROff d K_seg ops.cfgRStride nodeBaseR i.val
        have hcBW_eq : nodeBaseW + (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride) = cBW := by
          dsimp [cBW, cfgsWOffVal, radWOffVal, histOffVal]
          unfold nodeCfgWOff nodeCfgsWBase nodeRadTreeWOff nodeHistOff; ring
        have hcBR_eq : nodeBaseR + (cfgsROffVal + (i.val : ℤ) * ops.cfgRStride) = cBR := by
          dsimp [cBR, cfgsROffVal]
          unfold nodeCfgROff nodeCfgsRBase nodeRadTreeROff; ring
        let ma := H3a.wWrite m scrW (wScr + 2) cBW
        let mb := H3a.wWrite ma scrW (wScr + 3) cBR
        have hda : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2)) (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride)))) m ma 20 :=
          DetExecAt.writeWordHeap 0 inp m scrW _ _ rfl
            (by change H3a.wRead m scrW wNodeBaseW + _ = cBW; rw [hbW_m, hcBW_eq])
            (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        have hfpa : InFootprint TW BW TR BR ma := InFootprint.wWrite hfpm htbls.1 (by omega) (by omega)
        have hdb : DetExec inp (.writeWordHeap scrW (.lit (wScr + 3)) (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit (cfgsROffVal + (i.val : ℤ) * ops.cfgRStride)))) ma mb 20 :=
          DetExecAt.writeWordHeap 0 inp ma scrW _ _ rfl
            (by change H3a.wRead ma scrW wNodeBaseR + _ = cBR
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR_m, hcBR_eq])
            (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        have hfpb : InFootprint TW BW TR BR mb := InFootprint.wWrite hfpa htbls.1 (by omega) (by omega)
        have hbndW := nodeCfgWOff_bounds n cap_hist K_seg hcfgW nodeBaseW i
        have hbndR := nodeCfgROff_bounds d K_seg hcfgR nodeBaseR i
        have hloW : nodeBaseW ≤ nodeCfgsWBase n cap_hist K_seg nodeBaseW := by
          unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride; omega
        have hloR : nodeBaseR ≤ nodeCfgsRBase d K_seg nodeBaseR := by
          unfold nodeCfgsRBase nodeRadTreeROff; omega
        have hrdy_mb : ops.CfgReady (specs i) cBW cBR mb :=
          ops.cfgReady_mono_slice (specs i) cBW cBR m mb (hrdy_ge i le_rfl)
            (fun j _ _ => by dsimp [mb, ma]; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
            (fun _ _ _ => rfl)
        obtain ⟨mc, hdc, hfpc, henc_c, hw_c, hfr_c⟩ :=
          ops.exec_clearStmt inp (specs i) (wScr + 2) (wScr + 3) (wScr + 4) (rScr + 1) cBW cBR pts o V_val
            hfpb htbls ⟨by dsimp [cBW]; omega, by dsimp [cBW]; omega⟩ ⟨by dsimp [cBR]; omega, by dsimp [cBR]; omega⟩
            ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
            (by dsimp [mb, ma]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
            (wRead_wWrite_self _ _ _ _) hrdy_mb
        have hfr_m_mc : RadFrameOutside scrW scrR tblW cBW ops.cfgWStride tblR cBR ops.cfgRStride m mc :=
          ⟨fun t j hts ho => (hfr_c.1 t j hts ho).trans
            (by dsimp [mb, ma]; rw [wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_wWrite_of_ne _ _ (Or.inl hts)]),
           fun t j hts ho => hfr_c.2 t j hts ho⟩
        have hdisjW : ∀ (idx : Fin N_cfg), idx ≠ i → ∀ j : ℤ,
            nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW idx.val ≤ j →
            j < nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW idx.val + ops.cfgWStride →
            (j < cBW ∨ cBW + ops.cfgWStride ≤ j) := by
          intro idx hne j hj1 hj2
          have hne_v : idx.val ≠ i.val := fun he => hne (Fin.ext he)
          rcases lt_or_gt_of_ne hne_v with hlt | hgt
          · apply Or.inl
            have hm1 : ((idx.val + 1 : ℕ) : ℤ) * ops.cfgWStride ≤ (i.val : ℤ) * ops.cfgWStride :=
              mul_le_mul_of_nonneg_right (by exact_mod_cast hlt) hcfgW
            have hm2 : (idx.val : ℤ) * ops.cfgWStride + ops.cfgWStride = ((idx.val + 1 : ℕ) : ℤ) * ops.cfgWStride := by
              push_cast; ring
            dsimp [cBW]; unfold nodeCfgWOff at hj1 hj2 ⊢; omega
          · apply Or.inr
            have hm1 : ((i.val + 1 : ℕ) : ℤ) * ops.cfgWStride ≤ (idx.val : ℤ) * ops.cfgWStride :=
              mul_le_mul_of_nonneg_right (by exact_mod_cast hgt) hcfgW
            have hm2 : (i.val : ℤ) * ops.cfgWStride + ops.cfgWStride = ((i.val + 1 : ℕ) : ℤ) * ops.cfgWStride := by
              push_cast; ring
            dsimp [cBW]; unfold nodeCfgWOff at hj1 hj2 ⊢; omega
        have hdisjR : ∀ (idx : Fin N_cfg), idx ≠ i → ∀ j : ℤ,
            nodeCfgROff d K_seg ops.cfgRStride nodeBaseR idx.val ≤ j →
            j < nodeCfgROff d K_seg ops.cfgRStride nodeBaseR idx.val + ops.cfgRStride →
            (j < cBR ∨ cBR + ops.cfgRStride ≤ j) := by
          intro idx hne j hj1 hj2
          have hne_v : idx.val ≠ i.val := fun he => hne (Fin.ext he)
          rcases lt_or_gt_of_ne hne_v with hlt | hgt
          · apply Or.inl
            have hm1 : ((idx.val + 1 : ℕ) : ℤ) * ops.cfgRStride ≤ (i.val : ℤ) * ops.cfgRStride :=
              mul_le_mul_of_nonneg_right (by exact_mod_cast hlt) hcfgR
            have hm2 : (idx.val : ℤ) * ops.cfgRStride + ops.cfgRStride = ((idx.val + 1 : ℕ) : ℤ) * ops.cfgRStride := by
              push_cast; ring
            dsimp [cBR]; unfold nodeCfgROff at hj1 hj2 ⊢; omega
          · apply Or.inr
            have hm1 : ((i.val + 1 : ℕ) : ℤ) * ops.cfgRStride ≤ (idx.val : ℤ) * ops.cfgRStride :=
              mul_le_mul_of_nonneg_right (by exact_mod_cast hgt) hcfgR
            have hm3 : (i.val : ℤ) * ops.cfgRStride + ops.cfgRStride = ((i.val + 1 : ℕ) : ℤ) * ops.cfgRStride := by
              push_cast; ring
            dsimp [cBR]; unfold nodeCfgROff at hj1 hj2 ⊢; omega
        refine ⟨mc, (DetExecAt.seq hda (DetExecAt.seq hdb hdc)).mono_cost (by omega), hfpc,
          ⟨fun j hj => (hfr_m_mc.1 tblW j hneW (Or.inr (Or.inl (by dsimp [cBW]; omega)))).trans (hpreWm j hj),
           fun j hj => (hfr_m_mc.2 tblR j hneR (Or.inr (Or.inl (by dsimp [cBR]; omega)))).trans (hpreRm j hj),
           fun idx hidx => ?_,
           fun idx hidx => ?_⟩,
          fun w hw => (hw_c w (by omega)).trans
            (by dsimp [mb, ma]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
          RadFrameOutside_mono_range hfr_m_mc (Or.inr ⟨by dsimp [cBW]; omega, by dsimp [cBW]; omega⟩)
            (Or.inr ⟨by dsimp [cBR]; omega, by dsimp [cBR]; omega⟩)⟩
        · rcases Nat.lt_succ_iff_lt_or_eq.mp hidx with hlt | heq
          · have hne_idx : idx ≠ i := fun he => by subst he; omega
            exact ops.encCfg_mono_slice (specs idx) _ _ pts o V_val ∅ _ m mc (henc_lt idx hlt)
              (fun j hj1 hj2 => hfr_m_mc.1 tblW j hneW (Or.inr (hdisjW idx hne_idx j hj1 hj2)))
              (fun j hj1 hj2 => hfr_m_mc.2 tblR j hneR (Or.inr (hdisjR idx hne_idx j hj1 hj2)))
              (fun _ hx => absurd hx (Finset.notMem_empty _))
          · have hidx_eq : idx = i := Fin.ext heq
            subst hidx_eq; exact henc_c
        · have hne_idx : idx ≠ i := fun he => by subst he; omega
          exact ops.cfgReady_mono_slice (specs idx) _ _ m mc (hrdy_ge idx (by omega))
            (fun j hj1 hj2 => hfr_m_mc.1 tblW j hneW (Or.inr (hdisjW idx hne_idx j hj1 hj2)))
            (fun j hj1 hj2 => hfr_m_mc.2 tblR j hneR (Or.inr (hdisjR idx hne_idx j hj1 hj2))))
  -- Assemble full `DetExec` & `EncManagedNode`
  have hd_all : DetExec inp (managedNodeOpenEmptyStmt ops specs cap_hist K_seg
      wNodeBaseW wNodeBaseR wBirthSz rInO wScr rScr) m₀ m6 (managedNodeOpenEmptyCost ops N_cfg) := by
    unfold managedNodeOpenEmptyStmt managedNodeOpenEmptyCost
    exact (DetExecAt.seq hd1 (DetExecAt.seq hd2a (DetExecAt.seq hd2b (DetExecAt.seq hd2c
      (DetExecAt.seq hd2d (DetExecAt.seq hd2e (DetExecAt.seq hd2f
      (DetExecAt.seq hd3a (DetExecAt.seq hd3b (DetExecAt.seq hd4a (DetExecAt.seq hd4b
      (DetExecAt.seq hd5a (DetExecAt.seq hd5b hd6))))))))))))).mono_cost (by omega)
  have hw_all : ∀ w, w < wScr → H3a.wRead m6 scrW w = H3a.wRead m₀ scrW w := fun w hw =>
    (hw6 w hw).trans ((hw2_5b w hw).trans ((hm2_keepW scrW w (Or.inl hneW.symm)).trans (hw1 w hw)))
  have hfr_all : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m₀ m6 :=
    ((hfr1.trans hfr2).trans hfr2_5b).trans hfr6
  refine ⟨m6, hd_all, hfp6, ?_, hw_all, hfr_all⟩
  -- Prove `EncManagedNode` on `m6`
  have hpreW_m2 : ∀ i : ℤ,
      (i < nodeDensePoolOff nodeBaseW ∨ i = nodeHistOff n nodeBaseW) →
      H3a.wRead m6 tblW i = H3a.wRead m2 tblW i := by
    intro i hi
    have hlt_cfgs : i < nodeCfgsWBase n cap_hist K_seg nodeBaseW := by
      rcases hi with h1 | rfl <;> unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff nodeDensePoolOff swapPoolStride at * <;> omega
    exact (hpreW6 i hlt_cfgs).trans (hkeep_hdr_m5b i (by rcases hi with h1 | h2; exact Or.inl h1; exact Or.inr (Or.inl h2)))
  have hm2_hdr0 : H3a.wRead m2 tblW (nodeBirthSizeOff nodeBaseW) = (m₀_sz : ℤ) := by
    dsimp [m2, m2e, m2d, m2c, m2b, m2a]; unfold nodeBirthSizeOff
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hm2_hdr1 : H3a.wRead m2 tblW (nodeAgeOff nodeBaseW) = 0 := by
    dsimp [m2, m2e, m2d, m2c, m2b, m2a]; unfold nodeAgeOff
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_self]
  have hm2_hdr2 : H3a.wRead m2 tblW (nodeBaseHasOff nodeBaseW) = 0 := by
    dsimp [m2, m2e, m2d, m2c, m2b, m2a]; unfold nodeBaseHasOff
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hm2_hdr3 : H3a.wRead m2 tblW (nodeBaseUOff nodeBaseW) = 0 := by
    dsimp [m2, m2e, m2d, m2c, m2b, m2a]; unfold nodeBaseUOff
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_self]
  have hm2_hdr4 : H3a.wRead m2 tblW (nodeBaseVOff nodeBaseW) = 0 := by
    dsimp [m2, m2e, m2d, m2c, m2b, m2a]; unfold nodeBaseVOff
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hm2_hist : H3a.wRead m2 tblW (nodeHistOff n nodeBaseW) = 0 := by
    have heq : nodeHistOff n nodeBaseW = nodeBaseW + histOffVal := by unfold nodeHistOff; dsimp [histOffVal]; ring
    rw [heq]; exact wRead_wWrite_self _ _ _ _
  refine ⟨(hpreW_m2 _ (Or.inl (by unfold nodeBirthSizeOff nodeDensePoolOff; omega))).trans hm2_hdr0,
    (hpreW_m2 _ (Or.inl (by unfold nodeAgeOff nodeDensePoolOff; omega))).trans hm2_hdr1,
    ⟨(hpreW_m2 _ (Or.inl (by unfold nodeBaseHasOff nodeDensePoolOff; omega))).trans hm2_hdr2,
     (hpreW_m2 _ (Or.inl (by unfold nodeBaseUOff nodeDensePoolOff; omega))).trans hm2_hdr3,
     (hpreW_m2 _ (Or.inl (by unfold nodeBaseVOff nodeDensePoolOff; omega))).trans hm2_hdr4⟩,
    fun c => (hpreR6 _ (by have := c.isLt; unfold nodeCenterROff nodeCfgsRBase nodeRadTreeROff; omega)).trans
      ((hkeep_R_m5b _).trans (ho1 c)),
    (hpreR6 _ (by unfold nodeHeightROff nodeCfgsRBase nodeRadTreeROff; omega)).trans
      ((hkeep_R_m5b _).trans hs1),
    (hpreR6 _ (by unfold nodeVarROff nodeCfgsRBase nodeRadTreeROff; omega)).trans
      ((hkeep_R_m5b _).trans hV1),
    Nat.zero_le cap_hist,
    (hpreW_m2 _ (Or.inr rfl)).trans hm2_hist,
    fun _ hj => absurd hj (Nat.not_lt_zero _),
    ⟨Pd', hPd'_wf, hPd'_l, ?_⟩,
    ⟨Pr', hPr'_wf, hPr'_l, ?_⟩,
    ⟨Tr', hTr'_wf, ?_⟩,
    fun i => by
      have hcs0 : nodeCfgSet (ManagedNode.openEmpty L_p2 R ℓ M₀ d b N_cfg T_cdf p_coord o s P₀ m₀_sz).nd = ∅ := by
        unfold nodeCfgSet; split_ifs <;> rfl
      rw [hcs0]; exact hcfgs6 i i.isLt⟩
  · have hsub : ∀ i : ℤ, nodeDensePoolOff nodeBaseW ≤ i →
        i < nodeDensePoolOff nodeBaseW + swapPoolStride n → H3a.wRead m6 tblW i = H3a.wRead m5b tblW i :=
      fun i _ hhi => hpreW6 i (by unfold nodeDensePoolOff nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride at *; omega)
    have hPd_sz := hPd'_wf.2.2.2.1
    exact ⟨(hsub _ le_rfl (by dsimp [swapPoolStride]; omega)).trans hPd'_m5b.1,
      (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans hPd'_m5b.2.1,
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPd'_m5b.2.2.1 x hx),
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPd'_m5b.2.2.2.1 x hx),
      fun r hr => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPd'_m5b.2.2.2.2 r hr)⟩
  · have hsub : ∀ i : ℤ, nodeResPoolOff n nodeBaseW ≤ i →
        i < nodeResPoolOff n nodeBaseW + swapPoolStride n → H3a.wRead m6 tblW i = H3a.wRead m5b tblW i :=
      fun i _ hhi => hpreW6 i (by unfold nodeResPoolOff nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride at *; omega)
    have hPr_sz := hPr'_wf.2.2.2.1
    exact ⟨(hsub _ le_rfl (by dsimp [swapPoolStride]; omega)).trans hPr'_m5b.1,
      (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans hPr'_m5b.2.1,
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr'_m5b.2.2.1 x hx),
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr'_m5b.2.2.2.1 x hx),
      fun r hr => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr'_m5b.2.2.2.2 r hr)⟩
  · refine ⟨(hpreW6 _ (by unfold nodeCfgsWBase; omega)).trans hTr'_e.1, fun v hv => ?_⟩
    have hvW := radTreeWStride_gt_node hv
    have hvR := radTreeRStride_gt_node hv
    obtain ⟨e1, e2, e3, e4⟩ := hTr'_e.2 v hv
    exact ⟨(hpreW6 _ (by unfold nodeCfgsWBase; omega)).trans e1,
           (hpreW6 _ (by unfold nodeCfgsWBase; omega)).trans e2,
           (hpreW6 _ (by unfold nodeCfgsWBase; omega)).trans e3,
           (hpreR6 _ (by unfold nodeCfgsRBase; omega)).trans e4⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
