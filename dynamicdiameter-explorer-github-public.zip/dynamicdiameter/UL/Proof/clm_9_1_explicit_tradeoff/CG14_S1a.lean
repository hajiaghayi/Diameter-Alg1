import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3c_ChainEngine
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.C14d1

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 1. Good-Event Invariants (`SuffixJobGood`, `ChainEngineGood`) & Stage-1 Good Coins -/

def SuffixJobGood {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (gt : GhostTracker d) (jb : SuffixJob cp) : Prop :=
  ChainListGood cp hh0 hh1 pts gt jb.ready ∧
  match jb.phase with
  | .copy _ => True
  | .build bs => LiveNodeGood cp hh0 hh1 pts gt bs.curNode

def ChainEngineGood {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (st : ChainEngineState cp) : Prop :=
  let pts := st.hp.coords
  st.leafOverflow = false ∧
  ChainListGood cp hh0 hh1 pts st.gt st.serving ∧
  ∀ r : Fin cp.D_max,
    r.val < st.serving.length →
    ∀ jb, st.jobs r = some jb →
      SuffixJobGood cp hh0 hh1 pts st.gt jb

theorem empty_chainEngineGood {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1) :
    ChainEngineGood cp hh0 hh1 (ChainEngineState.empty cp) :=
  ⟨rfl, fun _ hm => absurd hm List.not_mem_nil, fun _ hr => absurd hr (Nat.not_lt_zero _)⟩

/-- Per-slot pre-Stage-1 good-seed predicate for `k : Fin cp.N_op_s1` (depends ONLY on pre-Stage-1 `st`!). -/
def s1SlotGood {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (st : ChainEngineState cp) (k : Fin cp.N_op_s1) (ω : OpSeed cp) : Prop :=
  let M_lat := M_lat_of d params.e
  if k.val < cp.D_max then
    ∀ hk : k.val < st.serving.length,
      NodeOpSeedGood cp.T_cdf cp.p_coord M_lat params cp.specs cp.τ_d cp.τ_q hh0 hh1
        cp.cap_u cp.cap_q (st.serving[k.val]'hk).nd ω
  else if k.val < cp.D_max + cp.D_max * cp.D_max then
    let r := (k.val - cp.D_max) / cp.D_max
    let q := (k.val - cp.D_max) % cp.D_max
    ∀ (hr : r < cp.D_max) (jb : SuffixJob cp),
      st.jobs ⟨r, hr⟩ = some jb →
      ∀ (hq : q < jb.ready.length),
        NodeOpSeedGood cp.T_cdf cp.p_coord M_lat params cp.specs cp.τ_d cp.τ_q hh0 hh1
          cp.cap_u cp.cap_q (jb.ready[q]'hq).nd ω
  else
    let r := k.val - (cp.D_max + cp.D_max * cp.D_max)
    ∀ (hr : r < cp.D_max) (jb : SuffixJob cp) (bs : BuildState cp),
      st.jobs ⟨r, hr⟩ = some jb →
      jb.phase = .build bs →
        NodeOpSeedGood cp.T_cdf cp.p_coord M_lat params cp.specs cp.τ_d cp.τ_q hh0 hh1
          cp.cap_u cp.cap_q bs.curNode.nd ω

def GoodStage1Coins {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (st : ChainEngineState cp) (ω₁ : Stage1Coins cp) : Prop :=
  ∀ k : Fin cp.N_op_s1, s1SlotGood cp hh0 hh1 st k (ω₁ k)

theorem GoodStage1Coins.serv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {hh0 : 0 < h} {hh1 : h < 1}
    {st : ChainEngineState cp} {ω₁ : Stage1Coins cp}
    (hserv_len : st.serving.length ≤ cp.D_max)
    (hgd : GoodStage1Coins cp hh0 hh1 st ω₁)
    (q : ℕ) (hq : q < st.serving.length) :
    NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
      cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q (st.serving[q]'hq).nd (getS1Seed cp ω₁ q) := by
  have hq_D : q < cp.D_max := lt_of_lt_of_le hq hserv_len
  have hq_N : q < cp.N_op_s1 := by change q < cp.D_max + cp.D_max * cp.D_max + cp.D_max; omega
  unfold getS1Seed
  rw [dif_pos hq_N]
  have hk := hgd ⟨q, hq_N⟩
  unfold s1SlotGood at hk
  dsimp only at hk
  rw [if_pos hq_D] at hk
  exact hk hq

theorem GoodStage1Coins.ready {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {hh0 : 0 < h} {hh1 : h < 1}
    {st : ChainEngineState cp} {ω₁ : Stage1Coins cp}
    (hgd : GoodStage1Coins cp hh0 hh1 st ω₁)
    (r : Fin cp.D_max) {jb : SuffixJob cp} (hjb : st.jobs r = some jb)
    (hrs : r.val + jb.ready.length < cp.D_max)
    (q : ℕ) (hq : q < jb.ready.length) :
    NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
      cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q (jb.ready[q]'hq).nd
      (getS1Seed cp ω₁ (cp.D_max + r.val * cp.D_max + q)) := by
  have hq_D : q < cp.D_max := by omega
  have hrq_lt : r.val * cp.D_max + q < cp.D_max * cp.D_max := by
    calc r.val * cp.D_max + q < r.val * cp.D_max + cp.D_max := Nat.add_lt_add_left hq_D _
      _ = (r.val + 1) * cp.D_max := by ring
      _ ≤ cp.D_max * cp.D_max := Nat.mul_le_mul_right _ r.isLt
  let idx := cp.D_max + r.val * cp.D_max + q
  have hidx_N : idx < cp.N_op_s1 := by change idx < cp.D_max + cp.D_max * cp.D_max + cp.D_max; dsimp [idx]; omega
  unfold getS1Seed
  rw [dif_pos hidx_N]
  have hk := hgd ⟨idx, hidx_N⟩
  unfold s1SlotGood at hk
  dsimp only at hk
  have hnot1 : ¬ idx < cp.D_max := by dsimp [idx]; omega
  have hlt2 : idx < cp.D_max + cp.D_max * cp.D_max := by dsimp [idx]; omega
  rw [if_neg hnot1, if_pos hlt2] at hk
  have hsub : idx - cp.D_max = q + r.val * cp.D_max := by dsimp [idx]; omega
  have hdiv : (idx - cp.D_max) / cp.D_max = r.val := by
    rw [hsub, Nat.add_mul_div_right _ _ cp.D_max_pos, Nat.div_eq_of_lt hq_D, zero_add]
  have hmod : (idx - cp.D_max) % cp.D_max = q := by
    rw [hsub, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hq_D]
  have hk' := hk
  simp only [hdiv, hmod] at hk'
  exact hk' r.isLt jb hjb hq

theorem GoodStage1Coins.cur {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {hh0 : 0 < h} {hh1 : h < 1}
    {st : ChainEngineState cp} {ω₁ : Stage1Coins cp}
    (hgd : GoodStage1Coins cp hh0 hh1 st ω₁)
    (r : Fin cp.D_max) {jb : SuffixJob cp} {bs : BuildState cp}
    (hjb : st.jobs r = some jb) (hbs : jb.phase = .build bs) :
    NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
      cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q bs.curNode.nd
      (getS1Seed cp ω₁ (cp.D_max + cp.D_max * cp.D_max + r.val)) := by
  let idx := cp.D_max + cp.D_max * cp.D_max + r.val
  have hidx_N : idx < cp.N_op_s1 := by change idx < cp.D_max + cp.D_max * cp.D_max + cp.D_max; dsimp [idx]; omega
  unfold getS1Seed
  rw [dif_pos hidx_N]
  have hk := hgd ⟨idx, hidx_N⟩
  unfold s1SlotGood at hk
  dsimp only at hk
  have hnot1 : ¬ idx < cp.D_max := by dsimp [idx]; omega
  have hnot2 : ¬ idx < cp.D_max + cp.D_max * cp.D_max := by dsimp [idx]; omega
  rw [if_neg hnot1, if_neg hnot2] at hk
  have hsub : idx - (cp.D_max + cp.D_max * cp.D_max) = r.val := by dsimp [idx]; omega
  simp only [hsub] at hk
  exact hk r.isLt jb bs hjb hbs

/-! ### 2. `HandlePool.step` Clean Insert/Delete Dichotomy -/

theorem handlePool_step_detail {d n : ℕ} {P : DynamicPointSet d} {hp : HandlePool d n}
    {op : DynamicUpdate d} (hP : P.WellFormed n) (hhp : hp.WellFormed P)
    (hleg : IsLegalUpdate n Set.univ P op) :
    let (hp', rh) := hp.step (toInternalUpdate P op)
    ∃ P' : DynamicPointSet d,
      applyDynamicUpdate P op rh = some P' ∧
      hp'.WellFormed P' ∧
      ((∃ h_new pt,
          toInternalUpdate P op = .insert pt ∧
          rh = some h_new ∧
          h_new ∉ P.activeHandles ∧
          P'.activeHandles = insert h_new P.activeHandles ∧
          hp'.coords h_new = pt ∧
          (∀ x ∈ P.activeHandles, hp'.coords x = hp.coords x)) ∨
       (∃ delH,
          toInternalUpdate P op = .delete delH ∧
          rh = none ∧
          delH ∈ P.activeHandles ∧
          P'.activeHandles = P.activeHandles.erase delH ∧
          hp'.coords = hp.coords)) := by
  rcases HandlePool.step_wellFormed hP hhp hleg with ⟨P', happ, hhp'⟩
  refine ⟨P', happ, hhp', ?_⟩
  cases op with
  | insert pid extName pt =>
      apply Or.inl
      dsimp only [toInternalUpdate, HandlePool.step] at happ ⊢
      cases hfl : hp.freeList with
      | cons h₀ rest =>
          rw [hfl] at happ
          dsimp only at happ
          unfold applyDynamicUpdate at happ
          dsimp only at happ
          split_ifs at happ with hcond
          injection happ with hP'_eq
          subst hP'_eq
          refine ⟨h₀, pt, rfl, rfl, hcond.2, rfl, by simp, fun x hx => ?_⟩
          have hne : x ≠ h₀ := by intro heq; subst heq; exact hcond.2 hx
          exact Function.update_of_ne hne pt hp.coords
      | nil =>
          rw [hfl] at happ
          dsimp only at happ
          unfold applyDynamicUpdate at happ
          dsimp only at happ
          split_ifs at happ with hcond
          injection happ with hP'_eq
          subst hP'_eq
          refine ⟨hp.nextFresh, pt, rfl, rfl, hcond.2, rfl, by simp, fun x hx => ?_⟩
          have hne : x ≠ hp.nextFresh := by intro heq; subst heq; exact hcond.2 hx
          exact Function.update_of_ne hne pt hp.coords
  | delete pid =>
      apply Or.inr
      dsimp only [toInternalUpdate, HandlePool.step] at happ ⊢
      unfold applyDynamicUpdate at happ
      dsimp only at happ
      split_ifs at happ with hid_in
      injection happ with hP'_eq
      subst hP'_eq
      exact ⟨P.handleOfId pid, rfl, rfl, (hP.2.1 pid hid_in).1, rfl, rfl⟩

theorem passesNodes_take_of_all {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    {pts' : ℕ → EuclideanSpace ℝ (Fin d)} {h_op : ℕ} :
    ∀ (k : ℕ) (ls : List (MNode cp)),
      passesNodes pts' h_op ls = true →
      passesNodes pts' h_op (ls.take k) = true
  | 0, _, _ => rfl
  | _ + 1, [], _ => rfl
  | k + 1, mn :: rest, hall => by
      dsimp only [passesNodes] at hall ⊢
      rcases Bool.and_eq_true_iff.mp hall with ⟨hhd, htl⟩
      exact Bool.and_eq_true_iff.mpr ⟨hhd, passesNodes_take_of_all k rest htl⟩

theorem handlePool_step_detail' {d n : ℕ} {P : DynamicPointSet d} {hp : HandlePool d n}
    {op : DynamicUpdate d} (hP : P.WellFormed n) (hhp : hp.WellFormed P)
    (hleg : IsLegalUpdate n Set.univ P op) :
    ∃ P' : DynamicPointSet d,
      applyDynamicUpdate P op (hp.step (toInternalUpdate P op)).2 = some P' ∧
      (hp.step (toInternalUpdate P op)).1.WellFormed P' ∧
      ((∃ h_new pt,
          toInternalUpdate P op = .insert pt ∧
          (hp.step (toInternalUpdate P op)).2 = some h_new ∧
          h_new ∉ P.activeHandles ∧
          P'.activeHandles = insert h_new P.activeHandles ∧
          (hp.step (toInternalUpdate P op)).1.coords h_new = pt ∧
          (∀ x ∈ P.activeHandles, (hp.step (toInternalUpdate P op)).1.coords x = hp.coords x)) ∨
       (∃ delH,
          toInternalUpdate P op = .delete delH ∧
          (hp.step (toInternalUpdate P op)).2 = none ∧
          delH ∈ P.activeHandles ∧
          P'.activeHandles = P.activeHandles.erase delH ∧
          (hp.step (toInternalUpdate P op)).1.coords = hp.coords)) :=
  handlePool_step_detail hP hhp hleg

theorem serving_age_le_of_wf {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) {P : DynamicPointSet d}
    {st : ChainEngineState cp} (hwf : ChainEngineWF cp P st) :
    ∀ mn ∈ st.serving, mn.nd.age ≤ mn.nd.birthSize := by
  rcases hwf with ⟨_, _, hserv_len, hserv_cl, hjobs_wf, _⟩
  let actH := P.activeHandles

  intro mn hmem
  rcases List.mem_iff_getElem.mp hmem with ⟨q, hq, rfl⟩
  have hqD : q < cp.D_max := lt_of_lt_of_le hq hserv_len
  have hslot := hjobs_wf ⟨q, hqD⟩
  rw [dif_pos hq] at hslot
  have hK : 36 ≤ K_alpha d := K_alpha_ge_36 d
  cases hjb_eq : st.jobs ⟨q, hqD⟩ with
  | none =>
      dsimp only at hslot
      rw [hjb_eq] at hslot
      have : (st.serving[q]'hq).nd.age ≤ 64 * K_alpha d * (st.serving[q]'hq).nd.age := by
        simpa using Nat.mul_le_mul_right (st.serving[q]'hq).nd.age (by omega : 1 ≤ 64 * K_alpha d)
      linarith only [this, hslot]
  | some jb =>
      rw [hjb_eq] at hslot
      have hMr : cp.B_scan < (st.serving[q]'hq).nd.birthSize :=
        (chainListInv_mem_birthSize actH st.serving hserv_cl _ (List.getElem_mem hq)).1
      have h16 := (suffixJobInvSlack_bounds (Nat.zero_le _) hMr hslot).2.1
      have : (st.serving[q]'hq).nd.age ≤ 16 * K_alpha d * (st.serving[q]'hq).nd.age := by
        simpa using Nat.mul_le_mul_right (st.serving[q]'hq).nd.age (by omega : 1 ≤ 16 * K_alpha d)
      omega

theorem stepStage1_spec_ins {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {P : DynamicPointSet d}
    {op : DynamicUpdate d}
    {st : ChainEngineState cp} (hwf : ChainEngineWF cp P st)
    (ω₁ : Stage1Coins cp)
    (P' : DynamicPointSet d)
    (hhp' : (st.hp.step (toInternalUpdate P op)).1.WellFormed P')
    (h_new : ℕ) (pt : EuclideanSpace ℝ (Fin d))
    (huop_eq : toInternalUpdate P op = .insert pt)
    (hrh_eq : (st.hp.step (toInternalUpdate P op)).2 = some h_new)
    (hnot_act : h_new ∉ P.activeHandles)
    (hact'_eq : P'.activeHandles = insert h_new P.activeHandles)
    (hpts_new : (st.hp.step (toInternalUpdate P op)).1.coords h_new = pt)
    (hpts_old : ∀ x ∈ P.activeHandles, (st.hp.step (toInternalUpdate P op)).1.coords x = st.hp.coords x) :
    PostStage1WF cp P' (stepStage1 cp st (toInternalUpdate P op) ω₁).1 ∧
      (ChainEngineGood cp hh0 hh1 st →
       GoodStage1Coins cp hh0 hh1 st ω₁ →
       ChainEngineGood cp hh0 hh1 (stepStage1 cp st (toInternalUpdate P op) ω₁).1) := by
  have hserv_age_le := serving_age_le_of_wf cp hwf
  rcases hwf with ⟨hhp, hgt, hserv_len, hserv_cl, hjobs_wf, hleaf_wf⟩
  let actH := P.activeHandles
  let pts := st.hp.coords
  have hstep_eq : stepStage1 cp st (toInternalUpdate P op) ω₁ =
      stepStage1 cp st (.insert pt) ω₁ := by rw [huop_eq]
  rw [hstep_eq]
  -- Unpack `(hp', rh)` on `.insert pt`
  have hhp_step : (st.hp.step (.insert pt)).2 = some h_new := by
    rw [← huop_eq]; exact hrh_eq
  let hp' := (st.hp.step (.insert pt)).1
  have hhp'_wf : hp'.WellFormed P' := by dsimp [hp']; rw [← huop_eq]; exact hhp'
  let pts' := hp'.coords
  have hpts'_new : pts' h_new = pt := by dsimp [pts', hp']; rw [← huop_eq]; exact hpts_new
  have hpts'_old : ∀ x ∈ actH, pts' x = pts x := by dsimp [pts', hp']; rw [← huop_eq]; exact hpts_old
  have hrh_getD : ((st.hp.step (.insert pt)).2).getD 0 = h_new := by rw [hhp_step]; rfl
  let gt' := st.gt.stepInsert h_new pt
  have hgt' : GhostTrackerWF (insert h_new actH) pts' gt' :=
    (ghostTracker_stepInsert_spec hnot_act pt hpts'_new hpts'_old hgt).2.2.2.2
  -- Serving list live update
  rcases liveUpdateChainList_insert_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hnot_act pt
    hpts'_new hpts'_old (getS1Seed cp ω₁) 0 actH st.serving (Finset.Subset.refl _)
    hserv_age_le hserv_cl
    with ⟨hserv_len₁, hserv_el₁, hserv_cl₁, hserv_fold₁, hserv_gd₁⟩
  let servRes := liveUpdateChainList cp pts' true h_new (getS1Seed cp ω₁) 0 st.serving
  let st₁ := (stepStage1 cp st (.insert pt) ω₁).1
  have hst₁_hp : st₁.hp = hp' := rfl
  have hst₁_gt : st₁.gt = gt' := by dsimp [st₁, stepStage1]; rw [hrh_getD]
  have hst₁_serv : st₁.serving = servRes.1 := by dsimp [st₁, stepStage1]; rw [hrh_getD]
  have hst₁_ov : st₁.leafOverflow = st.leafOverflow := rfl
  refine ⟨⟨hhp'_wf, ?_, ?_, ?_, ?_, ?_⟩, fun ⟨hov0, hgd_serv0, hgd_jobs0⟩ hcoins1 => ?_⟩
  · rw [hact'_eq, hst₁_hp, hst₁_gt]; exact hgt'
  · rw [hst₁_serv, hserv_len₁]; exact hserv_len
  · rw [hact'_eq, hst₁_hp, hst₁_gt, hst₁_serv]; exact hserv_cl₁
  · -- Per-slot `PostStage1WF`
    intro r
    by_cases hr1_st : r.val < st₁.serving.length
    · rw [dif_pos hr1_st]
      have hr : r.val < st.serving.length := by rwa [hst₁_serv, hserv_len₁] at hr1_st
      have hslot0 := hjobs_wf r
      rw [dif_pos hr] at hslot0
      have hr1 : r.val < servRes.1.length := by rwa [hst₁_serv] at hr1_st
      rcases hserv_el₁ r.val hr hr1 with ⟨_, _, hbsz_r, hage_r⟩
      cases hjb0 : st.jobs r with
      | none =>
          dsimp only at hslot0
          rw [hjb0] at hslot0
          have hjb1 : st₁.jobs r = none := by dsimp [st₁, stepStage1]; rw [hjb0]
          rw [hjb1]
          dsimp only
          have heq_elem : st₁.serving[r.val]'hr1_st = servRes.1[r.val]'hr1 :=
            List.getElem_of_eq hst₁_serv hr1_st
          rw [heq_elem, hbsz_r]
          have hmul : 64 * K_alpha d * (servRes.1[r.val]'hr1).nd.age ≤
              64 * K_alpha d * (st.serving[r.val]'hr).nd.age + 64 * K_alpha d := by
            have := Nat.mul_le_mul_left (64 * K_alpha d) hage_r
            linarith only [this]
          omega
      | some jb =>
          rw [hjb0] at hslot0
          have hMr0 : cp.B_scan < (st.serving[r.val]'hr).nd.birthSize :=
            (chainListInv_mem_birthSize actH st.serving hserv_cl _ (List.getElem_mem hr)).1
          rcases suffixJobInvSlack_bounds (Nat.zero_le _) hMr0 hslot0
            with ⟨hready_b0, _, _, hbs_age0⟩
          dsimp only [SuffixJobInv, SuffixJobInvSlack] at hslot0
          rcases hslot0 with ⟨hrs_lt, hcl_r0, hrb0, hanc_age0, hph0⟩
          -- Prefix `st.serving.take r.val`
          have hcl_take0 := chainListInv_take r.val actH st.serving hserv_cl
          have hS_anc_sub : foldResiduals pts actH (st.serving.take r.val) ⊆ actH :=
            (chainListInv_getElem actH st.serving (Finset.Subset.refl _) hserv_cl).2 r.val hr |>.1
          have htake_age : ∀ mn ∈ st.serving.take r.val, mn.nd.age ≤ mn.nd.birthSize :=
            fun mn hm => hserv_age_le mn (List.mem_of_mem_take hm)
          rcases liveUpdateChainList_insert_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hnot_act pt
            hpts'_new hpts'_old (getS1Seed cp ω₁) 0 actH (st.serving.take r.val)
            (Finset.Subset.refl _) htake_age hcl_take0
            with ⟨_, _, _, htake_fold, _⟩
          have htake_snd := liveUpdateChainList_snd_eq cp pts' true h_new (getS1Seed cp ω₁) 0 (st.serving.take r.val)
          have htake_eq := liveUpdateChainList_take cp pts' true h_new (getS1Seed cp ω₁) r.val 0 st.serving
          rcases liveUpdateChainList_hist_dichotomy cp pts' true h_new (getS1Seed cp ω₁) 0 st.serving r.val hr
            with ⟨hr1', hanc_dic, hanc_pass⟩
          have helem_serv1 : st₁.serving[r.val]'hr1_st = servRes.1[r.val]'hr1 :=
            List.getElem_of_eq hst₁_serv hr1_st
          have htake_serv1 : st₁.serving.take r.val = servRes.1.take r.val := by rw [hst₁_serv]
          by_cases hpass_r : passesNodes pts' h_new (st.serving.take r.val) = true
          · -- Update reaches anchor `r`!
            have hcond_r : (r.val < st.serving.length && passesNodes pts' h_new (st.serving.take r.val)) = true := by
              simp [hr, hpass_r]
            rw [htake_snd, hpass_r, if_pos rfl] at htake_fold
            let readyBase := cp.D_max + r.val * cp.D_max
            let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
            let rRes := liveUpdateChainList cp pts' true h_new
              (fun q => getS1Seed cp ω₁ (readyBase + q)) 0 jb.ready
            have hready_age_le : ∀ u ∈ jb.ready, u.nd.age ≤ u.nd.birthSize := by
              intro u hu
              rcases List.mem_iff_getElem.mp hu with ⟨q, hq, rfl⟩
              have h128 := (hready_b0 q hq).1
              have hK := K_alpha_ge_36 d
              have : (jb.ready[q]'hq).nd.age ≤ 128 * K_alpha d * (jb.ready[q]'hq).nd.age := by
                simpa using Nat.mul_le_mul_right (jb.ready[q]'hq).nd.age (by omega : 1 ≤ 128 * K_alpha d)
              omega
            rcases liveUpdateChainList_insert_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hnot_act pt
              hpts'_new hpts'_old (fun q => getS1Seed cp ω₁ (readyBase + q)) 0
              (foldResiduals pts actH (st.serving.take r.val)) jb.ready hS_anc_sub
              hready_age_le hcl_r0
              with ⟨hr_len1, hr_el1, hr_cl1, hr_fold1, _⟩
            let phase₁ : JobPhase cp :=
              if rRes.2 then
                match jb.phase with
                | .copy cs => .copy (cs.liveInsert h_new)
                | .build bs => .build (bs.liveInsert cp pts' h_new (getS1Seed cp ω₁ curIdx))
              else
                jb.phase
            have hjb1_eq : st₁.jobs r = some { ready := rRes.1, phase := phase₁ } := by
              dsimp [st₁, stepStage1]
              rw [hrh_getD, hjb0]
              dsimp only
              rw [if_pos hcond_r]; rfl
            rw [hjb1_eq]
            set anc1 := st₁.serving[r.val]'hr1_st
            have hanc1_eq : anc1 = servRes.1[r.val]'hr1 := helem_serv1
            dsimp only [SuffixJobInvSlack]
            rw [hact'_eq, hst₁_hp, hst₁_gt, hanc1_eq, htake_serv1, htake_eq, htake_fold, hbsz_r]
            have hlvl_eq : phase₁.lvlProg = jb.phase.lvlProg := by
              dsimp only [phase₁]
              by_cases h2 : rRes.2 = true
              · rw [if_pos h2]; cases jb.phase <;> rfl
              · rw [if_neg h2]
            have hr_len1_r : rRes.1.length = jb.ready.length := hr_len1
            refine ⟨by rw [hr_len1_r]; exact hrs_lt, hr_cl1, ?_, ?_, ?_⟩
            · intro q hq1
              have hq0 : q < jb.ready.length := by omega
              rcases hr_el1 q hq0 hq1 with ⟨_, _, hubsz, huage⟩
              rcases hrb0 q hq0 with ⟨hq0_mr, hq_pow, hq_age⟩
              refine ⟨fun h0 => by rw [hubsz]; exact hq0_mr h0,
                fun q' hq1' hqq' => ?_, ?_⟩
              · have hq0' : q' < jb.ready.length := by omega
                rw [(hr_el1 q' hq0' hq1').2.2.1, hubsz]
                exact hq_pow q' hq0' hqq'
              · rw [hubsz, hr_len1_r, hlvl_eq]
                have hm := Nat.mul_le_mul_left cp.B_scan huage
                linarith only [hq_age, hm]
            · rw [hr_len1_r, hlvl_eq]
              have hm := Nat.mul_le_mul_left (64 * K_alpha d * cp.B_scan) hage_r
              linarith only [hanc_age0, hm]
            · -- Phase invariant (`copy` or `build`, `rRes.2 = true` or `false`)
              have hTend_sub : foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready ⊆ actH :=
                (chainListInv_getElem _ jb.ready hS_anc_sub hcl_r0).1
              have hr_fold1' :
                  if rRes.2 = true then
                    foldResiduals pts' (insert h_new (foldResiduals pts actH (st.serving.take r.val))) rRes.1 =
                      insert h_new (foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready)
                  else
                    foldResiduals pts' (insert h_new (foldResiduals pts actH (st.serving.take r.val))) rRes.1 =
                      foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready := hr_fold1
              have hprev_props :
                  ∃ (u0 u1 : MNode cp),
                    ((jb.ready = [] ∧ rRes.1 = [] ∧ u0 = st.serving[r.val]'hr ∧ u1 = servRes.1[r.val]'hr1) ∨
                     (jb.ready.getLast? = some u0 ∧ rRes.1.getLast? = some u1)) ∧
                    u1.nd.birthSize = u0.nd.birthSize ∧
                    (u1.histArr = u0.histArr ∨ u1.histArr = u0.histArr ++ [h_new]) ∧
                    (rRes.2 = true → u1.histArr = u0.histArr ++ [h_new]) := by
                by_cases hremp : jb.ready = []
                · have hr1_emp : rRes.1 = [] := List.eq_nil_of_length_eq_zero (by rw [hr_len1_r, hremp]; rfl)
                  have hp_anc := hanc_pass hpass_r
                  simp only [↓reduceIte] at hp_anc
                  exact ⟨st.serving[r.val]'hr, servRes.1[r.val]'hr1,
                    Or.inl ⟨hremp, hr1_emp, rfl, rfl⟩, hbsz_r, Or.inr hp_anc, fun _ => hp_anc⟩
                · have hlen_pos : 0 < jb.ready.length :=
                    Nat.pos_of_ne_zero (fun h0 => hremp (List.eq_nil_of_length_eq_zero h0))
                  have hs1_lt0 : jb.ready.length - 1 < jb.ready.length := by omega
                  have hs1_lt1 : rRes.1.length - 1 < rRes.1.length := by omega
                  have hgl0 : jb.ready.getLast? = some (jb.ready[jb.ready.length - 1]'hs1_lt0) := by
                    rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem hs1_lt0]
                  have hgl1 : rRes.1.getLast? = some (rRes.1[rRes.1.length - 1]'hs1_lt1) := by
                    rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem hs1_lt1]
                  have hget_eq : rRes.1[rRes.1.length - 1]'hs1_lt1 = rRes.1[jb.ready.length - 1]'(by omega) := by
                    exact List.getElem_of_eq rfl (by omega) |> fun _ => by congr 1; omega
                  rw [hget_eq] at hgl1
                  rcases liveUpdateChainList_hist_dichotomy cp pts' true h_new
                    (fun q => getS1Seed cp ω₁ (readyBase + q)) 0 jb.ready (jb.ready.length - 1) hs1_lt0
                    with ⟨hs1_lt1', hdic_last, hpass_last⟩
                  refine ⟨jb.ready[jb.ready.length - 1]'hs1_lt0, rRes.1[jb.ready.length - 1]'hs1_lt1',
                    Or.inr ⟨hgl0, hgl1⟩, (hr_el1 (jb.ready.length - 1) hs1_lt0 _).2.2.1, ?_, fun hr2 => ?_⟩
                  · rcases hdic_last with h1 | ⟨_, h2⟩
                    · exact Or.inl h1
                    · exact Or.inr h2
                  · have hall_pass : passesNodes pts' h_new jb.ready = true := by
                      rw [← liveUpdateChainList_snd_eq cp pts' true h_new (fun q => getS1Seed cp ω₁ (readyBase + q)) 0 jb.ready]
                      exact hr2
                    have htk_pass := passesNodes_take_of_all (jb.ready.length - 1) jb.ready hall_pass
                    simpa using hpass_last htk_pass
              rcases hprev_props with ⟨u0, u1, hgl_both, hprev_bsz, hprev_dic, hprev_pass⟩
              have hph0_norm :
                  match jb.phase with
                  | .copy cs =>
                      cs.copyCur < cs.L_hist ∧ cs.L_hist ≤ 2 * u0.nd.birthSize ∧
                      CopyStateInv u0.histArr (foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready) cs
                  | .build bs =>
                      bs.insCur < bs.snapArr.length ∧ bs.L_hist ≤ 2 * u0.nd.birthSize ∧
                      cp.B_scan * bs.curNode.nd.age ≤ bs.insCur + 0 ∧
                      (if h0 : jb.ready.length = 0 then bs.curNode.nd.birthSize ≤ 2 * (st.serving[r.val]'hr).nd.birthSize
                       else bs.curNode.nd.birthSize * (2 * cp.D2) ≤ (jb.ready[jb.ready.length - 1]'(by omega)).nd.birthSize * (2 * cp.D2 + 1)) ∧
                      BuildStateInv cp pts st.gt (foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready) bs := by
                rcases hgl_both with ⟨h0e, _, rfl, _⟩ | ⟨hgs0, _⟩
                · have hgl0' : jb.ready.getLast? = none := by rw [h0e]; rfl
                  rw [hgl0'] at hph0; exact hph0
                · rw [hgs0] at hph0; exact hph0
              suffices hgoal_norm :
                  match (generalizing := false) phase₁ with
                  | .copy cs =>
                      cs.copyCur < cs.L_hist ∧ cs.L_hist ≤ 2 * u1.nd.birthSize ∧
                      CopyStateInv u1.histArr (foldResiduals pts' (insert h_new (foldResiduals pts actH (st.serving.take r.val))) rRes.1) cs
                  | .build bs =>
                      bs.insCur < bs.snapArr.length ∧ bs.L_hist ≤ 2 * u1.nd.birthSize ∧
                      cp.B_scan * bs.curNode.nd.age ≤ bs.insCur + cp.B_scan ∧
                      (if h0 : rRes.1.length = 0 then bs.curNode.nd.birthSize ≤ 2 * (st.serving[r.val]'hr).nd.birthSize
                       else bs.curNode.nd.birthSize * (2 * cp.D2) ≤ (rRes.1[rRes.1.length - 1]'(by omega)).nd.birthSize * (2 * cp.D2 + 1)) ∧
                      BuildStateInv cp pts' gt' (foldResiduals pts' (insert h_new (foldResiduals pts actH (st.serving.take r.val))) rRes.1) bs by
                rcases hgl_both with ⟨_, h1e, _, rfl⟩ | ⟨_, hgs1⟩
                · have hgl1' : rRes.1.getLast? = none := by rw [h1e]; rfl
                  rw [hgl1']; exact hgoal_norm
                · rw [hgs1]; exact hgoal_norm
              by_cases hr2 : rRes.2 = true
              · rw [if_pos hr2] at hr_fold1'
                dsimp only [phase₁]
                rw [if_pos hr2]
                cases hphase0 : jb.phase with
                | copy cs =>
                    rw [hphase0] at hph0_norm
                    rcases hph0_norm with ⟨hcur_lt, hL_le, hcs_inv⟩
                    dsimp only
                    rw [hprev_bsz, hr_fold1', hprev_pass hr2]
                    rcases copyState_liveInsert_spec h_new [h_new] hcs_inv with ⟨hL_eq, hcur_eq, hcs_inv'⟩
                    rw [hL_eq, hcur_eq]
                    exact ⟨hcur_lt, hL_le, hcs_inv'⟩
                | build bs =>
                    rw [hphase0] at hph0_norm
                    rcases hph0_norm with ⟨hins_lt, hL_le, hage_ins, hmc_rat, hbs_inv⟩
                    dsimp only
                    rw [hprev_bsz, hr_fold1']
                    rcases buildState_liveInsert_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hTend_sub
                      hnot_act pt hpts'_old (hbs_age0 bs hphase0) hbs_inv (getS1Seed cp ω₁ curIdx)
                      with ⟨hL', hsnap', hins', hbsz', hage', hbs_inv', _⟩
                    rw [hins', hsnap', hL', hage', hbsz']
                    refine ⟨hins_lt, hL_le, by linarith only [hage_ins], ?_, hbs_inv'⟩
                    by_cases hs0 : rRes.1.length = 0
                    · rw [dif_pos hs0]
                      have hs0' : jb.ready.length = 0 := by omega
                      rw [dif_pos hs0'] at hmc_rat; exact hmc_rat
                    · rw [dif_neg hs0]
                      have hs0' : ¬ jb.ready.length = 0 := by omega
                      rw [dif_neg hs0'] at hmc_rat
                      have hlast_bsz := (hr_el1 (jb.ready.length - 1) (by omega) (by omega)).2.2.1
                      have hget_eq : (rRes.1[rRes.1.length - 1]'(by omega)).nd.birthSize =
                          (jb.ready[jb.ready.length - 1]'(by omega)).nd.birthSize := by
                        have hidx : rRes.1.length - 1 = jb.ready.length - 1 := by omega
                        simp only [hidx]; exact hlast_bsz
                      rw [hget_eq]; exact hmc_rat
              · rw [if_neg hr2] at hr_fold1'
                dsimp only [phase₁]
                rw [if_neg hr2]
                cases hphase0 : jb.phase with
                | copy cs =>
                    rw [hphase0] at hph0_norm
                    rcases hph0_norm with ⟨hcur_lt, hL_le, hcs_inv⟩
                    dsimp only
                    rw [hprev_bsz, hr_fold1']
                    refine ⟨hcur_lt, hL_le, ?_⟩
                    rcases hprev_dic with heq_h | heq_app
                    · rwa [heq_h]
                    · rw [heq_app]; exact copyStateInv_append_right [h_new] hcs_inv
                | build bs =>
                    rw [hphase0] at hph0_norm
                    rcases hph0_norm with ⟨hins_lt, hL_le, hage_ins, hmc_rat, hbs_inv⟩
                    dsimp only
                    rw [hprev_bsz, hr_fold1']
                    have hbs_inv' := (buildStateInv_unchanged_insert hh0 hh1 hnot_act pt hpts'_old hTend_sub hbs_inv).1
                    refine ⟨hins_lt, hL_le, by omega, ?_, hbs_inv'⟩
                    by_cases hs0 : rRes.1.length = 0
                    · rw [dif_pos hs0]
                      have hs0' : jb.ready.length = 0 := by omega
                      rw [dif_pos hs0'] at hmc_rat; exact hmc_rat
                    · rw [dif_neg hs0]
                      have hs0' : ¬ jb.ready.length = 0 := by omega
                      rw [dif_neg hs0'] at hmc_rat
                      have hlast_bsz := (hr_el1 (jb.ready.length - 1) (by omega) (by omega)).2.2.1
                      have hget_eq : (rRes.1[rRes.1.length - 1]'(by omega)).nd.birthSize =
                          (jb.ready[jb.ready.length - 1]'(by omega)).nd.birthSize := by
                        have hidx : rRes.1.length - 1 = jb.ready.length - 1 := by omega
                        simp only [hidx]; exact hlast_bsz
                      rw [hget_eq]; exact hmc_rat
          · -- Update absorbed before anchor `r` (`passesNodes = false`)!
            have hcond_r : (r.val < st.serving.length && passesNodes pts' h_new (st.serving.take r.val)) = false := by
              cases hp_b : passesNodes pts' h_new (st.serving.take r.val)
              · simp
              · exact absurd hp_b hpass_r
            have hp_false : passesNodes pts' h_new (st.serving.take r.val) = false := by
              cases hp_b : passesNodes pts' h_new (st.serving.take r.val)
              · rfl
              · exact absurd hp_b hpass_r
            rw [htake_snd, hp_false, if_neg Bool.false_ne_true] at htake_fold
            have hanc_same : servRes.1[r.val]'hr1 = st.serving[r.val]'hr := by
              have haux : ∀ (idx k : ℕ) (ls : List (MNode cp)) (hk : k < ls.length),
                  passesNodes pts' h_new (ls.take k) = false →
                  ∀ hk' : k < (liveUpdateChainList cp pts' true h_new (getS1Seed cp ω₁) idx ls).1.length,
                    (liveUpdateChainList cp pts' true h_new (getS1Seed cp ω₁) idx ls).1[k]'hk' = ls[k]'hk := by
                intro idx k
                induction k generalizing idx with
                | zero => intro ls _ hpf; simp [passesNodes] at hpf
                | succ k' ih =>
                    intro ls hk hpf hk'
                    cases ls with
                    | nil => exact absurd hk (Nat.not_lt_zero _)
                    | cons hd tl =>
                        dsimp only [List.take_succ_cons, passesNodes, liveUpdateChainList] at hpf hk' ⊢
                        by_cases hcb : inCoreBall hd.nd.o hd.nd.V (pts' h_new) = true
                        · simp only [hcb]; rfl
                        · simp only [hcb, List.getElem_cons_succ]
                          have hnot_cb : (!inCoreBall hd.nd.o hd.nd.V (pts' h_new)) = true := by
                            cases hb : inCoreBall hd.nd.o hd.nd.V (pts' h_new)
                            · rfl
                            · exact absurd hb hcb
                          rw [hnot_cb, Bool.true_and] at hpf
                          exact ih (idx + 1) tl (Nat.lt_of_succ_lt_succ hk) hpf _
              exact haux 0 r.val st.serving hr hp_false hr1
            have hjb1_eq : st₁.jobs r = some jb := by
              dsimp [st₁, stepStage1]
              rw [hrh_getD, hjb0]
              dsimp only
              rw [if_neg (by rw [hcond_r]; decide)]
            rw [hjb1_eq]
            set anc1 := st₁.serving[r.val]'hr1_st
            have hanc1_eq : anc1 = st.serving[r.val]'hr := helem_serv1.trans hanc_same
            dsimp only [SuffixJobInvSlack]
            rw [hact'_eq, hst₁_hp, hst₁_gt, hanc1_eq, htake_serv1, htake_eq, htake_fold]
            rcases chainListInv_unchanged_insert hh0 hh1 hnot_act pt hpts'_old
              (foldResiduals pts actH (st.serving.take r.val)) jb.ready hS_anc_sub hcl_r0
              with ⟨hTend_same, hcl_r1, _⟩
            have hTend_sub : foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready ⊆ actH :=
              (chainListInv_getElem _ jb.ready hS_anc_sub hcl_r0).1
            refine ⟨hrs_lt, hcl_r1, fun q hq => ⟨(hrb0 q hq).1, (hrb0 q hq).2.1, by linarith only [(hrb0 q hq).2.2]⟩,
              by
                have hm := Nat.mul_le_mul_left (64 * K_alpha d)
                  (Nat.le_add_right (jb.ready.length * (48 * (st.serving[r.val]'hr).nd.birthSize) + jb.phase.lvlProg) cp.B_scan)
                linarith only [hanc_age0, hm], ?_⟩
            rw [hTend_same]
            cases hphase0 : jb.phase with
            | copy cs =>
                rw [hphase0] at hph0
                exact hph0
            | build bs =>
                rw [hphase0] at hph0
                rcases hph0 with ⟨hins_lt, hL_le, hage_ins, hmc_rat, hbs_inv⟩
                exact ⟨hins_lt, hL_le, by omega, hmc_rat,
                  (buildStateInv_unchanged_insert hh0 hh1 hnot_act pt hpts'_old hTend_sub hbs_inv).1⟩
    · rw [dif_neg hr1_st]
      have hr_not : ¬ r.val < st.serving.length := by rwa [hst₁_serv, hserv_len₁] at hr1_st
      have hnone0 := hjobs_wf r
      rw [dif_neg hr_not] at hnone0
      dsimp [st₁, stepStage1]
      rw [hnone0]
  · -- Leaf array invariant (`st₁.leafOverflow = false`)
    intro hov1
    rw [hst₁_ov] at hov1
    rcases hleaf_wf hov1 with ⟨hlf_nd, hlf_set, hlf_len⟩
    have hleaf_eq : st₁.leafArr =
        if servRes.2 && !st.leafOverflow then denseInsert h_new st.leafArr else st.leafArr := by
      dsimp [st₁, stepStage1]; rw [hrh_getD]
    rw [hact'_eq, hst₁_hp, hst₁_serv, hleaf_eq, hov1]
    by_cases hs2 : servRes.2 = true
    · rw [if_pos (by simp [hs2])]
      rw [if_pos hs2] at hserv_fold₁
      have hlf_sub : st.leafArr.toFinset ⊆ actH :=
        hlf_set ▸ (chainListInv_getElem actH st.serving (Finset.Subset.refl _) hserv_cl).1
      have hnot_lf : h_new ∉ st.leafArr.toFinset := fun hm => hnot_act (hlf_sub hm)
      rcases denseInsert_spec hlf_nd hnot_lf with ⟨hnd', hset'⟩
      have hlen' : (denseInsert h_new st.leafArr).length = st.leafArr.length + 1 := by
        unfold denseInsert; simp
      exact ⟨hnd', by rw [hset', hlf_set, hserv_fold₁], by omega⟩
    · rw [if_neg (by simp [hs2])]
      rw [if_neg hs2] at hserv_fold₁
      exact ⟨hlf_nd, by rw [hlf_set, hserv_fold₁], by omega⟩
  · -- `ChainEngineGood` preservation on `GoodStage1Coins`!
    have hserv_gd' : ChainListGood cp hh0 hh1 pts' gt' servRes.1 :=
      hserv_gd₁ hgd_serv0 (fun q hq => by
        simpa using GoodStage1Coins.serv hserv_len hcoins1 q hq)
    refine ⟨by rw [hst₁_ov]; exact hov0, ?_, ?_⟩
    · rw [hst₁_hp, hst₁_gt, hst₁_serv]; exact hserv_gd'
    · intro r hr1 jb₁ hjb1
      rw [hst₁_serv, hserv_len₁] at hr1
      cases hjb0 : st.jobs r with
      | none =>
          dsimp [st₁, stepStage1] at hjb1
          rw [hjb0] at hjb1; cases hjb1
      | some jb =>
          have hgd_jb0 := hgd_jobs0 r hr1 jb hjb0
          have hslot0 := hjobs_wf r
          rw [dif_pos hr1, hjb0] at hslot0
          have hMr0 : cp.B_scan < (st.serving[r.val]'hr1).nd.birthSize :=
            (chainListInv_mem_birthSize actH st.serving hserv_cl _ (List.getElem_mem hr1)).1
          rcases suffixJobInvSlack_bounds (Nat.zero_le _) hMr0 hslot0
            with ⟨hready_b0, _, _, hbs_age0⟩
          dsimp only [SuffixJobInv, SuffixJobInvSlack] at hslot0
          rcases hslot0 with ⟨hrs_lt, hcl_r0, _, _, hph0⟩
          have hS_anc_sub : foldResiduals pts actH (st.serving.take r.val) ⊆ actH :=
            (chainListInv_getElem actH st.serving (Finset.Subset.refl _) hserv_cl).2 r.val hr1 |>.1
          have hTend_sub : foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready ⊆ actH :=
            (chainListInv_getElem _ jb.ready hS_anc_sub hcl_r0).1
          rw [hst₁_hp, hst₁_gt]
          dsimp [st₁, stepStage1] at hjb1
          rw [hrh_getD, hjb0] at hjb1
          dsimp only at hjb1
          by_cases hcond_r : (r.val < st.serving.length && passesNodes pts' h_new (st.serving.take r.val)) = true
          · rw [if_pos hcond_r] at hjb1
            injection hjb1 with hjb1_eq; subst hjb1_eq
            have hready_age_le : ∀ u ∈ jb.ready, u.nd.age ≤ u.nd.birthSize := by
              intro u hu
              rcases List.mem_iff_getElem.mp hu with ⟨q, hq, rfl⟩
              have h128 := (hready_b0 q hq).1
              have hK := K_alpha_ge_36 d
              have : (jb.ready[q]'hq).nd.age ≤ 128 * K_alpha d * (jb.ready[q]'hq).nd.age := by
                simpa using Nat.mul_le_mul_right (jb.ready[q]'hq).nd.age (by omega : 1 ≤ 128 * K_alpha d)
              omega
            rcases liveUpdateChainList_insert_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hnot_act pt
              hpts'_new hpts'_old (fun q => getS1Seed cp ω₁ (cp.D_max + r.val * cp.D_max + q)) 0
              (foldResiduals pts actH (st.serving.take r.val)) jb.ready hS_anc_sub
              hready_age_le hcl_r0
              with ⟨_, _, _, _, hr_gd1⟩
            have hr_gd' := hr_gd1 hgd_jb0.1 (fun q hq => by
              simpa [Nat.zero_add] using GoodStage1Coins.ready hcoins1 r hjb0 hrs_lt q hq)
            refine ⟨hr_gd', ?_⟩
            dsimp only
            split_ifs with hr2
            · cases hphase0 : jb.phase with
              | copy _ => trivial
              | build bs =>
                  rw [hphase0] at hph0
                  have hgd_bs0 : LiveNodeGood cp hh0 hh1 pts st.gt bs.curNode := by
                    have := hgd_jb0.2; rwa [hphase0] at this
                  dsimp only [↓reduceIte]
                  exact (buildState_liveInsert_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hTend_sub
                    hnot_act pt hpts'_old (hbs_age0 bs hphase0) hph0.2.2.2.2
                    (getS1Seed cp ω₁ (cp.D_max + cp.D_max * cp.D_max + r.val))).2.2.2.2.2.2
                    hgd_bs0 (GoodStage1Coins.cur hcoins1 r hjb0 hphase0)
            · cases hphase0 : jb.phase with
              | copy _ => trivial
              | build bs =>
                  rw [hphase0] at hph0
                  have hgd_bs0 : LiveNodeGood cp hh0 hh1 pts st.gt bs.curNode := by
                    have := hgd_jb0.2; rwa [hphase0] at this
                  exact (buildStateInv_unchanged_insert hh0 hh1 hnot_act pt hpts'_old hTend_sub hph0.2.2.2.2).2 hgd_bs0
          · rw [if_neg hcond_r] at hjb1
            injection hjb1 with hjb1_eq; subst hjb1_eq
            rcases chainListInv_unchanged_insert hh0 hh1 hnot_act pt hpts'_old
              (foldResiduals pts actH (st.serving.take r.val)) jb.ready hS_anc_sub hcl_r0
              with ⟨_, _, hgd_r'⟩
            refine ⟨hgd_r' hgd_jb0.1, ?_⟩
            cases hphase0 : jb.phase with
            | copy _ => trivial
            | build bs =>
                rw [hphase0] at hph0
                have hgd_bs0 : LiveNodeGood cp hh0 hh1 pts st.gt bs.curNode := by
                  have := hgd_jb0.2; rwa [hphase0] at this
                exact (buildStateInv_unchanged_insert hh0 hh1 hnot_act pt hpts'_old hTend_sub hph0.2.2.2.2).2 hgd_bs0

end UL.Proof.clm_9_1_explicit_tradeoff.C14d1
