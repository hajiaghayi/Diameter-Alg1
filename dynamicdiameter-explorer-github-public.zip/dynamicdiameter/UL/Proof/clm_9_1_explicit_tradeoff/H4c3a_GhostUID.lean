import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_mc_baseline
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H4c1_NodePrim
import UL.Proof.clm_9_1_explicit_tradeoff.H4c2_ChainSched
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H4c3a

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2

/-! ### 1. Immutable Ghost UID Tracker (Prevents Handle-Reuse Coordinate Aliasing on `P₀`) -/

/-- Purely ghost proof state assigning each newly inserted point a fresh monotonic `uid : ℕ`
whose coordinate `ghostPts uid` is never overwritten even when physical handles `< n` are recycled. -/
structure GhostTracker (d : ℕ) where
  nextUid : ℕ
  uidOf : ℕ → ℕ
  ghostPts : ℕ → EuclideanSpace ℝ (Fin d)

def GhostTracker.empty (d : ℕ) : GhostTracker d :=
  { nextUid := 0, uidOf := fun _ => 0, ghostPts := fun _ => 0 }

noncomputable def GhostTracker.stepInsert {d : ℕ}
    (h_new : ℕ) (pt : EuclideanSpace ℝ (Fin d)) (gt : GhostTracker d) : GhostTracker d :=
  { nextUid := gt.nextUid + 1
    uidOf := Function.update gt.uidOf h_new gt.nextUid
    ghostPts := Function.update gt.ghostPts gt.nextUid pt }

def GhostTrackerWF {d : ℕ} (actHandles : Finset ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (gt : GhostTracker d) : Prop :=
  (∀ h ∈ actHandles, gt.uidOf h < gt.nextUid) ∧
  (∀ h₁ ∈ actHandles, ∀ h₂ ∈ actHandles, gt.uidOf h₁ = gt.uidOf h₂ → h₁ = h₂) ∧
  (∀ h ∈ actHandles, gt.ghostPts (gt.uidOf h) = pts h)

theorem ghostTracker_empty_wf (d : ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d)) :
    GhostTrackerWF ∅ pts (GhostTracker.empty d) :=
  ⟨fun _ h => absurd h (Finset.notMem_empty _),
   fun _ h => absurd h (Finset.notMem_empty _),
   fun _ h => absurd h (Finset.notMem_empty _)⟩

theorem ghostTracker_stepInsert_spec {d : ℕ}
    {actHandles : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {h_new : ℕ} (hnot : h_new ∉ actHandles) (pt : EuclideanSpace ℝ (Fin d))
    (hpts_new : pts' h_new = pt)
    (hpts_old : ∀ h ∈ actHandles, pts' h = pts h)
    {gt : GhostTracker d} (hwf : GhostTrackerWF actHandles pts gt) :
    let gt' := gt.stepInsert h_new pt
    gt.nextUid < gt'.nextUid ∧
    (∀ u < gt.nextUid, gt'.ghostPts u = gt.ghostPts u) ∧
    (∀ h ∈ actHandles, gt'.uidOf h = gt.uidOf h) ∧
    gt'.uidOf h_new = gt.nextUid ∧
    GhostTrackerWF (insert h_new actHandles) pts' gt' := by
  rcases hwf with ⟨hlt, hinj, hcoord⟩
  have hghost_old : ∀ u < gt.nextUid, (gt.stepInsert h_new pt).ghostPts u = gt.ghostPts u := by
    intro u hu
    have hne : u ≠ gt.nextUid := by omega
    dsimp [GhostTracker.stepInsert]
    exact Function.update_of_ne hne pt gt.ghostPts
  have huid_old : ∀ h ∈ actHandles, (gt.stepInsert h_new pt).uidOf h = gt.uidOf h := by
    intro h hh
    have hne : h ≠ h_new := fun heq => hnot (heq ▸ hh)
    dsimp [GhostTracker.stepInsert]
    exact Function.update_of_ne hne gt.nextUid gt.uidOf
  have huid_new : (gt.stepInsert h_new pt).uidOf h_new = gt.nextUid := by
    dsimp [GhostTracker.stepInsert]; exact Function.update_self h_new gt.nextUid gt.uidOf
  refine ⟨Nat.lt_succ_self _, hghost_old, huid_old, huid_new, ?_, ?_, ?_⟩
  · intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hx_old
    · rw [huid_new]; exact Nat.lt_succ_self _
    · rw [huid_old x hx_old]; exact Nat.lt_succ_of_lt (hlt x hx_old)
  · intro x₁ hx₁ x₂ hx₂ heq
    rcases Finset.mem_insert.mp hx₁ with rfl | hx₁_old
    · rcases Finset.mem_insert.mp hx₂ with rfl | hx₂_old
      · rfl
      · rw [huid_new, huid_old x₂ hx₂_old] at heq
        have := hlt x₂ hx₂_old; omega
    · rcases Finset.mem_insert.mp hx₂ with rfl | hx₂_old
      · rw [huid_old x₁ hx₁_old, huid_new] at heq
        have := hlt x₁ hx₁_old; omega
      · rw [huid_old x₁ hx₁_old, huid_old x₂ hx₂_old] at heq
        exact hinj x₁ hx₁_old x₂ hx₂_old heq
  · intro x hx
    rcases Finset.mem_insert.mp hx with rfl | hx_old
    · rw [huid_new, hpts_new]
      dsimp [GhostTracker.stepInsert]
      exact Function.update_self gt.nextUid pt gt.ghostPts
    · rw [huid_old x hx_old, hghost_old _ (hlt x hx_old), hcoord x hx_old, hpts_old x hx_old]

theorem ghostTracker_stepDelete_spec {d : ℕ}
    {actHandles : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    (h_del : ℕ)
    (hpts_old : ∀ h ∈ actHandles.erase h_del, pts' h = pts h)
    {gt : GhostTracker d} (hwf : GhostTrackerWF actHandles pts gt) :
    GhostTrackerWF (actHandles.erase h_del) pts' gt := by
  rcases hwf with ⟨hlt, hinj, hcoord⟩
  refine ⟨fun h hh => hlt h (Finset.mem_of_mem_erase hh),
    fun h₁ hh₁ h₂ hh₂ => hinj h₁ (Finset.mem_of_mem_erase hh₁) h₂ (Finset.mem_of_mem_erase hh₂),
    fun h hh => (hcoord h (Finset.mem_of_mem_erase hh)).trans (hpts_old h hh).symm⟩

theorem image_insert_uidOf {d : ℕ}
    {actHandles S : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hwf : GhostTrackerWF actHandles pts gt)
    (hS : S ⊆ actHandles) {h_new : ℕ} (hnot_act : h_new ∉ actHandles)
    (pt : EuclideanSpace ℝ (Fin d)) :
    let gt' := gt.stepInsert h_new pt
    gt.nextUid ∉ S.image gt.uidOf ∧
    (insert h_new S).image gt'.uidOf = insert gt.nextUid (S.image gt.uidOf) := by
  rcases hwf with ⟨hlt, _, _⟩
  refine ⟨?_, ?_⟩
  · intro hm
    rcases Finset.mem_image.mp hm with ⟨x, hxS, hx_eq⟩
    have := hlt x (hS hxS)
    omega
  · rw [Finset.image_insert]
    congr 1
    · dsimp [GhostTracker.stepInsert]; exact Function.update_self h_new gt.nextUid gt.uidOf
    · refine Finset.image_congr (fun x hxS => ?_)
      have hne : x ≠ h_new := fun heq => hnot_act (heq ▸ hS hxS)
      dsimp [GhostTracker.stepInsert]
      exact Function.update_of_ne hne gt.nextUid gt.uidOf

theorem image_erase_uidOf {d : ℕ}
    {actHandles S : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hwf : GhostTrackerWF actHandles pts gt)
    (hS : S ⊆ actHandles) {h_del : ℕ} (hmem : h_del ∈ S) :
    gt.uidOf h_del ∈ S.image gt.uidOf ∧
    (S.erase h_del).image gt.uidOf = (S.image gt.uidOf).erase (gt.uidOf h_del) := by
  refine ⟨Finset.mem_image_of_mem _ hmem, ?_⟩
  ext u
  simp only [Finset.mem_image, Finset.mem_erase]
  constructor
  · rintro ⟨x, ⟨hne, hxS⟩, rfl⟩
    exact ⟨fun heq => hne (hwf.2.1 x (hS hxS) h_del (hS hmem) heq), x, hxS, rfl⟩
  · rintro ⟨hne_u, x, hxS, rfl⟩
    exact ⟨x, ⟨fun heq => hne_u (heq ▸ rfl), hxS⟩, rfl⟩

theorem card_image_uidOf {d : ℕ}
    {actHandles S : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hwf : GhostTrackerWF actHandles pts gt) (hS : S ⊆ actHandles) :
    (S.image gt.uidOf).card = S.card :=
  Finset.card_image_of_injOn (fun x hx y hy hxy => hwf.2.1 x (hS hx) y (hS hy) hxy)

theorem isCenterpoint_congr_ghostPts {d : ℕ}
    {pts₁ pts₂ : ℕ → EuclideanSpace ℝ (Fin d)} {P₀ : Finset ℕ}
    (heq : ∀ u ∈ P₀, pts₂ u = pts₁ u) {α : ℝ} {z : EuclideanSpace ℝ (Fin (d + 1))}
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun u : P₀ => pts₁ u.1)) z) :
    IsCenterpoint α (paraboloidLiftSet (fun u : P₀ => pts₂ u.1)) z := by
  have hfn : (paraboloidLiftSet (fun u : P₀ => pts₂ u.1)) =
      (paraboloidLiftSet (fun u : P₀ => pts₁ u.1)) := by
    funext u
    simp only [paraboloidLiftSet, heq u.1 u.2]
  rwa [hfn]

/-! ### 2. Ghost-Transported Centerpoint, Residual Contraction & Baseline Sampling -/

/-- HPJ19 good-coin cardinality transported to `(gt.ghostPts, (arr.toFinset).image gt.uidOf)`! -/
theorem hpjCenter_good_via_ghost {d N_samp q_idx : ℕ}
    {actHandles : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hwf : GhostTrackerWF actHandles pts gt)
    {phiRat : ℚ} (hφ0 : 0 < (phiRat : ℝ)) (hφ1 : (phiRat : ℝ) < 1 / 2)
    {P_hpj : HPJParams} (hP : HPJParamProps d (phiRat : ℝ) P_hpj)
    (hmN : 2 ^ P_hpj.q ≤ N_samp)
    {arr : List ℕ} (hsz : 1 ≤ arr.length) (hnd : arr.Nodup)
    (hsub : arr.toFinset ⊆ actHandles) :
    let B_walk := P_hpj.L * (d + 1 + 3) * P_hpj.q
    let CoinT := HPJCoin N_samp q_idx B_walk
    let P₀_uid := arr.toFinset.image gt.uidOf
    open Classical in
    (1 - (phiRat : ℝ) - ((N_samp * arr.length : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) *
        (Fintype.card CoinT : ℝ) ≤
      ((Finset.univ.filter (fun cw : CoinT =>
        let os := evalHPJCenter P_hpj N_samp q_idx hmN pts arr cw
        IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => gt.ghostPts u.1))
          (liftedPoint os.1 os.2))).card : ℝ) := by
  let arr_uid := arr.map gt.uidOf
  have hlen_eq : arr_uid.length = arr.length := List.length_map _
  have hsz_uid : 1 ≤ arr_uid.length := (by omega)
  have hnd_uid : arr_uid.Nodup := by
    refine List.Nodup.map_on ?_ hnd
    intro x hx y hy hxy
    exact hwf.2.1 x (hsub (List.mem_toFinset.mpr hx)) y (hsub (List.mem_toFinset.mpr hy)) hxy
  let P₀_uid := arr.toFinset.image gt.uidOf
  have hP₀_eq : arr_uid.toFinset = P₀_uid := by ext u; simp [arr_uid, P₀_uid]
  have hbase := hpjCenter_good_card_ge (q_idx := q_idx) gt.ghostPts hφ0 hφ1 hP hmN hsz_uid hnd_uid hP₀_eq
  classical
  dsimp only at hbase ⊢
  have hfac_eq : ((N_samp * arr.length : ℕ) : ℝ) = ((N_samp * arr_uid.length : ℕ) : ℝ) := by
    rw [hlen_eq]
  rw [hfac_eq]
  refine hbase.trans (Nat.cast_le.mpr (Finset.card_le_card (fun cw hcw => ?_)))
  have hcp := (Finset.mem_filter.mp hcw).2
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ cw, ?_⟩
  unfold evalHPJCenter
  rw [dif_pos hsz]
  dsimp only
  rw [liftedPoint_liftedBase_liftedHeight]
  -- Show the `radonWalkOutput` inputs match identically!
  convert hcp using 2
  congr 1
  funext j
  simp only [arr_uid, List.length_map, List.getElem_map]
  have hlt_idx : (cw.1 ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩).val % arr.length < arr.length :=
    Nat.mod_lt _ hsz
  rw [hwf.2.2 _ (hsub (List.mem_toFinset.mpr (List.getElem_mem hlt_idx)))]

/-- Residual contraction transported from `(gt.ghostPts, P₀_uid, S.image gt.uidOf)` back to `(pts, S)`! -/
theorem residual_contraction_via_ghost
    (h_lem_5_1 : S_lem_5_1)
    {d : ℕ} {actHandles S : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hwf : GhostTrackerWF actHandles pts gt) (hS : S ⊆ actHandles)
    {P₀_uid : Finset ℕ} (hm : 1 ≤ P₀_uid.card)
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (hcp : IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => gt.ghostPts u.1))
      (liftedPoint o s))
    {age : ℕ} (hage : HasNodeAge P₀_uid (S.image gt.uidOf) age)
    (hage_int : 16 * K_alpha d * age ≤ P₀_uid.card) :
    let V := max 0 (liftVariance o s)
    V = liftVariance o s ∧
    ((nodeResidual pts o V S).card : ℝ) ≤ (1 - hpjAlpha d / 2) * (S.card : ℝ) ∧
    (K_alpha d < P₀_uid.card → S.image gt.uidOf = P₀_uid →
      (nodeResidual pts o V S).card + 1 ≤ P₀_uid.card) := by
  have hage_ub := age_real_le_of_int hage_int
  rcases residual_contraction_of_lem51 h_lem_5_1 gt.ghostPts hm (hpjAlpha_pos d) (hpjAlpha_le_one d)
    hcp hage hage_ub with ⟨hV_eq, hres_ub, hres_strict⟩
  let V := max 0 (liftVariance o s)
  have hS_card : (S.image gt.uidOf).card = S.card := card_image_uidOf hwf hS
  have hres_img : (nodeResidual pts o V S).image gt.uidOf =
      nodeResidual gt.ghostPts o V (S.image gt.uidOf) := by
    ext u
    unfold nodeResidual nodeCore
    simp only [Finset.mem_image, @Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter]
    constructor
    · rintro ⟨x, ⟨hxS, hnc⟩, rfl⟩
      refine ⟨⟨x, hxS, rfl⟩, ?_⟩
      rintro ⟨_, hcb⟩
      rw [hwf.2.2 x (hS hxS)] at hcb
      exact hnc ⟨hxS, hcb⟩
    · rintro ⟨⟨x, hxS, rfl⟩, hnc⟩
      refine ⟨x, ⟨hxS, ?_⟩, rfl⟩
      rintro ⟨_, hcb⟩
      apply hnc ⟨⟨x, hxS, rfl⟩, ?_⟩
      rwa [hwf.2.2 x (hS hxS)]
  have hres_sub : nodeResidual pts o V S ⊆ actHandles := by
    intro x hx
    unfold nodeResidual at hx
    rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx
    exact hS hx.1
  have hres_card : (nodeResidual gt.ghostPts o V (S.image gt.uidOf)).card =
      (nodeResidual pts o V S).card := by
    rw [← hres_img, card_image_uidOf hwf hres_sub]
  refine ⟨hV_eq, ?_, ?_⟩
  · rw [← hres_card, ← hS_card]
    exact hres_ub
  · intro hgt hSP
    have h1 := alpha_mul_gt_one_of_gt hgt
    have hst := hres_strict h1 hSP
    have hrc : (nodeResidual gt.ghostPts o (max 0 (liftVariance o s)) P₀_uid).card =
        (nodeResidual pts o (max 0 (liftVariance o s)) S).card := by
      dsimp only [V] at hres_card
      rw [← hSP, hres_card]
    omega

/-- Baseline good-coin cardinality transported via `gt.uidOf` back to `(pts, S, evalBaselinePair)`! -/
theorem baseline_good_via_ghost {d k_base q_idx T_pow : ℕ} (hk : 1 ≤ k_base)
    {ψ : ℝ} (hψ0 : 0 < ψ)
    (hmc : HasMCBaselineBound (hpjAlpha d) ψ k_base)
    {actHandles S : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} (hwf : GhostTrackerWF actHandles pts gt) (hS_act : S ⊆ actHandles)
    {P₀_uid : Finset ℕ} (hm : 1 ≤ P₀_uid.card)
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (hcp : IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => gt.ghostPts u.1))
      (liftedPoint o s))
    {age : ℕ} (hage : HasNodeAge P₀_uid (S.image gt.uidOf) age)
    (hage_int : 16 * K_alpha d * age ≤ P₀_uid.card)
    (hsub_T : ∀ x ∈ S, x < T_pow)
    {denseArr : List ℕ} (hnd : denseArr.Nodup) (hS : denseArr.toFinset = S) :
    let V := max 0 (liftVariance o s)
    let CoinB := Fin k_base → Fin (2 ^ q_idx)
    open Classical in
    (1 - ψ - ((k_base * denseArr.length : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) *
        (Fintype.card CoinB : ℝ) ≤
      ((Finset.univ.filter (fun u : CoinB =>
        SatisfiesNodeBaselineCond pts o V S (evalBaselinePair hk T_pow pts o denseArr u))).card : ℝ) := by
  haveI : Nonempty ↥P₀_uid := Finset.Nonempty.coe_sort (Finset.card_pos.mp hm)
  have hV_nn : 0 ≤ liftVariance o s := liftVariance_nonneg_of_isCenterpoint _ (hpjAlpha_pos d) hcp
  have hV_eq : max 0 (liftVariance o s) = liftVariance o s := max_eq_right hV_nn
  let CoinB := Fin k_base → Fin (2 ^ q_idx)
  rcases maxRadiusHandle_spec T_pow pts o (S := denseArr.toFinset) (by rw [hS]; exact hsub_T)
    with ⟨hemp_spec, hne_spec⟩
  by_cases hSne : S.Nonempty
  · have hArr_ne : denseArr.toFinset.Nonempty := by rwa [hS]
    rcases hne_spec hArr_ne with ⟨y, hmrh_eq, hy_max_arr⟩
    have hy_max : IsNodeMaxRadiusPoint pts o S y := by rwa [hS] at hy_max_arr
    let S_uid := S.image gt.uidOf
    have hS_uid_ne : S_uid.Nonempty := hSne.image _
    -- Transport `IsNodeMaxRadiusPoint` from `(pts, S, y)` to `(gt.ghostPts, S_uid, gt.uidOf y)`!
    have hrad_eq : nodeMaxRadius gt.ghostPts o S_uid = nodeMaxRadius pts o S := by
      unfold nodeMaxRadius
      rw [dif_pos hS_uid_ne, dif_pos hSne]
      apply le_antisymm
      · refine Finset.sup'_le hS_uid_ne _ (fun u hu => ?_)
        rcases Finset.mem_image.mp hu with ⟨x, hxS, rfl⟩
        rw [hwf.2.2 x (hS_act hxS)]
        exact Finset.le_sup' (fun i => ‖pts i - o‖) hxS
      · refine Finset.sup'_le hSne _ (fun x hxS => ?_)
        rw [← hwf.2.2 x (hS_act hxS)]
        exact Finset.le_sup' (fun i => ‖gt.ghostPts i - o‖) (Finset.mem_image_of_mem _ hxS)
    have hy_uid_max : IsNodeMaxRadiusPoint gt.ghostPts o S_uid (gt.uidOf y) := by
      refine ⟨Finset.mem_image_of_mem _ hy_max.1, ?_⟩
      rw [hrad_eq, hwf.2.2 y (hS_act hy_max.1)]
      exact hy_max.2
    have hsz : 1 ≤ denseArr.length := by
      rcases hArr_ne with ⟨z, hz⟩
      exact List.length_pos_of_mem (List.mem_toFinset.mp hz)
    let sz := denseArr.length
    have hsz_card : sz = S_uid.card := by
      rw [card_image_uidOf hwf hS_act, ← hS, List.toFinset_card_of_nodup hnd]
    let toSampUid : (Fin k_base → Fin sz) → (Fin k_base → ℕ) :=
      fun ω j => gt.uidOf (denseArr[(ω j).val])
    have htoSamp_inj : Function.Injective toSampUid := by
      intro ω₁ ω₂ heq
      funext j
      have hj_uid : gt.uidOf (denseArr[(ω₁ j).val]) = gt.uidOf (denseArr[(ω₂ j).val]) := congrFun heq j
      have hm1 : denseArr[(ω₁ j).val] ∈ actHandles :=
        hS_act ((Finset.subset_of_eq hS) (List.mem_toFinset.mpr (List.getElem_mem (ω₁ j).isLt)))
      have hm2 : denseArr[(ω₂ j).val] ∈ actHandles :=
        hS_act ((Finset.subset_of_eq hS) (List.mem_toFinset.mpr (List.getElem_mem (ω₂ j).isLt)))
      have hj := hwf.2.1 _ hm1 _ hm2 hj_uid
      exact Fin.ext ((List.Nodup.getElem_inj_iff hnd).mp hj)
    let samples := Fintype.piFinset (fun _ : Fin k_base => S_uid)
    have htoSamp_mem : ∀ ω : Fin k_base → Fin sz, toSampUid ω ∈ samples := by
      intro ω
      rw [Fintype.mem_piFinset]
      intro j
      exact Finset.mem_image_of_mem _ ((Finset.subset_of_eq hS) (List.mem_toFinset.mpr (List.getElem_mem (ω j).isLt)))
    have hsamples_card : samples.card = Fintype.card (Fin k_base → Fin sz) := by
      rw [Fintype.card_piFinset_const, Fintype.card_fun, Fintype.card_fin, Fintype.card_fin, hsz_card]
    have hmap_eq : (Finset.univ : Finset (Fin k_base → Fin sz)).map ⟨toSampUid, htoSamp_inj⟩ = samples := by
      apply Finset.eq_of_subset_of_card_le
      · intro s_fn hs
        rcases Finset.mem_map.mp hs with ⟨ω, _, rfl⟩
        exact htoSamp_mem ω
      · rw [Finset.card_map, Finset.card_univ, hsamples_card]
    let farthestUid : (Fin k_base → ℕ) → ℕ :=
      fun samp => samp (farthestIdxList gt.ghostPts (gt.uidOf y) samp ⟨0, hk⟩ (List.finRange k_base))
    have hfar_spec : ∀ samp ∈ samples,
        (∃ j : Fin k_base, farthestUid samp = samp j) ∧
        ∀ j : Fin k_base,
          ‖gt.ghostPts (samp j) - gt.ghostPts (gt.uidOf y)‖ ≤
            ‖gt.ghostPts (farthestUid samp) - gt.ghostPts (gt.uidOf y)‖ := by
      intro samp _
      refine ⟨⟨_, rfl⟩, fun j => ?_⟩
      have hsq := (farthestIdxList_spec gt.ghostPts (gt.uidOf y) samp ⟨0, hk⟩ (List.finRange k_base)).2
        j (List.mem_finRange j)
      have h1 : 0 ≤ ‖gt.ghostPts (samp j) - gt.ghostPts (gt.uidOf y)‖ := norm_nonneg _
      have h2 : 0 ≤ ‖gt.ghostPts (farthestUid samp) - gt.ghostPts (gt.uidOf y)‖ := norm_nonneg _
      nlinarith only [hsq, h1, h2]
    have hbad_div := hmc d gt.ghostPts P₀_uid S_uid age o s (gt.uidOf y) farthestUid
      hm hcp hage (age_real_le_of_int hage_int) hy_uid_max hfar_spec
    classical
    let BadPred : (Fin k_base → ℕ) → Prop :=
      fun samp => ¬ IsNodeBaselinePair gt.ghostPts o (liftVariance o s) S_uid (gt.uidOf y) (farthestUid samp)
    have hsc_pos : (0 : ℝ) < (samples.card : ℝ) := by
      rw [hsamples_card]
      haveI : Nonempty (Fin sz) := ⟨⟨0, hsz⟩⟩
      exact Nat.cast_pos.mpr Fintype.card_pos
    have hbad_le : ((samples.filter BadPred).card : ℝ) ≤ ψ * (Fintype.card (Fin k_base → Fin sz) : ℝ) := by
      have hmul := (div_le_iff₀ hsc_pos).mp hbad_div
      rwa [hsamples_card] at hmul
    have hbad_fin :
        (((Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => BadPred (toSampUid ω))).card : ℝ) =
          ((samples.filter BadPred).card : ℝ) := by
      rw [← hmap_eq, Finset.filter_map, Finset.card_map]
      rfl
    let GoodIdx : (Fin k_base → Fin sz) → Prop :=
      fun ω => IsNodeBaselinePair gt.ghostPts o (liftVariance o s) S_uid (gt.uidOf y) (farthestUid (toSampUid ω))
    have hpart_nat :
        ((Finset.univ : Finset (Fin k_base → Fin sz)).filter GoodIdx).card +
        ((Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => BadPred (toSampUid ω))).card =
          Fintype.card (Fin k_base → Fin sz) := by
      have hfeq : (Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => BadPred (toSampUid ω)) =
          (Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => ¬ GoodIdx ω) := by
        ext ω; rfl
      rw [hfeq, Finset.card_filter_add_card_filter_not, Finset.card_univ]
    have hpart_r :
        (((Finset.univ : Finset (Fin k_base → Fin sz)).filter GoodIdx).card : ℝ) +
        (((Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => BadPred (toSampUid ω))).card : ℝ) =
          (Fintype.card (Fin k_base → Fin sz) : ℝ) := by exact_mod_cast hpart_nat
    have hunif_good :
        (1 - ψ) * (Fintype.card (Fin k_base → Fin sz) : ℝ) ≤
          (((Finset.univ : Finset (Fin k_base → Fin sz)).filter GoodIdx).card : ℝ) := by
      have hsub_r : (1 - ψ) * (Fintype.card (Fin k_base → Fin sz) : ℝ) =
          (Fintype.card (Fin k_base → Fin sz) : ℝ) - ψ * (Fintype.card (Fin k_base → Fin sz) : ℝ) := by ring
      linarith only [hpart_r, hbad_fin, hbad_le, hsub_r]
    have hmod := modSample_good_card_ge (q_idx := q_idx) hsz GoodIdx hψ0.le hunif_good
    refine hmod.trans (Nat.cast_le.mpr (Finset.card_le_card (fun u hu => ?_)))
    let ω_u : Fin k_base → Fin sz := fun j => ⟨(u j).val % sz, Nat.mod_lt _ hsz⟩
    have hu_gd : IsNodeBaselinePair gt.ghostPts o (liftVariance o s) S_uid (gt.uidOf y)
        (farthestUid (toSampUid ω_u)) := (Finset.mem_filter.mp hu).2
    rcases hu_gd with ⟨_, _, hlen_sq_uid⟩
    -- Show `farthestIdxList` on `(pts, y)` picks the EXACT SAME index `best : Fin k_base`!
    let sampPhys : Fin k_base → ℕ := fun j => denseArr[(ω_u j).val]
    have hsamp_coord : ∀ j : Fin k_base, gt.ghostPts (toSampUid ω_u j) = pts (sampPhys j) := by
      intro j
      exact hwf.2.2 _ (hS_act ((Finset.subset_of_eq hS) (List.mem_toFinset.mpr (List.getElem_mem (ω_u j).isLt))))
    have hy_coord : gt.ghostPts (gt.uidOf y) = pts y := hwf.2.2 y (hS_act hy_max.1)
    have hbest_eq : ∀ (cur : Fin k_base) (ls : List (Fin k_base)),
        farthestIdxList gt.ghostPts (gt.uidOf y) (toSampUid ω_u) cur ls =
          farthestIdxList pts y sampPhys cur ls := by
      intro cur ls
      induction ls generalizing cur with
      | nil => rfl
      | cons j js ih =>
          dsimp only [farthestIdxList]
          simp only [hsamp_coord, hy_coord]
          exact ih _
    let best := farthestIdxList pts y sampPhys ⟨0, hk⟩ (List.finRange k_base)
    have hfar_eq : farthestUid (toSampUid ω_u) = gt.uidOf (sampPhys best) := by
      dsimp only [farthestUid]
      rw [hbest_eq]
    rw [hfar_eq, hsamp_coord best, hy_coord, hrad_eq] at hlen_sq_uid
    have hzS : sampPhys best ∈ S := (Finset.subset_of_eq hS) (List.mem_toFinset.mpr (List.getElem_mem (ω_u best).isLt))
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ u, ?_⟩
    have heval_eq : evalBaselinePair hk T_pow pts o denseArr u = some (y, sampPhys best) := by
      unfold evalBaselinePair
      rw [hmrh_eq]
      dsimp only
      rw [dif_pos hsz]
    rw [heval_eq, hV_eq]
    exact ⟨⟨hy_max.1, hzS⟩, fun _ => hlen_sq_uid⟩
  · classical
    have hS_emp : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hSne
    have hArr_emp : denseArr.toFinset = ∅ := by rw [hS, hS_emp]
    have hmrh_none : maxRadiusHandle T_pow pts o denseArr.toFinset = none := hemp_spec hArr_emp
    have hall_u : (Finset.univ : Finset CoinB).filter (fun u : CoinB =>
        SatisfiesNodeBaselineCond pts o (max 0 (liftVariance o s)) S
          (evalBaselinePair hk T_pow pts o denseArr u)) = Finset.univ := by
      apply Finset.filter_true_of_mem
      intro u _
      unfold evalBaselinePair
      rw [hmrh_none, hS_emp]
      exact ⟨rfl, fun hne => absurd hne Finset.not_nonempty_empty⟩
    change _ ≤ (((Finset.univ : Finset CoinB).filter (fun u : CoinB =>
      SatisfiesNodeBaselineCond pts o (max 0 (liftVariance o s)) S
        (evalBaselinePair hk T_pow pts o denseArr u))).card : ℝ)
    rw [hall_u, Finset.card_univ]
    have h1 : 1 - ψ - ((k_base * denseArr.length : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ))) ≤ 1 := by
      have hbias : 0 ≤ ((k_base * denseArr.length : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ))) := by positivity
      linarith only [hψ0, hbias]
    simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg (Fintype.card CoinB))

end UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
