import UL.Proof.clm_9_1_explicit_tradeoff.CG19_LayoutB
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 5. `NodeAndHPJRAMOps` Record & `EncChainEngine` State Layout -/

inductive NodeScalarField where
  | birthSize | age | denseLen | histLen | resLen
  deriving DecidableEq

inductive NodeArrKind where
  | dense | hist | res
  deriving DecidableEq

def evalNodeScalar {d : ℕ} {params : LocalScaleParams} {h : ℝ} {cp : ChainParams d params h}
    (mn : MNode cp) : NodeScalarField → ℕ
  | .birthSize => mn.nd.birthSize
  | .age => mn.nd.age
  | .denseLen => mn.nd.denseArr.length
  | .histLen => mn.histArr.length
  | .resLen => mn.resArr.length

def evalNodeArr {d : ℕ} {params : LocalScaleParams} {h : ℝ} {cp : ChainParams d params h}
    (mn : MNode cp) : NodeArrKind → List ℕ
  | .dense => mn.nd.denseArr
  | .hist => mn.histArr
  | .res => mn.resArr

/-- Clean interface packaging single-node RAM operations (`ManagedNode`) and `evalHPJCenter`,
owning word tables `9 .. TW - 2` and real tables `3 .. TR - 1`, reading coordinates from
`ptsRTbl = 1` and pre-drawn coins from `coinTbl = 5`. -/
structure NodeAndHPJRAMOps {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) where
  TW : ℕ
  hTW : 10 ≤ TW
  nodeWStride : ℕ
  BW : ℕ
  TR : ℕ
  hTR : 3 ≤ TR
  nodeRStride : ℕ
  BR : ℕ
  hBW_coins : cp.B_STEP + 16 ≤ BW
  hBW_meta : 16 + 9 * cp.D_max + cp.D_max * cp.D_max + 16 ≤ BW
  hBW_arr : (2 + 4 * cp.D_max) * S_stride cp + 16 ≤ BW
  hBW_scr : M_slots cp + 128 ≤ BW
  hBW_node : M_slots cp * nodeWStride ≤ BW
  hBR_pts : cp.n * d + 8 ≤ BR
  hBR_eng : d + 32 ≤ BR
  hBR_node : M_slots cp * nodeRStride ≤ BR
  C_open : ℕ
  C_ins : ℕ
  C_del : ℕ
  C_bump : ℕ
  C_ball : ℕ
  C_hpj : ℕ
  C_read : ℕ
  SlotsReady : ArithRAMMemory → Prop
  slotsReady_empty : SlotsReady ArithRAMMemory.empty
  slotsReady_ext : ∀ (m₁ m₂ : ArithRAMMemory),
    SlotsReady m₁ →
    (∀ t, 9 ≤ t → t < TW - 1 → ∀ i, wRead m₂ t i = wRead m₁ t i) →
    (∀ t, 3 ≤ t → t < TR → ∀ i, rRead m₂ t i = rRead m₁ t i) →
    SlotsReady m₂
  EncNode : MNode cp → ℕ → ArithRAMMemory → Prop
  encNode_ext : ∀ (mn : MNode cp) (slot : ℕ) (m₁ m₂ : ArithRAMMemory),
    EncNode mn slot m₁ →
    (∀ t, 9 ≤ t → t < TW - 1 → ∀ i, wRead m₂ t i = wRead m₁ t i) →
    (∀ t, 3 ≤ t → t < TR → ∀ i, rRead m₂ t i = rRead m₁ t i) →
    (∀ x ∈ mn.nd.curSet, x < cp.n → ∀ c : Fin d,
      rRead m₂ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) =
        rRead m₁ ptsRTbl (((x * d + c.val : ℕ) : ℤ))) →
    EncNode mn slot m₂
  openEmptyStmt : ℤ → ℤ → ArithRAMStmt
  insertMatStmt : ℤ → ℤ → ℤ → ArithRAMStmt
  deleteMatStmt : ℤ → ℤ → ℤ → ArithRAMStmt
  bumpAgeStmt : ℤ → ArithRAMStmt
  inCoreBallStmt : ℤ → ℤ → ℤ → ArithRAMStmt
  evalHPJCenterStmt : ℕ → ℤ → ℤ → ℤ → ArithRAMStmt
  readNodeScalarStmt : NodeScalarField → ℤ → ℤ → ArithRAMStmt
  readNodeArrElemStmt : NodeArrKind → ℤ → ℤ → ℤ → ArithRAMStmt
  containsNodeArrStmt : Bool → ℤ → ℤ → ℤ → ArithRAMStmt
  readCenterCoordStmt : ℤ → ℤ → ℤ → ArithRAMStmt
  readCfgStoredEdgeStmt : ℤ → Fin cp.N_cfg → ℤ → ℤ → ℤ → ArithRAMStmt
  zeroRand_openEmpty : ∀ sR mR, ZeroRandStmt (openEmptyStmt sR mR)
  zeroRand_insertMat : ∀ sR pR cR, ZeroRandStmt (insertMatStmt sR pR cR)
  zeroRand_deleteMat : ∀ sR pR cR, ZeroRandStmt (deleteMatStmt sR pR cR)
  zeroRand_bumpAge : ∀ sR, ZeroRandStmt (bumpAgeStmt sR)
  zeroRand_inCoreBall : ∀ sR pR oR, ZeroRandStmt (inCoreBallStmt sR pR oR)
  zeroRand_evalHPJCenter : ∀ aT aOR aLR cOR, ZeroRandStmt (evalHPJCenterStmt aT aOR aLR cOR)
  zeroRand_readNodeScalar : ∀ f sR oR, ZeroRandStmt (readNodeScalarStmt f sR oR)
  zeroRand_readNodeArrElem : ∀ k sR iR oR, ZeroRandStmt (readNodeArrElemStmt k sR iR oR)
  zeroRand_containsNodeArr : ∀ u sR xR oR, ZeroRandStmt (containsNodeArrStmt u sR xR oR)
  zeroRand_readCenterCoord : ∀ sR cR oRI, ZeroRandStmt (readCenterCoordStmt sR cR oRI)
  zeroRand_readCfgStoredEdge : ∀ sR c hR u1R u2R, ZeroRandStmt (readCfgStoredEdgeStmt sR c hR u1R u2R)
  openEmpty_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (slot m₀_sz : ℕ) (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (P₀ : Finset ℕ) (sR mR : ℤ),
    slot < M_slots cp → m₀_sz ≤ cp.n →
    0 ≤ sR → sR < 64 → 0 ≤ mR → mR < 64 →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    wRead m₀ engScrTbl mR = (m₀_sz : ℤ) →
    (∀ c : Fin d, rRead m₀ engRealTbl (16 + (c.val : ℤ)) = euclideanCoord o c) →
    rRead m₀ engRealTbl (16 + (d : ℤ)) = s →
    ExecDet TW BW TR BR inp (openEmptyStmt sR mR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        EncNode (ManagedNode.openEmpty cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b cp.N_cfg
          cp.T_cdf cp.p_coord o s P₀ m₀_sz) slot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ slot → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      C_open
  insertMat_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
    (slot p coinOff bound : ℕ) (seedBits : Fin cp.B_op → Bool) (sR pR cR : ℤ),
    slot < M_slots cp → p < cp.n → p ∉ mn.nd.curSet →
    (∀ x ∈ mn.nd.curSet, x < cp.n) →
    mn.histArr.length + 1 ≤ 4 * cp.n + 4 →
    mn.nd.maxTIns bound → bound + 1 < 2 ^ cp.L_p2 →
    ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts mn →
    coinOff + cp.B_op ≤ cp.B_STEP →
    0 ≤ sR → sR < 64 → 0 ≤ pR → pR < 64 → 0 ≤ cR → cR < 64 →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    EncNode mn slot m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    wRead m₀ engScrTbl pR = (p : ℤ) →
    wRead m₀ engScrTbl cR = (coinOff : ℤ) →
    (∀ x ∈ insert p mn.nd.curSet, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) →
    (∀ k : Fin cp.B_op, wRead m₀ coinTbl ((coinOff : ℤ) + (k.val : ℤ)) =
      if seedBits k then 1 else 0) →
    ExecDet TW BW TR BR inp (insertMatStmt sR pR cR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        EncNode (mn.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts p (bitsToOpSeedEquiv cp seedBits)) slot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ slot → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      C_ins
  deleteMat_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
    (slot p coinOff bound : ℕ) (seedBits : Fin cp.B_op → Bool) (sR pR cR : ℤ),
    slot < M_slots cp → p < cp.n → p ∈ mn.nd.curSet →
    (∀ x ∈ mn.nd.curSet, x < cp.n) →
    mn.histArr.length ≤ 4 * cp.n + 4 →
    mn.nd.maxTIns bound → bound + 1 < 2 ^ cp.L_p2 →
    ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts mn →
    coinOff + cp.B_op ≤ cp.B_STEP →
    0 ≤ sR → sR < 64 → 0 ≤ pR → pR < 64 → 0 ≤ cR → cR < 64 →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    EncNode mn slot m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    wRead m₀ engScrTbl pR = (p : ℤ) →
    wRead m₀ engScrTbl cR = (coinOff : ℤ) →
    (∀ x ∈ mn.nd.curSet, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) →
    (∀ k : Fin cp.B_op, wRead m₀ coinTbl ((coinOff : ℤ) + (k.val : ℤ)) =
      if seedBits k then 1 else 0) →
    ExecDet TW BW TR BR inp (deleteMatStmt sR pR cR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        EncNode (mn.deleteMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts p (bitsToOpSeedEquiv cp seedBits)) slot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ slot → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      C_del
  bumpAge_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot : ℕ) (sR : ℤ),
    slot < M_slots cp → mn.nd.age + 1 ≤ 4 * cp.n + 4 →
    0 ≤ sR → sR < 64 →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    EncNode mn slot m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    ExecDet TW BW TR BR inp (bumpAgeStmt sR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        EncNode mn.bumpAge slot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ slot → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      C_bump
  inCoreBall_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot p : ℕ) (pt : EuclideanSpace ℝ (Fin d)) (sR pR oR : ℤ),
    slot < M_slots cp → p < cp.n →
    0 ≤ sR → sR < 64 → 0 ≤ pR → pR < 64 → 0 ≤ oR → oR < 64 →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    EncNode mn slot m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    wRead m₀ engScrTbl pR = (p : ℤ) →
    (∀ c : Fin d, rRead m₀ ptsRTbl (((p * d + c.val : ℕ) : ℤ)) = euclideanCoord pt c) →
    ExecDet TW BW TR BR inp (inCoreBallStmt sR pR oR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        wRead m₁ engScrTbl oR = (if inCoreBall mn.nd.o mn.nd.V pt then 1 else 0) ∧
        (∀ mn' s', s' < M_slots cp → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ oR → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      C_ball
  evalHPJCenter_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (arr : List ℕ)
    (arrTbl : ℕ) (arrOff : ℤ) (coinOff : ℕ) (ctrBits : Fin cp.B_ctr → Bool)
    (aOR aLR cOR : ℤ),
    arrTbl < 8 → 1 ≤ arr.length → arr.length ≤ cp.n → (∀ x ∈ arr, x < cp.n) →
    0 ≤ arrOff → arrOff + (arr.length : ℤ) ≤ (BW : ℤ) →
    coinOff + cp.B_ctr ≤ cp.B_STEP →
    0 ≤ aOR → aOR < 64 → 0 ≤ aLR → aLR < 64 → 0 ≤ cOR → cOR < 64 →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    wRead m₀ engScrTbl aOR = arrOff →
    wRead m₀ engScrTbl aLR = (arr.length : ℤ) →
    wRead m₀ engScrTbl cOR = (coinOff : ℤ) →
    (∀ i (hi : i < arr.length), wRead m₀ arrTbl (arrOff + (i : ℤ)) = (arr[i]'hi : ℤ)) →
    (∀ x ∈ arr, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) →
    (∀ k : Fin cp.B_ctr, wRead m₀ coinTbl ((coinOff : ℤ) + (k.val : ℤ)) =
      if ctrBits k then 1 else 0) →
    let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts arr
      (bitsToCenterSeedEquiv cp ctrBits)
    ExecDet TW BW TR BR inp (evalHPJCenterStmt arrTbl aOR aLR cOR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        (∀ c : Fin d, rRead m₁ engRealTbl (16 + (c.val : ℤ)) = euclideanCoord os.1 c) ∧
        rRead m₁ engRealTbl (16 + (d : ℤ)) = os.2 ∧
        (∀ mn' s', s' < M_slots cp → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ t < 2, ∀ i, rRead m₁ t i = rRead m₀ t i) ∧
        rRead m₁ engRealTbl 0 = rRead m₀ engRealTbl 0)
      C_hpj
  readNodeScalar_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot : ℕ) (f : NodeScalarField) (sR oR : ℤ),
    slot < M_slots cp → 0 ≤ sR → sR < 64 → 0 ≤ oR → oR < 64 →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    EncNode mn slot m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    ExecDet TW BW TR BR inp (readNodeScalarStmt f sR oR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        wRead m₁ engScrTbl oR = (evalNodeScalar mn f : ℤ) ∧
        (∀ mn' s', s' < M_slots cp → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ oR → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      C_read
  readNodeArrElem_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot idx : ℕ) (k : NodeArrKind)
    (hidx : idx < (evalNodeArr mn k).length) (sR iR oR : ℤ),
    slot < M_slots cp → 0 ≤ sR → sR < 64 → 0 ≤ iR → iR < 64 → 0 ≤ oR → oR < 64 →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    EncNode mn slot m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    wRead m₀ engScrTbl iR = (idx : ℤ) →
    ExecDet TW BW TR BR inp (readNodeArrElemStmt k sR iR oR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        wRead m₁ engScrTbl oR = ((evalNodeArr mn k)[idx]'hidx : ℤ) ∧
        (∀ mn' s', s' < M_slots cp → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ oR → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      C_read
  containsNodeArr_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
    (slot x : ℕ) (useRes : Bool) (sR xR oR : ℤ),
    slot < M_slots cp → (∀ y ∈ mn.nd.curSet, y < cp.n) →
    ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts mn →
    0 ≤ sR → sR < 64 → 0 ≤ xR → xR < 64 → 0 ≤ oR → oR < 64 →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    EncNode mn slot m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    wRead m₀ engScrTbl xR = (x : ℤ) →
    ExecDet TW BW TR BR inp (containsNodeArrStmt useRes sR xR oR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        wRead m₁ engScrTbl oR =
          (if (if useRes then mn.resArr else mn.nd.denseArr).contains x then 1 else 0) ∧
        (∀ mn' s', s' < M_slots cp → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ oR → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      C_read
  readCenterCoord_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot : ℕ) (c : Fin d) (sR cR oRI : ℤ),
    slot < M_slots cp → 0 ≤ sR → sR < 64 → 0 ≤ cR → cR < 64 → 1 ≤ oRI → oRI < (BR : ℤ) →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    EncNode mn slot m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    wRead m₀ engScrTbl cR = (c.val : ℤ) →
    ExecDet TW BW TR BR inp (readCenterCoordStmt sR cR oRI) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        rRead m₁ engRealTbl oRI = euclideanCoord mn.nd.o c ∧
        (∀ mn' s', s' < M_slots cp → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ t < 2, ∀ i, rRead m₁ t i = rRead m₀ t i) ∧
        (∀ i, i ≠ oRI → rRead m₁ engRealTbl i = rRead m₀ engRealTbl i))
      C_read
  readCfgStoredEdge_spec : ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot : ℕ) (cfgIdx : Fin cp.N_cfg) (sR hR u1R u2R : ℤ),
    slot < M_slots cp →
    0 ≤ sR → sR < 64 → 0 ≤ hR → hR < 64 → 0 ≤ u1R → u1R < 64 → 0 ≤ u2R → u2R < 64 →
    hR ≠ u1R → hR ≠ u2R → u1R ≠ u2R →
    InFootprint TW BW TR BR m₀ →
    SlotsReady m₀ →
    EncNode mn slot m₀ →
    wRead m₀ engScrTbl sR = (slot : ℤ) →
    ExecDet TW BW TR BR inp (readCfgStoredEdgeStmt sR cfgIdx hR u1R u2R) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        (match (mn.nd.cfgs cfgIdx).st.storedEdge with
         | none => wRead m₁ engScrTbl hR = 0
         | some (u, v) =>
             wRead m₁ engScrTbl hR = 1 ∧
             wRead m₁ engScrTbl u1R = (u : ℤ) ∧
             wRead m₁ engScrTbl u2R = (v : ℤ)) ∧
        (∀ mn' s', s' < M_slots cp → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ hR → i ≠ u1R → i ≠ u2R → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      C_read

/-- Encoding of cached diameter answer in both header registers (`heap 0 [1..3]`, `realHeap 0 0`)
and shadow registers (`engMetaTbl[3..5]`, `engRealTbl[0]`). -/
def EncCachedAns (ans : StoredDiameterAnswer) (mem : ArithRAMMemory) : Prop :=
  ArithRAMDynamicProgram.readCachedAnswer mem = (ans.diameterHandles, ans.cachedDistSq) ∧
  rRead mem engRealTbl 0 = ans.cachedDistSq ∧
  match ans.diameterHandles with
  | none =>
      wRead mem engMetaTbl 3 = 0 ∧
      wRead mem engMetaTbl 4 = 0 ∧
      wRead mem engMetaTbl 5 = 0
  | some (u, v) =>
      wRead mem engMetaTbl 3 = 1 ∧
      wRead mem engMetaTbl 4 = (u : ℤ) ∧
      wRead mem engMetaTbl 5 = (v : ℤ)

/-- Encoding of one job slot `r : Fin cp.D_max` (`st.jobs r`) with physical node slots
`rSlots` (for `jb.ready`) and `cSlot` (for `bs.curNode`). -/
def EncJobSlot {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max) (jbOpt : Option (SuffixJob cp))
    (rSlots : List ℕ) (cSlot : ℕ) (mem : ArithRAMMemory) : Prop :=
  let base := jobMetaBase cp r.val
  match jbOpt with
  | none =>
      rSlots = [] ∧
      wRead mem engMetaTbl base = 0
  | some jb =>
      wRead mem engMetaTbl base = 1 ∧
      jb.ready.length ≤ cp.D_max ∧
      rSlots.length = jb.ready.length ∧
      wRead mem engMetaTbl (base + 1) = (jb.ready.length : ℤ) ∧
      (∀ q (hq : q < jb.ready.length) (hqs : q < rSlots.length),
        wRead mem engMetaTbl (readySlotOff cp r.val q) = (rSlots[q]'hqs : ℤ) ∧
        ops.EncNode (jb.ready[q]'hq) (rSlots[q]'hqs) mem) ∧
      match jb.phase with
      | .copy cs =>
          wRead mem engMetaTbl (base + 2) = 0 ∧
          wRead mem engMetaTbl (base + 3) = (cs.L_hist : ℤ) ∧
          wRead mem engMetaTbl (base + 4) = (cs.copyCur : ℤ) ∧
          EncSparseSet cp.n (base + 5) (snapElemOff cp r.val) (snapPosOff cp r.val) cs.snapArr mem
      | .build bs =>
          wRead mem engMetaTbl (base + 2) = 1 ∧
          wRead mem engMetaTbl (base + 3) = (bs.L_hist : ℤ) ∧
          wRead mem engMetaTbl (base + 4) = (bs.insCur : ℤ) ∧
          EncSparseSet cp.n (base + 5) (snapElemOff cp r.val) (snapPosOff cp r.val) bs.snapArr mem ∧
          EncSparseSet cp.n (base + 6) (delSnapElemOff cp r.val) (delSnapPosOff cp r.val)
            bs.delSnapArr mem ∧
          wRead mem engMetaTbl (base + 7) = (cSlot : ℤ) ∧
          ops.EncNode bs.curNode cSlot mem

def jobUsedSlots {d : ℕ} {params : LocalScaleParams} {h : ℝ} {cp : ChainParams d params h}
    (jbOpt : Option (SuffixJob cp)) (rSlots : List ℕ) (cSlot : ℕ) : List ℕ :=
  match jbOpt with
  | none => []
  | some jb =>
      match jb.phase with
      | .copy _ => rSlots
      | .build _ => rSlots ++ [cSlot]

/-- Master RAM encoding of `ChainEngineState cp` (purely value-based on `wRead`/`rRead` outside
`coinTbl = 5` and `engScrTbl = 8`, so `drawCoinsStmt` frames trivially). -/
def EncChainEngine {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (st : ChainEngineState cp) (mem : ArithRAMMemory) : Prop :=
  ops.SlotsReady mem ∧
  EncHandlePool st.hp mem ∧
  EncCachedAns st.cachedAns mem ∧
  wRead mem engMetaTbl 1 = (if st.leafOverflow then 1 else 0) ∧
  st.leafArr.length ≤ cp.B_scan + 1 ∧
  EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) st.leafArr mem ∧
  st.serving.length ≤ cp.D_max ∧
  wRead mem engMetaTbl 0 = (st.serving.length : ℤ) ∧
  ∃ (servSlots : List ℕ) (readySlots : Fin cp.D_max → List ℕ) (curSlots : Fin cp.D_max → ℕ),
    servSlots.length = st.serving.length ∧
    (∀ i (hi : i < st.serving.length) (his : i < servSlots.length),
      wRead mem engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ) ∧
      ops.EncNode (st.serving[i]'hi) (servSlots[i]'his) mem) ∧
    (∀ r : Fin cp.D_max, EncJobSlot ops r (st.jobs r) (readySlots r) (curSlots r) mem) ∧
    let allSlots := servSlots ++
      (List.finRange cp.D_max).flatMap (fun r => jobUsedSlots (st.jobs r) (readySlots r) (curSlots r))
    allSlots.Nodup ∧
    (∀ s ∈ allSlots, s < M_slots cp)

theorem encChainEngine_empty {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    EncChainEngine ops (ChainEngineState.empty cp) ArithRAMMemory.empty := by
  refine ⟨ops.slotsReady_empty, encHandlePool_empty d cp.n,
    ?_, ?_, Nat.zero_le _, ?_, Nat.zero_le _, ?_, [], fun _ => [], fun _ => 0, rfl, ?_, ?_, ?_, ?_⟩
  · refine ⟨?_, ?_, ?_, ?_, ?_⟩ <;>
      simp [ChainEngineState.empty, ArithRAMDynamicProgram.readCachedAnswer, wRead, rRead,
        ArithRAMMemory.empty, WordStore.empty, WordStore.read, RealStore.empty, RealStore.read]
  · simp [ChainEngineState.empty, wRead, ArithRAMMemory.empty, WordStore.empty, WordStore.read]
  · refine ⟨List.nodup_nil, fun _ h => absurd h List.not_mem_nil, ?_, fun _ h => absurd h (Nat.not_lt_zero _)⟩
    simp [ChainEngineState.empty, wRead, ArithRAMMemory.empty, WordStore.empty, WordStore.read]
  · simp [ChainEngineState.empty, wRead, ArithRAMMemory.empty, WordStore.empty, WordStore.read]
  · intro _ h; exact absurd h (Nat.not_lt_zero _)
  · intro r
    simp [EncJobSlot, ChainEngineState.empty, wRead, ArithRAMMemory.empty, WordStore.empty, WordStore.read]
  · have hnil : (List.finRange cp.D_max).flatMap (fun _ => ([] : List ℕ)) = [] := by simp
    simp [ChainEngineState.empty, jobUsedSlots, hnil]
  · intro s hs
    have hnil : (List.finRange cp.D_max).flatMap (fun _ => ([] : List ℕ)) = [] := by simp
    simp [ChainEngineState.empty, jobUsedSlots, hnil] at hs

theorem encCachedAns_ext {ans : StoredDiameterAnswer} {m₀ m₁ : ArithRAMMemory}
    (ha : EncCachedAns ans m₀)
    (hw0 : ∀ i, wRead m₁ 0 i = wRead m₀ 0 i)
    (hw6 : ∀ i, wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i)
    (hr0 : rRead m₁ 0 0 = rRead m₀ 0 0)
    (hr2 : rRead m₁ engRealTbl 0 = rRead m₀ engRealTbl 0) :
    EncCachedAns ans m₁ := by
  rcases ha with ⟨hread, hr_sh, hmatch⟩
  have hread₁ : ArithRAMDynamicProgram.readCachedAnswer m₁ =
      ArithRAMDynamicProgram.readCachedAnswer m₀ := by
    have h01 : m₁.words.read (.heap 0 1) = m₀.words.read (.heap 0 1) := hw0 1
    have h02 : m₁.words.read (.heap 0 2) = m₀.words.read (.heap 0 2) := hw0 2
    have h03 : m₁.words.read (.heap 0 3) = m₀.words.read (.heap 0 3) := hw0 3
    have hr00 : m₁.reals.read (.heap 0 0) = m₀.reals.read (.heap 0 0) := hr0
    unfold ArithRAMDynamicProgram.readCachedAnswer
    simp only [h01, h02, h03, hr00]
  refine ⟨hread₁.trans hread, hr2.trans hr_sh, ?_⟩
  cases hd : ans.diameterHandles with
  | none =>
      simp only [hd] at hmatch
      exact ⟨(hw6 3).trans hmatch.1, (hw6 4).trans hmatch.2.1, (hw6 5).trans hmatch.2.2⟩
  | some uv =>
      rcases uv with ⟨u, v⟩
      simp only [hd] at hmatch
      exact ⟨(hw6 3).trans hmatch.1, (hw6 4).trans hmatch.2.1, (hw6 5).trans hmatch.2.2⟩

theorem encJobSlot_ext {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {r : Fin cp.D_max} {jbOpt : Option (SuffixJob cp)} {rSlots : List ℕ} {cSlot : ℕ}
    {m₀ m₁ : ArithRAMMemory}
    (hj : EncJobSlot ops r jbOpt rSlots cSlot m₀)
    (hw6 : ∀ i, wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i)
    (hw7 : ∀ i, wRead m₁ engArrTbl i = wRead m₀ engArrTbl i)
    (hnd : ∀ mn s, ops.EncNode mn s m₀ → ops.EncNode mn s m₁) :
    EncJobSlot ops r jbOpt rSlots cSlot m₁ := by
  cases jbOpt with
  | none =>
      exact ⟨hj.1, (hw6 _).trans hj.2⟩
  | some jb =>
      rcases hj with ⟨hact, hrle, hrlen, hwlen, hready, hph⟩
      refine ⟨(hw6 _).trans hact, hrle, hrlen, (hw6 _).trans hwlen,
        fun q hq hqs => ⟨(hw6 _).trans (hready q hq hqs).1, hnd _ _ (hready q hq hqs).2⟩, ?_⟩
      cases hjp : jb.phase with
      | copy cs =>
          simp only [hjp] at hph
          rcases hph with ⟨hp2, hp3, hp4, hsp⟩
          exact ⟨(hw6 _).trans hp2, (hw6 _).trans hp3, (hw6 _).trans hp4,
            hsp.ext (hw6 _) (fun _ _ => hw7 _) (fun _ _ => hw7 _)⟩
      | build bs =>
          simp only [hjp] at hph
          rcases hph with ⟨hp2, hp3, hp4, hsp, hdsp, hcslot, hcenc⟩
          exact ⟨(hw6 _).trans hp2, (hw6 _).trans hp3, (hw6 _).trans hp4,
            hsp.ext (hw6 _) (fun _ _ => hw7 _) (fun _ _ => hw7 _),
            hdsp.ext (hw6 _) (fun _ _ => hw7 _) (fun _ _ => hw7 _),
            (hw6 _).trans hcslot, hnd _ _ hcenc⟩

/-- Direct match for `CG20_Bridge.StepChainRAMSpec.enc_frame_coins` (`coinTbl = 5`, `scratchTbl = 8`). -/
theorem encChainEngine_frame_coins {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (st : ChainEngineState cp) (m₀ m₁ : ArithRAMMemory)
    (henc : EncChainEngine ops st m₀)
    (hw : ∀ tbl idx, tbl ≠ coinTbl → tbl ≠ engScrTbl → wRead m₁ tbl idx = wRead m₀ tbl idx)
    (hr : ∀ tbl idx, rRead m₁ tbl idx = rRead m₀ tbl idx) :
    EncChainEngine ops st m₁ := by
  rcases henc with ⟨hsr, hhp, hans, hov, hleaf_le, hleaf_sp, hserv_le, hserv_len,
    servSlots, readySlots, curSlots, hslen, hserv, hjobs, hnodup, hlt⟩
  have hw0 : ∀ i, wRead m₁ 0 i = wRead m₀ 0 i := fun i => hw 0 i (by decide) (by decide)
  have hw1 : ∀ i, wRead m₁ 1 i = wRead m₀ 1 i := fun i => hw 1 i (by decide) (by decide)
  have hw2 : ∀ i, wRead m₁ 2 i = wRead m₀ 2 i := fun i => hw 2 i (by decide) (by decide)
  have hw3 : ∀ i, wRead m₁ 3 i = wRead m₀ 3 i := fun i => hw 3 i (by decide) (by decide)
  have hw6 : ∀ i, wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i :=
    fun i => hw engMetaTbl i (by decide) (by decide)
  have hw7 : ∀ i, wRead m₁ engArrTbl i = wRead m₀ engArrTbl i :=
    fun i => hw engArrTbl i (by decide) (by decide)
  have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m₁ t i = wRead m₀ t i :=
    fun t ht9 _ i => hw t i (by unfold coinTbl; omega) (by unfold engScrTbl; omega)
  have hnd : ∀ mn s, ops.EncNode mn s m₀ → ops.EncNode mn s m₁ :=
    fun mn s he => ops.encNode_ext mn s m₀ m₁ he hw9 (fun t _ _ i => hr t i)
      (fun _ _ _ _ => hr ptsRTbl _)
  refine ⟨ops.slotsReady_ext m₀ m₁ hsr hw9 (fun t _ _ i => hr t i),
    ⟨(hw0 4).trans hhp.1, (hw0 5).trans hhp.2.1, (hw0 6).trans hhp.2.2.1,
     fun i hi => (hw1 _).trans (hhp.2.2.2.1 i hi),
     fun i hi => ⟨(hw2 _).trans (hhp.2.2.2.2.1 i hi).1, (hw3 _).trans (hhp.2.2.2.2.1 i hi).2⟩,
     fun x hx c => (hr ptsRTbl _).trans (hhp.2.2.2.2.2 x hx c)⟩,
    encCachedAns_ext hans hw0 hw6 (hr 0 0) (hr engRealTbl 0),
    (hw6 1).trans hov,
    hleaf_le,
    hleaf_sp.ext (hw6 2) (fun _ _ => hw7 _) (fun _ _ => hw7 _),
    hserv_le,
    (hw6 0).trans hserv_len,
    servSlots, readySlots, curSlots, hslen,
    fun i hi his => ⟨(hw6 _).trans (hserv i hi his).1, hnd _ _ (hserv i hi his).2⟩,
    fun r => encJobSlot_ext (hjobs r) hw6 hw7 hnd,
    hnodup, hlt⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG19
