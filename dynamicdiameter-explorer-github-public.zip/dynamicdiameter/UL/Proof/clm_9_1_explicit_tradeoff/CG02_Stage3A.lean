import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage30
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H1
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
open UL.Proof.clm_9_1_explicit_tradeoff.CG20

/-! ### 1. Branch 1 (`truncateAtStage3Stmt`): Truncate Chain & Copy `denseArr` to Leaf -/

def truncateAtStage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 10) (.readHeap engMetaTbl (.lit (servSlotOff r.val))))
  (.seq (copyNodeDenseToLeafStmt ops 10)
  (.seq (.writeWordHeap engMetaTbl (.lit 1) (.lit 0))
  (.seq (.writeWordHeap engMetaTbl (.lit 0) (.lit (r.val : ℤ)))
        (clearJobsFromStmt cp r))))

theorem zeroRand_truncateAtStage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (truncateAtStage3Stmt ops r) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_copyNodeDenseToLeafStmt ops 10)
      (.seq (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _)
              (zeroRand_clearJobsFromStmt cp r))))

def C_truncateStage3 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  117 + ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12

private lemma readySlotOff_ne_jobMetaBase {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (rr rk : Fin cp.D_max) {q : ℕ} (hq : q < cp.D_max)
    {j : ℤ} (hj0 : 0 ≤ j) (hj7 : j ≤ 7) :
    readySlotOff cp rr.val q ≠ jobMetaBase cp rk.val + j := by
  have hrr := rr.isLt
  have hrk := rk.isLt
  have hprod_nonneg : 0 ≤ (rr.val : ℤ) * (cp.D_max : ℤ) :=
    mul_nonneg (Int.natCast_nonneg _) (Int.natCast_nonneg _)
  unfold readySlotOff jobMetaBase
  omega

theorem exec_truncateAtStage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {cur : ChainEngineState cp} {m₀ : ArithRAMMemory}
    (hr : r.val < cur.serving.length)
    (hsd : ServingDenseWF cp cur)
    (hsmall : (cur.serving[r.val]'hr).nd.denseArr.length ≤ cp.B_scan)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops cur m₀) :
    let mn := cur.serving[r.val]'hr
    let nxt : ChainEngineState cp :=
      { cur with
        serving := cur.serving.take r.val
        jobs := fun rr => if rr.val < r.val then cur.jobs rr else none
        leafArr := mn.nd.denseArr
        leafOverflow := false }
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (truncateAtStage3Stmt ops r) m₀
      (fun m₁ =>
        EncChainEngine ops nxt m₁ ∧
        (∀ t < 6, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ rt < 3, ∀ i, rRead m₁ rt i = rRead m₀ rt i))
      (C_truncateStage3 ops) := by
  have hTW := ops.hTW
  have hBW_scr := ops.hBW_scr
  have hBW_meta := ops.hBW_meta
  let mn := cur.serving[r.val]'hr
  rcases hsd mn (List.getElem_mem hr) with ⟨hnd_dense, hdense_n⟩
  rcases henc₀ with ⟨hsr₀, hhp₀, hans₀, _, _, _, hserv_le₀, _,
    servSlots, readySlots, curSlots, hslen₀, hserv₀, hjobs₀, hall_nd, hall_lt⟩
  have hrs : r.val < servSlots.length := hslen₀.symm ▸ hr
  let cSlot := servSlots[r.val]'hrs
  have hcSlot_lt : cSlot < M_slots cp :=
    hall_lt cSlot (List.mem_append_left _ (List.getElem_mem hrs))
  unfold truncateAtStage3Stmt C_truncateStage3
  -- Step 1: Load `cSlot` into `engScrTbl[10]`
  refine ExecDet.seq' (105 + ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 10) (.readHeap engMetaTbl (.lit (servSlotOff r.val)))
      10 (cSlot : ℤ) hfp₀ (by unfold engScrTbl; omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) rfl
      (by simp only [evalIntExpr]; exact (hserv₀ r.val hr hrs).1)
      (by simp [intExprOps]) rfl)
    (by nlinarith) ?_
  intro m₁ hm₁ hfp₁; subst hm₁
  let m₁_st := H3a.wWrite m₀ engScrTbl 10 (cSlot : ℤ)
  have hw9_1 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m₁_st t i = wRead m₀ t i :=
    fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
  have hr_1 : ∀ t i, rRead m₁_st t i = rRead m₀ t i :=
    fun t i => rRead_wWrite _ _ _ _ _ _
  have hsr₁ : ops.SlotsReady m₁_st :=
    ops.slotsReady_ext m₀ m₁_st hsr₀ hw9_1 (fun t _ _ i => hr_1 t i)
  have hnd₁ : ∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m₁_st :=
    fun mn' s _ he => ops.encNode_ext mn' s m₀ m₁_st he hw9_1 (fun t _ _ i => hr_1 t i)
      (fun _ _ _ _ => hr_1 ptsRTbl _)
  -- Step 2: Copy `mn.nd.denseArr` into leaf sparse set
  refine ExecDet.seq' (25 + cp.D_max * 12)
    (exec_copyNodeDenseToLeafStmt ops inp 10 (by omega) (by omega) hcSlot_lt
      hfp₁ hsr₁ (hnd₁ mn cSlot hcSlot_lt (hserv₀ r.val hr hrs).2)
      (wRead_wWrite_self _ _ _ _) hnd_dense hdense_n hsmall)
    (by nlinarith) ?_
  intro m₂ ⟨hsr₂, hleaf_sp₂, hnd₂, hft₂, hfm₂, hfa₂, _, hfr₂⟩ hfp₂
  -- Step 3: Set `leafOverflow := false` (`engMetaTbl[1] := 0`)
  refine ExecDet.seq' (13 + cp.D_max * 12)
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 1) (.lit 0) 1 0
      hfp₂ (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl
      (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₃ hm₃ hfp₃; subst hm₃
  -- Step 4: Set `serving.length := r.val` (`engMetaTbl[0] := r.val`)
  refine ExecDet.seq' (1 + cp.D_max * 12)
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit 0) (.lit (r.val : ℤ)) 0 (r.val : ℤ)
      hfp₃ (by unfold engMetaTbl; omega) (by omega) (by omega) rfl rfl
      (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₄ hm₄ hfp₄; subst hm₄
  let m₄_st := H3a.wWrite (H3a.wWrite m₂ engMetaTbl 1 0) engMetaTbl 0 (r.val : ℤ)
  -- Step 5: Clear `jobMetaBase cp rr` for `r.val ≤ rr.val`
  refine (exec_clearJobsFromStmt ops inp r hfp₄).mono ?_ le_rfl
  intro m₅ ⟨hclr₅, hpres6_₅, hpresT_₅, hpresR_₅⟩ _
  -- Establish frame facts on `m₅`
  have hw9_25 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m₅ t i = wRead m₂ t i := by
    intro t ht9 _ i
    have ht_ne : t ≠ engMetaTbl := by unfold engMetaTbl; omega
    exact (hpresT_₅ t ht_ne i).trans
      ((wRead_wWrite_of_ne _ _ (Or.inl ht_ne)).trans (wRead_wWrite_of_ne _ _ (Or.inl ht_ne)))
  have hr_25 : ∀ t i, rRead m₅ t i = rRead m₂ t i := by
    intro t i
    exact (hpresR_₅ t i).trans (by simp [m₄_st])
  have hsr₅ : ops.SlotsReady m₅ :=
    ops.slotsReady_ext m₂ m₅ hsr₂ hw9_25 (fun t _ _ i => hr_25 t i)
  have hnd₀₅ : ∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m₅ :=
    fun mn' s hs he => ops.encNode_ext mn' s m₂ m₅ (hnd₂ mn' s hs (hnd₁ mn' s hs he))
      hw9_25 (fun t _ _ i => hr_25 t i) (fun _ _ _ _ => hr_25 ptsRTbl _)
  have hw_lt6 : ∀ t < 6, ∀ i, wRead m₅ t i = wRead m₀ t i := by
    intro t ht6 i
    have ht_ne6 : t ≠ engMetaTbl := by unfold engMetaTbl; omega
    have ht_ne7 : t ≠ engArrTbl := by unfold engArrTbl; omega
    have ht_ne8 : t ≠ engScrTbl := by unfold engScrTbl; omega
    exact (hpresT_₅ t ht_ne6 i).trans
      ((wRead_wWrite_of_ne _ _ (Or.inl ht_ne6)).trans
        ((wRead_wWrite_of_ne _ _ (Or.inl ht_ne6)).trans
          ((hft₂ t (by omega) ht_ne6 ht_ne7 ht_ne8 i).trans
            (wRead_wWrite_of_ne _ _ (Or.inl ht_ne8)))))
  have hr_lt3 : ∀ rt < 3, ∀ i, rRead m₅ rt i = rRead m₀ rt i := by
    intro rt hrt i
    exact (hr_25 rt i).trans ((hfr₂ rt hrt i).trans (hr_1 rt i))
  have hw7_25 : ∀ i, wRead m₅ engArrTbl i = wRead m₂ engArrTbl i := by
    intro i
    exact (hpresT_₅ engArrTbl (by decide) i).trans (by simp [m₄_st, wRead_wWrite_eq])
  have hw6_unchanged : ∀ i : ℤ,
      i ≠ 0 → i ≠ 1 → i ≠ 2 →
      (∀ rk : Fin cp.D_max, r.val ≤ rk.val → i ≠ jobMetaBase cp rk.val) →
      wRead m₅ engMetaTbl i = wRead m₀ engMetaTbl i := by
    intro i hi0 hi1 hi2 hne_jb
    exact (hpres6_₅ i hne_jb).trans
      ((wRead_wWrite_of_ne _ _ (Or.inr hi0)).trans
        ((wRead_wWrite_of_ne _ _ (Or.inr hi1)).trans
          ((hfm₂ i hi2).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide))))))
  have hlt16_ne_jb : ∀ (i : ℤ), i < 16 → ∀ rk : Fin cp.D_max, r.val ≤ rk.val →
      i ≠ jobMetaBase cp rk.val := by
    intro i hi rk _; unfold jobMetaBase; omega
  have htake_len : (cur.serving.take r.val).length = r.val :=
    List.length_take_of_le (Nat.le_of_lt hr)
  refine ⟨?_, hw_lt6, hr_lt3⟩
  -- Assemble `EncChainEngine ops nxt m₅`
  refine ⟨hsr₅,
    encHandlePool_ext_local hhp₀ (fun t ht => hw_lt6 t (by omega)) (hr_lt3 ptsRTbl (by decide)),
    encCachedAns_ext_local hans₀ (hw_lt6 0 (by decide))
      (hw6_unchanged 3 (by decide) (by decide) (by decide) (hlt16_ne_jb 3 (by omega)))
      (hw6_unchanged 4 (by decide) (by decide) (by decide) (hlt16_ne_jb 4 (by omega)))
      (hw6_unchanged 5 (by decide) (by decide) (by decide) (hlt16_ne_jb 5 (by omega)))
      (hr_lt3 0 (by decide) 0) (hr_lt3 engRealTbl (by decide) 0),
    ?_,
    Nat.le_succ_of_le hsmall,
    hleaf_sp₂.ext
      ((hpres6_₅ 2 (hlt16_ne_jb 2 (by omega))).trans
        ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
          (wRead_wWrite_of_ne _ _ (Or.inr (by decide)))))
      (fun _ _ => hw7_25 _) (fun _ _ => hw7_25 _),
    by rw [htake_len]; exact Nat.le_of_lt r.isLt,
    ?_,
    servSlots.take r.val,
    fun rr => if rr.val < r.val then readySlots rr else [],
    curSlots,
    by simp [hslen₀],
    ?_, ?_, ?_⟩
  · -- `wRead m₅ engMetaTbl 1 = 0`
    exact (hpres6_₅ 1 (hlt16_ne_jb 1 (by omega))).trans
      ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans (wRead_wWrite_self _ _ _ _))
  · -- `wRead m₅ engMetaTbl 0 = (r.val : ℤ)`
    rw [htake_len]
    exact (hpres6_₅ 0 (hlt16_ne_jb 0 (by omega))).trans (wRead_wWrite_self _ _ _ _)
  · -- Serving slots `i < r.val`
    intro i hi his
    have hi_r : i < r.val := by rwa [htake_len] at hi
    have hi_orig : i < cur.serving.length := lt_trans hi_r hr
    have his_orig : i < servSlots.length := hslen₀.symm ▸ hi_orig
    have hoff_ne : ∀ rk : Fin cp.D_max, r.val ≤ rk.val → servSlotOff i ≠ jobMetaBase cp rk.val := by
      intro rk _
      have hi_D : i < cp.D_max := lt_trans hi_r r.isLt
      unfold servSlotOff jobMetaBase; omega
    have hw_off : wRead m₅ engMetaTbl (servSlotOff i) = wRead m₀ engMetaTbl (servSlotOff i) :=
      hw6_unchanged (servSlotOff i)
        (by unfold servSlotOff; omega) (by unfold servSlotOff; omega) (by unfold servSlotOff; omega)
        hoff_ne
    rw [List.getElem_take, List.getElem_take]
    exact ⟨hw_off.trans (hserv₀ i hi_orig his_orig).1,
      hnd₀₅ _ _ (hall_lt _ (List.mem_append_left _ (List.getElem_mem his_orig)))
        (hserv₀ i hi_orig his_orig).2⟩
  · -- Job slots `rr : Fin cp.D_max`
    intro rr
    dsimp only
    by_cases hrr : rr.val < r.val
    · simp only [hrr, ite_true]
      refine encJobSlot_ext_local (hjobs₀ rr)
        (fun s hs => hall_lt s (List.mem_append_right _ (List.mem_flatMap.mpr ⟨rr, List.mem_finRange rr, hs⟩)))
        (fun j hj0 hj7 => hw6_unchanged (jobMetaBase cp rr.val + j)
          (by unfold jobMetaBase; omega) (by unfold jobMetaBase; omega) (by unfold jobMetaBase; omega)
          (fun rk hrk => by unfold jobMetaBase; omega))
        (fun q hq => hw6_unchanged (readySlotOff cp rr.val q)
          (by have := mul_nonneg (Int.natCast_nonneg rr.val) (Int.natCast_nonneg cp.D_max)
              unfold readySlotOff; omega)
          (by have := mul_nonneg (Int.natCast_nonneg rr.val) (Int.natCast_nonneg cp.D_max)
              unfold readySlotOff; omega)
          (by have := mul_nonneg (Int.natCast_nonneg rr.val) (Int.natCast_nonneg cp.D_max)
              unfold readySlotOff; omega)
          (fun rk _ => by
            simpa using readySlotOff_ne_jobMetaBase cp rr rk hq (j := 0) (by omega) (by omega)))
        (fun i hi => (hw7_25 i).trans
          ((hfa₂ i hi).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))))
        hnd₀₅
    · simp only [hrr, ite_false]
      exact ⟨rfl, hclr₅ rr (by omega)⟩
  · -- `allSlots'.Nodup` and `< M_slots cp`
    exact allSlots_truncate_nodup_lt r hall_nd hall_lt

/-! ### 2. Branch 2 (`openCopyJobStage3Stmt`): Initialize Copy-Phase Job at Slot `r` -/

def openCopyJobStage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .seq (.writeWordHeap engScrTbl (.lit 10) (.readHeap engMetaTbl (.lit (servSlotOff r.val))))
  (.seq (ops.readNodeScalarStmt .histLen 10 14)
  (.seq (.writeWordHeap engMetaTbl (.lit base) (.lit 1))
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 1)) (.lit 0))
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 2)) (.lit 0))
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 3)) (.readHeap engScrTbl (.lit 14)))
  (.seq (.writeWordHeap engMetaTbl (.lit (base + 4)) (.lit 0))
        (.writeWordHeap engMetaTbl (.lit (base + 5)) (.lit 0))))))))

theorem zeroRand_openCopyJobStage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (openCopyJobStage3Stmt ops r) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (ops.zeroRand_readNodeScalar .histLen 10 14)
      (.seq (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _)
          (.seq (.writeWordHeap _ _ _)
            (.seq (.writeWordHeap _ _ _)
              (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))))

def C_openCopyStage3 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  84 + ops.C_read

theorem exec_openCopyJobStage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {cur : ChainEngineState cp} {m₀ : ArithRAMMemory}
    (hr : r.val < cur.serving.length)
    (hjb_r : cur.jobs r = none)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops cur m₀) :
    let mn := cur.serving[r.val]'hr
    let jbNew : SuffixJob cp := { ready := [], phase := .copy (CopyState.init mn.histArr.length) }
    let nxt : ChainEngineState cp := { cur with jobs := Function.update cur.jobs r (some jbNew) }
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (openCopyJobStage3Stmt ops r) m₀
      (fun m₁ =>
        EncChainEngine ops nxt m₁ ∧
        (∀ t < 6, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ rt < 3, ∀ i, rRead m₁ rt i = rRead m₀ rt i))
      (C_openCopyStage3 ops) := by
  have hTW := ops.hTW
  have hBW_scr := ops.hBW_scr
  let mn := cur.serving[r.val]'hr
  let jbNew : SuffixJob cp := { ready := [], phase := .copy (CopyState.init mn.histArr.length) }
  let base := jobMetaBase cp r.val
  rcases henc₀ with ⟨hsr₀, hhp₀, hans₀, hov₀, hleaf_le₀, hleaf_sp₀, hserv_le₀, hserv_len₀,
    servSlots, readySlots, curSlots, hslen₀, hserv₀, hjobs₀, hall_nd, hall_lt⟩
  have hrs : r.val < servSlots.length := hslen₀.symm ▸ hr
  let cSlot := servSlots[r.val]'hrs
  have hcSlot_lt : cSlot < M_slots cp :=
    hall_lt cSlot (List.mem_append_left _ (List.getElem_mem hrs))
  have hrSlots_r : readySlots r = [] := by
    have hjr := hjobs₀ r
    simp only [EncJobSlot, hjb_r] at hjr
    exact hjr.1
  unfold openCopyJobStage3Stmt C_openCopyStage3
  -- Step 1: Load `cSlot` into `engScrTbl[10]`
  refine ExecDet.seq' (72 + ops.C_read)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 10) (.readHeap engMetaTbl (.lit (servSlotOff r.val)))
      10 (cSlot : ℤ) hfp₀ (by unfold engScrTbl; omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) rfl
      (by simp only [evalIntExpr]; exact (hserv₀ r.val hr hrs).1)
      (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₁ hm₁ hfp₁; subst hm₁
  let m₁_st := H3a.wWrite m₀ engScrTbl 10 (cSlot : ℤ)
  have hw9_1 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m₁_st t i = wRead m₀ t i :=
    fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
  have hr_1 : ∀ t i, rRead m₁_st t i = rRead m₀ t i := fun t i => rRead_wWrite _ _ _ _ _ _
  have hsr₁ : ops.SlotsReady m₁_st :=
    ops.slotsReady_ext m₀ m₁_st hsr₀ hw9_1 (fun t _ _ i => hr_1 t i)
  have hnd₁ : ∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m₁_st :=
    fun mn' s _ he => ops.encNode_ext mn' s m₀ m₁_st he hw9_1 (fun t _ _ i => hr_1 t i)
      (fun _ _ _ _ => hr_1 ptsRTbl _)
  -- Step 2: Read `mn.histArr.length` into `engScrTbl[14]`
  refine ExecDet.seq' 72
    (ops.readNodeScalar_spec inp m₁_st mn cSlot .histLen 10 14
      hcSlot_lt (by omega) (by omega) (by omega) (by omega)
      hfp₁ hsr₁ (hnd₁ mn cSlot hcSlot_lt (hserv₀ r.val hr hrs).2)
      (wRead_wWrite_self _ _ _ _))
    (by omega) ?_
  intro m₂ ⟨hsr₂, hr14, hnd₂, hft₂, _, hfr₂⟩ hfp₂
  dsimp [evalNodeScalar] at hr14
  rcases jobMetaBase_bounds ops r (j := 0) (by omega) (by omega) with ⟨hb0, hb0B⟩
  simp only [add_zero] at hb0 hb0B
  rcases jobMetaBase_bounds ops r (j := 1) (by omega) (by omega) with ⟨hb1, hb1B⟩
  rcases jobMetaBase_bounds ops r (j := 2) (by omega) (by omega) with ⟨hb2, hb2B⟩
  rcases jobMetaBase_bounds ops r (j := 3) (by omega) (by omega) with ⟨hb3, hb3B⟩
  rcases jobMetaBase_bounds ops r (j := 4) (by omega) (by omega) with ⟨hb4, hb4B⟩
  rcases jobMetaBase_bounds ops r (j := 5) (by omega) (by omega) with ⟨hb5, hb5B⟩
  -- Steps 3..8: Write `base .. base + 5` in `engMetaTbl`
  refine ExecDet.seq' 60
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit base) (.lit 1) base 1
      hfp₂ (by unfold engMetaTbl; omega) hb0 hb0B rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₃ hm₃ hfp₃; subst hm₃
  refine ExecDet.seq' 48
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 1)) (.lit 0) (base + 1) 0
      hfp₃ (by unfold engMetaTbl; omega) hb1 hb1B rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₄ hm₄ hfp₄; subst hm₄
  refine ExecDet.seq' 36
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 2)) (.lit 0) (base + 2) 0
      hfp₄ (by unfold engMetaTbl; omega) hb2 hb2B rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₅ hm₅ hfp₅; subst hm₅
  refine ExecDet.seq' 24
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 3)) (.readHeap engScrTbl (.lit 14))
      (base + 3) (mn.histArr.length : ℤ)
      hfp₅ (by unfold engMetaTbl; omega) hb3 hb3B rfl
      (by simp only [evalIntExpr]
          change wRead _ engScrTbl 14 = _
          iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
          exact hr14)
      (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₆ hm₆ hfp₆; subst hm₆
  refine ExecDet.seq' 12
    (ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 4)) (.lit 0) (base + 4) 0
      hfp₆ (by unfold engMetaTbl; omega) hb4 hb4B rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₇ hm₇ hfp₇; subst hm₇
  refine ExecDet.wWrite (C := 12) inp engMetaTbl (.lit (base + 5)) (.lit 0) (base + 5) 0
    hfp₇ (by unfold engMetaTbl; omega) hb5 hb5B rfl rfl (by simp [intExprOps]) ?_
  set mF := H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite
    m₂ engMetaTbl base 1) engMetaTbl (base + 1) 0) engMetaTbl (base + 2) 0)
    engMetaTbl (base + 3) (mn.histArr.length : ℤ)) engMetaTbl (base + 4) 0)
    engMetaTbl (base + 5) 0
  have hw_mF_ne6 : ∀ t, t ≠ engMetaTbl → ∀ i, wRead mF t i = wRead m₂ t i := by
    intro t ht i; dsimp only [mF]; iterate 6 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
  have hr_mF : ∀ t i, rRead mF t i = rRead m₂ t i := by
    intro t i; simp [mF]
  have hw9_2F : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead m₂ t i :=
    fun t ht9 _ i => hw_mF_ne6 t (by unfold engMetaTbl; omega) i
  have hsrF : ops.SlotsReady mF :=
    ops.slotsReady_ext m₂ mF hsr₂ hw9_2F (fun t _ _ i => hr_mF t i)
  have hnd₀F : ∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s mF :=
    fun mn' s hs he => ops.encNode_ext mn' s m₂ mF (hnd₂ mn' s hs (hnd₁ mn' s hs he))
      hw9_2F (fun t _ _ i => hr_mF t i) (fun _ _ _ _ => hr_mF ptsRTbl _)
  have hw_lt6 : ∀ t < 6, ∀ i, wRead mF t i = wRead m₀ t i := by
    intro t ht6 i
    have ht_ne6 : t ≠ engMetaTbl := by unfold engMetaTbl; omega
    have ht_ne8 : t ≠ engScrTbl := by unfold engScrTbl; omega
    exact (hw_mF_ne6 t ht_ne6 i).trans
      ((hft₂ t (by omega) ht_ne8 i).trans (wRead_wWrite_of_ne _ _ (Or.inl ht_ne8)))
  have hr_lt3 : ∀ rt < 3, ∀ i, rRead mF rt i = rRead m₀ rt i := by
    intro rt hrt i
    exact (hr_mF rt i).trans ((hfr₂ rt hrt i).trans (hr_1 rt i))
  have hw7_0F : ∀ i, wRead mF engArrTbl i = wRead m₀ engArrTbl i := by
    intro i
    exact (hw_mF_ne6 engArrTbl (by decide) i).trans
      ((hft₂ engArrTbl (by decide) (by decide) i).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide))))
  have hw6_outside : ∀ i : ℤ, (i < base ∨ base + 5 < i) → wRead mF engMetaTbl i = wRead m₀ engMetaTbl i := by
    intro i hrange
    have h0 : i ≠ base := by omega
    have h1 : i ≠ base + 1 := by omega
    have h2 : i ≠ base + 2 := by omega
    have h3 : i ≠ base + 3 := by omega
    have h4 : i ≠ base + 4 := by omega
    have h5 : i ≠ base + 5 := by omega
    dsimp only [mF]
    rw [wRead_wWrite_of_ne _ _ (Or.inr h5), wRead_wWrite_of_ne _ _ (Or.inr h4),
        wRead_wWrite_of_ne _ _ (Or.inr h3), wRead_wWrite_of_ne _ _ (Or.inr h2),
        wRead_wWrite_of_ne _ _ (Or.inr h1), wRead_wWrite_of_ne _ _ (Or.inr h0)]
    exact (hft₂ engMetaTbl (by decide) (by decide) i).trans
      (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
  have hbase_ge16 : 16 ≤ base := by dsimp only [base]; unfold jobMetaBase; omega
  refine ⟨?_, hw_lt6, hr_lt3⟩
  refine ⟨hsrF,
    encHandlePool_ext_local hhp₀ (fun t ht => hw_lt6 t (by omega)) (hr_lt3 ptsRTbl (by decide)),
    encCachedAns_ext_local hans₀ (hw_lt6 0 (by decide))
      (hw6_outside 3 (Or.inl (by omega)))
      (hw6_outside 4 (Or.inl (by omega)))
      (hw6_outside 5 (Or.inl (by omega)))
      (hr_lt3 0 (by decide) 0) (hr_lt3 engRealTbl (by decide) 0),
    (hw6_outside 1 (Or.inl (by omega))).trans hov₀,
    hleaf_le₀,
    hleaf_sp₀.ext (hw6_outside 2 (Or.inl (by omega))) (fun _ _ => hw7_0F _) (fun _ _ => hw7_0F _),
    hserv_le₀,
    (hw6_outside 0 (Or.inl (by omega))).trans hserv_len₀,
    servSlots, readySlots, curSlots, hslen₀,
    fun i hi his => ?_,
    fun rr => ?_,
    ?_⟩
  · have hi_D : i < cp.D_max := lt_of_lt_of_le hi hserv_le₀
    have hoff_lt : servSlotOff i < base := by
      dsimp only [base]; unfold servSlotOff jobMetaBase; omega
    exact ⟨(hw6_outside (servSlotOff i) (Or.inl hoff_lt)).trans (hserv₀ i hi his).1,
      hnd₀F _ _ (hall_lt _ (List.mem_append_left _ (List.getElem_mem his))) (hserv₀ i hi his).2⟩
  · by_cases hrr : rr = r
    · subst hrr
      dsimp only
      rw [Function.update_self]
      have hwb0 : wRead mF engMetaTbl base = 1 := by
        dsimp only [mF]
        iterate 5 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact wRead_wWrite_self _ _ _ _
      have hwb1 : wRead mF engMetaTbl (base + 1) = 0 := by
        dsimp only [mF]
        iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact wRead_wWrite_self _ _ _ _
      have hwb2 : wRead mF engMetaTbl (base + 2) = 0 := by
        dsimp only [mF]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact wRead_wWrite_self _ _ _ _
      have hwb3 : wRead mF engMetaTbl (base + 3) = (mn.histArr.length : ℤ) := by
        dsimp only [mF]
        iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact wRead_wWrite_self _ _ _ _
      have hwb4 : wRead mF engMetaTbl (base + 4) = 0 := by
        dsimp only [mF]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact wRead_wWrite_self _ _ _ _
      have hwb5 : wRead mF engMetaTbl (base + 5) = 0 := wRead_wWrite_self _ _ _ _
      refine ⟨hwb0, Nat.zero_le _, by simp [hrSlots_r, jbNew], hwb1,
        fun q hq _ => absurd hq (Nat.not_lt_zero _),
        hwb2, hwb3, hwb4, encSparseSet_empty_of_zero hwb5⟩
    · dsimp only
      rw [Function.update_of_ne hrr]
      have hrr_ne_v : rr.val ≠ r.val := fun hv => hrr (Fin.ext hv)
      refine encJobSlot_ext_local (hjobs₀ rr)
        (fun s hs => hall_lt s (List.mem_append_right _ (List.mem_flatMap.mpr ⟨rr, List.mem_finRange rr, hs⟩)))
        (fun j hj0 hj7 => hw6_outside (jobMetaBase cp rr.val + j)
          (by dsimp only [base]; unfold jobMetaBase; omega))
        (fun q hq => hw6_outside (readySlotOff cp rr.val q)
          (Or.inr (by
            have hrr_lt := rr.isLt
            have hr_lt := r.isLt
            have hprod : 0 ≤ (rr.val : ℤ) * (cp.D_max : ℤ) :=
              mul_nonneg (Int.natCast_nonneg _) (Int.natCast_nonneg _)
            dsimp only [base]; unfold readySlotOff jobMetaBase; omega)))
        (fun i _ => hw7_0F i)
        hnd₀F
  · have hj_eq : (fun rr => jobUsedSlots (Function.update cur.jobs r (some jbNew) rr)
        (readySlots rr) (curSlots rr)) =
        (fun rr => jobUsedSlots (cur.jobs rr) (readySlots rr) (curSlots rr)) := by
      funext rr
      by_cases hrr : rr = r
      · subst hrr
        rw [Function.update_self, hjb_r, hrSlots_r]
        rfl
      · rw [Function.update_of_ne hrr]
    dsimp only
    rw [hj_eq]
    exact ⟨hall_nd, hall_lt⟩


end UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3
