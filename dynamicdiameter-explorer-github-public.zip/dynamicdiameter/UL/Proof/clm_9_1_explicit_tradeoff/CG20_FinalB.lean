import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_FinalA
import UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3
open UL.Proof.clm_9_1_explicit_tradeoff.CG15
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge

/-! ### 1. Stage 1 + Stage 2 Bundle Wiring into Stage 3 (`CG02_Stage3`) + Stage 4 (`CG20_Stage4`) -/

/-- Remaining Stage 1 + Stage 2 deterministic RAM bundle once Stages 3 and 4 are wired in. -/
structure Stage12RAMBundle {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) where
  s1 : ArithRAMStmt
  s2 : ArithRAMStmt
  C1 : ℕ
  C2 : ℕ
  hzr1 : ZeroRandStmt s1
  hzr2 : ZeroRandStmt s2
  exec1 :
    ∀ {P : DynamicPointSet d} {op : DynamicUpdate d}
      {st : ChainEngineState cp} {bits : Fin cp.B_STEP → Bool} {m₀ : ArithRAMMemory},
      P.WellFormed cp.n →
      IsLegalUpdate cp.n Set.univ P op →
      ChainEngineWF cp P st →
      InFootprint ops.TW ops.BW ops.TR ops.BR m₀ →
      EncChainEngine ops st m₀ →
      MemHasStepCoins cp bits m₀ →
      let uop := toInternalUpdate P op
      let inp := mkUpdateInp cp.n P uop
      let ω₁ := (bitsToStepCoinBundle cp bits).1
      let res := stepStage1 cp st uop ω₁
      ExecDet ops.TW ops.BW ops.TR ops.BR inp s1 m₀
        (fun m₁ =>
          EncChainEngine ops res.1 m₁ ∧
          MemHasStepCoins cp bits m₁ ∧
          (∀ h_new, res.2 = some h_new →
            ArithRAMDynamicProgram.readReturnedHandle m₁ = some h_new))
        C1
  exec2 :
    ∀ (inp : ArithRAMInput d) {P' : DynamicPointSet d}
      {st₁ : ChainEngineState cp} {bits : Fin cp.B_STEP → Bool} {m₁ : ArithRAMMemory},
      P'.WellFormed cp.n →
      PostStage1WF cp P' st₁ →
      InFootprint ops.TW ops.BW ops.TR ops.BR m₁ →
      EncChainEngine ops st₁ m₁ →
      MemHasStepCoins cp bits m₁ →
      let ω₂ := (bitsToStepCoinBundle cp bits).2.1
      let st₂ := stepStage2 cp st₁ ω₂
      ExecDet ops.TW ops.BW ops.TR ops.BR inp s2 m₁
        (fun m₂ =>
          EncChainEngine ops st₂ m₂ ∧
          MemHasStepCoins cp bits m₂ ∧
          wRead m₂ 0 0 = wRead m₁ 0 0)
        C2

def Stage12RAMBundle.toStage123 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    (s12 : Stage12RAMBundle ops) : Stage123RAMBundle ops where
  s1 := s12.s1
  s2 := s12.s2
  s3 := stepStage3Stmt ops
  C1 := s12.C1
  C2 := s12.C2
  C3 := C_stage3 ops
  hzr1 := s12.hzr1
  hzr2 := s12.hzr2
  hzr3 := zeroRand_stepStage3Stmt ops
  exec1 := s12.exec1
  exec2 := s12.exec2
  exec3 := by
    intro inp P' st₂ bits m₂ _ hwf₂ hfp₂ henc₂ hcoins₂
    exact (exec_stage3Stmt ops inp bits hwf₂ hfp₂ henc₂ hcoins₂).mono
      (fun _ ⟨henc₃, hcoins₃, hw32, _⟩ _ => ⟨henc₃, hcoins₃, hw32⟩) le_rfl

def mkStepChainRAMSpec12 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1) (hh0 : 0 < h) (hh1 : h < 1)
    (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops)
    (s12 : Stage12RAMBundle ops) :
    StepChainRAMSpec cp :=
  mkStepChainRAMSpec h_lem_5_1 h_clm_7_3 hd he1 hh0 hh1 ops mops s12.toStage123

/-- Concrete polynomial bound on `CG02_Stage3.C_stage3 ops` when `ops.C_read = 370`. -/
theorem C_stage3_le_master_of_read370 {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    (ops : NodeAndHPJRAMOps inst.cp) (hread : ops.C_read = 370) :
    C_stage3 ops ≤ 3000 * (masterPolyParamNat inst) ^ 2 * masterWorkFactorNat inst.cp := by
  let P := masterPolyParamNat inst
  let W := masterWorkFactorNat inst.cp
  have hP1 : 1 ≤ P := by change 1 ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hW1 : 1 ≤ W := by change 1 ≤ masterWorkFactorNat inst.cp; unfold masterWorkFactorNat; omega
  have hD1 : inst.cp.D_max + 1 ≤ P := by
    change _ ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hB : inst.cp.B_scan ≤ P := by
    change _ ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hc := C_stage3_le ops
  rw [hread] at hc
  have hinner : 180 + (inst.cp.B_scan + 4) * (370 + 120) + 12 * inst.cp.D_max ≤ 3000 * P := by
    omega
  have hprod : (inst.cp.D_max + 1) * (180 + (inst.cp.B_scan + 4) * (370 + 120) + 12 * inst.cp.D_max) ≤
      3000 * P ^ 2 := by
    calc (inst.cp.D_max + 1) * (180 + (inst.cp.B_scan + 4) * (370 + 120) + 12 * inst.cp.D_max)
        ≤ P * (3000 * P) := Nat.mul_le_mul hD1 hinner
      _ = 3000 * P ^ 2 := by ring
  calc C_stage3 ops ≤ 3000 * P ^ 2 := hc.trans hprod
    _ = 3000 * P ^ 2 * 1 := by ring
    _ ≤ 3000 * P ^ 2 * W := Nat.mul_le_mul_left _ hW1

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
