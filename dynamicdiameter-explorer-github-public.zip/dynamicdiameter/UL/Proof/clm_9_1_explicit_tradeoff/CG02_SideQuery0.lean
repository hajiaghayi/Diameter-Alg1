import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideA

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot optNatToInt
  slotWStride slotRStride slotWStride_ge_four slotQryWStride slotQryRStride
  copyVecToHeapStmt exec_copyVecToHeapStmt corrGtRegStmt exec_corrGtRegStmt
  liveSlotQueryStmt liveSlotQueryCost exec_liveSlotQueryStmt)

/-! ### 1. Scratch Strides & `ZeroRandStmt` Lemmas for `DyadicSideIndex.query` -/

def dyadicSideQueryWStride (ℓ M₀ cap_q : ℕ) : ℤ :=
  16 + slotQryWStride ℓ M₀ cap_q

def dyadicSideQueryUidWStride (ℓ M₀ cap_q : ℕ) : ℤ :=
  20 + slotQryWStride ℓ M₀ cap_q

def dyadicSideQueryRStride (d : ℕ) : ℤ :=
  slotQryRStride d

lemma slotQryWStride_ge_28 (ℓ M₀ cap_q : ℕ) : 28 ≤ slotQryWStride ℓ M₀ cap_q := by
  unfold slotQryWStride RacerP43.evalWStride; omega

lemma dyadicSideQueryWStride_ge_44 (ℓ M₀ cap_q : ℕ) :
    44 ≤ dyadicSideQueryWStride ℓ M₀ cap_q := by
  have := slotQryWStride_ge_28 ℓ M₀ cap_q
  unfold dyadicSideQueryWStride; omega

lemma dyadicSideQueryWStride_pos (ℓ M₀ cap_q : ℕ) :
    1 ≤ dyadicSideQueryWStride ℓ M₀ cap_q := by
  have := dyadicSideQueryWStride_ge_44 ℓ M₀ cap_q; omega

lemma dyadicSideQueryUidWStride_ge_48 (ℓ M₀ cap_q : ℕ) :
    48 ≤ dyadicSideQueryUidWStride ℓ M₀ cap_q := by
  have := slotQryWStride_ge_28 ℓ M₀ cap_q
  unfold dyadicSideQueryUidWStride; omega

lemma dyadicSideQueryUidWStride_pos (ℓ M₀ cap_q : ℕ) :
    1 ≤ dyadicSideQueryUidWStride ℓ M₀ cap_q := by
  have := dyadicSideQueryUidWStride_ge_48 ℓ M₀ cap_q; omega

lemma dyadicSideQueryRStride_ge_4 (d : ℕ) :
    4 ≤ dyadicSideQueryRStride d := by
  unfold dyadicSideQueryRStride slotQryRStride; omega

lemma dyadicSideQueryRStride_pos (d : ℕ) :
    1 ≤ dyadicSideQueryRStride d := by
  have := dyadicSideQueryRStride_ge_4 d; omega

theorem zeroRand_qry_copyVecToHeapStmt (scrW tblSrc tblDst : ℕ) (wCtr wOffSrc wOffDst : ℤ) (N : ℕ) :
    H3a.ZeroRandStmt (copyVecToHeapStmt scrW tblSrc tblDst wCtr wOffSrc wOffDst N) :=
  of_isZeroRandB rfl

theorem zeroRand_qry_corrGtRegStmt (scrW scrR tblO tblPts : ℕ)
    (wCtr wDst rBase wOffO wOffX wOffY : ℤ) (d : ℕ) (b : ℚ) :
    H3a.ZeroRandStmt (corrGtRegStmt scrW scrR tblO tblPts wCtr wDst rBase wOffO wOffX wOffY d b) :=
  of_isZeroRandB rfl

theorem zeroRand_qry_liveSlotQueryStmt (scrW scrR tblW tblR tblO tblPts : ℕ)
    (wBaseW wBaseR wEntryPtBase wOffO wOffPv wAnsOut wQryBase rQryBase : ℤ)
    (R ℓ M₀ d M_lat S_lat cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) :
    H3a.ZeroRandStmt (liveSlotQueryStmt scrW scrR tblW tblR tblO tblPts
      wBaseW wBaseR wEntryPtBase wOffO wOffPv wAnsOut wQryBase rQryBase
      R ℓ M₀ d M_lat S_lat cap_q A B_rat τ_q b_rat) :=
  of_isZeroRandB rfl

@[simp]
lemma optNatToInt_lt_zero_iff (o : Option ℕ) :
    optNatToInt o < 0 ↔ o = none := by
  cases o with
  | none => simp [optNatToInt]
  | some x =>
      simp only [optNatToInt, reduceCtorEq, iff_false]
      omega

/-! ### 2. Tail Candidate Check Helper (`tail1` for `delta = 1`, `tail2` for `delta = 2`) -/

noncomputable def dyadicSideTailOpt {L_p2 R ℓ M₀ d b : ℕ}
    (b_thr : ℝ) (o p_v : EuclideanSpace ℝ (Fin d))
    (idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b) (delta : ℕ) : Option ℕ :=
  open Classical in
  if delta ≤ idx.t_ins ∧ idx.entryAlive (idx.t_ins - delta) = true ∧
      b_thr < radialCorrelation o p_v (idx.entryPt (idx.t_ins - delta)) then
    some (idx.entryHandle (idx.t_ins - delta))
  else
    none

def dyadicSideTailCheckStmt (scrW scrR tblW tblO tblR : ℕ)
    (wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr : ℤ)
    (L_p2 d delta : ℕ) (b_rat : ℚ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let bMaxZ : ℤ := ((2 ^ L_p2 : ℕ) : ℤ)
  let wEp := wScr
  let wT := wScr + 1
  let wEntryPtBase := wScr + 2
  let wEid := wScr + 12
  let wCandOff := wScr + 13
  let wSubCtr := wScr + 14
  let wSubDst := wScr + 15
  .ite (.intLt (.readHeap scrW (.lit wAnsOut)) (.lit 0))
    (.ite (.intLe (.lit (delta : ℤ)) (.readHeap scrW (.lit wT)))
      (.seq (.writeWordHeap scrW (.lit wEid)
              (.sub (.readHeap scrW (.lit wT)) (.lit (delta : ℤ))))
        (.ite (.intEq (.readHeap tblW (.add (.add bW (.lit (2 + bMaxZ)))
                                            (.readHeap scrW (.lit wEid))))
                      (.readHeap scrW (.lit wEp)))
          (.seq (.writeWordHeap scrW (.lit wCandOff)
                  (.add (.readHeap scrW (.lit wEntryPtBase))
                        (.mul (.readHeap scrW (.lit wEid)) (.lit (d : ℤ)))))
          (.seq (corrGtRegStmt scrW scrR tblO tblR
                  wSubCtr wSubDst rScr wOffO wSideBaseR wCandOff d b_rat)
            (.ite (.intEq (.readHeap scrW (.lit wSubDst)) (.lit 1))
              (.writeWordHeap scrW (.lit wAnsOut)
                (.readHeap tblW (.add (.add bW (.lit 2)) (.readHeap scrW (.lit wEid)))))
              .skip)))
          .skip))
      .skip)
    .skip

def dyadicSideTailCheckCost (d : ℕ) : ℕ :=
  380 + 130 * d

theorem zeroRand_dyadicSideTailCheckStmt (scrW scrR tblW tblO tblR : ℕ)
    (wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr : ℤ)
    (L_p2 d delta : ℕ) (b_rat : ℚ) :
    H3a.ZeroRandStmt (dyadicSideTailCheckStmt scrW scrR tblW tblO tblR
      wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr L_p2 d delta b_rat) :=
  of_isZeroRandB rfl

theorem exec_dyadicSideTailCheckStmt {d TW BW TR BR scrW scrR tblW tblO tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr sideBaseW sideBaseR offO : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord cap_u cap_q delta : ℕ}
    (hM₀ : 1 ≤ M₀) (hdelta : 1 ≤ delta)
    {A B_rat τ_d : ℚ} (b_rat : ℚ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {o p_v : EuclideanSpace ℝ (Fin d)} (hpv_ne : p_v ≠ o)
    {U : Finset ℕ} {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b}
    (hwf : H4b.DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx)
    (prevAns : Option ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneO : tblO ≠ scrR)
    (hwAns : 0 ≤ wAnsOut ∧ wAnsOut < (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + dyadicSideQueryRStride d ≤ (BR : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wSideBaseW)
    (hdisjBR : wSideBaseR < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wSideBaseR)
    (hdisjO : wOffO < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wOffO)
    (hdisjAns : wAnsOut < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wAnsOut)
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hbR : wRead m₀ scrW wSideBaseR = sideBaseR)
    (hoffO : wRead m₀ scrW wOffO = offO)
    (hep_r : wRead m₀ scrW wScr = wRead m₀ tblW sideBaseW)
    (ht_r : wRead m₀ scrW (wScr + 1) = (idx.t_ins : ℤ))
    (hepBase_r : wRead m₀ scrW (wScr + 2) = sideEntryPtOff d sideBaseR)
    (hans₀ : wRead m₀ scrW wAnsOut = optNatToInt prevAns)
    (ho : ∀ c : Fin d, rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpv : ∀ c : Fin d, rRead m₀ tblR (sideBaseR + (c.val : ℤ)) = euclideanCoord p_v c)
    (henc₀ : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀) :
    let nextAns : Option ℕ :=
      match prevAns with
      | some w => some w
      | none => dyadicSideTailOpt (b_rat : ℝ) o p_v idx delta
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (dyadicSideTailCheckStmt scrW scrR tblW tblO tblR
          wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr L_p2 d delta b_rat)
        m₀ m₁ (dyadicSideTailCheckCost d) ∧
      InFootprint TW BW TR BR m₁ ∧
      wRead m₁ scrW wAnsOut = optNatToInt nextAns ∧
      (∀ w, w ≠ wAnsOut → (w < wScr + 12 ∨ wScr + 16 ≤ w) → wRead m₁ scrW w = wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m₁ := by
  classical
  intro nextAns
  have hge44 := dyadicSideQueryWStride_ge_44 ℓ M₀ cap_q
  have hrge4 := dyadicSideQueryRStride_ge_4 d
  rcases henc₀ with ⟨ht_le, ep₀, live₀, _, hep_tbl, _, hhand, _, hal_iff, _, hpt, _, _⟩
  have hep_val : wRead m₀ scrW wScr = (ep₀ : ℤ) := hep_r.trans hep_tbl
  cases prevAns with
  | some w_prev =>
      have hc_ans : cValAt 0 inp m₀ (.intLt (.readHeap scrW (.lit wAnsOut)) (.lit 0)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (wRead m₀ scrW wAnsOut < 0) = false
        rw [hans₀]; simp [optNatToInt]
      exact ⟨m₀,
        (DetExecAt.ite_false (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
          (DetExecAt.skip 0 inp m₀)).mono_cost (by unfold dyadicSideTailCheckCost; omega),
        hfp₀, hans₀, fun _ _ _ => rfl,
        RadFrameOutside.refl scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀⟩
  | none =>
      have hc_ans : cValAt 0 inp m₀ (.intLt (.readHeap scrW (.lit wAnsOut)) (.lit 0)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (wRead m₀ scrW wAnsOut < 0) = true
        rw [hans₀]; simp [optNatToInt]
      by_cases hdel_le : delta ≤ idx.t_ins
      · have hc_del : cValAt 0 inp m₀ (.intLe (.lit (delta : ℤ)) (.readHeap scrW (.lit (wScr + 1)))) = true := by
          simp only [cValAt, evalArithCond, evalIntExpr]
          change decide ((delta : ℤ) ≤ wRead m₀ scrW (wScr + 1)) = true
          rw [ht_r, decide_eq_true_eq]; exact_mod_cast hdel_le
        let eid : ℕ := idx.t_ins - delta
        have heid_lt : eid < idx.t_ins := by dsimp [eid]; omega
        let m1 := wWrite m₀ scrW (wScr + 12) (eid : ℤ)
        have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 12))
            (.sub (.readHeap scrW (.lit (wScr + 1))) (.lit (delta : ℤ)))) m₀ m1 20 :=
          DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wScr + 12)) _ rfl
            (by change wRead m₀ scrW (wScr + 1) - (delta : ℤ) = (eid : ℤ)
                rw [ht_r]; dsimp [eid]; omega)
            (by dsimp [intExprOps]; omega)
        have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)
        have hfr01 : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m1 :=
          RadFrameOutside.wWrite_scr scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ _ _
        have hbW1 : wRead m1 scrW wSideBaseW = sideBaseW := by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbW
        have hep1 : wRead m1 scrW wScr = (ep₀ : ℤ) := by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hep_val
        have heid1 : wRead m1 scrW (wScr + 12) = (eid : ℤ) := wRead_wWrite_self _ _ _ _
        have hal_addr : (sideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) + (eid : ℤ) =
            sideAliveEpOff L_p2 sideBaseW eid := by unfold sideAliveEpOff; ring
        by_cases hal : idx.entryAlive eid = true
        · have hal_eq : wRead m1 tblW (sideAliveEpOff L_p2 sideBaseW eid) = (ep₀ : ℤ) := by
            rw [wRead_wWrite_of_ne _ _ (Or.inl hneW)]
            exact (hal_iff eid heid_lt).mpr hal
          have hc_al : cValAt 0 inp m1
              (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW))
                                                  (.lit (2 + ((2 ^ L_p2 : ℕ) : ℤ))))
                                            (.readHeap scrW (.lit (wScr + 12)))))
                      (.readHeap scrW (.lit wScr))) = true := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (wRead m1 tblW ((wRead m1 scrW wSideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) +
              wRead m1 scrW (wScr + 12)) = wRead m1 scrW wScr) = true
            rw [hbW1, heid1, hep1, hal_addr, hal_eq]; simp
          let candOff : ℤ := sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ)
          let m2 := wWrite m1 scrW (wScr + 13) candOff
          have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 13))
              (.add (.readHeap scrW (.lit (wScr + 2)))
                    (.mul (.readHeap scrW (.lit (wScr + 12))) (.lit (d : ℤ))))) m1 m2 25 :=
            DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 13)) _ rfl
              (by change wRead m1 scrW (wScr + 2) + wRead m1 scrW (wScr + 12) * (d : ℤ) = candOff
                  have hepB1 : wRead m1 scrW (wScr + 2) = sideEntryPtOff d sideBaseR := by
                    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hepBase_r
                  rw [hepB1, heid1])
              (by dsimp [intExprOps]; omega)
          have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 hscrW (by omega) (by omega)
          have hfr02 : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m2 :=
            hfr01.trans (RadFrameOutside.wWrite_scr scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m1 _ _)
          have hne_cand : idx.entryPt eid ≠ o := hwf.1 eid heid_lt
          obtain ⟨m3, hd_corr, hfp3, hdst3, hkW3, _, hfr23⟩ :=
            exec_corrGtRegStmt (tblW := tblW) (tblR := tblR) inp
              (wScr + 14) (wScr + 15) rScr wOffO wSideBaseR (wScr + 13)
              offO sideBaseR candOff sideBaseW sideBaseR b_rat
              o p_v (idx.entryPt eid) hpv_ne hne_cand hfp2 hscrW hscrR
              ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨hrScr.1, by omega⟩
              hneO hneR ⟨by omega, by omega, by omega⟩
              (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hoffO)
              (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbR)
              (wRead_wWrite_self _ _ _ _)
              (fun c => by rw [rRead_wWrite, rRead_wWrite]; exact ho c)
              (fun c => by rw [rRead_wWrite, rRead_wWrite]; exact hpv c)
              (fun c => by rw [rRead_wWrite, rRead_wWrite]; exact hpt eid heid_lt c)
          have hfr03 : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m3 :=
            hfr02.trans hfr23
          have hkW03 : ∀ w, w ≠ wAnsOut → (w < wScr + 12 ∨ wScr + 16 ≤ w) →
              wRead m3 scrW w = wRead m₀ scrW w := by
            intro w _ hw_out
            rw [hkW3 w (by omega) (by omega),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          by_cases hcorr : (b_rat : ℝ) < radialCorrelation o p_v (idx.entryPt eid)
          · have hdst_one : wRead m3 scrW (wScr + 15) = 1 := by
              rw [hdst3, if_pos hcorr]
            have hc_hit : cValAt 0 inp m3
                (.intEq (.readHeap scrW (.lit (wScr + 15))) (.lit 1)) = true := by
              simp only [cValAt, evalArithCond, evalIntExpr]
              change decide (wRead m3 scrW (wScr + 15) = 1) = true
              rw [hdst_one]; simp
            let m4 := wWrite m3 scrW wAnsOut (idx.entryHandle eid : ℤ)
            have hd_wr : DetExec inp (.writeWordHeap scrW (.lit wAnsOut)
                (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit 2))
                                      (.readHeap scrW (.lit (wScr + 12)))))) m3 m4 25 :=
              DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wAnsOut) _ rfl
                (by change wRead m3 tblW ((wRead m3 scrW wSideBaseW + 2) + wRead m3 scrW (wScr + 12)) = _
                    have hbW3 : wRead m3 scrW wSideBaseW = sideBaseW := by
                      rw [hkW3 _ (by omega) (by omega),
                          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbW1
                    have heid3 : wRead m3 scrW (wScr + 12) = (eid : ℤ) := by
                      rw [hkW3 _ (by omega) (by omega),
                          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact heid1
                    have hhd_addr : (sideBaseW + 2) + (eid : ℤ) = sideHandleOff sideBaseW eid := by
                      unfold sideHandleOff; ring
                    rw [hbW3, heid3, hhd_addr, hfr03.1 tblW _ hneW (Or.inr (Or.inr (by omega)))]
                    exact hhand eid heid_lt)
                (by dsimp [intExprOps]; omega)
            have hnext : nextAns = some (idx.entryHandle eid) := by
              dsimp [nextAns, dyadicSideTailOpt]
              rw [if_pos ⟨hdel_le, hal, hcorr⟩]
            refine ⟨m4,
              (DetExecAt.ite_true (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
                (DetExecAt.ite_true (C_c := 10) hc_del (by dsimp [condExprOps, intExprOps]; omega)
                  (hd1.seq (DetExecAt.ite_true (C_c := 25) hc_al (by dsimp [condExprOps, intExprOps]; omega)
                    (hd2.seq (hd_corr.seq
                      (DetExecAt.ite_true (C_c := 10) hc_hit (by dsimp [condExprOps, intExprOps]; omega)
                        hd_wr))))))).mono_cost (by unfold dyadicSideTailCheckCost; omega),
              InFootprint.wWrite hfp3 hscrW hwAns.1 hwAns.2,
              by rw [hnext, wRead_wWrite_self]; rfl,
              fun w hw_ne hw_out => by
                rw [wRead_wWrite_of_ne _ _ (Or.inr hw_ne)]
                exact hkW03 w hw_ne hw_out,
              hfr03.trans (RadFrameOutside.wWrite_scr scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m3 _ _)⟩
          · have hdst_zero : wRead m3 scrW (wScr + 15) = 0 := by
              rw [hdst3, if_neg hcorr]
            have hc_miss : cValAt 0 inp m3
                (.intEq (.readHeap scrW (.lit (wScr + 15))) (.lit 1)) = false := by
              simp only [cValAt, evalArithCond, evalIntExpr]
              change decide (wRead m3 scrW (wScr + 15) = 1) = false
              rw [hdst_zero]; simp
            have hnext : nextAns = none := by
              dsimp [nextAns, dyadicSideTailOpt]
              rw [if_neg (fun h => hcorr h.2.2)]
            have hans3 : wRead m3 scrW wAnsOut = optNatToInt none := by
              rw [hkW3 _ (by omega) (by omega),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hans₀]
            refine ⟨m3,
              (DetExecAt.ite_true (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
                (DetExecAt.ite_true (C_c := 10) hc_del (by dsimp [condExprOps, intExprOps]; omega)
                  (hd1.seq (DetExecAt.ite_true (C_c := 25) hc_al (by dsimp [condExprOps, intExprOps]; omega)
                    (hd2.seq (hd_corr.seq
                      (DetExecAt.ite_false (C_c := 10) hc_miss (by dsimp [condExprOps, intExprOps]; omega)
                        (DetExecAt.skip 0 inp m3)))))))).mono_cost (by unfold dyadicSideTailCheckCost; omega),
              hfp3, by rw [hnext]; exact hans3, hkW03, hfr03⟩
        · have hal_neq : wRead m1 tblW (sideAliveEpOff L_p2 sideBaseW eid) ≠ (ep₀ : ℤ) := by
            rw [wRead_wWrite_of_ne _ _ (Or.inl hneW)]
            intro heq; exact hal ((hal_iff eid heid_lt).mp heq)
          have hc_al_f : cValAt 0 inp m1
              (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW))
                                                  (.lit (2 + ((2 ^ L_p2 : ℕ) : ℤ))))
                                            (.readHeap scrW (.lit (wScr + 12)))))
                      (.readHeap scrW (.lit wScr))) = false := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (wRead m1 tblW ((wRead m1 scrW wSideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) +
              wRead m1 scrW (wScr + 12)) = wRead m1 scrW wScr) = false
            rw [hbW1, heid1, hep1, hal_addr, decide_eq_false_iff_not]; exact hal_neq
          have hnext : nextAns = none := by
            dsimp [nextAns, dyadicSideTailOpt]
            rw [if_neg (fun h => hal h.2.1)]
          refine ⟨m1,
            (DetExecAt.ite_true (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
              (DetExecAt.ite_true (C_c := 10) hc_del (by dsimp [condExprOps, intExprOps]; omega)
                (hd1.seq (DetExecAt.ite_false (C_c := 25) hc_al_f (by dsimp [condExprOps, intExprOps]; omega)
                  (DetExecAt.skip 0 inp m1))))).mono_cost (by unfold dyadicSideTailCheckCost; omega),
            hfp1,
            by rw [hnext, wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hans₀,
            fun w _ hw_out => wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hfr01⟩
      · have hc_del_f : cValAt 0 inp m₀ (.intLe (.lit (delta : ℤ)) (.readHeap scrW (.lit (wScr + 1)))) = false := by
          simp only [cValAt, evalArithCond, evalIntExpr]
          change decide ((delta : ℤ) ≤ wRead m₀ scrW (wScr + 1)) = false
          rw [ht_r, decide_eq_false_iff_not]; omega
        have hnext : nextAns = none := by
          dsimp [nextAns, dyadicSideTailOpt]
          rw [if_neg (fun h => hdel_le h.1)]
        exact ⟨m₀,
          (DetExecAt.ite_true (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
            (DetExecAt.ite_false (C_c := 10) hc_del_f (by dsimp [condExprOps, intExprOps]; omega)
              (DetExecAt.skip 0 inp m₀))).mono_cost (by unfold dyadicSideTailCheckCost; omega),
          hfp₀, by rw [hnext]; exact hans₀, fun _ _ _ => rfl,
          RadFrameOutside.refl scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀⟩

/-! ### 3. Single Active-Slot Sub-Query Helper (`r1` and `r2`) -/

def dyadicSideSlotSubQueryStmt (scrW scrR tblW tblR tblO : ℕ)
    (wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let bR := IntExpr.readHeap scrW (.lit wSideBaseR)
  let bMaxZ : ℤ := ((2 ^ L_p2 : ℕ) : ℤ)
  let sWStr := slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
  let sRStr := slotRStride R ℓ M₀ d
  let wEntryPtBase := wScr + 2
  let wS := wScr + 3
  let wSl := wScr + 8
  let wK := wScr + 9
  let wSlotBW := wScr + 10
  let wSlotBR := wScr + 11
  let wRawEid := wScr + 13
  let wQryBase := wScr + 16
  .ite (.intLt (.readHeap scrW (.lit wAnsOut)) (.lit 0))
    (.seq (.writeWordHeap scrW (.lit wK)
            (.add (.mul (.lit 2) (.readHeap scrW (.lit wS))) (.readHeap scrW (.lit wSl))))
    (.seq (.writeWordHeap scrW (.lit wSlotBW)
            (.add (.add bW (.lit (2 + 2 * bMaxZ + (n : ℤ))))
                  (.mul (.readHeap scrW (.lit wK)) (.lit sWStr))))
    (.seq (.writeWordHeap scrW (.lit wSlotBR)
            (.add (.add bR (.lit ((d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ))))
                  (.mul (.readHeap scrW (.lit wK)) (.lit sRStr))))
    (.seq (liveSlotQueryStmt scrW scrR tblW tblR tblO tblR
            wSlotBW wSlotBR wEntryPtBase wOffO wSideBaseR wRawEid wQryBase rScr
            R ℓ M₀ d M_lat S_lat cap_q A B_rat τ_q b_rat)
      (.ite (.intLe (.lit 0) (.readHeap scrW (.lit wRawEid)))
        (.writeWordHeap scrW (.lit wAnsOut)
          (.readHeap tblW (.add (.add bW (.lit 2)) (.readHeap scrW (.lit wRawEid)))))
        .skip)))))
    .skip

def dyadicSideSlotSubQueryCost (R ℓ M₀ d S_lat cap_q : ℕ) : ℕ :=
  160 + liveSlotQueryCost R ℓ M₀ d S_lat cap_q

theorem zeroRand_dyadicSideSlotSubQueryStmt (scrW scrR tblW tblR tblO : ℕ)
    (wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) :
    H3a.ZeroRandStmt (dyadicSideSlotSubQueryStmt scrW scrR tblW tblR tblO
      wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr
      n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q A B_rat τ_q b_rat) :=
  of_isZeroRandB rfl

theorem exec_dyadicSideSlotSubQueryStmt {d TW BW TR BR scrW scrR tblW tblR tblO : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr sideBaseW sideBaseR offO : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q : ℕ}
    (hM₀ : 1 ≤ M₀) (hS_lat : 2 * M_lat + 1 ≤ 2 ^ S_lat)
    {A B_rat τ_d : ℚ} (τ_q b_rat : ℚ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {o p_v : EuclideanSpace ℝ (Fin d)} (hpv_ne : p_v ≠ o)
    {U : Finset ℕ} {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b}
    (hwf : H4b.DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx)
    (s : Fin L_p2) (sl : Fin 2) (prevAns : Option ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneO : tblO ≠ scrR)
    (hwAns : 0 ≤ wAnsOut ∧ wAnsOut < (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + dyadicSideQueryRStride d ≤ (BR : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wSideBaseW)
    (hdisjBR : wSideBaseR < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wSideBaseR)
    (hdisjO : wOffO < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wOffO)
    (hdisjAns : wAnsOut < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wAnsOut)
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hbR : wRead m₀ scrW wSideBaseR = sideBaseR)
    (hoffO : wRead m₀ scrW wOffO = offO)
    (hepBase_r : wRead m₀ scrW (wScr + 2) = sideEntryPtOff d sideBaseR)
    (hs_r : wRead m₀ scrW (wScr + 3) = (s.val : ℤ))
    (hsl_r : wRead m₀ scrW (wScr + 8) = (sl.val : ℤ))
    (hans₀ : wRead m₀ scrW wAnsOut = optNatToInt prevAns)
    (ho : ∀ c : Fin d, rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpv : ∀ c : Fin d, rRead m₀ tblR (sideBaseR + (c.val : ℤ)) = euclideanCoord p_v c)
    {liveSlots : Fin L_p2 → Fin 2 → LiveSlot R ℓ M₀ d}
    (hblk_nonneg : 0 ≤ (liveSlots s sl).blkId)
    (htr_slot : LiveSlotTrackedH4 cap_u (2 ^ L_p2) idx.t_ins idx.entryAlive
      (idx.slots s sl) (liveSlots s sl))
    (henc_slot : EncLiveSlot tblW
      (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx s sl))
      tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx s sl))
      R ℓ M₀ d cap_u (2 ^ L_p2) (liveSlots s sl) m₀)
    (hhand : ∀ eid < idx.t_ins,
      wRead m₀ tblW (sideHandleOff sideBaseW eid) = (idx.entryHandle eid : ℤ))
    (hpt : ∀ eid < idx.t_ins, ∀ c : Fin d,
      rRead m₀ tblR (sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
        euclideanCoord (idx.entryPt eid) c) :
    let slotAns : Option ℕ :=
      ((idx.slots s sl).query hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q
        idx.entryPt o p_v idx.entryAlive).map idx.entryHandle
    let nextAns : Option ℕ :=
      match prevAns with
      | some w => some w
      | none => slotAns
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (dyadicSideSlotSubQueryStmt scrW scrR tblW tblR tblO
          wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr
          n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q A B_rat τ_q b_rat)
        m₀ m₁ (dyadicSideSlotSubQueryCost R ℓ M₀ d S_lat cap_q) ∧
      InFootprint TW BW TR BR m₁ ∧
      wRead m₁ scrW wAnsOut = optNatToInt nextAns ∧
      (∀ w, w ≠ wAnsOut →
        (w < wScr + 9 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m₁ := by
  classical
  intro slotAns nextAns
  have hge44 := dyadicSideQueryWStride_ge_44 ℓ M₀ cap_q
  have hstrW_eq : dyadicSideQueryWStride ℓ M₀ cap_q = 16 + slotQryWStride ℓ M₀ cap_q := rfl
  have hstrR_eq : dyadicSideQueryRStride d = slotQryRStride d := rfl
  cases prevAns with
  | some w_prev =>
      have hc_ans : cValAt 0 inp m₀ (.intLt (.readHeap scrW (.lit wAnsOut)) (.lit 0)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (wRead m₀ scrW wAnsOut < 0) = false
        rw [hans₀]; simp [optNatToInt]
      exact ⟨m₀,
        (DetExecAt.ite_false (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
          (DetExecAt.skip 0 inp m₀)).mono_cost (by unfold dyadicSideSlotSubQueryCost; omega),
        hfp₀, hans₀, fun _ _ _ => rfl,
        RadFrameOutside.refl scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀⟩
  | none =>
      have hc_ans : cValAt 0 inp m₀ (.intLt (.readHeap scrW (.lit wAnsOut)) (.lit 0)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (wRead m₀ scrW wAnsOut < 0) = true
        rw [hans₀]; simp [optNatToInt]
      let k : ℕ := sideSlotIdx s sl
      let slotBW : ℤ := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k
      let slotBR : ℤ := sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k
      let m1 := wWrite m₀ scrW (wScr + 9) (k : ℤ)
      let m2 := wWrite m1 scrW (wScr + 10) slotBW
      let m3 := wWrite m2 scrW (wScr + 11) slotBR
      have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 9))
          (.add (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 3))))
                (.readHeap scrW (.lit (wScr + 8))))) m₀ m1 25 :=
        DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wScr + 9)) _ rfl
          (by change 2 * wRead m₀ scrW (wScr + 3) + wRead m₀ scrW (wScr + 8) = (k : ℤ)
              rw [hs_r, hsl_r]; dsimp [k, sideSlotIdx])
          (by dsimp [intExprOps]; omega)
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 10))
          (.add (.add (.readHeap scrW (.lit wSideBaseW))
                      (.lit (2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ))))
                (.mul (.readHeap scrW (.lit (wScr + 9)))
                      (.lit (slotWStride R ℓ M₀ cap_u (2 ^ L_p2)))))) m1 m2 30 :=
        DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 10)) _ rfl
          (by change (wRead m1 scrW wSideBaseW + (2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ))) +
                wRead m1 scrW (wScr + 9) * slotWStride R ℓ M₀ cap_u (2 ^ L_p2) = slotBW
              have hbW1 : wRead m1 scrW wSideBaseW = sideBaseW := by
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbW
              rw [hbW1, wRead_wWrite_self]; dsimp [slotBW, sideSlotBaseW]; ring)
          (by dsimp [intExprOps]; omega)
      have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 11))
          (.add (.add (.readHeap scrW (.lit wSideBaseR))
                      (.lit ((d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ))))
                (.mul (.readHeap scrW (.lit (wScr + 9)))
                      (.lit (slotRStride R ℓ M₀ d))))) m2 m3 30 :=
        DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wScr + 11)) _ rfl
          (by change (wRead m2 scrW wSideBaseR + ((d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ))) +
                wRead m2 scrW (wScr + 9) * slotRStride R ℓ M₀ d = slotBR
              have hbR2 : wRead m2 scrW wSideBaseR = sideBaseR := by
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbR
              have hk2 : wRead m2 scrW (wScr + 9) = (k : ℤ) := by
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact wRead_wWrite_self _ _ _ _
              rw [hbR2, hk2]; dsimp [slotBR, sideSlotBaseR]; ring)
          (by dsimp [intExprOps]; omega)
      have hfp3 : InFootprint TW BW TR BR m3 :=
        InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW (by omega) (by omega))
          hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
      have hfr03 : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m3 :=
        ((RadFrameOutside.wWrite_scr scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ _ _).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m1 _ _)).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m2 _ _)
      have hwf_slot : (liveSlots s sl).WF cap_u (2 ^ L_p2) (liveSlots s sl).blkId.toNat
          idx.entryAlive (toP43Slot (idx.slots s sl)) :=
        (htr_slot.2 hblk_nonneg).2.2
      have henc_slot3 : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) (liveSlots s sl) m3 :=
        henc_slot.mono_frame (hfr03.mono_range (bW₂ := slotBW) (lW₂ := 0) (bR₂ := slotBR) (lR₂ := 0) (Or.inl rfl) (Or.inl rfl)) hneW hneR
          (Or.inr (Or.inr (add_zero slotBW).le)) (Or.inr (Or.inr (add_zero slotBR).le))
      have hEntryPt3 : ∀ eid : ℕ, idx.entryAlive eid = true →
          idx.entryPt eid ≠ o ∧
          ∀ c : Fin d, rRead m3 tblR (sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
            euclideanCoord (idx.entryPt eid) c := by
        intro eid hal
        have heid_lt : eid < idx.t_ins := by
          by_contra hnot
          have hf := hwf.2.1 eid (by omega)
          rw [hf] at hal; cases hal
        refine ⟨hwf.1 eid heid_lt, fun c => ?_⟩
        rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]
        exact hpt eid heid_lt c
      obtain ⟨m4, hd_q, hfp4, hraw4, _, hkW4, hfr34_slot⟩ :=
        exec_liveSlotQueryStmt (cap_q := cap_q) inp
          (wScr + 10) (wScr + 11) (wScr + 2) wOffO wSideBaseR (wScr + 13) (wScr + 16) rScr
          slotBW slotBR (sideEntryPtOff d sideBaseR) offO sideBaseR
          hM₀ hS_lat A B_rat τ_q b_rat idx.entryPt idx.entryAlive o p_v hpv_ne
          hwf_slot hfp3 hscrW hscrR hneW hneR hneO hneR
          ⟨by omega, by omega⟩
          ⟨by omega, by omega⟩
          ⟨hrScr.1, by rw [← hstrR_eq]; exact hrScr.2⟩
          (Or.inl (by omega)) (Or.inl (by omega)) (Or.inl (by omega))
          (by rcases hdisjO with h | h <;> [exact Or.inl (by omega); exact Or.inr (by omega)])
          (by rcases hdisjBR with h | h <;> [exact Or.inl (by omega); exact Or.inr (by omega)])
          (Or.inl (by omega))
          ⟨by omega, by omega, by omega, by omega, by omega⟩
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact wRead_wWrite_self _ _ _ _)
          (wRead_wWrite_self _ _ _ _)
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hepBase_r)
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hoffO)
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbR)
          (fun c => by rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]; exact ho c)
          (fun c => by rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]; exact hpv c)
          hEntryPt3 henc_slot3
      rw [toP43Slot_query] at hraw4
      have hfr04 : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m4 :=
        hfr03.trans (hfr34_slot.mono_range (Or.inl rfl) (Or.inl rfl))
      have hkW04 : ∀ w,
          (w < wScr + 9 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
          wRead m4 scrW w = wRead m₀ scrW w := by
        intro w hw_out
        have hdisj_q : w < wScr + 16 ∨ (wScr + 16) + slotQryWStride ℓ M₀ cap_q ≤ w := by
          rcases hw_out with h | h
          · exact Or.inl (by omega)
          · exact Or.inr (by omega)
        rw [hkW4 w (by omega) hdisj_q,
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      cases hq : (idx.slots s sl).query hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q
          idx.entryPt o p_v idx.entryAlive with
      | none =>
          rw [hq] at hraw4
          have hc_hit_f : cValAt 0 inp m4 (.intLe (.lit 0) (.readHeap scrW (.lit (wScr + 13)))) = false := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (0 ≤ wRead m4 scrW (wScr + 13)) = false
            rw [hraw4]; simp [optNatToInt]
          have hans4 : wRead m4 scrW wAnsOut = optNatToInt nextAns := by
            have hdisj_ans : wAnsOut < wScr + 16 ∨ (wScr + 16) + slotQryWStride ℓ M₀ cap_q ≤ wAnsOut := by
              rcases hdisjAns with h | h
              · exact Or.inl (by omega)
              · exact Or.inr (by omega)
            rw [hkW4 wAnsOut (by omega) hdisj_ans,
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hans₀]
            dsimp [nextAns, slotAns]; rw [hq]; rfl
          refine ⟨m4,
            (DetExecAt.ite_true (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
              (hd1.seq (hd2.seq (hd3.seq (hd_q.seq
                (DetExecAt.ite_false (C_c := 10) hc_hit_f (by dsimp [condExprOps, intExprOps]; omega)
                  (DetExecAt.skip 0 inp m4))))))).mono_cost
              (by unfold dyadicSideSlotSubQueryCost; omega),
            hfp4, hans4, fun w _ hw_out => hkW04 w hw_out, hfr04⟩
      | some eid =>
          rw [hq] at hraw4
          have hsnd := H4a1.pureFilterSlot_query_sound hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q
            idx.entryPt o p_v idx.entryAlive (idx.slots s sl) hq
          have heid_lt : eid < idx.t_ins := by
            by_contra hnot
            have hf := hwf.2.1 eid (by omega)
            rw [hf] at hsnd; exact Bool.noConfusion hsnd.1
          have hc_hit_t : cValAt 0 inp m4 (.intLe (.lit 0) (.readHeap scrW (.lit (wScr + 13)))) = true := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (0 ≤ wRead m4 scrW (wScr + 13)) = true
            rw [hraw4]; simp [optNatToInt]
          let m5 := wWrite m4 scrW wAnsOut (idx.entryHandle eid : ℤ)
          have hd_wr : DetExec inp (.writeWordHeap scrW (.lit wAnsOut)
              (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit 2))
                                    (.readHeap scrW (.lit (wScr + 13)))))) m4 m5 25 :=
            DetExecAt.writeWordHeap 0 inp m4 scrW (.lit wAnsOut) _ rfl
              (by change wRead m4 tblW ((wRead m4 scrW wSideBaseW + 2) + wRead m4 scrW (wScr + 13)) = _
                  have hbW4 : wRead m4 scrW wSideBaseW = sideBaseW := by
                    rw [hkW04 wSideBaseW
                      (by rcases hdisjBW with h | h <;> [exact Or.inl (by omega); exact Or.inr h])]
                    exact hbW
                  have hhd_addr : (sideBaseW + 2) + (eid : ℤ) = sideHandleOff sideBaseW eid := by
                    unfold sideHandleOff; ring
                  rw [hbW4, hraw4]
                  dsimp [optNatToInt]
                  rw [hhd_addr, hfr04.1 tblW _ hneW (Or.inr (Or.inr (by unfold sideHandleOff; omega)))]
                  exact hhand eid heid_lt)
              (by dsimp [intExprOps]; omega)
          refine ⟨m5,
            (DetExecAt.ite_true (C_c := 10) hc_ans (by dsimp [condExprOps, intExprOps]; omega)
              (hd1.seq (hd2.seq (hd3.seq (hd_q.seq
                (DetExecAt.ite_true (C_c := 10) hc_hit_t (by dsimp [condExprOps, intExprOps]; omega)
                  hd_wr)))))).mono_cost
              (by unfold dyadicSideSlotSubQueryCost; omega),
            InFootprint.wWrite hfp4 hscrW hwAns.1 hwAns.2,
            by dsimp [nextAns, slotAns]; rw [hq, wRead_wWrite_self]; rfl,
            fun w hw_ne hw_out => by
              rw [wRead_wWrite_of_ne _ _ (Or.inr hw_ne)]
              exact hkW04 w hw_out,
            hfr04.trans (RadFrameOutside.wWrite_scr scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m4 _ _)⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
