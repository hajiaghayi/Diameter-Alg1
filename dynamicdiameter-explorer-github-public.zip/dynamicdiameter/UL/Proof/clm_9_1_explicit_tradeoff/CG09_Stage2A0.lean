import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Layout
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_S2b
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 1. Dynamic Loop Combinators (`ExecDet.repeatExpr`, `dynForLoopStmt`, `foldrSeqStmt`) -/

open Classical in
theorem ExecDet.repeatExpr {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (countE : IntExpr) (body : ArithRAMStmt) {N N_max C_cnt C_b : ℕ}
    {m₀ : ArithRAMMemory} (Inv : ℕ → ArithRAMMemory → Prop)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hcnt : (evalIntExpr inp.toWordView 0 m₀.words countE).1 = (N : ℤ))
    (huc : intExprOps countE ≤ C_cnt)
    (hN_le : N ≤ N_max)
    (hInv₀ : Inv 0 m₀)
    (hbody : ∀ i < N, ∀ m, Inv i m → InFootprint TW BW TR BR m →
      ExecDet TW BW TR BR inp body m (Inv (i + 1)) C_b) :
    ExecDet TW BW TR BR inp (.repeatN countE body) m₀ (Inv N) (C_cnt + N_max * C_b) := by
  let stepFn : ∀ (i : ℕ) (m : ArithRAMMemory), ArithRAMMemory := fun i m =>
    if h : i < N ∧ Inv i m ∧ InFootprint TW BW TR BR m then
      Classical.choose (hbody i h.1 m h.2.1 h.2.2)
    else m
  let mSeq : ℕ → ArithRAMMemory := fun k => Nat.recOn k m₀ stepFn
  have hmSeq_props : ∀ k ≤ N, Inv k (mSeq k) ∧ InFootprint TW BW TR BR (mSeq k) ∧
      (∀ i < k, StepFP TW BW TR BR inp body (mSeq i) (mSeq (i + 1)) [] [] C_b) := by
    intro k
    induction k with
    | zero =>
      intro _
      exact ⟨hInv₀, hfp₀, fun _ hi => absurd hi (Nat.not_lt_zero _)⟩
    | succ k ih =>
      intro hk_le
      obtain ⟨hIk, hfpk, hprev⟩ := ih (by omega)
      have hk_lt : k < N := by omega
      have hcond : k < N ∧ Inv k (mSeq k) ∧ InFootprint TW BW TR BR (mSeq k) := ⟨hk_lt, hIk, hfpk⟩
      have hnext_eq : mSeq (k + 1) = Classical.choose (hbody k hk_lt (mSeq k) hIk hfpk) := by
        show stepFn k (mSeq k) = _
        dsimp only [stepFn]; rw [dif_pos hcond]
      obtain ⟨hIk1, hfp_step⟩ := Classical.choose_spec (hbody k hk_lt (mSeq k) hIk hfpk)
      rw [← hnext_eq] at hIk1 hfp_step
      refine ⟨hIk1, hfp_step.1, fun i hi => ?_⟩
      rcases Nat.lt_succ_iff_lt_or_eq.mp hi with hlt | rfl
      · exact hprev i hlt
      · exact hfp_step
  obtain ⟨hIN, hfpN, hsteps⟩ := hmSeq_props N le_rfl
  refine ⟨mSeq N, hIN, hfpN, ?_⟩
  exact (StepTo.repeatN countE body N C_cnt C_b (TW * BW + TR * BR) mSeq (fun _ => [])
    hfp₀.1 hfp₀.cellCount_le hcnt huc (fun i hi => (hsteps i hi).2)).mono
    (Nat.add_le_add_left (Nat.mul_le_mul_right C_b hN_le) C_cnt) le_rfl

/-- Dynamic-count indexed `for` loop reading iteration count from `engScrTbl[lenR]`
and maintaining `0 .. N - 1` in `engScrTbl[ctrR]` (`ctrR ≠ lenR`). -/
def dynForLoopStmt (ctrR lenR : ℤ) (body : ArithRAMStmt) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit ctrR) (.lit 0))
    (.repeatN (.readHeap engScrTbl (.lit lenR))
      (.seq body
        (.writeWordHeap engScrTbl (.lit ctrR)
          (.add (.readHeap engScrTbl (.lit ctrR)) (.lit 1)))))

theorem zeroRand_dynForLoopStmt (ctrR lenR : ℤ) {body : ArithRAMStmt}
    (hb : ZeroRandStmt body) : ZeroRandStmt (dynForLoopStmt ctrR lenR body) :=
  .seq (.writeWordHeap _ _ _) (.repeatN (.seq hb (.writeWordHeap _ _ _)))

theorem ExecDet.dynForLoop {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (ctrR lenR : ℤ) (body : ArithRAMStmt) {N N_max C_b : ℕ}
    {m₀ : ArithRAMMemory} (Inv : ℕ → ArithRAMMemory → Prop)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hTW : 9 ≤ TW)
    (hctr0 : 0 ≤ ctrR) (hctrB : ctrR < (BW : ℤ))
    (hne : ctrR ≠ lenR)
    (hlen : wRead m₀ engScrTbl lenR = (N : ℤ))
    (hN_le : N ≤ N_max)
    (hInv₀ : Inv 0 (H3a.wWrite m₀ engScrTbl ctrR 0))
    (hbody : ∀ i < N, ∀ m, Inv i m → wRead m engScrTbl ctrR = (i : ℤ) →
      InFootprint TW BW TR BR m →
      ExecDet TW BW TR BR inp body m
        (fun m' => wRead m' engScrTbl ctrR = (i : ℤ) ∧
          Inv (i + 1) (H3a.wWrite m' engScrTbl ctrR ((i : ℤ) + 1))) C_b) :
    ExecDet TW BW TR BR inp (dynForLoopStmt ctrR lenR body) m₀ (Inv N)
      (16 + N_max * (C_b + 12)) := by
  unfold dynForLoopStmt
  let LoopInv : ℕ → ArithRAMMemory → Prop := fun i m =>
    Inv i m ∧ wRead m engScrTbl ctrR = (i : ℤ)
  refine ExecDet.seq' (4 + N_max * (C_b + 12))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit ctrR) (.lit 0) ctrR 0
      hfp₀ (by unfold engScrTbl; omega) hctr0 hctrB rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₁ hm₁ hfp₁; subst hm₁
  have hlen₁ : wRead (H3a.wWrite m₀ engScrTbl ctrR 0) engScrTbl lenR = (N : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr hne.symm)]; exact hlen
  refine (ExecDet.repeatExpr (N := N) (N_max := N_max) (C_cnt := 4) (C_b := C_b + 12)
    (.readHeap engScrTbl (.lit lenR)) _ LoopInv hfp₁
    (by simp only [evalIntExpr]; exact hlen₁) (by simp [intExprOps]) hN_le
    ⟨hInv₀, wRead_wWrite_self m₀ engScrTbl ctrR 0⟩ ?_).mono (fun _ hm _ => hm.1) le_rfl
  intro i hi m ⟨hI, hctr_m⟩ hfp_m
  refine ExecDet.seq (hbody i hi m hI hctr_m hfp_m) ?_
  intro m' ⟨hctr_m', hI_next⟩ hfp_m'
  exact ExecDet.wWrite (C := 12) inp engScrTbl (.lit ctrR)
    (.add (.readHeap engScrTbl (.lit ctrR)) (.lit 1)) ctrR ((i : ℤ) + 1)
    hfp_m' (by unfold engScrTbl; omega) hctr0 hctrB rfl
    (by simp only [evalIntExpr]; change wRead m' engScrTbl ctrR + 1 = _; rw [hctr_m'])
    (by simp [intExprOps])
    ⟨hI_next, by rw [wRead_wWrite_self]; omega⟩

/-- Static sequential fold over a finite list `xs : List α`. -/
def foldrSeqStmt {α : Type*} (f : α → ArithRAMStmt) : List α → ArithRAMStmt
  | [] => .skip
  | x :: xs => .seq (f x) (foldrSeqStmt f xs)

theorem zeroRand_foldrSeqStmt {α : Type*} {f : α → ArithRAMStmt} :
    ∀ (xs : List α), (∀ x ∈ xs, ZeroRandStmt (f x)) → ZeroRandStmt (foldrSeqStmt f xs)
  | [], _ => .skip
  | x :: xs, h =>
      .seq (h x List.mem_cons_self)
        (zeroRand_foldrSeqStmt xs (fun y hy => h y (List.mem_cons_of_mem x hy)))

theorem ExecDet.foldrSeq {α : Type*} {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (f : α → ArithRAMStmt) (xs : List α) (C_step : ℕ) :
    ∀ (idx : ℕ) {m₀ : ArithRAMMemory} (Inv : ℕ → ArithRAMMemory → Prop),
      InFootprint TW BW TR BR m₀ →
      Inv idx m₀ →
      (∀ k (hk : k < xs.length), ∀ m, Inv (idx + k) m → InFootprint TW BW TR BR m →
        ExecDet TW BW TR BR inp (f (xs[k]'hk)) m (Inv (idx + k + 1)) C_step) →
      ExecDet TW BW TR BR inp (foldrSeqStmt f xs) m₀ (Inv (idx + xs.length))
        (1 + xs.length * C_step) := by
  induction xs with
  | nil =>
      intro idx m₀ Inv hfp₀ hI₀ _
      simpa [foldrSeqStmt] using ExecDet.skip inp hfp₀ hI₀ le_rfl
  | cons x tl ih =>
      intro idx m₀ Inv hfp₀ hI₀ hstep
      unfold foldrSeqStmt
      have h0 : ExecDet TW BW TR BR inp (f x) m₀ (Inv (idx + 1)) C_step := by
        simpa using hstep 0 (Nat.zero_lt_succ _) m₀ (by simpa using hI₀) hfp₀
      refine ExecDet.seq' (1 + tl.length * C_step) h0 (by simp [Nat.succ_mul]; omega) ?_
      intro m₁ hI₁ hfp₁
      have htl := ih (idx + 1) Inv hfp₁ hI₁ (fun k hk m hIm hfpm => by
        have hk' : k + 1 < (x :: tl).length := Nat.succ_lt_succ hk
        have hs := hstep (k + 1) hk' m (by rwa [show idx + (k + 1) = idx + 1 + k by omega]) hfpm
        simpa [show idx + (k + 1) + 1 = idx + 1 + k + 1 by omega] using hs)
      simpa [List.length_cons, show idx + 1 + tl.length = idx + (tl.length + 1) by omega] using htl

/-! ### 2. Layout Disjointness, Empty Sparse-Set, Prefix Insertion & `allSlots.Nodup` Lemmas -/

theorem encSparseSet_empty_of_zero {N_cap : ℕ} {lenIdx elemOff posOff : ℤ} {mem : ArithRAMMemory}
    (hz : wRead mem engMetaTbl lenIdx = 0) :
    EncSparseSet N_cap lenIdx elemOff posOff [] mem :=
  ⟨List.nodup_nil, fun _ h => absurd h List.not_mem_nil, hz,
   fun _ h => absurd h (Nat.not_lt_zero _)⟩

theorem denseInsert_take_succ {arr : List ℕ} (hnd : arr.Nodup) {k : ℕ} (hk : k < arr.length) :
    (arr[k]'hk) ∉ arr.take k ∧
    denseInsert (arr[k]'hk) (arr.take k) = arr.take (k + 1) := by
  refine ⟨?_, ?_⟩
  · intro hmem
    rw [List.mem_iff_getElem] at hmem
    rcases hmem with ⟨i, hi_take, heq⟩
    have hi_k : i < k := by rw [List.length_take_of_le (Nat.le_of_lt hk)] at hi_take; exact hi_take
    have hi_len : i < arr.length := lt_trans hi_k hk
    rw [List.getElem_take] at heq
    have hinj := List.nodup_iff_injective_getElem.mp hnd
    have hf : (⟨i, hi_len⟩ : Fin arr.length) = ⟨k, hk⟩ := hinj heq
    have : i = k := congrArg Fin.val hf
    omega
  · unfold denseInsert
    exact (List.take_succ_eq_append_getElem hk).symm

theorem handle_lt_nextFresh_of_mem_act {d n : ℕ} {P : DynamicPointSet d} {hp : HandlePool d n}
    (hhp : hp.WellFormed P) {x : ℕ} (hx : x ∈ P.activeHandles) :
    x < hp.nextFresh ∧ x < n := by
  have hx_l : x ∈ hp.actList := List.mem_toFinset.mp (hhp.2.2.2.1.symm ▸ hx)
  have hlt := hhp.2.2.2.2.1 x hx_l
  exact ⟨hlt, lt_of_lt_of_le hlt hhp.1⟩

theorem M_slots_gt_used {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h)
    {servSlots : List ℕ} (hs : servSlots.length ≤ cp.D_max)
    {U : Fin cp.D_max → List ℕ} (hU : ∀ r, (U r).length ≤ cp.D_max + 1) :
    (servSlots ++ (List.finRange cp.D_max).flatMap U).length < M_slots cp := by
  have hflat : ∀ (xs : List (Fin cp.D_max)),
      (xs.flatMap U).length ≤ xs.length * (cp.D_max + 1) := by
    intro xs; induction xs with
    | nil => simp
    | cons r tl ih =>
        simp only [List.flatMap_cons, List.length_append, List.length_cons, Nat.succ_mul]
        have hr := hU r
        omega
  have hf := hflat (List.finRange cp.D_max)
  rw [List.length_finRange] at hf
  rw [List.length_append]
  unfold M_slots
  nlinarith only [hs, hf]

theorem nodup_append_disj {α : Type*} {l₁ l₂ : List α} :
    (l₁ ++ l₂).Nodup ↔ l₁.Nodup ∧ l₂.Nodup ∧ (∀ x, x ∈ l₁ → x ∈ l₂ → False) := by
  induction l₁ with
  | nil => simp
  | cons a tl ih =>
      simp only [List.cons_append, List.nodup_cons, List.mem_append, List.mem_cons, not_or, ih]
      constructor
      · rintro ⟨⟨hna1, hna2⟩, htl, hl2, hdisj⟩
        refine ⟨⟨hna1, htl⟩, hl2, fun x hx1 hx2 => ?_⟩
        rcases hx1 with rfl | hxtl
        · exact hna2 hx2
        · exact hdisj x hxtl hx2
      · rintro ⟨⟨hna1, htl⟩, hl2, hdisj⟩
        exact ⟨⟨hna1, fun ha2 => hdisj a (Or.inl rfl) ha2⟩, htl, hl2,
          fun x hxtl hx2 => hdisj x (Or.inr hxtl) hx2⟩

theorem flatMap_mem_iff_finRange {D : ℕ} {U : Fin D → List ℕ} {s : ℕ} :
    s ∈ (List.finRange D).flatMap U ↔ ∃ r : Fin D, s ∈ U r := by
  simp [List.mem_flatMap, List.mem_finRange]

theorem nodup_flatMap_of_nodup {α : Type*} [DecidableEq α] {xs : List α} (hxs : xs.Nodup)
    (U : α → List ℕ) :
    (xs.flatMap U).Nodup ↔
      (∀ r ∈ xs, (U r).Nodup) ∧
      (∀ r₁ ∈ xs, ∀ r₂ ∈ xs, r₁ ≠ r₂ → ∀ s, s ∈ U r₁ → s ∈ U r₂ → False) := by
  induction xs with
  | nil => simp
  | cons a tl ih =>
      rw [List.nodup_cons] at hxs
      rcases hxs with ⟨ha_not, htl_nd⟩
      simp only [List.flatMap_cons, nodup_append_disj, ih htl_nd, List.mem_flatMap]
      constructor
      · rintro ⟨hUa, ⟨htl1, htl2⟩, hdisj⟩
        refine ⟨fun r hr => ?_, fun r₁ hr₁ r₂ hr₂ hne s hs1 hs2 => ?_⟩
        · rcases List.mem_cons.mp hr with rfl | hrt
          · exact hUa
          · exact htl1 r hrt
        · rcases List.mem_cons.mp hr₁ with rfl | h1t
          · rcases List.mem_cons.mp hr₂ with rfl | h2t
            · exact hne rfl
            · exact hdisj s hs1 ⟨r₂, h2t, hs2⟩
          · rcases List.mem_cons.mp hr₂ with rfl | h2t
            · exact hdisj s hs2 ⟨r₁, h1t, hs1⟩
            · exact htl2 r₁ h1t r₂ h2t hne s hs1 hs2
      · rintro ⟨hall1, hall2⟩
        refine ⟨hall1 a List.mem_cons_self,
          ⟨fun r hr => hall1 r (List.mem_cons_of_mem a hr),
           fun r₁ h1 r₂ h2 hne s hs1 hs2 =>
             hall2 r₁ (List.mem_cons_of_mem a h1) r₂ (List.mem_cons_of_mem a h2) hne s hs1 hs2⟩,
          fun s hsa ⟨r, hrt, hsr⟩ =>
            hall2 a List.mem_cons_self r (List.mem_cons_of_mem a hrt)
              (fun heq => ha_not (heq ▸ hrt)) s hsa hsr⟩

theorem nodup_finRange_flatMap_iff {D : ℕ} {U : Fin D → List ℕ} :
    ((List.finRange D).flatMap U).Nodup ↔
      (∀ r : Fin D, (U r).Nodup) ∧
      (∀ r₁ r₂ : Fin D, r₁ ≠ r₂ → ∀ s, s ∈ U r₁ → s ∈ U r₂ → False) := by
  rw [nodup_flatMap_of_nodup (List.nodup_finRange D) U]
  simp [List.mem_finRange]

theorem allSlots_nodup_update_sub {D M : ℕ} {servSlots : List ℕ}
    {U U' : Fin D → List ℕ} (r₀ : Fin D)
    (hnd : (servSlots ++ (List.finRange D).flatMap U).Nodup)
    (hlt : ∀ s ∈ servSlots ++ (List.finRange D).flatMap U, s < M)
    (hother : ∀ r ≠ r₀, U' r = U r)
    (hr₀_nd : (U' r₀).Nodup)
    (hr₀_sub : ∀ s ∈ U' r₀, s ∈ U r₀) :
    (servSlots ++ (List.finRange D).flatMap U').Nodup ∧
    (∀ s ∈ servSlots ++ (List.finRange D).flatMap U', s < M) := by
  rw [nodup_append_disj] at hnd ⊢
  rcases hnd with ⟨hnd_serv, hnd_flat, hdisj⟩
  rw [nodup_finRange_flatMap_iff] at hnd_flat ⊢
  have hsub_all : ∀ s ∈ servSlots ++ (List.finRange D).flatMap U',
      s ∈ servSlots ++ (List.finRange D).flatMap U := by
    intro s hs
    rcases List.mem_append.mp hs with hs1 | hs2
    · exact List.mem_append_left _ hs1
    · rcases flatMap_mem_iff_finRange.mp hs2 with ⟨r, hr⟩
      apply List.mem_append_right
      refine flatMap_mem_iff_finRange.mpr ⟨r, ?_⟩
      by_cases heq : r = r₀
      · subst heq; exact hr₀_sub s hr
      · rwa [← hother r heq]
  refine ⟨⟨hnd_serv, ⟨fun r => ?_, fun r₁ r₂ hne s hs1 hs2 => ?_⟩, fun s hs1 hs2 => ?_⟩,
    fun s hs => hlt s (hsub_all s hs)⟩
  · by_cases heq : r = r₀
    · subst heq; exact hr₀_nd
    · rw [hother r heq]; exact hnd_flat.1 r
  · have hm1 : s ∈ U r₁ := by by_cases h1 : r₁ = r₀; { subst h1; exact hr₀_sub s hs1 }; { rwa [← hother r₁ h1] }
    have hm2 : s ∈ U r₂ := by by_cases h2 : r₂ = r₀; { subst h2; exact hr₀_sub s hs2 }; { rwa [← hother r₂ h2] }
    exact hnd_flat.2 r₁ r₂ hne s hm1 hm2
  · rcases flatMap_mem_iff_finRange.mp hs2 with ⟨r, hr⟩
    have hm : s ∈ U r := by by_cases h1 : r = r₀; { subst h1; exact hr₀_sub s hr }; { rwa [← hother r h1] }
    exact hdisj s hs1 (flatMap_mem_iff_finRange.mpr ⟨r, hm⟩)

theorem allSlots_nodup_update_append_fresh {D M : ℕ} {servSlots : List ℕ}
    {U U' : Fin D → List ℕ} (r₀ : Fin D) {ns : ℕ}
    (hnd : (servSlots ++ (List.finRange D).flatMap U).Nodup)
    (hlt : ∀ s ∈ servSlots ++ (List.finRange D).flatMap U, s < M)
    (hns_M : ns < M)
    (hns_fresh : ns ∉ servSlots ++ (List.finRange D).flatMap U)
    (hother : ∀ r ≠ r₀, U' r = U r)
    (hr₀_eq : U' r₀ = U r₀ ++ [ns]) :
    (servSlots ++ (List.finRange D).flatMap U').Nodup ∧
    (∀ s ∈ servSlots ++ (List.finRange D).flatMap U', s < M) := by
  have hns_not_serv : ns ∉ servSlots := fun hm => hns_fresh (List.mem_append_left _ hm)
  have hns_not_U : ∀ r : Fin D, ns ∉ U r := fun r hm =>
    hns_fresh (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hm⟩))
  rw [nodup_append_disj] at hnd ⊢
  rcases hnd with ⟨hnd_serv, hnd_flat, hdisj⟩
  rw [nodup_finRange_flatMap_iff] at hnd_flat ⊢
  refine ⟨⟨hnd_serv, ⟨fun r => ?_, fun r₁ r₂ hne s hs1 hs2 => ?_⟩, fun s hs1 hs2 => ?_⟩,
    fun s hs => ?_⟩
  · by_cases heq : r = r₀
    · subst heq; rw [hr₀_eq, nodup_append_disj]
      exact ⟨hnd_flat.1 r, List.nodup_singleton ns,
        fun x hx hy => by rw [List.mem_singleton.mp hy] at hx; exact hns_not_U r hx⟩
    · rw [hother r heq]; exact hnd_flat.1 r
  · have hcases : ∀ r : Fin D, s ∈ U' r → s ∈ U r ∨ (r = r₀ ∧ s = ns) := by
      intro r hr
      by_cases heq : r = r₀
      · subst heq; rw [hr₀_eq] at hr
        rcases List.mem_append.mp hr with h1 | h2
        · exact Or.inl h1
        · exact Or.inr ⟨rfl, List.mem_singleton.mp h2⟩
      · rw [hother r heq] at hr; exact Or.inl hr
    rcases hcases r₁ hs1 with hm1 | ⟨rfl, rfl⟩
    · rcases hcases r₂ hs2 with hm2 | ⟨rfl, rfl⟩
      · exact hnd_flat.2 r₁ r₂ hne s hm1 hm2
      · exact hns_not_U r₁ hm1
    · rcases hcases r₂ hs2 with hm2 | ⟨rfl, _⟩
      · exact hns_not_U r₂ hm2
      · exact hne rfl
  · rcases flatMap_mem_iff_finRange.mp hs2 with ⟨r, hr⟩
    by_cases heq : r = r₀
    · subst heq; rw [hr₀_eq] at hr
      rcases List.mem_append.mp hr with hm | hns_eq
      · exact hdisj s hs1 (flatMap_mem_iff_finRange.mpr ⟨r, hm⟩)
      · rw [List.mem_singleton.mp hns_eq] at hs1; exact hns_not_serv hs1
    · rw [hother r heq] at hr
      exact hdisj s hs1 (flatMap_mem_iff_finRange.mpr ⟨r, hr⟩)
  · rcases List.mem_append.mp hs with hs1 | hs2
    · exact hlt s (List.mem_append_left _ hs1)
    · rcases flatMap_mem_iff_finRange.mp hs2 with ⟨r, hr⟩
      by_cases heq : r = r₀
      · subst heq; rw [hr₀_eq] at hr
        rcases List.mem_append.mp hr with hm | hns_eq
        · exact hlt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hm⟩))
        · rw [List.mem_singleton.mp hns_eq]; exact hns_M
      · rw [hother r heq] at hr
        exact hlt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hr⟩))

theorem allSlots_nodup_commit {D M : ℕ} {servSlots : List ℕ}
    {U U' : Fin D → List ℕ} (r₀ : Fin D)
    (hnd : (servSlots ++ (List.finRange D).flatMap U).Nodup)
    (hlt : ∀ s ∈ servSlots ++ (List.finRange D).flatMap U, s < M)
    (hother : ∀ r ≠ r₀, U' r = U r)
    (hr₀_nil : U' r₀ = []) :
    ((servSlots.take r₀.val ++ U r₀) ++ (List.finRange D).flatMap U').Nodup ∧
    (∀ s ∈ (servSlots.take r₀.val ++ U r₀) ++ (List.finRange D).flatMap U', s < M) := by
  rw [nodup_append_disj] at hnd ⊢
  rcases hnd with ⟨hnd_serv, hnd_flat, hdisj⟩
  rw [nodup_finRange_flatMap_iff] at hnd_flat ⊢
  have htake_nd : (servSlots.take r₀.val).Nodup := hnd_serv.sublist (List.take_sublist _ _)
  have hnew_serv_nd : (servSlots.take r₀.val ++ U r₀).Nodup := by
    rw [nodup_append_disj]
    exact ⟨htake_nd, hnd_flat.1 r₀, fun s hs1 hs2 =>
      hdisj s (List.mem_of_mem_take hs1) (flatMap_mem_iff_finRange.mpr ⟨r₀, hs2⟩)⟩
  have hsub_all : ∀ s ∈ (servSlots.take r₀.val ++ U r₀) ++ (List.finRange D).flatMap U',
      s ∈ servSlots ++ (List.finRange D).flatMap U := by
    intro s hs
    rcases List.mem_append.mp hs with hs_new | hs_fl
    · rcases List.mem_append.mp hs_new with htk | hur0
      · exact List.mem_append_left _ (List.mem_of_mem_take htk)
      · exact List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r₀, hur0⟩)
    · rcases flatMap_mem_iff_finRange.mp hs_fl with ⟨r, hr⟩
      by_cases heq : r = r₀
      · subst heq; rw [hr₀_nil] at hr; exact absurd hr List.not_mem_nil
      · rw [hother r heq] at hr
        exact List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hr⟩)
  refine ⟨⟨hnew_serv_nd, ⟨fun r => ?_, fun r₁ r₂ hne s hs1 hs2 => ?_⟩, fun s hs1 hs2 => ?_⟩,
    fun s hs => hlt s (hsub_all s hs)⟩
  · by_cases heq : r = r₀
    · subst heq; rw [hr₀_nil]; exact List.nodup_nil
    · rw [hother r heq]; exact hnd_flat.1 r
  · by_cases h1 : r₁ = r₀
    · subst h1; rw [hr₀_nil] at hs1; exact absurd hs1 List.not_mem_nil
    · by_cases h2 : r₂ = r₀
      · subst h2; rw [hr₀_nil] at hs2; exact absurd hs2 List.not_mem_nil
      · rw [hother r₁ h1] at hs1; rw [hother r₂ h2] at hs2
        exact hnd_flat.2 r₁ r₂ hne s hs1 hs2
  · rcases flatMap_mem_iff_finRange.mp hs2 with ⟨r, hr⟩
    by_cases heq : r = r₀
    · subst heq; rw [hr₀_nil] at hr; exact absurd hr List.not_mem_nil
    · rw [hother r heq] at hr
      rcases List.mem_append.mp hs1 with htk | hur0
      · exact hdisj s (List.mem_of_mem_take htk) (flatMap_mem_iff_finRange.mpr ⟨r, hr⟩)
      · exact hnd_flat.2 r₀ r (Ne.symm heq) s hur0 hr

theorem allSlots_nodup_serv_append_fresh {D M : ℕ} {servSlots : List ℕ}
    {U : Fin D → List ℕ} {ns : ℕ}
    (hnd : (servSlots ++ (List.finRange D).flatMap U).Nodup)
    (hlt : ∀ s ∈ servSlots ++ (List.finRange D).flatMap U, s < M)
    (hns_M : ns < M)
    (hns_fresh : ns ∉ servSlots ++ (List.finRange D).flatMap U) :
    ((servSlots ++ [ns]) ++ (List.finRange D).flatMap U).Nodup ∧
    (∀ s ∈ (servSlots ++ [ns]) ++ (List.finRange D).flatMap U, s < M) := by
  have hns_not_serv : ns ∉ servSlots := fun hm => hns_fresh (List.mem_append_left _ hm)
  have hns_not_fl : ns ∉ (List.finRange D).flatMap U := fun hm => hns_fresh (List.mem_append_right _ hm)
  rw [nodup_append_disj] at hnd ⊢
  rcases hnd with ⟨hnd_serv, hnd_flat, hdisj⟩
  refine ⟨⟨?_, hnd_flat, fun s hs1 hs2 => ?_⟩, fun s hs => ?_⟩
  · rw [nodup_append_disj]
    exact ⟨hnd_serv, List.nodup_singleton ns, fun x hx hy => by
      rw [List.mem_singleton.mp hy] at hx; exact hns_not_serv hx⟩
  · rcases List.mem_append.mp hs1 with hs_old | hs_ns
    · exact hdisj s hs_old hs2
    · rw [List.mem_singleton.mp hs_ns] at hs2; exact hns_not_fl hs2
  · rcases List.mem_append.mp hs with hs1 | hs2
    · rcases List.mem_append.mp hs1 with hs_old | hs_ns
      · exact hlt s (List.mem_append_left _ hs_old)
      · rw [List.mem_singleton.mp hs_ns]; exact hns_M
    · exact hlt s (List.mem_append_right _ hs2)

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
