import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_FinalB
import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Stage1
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3
open UL.Proof.clm_9_1_explicit_tradeoff.CG15
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge

/-! ### 1. Stage-2-Only Interface (Stages 1, 3, and 4 Already Wired In!) -/

/-- Minimal 4-field interface for Stage 2; Stages 1 (`CG19_Stage1`), 3 (`CG02_Stage3`),
and 4 (`CG20_Stage4`) are already wired into `mkStepChainRAMSpec_fromStage2`. -/
structure Stage2RAMOnly {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) where
  s2 : ArithRAMStmt
  C2 : ℕ
  hzr2 : ZeroRandStmt s2
  exec2 :
    ∀ (inp : ArithRAMInput d) {P' : DynamicPointSet d}
      {st₁ : ChainEngineState cp} {bits : Fin cp.B_STEP → Bool} {m₁ : ArithRAMMemory},
      P'.WellFormed cp.n →
      PostStage1WF cp P' st₁ →
      InFootprint ops.TW ops.BW ops.TR ops.BR m₁ →
      EncChainEngine ops st₁ m₁ →
      MemHasStepCoins cp bits m₁ →
      let ω₂ := (bitsToStepCoinBundle cp bits).2.1
      let st₂ := stepStage2 cp st₁ ω₂
      ExecDet ops.TW ops.BW ops.TR ops.BR inp s2 m₁
        (fun m₂ =>
          EncChainEngine ops st₂ m₂ ∧
          MemHasStepCoins cp bits m₂ ∧
          wRead m₂ 0 0 = wRead m₁ 0 0)
        C2

def Stage2RAMOnly.toStage12 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    (s2 : Stage2RAMOnly ops) : Stage12RAMBundle ops where
  s1 := stepStage1Stmt ops
  s2 := s2.s2
  C1 := C_stage1 ops
  C2 := s2.C2
  hzr1 := zeroRand_stepStage1Stmt ops
  hzr2 := s2.hzr2
  exec1 := exec_stepStage1Stmt ops
  exec2 := s2.exec2

def mkStepChainRAMSpec_fromStage2 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1) (hh0 : 0 < h) (hh1 : h < 1)
    (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops)
    (s2 : Stage2RAMOnly ops) :
    StepChainRAMSpec cp :=
  mkStepChainRAMSpec12 h_lem_5_1 h_clm_7_3 hd he1 hh0 hh1 ops mops s2.toStage12

/-! ### 2. Polynomial Work Bound for `CG19.C_stage1 ops` -/

private theorem c_stage1_arith {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (P B : ℕ) (hP1 : 1 ≤ P) (hB1 : 1 ≤ B)
    (hD : cp.D_max ≤ P) (hd_P : d ≤ P)
    (hins : ops.C_ins ≤ B) (hdel : ops.C_del ≤ B)
    (hbump : ops.C_bump ≤ B) (hball : ops.C_ball ≤ B) (hread : ops.C_read ≤ B) :
    C_stage1 ops ≤ 1600 * (P ^ 2 * B) := by
  have hP_P2 : P ≤ P ^ 2 := by simpa [sq] using Nat.le_mul_of_pos_right P hP1
  have h1_P2 : 1 ≤ P ^ 2 := hP1.trans hP_P2
  have hPB : B ≤ P * B := Nat.le_mul_of_pos_left B hP1
  have hmax_id : max ops.C_ins ops.C_del ≤ B := max_le hins hdel
  have hls : C_liveSingle ops ≤ 33 * B := by
    unfold C_liveSingle; omega
  have hll1 : (C_liveSingle ops + 48) + 6 ≤ 87 * B := by omega
  have hll : C_liveList ops ≤ 117 * (P * B) := by
    unfold C_liveList
    have hm : cp.D_max * ((C_liveSingle ops + 48) + 6) ≤ P * (87 * B) :=
      Nat.mul_le_mul hD hll1
    have h30 : 30 ≤ 30 * (P * B) := by
      have : 1 ≤ P * B := Nat.mul_pos hP1 hB1
      omega
    calc 30 + cp.D_max * ((C_liveSingle ops + 48) + 6)
        ≤ 30 * (P * B) + P * (87 * B) := Nat.add_le_add h30 hm
      _ = 117 * (P * B) := by ring
  have hbl : C_buildLive ops ≤ 263 * B := by
    unfold C_buildLive
    have hm : max ops.C_ins (ops.C_del + 180) ≤ 181 * B := by
      apply max_le <;> omega
    omega
  have hmax_bl : max 380 (C_buildLive ops) ≤ 380 * B := by
    apply max_le <;> omega
  have hjob : C_jobSlotUpdateStage1 ops ≤ 617 * (P * B) := by
    unfold C_jobSlotUpdateStage1
    have h500 : max 380 (C_buildLive ops) + 120 ≤ 500 * (P * B) := by
      calc max 380 (C_buildLive ops) + 120 ≤ 500 * B := by omega
        _ ≤ 500 * (P * B) := Nat.mul_le_mul_left 500 hPB
    calc C_liveList ops + max 380 (C_buildLive ops) + 120
        = C_liveList ops + (max 380 (C_buildLive ops) + 120) := by ring
      _ ≤ 117 * (P * B) + 500 * (P * B) := Nat.add_le_add hll h500
      _ = 617 * (P * B) := by ring
  have hbody : (C_jobSlotUpdateStage1 ops + (ops.C_ball + 50) + 18) + 6 ≤ 692 * (P * B) := by
    have h75 : (ops.C_ball + 50) + 18 + 6 ≤ 75 * (P * B) := by
      calc (ops.C_ball + 50) + 18 + 6 ≤ 75 * B := by omega
        _ ≤ 75 * (P * B) := Nat.mul_le_mul_left 75 hPB
    calc (C_jobSlotUpdateStage1 ops + (ops.C_ball + 50) + 18) + 6
        = C_jobSlotUpdateStage1 ops + ((ops.C_ball + 50) + 18 + 6) := by ring
      _ ≤ 617 * (P * B) + 75 * (P * B) := Nat.add_le_add hjob h75
      _ = 692 * (P * B) := by ring
  have hdloop : cp.D_max * ((C_jobSlotUpdateStage1 ops + (ops.C_ball + 50) + 18) + 6) ≤
      692 * (P ^ 2 * B) := by
    calc cp.D_max * ((C_jobSlotUpdateStage1 ops + (ops.C_ball + 50) + 18) + 6)
        ≤ P * (692 * (P * B)) := Nat.mul_le_mul hD hbody
      _ = 692 * (P ^ 2 * B) := by ring
  have hll_P2 : C_liveList ops ≤ 117 * (P ^ 2 * B) := by
    calc C_liveList ops ≤ 117 * (P * B) := hll
      _ ≤ 117 * (P ^ 2 * B) := Nat.mul_le_mul_left 117 (Nat.mul_le_mul_right B hP_P2)
  have hd_P2B : d ≤ P ^ 2 * B :=
    (hd_P.trans hP_P2).trans (Nat.le_mul_of_pos_right (P ^ 2) hB1)
  have h1_P2B : 1 ≤ P ^ 2 * B := h1_P2.trans (Nat.le_mul_of_pos_right (P ^ 2) hB1)
  unfold C_stage1
  omega

theorem C_stage1_le_master {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    {C_op k_op : ℕ} (hCop : 1 ≤ C_op)
    (ops : NodeAndHPJRAMOps inst.cp)
    (hins : ops.C_ins ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hdel : ops.C_del ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hbump : ops.C_bump ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hball : ops.C_ball ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hread : ops.C_read ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp) :
    C_stage1 ops ≤
      (1600 * C_op) * (masterPolyParamNat inst) ^ (k_op + 2) * masterWorkFactorNat inst.cp := by
  let P := masterPolyParamNat inst
  let W := masterWorkFactorNat inst.cp
  let B := C_op * P ^ k_op * W
  have hP1 : 1 ≤ P := by change 1 ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hW1 : 1 ≤ W := by change 1 ≤ masterWorkFactorNat inst.cp; unfold masterWorkFactorNat; omega
  have hPk1 : 1 ≤ P ^ k_op := Nat.one_le_pow k_op P hP1
  have hB1 : 1 ≤ B := Nat.mul_pos (Nat.mul_pos hCop hPk1) hW1
  have hD : inst.cp.D_max ≤ P := by
    change _ ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hd_P : d ≤ P := by
    change _ ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hc := c_stage1_arith ops P B hP1 hB1 hD hd_P hins hdel hbump hball hread
  calc C_stage1 ops ≤ 1600 * (P ^ 2 * B) := hc
    _ = (1600 * C_op) * P ^ (k_op + 2) * W := by
        dsimp only [B]
        rw [pow_add]
        ring

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
