import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_CP
import UL.Proof.clm_9_1_explicit_tradeoff.CG15_ParamsB0
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG15

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_clm_6_1_precision_RaceV30
open UL.Proof.clm_9_1_explicit_tradeoff.H1
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge

/-! ### 4. `n ^ Q_c(c, σ)` Work Factor Bounds & `n ^ (1 + σ)` Space Factor Bounds -/

noncomputable def P_cap_ub {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℝ :=
  poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat d (Llog_ub_nat csp d L)

theorem nonnegPoly2_P_cap_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NonnegPoly2 (P_cap_ub csp) :=
  nonnegPoly2_comp_L (f := poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat) (g := Llog_ub_nat csp)
    (nonnegPoly2_poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat) (natPoly2_Llog_ub csp)

def masterWorkFactorNat {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.cap_u + cp.cap_q + cp.R * cp.ℓ * cp.M₀ + cp.M₀ + cp.B_op + cp.B_STEP + 1

def masterSpaceFactorNat {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.n + cp.T_pow + 2 ^ cp.L_p2 + 2 ^ cp.L_p2 * cp.cap_u + cp.M₀ ^ cp.ℓ +
    masterWorkFactorNat cp

noncomputable def cap_tot_ub {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℝ :=
  (24 + 12 * (2 : ℝ) ^ (4 * csp.C_q)) * P_cap_ub csp d L + 1

noncomputable def Bop_ub {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℝ :=
  24 * (masterPoly_ub csp d L) ^ 4 * P_cap_ub csp d L

noncomputable def Bstep_ub {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℝ :=
  2 * masterPoly_ub csp d L * Bop_ub csp d L + 2 * (masterPoly_ub csp d L) ^ 2

noncomputable def workFactor_ub {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℝ :=
  cap_tot_ub csp d L + 12 * P_cap_ub csp d L + Bop_ub csp d L + Bstep_ub csp d L

noncomputable def spaceFactor_ub {c σ : ℝ} (csp : CurveStaticParams c σ) (d L : ℕ) : ℝ :=
  15 + 144 * P_cap_ub csp d L + 144 * (P_cap_ub csp d L) ^ csp.ℓ + workFactor_ub csp d L

theorem nonnegPoly2_cap_tot_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NonnegPoly2 (cap_tot_ub csp) :=
  nonnegPoly2_add
    (nonnegPoly2_mul (nonnegPoly2_const (by positivity)) (nonnegPoly2_P_cap_ub csp))
    (nonnegPoly2_const zero_le_one)

theorem nonnegPoly2_Bop_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NonnegPoly2 (Bop_ub csp) :=
  nonnegPoly2_mul
    (nonnegPoly2_mul (nonnegPoly2_const (by norm_num))
      (nonnegPoly2_pow (nonnegPoly2_masterPoly_ub csp) 4))
    (nonnegPoly2_P_cap_ub csp)

theorem nonnegPoly2_Bstep_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NonnegPoly2 (Bstep_ub csp) :=
  nonnegPoly2_add
    (nonnegPoly2_mul
      (nonnegPoly2_mul (nonnegPoly2_const (by norm_num)) (nonnegPoly2_masterPoly_ub csp))
      (nonnegPoly2_Bop_ub csp))
    (nonnegPoly2_mul (nonnegPoly2_const (by norm_num))
      (nonnegPoly2_pow (nonnegPoly2_masterPoly_ub csp) 2))

theorem nonnegPoly2_workFactor_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NonnegPoly2 (workFactor_ub csp) :=
  nonnegPoly2_add
    (nonnegPoly2_add
      (nonnegPoly2_add (nonnegPoly2_cap_tot_ub csp)
        (nonnegPoly2_mul (nonnegPoly2_const (by norm_num)) (nonnegPoly2_P_cap_ub csp)))
      (nonnegPoly2_Bop_ub csp))
    (nonnegPoly2_Bstep_ub csp)

theorem nonnegPoly2_spaceFactor_ub {c σ : ℝ} (csp : CurveStaticParams c σ) :
    NonnegPoly2 (spaceFactor_ub csp) :=
  nonnegPoly2_add
    (nonnegPoly2_add
      (nonnegPoly2_add (nonnegPoly2_const (by norm_num))
        (nonnegPoly2_mul (nonnegPoly2_const (by norm_num)) (nonnegPoly2_P_cap_ub csp)))
      (nonnegPoly2_mul (nonnegPoly2_const (by norm_num))
        (nonnegPoly2_pow (nonnegPoly2_P_cap_ub csp) csp.ℓ)))
    (nonnegPoly2_workFactor_ub csp)

private theorem m2_rpow_le_twelve_n_rpow {m2 n_r e Q : ℝ}
    (hm2_ge1 : 1 ≤ m2) (hm2_12n : m2 ≤ 12 * n_r) (hn_nn : 0 ≤ n_r)
    (he_Q : e ≤ Q) (hQ0 : 0 ≤ Q) (hQ1 : Q ≤ 1) :
    m2 ^ e ≤ 12 * n_r ^ Q := by
  have h1 : m2 ^ e ≤ m2 ^ Q := Real.rpow_le_rpow_of_exponent_le hm2_ge1 he_Q
  have h2 : m2 ^ Q ≤ (12 * n_r) ^ Q := Real.rpow_le_rpow (by linarith only [hm2_ge1]) hm2_12n hQ0
  rw [Real.mul_rpow (by norm_num) hn_nn] at h2
  have h12 : (12 : ℝ) ^ Q ≤ 12 := by
    calc (12 : ℝ) ^ Q ≤ (12 : ℝ) ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le (by norm_num) hQ1
      _ = 12 := Real.rpow_one 12
  exact (h1.trans h2).trans (mul_le_mul_of_nonneg_right h12 (Real.rpow_nonneg hn_nn Q))

theorem cap_and_workFactor_bounds {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (inst : ConcreteChainInst csp d n t δ) :
    ((inst.cp.R * inst.cp.ℓ * inst.cp.M₀ : ℕ) : ℝ) ≤
      (n : ℝ) ^ (Q_c c σ) * (12 * P_cap_ub csp d (logTerm_of n t δ)) ∧
    ((inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀ + 1 : ℕ) : ℝ) ≤
      (n : ℝ) ^ (Q_c c σ) * cap_tot_ub csp d (logTerm_of n t δ) ∧
    (inst.cp.B_STEP : ℝ) ≤ (n : ℝ) ^ (Q_c c σ) * Bstep_ub csp d (logTerm_of n t δ) ∧
    (masterWorkFactorNat inst.cp : ℝ) ≤ (n : ℝ) ^ (Q_c c σ) * workFactor_ub csp d (logTerm_of n t δ) := by
  obtain ⟨L, hL_def⟩ : ∃ x, x = logTerm_of n t δ := ⟨_, rfl⟩
  obtain ⟨Q, hQ_def⟩ : ∃ q, q = Q_c c σ := ⟨_, rfl⟩
  rw [← hL_def, ← hQ_def]
  have hQb := Q_c_bounds_of_curve csp; rw [← hQ_def] at hQb
  obtain ⟨hrho0, hrho_Q, hQ1, _, _⟩ := hQb
  have hQ0 : 0 ≤ Q := hrho0.le.trans hrho_Q
  have hLMP := L_log_and_masterPoly_le_ub hn ht hδ0 hδ1 inst; rw [← hL_def] at hLMP
  obtain ⟨hLlog_le, hMP_nat⟩ := hLMP
  obtain ⟨_, hLp2_12n, hLp2_pow4⟩ := T_pow_and_Lp2_pow_bounds hn inst
  have hMP_r : (masterPolyParamNat inst : ℝ) ≤ masterPoly_ub csp d L := by
    unfold masterPoly_ub; exact Nat.cast_le.mpr hMP_nat
  have hP_mono : poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log ≤ P_cap_ub csp d L :=
    poly_cap_fn_mono_L csp.ℓ csp.C_net_nat csp.C_M_nat d hLlog_le
  have hP_nn : 0 ≤ P_cap_ub csp d L := (nonnegPoly2_P_cap_ub csp).1 d L
  have hm2_ge1 : (1 : ℝ) ≤ ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) := by
    exact_mod_cast (@Nat.one_le_two_pow inst.cp.L_p2)
  have hm2_12n : ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ≤ 12 * (n : ℝ) := by exact_mod_cast hLp2_12n
  have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
  have hn_nn : (0 : ℝ) ≤ (n : ℝ) := by positivity
  have hrpow_Q_ge1 : (1 : ℝ) ≤ (n : ℝ) ^ Q := Real.one_le_rpow hn1 hQ0

  have hI_le_Q : I_h (inst.h_rat : ℝ) (inst.x_rat : ℝ) / (csp.ℓ : ℝ) ≤ Q := by
    obtain ⟨heq, hrho8, _⟩ :=
      base_exp_le_rho_div_8 csp.hc_gt csp.hc_lt csp.hℓ_bound inst.hh0 inst.hh1 inst.hhx inst.hx1
    rw [heq]; linarith only [hrho8, hrho0, hrho_Q]
  have hRlM : ((inst.cp.R * inst.cp.ℓ * inst.cp.M₀ : ℕ) : ℝ) ≤
      (n : ℝ) ^ Q * (12 * P_cap_ub csp d L) := by
    have hm_exp := m2_rpow_le_twelve_n_rpow hm2_ge1 hm2_12n hn_nn hI_le_Q hQ0 hQ1
    calc ((inst.cp.R * inst.cp.ℓ * inst.cp.M₀ : ℕ) : ℝ)
        ≤ ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (I_h (inst.h_rat : ℝ) (inst.x_rat : ℝ) / (csp.ℓ : ℝ)) *
            poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log := inst.hRlM_bound
      _ ≤ (12 * (n : ℝ) ^ Q) * P_cap_ub csp d L :=
          mul_le_mul hm_exp hP_mono
            ((nonnegPoly2_poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat).1 d inst.L_log)
            (by positivity)
      _ = (n : ℝ) ^ Q * (12 * P_cap_ub csp d L) := by ring

  have hu_le_Q : u_search (inst.h_rat : ℝ) (inst.x_rat : ℝ) ≤ Q :=
    inst.hu_le.trans (csp.hσ_hi.trans hrho_Q)
  have hcap_u : (inst.cp.cap_u : ℝ) ≤ (n : ℝ) ^ Q * (12 * P_cap_ub csp d L) := by
    have hm_exp := m2_rpow_le_twelve_n_rpow hm2_ge1 hm2_12n hn_nn hu_le_Q hQ0 hQ1
    calc (inst.cp.cap_u : ℝ)
        ≤ ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (u_search (inst.h_rat : ℝ) (inst.x_rat : ℝ)) *
            poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log := inst.hcap_u_bound
      _ ≤ (12 * (n : ℝ) ^ Q) * P_cap_ub csp d L :=
          mul_le_mul hm_exp hP_mono
            ((nonnegPoly2_poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat).1 d inst.L_log)
            (by positivity)
      _ = (n : ℝ) ^ Q * (12 * P_cap_ub csp d L) := by ring

  have hcap_q : (inst.cp.cap_q : ℝ) ≤
      (n : ℝ) ^ Q * (12 * (2 : ℝ) ^ (4 * csp.C_q) * P_cap_ub csp d L) := by
    have hLn_pos_r : (0 : ℝ) < (L_n n : ℝ) := by exact_mod_cast (one_le_L_n hn)
    have hCq_div_nn : 0 ≤ csp.C_q / (L_n n : ℝ) := div_nonneg csp.hCq0 hLn_pos_r.le
    have hm_q1 : ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (q_search (inst.h_rat : ℝ) (inst.x_rat : ℝ)) ≤
        ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (Q + csp.C_q / (L_n n : ℝ)) :=
      Real.rpow_le_rpow_of_exponent_le hm2_ge1 (hQ_def ▸ inst.hq_le)
    rw [Real.rpow_add (by positivity)] at hm_q1
    have hm_Q := m2_rpow_le_twelve_n_rpow hm2_ge1 hm2_12n hn_nn le_rfl hQ0 hQ1
    have hm_pow4 : ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ≤ (2 : ℝ) ^ (4 * L_n n) := by
      exact_mod_cast hLp2_pow4
    have hm_sl : ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (csp.C_q / (L_n n : ℝ)) ≤ (2 : ℝ) ^ (4 * csp.C_q) := by
      calc ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (csp.C_q / (L_n n : ℝ))
          ≤ ((2 : ℝ) ^ (4 * L_n n)) ^ (csp.C_q / (L_n n : ℝ)) :=
            Real.rpow_le_rpow (by positivity) hm_pow4 hCq_div_nn
        _ = (2 : ℝ) ^ (((4 * L_n n : ℕ) : ℝ) * (csp.C_q / (L_n n : ℝ))) := by
            rw [← Real.rpow_natCast (2 : ℝ), ← Real.rpow_mul (by norm_num)]
        _ = (2 : ℝ) ^ (4 * csp.C_q) := by
            congr 1; have hne := hLn_pos_r.ne'; push_cast; field_simp [hne]
    have hm_q_ub := hm_q1.trans (mul_le_mul hm_Q hm_sl (by positivity) (by positivity))
    calc (inst.cp.cap_q : ℝ)
        ≤ ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (q_search (inst.h_rat : ℝ) (inst.x_rat : ℝ)) *
            poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log := inst.hcap_q_bound
      _ ≤ ((12 * (n : ℝ) ^ Q) * (2 : ℝ) ^ (4 * csp.C_q)) * P_cap_ub csp d L :=
          mul_le_mul hm_q_ub hP_mono
            ((nonnegPoly2_poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat).1 d inst.L_log)
            (by positivity)
      _ = (n : ℝ) ^ Q * (12 * (2 : ℝ) ^ (4 * csp.C_q) * P_cap_ub csp d L) := by ring

  have hcap_tot : ((inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀ + 1 : ℕ) : ℝ) ≤
      (n : ℝ) ^ Q * cap_tot_ub csp d L := by
    have hlhs : ((inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀ + 1 : ℕ) : ℝ) =
        (inst.cp.cap_u : ℝ) + (inst.cp.cap_q : ℝ) +
          ((inst.cp.R * inst.cp.ℓ * inst.cp.M₀ : ℕ) : ℝ) + 1 := by
      simp only [Nat.cast_add, Nat.cast_one]
    rw [hlhs]; unfold cap_tot_ub
    have hrhs : (n : ℝ) ^ Q * ((24 + 12 * (2 : ℝ) ^ (4 * csp.C_q)) * P_cap_ub csp d L + 1) =
        (n : ℝ) ^ Q * (12 * P_cap_ub csp d L) +
        (n : ℝ) ^ Q * (12 * (2 : ℝ) ^ (4 * csp.C_q) * P_cap_ub csp d L) +
        (n : ℝ) ^ Q * (12 * P_cap_ub csp d L) + (n : ℝ) ^ Q := by ring
    linarith only [hcap_u, hcap_q, hRlM, hrpow_Q_ge1, hrhs]

  have hM0 : (inst.cp.M₀ : ℝ) ≤ (n : ℝ) ^ Q * (12 * P_cap_ub csp d L) := by
    have h1 : 1 ≤ inst.cp.R * inst.cp.ℓ := Nat.mul_pos inst.hR_pos (inst.hℓ_eq ▸ csp.hℓ_ge1)
    have hle : inst.cp.M₀ ≤ inst.cp.R * inst.cp.ℓ * inst.cp.M₀ := by
      calc inst.cp.M₀ = 1 * inst.cp.M₀ := (one_mul _).symm
        _ ≤ (inst.cp.R * inst.cp.ℓ) * inst.cp.M₀ := Nat.mul_le_mul_right _ h1
    exact (Nat.cast_le.mpr hle).trans hRlM

  have hBop : (inst.cp.B_op : ℝ) ≤ (n : ℝ) ^ Q * Bop_ub csp d L := by
    obtain ⟨P4, hP4⟩ : ∃ x, x = 2 * inst.cp.N_cfg * inst.cp.L_p2 * (d + 1) * inst.cp.b := ⟨_, rfl⟩
    have hf1 : inst.cp.N_cfg ≤ masterPolyParamNat inst := by unfold masterPolyParamNat; omega
    have hf2 : inst.cp.L_p2 ≤ masterPolyParamNat inst := by unfold masterPolyParamNat; omega
    have hf3 : d + 1 ≤ masterPolyParamNat inst := by unfold masterPolyParamNat; omega
    have hf4 : inst.cp.b ≤ masterPolyParamNat inst := by unfold masterPolyParamNat; omega
    have hpoly_nat : P4 ≤ 2 * (masterPolyParamNat inst) ^ 4 := by
      rw [hP4]
      have hm1234 := Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul hf1 hf2) hf3) hf4
      have hpow4 : (masterPolyParamNat inst) ^ 4 =
          masterPolyParamNat inst * masterPolyParamNat inst *
            masterPolyParamNat inst * masterPolyParamNat inst := by ring
      have hmul2 := Nat.mul_le_mul_left 2 hm1234
      linarith only [hmul2, hpow4]
    have hpoly_r : (P4 : ℝ) ≤ 2 * (masterPoly_ub csp d L) ^ 4 := by
      have h1 : (P4 : ℝ) ≤ ((2 * (masterPolyParamNat inst) ^ 4 : ℕ) : ℝ) := Nat.cast_le.mpr hpoly_nat
      have h2 : ((2 * (masterPolyParamNat inst) ^ 4 : ℕ) : ℝ) =
          2 * (masterPolyParamNat inst : ℝ) ^ 4 := by
        rw [Nat.cast_mul, Nat.cast_pow]; norm_num
      rw [h2] at h1
      exact h1.trans (mul_le_mul_of_nonneg_left
        (pow_le_pow_left₀ (Nat.cast_nonneg _) hMP_r 4) (by norm_num))
    have hBop_eq : inst.cp.B_op = P4 * (inst.cp.R * inst.cp.ℓ * inst.cp.M₀) := by
      rw [hP4]
      change inst.cp.N_cfg * 2 * inst.cp.L_p2 * inst.cp.R * inst.cp.ℓ * inst.cp.M₀ * (d + 1) * inst.cp.b = _
      ring
    rw [hBop_eq, Nat.cast_mul]; unfold Bop_ub
    calc (P4 : ℝ) * ((inst.cp.R * inst.cp.ℓ * inst.cp.M₀ : ℕ) : ℝ)
        ≤ (2 * (masterPoly_ub csp d L) ^ 4) * ((n : ℝ) ^ Q * (12 * P_cap_ub csp d L)) :=
          mul_le_mul hpoly_r hRlM (Nat.cast_nonneg _)
            (mul_nonneg (by norm_num) (pow_nonneg ((nonnegPoly2_masterPoly_ub csp).1 d L) 4))
      _ = (n : ℝ) ^ Q * (24 * (masterPoly_ub csp d L) ^ 4 * P_cap_ub csp d L) := by ring

  have hBstep : (inst.cp.B_STEP : ℝ) ≤ (n : ℝ) ^ Q * Bstep_ub csp d L := by
    obtain ⟨Tcb, hTcb⟩ : ∃ x, x = (inst.cp.D_max + 1) * inst.cp.B_ctr + inst.cp.D_max * inst.cp.B_base := ⟨_, rfl⟩
    have hBstep_eq : inst.cp.B_STEP = (inst.cp.N_op_s1 + inst.cp.N_op_s2) * inst.cp.B_op + Tcb := by
      rw [hTcb]
      change inst.cp.N_op_s1 * inst.cp.B_op +
        (inst.cp.N_op_s2 * inst.cp.B_op + (inst.cp.D_max + 1) * inst.cp.B_ctr) +
        inst.cp.D_max * inst.cp.B_base = _
      ring
    have hs12_nat : inst.cp.N_op_s1 + inst.cp.N_op_s2 ≤ 2 * masterPolyParamNat inst := by
      unfold masterPolyParamNat; omega
    have hs12_r : ((inst.cp.N_op_s1 + inst.cp.N_op_s2 : ℕ) : ℝ) ≤ 2 * masterPoly_ub csp d L := by
      have h1 : ((inst.cp.N_op_s1 + inst.cp.N_op_s2 : ℕ) : ℝ) ≤
          ((2 * masterPolyParamNat inst : ℕ) : ℝ) := Nat.cast_le.mpr hs12_nat
      have h2 : ((2 * masterPolyParamNat inst : ℕ) : ℝ) = 2 * (masterPolyParamNat inst : ℝ) := by
        rw [Nat.cast_mul]; norm_num
      rw [h2] at h1; linarith only [h1, hMP_r]
    have hd1_nat : inst.cp.D_max + 1 ≤ masterPolyParamNat inst := by unfold masterPolyParamNat; omega
    have hctr_nat : inst.cp.B_ctr ≤ masterPolyParamNat inst := by unfold masterPolyParamNat; omega
    have hd_nat : inst.cp.D_max ≤ masterPolyParamNat inst := by unfold masterPolyParamNat; omega
    have hbase_nat : inst.cp.B_base ≤ masterPolyParamNat inst := by unfold masterPolyParamNat; omega
    have htail_nat : Tcb ≤ 2 * (masterPolyParamNat inst) ^ 2 := by
      rw [hTcb]
      have hm1 := Nat.mul_le_mul hd1_nat hctr_nat
      have hm2 := Nat.mul_le_mul hd_nat hbase_nat
      have hsq : (masterPolyParamNat inst) ^ 2 = masterPolyParamNat inst * masterPolyParamNat inst := sq _
      omega
    have htail_r : (Tcb : ℝ) ≤ (n : ℝ) ^ Q * (2 * (masterPoly_ub csp d L) ^ 2) := by
      have h1 : (Tcb : ℝ) ≤ 2 * (masterPoly_ub csp d L) ^ 2 := by
        have h0 : (Tcb : ℝ) ≤ ((2 * (masterPolyParamNat inst) ^ 2 : ℕ) : ℝ) := Nat.cast_le.mpr htail_nat
        have h2 : ((2 * (masterPolyParamNat inst) ^ 2 : ℕ) : ℝ) =
            2 * (masterPolyParamNat inst : ℝ) ^ 2 := by
          rw [Nat.cast_mul, Nat.cast_pow]; norm_num
        rw [h2] at h0
        exact h0.trans (mul_le_mul_of_nonneg_left
          (pow_le_pow_left₀ (Nat.cast_nonneg _) hMP_r 2) (by norm_num))
      calc (Tcb : ℝ) ≤ 1 * (2 * (masterPoly_ub csp d L) ^ 2) := by linarith only [h1]
        _ ≤ (n : ℝ) ^ Q * (2 * (masterPoly_ub csp d L) ^ 2) :=
            mul_le_mul_of_nonneg_right hrpow_Q_ge1
              (mul_nonneg (by norm_num) (pow_nonneg ((nonnegPoly2_masterPoly_ub csp).1 d L) 2))
    have hhead_r : (((inst.cp.N_op_s1 + inst.cp.N_op_s2) * inst.cp.B_op : ℕ) : ℝ) ≤
        (n : ℝ) ^ Q * (2 * masterPoly_ub csp d L * Bop_ub csp d L) := by
      rw [Nat.cast_mul]
      calc ((inst.cp.N_op_s1 + inst.cp.N_op_s2 : ℕ) : ℝ) * (inst.cp.B_op : ℝ)
          ≤ (2 * masterPoly_ub csp d L) * ((n : ℝ) ^ Q * Bop_ub csp d L) :=
            mul_le_mul hs12_r hBop (Nat.cast_nonneg _)
              (mul_nonneg (by norm_num) ((nonnegPoly2_masterPoly_ub csp).1 d L))
        _ = (n : ℝ) ^ Q * (2 * masterPoly_ub csp d L * Bop_ub csp d L) := by ring
    rw [hBstep_eq, Nat.cast_add]; unfold Bstep_ub
    have hrhs : (n : ℝ) ^ Q * (2 * masterPoly_ub csp d L * Bop_ub csp d L + 2 * (masterPoly_ub csp d L) ^ 2) =
        (n : ℝ) ^ Q * (2 * masterPoly_ub csp d L * Bop_ub csp d L) +
        (n : ℝ) ^ Q * (2 * (masterPoly_ub csp d L) ^ 2) := by ring
    linarith only [hhead_r, htail_r, hrhs]

  have hWF : (masterWorkFactorNat inst.cp : ℝ) ≤ (n : ℝ) ^ Q * workFactor_ub csp d L := by
    have hwf_nat : masterWorkFactorNat inst.cp =
        (inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀ + 1) +
          inst.cp.M₀ + inst.cp.B_op + inst.cp.B_STEP := by
      unfold masterWorkFactorNat; ring
    have hwf_eq : (masterWorkFactorNat inst.cp : ℝ) =
        ((inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀ + 1 : ℕ) : ℝ) +
        (inst.cp.M₀ : ℝ) + (inst.cp.B_op : ℝ) + (inst.cp.B_STEP : ℝ) := by
      rw [hwf_nat, Nat.cast_add, Nat.cast_add, Nat.cast_add]
    rw [hwf_eq]; unfold workFactor_ub
    have hrhs : (n : ℝ) ^ Q *
        (cap_tot_ub csp d L + 12 * P_cap_ub csp d L + Bop_ub csp d L + Bstep_ub csp d L) =
        (n : ℝ) ^ Q * cap_tot_ub csp d L + (n : ℝ) ^ Q * (12 * P_cap_ub csp d L) +
        (n : ℝ) ^ Q * Bop_ub csp d L + (n : ℝ) ^ Q * Bstep_ub csp d L := by ring
    linarith only [hcap_tot, hM0, hBop, hBstep, hrhs]

  exact ⟨hRlM, hcap_tot, hBstep, hWF⟩

theorem spaceFactor_bound {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (inst : ConcreteChainInst csp d n t δ) :
    (masterSpaceFactorNat inst.cp : ℝ) ≤
      (n : ℝ) ^ (1 + σ) * spaceFactor_ub csp d (logTerm_of n t δ) := by
  obtain ⟨L, hL_def⟩ : ∃ x, x = logTerm_of n t δ := ⟨_, rfl⟩
  obtain ⟨Q, hQ_def⟩ : ∃ q, q = Q_c c σ := ⟨_, rfl⟩
  rw [← hL_def]
  have hQb := Q_c_bounds_of_curve csp; rw [← hQ_def] at hQb
  obtain ⟨hrho0, hrho_Q, hQ1, h1_sig, hsig_2⟩ := hQb
  have hLMP := L_log_and_masterPoly_le_ub hn ht hδ0 hδ1 inst; rw [← hL_def] at hLMP
  obtain ⟨hLlog_le, _⟩ := hLMP
  obtain ⟨hT_pow_2n, hLp2_12n, _⟩ := T_pow_and_Lp2_pow_bounds hn inst
  have hcw := cap_and_workFactor_bounds hn ht hδ0 hδ1 inst; rw [← hL_def, ← hQ_def] at hcw
  obtain ⟨_, _, _, hWF_Q⟩ := hcw
  have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
  have hn_pos : (0 : ℝ) < (n : ℝ) := by linarith only [hn1]
  have hn_le_sig : (n : ℝ) ≤ (n : ℝ) ^ (1 + σ) := by
    calc (n : ℝ) = (n : ℝ) ^ (1 : ℝ) := (Real.rpow_one (n : ℝ)).symm
      _ ≤ (n : ℝ) ^ (1 + σ) := Real.rpow_le_rpow_of_exponent_le hn1 h1_sig
  have hQ_le_sig : (n : ℝ) ^ Q ≤ (n : ℝ) ^ (1 + σ) :=
    Real.rpow_le_rpow_of_exponent_le hn1 (hQ1.trans h1_sig)
  have h15_bound : ((inst.cp.n + inst.cp.T_pow + 2 ^ inst.cp.L_p2 : ℕ) : ℝ) ≤
      (n : ℝ) ^ (1 + σ) * 15 := by
    have hnat : inst.cp.n + inst.cp.T_pow + 2 ^ inst.cp.L_p2 ≤ 15 * n := by
      have := inst.hn_eq; omega
    have hr : ((inst.cp.n + inst.cp.T_pow + 2 ^ inst.cp.L_p2 : ℕ) : ℝ) ≤ 15 * (n : ℝ) := by
      exact_mod_cast hnat
    linarith only [hr, hn_le_sig]

  have hP_mono : poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat d inst.L_log ≤ P_cap_ub csp d L :=
    poly_cap_fn_mono_L csp.ℓ csp.C_net_nat csp.C_M_nat d hLlog_le
  have hP_nn : 0 ≤ P_cap_ub csp d L := (nonnegPoly2_P_cap_ub csp).1 d L
  have hm2_ge1 : (1 : ℝ) ≤ ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) := by
    exact_mod_cast (@Nat.one_le_two_pow inst.cp.L_p2)
  have hm2_12n : ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ≤ 12 * (n : ℝ) := by exact_mod_cast hLp2_12n

  have hLp2_capu : ((2 ^ inst.cp.L_p2 * inst.cp.cap_u : ℕ) : ℝ) ≤
      (n : ℝ) ^ (1 + σ) * (144 * P_cap_ub csp d L) := by
    have hsig_le1 : σ ≤ 1 := csp.hσ_hi.trans (hrho_Q.trans hQ1)
    have hm_u : ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (u_search (inst.h_rat : ℝ) (inst.x_rat : ℝ)) ≤
        12 * (n : ℝ) ^ σ :=
      m2_rpow_le_twelve_n_rpow hm2_ge1 hm2_12n hn_pos.le inst.hu_le csp.hσ0 hsig_le1
    have hcu : (inst.cp.cap_u : ℝ) ≤ (12 * (n : ℝ) ^ σ) * P_cap_ub csp d L :=
      inst.hcap_u_bound.trans (mul_le_mul hm_u hP_mono
        ((nonnegPoly2_poly_cap_fn csp.ℓ csp.C_net_nat csp.C_M_nat).1 d inst.L_log)
        (by positivity))
    have hn_mul_sig : (n : ℝ) * (n : ℝ) ^ σ = (n : ℝ) ^ (1 + σ) := by
      rw [Real.rpow_add hn_pos 1 σ, Real.rpow_one]
    rw [Nat.cast_mul]
    calc ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) * (inst.cp.cap_u : ℝ)
        ≤ (12 * (n : ℝ)) * ((12 * (n : ℝ) ^ σ) * P_cap_ub csp d L) :=
          mul_le_mul hm2_12n hcu (Nat.cast_nonneg _) (by positivity)
      _ = ((n : ℝ) * (n : ℝ) ^ σ) * (144 * P_cap_ub csp d L) := by ring
      _ = (n : ℝ) ^ (1 + σ) * (144 * P_cap_ub csp d L) := by rw [hn_mul_sig]

  have hM0_ell : ((inst.cp.M₀ ^ inst.cp.ℓ : ℕ) : ℝ) ≤
      (n : ℝ) ^ (1 + σ) * (144 * (P_cap_ub csp d L) ^ csp.ℓ) := by
    rw [inst.hℓ_eq]
    have hRlM_ub : ((inst.cp.R * csp.ℓ * inst.cp.M₀ : ℕ) : ℝ) ≤
        ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (I_h (inst.h_rat : ℝ) (inst.x_rat : ℝ) / (csp.ℓ : ℝ)) *
          P_cap_ub csp d L := by
      have h0 := inst.hRlM_bound
      rw [inst.hℓ_eq] at h0
      exact h0.trans (mul_le_mul_of_nonneg_left hP_mono (by positivity))
    have hsp1 := M0_pow_ell_le_space (m := 2 ^ inst.cp.L_p2) csp.hℓ_ge1
      (@Nat.one_le_two_pow inst.cp.L_p2)
      (fun _ _ => trivial) inst.hR_pos inst.hh0 inst.hh1 inst.hhx inst.hx1 inst.hu_le hP_nn hRlM_ub
    have hm_1sig : ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (1 + σ) ≤ 144 * (n : ℝ) ^ (1 + σ) := by
      have h1 : ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (1 + σ) ≤ (12 * (n : ℝ)) ^ (1 + σ) :=
        Real.rpow_le_rpow (by positivity) hm2_12n (by linarith only [h1_sig])
      rw [Real.mul_rpow (by norm_num) hn_pos.le] at h1
      have h12_2 : (12 : ℝ) ^ (1 + σ) ≤ 144 := by
        calc (12 : ℝ) ^ (1 + σ) ≤ (12 : ℝ) ^ (2 : ℝ) :=
              Real.rpow_le_rpow_of_exponent_le (by norm_num) hsig_2
          _ = 144 := by norm_num
      exact h1.trans (mul_le_mul_of_nonneg_right h12_2 (by positivity))
    calc ((inst.cp.M₀ ^ csp.ℓ : ℕ) : ℝ)
        ≤ ((2 ^ inst.cp.L_p2 : ℕ) : ℝ) ^ (1 + σ) * (P_cap_ub csp d L) ^ csp.ℓ := hsp1
      _ ≤ (144 * (n : ℝ) ^ (1 + σ)) * (P_cap_ub csp d L) ^ csp.ℓ :=
          mul_le_mul_of_nonneg_right hm_1sig (pow_nonneg hP_nn csp.ℓ)
      _ = (n : ℝ) ^ (1 + σ) * (144 * (P_cap_ub csp d L) ^ csp.ℓ) := by ring

  have hWF_sig : (masterWorkFactorNat inst.cp : ℝ) ≤ (n : ℝ) ^ (1 + σ) * workFactor_ub csp d L :=
    hWF_Q.trans (mul_le_mul_of_nonneg_right hQ_le_sig ((nonnegPoly2_workFactor_ub csp).1 d L))

  have hsf_eq : (masterSpaceFactorNat inst.cp : ℝ) =
      ((inst.cp.n + inst.cp.T_pow + 2 ^ inst.cp.L_p2 : ℕ) : ℝ) +
      ((2 ^ inst.cp.L_p2 * inst.cp.cap_u : ℕ) : ℝ) +
      ((inst.cp.M₀ ^ inst.cp.ℓ : ℕ) : ℝ) +
      (masterWorkFactorNat inst.cp : ℝ) := by
    unfold masterSpaceFactorNat
    rw [Nat.cast_add, Nat.cast_add, Nat.cast_add]
  rw [hsf_eq]; unfold spaceFactor_ub
  have hrhs : (n : ℝ) ^ (1 + σ) *
      (15 + 144 * P_cap_ub csp d L + 144 * (P_cap_ub csp d L) ^ csp.ℓ + workFactor_ub csp d L) =
      (n : ℝ) ^ (1 + σ) * 15 + (n : ℝ) ^ (1 + σ) * (144 * P_cap_ub csp d L) +
      (n : ℝ) ^ (1 + σ) * (144 * (P_cap_ub csp d L) ^ csp.ℓ) +
      (n : ℝ) ^ (1 + σ) * workFactor_ub csp d L := by ring
  linarith only [h15_bound, hLp2_capu, hM0_ell, hWF_sig, hrhs]

/-! ### 5. Explicit & Master Polynomial Bounds + `CG14_CP` & `CG20_Bridge` Wiring -/

noncomputable def polyTime_explicit {c σ : ℝ} (csp : CurveStaticParams c σ)
    (C₀ k : ℕ) (d L : ℕ) : ℝ :=
  (C₀ : ℝ) * (masterPoly_ub csp d L) ^ (3 * k) * cap_tot_ub csp d L

theorem polyTime_explicit_isBoundedByPoly2 {c σ : ℝ} (csp : CurveStaticParams c σ) (C₀ k : ℕ) :
    IsBoundedByPoly2 (polyTime_explicit csp C₀ k) :=
  (nonnegPoly2_mul
    (nonnegPoly2_mul (nonnegPoly2_const (Nat.cast_nonneg C₀))
      (nonnegPoly2_pow (nonnegPoly2_masterPoly_ub csp) (3 * k)))
    (nonnegPoly2_cap_tot_ub csp)).2

theorem polyTime_explicit_bound {c σ : ℝ} {csp : CurveStaticParams c σ}
    (C₀ k : ℕ) {d n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (inst : ConcreteChainInst csp d n t δ) :
    ((C₀ * (inst.cp.D_max + inst.cp.B_scan + 1) ^ k * (inst.cp.N_cfg + 1) ^ k *
      (inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀ + 1) *
      (d + inst.cp.L_p2 + inst.cp.b + L_n n + 1) ^ k : ℕ) : ℝ) ≤
      ((n : ℝ) ^ (Q_c c σ)) * polyTime_explicit csp C₀ k d (logTerm_of n t δ) := by
  obtain ⟨L, hL_def⟩ : ∃ x, x = logTerm_of n t δ := ⟨_, rfl⟩
  obtain ⟨P3, hP3⟩ : ∃ x, x = (inst.cp.D_max + inst.cp.B_scan + 1) ^ k * (inst.cp.N_cfg + 1) ^ k *
      (d + inst.cp.L_p2 + inst.cp.b + L_n n + 1) ^ k := ⟨_, rfl⟩
  obtain ⟨Ctot, hCtot⟩ : ∃ x, x = inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀ + 1 := ⟨_, rfl⟩
  rw [← hL_def, ← hCtot]
  have hLMP := L_log_and_masterPoly_le_ub hn ht hδ0 hδ1 inst; rw [← hL_def] at hLMP
  obtain ⟨_, hMP_nat⟩ := hLMP
  have hcw := cap_and_workFactor_bounds hn ht hδ0 hδ1 inst; rw [← hL_def, ← hCtot] at hcw
  obtain ⟨_, hcap_tot, _, _⟩ := hcw
  obtain ⟨M, hM_def⟩ : ∃ m, m = masterPolyParamNat inst := ⟨_, rfl⟩
  rw [← hM_def] at hMP_nat
  have ha : inst.cp.D_max + inst.cp.B_scan + 1 ≤ M := by rw [hM_def]; unfold masterPolyParamNat; omega
  have hb : inst.cp.N_cfg + 1 ≤ M := by rw [hM_def]; unfold masterPolyParamNat; omega
  have hc : d + inst.cp.L_p2 + inst.cp.b + L_n n + 1 ≤ M := by rw [hM_def]; unfold masterPolyParamNat; omega
  have hprod_nat : P3 ≤ M ^ (3 * k) := by
    rw [hP3]
    calc (inst.cp.D_max + inst.cp.B_scan + 1) ^ k * (inst.cp.N_cfg + 1) ^ k *
          (d + inst.cp.L_p2 + inst.cp.b + L_n n + 1) ^ k
        ≤ M ^ k * M ^ k * M ^ k :=
          Nat.mul_le_mul
            (Nat.mul_le_mul (Nat.pow_le_pow_left ha k) (Nat.pow_le_pow_left hb k))
            (Nat.pow_le_pow_left hc k)
      _ = M ^ (3 * k) := by rw [← pow_add, ← pow_add]; congr 1; omega
  have hMP_r : (M : ℝ) ≤ masterPoly_ub csp d L := by
    unfold masterPoly_ub; exact Nat.cast_le.mpr hMP_nat
  have hpoly_r : (P3 : ℝ) ≤ (masterPoly_ub csp d L) ^ (3 * k) := by
    have h1 : (P3 : ℝ) ≤ ((M ^ (3 * k) : ℕ) : ℝ) := Nat.cast_le.mpr hprod_nat
    rw [Nat.cast_pow] at h1
    exact h1.trans (pow_le_pow_left₀ (Nat.cast_nonneg M) hMP_r (3 * k))
  have hlhs_nat :
      C₀ * (inst.cp.D_max + inst.cp.B_scan + 1) ^ k * (inst.cp.N_cfg + 1) ^ k * Ctot *
        (d + inst.cp.L_p2 + inst.cp.b + L_n n + 1) ^ k = C₀ * P3 * Ctot := by
    rw [hP3]; ring
  rw [hlhs_nat, Nat.cast_mul, Nat.cast_mul]; unfold polyTime_explicit
  have hmp_nn : 0 ≤ (masterPoly_ub csp d L) ^ (3 * k) :=
    pow_nonneg ((nonnegPoly2_masterPoly_ub csp).1 d L) (3 * k)
  calc (C₀ : ℝ) * (P3 : ℝ) * (Ctot : ℝ)
      ≤ (C₀ : ℝ) * ((masterPoly_ub csp d L) ^ (3 * k) * ((n : ℝ) ^ (Q_c c σ) * cap_tot_ub csp d L)) := by
        rw [mul_assoc]
        exact mul_le_mul_of_nonneg_left
          (mul_le_mul hpoly_r hcap_tot (Nat.cast_nonneg _) hmp_nn) (Nat.cast_nonneg C₀)
    _ = ((n : ℝ) ^ (Q_c c σ)) * ((C₀ : ℝ) * (masterPoly_ub csp d L) ^ (3 * k) * cap_tot_ub csp d L) := by ring

noncomputable def polyTime_master {c σ : ℝ} (csp : CurveStaticParams c σ)
    (C₀ k : ℕ) (d L : ℕ) : ℝ :=
  5 + 10 * Bstep_ub csp d L + (C₀ : ℝ) * (masterPoly_ub csp d L) ^ k * workFactor_ub csp d L

theorem polyTime_master_isBoundedByPoly2 {c σ : ℝ} (csp : CurveStaticParams c σ) (C₀ k : ℕ) :
    IsBoundedByPoly2 (polyTime_master csp C₀ k) :=
  (nonnegPoly2_add
    (nonnegPoly2_add (nonnegPoly2_const (by norm_num))
      (nonnegPoly2_mul (nonnegPoly2_const (by norm_num)) (nonnegPoly2_Bstep_ub csp)))
    (nonnegPoly2_mul
      (nonnegPoly2_mul (nonnegPoly2_const (Nat.cast_nonneg C₀))
        (nonnegPoly2_pow (nonnegPoly2_masterPoly_ub csp) k))
      (nonnegPoly2_workFactor_ub csp))).2

theorem polyTime_master_bound {c σ : ℝ} {csp : CurveStaticParams c σ}
    (C₀ k : ℕ) {d n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (inst : ConcreteChainInst csp d n t δ) :
    ((5 + 10 * inst.cp.B_STEP + C₀ * (masterPolyParamNat inst) ^ k * masterWorkFactorNat inst.cp : ℕ) : ℝ) ≤
      ((n : ℝ) ^ (Q_c c σ)) * polyTime_master csp C₀ k d (logTerm_of n t δ) := by
  obtain ⟨L, hL_def⟩ : ∃ x, x = logTerm_of n t δ := ⟨_, rfl⟩
  obtain ⟨Q, hQ_def⟩ : ∃ q, q = Q_c c σ := ⟨_, rfl⟩
  rw [← hL_def, ← hQ_def]
  have hQb := Q_c_bounds_of_curve csp; rw [← hQ_def] at hQb
  obtain ⟨hrho0, hrho_Q, _, _, _⟩ := hQb
  have hLMP := L_log_and_masterPoly_le_ub hn ht hδ0 hδ1 inst; rw [← hL_def] at hLMP
  obtain ⟨_, hMP_nat⟩ := hLMP
  have hcw := cap_and_workFactor_bounds hn ht hδ0 hδ1 inst; rw [← hL_def, ← hQ_def] at hcw
  obtain ⟨_, _, hBstep, hWF⟩ := hcw
  have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
  have hrpow_ge1 : (1 : ℝ) ≤ (n : ℝ) ^ Q := Real.one_le_rpow hn1 (hrho0.le.trans hrho_Q)
  have h5 : (5 : ℝ) ≤ (n : ℝ) ^ Q * 5 := by linarith only [hrpow_ge1]
  have h10B : 10 * (inst.cp.B_STEP : ℝ) ≤ (n : ℝ) ^ Q * (10 * Bstep_ub csp d L) := by
    linarith only [hBstep]
  have hMP_r : (masterPolyParamNat inst : ℝ) ≤ masterPoly_ub csp d L := by
    unfold masterPoly_ub; exact Nat.cast_le.mpr hMP_nat
  have hdet : (C₀ : ℝ) * ((masterPolyParamNat inst : ℝ) ^ k * (masterWorkFactorNat inst.cp : ℝ)) ≤
      (n : ℝ) ^ Q * ((C₀ : ℝ) * (masterPoly_ub csp d L) ^ k * workFactor_ub csp d L) := by
    have hp : (masterPolyParamNat inst : ℝ) ^ k ≤ (masterPoly_ub csp d L) ^ k :=
      pow_le_pow_left₀ (Nat.cast_nonneg _) hMP_r k
    have hmp_nn : 0 ≤ (masterPoly_ub csp d L) ^ k :=
      pow_nonneg ((nonnegPoly2_masterPoly_ub csp).1 d L) k
    calc (C₀ : ℝ) * ((masterPolyParamNat inst : ℝ) ^ k * (masterWorkFactorNat inst.cp : ℝ))
        ≤ (C₀ : ℝ) * ((masterPoly_ub csp d L) ^ k * ((n : ℝ) ^ Q * workFactor_ub csp d L)) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul hp hWF (Nat.cast_nonneg _) hmp_nn) (Nat.cast_nonneg C₀)
      _ = (n : ℝ) ^ Q * ((C₀ : ℝ) * (masterPoly_ub csp d L) ^ k * workFactor_ub csp d L) := by ring
  unfold polyTime_master
  have hlhs : ((5 + 10 * inst.cp.B_STEP +
      C₀ * (masterPolyParamNat inst) ^ k * masterWorkFactorNat inst.cp : ℕ) : ℝ) =
      5 + 10 * (inst.cp.B_STEP : ℝ) +
      (C₀ : ℝ) * ((masterPolyParamNat inst : ℝ) ^ k * (masterWorkFactorNat inst.cp : ℝ)) := by
    rw [Nat.cast_add, Nat.cast_add, Nat.cast_mul, Nat.cast_mul, Nat.cast_mul, Nat.cast_pow]
    norm_num [mul_assoc]
  rw [hlhs]
  have hrhs : (n : ℝ) ^ Q *
      (5 + 10 * Bstep_ub csp d L + (C₀ : ℝ) * (masterPoly_ub csp d L) ^ k * workFactor_ub csp d L) =
      (n : ℝ) ^ Q * 5 + (n : ℝ) ^ Q * (10 * Bstep_ub csp d L) +
      (n : ℝ) ^ Q * ((C₀ : ℝ) * (masterPoly_ub csp d L) ^ k * workFactor_ub csp d L) := by ring
  linarith only [h5, h10B, hdet, hrhs]

theorem stepTotalWork_le_polyTime_master {c σ : ℝ} {csp : CurveStaticParams c σ}
    (C₀ k : ℕ) {d n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (inst : ConcreteChainInst csp d n t δ)
    (ram : StepChainRAMSpec inst.cp)
    (hinit : ram.initCost ≤ 5 + 10 * inst.cp.B_STEP +
      C₀ * (masterPolyParamNat inst) ^ k * masterWorkFactorNat inst.cp)
    (hdet : ram.detCost ≤ C₀ * (masterPolyParamNat inst) ^ k * masterWorkFactorNat inst.cp) :
    (ram.stepTotalWork : ℝ) ≤ ((n : ℝ) ^ (Q_c c σ)) * polyTime_master csp C₀ k d (logTerm_of n t δ) := by
  have hmax : ram.stepTotalWork ≤
      5 + 10 * inst.cp.B_STEP + C₀ * (masterPolyParamNat inst) ^ k * masterWorkFactorNat inst.cp := by
    unfold StepChainRAMSpec.stepTotalWork; exact max_le hinit (by omega)
  exact (Nat.cast_le.mpr hmax).trans (polyTime_master_bound C₀ k hn ht hδ0 hδ1 inst)

noncomputable def polySpace_master {c σ : ℝ} (csp : CurveStaticParams c σ)
    (C_sp k_sp : ℕ) (d L : ℕ) : ℝ :=
  3 + ((d : ℝ) + 1) + (d : ℝ) + (C_sp : ℝ) * (masterPoly_ub csp d L) ^ k_sp * spaceFactor_ub csp d L

theorem polySpace_master_isBoundedByPoly2 {c σ : ℝ} (csp : CurveStaticParams c σ) (C_sp k_sp : ℕ) :
    IsBoundedByPoly2 (polySpace_master csp C_sp k_sp) :=
  (nonnegPoly2_add
    (nonnegPoly2_add
      (nonnegPoly2_add (nonnegPoly2_const (by norm_num))
        (nonnegPoly2_add nonnegPoly2_d (nonnegPoly2_const zero_le_one)))
      nonnegPoly2_d)
    (nonnegPoly2_mul
      (nonnegPoly2_mul (nonnegPoly2_const (Nat.cast_nonneg C_sp))
        (nonnegPoly2_pow (nonnegPoly2_masterPoly_ub csp) k_sp))
      (nonnegPoly2_spaceFactor_ub csp))).2

theorem polySpace_master_bound {c σ : ℝ} {csp : CurveStaticParams c σ}
    (C_sp k_sp : ℕ) {d n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (inst : ConcreteChainInst csp d n t δ) :
    ((3 + inst.cp.n * (d + 1) + d +
      C_sp * (masterPolyParamNat inst) ^ k_sp * masterSpaceFactorNat inst.cp : ℕ) : ℝ) ≤
      ((n : ℝ) ^ (1 + σ)) * polySpace_master csp C_sp k_sp d (logTerm_of n t δ) := by
  obtain ⟨L, hL_def⟩ : ∃ x, x = logTerm_of n t δ := ⟨_, rfl⟩
  rw [← hL_def]
  obtain ⟨_, _, _, h1_sig, _⟩ := Q_c_bounds_of_curve csp
  have hLMP := L_log_and_masterPoly_le_ub hn ht hδ0 hδ1 inst; rw [← hL_def] at hLMP
  obtain ⟨_, hMP_nat⟩ := hLMP
  have hSF := spaceFactor_bound hn ht hδ0 hδ1 inst; rw [← hL_def] at hSF
  have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
  have hrpow_ge1 : (1 : ℝ) ≤ (n : ℝ) ^ (1 + σ) :=
    Real.one_le_rpow hn1 (by linarith only [h1_sig])
  have hn_le_sig : (n : ℝ) ≤ (n : ℝ) ^ (1 + σ) := by
    calc (n : ℝ) = (n : ℝ) ^ (1 : ℝ) := (Real.rpow_one (n : ℝ)).symm
      _ ≤ (n : ℝ) ^ (1 + σ) := Real.rpow_le_rpow_of_exponent_le hn1 h1_sig
  have hbase_sp : ((3 + inst.cp.n * (d + 1) + d : ℕ) : ℝ) ≤
      (n : ℝ) ^ (1 + σ) * (3 + ((d : ℝ) + 1) + (d : ℝ)) := by
    rw [inst.hn_eq]; push_cast
    have ht1 : (3 : ℝ) + (d : ℝ) ≤ (n : ℝ) ^ (1 + σ) * (3 + (d : ℝ)) := by
      calc (3 : ℝ) + (d : ℝ) = 1 * (3 + (d : ℝ)) := (one_mul _).symm
        _ ≤ (n : ℝ) ^ (1 + σ) * (3 + (d : ℝ)) :=
            mul_le_mul_of_nonneg_right hrpow_ge1 (by positivity)
    have ht2 : (n : ℝ) * ((d : ℝ) + 1) ≤ (n : ℝ) ^ (1 + σ) * ((d : ℝ) + 1) :=
      mul_le_mul_of_nonneg_right hn_le_sig (by positivity)
    linarith only [ht1, ht2]
  have hMP_r : (masterPolyParamNat inst : ℝ) ≤ masterPoly_ub csp d L := by
    unfold masterPoly_ub; exact Nat.cast_le.mpr hMP_nat
  have hheap : (C_sp : ℝ) * ((masterPolyParamNat inst : ℝ) ^ k_sp * (masterSpaceFactorNat inst.cp : ℝ)) ≤
      (n : ℝ) ^ (1 + σ) * ((C_sp : ℝ) * (masterPoly_ub csp d L) ^ k_sp * spaceFactor_ub csp d L) := by
    have hp : (masterPolyParamNat inst : ℝ) ^ k_sp ≤ (masterPoly_ub csp d L) ^ k_sp :=
      pow_le_pow_left₀ (Nat.cast_nonneg _) hMP_r k_sp
    have hmp_nn : 0 ≤ (masterPoly_ub csp d L) ^ k_sp :=
      pow_nonneg ((nonnegPoly2_masterPoly_ub csp).1 d L) k_sp
    calc (C_sp : ℝ) * ((masterPolyParamNat inst : ℝ) ^ k_sp * (masterSpaceFactorNat inst.cp : ℝ))
        ≤ (C_sp : ℝ) * ((masterPoly_ub csp d L) ^ k_sp * ((n : ℝ) ^ (1 + σ) * spaceFactor_ub csp d L)) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul hp hSF (Nat.cast_nonneg _) hmp_nn) (Nat.cast_nonneg C_sp)
      _ = (n : ℝ) ^ (1 + σ) * ((C_sp : ℝ) * (masterPoly_ub csp d L) ^ k_sp * spaceFactor_ub csp d L) := by ring
  unfold polySpace_master; rw [Nat.cast_add]
  have hlhs : ((C_sp * (masterPolyParamNat inst) ^ k_sp * masterSpaceFactorNat inst.cp : ℕ) : ℝ) =
      (C_sp : ℝ) * ((masterPolyParamNat inst : ℝ) ^ k_sp * (masterSpaceFactorNat inst.cp : ℝ)) := by
    rw [Nat.cast_mul, Nat.cast_mul, Nat.cast_pow, mul_assoc]
  have hrhs : (n : ℝ) ^ (1 + σ) *
      (3 + ((d : ℝ) + 1) + (d : ℝ) + (C_sp : ℝ) * (masterPoly_ub csp d L) ^ k_sp * spaceFactor_ub csp d L) =
      (n : ℝ) ^ (1 + σ) * (3 + ((d : ℝ) + 1) + (d : ℝ)) +
      (n : ℝ) ^ (1 + σ) * ((C_sp : ℝ) * (masterPoly_ub csp d L) ^ k_sp * spaceFactor_ub csp d L) := by ring
  linarith only [hbase_sp, hheap, hlhs, hrhs]

theorem totalSpace_le_polySpace_master {c σ : ℝ} {csp : CurveStaticParams c σ}
    (C_sp k_sp : ℕ) {d n t : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (inst : ConcreteChainInst csp d n t δ)
    (ram : StepChainRAMSpec inst.cp)
    (hfp : ram.TW * ram.BW + ram.TR * ram.BR ≤
      C_sp * (masterPolyParamNat inst) ^ k_sp * masterSpaceFactorNat inst.cp) :
    (ram.totalSpace : ℝ) ≤ ((n : ℝ) ^ (1 + σ)) * polySpace_master csp C_sp k_sp d (logTerm_of n t δ) := by
  have hle : ram.totalSpace ≤
      3 + inst.cp.n * (d + 1) + d +
        C_sp * (masterPolyParamNat inst) ^ k_sp * masterSpaceFactorNat inst.cp := by
    unfold StepChainRAMSpec.totalSpace; omega
  exact (Nat.cast_le.mpr hle).trans (polySpace_master_bound C_sp k_sp hn ht hδ0 hδ1 inst)

theorem ConcreteChainInst.good_and_bad_stepCoins_card {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d)
    {P : DynamicPointSet d} (hP : P.WellFormed inst.cp.n)
    {op : DynamicUpdate d} (hleg : IsLegalUpdate inst.cp.n Set.univ P op)
    {st : ChainEngineState inst.cp} (hwf : ChainEngineWF inst.cp P st)
    (hgd : C14d1.ChainEngineGood inst.cp inst.hh0 inst.hh1 st) :
    open Classical in
    ((1 - δ / (t : ℝ)) * ((2 ^ inst.cp.B_STEP : ℕ) : ℝ) ≤
      ((Finset.univ.filter (fun bits : Fin inst.cp.B_STEP → Bool =>
        C14d2.GoodStepCoins inst.cp inst.hh0 inst.hh1 st (toInternalUpdate P op)
          (bitsToStepCoinBundle inst.cp bits))).card : ℝ)) ∧
    (((Finset.univ.filter (fun bits : Fin inst.cp.B_STEP → Bool =>
        ¬ C14d2.GoodStepCoins inst.cp inst.hh0 inst.hh1 st (toInternalUpdate P op)
          (bitsToStepCoinBundle inst.cp bits))).card : ℝ) ≤
      (δ / (t : ℝ)) * ((2 ^ inst.cp.B_STEP : ℕ) : ℝ)) :=
  good_and_bad_stepCoins_bounds inst _
    (C14e.goodStepCoins_card_ge h_lem_5_1 h_clm_7_3 hd inst.he1 inst.cp inst.hh0 inst.hh1
      inst.hε0 inst.hε1 inst.hψ0 inst.hmc inst.hjob_err_le1 inst.hδ_base_le1 inst.hgen_card
      hP hleg hwf hgd)

def ConcreteChainInst.toChainEngineProbSpec {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) :
    ChainEngineProbSpec inst.cp t δ where
  GoodEngine := C14d1.ChainEngineGood inst.cp inst.hh0 inst.hh1
  GoodCoins := C14d2.GoodStepCoins inst.cp inst.hh0 inst.hh1
  good_empty := C14d1.empty_chainEngineGood inst.cp inst.hh0 inst.hh1
  step_spec := fun coins hP hleg hwf =>
    C14d2.stepChainEngine_spec h_lem_5_1 h_clm_7_3 hd inst.he1
      (by rw [inst.hc_eq]; linarith only [csp.hc_gt])
      inst.cp inst.hh0 inst.hh1 hP hleg hwf coins
  good_coins_card_ge := fun hP hleg hwf hgd =>
    (inst.good_and_bad_stepCoins_card h_lem_5_1 h_clm_7_3 hd hP hleg hwf hgd).1

noncomputable def mkSublinearCurveSpec {c σ : ℝ}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (csp : CurveStaticParams c σ) (C₀ k C_sp k_sp : ℕ)
    (mkRAM :
      ∀ (d n t : ℕ) (δ : ℝ)
        (hd : 1 ≤ d) (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2),
        M_cutoff c σ < n → M_cutoff c σ < t →
        let inst := mkConcreteChainInst csp d n t δ hd hn ht hδ0 hδ1
        { ram : StepChainRAMSpec inst.cp //
            ram.initCost ≤ 5 + 10 * inst.cp.B_STEP +
              C₀ * (masterPolyParamNat inst) ^ k * masterWorkFactorNat inst.cp ∧
            ram.detCost ≤ C₀ * (masterPolyParamNat inst) ^ k * masterWorkFactorNat inst.cp ∧
            ram.TW * ram.BW + ram.TR * ram.BR ≤
              C_sp * (masterPolyParamNat inst) ^ k_sp * masterSpaceFactorNat inst.cp }) :
    SublinearCurveSpec c σ where
  M_cut := M_cut_poly c σ
  polyM := M_cut_poly_bounded c σ
  polySubTime := polyTime_master csp C₀ k
  polySubSpace := polySpace_master csp C_sp k_sp
  hPolySubTime := polyTime_master_isBoundedByPoly2 csp C₀ k
  hPolySubSpace := polySpace_master_isBoundedByPoly2 csp C_sp k_sp
  mkEngine := by
    intro d n t δ hd hn ht hδ0 hδ1 logTerm hMn hMt
    let inst := mkConcreteChainInst csp d n t δ hd hn ht hδ0 hδ1
    obtain ⟨ram, hinit, hdet, hfp⟩ := mkRAM d n t δ hd hn ht hδ0 hδ1 hMn hMt
    exact ⟨inst.params, (inst.h_rat : ℝ), inst.cp,
      inst.toChainEngineProbSpec h_lem_5_1 h_clm_7_3 hd, ram,
      inst.hc_eq, inst.hn_eq,
      stepTotalWork_le_polyTime_master C₀ k hn ht hδ0 hδ1 inst ram hinit hdet,
      totalSpace_le_polySpace_master C_sp k_sp hn ht hδ0 hδ1 inst ram hfp⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG15
