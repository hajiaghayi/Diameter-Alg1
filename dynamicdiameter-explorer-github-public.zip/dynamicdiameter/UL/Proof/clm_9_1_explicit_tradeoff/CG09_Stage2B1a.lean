import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 8a. Job Footprint Predicates, `TickJobResultPost`, & `.copy` Scan Wrapper -/

/-- `engMetaTbl` indices owned by rebuild job `r` (`jobMetaBase r .. +8` and `readySlotOff r 0 .. +D_max`). -/
def InJobMetaRegion {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : ℕ) (i : ℤ) : Prop :=
  (jobMetaBase cp r ≤ i ∧ i < jobMetaBase cp r + 8) ∨
  (readySlotOff cp r 0 ≤ i ∧ i < readySlotOff cp r 0 + (cp.D_max : ℤ))

/-- `engArrTbl` indices owned by rebuild job `r` (the 4 sparse-set slices `2+4r .. 5+4r`). -/
def InJobArrRegion {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : ℕ) (i : ℤ) : Prop :=
  (snapElemOff cp r ≤ i ∧ i < snapElemOff cp r + (cp.n : ℤ)) ∨
  (snapPosOff cp r ≤ i ∧ i < snapPosOff cp r + (cp.n : ℤ)) ∨
  (delSnapElemOff cp r ≤ i ∧ i < delSnapElemOff cp r + (cp.n : ℤ)) ∨
  (delSnapPosOff cp r ≤ i ∧ i < delSnapPosOff cp r + (cp.n : ℤ))

theorem not_inJobMetaRegion_header {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (r : ℕ) {i : ℤ}
    (_h0 : 0 ≤ i) (hlt : i < 16 + (cp.D_max : ℤ)) :
    ¬ InJobMetaRegion cp r i := by
  have hnn : 0 ≤ (r : ℤ) * (cp.D_max : ℤ) := by exact_mod_cast Nat.zero_le (r * cp.D_max)
  unfold InJobMetaRegion jobMetaBase readySlotOff
  omega

private theorem blk_stride_disj {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {blk b : ℕ} (hne : blk ≠ b)
    {k : ℤ} (hk0 : 0 ≤ k) (hkn : k < (cp.n : ℤ)) :
    ¬ (((b * S_stride cp : ℕ) : ℤ) ≤ ((blk * S_stride cp : ℕ) : ℤ) + k ∧
       ((blk * S_stride cp : ℕ) : ℤ) + k < ((b * S_stride cp : ℕ) : ℤ) + (cp.n : ℤ)) := by
  have hS : (cp.n : ℤ) < (S_stride cp : ℤ) := by
    have : cp.n < S_stride cp := by unfold S_stride; omega
    exact_mod_cast this
  rcases Nat.lt_or_gt_of_ne hne with hlt | hgt
  · have hm : blk * S_stride cp + S_stride cp ≤ b * S_stride cp := by
      simpa [Nat.succ_mul] using Nat.mul_le_mul_right (S_stride cp) hlt
    have hmZ : ((blk * S_stride cp : ℕ) : ℤ) + (S_stride cp : ℤ) ≤ ((b * S_stride cp : ℕ) : ℤ) := by
      exact_mod_cast hm
    omega
  · have hm : b * S_stride cp + S_stride cp ≤ blk * S_stride cp := by
      simpa [Nat.succ_mul] using Nat.mul_le_mul_right (S_stride cp) hgt
    have hmZ : ((b * S_stride cp : ℕ) : ℤ) + (S_stride cp : ℤ) ≤ ((blk * S_stride cp : ℕ) : ℤ) := by
      exact_mod_cast hm
    omega

theorem not_inJobArrRegion_of_blk_ne {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (r : ℕ) {blk : ℕ}
    (h2 : blk ≠ 2 + 4 * r) (h3 : blk ≠ 3 + 4 * r)
    (h4 : blk ≠ 4 + 4 * r) (h5 : blk ≠ 5 + 4 * r)
    {k : ℤ} (hk0 : 0 ≤ k) (hkn : k < (cp.n : ℤ)) :
    ¬ InJobArrRegion cp r (((blk * S_stride cp : ℕ) : ℤ) + k) := by
  rintro (hc | hc | hc | hc)
  · exact blk_stride_disj h2 hk0 hkn hc
  · exact blk_stride_disj h3 hk0 hkn hc
  · exact blk_stride_disj h4 hk0 hkn hc
  · exact blk_stride_disj h5 hk0 hkn hc

/-- Complete postcondition of `tickRebuildJobStmt ops r` on active job `r`:
leaves commit status code `wRead m₁ engScrTbl 10 ∈ {0, 1, 2, 3}` (`0` = `Sum.inl jb'`,
`1` = `.copy` commit, `2` = `.build` commit with `u_done.resArr`, `3` = `.build` overflow commit),
keeps `EncJobSlot` and `allSlots'.Nodup` valid in ALL cases (so all `D_max` jobs can be ticked
before splicing the earliest commit, or spliced immediately), and preserves everything outside
job `r`'s own metadata/arrays and `engScrTbl[10 ..]`. -/
def TickJobResultPost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max)
    (servSlots : List ℕ)
    (curJobs : Fin cp.D_max → Option (SuffixJob cp))
    (readySlots : Fin cp.D_max → List ℕ)
    (curSlots : Fin cp.D_max → ℕ)
    (advRes : SuffixJob cp ⊕ (List (MNode cp) × List ℕ × Bool))
    (m₀ m₁ : ArithRAMMemory) : Prop :=
  ops.SlotsReady m₁ ∧
  (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
  (∀ i, ¬ InJobMetaRegion cp r.val i → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
  (∀ i, ¬ InJobArrRegion cp r.val i → wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
  (∀ i, i < 10 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
  (∀ t < 2, ∀ i, rRead m₁ t i = rRead m₀ t i) ∧
  rRead m₁ engRealTbl 0 = rRead m₀ engRealTbl 0 ∧
  (∀ mn' s, s < M_slots cp →
    s ∈ servSlots ++ (List.finRange cp.D_max).flatMap (fun r' =>
      if r' = r then [] else jobUsedSlots (curJobs r') (readySlots r') (curSlots r')) →
    ops.EncNode mn' s m₀ → ops.EncNode mn' s m₁) ∧
  ∃ (outJb : SuffixJob cp) (rSlots' : List ℕ) (cSlot' : ℕ),
    let curJobs' := Function.update curJobs r (some outJb)
    let readySlots' := Function.update readySlots r rSlots'
    let curSlots' := Function.update curSlots r cSlot'
    let allSlots' := servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs' r') (readySlots' r') (curSlots' r'))
    EncJobSlot ops r (some outJb) rSlots' cSlot' m₁ ∧
    (∀ r' : Fin cp.D_max, EncJobSlot ops r' (curJobs' r') (readySlots' r') (curSlots' r') m₁) ∧
    allSlots'.Nodup ∧
    (∀ s ∈ allSlots', s < M_slots cp) ∧
    match advRes with
    | Sum.inl jb' =>
        wRead m₁ engScrTbl 10 = 0 ∧ outJb = jb'
    | Sum.inr (newSuf, newLeaf, newOv) =>
        outJb.ready = newSuf ∧
        jobUsedSlots (some outJb) rSlots' cSlot' = rSlots' ∧
        rSlots'.length = newSuf.length ∧
        wRead m₁ engMetaTbl (jobMetaBase cp r.val + 1) = (newSuf.length : ℤ) ∧
        (∀ q (hq : q < newSuf.length) (hqs : q < rSlots'.length),
          wRead m₁ engMetaTbl (readySlotOff cp r.val q) = (rSlots'[q]'hqs : ℤ) ∧
          ops.EncNode (newSuf[q]'hq) (rSlots'[q]'hqs) m₁) ∧
        ((wRead m₁ engScrTbl 10 = 1 ∧ newOv = false ∧
            EncSparseSet cp.n (jobMetaBase cp r.val + 5)
              (snapElemOff cp r.val) (snapPosOff cp r.val) newLeaf m₁) ∨
         (wRead m₁ engScrTbl 10 = 2 ∧ newOv = false ∧
            ∃ (u_done : MNode cp) (uSlot : ℕ),
              uSlot < M_slots cp ∧
              wRead m₁ engMetaTbl (jobMetaBase cp r.val + 7) = (uSlot : ℤ) ∧
              ops.EncNode u_done uSlot m₁ ∧
              u_done.resArr = newLeaf) ∨
         (wRead m₁ engScrTbl 10 = 3 ∧ newOv = true ∧ newLeaf = []))

/-- Helper: preserve `EncJobSlot ops r'` for all `r' ≠ r` whenever job `r`'s regions are disjoint
and every slot in `jobUsedSlots` of `r'` preserves `ops.EncNode`. -/
theorem encJobSlot_other_of_frame {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {r r' : Fin cp.D_max} (hne : r' ≠ r)
    {jbOpt : Option (SuffixJob cp)} {rSlots : List ℕ} {cSlot : ℕ}
    {m₀ m₁ : ArithRAMMemory}
    (hj : EncJobSlot ops r' jbOpt rSlots cSlot m₀)
    (hu_lt : ∀ s ∈ jobUsedSlots jbOpt rSlots cSlot, s < M_slots cp)
    (hfm : ∀ i, ¬ InJobMetaRegion cp r.val i → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i)
    (hfa : ∀ i, ¬ InJobArrRegion cp r.val i → wRead m₁ engArrTbl i = wRead m₀ engArrTbl i)
    (hnd : ∀ mn' s, s < M_slots cp → s ∈ jobUsedSlots jbOpt rSlots cSlot →
           ops.EncNode mn' s m₀ → ops.EncNode mn' s m₁) :
    EncJobSlot ops r' jbOpt rSlots cSlot m₁ := by
  have hne_val : r'.val ≠ r.val := fun he => hne (Fin.ext he)
  have hbase_disj : ∀ k : ℤ, 0 ≤ k → k < 8 →
      ¬ InJobMetaRegion cp r.val (jobMetaBase cp r'.val + k) := by
    intro k hk0 hk8
    have hr'_lt := r'.isLt; have hr_lt := r.isLt
    have hnn : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) := by exact_mod_cast Nat.zero_le (r.val * cp.D_max)
    unfold InJobMetaRegion jobMetaBase readySlotOff
    omega
  have hready_disj : ∀ q : ℕ, q < cp.D_max →
      ¬ InJobMetaRegion cp r.val (readySlotOff cp r'.val q) := by
    intro q hq
    have hr'_lt := r'.isLt; have hr_lt := r.isLt
    have hnn' : 0 ≤ (r'.val : ℤ) * (cp.D_max : ℤ) := by exact_mod_cast Nat.zero_le (r'.val * cp.D_max)
    unfold InJobMetaRegion jobMetaBase readySlotOff
    rcases Nat.lt_or_gt_of_ne hne_val with hlt1 | hlt2
    · have hm : r'.val * cp.D_max + cp.D_max ≤ r.val * cp.D_max := by
        simpa [Nat.succ_mul] using Nat.mul_le_mul_right cp.D_max hlt1
      have hcast : (r'.val : ℤ) * (cp.D_max : ℤ) + (cp.D_max : ℤ) ≤ (r.val : ℤ) * (cp.D_max : ℤ) := by
        exact_mod_cast hm
      omega
    · have hm : r.val * cp.D_max + cp.D_max ≤ r'.val * cp.D_max := by
        simpa [Nat.succ_mul] using Nat.mul_le_mul_right cp.D_max hlt2
      have hcast : (r.val : ℤ) * (cp.D_max : ℤ) + (cp.D_max : ℤ) ≤ (r'.val : ℤ) * (cp.D_max : ℤ) := by
        exact_mod_cast hm
      omega
  cases jbOpt with
  | none =>
      refine ⟨hj.1, ?_⟩
      simpa using (hfm (jobMetaBase cp r'.val) (hbase_disj 0 (by omega) (by omega))).trans hj.2
  | some jb =>
      rcases hj with ⟨hact, hrle, hrlen, hwlen, hready, hph⟩
      have hb0 : wRead m₁ engMetaTbl (jobMetaBase cp r'.val) = wRead m₀ engMetaTbl (jobMetaBase cp r'.val) := by
        simpa using hfm (jobMetaBase cp r'.val) (hbase_disj 0 (by omega) (by omega))
      refine ⟨hb0.trans hact,
        hrle, hrlen, (hfm _ (hbase_disj 1 (by omega) (by omega))).trans hwlen,
        fun q hq hqs => ?_, ?_⟩
      · have hmem_u : rSlots[q]'hqs ∈ jobUsedSlots (some jb) rSlots cSlot := by
          dsimp only [jobUsedSlots]
          cases jb.phase with
          | copy _ => exact List.getElem_mem hqs
          | build _ => exact List.mem_append_left _ (List.getElem_mem hqs)
        exact ⟨(hfm _ (hready_disj q (lt_of_lt_of_le hq hrle))).trans (hready q hq hqs).1,
          hnd _ _ (hu_lt _ hmem_u) hmem_u (hready q hq hqs).2⟩
      · cases hjp : jb.phase with
        | copy cs =>
            simp only [hjp] at hph
            rcases hph with ⟨hp2, hp3, hp4, hsp⟩
            refine ⟨(hfm _ (hbase_disj 2 (by omega) (by omega))).trans hp2,
              (hfm _ (hbase_disj 3 (by omega) (by omega))).trans hp3,
              (hfm _ (hbase_disj 4 (by omega) (by omega))).trans hp4,
              hsp.ext (hfm _ (hbase_disj 5 (by omega) (by omega)))
                (fun k hk => hfa _ (not_inJobArrRegion_of_blk_ne r.val
                  (by omega) (by omega) (by omega) (by omega) (by omega)
                  (by exact_mod_cast lt_of_lt_of_le hk hsp.length_le)))
                (fun y hy => hfa _ (not_inJobArrRegion_of_blk_ne r.val
                  (by omega) (by omega) (by omega) (by omega) (by omega) (by exact_mod_cast hsp.2.1 y hy)))⟩
        | build bs =>
            simp only [hjp] at hph
            rcases hph with ⟨hp2, hp3, hp4, hsp, hdsp, hcslot, hcenc⟩
            have hc_mem : cSlot ∈ jobUsedSlots (some jb) rSlots cSlot := by
              simp [jobUsedSlots, hjp]
            refine ⟨(hfm _ (hbase_disj 2 (by omega) (by omega))).trans hp2,
              (hfm _ (hbase_disj 3 (by omega) (by omega))).trans hp3,
              (hfm _ (hbase_disj 4 (by omega) (by omega))).trans hp4,
              hsp.ext (hfm _ (hbase_disj 5 (by omega) (by omega)))
                (fun k hk => hfa _ (not_inJobArrRegion_of_blk_ne r.val
                  (by omega) (by omega) (by omega) (by omega) (by omega)
                  (by exact_mod_cast lt_of_lt_of_le hk hsp.length_le)))
                (fun y hy => hfa _ (not_inJobArrRegion_of_blk_ne r.val
                  (by omega) (by omega) (by omega) (by omega) (by omega) (by exact_mod_cast hsp.2.1 y hy))),
              hdsp.ext (hfm _ (hbase_disj 6 (by omega) (by omega)))
                (fun k hk => hfa _ (not_inJobArrRegion_of_blk_ne r.val
                  (by omega) (by omega) (by omega) (by omega) (by omega)
                  (by exact_mod_cast lt_of_lt_of_le hk hdsp.length_le)))
                (fun y hy => hfa _ (not_inJobArrRegion_of_blk_ne r.val
                  (by omega) (by omega) (by omega) (by omega) (by omega) (by exact_mod_cast hdsp.2.1 y hy))),
              (hfm _ (hbase_disj 7 (by omega) (by omega))).trans hcslot,
              hnd _ _ (hu_lt _ hc_mem) hc_mem hcenc⟩

/-! ### `.copy`-Phase Scan Wrapper (`tickJobCopyRunLoopStmt`) -/

def tickJobCopyRunLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .ite (.intEq (.readHeap engMetaTbl (.lit (base + 1))) (.lit 0))
    (.seq (.writeWordHeap engScrTbl (.lit 18) (.readHeap engMetaTbl (.lit (servSlotOff r.val))))
          (advanceCopyLoopStmt ops r false 18))
    (.seq (.writeWordHeap engScrTbl (.lit 18)
            (.readHeap engMetaTbl
              (.add (.lit (readySlotOff cp r.val 0))
                    (.sub (.readHeap engMetaTbl (.lit (base + 1))) (.lit 1)))))
          (advanceCopyLoopStmt ops r true 18))

theorem zeroRand_tickJobCopyRunLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (tickJobCopyRunLoopStmt ops r) :=
  .ite (.seq (.writeWordHeap _ _ _) (zeroRand_advanceCopyLoopStmt ops r false 18))
       (.seq (.writeWordHeap _ _ _) (zeroRand_advanceCopyLoopStmt ops r true 18))

theorem exec_tickJobCopyRunLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {actH S_anc : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    {anc : MNode cp} {jb : SuffixJob cp} {cs : CopyState}
    {servSlots : List ℕ}
    {curJobs : Fin cp.D_max → Option (SuffixJob cp)}
    {readySlots : Fin cp.D_max → List ℕ}
    {curSlots : Fin cp.D_max → ℕ}
    {m₀ : ArithRAMMemory}
    (hphase : jb.phase = .copy cs)
    (hcur_r : curJobs r = some jb)
    (hr_serv : r.val < servSlots.length)
    (hS_anc : S_anc ⊆ actH)
    (hact_n : ∀ x ∈ actH, x < cp.n)
    (hanc_ln : LiveNodeInv cp actH pts gt S_anc anc)
    (hjb_inv : SuffixJobInvSlack cp cp.B_scan actH pts gt S_anc anc r.val jb)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hserv_slots : ∀ i (his : i < servSlots.length),
      wRead m₀ engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ))
    (henc_anc : ops.EncNode anc (servSlots[r.val]'hr_serv) m₀)
    (hj_r : EncJobSlot ops r (some jb) (readySlots r) (curSlots r) m₀)
    (hall_lt : ∀ s ∈ servSlots ++ (List.finRange cp.D_max).flatMap
      (fun r' => jobUsedSlots (curJobs r') (readySlots r') (curSlots r')), s < M_slots cp) :
    let base := jobMetaBase cp r.val
    let srcHist := (match jb.ready.getLast? with | none => anc | some u_last => u_last).histArr
    let tgtArr := match jb.ready.getLast? with | none => anc.nd.denseArr | some u_last => u_last.resArr
    let steps := min (cs.L_hist - cs.copyCur) cp.B_scan
    let cs' := advanceCopyLoop srcHist tgtArr steps cs
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (tickJobCopyRunLoopStmt ops r) m₀
      (fun mL =>
        ops.SlotsReady mL ∧
        wRead mL engMetaTbl (base + 3) = (cs'.L_hist : ℤ) ∧
        wRead mL engMetaTbl (base + 4) = (cs'.copyCur : ℤ) ∧
        EncSparseSet cp.n (base + 5) (snapElemOff cp r.val) (snapPosOff cp r.val) cs'.snapArr mL ∧
        (∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s mL) ∧
        (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead mL t i = wRead m₀ t i) ∧
        (∀ i, i ≠ base + 4 → i ≠ base + 5 → wRead mL engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, (i < snapElemOff cp r.val ∨ snapElemOff cp r.val + (cp.n : ℤ) ≤ i) →
              (i < snapPosOff cp r.val ∨ snapPosOff cp r.val + (cp.n : ℤ) ≤ i) →
              wRead mL engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, i < 18 → wRead mL engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead mL t i = rRead m₀ t i))
      (140 + cp.B_scan * (2 * ops.C_read + 260)) := by
  intro base srcHist tgtArr steps cs'
  have hTW := ops.hTW; have hBW_scr := ops.hBW_scr
  have hj_r' := hj_r
  simp only [EncJobSlot, hphase] at hj_r'
  rcases hj_r' with ⟨_, hr_le, hr_len, hw_rlen, hready_enc, _, hw_L, hw_cur, hsnap_enc⟩
  dsimp only [SuffixJobInvSlack] at hjb_inv
  rcases hjb_inv with ⟨_, hcl_r, _, _, hph_inv⟩
  rw [hphase] at hph_inv
  rcases hph_inv with ⟨hcur_lt_L, _, hcs_inv⟩
  set T_end := foldResiduals pts S_anc jb.ready
  have hTend_sub : T_end ⊆ actH := (chainListInv_getElem S_anc jb.ready hS_anc hcl_r).1
  have hTend_n : ∀ x ∈ T_end, x < cp.n := fun x hx => hact_n x (hTend_sub hx)
  unfold tickJobCopyRunLoopStmt
  by_cases hs0 : jb.ready.length = 0
  · have hemp : jb.ready = [] := List.eq_nil_of_length_eq_zero hs0
    have hgl : jb.ready.getLast? = none := by simp [hemp]
    have hcond0 : (evalArithCond inp 0 m₀ (.intEq (.readHeap engMetaTbl (.lit (base + 1))) (.lit 0))).1 = true := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead m₀ engMetaTbl (base + 1) = 0) = true
      rw [hw_rlen, hs0]; decide
    refine ExecDet.ite' (C_c := 8) (C_b := 132 + cp.B_scan * (2 * ops.C_read + 260)) _ _ _ hcond0
      (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
      (by clear * -; nlinarith)
    let pSlot := servSlots[r.val]'hr_serv
    have hpSlot_M : pSlot < M_slots cp := hall_lt pSlot (List.mem_append_left _ (List.getElem_mem hr_serv))
    refine ExecDet.seq' (100 + cp.B_scan * (2 * ops.C_read + 260))
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 18) (.readHeap engMetaTbl (.lit (servSlotOff r.val)))
        18 (pSlot : ℤ) hfp₀ (by unfold engScrTbl; omega) (by omega)
        (by unfold M_slots at hBW_scr; omega) rfl
        (by simp only [evalIntExpr]; exact hserv_slots r.val hr_serv) (by simp [intExprOps]) rfl)
      (by clear * -; nlinarith) ?_
    intro m1 hm1 hfp1; subst hm1
    set m1_st := H3a.wWrite m₀ engScrTbl 18 (pSlot : ℤ)
    have hw9_1 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m1_st t i = wRead m₀ t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    have hcs_inv_anc : CopyStateInv anc.histArr T_end cs := by simpa [srcHist, hgl] using hcs_inv
    have htgt_anc : anc.nd.denseArr.toFinset = T_end := by
      dsimp only [T_end]; rw [hemp]; dsimp only [foldResiduals]
      exact hanc_ln.1
    have hcur_anc_n : ∀ y ∈ anc.nd.curSet, y < cp.n :=
      fun y hy => hact_n y (hS_anc (hanc_ln.1 ▸ hy))
    refine (exec_advanceCopyLoopStmt ops inp r false 18 (pts := pts) (T_end := T_end)
      (prevNode := anc) (prevSlot := pSlot) (cs := cs)
      (by omega) (by omega) hpSlot_M (Nat.le_of_lt hcur_lt_L) hcs_inv_anc
      (by simpa using htgt_anc) hTend_n hcur_anc_n hanc_ln.2.2.2.2.2.2.2
      hfp1 (ops.slotsReady_ext m₀ m1_st hsr₀ hw9_1 (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
      (ops.encNode_ext anc pSlot m₀ m1_st henc_anc hw9_1
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
      (wRead_wWrite_self _ _ _ _)
      ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hw_L)
      ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hw_cur)
      (hsnap_enc.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide))))).mono ?_ le_rfl
    intro mL ⟨hsrL, hwLL, hwcurL, hsnapL, hndL, hftL, hfmL, hfaL, hfsL, hfrL⟩ _
    have hcs'_eq : advanceCopyLoop anc.histArr
        (if false = true then anc.resArr else anc.nd.denseArr)
        (min (cs.L_hist - cs.copyCur) cp.B_scan) cs = cs' := by
      simp [cs', steps, srcHist, tgtArr, hgl]
    rw [hcs'_eq] at hwLL hwcurL hsnapL
    exact ⟨hsrL, hwLL, hwcurL, hsnapL,
      fun mn' s hs he0 => hndL mn' s hs
        (ops.encNode_ext mn' s m₀ m1_st he0 hw9_1
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)),
      fun t ht9 ht1 ht2 ht3 i => (hftL t ht9 ht1 ht2 ht3 i).trans (wRead_wWrite_of_ne _ _ (Or.inl ht3)),
      fun i h4 h5 => (hfmL i h4 h5).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide))),
      fun i he hp => (hfaL i he hp).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide))),
      fun i hi18 => (hfsL i (by omega)).trans (wRead_wWrite_of_ne _ _ (Or.inr (by omega))),
      fun t ht3 i => (hfrL t ht3 i).trans (rRead_wWrite _ _ _ _ _ _)⟩
  · have hpos : 0 < jb.ready.length := Nat.pos_of_ne_zero hs0
    have hcond0 : (evalArithCond inp 0 m₀ (.intEq (.readHeap engMetaTbl (.lit (base + 1))) (.lit 0))).1 = false := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead m₀ engMetaTbl (base + 1) = 0) = false
      rw [hw_rlen]; exact decide_eq_false (by omega)
    refine ExecDet.ite' (C_c := 8) (C_b := 132 + cp.B_scan * (2 * ops.C_read + 260)) _ _ _ hcond0
      (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
      (by clear * -; nlinarith)
    have hlast_idx : jb.ready.length - 1 < jb.ready.length := by omega
    have hlast_s : jb.ready.length - 1 < (readySlots r).length := by omega
    let u_last := jb.ready[jb.ready.length - 1]'hlast_idx
    let pSlot := (readySlots r)[jb.ready.length - 1]'hlast_s
    have hgl : jb.ready.getLast? = some u_last := by
      rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem hlast_idx]
    have hpSlot_M : pSlot < M_slots cp := hall_lt pSlot
      (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, by
        simp only [hcur_r, jobUsedSlots, hphase]; exact List.getElem_mem hlast_s⟩))
    have hread_last : (evalIntExpr inp.toWordView 0 m₀.words (.readHeap engMetaTbl
        (.add (.lit (readySlotOff cp r.val 0))
              (.sub (.readHeap engMetaTbl (.lit (base + 1))) (.lit 1))))).1 = (pSlot : ℤ) := by
      simp only [evalIntExpr]
      change wRead m₀ engMetaTbl (readySlotOff cp r.val 0 + (wRead m₀ engMetaTbl (base + 1) - 1)) = _
      rw [hw_rlen]
      have hidx_eq : readySlotOff cp r.val 0 + ((jb.ready.length : ℤ) - 1) =
          readySlotOff cp r.val (jb.ready.length - 1) := by unfold readySlotOff; omega
      rw [hidx_eq]; exact (hready_enc (jb.ready.length - 1) hlast_idx hlast_s).1
    refine ExecDet.seq' (100 + cp.B_scan * (2 * ops.C_read + 260))
      (ExecDet.wWrite (C := 20) inp engScrTbl (.lit 18)
        (.readHeap engMetaTbl (.add (.lit (readySlotOff cp r.val 0))
          (.sub (.readHeap engMetaTbl (.lit (base + 1))) (.lit 1))))
        18 (pSlot : ℤ) hfp₀ (by unfold engScrTbl; omega) (by omega)
        (by unfold M_slots at hBW_scr; omega) rfl hread_last (by simp [intExprOps]) rfl)
      (by clear * -; nlinarith) ?_
    intro m1 hm1 hfp1; subst hm1
    set m1_st := H3a.wWrite m₀ engScrTbl 18 (pSlot : ℤ)
    have hw9_1 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m1_st t i = wRead m₀ t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    rcases chainListInv_getLast hS_anc hcl_r hgl with ⟨_, hres_eq, _⟩
    rcases (chainListInv_getElem S_anc jb.ready hS_anc hcl_r).2 (jb.ready.length - 1) hlast_idx
      with ⟨hS_prev_sub, hln_last⟩
    have hcur_last_n : ∀ y ∈ u_last.nd.curSet, y < cp.n :=
      fun y hy => hact_n y (hS_prev_sub (hln_last.1 ▸ hy))
    have hcs_inv_last : CopyStateInv u_last.histArr T_end cs := by simpa [srcHist, hgl] using hcs_inv
    refine (exec_advanceCopyLoopStmt ops inp r true 18 (pts := pts) (T_end := T_end)
      (prevNode := u_last) (prevSlot := pSlot) (cs := cs)
      (by omega) (by omega) hpSlot_M (Nat.le_of_lt hcur_lt_L) hcs_inv_last
      (by simpa using hres_eq) hTend_n hcur_last_n hln_last.2.2.2.2.2.2.2
      hfp1 (ops.slotsReady_ext m₀ m1_st hsr₀ hw9_1 (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
      (ops.encNode_ext u_last pSlot m₀ m1_st (hready_enc _ hlast_idx hlast_s).2 hw9_1
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
      (wRead_wWrite_self _ _ _ _)
      ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hw_L)
      ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hw_cur)
      (hsnap_enc.ext (wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide)))
        (fun _ _ => wRead_wWrite_of_ne _ _ (Or.inl (by decide))))).mono ?_ le_rfl
    intro mL ⟨hsrL, hwLL, hwcurL, hsnapL, hndL, hftL, hfmL, hfaL, hfsL, hfrL⟩ _
    have hcs'_eq : advanceCopyLoop u_last.histArr
        (if true = true then u_last.resArr else u_last.nd.denseArr)
        (min (cs.L_hist - cs.copyCur) cp.B_scan) cs = cs' := by
      simp [cs', steps, srcHist, tgtArr, hgl]
    rw [hcs'_eq] at hwLL hwcurL hsnapL
    exact ⟨hsrL, hwLL, hwcurL, hsnapL,
      fun mn' s hs he0 => hndL mn' s hs
        (ops.encNode_ext mn' s m₀ m1_st he0 hw9_1
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)),
      fun t ht9 ht1 ht2 ht3 i => (hftL t ht9 ht1 ht2 ht3 i).trans (wRead_wWrite_of_ne _ _ (Or.inl ht3)),
      fun i h4 h5 => (hfmL i h4 h5).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide))),
      fun i he hp => (hfaL i he hp).trans (wRead_wWrite_of_ne _ _ (Or.inl (by decide))),
      fun i hi18 => (hfsL i (by omega)).trans (wRead_wWrite_of_ne _ _ (Or.inr (by omega))),
      fun t ht3 i => (hfrL t ht3 i).trans (rRead_wWrite _ _ _ _ _ _)⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
