import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeB2

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

/-! ### 5c-pre. `N_cfg` Delete Loop Helper (`managedNodeDeleteCfgsStmt`) -/

def managedNodeDeleteCfgsStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wNodeBaseW)
  let bRE := IntExpr.readHeap scrW (.lit wNodeBaseR)
  let sOE := IntExpr.readHeap scrW (.lit wNodeSeedOff)
  let wOffO := wScr + 2
  let wOffV := wScr + 3
  let wCfgBW := wScr + 6
  let wCfgBR := wScr + 7
  let wCfgSeed := wScr + 8
  let wSubScr := wScr + 10
  let histOffVal : ℤ := 8 + 2 * swapPoolStride n
  let radWOffVal : ℤ := histOffVal + (1 + (cap_hist : ℤ))
  let radROffVal : ℤ := (d : ℤ) + 2
  let cfgsWOffVal : ℤ := radWOffVal + radTreeWStride K_seg
  let cfgsROffVal : ℤ := radROffVal + radTreeRStride K_seg
  let B_cfg : ℤ := (cfgSeedBits L_p2 R ℓ M₀ d b : ℤ)
  .seq (.writeWordHeap scrW (.lit wOffO) bRE)
  (.seq (.writeWordHeap scrW (.lit wOffV) (.add bRE (.lit ((d : ℤ) + 1))))
        (.ite (.realLt (.ofInt (.lit 0)) (.readRealHeap tblR (.readHeap scrW (.lit wOffV))))
          (seqFinCfgStmt N_cfg (fun i =>
            .seq (.writeWordHeap scrW (.lit wCfgBW)
                    (.add bWE (.lit (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride))))
            (.seq (.writeWordHeap scrW (.lit wCfgBR)
                    (.add bRE (.lit (cfgsROffVal + (i.val : ℤ) * ops.cfgRStride))))
            (.seq (.writeWordHeap scrW (.lit wCfgSeed)
                    (.add sOE (.lit ((i.val : ℤ) * B_cfg))))
                  (ops.deleteStmt (specs i)
                    wCfgBW wCfgBR wOffO wOffV wUid wCfgSeed wSubScr rScr)))))
          .skip))

theorem zeroRand_managedNodeDeleteCfgsStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr : ℤ) :
    ZeroRandStmt (managedNodeDeleteCfgsStmt ops specs cap_hist K_seg
      wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr) := by
  unfold managedNodeDeleteCfgsStmt
  exact .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.ite (zeroRand_seqFinCfgStmt N_cfg _ (fun i =>
            .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
            (.seq (.writeWordHeap _ _ _)
                  (ops.zeroRand_deleteStmt _ _ _ _ _ _ _ _ _)))))
          .skip))

theorem exec_managedNodeDeleteCfgsStmt
    {d TW BW TR BR n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (hM₀ : 1 ≤ M₀) (hn : 2 ≤ n) (hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (inp : ArithRAMInput d) {m4 : ArithRAMMemory}
    (wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr nodeBaseW nodeBaseR nodeSeedOff : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg}
    {p : ℕ} (hp_mem : p ∈ mn.nd.curSet) (hp_lt : p < n)
    (hS_lt : ∀ x ∈ mn.nd.curSet, x < n)
    (hS_card : mn.nd.curSet.card ≤ n)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    {bound : ℕ} (ht_bnd : mn.nd.maxTIns bound) (ht_cap : bound + 1 < 2 ^ L_p2)
    (hwf_mn : ManagedNodeWF hM₀ T_cdf p_coord params specs τ_d cap_u pts mn)
    (hfp4 : InFootprint TW BW TR BR m4)
    (htbls : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ nodeBaseW ∧
      nodeBaseW + managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride ≤ (BW : ℤ))
    (hbaseR : 0 ≤ nodeBaseR ∧
      nodeBaseR + managedNodeRStride d K_seg N_cfg ops.cfgRStride ≤ (BR : ℤ))
    (hseedB : 0 ≤ nodeSeedOff ∧
      nodeSeedOff + (nodeOpSeedBits N_cfg L_p2 R ℓ M₀ d b : ℤ) ≤ (BW : ℤ))
    (hptsB : ((n * d : ℕ) : ℤ) ≤ (BR : ℤ))
    (hwBW : 0 ≤ wNodeBaseW ∧ wNodeBaseW < wScr)
    (hwBR : 0 ≤ wNodeBaseR ∧ wNodeBaseR < wScr)
    (hwUid : 0 ≤ wUid ∧ wUid < wScr)
    (hwSO : 0 ≤ wNodeSeedOff ∧ wNodeSeedOff < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + managedNodeMatWScr ops ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + managedNodeMatRScr ops ≤ (BR : ℤ))
    (hbW4 : H3a.wRead m4 scrW wNodeBaseW = nodeBaseW)
    (hbR4 : H3a.wRead m4 scrW wNodeBaseR = nodeBaseR)
    (huid4 : H3a.wRead m4 scrW wUid = (p : ℤ))
    (hseed_reg4 : H3a.wRead m4 scrW wNodeSeedOff = nodeSeedOff)
    (ho4 : ∀ c : Fin d, H3a.rRead m4 tblR (nodeCenterROff nodeBaseR + (c.val : ℤ)) = euclideanCoord mn.nd.o c)
    (hV4 : H3a.rRead m4 tblR (nodeVarROff d nodeBaseR) = mn.nd.V)
    (hpts4 : ∀ x ∈ mn.nd.curSet, ∀ c : Fin d,
      H3a.rRead m4 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hseed_enc4 : EncNodeOpSeedSlice coinTbl nodeSeedOff ω m4)
    (hcfgs4 : ∀ i : Fin N_cfg,
      ops.EncCfg (specs i)
        (nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val)
        (nodeCfgROff d K_seg ops.cfgRStride nodeBaseR i.val)
        pts mn.nd.o mn.nd.V (nodeCfgSet mn.nd) (mn.nd.cfgs i) m4) :
    let mn' := mn.deleteMat hM₀ T_cdf p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω
    ∃ m6 : ArithRAMMemory,
      DetExec inp (managedNodeDeleteCfgsStmt ops specs cap_hist K_seg
        wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr)
        m4 m6 (50 + N_cfg * (ops.deleteCost + 60)) ∧
      InFootprint TW BW TR BR m6 ∧
      (∀ j : ℤ, j < nodeCfgsWBase n cap_hist K_seg nodeBaseW → H3a.wRead m6 tblW j = H3a.wRead m4 tblW j) ∧
      (∀ j : ℤ, j < nodeCfgsRBase d K_seg nodeBaseR → H3a.rRead m6 tblR j = H3a.rRead m4 tblR j) ∧
      (∀ i : Fin N_cfg,
        ops.EncCfg (specs i)
          (nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val)
          (nodeCfgROff d K_seg ops.cfgRStride nodeBaseR i.val)
          pts mn'.nd.o mn'.nd.V (nodeCfgSet mn'.nd) (mn'.nd.cfgs i) m6) ∧
      (∀ w, w < wScr → H3a.wRead m6 scrW w = H3a.wRead m4 scrW w) ∧
      RadFrameOutside scrW scrR tblW nodeBaseW
        (managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride)
        tblR nodeBaseR (managedNodeRStride d K_seg N_cfg ops.cfgRStride) m4 m6 := by
  intro mn'
  have hcfgW := ops.hcfgW_nonneg
  have hcfgR := ops.hcfgR_nonneg
  have hw_op := ops.hopWScr_pos
  have hr_op := ops.hopRScr_pos
  have hrad4 := radTreeWStride_ge_four K_seg
  have hradR := radTreeRStride_nonneg K_seg
  let W_tot := managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride
  let R_tot := managedNodeRStride d K_seg N_cfg ops.cfgRStride
  unfold managedNodeMatWScr at hwScr
  unfold managedNodeMatRScr at hrScr
  have hneW := htbls.2.2.2.2.2.2.1
  have hneCoinScr := htbls.2.2.2.2.2.2.2.1
  have hneCoinW := htbls.2.2.2.2.2.2.2.2.1
  have hneR := htbls.2.2.2.2.2.2.2.2.2.1
  have hne1Scr := htbls.2.2.2.2.2.2.2.2.2.2.1
  have hne1R := htbls.2.2.2.2.2.2.2.2.2.2.2
  let histOffVal : ℤ := 8 + 2 * swapPoolStride n
  let radWOffVal : ℤ := histOffVal + (1 + (cap_hist : ℤ))
  let radROffVal : ℤ := (d : ℤ) + 2
  let cfgsWOffVal : ℤ := radWOffVal + radTreeWStride K_seg
  let cfgsROffVal : ℤ := radROffVal + radTreeRStride K_seg
  let B_cfg : ℤ := (cfgSeedBits L_p2 R ℓ M₀ d b : ℤ)
  let m5a := H3a.wWrite m4 scrW (wScr + 2) nodeBaseR
  let m5b := H3a.wWrite m5a scrW (wScr + 3) (nodeVarROff d nodeBaseR)
  have hd5a : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2)) (.readHeap scrW (.lit wNodeBaseR))) m4 m5a 15 :=
    DetExecAt.writeWordHeap 0 inp m4 scrW _ _ rfl hbR4
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp5a : InFootprint TW BW TR BR m5a := InFootprint.wWrite hfp4 htbls.1 (by omega) (by omega)
  have hd5b : DetExec inp (.writeWordHeap scrW (.lit (wScr + 3))
      (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit ((d : ℤ) + 1)))) m5a m5b 15 :=
    DetExecAt.writeWordHeap 0 inp m5a scrW _ _ rfl
      (by change H3a.wRead m5a scrW wNodeBaseR + ((d : ℤ) + 1) = nodeVarROff d nodeBaseR
          dsimp [m5a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR4]
          unfold nodeVarROff; ring)
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp5b : InFootprint TW BW TR BR m5b := InFootprint.wWrite hfp5a htbls.1 (by omega) (by omega)
  have hfr4_5b : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m4 m5b :=
    (radFrame_wWrite_scr scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m4 _ _).trans
      (radFrame_wWrite_scr scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m5a _ _)
  have hV_5b : H3a.rRead m5b tblR (nodeVarROff d nodeBaseR) = mn.nd.V := hV4
  have hcur' : mn'.nd.curSet = mn.nd.curSet.erase p :=
    (denseDelete_spec hwf_mn.1.1).2
  have hV_eq' : mn'.nd.V = mn.nd.V := rfl
  let cfgStepStmt : Fin N_cfg → ArithRAMStmt := fun i =>
    .seq (.writeWordHeap scrW (.lit (wScr + 6))
            (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride))))
    (.seq (.writeWordHeap scrW (.lit (wScr + 7))
            (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit (cfgsROffVal + (i.val : ℤ) * ops.cfgRStride))))
    (.seq (.writeWordHeap scrW (.lit (wScr + 8))
            (.add (.readHeap scrW (.lit wNodeSeedOff)) (.lit ((i.val : ℤ) * B_cfg))))
          (ops.deleteStmt (specs i)
            (wScr + 6) (wScr + 7) (wScr + 2) (wScr + 3) wUid (wScr + 8) (wScr + 10) rScr)))
  have hcfgs_step : ∃ m6 : ArithRAMMemory,
      DetExec inp (.ite (.realLt (.ofInt (.lit 0)) (.readRealHeap tblR (.readHeap scrW (.lit (wScr + 3)))))
        (seqFinCfgStmt N_cfg cfgStepStmt)
        .skip) m5b m6 (20 + N_cfg * (ops.deleteCost + 60)) ∧
      InFootprint TW BW TR BR m6 ∧
      (∀ j : ℤ, j < nodeCfgsWBase n cap_hist K_seg nodeBaseW → H3a.wRead m6 tblW j = H3a.wRead m5b tblW j) ∧
      (∀ j : ℤ, j < nodeCfgsRBase d K_seg nodeBaseR → H3a.rRead m6 tblR j = H3a.rRead m5b tblR j) ∧
      (∀ i : Fin N_cfg,
        ops.EncCfg (specs i)
          (nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val)
          (nodeCfgROff d K_seg ops.cfgRStride nodeBaseR i.val)
          pts mn'.nd.o mn'.nd.V (nodeCfgSet mn'.nd) (mn'.nd.cfgs i) m6) ∧
      (∀ w, w < wScr → H3a.wRead m6 scrW w = H3a.wRead m5b scrW w) ∧
      RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m5b m6 := by
    by_cases hV_pos : 0 < mn.nd.V
    · have hc_t : cValAt 0 inp m5b
          (.realLt (.ofInt (.lit 0)) (.readRealHeap tblR (.readHeap scrW (.lit (wScr + 3))))) = true := by
        have hw3 : H3a.wRead m5b scrW (wScr + 3) = nodeVarROff d nodeBaseR := wRead_wWrite_self _ _ _ _
        simp only [cValAt, evalArithCond, evalRealExpr, evalIntExpr, Int.cast_zero, decide_eq_true_eq]
        change (0 : ℝ) < H3a.rRead m5b tblR (H3a.wRead m5b scrW (wScr + 3))
        rw [hw3, hV_5b]; exact hV_pos
      let CfgInv : ℕ → ArithRAMMemory → Prop := fun k m =>
        (∀ j : ℤ, j < nodeCfgsWBase n cap_hist K_seg nodeBaseW → H3a.wRead m tblW j = H3a.wRead m5b tblW j) ∧
        (∀ j : ℤ, j < nodeCfgsRBase d K_seg nodeBaseR → H3a.rRead m tblR j = H3a.rRead m5b tblR j) ∧
        (∀ idx : Fin N_cfg, idx.val < k →
          ops.EncCfg (specs idx)
            (nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW idx.val)
            (nodeCfgROff d K_seg ops.cfgRStride nodeBaseR idx.val)
            pts mn.nd.o mn.nd.V (mn.nd.curSet.erase p)
            ((mn.nd.cfgs idx).deleteOriginal hM₀ T_cdf p_coord M_lat params (specs idx).A (specs idx).B
              τ_d τ_q cap_u cap_q pts mn.nd.o mn.nd.V (specs idx).cfg p
              (fun s => ω (idx, false, s)) (fun s => ω (idx, true, s))) m) ∧
        (∀ idx : Fin N_cfg, k ≤ idx.val →
          ops.EncCfg (specs idx)
            (nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW idx.val)
            (nodeCfgROff d K_seg ops.cfgRStride nodeBaseR idx.val)
            pts mn.nd.o mn.nd.V mn.nd.curSet (mn.nd.cfgs idx) m)
      have hInv0 : CfgInv 0 m5b := by
        refine ⟨fun _ _ => rfl, fun _ _ => rfl, fun _ h => absurd h (Nat.not_lt_zero _), fun idx _ => ?_⟩
        have hc0 := hcfgs4 idx
        have hcs_eq : nodeCfgSet mn.nd = mn.nd.curSet := by unfold nodeCfgSet; simp [hV_pos]
        rw [hcs_eq] at hc0
        exact ops.encCfg_mono_slice (specs idx) _ _ pts mn.nd.o mn.nd.V mn.nd.curSet (mn.nd.cfgs idx) m4 m5b hc0
          (fun _ _ _ => by dsimp [m5b, m5a]; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
          (fun _ _ _ => rfl)
          (fun _ _ _ _ => rfl)
      obtain ⟨m6, hd_loop, hfp6, ⟨hpW6, hpR6, henc_done, _⟩, hw_loop, hfr_loop⟩ :=
        exec_seqFinCfgStmt (scrW := scrW) (scrR := scrR) (tblW := tblW) (tblR := tblR) (N_cfg := N_cfg)
          inp cfgStepStmt CfgInv (wScr + 4) nodeBaseW W_tot nodeBaseR R_tot (ops.deleteCost + 60)
          hfp5b hInv0
          (fun i m hfpm hInvm hwm hfrm => by
            rcases hInvm with ⟨hpWm, hpRm, hlt_m, hge_m⟩
            let cBW := nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val
            let cBR := nodeCfgROff d K_seg ops.cfgRStride nodeBaseR i.val
            let sOff := nodeSeedOff + (i.val : ℤ) * B_cfg
            have hbW_m : H3a.wRead m scrW wNodeBaseW = nodeBaseW := by
              rw [hwm wNodeBaseW (by omega)]; dsimp [m5b, m5a]
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbW4]
            have hbR_m : H3a.wRead m scrW wNodeBaseR = nodeBaseR := by
              rw [hwm wNodeBaseR (by omega)]; dsimp [m5b, m5a]
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR4]
            have hso_m : H3a.wRead m scrW wNodeSeedOff = nodeSeedOff := by
              rw [hwm wNodeSeedOff (by omega)]; dsimp [m5b, m5a]
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hseed_reg4]
            have hcBW_eq : nodeBaseW + (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride) = cBW := by
              dsimp [cBW, cfgsWOffVal, radWOffVal, histOffVal]
              unfold nodeCfgWOff nodeCfgsWBase nodeRadTreeWOff nodeHistOff; ring
            have hcBR_eq : nodeBaseR + (cfgsROffVal + (i.val : ℤ) * ops.cfgRStride) = cBR := by
              dsimp [cBR, cfgsROffVal, radROffVal]
              unfold nodeCfgROff nodeCfgsRBase nodeRadTreeROff; ring
            let ma := H3a.wWrite m scrW (wScr + 6) cBW
            let mb := H3a.wWrite ma scrW (wScr + 7) cBR
            let mc := H3a.wWrite mb scrW (wScr + 8) sOff
            have hda : DetExec inp (.writeWordHeap scrW (.lit (wScr + 6))
                (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride)))) m ma 20 :=
              DetExecAt.writeWordHeap 0 inp m scrW _ _ rfl
                (by change H3a.wRead m scrW wNodeBaseW + _ = cBW; rw [hbW_m, hcBW_eq])
                (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hfpa : InFootprint TW BW TR BR ma := InFootprint.wWrite hfpm htbls.1 (by omega) (by omega)
            have hdb : DetExec inp (.writeWordHeap scrW (.lit (wScr + 7))
                (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit (cfgsROffVal + (i.val : ℤ) * ops.cfgRStride)))) ma mb 20 :=
              DetExecAt.writeWordHeap 0 inp ma scrW _ _ rfl
                (by change H3a.wRead ma scrW wNodeBaseR + _ = cBR
                    dsimp [ma]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR_m, hcBR_eq])
                (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hfpb : InFootprint TW BW TR BR mb := InFootprint.wWrite hfpa htbls.1 (by omega) (by omega)
            have hdc : DetExec inp (.writeWordHeap scrW (.lit (wScr + 8))
                (.add (.readHeap scrW (.lit wNodeSeedOff)) (.lit ((i.val : ℤ) * B_cfg)))) mb mc 20 :=
              DetExecAt.writeWordHeap 0 inp mb scrW _ _ rfl
                (by change H3a.wRead mb scrW wNodeSeedOff + _ = sOff
                    dsimp [mb, ma]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hso_m])
                (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hfpc : InFootprint TW BW TR BR mc := InFootprint.wWrite hfpb htbls.1 (by omega) (by omega)
            have hbndW := nodeCfgWOff_bounds n cap_hist K_seg hcfgW nodeBaseW i
            have hbndR := nodeCfgROff_bounds d K_seg hcfgR nodeBaseR i
            have hloW : nodeBaseW ≤ nodeCfgsWBase n cap_hist K_seg nodeBaseW := by
              unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride; omega
            have hloR : nodeBaseR + (d : ℤ) + 2 ≤ nodeCfgsRBase d K_seg nodeBaseR := by
              unfold nodeCfgsRBase nodeRadTreeROff; omega
            have hs_bnd : 0 ≤ sOff ∧ sOff + B_cfg ≤ (BW : ℤ) := by
              have h0_B : 0 ≤ B_cfg := Nat.cast_nonneg _
              have h1 : 0 ≤ (i.val : ℤ) * B_cfg := mul_nonneg (Nat.cast_nonneg _) h0_B
              have h2 : ((i.val + 1 : ℕ) : ℤ) * B_cfg ≤ (N_cfg : ℤ) * B_cfg :=
                mul_le_mul_of_nonneg_right (by exact_mod_cast i.isLt) h0_B
              have h3 : (i.val : ℤ) * B_cfg + B_cfg = ((i.val + 1 : ℕ) : ℤ) * B_cfg := by push_cast; ring
              have htot : (nodeOpSeedBits N_cfg L_p2 R ℓ M₀ d b : ℤ) = (N_cfg : ℤ) * B_cfg := by
                dsimp [B_cfg]; unfold nodeOpSeedBits; push_cast; rfl
              dsimp [sOff]; omega
            rcases ht_bnd hV_pos i with ⟨htL_i, htR_i⟩
            have hfr4_mc : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m4 mc :=
              hfr4_5b.trans (hfrm.trans
                ((radFrame_wWrite_scr scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m (wScr + 6) cBW).trans
                  ((radFrame_wWrite_scr scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot ma (wScr + 7) cBR).trans
                    (radFrame_wWrite_scr scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot mb (wScr + 8) sOff))))
            have henc_mc : ops.EncCfg (specs i) cBW cBR pts mn.nd.o mn.nd.V mn.nd.curSet (mn.nd.cfgs i) mc :=
              ops.encCfg_mono_slice (specs i) cBW cBR pts mn.nd.o mn.nd.V mn.nd.curSet (mn.nd.cfgs i) m mc (hge_m i le_rfl)
                (fun _ _ _ => by dsimp [mc, mb, ma]; repeat rw [wRead_wWrite_of_ne _ _ (Or.inl hneW)])
                (fun _ _ _ => rfl)
                (fun _ _ _ _ => rfl)
            obtain ⟨md, hdd, hfpd, henc_d, hw_d, hfr_d⟩ :=
              ops.exec_deleteStmt inp hM₀ hn hL_p2 (specs i)
                (wScr + 6) (wScr + 7) (wScr + 2) (wScr + 3) wUid (wScr + 8) (wScr + 10) rScr
                cBW cBR nodeBaseR (nodeVarROff d nodeBaseR) sOff hV_pos hp_mem hp_lt hS_lt hS_card
                (fun s => ω (i, false, s)) (fun s => ω (i, true, s))
                (by omega) (by omega) (hwf_mn.1.2.2 hV_pos i)
                hfpc htbls
                ⟨by dsimp [cBW]; omega, by dsimp [cBW]; omega⟩
                ⟨by dsimp [cBR]; omega, by dsimp [cBR]; omega⟩
                ⟨hbaseR.1, by dsimp [cBR]; omega⟩
                ⟨by unfold nodeVarROff; omega, by unfold nodeVarROff; dsimp [cBR]; omega⟩
                hs_bnd hptsB
                ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
                ⟨by omega, by omega⟩ ⟨hwUid.1, by omega⟩ ⟨by omega, by omega⟩
                ⟨by omega, by omega⟩ ⟨hrScr.1, by omega⟩
                (by dsimp [mc, mb, ma]
                    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
                (by dsimp [mc, mb]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
                (by dsimp [mc, mb, ma]
                    repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                    rw [hwm (wScr + 2) (by omega)]; dsimp [m5b, m5a]
                    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
                (by dsimp [mc, mb, ma]
                    repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                    rw [hwm (wScr + 3) (by omega)]; dsimp [m5b]; exact wRead_wWrite_self _ _ _ _)
                (by dsimp [mc, mb, ma]
                    repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                    rw [hwm wUid (by omega)]; dsimp [m5b, m5a]
                    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), huid4])
                (wRead_wWrite_self _ _ _ _)
                (fun c =>
                  (hpRm _ (by have := c.isLt; unfold nodeCfgsRBase nodeRadTreeROff; omega)).trans (ho4 c))
                ((hpRm _ (by unfold nodeVarROff nodeCfgsRBase nodeRadTreeROff; omega)).trans hV4)
                (fun x hx c => by
                  rw [hfr4_mc.2 1 _ hne1Scr (Or.inl hne1R)]; exact hpts4 x hx c)
                (EncCfgSeedSlice.mono_coinTbl (hseed_enc4 i)
                  (fun idx_c => hfr4_mc.1 coinTbl idx_c hneCoinScr (Or.inl hneCoinW)))
                henc_mc
            have hfr_m_md : RadFrameOutside scrW scrR tblW cBW ops.cfgWStride tblR cBR ops.cfgRStride m md :=
              ⟨fun t j hts ho => (hfr_d.1 t j hts ho).trans
                (by dsimp [mc, mb, ma]; repeat rw [wRead_wWrite_of_ne _ _ (Or.inl hts)]),
               fun t j hts ho => hfr_d.2 t j hts ho⟩
            refine ⟨md, (DetExecAt.seq hda (DetExecAt.seq hdb (DetExecAt.seq hdc hdd))).mono_cost (by omega), hfpd,
              ⟨fun j hj => (hfr_m_md.1 tblW j hneW (Or.inr (Or.inl (by dsimp [cBW]; omega)))).trans (hpWm j hj),
               fun j hj => (hfr_m_md.2 tblR j hneR (Or.inr (Or.inl (by dsimp [cBR]; omega)))).trans (hpRm j hj),
               fun idx hidx => ?_,
               fun idx hidx => ?_⟩,
              fun w hw => (hw_d w (by omega)).trans
                (by dsimp [mc, mb, ma]; repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
              RadFrameOutside_mono_range hfr_m_md
                (Or.inr ⟨by dsimp [cBW]; omega, by dsimp [cBW]; omega⟩)
                (Or.inr ⟨by dsimp [cBR]; omega, by dsimp [cBR]; omega⟩)⟩
            · rcases Nat.lt_succ_iff_lt_or_eq.mp hidx with hlt | heq
              · have hne_idx : idx ≠ i := fun he => by subst he; omega
                exact ops.encCfg_mono_slice (specs idx) _ _ pts mn.nd.o mn.nd.V _ _ m md (hlt_m idx hlt)
                  (fun j hj1 hj2 => hfr_m_md.1 tblW j hneW (Or.inr (cfgDisjW hcfgW nodeBaseW hne_idx j hj1 hj2)))
                  (fun j hj1 hj2 => hfr_m_md.2 tblR j hneR (Or.inr (cfgDisjR hcfgR nodeBaseR hne_idx j hj1 hj2)))
                  (fun _ _ _ _ => hfr_m_md.2 1 _ hne1Scr (Or.inl hne1R))
              · have hidx_eq : idx = i := Fin.ext heq
                subst hidx_eq; exact henc_d
            · have hne_idx : idx ≠ i := fun he => by subst he; omega
              exact ops.encCfg_mono_slice (specs idx) _ _ pts mn.nd.o mn.nd.V _ _ m md (hge_m idx (by omega))
                (fun j hj1 hj2 => hfr_m_md.1 tblW j hneW (Or.inr (cfgDisjW hcfgW nodeBaseW hne_idx j hj1 hj2)))
                (fun j hj1 hj2 => hfr_m_md.2 tblR j hneR (Or.inr (cfgDisjR hcfgR nodeBaseR hne_idx j hj1 hj2)))
                (fun _ _ _ _ => hfr_m_md.2 1 _ hne1Scr (Or.inl hne1R)))
      refine ⟨m6,
        (DetExecAt.ite_true hc_t (C_c := 15) (C_b := 1 + N_cfg * (ops.deleteCost + 60))
          (by dsimp [H3a.condExprOps, H3a.realExprOps, H3a.intExprOps,
                UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps,
                UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          hd_loop).mono_cost (by omega),
        hfp6, hpW6, hpR6, fun i => ?_, fun w hw => hw_loop w (by omega), hfr_loop⟩
      have hcs' : nodeCfgSet mn'.nd = mn.nd.curSet.erase p := by
        unfold nodeCfgSet; rw [hV_eq', hcur']; simp [hV_pos]
      have hcf_i : mn'.nd.cfgs i = (mn.nd.cfgs i).deleteOriginal hM₀ T_cdf p_coord M_lat params
          (specs i).A (specs i).B τ_d τ_q cap_u cap_q pts mn.nd.o mn.nd.V (specs i).cfg p
          (fun s => ω (i, false, s)) (fun s => ω (i, true, s)) := by
        dsimp [mn', ManagedNode.deleteMat, NodeInst.deleteMat]; simp [hV_pos]
      have ho_eq : mn'.nd.o = mn.nd.o := rfl
      rw [ho_eq, hV_eq', hcs', hcf_i]
      exact henc_done i i.isLt
    · have hc_f : cValAt 0 inp m5b
          (.realLt (.ofInt (.lit 0)) (.readRealHeap tblR (.readHeap scrW (.lit (wScr + 3))))) = false := by
        have hw3 : H3a.wRead m5b scrW (wScr + 3) = nodeVarROff d nodeBaseR := wRead_wWrite_self _ _ _ _
        simp only [cValAt, evalArithCond, evalRealExpr, evalIntExpr, Int.cast_zero, decide_eq_false_iff_not]
        change ¬ ((0 : ℝ) < H3a.rRead m5b tblR (H3a.wRead m5b scrW (wScr + 3)))
        rw [hw3, hV_5b]; exact hV_pos
      refine ⟨m5b,
        (DetExecAt.ite_false hc_f (C_c := 15) (C_b := 1)
          (by dsimp [H3a.condExprOps, H3a.realExprOps, H3a.intExprOps,
                UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps,
                UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (DetExecAt.skip 0 inp m5b)).mono_cost (by omega),
        hfp5b, fun _ _ => rfl, fun _ _ => rfl, fun i => ?_, fun _ _ => rfl,
        RadFrameOutside.refl _ _ _ _ _ _ _ _ m5b⟩
      have hcs0 : nodeCfgSet mn.nd = ∅ := by unfold nodeCfgSet; simp [hV_pos]
      have hcs' : nodeCfgSet mn'.nd = ∅ := by unfold nodeCfgSet; rw [hV_eq']; simp [hV_pos]
      have hcf_i : mn'.nd.cfgs i = mn.nd.cfgs i := by
        dsimp [mn', ManagedNode.deleteMat, NodeInst.deleteMat]; simp [hV_pos]
      have ho_eq : mn'.nd.o = mn.nd.o := rfl
      rw [ho_eq, hV_eq', hcs', hcf_i]
      have hc0 := hcfgs4 i; rw [hcs0] at hc0
      exact ops.encCfg_mono_slice (specs i) _ _ pts mn.nd.o mn.nd.V ∅ (mn.nd.cfgs i) m4 m5b hc0
        (fun _ _ _ => by dsimp [m5b, m5a]; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
        (fun _ _ _ => rfl)
        (fun _ hx => absurd hx (Finset.notMem_empty _))
  rcases hcfgs_step with ⟨m6, hd6, hfp6, hpW6, hpR6, hcfgs6, hw6, hfr6⟩
  refine ⟨m6,
    (DetExecAt.seq hd5a (DetExecAt.seq hd5b hd6)).mono_cost (by omega),
    hfp6,
    fun j hj => (hpW6 j hj).trans (by dsimp [m5b, m5a]; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]),
    fun j hj => hpR6 j hj,
    hcfgs6,
    fun w hw => (hw6 w hw).trans (by dsimp [m5b, m5a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
    hfr4_5b.trans hfr6⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
