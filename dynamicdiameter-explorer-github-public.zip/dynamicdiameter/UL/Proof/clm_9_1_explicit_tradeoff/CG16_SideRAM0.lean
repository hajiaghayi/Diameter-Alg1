import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideA
import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideB
import UL.Proof.clm_9_1_explicit_tradeoff.CG02_SideQuery
import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchA0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot slotWStride slotRStride slotWStride_ge_four
  seedCoordCount seedBitCount capCoordIdx capCoordIdx_lt slotRStride_gt_coord
  slotBktOff_bounds slotNodeOff_bounds slotInsWStride slotInsRStride slotQryWStride slotQryRStride
  evalWStride evalCopyTuplesCost liveSlotQueryStepCost liveSlotQueryCopyCost liveSlotQueryCost)

/-! ### 1. Real-Slice-Agnostic `dyadicSideZeroInitStmt` Execution (`O(L_p2)`) -/

noncomputable def zeroWordWithCaps (R ℓ M₀ d : ℕ)
    (m : ArithRAMMemory) (tblR : ℕ) (baseR : ℤ) : LiveSlot R ℓ M₀ d :=
  { (LiveSlot.zeroMem R ℓ M₀ d) with
    caps := fun p =>
      (WithLp.equiv 2 (Fin (d + 1) → ℝ)).symm
        (fun j => rRead m tblR (baseR + (capCoordIdx p.1 p.2.1 p.2.2 j : ℤ))) }

lemma LiveSlotTrackedH4.of_zeroWordWithCaps {R ℓ M₀ d : ℕ} (cap_u B_max : ℕ)
    (entryAlive : ℕ → Bool) (hSlot : H4a1.PureFilterSlot R ℓ M₀ d)
    (m : ArithRAMMemory) (tblR : ℕ) (baseR : ℤ) :
    LiveSlotTrackedH4 cap_u B_max 0 entryAlive hSlot (zeroWordWithCaps R ℓ M₀ d m tblR baseR) := by
  refine ⟨fun _ => ⟨rfl, ?_⟩,
          fun h0 => False.elim (by dsimp [zeroWordWithCaps, LiveSlot.zeroMem] at h0; omega)⟩
  rcases LiveSlot.wf_zeroMem (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d) cap_u B_max entryAlive with
    ⟨hbc, _, ndL, hinv, hrc⟩
  exact ⟨hbc, rfl, ndL, hinv, hrc⟩

theorem exec_liveSlotZeroInitStmt_anyR {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW baseW baseR : ℤ) (R ℓ M₀ cap_u B_max : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htblW : tblW < TW) (hneW : tblW ≠ scrW)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hbW : wRead m₀ scrW wBaseW = baseW)
    (hzeroW : ∀ i, baseW ≤ i → i < baseW + slotWStride R ℓ M₀ cap_u B_max → wRead m₀ tblW i = 0) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (RacerP43.liveSlotZeroInitStmt scrW tblW wBaseW) m₀ m₁ 60 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max
        (zeroWordWithCaps R ℓ M₀ d m₀ tblR baseR) m₁ ∧
      (∀ w, wRead m₁ scrW w = wRead m₀ scrW w) ∧
      (∀ r, rRead m₁ scrR r = rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m₁ := by
  have hge4 := slotWStride_ge_four R ℓ M₀ cap_u B_max
  let m1 := wWrite m₀ tblW baseW 1
  let m2 := wWrite m1 tblW (baseW + 1) (-1)
  let m3 := wWrite m2 tblW (baseW + 2) 0
  have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wBaseW)) (.lit 1)) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW _ (.lit 1) hbW rfl (by dsimp [intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 1)) (.lit (-1)))
      m1 m2 20 :=
    DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit (-1))
      (by change wRead m1 scrW wBaseW + 1 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 2)) (.lit 0))
      m2 m3 20 :=
    DetExecAt.writeWordHeap 0 inp m2 tblW _ (.lit 0)
      (by change wRead m2 scrW wBaseW + 2 = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ htblW hbaseW.1 (by omega)
  have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 htblW (by omega) (by omega)
  have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 htblW (by omega) (by omega)
  have hfr : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m3 :=
    ((RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m₀ (idx := baseW) 1 le_rfl (by omega)).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m1 (idx := baseW + 1) (-1) (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m2 (idx := baseW + 2) 0 (by omega) (by omega))
  have hk_ge4 : ∀ i, baseW + 4 ≤ i → i < baseW + slotWStride R ℓ M₀ cap_u B_max →
      wRead m3 tblW i = 0 := by
    intro i hlo hhi
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    exact hzeroW i (by omega) hhi
  refine ⟨m3, hd1.seq (hd2.seq hd3), hfp3, ?_, ?_, ?_, hfr⟩
  · refine ⟨?_, ?_, wRead_wWrite_self _ _ _ _, fun r s k j => ?_, fun b hb => ?_, fun n hn => ?_⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
    · rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]; rfl
    · have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hb
      exact ⟨hk_ge4 _ (by omega) (by omega), hk_ge4 _ (by omega) (by omega)⟩
    · have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hn
      have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
      exact ⟨hk_ge4 _ (by omega) (by omega),
             hk_ge4 _ (by omega) (by omega),
             hk_ge4 _ (by omega) (by omega),
             hk_ge4 _ (by omega) (by omega),
             hk_ge4 _ (by omega) (by omega)⟩
  · intro w
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
  · intro r
    rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]

theorem exec_h4_dyadicSideZeroInitStmt_anyR {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wScr sideBaseW sideBaseR : ℤ)
    (n L_p2 R ℓ M₀ b T p_coord cap_u : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htblW : tblW < TW)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ sideBaseW ∧ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 2 ≤ (BW : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + 2 ≤ wSideBaseW)
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hzeroW : ∀ i, sideBaseW ≤ i →
      i < sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u → wRead m₀ tblW i = 0) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (dyadicSideZeroInitStmt scrW tblW wSideBaseW wScr n L_p2 R ℓ M₀ cap_u)
        m₀ m₁ (dyadicSideZeroInitCost L_p2) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u ∅
        (H4b.DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord) m₁ ∧
      (∀ w, (w < wScr ∨ wScr + 2 ≤ w) → wRead m₁ scrW w = wRead m₀ scrW w) ∧
      (∀ r, rRead m₁ scrR r = rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
        tblR sideBaseR 0 m₀ m₁ := by
  have hge2 := dyadicSideWStride_ge_two n L_p2 R ℓ M₀ cap_u
  have hpow_pos : (1 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (@Nat.one_le_two_pow L_p2)
  let hdrEnd := sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  have hhdr_le_stride : hdrEnd ≤ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u := by
    have hh := dyadicSideWStride_ge_hdrEnd n L_p2 R ℓ M₀ cap_u
    dsimp only [hdrEnd]; linarith
  let m1 := wWrite m₀ tblW sideBaseW 1
  let m2 := wWrite m1 tblW (sideBaseW + 1) 0
  let m3 := wWrite m2 scrW wScr 0
  have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wSideBaseW)) (.lit 1)) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW _ (.lit 1) hbW rfl (by dsimp [intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wSideBaseW)) (.lit 1)) (.lit 0))
      m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit 0)
      (by change wRead m1 scrW wSideBaseW + 1 = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.lit 0)) m2 m3 10 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit wScr) (.lit 0) rfl rfl (by dsimp [intExprOps]; omega)
  have hfp3 : InFootprint TW BW TR BR m3 :=
    InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ htblW hbaseW.1 (by omega))
      htblW (by omega) (by omega)) hscrW hwScr.1 (by omega)
  have hfr3 : RadFrameOutside scrW scrR tblW sideBaseW
      (dyadicSideWStride n L_p2 R ℓ M₀ cap_u) tblR sideBaseR 0 m₀ m3 :=
    ((RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m₀ (idx := sideBaseW) 1 le_rfl (by omega)).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m1 (idx := sideBaseW + 1) 0 (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m2 wScr 0)
  let N := 2 * L_p2
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    InFootprint TW BW TR BR m ∧
    wRead m scrW wScr = (k : ℤ) ∧
    wRead m tblW sideBaseW = 1 ∧
    wRead m tblW (sideBaseW + 1) = 0 ∧
    (∀ i, sideBaseW + 2 ≤ i → i < hdrEnd → wRead m tblW i = 0) ∧
    (∀ j, k ≤ j → j < N → ∀ i,
      sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW j ≤ i →
      i < sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW j + slotWStride R ℓ M₀ cap_u (2 ^ L_p2) →
      wRead m tblW i = 0) ∧
    (∀ i : ℤ, rRead m tblR i = rRead m₀ tblR i) ∧
    (∀ j < k,
      EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW j)
        tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR j)
        R ℓ M₀ d cap_u (2 ^ L_p2)
        (zeroWordWithCaps R ℓ M₀ d m₀ tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR j)) m) ∧
    (∀ w, (w < wScr ∨ wScr + 2 ≤ w) → wRead m scrW w = wRead m₀ scrW w) ∧
    (∀ r, rRead m scrR r = rRead m₀ scrR r) ∧
    RadFrameOutside scrW scrR tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
      tblR sideBaseR 0 m₀ m
  have hInv0 : Inv 0 m3 := by
    refine ⟨hfp3, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, ?_, ?_, fun _ h => by omega, ?_, fun _ => rfl, hfr3⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_self]
    · rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_self]
    · intro i hlo hhi
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact hzeroW i (by omega) (by dsimp only [hdrEnd] at hhi; linarith)
    · intro j _ hjN i hlo hhi
      have hbw := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hjN
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact hzeroW i (by omega) (by omega)
    · intro i; simp only [m3, m2, m1, rRead_wWrite]
    · intro w hw
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
  let sStride := slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
  let headerLen : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  let loopBody : ArithRAMStmt :=
    .seq (.writeWordHeap scrW (.lit (wScr + 1))
            (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit headerLen))
                  (.mul (.readHeap scrW (.lit wScr)) (.lit sStride))))
    (.seq (RacerP43.liveSlotZeroInitStmt scrW tblW (wScr + 1))
          (.writeWordHeap scrW (.lit wScr)
            (.add (.readHeap scrW (.lit wScr)) (.lit 1))))
  obtain ⟨m_end, hInvN, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (N : ℤ)) loopBody N 5 115 Inv hInv0 rfl
    (by dsimp [intExprOps]; omega) (fun k hk m hIm => by
      rcases hIm with ⟨hfp_m, hk_r, hep_m, ht_m, hhdr_m, hrem_zero, heqR_m, henc_prev, hkW_m, hkR_m, hfr_m⟩
      let slotBW := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k
      let slotBR := sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k
      have hbw_k := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hk
      have hbW_m : wRead m scrW wSideBaseW = sideBaseW := (hkW_m _ hdisjBW).trans hbW
      let m_a := wWrite m scrW (wScr + 1) slotBW
      have hd_a : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
          (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit headerLen))
                (.mul (.readHeap scrW (.lit wScr)) (.lit sStride)))) m m_a 35 :=
        DetExecAt.writeWordHeap 0 inp m scrW (.lit (wScr + 1)) _ rfl
          (by change (wRead m scrW wSideBaseW + headerLen) + wRead m scrW wScr * sStride = slotBW
              rw [hbW_m, hk_r]
              dsimp only [slotBW, headerLen, sStride]; unfold sideSlotBaseW; ring)
          (by dsimp [intExprOps]; omega)
      have hfp_a : InFootprint TW BW TR BR m_a := InFootprint.wWrite hfp_m hscrW (by omega) (by omega)
      obtain ⟨m_b, hd_b, hfp_b, henc_k_a, hkW_b, hkR_b, hfr_b⟩ :=
        exec_liveSlotZeroInitStmt_anyR (scrR := scrR) (tblR := tblR) inp (wScr + 1) slotBW slotBR R ℓ M₀ cap_u (2 ^ L_p2)
          hfp_a htblW hneW ⟨by omega, by omega⟩ (wRead_wWrite_self _ _ _ _)
          (fun i hlo hhi => by
            rw [wRead_wWrite_of_ne _ _ (Or.inl hneW)]
            exact hrem_zero k le_rfl hk i hlo hhi)
      have hcaps_eq : zeroWordWithCaps R ℓ M₀ d m_a tblR slotBR = zeroWordWithCaps R ℓ M₀ d m₀ tblR slotBR := by
        dsimp only [zeroWordWithCaps]
        congr 1; funext p
        congr 1; funext j
        rw [rRead_wWrite, heqR_m]
      rw [hcaps_eq] at henc_k_a
      let m_c := wWrite m_b scrW wScr ((k + 1 : ℕ) : ℤ)
      have hd_c : DetExec inp (.writeWordHeap scrW (.lit wScr)
          (.add (.readHeap scrW (.lit wScr)) (.lit 1))) m_b m_c 20 :=
        DetExecAt.writeWordHeap 0 inp m_b scrW (.lit wScr) _ rfl
          (by change wRead m_b scrW wScr + 1 = _
              rw [hkW_b wScr, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hk_r]; push_cast; ring)
          (by dsimp [intExprOps]; omega)
      have hfp_c : InFootprint TW BW TR BR m_c := InFootprint.wWrite hfp_b hscrW hwScr.1 (by omega)
      have htblW_keep : ∀ i : ℤ, (i < slotBW ∨ slotBW + sStride ≤ i) → wRead m_c tblW i = wRead m tblW i := by
        intro i hout
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW)]
        exact (hfr_b.1 tblW i hneW (Or.inr hout)).trans (wRead_wWrite_of_ne _ _ (Or.inl hneW))
      have htblR_keep : ∀ i : ℤ, rRead m_c tblR i = rRead m tblR i := by
        intro i
        rw [rRead_wWrite]
        have ho : tblR ≠ tblR ∨ i < slotBR ∨ slotBR + 0 ≤ i := by
          rcases lt_or_ge i slotBR with h | h
          · exact Or.inr (Or.inl h)
          · exact Or.inr (Or.inr (by omega))
        exact (hfr_b.2 tblR i hneR ho).trans (rRead_wWrite _ _ _ _ _ _)
      have hfr_ab : RadFrameOutside scrW scrR tblW slotBW sStride tblR slotBR 0 m m_c :=
        ((RadFrameOutside.wWrite_scr scrW scrR tblW slotBW sStride tblR slotBR 0 m (wScr + 1) slotBW).trans hfr_b).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW slotBW sStride tblR slotBR 0 m_b wScr ((k + 1 : ℕ) : ℤ))
      have hfr_c : RadFrameOutside scrW scrR tblW sideBaseW
          (dyadicSideWStride n L_p2 R ℓ M₀ cap_u) tblR sideBaseR 0 m₀ m_c :=
        hfr_m.trans (hfr_ab.mono_range
          (Or.inr ⟨by dsimp only [slotBW, sStride]; omega, by dsimp only [slotBW, sStride]; omega⟩)
          (Or.inl rfl))
      refine ⟨m_c, (hd_a.seq (hd_b.seq hd_c)).mono_cost (by omega), hfp_c,
        wRead_wWrite_self _ _ _ _,
        (htblW_keep sideBaseW (Or.inl (by dsimp only [slotBW]; omega))).trans hep_m,
        (htblW_keep (sideBaseW + 1) (Or.inl (by dsimp only [slotBW]; omega))).trans ht_m,
        fun i hlo hhi => (htblW_keep i (Or.inl (by dsimp only [hdrEnd] at hhi; have := hbw_k.1; omega))).trans (hhdr_m i hlo hhi),
        fun j hkj hjN i hlo hhi => ?_,
        fun i => (htblR_keep i).trans (heqR_m i),
        fun j hj => ?_,
        fun w hw => ?_,
        fun r => ?_,
        hfr_c⟩
      · have hdisj := sideSlotBaseW_disj (n := n) (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
          sideBaseW (by omega : k ≠ j)
        rcases hdisj with hle | hge
        · exact (htblW_keep i (Or.inr (by dsimp only [slotBW, sStride]; omega))).trans
            (hrem_zero j (by omega) hjN i hlo hhi)
        · have hbw_j := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hjN
          exact (htblW_keep i (Or.inl (by dsimp only [slotBW]; omega))).trans
            (hrem_zero j (by omega) hjN i hlo hhi)
      · by_cases hjk : j = k
        · subst hjk
          exact henc_k_a.mono_frame
            (RadFrameOutside.wWrite_scr scrW scrR tblW slotBW 0 tblR slotBR 0 m_b wScr ((j + 1 : ℕ) : ℤ))
            hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
        · have hj_lt : j < k := by omega
          have hfr_r : RadFrameOutside scrW scrR tblW slotBW sStride
              tblR slotBR (slotRStride R ℓ M₀ d) m m_c :=
            hfr_ab.mono_range (Or.inr ⟨le_rfl, le_rfl⟩)
              (Or.inr ⟨le_rfl, by have := slotRStride_nonneg R ℓ M₀ d; linarith⟩)
          have hdisjW := sideSlotBaseW_disj (n := n) (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
            sideBaseW (ne_of_lt hj_lt)
          have hdisjR := sideSlotBaseR_disj (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
            sideBaseR (ne_of_lt hj_lt)
          exact (henc_prev j hj_lt).mono_frame hfr_r hneW hneR (Or.inr hdisjW) (Or.inr hdisjR)
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hkW_b w,
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hkW_m w hw
      · rw [rRead_wWrite, hkR_b r, rRead_wWrite]
        exact hkR_m r)
  rcases hInvN with ⟨hfp_e, _, hep_e, ht_e, hhdr_e, _, _, henc_e, hkW_e, hkR_e, hfr_e⟩
  refine ⟨m_end, (hd1.seq (hd2.seq (hd3.seq hd_loop))).mono_cost (by unfold dyadicSideZeroInitCost; dsimp only [N]; omega),
    hfp_e, ?_, hkW_e, hkR_e, hfr_e⟩
  refine ⟨Nat.zero_le _, 1,
    fun s sl => zeroWordWithCaps R ℓ M₀ d m₀ tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx s sl)),
    le_rfl, hep_e, ht_e,
    fun _ h => by simp [H4b.DyadicSideIndex.empty] at h,
    fun eid heid => ?_,
    fun _ h => by simp [H4b.DyadicSideIndex.empty] at h,
    fun _ h => by simp at h,
    fun _ h => by simp [H4b.DyadicSideIndex.empty] at h,
    fun s sl => ⟨LiveSlotTrackedH4.of_zeroWordWithCaps cap_u (2 ^ L_p2) (fun _ => false) _ m₀ tblR _,
      henc_e (sideSlotIdx s sl) (sideSlotIdx_lt s sl)⟩,
    fun s => by
      have hq0 : (H4b.DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord).t_ins / (2 * 2 ^ s.val) = 0 :=
        Nat.zero_div _
      dsimp only; rw [hq0]
      exact ⟨fun h => by omega, fun h => by omega, fun h => by omega⟩⟩
  have heidZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast heid
  have hzero_al : wRead m_end tblW (sideAliveEpOff L_p2 sideBaseW eid) = 0 :=
    hhdr_e _ (by unfold sideAliveEpOff; omega) (by dsimp only [hdrEnd]; unfold sideAliveEpOff; omega)
  rw [hzero_al]; omega

/-! ### 2. `EncH4DyadicSide.mono_slice_uLt` & Unified Scratch Strides -/

theorem EncH4DyadicSide.mono_slice_uLt {tblW : ℕ} {sideBaseW : ℤ} {tblR : ℕ} {sideBaseR : ℤ}
    {n L_p2 R ℓ M₀ d b cap_u : ℕ} {U : Finset ℕ}
    (hU : ∀ u ∈ U, u < n)
    {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b} {m₀ m₁ : ArithRAMMemory}
    (henc : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀)
    (hkW : ∀ i : ℤ, sideBaseW ≤ i →
      i < sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u →
      wRead m₁ tblW i = wRead m₀ tblW i)
    (hkR : ∀ i : ℤ, sideBaseR ≤ i →
      i < sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d →
      rRead m₁ tblR i = rRead m₀ tblR i) :
    EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₁ := by
  have hpow_pos : (1 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (@Nat.one_le_two_pow L_p2)
  have hge2 := dyadicSideWStride_ge_two n L_p2 R ℓ M₀ cap_u
  have hslot0_ge : 0 ≤ ((2 * L_p2 : ℕ) : ℤ) * slotWStride R ℓ M₀ cap_u (2 ^ L_p2) :=
    mul_nonneg (by positivity) (by have := slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2); omega)
  rcases henc with ⟨ht_le, ep_side, liveSlots, hep1, hep_r, ht_r,
    hhand, hal_le, hal_iff, hact, hpt, hslots, hcur⟩
  refine ⟨ht_le, ep_side, liveSlots, hep1,
    (hkW sideBaseW le_rfl (by omega)).trans hep_r,
    (hkW (sideBaseW + 1) (by omega) (by omega)).trans ht_r,
    fun eid heid => (hkW _ (by unfold sideHandleOff; omega)
      (by unfold sideHandleOff dyadicSideWStride; omega)).trans (hhand eid heid),
    fun eid heid => by
      rw [hkW _ (by unfold sideAliveEpOff; omega) (by unfold sideAliveEpOff dyadicSideWStride; omega)]
      exact hal_le eid heid,
    fun eid heid => by
      rw [hkW _ (by unfold sideAliveEpOff; omega) (by unfold sideAliveEpOff dyadicSideWStride; omega)]
      exact hal_iff eid heid,
    fun u hu => by
      have hn_pos : 1 ≤ n := by have := hU u hu; omega
      have hmod : u % n < n := Nat.mod_lt u hn_pos
      exact (hkW _ (by unfold sideActiveOff; omega)
        (by unfold sideActiveOff dyadicSideWStride; omega)).trans (hact u hu),
    fun eid heid c => by
      have hb := sideEntryPt_bounds (L_p2 := L_p2) sideBaseR (lt_of_lt_of_le heid ht_le) c
      have hre := dyadicSideRStride_ge_entryEnd L_p2 R ℓ M₀ d
      exact (hkR _ (by omega) (by omega)).trans (hpt eid heid c),
    fun s sl => ?_, hcur⟩
  rcases hslots s sl with ⟨htr_s, henc_s⟩
  have hbw := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
    sideBaseW (sideSlotIdx_lt s sl)
  have hbr := sideSlotBaseR_bounds (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
    sideBaseR (sideSlotIdx_lt s sl)
  exact ⟨htr_s, EncLiveSlot.mono_slice henc_s
    (fun i hlo hhi => hkW i (by omega) (by omega))
    (fun i hlo hhi => hkR i (by omega) (by omega))⟩

def sideRAMWScrStride (ℓ M₀ cap_u cap_q : ℕ) : ℤ :=
  max (dyadicSideInsertUidWStride ℓ M₀ cap_u) (dyadicSideQueryUidWStride ℓ M₀ cap_q)

def sideRAMRScrStride (d : ℕ) : ℤ :=
  max (dyadicSideInsertRStride d) (dyadicSideQueryRStride d)

lemma sideRAMWScrStride_ge_48 (ℓ M₀ cap_u cap_q : ℕ) :
    48 ≤ sideRAMWScrStride ℓ M₀ cap_u cap_q := by
  have := dyadicSideQueryUidWStride_ge_48 ℓ M₀ cap_q
  exact le_trans this (le_max_right _ _)

lemma sideRAMWScrStride_pos (ℓ M₀ cap_u cap_q : ℕ) :
    1 ≤ sideRAMWScrStride ℓ M₀ cap_u cap_q := by
  have := sideRAMWScrStride_ge_48 ℓ M₀ cap_u cap_q; omega

lemma sideRAMWScrStride_ge_ins (ℓ M₀ cap_u cap_q : ℕ) :
    dyadicSideInsertUidWStride ℓ M₀ cap_u ≤ sideRAMWScrStride ℓ M₀ cap_u cap_q :=
  le_max_left _ _

lemma sideRAMWScrStride_ge_qry (ℓ M₀ cap_u cap_q : ℕ) :
    dyadicSideQueryUidWStride ℓ M₀ cap_q ≤ sideRAMWScrStride ℓ M₀ cap_u cap_q :=
  le_max_right _ _

lemma sideRAMRScrStride_ge_9 (d : ℕ) :
    9 ≤ sideRAMRScrStride d := by
  have := dyadicSideInsertRStride_ge_9 d
  exact le_trans this (le_max_left _ _)

lemma sideRAMRScrStride_pos (d : ℕ) :
    1 ≤ sideRAMRScrStride d := by
  have := sideRAMRScrStride_ge_9 d; omega

lemma sideRAMRScrStride_ge_ins (d : ℕ) :
    dyadicSideInsertRStride d ≤ sideRAMRScrStride d :=
  le_max_left _ _

lemma sideRAMRScrStride_ge_qry (d : ℕ) :
    dyadicSideQueryRStride d ≤ sideRAMRScrStride d :=
  le_max_right _ _

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
