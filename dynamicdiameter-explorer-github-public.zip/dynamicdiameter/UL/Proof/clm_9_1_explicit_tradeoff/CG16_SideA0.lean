import UL.Proof.clm_9_1_explicit_tradeoff.H4b_DyadicMatching
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3c_ChainEngine
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3c2d_SlotOps
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3c2e_SlotQuery

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)

/-! ### 1. Syntactic `ZeroRandStmt` Boolean Reflection Checker -/

def isZeroRandB : ArithRAMStmt → Bool
  | .skip => true
  | .writeWordHeap _ _ _ | .writeWordLocal _ _ _
  | .freeWordHeap _ _ | .freeWordLocal _ _
  | .writeRealHeap _ _ _ | .writeRealLocal _ _ _
  | .freeRealHeap _ _ | .freeRealLocal _ _ => true
  | .randBitHeap _ _ | .randBitLocal _ _ => false
  | .seq s₁ s₂ => isZeroRandB s₁ && isZeroRandB s₂
  | .ite _ t f => isZeroRandB t && isZeroRandB f
  | .whileLoop _ b => isZeroRandB b
  | .repeatN _ b => isZeroRandB b
  | .localScope b => isZeroRandB b

theorem of_isZeroRandB : ∀ {s : ArithRAMStmt}, isZeroRandB s = true → H3a.ZeroRandStmt s
  | .skip, _ => .skip
  | .writeWordHeap t i v, _ => .writeWordHeap t i v
  | .writeWordLocal v i x, _ => .writeWordLocal v i x
  | .freeWordHeap t i, _ => .freeWordHeap t i
  | .freeWordLocal v i, _ => .freeWordLocal v i
  | .writeRealHeap t i v, _ => .writeRealHeap t i v
  | .writeRealLocal v i x, _ => .writeRealLocal v i x
  | .freeRealHeap t i, _ => .freeRealHeap t i
  | .freeRealLocal v i, _ => .freeRealLocal v i
  | .randBitHeap _ _, h => by simp [isZeroRandB] at h
  | .randBitLocal _ _, h => by simp [isZeroRandB] at h
  | .seq s₁ s₂, h => by
      simp only [isZeroRandB, Bool.and_eq_true] at h
      exact .seq (of_isZeroRandB h.1) (of_isZeroRandB h.2)
  | .ite _ t f, h => by
      simp only [isZeroRandB, Bool.and_eq_true] at h
      exact .ite (of_isZeroRandB h.1) (of_isZeroRandB h.2)
  | .whileLoop _ b, h => .whileLoop (of_isZeroRandB h)
  | .repeatN _ b, h => .repeatN (of_isZeroRandB h)
  | .localScope b, h => .localScope (of_isZeroRandB h)

/-! ### 2. Bijection `H4a1.PureFilterSlot ↔ RacerP43.PureFilterSlot` -/

def toP43Slot {R ℓ M₀ d : ℕ} (s : H4a1.PureFilterSlot R ℓ M₀ d) :
    RacerP43.PureFilterSlot R ℓ M₀ d :=
  { caps := s.caps, buckets := s.buckets }

def ofP43Slot {R ℓ M₀ d : ℕ} (s : RacerP43.PureFilterSlot R ℓ M₀ d) :
    H4a1.PureFilterSlot R ℓ M₀ d :=
  { caps := s.caps, buckets := s.buckets }

def pureFilterSlotEquiv (R ℓ M₀ d : ℕ) :
    H4a1.PureFilterSlot R ℓ M₀ d ≃ RacerP43.PureFilterSlot R ℓ M₀ d where
  toFun := toP43Slot
  invFun := ofP43Slot
  left_inv := fun ⟨_, _⟩ => rfl
  right_inv := fun ⟨_, _⟩ => rfl

theorem encodeTuple_p43_eq {M₀ : ℕ} :
    ∀ {ℓ : ℕ} (τ : Fin ℓ → Fin M₀), RacerP43.encodeTuple τ = H4a1.encodeTuple τ
  | 0, _ => rfl
  | ℓ + 1, τ => by
      simp only [RacerP43.encodeTuple, H4a1.encodeTuple,
        encodeTuple_p43_eq (fun j : Fin ℓ => τ j.castSucc)]

theorem mixedTuple_p43_eq {M₀ : ℕ} (hM₀ : 1 ≤ M₀) :
    ∀ {ℓ : ℕ} (cnt : Fin ℓ → ℕ) (elig : Fin ℓ → ℕ → ℕ) (idx : ℕ),
      RacerP43.mixedTuple hM₀ cnt elig idx = H4a1.mixedTuple hM₀ cnt elig idx
  | 0, _, _, _ => funext fun s => Fin.elim0 s
  | ℓ + 1, cnt, elig, idx => by
      funext s
      refine Fin.cases rfl (fun j => ?_) s
      exact congrFun
        (mixedTuple_p43_eq hM₀ (fun j' => cnt j'.succ) (fun j' => elig j'.succ) (idx / cnt 0)) j

@[simp]
theorem toP43Slot_init {R ℓ M₀ d b : ℕ} (T p_coord : ℕ)
    (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b) :
    toP43Slot (H4a1.PureFilterSlot.init T p_coord ω) =
      RacerP43.PureFilterSlot.init T p_coord ω := rfl

theorem toP43Slot_insertPoint {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (A B τ_d : ℚ) (cap_u : ℕ) (o p_pt : EuclideanSpace ℝ (Fin d)) (h : ℕ)
    (slot : H4a1.PureFilterSlot R ℓ M₀ d) :
    toP43Slot (slot.insertPoint hM₀ A B τ_d cap_u o p_pt h) =
      (toP43Slot slot).insertPoint hM₀ A B τ_d cap_u o p_pt h := by
  classical
  simp only [toP43Slot, H4a1.PureFilterSlot.insertPoint, RacerP43.PureFilterSlot.insertPoint,
    encodeTuple_p43_eq]

theorem scanLiveCands_p43_eq {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o p_v : EuclideanSpace ℝ (Fin d)) (b_thr : ℝ) (inU : ℕ → Bool) :
    ∀ (cands : List ℕ) (rem : ℕ),
      RacerP43.scanLiveCands pts o p_v b_thr inU rem cands =
      H4a1.scanLiveCands pts o p_v b_thr inU rem cands
  | [], _ => rfl
  | _ :: _, 0 => rfl
  | c :: tl, rem + 1 => by
      classical
      unfold RacerP43.scanLiveCands H4a1.scanLiveCands
      split_ifs with h1 h2
      · rfl
      · exact scanLiveCands_p43_eq pts o p_v b_thr inU tl rem
      · exact scanLiveCands_p43_eq pts o p_v b_thr inU tl (rem + 1)

theorem scanCopyTuples_p43_eq {R ℓ M₀ d : ℕ}
    (buckets : Fin R → Fin (M₀ ^ ℓ) → List ℕ) (r : Fin R)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (b_thr : ℝ) (inU : ℕ → Bool) :
    ∀ (codes : List (Fin (M₀ ^ ℓ))) (rem : ℕ),
      RacerP43.scanCopyTuples buckets r pts o p_v b_thr inU rem codes =
      H4a1.scanCopyTuples buckets r pts o p_v b_thr inU rem codes
  | [], _ => rfl
  | _ :: _, 0 => rfl
  | code :: rest, rem + 1 => by
      unfold RacerP43.scanCopyTuples H4a1.scanCopyTuples
      rw [scanLiveCands_p43_eq]
      cases H4a1.scanLiveCands pts o p_v b_thr inU (rem + 1) (buckets r code) with
      | mk ans rem' =>
          cases ans with
          | some h => rfl
          | none => exact scanCopyTuples_p43_eq buckets r pts o p_v b_thr inU rest rem'

theorem queryTupleCodeList_p43_eq {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (caps : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)))
    (A B τ_q : ℚ) (cap_q : ℕ) (v_lat : EuclideanSpace ℝ (Fin d)) (r : Fin R) :
    RacerP43.queryTupleCodeList hM₀ caps A B τ_q cap_q v_lat r =
      H4a1.queryTupleCodeList hM₀ caps A B τ_q cap_q v_lat r := by
  classical
  unfold RacerP43.queryTupleCodeList H4a1.queryTupleCodeList
  dsimp only
  split_ifs with hpos
  · refine List.map_congr_left fun idx _ => ?_
    apply Fin.ext
    dsimp only
    rw [mixedTuple_p43_eq, encodeTuple_p43_eq]
  · rfl

theorem toP43Slot_query {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (M_lat : ℕ) (A B τ_q : ℚ) (b_thr : ℝ) (cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (inU : ℕ → Bool) (slot : H4a1.PureFilterSlot R ℓ M₀ d) :
    (toP43Slot slot).query hM₀ M_lat A B τ_q b_thr cap_q pts o p_v inU =
      slot.query hM₀ M_lat A B τ_q b_thr cap_q pts o p_v inU := by
  unfold RacerP43.PureFilterSlot.query H4a1.PureFilterSlot.query
  have hlat : RacerP43.latVec M_lat (‖o - p_v‖⁻¹ • (o - p_v)) =
      H4a1.latVec M_lat (‖o - p_v‖⁻¹ • (o - p_v)) := rfl
  dsimp only [toP43Slot]
  rw [hlat]
  congr 1
  funext r
  rw [queryTupleCodeList_p43_eq, scanCopyTuples_p43_eq]

/-! ### 3. Flattened `(Fin L_p2 × Fin 2)` Slot Indexing & Heap Layout Offsets -/

def sideSlotIdx {L_p2 : ℕ} (s : Fin L_p2) (sl : Fin 2) : ℕ :=
  2 * s.val + sl.val

lemma sideSlotIdx_lt {L_p2 : ℕ} (s : Fin L_p2) (sl : Fin 2) :
    sideSlotIdx s sl < 2 * L_p2 := by
  have hs := s.isLt; have hsl := sl.isLt; unfold sideSlotIdx; omega

lemma sideSlotIdx_inj {L_p2 : ℕ} {s₁ s₂ : Fin L_p2} {sl₁ sl₂ : Fin 2}
    (h : sideSlotIdx s₁ sl₁ = sideSlotIdx s₂ sl₂) : s₁ = s₂ ∧ sl₁ = sl₂ := by
  unfold sideSlotIdx at h
  have hs1 := s₁.isLt; have hs2 := s₂.isLt
  have hsl1 := sl₁.isLt; have hsl2 := sl₂.isLt
  exact ⟨Fin.ext (by omega), Fin.ext (by omega)⟩

def sideSlotScale {L_p2 : ℕ} (k : ℕ) (hk : k < 2 * L_p2) : Fin L_p2 :=
  ⟨k / 2, by omega⟩

def sideSlotBuf (k : ℕ) : Fin 2 :=
  ⟨k % 2, by omega⟩

@[simp] lemma sideSlotIdx_scale_buf {L_p2 : ℕ} (k : ℕ) (hk : k < 2 * L_p2) :
    sideSlotIdx (sideSlotScale k hk) (sideSlotBuf k) = k := by
  unfold sideSlotIdx sideSlotScale sideSlotBuf; dsimp only; omega

@[simp] lemma sideSlotScale_idx {L_p2 : ℕ} (s : Fin L_p2) (sl : Fin 2)
    (hk : sideSlotIdx s sl < 2 * L_p2) :
    sideSlotScale (sideSlotIdx s sl) hk = s := by
  have hsl := sl.isLt
  apply Fin.ext; dsimp [sideSlotScale, sideSlotIdx]; omega

@[simp] lemma sideSlotBuf_idx {L_p2 : ℕ} (s : Fin L_p2) (sl : Fin 2) :
    sideSlotBuf (sideSlotIdx s sl) = sl := by
  have hsl := sl.isLt
  apply Fin.ext; dsimp [sideSlotBuf, sideSlotIdx]; omega

def sideHandleOff (sideBaseW : ℤ) (eid : ℕ) : ℤ :=
  sideBaseW + 2 + (eid : ℤ)

def sideAliveEpOff (L_p2 : ℕ) (sideBaseW : ℤ) (eid : ℕ) : ℤ :=
  sideBaseW + 2 + ((2 ^ L_p2 : ℕ) : ℤ) + (eid : ℤ)

def sideActiveOff (L_p2 : ℕ) (sideBaseW : ℤ) (rem : ℕ) : ℤ :=
  sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (rem : ℤ)

def sideSlotBaseW (n L_p2 R ℓ M₀ cap_u : ℕ) (sideBaseW : ℤ) (k : ℕ) : ℤ :=
  sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ) +
    (k : ℤ) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2)

def dyadicSideWStride (n L_p2 R ℓ M₀ cap_u : ℕ) : ℤ :=
  2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ) +
    ((2 * L_p2 : ℕ) : ℤ) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2)

def sidePvStageOff (sideBaseR : ℤ) : ℤ := sideBaseR

def sideEntryPtOff (d : ℕ) (sideBaseR : ℤ) : ℤ := sideBaseR + (d : ℤ)

def sideSlotBaseR (L_p2 R ℓ M₀ d : ℕ) (sideBaseR : ℤ) (k : ℕ) : ℤ :=
  sideBaseR + (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ) +
    (k : ℤ) * RacerP43.slotRStride R ℓ M₀ d

def dyadicSideRStride (L_p2 R ℓ M₀ d : ℕ) : ℤ :=
  (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ) +
    ((2 * L_p2 : ℕ) : ℤ) * RacerP43.slotRStride R ℓ M₀ d

lemma slotRStride_nonneg (R ℓ M₀ d : ℕ) : 0 ≤ RacerP43.slotRStride R ℓ M₀ d := by
  unfold RacerP43.slotRStride; positivity

lemma dyadicSideWStride_ge_two (n L_p2 R ℓ M₀ cap_u : ℕ) :
    2 ≤ dyadicSideWStride n L_p2 R ℓ M₀ cap_u := by
  have hpow_pos : (1 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (@Nat.one_le_two_pow L_p2)
  have hge4 := RacerP43.slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2)
  have hnonneg : 0 ≤ ((2 * L_p2 : ℕ) : ℤ) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) :=
    mul_nonneg (by positivity) (by omega)
  unfold dyadicSideWStride; omega

lemma dyadicSideRStride_ge_d (L_p2 R ℓ M₀ d : ℕ) :
    (d : ℤ) ≤ dyadicSideRStride L_p2 R ℓ M₀ d := by
  have hr := slotRStride_nonneg R ℓ M₀ d
  have hnonneg : 0 ≤ ((2 * L_p2 : ℕ) : ℤ) * RacerP43.slotRStride R ℓ M₀ d :=
    mul_nonneg (by positivity) hr
  unfold dyadicSideRStride; omega

lemma dyadicSideRStride_ge_entryEnd (L_p2 R ℓ M₀ d : ℕ) :
    (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ) ≤ dyadicSideRStride L_p2 R ℓ M₀ d := by
  have hr := slotRStride_nonneg R ℓ M₀ d
  have hnonneg : 0 ≤ ((2 * L_p2 : ℕ) : ℤ) * RacerP43.slotRStride R ℓ M₀ d :=
    mul_nonneg (by positivity) hr
  unfold dyadicSideRStride; omega

lemma dyadicSideWStride_ge_hdrEnd (n L_p2 R ℓ M₀ cap_u : ℕ) :
    2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ) ≤ dyadicSideWStride n L_p2 R ℓ M₀ cap_u := by
  have hge4 := RacerP43.slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2)
  have hnonneg : 0 ≤ ((2 * L_p2 : ℕ) : ℤ) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) :=
    mul_nonneg (by positivity) (by omega)
  unfold dyadicSideWStride; omega

lemma sideSlotBaseW_bounds {n L_p2 R ℓ M₀ cap_u k : ℕ} (sideBaseW : ℤ) (hk : k < 2 * L_p2) :
    sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ) ≤
      sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k ∧
    sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k +
      RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) ≤
      sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u := by
  have hge4 := RacerP43.slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2)
  have hlo : 0 ≤ (k : ℤ) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) :=
    mul_nonneg (by positivity) (by omega)
  have hhi : ((k : ℤ) + 1) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) ≤
      ((2 * L_p2 : ℕ) : ℤ) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) :=
    mul_le_mul_of_nonneg_right (by omega) (by omega)
  unfold sideSlotBaseW dyadicSideWStride
  constructor <;> linarith

lemma sideSlotBaseW_disj {n L_p2 R ℓ M₀ cap_u k₁ k₂ : ℕ} (sideBaseW : ℤ) (hne : k₁ ≠ k₂) :
    sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k₁ +
      RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) ≤
      sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k₂ ∨
    sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k₂ +
      RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) ≤
      sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k₁ := by
  have hge4 := RacerP43.slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2)
  rcases Nat.lt_or_gt_of_ne hne with hlt | hgt
  · left
    have hm : ((k₁ : ℤ) + 1) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) ≤
        (k₂ : ℤ) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) :=
      mul_le_mul_of_nonneg_right (by omega) (by omega)
    unfold sideSlotBaseW; linarith
  · right
    have hm : ((k₂ : ℤ) + 1) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) ≤
        (k₁ : ℤ) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) :=
      mul_le_mul_of_nonneg_right (by omega) (by omega)
    unfold sideSlotBaseW; linarith

lemma sideSlotBaseR_bounds {L_p2 R ℓ M₀ d k : ℕ} (sideBaseR : ℤ) (hk : k < 2 * L_p2) :
    sideBaseR + (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ) ≤
      sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k ∧
    sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k + RacerP43.slotRStride R ℓ M₀ d ≤
      sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d := by
  have hr := slotRStride_nonneg R ℓ M₀ d
  have hlo : 0 ≤ (k : ℤ) * RacerP43.slotRStride R ℓ M₀ d := mul_nonneg (by positivity) hr
  have hhi : ((k : ℤ) + 1) * RacerP43.slotRStride R ℓ M₀ d ≤
      ((2 * L_p2 : ℕ) : ℤ) * RacerP43.slotRStride R ℓ M₀ d :=
    mul_le_mul_of_nonneg_right (by omega) hr
  unfold sideSlotBaseR dyadicSideRStride
  constructor <;> linarith

lemma sideSlotBaseR_disj {L_p2 R ℓ M₀ d k₁ k₂ : ℕ} (sideBaseR : ℤ) (hne : k₁ ≠ k₂) :
    sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k₁ + RacerP43.slotRStride R ℓ M₀ d ≤
      sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k₂ ∨
    sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k₂ + RacerP43.slotRStride R ℓ M₀ d ≤
      sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k₁ := by
  have hr := slotRStride_nonneg R ℓ M₀ d
  rcases Nat.lt_or_gt_of_ne hne with hlt | hgt
  · left
    have hm : ((k₁ : ℤ) + 1) * RacerP43.slotRStride R ℓ M₀ d ≤
        (k₂ : ℤ) * RacerP43.slotRStride R ℓ M₀ d :=
      mul_le_mul_of_nonneg_right (by omega) hr
    unfold sideSlotBaseR; linarith
  · right
    have hm : ((k₂ : ℤ) + 1) * RacerP43.slotRStride R ℓ M₀ d ≤
        (k₁ : ℤ) * RacerP43.slotRStride R ℓ M₀ d :=
      mul_le_mul_of_nonneg_right (by omega) hr
    unfold sideSlotBaseR; linarith

lemma sideEntryPt_bounds {L_p2 d eid : ℕ} (sideBaseR : ℤ) (heid : eid < 2 ^ L_p2) (c : Fin d) :
    sideBaseR + (d : ℤ) ≤ sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ) ∧
    sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ) <
      sideBaseR + (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ) := by
  have hc := c.isLt
  have hlo : 0 ≤ (eid : ℤ) * (d : ℤ) := mul_nonneg (by positivity) (by positivity)
  have hhi : (eid : ℤ) * (d : ℤ) + (c.val : ℤ) < (((2 ^ L_p2) * d : ℕ) : ℤ) := by
    calc (eid : ℤ) * (d : ℤ) + (c.val : ℤ)
        < (eid : ℤ) * (d : ℤ) + (d : ℤ) := by omega
      _ = ((eid : ℤ) + 1) * (d : ℤ) := by ring
      _ ≤ ((2 ^ L_p2 : ℕ) : ℤ) * (d : ℤ) := mul_le_mul_of_nonneg_right (by omega) (by positivity)
      _ = (((2 ^ L_p2) * d : ℕ) : ℤ) := by push_cast; ring
  unfold sideEntryPtOff; omega

/-! ### 4. `LiveSlotTrackedH4` & `EncH4DyadicSide` Directly on `H4b.DyadicSideIndex` -/

/-- Uniform ring-buffer slot invariant directly relating a RAM `RacerP43.LiveSlot` to an
`H4a1.PureFilterSlot`. When `S.blkId < 0` (cleared / unallocated slot), `S` is a valid empty DLL
independent of `hSlot`; once initialized (`0 ≤ S.blkId`), `S` tracks `toP43Slot hSlot` exactly. -/
def LiveSlotTrackedH4 {R ℓ M₀ d : ℕ} (cap_u B_max t_ins : ℕ)
    (entryAlive : ℕ → Bool) (hSlot : H4a1.PureFilterSlot R ℓ M₀ d)
    (S : RacerP43.LiveSlot R ℓ M₀ d) : Prop :=
  (S.blkId < 0 →
    S.builtCnt = 0 ∧
    S.WF cap_u B_max 0 entryAlive { caps := S.caps, buckets := fun _ _ => [] }) ∧
  (0 ≤ S.blkId →
    S.blkId.toNat + S.builtCnt ≤ t_ins ∧
    (∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ e ∈ hSlot.buckets r c,
      S.blkId.toNat ≤ e ∧ e < S.blkId.toNat + S.builtCnt) ∧
    S.WF cap_u B_max S.blkId.toNat entryAlive (toP43Slot hSlot))

theorem LiveSlotTrackedH4.wf_some {R ℓ M₀ d : ℕ} {cap_u B_max t_ins : ℕ}
    {entryAlive : ℕ → Bool} {hSlot : H4a1.PureFilterSlot R ℓ M₀ d}
    {S : RacerP43.LiveSlot R ℓ M₀ d}
    (htr : LiveSlotTrackedH4 cap_u B_max t_ins entryAlive hSlot S) :
    ∃ pSlot : RacerP43.PureFilterSlot R ℓ M₀ d,
      S.WF cap_u B_max S.blkId.toNat entryAlive pSlot := by
  by_cases hneg : S.blkId < 0
  · have h0 : S.blkId.toNat = 0 := Int.toNat_of_nonpos (le_of_lt hneg)
    exact ⟨_, h0 ▸ (htr.1 hneg).2⟩
  · exact ⟨toP43Slot hSlot, (htr.2 (not_lt.mp hneg)).2.2⟩

theorem LiveSlotTrackedH4.of_zeroMem {R ℓ M₀ d : ℕ} (cap_u B_max : ℕ)
    (entryAlive : ℕ → Bool) (hSlot : H4a1.PureFilterSlot R ℓ M₀ d) :
    LiveSlotTrackedH4 cap_u B_max 0 entryAlive hSlot (RacerP43.LiveSlot.zeroMem R ℓ M₀ d) := by
  refine ⟨fun _ => ⟨rfl, RacerP43.LiveSlot.wf_zeroMem cap_u B_max entryAlive⟩,
          fun h0 => False.elim (by dsimp [RacerP43.LiveSlot.zeroMem] at h0; omega)⟩

theorem LiveSlotTrackedH4.of_clear {R ℓ M₀ d : ℕ} {cap_u B_max t_ins : ℕ}
    {entryAlive : ℕ → Bool} {hSlot : H4a1.PureFilterSlot R ℓ M₀ d}
    {S : RacerP43.LiveSlot R ℓ M₀ d}
    (htr : LiveSlotTrackedH4 cap_u B_max t_ins entryAlive hSlot S)
    {newEp : ℕ} (hgt : S.ep < newEp) (newAlive : ℕ → Bool)
    (newHSlot : H4a1.PureFilterSlot R ℓ M₀ d) :
    LiveSlotTrackedH4 cap_u B_max 0 newAlive newHSlot (S.clear newEp) := by
  obtain ⟨_, hwf⟩ := htr.wf_some
  refine ⟨fun _ => ⟨rfl, RacerP43.LiveSlot.wf_clear hwf hgt 0 newAlive⟩,
          fun h0 => False.elim (by dsimp [RacerP43.LiveSlot.clear] at h0; omega)⟩

theorem LiveSlotTrackedH4.of_advance_t_ins {R ℓ M₀ d : ℕ} {cap_u B_max t : ℕ}
    {entryAlive : ℕ → Bool} {hSlot : H4a1.PureFilterSlot R ℓ M₀ d}
    {S : RacerP43.LiveSlot R ℓ M₀ d}
    (htr : LiveSlotTrackedH4 cap_u B_max t entryAlive hSlot S) :
    LiveSlotTrackedH4 cap_u B_max (t + 1) (Function.update entryAlive t true) hSlot S := by
  refine ⟨fun hneg => ?_, fun hnonneg => ?_⟩
  · rcases htr.1 hneg with ⟨hbc, hbc_le, hcaps, ndL, hinv, hmap⟩
    refine ⟨hbc, hbc_le, hcaps, ndL, hinv, fun r c => ⟨(hmap r c).1, ?_⟩⟩
    rw [(hmap r c).2]; rfl
  · rcases htr.2 hnonneg with ⟨hub, hrange, hbc_le, hcaps, ndL, hinv, hmap⟩
    refine ⟨by omega, hrange, hbc_le, hcaps, ndL, hinv, fun r c => ⟨(hmap r c).1, ?_⟩⟩
    rw [(hmap r c).2]
    refine List.filter_congr fun e he => ?_
    have hlt_t : e < t := lt_of_lt_of_le (hrange r c e he).2 hub
    rw [Function.update_of_ne (by omega : e ≠ t)]

theorem LiveSlotTrackedH4.of_init {R ℓ M₀ d b : ℕ} {cap_u B_max t_ins : ℕ}
    {entryAlive : ℕ → Bool} {hSlot : H4a1.PureFilterSlot R ℓ M₀ d}
    {S : RacerP43.LiveSlot R ℓ M₀ d}
    (htr : LiveSlotTrackedH4 cap_u B_max t_ins entryAlive hSlot S)
    {newEp : ℕ} (hgt : S.ep < newEp) {blkStart : ℕ} (hle : blkStart ≤ t_ins)
    (T p_coord : ℕ) (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b) :
    LiveSlotTrackedH4 cap_u B_max t_ins entryAlive
      (H4a1.PureFilterSlot.init T p_coord ω)
      (S.init newEp (blkStart : ℤ) T p_coord ω) := by
  obtain ⟨_, hwf₀⟩ := htr.wf_some
  refine ⟨fun hneg => False.elim (by dsimp [RacerP43.LiveSlot.init] at hneg; omega),
          fun _ => ?_⟩
  have hblk_toNat : (S.init newEp (blkStart : ℤ) T p_coord ω).blkId.toNat = blkStart := by
    dsimp [RacerP43.LiveSlot.init]
  refine ⟨by dsimp [RacerP43.LiveSlot.init]; omega,
          fun _ _ _ h => by simp [H4a1.PureFilterSlot.init] at h,
          ?_⟩
  rw [hblk_toNat, toP43Slot_init]
  exact RacerP43.LiveSlot.wf_init hwf₀ hgt (blkStart : ℤ) blkStart T p_coord ω

theorem LiveSlotTrackedH4.of_insertRecord {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    {A B_rat τ_d : ℚ} {cap_u B_max t_ins blkStart : ℕ}
    {entryAlive : ℕ → Bool} {hSlot : H4a1.PureFilterSlot R ℓ M₀ d}
    {S : RacerP43.LiveSlot R ℓ M₀ d}
    (htr : LiveSlotTrackedH4 cap_u B_max t_ins entryAlive hSlot S)
    (hblk : S.blkId = (blkStart : ℤ))
    (hlt_B : S.builtCnt < B_max)
    (hlt_t : blkStart + S.builtCnt < t_ins)
    (o pt : EuclideanSpace ℝ (Fin d)) :
    let eid := blkStart + S.builtCnt
    let S' := S.insertRecord hM₀ A B_rat τ_d cap_u eid (entryAlive eid) o pt
    let hSlot' := hSlot.insertPoint hM₀ A B_rat τ_d cap_u o pt eid
    LiveSlotTrackedH4 cap_u B_max t_ins entryAlive hSlot' S' ∧
    S'.blkId = (blkStart : ℤ) ∧
    S'.builtCnt = S.builtCnt + 1 := by
  classical
  intro eid S' hSlot'
  have hnonneg : 0 ≤ S.blkId := by rw [hblk]; positivity
  have htoNat : S.blkId.toNat = blkStart := by rw [hblk]; omega
  rcases htr.2 hnonneg with ⟨_, hrange, hwf₀⟩
  rw [htoNat] at hwf₀
  obtain ⟨hwf', _, _, hbc', hblk'⟩ :=
    RacerP43.LiveSlot.wf_insertRecord hM₀ (A := A) (B_rat := B_rat) (τ_d := τ_d) hwf₀ hlt_B o pt
  have hblk_S' : S'.blkId = (blkStart : ℤ) := hblk'.trans hblk
  have htoNat_S' : S'.blkId.toNat = blkStart := by rw [hblk_S']; omega
  refine ⟨⟨fun hneg => False.elim (by rw [hblk_S'] at hneg; omega), fun _ => ?_⟩,
          hblk_S', hbc'⟩
  rw [htoNat_S', hbc']
  refine ⟨by omega, fun r c e he => ?_, ?_⟩
  · dsimp only [hSlot', H4a1.PureFilterSlot.insertPoint] at he
    split_ifs at he with hc1 hc2
    · rcases List.mem_cons.mp he with rfl | hold
      · dsimp [eid]; omega
      · have := hrange r c e hold; rw [htoNat] at this; omega
    · have := hrange r c e he; rw [htoNat] at this; omega
    · have := hrange r c e he; rw [htoNat] at this; omega
  · dsimp only [hSlot']
    rw [toP43Slot_insertPoint]
    exact hwf'

theorem LiveSlotTrackedH4.of_unlinkCond {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    {cap_u B_max t_ins : ℕ}
    {entryAlive : ℕ → Bool} {hSlot : H4a1.PureFilterSlot R ℓ M₀ d}
    {S : RacerP43.LiveSlot R ℓ M₀ d}
    (htr : LiveSlotTrackedH4 cap_u B_max t_ins entryAlive hSlot S)
    (e_del : ℕ) :
    let inBlk : Bool :=
      decide (0 ≤ S.blkId ∧ S.blkId ≤ (e_del : ℤ) ∧ (e_del : ℤ) < S.blkId + (S.builtCnt : ℤ))
    let S' := if inBlk then S.unlinkLoc (R * cap_u) (e_del - S.blkId.toNat) else S
    LiveSlotTrackedH4 cap_u B_max t_ins (Function.update entryAlive e_del false) hSlot S' ∧
    S'.blkId = S.blkId ∧
    S'.builtCnt = S.builtCnt := by
  intro inBlk S'
  by_cases hc : 0 ≤ S.blkId ∧ S.blkId ≤ (e_del : ℤ) ∧ (e_del : ℤ) < S.blkId + (S.builtCnt : ℤ)
  · have hin : inBlk = true := decide_eq_true hc
    have hS'_eq : S' = S.unlinkLoc (R * cap_u) (e_del - S.blkId.toNat) := by
      dsimp [S']; rw [hin]; rfl
    rcases htr.2 hc.1 with ⟨hub, hrange, hwf₀⟩
    have hbc_B : S.builtCnt ≤ B_max := hwf₀.1
    let loc := e_del - S.blkId.toNat
    have hloc_lt : loc < B_max := by dsimp [loc]; omega
    have he_eq : S.blkId.toNat + loc = e_del := by dsimp [loc]; omega
    obtain ⟨hwf_u, _, _, hbc_u, hblk_u⟩ := RacerP43.LiveSlot.wf_unlinkLoc hM₀ hwf₀ hloc_lt
    rw [he_eq] at hwf_u
    rw [hS'_eq]
    refine ⟨⟨fun hneg => False.elim (by rw [hblk_u] at hneg; omega), fun _ => ?_⟩,
            hblk_u, hbc_u⟩
    rw [hblk_u, hbc_u]
    exact ⟨hub, hrange, hwf_u⟩
  · have hin : inBlk = false := decide_eq_false hc
    have hS'_eq : S' = S := by dsimp [S']; rw [hin]; rfl
    rw [hS'_eq]
    refine ⟨⟨fun hneg => ?_, fun hnonneg => ?_⟩, rfl, rfl⟩
    · rcases htr.1 hneg with ⟨hbc, hwf₀⟩
      refine ⟨hbc, RacerP43.LiveSlot.wf_unlink_outside hwf₀ (fun _ hlo hhi => by omega)
        (fun _ _ _ he => by cases he)⟩
    · rcases htr.2 hnonneg with ⟨hub, hrange, hwf₀⟩
      refine ⟨hub, hrange, RacerP43.LiveSlot.wf_unlink_outside hwf₀ (fun e hlo hhi => ?_) hrange⟩
      intro heq; subst heq; exact hc ⟨hnonneg, by omega, by omega⟩

/-- Heap memory representation of `H4b.DyadicSideIndex` in word table `tblW` at `sideBaseW`
(stride `dyadicSideWStride n L_p2 R ℓ M₀ cap_u`) and real table `tblR` at `sideBaseR`
(stride `dyadicSideRStride L_p2 R ℓ M₀ d`). -/
def EncH4DyadicSide (tblW : ℕ) (sideBaseW : ℤ) (tblR : ℕ) (sideBaseR : ℤ)
    (n L_p2 R ℓ M₀ d b cap_u : ℕ)
    (U : Finset ℕ) (idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b)
    (m : ArithRAMMemory) : Prop :=
  let B_max := 2 ^ L_p2
  idx.t_ins ≤ B_max ∧
  ∃ (ep_side : ℕ) (liveSlots : Fin L_p2 → Fin 2 → RacerP43.LiveSlot R ℓ M₀ d),
    1 ≤ ep_side ∧
    H3a.wRead m tblW sideBaseW = (ep_side : ℤ) ∧
    H3a.wRead m tblW (sideBaseW + 1) = (idx.t_ins : ℤ) ∧
    (∀ eid < idx.t_ins,
      H3a.wRead m tblW (sideHandleOff sideBaseW eid) = (idx.entryHandle eid : ℤ)) ∧
    (∀ eid < B_max,
      H3a.wRead m tblW (sideAliveEpOff L_p2 sideBaseW eid) ≤ (ep_side : ℤ)) ∧
    (∀ eid < idx.t_ins,
      (H3a.wRead m tblW (sideAliveEpOff L_p2 sideBaseW eid) = (ep_side : ℤ) ↔
        idx.entryAlive eid = true)) ∧
    (∀ u ∈ U,
      H3a.wRead m tblW (sideActiveOff L_p2 sideBaseW (u % n)) = (idx.activeEid u : ℤ)) ∧
    (∀ eid < idx.t_ins, ∀ c : Fin d,
      H3a.rRead m tblR (sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
        euclideanCoord (idx.entryPt eid) c) ∧
    (∀ s : Fin L_p2, ∀ sl : Fin 2,
      LiveSlotTrackedH4 cap_u B_max idx.t_ins idx.entryAlive (idx.slots s sl) (liveSlots s sl) ∧
      RacerP43.EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx s sl))
        tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx s sl))
        R ℓ M₀ d cap_u B_max (liveSlots s sl) m) ∧
    (∀ s : Fin L_p2,
      let H := 2 ^ s.val
      let B := 2 * H
      let q := idx.t_ins / B
      let off := idx.t_ins % B
      (1 ≤ q → 1 ≤ off → off < H →
        (liveSlots s (H4b.mod2Fin (q - 1))).blkId = (((q - 1) * B : ℕ) : ℤ) ∧
        (liveSlots s (H4b.mod2Fin (q - 1))).builtCnt = 2 * off) ∧
      (1 ≤ q → H ≤ off → 0 ≤ (liveSlots s (H4b.mod2Fin (q - 1))).blkId) ∧
      (2 ≤ q → 0 ≤ (liveSlots s (H4b.mod2Fin (q - 2))).blkId))

theorem EncH4DyadicSide.t_ins_le {tblW : ℕ} {sideBaseW : ℤ} {tblR : ℕ} {sideBaseR : ℤ}
    {n L_p2 R ℓ M₀ d b cap_u : ℕ} {U : Finset ℕ}
    {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b} {m : ArithRAMMemory}
    (henc : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m) :
    idx.t_ins ≤ 2 ^ L_p2 := henc.1

theorem EncH4DyadicSide.t_ins_read {tblW : ℕ} {sideBaseW : ℤ} {tblR : ℕ} {sideBaseR : ℤ}
    {n L_p2 R ℓ M₀ d b cap_u : ℕ} {U : Finset ℕ}
    {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b} {m : ArithRAMMemory}
    (henc : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m) :
    H3a.wRead m tblW (sideBaseW + 1) = (idx.t_ins : ℤ) := by
  rcases henc with ⟨_, _, _, _, _, ht_r, _⟩
  exact ht_r

theorem EncH4DyadicSide.mono_frame {scrW scrR tblW' tblW : ℕ} {baseW' lenW' sideBaseW : ℤ}
    {tblR' tblR : ℕ} {baseR' lenR' sideBaseR : ℤ}
    {n L_p2 R ℓ M₀ d b cap_u : ℕ} (hn : 1 ≤ n)
    {U : Finset ℕ} {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b} {m₀ m₁ : ArithRAMMemory}
    (henc : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀)
    (hfr : RacerP43.RadFrameOutside scrW scrR tblW' baseW' lenW' tblR' baseR' lenR' m₀ m₁)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hdisjW : tblW ≠ tblW' ∨
      sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ baseW' ∨
      baseW' + lenW' ≤ sideBaseW)
    (hdisjR : tblR ≠ tblR' ∨
      sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ baseR' ∨
      baseR' + lenR' ≤ sideBaseR + (d : ℤ)) :
    EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₁ := by
  have hkW : ∀ i : ℤ, sideBaseW ≤ i →
      i < sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i := by
    intro i _ _
    apply hfr.1 tblW i hneW
    rcases hdisjW with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by omega))
    · exact Or.inr (Or.inr (by omega))
  have hkR : ∀ i : ℤ, sideBaseR + (d : ℤ) ≤ i →
      i < sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d →
      H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i := by
    intro i _ _
    apply hfr.2 tblR i hneR
    rcases hdisjR with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by omega))
    · exact Or.inr (Or.inr (by omega))
  have hpow_pos : (1 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (@Nat.one_le_two_pow L_p2)
  have hge2 := dyadicSideWStride_ge_two n L_p2 R ℓ M₀ cap_u
  have hslot0_ge : 0 ≤ ((2 * L_p2 : ℕ) : ℤ) * RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) :=
    mul_nonneg (by positivity) (by have := RacerP43.slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2); omega)
  rcases henc with ⟨ht_le, ep_side, liveSlots, hep1, hep_r, ht_r,
    hhand, hal_le, hal_iff, hact, hpt, hslots, hcur⟩
  refine ⟨ht_le, ep_side, liveSlots, hep1,
    (hkW sideBaseW le_rfl (by omega)).trans hep_r,
    (hkW (sideBaseW + 1) (by omega) (by omega)).trans ht_r,
    fun eid heid => (hkW _ (by unfold sideHandleOff; omega)
      (by unfold sideHandleOff dyadicSideWStride; omega)).trans (hhand eid heid),
    fun eid heid => by
      rw [hkW _ (by unfold sideAliveEpOff; omega) (by unfold sideAliveEpOff dyadicSideWStride; omega)]
      exact hal_le eid heid,
    fun eid heid => by
      rw [hkW _ (by unfold sideAliveEpOff; omega) (by unfold sideAliveEpOff dyadicSideWStride; omega)]
      exact hal_iff eid heid,
    fun u hu => by
      have hmod : u % n < n := Nat.mod_lt u hn
      exact (hkW _ (by unfold sideActiveOff; omega)
        (by unfold sideActiveOff dyadicSideWStride; omega)).trans (hact u hu),
    fun eid heid c => by
      have hb := sideEntryPt_bounds (L_p2 := L_p2) sideBaseR (lt_of_lt_of_le heid ht_le) c
      have hre := dyadicSideRStride_ge_entryEnd L_p2 R ℓ M₀ d
      exact (hkR _ hb.1 (by omega)).trans (hpt eid heid c),
    fun s sl => ?_, hcur⟩
  rcases hslots s sl with ⟨htr_s, henc_s⟩
  have hbw := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
    sideBaseW (sideSlotIdx_lt s sl)
  have hbr := sideSlotBaseR_bounds (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
    sideBaseR (sideSlotIdx_lt s sl)
  refine ⟨htr_s, henc_s.mono_frame hfr hneW hneR ?_ ?_⟩
  · rcases hdisjW with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by omega))
    · exact Or.inr (Or.inr (by omega))
  · rcases hdisjR with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by omega))
    · exact Or.inr (Or.inr (by omega))


end UL.Proof.clm_9_1_explicit_tradeoff.CG16
