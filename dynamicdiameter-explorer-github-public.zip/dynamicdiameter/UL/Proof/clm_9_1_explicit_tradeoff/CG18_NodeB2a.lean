import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeB1

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

/-! ### 5a. Syntactic Caller-Register Preservation (`PreservesScrBelow`) -/

inductive PreservesScrBelow (scrW : ℕ) (wBound : ℤ) : ArithRAMStmt → Prop
  | skip : PreservesScrBelow scrW wBound .skip
  | writeWordOther {t : ℕ} {idxE valE : IntExpr} (hne : t ≠ scrW) :
      PreservesScrBelow scrW wBound (.writeWordHeap t idxE valE)
  | writeWordGe {k : ℤ} {valE : IntExpr} (hge : wBound ≤ k) :
      PreservesScrBelow scrW wBound (.writeWordHeap scrW (.lit k) valE)
  | writeReal {t : ℕ} {idxE : IntExpr} {valE : RealExpr} :
      PreservesScrBelow scrW wBound (.writeRealHeap t idxE valE)
  | seq {s₁ s₂ : ArithRAMStmt} :
      PreservesScrBelow scrW wBound s₁ → PreservesScrBelow scrW wBound s₂ →
      PreservesScrBelow scrW wBound (.seq s₁ s₂)
  | ite {c : ArithCondExpr} {t f : ArithRAMStmt} :
      PreservesScrBelow scrW wBound t → PreservesScrBelow scrW wBound f →
      PreservesScrBelow scrW wBound (.ite c t f)
  | repeatN {cnt : IntExpr} {b : ArithRAMStmt} :
      PreservesScrBelow scrW wBound b → PreservesScrBelow scrW wBound (.repeatN cnt b)

def PreservesScrCont (scrW : ℕ) (wBound : ℤ) : ArithRAMCont → Prop
  | .stmt s => PreservesScrBelow scrW wBound s
  | .repeatLoop _ b => PreservesScrBelow scrW wBound b
  | .popScope _ => False

private lemma preservesScrBelow_fuel {d : ℕ} {inp : ArithRAMInput d} {scrW : ℕ} {wBound : ℤ} :
    ∀ (f : ℕ) (stk : List ArithRAMCont) (m₀ : ArithRAMMemory) (bs : List Bool)
      (u₀ sp₀ : ℕ) (out : ArithRAMExecOutcome),
      CleanMem m₀ →
      (∀ c ∈ stk, PreservesScrCont scrW wBound c) →
      runArithRAMFuel inp f stk
        { mem := m₀, frameDepth := 0, remainingBits := bs,
          unitCost := u₀, peakCellSpace := sp₀ } = .halted out →
      ∀ w, w < wBound → H3a.wRead out.mem scrW w = H3a.wRead m₀ scrW w
  | 0, [], m₀, _, _, _, out, hcm, _, hrun => by
      simp only [runArithRAMFuel] at hrun
      split_ifs at hrun with he
      simp only [ArithRAMRunStatus.halted.injEq] at hrun
      subst out; dsimp only
      have hpop : m₀.popDepth 0 = m₀ := hcm
      rw [hpop]; exact fun _ _ => rfl
  | 0, _ :: _, _, _, _, _, _, _, _, hrun => by
      simp [runArithRAMFuel] at hrun
  | f + 1, [], m₀, _, _, _, out, hcm, _, hrun => by
      simp only [runArithRAMFuel] at hrun
      split_ifs at hrun with he
      simp only [ArithRAMRunStatus.halted.injEq] at hrun
      subst out; dsimp only
      have hpop : m₀.popDepth 0 = m₀ := hcm
      rw [hpop]; exact fun _ _ => rfl
  | f + 1, item :: tl, m₀, bs, u₀, sp₀, out, hcm, hstk, hrun => by
      have hitem := hstk item List.mem_cons_self
      have htl : ∀ c ∈ tl, PreservesScrCont scrW wBound c :=
        fun c hc => hstk c (List.mem_cons_of_mem _ hc)
      cases item with
      | popScope _ => cases hitem
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              exact preservesScrBelow_fuel f tl m₀ bs u₀ sp₀ out hcm htl hrun
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt body :: .repeatLoop r body :: tl), PreservesScrCont scrW wBound c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc'
                · exact hitem
                · rcases List.mem_cons.mp hc' with rfl | hc''
                  · exact hitem
                  · exact htl c hc''
              exact preservesScrBelow_fuel f _ m₀ bs u₀ sp₀ out hcm hstk' hrun
      | stmt s =>
          cases hitem with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              exact preservesScrBelow_fuel f tl m₀ bs _ _ out hcm htl hrun
          | @writeWordOther t idxE valE hne =>
              simp only [runArithRAMFuel] at hrun
              let idx := (evalIntExpr inp.toWordView 0 m₀.words idxE).1
              let val := (evalIntExpr inp.toWordView 0 m₀.words valE).1
              have hcm' : CleanMem (H3a.wWrite m₀ t idx val) := cleanMem_wWrite hcm t idx val
              have ih := preservesScrBelow_fuel f tl (H3a.wWrite m₀ t idx val) bs _ _ out hcm' htl hrun
              exact fun w hw => (ih w hw).trans (wRead_wWrite_of_ne m₀ val (Or.inl hne.symm))
          | @writeWordGe k valE hge =>
              simp only [runArithRAMFuel, evalIntExpr] at hrun
              let val := (evalIntExpr inp.toWordView 0 m₀.words valE).1
              have hcm' : CleanMem (H3a.wWrite m₀ scrW k val) := cleanMem_wWrite hcm scrW k val
              have ih := preservesScrBelow_fuel f tl (H3a.wWrite m₀ scrW k val) bs _ _ out hcm' htl hrun
              exact fun w hw => (ih w hw).trans (wRead_wWrite_of_ne m₀ val (Or.inr (by omega)))
          | @writeReal t idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let idx := (evalIntExpr inp.toWordView 0 m₀.words idxE).1
              let val := (evalRealExpr inp 0 m₀ valE).1
              have hcm' : CleanMem (H3a.rWrite m₀ t idx val) := cleanMem_rWrite hcm t idx val
              have ih := preservesScrBelow_fuel f tl (H3a.rWrite m₀ t idx val) bs _ _ out hcm' htl hrun
              exact fun w hw => ih w hw
          | @seq s₁ s₂ hs₁ hs₂ =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt s₁ :: .stmt s₂ :: tl), PreservesScrCont scrW wBound c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc'
                · exact hs₁
                · rcases List.mem_cons.mp hc' with rfl | hc''
                  · exact hs₂
                  · exact htl c hc''
              exact preservesScrBelow_fuel f _ m₀ bs _ _ out hcm hstk' hrun
          | @ite c tB fB htB hfB =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalArithCond inp 0 m₀ c
              have hbr : PreservesScrCont scrW wBound (.stmt (if ec.1 then tB else fB)) := by
                dsimp [PreservesScrCont]; split_ifs <;> assumption
              have hstk2 : ∀ x ∈ (.stmt (if ec.1 then tB else fB) :: tl), PreservesScrCont scrW wBound x := by
                intro x hx
                rcases List.mem_cons.mp hx with rfl | hx'
                · exact hbr
                · exact htl x hx'
              exact preservesScrBelow_fuel f _ m₀ bs _ _ out hcm hstk2 hrun
          | @repeatN cntE b hb =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalIntExpr inp.toWordView 0 m₀.words cntE
              let n_it := if 0 ≤ ec.1 then ec.1.toNat else 0
              have hstk2 : ∀ x ∈ (.repeatLoop n_it b :: tl), PreservesScrCont scrW wBound x := by
                intro x hx
                rcases List.mem_cons.mp hx with rfl | hx'
                · exact hb
                · exact htl x hx'
              exact preservesScrBelow_fuel f _ m₀ bs _ _ out hcm hstk2 hrun

theorem detExec_preserves_scr_below {d TW BW TR BR scrW : ℕ} {inp : ArithRAMInput d}
    {wBound : ℤ} {s : ArithRAMStmt} {m₀ m₁ : ArithRAMMemory} {C : ℕ}
    (hps : PreservesScrBelow scrW wBound s)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hfp₁ : InFootprint TW BW TR BR m₁)
    (hdet : DetExec inp s m₀ m₁ C) :
    ∀ w, w < wBound → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w := by
  obtain ⟨fuel, u₁, sp₁, _, hstep⟩ := hdet [] 0 0 []
  have hrun := hstep 0
  simp only [Nat.add_zero, runArithRAMFuel, List.isEmpty_nil, ↓reduceIte] at hrun
  have hpop : m₁.popDepth 0 = m₁ := hfp₁.1
  rw [hpop] at hrun
  exact preservesScrBelow_fuel fuel [.stmt s] m₀ [] 0 0
    { mem := m₁, unitCost := u₁, peakCellSpace := sp₁ } hfp₀.1
    (fun c hc => by rcases List.mem_singleton.mp hc with rfl; exact hps) hrun

theorem psb_swapPoolMemStmt {scrW tbl : ℕ} {wBound wPoolBase wUid wScr wOut : ℤ} {n : ℕ}
    (hneW : tbl ≠ scrW) (hScr : wBound ≤ wScr) (hOut : wBound ≤ wOut) :
    PreservesScrBelow scrW wBound (swapPoolMemStmt scrW tbl wPoolBase wUid wScr wOut n) := by
  unfold swapPoolMemStmt
  repeat' first
    | apply PreservesScrBelow.seq
    | apply PreservesScrBelow.ite
    | apply PreservesScrBelow.repeatN
    | apply PreservesScrBelow.skip
    | apply PreservesScrBelow.writeReal
    | (apply PreservesScrBelow.writeWordGe; omega)
    | exact PreservesScrBelow.writeWordOther hneW

theorem psb_swapPoolInsertStmt {scrW tbl : ℕ} {wBound wPoolBase wUid wScr : ℤ} {n : ℕ}
    (hneW : tbl ≠ scrW) (hScr : wBound ≤ wScr) :
    PreservesScrBelow scrW wBound (swapPoolInsertStmt scrW tbl wPoolBase wUid wScr n) := by
  unfold swapPoolInsertStmt
  refine .seq (psb_swapPoolMemStmt hneW hScr (by omega)) ?_
  repeat' first
    | apply PreservesScrBelow.seq
    | apply PreservesScrBelow.ite
    | apply PreservesScrBelow.repeatN
    | apply PreservesScrBelow.skip
    | apply PreservesScrBelow.writeReal
    | (apply PreservesScrBelow.writeWordGe; omega)
    | exact PreservesScrBelow.writeWordOther hneW

theorem psb_swapPoolDeleteStmt {scrW tbl : ℕ} {wBound wPoolBase wUid wScr : ℤ} {n : ℕ}
    (hneW : tbl ≠ scrW) (hScr : wBound ≤ wScr) :
    PreservesScrBelow scrW wBound (swapPoolDeleteStmt scrW tbl wPoolBase wUid wScr n) := by
  unfold swapPoolDeleteStmt
  refine .seq (psb_swapPoolMemStmt hneW hScr (by omega)) ?_
  repeat' first
    | apply PreservesScrBelow.seq
    | apply PreservesScrBelow.ite
    | apply PreservesScrBelow.repeatN
    | apply PreservesScrBelow.skip
    | apply PreservesScrBelow.writeReal
    | (apply PreservesScrBelow.writeWordGe; omega)
    | exact PreservesScrBelow.writeWordOther hneW

theorem psb_radTreeUpdateLeafStmt {scrW scrR tblW tblR tblO : ℕ}
    {wBound wBaseW wBaseR wOffO wUid wIns wScr rScr : ℤ} {K_seg n d : ℕ}
    (hneW : tblW ≠ scrW) (hScr : wBound ≤ wScr) :
    PreservesScrBelow scrW wBound
      (radTreeUpdateLeafStmt scrW scrR tblW tblR tblO
        wBaseW wBaseR wOffO wUid wIns wScr rScr K_seg n d) := by
  unfold radTreeUpdateLeafStmt radTreePrepLeafStmt radTreePullStepStmt
    combineRadRegsStmt radTreeWriteNodeStmt radTreeReadNodeStmt
  repeat' first
    | apply PreservesScrBelow.seq
    | apply PreservesScrBelow.ite
    | apply PreservesScrBelow.repeatN
    | apply PreservesScrBelow.skip
    | apply PreservesScrBelow.writeReal
    | (apply PreservesScrBelow.writeWordGe; omega)
    | exact PreservesScrBelow.writeWordOther hneW

theorem cfgDisjW {n cap_hist K_seg N_cfg : ℕ} {cfgWStride : ℤ}
    (hcfgW : 0 ≤ cfgWStride) (nodeBaseW : ℤ) {idx i : Fin N_cfg} (hne : idx ≠ i) (j : ℤ)
    (hj1 : nodeCfgWOff n cap_hist K_seg cfgWStride nodeBaseW idx.val ≤ j)
    (hj2 : j < nodeCfgWOff n cap_hist K_seg cfgWStride nodeBaseW idx.val + cfgWStride) :
    j < nodeCfgWOff n cap_hist K_seg cfgWStride nodeBaseW i.val ∨
    nodeCfgWOff n cap_hist K_seg cfgWStride nodeBaseW i.val + cfgWStride ≤ j := by
  have hne_v : idx.val ≠ i.val := fun he => hne (Fin.ext he)
  rcases lt_or_gt_of_ne hne_v with hlt | hgt
  · apply Or.inl
    have hm1 : ((idx.val + 1 : ℕ) : ℤ) * cfgWStride ≤ (i.val : ℤ) * cfgWStride :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast hlt) hcfgW
    have hm2 : (idx.val : ℤ) * cfgWStride + cfgWStride = ((idx.val + 1 : ℕ) : ℤ) * cfgWStride := by
      push_cast; ring
    unfold nodeCfgWOff at hj1 hj2 ⊢; omega
  · apply Or.inr
    have hm1 : ((i.val + 1 : ℕ) : ℤ) * cfgWStride ≤ (idx.val : ℤ) * cfgWStride :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast hgt) hcfgW
    have hm2 : (i.val : ℤ) * cfgWStride + cfgWStride = ((i.val + 1 : ℕ) : ℤ) * cfgWStride := by
      push_cast; ring
    unfold nodeCfgWOff at hj1 hj2 ⊢; omega

theorem cfgDisjR {d K_seg N_cfg : ℕ} {cfgRStride : ℤ}
    (hcfgR : 0 ≤ cfgRStride) (nodeBaseR : ℤ) {idx i : Fin N_cfg} (hne : idx ≠ i) (j : ℤ)
    (hj1 : nodeCfgROff d K_seg cfgRStride nodeBaseR idx.val ≤ j)
    (hj2 : j < nodeCfgROff d K_seg cfgRStride nodeBaseR idx.val + cfgRStride) :
    j < nodeCfgROff d K_seg cfgRStride nodeBaseR i.val ∨
    nodeCfgROff d K_seg cfgRStride nodeBaseR i.val + cfgRStride ≤ j := by
  have hne_v : idx.val ≠ i.val := fun he => hne (Fin.ext he)
  rcases lt_or_gt_of_ne hne_v with hlt | hgt
  · apply Or.inl
    have hm1 : ((idx.val + 1 : ℕ) : ℤ) * cfgRStride ≤ (i.val : ℤ) * cfgRStride :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast hlt) hcfgR
    have hm2 : (idx.val : ℤ) * cfgRStride + cfgRStride = ((idx.val + 1 : ℕ) : ℤ) * cfgRStride := by
      push_cast; ring
    unfold nodeCfgROff at hj1 hj2 ⊢; omega
  · apply Or.inr
    have hm1 : ((i.val + 1 : ℕ) : ℤ) * cfgRStride ≤ (idx.val : ℤ) * cfgRStride :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast hgt) hcfgR
    have hm2 : (i.val : ℤ) * cfgRStride + cfgRStride = ((i.val + 1 : ℕ) : ℤ) * cfgRStride := by
      push_cast; ring
    unfold nodeCfgROff at hj1 hj2 ⊢; omega

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
