import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInstA0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 1. `ManagedNodeSlotReady.mono_slice` & `NodeSlotLayout` -/

theorem ManagedNodeSlotReady.mono_slice
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    {ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    {specs : Fin N_cfg → ConfigStaticSpec d params h}
    {cap_hist K_seg : ℕ} {nodeBaseW nodeBaseR : ℤ} {m₀ m₁ : ArithRAMMemory}
    (hrdy : ManagedNodeSlotReady ops specs cap_hist K_seg nodeBaseW nodeBaseR m₀)
    (heqW : ∀ i : ℤ, nodeBaseW ≤ i →
      i < nodeBaseW + managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i)
    (heqR : ∀ i : ℤ, nodeBaseR ≤ i →
      i < nodeBaseR + managedNodeRStride d K_seg N_cfg ops.cfgRStride →
      H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i) :
    ManagedNodeSlotReady ops specs cap_hist K_seg nodeBaseW nodeBaseR m₁ := by
  have hcfgW := ops.hcfgW_nonneg
  have hcfgR := ops.hcfgR_nonneg
  have hrad4 := radTreeWStride_ge_four K_seg
  have hradR := radTreeRStride_nonneg K_seg
  have hncfgW : 0 ≤ (N_cfg : ℤ) * ops.cfgWStride := mul_nonneg (Nat.cast_nonneg _) hcfgW
  have hncfgR : 0 ≤ (N_cfg : ℤ) * ops.cfgRStride := mul_nonneg (Nat.cast_nonneg _) hcfgR
  rcases hrdy with ⟨hd_r, hr_r, ht_r, hc_r⟩
  refine ⟨?_, ?_, ?_, fun i => ?_⟩
  · refine SwapPoolReady.mono_slice hd_r (fun k hlo hhi => heqW k ?_ ?_)
    · unfold nodeDensePoolOff at hlo; omega
    · unfold nodeDensePoolOff at hhi; unfold managedNodeWStride swapPoolStride at *; omega
  · refine SwapPoolReady.mono_slice hr_r (fun k hlo hhi => heqW k ?_ ?_)
    · unfold nodeResPoolOff swapPoolStride at hlo; omega
    · unfold nodeResPoolOff at hhi; unfold managedNodeWStride swapPoolStride at *; omega
  · refine RadTreeReady.mono_slice ht_r (fun k hlo hhi => heqW k ?_ ?_)
    · unfold nodeRadTreeWOff nodeHistOff swapPoolStride at hlo; omega
    · unfold nodeRadTreeWOff nodeHistOff at hhi; unfold managedNodeWStride at *; omega
  · have hbW := nodeCfgWOff_bounds n cap_hist K_seg hcfgW nodeBaseW i
    have hbR := nodeCfgROff_bounds d K_seg hcfgR nodeBaseR i
    have hloW : nodeBaseW ≤ nodeCfgsWBase n cap_hist K_seg nodeBaseW := by
      unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride; omega
    have hloR : nodeBaseR ≤ nodeCfgsRBase d K_seg nodeBaseR := by
      unfold nodeCfgsRBase nodeRadTreeROff; omega
    exact ops.cfgReady_mono_slice (specs i) _ _ m₀ m₁ (hc_r i)
      (fun k hk0 hk1 => heqW k (by omega) (by omega))
      (fun k hk0 hk1 => heqR k (by omega) (by omega))

/-- Parameterized physical slot layout for `M_slots cp` `ManagedNode` instances in `nodeWTbl`
and `nodeRTbl`, with dedicated scratch tables `nodeScrWTbl` and `nodeScrRTbl`. -/
structure NodeSlotLayout {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) where
  TW : ℕ
  TR : ℕ
  nodeWTbl : ℕ
  nodeScrWTbl : ℕ
  nodeRTbl : ℕ
  nodeScrRTbl : ℕ
  hNodeWTbl_lo : 9 ≤ nodeWTbl
  hNodeWTbl_hi : nodeWTbl < TW - 1
  hNodeScrW_lo : 9 ≤ nodeScrWTbl
  hNodeScrW_hi : nodeScrWTbl < TW
  hne_nodeW : nodeWTbl ≠ nodeScrWTbl
  hNodeRTbl_lo : 3 ≤ nodeRTbl
  hNodeRTbl_hi : nodeRTbl < TR
  hNodeScrR_lo : 3 ≤ nodeScrRTbl
  hNodeScrR_hi : nodeScrRTbl < TR
  hne_nodeR : nodeRTbl ≠ nodeScrRTbl
  BW_extra : ℕ
  BR_extra : ℕ
  cmOps : ConfigMatchRAMOps d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b cp.T_cdf cp.p_coord
    (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
    nodeScrWTbl nodeScrRTbl nodeWTbl nodeRTbl coinTbl
  cmHzr : ConfigMatchHeapZeroRand cmOps

section SlotOps

variable {d : ℕ} {params : LocalScaleParams} {h : ℝ}
variable {cp : ChainParams d params h} (L : NodeSlotLayout cp)

def NodeSlotLayout.capHist (_L : NodeSlotLayout cp) : ℕ := 4 * cp.n + 4

def NodeSlotLayout.nodeWStride : ℕ :=
  (managedNodeWStride cp.n (4 * cp.n + 4) cp.L_p2 cp.N_cfg L.cmOps.cfgWStride).toNat

def NodeSlotLayout.nodeRStride : ℕ :=
  (managedNodeRStride d cp.L_p2 cp.N_cfg L.cmOps.cfgRStride).toNat

theorem NodeSlotLayout.nodeWStride_cast :
    (L.nodeWStride : ℤ) =
      managedNodeWStride cp.n (4 * cp.n + 4) cp.L_p2 cp.N_cfg L.cmOps.cfgWStride := by
  unfold NodeSlotLayout.nodeWStride
  exact Int.toNat_of_nonneg (by
    have := managedNodeWStride_ge_header cp.n (4 * cp.n + 4) cp.L_p2 cp.N_cfg L.cmOps.hcfgW_nonneg
    omega)

theorem NodeSlotLayout.nodeRStride_cast :
    (L.nodeRStride : ℤ) =
      managedNodeRStride d cp.L_p2 cp.N_cfg L.cmOps.cfgRStride := by
  unfold NodeSlotLayout.nodeRStride
  exact Int.toNat_of_nonneg (by
    have := managedNodeRStride_ge_header d cp.L_p2 cp.N_cfg L.cmOps.hcfgR_nonneg
    omega)

def NodeSlotLayout.BW : ℕ :=
  (cp.B_STEP + 16) +
  (16 + 9 * cp.D_max + cp.D_max * cp.D_max + 16) +
  ((2 + 4 * cp.D_max) * S_stride cp + 16) +
  (M_slots cp + 128) +
  M_slots cp * L.nodeWStride +
  (64 + L.cmOps.opWScrStride.toNat) +
  L.BW_extra

def NodeSlotLayout.BR : ℕ :=
  (cp.n * d + 8) +
  (d + 32) +
  M_slots cp * L.nodeRStride +
  (d + 16 + L.cmOps.opRScrStride.toNat) +
  L.BR_extra

def NodeSlotLayout.slotBaseW (slot : ℕ) : ℤ := ((slot * L.nodeWStride : ℕ) : ℤ)
def NodeSlotLayout.slotBaseR (slot : ℕ) : ℤ := ((slot * L.nodeRStride : ℕ) : ℤ)

theorem NodeSlotLayout.slotBaseW_eq_mul (slot : ℕ) :
    L.slotBaseW slot = (slot : ℤ) * (L.nodeWStride : ℤ) := by
  unfold NodeSlotLayout.slotBaseW; push_cast; rfl

theorem NodeSlotLayout.slotBaseR_eq_mul (slot : ℕ) :
    L.slotBaseR slot = (slot : ℤ) * (L.nodeRStride : ℤ) := by
  unfold NodeSlotLayout.slotBaseR; push_cast; rfl

theorem NodeSlotLayout.hTW : 10 ≤ L.TW := by
  have := L.hNodeWTbl_lo; have := L.hNodeWTbl_hi; omega

theorem NodeSlotLayout.hTR : 3 ≤ L.TR := by
  have := L.hNodeRTbl_lo; have := L.hNodeRTbl_hi; omega

theorem NodeSlotLayout.validTables :
    ValidNodeTables L.TW L.TR L.nodeScrWTbl L.nodeScrRTbl L.nodeWTbl L.nodeRTbl coinTbl := by
  have h1 := L.hNodeWTbl_lo; have h2 := L.hNodeWTbl_hi
  have h3 := L.hNodeScrW_lo; have h4 := L.hNodeScrW_hi; have h5 := L.hne_nodeW
  have h6 := L.hNodeRTbl_lo; have h7 := L.hNodeRTbl_hi
  have h8 := L.hNodeScrR_lo; have h9 := L.hNodeScrR_hi; have h10 := L.hne_nodeR
  unfold ValidNodeTables coinTbl
  refine ⟨h4, by omega, by omega, h9, h7, by omega,
    h5, by omega, by omega, h10, by omega, by omega⟩

theorem NodeSlotLayout.opWScr_cast :
    (L.cmOps.opWScrStride.toNat : ℤ) = L.cmOps.opWScrStride :=
  Int.toNat_of_nonneg (by have := L.cmOps.hopWScr_pos; omega)

theorem NodeSlotLayout.opRScr_cast :
    (L.cmOps.opRScrStride.toNat : ℤ) = L.cmOps.opRScrStride :=
  Int.toNat_of_nonneg (by have := L.cmOps.hopRScr_pos; omega)

theorem NodeSlotLayout.slotBaseW_bounds {slot : ℕ} (hs : slot < M_slots cp) :
    0 ≤ L.slotBaseW slot ∧
    L.slotBaseW slot +
      managedNodeWStride cp.n (4 * cp.n + 4) cp.L_p2 cp.N_cfg L.cmOps.cfgWStride ≤ (L.BW : ℤ) := by
  obtain ⟨h0, hhi⟩ := slotSlice_bounds (stride := L.nodeWStride) hs
  rw [← L.nodeWStride_cast]
  refine ⟨h0, hhi.trans ?_⟩
  have hle : M_slots cp * L.nodeWStride ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  exact_mod_cast hle

theorem NodeSlotLayout.slotBaseR_bounds {slot : ℕ} (hs : slot < M_slots cp) :
    0 ≤ L.slotBaseR slot ∧
    L.slotBaseR slot +
      managedNodeRStride d cp.L_p2 cp.N_cfg L.cmOps.cfgRStride ≤ (L.BR : ℤ) := by
  obtain ⟨h0, hhi⟩ := slotSlice_bounds (stride := L.nodeRStride) hs
  rw [← L.nodeRStride_cast]
  refine ⟨h0, hhi.trans ?_⟩
  have hle : M_slots cp * L.nodeRStride ≤ L.BR := by unfold NodeSlotLayout.BR; omega
  exact_mod_cast hle

/-! ### 2. `SlotsReady` & `EncNode` Predicates and Extensionality / Frame Lemmas -/

def NodeSlotLayout.SlotsReady (m : ArithRAMMemory) : Prop :=
  ∀ s < M_slots cp,
    ManagedNodeSlotReady L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW s) (L.slotBaseR s) m

def NodeSlotLayout.EncNode (mn : MNode cp) (slot : ℕ) (m : ArithRAMMemory) : Prop :=
  (∀ x ∈ mn.nd.curSet, x < cp.n) ∧
  EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
    (L.slotBaseW slot) (L.slotBaseR slot) (memPtsOf d m) mn none m

theorem NodeSlotLayout.slotsReady_empty : L.SlotsReady ArithRAMMemory.empty :=
  fun s _ => ManagedNodeSlotReady.of_empty L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
    (L.slotBaseW s) (L.slotBaseR s)

theorem NodeSlotLayout.slotsReady_ext (m₁ m₂ : ArithRAMMemory)
    (hsr : L.SlotsReady m₁)
    (hw : ∀ t, 9 ≤ t → t < L.TW - 1 → ∀ i, H3a.wRead m₂ t i = H3a.wRead m₁ t i)
    (hr : ∀ t, 3 ≤ t → t < L.TR → ∀ i, H3a.rRead m₂ t i = H3a.rRead m₁ t i) :
    L.SlotsReady m₂ :=
  fun s hs =>
    ManagedNodeSlotReady.mono_slice (hsr s hs)
      (fun i _ _ => hw L.nodeWTbl L.hNodeWTbl_lo L.hNodeWTbl_hi i)
      (fun i _ _ => hr L.nodeRTbl L.hNodeRTbl_lo L.hNodeRTbl_hi i)

theorem NodeSlotLayout.encNode_ext (mn : MNode cp) (slot : ℕ) (m₁ m₂ : ArithRAMMemory)
    (henc : L.EncNode mn slot m₁)
    (hw : ∀ t, 9 ≤ t → t < L.TW - 1 → ∀ i, H3a.wRead m₂ t i = H3a.wRead m₁ t i)
    (hr : ∀ t, 3 ≤ t → t < L.TR → ∀ i, H3a.rRead m₂ t i = H3a.rRead m₁ t i)
    (hpts : ∀ x ∈ mn.nd.curSet, x < cp.n → ∀ c : Fin d,
      H3a.rRead m₂ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) =
        H3a.rRead m₁ ptsRTbl (((x * d + c.val : ℕ) : ℤ))) :
    L.EncNode mn slot m₂ := by
  rcases henc with ⟨hS_lt, hm₁⟩
  have hm₂ : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) (memPtsOf d m₁) mn none m₂ :=
    EncManagedNode.mono_slice hm₁
      (fun i _ _ => hw L.nodeWTbl L.hNodeWTbl_lo L.hNodeWTbl_hi i)
      (fun i _ _ => hr L.nodeRTbl L.hNodeRTbl_lo L.hNodeRTbl_hi i)
      hpts
  refine ⟨hS_lt, EncManagedNode.pts_congr ?_ hm₂⟩
  intro x hx
  exact memPtsOf_congr d (hpts x hx (hS_lt x hx))

theorem NodeSlotLayout.slotsReady_of_slot_frame {slot : ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn' : MNode cp} {m₀ m₁ : ArithRAMMemory}
    (hsr₀ : L.SlotsReady m₀)
    (henc' : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) pts mn' none m₁)
    (hfr : RadFrameOutside L.nodeScrWTbl L.nodeScrRTbl
      L.nodeWTbl (L.slotBaseW slot) (L.nodeWStride : ℤ)
      L.nodeRTbl (L.slotBaseR slot) (L.nodeRStride : ℤ) m₀ m₁) :
    L.SlotsReady m₁ := by
  intro s hs
  by_cases hss : s = slot
  · subst hss
    exact ManagedNodeSlotReady.of_enc L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2 _ _ henc'
  · refine ManagedNodeSlotReady.mono_slice (hsr₀ s hs)
      (fun i hlo hhi => hfr.1 L.nodeWTbl i L.hne_nodeW (Or.inr ?_))
      (fun i hlo hhi => hfr.2 L.nodeRTbl i L.hne_nodeR (Or.inr ?_))
    · rw [← L.nodeWStride_cast] at hhi
      exact slotSlice_disj hss i hlo hhi
    · rw [← L.nodeRStride_cast] at hhi
      exact slotSlice_disj hss i hlo hhi

theorem NodeSlotLayout.encNode_other_of_slot_frame {slot s' : ℕ} {mn' : MNode cp}
    {m₀ m₁ : ArithRAMMemory}
    (hne : s' ≠ slot)
    (henc₀ : L.EncNode mn' s' m₀)
    (hfr : RadFrameOutside L.nodeScrWTbl L.nodeScrRTbl
      L.nodeWTbl (L.slotBaseW slot) (L.nodeWStride : ℤ)
      L.nodeRTbl (L.slotBaseR slot) (L.nodeRStride : ℤ) m₀ m₁) :
    L.EncNode mn' s' m₁ := by
  rcases henc₀ with ⟨hS_lt, hm₀⟩
  have h1_ne_scr : ptsRTbl ≠ L.nodeScrRTbl := by
    have := L.hNodeScrR_lo; unfold ptsRTbl; omega
  have h1_ne_tbl : ptsRTbl ≠ L.nodeRTbl := by
    have := L.hNodeRTbl_lo; unfold ptsRTbl; omega
  have hm₁ : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW s') (L.slotBaseR slot |> fun _ => L.slotBaseR s') (memPtsOf d m₀) mn' none m₁ :=
    EncManagedNode.mono_slice hm₀
      (fun i hlo hhi => by
        rw [← L.nodeWStride_cast] at hhi
        exact hfr.1 L.nodeWTbl i L.hne_nodeW (Or.inr (slotSlice_disj hne i hlo hhi)))
      (fun i hlo hhi => by
        rw [← L.nodeRStride_cast] at hhi
        exact hfr.2 L.nodeRTbl i L.hne_nodeR (Or.inr (slotSlice_disj hne i hlo hhi)))
      (fun _ _ _ _ => hfr.2 ptsRTbl _ h1_ne_scr (Or.inl h1_ne_tbl))
  refine ⟨hS_lt, EncManagedNode.pts_congr ?_ hm₁⟩
  intro x _
  exact memPtsOf_congr d (fun _ => hfr.2 ptsRTbl _ h1_ne_scr (Or.inl h1_ne_tbl))

theorem NodeSlotLayout.frame_low_tables {slot : ℕ} {m₀ m₁ : ArithRAMMemory}
    (hfr : RadFrameOutside L.nodeScrWTbl L.nodeScrRTbl
      L.nodeWTbl (L.slotBaseW slot) (L.nodeWStride : ℤ)
      L.nodeRTbl (L.slotBaseR slot) (L.nodeRStride : ℤ) m₀ m₁) :
    (∀ t < 9, ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
    (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i) := by
  have h1 := L.hNodeWTbl_lo; have h2 := L.hNodeScrW_lo
  have h3 := L.hNodeRTbl_lo; have h4 := L.hNodeScrR_lo
  exact ⟨fun t ht i => hfr.1 t i (by omega) (Or.inl (by omega)),
         fun t ht i => hfr.2 t i (by omega) (Or.inl (by omega))⟩

/-! ### 3. `slotOpenEmptyStmt` (`openEmptyStmt`) & `slotBumpAgeStmt` (`bumpAgeStmt`) -/

def NodeSlotLayout.slotOpenEmptyCost : ℕ :=
  500 + 95 * d + cp.N_cfg * (L.cmOps.clearCost + 40)

def NodeSlotLayout.slotOpenEmptyStmt (sR mR : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap L.nodeScrWTbl (.lit 0)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))))
  (.seq (.writeWordHeap L.nodeScrWTbl (.lit 1)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeRStride : ℤ))))
  (.seq (.writeWordHeap L.nodeScrWTbl (.lit 2) (.readHeap engScrTbl (.lit mR)))
  (.seq (copyCenterHeightStmt L.nodeScrWTbl L.nodeScrRTbl 3 d)
        (managedNodeOpenEmptyStmt L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
          0 1 2 0 4 ((d : ℤ) + 1)))))

theorem NodeSlotLayout.zeroRand_slotOpenEmptyStmt (sR mR : ℤ) :
    ZeroRandStmt (L.slotOpenEmptyStmt sR mR) := by
  unfold NodeSlotLayout.slotOpenEmptyStmt
  exact .seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
    (.seq (hzr_to_zeroRand (hzr_copyCenterHeightStmt _ _ _ _))
          (zeroRand_managedNodeOpenEmptyStmt L.cmOps cp.specs _ _ _ _ _ _ _ _))))

theorem NodeSlotLayout.exec_slotOpenEmptyStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (slot m₀_sz : ℕ) (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (P₀ : Finset ℕ) (sR mR : ℤ)
    (hslot : slot < M_slots cp) (_hm₀ : m₀_sz ≤ cp.n)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64) (_hmR0 : 0 ≤ mR) (_hmR64 : mR < 64)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ))
    (hmR_v : H3a.wRead m₀ engScrTbl mR = (m₀_sz : ℤ))
    (ho_in : ∀ c : Fin d, H3a.rRead m₀ engRealTbl (16 + (c.val : ℤ)) = euclideanCoord o c)
    (hs_in : H3a.rRead m₀ engRealTbl (16 + (d : ℤ)) = s) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotOpenEmptyStmt sR mR) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        L.EncNode (ManagedNode.openEmpty cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b cp.N_cfg
          cp.T_cdf cp.p_coord o s P₀ m₀_sz) slot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ slot → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      L.slotOpenEmptyCost := by
  have hscrW : L.nodeScrWTbl < L.TW := L.hNodeScrW_hi
  have hscrR : L.nodeScrRTbl < L.TR := L.hNodeScrR_hi
  have hne_engW : engScrTbl ≠ L.nodeScrWTbl := by
    have := L.hNodeScrW_lo; unfold engScrTbl; omega
  have hne_engR : engRealTbl ≠ L.nodeScrRTbl := by
    have := L.hNodeScrR_lo; unfold engRealTbl; omega
  have hBW64 : 64 + L.cmOps.opWScrStride.toNat ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  have hBR16 : d + 16 + L.cmOps.opRScrStride.toNat ≤ L.BR := by unfold NodeSlotLayout.BR; omega
  have hCostInner : managedNodeOpenEmptyCost L.cmOps cp.N_cfg ≤
      L.slotOpenEmptyCost - (12 + 12 + 12 + (35 + 35 * d)) := by
    unfold managedNodeOpenEmptyCost NodeSlotLayout.slotOpenEmptyCost; omega
  unfold NodeSlotLayout.slotOpenEmptyStmt
  refine ExecDet.seq' (12 + 12 + (35 + 35 * d) + managedNodeOpenEmptyCost L.cmOps cp.N_cfg)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 0)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))) 0 (L.slotBaseW slot)
      hfp₀ hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead m₀ engScrTbl sR * _ = _
          rw [hsR_v, ← L.slotBaseW_eq_mul])
      (by simp [intExprOps]))
    (by unfold managedNodeOpenEmptyCost NodeSlotLayout.slotOpenEmptyCost; omega) ?_
  intro mA hmA hfpA; subst hmA
  refine ExecDet.seq' (12 + (35 + 35 * d) + managedNodeOpenEmptyCost L.cmOps cp.N_cfg)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 1)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeRStride : ℤ))) 1 (L.slotBaseR slot)
      hfpA hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead _ engScrTbl sR * _ = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_engW), hsR_v, ← L.slotBaseR_eq_mul])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mB hmB hfpB; subst hmB
  refine ExecDet.seq' ((35 + 35 * d) + managedNodeOpenEmptyCost L.cmOps cp.N_cfg)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 2) (.readHeap engScrTbl (.lit mR)) 2 (m₀_sz : ℤ)
      hfpB hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead _ engScrTbl mR = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_engW),
              wRead_wWrite_of_ne _ _ (Or.inl hne_engW), hmR_v])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mC hmC hfpC; subst hmC
  refine ExecDet.seq' (managedNodeOpenEmptyCost L.cmOps cp.N_cfg)
    (exec_copyCenterHeightStmt inp 3 o s hfpC hscrW hscrR hne_engR
      ⟨by omega, by omega⟩ (by omega)
      (fun c => ho_in c) hs_in)
    (by omega) ?_
  intro mD ⟨ho_D, hs_D, hw_D, hwt_D, hrt_D⟩ hfpD
  have hbW_D : H3a.wRead mD L.nodeScrWTbl 0 = L.slotBaseW slot := by
    rw [hw_D 0 (by decide), wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
  have hbR_D : H3a.wRead mD L.nodeScrWTbl 1 = L.slotBaseR slot := by
    rw [hw_D 1 (by decide), wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
  have hbsz_D : H3a.wRead mD L.nodeScrWTbl 2 = (m₀_sz : ℤ) := by
    rw [hw_D 2 (by decide), wRead_wWrite_self]
  have hw0D : ∀ t, t ≠ L.nodeScrWTbl → ∀ i, H3a.wRead mD t i = H3a.wRead m₀ t i := by
    intro t ht i
    rw [hwt_D t ht i]
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
  have hr0D : ∀ t, t ≠ L.nodeScrRTbl → ∀ i, H3a.rRead mD t i = H3a.rRead m₀ t i := hrt_D
  have hrdy_D : ManagedNodeSlotReady L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) mD :=
    ManagedNodeSlotReady.mono_slice (hsr₀ slot hslot)
      (fun i _ _ => hw0D L.nodeWTbl L.hne_nodeW i)
      (fun i _ _ => hr0D L.nodeRTbl L.hne_nodeR i)
  have hwScr_B : (4 : ℤ) + managedNodeOpenEmptyWScr L.cmOps ≤ (L.BW : ℤ) := by
    unfold managedNodeOpenEmptyWScr
    rw [← L.opWScr_cast]
    omega
  have hrScr_B : ((d : ℤ) + 1) + managedNodeOpenEmptyRScr L.cmOps ≤ (L.BR : ℤ) := by
    unfold managedNodeOpenEmptyRScr
    rw [← L.opRScr_cast]
    omega
  obtain ⟨m₁, hdet, hfp₁, henc₁, _, hfrD₁⟩ :=
    exec_managedNodeOpenEmptyStmt L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2 inp
      0 1 2 0 4 ((d : ℤ) + 1) (L.slotBaseW slot) (L.slotBaseR slot)
      (memPtsOf d mD) o s P₀ m₀_sz hfpD L.validTables
      (L.slotBaseW_bounds hslot) (L.slotBaseR_bounds hslot)
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      ⟨by omega, hwScr_B⟩ ⟨by omega, by omega⟩ ⟨by omega, hrScr_B⟩
      hbW_D hbR_D hbsz_D
      (fun c => by rw [zero_add]; exact ho_D c)
      (by rw [zero_add]; exact hs_D)
      hrdy_D
  have hfr01 : RadFrameOutside L.nodeScrWTbl L.nodeScrRTbl
      L.nodeWTbl (L.slotBaseW slot) (L.nodeWStride : ℤ)
      L.nodeRTbl (L.slotBaseR slot) (L.nodeRStride : ℤ) m₀ m₁ := by
    rw [L.nodeWStride_cast, L.nodeRStride_cast]
    exact ⟨fun t i hs hout => (hfrD₁.1 t i hs hout).trans (hw0D t hs i),
           fun t i hs hout => (hfrD₁.2 t i hs hout).trans (hr0D t hs i)⟩
  have hcur_empty : ∀ x ∈ (ManagedNode.openEmpty cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b cp.N_cfg
      cp.T_cdf cp.p_coord o s P₀ m₀_sz).nd.curSet, x < cp.n := by
    intro x hx
    simp [ManagedNode.openEmpty, NodeInst.openEmpty, NodeInst.curSet] at hx
  have henc₁_m₁ : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) (memPtsOf d m₁)
      (ManagedNode.openEmpty cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b cp.N_cfg
        cp.T_cdf cp.p_coord o s P₀ m₀_sz) none m₁ :=
    EncManagedNode.pts_congr (fun x hx => absurd (hcur_empty x hx) (by
      simp [ManagedNode.openEmpty, NodeInst.openEmpty, NodeInst.curSet] at hx)) henc₁
  obtain ⟨hlowW, hlowR⟩ := L.frame_low_tables hfr01
  exact detExec_to_execDet
    (hzr_managedNodeOpenEmptyStmt L.cmHzr cp.specs (4 * cp.n + 4) cp.L_p2 0 1 2 0 4 ((d : ℤ) + 1))
    hfpD hfp₁ hdet
    ⟨L.slotsReady_of_slot_frame hsr₀ henc₁_m₁ hfr01,
     ⟨hcur_empty, henc₁_m₁⟩,
     fun mn' s' _ hne he => L.encNode_other_of_slot_frame hne he hfr01,
     hlowW, hlowR⟩

def NodeSlotLayout.slotBumpAgeStmt (sR : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap L.nodeScrWTbl (.lit 0)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))))
       (managedNodeBumpAgeStmt L.nodeScrWTbl L.nodeWTbl 0)

theorem NodeSlotLayout.zeroRand_slotBumpAgeStmt (sR : ℤ) :
    ZeroRandStmt (L.slotBumpAgeStmt sR) :=
  .seq (.writeWordHeap _ _ _) (zeroRand_managedNodeBumpAgeStmt _ _ _)

theorem NodeSlotLayout.exec_slotBumpAgeStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot : ℕ) (sR : ℤ)
    (hslot : slot < M_slots cp) (_hage : mn.nd.age + 1 ≤ 4 * cp.n + 4)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ)) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotBumpAgeStmt sR) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        L.EncNode mn.bumpAge slot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ slot → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      50 := by
  have hscrW : L.nodeScrWTbl < L.TW := L.hNodeScrW_hi
  have hBW64 : 64 ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  unfold NodeSlotLayout.slotBumpAgeStmt
  refine ExecDet.seq' 25
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 0)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))) 0 (L.slotBaseW slot)
      hfp₀ hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead m₀ engScrTbl sR * _ = _
          rw [hsR_v, ← L.slotBaseW_eq_mul])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mA hmA hfpA; subst hmA
  rcases henc₀ with ⟨hS_lt, hm₀⟩
  have hmA : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) (memPtsOf d m₀) mn none
      (H3a.wWrite m₀ L.nodeScrWTbl 0 (L.slotBaseW slot)) :=
    EncManagedNode.mono_slice hm₀
      (fun _ _ _ => wRead_wWrite_of_ne _ _ (Or.inl L.hne_nodeW))
      (fun _ _ _ => rfl)
      (fun _ _ _ _ => rfl)
  obtain ⟨m₁, hdet, hfp₁, henc₁, _, _, hfrA₁⟩ :=
    exec_managedNodeBumpAgeStmt L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2 inp
      0 (L.slotBaseW slot) (L.slotBaseR slot) hfpA L.validTables
      (L.slotBaseW_bounds hslot) (wRead_wWrite_self _ _ _ _) hmA
  have hfr01 : RadFrameOutside L.nodeScrWTbl L.nodeScrRTbl
      L.nodeWTbl (L.slotBaseW slot) (L.nodeWStride : ℤ)
      L.nodeRTbl (L.slotBaseR slot) (L.nodeRStride : ℤ) m₀ m₁ := by
    have hfrA₁' : RadFrameOutside L.nodeScrWTbl L.nodeScrRTbl
        L.nodeWTbl (L.slotBaseW slot) (L.nodeWStride : ℤ)
        L.nodeRTbl (L.slotBaseR slot) (L.nodeRStride : ℤ)
        (H3a.wWrite m₀ L.nodeScrWTbl 0 (L.slotBaseW slot)) m₁ := by
      rw [L.nodeWStride_cast]
      exact RadFrameOutside_mono_range hfrA₁ (Or.inr ⟨le_rfl, le_rfl⟩) (Or.inl rfl)
    exact ⟨fun t i hs hout => (hfrA₁'.1 t i hs hout).trans (wRead_wWrite_of_ne _ _ (Or.inl hs)),
           fun t i hs hout => hfrA₁'.2 t i hs hout⟩
  have h1_ne_scr : ptsRTbl ≠ L.nodeScrRTbl := by have := L.hNodeScrR_lo; unfold ptsRTbl; omega
  have h1_ne_tbl : ptsRTbl ≠ L.nodeRTbl := by have := L.hNodeRTbl_lo; unfold ptsRTbl; omega
  have henc₁_m₁ : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) (memPtsOf d m₁) mn.bumpAge none m₁ :=
    EncManagedNode.pts_congr
      (fun _ _ => memPtsOf_congr d (fun _ => hfr01.2 ptsRTbl _ h1_ne_scr (Or.inl h1_ne_tbl)))
      henc₁
  obtain ⟨hlowW, hlowR⟩ := L.frame_low_tables hfr01
  exact detExec_to_execDet (hzr_managedNodeBumpAgeStmt _ _ _) hfpA hfp₁ hdet
    ⟨L.slotsReady_of_slot_frame hsr₀ henc₁_m₁ hfr01,
     ⟨hS_lt, henc₁_m₁⟩,
     fun mn' s' _ hne he => L.encNode_other_of_slot_frame hne he hfr01,
     hlowW, hlowR⟩

end SlotOps

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
