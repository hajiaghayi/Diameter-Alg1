import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInstA1c

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

section SlotReadOps2

variable {d : ℕ} {params : LocalScaleParams} {h : ℝ}
variable {cp : ChainParams d params h} (L : NodeSlotLayout cp)

/-! #### 5.4 `slotContainsNodeArrStmt` -/

def NodeSlotLayout.slotContainsNodeArrStmt (useRes : Bool) (sR xR oR : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap L.nodeScrWTbl (.lit 0)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))))
  (.seq (.writeWordHeap L.nodeScrWTbl (.lit 1) (.readHeap engScrTbl (.lit xR)))
  (.seq (managedNodeContainsStmt useRes L.nodeScrWTbl L.nodeWTbl 0 1 2 3 cp.n)
        (.writeWordHeap engScrTbl (.lit oR) (.readHeap L.nodeScrWTbl (.lit 2)))))

theorem NodeSlotLayout.zeroRand_slotContainsNodeArrStmt (useRes : Bool) (sR xR oR : ℤ) :
    ZeroRandStmt (L.slotContainsNodeArrStmt useRes sR xR oR) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
      (.seq (zeroRand_managedNodeContainsStmt _ _ _ _ _ _ _ _) (.writeWordHeap _ _ _)))

theorem NodeSlotLayout.exec_slotContainsNodeArrStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
    (slot x : ℕ) (useRes : Bool) (sR xR oR : ℤ)
    (_hslot : slot < M_slots cp) (_hS : ∀ y ∈ mn.nd.curSet, y < cp.n)
    (_hwf : ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts mn)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (_hxR0 : 0 ≤ xR) (_hxR64 : xR < 64)
    (hoR0 : 0 ≤ oR) (hoR64 : oR < 64)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ))
    (hxR_v : H3a.wRead m₀ engScrTbl xR = (x : ℤ)) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotContainsNodeArrStmt useRes sR xR oR) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        H3a.wRead m₁ engScrTbl oR =
          (if (if useRes then mn.resArr else mn.nd.denseArr).contains x then 1 else 0) ∧
        (∀ mn' s', s' < M_slots cp → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ i, i ≠ oR → H3a.wRead m₁ engScrTbl i = H3a.wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      L.slotReadCost := by
  have hscrW : L.nodeScrWTbl < L.TW := L.hNodeScrW_hi
  have hT_eng : engScrTbl < L.TW := by have := L.hTW; unfold engScrTbl; omega
  have hBW64 : 64 ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  have hne_eng : engScrTbl ≠ L.nodeScrWTbl := by have := L.hNodeScrW_lo; unfold engScrTbl; omega
  unfold NodeSlotLayout.slotContainsNodeArrStmt
  refine ExecDet.seq' (12 + 115 + 12)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 0)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))) 0 (L.slotBaseW slot)
      hfp₀ hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead m₀ engScrTbl sR * _ = _
          rw [hsR_v, ← L.slotBaseW_eq_mul])
      (by simp [intExprOps]))
    (by unfold NodeSlotLayout.slotReadCost; omega) ?_
  intro mA hmA hfpA; subst hmA
  refine ExecDet.seq' (115 + 12)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 1) (.readHeap engScrTbl (.lit xR)) 1 (x : ℤ)
      hfpA hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead _ engScrTbl xR = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_eng), hxR_v])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mB hmB hfpB; subst hmB
  have hmB_enc : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) (memPtsOf d m₀) mn none
      (H3a.wWrite (H3a.wWrite m₀ L.nodeScrWTbl 0 (L.slotBaseW slot)) L.nodeScrWTbl 1 (x : ℤ)) :=
    EncManagedNode.mono_slice henc₀.2
      (fun _ _ _ => by iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl L.hne_nodeW)])
      (fun _ _ _ => rfl) (fun _ _ _ _ => rfl)
  obtain ⟨mC, hdetC, hfpC, houtC, hfrBC⟩ :=
    exec_managedNodeContainsStmt useRes (by have := cp.hn; omega) L.cmOps cp.specs
      (4 * cp.n + 4) cp.L_p2 inp 0 1 2 3 (L.slotBaseW slot) (L.slotBaseR slot) x
      hfpB L.validTables
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
      (wRead_wWrite_self _ _ _ _) hmB_enc
  obtain ⟨hwBC, hrBC⟩ := radFrame_zero_eq hfrBC
  refine ExecDet.seq' (Mid := fun m =>
      H3a.wRead m L.nodeScrWTbl 2 =
        (if (if useRes then mn.resArr else mn.nd.denseArr).contains x then 1 else 0) ∧
      (∀ t, t ≠ L.nodeScrWTbl → ∀ i, H3a.wRead m t i = H3a.wRead m₀ t i) ∧
      (∀ t, t ≠ L.nodeScrRTbl → ∀ i, H3a.rRead m t i = H3a.rRead m₀ t i)) 12
    (detExec_to_execDet (hzr_managedNodeContainsStmt useRes _ _ _ _ _ _ _) hfpB hfpC hdetC
      ⟨houtC,
       fun t ht i => by rw [hwBC t ht i]; iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)],
       hrBC⟩)
    (by omega) ?_
  intro mC' ⟨houtC', hw0C', hr0C'⟩ hfpC'
  refine ExecDet.wWrite inp engScrTbl (.lit oR) (.readHeap L.nodeScrWTbl (.lit 2))
    oR (if (if useRes then mn.resArr else mn.nd.denseArr).contains x then 1 else 0)
    hfpC' hT_eng hoR0 (by omega) rfl
    (by simp only [evalIntExpr]; change H3a.wRead mC' L.nodeScrWTbl 2 = _; exact houtC')
    (by simp [intExprOps]) ?_
  have hne_node_eng : L.nodeWTbl ≠ engScrTbl := by
    have := L.hNodeWTbl_lo; unfold engScrTbl; omega
  have h1_ne_scrR : ptsRTbl ≠ L.nodeScrRTbl := by have := L.hNodeScrR_lo; unfold ptsRTbl; omega
  obtain ⟨hsr₁, henc₁⟩ := L.ro_preserve hsr₀
    (fun i => (wRead_wWrite_of_ne _ _ (Or.inl hne_node_eng)).trans (hw0C' L.nodeWTbl L.hne_nodeW i))
    (fun i => hr0C' L.nodeRTbl L.hne_nodeR i)
    (fun i => hr0C' ptsRTbl h1_ne_scrR i)
  have hscr_lo := L.hNodeScrW_lo; have hscrR_lo := L.hNodeScrR_lo
  exact ⟨hsr₁,
    wRead_wWrite_self _ _ _ _,
    henc₁,
    fun t ht9 hne_t i => (wRead_wWrite_of_ne _ _ (Or.inl hne_t)).trans (hw0C' t (by omega) i),
    fun i hne_i => (wRead_wWrite_of_ne _ _ (Or.inr hne_i)).trans (hw0C' engScrTbl hne_eng i),
    fun t ht3 i => hr0C' t (by omega) i⟩

/-! #### 5.6 `slotReadCfgStoredEdgeStmt` -/

def NodeSlotLayout.slotReadCfgStoredEdgeStmt (sR : ℤ) (cfgIdx : Fin cp.N_cfg)
    (hR u1R u2R : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap L.nodeScrWTbl (.lit 0)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))))
  (.seq (managedNodeReadCfgEdgeStmt L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2 cfgIdx 0 1 2 3 4)
  (.seq (.writeWordHeap engScrTbl (.lit hR) (.readHeap L.nodeScrWTbl (.lit 1)))
  (.seq (.writeWordHeap engScrTbl (.lit u1R) (.readHeap L.nodeScrWTbl (.lit 2)))
        (.writeWordHeap engScrTbl (.lit u2R) (.readHeap L.nodeScrWTbl (.lit 3))))))

theorem NodeSlotLayout.zeroRand_slotReadCfgStoredEdgeStmt (sR : ℤ) (cfgIdx : Fin cp.N_cfg)
    (hR u1R u2R : ℤ) :
    ZeroRandStmt (L.slotReadCfgStoredEdgeStmt sR cfgIdx hR u1R u2R) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_managedNodeReadCfgEdgeStmt L.cmOps cp.specs _ _ _ _ _ _ _ _)
      (.seq (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))

theorem NodeSlotLayout.exec_slotReadCfgStoredEdgeStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot : ℕ) (cfgIdx : Fin cp.N_cfg) (sR hR u1R u2R : ℤ)
    (hslot : slot < M_slots cp)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (hhR0 : 0 ≤ hR) (hhR64 : hR < 64)
    (hu1R0 : 0 ≤ u1R) (hu1R64 : u1R < 64)
    (hu2R0 : 0 ≤ u2R) (hu2R64 : u2R < 64)
    (hne1 : hR ≠ u1R) (hne2 : hR ≠ u2R) (hne3 : u1R ≠ u2R)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ)) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotReadCfgStoredEdgeStmt sR cfgIdx hR u1R u2R) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        (match (mn.nd.cfgs cfgIdx).st.storedEdge with
         | none => H3a.wRead m₁ engScrTbl hR = 0
         | some (u, v) =>
             H3a.wRead m₁ engScrTbl hR = 1 ∧
             H3a.wRead m₁ engScrTbl u1R = (u : ℤ) ∧
             H3a.wRead m₁ engScrTbl u2R = (v : ℤ)) ∧
        (∀ mn' s', s' < M_slots cp → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ i, i ≠ hR → i ≠ u1R → i ≠ u2R → H3a.wRead m₁ engScrTbl i = H3a.wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      L.slotReadCost := by
  have hscrW : L.nodeScrWTbl < L.TW := L.hNodeScrW_hi
  have hT_eng : engScrTbl < L.TW := by have := L.hTW; unfold engScrTbl; omega
  have hBW64 : 64 + L.cmOps.opWScrStride.toNat ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  have hne_eng : engScrTbl ≠ L.nodeScrWTbl := by have := L.hNodeScrW_lo; unfold engScrTbl; omega
  have hwScr_B : (4 : ℤ) + 1 + L.cmOps.opWScrStride ≤ (L.BW : ℤ) := by
    rw [← L.opWScr_cast]
    omega
  unfold NodeSlotLayout.slotReadCfgStoredEdgeStmt
  refine ExecDet.seq' ((L.cmOps.readEdgeCost + 25) + 36)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 0)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))) 0 (L.slotBaseW slot)
      hfp₀ hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead m₀ engScrTbl sR * _ = _
          rw [hsR_v, ← L.slotBaseW_eq_mul])
      (by simp [intExprOps]))
    (by unfold NodeSlotLayout.slotReadCost; omega) ?_
  intro mA hmA hfpA; subst hmA
  have hmA_enc : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) (memPtsOf d m₀) mn none
      (H3a.wWrite m₀ L.nodeScrWTbl 0 (L.slotBaseW slot)) :=
    EncManagedNode.mono_slice henc₀.2
      (fun _ _ _ => wRead_wWrite_of_ne _ _ (Or.inl L.hne_nodeW))
      (fun _ _ _ => rfl) (fun _ _ _ _ => rfl)
  obtain ⟨mB, hdetB, hfpB, houtB, _, _, hfrAB⟩ :=
    exec_managedNodeReadCfgEdgeStmt L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2 cfgIdx inp
      0 1 2 3 4 (L.slotBaseW slot) (L.slotBaseR slot)
      hfpA L.validTables (L.slotBaseW_bounds hslot)
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      ⟨by decide, by decide, by decide⟩ ⟨by omega, hwScr_B⟩
      (wRead_wWrite_self _ _ _ _) hmA_enc
  obtain ⟨hwAB, hrAB⟩ := radFrame_zero_eq hfrAB
  refine ExecDet.seq' (Mid := fun m =>
      (match (mn.nd.cfgs cfgIdx).st.storedEdge with
       | none => H3a.wRead m L.nodeScrWTbl 1 = 0
       | some (u, v) =>
           H3a.wRead m L.nodeScrWTbl 1 = 1 ∧
           H3a.wRead m L.nodeScrWTbl 2 = (u : ℤ) ∧
           H3a.wRead m L.nodeScrWTbl 3 = (v : ℤ)) ∧
      (∀ t, t ≠ L.nodeScrWTbl → ∀ i, H3a.wRead m t i = H3a.wRead m₀ t i) ∧
      (∀ t, t ≠ L.nodeScrRTbl → ∀ i, H3a.rRead m t i = H3a.rRead m₀ t i)) 36
    (detExec_to_execDet (hzr_managedNodeReadCfgEdgeStmt L.cmHzr cp.specs _ _ cfgIdx _ _ _ _ _)
      hfpA hfpB hdetB
      ⟨houtB,
       fun t ht i => (hwAB t ht i).trans (wRead_wWrite_of_ne _ _ (Or.inl ht)),
       hrAB⟩)
    (by omega) ?_
  intro mB' ⟨houtB', hw0B', hr0B'⟩ hfpB'
  let v1 := H3a.wRead mB' L.nodeScrWTbl 1
  let v2 := H3a.wRead mB' L.nodeScrWTbl 2
  let v3 := H3a.wRead mB' L.nodeScrWTbl 3
  refine ExecDet.seq' 24
    (ExecDet.wWriteEq inp engScrTbl (.lit hR) (.readHeap L.nodeScrWTbl (.lit 1)) hR v1
      hfpB' hT_eng hhR0 (by omega) rfl rfl (by simp [intExprOps]))
    (by omega) ?_
  intro mC hmC hfpC; subst hmC
  refine ExecDet.seq' 12
    (ExecDet.wWriteEq inp engScrTbl (.lit u1R) (.readHeap L.nodeScrWTbl (.lit 2)) u1R v2
      hfpC hT_eng hu1R0 (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead _ L.nodeScrWTbl 2 = v2
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_eng.symm)])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mD hmD hfpD; subst hmD
  refine ExecDet.wWrite inp engScrTbl (.lit u2R) (.readHeap L.nodeScrWTbl (.lit 3)) u2R v3
    hfpD hT_eng hu2R0 (by omega) rfl
    (by simp only [evalIntExpr]; change H3a.wRead _ L.nodeScrWTbl 3 = v3
        iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl hne_eng.symm)])
    (by simp [intExprOps]) ?_
  have hne_node_eng : L.nodeWTbl ≠ engScrTbl := by
    have := L.hNodeWTbl_lo; unfold engScrTbl; omega
  have h1_ne_scrR : ptsRTbl ≠ L.nodeScrRTbl := by have := L.hNodeScrR_lo; unfold ptsRTbl; omega
  obtain ⟨hsr₁, henc₁⟩ := L.ro_preserve
    (m₁ := H3a.wWrite (H3a.wWrite (H3a.wWrite mB' engScrTbl hR v1) engScrTbl u1R v2) engScrTbl u2R v3) hsr₀
    (fun i => by
      iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl hne_node_eng)]
      exact hw0B' L.nodeWTbl L.hne_nodeW i)
    (fun i => hr0B' L.nodeRTbl L.hne_nodeR i)
    (fun i => hr0B' ptsRTbl h1_ne_scrR i)
  have hhR_out : H3a.wRead (H3a.wWrite (H3a.wWrite (H3a.wWrite mB' engScrTbl hR v1)
      engScrTbl u1R v2) engScrTbl u2R v3) engScrTbl hR = v1 := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr hne2), wRead_wWrite_of_ne _ _ (Or.inr hne1), wRead_wWrite_self]
  have hu1R_out : H3a.wRead (H3a.wWrite (H3a.wWrite (H3a.wWrite mB' engScrTbl hR v1)
      engScrTbl u1R v2) engScrTbl u2R v3) engScrTbl u1R = v2 := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr hne3), wRead_wWrite_self]
  have hu2R_out : H3a.wRead (H3a.wWrite (H3a.wWrite (H3a.wWrite mB' engScrTbl hR v1)
      engScrTbl u1R v2) engScrTbl u2R v3) engScrTbl u2R = v3 :=
    wRead_wWrite_self _ _ _ _
  have hscr_lo := L.hNodeScrW_lo; have hscrR_lo := L.hNodeScrR_lo
  refine ⟨hsr₁, ?_, henc₁,
    fun t ht9 hne_t i => by
      iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl hne_t)]
      exact hw0B' t (by omega) i,
    fun i hi1 hi2 hi3 => by
      rw [wRead_wWrite_of_ne _ _ (Or.inr hi3),
          wRead_wWrite_of_ne _ _ (Or.inr hi2),
          wRead_wWrite_of_ne _ _ (Or.inr hi1)]
      exact hw0B' engScrTbl hne_eng i,
    fun t ht3 i => hr0B' t (by omega) i⟩
  cases hedge : (mn.nd.cfgs cfgIdx).st.storedEdge with
  | none =>
      rw [hedge] at houtB'
      exact hhR_out.trans houtB'
  | some uv =>
      rcases uv with ⟨u, v⟩
      rw [hedge] at houtB'
      exact ⟨hhR_out.trans houtB'.1, hu1R_out.trans houtB'.2.1, hu2R_out.trans houtB'.2.2⟩

/-! #### 5.7 `slotReadMaxRadiusStmt` (Stage 4 `O(1)` Max-Radius Handle Sidecar) -/

def NodeSlotLayout.slotReadMaxRadiusStmt (sR hR yR : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap L.nodeScrWTbl (.lit 0)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))))
  (.seq (.writeWordHeap L.nodeScrWTbl (.lit 1)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeRStride : ℤ))))
  (.seq (managedNodeReadMaxRadiusStmt L.nodeScrWTbl L.nodeScrRTbl L.nodeWTbl L.nodeRTbl
          0 1 2 3 0 4 cp.n (4 * cp.n + 4) d)
  (.seq (.writeWordHeap engScrTbl (.lit hR) (.readHeap L.nodeScrWTbl (.lit 2)))
        (.writeWordHeap engScrTbl (.lit yR) (.readHeap L.nodeScrWTbl (.lit 3))))))

theorem NodeSlotLayout.zeroRand_slotReadMaxRadiusStmt (sR hR yR : ℤ) :
    ZeroRandStmt (L.slotReadMaxRadiusStmt sR hR yR) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
      (.seq (zeroRand_managedNodeReadMaxRadiusStmt _ _ _ _ _ _ _ _ _ _ _ _ _)
        (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))

theorem NodeSlotLayout.exec_slotReadMaxRadiusStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
    (slot : ℕ) (sR hR yR : ℤ)
    (_hslot : slot < M_slots cp)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (hhR0 : 0 ≤ hR) (hhR64 : hR < 64)
    (hyR0 : 0 ≤ yR) (hyR64 : yR < 64)
    (hne : hR ≠ yR)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ))
    (hpts : ∀ x ∈ mn.nd.curSet, ∀ c : Fin d,
      H3a.rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotReadMaxRadiusStmt sR hR yR) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        (match maxRadiusHandle cp.T_pow pts mn.nd.o mn.nd.denseArr.toFinset with
         | none =>
             H3a.wRead m₁ engScrTbl hR = 0 ∧
             H3a.wRead m₁ engScrTbl yR = 0
         | some y =>
             H3a.wRead m₁ engScrTbl hR = 1 ∧
             H3a.wRead m₁ engScrTbl yR = (y : ℤ)) ∧
        (∀ mn' s', s' < M_slots cp → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ i, i ≠ hR → i ≠ yR → H3a.wRead m₁ engScrTbl i = H3a.wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      200 := by
  have hscrW : L.nodeScrWTbl < L.TW := L.hNodeScrW_hi
  have hT_eng : engScrTbl < L.TW := by have := L.hTW; unfold engScrTbl; omega
  have hBW64 : 64 ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  have hBR16 : 16 ≤ L.BR := by unfold NodeSlotLayout.BR; omega
  have hne_eng : engScrTbl ≠ L.nodeScrWTbl := by have := L.hNodeScrW_lo; unfold engScrTbl; omega
  rcases henc₀ with ⟨hS_lt, hm₀⟩
  have hm₀_pts : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) pts mn none m₀ :=
    EncManagedNode.pts_congr
      (fun x hx => (memPtsOf_eq_of_coords m₀ x (pts x) (hpts x hx)).symm) hm₀
  unfold NodeSlotLayout.slotReadMaxRadiusStmt
  refine ExecDet.seq' (12 + 135 + 24)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 0)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))) 0 (L.slotBaseW slot)
      hfp₀ hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead m₀ engScrTbl sR * _ = _
          rw [hsR_v, ← L.slotBaseW_eq_mul])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mA hmA hfpA; subst hmA
  refine ExecDet.seq' (135 + 24)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 1)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeRStride : ℤ))) 1 (L.slotBaseR slot)
      hfpA hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead _ engScrTbl sR * _ = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_eng), hsR_v, ← L.slotBaseR_eq_mul])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mB hmB hfpB; subst hmB
  have hmB_pts : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) pts mn none
      (H3a.wWrite (H3a.wWrite m₀ L.nodeScrWTbl 0 (L.slotBaseW slot)) L.nodeScrWTbl 1 (L.slotBaseR slot)) :=
    EncManagedNode.mono_slice hm₀_pts
      (fun _ _ _ => by iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl L.hne_nodeW)])
      (fun _ _ _ => rfl) (fun _ _ _ _ => rfl)
  obtain ⟨mC, hdetC, hfpC, houtC, _, _, _, hfrBC⟩ :=
    exec_managedNodeReadMaxRadiusStmt L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2 cp.T_pow
      cp.hT_pow (by have := cp.hL_p2; omega) inp
      0 1 2 3 0 4 (L.slotBaseW slot) (L.slotBaseR slot)
      hS_lt hfpB L.validTables
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by decide) ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
      (wRead_wWrite_self _ _ _ _) hmB_pts
  obtain ⟨hwBC, hrBC⟩ := radFrame_zero_eq hfrBC
  refine ExecDet.seq' (Mid := fun m =>
      (match maxRadiusHandle cp.T_pow pts mn.nd.o mn.nd.denseArr.toFinset with
       | none =>
           H3a.wRead m L.nodeScrWTbl 2 = 0 ∧
           H3a.wRead m L.nodeScrWTbl 3 = 0 ∧
           H3a.rRead m L.nodeScrRTbl 0 = 0
       | some y =>
           H3a.wRead m L.nodeScrWTbl 2 = 1 ∧
           H3a.wRead m L.nodeScrWTbl 3 = (y : ℤ) ∧
           H3a.rRead m L.nodeScrRTbl 0 = ‖pts y - mn.nd.o‖ ^ 2) ∧
      (∀ t, t ≠ L.nodeScrWTbl → ∀ i, H3a.wRead m t i = H3a.wRead m₀ t i) ∧
      (∀ t, t ≠ L.nodeScrRTbl → ∀ i, H3a.rRead m t i = H3a.rRead m₀ t i)) 24
    (detExec_to_execDet (hzr_managedNodeReadMaxRadiusStmt _ _ _ _ _ _ _ _ _ _ _ _ _)
      hfpB hfpC hdetC
      ⟨houtC,
       fun t ht i => by rw [hwBC t ht i]; iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)],
       hrBC⟩)
    (by omega) ?_
  intro mC' ⟨houtC', hw0C', hr0C'⟩ hfpC'
  let vHas := H3a.wRead mC' L.nodeScrWTbl 2
  let vUid := H3a.wRead mC' L.nodeScrWTbl 3
  refine ExecDet.seq' 12
    (ExecDet.wWriteEq inp engScrTbl (.lit hR) (.readHeap L.nodeScrWTbl (.lit 2)) hR vHas
      hfpC' hT_eng hhR0 (by omega) rfl rfl (by simp [intExprOps]))
    (by omega) ?_
  intro mD hmD hfpD; subst hmD
  refine ExecDet.wWrite inp engScrTbl (.lit yR) (.readHeap L.nodeScrWTbl (.lit 3)) yR vUid
    hfpD hT_eng hyR0 (by omega) rfl
    (by simp only [evalIntExpr]; change H3a.wRead _ L.nodeScrWTbl 3 = vUid
        rw [wRead_wWrite_of_ne _ _ (Or.inl hne_eng.symm)])
    (by simp [intExprOps]) ?_
  have hne_node_eng : L.nodeWTbl ≠ engScrTbl := by
    have := L.hNodeWTbl_lo; unfold engScrTbl; omega
  have h1_ne_scrR : ptsRTbl ≠ L.nodeScrRTbl := by have := L.hNodeScrR_lo; unfold ptsRTbl; omega
  obtain ⟨hsr₁, henc₁⟩ := L.ro_preserve
    (m₁ := H3a.wWrite (H3a.wWrite mC' engScrTbl hR vHas) engScrTbl yR vUid) hsr₀
    (fun i => by
      iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl hne_node_eng)]
      exact hw0C' L.nodeWTbl L.hne_nodeW i)
    (fun i => hr0C' L.nodeRTbl L.hne_nodeR i)
    (fun i => hr0C' ptsRTbl h1_ne_scrR i)
  have hhR_out : H3a.wRead (H3a.wWrite (H3a.wWrite mC' engScrTbl hR vHas)
      engScrTbl yR vUid) engScrTbl hR = vHas := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr hne), wRead_wWrite_self]
  have hyR_out : H3a.wRead (H3a.wWrite (H3a.wWrite mC' engScrTbl hR vHas)
      engScrTbl yR vUid) engScrTbl yR = vUid :=
    wRead_wWrite_self _ _ _ _
  have hscr_lo := L.hNodeScrW_lo; have hscrR_lo := L.hNodeScrR_lo
  refine ⟨hsr₁, ?_, henc₁,
    fun t ht9 hne_t i => by
      iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl hne_t)]
      exact hw0C' t (by omega) i,
    fun i hi1 hi2 => by
      rw [wRead_wWrite_of_ne _ _ (Or.inr hi2),
          wRead_wWrite_of_ne _ _ (Or.inr hi1)]
      exact hw0C' engScrTbl hne_eng i,
    fun t ht3 i => hr0C' t (by omega) i⟩
  cases hmrad : maxRadiusHandle cp.T_pow pts mn.nd.o mn.nd.denseArr.toFinset with
  | none =>
      rw [hmrad] at houtC'
      exact ⟨hhR_out.trans houtC'.1, hyR_out.trans houtC'.2.1⟩
  | some y =>
      rw [hmrad] at houtC'
      exact ⟨hhR_out.trans houtC'.1, hyR_out.trans houtC'.2.1⟩

end SlotReadOps2

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
