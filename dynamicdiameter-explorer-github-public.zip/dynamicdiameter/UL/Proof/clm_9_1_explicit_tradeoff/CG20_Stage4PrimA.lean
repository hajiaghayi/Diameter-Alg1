import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H3a3_ExactScan
import UL.Proof.clm_9_1_explicit_tradeoff.H4c1_NodePrim
import UL.Proof.clm_9_1_explicit_tradeoff.H4c2_ChainSched
import UL.Proof.clm_9_1_explicit_tradeoff.CG19_LayoutA
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a3
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 1. Pure Fold Bridges for `evalExactLeafPair`, `evalBaselinePair`, `evalBestGlobalAnswer` -/

theorem foldl_congr_mem {α β : Type*} {xs : List β} {f₁ f₂ : α → β → α} (init : α)
    (h : ∀ a, ∀ x ∈ xs, f₁ a x = f₂ a x) :
    xs.foldl f₁ init = xs.foldl f₂ init := by
  induction xs generalizing init with
  | nil => rfl
  | cons x tl ih =>
      simp only [List.foldl_cons]
      rw [h init x List.mem_cons_self]
      exact ih _ (fun a y hy => h a y (List.mem_cons_of_mem _ hy))

theorem range_foldl_trim {α : Type*} (f : ℕ → α → α) (L : ℕ)
    (hnoop : ∀ i, L ≤ i → ∀ a, f i a = a) :
    ∀ (B : ℕ), L ≤ B → ∀ init : α,
      (List.range B).foldl (fun a i => f i a) init =
        (List.range L).foldl (fun a i => f i a) init := by
  intro B hLB
  obtain ⟨k, rfl⟩ := Nat.exists_eq_add_of_le hLB
  clear hLB
  induction k with
  | zero => intro init; simp
  | succ k ih =>
      intro init
      rw [Nat.add_succ, List.range_succ, List.foldl_append, List.foldl_cons, List.foldl_nil,
          hnoop (L + k) (Nat.le_add_right L k), ih]

theorem range_length_foldl_eq {α β : Type*} (g : α → β → α) (xs : List β) (init : α) :
    (List.range xs.length).foldl
      (fun a i => if hi : i < xs.length then g a (xs[i]'hi) else a) init =
    xs.foldl g init := by
  induction xs using List.reverseRecOn with
  | nil => simp
  | append_singleton ys y ih =>
      have hlen : (ys ++ [y]).length = ys.length + 1 := by simp
      have hrng : List.range (ys ++ [y]).length = List.range ys.length ++ [ys.length] := by
        rw [hlen, List.range_succ]
      rw [hrng, List.foldl_append, List.foldl_cons, List.foldl_nil, List.foldl_append,
          List.foldl_cons, List.foldl_nil]
      have hpre :
          (List.range ys.length).foldl
            (fun a i => if hi : i < (ys ++ [y]).length then g a ((ys ++ [y])[i]'hi) else a) init =
          (List.range ys.length).foldl
            (fun a i => if hi : i < ys.length then g a (ys[i]'hi) else a) init := by
        refine foldl_congr_mem init fun a i hi_mem => ?_
        have hi : i < ys.length := List.mem_range.mp hi_mem
        have hi' : i < (ys ++ [y]).length := by omega
        rw [dif_pos hi', dif_pos hi, List.getElem_append_left hi]
      have hlast : ys.length < (ys ++ [y]).length := by omega
      rw [hpre, ih, dif_pos hlast]
      congr 1
      simp [List.getElem_append_right (Nat.le_refl ys.length)]

noncomputable def stepOptPair {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (acc : Option (ℕ × ℕ)) (p : ℕ × ℕ) : Option (ℕ × ℕ) :=
  open Classical in
  match acc with
  | none => some p
  | some best =>
      if ‖pts best.1 - pts best.2‖ ^ 2 < ‖pts p.1 - pts p.2‖ ^ 2 then some p else some best

theorem foldl_stepOptPair_some {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d)) :
    ∀ (rest : List (ℕ × ℕ)) (p₀ : ℕ × ℕ),
      rest.foldl (stepOptPair pts) (some p₀) =
        some (open Classical in rest.foldl
          (fun best p =>
            if ‖pts best.1 - pts best.2‖ ^ 2 < ‖pts p.1 - pts p.2‖ ^ 2 then p else best) p₀)
  | [], _ => rfl
  | p :: ps, p₀ => by
      simp only [List.foldl_cons]
      dsimp only [stepOptPair]
      split_ifs with hlt <;> exact foldl_stepOptPair_some pts ps _

theorem evalExactLeafPair_eq_foldl {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (leafArr : List ℕ) :
    evalExactLeafPair pts leafArr =
      (leafArr.flatMap (fun u => (leafArr.filter (· ≠ u)).map (fun v => (u, v)))).foldl
        (stepOptPair pts) none := by
  unfold evalExactLeafPair
  by_cases hle : leafArr.length ≤ 1
  · rw [if_pos hle]
    cases leafArr with
    | nil => rfl
    | cons a tl =>
        cases tl with
        | nil => simp
        | cons b tl2 => simp at hle
  · rw [if_neg hle]
    set pairs := leafArr.flatMap (fun u => (leafArr.filter (· ≠ u)).map (fun v => (u, v)))
    cases pairs with
    | nil => rfl
    | cons p₀ rest =>
        simp only [List.foldl_cons]
        dsimp only [stepOptPair]
        exact (foldl_stepOptPair_some pts rest p₀).symm

noncomputable def leafInnerFold {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (leafArr : List ℕ) (u : ℕ) (k : ℕ) (acc : Option (ℕ × ℕ)) : Option (ℕ × ℕ) :=
  (List.range k).foldl (fun cur iv =>
    if hiv : iv < leafArr.length then
      let v := leafArr[iv]'hiv
      if v ≠ u then stepOptPair pts cur (u, v) else cur
    else cur) acc

noncomputable def leafOuterFold {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (leafArr : List ℕ) (B : ℕ) (k : ℕ) : Option (ℕ × ℕ) :=
  (List.range k).foldl (fun cur iu =>
    if hiu : iu < leafArr.length then
      leafInnerFold pts leafArr (leafArr[iu]'hiu) B cur
    else cur) none

private lemma foldl_filter_ne_map {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d)) (u : ℕ) :
    ∀ (xs : List ℕ) (acc : Option (ℕ × ℕ)),
      xs.foldl (fun cur v => if v ≠ u then stepOptPair pts cur (u, v) else cur) acc =
        ((xs.filter (· ≠ u)).map (fun v => (u, v))).foldl (stepOptPair pts) acc
  | [], _ => rfl
  | v :: vs, acc => by
      rw [List.foldl_cons, List.filter_cons]
      by_cases hne : v ≠ u
      · rw [if_pos hne, if_pos (decide_eq_true hne), List.map_cons, List.foldl_cons]
        exact foldl_filter_ne_map pts u vs _
      · rw [if_neg hne, if_neg (by simp [hne])]
        exact foldl_filter_ne_map pts u vs _

private lemma foldl_flatMap_eq {α β γ : Type*} (f : α → γ → α) (g : β → List γ) :
    ∀ (xs : List β) (acc : α),
      (xs.flatMap g).foldl f acc = xs.foldl (fun a x => (g x).foldl f a) acc
  | [], _ => rfl
  | x :: xs, acc => by
      simp only [List.flatMap_cons, List.foldl_append, List.foldl_cons]
      exact foldl_flatMap_eq f g xs _

theorem leafOuterFold_eq_evalExactLeafPair {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) {leafArr : List ℕ} {B : ℕ}
    (hB : leafArr.length ≤ B) :
    leafOuterFold pts leafArr B B = evalExactLeafPair pts leafArr := by
  have hInner : ∀ u acc,
      leafInnerFold pts leafArr u B acc =
        ((leafArr.filter (· ≠ u)).map (fun v => (u, v))).foldl (stepOptPair pts) acc := by
    intro u acc
    unfold leafInnerFold
    rw [range_foldl_trim
      (fun iv cur => if hiv : iv < leafArr.length then
        let v := leafArr[iv]'hiv; if v ≠ u then stepOptPair pts cur (u, v) else cur else cur)
      leafArr.length (fun iv hiv cur => dif_neg (Nat.not_lt.mpr hiv)) B hB acc]
    rw [range_length_foldl_eq
      (fun cur v => if v ≠ u then stepOptPair pts cur (u, v) else cur) leafArr acc]
    exact foldl_filter_ne_map pts u leafArr acc
  unfold leafOuterFold
  rw [range_foldl_trim
    (fun iu cur => if hiu : iu < leafArr.length then
      leafInnerFold pts leafArr (leafArr[iu]'hiu) B cur else cur)
    leafArr.length (fun iu hiu cur => dif_neg (Nat.not_lt.mpr hiu)) B hB none]
  have hcongr :
      (List.range leafArr.length).foldl
        (fun cur iu => if hiu : iu < leafArr.length then
          leafInnerFold pts leafArr (leafArr[iu]'hiu) B cur else cur) none =
      (List.range leafArr.length).foldl
        (fun cur iu => if hiu : iu < leafArr.length then
          ((leafArr.filter (· ≠ (leafArr[iu]'hiu))).map (fun v => (leafArr[iu]'hiu, v))).foldl
            (stepOptPair pts) cur else cur) none := by
    refine foldl_congr_mem none fun cur iu _ => ?_
    split_ifs with hiu
    · exact hInner _ cur
    · rfl
  rw [hcongr, range_length_foldl_eq
    (fun cur u => ((leafArr.filter (· ≠ u)).map (fun v => (u, v))).foldl (stepOptPair pts) cur)
    leafArr none, ← foldl_flatMap_eq, evalExactLeafPair_eq_foldl]

/-! ### 2. Pure Baseline Fold Bridge (`farthestValStep`) -/

noncomputable def farthestValList {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d)) (y : ℕ) :
    ℕ → List ℕ → ℕ
  | best, [] => best
  | best, x :: xs =>
      open Classical in
      farthestValList pts y (if ‖pts best - pts y‖ ^ 2 < ‖pts x - pts y‖ ^ 2 then x else best) xs

theorem samp_farthestIdxList {d k_base : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (y : ℕ) (samp : Fin k_base → ℕ) :
    ∀ (best : Fin k_base) (ls : List (Fin k_base)),
      samp (farthestIdxList pts y samp best ls) =
        farthestValList pts y (samp best) (ls.map samp)
  | best, [] => rfl
  | best, j :: js => by
      dsimp only [farthestIdxList, List.map_cons, farthestValList]
      rw [samp_farthestIdxList pts y samp]
      congr 1
      split_ifs <;> rfl

theorem farthestValList_eq_foldl {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d)) (y : ℕ) :
    ∀ (xs : List ℕ) (best : ℕ),
      farthestValList pts y best xs =
        xs.foldl (fun b x =>
          open Classical in if ‖pts b - pts y‖ ^ 2 < ‖pts x - pts y‖ ^ 2 then x else b) best
  | [], _ => rfl
  | x :: xs, best => by
      simp only [farthestValList, List.foldl_cons]
      exact farthestValList_eq_foldl pts y xs _

noncomputable def farthestValStep {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d)) (y : ℕ)
    (j : ℕ) (best : ℕ) (xj : ℕ) : ℕ :=
  open Classical in
  if j = 0 ∨ ‖pts best - pts y‖ ^ 2 < ‖pts xj - pts y‖ ^ 2 then xj else best

theorem range_farthestValStep_eq {d k_base : ℕ} (hk : 1 ≤ k_base)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (y : ℕ) (samp : Fin k_base → ℕ) (init : ℕ) :
    (List.range k_base).foldl
      (fun best j => if hj : j < k_base then farthestValStep pts y j best (samp ⟨j, hj⟩) else best)
      init =
    samp (farthestIdxList pts y samp ⟨0, hk⟩ (List.finRange k_base)) := by
  cases k_base with
  | zero => omega
  | succ m =>
      have hk0 : (⟨0, hk⟩ : Fin (m + 1)) = 0 := rfl
      rw [hk0, samp_farthestIdxList pts y samp, List.finRange_succ, List.map_cons, farthestValList,
          if_neg (lt_irrefl _), farthestValList_eq_foldl, List.range_succ_eq_map,
          List.foldl_cons, dif_pos (Nat.zero_lt_succ m)]
      have h0 : farthestValStep pts y 0 init (samp ⟨0, Nat.zero_lt_succ m⟩) =
          samp (0 : Fin (m + 1)) := by
        unfold farthestValStep
        rw [if_pos (Or.inl rfl)]
        rfl
      rw [h0, List.foldl_map, List.map_map, List.foldl_map]
      have hlen : (List.finRange m).map Fin.val = List.range m := by
        apply List.ext_getElem (by simp)
        intro i hi1 hi2; simp
      rw [← hlen, List.foldl_map]
      refine foldl_congr_mem (samp (0 : Fin (m + 1))) fun b j _ => ?_
      have hj_lt : j.val + 1 < m + 1 := Nat.succ_lt_succ j.isLt
      rw [dif_pos hj_lt]
      unfold farthestValStep
      have hfin : (⟨j.val + 1, hj_lt⟩ : Fin (m + 1)) = j.succ := rfl
      rw [hfin]
      dsimp only [Function.comp_apply]
      by_cases hlt : ‖pts b - pts y‖ ^ 2 < ‖pts (samp j.succ) - pts y‖ ^ 2
      · rw [if_pos (Or.inr hlt), if_pos hlt]
      · rw [if_neg (by rintro (h | h); exact Nat.succ_ne_zero j.val h; exact hlt h), if_neg hlt]

/-! ### 3. Pure Global Candidate Fold Bridge (`stepBestGlobal`) -/

noncomputable def stepBestGlobal {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (actList : List ℕ)
    (cur : ℕ × ℕ) (opt : Option (ℕ × ℕ)) : ℕ × ℕ :=
  open Classical in
  match opt with
  | none => cur
  | some (u, v) =>
      if u ≠ v ∧ actList.contains u = true ∧ actList.contains v = true ∧
          ‖pts cur.1 - pts cur.2‖ ^ 2 < ‖pts u - pts v‖ ^ 2 then
        (u, v)
      else
        cur

theorem evalBestGlobalAnswer_of_ge_two {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) {actList : List ℕ}
    (h2 : 2 ≤ actList.length) (cands : List (Option (ℕ × ℕ))) :
    evalBestGlobalAnswer pts actList cands =
      let init : ℕ × ℕ := (actList[0]'(by omega), actList[1]'(by omega))
      let best := cands.foldl (stepBestGlobal pts actList) init
      { diameterHandles := some best, cachedDistSq := ‖pts best.1 - pts best.2‖ ^ 2 } := by
  unfold evalBestGlobalAnswer
  rw [dif_pos h2]
  rfl

theorem evalBestGlobalAnswer_of_lt_two {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) {actList : List ℕ}
    (h2 : ¬ 2 ≤ actList.length) (cands : List (Option (ℕ × ℕ))) :
    evalBestGlobalAnswer pts actList cands =
      { diameterHandles := none, cachedDistSq := 0 } := by
  unfold evalBestGlobalAnswer
  rw [dif_neg h2]

/-! ### 4. Option-Pair Encoding & Atomic Stage-4 RAM Primitives -/

theorem ExecDet.ite_le {d TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (cond : ArithCondExpr) (tB fB : ArithRAMStmt)
    {m₀ : ArithRAMMemory} {Post : ArithRAMMemory → Prop} {C_c C_b C : ℕ}
    (huc : condExprOps cond ≤ C_c)
    (ht : (evalArithCond inp 0 m₀ cond).1 = true → ExecDet TW BW TR BR inp tB m₀ Post C_b)
    (hf : (evalArithCond inp 0 m₀ cond).1 = false → ExecDet TW BW TR BR inp fB m₀ Post C_b)
    (hC : C_c + C_b ≤ C := by omega) :
    ExecDet TW BW TR BR inp (.ite cond tB fB) m₀ Post C :=
  (ExecDet.ite cond tB fB huc ht hf).mono (fun _ h _ => h) hC

def EncOptPair (hasR uR vR : ℤ) (opt : Option (ℕ × ℕ)) (mem : ArithRAMMemory) : Prop :=
  match opt with
  | none => wRead mem engScrTbl hasR = 0
  | some (u, v) =>
      wRead mem engScrTbl hasR = 1 ∧
      wRead mem engScrTbl uR = (u : ℤ) ∧
      wRead mem engScrTbl vR = (v : ℤ)

def EncOptSingle (hasR yR : ℤ) (opt : Option ℕ) (mem : ArithRAMMemory) : Prop :=
  match opt with
  | none => wRead mem engScrTbl hasR = 0
  | some y =>
      wRead mem engScrTbl hasR = 1 ∧
      wRead mem engScrTbl yR = (y : ℤ)

def pairDistSqStmt (uReg vReg outRIdx : ℤ) (d : ℕ) : ArithRAMStmt :=
  .seq (.writeRealHeap engRealTbl (.lit 7) (.ofInt (.lit 0)))
  (.seq
    (forLoopStmt engScrTbl 40 d
      (.seq
        (.writeRealHeap engRealTbl (.lit 6)
          (.sub
            (.readRealHeap ptsRTbl (.add (.mul (.readHeap engScrTbl (.lit uReg)) (.lit (d : ℤ)))
                                         (.readHeap engScrTbl (.lit 40))))
            (.readRealHeap ptsRTbl (.add (.mul (.readHeap engScrTbl (.lit vReg)) (.lit (d : ℤ)))
                                         (.readHeap engScrTbl (.lit 40))))))
        (.writeRealHeap engRealTbl (.lit 7)
          (.add (.readRealHeap engRealTbl (.lit 7))
                (.mul (.readRealHeap engRealTbl (.lit 6)) (.readRealHeap engRealTbl (.lit 6)))))))
    (.writeRealHeap engRealTbl (.lit outRIdx) (.readRealHeap engRealTbl (.lit 7))))

theorem zeroRand_pairDistSqStmt (uReg vReg outRIdx : ℤ) (d : ℕ) :
    ZeroRandStmt (pairDistSqStmt uReg vReg outRIdx d) :=
  .seq (.writeRealHeap _ _ _)
    (.seq (zeroRand_forLoopStmt (.seq (.writeRealHeap _ _ _) (.writeRealHeap _ _ _)))
      (.writeRealHeap _ _ _))

theorem exec_pairDistSqStmt {d TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    {u v : ℕ} (uReg vReg outRIdx : ℤ)
    (hTW : 9 ≤ TW) (hBW : 64 ≤ BW) (hTR : 3 ≤ TR) (hBR : 16 ≤ BR)
    (huR : uReg < 40) (hvR : vReg < 40) (ho0 : 0 ≤ outRIdx) (ho6 : outRIdx < 6)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hu_mem : wRead m₀ engScrTbl uReg = (u : ℤ))
    (hv_mem : wRead m₀ engScrTbl vReg = (v : ℤ))
    (hu_pts : ∀ c : Fin d, rRead m₀ ptsRTbl (((u * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts u) c)
    (hv_pts : ∀ c : Fin d, rRead m₀ ptsRTbl (((v * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts v) c) :
    ExecDet TW BW TR BR inp (pairDistSqStmt uReg vReg outRIdx d) m₀
      (fun m₁ =>
        rRead m₁ engRealTbl outRIdx = ‖pts u - pts v‖ ^ 2 ∧
        (∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ r, r ≠ 40 → wRead m₁ engScrTbl r = wRead m₀ engScrTbl r) ∧
        (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m₁ rt i = rRead m₀ rt i) ∧
        (∀ ri, ri ≠ outRIdx → ri ≠ 6 → ri ≠ 7 → rRead m₁ engRealTbl ri = rRead m₀ engRealTbl ri))
      (80 + 80 * d) := by
  have hT_scr : engScrTbl < TW := by show 8 < TW; omega
  have hT_real : engRealTbl < TR := by show 2 < TR; omega
  unfold pairDistSqStmt
  let pSum : ℕ → ℝ := fun k =>
    ∑ c ∈ Finset.range k,
      (if hc : c < d then (euclideanCoord (pts u) ⟨c, hc⟩ - euclideanCoord (pts v) ⟨c, hc⟩) ^ 2 else 0)
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    rRead m engRealTbl 7 = pSum k ∧
    (∀ t, t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ r, r ≠ 40 → wRead m engScrTbl r = wRead m₀ engScrTbl r) ∧
    (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m rt i = rRead m₀ rt i) ∧
    (∀ ri, ri ≠ 6 → ri ≠ 7 → rRead m engRealTbl ri = rRead m₀ engRealTbl ri)
  refine ExecDet.seq' (50 + 80 * d)
    (ExecDet.rWriteEq inp engRealTbl (.lit 7) (.ofInt (.lit 0)) 7 0
      hfp₀ hT_real (by omega) (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
      (by simp [intExprOps, realExprOps])) (by omega) ?_
  intro mA hmA hfpA; subst hmA
  refine ExecDet.seq' 30
    (ExecDet.forLoop engScrTbl 40 d _ Inv 60 hfpA hT_scr (by omega) (by omega)
      ⟨by simp [pSum, rRead_wWrite, rRead_rWrite_self],
       fun t ht i => by rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_rWrite],
       fun r hr => by rw [wRead_wWrite_of_ne _ _ (Or.inr hr), wRead_rWrite],
       fun rt hrt i => by rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hrt)],
       fun ri _ h7 => by rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr h7)]⟩ ?_) (by omega) ?_
  · intro c hc m ⟨hsum, hw_t, hw_r, hr_t, hr_r⟩ hctr hfp_m
    let cf : Fin d := ⟨c, hc⟩
    let dv : ℝ := euclideanCoord (pts u) cf - euclideanCoord (pts v) cf
    have hu_m : wRead m engScrTbl uReg = (u : ℤ) := (hw_r uReg (by omega)).trans hu_mem
    have hv_m : wRead m engScrTbl vReg = (v : ℤ) := (hw_r vReg (by omega)).trans hv_mem
    have hpu_m : rRead m ptsRTbl ((u : ℤ) * (d : ℤ) + (c : ℤ)) = euclideanCoord (pts u) cf := by
      have hid : ((u : ℤ) * (d : ℤ) + (c : ℤ)) = (((u * d + cf.val : ℕ) : ℤ)) := by
        simp [cf]
      rw [hid, hr_t ptsRTbl (by decide)]; exact hu_pts cf
    have hpv_m : rRead m ptsRTbl ((v : ℤ) * (d : ℤ) + (c : ℤ)) = euclideanCoord (pts v) cf := by
      have hid : ((v : ℤ) * (d : ℤ) + (c : ℤ)) = (((v * d + cf.val : ℕ) : ℤ)) := by
        simp [cf]
      rw [hid, hr_t ptsRTbl (by decide)]; exact hv_pts cf
    refine ExecDet.seq' 30
      (ExecDet.rWriteEq inp engRealTbl (.lit 6) _ 6 dv hfp_m hT_real (by omega) (by omega) rfl
        (by simp only [evalRealExpr, evalIntExpr]
            change rRead m ptsRTbl (wRead m engScrTbl uReg * (d : ℤ) + wRead m engScrTbl 40) -
                   rRead m ptsRTbl (wRead m engScrTbl vReg * (d : ℤ) + wRead m engScrTbl 40) = dv
            rw [hu_m, hv_m, hctr, hpu_m, hpv_m])
        (by simp [intExprOps, realExprOps])) (by omega) ?_
    intro m1 hm1 hfp1; subst hm1
    refine ExecDet.rWrite inp engRealTbl (.lit 7) _ 7 (pSum c + dv * dv)
      hfp1 hT_real (by omega) (by omega) rfl
      (by simp only [evalRealExpr, evalIntExpr]
          change rRead _ engRealTbl 7 + rRead _ engRealTbl 6 * rRead _ engRealTbl 6 = _
          rw [rRead_rWrite_of_ne _ _ (Or.inr (by decide)), rRead_rWrite_self, hsum])
      (by simp [intExprOps, realExprOps]) ?_
    refine ⟨by simp [wRead_rWrite, hctr], ?_, ?_, ?_, ?_, ?_⟩
    · rw [rRead_wWrite, rRead_rWrite_self]
      dsimp only [pSum]
      rw [Finset.sum_range_succ, dif_pos hc]
      dsimp only [dv, cf]; ring
    · intro t ht i
      rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_rWrite, wRead_rWrite]
      exact hw_t t ht i
    · intro r hr
      rw [wRead_wWrite_of_ne _ _ (Or.inr hr), wRead_rWrite, wRead_rWrite]
      exact hw_r r hr
    · intro rt hrt i
      rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hrt), rRead_rWrite_of_ne _ _ (Or.inl hrt)]
      exact hr_t rt hrt i
    · intro ri h6 h7
      rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr h7), rRead_rWrite_of_ne _ _ (Or.inr h6)]
      exact hr_r ri h6 h7
  · intro mL ⟨hsum_d, hw_t, hw_r, hr_t, hr_r⟩ hfpL
    have hpSum_eq : pSum d = ‖pts u - pts v‖ ^ 2 := by
      rw [norm_sub_sq_eq_sum_coord]
      dsimp only [pSum]
      rw [← Fin.sum_univ_eq_sum_range (fun c =>
        if hc : c < d then (euclideanCoord (pts u) ⟨c, hc⟩ - euclideanCoord (pts v) ⟨c, hc⟩) ^ 2 else 0)]
      refine Finset.sum_congr rfl fun c _ => ?_
      rw [dif_pos c.isLt]
    refine ExecDet.rWrite inp engRealTbl (.lit outRIdx) (.readRealHeap engRealTbl (.lit 7))
      outRIdx (‖pts u - pts v‖ ^ 2)
      hfpL hT_real ho0 (by omega) rfl
      (by simp only [evalRealExpr, evalIntExpr]
          change rRead mL engRealTbl 7 = _
          rw [hsum_d, hpSum_eq])
      (by simp [intExprOps, realExprOps]) ?_
    refine ⟨rRead_rWrite_self _ _ _ _,
      fun t ht i => by rw [wRead_rWrite]; exact hw_t t ht i,
      fun r hr => by rw [wRead_rWrite]; exact hw_r r hr,
      fun rt hrt i => by rw [rRead_rWrite_of_ne _ _ (Or.inl hrt)]; exact hr_t rt hrt i,
      fun ri ho h6 h7 => by rw [rRead_rWrite_of_ne _ _ (Or.inr ho)]; exact hr_r ri h6 h7⟩

def actContainsStmt (xReg outReg : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 43) (.readHeap 3 (.readHeap engScrTbl (.lit xReg))))
    (.ite (.and (.and (.intLe (.lit 0) (.readHeap engScrTbl (.lit 43)))
                      (.intLt (.readHeap engScrTbl (.lit 43)) (.readHeap 0 (.lit 6))))
                (.intEq (.readHeap 2 (.readHeap engScrTbl (.lit 43)))
                        (.readHeap engScrTbl (.lit xReg))))
      (.writeWordHeap engScrTbl (.lit outReg) (.lit 1))
      (.writeWordHeap engScrTbl (.lit outReg) (.lit 0)))

theorem zeroRand_actContainsStmt (xReg outReg : ℤ) :
    ZeroRandStmt (actContainsStmt xReg outReg) :=
  .seq (.writeWordHeap _ _ _) (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))

theorem exec_actContainsStmt {d n TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} {hp : HandlePool d n} {x : ℕ} (xReg outReg : ℤ)
    (hTW : 9 ≤ TW) (hBW : 64 ≤ BW)
    (hxR : xReg < 40) (ho0 : 0 ≤ outReg) (hoB : outReg < 43)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hhp : EncHandlePool hp m₀)
    (hx_mem : wRead m₀ engScrTbl xReg = (x : ℤ)) :
    ExecDet TW BW TR BR inp (actContainsStmt xReg outReg) m₀
      (fun m₁ =>
        wRead m₁ engScrTbl outReg = (if hp.actList.contains x then 1 else 0) ∧
        (∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ r, r ≠ outReg → r ≠ 43 → wRead m₁ engScrTbl r = wRead m₀ engScrTbl r) ∧
        (∀ rt i, rRead m₁ rt i = rRead m₀ rt i))
      60 := by
  have hT_scr : engScrTbl < TW := by show 8 < TW; omega
  unfold actContainsStmt
  let pos : ℤ := wRead m₀ 3 (x : ℤ)
  refine ExecDet.seq' 45
    (ExecDet.wWriteEq inp engScrTbl (.lit 43) (.readHeap 3 (.readHeap engScrTbl (.lit xReg)))
      43 pos hfp₀ hT_scr (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change wRead m₀ 3 (wRead m₀ engScrTbl xReg) = pos; rw [hx_mem])
      (by simp [intExprOps])) (by omega) ?_
  intro mA hmA hfpA; subst hmA
  have hcond_eq :
      (evalArithCond inp 0 (H3a.wWrite m₀ engScrTbl 43 pos)
        (.and (.and (.intLe (.lit 0) (.readHeap engScrTbl (.lit 43)))
                    (.intLt (.readHeap engScrTbl (.lit 43)) (.readHeap 0 (.lit 6))))
              (.intEq (.readHeap 2 (.readHeap engScrTbl (.lit 43)))
                      (.readHeap engScrTbl (.lit xReg))))).1 =
      hp.actList.contains x := by
    simp only [evalArithCond, evalIntExpr]
    change ((decide (0 ≤ wRead (H3a.wWrite m₀ engScrTbl 43 pos) engScrTbl 43) &&
            decide (wRead (H3a.wWrite m₀ engScrTbl 43 pos) engScrTbl 43 <
                    wRead (H3a.wWrite m₀ engScrTbl 43 pos) 0 6)) &&
           decide (wRead (H3a.wWrite m₀ engScrTbl 43 pos) 2
                     (wRead (H3a.wWrite m₀ engScrTbl 43 pos) engScrTbl 43) =
                   wRead (H3a.wWrite m₀ engScrTbl 43 pos) engScrTbl xReg)) =
           hp.actList.contains x
    rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hhp.2.2.1, hx_mem]
    apply Bool.eq_iff_iff.mpr
    simp only [Bool.and_eq_true, decide_eq_true_eq, List.contains_iff_mem]
    constructor
    · rintro ⟨⟨hp0, hpL⟩, h2⟩
      let p := pos.toNat
      have hp_eq : (p : ℤ) = pos := Int.toNat_of_nonneg hp0
      have hp_lt : p < hp.actList.length := by omega
      have hact := (hhp.2.2.2.2.1 p hp_lt).1
      rw [hp_eq, h2] at hact
      have hval : hp.actList[p]'hp_lt = x := Int.ofNat.inj hact.symm
      exact hval ▸ List.getElem_mem hp_lt
    · intro hmem
      obtain ⟨k, hk, hkx⟩ := List.mem_iff_getElem.mp hmem
      have hpos_k : pos = (k : ℤ) := by
        dsimp only [pos]; rw [← hkx]; exact (hhp.2.2.2.2.1 k hk).2
      rw [hpos_k]
      refine ⟨⟨Int.natCast_nonneg k, Int.ofNat_lt.mpr hk⟩, ?_⟩
      rw [(hhp.2.2.2.2.1 k hk).1, hkx]
  refine ExecDet.ite_le (C_c := 25) (C_b := 20) _ _ _ (by simp [condExprOps, intExprOps])
    (fun htrue => ?_) (fun hfalse => ?_)
  · have hc : hp.actList.contains x = true := hcond_eq.symm.trans htrue
    refine ExecDet.wWrite inp engScrTbl (.lit outReg) (.lit 1) outReg 1
      hfpA hT_scr ho0 (by omega) rfl rfl (by simp [intExprOps]) ?_
    refine ⟨by rw [wRead_wWrite_self, hc]; rfl,
      fun t ht i => by rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)],
      fun r hro hr43 => by
        rw [wRead_wWrite_of_ne _ _ (Or.inr hro), wRead_wWrite_of_ne _ _ (Or.inr hr43)],
      fun rt i => by simp [rRead_wWrite]⟩
  · have hc : hp.actList.contains x = false := hcond_eq.symm.trans hfalse
    refine ExecDet.wWrite inp engScrTbl (.lit outReg) (.lit 0) outReg 0
      hfpA hT_scr ho0 (by omega) rfl rfl (by simp [intExprOps]) ?_
    refine ⟨by rw [wRead_wWrite_self, hc]; rfl,
      fun t ht i => by rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)],
      fun r hro hr43 => by
        rw [wRead_wWrite_of_ne _ _ (Or.inr hro), wRead_wWrite_of_ne _ _ (Or.inr hr43)],
      fun rt i => by simp [rRead_wWrite]⟩

def foldCandStepStmt (hasR uR vR : ℤ) (d : ℕ) : ArithRAMStmt :=
  .ite (.intEq (.readHeap engScrTbl (.lit hasR)) (.lit 1))
    (.ite (.not (.intEq (.readHeap engScrTbl (.lit uR)) (.readHeap engScrTbl (.lit vR))))
      (.seq (actContainsStmt uR 41)
      (.seq (actContainsStmt vR 42)
        (.ite (.and (.intEq (.readHeap engScrTbl (.lit 41)) (.lit 1))
                    (.intEq (.readHeap engScrTbl (.lit 42)) (.lit 1)))
          (.seq (pairDistSqStmt uR vR 4 d)
            (.ite (.realLt (.readRealHeap engRealTbl (.lit 1)) (.readRealHeap engRealTbl (.lit 4)))
              (.seq (.writeWordHeap engScrTbl (.lit 10) (.readHeap engScrTbl (.lit uR)))
              (.seq (.writeWordHeap engScrTbl (.lit 11) (.readHeap engScrTbl (.lit vR)))
                    (.writeRealHeap engRealTbl (.lit 1) (.readRealHeap engRealTbl (.lit 4)))))
              .skip))
          .skip)))
      .skip)
    .skip

theorem zeroRand_foldCandStepStmt (hasR uR vR : ℤ) (d : ℕ) :
    ZeroRandStmt (foldCandStepStmt hasR uR vR d) :=
  .ite (.ite (.seq (zeroRand_actContainsStmt uR 41)
    (.seq (zeroRand_actContainsStmt vR 42)
      (.ite (.seq (zeroRand_pairDistSqStmt uR vR 4 d)
        (.ite (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.writeRealHeap _ _ _)))
          .skip))
        .skip))) .skip) .skip

theorem exec_foldCandStepStmt {d n TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} {P : DynamicPointSet d} {hp : HandlePool d n}
    {cur : ℕ × ℕ} {opt : Option (ℕ × ℕ)} (hasR uR vR : ℤ)
    (hTW : 9 ≤ TW) (hBW : 64 ≤ BW) (hTR : 3 ≤ TR) (hBR : 16 ≤ BR)
    (hhR : 12 ≤ hasR ∧ hasR < 40) (huR : 12 ≤ uR ∧ uR < 40) (hvR : 12 ≤ vR ∧ uR < 40 ∧ vR < 40)
    (hwf_hp : hp.WellFormed P)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hhp : EncHandlePool hp m₀)
    (hopt : EncOptPair hasR uR vR opt m₀)
    (hcurU : wRead m₀ engScrTbl 10 = (cur.1 : ℤ))
    (hcurV : wRead m₀ engScrTbl 11 = (cur.2 : ℤ))
    (hcurSq : rRead m₀ engRealTbl 1 = ‖hp.coords cur.1 - hp.coords cur.2‖ ^ 2) :
    let nxt := stepBestGlobal hp.coords hp.actList cur opt
    ExecDet TW BW TR BR inp (foldCandStepStmt hasR uR vR d) m₀
      (fun m₁ =>
        wRead m₁ engScrTbl 10 = (nxt.1 : ℤ) ∧
        wRead m₁ engScrTbl 11 = (nxt.2 : ℤ) ∧
        rRead m₁ engRealTbl 1 = ‖hp.coords nxt.1 - hp.coords nxt.2‖ ^ 2 ∧
        (∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ r, r < 40 → r ≠ 10 → r ≠ 11 → wRead m₁ engScrTbl r = wRead m₀ engScrTbl r) ∧
        (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m₁ rt i = rRead m₀ rt i) ∧
        (∀ ri, ri < 4 → ri ≠ 1 → rRead m₁ engRealTbl ri = rRead m₀ engRealTbl ri))
      (300 + 80 * d) := by
  have hT_scr : engScrTbl < TW := by show 8 < TW; omega
  have hT_real : engRealTbl < TR := by show 2 < TR; omega
  unfold foldCandStepStmt
  cases opt with
  | none =>
      have hhas0 : wRead m₀ engScrTbl hasR = 0 := hopt
      refine ExecDet.ite_le (C_c := 10) (C_b := 290 + 80 * d) _ _ _
        (by simp [condExprOps, intExprOps])
        (fun htrue => by
          simp only [evalArithCond, evalIntExpr] at htrue
          change decide (wRead m₀ engScrTbl hasR = 1) = true at htrue
          rw [hhas0] at htrue; simp at htrue)
        (fun _ => ExecDet.skip inp hfp₀ ⟨hcurU, hcurV, hcurSq,
          fun _ _ _ => rfl, fun _ _ _ _ => rfl, fun _ _ _ => rfl, fun _ _ _ => rfl⟩ (by omega))
  | some uv =>
      rcases uv with ⟨u, v⟩
      rcases hopt with ⟨hhas1, hu_m₀, hv_m₀⟩
      refine ExecDet.ite_le (C_c := 10) (C_b := 290 + 80 * d) _ _ _
        (by simp [condExprOps, intExprOps])
        (fun _ => ?_)
        (fun hfalse => by
          simp only [evalArithCond, evalIntExpr] at hfalse
          change decide (wRead m₀ engScrTbl hasR = 1) = false at hfalse
          rw [hhas1] at hfalse; simp at hfalse)
      refine ExecDet.ite_le (C_c := 10) (C_b := 280 + 80 * d) _ _ _
        (by simp [condExprOps, intExprOps])
        (fun hne_b => ?_)
        (fun heq_b => ?_)
      · have huv_ne : u ≠ v := by
          simp only [evalArithCond, evalIntExpr] at hne_b
          change (!decide (wRead m₀ engScrTbl uR = wRead m₀ engScrTbl vR)) = true at hne_b
          rw [hu_m₀, hv_m₀] at hne_b
          intro h; subst h; simp at hne_b
        refine ExecDet.seq' (220 + 80 * d)
          (exec_actContainsStmt inp uR 41 hTW hBW huR.2 (by omega) (by omega) hfp₀ hhp hu_m₀)
          (by omega) ?_
        intro m₁ ⟨hc_u, hwt₁, hwr₁, hrr₁⟩ hfp₁
        have hhp₁ : EncHandlePool hp m₁ :=
          ⟨(hwt₁ 0 (by decide) 4).trans hhp.1, (hwt₁ 0 (by decide) 5).trans hhp.2.1,
           (hwt₁ 0 (by decide) 6).trans hhp.2.2.1,
           fun i hi => (hwt₁ 1 (by decide) _).trans (hhp.2.2.2.1 i hi),
           fun i hi => ⟨(hwt₁ 2 (by decide) _).trans (hhp.2.2.2.2.1 i hi).1,
                        (hwt₁ 3 (by decide) _).trans (hhp.2.2.2.2.1 i hi).2⟩,
           fun x hx c => (hrr₁ 1 _).trans (hhp.2.2.2.2.2 x hx c)⟩
        have hv_m₁ : wRead m₁ engScrTbl vR = (v : ℤ) :=
          (hwr₁ vR (by omega) (by omega)).trans hv_m₀
        refine ExecDet.seq' (160 + 80 * d)
          (exec_actContainsStmt inp vR 42 hTW hBW hvR.2.2 (by omega) (by omega) hfp₁ hhp₁ hv_m₁)
          (by omega) ?_
        intro m₂ ⟨hc_v, hwt₂, hwr₂, hrr₂⟩ hfp₂
        have hc_u₂ : wRead m₂ engScrTbl 41 = (if hp.actList.contains u then 1 else 0) :=
          (hwr₂ 41 (by omega) (by omega)).trans hc_u
        have hu_m₂ : wRead m₂ engScrTbl uR = (u : ℤ) :=
          (hwr₂ uR (by omega) (by omega)).trans ((hwr₁ uR (by omega) (by omega)).trans hu_m₀)
        have hv_m₂ : wRead m₂ engScrTbl vR = (v : ℤ) :=
          (hwr₂ vR (by omega) (by omega)).trans hv_m₁
        have hcurU₂ : wRead m₂ engScrTbl 10 = (cur.1 : ℤ) :=
          (hwr₂ 10 (by omega) (by omega)).trans ((hwr₁ 10 (by omega) (by omega)).trans hcurU)
        have hcurV₂ : wRead m₂ engScrTbl 11 = (cur.2 : ℤ) :=
          (hwr₂ 11 (by omega) (by omega)).trans ((hwr₁ 11 (by omega) (by omega)).trans hcurV)
        have hcurSq₂ : rRead m₂ engRealTbl 1 = ‖hp.coords cur.1 - hp.coords cur.2‖ ^ 2 :=
          (hrr₂ engRealTbl 1).trans ((hrr₁ engRealTbl 1).trans hcurSq)
        refine ExecDet.ite_le (C_c := 15) (C_b := 145 + 80 * d) _ _ _
          (by simp [condExprOps, intExprOps])
          (fun hboth => ?_) (fun hnotboth => ?_)
        · have hmem_uv : hp.actList.contains u = true ∧ hp.actList.contains v = true := by
            simp only [evalArithCond, evalIntExpr] at hboth
            change (decide (wRead m₂ engScrTbl 41 = 1) && decide (wRead m₂ engScrTbl 42 = 1)) = true at hboth
            rw [hc_u₂, hc_v] at hboth
            simp only [Bool.and_eq_true, decide_eq_true_eq] at hboth
            rcases hboth with ⟨hbu, hbv⟩
            exact ⟨by cases h : hp.actList.contains u <;> rw [h] at hbu <;> simp at hbu ⊢,
                   by cases h : hp.actList.contains v <;> rw [h] at hbv <;> simp at hbv ⊢⟩
          have hu_nf : u < hp.nextFresh := hwf_hp.2.2.2.2.1 u (List.contains_iff_mem.mp hmem_uv.1)
          have hv_nf : v < hp.nextFresh := hwf_hp.2.2.2.2.1 v (List.contains_iff_mem.mp hmem_uv.2)
          have hpu₂ : ∀ c : Fin d, rRead m₂ ptsRTbl (((u * d + c.val : ℕ) : ℤ)) =
              euclideanCoord (hp.coords u) c :=
            fun c => (hrr₂ ptsRTbl _).trans ((hrr₁ ptsRTbl _).trans (hhp.2.2.2.2.2 u hu_nf c))
          have hpv₂ : ∀ c : Fin d, rRead m₂ ptsRTbl (((v * d + c.val : ℕ) : ℤ)) =
              euclideanCoord (hp.coords v) c :=
            fun c => (hrr₂ ptsRTbl _).trans ((hrr₁ ptsRTbl _).trans (hhp.2.2.2.2.2 v hv_nf c))
          refine ExecDet.seq' 65
            (exec_pairDistSqStmt inp hp.coords uR vR 4 hTW hBW hTR hBR huR.2 hvR.2.2
              (by omega) (by omega) hfp₂ hu_m₂ hv_m₂ hpu₂ hpv₂)
            (by omega) ?_
          intro m₃ ⟨hdsq, hwt₃, hwr₃, hrt₃, hrr₃⟩ hfp₃
          have hu_m₃ : wRead m₃ engScrTbl uR = (u : ℤ) := (hwr₃ uR (by omega)).trans hu_m₂
          have hv_m₃ : wRead m₃ engScrTbl vR = (v : ℤ) := (hwr₃ vR (by omega)).trans hv_m₂
          have hcurU₃ : wRead m₃ engScrTbl 10 = (cur.1 : ℤ) := (hwr₃ 10 (by omega)).trans hcurU₂
          have hcurV₃ : wRead m₃ engScrTbl 11 = (cur.2 : ℤ) := (hwr₃ 11 (by omega)).trans hcurV₂
          have hcurSq₃ : rRead m₃ engRealTbl 1 = ‖hp.coords cur.1 - hp.coords cur.2‖ ^ 2 :=
            (hrr₃ 1 (by omega) (by omega) (by omega)).trans hcurSq₂
          refine ExecDet.ite_le (C_c := 10) (C_b := 55) _ _ _
            (by simp [condExprOps, realExprOps, intExprOps])
            (fun hlt_b => ?_) (fun hle_b => ?_)
          · have hlt_sq : ‖hp.coords cur.1 - hp.coords cur.2‖ ^ 2 < ‖hp.coords u - hp.coords v‖ ^ 2 := by
              simp only [evalArithCond, evalRealExpr, evalIntExpr] at hlt_b
              change decide (rRead m₃ engRealTbl 1 < rRead m₃ engRealTbl 4) = true at hlt_b
              rw [hcurSq₃, hdsq] at hlt_b
              exact of_decide_eq_true hlt_b
            have hstep_eq : stepBestGlobal hp.coords hp.actList cur (some (u, v)) = (u, v) := by
              unfold stepBestGlobal
              exact if_pos ⟨huv_ne, hmem_uv.1, hmem_uv.2, hlt_sq⟩
            refine ExecDet.seq' 43
              (ExecDet.wWriteEq inp engScrTbl (.lit 10) (.readHeap engScrTbl (.lit uR))
                10 (u : ℤ) hfp₃ hT_scr (by omega) (by omega) rfl
                (by simp only [evalIntExpr]; exact hu_m₃) (by simp [intExprOps])) (by omega) ?_
            intro m₄ hm₄ hfp₄; subst hm₄
            refine ExecDet.seq' 30
              (ExecDet.wWriteEq inp engScrTbl (.lit 11) (.readHeap engScrTbl (.lit vR))
                11 (v : ℤ) hfp₄ hT_scr (by omega) (by omega) rfl
                (by simp only [evalIntExpr]
                    change wRead _ engScrTbl vR = _
                    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hv_m₃)
                (by simp [intExprOps])) (by omega) ?_
            intro m₅ hm₅ hfp₅; subst hm₅
            refine ExecDet.rWrite inp engRealTbl (.lit 1) (.readRealHeap engRealTbl (.lit 4))
              1 (‖hp.coords u - hp.coords v‖ ^ 2)
              hfp₅ hT_real (by omega) (by omega) rfl
              (by simp only [evalRealExpr, evalIntExpr]
                  change rRead _ engRealTbl 4 = _
                  simp only [rRead_wWrite]; exact hdsq)
              (by simp [intExprOps, realExprOps]) ?_
            dsimp only
            rw [hstep_eq]
            refine ⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
              by rw [wRead_rWrite, wRead_wWrite_self],
              rRead_rWrite_self _ _ _ _,
              fun t ht i => by
                rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
                exact (hwt₃ t ht i).trans ((hwt₂ t ht i).trans (hwt₁ t ht i)),
              fun r hr40 hr10 hr11 => by
                rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hr11), wRead_wWrite_of_ne _ _ (Or.inr hr10)]
                exact (hwr₃ r (by omega)).trans ((hwr₂ r (by omega) (by omega)).trans (hwr₁ r (by omega) (by omega))),
              fun rt hrt i => by
                rw [rRead_rWrite_of_ne _ _ (Or.inl hrt), rRead_wWrite, rRead_wWrite]
                exact (hrt₃ rt hrt i).trans ((hrr₂ rt i).trans (hrr₁ rt i)),
              fun ri hri4 hri1 => by
                rw [rRead_rWrite_of_ne _ _ (Or.inr hri1), rRead_wWrite, rRead_wWrite]
                exact (hrr₃ ri (by omega) (by omega) (by omega)).trans ((hrr₂ engRealTbl ri).trans (hrr₁ engRealTbl ri))⟩
          · have hnot_lt : ¬ ‖hp.coords cur.1 - hp.coords cur.2‖ ^ 2 < ‖hp.coords u - hp.coords v‖ ^ 2 := by
              simp only [evalArithCond, evalRealExpr, evalIntExpr] at hle_b
              change decide (rRead m₃ engRealTbl 1 < rRead m₃ engRealTbl 4) = false at hle_b
              rw [hcurSq₃, hdsq] at hle_b
              exact of_decide_eq_false hle_b
            have hstep_eq : stepBestGlobal hp.coords hp.actList cur (some (u, v)) = cur := by
              unfold stepBestGlobal
              exact if_neg (fun h => hnot_lt h.2.2.2)
            refine ExecDet.skip inp hfp₃ ?_ (by omega)
            dsimp only; rw [hstep_eq]
            exact ⟨hcurU₃, hcurV₃, hcurSq₃,
              fun t ht i => (hwt₃ t ht i).trans ((hwt₂ t ht i).trans (hwt₁ t ht i)),
              fun r hr40 _ _ => (hwr₃ r (by omega)).trans ((hwr₂ r (by omega) (by omega)).trans (hwr₁ r (by omega) (by omega))),
              fun rt hrt i => (hrt₃ rt hrt i).trans ((hrr₂ rt i).trans (hrr₁ rt i)),
              fun ri hri4 _ => (hrr₃ ri (by omega) (by omega) (by omega)).trans ((hrr₂ engRealTbl ri).trans (hrr₁ engRealTbl ri))⟩
        · have hnot_mem : ¬ (hp.actList.contains u = true ∧ hp.actList.contains v = true) := by
            simp only [evalArithCond, evalIntExpr] at hnotboth
            change (decide (wRead m₂ engScrTbl 41 = 1) && decide (wRead m₂ engScrTbl 42 = 1)) = false at hnotboth
            rw [hc_u₂, hc_v] at hnotboth
            rintro ⟨hu_t, hv_t⟩
            rw [hu_t, hv_t] at hnotboth; simp at hnotboth
          have hstep_eq : stepBestGlobal hp.coords hp.actList cur (some (u, v)) = cur := by
            unfold stepBestGlobal
            exact if_neg (fun h => hnot_mem ⟨h.2.1, h.2.2.1⟩)
          refine ExecDet.skip inp hfp₂ ?_ (by omega)
          dsimp only; rw [hstep_eq]
          exact ⟨hcurU₂, hcurV₂, hcurSq₂,
            fun t ht i => (hwt₂ t ht i).trans (hwt₁ t ht i),
            fun r hr40 _ _ => (hwr₂ r (by omega) (by omega)).trans (hwr₁ r (by omega) (by omega)),
            fun rt _ i => (hrr₂ rt i).trans (hrr₁ rt i),
            fun ri _ _ => (hrr₂ engRealTbl ri).trans (hrr₁ engRealTbl ri)⟩
      · have huv_eq : u = v := by
          simp only [evalArithCond, evalIntExpr] at heq_b
          change (!decide (wRead m₀ engScrTbl uR = wRead m₀ engScrTbl vR)) = false at heq_b
          rw [hu_m₀, hv_m₀] at heq_b
          have hd : decide ((u : ℤ) = (v : ℤ)) = true := by simpa using heq_b
          exact Int.ofNat.inj (of_decide_eq_true hd)
        have hstep_eq : stepBestGlobal hp.coords hp.actList cur (some (u, v)) = cur := by
          unfold stepBestGlobal
          exact if_neg (fun h => h.1 huv_eq)
        refine ExecDet.skip inp hfp₀ ?_ (by omega)
        dsimp only; rw [hstep_eq]
        exact ⟨hcurU, hcurV, hcurSq,
          fun _ _ _ => rfl, fun _ _ _ _ => rfl, fun _ _ _ => rfl, fun _ _ _ => rfl⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
