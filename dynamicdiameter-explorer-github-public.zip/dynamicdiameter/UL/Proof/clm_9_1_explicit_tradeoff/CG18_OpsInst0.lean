import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInstA
import UL.Proof.clm_9_1_explicit_tradeoff.CG15_ParamsB

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b3
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.CG14
open UL.Proof.clm_9_1_explicit_tradeoff.CG15
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG20

/-! ### 1. Universal Polynomial Domination Constants & Component Helpers -/

/-- Closed universal constant for all single-node RAM operation work bounds. -/
noncomputable def C_node_work : ℕ := 50000 + 50 * Nat.ceil hpjOpConst

/-- Closed universal constant for total node-and-HPJ table cell footprint `TW * BW + TR * BR`. -/
noncomputable def C_node_space : ℕ := 50000 + 20 * Nat.ceil hpjOpConst

/-- Polynomial factor matching `CG17.configMatchPolyFactor` definitionally (`rfl`). -/
def cfgPolyFactorNat (d L_p2 R ℓ b T_cdf p_coord M_lat : ℕ) : ℕ :=
  (L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * (M_lat + 1) *
    (24000 + 120 * b + 2 * (T_cdf + p_coord + 6) * (120 + 48 * cdfDegree T_cdf b))

theorem self_le_pow {P k : ℕ} (hP : 1 ≤ P) (hk : 1 ≤ k) : P ≤ P ^ k := by
  have h := Nat.pow_le_pow_right hP hk
  rwa [pow_one] at h

theorem toNat_le_of_int_le {z : ℤ} {N : ℕ} (h : z ≤ (N : ℤ)) : z.toNat ≤ N := by
  have h1 := Int.toNat_le_toNat h
  rwa [Int.toNat_natCast] at h1

theorem poly_param_components {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ) :
    let P := masterPolyParamNat inst
    1 ≤ P ∧
    d + 1 ≤ P ∧
    inst.cp.L_p2 + 1 ≤ P ∧
    inst.cp.D_max ≤ P ∧
    inst.cp.B_scan ≤ P ∧
    inst.cp.N_cfg ≤ P ∧
    inst.cp.R + 1 ≤ P ∧
    inst.cp.ℓ + 1 ≤ P ∧
    inst.cp.T_cdf + 1 ≤ P ∧
    inst.cp.p_coord + 1 ≤ P ∧
    inst.cp.b ≤ P ∧
    inst.cp.N_samp ≤ P ∧
    inst.cp.P_hpj.k_phi ≤ P ∧
    inst.cp.B_walk ≤ P ∧
    inst.cp.q_idx + 1 ≤ P ∧
    inst.cp.k_base ≤ P ∧
    M_lat_of d inst.params.e + 1 ≤ P := by
  dsimp only; unfold masterPolyParamNat
  refine ⟨by omega, by omega, by omega, by omega, by omega, by omega, by omega, by omega,
    by omega, by omega, by omega, by omega, by omega, by omega, by omega, by omega, by omega⟩

theorem work_space_components {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    let W := masterWorkFactorNat cp
    let S := masterSpaceFactorNat cp
    1 ≤ W ∧
    W ≤ S ∧
    1 ≤ S ∧
    1 + cp.cap_u + cp.cap_q + cp.R * cp.ℓ * cp.M₀ ≤ W ∧
    cp.M₀ ≤ W ∧
    cp.B_STEP ≤ W ∧
    cp.cap_u + cp.cap_q ≤ W ∧
    cp.R * cp.ℓ * cp.M₀ ≤ S ∧
    cp.n ≤ S ∧
    2 ^ cp.L_p2 ≤ S ∧
    2 ^ cp.L_p2 * cp.cap_u ≤ S ∧
    cp.M₀ ^ cp.ℓ ≤ S := by
  dsimp only; unfold masterSpaceFactorNat masterWorkFactorNat
  generalize 2 ^ cp.L_p2 * cp.cap_u = p2u
  generalize 2 ^ cp.L_p2 = p2
  generalize cp.M₀ ^ cp.ℓ = ml
  generalize cp.R * cp.ℓ * cp.M₀ = rlm
  refine ⟨by omega, by omega, by omega, by omega, by omega, by omega, by omega,
    by omega, by omega, by omega, by omega, by omega⟩

theorem cfgPolyFactorNat_le_masterPoly {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ) :
    cfgPolyFactorNat d inst.cp.L_p2 inst.cp.R inst.cp.ℓ inst.cp.b
      inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e) ≤
      40000 * (masterPolyParamNat inst) ^ 8 := by
  let P := masterPolyParamNat inst
  obtain ⟨hP1, hd1, hLp1, _, _, _, hR1, hℓ1, hTc1, hpc1, hb, _, _, _, _, _, hMl1⟩ :=
    poly_param_components inst
  have hP2_ge1 : 1 ≤ P ^ 2 := Nat.one_le_pow 2 P hP1
  have hP3_ge1 : 1 ≤ P ^ 3 := Nat.one_le_pow 3 P hP1
  have hP_le_P2 : P ≤ P ^ 2 := self_le_pow hP1 (by decide : 1 ≤ 2)
  have hP_le_P3 : P ≤ P ^ 3 := self_le_pow hP1 (by decide : 1 ≤ 3)
  have hBase : (inst.cp.L_p2 + 1) * (inst.cp.R + 1) * (inst.cp.ℓ + 1) * (d + 1) *
      (M_lat_of d inst.params.e + 1) ≤ P ^ 5 := by
    calc (inst.cp.L_p2 + 1) * (inst.cp.R + 1) * (inst.cp.ℓ + 1) * (d + 1) *
          (M_lat_of d inst.params.e + 1)
        ≤ P * P * P * P * P :=
          Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul (Nat.mul_le_mul hLp1 hR1) hℓ1) hd1) hMl1
      _ = P ^ 5 := by ring
  have hcdf : cdfDegree inst.cp.T_cdf inst.cp.b ≤ 18 * P ^ 2 := by
    unfold cdfDegree
    have h1 : (inst.cp.T_cdf + 1) ^ 2 ≤ P ^ 2 := Nat.pow_le_pow_left hTc1 2
    have h2 : inst.cp.T_cdf ≤ P ^ 2 := le_trans (by omega : inst.cp.T_cdf ≤ P) hP_le_P2
    have h3 : inst.cp.b ≤ P ^ 2 := le_trans hb hP_le_P2
    omega
  have hinner1 : 120 + 48 * cdfDegree inst.cp.T_cdf inst.cp.b ≤ 984 * P ^ 2 := by omega
  have hinner2 : inst.cp.T_cdf + inst.cp.p_coord + 6 ≤ 8 * P := by omega
  have hmul : 2 * (inst.cp.T_cdf + inst.cp.p_coord + 6) *
      (120 + 48 * cdfDegree inst.cp.T_cdf inst.cp.b) ≤ 15744 * P ^ 3 := by
    calc 2 * (inst.cp.T_cdf + inst.cp.p_coord + 6) *
          (120 + 48 * cdfDegree inst.cp.T_cdf inst.cp.b)
        ≤ 2 * (8 * P) * (984 * P ^ 2) :=
          Nat.mul_le_mul (Nat.mul_le_mul_left 2 hinner2) hinner1
      _ = 15744 * P ^ 3 := by ring
  have hQ : 24000 + 120 * inst.cp.b +
      2 * (inst.cp.T_cdf + inst.cp.p_coord + 6) *
        (120 + 48 * cdfDegree inst.cp.T_cdf inst.cp.b) ≤ 40000 * P ^ 3 := by
    have hb3 : inst.cp.b ≤ P ^ 3 := le_trans hb hP_le_P3
    omega
  unfold cfgPolyFactorNat
  calc (inst.cp.L_p2 + 1) * (inst.cp.R + 1) * (inst.cp.ℓ + 1) * (d + 1) *
        (M_lat_of d inst.params.e + 1) *
        (24000 + 120 * inst.cp.b +
          2 * (inst.cp.T_cdf + inst.cp.p_coord + 6) *
            (120 + 48 * cdfDegree inst.cp.T_cdf inst.cp.b))
      ≤ P ^ 5 * (40000 * P ^ 3) := Nat.mul_le_mul hBase hQ
    _ = 40000 * P ^ 8 := by ring

/-! ### 2. Master Polynomial Cost & Space Theorems for `mkNodeAndHPJRAMOps` -/

theorem mkNodeAndHPJRAMOps_master_bounds {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    (cmOps : ConfigMatchRAMOps d inst.cp.n inst.cp.L_p2 inst.cp.R inst.cp.ℓ inst.cp.M₀
      inst.cp.b inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e)
      inst.params (inst.h_rat : ℝ) inst.cp.τ_d inst.cp.τ_q inst.cp.cap_u inst.cp.cap_q
      10 4 9 3 coinTbl)
    (cmHzr : ConfigMatchHeapZeroRand cmOps)
    (hcfgW : cmOps.cfgWStride ≤
      (((3 + 8 * inst.cp.n + 2 * (2 + 2 * 2 ^ inst.cp.L_p2 + inst.cp.n +
        2 * inst.cp.L_p2 * (4 + 2 * inst.cp.R * inst.cp.M₀ ^ inst.cp.ℓ +
          5 * 2 ^ inst.cp.L_p2 * inst.cp.R * inst.cp.cap_u))) : ℕ) : ℤ))
    (hcfgR : cmOps.cfgRStride ≤
      (((2 * (d + 2 ^ inst.cp.L_p2 * d +
        2 * inst.cp.L_p2 * (inst.cp.R * inst.cp.ℓ * inst.cp.M₀ * (d + 1)))) : ℕ) : ℤ))
    (hopW : cmOps.opWScrStride ≤
      (((64 + inst.cp.ℓ + inst.cp.ℓ * inst.cp.M₀ + inst.cp.cap_u + inst.cp.cap_q) : ℕ) : ℤ))
    (hopR : cmOps.opRScrStride ≤ (((15 + 3 * d) : ℕ) : ℤ))
    (hreadC : cmOps.readEdgeCost = 120)
    (hclrC : cmOps.clearCost ≤ 220 + 1440 * (inst.cp.L_p2 + 1))
    (hinsC : cmOps.insertCost ≤
      (1 + inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀) *
        cfgPolyFactorNat d inst.cp.L_p2 inst.cp.R inst.cp.ℓ inst.cp.b
          inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e))
    (hdelC : cmOps.deleteCost ≤
      (1 + inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀) *
        cfgPolyFactorNat d inst.cp.L_p2 inst.cp.R inst.cp.ℓ inst.cp.b
          inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e)) :
    let P := masterPolyParamNat inst
    let W := masterWorkFactorNat inst.cp
    let S := masterSpaceFactorNat inst.cp
    let ops := mkNodeAndHPJRAMOps inst.cp cmOps cmHzr
    let mops := mkMaxRadRAMOp inst.cp cmOps cmHzr
    ops.C_open ≤ C_node_work * P ^ 13 * W ∧
    ops.C_ins ≤ C_node_work * P ^ 13 * W ∧
    ops.C_del ≤ C_node_work * P ^ 13 * W ∧
    ops.C_bump = 50 ∧
    ops.C_ball = 200 + 60 * d ∧
    ops.C_hpj ≤ C_node_work * P ^ 13 * W ∧
    ops.C_read = 370 ∧
    mops.C_maxRad = 200 ∧
    ops.TW * ops.BW + ops.TR * ops.BR ≤ C_node_space * P ^ 13 * S := by
  intro _P _W _S ops mops
  dsimp only [_P, _W, _S]
  clear _P _W _S
  obtain ⟨P, hP_def⟩ : ∃ x, x = masterPolyParamNat inst := ⟨_, rfl⟩
  obtain ⟨W, hW_def⟩ : ∃ x, x = masterWorkFactorNat inst.cp := ⟨_, rfl⟩
  obtain ⟨S, hS_def⟩ : ∃ x, x = masterSpaceFactorNat inst.cp := ⟨_, rfl⟩
  rw [← hP_def, ← hW_def, ← hS_def]
  have hpc := poly_param_components inst; dsimp only at hpc; rw [← hP_def] at hpc
  obtain ⟨hP1, hd1, hLp1, hDm, hBsc, hNcfg, hR1, hℓ1, _, _, _, hNs, hkphi, hBw, hq1, _, _⟩ := hpc
  have hwsc := work_space_components inst.cp; dsimp only at hwsc; rw [← hW_def, ← hS_def] at hwsc
  obtain ⟨hW1, hWS, hS1, hCapTot, hM0W, hBstepW, hCuCqW, hRlMS, hnS, h2LpS, h2LpCuS, hM0lS⟩ := hwsc
  obtain ⟨hTW, hTR, hnW_eq, hnR_eq, hBW_eq, hBR_eq⟩ :=
    mkNodeAndHPJRAMOps_strides_and_dims inst.cp cmOps cmHzr
  obtain ⟨hCopen, hCins, hCdel, hCbump, hCball, hChpj, hCread, hCmrad⟩ :=
    mkNodeAndHPJRAMOps_costs inst.cp cmOps cmHzr
  have hPF := cfgPolyFactorNat_le_masterPoly inst; rw [← hP_def] at hPF
  have hpow : ∀ {a b : ℕ}, a ≤ b → P ^ a ≤ P ^ b := fun hab => Nat.pow_le_pow_right hP1 hab
  have hP13_ge1 : 1 ≤ P ^ 13 := Nat.one_le_pow 13 P hP1

  -- 1. C_open
  have hOpen_le : ops.C_open ≤ C_node_work * P ^ 13 * W := by
    have hc1 : cmOps.clearCost + 40 ≤ 1700 * P := by omega
    have hc2 : inst.cp.N_cfg * (cmOps.clearCost + 40) ≤ 1700 * P ^ 2 := by
      calc inst.cp.N_cfg * (cmOps.clearCost + 40) ≤ P * (1700 * P) := Nat.mul_le_mul hNcfg hc1
        _ = 1700 * P ^ 2 := by ring
    have hc3 : ops.C_open ≤ 2300 * P ^ 2 := by
      rw [hCopen]
      have hd_P2 : d ≤ P ^ 2 := le_trans (by omega : d ≤ P) (self_le_pow hP1 (by decide : 1 ≤ 2))
      have h1_P2 : 1 ≤ P ^ 2 := Nat.one_le_pow 2 P hP1
      linarith only [hc2, hd_P2, h1_P2]
    calc ops.C_open ≤ 2300 * P ^ 2 := hc3
      _ ≤ 2300 * P ^ 13 := Nat.mul_le_mul_left 2300 (hpow (by decide))
      _ = 2300 * P ^ 13 * 1 := by ring
      _ ≤ C_node_work * P ^ 13 * W :=
          Nat.mul_le_mul (Nat.mul_le_mul_right _ (by unfold C_node_work; omega)) hW1

  -- 2 & 3. C_ins and C_del
  have hInsDel_sub : ∀ {c_op c_hd : ℕ},
      c_hd ≤ 1110 →
      c_op ≤ (1 + inst.cp.cap_u + inst.cp.cap_q + inst.cp.R * inst.cp.ℓ * inst.cp.M₀) *
        cfgPolyFactorNat d inst.cp.L_p2 inst.cp.R inst.cp.ℓ inst.cp.b
          inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e) →
      c_hd + 110 * d + 380 * inst.cp.L_p2 + inst.cp.N_cfg * (c_op + 60) ≤
        C_node_work * P ^ 13 * W := by
    intro c_op c_hd hchd hcop
    have h1 : c_op ≤ 40000 * P ^ 8 * W := by
      calc c_op ≤ W * (40000 * P ^ 8) := le_trans hcop (Nat.mul_le_mul hCapTot hPF)
        _ = 40000 * P ^ 8 * W := by ring
    have hP8W_ge1 : 1 ≤ P ^ 8 * W := Nat.mul_pos (Nat.one_le_pow 8 P hP1) hW1
    have h2 : c_op + 60 ≤ 40060 * P ^ 8 * W := by linarith only [h1, hP8W_ge1]
    have h3 : inst.cp.N_cfg * (c_op + 60) ≤ 40060 * P ^ 9 * W := by
      calc inst.cp.N_cfg * (c_op + 60) ≤ P * (40060 * P ^ 8 * W) := Nat.mul_le_mul hNcfg h2
        _ = 40060 * P ^ 9 * W := by ring
    have h4 : c_hd + 110 * d + 380 * inst.cp.L_p2 ≤ 1600 * P ^ 9 * W := by
      have hp9 : P ≤ P ^ 9 * W := by
        calc P = P ^ 1 * 1 := by ring
          _ ≤ P ^ 9 * W := Nat.mul_le_mul (hpow (by decide)) hW1
      have h1_9 : 1 ≤ P ^ 9 * W := le_trans hP1 hp9
      have hd_9 : d ≤ P ^ 9 * W := le_trans (by omega : d ≤ P) hp9
      have hl_9 : inst.cp.L_p2 ≤ P ^ 9 * W := le_trans (by omega : inst.cp.L_p2 ≤ P) hp9
      linarith only [hchd, h1_9, hd_9, hl_9]
    calc c_hd + 110 * d + 380 * inst.cp.L_p2 + inst.cp.N_cfg * (c_op + 60)
        ≤ 41660 * P ^ 9 * W := by linarith only [h3, h4]
      _ ≤ 41660 * P ^ 13 * W :=
          Nat.mul_le_mul_right W (Nat.mul_le_mul_left 41660 (hpow (by decide)))
      _ ≤ C_node_work * P ^ 13 * W :=
          Nat.mul_le_mul_right W (Nat.mul_le_mul_right _ (by unfold C_node_work; omega))

  have hIns_le : ops.C_ins ≤ C_node_work * P ^ 13 * W := by
    rw [hCins]; exact hInsDel_sub (by omega) hinsC
  have hDel_le : ops.C_del ≤ C_node_work * P ^ 13 * W := by
    rw [hCdel]; exact hInsDel_sub le_rfl hdelC

  -- 4. C_hpj
  have hHpj_le : ops.C_hpj ≤ C_node_work * P ^ 13 * W := by
    rw [hChpj]
    have hp := evalHPJCenterCost_le_poly inst.cp
    have hd10_k3 : (d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3 ≤ P ^ 13 := by
      calc (d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3
          ≤ P ^ 10 * P ^ 3 := Nat.mul_le_mul (Nat.pow_le_pow_left hd1 10) (Nat.pow_le_pow_left hkphi 3)
        _ = P ^ 13 := by ring
    have hNs_q : inst.cp.N_samp * (inst.cp.q_idx + 1) ≤ P ^ 13 := by
      calc inst.cp.N_samp * (inst.cp.q_idx + 1) ≤ P * P := Nat.mul_le_mul hNs hq1
        _ = P ^ 2 := by ring
        _ ≤ P ^ 13 := hpow (by decide)
    have hBw_13 : inst.cp.B_walk ≤ P ^ 13 :=
      le_trans hBw (self_le_pow hP1 (by decide : 1 ≤ 13))
    have hd_13 : d ≤ P ^ 13 :=
      le_trans (by omega : d ≤ P) (self_le_pow hP1 (by decide : 1 ≤ 13))
    have hterm_hpj : 40 * (Nat.ceil hpjOpConst * (d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3) ≤
        (40 * Nat.ceil hpjOpConst) * P ^ 13 := by
      calc 40 * (Nat.ceil hpjOpConst * (d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3)
          = (40 * Nat.ceil hpjOpConst) * ((d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3) := by ring
        _ ≤ (40 * Nat.ceil hpjOpConst) * P ^ 13 := Nat.mul_le_mul_left _ hd10_k3
    have htot13 : evalHPJCenterCost inst.cp ≤ (660 + 40 * Nat.ceil hpjOpConst) * P ^ 13 := by
      have hlin : 500 + 60 * (inst.cp.N_samp * (inst.cp.q_idx + 1)) + 40 * inst.cp.B_walk + 60 * d ≤
          660 * P ^ 13 := by linarith only [hP13_ge1, hNs_q, hBw_13, hd_13]
      have hp' : evalHPJCenterCost inst.cp ≤
          (500 + 60 * (inst.cp.N_samp * (inst.cp.q_idx + 1)) + 40 * inst.cp.B_walk + 60 * d) +
            40 * (Nat.ceil hpjOpConst * (d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3) := by
        have hassoc : 60 * inst.cp.N_samp * (inst.cp.q_idx + 1) =
            60 * (inst.cp.N_samp * (inst.cp.q_idx + 1)) := by ring
        linarith only [hp, hassoc]
      calc evalHPJCenterCost inst.cp
          ≤ 660 * P ^ 13 + (40 * Nat.ceil hpjOpConst) * P ^ 13 :=
            le_trans hp' (Nat.add_le_add hlin hterm_hpj)
        _ = (660 + 40 * Nat.ceil hpjOpConst) * P ^ 13 := by ring
    calc evalHPJCenterCost inst.cp
        ≤ (660 + 40 * Nat.ceil hpjOpConst) * P ^ 13 := htot13
      _ = (660 + 40 * Nat.ceil hpjOpConst) * P ^ 13 * 1 := by ring
      _ ≤ C_node_work * P ^ 13 * W :=
          Nat.mul_le_mul (Nat.mul_le_mul_right _ (by unfold C_node_work; omega)) hW1

  -- 5. Space: TW * BW + TR * BR ≤ C_node_space * P ^ 13 * S
  have hSpace_le : ops.TW * ops.BW + ops.TR * ops.BR ≤ C_node_space * P ^ 13 * S := by
    have hcw := toNat_le_of_int_le hcfgW
    have hcr := toNat_le_of_int_le hcfgR
    have how := toNat_le_of_int_le hopW
    have hor := toNat_le_of_int_le hopR
    have hPS : P ≤ P ^ 2 * S := by
      calc P = P ^ 1 * 1 := by ring
        _ ≤ P ^ 2 * S := Nat.mul_le_mul (hpow (by decide)) hS1
    have hS_P2S : S ≤ P ^ 2 * S := by
      calc S = 1 * S := by ring
        _ ≤ P ^ 2 * S := Nat.mul_le_mul_right S (Nat.one_le_pow 2 P hP1)
    have hLR_P2 : inst.cp.L_p2 * inst.cp.R ≤ P ^ 2 := by
      calc inst.cp.L_p2 * inst.cp.R ≤ P * P := Nat.mul_le_mul (by omega) (by omega)
        _ = P ^ 2 := by ring
    have hcw_le : cmOps.cfgWStride.toNat ≤ 65 * P ^ 2 * S := by
      have ht1 : (inst.cp.L_p2 * inst.cp.R) * inst.cp.M₀ ^ inst.cp.ℓ ≤ P ^ 2 * S :=
        Nat.mul_le_mul hLR_P2 hM0lS
      have ht2 : (inst.cp.L_p2 * inst.cp.R) * (2 ^ inst.cp.L_p2 * inst.cp.cap_u) ≤ P ^ 2 * S :=
        Nat.mul_le_mul hLR_P2 h2LpCuS
      have hexp : 3 + 8 * inst.cp.n + 2 * (2 + 2 * 2 ^ inst.cp.L_p2 + inst.cp.n +
          2 * inst.cp.L_p2 * (4 + 2 * inst.cp.R * inst.cp.M₀ ^ inst.cp.ℓ +
            5 * 2 ^ inst.cp.L_p2 * inst.cp.R * inst.cp.cap_u)) =
          7 + 10 * inst.cp.n + 4 * 2 ^ inst.cp.L_p2 + 16 * inst.cp.L_p2 +
            8 * ((inst.cp.L_p2 * inst.cp.R) * inst.cp.M₀ ^ inst.cp.ℓ) +
            20 * ((inst.cp.L_p2 * inst.cp.R) * (2 ^ inst.cp.L_p2 * inst.cp.cap_u)) := by ring
      rw [hexp] at hcw
      have hn_P2S : inst.cp.n ≤ P ^ 2 * S := le_trans hnS hS_P2S
      have h2L_P2S : 2 ^ inst.cp.L_p2 ≤ P ^ 2 * S := le_trans h2LpS hS_P2S
      have hLp_P2S : inst.cp.L_p2 ≤ P ^ 2 * S := le_trans (by omega : inst.cp.L_p2 ≤ P) hPS
      have h1_P2S : 1 ≤ P ^ 2 * S := le_trans hS1 hS_P2S
      linarith only [hcw, ht1, ht2, hn_P2S, h2L_P2S, hLp_P2S, h1_P2S]
    have hcr_le : cmOps.cfgRStride.toNat ≤ 8 * P ^ 2 * S := by
      have hLd : inst.cp.L_p2 * (d + 1) ≤ P ^ 2 := by
        calc inst.cp.L_p2 * (d + 1) ≤ P * P := Nat.mul_le_mul (by omega) hd1
          _ = P ^ 2 := by ring
      have ht1 : (inst.cp.L_p2 * (d + 1)) * (inst.cp.R * inst.cp.ℓ * inst.cp.M₀) ≤ P ^ 2 * S :=
        Nat.mul_le_mul hLd hRlMS
      have ht2 : d * 2 ^ inst.cp.L_p2 ≤ P ^ 2 * S := by
        calc d * 2 ^ inst.cp.L_p2 ≤ P * S := Nat.mul_le_mul (by omega) h2LpS
          _ ≤ P ^ 2 * S := Nat.mul_le_mul_right S (self_le_pow hP1 (by decide : 1 ≤ 2))
      have hexp : 2 * (d + 2 ^ inst.cp.L_p2 * d +
          2 * inst.cp.L_p2 * (inst.cp.R * inst.cp.ℓ * inst.cp.M₀ * (d + 1))) =
          2 * d + 2 * (d * 2 ^ inst.cp.L_p2) +
            4 * ((inst.cp.L_p2 * (d + 1)) * (inst.cp.R * inst.cp.ℓ * inst.cp.M₀)) := by ring
      rw [hexp] at hcr
      have hd_P2S : d ≤ P ^ 2 * S := le_trans (by omega : d ≤ P) hPS
      linarith only [hcr, ht1, ht2, hd_P2S]
    have hnW_le : ops.nodeWStride ≤ 106 * P ^ 3 * S := by
      have hNcw : inst.cp.N_cfg * cmOps.cfgWStride.toNat ≤ 65 * P ^ 3 * S := by
        calc inst.cp.N_cfg * cmOps.cfgWStride.toNat ≤ P * (65 * P ^ 2 * S) := Nat.mul_le_mul hNcfg hcw_le
          _ = 65 * P ^ 3 * S := by ring
      have hS_P3S : S ≤ P ^ 3 * S := by
        calc S = 1 * S := by ring
          _ ≤ P ^ 3 * S := Nat.mul_le_mul_right S (Nat.one_le_pow 3 P hP1)
      have h1 : 1 ≤ P ^ 3 * S := le_trans hS1 hS_P3S
      have h2 : inst.cp.n ≤ P ^ 3 * S := le_trans hnS hS_P3S
      have h3 : 2 ^ inst.cp.L_p2 ≤ P ^ 3 * S := le_trans h2LpS hS_P3S
      rw [hnW_eq]; linarith only [hNcw, h1, h2, h3]
    have hnR_le : ops.nodeRStride ≤ 13 * P ^ 3 * S := by
      have hNcr : inst.cp.N_cfg * cmOps.cfgRStride.toNat ≤ 8 * P ^ 3 * S := by
        calc inst.cp.N_cfg * cmOps.cfgRStride.toNat ≤ P * (8 * P ^ 2 * S) := Nat.mul_le_mul hNcfg hcr_le
          _ = 8 * P ^ 3 * S := by ring
      have hS_P3S : S ≤ P ^ 3 * S := by
        calc S = 1 * S := by ring
          _ ≤ P ^ 3 * S := Nat.mul_le_mul_right S (Nat.one_le_pow 3 P hP1)
      have hd_P3S : d ≤ P ^ 3 * S := by
        calc d ≤ P * 1 := by omega
          _ ≤ P ^ 3 * S := Nat.mul_le_mul (self_le_pow hP1 (by decide : 1 ≤ 3)) hS1
      have h1 : 1 ≤ P ^ 3 * S := le_trans hS1 hS_P3S
      have h3 : 2 ^ inst.cp.L_p2 ≤ P ^ 3 * S := le_trans h2LpS hS_P3S
      rw [hnR_eq]; linarith only [hNcr, hd_P3S, h1, h3]
    have hMslots : M_slots inst.cp ≤ 13 * P ^ 2 := by
      unfold M_slots
      have hDm2 : inst.cp.D_max * inst.cp.D_max ≤ P ^ 2 := by
        calc inst.cp.D_max * inst.cp.D_max ≤ P * P := Nat.mul_le_mul hDm hDm
          _ = P ^ 2 := by ring
      have hDm_P2 : inst.cp.D_max ≤ P ^ 2 :=
        le_trans hDm (self_le_pow hP1 (by decide : 1 ≤ 2))
      have h1_P2 : 1 ≤ P ^ 2 := Nat.one_le_pow 2 P hP1
      linarith only [hDm2, hDm_P2, h1_P2]
    have hSstride : S_stride inst.cp ≤ 10 * P * S := by
      unfold S_stride
      have h1_PS : 1 ≤ P * S := Nat.mul_pos hP1 hS1
      have hn_PS : inst.cp.n ≤ P * S := by
        calc inst.cp.n = 1 * inst.cp.n := by ring
          _ ≤ P * S := Nat.mul_le_mul hP1 hnS
      have hB_PS : inst.cp.B_scan ≤ P * S := by
        calc inst.cp.B_scan = inst.cp.B_scan * 1 := by ring
          _ ≤ P * S := Nat.mul_le_mul hBsc hS1
      linarith only [h1_PS, hn_PS, hB_PS]
    have hopW_le : cmOps.opWScrStride.toNat ≤ 67 * P * S := by
      have h1_PS : 1 ≤ P * S := Nat.mul_pos hP1 hS1
      have hl_PS : inst.cp.ℓ ≤ P * S := by
        calc inst.cp.ℓ = inst.cp.ℓ * 1 := by ring
          _ ≤ P * S := Nat.mul_le_mul (by omega) hS1
      have hlM_PS : inst.cp.ℓ * inst.cp.M₀ ≤ P * S :=
        Nat.mul_le_mul (by omega) (le_trans hM0W hWS)
      have hcc_PS : inst.cp.cap_u + inst.cp.cap_q ≤ P * S := by
        calc inst.cp.cap_u + inst.cp.cap_q = 1 * (inst.cp.cap_u + inst.cp.cap_q) := by ring
          _ ≤ P * S := Nat.mul_le_mul hP1 (le_trans hCuCqW hWS)
      linarith only [how, h1_PS, hl_PS, hlM_PS, hcc_PS]
    have hopR_le : cmOps.opRScrStride.toNat ≤ 18 * P * S := by
      have h1_PS : 1 ≤ P * S := Nat.mul_pos hP1 hS1
      have hd_PS : d ≤ P * S := by
        calc d = d * 1 := by ring
          _ ≤ P * S := Nat.mul_le_mul (by omega) hS1
      linarith only [hor, h1_PS, hd_PS]
    have hhpj_cap : hpjWordCap inst.cp ≤ (20 + Nat.ceil hpjOpConst) * P ^ 13 * S := by
      have hp := hpjWordCap_le_poly inst.cp
      have hd10_k3 : (d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3 ≤ P ^ 13 := by
        calc (d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3
            ≤ P ^ 10 * P ^ 3 := Nat.mul_le_mul (Nat.pow_le_pow_left hd1 10) (Nat.pow_le_pow_left hkphi 3)
          _ = P ^ 13 := by ring
      have ht_hpj : Nat.ceil hpjOpConst * (d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3 ≤
          Nat.ceil hpjOpConst * P ^ 13 := by
        calc Nat.ceil hpjOpConst * (d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3
            = Nat.ceil hpjOpConst * ((d + 1) ^ 10 * inst.cp.P_hpj.k_phi ^ 3) := by ring
          _ ≤ Nat.ceil hpjOpConst * P ^ 13 := Nat.mul_le_mul_left _ hd10_k3
      have hNs13 : inst.cp.N_samp ≤ P ^ 13 := le_trans hNs (self_le_pow hP1 (by decide : 1 ≤ 13))
      have hBw13 : inst.cp.B_walk ≤ P ^ 13 := le_trans hBw (self_le_pow hP1 (by decide : 1 ≤ 13))
      have hd13 : d ≤ P ^ 13 := le_trans (by omega : d ≤ P) (self_le_pow hP1 (by decide : 1 ≤ 13))
      have hlin_cap : 16 + inst.cp.N_samp + inst.cp.B_walk + 2 * d ≤ 20 * P ^ 13 := by
        linarith only [hP13_ge1, hNs13, hBw13, hd13]
      have hsum13 : hpjWordCap inst.cp ≤ (20 + Nat.ceil hpjOpConst) * P ^ 13 := by
        calc hpjWordCap inst.cp
            ≤ 20 * P ^ 13 + Nat.ceil hpjOpConst * P ^ 13 :=
              le_trans hp (Nat.add_le_add hlin_cap ht_hpj)
          _ = (20 + Nat.ceil hpjOpConst) * P ^ 13 := by ring
      calc hpjWordCap inst.cp ≤ (20 + Nat.ceil hpjOpConst) * P ^ 13 := hsum13
        _ = (20 + Nat.ceil hpjOpConst) * P ^ 13 * 1 := by ring
        _ ≤ (20 + Nat.ceil hpjOpConst) * P ^ 13 * S := Nat.mul_le_mul_left _ hS1
    have hPS_le_13 : P * S ≤ P ^ 13 * S :=
      Nat.mul_le_mul_right S (self_le_pow hP1 (by decide : 1 ≤ 13))
    have hP2S_le_13 : P ^ 2 * S ≤ P ^ 13 * S :=
      Nat.mul_le_mul_right S (hpow (by decide))
    have hP5S_le_13 : P ^ 5 * S ≤ P ^ 13 * S :=
      Nat.mul_le_mul_right S (hpow (by decide))
    have hS_le_13 : S ≤ P ^ 13 * S := by
      calc S = 1 * S := by ring
        _ ≤ P ^ 13 * S := Nat.mul_le_mul_right S hP13_ge1
    have h1_le_13 : 1 ≤ P ^ 13 * S := le_trans hS1 hS_le_13
    have hMnW : M_slots inst.cp * ops.nodeWStride ≤ 1378 * (P ^ 13 * S) := by
      calc M_slots inst.cp * ops.nodeWStride
          ≤ (13 * P ^ 2) * (106 * P ^ 3 * S) := Nat.mul_le_mul hMslots hnW_le
        _ = 1378 * (P ^ 5 * S) := by ring
        _ ≤ 1378 * (P ^ 13 * S) := Nat.mul_le_mul_left 1378 hP5S_le_13
    have hMnR : M_slots inst.cp * ops.nodeRStride ≤ 169 * (P ^ 13 * S) := by
      calc M_slots inst.cp * ops.nodeRStride
          ≤ (13 * P ^ 2) * (13 * P ^ 3 * S) := Nat.mul_le_mul hMslots hnR_le
        _ = 169 * (P ^ 5 * S) := by ring
        _ ≤ 169 * (P ^ 13 * S) := Nat.mul_le_mul_left 169 hP5S_le_13
    have hArr : (2 + 4 * inst.cp.D_max) * S_stride inst.cp ≤ 60 * (P ^ 13 * S) := by
      have h24 : 2 + 4 * inst.cp.D_max ≤ 6 * P := by omega
      calc (2 + 4 * inst.cp.D_max) * S_stride inst.cp
          ≤ (6 * P) * (10 * P * S) := Nat.mul_le_mul h24 hSstride
        _ = 60 * (P ^ 2 * S) := by ring
        _ ≤ 60 * (P ^ 13 * S) := Nat.mul_le_mul_left 60 hP2S_le_13
    have hDmSq : inst.cp.D_max * inst.cp.D_max ≤ P ^ 13 * S := by
      calc inst.cp.D_max * inst.cp.D_max ≤ P * P := Nat.mul_le_mul hDm hDm
        _ = P ^ 2 * 1 := by ring
        _ ≤ P ^ 2 * S := Nat.mul_le_mul_left _ hS1
        _ ≤ P ^ 13 * S := hP2S_le_13
    have hDm_13 : inst.cp.D_max ≤ P ^ 13 * S := by
      calc inst.cp.D_max ≤ P * 1 := by omega
        _ ≤ P * S := Nat.mul_le_mul_left P hS1
        _ ≤ P ^ 13 * S := hPS_le_13
    have hBstep_13 : inst.cp.B_STEP ≤ P ^ 13 * S :=
      le_trans (le_trans hBstepW hWS) hS_le_13
    have hMslots_13 : M_slots inst.cp ≤ 13 * (P ^ 13 * S) := by
      calc M_slots inst.cp ≤ 13 * P ^ 2 := hMslots
        _ = 13 * (P ^ 2 * 1) := by ring
        _ ≤ 13 * (P ^ 2 * S) := Nat.mul_le_mul_left 13 (Nat.mul_le_mul_left _ hS1)
        _ ≤ 13 * (P ^ 13 * S) := Nat.mul_le_mul_left 13 hP2S_le_13
    have hopW_13 : cmOps.opWScrStride.toNat ≤ 67 * (P ^ 13 * S) :=
      le_trans hopW_le (by
        calc 67 * P * S = 67 * (P * S) := by ring
          _ ≤ 67 * (P ^ 13 * S) := Nat.mul_le_mul_left 67 hPS_le_13)
    have hopR_13 : cmOps.opRScrStride.toNat ≤ 18 * (P ^ 13 * S) :=
      le_trans hopR_le (by
        calc 18 * P * S = 18 * (P * S) := by ring
          _ ≤ 18 * (P ^ 13 * S) := Nat.mul_le_mul_left 18 hPS_le_13)
    have hnd_13 : inst.cp.n * d ≤ P ^ 13 * S := by
      calc inst.cp.n * d = d * inst.cp.n := by ring
        _ ≤ P * S := Nat.mul_le_mul (by omega) hnS
        _ ≤ P ^ 13 * S := hPS_le_13
    have hd_13S : d ≤ P ^ 13 * S := by
      calc d ≤ P * 1 := by omega
        _ ≤ P * S := Nat.mul_le_mul_left P hS1
        _ ≤ P ^ 13 * S := hPS_le_13
    have hBW_le : ops.BW ≤ 1900 * (P ^ 13 * S) + hpjWordCap inst.cp := by
      rw [hBW_eq]
      linarith only [h1_le_13, hBstep_13, hDm_13, hDmSq, hArr, hMslots_13, hMnW, hopW_13]
    have hBR_le : ops.BR ≤ 260 * (P ^ 13 * S) := by
      rw [hBR_eq]
      linarith only [h1_le_13, hnd_13, hd_13S, hMnR, hopR_13]
    rw [hTW, hTR]
    calc 11 * ops.BW + 5 * ops.BR
        ≤ 11 * (1900 * (P ^ 13 * S) + ((20 + Nat.ceil hpjOpConst) * P ^ 13 * S)) +
            5 * (260 * (P ^ 13 * S)) :=
          Nat.add_le_add
            (Nat.mul_le_mul_left 11 (le_trans hBW_le (Nat.add_le_add_left hhpj_cap _)))
            (Nat.mul_le_mul_left 5 hBR_le)
      _ = (22420 + 11 * Nat.ceil hpjOpConst) * P ^ 13 * S := by ring
      _ ≤ C_node_space * P ^ 13 * S :=
          Nat.mul_le_mul_right S (Nat.mul_le_mul_right _ (by unfold C_node_space; omega))

  exact ⟨hOpen_le, hIns_le, hDel_le, hCbump, hCball, hHpj_le,
    by rw [hCread, hreadC], hCmrad, hSpace_le⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
