import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.lem_5_1
import UL.Stmt.clm_5_1_mc_baseline
import UL.Proof.cit_hpj19_thm18.H0
import UL.Proof.cit_hpj19_thm18.H1
import UL.Proof.cit_hpj19_thm18.H2
import UL.Proof.cit_hpj19_thm18.H3
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
import UL.Proof.clm_9_1_explicit_tradeoff.H3b2_GaussRAM
import UL.Proof.clm_9_1_explicit_tradeoff.H4a1_FilterPure
import UL.Proof.clm_9_1_explicit_tradeoff.H4b_DyadicMatching
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H4c1

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b

/-! ### 1. Positive-Depth Variance Nonnegativity & Residual Contraction from `S_lem_5_1` -/

private lemma inner_liftedPoint_eq {d : ℕ}
    (u v : EuclideanSpace ℝ (Fin d)) (a b : ℝ) :
    inner ℝ (liftedPoint u a) (liftedPoint v b) = inner ℝ u v + a * b := by
  rw [PiLp.inner_apply, Fin.sum_univ_castSucc, PiLp.inner_apply]
  congr 1
  · refine Finset.sum_congr rfl (fun i _ => ?_)
    simp [liftedPoint]
  · simp [liftedPoint, mul_comm]

/-- Any `α`-centerpoint (`0 < α`, `1 ≤ |P₀|`) of the paraboloid lift `P₀^+` lies above the
paraboloid: `0 ≤ liftVariance o s = s - ‖o‖^2`. -/
theorem liftVariance_nonneg_of_isCenterpoint {d : ℕ} {ι : Type*} [Fintype ι] [Nonempty ι]
    (Q_base : ι → EuclideanSpace ℝ (Fin d))
    {α : ℝ} (hα : 0 < α)
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (hcp : IsCenterpoint α (paraboloidLiftSet Q_base) (liftedPoint o s)) :
    0 ≤ liftVariance o s := by
  by_contra hneg
  push_neg at hneg
  unfold liftVariance at hneg
  let v : EuclideanSpace ℝ (Fin (d + 1)) := liftedPoint ((-2 : ℝ) • o) 1
  have hv_ne : v ≠ 0 := by
    intro hv0
    have hlast : v (Fin.last d) = (0 : EuclideanSpace ℝ (Fin (d + 1))) (Fin.last d) :=
      congrArg (fun z => z (Fin.last d)) hv0
    simp [v, liftedPoint] at hlast
  let β : ℝ := inner ℝ v (liftedPoint o s)
  have hβ_eq : β = s - 2 * ‖o‖ ^ 2 := by
    dsimp [β, v]
    rw [inner_liftedPoint_eq, inner_smul_left]
    simp
    ring
  let H : Set (EuclideanSpace ℝ (Fin (d + 1))) := {z | inner ℝ v z ≤ β}
  have hH_closed : IsClosedHalfspace H := ⟨v, hv_ne, β, rfl⟩
  have hz_in_H : liftedPoint o s ∈ H := le_refl β
  have hcount_zero : pointCount (paraboloidLiftSet Q_base) H = 0 := by
    classical
    unfold pointCount
    rw [Finset.card_eq_zero, Finset.filter_eq_empty_iff]
    intro i _
    change ¬ inner ℝ v (paraboloidLift (Q_base i)) ≤ β
    unfold paraboloidLift
    dsimp [v]
    rw [inner_liftedPoint_eq, inner_smul_left, hβ_eq]
    simp only [map_neg, map_ofNat, one_mul]
    have hnorm_sub : 0 ≤ ‖Q_base i - o‖ ^ 2 := sq_nonneg _
    have hexp : ‖Q_base i - o‖ ^ 2 = ‖Q_base i‖ ^ 2 - 2 * inner ℝ o (Q_base i) + ‖o‖ ^ 2 := by
      rw [norm_sub_sq_real, real_inner_comm]
    linarith only [hneg, hnorm_sub, hexp]
  have hdepth_zero : halfspaceDepth (paraboloidLiftSet Q_base) (liftedPoint o s) = 0 := by
    unfold halfspaceDepth
    exact Nat.eq_zero_of_le_zero (Nat.sInf_le ⟨H, hH_closed, hz_in_H, hcount_zero.symm⟩)
  unfold IsCenterpoint at hcp
  rw [hdepth_zero] at hcp
  have hcard_pos : (0 : ℝ) < (Fintype.card ι : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have hmul_pos : 0 < α * (Fintype.card ι : ℝ) := mul_pos hα hcard_pos
  push_cast at hcp
  linarith only [hcp, hmul_pos]

private lemma pointCount_subtype_eq_filter {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (A : Finset ℕ)
    (T : Set (EuclideanSpace ℝ (Fin d))) :
    open Classical in
    pointCount (fun i : ↥A => pts i.1) T = (A.filter (fun i => pts i ∈ T)).card := by
  classical
  unfold pointCount
  rw [← Finset.card_map ⟨Subtype.val, Subtype.val_injective⟩]
  apply congrArg Finset.card
  ext x
  simp [and_comm]

theorem hasNodeAge_zero (P₀ : Finset ℕ) : HasNodeAge P₀ P₀ 0 :=
  ⟨fun _ => P₀, rfl, rfl, fun r => Fin.elim0 r⟩

theorem hasNodeAge_step {P₀ S S' : Finset ℕ} {age : ℕ}
    (h : HasNodeAge P₀ S age) (hchg : IsInputChange S S') :
    HasNodeAge P₀ S' (age + 1) := by
  rcases h with ⟨seq, h0, hlast, hstep⟩
  refine ⟨Fin.snoc seq S', ?_, ?_, ?_⟩
  · simpa [Fin.snoc] using h0
  · simp [Fin.snoc]
  · intro r
    refine Fin.lastCases ?_ (fun i => ?_) r
    · have hsl : (Fin.last age).succ = Fin.last (age + 1) := by ext; simp
      rw [Fin.snoc_castSucc, hsl, Fin.snoc_last, hlast]
      exact hchg
    · simp only [Fin.snoc_castSucc, ← Fin.castSucc_succ]
      exact hstep i

theorem hasNodeAge_card_bounds {P₀ S : Finset ℕ} {age : ℕ}
    (h : HasNodeAge P₀ S age) :
    P₀.card ≤ S.card + age ∧
    S.card ≤ P₀.card + age ∧
    ∃ ops : List (ℕ ⊕ ℕ),
      (ops.filter Sum.isRight).length ≤ age ∧
      ops.foldl (fun acc op =>
        match op with
        | Sum.inl j => insert j acc
        | Sum.inr j => acc.erase j) P₀ = S := by
  induction age generalizing S with
  | zero =>
      rcases h with ⟨seq, h0, hlast, _⟩
      have heq : P₀ = S := by
        have : (0 : Fin 1) = Fin.last 0 := rfl
        rw [← h0, ← hlast, this]
      subst heq
      exact ⟨by omega, by omega, [], by simp, rfl⟩
  | succ t ih =>
      rcases h with ⟨seq, h0, hlast, hstep⟩
      let S_mid := seq (Fin.last t).castSucc
      have hmid : HasNodeAge P₀ S_mid t := by
        refine ⟨fun j => seq j.castSucc, h0, rfl, fun r => ?_⟩
        dsimp only
        have hsucc : (r.succ : Fin (t + 1)).castSucc = r.castSucc.succ := by ext; rfl
        rw [hsucc]; exact hstep r.castSucc
      rcases ih hmid with ⟨hlo, hhi, ops, hdel, hfold⟩
      have hlast_step : IsInputChange S_mid S := by
        rw [← hlast]; exact hstep (Fin.last t)
      rcases hlast_step with ⟨x, hx, hS_eq⟩ | ⟨x, hx, hS_eq⟩
      · have hS_std : S = insert x S_mid := by
          rw [hS_eq]; ext z; simp
        subst hS_std
        have hcard := Finset.card_insert_of_notMem hx
        refine ⟨by omega, by omega, ops ++ [Sum.inl x], ?_, ?_⟩
        · rw [List.filter_append]; simpa using hdel.trans (Nat.le_succ t)
        · rw [List.foldl_append]; simp [hfold]
      · have hS_std : S = S_mid.erase x := by
          rw [hS_eq]; ext z; simp
        subst hS_std
        have hcard := Finset.card_erase_of_mem hx
        have hpos : 1 ≤ S_mid.card := Finset.card_pos.mpr ⟨x, hx⟩
        refine ⟨by omega, by omega, ops ++ [Sum.inr x], ?_, ?_⟩
        · rw [List.filter_append]; simp; omega
        · rw [List.foldl_append]; simp [hfold]

/-- Residual contraction from `S_lem_5_1`: if `(o, s)` is an `α`-centerpoint of `P₀^+` (`1 ≤ |P₀|`,
`0 < α ≤ 1`) and `HasNodeAge P₀ S age` with `(age : ℝ) ≤ α * |P₀| / 16`, then for
`V = max 0 (liftVariance o s)`:
1. `V = liftVariance o s` (`0 ≤ liftVariance o s`);
2. `|nodeResidual pts o V S| ≤ (1 - α / 2) * |S|`;
3. When `age = 0` (`S = P₀`) and `1 < α * |P₀|`, `|nodeResidual pts o V P₀| + 1 ≤ |P₀|`. -/
theorem residual_contraction_of_lem51
    (h_lem_5_1 : S_lem_5_1)
    {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    {P₀ S : Finset ℕ} (hm : 1 ≤ P₀.card)
    {α : ℝ} (hα0 : 0 < α) (hα1 : α ≤ 1)
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s))
    {age : ℕ} (hage : HasNodeAge P₀ S age)
    (hage_ub : (age : ℝ) ≤ α * (P₀.card : ℝ) / 16) :
    let V := max 0 (liftVariance o s)
    V = liftVariance o s ∧
    ((nodeResidual pts o V S).card : ℝ) ≤ (1 - α / 2) * (S.card : ℝ) ∧
    (1 < α * (P₀.card : ℝ) → S = P₀ → (nodeResidual pts o V P₀).card + 1 ≤ P₀.card) := by
  haveI : Nonempty ↥P₀ := Finset.Nonempty.coe_sort (Finset.card_pos.mp hm)
  have hV_nn : 0 ≤ liftVariance o s := liftVariance_nonneg_of_isCenterpoint _ hα0 hcp
  have hV_eq : max 0 (liftVariance o s) = liftVariance o s := max_eq_right hV_nn
  rcases hasNodeAge_card_bounds hage with ⟨_, hScard_le, ops, hdel, hfold⟩
  have hdepth : α * (P₀.card : ℝ) ≤
      (halfspaceDepth (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) : ℝ) := by
    simpa [IsCenterpoint, Fintype.card_coe] using hcp
  have h51 := (h_lem_5_1 d ℕ pts P₀ hm α hα0 o s hdepth).2.2 age ops hdel
  have h51_0 := (h_lem_5_1 d ℕ pts P₀ hm α hα0 o s hdepth).1
  have hpc := h51.2.2.2.1
  rw [pointCount_subtype_eq_filter] at hpc
  classical
  have hcore_lb : α * (P₀.card : ℝ) - (age : ℝ) ≤ ((nodeCore pts o (liftVariance o s) S).card : ℝ) := by
    refine hpc.trans_eq ?_
    apply congrArg (fun (X : Finset ℕ) => (((X.filter (fun i => pts i ∈ coreBall o (liftVariance o s))).card : ℕ) : ℝ))
    refine Eq.trans ?_ hfold
    congr 1; ext acc op; cases op <;> rfl
  have hpart : (nodeResidual pts o (liftVariance o s) S).card +
      (nodeCore pts o (liftVariance o s) S).card = S.card :=
    @Finset.card_sdiff_add_card_eq_card ℕ (Classical.decEq ℕ) _ S (Finset.filter_subset _ S)
  have hpart_r : ((nodeResidual pts o (liftVariance o s) S).card : ℝ) +
      ((nodeCore pts o (liftVariance o s) S).card : ℝ) = (S.card : ℝ) := by
    exact_mod_cast hpart
  have hS_ub : (S.card : ℝ) ≤ (17 / 16 : ℝ) * (P₀.card : ℝ) := by
    have h1 : (S.card : ℝ) ≤ (P₀.card : ℝ) + (age : ℝ) := by exact_mod_cast hScard_le
    have h2 : α * (P₀.card : ℝ) ≤ 1 * (P₀.card : ℝ) :=
      mul_le_mul_of_nonneg_right hα1 (Nat.cast_nonneg _)
    linarith only [h1, hage_ub, h2]
  have hcore_half : (α / 2) * (S.card : ℝ) ≤ ((nodeCore pts o (liftVariance o s) S).card : ℝ) := by
    have hmul : (α / 2) * (S.card : ℝ) ≤ (α / 2) * ((17 / 16 : ℝ) * (P₀.card : ℝ)) :=
      mul_le_mul_of_nonneg_left hS_ub (by positivity)
    linarith only [hmul, hcore_lb, hage_ub]
  refine ⟨hV_eq, ?_, ?_⟩
  · rw [hV_eq]
    linarith only [hpart_r, hcore_half]
  · intro hgt1 hSP
    rw [hV_eq]
    rw [pointCount_subtype_eq_filter] at h51_0
    have hcore_pos_r : (1 : ℝ) < ((nodeCore pts o (liftVariance o s) P₀).card : ℝ) :=
      lt_of_lt_of_le hgt1 h51_0
    have hcore_pos : 1 ≤ (nodeCore pts o (liftVariance o s) P₀).card := by
      have : 0 < (nodeCore pts o (liftVariance o s) P₀).card := by exact_mod_cast ( zero_lt_one.trans hcore_pos_r )
      omega
    have hp0 : (nodeResidual pts o (liftVariance o s) P₀).card + (nodeCore pts o (liftVariance o s) P₀).card = P₀.card :=
      @Finset.card_sdiff_add_card_eq_card ℕ (Classical.decEq ℕ) _ P₀ (Finset.filter_subset _ P₀)
    omega

/-! ### 2. Swap-with-Back Dense Array & Associative Tournament Max-Radius Selector -/

/-- Insert handle `h` at the back of dense array `arr`. -/
def denseInsert (h : ℕ) (arr : List ℕ) : List ℕ :=
  arr ++ [h]

/-- Swap-with-back deletion of handle `h` from duplicate-free dense array `arr` (exact pure model
of `O(1)` RAM swap-with-back!). -/
def denseDelete (h : ℕ) (arr : List ℕ) : List ℕ :=
  let idx := arr.idxOf h
  let sz := arr.length
  if hlt : idx < sz then
    if idx = sz - 1 then
      arr.take (sz - 1)
    else
      have hlast : sz - 1 < arr.length := by omega
      (arr.take (sz - 1)).set idx arr[sz - 1]
  else
    arr

theorem denseInsert_spec {h : ℕ} {arr : List ℕ}
    (hnd : arr.Nodup) (hnot : h ∉ arr.toFinset) :
    (denseInsert h arr).Nodup ∧ (denseInsert h arr).toFinset = insert h arr.toFinset := by
  have hnot_l : h ∉ arr := fun hm => hnot (List.mem_toFinset.mpr hm)
  unfold denseInsert
  refine ⟨List.nodup_append.mpr ⟨hnd, List.nodup_singleton h, fun x hx y hy heq => ?_⟩, ?_⟩
  · rw [List.mem_singleton.mp hy] at heq; exact hnot_l (heq ▸ hx)
  · ext x; simp only [List.mem_toFinset, List.mem_append, List.mem_singleton, Finset.mem_insert]; exact or_comm

theorem denseDelete_spec {h : ℕ} {arr : List ℕ} (hnd : arr.Nodup) :
    (denseDelete h arr).Nodup ∧ (denseDelete h arr).toFinset = arr.toFinset.erase h := by
  unfold denseDelete
  dsimp only
  by_cases hmem : h ∈ arr
  · have hlt : arr.idxOf h < arr.length := List.idxOf_lt_length_of_mem hmem
    rw [dif_pos hlt]
    set idx := arr.idxOf h
    set sz := arr.length
    have hget_idx : arr[idx] = h := List.getElem_idxOf hlt
    by_cases hlast_eq : idx = sz - 1
    · rw [if_pos hlast_eq]
      have harr_split : arr = arr.take (sz - 1) ++ [h] := by
        have h1 : arr = arr.take (sz - 1) ++ arr.drop (sz - 1) := (List.take_append_drop (sz - 1) arr).symm
        have hdrop : arr.drop (sz - 1) = [arr[sz - 1]] := by
          rw [List.drop_eq_getElem_cons (by omega)]
          have : arr.drop (sz - 1 + 1) = [] := List.drop_eq_nil_of_le (by omega)
          rw [this]
        have hval_last : arr[sz - 1] = h := by
          have : arr[idx] = arr[sz - 1] := by simp only [hlast_eq]
          rw [← this, hget_idx]
        rw [hval_last] at hdrop
        rw [hdrop] at h1
        exact h1
      have hnd_app := harr_split ▸ hnd
      rcases List.nodup_append.mp hnd_app with ⟨hnd_tk, _, hdisj⟩
      refine ⟨hnd_tk, ?_⟩
      ext x
      simp only [List.mem_toFinset, Finset.mem_erase]
      conv_rhs => rw [harr_split]
      simp only [List.mem_append, List.mem_singleton]
      constructor
      · intro hx
        refine ⟨?_, Or.inl hx⟩
        intro heq; subst heq; exact hdisj x hx x (List.mem_singleton_self _) rfl
      · rintro ⟨hne, hx | rfl⟩
        · exact hx
        · exact absurd rfl hne
    · rw [if_neg hlast_eq]
      have idx_lt_tk : idx < (arr.take (sz - 1)).length := by
        rw [List.length_take]; omega
      let lastVal := arr[sz - 1]
      have harr_split : arr = arr.take (sz - 1) ++ [lastVal] := by
        have h1 : arr = arr.take (sz - 1) ++ arr.drop (sz - 1) := (List.take_append_drop (sz - 1) arr).symm
        have hdrop : arr.drop (sz - 1) = [lastVal] := by
          rw [List.drop_eq_getElem_cons (by omega)]
          have : arr.drop (sz - 1 + 1) = [] := List.drop_eq_nil_of_le (by omega)
          rw [this]
        rw [hdrop] at h1; exact h1
      have hnd_app := harr_split ▸ hnd
      rcases List.nodup_append.mp hnd_app with ⟨hnd_tk, _, hdisj⟩
      have hlast_not_tk : lastVal ∉ arr.take (sz - 1) := fun hm => hdisj lastVal hm lastVal (List.mem_singleton_self _) rfl
      -- `(arr.take (sz - 1))[idx] = h`
      have htk_idx : (arr.take (sz - 1))[idx] = h := by
        rw [List.getElem_take]; exact hget_idx
      -- Split `arr.take (sz - 1)` around `idx`
      let L1 := (arr.take (sz - 1)).take idx
      let L2 := (arr.take (sz - 1)).drop (idx + 1)
      have htk_split : arr.take (sz - 1) = L1 ++ h :: L2 := by
        have h1 := (List.take_append_drop idx (arr.take (sz - 1))).symm
        have h2 : (arr.take (sz - 1)).drop idx = h :: L2 := by
          rw [List.drop_eq_getElem_cons idx_lt_tk, htk_idx]
        rw [h2] at h1; exact h1
      have hset_eq : (arr.take (sz - 1)).set idx lastVal = L1 ++ lastVal :: L2 := by
        have hlen_L1 : L1.length = idx := by dsimp [L1]; rw [List.length_take]; omega
        rw [htk_split, List.set_append_right _ _ (by omega)]
        simp [hlen_L1]
      rw [hset_eq]
      have hnd_mid := htk_split ▸ hnd_tk
      rcases List.nodup_append.mp hnd_mid with ⟨hnd1, hnd_h2, hdisj12⟩
      rcases List.nodup_cons.mp hnd_h2 with ⟨hh_not2, hnd2⟩
      have hh_not1 : h ∉ L1 := fun hm => hdisj12 h hm h List.mem_cons_self rfl
      have hlast_not1 : lastVal ∉ L1 := fun hm => hlast_not_tk (by rw [htk_split]; exact List.mem_append_left _ hm)
      have hlast_not2 : lastVal ∉ L2 := fun hm => hlast_not_tk (by rw [htk_split]; exact List.mem_append_right _ (List.mem_cons_of_mem h hm))
      have hh_ne_last : lastVal ≠ h := fun heq => hlast_not_tk (by rw [heq, htk_split]; exact List.mem_append_right _ List.mem_cons_self)
      refine ⟨?_, ?_⟩
      · refine List.nodup_append.mpr ⟨hnd1, List.nodup_cons.mpr ⟨hlast_not2, hnd2⟩, fun a ha b hb heq => ?_⟩
        rcases List.mem_cons.mp hb with rfl | hb2
        · exact hlast_not1 (heq ▸ ha)
        · exact hdisj12 a ha b (List.mem_cons_of_mem h hb2) heq
      · ext x
        simp only [List.mem_toFinset, Finset.mem_erase]
        conv_rhs => rw [harr_split, htk_split]
        simp only [List.mem_append, List.mem_cons, List.not_mem_nil, or_false]
        constructor
        · rintro (hx1 | rfl | hx2)
          · exact ⟨fun heq => hh_not1 (heq ▸ hx1), Or.inl (Or.inl hx1)⟩
          · exact ⟨hh_ne_last, Or.inr rfl⟩
          · exact ⟨fun heq => hh_not2 (heq ▸ hx2), Or.inl (Or.inr (Or.inr hx2))⟩
        · rintro ⟨hne, (hx1 | rfl | hx2) | rfl⟩
          · exact Or.inl hx1
          · exact absurd rfl hne
          · exact Or.inr (Or.inr hx2)
          · exact Or.inr (Or.inl rfl)
  · have hnot_lt : ¬ arr.idxOf h < arr.length := by
      intro hlt
      have hm := List.getElem_mem hlt
      rw [List.getElem_idxOf hlt] at hm
      exact hmem hm
    rw [dif_neg hnot_lt]
    have hnot_fs : h ∉ arr.toFinset := fun hm => hmem (List.mem_toFinset.mp hm)
    exact ⟨hnd, (Finset.erase_eq_of_notMem hnot_fs).symm⟩

/-- Left-biased tournament comparison on `Option ℕ` maximizing squared distance `‖pts h - o‖^2`. -/
noncomputable def pickBetter {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) : Option ℕ → Option ℕ → Option ℕ
  | none, b => b
  | a, none => a
  | some h₁, some h₂ =>
      open Classical in
      if ‖pts h₁ - o‖ ^ 2 < ‖pts h₂ - o‖ ^ 2 then some h₂ else some h₁

theorem pickBetter_assoc {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (a b c : Option ℕ) :
    pickBetter pts o (pickBetter pts o a b) c = pickBetter pts o a (pickBetter pts o b c) := by
  classical
  cases a with
  | none => rfl
  | some h₁ =>
      cases b with
      | none => rfl
      | some h₂ =>
          cases c with
          | none =>
              dsimp only [pickBetter]
              split_ifs <;> rfl
          | some h₃ =>
              dsimp only [pickBetter]
              by_cases h12 : ‖pts h₁ - o‖ ^ 2 < ‖pts h₂ - o‖ ^ 2
              · rw [if_pos h12]
                dsimp only [pickBetter]
                by_cases h23 : ‖pts h₂ - o‖ ^ 2 < ‖pts h₃ - o‖ ^ 2
                · rw [if_pos h23]; dsimp only [pickBetter]; rw [if_pos (h12.trans h23)]
                · rw [if_neg h23]; dsimp only [pickBetter]; rw [if_pos h12]
              · rw [if_neg h12]
                dsimp only [pickBetter]
                by_cases h23 : ‖pts h₂ - o‖ ^ 2 < ‖pts h₃ - o‖ ^ 2
                · rw [if_pos h23]
                · rw [if_neg h23]
                  dsimp only [pickBetter]
                  have hnot13 : ¬ ‖pts h₁ - o‖ ^ 2 < ‖pts h₃ - o‖ ^ 2 := by
                    intro h13; linarith only [h12, h23, h13]
                  rw [if_neg hnot13, if_neg h12]

/-- Canonical tournament winner over handle universe `0 .. T_pow - 1` (`S ⊆ range T_pow`). -/
noncomputable def maxRadiusHandle {d : ℕ} (T_pow : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (S : Finset ℕ) : Option ℕ :=
  open Classical in
  (List.range T_pow).foldl
    (fun acc h => pickBetter pts o acc (if h ∈ S then some h else none)) none

theorem maxRadiusHandle_spec {d : ℕ} (T_pow : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    {S : Finset ℕ} (hS_sub : ∀ h ∈ S, h < T_pow) :
    (S = ∅ → maxRadiusHandle T_pow pts o S = none) ∧
    (S.Nonempty → ∃ y : ℕ,
      maxRadiusHandle T_pow pts o S = some y ∧
      IsNodeMaxRadiusPoint pts o S y) := by
  classical
  have hfold_inv : ∀ (m : ℕ),
      let res := (List.range m).foldl
        (fun acc h => pickBetter pts o acc (if h ∈ S then some h else none)) none
      let Sm := S.filter (· < m)
      (Sm = ∅ → res = none) ∧
      (Sm.Nonempty → ∃ y ∈ Sm, res = some y ∧ ∀ x ∈ Sm, ‖pts x - o‖ ^ 2 ≤ ‖pts y - o‖ ^ 2) := by
    intro m
    induction m with
    | zero =>
        simp
    | succ m ih =>
        dsimp only at ih ⊢
        rw [List.range_succ, List.foldl_append, List.foldl_cons, List.foldl_nil]
        set prev := (List.range m).foldl
          (fun acc h => pickBetter pts o acc (if h ∈ S then some h else none)) none
        have hSm_eq : S.filter (· < m + 1) =
            if m ∈ S then insert m (S.filter (· < m)) else S.filter (· < m) := by
          ext x
          by_cases hm : m ∈ S <;> simp only [hm, ↓reduceIte, Finset.mem_filter, Finset.mem_insert]
          · constructor
            · rintro ⟨hxS, hlt⟩
              by_cases hxm : x = m
              · exact Or.inl hxm
              · exact Or.inr ⟨hxS, by omega⟩
            · rintro (rfl | ⟨hxS, hlt⟩)
              · exact ⟨hm, by omega⟩
              · exact ⟨hxS, by omega⟩
          · constructor
            · rintro ⟨hxS, hlt⟩
              have hne : x ≠ m := fun heq => hm (heq ▸ hxS)
              exact ⟨hxS, by omega⟩
            · rintro ⟨hxS, hlt⟩
              exact ⟨hxS, by omega⟩
        by_cases hmS : m ∈ S
        · rw [if_pos hmS, hSm_eq, if_pos hmS]
          refine ⟨fun hemp => absurd (Finset.mem_insert_self m _) (hemp ▸ Finset.notMem_empty m),
            fun _ => ?_⟩
          by_cases hprev_ne : (S.filter (· < m)).Nonempty
          · rcases ih.2 hprev_ne with ⟨y₀, hy₀, hprev_eq, hmax₀⟩
            rw [hprev_eq]
            dsimp only [pickBetter]
            by_cases hlt_m : ‖pts y₀ - o‖ ^ 2 < ‖pts m - o‖ ^ 2
            · rw [if_pos hlt_m]
              refine ⟨m, Finset.mem_insert_self _ _, rfl, fun x hx => ?_⟩
              rcases Finset.mem_insert.mp hx with rfl | hx₀
              · exact le_rfl
              · exact (hmax₀ x hx₀).trans hlt_m.le
            · rw [if_neg hlt_m]
              refine ⟨y₀, Finset.mem_insert_of_mem hy₀, rfl, fun x hx => ?_⟩
              rcases Finset.mem_insert.mp hx with rfl | hx₀
              · exact not_lt.mp hlt_m
              · exact hmax₀ x hx₀
          · have hprev_emp : S.filter (· < m) = ∅ := Finset.not_nonempty_iff_eq_empty.mp hprev_ne
            rw [ih.1 hprev_emp]
            dsimp only [pickBetter]
            refine ⟨m, Finset.mem_insert_self _ _, rfl, fun x hx => ?_⟩
            rcases Finset.mem_insert.mp hx with rfl | hx₀
            · exact le_rfl
            · rw [hprev_emp] at hx₀; exact absurd hx₀ (Finset.notMem_empty _)
        · rw [if_neg hmS, hSm_eq, if_neg hmS]
          have hp : pickBetter pts o prev none = prev := by cases prev <;> rfl
          rw [hp]; exact ih
  have hST : S.filter (· < T_pow) = S := Finset.filter_true_of_mem (fun x hx => hS_sub x hx)
  have hT := hfold_inv T_pow
  dsimp only at hT
  rw [hST] at hT
  refine ⟨hT.1, fun hne => ?_⟩
  rcases hT.2 hne with ⟨y, hyS, heq, hall_sq⟩
  refine ⟨y, heq, hyS, ?_⟩
  unfold nodeMaxRadius
  rw [dif_pos hne]
  apply le_antisymm
  · exact Finset.le_sup' (fun i => ‖pts i - o‖) hyS
  · refine Finset.sup'_le hne _ (fun x hxS => ?_)
    have hsq := hall_sq x hxS
    have hnn_x : 0 ≤ ‖pts x - o‖ := norm_nonneg _
    have hnn_y : 0 ≤ ‖pts y - o‖ := norm_nonneg _
    nlinarith only [hsq, hnn_x, hnn_y]

/-! ### 3. HPJ19 Centerpoint & Baseline Sample Good-Coin Cardinality Theorems -/

private lemma halfspaceDepth_equiv {k : ℕ} {ι₁ ι₂ : Type*} [Fintype ι₁] [Fintype ι₂]
    (e : ι₁ ≃ ι₂) (Q : ι₂ → EuclideanSpace ℝ (Fin k)) (z : EuclideanSpace ℝ (Fin k)) :
    halfspaceDepth (Q ∘ e) z = halfspaceDepth Q z := by
  classical
  unfold halfspaceDepth
  congr 1
  ext n
  constructor
  · rintro ⟨H, hH, hz, rfl⟩
    refine ⟨H, hH, hz, ?_⟩
    unfold pointCount
    rw [← Finset.card_map e.toEmbedding]
    apply congrArg Finset.card; ext x; simp
  · rintro ⟨H, hH, hz, rfl⟩
    refine ⟨H, hH, hz, ?_⟩
    unfold pointCount
    rw [← Finset.card_map e.symm.toEmbedding]
    apply congrArg Finset.card; ext x; simp

theorem isCenterpoint_of_nodup_list {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    {arr : List ℕ} (hnd : arr.Nodup) {P₀ : Finset ℕ} (hP₀ : arr.toFinset = P₀)
    {α : ℝ} {z : EuclideanSpace ℝ (Fin (d + 1))}
    (hcp : IsCenterpoint α (fun j : Fin arr.length => paraboloidLift (pts arr[j.val])) z) :
    IsCenterpoint α (paraboloidLiftSet (fun x : ↥P₀ => pts x.1)) z := by
  let f : Fin arr.length → ↥P₀ := fun j =>
    ⟨arr[j.val], hP₀ ▸ List.mem_toFinset.mpr (List.getElem_mem j.isLt)⟩
  have hf_inj : Function.Injective f := by
    intro a b hab
    have hval : arr[a.val] = arr[b.val] := congrArg Subtype.val hab
    exact Fin.ext ((List.Nodup.getElem_inj_iff hnd).mp hval)
  have hcard : Fintype.card (Fin arr.length) = Fintype.card ↥P₀ := by
    rw [Fintype.card_fin, Fintype.card_coe, ← hP₀, List.toFinset_card_of_nodup hnd]
  let e : Fin arr.length ≃ ↥P₀ :=
    Equiv.ofBijective f ((Fintype.bijective_iff_injective_and_card f).mpr ⟨hf_inj, hcard⟩)
  unfold IsCenterpoint at hcp ⊢
  rw [← hcard, ← halfspaceDepth_equiv e]
  exact hcp

/-- Combined good-coin bound for a single HPJ19 call on `arr` (`arr.length = sz ≥ 1`, `arr.Nodup`,
`arr.toFinset = P₀`), sampling `N_samp` indices via `u_k % sz` (`q_idx` bits each) and walk bits:
at least `(1 - φ - N_samp * sz * 2^{-q_idx})` of coin pairs produce an `hpjAlpha d`-centerpoint
of `P₀^+`. -/
theorem hpjCenter_good_card_ge {d N_samp q_idx : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    {phiRat : ℚ} (hφ0 : 0 < (phiRat : ℝ)) (hφ1 : (phiRat : ℝ) < 1 / 2)
    {P : HPJParams} (hP : HPJParamProps d (phiRat : ℝ) P)
    (hmN : 2 ^ P.q ≤ N_samp)
    {arr : List ℕ} (hsz : 1 ≤ arr.length) (hnd : arr.Nodup)
    {P₀ : Finset ℕ} (hP₀ : arr.toFinset = P₀) :
    let B_walk := P.L * (d + 1 + 3) * P.q
    let CoinT := (Fin N_samp → Fin (2 ^ q_idx)) × (Fin B_walk → Bool)
    let evalZ : CoinT → EuclideanSpace ℝ (Fin (d + 1)) := fun cw =>
      let ω₀ : Fin (2 ^ P.q) → Fin arr.length := fun j =>
        ⟨(cw.1 ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩).val % arr.length, Nat.mod_lt _ hsz⟩
      radonWalkOutput (d + 1) P.q P.L (fun j => paraboloidLift (pts arr[(ω₀ j).val])) cw.2
    open Classical in
    (1 - (phiRat : ℝ) - ((N_samp * arr.length : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) *
        (Fintype.card CoinT : ℝ) ≤
      ((Finset.univ.filter (fun cw : CoinT =>
        IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun x : ↥P₀ => pts x.1)) (evalZ cw))).card : ℝ) := by
  classical
  let sz := arr.length
  haveI : Nonempty (Fin sz) := ⟨⟨0, hsz⟩⟩
  let Q_fin : Fin sz → EuclideanSpace ℝ (Fin (d + 1)) := fun i => paraboloidLift (pts arr[i.val])
  -- 1. Uniform good initial sample bound -> modulo-sampled bound on `Fin N_samp → Fin (2 ^ q_idx)`
  have hunif := card_goodInitialSample_prefix_ge hφ0 hφ1 P hP (Fin sz) Q_fin N_samp hmN
  have hmod := modSample_good_card_ge (q_idx := q_idx) hsz
    (fun ω : Fin N_samp → Fin sz =>
      GoodInitialSample Q_fin (hpjAlpha d) (fun j : Fin (2 ^ P.q) => ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩))
    (by positivity) hunif
  let B_walk := P.L * (d + 1 + 3) * P.q
  let GoodU : Finset (Fin N_samp → Fin (2 ^ q_idx)) :=
    Finset.univ.filter (fun u =>
      GoodInitialSample Q_fin (hpjAlpha d)
        (fun j : Fin (2 ^ P.q) => ⟨(u ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩).val % sz, Nat.mod_lt _ hsz⟩))
  -- 2. For every `u ∈ GoodU`, walk bits succeed with fraction `≥ 1 - φ / 2`!
  have hrad : ∀ (pts_r : Fin (d + 1 + 2) → EuclideanSpace ℝ (Fin (d + 1)))
      (K : Set (EuclideanSpace ℝ (Fin (d + 1)))),
      Convex ℝ K → gaussRadonPoint pts_r ∉ K →
        ∃ a b : Fin (d + 1 + 2), a ≠ b ∧ pts_r a ∉ K ∧ pts_r b ∉ K :=
    fun pts_r K hK hnot => gaussRadonPoint_avoid_of_convex pts_r K hK hnot
  let CoinT := (Fin N_samp → Fin (2 ^ q_idx)) × (Fin B_walk → Bool)
  let evalZ : CoinT → EuclideanSpace ℝ (Fin (d + 1)) := fun cw =>
    let ω₀ : Fin (2 ^ P.q) → Fin arr.length := fun j =>
      ⟨(cw.1 ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩).val % arr.length, Nat.mod_lt _ hsz⟩
    radonWalkOutput (d + 1) P.q P.L (fun j => paraboloidLift (pts arr[(ω₀ j).val])) cw.2
  let GoodCW := (Finset.univ : Finset CoinT).filter (fun cw =>
    IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun x : ↥P₀ => pts x.1)) (evalZ cw))
  have hfiber_ge : ∀ u ∈ GoodU,
      (1 - (phiRat : ℝ) / 2) * ((2 : ℝ) ^ B_walk) ≤
        (((Finset.univ : Finset (Fin B_walk → Bool)).filter (fun wb => (u, wb) ∈ GoodCW)).card : ℝ) := by
    intro u hu
    have hu_gd := (Finset.mem_filter.mp hu).2
    let ω₀ : Fin (2 ^ P.q) → Fin sz := fun j =>
      ⟨(u ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩).val % sz, Nat.mod_lt _ hsz⟩
    have hwb := card_goodWalkBits_centerpoint_ge hφ0 hφ1 P hP hrad (Fin sz) Q_fin ω₀ hu_gd
    refine hwb.trans (Nat.cast_le.mpr (Finset.card_le_card (fun wb hwb_mem => ?_)))
    have hcp_fin := (Finset.mem_filter.mp hwb_mem).2
    exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,
      Finset.mem_filter.mpr ⟨Finset.mem_univ _, isCenterpoint_of_nodup_list pts hnd hP₀ hcp_fin⟩⟩
  -- 3. Sum over `u ∈ GoodU` inside `GoodCW`!
  have hsum_le :
      (∑ u ∈ GoodU,
        (((Finset.univ : Finset (Fin B_walk → Bool)).filter (fun wb => (u, wb) ∈ GoodCW)).card : ℝ)) ≤
      (GoodCW.card : ℝ) := by
    rw [← Nat.cast_sum]
    apply Nat.cast_le.mpr
    have hsub : GoodU.biUnion (fun u =>
        ((Finset.univ : Finset (Fin B_walk → Bool)).filter (fun wb => (u, wb) ∈ GoodCW)).map
          ⟨fun wb => (u, wb), fun _ _ h => Prod.mk.inj h |>.2⟩) ⊆ GoodCW := by
      intro cw hcw
      rcases Finset.mem_biUnion.mp hcw with ⟨u, _, hmap⟩
      rcases Finset.mem_map.mp hmap with ⟨wb, hfilt, rfl⟩
      exact (Finset.mem_filter.mp hfilt).2
    calc (∑ u ∈ GoodU, ((Finset.univ.filter (fun wb => (u, wb) ∈ GoodCW)).card))
        = ∑ u ∈ GoodU, (((Finset.univ.filter (fun wb => (u, wb) ∈ GoodCW)).map
            ⟨fun wb => (u, wb), fun _ _ h => Prod.mk.inj h |>.2⟩).card) := by
            refine Finset.sum_congr rfl (fun _ _ => (Finset.card_map _).symm)
      _ = (GoodU.biUnion _).card := by
            refine (Finset.card_biUnion (fun u₁ _ u₂ _ hne => ?_)).symm
            unfold Function.onFun
            rw [Finset.disjoint_left]
            intro cw h1 h2
            rcases Finset.mem_map.mp h1 with ⟨_, _, rfl⟩
            rcases Finset.mem_map.mp h2 with ⟨_, _, heq⟩
            exact hne (Prod.mk.inj heq).1.symm
      _ ≤ GoodCW.card := Finset.card_le_card hsub
  have hprod_lb :
      (GoodU.card : ℝ) * ((1 - (phiRat : ℝ) / 2) * ((2 : ℝ) ^ B_walk)) ≤ (GoodCW.card : ℝ) := by
    calc (GoodU.card : ℝ) * ((1 - (phiRat : ℝ) / 2) * ((2 : ℝ) ^ B_walk))
        = ∑ _u ∈ GoodU, (1 - (phiRat : ℝ) / 2) * ((2 : ℝ) ^ B_walk) := by
          rw [Finset.sum_const, nsmul_eq_mul]
      _ ≤ _ := Finset.sum_le_sum hfiber_ge
      _ ≤ (GoodCW.card : ℝ) := hsum_le
  have hcard_prod : (Fintype.card CoinT : ℝ) =
      (Fintype.card (Fin N_samp → Fin (2 ^ q_idx)) : ℝ) * ((2 : ℝ) ^ B_walk) := by
    dsimp [CoinT]
    rw [Fintype.card_prod, Nat.cast_mul]
    congr 1
    rw [Fintype.card_fun, Fintype.card_fin, Fintype.card_bool]
    push_cast; rfl
  dsimp only
  change (1 - (phiRat : ℝ) - ((N_samp * arr.length : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) *
      (Fintype.card CoinT : ℝ) ≤ (GoodCW.card : ℝ)
  rw [hcard_prod]
  by_cases hpos_fac : 0 ≤ 1 - (phiRat : ℝ) / 2 - ((N_samp * sz : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))
  · have h1 :
        (1 - (phiRat : ℝ) - ((N_samp * sz : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) ≤
        (1 - (phiRat : ℝ) / 2 - ((N_samp * sz : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) *
          (1 - (phiRat : ℝ) / 2) := by
      have hphi_nn : 0 ≤ (phiRat : ℝ) / 2 := by positivity
      have hbias_nn : 0 ≤ ((N_samp * sz : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ))) := by positivity
      nlinarith only [hphi_nn, hφ1, hbias_nn]
    calc (1 - (phiRat : ℝ) - ((N_samp * sz : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) *
          ((Fintype.card (Fin N_samp → Fin (2 ^ q_idx)) : ℝ) * ((2 : ℝ) ^ B_walk))
        ≤ ((1 - (phiRat : ℝ) / 2 - ((N_samp * sz : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) *
            (Fintype.card (Fin N_samp → Fin (2 ^ q_idx)) : ℝ)) *
          ((1 - (phiRat : ℝ) / 2) * ((2 : ℝ) ^ B_walk)) := by
          have hcard_nn : 0 ≤ (Fintype.card (Fin N_samp → Fin (2 ^ q_idx)) : ℝ) * ((2 : ℝ) ^ B_walk) := by positivity
          have := mul_le_mul_of_nonneg_right h1 hcard_nn
          linarith only [this]
      _ ≤ (GoodU.card : ℝ) * ((1 - (phiRat : ℝ) / 2) * ((2 : ℝ) ^ B_walk)) :=
          mul_le_mul_of_nonneg_right hmod (mul_nonneg (by linarith only [hφ1]) (by positivity))
      _ ≤ (GoodCW.card : ℝ) := hprod_lb
  · have hneg : 1 - (phiRat : ℝ) - ((N_samp * sz : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ))) ≤ 0 := by
      linarith only [hpos_fac, hφ0]
    exact (mul_nonpos_of_nonpos_of_nonneg hneg (by positivity)).trans (Nat.cast_nonneg _)


/-! ### 4. Monte Carlo Baseline Pair Selector & Good-Coin Cardinality -/

/-- Universal single-step baseline failure bound extracted from `S_clm_5_1_mc_baseline`. -/
def HasMCBaselineBound (α ψ : ℝ) (k : ℕ) : Prop :=
  ∀ (d : ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (P₀ S : Finset ℕ) (age : ℕ) (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (y : ℕ) (farthest : (Fin k → ℕ) → ℕ),
    1 ≤ P₀.card →
    IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s) →
    HasNodeAge P₀ S age →
    (age : ℝ) ≤ α * (P₀.card : ℝ) / 16 →
    IsNodeMaxRadiusPoint pts o S y →
    let V := liftVariance o s
    let samples := Fintype.piFinset (fun _ : Fin k => S)
    (∀ samp ∈ samples,
      (∃ j : Fin k, farthest samp = samp j) ∧
      ∀ j : Fin k, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖) →
    open Classical in
    (((samples.filter (fun samp =>
        ¬ IsNodeBaselinePair pts o V S y (farthest samp))).card : ℝ) /
      (samples.card : ℝ)) ≤ ψ

theorem exists_mcBaselineConstant (h_mc : S_clm_5_1_mc_baseline) :
    ∃ C : ℝ, 0 < C ∧
      ∀ (α ψ : ℝ), 0 < α → α ≤ 1 → 0 < ψ → ψ < 1 →
        ∃ k : ℕ, 1 ≤ k ∧ k ≤ Nat.ceil (C * α⁻¹ * Real.log (1 / ψ)) ∧
          HasMCBaselineBound α ψ k := by
  rcases h_mc with ⟨C, hC, hall⟩
  refine ⟨C, hC, fun α ψ hα0 hα1 hψ0 hψ1 => ?_⟩
  rcases hall α ψ hα0 hα1 hψ0 hψ1 with ⟨k, hk1, hkub, hk_spec⟩
  refine ⟨k, hk1, hkub, fun d pts P₀ S age o s y farthest hm hcp hage hage_ub hy hfar => ?_⟩
  exact (hk_spec d ℕ pts Unit (fun _ => P₀) (fun _ => S) (fun _ => age)
    (fun _ => o) (fun _ => s)).2 (fun _ => y) (fun _ => farthest) () hm hcp hage hage_ub hy hfar

/-- Left-biased scan picking the sample index maximizing squared distance `‖pts (samp j) - pts y‖^2`. -/
noncomputable def farthestIdxList {d k_base : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (y : ℕ) (samp : Fin k_base → ℕ) :
    Fin k_base → List (Fin k_base) → Fin k_base
  | best, [] => best
  | best, j :: js =>
      open Classical in
      let next := if ‖pts (samp best) - pts y‖ ^ 2 < ‖pts (samp j) - pts y‖ ^ 2 then j else best
      farthestIdxList pts y samp next js

theorem farthestIdxList_spec {d k_base : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (y : ℕ) (samp : Fin k_base → ℕ) :
    ∀ (best : Fin k_base) (ls : List (Fin k_base)),
      ‖pts (samp best) - pts y‖ ^ 2 ≤
        ‖pts (samp (farthestIdxList pts y samp best ls)) - pts y‖ ^ 2 ∧
      ∀ j ∈ ls,
        ‖pts (samp j) - pts y‖ ^ 2 ≤
          ‖pts (samp (farthestIdxList pts y samp best ls)) - pts y‖ ^ 2
  | best, [] => ⟨le_rfl, fun _ h => absurd h List.not_mem_nil⟩
  | best, j :: js => by
      dsimp only [farthestIdxList]
      set next : Fin k_base :=
        open Classical in
        if ‖pts (samp best) - pts y‖ ^ 2 < ‖pts (samp j) - pts y‖ ^ 2 then j else best
      rcases farthestIdxList_spec pts y samp next js with ⟨hnext, hjs⟩
      have hbest_le : ‖pts (samp best) - pts y‖ ^ 2 ≤ ‖pts (samp next) - pts y‖ ^ 2 := by
        dsimp only [next]; split_ifs with hlt
        · exact hlt.le
        · exact le_rfl
      have hj_le : ‖pts (samp j) - pts y‖ ^ 2 ≤ ‖pts (samp next) - pts y‖ ^ 2 := by
        dsimp only [next]; split_ifs with hlt
        · exact le_rfl
        · exact not_lt.mp hlt
      refine ⟨hbest_le.trans hnext, fun x hx => ?_⟩
      rcases List.mem_cons.mp hx with rfl | hx_js
      · exact hj_le.trans hnext
      · exact hjs x hx_js

/-- Pure baseline pair evaluator matching the RAM tournament + dense-array modulo sampler. -/
noncomputable def evalBaselinePair {d k_base q_idx : ℕ} (hk : 1 ≤ k_base)
    (T_pow : ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (denseArr : List ℕ)
    (u : Fin k_base → Fin (2 ^ q_idx)) : Option (ℕ × ℕ) :=
  match maxRadiusHandle T_pow pts o denseArr.toFinset with
  | none => none
  | some y =>
      if hsz : 1 ≤ denseArr.length then
        let samp : Fin k_base → ℕ := fun j =>
          denseArr[(u j).val % denseArr.length]'(Nat.mod_lt _ hsz)
        let best := farthestIdxList pts y samp ⟨0, hk⟩ (List.finRange k_base)
        some (y, samp best)
      else
        some (y, y)

/-- Good-coin cardinality theorem for `evalBaselinePair`: holds for ALL `S` (empty or nonempty)
whenever `(o, s)` is an `α`-centerpoint of `P₀^+` and `HasNodeAge P₀ S age` with `age ≤ α|P₀|/16`. -/
theorem baseline_good_card_ge {d k_base q_idx T_pow : ℕ} (hk : 1 ≤ k_base)
    {α ψ : ℝ} (hα0 : 0 < α) (hψ0 : 0 < ψ)
    (hmc : HasMCBaselineBound α ψ k_base)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    {P₀ S : Finset ℕ} (hm : 1 ≤ P₀.card)
    {o : EuclideanSpace ℝ (Fin d)} {s : ℝ}
    (hcp : IsCenterpoint α (paraboloidLiftSet (fun i : P₀ => pts i.1)) (liftedPoint o s))
    {age : ℕ} (hage : HasNodeAge P₀ S age)
    (hage_ub : (age : ℝ) ≤ α * (P₀.card : ℝ) / 16)
    (hsub : ∀ x ∈ S, x < T_pow)
    {denseArr : List ℕ} (hnd : denseArr.Nodup) (hS : denseArr.toFinset = S) :
    let V := max 0 (liftVariance o s)
    let CoinB := Fin k_base → Fin (2 ^ q_idx)
    open Classical in
    (1 - ψ - ((k_base * denseArr.length : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ)))) *
        (Fintype.card CoinB : ℝ) ≤
      ((Finset.univ.filter (fun u : CoinB =>
        SatisfiesNodeBaselineCond pts o V S (evalBaselinePair hk T_pow pts o denseArr u))).card : ℝ) := by
  haveI : Nonempty ↥P₀ := Finset.Nonempty.coe_sort (Finset.card_pos.mp hm)
  have hV_nn : 0 ≤ liftVariance o s := liftVariance_nonneg_of_isCenterpoint _ hα0 hcp
  have hV_eq : max 0 (liftVariance o s) = liftVariance o s := max_eq_right hV_nn
  let CoinB := Fin k_base → Fin (2 ^ q_idx)
  rcases maxRadiusHandle_spec T_pow pts o (S := denseArr.toFinset) (by rw [hS]; exact hsub) with ⟨hemp_spec, hne_spec⟩
  by_cases hSne : S.Nonempty
  · have hArr_ne : denseArr.toFinset.Nonempty := by rwa [hS]
    rcases hne_spec hArr_ne with ⟨y, hmrh_eq, hy_max_arr⟩
    have hy_max : IsNodeMaxRadiusPoint pts o S y := by rwa [hS] at hy_max_arr
    have hsz : 1 ≤ denseArr.length := by
      rcases hArr_ne with ⟨z, hz⟩
      exact List.length_pos_of_mem (List.mem_toFinset.mp hz)
    let sz := denseArr.length
    have hsz_card : sz = S.card := by rw [← hS, List.toFinset_card_of_nodup hnd]
    let toSamp : (Fin k_base → Fin sz) → (Fin k_base → ℕ) :=
      fun ω j => denseArr[(ω j).val]
    have htoSamp_inj : Function.Injective toSamp := by
      intro ω₁ ω₂ heq
      funext j
      have hj : denseArr[(ω₁ j).val] = denseArr[(ω₂ j).val] := congrFun heq j
      exact Fin.ext ((List.Nodup.getElem_inj_iff hnd).mp hj)
    let samples := Fintype.piFinset (fun _ : Fin k_base => S)
    have htoSamp_mem : ∀ ω : Fin k_base → Fin sz, toSamp ω ∈ samples := by
      intro ω
      rw [Fintype.mem_piFinset]
      intro j
      rw [← hS]
      exact List.mem_toFinset.mpr (List.getElem_mem (ω j).isLt)
    have hsamples_card : samples.card = Fintype.card (Fin k_base → Fin sz) := by
      rw [Fintype.card_piFinset_const, Fintype.card_fun, Fintype.card_fin, Fintype.card_fin, hsz_card]
    have hmap_eq : (Finset.univ : Finset (Fin k_base → Fin sz)).map ⟨toSamp, htoSamp_inj⟩ = samples := by
      apply Finset.eq_of_subset_of_card_le
      · intro s_fn hs
        rcases Finset.mem_map.mp hs with ⟨ω, _, rfl⟩
        exact htoSamp_mem ω
      · rw [Finset.card_map, Finset.card_univ, hsamples_card]
    let farthest : (Fin k_base → ℕ) → ℕ :=
      fun samp => samp (farthestIdxList pts y samp ⟨0, hk⟩ (List.finRange k_base))
    have hfar_spec : ∀ samp ∈ samples,
        (∃ j : Fin k_base, farthest samp = samp j) ∧
        ∀ j : Fin k_base, ‖pts (samp j) - pts y‖ ≤ ‖pts (farthest samp) - pts y‖ := by
      intro samp _
      refine ⟨⟨_, rfl⟩, fun j => ?_⟩
      have hsq := (farthestIdxList_spec pts y samp ⟨0, hk⟩ (List.finRange k_base)).2 j (List.mem_finRange j)
      have h1 : 0 ≤ ‖pts (samp j) - pts y‖ := norm_nonneg _
      have h2 : 0 ≤ ‖pts (farthest samp) - pts y‖ := norm_nonneg _
      nlinarith only [hsq, h1, h2]
    have hbad_div := hmc d pts P₀ S age o s y farthest hm hcp hage hage_ub hy_max hfar_spec
    classical
    let BadPred : (Fin k_base → ℕ) → Prop :=
      fun samp => ¬ IsNodeBaselinePair pts o (liftVariance o s) S y (farthest samp)
    have hsc_pos : (0 : ℝ) < (samples.card : ℝ) := by
      rw [hsamples_card]
      haveI : Nonempty (Fin sz) := ⟨⟨0, hsz⟩⟩
      exact Nat.cast_pos.mpr Fintype.card_pos
    have hbad_le : ((samples.filter BadPred).card : ℝ) ≤ ψ * (Fintype.card (Fin k_base → Fin sz) : ℝ) := by
      have hmul := (div_le_iff₀ hsc_pos).mp hbad_div
      rwa [hsamples_card] at hmul
    have hbad_fin :
        (((Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => BadPred (toSamp ω))).card : ℝ) =
          ((samples.filter BadPred).card : ℝ) := by
      rw [← hmap_eq, Finset.filter_map, Finset.card_map]
      rfl
    let GoodIdx : (Fin k_base → Fin sz) → Prop :=
      fun ω => IsNodeBaselinePair pts o (liftVariance o s) S y (farthest (toSamp ω))
    have hpart_nat :
        ((Finset.univ : Finset (Fin k_base → Fin sz)).filter GoodIdx).card +
        ((Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => BadPred (toSamp ω))).card =
          Fintype.card (Fin k_base → Fin sz) := by
      have hfeq : (Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => BadPred (toSamp ω)) =
          (Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => ¬ GoodIdx ω) := by
        ext ω; rfl
      rw [hfeq, Finset.card_filter_add_card_filter_not, Finset.card_univ]
    have hpart_r :
        (((Finset.univ : Finset (Fin k_base → Fin sz)).filter GoodIdx).card : ℝ) +
        (((Finset.univ : Finset (Fin k_base → Fin sz)).filter (fun ω => BadPred (toSamp ω))).card : ℝ) =
          (Fintype.card (Fin k_base → Fin sz) : ℝ) := by exact_mod_cast hpart_nat
    have hunif_good :
        (1 - ψ) * (Fintype.card (Fin k_base → Fin sz) : ℝ) ≤
          (((Finset.univ : Finset (Fin k_base → Fin sz)).filter GoodIdx).card : ℝ) := by
      have hsub_r : (1 - ψ) * (Fintype.card (Fin k_base → Fin sz) : ℝ) =
          (Fintype.card (Fin k_base → Fin sz) : ℝ) - ψ * (Fintype.card (Fin k_base → Fin sz) : ℝ) := by ring
      linarith only [hpart_r, hbad_fin, hbad_le, hsub_r]
    have hmod := modSample_good_card_ge (q_idx := q_idx) hsz GoodIdx hψ0.le hunif_good
    refine hmod.trans (Nat.cast_le.mpr (Finset.card_le_card (fun u hu => ?_)))
    have hu_gd : IsNodeBaselinePair pts o (liftVariance o s) S y
        (farthest (toSamp (fun j => ⟨(u j).val % sz, Nat.mod_lt _ hsz⟩))) :=
      (Finset.mem_filter.mp hu).2
    rcases hu_gd with ⟨hyS, hzS, hlen_sq⟩
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ u, ?_⟩
    have heval_eq : evalBaselinePair hk T_pow pts o denseArr u =
        some (y, farthest (toSamp (fun j => ⟨(u j).val % sz, Nat.mod_lt _ hsz⟩))) := by
      unfold evalBaselinePair
      rw [hmrh_eq]
      dsimp only
      rw [dif_pos hsz]
    rw [heval_eq, hV_eq]
    exact ⟨⟨hyS, hzS⟩, fun _ => hlen_sq⟩
  · classical
    have hS_emp : S = ∅ := Finset.not_nonempty_iff_eq_empty.mp hSne
    have hArr_emp : denseArr.toFinset = ∅ := by rw [hS, hS_emp]
    have hmrh_none : maxRadiusHandle T_pow pts o denseArr.toFinset = none := hemp_spec hArr_emp
    have hall_u : (Finset.univ : Finset CoinB).filter (fun u : CoinB =>
        SatisfiesNodeBaselineCond pts o (max 0 (liftVariance o s)) S
          (evalBaselinePair hk T_pow pts o denseArr u)) = Finset.univ := by
      apply Finset.filter_true_of_mem
      intro u _
      unfold evalBaselinePair
      rw [hmrh_none, hS_emp]
      exact ⟨rfl, fun hne => absurd hne (Finset.not_nonempty_empty)⟩
    change _ ≤ (((Finset.univ : Finset CoinB).filter (fun u : CoinB => SatisfiesNodeBaselineCond pts o (max 0 (liftVariance o s)) S (evalBaselinePair hk T_pow pts o denseArr u))).card : ℝ)
    rw [hall_u, Finset.card_univ]
    have h1 : 1 - ψ - ((k_base * denseArr.length : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ))) ≤ 1 := by
      have hbias : 0 ≤ ((k_base * denseArr.length : ℕ) : ℝ) * ((2 : ℝ) ^ (-(q_idx : ℤ))) := by positivity
      linarith only [hψ0, hbias]
    simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg (Fintype.card CoinB))

/-! ### 5. Pure Single-Node Instance Bundle (`NodeInst`) & Op-Seed Cardinality -/

private lemma of_mem_filter_any {α : Type*} {p : α → Prop} {inst : DecidablePred p}
    {s : Finset α} {x : α} (h : x ∈ @Finset.filter α p inst s) : p x :=
  ((@Finset.mem_filter α p inst s x).mp h).2

/-- Good-seed cardinality for `StepSeedGood` across all `s : Fin L_p2` on one dyadic side index. -/
theorem stepSeedGood_card_ge {L_p2 R ℓ M₀ d b : ℕ}
    {T p_coord M_lat : ℕ} {A B_rat τ_d τ_q : ℚ} (hAB : A ^ 2 + B_rat ^ 2 = 1)
    {h ε₀ : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hε0 : 0 ≤ ε₀) (hε1 : ε₀ ≤ 1)
    {cap_u cap_q : ℕ}
    (o : EuclideanSpace ℝ (Fin d))
    (idx : DyadicSideIndex L_p2 R ℓ M₀ d b)
    (hgen_card : ∀ (gen : SearchGeneration (Fin (2 ^ L_p2)) (d + 1)),
      gen.m = 2 ^ L_p2 → gen.h = h →
      open Classical in
      (1 - ε₀) * (Fintype.card (ExplicitBitSeed R ℓ M₀ (d + 1) b) : ℝ) ≤
        ((Finset.univ.filter (fun ω : ExplicitBitSeed R ℓ M₀ (d + 1) b =>
          IsOrderIndepGoodFilter (polyFDisc T p_coord ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q
            gen (paddedLatNet M_lat A B_rat))).card : ℝ)) :
    let Ω_side := Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b
    open Classical in
    (1 - (L_p2 : ℝ) * ε₀) * (Fintype.card Ω_side : ℝ) ≤
      ((Finset.univ.filter (fun ω_step : Ω_side =>
        StepSeedGood T p_coord M_lat A B_rat τ_d τ_q hAB h hh0 hh1 cap_u cap_q o idx ω_step)).card : ℝ) := by
  classical
  let P_s : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b → Prop := fun s ω =>
    let H := 2 ^ s.val
    let B := 2 * H
    let q := idx.t_ins / B
    let off := idx.t_ins % B
    1 ≤ q → off = 0 →
      ∀ (hne_arr : ∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ o),
      IsOrderIndepGoodFilter (polyFDisc T p_coord ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q
        (mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx.entryPt o A B_rat hAB h hh0 hh1
          (fun j : Fin B => (q - 1) * B + j.val) hne_arr)
        (paddedLatNet M_lat A B_rat)
  have hcard_each : ∀ s : Fin L_p2,
      (1 - ε₀) * (Fintype.card (ExplicitBitSeed R ℓ M₀ (d + 1) b) : ℝ) ≤
        ((Finset.univ.filter (P_s s)).card : ℝ) := by
    intro s
    let H := 2 ^ s.val
    let B := 2 * H
    let q := idx.t_ins / B
    let off := idx.t_ins % B
    by_cases hcond : 1 ≤ q ∧ off = 0 ∧ (∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ o)
    · rcases hcond with ⟨hq1, hoff0, hne_arr⟩
      let gen := mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx.entryPt o
        A B_rat hAB h hh0 hh1 (fun j : Fin B => (q - 1) * B + j.val) hne_arr
      have hgm : gen.m = 2 ^ L_p2 := by simp [gen, mkPaddedGeneration, SearchGeneration.m]
      have hgh : gen.h = h := rfl
      refine (hgen_card gen hgm hgh).trans (Nat.cast_le.mpr (Finset.card_le_card (fun ω hω => ?_)))
      have hω_gd := (Finset.mem_filter.mp hω).2
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ ω, fun _ _ hne' => ?_⟩
      have heq_prf : hne' = hne_arr := Subsingleton.elim _ _
      rwa [heq_prf]
    · have hall : (Finset.univ : Finset (ExplicitBitSeed R ℓ M₀ (d + 1) b)).filter (P_s s) = Finset.univ := by
        apply Finset.filter_true_of_mem
        intro ω _ hq1 hoff0 hne'
        exact absurd ⟨hq1, hoff0, hne'⟩ hcond
      rw [hall, Finset.card_univ]
      have h1 : 1 - ε₀ ≤ 1 := by linarith only [hε0]
      simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)
  have hpi := pi_good_card_ge P_s hε0 hε1 hcard_each
  rw [Fintype.card_fin] at hpi
  dsimp only
  refine hpi.trans (Nat.cast_le.mpr (Finset.card_le_card (fun ω hω => ?_)))
  exact Finset.mem_filter.mpr ⟨Finset.mem_univ ω, of_mem_filter_any hω⟩

/-- Coin seed consumed by ONE materialized insertion or deletion across all `N_cfg` configurations
of a single `NodeInst` (uncurried over `Fin N_cfg × Bool × Fin L_p2` so `Fintype` resolves in 1 step). -/
abbrev NodeOpSeed (N_cfg L_p2 R ℓ M₀ d b : ℕ) : Type :=
  (Fin N_cfg × Bool × Fin L_p2) → ExplicitBitSeed R ℓ M₀ (d + 1) b

/-- Pure single-node state (center `(o, s)`, ghost `birthSet`, operational `birthSize` and `age`,
dense active-handle array `denseArr`, and `N_cfg` coupled matching/filter states). -/
structure NodeInst (L_p2 R ℓ M₀ d b N_cfg : ℕ) where
  o : EuclideanSpace ℝ (Fin d)
  s : ℝ
  birthSet : Finset ℕ
  birthSize : ℕ
  age : ℕ
  denseArr : List ℕ
  cfgs : Fin N_cfg → ConfigDynamicState L_p2 R ℓ M₀ d b

noncomputable def NodeInst.V {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg) : ℝ :=
  max 0 (liftVariance nd.o nd.s)

noncomputable def NodeInst.toChainNode {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg) : ChainNode d :=
  ⟨nd.o, nd.V, le_max_left _ _⟩

def NodeInst.curSet {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg) : Finset ℕ :=
  nd.denseArr.toFinset

noncomputable def NodeInst.openEmpty (L_p2 R ℓ M₀ d b N_cfg T p_coord : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (P₀ : Finset ℕ) (m₀ : ℕ) :
    NodeInst L_p2 R ℓ M₀ d b N_cfg :=
  { o := o
    s := s
    birthSet := P₀
    birthSize := m₀
    age := 0
    denseArr := []
    cfgs := fun _ => ConfigDynamicState.empty L_p2 R ℓ M₀ d b T p_coord }

/-- Materialized insertion of handle `p ∉ nd.curSet` into `nd` (does not alter `age`). -/
noncomputable def NodeInst.insertMat {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (p : ℕ)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg) : NodeInst L_p2 R ℓ M₀ d b N_cfg :=
  open Classical in
  { nd with
    denseArr := denseInsert p nd.denseArr
    cfgs := if 0 < nd.V then
      fun i =>
        (nd.cfgs i).insertOriginal hM₀ T p_coord M_lat params (specs i).A (specs i).B
          τ_d τ_q cap_u cap_q pts nd.o nd.V (specs i).cfg p
          (fun s => ω (i, false, s)) (fun s => ω (i, true, s))
    else
      nd.cfgs }

/-- Materialized deletion of handle `p ∈ nd.curSet` from `nd` (does not alter `age`). -/
noncomputable def NodeInst.deleteMat {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (p : ℕ)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg) : NodeInst L_p2 R ℓ M₀ d b N_cfg :=
  open Classical in
  { nd with
    denseArr := denseDelete p nd.denseArr
    cfgs := if 0 < nd.V then
      fun i =>
        (nd.cfgs i).deleteOriginal hM₀ T p_coord M_lat params (specs i).A (specs i).B
          τ_d τ_q cap_u cap_q pts nd.o nd.V (specs i).cfg p
          (fun s => ω (i, false, s)) (fun s => ω (i, true, s))
    else
      nd.cfgs }

/-- Deterministic structural invariant of `NodeInst` on materialized set `nd.curSet` (holds on ALL
coin sequences!). -/
def NodeInstMatWF {L_p2 R ℓ M₀ d b N_cfg : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg) : Prop :=
  nd.denseArr.Nodup ∧
  nd.birthSize = nd.birthSet.card ∧
  (0 < nd.V → ∀ i : Fin N_cfg,
    ConfigDynamicWF hM₀ T p_coord params (specs i).A (specs i).B τ_d cap_u
      pts nd.o nd.V nd.curSet (specs i).cfg (nd.cfgs i))

/-- Non-dependent good-seed invariant on `nd.cfgs` (holds on good coin sequences). -/
def NodeInstMatGood {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg) : Prop :=
  0 < nd.V → ∀ i : Fin N_cfg,
    ConfigDynamicGood T p_coord M_lat params (specs i).A (specs i).B τ_d τ_q (specs i).hAB
      h hh0 hh1 cap_u cap_q pts nd.o nd.V nd.curSet (specs i).cfg (nd.cfgs i)

/-- Pre-op good-seed predicate on `ω : NodeOpSeed` before `insertMat` or `deleteMat` on `nd`. -/
def NodeOpSeedGood {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b) : Prop :=
  0 < nd.V → ∀ i : Fin N_cfg,
    StepSeedGood T p_coord M_lat (specs i).A (specs i).B τ_d τ_q (specs i).hAB
      h hh0 hh1 cap_u cap_q nd.o (nd.cfgs i).leftIdx (fun s => ω (i, false, s)) ∧
    StepSeedGood T p_coord M_lat (specs i).A (specs i).B τ_d τ_q (specs i).hAB
      h hh0 hh1 cap_u cap_q nd.o (nd.cfgs i).rightIdx (fun s => ω (i, true, s))

def NodeInst.maxTIns {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg) (bound : ℕ) : Prop :=
  0 < nd.V → ∀ i : Fin N_cfg,
    (nd.cfgs i).leftIdx.t_ins ≤ bound ∧ (nd.cfgs i).rightIdx.t_ins ≤ bound

theorem nodeInst_openEmpty_spec {L_p2 R ℓ M₀ d b N_cfg : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (P₀ : Finset ℕ) :
    let nd := NodeInst.openEmpty L_p2 R ℓ M₀ d b N_cfg T p_coord o s P₀ P₀.card
    nd.curSet = ∅ ∧
    nd.maxTIns 0 ∧
    NodeInstMatWF hM₀ T p_coord params specs τ_d cap_u pts nd ∧
    NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts nd := by
  refine ⟨rfl, fun _ _ => ⟨le_rfl, le_rfl⟩, ⟨List.nodup_nil, rfl, fun hV i => ?_⟩, fun hV i => ?_⟩
  · exact configDynamic_empty_wf hM₀ T p_coord params (specs i).A (specs i).B τ_d cap_u
      pts o hV (specs i).mem_one
  · exact configDynamic_empty_good hM₀ T p_coord M_lat params (specs i).A (specs i).B τ_d τ_q
      (specs i).hAB h hh0 hh1 cap_u cap_q pts o hV (specs i).mem_one

theorem nodeInst_pts_congr {L_p2 R ℓ M₀ d b N_cfg : ℕ} {hM₀ : 1 ≤ M₀}
    {T p_coord M_lat : ℕ} {params : LocalScaleParams}
    {h : ℝ} {specs : Fin N_cfg → ConfigStaticSpec d params h}
    {τ_d τ_q : ℚ} (hh0 : 0 < h) (hh1 : h < 1) {cap_u cap_q : ℕ}
    {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {nd : NodeInst L_p2 R ℓ M₀ d b N_cfg}
    (heq : ∀ x ∈ nd.curSet, pts' x = pts x)
    (hwf : NodeInstMatWF hM₀ T p_coord params specs τ_d cap_u pts nd) :
    NodeInstMatWF hM₀ T p_coord params specs τ_d cap_u pts' nd ∧
    (NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts nd →
      NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts' nd) := by
  refine ⟨⟨hwf.1, hwf.2.1, fun hV i => configDynamic_pts_congr heq (hwf.2.2 hV i)⟩,
    fun hgd hV i => configDynamic_good_pts_congr (specs i).hAB hh0 hh1 heq (hwf.2.2 hV i) (hgd hV i)⟩

theorem nodeInst_insertMat_spec {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams) (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {nd : NodeInst L_p2 R ℓ M₀ d b N_cfg}
    {p : ℕ} (hp : p ∉ nd.curSet)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    {bound : ℕ} (ht_bnd : nd.maxTIns bound) (hcap : bound + 1 < 2 ^ L_p2)
    (hwf : NodeInstMatWF hM₀ T p_coord params specs τ_d cap_u pts nd) :
    let M_lat := M_lat_of d params.e
    let nd' := nd.insertMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω
    nd'.o = nd.o ∧ nd'.s = nd.s ∧ nd'.V = nd.V ∧
    nd'.birthSet = nd.birthSet ∧ nd'.birthSize = nd.birthSize ∧ nd'.age = nd.age ∧
    nd'.curSet = insert p nd.curSet ∧
    nd'.maxTIns (bound + 1) ∧
    NodeInstMatWF hM₀ T p_coord params specs τ_d cap_u pts nd' ∧
    (NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts nd →
     NodeOpSeedGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q nd ω →
     NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts nd') := by
  let M_lat := M_lat_of d params.e
  rcases denseInsert_spec hwf.1 hp with ⟨hnd', hcur'⟩
  have hcur_eq : (nd.insertMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω).curSet =
      insert p nd.curSet := hcur'
  have hV_eq : (nd.insertMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω).V = nd.V := rfl
  refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, hcur_eq, ?_, ⟨hnd', hwf.2.1, ?_⟩, ?_⟩
  · intro hV' i
    rw [hV_eq] at hV'
    dsimp only [NodeInst.insertMat]
    rw [if_pos hV']
    rcases ht_bnd hV' i with ⟨htL, htR⟩
    have hins := configDynamic_insert_spec h_clm_7_3 hd hM₀ T p_coord params he1 (specs i)
      τ_d τ_q hh0 hh1 cap_u cap_q hV' hp (fun s => ω (i, false, s)) (fun s => ω (i, true, s))
      (by omega) (by omega) (hwf.2.2 hV' i)
    exact ⟨hins.1.trans (Nat.add_le_add_right htL 1), hins.2.1.trans (Nat.add_le_add_right htR 1)⟩
  · intro hV' i
    rw [hV_eq] at hV'
    rw [hcur_eq]
    dsimp only [NodeInst.insertMat]
    rw [if_pos hV']
    rcases ht_bnd hV' i with ⟨htL, htR⟩
    exact (configDynamic_insert_spec h_clm_7_3 hd hM₀ T p_coord params he1 (specs i)
      τ_d τ_q hh0 hh1 cap_u cap_q hV' hp (fun s => ω (i, false, s)) (fun s => ω (i, true, s))
      (by omega) (by omega) (hwf.2.2 hV' i)).2.2.1
  · intro hgd hseed hV' i
    rw [hV_eq] at hV'
    rw [hcur_eq]
    dsimp only [NodeInst.insertMat]
    rw [if_pos hV']
    rcases ht_bnd hV' i with ⟨htL, htR⟩
    rcases hseed hV' i with ⟨hsL, hsR⟩
    exact (configDynamic_insert_spec h_clm_7_3 hd hM₀ T p_coord params he1 (specs i)
      τ_d τ_q hh0 hh1 cap_u cap_q hV' hp (fun s => ω (i, false, s)) (fun s => ω (i, true, s))
      (by omega) (by omega) (hwf.2.2 hV' i)).2.2.2 (hgd hV' i) hsL hsR

theorem nodeInst_deleteMat_spec {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams) (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {nd : NodeInst L_p2 R ℓ M₀ d b N_cfg}
    {p : ℕ} (hp : p ∈ nd.curSet)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    {bound : ℕ} (ht_bnd : nd.maxTIns bound) (hcap : bound + 1 < 2 ^ L_p2)
    (hwf : NodeInstMatWF hM₀ T p_coord params specs τ_d cap_u pts nd) :
    let M_lat := M_lat_of d params.e
    let nd' := nd.deleteMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω
    nd'.o = nd.o ∧ nd'.s = nd.s ∧ nd'.V = nd.V ∧
    nd'.birthSet = nd.birthSet ∧ nd'.birthSize = nd.birthSize ∧ nd'.age = nd.age ∧
    nd'.curSet = nd.curSet.erase p ∧
    nd'.maxTIns (bound + 1) ∧
    NodeInstMatWF hM₀ T p_coord params specs τ_d cap_u pts nd' ∧
    (NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts nd →
     NodeOpSeedGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q nd ω →
     NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts nd') := by
  let M_lat := M_lat_of d params.e
  rcases denseDelete_spec (h := p) hwf.1 with ⟨hnd', hcur'⟩
  have hcur_eq : (nd.deleteMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω).curSet =
      nd.curSet.erase p := hcur'
  have hV_eq : (nd.deleteMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω).V = nd.V := rfl
  refine ⟨rfl, rfl, rfl, rfl, rfl, rfl, hcur_eq, ?_, ⟨hnd', hwf.2.1, ?_⟩, ?_⟩
  · intro hV' i
    rw [hV_eq] at hV'
    dsimp only [NodeInst.deleteMat]
    rw [if_pos hV']
    rcases ht_bnd hV' i with ⟨htL, htR⟩
    have hdel := configDynamic_delete_spec h_clm_7_3 hd hM₀ T p_coord params he1 (specs i)
      τ_d τ_q hh0 hh1 cap_u cap_q hV' hp (fun s => ω (i, false, s)) (fun s => ω (i, true, s))
      (by omega) (by omega) (hwf.2.2 hV' i)
    exact ⟨hdel.1.trans (Nat.add_le_add_right htL 1), hdel.2.1.trans (Nat.add_le_add_right htR 1)⟩
  · intro hV' i
    rw [hV_eq] at hV'
    rw [hcur_eq]
    dsimp only [NodeInst.deleteMat]
    rw [if_pos hV']
    rcases ht_bnd hV' i with ⟨htL, htR⟩
    exact (configDynamic_delete_spec h_clm_7_3 hd hM₀ T p_coord params he1 (specs i)
      τ_d τ_q hh0 hh1 cap_u cap_q hV' hp (fun s => ω (i, false, s)) (fun s => ω (i, true, s))
      (by omega) (by omega) (hwf.2.2 hV' i)).2.2.1
  · intro hgd hseed hV' i
    rw [hV_eq] at hV'
    rw [hcur_eq]
    dsimp only [NodeInst.deleteMat]
    rw [if_pos hV']
    rcases ht_bnd hV' i with ⟨htL, htR⟩
    rcases hseed hV' i with ⟨hsL, hsR⟩
    exact (configDynamic_delete_spec h_clm_7_3 hd hM₀ T p_coord params he1 (specs i)
      τ_d τ_q hh0 hh1 cap_u cap_q hV' hp (fun s => ω (i, false, s)) (fun s => ω (i, true, s))
      (by omega) (by omega) (hwf.2.2 hV' i)).2.2.2 (hgd hV' i) hsL hsR

/-- Good-seed cardinality for `NodeOpSeedGood` across all `N_cfg × Bool × Fin L_p2` indices! -/
theorem nodeOpSeedGood_card_ge {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    {T p_coord M_lat : ℕ} {params : LocalScaleParams}
    {h ε₀ : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    {τ_d τ_q : ℚ} (hh0 : 0 < h) (hh1 : h < 1) (hε0 : 0 ≤ ε₀) (hε1 : ε₀ ≤ 1)
    {cap_u cap_q : ℕ}
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg)
    (hgen_card : ∀ (i : Fin N_cfg) (gen : SearchGeneration (Fin (2 ^ L_p2)) (d + 1)),
      gen.m = 2 ^ L_p2 → gen.h = h →
      open Classical in
      (1 - ε₀) * (Fintype.card (ExplicitBitSeed R ℓ M₀ (d + 1) b) : ℝ) ≤
        ((Finset.univ.filter (fun ω : ExplicitBitSeed R ℓ M₀ (d + 1) b =>
          IsOrderIndepGoodFilter (polyFDisc T p_coord ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q
            gen (paddedLatNet M_lat (specs i).A (specs i).B))).card : ℝ)) :
    open Classical in
    (1 - (2 * N_cfg * L_p2 : ℝ) * ε₀) * (Fintype.card (NodeOpSeed N_cfg L_p2 R ℓ M₀ d b) : ℝ) ≤
      ((Finset.univ.filter (fun ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b =>
        NodeOpSeedGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q nd ω)).card : ℝ) := by
  classical
  let κ := Fin N_cfg × Bool × Fin L_p2
  let P_idx : κ → ExplicitBitSeed R ℓ M₀ (d + 1) b → Prop := fun ⟨i, side, s⟩ ω_one =>
    let idx := if side then (nd.cfgs i).rightIdx else (nd.cfgs i).leftIdx
    let H := 2 ^ s.val
    let B := 2 * H
    let q := idx.t_ins / B
    let off := idx.t_ins % B
    0 < nd.V → 1 ≤ q → off = 0 →
      ∀ (hne_arr : ∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ nd.o),
      IsOrderIndepGoodFilter (polyFDisc T p_coord ω_one) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q
        (mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx.entryPt nd.o
          (specs i).A (specs i).B (specs i).hAB h hh0 hh1
          (fun j : Fin B => (q - 1) * B + j.val) hne_arr)
        (paddedLatNet M_lat (specs i).A (specs i).B)
  have hcard_each : ∀ k : κ,
      (1 - ε₀) * (Fintype.card (ExplicitBitSeed R ℓ M₀ (d + 1) b) : ℝ) ≤
        ((Finset.univ.filter (P_idx k)).card : ℝ) := by
    rintro ⟨i, side, s⟩
    let idx := if side then (nd.cfgs i).rightIdx else (nd.cfgs i).leftIdx
    let H := 2 ^ s.val
    let B := 2 * H
    let q := idx.t_ins / B
    let off := idx.t_ins % B
    by_cases hcond : 0 < nd.V ∧ 1 ≤ q ∧ off = 0 ∧
        (∀ j : Fin B, idx.entryPt ((q - 1) * B + j.val) ≠ nd.o)
    · rcases hcond with ⟨hV, hq1, hoff0, hne_arr⟩
      let gen := mkPaddedGeneration (Nat.one_le_two_pow : 1 ≤ 2 ^ L_p2) idx.entryPt nd.o
        (specs i).A (specs i).B (specs i).hAB h hh0 hh1
        (fun j : Fin B => (q - 1) * B + j.val) hne_arr
      have hgm : gen.m = 2 ^ L_p2 := by simp [gen, mkPaddedGeneration, SearchGeneration.m]
      refine (hgen_card i gen hgm rfl).trans (Nat.cast_le.mpr (Finset.card_le_card (fun ω hω => ?_)))
      rw [Finset.mem_filter] at hω ⊢
      refine ⟨Finset.mem_univ ω, ?_⟩
      dsimp only [P_idx]
      intro _ _ _ hne'
      have heq_prf : hne' = hne_arr := Subsingleton.elim _ _
      rw [heq_prf]
      exact hω.2
    · have hall : (Finset.univ : Finset (ExplicitBitSeed R ℓ M₀ (d + 1) b)).filter (P_idx ⟨i, side, s⟩) =
          Finset.univ := by
        apply Finset.filter_true_of_mem
        intro ω _
        dsimp only [P_idx]
        intro hV hq1 hoff0 hne'
        exact absurd ⟨hV, hq1, hoff0, hne'⟩ hcond
      rw [hall, Finset.card_univ]
      have h1 : 1 - ε₀ ≤ 1 := by linarith only [hε0]
      simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)
  have hpi := pi_good_card_ge P_idx hε0 hε1 hcard_each
  have hcard_κ : (Fintype.card κ : ℝ) = 2 * (N_cfg : ℝ) * (L_p2 : ℝ) := by
    dsimp [κ]
    rw [Fintype.card_prod, Fintype.card_prod, Fintype.card_fin, Fintype.card_bool, Fintype.card_fin]
    push_cast; ring
  rw [hcard_κ] at hpi
  refine hpi.trans (Nat.cast_le.mpr (Finset.card_le_card (fun ω hω => ?_)))
  have hall := of_mem_filter_any hω
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ ω, fun hV i => ⟨fun s hq1 hoff0 hne => ?_, fun s hq1 hoff0 hne => ?_⟩⟩
  · exact hall (i, false, s) hV hq1 hoff0 hne
  · exact hall (i, true, s) hV hq1 hoff0 hne

end UL.Proof.clm_9_1_explicit_tradeoff.H4c1
