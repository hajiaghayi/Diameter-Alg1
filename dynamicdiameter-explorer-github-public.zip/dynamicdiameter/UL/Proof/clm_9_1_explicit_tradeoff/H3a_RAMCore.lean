import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H3a

open UL

/-! ### 1. Clean memory, heap read/write helpers, and rectangular footprints -/

def CleanWords (ws : WordStore) : Prop :=
  ws.popDepth 0 = ws

def CleanReals (rs : RealStore) : Prop :=
  rs.popDepth 0 = rs

def CleanMem (mem : ArithRAMMemory) : Prop :=
  mem.popDepth 0 = mem

theorem cleanMem_iff (mem : ArithRAMMemory) :
    CleanMem mem ↔ CleanWords mem.words ∧ CleanReals mem.reals := by
  unfold CleanMem CleanWords CleanReals ArithRAMMemory.popDepth
  cases mem
  simp

theorem cleanMem_empty : CleanMem ArithRAMMemory.empty := by
  simp [CleanMem, ArithRAMMemory.popDepth, ArithRAMMemory.empty,
    WordStore.popDepth, WordStore.empty, RealStore.popDepth, RealStore.empty]

def wRead (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ℤ :=
  mem.words.read (.heap t i)

def wWrite (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℤ) : ArithRAMMemory :=
  { mem with words := mem.words.write (.heap t i) v }

def wFree (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ArithRAMMemory :=
  { mem with words := mem.words.free (.heap t i) }

noncomputable def rRead (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ℝ :=
  mem.reals.read (.heap t i)

noncomputable def rWrite (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℝ) : ArithRAMMemory :=
  { mem with reals := mem.reals.write (.heap t i) v }

noncomputable def rFree (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) : ArithRAMMemory :=
  { mem with reals := mem.reals.free (.heap t i) }

@[simp]
theorem wRead_wWrite_self (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℤ) :
    wRead (wWrite mem t i v) t i = v := by
  simp [wRead, wWrite, WordStore.read, WordStore.write]

theorem wRead_wWrite_of_ne (mem : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℤ)
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    wRead (wWrite mem t₂ i₂ v) t₁ i₁ = wRead mem t₁ i₁ := by
  have hloc : (RAMCellLoc.heap t₁ i₁) ≠ (RAMCellLoc.heap t₂ i₂) := by
    intro h; cases h; rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [wRead, wWrite, WordStore.read, WordStore.write, hloc]

@[simp]
theorem wRead_rWrite (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) (v : ℝ) :
    wRead (rWrite mem t₂ i₂ v) t₁ i₁ = wRead mem t₁ i₁ := rfl

@[simp]
theorem rRead_wWrite (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) (v : ℤ) :
    rRead (wWrite mem t₂ i₂ v) t₁ i₁ = rRead mem t₁ i₁ := rfl

@[simp]
theorem rRead_rWrite_self (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) (v : ℝ) :
    rRead (rWrite mem t i v) t i = v := by
  simp [rRead, rWrite, RealStore.read, RealStore.write]

theorem rRead_rWrite_of_ne (mem : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℝ)
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    rRead (rWrite mem t₂ i₂ v) t₁ i₁ = rRead mem t₁ i₁ := by
  have hloc : (RAMCellLoc.heap t₁ i₁) ≠ (RAMCellLoc.heap t₂ i₂) := by
    intro h; cases h; rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [rRead, rWrite, RealStore.read, RealStore.write, hloc]

theorem cleanMem_wWrite {mem : ArithRAMMemory} (h : CleanMem mem) (t : ℕ) (i : ℤ) (v : ℤ) :
    CleanMem (wWrite mem t i v) := by
  rw [cleanMem_iff] at h ⊢
  refine ⟨?_, h.2⟩
  rcases mem with ⟨⟨live, vals⟩, rs⟩
  have hlive : Finset.filter (fun l => l.keepAtDepth 0 = true) live = live :=
    congrArg WordStore.live h.1
  have hvals : (fun l => if l.keepAtDepth 0 then vals l else 0) = vals :=
    congrArg WordStore.vals h.1
  unfold CleanWords wWrite WordStore.write WordStore.popDepth
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hm, _⟩
      · exact Or.inl rfl
      · exact Or.inr hm
    · rintro (rfl | hm)
      · exact ⟨Or.inl rfl, rfl⟩
      · have hm' : loc ∈ Finset.filter (fun l => l.keepAtDepth 0 = true) live := by
          rw [hlive]; exact hm
        exact ⟨Or.inr hm, (Finset.mem_filter.mp hm').2⟩
  · funext loc
    by_cases heq : loc = .heap t i
    · subst heq; simp [RAMCellLoc.keepAtDepth]
    · have hv := congrFun hvals loc
      simp [Function.update, heq] at hv ⊢
      exact hv

theorem cleanMem_rWrite {mem : ArithRAMMemory} (h : CleanMem mem) (t : ℕ) (i : ℤ) (v : ℝ) :
    CleanMem (rWrite mem t i v) := by
  rw [cleanMem_iff] at h ⊢
  refine ⟨h.1, ?_⟩
  rcases mem with ⟨ws, ⟨live, vals⟩⟩
  have hlive : Finset.filter (fun l => l.keepAtDepth 0 = true) live = live :=
    congrArg RealStore.live h.2
  have hvals : (fun l => if l.keepAtDepth 0 then vals l else 0) = vals :=
    congrArg RealStore.vals h.2
  unfold CleanReals rWrite RealStore.write RealStore.popDepth
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_insert]
    constructor
    · rintro ⟨rfl | hm, _⟩
      · exact Or.inl rfl
      · exact Or.inr hm
    · rintro (rfl | hm)
      · exact ⟨Or.inl rfl, rfl⟩
      · have hm' : loc ∈ Finset.filter (fun l => l.keepAtDepth 0 = true) live := by
          rw [hlive]; exact hm
        exact ⟨Or.inr hm, (Finset.mem_filter.mp hm').2⟩
  · funext loc
    by_cases heq : loc = .heap t i
    · subst heq; simp [RAMCellLoc.keepAtDepth]
    · have hv := congrFun hvals loc
      simp [Function.update, heq] at hv ⊢
      exact hv

def rectHeapFinset (T B : ℕ) : Finset RAMCellLoc :=
  (Finset.range T).biUnion (fun t =>
    (Finset.range B).image (fun i : ℕ => RAMCellLoc.heap t (i : ℤ)))

theorem mem_rectHeapFinset {T B t : ℕ} {i : ℤ}
    (ht : t < T) (hi0 : 0 ≤ i) (hiB : i < (B : ℤ)) :
    RAMCellLoc.heap t i ∈ rectHeapFinset T B := by
  unfold rectHeapFinset
  rw [Finset.mem_biUnion]
  refine ⟨t, Finset.mem_range.mpr ht, ?_⟩
  rw [Finset.mem_image]
  exact ⟨i.toNat, Finset.mem_range.mpr (by omega), by simp [Int.toNat_of_nonneg hi0]⟩

theorem card_rectHeapFinset_le (T B : ℕ) : (rectHeapFinset T B).card ≤ T * B := by
  unfold rectHeapFinset
  calc
    ((Finset.range T).biUnion _).card
        ≤ ∑ _t ∈ Finset.range T, ((Finset.range B).image (fun i : ℕ => RAMCellLoc.heap _t (i : ℤ))).card :=
          Finset.card_biUnion_le
    _ ≤ ∑ _t ∈ Finset.range T, (Finset.range B).card :=
          Finset.sum_le_sum (fun _ _ => Finset.card_image_le)
    _ = T * B := by simp

def InFootprint (T_w W_cap T_r R_cap : ℕ) (mem : ArithRAMMemory) : Prop :=
  CleanMem mem ∧
  mem.words.live ⊆ rectHeapFinset T_w W_cap ∧
  mem.reals.live ⊆ rectHeapFinset T_r R_cap

theorem InFootprint.empty (T_w W_cap T_r R_cap : ℕ) :
    InFootprint T_w W_cap T_r R_cap ArithRAMMemory.empty :=
  ⟨cleanMem_empty, Finset.empty_subset _, Finset.empty_subset _⟩

theorem InFootprint.cellCount_le {T_w W_cap T_r R_cap : ℕ} {mem : ArithRAMMemory}
    (h : InFootprint T_w W_cap T_r R_cap mem) :
    mem.cellCount ≤ T_w * W_cap + T_r * R_cap := by
  unfold ArithRAMMemory.cellCount WordStore.cellCount RealStore.cellCount
  have hw := (Finset.card_le_card h.2.1).trans (card_rectHeapFinset_le T_w W_cap)
  have hr := (Finset.card_le_card h.2.2).trans (card_rectHeapFinset_le T_r R_cap)
  omega

theorem InFootprint.wWrite {T_w W_cap T_r R_cap : ℕ} {mem : ArithRAMMemory}
    (h : InFootprint T_w W_cap T_r R_cap mem) {t : ℕ} {i v : ℤ}
    (ht : t < T_w) (hi0 : 0 ≤ i) (hiB : i < (W_cap : ℤ)) :
    InFootprint T_w W_cap T_r R_cap (H3a.wWrite mem t i v) :=
  ⟨cleanMem_wWrite h.1 t i v,
   Finset.insert_subset (mem_rectHeapFinset ht hi0 hiB) h.2.1,
   h.2.2⟩

theorem InFootprint.rWrite {T_w W_cap T_r R_cap : ℕ} {mem : ArithRAMMemory}
    (h : InFootprint T_w W_cap T_r R_cap mem) {t : ℕ} {i : ℤ} {v : ℝ}
    (ht : t < T_r) (hi0 : 0 ≤ i) (hiB : i < (R_cap : ℤ)) :
    InFootprint T_w W_cap T_r R_cap (H3a.rWrite mem t i v) :=
  ⟨cleanMem_rWrite h.1 t i v,
   h.2.1,
   Finset.insert_subset (mem_rectHeapFinset ht hi0 hiB) h.2.2⟩

/-! ### 2. `runArithRAMFuel` monotonicity, determinism, and universal prefix-freeness -/

theorem runArithRAMFuel_mono {d : ℕ} {inp : ArithRAMInput d} :
    ∀ {fuel fuel' : ℕ} {stack : List ArithRAMCont} {st : ArithRAMExecState} {out : ArithRAMExecOutcome},
      runArithRAMFuel inp fuel stack st = .halted out →
      fuel ≤ fuel' →
      runArithRAMFuel inp fuel' stack st = .halted out
  | _, _, [], st, out, h, _ => by unfold runArithRAMFuel at h ⊢; exact h
  | 0, _, _ :: _, _, _, h, _ => by simp [runArithRAMFuel] at h
  | _ + 1, 0, _ :: _, _, _, _, hle => by omega
  | fuel + 1, fuel' + 1, item :: rest, st, out, h, hle => by
      have hle' : fuel ≤ fuel' := by omega
      cases item with
      | popScope _ =>
          simp only [runArithRAMFuel] at h ⊢
          exact runArithRAMFuel_mono h hle'
      | repeatLoop rem _ =>
          cases rem <;> (simp only [runArithRAMFuel] at h ⊢; exact runArithRAMFuel_mono h hle')
      | stmt s =>
          cases s with
          | randBitHeap _ _ | randBitLocal _ _ =>
              simp only [runArithRAMFuel] at h ⊢
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons _ _ =>
                  simp only [hbits] at h ⊢
                  exact runArithRAMFuel_mono h hle'
          | _ =>
              simp only [runArithRAMFuel] at h ⊢
              exact runArithRAMFuel_mono h hle'

theorem runArithRAMFuel_det {d : ℕ} {inp : ArithRAMInput d}
    {f₁ f₂ : ℕ} {stack : List ArithRAMCont} {st : ArithRAMExecState}
    {o₁ o₂ : ArithRAMExecOutcome}
    (h₁ : runArithRAMFuel inp f₁ stack st = .halted o₁)
    (h₂ : runArithRAMFuel inp f₂ stack st = .halted o₂) :
    o₁ = o₂ := by
  have h1' := runArithRAMFuel_mono h₁ (Nat.le_max_left f₁ f₂)
  have h2' := runArithRAMFuel_mono h₂ (Nat.le_max_right f₁ f₂)
  rw [h1'] at h2'
  injection h2'

theorem runArithRAMFuel_prefixFree_aux {d : ℕ} {inp : ArithRAMInput d} :
    ∀ (fuel : ℕ) (stack : List ArithRAMCont) (st : ArithRAMExecState) (v : List Bool)
      (o₁ o₂ : ArithRAMExecOutcome),
      runArithRAMFuel inp fuel stack st = .halted o₁ →
      runArithRAMFuel inp fuel stack { st with remainingBits := st.remainingBits ++ v } = .halted o₂ →
      v = []
  | _, [], st, v, _, _, h₁, h₂ => by
      simp only [runArithRAMFuel] at h₁ h₂
      split_ifs at h₁ with he₁
      have hb₁ : st.remainingBits = [] := List.isEmpty_iff.mp he₁
      rw [hb₁, List.nil_append] at h₂
      split_ifs at h₂ with he₂
      exact List.isEmpty_iff.mp he₂
  | 0, _ :: _, _, _, _, _, h₁, _ => by simp [runArithRAMFuel] at h₁
  | fuel + 1, item :: rest, st, v, o₁, o₂, h₁, h₂ => by
      cases item with
      | popScope prev =>
          simp only [runArithRAMFuel] at h₁ h₂
          exact runArithRAMFuel_prefixFree_aux fuel rest _ v o₁ o₂ h₁ h₂
      | repeatLoop rem body =>
          cases rem <;>
            (simp only [runArithRAMFuel] at h₁ h₂;
             exact runArithRAMFuel_prefixFree_aux fuel _ _ v o₁ o₂ h₁ h₂)
      | stmt s =>
          cases s with
          | randBitHeap _ _ | randBitLocal _ _ =>
              simp only [runArithRAMFuel] at h₁ h₂
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h₁
              | cons b bs =>
                  simp only [hbits, List.cons_append] at h₁ h₂
                  exact runArithRAMFuel_prefixFree_aux fuel rest _ v o₁ o₂ h₁ h₂
          | _ =>
              simp only [runArithRAMFuel] at h₁ h₂
              exact runArithRAMFuel_prefixFree_aux fuel _ _ v o₁ o₂ h₁ h₂

theorem runArithRAMWithBits_prefixFree {d : ℕ} (prog : ArithRAMStmt) (inp : ArithRAMInput d)
    (initMem : ArithRAMMemory) {bs₁ bs₂ : List Bool} {o₁ o₂ : ArithRAMExecOutcome}
    (h₁ : runArithRAMWithBits prog inp initMem bs₁ = some o₁)
    (h₂ : runArithRAMWithBits prog inp initMem bs₂ = some o₂)
    (hpref : bs₁ <+: bs₂) :
    bs₁ = bs₂ := by
  classical
  rcases hpref with ⟨v, rfl⟩
  unfold runArithRAMWithBits at h₁ h₂
  dsimp only at h₁ h₂
  split_ifs at h₁ with hex₁
  split_ifs at h₂ with hex₂
  obtain ⟨out₁, hf₁⟩ := Nat.find_spec hex₁
  obtain ⟨out₂, hf₂⟩ := Nat.find_spec hex₂
  let F := max (Nat.find hex₁) (Nat.find hex₂)
  have hg₁ := runArithRAMFuel_mono hf₁ (Nat.le_max_left (Nat.find hex₁) (Nat.find hex₂))
  have hg₂ := runArithRAMFuel_mono hf₂ (Nat.le_max_right (Nat.find hex₁) (Nat.find hex₂))
  have hv := runArithRAMFuel_prefixFree_aux F [.stmt prog] _ v out₁ out₂ hg₁ hg₂
  simp [hv]

theorem runArithRAMWithBits_eq_some_of_fuel {d : ℕ} (prog : ArithRAMStmt) (inp : ArithRAMInput d)
    (initMem : ArithRAMMemory) (bs : List Bool) (fuel : ℕ) (out : ArithRAMExecOutcome)
    (hf : runArithRAMFuel inp fuel [.stmt prog]
      { mem := initMem.popDepth 0, frameDepth := 0, remainingBits := bs,
        unitCost := 0, peakCellSpace := inp.inputCellSpace + (initMem.popDepth 0).cellCount } =
      .halted out) :
    runArithRAMWithBits prog inp initMem bs = some out := by
  classical
  unfold runArithRAMWithBits
  dsimp only
  have hex : ∃ f o, runArithRAMFuel inp f [.stmt prog] _ = .halted o := ⟨fuel, out, hf⟩
  rw [dif_pos hex]
  obtain ⟨o', ho'⟩ := Nat.find_spec hex
  have heq : o' = out := runArithRAMFuel_det ho' hf
  subst heq
  rw [ho']

/-! ### 3. Composable `StepTo` Hoare combinators & `ArithRAMDynamicProgram` wrapper -/

def intExprOps : IntExpr → ℕ
  | .lit _ | .dim => 1
  | .intParam e | .readHeap _ e | .readLocal _ e | .extraRatNum e | .extraRatDen e | .neg e =>
      intExprOps e + 1
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ | .add e₁ e₂ | .sub e₁ e₂
  | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ =>
      intExprOps e₁ + intExprOps e₂ + 1

def realExprOps : RealExpr → ℕ
  | .ofInt e | .readRealHeap _ e | .readRealLocal _ e | .extraReal e => intExprOps e + 1
  | .activePtCoord e₁ e₂ => intExprOps e₁ + intExprOps e₂ + 1
  | .neg r => realExprOps r + 1
  | .add r₁ r₂ | .sub r₁ r₂ | .mul r₁ r₂ | .div r₁ r₂ => realExprOps r₁ + realExprOps r₂ + 1

def condExprOps : ArithCondExpr → ℕ
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => intExprOps e₁ + intExprOps e₂ + 1
  | .realEq r₁ r₂ | .realLt r₁ r₂ | .realLe r₁ r₂ => realExprOps r₁ + realExprOps r₂ + 1
  | .not c => condExprOps c + 1
  | .and c₁ c₂ | .or c₁ c₂ => condExprOps c₁ + condExprOps c₂ + 1

theorem evalIntExpr_ops {d : ℕ} (bw : BitRAMInput d) (fd : ℕ) (ws : WordStore) :
    ∀ e : IntExpr, (evalIntExpr bw fd ws e).2.1 = intExprOps e
  | .lit _ | .dim => rfl
  | .intParam e | .readHeap _ e | .readLocal _ e | .extraRatNum e | .extraRatDen e | .neg e => by
      simp [evalIntExpr, intExprOps, evalIntExpr_ops bw fd ws e]
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ | .add e₁ e₂ | .sub e₁ e₂
  | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ => by
      simp [evalIntExpr, intExprOps, evalIntExpr_ops bw fd ws e₁, evalIntExpr_ops bw fd ws e₂]

theorem evalRealExpr_ops {d : ℕ} (inp : ArithRAMInput d) (fd : ℕ) (mem : ArithRAMMemory) :
    ∀ r : RealExpr, (evalRealExpr inp fd mem r).2 = realExprOps r
  | .ofInt e | .readRealHeap _ e | .readRealLocal _ e | .extraReal e => by
      simp [evalRealExpr, realExprOps, evalIntExpr_ops]
  | .activePtCoord e₁ e₂ => by simp [evalRealExpr, realExprOps, evalIntExpr_ops]
  | .neg r => by simp [evalRealExpr, realExprOps, evalRealExpr_ops inp fd mem r]
  | .add r₁ r₂ | .sub r₁ r₂ | .mul r₁ r₂ | .div r₁ r₂ => by
      simp [evalRealExpr, realExprOps, evalRealExpr_ops inp fd mem r₁, evalRealExpr_ops inp fd mem r₂]

theorem evalArithCond_ops {d : ℕ} (inp : ArithRAMInput d) (fd : ℕ) (mem : ArithRAMMemory) :
    ∀ c : ArithCondExpr, (evalArithCond inp fd mem c).2 = condExprOps c
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => by
      simp [evalArithCond, condExprOps, evalIntExpr_ops]
  | .realEq r₁ r₂ | .realLt r₁ r₂ | .realLe r₁ r₂ => by
      simp [evalArithCond, condExprOps, evalRealExpr_ops]
  | .not c => by simp [evalArithCond, condExprOps, evalArithCond_ops inp fd mem c]
  | .and c₁ c₂ | .or c₁ c₂ => by
      simp [evalArithCond, condExprOps, evalArithCond_ops inp fd mem c₁, evalArithCond_ops inp fd mem c₂]

def StepTo {d : ℕ} (inp : ArithRAMInput d)
    (s : ArithRAMStmt) (m₀ m₁ : ArithRAMMemory) (rem₀ rem₁ : List Bool)
    (C S_aux : ℕ) : Prop :=
  CleanMem m₁ ∧ m₁.cellCount ≤ S_aux ∧
  ∀ (rest : List ArithRAMCont) (u₀ sp₀ : ℕ),
    ∃ (k u₁ sp₁ : ℕ),
      u₁ ≤ u₀ + C ∧
      sp₁ ≤ max sp₀ (inp.inputCellSpace + S_aux) ∧
      ∀ fuel : ℕ,
        runArithRAMFuel inp (fuel + k) (.stmt s :: rest)
          { mem := m₀, frameDepth := 0, remainingBits := rem₀,
            unitCost := u₀, peakCellSpace := sp₀ } =
        runArithRAMFuel inp fuel rest
          { mem := m₁, frameDepth := 0, remainingBits := rem₁,
            unitCost := u₁, peakCellSpace := sp₁ }

theorem StepTo.mono {d : ℕ} {inp : ArithRAMInput d} {s : ArithRAMStmt}
    {m₀ m₁ : ArithRAMMemory} {rem₀ rem₁ : List Bool} {C C' S S' : ℕ}
    (h : StepTo inp s m₀ m₁ rem₀ rem₁ C S) (hC : C ≤ C') (hS : S ≤ S') :
    StepTo inp s m₀ m₁ rem₀ rem₁ C' S' := by
  refine ⟨h.1, h.2.1.trans hS, fun rest u₀ sp₀ => ?_⟩
  obtain ⟨k, u₁, sp₁, hu, hsp, hf⟩ := h.2.2 rest u₀ sp₀
  exact ⟨k, u₁, sp₁, hu.trans (by omega), hsp.trans (max_le_max le_rfl (by omega)), hf⟩

theorem StepTo.skip {d : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (rem₀ : List Bool) {S_aux : ℕ} (hc : CleanMem m₀) (hS : m₀.cellCount ≤ S_aux) :
    StepTo inp .skip m₀ m₀ rem₀ rem₀ 1 S_aux := by
  refine ⟨hc, hS, fun rest u₀ sp₀ => ⟨1, u₀ + 1, sp₀, le_rfl, le_max_left _ _, fun fuel => ?_⟩⟩
  simp [runArithRAMFuel]

theorem StepTo.seq {d : ℕ} {inp : ArithRAMInput d} {s₁ s₂ : ArithRAMStmt}
    {m₀ m₁ m₂ : ArithRAMMemory} {r₀ r₁ r₂ : List Bool} {C₁ C₂ S_aux : ℕ}
    (h₁ : StepTo inp s₁ m₀ m₁ r₀ r₁ C₁ S_aux)
    (h₂ : StepTo inp s₂ m₁ m₂ r₁ r₂ C₂ S_aux) :
    StepTo inp (.seq s₁ s₂) m₀ m₂ r₀ r₂ (C₁ + C₂) S_aux := by
  refine ⟨h₂.1, h₂.2.1, fun rest u₀ sp₀ => ?_⟩
  obtain ⟨k₁, u₁, sp₁, hu₁, hsp₁, hf₁⟩ := h₁.2.2 (.stmt s₂ :: rest) u₀ sp₀
  obtain ⟨k₂, u₂, sp₂, hu₂, hsp₂, hf₂⟩ := h₂.2.2 rest u₁ sp₁
  refine ⟨k₂ + k₁ + 1, u₂, sp₂, by omega, ?_, fun fuel => ?_⟩
  · exact hsp₂.trans (max_le hsp₁ (le_max_right _ _))
  · have hstep : fuel + (k₂ + k₁ + 1) = (fuel + k₂ + k₁) + 1 := by omega
    rw [hstep]
    simp only [runArithRAMFuel]
    rw [hf₁ (fuel + k₂), hf₂ fuel]

theorem StepTo.wWrite {d : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (rem₀ : List Bool) (tbl : ℕ) (idxE valE : IntExpr) (idx val : ℤ) {C S_aux : ℕ}
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hval : (evalIntExpr inp.toWordView 0 m₀.words valE).1 = val)
    (hcost : intExprOps idxE + intExprOps valE + 1 ≤ C)
    (hc₁ : CleanMem (H3a.wWrite m₀ tbl idx val))
    (hS₁ : (H3a.wWrite m₀ tbl idx val).cellCount ≤ S_aux) :
    StepTo inp (.writeWordHeap tbl idxE valE) m₀ (H3a.wWrite m₀ tbl idx val) rem₀ rem₀ C S_aux := by
  refine ⟨hc₁, hS₁, fun rest u₀ sp₀ => ?_⟩
  refine ⟨1, u₀ + intExprOps idxE + intExprOps valE + 1,
    max sp₀ (inp.inputCellSpace + (H3a.wWrite m₀ tbl idx val).cellCount),
    by omega, max_le_max le_rfl (Nat.add_le_add_left hS₁ _), fun fuel => ?_⟩
  simp only [runArithRAMFuel]
  rcases hi : evalIntExpr inp.toWordView 0 m₀.words idxE with ⟨idx', ui, _⟩
  rcases hv : evalIntExpr inp.toWordView 0 m₀.words valE with ⟨val', uv, _⟩
  have hui : ui = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView 0 m₀.words idxE; simpa [hi] using this
  have huv : uv = intExprOps valE := by
    have := evalIntExpr_ops inp.toWordView 0 m₀.words valE; simpa [hv] using this
  have hidx' : idx' = idx := by simpa [hi] using hidx
  have hval' : val' = val := by simpa [hv] using hval
  subst hidx'; subst hval'; subst hui; subst huv
  rfl

theorem StepTo.rWrite {d : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (rem₀ : List Bool) (tbl : ℕ) (idxE : IntExpr) (valE : RealExpr) (idx : ℤ) (val : ℝ) {C S_aux : ℕ}
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hval : (evalRealExpr inp 0 m₀ valE).1 = val)
    (hcost : intExprOps idxE + realExprOps valE + 1 ≤ C)
    (hc₁ : CleanMem (H3a.rWrite m₀ tbl idx val))
    (hS₁ : (H3a.rWrite m₀ tbl idx val).cellCount ≤ S_aux) :
    StepTo inp (.writeRealHeap tbl idxE valE) m₀ (H3a.rWrite m₀ tbl idx val) rem₀ rem₀ C S_aux := by
  refine ⟨hc₁, hS₁, fun rest u₀ sp₀ => ?_⟩
  refine ⟨1, u₀ + intExprOps idxE + realExprOps valE + 1,
    max sp₀ (inp.inputCellSpace + (H3a.rWrite m₀ tbl idx val).cellCount),
    by omega, max_le_max le_rfl (Nat.add_le_add_left hS₁ _), fun fuel => ?_⟩
  simp only [runArithRAMFuel]
  rcases hi : evalIntExpr inp.toWordView 0 m₀.words idxE with ⟨idx', ui, _⟩
  rcases hv : evalRealExpr inp 0 m₀ valE with ⟨val', uv⟩
  have hui : ui = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView 0 m₀.words idxE; simpa [hi] using this
  have huv : uv = realExprOps valE := by
    have := evalRealExpr_ops inp 0 m₀ valE; simpa [hv] using this
  have hidx' : idx' = idx := by simpa [hi] using hidx
  have hval' : val' = val := by simpa [hv] using hval
  subst hidx'; subst hval'; subst hui; subst huv
  rfl

theorem StepTo.ite_true {d : ℕ} {inp : ArithRAMInput d} (cond : ArithCondExpr)
    (tB fB : ArithRAMStmt) {m₀ m₁ : ArithRAMMemory} {r₀ r₁ : List Bool} {C_c C_b S_aux : ℕ}
    (hcond : (evalArithCond inp 0 m₀ cond).1 = true)
    (huc : condExprOps cond ≤ C_c)
    (ht : StepTo inp tB m₀ m₁ r₀ r₁ C_b S_aux) :
    StepTo inp (.ite cond tB fB) m₀ m₁ r₀ r₁ (C_c + C_b) S_aux := by
  refine ⟨ht.1, ht.2.1, fun rest u₀ sp₀ => ?_⟩
  have huc_eq := evalArithCond_ops inp 0 m₀ cond
  rcases hc : evalArithCond inp 0 m₀ cond with ⟨flag, uc⟩
  have hf : flag = true := by simpa [hc] using hcond
  have huc' : uc = condExprOps cond := by simpa [hc] using huc_eq
  subst hf
  obtain ⟨k, u₁, sp₁, hu₁, hsp₁, hfuel⟩ := ht.2.2 rest (u₀ + uc) sp₀
  refine ⟨k + 1, u₁, sp₁, by omega, hsp₁, fun fuel => ?_⟩
  have hs : fuel + (k + 1) = (fuel + k) + 1 := by omega
  rw [hs]
  simp only [runArithRAMFuel, hc, ↓reduceIte]
  exact hfuel fuel

theorem StepTo.ite_false {d : ℕ} {inp : ArithRAMInput d} (cond : ArithCondExpr)
    (tB fB : ArithRAMStmt) {m₀ m₁ : ArithRAMMemory} {r₀ r₁ : List Bool} {C_c C_b S_aux : ℕ}
    (hcond : (evalArithCond inp 0 m₀ cond).1 = false)
    (huc : condExprOps cond ≤ C_c)
    (hf_step : StepTo inp fB m₀ m₁ r₀ r₁ C_b S_aux) :
    StepTo inp (.ite cond tB fB) m₀ m₁ r₀ r₁ (C_c + C_b) S_aux := by
  refine ⟨hf_step.1, hf_step.2.1, fun rest u₀ sp₀ => ?_⟩
  have huc_eq := evalArithCond_ops inp 0 m₀ cond
  rcases hc : evalArithCond inp 0 m₀ cond with ⟨flag, uc⟩
  have hf : flag = false := by simpa [hc] using hcond
  have huc' : uc = condExprOps cond := by simpa [hc] using huc_eq
  subst hf
  obtain ⟨k, u₁, sp₁, hu₁, hsp₁, hfuel⟩ := hf_step.2.2 rest (u₀ + uc) sp₀
  refine ⟨k + 1, u₁, sp₁, by omega, hsp₁, fun fuel => ?_⟩
  have hs : fuel + (k + 1) = (fuel + k) + 1 := by omega
  rw [hs]
  simp only [runArithRAMFuel, hc]
  exact hfuel fuel

theorem StepTo.repeatN {d : ℕ} {inp : ArithRAMInput d} (countE : IntExpr) (body : ArithRAMStmt)
    (N C_cnt C_b S_aux : ℕ) (mSeq : ℕ → ArithRAMMemory) (rSeq : ℕ → List Bool)
    (hc₀ : CleanMem (mSeq 0)) (hS₀ : (mSeq 0).cellCount ≤ S_aux)
    (hcnt : (evalIntExpr inp.toWordView 0 (mSeq 0).words countE).1 = (N : ℤ))
    (huc : intExprOps countE ≤ C_cnt)
    (hstep : ∀ i < N, StepTo inp body (mSeq i) (mSeq (i + 1)) (rSeq i) (rSeq (i + 1)) C_b S_aux) :
    StepTo inp (.repeatN countE body) (mSeq 0) (mSeq N) (rSeq 0) (rSeq N)
      (C_cnt + N * C_b) S_aux := by
  have hloop : ∀ (rem idx : ℕ), idx + rem = N →
      CleanMem (mSeq idx) → (mSeq idx).cellCount ≤ S_aux →
      CleanMem (mSeq N) ∧ (mSeq N).cellCount ≤ S_aux ∧
      ∀ (rest : List ArithRAMCont) (u₀ sp₀ : ℕ),
        ∃ (k u₁ sp₁ : ℕ),
          u₁ ≤ u₀ + rem * C_b ∧
          sp₁ ≤ max sp₀ (inp.inputCellSpace + S_aux) ∧
          ∀ fuel : ℕ,
            runArithRAMFuel inp (fuel + k) (.repeatLoop rem body :: rest)
              { mem := mSeq idx, frameDepth := 0, remainingBits := rSeq idx,
                unitCost := u₀, peakCellSpace := sp₀ } =
            runArithRAMFuel inp fuel rest
              { mem := mSeq N, frameDepth := 0, remainingBits := rSeq N,
                unitCost := u₁, peakCellSpace := sp₁ } := by
    intro rem
    induction rem with
    | zero =>
      intro idx hidx hc hS
      have heq : idx = N := by omega
      subst heq
      refine ⟨hc, hS, fun rest u₀ sp₀ => ⟨1, u₀, sp₀, by simp, le_max_left _ _, fun fuel => ?_⟩⟩
      simp [runArithRAMFuel]
    | succ r ih =>
      intro idx hidx _ _
      have hi_lt : idx < N := by omega
      have hs := hstep idx hi_lt
      obtain ⟨hcN, hSN, hrest⟩ := ih (idx + 1) (by omega) hs.1 hs.2.1
      refine ⟨hcN, hSN, fun rest u₀ sp₀ => ?_⟩
      obtain ⟨k₁, u₁, sp₁, hu₁, hsp₁, hf₁⟩ := hs.2.2 (.repeatLoop r body :: rest) u₀ sp₀
      obtain ⟨k₂, u₂, sp₂, hu₂, hsp₂, hf₂⟩ := hrest rest u₁ sp₁
      refine ⟨k₂ + k₁ + 1, u₂, sp₂, ?_, hsp₂.trans (max_le hsp₁ (le_max_right _ _)), fun fuel => ?_⟩
      · have : (r + 1) * C_b = C_b + r * C_b := by ring
        omega
      · have hst : fuel + (k₂ + k₁ + 1) = (fuel + k₂ + k₁) + 1 := by omega
        rw [hst]
        simp only [runArithRAMFuel]
        rw [hf₁ (fuel + k₂), hf₂ fuel]
  obtain ⟨hcN, hSN, hloop0⟩ := hloop N 0 (by omega) hc₀ hS₀
  refine ⟨hcN, hSN, fun rest u₀ sp₀ => ?_⟩
  have huc_eq := evalIntExpr_ops inp.toWordView 0 (mSeq 0).words countE
  rcases he : evalIntExpr inp.toWordView 0 (mSeq 0).words countE with ⟨cnt, uc, _⟩
  have hcnt' : cnt = (N : ℤ) := by simpa [he] using hcnt
  have huc' : uc = intExprOps countE := by simpa [he] using huc_eq
  subst hcnt'
  obtain ⟨k, u₁, sp₁, hu₁, hsp₁, hf⟩ := hloop0 rest (u₀ + uc) sp₀
  refine ⟨k + 1, u₁, sp₁, by omega, hsp₁, fun fuel => ?_⟩
  have hst : fuel + (k + 1) = (fuel + k) + 1 := by omega
  rw [hst]
  simp only [runArithRAMFuel, he, Int.natCast_nonneg, ↓reduceIte, Int.toNat_natCast]
  exact hf fuel

theorem StepTo.randBitHeap {d : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (b : Bool) (rem : List Bool) (tbl : ℕ) (idxE : IntExpr) (idx : ℤ) {C S_aux : ℕ}
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hcost : intExprOps idxE + 1 ≤ C)
    (hc₁ : CleanMem (H3a.wWrite m₀ tbl idx (if b then 1 else 0)))
    (hS₁ : (H3a.wWrite m₀ tbl idx (if b then 1 else 0)).cellCount ≤ S_aux) :
    StepTo inp (.randBitHeap tbl idxE) m₀
      (H3a.wWrite m₀ tbl idx (if b then 1 else 0)) (b :: rem) rem C S_aux := by
  refine ⟨hc₁, hS₁, fun rest u₀ sp₀ => ?_⟩
  refine ⟨1, u₀ + intExprOps idxE + 1,
    max sp₀ (inp.inputCellSpace + (H3a.wWrite m₀ tbl idx (if b then 1 else 0)).cellCount),
    by omega, max_le_max le_rfl (Nat.add_le_add_left hS₁ _), fun fuel => ?_⟩
  simp only [runArithRAMFuel]
  rcases hi : evalIntExpr inp.toWordView 0 m₀.words idxE with ⟨idx', ui, _⟩
  have hui : ui = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView 0 m₀.words idxE; simpa [hi] using this
  have hidx' : idx' = idx := by simpa [hi] using hidx
  subst hidx'; subst hui
  rfl

theorem StepTo.to_runArithRAMWithBits {d : ℕ} {inp : ArithRAMInput d} {prog : ArithRAMStmt}
    {m₀ m₁ : ArithRAMMemory} {bs : List Bool} {C S_aux : ℕ}
    (hc₀ : CleanMem m₀) (hS₀ : m₀.cellCount ≤ S_aux)
    (hstep : StepTo inp prog m₀ m₁ bs [] C S_aux) :
    ∃ out : ArithRAMExecOutcome,
      runArithRAMWithBits prog inp m₀ bs = some out ∧
      out.mem = m₁ ∧
      out.unitCost ≤ C ∧
      out.peakCellSpace ≤ inp.inputCellSpace + S_aux := by
  obtain ⟨hc₁, _, hrun⟩ := hstep
  obtain ⟨k, u₁, sp₁, hu₁, hsp₁, hf⟩ := hrun [] 0 (inp.inputCellSpace + m₀.cellCount)
  have hf0 := hf 0
  have hm₁_pop : m₁.popDepth 0 = m₁ := hc₁
  simp only [Nat.zero_add, runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, hm₁_pop] at hf0
  have hm₀_pop : m₀.popDepth 0 = m₀ := hc₀
  have hwith : runArithRAMWithBits prog inp m₀ bs =
      some { mem := m₁, unitCost := u₁, peakCellSpace := sp₁ } := by
    apply runArithRAMWithBits_eq_some_of_fuel prog inp m₀ bs k
    simpa [hm₀_pop] using hf0
  exact ⟨_, hwith, rfl, Nat.zero_add C ▸ hu₁, hsp₁.trans (max_le (Nat.add_le_add_left hS₀ _) le_rfl)⟩

/-- Deterministic statement consuming zero random bits (`remainingBits` unchanged on any execution). -/
inductive ZeroRandStmt : ArithRAMStmt → Prop
  | skip : ZeroRandStmt .skip
  | writeWordHeap (t idx val) : ZeroRandStmt (.writeWordHeap t idx val)
  | writeWordLocal (v idx val) : ZeroRandStmt (.writeWordLocal v idx val)
  | freeWordHeap (t idx) : ZeroRandStmt (.freeWordHeap t idx)
  | freeWordLocal (v idx) : ZeroRandStmt (.freeWordLocal v idx)
  | writeRealHeap (t idx val) : ZeroRandStmt (.writeRealHeap t idx val)
  | writeRealLocal (v idx val) : ZeroRandStmt (.writeRealLocal v idx val)
  | freeRealHeap (t idx) : ZeroRandStmt (.freeRealHeap t idx)
  | freeRealLocal (v idx) : ZeroRandStmt (.freeRealLocal v idx)
  | seq {s₁ s₂} : ZeroRandStmt s₁ → ZeroRandStmt s₂ → ZeroRandStmt (.seq s₁ s₂)
  | ite {c t f} : ZeroRandStmt t → ZeroRandStmt f → ZeroRandStmt (.ite c t f)
  | whileLoop {c b} : ZeroRandStmt b → ZeroRandStmt (.whileLoop c b)
  | repeatN {cnt b} : ZeroRandStmt b → ZeroRandStmt (.repeatN cnt b)
  | localScope {b} : ZeroRandStmt b → ZeroRandStmt (.localScope b)

def ZeroRandCont : ArithRAMCont → Prop
  | .stmt s => ZeroRandStmt s
  | .repeatLoop _ b => ZeroRandStmt b
  | .popScope _ => True

theorem zeroRand_preserves_bits {d : ℕ} {inp : ArithRAMInput d}
    (fuel : ℕ) :
    ∀ (stack : List ArithRAMCont) (st : ArithRAMExecState) (out : ArithRAMExecOutcome),
      (∀ c ∈ stack, ZeroRandCont c) →
      runArithRAMFuel inp fuel stack st = .halted out →
      st.remainingBits = [] := by
  induction fuel with
  | zero =>
      intro stack st out _ h
      cases stack with
      | nil =>
          simp only [runArithRAMFuel] at h
          split_ifs at h with he
          exact List.isEmpty_iff.mp he
      | cons _ _ =>
          simp [runArithRAMFuel] at h
  | succ fuel ih =>
      intro stack st out hzr h
      cases stack with
      | nil =>
          simp only [runArithRAMFuel] at h
          split_ifs at h with he
          exact List.isEmpty_iff.mp he
      | cons item rest =>
          have hitem := hzr item List.mem_cons_self
          have hrest : ∀ c ∈ rest, ZeroRandCont c := fun c hc => hzr c (List.mem_cons_of_mem _ hc)
          cases item with
          | popScope _ =>
              simp only [runArithRAMFuel] at h
              have hnil := ih rest _ out hrest h
              exact hnil
          | repeatLoop rem body =>
              cases rem with
              | zero =>
                  simp only [runArithRAMFuel] at h
                  have hnil := ih rest _ out hrest h
                  exact hnil
              | succ r =>
                  simp only [runArithRAMFuel] at h
                  have hstack' : ∀ c ∈ (ArithRAMCont.stmt body :: ArithRAMCont.repeatLoop r body :: rest), ZeroRandCont c := by
                    intro c hc
                    rcases List.mem_cons.mp hc with rfl | hc'
                    · exact hitem
                    · rcases List.mem_cons.mp hc' with rfl | hc''
                      · exact hitem
                      · exact hrest c hc''
                  have hnil := ih _ _ out hstack' h
                  exact hnil
          | stmt s =>
              cases hitem with
              | skip | writeWordHeap _ _ _ | writeWordLocal _ _ _ | freeWordHeap _ _ | freeWordLocal _ _
              | writeRealHeap _ _ _ | writeRealLocal _ _ _ | freeRealHeap _ _ | freeRealLocal _ _ =>
                  simp only [runArithRAMFuel] at h
                  have hnil := ih rest _ out hrest h
                  exact hnil
              | @seq s₁ s₂ hs₁ hs₂ =>
                  simp only [runArithRAMFuel] at h
                  have hstack' : ∀ c ∈ (ArithRAMCont.stmt s₁ :: ArithRAMCont.stmt s₂ :: rest), ZeroRandCont c := by
                    intro c hc
                    rcases List.mem_cons.mp hc with rfl | hc'
                    · exact hs₁
                    · rcases List.mem_cons.mp hc' with rfl | hc''
                      · exact hs₂
                      · exact hrest c hc''
                  have hnil := ih _ _ out hstack' h
                  exact hnil
              | @ite cond tB fB ht hf =>
                  simp only [runArithRAMFuel] at h
                  split_ifs at h
                  · have hstack' : ∀ c ∈ (ArithRAMCont.stmt tB :: rest), ZeroRandCont c := by
                      intro c hc
                      rcases List.mem_cons.mp hc with rfl | hc'
                      · exact ht
                      · exact hrest c hc'
                    have hnil := ih _ _ out hstack' h
                    exact hnil
                  · have hstack' : ∀ c ∈ (ArithRAMCont.stmt fB :: rest), ZeroRandCont c := by
                      intro c hc
                      rcases List.mem_cons.mp hc with rfl | hc'
                      · exact hf
                      · exact hrest c hc'
                    have hnil := ih _ _ out hstack' h
                    exact hnil
              | @whileLoop cond body hb =>
                  simp only [runArithRAMFuel] at h
                  split_ifs at h
                  · have hstack' : ∀ c ∈ (ArithRAMCont.stmt body :: ArithRAMCont.stmt (.whileLoop cond body) :: rest), ZeroRandCont c := by
                      intro c hc
                      rcases List.mem_cons.mp hc with rfl | hc'
                      · exact hb
                      · rcases List.mem_cons.mp hc' with rfl | hc''
                        · exact ZeroRandStmt.whileLoop hb
                        · exact hrest c hc''
                    have hnil := ih _ _ out hstack' h
                    exact hnil
                  · have hnil := ih rest _ out hrest h
                    exact hnil
              | @repeatN cntE body hb =>
                  simp only [runArithRAMFuel] at h
                  let nIter := if 0 ≤ (evalIntExpr inp.toWordView st.frameDepth st.mem.words cntE).1 then
                    (evalIntExpr inp.toWordView st.frameDepth st.mem.words cntE).1.toNat else 0
                  have hstack' : ∀ c ∈ (ArithRAMCont.repeatLoop nIter body :: rest), ZeroRandCont c := by
                    intro c hc
                    rcases List.mem_cons.mp hc with rfl | hc'
                    · exact hb
                    · exact hrest c hc'
                  have hnil := ih _ _ out hstack' h
                  exact hnil
              | @localScope body hb =>
                  simp only [runArithRAMFuel] at h
                  have hstack' : ∀ c ∈ (ArithRAMCont.stmt body :: ArithRAMCont.popScope st.frameDepth :: rest), ZeroRandCont c := by
                    intro c hc
                    rcases List.mem_cons.mp hc with rfl | hc'
                    · exact hb
                    · rcases List.mem_cons.mp hc' with rfl | hc''
                      · trivial
                      · exact hrest c hc''
                  have hnil := ih _ _ out hstack' h
                  exact hnil

theorem zeroRand_none_of_nonempty {d : ℕ} {prog : ArithRAMStmt} (hzr : ZeroRandStmt prog)
    (inp : ArithRAMInput d) (initMem : ArithRAMMemory) {bs : List Bool} (hbs : bs ≠ []) :
    runArithRAMWithBits prog inp initMem bs = none := by
  classical
  unfold runArithRAMWithBits
  dsimp only
  split_ifs with hex
  · obtain ⟨out, hf⟩ := Nat.find_spec hex
    have hnil := zeroRand_preserves_bits (Nat.find hex) [.stmt prog] _ out
      (fun c hc => by rcases List.mem_singleton.mp hc with rfl; exact hzr) hf
    exact absurd hnil hbs
  · rfl

/-- Draw `B_coins` random bits sequentially into `.heap coinTbl (0 .. B_coins - 1)` using scratch
counter `.heap scratchTbl 0`. -/
def drawCoinsStmt (coinTbl scratchTbl B_coins : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap scratchTbl (.lit 0) (.lit 0))
    (.repeatN (.lit (B_coins : ℤ))
      (.seq (.randBitHeap coinTbl (.readHeap scratchTbl (.lit 0)))
        (.writeWordHeap scratchTbl (.lit 0)
          (.add (.readHeap scratchTbl (.lit 0)) (.lit 1)))))

/-! ### 4. Standard `ArithRAMDynamicProgram` wrapper & `SatisfiesDynamicStorageAndQueryModel` -/

noncomputable def mkArithAlg {d : ℕ} (n : ℕ) (prog : ArithRAMDynamicProgram)
    (initOut : ArithRAMExecOutcome) : DynamicDiameterStructure d ArithRAMMemory :=
  { initState := initOut.mem
    initWork := initOut.unitCost
    initSpace := initOut.peakCellSpace
    cachedAnswer := fun mem =>
      let ans := ArithRAMDynamicProgram.readCachedAnswer mem
      { diameterHandles := ans.1, cachedDistSq := ans.2 }
    retrieveIdsAndRefCost := 4
    writeOutputCost := fun outLen => outLen + 1
    stepWithBits := fun activeH hCoords mem uop bs =>
      match uop with
      | .insert pt =>
          (prog.evalUpdate n activeH hCoords mem true pt 0 bs).map (fun stepOut =>
            let ans := ArithRAMDynamicProgram.readCachedAnswer stepOut.mem
            { nextState := stepOut.mem
              returnedHandle := ArithRAMDynamicProgram.readReturnedHandle stepOut.mem
              storedAnswer := { diameterHandles := ans.1, cachedDistSq := ans.2 }
              work := stepOut.unitCost
              peakSpace := stepOut.peakCellSpace })
      | .delete h =>
          (prog.evalUpdate n activeH hCoords mem false 0 h bs).map (fun stepOut =>
            let ans := ArithRAMDynamicProgram.readCachedAnswer stepOut.mem
            { nextState := stepOut.mem
              returnedHandle := none
              storedAnswer := { diameterHandles := ans.1, cachedDistSq := ans.2 }
              work := stepOut.unitCost
              peakSpace := stepOut.peakCellSpace }) }

theorem evalInit_skip (n d : ℕ) (updStmt : ArithRAMStmt) :
    let prog : ArithRAMDynamicProgram := { initStmt := .skip, updateStmt := updStmt }
    prog.evalInit n d = some { mem := ArithRAMMemory.empty, unitCost := 1, peakCellSpace := 1 } := by
  intro prog

  have hm_pop : ArithRAMMemory.empty.popDepth 0 = ArithRAMMemory.empty := cleanMem_empty
  apply runArithRAMWithBits_eq_some_of_fuel .skip _ ArithRAMMemory.empty [] 1
  simp only [runArithRAMFuel, hm_pop, List.isEmpty_nil, ↓reduceIte]
  congr 1
  simp [ArithRAMInput.inputCellSpace, ArithRAMMemory.empty, ArithRAMMemory.cellCount,
    WordStore.empty, WordStore.cellCount, RealStore.empty, RealStore.cellCount]

theorem storageModel_of_empty_init {d : ℕ} (n : ℕ) (prog : ArithRAMDynamicProgram)
    (initOut : ArithRAMExecOutcome) (hmem : initOut.mem = ArithRAMMemory.empty) :
    SatisfiesDynamicStorageAndQueryModel 4 1 (mkArithAlg (d := d) n prog initOut) := by
  refine ⟨?_, ?_, ?_, le_rfl, fun L => by dsimp only [mkArithAlg]; omega⟩
  · dsimp only [mkArithAlg]
    rw [hmem]
    simp [ArithRAMDynamicProgram.readCachedAnswer, ArithRAMMemory.empty,
      WordStore.empty, WordStore.read, RealStore.empty, RealStore.read]
  · intro activeH hCoords st uop bs out hstep
    cases uop <;>
      (simp only [mkArithAlg, Option.map_eq_some_iff] at hstep;
       rcases hstep with ⟨stepOut, _, rfl⟩;
       rfl)
  · intro activeH hCoords st uop bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
    cases uop with
    | insert pt =>
        simp only [mkArithAlg, Option.map_eq_some_iff] at h₁ h₂
        rcases h₁ with ⟨so₁, he₁, _⟩
        rcases h₂ with ⟨so₂, he₂, _⟩
        exact runArithRAMWithBits_prefixFree prog.updateStmt _ st he₁ he₂ hpref
    | delete h =>
        simp only [mkArithAlg, Option.map_eq_some_iff] at h₁ h₂
        rcases h₁ with ⟨so₁, he₁, _⟩
        rcases h₂ with ⟨so₂, he₂, _⟩
        exact runArithRAMWithBits_prefixFree prog.updateStmt _ st he₁ he₂ hpref

/-! ### 5. Universal Fixed-Coin Adaptive Monte Carlo & Worst-Case Work/Space Bridge -/

theorem sum_bitListProb_ofFn (B : ℕ) :
    (∑ bits : Fin B → Bool, bitListProb (List.ofFn bits)) = 1 := by
  have hlen : ∀ bits : Fin B → Bool, bitListProb (List.ofFn bits) = ((2 : ENNReal)⁻¹) ^ B := by
    intro bits
    simp [bitListProb]
  simp_rw [hlen]
  rw [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_fin, Fintype.card_bool,
    nsmul_eq_mul, Nat.cast_pow, Nat.cast_ofNat]
  rw [← mul_pow, ENNReal.mul_inv_cancel (by norm_num) (by simp), one_pow]

theorem tsum_eq_sum_ofFn_of_len {B : ℕ} (f : List Bool → ENNReal)
    (hother : ∀ bs : List Bool, bs.length ≠ B → f bs = 0) :
    (∑' bs : List Bool, f bs) = ∑ bits : Fin B → Bool, f (List.ofFn bits) := by
  have hinj : Function.Injective (fun bits : Fin B → Bool => List.ofFn bits) := by
    intro b₁ b₂ h
    ext i
    have hi := congrArg (fun l => l[i.val]?) h
    simpa using hi
  let s : Finset (List Bool) := Finset.univ.map ⟨fun bits : Fin B → Bool => List.ofFn bits, hinj⟩
  rw [tsum_eq_sum (s := s)]
  · exact Finset.sum_map Finset.univ ⟨fun bits : Fin B → Bool => List.ofFn bits, hinj⟩ f
  · intro bs hbs
    by_cases hlen : bs.length = B
    · exfalso
      apply hbs
      simp only [s, Finset.mem_map, Finset.mem_univ, Function.Embedding.coeFn_mk, true_and]
      exact ⟨fun i => bs[i.val]'(by omega), List.ext_getElem (by simp [hlen]) (by simp)⟩
    · exact hother bs hlen

theorem applyDynamicUpdate_wellFormed {d : ℕ} {n : ℕ} {P P' : DynamicPointSet d}
    {op : DynamicUpdate d} {rh : Option ℕ}
    (hwf : P.WellFormed n) (hleg : IsLegalUpdate n Set.univ P op)
    (happ : applyDynamicUpdate P op rh = some P') :
    P'.WellFormed n := by
  rcases hwf with ⟨hcard, hid_h, hh_id, hlt_life, hinj_life⟩
  cases op with
  | insert pid extName pt =>
    cases rh with
    | none => simp [applyDynamicUpdate] at happ
    | some hdl =>
      unfold applyDynamicUpdate at happ
      dsimp only at happ
      split_ifs at happ with hcond
      simp only [Option.some.injEq] at happ
      subst happ
      rcases hleg with ⟨hid_not, hcard_ins, _⟩
      refine ⟨by rw [Finset.card_insert_of_notMem hcond.1]; omega, ?_, ?_, ?_, ?_⟩
      · intro id' hid'
        rcases Finset.mem_insert.mp hid' with rfl | hold
        · simp [Function.update]
        · have hne_id : id' ≠ pid := fun heq => hcond.1 (heq ▸ hold)
          have ⟨hm, heq⟩ := hid_h id' hold
          have hne_h : P.handleOfId id' ≠ hdl := fun hh => hcond.2 (hh ▸ hm)
          simp [Function.update, hne_id, hne_h, hm, heq]
      · intro h' hh'
        rcases Finset.mem_insert.mp hh' with rfl | hold
        · simp [Function.update]
        · have hne_h : h' ≠ hdl := fun heq => hcond.2 (heq ▸ hold)
          have ⟨hm, heq⟩ := hh_id h' hold
          have hne_id : P.idOfHandle h' ≠ pid := fun hi => hcond.1 (hi ▸ hm)
          simp [Function.update, hne_h, hne_id, hm, heq]
      · intro id' hid'
        dsimp only
        rcases Finset.mem_insert.mp hid' with rfl | hold
        · simp [Function.update]
        · have hne_id : id' ≠ pid := fun heq => hcond.1 (heq ▸ hold)
          have hlt := hlt_life id' hold
          rw [Function.update_of_ne hne_id]
          omega
      · intro i₁ hi₁ i₂ hi₂ heq_l
        dsimp only at heq_l
        rcases Finset.mem_insert.mp hi₁ with heq₁ | hold₁ <;>
        rcases Finset.mem_insert.mp hi₂ with heq₂ | hold₂
        · exact heq₁.trans heq₂.symm
        · subst heq₁
          have hne₂ : i₂ ≠ i₁ := fun heq => hcond.1 (heq ▸ hold₂)
          rw [Function.update_self, Function.update_of_ne hne₂] at heq_l
          have := hlt_life i₂ hold₂
          omega
        · subst heq₂
          have hne₁ : i₁ ≠ i₂ := fun heq => hcond.1 (heq ▸ hold₁)
          rw [Function.update_of_ne hne₁, Function.update_self] at heq_l
          have := hlt_life i₁ hold₁
          omega
        · have hne₁ : i₁ ≠ pid := fun heq => hcond.1 (heq ▸ hold₁)
          have hne₂ : i₂ ≠ pid := fun heq => hcond.1 (heq ▸ hold₂)
          rw [Function.update_of_ne hne₁, Function.update_of_ne hne₂] at heq_l
          exact hinj_life i₁ hold₁ i₂ hold₂ heq_l
  | delete id =>
    cases rh with
    | some _ => simp [applyDynamicUpdate] at happ
    | none =>
      unfold applyDynamicUpdate at happ
      dsimp only at happ
      split_ifs at happ with hid_in
      simp only [Option.some.injEq] at happ
      subst happ
      refine ⟨(Finset.card_erase_le).trans hcard, ?_, ?_, ?_, ?_⟩
      · intro id' hid'
        rcases Finset.mem_erase.mp hid' with ⟨hne_id, hold⟩
        have ⟨hm, heq⟩ := hid_h id' hold
        have hne_h : P.handleOfId id' ≠ P.handleOfId id := by
          intro hh
          have h1 := congrArg P.idOfHandle hh
          rw [heq, (hid_h id hid_in).2] at h1
          exact hne_id h1
        simp [Function.update, hne_id, hne_h, hm, heq]
      · intro h' hh'
        rcases Finset.mem_erase.mp hh' with ⟨hne_h, hold⟩
        have ⟨hm, heq⟩ := hh_id h' hold
        have hne_id : P.idOfHandle h' ≠ id := fun hi => hne_h (hi ▸ heq.symm)
        simp [Function.update, hne_h, hne_id, hm, heq]
      · intro id' hid'
        rcases Finset.mem_erase.mp hid' with ⟨hne_id, hold⟩
        simp [Function.update, hne_id, hlt_life id' hold]
      · intro i₁ hi₁ i₂ hi₂ heq_l
        rcases Finset.mem_erase.mp hi₁ with ⟨hne₁, hold₁⟩
        rcases Finset.mem_erase.mp hi₂ with ⟨hne₂, hold₂⟩
        simp only [Function.update_of_ne hne₁, Function.update_of_ne hne₂] at heq_l
        exact hinj_life i₁ hold₁ i₂ hold₂ heq_l

open Classical in
theorem fixedCoinBridge {d : ℕ} {State : Type}
    {n t : ℕ} {δ c stepWorkBound spaceBound : ℝ}
    (_hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (B_STEP : ℕ)
    (alg : DynamicDiameterStructure d State)
    (ReachInv : ℕ → DynamicPointSet d → State → Prop)
    (GoodInv : ℕ → DynamicPointSet d → State → Prop)
    (hInitWork : (alg.initWork : ℝ) ≤ stepWorkBound)
    (hInitSpace : (alg.initSpace : ℝ) ≤ spaceBound)
    (hInitReach : ReachInv 0 (DynamicPointSet.empty d) alg.initState)
    (hInitGood : GoodInv 0 (DynamicPointSet.empty d) alg.initState)
    (hStepNone : ∀ (s : ℕ) (P : DynamicPointSet d) (st : State) (op : DynamicUpdate d) (bs : List Bool),
      s < t → P.WellFormed n → ReachInv s P st → IsLegalUpdate n Set.univ P op →
      bs.length ≠ B_STEP →
      runSingleAdaptiveStep alg P st op bs = none)
    (hStepSome : ∀ (s : ℕ) (P : DynamicPointSet d) (st : State) (op : DynamicUpdate d)
        (bits : Fin B_STEP → Bool),
      s < t → P.WellFormed n → ReachInv s P st → IsLegalUpdate n Set.univ P op →
      ∃ (P' : DynamicPointSet d) (out : DynamicStepOutcome State),
        runSingleAdaptiveStep alg P st op (List.ofFn bits) = some (P', out) ∧
        ReachInv (s + 1) P' out.nextState ∧
        (out.work : ℝ) ≤ stepWorkBound ∧
        (out.peakSpace : ℝ) ≤ spaceBound ∧
        (GoodInv (s + 1) P' out.nextState → IsValidFactorCAnswer c P' out.storedAnswer))
    (hBadFrac : ∀ (s : ℕ) (P : DynamicPointSet d) (st : State) (op : DynamicUpdate d),
      s < t → P.WellFormed n → ReachInv s P st → GoodInv s P st → IsLegalUpdate n Set.univ P op →
      (((Finset.univ.filter (fun bits : Fin B_STEP → Bool =>
          match runSingleAdaptiveStep alg P st op (List.ofFn bits) with
          | some (P', out) => ¬ GoodInv (s + 1) P' out.nextState
          | none => True)).card : ℝ) ≤ (δ / (t : ℝ)) * ((2 ^ B_STEP : ℕ) : ℝ))) :
    SatisfiesMonteCarloGuarantee n t δ c Set.univ alg ∧
    SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg stepWorkBound ∧
    SatisfiesBoundedSpaceBound n t Set.univ alg spaceBound := by
  have hEmptyWF : (DynamicPointSet.empty d).WellFormed n := by
    refine ⟨by simp [DynamicPointSet.empty], ?_, ?_, ?_, ?_⟩ <;> simp [DynamicPointSet.empty]
  -- Reachability invariant along any valid `bitTrace` of length `≤ t`
  have hReachSteps : ∀ (adv : AdaptiveAdversary d),
      IsValidBoundedAdversary n t Set.univ alg adv →
      ∀ (k : ℕ) (hk : k ≤ t) (bitTrace : List (List Bool)) (hlen : bitTrace.length = k)
        (prefSt : AdaptivePrefixState d State),
        runAdaptiveSteps alg adv bitTrace = some prefSt →
        prefSt.history.length = k ∧
        prefSt.pointSet.WellFormed n ∧
        ReachInv k prefSt.pointSet prefSt.algState ∧
        (∀ w ∈ prefSt.stepWorks, (w : ℝ) ≤ stepWorkBound) ∧
        (prefSt.maxSpace : ℝ) ≤ spaceBound ∧
        (∀ i : Fin k, (bitTrace[i.val]'(by omega)).length = B_STEP) := by
    intro adv hadv k
    induction k with
    | zero =>
      intro _ bitTrace hlen prefSt hrun
      have hnil : bitTrace = [] := List.eq_nil_of_length_eq_zero hlen
      subst hnil
      simp only [runAdaptiveSteps, runAdaptiveStepsFrom, Option.some.injEq] at hrun
      subst hrun
      exact ⟨rfl, hEmptyWF, hInitReach, by simp [initAdaptivePrefixState],
        hInitSpace, fun i => Fin.elim0 i⟩
    | succ s ih =>
      intro hs_le bitTrace hlen prefSt hrun
      have hne : bitTrace ≠ [] := by intro h; simp [h] at hlen
      have hdrop_len : (bitTrace.dropLast).length = s := by
        rw [List.length_dropLast, hlen]; omega
      have hsplit : bitTrace = bitTrace.dropLast ++ [bitTrace.getLast hne] :=
        (List.dropLast_append_getLast hne).symm
      rw [hsplit] at hrun
      -- Split `runAdaptiveStepsFrom` across `++ [b]`
      have hfrom_app : ∀ (l₁ : List (List Bool)) (b : List Bool) (cur : AdaptivePrefixState d State),
          runAdaptiveStepsFrom alg adv cur (l₁ ++ [b]) =
            match runAdaptiveStepsFrom alg adv cur l₁ with
            | none => none
            | some mid => runAdaptiveStepsFrom alg adv mid [b] := by
        intro l₁ b
        induction l₁ with
        | nil => intro cur; rfl
        | cons hd tl ihl =>
          intro cur
          simp only [List.cons_append, runAdaptiveStepsFrom]
          cases runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) hd with
          | none => rfl
          | some po => exact ihl _
      unfold runAdaptiveSteps at hrun
      rw [hfrom_app] at hrun
      cases hmid : runAdaptiveSteps alg adv bitTrace.dropLast with
      | none =>
        unfold runAdaptiveSteps at hmid
        simp [hmid] at hrun
      | some mid =>
        have hmid' : runAdaptiveStepsFrom alg adv (initAdaptivePrefixState alg) bitTrace.dropLast = some mid := hmid
        rw [hmid'] at hrun
        obtain ⟨hh_mid, hwf_mid, hr_mid, hw_mid, hsp_mid, hbl_mid⟩ :=
          ih (by omega) bitTrace.dropLast hdrop_len mid hmid
        have hleg_mid : IsLegalUpdate n Set.univ mid.pointSet (adv mid.history) :=
          hadv bitTrace.dropLast (by omega) mid hmid
        simp only [runAdaptiveStepsFrom] at hrun
        cases hstep_last : runSingleAdaptiveStep alg mid.pointSet mid.algState (adv mid.history) (bitTrace.getLast hne) with
        | none => simp [hstep_last] at hrun
        | some po =>
          rcases po with ⟨P', out⟩
          simp only [hstep_last, Option.some.injEq] at hrun
          subst hrun
          let bLast := bitTrace.getLast hne
          have hb_len : bLast.length = B_STEP := by
            by_contra hne_len
            have hnone := hStepNone s mid.pointSet mid.algState (adv mid.history) bLast
              (by omega) hwf_mid hr_mid hleg_mid hne_len
            dsimp only [bLast] at hnone
            rw [hnone] at hstep_last
            simp at hstep_last
          let bitsLast : Fin B_STEP → Bool := fun j => bLast[j.val]'(by omega)
          have hb_eq : List.ofFn bitsLast = bitTrace.getLast hne :=
            List.ext_getElem (by simp [bLast, hb_len]) (by simp [bitsLast, bLast])
          obtain ⟨P'', out'', hsome'', hr_nxt, hw_nxt, hsp_nxt, _⟩ :=
            hStepSome s mid.pointSet mid.algState (adv mid.history) bitsLast
              (by omega) hwf_mid hr_mid hleg_mid
          rw [hb_eq, hstep_last] at hsome''
          injection hsome'' with hpair
          obtain ⟨rfl, rfl⟩ := Prod.mk.inj hpair
          have hwf_P' : P'.WellFormed n := by
            unfold runSingleAdaptiveStep at hstep_last
            cases hbits : alg.stepWithBits mid.pointSet.activeHandles mid.pointSet.handleCoords
                mid.algState (toInternalUpdate mid.pointSet (adv mid.history)) (bitTrace.getLast hne) with
            | none => simp [hbits] at hstep_last
            | some out0 =>
              simp only [hbits] at hstep_last
              cases happ : applyDynamicUpdate mid.pointSet (adv mid.history) out0.returnedHandle with
              | none => simp [happ] at hstep_last
              | some P0 =>
                simp only [happ, Option.some.injEq, Prod.mk.injEq] at hstep_last
                rw [← hstep_last.1]
                exact applyDynamicUpdate_wellFormed hwf_mid hleg_mid happ
          refine ⟨by simp [hh_mid], hwf_P', hr_nxt, ?_, ?_, ?_⟩
          · intro w hw
            simp only [List.mem_append, List.mem_singleton] at hw
            rcases hw with hw | rfl
            · exact hw_mid w hw
            · exact hw_nxt
          · simp only [Nat.cast_max]
            exact max_le hsp_mid hsp_nxt
          · intro i
            have hi_bound : i.val < s + 1 := by have := i.isLt; omega
            have hget_eq : bitTrace[i.val] = (bitTrace.dropLast ++ [bitTrace.getLast hne])[i.val]'(by simp [hdrop_len]; omega) := by
              congr 1
            rw [hget_eq]
            by_cases hi_lt : i.val < s
            · rw [List.getElem_append_left (by omega)]
              exact hbl_mid ⟨i.val, by omega⟩
            · have hi_eq : i.val = s := by omega
              rw [List.getElem_append_right (by omega)]
              simpa [hdrop_len, hi_eq] using hb_len

  refine ⟨⟨hδ0, hδ1, fun adv hadv => ⟨?_, ?_⟩⟩,
    ⟨hInitWork, fun adv hadv T hT trace out hrun => ?_⟩,
    ⟨hInitSpace, fun adv hadv T hT trace out hrun => ?_⟩⟩
  · -- Almost-sure single-step halting
    intro bitTrace hlt prefSt hrun
    obtain ⟨_, hwf, hreach, _, _, _⟩ :=
      hReachSteps adv hadv bitTrace.length (by omega) bitTrace rfl prefSt hrun
    have hleg := hadv bitTrace hlt prefSt hrun
    unfold singleStepValidHaltProb
    rw [tsum_eq_sum_ofFn_of_len (B := B_STEP)]
    · have hcongr : ∀ bits : Fin B_STEP → Bool,
          (if (runSingleAdaptiveStep alg prefSt.pointSet prefSt.algState (adv prefSt.history)
              (List.ofFn bits)).isSome then bitListProb (List.ofFn bits) else 0) =
          bitListProb (List.ofFn bits) := by
        intro bits
        obtain ⟨P', out, hsome, _⟩ :=
          hStepSome bitTrace.length prefSt.pointSet prefSt.algState (adv prefSt.history) bits
            hlt hwf hreach hleg
        simp [hsome]
      simp_rw [hcongr]
      exact sum_bitListProb_ofFn B_STEP
    · intro bs hbs
      rw [hStepNone bitTrace.length prefSt.pointSet prefSt.algState (adv prefSt.history) bs
        hlt hwf hreach hleg hbs]
      simp
  · -- Monte Carlo probability ≥ 1 - δ over T ≤ t steps via finite coin space `Fin T → Fin B_STEP → Bool`
    intro T hT
    have hfrom_app : ∀ (l₁ : List (List Bool)) (b : List Bool) (cur : AdaptivePrefixState d State),
        runAdaptiveStepsFrom alg adv cur (l₁ ++ [b]) =
          match runAdaptiveStepsFrom alg adv cur l₁ with
          | none => none
          | some mid => runAdaptiveStepsFrom alg adv mid [b] := by
      intro l₁ b
      induction l₁ with
      | nil => intro cur; rfl
      | cons hd tl ihl =>
        intro cur
        simp only [List.cons_append, runAdaptiveStepsFrom]
        cases runSingleAdaptiveStep alg cur.pointSet cur.algState (adv cur.history) hd with
        | none => rfl
        | some _ => exact ihl _
    -- Inductive lower bound `(1 - k * (δ / t)) * (2^B_STEP)^k ≤ goodCoinCount k`
    have hgood_ind : ∀ (k : ℕ), k ≤ t →
        ∃ (evalCoins : (Fin k → Fin B_STEP → Bool) → AdaptivePrefixState d State),
          (∀ fc : Fin k → Fin B_STEP → Bool,
            runAdaptivePrefix alg adv k (fun j => List.ofFn (fc j)) = some (evalCoins fc)) ∧
          (1 - (k : ℝ) * (δ / (t : ℝ))) * (((2 ^ B_STEP : ℕ) ^ k : ℕ) : ℝ) ≤
            ((Finset.univ.filter (fun fc : Fin k → Fin B_STEP → Bool =>
                GoodInv k (evalCoins fc).pointSet (evalCoins fc).algState ∧
                AllPrefixAnswersValid c (evalCoins fc))).card : ℝ) := by
      intro k
      induction k with
      | zero =>
        intro _
        refine ⟨fun _ => initAdaptivePrefixState alg, fun _ => rfl, ?_⟩
        have hall : Finset.univ.filter (fun _ : Fin 0 → Fin B_STEP → Bool =>
            GoodInv 0 (DynamicPointSet.empty d) alg.initState ∧
            AllPrefixAnswersValid c (initAdaptivePrefixState alg)) = Finset.univ := by
          ext _
          simp [hInitGood, AllPrefixAnswersValid, initAdaptivePrefixState]
        change _ ≤ ((Finset.univ.filter (fun _ : Fin 0 → Fin B_STEP → Bool =>
          GoodInv 0 (DynamicPointSet.empty d) alg.initState ∧
          AllPrefixAnswersValid c (initAdaptivePrefixState alg))).card : ℝ)
        rw [hall, Finset.card_univ, Fintype.card_fun, Fintype.card_fin]
        simp
      | succ s ih =>
        intro hs_le
        obtain ⟨evalS, hevalS, hcardS⟩ := ih (by omega)
        -- Snoc equivalence `(Fin s → α) × α ≃ (Fin (s + 1) → α)`
        let snocEq : ((Fin s → Fin B_STEP → Bool) × (Fin B_STEP → Bool)) ≃
            (Fin (s + 1) → Fin B_STEP → Bool) :=
          { toFun := fun p => Fin.snoc p.1 p.2
            invFun := fun f => (Fin.init f, f (Fin.last s))
            left_inv := fun p => Prod.ext (by simp) (by simp)
            right_inv := fun f => Fin.snoc_init_self f }
        have hstep_fc : ∀ fc : Fin (s + 1) → Fin B_STEP → Bool,
            ∃ out : AdaptivePrefixState d State,
              runAdaptivePrefix alg adv (s + 1) (fun j => List.ofFn (fc j)) = some out := by
          intro fc
          let fc0 : Fin s → Fin B_STEP → Bool := Fin.init fc
          let bLast : Fin B_STEP → Bool := fc (Fin.last s)
          have hmid := hevalS fc0
          unfold runAdaptivePrefix runAdaptiveSteps at hmid
          obtain ⟨_, hwf_m, hr_m, _, _, _⟩ :=
            hReachSteps adv hadv s (by omega) (List.ofFn fun j => List.ofFn (fc0 j)) (by simp)
              (evalS fc0) hmid
          have hleg_m := hadv (List.ofFn fun j => List.ofFn (fc0 j)) (by simp; omega) (evalS fc0) hmid
          obtain ⟨P', out', hsome', _⟩ :=
            hStepSome s (evalS fc0).pointSet (evalS fc0).algState (adv (evalS fc0).history)
              bLast (by omega) hwf_m hr_m hleg_m
          have hofFn_snoc : (List.ofFn fun j : Fin (s + 1) => List.ofFn (fc j)) =
              (List.ofFn fun j : Fin s => List.ofFn (fc0 j)) ++ [List.ofFn bLast] := by
            have hfc : (fun j : Fin (s + 1) => List.ofFn (fc j)) =
                Fin.snoc (fun j : Fin s => List.ofFn (fc0 j)) (List.ofFn bLast) := by
              ext j
              refine Fin.lastCases ?_ ?_ j
              · simp [bLast]
              · intro i; simp [fc0, Fin.init]
            rw [hfc]
            refine List.ext_getElem (by simp) (fun idx h1 h2 => ?_)
            rw [List.getElem_ofFn]
            by_cases hlt : idx < s
            · have hc : ∀ hp : idx < s + 1, (⟨idx, hp⟩ : Fin (s + 1)) = (⟨idx, hlt⟩ : Fin s).castSucc :=
                fun _ => Fin.ext rfl
              rw [hc, Fin.snoc_castSucc, List.getElem_append_left (by simpa using hlt), List.getElem_ofFn]
            · have heq_i : idx = s := by simp at h1; omega
              have hl : ∀ hp : idx < s + 1, (⟨idx, hp⟩ : Fin (s + 1)) = Fin.last s :=
                fun _ => Fin.ext heq_i
              rw [hl, Fin.snoc_last, List.getElem_append_right (by simp [heq_i])]
              simp [heq_i]
          unfold runAdaptivePrefix runAdaptiveSteps
          rw [hofFn_snoc, hfrom_app, hmid]
          simp only [runAdaptiveStepsFrom, hsome']
          exact ⟨_, rfl⟩
        let evalSucc : (Fin (s + 1) → Fin B_STEP → Bool) → AdaptivePrefixState d State :=
          fun fc => Classical.choose (hstep_fc fc)
        have hevalSucc : ∀ fc, runAdaptivePrefix alg adv (s + 1) (fun j => List.ofFn (fc j)) =
            some (evalSucc fc) := fun fc => Classical.choose_spec (hstep_fc fc)
        refine ⟨evalSucc, hevalSucc, ?_⟩
        let GoodS := Finset.univ.filter (fun fc0 : Fin s → Fin B_STEP → Bool =>
          GoodInv s (evalS fc0).pointSet (evalS fc0).algState ∧
          AllPrefixAnswersValid c (evalS fc0))
        let GoodSucc := Finset.univ.filter (fun fc : Fin (s + 1) → Fin B_STEP → Bool =>
          GoodInv (s + 1) (evalSucc fc).pointSet (evalSucc fc).algState ∧
          AllPrefixAnswersValid c (evalSucc fc))
        -- Count good extensions `(fc0, bLast)` for each `fc0 ∈ GoodS`
        have hfiber : ∀ fc0 ∈ GoodS,
            (1 - δ / (t : ℝ)) * ((2 ^ B_STEP : ℕ) : ℝ) ≤
              ((Finset.univ.filter (fun bLast : Fin B_STEP → Bool =>
                snocEq (fc0, bLast) ∈ GoodSucc)).card : ℝ) := by
          intro fc0 hfc0
          obtain ⟨hg_fc0, hall_fc0⟩ := (Finset.mem_filter.mp hfc0).2
          have hmid := hevalS fc0
          obtain ⟨_, hwf_m, hr_m, _, _, _⟩ :=
            hReachSteps adv hadv s (by omega) (List.ofFn fun j => List.ofFn (fc0 j)) (by simp)
              (evalS fc0) hmid
          have hleg_m := hadv (List.ofFn fun j => List.ofFn (fc0 j)) (by simp; omega) (evalS fc0) hmid
          have hbad := hBadFrac s (evalS fc0).pointSet (evalS fc0).algState (adv (evalS fc0).history)
            (by omega) hwf_m hr_m hg_fc0 hleg_m
          let BadB := Finset.univ.filter (fun bLast : Fin B_STEP → Bool =>
            match runSingleAdaptiveStep alg (evalS fc0).pointSet (evalS fc0).algState
                (adv (evalS fc0).history) (List.ofFn bLast) with
            | some (P', out) => ¬ GoodInv (s + 1) P' out.nextState
            | none => True)
          let GoodB := Finset.univ.filter (fun bLast : Fin B_STEP → Bool =>
            snocEq (fc0, bLast) ∈ GoodSucc)
          have hcompl_sub : Finset.univ \ BadB ⊆ GoodB := by
            intro bLast hb
            rw [Finset.mem_sdiff] at hb
            have hnot_bad := hb.2
            simp only [BadB, Finset.mem_filter, Finset.mem_univ, true_and] at hnot_bad
            obtain ⟨P', out', hsome', _, _, _, hvalid_ans⟩ :=
              hStepSome s (evalS fc0).pointSet (evalS fc0).algState (adv (evalS fc0).history)
                bLast (by omega) hwf_m hr_m hleg_m
            rw [hsome'] at hnot_bad
            push_neg at hnot_bad
            -- Show `evalSucc (snocEq (fc0, bLast))` matches `(P', out')`
            have hrun_succ := hevalSucc (snocEq (fc0, bLast))
            have hofFn_snoc : (List.ofFn fun j : Fin (s + 1) => List.ofFn (snocEq (fc0, bLast) j)) =
                (List.ofFn fun j : Fin s => List.ofFn (fc0 j)) ++ [List.ofFn bLast] := by
              refine List.ext_getElem (by simp) (fun idx h1 h2 => ?_)
              rw [List.getElem_ofFn]
              by_cases hlt : idx < s
              · have hc : ∀ hp : idx < s + 1, (⟨idx, hp⟩ : Fin (s + 1)) = (⟨idx, hlt⟩ : Fin s).castSucc :=
                  fun _ => Fin.ext rfl
                rw [hc]
                simp only [snocEq, Equiv.coe_fn_mk, Fin.snoc_castSucc]
                rw [List.getElem_append_left (by simp [hlt]), List.getElem_ofFn]
              · have heq_i : idx = s := by simp at h1; omega
                have hl : ∀ hp : idx < s + 1, (⟨idx, hp⟩ : Fin (s + 1)) = Fin.last s :=
                  fun _ => Fin.ext heq_i
                rw [hl]
                simp only [snocEq, Equiv.coe_fn_mk, Fin.snoc_last]
                rw [List.getElem_append_right (by simp [heq_i])]
                simp [heq_i]
            unfold runAdaptivePrefix runAdaptiveSteps at hrun_succ hmid
            rw [hofFn_snoc, hfrom_app, hmid] at hrun_succ
            simp only [runAdaptiveStepsFrom, hsome', Option.some.injEq] at hrun_succ
            change bLast ∈ GoodB
            exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,
              Finset.mem_filter.mpr ⟨Finset.mem_univ _,
              by rw [← hrun_succ]; exact hnot_bad,
              by
                rw [← hrun_succ]
                intro snap hsnap
                simp only [List.mem_append, List.mem_singleton] at hsnap
                rcases hsnap with hsnap | rfl
                · exact hall_fc0 snap hsnap
                · exact hvalid_ans hnot_bad⟩⟩

          have hcard_gb : (2 ^ B_STEP : ℕ) ≤ GoodB.card + BadB.card := by
            have h1 : (Finset.univ \ BadB).card ≤ GoodB.card := Finset.card_le_card hcompl_sub
            have h2 : (Finset.univ : Finset (Fin B_STEP → Bool)).card = 2 ^ B_STEP := by simp
            have h3 := Finset.card_sdiff_add_card_eq_card (Finset.subset_univ BadB)
            omega
          have hcard_gb_r : ((2 ^ B_STEP : ℕ) : ℝ) ≤ (GoodB.card : ℝ) + (BadB.card : ℝ) := by
            exact_mod_cast hcard_gb
          linarith
        -- Sum `hfiber` over `fc0 ∈ GoodS` and inject into `GoodSucc` via `snocEq`
        let GoodPairs := (GoodS ×ˢ (Finset.univ : Finset (Fin B_STEP → Bool))).filter
          (fun p => snocEq p ∈ GoodSucc)
        have hmap_sub : GoodPairs.map snocEq.toEmbedding ⊆ GoodSucc := by
          intro fc hfc
          rw [Finset.mem_map] at hfc
          rcases hfc with ⟨p, hp, rfl⟩
          exact (Finset.mem_filter.mp hp).2
        have hpairs_le : GoodPairs.card ≤ GoodSucc.card := by
          rw [← Finset.card_map snocEq.toEmbedding]
          exact Finset.card_le_card hmap_sub
        have hpairs_eq : GoodPairs.card =
            ∑ fc0 ∈ GoodS, (Finset.univ.filter (fun bLast => snocEq (fc0, bLast) ∈ GoodSucc)).card := by
          rw [Finset.card_filter, Finset.sum_product]
          refine Finset.sum_congr rfl (fun fc0 _ => ?_)
          rw [Finset.card_filter]
        have hsum_ge :
            (GoodS.card : ℝ) * ((1 - δ / (t : ℝ)) * ((2 ^ B_STEP : ℕ) : ℝ)) ≤ (GoodSucc.card : ℝ) := by
          calc
            (GoodS.card : ℝ) * ((1 - δ / (t : ℝ)) * ((2 ^ B_STEP : ℕ) : ℝ))
                = ∑ _fc0 ∈ GoodS, (1 - δ / (t : ℝ)) * ((2 ^ B_STEP : ℕ) : ℝ) := by
                  rw [Finset.sum_const, nsmul_eq_mul]
            _ ≤ ∑ fc0 ∈ GoodS,
                  ((Finset.univ.filter (fun bLast => snocEq (fc0, bLast) ∈ GoodSucc)).card : ℝ) :=
                  Finset.sum_le_sum hfiber
            _ = (GoodPairs.card : ℝ) := by exact_mod_cast hpairs_eq.symm
            _ ≤ (GoodSucc.card : ℝ) := by exact_mod_cast hpairs_le
        have h1m_nn : 0 ≤ 1 - δ / (t : ℝ) := by
          have ht_ge1 : (1 : ℝ) ≤ (t : ℝ) := by exact_mod_cast ht
          have hdiv_le : δ / (t : ℝ) ≤ δ := div_le_self hδ0.le ht_ge1
          linarith
        have hbern : 1 - ((s + 1 : ℕ) : ℝ) * (δ / (t : ℝ)) ≤
            (1 - (s : ℝ) * (δ / (t : ℝ))) * (1 - δ / (t : ℝ)) := by
          have hsq : 0 ≤ (s : ℝ) * (δ / (t : ℝ)) ^ 2 := by positivity
          push_cast
          nlinarith
        calc
          (1 - ((s + 1 : ℕ) : ℝ) * (δ / (t : ℝ))) * (((2 ^ B_STEP : ℕ) ^ (s + 1) : ℕ) : ℝ)
              ≤ ((1 - (s : ℝ) * (δ / (t : ℝ))) * (1 - δ / (t : ℝ))) *
                  ((((2 ^ B_STEP : ℕ) ^ s : ℕ) : ℝ) * ((2 ^ B_STEP : ℕ) : ℝ)) := by
                rw [pow_succ, Nat.cast_mul]
                exact mul_le_mul_of_nonneg_right hbern (by positivity)
          _ = ((1 - (s : ℝ) * (δ / (t : ℝ))) * (((2 ^ B_STEP : ℕ) ^ s : ℕ) : ℝ)) *
                ((1 - δ / (t : ℝ)) * ((2 ^ B_STEP : ℕ) : ℝ)) := by ring
          _ ≤ (GoodS.card : ℝ) * ((1 - δ / (t : ℝ)) * ((2 ^ B_STEP : ℕ) : ℝ)) :=
                mul_le_mul_of_nonneg_right hcardS (by positivity)
          _ ≤ (GoodSucc.card : ℝ) := hsum_ge

    obtain ⟨evalT, hevalT, hcardT⟩ := hgood_ind T hT
    let GoodT := Finset.univ.filter (fun fc : Fin T → Fin B_STEP → Bool =>
      GoodInv T (evalT fc).pointSet (evalT fc).algState ∧
      AllPrefixAnswersValid c (evalT fc))
    -- Lower-bound `adaptivePrefixEventProb` by the sum over `fc ∈ GoodT`
    have hinj_tr : Function.Injective
        (fun fc : Fin T → Fin B_STEP → Bool => (fun j : Fin T => List.ofFn (fc j))) := by
      intro f₁ f₂ h
      ext j i
      have hj := congrFun h j
      have hi := congrArg (fun l => l[i.val]?) hj
      simpa using hi
    have hprob_fc : ∀ fc : Fin T → Fin B_STEP → Bool,
        prefixTraceProb (fun j : Fin T => List.ofFn (fc j)) =
          (((2 : ENNReal)⁻¹) ^ B_STEP) ^ T := by
      intro fc
      unfold prefixTraceProb
      simp [bitListProb]
    have hsum_le_tsum :
        (GoodT.card : ENNReal) * ((((2 : ENNReal)⁻¹) ^ B_STEP) ^ T) ≤
          adaptivePrefixEventProb alg adv T (AllPrefixAnswersValid c) := by
      unfold adaptivePrefixEventProb
      let term : (Fin T → List Bool) → ENNReal := fun tr =>
        match runAdaptivePrefix alg adv T tr with
        | some out => if AllPrefixAnswersValid c out then prefixTraceProb tr else 0
        | none => 0
      change _ ≤ ∑' tr, term tr
      have hterm_good : ∀ fc ∈ GoodT,
          ((((2 : ENNReal)⁻¹) ^ B_STEP) ^ T) ≤ term (fun j => List.ofFn (fc j)) := by
        intro fc hfc
        have hall := (Finset.mem_filter.mp hfc).2.2
        dsimp only [term]
        rw [hevalT fc]
        dsimp only
        rw [if_pos hall, hprob_fc fc]
      calc
        (GoodT.card : ENNReal) * ((((2 : ENNReal)⁻¹) ^ B_STEP) ^ T)
            = ∑ _fc ∈ GoodT, ((((2 : ENNReal)⁻¹) ^ B_STEP) ^ T) := by
              rw [Finset.sum_const, nsmul_eq_mul]
        _ ≤ ∑ fc ∈ GoodT, term (fun j => List.ofFn (fc j)) :=
              Finset.sum_le_sum hterm_good
        _ = ∑ tr ∈ GoodT.map ⟨_, hinj_tr⟩, term tr := (Finset.sum_map GoodT ⟨_, hinj_tr⟩ term).symm
        _ ≤ ∑' tr, term tr := ENNReal.sum_le_tsum _
    have h1m_le : 1 - δ ≤ 1 - (T : ℝ) * (δ / (t : ℝ)) := by
      have hT_le_t : (T : ℝ) ≤ (t : ℝ) := by exact_mod_cast hT
      have ht_pos : (0 : ℝ) < (t : ℝ) := by exact_mod_cast ht
      have hmul : (T : ℝ) * (δ / (t : ℝ)) ≤ δ := by
        rw [← mul_div_assoc, div_le_iff₀ ht_pos]
        exact mul_comm (T : ℝ) δ ▸ mul_le_mul_of_nonneg_left hT_le_t hδ0.le
      linarith
    have hreal_good : (1 - δ) * (((2 ^ B_STEP : ℕ) ^ T : ℕ) : ℝ) ≤ (GoodT.card : ℝ) :=
      (mul_le_mul_of_nonneg_right h1m_le (by positivity)).trans hcardT
    have henn_good := ENNReal.ofReal_le_ofReal hreal_good
    rw [ENNReal.ofReal_mul (by linarith), ENNReal.ofReal_natCast, ENNReal.ofReal_natCast] at henn_good
    have hcancel :
        ((((2 ^ B_STEP : ℕ) ^ T : ℕ) : ENNReal)) * ((((2 : ENNReal)⁻¹) ^ B_STEP) ^ T) = 1 := by
      push_cast
      rw [← mul_pow, ← mul_pow, ENNReal.mul_inv_cancel (by norm_num) (by simp), one_pow, one_pow]
    calc
      ENNReal.ofReal (1 - δ)
          = ENNReal.ofReal (1 - δ) *
              (((((2 ^ B_STEP : ℕ) ^ T : ℕ) : ENNReal)) * ((((2 : ENNReal)⁻¹) ^ B_STEP) ^ T)) := by
            rw [hcancel, mul_one]
      _ = (ENNReal.ofReal (1 - δ) * (((2 ^ B_STEP : ℕ) ^ T : ℕ) : ENNReal)) *
            ((((2 : ENNReal)⁻¹) ^ B_STEP) ^ T) := by ring
      _ ≤ (GoodT.card : ENNReal) * ((((2 : ENNReal)⁻¹) ^ B_STEP) ^ T) :=
            mul_le_mul_of_nonneg_right henn_good (zero_le _)
      _ ≤ adaptivePrefixEventProb alg adv T (AllPrefixAnswersValid c) := hsum_le_tsum
  · -- Worst-case update work bound
    exact (hReachSteps adv hadv T hT (List.ofFn trace) (by simp) out hrun).2.2.2.1
  · -- Worst-case space bound
    exact (hReachSteps adv hadv T hT (List.ofFn trace) (by simp) out hrun).2.2.2.2.1

end UL.Proof.clm_9_1_explicit_tradeoff.H3a
