import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInst0
import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchRAM
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Stage4

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3b3
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.CG14
open UL.Proof.clm_9_1_explicit_tradeoff.CG15
open UL.Proof.clm_9_1_explicit_tradeoff.CG17
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG20

/-! ### Concrete `nodeAndHPJRAMOps` + `maxRadRAMOp` Instantiation & Master Polynomial Bounds -/

/-- Concrete `ConfigMatchRAMOps` (`CG17` + `CG16`) specialized to tables
`scrW = 10`, `scrR = 4`, `tblW = 9`, `tblR = 3`, `coinTbl = 5`. -/
noncomputable def nodeConfigMatchOps {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    ConfigMatchRAMOps d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b cp.T_cdf cp.p_coord
      (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
      10 4 9 3 coinTbl :=
  CG17.configMatchRAMOps d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b cp.T_cdf cp.p_coord
    (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
    10 4 9 3 coinTbl

theorem nodeConfigMatchHzr {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    ConfigMatchHeapZeroRand (nodeConfigMatchOps cp) :=
  CG17.configMatchHeapZeroRand d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b cp.T_cdf cp.p_coord
    (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
    10 4 9 3 coinTbl

/-- Full concrete transparent instantiation of `CG19.NodeAndHPJRAMOps cp` combining
`CG18_NodeRAM`, `CG17_MatchRAM` (`CG16_SideRAM`), and `CG14_CoinHPJ`. -/
noncomputable def nodeAndHPJRAMOps {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : NodeAndHPJRAMOps cp :=
  mkNodeAndHPJRAMOps cp (nodeConfigMatchOps cp) (nodeConfigMatchHzr cp)

/-- Companion `O(1)` (`C_maxRad = 200`) `CG20.MaxRadRAMOp` on `nodeAndHPJRAMOps cp` for Stage 4. -/
noncomputable def maxRadRAMOp {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : MaxRadRAMOp (nodeAndHPJRAMOps cp) :=
  mkMaxRadRAMOp cp (nodeConfigMatchOps cp) (nodeConfigMatchHzr cp)

/-- Explicit `ChainParams`-level cost and table-count formulas for `nodeAndHPJRAMOps cp`. -/
theorem nodeAndHPJRAMOps_costs_and_dims {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    let ops := nodeAndHPJRAMOps cp
    let mops := maxRadRAMOp cp
    ops.TW = 11 ∧
    ops.TR = 5 ∧
    ops.C_bump = 50 ∧
    ops.C_ball = 200 + 60 * d ∧
    ops.C_read = 370 ∧
    mops.C_maxRad = 200 ∧
    ops.C_open ≤ 500 + 95 * d + cp.N_cfg * (260 + 1440 * (cp.L_p2 + 1)) ∧
    ops.C_ins ≤ 1100 + 110 * d + 380 * cp.L_p2 +
      cp.N_cfg * ((1 + cp.cap_u + cp.cap_q + cp.R * cp.ℓ * cp.M₀) *
        configMatchPolyFactor d cp.L_p2 cp.R cp.ℓ cp.b cp.T_cdf cp.p_coord
          (M_lat_of d params.e) + 60) ∧
    ops.C_del ≤ 1110 + 110 * d + 380 * cp.L_p2 +
      cp.N_cfg * ((1 + cp.cap_u + cp.cap_q + cp.R * cp.ℓ * cp.M₀) *
        configMatchPolyFactor d cp.L_p2 cp.R cp.ℓ cp.b cp.T_cdf cp.p_coord
          (M_lat_of d params.e) + 60) ∧
    ops.C_hpj ≤ 500 + 60 * cp.N_samp * (cp.q_idx + 1) + 40 * cp.B_walk + 60 * d +
      40 * (Nat.ceil hpjOpConst * (d + 1) ^ 10 * cp.P_hpj.k_phi ^ 3) := by
  intro ops mops
  dsimp only [ops, mops, nodeAndHPJRAMOps, maxRadRAMOp]
  obtain ⟨hTW, hTR, _⟩ :=
    mkNodeAndHPJRAMOps_strides_and_dims cp (nodeConfigMatchOps cp) (nodeConfigMatchHzr cp)
  obtain ⟨hCopen, hCins, hCdel, hCbump, hCball, hChpj, hCread, hCmrad⟩ :=
    mkNodeAndHPJRAMOps_costs cp (nodeConfigMatchOps cp) (nodeConfigMatchHzr cp)
  have hreadE : (nodeConfigMatchOps cp).readEdgeCost = 120 := rfl
  have hclr := CG17.configMatchRAMOps_clearCost_le d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b
    cp.T_cdf cp.p_coord (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
    10 4 9 3 coinTbl
  have hins := CG17.configMatchRAMOps_insertCost_le d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b
    cp.T_cdf cp.p_coord (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
    10 4 9 3 coinTbl
  have hdel := CG17.configMatchRAMOps_deleteCost_le d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b
    cp.T_cdf cp.p_coord (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
    10 4 9 3 coinTbl
  refine ⟨hTW, hTR, hCbump, hCball, by rw [hCread, hreadE], hCmrad, ?_, ?_, ?_, ?_⟩
  · rw [hCopen]
    exact Nat.add_le_add_left (Nat.mul_le_mul_left cp.N_cfg (by
      change (CG17.configMatchRAMOps _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 10 4 9 3 coinTbl).clearCost + 40 ≤ _
      omega)) _
  · rw [hCins]
    exact Nat.add_le_add_left (Nat.mul_le_mul_left cp.N_cfg (Nat.add_le_add_right hins 60)) _
  · rw [hCdel]
    exact Nat.add_le_add_left (Nat.mul_le_mul_left cp.N_cfg (Nat.add_le_add_right hdel 60)) _
  · rw [hChpj]; exact evalHPJCenterCost_le_poly cp

/-- Uniform polynomial work and space bounds on `nodeAndHPJRAMOps inst.cp` + `maxRadRAMOp inst.cp`
(including `CG20.stepStage4Cost`) against `CG15.masterPolyParamNat`, `CG15.masterWorkFactorNat`,
and `CG15.masterSpaceFactorNat`. -/
theorem nodeAndHPJRAMOps_master_bounds {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ) :
    let P := masterPolyParamNat inst
    let W := masterWorkFactorNat inst.cp
    let S := masterSpaceFactorNat inst.cp
    let ops := nodeAndHPJRAMOps inst.cp
    let mops := maxRadRAMOp inst.cp
    ops.C_open ≤ C_node_work * P ^ 13 * W ∧
    ops.C_ins ≤ C_node_work * P ^ 13 * W ∧
    ops.C_del ≤ C_node_work * P ^ 13 * W ∧
    ops.C_bump ≤ C_node_work * P ^ 13 * W ∧
    ops.C_ball ≤ C_node_work * P ^ 13 * W ∧
    ops.C_hpj ≤ C_node_work * P ^ 13 * W ∧
    ops.C_read ≤ C_node_work * P ^ 13 * W ∧
    ops.C_bump = 50 ∧
    ops.C_ball = 200 + 60 * d ∧
    ops.C_read = 370 ∧
    mops.C_maxRad = 200 ∧
    stepStage4Cost ops mops ≤ C_node_work * P ^ 13 * W ∧
    ops.TW * ops.BW + ops.TR * ops.BR ≤ C_node_space * P ^ 13 * S := by
  intro _P _W _S ops mops
  dsimp only [_P, _W, _S]
  clear _P _W _S
  have hmain := mkNodeAndHPJRAMOps_master_bounds inst
    (nodeConfigMatchOps inst.cp) (nodeConfigMatchHzr inst.cp)
    (CG17.configMatchRAMOps_cfgWStride_le d inst.cp.n inst.cp.L_p2 inst.cp.R inst.cp.ℓ
      inst.cp.M₀ inst.cp.b inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e)
      inst.params (inst.h_rat : ℝ) inst.cp.τ_d inst.cp.τ_q inst.cp.cap_u inst.cp.cap_q
      10 4 9 3 coinTbl)
    (CG17.configMatchRAMOps_cfgRStride_le d inst.cp.n inst.cp.L_p2 inst.cp.R inst.cp.ℓ
      inst.cp.M₀ inst.cp.b inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e)
      inst.params (inst.h_rat : ℝ) inst.cp.τ_d inst.cp.τ_q inst.cp.cap_u inst.cp.cap_q
      10 4 9 3 coinTbl)
    (CG17.configMatchRAMOps_opWScrStride_le d inst.cp.n inst.cp.L_p2 inst.cp.R inst.cp.ℓ
      inst.cp.M₀ inst.cp.b inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e)
      inst.params (inst.h_rat : ℝ) inst.cp.τ_d inst.cp.τ_q inst.cp.cap_u inst.cp.cap_q
      10 4 9 3 coinTbl)
    (CG17.configMatchRAMOps_opRScrStride_le d inst.cp.n inst.cp.L_p2 inst.cp.R inst.cp.ℓ
      inst.cp.M₀ inst.cp.b inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e)
      inst.params (inst.h_rat : ℝ) inst.cp.τ_d inst.cp.τ_q inst.cp.cap_u inst.cp.cap_q
      10 4 9 3 coinTbl)
    rfl
    (CG17.configMatchRAMOps_clearCost_le d inst.cp.n inst.cp.L_p2 inst.cp.R inst.cp.ℓ
      inst.cp.M₀ inst.cp.b inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e)
      inst.params (inst.h_rat : ℝ) inst.cp.τ_d inst.cp.τ_q inst.cp.cap_u inst.cp.cap_q
      10 4 9 3 coinTbl)
    (CG17.configMatchRAMOps_insertCost_le d inst.cp.n inst.cp.L_p2 inst.cp.R inst.cp.ℓ
      inst.cp.M₀ inst.cp.b inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e)
      inst.params (inst.h_rat : ℝ) inst.cp.τ_d inst.cp.τ_q inst.cp.cap_u inst.cp.cap_q
      10 4 9 3 coinTbl)
    (CG17.configMatchRAMOps_deleteCost_le d inst.cp.n inst.cp.L_p2 inst.cp.R inst.cp.ℓ
      inst.cp.M₀ inst.cp.b inst.cp.T_cdf inst.cp.p_coord (M_lat_of d inst.params.e)
      inst.params (inst.h_rat : ℝ) inst.cp.τ_d inst.cp.τ_q inst.cp.cap_u inst.cp.cap_q
      10 4 9 3 coinTbl)
  dsimp only at hmain
  obtain ⟨P, hP_def⟩ : ∃ x, x = masterPolyParamNat inst := ⟨_, rfl⟩
  obtain ⟨W, hW_def⟩ : ∃ x, x = masterWorkFactorNat inst.cp := ⟨_, rfl⟩
  obtain ⟨S, hS_def⟩ : ∃ x, x = masterSpaceFactorNat inst.cp := ⟨_, rfl⟩
  rw [← hP_def, ← hW_def, ← hS_def] at hmain ⊢
  rcases hmain with ⟨hOpen, hIns, hDel, hBumpEq, hBallEq, hHpj, hReadEq, hMradEq, hSp⟩
  have hBumpEq' : ops.C_bump = 50 := hBumpEq
  have hBallEq' : ops.C_ball = 200 + 60 * d := hBallEq
  have hReadEq' : ops.C_read = 370 := hReadEq
  have hMradEq' : mops.C_maxRad = 200 := hMradEq
  have hpc := poly_param_components inst; dsimp only at hpc; rw [← hP_def] at hpc
  obtain ⟨hP1, hd1, _, hDm, hBsc, hNcfg, _, _, _, _, _, _, _, _, hq1, hkbase, _⟩ := hpc
  have hwsc := work_space_components inst.cp; dsimp only at hwsc; rw [← hW_def, ← hS_def] at hwsc
  obtain ⟨hW1, _⟩ := hwsc
  have hpow : ∀ {a b : ℕ}, a ≤ b → P ^ a ≤ P ^ b := fun hab => Nat.pow_le_pow_right hP1 hab
  have hP13W : P ≤ P ^ 13 * W := by
    calc P = P ^ 1 * 1 := by ring
      _ ≤ P ^ 13 * W := Nat.mul_le_mul (hpow (by decide)) hW1
  have h1_13W : 1 ≤ P ^ 13 * W := le_trans hP1 hP13W
  have hBump : ops.C_bump ≤ C_node_work * P ^ 13 * W := by
    rw [hBumpEq']; unfold C_node_work
    calc 50 = 50 * 1 := by ring
      _ ≤ (50000 + 50 * Nat.ceil hpjOpConst) * (P ^ 13 * W) := Nat.mul_le_mul (by omega) h1_13W
      _ = (50000 + 50 * Nat.ceil hpjOpConst) * P ^ 13 * W := by ring
  have hBall : ops.C_ball ≤ C_node_work * P ^ 13 * W := by
    rw [hBallEq']
    have hd_le : d ≤ P ^ 13 * W := le_trans (by omega : d ≤ P) hP13W
    calc 200 + 60 * d ≤ 260 * (P ^ 13 * W) := by linarith only [h1_13W, hd_le]
      _ = 260 * P ^ 13 * W := by ring
      _ ≤ C_node_work * P ^ 13 * W :=
          Nat.mul_le_mul_right W (Nat.mul_le_mul_right _ (by unfold C_node_work; omega))
  have hRead : ops.C_read ≤ C_node_work * P ^ 13 * W := by
    rw [hReadEq']; unfold C_node_work
    calc 370 = 370 * 1 := by ring
      _ ≤ (50000 + 50 * Nat.ceil hpjOpConst) * (P ^ 13 * W) := Nat.mul_le_mul (by omega) h1_13W
      _ = (50000 + 50 * Nat.ceil hpjOpConst) * P ^ 13 * W := by ring
  have hS4 : stepStage4Cost ops mops ≤ C_node_work * P ^ 13 * W := by
    unfold stepStage4Cost leafCandCost oneNodeCandCost
    rw [hReadEq', hMradEq']
    have hP_P2 : P ≤ P ^ 2 := self_le_pow hP1 (by decide : 1 ≤ 2)
    have hP_P3 : P ≤ P ^ 3 := self_le_pow hP1 (by decide : 1 ≤ 3)
    have h1_P3 : 1 ≤ P ^ 3 := Nat.one_le_pow 3 P hP1
    have hd_P : d ≤ P := by omega
    have hleaf : 380 + 80 * d + inst.cp.B_scan * (60 + inst.cp.B_scan * (210 + 80 * d)) ≤
        810 * P ^ 3 := by
      have h1 : 210 + 80 * d ≤ 290 * P := by omega
      have h2 : inst.cp.B_scan * (210 + 80 * d) ≤ 290 * P ^ 2 := by
        calc inst.cp.B_scan * (210 + 80 * d) ≤ P * (290 * P) := Nat.mul_le_mul hBsc h1
          _ = 290 * P ^ 2 := by ring
      have h1_P2 : 1 ≤ P ^ 2 := Nat.one_le_pow 2 P hP1
      have h3 : 60 + inst.cp.B_scan * (210 + 80 * d) ≤ 350 * P ^ 2 := by linarith only [h1_P2, h2]
      have h4 : inst.cp.B_scan * (60 + inst.cp.B_scan * (210 + 80 * d)) ≤ 350 * P ^ 3 := by
        calc inst.cp.B_scan * (60 + inst.cp.B_scan * (210 + 80 * d))
            ≤ P * (350 * P ^ 2) := Nat.mul_le_mul hBsc h3
          _ = 350 * P ^ 3 := by ring
      have hd_P3 : d ≤ P ^ 3 := le_trans hd_P hP_P3
      linarith only [h1_P3, hd_P3, h4]
    have hone : 200 + 370 + 550 + 80 * d +
        inst.cp.k_base * (370 + 240 + 30 * inst.cp.q_idx + 80 * d) +
        inst.cp.N_cfg * (370 + 300 + 80 * d) ≤ 2670 * P ^ 2 := by
      have h1 : 370 + 240 + 30 * inst.cp.q_idx + 80 * d ≤ 720 * P := by omega
      have h2 : inst.cp.k_base * (370 + 240 + 30 * inst.cp.q_idx + 80 * d) ≤ 720 * P ^ 2 := by
        calc inst.cp.k_base * (370 + 240 + 30 * inst.cp.q_idx + 80 * d)
            ≤ P * (720 * P) := Nat.mul_le_mul hkbase h1
          _ = 720 * P ^ 2 := by ring
      have h3 : 370 + 300 + 80 * d ≤ 750 * P := by omega
      have h4 : inst.cp.N_cfg * (370 + 300 + 80 * d) ≤ 750 * P ^ 2 := by
        calc inst.cp.N_cfg * (370 + 300 + 80 * d) ≤ P * (750 * P) := Nat.mul_le_mul hNcfg h3
          _ = 750 * P ^ 2 := by ring
      have h1_P2 : 1 ≤ P ^ 2 := Nat.one_le_pow 2 P hP1
      have hd_P2 : d ≤ P ^ 2 := le_trans hd_P hP_P2
      linarith only [h1_P2, hd_P2, h2, h4]
    have hall : inst.cp.D_max * (200 + 370 + 550 + 80 * d +
        inst.cp.k_base * (370 + 240 + 30 * inst.cp.q_idx + 80 * d) +
        inst.cp.N_cfg * (370 + 300 + 80 * d)) ≤ 2670 * P ^ 3 := by
      calc inst.cp.D_max * _ ≤ P * (2670 * P ^ 2) := Nat.mul_le_mul hDm hone
        _ = 2670 * P ^ 3 := by ring
    have hd_P3 : d ≤ P ^ 3 := le_trans hd_P hP_P3
    have htot3 : 290 + 80 * d +
        (380 + 80 * d + inst.cp.B_scan * (60 + inst.cp.B_scan * (210 + 80 * d))) +
        inst.cp.D_max * (200 + 370 + 550 + 80 * d +
          inst.cp.k_base * (370 + 240 + 30 * inst.cp.q_idx + 80 * d) +
          inst.cp.N_cfg * (370 + 300 + 80 * d)) ≤ 3850 * P ^ 3 := by linarith only [h1_P3, hd_P3, hleaf, hall]
    calc _ ≤ 3850 * P ^ 3 := htot3
      _ ≤ 3850 * P ^ 13 := Nat.mul_le_mul_left 3850 (hpow (by decide))
      _ = 3850 * P ^ 13 * 1 := by ring
      _ ≤ C_node_work * P ^ 13 * W :=
          Nat.mul_le_mul (Nat.mul_le_mul_right _ (by unfold C_node_work; omega)) hW1
  exact ⟨hOpen, hIns, hDel, hBump, hBall, hHpj, hRead,
    hBumpEq, hBallEq, hReadEq, hMradEq, hS4, hSp⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
