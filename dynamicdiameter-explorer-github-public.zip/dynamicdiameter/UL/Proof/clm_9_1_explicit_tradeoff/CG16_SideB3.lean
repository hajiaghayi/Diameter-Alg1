import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideB2

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot slotWStride slotRStride slotWStride_ge_four
  seedCoordCount seedBitCount slotInsWStride slotInsRStride
  slotBktOff_bounds slotNodeOff_bounds slotRStride_gt_coord capCoordIdx_lt
  copyVecToHeapStmt exec_copyVecToHeapStmt)

private theorem wNe (m : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℤ)
    (h : t₁ ≠ t₂ ∨ i₁ ≠ i₂) : wRead (wWrite m t₂ i₂ v) t₁ i₁ = wRead m t₁ i₁ :=
  wRead_wWrite_of_ne m v h

private theorem rws (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) (idx val : ℤ) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (wWrite m scrW idx val) :=
  RadFrameOutside.wWrite_scr scrW scrR tblW baseW lenW tblR baseR lenR m idx val

private theorem rfo_wWrite_in (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) {idx : ℤ} (val : ℤ)
    (hlo : baseW ≤ idx) (hhi : idx < baseW + lenW) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (wWrite m tblW idx val) := by
  refine ⟨fun t i _ h => ?_, fun t _ _ _ => rRead_wWrite m t tblW _ idx val⟩
  apply wRead_wWrite_of_ne
  rcases h with ht | h1 | h2
  · exact Or.inl ht
  · exact Or.inr (by omega)
  · exact Or.inr (by omega)

/-! ### 1. `EncH4DyadicSide` & `EncSideStepSeed` Interface Helpers -/

theorem EncLiveSlot.mono_slice {tblW : ℕ} {baseW : ℤ} {tblR : ℕ} {baseR : ℤ}
    {R ℓ M₀ d cap_u B_max : ℕ} {S : LiveSlot R ℓ M₀ d} {m₀ m₁ : ArithRAMMemory}
    (henc : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀)
    (hkW : ∀ i : ℤ, baseW ≤ i → i < baseW + slotWStride R ℓ M₀ cap_u B_max →
      wRead m₁ tblW i = wRead m₀ tblW i)
    (hkR : ∀ i : ℤ, baseR ≤ i → i < baseR + slotRStride R ℓ M₀ d →
      rRead m₁ tblR i = rRead m₀ tblR i) :
    EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₁ := by
  have hge4 := slotWStride_ge_four R ℓ M₀ cap_u B_max
  rcases henc with ⟨hep, hblk, hbc, hcaps, hbkt, hnd⟩
  refine ⟨(hkW baseW le_rfl (by omega)).trans hep,
          (hkW (baseW + 1) (by omega) (by omega)).trans hblk,
          (hkW (baseW + 2) (by omega) (by omega)).trans hbc,
          fun r s k j => ?_, fun bkt hb => ?_, fun nd hn => ?_⟩
  · have hc := slotRStride_gt_coord (capCoordIdx_lt r s k j)
    exact (hkR _ (by omega) (by omega)).trans (hcaps r s k j)
  · have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hb
    rcases hbkt bkt hb with ⟨h1, h2⟩
    exact ⟨(hkW _ (by omega) (by omega)).trans h1, (hkW _ (by omega) (by omega)).trans h2⟩
  · have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hn
    have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
    rcases hnd nd hn with ⟨h1, h2, h3, h4, h5⟩
    exact ⟨(hkW _ (by omega) (by omega)).trans h1,
           (hkW _ (by omega) (by omega)).trans h2,
           (hkW _ (by omega) (by omega)).trans h3,
           (hkW _ (by omega) (by omega)).trans h4,
           (hkW _ (by omega) (by omega)).trans h5⟩

theorem EncH4DyadicSide.ep_pos {tblW : ℕ} {sideBaseW : ℤ} {tblR : ℕ} {sideBaseR : ℤ}
    {n L_p2 R ℓ M₀ d b cap_u : ℕ} {U : Finset ℕ}
    {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b} {m : ArithRAMMemory}
    (henc : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m) :
    1 ≤ wRead m tblW sideBaseW := by
  rcases henc with ⟨_, ep_side, _, hep1, hep_r, _⟩
  rw [hep_r]; exact_mod_cast hep1

theorem EncH4DyadicSide.mono_slice {tblW : ℕ} {sideBaseW : ℤ} {tblR : ℕ} {sideBaseR : ℤ}
    {n L_p2 R ℓ M₀ d b cap_u : ℕ} (hn : 1 ≤ n) {U : Finset ℕ}
    {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b} {m₀ m₁ : ArithRAMMemory}
    (henc : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀)
    (hkW : ∀ i : ℤ, sideBaseW ≤ i →
      i < sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u →
      wRead m₁ tblW i = wRead m₀ tblW i)
    (hkR : ∀ i : ℤ, sideBaseR + (d : ℤ) ≤ i →
      i < sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d →
      rRead m₁ tblR i = rRead m₀ tblR i) :
    EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₁ := by
  have hpow_pos : (1 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (@Nat.one_le_two_pow L_p2)
  have hge2 := dyadicSideWStride_ge_two n L_p2 R ℓ M₀ cap_u
  have hslot0_ge : 0 ≤ ((2 * L_p2 : ℕ) : ℤ) * slotWStride R ℓ M₀ cap_u (2 ^ L_p2) :=
    mul_nonneg (by positivity) (by have := slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2); omega)
  rcases henc with ⟨ht_le, ep_side, liveSlots, hep1, hep_r, ht_r,
    hhand, hal_le, hal_iff, hact, hpt, hslots, hcur⟩
  refine ⟨ht_le, ep_side, liveSlots, hep1,
    (hkW sideBaseW le_rfl (by omega)).trans hep_r,
    (hkW (sideBaseW + 1) (by omega) (by omega)).trans ht_r,
    fun eid heid => (hkW _ (by unfold sideHandleOff; omega)
      (by unfold sideHandleOff dyadicSideWStride; omega)).trans (hhand eid heid),
    fun eid heid => by
      rw [hkW _ (by unfold sideAliveEpOff; omega) (by unfold sideAliveEpOff dyadicSideWStride; omega)]
      exact hal_le eid heid,
    fun eid heid => by
      rw [hkW _ (by unfold sideAliveEpOff; omega) (by unfold sideAliveEpOff dyadicSideWStride; omega)]
      exact hal_iff eid heid,
    fun u hu => by
      have hmod : u % n < n := Nat.mod_lt u hn
      exact (hkW _ (by unfold sideActiveOff; omega)
        (by unfold sideActiveOff dyadicSideWStride; omega)).trans (hact u hu),
    fun eid heid c => by
      have hb := sideEntryPt_bounds (L_p2 := L_p2) sideBaseR (lt_of_lt_of_le heid ht_le) c
      have hre := dyadicSideRStride_ge_entryEnd L_p2 R ℓ M₀ d
      exact (hkR _ hb.1 (by omega)).trans (hpt eid heid c),
    fun s sl => ?_, hcur⟩
  rcases hslots s sl with ⟨htr_s, henc_s⟩
  have hbw := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
    sideBaseW (sideSlotIdx_lt s sl)
  have hbr := sideSlotBaseR_bounds (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
    sideBaseR (sideSlotIdx_lt s sl)
  exact ⟨htr_s, EncLiveSlot.mono_slice henc_s
    (fun i hlo hhi => hkW i (by omega) (by omega))
    (fun i hlo hhi => hkR i (by omega) (by omega))⟩

theorem encSideStepSeed_of_slices {L_p2 R ℓ M₀ d b : ℕ}
    (coinTbl : ℕ) (seedBase : ℤ)
    (ω_side : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (m : ArithRAMMemory)
    (hs : ∀ (s : Fin L_p2) (r : Fin R) (a : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)) (bi : Fin b),
      let idx := ((((r.val * ℓ + a.val) * M₀ + k.val) * (d + 1) + j.val) * b + bi.val)
      wRead m coinTbl (seedBase + (s.val : ℤ) * (((R * ℓ * M₀ * (d + 1) * b : ℕ) : ℤ)) + (idx : ℤ)) =
        if ω_side s ((r, a, k), j, bi) then 1 else 0) :
    EncSideStepSeed coinTbl seedBase ω_side m := by
  intro s r a k j bi
  have h := hs s r a k j bi
  dsimp only at h
  have hoff : seedBase + ((s.val * seedBitCount R ℓ M₀ d b : ℕ) : ℤ) +
      ((RacerP43.capCoordIdx r a k j * b + bi.val : ℕ) : ℤ) =
      seedBase + (s.val : ℤ) * (((R * ℓ * M₀ * (d + 1) * b : ℕ) : ℤ)) +
        (((((r.val * ℓ + a.val) * M₀ + k.val) * (d + 1) + j.val) * b + bi.val : ℕ) : ℤ) := by
    dsimp only [seedBitCount, seedCoordCount, RacerP43.capCoordIdx]
    push_cast
    ring
  change wRead m coinTbl _ = _
  rw [hoff]
  exact h

/-! ### 2. `dyadicSideInsertHeaderStmt` & `exec_dyadicSideInsertHeaderStmt` -/

def dyadicSideInsertHeaderStmt (scrW tblW tblPt tblR : ℕ)
    (wSideBaseW wSideBaseR wOffPt wHNew wScr : ℤ)
    (n L_p2 d : ℕ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let bR := IntExpr.readHeap scrW (.lit wSideBaseR)
  let bMaxZ : ℤ := ((2 ^ L_p2 : ℕ) : ℤ)
  let wEp := wScr
  let wT := wScr + 1
  let wRem := wScr + 2
  let wDstPt := wScr + 3
  let wS := wScr + 4
  let wH := wScr + 5
  let wSubW := wScr + 20
  .seq (.writeWordHeap scrW (.lit wEp) (.readHeap tblW bW))
  (.seq (.writeWordHeap scrW (.lit wT) (.readHeap tblW (.add bW (.lit 1))))
  (.seq (.writeWordHeap scrW (.lit wRem) (.mod (.readHeap scrW (.lit wHNew)) (.lit (n : ℤ))))
  (.seq (.writeWordHeap tblW (.add bW (.lit 1)) (.add (.readHeap scrW (.lit wT)) (.lit 1)))
  (.seq (.writeWordHeap tblW (.add (.add bW (.lit 2)) (.readHeap scrW (.lit wT)))
          (.readHeap scrW (.lit wHNew)))
  (.seq (.writeWordHeap tblW (.add (.add bW (.lit (2 + bMaxZ))) (.readHeap scrW (.lit wT)))
          (.readHeap scrW (.lit wEp)))
  (.seq (.writeWordHeap tblW (.add (.add bW (.lit (2 + 2 * bMaxZ))) (.readHeap scrW (.lit wRem)))
          (.readHeap scrW (.lit wT)))
  (.seq (.writeWordHeap scrW (.lit wDstPt)
          (.add (.add bR (.lit (d : ℤ))) (.mul (.readHeap scrW (.lit wT)) (.lit (d : ℤ)))))
  (.seq (copyVecToHeapStmt scrW tblPt tblR wSubW wOffPt wDstPt d)
  (.seq (.writeWordHeap scrW (.lit wS) (.lit 0))
        (.writeWordHeap scrW (.lit wH) (.lit 1)))))))))))

theorem zeroRand_dyadicSideInsertHeaderStmt (scrW tblW tblPt tblR : ℕ)
    (wSideBaseW wSideBaseR wOffPt wHNew wScr : ℤ) (n L_p2 d : ℕ) :
    H3a.ZeroRandStmt (dyadicSideInsertHeaderStmt scrW tblW tblPt tblR
      wSideBaseW wSideBaseR wOffPt wHNew wScr n L_p2 d) :=
  of_isZeroRandB rfl

theorem exec_dyadicSideInsertHeaderStmt {d TW BW TR BR scrW scrR tblW tblR tblO tblPt coinTbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wOffPt wHNew wScr rScr
      sideBaseW sideBaseR offO offPt seedBaseOff : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord cap_u ep₀ : ℕ}
    (hn : 1 ≤ n) (hM₀ : 1 ≤ M₀)
    (A B_rat τ_d : ℚ)
    (o pt : EuclideanSpace ℝ (Fin d))
    {U : Finset ℕ} {h_new : ℕ}
    (hmod_disj : ∀ u ∈ U, u % n ≠ h_new % n)
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b)
    (ht_lt : idx.t_ins < 2 ^ L_p2)
    (liveSlots₀ : Fin L_p2 → Fin 2 → LiveSlot R ℓ M₀ d)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneO : tblO ≠ scrR) (hneCoinScr : coinTbl ≠ scrW)
    (hsideW : 0 ≤ sideBaseW ∧ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ (BW : ℤ))
    (hsideR : 0 ≤ sideBaseR ∧ sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ (BR : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ (BW : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSideBaseW)
    (hdisjBR : wSideBaseR < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSideBaseR)
    (hdisjPt : wOffPt < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wOffPt)
    (hdisjH : wHNew < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wHNew)
    (hdisjCoinW : coinTbl ≠ tblW ∨
      seedBaseOff + ((sideSeedStride L_p2 R ℓ M₀ d b : ℕ) : ℤ) ≤ sideBaseW ∨
      sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ seedBaseOff)
    (hdisjPt_R : tblPt ≠ tblR ∨
      offPt + (d : ℤ) ≤ sideEntryPtOff d sideBaseR ∨
      sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ offPt)
    (hdisjO_R : tblO ≠ tblR ∨
      offO + (d : ℤ) ≤ sideEntryPtOff d sideBaseR ∨
      sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ offO)
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hbR : wRead m₀ scrW wSideBaseR = sideBaseR)
    (hoffPt : wRead m₀ scrW wOffPt = offPt)
    (hhNew : wRead m₀ scrW wHNew = (h_new : ℤ))
    (hep0_r : wRead m₀ tblW sideBaseW = (ep₀ : ℤ))
    (ht0_r : wRead m₀ tblW (sideBaseW + 1) = (idx.t_ins : ℤ))
    (hhand0 : ∀ eid < idx.t_ins, wRead m₀ tblW (sideHandleOff sideBaseW eid) = (idx.entryHandle eid : ℤ))
    (hal_le0 : ∀ eid < 2 ^ L_p2, wRead m₀ tblW (sideAliveEpOff L_p2 sideBaseW eid) ≤ (ep₀ : ℤ))
    (hal_iff0 : ∀ eid < idx.t_ins,
      wRead m₀ tblW (sideAliveEpOff L_p2 sideBaseW eid) = (ep₀ : ℤ) ↔ idx.entryAlive eid = true)
    (hact0 : ∀ u ∈ U, wRead m₀ tblW (sideActiveOff L_p2 sideBaseW (u % n)) = (idx.activeEid u : ℤ))
    (hpt0 : ∀ eid < idx.t_ins, ∀ c : Fin d,
      rRead m₀ tblR (sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
        euclideanCoord (idx.entryPt eid) c)
    (hslots0 : ∀ s : Fin L_p2, ∀ sl : Fin 2,
      LiveSlotTrackedH4 cap_u (2 ^ L_p2) idx.t_ins idx.entryAlive (idx.slots s sl) (liveSlots₀ s sl) ∧
      EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx s sl))
        tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx s sl))
        R ℓ M₀ d cap_u (2 ^ L_p2) (liveSlots₀ s sl) m₀)
    (ho : ∀ c : Fin d, rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpt_in : ∀ c : Fin d, rRead m₀ tblPt (offPt + (c.val : ℤ)) = euclideanCoord pt c)
    (hseed₀ : EncSideStepSeed coinTbl seedBaseOff ω_step m₀) :
    let idx' := idx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o pt h_new ω_step
    let hdrLen : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
    let dstPt : ℤ := sideEntryPtOff d sideBaseR + (idx.t_ins : ℤ) * (d : ℤ)
    ∃ mA : ArithRAMMemory,
      DetExec inp
        (dyadicSideInsertHeaderStmt scrW tblW tblPt tblR wSideBaseW wSideBaseR wOffPt wHNew wScr n L_p2 d)
        m₀ mA (270 + 35 * d) ∧
      InFootprint TW BW TR BR mA ∧
      wRead mA scrW wScr = (ep₀ : ℤ) ∧
      wRead mA scrW (wScr + 1) = (idx.t_ins : ℤ) ∧
      wRead mA scrW (wScr + 4) = 0 ∧
      wRead mA scrW (wScr + 5) = 1 ∧
      wRead mA tblW sideBaseW = (ep₀ : ℤ) ∧
      wRead mA tblW (sideBaseW + 1) = ((idx.t_ins + 1 : ℕ) : ℤ) ∧
      (∀ eid < idx.t_ins + 1, wRead mA tblW (sideHandleOff sideBaseW eid) = (idx'.entryHandle eid : ℤ)) ∧
      (∀ eid < 2 ^ L_p2, wRead mA tblW (sideAliveEpOff L_p2 sideBaseW eid) ≤ (ep₀ : ℤ)) ∧
      (∀ eid < idx.t_ins + 1,
        wRead mA tblW (sideAliveEpOff L_p2 sideBaseW eid) = (ep₀ : ℤ) ↔
          (Function.update idx.entryAlive idx.t_ins true) eid = true) ∧
      (∀ u ∈ Insert.insert h_new U,
        wRead mA tblW (sideActiveOff L_p2 sideBaseW (u % n)) = (idx'.activeEid u : ℤ)) ∧
      (∀ eid < idx.t_ins + 1, ∀ c : Fin d,
        rRead mA tblR (sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
          euclideanCoord (idx'.entryPt eid) c) ∧
      (∀ c : Fin d, rRead mA tblO (offO + (c.val : ℤ)) = euclideanCoord o c) ∧
      EncSideStepSeed coinTbl seedBaseOff ω_step mA ∧
      (∀ s : Fin L_p2, ∀ sl : Fin 2,
        LiveSlotTrackedH4 cap_u (2 ^ L_p2) (idx.t_ins + 1) (Function.update idx.entryAlive idx.t_ins true)
          (idx.slots s sl) (liveSlots₀ s sl) ∧
        EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx s sl))
          tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx s sl))
          R ℓ M₀ d cap_u (2 ^ L_p2) (liveSlots₀ s sl) mA) ∧
      (∀ w, (w < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ w) →
        wRead mA scrW w = wRead m₀ scrW w) ∧
      (∀ r, (r < rScr ∨ rScr + dyadicSideInsertRStride d ≤ r) →
        rRead mA scrR r = rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m₀ mA := by
  classical
  intro idx' hdrLen dstPt
  have hw_ge := dyadicSideInsertWStride_ge_44 ℓ M₀ cap_u
  have hhdr_end := dyadicSideWStride_ge_hdrEnd n L_p2 R ℓ M₀ cap_u
  have hent_end := dyadicSideRStride_ge_entryEnd L_p2 R ℓ M₀ d
  let t := idx.t_ins
  let rem := h_new % n
  have hrem_lt : rem < n := Nat.mod_lt h_new hn
  have htZ : (t : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast ht_lt
  have hremZ : (rem : ℤ) < (n : ℤ) := by exact_mod_cast hrem_lt
  have hdst_lo : sideBaseR + (d : ℤ) ≤ dstPt := by
    dsimp only [dstPt, sideEntryPtOff]
    have h0 : (0 : ℤ) ≤ (idx.t_ins : ℤ) * (d : ℤ) := mul_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _)
    linarith
  have hdst_hi : dstPt + (d : ℤ) ≤ sideBaseR + (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ) := by
    have hmul : (idx.t_ins + 1) * d ≤ (2 ^ L_p2) * d := Nat.mul_le_mul_right d ht_lt
    have hmulZ : (((idx.t_ins + 1) * d : ℕ) : ℤ) ≤ (((2 ^ L_p2) * d : ℕ) : ℤ) := by exact_mod_cast hmul
    have hlin : (idx.t_ins : ℤ) * (d : ℤ) + (d : ℤ) = (((idx.t_ins + 1) * d : ℕ) : ℤ) := by push_cast; ring
    dsimp only [dstPt, sideEntryPtOff]; linarith
  let m1 := wWrite m₀ scrW wScr (ep₀ : ℤ)
  let m2 := wWrite m1 scrW (wScr + 1) (t : ℤ)
  let m3 := wWrite m2 scrW (wScr + 2) (rem : ℤ)
  let m4 := wWrite m3 tblW (sideBaseW + 1) ((t + 1 : ℕ) : ℤ)
  let m5 := wWrite m4 tblW (sideHandleOff sideBaseW t) (h_new : ℤ)
  let m6 := wWrite m5 tblW (sideAliveEpOff L_p2 sideBaseW t) (ep₀ : ℤ)
  let m7 := wWrite m6 tblW (sideActiveOff L_p2 sideBaseW rem) (t : ℤ)
  let m8 := wWrite m7 scrW (wScr + 3) dstPt
  have hbW_out : wSideBaseW < wScr ∨ wScr + 4 ≤ wSideBaseW := by
    rcases hdisjBW with h | h; exact Or.inl h; exact Or.inr (by omega)
  have hbR_out : wSideBaseR < wScr ∨ wScr + 4 ≤ wSideBaseR := by
    rcases hdisjBR with h | h; exact Or.inl h; exact Or.inr (by omega)
  have hhN_out : wHNew < wScr ∨ wScr + 4 ≤ wHNew := by
    rcases hdisjH with h | h; exact Or.inl h; exact Or.inr (by omega)
  have hkW_scr8 : ∀ w, (w < wScr ∨ wScr + 4 ≤ w) → wRead m8 scrW w = wRead m₀ scrW w := by
    intro w hw
    rw [wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
        wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
        wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
        wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
        wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
        wNe _ _ (Or.inr (by rcases hw with h | h <;> omega))]
  let bWE := IntExpr.readHeap scrW (.lit wSideBaseW)
  let bRE := IntExpr.readHeap scrW (.lit wSideBaseR)
  let bMaxZ : ℤ := ((2 ^ L_p2 : ℕ) : ℤ)
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.readHeap tblW bWE)) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wScr) _ rfl
      (by change wRead m₀ tblW (wRead m₀ scrW wSideBaseW) = (ep₀ : ℤ); rw [hbW, hep0_r])
      (by dsimp [bWE, intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1)) (.readHeap tblW (.add bWE (.lit 1)))) m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 1)) _ rfl
      (by change wRead m1 tblW (wRead m1 scrW wSideBaseW + 1) = (t : ℤ)
          rw [wNe _ _ (Or.inl hneW), wNe _ _ (Or.inr (by rcases hbW_out with h | h <;> omega)), hbW, ht0_r])
      (by dsimp [bWE, intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2))
      (.mod (.readHeap scrW (.lit wHNew)) (.lit (n : ℤ)))) m2 m3 20 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wScr + 2)) _ rfl
      (by change wRead m2 scrW wHNew % (n : ℤ) = (rem : ℤ)
          rw [wNe _ _ (Or.inr (by rcases hhN_out with h | h <;> omega)),
              wNe _ _ (Or.inr (by rcases hhN_out with h | h <;> omega)), hhNew]
          exact (Int.natCast_emod h_new n).symm)
      (by dsimp [intExprOps]; omega)
  have hbW3 : wRead m3 scrW wSideBaseW = sideBaseW := by
    rw [wNe _ _ (Or.inr (by rcases hbW_out with h | h <;> omega)),
        wNe _ _ (Or.inr (by rcases hbW_out with h | h <;> omega)),
        wNe _ _ (Or.inr (by rcases hbW_out with h | h <;> omega)), hbW]
  have ht3 : wRead m3 scrW (wScr + 1) = (t : ℤ) :=
    (wNe _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _)
  have hep3 : wRead m3 scrW wScr = (ep₀ : ℤ) :=
    (wNe _ _ (Or.inr (by omega))).trans ((wNe _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _))
  have hrem3 : wRead m3 scrW (wScr + 2) = (rem : ℤ) := wRead_wWrite_self _ _ _ _
  have hhN3 : wRead m3 scrW wHNew = (h_new : ℤ) := by
    rw [wNe _ _ (Or.inr (by rcases hhN_out with h | h <;> omega)),
        wNe _ _ (Or.inr (by rcases hhN_out with h | h <;> omega)),
        wNe _ _ (Or.inr (by rcases hhN_out with h | h <;> omega)), hhNew]
  have hd4 : DetExec inp (.writeWordHeap tblW (.add bWE (.lit 1))
      (.add (.readHeap scrW (.lit (wScr + 1))) (.lit 1))) m3 m4 25 :=
    DetExecAt.writeWordHeap 0 inp m3 tblW _ _
      (by change wRead m3 scrW wSideBaseW + 1 = sideBaseW + 1; rw [hbW3])
      (by change wRead m3 scrW (wScr + 1) + 1 = ((t + 1 : ℕ) : ℤ); rw [ht3]; push_cast; ring)
      (by dsimp [bWE, intExprOps]; omega)
  have hd5 : DetExec inp (.writeWordHeap tblW (.add (.add bWE (.lit 2)) (.readHeap scrW (.lit (wScr + 1))))
      (.readHeap scrW (.lit wHNew))) m4 m5 30 :=
    DetExecAt.writeWordHeap 0 inp m4 tblW _ _
      (by change (wRead m4 scrW wSideBaseW + 2) + wRead m4 scrW (wScr + 1) = sideHandleOff sideBaseW t
          rw [wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm), hbW3, ht3]
          unfold sideHandleOff; ring)
      (by change wRead m4 scrW wHNew = (h_new : ℤ); rw [wNe _ _ (Or.inl hneW.symm), hhN3])
      (by dsimp [bWE, intExprOps]; omega)
  have hd6 : DetExec inp (.writeWordHeap tblW (.add (.add bWE (.lit (2 + bMaxZ))) (.readHeap scrW (.lit (wScr + 1))))
      (.readHeap scrW (.lit wScr))) m5 m6 30 :=
    DetExecAt.writeWordHeap 0 inp m5 tblW _ _
      (by change (wRead m5 scrW wSideBaseW + (2 + bMaxZ)) + wRead m5 scrW (wScr + 1) = sideAliveEpOff L_p2 sideBaseW t
          rw [wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
              wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm), hbW3, ht3]
          unfold sideAliveEpOff; dsimp only [bMaxZ]; ring)
      (by change wRead m5 scrW wScr = (ep₀ : ℤ)
          rw [wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm), hep3])
      (by dsimp [bWE, intExprOps]; omega)
  have hd7 : DetExec inp (.writeWordHeap tblW (.add (.add bWE (.lit (2 + 2 * bMaxZ))) (.readHeap scrW (.lit (wScr + 2))))
      (.readHeap scrW (.lit (wScr + 1)))) m6 m7 30 :=
    DetExecAt.writeWordHeap 0 inp m6 tblW _ _
      (by change (wRead m6 scrW wSideBaseW + (2 + 2 * bMaxZ)) + wRead m6 scrW (wScr + 2) = sideActiveOff L_p2 sideBaseW rem
          rw [wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
              wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
              wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm), hbW3, hrem3]
          unfold sideActiveOff; dsimp only [bMaxZ]; ring)
      (by change wRead m6 scrW (wScr + 1) = (t : ℤ)
          rw [wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
              wNe _ _ (Or.inl hneW.symm), ht3])
      (by dsimp [bWE, intExprOps]; omega)
  have hd8 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 3))
      (.add (.add bRE (.lit (d : ℤ))) (.mul (.readHeap scrW (.lit (wScr + 1))) (.lit (d : ℤ))))) m7 m8 30 :=
    DetExecAt.writeWordHeap 0 inp m7 scrW (.lit (wScr + 3)) _ rfl
      (by change (wRead m7 scrW wSideBaseR + (d : ℤ)) + wRead m7 scrW (wScr + 1) * (d : ℤ) = dstPt
          have hbR7 : wRead m7 scrW wSideBaseR = sideBaseR := by
            rw [wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
                wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
                wNe _ _ (Or.inr (by rcases hbR_out with h | h <;> omega)),
                wNe _ _ (Or.inr (by rcases hbR_out with h | h <;> omega)),
                wNe _ _ (Or.inr (by rcases hbR_out with h | h <;> omega)), hbR]
          have ht7 : wRead m7 scrW (wScr + 1) = (t : ℤ) := by
            rw [wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
                wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm), ht3]
          rw [hbR7, ht7]; dsimp only [dstPt, sideEntryPtOff, t])
      (by dsimp [bRE, intExprOps]; omega)
  have hfp8 : InFootprint TW BW TR BR m8 := by
    have hhdr_le : sideBaseW + (2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)) ≤ (BW : ℤ) := by
      have := hhdr_end; omega
    have h1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)
    have h2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite h1 hscrW (by omega) (by omega)
    have h3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite h2 hscrW (by omega) (by omega)
    have h4 : InFootprint TW BW TR BR m4 := InFootprint.wWrite h3 htblW (by omega) (by omega)
    have h5 : InFootprint TW BW TR BR m5 := InFootprint.wWrite h4 htblW
      (by unfold sideHandleOff; omega) (by unfold sideHandleOff; omega)
    have h6 : InFootprint TW BW TR BR m6 := InFootprint.wWrite h5 htblW
      (by unfold sideAliveEpOff; omega) (by unfold sideAliveEpOff; omega)
    have h7 : InFootprint TW BW TR BR m7 := InFootprint.wWrite h6 htblW
      (by unfold sideActiveOff; omega) (by unfold sideActiveOff; omega)
    exact InFootprint.wWrite h7 hscrW (by omega) (by omega)
  have hfr08 : RadFrameOutside scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m₀ m8 :=
    (((((((rws scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m₀ _ _).trans
      (rws scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m1 _ _)).trans
      (rws scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m2 _ _)).trans
      (rfo_wWrite_in scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m3 _
        (by omega) (by dsimp only [hdrLen]; omega))).trans
      (rfo_wWrite_in scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m4 _
        (by unfold sideHandleOff; omega) (by unfold sideHandleOff; dsimp only [hdrLen]; omega))).trans
      (rfo_wWrite_in scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m5 _
        (by unfold sideAliveEpOff; omega) (by unfold sideAliveEpOff; dsimp only [hdrLen]; omega))).trans
      (rfo_wWrite_in scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m6 _
        (by unfold sideActiveOff; omega) (by unfold sideActiveOff; dsimp only [hdrLen]; omega))).trans
      (rws scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m7 _ _)
  have hdisjSrcDst : tblPt ≠ tblR ∨ offPt + (d : ℤ) ≤ dstPt ∨ dstPt + (d : ℤ) ≤ offPt := by
    rcases hdisjPt_R with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by unfold sideEntryPtOff at h1; omega))
    · exact Or.inr (Or.inr (by omega))
  obtain ⟨m9, hd9, hfp9, hcopied9, hkW89, hkR89, hfr89⟩ :=
    exec_copyVecToHeapStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
      inp (wScr + 20) wOffPt (wScr + 3) offPt dstPt sideBaseW d
      hfp8 hscrW htblR hneR ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by rcases hdisjPt with h | h <;> omega) (by omega) hdisjSrcDst
      ((hkW_scr8 _ (by rcases hdisjPt with h | h; exact Or.inl h; exact Or.inr (by omega))).trans hoffPt)
      (wRead_wWrite_self _ _ _ _)
  let m10 := wWrite m9 scrW (wScr + 4) 0
  let mA := wWrite m10 scrW (wScr + 5) 1
  have hd10 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 4)) (.lit 0)) m9 m10 10 :=
    DetExecAt.writeWordHeap 0 inp m9 scrW (.lit (wScr + 4)) (.lit 0) rfl rfl (by dsimp [intExprOps]; omega)
  have hd11 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 5)) (.lit 1)) m10 mA 10 :=
    DetExecAt.writeWordHeap 0 inp m10 scrW (.lit (wScr + 5)) (.lit 1) rfl rfl (by dsimp [intExprOps]; omega)
  have hfpA : InFootprint TW BW TR BR mA :=
    InFootprint.wWrite (InFootprint.wWrite hfp9 hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hfr0A : RadFrameOutside scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m₀ mA :=
    ((hfr08.trans (hfr89.mono_range (Or.inl rfl) (Or.inr ⟨le_rfl, le_rfl⟩))).trans
      (rws scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m9 _ _)).trans
      (rws scrW scrR tblW sideBaseW hdrLen tblR dstPt (d : ℤ) m10 _ _)
  have hmA_tblW : ∀ i, wRead mA tblW i = wRead m7 tblW i := by
    intro i
    rw [wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW),
        hfr89.1 tblW i hneW (Or.inr (by rcases lt_or_ge i sideBaseW with h | h; exact Or.inl h; exact Or.inr (by omega))),
        wNe _ _ (Or.inl hneW)]
  refine ⟨mA,
    (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq (hd8.seq (hd9.seq (hd10.seq hd11)))))))))).mono_cost (by omega),
    hfpA,
    by rw [wNe _ _ (Or.inr (by omega)), wNe _ _ (Or.inr (by omega)), hkW89 _ (by omega),
           wNe _ _ (Or.inr (by omega)), wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
           wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm), hep3],
    by rw [wNe _ _ (Or.inr (by omega)), wNe _ _ (Or.inr (by omega)), hkW89 _ (by omega),
           wNe _ _ (Or.inr (by omega)), wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm),
           wNe _ _ (Or.inl hneW.symm), wNe _ _ (Or.inl hneW.symm), ht3],
    (wNe _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _),
    wRead_wWrite_self _ _ _ _,
    by rw [hmA_tblW, wNe _ _ (Or.inr (by unfold sideActiveOff; omega)),
           wNe _ _ (Or.inr (by unfold sideAliveEpOff; omega)),
           wNe _ _ (Or.inr (by unfold sideHandleOff; omega)),
           wNe _ _ (Or.inr (by omega)),
           wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW), hep0_r],
    by rw [hmA_tblW, wNe _ _ (Or.inr (by unfold sideActiveOff; omega)),
           wNe _ _ (Or.inr (by unfold sideAliveEpOff; omega)),
           wNe _ _ (Or.inr (by unfold sideHandleOff; omega)), wRead_wWrite_self],
    fun eid heid => ?_,
    fun eid heid => ?_,
    fun eid heid => ?_,
    fun u hu => ?_,
    fun eid heid c => ?_,
    fun c => ?_,
    ?_,
    fun s sl => ?_,
    fun w hw => ?_,
    fun r _ => ?_,
    hfr0A⟩
  · have heidZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (lt_of_lt_of_le heid ht_lt)
    rw [hmA_tblW, wNe _ _ (Or.inr (by unfold sideHandleOff sideActiveOff; omega)),
        wNe _ _ (Or.inr (by unfold sideHandleOff sideAliveEpOff; omega))]
    dsimp only [idx', H4b.DyadicSideIndex.insertHandle]
    by_cases heq : eid = t
    · subst heq; rw [wRead_wWrite_self, Function.update_self]
    · rw [wNe _ _ (Or.inr (by unfold sideHandleOff; omega)),
          wNe _ _ (Or.inr (by unfold sideHandleOff; omega)),
          wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW),
          Function.update_of_ne heq]
      exact hhand0 eid (by omega)
  · have heidZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast heid
    rw [hmA_tblW, wNe _ _ (Or.inr (by unfold sideAliveEpOff sideActiveOff; omega))]
    by_cases heq : eid = t
    · subst heq; rw [wRead_wWrite_self]
    · rw [wNe _ _ (Or.inr (by unfold sideAliveEpOff; omega)),
          wNe _ _ (Or.inr (by unfold sideAliveEpOff sideHandleOff; omega)),
          wNe _ _ (Or.inr (by unfold sideAliveEpOff; omega)),
          wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW)]
      exact hal_le0 eid heid
  · have heidZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (lt_of_lt_of_le heid ht_lt)
    rw [hmA_tblW, wNe _ _ (Or.inr (by unfold sideAliveEpOff sideActiveOff; omega))]
    by_cases heq : eid = t
    · subst heq; rw [wRead_wWrite_self, Function.update_self]; simp
    · rw [wNe _ _ (Or.inr (by unfold sideAliveEpOff; omega)),
          wNe _ _ (Or.inr (by unfold sideAliveEpOff sideHandleOff; omega)),
          wNe _ _ (Or.inr (by unfold sideAliveEpOff; omega)),
          wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW),
          Function.update_of_ne heq]
      exact hal_iff0 eid (by omega)
  · rw [hmA_tblW]
    dsimp only [idx', H4b.DyadicSideIndex.insertHandle]
    rcases Finset.mem_insert.mp hu with rfl | huU
    · rw [wRead_wWrite_self, Function.update_self]
    · have hmod_ne : u % n ≠ rem := hmod_disj u huU
      have hu_ne : u ≠ h_new := fun heq => hmod_ne (by subst heq; rfl)
      have humZ : (u % n : ℤ) < (n : ℤ) := by exact_mod_cast (Nat.mod_lt u hn)
      rw [wNe _ _ (Or.inr (by unfold sideActiveOff; omega)),
          wNe _ _ (Or.inr (by unfold sideActiveOff sideAliveEpOff; omega)),
          wNe _ _ (Or.inr (by unfold sideActiveOff sideHandleOff; omega)),
          wNe _ _ (Or.inr (by unfold sideActiveOff; omega)),
          wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW), wNe _ _ (Or.inl hneW),
          Function.update_of_ne hu_ne]
      exact hact0 u huU
  · rw [rRead_wWrite, rRead_wWrite]
    dsimp only [idx', H4b.DyadicSideIndex.insertHandle]
    by_cases heq : eid = t
    · subst heq
      rw [Function.update_self]
      have h1 := hcopied9 c.val c.isLt
      have hr8 : rRead m8 tblPt (offPt + (c.val : ℤ)) = rRead m₀ tblPt (offPt + (c.val : ℤ)) := by
        simp only [m8, m7, m6, m5, m4, m3, m2, m1, rRead_wWrite]
      have haddr : dstPt + (c.val : ℤ) = sideEntryPtOff d sideBaseR + (t : ℤ) * (d : ℤ) + (c.val : ℤ) := rfl
      rw [← haddr, h1, hr8, hpt_in c]
    · rw [Function.update_of_ne heq]
      have heid_lt : eid < t := by omega
      have hlt_dst : sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ) < dstPt := by
        have hcZ : (c.val : ℤ) < (d : ℤ) := by exact_mod_cast c.isLt
        have hm1 : (eid + 1) * d ≤ idx.t_ins * d := Nat.mul_le_mul_right d heid_lt
        have hmZ : (((eid + 1) * d : ℕ) : ℤ) ≤ ((idx.t_ins * d : ℕ) : ℤ) := by exact_mod_cast hm1
        have hl1 : (eid : ℤ) * (d : ℤ) + (d : ℤ) = (((eid + 1) * d : ℕ) : ℤ) := by push_cast; ring
        have hl2 : (idx.t_ins : ℤ) * (d : ℤ) = ((idx.t_ins * d : ℕ) : ℤ) := by push_cast; ring
        dsimp only [dstPt]; linarith
      have hr9 := hfr89.2 tblR _ hneR (Or.inr (Or.inl hlt_dst))
      have hr8 : rRead m8 tblR (sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
          rRead m₀ tblR (sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) := by
        simp only [m8, m7, m6, m5, m4, m3, m2, m1, rRead_wWrite]
      rw [hr9, hr8, hpt0 eid heid_lt c]
  · have hc := c.isLt
    refine (hfr0A.2 tblO _ hneO ?_).trans (ho c)
    rcases hdisjO_R with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by unfold sideEntryPtOff at h1; omega))
    · exact Or.inr (Or.inr (by omega))
  · refine hseed₀.mono_frame hfr0A hneCoinScr ?_
    rcases hdisjCoinW with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl h1)
    · exact Or.inr (Or.inr (by omega))
  · rcases hslots0 s sl with ⟨htr_s, henc_s⟩
    have hbw := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
      sideBaseW (sideSlotIdx_lt s sl)
    have hbr := sideSlotBaseR_bounds (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
      sideBaseR (sideSlotIdx_lt s sl)
    exact ⟨LiveSlotTrackedH4.of_advance_t_ins htr_s,
      henc_s.mono_frame hfr0A hneW hneR
        (Or.inr (Or.inr (by dsimp only [hdrLen]; omega)))
        (Or.inr (Or.inr (by omega)))⟩
  · rw [wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
        wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
        hkW89 w (by rcases hw with h | h <;> omega),
        hkW_scr8 w (by rcases hw with h | h; exact Or.inl h; exact Or.inr (by omega))]
  · rw [rRead_wWrite, rRead_wWrite, hkR89 r]
    simp only [m8, m7, m6, m5, m4, m3, m2, m1, rRead_wWrite]

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
