import UL.Proof.clm_9_1_explicit_tradeoff.CG19_LayoutA
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-- `O(1)` sparse-set insertion of `x < N_cap` when `x ∉ arr`. -/
def sparseInsertFreshStmt (lenIdxReg elemOffReg posOffReg xReg : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 56) (.readHeap engScrTbl (.lit xReg)))
  (.seq (.writeWordHeap engScrTbl (.lit 57) (.readHeap engScrTbl (.lit lenIdxReg)))
  (.seq (.writeWordHeap engScrTbl (.lit 58) (.readHeap engMetaTbl (.readHeap engScrTbl (.lit 57))))
  (.seq (.writeWordHeap engArrTbl
          (.add (.readHeap engScrTbl (.lit elemOffReg)) (.readHeap engScrTbl (.lit 58)))
          (.readHeap engScrTbl (.lit 56)))
  (.seq (.writeWordHeap engArrTbl
          (.add (.readHeap engScrTbl (.lit posOffReg)) (.readHeap engScrTbl (.lit 56)))
          (.readHeap engScrTbl (.lit 58)))
        (.writeWordHeap engMetaTbl (.readHeap engScrTbl (.lit 57))
          (.add (.readHeap engScrTbl (.lit 58)) (.lit 1)))))))

theorem zeroRand_sparseInsertFreshStmt (lR eR pR xR : ℤ) :
    ZeroRandStmt (sparseInsertFreshStmt lR eR pR xR) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))

theorem exec_sparseInsertFreshStmt {d TW BW TR BR N_cap : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} {arr : List ℕ}
    {lenIdx elemOff posOff : ℤ} {x : ℕ}
    (lR eR pR xR : ℤ)
    (hTW : 9 ≤ TW) (hBW_scr : 64 ≤ BW)
    (hlR : lR < 56) (heR : eR < 56) (hpR : pR < 56) (hxR : xR < 56)
    (hlen0 : 0 ≤ lenIdx) (hlenB : lenIdx < (BW : ℤ))
    (he0 : 0 ≤ elemOff) (heB : elemOff + (N_cap : ℤ) ≤ (BW : ℤ))
    (hp0 : 0 ≤ posOff) (hpB : posOff + (N_cap : ℤ) ≤ (BW : ℤ))
    (hdisj_ep : elemOff + (N_cap : ℤ) ≤ posOff ∨ posOff + (N_cap : ℤ) ≤ elemOff)
    (hxN : x < N_cap) (hx_not : x ∉ arr)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (henc : EncSparseSet N_cap lenIdx elemOff posOff arr m₀)
    (hread_l : wRead m₀ engScrTbl lR = lenIdx)
    (hread_e : wRead m₀ engScrTbl eR = elemOff)
    (hread_p : wRead m₀ engScrTbl pR = posOff)
    (hread_x : wRead m₀ engScrTbl xR = (x : ℤ)) :
    ExecDet TW BW TR BR inp (sparseInsertFreshStmt lR eR pR xR) m₀
      (fun m₁ =>
        EncSparseSet N_cap lenIdx elemOff posOff (denseInsert x arr) m₁ ∧
        (∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ lenIdx → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, i ≠ elemOff + (arr.length : ℤ) → i ≠ posOff + (x : ℤ) →
          wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, i < 56 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      100 := by
  have hlen_lt_N : arr.length < N_cap := by
    have hnd' : (arr ++ [x]).Nodup :=
      (denseInsert_spec henc.1 (fun hm => hx_not (List.mem_toFinset.mp hm))).1
    have hsub : (arr ++ [x]).toFinset ⊆ Finset.range N_cap := by
      intro y hy
      rcases List.mem_append.mp (List.mem_toFinset.mp hy) with hya | hyx
      · exact Finset.mem_range.mpr (henc.2.1 y hya)
      · rw [List.mem_singleton.mp hyx]; exact Finset.mem_range.mpr hxN
    have hc : (arr ++ [x]).toFinset.card ≤ N_cap := (Finset.card_le_card hsub).trans (by simp)
    rw [List.toFinset_card_of_nodup hnd', List.length_append, List.length_singleton] at hc
    omega
  unfold sparseInsertFreshStmt
  refine ExecDet.seq' 88
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 56) (.readHeap engScrTbl (.lit xR)) 56 (x : ℤ)
      hfp₀ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega) rfl (by simp [evalIntExpr]; exact hread_x)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro m₁ hm₁ hfp₁; subst hm₁
  refine ExecDet.seq' 76
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 57) (.readHeap engScrTbl (.lit lR)) 57 lenIdx
      hfp₁ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change wRead _ engScrTbl lR = lenIdx
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hread_l)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro m₂ hm₂ hfp₂; subst hm₂
  refine ExecDet.seq' 64
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 58)
      (.readHeap engMetaTbl (.readHeap engScrTbl (.lit 57))) 58 (arr.length : ℤ)
      hfp₂ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change wRead _ engMetaTbl (wRead _ engScrTbl 57) = _
          rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
          exact henc.2.2.1)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro m₃ hm₃ hfp₃; subst hm₃
  set mA := H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engScrTbl 56 (x : ℤ)) engScrTbl 57 lenIdx)
              engScrTbl 58 (arr.length : ℤ)
  have hxA : wRead mA engScrTbl 56 = (x : ℤ) := by
    simp only [mA]; (iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]); rw [wRead_wWrite_self]
  have hlA : wRead mA engScrTbl 57 = lenIdx := by
    simp only [mA]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hLA : wRead mA engScrTbl 58 = (arr.length : ℤ) := wRead_wWrite_self _ _ _ _
  have heA : wRead mA engScrTbl eR = elemOff := by
    simp only [mA]; (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]); exact hread_e
  have hpA : wRead mA engScrTbl pR = posOff := by
    simp only [mA]; (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]); exact hread_p
  refine ExecDet.seq' 50
    (ExecDet.wWrite (C := 12) inp engArrTbl
      (.add (.readHeap engScrTbl (.lit eR)) (.readHeap engScrTbl (.lit 58)))
      (.readHeap engScrTbl (.lit 56)) (elemOff + (arr.length : ℤ)) (x : ℤ)
      hfp₃ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega)
      (by simp only [evalIntExpr]; change wRead mA engScrTbl eR + wRead mA engScrTbl 58 = _
          rw [heA, hLA])
      (by simp only [evalIntExpr]; exact hxA)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro m₄ hm₄ hfp₄; subst hm₄
  set mB := H3a.wWrite mA engArrTbl (elemOff + (arr.length : ℤ)) (x : ℤ)
  refine ExecDet.seq' 18
    (ExecDet.wWrite (C := 12) inp engArrTbl
      (.add (.readHeap engScrTbl (.lit pR)) (.readHeap engScrTbl (.lit 56)))
      (.readHeap engScrTbl (.lit 58)) (posOff + (x : ℤ)) (arr.length : ℤ)
      hfp₄ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega)
      (by simp only [evalIntExpr]; change wRead mB engScrTbl pR + wRead mB engScrTbl 56 = _
          dsimp only [mB]
          rw [wRead_wWrite_of_ne mA _ (Or.inl (by decide)),
              wRead_wWrite_of_ne mA _ (Or.inl (by decide)), hpA, hxA])
      (by simp only [evalIntExpr]; change wRead mB engScrTbl 58 = _
          dsimp only [mB]
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hLA])
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro m₅ hm₅ hfp₅; subst hm₅
  set mC := H3a.wWrite mB engArrTbl (posOff + (x : ℤ)) (arr.length : ℤ)
  refine ExecDet.wWrite inp engMetaTbl (.readHeap engScrTbl (.lit 57))
    (.add (.readHeap engScrTbl (.lit 58)) (.lit 1)) lenIdx ((arr.length : ℤ) + 1)
    hfp₅ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) hlen0 hlenB
    (by simp only [evalIntExpr]
        change wRead mC engScrTbl 57 = lenIdx
        dsimp only [mC, mB]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hlA])
    (by simp only [evalIntExpr]
        change wRead mC engScrTbl 58 + 1 = _
        dsimp only [mC, mB]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hLA])
    (by simp [intExprOps]) ?_
  set mF := H3a.wWrite mC engMetaTbl lenIdx ((arr.length : ℤ) + 1)
  have hnd_ins : (denseInsert x arr).Nodup :=
    (denseInsert_spec henc.1 (fun hm => hx_not (List.mem_toFinset.mp hm))).1
  refine ⟨⟨hnd_ins, ?_, ?_, ?_⟩, ?_, ?_, ?_, ?_, ?_⟩
  · intro y hy
    rcases List.mem_append.mp hy with hya | hyx
    · exact henc.2.1 y hya
    · rw [List.mem_singleton.mp hyx]; exact hxN
  · simp only [mF, denseInsert, List.length_append, List.length_singleton]
    rw [wRead_wWrite_self]; push_cast; ring
  · intro i hi
    have hi' : i < arr.length + 1 := by
      simpa only [denseInsert, List.length_append, List.length_singleton] using hi
    rcases Nat.lt_succ_iff_lt_or_eq.mp hi' with hlt | rfl
    · have hget : (denseInsert x arr)[i]'hi = arr[i]'hlt := List.getElem_append_left hlt
      rw [hget]
      have hne_ax : arr[i]'hlt ≠ x := fun heq => hx_not (heq ▸ List.getElem_mem hlt)
      refine ⟨?_, ?_⟩
      · simp only [mF, mC, mB, mA]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        exact (henc.2.2.2 i hlt).1
      · simp only [mF, mC, mB, mA]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by intro heq; apply hne_ax; omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by
              have := henc.2.1 (arr[i]'hlt) (List.getElem_mem hlt); omega))]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        exact (henc.2.2.2 i hlt).2
    · have hget : (denseInsert x arr)[arr.length]'hi = x := by
        simp [denseInsert]
      rw [hget]
      refine ⟨?_, ?_⟩
      · simp only [mF, mC, mB]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
      · simp only [mF, mC]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]
  · intro t ht1 ht2 ht3 i
    simp only [mF, mC, mB, mA]
    rw [wRead_wWrite_of_ne _ _ (Or.inl ht1),
        wRead_wWrite_of_ne _ _ (Or.inl ht2),
        wRead_wWrite_of_ne _ _ (Or.inl ht2)]
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht3)]
  · intro i hi
    simp only [mF, mC, mB, mA]
    rw [wRead_wWrite_of_ne _ _ (Or.inr hi)]
    iterate 5 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
  · intro i hi1 hi2
    simp only [mF, mC, mB, mA]
    rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr hi2),
        wRead_wWrite_of_ne _ _ (Or.inr hi1)]
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
  · intro i hi
    simp only [mF, mC, mB, mA]
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  · intro t i
    simp [mF, mC, mB, mA, rRead_wWrite]

/-- `O(1)` sparse-set deletion matching `H4c1.denseDelete` (using scratch `55, 56, 57, 58, 59`). -/
def sparseDeleteStmt (N_cap : ℕ) (lenIdxReg elemOffReg posOffReg xReg : ℤ) : ArithRAMStmt :=
  .seq (sparseContainsStmt N_cap lenIdxReg elemOffReg posOffReg xReg 55)
    (.ite (.intEq (.readHeap engScrTbl (.lit 55)) (.lit 1))
      (.seq (.writeWordHeap engScrTbl (.lit 56) (.readHeap engScrTbl (.lit xReg)))
      (.seq (.writeWordHeap engScrTbl (.lit 57)
              (.readHeap engArrTbl
                (.add (.readHeap engScrTbl (.lit posOffReg)) (.readHeap engScrTbl (.lit 56)))))
      (.seq (.writeWordHeap engScrTbl (.lit 58)
              (.sub (.readHeap engMetaTbl (.readHeap engScrTbl (.lit lenIdxReg))) (.lit 1)))
        (.ite (.intEq (.readHeap engScrTbl (.lit 57)) (.readHeap engScrTbl (.lit 58)))
          (.writeWordHeap engMetaTbl (.readHeap engScrTbl (.lit lenIdxReg))
            (.readHeap engScrTbl (.lit 58)))
          (.seq (.writeWordHeap engScrTbl (.lit 59)
                  (.readHeap engArrTbl
                    (.add (.readHeap engScrTbl (.lit elemOffReg)) (.readHeap engScrTbl (.lit 58)))))
          (.seq (.writeWordHeap engArrTbl
                  (.add (.readHeap engScrTbl (.lit elemOffReg)) (.readHeap engScrTbl (.lit 57)))
                  (.readHeap engScrTbl (.lit 59)))
          (.seq (.writeWordHeap engArrTbl
                  (.add (.readHeap engScrTbl (.lit posOffReg)) (.readHeap engScrTbl (.lit 59)))
                  (.readHeap engScrTbl (.lit 57)))
                (.writeWordHeap engMetaTbl (.readHeap engScrTbl (.lit lenIdxReg))
                  (.readHeap engScrTbl (.lit 58))))))))))
      .skip)

theorem zeroRand_sparseDeleteStmt (N_cap : ℕ) (lR eR pR xR : ℤ) :
    ZeroRandStmt (sparseDeleteStmt N_cap lR eR pR xR) :=
  .seq (zeroRand_sparseContainsStmt N_cap lR eR pR xR 55)
    (.ite (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.ite (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
          (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))))) .skip)

theorem exec_sparseDeleteStmt {d TW BW TR BR N_cap : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} {arr : List ℕ}
    {lenIdx elemOff posOff : ℤ} {x : ℕ}
    (lR eR pR xR : ℤ)
    (hTW : 9 ≤ TW) (hBW_scr : 64 ≤ BW)
    (hlR : lR < 55) (heR : eR < 55) (hpR : pR < 55) (hxR : xR < 55)
    (hlen0 : 0 ≤ lenIdx) (hlenB : lenIdx < (BW : ℤ))
    (he0 : 0 ≤ elemOff) (heB : elemOff + (N_cap : ℤ) ≤ (BW : ℤ))
    (hp0 : 0 ≤ posOff) (hpB : posOff + (N_cap : ℤ) ≤ (BW : ℤ))
    (hdisj_ep : elemOff + (N_cap : ℤ) ≤ posOff ∨ posOff + (N_cap : ℤ) ≤ elemOff)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (henc : EncSparseSet N_cap lenIdx elemOff posOff arr m₀)
    (hread_l : wRead m₀ engScrTbl lR = lenIdx)
    (hread_e : wRead m₀ engScrTbl eR = elemOff)
    (hread_p : wRead m₀ engScrTbl pR = posOff)
    (hread_x : wRead m₀ engScrTbl xR = (x : ℤ)) :
    ExecDet TW BW TR BR inp (sparseDeleteStmt N_cap lR eR pR xR) m₀
      (fun m₁ =>
        EncSparseSet N_cap lenIdx elemOff posOff (denseDelete x arr) m₁ ∧
        (∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ lenIdx → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, (i < elemOff ∨ elemOff + (N_cap : ℤ) ≤ i) →
              (i < posOff ∨ posOff + (N_cap : ℤ) ≤ i) →
              wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, i < 55 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      260 := by
  unfold sparseDeleteStmt
  refine ExecDet.seq' 160
    (exec_sparseContainsStmt inp lR eR pR xR 55 hTW hBW_scr
      (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
      hfp₀ henc hread_l hread_e hread_p hread_x) (by omega) ?_
  intro m₁ ⟨hc_res, hfr_t, hfr_scr, hfr_r⟩ hfp₁
  have hcond1 : (evalArithCond inp 0 m₁ (.intEq (.readHeap engScrTbl (.lit 55)) (.lit 1))).1 =
      arr.contains x := by
    simp only [evalArithCond, evalIntExpr]
    change decide (wRead m₁ engScrTbl 55 = 1) = arr.contains x
    rw [hc_res]; cases arr.contains x <;> rfl
  refine ExecDet.ite' (C_c := 8) (C_b := 150) _ _ _ hcond1 (by simp [condExprOps, intExprOps])
    (fun hmem_b => ?_) (fun hnot_b => ?_)
  · have hmem : x ∈ arr := List.contains_iff_mem.mp hmem_b
    have hxN : x < N_cap := henc.2.1 x hmem
    have hlen_le_N : arr.length ≤ N_cap := henc.length_le
    let idx := arr.idxOf x
    have hidx_lt : idx < arr.length := List.idxOf_lt_length_of_mem hmem
    have hget_idx : arr[idx]'hidx_lt = x := List.getElem_idxOf hidx_lt
    have hpos_val : wRead m₀ engArrTbl (posOff + (x : ℤ)) = (idx : ℤ) := by
      rw [← hget_idx]; exact (henc.2.2.2 idx hidx_lt).2
    have hl₁ : wRead m₁ engScrTbl lR = lenIdx := (hfr_scr lR (by omega) (by omega)).trans hread_l
    have he₁ : wRead m₁ engScrTbl eR = elemOff := (hfr_scr eR (by omega) (by omega)).trans hread_e
    have hp₁ : wRead m₁ engScrTbl pR = posOff := (hfr_scr pR (by omega) (by omega)).trans hread_p
    have hx₁ : wRead m₁ engScrTbl xR = (x : ℤ) := (hfr_scr xR (by omega) (by omega)).trans hread_x
    refine ExecDet.seq' 136
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 56) (.readHeap engScrTbl (.lit xR)) 56 (x : ℤ)
        hfp₁ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega) rfl (by simp only [evalIntExpr]; exact hx₁)
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro m₂ hm₂ hfp₂; subst hm₂
    refine ExecDet.seq' 122
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 57)
        (.readHeap engArrTbl (.add (.readHeap engScrTbl (.lit pR)) (.readHeap engScrTbl (.lit 56))))
        57 (idx : ℤ) hfp₂ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega) rfl
        (by simp only [evalIntExpr]
            set m_2 := H3a.wWrite m₁ engScrTbl 56 (x : ℤ)
            have hp2 : wRead m_2 engScrTbl pR = posOff := by
              rw [wRead_wWrite_of_ne m₁ _ (Or.inr (by omega))]; exact hp₁
            have hx2 : wRead m_2 engScrTbl 56 = (x : ℤ) := wRead_wWrite_self _ _ _ _
            change wRead m_2 engArrTbl (wRead m_2 engScrTbl pR + wRead m_2 engScrTbl 56) = (idx : ℤ)
            rw [hp2, hx2, wRead_wWrite_of_ne m₁ _ (Or.inl (by decide)),
                hfr_t engArrTbl (by decide), hpos_val])
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro m₃ hm₃ hfp₃; subst hm₃
    refine ExecDet.seq' 108
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 58)
        (.sub (.readHeap engMetaTbl (.readHeap engScrTbl (.lit lR))) (.lit 1))
        58 ((arr.length - 1 : ℕ) : ℤ) hfp₃ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega) rfl
        (by simp only [evalIntExpr]
            set m_3 := H3a.wWrite (H3a.wWrite m₁ engScrTbl 56 (x : ℤ)) engScrTbl 57 (idx : ℤ)
            have hl3 : wRead m_3 engScrTbl lR = lenIdx := by
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
              exact hl₁
            change wRead m_3 engMetaTbl (wRead m_3 engScrTbl lR) - 1 = _
            rw [hl3, wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                hfr_t engMetaTbl (by decide), henc.2.2.1]
            omega)
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro m₄ hm₄ hfp₄; subst hm₄
    set mA := H3a.wWrite (H3a.wWrite (H3a.wWrite m₁ engScrTbl 56 (x : ℤ)) engScrTbl 57 (idx : ℤ))
                engScrTbl 58 ((arr.length - 1 : ℕ) : ℤ)
    have hidxA : wRead mA engScrTbl 57 = (idx : ℤ) := by
      simp only [mA]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
    have hlastIdxA : wRead mA engScrTbl 58 = ((arr.length - 1 : ℕ) : ℤ) := wRead_wWrite_self _ _ _ _
    have hlA : wRead mA engScrTbl lR = lenIdx := by
      simp only [mA]; (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]); exact hl₁
    have heA : wRead mA engScrTbl eR = elemOff := by
      simp only [mA]; (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]); exact he₁
    have hpA : wRead mA engScrTbl pR = posOff := by
      simp only [mA]; (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]); exact hp₁
    have hcond2 : (evalArithCond inp 0 mA
        (.intEq (.readHeap engScrTbl (.lit 57)) (.readHeap engScrTbl (.lit 58)))).1 =
        decide (idx = arr.length - 1) := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead mA engScrTbl 57 = wRead mA engScrTbl 58) = _
      rw [hidxA, hlastIdxA]
      by_cases heq : idx = arr.length - 1 <;> simp [heq] <;> omega
    refine ExecDet.ite' (C_c := 8) (C_b := 90) _ _ _ hcond2 (by simp [condExprOps, intExprOps])
      (fun hlast_eq => ?_) (fun hlast_ne => ?_)
    · have heq_idx : idx = arr.length - 1 := of_decide_eq_true hlast_eq
      have hdd : denseDelete x arr = arr.take (arr.length - 1) := by
        unfold denseDelete; simp only [idx] at hidx_lt heq_idx
        rw [dif_pos hidx_lt, if_pos heq_idx]
      refine ExecDet.wWrite inp engMetaTbl (.readHeap engScrTbl (.lit lR))
        (.readHeap engScrTbl (.lit 58)) lenIdx ((arr.length - 1 : ℕ) : ℤ)
        hfp₄ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) hlen0 hlenB
        (by simp only [evalIntExpr]; exact hlA)
        (by simp only [evalIntExpr]; exact hlastIdxA)
        (by simp [intExprOps]) ?_
      set mF := H3a.wWrite mA engMetaTbl lenIdx ((arr.length - 1 : ℕ) : ℤ)
      refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
      · rw [hdd]
        refine ⟨henc.1.take, fun y hy => henc.2.1 y (List.mem_of_mem_take hy), ?_, fun i hi => ?_⟩
        · simp only [mF, List.length_take]; rw [wRead_wWrite_self]; congr 1; omega
        · simp only [List.length_take] at hi
          have hlt : i < arr.length - 1 := by omega
          have hlt_a : i < arr.length := by omega
          rw [List.getElem_take]
          refine ⟨?_, ?_⟩
          · simp only [mF, mA]
            iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
            rw [hfr_t engArrTbl (by decide)]
            exact (henc.2.2.2 i hlt_a).1
          · simp only [mF, mA]
            iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
            rw [hfr_t engArrTbl (by decide)]
            exact (henc.2.2.2 i hlt_a).2
      · intro t ht1 ht2 ht3 i
        simp only [mF, mA]
        rw [wRead_wWrite_of_ne _ _ (Or.inl ht1)]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht3)]
        exact hfr_t t ht3 i
      · intro i hi
        simp only [mF, mA]
        rw [wRead_wWrite_of_ne _ _ (Or.inr hi)]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        exact hfr_t engMetaTbl (by decide) i
      · intro i _ _
        simp only [mF, mA]
        iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        exact hfr_t engArrTbl (by decide) i
      · intro i hi
        simp only [mF, mA]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hfr_scr i (by omega) (by omega)
      · intro t i; simp only [mF, mA, rRead_wWrite]; exact hfr_r t i
    · have hne_idx : idx ≠ arr.length - 1 := of_decide_eq_false hlast_ne
      have hlast_lt : arr.length - 1 < arr.length := by omega
      let lastV := arr[arr.length - 1]'hlast_lt
      have hlastN : lastV < N_cap := henc.2.1 lastV (List.getElem_mem hlast_lt)
      have hdd : denseDelete x arr = (arr.take (arr.length - 1)).set idx lastV := by
        unfold denseDelete; simp only [idx] at hidx_lt hne_idx
        rw [dif_pos hidx_lt, if_neg hne_idx]
      have hlast_mA : wRead mA engArrTbl (elemOff + ((arr.length - 1 : ℕ) : ℤ)) = (lastV : ℤ) := by
        simp only [mA]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        rw [hfr_t engArrTbl (by decide)]
        exact (henc.2.2.2 (arr.length - 1) hlast_lt).1
      refine ExecDet.seq' 76
        (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 59)
          (.readHeap engArrTbl (.add (.readHeap engScrTbl (.lit eR)) (.readHeap engScrTbl (.lit 58))))
          59 (lastV : ℤ) hfp₄ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega) rfl
          (by simp only [evalIntExpr]; change wRead mA engArrTbl (wRead mA engScrTbl eR + wRead mA engScrTbl 58) = _
              rw [heA, hlastIdxA, hlast_mA])
          (by simp [intExprOps]) rfl) (by omega) ?_
      intro m₅ hm₅ hfp₅; subst hm₅
      set mB := H3a.wWrite mA engScrTbl 59 (lastV : ℤ)
      refine ExecDet.seq' 62
        (ExecDet.wWrite (C := 12) inp engArrTbl
          (.add (.readHeap engScrTbl (.lit eR)) (.readHeap engScrTbl (.lit 57)))
          (.readHeap engScrTbl (.lit 59)) (elemOff + (idx : ℤ)) (lastV : ℤ)
          hfp₅ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega)
          (by simp only [evalIntExpr]; change wRead mB engScrTbl eR + wRead mB engScrTbl 57 = _
              dsimp only [mB]
              rw [wRead_wWrite_of_ne mA _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne mA _ (Or.inr (by omega)), heA, hidxA])
          (by simp only [evalIntExpr, mB]; exact wRead_wWrite_self _ _ _ _)
          (by simp [intExprOps]) rfl) (by omega) ?_
      intro m₆ hm₆ hfp₆; subst hm₆
      set mC := H3a.wWrite mB engArrTbl (elemOff + (idx : ℤ)) (lastV : ℤ)
      refine ExecDet.seq' 48
        (ExecDet.wWrite (C := 12) inp engArrTbl
          (.add (.readHeap engScrTbl (.lit pR)) (.readHeap engScrTbl (.lit 59)))
          (.readHeap engScrTbl (.lit 57)) (posOff + (lastV : ℤ)) (idx : ℤ)
          hfp₆ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) (by omega) (by omega)
          (by simp only [evalIntExpr]
              have hpC : wRead mC engScrTbl pR = posOff := by
                dsimp only [mC, mB]
                rw [wRead_wWrite_of_ne mB _ (Or.inl (by decide)),
                    wRead_wWrite_of_ne mA _ (Or.inr (by omega))]
                exact hpA
              have h59C : wRead mC engScrTbl 59 = (lastV : ℤ) := by
                dsimp only [mC, mB]
                rw [wRead_wWrite_of_ne mB _ (Or.inl (by decide)), wRead_wWrite_self]
              change wRead mC engScrTbl pR + wRead mC engScrTbl 59 = _
              rw [hpC, h59C])
          (by simp only [evalIntExpr]; change wRead mC engScrTbl 57 = _
              dsimp only [mC, mB]
              rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hidxA])
          (by simp [intExprOps]) rfl) (by omega) ?_
      intro m₇ hm₇ hfp₇; subst hm₇
      set mD := H3a.wWrite mC engArrTbl (posOff + (lastV : ℤ)) (idx : ℤ)
      refine ExecDet.wWrite inp engMetaTbl (.readHeap engScrTbl (.lit lR))
        (.readHeap engScrTbl (.lit 58)) lenIdx ((arr.length - 1 : ℕ) : ℤ)
        hfp₇ (by dsimp [engScrTbl, engArrTbl, engMetaTbl]; omega) hlen0 hlenB
        (by simp only [evalIntExpr]; change wRead mD engScrTbl lR = _
            dsimp only [mD, mC, mB]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hlA])
        (by simp only [evalIntExpr]; change wRead mD engScrTbl 58 = _
            dsimp only [mD, mC, mB]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hlastIdxA])
        (by simp [intExprOps]) ?_
      set mF := H3a.wWrite mD engMetaTbl lenIdx ((arr.length - 1 : ℕ) : ℤ)
      rcases denseDelete_spec (h := x) henc.1 with ⟨hnd_dd, hset_dd⟩
      refine ⟨⟨hnd_dd, ?_, ?_, ?_⟩, ?_, ?_, ?_, ?_, ?_⟩
      · intro y hy
        have hy_er : y ∈ arr.toFinset.erase x := hset_dd ▸ List.mem_toFinset.mpr hy
        exact henc.2.1 y (List.mem_toFinset.mp (Finset.mem_of_mem_erase hy_er))
      · rw [hdd]; simp only [mF, List.length_set, List.length_take]
        rw [wRead_wWrite_self]; congr 1; omega
      · intro i hi
        have hi_sub : i < arr.length - 1 := by
          have hi' := hi; rw [hdd, List.length_set, List.length_take] at hi'; omega
        have hi_lt : i < arr.length := by omega
        have hget_dd : (denseDelete x arr)[i]'hi = if i = idx then lastV else arr[i]'hi_lt := by
          have : (denseDelete x arr)[i]'hi =
              ((arr.take (arr.length - 1)).set idx lastV)[i]'(by rw [← hdd]; exact hi) := by
            congr 1
          rw [this, List.getElem_set]
          by_cases heq : i = idx
          · subst heq; simp [List.getElem_take]
          · rw [if_neg (Ne.symm heq), if_neg heq, List.getElem_take]
        rw [hget_dd]
        split_ifs with h_i_idx
        · subst h_i_idx
          refine ⟨?_, ?_⟩
          · simp only [mF, mD, mC]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
          · simp only [mF, mD]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]
        · have hne_last : arr[i]'hi_lt ≠ lastV := by
            intro heq
            have hinj := List.nodup_iff_injective_getElem.mp henc.1
            have hf : (⟨i, hi_lt⟩ : Fin arr.length) = ⟨arr.length - 1, hlast_lt⟩ := hinj heq
            have : i = arr.length - 1 := congrArg Fin.val hf
            omega
          refine ⟨?_, ?_⟩
          · simp only [mF, mD, mC, mB, mA]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
            iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
            rw [hfr_t engArrTbl (by decide)]
            exact (henc.2.2.2 i hi_lt).1
          · simp only [mF, mD, mC, mB, mA]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inr (by intro heq; apply hne_last; omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by
                  have := henc.2.1 (arr[i]'hi_lt) (List.getElem_mem hi_lt); omega))]
            iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
            rw [hfr_t engArrTbl (by decide)]
            exact (henc.2.2.2 i hi_lt).2
      · intro t ht1 ht2 ht3 i
        simp only [mF, mD, mC, mB, mA]
        rw [wRead_wWrite_of_ne _ _ (Or.inl ht1),
            wRead_wWrite_of_ne _ _ (Or.inl ht2),
            wRead_wWrite_of_ne _ _ (Or.inl ht2)]
        iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl ht3)]
        exact hfr_t t ht3 i
      · intro i hi
        simp only [mF, mD, mC, mB, mA]
        rw [wRead_wWrite_of_ne _ _ (Or.inr hi)]
        iterate 6 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        exact hfr_t engMetaTbl (by decide) i
      · intro i hie hip
        simp only [mF, mD, mC, mB, mA]
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        exact hfr_t engArrTbl (by decide) i
      · intro i hi
        simp only [mF, mD, mC, mB, mA]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hfr_scr i (by omega) (by omega)
      · intro t i; simp only [mF, mD, mC, mB, mA, rRead_wWrite]; exact hfr_r t i
  · have hnot_mem : x ∉ arr := fun hm =>
      absurd (List.contains_iff_mem.mpr hm) (by rw [hnot_b]; decide)
    have hdd : denseDelete x arr = arr := by
      unfold denseDelete; dsimp only
      rw [dif_neg (by rw [List.idxOf_eq_length_iff.mpr hnot_mem]; omega)]
    refine ExecDet.skip inp hfp₁ ?_ (by omega)
    refine ⟨hdd.symm ▸ EncSparseSet.ext henc
      (hfr_t engMetaTbl (by decide) lenIdx)
      (fun i _ => hfr_t engArrTbl (by decide) _)
      (fun y _ => hfr_t engArrTbl (by decide) _),
      fun t _ _ ht3 i => hfr_t t ht3 i,
      fun i _ => hfr_t engMetaTbl (by decide) i,
      fun i _ _ => hfr_t engArrTbl (by decide) i,
      fun i hi => hfr_scr i (by omega) (by omega),
      hfr_r⟩


end UL.Proof.clm_9_1_explicit_tradeoff.CG19
