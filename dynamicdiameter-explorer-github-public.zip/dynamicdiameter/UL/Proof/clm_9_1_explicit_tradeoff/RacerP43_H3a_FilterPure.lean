import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.clm_7_3_global_approx
import UL.Stmt.lem_9_1
import UL.Proof.clm_9_1_explicit_tradeoff.H1_Algebra
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
import UL.Proof.clm_9_1_explicit_tradeoff.H3b2_GaussRAM
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof_clm_6_1_precision_RaceV30
open UL.Proof.clm_9_1_explicit_tradeoff.H1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2

/-! ### 1. Concrete `sqrt`-free lattice direction net & padded `ℝ^{d+1}` query net -/

noncomputable def M_lat_of (d : ℕ) (e : ℚ) : ℕ :=
  Nat.ceil (16 * (d : ℝ) / (e : ℝ))

noncomputable def S_lat_of (d : ℕ) (e : ℚ) : ℕ :=
  Nat.clog 2 (2 * M_lat_of d e + 2) + 1

theorem two_mul_M_lat_le_pow (d : ℕ) (e : ℚ) :
    2 * M_lat_of d e + 1 ≤ 2 ^ S_lat_of d e := by
  unfold S_lat_of
  have h1 : 2 * M_lat_of d e + 2 ≤ 2 ^ Nat.clog 2 (2 * M_lat_of d e + 2) :=
    Nat.le_pow_clog (by decide) _
  have h2 : 2 ^ Nat.clog 2 (2 * M_lat_of d e + 2) ≤ 2 ^ (Nat.clog 2 (2 * M_lat_of d e + 2) + 1) :=
    Nat.pow_le_pow_right (by decide) (Nat.le_succ _)
  omega

noncomputable def latRoundInt {d : ℕ} (M : ℕ) (z : EuclideanSpace ℝ (Fin d)) (i : Fin d) : ℤ :=
  Int.floor ((M : ℝ) * euclideanCoord z i + 1 / 2)

noncomputable def latVec {d : ℕ} (M : ℕ) (z : EuclideanSpace ℝ (Fin d)) :
    EuclideanSpace ℝ (Fin d) :=
  ratPointToEuclidean (fun i => (latRoundInt M z i : ℚ))

noncomputable def paddedLatDir {d : ℕ} (A B : ℚ) (m : Fin d → ℤ) :
    EuclideanSpace ℝ (Fin (d + 1)) :=
  let v := ratPointToEuclidean (fun i => (m i : ℚ))
  liftedPoint ((A : ℝ) • (‖v‖⁻¹ • v)) (-(B : ℝ))

noncomputable def paddedLatNet {d : ℕ} (M : ℕ) (A B : ℚ) :
    List (EuclideanSpace ℝ (Fin (d + 1))) :=
  open Classical in
  let box : Finset (Fin d → ℤ) :=
    (Fintype.piFinset (fun _ : Fin d => Finset.Icc (-(M : ℤ)) (M : ℤ))).filter (fun m => m ≠ 0)
  box.toList.map (paddedLatDir A B)

private lemma norm_sq_eq_sum_coords {d : ℕ} (v : EuclideanSpace ℝ (Fin d)) :
    ‖v‖ ^ 2 = ∑ i : Fin d, (euclideanCoord v i) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
  refine Finset.sum_congr rfl fun i _ => ?_
  simp [euclideanCoord, sq]

private lemma coord_abs_le_norm {d : ℕ} (v : EuclideanSpace ℝ (Fin d)) (i : Fin d) :
    |euclideanCoord v i| ≤ ‖v‖ := by
  have hsq : (euclideanCoord v i) ^ 2 ≤ ‖v‖ ^ 2 := by
    rw [norm_sq_eq_sum_coords]
    exact Finset.single_le_sum (fun j _ => sq_nonneg _) (Finset.mem_univ i)
  have habs := sq_le_sq.mp hsq
  rwa [abs_of_nonneg (norm_nonneg v)] at habs

private lemma isUnitVec_lifted_of_sq {d : ℕ} {u : EuclideanSpace ℝ (Fin d)} (hu : ‖u‖ = 1)
    {a b : ℝ} (hab : a ^ 2 + b ^ 2 = 1) :
    IsUnitVec (liftedPoint (a • u) b) := by
  unfold IsUnitVec
  have hsq : ‖liftedPoint (a • u) b‖ ^ 2 = 1 := by
    rw [norm_sq_eq_sum_coords, Fin.sum_univ_castSucc]
    have hbase : (∑ i : Fin d, (euclideanCoord (liftedPoint (a • u) b) i.castSucc) ^ 2) =
        a ^ 2 * ∑ i : Fin d, (euclideanCoord u i) ^ 2 := by
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      simp [liftedPoint, euclideanCoord, Fin.snoc_castSucc]
      ring
    have hlast : (euclideanCoord (liftedPoint (a • u) b) (Fin.last d)) ^ 2 = b ^ 2 := by
      simp [liftedPoint, euclideanCoord, Fin.snoc_last]
    have hu_sq : ∑ i : Fin d, (euclideanCoord u i) ^ 2 = 1 := by
      rw [← norm_sq_eq_sum_coords, hu, one_pow]
    rw [hbase, hu_sq, mul_one, hlast, hab]
  nlinarith [norm_nonneg (liftedPoint (a • u) b)]

private lemma normalize_dist_le {d : ℕ} {z w : EuclideanSpace ℝ (Fin d)}
    (hz : ‖z‖ = 1) {δ : ℝ} (hwz : ‖w - z‖ ≤ δ) (hδ : δ < 1) :
    w ≠ 0 ∧ ‖(‖w‖⁻¹ • w) - z‖ ≤ 2 * δ := by
  have hw_ge : 1 - δ ≤ ‖w‖ := by
    have htri : ‖z‖ ≤ ‖w‖ + ‖z - w‖ := norm_le_insert' z w
    rw [hz, norm_sub_rev] at htri
    linarith only [htri, hwz]
  have hw_pos : 0 < ‖w‖ := by linarith only [hw_ge, hδ]
  have hw_ne : w ≠ 0 := norm_pos_iff.mp hw_pos
  refine ⟨hw_ne, ?_⟩
  have hdecomp : (‖w‖⁻¹ • w) - z = (w - z) + (1 - ‖w‖) • (‖w‖⁻¹ • w) := by
    ext i
    simp only [PiLp.sub_apply, PiLp.add_apply, PiLp.smul_apply, smul_eq_mul]
    have hne : ‖w‖ ≠ 0 := hw_pos.ne'
    field_simp [hne]
    ring
  have hunit_w : ‖‖w‖⁻¹ • w‖ = 1 := by
    rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hw_pos.ne']
  have habs_norm : |1 - ‖w‖| ≤ δ := by
    rw [abs_sub_comm, ← hz]
    exact (abs_norm_sub_norm_le w z).trans hwz
  have htri2 := norm_add_le (w - z) ((1 - ‖w‖) • (‖w‖⁻¹ • w))
  rw [← hdecomp, norm_smul, Real.norm_eq_abs, hunit_w, mul_one] at htri2
  linarith only [htri2, hwz, habs_norm]

theorem concrete_paddedLatNet_spec {d : ℕ} (hd : 1 ≤ d) {e A B : ℚ}
    (he0 : 0 < (e : ℝ)) (he1 : (e : ℝ) ≤ 1)
    (hAB : A ^ 2 + B ^ 2 = 1) :
    let M := M_lat_of d e
    (∀ q ∈ paddedLatNet (d := d) M A B, IsUnitVec q) ∧
    (((paddedLatNet (d := d) M A B).length : ℝ) ≤
      Real.exp (6 * (d : ℝ) * Real.log (2 * (d : ℝ) / (e : ℝ)))) ∧
    (∀ w : EuclideanSpace ℝ (Fin d), w ≠ 0 →
      let z := ‖w‖⁻¹ • w
      let v := latVec M z
      v ≠ 0 ∧
      ‖‖v‖⁻¹ • v‖ = 1 ∧
      ‖(‖v‖⁻¹ • v) - z‖ ≤ (e : ℝ) / 8 ∧
      liftedPoint ((A : ℝ) • (‖v‖⁻¹ • v)) (-(B : ℝ)) ∈ paddedLatNet (d := d) M A B) := by
  classical
  intro M
  have hAB_r : (A : ℝ) ^ 2 + (-(B : ℝ)) ^ 2 = 1 := by
    rw [neg_sq]; exact_mod_cast hAB
  have hd_r : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
  let x : ℝ := (d : ℝ) / (e : ℝ)
  have hx_ge1 : 1 ≤ x := by dsimp [x]; rw [one_le_div he0]; linarith only [hd_r, he1]
  have hM_ge : 16 * x ≤ (M : ℝ) := by
    dsimp [M, M_lat_of, x]; rw [← mul_div_assoc]; exact Nat.le_ceil _
  have hM_pos : (0 : ℝ) < (M : ℝ) := by linarith only [hx_ge1, hM_ge]
  have hM_lt : (M : ℝ) < 16 * x + 1 := by
    dsimp [M, M_lat_of, x]; rw [← mul_div_assoc]; exact Nat.ceil_lt_add_one (by positivity)
  let box : Finset (Fin d → ℤ) :=
    (Fintype.piFinset (fun _ : Fin d => Finset.Icc (-(M : ℤ)) (M : ℤ))).filter (fun m => m ≠ 0)
  refine ⟨?_, ?_, ?_⟩
  · intro q hq
    unfold paddedLatNet at hq
    rcases List.mem_map.mp hq with ⟨m, hm_list, rfl⟩
    have hm_ne : m ≠ 0 := (Finset.mem_filter.mp (Finset.mem_toList.mp hm_list)).2
    let v := ratPointToEuclidean (fun i => (m i : ℚ))
    have hv_ne : v ≠ 0 := by
      intro hv0; apply hm_ne; funext i
      have hi := congrArg (fun u => euclideanCoord u i) hv0
      dsimp [v] at hi
      rw [euclideanCoord_ratPointToEuclidean] at hi
      have h0 : euclideanCoord (0 : EuclideanSpace ℝ (Fin d)) i = 0 := by simp [euclideanCoord]
      rw [h0] at hi
      exact_mod_cast hi
    have hv_pos : 0 < ‖v‖ := norm_pos_iff.mpr hv_ne
    have hunit_v : ‖‖v‖⁻¹ • v‖ = 1 := by
      rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hv_pos.ne']
    exact isUnitVec_lifted_of_sq hunit_v hAB_r
  · unfold paddedLatNet
    rw [List.length_map, Finset.length_toList]
    have hcard_box : box.card ≤ (2 * M + 1) ^ d := by
      calc box.card
          ≤ (Fintype.piFinset (fun _ : Fin d => Finset.Icc (-(M : ℤ)) (M : ℤ))).card :=
            Finset.card_filter_le _ _
        _ = ∏ _i : Fin d, (Finset.Icc (-(M : ℤ)) (M : ℤ)).card := Fintype.card_piFinset _
        _ = (2 * M + 1) ^ d := by
            have hI : (Finset.Icc (-(M : ℤ)) (M : ℤ)).card = 2 * M + 1 := by
              rw [Int.card_Icc]; omega
            simp [hI]
    let y : ℝ := 2 * (d : ℝ) / (e : ℝ)
    have hy_eq : y = 2 * x := by dsimp [y, x]; ring
    have hy_pos : 0 < y := by positivity
    have h2M1_le_y6 : ((2 * M + 1 : ℕ) : ℝ) ≤ y ^ 6 := by
      have h1 : ((2 * M + 1 : ℕ) : ℝ) ≤ 32 * x + 3 := by push_cast; linarith only [hM_lt]
      have hx6 : 1 ≤ x ^ 5 := one_le_pow₀ hx_ge1
      have h2 : 32 * x + 3 ≤ 64 * x ^ 6 := by nlinarith only [hx_ge1, hx6]
      have hy6 : y ^ 6 = 64 * x ^ 6 := by rw [hy_eq]; ring
      linarith only [h1, h2, hy6]
    have hpow_le : (((2 * M + 1) ^ d : ℕ) : ℝ) ≤ Real.exp (6 * (d : ℝ) * Real.log y) := by
      calc (((2 * M + 1) ^ d : ℕ) : ℝ)
          = ((2 * M + 1 : ℕ) : ℝ) ^ d := by push_cast; rfl
        _ ≤ (y ^ 6) ^ d := pow_le_pow_left₀ (Nat.cast_nonneg _) h2M1_le_y6 d
        _ = y ^ (6 * d) := (pow_mul y 6 d).symm
        _ = (Real.exp (Real.log y)) ^ (6 * d) := by rw [Real.exp_log hy_pos]
        _ = Real.exp (6 * (d : ℝ) * Real.log y) := by
            rw [← Real.exp_nat_mul]; congr 1; push_cast; ring
    exact (Nat.cast_le.mpr hcard_box).trans hpow_le
  · intro w hw_ne
    let z := ‖w‖⁻¹ • w
    let v := latVec M z
    have hw_pos : 0 < ‖w‖ := norm_pos_iff.mpr hw_ne
    have hz_unit : ‖z‖ = 1 := by
      dsimp [z]; rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hw_pos.ne']
    have hmem_I : ∀ i : Fin d, latRoundInt M z i ∈ Finset.Icc (-(M : ℤ)) (M : ℤ) := by
      intro i
      have hc := coord_abs_le_norm z i
      rw [hz_unit] at hc
      rcases abs_le.mp hc with ⟨hlo, hhi⟩
      have hfl_le : (latRoundInt M z i : ℝ) ≤ (M : ℝ) * euclideanCoord z i + 1 / 2 := Int.floor_le _
      have hfl_gt : (M : ℝ) * euclideanCoord z i - 1 / 2 < (latRoundInt M z i : ℝ) := by
        have := Int.lt_floor_add_one ((M : ℝ) * euclideanCoord z i + 1 / 2)
        unfold latRoundInt; linarith only [this]
      have h1 : -(M : ℝ) ≤ (M : ℝ) * euclideanCoord z i := by nlinarith only [hlo, hM_pos]
      have h2 : (M : ℝ) * euclideanCoord z i ≤ (M : ℝ) := by nlinarith only [hhi, hM_pos]
      have hlo_z : -(M : ℤ) - 1 < latRoundInt M z i := by
        exact_mod_cast (by push_cast; linarith only [hfl_gt, h1] : (-(M : ℤ) - 1 : ℝ) < (latRoundInt M z i : ℝ))
      have hhi_z : latRoundInt M z i < (M : ℤ) + 1 := by
        exact_mod_cast (by push_cast; linarith only [hfl_le, h2] : (latRoundInt M z i : ℝ) < ((M : ℤ) + 1 : ℝ))
      exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
    let u_scaled : EuclideanSpace ℝ (Fin d) := (M : ℝ)⁻¹ • v
    have hdist_sq : ‖u_scaled - z‖ ^ 2 ≤ ((d : ℝ) / (2 * (M : ℝ))) ^ 2 := by
      rw [norm_sq_eq_sum_coords]
      have hcoord : ∀ i : Fin d, (euclideanCoord (u_scaled - z) i) ^ 2 ≤ (1 / (2 * (M : ℝ))) ^ 2 := by
        intro i
        have hfl_le : (latRoundInt M z i : ℝ) ≤ (M : ℝ) * euclideanCoord z i + 1 / 2 := Int.floor_le _
        have hfl_gt : (M : ℝ) * euclideanCoord z i - 1 / 2 ≤ (latRoundInt M z i : ℝ) := by
          have := Int.lt_floor_add_one ((M : ℝ) * euclideanCoord z i + 1 / 2)
          unfold latRoundInt; linarith only [this]
        have hci : euclideanCoord (u_scaled - z) i =
            ((latRoundInt M z i : ℝ) - (M : ℝ) * euclideanCoord z i) / (M : ℝ) := by
          have hv_i : euclideanCoord v i = (latRoundInt M z i : ℝ) := by
            dsimp [v, latVec]; rw [euclideanCoord_ratPointToEuclidean]; push_cast; rfl
          have hlin : euclideanCoord (u_scaled - z) i = (M : ℝ)⁻¹ * euclideanCoord v i - euclideanCoord z i := by
            simp [u_scaled, euclideanCoord]
          rw [hlin, hv_i]; field_simp [hM_pos.ne']
        have hnum : ((latRoundInt M z i : ℝ) - (M : ℝ) * euclideanCoord z i) ^ 2 ≤ (1 / 2 : ℝ) ^ 2 := by
          nlinarith only [hfl_le, hfl_gt]
        rw [hci, div_pow]
        calc ((latRoundInt M z i : ℝ) - (M : ℝ) * euclideanCoord z i) ^ 2 / (M : ℝ) ^ 2
            ≤ (1 / 2 : ℝ) ^ 2 / (M : ℝ) ^ 2 := div_le_div_of_nonneg_right hnum (sq_nonneg _)
          _ = (1 / (2 * (M : ℝ))) ^ 2 := by ring
      calc ∑ i : Fin d, (euclideanCoord (u_scaled - z) i) ^ 2
          ≤ ∑ _i : Fin d, (1 / (2 * (M : ℝ))) ^ 2 := Finset.sum_le_sum (fun i _ => hcoord i)
        _ = (d : ℝ) * (1 / (2 * (M : ℝ))) ^ 2 := by simp
        _ ≤ (d : ℝ) ^ 2 * (1 / (2 * (M : ℝ))) ^ 2 :=
            mul_le_mul_of_nonneg_right (by nlinarith only [hd_r]) (sq_nonneg _)
        _ = ((d : ℝ) / (2 * (M : ℝ))) ^ 2 := by ring
    have hdist : ‖u_scaled - z‖ ≤ (e : ℝ) / 32 := by
      have h1 : ‖u_scaled - z‖ ≤ (d : ℝ) / (2 * (M : ℝ)) := by
        have hnn1 := norm_nonneg (u_scaled - z)
        have hnn2 : 0 ≤ (d : ℝ) / (2 * (M : ℝ)) := by positivity
        nlinarith only [hdist_sq, hnn1, hnn2]
      have h2 : (d : ℝ) / (2 * (M : ℝ)) ≤ (e : ℝ) / 32 := by
        rw [div_le_div_iff₀ (by positivity) (by norm_num)]
        have hmul : 16 * (d : ℝ) ≤ (M : ℝ) * (e : ℝ) := by
          have h16 : 16 * (d : ℝ) / (e : ℝ) ≤ (M : ℝ) := by
            simpa [x, mul_div_assoc] using hM_ge
          exact (div_le_iff₀ he0).mp h16
        linarith only [hmul]
      exact h1.trans h2
    obtain ⟨hu_ne, hnorm_u⟩ := normalize_dist_le hz_unit hdist (by linarith only [he1])
    have hv_ne : v ≠ 0 := by intro hv0; apply hu_ne; simp [u_scaled, hv0]
    have hv_pos : 0 < ‖v‖ := norm_pos_iff.mpr hv_ne
    have hm_ne : latRoundInt M z ≠ 0 := by
      intro hm0; apply hv_ne; ext i
      simp [v, latVec, ratPointToEuclidean, hm0]
    have hdir_eq : ‖v‖⁻¹ • v = ‖u_scaled‖⁻¹ • u_scaled := by
      dsimp [u_scaled]
      rw [norm_smul, Real.norm_eq_abs, abs_of_pos (inv_pos.mpr hM_pos), mul_inv, inv_inv,
        smul_smul]
      congr 1; field_simp [hM_pos.ne']
    have hv_unit : ‖‖v‖⁻¹ • v‖ = 1 := by
      rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hv_pos.ne']
    have hv_dist : ‖(‖v‖⁻¹ • v) - z‖ ≤ (e : ℝ) / 8 := by
      rw [hdir_eq]; linarith only [hnorm_u, he0]
    have hm_box : latRoundInt M z ∈ box :=
      Finset.mem_filter.mpr ⟨Fintype.mem_piFinset.mpr hmem_I, hm_ne⟩
    have hmem_net : liftedPoint ((A : ℝ) • (‖v‖⁻¹ • v)) (-(B : ℝ)) ∈ paddedLatNet (d := d) M A B := by
      unfold paddedLatNet
      exact List.mem_map.mpr ⟨latRoundInt M z, Finset.mem_toList.mpr hm_box, rfl⟩
    exact ⟨hv_ne, hv_unit, hv_dist, hmem_net⟩

/-! ### 2. Space bound `M₀ ^ ℓ ≤ m^{1 + σ} * (poly_cap_fn)^ℓ` -/

theorem M0_pow_ell_le_space {ℓ M₀ m : ℕ} {h x σ P_cap : ℝ}
    (hℓ : 1 ≤ ℓ) (hm : 1 ≤ m) (hR_pos : ∀ R : ℕ, 1 ≤ R → True)
    {R : ℕ} (hR : 1 ≤ R)
    (hh0 : 0 < h) (hh1 : h < 1) (hhx : h ≤ x) (hx1 : x ≤ 1)
    (hu_le : u_search h x ≤ σ)
    (hP_nn : 0 ≤ P_cap)
    (hRlM : ((R * ℓ * M₀ : ℕ) : ℝ) ≤ (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) * P_cap) :
    ((M₀ ^ ℓ : ℕ) : ℝ) ≤ (m : ℝ) ^ (1 + σ) * P_cap ^ ℓ := by
  let _ := hR_pos
  have hM_le_prod : M₀ ≤ R * ℓ * M₀ := by
    have h1 : 1 ≤ R * ℓ := Nat.mul_pos hR hℓ
    calc M₀ = 1 * M₀ := (one_mul M₀).symm
      _ ≤ (R * ℓ) * M₀ := Nat.mul_le_mul_right M₀ h1
  have hM_r : (M₀ : ℝ) ≤ (m : ℝ) ^ (I_h h x / (ℓ : ℝ)) * P_cap :=
    (Nat.cast_le.mpr hM_le_prod).trans hRlM
  have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm
  have hℓ_ne : (ℓ : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hpow : (M₀ : ℝ) ^ ℓ ≤ ((m : ℝ) ^ (I_h h x / (ℓ : ℝ)) * P_cap) ^ ℓ :=
    pow_le_pow_left₀ (Nat.cast_nonneg M₀) hM_r ℓ
  rw [mul_pow, ← Real.rpow_natCast ((m : ℝ) ^ _), ← Real.rpow_mul (by positivity),
    div_mul_cancel₀ _ hℓ_ne] at hpow
  have hI_eq : I_h h x = 1 + u_search h x := by
    have hdiv := (I_h_bounds hh0 hh1 hhx hx1)
    unfold u_search; linarith
  have hexp_le : I_h h x ≤ 1 + σ := by linarith only [hI_eq, hu_le]
  have hm_pow : (m : ℝ) ^ (I_h h x) ≤ (m : ℝ) ^ (1 + σ) :=
    Real.rpow_le_rpow_of_exponent_le hm_ge1 hexp_le
  push_cast
  exact hpow.trans (mul_le_mul_of_nonneg_right hm_pow (pow_nonneg hP_nn ℓ))

/-! ### 3. Stateless mixed-radix tuple enumeration & base-`M₀` encoding -/

def encodeTuple {M₀ : ℕ} : ∀ {ℓ : ℕ}, (Fin ℓ → Fin M₀) → ℕ
  | 0, _ => 0
  | ℓ + 1, τ => encodeTuple (fun j : Fin ℓ => τ j.castSucc) * M₀ + (τ (Fin.last ℓ)).val

theorem encodeTuple_lt {M₀ : ℕ} (hM₀ : 1 ≤ M₀) :
    ∀ {ℓ : ℕ} (τ : Fin ℓ → Fin M₀), encodeTuple τ < M₀ ^ ℓ
  | 0, _ => by simp [encodeTuple]
  | ℓ + 1, τ => by
      have ih := encodeTuple_lt hM₀ (fun j : Fin ℓ => τ j.castSucc)
      have hlast := (τ (Fin.last ℓ)).isLt
      dsimp [encodeTuple]
      calc encodeTuple (fun j : Fin ℓ => τ j.castSucc) * M₀ + (τ (Fin.last ℓ)).val
          < encodeTuple (fun j : Fin ℓ => τ j.castSucc) * M₀ + M₀ := by omega
        _ = (encodeTuple (fun j : Fin ℓ => τ j.castSucc) + 1) * M₀ := by ring
        _ ≤ M₀ ^ ℓ * M₀ := Nat.mul_le_mul_right M₀ ih
        _ = M₀ ^ (ℓ + 1) := (pow_succ M₀ ℓ).symm

theorem encodeTuple_injective {M₀ : ℕ} (hM₀ : 1 ≤ M₀) :
    ∀ {ℓ : ℕ}, Function.Injective (@encodeTuple M₀ ℓ)
  | 0, τ₁, τ₂, _ => by ext s; exact Fin.elim0 s
  | ℓ + 1, τ₁, τ₂, h => by
      dsimp [encodeTuple] at h
      have h1 := (τ₁ (Fin.last ℓ)).isLt
      have h2 := (τ₂ (Fin.last ℓ)).isLt
      have hmod : (encodeTuple (fun j => τ₁ j.castSucc) * M₀ + (τ₁ (Fin.last ℓ)).val) % M₀ =
          (encodeTuple (fun j => τ₂ j.castSucc) * M₀ + (τ₂ (Fin.last ℓ)).val) % M₀ :=
        congrArg (· % M₀) h
      rw [Nat.mul_add_mod_self_right, Nat.mod_eq_of_lt h1,
          Nat.mul_add_mod_self_right, Nat.mod_eq_of_lt h2] at hmod
      have hdiv : encodeTuple (fun j => τ₁ j.castSucc) = encodeTuple (fun j => τ₂ j.castSucc) :=
        Nat.mul_right_cancel hM₀ (by omega)
      have hinit := encodeTuple_injective hM₀ hdiv
      funext s
      refine Fin.lastCases (Fin.ext hmod) (fun j => congrFun hinit j) s

/-- Stateless mixed-radix tuple decoding matching RAM loop `s = 0 .. ℓ - 1`:
`d_s := rem % cnt_s; rem := rem / cnt_s; τ_s := elig s d_s`. -/
def mixedTuple {M₀ : ℕ} (hM₀ : 1 ≤ M₀) :
    ∀ {ℓ : ℕ}, (Fin ℓ → ℕ) → (Fin ℓ → ℕ → ℕ) → ℕ → (Fin ℓ → Fin M₀)
  | 0, _, _, _, s => Fin.elim0 s
  | ℓ + 1, cnt, elig, idx, s =>
      Fin.cases
        (let v := elig 0 (idx % cnt 0)
         if hv : v < M₀ then ⟨v, hv⟩ else ⟨0, hM₀⟩)
        (fun j => mixedTuple hM₀ (fun j' => cnt j'.succ) (fun j' => elig j'.succ) (idx / cnt 0) j)
        s

theorem truncMul_eq_min_prod (K : ℕ) :
    ∀ {ℓ : ℕ} (cnt : Fin ℓ → ℕ), (∀ s, 1 ≤ cnt s) →
      Fin.foldl ℓ (fun acc s => min K (acc * cnt s)) (min K 1) = min K (∏ s : Fin ℓ, cnt s)
  | 0, _, _ => by simp
  | ℓ + 1, cnt, hpos => by
      rw [Fin.foldl_succ_last, truncMul_eq_min_prod K (fun j => cnt j.castSucc) (fun j => hpos j.castSucc)]
      rw [Fin.prod_univ_castSucc]
      have hc : 1 ≤ cnt (Fin.last ℓ) := hpos (Fin.last ℓ)
      rcases le_total K (∏ i : Fin ℓ, cnt i.castSucc) with h | h
      · rw [min_eq_left h,
            min_eq_left (h.trans (Nat.le_mul_of_pos_right _ hc)),
            min_eq_left (Nat.le_mul_of_pos_right K hc)]
      · rw [min_eq_right h]

theorem mixedTuple_image_range {M₀ : ℕ} (hM₀ : 1 ≤ M₀) :
    ∀ {ℓ : ℕ} (B : Fin ℓ → Finset (Fin M₀)) (cnt : Fin ℓ → ℕ) (elig : Fin ℓ → ℕ → ℕ),
      (∀ s, 1 ≤ cnt s) →
      (∀ s, ∀ k : Fin M₀, k ∈ B s ↔ ∃ j < cnt s, elig s j = k.val) →
      (∀ s j, j < cnt s → elig s j < M₀) →
      (∀ s j₁ j₂, j₁ < cnt s → j₂ < cnt s → elig s j₁ = elig s j₂ → j₁ = j₂) →
      ((Finset.range (∏ s : Fin ℓ, cnt s)).image (mixedTuple hM₀ cnt elig) =
        Fintype.piFinset B) ∧
      Set.InjOn (mixedTuple hM₀ cnt elig) ↑(Finset.range (∏ s : Fin ℓ, cnt s))
  | 0, B, cnt, elig, _, _, _, _ => by
      refine ⟨?_, ?_⟩
      · ext τ
        simp only [Fin.prod_univ_zero, Finset.range_one, Finset.image_singleton,
          Finset.mem_singleton, Fintype.mem_piFinset]
        exact ⟨fun _ s => Fin.elim0 s, fun _ => Subsingleton.elim _ _⟩
      · intro a ha b hb _
        simp only [Fin.prod_univ_zero, Finset.coe_range, Set.mem_Iio] at ha hb
        omega
  | ℓ + 1, B, cnt, elig, hpos, hmem, hlt, hinj => by
      have hc0 : 1 ≤ cnt 0 := hpos 0
      obtain ⟨himg_tl, hinj_tl⟩ := mixedTuple_image_range hM₀
        (fun j => B j.succ) (fun j => cnt j.succ) (fun j => elig j.succ)
        (fun j => hpos j.succ) (fun j => hmem j.succ) (fun j j' => hlt j.succ j')
        (fun j j₁ j₂ => hinj j.succ j₁ j₂)
      let P_tl := ∏ j : Fin ℓ, cnt j.succ
      have hprod_eq : (∏ s : Fin (ℓ + 1), cnt s) = cnt 0 * P_tl := Fin.prod_univ_succ cnt
      refine ⟨?_, ?_⟩
      · ext τ
        simp only [Finset.mem_image, Finset.mem_range, Fintype.mem_piFinset, hprod_eq]
        constructor
        · rintro ⟨idx, hidx, rfl⟩
          intro s
          refine Fin.cases ?_ (fun j => ?_) s
          · have hmod : idx % cnt 0 < cnt 0 := Nat.mod_lt idx hc0
            have hv : elig 0 (idx % cnt 0) < M₀ := hlt 0 _ hmod
            simp only [mixedTuple, Fin.cases_zero, dif_pos hv]
            exact (hmem 0 _).mpr ⟨idx % cnt 0, hmod, rfl⟩
          · have hdiv : idx / cnt 0 < P_tl := Nat.div_lt_of_lt_mul (by omega)
            have hmem_tl : mixedTuple hM₀ (fun j' => cnt j'.succ) (fun j' => elig j'.succ) (idx / cnt 0) ∈
                Fintype.piFinset (fun j' => B j'.succ) := by
              rw [← himg_tl]
              exact Finset.mem_image.mpr ⟨idx / cnt 0, Finset.mem_range.mpr hdiv, rfl⟩
            simpa [mixedTuple] using Fintype.mem_piFinset.mp hmem_tl j
        · intro hτ
          obtain ⟨j0, hj0, he0⟩ := (hmem 0 (τ 0)).mp (hτ 0)
          have hτ_tl : (fun j : Fin ℓ => τ j.succ) ∈ Fintype.piFinset (fun j => B j.succ) :=
            Fintype.mem_piFinset.mpr (fun j => hτ j.succ)
          rw [← himg_tl] at hτ_tl
          obtain ⟨q_tl, hq_range, hq_eq⟩ := Finset.mem_image.mp hτ_tl
          have hq_lt : q_tl < P_tl := Finset.mem_range.mp hq_range
          let idx := j0 + cnt 0 * q_tl
          have hidx_lt : idx < cnt 0 * P_tl := by
            dsimp [idx]
            calc j0 + cnt 0 * q_tl < cnt 0 + cnt 0 * q_tl := by omega
              _ = cnt 0 * (q_tl + 1) := by ring
              _ ≤ cnt 0 * P_tl := Nat.mul_le_mul_left (cnt 0) hq_lt
          refine ⟨idx, hidx_lt, ?_⟩
          have hmod_eq : idx % cnt 0 = j0 := by
            dsimp [idx]; rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hj0]
          have hdiv_eq : idx / cnt 0 = q_tl := by
            dsimp [idx]; rw [Nat.add_mul_div_left _ _ hc0, Nat.div_eq_of_lt hj0, zero_add]
          funext s
          refine Fin.cases ?_ (fun j => ?_) s
          · have hv : elig 0 j0 < M₀ := hlt 0 j0 hj0
            apply Fin.ext
            dsimp only [mixedTuple, Fin.cases_zero]
            rw [hmod_eq, dif_pos hv]
            exact he0
          · simp only [mixedTuple, Fin.cases_succ, hdiv_eq]
            exact congrFun hq_eq j
      · intro a ha b hb hab
        simp only [Finset.coe_range, Set.mem_Iio, hprod_eq] at ha hb
        have hma : a % cnt 0 < cnt 0 := Nat.mod_lt a hc0
        have hmb : b % cnt 0 < cnt 0 := Nat.mod_lt b hc0
        have h0_eq : (mixedTuple hM₀ cnt elig a 0).val = (mixedTuple hM₀ cnt elig b 0).val :=
          congrArg (fun f => (f 0).val) hab
        simp only [mixedTuple, Fin.cases_zero, dif_pos (hlt 0 _ hma), dif_pos (hlt 0 _ hmb)] at h0_eq
        have hrem_eq : a % cnt 0 = b % cnt 0 := hinj 0 _ _ hma hmb h0_eq
        have htl_eq : mixedTuple hM₀ (fun j' => cnt j'.succ) (fun j' => elig j'.succ) (a / cnt 0) =
            mixedTuple hM₀ (fun j' => cnt j'.succ) (fun j' => elig j'.succ) (b / cnt 0) := by
          funext j
          simpa [mixedTuple] using congrFun hab j.succ
        have hda : a / cnt 0 ∈ (Finset.range P_tl : Set ℕ) := by
          simp only [Finset.coe_range, Set.mem_Iio]
          exact Nat.div_lt_of_lt_mul (by omega)
        have hdb : b / cnt 0 ∈ (Finset.range P_tl : Set ℕ) := by
          simp only [Finset.coe_range, Set.mem_Iio]
          exact Nat.div_lt_of_lt_mul (by omega)
        have hdiv_eq : a / cnt 0 = b / cnt 0 := hinj_tl hda hdb htl_eq
        calc a = cnt 0 * (a / cnt 0) + a % cnt 0 := (Nat.div_add_mod a (cnt 0)).symm
          _ = cnt 0 * (b / cnt 0) + b % cnt 0 := by rw [hdiv_eq, hrem_eq]
          _ = b := Nat.div_add_mod b (cnt 0)

/-! ### 4. Pure filter slot operations & good-coin `SatisfiesConfigSearchPromise` bridge -/

structure PureFilterSlot (R ℓ M₀ d : ℕ) where
  caps : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1))
  buckets : Fin R → Fin (M₀ ^ ℓ) → List ℕ

noncomputable def PureFilterSlot.init {R ℓ M₀ d b : ℕ} (T p_coord : ℕ)
    (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b) : PureFilterSlot R ℓ M₀ d :=
  { caps := polyFDisc T p_coord ω
    buckets := fun _ _ => [] }

noncomputable def PureFilterSlot.insertPoint {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (A B τ_d : ℚ) (cap_u : ℕ) (o p_pt : EuclideanSpace ℝ (Fin d)) (h : ℕ)
    (slot : PureFilterSlot R ℓ M₀ d) : PureFilterSlot R ℓ M₀ d :=
  open Classical in
  let w := p_pt - o
  let newBuckets : Fin R → Fin (M₀ ^ ℓ) → List ℕ := fun r code =>
    let baseSets : Fin ℓ → Finset (Fin M₀) := fun s =>
      Finset.univ.filter (fun k : Fin M₀ =>
        realSignedSqCapCond (A : ℝ) (B : ℝ) (τ_d : ℝ) (slot.caps (r, s, k)) w)
    let prodSet := Fintype.piFinset baseSets
    if prodSet.card ≤ cap_u then
      if ∃ τ ∈ prodSet, encodeTuple τ = code.val then
        h :: slot.buckets r code
      else
        slot.buckets r code
    else
      slot.buckets r code
  { slot with buckets := newBuckets }

/-- Scan a list of bucket candidate handles `cands`, keeping only live handles (`inU h = true`),
stopping as soon as `remRej = 0` after `cap_q` rejections, or returning `some h` on acceptance. -/
noncomputable def scanLiveCands {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o p_v : EuclideanSpace ℝ (Fin d)) (b_thr : ℝ) (inU : ℕ → Bool) :
    ℕ → List ℕ → Option ℕ × ℕ
  | remRej, [] => (none, remRej)
  | 0, _ :: _ => (none, 0)
  | remRej + 1, h :: tl =>
      open Classical in
      if inU h = true then
        if b_thr < radialCorrelation o p_v (pts h) then
          (some h, remRej + 1)
        else
          scanLiveCands pts o p_v b_thr inU remRej tl
      else
        scanLiveCands pts o p_v b_thr inU (remRej + 1) tl

/-- Scan a list of tuple codes in copy `r` with shared live-rejection budget `cap_q + 1`. -/
noncomputable def scanCopyTuples {R ℓ M₀ d : ℕ}
    (buckets : Fin R → Fin (M₀ ^ ℓ) → List ℕ) (r : Fin R)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (b_thr : ℝ) (inU : ℕ → Bool) :
    ℕ → List (Fin (M₀ ^ ℓ)) → Option ℕ
  | _, [] => none
  | 0, _ :: _ => none
  | remRej + 1, code :: rest =>
      match scanLiveCands pts o p_v b_thr inU (remRej + 1) (buckets r code) with
      | (some h, _) => some h
      | (none, remRej') => scanCopyTuples buckets r pts o p_v b_thr inU remRej' rest

/-- Ordered query tuple list produced by mixed-radix enumeration of `min cap_q (∏ cnt_s)` tuples. -/
noncomputable def queryTupleCodeList {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (caps : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)))
    (A B τ_q : ℚ) (cap_q : ℕ) (v_lat : EuclideanSpace ℝ (Fin d)) (r : Fin R) :
    List (Fin (M₀ ^ ℓ)) :=
  open Classical in
  let eligList : Fin ℓ → List (Fin M₀) := fun s =>
    (List.finRange M₀).filter (fun k =>
      realSignedSqCapCond (A : ℝ) (-(B : ℝ)) (τ_q : ℝ) (caps (r, s, k)) v_lat)
  let cnt : Fin ℓ → ℕ := fun s => (eligList s).length
  if ∀ s : Fin ℓ, 1 ≤ cnt s then
    let elig : Fin ℓ → ℕ → ℕ := fun s j =>
      if hj : j < (eligList s).length then ((eligList s)[j]).val else 0
    let nVis := min cap_q (∏ s : Fin ℓ, cnt s)
    (List.range nVis).map (fun idx =>
      let τ := mixedTuple hM₀ cnt elig idx
      ⟨encodeTuple τ, encodeTuple_lt hM₀ τ⟩)
  else
    []

noncomputable def PureFilterSlot.query {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (M_lat : ℕ) (A B τ_q : ℚ) (b_thr : ℝ) (cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (inU : ℕ → Bool) (slot : PureFilterSlot R ℓ M₀ d) : Option ℕ :=
  let w_q := o - p_v
  let z_q := ‖w_q‖⁻¹ • w_q
  let v_lat := latVec M_lat z_q
  (List.finRange R).findSome? (fun r =>
    scanCopyTuples slot.buckets r pts o p_v b_thr inU (cap_q + 1)
      (queryTupleCodeList hM₀ slot.caps A B τ_q cap_q v_lat r))

/-! ### 5. Universal Soundness & Good-Seed Completeness of `PureFilterSlot` -/

private lemma scanLiveCands_sound {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o p_v : EuclideanSpace ℝ (Fin d)) (b_thr : ℝ) (inU : ℕ → Bool) :
    ∀ (rem : ℕ) (cands : List ℕ) {w rem'},
      scanLiveCands pts o p_v b_thr inU rem cands = (some w, rem') →
      inU w = true ∧ b_thr < radialCorrelation o p_v (pts w)
  | _, [], _, _, h => by simp [scanLiveCands] at h
  | 0, _ :: _, _, _, h => by simp [scanLiveCands] at h
  | rem + 1, c :: tl, w, rem', h => by
      unfold scanLiveCands at h
      split_ifs at h with h1 h2
      · injection h with hw _; injection hw with hcw; subst hcw; exact ⟨h1, h2⟩
      · exact scanLiveCands_sound pts o p_v b_thr inU rem tl h
      · exact scanLiveCands_sound pts o p_v b_thr inU (rem + 1) tl h

private lemma scanCopyTuples_sound {R ℓ M₀ d : ℕ}
    (buckets : Fin R → Fin (M₀ ^ ℓ) → List ℕ) (r : Fin R)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (b_thr : ℝ) (inU : ℕ → Bool) :
    ∀ (rem : ℕ) (codes : List (Fin (M₀ ^ ℓ))) {w},
      scanCopyTuples buckets r pts o p_v b_thr inU rem codes = some w →
      inU w = true ∧ b_thr < radialCorrelation o p_v (pts w)
  | _, [], _, h => by simp [scanCopyTuples] at h
  | 0, _ :: _, _, h => by simp [scanCopyTuples] at h
  | rem + 1, code :: rest, w, h => by
      unfold scanCopyTuples at h
      cases hsc : scanLiveCands pts o p_v b_thr inU (rem + 1) (buckets r code) with
      | mk ans rem' =>
        rw [hsc] at h
        cases ans with
        | some w' =>
          injection h with hw; subst hw
          exact scanLiveCands_sound pts o p_v b_thr inU (rem + 1) (buckets r code) hsc
        | none =>
          exact scanCopyTuples_sound buckets r pts o p_v b_thr inU rem' rest h

theorem pureFilterSlot_query_sound {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (M_lat : ℕ) (A B τ_q : ℚ) (b_thr : ℝ) (cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (inU : ℕ → Bool) (slot : PureFilterSlot R ℓ M₀ d) {w : ℕ}
    (hans : slot.query hM₀ M_lat A B τ_q b_thr cap_q pts o p_v inU = some w) :
    inU w = true ∧ b_thr < radialCorrelation o p_v (pts w) := by
  unfold PureFilterSlot.query at hans
  rw [List.findSome?_eq_some_iff] at hans
  obtain ⟨_, r, _, _, hscan, _⟩ := hans
  exact scanCopyTuples_sound slot.buckets r pts o p_v b_thr inU (cap_q + 1) _ hscan

/-- Default unit vector `(0, ..., 0, 1) ∈ ℝ^{d+1}` used to pad `SearchGeneration` to fixed size `N_pad`. -/
noncomputable def padDummyUnitVec (d : ℕ) : EuclideanSpace ℝ (Fin (d + 1)) :=
  liftedPoint 0 1

theorem isUnitVec_padDummy (d : ℕ) : IsUnitVec (padDummyUnitVec d) := by
  unfold IsUnitVec padDummyUnitVec
  have hsq : ‖(liftedPoint (0 : EuclideanSpace ℝ (Fin d)) 1)‖ ^ 2 = 1 := by
    rw [norm_sq_eq_sum_coords, Fin.sum_univ_castSucc]
    simp [liftedPoint, euclideanCoord, Fin.snoc_castSucc, Fin.snoc_last]
  nlinarith [norm_nonneg (liftedPoint (0 : EuclideanSpace ℝ (Fin d)) 1)]

/-- Padded `SearchGeneration (Fin N_pad) (d + 1)` for a block of `sz ≤ N_pad` inserted handles
`arr : Fin sz → ℕ` (with `pts (arr j) ≠ o`). -/
noncomputable def mkPaddedGeneration {d N_pad sz : ℕ} (hN : 1 ≤ N_pad)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (A B : ℚ) (hAB : A ^ 2 + B ^ 2 = 1)
    (h : ℝ) (hh0 : 0 < h) (hh1 : h < 1)
    (arr : Fin sz → ℕ) (hne_o : ∀ j : Fin sz, pts (arr j) ≠ o) :
    SearchGeneration (Fin N_pad) (d + 1) :=
  { P₀ := Finset.univ
    pts := fun k =>
      if hlt : k.val < sz then
        liftedPoint ((A : ℝ) • radialDirection o (pts (arr ⟨k.val, hlt⟩))) (B : ℝ)
      else
        padDummyUnitVec d
    nonempty := ⟨⟨0, hN⟩, Finset.mem_univ _⟩
    unit_pts := fun k _ => by
      dsimp only
      split_ifs with hlt
      · have hw_ne : pts (arr ⟨k.val, hlt⟩) - o ≠ 0 := sub_ne_zero.mpr (hne_o ⟨k.val, hlt⟩)
        have hw_pos : 0 < ‖pts (arr ⟨k.val, hlt⟩) - o‖ := norm_pos_iff.mpr hw_ne
        have hu : ‖radialDirection o (pts (arr ⟨k.val, hlt⟩))‖ = 1 := by
          unfold radialDirection
          rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hw_pos.ne']
        exact isUnitVec_lifted_of_sq hu (by exact_mod_cast hAB)
      · exact isUnitVec_padDummy d
    h := h
    h_pos := hh0
    h_lt_one := hh1 }

@[simp]
theorem mkPaddedGeneration_m {d N_pad sz : ℕ} (hN : 1 ≤ N_pad)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (A B : ℚ) (hAB : A ^ 2 + B ^ 2 = 1)
    (h : ℝ) (hh0 : 0 < h) (hh1 : h < 1)
    (arr : Fin sz → ℕ) (hne_o : ∀ j : Fin sz, pts (arr j) ≠ o) :
    (mkPaddedGeneration hN pts o A B hAB h hh0 hh1 arr hne_o).m = N_pad := by
  simp [SearchGeneration.m, mkPaddedGeneration]

/-- Build a `PureFilterSlot` on an array `arr : Fin sz → ℕ` of handles sequentially `j = 0 .. sz - 1`. -/
noncomputable def buildSlotOnBlock {R ℓ M₀ d b sz : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (A B τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (arr : Fin sz → ℕ) (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b) :
    PureFilterSlot R ℓ M₀ d :=
  Fin.foldl sz
    (fun sl j => sl.insertPoint hM₀ A B τ_d cap_u o (pts (arr j)) (arr j))
    (PureFilterSlot.init T p_coord ω)

private lemma buildSlotOnBlock_caps {R ℓ M₀ d b sz : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (A B τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (arr : Fin sz → ℕ) (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b) :
    (buildSlotOnBlock hM₀ T p_coord A B τ_d cap_u pts o arr ω).caps = polyFDisc T p_coord ω := by
  unfold buildSlotOnBlock
  suffices ∀ (k : ℕ) (sl : PureFilterSlot R ℓ M₀ d) (f : Fin k → ℕ),
      (Fin.foldl k (fun s j => s.insertPoint hM₀ A B τ_d cap_u o (pts (f j)) (f j)) sl).caps = sl.caps by
    exact this sz (PureFilterSlot.init T p_coord ω) arr
  intro k
  induction k with
  | zero => intro sl _; simp [Fin.foldl_zero]
  | succ k ih =>
      intro sl f
      rw [Fin.foldl_succ_last]
      dsimp [PureFilterSlot.insertPoint]
      exact ih sl (fun j => f j.castSucc)

/-- Exact bucket membership characterization of `buildSlotOnBlock`: `buckets r code` consists of
`arr j` (in reverse index order) for those `j : Fin sz` whose `explicitStoredTuples` contains the
unique `τ` with `encodeTuple τ = code.val`! -/
theorem buildSlotOnBlock_buckets_eq {R ℓ M₀ d b sz : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (A B τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d))
    (arr : Fin sz → ℕ) (hne_o : ∀ j : Fin sz, pts (arr j) ≠ o)
    (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (r : Fin R) (code : Fin (M₀ ^ ℓ)) :
    open Classical in
    let F := polyFDisc T p_coord ω
    let padPt : Fin sz → EuclideanSpace ℝ (Fin (d + 1)) := fun j =>
      liftedPoint ((A : ℝ) • radialDirection o (pts (arr j))) (B : ℝ)
    (buildSlotOnBlock hM₀ T p_coord A B τ_d cap_u pts o arr ω).buckets r code =
      ((List.finRange sz).reverse.filter (fun j =>
        ∃ τ ∈ explicitStoredTuples F (τ_d : ℝ) cap_u padPt r j, encodeTuple τ = code.val)).map arr := by
  classical
  intro F padPt
  -- Base-cap equivalence via `real_cap_test_iff`
  have hbase_eq : ∀ (j : Fin sz) (s : Fin ℓ),
      (Finset.univ.filter (fun k : Fin M₀ =>
        realSignedSqCapCond (A : ℝ) (B : ℝ) (τ_d : ℝ) (F (r, s, k)) (pts (arr j) - o))) =
      explicitDataBaseSet F (τ_d : ℝ) (padPt j) r s := by
    intro j s
    ext k
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, explicitDataBaseSet]
    have hw_ne : pts (arr j) - o ≠ 0 := sub_ne_zero.mpr (hne_o j)
    exact (real_cap_test_iff (A : ℝ) (B : ℝ) (τ_d : ℝ) (F (r, s, k)) (pts (arr j) - o) hw_ne).symm
  -- Prove by induction on prefix length `m ≤ sz`
  suffices h_ind : ∀ (m : ℕ) (hm : m ≤ sz),
      let subArr : Fin m → ℕ := fun j => arr ⟨j.val, lt_of_lt_of_le j.isLt hm⟩
      (Fin.foldl m (fun sl j => sl.insertPoint hM₀ A B τ_d cap_u o (pts (subArr j)) (subArr j))
        (PureFilterSlot.init T p_coord ω)).buckets r code =
      ((List.finRange m).reverse.filter (fun j : Fin m =>
        ∃ τ ∈ explicitStoredTuples F (τ_d : ℝ) cap_u
          (fun j' : Fin m => padPt ⟨j'.val, lt_of_lt_of_le j'.isLt hm⟩) r j,
          encodeTuple τ = code.val)).map subArr by
    simpa [buildSlotOnBlock] using h_ind sz le_rfl
  intro m
  induction m with
  | zero => intro _; simp [PureFilterSlot.init]
  | succ m ih =>
      intro hm
      let subArr : Fin (m + 1) → ℕ := fun j => arr ⟨j.val, lt_of_lt_of_le j.isLt hm⟩
      let prevArr : Fin m → ℕ := fun j => arr ⟨j.val, lt_of_lt_of_le j.isLt (Nat.le_of_succ_le hm)⟩
      let prevSlot := Fin.foldl m
        (fun sl j => sl.insertPoint hM₀ A B τ_d cap_u o (pts (prevArr j)) (prevArr j))
        (PureFilterSlot.init T p_coord ω)
      have hcaps_prev : prevSlot.caps = F :=
        buildSlotOnBlock_caps hM₀ T p_coord A B τ_d cap_u pts o prevArr ω
      have hprev_b := ih (Nat.le_of_succ_le hm)
      dsimp only
      rw [Fin.foldl_succ_last]
      change (prevSlot.insertPoint hM₀ A B τ_d cap_u o (pts (subArr (Fin.last m))) (subArr (Fin.last m))).buckets r code = _
      dsimp only [PureFilterSlot.insertPoint]
      rw [hcaps_prev]
      let j_last : Fin sz := ⟨m, hm⟩
      have hbase_last : (fun s : Fin ℓ => Finset.univ.filter (fun k : Fin M₀ =>
          realSignedSqCapCond (A : ℝ) (B : ℝ) (τ_d : ℝ) (F (r, s, k)) (pts (subArr (Fin.last m)) - o))) =
          (fun s : Fin ℓ => explicitDataBaseSet F (τ_d : ℝ) (padPt j_last) r s) :=
        funext (fun s => hbase_eq j_last s)
      rw [hbase_last]
      -- Simplify `(List.finRange (m + 1)).reverse` = `Fin.last m :: (List.finRange m).reverse.map Fin.castSucc`
      have hrev_succ : (List.finRange (m + 1)).reverse =
          Fin.last m :: ((List.finRange m).reverse.map Fin.castSucc) := by
        rw [List.finRange_succ_last, List.reverse_append, List.reverse_singleton, List.singleton_append,
          List.map_reverse]
      rw [hrev_succ]
      have hidx_last : (⟨(Fin.last m).val, lt_of_lt_of_le (Fin.last m).isLt hm⟩ : Fin sz) = j_last :=
        Fin.ext rfl
      have hstored_last :
          (∃ τ ∈ explicitStoredTuples F (τ_d : ℝ) cap_u
              (fun j' : Fin (m + 1) => padPt ⟨j'.val, lt_of_lt_of_le j'.isLt hm⟩) r (Fin.last m),
            encodeTuple τ = code.val) ↔
          ((Fintype.piFinset (fun s => explicitDataBaseSet F (τ_d : ℝ) (padPt j_last) r s)).card ≤ cap_u ∧
           ∃ τ ∈ Fintype.piFinset (fun s => explicitDataBaseSet F (τ_d : ℝ) (padPt j_last) r s),
             encodeTuple τ = code.val) := by
        unfold explicitStoredTuples
        dsimp only
        rw [hidx_last]
        by_cases hcu : (Fintype.piFinset (fun s => explicitDataBaseSet F (τ_d : ℝ) (padPt j_last) r s)).card ≤ cap_u
        · rw [if_pos hcu]
          exact ⟨fun h => ⟨hcu, h⟩, fun h => h.2⟩
        · rw [if_neg hcu]
          exact ⟨fun ⟨_, hmem, _⟩ => absurd hmem (Finset.notMem_empty _), fun h => absurd h.1 hcu⟩
      have htail_eq :
          ((((List.finRange m).reverse.map Fin.castSucc).filter (fun j : Fin (m + 1) =>
            decide (∃ τ ∈ explicitStoredTuples F (τ_d : ℝ) cap_u
                (fun j' : Fin (m + 1) => padPt ⟨j'.val, lt_of_lt_of_le j'.isLt hm⟩) r j,
              encodeTuple τ = code.val))).map subArr) =
          prevSlot.buckets r code := by
        rw [List.filter_map, List.map_map, hprev_b]
        rfl
      by_cases hcond : (Fintype.piFinset (fun s => explicitDataBaseSet F (τ_d : ℝ) (padPt j_last) r s)).card ≤ cap_u ∧
          ∃ τ ∈ Fintype.piFinset (fun s => explicitDataBaseSet F (τ_d : ℝ) (padPt j_last) r s),
            encodeTuple τ = code.val
      · rw [if_pos hcond.1, if_pos hcond.2,
            List.filter_cons_of_pos (by simp only [decide_eq_true_eq]; exact hstored_last.mpr hcond),
            List.map_cons, htail_eq]
      · have hnot_st : ¬ (∃ τ ∈ explicitStoredTuples F (τ_d : ℝ) cap_u
              (fun j' : Fin (m + 1) => padPt ⟨j'.val, lt_of_lt_of_le j'.isLt hm⟩) r (Fin.last m),
            encodeTuple τ = code.val) := fun h => hcond (hstored_last.mp h)
        rw [List.filter_cons_of_neg (by simp only [decide_eq_true_eq]; exact hnot_st), htail_eq]
        by_cases h1 : (Fintype.piFinset (fun s => explicitDataBaseSet F (τ_d : ℝ) (padPt j_last) r s)).card ≤ cap_u
        · have h2 : ¬ ∃ τ ∈ Fintype.piFinset (fun s => explicitDataBaseSet F (τ_d : ℝ) (padPt j_last) r s),
              encodeTuple τ = code.val := fun h => hcond ⟨h1, h⟩
          rw [if_pos h1, if_neg h2]
        · rw [if_neg h1]

/-- **Master Good-Seed Completeness Theorem (`pureFilterSlot_query_complete`)**:
If `ω` satisfies `IsOrderIndepGoodFilter` on `mkPaddedGeneration` (`sz ≤ N_pad`), and `(A, B)` has
Lemma 9.1's correlation-threshold separation for `(a_thr, b_thr)` with `b_thr ≥ 0`, then whenever
`slot.query ... = none`, NO handle `w_star` in the block (`w_star = arr j_star` with `inU w_star = true`)
can have `a_thr ≤ radialCorrelation o p_v (pts w_star)`! -/
theorem pureFilterSlot_query_complete {R ℓ M₀ d b N_pad sz : ℕ}
    (hd : 1 ≤ d) (hM₀ : 1 ≤ M₀) (hN : 1 ≤ N_pad) (hsz : sz ≤ N_pad)
    (T p_coord : ℕ) (e A B τ_d τ_q : ℚ) (he0 : 0 < (e : ℝ)) (he1 : (e : ℝ) ≤ 1)
    (hAB : A ^ 2 + B ^ 2 = 1)
    (h a_thr b_thr : ℝ) (hh0 : 0 < h) (hh1 : h < 1)
    (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (hpv : p_v ≠ o)
    (arr : Fin sz → ℕ) (hne_o : ∀ j : Fin sz, pts (arr j) ≠ o)
    (inU : ℕ → Bool)
    (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (hsep : ∀ (u z z_bar : EuclideanSpace ℝ (Fin d)),
      ‖u‖ = 1 → ‖z‖ = 1 → ‖z_bar‖ = 1 → ‖z_bar - z‖ ≤ (e : ℝ) / 8 →
      (a_thr ≤ inner ℝ z u →
        h ≤ inner ℝ (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ))) (liftedPoint ((A : ℝ) • u) (B : ℝ))) ∧
      (inner ℝ z u ≤ b_thr →
        inner ℝ (liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ))) (liftedPoint ((A : ℝ) • u) (B : ℝ)) < 0))
    (hGood : IsOrderIndepGoodFilter (polyFDisc T p_coord ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q
      (mkPaddedGeneration hN pts o A B hAB h hh0 hh1 arr hne_o)
      (paddedLatNet (M_lat_of d e) A B))
    (hnone : (buildSlotOnBlock hM₀ T p_coord A B τ_d cap_u pts o arr ω).query hM₀
      (M_lat_of d e) A B τ_q b_thr cap_q pts o p_v inU = none) :
    ∀ j_star : Fin sz, inU (arr j_star) = true →
      radialCorrelation o p_v (pts (arr j_star)) < a_thr := by
  classical
  set gen := mkPaddedGeneration hN pts o A B hAB h hh0 hh1 arr hne_o
  set M_lat := M_lat_of d e
  set Q_net := paddedLatNet (d := d) M_lat A B
  set F := polyFDisc T p_coord ω
  set slot := buildSlotOnBlock hM₀ T p_coord A B τ_d cap_u pts o arr ω
  have hcaps_eq : slot.caps = F := buildSlotOnBlock_caps hM₀ T p_coord A B τ_d cap_u pts o arr ω
  -- Query vector geometry: `w_q = o - p_v = -(p_v - o) ≠ 0`, so `z_q = -radialDirection o p_v`!
  let w_q := o - p_v
  have hwq_ne : w_q ≠ 0 := sub_ne_zero.mpr hpv.symm
  let z_q := ‖w_q‖⁻¹ • w_q
  have hzq_eq_neg : z_q = -radialDirection o p_v := by
    dsimp [z_q, w_q, radialDirection]
    have hn : ‖o - p_v‖ = ‖p_v - o‖ := norm_sub_rev o p_v
    rw [hn, ← smul_neg, neg_sub]
  have hw_pv_pos : 0 < ‖p_v - o‖ := norm_pos_iff.mpr (sub_ne_zero.mpr hpv)
  have hzq_unit : ‖z_q‖ = 1 := by
    rw [hzq_eq_neg, norm_neg]; unfold radialDirection
    rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hw_pv_pos.ne']
  obtain ⟨hQ_unit, _, hlat_spec⟩ := concrete_paddedLatNet_spec hd he0 he1 hAB
  obtain ⟨hv_ne, hz_bar_unit, hz_bar_dist, hqz_mem⟩ := hlat_spec w_q hwq_ne
  let v_lat := latVec M_lat z_q
  let z_bar := ‖v_lat‖⁻¹ • v_lat
  let qz := liftedPoint ((A : ℝ) • z_bar) (-(B : ℝ))
  have hqz_unit : IsUnitVec qz := hQ_unit qz hqz_mem
  -- Define surviving subset `P_surv ⊆ Fin N_pad` and compatible `SearchQuery`
  let P_surv : Finset (Fin N_pad) :=
    Finset.univ.filter (fun k : Fin N_pad => ∃ hlt : k.val < sz, inU (arr ⟨k.val, hlt⟩) = true)
  let qry : SearchQuery (Fin N_pad) (d + 1) :=
    { z := qz
      unit_z := hqz_unit
      accept := fun k => ∃ hlt : k.val < sz, b_thr < radialCorrelation o p_v (pts (arr ⟨k.val, hlt⟩)) }
  have hP_sub : gen.IsSurvivingSubset P_surv := Finset.subset_univ _
  have hcompat : gen.IsCompatible P_surv qry := by
    intro k hk hrej
    obtain ⟨_, hlt, _⟩ := Finset.mem_filter.mp hk
    have hle_b : radialCorrelation o p_v (pts (arr ⟨k.val, hlt⟩)) ≤ b_thr := by
      by_contra hgt; exact hrej ⟨hlt, lt_of_not_ge hgt⟩
    have hcorr_eq : radialCorrelation o p_v (pts (arr ⟨k.val, hlt⟩)) =
        inner ℝ z_q (radialDirection o (pts (arr ⟨k.val, hlt⟩))) := by
      rw [hzq_eq_neg]; rfl
    rw [hcorr_eq] at hle_b
    have hu_k : ‖radialDirection o (pts (arr ⟨k.val, hlt⟩))‖ = 1 := by
      unfold radialDirection
      have hp := norm_pos_iff.mpr (sub_ne_zero.mpr (hne_o ⟨k.val, hlt⟩))
      rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hp.ne']
    have hneg := (hsep _ z_q z_bar hu_k hzq_unit hz_bar_unit hz_bar_dist).2 hle_b
    have hgen_pt : gen.pts k = liftedPoint ((A : ℝ) • radialDirection o (pts (arr ⟨k.val, hlt⟩))) (B : ℝ) := by
      dsimp [gen, mkPaddedGeneration]; rw [dif_pos hlt]
    rw [hgen_pt, real_inner_comm]
    exact hneg.le
  -- Apply `orderIndep_bucketQuery_correct` with `ans := none`!
  have hcorr_ans : gen.IsCorrectAnswer P_surv qry none := by
    refine orderIndep_bucketQuery_correct F (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen Q_net hGood
      P_surv hP_sub qry hqz_mem hcompat none (fun _ h => by cases h) ?_
    intro r QSet hQcard hBadCard ⟨k_star, hk_star_P, τ_star, hτ_Q, hτ_stored, hk_acc⟩ _
    -- Show copy `r` in `slot.query` MUST return `some _`, contradicting `hnone`!
    have hr_none : scanCopyTuples slot.buckets r pts o p_v b_thr inU (cap_q + 1)
        (queryTupleCodeList hM₀ slot.caps A B τ_q cap_q v_lat r) = none := by
      unfold PureFilterSlot.query at hnone
      rw [List.findSome?_eq_none_iff] at hnone
      exact hnone r (List.mem_finRange r)
    have hqbase_eq : ∀ s : Fin ℓ,
        ((List.finRange M₀).filter (fun k =>
          realSignedSqCapCond (A : ℝ) (-(B : ℝ)) (τ_q : ℝ) (F (r, s, k)) v_lat)).toFinset =
        explicitQueryBaseSet F (τ_q : ℝ) qz r s := by
      intro s; ext k
      simp only [List.mem_toFinset, List.mem_filter, List.mem_finRange, true_and,
        decide_eq_true_eq, explicitQueryBaseSet, Finset.mem_filter, Finset.mem_univ]
      exact (real_cap_test_iff (A : ℝ) (-(B : ℝ)) (τ_q : ℝ) (F (r, s, k)) v_lat hv_ne).symm
    let eligList : Fin ℓ → List (Fin M₀) := fun s =>
      (List.finRange M₀).filter (fun k =>
        realSignedSqCapCond (A : ℝ) (-(B : ℝ)) (τ_q : ℝ) (F (r, s, k)) v_lat)
    have helig_nodup : ∀ s, (eligList s).Nodup :=
      fun s => (List.nodup_finRange M₀).filter _
    have hcnt_pos : ∀ s : Fin ℓ, 1 ≤ (eligList s).length := by
      intro s
      have hmem_s : τ_star s ∈ explicitQueryBaseSet F (τ_q : ℝ) qz r s :=
        Fintype.mem_piFinset.mp hτ_Q s
      rw [← hqbase_eq s, List.mem_toFinset] at hmem_s
      exact List.length_pos_of_mem hmem_s
    have hprod_eq_card : (∏ s : Fin ℓ, (eligList s).length) = QSet.card := by
      dsimp [QSet]
      rw [Fintype.card_piFinset]
      refine Finset.prod_congr rfl fun s _ => ?_
      rw [← hqbase_eq s, List.toFinset_card_of_nodup (helig_nodup s)]
    let cnt : Fin ℓ → ℕ := fun s => (eligList s).length
    let elig : Fin ℓ → ℕ → ℕ := fun s j =>
      if hj : j < (eligList s).length then ((eligList s)[j]).val else 0
    obtain ⟨himg_Q, hinj_Q⟩ := mixedTuple_image_range hM₀
      (fun s => explicitQueryBaseSet F (τ_q : ℝ) qz r s) cnt elig hcnt_pos
      (fun s k => by
        dsimp only
        rw [← hqbase_eq s, List.mem_toFinset]
        constructor
        · intro hk
          obtain ⟨j, hj, hget⟩ := List.getElem_of_mem hk
          exact ⟨j, hj, by dsimp only [elig]; rw [dif_pos hj, hget]⟩
        · rintro ⟨j, hj, heq⟩
          dsimp only [elig] at heq; rw [dif_pos hj] at heq
          have hk_eq : (eligList s)[j] = k := Fin.ext heq
          rw [← hk_eq]; exact List.getElem_mem hj)
      (fun s j hj => by dsimp only [elig]; rw [dif_pos hj]; exact ((eligList s)[j]).isLt)
      (fun s j₁ j₂ hj₁ hj₂ heq => by
        dsimp only [elig] at heq; rw [dif_pos hj₁, dif_pos hj₂] at heq
        exact (helig_nodup s).getElem_inj_iff.mp (Fin.ext heq))
    have hmin_eq : min cap_q (∏ s : Fin ℓ, cnt s) = ∏ s : Fin ℓ, cnt s :=
      min_eq_right (hprod_eq_card.symm ▸ hQcard)
    have hcodes_eq : queryTupleCodeList hM₀ slot.caps A B τ_q cap_q v_lat r =
        (List.range (∏ s : Fin ℓ, cnt s)).map (fun idx =>
          let τ := mixedTuple hM₀ cnt elig idx
          ⟨encodeTuple τ, encodeTuple_lt hM₀ τ⟩) := by
      rw [hcaps_eq]; unfold queryTupleCodeList
      dsimp only
      rw [if_pos hcnt_pos, hmin_eq]
    rw [hcodes_eq] at hr_none
    -- Notice `τ_star ∈ QSet`, so `τ_star = mixedTuple hM₀ cnt elig idx_star` for some `idx_star < ∏ cnt`!
    have hτ_in_img : τ_star ∈ (Finset.range (∏ s : Fin ℓ, cnt s)).image (mixedTuple hM₀ cnt elig) := by
      rwa [himg_Q]
    obtain ⟨idx_star, hidx_range, hτ_idx⟩ := Finset.mem_image.mp hτ_in_img
    let code_star : Fin (M₀ ^ ℓ) := ⟨encodeTuple τ_star, encodeTuple_lt hM₀ τ_star⟩
    have hcode_mem : code_star ∈ (List.range (∏ s : Fin ℓ, cnt s)).map (fun idx =>
        let τ := mixedTuple hM₀ cnt elig idx
        (⟨encodeTuple τ, encodeTuple_lt hM₀ τ⟩ : Fin (M₀ ^ ℓ))) := by
      refine List.mem_map.mpr ⟨idx_star, List.mem_range.mpr (Finset.mem_range.mp hidx_range), ?_⟩
      ext; dsimp [code_star]; rw [hτ_idx]
    -- Also `k_star ∈ P_surv` implies `k_star.val < sz` and `arr ⟨k_star.val, hlt⟩ ∈ slot.buckets r code_star`
    -- with `inU = true` and `b_thr < radialCorrelation`!
    obtain ⟨_, hlt_star, hinU_star⟩ := Finset.mem_filter.mp hk_star_P
    obtain ⟨_, hacc_star⟩ := hk_acc
    let j_star : Fin sz := ⟨k_star.val, hlt_star⟩
    have hbkt_star : arr j_star ∈ slot.buckets r code_star := by
      rw [buildSlotOnBlock_buckets_eq hM₀ T p_coord A B τ_d cap_u pts o arr hne_o ω r code_star]
      refine List.mem_map.mpr ⟨j_star, ?_, rfl⟩
      rw [List.mem_filter]
      refine ⟨List.mem_reverse.mpr (List.mem_finRange j_star), ?_⟩
      rw [decide_eq_true_eq]
      refine ⟨τ_star, ?_, rfl⟩
      -- `explicitStoredTuples` agrees between `gen.pts k_star` and `padPt j_star`!
      have hpt_eq : (fun j : Fin sz => liftedPoint ((A : ℝ) • radialDirection o (pts (arr j))) (B : ℝ)) j_star =
          gen.pts k_star := by
        dsimp [gen, mkPaddedGeneration, j_star]; rw [dif_pos hlt_star]
      unfold explicitStoredTuples at hτ_stored ⊢
      rwa [hpt_eq]
    -- Key counting lemma: on any sublist of distinct `QSet` codes, if `scanCopyTuples` returns `none`,
    -- then EITHER `rem` never hit `0` (so EVERY live accepted candidate in every visited bucket was tested — impossible since `arr j_star` accepts!),
    -- OR total live rejected visits across those distinct codes was `≥ cap_q + 1`, contradicting `hBadCard : ... ≤ cap_q`!
    have hcodes_nodup : ((List.range (∏ s : Fin ℓ, cnt s)).map (fun idx =>
        let τ := mixedTuple hM₀ cnt elig idx
        (⟨encodeTuple τ, encodeTuple_lt hM₀ τ⟩ : Fin (M₀ ^ ℓ)))).Nodup := by
      rw [List.nodup_map_iff_inj_on List.nodup_range]
      intro a ha b hb heq
      have hτ_eq := encodeTuple_injective hM₀ (congrArg Fin.val heq)
      exact hinj_Q (Finset.mem_coe.mpr (Finset.mem_range.mpr (List.mem_range.mp ha)))
                   (Finset.mem_coe.mpr (Finset.mem_range.mpr (List.mem_range.mp hb))) hτ_eq
    -- Count live rejected entries in `buckets r code` using a single shared predicate `isLiveRej`:
    let isLiveRej : ℕ → Bool := fun h_c =>
      inU h_c && decide (¬ b_thr < radialCorrelation o p_v (pts h_c))
    let rejCountCode : Fin (M₀ ^ ℓ) → ℕ := fun cd =>
      ((slot.buckets r cd).filter isLiveRej).length
    have hscan_cands_none : ∀ (cands : List ℕ) (rem rem' : ℕ),
        scanLiveCands pts o p_v b_thr inU rem cands = (none, rem') →
        (rem' = 0 ∧ rem ≤ (cands.filter isLiveRej).length) ∨
        (1 ≤ rem' ∧
          rem = rem' + (cands.filter isLiveRej).length ∧
          ∀ h_c ∈ cands, inU h_c = true → ¬ b_thr < radialCorrelation o p_v (pts h_c)) := by
      intro cands
      induction cands with
      | nil =>
          intro rem rem' hsc
          simp only [scanLiveCands, Prod.mk.injEq, true_and] at hsc
          subst hsc
          by_cases hr0 : rem = 0
          · subst hr0; exact Or.inl ⟨rfl, Nat.zero_le _⟩
          · exact Or.inr ⟨by omega, by simp, fun _ hm => by cases hm⟩
      | cons c tl ih =>
          intro rem rem' hsc
          cases rem with
          | zero =>
              simp only [scanLiveCands, Prod.mk.injEq, true_and] at hsc
              exact Or.inl ⟨hsc.symm, Nat.zero_le _⟩
          | succ r0 =>
              unfold scanLiveCands at hsc
              by_cases hu : inU c = true
              · rw [if_pos hu] at hsc
                by_cases hgt : b_thr < radialCorrelation o p_v (pts c)
                · rw [if_pos hgt] at hsc; simp at hsc
                · rw [if_neg hgt] at hsc
                  have hfilt : ((c :: tl).filter isLiveRej).length =
                      1 + (tl.filter isLiveRej).length := by
                    rw [List.filter_cons_of_pos (by dsimp only [isLiveRej]; simp [hu, hgt]), List.length_cons]; omega
                  rcases ih r0 rem' hsc with ⟨hr0', hle⟩ | ⟨hge1, heq, hall⟩
                  · exact Or.inl ⟨hr0', by omega⟩
                  · refine Or.inr ⟨hge1, by omega, fun h_c hmc hin => ?_⟩
                    rcases List.mem_cons.mp hmc with rfl | htl
                    · exact hgt
                    · exact hall h_c htl hin
              · rw [if_neg hu] at hsc
                have hfilt : (c :: tl).filter isLiveRej = tl.filter isLiveRej :=
                  List.filter_cons_of_neg (by simp [isLiveRej, hu])
                rw [hfilt]
                rcases ih (r0 + 1) rem' hsc with ⟨hr0', hle⟩ | ⟨hge1, heq, hall⟩
                · exact Or.inl ⟨hr0', hle⟩
                · refine Or.inr ⟨hge1, heq, fun h_c hmc hin => ?_⟩
                  rcases List.mem_cons.mp hmc with rfl | htl
                  · exact absurd hin hu
                  · exact hall h_c htl hin
    have hscan_tuples_none : ∀ (codes : List (Fin (M₀ ^ ℓ))) (rem : ℕ),
        scanCopyTuples slot.buckets r pts o p_v b_thr inU rem codes = none →
        rem ≤ (codes.map rejCountCode).sum ∨
        (∀ cd ∈ codes, ∀ h_c ∈ slot.buckets r cd,
          inU h_c = true → ¬ b_thr < radialCorrelation o p_v (pts h_c)) := by
      intro codes
      induction codes with
      | nil =>
          intro _ _; exact Or.inr (fun _ hm => by cases hm)
      | cons cd rest ih =>
          intro rem hsc
          cases rem with
          | zero => exact Or.inl (Nat.zero_le _)
          | succ r0 =>
              unfold scanCopyTuples at hsc
              cases hcand : scanLiveCands pts o p_v b_thr inU (r0 + 1) (slot.buckets r cd) with
              | mk ans rem' =>
                rw [hcand] at hsc
                cases ans with
                | some _ => cases hsc
                | none =>
                  rcases hscan_cands_none (slot.buckets r cd) (r0 + 1) rem' hcand with
                    ⟨_, hle⟩ | ⟨_, heq, hall_cd⟩
                  · refine Or.inl ?_
                    simp only [List.map_cons, List.sum_cons]
                    have hle' : r0 + 1 ≤ rejCountCode cd := hle
                    omega
                  · rcases ih rem' hsc with hle_rest | hall_rest
                    · refine Or.inl ?_
                      simp only [List.map_cons, List.sum_cons]
                      have heq' : r0 + 1 = rem' + rejCountCode cd := heq
                      omega
                    · refine Or.inr (fun cd' hcd' h_c hmc hin => ?_)
                      rcases List.mem_cons.mp hcd' with rfl | hrest
                      · exact hall_cd h_c hmc hin
                      · exact hall_rest cd' hrest h_c hmc hin
    -- Upper-bound `(codes.map rejCountCode).sum` by `((gen.P₀ ×ˢ QSet).filter bad).card ≤ cap_q`!
    let codes := (List.range (∏ s : Fin ℓ, cnt s)).map (fun idx =>
      let τ := mixedTuple hM₀ cnt elig idx
      (⟨encodeTuple τ, encodeTuple_lt hM₀ τ⟩ : Fin (M₀ ^ ℓ)))
    rcases hscan_tuples_none codes (cap_q + 1) hr_none with hexhaust | hall_rej
    · -- Budget exhausted: `cap_q + 1 ≤ (codes.map rejCountCode).sum ≤ cap_q`, contradiction!
      have hrej_code_le : ∀ idx < ∏ s : Fin ℓ, cnt s,
          let τ := mixedTuple hM₀ cnt elig idx
          let cd : Fin (M₀ ^ ℓ) := ⟨encodeTuple τ, encodeTuple_lt hM₀ τ⟩
          rejCountCode cd ≤ ((gen.P₀).filter (fun k : Fin N_pad =>
            (∀ s : Fin ℓ, gaussianDataTest (τ_d : ℝ) (F (r, s, τ s)) (gen.pts k)) ∧
              inner ℝ (gen.pts k) qz ≤ 0)).card := by
        intro idx hidx τ cd
        dsimp [rejCountCode]
        rw [buildSlotOnBlock_buckets_eq hM₀ T p_coord A B τ_d cap_u pts o arr hne_o ω r cd]
        rw [List.filter_map, List.length_map]
        let filtJ := ((List.finRange sz).reverse.filter (fun j =>
          ∃ τ' ∈ explicitStoredTuples F (τ_d : ℝ) cap_u
            (fun j' => liftedPoint ((A : ℝ) • radialDirection o (pts (arr j'))) (B : ℝ)) r j,
            encodeTuple τ' = cd.val)).filter (isLiveRej ∘ arr)
        change filtJ.length ≤ _
        have hnodup_J : filtJ.Nodup :=
          List.Nodup.filter _ (List.Nodup.filter _ (List.nodup_reverse.mpr (List.nodup_finRange sz)))
        rw [← List.toFinset_card_of_nodup hnodup_J]
        let embN : Fin sz ↪ Fin N_pad := ⟨fun j => ⟨j.val, lt_of_lt_of_le j.isLt hsz⟩,
          fun a b h => by dsimp only at h; exact Fin.ext (Fin.mk.inj h)⟩
        rw [← Finset.card_map embN]
        refine Finset.card_le_card (fun k hk => ?_)
        rcases Finset.mem_map.mp hk with ⟨j, hj_fs, rfl⟩
        have hj_mem := List.mem_toFinset.mp hj_fs
        have hj_f1 := (List.mem_filter.mp hj_mem).1
        have hj_f2 := (List.mem_filter.mp hj_mem).2
        have hj_st := (List.mem_filter.mp hj_f1).2
        simp only [Function.comp_apply, isLiveRej, Bool.and_eq_true, decide_eq_true_eq] at hj_f2 hj_st
        obtain ⟨τ', hτ'_st, hτ'_code⟩ := hj_st
        have hτ'_eq : τ' = τ := encodeTuple_injective hM₀ hτ'_code
        subst hτ'_eq
        refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_, ?_⟩
        · intro s
          unfold explicitStoredTuples at hτ'_st
          dsimp only at hτ'_st
          split_ifs at hτ'_st with hcu_j
          · have h_in := Fintype.mem_piFinset.mp hτ'_st s
            simp only [explicitDataBaseSet, Finset.mem_filter, Finset.mem_univ, true_and] at h_in
            dsimp [gen, mkPaddedGeneration, embN]
            simp only [j.isLt, ↓reduceIte]
            exact h_in
          · simp at hτ'_st
        · have hk_in_P : embN j ∈ P_surv :=
            Finset.mem_filter.mpr ⟨Finset.mem_univ _, j.isLt, hj_f2.1⟩
          have hk_rej : ¬ qry.accept (embN j) := by
            rintro ⟨_, hgt⟩
            exact hj_f2.2 hgt
          exact hcompat (embN j) hk_in_P hk_rej
      -- Sum over `idx < ∏ cnt`
      have hlist_sum_range : ∀ (N : ℕ) (g : ℕ → ℕ),
          ((List.range N).map g).sum = ∑ idx ∈ Finset.range N, g idx := by
        intro N g
        induction N with
        | zero => simp
        | succ m ih => rw [List.range_succ, List.map_append, List.sum_append, ih, Finset.sum_range_succ]; simp
      have hsum_le : (codes.map rejCountCode).sum ≤
          ((gen.P₀ ×ˢ QSet).filter (fun it =>
            (∀ s : Fin ℓ, gaussianDataTest (τ_d : ℝ) (F (r, s, it.2 s)) (gen.pts it.1)) ∧
              inner ℝ (gen.pts it.1) qz ≤ 0)).card := by
        dsimp [codes]
        rw [List.map_map, hlist_sum_range]
        calc (∑ idx ∈ Finset.range (∏ s : Fin ℓ, cnt s),
                rejCountCode ⟨encodeTuple (mixedTuple hM₀ cnt elig idx), encodeTuple_lt hM₀ _⟩)
            ≤ ∑ idx ∈ Finset.range (∏ s : Fin ℓ, cnt s),
                (gen.P₀.filter (fun k =>
                  (∀ s : Fin ℓ, gaussianDataTest (τ_d : ℝ) (F (r, s, mixedTuple hM₀ cnt elig idx s)) (gen.pts k)) ∧
                    inner ℝ (gen.pts k) qz ≤ 0)).card :=
              Finset.sum_le_sum (fun idx hidx => hrej_code_le idx (Finset.mem_range.mp hidx))
          _ = ∑ τ ∈ (Finset.range (∏ s : Fin ℓ, cnt s)).image (mixedTuple hM₀ cnt elig),
                (gen.P₀.filter (fun k =>
                  (∀ s : Fin ℓ, gaussianDataTest (τ_d : ℝ) (F (r, s, τ s)) (gen.pts k)) ∧
                    inner ℝ (gen.pts k) qz ≤ 0)).card := by
              rw [Finset.sum_image (fun a ha b hb h => hinj_Q ha hb h)]
          _ = ∑ τ ∈ QSet,
                (gen.P₀.filter (fun k =>
                  (∀ s : Fin ℓ, gaussianDataTest (τ_d : ℝ) (F (r, s, τ s)) (gen.pts k)) ∧
                    inner ℝ (gen.pts k) qz ≤ 0)).card := by rw [himg_Q]
          _ = ((gen.P₀ ×ˢ QSet).filter (fun it =>
                (∀ s : Fin ℓ, gaussianDataTest (τ_d : ℝ) (F (r, s, it.2 s)) (gen.pts it.1)) ∧
                  inner ℝ (gen.pts it.1) qz ≤ 0)).card := by
              rw [Finset.card_filter, Finset.sum_product_right]
              refine Finset.sum_congr rfl fun τ _ => ?_
              rw [Finset.card_filter]
      dsimp [qry] at hBadCard
      omega
    · -- Every live candidate in every visited bucket was rejected — contradicts `arr j_star`!
      exact hall_rej code_star hcode_mem (arr j_star) hbkt_star hinU_star hacc_star
  -- Now deduce `radialCorrelation o p_v (pts (arr j_star)) < a_thr` for every live `j_star`!
  intro j_star hinU
  by_contra hge_a
  push_neg at hge_a
  let k_star : Fin N_pad := ⟨j_star.val, lt_of_lt_of_le j_star.isLt hsz⟩
  have hk_P : k_star ∈ P_surv := Finset.mem_filter.mpr ⟨Finset.mem_univ _, j_star.isLt, hinU⟩
  have hcorr_eq : radialCorrelation o p_v (pts (arr j_star)) =
      inner ℝ z_q (radialDirection o (pts (arr j_star))) := by
    rw [hzq_eq_neg]; rfl
  rw [hcorr_eq] at hge_a
  have hu_j : ‖radialDirection o (pts (arr j_star))‖ = 1 := by
    unfold radialDirection
    have hp := norm_pos_iff.mpr (sub_ne_zero.mpr (hne_o j_star))
    rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hp.ne']
  have hge_h := (hsep _ z_q z_bar hu_j hzq_unit hz_bar_unit hz_bar_dist).1 hge_a
  have hgen_pt : gen.pts k_star = liftedPoint ((A : ℝ) • radialDirection o (pts (arr j_star))) (B : ℝ) := by
    dsimp [gen, mkPaddedGeneration, k_star]; simp [j_star.isLt]
  have htarget : HasSearchTarget gen.pts P_surv gen.h qry.z :=
    ⟨k_star, hk_P, by dsimp [qry]; rw [hgen_pt, real_inner_comm]; exact hge_h⟩
  exact hcorr_ans.2 rfl htarget

theorem scanLiveCands_filter_inU {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o p_v : EuclideanSpace ℝ (Fin d)) (b_thr : ℝ) (inU : ℕ → Bool) :
    ∀ (rem : ℕ) (cands : List ℕ),
      scanLiveCands pts o p_v b_thr inU rem (cands.filter inU) =
        scanLiveCands pts o p_v b_thr inU rem cands := by
  have hzero : ∀ xs, scanLiveCands pts o p_v b_thr inU 0 xs = (none, 0) := by
    intro xs; cases xs <;> rfl
  intro rem cands
  induction cands generalizing rem with
  | nil => rfl
  | cons c tl ih =>
      cases rem with
      | zero => rw [hzero, hzero]
      | succ r0 =>
          by_cases hu : inU c = true
          · rw [List.filter_cons_of_pos hu]
            dsimp only [scanLiveCands]
            rw [if_pos hu, if_pos hu]
            split_ifs
            · rfl
            · exact ih r0
          · rw [List.filter_cons_of_neg hu]
            conv_rhs =>
              dsimp only [scanLiveCands]
              rw [if_neg hu]
            exact ih (r0 + 1)



/-! ### 6. Live-Filtered Bucket Equivalence (`scanLiveCands` on `buckets.filter inU`) -/

theorem scanLiveCands_filter_alive {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o p_v : EuclideanSpace ℝ (Fin d)) (b_thr : ℝ) (inU : ℕ → Bool) :
    ∀ (L : List ℕ) (rem : ℕ),
      scanLiveCands pts o p_v b_thr (fun _ => true) rem (L.filter inU) =
      scanLiveCands pts o p_v b_thr inU rem L
  | [], rem => by simp [scanLiveCands]
  | h :: tl, 0 => by
      by_cases hh : inU h = true
      · simp [List.filter, hh, scanLiveCands]
      · have hhf : inU h = false := Bool.eq_false_iff.mpr hh
        simp only [List.filter, hhf]
        cases htl : tl.filter inU <;> simp [scanLiveCands]
  | h :: tl, rem + 1 => by
      by_cases hh : inU h = true
      · simp only [List.filter, hh, scanLiveCands, ↓reduceIte]
        split_ifs with hcorr
        · rfl
        · exact scanLiveCands_filter_alive pts o p_v b_thr inU tl rem
      · have hhf : inU h = false := Bool.eq_false_iff.mpr hh
        simp only [List.filter, hhf, scanLiveCands, Bool.false_eq_true, ↓reduceIte]
        exact scanLiveCands_filter_alive pts o p_v b_thr inU tl (rem + 1)

theorem scanCopyTuples_filter_alive {R ℓ M₀ d : ℕ}
    (buckets : Fin R → Fin (M₀ ^ ℓ) → List ℕ) (r : Fin R)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (b_thr : ℝ) (inU : ℕ → Bool) :
    ∀ (codes : List (Fin (M₀ ^ ℓ))) (rem : ℕ),
      scanCopyTuples (fun r' c' => (buckets r' c').filter inU) r pts o p_v b_thr (fun _ => true) rem codes =
      scanCopyTuples buckets r pts o p_v b_thr inU rem codes
  | [], _ => rfl
  | _ :: _, 0 => rfl
  | code :: rest, rem + 1 => by
      dsimp only [scanCopyTuples]
      rw [scanLiveCands_filter_alive]
      cases scanLiveCands pts o p_v b_thr inU (rem + 1) (buckets r code) with
      | mk ans rem' =>
          cases ans with
          | some h => rfl
          | none => exact scanCopyTuples_filter_alive buckets r pts o p_v b_thr inU rest rem'

theorem pureFilterSlot_query_eq_live {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (M_lat : ℕ) (A B τ_q : ℚ) (b_thr : ℝ) (cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o p_v : EuclideanSpace ℝ (Fin d))
    (inU : ℕ → Bool) (slot : PureFilterSlot R ℓ M₀ d) :
    ({ caps := slot.caps, buckets := fun r c => (slot.buckets r c).filter inU } :
        PureFilterSlot R ℓ M₀ d).query hM₀ M_lat A B τ_q b_thr cap_q pts o p_v (fun _ => true) =
      slot.query hM₀ M_lat A B τ_q b_thr cap_q pts o p_v inU := by
  unfold PureFilterSlot.query
  dsimp only
  congr 1
  funext r
  exact scanCopyTuples_filter_alive slot.buckets r pts o p_v b_thr inU _ (cap_q + 1)

/-! ### 7. Pure Strictly-Decreasing Doubly-Linked List (`IsDLL` / `IsBucketDLL`) -/

def listHeadInt : List ℕ → ℤ
  | [] => -1
  | x :: _ => (x : ℤ)

def IsDLL (prv : ℤ) : List ℕ → (ℕ → ℤ) → (ℕ → ℤ) → Prop
  | [], _, _ => True
  | x :: xs, prev, next =>
      prev x = prv ∧
      next x = listHeadInt xs ∧
      IsDLL (x : ℤ) xs prev next

def IsBucketDLL (L : List ℕ) (head : ℤ) (prev next : ℕ → ℤ) : Prop :=
  L.IsChain (· > ·) ∧ head = listHeadInt L ∧ IsDLL (-1) L prev next

theorem isDLL_congr_outside :
    ∀ {L : List ℕ} {prv : ℤ} {prev₁ next₁ prev₂ next₂ : ℕ → ℤ},
      IsDLL prv L prev₁ next₁ →
      (∀ z ∈ L, prev₂ z = prev₁ z ∧ next₂ z = next₁ z) →
      IsDLL prv L prev₂ next₂
  | [], _, _, _, _, _, _, _ => trivial
  | x :: xs, _, _, _, _, _, ⟨hp, hn, htl⟩, hfg => by
      have hx := hfg x List.mem_cons_self
      exact ⟨hx.1.trans hp, hx.2.trans hn,
        isDLL_congr_outside htl (fun z hz => hfg z (List.mem_cons_of_mem x hz))⟩

theorem chain_gt_forall_lt :
    ∀ {x : ℕ} {xs : List ℕ}, (x :: xs).IsChain (· > ·) → ∀ z ∈ xs, z < x
  | _, [], _, _, hz => by cases hz
  | x, y :: ys, hc, z, hz => by
      rw [List.isChain_cons_cons] at hc
      rcases List.mem_cons.mp hz with rfl | hzy
      · exact hc.1
      · exact lt_trans (chain_gt_forall_lt hc.2 z hzy) hc.1

theorem chain_gt_nodup : ∀ {L : List ℕ}, L.IsChain (· > ·) → L.Nodup
  | [], _ => List.nodup_nil
  | x :: xs, hc => by
      refine List.nodup_cons.mpr ⟨fun hx => ?_, chain_gt_nodup (List.IsChain.tail hc)⟩
      exact Nat.lt_irrefl x (chain_gt_forall_lt hc x hx)

theorem chain_gt_erase : ∀ {L : List ℕ} (nd : ℕ), L.IsChain (· > ·) → (L.erase nd).IsChain (· > ·)
  | [], _, _ => List.isChain_nil
  | x :: xs, nd, hc => by
      by_cases hxn : x = nd
      · subst hxn; rw [List.erase_cons_head]; exact List.IsChain.tail hc
      · rw [List.erase_cons_tail (by simp [beq_iff_eq, hxn])]
        have htl : (xs.erase nd).IsChain (· > ·) := chain_gt_erase nd (List.IsChain.tail hc)
        cases hxe : xs.erase nd with
        | nil => exact List.isChain_singleton x
        | cons y ys' =>
            have hy_er : y ∈ xs.erase nd := by rw [hxe]; exact List.mem_cons_self
            have hy_mem : y ∈ xs := List.mem_of_mem_erase hy_er
            rw [hxe] at htl
            exact List.isChain_cons_cons.mpr ⟨chain_gt_forall_lt hc y hy_mem, htl⟩

theorem erase_eq_filter_ne_of_nodup :
    ∀ {L : List ℕ} (nd : ℕ), L.Nodup → L.erase nd = L.filter (fun z => decide (z ≠ nd))
  | [], _, _ => rfl
  | x :: xs, nd, hnd => by
      rcases List.nodup_cons.mp hnd with ⟨hx_not, hnd_tl⟩
      by_cases hxn : x = nd
      · subst hxn
        rw [List.erase_cons_head]
        simp only [List.filter, ne_eq, not_true_eq_false, decide_false]
        symm
        refine List.filter_eq_self.mpr fun z hz => ?_
        simp only [decide_eq_true_eq]
        exact fun hzx => hx_not (hzx ▸ hz)
      · rw [List.erase_cons_tail (by simp [beq_iff_eq, hxn])]
        have hex : decide (x ≠ nd) = true := decide_eq_true hxn
        simp only [List.filter, hex, erase_eq_filter_ne_of_nodup nd hnd_tl]

theorem isDLL_next_mem :
    ∀ {L : List ℕ} {prv : ℤ} {prev next : ℕ → ℤ} {nd : ℕ},
      nd ∈ L → IsDLL prv L prev next →
      next nd = -1 ∨ ∃ z ∈ L, next nd = (z : ℤ)
  | [], _, _, _, _, hm, _ => by cases hm
  | x :: xs, _, _, _, nd, hm, ⟨_, hnx, htl⟩ => by
      rcases List.mem_cons.mp hm with hnd_x | hxs
      · subst hnd_x
        cases xs with
        | nil => exact Or.inl hnx
        | cons y ys => exact Or.inr ⟨y, List.mem_cons_of_mem nd List.mem_cons_self, hnx⟩
      · rcases isDLL_next_mem hxs htl with hneg | ⟨z, hz, heq⟩
        · exact Or.inl hneg
        · exact Or.inr ⟨z, List.mem_cons_of_mem x hz, heq⟩

theorem isDLL_prev_mem :
    ∀ {L : List ℕ} {prv : ℤ} {prev next : ℕ → ℤ} {nd : ℕ},
      nd ∈ L → IsDLL prv L prev next →
      prev nd = prv ∨ ∃ z ∈ L, prev nd = (z : ℤ)
  | [], _, _, _, _, hm, _ => by cases hm
  | x :: xs, _, _, _, nd, hm, ⟨hpx, _, htl⟩ => by
      rcases List.mem_cons.mp hm with hnd_x | hxs
      · subst hnd_x; exact Or.inl hpx
      · rcases isDLL_prev_mem hxs htl with heq | ⟨z, hz, heq⟩
        · exact Or.inr ⟨x, List.mem_cons_self, heq⟩
        · exact Or.inr ⟨z, List.mem_cons_of_mem x hz, heq⟩

theorem isBucketDLL_nil (prev next : ℕ → ℤ) :
    IsBucketDLL [] (-1) prev next :=
  ⟨List.isChain_nil, rfl, trivial⟩

theorem isBucketDLL_congr_outside {L : List ℕ} {head : ℤ} {prev₁ next₁ prev₂ next₂ : ℕ → ℤ}
    (hdll : IsBucketDLL L head prev₁ next₁)
    (hfg : ∀ z ∈ L, prev₂ z = prev₁ z ∧ next₂ z = next₁ z) :
    IsBucketDLL L head prev₂ next₂ :=
  ⟨hdll.1, hdll.2.1, isDLL_congr_outside hdll.2.2 hfg⟩

theorem isBucketDLL_push {L : List ℕ} {head : ℤ} {prev next : ℕ → ℤ} {nd : ℕ}
    (hdll : IsBucketDLL L head prev next)
    (hgt : ∀ z ∈ L, z < nd) :
    let prev1 := Function.update prev nd (-1)
    let next1 := Function.update next nd head
    let prev2 := if head < 0 then prev1 else Function.update prev1 head.toNat (nd : ℤ)
    IsBucketDLL (nd :: L) (nd : ℤ) prev2 next1 := by
  rcases hdll with ⟨hch, hhd, hdll0⟩
  dsimp only
  cases L with
  | nil =>
      subst hhd
      dsimp only [listHeadInt]
      have hneg : (-1 : ℤ) < 0 := by omega
      rw [if_pos hneg]
      exact ⟨List.isChain_singleton nd, rfl, Function.update_self nd (-1) prev,
        Function.update_self nd (-1) next, trivial⟩
  | cons y ys =>
      subst hhd
      have hy_lt : y < nd := hgt y List.mem_cons_self
      have hch' : (nd :: y :: ys).IsChain (· > ·) := List.isChain_cons_cons.mpr ⟨hy_lt, hch⟩
      have hnot_neg : ¬ ((listHeadInt (y :: ys)) < 0) := by simp [listHeadInt]
      have htoNat : (listHeadInt (y :: ys)).toNat = y := by simp [listHeadInt]
      rw [if_neg hnot_neg, htoNat]
      refine ⟨hch', rfl, ?_, Function.update_self nd _ next, ?_⟩
      · rw [Function.update_of_ne (by omega : nd ≠ y), Function.update_self]
      · rcases hdll0 with ⟨_, hny, htly⟩
        refine ⟨by rw [Function.update_self], ?_, ?_⟩
        · rw [Function.update_of_ne (by omega : y ≠ nd)]; exact hny
        · refine isDLL_congr_outside htly fun z hz => ?_
          have hz_lt_y : z < y := chain_gt_forall_lt hch z hz
          exact ⟨by rw [Function.update_of_ne (by omega : z ≠ y), Function.update_of_ne (by omega : z ≠ nd)],
                 by rw [Function.update_of_ne (by omega : z ≠ nd)]⟩

private lemma isDLL_unlink_aux :
    ∀ (L : List ℕ) (prv : ℤ) (prev next : ℕ → ℤ) (nd : ℕ),
      L.IsChain (· > ·) →
      (prv = -1 ∨ ∃ w : ℕ, prv = (w : ℤ) ∧ ∀ z ∈ L, z < w) →
      nd ∈ L →
      IsDLL prv L prev next →
      let p := prev nd
      let nx := next nd
      let prev' := if nx < 0 then prev else Function.update prev nx.toNat p
      let next' := if p < 0 then next else Function.update next p.toNat nx
      (prv = -1 → (if p < 0 then nx else listHeadInt L) = listHeadInt (L.erase nd)) ∧
      (∀ w : ℕ, prv = (w : ℤ) → next w = listHeadInt L → (∀ z ∈ L, z < w) →
        0 ≤ p ∧ next' w = listHeadInt (L.erase nd)) ∧
      (∀ u : ℕ, (∀ z ∈ L, z < u) → prv ≠ (u : ℤ) → prev' u = prev u ∧ next' u = next u) ∧
      IsDLL prv (L.erase nd) prev' next'
  | [], _, _, _, _, _, _, hm, _ => by cases hm
  | x :: xs, prv, prev, next, nd, hch, hprv, hm, ⟨hpx, hnx, htl⟩ => by
      dsimp only
      by_cases hxn : x = nd
      · subst hxn
        simp only [List.erase_cons_head]
        refine ⟨?_, ?_, ?_, ?_⟩
        · intro hp1
          have hneg : prev x < 0 := by rw [hpx, hp1]; omega
          rw [if_pos hneg]; exact hnx
        · intro w hw _ _
          have hnneg : ¬ (prev x < 0) := by rw [hpx, hw]; omega
          have hto : (prev x).toNat = w := by rw [hpx, hw]; exact Int.toNat_natCast w
          refine ⟨by omega, ?_⟩
          rw [if_neg hnneg, hto, Function.update_self]
          exact hnx
        · intro u hu hne_u
          have hx_lt_u : x < u := hu x List.mem_cons_self
          constructor
          · cases xs with
            | nil =>
                have hneg : next x < 0 := by simp [listHeadInt] at hnx; omega
                rw [if_pos hneg]
            | cons y ys =>
                have hnneg : ¬ (next x < 0) := by simp [listHeadInt] at hnx; omega
                have hto : (next x).toNat = y := by simp [listHeadInt] at hnx; rw [hnx]; exact Int.toNat_natCast y
                have hy_lt_u : y < u := hu y (List.mem_cons_of_mem x List.mem_cons_self)
                rw [if_neg hnneg, hto]
                exact Function.update_of_ne (by omega : u ≠ y) _ _
          · by_cases hpneg : prev x < 0
            · rw [if_pos hpneg]
            · rcases hprv with hp1 | ⟨w, hw, _⟩
              · exfalso; rw [hpx, hp1] at hpneg; omega
              · have hto : (prev x).toNat = w := by rw [hpx, hw]; exact Int.toNat_natCast w
                have huw : u ≠ w := fun h => hne_u (h ▸ hw)
                rw [if_neg hpneg, hto]
                exact Function.update_of_ne huw _ _
        · cases xs with
          | nil => exact trivial
          | cons y ys =>
              rcases htl with ⟨_, hny, htly⟩
              have hnneg_nx : ¬ (next x < 0) := by simp [listHeadInt] at hnx; omega
              have hto_nx : (next x).toNat = y := by simp [listHeadInt] at hnx; rw [hnx]; exact Int.toNat_natCast y
              have hy_gt : ∀ z ∈ ys, z < y := chain_gt_forall_lt (List.IsChain.tail hch)
              refine ⟨?_, ?_, ?_⟩
              · rw [if_neg hnneg_nx, hto_nx, Function.update_self, hpx]
              · by_cases hpneg : prev x < 0
                · rw [if_pos hpneg]; exact hny
                · rcases hprv with hp1 | ⟨w, hw, hw_gt⟩
                  · exfalso; rw [hpx, hp1] at hpneg; omega
                  · have hto_p : (prev x).toNat = w := by rw [hpx, hw]; exact Int.toNat_natCast w
                    have hy_lt_w : y < w := hw_gt y (List.mem_cons_of_mem x List.mem_cons_self)
                    rw [if_neg hpneg, hto_p, Function.update_of_ne (by omega : y ≠ w)]
                    exact hny
              · refine isDLL_congr_outside htly fun z hz => ?_
                have hz_lt_y : z < y := hy_gt z hz
                constructor
                · rw [if_neg hnneg_nx, hto_nx]
                  exact Function.update_of_ne (by omega : z ≠ y) _ _
                · by_cases hpneg : prev x < 0
                  · rw [if_pos hpneg]
                  · rcases hprv with hp1 | ⟨w, hw, hw_gt⟩
                    · exfalso; rw [hpx, hp1] at hpneg; omega
                    · have hto_p : (prev x).toNat = w := by rw [hpx, hw]; exact Int.toNat_natCast w
                      have hz_lt_w : z < w := hw_gt z (List.mem_cons_of_mem x (List.mem_cons_of_mem y hz))
                      rw [if_neg hpneg, hto_p]
                      exact Function.update_of_ne (by omega : z ≠ w) _ _
      · have hxs_mem : nd ∈ xs := by
          rcases List.mem_cons.mp hm with rfl | h
          · exact False.elim (hxn rfl)
          · exact h
        rw [List.erase_cons_tail (by simp [beq_iff_eq, hxn])]
        have hgt_xs : ∀ z ∈ xs, z < x := chain_gt_forall_lt hch
        have hch_xs : xs.IsChain (· > ·) := List.IsChain.tail hch
        obtain ⟨_, ih2, ih3, ih4⟩ :=
          isDLL_unlink_aux xs (x : ℤ) prev next nd hch_xs (Or.inr ⟨x, rfl, hgt_xs⟩) hxs_mem htl
        obtain ⟨hp_nneg, hnx'_x⟩ := ih2 x rfl hnx hgt_xs
        have hp_not_neg : ¬ (prev nd < 0) := by omega
        have hprv'_x : (if next nd < 0 then prev else Function.update prev (next nd).toNat (prev nd)) x = prev x := by
          rcases isDLL_next_mem hxs_mem htl with hnx_neg | ⟨z, hz, hnx_z⟩
          · have hlt0 : next nd < 0 := by omega
            rw [if_pos hlt0]
          · have hnlt0 : ¬ (next nd < 0) := by omega
            have hto_z : (next nd).toNat = z := by rw [hnx_z]; exact Int.toNat_natCast z
            have hz_lt_x : z < x := hgt_xs z hz
            rw [if_neg hnlt0, hto_z]
            exact Function.update_of_ne (by omega : x ≠ z) _ _
        refine ⟨?_, ?_, ?_, ?_⟩
        · intro _
          rw [if_neg hp_not_neg]; rfl
        · intro w _ hnw hw_gt
          have hx_lt_w : x < w := hw_gt x List.mem_cons_self
          have h_u := ih3 w (fun z hz => lt_trans (hgt_xs z hz) hx_lt_w) (by omega)
          exact ⟨hp_nneg, h_u.2.trans hnw⟩
        · intro u hu hne_u
          have hx_lt_u : x < u := hu x List.mem_cons_self
          exact ih3 u (fun z hz => lt_trans (hgt_xs z hz) hx_lt_u) (by omega)
        · exact ⟨hprv'_x.trans hpx, hnx'_x, ih4⟩

theorem isBucketDLL_erase {L : List ℕ} {head : ℤ} {prev next : ℕ → ℤ} {nd : ℕ}
    (hdll : IsBucketDLL L head prev next) (hmem : nd ∈ L) :
    let p := prev nd
    let nx := next nd
    let head' := if p < 0 then nx else head
    let prev' := if nx < 0 then prev else Function.update prev nx.toNat p
    let next' := if p < 0 then next else Function.update next p.toNat nx
    (p = -1 ∨ ∃ z ∈ L, p = (z : ℤ)) ∧
    (nx = -1 ∨ ∃ z ∈ L, nx = (z : ℤ)) ∧
    IsBucketDLL (L.erase nd) head' prev' next' := by
  rcases hdll with ⟨hch, hhd, hdll0⟩
  obtain ⟨h1, _, _, h4⟩ := isDLL_unlink_aux L (-1) prev next nd hch (Or.inl rfl) hmem hdll0
  refine ⟨isDLL_prev_mem hmem hdll0, isDLL_next_mem hmem hdll0,
    chain_gt_erase nd hch, ?_, h4⟩
  dsimp only
  rw [hhd]; exact h1 rfl

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
