import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3c_ChainEngine
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 1. Fixed Engine Table Partition, Slot Pool, and Offsets -/

abbrev coinTbl : ℕ := 5
abbrev engMetaTbl : ℕ := 6
abbrev engArrTbl : ℕ := 7
abbrev engScrTbl : ℕ := 8
abbrev ptsRTbl : ℕ := 1
abbrev engRealTbl : ℕ := 2

/-- Static pool size of pre-partitioned node slots (`> D_max + D_max^2 + D_max`). -/
def M_slots {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) : ℕ :=
  cp.D_max * cp.D_max + 4 * cp.D_max + 8

/-- Per-array stride in `engArrTbl` (`> cp.n` and `> cp.B_scan + 2`). -/
def S_stride {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) : ℕ :=
  cp.n + cp.B_scan + 8

def servSlotOff (i : ℕ) : ℤ := 16 + (i : ℤ)

def jobMetaBase {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : ℕ) : ℤ :=
  16 + (cp.D_max : ℤ) + 8 * (r : ℤ)

def readySlotOff {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r q : ℕ) : ℤ :=
  16 + 9 * (cp.D_max : ℤ) + (r : ℤ) * (cp.D_max : ℤ) + (q : ℤ)

def leafElemOff : ℤ := 0

def leafPosOff {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℤ := (S_stride cp : ℤ)

def snapElemOff {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : ℕ) : ℤ :=
  (((2 + 4 * r) * S_stride cp : ℕ) : ℤ)

def snapPosOff {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : ℕ) : ℤ :=
  (((3 + 4 * r) * S_stride cp : ℕ) : ℤ)

def delSnapElemOff {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : ℕ) : ℤ :=
  (((4 + 4 * r) * S_stride cp : ℕ) : ℤ)

def delSnapPosOff {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : ℕ) : ℤ :=
  (((5 + 4 * r) * S_stride cp : ℕ) : ℤ)

/-! ### 2. `ZeroRandStmt` & `NoWriteWordTbl` Helpers -/

theorem zeroRand_forLoopStmt {ctrTbl : ℕ} {ctrIdx : ℤ} {N : ℕ} {body : ArithRAMStmt}
    (hb : ZeroRandStmt body) : ZeroRandStmt (forLoopStmt ctrTbl ctrIdx N body) :=
  .seq (.writeWordHeap _ _ _) (.repeatN (.seq hb (.writeWordHeap _ _ _)))

theorem zeroRand_applyHandleUpdateStmt (d : ℕ) : ZeroRandStmt (applyHandleUpdateStmt d) := by
  unfold applyHandleUpdateStmt
  refine .ite (.seq (.ite (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
      (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
    (.seq (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
      (zeroRand_forLoopStmt (.writeRealHeap _ _ _)))) ?_
  exact .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))))

theorem wRead_wWrite_eq (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ v : ℤ) :
    wRead (H3a.wWrite mem t₂ i₂ v) t₁ i₁ = if t₁ = t₂ ∧ i₁ = i₂ then v else wRead mem t₁ i₁ := by
  by_cases h : t₁ = t₂ ∧ i₁ = i₂
  · rcases h with ⟨rfl, rfl⟩; simp
  · rw [if_neg h]; apply wRead_wWrite_of_ne; tauto

theorem ExecDet.ite' {d : ℕ} {TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (cond : ArithCondExpr) (tB fB : ArithRAMStmt) {b : Bool}
    {m₀ : ArithRAMMemory} {Post : ArithRAMMemory → Prop} {C_c C_b C : ℕ}
    (hcond : (evalArithCond inp 0 m₀ cond).1 = b)
    (huc : condExprOps cond ≤ C_c)
    (ht : b = true → ExecDet TW BW TR BR inp tB m₀ Post C_b)
    (hf : b = false → ExecDet TW BW TR BR inp fB m₀ Post C_b)
    (hC : C_c + C_b ≤ C := by omega) :
    ExecDet TW BW TR BR inp (.ite cond tB fB) m₀ Post C :=
  (ExecDet.ite cond tB fB huc (fun hc => ht (hcond.symm.trans hc))
    (fun hc => hf (hcond.symm.trans hc))).mono (fun _ hm _ => hm) hC

/-! ### 3. Coin-Slice Offset Lemmas (`coinTbl = 5`) -/

def MemHasStepCoins {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (bits : Fin cp.B_STEP → Bool) (mem : ArithRAMMemory) : Prop :=
  ∀ k : Fin cp.B_STEP, wRead mem coinTbl (k.val : ℤ) = if bits k then 1 else 0

private theorem stepCoinBundle_s2 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (bits : Fin cp.B_STEP → Bool) :
    (bitsToStepCoinBundle cp bits).2.1 =
      bitsToStage2Equiv cp (fun j : Fin cp.B_S2 =>
        bits ⟨cp.B_S1 + j.val, by
          change cp.B_S1 + j.val < cp.B_S1 + cp.B_S2 + cp.B_S4; have := j.isLt; omega⟩) := by
  simp only [bitsToStepCoinBundle, Equiv.trans_apply, Equiv.prodCongr_apply,
    Equiv.prodAssoc_apply, Equiv.refl_apply, Prod.map]
  congr 1

private theorem stepCoinBundle_s4 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (bits : Fin cp.B_STEP → Bool) :
    (bitsToStepCoinBundle cp bits).2.2 =
      bitsToStage4Equiv cp (fun j : Fin cp.B_S4 =>
        bits ⟨cp.B_S1 + cp.B_S2 + j.val, by
          change cp.B_S1 + cp.B_S2 + j.val < cp.B_S1 + cp.B_S2 + cp.B_S4; have := j.isLt; omega⟩) := by
  simp only [bitsToStepCoinBundle, Equiv.trans_apply, Equiv.prodCongr_apply,
    Equiv.prodAssoc_apply, Equiv.refl_apply, Prod.map]
  congr 1

theorem memHasStepCoins_stage1 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (bits : Fin cp.B_STEP → Bool) (mem : ArithRAMMemory)
    (hcoins : MemHasStepCoins cp bits mem) {idx : ℕ} (hidx : idx < cp.N_op_s1) :
    let ω₁ := (bitsToStepCoinBundle cp bits).1
    ∃ seedBits : Fin cp.B_op → Bool,
      getS1Seed cp ω₁ idx = bitsToOpSeedEquiv cp seedBits ∧
      idx * cp.B_op + cp.B_op ≤ cp.B_STEP ∧
      ∀ k : Fin cp.B_op,
        wRead mem coinTbl (((idx * cp.B_op : ℕ) : ℤ) + (k.val : ℤ)) =
          if seedBits k then 1 else 0 := by
  have hbound : idx * cp.B_op + cp.B_op ≤ cp.B_STEP := by
    have h1 : idx * cp.B_op + cp.B_op = (idx + 1) * cp.B_op := by ring
    have h2 : (idx + 1) * cp.B_op ≤ cp.N_op_s1 * cp.B_op := Nat.mul_le_mul_right _ hidx
    change idx * cp.B_op + cp.B_op ≤ cp.B_S1 + cp.B_S2 + cp.B_S4
    unfold ChainParams.B_S1; omega
  let seedBits : Fin cp.B_op → Bool := fun k => bits ⟨idx * cp.B_op + k.val, by omega⟩
  refine ⟨seedBits, ?_, hbound, fun k => ?_⟩
  · simp only [getS1Seed, dif_pos hidx, bitsToStepCoinBundle, bitsToStage1Equiv,
      Equiv.trans_apply, Equiv.prodCongr_apply, Prod.map, Equiv.prodAssoc_apply,
      Equiv.refl_apply, Equiv.arrowCongr_apply, splitBlocksEquiv_apply]
    rfl
  · have hk := hcoins ⟨idx * cp.B_op + k.val, by omega⟩
    push_cast at hk; exact hk

theorem memHasStepCoins_stage2_op {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (bits : Fin cp.B_STEP → Bool) (mem : ArithRAMMemory)
    (hcoins : MemHasStepCoins cp bits mem) (idx : Fin cp.N_op_s2) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let off := cp.B_S1 + idx.val * cp.B_op
    ∃ seedBits : Fin cp.B_op → Bool,
      ω₂.1 idx = bitsToOpSeedEquiv cp seedBits ∧
      off + cp.B_op ≤ cp.B_STEP ∧
      ∀ k : Fin cp.B_op,
        wRead mem coinTbl ((off : ℤ) + (k.val : ℤ)) = if seedBits k then 1 else 0 := by
  intro ω₂ off
  have hbound : off + cp.B_op ≤ cp.B_STEP := by
    have h1 : idx.val * cp.B_op + cp.B_op = (idx.val + 1) * cp.B_op := by ring
    have h2 : (idx.val + 1) * cp.B_op ≤ cp.N_op_s2 * cp.B_op := Nat.mul_le_mul_right _ idx.isLt
    change (cp.B_S1 + idx.val * cp.B_op) + cp.B_op ≤ cp.B_S1 + cp.B_S2 + cp.B_S4
    unfold ChainParams.B_S2; omega
  let seedBits : Fin cp.B_op → Bool := fun k => bits ⟨off + k.val, by omega⟩
  refine ⟨seedBits, ?_, hbound, fun k => ?_⟩
  · dsimp only [ω₂]
    rw [stepCoinBundle_s2]
    simp only [bitsToStage2Equiv, Equiv.trans_apply, Equiv.prodCongr_apply, Prod.map,
      Equiv.refl_apply, Equiv.arrowCongr_apply, splitAddEquiv_fst, splitBlocksEquiv_apply]
    exact congrArg (bitsToOpSeedEquiv cp) (funext fun k =>
      congrArg bits (Fin.ext (by change cp.B_S1 + (idx.val * cp.B_op + k.val) = off + k.val; dsimp only [off]; omega)))
  · have hk := hcoins ⟨off + k.val, by omega⟩
    push_cast at hk; exact hk

theorem memHasStepCoins_stage2_ctr {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (bits : Fin cp.B_STEP → Bool) (mem : ArithRAMMemory)
    (hcoins : MemHasStepCoins cp bits mem) (cIdx : Fin (cp.D_max + 1)) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let off := cp.B_S1 + cp.N_op_s2 * cp.B_op + cIdx.val * cp.B_ctr
    ∃ ctrBits : Fin cp.B_ctr → Bool,
      ω₂.2 cIdx = bitsToCenterSeedEquiv cp ctrBits ∧
      off + cp.B_ctr ≤ cp.B_STEP ∧
      ∀ k : Fin cp.B_ctr,
        wRead mem coinTbl ((off : ℤ) + (k.val : ℤ)) = if ctrBits k then 1 else 0 := by
  intro ω₂ off
  have hbound : off + cp.B_ctr ≤ cp.B_STEP := by
    have h1 : cIdx.val * cp.B_ctr + cp.B_ctr = (cIdx.val + 1) * cp.B_ctr := by ring
    have h2 : (cIdx.val + 1) * cp.B_ctr ≤ (cp.D_max + 1) * cp.B_ctr := Nat.mul_le_mul_right _ cIdx.isLt
    change (cp.B_S1 + cp.N_op_s2 * cp.B_op + cIdx.val * cp.B_ctr) + cp.B_ctr ≤
      cp.B_S1 + cp.B_S2 + cp.B_S4
    unfold ChainParams.B_S2; omega
  let ctrBits : Fin cp.B_ctr → Bool := fun k => bits ⟨off + k.val, by omega⟩
  refine ⟨ctrBits, ?_, hbound, fun k => ?_⟩
  · dsimp only [ω₂]
    rw [stepCoinBundle_s2]
    simp only [bitsToStage2Equiv, Equiv.trans_apply, Equiv.prodCongr_apply, Prod.map,
      Equiv.refl_apply, Equiv.arrowCongr_apply, splitAddEquiv_snd, splitBlocksEquiv_apply]
    exact congrArg (bitsToCenterSeedEquiv cp) (funext fun k =>
      congrArg bits (Fin.ext (by change cp.B_S1 + (cp.N_op_s2 * cp.B_op + (cIdx.val * cp.B_ctr + k.val)) = off + k.val; dsimp only [off]; omega)))
  · have hk := hcoins ⟨off + k.val, by omega⟩
    push_cast at hk; exact hk

theorem memHasStepCoins_stage4_base {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (bits : Fin cp.B_STEP → Bool) (mem : ArithRAMMemory)
    (hcoins : MemHasStepCoins cp bits mem) (i : Fin cp.D_max) :
    let ω₄ := (bitsToStepCoinBundle cp bits).2.2
    let off := cp.B_S1 + cp.B_S2 + i.val * cp.B_base
    ∃ bBits : Fin cp.B_base → Bool,
      ω₄ i = bitsToBaseSeedEquiv cp bBits ∧
      off + cp.B_base ≤ cp.B_STEP ∧
      ∀ k : Fin cp.B_base,
        wRead mem coinTbl ((off : ℤ) + (k.val : ℤ)) = if bBits k then 1 else 0 := by
  intro ω₄ off
  have hbound : off + cp.B_base ≤ cp.B_STEP := by
    have h1 : i.val * cp.B_base + cp.B_base = (i.val + 1) * cp.B_base := by ring
    have h2 : (i.val + 1) * cp.B_base ≤ cp.D_max * cp.B_base := Nat.mul_le_mul_right _ i.isLt
    change (cp.B_S1 + cp.B_S2 + i.val * cp.B_base) + cp.B_base ≤ cp.B_S1 + cp.B_S2 + cp.B_S4
    unfold ChainParams.B_S4; omega
  let bBits : Fin cp.B_base → Bool := fun k => bits ⟨off + k.val, by omega⟩
  refine ⟨bBits, ?_, hbound, fun k => ?_⟩
  · dsimp only [ω₄]
    rw [stepCoinBundle_s4]
    simp only [bitsToStage4Equiv, Equiv.trans_apply, Equiv.refl_apply,
      Equiv.arrowCongr_apply, splitBlocksEquiv_apply]
    exact congrArg (bitsToBaseSeedEquiv cp) (funext fun k =>
      congrArg bits (Fin.ext (by change cp.B_S1 + cp.B_S2 + (i.val * cp.B_base + k.val) = off + k.val; dsimp only [off]; omega)))
  · have hk := hcoins ⟨off + k.val, by omega⟩
    push_cast at hk; exact hk

/-! ### 4. Briggs-Torczon Sparse Set (`EncSparseSet`) & `O(1)` Operations -/

/-- Briggs-Torczon sparse-set encoding of duplicate-free `arr : List ℕ` (`∀ y ∈ arr, y < N_cap`),
with length in `engMetaTbl[lenIdx]`, dense elements in `engArrTbl[elemOff ..]`, and inverse
positions in `engArrTbl[posOff ..]`. -/
def EncSparseSet (N_cap : ℕ) (lenIdx elemOff posOff : ℤ)
    (arr : List ℕ) (mem : ArithRAMMemory) : Prop :=
  arr.Nodup ∧
  (∀ y ∈ arr, y < N_cap) ∧
  wRead mem engMetaTbl lenIdx = (arr.length : ℤ) ∧
  (∀ i (hi : i < arr.length),
    wRead mem engArrTbl (elemOff + (i : ℤ)) = (arr[i]'hi : ℤ) ∧
    wRead mem engArrTbl (posOff + ((arr[i]'hi : ℕ) : ℤ)) = (i : ℤ))

theorem EncSparseSet.length_le {N_cap : ℕ} {lenIdx elemOff posOff : ℤ}
    {arr : List ℕ} {mem : ArithRAMMemory}
    (h : EncSparseSet N_cap lenIdx elemOff posOff arr mem) : arr.length ≤ N_cap := by
  rw [← List.toFinset_card_of_nodup h.1]
  have hsub : arr.toFinset ⊆ Finset.range N_cap := by
    intro y hy; exact Finset.mem_range.mpr (h.2.1 y (List.mem_toFinset.mp hy))
  exact (Finset.card_le_card hsub).trans (by simp)

theorem EncSparseSet.ext {N_cap : ℕ} {lenIdx elemOff posOff : ℤ}
    {arr : List ℕ} {m₁ m₂ : ArithRAMMemory}
    (h₁ : EncSparseSet N_cap lenIdx elemOff posOff arr m₁)
    (hlen : wRead m₂ engMetaTbl lenIdx = wRead m₁ engMetaTbl lenIdx)
    (helem : ∀ i < arr.length, wRead m₂ engArrTbl (elemOff + (i : ℤ)) =
      wRead m₁ engArrTbl (elemOff + (i : ℤ)))
    (hpos : ∀ y ∈ arr, wRead m₂ engArrTbl (posOff + (y : ℤ)) =
      wRead m₁ engArrTbl (posOff + (y : ℤ))) :
    EncSparseSet N_cap lenIdx elemOff posOff arr m₂ :=
  ⟨h₁.1, h₁.2.1, hlen.trans h₁.2.2.1, fun i hi =>
    ⟨(helem i hi).trans (h₁.2.2.2 i hi).1,
     (hpos (arr[i]'hi) (List.getElem_mem hi)).trans (h₁.2.2.2 i hi).2⟩⟩

/-- `O(1)` sparse-set membership test writing `1` (`x ∈ arr`) or `0` (`x ∉ arr`) to
`engScrTbl[outReg]`, using scratch registers `56, 57, 58` of `engScrTbl`.
Addresses `(lenIdx, elemOff, posOff, x)` are read from `engScrTbl` registers `< 56`! -/
def sparseContainsStmt (N_cap : ℕ) (lenIdxReg elemOffReg posOffReg xReg outReg : ℤ) :
    ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 56) (.readHeap engScrTbl (.lit xReg)))
  (.seq (.writeWordHeap engScrTbl (.lit 58)
          (.readHeap engMetaTbl (.readHeap engScrTbl (.lit lenIdxReg))))
    (.ite (.and (.intLe (.lit 0) (.readHeap engScrTbl (.lit 56)))
                (.intLt (.readHeap engScrTbl (.lit 56)) (.lit (N_cap : ℤ))))
      (.seq (.writeWordHeap engScrTbl (.lit 57)
              (.readHeap engArrTbl
                (.add (.readHeap engScrTbl (.lit posOffReg)) (.readHeap engScrTbl (.lit 56)))))
        (.ite (.and (.intLe (.lit 0) (.readHeap engScrTbl (.lit 57)))
                    (.intLt (.readHeap engScrTbl (.lit 57)) (.readHeap engScrTbl (.lit 58))))
          (.ite (.intEq (.readHeap engArrTbl
                       (.add (.readHeap engScrTbl (.lit elemOffReg)) (.readHeap engScrTbl (.lit 57))))
                     (.readHeap engScrTbl (.lit 56)))
            (.writeWordHeap engScrTbl (.lit outReg) (.lit 1))
            (.writeWordHeap engScrTbl (.lit outReg) (.lit 0)))
          (.writeWordHeap engScrTbl (.lit outReg) (.lit 0))))
      (.writeWordHeap engScrTbl (.lit outReg) (.lit 0))))

theorem zeroRand_sparseContainsStmt (N_cap : ℕ) (lR eR pR xR outR : ℤ) :
    ZeroRandStmt (sparseContainsStmt N_cap lR eR pR xR outR) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.ite (.seq (.writeWordHeap _ _ _)
      (.ite (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)) (.writeWordHeap _ _ _)))
      (.writeWordHeap _ _ _)))

theorem exec_sparseContainsStmt {d TW BW TR BR N_cap : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} {arr : List ℕ}
    {lenIdx elemOff posOff : ℤ} {x : ℕ}
    (lR eR pR xR outR : ℤ)
    (hTW : 9 ≤ TW) (hBW_scr : 64 ≤ BW)
    (hlR : lR < 56) (heR : eR < 56) (hpR : pR < 56) (hxR : xR < 56)
    (hout0 : 0 ≤ outR) (hout56 : outR < 56)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (henc : EncSparseSet N_cap lenIdx elemOff posOff arr m₀)
    (hread_l : wRead m₀ engScrTbl lR = lenIdx)
    (hread_e : wRead m₀ engScrTbl eR = elemOff)
    (hread_p : wRead m₀ engScrTbl pR = posOff)
    (hread_x : wRead m₀ engScrTbl xR = (x : ℤ)) :
    ExecDet TW BW TR BR inp (sparseContainsStmt N_cap lR eR pR xR outR) m₀
      (fun m₁ =>
        wRead m₁ engScrTbl outR = (if arr.contains x then 1 else 0) ∧
        (∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i < 56 → i ≠ outR → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      100 := by
  unfold sparseContainsStmt
  refine ExecDet.seq' 88
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 56) (.readHeap engScrTbl (.lit xR)) 56 (x : ℤ)
      hfp₀ (by unfold engScrTbl; omega) (by omega) (by omega) rfl (by simp [evalIntExpr]; exact hread_x)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro m₁ hm₁ hfp₁; subst hm₁
  have hl₁ : wRead (H3a.wWrite m₀ engScrTbl 56 (x : ℤ)) engScrTbl lR = lenIdx := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hread_l
  refine ExecDet.seq' 76
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 58)
      (.readHeap engMetaTbl (.readHeap engScrTbl (.lit lR))) 58 (arr.length : ℤ)
      hfp₁ (by unfold engScrTbl; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change wRead _ engMetaTbl (wRead _ engScrTbl lR) = _; rw [hl₁, wRead_wWrite_of_ne _ _ (Or.inl (by decide))]; exact henc.2.2.1)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro m₂ hm₂ hfp₂; subst hm₂
  have hx₂ : wRead (H3a.wWrite (H3a.wWrite m₀ engScrTbl 56 (x : ℤ)) engScrTbl 58 (arr.length : ℤ))
      engScrTbl 56 = (x : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hl₂ : wRead (H3a.wWrite (H3a.wWrite m₀ engScrTbl 56 (x : ℤ)) engScrTbl 58 (arr.length : ℤ))
      engScrTbl 58 = (arr.length : ℤ) := wRead_wWrite_self _ _ _ _
  have he₂ : wRead (H3a.wWrite (H3a.wWrite m₀ engScrTbl 56 (x : ℤ)) engScrTbl 58 (arr.length : ℤ))
      engScrTbl eR = elemOff := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    exact hread_e
  have hp₂ : wRead (H3a.wWrite (H3a.wWrite m₀ engScrTbl 56 (x : ℤ)) engScrTbl 58 (arr.length : ℤ))
      engScrTbl pR = posOff := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    exact hread_p
  set mA := H3a.wWrite (H3a.wWrite m₀ engScrTbl 56 (x : ℤ)) engScrTbl 58 (arr.length : ℤ)
  have hcond1 : (evalArithCond inp 0 mA
      (.and (.intLe (.lit 0) (.readHeap engScrTbl (.lit 56)))
            (.intLt (.readHeap engScrTbl (.lit 56)) (.lit (N_cap : ℤ))))).1 = decide (x < N_cap) := by
    simp only [evalArithCond, evalIntExpr]
    change (decide ((0 : ℤ) ≤ wRead mA engScrTbl 56) &&
            decide (wRead mA engScrTbl 56 < (N_cap : ℤ))) = decide (x < N_cap)
    rw [hx₂]
    by_cases hxN : x < N_cap <;> simp [hxN, Nat.cast_nonneg]
  refine ExecDet.ite' (C_c := 10) (C_b := 64) _ _ _ hcond1 (by simp [condExprOps, intExprOps])
    (fun htrue => ?_) (fun hfalse => ?_)
  · have hxN : x < N_cap := of_decide_eq_true htrue
    let p_val := wRead m₀ engArrTbl (posOff + (x : ℤ))
    have hp_mA : wRead mA engArrTbl (posOff + (x : ℤ)) = p_val := by
      simp only [mA, p_val]
      rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
    refine ExecDet.seq' 50
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 57)
        (.readHeap engArrTbl (.add (.readHeap engScrTbl (.lit pR)) (.readHeap engScrTbl (.lit 56))))
        57 p_val hfp₂ (by unfold engScrTbl; omega) (by omega) (by omega) rfl
        (by
          simp only [evalIntExpr]
          change wRead mA engArrTbl (wRead mA engScrTbl pR + wRead mA engScrTbl 56) = p_val
          rw [hp₂, hx₂, hp_mA])
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro m₃ hm₃ hfp₃; subst hm₃
    set mB := H3a.wWrite mA engScrTbl 57 p_val
    have hpB : wRead mB engScrTbl 57 = p_val := wRead_wWrite_self _ _ _ _
    have hlB : wRead mB engScrTbl 58 = (arr.length : ℤ) := by
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hl₂
    have hxB : wRead mB engScrTbl 56 = (x : ℤ) := by
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hx₂
    have heB : wRead mB engScrTbl eR = elemOff := by
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact he₂
    have hcond2 : (evalArithCond inp 0 mB
        (.and (.intLe (.lit 0) (.readHeap engScrTbl (.lit 57)))
              (.intLt (.readHeap engScrTbl (.lit 57)) (.readHeap engScrTbl (.lit 58))))).1 =
        decide (0 ≤ p_val ∧ p_val < (arr.length : ℤ)) := by
      simp only [evalArithCond, evalIntExpr]
      change (decide ((0 : ℤ) ≤ wRead mB engScrTbl 57) &&
              decide (wRead mB engScrTbl 57 < wRead mB engScrTbl 58)) = _
      rw [hpB, hlB, Bool.decide_and]
    refine ExecDet.ite' (C_c := 10) (C_b := 30) _ _ _ hcond2 (by simp [condExprOps, intExprOps])
      (fun htrue2 => ?_) (fun hfalse2 => ?_)
    · obtain ⟨hp0, hpL⟩ := of_decide_eq_true htrue2
      let p_nat := p_val.toNat
      have hp_eq : (p_nat : ℤ) = p_val := Int.toNat_of_nonneg hp0
      have hp_lt : p_nat < arr.length := by omega
      have helem_mB : wRead mB engArrTbl (elemOff + p_val) = (arr[p_nat]'hp_lt : ℤ) := by
        simp only [mB, mA]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        rw [← hp_eq]; exact (henc.2.2.2 p_nat hp_lt).1
      have hcond3 : (evalArithCond inp 0 mB
          (.intEq (.readHeap engArrTbl
                 (.add (.readHeap engScrTbl (.lit eR)) (.readHeap engScrTbl (.lit 57))))
               (.readHeap engScrTbl (.lit 56)))).1 =
          decide (arr[p_nat]'hp_lt = x) := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mB engArrTbl (wRead mB engScrTbl eR + wRead mB engScrTbl 57) =
          wRead mB engScrTbl 56) = _
        rw [heB, hpB, helem_mB, hxB]
        by_cases hax : arr[p_nat]'hp_lt = x <;> simp [hax]
      refine ExecDet.ite' (C_c := 12) (C_b := 18) _ _ _ hcond3 (by simp [condExprOps, intExprOps])
        (fun htrue3 => ?_) (fun hfalse3 => ?_)
      · have hax : arr[p_nat]'hp_lt = x := of_decide_eq_true htrue3
        have hmem : arr.contains x = true :=
          List.contains_iff_mem.mpr (hax ▸ List.getElem_mem hp_lt)
        refine ExecDet.wWrite inp engScrTbl (.lit outR) (.lit 1) outR 1
          hfp₃ (by unfold engScrTbl; omega) hout0 (by omega) rfl rfl (by simp [intExprOps]) ?_
        refine ⟨by rw [wRead_wWrite_self, hmem]; rfl, fun t ht i => ?_, fun i hi hne => ?_,
          fun t i => by simp [mB, mA, rRead_wWrite]⟩
        · simp only [mB, mA]; (iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)])
        · simp only [mB, mA]
          rw [wRead_wWrite_of_ne _ _ (Or.inr hne)]
          iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      · have hax : arr[p_nat]'hp_lt ≠ x := of_decide_eq_false hfalse3
        have hnot_mem : arr.contains x = false := by
          rw [Bool.eq_false_iff, Ne, List.contains_iff_mem]
          intro hmem
          obtain ⟨k, hk, hkx⟩ := List.mem_iff_getElem.mp hmem
          have hpk : p_val = (k : ℤ) := by
            dsimp only [p_val]; rw [← hkx]; exact (henc.2.2.2 k hk).2
          have : p_nat = k := by omega
          subst this; exact hax hkx
        refine ExecDet.wWrite inp engScrTbl (.lit outR) (.lit 0) outR 0
          hfp₃ (by unfold engScrTbl; omega) hout0 (by omega) rfl rfl (by simp [intExprOps]) ?_
        refine ⟨by rw [wRead_wWrite_self, hnot_mem]; rfl, fun t ht i => ?_, fun i hi hne => ?_,
          fun t i => by simp [mB, mA, rRead_wWrite]⟩
        · simp only [mB, mA]; (iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)])
        · simp only [mB, mA]
          rw [wRead_wWrite_of_ne _ _ (Or.inr hne)]
          iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    · have hp_out : ¬ (0 ≤ p_val ∧ p_val < (arr.length : ℤ)) := of_decide_eq_false hfalse2
      have hnot_mem : arr.contains x = false := by
        rw [Bool.eq_false_iff, Ne, List.contains_iff_mem]
        intro hmem
        obtain ⟨k, hk, hkx⟩ := List.mem_iff_getElem.mp hmem
        have hpk : p_val = (k : ℤ) := by
          dsimp only [p_val]; rw [← hkx]; exact (henc.2.2.2 k hk).2
        exact hp_out ⟨by omega, by omega⟩
      refine ExecDet.wWrite inp engScrTbl (.lit outR) (.lit 0) outR 0
        hfp₃ (by unfold engScrTbl; omega) hout0 (by omega) rfl rfl (by simp [intExprOps]) ?_
      refine ⟨by rw [wRead_wWrite_self, hnot_mem]; rfl, fun t ht i => ?_, fun i hi hne => ?_,
        fun t i => by simp [mB, mA, rRead_wWrite]⟩
      · simp only [mB, mA]; (iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)])
      · simp only [mB, mA]
        rw [wRead_wWrite_of_ne _ _ (Or.inr hne)]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  · have hxN : ¬ (x < N_cap) := of_decide_eq_false hfalse
    have hnot_mem : arr.contains x = false := by
      rw [Bool.eq_false_iff, Ne, List.contains_iff_mem]
      exact fun hm => hxN (henc.2.1 x hm)
    refine ExecDet.wWrite inp engScrTbl (.lit outR) (.lit 0) outR 0
      hfp₂ (by unfold engScrTbl; omega) hout0 (by omega) rfl rfl (by simp [intExprOps]) ?_
    refine ⟨by rw [wRead_wWrite_self, hnot_mem]; rfl, fun t ht i => ?_, fun i hi hne => ?_,
      fun t i => by simp [mA, rRead_wWrite]⟩
    · simp only [mA]; (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)])
    · simp only [mA]
      rw [wRead_wWrite_of_ne _ _ (Or.inr hne)]
      iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]


end UL.Proof.clm_9_1_explicit_tradeoff.CG19
