import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB3
import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInstA0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### Parametric `mkConfigMatchRAMOps` from `SideRAMOps` & Explicit Stride/Cost Bounds -/

def mkConfigMatchRAMOps
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    (params : LocalScaleParams) (h : ℝ)
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) :
    ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat
      params h τ_d τ_q cap_u cap_q scrW scrR tblW tblR coinTbl where
  cfgWStride := cfgTotalWStride n sops.sideWStride
  cfgRStride := cfgTotalRStride sops.sideRStride
  hcfgW_nonneg := by
    have := sops.hsideW_ge_two
    have := cfgHdrWStride_ge_three n
    unfold cfgTotalWStride; omega
  hcfgR_nonneg := by
    have := sops.hsideR_nonneg
    unfold cfgTotalRStride; omega
  opWScrStride := configDynOpWScr sops
  opRScrStride := configDynOpRScr sops
  hopWScr_pos := by
    have := sops.hsideWScr_pos
    unfold configDynOpWScr; omega
  hopRScr_pos := by
    have := sops.hsideRScr_pos
    unfold configDynOpRScr; omega
  clearCost := configDynClearCost sops
  insertCost := configDynInsertCost sops
  deleteCost := configDynDeleteCost sops
  readEdgeCost := configDynReadEdgeCost

  CfgReady := fun _ cfgBaseW cfgBaseR m => CfgSlotReady sops cfgBaseW cfgBaseR m
  EncCfg := fun _ cfgBaseW cfgBaseR _ _ _ _ cs m => EncCfgDyn sops cfgBaseW cfgBaseR cs m

  cfgReady_of_zero := fun _ cfgBaseW cfgBaseR m hz =>
    cfgSlotReady_of_zero sops cfgBaseW cfgBaseR m hz
  cfgReady_of_enc := fun _ cfgBaseW cfgBaseR _ _ _ _ cs m henc =>
    cfgSlotReady_of_enc sops cfgBaseW cfgBaseR cs m henc
  cfgReady_mono_slice := fun _ cfgBaseW cfgBaseR m₀ m₁ hrdy hkW hkR =>
    cfgSlotReady_mono_slice sops cfgBaseW cfgBaseR m₀ m₁ hrdy hkW hkR

  encCfg_pts_congr := fun _ _ _ _ _ _ _ _ _ _ _ henc => henc
  encCfg_mono_slice := fun _ _ _ _ _ _ _ _ _ _ henc hkW hkR _ =>
    henc.mono_slice sops hkW hkR

  clearStmt := fun _ wCfgBaseW wCfgBaseR wScr rScr =>
    configDynClearStmt sops wCfgBaseW wCfgBaseR wScr rScr
  insertStmt := fun spec wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr =>
    configDynInsertStmt sops spec wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
  deleteStmt := fun spec wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr =>
    configDynDeleteStmt sops spec wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
  readEdgeStmt := fun _ wCfgBaseW wOutHas wOutU wOutV wScr =>
    configDynReadEdgeStmt scrW tblW n wCfgBaseW wOutHas wOutU wOutV wScr

  zeroRand_clearStmt := fun _ => zeroRand_configDynClearStmt sops
  zeroRand_insertStmt := fun spec => zeroRand_configDynInsertStmt sops spec
  zeroRand_deleteStmt := fun spec => zeroRand_configDynDeleteStmt sops spec
  zeroRand_readEdgeStmt := fun _ => zeroRand_configDynReadEdgeStmt scrW tblW n

  exec_clearStmt := by
    intro TW BW TR BR inp m₀ _ wCfgBaseW wCfgBaseR wScr rScr cfgBaseW cfgBaseR _ _ _
      hfp₀ hvt hbaseW hbaseR hwBW hwBR hwScr hrScr hbW hbR hrdy
    exact exec_configDynClearStmt sops inp wCfgBaseW wCfgBaseR wScr rScr cfgBaseW cfgBaseR
      hfp₀ hvt hbaseW hbaseR hwBW hwBR
      ⟨hwScr.1, by unfold configDynClearWScr; unfold configDynOpWScr at hwScr; omega⟩
      ⟨hrScr.1, by unfold configDynOpRScr at hrScr; omega⟩
      hbW hbR hrdy

  exec_insertStmt := by
    intro TW BW TR BR inp m₀ hM₀ hn hL_p2 spec
      wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
      cfgBaseW cfgBaseR offO offV seedOff
      pts o V hV S p hp_not hp_lt hS_lt hS_card ω_L ω_R cs htL htR hwf
      hfp₀ hvt hbaseW hbaseR hoffO hoffV hseedB hptsB
      hwBW hwBR hwO hwV hwUid hwSeed hwScr hrScr
      hbW hbR ho_off hv_off hp_r hseed_off ho_mem hv_mem hpts hseed henc
    exact exec_configDynInsertStmt sops inp hM₀ hn hL_p2 spec
      wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
      cfgBaseW cfgBaseR offO offV seedOff
      hV hp_not hp_lt hS_lt hS_card ω_L ω_R htL htR hwf
      hfp₀ hvt hbaseW hbaseR hoffO hoffV hseedB hptsB
      hwBW hwBR hwO hwV hwUid hwSeed hwScr hrScr
      hbW hbR ho_off hv_off hp_r hseed_off ho_mem hv_mem hpts hseed henc

  exec_deleteStmt := by
    intro TW BW TR BR inp m₀ hM₀ hn hL_p2 spec
      wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
      cfgBaseW cfgBaseR offO offV seedOff
      pts o V hV S p hp_mem hp_lt hS_lt hS_card ω_L ω_R cs htL htR hwf
      hfp₀ hvt hbaseW hbaseR hoffO hoffV hseedB hptsB
      hwBW hwBR hwO hwV hwUid hwSeed hwScr hrScr
      hbW hbR ho_off hv_off hp_r hseed_off ho_mem hv_mem hpts hseed henc
    exact exec_configDynDeleteStmt sops inp hM₀ hn hL_p2 spec
      wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
      cfgBaseW cfgBaseR offO offV seedOff
      hV hp_mem hp_lt hS_lt hS_card ω_L ω_R htL htR hwf
      hfp₀ hvt hbaseW hbaseR hoffO hoffV hseedB hptsB
      hwBW hwBR hwO hwV hwUid hwSeed hwScr hrScr
      hbW hbR ho_off hv_off hp_r hseed_off ho_mem hv_mem hpts hseed henc

  exec_readEdgeStmt := by
    intro TW BW TR BR inp m₀ _ wCfgBaseW wOutHas wOutU wOutV wScr cfgBaseW cfgBaseR
      _ _ _ _ cs hfp₀ hvt _ hwBW hwHas hwU hwV hne_out hwScr hbW henc
    have := sops.hsideWScr_pos
    exact exec_configDynReadEdgeStmt (tblR := tblR) (coinTbl := coinTbl) inp
      wCfgBaseW wOutHas wOutU wOutV wScr cfgBaseW cfgBaseR
      hfp₀ hvt hwBW hwHas hwU hwV hne_out
      ⟨hwScr.1, by unfold configDynOpWScr at hwScr; omega⟩
      hbW henc.1

/-! ### Explicit Stride and Cost Bounds for `mkConfigMatchRAMOps` -/

section Bounds
variable {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
variable (params : LocalScaleParams) (h : ℝ)
variable {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
variable {scrW scrR tblW tblR coinTbl : ℕ}
variable (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
  scrW scrR tblW tblR coinTbl)

@[simp] theorem mkConfigMatchRAMOps_cfgWStride :
    (mkConfigMatchRAMOps params h sops).cfgWStride =
      3 + 8 * (n : ℤ) + 2 * sops.sideWStride := rfl

@[simp] theorem mkConfigMatchRAMOps_cfgRStride :
    (mkConfigMatchRAMOps params h sops).cfgRStride =
      2 * sops.sideRStride := rfl

@[simp] theorem mkConfigMatchRAMOps_opWScrStride :
    (mkConfigMatchRAMOps params h sops).opWScrStride =
      16 + sops.sideWScrStride := rfl

@[simp] theorem mkConfigMatchRAMOps_opRScrStride :
    (mkConfigMatchRAMOps params h sops).opRScrStride =
      2 + sops.sideRScrStride := rfl

@[simp] theorem mkConfigMatchRAMOps_readEdgeCost :
    (mkConfigMatchRAMOps params h sops).readEdgeCost = 120 := rfl

theorem mkConfigMatchRAMOps_clearCost_le :
    (mkConfigMatchRAMOps params h sops).clearCost ≤
      220 + 2 * sops.zeroInitCost + 2 * sops.clearCost := by
  change configDynClearCost sops ≤ _
  unfold configDynClearCost
  omega

theorem mkConfigMatchRAMOps_insertCost_le :
    (mkConfigMatchRAMOps params h sops).insertCost ≤
      1720 + 55 * d + 2 * sops.queryCost + 2 * sops.insertCost + 2 * sops.removeCost := by
  change configDynInsertCost sops ≤ _
  unfold configDynInsertCost attachCopyCost appendEdgeCost
  omega

theorem mkConfigMatchRAMOps_deleteCost_le :
    (mkConfigMatchRAMOps params h sops).deleteCost ≤
      2700 + 2 * sops.queryCost + 2 * sops.insertCost + 4 * sops.removeCost := by
  change configDynDeleteCost sops ≤ _
  unfold configDynDeleteCost attachCopyCost appendEdgeCost unlinkLeftKeyCost
  omega

end Bounds

/-! ### `SideHeapZeroRand` & `mkConfigMatchHeapZeroRand` (`HeapZeroRandStmt` Packaging) -/

structure SideHeapZeroRand
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : Prop where
  hzr_zeroInitStmt : ∀ wBW wBR wScr rScr,
    HeapZeroRandStmt (sops.zeroInitStmt wBW wBR wScr rScr)
  hzr_clearStmt : ∀ wBW wBR wScr rScr,
    HeapZeroRandStmt (sops.clearStmt wBW wBR wScr rScr)
  hzr_removeStmt : ∀ wBW wBR wUid wScr rScr,
    HeapZeroRandStmt (sops.removeStmt wBW wBR wUid wScr rScr)
  hzr_insertStmt : ∀ A B_rat wBW wBR wOffO wUid wSeed wScr rScr,
    HeapZeroRandStmt (sops.insertStmt A B_rat wBW wBR wOffO wUid wSeed wScr rScr)
  hzr_queryStmt : ∀ A B_rat b_rat wBW wBR wOffO wQry wAns wScr rScr,
    HeapZeroRandStmt (sops.queryStmt A B_rat b_rat wBW wBR wOffO wQry wAns wScr rScr)

theorem hzr_appendEdgeStmt (scrW tblW n : ℕ) (wCfgBaseW wU wV wScr : ℤ) :
    HeapZeroRandStmt (appendEdgeStmt scrW tblW n wCfgBaseW wU wV wScr) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
        (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))))))))

theorem hzr_unlinkLeftKeyStmt (scrW tblW n : ℕ) (wCfgBaseW wK wScr : ℤ) :
    HeapZeroRandStmt (unlinkLeftKeyStmt scrW tblW n wCfgBaseW wK wScr) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
        (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))))

theorem hzr_attachLeftCopyStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    {sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    (shzr : SideHeapZeroRand sops) (A B_rat b_rat : ℚ)
    (wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr : ℤ) :
    HeapZeroRandStmt (attachLeftCopyStmt sops A B_rat b_rat
      wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (shzr.hzr_queryStmt _ _ _ _ _ _ _ _ _ _)
    (.ite
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (shzr.hzr_insertStmt _ _ _ _ _ _ _ _ _)))))
      (.seq (.writeWordHeap _ _ _) (.seq (hzr_appendEdgeStmt _ _ _ _ _ _ _)
            (shzr.hzr_removeStmt _ _ _ _ _))))))))

theorem hzr_attachRightCopyStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    {sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    (shzr : SideHeapZeroRand sops) (A B_rat b_rat : ℚ)
    (wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr : ℤ) :
    HeapZeroRandStmt (attachRightCopyStmt sops A B_rat b_rat
      wCfgBaseW wCfgBaseR wOffO wVId wSeedOff wScr rScr) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _) (.seq (shzr.hzr_queryStmt _ _ _ _ _ _ _ _ _ _)
    (.ite
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (shzr.hzr_insertStmt _ _ _ _ _ _ _ _ _)))))
      (.seq (.writeWordHeap _ _ _) (.seq (hzr_appendEdgeStmt _ _ _ _ _ _ _)
            (shzr.hzr_removeStmt _ _ _ _ _))))))))

theorem mkConfigMatchHeapZeroRand
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    (params : LocalScaleParams) (h : ℝ)
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    {sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    (shzr : SideHeapZeroRand sops) :
    ConfigMatchHeapZeroRand (mkConfigMatchRAMOps params h sops) where
  hzr_clearStmt := fun _ _ _ _ _ =>
    .ite
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (shzr.hzr_zeroInitStmt _ _ _ _)
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
            (shzr.hzr_zeroInitStmt _ _ _ _)))))))))
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (shzr.hzr_clearStmt _ _ _ _)
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
            (shzr.hzr_clearStmt _ _ _ _)))))))))
  hzr_insertStmt := fun _ _ _ _ _ _ _ _ _ =>
    .seq (hzr_sqDistPtCenterStmt _ _ _ _ _ _ _ _ _)
    (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
    (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
    (.seq (.ite (hzr_attachLeftCopyStmt shzr _ _ _ _ _ _ _ _ _ _) .skip)
          (.ite (hzr_attachRightCopyStmt shzr _ _ _ _ _ _ _ _ _ _) .skip))))
  hzr_deleteStmt := fun _ _ _ _ _ _ _ _ _ =>
    .seq
      (.seq
        (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
        (.seq (.ite
                (.seq (.writeWordHeap _ _ _) (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
                      (hzr_unlinkLeftKeyStmt _ _ _ _ _ _)))
                (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
        (.seq (.writeWordHeap _ _ _)
        (.seq (.ite
                (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
                      (hzr_unlinkLeftKeyStmt _ _ _ _ _ _)))
                (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
        (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))))
        (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
        (.seq (shzr.hzr_removeStmt _ _ _ _ _)
        (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
              (shzr.hzr_removeStmt _ _ _ _ _)))))))
      (.seq (.ite (hzr_attachRightCopyStmt shzr _ _ _ _ _ _ _ _ _ _) .skip)
            (.ite (hzr_attachLeftCopyStmt shzr _ _ _ _ _ _ _ _ _ _) .skip))
  hzr_readEdgeStmt := fun _ _ _ _ _ _ =>
    .seq (.writeWordHeap _ _ _)
      (.ite (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
