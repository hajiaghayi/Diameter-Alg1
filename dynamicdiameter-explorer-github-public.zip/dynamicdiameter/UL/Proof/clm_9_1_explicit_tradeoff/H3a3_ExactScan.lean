import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Def.def_C_2_schedule
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H3a3

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2

private lemma exactScan_cost_outer (maxCap d : ℕ) :
    70 + (4 + (1 + maxCap * ((80 + maxCap * (180 + 75 * d)) + 6))) ≤
      100 + maxCap * (100 + maxCap * (200 + 80 * d)) := by
  have h1 : (80 + maxCap * (180 + 75 * d)) + 6 ≤ 100 + maxCap * (200 + 80 * d) := by nlinarith
  have h2 := Nat.mul_le_mul_left maxCap h1
  omega

private lemma exactScan_cost_inner (maxCap d : ℕ) :
    4 + (1 + maxCap * ((165 + 75 * d) + 6)) ≤
      80 + maxCap * (180 + 75 * d) := by nlinarith

private lemma exactScan_cost_body (d : ℕ) :
    12 + (12 + (30 + ((4 + (1 + d * (65 + 6))) + (15 + 60)))) ≤
      150 + 75 * d := by omega

private lemma le_of_sq_le_sq_nonneg {a b : ℝ} (hb : 0 ≤ b) (h : a ^ 2 ≤ b ^ 2) : a ≤ b :=
  (abs_le_of_sq_le_sq' h hb).2

private lemma peakSpace_le_exact (c n d : ℕ) (hc : c ≤ n) :
    3 + c * d + d + (8 * (n + 8) + 4 * (n * d + 8)) ≤
      8 * (n + 8) + 4 * (n * d + 8) + (d + 4) + n * d := by
  have hcd : c * d ≤ n * d := Nat.mul_le_mul_right d hc
  omega

private lemma peakSpace_le_exact_del (c n d : ℕ) (hc : c ≤ n) :
    3 + c * d + 0 + (8 * (n + 8) + 4 * (n * d + 8)) ≤
      8 * (n + 8) + 4 * (n * d + 8) + (d + 4) + n * d := by
  have hcd : c * d ≤ n * d := Nat.mul_le_mul_right d hc
  omega

theorem ExecDet.rWriteEq {d : ℕ} {TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (tbl : ℕ) (idxE : IntExpr) (valE : RealExpr) (idx : ℤ) (val : ℝ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : tbl < TR) (hi0 : 0 ≤ idx) (hiB : idx < (BR : ℤ))
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hval : (evalRealExpr inp 0 m₀ valE).1 = val)
    (hcost : intExprOps idxE + realExprOps valE + 1 ≤ 30) :
    ExecDet TW BW TR BR inp (.writeRealHeap tbl idxE valE) m₀
      (fun m => m = H3a.rWrite m₀ tbl idx val) 30 :=
  ExecDet.rWrite inp tbl idxE valE idx val hfp₀ htbl hi0 hiB hidx hval hcost rfl

/-- Exact squared Euclidean distance `‖x - y‖^2 = ∑ c : Fin d, (x_c - y_c)^2`. -/
theorem norm_sub_sq_eq_sum_coord {d : ℕ} (x y : EuclideanSpace ℝ (Fin d)) :
    ‖x - y‖ ^ 2 = ∑ c : Fin d, (euclideanCoord x c - euclideanCoord y c) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
  refine Finset.sum_congr rfl fun c _ => ?_
  simp [euclideanCoord, sq]

/-- Parameterized exact pairwise squared-distance scan over `arrTbl[0 .. sz - 1]` (`sz = wRead szTbl szIdx`),
reading point coordinates from `realHeap 1 (h * d + c)`, using `scrWTbl (0..4)` and `scrRTbl (0..1)`,
and writing `(hasPair, h1, h2)` to `outWTbl (outHas, outH1, outH2)` and `distSq` to `outRTbl outSq`. -/
def exactPairwiseScanStmt
    (arrTbl szTbl : ℕ) (szIdx : ℤ)
    (outWTbl : ℕ) (outHas outH1 outH2 : ℤ)
    (outRTbl : ℕ) (outSq : ℤ)
    (scrWTbl scrRTbl : ℕ)
    (maxCap d : ℕ) : ArithRAMStmt :=
  .seq
    (.seq (.writeWordHeap outWTbl (.lit outHas) (.lit 0))
      (.seq (.writeWordHeap outWTbl (.lit outH1) (.lit 0))
        (.seq (.writeWordHeap outWTbl (.lit outH2) (.lit 0))
          (.writeRealHeap outRTbl (.lit outSq) (.ofInt (.lit 0))))))
    (forLoopStmt scrWTbl 0 maxCap
      (forLoopStmt scrWTbl 1 maxCap
        (.ite (.and (.intLt (.readHeap scrWTbl (.lit 0)) (.readHeap scrWTbl (.lit 1)))
                    (.intLt (.readHeap scrWTbl (.lit 1)) (.readHeap szTbl (.lit szIdx))))
          (.seq (.writeWordHeap scrWTbl (.lit 2) (.readHeap arrTbl (.readHeap scrWTbl (.lit 0))))
            (.seq (.writeWordHeap scrWTbl (.lit 3) (.readHeap arrTbl (.readHeap scrWTbl (.lit 1))))
              (.seq (.writeRealHeap scrRTbl (.lit 0) (.ofInt (.lit 0)))
                (.seq
                  (forLoopStmt scrWTbl 4 d
                    (.seq
                      (.writeRealHeap scrRTbl (.lit 1)
                        (.sub
                          (.readRealHeap 1 (.add (.mul (.readHeap scrWTbl (.lit 2)) (.lit (d : ℤ)))
                                                 (.readHeap scrWTbl (.lit 4))))
                          (.readRealHeap 1 (.add (.mul (.readHeap scrWTbl (.lit 3)) (.lit (d : ℤ)))
                                                 (.readHeap scrWTbl (.lit 4))))))
                      (.writeRealHeap scrRTbl (.lit 0)
                        (.add (.readRealHeap scrRTbl (.lit 0))
                              (.mul (.readRealHeap scrRTbl (.lit 1)) (.readRealHeap scrRTbl (.lit 1)))))))
                  (.ite (.or (.intEq (.readHeap outWTbl (.lit outHas)) (.lit 0))
                             (.realLt (.readRealHeap outRTbl (.lit outSq)) (.readRealHeap scrRTbl (.lit 0))))
                    (.seq (.writeWordHeap outWTbl (.lit outHas) (.lit 1))
                      (.seq (.writeWordHeap outWTbl (.lit outH1) (.readHeap scrWTbl (.lit 2)))
                        (.seq (.writeWordHeap outWTbl (.lit outH2) (.readHeap scrWTbl (.lit 3)))
                          (.writeRealHeap outRTbl (.lit outSq) (.readRealHeap scrRTbl (.lit 0))))))
                    .skip)))))
          .skip)))

theorem zeroRand_exactPairwiseScanStmt
    (arrTbl szTbl : ℕ) (szIdx : ℤ)
    (outWTbl : ℕ) (outHas outH1 outH2 : ℤ)
    (outRTbl : ℕ) (outSq : ℤ)
    (scrWTbl scrRTbl : ℕ) (maxCap d : ℕ) :
    ZeroRandStmt (exactPairwiseScanStmt arrTbl szTbl szIdx outWTbl outHas outH1 outH2 outRTbl outSq scrWTbl scrRTbl maxCap d) := by
  unfold exactPairwiseScanStmt forLoopStmt
  repeat' constructor

/-- Invariant over a visited set `V ⊆ Finset.range sz ×ˢ Finset.range sz` of ordered index pairs `(a < b)`. -/
def ScanBestInv {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d)) (L_h : List ℕ)
    (outWTbl : ℕ) (outHas outH1 outH2 : ℤ) (outRTbl : ℕ) (outSq : ℤ)
    (V : Finset (ℕ × ℕ)) (mem : ArithRAMMemory) : Prop :=
  if V = ∅ then
    wRead mem outWTbl outHas = 0 ∧
    wRead mem outWTbl outH1 = 0 ∧
    wRead mem outWTbl outH2 = 0 ∧
    rRead mem outRTbl outSq = 0
  else
    wRead mem outWTbl outHas = 1 ∧
    ∃ (a b : ℕ) (hb : b < L_h.length) (hab : a < b),
      (a, b) ∈ V ∧
      let h₁ := L_h[a]'(Nat.lt_trans hab hb)
      let h₂ := L_h[b]'hb
      wRead mem outWTbl outH1 = (h₁ : ℤ) ∧
      wRead mem outWTbl outH2 = (h₂ : ℤ) ∧
      rRead mem outRTbl outSq = ‖pts h₁ - pts h₂‖ ^ 2 ∧
      ∀ (p : ℕ × ℕ), p ∈ V → ∀ (hpb : p.2 < L_h.length) (hpab : p.1 < p.2),
        ‖pts (L_h[p.1]'(Nat.lt_trans hpab hpb)) - pts (L_h[p.2]'hpb)‖ ^ 2 ≤
          rRead mem outRTbl outSq

theorem exec_exactPairwiseScan {d TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (arrTbl szTbl : ℕ) (szIdx : ℤ)
    (outWTbl : ℕ) (outHas outH1 outH2 : ℤ)
    (outRTbl : ℕ) (outSq : ℤ)
    (scrWTbl scrRTbl : ℕ)
    (maxCap n : ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d)) (L_h : List ℕ)
    {m₀ : ArithRAMMemory}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (h_arrT : arrTbl < TW) (h_szT : szTbl < TW) (h_outWT : outWTbl < TW) (h_scrWT : scrWTbl < TW)
    (h_outRT : outRTbl < TR) (h_scrRT : scrRTbl < TR) (h_ptRT : 1 < TR)
    (h_ne_scrW_arr : scrWTbl ≠ arrTbl) (h_ne_scrW_sz : scrWTbl ≠ szTbl) (h_ne_scrW_out : scrWTbl ≠ outWTbl)
    (h_ne_out_arr : outWTbl ≠ arrTbl)
    (h_sz_not_out : szTbl ≠ outWTbl ∨ (szIdx ≠ outHas ∧ szIdx ≠ outH1 ∧ szIdx ≠ outH2))
    (h_out_distinct : outHas ≠ outH1 ∧ outHas ≠ outH2 ∧ outH1 ≠ outH2)
    (h_outW_bounds : 0 ≤ outHas ∧ outHas < (BW : ℤ) ∧ 0 ≤ outH1 ∧ outH1 < (BW : ℤ) ∧ 0 ≤ outH2 ∧ outH2 < (BW : ℤ))
    (h_outR_bounds : 0 ≤ outSq ∧ outSq < (BR : ℤ))
    (h_scrW_bounds : 5 ≤ BW) (h_scrR_bounds : 2 ≤ BR)
    (h_ne_scrR_pt : scrRTbl ≠ 1) (h_ne_outR_pt : outRTbl ≠ 1) (h_ne_scrR_outR : scrRTbl ≠ outRTbl)
    (h_nd : L_h.Nodup) (h_cap : L_h.length ≤ maxCap)
    (h_lt_n : ∀ h ∈ L_h, h < n)
    (h_sz_mem : wRead m₀ szTbl szIdx = (L_h.length : ℤ))
    (h_arr_mem : ∀ i (hi : i < L_h.length), wRead m₀ arrTbl (i : ℤ) = (L_h[i]'hi : ℤ))
    (h_pts_mem : ∀ h ∈ L_h, ∀ c : Fin d, rRead m₀ 1 ((h * d + c.val : ℕ) : ℤ) = euclideanCoord (pts h) c) :
    ExecDet TW BW TR BR inp
      (exactPairwiseScanStmt arrTbl szTbl szIdx outWTbl outHas outH1 outH2 outRTbl outSq scrWTbl scrRTbl maxCap d)
      m₀
      (fun mF =>
        let hasP := wRead mF outWTbl outHas
        let h1 := wRead mF outWTbl outH1
        let h2 := wRead mF outWTbl outH2
        let sqVal := rRead mF outRTbl outSq
        let leafPair : Option (ℕ × ℕ) :=
          if hasP = 1 ∧ 0 ≤ h1 ∧ 0 ≤ h2 then some (h1.toNat, h2.toNat) else none
        IsExactLeafAnswer pts L_h.toFinset leafPair ∧
        sqVal = (baselinePairLength pts leafPair) ^ 2 ∧
        (∀ t idx, t ≠ outWTbl → t ≠ scrWTbl → wRead mF t idx = wRead m₀ t idx) ∧
        (∀ idx, idx ≠ outHas → idx ≠ outH1 → idx ≠ outH2 → wRead mF outWTbl idx = wRead m₀ outWTbl idx) ∧
        (∀ t idx, t ≠ outRTbl → t ≠ scrRTbl → rRead mF t idx = rRead m₀ t idx) ∧
        (∀ idx, idx ≠ outSq → rRead mF outRTbl idx = rRead m₀ outRTbl idx))
      (100 + maxCap * (100 + maxCap * (200 + 80 * d))) := by
  let Preserve (m : ArithRAMMemory) : Prop :=
    (∀ t idx, t ≠ outWTbl → t ≠ scrWTbl → wRead m t idx = wRead m₀ t idx) ∧
    (∀ idx, idx ≠ outHas → idx ≠ outH1 → idx ≠ outH2 → wRead m outWTbl idx = wRead m₀ outWTbl idx) ∧
    (∀ t idx, t ≠ outRTbl → t ≠ scrRTbl → rRead m t idx = rRead m₀ t idx) ∧
    (∀ idx, idx ≠ outSq → rRead m outRTbl idx = rRead m₀ outRTbl idx)
  have hsz_from_pres : ∀ m, Preserve m → wRead m szTbl szIdx = (L_h.length : ℤ) := by
    intro m hp
    rcases h_sz_not_out with hne | ⟨h1, h2, h3⟩
    · rw [hp.1 szTbl szIdx hne h_ne_scrW_sz.symm, h_sz_mem]
    · by_cases heq : szTbl = outWTbl
      · subst heq; rw [hp.2.1 szIdx h1 h2 h3, h_sz_mem]
      · rw [hp.1 szTbl szIdx heq h_ne_scrW_sz.symm, h_sz_mem]
  have harr_from_pres : ∀ m, Preserve m → ∀ i (hi : i < L_h.length),
      wRead m arrTbl (i : ℤ) = (L_h[i]'hi : ℤ) := by
    intro m hp i hi
    rw [hp.1 arrTbl (i : ℤ) h_ne_out_arr.symm h_ne_scrW_arr.symm, h_arr_mem i hi]
  have hpts_from_pres : ∀ m, Preserve m → ∀ h ∈ L_h, ∀ c : Fin d,
      rRead m 1 ((h * d + c.val : ℕ) : ℤ) = euclideanCoord (pts h) c := by
    intro m hp h hh c
    rw [hp.2.2.1 1 _ h_ne_outR_pt.symm h_ne_scrR_pt.symm, h_pts_mem h hh c]

  unfold exactPairwiseScanStmt
  -- Step 1: Initialize outHas, outH1, outH2 := 0 and outSq := 0
  have hinit : ExecDet TW BW TR BR inp
      (.seq (.writeWordHeap outWTbl (.lit outHas) (.lit 0))
        (.seq (.writeWordHeap outWTbl (.lit outH1) (.lit 0))
          (.seq (.writeWordHeap outWTbl (.lit outH2) (.lit 0))
            (.writeRealHeap outRTbl (.lit outSq) (.ofInt (.lit 0))))))
      m₀ (fun m => Preserve m ∧ ScanBestInv pts L_h outWTbl outHas outH1 outH2 outRTbl outSq ∅ m) 70 := by
    refine (ExecDet.seq
      (ExecDet.wWriteEq inp outWTbl (.lit outHas) (.lit 0) outHas 0 hfp₀ h_outWT h_outW_bounds.1 h_outW_bounds.2.1 rfl rfl (by simp [intExprOps]))
      fun m1 hm1 hfp1 => by
        subst hm1
        refine ExecDet.seq
          (ExecDet.wWriteEq inp outWTbl (.lit outH1) (.lit 0) outH1 0 hfp1 h_outWT h_outW_bounds.2.2.1 h_outW_bounds.2.2.2.1 rfl rfl (by simp [intExprOps]))
          fun m2 hm2 hfp2 => by
            subst hm2
            refine ExecDet.seq
              (ExecDet.wWriteEq inp outWTbl (.lit outH2) (.lit 0) outH2 0 hfp2 h_outWT h_outW_bounds.2.2.2.2.1 h_outW_bounds.2.2.2.2.2 rfl rfl (by simp [intExprOps]))
              fun m3 hm3 hfp3 => by
                subst hm3
                refine ExecDet.rWrite (C := 12) inp outRTbl (.lit outSq) (.ofInt (.lit 0)) outSq 0
                  hfp3 h_outRT h_outR_bounds.1 h_outR_bounds.2 rfl (by simp [evalRealExpr, evalIntExpr])
                  (by simp [intExprOps, realExprOps]) ?_
                refine ⟨⟨?_, ?_, ?_, ?_⟩, ?_⟩
                · intro t idx hto hts
                  rw [wRead_rWrite]
                  iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl hto)]
                · intro idx h1 h2 h3
                  rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr h3),
                      wRead_wWrite_of_ne _ _ (Or.inr h2), wRead_wWrite_of_ne _ _ (Or.inr h1)]
                · intro t idx hto hts
                  rw [rRead_rWrite_of_ne _ _ (Or.inl hto)]
                  iterate 3 rw [rRead_wWrite]
                · intro idx h1
                  rw [rRead_rWrite_of_ne _ _ (Or.inr h1)]
                  iterate 3 rw [rRead_wWrite]
                · unfold ScanBestInv
                  rw [if_pos rfl]
                  refine ⟨?_, ?_, ?_, rRead_rWrite_self _ _ _ _⟩
                  · rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr h_out_distinct.2.1),
                        wRead_wWrite_of_ne _ _ (Or.inr h_out_distinct.1), wRead_wWrite_self]
                  · rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr h_out_distinct.2.2), wRead_wWrite_self]
                  · rw [wRead_rWrite, wRead_wWrite_self]).mono (fun _ hm _ => hm) (by omega)

  refine ExecDet.seq' (4 + (1 + maxCap * ((80 + maxCap * (180 + 75 * d)) + 6)))
    hinit (exactScan_cost_outer maxCap d) ?_
  intro mInit ⟨hPres0, hBest0⟩ hfpInit
  -- Visited pair sets `VisOuter i` = `{(a, b) | a < i ∧ a < b ∧ b < L_h.length}`
  let VisOuter : ℕ → Finset (ℕ × ℕ) := fun i =>
    ((Finset.range i) ×ˢ (Finset.range L_h.length)).filter (fun p => p.1 < p.2)
  let OuterInv : ℕ → ArithRAMMemory → Prop := fun i m =>
    Preserve m ∧ ScanBestInv pts L_h outWTbl outHas outH1 outH2 outRTbl outSq (VisOuter i) m
  have hVis0 : VisOuter 0 = ∅ := by ext p; simp [VisOuter]
  refine (ExecDet.forLoop scrWTbl 0 maxCap _ OuterInv (80 + maxCap * (180 + 75 * d))
    hfpInit h_scrWT le_rfl (by omega) ?_ ?_).mono ?_ le_rfl
  · refine ⟨⟨?_, ?_, fun t idx hto hts => by rw [rRead_wWrite]; exact hPres0.2.2.1 t idx hto hts,
      fun idx h1 => by rw [rRead_wWrite]; exact hPres0.2.2.2 idx h1⟩, ?_⟩
    · intro t idx hto hts
      rw [wRead_wWrite_of_ne _ _ (Or.inl hts)]
      exact hPres0.1 t idx hto hts
    · intro idx h1 h2 h3
      rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]
      exact hPres0.2.1 idx h1 h2 h3
    · rw [hVis0]
      unfold ScanBestInv at hBest0 ⊢
      rw [if_pos rfl] at hBest0 ⊢
      iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]
      rw [rRead_wWrite]
      exact hBest0
  · intro i hi mOut ⟨hPres_i, hBest_i⟩ hctr_i hfp_i
    let VisInner : ℕ → Finset (ℕ × ℕ) := fun j =>
      VisOuter i ∪ ((({i} : Finset ℕ) ×ˢ (Finset.range (min j L_h.length))).filter (fun p => p.1 < p.2))
    let InnerInv : ℕ → ArithRAMMemory → Prop := fun j m =>
      Preserve m ∧ wRead m scrWTbl 0 = (i : ℤ) ∧
      ScanBestInv pts L_h outWTbl outHas outH1 outH2 outRTbl outSq (VisInner j) m
    have hVisIn0 : VisInner 0 = VisOuter i := by ext p; simp [VisInner]
    have hVisInMax : VisInner maxCap = VisOuter (i + 1) := by
      ext ⟨a, b⟩
      simp only [VisInner, VisOuter, Finset.mem_union, Finset.mem_filter, Finset.mem_product,
        Finset.mem_range, Finset.mem_singleton, Nat.min_eq_right h_cap]
      omega
    refine (ExecDet.forLoop scrWTbl 1 maxCap _ InnerInv (165 + 75 * d)
      hfp_i h_scrWT (by omega) (by omega) ?_ ?_).mono ?_ (exactScan_cost_inner maxCap d)
    · refine ⟨⟨?_, ?_, fun t idx hto hts => by rw [rRead_wWrite]; exact hPres_i.2.2.1 t idx hto hts,
        fun idx h1 => by rw [rRead_wWrite]; exact hPres_i.2.2.2 idx h1⟩,
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctr_i, ?_⟩
      · intro t idx hto hts; rw [wRead_wWrite_of_ne _ _ (Or.inl hts)]; exact hPres_i.1 t idx hto hts
      · intro idx h1 h2 h3; rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]; exact hPres_i.2.1 idx h1 h2 h3
      · rw [hVisIn0]
        unfold ScanBestInv at hBest_i ⊢
        split_ifs at hBest_i ⊢
        · iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]
          rw [rRead_wWrite]; exact hBest_i
        · refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]; exact hBest_i.1, ?_⟩
          obtain ⟨a, b, hb, hab, hmem, h1, h2, hsq, hall⟩ := hBest_i.2
          refine ⟨a, b, hb, hab, hmem, ?_, ?_, ?_, ?_⟩
          · rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]; exact h1
          · rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]; exact h2
          · rw [rRead_wWrite]; exact hsq
          · intro p hp hpb hpab; rw [rRead_wWrite]; exact hall p hp hpb hpab
    · -- Inner loop body at `(i, j)`
      intro j hj mIn ⟨hPres_ij, hctr_i', hBest_ij⟩ hctr_j hfp_ij
      have hsz_val := hsz_from_pres mIn hPres_ij
      refine (ExecDet.ite _ _ _ (C_c := 15) (C_b := 150 + 75 * d)
        (by simp [condExprOps, intExprOps]) ?_ ?_).mono (fun _ hm _ => hm) (by omega)
      · intro hcond_ij
        have hij_valid : i < j ∧ j < L_h.length := by
          simp [evalArithCond, evalIntExpr, wRead] at hctr_i' hctr_j hsz_val hcond_ij
          omega
        have hi_len : i < L_h.length := Nat.lt_trans hij_valid.1 hij_valid.2
        let hA := L_h[i]'hi_len
        let hB := L_h[j]'hij_valid.2
        have hhA_mem : hA ∈ L_h := List.getElem_mem _
        have hhB_mem : hB ∈ L_h := List.getElem_mem _
        have hVis_next : VisInner (j + 1) = insert (i, j) (VisInner j) := by
          ext ⟨a, b⟩
          simp only [VisInner, Finset.mem_insert, Finset.mem_union, Finset.mem_filter,
            Finset.mem_product, Finset.mem_singleton, Finset.mem_range]
          have hm1 : min j L_h.length = j := Nat.min_eq_left hij_valid.2.le
          have hm2 : min (j + 1) L_h.length = j + 1 := Nat.min_eq_left hij_valid.2
          rw [hm1, hm2]
          constructor
          · rintro (hO | ⟨⟨rfl, hb⟩, hab⟩)
            · exact Or.inr (Or.inl hO)
            · rcases Nat.lt_succ_iff_lt_or_eq.mp hb with hlt | rfl
              · exact Or.inr (Or.inr ⟨⟨rfl, hlt⟩, hab⟩)
              · exact Or.inl rfl
          · rintro (⟨rfl, rfl⟩ | hO | ⟨⟨rfl, hb⟩, hab⟩)
            · exact Or.inr ⟨⟨rfl, Nat.lt_succ_self j⟩, hij_valid.1⟩
            · exact Or.inl hO
            · exact Or.inr ⟨⟨rfl, Nat.lt_succ_of_lt hb⟩, hab⟩
        -- Load hA, hB and zero accSq
        refine (ExecDet.seq
          (ExecDet.wWriteEq inp scrWTbl (.lit 2) (.readHeap arrTbl (.readHeap scrWTbl (.lit 0))) 2 (hA : ℤ)
            hfp_ij h_scrWT (by omega) (by omega) rfl
            (by change wRead mIn arrTbl (wRead mIn scrWTbl 0) = _
                rw [hctr_i', harr_from_pres mIn hPres_ij i hi_len])
            (by simp [intExprOps]))
          fun mA hmA hfpA => by
            subst hmA
            refine ExecDet.seq
              (ExecDet.wWriteEq inp scrWTbl (.lit 3) (.readHeap arrTbl (.readHeap scrWTbl (.lit 1))) 3 (hB : ℤ)
                hfpA h_scrWT (by omega) (by omega) rfl
                (by change wRead _ arrTbl (wRead _ scrWTbl 1) = _
                    rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_arr.symm),
                        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hctr_j,
                        harr_from_pres mIn hPres_ij j hij_valid.2])
                (by simp [intExprOps]))
              fun mB hmB hfpB => by
                subst hmB
                refine ExecDet.seq
                  (ExecDet.rWriteEq inp scrRTbl (.lit 0) (.ofInt (.lit 0)) 0 0
                    hfpB h_scrRT le_rfl (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
                    (by simp [intExprOps, realExprOps]))
                  fun mC hmC hfpC => by
                    subst hmC
                    -- Coordinate loop accumulating `∑_{c < k} (pts hA c - pts hB c)^2`
                    let DistInv : ℕ → ArithRAMMemory → Prop := fun k m =>
                      Preserve m ∧
                      wRead m scrWTbl 0 = (i : ℤ) ∧
                      wRead m scrWTbl 1 = (j : ℤ) ∧
                      wRead m scrWTbl 2 = (hA : ℤ) ∧
                      wRead m scrWTbl 3 = (hB : ℤ) ∧
                      ScanBestInv pts L_h outWTbl outHas outH1 outH2 outRTbl outSq (VisInner j) m ∧
                      rRead m scrRTbl 0 = ∑ c ∈ Finset.univ.filter (fun x : Fin d => x.val < k),
                        (euclideanCoord (pts hA) c - euclideanCoord (pts hB) c) ^ 2
                    refine ExecDet.seq
                      (ExecDet.forLoop scrWTbl 4 d _ DistInv 65 hfpC h_scrWT (by omega) (by omega) ?_ ?_) ?_
                    · refine ⟨⟨?_, ?_, ?_, ?_⟩, ?_, ?_, ?_, ?_, ?_, ?_⟩
                      · intro t idx hto hts
                        rw [wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_rWrite]
                        iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl hts)]
                        exact hPres_ij.1 t idx hto hts
                      · intro idx h1 h2 h3
                        rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm), wRead_rWrite]
                        iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]
                        exact hPres_ij.2.1 idx h1 h2 h3
                      · intro t idx hto hts
                        rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hts), rRead_wWrite, rRead_wWrite]
                        exact hPres_ij.2.2.1 t idx hto hts
                      · intro idx h1
                        rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl h_ne_scrR_outR.symm), rRead_wWrite, rRead_wWrite]
                        exact hPres_ij.2.2.2 idx h1
                      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite,
                            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hctr_i']
                      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite,
                            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hctr_j]
                      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite,
                            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
                      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_self]
                      · unfold ScanBestInv at hBest_ij ⊢
                        have hw_unch : ∀ idx, wRead (H3a.wWrite (H3a.rWrite (H3a.wWrite (H3a.wWrite mIn scrWTbl 2 (hA : ℤ)) scrWTbl 3 (hB : ℤ)) scrRTbl 0 0) scrWTbl 4 0) outWTbl idx = wRead mIn outWTbl idx := by
                          intro idx
                          rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm), wRead_rWrite,
                              wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm),
                              wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]
                        have hr_unch : rRead (H3a.wWrite (H3a.rWrite (H3a.wWrite (H3a.wWrite mIn scrWTbl 2 (hA : ℤ)) scrWTbl 3 (hB : ℤ)) scrRTbl 0 0) scrWTbl 4 0) outRTbl outSq = rRead mIn outRTbl outSq := by
                          rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl h_ne_scrR_outR.symm), rRead_wWrite, rRead_wWrite]
                        split_ifs at hBest_ij ⊢
                        · rw [hw_unch, hw_unch, hw_unch, hr_unch]; exact hBest_ij
                        · obtain ⟨hh1, a, b, hb, hab, hm, e1, e2, esq, eall⟩ := hBest_ij
                          refine ⟨by rw [hw_unch]; exact hh1, a, b, hb, hab, hm, by rw [hw_unch]; exact e1,
                            by rw [hw_unch]; exact e2, by rw [hr_unch]; exact esq,
                            fun p hp hpb hpab => by rw [hr_unch]; exact eall p hp hpb hpab⟩
                      · rw [rRead_wWrite, rRead_rWrite_self]
                        have hempty : Finset.univ.filter (fun x : Fin d => x.val < 0) = ∅ := by ext x; simp
                        rw [hempty, Finset.sum_empty]
                    · intro k hk mD ⟨hPD, hiD, hjD, hAD, hBD, hBestD, haccD⟩ hctr_k hfpD
                      let diff_k := euclideanCoord (pts hA) ⟨k, hk⟩ - euclideanCoord (pts hB) ⟨k, hk⟩
                      refine (ExecDet.seq
                        (ExecDet.rWriteEq inp scrRTbl (.lit 1)
                          (.sub
                            (.readRealHeap 1 (.add (.mul (.readHeap scrWTbl (.lit 2)) (.lit (d : ℤ)))
                                                   (.readHeap scrWTbl (.lit 4))))
                            (.readRealHeap 1 (.add (.mul (.readHeap scrWTbl (.lit 3)) (.lit (d : ℤ)))
                                                   (.readHeap scrWTbl (.lit 4)))))
                          1 diff_k hfpD h_scrRT (by omega) (by omega) rfl
                          (by
                            change rRead mD 1 (wRead mD scrWTbl 2 * (d : ℤ) + wRead mD scrWTbl 4) -
                              rRead mD 1 (wRead mD scrWTbl 3 * (d : ℤ) + wRead mD scrWTbl 4) = diff_k
                            rw [hAD, hBD, hctr_k]
                            have i1 : (hA : ℤ) * (d : ℤ) + (k : ℤ) = ((hA * d + k : ℕ) : ℤ) := by push_cast; ring
                            have i2 : (hB : ℤ) * (d : ℤ) + (k : ℤ) = ((hB * d + k : ℕ) : ℤ) := by push_cast; ring
                            rw [i1, i2, hpts_from_pres mD hPD hA hhA_mem ⟨k, hk⟩,
                                hpts_from_pres mD hPD hB hhB_mem ⟨k, hk⟩])
                          (by simp [intExprOps, realExprOps]))
                        fun mE hmE hfpE => by
                          subst hmE
                          let nextSum := ∑ c ∈ Finset.univ.filter (fun x : Fin d => x.val < k + 1),
                            (euclideanCoord (pts hA) c - euclideanCoord (pts hB) c) ^ 2
                          have hsum_step : rRead mD scrRTbl 0 + diff_k * diff_k = nextSum := by
                            rw [haccD]
                            have hsplit : Finset.univ.filter (fun x : Fin d => x.val < k + 1) =
                                insert (⟨k, hk⟩ : Fin d) (Finset.univ.filter (fun x : Fin d => x.val < k)) := by
                              ext x; simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert]
                              constructor
                              · intro h; rcases Nat.lt_succ_iff_lt_or_eq.mp h with hlt | heq
                                · exact Or.inr hlt
                                · exact Or.inl (Fin.ext heq)
                              · rintro (rfl | hlt)
                                · simp
                                · omega
                            dsimp only [nextSum]
                            rw [hsplit, Finset.sum_insert (by simp)]
                            dsimp only [diff_k]; ring
                          refine ExecDet.rWrite (C := 30) inp scrRTbl (.lit 0)
                            (.add (.readRealHeap scrRTbl (.lit 0))
                                  (.mul (.readRealHeap scrRTbl (.lit 1)) (.readRealHeap scrRTbl (.lit 1))))
                            0 nextSum hfpE h_scrRT le_rfl (by omega) rfl
                            (by
                              change rRead _ scrRTbl 0 + rRead _ scrRTbl 1 * rRead _ scrRTbl 1 = nextSum
                              rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega)), rRead_rWrite_self, hsum_step])
                            (by simp [intExprOps, realExprOps]) ?_
                          refine ⟨by rw [wRead_rWrite, wRead_rWrite]; exact hctr_k,
                            ⟨?_, ?_, ?_, ?_⟩, ?_, ?_, ?_, ?_, ?_, ?_⟩
                          · intro t idx hto hts
                            rw [wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_rWrite, wRead_rWrite]
                            exact hPD.1 t idx hto hts
                          · intro idx h1 h2 h3
                            rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm), wRead_rWrite, wRead_rWrite]
                            exact hPD.2.1 idx h1 h2 h3
                          · intro t idx hto hts
                            rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hts), rRead_rWrite_of_ne _ _ (Or.inl hts)]
                            exact hPD.2.2.1 t idx hto hts
                          · intro idx h1
                            rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl h_ne_scrR_outR.symm),
                                rRead_rWrite_of_ne _ _ (Or.inl h_ne_scrR_outR.symm)]
                            exact hPD.2.2.2 idx h1
                          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hiD]
                          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hjD]
                          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hAD]
                          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hBD]
                          · unfold ScanBestInv at hBestD ⊢
                            have hwu : ∀ idx, wRead (H3a.wWrite (H3a.rWrite (H3a.rWrite mD scrRTbl 1 diff_k) scrRTbl 0 nextSum) scrWTbl 4 ((k : ℤ) + 1)) outWTbl idx = wRead mD outWTbl idx := by
                              intro idx; rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm), wRead_rWrite, wRead_rWrite]
                            have hru : rRead (H3a.wWrite (H3a.rWrite (H3a.rWrite mD scrRTbl 1 diff_k) scrRTbl 0 nextSum) scrWTbl 4 ((k : ℤ) + 1)) outRTbl outSq = rRead mD outRTbl outSq := by
                              rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl h_ne_scrR_outR.symm),
                                  rRead_rWrite_of_ne _ _ (Or.inl h_ne_scrR_outR.symm)]
                            split_ifs at hBestD ⊢
                            · rw [hwu, hwu, hwu, hru]; exact hBestD
                            · obtain ⟨hh1, a, b, hb, hab, hm, e1, e2, esq, eall⟩ := hBestD
                              exact ⟨by rw [hwu]; exact hh1, a, b, hb, hab, hm, by rw [hwu]; exact e1,
                                by rw [hwu]; exact e2, by rw [hru]; exact esq,
                                fun p hp hpb hpab => by rw [hru]; exact eall p hp hpb hpab⟩
                          · rw [rRead_wWrite, rRead_rWrite_self]).mono (fun _ hm _ => hm) (by omega)
                    · intro mSum ⟨hPSum, hiSum, hjSum, hASum, hBSum, hBestSum, haccSum⟩ hfpSum
                      have hacc_norm : rRead mSum scrRTbl 0 = ‖pts hA - pts hB‖ ^ 2 := by
                        rw [haccSum, norm_sub_sq_eq_sum_coord]
                        congr 1; ext c; simp
                      -- Update max if `outHas == 0 ∨ outSq < accSq`
                      refine ExecDet.ite _ _ _ (C_c := 15) (C_b := 60)
                        (by simp [condExprOps, intExprOps, realExprOps]) ?_ ?_
                      · intro hupd_true
                        have hle_prev : ∀ p ∈ VisInner j, ∀ (hpb : p.2 < L_h.length) (hpab : p.1 < p.2),
                            ‖pts (L_h[p.1]'(Nat.lt_trans hpab hpb)) - pts (L_h[p.2]'hpb)‖ ^ 2 ≤ ‖pts hA - pts hB‖ ^ 2 := by
                          intro p hp hpb hpab
                          by_cases hemp : VisInner j = ∅
                          · rw [hemp] at hp; exact absurd hp (Finset.notMem_empty _)
                          · unfold ScanBestInv at hBestSum
                            rw [if_neg hemp] at hBestSum
                            have hprev := hBestSum.2.choose_spec.choose_spec.choose_spec.2.2.2.2.2 p hp hpb hpab
                            have hhas1 := hBestSum.1
                            simp [evalArithCond, evalIntExpr, evalRealExpr, wRead, rRead] at hhas1 hacc_norm hupd_true
                            rcases hupd_true with h0 | hlt_r
                            · omega
                            · rw [hacc_norm] at hlt_r
                              exact le_trans hprev (le_of_lt hlt_r)
                        refine (ExecDet.seq
                          (ExecDet.wWriteEq inp outWTbl (.lit outHas) (.lit 1) outHas 1
                            hfpSum h_outWT h_outW_bounds.1 h_outW_bounds.2.1 rfl rfl (by simp [intExprOps]))
                          fun mU1 hmU1 hfpU1 => by
                            subst hmU1
                            refine ExecDet.seq
                              (ExecDet.wWriteEq inp outWTbl (.lit outH1) (.readHeap scrWTbl (.lit 2)) outH1 (hA : ℤ)
                                hfpU1 h_outWT h_outW_bounds.2.2.1 h_outW_bounds.2.2.2.1 rfl
                                (by change wRead _ scrWTbl 2 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out), hASum])
                                (by simp [intExprOps]))
                              fun mU2 hmU2 hfpU2 => by
                                subst hmU2
                                refine ExecDet.seq
                                  (ExecDet.wWriteEq inp outWTbl (.lit outH2) (.readHeap scrWTbl (.lit 3)) outH2 (hB : ℤ)
                                    hfpU2 h_outWT h_outW_bounds.2.2.2.2.1 h_outW_bounds.2.2.2.2.2 rfl
                                    (by change wRead _ scrWTbl 3 = _
                                        rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out),
                                            wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out), hBSum])
                                    (by simp [intExprOps]))
                                  fun mU3 hmU3 hfpU3 => by
                                    subst hmU3
                                    refine ExecDet.rWrite (C := 12) inp outRTbl (.lit outSq) (.readRealHeap scrRTbl (.lit 0))
                                      outSq (‖pts hA - pts hB‖ ^ 2) hfpU3 h_outRT h_outR_bounds.1 h_outR_bounds.2 rfl
                                      (by change rRead _ scrRTbl 0 = _; rw [rRead_wWrite, rRead_wWrite, rRead_wWrite, hacc_norm])
                                      (by simp [intExprOps, realExprOps]) ?_
                                    refine ⟨by rw [wRead_rWrite]; (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out)]); exact hjSum,
                                      ⟨?_, ?_, ?_, ?_⟩, ?_, ?_⟩
                                    · intro t idx hto hts
                                      rw [wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_rWrite]
                                      iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl hto)]
                                      exact hPSum.1 t idx hto hts
                                    · intro idx h1 h2 h3
                                      rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm), wRead_rWrite,
                                          wRead_wWrite_of_ne _ _ (Or.inr h3), wRead_wWrite_of_ne _ _ (Or.inr h2),
                                          wRead_wWrite_of_ne _ _ (Or.inr h1)]
                                      exact hPSum.2.1 idx h1 h2 h3
                                    · intro t idx hto hts
                                      rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hto)]
                                      iterate 3 rw [rRead_wWrite]
                                      exact hPSum.2.2.1 t idx hto hts
                                    · intro idx h1
                                      rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr h1)]
                                      iterate 3 rw [rRead_wWrite]
                                      exact hPSum.2.2.2 idx h1
                                    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite]
                                      iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out)]
                                      exact hiSum
                                    · rw [hVis_next]
                                      unfold ScanBestInv
                                      rw [if_neg (Finset.insert_ne_empty _ _)]
                                      refine ⟨?_, i, j, hij_valid.2, hij_valid.1, Finset.mem_insert_self _ _, ?_, ?_, ?_, ?_⟩
                                      · rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm), wRead_rWrite,
                                            wRead_wWrite_of_ne _ _ (Or.inr h_out_distinct.2.1),
                                            wRead_wWrite_of_ne _ _ (Or.inr h_out_distinct.1), wRead_wWrite_self]
                                      · rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm), wRead_rWrite,
                                            wRead_wWrite_of_ne _ _ (Or.inr h_out_distinct.2.2), wRead_wWrite_self]
                                      · rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm), wRead_rWrite, wRead_wWrite_self]
                                      · rw [rRead_wWrite, rRead_rWrite_self]
                                      · intro p hp hpb hpab
                                        rw [rRead_wWrite, rRead_rWrite_self]
                                        rcases Finset.mem_insert.mp hp with rfl | hold
                                        · exact le_rfl
                                        · exact hle_prev p hold hpb hpab).mono (fun _ hm _ => hm) (by omega)
                      · intro hupd_false
                        have hnot_empty : VisInner j ≠ ∅ := by
                          intro hemp
                          unfold ScanBestInv at hBestSum
                          rw [if_pos hemp] at hBestSum
                          have h0 := hBestSum.1
                          simp [evalArithCond, evalIntExpr, evalRealExpr, wRead, rRead] at h0 hupd_false
                          omega
                        unfold ScanBestInv at hBestSum
                        rw [if_neg hnot_empty] at hBestSum
                        obtain ⟨hhas1, a, b, hb, hab, hm, e1, e2, esq, eall⟩ := hBestSum
                        have hge_cur : ‖pts hA - pts hB‖ ^ 2 ≤ rRead mSum outRTbl outSq := by
                          simp [evalArithCond, evalIntExpr, evalRealExpr, wRead, rRead] at hhas1 hacc_norm hupd_false ⊢
                          rw [← hacc_norm]
                          exact hupd_false.2
                        refine ExecDet.skip inp hfpSum ?_ (by omega)
                        refine ⟨hjSum, ⟨?_, ?_, ?_, ?_⟩, ?_, ?_⟩
                        · intro t idx hto hts; rw [wRead_wWrite_of_ne _ _ (Or.inl hts)]; exact hPSum.1 t idx hto hts
                        · intro idx h1 h2 h3; rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]; exact hPSum.2.1 idx h1 h2 h3
                        · intro t idx hto hts; rw [rRead_wWrite]; exact hPSum.2.2.1 t idx hto hts
                        · intro idx h1; rw [rRead_wWrite]; exact hPSum.2.2.2 idx h1
                        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hiSum
                        · rw [hVis_next]
                          unfold ScanBestInv
                          rw [if_neg (Finset.insert_ne_empty _ _)]
                          have hwu : ∀ idx, wRead (H3a.wWrite mSum scrWTbl 1 ((j : ℤ) + 1)) outWTbl idx = wRead mSum outWTbl idx :=
                            fun idx => wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)
                          refine ⟨by rw [hwu]; exact hhas1, a, b, hb, hab, Finset.mem_insert_of_mem hm,
                            by rw [hwu]; exact e1, by rw [hwu]; exact e2, by rw [rRead_wWrite]; exact esq, ?_⟩
                          intro p hp hpb hpab
                          rw [rRead_wWrite]
                          rcases Finset.mem_insert.mp hp with rfl | hold
                          · exact hge_cur
                          · exact eall p hold hpb hpab).mono
          (fun _ hm _ => hm) (exactScan_cost_body d)
      · intro hcond_false
        have hnot_valid : ¬ (i < j ∧ j < L_h.length) := by
          simp [evalArithCond, evalIntExpr, wRead] at hctr_i' hctr_j hsz_val hcond_false
          omega
        have hVis_same : VisInner (j + 1) = VisInner j := by
          ext ⟨a, b⟩
          simp only [VisInner, Finset.mem_union, Finset.mem_filter, Finset.mem_product,
            Finset.mem_singleton, Finset.mem_range]
          constructor
          · rintro (hO | ⟨⟨rfl, hb⟩, hab⟩)
            · exact Or.inl hO
            · have hb1 : b < j + 1 := lt_of_lt_of_le hb (Nat.min_le_left _ _)
              have hb2 : b < L_h.length := lt_of_lt_of_le hb (Nat.min_le_right _ _)
              rcases Nat.lt_succ_iff_lt_or_eq.mp hb1 with hlt | rfl
              · exact Or.inr ⟨⟨rfl, lt_min hlt hb2⟩, hab⟩
              · exact absurd ⟨hab, hb2⟩ hnot_valid
          · rintro (hO | ⟨⟨rfl, hb⟩, hab⟩)
            · exact Or.inl hO
            · exact Or.inr ⟨⟨rfl, lt_of_lt_of_le hb (min_le_min_right _ (Nat.le_succ j))⟩, hab⟩
        refine ExecDet.skip inp hfp_ij ?_ (by omega)
        refine ⟨hctr_j, ⟨?_, ?_, ?_, ?_⟩, ?_, ?_⟩
        · intro t idx hto hts; rw [wRead_wWrite_of_ne _ _ (Or.inl hts)]; exact hPres_ij.1 t idx hto hts
        · intro idx h1 h2 h3; rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]; exact hPres_ij.2.1 idx h1 h2 h3
        · intro t idx hto hts; rw [rRead_wWrite]; exact hPres_ij.2.2.1 t idx hto hts
        · intro idx h1; rw [rRead_wWrite]; exact hPres_ij.2.2.2 idx h1
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctr_i'
        · rw [hVis_same]
          unfold ScanBestInv at hBest_ij ⊢
          have hwu : ∀ idx, wRead (H3a.wWrite mIn scrWTbl 1 ((j : ℤ) + 1)) outWTbl idx = wRead mIn outWTbl idx :=
            fun idx => wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)
          split_ifs at hBest_ij ⊢
          · rw [hwu, hwu, hwu, rRead_wWrite]; exact hBest_ij
          · obtain ⟨hh1, a, b, hb, hab, hm, e1, e2, esq, eall⟩ := hBest_ij
            exact ⟨by rw [hwu]; exact hh1, a, b, hb, hab, hm, by rw [hwu]; exact e1,
              by rw [hwu]; exact e2, by rw [rRead_wWrite]; exact esq,
              fun p hp hpb hpab => by rw [rRead_wWrite]; exact eall p hp hpb hpab⟩
    · intro mEndIn ⟨hPEnd, hiEnd, hBestEnd⟩ _
      rw [hVisInMax] at hBestEnd
      refine ⟨hiEnd, ⟨?_, ?_, ?_, ?_⟩, ?_⟩
      · intro t idx hto hts; rw [wRead_wWrite_of_ne _ _ (Or.inl hts)]; exact hPEnd.1 t idx hto hts
      · intro idx h1 h2 h3; rw [wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)]; exact hPEnd.2.1 idx h1 h2 h3
      · intro t idx hto hts; rw [rRead_wWrite]; exact hPEnd.2.2.1 t idx hto hts
      · intro idx h1; rw [rRead_wWrite]; exact hPEnd.2.2.2 idx h1
      · unfold ScanBestInv at hBestEnd ⊢
        have hwu : ∀ idx, wRead (H3a.wWrite mEndIn scrWTbl 0 ((i : ℤ) + 1)) outWTbl idx = wRead mEndIn outWTbl idx :=
          fun idx => wRead_wWrite_of_ne _ _ (Or.inl h_ne_scrW_out.symm)
        split_ifs at hBestEnd ⊢
        · rw [hwu, hwu, hwu, rRead_wWrite]; exact hBestEnd
        · obtain ⟨hh1, a, b, hb, hab, hm, e1, e2, esq, eall⟩ := hBestEnd
          exact ⟨by rw [hwu]; exact hh1, a, b, hb, hab, hm, by rw [hwu]; exact e1,
            by rw [hwu]; exact e2, by rw [rRead_wWrite]; exact esq,
            fun p hp hpb hpab => by rw [rRead_wWrite]; exact eall p hp hpb hpab⟩
  · -- Final postcondition at `i = maxCap`
    intro mF ⟨hPF, hBestF⟩ _
    have hcard_eq : L_h.toFinset.card = L_h.length := List.toFinset_card_of_nodup h_nd
    by_cases hsz1 : L_h.length ≤ 1
    · have hemp : VisOuter maxCap = ∅ := by
        ext ⟨a, b⟩
        simp only [VisOuter, Finset.mem_filter, Finset.mem_product, Finset.mem_range, Finset.notMem_empty, iff_false]
        omega
      unfold ScanBestInv at hBestF
      rw [if_pos hemp] at hBestF
      obtain ⟨h0, _, _, hsq0⟩ := hBestF
      refine ⟨?_, ?_, hPF.1, hPF.2.1, hPF.2.2.1, hPF.2.2.2⟩
      · unfold IsExactLeafAnswer
        rw [if_pos (by omega)]
        simp [h0]
      · simp [h0, hsq0, baselinePairLength]
    · have hsz2 : 2 ≤ L_h.length := by omega
      have h01_mem : (0, 1) ∈ VisOuter maxCap := by
        simp only [VisOuter, Finset.mem_filter, Finset.mem_product, Finset.mem_range]
        omega
      have hne_emp : VisOuter maxCap ≠ ∅ := Finset.ne_empty_of_mem h01_mem
      unfold ScanBestInv at hBestF
      rw [if_neg hne_emp] at hBestF
      obtain ⟨hhas1, a, b, hb, hab, _, eh1, eh2, esq, eall⟩ := hBestF
      let u := L_h[a]'(Nat.lt_trans hab hb)
      let v := L_h[b]'hb
      have hu_in : u ∈ L_h.toFinset := List.mem_toFinset.mpr (List.getElem_mem _)
      have hv_in : v ∈ L_h.toFinset := List.mem_toFinset.mpr (List.getElem_mem _)
      have huv_ne : u ≠ v := by
        intro heq
        have hinj := List.nodup_iff_injective_getElem.mp h_nd
        have hidx : (⟨a, Nat.lt_trans hab hb⟩ : Fin L_h.length) = ⟨b, hb⟩ := hinj heq
        have : a = b := congrArg Fin.val hidx
        omega
      have hdiam_eq : ‖pts u - pts v‖ = indexedEuclideanDiam L_h.toFinset pts := by
        unfold indexedEuclideanDiam
        have hne_set : L_h.toFinset.Nonempty := ⟨u, hu_in⟩
        rw [dif_pos hne_set]
        apply le_antisymm
        · exact Finset.le_sup' (f := fun xy : ℕ × ℕ => ‖pts xy.1 - pts xy.2‖)
            (show (u, v) ∈ L_h.toFinset ×ˢ L_h.toFinset from Finset.mem_product.mpr ⟨hu_in, hv_in⟩)
        · refine Finset.sup'_le _ _ fun xy hxy => ?_
          rcases Finset.mem_product.mp hxy with ⟨hx_in, hy_in⟩
          obtain ⟨ix, hix, hx_eq⟩ := List.getElem_of_mem (List.mem_toFinset.mp hx_in)
          obtain ⟨iy, hiy, hy_eq⟩ := List.getElem_of_mem (List.mem_toFinset.mp hy_in)
          rw [← hx_eq, ← hy_eq]
          rcases lt_trichotomy ix iy with hlt | rfl | hgt
          · have hp_in : (ix, iy) ∈ VisOuter maxCap := by
              simp only [VisOuter, Finset.mem_filter, Finset.mem_product, Finset.mem_range]
              omega
            have hsq_le := eall (ix, iy) hp_in hiy hlt
            rw [esq] at hsq_le
            exact le_of_sq_le_sq_nonneg (norm_nonneg _) hsq_le
          · simp
          · have hp_in : (iy, ix) ∈ VisOuter maxCap := by
              simp only [VisOuter, Finset.mem_filter, Finset.mem_product, Finset.mem_range]
              omega
            have hsq_le := eall (iy, ix) hp_in hix hgt
            rw [esq, norm_sub_rev] at hsq_le
            exact le_of_sq_le_sq_nonneg (norm_nonneg _) hsq_le
      refine ⟨?_, ?_, hPF.1, hPF.2.1, hPF.2.2.1, hPF.2.2.2⟩
      · change wRead mF outWTbl outH1 = (u : ℤ) at eh1
        change wRead mF outWTbl outH2 = (v : ℤ) at eh2
        unfold IsExactLeafAnswer
        rw [if_neg (by omega)]
        refine ⟨u, v, ?_, hu_in, hv_in, huv_ne, hdiam_eq⟩
        dsimp only
        rw [hhas1, eh1, eh2]; simp
      · change wRead mF outWTbl outH1 = (u : ℤ) at eh1
        change wRead mF outWTbl outH2 = (v : ℤ) at eh2
        change rRead mF outRTbl outSq = ‖pts u - pts v‖ ^ 2 at esq
        rw [hhas1, eh1, eh2, esq]; simp [baselinePairLength]

/-! ### Branch 2 (`1 ≤ d`, exact `O(maxCap^2 * d)` dynamic diameter RAM program) -/

def updateExactStmt (maxCap d : ℕ) : ArithRAMStmt :=
  .seq (applyHandleUpdateStmt d)
    (exactPairwiseScanStmt 2 0 6 0 1 2 3 0 0 4 2 maxCap d)

open Classical in
theorem branchExact_theorem {d : ℕ} {c : ℝ} (hc_gt : 1 < c) {n t maxCap : ℕ} {δ : ℝ}
    (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (hCap : min n t ≤ maxCap)
    {stepWorkBound spaceBound : ℝ}
    (hWork : ((400 + 25 * d + maxCap * (100 + maxCap * (200 + 80 * d)) : ℕ) : ℝ) ≤ stepWorkBound)
    (hSpace : ((8 * (n + 8) + 4 * (n * d + 8) + (d + 4) : ℕ) : ℝ) ≤ spaceBound) :
    let prog : ArithRAMDynamicProgram := { initStmt := .skip, updateStmt := updateExactStmt maxCap d }
    ∃ initOut : ArithRAMExecOutcome,
      prog.evalInit n d = some initOut ∧
      let alg := mkArithAlg (d := d) n prog initOut
      SatisfiesDynamicStorageAndQueryModel 4 1 alg ∧
      SatisfiesMonteCarloGuarantee n t δ c Set.univ alg ∧
      SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg stepWorkBound ∧
      SatisfiesBoundedSpaceBound n t Set.univ alg spaceBound := by
  intro prog
  let initOut : ArithRAMExecOutcome := { mem := ArithRAMMemory.empty, unitCost := 1, peakCellSpace := 1 }
  let alg := mkArithAlg (d := d) n prog initOut
  refine ⟨initOut, evalInit_skip n d _, storageModel_of_empty_init n prog initOut rfl, ?_⟩
  let TW := 6; let BW := n + 8; let TR := 3; let BR := n * d + 8
  let ReachInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop := fun s P mem =>
    P.activeHandles.card ≤ s ∧
    InFootprint TW BW TR BR mem ∧
    ∃ hp : HandlePool d n, hp.WellFormed P ∧ EncHandlePool hp mem
  have hzr : ZeroRandStmt (updateExactStmt maxCap d) := by
    unfold updateExactStmt applyHandleUpdateStmt forLoopStmt
    exact ZeroRandStmt.seq (by repeat' constructor) (zeroRand_exactPairwiseScanStmt _ _ _ _ _ _ _ _ _ _ _ _ _)
  have hW1 : (1 : ℝ) ≤ stepWorkBound := by
    refine le_trans (by exact_mod_cast (by omega : 1 ≤ 400 + 25 * d + maxCap * (100 + maxCap * (200 + 80 * d)))) hWork
  have hS1 : (1 : ℝ) ≤ spaceBound := by
    refine le_trans (by exact_mod_cast (by omega : 1 ≤ 8 * (n + 8) + 4 * (n * d + 8) + (d + 4))) hSpace
  have hRunStep : ∀ (s : ℕ) (P : DynamicPointSet d) (mem : ArithRAMMemory) (op : DynamicUpdate d),
      s < t → P.WellFormed n → ReachInv s P mem → IsLegalUpdate n Set.univ P op →
      ∃ (P' : DynamicPointSet d) (out : DynamicStepOutcome ArithRAMMemory),
        runSingleAdaptiveStep alg P mem op [] = some (P', out) ∧
        ReachInv (s + 1) P' out.nextState ∧
        (out.work : ℝ) ≤ stepWorkBound ∧
        (out.peakSpace : ℝ) ≤ spaceBound ∧
        IsValidFactorCAnswer c P' out.storedAnswer := by
    intro s P mem op hs hP ⟨hcard_s, hfp, hp, hhp, henc⟩ hleg
    have hwf_raw := HandlePool.step_wellFormed hP hhp hleg
    have hexec1 := exec_applyHandleUpdateStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
      (by omega) le_rfl (by omega) le_rfl hP hhp hleg hfp henc
    dsimp only at hwf_raw hexec1
    rcases hstep_eq : hp.step (toInternalUpdate P op) with ⟨hp', rh⟩
    rw [hstep_eq] at hwf_raw hexec1
    dsimp only at hwf_raw hexec1
    obtain ⟨P', happ, hhp'⟩ := hwf_raw
    have hP'_wf : P'.WellFormed n := applyDynamicUpdate_wellFormed hP hleg happ
    have hcard_P'_n : P'.activeHandles.card ≤ n := by
      have hbij : P'.activeHandles.card = P'.activeIds.card := by
        refine Finset.card_bij (fun h _ => P'.idOfHandle h)
          (fun h hh => (hP'_wf.2.2.1 h hh).1)
          (fun h₁ hh₁ h₂ hh₂ heq => by
            dsimp only at heq; rw [← (hP'_wf.2.2.1 h₁ hh₁).2, ← (hP'_wf.2.2.1 h₂ hh₂).2, heq])
          (fun pid hpid => ⟨P'.handleOfId pid, (hP'_wf.2.1 pid hpid).1, (hP'_wf.2.1 pid hpid).2⟩)
      rw [hbij]; exact hP'_wf.1
    have hcard_P'_s : P'.activeHandles.card ≤ s + 1 := by
      cases op with
      | insert pid extName pt =>
        have hrh_some : ∃ h, rh = some h := by
          have : (hp.step (.insert pt)).2 = rh := congrArg Prod.snd hstep_eq
          rw [← this]; dsimp [HandlePool.step]; cases hp.freeList <;> exact ⟨_, rfl⟩
        obtain ⟨h_ins, hrh_eq⟩ := hrh_some
        rw [hrh_eq] at happ
        unfold applyDynamicUpdate at happ; dsimp only at happ
        split_ifs at happ with hc
        injection happ with hP'_eq; rw [← hP'_eq]
        dsimp only; rw [Finset.card_insert_of_notMem hc.2]; omega
      | delete pid =>
        have hrh_eq : rh = none := (congrArg Prod.snd hstep_eq).symm.trans rfl
        rw [hrh_eq] at happ
        unfold applyDynamicUpdate at happ; dsimp only at happ
        split_ifs at happ with hc
        injection happ with hP'_eq; rw [← hP'_eq]
        dsimp only; exact Finset.card_erase_le.trans (by omega)
    have hcard_P'_cap : P'.activeHandles.card ≤ maxCap := by
      have : P'.activeHandles.card ≤ min n t := le_min hcard_P'_n (by omega)
      exact this.trans hCap
    have hlen_cap : hp'.actList.length ≤ maxCap := by
      have : hp'.actList.length = P'.activeHandles.card := by
        rw [← hhp'.2.2.2.1, List.toFinset_card_of_nodup hhp'.2.1]
      omega
    let PostFull : ArithRAMMemory → Prop := fun mF =>
      EncHandlePool hp' mF ∧
      (∀ h, rh = some h → ArithRAMDynamicProgram.readReturnedHandle mF = some h) ∧
      IsValidFactorCAnswer c P'
        (let a := ArithRAMDynamicProgram.readCachedAnswer mF; { diameterHandles := a.1, cachedDistSq := a.2 })
    have hexec_full := ExecDet.seq (s₂ := exactPairwiseScanStmt 2 0 6 0 1 2 3 0 0 4 2 maxCap d)
        (Post := PostFull) hexec1 (by
      intro m1 ⟨henc1, hret1, _, _⟩ hfp1
      refine (exec_exactPairwiseScan (TW := TW) (BW := BW) (TR := TR) (BR := BR)
        2 0 6 0 1 2 3 0 0 4 2 maxCap n hp'.coords hp'.actList hfp1
        (by omega) (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
        (by omega) (by omega) (by omega) (by omega)
        (Or.inr ⟨by omega, by omega, by omega⟩) ⟨by omega, by omega, by omega⟩
        ⟨by omega, by omega, by omega, by omega, by omega, by omega⟩
        ⟨le_rfl, by omega⟩ (by omega) (by omega) (by omega) (by omega) (by omega)
        hhp'.2.1 hlen_cap (fun h hh => (hhp'.2.2.2.2.1 h hh).trans_le hhp'.1)
        henc1.2.2.1 (fun i hi => (henc1.2.2.2.2.1 i hi).1)
        (fun h hh c => henc1.2.2.2.2.2 h (hhp'.2.2.2.2.1 h hh) c)).mono ?_ le_rfl
      intro mF ⟨hleaf, hsq_eq, hpresW, hpresW0, hpresR, _⟩ _
      refine ⟨⟨?_, ?_, ?_, ?_, ?_, ?_⟩, ?_, ?_⟩
      · rw [hpresW0 4 (by omega) (by omega) (by omega)]; exact henc1.1
      · rw [hpresW0 5 (by omega) (by omega) (by omega)]; exact henc1.2.1
      · rw [hpresW0 6 (by omega) (by omega) (by omega)]; exact henc1.2.2.1
      · intro i hi; rw [hpresW 1 (i : ℤ) (by omega) (by omega)]; exact henc1.2.2.2.1 i hi
      · intro i hi
        refine ⟨?_, ?_⟩
        · rw [hpresW 2 (i : ℤ) (by omega) (by omega)]; exact (henc1.2.2.2.2.1 i hi).1
        · rw [hpresW 3 _ (by omega) (by omega)]; exact (henc1.2.2.2.2.1 i hi).2
      · intro h hh c
        rw [hpresR 1 _ (by omega) (by omega)]
        exact henc1.2.2.2.2.2 h hh c
      · intro h hr
        have := hret1 h hr
        unfold ArithRAMDynamicProgram.readReturnedHandle at this ⊢
        change (let hv := wRead _ 0 0; if 0 ≤ hv then some hv.toNat else none) = _
        rw [hpresW0 0 (by omega) (by omega) (by omega)]
        exact this
      · rw [hhp'.2.2.2.1] at hleaf
        apply validFactorCAnswer_of_handles hP'_wf
        · intro hle1
          unfold IsExactLeafAnswer at hleaf
          rw [if_pos hle1] at hleaf
          unfold ArithRAMDynamicProgram.readCachedAnswer
          change (if wRead mF 0 1 = 1 ∧ 0 ≤ wRead mF 0 2 ∧ 0 ≤ wRead mF 0 3 then _ else none) = none ∧
            rRead mF 0 0 = 0
          refine ⟨hleaf, ?_⟩
          rw [hsq_eq, hleaf, baselinePairLength, sq, zero_mul]
        · intro hge2
          unfold IsExactLeafAnswer at hleaf
          rw [if_neg (by omega)] at hleaf
          obtain ⟨u, v, huv_ans, hu_in, hv_in, huv_ne, huv_diam⟩ := hleaf
          have hcu := hhp'.2.2.2.2.2.2.2 u hu_in
          have hcv := hhp'.2.2.2.2.2.2.2 v hv_in
          have hdiam_congr : indexedEuclideanDiam P'.activeHandles hp'.coords =
              indexedEuclideanDiam P'.activeHandles P'.handleCoords := by
            unfold indexedEuclideanDiam
            split_ifs with hne_s
            · refine Finset.sup'_congr (hne_s.product hne_s) rfl fun xy hxy => ?_
              rcases Finset.mem_product.mp hxy with ⟨hx, hy⟩
              rw [hhp'.2.2.2.2.2.2.2 xy.1 hx, hhp'.2.2.2.2.2.2.2 xy.2 hy]
            · rfl
          rw [hcu, hcv, hdiam_congr] at huv_diam
          have hc_pos : 0 < c := zero_lt_one.trans hc_gt
          have hdiv_le : indexedEuclideanDiam P'.activeHandles P'.handleCoords / c ≤
              indexedEuclideanDiam P'.activeHandles P'.handleCoords :=
            div_le_self (by rw [← huv_diam]; exact norm_nonneg _) hc_gt.le
          refine ⟨u, v, huv_ans, huv_ne, ?_, hu_in, hv_in, huv_ne, hdiv_le.trans_eq huv_diam.symm, huv_diam.le⟩
          unfold ArithRAMDynamicProgram.readCachedAnswer
          change rRead mF 0 0 = _
          rw [hsq_eq, huv_ans, baselinePairLength, hcu, hcv])
    change ExecDet TW BW TR BR _ (updateExactStmt maxCap d) mem PostFull
      (200 + 25 * d + (100 + maxCap * (100 + maxCap * (200 + 80 * d)))) at hexec_full
    obtain ⟨mF, ⟨hencF, hretF, hvalidF⟩, hfpF, hstF⟩ := hexec_full
    obtain ⟨outR, hrunR, hmemR, hcostR, hspR⟩ := StepTo.to_runArithRAMWithBits hfp.1 hfp.cellCount_le hstF
    have hinp_card : P.activeHandles.card ≤ n := by
      have hbij : P.activeHandles.card = P.activeIds.card := by
        refine Finset.card_bij (fun h _ => P.idOfHandle h)
          (fun h hh => (hP.2.2.1 h hh).1)
          (fun h₁ hh₁ h₂ hh₂ heq => by
            dsimp only at heq; rw [← (hP.2.2.1 h₁ hh₁).2, ← (hP.2.2.1 h₂ hh₂).2, heq])
          (fun pid hpid => ⟨P.handleOfId pid, (hP.2.1 pid hpid).1, (hP.2.1 pid hpid).2⟩)
      rw [hbij]; exact hP.1
    cases op with
    | insert pid extName pt =>
      dsimp only [toInternalUpdate] at hrunR hspR hstep_eq
      have hrh_some : ∃ h, rh = some h := by
        have : (hp.step (.insert pt)).2 = rh := congrArg Prod.snd hstep_eq
        rw [← this]; dsimp [HandlePool.step]; cases hp.freeList <;> exact ⟨_, rfl⟩
      obtain ⟨h_new, hrh_eq⟩ := hrh_some
      have hret_eq : ArithRAMDynamicProgram.readReturnedHandle outR.mem = rh := by
        rw [hmemR, hrh_eq, hretF h_new hrh_eq]
      let ansOut := ArithRAMDynamicProgram.readCachedAnswer outR.mem
      let outStep : DynamicStepOutcome ArithRAMMemory :=
        { nextState := outR.mem
          returnedHandle := rh
          storedAnswer := { diameterHandles := ansOut.1, cachedDistSq := ansOut.2 }
          work := outR.unitCost
          peakSpace := outR.peakCellSpace }
      refine ⟨P', outStep, ?_, ⟨hcard_P'_s, by dsimp [outStep]; rwa [hmemR], hp', hhp', by dsimp [outStep]; rwa [hmemR]⟩, ?_, ?_, ?_⟩
      · simp only [runSingleAdaptiveStep, toInternalUpdate, alg, mkArithAlg, prog,
          ArithRAMDynamicProgram.evalUpdate, ite_true, ite_false, Bool.false_eq_true]
        rw [hrunR]; dsimp only [Option.map]; rw [hret_eq, happ]
      · dsimp only [outStep]
        refine (Nat.cast_le.mpr (hcostR.trans (by omega))).trans hWork
      · dsimp only [outStep]
        have hsp_nat : outR.peakCellSpace ≤ 8 * (n + 8) + 4 * (n * d + 8) + (d + 4) := by
          refine hspR.trans ?_
          simp only [ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil, List.length_ofFn, Nat.mul_add, Nat.mul_one]
          dsimp only [TW, BW, TR, BR]
          have hcd : P.activeHandles.card * d ≤ n * d := Nat.mul_le_mul_right d hinp_card
          omega
        exact (Nat.cast_le.mpr hsp_nat).trans hSpace
      · dsimp only [outStep, ansOut]; rw [hmemR]; exact hvalidF
    | delete pid =>
      dsimp only [toInternalUpdate] at hrunR hspR hstep_eq
      have hrh_none : rh = none := (congrArg Prod.snd hstep_eq).symm.trans rfl
      let ansOut := ArithRAMDynamicProgram.readCachedAnswer outR.mem
      let outStep : DynamicStepOutcome ArithRAMMemory :=
        { nextState := outR.mem
          returnedHandle := rh
          storedAnswer := { diameterHandles := ansOut.1, cachedDistSq := ansOut.2 }
          work := outR.unitCost
          peakSpace := outR.peakCellSpace }
      refine ⟨P', outStep, ?_, ⟨hcard_P'_s, by dsimp [outStep]; rwa [hmemR], hp', hhp', by dsimp [outStep]; rwa [hmemR]⟩, ?_, ?_, ?_⟩
      · simp only [runSingleAdaptiveStep, toInternalUpdate, alg, mkArithAlg, prog,
          ArithRAMDynamicProgram.evalUpdate, ite_true, ite_false, Bool.false_eq_true]
        rw [hrunR]; dsimp only [Option.map]; rw [← hrh_none, happ]
      · dsimp only [outStep]
        refine (Nat.cast_le.mpr (hcostR.trans (by omega))).trans hWork
      · dsimp only [outStep]
        have hsp_nat : outR.peakCellSpace ≤ 8 * (n + 8) + 4 * (n * d + 8) + (d + 4) := by
          refine hspR.trans ?_
          simp only [ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil, Nat.mul_add, Nat.mul_one]
          dsimp only [TW, BW, TR, BR]
          have hcd : P.activeHandles.card * d ≤ n * d := Nat.mul_le_mul_right d hinp_card
          omega
        exact (Nat.cast_le.mpr hsp_nat).trans hSpace
      · dsimp only [outStep, ansOut]; rw [hmemR]; exact hvalidF

  refine fixedCoinBridge hn ht hδ0 hδ1 0 alg ReachInv (fun _ _ _ => True)
    (by simpa [alg, mkArithAlg, initOut] using hW1)
    (by simpa [alg, mkArithAlg, initOut] using hS1)
    ⟨by simp [DynamicPointSet.empty], InFootprint.empty TW BW TR BR,
      HandlePool.empty d n, HandlePool.empty_wellFormed d n, encHandlePool_empty d n⟩
    trivial ?_ ?_ ?_
  · intro _ P mem op bs _ _ _ _ hlen
    have hbs : bs ≠ [] := List.ne_nil_of_length_pos (by omega)
    unfold runSingleAdaptiveStep
    cases toInternalUpdate P op with
    | insert pt =>
      dsimp only [alg, mkArithAlg, ArithRAMDynamicProgram.evalUpdate]
      rw [zeroRand_none_of_nonempty hzr _ _ hbs]; rfl
    | delete delH =>
      dsimp only [alg, mkArithAlg, ArithRAMDynamicProgram.evalUpdate]
      rw [zeroRand_none_of_nonempty hzr _ _ hbs]; rfl
  · intro s P mem op bits hs hP hR hleg
    have hnil : List.ofFn bits = [] := by simp
    rw [hnil]
    obtain ⟨P', out, hsome, hR', hw, hsp, hv⟩ := hRunStep s P mem op hs hP hR hleg
    exact ⟨P', out, hsome, hR', hw, hsp, fun _ => hv⟩
  · intro s P mem op hs hP hR _ hleg
    obtain ⟨P', out, hsome, _, _, _, _⟩ := hRunStep s P mem op hs hP hR hleg
    refine le_trans (b := (0 : ℝ)) ?_ (by positivity)
    norm_cast
    refine Nat.le_zero.mpr (Finset.card_eq_zero.mpr (Finset.eq_empty_iff_forall_notMem.mpr fun bits hmem => ?_))
    have hpred := (Finset.mem_filter.mp hmem).2
    have hnil : List.ofFn bits = [] := by simp
    rw [hnil, hsome] at hpred
    exact hpred trivial

end UL.Proof.clm_9_1_explicit_tradeoff.H3a3
