import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Stage1B
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 4. Job-Phase Live-Update Statements (`copyLiveUpdateStmt`, `buildLiveUpdateStmt`) -/

def copyLiveUpdateStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 30) (.add (.readHeap engScrTbl (.lit 21)) (.lit 5)))
  (.seq (.writeWordHeap engScrTbl (.lit 31)
          (.mul (.add (.lit 2) (.mul (.lit 4) (.readHeap engScrTbl (.lit 20))))
                (.lit (S_stride cp : ℤ))))
  (.seq (.writeWordHeap engScrTbl (.lit 32)
          (.mul (.add (.lit 3) (.mul (.lit 4) (.readHeap engScrTbl (.lit 20))))
                (.lit (S_stride cp : ℤ))))
        (.ite (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))
          (.seq (sparseContainsStmt cp.n 30 31 32 2 33)
                (.ite (.intEq (.readHeap engScrTbl (.lit 33)) (.lit 0))
                  (sparseInsertFreshStmt 30 31 32 2)
                  .skip))
          (sparseDeleteStmt cp.n 30 31 32 2))))

theorem zeroRand_copyLiveUpdateStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ZeroRandStmt (copyLiveUpdateStmt cp) :=
  .seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
    (.ite (.seq (zeroRand_sparseContainsStmt _ _ _ _ _ _)
            (.ite (zeroRand_sparseInsertFreshStmt _ _ _ _) .skip))
          (zeroRand_sparseDeleteStmt _ _ _ _ _))))

theorem exec_copyLiveUpdateStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (r : Fin cp.D_max) (cs : CopyState) {isIns : Bool} {h_op : ℕ}
    (hhop_lt : h_op < cp.n)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hsp₀ : EncSparseSet cp.n (jobMetaBase cp r.val + 5) (snapElemOff cp r.val)
      (snapPosOff cp r.val) cs.snapArr m₀)
    (hr1 : wRead m₀ engScrTbl 1 = (if isIns then 1 else 0))
    (hr2 : wRead m₀ engScrTbl 2 = (h_op : ℤ))
    (hr20 : wRead m₀ engScrTbl 20 = (r.val : ℤ))
    (hr21 : wRead m₀ engScrTbl 21 = jobMetaBase cp r.val) :
    let cs₁ := if isIns then cs.liveInsert h_op else cs.liveDelete h_op
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (copyLiveUpdateStmt cp) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        EncSparseSet cp.n (jobMetaBase cp r.val + 5) (snapElemOff cp r.val)
          (snapPosOff cp r.val) cs₁.snapArr m₁ ∧
        (∀ mn' s', ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m₁) ∧
        (∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ jobMetaBase cp r.val + 5 → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, (i < snapElemOff cp r.val ∨ snapPosOff cp r.val + (S_stride cp : ℤ) ≤ i) →
          wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, i < 30 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      380 := by
  have hTW := ops.hTW
  have hBW_s := ops_hBW_scr64 ops
  have hBW_m := ops.hBW_meta
  have hBW_a := ops.hBW_arr
  have hr_lt := r.isLt
  have hS_ge_n : cp.n < S_stride cp := by unfold S_stride; omega
  have hmeta_ub : jobMetaBase cp r.val + 8 ≤ 16 + 9 * (cp.D_max : ℤ) := by
    unfold jobMetaBase; omega
  have harr_ub : snapPosOff cp r.val + (S_stride cp : ℤ) ≤
      (((2 + 4 * cp.D_max) * S_stride cp : ℕ) : ℤ) := by
    unfold snapPosOff
    have : (3 + 4 * r.val) * S_stride cp + S_stride cp ≤ (2 + 4 * cp.D_max) * S_stride cp := by
      have : 4 + 4 * r.val ≤ 2 + 4 * cp.D_max := by omega
      nlinarith
    exact_mod_cast this
  have hse_le_sp : snapElemOff cp r.val + (cp.n : ℤ) ≤ snapPosOff cp r.val := by
    unfold snapElemOff snapPosOff
    have : (2 + 4 * r.val) * S_stride cp + cp.n ≤ (3 + 4 * r.val) * S_stride cp := by nlinarith
    exact_mod_cast this
  unfold copyLiveUpdateStmt
  refine ExecDet.seq' 360
    (ExecDet.wWrite (C := 16) inp engScrTbl (.lit 30)
      (.add (.readHeap engScrTbl (.lit 21)) (.lit 5))
      30 (jobMetaBase cp r.val + 5) hfp₀ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change wRead m₀ engScrTbl 21 + 5 = _; rw [hr21])
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mA₁ hmA₁ hfpA₁; subst hmA₁
  refine ExecDet.seq' 340
    (ExecDet.wWrite (C := 20) inp engScrTbl (.lit 31)
      (.mul (.add (.lit 2) (.mul (.lit 4) (.readHeap engScrTbl (.lit 20)))) (.lit (S_stride cp : ℤ)))
      31 (snapElemOff cp r.val) hfpA₁ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change (2 + 4 * wRead _ engScrTbl 20) * (S_stride cp : ℤ) = _
          rw [wRead_wWrite_of_ne m₀ _ (Or.inr (by decide)), hr20]
          unfold snapElemOff; push_cast; ring)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mA₂ hmA₂ hfpA₂; subst hmA₂
  refine ExecDet.seq' 320
    (ExecDet.wWrite (C := 20) inp engScrTbl (.lit 32)
      (.mul (.add (.lit 3) (.mul (.lit 4) (.readHeap engScrTbl (.lit 20)))) (.lit (S_stride cp : ℤ)))
      32 (snapPosOff cp r.val) hfpA₂ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change (3 + 4 * wRead _ engScrTbl 20) * (S_stride cp : ℤ) = _
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
              wRead_wWrite_of_ne m₀ _ (Or.inr (by decide)), hr20]
          unfold snapPosOff; push_cast; ring)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mA₃ hmA₃ hfpA; subst hmA₃
  set mA := H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engScrTbl 30 (jobMetaBase cp r.val + 5))
    engScrTbl 31 (snapElemOff cp r.val)) engScrTbl 32 (snapPosOff cp r.val)
  have hwA_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead mA t i = wRead m₀ t i := by
    intro t ht i; simp only [mA]
    iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
  have hwA_lt30 : ∀ i, i < 30 → wRead mA engScrTbl i = wRead m₀ engScrTbl i := by
    intro i hi; simp only [mA]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  have hrA : ∀ t i, rRead mA t i = rRead m₀ t i := fun _ _ => by simp [mA, rRead_wWrite]
  have hspA : EncSparseSet cp.n (jobMetaBase cp r.val + 5) (snapElemOff cp r.val)
      (snapPosOff cp r.val) cs.snapArr mA :=
    hsp₀.ext (hwA_ne8 engMetaTbl (by decide) _)
      (fun _ _ => hwA_ne8 engArrTbl (by decide) _)
      (fun _ _ => hwA_ne8 engArrTbl (by decide) _)
  have hr30A : wRead mA engScrTbl 30 = jobMetaBase cp r.val + 5 := by
    simp only [mA]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
        wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
  have hr31A : wRead mA engScrTbl 31 = snapElemOff cp r.val := by
    simp only [mA]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
  have hr32A : wRead mA engScrTbl 32 = snapPosOff cp r.val := by simp [mA]
  have hr2A : wRead mA engScrTbl 2 = (h_op : ℤ) := (hwA_lt30 2 (by omega)).trans hr2
  have hcond_ins : (evalArithCond inp 0 mA (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))).1 = isIns := by
    simp only [evalArithCond, evalIntExpr]
    change decide (wRead mA engScrTbl 1 = 1) = isIns
    rw [(hwA_lt30 1 (by omega)).trans hr1]; cases isIns <;> rfl
  refine ExecDet.ite' (C_c := 8) (C_b := 300) _ _ _ hcond_ins
    (by simp [condExprOps, intExprOps]) (fun his_t => ?_) (fun his_f => ?_)
  · refine ExecDet.seq' 120
      (exec_sparseContainsStmt inp 30 31 32 2 33 (by omega) hBW_s
        (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
        hfpA hspA hr30A hr31A hr32A hr2A) (by omega) ?_
    intro mB ⟨hcB, hwB_ne8, hwB_scr, hrB⟩ hfpB
    have hspB : EncSparseSet cp.n (jobMetaBase cp r.val + 5) (snapElemOff cp r.val)
        (snapPosOff cp r.val) cs.snapArr mB :=
      hspA.ext (hwB_ne8 engMetaTbl (by decide) _)
        (fun _ _ => hwB_ne8 engArrTbl (by decide) _)
        (fun _ _ => hwB_ne8 engArrTbl (by decide) _)
    have hcond_c : (evalArithCond inp 0 mB (.intEq (.readHeap engScrTbl (.lit 33)) (.lit 0))).1 =
        !cs.snapArr.contains h_op := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead mB engScrTbl 33 = 0) = _
      rw [hcB]; cases cs.snapArr.contains h_op <;> rfl
    refine ExecDet.ite' (C_c := 8) (C_b := 105) _ _ _ hcond_c
      (by simp [condExprOps, intExprOps]) (fun hnc => ?_) (fun hc => ?_)
    · have hc_f : cs.snapArr.contains h_op = false := by
        cases h : cs.snapArr.contains h_op <;> simp_all
      have hx_not : h_op ∉ cs.snapArr := fun hm => by rw [List.contains_iff_mem.mpr hm] at hc_f; cases hc_f
      refine (exec_sparseInsertFreshStmt inp 30 31 32 2 (by omega) hBW_s
        (by omega) (by omega) (by omega) (by omega)
        (by unfold jobMetaBase; omega) (by omega)
        (by unfold snapElemOff; exact Int.natCast_nonneg _) (by omega)
        (by unfold snapPosOff; exact Int.natCast_nonneg _) (by omega)
        (Or.inl hse_le_sp) hhop_lt hx_not hfpB hspB
        ((hwB_scr 30 (by omega) (by decide)).trans hr30A)
        ((hwB_scr 31 (by omega) (by decide)).trans hr31A)
        ((hwB_scr 32 (by omega) (by decide)).trans hr32A)
        ((hwB_scr 2 (by omega) (by decide)).trans hr2A)).mono ?_ (by omega)
      intro mC ⟨hspC, hwC_t, hwC_m, hwC_a, hwC_s, hrC⟩ _
      have hcs1 : (if isIns then cs.liveInsert h_op else cs.liveDelete h_op).snapArr =
          denseInsert h_op cs.snapArr := by
        rw [if_pos his_t]; dsimp [CopyState.liveInsert]; rw [if_neg (by rw [hc_f]; decide)]
      have hw0_t : ∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead mC t i = wRead m₀ t i :=
        fun t h1 h2 h3 i => (hwC_t t h1 h2 h3 i).trans ((hwB_ne8 t h3 i).trans (hwA_ne8 t h3 i))
      have hr0_all : ∀ t i, rRead mC t i = rRead m₀ t i :=
        fun t i => (hrC t i).trans ((hrB t i).trans (hrA t i))
      refine ⟨ops.slotsReady_ext m₀ mC hsr₀
          (fun t ht9 _ i => hw0_t t (by dsimp [engMetaTbl]; omega) (by dsimp [engArrTbl]; omega) (by dsimp [engScrTbl]; omega) i)
          (fun t _ _ i => hr0_all t i),
        hcs1 ▸ hspC,
        fun mn' s' he => ops.encNode_ext mn' s' m₀ mC he
          (fun t ht9 _ i => hw0_t t (by dsimp [engMetaTbl]; omega) (by dsimp [engArrTbl]; omega) (by dsimp [engScrTbl]; omega) i)
          (fun t _ _ i => hr0_all t i)
          (fun _ _ _ _ => hr0_all ptsRTbl _),
        hw0_t,
        fun i hi => (hwC_m i hi).trans ((hwB_ne8 engMetaTbl (by decide) i).trans (hwA_ne8 engMetaTbl (by decide) i)),
        fun i hi => (hwC_a i ?_ ?_).trans ((hwB_ne8 engArrTbl (by decide) i).trans (hwA_ne8 engArrTbl (by decide) i)),
        fun i hi => (hwC_s i (by omega)).trans ((hwB_scr i (by omega) (by omega)).trans (hwA_lt30 i hi)),
        hr0_all⟩
      · have hlen_le : cs.snapArr.length ≤ cp.n := hspB.length_le
        omega
      · omega
    · have hc_t : cs.snapArr.contains h_op = true := by
        cases h : cs.snapArr.contains h_op <;> simp_all
      refine ExecDet.skip inp hfpB ?_ (by omega)
      have hcs1 : (if isIns then cs.liveInsert h_op else cs.liveDelete h_op).snapArr = cs.snapArr := by
        rw [if_pos his_t]; dsimp [CopyState.liveInsert]; rw [if_pos hc_t]
      have hw0_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead mB t i = wRead m₀ t i :=
        fun t ht i => (hwB_ne8 t ht i).trans (hwA_ne8 t ht i)
      have hr0_all : ∀ t i, rRead mB t i = rRead m₀ t i :=
        fun t i => (hrB t i).trans (hrA t i)
      exact ⟨ops.slotsReady_ext m₀ mB hsr₀
          (fun t ht9 _ i => hw0_ne8 t (by dsimp [engScrTbl]; omega) i)
          (fun t _ _ i => hr0_all t i),
        hcs1 ▸ hspB,
        fun mn' s' he => ops.encNode_ext mn' s' m₀ mB he
          (fun t ht9 _ i => hw0_ne8 t (by dsimp [engScrTbl]; omega) i)
          (fun t _ _ i => hr0_all t i)
          (fun _ _ _ _ => hr0_all ptsRTbl _),
        fun t _ _ h3 i => hw0_ne8 t h3 i,
        fun i _ => hw0_ne8 engMetaTbl (by decide) i,
        fun i _ => hw0_ne8 engArrTbl (by decide) i,
        fun i hi => (hwB_scr i (by omega) (by omega)).trans (hwA_lt30 i hi),
        hr0_all⟩
  · refine (exec_sparseDeleteStmt inp 30 31 32 2 (by omega) hBW_s
      (by omega) (by omega) (by omega) (by omega)
      (by unfold jobMetaBase; omega) (by omega)
      (by unfold snapElemOff; exact Int.natCast_nonneg _) (by omega)
      (by unfold snapPosOff; exact Int.natCast_nonneg _) (by omega)
      (Or.inl hse_le_sp) hfpA hspA hr30A hr31A hr32A hr2A).mono ?_ (by omega)
    intro mC ⟨hspC, hwC_t, hwC_m, hwC_a, hwC_s, hrC⟩ _
    have hcs1 : (if isIns then cs.liveInsert h_op else cs.liveDelete h_op).snapArr =
        denseDelete h_op cs.snapArr := by
      rw [if_neg (by simp [his_f])]; rfl
    have hw0_t : ∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead mC t i = wRead m₀ t i :=
      fun t h1 h2 h3 i => (hwC_t t h1 h2 h3 i).trans (hwA_ne8 t h3 i)
    have hr0_all : ∀ t i, rRead mC t i = rRead m₀ t i :=
      fun t i => (hrC t i).trans (hrA t i)
    refine ⟨ops.slotsReady_ext m₀ mC hsr₀
        (fun t ht9 _ i => hw0_t t (by dsimp [engMetaTbl]; omega) (by dsimp [engArrTbl]; omega) (by dsimp [engScrTbl]; omega) i)
        (fun t _ _ i => hr0_all t i),
      hcs1 ▸ hspC,
      fun mn' s' he => ops.encNode_ext mn' s' m₀ mC he
        (fun t ht9 _ i => hw0_t t (by dsimp [engMetaTbl]; omega) (by dsimp [engArrTbl]; omega) (by dsimp [engScrTbl]; omega) i)
        (fun t _ _ i => hr0_all t i)
        (fun _ _ _ _ => hr0_all ptsRTbl _),
      hw0_t,
      fun i hi => (hwC_m i hi).trans (hwA_ne8 engMetaTbl (by decide) i),
      fun i hi => (hwC_a i (by omega) (by omega)).trans (hwA_ne8 engArrTbl (by decide) i),
      fun i hi => (hwC_s i (by omega)).trans (hwA_lt30 i hi),
      hr0_all⟩


/-! ### 5. Leaf Update (`leafLiveUpdateStmt`) & `BuildState` Live Update (`buildLiveUpdateStmt`) -/

theorem denseInsert_length_le_succ {x : ℕ} {arr : List ℕ} :
    (denseInsert x arr).length ≤ arr.length + 1 := by
  unfold denseInsert
  simp

theorem denseDelete_length_le {x : ℕ} {arr : List ℕ} :
    (denseDelete x arr).length ≤ arr.length := by
  unfold denseDelete
  dsimp only
  split_ifs <;> simp [List.length_set, List.length_take]

def leafLiveUpdateStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ArithRAMStmt :=
  .ite (.and (.intEq (.readHeap engScrTbl (.lit 14)) (.lit 1))
             (.intEq (.readHeap engMetaTbl (.lit 1)) (.lit 0)))
    (.seq (.writeWordHeap engScrTbl (.lit 30) (.lit 2))
    (.seq (.writeWordHeap engScrTbl (.lit 31) (.lit leafElemOff))
    (.seq (.writeWordHeap engScrTbl (.lit 32) (.lit (leafPosOff cp)))
          (.ite (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))
            (sparseInsertFreshStmt 30 31 32 2)
            (sparseDeleteStmt cp.n 30 31 32 2)))))
    .skip

theorem zeroRand_leafLiveUpdateStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ZeroRandStmt (leafLiveUpdateStmt cp) :=
  .ite (.seq (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _)
          (.ite (zeroRand_sparseInsertFreshStmt _ _ _ _)
                (zeroRand_sparseDeleteStmt _ _ _ _ _)))))
       .skip

theorem exec_leafLiveUpdateStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    {leafArr : List ℕ} {servPassed leafOverflow isIns : Bool} {h_op : ℕ}
    (hhop_lt : h_op < cp.n)
    (hleaf_le : leafArr.length ≤ cp.B_scan + 1)
    (hov_inv : leafOverflow = false →
      (isIns = true → h_op ∉ leafArr) ∧ leafArr.length ≤ cp.B_scan)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hov_rd : wRead m₀ engMetaTbl 1 = (if leafOverflow then 1 else 0))
    (hsp₀ : EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) leafArr m₀)
    (hr1 : wRead m₀ engScrTbl 1 = (if isIns then 1 else 0))
    (hr2 : wRead m₀ engScrTbl 2 = (h_op : ℤ))
    (hr14 : wRead m₀ engScrTbl 14 = (if servPassed then 1 else 0)) :
    let leafArr₁ :=
      if servPassed && !leafOverflow then
        if isIns then denseInsert h_op leafArr else denseDelete h_op leafArr
      else
        leafArr
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (leafLiveUpdateStmt cp) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        leafArr₁.length ≤ cp.B_scan + 1 ∧
        EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) leafArr₁ m₁ ∧
        (∀ mn' s', ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m₁) ∧
        (∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 2 → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, 2 * (S_stride cp : ℤ) ≤ i → wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, i < 30 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      340 := by
  have hTW := ops.hTW
  have hBW_s := ops_hBW_scr64 ops
  have hBW_m := ops.hBW_meta
  have hBW_a := ops.hBW_arr
  have hS_ge_n : cp.n < S_stride cp := by unfold S_stride; omega
  have h2S_le : 2 * S_stride cp ≤ (2 + 4 * cp.D_max) * S_stride cp :=
    Nat.mul_le_mul_right _ (by omega)
  have hcond : (evalArithCond inp 0 m₀
      (.and (.intEq (.readHeap engScrTbl (.lit 14)) (.lit 1))
            (.intEq (.readHeap engMetaTbl (.lit 1)) (.lit 0)))).1 =
      (servPassed && !leafOverflow) := by
    simp only [evalArithCond, evalIntExpr]
    change (decide (wRead m₀ engScrTbl 14 = 1) && decide (wRead m₀ engMetaTbl 1 = 0)) = _
    rw [hr14, hov_rd]
    cases servPassed <;> cases leafOverflow <;> rfl
  unfold leafLiveUpdateStmt
  refine ExecDet.ite' (C_c := 16) (C_b := 320) _ _ _ hcond
    (by simp [condExprOps, intExprOps]) (fun hgo => ?_) (fun hskip => ?_)
  · rcases Bool.and_eq_true_iff.mp hgo with ⟨hsp_t, hnov_t⟩
    have hov_f : leafOverflow = false := by cases leafOverflow <;> simp_all
    rcases hov_inv hov_f with ⟨hins_not, hlen_B⟩
    refine ExecDet.seq' 304
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 30) (.lit 2) 30 2
        hfp₀ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
      (by omega) ?_
    intro mA₁ hmA₁ hfpA₁; subst hmA₁
    refine ExecDet.seq' 290
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 31) (.lit leafElemOff) 31 leafElemOff
        hfpA₁ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
      (by omega) ?_
    intro mA₂ hmA₂ hfpA₂; subst hmA₂
    refine ExecDet.seq' 276
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 32) (.lit (leafPosOff cp)) 32 (leafPosOff cp)
        hfpA₂ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
      (by omega) ?_
    intro mA₃ hmA₃ hfpA; subst hmA₃
    set mA := H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engScrTbl 30 2) engScrTbl 31 leafElemOff)
      engScrTbl 32 (leafPosOff cp)
    have hwA_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead mA t i = wRead m₀ t i := by
      intro t ht i; simp only [mA]
      iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
    have hwA_lt30 : ∀ i, i < 30 → wRead mA engScrTbl i = wRead m₀ engScrTbl i := by
      intro i hi; simp only [mA]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    have hrA : ∀ t i, rRead mA t i = rRead m₀ t i := fun _ _ => by simp [mA, rRead_wWrite]
    have hspA : EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) leafArr mA :=
      hsp₀.ext (hwA_ne8 engMetaTbl (by decide) 2)
        (fun _ _ => hwA_ne8 engArrTbl (by decide) _)
        (fun _ _ => hwA_ne8 engArrTbl (by decide) _)
    have hr30A : wRead mA engScrTbl 30 = 2 := by
      simp only [mA]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
          wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
    have hr31A : wRead mA engScrTbl 31 = leafElemOff := by
      simp only [mA]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
    have hr32A : wRead mA engScrTbl 32 = leafPosOff cp := by simp [mA]
    have hr2A : wRead mA engScrTbl 2 = (h_op : ℤ) := (hwA_lt30 2 (by omega)).trans hr2
    have hcond_ins : (evalArithCond inp 0 mA (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))).1 = isIns := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead mA engScrTbl 1 = 1) = isIns
      rw [(hwA_lt30 1 (by omega)).trans hr1]; cases isIns <;> rfl
    refine ExecDet.ite' (C_c := 8) (C_b := 265) _ _ _ hcond_ins
      (by simp [condExprOps, intExprOps]) (fun his_t => ?_) (fun his_f => ?_)
    · refine (exec_sparseInsertFreshStmt inp 30 31 32 2 (by omega) hBW_s
        (by omega) (by omega) (by omega) (by omega)
        (by omega) (by omega)
        (by unfold leafElemOff; omega) (by unfold leafElemOff; omega)
        (by unfold leafPosOff; exact Int.natCast_nonneg _) (by unfold leafPosOff; omega)
        (Or.inl (by unfold leafElemOff leafPosOff; omega))
        hhop_lt (hins_not his_t) hfpA hspA hr30A hr31A hr32A hr2A).mono ?_ (by omega)
      intro mB ⟨hspB, hwB_t, hwB_m, hwB_a, hwB_s, hrB⟩ _
      have hl1 : (if servPassed && !leafOverflow then
          if isIns then denseInsert h_op leafArr else denseDelete h_op leafArr else leafArr) =
          denseInsert h_op leafArr := by simp [hgo, his_t]
      have hw0_t : ∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead mB t i = wRead m₀ t i :=
        fun t h1 h2 h3 i => (hwB_t t h1 h2 h3 i).trans (hwA_ne8 t h3 i)
      have hr0_all : ∀ t i, rRead mB t i = rRead m₀ t i := fun t i => (hrB t i).trans (hrA t i)
      have hlen_le_n : leafArr.length ≤ cp.n := hspA.length_le
      refine ⟨ops.slotsReady_ext m₀ mB hsr₀
          (fun t ht9 _ i => hw0_t t (by dsimp [engMetaTbl]; omega) (by dsimp [engArrTbl]; omega) (by dsimp [engScrTbl]; omega) i)
          (fun t _ _ i => hr0_all t i),
        by rw [hl1]; exact denseInsert_length_le_succ.trans (Nat.add_le_add_right hlen_B 1),
        (by (try dsimp only); rw [hl1]; exact hspB),
        fun mn' s' he => ops.encNode_ext mn' s' m₀ mB he
          (fun t ht9 _ i => hw0_t t (by dsimp [engMetaTbl]; omega) (by dsimp [engArrTbl]; omega) (by dsimp [engScrTbl]; omega) i)
          (fun t _ _ i => hr0_all t i)
          (fun _ _ _ _ => hr0_all ptsRTbl _),
        hw0_t,
        fun i hi => (hwB_m i hi).trans (hwA_ne8 engMetaTbl (by decide) i),
        fun i hi => (hwB_a i (by unfold leafElemOff; omega) (by unfold leafPosOff; omega)).trans
          (hwA_ne8 engArrTbl (by decide) i),
        fun i hi => (hwB_s i (by omega)).trans (hwA_lt30 i hi),
        hr0_all⟩
    · refine (exec_sparseDeleteStmt inp 30 31 32 2 (by omega) hBW_s
        (by omega) (by omega) (by omega) (by omega)
        (by omega) (by omega)
        (by unfold leafElemOff; omega) (by unfold leafElemOff; omega)
        (by unfold leafPosOff; exact Int.natCast_nonneg _) (by unfold leafPosOff; omega)
        (Or.inl (by unfold leafElemOff leafPosOff; omega))
        hfpA hspA hr30A hr31A hr32A hr2A).mono ?_ (by omega)
      intro mB ⟨hspB, hwB_t, hwB_m, hwB_a, hwB_s, hrB⟩ _
      have hl1 : (if servPassed && !leafOverflow then
          if isIns then denseInsert h_op leafArr else denseDelete h_op leafArr else leafArr) =
          denseDelete h_op leafArr := by simp [hgo, his_f]
      have hw0_t : ∀ t, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead mB t i = wRead m₀ t i :=
        fun t h1 h2 h3 i => (hwB_t t h1 h2 h3 i).trans (hwA_ne8 t h3 i)
      have hr0_all : ∀ t i, rRead mB t i = rRead m₀ t i := fun t i => (hrB t i).trans (hrA t i)
      refine ⟨ops.slotsReady_ext m₀ mB hsr₀
          (fun t ht9 _ i => hw0_t t (by dsimp [engMetaTbl]; omega) (by dsimp [engArrTbl]; omega) (by dsimp [engScrTbl]; omega) i)
          (fun t _ _ i => hr0_all t i),
        by rw [hl1]; exact denseDelete_length_le.trans hleaf_le,
        (by (try dsimp only); rw [hl1]; exact hspB),
        fun mn' s' he => ops.encNode_ext mn' s' m₀ mB he
          (fun t ht9 _ i => hw0_t t (by dsimp [engMetaTbl]; omega) (by dsimp [engArrTbl]; omega) (by dsimp [engScrTbl]; omega) i)
          (fun t _ _ i => hr0_all t i)
          (fun _ _ _ _ => hr0_all ptsRTbl _),
        hw0_t,
        fun i hi => (hwB_m i hi).trans (hwA_ne8 engMetaTbl (by decide) i),
        fun i hi => (hwB_a i (by unfold leafElemOff; omega) (by unfold leafPosOff; omega)).trans
          (hwA_ne8 engArrTbl (by decide) i),
        fun i hi => (hwB_s i (by omega)).trans (hwA_lt30 i hi),
        hr0_all⟩
  · refine ExecDet.skip inp hfp₀ ?_ (by omega)
    have hl1 : (if servPassed && !leafOverflow then
        if isIns then denseInsert h_op leafArr else denseDelete h_op leafArr else leafArr) =
        leafArr := by simp [hskip]
    exact ⟨hsr₀, (by (try dsimp only); rw [hl1]; exact hleaf_le), (by (try dsimp only); rw [hl1]; exact hsp₀),
      fun _ _ h => h, fun _ _ _ _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl,
      fun _ _ => rfl⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG19
