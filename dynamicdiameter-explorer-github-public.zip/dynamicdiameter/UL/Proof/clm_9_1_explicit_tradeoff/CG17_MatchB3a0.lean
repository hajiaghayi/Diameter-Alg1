import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB2

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 1. `configDynRemoveHdrStmt`: Header Unlink & Index-Epoch Zeroing (Phases 1–4) -/

theorem EncLocalMatching.congr_state {tblW : ℕ} {cfgBaseW : ℤ} {n : ℕ}
    {st st' : LocalMatchingState ℕ} {m : ArithRAMMemory}
    (henc : EncLocalMatching tblW cfgBaseW n st m)
    (hpairs : st'.matchingList.map MatchingEdge.pair = st.matchingList.map MatchingEdge.pair)
    (hUL : st'.leftIndexSet = st.leftIndexSet)
    (hUR : st'.rightIndexSet = st.rightIndexSet) :
    EncLocalMatching tblW cfgBaseW n st' m := by
  rcases henc with ⟨ep, hep1, hep_r, hndL, hndR, hpairs_lt, hUL_lt, hUR_lt,
    hdll, hmL_le, hmL_to, hmL_of, hmR_le, hmR_to, hmR_of, hiL, hiR⟩
  refine ⟨ep, hep1, hep_r, by rwa [hpairs], by rwa [hpairs], by rwa [hpairs],
    by rwa [hUL], by rwa [hUR], by rwa [hpairs], hmL_le,
    fun u hu h => by rw [hpairs]; exact hmL_to u hu h,
    fun x y hxy => hmL_of x y (hpairs ▸ hxy),
    hmR_le,
    fun u hu h => by rw [hpairs]; exact hmR_to u hu h,
    fun x y hxy => hmR_of x y (hpairs ▸ hxy),
    fun u hu => by rw [hUL]; exact hiL u hu,
    fun u hu => by rw [hUR]; exact hiR u hu⟩

private lemma pairs_filter_left_eq (es : List (MatchingEdge ℕ)) (p : ℕ) :
    (es.filter (fun e => decide (e.left ≠ p))).map MatchingEdge.pair =
    (es.map MatchingEdge.pair).filter (fun xy => decide (xy.1 ≠ p)) := by
  induction es with
  | nil => rfl
  | cons e tl ih =>
      simp only [List.map_cons, List.filter_cons]
      dsimp only [MatchingEdge.pair]
      split_ifs with h
      · simp only [List.map_cons, ih, MatchingEdge.pair]
      · exact ih

def configDynRemoveHdrCost : ℕ := 380 + 2 * unlinkLeftKeyCost

def configDynRemoveHdrStmt (scrW tblW n : ℕ)
    (wCfgBaseW wUid wScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wCfgBaseW)
  let wEp := wScr
  let wHasRP := wScr + 1
  let wYRP := wScr + 2
  let wHasLP := wScr + 3
  let wXLP := wScr + 4
  let wP := wScr + 7
  let wSub := wScr + 8
  let pE := IntExpr.readHeap scrW (.lit wP)
  let epE := IntExpr.readHeap scrW (.lit wEp)
  .seq (.writeWordHeap scrW (.lit wP) (.readHeap scrW (.lit wUid)))
  (.seq (.writeWordHeap scrW (.lit wEp) (.readHeap tblW bWE))
  (.seq (.ite (.intEq (.readHeap tblW (.add (.add bWE (.lit 3)) pE)) epE)
          (.seq (.writeWordHeap scrW (.lit wYRP)
                  (.readHeap tblW (.add (.add bWE (.lit (3 + (n : ℤ)))) pE)))
          (.seq (.ite (.intEq (.readHeap scrW (.lit wYRP)) pE)
                  (.writeWordHeap scrW (.lit wHasRP) (.lit 0))
                  (.writeWordHeap scrW (.lit wHasRP) (.lit 1)))
                (unlinkLeftKeyStmt scrW tblW n wCfgBaseW wP wSub)))
          (.seq (.writeWordHeap scrW (.lit wHasRP) (.lit 0))
                (.writeWordHeap scrW (.lit wYRP) (.lit 0))))
  (.seq (.writeWordHeap scrW (.lit wEp) (.readHeap tblW bWE))
  (.seq (.ite (.intEq (.readHeap tblW (.add (.add bWE (.lit (3 + 2 * (n : ℤ)))) pE)) epE)
          (.seq (.writeWordHeap scrW (.lit wXLP)
                  (.readHeap tblW (.add (.add bWE (.lit (3 + 3 * (n : ℤ)))) pE)))
          (.seq (.writeWordHeap scrW (.lit wHasLP) (.lit 1))
                (unlinkLeftKeyStmt scrW tblW n wCfgBaseW wXLP wSub)))
          (.seq (.writeWordHeap scrW (.lit wHasLP) (.lit 0))
                (.writeWordHeap scrW (.lit wXLP) (.lit 0))))
  (.seq (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 4 * (n : ℤ)))) pE) (.lit 0))
        (.writeWordHeap tblW (.add (.add bWE (.lit (3 + 5 * (n : ℤ)))) pE) (.lit 0)))))))

theorem zeroRand_configDynRemoveHdrStmt (scrW tblW n : ℕ)
    (wCfgBaseW wUid wScr : ℤ) :
    ZeroRandStmt (configDynRemoveHdrStmt scrW tblW n wCfgBaseW wUid wScr) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
  (.seq (.ite
          (.seq (.writeWordHeap _ _ _) (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
                (zeroRand_unlinkLeftKeyStmt _ _ _ _ _ _)))
          (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
  (.seq (.writeWordHeap _ _ _)
  (.seq (.ite
          (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
                (zeroRand_unlinkLeftKeyStmt _ _ _ _ _ _)))
          (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
  (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))))

theorem exec_configDynRemoveHdrStmt {d n : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCfgBaseW wUid wScr cfgBaseW cfgBaseR : ℤ)
    {p : ℕ} (hp_lt : p < n) {st : LocalMatchingState ℕ}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ cfgBaseW ∧ cfgBaseW + cfgHdrWStride n ≤ (BW : ℤ))
    (hwBW : 0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr)
    (_hwUid : 0 ≤ wUid ∧ wUid < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + 11 ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW)
    (hp_r : H3a.wRead m₀ scrW wUid = (p : ℤ))
    (henc : EncLocalMatching tblW cfgBaseW n st m₀) :
    let pairs := st.matchingList.map MatchingEdge.pair
    let rP := (st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
      (fun e => CopyVertex.mk .right e.right)
    let lP := (st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
      (fun e => CopyVertex.mk .left e.left)
    ∃ md : ArithRAMMemory,
      DetExec inp (configDynRemoveHdrStmt scrW tblW n wCfgBaseW wUid wScr)
        m₀ md configDynRemoveHdrCost ∧
      InFootprint TW BW TR BR md ∧
      EncLocalMatching tblW cfgBaseW n (removeCopiesFromState st p) md ∧
      (∀ w, w < wScr → H3a.wRead md scrW w = H3a.wRead m₀ scrW w) ∧
      H3a.wRead md scrW (wScr + 7) = (p : ℤ) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m₀ md ∧
      ((rP = [] ∧ H3a.wRead md scrW (wScr + 1) = 0) ∨
       (∃ y₀ : ℕ, y₀ ≠ p ∧ (p, y₀) ∈ pairs ∧ rP = [⟨.right, y₀⟩] ∧
         H3a.wRead md scrW (wScr + 1) = 1 ∧ H3a.wRead md scrW (wScr + 2) = (y₀ : ℤ))) ∧
      ((lP = [] ∧ H3a.wRead md scrW (wScr + 3) = 0) ∨
       (∃ x₀ : ℕ, x₀ ≠ p ∧ (x₀, p) ∈ pairs ∧ lP = [⟨.left, x₀⟩] ∧
         H3a.wRead md scrW (wScr + 3) = 1 ∧ H3a.wRead md scrW (wScr + 4) = (x₀ : ℤ))) := by
  intro pairs rP lP
  have hscrW : scrW < TW := hvt.1
  have htblW : tblW < TW := hvt.2.1
  have hneW : tblW ≠ scrW := hvt.2.2.2.2.2.2.1
  let wEp := wScr
  let wHasRP := wScr + 1
  let wYRP := wScr + 2
  let wHasLP := wScr + 3
  let wXLP := wScr + 4
  let wP := wScr + 7
  let wSub := wScr + 8
  rcases henc with ⟨ep0, hep0_pos, hep0_r, hndL0, hndR0, hpairs_lt0, hUL_lt0, hUR_lt0,
    hdll0, hmL0_le, hmL0_to, hmL0_of, hmR0_le, hmR0_to, hmR0_of, hiL0, hiR0⟩
  have henc_hdr0 : EncLocalMatching tblW cfgBaseW n st m₀ :=
    ⟨ep0, hep0_pos, hep0_r, hndL0, hndR0, hpairs_lt0, hUL_lt0, hUR_lt0,
     hdll0, hmL0_le, hmL0_to, hmL0_of, hmR0_le, hmR0_to, hmR0_of, hiL0, hiR0⟩
  let m1 := H3a.wWrite m₀ scrW wP (p : ℤ)
  let m2 := H3a.wWrite m1 scrW wEp (ep0 : ℤ)
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wP) (.readHeap scrW (.lit wUid))) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wP) _ rfl hp_r
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit wEp)
      (.readHeap tblW (.readHeap scrW (.lit wCfgBaseW)))) m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wEp) _ rfl
      (by change H3a.wRead m1 tblW (H3a.wRead m1 scrW wCfgBaseW) = (ep0 : ℤ)
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbW]
          exact hep0_r)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp2 : InFootprint TW BW TR BR m2 :=
    InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hfr02 : RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m₀ m2 :=
    (rfo_wWrite_scr _ _ _ _ _ _ _ _ m₀ wP (p : ℤ)).trans (rfo_wWrite_scr _ _ _ _ _ _ _ _ m1 wEp (ep0 : ℤ))
  have hscr02 : ∀ w, w < wScr → H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w :=
    fun w hw => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (wRead_wWrite_of_ne _ _ (Or.inr (by omega)))
  have hwP2 : H3a.wRead m2 scrW wP = (p : ℤ) :=
    (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _)
  have hwEp2 : H3a.wRead m2 scrW wEp = (ep0 : ℤ) := wRead_wWrite_self _ _ _ _
  have henc_hdr2 : EncLocalMatching tblW cfgBaseW n st m2 :=
    henc_hdr0.mono_slice (fun i _ _ => by simp [m2, m1, wRead_wWrite_of_ne _ _ (Or.inl hneW)])
  let st1 : LocalMatchingState ℕ :=
    { st with matchingList := st.matchingList.filter (fun e => decide (e.left ≠ p)) }
  have hpairs1 : st1.matchingList.map MatchingEdge.pair =
      pairs.filter (fun xy => decide (xy.1 ≠ p)) :=
    pairs_filter_left_eq st.matchingList p
  have hphase2 : ∃ mb : ArithRAMMemory,
      DetExec inp (.ite (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 3))
                                                      (.readHeap scrW (.lit wP))))
                                (.readHeap scrW (.lit wEp)))
        (.seq (.writeWordHeap scrW (.lit wYRP)
                (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + (n : ℤ))))
                                      (.readHeap scrW (.lit wP)))))
        (.seq (.ite (.intEq (.readHeap scrW (.lit wYRP)) (.readHeap scrW (.lit wP)))
                (.writeWordHeap scrW (.lit wHasRP) (.lit 0))
                (.writeWordHeap scrW (.lit wHasRP) (.lit 1)))
              (unlinkLeftKeyStmt scrW tblW n wCfgBaseW wP wSub)))
        (.seq (.writeWordHeap scrW (.lit wHasRP) (.lit 0))
              (.writeWordHeap scrW (.lit wYRP) (.lit 0))))
        m2 mb (120 + unlinkLeftKeyCost) ∧
      InFootprint TW BW TR BR mb ∧
      EncLocalMatching tblW cfgBaseW n st1 mb ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m2 mb ∧
      (∀ w, w < wScr → H3a.wRead mb scrW w = H3a.wRead m₀ scrW w) ∧
      H3a.wRead mb scrW wP = (p : ℤ) ∧
      ((rP = [] ∧ H3a.wRead mb scrW wHasRP = 0) ∨
       (∃ y₀ : ℕ, y₀ ≠ p ∧ (p, y₀) ∈ pairs ∧ rP = [⟨.right, y₀⟩] ∧
         H3a.wRead mb scrW wHasRP = 1 ∧ H3a.wRead mb scrW wYRP = (y₀ : ℤ))) := by
    have hmL2 : H3a.wRead m2 tblW ((cfgBaseW + 3) + (p : ℤ)) =
        H3a.wRead m₀ tblW (cfgMateLEpOff cfgBaseW n p) := by
      rw [show (cfgBaseW + 3) + (p : ℤ) = cfgMateLEpOff cfgBaseW n p by unfold cfgMateLEpOff; ring,
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    by_cases hmeq : H3a.wRead m₀ tblW (cfgMateLEpOff cfgBaseW n p) = (ep0 : ℤ)
    · obtain ⟨y₀, hpy_mem, hmLVal0⟩ := hmL0_to p hp_lt hmeq
      have hrP_eq := rP_eq_of_mem_pair hndL0 hpy_mem
      have hct : cValAt 0 inp m2 (.intEq (.readHeap tblW
          (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 3)) (.readHeap scrW (.lit wP))))
          (.readHeap scrW (.lit wEp))) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m2 tblW ((H3a.wRead m2 scrW wCfgBaseW + 3) + H3a.wRead m2 scrW wP) =
          H3a.wRead m2 scrW wEp) = true
        rw [hscr02 wCfgBaseW hwBW.2, hbW, hwP2, hwEp2, hmL2, hmeq]; exact decide_eq_true rfl
      let m2a := H3a.wWrite m2 scrW wYRP (y₀ : ℤ)
      have hd2a : DetExec inp (.writeWordHeap scrW (.lit wYRP)
          (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + (n : ℤ))))
                                (.readHeap scrW (.lit wP))))) m2 m2a 35 :=
        DetExecAt.writeWordHeap 0 inp m2 scrW (.lit wYRP) _ rfl
          (by change H3a.wRead m2 tblW ((H3a.wRead m2 scrW wCfgBaseW + (3 + (n : ℤ))) +
                H3a.wRead m2 scrW wP) = (y₀ : ℤ)
              rw [hscr02 wCfgBaseW hwBW.2, hbW, hwP2,
                  show (cfgBaseW + (3 + (n : ℤ))) + (p : ℤ) = cfgMateLValOff cfgBaseW n p by
                    unfold cfgMateLValOff; ring,
                  wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
              exact hmLVal0)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp2a : InFootprint TW BW TR BR m2a := InFootprint.wWrite hfp2 hscrW (by omega) (by omega)
      let flagVal : ℤ := if y₀ = p then 0 else 1
      let m2b := H3a.wWrite m2a scrW wHasRP flagVal
      have hd2b : DetExec inp (.ite (.intEq (.readHeap scrW (.lit wYRP)) (.readHeap scrW (.lit wP)))
          (.writeWordHeap scrW (.lit wHasRP) (.lit 0))
          (.writeWordHeap scrW (.lit wHasRP) (.lit 1))) m2a m2b 35 := by
        by_cases hyp : y₀ = p
        · have hcy : cValAt 0 inp m2a (.intEq (.readHeap scrW (.lit wYRP)) (.readHeap scrW (.lit wP))) = true := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m2a scrW wYRP = H3a.wRead m2a scrW wP) = true
            rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hwP2, hyp]; exact decide_eq_true rfl
          have hdw : DetExec inp (.writeWordHeap scrW (.lit wHasRP) (.lit 0)) m2a m2b 15 :=
            DetExecAt.writeWordHeap 0 inp m2a scrW (.lit wHasRP) (.lit 0) rfl
              (by dsimp [flagVal]; rw [if_pos hyp])
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          exact (DetExecAt.ite_true (C_c := 15) hcy
            (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            hdw).mono_cost (by omega)
        · have hcy : cValAt 0 inp m2a (.intEq (.readHeap scrW (.lit wYRP)) (.readHeap scrW (.lit wP))) = false := by
            simp only [cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m2a scrW wYRP = H3a.wRead m2a scrW wP) = false
            rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hwP2]
            exact decide_eq_false (by omega)
          have hdw : DetExec inp (.writeWordHeap scrW (.lit wHasRP) (.lit 1)) m2a m2b 15 :=
            DetExecAt.writeWordHeap 0 inp m2a scrW (.lit wHasRP) (.lit 1) rfl
              (by dsimp [flagVal]; rw [if_neg hyp])
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          exact (DetExecAt.ite_false (C_c := 15) hcy
            (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            hdw).mono_cost (by omega)
      have hfp2b : InFootprint TW BW TR BR m2b := InFootprint.wWrite hfp2a hscrW (by omega) (by omega)
      have henc_hdr2b : EncLocalMatching tblW cfgBaseW n st m2b :=
        henc_hdr2.mono_slice (fun i _ _ => by simp [m2b, m2a, wRead_wWrite_of_ne _ _ (Or.inl hneW)])
      obtain ⟨mb, hd_unl, hfpb, henc_hdrb, hkWb, hfr_unl⟩ :=
        exec_unlinkLeftKeyStmt (tblR := tblR) (coinTbl := coinTbl) inp
          wCfgBaseW wP wSub cfgBaseW cfgBaseR (st := st) (st' := st1)
          hfp2b hvt hbaseW
          ⟨hwBW.1, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  hscr02 wCfgBaseW hwBW.2, hbW])
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hwP2])
          hpy_mem hpairs1 rfl rfl henc_hdr2b
      refine ⟨mb, (DetExecAt.ite_true (C_c := 25) hct
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (hd2a.seq (hd2b.seq hd_unl))).mono_cost (by omega),
        hfpb, henc_hdrb,
        ((rfo_wWrite_scr _ _ _ _ _ _ _ _ m2 wYRP (y₀ : ℤ)).trans
          (rfo_wWrite_scr _ _ _ _ _ _ _ _ m2a wHasRP flagVal)).trans hfr_unl,
        fun w hw => by
          rw [hkWb w (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hscr02 w hw],
        by rw [hkWb wP (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
               wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hwP2],
        ?_⟩
      by_cases hyp : y₀ = p
      · left
        refine ⟨by dsimp [rP]; rw [hrP_eq, if_pos hyp], ?_⟩
        rw [hkWb wHasRP (by omega), wRead_wWrite_self]; dsimp [flagVal]; rw [if_pos hyp]
      · right
        refine ⟨y₀, hyp, hpy_mem, by dsimp [rP]; rw [hrP_eq, if_neg hyp], ?_, ?_⟩
        · rw [hkWb wHasRP (by omega), wRead_wWrite_self]; dsimp [flagVal]; rw [if_neg hyp]
        · rw [hkWb wYRP (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
    · have hno_py : ∀ y, (p, y) ∉ pairs := fun y hy => hmeq (hmL0_of p y hy).1
      have hrP_nil : rP = [] := rP_eq_nil_of_forall_not_pair hno_py
      have hpairs1_eq : st1.matchingList.map MatchingEdge.pair = pairs := by
        rw [hpairs1, List.filter_eq_self]
        intro xy hxy
        exact decide_eq_true (fun h1 => hno_py xy.2 (h1 ▸ hxy))
      have hcf : cValAt 0 inp m2 (.intEq (.readHeap tblW
          (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 3)) (.readHeap scrW (.lit wP))))
          (.readHeap scrW (.lit wEp))) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m2 tblW ((H3a.wRead m2 scrW wCfgBaseW + 3) + H3a.wRead m2 scrW wP) =
          H3a.wRead m2 scrW wEp) = false
        rw [hscr02 wCfgBaseW hwBW.2, hbW, hwP2, hwEp2, hmL2]
        exact decide_eq_false hmeq
      let m2a := H3a.wWrite m2 scrW wHasRP 0
      let mb := H3a.wWrite m2a scrW wYRP 0
      have hd2a : DetExec inp (.writeWordHeap scrW (.lit wHasRP) (.lit 0)) m2 m2a 15 :=
        DetExecAt.writeWordHeap 0 inp m2 scrW (.lit wHasRP) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd2b : DetExec inp (.writeWordHeap scrW (.lit wYRP) (.lit 0)) m2a mb 15 :=
        DetExecAt.writeWordHeap 0 inp m2a scrW (.lit wYRP) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have henc_hdrb : EncLocalMatching tblW cfgBaseW n st1 mb :=
        (henc_hdr2.mono_slice (fun i _ _ => by simp [mb, m2a, wRead_wWrite_of_ne _ _ (Or.inl hneW)])).congr_state
          hpairs1_eq rfl rfl
      refine ⟨mb, (DetExecAt.ite_false (C_c := 25) hcf
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (hd2a.seq hd2b)).mono_cost (by omega),
        InFootprint.wWrite (InFootprint.wWrite hfp2 hscrW (by omega) (by omega)) hscrW (by omega) (by omega),
        henc_hdrb,
        (rfo_wWrite_scr _ _ _ _ _ _ _ _ m2 wHasRP 0).trans (rfo_wWrite_scr _ _ _ _ _ _ _ _ m2a wYRP 0),
        fun w hw => by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hscr02 w hw],
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hwP2],
        Or.inl ⟨hrP_nil, by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]⟩⟩
  obtain ⟨mb, hdb, hfpb, henc_hdrb, hfr2b_H, hscrb, hwPb, hrP_info⟩ := hphase2
  rcases henc_hdrb with ⟨ep1, hep1_pos, hep1_r, hndL1, hndR1, hpairs_lt1, hUL_lt1, hUR_lt1,
    hdll1, hmL1_le, hmL1_to, hmL1_of, hmR1_le, hmR1_to, hmR1_of, hiL1, hiR1⟩
  have henc_hdrb' : EncLocalMatching tblW cfgBaseW n st1 mb :=
    ⟨ep1, hep1_pos, hep1_r, hndL1, hndR1, hpairs_lt1, hUL_lt1, hUR_lt1,
     hdll1, hmL1_le, hmL1_to, hmL1_of, hmR1_le, hmR1_to, hmR1_of, hiL1, hiR1⟩
  let mb1 := H3a.wWrite mb scrW wEp (ep1 : ℤ)
  have hdb1 : DetExec inp (.writeWordHeap scrW (.lit wEp)
      (.readHeap tblW (.readHeap scrW (.lit wCfgBaseW)))) mb mb1 25 :=
    DetExecAt.writeWordHeap 0 inp mb scrW (.lit wEp) _ rfl
      (by change H3a.wRead mb tblW (H3a.wRead mb scrW wCfgBaseW) = (ep1 : ℤ)
          rw [hscrb wCfgBaseW hwBW.2, hbW]; exact hep1_r)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfpb1 : InFootprint TW BW TR BR mb1 := InFootprint.wWrite hfpb hscrW (by omega) (by omega)
  let st2 : LocalMatchingState ℕ :=
    { st with matchingList := (removeCopiesFromState st p).matchingList }
  have hphase3 : ∃ mc : ArithRAMMemory,
      DetExec inp (.ite (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 2 * (n : ℤ))))
                                                      (.readHeap scrW (.lit wP))))
                                (.readHeap scrW (.lit wEp)))
        (.seq (.writeWordHeap scrW (.lit wXLP)
                (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 3 * (n : ℤ))))
                                      (.readHeap scrW (.lit wP)))))
        (.seq (.writeWordHeap scrW (.lit wHasLP) (.lit 1))
              (unlinkLeftKeyStmt scrW tblW n wCfgBaseW wXLP wSub)))
        (.seq (.writeWordHeap scrW (.lit wHasLP) (.lit 0))
              (.writeWordHeap scrW (.lit wXLP) (.lit 0))))
        mb1 mc (100 + unlinkLeftKeyCost) ∧
      InFootprint TW BW TR BR mc ∧
      EncLocalMatching tblW cfgBaseW n st2 mc ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 mb1 mc ∧
      (∀ w, w < wSub → w ≠ wHasLP → w ≠ wXLP → H3a.wRead mc scrW w = H3a.wRead mb1 scrW w) ∧
      ((lP = [] ∧ H3a.wRead mc scrW wHasLP = 0) ∨
       (∃ x₀ : ℕ, x₀ ≠ p ∧ (x₀, p) ∈ pairs ∧ lP = [⟨.left, x₀⟩] ∧
         H3a.wRead mc scrW wHasLP = 1 ∧ H3a.wRead mc scrW wXLP = (x₀ : ℤ))) := by
    have hmR_b1 : H3a.wRead mb1 tblW ((cfgBaseW + (3 + 2 * (n : ℤ))) + (p : ℤ)) =
        H3a.wRead mb tblW (cfgMateREpOff cfgBaseW n p) := by
      rw [show (cfgBaseW + (3 + 2 * (n : ℤ))) + (p : ℤ) = cfgMateREpOff cfgBaseW n p by
            unfold cfgMateREpOff; ring,
          wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    by_cases hmeq : H3a.wRead mb tblW (cfgMateREpOff cfgBaseW n p) = (ep1 : ℤ)
    · obtain ⟨x₀, hxp1_mem, hmRVal1⟩ := hmR1_to p hp_lt hmeq
      have hxp1_filt : (x₀, p) ∈ pairs.filter (fun xy => decide (xy.1 ≠ p)) := hpairs1 ▸ hxp1_mem
      obtain ⟨hx_ne, hxp_mem, hlP_eq, hpairs2_eq⟩ := lP_eq_of_mem_pair1 hndL0 hndR0 hxp1_filt
      have hpairs2_st2 : st2.matchingList.map MatchingEdge.pair =
          (st1.matchingList.map MatchingEdge.pair).filter (fun xy => decide (xy.1 ≠ x₀)) := by
        dsimp only [st2]
        rw [removeCopiesFromState_matchingList_eq, hpairs1, hpairs2_eq]
      have hct : cValAt 0 inp mb1 (.intEq (.readHeap tblW
          (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 2 * (n : ℤ))))
                (.readHeap scrW (.lit wP))))
          (.readHeap scrW (.lit wEp))) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead mb1 tblW ((H3a.wRead mb1 scrW wCfgBaseW + (3 + 2 * (n : ℤ))) +
          H3a.wRead mb1 scrW wP) = H3a.wRead mb1 scrW wEp) = true
        have hb1_bw : H3a.wRead mb1 scrW wCfgBaseW = cfgBaseW :=
          (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans ((hscrb wCfgBaseW hwBW.2).trans hbW)
        have hb1_p : H3a.wRead mb1 scrW wP = (p : ℤ) :=
          (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hwPb
        have hb1_ep : H3a.wRead mb1 scrW wEp = (ep1 : ℤ) := wRead_wWrite_self _ _ _ _
        rw [hb1_bw, hb1_p, hb1_ep, hmR_b1, hmeq]; exact decide_eq_true rfl
      let mc1 := H3a.wWrite mb1 scrW wXLP (x₀ : ℤ)
      let mc2 := H3a.wWrite mc1 scrW wHasLP 1
      have hdc1 : DetExec inp (.writeWordHeap scrW (.lit wXLP)
          (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 3 * (n : ℤ))))
                                (.readHeap scrW (.lit wP))))) mb1 mc1 35 :=
        DetExecAt.writeWordHeap 0 inp mb1 scrW (.lit wXLP) _ rfl
          (by change H3a.wRead mb1 tblW ((H3a.wRead mb1 scrW wCfgBaseW + (3 + 3 * (n : ℤ))) +
                H3a.wRead mb1 scrW wP) = (x₀ : ℤ)
              rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hscrb wCfgBaseW hwBW.2, hbW,
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hwPb,
                  show (cfgBaseW + (3 + 3 * (n : ℤ))) + (p : ℤ) = cfgMateRValOff cfgBaseW n p by
                    unfold cfgMateRValOff; ring]
              exact hmRVal1)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hdc2 : DetExec inp (.writeWordHeap scrW (.lit wHasLP) (.lit 1)) mc1 mc2 15 :=
        DetExecAt.writeWordHeap 0 inp mc1 scrW (.lit wHasLP) (.lit 1) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfpc2 : InFootprint TW BW TR BR mc2 :=
        InFootprint.wWrite (InFootprint.wWrite hfpb1 hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
      have henc_hdrc2 : EncLocalMatching tblW cfgBaseW n st1 mc2 :=
        henc_hdrb'.mono_slice (fun i _ _ => by simp [mc2, mc1, mb1, wRead_wWrite_of_ne _ _ (Or.inl hneW)])
      obtain ⟨mc, hd_unl, hfpc, henc_hdrc, hkWc, hfr_unl⟩ :=
        exec_unlinkLeftKeyStmt (tblR := tblR) (coinTbl := coinTbl) inp
          wCfgBaseW wXLP wSub cfgBaseW cfgBaseR (st := st1) (st' := st2)
          hfpc2 hvt hbaseW
          ⟨hwBW.1, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hscrb wCfgBaseW hwBW.2, hbW])
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
          hxp1_mem hpairs2_st2 rfl rfl henc_hdrc2
      refine ⟨mc, (DetExecAt.ite_true (C_c := 25) hct
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (hdc1.seq (hdc2.seq hd_unl))).mono_cost (by omega),
        hfpc, henc_hdrc,
        ((rfo_wWrite_scr _ _ _ _ _ _ _ _ mb1 wXLP (x₀ : ℤ)).trans
          (rfo_wWrite_scr _ _ _ _ _ _ _ _ mc1 wHasLP 1)).trans hfr_unl,
        fun w hw hne1 hne2 => by
          rw [hkWc w hw, wRead_wWrite_of_ne _ _ (Or.inr hne1), wRead_wWrite_of_ne _ _ (Or.inr hne2)],
        Or.inr ⟨x₀, hx_ne, hxp_mem, hlP_eq,
          by rw [hkWc wHasLP (by omega), wRead_wWrite_self],
          by rw [hkWc wXLP (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]⟩⟩
    · have hno_xp1 : ∀ x, (x, p) ∉ pairs.filter (fun xy => decide (xy.1 ≠ p)) :=
        fun x hx => hmeq (hmR1_of x p (hpairs1.symm ▸ hx)).1
      obtain ⟨hlP_nil, hpairs2_eq⟩ := lP_eq_nil_of_forall_not_pair1 hno_xp1
      have hpairs_st2 : st2.matchingList.map MatchingEdge.pair = st1.matchingList.map MatchingEdge.pair := by
        dsimp only [st2]
        rw [removeCopiesFromState_matchingList_eq, hpairs1, hpairs2_eq]
      have hcf : cValAt 0 inp mb1 (.intEq (.readHeap tblW
          (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 2 * (n : ℤ))))
                (.readHeap scrW (.lit wP))))
          (.readHeap scrW (.lit wEp))) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead mb1 tblW ((H3a.wRead mb1 scrW wCfgBaseW + (3 + 2 * (n : ℤ))) +
          H3a.wRead mb1 scrW wP) = H3a.wRead mb1 scrW wEp) = false
        have hb1_bw : H3a.wRead mb1 scrW wCfgBaseW = cfgBaseW :=
          (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans ((hscrb wCfgBaseW hwBW.2).trans hbW)
        have hb1_p : H3a.wRead mb1 scrW wP = (p : ℤ) :=
          (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hwPb
        have hb1_ep : H3a.wRead mb1 scrW wEp = (ep1 : ℤ) := wRead_wWrite_self _ _ _ _
        rw [hb1_bw, hb1_p, hb1_ep, hmR_b1]
        exact decide_eq_false hmeq
      let mc1 := H3a.wWrite mb1 scrW wHasLP 0
      let mc := H3a.wWrite mc1 scrW wXLP 0
      have hdc1 : DetExec inp (.writeWordHeap scrW (.lit wHasLP) (.lit 0)) mb1 mc1 15 :=
        DetExecAt.writeWordHeap 0 inp mb1 scrW (.lit wHasLP) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hdc2 : DetExec inp (.writeWordHeap scrW (.lit wXLP) (.lit 0)) mc1 mc 15 :=
        DetExecAt.writeWordHeap 0 inp mc1 scrW (.lit wXLP) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have henc_hdrc : EncLocalMatching tblW cfgBaseW n st2 mc :=
        (henc_hdrb'.mono_slice (fun i _ _ => by simp [mc, mc1, mb1, wRead_wWrite_of_ne _ _ (Or.inl hneW)])).congr_state
          hpairs_st2 rfl rfl
      refine ⟨mc, (DetExecAt.ite_false (C_c := 25) hcf
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (hdc1.seq hdc2)).mono_cost (by omega),
        InFootprint.wWrite (InFootprint.wWrite hfpb1 hscrW (by omega) (by omega)) hscrW (by omega) (by omega),
        henc_hdrc,
        (rfo_wWrite_scr _ _ _ _ _ _ _ _ mb1 wHasLP 0).trans (rfo_wWrite_scr _ _ _ _ _ _ _ _ mc1 wXLP 0),
        fun w _ hne1 hne2 => by
          rw [wRead_wWrite_of_ne _ _ (Or.inr hne2), wRead_wWrite_of_ne _ _ (Or.inr hne1)],
        Or.inl ⟨hlP_nil, by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]⟩⟩
  obtain ⟨mc, hdc, hfpc, henc_hdrc, hfrb1c_H, hkWc, hlP_info⟩ := hphase3
  have hscrc : ∀ w, w < wScr → H3a.wRead mc scrW w = H3a.wRead m₀ scrW w :=
    fun w hw => (hkWc w (by omega) (by omega) (by omega)).trans
      ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hscrb w hw))
  have hwPc : H3a.wRead mc scrW wP = (p : ℤ) :=
    (hkWc wP (by omega) (by omega) (by omega)).trans
      ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hwPb)
  have hrP_mc :
      (rP = [] ∧ H3a.wRead mc scrW wHasRP = 0) ∨
      (∃ y₀ : ℕ, y₀ ≠ p ∧ (p, y₀) ∈ pairs ∧ rP = [⟨.right, y₀⟩] ∧
        H3a.wRead mc scrW wHasRP = 1 ∧ H3a.wRead mc scrW wYRP = (y₀ : ℤ)) := by
    rcases hrP_info with ⟨hr, hh⟩ | ⟨y₀, hne, hmem, hr, hh, hy⟩
    · left
      exact ⟨hr, (hkWc wHasRP (by omega) (by omega) (by omega)).trans
        ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hh)⟩
    · right
      exact ⟨y₀, hne, hmem, hr,
        (hkWc wHasRP (by omega) (by omega) (by omega)).trans
          ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hh),
        (hkWc wYRP (by omega) (by omega) (by omega)).trans
          ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hy)⟩
  let st3 : LocalMatchingState ℕ :=
    { st2 with leftUnmatchedIndex := (removeCopiesFromState st p).leftUnmatchedIndex }
  let md1 := H3a.wWrite mc tblW (cfgInIdxLEpOff cfgBaseW n p) 0
  let md := H3a.wWrite md1 tblW (cfgInIdxREpOff cfgBaseW n p) 0
  have hdd1 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 4 * (n : ℤ))))
            (.readHeap scrW (.lit wP))) (.lit 0)) mc md1 35 :=
    DetExecAt.writeWordHeap 0 inp mc tblW _ (.lit 0)
      (by change (H3a.wRead mc scrW wCfgBaseW + (3 + 4 * (n : ℤ))) + H3a.wRead mc scrW wP =
            cfgInIdxLEpOff cfgBaseW n p
          rw [hscrc wCfgBaseW hwBW.2, hbW, hwPc]; unfold cfgInIdxLEpOff; ring)
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hdd2 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + 5 * (n : ℤ))))
            (.readHeap scrW (.lit wP))) (.lit 0)) md1 md 35 :=
    DetExecAt.writeWordHeap 0 inp md1 tblW _ (.lit 0)
      (by change (H3a.wRead md1 scrW wCfgBaseW + (3 + 5 * (n : ℤ))) + H3a.wRead md1 scrW wP =
            cfgInIdxREpOff cfgBaseW n p
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hscrc wCfgBaseW hwBW.2, hbW,
              wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hwPc]
          unfold cfgInIdxREpOff; ring)
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have henc_hdrd1 : EncLocalMatching tblW cfgBaseW n st3 md1 :=
    henc_hdrc.write_inIdxL_zero p hp_lt rfl
      (by simpa [st3, st2] using leftIndexSet_removeCopies_eq st p) rfl
  have henc_hdrd : EncLocalMatching tblW cfgBaseW n (removeCopiesFromState st p) md :=
    henc_hdrd1.write_inIdxR_zero p hp_lt rfl rfl
      (by simpa [st3, st2] using rightIndexSet_removeCopies_eq st p)
  have hfpd : InFootprint TW BW TR BR md := by
    unfold cfgHdrWStride at hbaseW
    exact InFootprint.wWrite
      (InFootprint.wWrite hfpc htblW (by unfold cfgInIdxLEpOff; omega) (by unfold cfgInIdxLEpOff; omega))
      htblW (by unfold cfgInIdxREpOff; omega) (by unfold cfgInIdxREpOff; omega)
  have hfr0d : RadFrameOutside scrW scrR tblW cfgBaseW (cfgHdrWStride n) tblR cfgBaseR 0 m₀ md :=
    ((((hfr02.trans hfr2b_H).trans
       (rfo_wWrite_scr _ _ _ _ _ _ _ _ mb wEp (ep1 : ℤ))).trans hfrb1c_H).trans
       (rfo_wWrite_in _ _ _ _ _ _ _ _ mc 0
         (by unfold cfgInIdxLEpOff; omega) (by unfold cfgInIdxLEpOff cfgHdrWStride; omega))).trans
       (rfo_wWrite_in _ _ _ _ _ _ _ _ md1 0
         (by unfold cfgInIdxREpOff; omega) (by unfold cfgInIdxREpOff cfgHdrWStride; omega))
  have hd_all : DetExec inp (configDynRemoveHdrStmt scrW tblW n wCfgBaseW wUid wScr)
      m₀ md configDynRemoveHdrCost :=
    (hd1.seq (hd2.seq (hdb.seq (hdb1.seq (hdc.seq (hdd1.seq hdd2)))))).mono_cost
      (by unfold configDynRemoveHdrCost; omega)
  have hmd_mc : ∀ w, H3a.wRead md scrW w = H3a.wRead mc scrW w :=
    fun w => (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm))
  refine ⟨md, hd_all, hfpd, henc_hdrd,
    fun w hw => (hmd_mc w).trans (hscrc w hw),
    (hmd_mc wP).trans hwPc, hfr0d, ?_, ?_⟩
  · rcases hrP_mc with ⟨hr, hh⟩ | ⟨y₀, hne, hmem, hr, hh, hy⟩
    · left; exact ⟨hr, (hmd_mc wHasRP).trans hh⟩
    · right; exact ⟨y₀, hne, hmem, hr, (hmd_mc wHasRP).trans hh, (hmd_mc wYRP).trans hy⟩
  · rcases hlP_info with ⟨hl, hh⟩ | ⟨x₀, hne, hmem, hl, hh, hx⟩
    · left; exact ⟨hl, (hmd_mc wHasLP).trans hh⟩
    · right; exact ⟨x₀, hne, hmem, hl, (hmd_mc wHasLP).trans hh, (hmd_mc wXLP).trans hx⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
