import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H3b2_GaussRAM
import UL.Proof.cit_hpj19_thm18.H4
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H3b3

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2

/-! ### 1. Syntactic purity check & `.localScope` relocation of `hpjProg` -/

def isPureHPJInt : IntExpr → Bool
  | .lit _ | .dim => true
  | .readHeap t e => decide (t < 6) && isPureHPJInt e
  | .neg e => isPureHPJInt e
  | .add e₁ e₂ | .sub e₁ e₂ | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ =>
      isPureHPJInt e₁ && isPureHPJInt e₂
  | _ => false

def isPureHPJReal : RealExpr → Bool
  | .ofInt e => isPureHPJInt e
  | .readRealHeap t e => decide (t < 6) && isPureHPJInt e
  | .extraReal (.lit 0) => true
  | .neg r => isPureHPJReal r
  | .add r₁ r₂ | .sub r₁ r₂ | .mul r₁ r₂ | .div r₁ r₂ => isPureHPJReal r₁ && isPureHPJReal r₂
  | _ => false

def isPureHPJCond : ArithCondExpr → Bool
  | .intEq e₁ e₂ | .intLt e₁ e₂ | .intLe e₁ e₂ => isPureHPJInt e₁ && isPureHPJInt e₂
  | .realEq r₁ r₂ | .realLt r₁ r₂ | .realLe r₁ r₂ => isPureHPJReal r₁ && isPureHPJReal r₂
  | .not c => isPureHPJCond c
  | .and c₁ c₂ | .or c₁ c₂ => isPureHPJCond c₁ && isPureHPJCond c₂

def isPureHPJStmt : ArithRAMStmt → Bool
  | .skip => true
  | .writeWordHeap t dstE (.intParam idxE) =>
      decide (t < 6) && isPureHPJInt dstE && isPureHPJInt idxE
  | .writeWordHeap t dstE valE =>
      decide (t < 6) && isPureHPJInt dstE && isPureHPJInt valE
  | .writeRealHeap t dstE (.activePtCoord hE cE) =>
      decide (t < 6) && isPureHPJInt dstE && isPureHPJInt hE && isPureHPJInt cE
  | .writeRealHeap t dstE valE =>
      decide (t < 6) && isPureHPJInt dstE && isPureHPJReal valE
  | .randBitHeap t dstE =>
      decide (t < 6) && isPureHPJInt dstE
  | .seq s₁ s₂ => isPureHPJStmt s₁ && isPureHPJStmt s₂
  | .ite c s₁ s₂ => isPureHPJCond c && isPureHPJStmt s₁ && isPureHPJStmt s₂
  | .whileLoop c body => isPureHPJCond c && isPureHPJStmt body
  | .repeatN cntE body => isPureHPJInt cntE && isPureHPJStmt body
  | _ => false

theorem isPureHPJStmt_hpjProg : isPureHPJStmt hpjProg = true := by decide

def relocInt : IntExpr → IntExpr
  | .lit c => .lit c
  | .dim => .dim
  | .readHeap t e => .readLocal (t + 1) (relocInt e)
  | .neg e => .neg (relocInt e)
  | .add e₁ e₂ => .add (relocInt e₁) (relocInt e₂)
  | .sub e₁ e₂ => .sub (relocInt e₁) (relocInt e₂)
  | .mul e₁ e₂ => .mul (relocInt e₁) (relocInt e₂)
  | .div e₁ e₂ => .div (relocInt e₁) (relocInt e₂)
  | .mod e₁ e₂ => .mod (relocInt e₁) (relocInt e₂)
  | _ => .lit 0

def relocReal (phiRat : ℚ) : RealExpr → RealExpr
  | .ofInt e => .ofInt (relocInt e)
  | .readRealHeap t e => .readRealLocal (t + 1) (relocInt e)
  | .extraReal (.lit 0) => ratExpr phiRat
  | .neg r => .neg (relocReal phiRat r)
  | .add r₁ r₂ => .add (relocReal phiRat r₁) (relocReal phiRat r₂)
  | .sub r₁ r₂ => .sub (relocReal phiRat r₁) (relocReal phiRat r₂)
  | .mul r₁ r₂ => .mul (relocReal phiRat r₁) (relocReal phiRat r₂)
  | .div r₁ r₂ => .div (relocReal phiRat r₁) (relocReal phiRat r₂)
  | _ => .ofInt (.lit 0)

def relocCond (phiRat : ℚ) : ArithCondExpr → ArithCondExpr
  | .intEq e₁ e₂ => .intEq (relocInt e₁) (relocInt e₂)
  | .intLt e₁ e₂ => .intLt (relocInt e₁) (relocInt e₂)
  | .intLe e₁ e₂ => .intLe (relocInt e₁) (relocInt e₂)
  | .realEq r₁ r₂ => .realEq (relocReal phiRat r₁) (relocReal phiRat r₂)
  | .realLt r₁ r₂ => .realLt (relocReal phiRat r₁) (relocReal phiRat r₂)
  | .realLe r₁ r₂ => .realLe (relocReal phiRat r₁) (relocReal phiRat r₂)
  | .not c => .not (relocCond phiRat c)
  | .and c₁ c₂ => .and (relocCond phiRat c₁) (relocCond phiRat c₂)
  | .or c₁ c₂ => .or (relocCond phiRat c₁) (relocCond phiRat c₂)

def relocStmt (tblSamp tblPts tblCoins : ℕ) (offSamp offPts offCoins : ℤ)
    (N_samp sz : ℕ) (phiRat : ℚ) : ArithRAMStmt → ArithRAMStmt
  | .skip => .skip
  | .writeWordHeap t dstE (.intParam idxE) =>
      let rDst := relocInt dstE
      let rIdx := relocInt idxE
      .ite (.and (.intLe (.lit 0) rIdx) (.intLt rIdx (.lit (N_samp : ℤ))))
        (.writeWordLocal (t + 1) rDst (.readHeap tblSamp (.add (.lit offSamp) rIdx)))
        (.writeWordLocal (t + 1) rDst (.lit 0))
  | .writeWordHeap t dstE valE =>
      .writeWordLocal (t + 1) (relocInt dstE) (relocInt valE)
  | .writeRealHeap t dstE (.activePtCoord hE cE) =>
      let rDst := relocInt dstE
      let rH := relocInt hE
      let rC := relocInt cE
      .ite (.and (.and (.intLe (.lit 0) rH) (.intLt rH (.lit (sz : ℤ))))
                 (.and (.intLe (.lit 0) rC) (.intLt rC .dim)))
        (.writeRealLocal (t + 1) rDst
          (.readRealHeap tblPts (.add (.lit offPts) (.add (.mul rH .dim) rC))))
        (.writeRealLocal (t + 1) rDst (.ofInt (.lit 0)))
  | .writeRealHeap t dstE valE =>
      .writeRealLocal (t + 1) (relocInt dstE) (relocReal phiRat valE)
  | .randBitHeap t dstE =>
      .seq
        (.writeWordLocal (t + 1) (relocInt dstE)
          (.readHeap tblCoins (.add (.lit offCoins) (.readLocal 0 (.lit 0)))))
        (.writeWordLocal 0 (.lit 0) (.add (.readLocal 0 (.lit 0)) (.lit 1)))
  | .seq s₁ s₂ =>
      .seq (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s₁)
           (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s₂)
  | .ite c s₁ s₂ =>
      .ite (relocCond phiRat c)
        (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s₁)
        (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s₂)
  | .whileLoop c body =>
      .whileLoop (relocCond phiRat c)
        (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat body)
  | .repeatN cntE body =>
      .repeatN (relocInt cntE)
        (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat body)
  | _ => .skip

def embedHPJStmt (scrR tblSamp tblPts tblCoins : ℕ)
    (outOff offSamp offPts offCoins : ℤ) (N_samp sz : ℕ) (phiRat : ℚ) : ArithRAMStmt :=
  .localScope
    (.seq (.writeWordLocal 0 (.lit 0) (.lit 0))
    (.seq (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat hpjProg)
    (.seq (.writeWordLocal 0 (.lit 1) (.lit 0))
          (.repeatN (.add .dim (.lit 1))
            (.seq
              (.writeRealHeap scrR (.add (.lit outOff) (.readLocal 0 (.lit 1)))
                (.readRealLocal 1 (.readLocal 0 (.lit 1))))
              (.writeWordLocal 0 (.lit 1) (.add (.readLocal 0 (.lit 1)) (.lit 1))))))))

/-! ### 2. Expression evaluation agreement & cost bounds -/

private lemma intExprOps_pos : ∀ e : IntExpr, 1 ≤ intExprOps e
  | .lit _ | .dim => le_rfl
  | .intParam e | .readHeap _ e | .readLocal _ e | .extraRatNum e | .extraRatDen e | .neg e => by
      dsimp [intExprOps]; omega
  | .activeRatNum e₁ e₂ | .activeRatDen e₁ e₂ | .add e₁ e₂ | .sub e₁ e₂
  | .mul e₁ e₂ | .div e₁ e₂ | .mod e₁ e₂ => by
      dsimp [intExprOps]; omega

private lemma realExprOps_pos : ∀ r : RealExpr, 1 ≤ realExprOps r
  | .ofInt _ | .readRealHeap _ _ | .readRealLocal _ _ | .extraReal _ | .activePtCoord _ _ => by
      dsimp [realExprOps]; omega
  | .neg r => by dsimp [realExprOps]; omega
  | .add _ _ | .sub _ _ | .mul _ _ | .div _ _ => by dsimp [realExprOps]; omega

private lemma intExprOps_reloc : ∀ e : IntExpr, isPureHPJInt e = true →
    intExprOps (relocInt e) = intExprOps e
  | .lit _, _ | .dim, _ => rfl
  | .readHeap t e, hp => by
      simp only [isPureHPJInt, Bool.and_eq_true] at hp
      simp [relocInt, intExprOps, intExprOps_reloc e hp.2]
  | .neg e, hp => by
      simp only [isPureHPJInt] at hp
      simp [relocInt, intExprOps, intExprOps_reloc e hp]
  | .add e₁ e₂, hp | .sub e₁ e₂, hp | .mul e₁ e₂, hp | .div e₁ e₂, hp | .mod e₁ e₂, hp => by
      simp only [isPureHPJInt, Bool.and_eq_true] at hp
      simp [relocInt, intExprOps, intExprOps_reloc e₁ hp.1, intExprOps_reloc e₂ hp.2]
  | .intParam _, hp | .readLocal _ _, hp | .activeRatNum _ _, hp | .activeRatDen _ _, hp
  | .extraRatNum _, hp | .extraRatDen _, hp => by simp [isPureHPJInt] at hp

private lemma realExprOps_reloc (phiRat : ℚ) : ∀ r : RealExpr, isPureHPJReal r = true →
    realExprOps (relocReal phiRat r) ≤ 3 * realExprOps r
  | .ofInt e, hp => by
      simp only [isPureHPJReal] at hp
      have he := intExprOps_reloc e hp
      dsimp [relocReal, realExprOps]; omega
  | .readRealHeap t e, hp => by
      simp only [isPureHPJReal, Bool.and_eq_true] at hp
      have he := intExprOps_reloc e hp.2
      dsimp [relocReal, realExprOps]; omega
  | .extraReal e, hp => by
      cases e with
      | lit c =>
          by_cases hc : c = 0
          · subst hc; rw [relocReal, realExprOps_ratExpr]; dsimp [realExprOps, intExprOps]; omega
          · simp [isPureHPJReal, hc] at hp
      | _ => simp [isPureHPJReal] at hp
  | .neg r, hp => by
      simp only [isPureHPJReal] at hp
      have hr := realExprOps_reloc phiRat r hp
      dsimp [relocReal, realExprOps]; omega
  | .add r₁ r₂, hp | .sub r₁ r₂, hp | .mul r₁ r₂, hp | .div r₁ r₂, hp => by
      simp only [isPureHPJReal, Bool.and_eq_true] at hp
      have h₁ := realExprOps_reloc phiRat r₁ hp.1
      have h₂ := realExprOps_reloc phiRat r₂ hp.2
      dsimp [relocReal, realExprOps]; omega
  | .readRealLocal _ _, hp | .activePtCoord _ _, hp => by simp [isPureHPJReal] at hp

private lemma condExprOps_reloc (phiRat : ℚ) : ∀ c : ArithCondExpr, isPureHPJCond c = true →
    condExprOps (relocCond phiRat c) ≤ 3 * condExprOps c
  | .intEq e₁ e₂, hp | .intLt e₁ e₂, hp | .intLe e₁ e₂, hp => by
      simp only [isPureHPJCond, Bool.and_eq_true] at hp
      have h₁ := intExprOps_reloc e₁ hp.1
      have h₂ := intExprOps_reloc e₂ hp.2
      dsimp [relocCond, condExprOps]; omega
  | .realEq r₁ r₂, hp | .realLt r₁ r₂, hp | .realLe r₁ r₂, hp => by
      simp only [isPureHPJCond, Bool.and_eq_true] at hp
      have h₁ := realExprOps_reloc phiRat r₁ hp.1
      have h₂ := realExprOps_reloc phiRat r₂ hp.2
      dsimp [relocCond, condExprOps]; omega
  | .not c, hp => by
      simp only [isPureHPJCond] at hp
      have hc := condExprOps_reloc phiRat c hp
      dsimp [relocCond, condExprOps]; omega
  | .and c₁ c₂, hp | .or c₁ c₂, hp => by
      simp only [isPureHPJCond, Bool.and_eq_true] at hp
      have h₁ := condExprOps_reloc phiRat c₁ hp.1
      have h₂ := condExprOps_reloc phiRat c₂ hp.2
      dsimp [relocCond, condExprOps]; omega

private lemma relocInt_val {d : ℕ} (mainInp fakeInp : ArithRAMInput d)
    (mainMem hpjMem : ArithRAMMemory)
    (hwords : ∀ t < 6, ∀ i, mainMem.words.read (.localFrame 1 (t + 1) i) = hpjMem.words.read (.heap t i)) :
    ∀ e : IntExpr, isPureHPJInt e = true →
      (evalIntExpr mainInp.toWordView 1 mainMem.words (relocInt e)).1 =
        (evalIntExpr fakeInp.toWordView 0 hpjMem.words e).1
  | .lit _, _ | .dim, _ => rfl
  | .readHeap t e, hp => by
      simp only [isPureHPJInt, Bool.and_eq_true, decide_eq_true_eq] at hp
      have hv := relocInt_val mainInp fakeInp mainMem hpjMem hwords e hp.2
      simp [relocInt, evalIntExpr, hv, hwords t hp.1]
  | .neg e, hp => by
      simp only [isPureHPJInt] at hp
      simp [relocInt, evalIntExpr, relocInt_val mainInp fakeInp mainMem hpjMem hwords e hp]
  | .add e₁ e₂, hp | .sub e₁ e₂, hp | .mul e₁ e₂, hp | .div e₁ e₂, hp | .mod e₁ e₂, hp => by
      simp only [isPureHPJInt, Bool.and_eq_true] at hp
      simp [relocInt, evalIntExpr,
        relocInt_val mainInp fakeInp mainMem hpjMem hwords e₁ hp.1,
        relocInt_val mainInp fakeInp mainMem hpjMem hwords e₂ hp.2]
  | .intParam _, hp | .readLocal _ _, hp | .activeRatNum _ _, hp | .activeRatDen _ _, hp
  | .extraRatNum _, hp | .extraRatDen _, hp => by simp [isPureHPJInt] at hp

private lemma relocInt_eval {d : ℕ} (mainInp fakeInp : ArithRAMInput d)
    (mainMem hpjMem : ArithRAMMemory)
    (hwords : ∀ t < 6, ∀ i, mainMem.words.read (.localFrame 1 (t + 1) i) = hpjMem.words.read (.heap t i))
    (e : IntExpr) (hp : isPureHPJInt e = true) :
    (evalIntExpr mainInp.toWordView 1 mainMem.words (relocInt e)).1 =
      (evalIntExpr fakeInp.toWordView 0 hpjMem.words e).1 ∧
    (evalIntExpr mainInp.toWordView 1 mainMem.words (relocInt e)).2.1 =
      (evalIntExpr fakeInp.toWordView 0 hpjMem.words e).2.1 :=
  ⟨relocInt_val mainInp fakeInp mainMem hpjMem hwords e hp, by
    rw [evalIntExpr_ops, evalIntExpr_ops, intExprOps_reloc e hp]⟩

private lemma relocReal_val {d : ℕ} (mainInp fakeInp : ArithRAMInput d)
    (phiRat : ℚ) (hextra : fakeInp.extraReals = [(phiRat : ℝ)])
    (mainMem hpjMem : ArithRAMMemory)
    (hwords : ∀ t < 6, ∀ i, mainMem.words.read (.localFrame 1 (t + 1) i) = hpjMem.words.read (.heap t i))
    (hreals : ∀ t < 6, ∀ i, mainMem.reals.read (.localFrame 1 (t + 1) i) = hpjMem.reals.read (.heap t i)) :
    ∀ r : RealExpr, isPureHPJReal r = true →
      (evalRealExpr mainInp 1 mainMem (relocReal phiRat r)).1 =
        (evalRealExpr fakeInp 0 hpjMem r).1
  | .ofInt e, hp => by
      simp only [isPureHPJReal] at hp
      simp [relocReal, evalRealExpr, relocInt_val mainInp fakeInp mainMem hpjMem hwords e hp]
  | .readRealHeap t e, hp => by
      simp only [isPureHPJReal, Bool.and_eq_true, decide_eq_true_eq] at hp
      simp [relocReal, evalRealExpr, relocInt_val mainInp fakeInp mainMem hpjMem hwords e hp.2, hreals t hp.1]
  | .extraReal e, hp => by
      cases e with
      | lit c =>
          by_cases hc : c = 0
          · subst hc
            rw [relocReal, evalRealExpr_ratExpr]
            simp [evalRealExpr, evalIntExpr, hextra, listGetIntD]
          · simp [isPureHPJReal, hc] at hp
      | _ => simp [isPureHPJReal] at hp
  | .neg r, hp => by
      simp only [isPureHPJReal] at hp
      simp [relocReal, evalRealExpr, relocReal_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals r hp]
  | .add r₁ r₂, hp | .sub r₁ r₂, hp | .mul r₁ r₂, hp | .div r₁ r₂, hp => by
      simp only [isPureHPJReal, Bool.and_eq_true] at hp
      simp [relocReal, evalRealExpr,
        relocReal_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals r₁ hp.1,
        relocReal_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals r₂ hp.2]
  | .readRealLocal _ _, hp | .activePtCoord _ _, hp => by simp [isPureHPJReal] at hp

private lemma relocReal_eval {d : ℕ} (mainInp fakeInp : ArithRAMInput d)
    (phiRat : ℚ) (hextra : fakeInp.extraReals = [(phiRat : ℝ)])
    (mainMem hpjMem : ArithRAMMemory)
    (hwords : ∀ t < 6, ∀ i, mainMem.words.read (.localFrame 1 (t + 1) i) = hpjMem.words.read (.heap t i))
    (hreals : ∀ t < 6, ∀ i, mainMem.reals.read (.localFrame 1 (t + 1) i) = hpjMem.reals.read (.heap t i))
    (r : RealExpr) (hp : isPureHPJReal r = true) :
    (evalRealExpr mainInp 1 mainMem (relocReal phiRat r)).1 =
      (evalRealExpr fakeInp 0 hpjMem r).1 ∧
    (evalRealExpr mainInp 1 mainMem (relocReal phiRat r)).2 ≤
      3 * (evalRealExpr fakeInp 0 hpjMem r).2 :=
  ⟨relocReal_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals r hp, by
    rw [evalRealExpr_ops, evalRealExpr_ops]
    exact realExprOps_reloc phiRat r hp⟩

private lemma relocCond_val {d : ℕ} (mainInp fakeInp : ArithRAMInput d)
    (phiRat : ℚ) (hextra : fakeInp.extraReals = [(phiRat : ℝ)])
    (mainMem hpjMem : ArithRAMMemory)
    (hwords : ∀ t < 6, ∀ i, mainMem.words.read (.localFrame 1 (t + 1) i) = hpjMem.words.read (.heap t i))
    (hreals : ∀ t < 6, ∀ i, mainMem.reals.read (.localFrame 1 (t + 1) i) = hpjMem.reals.read (.heap t i)) :
    ∀ c : ArithCondExpr, isPureHPJCond c = true →
      (evalArithCond mainInp 1 mainMem (relocCond phiRat c)).1 =
        (evalArithCond fakeInp 0 hpjMem c).1
  | .intEq e₁ e₂, hp | .intLt e₁ e₂, hp | .intLe e₁ e₂, hp => by
      simp only [isPureHPJCond, Bool.and_eq_true] at hp
      simp [relocCond, evalArithCond,
        relocInt_val mainInp fakeInp mainMem hpjMem hwords e₁ hp.1,
        relocInt_val mainInp fakeInp mainMem hpjMem hwords e₂ hp.2]
  | .realEq r₁ r₂, hp | .realLt r₁ r₂, hp | .realLe r₁ r₂, hp => by
      simp only [isPureHPJCond, Bool.and_eq_true] at hp
      simp [relocCond, evalArithCond,
        relocReal_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals r₁ hp.1,
        relocReal_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals r₂ hp.2]
  | .not c, hp => by
      simp only [isPureHPJCond] at hp
      simp [relocCond, evalArithCond, relocCond_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals c hp]
  | .and c₁ c₂, hp | .or c₁ c₂, hp => by
      simp only [isPureHPJCond, Bool.and_eq_true] at hp
      simp [relocCond, evalArithCond,
        relocCond_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals c₁ hp.1,
        relocCond_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals c₂ hp.2]

private lemma relocCond_eval {d : ℕ} (mainInp fakeInp : ArithRAMInput d)
    (phiRat : ℚ) (hextra : fakeInp.extraReals = [(phiRat : ℝ)])
    (mainMem hpjMem : ArithRAMMemory)
    (hwords : ∀ t < 6, ∀ i, mainMem.words.read (.localFrame 1 (t + 1) i) = hpjMem.words.read (.heap t i))
    (hreals : ∀ t < 6, ∀ i, mainMem.reals.read (.localFrame 1 (t + 1) i) = hpjMem.reals.read (.heap t i))
    (c : ArithCondExpr) (hp : isPureHPJCond c = true) :
    (evalArithCond mainInp 1 mainMem (relocCond phiRat c)).1 =
      (evalArithCond fakeInp 0 hpjMem c).1 ∧
    (evalArithCond mainInp 1 mainMem (relocCond phiRat c)).2 ≤
      3 * (evalArithCond fakeInp 0 hpjMem c).2 :=
  ⟨relocCond_val mainInp fakeInp phiRat hextra mainMem hpjMem hwords hreals c hp, by
    rw [evalArithCond_ops, evalArithCond_ops]
    exact condExprOps_reloc phiRat c hp⟩

/-! ### 3. Step-for-step fuel simulation of `hpjProg` inside `.localScope` -/

private def isPureHPJCont : ArithRAMCont → Bool
  | .stmt s => isPureHPJStmt s
  | .repeatLoop _ body => isPureHPJStmt body
  | .popScope _ => false

private def relocCont (tblSamp tblPts tblCoins : ℕ) (offSamp offPts offCoins : ℤ)
    (N_samp sz : ℕ) (phiRat : ℚ) : ArithRAMCont → ArithRAMCont
  | .stmt s => .stmt (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s)
  | .repeatLoop rem body =>
      .repeatLoop rem (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat body)
  | .popScope prev => .popScope prev

private def mapLoc1 : RAMCellLoc → RAMCellLoc
  | .heap t i => .localFrame 1 (t + 1) i
  | loc => loc

private lemma hpj_unitCost_le_halted {d : ℕ} {inp : ArithRAMInput d} :
    ∀ {fuel : ℕ} {stack : List ArithRAMCont} {st : ArithRAMExecState} {out : ArithRAMExecOutcome},
      runArithRAMFuel inp fuel stack st = .halted out →
      st.unitCost ≤ out.unitCost
  | _, [], st, out, h => by
      simp only [runArithRAMFuel] at h
      split_ifs at h
      injection h with ho
      rw [← ho]
  | 0, _ :: _, _, _, h => by simp [runArithRAMFuel] at h
  | fuel + 1, item :: rest, st, out, h => by
      cases item with
      | popScope _ =>
          simp only [runArithRAMFuel] at h
          simpa using hpj_unitCost_le_halted h
      | repeatLoop rem _ =>
          cases rem <;> (simp only [runArithRAMFuel] at h; simpa using hpj_unitCost_le_halted h)
      | stmt s =>
          cases s with
          | randBitHeap _ _ | randBitLocal _ _ =>
              simp only [runArithRAMFuel] at h
              cases hbits : st.remainingBits with
              | nil => simp [hbits] at h
              | cons _ _ =>
                  simp only [hbits] at h
                  exact le_trans (by dsimp; omega) (hpj_unitCost_le_halted h)
          | seq _ _ =>
              simp only [runArithRAMFuel] at h
              exact hpj_unitCost_le_halted h
          | localScope _ =>
              simp only [runArithRAMFuel] at h
              simpa using hpj_unitCost_le_halted h
          | _ =>
              simp only [runArithRAMFuel] at h
              exact le_trans (by dsimp; omega) (hpj_unitCost_le_halted h)

private def Coupled (m₀ : ArithRAMMemory) (B cur : ℕ) (hpjMem mainMem : ArithRAMMemory) : Prop :=
  cur ≤ B ∧
  mainMem.words.read (.localFrame 1 0 0) = (cur : ℤ) ∧
  (∀ t < 6, ∀ i, mainMem.words.read (.localFrame 1 (t + 1) i) = hpjMem.words.read (.heap t i)) ∧
  (∀ t < 6, ∀ i, mainMem.reals.read (.localFrame 1 (t + 1) i) = hpjMem.reals.read (.heap t i)) ∧
  (∀ loc, loc.keepAtDepth 0 = true →
    (loc ∈ mainMem.words.live ↔ loc ∈ m₀.words.live) ∧ mainMem.words.vals loc = m₀.words.vals loc) ∧
  (∀ loc, loc.keepAtDepth 0 = true →
    (loc ∈ mainMem.reals.live ↔ loc ∈ m₀.reals.live) ∧ mainMem.reals.vals loc = m₀.reals.vals loc) ∧
  mainMem.words.live ⊆ m₀.words.live ∪ insert (.localFrame 1 0 0) (hpjMem.words.live.image mapLoc1) ∧
  mainMem.reals.live ⊆ m₀.reals.live ∪ hpjMem.reals.live.image mapLoc1

private lemma Coupled.wRead_heap {m₀ : ArithRAMMemory} {B cur : ℕ} {hpjMem mainMem : ArithRAMMemory}
    (hc : Coupled m₀ B cur hpjMem mainMem) (t : ℕ) (i : ℤ) :
    mainMem.words.read (.heap t i) = wRead m₀ t i := by
  obtain ⟨hlive, hval⟩ := hc.2.2.2.2.1 (.heap t i) rfl
  simp only [wRead, WordStore.read, hlive, hval]

private lemma Coupled.rRead_heap {m₀ : ArithRAMMemory} {B cur : ℕ} {hpjMem mainMem : ArithRAMMemory}
    (hc : Coupled m₀ B cur hpjMem mainMem) (t : ℕ) (i : ℤ) :
    mainMem.reals.read (.heap t i) = rRead m₀ t i := by
  obtain ⟨hlive, hval⟩ := hc.2.2.2.2.2.1 (.heap t i) rfl
  simp only [rRead, RealStore.read, hlive, hval]

private lemma Coupled.cellCount_le {m₀ : ArithRAMMemory} {B cur : ℕ} {hpjMem mainMem : ArithRAMMemory}
    (hc : Coupled m₀ B cur hpjMem mainMem) :
    mainMem.cellCount ≤ m₀.cellCount + 1 + hpjMem.cellCount := by
  unfold ArithRAMMemory.cellCount WordStore.cellCount RealStore.cellCount
  have hw : mainMem.words.live.card ≤ m₀.words.live.card + 1 + hpjMem.words.live.card := by
    calc mainMem.words.live.card
        ≤ (m₀.words.live ∪ insert (.localFrame 1 0 0) (hpjMem.words.live.image mapLoc1)).card :=
          Finset.card_le_card hc.2.2.2.2.2.2.1
      _ ≤ m₀.words.live.card + (insert (.localFrame 1 0 0) (hpjMem.words.live.image mapLoc1)).card :=
          Finset.card_union_le _ _
      _ ≤ m₀.words.live.card + (1 + (hpjMem.words.live.image mapLoc1).card) := by
          have := Finset.card_insert_le (RAMCellLoc.localFrame 1 0 0) (hpjMem.words.live.image mapLoc1)
          omega
      _ ≤ m₀.words.live.card + (1 + hpjMem.words.live.card) := by
          have := Finset.card_image_le (f := mapLoc1) (s := hpjMem.words.live)
          omega
      _ = m₀.words.live.card + 1 + hpjMem.words.live.card := by omega
  have hr : mainMem.reals.live.card ≤ m₀.reals.live.card + hpjMem.reals.live.card := by
    calc mainMem.reals.live.card
        ≤ (m₀.reals.live ∪ hpjMem.reals.live.image mapLoc1).card :=
          Finset.card_le_card hc.2.2.2.2.2.2.2
      _ ≤ m₀.reals.live.card + (hpjMem.reals.live.image mapLoc1).card := Finset.card_union_le _ _
      _ ≤ m₀.reals.live.card + hpjMem.reals.live.card := by
          have := Finset.card_image_le (f := mapLoc1) (s := hpjMem.reals.live)
          omega
  omega

private lemma Coupled.init (m₀ : ArithRAMMemory) (B : ℕ)
    (hno_loc1_w : ∀ v i, RAMCellLoc.localFrame 1 v i ∉ m₀.words.live)
    (hno_loc1_r : ∀ v i, RAMCellLoc.localFrame 1 v i ∉ m₀.reals.live) :
    Coupled m₀ B 0 (ArithRAMMemory.empty.popDepth 0)
      { m₀ with words := m₀.words.write (.localFrame 1 0 0) 0 } := by
  refine ⟨Nat.zero_le B, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp [WordStore.read, WordStore.write]
  · intro t _ i
    have hne : RAMCellLoc.localFrame 1 (t + 1) i ≠ .localFrame 1 0 0 := by intro h; injection h; omega
    have hnot : RAMCellLoc.localFrame 1 (t + 1) i ∉ m₀.words.live := hno_loc1_w (t + 1) i
    simp [WordStore.read, WordStore.write, hne, hnot, ArithRAMMemory.empty,
      ArithRAMMemory.popDepth, WordStore.popDepth, WordStore.empty]
  · intro t _ i
    have hnot : RAMCellLoc.localFrame 1 (t + 1) i ∉ m₀.reals.live := hno_loc1_r (t + 1) i
    simp [RealStore.read, hnot, ArithRAMMemory.empty,
      ArithRAMMemory.popDepth, RealStore.popDepth, RealStore.empty]
  · intro loc hkeep
    have hne : loc ≠ .localFrame 1 0 0 := by
      intro h; subst h; simp [RAMCellLoc.keepAtDepth] at hkeep
    simp [WordStore.write, hne]
  · intro loc _; exact ⟨Iff.rfl, rfl⟩
  · intro loc hmem
    simp only [WordStore.write, Finset.mem_insert] at hmem
    simp only [Finset.mem_union, Finset.mem_insert]
    rcases hmem with rfl | hm
    · exact Or.inr (Or.inl rfl)
    · exact Or.inl hm
  · intro loc hmem; exact Finset.mem_union_left _ hmem

private lemma Coupled.writeWord {m₀ : ArithRAMMemory} {B cur : ℕ} {hpjMem mainMem : ArithRAMMemory}
    (hc : Coupled m₀ B cur hpjMem mainMem) {t : ℕ} (ht : t < 6) (idx val : ℤ) :
    Coupled m₀ B cur
      { hpjMem with words := hpjMem.words.write (.heap t idx) val }
      { mainMem with words := mainMem.words.write (.localFrame 1 (t + 1) idx) val } := by
  refine ⟨hc.1, ?_, ?_, hc.2.2.2.1, ?_, hc.2.2.2.2.2.1, ?_, hc.2.2.2.2.2.2.2⟩
  · have hne : RAMCellLoc.localFrame 1 0 0 ≠ .localFrame 1 (t + 1) idx := by intro h; injection h; omega
    simp only [WordStore.read, WordStore.write, Finset.mem_insert, hne, false_or,
      Function.update_of_ne hne]
    exact hc.2.1
  · intro t' ht' i'
    by_cases heq : t' = t ∧ i' = idx
    · rcases heq with ⟨rfl, rfl⟩
      simp [WordStore.read, WordStore.write]
    · have hne1 : RAMCellLoc.localFrame 1 (t' + 1) i' ≠ .localFrame 1 (t + 1) idx := by
        intro h; injection h with _ h1 h2; exact heq ⟨by omega, h2⟩
      have hne2 : RAMCellLoc.heap t' i' ≠ .heap t idx := by
        intro h; injection h with h1 h2; exact heq ⟨h1, h2⟩
      simp only [WordStore.read, WordStore.write, Finset.mem_insert, hne1, hne2, false_or,
        Function.update_of_ne hne1, Function.update_of_ne hne2]
      exact hc.2.2.1 t' ht' i'
  · intro loc hkeep
    have hne : loc ≠ .localFrame 1 (t + 1) idx := by
      intro h; subst h; simp [RAMCellLoc.keepAtDepth] at hkeep
    simp only [WordStore.write, Finset.mem_insert, hne, false_or, Function.update_of_ne hne]
    exact hc.2.2.2.2.1 loc hkeep
  · intro loc hmem
    simp only [WordStore.write, Finset.mem_insert] at hmem ⊢
    rcases hmem with rfl | hm
    · refine Finset.mem_union_right _ (Finset.mem_insert_of_mem ?_)
      exact Finset.mem_image.mpr ⟨.heap t idx, Finset.mem_insert_self _ _, rfl⟩
    · rcases Finset.mem_union.mp (hc.2.2.2.2.2.2.1 hm) with hm0 | hloc
      · exact Finset.mem_union_left _ hm0
      · refine Finset.mem_union_right _ ?_
        rcases Finset.mem_insert.mp hloc with rfl | himg
        · exact Finset.mem_insert_self _ _
        · rcases Finset.mem_image.mp himg with ⟨src, hsrc, rfl⟩
          exact Finset.mem_insert_of_mem (Finset.mem_image.mpr ⟨src, Finset.mem_insert_of_mem hsrc, rfl⟩)

private lemma Coupled.writeReal {m₀ : ArithRAMMemory} {B cur : ℕ} {hpjMem mainMem : ArithRAMMemory}
    (hc : Coupled m₀ B cur hpjMem mainMem) {t : ℕ} (ht : t < 6) (idx : ℤ) (val : ℝ) :
    Coupled m₀ B cur
      { hpjMem with reals := hpjMem.reals.write (.heap t idx) val }
      { mainMem with reals := mainMem.reals.write (.localFrame 1 (t + 1) idx) val } := by
  refine ⟨hc.1, hc.2.1, hc.2.2.1, ?_, hc.2.2.2.2.1, ?_, hc.2.2.2.2.2.2.1, ?_⟩
  · intro t' ht' i'
    by_cases heq : t' = t ∧ i' = idx
    · rcases heq with ⟨rfl, rfl⟩
      simp [RealStore.read, RealStore.write]
    · have hne1 : RAMCellLoc.localFrame 1 (t' + 1) i' ≠ .localFrame 1 (t + 1) idx := by
        intro h; injection h with _ h1 h2; exact heq ⟨by omega, h2⟩
      have hne2 : RAMCellLoc.heap t' i' ≠ .heap t idx := by
        intro h; injection h with h1 h2; exact heq ⟨h1, h2⟩
      simp only [RealStore.read, RealStore.write, Finset.mem_insert, hne1, hne2, false_or,
        Function.update_of_ne hne1, Function.update_of_ne hne2]
      exact hc.2.2.2.1 t' ht' i'
  · intro loc hkeep
    have hne : loc ≠ .localFrame 1 (t + 1) idx := by
      intro h; subst h; simp [RAMCellLoc.keepAtDepth] at hkeep
    simp only [RealStore.write, Finset.mem_insert, hne, false_or, Function.update_of_ne hne]
    exact hc.2.2.2.2.2.1 loc hkeep
  · intro loc hmem
    simp only [RealStore.write, Finset.mem_insert] at hmem ⊢
    rcases hmem with rfl | hm
    · exact Finset.mem_union_right _ (Finset.mem_image.mpr ⟨.heap t idx, Finset.mem_insert_self _ _, rfl⟩)
    · rcases Finset.mem_union.mp (hc.2.2.2.2.2.2.2 hm) with hm0 | himg
      · exact Finset.mem_union_left _ hm0
      · rcases Finset.mem_image.mp himg with ⟨src, hsrc, rfl⟩
        exact Finset.mem_union_right _ (Finset.mem_image.mpr ⟨src, Finset.mem_insert_of_mem hsrc, rfl⟩)

private lemma Coupled.incCur {m₀ : ArithRAMMemory} {B cur : ℕ} {hpjMem mainMem : ArithRAMMemory}
    (hc : Coupled m₀ B cur hpjMem mainMem) (hlt : cur < B) :
    Coupled m₀ B (cur + 1) hpjMem
      { mainMem with words := mainMem.words.write (.localFrame 1 0 0) ((cur : ℤ) + 1) } := by
  refine ⟨by omega, ?_, ?_, hc.2.2.2.1, ?_, hc.2.2.2.2.2.1, ?_, hc.2.2.2.2.2.2.2⟩
  · simp only [WordStore.read, WordStore.write, Finset.mem_insert, true_or, ↓reduceIte,
      Function.update_self]
    push_cast; ring
  · intro t ht i
    have hne : RAMCellLoc.localFrame 1 (t + 1) i ≠ .localFrame 1 0 0 := by intro h; injection h; omega
    simp only [WordStore.read, WordStore.write, Finset.mem_insert, hne, false_or,
      Function.update_of_ne hne]
    exact hc.2.2.1 t ht i
  · intro loc hkeep
    have hne : loc ≠ .localFrame 1 0 0 := by
      intro h; subst h; simp [RAMCellLoc.keepAtDepth] at hkeep
    simp only [WordStore.write, Finset.mem_insert, hne, false_or, Function.update_of_ne hne]
    exact hc.2.2.2.2.1 loc hkeep
  · intro loc hmem
    simp only [WordStore.write, Finset.mem_insert] at hmem
    rcases hmem with rfl | hm
    · exact Finset.mem_union_right _ (Finset.mem_insert_self _ _)
    · exact hc.2.2.2.2.2.2.1 hm

private lemma not_intParam_pure {t : ℕ} {dstE valE : IntExpr}
    (hp : isPureHPJStmt (.writeWordHeap t dstE valE) = true)
    (hnp : ∀ idxE, valE ≠ .intParam idxE) :
    t < 6 ∧ isPureHPJInt dstE = true ∧ isPureHPJInt valE = true := by
  cases valE with
  | intParam idxE => exact absurd rfl (hnp idxE)
  | _ =>
    simp only [isPureHPJStmt, Bool.and_eq_true, decide_eq_true_eq] at hp
    exact ⟨hp.1.1, hp.1.2, hp.2⟩

private lemma not_activePtCoord_pure {t : ℕ} {dstE : IntExpr} {valE : RealExpr}
    (hp : isPureHPJStmt (.writeRealHeap t dstE valE) = true)
    (hnp : ∀ hE cE, valE ≠ .activePtCoord hE cE) :
    t < 6 ∧ isPureHPJInt dstE = true ∧ isPureHPJReal valE = true := by
  cases valE with
  | activePtCoord hE cE => exact absurd rfl (hnp hE cE)
  | _ =>
    simp only [isPureHPJStmt, Bool.and_eq_true, decide_eq_true_eq] at hp
    exact ⟨hp.1.1, hp.1.2, hp.2⟩

private lemma listGetIntD_ofFn_fin {N : ℕ} (f : Fin N → ℤ) (idx : ℤ) :
    listGetIntD (List.ofFn f) idx 0 =
      if h : 0 ≤ idx ∧ idx < (N : ℤ) then
        f ⟨idx.toNat, by omega⟩
      else 0 := by
  unfold listGetIntD
  by_cases h : 0 ≤ idx ∧ idx < (N : ℤ)
  · rw [dif_pos h, if_pos h.1, List.getD_eq_getElem?_getD]
    have hlt : idx.toNat < (List.ofFn f).length := by simp; omega
    rw [List.getElem?_eq_getElem hlt, Option.getD_some, List.getElem_ofFn]
  · rw [dif_neg h]
    by_cases h0 : 0 ≤ idx
    · rw [if_pos h0, List.getD_eq_getElem?_getD]
      have hge : (List.ofFn f).length ≤ idx.toNat := by simp; omega
      rw [List.getElem?_eq_none hge]; rfl
    · rw [if_neg h0]

private lemma cellCount_writeWord_le (m : ArithRAMMemory) (loc : RAMCellLoc) (v : ℤ) :
    ({ m with words := m.words.write loc v } : ArithRAMMemory).cellCount ≤ m.cellCount + 1 := by
  dsimp [ArithRAMMemory.cellCount, WordStore.cellCount, RealStore.cellCount, WordStore.write]
  have := Finset.card_insert_le loc m.words.live
  omega

private lemma cellCount_writeReal_le (m : ArithRAMMemory) (loc : RAMCellLoc) (v : ℝ) :
    ({ m with reals := m.reals.write loc v } : ArithRAMMemory).cellCount ≤ m.cellCount + 1 := by
  dsimp [ArithRAMMemory.cellCount, WordStore.cellCount, RealStore.cellCount, RealStore.write]
  have := Finset.card_insert_le loc m.reals.live
  omega

private lemma drop_ofFn_eq_cons {B cur : ℕ} (bits : Fin B → Bool) {b : Bool} {bs' : List Bool}
    (h : (List.ofFn bits).drop cur = b :: bs') :
    ∃ hlt : cur < B, b = bits ⟨cur, hlt⟩ ∧ bs' = (List.ofFn bits).drop (cur + 1) := by
  have hlt : cur < B := by
    by_contra hge
    have hnil : (List.ofFn bits).drop cur = [] := by
      rw [List.drop_eq_nil_iff, List.length_ofFn]; omega
    rw [hnil] at h; cases h
  have hlen : cur < (List.ofFn bits).length := by simp [hlt]
  have hcons := List.drop_eq_getElem_cons hlen
  rw [h] at hcons
  injection hcons with hb hbs
  refine ⟨hlt, ?_, hbs⟩
  rw [hb]; simp

private lemma reloc_sim_fuel {d : ℕ}
    (mainInp fakeInp : ArithRAMInput d)
    (tblSamp tblPts tblCoins : ℕ) (offSamp offPts offCoins : ℤ)
    (N_samp sz B : ℕ) (phiRat : ℚ)
    (bits : Fin B → Bool)
    (poolPt : Fin sz → EuclideanSpace ℝ (Fin d))
    (ω : Fin N_samp → Fin sz)
    (hfake_int : fakeInp.intParams = List.ofFn (fun k : Fin N_samp => ((ω k).val : ℤ)))
    (hfake_handles : fakeInp.activeHandles = (Finset.univ : Finset (Fin sz)).map ⟨Fin.val, Fin.val_injective⟩)
    (hfake_coords : fakeInp.activeCoords = fun h =>
      if hh : ∃ i : Fin sz, i.val = h then poolPt (Classical.choose hh) else 0)
    (hfake_extra : fakeInp.extraReals = [(phiRat : ℝ)])
    (m₀ : ArithRAMMemory) (S_cap : ℕ)
    (hsamp_mem : ∀ k : Fin N_samp, wRead m₀ tblSamp (offSamp + (k.val : ℤ)) = ((ω k).val : ℤ))
    (hpts_mem : ∀ (i : Fin sz) (c : Fin d),
      rRead m₀ tblPts (offPts + ((i.val : ℤ) * (d : ℤ) + (c.val : ℤ))) = euclideanCoord (poolPt i) c)
    (hcoins_mem : ∀ j : Fin B, wRead m₀ tblCoins (offCoins + (j.val : ℤ)) = if bits j then 1 else 0)
    (tailStack : List ArithRAMCont) :
    ∀ (fuel : ℕ) (stack : List ArithRAMCont) (hpjSt : ArithRAMExecState)
      (out : ArithRAMExecOutcome) (cur u_m sp_m : ℕ) (mainMem : ArithRAMMemory),
      (∀ item ∈ stack, isPureHPJCont item = true) →
      hpjSt.frameDepth = 0 →
      hpjSt.remainingBits = (List.ofFn bits).drop cur →
      hpjSt.mem.cellCount ≤ hpjSt.unitCost →
      m₀.cellCount + 1 + out.unitCost ≤ S_cap →
      Coupled m₀ B cur hpjSt.mem mainMem →
      runArithRAMFuel fakeInp fuel stack hpjSt = .halted out →
      ∃ (k u_m' sp_m' : ℕ) (mainMem' : ArithRAMMemory) (hpjEndMem : ArithRAMMemory),
        out.mem = hpjEndMem.popDepth 0 ∧
        Coupled m₀ B B hpjEndMem mainMem' ∧
        hpjEndMem.cellCount ≤ out.unitCost ∧
        u_m' ≤ u_m + 15 * (out.unitCost - hpjSt.unitCost) ∧
        sp_m' ≤ max sp_m (mainInp.inputCellSpace + S_cap) ∧
        (∀ f : ℕ,
          runArithRAMFuel mainInp (f + k)
            (stack.map (relocCont tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat) ++ tailStack)
            { mem := mainMem, frameDepth := 1, remainingBits := [], unitCost := u_m, peakCellSpace := sp_m } =
          runArithRAMFuel mainInp f tailStack
            { mem := mainMem', frameDepth := 1, remainingBits := [], unitCost := u_m', peakCellSpace := sp_m' })
  | _, [], hpjSt, out, cur, u_m, sp_m, mainMem, _, _, hrem, hcc, _, hcpl, hhalt => by
      simp only [runArithRAMFuel] at hhalt
      split_ifs at hhalt with hemp
      injection hhalt with hout
      have hcur_eq : cur = B := by
        have hnil : (List.ofFn bits).drop cur = [] := List.isEmpty_iff.mp (hrem ▸ hemp)
        rw [List.drop_eq_nil_iff, List.length_ofFn] at hnil
        have := hcpl.1; omega
      subst hcur_eq
      refine ⟨0, u_m, sp_m, mainMem, hpjSt.mem, ?_, hcpl, ?_, ?_, le_max_left _ _, fun f => by simp⟩
      · rw [← hout]
      · rw [← hout]; exact hcc
      · rw [← hout]; dsimp; omega
  | 0, _ :: _, _, _, _, _, _, _, _, _, _, _, _, _, hhalt => by
      simp [runArithRAMFuel] at hhalt
  | fuel + 1, item :: rest, hpjSt, out, cur, u_m, sp_m, mainMem,
    hpure, hfd, hrem, hcc, hScap, hcpl, hhalt => by
      rcases hpjSt with ⟨hpjMem, hpjFD, hpjRem, hpjU, hpjSp⟩
      dsimp only at hfd hrem hcc hcpl
      subst hfd
      let hpjSt : ArithRAMExecState :=
        { mem := hpjMem, frameDepth := 0, remainingBits := hpjRem, unitCost := hpjU, peakCellSpace := hpjSp }
      change runArithRAMFuel fakeInp (fuel + 1) (item :: rest) hpjSt = .halted out at hhalt
      have hfd : hpjSt.frameDepth = 0 := rfl
      have hp_head : isPureHPJCont item = true := hpure item List.mem_cons_self
      have hp_rest : ∀ it ∈ rest, isPureHPJCont it = true :=
        fun it hit => hpure it (List.mem_cons_of_mem _ hit)
      cases item with
      | popScope _ => simp [isPureHPJCont] at hp_head
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hhalt
              obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                  bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                  hsamp_mem hpts_mem hcoins_mem tailStack
                  fuel rest hpjSt out cur u_m sp_m mainMem hp_rest hfd hrem hcc hScap hcpl hhalt
              refine ⟨k + 1, u', sp', mm', hem, h1, h2, h3, h4, h5, fun f => ?_⟩
              rw [show f + (k + 1) = (f + k) + 1 by omega]
              simp only [List.map_cons, List.cons_append, relocCont, runArithRAMFuel]
              exact hstep f
          | succ r =>
              simp only [runArithRAMFuel] at hhalt
              have hp_next : ∀ it ∈ (ArithRAMCont.stmt body :: ArithRAMCont.repeatLoop r body :: rest),
                  isPureHPJCont it = true := by
                intro it hit
                rcases List.mem_cons.mp hit with rfl | hit2
                · exact hp_head
                · rcases List.mem_cons.mp hit2 with rfl | hit3
                  · exact hp_head
                  · exact hp_rest it hit3
              obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                  bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                  hsamp_mem hpts_mem hcoins_mem tailStack
                  fuel (.stmt body :: .repeatLoop r body :: rest) hpjSt out cur u_m sp_m mainMem
                  hp_next hfd hrem hcc hScap hcpl hhalt
              refine ⟨k + 1, u', sp', mm', hem, h1, h2, h3, h4, h5, fun f => ?_⟩
              rw [show f + (k + 1) = (f + k) + 1 by omega]
              simp only [List.map_cons, List.cons_append, relocCont, runArithRAMFuel]
              exact hstep f
      | stmt s =>
          dsimp [isPureHPJCont] at hp_head
          cases s with
          | skip =>
              simp only [runArithRAMFuel] at hhalt
              have hu_le : hpjSt.unitCost + 1 ≤ out.unitCost := hpj_unitCost_le_halted hhalt
              obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                  bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                  hsamp_mem hpts_mem hcoins_mem tailStack
                  fuel rest { hpjSt with unitCost := hpjSt.unitCost + 1 } out cur (u_m + 1) sp_m mainMem
                  hp_rest hfd hrem (by dsimp [hpjSt] at *; omega) hScap hcpl hhalt
              refine ⟨k + 1, u', sp', mm', hem, h1, h2, h3, by dsimp [hpjSt] at h4 hu_le ⊢; omega, h5, fun f => ?_⟩
              rw [show f + (k + 1) = (f + k) + 1 by omega]
              simp only [List.map_cons, List.cons_append, relocCont, relocStmt, runArithRAMFuel]
              exact hstep f
          | seq s₁ s₂ =>
              simp only [isPureHPJStmt, Bool.and_eq_true] at hp_head
              simp only [runArithRAMFuel] at hhalt
              have hp_next : ∀ it ∈ (ArithRAMCont.stmt s₁ :: ArithRAMCont.stmt s₂ :: rest),
                  isPureHPJCont it = true := by
                intro it hit
                rcases List.mem_cons.mp hit with rfl | hit2
                · exact hp_head.1
                · rcases List.mem_cons.mp hit2 with rfl | hit3
                  · exact hp_head.2
                  · exact hp_rest it hit3
              obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                  bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                  hsamp_mem hpts_mem hcoins_mem tailStack
                  fuel (.stmt s₁ :: .stmt s₂ :: rest) hpjSt out cur u_m sp_m mainMem
                  hp_next hfd hrem hcc hScap hcpl hhalt
              refine ⟨k + 1, u', sp', mm', hem, h1, h2, h3, h4, h5, fun f => ?_⟩
              rw [show f + (k + 1) = (f + k) + 1 by omega]
              simp only [List.map_cons, List.cons_append, relocCont, relocStmt, runArithRAMFuel]
              exact hstep f
          | ite cond tB fB =>
              simp only [isPureHPJStmt, Bool.and_eq_true] at hp_head
              simp only [runArithRAMFuel] at hhalt
              obtain ⟨hflag, hcu⟩ :=
                relocCond_eval mainInp fakeInp phiRat hfake_extra mainMem hpjSt.mem hcpl.2.2.1 hcpl.2.2.2.1 cond hp_head.1.1
              let flag := (evalArithCond fakeInp 0 hpjSt.mem cond).1
              let uc_h := (evalArithCond fakeInp 0 hpjSt.mem cond).2
              let uc_m := (evalArithCond mainInp 1 mainMem (relocCond phiRat cond)).2
              let chosen_h := if flag then tB else fB
              have hp_ch : isPureHPJCont (.stmt chosen_h) = true := by
                dsimp [chosen_h]; split_ifs <;> [exact hp_head.1.2; exact hp_head.2]
              have hu_le : hpjSt.unitCost + uc_h ≤ out.unitCost := hpj_unitCost_le_halted hhalt
              obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                  bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                  hsamp_mem hpts_mem hcoins_mem tailStack
                  fuel (.stmt chosen_h :: rest) { hpjSt with unitCost := hpjSt.unitCost + uc_h } out
                  cur (u_m + uc_m) sp_m mainMem
                  (fun it hit => by rcases List.mem_cons.mp hit with rfl | hr; exact hp_ch; exact hp_rest it hr)
                  hfd hrem (by dsimp [hpjSt] at *; omega) hScap hcpl hhalt
              refine ⟨k + 1, u', sp', mm', hem, h1, h2, h3, ?_, h5, fun f => ?_⟩
              · have : uc_m ≤ 3 * uc_h := hcu
                dsimp [hpjSt] at h4 hu_le ⊢; omega
              · rw [show f + (k + 1) = (f + k) + 1 by omega]
                simp only [List.map_cons, List.cons_append, relocCont, relocStmt, runArithRAMFuel, hflag]
                have hch_map : (if flag then
                    relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat tB
                  else relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat fB) =
                  relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat chosen_h := by
                  dsimp [chosen_h]; split_ifs <;> rfl
                rw [hch_map]
                exact hstep f
          | whileLoop cond body =>
              simp only [isPureHPJStmt, Bool.and_eq_true] at hp_head
              simp only [runArithRAMFuel] at hhalt
              obtain ⟨hflag, hcu⟩ :=
                relocCond_eval mainInp fakeInp phiRat hfake_extra mainMem hpjSt.mem hcpl.2.2.1 hcpl.2.2.2.1 cond hp_head.1
              let flag := (evalArithCond fakeInp 0 hpjSt.mem cond).1
              let uc_h := (evalArithCond fakeInp 0 hpjSt.mem cond).2
              let uc_m := (evalArithCond mainInp 1 mainMem (relocCond phiRat cond)).2
              let next_h := if flag then .stmt body :: .stmt (.whileLoop cond body) :: rest else rest
              have hp_nh : ∀ it ∈ next_h, isPureHPJCont it = true := by
                intro it hit
                dsimp [next_h] at hit
                split_ifs at hit
                · rcases List.mem_cons.mp hit with rfl | hit2
                  · exact hp_head.2
                  · rcases List.mem_cons.mp hit2 with rfl | hit3
                    · simp [isPureHPJCont, isPureHPJStmt, hp_head.1, hp_head.2]
                    · exact hp_rest it hit3
                · exact hp_rest it hit
              have hu_le : hpjSt.unitCost + uc_h ≤ out.unitCost := hpj_unitCost_le_halted hhalt
              obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                  bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                  hsamp_mem hpts_mem hcoins_mem tailStack
                  fuel next_h { hpjSt with unitCost := hpjSt.unitCost + uc_h } out
                  cur (u_m + uc_m) sp_m mainMem
                  hp_nh hfd hrem (by dsimp [hpjSt] at *; omega) hScap hcpl hhalt
              refine ⟨k + 1, u', sp', mm', hem, h1, h2, h3, ?_, h5, fun f => ?_⟩
              · have : uc_m ≤ 3 * uc_h := hcu
                dsimp [hpjSt] at h4 hu_le ⊢; omega
              · rw [show f + (k + 1) = (f + k) + 1 by omega]
                simp only [List.map_cons, List.cons_append, relocCont, relocStmt, runArithRAMFuel, hflag]
                have hmap_eq : (if flag then
                    ArithRAMCont.stmt (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat body) ::
                    ArithRAMCont.stmt (.whileLoop (relocCond phiRat cond)
                      (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat body)) ::
                    (rest.map (relocCont tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat) ++ tailStack)
                  else rest.map (relocCont tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat) ++ tailStack) =
                  next_h.map (relocCont tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat) ++ tailStack := by
                  dsimp [next_h]; split_ifs <;> rfl
                rw [hmap_eq]
                exact hstep f
          | repeatN cntE body =>
              simp only [isPureHPJStmt, Bool.and_eq_true] at hp_head
              simp only [runArithRAMFuel] at hhalt
              obtain ⟨hcnt, hcu⟩ :=
                relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 cntE hp_head.1
              let cnt := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words cntE).1
              let uc_h := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words cntE).2.1
              let nIter := if 0 ≤ cnt then cnt.toNat else 0
              have hu_le : hpjSt.unitCost + uc_h ≤ out.unitCost := hpj_unitCost_le_halted hhalt
              obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                  bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                  hsamp_mem hpts_mem hcoins_mem tailStack
                  fuel (.repeatLoop nIter body :: rest) { hpjSt with unitCost := hpjSt.unitCost + uc_h } out
                  cur (u_m + uc_h) sp_m mainMem
                  (fun it hit => by rcases List.mem_cons.mp hit with rfl | hr; exact hp_head.2; exact hp_rest it hr)
                  hfd hrem (by dsimp [hpjSt] at *; omega) hScap hcpl hhalt
              refine ⟨k + 1, u', sp', mm', hem, h1, h2, h3, by dsimp [hpjSt] at h4 hu_le ⊢; omega, h5, fun f => ?_⟩
              rw [show f + (k + 1) = (f + k) + 1 by omega]
              simp only [List.map_cons, List.cons_append, relocCont, relocStmt, runArithRAMFuel, hcnt, hcu]
              exact hstep f
          | writeWordHeap t dstE valE =>
              by_cases hpar : ∃ idxE, valE = .intParam idxE
              · rcases hpar with ⟨idxE, rfl⟩
                simp only [isPureHPJStmt, Bool.and_eq_true, decide_eq_true_eq] at hp_head
                rcases hp_head with ⟨⟨ht, hp_dst⟩, hp_idx⟩
                simp only [runArithRAMFuel] at hhalt
                obtain ⟨vdst, udst⟩ := relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 dstE hp_dst
                obtain ⟨vidx, uidx⟩ := relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 idxE hp_idx
                let dst := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).1
                let idx := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words idxE).1
                let u_d := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).2.1
                let u_i := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words idxE).2.1
                let val := listGetIntD fakeInp.intParams idx 0
                let hpjMem' : ArithRAMMemory := { hpjSt.mem with words := hpjSt.mem.words.write (.heap t dst) val }
                let mainMem' : ArithRAMMemory := { mainMem with words := mainMem.words.write (.localFrame 1 (t + 1) dst) val }
                have hcpl' : Coupled m₀ B cur hpjMem' mainMem' := hcpl.writeWord ht dst val
                have hcc_h : hpjMem'.cellCount ≤ hpjSt.unitCost + u_d + (u_i + 1) + 1 := by
                  have := cellCount_writeWord_le hpjSt.mem (.heap t dst) val; dsimp [hpjMem', hpjSt] at *; omega
                have hu_le : hpjSt.unitCost + u_d + (u_i + 1) + 1 ≤ out.unitCost := hpj_unitCost_le_halted hhalt
                have hcc_m : mainMem'.cellCount ≤ S_cap := by
                  have := hcpl'.cellCount_le; omega
                -- Evaluate `.ite` + `.writeWordLocal` (2 steps on `mainInp`)
                let cond_m : ArithCondExpr := .and (.intLe (.lit 0) (relocInt idxE)) (.intLt (relocInt idxE) (.lit (N_samp : ℤ)))
                let uc_cond := (evalArithCond mainInp 1 mainMem cond_m).2
                let chosen_m : ArithRAMStmt :=
                  if 0 ≤ idx ∧ idx < (N_samp : ℤ) then
                    .writeWordLocal (t + 1) (relocInt dstE) (.readHeap tblSamp (.add (.lit offSamp) (relocInt idxE)))
                  else
                    .writeWordLocal (t + 1) (relocInt dstE) (.lit 0)
                let valE_m : IntExpr :=
                  if 0 ≤ idx ∧ idx < (N_samp : ℤ) then .readHeap tblSamp (.add (.lit offSamp) (relocInt idxE)) else .lit 0
                have hval_m : (evalIntExpr mainInp.toWordView 1 mainMem.words valE_m).1 = val := by
                  dsimp [val, valE_m]
                  rw [hfake_int, listGetIntD_ofFn_fin]
                  by_cases hrng : 0 ≤ idx ∧ idx < (N_samp : ℤ)
                  · rw [dif_pos hrng, if_pos hrng]
                    simp only [evalIntExpr, vidx]
                    change mainMem.words.read (.heap tblSamp (offSamp + idx)) = _
                    rw [hcpl.wRead_heap]
                    have hk_eq : offSamp + idx = offSamp + ((⟨idx.toNat, by omega⟩ : Fin N_samp).val : ℤ) := by
                      dsimp; omega
                    rw [hk_eq, hsamp_mem]
                  · rw [dif_neg hrng, if_neg hrng]; rfl
                let uc_val := (evalIntExpr mainInp.toWordView 1 mainMem.words valE_m).2.1
                let u_m1 := u_m + uc_cond + u_d + uc_val + 1
                let sp_m1 := max sp_m (mainInp.inputCellSpace + mainMem'.cellCount)
                have hsp_le : sp_m1 ≤ max sp_m (mainInp.inputCellSpace + S_cap) :=
                  max_le_max le_rfl (by omega)
                obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                  reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                    bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                    hsamp_mem hpts_mem hcoins_mem tailStack
                    fuel rest
                    { hpjSt with mem := hpjMem', unitCost := hpjSt.unitCost + u_d + (u_i + 1) + 1, peakCellSpace := max hpjSt.peakCellSpace (fakeInp.inputCellSpace + hpjMem'.cellCount) }
                    out cur u_m1 sp_m1 mainMem' hp_rest hfd hrem hcc_h hScap hcpl' hhalt
                refine ⟨k + 2, u', sp', mm', hem, h1, h2, h3, ?_, ?_, fun f => ?_⟩
                · have huc_cond : uc_cond = 2 * u_i + 5 := by
                    dsimp [uc_cond, cond_m]; simp only [evalArithCond, evalIntExpr, uidx]; omega
                  have huc_val : uc_val ≤ u_i + 3 := by
                    dsimp [uc_val, valE_m]; split_ifs <;> simp only [evalIntExpr, uidx] <;> omega
                  dsimp [u_m1, hpjSt] at h4 hu_le ⊢; omega
                · refine h5.trans ?_
                  dsimp [sp_m1]; omega
                · rw [show f + (k + 2) = ((f + k) + 1) + 1 by omega]
                  simp only [List.map_cons, List.cons_append, relocCont, relocStmt, runArithRAMFuel]
                  have hcond_eq : (evalArithCond mainInp 1 mainMem cond_m).1 = decide (0 ≤ idx ∧ idx < (N_samp : ℤ)) := by
                    apply Bool.eq_iff_iff.mpr
                    dsimp [cond_m, idx]; simp [evalArithCond, evalIntExpr, vidx, Bool.and_eq_true, decide_eq_true_eq]
                  rw [hcond_eq]
                  by_cases hrng : 0 ≤ idx ∧ idx < (N_samp : ℤ)
                  · simp only [decide_eq_true hrng, ↓reduceIte, runArithRAMFuel, vdst, udst]
                    have hv : (evalIntExpr mainInp.toWordView 1 mainMem.words (.readHeap tblSamp (.add (.lit offSamp) (relocInt idxE)))) =
                        (val, uc_val, (evalIntExpr mainInp.toWordView 1 mainMem.words valE_m).2.2) := by
                      dsimp [valE_m, uc_val]; rw [if_pos hrng]
                      rw [← hval_m]; dsimp [valE_m]; rw [if_pos hrng]
                    rw [hv]; exact hstep f
                  · simp only [decide_eq_false hrng, Bool.false_eq_true, ↓reduceIte, runArithRAMFuel, vdst, udst]
                    have hv : (evalIntExpr mainInp.toWordView 1 mainMem.words (.lit 0)) =
                        (val, uc_val, (evalIntExpr mainInp.toWordView 1 mainMem.words valE_m).2.2) := by
                      rw [← hval_m]; dsimp [valE_m, uc_val]; rw [if_neg hrng]
                    rw [hv]; exact hstep f
              · obtain ⟨ht, hp_dst, hp_val⟩ := not_intParam_pure hp_head (fun idxE h => hpar ⟨idxE, h⟩)
                simp only [runArithRAMFuel] at hhalt
                obtain ⟨vdst, udst⟩ := relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 dstE hp_dst
                obtain ⟨vval, uval⟩ := relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 valE hp_val
                let dst := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).1
                let val := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words valE).1
                let u_d := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).2.1
                let u_v := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words valE).2.1
                let hpjMem' : ArithRAMMemory := { hpjSt.mem with words := hpjSt.mem.words.write (.heap t dst) val }
                let mainMem' : ArithRAMMemory := { mainMem with words := mainMem.words.write (.localFrame 1 (t + 1) dst) val }
                have hcpl' : Coupled m₀ B cur hpjMem' mainMem' := hcpl.writeWord ht dst val
                have hcc_h : hpjMem'.cellCount ≤ hpjSt.unitCost + u_d + u_v + 1 := by
                  have := cellCount_writeWord_le hpjSt.mem (.heap t dst) val; dsimp [hpjMem', hpjSt] at *; omega
                have hu_le : hpjSt.unitCost + u_d + u_v + 1 ≤ out.unitCost := hpj_unitCost_le_halted hhalt
                have hcc_m : mainMem'.cellCount ≤ S_cap := by have := hcpl'.cellCount_le; omega
                let sp_m1 := max sp_m (mainInp.inputCellSpace + mainMem'.cellCount)
                obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                  reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                    bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                    hsamp_mem hpts_mem hcoins_mem tailStack
                    fuel rest
                    { hpjSt with mem := hpjMem', unitCost := hpjSt.unitCost + u_d + u_v + 1, peakCellSpace := max hpjSt.peakCellSpace (fakeInp.inputCellSpace + hpjMem'.cellCount) }
                    out cur (u_m + u_d + u_v + 1) sp_m1 mainMem' hp_rest hfd hrem hcc_h hScap hcpl' hhalt
                refine ⟨k + 1, u', sp', mm', hem, h1, h2, h3, by dsimp [hpjSt] at h4 hu_le ⊢; omega, ?_, fun f => ?_⟩
                · refine h5.trans ?_
                  dsimp [sp_m1]; omega
                · rw [show f + (k + 1) = (f + k) + 1 by omega]
                  have hrel : relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat (.writeWordHeap t dstE valE) =
                      .writeWordLocal (t + 1) (relocInt dstE) (relocInt valE) := by
                    cases valE with
                    | intParam idxE => exact absurd ⟨idxE, rfl⟩ hpar
                    | _ => rfl
                  simp only [List.map_cons, List.cons_append, relocCont, hrel, runArithRAMFuel, vdst, udst, vval, uval]
                  exact hstep f
          | writeRealHeap t dstE valE =>
              by_cases hact : ∃ hE cE, valE = .activePtCoord hE cE
              · rcases hact with ⟨hE, cE, rfl⟩
                simp only [isPureHPJStmt, Bool.and_eq_true, decide_eq_true_eq] at hp_head
                rcases hp_head with ⟨⟨⟨ht, hp_dst⟩, hp_h⟩, hp_c⟩
                simp only [runArithRAMFuel] at hhalt
                obtain ⟨vdst, udst⟩ := relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 dstE hp_dst
                obtain ⟨vh, uh⟩ := relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 hE hp_h
                obtain ⟨vc, uc⟩ := relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 cE hp_c
                let dst := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).1
                let h_v := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words hE).1
                let c_v := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words cE).1
                let u_d := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).2.1
                let u_h := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words hE).2.1
                let u_c := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words cE).2.1
                let val := (evalRealExpr fakeInp 0 hpjSt.mem (.activePtCoord hE cE)).1
                let hpjMem' : ArithRAMMemory := { hpjSt.mem with reals := hpjSt.mem.reals.write (.heap t dst) val }
                let mainMem' : ArithRAMMemory := { mainMem with reals := mainMem.reals.write (.localFrame 1 (t + 1) dst) val }
                have hcpl' : Coupled m₀ B cur hpjMem' mainMem' := hcpl.writeReal ht dst val
                have hu_act : (evalRealExpr fakeInp 0 hpjSt.mem (.activePtCoord hE cE)).2 = u_h + u_c + 1 := rfl
                have hcc_h : hpjMem'.cellCount ≤ hpjSt.unitCost + u_d + (u_h + u_c + 1) + 1 := by
                  have := cellCount_writeReal_le hpjSt.mem (.heap t dst) val; dsimp [hpjMem', hpjSt] at *; omega
                have hu_le : hpjSt.unitCost + u_d + (u_h + u_c + 1) + 1 ≤ out.unitCost := by
                  rw [hu_act] at hhalt; exact hpj_unitCost_le_halted hhalt
                have hcc_m : mainMem'.cellCount ≤ S_cap := by have := hcpl'.cellCount_le; omega
                let cond_m : ArithCondExpr :=
                  .and (.and (.intLe (.lit 0) (relocInt hE)) (.intLt (relocInt hE) (.lit (sz : ℤ))))
                       (.and (.intLe (.lit 0) (relocInt cE)) (.intLt (relocInt cE) .dim))
                let uc_cond := (evalArithCond mainInp 1 mainMem cond_m).2
                let rngP : Prop := (0 ≤ h_v ∧ h_v < (sz : ℤ)) ∧ (0 ≤ c_v ∧ c_v < (d : ℤ))
                let valE_m : RealExpr :=
                  if (0 ≤ h_v ∧ h_v < (sz : ℤ)) ∧ (0 ≤ c_v ∧ c_v < (d : ℤ)) then
                    .readRealHeap tblPts (.add (.lit offPts) (.add (.mul (relocInt hE) .dim) (relocInt cE)))
                  else .ofInt (.lit 0)
                have hval_m : (evalRealExpr mainInp 1 mainMem valE_m).1 = val := by
                  dsimp [val, valE_m, evalRealExpr]
                  rw [hfake_handles, hfake_coords]
                  have hmem_iff : (0 ≤ h_v ∧ h_v.toNat ∈ (Finset.univ : Finset (Fin sz)).map ⟨Fin.val, Fin.val_injective⟩) ↔
                      (0 ≤ h_v ∧ h_v < (sz : ℤ)) := by
                    simp only [Finset.mem_map, Finset.mem_univ, Function.Embedding.coeFn_mk, true_and]
                    constructor
                    · rintro ⟨hh0, i, hi⟩
                      have hilt := i.isLt; omega
                    · rintro ⟨hh0, hhlt⟩
                      exact ⟨hh0, ⟨h_v.toNat, by omega⟩, rfl⟩
                  have hc_iff : (0 ≤ c_v ∧ c_v.toNat < d) ↔ (0 ≤ c_v ∧ c_v < (d : ℤ)) := by omega
                  change (evalRealExpr mainInp 1 mainMem valE_m).1 =
                    if 0 ≤ h_v ∧ h_v.toNat ∈ (Finset.univ : Finset (Fin sz)).map ⟨Fin.val, Fin.val_injective⟩ then
                      if hc : 0 ≤ c_v ∧ c_v.toNat < d then
                        euclideanCoord (if hh : ∃ i : Fin sz, i.val = h_v.toNat then poolPt (Classical.choose hh) else 0) ⟨c_v.toNat, hc.2⟩
                      else 0
                    else 0
                  dsimp only [valE_m]
                  by_cases hrng : (0 ≤ h_v ∧ h_v < (sz : ℤ)) ∧ (0 ≤ c_v ∧ c_v < (d : ℤ))
                  · rw [if_pos hrng, if_pos (hmem_iff.mpr hrng.1), dif_pos (hc_iff.mpr hrng.2)]
                    have hex_h : ∃ i : Fin sz, i.val = h_v.toNat := ⟨⟨h_v.toNat, by omega⟩, rfl⟩
                    rw [dif_pos hex_h]
                    have hch_eq : Classical.choose hex_h = ⟨h_v.toNat, by omega⟩ :=
                      Fin.ext (Classical.choose_spec hex_h)
                    rw [hch_eq]
                    simp only [evalRealExpr, evalIntExpr, vh, vc]
                    change mainMem.reals.read (.heap tblPts (offPts + (h_v * (d : ℤ) + c_v))) = _
                    rw [hcpl.rRead_heap]
                    have hidx_eq : offPts + (h_v * (d : ℤ) + c_v) =
                        offPts + ((((⟨h_v.toNat, by omega⟩ : Fin sz).val : ℤ) * (d : ℤ)) +
                          (((⟨c_v.toNat, by omega⟩ : Fin d).val : ℤ))) := by
                      dsimp
                      have hh_cast : ((h_v.toNat : ℕ) : ℤ) = h_v := Int.toNat_of_nonneg hrng.1.1
                      have hc_cast : ((c_v.toNat : ℕ) : ℤ) = c_v := Int.toNat_of_nonneg hrng.2.1
                      rw [hh_cast, hc_cast]
                    rw [hidx_eq, hpts_mem]
                  · rw [if_neg hrng]
                    by_cases hh_ok : 0 ≤ h_v ∧ h_v < (sz : ℤ)
                    · have hc_bad : ¬ (0 ≤ c_v ∧ c_v < (d : ℤ)) := fun hc => hrng ⟨hh_ok, hc⟩
                      rw [if_pos (hmem_iff.mpr hh_ok), dif_neg (fun hc => hc_bad (hc_iff.mp hc))]
                      simp [evalRealExpr, evalIntExpr]
                    · rw [if_neg (fun hh => hh_ok (hmem_iff.mp hh))]
                      simp [evalRealExpr, evalIntExpr]
                let uc_val := (evalRealExpr mainInp 1 mainMem valE_m).2
                let u_m1 := u_m + uc_cond + u_d + uc_val + 1
                let sp_m1 := max sp_m (mainInp.inputCellSpace + mainMem'.cellCount)
                obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                  reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                    bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                    hsamp_mem hpts_mem hcoins_mem tailStack
                    fuel rest
                    { hpjSt with mem := hpjMem', unitCost := hpjSt.unitCost + u_d + (u_h + u_c + 1) + 1, peakCellSpace := max hpjSt.peakCellSpace (fakeInp.inputCellSpace + hpjMem'.cellCount) }
                    out cur u_m1 sp_m1 mainMem' hp_rest hfd hrem hcc_h hScap hcpl' hhalt
                refine ⟨k + 2, u', sp', mm', hem, h1, h2, h3, ?_, ?_, fun f => ?_⟩
                · have huc_cond : uc_cond = 2 * u_h + 2 * u_c + 11 := by
                    dsimp [uc_cond, cond_m]; simp only [evalArithCond, evalIntExpr, uh, uc]; omega
                  have huc_val : uc_val ≤ u_h + u_c + 6 := by
                    dsimp [uc_val, valE_m]; split_ifs <;> simp only [evalRealExpr, evalIntExpr, uh, uc] <;> omega
                  dsimp [u_m1, hpjSt] at h4 hu_le ⊢; omega
                · refine h5.trans ?_; dsimp [sp_m1]; omega
                · rw [show f + (k + 2) = ((f + k) + 1) + 1 by omega]
                  simp only [List.map_cons, List.cons_append, relocCont, relocStmt, runArithRAMFuel]
                  have hcond_eq : (evalArithCond mainInp 1 mainMem cond_m).1 =
                      decide ((0 ≤ h_v ∧ h_v < (sz : ℤ)) ∧ (0 ≤ c_v ∧ c_v < (d : ℤ))) := by
                    apply Bool.eq_iff_iff.mpr
                    dsimp [cond_m, h_v, c_v]; simp [evalArithCond, evalIntExpr, vh, vc, Bool.and_eq_true, decide_eq_true_eq]
                  rw [hcond_eq]
                  by_cases hrng : (0 ≤ h_v ∧ h_v < (sz : ℤ)) ∧ (0 ≤ c_v ∧ c_v < (d : ℤ))
                  · simp only [decide_eq_true hrng, ↓reduceIte, runArithRAMFuel, vdst, udst]
                    have hv : evalRealExpr mainInp 1 mainMem (.readRealHeap tblPts (.add (.lit offPts) (.add (.mul (relocInt hE) .dim) (relocInt cE)))) =
                        (val, uc_val) := by
                      rw [← hval_m]; dsimp [valE_m, uc_val]; rw [if_pos hrng]
                    rw [hv]; exact hstep f
                  · simp only [decide_eq_false hrng, Bool.false_eq_true, ↓reduceIte, runArithRAMFuel, vdst, udst]
                    have hv : evalRealExpr mainInp 1 mainMem (.ofInt (.lit 0)) = (val, uc_val) := by
                      rw [← hval_m]; dsimp [valE_m, uc_val]; rw [if_neg hrng]
                    rw [hv]; exact hstep f
              · obtain ⟨ht, hp_dst, hp_val⟩ := not_activePtCoord_pure hp_head (fun hE cE h => hact ⟨hE, cE, h⟩)
                simp only [runArithRAMFuel] at hhalt
                obtain ⟨vdst, udst⟩ := relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 dstE hp_dst
                obtain ⟨vval, uval⟩ := relocReal_eval mainInp fakeInp phiRat hfake_extra mainMem hpjSt.mem hcpl.2.2.1 hcpl.2.2.2.1 valE hp_val
                let dst := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).1
                let val := (evalRealExpr fakeInp 0 hpjSt.mem valE).1
                let u_d := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).2.1
                let u_v := (evalRealExpr fakeInp 0 hpjSt.mem valE).2
                let u_vm := (evalRealExpr mainInp 1 mainMem (relocReal phiRat valE)).2
                let hpjMem' : ArithRAMMemory := { hpjSt.mem with reals := hpjSt.mem.reals.write (.heap t dst) val }
                let mainMem' : ArithRAMMemory := { mainMem with reals := mainMem.reals.write (.localFrame 1 (t + 1) dst) val }
                have hcpl' : Coupled m₀ B cur hpjMem' mainMem' := hcpl.writeReal ht dst val
                have hcc_h : hpjMem'.cellCount ≤ hpjSt.unitCost + u_d + u_v + 1 := by
                  have := cellCount_writeReal_le hpjSt.mem (.heap t dst) val; dsimp [hpjMem', hpjSt] at *; omega
                have hu_le : hpjSt.unitCost + u_d + u_v + 1 ≤ out.unitCost := hpj_unitCost_le_halted hhalt
                have hcc_m : mainMem'.cellCount ≤ S_cap := by have := hcpl'.cellCount_le; omega
                let sp_m1 := max sp_m (mainInp.inputCellSpace + mainMem'.cellCount)
                obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                  reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                    bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                    hsamp_mem hpts_mem hcoins_mem tailStack
                    fuel rest
                    { hpjSt with mem := hpjMem', unitCost := hpjSt.unitCost + u_d + u_v + 1, peakCellSpace := max hpjSt.peakCellSpace (fakeInp.inputCellSpace + hpjMem'.cellCount) }
                    out cur (u_m + u_d + u_vm + 1) sp_m1 mainMem' hp_rest hfd hrem hcc_h hScap hcpl' hhalt
                refine ⟨k + 1, u', sp', mm', hem, h1, h2, h3, ?_, ?_, fun f => ?_⟩
                · have : u_vm ≤ 3 * u_v := uval; dsimp [hpjSt] at h4 hu_le ⊢; omega
                · refine h5.trans ?_; dsimp [sp_m1]; omega
                · rw [show f + (k + 1) = (f + k) + 1 by omega]
                  have hrel : relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat (.writeRealHeap t dstE valE) =
                      .writeRealLocal (t + 1) (relocInt dstE) (relocReal phiRat valE) := by
                    cases valE with
                    | activePtCoord hE cE => exact absurd ⟨hE, cE, rfl⟩ hact
                    | _ => rfl
                  simp only [List.map_cons, List.cons_append, relocCont, hrel, runArithRAMFuel, vdst, udst, vval]
                  exact hstep f
          | randBitHeap t dstE =>
              simp only [isPureHPJStmt, Bool.and_eq_true, decide_eq_true_eq] at hp_head
              rcases hp_head with ⟨ht, hp_dst⟩
              simp only [runArithRAMFuel] at hhalt
              cases hbits : hpjSt.remainingBits with
              | nil => simp [hbits] at hhalt
              | cons bit bs' =>
                  rw [hbits] at hhalt
                  obtain ⟨hlt_cur, rfl, hbs'⟩ := drop_ofFn_eq_cons bits (hrem.symm.trans hbits)
                  obtain ⟨vdst, udst⟩ := relocInt_eval mainInp fakeInp mainMem hpjSt.mem hcpl.2.2.1 dstE hp_dst
                  let dst := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).1
                  let u_d := (evalIntExpr fakeInp.toWordView 0 hpjSt.mem.words dstE).2.1
                  have hud_pos : 1 ≤ u_d := by
                    dsimp [u_d]; rw [evalIntExpr_ops]; exact intExprOps_pos dstE
                  let vbit : ℤ := if bits ⟨cur, hlt_cur⟩ then 1 else 0
                  let hpjMem' : ArithRAMMemory := { hpjSt.mem with words := hpjSt.mem.words.write (.heap t dst) vbit }
                  let mainMem₁ : ArithRAMMemory := { mainMem with words := mainMem.words.write (.localFrame 1 (t + 1) dst) vbit }
                  let mainMem₂ : ArithRAMMemory := { mainMem₁ with words := mainMem₁.words.write (.localFrame 1 0 0) ((cur : ℤ) + 1) }
                  have hcpl₁ : Coupled m₀ B cur hpjMem' mainMem₁ := hcpl.writeWord ht dst vbit
                  have hcpl₂ : Coupled m₀ B (cur + 1) hpjMem' mainMem₂ := hcpl₁.incCur hlt_cur
                  have hcc_h : hpjMem'.cellCount ≤ hpjSt.unitCost + u_d + 1 := by
                    have := cellCount_writeWord_le hpjSt.mem (.heap t dst) vbit; dsimp [hpjMem', hpjSt] at *; omega
                  have hu_le : hpjSt.unitCost + u_d + 1 ≤ out.unitCost := hpj_unitCost_le_halted hhalt
                  have hcc_m1 : mainMem₁.cellCount ≤ S_cap := by have := hcpl₁.cellCount_le; omega
                  have hcc_m2 : mainMem₂.cellCount ≤ S_cap := by have := hcpl₂.cellCount_le; omega
                  let sp_m1 := max sp_m (mainInp.inputCellSpace + mainMem₁.cellCount)
                  let sp_m2 := max sp_m1 (mainInp.inputCellSpace + mainMem₂.cellCount)
                  let u_m2 := (u_m + u_d + 5 + 1) + 1 + 4 + 1
                  obtain ⟨k, u', sp', mm', hem, h1, h2, h3, h4, h5, hstep⟩ :=
                    reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
                      bits poolPt ω hfake_int hfake_handles hfake_coords hfake_extra m₀ S_cap
                      hsamp_mem hpts_mem hcoins_mem tailStack
                      fuel rest
                      { hpjSt with mem := hpjMem', remainingBits := bs', unitCost := hpjSt.unitCost + u_d + 1, peakCellSpace := max hpjSt.peakCellSpace (fakeInp.inputCellSpace + hpjMem'.cellCount) }
                      out (cur + 1) u_m2 sp_m2 mainMem₂ hp_rest hfd hbs' hcc_h hScap hcpl₂ hhalt
                  refine ⟨k + 3, u', sp', mm', hem, h1, h2, h3, ?_, ?_, fun f => ?_⟩
                  · dsimp [u_m2, hpjSt] at h4 hu_le ⊢; omega
                  · refine h5.trans ?_; dsimp [sp_m1, sp_m2]; omega
                  · rw [show f + (k + 3) = (((f + k) + 1) + 1) + 1 by omega]
                    simp only [List.map_cons, List.cons_append, relocCont, relocStmt, runArithRAMFuel, vdst, udst]
                    have hcoin_read : mainMem.words.read (.heap tblCoins (offCoins + mainMem.words.read (.localFrame 1 0 0))) = vbit := by
                      rw [hcpl.2.1, hcpl.wRead_heap]
                      exact hcoins_mem ⟨cur, hlt_cur⟩
                    simp only [evalIntExpr, hcoin_read]
                    change runArithRAMFuel mainInp (f + k) _
                      { mem := { mainMem₁ with words := mainMem₁.words.write (.localFrame 1 0 0) (mainMem₁.words.read (.localFrame 1 0 0) + 1) },
                        frameDepth := 1, remainingBits := [],
                        unitCost := (u_m + u_d + (1 + (1 + 1) + 1 + 1) + 1) + 1 + ((1 + 1) + 1 + 1) + 1,
                        peakCellSpace := max sp_m1 (mainInp.inputCellSpace + ({ mainMem₁ with words := mainMem₁.words.write (.localFrame 1 0 0) (mainMem₁.words.read (.localFrame 1 0 0) + 1) } : ArithRAMMemory).cellCount) } = _
                    rw [hcpl₁.2.1]
                    convert hstep f using 2 <;> (dsimp [hpjSt, u_m2, u_d, dst, vbit, sp_m1, sp_m2, mainMem₁, mainMem₂]; omega)
          | writeWordLocal _ _ _ | freeWordHeap _ _ | freeWordLocal _ _ | writeRealLocal _ _ _
          | freeRealHeap _ _ | freeRealLocal _ _ | randBitLocal _ _ | localScope _ =>
              simp [isPureHPJStmt] at hp_head

/-! ### 4. Copy-out loop, `.popScope 0` extensionality, and master `exec_embedHPJStmt` -/

private noncomputable def writeOutCoords (scrR : ℕ) (outOff : ℤ) (vals : ℕ → ℝ) :
    ℕ → ArithRAMMemory → ArithRAMMemory
  | 0, m => m
  | k + 1, m => H3a.rWrite (writeOutCoords scrR outOff vals k m) scrR (outOff + (k : ℤ)) (vals k)

private lemma writeOutCoords_footprint {TW BW TR BR scrR : ℕ} {outOff : ℤ} {vals : ℕ → ℝ}
    {m₀ : ArithRAMMemory} (hfp : InFootprint TW BW TR BR m₀) (hscrR : scrR < TR)
    (ho0 : 0 ≤ outOff) :
    ∀ k : ℕ, outOff + (k : ℤ) ≤ (BR : ℤ) →
      InFootprint TW BW TR BR (writeOutCoords scrR outOff vals k m₀)
  | 0, _ => hfp
  | k + 1, hk =>
      (writeOutCoords_footprint hfp hscrR ho0 k (by omega)).rWrite hscrR (by omega) (by omega)

private lemma writeOutCoords_preserves {scrW scrR : ℕ} {outOff : ℤ} {vals : ℕ → ℝ}
    (m₀ : ArithRAMMemory) :
    ∀ k : ℕ, PreservesNonScratch scrW scrR m₀ (writeOutCoords scrR outOff vals k m₀)
  | 0 => PreservesNonScratch.refl scrW scrR m₀
  | k + 1 =>
      (writeOutCoords_preserves m₀ k).trans
        (PreservesNonScratch.rWrite_scr scrW scrR _ (outOff + (k : ℤ)) (vals k))

private lemma writeOutCoords_read_self {scrR : ℕ} {outOff : ℤ} {vals : ℕ → ℝ}
    (m₀ : ArithRAMMemory) :
    ∀ (k j : ℕ), j < k →
      rRead (writeOutCoords scrR outOff vals k m₀) scrR (outOff + (j : ℤ)) = vals j
  | 0, _, hj => absurd hj (Nat.not_lt_zero _)
  | k + 1, j, hj => by
      dsimp [writeOutCoords]
      rcases Nat.lt_succ_iff_lt_or_eq.mp hj with hlt | rfl
      · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]
        exact writeOutCoords_read_self m₀ k j hlt
      · exact rRead_rWrite_self _ _ _ _

private lemma writeOutCoords_read_outside {scrR : ℕ} {outOff : ℤ} {vals : ℕ → ℝ}
    (m₀ : ArithRAMMemory) :
    ∀ (k : ℕ) (idx : ℤ), (idx < outOff ∨ outOff + (k : ℤ) ≤ idx) →
      rRead (writeOutCoords scrR outOff vals k m₀) scrR idx = rRead m₀ scrR idx
  | 0, _, _ => rfl
  | k + 1, idx, h => by
      dsimp [writeOutCoords]
      rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]
      exact writeOutCoords_read_outside m₀ k idx (by omega)

private lemma writeOutCoords_wRead (scrR : ℕ) (outOff : ℤ) (vals : ℕ → ℝ)
    (m₀ : ArithRAMMemory) :
    ∀ (k t : ℕ) (i : ℤ), wRead (writeOutCoords scrR outOff vals k m₀) t i = wRead m₀ t i
  | 0, _, _ => rfl
  | k + 1, t, i => (wRead_rWrite _ _ _ _ _ _).trans (writeOutCoords_wRead scrR outOff vals m₀ k t i)

private lemma copyOut_loop_fuel {d : ℕ} (mainInp : ArithRAMInput d)
    (scrR : ℕ) (outOff : ℤ) (m₀ : ArithRAMMemory) (S_cap : ℕ)
    (vals : ℕ → ℝ) :
    let copyBody : ArithRAMStmt :=
      .seq
        (.writeRealHeap scrR (.add (.lit outOff) (.readLocal 0 (.lit 1)))
          (.readRealLocal 1 (.readLocal 0 (.lit 1))))
        (.writeWordLocal 0 (.lit 1) (.add (.readLocal 0 (.lit 1)) (.lit 1)))
    ∀ (j : ℕ) (_hj : j ≤ d + 1) (curMem : ArithRAMMemory) (u_c sp_c : ℕ) (rest : List ArithRAMCont),
      curMem.words.read (.localFrame 1 0 1) = (j : ℤ) →
      (∀ c < d + 1, curMem.reals.read (.localFrame 1 1 (c : ℤ)) = vals c) →
      (∀ loc, loc.keepAtDepth 0 = true →
        (loc ∈ curMem.words.live ↔ loc ∈ m₀.words.live) ∧ curMem.words.vals loc = m₀.words.vals loc) →
      (∀ loc, loc.keepAtDepth 0 = true →
        (loc ∈ curMem.reals.live ↔ loc ∈ (writeOutCoords scrR outOff vals j m₀).reals.live) ∧
        curMem.reals.vals loc = (writeOutCoords scrR outOff vals j m₀).reals.vals loc) →
      curMem.cellCount + 2 * ((d + 1) - j) ≤ S_cap →
      ∃ (k u_f sp_f : ℕ) (endMem : ArithRAMMemory),
        (∀ loc, loc.keepAtDepth 0 = true →
          (loc ∈ endMem.words.live ↔ loc ∈ m₀.words.live) ∧ endMem.words.vals loc = m₀.words.vals loc) ∧
        (∀ loc, loc.keepAtDepth 0 = true →
          (loc ∈ endMem.reals.live ↔ loc ∈ (writeOutCoords scrR outOff vals (d + 1) m₀).reals.live) ∧
          endMem.reals.vals loc = (writeOutCoords scrR outOff vals (d + 1) m₀).reals.vals loc) ∧
        u_f ≤ u_c + 16 * ((d + 1) - j) ∧
        sp_f ≤ max sp_c (mainInp.inputCellSpace + S_cap) ∧
        (∀ f : ℕ,
          runArithRAMFuel mainInp (f + k) (.repeatLoop ((d + 1) - j) copyBody :: rest)
            { mem := curMem, frameDepth := 1, remainingBits := [], unitCost := u_c, peakCellSpace := sp_c } =
          runArithRAMFuel mainInp f rest
            { mem := endMem, frameDepth := 1, remainingBits := [], unitCost := u_f, peakCellSpace := sp_f }) := by
  intro copyBody j
  suffices hrem : ∀ (rem j : ℕ), j + rem = d + 1 →
      ∀ (curMem : ArithRAMMemory) (u_c sp_c : ℕ) (rest : List ArithRAMCont),
        curMem.words.read (.localFrame 1 0 1) = (j : ℤ) →
        (∀ c < d + 1, curMem.reals.read (.localFrame 1 1 (c : ℤ)) = vals c) →
        (∀ loc, loc.keepAtDepth 0 = true →
          (loc ∈ curMem.words.live ↔ loc ∈ m₀.words.live) ∧ curMem.words.vals loc = m₀.words.vals loc) →
        (∀ loc, loc.keepAtDepth 0 = true →
          (loc ∈ curMem.reals.live ↔ loc ∈ (writeOutCoords scrR outOff vals j m₀).reals.live) ∧
          curMem.reals.vals loc = (writeOutCoords scrR outOff vals j m₀).reals.vals loc) →
        curMem.cellCount + 2 * rem ≤ S_cap →
        ∃ (k u_f sp_f : ℕ) (endMem : ArithRAMMemory),
          (∀ loc, loc.keepAtDepth 0 = true →
            (loc ∈ endMem.words.live ↔ loc ∈ m₀.words.live) ∧ endMem.words.vals loc = m₀.words.vals loc) ∧
          (∀ loc, loc.keepAtDepth 0 = true →
            (loc ∈ endMem.reals.live ↔ loc ∈ (writeOutCoords scrR outOff vals (d + 1) m₀).reals.live) ∧
            endMem.reals.vals loc = (writeOutCoords scrR outOff vals (d + 1) m₀).reals.vals loc) ∧
          u_f ≤ u_c + 16 * rem ∧
          sp_f ≤ max sp_c (mainInp.inputCellSpace + S_cap) ∧
          (∀ f : ℕ,
            runArithRAMFuel mainInp (f + k) (.repeatLoop rem copyBody :: rest)
              { mem := curMem, frameDepth := 1, remainingBits := [], unitCost := u_c, peakCellSpace := sp_c } =
            runArithRAMFuel mainInp f rest
              { mem := endMem, frameDepth := 1, remainingBits := [], unitCost := u_f, peakCellSpace := sp_f }) by
    intro hj curMem u_c sp_c rest hctr hloc1 hw hr hcc
    exact hrem ((d + 1) - j) j (by omega) curMem u_c sp_c rest hctr hloc1 hw hr hcc
  intro rem
  induction rem with
  | zero =>
      intro j hj curMem u_c sp_c rest _ _ hw hr _
      have hj_eq : j = d + 1 := by omega
      subst hj_eq
      refine ⟨1, u_c, sp_c, curMem, hw, hr, by omega, le_max_left _ _, fun f => ?_⟩
      simp [runArithRAMFuel]
  | succ r ih =>
      intro j hj curMem u_c sp_c rest hctr hloc1 hw hr hcc
      have hj_lt : j < d + 1 := by omega
      let mem1 : ArithRAMMemory :=
        { curMem with reals := curMem.reals.write (.heap scrR (outOff + (j : ℤ))) (vals j) }
      let sp1 : ℕ := max sp_c (mainInp.inputCellSpace + mem1.cellCount)
      let mem2 : ArithRAMMemory :=
        { mem1 with words := mem1.words.write (.localFrame 1 0 1) ((j : ℤ) + 1) }
      let sp2 : ℕ := max sp1 (mainInp.inputCellSpace + mem2.cellCount)
      have hcc1 : mem1.cellCount ≤ curMem.cellCount + 1 :=
        cellCount_writeReal_le curMem (.heap scrR (outOff + (j : ℤ))) (vals j)
      have hcc2 : mem2.cellCount ≤ mem1.cellCount + 1 :=
        cellCount_writeWord_le mem1 (.localFrame 1 0 1) ((j : ℤ) + 1)
      have hctr2 : mem2.words.read (.localFrame 1 0 1) = ((j + 1 : ℕ) : ℤ) := by
        simp only [mem2, WordStore.read, WordStore.write, Finset.mem_insert, true_or, ↓reduceIte,
          Function.update_self]
        push_cast; ring
      have hloc1_2 : ∀ c < d + 1, mem2.reals.read (.localFrame 1 1 (c : ℤ)) = vals c := by
        intro c hc
        have hne : RAMCellLoc.localFrame 1 1 (c : ℤ) ≠ .heap scrR (outOff + (j : ℤ)) := by
          intro h; cases h
        change mem1.reals.read (.localFrame 1 1 (c : ℤ)) = vals c
        simp only [mem1, RealStore.read, RealStore.write, Finset.mem_insert, hne, false_or,
          Function.update_of_ne hne]
        exact hloc1 c hc
      have hw2 : ∀ loc, loc.keepAtDepth 0 = true →
          (loc ∈ mem2.words.live ↔ loc ∈ m₀.words.live) ∧ mem2.words.vals loc = m₀.words.vals loc := by
        intro loc hk
        have hne : loc ≠ .localFrame 1 0 1 := by
          intro h; subst h; simp [RAMCellLoc.keepAtDepth] at hk
        simp only [mem2, mem1, WordStore.write, Finset.mem_insert, hne, false_or,
          Function.update_of_ne hne]
        exact hw loc hk
      have hr2 : ∀ loc, loc.keepAtDepth 0 = true →
          (loc ∈ mem2.reals.live ↔ loc ∈ (writeOutCoords scrR outOff vals (j + 1) m₀).reals.live) ∧
          mem2.reals.vals loc = (writeOutCoords scrR outOff vals (j + 1) m₀).reals.vals loc := by
        intro loc hk
        dsimp only [mem2, mem1, writeOutCoords, H3a.rWrite]
        by_cases heq : loc = .heap scrR (outOff + (j : ℤ))
        · subst heq; simp [RealStore.write]
        · simp only [RealStore.write, Finset.mem_insert, heq, false_or, Function.update_of_ne heq]
          exact hr loc hk
      obtain ⟨k, u_f, sp_f, endMem, hwf, hrf, huf, hspf, hstep⟩ :=
        ih (j + 1) (by omega) mem2 (u_c + 14) sp2 rest hctr2 hloc1_2 hw2 hr2 (by omega)
      refine ⟨k + 4, u_f, sp_f, endMem, hwf, hrf, by omega, ?_, fun f => ?_⟩
      · refine hspf.trans ?_
        dsimp [sp2, sp1]; omega
      · rw [show f + (k + 4) = (((f + k) + 1) + 1) + 1 + 1 by omega]
        have hread1 : curMem.reals.read (.localFrame 1 1 (j : ℤ)) = vals j := hloc1 j hj_lt
        simp only [copyBody, runArithRAMFuel, evalIntExpr, evalRealExpr, hctr, hread1]
        convert hstep f using 2

private lemma popDepth_eq_of_keep0 {m m_ref : ArithRAMMemory} (hclean : CleanMem m_ref)
    (hw : ∀ loc, loc.keepAtDepth 0 = true →
      (loc ∈ m.words.live ↔ loc ∈ m_ref.words.live) ∧ m.words.vals loc = m_ref.words.vals loc)
    (hr : ∀ loc, loc.keepAtDepth 0 = true →
      (loc ∈ m.reals.live ↔ loc ∈ m_ref.reals.live) ∧ m.reals.vals loc = m_ref.reals.vals loc) :
    m.popDepth 0 = m_ref := by
  rw [← hclean]
  unfold ArithRAMMemory.popDepth WordStore.popDepth RealStore.popDepth
  congr 1
  · congr 1
    · ext loc; simp only [Finset.mem_filter]
      exact ⟨fun ⟨hl, hk⟩ => ⟨(hw loc hk).1.mp hl, hk⟩, fun ⟨hl, hk⟩ => ⟨(hw loc hk).1.mpr hl, hk⟩⟩
    · funext loc; by_cases hk : loc.keepAtDepth 0 = true
      · simp [hk, (hw loc hk).2]
      · simp [hk]
  · congr 1
    · ext loc; simp only [Finset.mem_filter]
      exact ⟨fun ⟨hl, hk⟩ => ⟨(hr loc hk).1.mp hl, hk⟩, fun ⟨hl, hk⟩ => ⟨(hr loc hk).1.mpr hl, hk⟩⟩
    · funext loc; by_cases hk : loc.keepAtDepth 0 = true
      · simp [hk, (hr loc hk).2]
      · simp [hk]

private lemma no_local1_words_of_clean {m : ArithRAMMemory} (hc : CleanMem m) (v : ℕ) (i : ℤ) :
    RAMCellLoc.localFrame 1 v i ∉ m.words.live := by
  intro hmem
  have hlive : Finset.filter (fun l => l.keepAtDepth 0 = true) m.words.live = m.words.live :=
    congrArg (fun x => x.words.live) hc
  rw [← hlive, Finset.mem_filter] at hmem
  simp [RAMCellLoc.keepAtDepth] at hmem

private lemma no_local1_reals_of_clean {m : ArithRAMMemory} (hc : CleanMem m) (v : ℕ) (i : ℤ) :
    RAMCellLoc.localFrame 1 v i ∉ m.reals.live := by
  intro hmem
  have hlive : Finset.filter (fun l => l.keepAtDepth 0 = true) m.reals.live = m.reals.live :=
    congrArg (fun x => x.reals.live) hc
  rw [← hlive, Finset.mem_filter] at hmem
  simp [RAMCellLoc.keepAtDepth] at hmem

/-- **Master Scoped HPJ19 Execution Theorem (`exec_embedHPJStmt`)**:
Executes `UL.Proof_cit_hpj19_thm18.hpjProg` inside `.localScope` reading sample indices from
`tblSamp`, pool coordinates from `tblPts`, and random walk bits from `tblCoins`, writing the
exact `radonWalkOutput` coordinates `0 .. d` to `realHeap scrR [outOff .. outOff + d]` and wiping
all local cells on `.popScope 0`! -/
theorem exec_embedHPJStmt {d : ℕ}
    (TW BW TR BR scrW scrR tblSamp tblPts tblCoins : ℕ)
    (outOff offSamp offPts offCoins : ℤ)
    (mainInp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (phiRat : ℚ) (hφ0 : 0 < (phiRat : ℝ)) (hφ1 : (phiRat : ℝ) < 1 / 2)
    (P : HPJParams) (hP_eq : P = hpjParams d (phiRat : ℝ)) (hP : HPJParamProps d (phiRat : ℝ) P)
    (sz : ℕ) (hsz : 1 ≤ sz)
    (poolPt : Fin sz → EuclideanSpace ℝ (Fin d))
    (N_samp : ℕ) (hmN : 2 ^ P.q ≤ N_samp)
    (ω : Fin N_samp → Fin sz)
    (bits : Fin (P.L * (d + 1 + 3) * P.q) → Bool)
    (C : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrR : scrR < TR) (hout0 : 0 ≤ outOff) (houtB : outOff + ((d + 1 : ℕ) : ℤ) ≤ (BR : ℤ))
    (hsamp_mem : ∀ k : Fin N_samp, wRead m₀ tblSamp (offSamp + (k.val : ℤ)) = ((ω k).val : ℤ))
    (hpts_mem : ∀ (i : Fin sz) (c : Fin d),
      rRead m₀ tblPts (offPts + ((i.val : ℤ) * (d : ℤ) + (c.val : ℤ))) = euclideanCoord (poolPt i) c)
    (hcoins_mem : ∀ j : Fin (P.L * (d + 1 + 3) * P.q),
      wRead m₀ tblCoins (offCoins + (j.val : ℤ)) = if bits j then 1 else 0)
    (hScap : m₀.cellCount + Nat.ceil (hpjOpBound d (phiRat : ℝ)) + 2 * d + 6 ≤ TW * BW + TR * BR)
    (hC : 15 * Nat.ceil (hpjOpBound d (phiRat : ℝ)) + 16 * d + 40 ≤ C) :
    let z_out : EuclideanSpace ℝ (Fin (d + 1)) :=
      radonWalkOutput (d + 1) P.q P.L
        (fun j : Fin (2 ^ P.q) => paraboloidLift (poolPt (ω ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩)))
        bits
    ExecScratch TW BW TR BR scrW scrR mainInp
      (embedHPJStmt scrR tblSamp tblPts tblCoins outOff offSamp offPts offCoins N_samp sz phiRat)
      m₀
      (fun m₁ =>
        (∀ j : Fin (d + 1), rRead m₁ scrR (outOff + (j.val : ℤ)) = euclideanCoord z_out j) ∧
        (∀ idx : ℤ, (idx < outOff ∨ outOff + ((d + 1 : ℕ) : ℤ) ≤ idx) →
          rRead m₁ scrR idx = rRead m₀ scrR idx) ∧
        (∀ i : ℤ, wRead m₁ scrW i = wRead m₀ scrW i))
      C := by
  classical
  intro z_out
  haveI : Nonempty (Fin sz) := ⟨⟨0, by omega⟩⟩
  let handleEmb : Fin sz ↪ ℕ := ⟨Fin.val, Fin.val_injective⟩
  have hspec :=
    (hpjProg_spec hφ0 hφ1 P hP_eq hP (Fin sz) poolPt handleEmb N_samp hmN ω).2 bits
  rcases hspec with ⟨out, hrun, hout_cost_r, hread_out⟩
  have hout_cost : out.unitCost ≤ Nat.ceil (hpjOpBound d (phiRat : ℝ)) := by
    exact_mod_cast hout_cost_r.trans (Nat.le_ceil _)
  let fakeInp : ArithRAMInput d :=
    { intParams := List.ofFn (fun k : Fin N_samp => ((ω k).val : ℤ))
      activeHandles := (Finset.univ : Finset (Fin sz)).map handleEmb
      activeCoords := fun h =>
        if hh : ∃ i : Fin sz, i.val = h then poolPt (Classical.choose hh) else 0
      extraReals := [(phiRat : ℝ)] }
  let hpjInitSt : ArithRAMExecState :=
    { mem := ArithRAMMemory.empty.popDepth 0
      frameDepth := 0
      remainingBits := List.ofFn bits
      unitCost := 0
      peakCellSpace := fakeInp.inputCellSpace + (ArithRAMMemory.empty.popDepth 0).cellCount }
  have hrun_fake : runArithRAMWithBits hpjProg fakeInp ArithRAMMemory.empty (List.ofFn bits) = some out := by
    convert hrun using 2
    dsimp [fakeInp, handleEmb]
    congr 1; funext h
    by_cases hh : ∃ i : Fin sz, i.val = h
    · rw [dif_pos hh, dif_pos hh]
    · rw [dif_neg hh, dif_neg hh]
  -- Extract halting fuel from `runArithRAMWithBits = some out`
  have hfuel : ∃ fuel : ℕ, runArithRAMFuel fakeInp fuel [.stmt hpjProg] hpjInitSt = .halted out := by
    clear hrun; rename_i _
    have hrun := hrun_fake
    unfold runArithRAMWithBits at hrun
    dsimp only at hrun
    split_ifs at hrun with hex
    obtain ⟨out₁, hf₁⟩ := Nat.find_spec hex
    change (match runArithRAMFuel fakeInp (Nat.find hex) [.stmt hpjProg] hpjInitSt with
      | .halted o => some o | _ => none) = some out at hrun
    rw [hf₁] at hrun
    injection hrun with heq
    subst heq
    exact ⟨Nat.find hex, hf₁⟩
  rcases hfuel with ⟨fuel_hpj, hhalt_hpj⟩
  let B := P.L * (d + 1 + 3) * P.q
  let S_cap := TW * BW + TR * BR
  let vals : ℕ → ℝ := fun j =>
    if hj : j < d + 1 then euclideanCoord z_out ⟨j, hj⟩ else 0
  let m₁ := writeOutCoords scrR outOff vals (d + 1) m₀
  have hm1_words : m₁.words = m₀.words := by
    dsimp [m₁]
    clear *-
    induction (d + 1) with
    | zero => rfl
    | succ k ih => dsimp [writeOutCoords, H3a.rWrite]; exact ih
  have hfp₁ : InFootprint TW BW TR BR m₁ :=
    writeOutCoords_footprint hfp₀ hscrR hout0 (d + 1) houtB
  have hpr₁ : PreservesNonScratch scrW scrR m₀ m₁ :=
    writeOutCoords_preserves m₀ (d + 1)
  have hpost₁ :
      (∀ j : Fin (d + 1), rRead m₁ scrR (outOff + (j.val : ℤ)) = euclideanCoord z_out j) ∧
      (∀ idx : ℤ, (idx < outOff ∨ outOff + ((d + 1 : ℕ) : ℤ) ≤ idx) →
        rRead m₁ scrR idx = rRead m₀ scrR idx) ∧
      (∀ i : ℤ, wRead m₁ scrW i = wRead m₀ scrW i) := by
    refine ⟨fun j => ?_, fun idx hidx => writeOutCoords_read_outside m₀ (d + 1) idx hidx,
            fun i => writeOutCoords_wRead scrR outOff vals m₀ (d + 1) scrW i⟩
    rw [writeOutCoords_read_self m₀ (d + 1) j.val j.isLt]
    dsimp only [vals]; rw [dif_pos j.isLt]
  -- Now construct `ExecScratch` (`⟨m₁, ⟨hpr₁, hpost₁⟩, hfp₁, StepTo⟩`)
  refine ⟨m₁, ⟨hpr₁, hpost₁⟩, hfp₁, hfp₁.1, hfp₁.cellCount_le, fun rest u₀ sp₀ => ?_⟩
  -- Initial local write `.writeWordLocal 0 0 0` inside `.localScope` (where `m₀.popDepth 0 = m₀`)
  let mem_init : ArithRAMMemory := { m₀ with words := m₀.words.write (.localFrame 1 0 0) 0 }
  let sp_init : ℕ := max sp₀ (mainInp.inputCellSpace + mem_init.cellCount)
  have hcpl_init : Coupled m₀ B 0 (ArithRAMMemory.empty.popDepth 0) mem_init :=
    Coupled.init m₀ B (no_local1_words_of_clean hfp₀.1) (no_local1_reals_of_clean hfp₀.1)
  have hcc_empty : (ArithRAMMemory.empty.popDepth 0).cellCount ≤ 0 := by
    simp [ArithRAMMemory.empty, ArithRAMMemory.popDepth, ArithRAMMemory.cellCount,
      WordStore.empty, WordStore.popDepth, WordStore.cellCount,
      RealStore.empty, RealStore.popDepth, RealStore.cellCount]
  have hcc_init : mem_init.cellCount ≤ S_cap := by
    have := hcpl_init.cellCount_le; omega
  let copyBody : ArithRAMStmt :=
    .seq
      (.writeRealHeap scrR (.add (.lit outOff) (.readLocal 0 (.lit 1)))
        (.readRealLocal 1 (.readLocal 0 (.lit 1))))
      (.writeWordLocal 0 (.lit 1) (.add (.readLocal 0 (.lit 1)) (.lit 1)))
  let afterHPJStack : List ArithRAMCont :=
    [.stmt (.seq (.writeWordLocal 0 (.lit 1) (.lit 0)) (.repeatN (.add .dim (.lit 1)) copyBody)),
     .popScope 0] ++ rest
  obtain ⟨k_hpj, u_m', sp_m', mainMem', hpjEndMem, hout_mem, hcpl_end, hcc_end, hu_m', hsp_m', hsim⟩ :=
    reloc_sim_fuel mainInp fakeInp tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz B phiRat
      bits poolPt ω rfl rfl rfl rfl m₀ S_cap hsamp_mem hpts_mem hcoins_mem afterHPJStack
      fuel_hpj [.stmt hpjProg] hpjInitSt out 0 (u₀ + 3) sp_init mem_init
      (fun it hit => by rcases List.mem_singleton.mp hit with rfl; exact isPureHPJStmt_hpjProg)
      rfl (by simp [hpjInitSt]) hcc_empty (by omega) hcpl_init hhalt_hpj
  -- Verify `mainMem'.reals.read (.localFrame 1 1 (c : ℤ)) = vals c` for `c < d + 1`
  have hvals_loc1 : ∀ c < d + 1, mainMem'.reals.read (.localFrame 1 1 (c : ℤ)) = vals c := by
    intro c hc
    rw [hcpl_end.2.2.2.1 0 (by omega) (c : ℤ)]
    have hpop_read : out.mem.reals.read (.heap 0 (c : ℤ)) = hpjEndMem.reals.read (.heap 0 (c : ℤ)) := by
      rw [hout_mem]
      simp [ArithRAMMemory.popDepth, RealStore.popDepth, RealStore.read, RAMCellLoc.keepAtDepth]
    rw [← hpop_read]
    dsimp only [vals]
    rw [dif_pos hc]
    let ic : Fin (d + 1) := ⟨c, hc⟩
    change out.mem.reals.read (.heap 0 (ic.val : ℤ)) = euclideanCoord z_out ic
    have hcoord := congrArg (fun v => euclideanCoord v ic) hread_out
    dsimp only at hcoord
    rw [← hcoord]
    refine Fin.lastCases ?_ ?_ ic
    · simp [liftedPoint, euclideanCoord, Fin.snoc_last]
    · intro j
      simp [liftedPoint, euclideanCoord, Fin.snoc_castSucc]
  -- Next: `.seq` -> `.writeWordLocal 0 1 0` -> `.repeatN (.add .dim 1)` -> `copyOut_loop_fuel` -> `.popScope 0`
  let mem_pre : ArithRAMMemory := { mainMem' with words := mainMem'.words.write (.localFrame 1 0 1) 0 }
  let sp_pre : ℕ := max sp_m' (mainInp.inputCellSpace + mem_pre.cellCount)
  have hcc_main' : mainMem'.cellCount ≤ m₀.cellCount + 1 + out.unitCost := by
    have := hcpl_end.cellCount_le; omega
  have hcc_pre : mem_pre.cellCount ≤ mainMem'.cellCount + 1 :=
    cellCount_writeWord_le mainMem' (.localFrame 1 0 1) 0
  have hw_pre : ∀ loc, loc.keepAtDepth 0 = true →
      (loc ∈ mem_pre.words.live ↔ loc ∈ m₀.words.live) ∧ mem_pre.words.vals loc = m₀.words.vals loc := by
    intro loc hk
    have hne : loc ≠ .localFrame 1 0 1 := by
      intro h; subst h; simp [RAMCellLoc.keepAtDepth] at hk
    simp only [mem_pre, WordStore.write, Finset.mem_insert, hne, false_or, Function.update_of_ne hne]
    exact hcpl_end.2.2.2.2.1 loc hk
  obtain ⟨k_cp, u_cp, sp_cp, endMem, hwf, hrf, hucp, hspcp, hcp⟩ :=
    copyOut_loop_fuel mainInp scrR outOff m₀ S_cap vals 0 (by omega) mem_pre (u_m' + 6) sp_pre
      (.popScope 0 :: rest)
      (by simp [mem_pre, WordStore.read, WordStore.write])
      (fun c hc => hvals_loc1 c hc)
      hw_pre
      hcpl_end.2.2.2.2.2.1
      (by omega)
  have hwf1 : ∀ loc, loc.keepAtDepth 0 = true →
      (loc ∈ endMem.words.live ↔ loc ∈ m₁.words.live) ∧ endMem.words.vals loc = m₁.words.vals loc := by
    rw [hm1_words]; exact hwf
  have hpop_eq : endMem.popDepth 0 = m₁ := popDepth_eq_of_keep0 hfp₁.1 hwf1 hrf
  refine ⟨k_cp + k_hpj + 8, u_cp, sp_cp, ?_, ?_, fun f => ?_⟩
  · dsimp [hpjInitSt] at hu_m'; omega
  · refine hspcp.trans ?_
    have h1 : sp_pre ≤ max sp_m' (mainInp.inputCellSpace + S_cap) := max_le_max le_rfl (by omega)
    have h2 : sp_init ≤ max sp₀ (mainInp.inputCellSpace + S_cap) := max_le_max le_rfl (by omega)
    omega
  · -- Trace exact fuel steps: 4 pre-HPJ + k_hpj + 3 pre-copy + k_cp + 1 popScope = k_cp + k_hpj + 8
    have hclean0 : m₀.popDepth 0 = m₀ := hfp₀.1
    have hs1 : ∀ g, runArithRAMFuel mainInp (g + 4) (.stmt (embedHPJStmt scrR tblSamp tblPts tblCoins outOff offSamp offPts offCoins N_samp sz phiRat) :: rest)
        { mem := m₀, frameDepth := 0, remainingBits := [], unitCost := u₀, peakCellSpace := sp₀ } =
      runArithRAMFuel mainInp g (([.stmt hpjProg].map (relocCont tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat)) ++ afterHPJStack)
        { mem := mem_init, frameDepth := 1, remainingBits := [], unitCost := u₀ + 3, peakCellSpace := sp_init } := by
      intro g
      rw [show g + 4 = (((g + 1) + 1) + 1) + 1 by omega]
      simp only [embedHPJStmt, runArithRAMFuel, hclean0, evalIntExpr, List.map_cons, List.map_nil,
        List.cons_append, List.nil_append, relocCont, afterHPJStack]
      rfl
    have hs3 : ∀ g, runArithRAMFuel mainInp (g + 3) afterHPJStack
        { mem := mainMem', frameDepth := 1, remainingBits := [], unitCost := u_m', peakCellSpace := sp_m' } =
      runArithRAMFuel mainInp g (.repeatLoop (d + 1) copyBody :: .popScope 0 :: rest)
        { mem := mem_pre, frameDepth := 1, remainingBits := [], unitCost := u_m' + 6, peakCellSpace := sp_pre } := by
      intro g
      rw [show g + 3 = ((g + 1) + 1) + 1 by omega]
      have hpos : (0 : ℤ) ≤ (d : ℤ) + 1 := by omega
      have htonat : ((d : ℤ) + 1).toNat = d + 1 := by omega
      simp only [afterHPJStack, List.cons_append, List.nil_append, runArithRAMFuel, evalIntExpr,
        hpos, ↓reduceIte, htonat]
      congr 2
    rw [show f + (k_cp + k_hpj + 8) = (((f + 1 + k_cp) + 3) + k_hpj) + 4 by omega]
    rw [hs1, hsim, hs3]
    have hcp_step := hcp (f + 1)
    simp only [Nat.sub_zero] at hcp_step
    rw [hcp_step]
    simp only [runArithRAMFuel, hpop_eq]

end UL.Proof.clm_9_1_explicit_tradeoff.H3b3
