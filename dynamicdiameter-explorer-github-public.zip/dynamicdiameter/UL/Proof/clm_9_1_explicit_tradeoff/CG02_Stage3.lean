import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3A
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H1
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
open UL.Proof.clm_9_1_explicit_tradeoff.CG20

/-! ### 3. Fast Condition Evaluators & Single-Slot Stage 3 Step (`stage3AtStmt`) -/

private lemma evalCond_lit_lt_heap {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (tbl : ℕ) (idx v : ℤ) :
    (evalArithCond inp 0 m (.intLt (.lit v) (.readHeap tbl (.lit idx)))).1 =
      decide (v < wRead m tbl idx) := rfl

private lemma evalCond_heap_eq_lit {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (tbl : ℕ) (idx v : ℤ) :
    (evalArithCond inp 0 m (.intEq (.readHeap tbl (.lit idx)) (.lit v))).1 =
      decide (wRead m tbl idx = v) := rfl

private lemma evalCond_heap_le_lit {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (tbl : ℕ) (idx v : ℤ) :
    (evalArithCond inp 0 m (.intLe (.readHeap tbl (.lit idx)) (.lit v))).1 =
      decide (wRead m tbl idx ≤ v) := rfl

private lemma evalCond_heap_le_mul {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (tbl : ℕ) (i₁ i₂ k : ℤ) :
    (evalArithCond inp 0 m
      (.intLe (.readHeap tbl (.lit i₁)) (.mul (.lit k) (.readHeap tbl (.lit i₂))))).1 =
      decide (wRead m tbl i₁ ≤ k * wRead m tbl i₂) := rfl

def stage3AtNoneStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 10) (.readHeap engMetaTbl (.lit (servSlotOff r.val))))
  (.seq (ops.readNodeScalarStmt .birthSize 10 11)
  (.seq (ops.readNodeScalarStmt .age 10 12)
    (.ite (.intLe (.readHeap engScrTbl (.lit 11))
                  (.mul (.lit (((64 * K_alpha d : ℕ) : ℤ))) (.readHeap engScrTbl (.lit 12))))
      (.seq (ops.readNodeScalarStmt .denseLen 10 13)
        (.ite (.intLe (.readHeap engScrTbl (.lit 13)) (.lit (cp.B_scan : ℤ)))
          (truncateAtStage3Stmt ops r)
          (openCopyJobStage3Stmt ops r)))
      .skip)))

theorem zeroRand_stage3AtNoneStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (stage3AtNoneStmt ops r) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (ops.zeroRand_readNodeScalar .birthSize 10 11)
      (.seq (ops.zeroRand_readNodeScalar .age 10 12)
        (.ite
          (.seq (ops.zeroRand_readNodeScalar .denseLen 10 13)
            (.ite (zeroRand_truncateAtStage3Stmt ops r)
                  (zeroRand_openCopyJobStage3Stmt ops r)))
          .skip)))

theorem exec_stage3AtNoneStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {cur : ChainEngineState cp} {m₀ : ArithRAMMemory}
    (hr : r.val < cur.serving.length)
    (hjb_r : cur.jobs r = none)
    (hsd : ServingDenseWF cp cur)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops cur m₀) :
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (stage3AtNoneStmt ops r) m₀
      (fun m₁ =>
        EncChainEngine ops (stage3At cp cur r) m₁ ∧
        (∀ t < 6, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ rt < 3, ∀ i, rRead m₁ rt i = rRead m₀ rt i))
      (160 + 4 * ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12) := by
  have hTW := ops.hTW
  have hBW_scr := ops.hBW_scr
  rcases henc₀.2.2.2.2.2.2.2.2 with ⟨servSlots, readySlots, curSlots, hslen₀, hserv₀, _, _, hall_lt⟩
  have hrs : r.val < servSlots.length := hslen₀.symm ▸ hr
  let mn := cur.serving[r.val]'hr
  let cSlot := servSlots[r.val]'hrs
  have hcSlot_lt : cSlot < M_slots cp :=
    hall_lt cSlot (List.mem_append_left _ (List.getElem_mem hrs))
  unfold stage3AtNoneStmt
  -- Step 1: Load `cSlot` into `engScrTbl[10]`
  refine ExecDet.seq' (148 + 4 * ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 10) (.readHeap engMetaTbl (.lit (servSlotOff r.val)))
      10 (cSlot : ℤ) hfp₀ (by unfold engScrTbl; omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) rfl
      (by simp only [evalIntExpr]; exact (hserv₀ r.val hr hrs).1)
      (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m₁ hm₁ hfp₁; subst hm₁
  let m₁_st := H3a.wWrite m₀ engScrTbl 10 (cSlot : ℤ)
  have hw9_1 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m₁_st t i = wRead m₀ t i :=
    fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
  have hr_1 : ∀ t i, rRead m₁_st t i = rRead m₀ t i := fun t i => rRead_wWrite _ _ _ _ _ _
  have hsr₁ : ops.SlotsReady m₁_st :=
    ops.slotsReady_ext m₀ m₁_st henc₀.1 hw9_1 (fun t _ _ i => hr_1 t i)
  have hnd₁ : ∀ mn' s, s < M_slots cp → ops.EncNode mn' s m₀ → ops.EncNode mn' s m₁_st :=
    fun mn' s _ he => ops.encNode_ext mn' s m₀ m₁_st he hw9_1 (fun t _ _ i => hr_1 t i)
      (fun _ _ _ _ => hr_1 ptsRTbl _)
  -- Step 2: Read `birthSize` into `11`
  refine ExecDet.seq' (148 + 3 * ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12)
    (ops.readNodeScalar_spec inp m₁_st mn cSlot .birthSize 10 11
      hcSlot_lt (by omega) (by omega) (by omega) (by omega)
      hfp₁ hsr₁ (hnd₁ mn cSlot hcSlot_lt (hserv₀ r.val hr hrs).2)
      (wRead_wWrite_self _ _ _ _))
    (by omega) ?_
  intro m₂ ⟨hsr₂, hr11, hnd₂, hft₂, hfs₂, hfr₂⟩ hfp₂
  dsimp [evalNodeScalar] at hr11
  -- Step 3: Read `age` into `12`
  refine ExecDet.seq' (148 + 2 * ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12)
    (ops.readNodeScalar_spec inp m₂ mn cSlot .age 10 12
      hcSlot_lt (by omega) (by omega) (by omega) (by omega)
      hfp₂ hsr₂ (hnd₂ mn cSlot hcSlot_lt (hnd₁ mn cSlot hcSlot_lt (hserv₀ r.val hr hrs).2))
      ((hfs₂ 10 (by decide)).trans (wRead_wWrite_self _ _ _ _)))
    (by omega) ?_
  intro m₃ ⟨hsr₃, hr12, hnd₃, hft₃, hfs₃, hfr₃⟩ hfp₃
  dsimp [evalNodeScalar] at hr12
  have hr11_3 : wRead m₃ engScrTbl 11 = (mn.nd.birthSize : ℤ) :=
    (hfs₃ 11 (by decide)).trans hr11
  have hr10_3 : wRead m₃ engScrTbl 10 = (cSlot : ℤ) :=
    (hfs₃ 10 (by decide)).trans ((hfs₂ 10 (by decide)).trans (wRead_wWrite_self _ _ _ _))
  have hw_03 : ∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₃ t i = wRead m₀ t i :=
    fun t ht9 ht8 i => (hft₃ t ht9 ht8 i).trans
      ((hft₂ t ht9 ht8 i).trans (wRead_wWrite_of_ne _ _ (Or.inl ht8)))
  have hr_03 : ∀ t < 3, ∀ i, rRead m₃ t i = rRead m₀ t i :=
    fun t ht3 i => (hfr₃ t ht3 i).trans ((hfr₂ t ht3 i).trans (hr_1 t i))
  have henc₃ : EncChainEngine ops cur m₃ :=
    encChainEngine_ext_scr henc₀ hsr₃
      (fun mn' s hs he => hnd₃ mn' s hs (hnd₂ mn' s hs (hnd₁ mn' s hs he)))
      hw_03 hr_03
  refine ExecDet.ite_le (C_c := 12)
    (C_b := 130 + 2 * ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12)
    _ _ _ (by simp [condExprOps, intExprOps])
    (fun haged_b => ?_) (fun hfresh_b => ?_) (by omega)
  · rw [evalCond_heap_le_mul, hr11_3, hr12, ← Nat.cast_mul] at haged_b
    have haged : mn.nd.birthSize ≤ 64 * K_alpha d * mn.nd.age :=
      Int.ofNat_le.mp (of_decide_eq_true haged_b)
    -- Step 4: Read `denseLen` into `13`
    refine ExecDet.seq' (130 + ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12)
      (ops.readNodeScalar_spec inp m₃ mn cSlot .denseLen 10 13
        hcSlot_lt (by omega) (by omega) (by omega) (by omega)
        hfp₃ hsr₃
        (hnd₃ mn cSlot hcSlot_lt (hnd₂ mn cSlot hcSlot_lt
          (hnd₁ mn cSlot hcSlot_lt (hserv₀ r.val hr hrs).2)))
        hr10_3)
      (by omega) ?_
    intro m₄ ⟨hsr₄, hr13, hnd₄, hft₄, _, hfr₄⟩ hfp₄
    dsimp [evalNodeScalar] at hr13
    have hw_04 : ∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₄ t i = wRead m₀ t i :=
      fun t ht9 ht8 i => (hft₄ t ht9 ht8 i).trans (hw_03 t ht9 ht8 i)
    have hr_04 : ∀ t < 3, ∀ i, rRead m₄ t i = rRead m₀ t i :=
      fun t ht3 i => (hfr₄ t ht3 i).trans (hr_03 t ht3 i)
    have henc₄ : EncChainEngine ops cur m₄ :=
      encChainEngine_ext_scr henc₃ hsr₄ hnd₄ hft₄ hfr₄
    refine ExecDet.ite_le (C_c := 10)
      (C_b := C_truncateStage3 ops)
      _ _ _ (by simp [condExprOps, intExprOps])
      (fun hsmall_b => ?_) (fun hbig_b => ?_)
      (by unfold C_truncateStage3; omega)
    · rw [evalCond_heap_le_lit, hr13] at hsmall_b
      have hsmall : mn.nd.denseArr.length ≤ cp.B_scan :=
        Int.ofNat_le.mp (of_decide_eq_true hsmall_b)
      have hst_eq : stage3At cp cur r =
          { cur with
            serving := cur.serving.take r.val
            jobs := fun rr => if rr.val < r.val then cur.jobs rr else none
            leafArr := mn.nd.denseArr
            leafOverflow := false } := by
        unfold stage3At
        rw [dif_pos hr, hjb_r]
        dsimp only
        rw [if_pos haged, if_pos hsmall]
      refine (exec_truncateAtStage3Stmt ops inp r hr hsd hsmall hfp₄ henc₄).mono
        (fun m₅ ⟨henc₅, hw₅, hr₅⟩ _ => ?_) le_rfl
      rw [← hst_eq] at henc₅
      exact ⟨henc₅,
        fun t ht6 i => (hw₅ t ht6 i).trans (hw_04 t (by omega) (by unfold engScrTbl; omega) i),
        fun rt hrt i => (hr₅ rt hrt i).trans (hr_04 rt hrt i)⟩
    · rw [evalCond_heap_le_lit, hr13] at hbig_b
      have hbig : ¬ mn.nd.denseArr.length ≤ cp.B_scan :=
        fun hle => of_decide_eq_false hbig_b (Int.ofNat_le.mpr hle)
      have hst_eq : stage3At cp cur r =
          { cur with
            jobs := Function.update cur.jobs r
              (some { ready := [], phase := .copy (CopyState.init mn.histArr.length) }) } := by
        unfold stage3At
        rw [dif_pos hr, hjb_r]
        dsimp only
        rw [if_pos haged, if_neg hbig]
      refine (exec_openCopyJobStage3Stmt ops inp r hr hjb_r hfp₄ henc₄).mono
        (fun m₅ ⟨henc₅, hw₅, hr₅⟩ _ => ?_)
        (by unfold C_openCopyStage3 C_truncateStage3; omega)
      rw [← hst_eq] at henc₅
      exact ⟨henc₅,
        fun t ht6 i => (hw₅ t ht6 i).trans (hw_04 t (by omega) (by unfold engScrTbl; omega) i),
        fun rt hrt i => (hr₅ rt hrt i).trans (hr_04 rt hrt i)⟩
  · rw [evalCond_heap_le_mul, hr11_3, hr12, ← Nat.cast_mul] at hfresh_b
    have hfresh : ¬ mn.nd.birthSize ≤ 64 * K_alpha d * mn.nd.age :=
      fun hle => of_decide_eq_false hfresh_b (Int.ofNat_le.mpr hle)
    have hst_eq : stage3At cp cur r = cur := by
      unfold stage3At
      rw [dif_pos hr, hjb_r]
      dsimp only
      rw [if_neg hfresh]
    refine ExecDet.skip inp hfp₃ ?_ (by omega)
    rw [hst_eq]
    exact ⟨henc₃,
      fun t ht6 i => hw_03 t (by omega) (by unfold engScrTbl; omega) i,
      hr_03⟩

def stage3AtStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  .ite (.intLt (.lit (r.val : ℤ)) (.readHeap engMetaTbl (.lit 0)))
    (.ite (.intEq (.readHeap engMetaTbl (.lit (jobMetaBase cp r.val))) (.lit 0))
      (stage3AtNoneStmt ops r)
      .skip)
    .skip

theorem zeroRand_stage3AtStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) :
    ZeroRandStmt (stage3AtStmt ops r) :=
  .ite (.ite (zeroRand_stage3AtNoneStmt ops r) .skip) .skip

def C_stage3At {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  180 + 4 * ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12

theorem exec_stage3AtStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {cur : ChainEngineState cp} {m₀ : ArithRAMMemory}
    (hsd : ServingDenseWF cp cur)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops cur m₀) :
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (stage3AtStmt ops r) m₀
      (fun m₁ =>
        EncChainEngine ops (stage3At cp cur r) m₁ ∧
        (∀ t < 6, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ rt < 3, ∀ i, rRead m₁ rt i = rRead m₀ rt i))
      (C_stage3At ops) := by
  have hserv_len₀ : wRead m₀ engMetaTbl 0 = (cur.serving.length : ℤ) := henc₀.2.2.2.2.2.2.2.1
  unfold stage3AtStmt C_stage3At
  refine ExecDet.ite_le (C_c := 10)
    (C_b := 170 + 4 * ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12)
    _ _ _ (by simp [condExprOps, intExprOps])
    (fun hlt_b => ?_) (fun hge_b => ?_) (by omega)
  · rw [evalCond_lit_lt_heap, hserv_len₀] at hlt_b
    have hr : r.val < cur.serving.length := Int.ofNat_lt.mp (of_decide_eq_true hlt_b)
    rcases henc₀.2.2.2.2.2.2.2.2 with ⟨_, _, _, _, _, hjobs₀, _, _⟩
    refine ExecDet.ite_le (C_c := 10)
      (C_b := 160 + 4 * ops.C_read + cp.B_scan * (ops.C_read + 120) + cp.D_max * 12)
      _ _ _ (by simp [condExprOps, intExprOps])
      (fun hnone_b => ?_) (fun hsome_b => ?_) (by omega)
    · rw [evalCond_heap_eq_lit] at hnone_b
      have hw_eq := of_decide_eq_true hnone_b
      have hjb_r : cur.jobs r = none := by
        have hjr := hjobs₀ r
        cases hopt : cur.jobs r with
        | none => rfl
        | some jb =>
            simp only [EncJobSlot, hopt] at hjr
            rw [hjr.1] at hw_eq
            omega
      exact exec_stage3AtNoneStmt ops inp r hr hjb_r hsd hfp₀ henc₀
    · rw [evalCond_heap_eq_lit] at hsome_b
      have hne0 := of_decide_eq_false hsome_b
      have hjb_some : ∃ jb, cur.jobs r = some jb := by
        have hjr := hjobs₀ r
        cases hopt : cur.jobs r with
        | none =>
            simp only [EncJobSlot, hopt] at hjr
            exact absurd hjr.2 hne0
        | some jb => exact ⟨jb, rfl⟩
      rcases hjb_some with ⟨jb, hjb⟩
      have hst_eq : stage3At cp cur r = cur := by
        unfold stage3At
        rw [dif_pos hr, hjb]
      refine ExecDet.skip inp hfp₀ ?_ (by omega)
      rw [hst_eq]
      exact ⟨henc₀, fun _ _ _ => rfl, fun _ _ _ => rfl⟩
  · rw [evalCond_lit_lt_heap, hserv_len₀] at hge_b
    have hnot_r : ¬ r.val < cur.serving.length :=
      fun hlt => of_decide_eq_false hge_b (Int.ofNat_lt.mpr hlt)
    have hst_eq : stage3At cp cur r = cur := by
      unfold stage3At
      rw [dif_neg hnot_r]
    refine ExecDet.skip inp hfp₀ ?_ (by omega)
    rw [hst_eq]
    exact ⟨henc₀, fun _ _ _ => rfl, fun _ _ _ => rfl⟩

/-! ### 4. Top-Level Stage 3 Statement, Execution Theorem & Cost Bound -/

def stepStage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  seqList (List.finRange cp.D_max) (stage3AtStmt ops)

abbrev stage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  stepStage3Stmt ops

theorem zeroRand_stepStage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (stepStage3Stmt ops) :=
  zeroRand_seqList _ _ (fun r _ => zeroRand_stage3AtStmt ops r)

theorem zeroRand_stage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (stage3Stmt ops) :=
  zeroRand_stepStage3Stmt ops

def C_stage3 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  1 + cp.D_max * C_stage3At ops

abbrev stepStage3Cost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  C_stage3 ops

abbrev stage3Cost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  C_stage3 ops

/-- Clean polynomial upper bound on `C_stage3 ops` in terms of `cp.D_max`, `cp.B_scan`, `ops.C_read`. -/
theorem C_stage3_le {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    C_stage3 ops ≤
      (cp.D_max + 1) * (180 + (cp.B_scan + 4) * (ops.C_read + 120) + 12 * cp.D_max) := by
  unfold C_stage3 C_stage3At
  nlinarith

theorem exec_stepStage3Stmt_of_servingWF {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d)
    {st₂ : ChainEngineState cp} {m₀ : ArithRAMMemory}
    (hsd₀ : ServingDenseWF cp st₂)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops st₂ m₀) :
    let st₃ := stepStage3 cp st₂
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (stepStage3Stmt ops) m₀
      (fun m₁ =>
        EncChainEngine ops st₃ m₁ ∧
        wRead m₁ 0 0 = wRead m₀ 0 0 ∧
        ArithRAMDynamicProgram.readReturnedHandle m₁ =
          ArithRAMDynamicProgram.readReturnedHandle m₀ ∧
        (∀ bits, MemHasStepCoins cp bits m₀ → MemHasStepCoins cp bits m₁) ∧
        (∀ t < 6, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ rt < 3, ∀ i, rRead m₁ rt i = rRead m₀ rt i))
      (C_stage3 ops) := by
  let Inv : ChainEngineState cp → ArithRAMMemory → Prop := fun cur m =>
    ServingDenseWF cp cur ∧
    EncChainEngine ops cur m ∧
    (∀ t < 6, ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ rt < 3, ∀ i, rRead m rt i = rRead m₀ rt i)
  have hInv₀ : Inv st₂ m₀ := ⟨hsd₀, henc₀, fun _ _ _ => rfl, fun _ _ _ => rfl⟩
  have hlen : (List.finRange cp.D_max).length = cp.D_max := List.length_finRange
  unfold stepStage3Stmt C_stage3
  refine (exec_seqList (List.finRange cp.D_max) (stage3AtStmt ops) (stage3At cp)
    Inv (C_stage3At ops) hfp₀ hInv₀ ?_).mono ?_ (by rw [hlen])
  · intro r _ cur m ⟨hsd, henc, hw, hr⟩ hfp
    refine (exec_stage3AtStmt ops inp r hsd hfp henc).mono ?_ le_rfl
    intro m' ⟨henc', hw', hr'⟩ _
    exact ⟨servingDenseWF_stage3At r hsd, henc',
      fun t ht6 i => (hw' t ht6 i).trans (hw t ht6 i),
      fun rt hrt i => (hr' rt hrt i).trans (hr rt hrt i)⟩
  · intro m₁ ⟨_, henc₁, hw₁, hr₁⟩ _
    have hst₃_eq : (List.finRange cp.D_max).foldl (stage3At cp) st₂ = stepStage3 cp st₂ := rfl
    rw [hst₃_eq] at henc₁
    have hw00 : wRead m₁ 0 0 = wRead m₀ 0 0 := hw₁ 0 (by decide) 0
    have hret : ArithRAMDynamicProgram.readReturnedHandle m₁ =
        ArithRAMDynamicProgram.readReturnedHandle m₀ := by
      have h00 : m₁.words.read (.heap 0 0) = m₀.words.read (.heap 0 0) := hw00
      unfold ArithRAMDynamicProgram.readReturnedHandle
      simp only [h00]
    have hcoins : ∀ bits, MemHasStepCoins cp bits m₀ → MemHasStepCoins cp bits m₁ :=
      fun bits hc k => (hw₁ coinTbl (by decide) (k.val : ℤ)).trans (hc k)
    exact ⟨henc₁, hw00, hret, hcoins, hw₁, hr₁⟩

/-- Deterministic RAM execution of `stepStage3Stmt` from `PostStage2WF cp P' st₂`,
producing `EncChainEngine ops (stepStage3 cp st₂) m₁` while preserving `InFootprint`,
`wRead _ 0 0`, `readReturnedHandle`, `MemHasStepCoins`, word tables `< 6`, and real tables `< 3`. -/
theorem exec_stepStage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d)
    {P' : DynamicPointSet d} {st₂ : ChainEngineState cp} {m₀ : ArithRAMMemory}
    (hwf₂ : PostStage2WF cp P' st₂)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops st₂ m₀) :
    let st₃ := stepStage3 cp st₂
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (stepStage3Stmt ops) m₀
      (fun m₁ =>
        EncChainEngine ops st₃ m₁ ∧
        wRead m₁ 0 0 = wRead m₀ 0 0 ∧
        ArithRAMDynamicProgram.readReturnedHandle m₁ =
          ArithRAMDynamicProgram.readReturnedHandle m₀ ∧
        (∀ bits, MemHasStepCoins cp bits m₀ → MemHasStepCoins cp bits m₁) ∧
        (∀ t < 6, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ rt < 3, ∀ i, rRead m₁ rt i = rRead m₀ rt i))
      (C_stage3 ops) :=
  exec_stepStage3Stmt_of_servingWF ops inp (servingDenseWF_of_postStage2WF hwf₂) hfp₀ henc₀

/-- Direct coin-threaded alias matching `CG19_Stage1` / `CG20_Stage4` pipeline shape. -/
theorem exec_stage3Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d)
    {P' : DynamicPointSet d} {st₂ : ChainEngineState cp} {m₀ : ArithRAMMemory}
    (bits : Fin cp.B_STEP → Bool)
    (hwf₂ : PostStage2WF cp P' st₂)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops st₂ m₀)
    (hcoins₀ : MemHasStepCoins cp bits m₀) :
    let st₃ := stepStage3 cp st₂
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (stage3Stmt ops) m₀
      (fun m₁ =>
        EncChainEngine ops st₃ m₁ ∧
        MemHasStepCoins cp bits m₁ ∧
        wRead m₁ 0 0 = wRead m₀ 0 0 ∧
        ArithRAMDynamicProgram.readReturnedHandle m₁ =
          ArithRAMDynamicProgram.readReturnedHandle m₀)
      (C_stage3 ops) :=
  (exec_stepStage3Stmt ops inp hwf₂ hfp₀ henc₀).mono
    (fun _ ⟨henc, hw00, hret, hcoins, _, _⟩ _ => ⟨henc, hcoins bits hcoins₀, hw00, hret⟩) le_rfl

end UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3
