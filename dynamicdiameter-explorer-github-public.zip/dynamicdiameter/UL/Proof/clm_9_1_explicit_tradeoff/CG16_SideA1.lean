import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideA0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)

/-! ### 5. Subroutine (1): `dyadicSideZeroInitStmt` & `dyadicSideClearStmt` (`empty`) -/

def dyadicSideZeroInitStmt (scrW tblW : ℕ) (wSideBaseW wScr : ℤ)
    (n L_p2 R ℓ M₀ cap_u : ℕ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let sStride := RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
  let headerLen : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  let wK := wScr
  let wSlotBW := wScr + 1
  .seq (.writeWordHeap tblW bW (.lit 1))
  (.seq (.writeWordHeap tblW (.add bW (.lit 1)) (.lit 0))
  (.seq (.writeWordHeap scrW (.lit wK) (.lit 0))
        (.repeatN (.lit ((2 * L_p2 : ℕ) : ℤ))
          (.seq (.writeWordHeap scrW (.lit wSlotBW)
                  (.add (.add bW (.lit headerLen))
                        (.mul (.readHeap scrW (.lit wK)) (.lit sStride))))
          (.seq (RacerP43.liveSlotZeroInitStmt scrW tblW wSlotBW)
                (.writeWordHeap scrW (.lit wK)
                  (.add (.readHeap scrW (.lit wK)) (.lit 1))))))))

def dyadicSideZeroInitCost (L_p2 : ℕ) : ℕ := 100 + 120 * (2 * L_p2)

theorem zeroRand_dyadicSideZeroInitStmt (scrW tblW : ℕ) (wSideBaseW wScr : ℤ)
    (n L_p2 R ℓ M₀ cap_u : ℕ) :
    H3a.ZeroRandStmt (dyadicSideZeroInitStmt scrW tblW wSideBaseW wScr n L_p2 R ℓ M₀ cap_u) :=
  of_isZeroRandB rfl

theorem exec_h4_dyadicSideZeroInitStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wScr sideBaseW sideBaseR : ℤ)
    (n L_p2 R ℓ M₀ b T p_coord cap_u : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htblW : tblW < TW)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ sideBaseW ∧ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 2 ≤ (BW : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + 2 ≤ wSideBaseW)
    (hbW : H3a.wRead m₀ scrW wSideBaseW = sideBaseW)
    (hzeroW : ∀ i, sideBaseW ≤ i →
      i < sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u → H3a.wRead m₀ tblW i = 0)
    (hzeroR : ∀ i, sideBaseR ≤ i →
      i < sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d → H3a.rRead m₀ tblR i = 0) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (dyadicSideZeroInitStmt scrW tblW wSideBaseW wScr n L_p2 R ℓ M₀ cap_u)
        m₀ m₁ (dyadicSideZeroInitCost L_p2) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u ∅
        (H4b.DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord) m₁ ∧
      (∀ w, (w < wScr ∨ wScr + 2 ≤ w) → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RacerP43.RadFrameOutside scrW scrR tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
        tblR sideBaseR 0 m₀ m₁ := by
  have hge2 := dyadicSideWStride_ge_two n L_p2 R ℓ M₀ cap_u
  have hpow_pos : (1 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (@Nat.one_le_two_pow L_p2)
  let hdrEnd := sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  have hhdr_le_stride : hdrEnd ≤ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u := by
    have hh := dyadicSideWStride_ge_hdrEnd n L_p2 R ℓ M₀ cap_u
    change sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ) ≤ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u; linarith
  let m1 := H3a.wWrite m₀ tblW sideBaseW 1
  let m2 := H3a.wWrite m1 tblW (sideBaseW + 1) 0
  let m3 := H3a.wWrite m2 scrW wScr 0
  have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wSideBaseW)) (.lit 1)) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW _ (.lit 1) hbW rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wSideBaseW)) (.lit 1)) (.lit 0))
      m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit 0)
      (by change H3a.wRead m1 scrW wSideBaseW + 1 = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.lit 0)) m2 m3 10 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit wScr) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp3 : InFootprint TW BW TR BR m3 :=
    InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ htblW hbaseW.1 (by omega))
      htblW (by omega) (by omega)) hscrW hwScr.1 (by omega)
  have hfr3 : RacerP43.RadFrameOutside scrW scrR tblW sideBaseW
      (dyadicSideWStride n L_p2 R ℓ M₀ cap_u) tblR sideBaseR 0 m₀ m3 :=
    ((RacerP43.RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m₀ (idx := sideBaseW) 1 le_rfl (by omega)).trans
      (RacerP43.RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m1 (idx := sideBaseW + 1) 0 (by omega) (by omega))).trans
      (RacerP43.RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m2 wScr 0)
  let N := 2 * L_p2
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    InFootprint TW BW TR BR m ∧
    H3a.wRead m scrW wScr = (k : ℤ) ∧
    H3a.wRead m tblW sideBaseW = 1 ∧
    H3a.wRead m tblW (sideBaseW + 1) = 0 ∧
    (∀ i, sideBaseW + 2 ≤ i → i < hdrEnd → H3a.wRead m tblW i = 0) ∧
    (∀ j, k ≤ j → j < N → ∀ i,
      sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW j ≤ i →
      i < sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW j + RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2) →
      H3a.wRead m tblW i = 0) ∧
    (∀ i, sideBaseR ≤ i → i < sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d → H3a.rRead m tblR i = 0) ∧
    (∀ j < k,
      RacerP43.EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW j)
        tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR j)
        R ℓ M₀ d cap_u (2 ^ L_p2) (RacerP43.LiveSlot.zeroMem R ℓ M₀ d) m) ∧
    (∀ w, (w < wScr ∨ wScr + 2 ≤ w) → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
    (∀ r, H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
    RacerP43.RadFrameOutside scrW scrR tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
      tblR sideBaseR 0 m₀ m
  have hInv0 : Inv 0 m3 := by
    refine ⟨hfp3, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, ?_, ?_, fun _ h => by omega, ?_, fun _ => rfl, hfr3⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_self]
    · rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_self]
    · intro i hlo hhi
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact hzeroW i (by omega) (by omega)
    · intro j _ hjN i hlo hhi
      have hbw := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hjN
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact hzeroW i (by omega) (by omega)
    · intro i hlo hhi; exact hzeroR i hlo hhi
    · intro w hw
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
  let sStride := RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
  let headerLen : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  let loopBody : ArithRAMStmt :=
    .seq (.writeWordHeap scrW (.lit (wScr + 1))
            (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit headerLen))
                  (.mul (.readHeap scrW (.lit wScr)) (.lit sStride))))
    (.seq (RacerP43.liveSlotZeroInitStmt scrW tblW (wScr + 1))
          (.writeWordHeap scrW (.lit wScr)
            (.add (.readHeap scrW (.lit wScr)) (.lit 1))))
  obtain ⟨m_end, hInvN, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (N : ℤ)) loopBody N 5 115 Inv hInv0 rfl
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) (fun k hk m hIm => by
      rcases hIm with ⟨hfp_m, hk_r, hep_m, ht_m, hhdr_m, hrem_zero, hzeroR_m, henc_prev, hkW_m, hkR_m, hfr_m⟩
      let slotBW := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k
      let slotBR := sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k
      have hbw_k := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hk
      have hbr_k := sideSlotBaseR_bounds (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d) sideBaseR hk
      have hbW_m : H3a.wRead m scrW wSideBaseW = sideBaseW := (hkW_m _ hdisjBW).trans hbW
      let m_a := H3a.wWrite m scrW (wScr + 1) slotBW
      have hd_a : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
          (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit headerLen))
                (.mul (.readHeap scrW (.lit wScr)) (.lit sStride)))) m m_a 35 :=
        DetExecAt.writeWordHeap 0 inp m scrW (.lit (wScr + 1)) _ rfl
          (by change (H3a.wRead m scrW wSideBaseW + headerLen) + H3a.wRead m scrW wScr * sStride = slotBW
              rw [hbW_m, hk_r]
              dsimp [slotBW, sideSlotBaseW, headerLen, sStride]; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_a : InFootprint TW BW TR BR m_a := InFootprint.wWrite hfp_m hscrW (by omega) (by omega)
      obtain ⟨m_b, hd_b, hfp_b, henc_k, hkW_b, hkR_b, hfr_b⟩ :=
        RacerP43.exec_liveSlotZeroInitStmt (scrR := scrR) inp (wScr + 1) slotBW slotBR R ℓ M₀ cap_u (2 ^ L_p2)
          hfp_a htblW hneW ⟨by omega, by omega⟩ (wRead_wWrite_self _ _ _ _)
          (fun i hlo hhi => by
            rw [wRead_wWrite_of_ne _ _ (Or.inl hneW)]
            exact hrem_zero k le_rfl hk i hlo hhi)
          (fun i hlo hhi => hzeroR_m i (by omega) (by omega))
      let m_c := H3a.wWrite m_b scrW wScr ((k + 1 : ℕ) : ℤ)
      have hd_c : DetExec inp (.writeWordHeap scrW (.lit wScr)
          (.add (.readHeap scrW (.lit wScr)) (.lit 1))) m_b m_c 20 :=
        DetExecAt.writeWordHeap 0 inp m_b scrW (.lit wScr) _ rfl
          (by change H3a.wRead m_b scrW wScr + 1 = _
              rw [hkW_b wScr, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hk_r]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_c : InFootprint TW BW TR BR m_c := InFootprint.wWrite hfp_b hscrW hwScr.1 (by omega)
      have htblW_keep : ∀ i : ℤ, (i < slotBW ∨ slotBW + sStride ≤ i) → H3a.wRead m_c tblW i = H3a.wRead m tblW i := by
        intro i hout
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW)]
        exact (hfr_b.1 tblW i hneW (Or.inr hout)).trans (wRead_wWrite_of_ne _ _ (Or.inl hneW))
      have htblR_keep : ∀ i : ℤ, H3a.rRead m_c tblR i = H3a.rRead m tblR i := by
        intro i
        rw [rRead_wWrite]
        have ho : tblR ≠ tblR ∨ i < slotBR ∨ slotBR + 0 ≤ i := by
          rcases lt_or_ge i slotBR with h | h
          · exact Or.inr (Or.inl h)
          · exact Or.inr (Or.inr (by omega))
        exact hfr_b.2 tblR i hneR ho
      have hfr_ab : RacerP43.RadFrameOutside scrW scrR tblW slotBW sStride tblR slotBR 0 m m_c :=
        ((RacerP43.RadFrameOutside.wWrite_scr scrW scrR tblW slotBW sStride tblR slotBR 0 m (wScr + 1) slotBW).trans hfr_b).trans
          (RacerP43.RadFrameOutside.wWrite_scr scrW scrR tblW slotBW sStride tblR slotBR 0 m_b wScr ((k + 1 : ℕ) : ℤ))
      have hfr_c : RacerP43.RadFrameOutside scrW scrR tblW sideBaseW
          (dyadicSideWStride n L_p2 R ℓ M₀ cap_u) tblR sideBaseR 0 m₀ m_c :=
        hfr_m.trans (hfr_ab.mono_range (Or.inr ⟨by dsimp [slotBW, sStride]; omega, by dsimp [slotBW, sStride]; omega⟩)
          (Or.inl rfl))
      refine ⟨m_c, (hd_a.seq (hd_b.seq hd_c)).mono_cost (by omega), hfp_c,
        wRead_wWrite_self _ _ _ _,
        (htblW_keep sideBaseW (Or.inl (by dsimp [slotBW]; omega))).trans hep_m,
        (htblW_keep (sideBaseW + 1) (Or.inl (by dsimp [slotBW]; omega))).trans ht_m,
        fun i hlo hhi => (htblW_keep i (Or.inl (by have h1 : hdrEnd ≤ slotBW := hbw_k.1; omega))).trans (hhdr_m i hlo hhi),
        fun j hkj hjN i hlo hhi => ?_,
        fun i hlo hhi => (htblR_keep i).trans (hzeroR_m i hlo hhi),
        fun j hj => ?_,
        fun w hw => ?_,
        fun r => ?_,
        hfr_c⟩
      · have hdisj := sideSlotBaseW_disj (n := n) (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
          sideBaseW (by omega : k ≠ j)
        rcases hdisj with hle | hge
        · exact (htblW_keep i (Or.inr (by dsimp [slotBW, sStride]; omega))).trans
            (hrem_zero j (by omega) hjN i hlo hhi)
        · have hbw_j := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hjN
          exact (htblW_keep i (Or.inl (by dsimp [slotBW]; omega))).trans
            (hrem_zero j (by omega) hjN i hlo hhi)
      · by_cases hjk : j = k
        · subst hjk
          exact henc_k.mono_frame
            (RacerP43.RadFrameOutside.wWrite_scr scrW scrR tblW slotBW 0 tblR slotBR 0 m_b wScr ((j + 1 : ℕ) : ℤ))
            hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
        · have hj_lt : j < k := by omega
          have hfr_r : RacerP43.RadFrameOutside scrW scrR tblW slotBW sStride
              tblR slotBR (RacerP43.slotRStride R ℓ M₀ d) m m_c :=
            hfr_ab.mono_range (Or.inr ⟨le_rfl, le_rfl⟩)
              (Or.inr ⟨le_rfl, by have := slotRStride_nonneg R ℓ M₀ d; linarith⟩)
          have hdisjW := sideSlotBaseW_disj (n := n) (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
            sideBaseW (ne_of_lt hj_lt)
          have hdisjR := sideSlotBaseR_disj (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
            sideBaseR (ne_of_lt hj_lt)
          exact (henc_prev j hj_lt).mono_frame hfr_r hneW hneR (Or.inr hdisjW) (Or.inr hdisjR)
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hkW_b w,
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hkW_m w hw
      · rw [rRead_wWrite, hkR_b r, rRead_wWrite]
        exact hkR_m r)
  rcases hInvN with ⟨hfp_e, _, hep_e, ht_e, hhdr_e, _, _, henc_e, hkW_e, hkR_e, hfr_e⟩
  refine ⟨m_end, (hd1.seq (hd2.seq (hd3.seq hd_loop))).mono_cost (by unfold dyadicSideZeroInitCost; dsimp [N]; omega),
    hfp_e, ?_, hkW_e, hkR_e, hfr_e⟩
  refine ⟨Nat.zero_le _, 1, fun _ _ => RacerP43.LiveSlot.zeroMem R ℓ M₀ d, le_rfl, hep_e, ht_e,
    fun _ h => by simp [H4b.DyadicSideIndex.empty] at h,
    fun eid heid => ?_,
    fun _ h => by simp [H4b.DyadicSideIndex.empty] at h,
    fun _ h => by simp at h,
    fun _ h => by simp [H4b.DyadicSideIndex.empty] at h,
    fun s sl => ⟨LiveSlotTrackedH4.of_zeroMem cap_u (2 ^ L_p2) (fun _ => false) _,
      henc_e (sideSlotIdx s sl) (sideSlotIdx_lt s sl)⟩,
    fun s => by
      have hq0 : (H4b.DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord).t_ins / (2 * 2 ^ s.val) = 0 :=
        Nat.zero_div _
      dsimp only; rw [hq0]
      exact ⟨fun h => by omega, fun h => by omega, fun h => by omega⟩⟩
  have heidZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast heid
  have hzero_al : H3a.wRead m_end tblW (sideAliveEpOff L_p2 sideBaseW eid) = 0 :=
    hhdr_e _ (by have he0 : (0 : ℤ) ≤ (eid : ℤ) := Nat.cast_nonneg eid; have hp0 : (0 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := Nat.cast_nonneg _; unfold sideAliveEpOff; linarith) (by have hn0 : (0 : ℤ) ≤ (n : ℤ) := Nat.cast_nonneg n; change sideAliveEpOff L_p2 sideBaseW eid < sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ); unfold sideAliveEpOff; linarith)
  rw [hzero_al]; omega

def dyadicSideClearStmt (scrW tblW : ℕ) (wSideBaseW wScr : ℤ)
    (n L_p2 R ℓ M₀ cap_u : ℕ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let sStride := RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
  let headerLen : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  let wK := wScr
  let wSlotBW := wScr + 1
  .seq (.writeWordHeap tblW bW (.add (.readHeap tblW bW) (.lit 1)))
  (.seq (.writeWordHeap tblW (.add bW (.lit 1)) (.lit 0))
  (.seq (.writeWordHeap scrW (.lit wK) (.lit 0))
        (.repeatN (.lit ((2 * L_p2 : ℕ) : ℤ))
          (.seq (.writeWordHeap scrW (.lit wSlotBW)
                  (.add (.add bW (.lit headerLen))
                        (.mul (.readHeap scrW (.lit wK)) (.lit sStride))))
          (.seq (RacerP43.liveSlotClearStmt scrW tblW wSlotBW)
                (.writeWordHeap scrW (.lit wK)
                  (.add (.readHeap scrW (.lit wK)) (.lit 1))))))))

def dyadicSideClearCost (L_p2 : ℕ) : ℕ := 100 + 140 * (2 * L_p2)

theorem zeroRand_dyadicSideClearStmt (scrW tblW : ℕ) (wSideBaseW wScr : ℤ)
    (n L_p2 R ℓ M₀ cap_u : ℕ) :
    H3a.ZeroRandStmt (dyadicSideClearStmt scrW tblW wSideBaseW wScr n L_p2 R ℓ M₀ cap_u) :=
  of_isZeroRandB rfl

theorem exec_h4_dyadicSideClearStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wScr sideBaseW sideBaseR : ℤ)
    {n L_p2 R ℓ M₀ b cap_u : ℕ} (T p_coord : ℕ)
    {U : Finset ℕ} {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htblW : tblW < TW)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ sideBaseW ∧ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 2 ≤ (BW : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + 2 ≤ wSideBaseW)
    (hbW : H3a.wRead m₀ scrW wSideBaseW = sideBaseW)
    (henc₀ : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (dyadicSideClearStmt scrW tblW wSideBaseW wScr n L_p2 R ℓ M₀ cap_u)
        m₀ m₁ (dyadicSideClearCost L_p2) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u ∅
        (H4b.DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord) m₁ ∧
      (∀ w, (w < wScr ∨ wScr + 2 ≤ w) → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RacerP43.RadFrameOutside scrW scrR tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
        tblR sideBaseR 0 m₀ m₁ := by
  have hge2 := dyadicSideWStride_ge_two n L_p2 R ℓ M₀ cap_u
  have hpow_pos : (1 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (@Nat.one_le_two_pow L_p2)
  rcases henc₀ with ⟨_, ep₀, live₀, hep1, hep_r, _, _, hal_le, _, _, _, hslots₀, _⟩
  let hdrEnd := sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  let m1 := H3a.wWrite m₀ tblW sideBaseW ((ep₀ + 1 : ℕ) : ℤ)
  let m2 := H3a.wWrite m1 tblW (sideBaseW + 1) 0
  let m3 := H3a.wWrite m2 scrW wScr 0
  have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wSideBaseW))
      (.add (.readHeap tblW (.readHeap scrW (.lit wSideBaseW))) (.lit 1))) m₀ m1 30 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW _ _ hbW
      (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wSideBaseW) + 1 = _
          rw [hbW, hep_r]; push_cast; ring)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wSideBaseW)) (.lit 1)) (.lit 0))
      m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit 0)
      (by change H3a.wRead m1 scrW wSideBaseW + 1 = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.lit 0)) m2 m3 10 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit wScr) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp3 : InFootprint TW BW TR BR m3 :=
    InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ htblW hbaseW.1 (by omega))
      htblW (by omega) (by omega)) hscrW hwScr.1 (by omega)
  have hfr3 : RacerP43.RadFrameOutside scrW scrR tblW sideBaseW
      (dyadicSideWStride n L_p2 R ℓ M₀ cap_u) tblR sideBaseR 0 m₀ m3 :=
    ((RacerP43.RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m₀ (idx := sideBaseW) ((ep₀ + 1 : ℕ) : ℤ) le_rfl (by omega)).trans
      (RacerP43.RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m1 (idx := sideBaseW + 1) 0 (by omega) (by omega))).trans
      (RacerP43.RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m2 wScr 0)
  let N := 2 * L_p2
  let slotOf : ∀ j, j < N → RacerP43.LiveSlot R ℓ M₀ d :=
    fun j hj => live₀ (sideSlotScale j hj) (sideSlotBuf j)
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    InFootprint TW BW TR BR m ∧
    H3a.wRead m scrW wScr = (k : ℤ) ∧
    H3a.wRead m tblW sideBaseW = ((ep₀ + 1 : ℕ) : ℤ) ∧
    H3a.wRead m tblW (sideBaseW + 1) = 0 ∧
    (∀ eid < 2 ^ L_p2, H3a.wRead m tblW (sideAliveEpOff L_p2 sideBaseW eid) ≤ ((ep₀ + 1 : ℕ) : ℤ)) ∧
    (∀ j (hj : j < N),
      RacerP43.EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW j)
        tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR j)
        R ℓ M₀ d cap_u (2 ^ L_p2)
        (if j < k then (slotOf j hj).clear ((slotOf j hj).ep + 1) else slotOf j hj) m) ∧
    (∀ w, (w < wScr ∨ wScr + 2 ≤ w) → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
    (∀ r, H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
    RacerP43.RadFrameOutside scrW scrR tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
      tblR sideBaseR 0 m₀ m
  have hfr03_hdr : RacerP43.RadFrameOutside scrW scrR tblW sideBaseW 2 tblR sideBaseR 0 m₀ m3 :=
    ((RacerP43.RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m₀ (idx := sideBaseW) ((ep₀ + 1 : ℕ) : ℤ) le_rfl (by omega)).trans
      (RacerP43.RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m1 (idx := sideBaseW + 1) 0 (by omega) (by omega))).trans
      (RacerP43.RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m2 wScr 0)
  have hInv0 : Inv 0 m3 := by
    refine ⟨hfp3, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, fun j hj => ?_, ?_, fun _ => rfl, hfr3⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_self]
    · rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_self]
    · intro eid heid
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold sideAliveEpOff; omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by unfold sideAliveEpOff; omega))]
      have hle := hal_le eid heid; omega
    · simp only [Nat.not_lt_zero, ↓reduceIte]
      have hbw := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hj
      have hbr := sideSlotBaseR_bounds (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d) sideBaseR hj
      have henc_j := (hslots₀ (sideSlotScale j hj) (sideSlotBuf j)).2
      rw [sideSlotIdx_scale_buf j hj] at henc_j
      exact henc_j.mono_frame hfr03_hdr hneW hneR
        (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
    · intro w hw
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
  let sStride := RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
  let headerLen : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  let loopBody : ArithRAMStmt :=
    .seq (.writeWordHeap scrW (.lit (wScr + 1))
            (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit headerLen))
                  (.mul (.readHeap scrW (.lit wScr)) (.lit sStride))))
    (.seq (RacerP43.liveSlotClearStmt scrW tblW (wScr + 1))
          (.writeWordHeap scrW (.lit wScr)
            (.add (.readHeap scrW (.lit wScr)) (.lit 1))))
  obtain ⟨m_end, hInvN, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (N : ℤ)) loopBody N 5 135 Inv hInv0 rfl
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) (fun k hk m hIm => by
      rcases hIm with ⟨hfp_m, hk_r, hep_m, ht_m, hal_m, henc_all, hkW_m, hkR_m, hfr_m⟩
      let slotBW := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k
      let slotBR := sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k
      have hbw_k := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hk
      have hbW_m : H3a.wRead m scrW wSideBaseW = sideBaseW := (hkW_m _ hdisjBW).trans hbW
      let m_a := H3a.wWrite m scrW (wScr + 1) slotBW
      have hd_a : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
          (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit headerLen))
                (.mul (.readHeap scrW (.lit wScr)) (.lit sStride)))) m m_a 35 :=
        DetExecAt.writeWordHeap 0 inp m scrW (.lit (wScr + 1)) _ rfl
          (by change (H3a.wRead m scrW wSideBaseW + headerLen) + H3a.wRead m scrW wScr * sStride = slotBW
              rw [hbW_m, hk_r]
              dsimp [slotBW, sideSlotBaseW, headerLen, sStride]; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_a : InFootprint TW BW TR BR m_a := InFootprint.wWrite hfp_m hscrW (by omega) (by omega)
      have henc_k_m : RacerP43.EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) (slotOf k hk) m_a := by
        have h0 := henc_all k hk
        simp only [lt_irrefl, ↓reduceIte] at h0
        exact h0.mono_frame
          (RacerP43.RadFrameOutside.wWrite_scr scrW scrR tblW slotBW 0 tblR slotBR 0 m (wScr + 1) slotBW)
          hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
      obtain ⟨m_b, hd_b, hfp_b, henc_k_b, hkW_b, hkR_b, hfr_b⟩ :=
        RacerP43.exec_liveSlotClearStmt (scrR := scrR) inp (wScr + 1) slotBW slotBR (slotOf k hk)
          hfp_a htblW hneW ⟨by omega, by omega⟩ (wRead_wWrite_self _ _ _ _) henc_k_m
      let m_c := H3a.wWrite m_b scrW wScr ((k + 1 : ℕ) : ℤ)
      have hd_c : DetExec inp (.writeWordHeap scrW (.lit wScr)
          (.add (.readHeap scrW (.lit wScr)) (.lit 1))) m_b m_c 20 :=
        DetExecAt.writeWordHeap 0 inp m_b scrW (.lit wScr) _ rfl
          (by change H3a.wRead m_b scrW wScr + 1 = _
              rw [hkW_b wScr, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hk_r]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_c : InFootprint TW BW TR BR m_c := InFootprint.wWrite hfp_b hscrW hwScr.1 (by omega)
      have htblW_keep : ∀ i : ℤ, i < slotBW → H3a.wRead m_c tblW i = H3a.wRead m tblW i := by
        intro i hlt
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW)]
        exact (hfr_b.1 tblW i hneW (Or.inr (Or.inl hlt))).trans (wRead_wWrite_of_ne _ _ (Or.inl hneW))
      have hfr_ab : RacerP43.RadFrameOutside scrW scrR tblW slotBW sStride tblR slotBR 0 m m_c :=
        ((RacerP43.RadFrameOutside.wWrite_scr scrW scrR tblW slotBW sStride tblR slotBR 0 m (wScr + 1) slotBW).trans hfr_b).trans
          (RacerP43.RadFrameOutside.wWrite_scr scrW scrR tblW slotBW sStride tblR slotBR 0 m_b wScr ((k + 1 : ℕ) : ℤ))
      have hfr_c : RacerP43.RadFrameOutside scrW scrR tblW sideBaseW
          (dyadicSideWStride n L_p2 R ℓ M₀ cap_u) tblR sideBaseR 0 m₀ m_c :=
        hfr_m.trans (hfr_ab.mono_range (Or.inr ⟨by dsimp [slotBW, sStride]; omega, by dsimp [slotBW, sStride]; omega⟩)
          (Or.inl rfl))
      refine ⟨m_c, (hd_a.seq (hd_b.seq hd_c)).mono_cost (by omega), hfp_c,
        wRead_wWrite_self _ _ _ _,
        (htblW_keep sideBaseW (by dsimp [slotBW]; omega)).trans hep_m,
        (htblW_keep (sideBaseW + 1) (by dsimp [slotBW]; omega)).trans ht_m,
        fun eid heid => ?_,
        fun j hj => ?_,
        fun w hw => ?_,
        fun r => ?_,
        hfr_c⟩
      · have heidZ : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast heid
        rw [htblW_keep _ (by have h1 := hbw_k.1; dsimp [slotBW]; unfold sideAliveEpOff; linarith)]
        exact hal_m eid heid
      · by_cases hjk : j = k
        · subst hjk
          simp only [Nat.lt_succ_self, ↓reduceIte]
          exact henc_k_b.mono_frame
            (RacerP43.RadFrameOutside.wWrite_scr scrW scrR tblW slotBW 0 tblR slotBR 0 m_b wScr ((j + 1 : ℕ) : ℤ))
            hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
        · have hiff : (j < k + 1) ↔ (j < k) := by omega
          have hfr_r : RacerP43.RadFrameOutside scrW scrR tblW slotBW sStride
              tblR slotBR (RacerP43.slotRStride R ℓ M₀ d) m m_c :=
            hfr_ab.mono_range (Or.inr ⟨le_rfl, le_rfl⟩)
              (Or.inr ⟨le_rfl, by have := slotRStride_nonneg R ℓ M₀ d; linarith⟩)
          have hdisjW := sideSlotBaseW_disj (n := n) (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
            sideBaseW hjk
          have hdisjR := sideSlotBaseR_disj (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
            sideBaseR hjk
          have hprev := (henc_all j hj).mono_frame hfr_r hneW hneR (Or.inr hdisjW) (Or.inr hdisjR)
          by_cases hlt : j < k
          · simp only [hlt, Nat.lt_succ_of_lt hlt, ↓reduceIte] at hprev ⊢; exact hprev
          · have hnot1 : ¬ j < k + 1 := by omega
            simp only [hlt, hnot1, ↓reduceIte] at hprev ⊢; exact hprev
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hkW_b w,
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hkW_m w hw
      · rw [rRead_wWrite, hkR_b r, rRead_wWrite]
        exact hkR_m r)
  rcases hInvN with ⟨hfp_e, _, hep_e, ht_e, hal_e, henc_e, hkW_e, hkR_e, hfr_e⟩
  refine ⟨m_end, (hd1.seq (hd2.seq (hd3.seq hd_loop))).mono_cost (by unfold dyadicSideClearCost; dsimp [N]; omega),
    hfp_e, ?_, hkW_e, hkR_e, hfr_e⟩
  let live' : Fin L_p2 → Fin 2 → RacerP43.LiveSlot R ℓ M₀ d :=
    fun s sl => (live₀ s sl).clear ((live₀ s sl).ep + 1)
  refine ⟨Nat.zero_le _, ep₀ + 1, live', by omega, hep_e, ht_e,
    fun _ h => by simp [H4b.DyadicSideIndex.empty] at h,
    hal_e,
    fun _ h => by simp [H4b.DyadicSideIndex.empty] at h,
    fun _ h => by simp at h,
    fun _ h => by simp [H4b.DyadicSideIndex.empty] at h,
    fun s sl => ?_,
    fun s => by
      have hq0 : (H4b.DyadicSideIndex.empty L_p2 R ℓ M₀ d b T p_coord).t_ins / (2 * 2 ^ s.val) = 0 :=
        Nat.zero_div _
      dsimp only; rw [hq0]
      exact ⟨fun h => by omega, fun h => by omega, fun h => by omega⟩⟩
  have hk_lt := sideSlotIdx_lt s sl
  have henc_s := henc_e (sideSlotIdx s sl) hk_lt
  dsimp only [N, slotOf] at henc_s
  rw [if_pos hk_lt, sideSlotScale_idx s sl hk_lt, sideSlotBuf_idx s sl] at henc_s
  exact ⟨LiveSlotTrackedH4.of_clear (hslots₀ s sl).1 (Nat.lt_succ_self _) (fun _ => false) _, henc_s⟩


theorem dyadicSideZeroInitCost_le (L_p2 : ℕ) :
    dyadicSideZeroInitCost L_p2 ≤ 340 * (L_p2 + 1) := by
  unfold dyadicSideZeroInitCost; omega

theorem dyadicSideClearCost_le (L_p2 : ℕ) :
    dyadicSideClearCost L_p2 ≤ 380 * (L_p2 + 1) := by
  unfold dyadicSideClearCost; omega

/-! ### 6. Subroutine (2): `dyadicSideRemoveStmt` (`H4b.DyadicSideIndex.removeHandle`) -/

def dyadicSideRemoveWStride : ℤ := 16

def dyadicSideRemoveSlotStepStmt (scrW tblW : ℕ)
    (wSideBaseW wScr : ℤ) (n L_p2 R ℓ M₀ cap_u : ℕ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let sStride := RacerP43.slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
  let headerLen : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  let wEid := wScr + 1
  let wK := wScr + 4
  let wSlotBW := wScr + 5
  let wBId := wScr + 6
  let wBCnt := wScr + 7
  let wLoc := wScr + 8
  let wUnlinkScr := wScr + 9
  .seq (.writeWordHeap scrW (.lit wSlotBW)
          (.add (.add bW (.lit headerLen))
                (.mul (.readHeap scrW (.lit wK)) (.lit sStride))))
  (.seq (.writeWordHeap scrW (.lit wBId)
          (.readHeap tblW (.add (.readHeap scrW (.lit wSlotBW)) (.lit 1))))
  (.seq (.writeWordHeap scrW (.lit wBCnt)
          (.readHeap tblW (.add (.readHeap scrW (.lit wSlotBW)) (.lit 2))))
  (.seq (.ite (.and (.and (.intLe (.lit 0) (.readHeap scrW (.lit wBId)))
                          (.intLe (.readHeap scrW (.lit wBId)) (.readHeap scrW (.lit wEid))))
                    (.intLt (.readHeap scrW (.lit wEid))
                            (.add (.readHeap scrW (.lit wBId)) (.readHeap scrW (.lit wBCnt)))))
          (.seq (.writeWordHeap scrW (.lit wLoc)
                  (.sub (.readHeap scrW (.lit wEid)) (.readHeap scrW (.lit wBId))))
                (RacerP43.liveSlotUnlinkLocStmt scrW tblW wSlotBW wLoc wUnlinkScr R ℓ M₀ cap_u))
          .skip)
        (.writeWordHeap scrW (.lit wK)
          (.add (.readHeap scrW (.lit wK)) (.lit 1))))))

def dyadicSideRemoveStmt (scrW tblW : ℕ)
    (wSideBaseW wH0 wScr : ℤ) (n L_p2 R ℓ M₀ cap_u : ℕ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let bMaxZ : ℤ := ((2 ^ L_p2 : ℕ) : ℤ)
  let wRem := wScr
  let wEid := wScr + 1
  let wEp := wScr + 2
  let wT := wScr + 3
  let wK := wScr + 4
  .seq (.writeWordHeap scrW (.lit wRem) (.mod (.readHeap scrW (.lit wH0)) (.lit (n : ℤ))))
  (.seq (.writeWordHeap scrW (.lit wEid)
          (.readHeap tblW (.add (.add bW (.lit (2 + 2 * bMaxZ))) (.readHeap scrW (.lit wRem)))))
  (.seq (.writeWordHeap scrW (.lit wEp) (.readHeap tblW bW))
  (.seq (.writeWordHeap scrW (.lit wT) (.readHeap tblW (.add bW (.lit 1))))
        (.ite (.and (.intLe (.lit 0) (.readHeap scrW (.lit wEid)))
                    (.intLt (.readHeap scrW (.lit wEid)) (.readHeap scrW (.lit wT))))
          (.ite (.and (.intEq (.readHeap tblW (.add (.add bW (.lit (2 + bMaxZ))) (.readHeap scrW (.lit wEid))))
                              (.readHeap scrW (.lit wEp)))
                      (.intEq (.readHeap tblW (.add (.add bW (.lit 2)) (.readHeap scrW (.lit wEid))))
                              (.readHeap scrW (.lit wH0))))
            (.seq (.writeWordHeap tblW (.add (.add bW (.lit (2 + bMaxZ))) (.readHeap scrW (.lit wEid))) (.lit 0))
            (.seq (.writeWordHeap scrW (.lit wK) (.lit 0))
                  (.repeatN (.lit ((2 * L_p2 : ℕ) : ℤ))
                    (dyadicSideRemoveSlotStepStmt scrW tblW wSideBaseW wScr n L_p2 R ℓ M₀ cap_u))))
            .skip)
          .skip))))

def dyadicSideRemoveCost (L_p2 R cap_u : ℕ) : ℕ :=
  250 + (2 * L_p2) * (200 + 400 * (R * cap_u))

theorem zeroRand_dyadicSideRemoveStmt (scrW tblW : ℕ)
    (wSideBaseW wH0 wScr : ℤ) (n L_p2 R ℓ M₀ cap_u : ℕ) :
    H3a.ZeroRandStmt (dyadicSideRemoveStmt scrW tblW wSideBaseW wH0 wScr n L_p2 R ℓ M₀ cap_u) :=
  of_isZeroRandB rfl


end UL.Proof.clm_9_1_explicit_tradeoff.CG16
