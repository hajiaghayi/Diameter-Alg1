import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_S1a
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.C14d1

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

theorem stepStage1_spec_del {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {P : DynamicPointSet d}
    {op : DynamicUpdate d}
    {st : ChainEngineState cp} (hwf : ChainEngineWF cp P st)
    (ω₁ : Stage1Coins cp)
    (P' : DynamicPointSet d)
    (hhp' : (st.hp.step (toInternalUpdate P op)).1.WellFormed P')
    (delH : ℕ)
    (huop_eq : toInternalUpdate P op = .delete delH)
    (hrh_eq : (st.hp.step (toInternalUpdate P op)).2 = none)
    (hdel_in_act : delH ∈ P.activeHandles)
    (hact'_eq : P'.activeHandles = P.activeHandles.erase delH)
    (hpts_eq : (st.hp.step (toInternalUpdate P op)).1.coords = st.hp.coords) :
    PostStage1WF cp P' (stepStage1 cp st (toInternalUpdate P op) ω₁).1 ∧
      (ChainEngineGood cp hh0 hh1 st →
       GoodStage1Coins cp hh0 hh1 st ω₁ →
       ChainEngineGood cp hh0 hh1 (stepStage1 cp st (toInternalUpdate P op) ω₁).1) := by
  have hserv_age_le := serving_age_le_of_wf cp hwf
  rcases hwf with ⟨hhp, hgt, hserv_len, hserv_cl, hjobs_wf, hleaf_wf⟩
  let actH := P.activeHandles
  let pts := st.hp.coords
  have hstep_eq : stepStage1 cp st (toInternalUpdate P op) ω₁ =
      stepStage1 cp st (.delete delH) ω₁ := by rw [huop_eq]
  rw [hstep_eq]
  let hp' := (st.hp.step (.delete delH)).1
  have hhp'_wf : hp'.WellFormed P' := by dsimp [hp']; rw [← huop_eq]; exact hhp'
  have hpts'_eq : hp'.coords = pts := by dsimp [hp']; rw [← huop_eq]; exact hpts_eq
  have hgt' : GhostTrackerWF (actH.erase delH) hp'.coords st.gt := by
    rw [hpts'_eq]
    exact ghostTracker_stepDelete_spec delH (fun x _ => rfl) hgt
  have hpts'_del : hp'.coords delH = pts delH := by rw [hpts'_eq]
  have hpts'_old : ∀ x ∈ actH.erase delH, hp'.coords x = pts x := fun x _ => by rw [hpts'_eq]
  rcases liveUpdateChainList_delete_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hpts'_del hpts'_old
    (getS1Seed cp ω₁) 0 actH st.serving (Finset.Subset.refl _) hdel_in_act hserv_age_le hserv_cl
    with ⟨hserv_len₁, hserv_el₁, hserv_cl₁, hserv_fold₁, hserv_gd₁⟩
  let servRes := liveUpdateChainList cp hp'.coords false delH (getS1Seed cp ω₁) 0 st.serving
  let st₁ := (stepStage1 cp st (.delete delH) ω₁).1
  have hst₁_hp : st₁.hp = hp' := rfl
  have hst₁_gt : st₁.gt = st.gt := rfl
  have hst₁_serv : st₁.serving = servRes.1 := rfl
  have hst₁_ov : st₁.leafOverflow = st.leafOverflow := rfl
  refine ⟨⟨hhp'_wf, ?_, ?_, ?_, ?_, ?_⟩, fun ⟨hov0, hgd_serv0, hgd_jobs0⟩ hcoins1 => ?_⟩
  · rw [hact'_eq, hst₁_hp, hst₁_gt]; exact hgt'
  · rw [hst₁_serv, hserv_len₁]; exact hserv_len
  · rw [hact'_eq, hst₁_hp, hst₁_gt, hst₁_serv]; exact hserv_cl₁
  · -- Per-slot `PostStage1WF` on delete
    intro r
    by_cases hr1_st : r.val < st₁.serving.length
    · rw [dif_pos hr1_st]
      have hr : r.val < st.serving.length := by rwa [hst₁_serv, hserv_len₁] at hr1_st
      have hslot0 := hjobs_wf r
      rw [dif_pos hr] at hslot0
      have hr1 : r.val < servRes.1.length := by rwa [hst₁_serv] at hr1_st
      rcases hserv_el₁ r.val hr hr1 with ⟨_, _, hbsz_r, hage_r⟩
      cases hjb0 : st.jobs r with
      | none =>
          dsimp only at hslot0
          rw [hjb0] at hslot0
          have hjb1 : st₁.jobs r = none := by dsimp [st₁, stepStage1]; rw [hjb0]
          rw [hjb1]
          dsimp only
          change 64 * K_alpha d * (servRes.1[r.val]'hr1).nd.age ≤
            (servRes.1[r.val]'hr1).nd.birthSize + 64 * K_alpha d
          rw [hbsz_r]
          have hmul : 64 * K_alpha d * (servRes.1[r.val]'hr1).nd.age ≤
              64 * K_alpha d * (st.serving[r.val]'hr).nd.age + 64 * K_alpha d := by
            have := Nat.mul_le_mul_left (64 * K_alpha d) hage_r
            linarith only [this]
          omega
      | some jb =>
          rw [hjb0] at hslot0
          have hMr0 : cp.B_scan < (st.serving[r.val]'hr).nd.birthSize :=
            (chainListInv_mem_birthSize actH st.serving hserv_cl _ (List.getElem_mem hr)).1
          rcases suffixJobInvSlack_bounds (Nat.zero_le _) hMr0 hslot0
            with ⟨hready_b0, _, _, hbs_age0⟩
          dsimp only [SuffixJobInv, SuffixJobInvSlack] at hslot0
          rcases hslot0 with ⟨hrs_lt, hcl_r0, hrb0, hanc_age0, hph0⟩
          have hcl_take0 := chainListInv_take r.val actH st.serving hserv_cl
          have hS_anc_sub : foldResiduals pts actH (st.serving.take r.val) ⊆ actH :=
            (chainListInv_getElem actH st.serving (Finset.Subset.refl _) hserv_cl).2 r.val hr |>.1
          have htake_age : ∀ mn ∈ st.serving.take r.val, mn.nd.age ≤ mn.nd.birthSize :=
            fun mn hm => hserv_age_le mn (List.mem_of_mem_take hm)
          rcases liveUpdateChainList_delete_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hpts'_del hpts'_old
            (getS1Seed cp ω₁) 0 actH (st.serving.take r.val) (Finset.Subset.refl _)
            hdel_in_act htake_age hcl_take0
            with ⟨_, _, _, htake_fold, _⟩
          have htake_snd := liveUpdateChainList_snd_eq cp hp'.coords false delH (getS1Seed cp ω₁) 0 (st.serving.take r.val)
          have htake_eq := liveUpdateChainList_take cp hp'.coords false delH (getS1Seed cp ω₁) r.val 0 st.serving
          rcases liveUpdateChainList_hist_dichotomy cp hp'.coords false delH (getS1Seed cp ω₁) 0 st.serving r.val hr
            with ⟨_, hanc_dic, _⟩
          have hanc_hist_same : (servRes.1[r.val]'hr1).histArr = (st.serving[r.val]'hr).histArr := by
            rcases hanc_dic with h1 | ⟨hf, _⟩
            · exact h1
            · cases hf
          -- Note `st₁.serving` is definitionally `servRes.1` here!
          by_cases hpass_r : passesNodes hp'.coords delH (st.serving.take r.val) = true
          · -- Delete reaches anchor `r`!
            have hcond_r : (r.val < st.serving.length && passesNodes hp'.coords delH (st.serving.take r.val)) = true := by
              simp [hr, hpass_r]
            rw [htake_snd, hpass_r, if_pos rfl] at htake_fold
            rcases htake_fold with ⟨hdel_in_Sanc, htake_fold_eq⟩
            let readyBase := cp.D_max + r.val * cp.D_max
            let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
            let rRes := liveUpdateChainList cp hp'.coords false delH
              (fun q => getS1Seed cp ω₁ (readyBase + q)) 0 jb.ready
            have hready_age_le : ∀ u ∈ jb.ready, u.nd.age ≤ u.nd.birthSize := by
              intro u hu
              rcases List.mem_iff_getElem.mp hu with ⟨q, hq, rfl⟩
              have h128 := (hready_b0 q hq).1
              have hK := K_alpha_ge_36 d
              have : (jb.ready[q]'hq).nd.age ≤ 128 * K_alpha d * (jb.ready[q]'hq).nd.age := by
                simpa using Nat.mul_le_mul_right (jb.ready[q]'hq).nd.age (by omega : 1 ≤ 128 * K_alpha d)
              omega
            rcases liveUpdateChainList_delete_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hpts'_del hpts'_old
              (fun q => getS1Seed cp ω₁ (readyBase + q)) 0
              (foldResiduals pts actH (st.serving.take r.val)) jb.ready hS_anc_sub
              hdel_in_Sanc hready_age_le hcl_r0
              with ⟨hr_len1, hr_el1, hr_cl1, hr_fold1, _⟩
            let phase₁ : JobPhase cp :=
              if rRes.2 then
                match jb.phase with
                | .copy cs => .copy (cs.liveDelete delH)
                | .build bs => .build (bs.liveDelete cp hp'.coords delH (getS1Seed cp ω₁ curIdx))
              else
                jb.phase
            have hjb1_eq : st₁.jobs r = some { ready := rRes.1, phase := phase₁ } := by
              dsimp [st₁, stepStage1]
              rw [hjb0]
              dsimp only
              rw [if_pos hcond_r]; rfl
            rw [hjb1_eq]
            set anc1 := st₁.serving[r.val]'hr1_st
            have hanc1_eq : anc1 = servRes.1[r.val]'hr1 := List.getElem_of_eq hst₁_serv hr1_st
            have htake_serv1 : st₁.serving.take r.val = servRes.1.take r.val := by rw [hst₁_serv]
            dsimp only [SuffixJobInvSlack]
            rw [hact'_eq, hst₁_hp, hst₁_gt, hanc1_eq, htake_serv1, htake_eq, htake_fold_eq, hbsz_r]
            have hlvl_eq : phase₁.lvlProg = jb.phase.lvlProg := by
              dsimp only [phase₁]
              by_cases h2 : rRes.2 = true
              · rw [if_pos h2]
                cases jb.phase with
                | copy cs => rfl
                | build bs =>
                    simp only [JobPhase.lvlProg, BuildState.liveDelete]
                    split_ifs <;> rfl
              · rw [if_neg h2]
            have hr_len1_r : rRes.1.length = jb.ready.length := hr_len1
            refine ⟨by rw [hr_len1_r]; exact hrs_lt, hr_cl1, ?_, ?_, ?_⟩
            · intro q hq1
              have hq0 : q < jb.ready.length := by omega
              rcases hr_el1 q hq0 hq1 with ⟨_, _, hubsz, huage⟩
              rcases hrb0 q hq0 with ⟨hq0_mr, hq_pow, hq_age⟩
              refine ⟨fun h0 => by rw [hubsz]; exact hq0_mr h0,
                fun q' hq1' hqq' => ?_, ?_⟩
              · have hq0' : q' < jb.ready.length := by omega
                rw [(hr_el1 q' hq0' hq1').2.2.1, hubsz]
                exact hq_pow q' hq0' hqq'
              · rw [hubsz, hr_len1_r, hlvl_eq]
                have hm := Nat.mul_le_mul_left cp.B_scan huage
                linarith only [hq_age, hm]
            · rw [hr_len1_r, hlvl_eq]
              have hm := Nat.mul_le_mul_left (64 * K_alpha d * cp.B_scan) hage_r
              linarith only [hanc_age0, hm]
            · have hTend_sub : foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready ⊆ actH :=
                (chainListInv_getElem _ jb.ready hS_anc_sub hcl_r0).1
              have hr_fold1' :
                  if rRes.2 = true then
                    delH ∈ foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready ∧
                    foldResiduals hp'.coords ((foldResiduals pts actH (st.serving.take r.val)).erase delH) rRes.1 =
                      (foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready).erase delH
                  else
                    delH ∉ foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready ∧
                    foldResiduals hp'.coords ((foldResiduals pts actH (st.serving.take r.val)).erase delH) rRes.1 =
                      foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready := hr_fold1
              have hprev_props :
                  ∃ (u0 u1 : MNode cp),
                    ((jb.ready = [] ∧ rRes.1 = [] ∧ u0 = st.serving[r.val]'hr ∧ u1 = servRes.1[r.val]'hr1) ∨
                     (jb.ready.getLast? = some u0 ∧ rRes.1.getLast? = some u1)) ∧
                    u1.nd.birthSize = u0.nd.birthSize ∧
                    u1.histArr = u0.histArr := by
                by_cases hremp : jb.ready = []
                · have hr1_emp : rRes.1 = [] := List.eq_nil_of_length_eq_zero (by rw [hr_len1_r, hremp]; rfl)
                  exact ⟨st.serving[r.val]'hr, servRes.1[r.val]'hr1,
                    Or.inl ⟨hremp, hr1_emp, rfl, rfl⟩, hbsz_r, hanc_hist_same⟩
                · have hlen_pos : 0 < jb.ready.length :=
                    Nat.pos_of_ne_zero (fun h0 => hremp (List.eq_nil_of_length_eq_zero h0))
                  have hs1_lt0 : jb.ready.length - 1 < jb.ready.length := by omega
                  have hs1_lt1 : rRes.1.length - 1 < rRes.1.length := by omega
                  have hgl0 : jb.ready.getLast? = some (jb.ready[jb.ready.length - 1]'hs1_lt0) := by
                    rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem hs1_lt0]
                  have hgl1 : rRes.1.getLast? = some (rRes.1[rRes.1.length - 1]'hs1_lt1) := by
                    rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem hs1_lt1]
                  have hget_eq : rRes.1[rRes.1.length - 1]'hs1_lt1 = rRes.1[jb.ready.length - 1]'(by omega) := by
                    exact List.getElem_of_eq rfl (by omega) |> fun _ => by congr 1; omega
                  rw [hget_eq] at hgl1
                  rcases liveUpdateChainList_hist_dichotomy cp hp'.coords false delH
                    (fun q => getS1Seed cp ω₁ (readyBase + q)) 0 jb.ready (jb.ready.length - 1) hs1_lt0
                    with ⟨hs1_lt1', hdic_last, _⟩
                  refine ⟨jb.ready[jb.ready.length - 1]'hs1_lt0, rRes.1[jb.ready.length - 1]'hs1_lt1',
                    Or.inr ⟨hgl0, hgl1⟩, (hr_el1 (jb.ready.length - 1) hs1_lt0 _).2.2.1, ?_⟩
                  rcases hdic_last with h1 | ⟨hf, _⟩
                  · exact h1
                  · cases hf
              rcases hprev_props with ⟨u0, u1, hgl_both, hprev_bsz, hprev_hist⟩
              have hph0_norm :
                  match jb.phase with
                  | .copy cs =>
                      cs.copyCur < cs.L_hist ∧ cs.L_hist ≤ 2 * u0.nd.birthSize ∧
                      CopyStateInv u0.histArr (foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready) cs
                  | .build bs =>
                      bs.insCur < bs.snapArr.length ∧ bs.L_hist ≤ 2 * u0.nd.birthSize ∧
                      cp.B_scan * bs.curNode.nd.age ≤ bs.insCur + 0 ∧
                      (if h0 : jb.ready.length = 0 then bs.curNode.nd.birthSize ≤ 2 * (st.serving[r.val]'hr).nd.birthSize
                       else bs.curNode.nd.birthSize * (2 * cp.D2) ≤ (jb.ready[jb.ready.length - 1]'(by omega)).nd.birthSize * (2 * cp.D2 + 1)) ∧
                      BuildStateInv cp pts st.gt (foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready) bs := by
                rcases hgl_both with ⟨h0e, _, rfl, _⟩ | ⟨hgs0, _⟩
                · have hgl0' : jb.ready.getLast? = none := by rw [h0e]; rfl
                  rw [hgl0'] at hph0; exact hph0
                · rw [hgs0] at hph0; exact hph0
              suffices hgoal_norm :
                  match (generalizing := false) phase₁ with
                  | .copy cs =>
                      cs.copyCur < cs.L_hist ∧ cs.L_hist ≤ 2 * u1.nd.birthSize ∧
                      CopyStateInv u1.histArr (foldResiduals hp'.coords ((foldResiduals pts actH (st.serving.take r.val)).erase delH) rRes.1) cs
                  | .build bs =>
                      bs.insCur < bs.snapArr.length ∧ bs.L_hist ≤ 2 * u1.nd.birthSize ∧
                      cp.B_scan * bs.curNode.nd.age ≤ bs.insCur + cp.B_scan ∧
                      (if h0 : rRes.1.length = 0 then bs.curNode.nd.birthSize ≤ 2 * (st.serving[r.val]'hr).nd.birthSize
                       else bs.curNode.nd.birthSize * (2 * cp.D2) ≤ (rRes.1[rRes.1.length - 1]'(by omega)).nd.birthSize * (2 * cp.D2 + 1)) ∧
                      BuildStateInv cp hp'.coords st.gt (foldResiduals hp'.coords ((foldResiduals pts actH (st.serving.take r.val)).erase delH) rRes.1) bs by
                rcases hgl_both with ⟨_, h1e, _, rfl⟩ | ⟨_, hgs1⟩
                · have hgl1' : rRes.1.getLast? = none := by rw [h1e]; rfl
                  rw [hgl1']; exact hgoal_norm
                · rw [hgs1]; exact hgoal_norm
              by_cases hr2 : rRes.2 = true
              · rw [if_pos hr2] at hr_fold1'
                rcases hr_fold1' with ⟨hdel_in_Tend, hr_fold1_eq⟩
                dsimp only [phase₁]
                rw [if_pos hr2]
                cases hphase0 : jb.phase with
                | copy cs =>
                    rw [hphase0] at hph0_norm
                    rcases hph0_norm with ⟨hcur_lt, hL_le, hcs_inv⟩
                    dsimp only
                    rw [hprev_bsz, hprev_hist, hr_fold1_eq]
                    rcases copyState_liveDelete_spec delH hcs_inv with ⟨hL_eq, hcur_eq, hcs_inv'⟩
                    rw [hL_eq, hcur_eq]
                    exact ⟨hcur_lt, hL_le, hcs_inv'⟩
                | build bs =>
                    rw [hphase0] at hph0_norm
                    rcases hph0_norm with ⟨hins_lt, hL_le, hage_ins, hmc_rat, hbs_inv⟩
                    dsimp only
                    rw [hprev_bsz, hr_fold1_eq]
                    rcases buildState_liveDelete_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hTend_sub
                      hdel_in_Tend hpts'_del hpts'_old (hbs_age0 bs hphase0) hbs_inv (getS1Seed cp ω₁ curIdx)
                      with ⟨hL', hsnap', hins', hbsz', hage', hbs_inv', _⟩
                    rw [hins', hsnap', hL', hage', hbsz']
                    refine ⟨hins_lt, hL_le, by linarith only [hage_ins], ?_, hbs_inv'⟩
                    by_cases hs0 : rRes.1.length = 0
                    · rw [dif_pos hs0]
                      have hs0' : jb.ready.length = 0 := by omega
                      rw [dif_pos hs0'] at hmc_rat; exact hmc_rat
                    · rw [dif_neg hs0]
                      have hs0' : ¬ jb.ready.length = 0 := by omega
                      rw [dif_neg hs0'] at hmc_rat
                      have hlast_bsz := (hr_el1 (jb.ready.length - 1) (by omega) (by omega)).2.2.1
                      have hget_eq : (rRes.1[rRes.1.length - 1]'(by omega)).nd.birthSize =
                          (jb.ready[jb.ready.length - 1]'(by omega)).nd.birthSize := by
                        have hidx : rRes.1.length - 1 = jb.ready.length - 1 := by omega
                        simp only [hidx]; exact hlast_bsz
                      rw [hget_eq]; exact hmc_rat
              · rw [if_neg hr2] at hr_fold1'
                rcases hr_fold1' with ⟨hdel_not_Tend, hr_fold1_eq⟩
                dsimp only [phase₁]
                rw [if_neg hr2]
                cases hphase0 : jb.phase with
                | copy cs =>
                    rw [hphase0] at hph0_norm
                    rcases hph0_norm with ⟨hcur_lt, hL_le, hcs_inv⟩
                    dsimp only
                    rw [hprev_bsz, hprev_hist, hr_fold1_eq]
                    exact ⟨hcur_lt, hL_le, hcs_inv⟩
                | build bs =>
                    rw [hphase0] at hph0_norm
                    rcases hph0_norm with ⟨hins_lt, hL_le, hage_ins, hmc_rat, hbs_inv⟩
                    dsimp only
                    rw [hprev_bsz, hr_fold1_eq]
                    have hbs_inv' := (buildStateInv_unchanged_delete hh0 hh1 hdel_not_Tend hpts'_old hTend_sub hbs_inv).1
                    refine ⟨hins_lt, hL_le, by omega, ?_, hbs_inv'⟩
                    by_cases hs0 : rRes.1.length = 0
                    · rw [dif_pos hs0]
                      have hs0' : jb.ready.length = 0 := by omega
                      rw [dif_pos hs0'] at hmc_rat; exact hmc_rat
                    · rw [dif_neg hs0]
                      have hs0' : ¬ jb.ready.length = 0 := by omega
                      rw [dif_neg hs0'] at hmc_rat
                      have hlast_bsz := (hr_el1 (jb.ready.length - 1) (by omega) (by omega)).2.2.1
                      have hget_eq : (rRes.1[rRes.1.length - 1]'(by omega)).nd.birthSize =
                          (jb.ready[jb.ready.length - 1]'(by omega)).nd.birthSize := by
                        have hidx : rRes.1.length - 1 = jb.ready.length - 1 := by omega
                        simp only [hidx]; exact hlast_bsz
                      rw [hget_eq]; exact hmc_rat
          · -- Delete absorbed before anchor `r` (`passesNodes = false`)!
            have hcond_r : (r.val < st.serving.length && passesNodes hp'.coords delH (st.serving.take r.val)) = false := by
              cases hp_b : passesNodes hp'.coords delH (st.serving.take r.val)
              · simp
              · exact absurd hp_b hpass_r
            have hp_false : passesNodes hp'.coords delH (st.serving.take r.val) = false := by
              cases hp_b : passesNodes hp'.coords delH (st.serving.take r.val)
              · rfl
              · exact absurd hp_b hpass_r
            rw [htake_snd, hp_false, if_neg Bool.false_ne_true] at htake_fold
            rcases htake_fold with ⟨hdel_not_Sanc, htake_fold_eq⟩
            have hanc_same : servRes.1[r.val]'hr1 = st.serving[r.val]'hr := by
              have haux : ∀ (idx k : ℕ) (ls : List (MNode cp)) (hk : k < ls.length),
                  passesNodes hp'.coords delH (ls.take k) = false →
                  ∀ hk' : k < (liveUpdateChainList cp hp'.coords false delH (getS1Seed cp ω₁) idx ls).1.length,
                    (liveUpdateChainList cp hp'.coords false delH (getS1Seed cp ω₁) idx ls).1[k]'hk' = ls[k]'hk := by
                intro idx k
                induction k generalizing idx with
                | zero => intro ls _ hpf; simp [passesNodes] at hpf
                | succ k' ih =>
                    intro ls hk hpf hk'
                    cases ls with
                    | nil => exact absurd hk (Nat.not_lt_zero _)
                    | cons hd tl =>
                        dsimp only [List.take_succ_cons, passesNodes, liveUpdateChainList] at hpf hk' ⊢
                        by_cases hcb : inCoreBall hd.nd.o hd.nd.V (hp'.coords delH) = true
                        · simp only [hcb]; rfl
                        · simp only [hcb, List.getElem_cons_succ]
                          have hnot_cb : (!inCoreBall hd.nd.o hd.nd.V (hp'.coords delH)) = true := by
                            cases hb : inCoreBall hd.nd.o hd.nd.V (hp'.coords delH)
                            · rfl
                            · exact absurd hb hcb
                          rw [hnot_cb, Bool.true_and] at hpf
                          exact ih (idx + 1) tl (Nat.lt_of_succ_lt_succ hk) hpf _
              exact haux 0 r.val st.serving hr hp_false hr1
            have hjb1_eq : st₁.jobs r = some jb := by
              dsimp [st₁, stepStage1]
              rw [hjb0]; dsimp only
              rw [if_neg (by rw [hcond_r]; decide)]
            rw [hjb1_eq]
            set anc1 := st₁.serving[r.val]'hr1_st
            have hanc1_eq : anc1 = st.serving[r.val]'hr :=
              (List.getElem_of_eq hst₁_serv hr1_st).trans hanc_same
            have htake_serv1 : st₁.serving.take r.val = servRes.1.take r.val := by rw [hst₁_serv]
            dsimp only [SuffixJobInvSlack]
            rw [hact'_eq, hst₁_hp, hst₁_gt, hanc1_eq, htake_serv1, htake_eq, htake_fold_eq]
            rcases chainListInv_unchanged_delete hh0 hh1 hpts'_old
              (foldResiduals pts actH (st.serving.take r.val)) jb.ready hS_anc_sub hdel_not_Sanc hcl_r0
              with ⟨hTend_same, hcl_r1, _⟩
            have hTend_sub : foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready ⊆ actH :=
              (chainListInv_getElem _ jb.ready hS_anc_sub hcl_r0).1
            have hdel_not_Tend : delH ∉ foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready := by
              have hTend_sub_Sanc : foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready ⊆
                  foldResiduals pts actH (st.serving.take r.val) := by
                have hsub_fold : ∀ (S : Finset ℕ) (ls : List (MNode cp)), foldResiduals pts S ls ⊆ S := by
                  intro S ls; induction ls generalizing S with
                  | nil => exact Finset.Subset.refl _
                  | cons u us ih =>
                      refine (ih _).trans (fun x hx => ?_)
                      unfold nodeResidual at hx
                      rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hx.1
                exact hsub_fold _ _
              exact fun hm => hdel_not_Sanc (hTend_sub_Sanc hm)
            refine ⟨hrs_lt, hcl_r1, fun q hq => ⟨(hrb0 q hq).1, (hrb0 q hq).2.1, by linarith only [(hrb0 q hq).2.2]⟩,
              by
                have hm := Nat.mul_le_mul_left (64 * K_alpha d)
                  (Nat.le_add_right (jb.ready.length * (48 * (st.serving[r.val]'hr).nd.birthSize) + jb.phase.lvlProg) cp.B_scan)
                linarith only [hanc_age0, hm], ?_⟩
            rw [hTend_same]
            cases hphase0 : jb.phase with
            | copy cs => rw [hphase0] at hph0; exact hph0
            | build bs =>
                rw [hphase0] at hph0
                rcases hph0 with ⟨hins_lt, hL_le, hage_ins, hmc_rat, hbs_inv⟩
                exact ⟨hins_lt, hL_le, by omega, hmc_rat,
                  (buildStateInv_unchanged_delete hh0 hh1 hdel_not_Tend hpts'_old hTend_sub hbs_inv).1⟩
    · rw [dif_neg hr1_st]
      have hr_not : ¬ r.val < st.serving.length := by rwa [hst₁_serv, hserv_len₁] at hr1_st
      have hnone0 := hjobs_wf r
      rw [dif_neg hr_not] at hnone0
      dsimp [st₁, stepStage1]
      rw [hnone0]
  · -- Leaf array invariant on delete
    intro hov1
    rw [hst₁_ov] at hov1
    rcases hleaf_wf hov1 with ⟨hlf_nd, hlf_set, hlf_len⟩
    have hleaf_eq : st₁.leafArr =
        if servRes.2 && !st.leafOverflow then denseDelete delH st.leafArr else st.leafArr := rfl
    rw [hact'_eq, hst₁_hp, hst₁_serv, hleaf_eq, hov1]
    by_cases hs2 : servRes.2 = true
    · rw [if_pos (by simp [hs2])]
      rw [if_pos hs2] at hserv_fold₁
      rcases denseDelete_spec (h := delH) hlf_nd with ⟨hnd', hset'⟩
      have hlen' : (denseDelete delH st.leafArr).length ≤ st.leafArr.length := by
        rw [← List.toFinset_card_of_nodup hnd', ← List.toFinset_card_of_nodup hlf_nd, hset']
        exact Finset.card_erase_le
      exact ⟨hnd', by rw [hset', hlf_set, hserv_fold₁.2], by omega⟩
    · rw [if_neg (by simp [hs2])]
      rw [if_neg hs2] at hserv_fold₁
      exact ⟨hlf_nd, by rw [hlf_set, hserv_fold₁.2], by omega⟩
  · -- `ChainEngineGood` preservation on delete!
    have hserv_gd' : ChainListGood cp hh0 hh1 hp'.coords st.gt servRes.1 :=
      hserv_gd₁ hgd_serv0 (fun q hq => by
        simpa using GoodStage1Coins.serv hserv_len hcoins1 q hq)
    refine ⟨by rw [hst₁_ov]; exact hov0, ?_, ?_⟩
    · rw [hst₁_hp, hst₁_gt, hst₁_serv]; exact hserv_gd'
    · intro r hr1 jb₁ hjb1
      rw [hst₁_serv, hserv_len₁] at hr1
      cases hjb0 : st.jobs r with
      | none =>
          dsimp [st₁, stepStage1] at hjb1
          rw [hjb0] at hjb1; cases hjb1
      | some jb =>
          have hgd_jb0 := hgd_jobs0 r hr1 jb hjb0
          have hslot0 := hjobs_wf r
          rw [dif_pos hr1, hjb0] at hslot0
          have hMr0 : cp.B_scan < (st.serving[r.val]'hr1).nd.birthSize :=
            (chainListInv_mem_birthSize actH st.serving hserv_cl _ (List.getElem_mem hr1)).1
          rcases suffixJobInvSlack_bounds (Nat.zero_le _) hMr0 hslot0
            with ⟨hready_b0, _, _, hbs_age0⟩
          dsimp only [SuffixJobInv, SuffixJobInvSlack] at hslot0
          rcases hslot0 with ⟨hrs_lt, hcl_r0, _, _, hph0⟩
          have hS_anc_sub : foldResiduals pts actH (st.serving.take r.val) ⊆ actH :=
            (chainListInv_getElem actH st.serving (Finset.Subset.refl _) hserv_cl).2 r.val hr1 |>.1
          have hTend_sub : foldResiduals pts (foldResiduals pts actH (st.serving.take r.val)) jb.ready ⊆ actH :=
            (chainListInv_getElem _ jb.ready hS_anc_sub hcl_r0).1
          rw [hst₁_hp, hst₁_gt]
          dsimp [st₁, stepStage1] at hjb1
          rw [hjb0] at hjb1
          dsimp only at hjb1
          by_cases hcond_r : (r.val < st.serving.length && passesNodes hp'.coords delH (st.serving.take r.val)) = true
          · rw [if_pos hcond_r] at hjb1
            injection hjb1 with hjb1_eq; subst hjb1_eq
            rcases Bool.and_eq_true_iff.mp hcond_r with ⟨_, hpass_r⟩
            have hcl_take0 := chainListInv_take r.val actH st.serving hserv_cl
            have htake_age : ∀ mn ∈ st.serving.take r.val, mn.nd.age ≤ mn.nd.birthSize :=
              fun mn hm => hserv_age_le mn (List.mem_of_mem_take hm)
            rcases liveUpdateChainList_delete_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hpts'_del hpts'_old
              (getS1Seed cp ω₁) 0 actH (st.serving.take r.val) (Finset.Subset.refl _)
              hdel_in_act htake_age hcl_take0
              with ⟨_, _, _, htake_fold, _⟩
            rw [liveUpdateChainList_snd_eq, hpass_r, if_pos rfl] at htake_fold
            have hready_age_le : ∀ u ∈ jb.ready, u.nd.age ≤ u.nd.birthSize := by
              intro u hu
              rcases List.mem_iff_getElem.mp hu with ⟨q, hq, rfl⟩
              have h128 := (hready_b0 q hq).1
              have hK := K_alpha_ge_36 d
              have : (jb.ready[q]'hq).nd.age ≤ 128 * K_alpha d * (jb.ready[q]'hq).nd.age := by
                simpa using Nat.mul_le_mul_right (jb.ready[q]'hq).nd.age (by omega : 1 ≤ 128 * K_alpha d)
              omega
            rcases liveUpdateChainList_delete_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hpts'_del hpts'_old
              (fun q => getS1Seed cp ω₁ (cp.D_max + r.val * cp.D_max + q)) 0
              (foldResiduals pts actH (st.serving.take r.val)) jb.ready hS_anc_sub
              htake_fold.1 hready_age_le hcl_r0
              with ⟨_, _, _, hr_fold1, hr_gd1⟩
            have hr_gd' := hr_gd1 hgd_jb0.1 (fun q hq => by
              simpa [Nat.zero_add] using GoodStage1Coins.ready hcoins1 r hjb0 hrs_lt q hq)
            refine ⟨hr_gd', ?_⟩
            dsimp only
            split_ifs with hr2
            · rw [if_pos hr2] at hr_fold1
              cases hphase0 : jb.phase with
              | copy _ => trivial
              | build bs =>
                  rw [hphase0] at hph0
                  have hgd_bs0 : LiveNodeGood cp hh0 hh1 pts st.gt bs.curNode := by
                    have := hgd_jb0.2; rwa [hphase0] at this
                  dsimp only [Bool.false_eq_true, ↓reduceIte]
                  exact (buildState_liveDelete_spec h_clm_7_3 hd he1 cp hh0 hh1 hgt hTend_sub
                    hr_fold1.1 hpts'_del hpts'_old (hbs_age0 bs hphase0) hph0.2.2.2.2
                    (getS1Seed cp ω₁ (cp.D_max + cp.D_max * cp.D_max + r.val))).2.2.2.2.2.2
                    hgd_bs0 (GoodStage1Coins.cur hcoins1 r hjb0 hphase0)
            · rw [if_neg hr2] at hr_fold1
              cases hphase0 : jb.phase with
              | copy _ => trivial
              | build bs =>
                  rw [hphase0] at hph0
                  have hgd_bs0 : LiveNodeGood cp hh0 hh1 pts st.gt bs.curNode := by
                    have := hgd_jb0.2; rwa [hphase0] at this
                  exact (buildStateInv_unchanged_delete hh0 hh1 hr_fold1.1 hpts'_old hTend_sub hph0.2.2.2.2).2 hgd_bs0
          · rw [if_neg hcond_r] at hjb1
            injection hjb1 with hjb1_eq; subst hjb1_eq
            rw [hpts'_eq]
            exact hgd_jb0

theorem stepStage1_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_clm_7_3 : S_clm_7_3_global_approx) (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {P : DynamicPointSet d} (hP : P.WellFormed cp.n)
    {op : DynamicUpdate d} (hleg : IsLegalUpdate cp.n Set.univ P op)
    {st : ChainEngineState cp} (hwf : ChainEngineWF cp P st)
    (ω₁ : Stage1Coins cp) :
    let res1 := stepStage1 cp st (toInternalUpdate P op) ω₁
    ∃ P' : DynamicPointSet d,
      applyDynamicUpdate P op res1.2 = some P' ∧
      PostStage1WF cp P' res1.1 ∧
      (ChainEngineGood cp hh0 hh1 st →
       GoodStage1Coins cp hh0 hh1 st ω₁ →
       ChainEngineGood cp hh0 hh1 res1.1) := by
  intro res1
  rcases handlePool_step_detail' hP hwf.1 hleg with ⟨P', happ, hhp', hdic⟩
  refine ⟨P', happ, ?_⟩
  rcases hdic with
    ⟨h_new, pt, huop_eq, hrh_eq, hnot_act, hact'_eq, hpts_new, hpts_old⟩ |
    ⟨delH, huop_eq, hrh_eq, hdel_in_act, hact'_eq, hpts_eq⟩
  · exact stepStage1_spec_ins h_clm_7_3 hd he1 cp hh0 hh1 hwf ω₁ P' hhp' h_new pt huop_eq hrh_eq
      hnot_act hact'_eq hpts_new hpts_old
  · exact stepStage1_spec_del h_clm_7_3 hd he1 cp hh0 hh1 hwf ω₁ P' hhp' delH huop_eq hrh_eq
      hdel_in_act hact'_eq hpts_eq

end UL.Proof.clm_9_1_explicit_tradeoff.C14d1
