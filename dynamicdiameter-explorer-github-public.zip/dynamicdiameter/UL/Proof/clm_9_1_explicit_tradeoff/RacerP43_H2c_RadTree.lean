import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Def.def_node_baseline
import UL.Proof.lem_7_2.RacerP33_H1_RAM
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H3a3_ExactScan
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H1_Bridge
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H2b_SwapPool
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a3
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)

/-! ### 1. `DualPool` (Live + Freeze-Once Snapshot `SwapPool` Pair) -/

structure DualPool where
  live : SwapPool
  snap : SwapPool
  frozen : Bool

def DualPool.empty : DualPool :=
  { live := SwapPool.empty, snap := SwapPool.empty, frozen := false }

def DualPool.WF (n : ℕ) (S_live S_snap : Finset ℕ) (D : DualPool) : Prop :=
  D.live.WF n S_live ∧
  D.snap.WF n S_snap ∧
  (D.frozen = false → S_snap = S_live)

def DualPool.clear (newEp : ℕ) (D : DualPool) : DualPool :=
  { live := D.live.clear newEp, snap := D.snap.clear newEp, frozen := false }

def DualPool.freeze (D : DualPool) : DualPool :=
  { D with frozen := true }

def DualPool.insert (n : ℕ) (D : DualPool) (uid : ℕ) : DualPool :=
  { live := D.live.insert n uid
    snap := if D.frozen then D.snap else D.snap.insert n uid
    frozen := D.frozen }

def DualPool.delete (n : ℕ) (D : DualPool) (uid : ℕ) : DualPool :=
  { live := D.live.delete n uid
    snap := if D.frozen then D.snap else D.snap.delete n uid
    frozen := D.frozen }

theorem DualPool.wf_empty (n : ℕ) : DualPool.empty.WF n ∅ ∅ :=
  ⟨SwapPool.wf_empty n, SwapPool.wf_empty n, fun _ => rfl⟩

theorem DualPool.wf_clear {n : ℕ} {S_l S_s : Finset ℕ} {D : DualPool}
    (hwf : D.WF n S_l S_s) {newEp : ℕ} (hl : D.live.ep < newEp) (hs : D.snap.ep < newEp) :
    (D.clear newEp).WF n ∅ ∅ :=
  ⟨D.live.wf_clear hwf.1 hl, D.snap.wf_clear hwf.2.1 hs, fun _ => rfl⟩

theorem DualPool.wf_freeze {n : ℕ} {S_l S_s : Finset ℕ} {D : DualPool}
    (hwf : D.WF n S_l S_s) (hnot_fr : D.frozen = false) :
    D.freeze.WF n S_l S_l := by
  have heq := hwf.2.2 hnot_fr
  subst heq
  exact ⟨hwf.1, hwf.2.1, fun h => by simp [DualPool.freeze] at h⟩

theorem DualPool.wf_insert {n : ℕ} (hn : 1 ≤ n) {S_l S_s : Finset ℕ} {D : DualPool}
    (hwf : D.WF n S_l S_s) {uid : ℕ}
    (hnot : uid ∉ S_l) (hcap : S_l.card + 1 ≤ n) (hfresh : ∀ x ∈ S_l, x % n ≠ uid % n) :
    (D.insert n uid).WF n (Insert.insert uid S_l) (if D.frozen then S_s else Insert.insert uid S_l) := by
  refine ⟨D.live.wf_insert hn hwf.1 hnot hcap hfresh, ?_, ?_⟩
  · cases hfr : D.frozen
    · simp only [DualPool.insert, hfr, Bool.false_eq_true, ↓reduceIte]
      have heq := hwf.2.2 hfr; subst heq
      exact D.snap.wf_insert hn hwf.2.1 hnot hcap hfresh
    · simp only [DualPool.insert, hfr, ↓reduceIte]; exact hwf.2.1
  · intro hfr; dsimp [DualPool.insert] at hfr; simp [hfr]

theorem DualPool.wf_delete {n : ℕ} (hn : 1 ≤ n) {S_l S_s : Finset ℕ} {D : DualPool}
    (hwf : D.WF n S_l S_s) (uid : ℕ) :
    (D.delete n uid).WF n (S_l.erase uid) (if D.frozen then S_s else S_l.erase uid) := by
  refine ⟨D.live.wf_delete hn hwf.1 uid, ?_, ?_⟩
  · cases hfr : D.frozen
    · simp only [DualPool.delete, hfr, Bool.false_eq_true, ↓reduceIte]
      have heq := hwf.2.2 hfr; subst heq
      exact D.snap.wf_delete hn hwf.2.1 uid
    · simp only [DualPool.delete, hfr, ↓reduceIte]; exact hwf.2.1
  · intro hfr; dsimp [DualPool.delete] at hfr; simp [hfr]

/-! ### 2. Pure Binary Subtree Arithmetic & `EpochRadTree` -/

def inRadSubtree (M_leaf h v : ℕ) : Prop :=
  ∃ k : ℕ, (M_leaf + h) / (2 ^ k) = v

noncomputable instance (M_leaf h v : ℕ) : Decidable (inRadSubtree M_leaf h v) :=
  Classical.propDecidable _

private lemma inRadSubtree_leaf_iff {K_seg h u_h : ℕ} (hh : h < 2 ^ K_seg) (huh : u_h < 2 ^ K_seg) :
    inRadSubtree (2 ^ K_seg) u_h (2 ^ K_seg + h) ↔ u_h = h := by
  constructor
  · rintro ⟨k, hk⟩
    cases k with
    | zero => simp at hk; exact hk
    | succ k' =>
        have h2 : 2 ≤ 2 ^ (k' + 1) := by
          rw [pow_succ']; exact Nat.mul_le_mul_left 2 (Nat.one_le_two_pow)
        have hdiv : (2 ^ K_seg + u_h) / 2 ^ (k' + 1) ≤ (2 ^ K_seg + u_h) / 2 :=
          Nat.div_le_div_left h2 (by omega)
        omega
  · rintro rfl; exact ⟨0, by simp⟩

private lemma inRadSubtree_internal_iff {K_seg u_h p : ℕ}
    (_huh : u_h < 2 ^ K_seg) (_hp1 : 1 ≤ p) (hpM : p < 2 ^ K_seg) :
    inRadSubtree (2 ^ K_seg) u_h p ↔
      inRadSubtree (2 ^ K_seg) u_h (2 * p) ∨ inRadSubtree (2 ^ K_seg) u_h (2 * p + 1) := by
  constructor
  · rintro ⟨k, hk⟩
    cases k with
    | zero => simp at hk; omega
    | succ k' =>
        rw [pow_succ, ← Nat.div_div_eq_div_mul] at hk
        set q := (2 ^ K_seg + u_h) / 2 ^ k'
        have hmod := Nat.div_add_mod q 2
        rcases Nat.mod_two_eq_zero_or_one q with h0 | h1
        · exact Or.inl ⟨k', by omega⟩
        · exact Or.inr ⟨k', by omega⟩
  · rintro (⟨k, hk⟩ | ⟨k, hk⟩) <;>
      exact ⟨k + 1, by rw [pow_succ, ← Nat.div_div_eq_div_mul, hk]; omega⟩

private lemma inRadSubtree_root {K_seg u_h : ℕ} (huh : u_h < 2 ^ K_seg) :
    inRadSubtree (2 ^ K_seg) u_h 1 := by
  refine ⟨K_seg, ?_⟩
  have hpos : 0 < 2 ^ K_seg := Nat.two_pow_pos K_seg
  have h1 : 1 ≤ (2 ^ K_seg + u_h) / 2 ^ K_seg := (Nat.le_div_iff_mul_le hpos).mpr (by omega)
  have h2 : (2 ^ K_seg + u_h) / 2 ^ K_seg < 2 := (Nat.div_lt_iff_lt_mul hpos).mpr (by omega)
  omega

private lemma inRadSubtree_unique_at_depth {K_seg h t w : ℕ}
    (hh : h < 2 ^ K_seg) (ht : t ≤ K_seg)
    (hw_lo : 2 ^ (K_seg - t) ≤ w) (hw_hi : w < 2 * 2 ^ (K_seg - t))
    (hin : inRadSubtree (2 ^ K_seg) h w) :
    w = (2 ^ K_seg + h) / 2 ^ t := by
  rcases hin with ⟨k, rfl⟩
  have h_eq_k : k = t := by
    by_contra hne
    rcases lt_or_gt_of_ne hne with hlt | hgt
    · have hk_le : k + 1 ≤ t := hlt
      have hpow : 2 * 2 ^ (K_seg - t) ≤ 2 ^ (K_seg - k) := by
        have hsub : K_seg - t + 1 ≤ K_seg - k := by omega
        calc 2 * 2 ^ (K_seg - t) = 2 ^ (K_seg - t + 1) := by rw [pow_succ']
          _ ≤ 2 ^ (K_seg - k) := Nat.pow_le_pow_right (by omega) hsub
      have h_ge : 2 ^ (K_seg - k) ≤ (2 ^ K_seg + h) / 2 ^ k := by
        rw [Nat.le_div_iff_mul_le (Nat.two_pow_pos k), ← pow_add, show K_seg - k + k = K_seg by omega]
        omega
      omega
    · have ht_le : t + 1 ≤ k := hgt
      have h_lt : (2 ^ K_seg + h) / 2 ^ k < 2 ^ (K_seg - t) := by
        rw [Nat.div_lt_iff_lt_mul (Nat.two_pow_pos k), ← pow_add]
        have hpow : 2 * 2 ^ K_seg ≤ 2 ^ (K_seg - t + k) := by
          calc 2 * 2 ^ K_seg = 2 ^ (K_seg + 1) := by rw [pow_succ']
            _ ≤ 2 ^ (K_seg - t + k) := Nat.pow_le_pow_right (by omega) (by omega)
        omega
      omega
  subst h_eq_k; rfl

structure EpochRadTree where
  ep : ℕ
  nEp : ℕ → ℕ
  nPres : ℕ → Bool
  nUid : ℕ → ℕ
  nRadSq : ℕ → ℝ

def EpochRadTree.empty : EpochRadTree :=
  { ep := 1, nEp := fun _ => 0, nPres := fun _ => false, nUid := fun _ => 0, nRadSq := fun _ => 0 }

noncomputable def EpochRadTree.effVal (T : EpochRadTree) (v : ℕ) : Option (ℕ × ℝ) :=
  if T.nEp v = T.ep ∧ T.nPres v = true then some (T.nUid v, T.nRadSq v) else none

noncomputable def combineRadOpt (L R : Option (ℕ × ℝ)) : Option (ℕ × ℝ) :=
  open Classical in
  match L, R with
  | none, r => r
  | some l, none => some l
  | some (u₁, d₁), some (u₂, d₂) => if d₁ < d₂ then some (u₂, d₂) else some (u₁, d₁)

noncomputable def radNodeSub (K_seg n : ℕ) (S : Finset ℕ) (v : ℕ) : Finset ℕ :=
  S.filter (fun u => inRadSubtree (2 ^ K_seg) (u % n) v)

def RadNodeSpec {d : ℕ} (K_seg n : ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (S : Finset ℕ) (val : Option (ℕ × ℝ)) (v : ℕ) : Prop :=
  let sub := radNodeSub K_seg n S v
  match val with
  | none => sub = ∅
  | some (u, r) =>
      u ∈ sub ∧ r = ‖pts u - o‖ ^ 2 ∧ ∀ x ∈ sub, ‖pts x - o‖ ^ 2 ≤ r

def EpochRadTree.WF {d : ℕ} (K_seg n : ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (S : Finset ℕ) (T : EpochRadTree) : Prop :=
  1 ≤ T.ep ∧
  (∀ v < 2 * 2 ^ K_seg, T.nEp v ≤ T.ep) ∧
  (∀ x ∈ S, ∀ y ∈ S, x % n = y % n → x = y) ∧
  (∀ v : ℕ, 1 ≤ v → v < 2 * 2 ^ K_seg → RadNodeSpec K_seg n pts o S (T.effVal v) v)

theorem EpochRadTree.wf_empty {d : ℕ} (K_seg n : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) :
    EpochRadTree.empty.WF K_seg n pts o ∅ := by
  unfold EpochRadTree.WF
  refine ⟨le_rfl, fun _ _ => Nat.zero_le 1, fun _ hx => by simp at hx, fun v _ _ => ?_⟩
  have heff : EpochRadTree.empty.effVal v = none := by simp [EpochRadTree.effVal, EpochRadTree.empty]
  rw [heff]; simp [RadNodeSpec, radNodeSub]

def EpochRadTree.clear (newEp : ℕ) (T : EpochRadTree) : EpochRadTree :=
  { T with ep := newEp }

theorem EpochRadTree.wf_clear {d : ℕ} {K_seg n : ℕ}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {T : EpochRadTree}
    (hwf : T.WF K_seg n pts o S) {newEp : ℕ} (hgt : T.ep < newEp) :
    (T.clear newEp).WF K_seg n pts o ∅ := by
  obtain ⟨_, hle, _, _⟩ := hwf
  unfold EpochRadTree.WF
  refine ⟨show 1 ≤ newEp by omega, fun v hv => le_of_lt (lt_of_le_of_lt (hle v hv) hgt),
    fun _ hx => by simp at hx, fun v _ hv => ?_⟩
  have heff : (T.clear newEp).effVal v = none := by
    unfold EpochRadTree.effVal EpochRadTree.clear
    have hne : T.nEp v ≠ newEp := by have := hle v hv; omega
    simp [hne]
  rw [heff]; simp [RadNodeSpec, radNodeSub]

theorem EpochRadTree.root_spec {d : ℕ} {K_seg n : ℕ} (hn_pos : 1 ≤ n) (hn_le : n ≤ 2 ^ K_seg)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {T : EpochRadTree} (hwf : T.WF K_seg n pts o S) :
    (T.effVal 1 = none ↔ S = ∅) ∧
    (∀ u r, T.effVal 1 = some (u, r) →
      IsNodeMaxRadiusPoint pts o S u ∧ r = (nodeMaxRadius pts o S) ^ 2) := by
  have h1_lt : 1 < 2 * 2 ^ K_seg := by have := Nat.one_le_two_pow (n := K_seg); omega
  have hsp := hwf.2.2.2 1 le_rfl h1_lt
  have hsub1 : radNodeSub K_seg n S 1 = S := by
    ext x
    simp only [radNodeSub, Finset.mem_filter, and_iff_left_iff_imp]
    intro _
    exact inRadSubtree_root (lt_of_lt_of_le (Nat.mod_lt x hn_pos) hn_le)
  unfold RadNodeSpec at hsp
  rw [hsub1] at hsp
  constructor
  · cases hval : T.effVal 1 with
    | none => rw [hval] at hsp; exact ⟨fun _ => hsp, fun _ => rfl⟩
    | some ur =>
        rcases ur with ⟨u, r⟩
        rw [hval] at hsp
        exact ⟨fun h => (by cases h), fun hS => False.elim (by rw [hS] at hsp; exact Finset.notMem_empty u hsp.1)⟩
  · intro u r hval
    rw [hval] at hsp
    obtain ⟨huS, hr_eq, hmax⟩ := hsp
    have hNE : S.Nonempty := ⟨u, huS⟩
    have hnorm_le : ∀ x ∈ S, ‖pts x - o‖ ≤ ‖pts u - o‖ := by
      intro x hx
      have hsq : ‖pts x - o‖ ^ 2 ≤ ‖pts u - o‖ ^ 2 := hr_eq ▸ hmax x hx
      exact (abs_le_of_sq_le_sq' hsq (norm_nonneg _)).2
    have hsup_eq : nodeMaxRadius pts o S = ‖pts u - o‖ := by
      unfold nodeMaxRadius
      rw [dif_pos hNE]
      exact le_antisymm (Finset.sup'_le hNE _ hnorm_le)
        (Finset.le_sup' (fun i => ‖pts i - o‖) huS)
    exact ⟨⟨huS, hsup_eq.symm⟩, by rw [hsup_eq, hr_eq]⟩

noncomputable def EpochRadTree.writeNode (T : EpochRadTree) (v : ℕ) : Option (ℕ × ℝ) → EpochRadTree
  | none =>
      { ep := T.ep
        nEp := Function.update T.nEp v T.ep
        nPres := Function.update T.nPres v false
        nUid := Function.update T.nUid v 0
        nRadSq := Function.update T.nRadSq v 0 }
  | some (u, r) =>
      { ep := T.ep
        nEp := Function.update T.nEp v T.ep
        nPres := Function.update T.nPres v true
        nUid := Function.update T.nUid v u
        nRadSq := Function.update T.nRadSq v r }

@[simp] theorem EpochRadTree.effVal_writeNode_self (T : EpochRadTree) (v : ℕ) (opt : Option (ℕ × ℝ)) :
    (T.writeNode v opt).effVal v = opt := by
  cases opt with
  | none => simp [EpochRadTree.writeNode, EpochRadTree.effVal]
  | some ur => rcases ur with ⟨u, r⟩; simp [EpochRadTree.writeNode, EpochRadTree.effVal]

theorem EpochRadTree.effVal_writeNode_of_ne (T : EpochRadTree) {v w : ℕ} (hne : w ≠ v)
    (opt : Option (ℕ × ℝ)) :
    (T.writeNode v opt).effVal w = T.effVal w := by
  cases opt with
  | none => simp [EpochRadTree.writeNode, EpochRadTree.effVal, Function.update_of_ne hne]
  | some ur => rcases ur with ⟨u, r⟩; simp [EpochRadTree.writeNode, EpochRadTree.effVal, Function.update_of_ne hne]

noncomputable def EpochRadTree.pullParent (T : EpochRadTree) (p : ℕ) : EpochRadTree :=
  T.writeNode p (combineRadOpt (T.effVal (2 * p)) (T.effVal (2 * p + 1)))

noncomputable def EpochRadTree.updatePathStep (ct : ℕ × EpochRadTree) : ℕ × EpochRadTree :=
  let p := ct.1 / 2
  (p, ct.2.pullParent p)

noncomputable def EpochRadTree.updateLeaf (K_seg h : ℕ) (opt : Option (ℕ × ℝ)) (T : EpochRadTree) :
    EpochRadTree :=
  let v₀ := 2 ^ K_seg + h
  ((EpochRadTree.updatePathStep)^[K_seg] (v₀, T.writeNode v₀ opt)).2

private lemma radNodeSpec_combine {d : ℕ} {K_seg n : ℕ}
    (hn_pos : 1 ≤ n) (hn_le : n ≤ 2 ^ K_seg)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {p : ℕ} (hp1 : 1 ≤ p) (hpM : p < 2 ^ K_seg)
    {vL vR : Option (ℕ × ℝ)}
    (hL : RadNodeSpec K_seg n pts o S vL (2 * p))
    (hR : RadNodeSpec K_seg n pts o S vR (2 * p + 1)) :
    RadNodeSpec K_seg n pts o S (combineRadOpt vL vR) p := by
  have hunion : radNodeSub K_seg n S p = radNodeSub K_seg n S (2 * p) ∪ radNodeSub K_seg n S (2 * p + 1) := by
    ext x
    simp only [radNodeSub, Finset.mem_union, Finset.mem_filter]
    have hx_lt : x % n < 2 ^ K_seg := lt_of_lt_of_le (Nat.mod_lt x hn_pos) hn_le
    rw [inRadSubtree_internal_iff hx_lt hp1 hpM]
    tauto
  unfold RadNodeSpec at hL hR ⊢
  rw [hunion]
  cases vL with
  | none =>
      simp only [combineRadOpt]
      rw [hL, Finset.empty_union]
      exact hR
  | some lr =>
      rcases lr with ⟨u₁, d₁⟩
      cases vR with
      | none =>
          simp only [combineRadOpt]
          rw [hR, Finset.union_empty]
          exact hL
      | some rr =>
          rcases rr with ⟨u₂, d₂⟩
          simp only [combineRadOpt]
          split_ifs with hlt
          · refine ⟨Finset.mem_union_right _ hR.1, hR.2.1, fun x hx => ?_⟩
            rcases Finset.mem_union.mp hx with hxL | hxR
            · exact (hL.2.2 x hxL).trans (le_of_lt hlt)
            · exact hR.2.2 x hxR
          · refine ⟨Finset.mem_union_left _ hL.1, hL.2.1, fun x hx => ?_⟩
            rcases Finset.mem_union.mp hx with hxL | hxR
            · exact hL.2.2 x hxL
            · exact (hR.2.2 x hxR).trans (not_lt.mp hlt)

theorem EpochRadTree.wf_updateLeaf {d : ℕ} {K_seg n : ℕ}
    (hn_pos : 1 ≤ n) (hn_le : n ≤ 2 ^ K_seg)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S S' : Finset ℕ} {T : EpochRadTree} (hwf : T.WF K_seg n pts o S)
    {h : ℕ} (hh_lt : h < n) (opt : Option (ℕ × ℝ))
    (hinjS' : ∀ x ∈ S', ∀ y ∈ S', x % n = y % n → x = y)
    (hother : ∀ u, u % n ≠ h → (u ∈ S' ↔ u ∈ S))
    (hleaf : RadNodeSpec K_seg n pts o S' opt (2 ^ K_seg + h)) :
    (T.updateLeaf K_seg h opt).WF K_seg n pts o S' := by
  have hh_2K : h < 2 ^ K_seg := lt_of_lt_of_le hh_lt hn_le
  let v₀ := 2 ^ K_seg + h
  let T₀ := T.writeNode v₀ opt
  have hsub_unch : ∀ v : ℕ, ¬ inRadSubtree (2 ^ K_seg) h v →
      radNodeSub K_seg n S' v = radNodeSub K_seg n S v := by
    intro v hnot
    ext u
    simp only [radNodeSub, Finset.mem_filter]
    by_cases huh : u % n = h
    · rw [huh]
      exact ⟨fun ⟨_, hin⟩ => absurd hin hnot, fun ⟨_, hin⟩ => absurd hin hnot⟩
    · rw [hother u huh]
  have hInv : ∀ t ≤ K_seg,
      let ct := (EpochRadTree.updatePathStep)^[t] (v₀, T₀)
      ct.1 = v₀ / (2 ^ t) ∧
      ct.2.ep = T.ep ∧
      (∀ v < 2 * 2 ^ K_seg, ct.2.nEp v ≤ T.ep) ∧
      (∀ v : ℕ, 1 ≤ v → v < 2 ^ (K_seg - t) → ct.2.effVal v = T.effVal v) ∧
      (∀ v : ℕ, 2 ^ (K_seg - t) ≤ v → v < 2 * 2 ^ K_seg →
        RadNodeSpec K_seg n pts o S' (ct.2.effVal v) v) := by
    intro t
    induction t with
    | zero =>
        intro _
        dsimp only [Function.iterate_zero, id_eq, Nat.sub_zero]
        rw [pow_zero, Nat.div_one]
        refine ⟨rfl, ?_, ?_, ?_, ?_⟩
        · cases opt <;> rfl
        · intro v hv
          cases opt with
          | none =>
              dsimp [T₀, EpochRadTree.writeNode]
              by_cases he : v = v₀
              · subst he; simp
              · rw [Function.update_of_ne he]; exact hwf.2.1 v hv
          | some ur =>
              rcases ur with ⟨u, r⟩
              dsimp [T₀, EpochRadTree.writeNode]
              by_cases he : v = v₀
              · subst he; simp
              · rw [Function.update_of_ne he]; exact hwf.2.1 v hv
        · intro v _ hv_lt
          exact T.effVal_writeNode_of_ne (by dsimp [v₀]; omega) opt
        · intro v hv_lo hv_hi
          by_cases he : v = v₀
          · subst he; rw [T.effVal_writeNode_self]; exact hleaf
          · rw [T.effVal_writeNode_of_ne he]
            let h' := v - 2 ^ K_seg
            have hv_eq : v = 2 ^ K_seg + h' := by omega
            have hh'_lt : h' < 2 ^ K_seg := by omega
            have hnot_in : ¬ inRadSubtree (2 ^ K_seg) h v := by
              rw [hv_eq, inRadSubtree_leaf_iff hh'_lt hh_2K]; omega
            have hsp_old := hwf.2.2.2 v (by omega) hv_hi
            unfold RadNodeSpec at hsp_old ⊢
            rwa [hsub_unch v hnot_in]
    | succ t ih =>
        intro ht_le
        obtain ⟨hcur, hep_t, hle_t, hlow_t, hhigh_t⟩ := ih (Nat.le_of_succ_le ht_le)
        rw [Function.iterate_succ_apply']
        set ct := (EpochRadTree.updatePathStep)^[t] (v₀, T₀)
        let p := ct.1 / 2
        have hp_eq : p = v₀ / 2 ^ (t + 1) := by
          dsimp [p]; rw [hcur, Nat.div_div_eq_div_mul, ← pow_succ]
        have hp_lo : 2 ^ (K_seg - (t + 1)) ≤ p := by
          rw [hp_eq, Nat.le_div_iff_mul_le (Nat.two_pow_pos (t + 1)), ← pow_add,
              show K_seg - (t + 1) + (t + 1) = K_seg by omega]
          dsimp [v₀]; omega
        have hp_hi : p < 2 ^ (K_seg - t) := by
          rw [hp_eq, Nat.div_lt_iff_lt_mul (Nat.two_pow_pos (t + 1)), ← pow_add,
              show K_seg - t + (t + 1) = K_seg + 1 by omega, pow_succ']
          dsimp [v₀]; omega
        have hp1 : 1 ≤ p := le_trans Nat.one_le_two_pow hp_lo
        have hpM : p < 2 ^ K_seg := lt_of_lt_of_le hp_hi (Nat.pow_le_pow_right (by omega) (by omega))
        refine ⟨hp_eq, ?_, ?_, ?_, ?_⟩
        · dsimp [EpochRadTree.updatePathStep, EpochRadTree.pullParent]
          cases combineRadOpt (ct.2.effVal (2 * p)) (ct.2.effVal (2 * p + 1)) <;> exact hep_t
        · intro v hv
          dsimp [EpochRadTree.updatePathStep, EpochRadTree.pullParent]
          cases combineRadOpt (ct.2.effVal (2 * p)) (ct.2.effVal (2 * p + 1)) with
          | none =>
              dsimp [EpochRadTree.writeNode]
              by_cases he : v = p
              · subst he; rw [Function.update_self, hep_t]
              · rw [Function.update_of_ne he]; exact hle_t v hv
          | some ur =>
              rcases ur with ⟨u, r⟩
              dsimp [EpochRadTree.writeNode]
              by_cases he : v = p
              · subst he; rw [Function.update_self, hep_t]
              · rw [Function.update_of_ne he]; exact hle_t v hv
        · intro v hv1 hv_lt
          dsimp [EpochRadTree.updatePathStep, EpochRadTree.pullParent]
          rw [EpochRadTree.effVal_writeNode_of_ne _ (by omega)]
          exact hlow_t v hv1 (by omega)
        · intro v hv_lo hv_hi
          dsimp [EpochRadTree.updatePathStep, EpochRadTree.pullParent]
          by_cases hvp : v = p
          · subst hvp
            rw [EpochRadTree.effVal_writeNode_self]
            have h2p_lo : 2 ^ (K_seg - t) ≤ 2 * p := by
              have hexp : 2 ^ (K_seg - t) = 2 * 2 ^ (K_seg - (t + 1)) := by
                rw [show K_seg - t = (K_seg - (t + 1)) + 1 by omega, pow_succ']
              omega
            have h2p1_hi : 2 * p + 1 < 2 * 2 ^ K_seg := by omega
            exact radNodeSpec_combine hn_pos hn_le hp1 hpM
              (hhigh_t (2 * p) h2p_lo (by omega))
              (hhigh_t (2 * p + 1) (by omega) h2p1_hi)
          · rw [EpochRadTree.effVal_writeNode_of_ne _ hvp]
            by_cases hv_ge : 2 ^ (K_seg - t) ≤ v
            · exact hhigh_t v hv_ge hv_hi
            · have hv_lt_mid : v < 2 * 2 ^ (K_seg - (t + 1)) := by
                have hexp : 2 ^ (K_seg - t) = 2 * 2 ^ (K_seg - (t + 1)) := by
                  rw [show K_seg - t = (K_seg - (t + 1)) + 1 by omega, pow_succ']
                omega
              have hnot_in : ¬ inRadSubtree (2 ^ K_seg) h v := by
                intro hin
                have heq := inRadSubtree_unique_at_depth hh_2K ht_le hv_lo hv_lt_mid hin
                exact hvp (heq.trans hp_eq.symm)
              rw [hlow_t v (le_trans Nat.one_le_two_pow hv_lo) (by omega)]
              have hsp_old := hwf.2.2.2 v (le_trans Nat.one_le_two_pow hv_lo) hv_hi
              unfold RadNodeSpec at hsp_old ⊢
              rwa [hsub_unch v hnot_in]
  obtain ⟨_, hep_f, hle_f, _, hhigh_f⟩ := hInv K_seg le_rfl
  rw [Nat.sub_self, pow_zero] at hhigh_f
  exact ⟨hep_f ▸ hwf.1, hep_f ▸ hle_f, hinjS', hhigh_f⟩

theorem EpochRadTree.wf_insert {d : ℕ} {K_seg n : ℕ}
    (hn_pos : 1 ≤ n) (hn_le : n ≤ 2 ^ K_seg)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {T : EpochRadTree} (hwf : T.WF K_seg n pts o S)
    (uid : ℕ) (hfresh : ∀ x ∈ S, x % n ≠ uid % n) :
    (T.updateLeaf K_seg (uid % n) (some (uid, ‖pts uid - o‖ ^ 2))).WF K_seg n pts o (Insert.insert uid S) := by
  have hh_lt : uid % n < n := Nat.mod_lt uid hn_pos
  have hh_2K : uid % n < 2 ^ K_seg := lt_of_lt_of_le hh_lt hn_le
  refine T.wf_updateLeaf hn_pos hn_le hwf hh_lt _ ?_ ?_ ?_
  · intro x hx y hy hmod
    rcases Finset.mem_insert.mp hx with rfl | hxS <;> rcases Finset.mem_insert.mp hy with rfl | hyS
    · rfl
    · exact absurd hmod.symm (hfresh y hyS)
    · exact absurd hmod (hfresh x hxS)
    · exact hwf.2.2.1 x hxS y hyS hmod
  · intro u huh
    simp only [Finset.mem_insert, or_iff_right_iff_imp]
    rintro rfl; exact absurd rfl huh
  · unfold RadNodeSpec
    have hmem : uid ∈ radNodeSub K_seg n (Insert.insert uid S) (2 ^ K_seg + uid % n) := by
      simp only [radNodeSub, Finset.mem_filter, Finset.mem_insert, true_or, true_and]
      exact (inRadSubtree_leaf_iff hh_2K hh_2K).mpr rfl
    refine ⟨hmem, rfl, fun x hx => ?_⟩
    simp only [radNodeSub, Finset.mem_filter] at hx
    have hx_mod : x % n = uid % n :=
      (inRadSubtree_leaf_iff hh_2K (lt_of_lt_of_le (Nat.mod_lt x hn_pos) hn_le)).mp hx.2
    rcases Finset.mem_insert.mp hx.1 with rfl | hxS
    · exact le_rfl
    · exact absurd hx_mod (hfresh x hxS)

theorem EpochRadTree.wf_delete {d : ℕ} {K_seg n : ℕ}
    (hn_pos : 1 ≤ n) (hn_le : n ≤ 2 ^ K_seg)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} {T : EpochRadTree} (hwf : T.WF K_seg n pts o S)
    (uid : ℕ) (huidS : uid ∈ S) :
    (T.updateLeaf K_seg (uid % n) none).WF K_seg n pts o (S.erase uid) := by
  have hh_lt : uid % n < n := Nat.mod_lt uid hn_pos
  have hh_2K : uid % n < 2 ^ K_seg := lt_of_lt_of_le hh_lt hn_le
  refine T.wf_updateLeaf hn_pos hn_le hwf hh_lt none ?_ ?_ ?_
  · intro x hx y hy
    exact hwf.2.2.1 x (Finset.mem_of_mem_erase hx) y (Finset.mem_of_mem_erase hy)
  · intro u huh
    have hne : u ≠ uid := fun heq => huh (congrArg (· % n) heq)
    simp [Finset.mem_erase, hne]
  · unfold RadNodeSpec
    ext x
    simp only [radNodeSub, Finset.mem_filter, Finset.mem_erase, Finset.notMem_empty, iff_false, not_and]
    rintro ⟨hx_ne, hxS⟩ hin
    have hx_mod : x % n = uid % n :=
      (inRadSubtree_leaf_iff hh_2K (lt_of_lt_of_le (Nat.mod_lt x hn_pos) hn_le)).mp hin
    exact hx_ne (hwf.2.2.1 x hxS uid huidS hx_mod)

/-! ### 3. `ArithRAM` Heap Encoding & `DetExec` Subroutines for `EpochRadTree` -/

def radTreeWStride (K_seg : ℕ) : ℤ := 4 + 6 * ((2 ^ K_seg : ℕ) : ℤ)
def radTreeRStride (K_seg : ℕ) : ℤ := 2 * ((2 ^ K_seg : ℕ) : ℤ)

lemma radTreeWStride_ge_four (K_seg : ℕ) : 4 ≤ radTreeWStride K_seg := by
  have h : (0 : ℤ) ≤ ((2 ^ K_seg : ℕ) : ℤ) := by positivity
  unfold radTreeWStride; linarith

lemma radTreeWStride_gt_node {K_seg v : ℕ} (hv : v < 2 * 2 ^ K_seg) :
    4 + 3 * (v : ℤ) + 2 < radTreeWStride K_seg := by
  have hvZ : (v : ℤ) < 2 * ((2 ^ K_seg : ℕ) : ℤ) := by exact_mod_cast hv
  unfold radTreeWStride; linarith

lemma radTreeRStride_gt_node {K_seg v : ℕ} (hv : v < 2 * 2 ^ K_seg) :
    (v : ℤ) < radTreeRStride K_seg := by
  have hvZ : (v : ℤ) < 2 * ((2 ^ K_seg : ℕ) : ℤ) := by exact_mod_cast hv
  unfold radTreeRStride; linarith

def EncEpochRadTree (tblW : ℕ) (baseW : ℤ) (tblR : ℕ) (baseR : ℤ)
    (K_seg : ℕ) (T : EpochRadTree) (m : ArithRAMMemory) : Prop :=
  H3a.wRead m tblW baseW = (T.ep : ℤ) ∧
  ∀ (v : ℕ), v < 2 * 2 ^ K_seg →
    H3a.wRead m tblW (baseW + 4 + 3 * (v : ℤ)) = (T.nEp v : ℤ) ∧
    H3a.wRead m tblW (baseW + 4 + 3 * (v : ℤ) + 1) = (if T.nPres v then 1 else 0) ∧
    H3a.wRead m tblW (baseW + 4 + 3 * (v : ℤ) + 2) = (T.nUid v : ℤ) ∧
    H3a.rRead m tblR (baseR + (v : ℤ)) = T.nRadSq v

def RadFrameOutside (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m₀ m₁ : ArithRAMMemory) : Prop :=
  (∀ t i, t ≠ scrW → (t ≠ tblW ∨ i < baseW ∨ baseW + lenW ≤ i) → H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
  (∀ t i, t ≠ scrR → (t ≠ tblR ∨ i < baseR ∨ baseR + lenR ≤ i) → H3a.rRead m₁ t i = H3a.rRead m₀ t i)

theorem RadFrameOutside.refl (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m m :=
  ⟨fun _ _ _ _ => rfl, fun _ _ _ _ => rfl⟩

theorem RadFrameOutside.trans {scrW scrR tblW : ℕ} {baseW lenW : ℤ}
    {tblR : ℕ} {baseR lenR : ℤ} {m₀ m₁ m₂ : ArithRAMMemory}
    (h₁ : RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m₀ m₁)
    (h₂ : RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m₁ m₂) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m₀ m₂ :=
  ⟨fun t i hs ho => (h₂.1 t i hs ho).trans (h₁.1 t i hs ho),
   fun t i hs ho => (h₂.2 t i hs ho).trans (h₁.2 t i hs ho)⟩

/-- `O(1)` clear of `EpochRadTree` by writing `newEpE` to `(tblW, baseWE)`. -/
def radTreeClearStmt (tblW : ℕ) (baseWE newEpE : IntExpr) : ArithRAMStmt :=
  .writeWordHeap tblW baseWE newEpE

theorem exec_radTreeClearStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (baseW baseR : ℤ) (baseWE newEpE : IntExpr) (K_seg newEp : ℕ) (T : EpochRadTree)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htblW : tblW < TW)
    (hbaseW : 0 ≤ baseW ∧ baseW + radTreeWStride K_seg ≤ (BW : ℤ))
    (hbE : iValAt 0 inp m₀ baseWE = baseW)
    (heE : iValAt 0 inp m₀ newEpE = (newEp : ℤ))
    (hops : UL.Proof_lem_7_2_RacerP33.intExprOps baseWE + UL.Proof_lem_7_2_RacerP33.intExprOps newEpE + 1 ≤ 25)
    (henc : EncEpochRadTree tblW baseW tblR baseR K_seg T m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (radTreeClearStmt tblW baseWE newEpE) m₀ m₁ 25 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncEpochRadTree tblW baseW tblR baseR K_seg (T.clear newEp) m₁ ∧
      RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR 0 m₀ m₁ := by
  let m₁ := H3a.wWrite m₀ tblW baseW (newEp : ℤ)
  have hd : DetExec inp (radTreeClearStmt tblW baseWE newEpE) m₀ m₁ 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW baseWE newEpE hbE heE hops
  refine ⟨m₁, hd, InFootprint.wWrite hfp₀ htblW hbaseW.1 (by have := radTreeWStride_ge_four K_seg; omega),
    ⟨wRead_wWrite_self _ _ _ _, fun v hv => ?_⟩, ?_⟩
  · obtain ⟨h1, h2, h3, h4⟩ := henc.2 v hv
    exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
           by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h2,
           by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h3,
           by rw [rRead_wWrite]; exact h4⟩
  · refine ⟨fun t i _ ho => ?_, fun t i _ _ => rRead_wWrite _ _ _ _ _ _⟩
    rcases ho with ht | hlt | hge
    · exact wRead_wWrite_of_ne _ _ (Or.inl ht)
    · exact wRead_wWrite_of_ne _ _ (Or.inr (by omega))
    · have := radTreeWStride_ge_four K_seg
      exact wRead_wWrite_of_ne _ _ (Or.inr (by omega))

theorem EncEpochRadTree.mono_frame {scrW scrR tblW' tblW : ℕ} {baseW' lenW' baseW : ℤ}
    {tblR' tblR : ℕ} {baseR' lenR' baseR : ℤ} {K_seg : ℕ}
    {T : EpochRadTree} {m₀ m₁ : ArithRAMMemory}
    (henc : EncEpochRadTree tblW baseW tblR baseR K_seg T m₀)
    (hfr : RadFrameOutside scrW scrR tblW' baseW' lenW' tblR' baseR' lenR' m₀ m₁)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hdisjW : tblW ≠ tblW' ∨ baseW + radTreeWStride K_seg ≤ baseW' ∨ baseW' + lenW' ≤ baseW)
    (hdisjR : tblR ≠ tblR' ∨ baseR + radTreeRStride K_seg ≤ baseR' ∨ baseR' + lenR' ≤ baseR) :
    EncEpochRadTree tblW baseW tblR baseR K_seg T m₁ := by
  have hkW : ∀ i : ℤ, baseW ≤ i → i < baseW + radTreeWStride K_seg →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i := by
    intro i hlo hhi; apply hfr.1 tblW i hneW
    rcases hdisjW with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by omega))
    · exact Or.inr (Or.inr (by omega))
  have hkR : ∀ i : ℤ, baseR ≤ i → i < baseR + radTreeRStride K_seg →
      H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i := by
    intro i hlo hhi; apply hfr.2 tblR i hneR
    rcases hdisjR with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by omega))
    · exact Or.inr (Or.inr (by omega))
  refine ⟨(hkW baseW le_rfl (by have := radTreeWStride_ge_four K_seg; omega)).trans henc.1, fun v hv => ?_⟩
  obtain ⟨h1, h2, h3, h4⟩ := henc.2 v hv
  have hw_v := radTreeWStride_gt_node hv
  have hr_v := radTreeRStride_gt_node hv
  exact ⟨(hkW _ (by omega) (by omega)).trans h1,
         (hkW _ (by omega) (by omega)).trans h2,
         (hkW _ (by omega) (by omega)).trans h3,
         (hkR _ (by omega) (by omega)).trans h4⟩

/-- Read `T.effVal v` (`v = wRead scrW wNode`) into `(scrW, wHas, wUid)` and `(scrR, rSq)`. -/
def radTreeReadNodeStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wNode wHas wUid rSq : ℤ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  let bR := IntExpr.readHeap scrW (.lit wBaseR)
  let vE := IntExpr.readHeap scrW (.lit wNode)
  let offW := IntExpr.add (.add bW (.lit 4)) (.mul (.lit 3) vE)
  .ite (.and (.intEq (.readHeap tblW offW) (.readHeap tblW bW))
             (.intEq (.readHeap tblW (.add offW (.lit 1))) (.lit 1)))
    (.seq (.writeWordHeap scrW (.lit wHas) (.lit 1))
    (.seq (.writeWordHeap scrW (.lit wUid) (.readHeap tblW (.add offW (.lit 2))))
          (.writeRealHeap scrR (.lit rSq) (.readRealHeap tblR (.add bR vE)))))
    (.seq (.writeWordHeap scrW (.lit wHas) (.lit 0))
    (.seq (.writeWordHeap scrW (.lit wUid) (.lit 0))
          (.writeRealHeap scrR (.lit rSq) (.ofInt (.lit 0)))))

theorem exec_radTreeReadNodeStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBaseR wNode wHas wUid rSq baseW baseR : ℤ)
    {K_seg v : ℕ} (hv : v < 2 * 2 ^ K_seg) (T : EpochRadTree)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hwHas : 0 ≤ wHas ∧ wHas < (BW : ℤ))
    (hwUid : 0 ≤ wUid ∧ wUid < (BW : ℤ))
    (hrSq : 0 ≤ rSq ∧ rSq < (BR : ℤ))
    (hneHasUid : wHas ≠ wUid)
    (hkeepW : ∀ w : ℤ, w ≠ wHas → w ≠ wUid → True)
    (hneNode : wNode ≠ wHas ∧ wNode ≠ wUid)
    (hneBW : wBaseW ≠ wHas ∧ wBaseW ≠ wUid)
    (hneBR : wBaseR ≠ wHas ∧ wBaseR ≠ wUid)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hbR : H3a.wRead m₀ scrW wBaseR = baseR)
    (hv_r : H3a.wRead m₀ scrW wNode = (v : ℤ))
    (henc : EncEpochRadTree tblW baseW tblR baseR K_seg T m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (radTreeReadNodeStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHas wUid rSq) m₀ m₁ 80 ∧
      InFootprint TW BW TR BR m₁ ∧
      (match T.effVal v with
       | none => H3a.wRead m₁ scrW wHas = 0 ∧ H3a.wRead m₁ scrW wUid = 0 ∧ H3a.rRead m₁ scrR rSq = 0
       | some (u, r) => H3a.wRead m₁ scrW wHas = 1 ∧ H3a.wRead m₁ scrW wUid = (u : ℤ) ∧ H3a.rRead m₁ scrR rSq = r) ∧
      (∀ w, w ≠ wHas → w ≠ wUid → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, r ≠ rSq → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  let _ := hkeepW; have _ := hneR
  obtain ⟨hepv, hprv, huv, hrv⟩ := henc.2 v hv
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  let bR := IntExpr.readHeap scrW (.lit wBaseR)
  let vE := IntExpr.readHeap scrW (.lit wNode)
  let offW := IntExpr.add (.add bW (.lit 4)) (.mul (.lit 3) vE)
  let cond : ArithCondExpr :=
    .and (.intEq (.readHeap tblW offW) (.readHeap tblW bW))
         (.intEq (.readHeap tblW (.add offW (.lit 1))) (.lit 1))
  by_cases hpres : T.nEp v = T.ep ∧ T.nPres v = true
  · have hc_t : cValAt 0 inp m₀ cond = true := by
      simp only [cValAt, cond, offW, bW, vE, evalArithCond, evalIntExpr]
      change (decide (H3a.wRead m₀ tblW ((H3a.wRead m₀ scrW wBaseW + 4) + 3 * H3a.wRead m₀ scrW wNode) =
                H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wBaseW)) &&
              decide (H3a.wRead m₀ tblW (((H3a.wRead m₀ scrW wBaseW + 4) + 3 * H3a.wRead m₀ scrW wNode) + 1) = 1)) = true
      rw [hbW, hv_r, show (baseW + 4) + 3 * (v : ℤ) = baseW + 4 + 3 * (v : ℤ) by ring,
          hepv, henc.1, hprv, hpres.1, if_pos hpres.2]; simp
    have heff : T.effVal v = some (T.nUid v, T.nRadSq v) := by
      unfold EpochRadTree.effVal; rw [if_pos hpres]
    let m1 := H3a.wWrite m₀ scrW wHas 1
    let m2 := H3a.wWrite m1 scrW wUid (T.nUid v : ℤ)
    let m3 := H3a.rWrite m2 scrR rSq (T.nRadSq v)
    have hd1 : DetExec inp (.writeWordHeap scrW (.lit wHas) (.lit 1)) m₀ m1 10 :=
      DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wHas) (.lit 1) rfl rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd2 : DetExec inp (.writeWordHeap scrW (.lit wUid) (.readHeap tblW (.add offW (.lit 2)))) m1 m2 20 := by
      refine DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wUid) _ rfl ?_
        (by dsimp [offW, bW, vE, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      change H3a.wRead m1 tblW (((H3a.wRead m1 scrW wBaseW + 4) + 3 * H3a.wRead m1 scrW wNode) + 2) = _
      rw [wRead_wWrite_of_ne _ _ (Or.inr hneBW.1), hbW,
          wRead_wWrite_of_ne _ _ (Or.inr hneNode.1), hv_r,
          wRead_wWrite_of_ne _ _ (Or.inl hneW),
          show ((baseW + 4) + 3 * (v : ℤ)) + 2 = baseW + 4 + 3 * (v : ℤ) + 2 by ring, huv]
    have hd3 : DetExec inp (.writeRealHeap scrR (.lit rSq) (.readRealHeap tblR (.add bR vE))) m2 m3 20 := by
      refine DetExecAt.writeRealHeap 0 inp m2 scrR (.lit rSq) _ rfl ?_
        (by dsimp [bR, vE, UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
      change H3a.rRead m2 tblR (H3a.wRead m2 scrW wBaseR + H3a.wRead m2 scrW wNode) = _
      rw [wRead_wWrite_of_ne _ _ (Or.inr hneBR.2), wRead_wWrite_of_ne _ _ (Or.inr hneBR.1), hbR,
          wRead_wWrite_of_ne _ _ (Or.inr hneNode.2), wRead_wWrite_of_ne _ _ (Or.inr hneNode.1), hv_r]
      exact hrv
    refine ⟨m3, (DetExecAt.ite_true hc_t (C_c := 30)
      (by dsimp [cond, offW, bW, vE, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      (DetExecAt.seq hd1 (DetExecAt.seq hd2 hd3))).mono_cost (by omega),
      InFootprint.rWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW hwHas.1 hwHas.2) hscrW hwUid.1 hwUid.2) hscrR hrSq.1 hrSq.2,
      ?_, ?_, ?_, ?_⟩
    · rw [heff]
      exact ⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hneHasUid), wRead_wWrite_self],
             by rw [wRead_rWrite, wRead_wWrite_self],
             rRead_rWrite_self _ _ _ _⟩
    · intro w hw1 hw2
      rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hw2), wRead_wWrite_of_ne _ _ (Or.inr hw1)]
    · intro r hr_ne
      rw [rRead_rWrite_of_ne _ _ (Or.inr hr_ne)]; rfl
    · refine ⟨fun t i hs _ => by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs)],
              fun t i hs _ => by rw [rRead_rWrite_of_ne _ _ (Or.inl hs)]; rfl⟩
  · have hc_f : cValAt 0 inp m₀ cond = false := by
      simp only [cValAt, cond, offW, bW, vE, evalArithCond, evalIntExpr]
      change (decide (H3a.wRead m₀ tblW ((H3a.wRead m₀ scrW wBaseW + 4) + 3 * H3a.wRead m₀ scrW wNode) =
                H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wBaseW)) &&
              decide (H3a.wRead m₀ tblW (((H3a.wRead m₀ scrW wBaseW + 4) + 3 * H3a.wRead m₀ scrW wNode) + 1) = 1)) = false
      rw [hbW, hv_r, show (baseW + 4) + 3 * (v : ℤ) = baseW + 4 + 3 * (v : ℤ) by ring,
          hepv, henc.1, hprv, Bool.and_eq_false_iff, decide_eq_false_iff_not, decide_eq_false_iff_not]
      by_cases h1 : T.nEp v = T.ep
      · right; have h2 : T.nPres v = false := by cases hc : T.nPres v <;> simp_all
        rw [h2]; decide
      · left; exact_mod_cast h1
    have heff : T.effVal v = none := by unfold EpochRadTree.effVal; rw [if_neg hpres]
    let m1 := H3a.wWrite m₀ scrW wHas 0
    let m2 := H3a.wWrite m1 scrW wUid 0
    let m3 := H3a.rWrite m2 scrR rSq 0
    have hd1 : DetExec inp (.writeWordHeap scrW (.lit wHas) (.lit 0)) m₀ m1 10 :=
      DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wHas) (.lit 0) rfl rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd2 : DetExec inp (.writeWordHeap scrW (.lit wUid) (.lit 0)) m1 m2 10 :=
      DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wUid) (.lit 0) rfl rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd3 : DetExec inp (.writeRealHeap scrR (.lit rSq) (.ofInt (.lit 0))) m2 m3 10 :=
      DetExecAt.writeRealHeap 0 inp m2 scrR (.lit rSq) (.ofInt (.lit 0)) rfl (by simp [rValAt, evalRealExpr, evalIntExpr])
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
    refine ⟨m3, (DetExecAt.ite_false hc_f (C_c := 30)
      (by dsimp [cond, offW, bW, vE, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      (DetExecAt.seq hd1 (DetExecAt.seq hd2 hd3))).mono_cost (by omega),
      InFootprint.rWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW hwHas.1 hwHas.2) hscrW hwUid.1 hwUid.2) hscrR hrSq.1 hrSq.2,
      ?_, ?_, ?_, ?_⟩
    · rw [heff]
      exact ⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hneHasUid), wRead_wWrite_self],
             by rw [wRead_rWrite, wRead_wWrite_self],
             rRead_rWrite_self _ _ _ _⟩
    · intro w hw1 hw2
      rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hw2), wRead_wWrite_of_ne _ _ (Or.inr hw1)]
    · intro r hr_ne
      rw [rRead_rWrite_of_ne _ _ (Or.inr hr_ne)]; rfl
    · refine ⟨fun t i hs _ => by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs)],
              fun t i hs _ => by rw [rRead_rWrite_of_ne _ _ (Or.inl hs)]; rfl⟩

/-- Write `opt` (represented by `(scrW, wHas, wUid)` and `(scrR, rSq)`) into node `v = wRead scrW wNode` of `EpochRadTree`. -/
def radTreeWriteNodeStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wNode wHas wUid rSq : ℤ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  let bR := IntExpr.readHeap scrW (.lit wBaseR)
  let vE := IntExpr.readHeap scrW (.lit wNode)
  let offW := IntExpr.add (.add bW (.lit 4)) (.mul (.lit 3) vE)
  .seq (.writeWordHeap tblW offW (.readHeap tblW bW))
    (.ite (.intEq (.readHeap scrW (.lit wHas)) (.lit 1))
      (.seq (.writeWordHeap tblW (.add offW (.lit 1)) (.lit 1))
      (.seq (.writeWordHeap tblW (.add offW (.lit 2)) (.readHeap scrW (.lit wUid)))
            (.writeRealHeap tblR (.add bR vE) (.readRealHeap scrR (.lit rSq)))))
      (.seq (.writeWordHeap tblW (.add offW (.lit 1)) (.lit 0))
      (.seq (.writeWordHeap tblW (.add offW (.lit 2)) (.lit 0))
            (.writeRealHeap tblR (.add bR vE) (.ofInt (.lit 0))))))

theorem exec_radTreeWriteNodeStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBaseR wNode wHas wUid rSq baseW baseR : ℤ)
    {K_seg v : ℕ} (hv : v < 2 * 2 ^ K_seg) (T : EpochRadTree)
    (opt : Option (ℕ × ℝ))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ baseW ∧ baseW + radTreeWStride K_seg ≤ (BW : ℤ))
    (hbaseR : 0 ≤ baseR ∧ baseR + radTreeRStride K_seg ≤ (BR : ℤ))
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hbR : H3a.wRead m₀ scrW wBaseR = baseR)
    (hv_r : H3a.wRead m₀ scrW wNode = (v : ℤ))
    (hopt : match opt with
            | none => H3a.wRead m₀ scrW wHas = 0
            | some (u, r) => H3a.wRead m₀ scrW wHas = 1 ∧ H3a.wRead m₀ scrW wUid = (u : ℤ) ∧ H3a.rRead m₀ scrR rSq = r)
    (henc : EncEpochRadTree tblW baseW tblR baseR K_seg T m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (radTreeWriteNodeStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHas wUid rSq) m₀ m₁ 90 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncEpochRadTree tblW baseW tblR baseR K_seg (T.writeNode v opt) m₁ ∧
      (∀ w, H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR (radTreeRStride K_seg) m₀ m₁ := by
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  let bR := IntExpr.readHeap scrW (.lit wBaseR)
  let vE := IntExpr.readHeap scrW (.lit wNode)
  let offW := IntExpr.add (.add bW (.lit 4)) (.mul (.lit 3) vE)
  let i0 := baseW + 4 + 3 * (v : ℤ)
  have hi0_lo : baseW ≤ i0 := by dsimp [i0]; omega
  have hi2_hi : i0 + 2 < baseW + radTreeWStride K_seg := by have := radTreeWStride_gt_node hv; dsimp [i0]; omega
  have hr_hi : baseR + (v : ℤ) < baseR + radTreeRStride K_seg := by have := radTreeRStride_gt_node hv; omega
  let m1 := H3a.wWrite m₀ tblW i0 (T.ep : ℤ)
  have hd1 : DetExec inp (.writeWordHeap tblW offW (.readHeap tblW bW)) m₀ m1 20 := by
    refine DetExecAt.writeWordHeap 0 inp m₀ tblW offW (.readHeap tblW bW) ?_ ?_
      (by dsimp [offW, bW, vE, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    · change (H3a.wRead m₀ scrW wBaseW + 4) + 3 * H3a.wRead m₀ scrW wNode = i0
      rw [hbW, hv_r]
    · change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wBaseW) = _; rw [hbW, henc.1]
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ htblW (by omega) (by omega)
  have hw_scr1 : ∀ w, H3a.wRead m1 scrW w = H3a.wRead m₀ scrW w :=
    fun w => wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)
  let cond : ArithCondExpr := .intEq (.readHeap scrW (.lit wHas)) (.lit 1)
  cases opt with
  | none =>
      have hc_f : cValAt 0 inp m1 cond = false := by
        simp only [cValAt, cond, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 scrW wHas = 1) = false
        rw [hw_scr1, hopt]; decide
      let m2 := H3a.wWrite m1 tblW (i0 + 1) 0
      let m3 := H3a.wWrite m2 tblW (i0 + 2) 0
      let m4 := H3a.rWrite m3 tblR (baseR + (v : ℤ)) 0
      have hd2 : DetExec inp (.writeWordHeap tblW (.add offW (.lit 1)) (.lit 0)) m1 m2 20 := by
        refine DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit 0) ?_ rfl
          (by dsimp [offW, bW, vE, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        change ((H3a.wRead m1 scrW wBaseW + 4) + 3 * H3a.wRead m1 scrW wNode) + 1 = i0 + 1
        rw [hw_scr1, hw_scr1, hbW, hv_r]
      have hw_scr2 : ∀ w, H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w :=
        fun w => (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans (hw_scr1 w)
      have hw_scr3 : ∀ w, H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w :=
        fun w => (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans (hw_scr2 w)
      have hd3 : DetExec inp (.writeWordHeap tblW (.add offW (.lit 2)) (.lit 0)) m2 m3 20 := by
        refine DetExecAt.writeWordHeap 0 inp m2 tblW _ (.lit 0) ?_ rfl
          (by dsimp [offW, bW, vE, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        change ((H3a.wRead m2 scrW wBaseW + 4) + 3 * H3a.wRead m2 scrW wNode) + 2 = i0 + 2
        rw [hw_scr2, hw_scr2, hbW, hv_r]
      have hd4 : DetExec inp (.writeRealHeap tblR (.add bR vE) (.ofInt (.lit 0))) m3 m4 20 := by
        refine DetExecAt.writeRealHeap 0 inp m3 tblR _ (.ofInt (.lit 0)) ?_ (by simp [rValAt, evalRealExpr, evalIntExpr])
          (by dsimp [bR, vE, UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
        change H3a.wRead m3 scrW wBaseR + H3a.wRead m3 scrW wNode = baseR + (v : ℤ)
        rw [hw_scr3, hw_scr3, hbR, hv_r]
      have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 htblW (by omega) (by omega)
      have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 htblW (by omega) (by omega)
      have hfp4 : InFootprint TW BW TR BR m4 := InFootprint.rWrite hfp3 htblR (by omega) (by omega)
      refine ⟨m4, (DetExecAt.seq hd1 (DetExecAt.ite_false hc_f (C_c := 5)
        (by dsimp [cond, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.seq hd2 (DetExecAt.seq hd3 hd4)))).mono_cost (by omega),
        hfp4, ?_, ?_, ?_, ?_⟩
      · refine ⟨?_, fun w hw => ?_⟩
        · rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)), henc.1]; rfl
        · by_cases he : w = v
          · subst he
            dsimp [EpochRadTree.writeNode]
            simp only [Function.update_self, Bool.false_eq_true, ↓reduceIte]
            exact ⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)), wRead_wWrite_self],
                   by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)), wRead_wWrite_self],
                   by rw [wRead_rWrite, wRead_wWrite_self]; rfl,
                   rRead_rWrite_self _ _ _ _⟩
          · dsimp [EpochRadTree.writeNode]
            simp only [Function.update_of_ne he]
            obtain ⟨h1, h2, h3, h4⟩ := henc.2 w hw
            exact ⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega))]; exact h1,
                   by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega))]; exact h2,
                   by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega))]; exact h3,
                   by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact h4⟩
      · intro w; rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
                     wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hw_scr1]
      · intro r; rw [rRead_rWrite_of_ne _ _ (Or.inl hneR.symm)]; rfl
      · refine ⟨fun t i _ ho => ?_, fun t i _ ho => ?_⟩
        · rw [wRead_rWrite]
          rcases ho with ht | hlt | hge
          · rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        · rcases ho with ht | hlt | hge
          · rw [rRead_rWrite_of_ne _ _ (Or.inl ht)]; rfl
          · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; rfl
          · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; rfl
  | some ur =>
      rcases ur with ⟨u, r_val⟩
      obtain ⟨hhas, huid_r, hrsq_r⟩ := hopt
      have hc_t : cValAt 0 inp m1 cond = true := by
        simp only [cValAt, cond, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 scrW wHas = 1) = true
        rw [hw_scr1, hhas]; rfl
      let m2 := H3a.wWrite m1 tblW (i0 + 1) 1
      let m3 := H3a.wWrite m2 tblW (i0 + 2) (u : ℤ)
      let m4 := H3a.rWrite m3 tblR (baseR + (v : ℤ)) r_val
      have hd2 : DetExec inp (.writeWordHeap tblW (.add offW (.lit 1)) (.lit 1)) m1 m2 20 := by
        refine DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit 1) ?_ rfl
          (by dsimp [offW, bW, vE, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        change ((H3a.wRead m1 scrW wBaseW + 4) + 3 * H3a.wRead m1 scrW wNode) + 1 = i0 + 1
        rw [hw_scr1, hw_scr1, hbW, hv_r]
      have hw_scr2 : ∀ w, H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w :=
        fun w => (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans (hw_scr1 w)
      have hw_scr3 : ∀ w, H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w :=
        fun w => (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans (hw_scr2 w)
      have hd3 : DetExec inp (.writeWordHeap tblW (.add offW (.lit 2)) (.readHeap scrW (.lit wUid))) m2 m3 20 := by
        refine DetExecAt.writeWordHeap 0 inp m2 tblW _ _ ?_ ?_
          (by dsimp [offW, bW, vE, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        · change ((H3a.wRead m2 scrW wBaseW + 4) + 3 * H3a.wRead m2 scrW wNode) + 2 = i0 + 2
          rw [hw_scr2, hw_scr2, hbW, hv_r]
        · change H3a.wRead m2 scrW wUid = (u : ℤ)
          rw [hw_scr2, huid_r]
      have hd4 : DetExec inp (.writeRealHeap tblR (.add bR vE) (.readRealHeap scrR (.lit rSq))) m3 m4 20 := by
        refine DetExecAt.writeRealHeap 0 inp m3 tblR _ _ ?_ ?_
          (by dsimp [bR, vE, UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
        · change H3a.wRead m3 scrW wBaseR + H3a.wRead m3 scrW wNode = baseR + (v : ℤ)
          rw [hw_scr3, hw_scr3, hbR, hv_r]
        · exact hrsq_r
      have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 htblW (by omega) (by omega)
      have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 htblW (by omega) (by omega)
      have hfp4 : InFootprint TW BW TR BR m4 := InFootprint.rWrite hfp3 htblR (by omega) (by omega)
      refine ⟨m4, (DetExecAt.seq hd1 (DetExecAt.ite_true hc_t (C_c := 5)
        (by dsimp [cond, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.seq hd2 (DetExecAt.seq hd3 hd4)))).mono_cost (by omega),
        hfp4, ?_, ?_, ?_, ?_⟩
      · refine ⟨?_, fun w hw => ?_⟩
        · rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)), henc.1]; rfl
        · by_cases he : w = v
          · subst he
            dsimp [EpochRadTree.writeNode]
            simp only [Function.update_self, ↓reduceIte]
            exact ⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)), wRead_wWrite_self],
                   by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)), wRead_wWrite_self],
                   by rw [wRead_rWrite, wRead_wWrite_self],
                   rRead_rWrite_self _ _ _ _⟩
          · dsimp [EpochRadTree.writeNode]
            simp only [Function.update_of_ne he]
            obtain ⟨h1, h2, h3, h4⟩ := henc.2 w hw
            exact ⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega))]; exact h1,
                   by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega))]; exact h2,
                   by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega)),
                          wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [i0]; omega))]; exact h3,
                   by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact h4⟩
      · intro w; rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
                     wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hw_scr1]
      · intro r; rw [rRead_rWrite_of_ne _ _ (Or.inl hneR.symm)]; rfl
      · refine ⟨fun t i _ ho => ?_, fun t i _ ho => ?_⟩
        · rw [wRead_rWrite]
          rcases ho with ht | hlt | hge
          · rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        · rcases ho with ht | hlt | hge
          · rw [rRead_rWrite_of_ne _ _ (Or.inl ht)]; rfl
          · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; rfl
          · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; rfl

/-- Combine `(wHasL, wUidL, rSqL)` and `(wHasR, wUidR, rSqR)` into `(wHasL, wUidL, rSqL)` matching `combineRadOpt`. -/
def combineRadRegsStmt (scrW scrR : ℕ)
    (wHasL wUidL rSqL wHasR wUidR rSqR : ℤ) : ArithRAMStmt :=
  .ite (.intEq (.readHeap scrW (.lit wHasL)) (.lit 0))
    (.seq (.writeWordHeap scrW (.lit wHasL) (.readHeap scrW (.lit wHasR)))
    (.seq (.writeWordHeap scrW (.lit wUidL) (.readHeap scrW (.lit wUidR)))
          (.writeRealHeap scrR (.lit rSqL) (.readRealHeap scrR (.lit rSqR)))))
    (.ite (.intEq (.readHeap scrW (.lit wHasR)) (.lit 0))
      .skip
      (.ite (.realLt (.readRealHeap scrR (.lit rSqL)) (.readRealHeap scrR (.lit rSqR)))
        (.seq (.writeWordHeap scrW (.lit wUidL) (.readHeap scrW (.lit wUidR)))
              (.writeRealHeap scrR (.lit rSqL) (.readRealHeap scrR (.lit rSqR))))
        .skip))

theorem exec_combineRadRegsStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wHasL wUidL rSqL wHasR wUidR rSqR baseW baseR : ℤ)
    (vL vR : Option (ℕ × ℝ))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hwHL : 0 ≤ wHasL ∧ wHasL < (BW : ℤ))
    (hwUL : 0 ≤ wUidL ∧ wUidL < (BW : ℤ))
    (hrSL : 0 ≤ rSqL ∧ rSqL < (BR : ℤ))
    (hdisjW : wHasL ≠ wUidL ∧ wHasL ≠ wHasR ∧ wHasL ≠ wUidR ∧ wUidL ≠ wHasR ∧ wUidL ≠ wUidR)
    (_hdisjR : rSqL ≠ rSqR)
    (hL : match vL with
          | none => H3a.wRead m₀ scrW wHasL = 0
          | some (u, r) => H3a.wRead m₀ scrW wHasL = 1 ∧ H3a.wRead m₀ scrW wUidL = (u : ℤ) ∧ H3a.rRead m₀ scrR rSqL = r)
    (hR : match vR with
          | none => H3a.wRead m₀ scrW wHasR = 0
          | some (u, r) => H3a.wRead m₀ scrW wHasR = 1 ∧ H3a.wRead m₀ scrW wUidR = (u : ℤ) ∧ H3a.rRead m₀ scrR rSqR = r) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (combineRadRegsStmt scrW scrR wHasL wUidL rSqL wHasR wUidR rSqR) m₀ m₁ 60 ∧
      InFootprint TW BW TR BR m₁ ∧
      (match combineRadOpt vL vR with
       | none => H3a.wRead m₁ scrW wHasL = 0
       | some (u, r) => H3a.wRead m₁ scrW wHasL = 1 ∧ H3a.wRead m₁ scrW wUidL = (u : ℤ) ∧ H3a.rRead m₁ scrR rSqL = r) ∧
      (∀ w, w ≠ wHasL → w ≠ wUidL → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, r ≠ rSqL → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  let cL0 : ArithCondExpr := .intEq (.readHeap scrW (.lit wHasL)) (.lit 0)
  cases vL with
  | none =>
      have hcL_t : cValAt 0 inp m₀ cL0 = true := by
        simp only [cValAt, cL0, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m₀ scrW wHasL = 0) = true; rw [hL]; rfl
      let m1 := H3a.wWrite m₀ scrW wHasL (H3a.wRead m₀ scrW wHasR)
      let m2 := H3a.wWrite m1 scrW wUidL (H3a.wRead m₀ scrW wUidR)
      let m3 := H3a.rWrite m2 scrR rSqL (H3a.rRead m₀ scrR rSqR)
      have hd1 : DetExec inp (.writeWordHeap scrW (.lit wHasL) (.readHeap scrW (.lit wHasR))) m₀ m1 10 :=
        DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wHasL) (.readHeap scrW (.lit wHasR)) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit wUidL) (.readHeap scrW (.lit wUidR))) m1 m2 10 := by
        refine DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wUidL) (.readHeap scrW (.lit wUidR)) rfl ?_
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        change H3a.wRead m1 scrW wUidR = _
        exact wRead_wWrite_of_ne _ _ (Or.inr hdisjW.2.2.1.symm)
      have hd3 : DetExec inp (.writeRealHeap scrR (.lit rSqL) (.readRealHeap scrR (.lit rSqR))) m2 m3 10 :=
        DetExecAt.writeRealHeap 0 inp m2 scrR (.lit rSqL) (.readRealHeap scrR (.lit rSqR)) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
      refine ⟨m3, (DetExecAt.ite_true hcL_t (C_c := 10)
        (by dsimp [cL0, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.seq hd1 (DetExecAt.seq hd2 hd3))).mono_cost (by omega),
        InFootprint.rWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW hwHL.1 hwHL.2) hscrW hwUL.1 hwUL.2) hscrR hrSL.1 hrSL.2,
        ?_, ?_, ?_, ?_⟩
      · dsimp [combineRadOpt]
        cases vR with
        | none =>
            rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hdisjW.1), wRead_wWrite_self, hR]
        | some rr =>
            rcases rr with ⟨u₂, d₂⟩
            exact ⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hdisjW.1), wRead_wWrite_self, hR.1],
                   by rw [wRead_rWrite, wRead_wWrite_self, hR.2.1],
                   by rw [rRead_rWrite_self, hR.2.2]⟩
      · intro w hw1 hw2
        rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hw2), wRead_wWrite_of_ne _ _ (Or.inr hw1)]
      · intro r hr_ne; rw [rRead_rWrite_of_ne _ _ (Or.inr hr_ne)]; rfl
      · exact ⟨fun t i hs _ => by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs)],
               fun t i hs _ => by rw [rRead_rWrite_of_ne _ _ (Or.inl hs)]; rfl⟩
  | some lr =>
      rcases lr with ⟨u₁, d₁⟩
      have hcL_f : cValAt 0 inp m₀ cL0 = false := by
        simp only [cValAt, cL0, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m₀ scrW wHasL = 0) = false; rw [hL.1]; decide
      let cR0 : ArithCondExpr := .intEq (.readHeap scrW (.lit wHasR)) (.lit 0)
      cases vR with
      | none =>
          have hcR_t : cValAt 0 inp m₀ cR0 = true := by
            simp only [cValAt, cR0, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m₀ scrW wHasR = 0) = true; rw [hR]; rfl
          refine ⟨m₀, (DetExecAt.ite_false hcL_f (C_c := 10)
            (by dsimp [cL0, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            (DetExecAt.ite_true hcR_t (C_c := 10)
              (by dsimp [cR0, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.skip 0 inp m₀))).mono_cost (by omega),
            hfp₀, by dsimp [combineRadOpt]; exact hL, fun _ _ _ => rfl, fun _ _ => rfl,
            RadFrameOutside.refl _ _ _ _ _ _ _ _ _⟩
      | some rr =>
          rcases rr with ⟨u₂, d₂⟩
          have hcR_f : cValAt 0 inp m₀ cR0 = false := by
            simp only [cValAt, cR0, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m₀ scrW wHasR = 0) = false; rw [hR.1]; decide
          let cLt : ArithCondExpr := .realLt (.readRealHeap scrR (.lit rSqL)) (.readRealHeap scrR (.lit rSqR))
          by_cases hlt : d₁ < d₂
          · have hcLt_t : cValAt 0 inp m₀ cLt = true := by
              simp only [cValAt, cLt, evalArithCond, evalRealExpr, evalIntExpr]
              change decide (H3a.rRead m₀ scrR rSqL < H3a.rRead m₀ scrR rSqR) = true
              rw [hL.2.2, hR.2.2, decide_eq_true_eq]; exact hlt
            let m1 := H3a.wWrite m₀ scrW wUidL (u₂ : ℤ)
            let m2 := H3a.rWrite m1 scrR rSqL d₂
            have hd1 : DetExec inp (.writeWordHeap scrW (.lit wUidL) (.readHeap scrW (.lit wUidR))) m₀ m1 10 :=
              DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wUidL) (.readHeap scrW (.lit wUidR)) rfl hR.2.1
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hd2 : DetExec inp (.writeRealHeap scrR (.lit rSqL) (.readRealHeap scrR (.lit rSqR))) m1 m2 10 :=
              DetExecAt.writeRealHeap 0 inp m1 scrR (.lit rSqL) (.readRealHeap scrR (.lit rSqR)) rfl hR.2.2
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
            refine ⟨m2, (DetExecAt.ite_false hcL_f (C_c := 10)
              (by dsimp [cL0, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.ite_false hcR_f (C_c := 10)
                (by dsimp [cR0, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                (DetExecAt.ite_true hcLt_t (C_c := 10)
                  (by dsimp [cLt, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                  (DetExecAt.seq hd1 hd2)))).mono_cost (by omega),
              InFootprint.rWrite (InFootprint.wWrite hfp₀ hscrW hwUL.1 hwUL.2) hscrR hrSL.1 hrSL.2,
              ?_, ?_, ?_, ?_⟩
            · dsimp [combineRadOpt]; rw [if_pos hlt]
              exact ⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hdisjW.1), hL.1],
                     by rw [wRead_rWrite, wRead_wWrite_self],
                     rRead_rWrite_self _ _ _ _⟩
            · intro w _ hw2; rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr hw2)]
            · intro r hr_ne; rw [rRead_rWrite_of_ne _ _ (Or.inr hr_ne)]; rfl
            · exact ⟨fun t i hs _ => by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inl hs)],
                     fun t i hs _ => by rw [rRead_rWrite_of_ne _ _ (Or.inl hs)]; rfl⟩
          · have hcLt_f : cValAt 0 inp m₀ cLt = false := by
              simp only [cValAt, cLt, evalArithCond, evalRealExpr, evalIntExpr]
              change decide (H3a.rRead m₀ scrR rSqL < H3a.rRead m₀ scrR rSqR) = false
              rw [hL.2.2, hR.2.2, decide_eq_false_iff_not]; exact hlt
            refine ⟨m₀, (DetExecAt.ite_false hcL_f (C_c := 10)
              (by dsimp [cL0, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.ite_false hcR_f (C_c := 10)
                (by dsimp [cR0, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                (DetExecAt.ite_false hcLt_f (C_c := 10)
                  (by dsimp [cLt, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
                  (DetExecAt.skip 0 inp m₀)))).mono_cost (by omega),
              hfp₀, by dsimp [combineRadOpt]; rw [if_neg hlt]; exact hL,
              fun _ _ _ => rfl, fun _ _ => rfl, RadFrameOutside.refl _ _ _ _ _ _ _ _ _⟩

/-- Prepare leaf registers `(wScr + 2, wScr + 3, rScr)` according to `insFlag` (`wRead scrW wIns`). -/
def radTreePrepLeafStmt (scrW scrR tblO : ℕ)
    (wOffO wUid wIns wScr rScr : ℤ) (d : ℕ) : ArithRAMStmt :=
  let wHasL := wScr + 2
  let wUidL := wScr + 3
  let rSqL := rScr
  let rSqR := rScr + 1
  let wCtr := wScr + 6
  let wH := wScr + 7
  .ite (.intEq (.readHeap scrW (.lit wIns)) (.lit 1))
    (.seq (.writeWordHeap scrW (.lit wHasL) (.lit 1))
    (.seq (.writeWordHeap scrW (.lit wUidL) (.readHeap scrW (.lit wUid)))
    (.seq (.writeRealHeap scrR (.lit rSqL) (.ofInt (.lit 0)))
    (.seq (.writeWordHeap scrW (.lit wCtr) (.lit 0))
          (.repeatN (.lit (d : ℤ))
            (.seq (.writeRealHeap scrR (.lit rSqR)
                    (.sub (.readRealHeap 1 (.add (.mul (.readHeap scrW (.lit wH)) (.lit (d : ℤ)))
                                                 (.readHeap scrW (.lit wCtr))))
                          (.readRealHeap tblO (.add (.readHeap scrW (.lit wOffO))
                                                    (.readHeap scrW (.lit wCtr))))))
            (.seq (.writeRealHeap scrR (.lit rSqL)
                    (.add (.readRealHeap scrR (.lit rSqL))
                          (.mul (.readRealHeap scrR (.lit rSqR)) (.readRealHeap scrR (.lit rSqR)))))
                  (.writeWordHeap scrW (.lit wCtr) (.add (.readHeap scrW (.lit wCtr)) (.lit 1))))))))))
    (.writeWordHeap scrW (.lit wHasL) (.lit 0))

private lemma exec_radTreePrepLeafStmt {d TW BW TR BR scrW scrR tblW tblR tblO : ℕ}
    (inp : ArithRAMInput d) {m3 : ArithRAMMemory}
    (wBaseW wBaseR wOffO wUid wIns wScr rScr baseW baseR offO : ℤ)
    (K_seg uid h v₀ : ℕ) (insFlag : Bool)
    (pt o : EuclideanSpace ℝ (Fin d)) (T : EpochRadTree)
    (hfp3 : InFootprint TW BW TR BR m3)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hne1 : 1 ≠ scrR) (hneO : tblO ≠ scrR)
    (hwScr : 0 ≤ wScr ∧ wScr + 8 ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + 2 ≤ (BR : ℤ))
    (hregs : (wBaseW < wScr ∨ wScr + 8 ≤ wBaseW) ∧
             (wBaseR < wScr ∨ wScr + 8 ≤ wBaseR) ∧
             (wOffO < wScr ∨ wScr + 8 ≤ wOffO) ∧
             (wUid < wScr ∨ wScr + 8 ≤ wUid) ∧
             (wIns < wScr ∨ wScr + 8 ≤ wIns))
    (hregs3 : H3a.wRead m3 scrW wBaseW = baseW ∧ H3a.wRead m3 scrW wBaseR = baseR ∧
      H3a.wRead m3 scrW wOffO = offO ∧ H3a.wRead m3 scrW wUid = (uid : ℤ) ∧
      H3a.wRead m3 scrW wIns = (if insFlag then 1 else 0) ∧
      H3a.wRead m3 scrW wScr = (v₀ : ℤ) ∧ H3a.wRead m3 scrW (wScr + 1) = (v₀ : ℤ) ∧
      H3a.wRead m3 scrW (wScr + 7) = (h : ℤ))
    (hpt : insFlag = true → ∀ c : Fin d, H3a.rRead m3 1 ((h : ℤ) * (d : ℤ) + (c.val : ℤ)) = euclideanCoord pt c)
    (ho : insFlag = true → ∀ c : Fin d, H3a.rRead m3 tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (henc3 : EncEpochRadTree tblW baseW tblR baseR K_seg T m3) :
    let opt : Option (ℕ × ℝ) := if insFlag then some (uid, ‖pt - o‖ ^ 2) else none
    ∃ m4 : ArithRAMMemory,
      DetExec inp (radTreePrepLeafStmt scrW scrR tblO wOffO wUid wIns wScr rScr d) m3 m4 (50 + 50 * d) ∧
      InFootprint TW BW TR BR m4 ∧
      EncEpochRadTree tblW baseW tblR baseR K_seg T m4 ∧
      H3a.wRead m4 scrW wBaseW = baseW ∧ H3a.wRead m4 scrW wBaseR = baseR ∧
      H3a.wRead m4 scrW wUid = (uid : ℤ) ∧
      H3a.wRead m4 scrW wScr = (v₀ : ℤ) ∧ H3a.wRead m4 scrW (wScr + 1) = (v₀ : ℤ) ∧
      (match opt with
       | none => H3a.wRead m4 scrW (wScr + 2) = 0
       | some (u, r) => H3a.wRead m4 scrW (wScr + 2) = 1 ∧ H3a.wRead m4 scrW (wScr + 3) = (u : ℤ) ∧ H3a.rRead m4 scrR rScr = r) ∧
      RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR (radTreeRStride K_seg) m3 m4 := by
  intro opt
  let cIns : ArithCondExpr := .intEq (.readHeap scrW (.lit wIns)) (.lit 1)
  cases insFlag with
  | false =>
      have hc_f : cValAt 0 inp m3 cIns = false := by
        simp only [cValAt, cIns, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m3 scrW wIns = 1) = false; rw [hregs3.2.2.2.2.1]; decide
      let m4 := H3a.wWrite m3 scrW (wScr + 2) 0
      have hd4 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2)) (.lit 0)) m3 m4 10 :=
        DetExecAt.writeWordHeap 0 inp m3 scrW (.lit (wScr + 2)) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfr4 : RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR (radTreeRStride K_seg) m3 m4 :=
        ⟨fun _ _ hs _ => wRead_wWrite_of_ne _ _ (Or.inl hs), fun _ _ _ _ => rfl⟩
      refine ⟨m4, (DetExecAt.ite_false hc_f (C_c := 10)
        (by dsimp [cIns, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd4).mono_cost (by omega),
        InFootprint.wWrite hfp3 hscrW (by omega) (by omega),
        henc3.mono_frame (tblW' := tblW) (baseW' := baseW) (lenW' := 0) (tblR' := tblR) (baseR' := baseR) (lenR' := 0) ⟨fun _ _ hs _ => wRead_wWrite_of_ne _ _ (Or.inl hs), fun _ _ _ _ => rfl⟩ hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega))),
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.1],
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.1],
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.2.2.1],
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.2.2.2.2.1],
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.2.2.2.2.2.1],
        wRead_wWrite_self _ _ _ _, hfr4⟩
  | true =>
      have hc_t : cValAt 0 inp m3 cIns = true := by
        simp only [cValAt, cIns, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m3 scrW wIns = 1) = true; rw [hregs3.2.2.2.2.1]; rfl
      let ma := H3a.wWrite m3 scrW (wScr + 2) 1
      let mb := H3a.wWrite ma scrW (wScr + 3) (uid : ℤ)
      let mc := H3a.rWrite mb scrR rScr 0
      let md := H3a.wWrite mc scrW (wScr + 6) 0
      have hda : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2)) (.lit 1)) m3 ma 10 :=
        DetExecAt.writeWordHeap 0 inp m3 scrW (.lit (wScr + 2)) (.lit 1) rfl rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hdb : DetExec inp (.writeWordHeap scrW (.lit (wScr + 3)) (.readHeap scrW (.lit wUid))) ma mb 10 :=
        DetExecAt.writeWordHeap 0 inp ma scrW (.lit (wScr + 3)) _ rfl
          (by change H3a.wRead ma scrW wUid = _; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.2.2.1])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hdc : DetExec inp (.writeRealHeap scrR (.lit rScr) (.ofInt (.lit 0))) mb mc 10 :=
        DetExecAt.writeRealHeap 0 inp mb scrR (.lit rScr) (.ofInt (.lit 0)) rfl (by simp [rValAt, evalRealExpr, evalIntExpr])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
      have hdd : DetExec inp (.writeWordHeap scrW (.lit (wScr + 6)) (.lit 0)) mc md 10 :=
        DetExecAt.writeWordHeap 0 inp mc scrW (.lit (wScr + 6)) (.lit 0) rfl rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      let pSq : ℕ → ℝ := fun k =>
        ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k), (euclideanCoord pt c - euclideanCoord o c) ^ 2
      let InvD : ℕ → ArithRAMMemory → Prop := fun k m =>
        InFootprint TW BW TR BR m ∧ RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m3 m ∧
        H3a.wRead m scrW wBaseW = baseW ∧ H3a.wRead m scrW wBaseR = baseR ∧
        H3a.wRead m scrW wOffO = offO ∧ H3a.wRead m scrW wUid = (uid : ℤ) ∧
        H3a.wRead m scrW wScr = (v₀ : ℤ) ∧ H3a.wRead m scrW (wScr + 1) = (v₀ : ℤ) ∧
        H3a.wRead m scrW (wScr + 2) = 1 ∧ H3a.wRead m scrW (wScr + 3) = (uid : ℤ) ∧
        H3a.wRead m scrW (wScr + 6) = (k : ℤ) ∧ H3a.wRead m scrW (wScr + 7) = (h : ℤ) ∧
        H3a.rRead m scrR rScr = pSq k
      have hInvD0 : InvD 0 md := by
        refine ⟨InFootprint.wWrite (InFootprint.rWrite (InFootprint.wWrite (InFootprint.wWrite hfp3 hscrW (by omega) (by omega)) hscrW (by omega) (by omega)) hscrR hrScr.1 (by omega)) hscrW (by omega) (by omega),
          ⟨fun _ _ hs _ => by rw [wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs)],
           fun _ _ hs _ => by rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hs)]; rfl⟩,
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.1],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.1],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.2.1],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.2.2.1],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.2.2.2.2.1],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.2.2.2.2.2.1],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self],
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_self],
          wRead_wWrite_self _ _ _ _,
          by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hregs3.2.2.2.2.2.2.2],
          by rw [rRead_wWrite, rRead_rWrite_self]; simp [pSq]⟩
      obtain ⟨m4, hInvDd, hloopD⟩ := DetExecAt.repeatN_nat (fd := 0) (inp := inp)
        (.lit (d : ℤ)) _ d 5 50 InvD hInvD0 rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (fun k hk m ⟨hfpm, hfrm, hbWm, hbRm, hoffm, huidm, hcurm, hnodem, hhasm, huLm, hctrm, hhm, haccm⟩ => by
          let ck : Fin d := ⟨k, hk⟩
          let diff_k := euclideanCoord pt ck - euclideanCoord o ck
          have hpt_k' : H3a.rRead m 1 ((h : ℤ) * (d : ℤ) + (k : ℤ)) = euclideanCoord pt ck := by
            rw [hfrm.2 1 _ hne1 (Or.inr (by omega))]; exact hpt rfl ck
          have ho_k' : H3a.rRead m tblO (offO + (k : ℤ)) = euclideanCoord o ck := by
            rw [hfrm.2 tblO _ hneO (Or.inr (by omega))]; exact ho rfl ck
          let ms1 := H3a.rWrite m scrR (rScr + 1) diff_k
          let ms2 := H3a.rWrite ms1 scrR rScr (pSq (k + 1))
          let ms3 := H3a.wWrite ms2 scrW (wScr + 6) (((k + 1 : ℕ) : ℤ))
          have hsplit : ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k + 1)) =
              Insert.insert ck ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by
            ext c; simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, Fin.ext_iff, ck]; omega
          have hnot : ck ∉ ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by simp [ck]
          have hpSq_s : pSq (k + 1) = pSq k + diff_k ^ 2 := by
            dsimp [pSq, diff_k]; rw [hsplit, Finset.sum_insert hnot, add_comm]
          let st1 : ArithRAMStmt := .writeRealHeap scrR (.lit (rScr + 1))
            (.sub (.readRealHeap 1 (.add (.mul (.readHeap scrW (.lit (wScr + 7))) (.lit (d : ℤ))) (.readHeap scrW (.lit (wScr + 6)))))
                  (.readRealHeap tblO (.add (.readHeap scrW (.lit wOffO)) (.readHeap scrW (.lit (wScr + 6))))))
          let st2 : ArithRAMStmt := .writeRealHeap scrR (.lit rScr)
            (.add (.readRealHeap scrR (.lit rScr)) (.mul (.readRealHeap scrR (.lit (rScr + 1))) (.readRealHeap scrR (.lit (rScr + 1)))))
          let st3 : ArithRAMStmt := .writeWordHeap scrW (.lit (wScr + 6)) (.add (.readHeap scrW (.lit (wScr + 6))) (.lit 1))
          have hds1 : DetExec inp st1 m ms1 25 := by
            refine DetExecAt.writeRealHeap 0 inp m scrR (.lit (rScr + 1)) _ rfl ?_
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
            change H3a.rRead m 1 (H3a.wRead m scrW (wScr + 7) * (d : ℤ) + H3a.wRead m scrW (wScr + 6)) -
              H3a.rRead m tblO (H3a.wRead m scrW wOffO + H3a.wRead m scrW (wScr + 6)) = diff_k
            rw [hhm, hctrm, hoffm, hpt_k', ho_k']
          have hds2 : DetExec inp st2 ms1 ms2 15 := by
            refine DetExecAt.writeRealHeap 0 inp ms1 scrR (.lit rScr) _ rfl ?_
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
            change H3a.rRead ms1 scrR rScr + H3a.rRead ms1 scrR (rScr + 1) * H3a.rRead ms1 scrR (rScr + 1) = pSq (k + 1)
            rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega)), haccm, rRead_rWrite_self, hpSq_s, sq]
          have hds3 : DetExec inp st3 ms2 ms3 10 := by
            refine DetExecAt.writeWordHeap 0 inp ms2 scrW (.lit (wScr + 6)) _ rfl ?_
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            change H3a.wRead ms2 scrW (wScr + 6) + 1 = (((k + 1 : ℕ) : ℤ))
            rw [wRead_rWrite, wRead_rWrite, hctrm]; omega
          have hfp_s1 : InFootprint TW BW TR BR ms1 := InFootprint.rWrite hfpm hscrR (by omega) (by omega)
          have hfp_s2 : InFootprint TW BW TR BR ms2 := InFootprint.rWrite hfp_s1 hscrR hrScr.1 (by omega)
          have hfp_s3 : InFootprint TW BW TR BR ms3 := InFootprint.wWrite hfp_s2 hscrW (by omega) (by omega)
          refine ⟨ms3, DetExecAt.seq hds1 (DetExecAt.seq hds2 hds3),
            hfp_s3,
            ⟨fun t i hs _ => by rw [wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_rWrite, wRead_rWrite]; exact hfrm.1 t i hs (Or.inr (by omega)),
             fun t i hs _ => by rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hs), rRead_rWrite_of_ne _ _ (Or.inl hs)]; exact hfrm.2 t i hs (Or.inr (by omega))⟩,
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hbWm],
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hbRm],
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hoffm],
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, huidm],
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hcurm],
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hnodem],
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hhasm],
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, huLm],
            wRead_wWrite_self _ _ _ _,
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite, hhm],
            by rw [rRead_wWrite, rRead_rWrite_self]⟩)
      obtain ⟨hfp4, hfr4_0, hbW4, hbR4, _, huid4, hcur4, hnode4, hhas4, huL4, _, _, hacc4⟩ := hInvDd
      have hnorm_eq : pSq d = ‖pt - o‖ ^ 2 := by
        rw [norm_sub_sq_eq_sum_coord]
        dsimp [pSq]; refine Finset.sum_congr (by ext c; simp) (fun _ _ => rfl)
      have hfr4 : RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR (radTreeRStride K_seg) m3 m4 :=
        ⟨fun t i hs _ => hfr4_0.1 t i hs (Or.inr (by omega)),
         fun t i hs _ => hfr4_0.2 t i hs (Or.inr (by omega))⟩
      refine ⟨m4, (DetExecAt.ite_true hc_t (C_c := 5)
        (by dsimp [cIns, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.seq hda (DetExecAt.seq hdb (DetExecAt.seq hdc (DetExecAt.seq hdd hloopD))))).mono_cost (by omega),
        hfp4, henc3.mono_frame hfr4_0 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega))),
        hbW4, hbR4, huid4, hcur4, hnode4, ⟨hhas4, huL4, hacc4.trans hnorm_eq⟩, hfr4⟩

/-- Pull one parent step `p := wCur / 2` along the update path. -/
def radTreePullStepStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wScr rScr : ℤ) : ArithRAMStmt :=
  let wCur := wScr
  let wNode := wScr + 1
  let wHasL := wScr + 2
  let wUidL := wScr + 3
  let wHasR := wScr + 4
  let wUidR := wScr + 5
  let rSqL := rScr
  let rSqR := rScr + 1
  .seq (.writeWordHeap scrW (.lit wCur) (.div (.readHeap scrW (.lit wCur)) (.lit 2)))
  (.seq (.writeWordHeap scrW (.lit wNode) (.mul (.lit 2) (.readHeap scrW (.lit wCur))))
  (.seq (radTreeReadNodeStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHasL wUidL rSqL)
  (.seq (.writeWordHeap scrW (.lit wNode) (.add (.mul (.lit 2) (.readHeap scrW (.lit wCur))) (.lit 1)))
  (.seq (radTreeReadNodeStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHasR wUidR rSqR)
  (.seq (combineRadRegsStmt scrW scrR wHasL wUidL rSqL wHasR wUidR rSqR)
  (.seq (.writeWordHeap scrW (.lit wNode) (.readHeap scrW (.lit wCur)))
        (radTreeWriteNodeStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHasL wUidL rSqL)))))))

private lemma exec_radTreePullStepStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m : ArithRAMMemory}
    (wBaseW wBaseR wUid wScr rScr baseW baseR : ℤ)
    {K_seg uid cur : ℕ} (hcur_lt : cur < 2 * 2 ^ K_seg) (T : EpochRadTree)
    (hfpm : InFootprint TW BW TR BR m)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ baseW ∧ baseW + radTreeWStride K_seg ≤ (BW : ℤ))
    (hbaseR : 0 ≤ baseR ∧ baseR + radTreeRStride K_seg ≤ (BR : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 8 ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + 2 ≤ (BR : ℤ))
    (hregs : (wBaseW < wScr ∨ wScr + 8 ≤ wBaseW) ∧
             (wBaseR < wScr ∨ wScr + 8 ≤ wBaseR) ∧
             (wUid < wScr ∨ wScr + 8 ≤ wUid))
    (hbWm : H3a.wRead m scrW wBaseW = baseW)
    (hbRm : H3a.wRead m scrW wBaseR = baseR)
    (huidm : H3a.wRead m scrW wUid = (uid : ℤ))
    (hcurm : H3a.wRead m scrW wScr = (cur : ℤ))
    (hencm : EncEpochRadTree tblW baseW tblR baseR K_seg T m) :
    let p := cur / 2
    ∃ mh : ArithRAMMemory,
      DetExec inp (radTreePullStepStmt scrW scrR tblW tblR wBaseW wBaseR wScr rScr) m mh 375 ∧
      InFootprint TW BW TR BR mh ∧
      EncEpochRadTree tblW baseW tblR baseR K_seg (T.pullParent p) mh ∧
      H3a.wRead mh scrW wBaseW = baseW ∧
      H3a.wRead mh scrW wBaseR = baseR ∧
      H3a.wRead mh scrW wUid = (uid : ℤ) ∧
      H3a.wRead mh scrW wScr = (p : ℤ) ∧
      RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR (radTreeRStride K_seg) m mh := by
  intro p
  have hp_hi : p < 2 ^ K_seg := by dsimp [p]; omega
  have h2p_lt : 2 * p < 2 * 2 ^ K_seg := by omega
  have h2p1_lt : 2 * p + 1 < 2 * 2 ^ K_seg := by omega
  have hp_lt : p < 2 * 2 ^ K_seg := by omega
  let ma := H3a.wWrite m scrW wScr (p : ℤ)
  let mb := H3a.wWrite ma scrW (wScr + 1) (((2 * p : ℕ) : ℤ))
  have hda : DetExec inp (.writeWordHeap scrW (.lit wScr) (.div (.readHeap scrW (.lit wScr)) (.lit 2))) m ma 15 :=
    DetExecAt.writeWordHeap 0 inp m scrW (.lit wScr) _ rfl
      (by change H3a.wRead m scrW wScr / 2 = (p : ℤ); rw [hcurm]; exact (Int.natCast_div cur 2).symm)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hdb : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1)) (.mul (.lit 2) (.readHeap scrW (.lit wScr)))) ma mb 15 :=
    DetExecAt.writeWordHeap 0 inp ma scrW (.lit (wScr + 1)) _ rfl
      (by change 2 * H3a.wRead ma scrW wScr = (((2 * p : ℕ) : ℤ)); rw [wRead_wWrite_self]; push_cast; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_a : InFootprint TW BW TR BR ma := InFootprint.wWrite hfpm hscrW hwScr.1 (by omega)
  have hfp_b : InFootprint TW BW TR BR mb := InFootprint.wWrite hfp_a hscrW (by omega) (by omega)
  have henc_b : EncEpochRadTree tblW baseW tblR baseR K_seg T mb :=
    hencm.mono_frame (scrW := scrW) (scrR := scrR) (tblW' := tblW) (baseW' := baseW) (lenW' := 0)
      (tblR' := tblR) (baseR' := baseR) (lenR' := 0)
      ⟨fun _ _ hs _ => by rw [wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs)],
       fun _ _ _ _ => rfl⟩ hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  obtain ⟨mc, hdL, hfp_c, hL_c, hw_c, _, hfr_c⟩ :=
    exec_radTreeReadNodeStmt inp wBaseW wBaseR (wScr + 1) (wScr + 2) (wScr + 3) rScr baseW baseR
      h2p_lt T hfp_b hscrW hscrR hneW hneR
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨hrScr.1, by omega⟩
      (by omega) (fun _ _ _ => trivial) ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbWm])
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbRm])
      (wRead_wWrite_self _ _ _ _) henc_b
  have hcur_c : H3a.wRead mc scrW wScr = (p : ℤ) := by
    rw [hw_c wScr (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  let md := H3a.wWrite mc scrW (wScr + 1) (((2 * p + 1 : ℕ) : ℤ))
  have hdd : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1)) (.add (.mul (.lit 2) (.readHeap scrW (.lit wScr))) (.lit 1))) mc md 15 :=
    DetExecAt.writeWordHeap 0 inp mc scrW (.lit (wScr + 1)) _ rfl
      (by change 2 * H3a.wRead mc scrW wScr + 1 = (((2 * p + 1 : ℕ) : ℤ)); rw [hcur_c]; push_cast; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_d : InFootprint TW BW TR BR md := InFootprint.wWrite hfp_c hscrW (by omega) (by omega)
  have henc_d : EncEpochRadTree tblW baseW tblR baseR K_seg T md :=
    (henc_b.mono_frame hfr_c hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))).mono_frame
      (scrW := scrW) (scrR := scrR) (tblW' := tblW) (baseW' := baseW) (lenW' := 0)
      (tblR' := tblR) (baseR' := baseR) (lenR' := 0)
      ⟨fun _ _ hs _ => wRead_wWrite_of_ne _ _ (Or.inl hs), fun _ _ _ _ => rfl⟩
      hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  obtain ⟨me, hdR, hfp_e1, hR_e, hw_e, hr_e, hfr_e1⟩ :=
    exec_radTreeReadNodeStmt inp wBaseW wBaseR (wScr + 1) (wScr + 4) (wScr + 5) (rScr + 1) baseW baseR
      h2p1_lt T hfp_d hscrW hscrR hneW hneR
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by omega) (fun _ _ _ => trivial) ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw_c wBaseW (by omega) (by omega),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbWm])
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw_c wBaseR (by omega) (by omega),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbRm])
      (wRead_wWrite_self _ _ _ _) henc_d
  have hL_me : match T.effVal (2 * p) with
      | none => H3a.wRead me scrW (wScr + 2) = 0
      | some (u, r) => H3a.wRead me scrW (wScr + 2) = 1 ∧ H3a.wRead me scrW (wScr + 3) = (u : ℤ) ∧ H3a.rRead me scrR rScr = r := by
    cases hvalL : T.effVal (2 * p) with
    | none => rw [hvalL] at hL_c; rw [hw_e (wScr + 2) (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hL_c.1]
    | some lr =>
        rcases lr with ⟨uL, dL⟩; rw [hvalL] at hL_c
        exact ⟨by rw [hw_e (wScr + 2) (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hL_c.1],
               by rw [hw_e (wScr + 3) (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hL_c.2.1],
               by rw [hr_e rScr (by omega)]; exact hL_c.2.2⟩
  have hR_me : match T.effVal (2 * p + 1) with
      | none => H3a.wRead me scrW (wScr + 4) = 0
      | some (u, r) => H3a.wRead me scrW (wScr + 4) = 1 ∧ H3a.wRead me scrW (wScr + 5) = (u : ℤ) ∧ H3a.rRead me scrR (rScr + 1) = r := by
    cases hvalR : T.effVal (2 * p + 1) with
    | none => rw [hvalR] at hR_e; exact hR_e.1
    | some rr => rcases rr with ⟨uR, dR⟩; rw [hvalR] at hR_e; exact hR_e
  obtain ⟨mf, hdComb, hfp_f, hComb_f, hw_f, _, hfr_f⟩ :=
    exec_combineRadRegsStmt (tblW := tblW) (tblR := tblR) inp
      (wScr + 2) (wScr + 3) rScr (wScr + 4) (wScr + 5) (rScr + 1) baseW baseR
      (T.effVal (2 * p)) (T.effVal (2 * p + 1)) hfp_e1 hscrW hscrR
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨hrScr.1, by omega⟩
      ⟨by omega, by omega, by omega, by omega, by omega⟩ (by omega) hL_me hR_me
  have hcur_f : H3a.wRead mf scrW wScr = (p : ℤ) := by
    rw [hw_f wScr (by omega) (by omega), hw_e wScr (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hcur_c]
  let mg := H3a.wWrite mf scrW (wScr + 1) (p : ℤ)
  have hdg : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1)) (.readHeap scrW (.lit wScr))) mf mg 10 :=
    DetExecAt.writeWordHeap 0 inp mf scrW (.lit (wScr + 1)) _ rfl hcur_f
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_g : InFootprint TW BW TR BR mg := InFootprint.wWrite hfp_f hscrW (by omega) (by omega)
  have henc_g : EncEpochRadTree tblW baseW tblR baseR K_seg T mg :=
    ((henc_d.mono_frame hfr_e1 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))).mono_frame
      hfr_f hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))).mono_frame
      (scrW := scrW) (scrR := scrR) (tblW' := tblW) (baseW' := baseW) (lenW' := 0)
      (tblR' := tblR) (baseR' := baseR) (lenR' := 0)
      ⟨fun _ _ hs _ => wRead_wWrite_of_ne _ _ (Or.inl hs), fun _ _ _ _ => rfl⟩
      hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  have hComb_g : match combineRadOpt (T.effVal (2 * p)) (T.effVal (2 * p + 1)) with
      | none => H3a.wRead mg scrW (wScr + 2) = 0
      | some (u, r) => H3a.wRead mg scrW (wScr + 2) = 1 ∧ H3a.wRead mg scrW (wScr + 3) = (u : ℤ) ∧ H3a.rRead mg scrR rScr = r := by
    cases hvalC : combineRadOpt (T.effVal (2 * p)) (T.effVal (2 * p + 1)) with
    | none => rw [hvalC] at hComb_f; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hComb_f]
    | some cr =>
        rcases cr with ⟨uC, dC⟩; rw [hvalC] at hComb_f
        exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hComb_f.1],
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hComb_f.2.1], hComb_f.2.2⟩
  have hbW_g : H3a.wRead mg scrW wBaseW = baseW := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw_f wBaseW (by omega) (by omega),
        hw_e wBaseW (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        hw_c wBaseW (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbWm]
  have hbR_g : H3a.wRead mg scrW wBaseR = baseR := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw_f wBaseR (by omega) (by omega),
        hw_e wBaseR (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        hw_c wBaseR (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbRm]
  have huid_g : H3a.wRead mg scrW wUid = (uid : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw_f wUid (by omega) (by omega),
        hw_e wUid (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        hw_c wUid (by omega) (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), huidm]
  obtain ⟨mh, hdW, hfp_h, henc_h, hw_h, _, hfr_h⟩ :=
    exec_radTreeWriteNodeStmt inp wBaseW wBaseR (wScr + 1) (wScr + 2) (wScr + 3) rScr baseW baseR
      hp_lt T _ hfp_g htblW htblR hneW hneR hbaseW hbaseR hbW_g hbR_g
      (wRead_wWrite_self _ _ _ _) hComb_g henc_g
  have hfr_mg : RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR (radTreeRStride K_seg) m mg :=
    ⟨fun t' i hs _ => by
      rw [wRead_wWrite_of_ne _ _ (Or.inl hs), hfr_f.1 t' i hs (Or.inr (by omega)),
          hfr_e1.1 t' i hs (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inl hs),
          hfr_c.1 t' i hs (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs)],
     fun t' i hs _ => by
      rw [rRead_wWrite, hfr_f.2 t' i hs (Or.inr (by omega)),
          hfr_e1.2 t' i hs (Or.inr (by omega)), rRead_wWrite, hfr_c.2 t' i hs (Or.inr (by omega)),
          rRead_wWrite, rRead_wWrite]⟩
  exact ⟨mh,
    (DetExecAt.seq hda (DetExecAt.seq hdb (DetExecAt.seq hdL (DetExecAt.seq hdd
      (DetExecAt.seq hdR (DetExecAt.seq hdComb (DetExecAt.seq hdg hdW))))))).mono_cost (by omega),
    hfp_h, henc_h, (hw_h wBaseW).trans hbW_g, (hw_h wBaseR).trans hbR_g, (hw_h wUid).trans huid_g,
    (hw_h wScr).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hcur_f),
    hfr_mg.trans hfr_h⟩

/-- Update leaf `h = uid % n` and pull `K_seg` ancestors up to root `1`. -/
def radTreeUpdateLeafStmt (scrW scrR tblW tblR tblO : ℕ)
    (wBaseW wBaseR wOffO wUid wIns wScr rScr : ℤ) (K_seg n d : ℕ) : ArithRAMStmt :=
  let wCur := wScr
  let wNode := wScr + 1
  let wHasL := wScr + 2
  let wUidL := wScr + 3
  let wH := wScr + 7
  let rSqL := rScr
  .seq (.writeWordHeap scrW (.lit wH) (.mod (.readHeap scrW (.lit wUid)) (.lit (n : ℤ))))
  (.seq (.writeWordHeap scrW (.lit wCur) (.add (.lit (((2 ^ K_seg : ℕ) : ℤ))) (.readHeap scrW (.lit wH))))
  (.seq (.writeWordHeap scrW (.lit wNode) (.readHeap scrW (.lit wCur)))
  (.seq (radTreePrepLeafStmt scrW scrR tblO wOffO wUid wIns wScr rScr d)
  (.seq (radTreeWriteNodeStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHasL wUidL rSqL)
        (.repeatN (.lit (K_seg : ℤ))
          (radTreePullStepStmt scrW scrR tblW tblR wBaseW wBaseR wScr rScr))))))

theorem exec_radTreeUpdateLeafStmt {d TW BW TR BR scrW scrR tblW tblR tblO : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBaseR wOffO wUid wIns wScr rScr baseW baseR offO : ℤ)
    {K_seg n : ℕ} (hn : 1 ≤ n) (hn_le : n ≤ 2 ^ K_seg)
    (uid : ℕ) (insFlag : Bool)
    (pt o : EuclideanSpace ℝ (Fin d)) (T : EpochRadTree)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hne1 : 1 ≠ scrR) (hneO : tblO ≠ scrR)
    (hbaseW : 0 ≤ baseW ∧ baseW + radTreeWStride K_seg ≤ (BW : ℤ))
    (hbaseR : 0 ≤ baseR ∧ baseR + radTreeRStride K_seg ≤ (BR : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 8 ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + 2 ≤ (BR : ℤ))
    (hregs : (wBaseW < wScr ∨ wScr + 8 ≤ wBaseW) ∧
             (wBaseR < wScr ∨ wScr + 8 ≤ wBaseR) ∧
             (wOffO < wScr ∨ wScr + 8 ≤ wOffO) ∧
             (wUid < wScr ∨ wScr + 8 ≤ wUid) ∧
             (wIns < wScr ∨ wScr + 8 ≤ wIns))
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hbR : H3a.wRead m₀ scrW wBaseR = baseR)
    (hoffO_r : H3a.wRead m₀ scrW wOffO = offO)
    (huid_r : H3a.wRead m₀ scrW wUid = (uid : ℤ))
    (hins_r : H3a.wRead m₀ scrW wIns = (if insFlag then 1 else 0))
    (hpt : insFlag = true → ∀ c : Fin d, H3a.rRead m₀ 1 (((uid % n : ℕ) : ℤ) * (d : ℤ) + (c.val : ℤ)) = euclideanCoord pt c)
    (ho : insFlag = true → ∀ c : Fin d, H3a.rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (henc : EncEpochRadTree tblW baseW tblR baseR K_seg T m₀) :
    let opt : Option (ℕ × ℝ) := if insFlag then some (uid, ‖pt - o‖ ^ 2) else none
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (radTreeUpdateLeafStmt scrW scrR tblW tblR tblO wBaseW wBaseR wOffO wUid wIns wScr rScr K_seg n d)
        m₀ m₁ (200 + 50 * d + 380 * K_seg) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncEpochRadTree tblW baseW tblR baseR K_seg (T.updateLeaf K_seg (uid % n) opt) m₁ ∧
      H3a.wRead m₁ scrW wUid = (uid : ℤ) ∧
      RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR (radTreeRStride K_seg) m₀ m₁ := by
  intro opt
  let h := uid % n
  have hh_lt : h < n := Nat.mod_lt uid hn
  have hh_2K : h < 2 ^ K_seg := lt_of_lt_of_le hh_lt hn_le
  let v₀ := 2 ^ K_seg + h
  have hv₀_lt : v₀ < 2 * 2 ^ K_seg := by dsimp [v₀]; omega
  let m1 := H3a.wWrite m₀ scrW (wScr + 7) (h : ℤ)
  let m2 := H3a.wWrite m1 scrW wScr (v₀ : ℤ)
  let m3 := H3a.wWrite m2 scrW (wScr + 1) (v₀ : ℤ)
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 7)) (.mod (.readHeap scrW (.lit wUid)) (.lit (n : ℤ)))) m₀ m1 15 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wScr + 7)) _ rfl
      (by change H3a.wRead m₀ scrW wUid % (n : ℤ) = (h : ℤ); rw [huid_r]; exact Int.natCast_emod uid n)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.add (.lit (((2 ^ K_seg : ℕ) : ℤ))) (.readHeap scrW (.lit (wScr + 7))))) m1 m2 15 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wScr) _ rfl
      (by change ((2 ^ K_seg : ℕ) : ℤ) + H3a.wRead m1 scrW (wScr + 7) = (v₀ : ℤ); rw [wRead_wWrite_self]; push_cast; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1)) (.readHeap scrW (.lit wScr))) m2 m3 10 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wScr + 1)) _ rfl (wRead_wWrite_self _ _ _ _)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)
  have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 hscrW hwScr.1 (by omega)
  have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 hscrW (by omega) (by omega)
  have hfr3 : RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR (radTreeRStride K_seg) m₀ m3 :=
    ⟨fun _ _ hs _ => by rw [wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs)],
     fun _ _ _ _ => rfl⟩
  have henc3 : EncEpochRadTree tblW baseW tblR baseR K_seg T m3 :=
    henc.mono_frame (scrW := scrW) (scrR := scrR) (tblW' := tblW) (baseW' := baseW) (lenW' := 0) (tblR' := tblR) (baseR' := baseR) (lenR' := 0) ⟨fun _ _ hs _ => by rw [wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs), wRead_wWrite_of_ne _ _ (Or.inl hs)], fun _ _ _ _ => rfl⟩ hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  have hregs3 : H3a.wRead m3 scrW wBaseW = baseW ∧ H3a.wRead m3 scrW wBaseR = baseR ∧
      H3a.wRead m3 scrW wOffO = offO ∧ H3a.wRead m3 scrW wUid = (uid : ℤ) ∧
      H3a.wRead m3 scrW wIns = (if insFlag then 1 else 0) ∧
      H3a.wRead m3 scrW wScr = (v₀ : ℤ) ∧ H3a.wRead m3 scrW (wScr + 1) = (v₀ : ℤ) ∧
      H3a.wRead m3 scrW (wScr + 7) = (h : ℤ) :=
    ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbW],
     by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR],
     by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hoffO_r],
     by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), huid_r],
     by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hins_r],
     by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self],
     wRead_wWrite_self _ _ _ _,
     by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]⟩
  obtain ⟨m4, hd_prep, hfp4, henc4, hbW4, hbR4, huid4, hcur4, hnode4, hopt4, hfr4⟩ :=
    exec_radTreePrepLeafStmt inp wBaseW wBaseR wOffO wUid wIns wScr rScr baseW baseR offO
      K_seg uid h v₀ insFlag pt o T hfp3 hscrW hscrR hneW hneR hne1 hneO hwScr hrScr hregs hregs3 hpt ho henc3
  obtain ⟨m5, hd_w0, hfp5, henc5, hw_scr5, _, hfr5⟩ :=
    exec_radTreeWriteNodeStmt inp wBaseW wBaseR (wScr + 1) (wScr + 2) (wScr + 3) rScr baseW baseR
      hv₀_lt T opt hfp4 htblW htblR hneW hneR hbaseW hbaseR hbW4 hbR4 hnode4 hopt4 henc4
  let InvK : ℕ → ArithRAMMemory → Prop := fun t m =>
    let ct := (EpochRadTree.updatePathStep)^[t] (v₀, T.writeNode v₀ opt)
    ct.1 = v₀ / (2 ^ t) ∧ InFootprint TW BW TR BR m ∧ EncEpochRadTree tblW baseW tblR baseR K_seg ct.2 m ∧
    H3a.wRead m scrW wBaseW = baseW ∧ H3a.wRead m scrW wBaseR = baseR ∧
    H3a.wRead m scrW wUid = (uid : ℤ) ∧ H3a.wRead m scrW wScr = (ct.1 : ℤ) ∧
    RadFrameOutside scrW scrR tblW baseW (radTreeWStride K_seg) tblR baseR (radTreeRStride K_seg) m5 m
  have hInvK0 : InvK 0 m5 :=
    ⟨by simp, hfp5, henc5, (hw_scr5 wBaseW).trans hbW4, (hw_scr5 wBaseR).trans hbR4,
     (hw_scr5 wUid).trans huid4, (hw_scr5 wScr).trans hcur4, RadFrameOutside.refl _ _ _ _ _ _ _ _ _⟩
  obtain ⟨m_end, ⟨_, hfp_e, henc_e, _, _, huid_e, _, hfr_e⟩, hloopK⟩ :=
    DetExecAt.repeatN_nat (fd := 0) (inp := inp) (.lit (K_seg : ℤ)) _ K_seg 5 375 InvK hInvK0 rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      (fun t _ m ⟨hct1, hfpm, hencm, hbWm, hbRm, huidm, hcurm, hfrm⟩ => by
        set ct := (EpochRadTree.updatePathStep)^[t] (v₀, T.writeNode v₀ opt)
        have hcur_lt : ct.1 < 2 * 2 ^ K_seg := by
          rw [hct1]; exact lt_of_le_of_lt (Nat.div_le_self _ _) hv₀_lt
        obtain ⟨mh, hd_st, hfp_h, henc_h, hbW_h, hbR_h, huid_h, hcur_h, hfr_h⟩ :=
          exec_radTreePullStepStmt inp wBaseW wBaseR wUid wScr rScr baseW baseR hcur_lt ct.2
            hfpm hscrW hscrR htblW htblR hneW hneR hbaseW hbaseR hwScr hrScr
            ⟨hregs.1, hregs.2.1, hregs.2.2.2.1⟩ hbWm hbRm huidm hcurm hencm
        have hstep_it : (EpochRadTree.updatePathStep)^[t + 1] (v₀, T.writeNode v₀ opt) =
            (ct.1 / 2, ct.2.pullParent (ct.1 / 2)) := by
          rw [Function.iterate_succ_apply']; rfl
        have hp_eq : ct.1 / 2 = v₀ / 2 ^ (t + 1) := by rw [hct1, Nat.div_div_eq_div_mul, ← pow_succ]
        refine ⟨mh, hd_st, ?_⟩
        dsimp only [InvK]; rw [hstep_it]
        exact ⟨hp_eq, hfp_h, henc_h, hbW_h, hbR_h, huid_h, hcur_h, hfrm.trans hfr_h⟩)
  exact ⟨m_end,
    (DetExecAt.seq hd1 (DetExecAt.seq hd2 (DetExecAt.seq hd3
      (DetExecAt.seq hd_prep (DetExecAt.seq hd_w0 hloopK))))).mono_cost (by omega),
    hfp_e, henc_e, huid_e, ((hfr3.trans hfr4).trans hfr5).trans hfr_e⟩

/-- `O(1)` root query wrapper writing `1` to `wNode` and reading root `1` of `EpochRadTree`. -/
def radTreeQueryRootStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wNode wHas wUid rSq : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit wNode) (.lit 1))
       (radTreeReadNodeStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHas wUid rSq)

theorem exec_radTreeQueryRootStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBaseR wNode wHas wUid rSq baseW baseR : ℤ)
    (K_seg : ℕ) (T : EpochRadTree)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hwNode : 0 ≤ wNode ∧ wNode < (BW : ℤ))
    (hwHas : 0 ≤ wHas ∧ wHas < (BW : ℤ))
    (hwUid : 0 ≤ wUid ∧ wUid < (BW : ℤ))
    (hrSq : 0 ≤ rSq ∧ rSq < (BR : ℤ))
    (hneHasUid : wHas ≠ wUid)
    (hneNode : wNode ≠ wHas ∧ wNode ≠ wUid ∧ wNode ≠ wBaseW ∧ wNode ≠ wBaseR)
    (hneBW : wBaseW ≠ wHas ∧ wBaseW ≠ wUid)
    (hneBR : wBaseR ≠ wHas ∧ wBaseR ≠ wUid)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hbR : H3a.wRead m₀ scrW wBaseR = baseR)
    (henc : EncEpochRadTree tblW baseW tblR baseR K_seg T m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (radTreeQueryRootStmt scrW scrR tblW tblR wBaseW wBaseR wNode wHas wUid rSq) m₀ m₁ 95 ∧
      InFootprint TW BW TR BR m₁ ∧
      (match T.effVal 1 with
       | none => H3a.wRead m₁ scrW wHas = 0 ∧ H3a.wRead m₁ scrW wUid = 0 ∧ H3a.rRead m₁ scrR rSq = 0
       | some (u, r) => H3a.wRead m₁ scrW wHas = 1 ∧ H3a.wRead m₁ scrW wUid = (u : ℤ) ∧ H3a.rRead m₁ scrR rSq = r) ∧
      (∀ w, w ≠ wNode → w ≠ wHas → w ≠ wUid → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, r ≠ rSq → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  have h1_lt : 1 < 2 * 2 ^ K_seg := by have := Nat.one_le_two_pow (n := K_seg); omega
  let ma := H3a.wWrite m₀ scrW wNode 1
  have hda : DetExec inp (.writeWordHeap scrW (.lit wNode) (.lit 1)) m₀ ma 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wNode) (.lit 1) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfpa : InFootprint TW BW TR BR ma := InFootprint.wWrite hfp₀ hscrW hwNode.1 hwNode.2
  have hfra : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ ma :=
    ⟨fun _ _ hs _ => wRead_wWrite_of_ne _ _ (Or.inl hs), fun _ _ _ _ => rfl⟩
  have henca := henc.mono_frame hfra hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  obtain ⟨m₁, hdb, hfp₁, hres, hw₁, hr₁, hfrb⟩ :=
    exec_radTreeReadNodeStmt inp wBaseW wBaseR wNode wHas wUid rSq baseW baseR h1_lt T
      hfpa hscrW hscrR hneW hneR hwHas hwUid hrSq hneHasUid (fun _ _ _ => trivial)
      ⟨hneNode.1, hneNode.2.1⟩ hneBW hneBR
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr hneNode.2.2.1.symm), hbW])
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr hneNode.2.2.2.symm), hbR])
      (wRead_wWrite_self _ _ _ _) henca
  refine ⟨m₁, (DetExecAt.seq hda hdb).mono_cost (by omega), hfp₁, hres, ?_, hr₁, hfra.trans hfrb⟩
  intro w hwn hwh hwu
  rw [hw₁ w hwh hwu, wRead_wWrite_of_ne _ _ (Or.inr hwn)]

/-! ### 4. `ArithRAM` Heap Encoding & Subroutines for `DualPool` -/

def dualPoolStride (n : ℕ) : ℤ := 2 + 2 * swapPoolStride n

def EncDualPool (tbl : ℕ) (base : ℤ) (n : ℕ) (D : DualPool) (m : ArithRAMMemory) : Prop :=
  EncSwapPool tbl base n D.live m ∧
  EncSwapPool tbl (base + swapPoolStride n) n D.snap m ∧
  H3a.wRead m tbl (base + 2 * swapPoolStride n) = (if D.frozen then 1 else 0)

theorem EncDualPool.mono_frame {scrW tbl' tbl : ℕ} {base' len' base : ℤ} {n : ℕ}
    {D : DualPool} {m₀ m₁ : ArithRAMMemory}
    (henc : EncDualPool tbl base n D m₀)
    (hfr : WordFrameOutside scrW tbl' base' len' m₀ m₁)
    (hne_scr : tbl ≠ scrW)
    (hdisj : tbl ≠ tbl' ∨ base + dualPoolStride n ≤ base' ∨ base' + len' ≤ base)
    (hl_le : D.live.sz ≤ n) (hs_le : D.snap.sz ≤ n) :
    EncDualPool tbl base n D m₁ := by
  have hsp_pos : 0 < swapPoolStride n := by dsimp [swapPoolStride]; omega
  refine ⟨henc.1.mono_frame hfr hne_scr ?_ hl_le,
    henc.2.1.mono_frame hfr hne_scr ?_ hs_le, ?_⟩
  · rcases hdisj with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by dsimp [dualPoolStride] at h1; omega))
    · exact Or.inr (Or.inr h2)
  · rcases hdisj with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by dsimp [dualPoolStride] at h1; omega))
    · exact Or.inr (Or.inr (by omega))
  · refine (hfr.1 tbl (base + 2 * swapPoolStride n) hne_scr ?_).trans henc.2.2
    rcases hdisj with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by dsimp [dualPoolStride] at h1; omega))
    · exact Or.inr (Or.inr (by omega))

def dualPoolClearStmt (scrW tbl : ℕ) (wBase wNewEp : ℤ) (n : ℕ) : ArithRAMStmt :=
  let bE := IntExpr.readHeap scrW (.lit wBase)
  let epE := IntExpr.readHeap scrW (.lit wNewEp)
  let S := swapPoolStride n
  .seq (.writeWordHeap tbl bE epE)
  (.seq (.writeWordHeap tbl (.add bE (.lit 1)) (.lit 0))
  (.seq (.writeWordHeap tbl (.add bE (.lit S)) epE)
  (.seq (.writeWordHeap tbl (.add bE (.lit (S + 1))) (.lit 0))
        (.writeWordHeap tbl (.add bE (.lit (2 * S))) (.lit 0)))))

theorem exec_dualPoolClearStmt {d TW BW TR BR scrW tbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBase wNewEp base : ℤ) (n newEp : ℕ) (D : DualPool)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : tbl < TW) (hne_scr : tbl ≠ scrW)
    (hbase : 0 ≤ base ∧ base + dualPoolStride n ≤ (BW : ℤ))
    (hb_r : H3a.wRead m₀ scrW wBase = base)
    (hep_r : H3a.wRead m₀ scrW wNewEp = (newEp : ℤ))
    (henc : EncDualPool tbl base n D m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (dualPoolClearStmt scrW tbl wBase wNewEp n) m₀ m₁ 90 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncDualPool tbl base n (D.clear newEp) m₁ ∧
      (∀ w, H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      WordFrameOutside scrW tbl base (dualPoolStride n) m₀ m₁ := by
  let S := swapPoolStride n
  have hS : 4 ≤ S := by dsimp [S, swapPoolStride]; omega
  have hD : dualPoolStride n = 2 + 2 * S := rfl
  let m1 := H3a.wWrite m₀ tbl base (newEp : ℤ)
  let m2 := H3a.wWrite m1 tbl (base + 1) 0
  let m3 := H3a.wWrite m2 tbl (base + S) (newEp : ℤ)
  let m4 := H3a.wWrite m3 tbl (base + (S + 1)) 0
  let m5 := H3a.wWrite m4 tbl (base + 2 * S) 0
  have hs1 : ∀ w, H3a.wRead m1 scrW w = H3a.wRead m₀ scrW w := fun _ => wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)
  have hs2 : ∀ w, H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w := fun w => (wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)).trans (hs1 w)
  have hs3 : ∀ w, H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w := fun w => (wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)).trans (hs2 w)
  have hs4 : ∀ w, H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w := fun w => (wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)).trans (hs3 w)
  have hs5 : ∀ w, H3a.wRead m5 scrW w = H3a.wRead m₀ scrW w := fun w => (wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)).trans (hs4 w)
  have hd1 : DetExec inp (.writeWordHeap tbl (.readHeap scrW (.lit wBase)) (.readHeap scrW (.lit wNewEp))) m₀ m1 15 :=
    DetExecAt.writeWordHeap 0 inp m₀ tbl _ _ hb_r hep_r (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap tbl (.add (.readHeap scrW (.lit wBase)) (.lit 1)) (.lit 0)) m1 m2 15 :=
    DetExecAt.writeWordHeap 0 inp m1 tbl _ _ (by change H3a.wRead m1 scrW wBase + 1 = _; rw [hs1, hb_r]) rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap tbl (.add (.readHeap scrW (.lit wBase)) (.lit S)) (.readHeap scrW (.lit wNewEp))) m2 m3 15 :=
    DetExecAt.writeWordHeap 0 inp m2 tbl _ _ (by change H3a.wRead m2 scrW wBase + S = _; rw [hs2, hb_r])
      (by change H3a.wRead m2 scrW wNewEp = _; rw [hs2, hep_r]) (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd4 : DetExec inp (.writeWordHeap tbl (.add (.readHeap scrW (.lit wBase)) (.lit (S + 1))) (.lit 0)) m3 m4 15 :=
    DetExecAt.writeWordHeap 0 inp m3 tbl _ _ (by change H3a.wRead m3 scrW wBase + (S + 1) = _; rw [hs3, hb_r]) rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd5 : DetExec inp (.writeWordHeap tbl (.add (.readHeap scrW (.lit wBase)) (.lit (2 * S))) (.lit 0)) m4 m5 15 :=
    DetExecAt.writeWordHeap 0 inp m4 tbl _ _ (by change H3a.wRead m4 scrW wBase + 2 * S = _; rw [hs4, hb_r]) rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ htbl hbase.1 (by omega)
  have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 htbl (by omega) (by omega)
  have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 htbl (by omega) (by omega)
  have hfp4 : InFootprint TW BW TR BR m4 := InFootprint.wWrite hfp3 htbl (by omega) (by omega)
  have hfp5 : InFootprint TW BW TR BR m5 := InFootprint.wWrite hfp4 htbl (by omega) (by omega)
  have hfr5 : WordFrameOutside scrW tbl base (dualPoolStride n) m₀ m5 :=
    ((((WordFrameOutside.wWrite_in scrW tbl base (dualPoolStride n) m₀ (idx := base) le_rfl (by omega) _).trans
    (WordFrameOutside.wWrite_in scrW tbl base (dualPoolStride n) m1 (idx := base + 1) (by omega) (by omega) _)).trans
    (WordFrameOutside.wWrite_in scrW tbl base (dualPoolStride n) m2 (idx := base + S) (by omega) (by omega) _)).trans
    (WordFrameOutside.wWrite_in scrW tbl base (dualPoolStride n) m3 (idx := base + (S + 1)) (by omega) (by omega) _)).trans
    (WordFrameOutside.wWrite_in scrW tbl base (dualPoolStride n) m4 (idx := base + 2 * S) (by omega) (by omega) _)
  refine ⟨m5, (DetExecAt.seq hd1 (DetExecAt.seq hd2 (DetExecAt.seq hd3 (DetExecAt.seq hd4 hd5)))).mono_cost (by omega),
    hfp5, ?_, hs5, hfr5⟩
  unfold EncDualPool EncSwapPool; dsimp only [DualPool.clear, SwapPool.clear, Bool.false_eq_true, ↓reduceIte]
  refine ⟨⟨?_, ?_, ?_, ?_, fun _ hr => by omega⟩, ⟨?_, ?_, ?_, ?_, fun _ hr => by omega⟩, wRead_wWrite_self _ _ _ _⟩
  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
  · intro h hh
    have : base + 4 + (h : ℤ) < base + S := by dsimp [S, swapPoolStride]; omega
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact henc.1.2.2.1 h hh
  · intro h hh
    have : base + 4 + (n : ℤ) + (h : ℤ) < base + S := by dsimp [S, swapPoolStride]; omega
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact henc.1.2.2.2.1 h hh
  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        show base + S + 1 = base + (S + 1) by ring, wRead_wWrite_self]; rfl
  · intro h hh
    have : base + S + 4 + (h : ℤ) < base + 2 * S := by dsimp [S, swapPoolStride]; omega
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact henc.2.1.2.2.1 h hh
  · intro h hh
    have : base + S + 4 + (n : ℤ) + (h : ℤ) < base + 2 * S := by dsimp [S, swapPoolStride]; omega
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact henc.2.1.2.2.2.1 h hh

def dualPoolFreezeStmt (scrW tbl : ℕ) (wBase : ℤ) (n : ℕ) : ArithRAMStmt :=
  .writeWordHeap tbl (.add (.readHeap scrW (.lit wBase)) (.lit (2 * swapPoolStride n))) (.lit 1)

theorem exec_dualPoolFreezeStmt {d TW BW TR BR scrW tbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBase base : ℤ) (n : ℕ) (D : DualPool)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : tbl < TW) (hne_scr : tbl ≠ scrW)
    (hbase : 0 ≤ base ∧ base + dualPoolStride n ≤ (BW : ℤ))
    (hb_r : H3a.wRead m₀ scrW wBase = base)
    (hl_le : D.live.sz ≤ n) (hs_le : D.snap.sz ≤ n)
    (henc : EncDualPool tbl base n D m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (dualPoolFreezeStmt scrW tbl wBase n) m₀ m₁ 20 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncDualPool tbl base n D.freeze m₁ ∧
      (∀ w, H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      WordFrameOutside scrW tbl base (dualPoolStride n) m₀ m₁ := by
  let S := swapPoolStride n
  have hS : 4 ≤ S := by dsimp [S, swapPoolStride]; omega
  have hD : dualPoolStride n = 2 + 2 * S := rfl
  let m1 := H3a.wWrite m₀ tbl (base + 2 * S) 1
  have hd1 : DetExec inp (dualPoolFreezeStmt scrW tbl wBase n) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ tbl _ _ (by change H3a.wRead m₀ scrW wBase + 2 * S = _; rw [hb_r]) rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  let ph := scrW + tbl + 1
  have hfr_ph := WordFrameOutside.wWrite_in ph tbl (base + 2 * S) 1 m₀ le_rfl (by omega) 1
  refine ⟨m1, hd1, InFootprint.wWrite hfp₀ htbl (by omega) (by omega),
    ⟨henc.1.mono_frame hfr_ph (by dsimp [ph]; omega) (Or.inr (Or.inl (by omega))) hl_le,
     henc.2.1.mono_frame hfr_ph (by dsimp [ph]; omega) (Or.inr (Or.inl (by dsimp [S]; omega))) hs_le,
     wRead_wWrite_self _ _ _ _⟩,
    fun _ => wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm),
    WordFrameOutside.wWrite_in scrW tbl base (dualPoolStride n) m₀ (by omega) (by omega) 1⟩

def dualPoolInsertStmt (scrW tbl : ℕ) (wBase wUid wScr : ℤ) (n : ℕ) : ArithRAMStmt :=
  let S := swapPoolStride n
  .seq (swapPoolInsertStmt scrW tbl wBase wUid wScr n)
    (.ite (.intEq (.readHeap tbl (.add (.readHeap scrW (.lit wBase)) (.lit (2 * S)))) (.lit 0))
      (.seq (.writeWordHeap scrW (.lit wBase) (.add (.readHeap scrW (.lit wBase)) (.lit S)))
      (.seq (swapPoolInsertStmt scrW tbl wBase wUid wScr n)
            (.writeWordHeap scrW (.lit wBase) (.sub (.readHeap scrW (.lit wBase)) (.lit S)))))
      .skip)

theorem exec_dualPoolInsertStmt {d TW BW TR BR scrW tbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBase wUid wScr base : ℤ) {n : ℕ} (hn : 1 ≤ n)
    {S_l S_s : Finset ℕ} {D : DualPool} (hwf : D.WF n S_l S_s) (uid : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htbl : tbl < TW) (hne_scr : tbl ≠ scrW)
    (hbase : 0 ≤ base ∧ base + dualPoolStride n ≤ (BW : ℤ))
    (hwB : 0 ≤ wBase ∧ wBase < (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 6 ≤ (BW : ℤ))
    (hneB : wBase < wScr ∨ wScr + 6 ≤ wBase)
    (hneBU : wBase ≠ wUid)
    (hneU : wUid < wScr ∨ wScr + 6 ≤ wUid)
    (hb_r : H3a.wRead m₀ scrW wBase = base)
    (hu_r : H3a.wRead m₀ scrW wUid = (uid : ℤ))
    (henc : EncDualPool tbl base n D m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (dualPoolInsertStmt scrW tbl wBase wUid wScr n) m₀ m₁ 530 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncDualPool tbl base n (D.insert n uid) m₁ ∧
      H3a.wRead m₁ scrW wBase = base ∧
      H3a.wRead m₁ scrW wUid = (uid : ℤ) ∧
      WordFrameOutside scrW tbl base (dualPoolStride n) m₀ m₁ := by
  let S := swapPoolStride n
  have hS : 4 ≤ S := by dsimp [S, swapPoolStride]; omega
  have hD : dualPoolStride n = 2 + 2 * S := rfl
  obtain ⟨m1, hd1, hfp1, hencL1, hb1, hu1, hfr1⟩ :=
    exec_swapPoolInsertStmt inp wBase wUid wScr base hn hwf.1 uid
      hfp₀ hscrW htbl hne_scr ⟨hbase.1, by omega⟩ hwScr hneB hneU hb_r hu_r henc.1
  have hencS1 : EncSwapPool tbl (base + S) n D.snap m1 :=
    henc.2.1.mono_frame hfr1 hne_scr (Or.inr (Or.inr le_rfl)) hwf.2.1.2.2.2.1
  have hfrz1 : H3a.wRead m1 tbl (base + 2 * S) = (if D.frozen then 1 else 0) :=
    (hfr1.1 tbl (base + 2 * S) hne_scr (Or.inr (Or.inr (by omega)))).trans henc.2.2
  let cFrz : ArithCondExpr := .intEq (.readHeap tbl (.add (.readHeap scrW (.lit wBase)) (.lit (2 * S)))) (.lit 0)
  have hl_ins_le : (D.live.insert n uid).sz ≤ n := by
    unfold SwapPool.insert; split_ifs with hc
    · exact hwf.1.2.2.2.1
    · have : ¬ n ≤ D.live.sz := fun h => hc (Or.inr h)
      dsimp only; omega
  cases hfrz : D.frozen with
  | true =>
      have hc_f : cValAt 0 inp m1 cFrz = false := by
        simp only [cValAt, cFrz, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 tbl (H3a.wRead m1 scrW wBase + 2 * S) = 0) = false
        rw [hb1, hfrz1, hfrz]; decide
      refine ⟨m1, (DetExecAt.seq hd1 (DetExecAt.ite_false hc_f (C_c := 15)
        (by dsimp [cFrz, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.skip 0 inp m1))).mono_cost (by omega),
        hfp1, ?_, hb1, hu1, hfr1.mono_len (by omega)⟩
      unfold EncDualPool DualPool.insert; rw [hfrz]; dsimp only [↓reduceIte]
      exact ⟨hencL1, hencS1, by rw [hfrz1, hfrz]⟩
  | false =>
      have hc_t : cValAt 0 inp m1 cFrz = true := by
        simp only [cValAt, cFrz, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 tbl (H3a.wRead m1 scrW wBase + 2 * S) = 0) = true
        rw [hb1, hfrz1, hfrz]; rfl
      let m2 := H3a.wWrite m1 scrW wBase (base + S)
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit wBase) (.add (.readHeap scrW (.lit wBase)) (.lit S))) m1 m2 15 :=
        DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wBase) _ rfl
          (by change H3a.wRead m1 scrW wBase + S = _; rw [hb1])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 hscrW hwB.1 hwB.2
      have hfr2_0 := WordFrameOutside.wWrite_scr scrW tbl base 0 m1 wBase (base + S)
      obtain ⟨m3, hd3, hfp3, hencS3, hb3, hu3, hfr3⟩ :=
        exec_swapPoolInsertStmt inp wBase wUid wScr (base + S) hn hwf.2.1 uid
          hfp2 hscrW htbl hne_scr ⟨by omega, by omega⟩ hwScr hneB hneU
          (wRead_wWrite_self _ _ _ _) (by rw [wRead_wWrite_of_ne _ _ (Or.inr hneBU.symm), hu1])
          (hencS1.mono_frame hfr2_0 hne_scr (Or.inr (Or.inr (by omega))) hwf.2.1.2.2.2.1)
      let m4 := H3a.wWrite m3 scrW wBase base
      have hd4 : DetExec inp (.writeWordHeap scrW (.lit wBase) (.sub (.readHeap scrW (.lit wBase)) (.lit S))) m3 m4 15 :=
        DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wBase) _ rfl
          (by change H3a.wRead m3 scrW wBase - S = base; rw [hb3]; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp4 : InFootprint TW BW TR BR m4 := InFootprint.wWrite hfp3 hscrW hwB.1 hwB.2
      have hs_ins_le : (D.snap.insert n uid).sz ≤ n := by
        unfold SwapPool.insert; split_ifs with hc
        · exact hwf.2.1.2.2.2.1
        · have : ¬ n ≤ D.snap.sz := fun h => hc (Or.inr h)
          dsimp only; omega
      have hencL4 : EncSwapPool tbl base n (D.live.insert n uid) m4 :=
        ((hencL1.mono_frame hfr2_0 hne_scr (Or.inr (Or.inr (by omega))) hl_ins_le).mono_frame
          hfr3 hne_scr (Or.inr (Or.inl (by omega))) hl_ins_le).mono_frame
          (WordFrameOutside.wWrite_scr scrW tbl base 0 m3 wBase base) hne_scr (Or.inr (Or.inr (by omega))) hl_ins_le
      have hencS4 : EncSwapPool tbl (base + S) n (D.snap.insert n uid) m4 :=
        hencS3.mono_frame (WordFrameOutside.wWrite_scr scrW tbl base 0 m3 wBase base) hne_scr
          (Or.inr (Or.inr (by omega))) hs_ins_le
      have hfrz4 : H3a.wRead m4 tbl (base + 2 * S) = 0 := by
        rw [wRead_wWrite_of_ne _ _ (Or.inl hne_scr),
            hfr3.1 tbl (base + 2 * S) hne_scr (Or.inr (Or.inr (by ring_nf; omega))),
            wRead_wWrite_of_ne _ _ (Or.inl hne_scr), hfrz1, hfrz]; rfl
      have hfr_all : WordFrameOutside scrW tbl base (dualPoolStride n) m₀ m4 :=
        ⟨fun t i hs ho => by
          rw [wRead_wWrite_of_ne _ _ (Or.inl hs),
              hfr3.1 t i hs (by
                rcases ho with ht | h1 | h2
                · exact Or.inl ht
                · exact Or.inr (Or.inl (by omega))
                · exact Or.inr (Or.inr (by omega))),
              wRead_wWrite_of_ne _ _ (Or.inl hs),
              hfr1.1 t i hs (by
                rcases ho with ht | h1 | h2
                · exact Or.inl ht
                · exact Or.inr (Or.inl h1)
                · exact Or.inr (Or.inr (by omega)))],
         fun t i => by rw [rRead_wWrite, hfr3.2, rRead_wWrite, hfr1.2]⟩
      refine ⟨m4, (DetExecAt.seq hd1 (DetExecAt.ite_true hc_t (C_c := 15)
        (by dsimp [cFrz, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.seq hd2 (DetExecAt.seq hd3 hd4)))).mono_cost (by omega),
        hfp4, ?_, wRead_wWrite_self _ _ _ _, by rw [wRead_wWrite_of_ne _ _ (Or.inr hneBU.symm), hu3], hfr_all⟩
      unfold EncDualPool DualPool.insert; rw [hfrz]; dsimp only [Bool.false_eq_true, ↓reduceIte]
      exact ⟨hencL4, hencS4, hfrz4⟩

def dualPoolDeleteStmt (scrW tbl : ℕ) (wBase wUid wScr : ℤ) (n : ℕ) : ArithRAMStmt :=
  let S := swapPoolStride n
  .seq (swapPoolDeleteStmt scrW tbl wBase wUid wScr n)
    (.ite (.intEq (.readHeap tbl (.add (.readHeap scrW (.lit wBase)) (.lit (2 * S)))) (.lit 0))
      (.seq (.writeWordHeap scrW (.lit wBase) (.add (.readHeap scrW (.lit wBase)) (.lit S)))
      (.seq (swapPoolDeleteStmt scrW tbl wBase wUid wScr n)
            (.writeWordHeap scrW (.lit wBase) (.sub (.readHeap scrW (.lit wBase)) (.lit S)))))
      .skip)

theorem exec_dualPoolDeleteStmt {d TW BW TR BR scrW tbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBase wUid wScr base : ℤ) {n : ℕ} (hn : 1 ≤ n)
    {S_l S_s : Finset ℕ} {D : DualPool} (hwf : D.WF n S_l S_s) (uid : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htbl : tbl < TW) (hne_scr : tbl ≠ scrW)
    (hbase : 0 ≤ base ∧ base + dualPoolStride n ≤ (BW : ℤ))
    (hwB : 0 ≤ wBase ∧ wBase < (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 8 ≤ (BW : ℤ))
    (hneB : wBase < wScr ∨ wScr + 8 ≤ wBase)
    (hneBU : wBase ≠ wUid)
    (hneU : wUid < wScr ∨ wScr + 8 ≤ wUid)
    (hb_r : H3a.wRead m₀ scrW wBase = base)
    (hu_r : H3a.wRead m₀ scrW wUid = (uid : ℤ))
    (henc : EncDualPool tbl base n D m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (dualPoolDeleteStmt scrW tbl wBase wUid wScr n) m₀ m₁ 630 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncDualPool tbl base n (D.delete n uid) m₁ ∧
      H3a.wRead m₁ scrW wBase = base ∧
      H3a.wRead m₁ scrW wUid = (uid : ℤ) ∧
      WordFrameOutside scrW tbl base (dualPoolStride n) m₀ m₁ := by
  let S := swapPoolStride n
  have hS : 4 ≤ S := by dsimp [S, swapPoolStride]; omega
  have hD : dualPoolStride n = 2 + 2 * S := rfl
  obtain ⟨m1, hd1, hfp1, hencL1, hb1, hu1, hfr1⟩ :=
    exec_swapPoolDeleteStmt inp wBase wUid wScr base hn hwf.1 uid
      hfp₀ hscrW htbl hne_scr ⟨hbase.1, by omega⟩ hwScr hneB hneU hb_r hu_r henc.1
  have hencS1 : EncSwapPool tbl (base + S) n D.snap m1 :=
    henc.2.1.mono_frame hfr1 hne_scr (Or.inr (Or.inr le_rfl)) hwf.2.1.2.2.2.1
  have hfrz1 : H3a.wRead m1 tbl (base + 2 * S) = (if D.frozen then 1 else 0) :=
    (hfr1.1 tbl (base + 2 * S) hne_scr (Or.inr (Or.inr (by omega)))).trans henc.2.2
  let cFrz : ArithCondExpr := .intEq (.readHeap tbl (.add (.readHeap scrW (.lit wBase)) (.lit (2 * S)))) (.lit 0)
  have hl_del_le : (D.live.delete n uid).sz ≤ n := (D.live.wf_delete hn hwf.1 uid).2.2.2.1
  cases hfrz : D.frozen with
  | true =>
      have hc_f : cValAt 0 inp m1 cFrz = false := by
        simp only [cValAt, cFrz, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 tbl (H3a.wRead m1 scrW wBase + 2 * S) = 0) = false
        rw [hb1, hfrz1, hfrz]; decide
      refine ⟨m1, (DetExecAt.seq hd1 (DetExecAt.ite_false hc_f (C_c := 15)
        (by dsimp [cFrz, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.skip 0 inp m1))).mono_cost (by omega),
        hfp1, ?_, hb1, hu1, hfr1.mono_len (by omega)⟩
      unfold EncDualPool DualPool.delete; rw [hfrz]; dsimp only [↓reduceIte]
      exact ⟨hencL1, hencS1, by rw [hfrz1, hfrz]⟩
  | false =>
      have hc_t : cValAt 0 inp m1 cFrz = true := by
        simp only [cValAt, cFrz, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 tbl (H3a.wRead m1 scrW wBase + 2 * S) = 0) = true
        rw [hb1, hfrz1, hfrz]; rfl
      let m2 := H3a.wWrite m1 scrW wBase (base + S)
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit wBase) (.add (.readHeap scrW (.lit wBase)) (.lit S))) m1 m2 15 :=
        DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wBase) _ rfl
          (by change H3a.wRead m1 scrW wBase + S = _; rw [hb1])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 hscrW hwB.1 hwB.2
      have hfr2_0 := WordFrameOutside.wWrite_scr scrW tbl base 0 m1 wBase (base + S)
      obtain ⟨m3, hd3, hfp3, hencS3, hb3, hu3, hfr3⟩ :=
        exec_swapPoolDeleteStmt inp wBase wUid wScr (base + S) hn hwf.2.1 uid
          hfp2 hscrW htbl hne_scr ⟨by omega, by omega⟩ hwScr hneB hneU
          (wRead_wWrite_self _ _ _ _) (by rw [wRead_wWrite_of_ne _ _ (Or.inr hneBU.symm), hu1])
          (hencS1.mono_frame hfr2_0 hne_scr (Or.inr (Or.inr (by omega))) hwf.2.1.2.2.2.1)
      let m4 := H3a.wWrite m3 scrW wBase base
      have hd4 : DetExec inp (.writeWordHeap scrW (.lit wBase) (.sub (.readHeap scrW (.lit wBase)) (.lit S))) m3 m4 15 :=
        DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wBase) _ rfl
          (by change H3a.wRead m3 scrW wBase - S = base; rw [hb3]; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp4 : InFootprint TW BW TR BR m4 := InFootprint.wWrite hfp3 hscrW hwB.1 hwB.2
      have hs_del_le : (D.snap.delete n uid).sz ≤ n := (D.snap.wf_delete hn hwf.2.1 uid).2.2.2.1
      have hencL4 : EncSwapPool tbl base n (D.live.delete n uid) m4 :=
        ((hencL1.mono_frame hfr2_0 hne_scr (Or.inr (Or.inr (by omega))) hl_del_le).mono_frame
          hfr3 hne_scr (Or.inr (Or.inl (by omega))) hl_del_le).mono_frame
          (WordFrameOutside.wWrite_scr scrW tbl base 0 m3 wBase base) hne_scr (Or.inr (Or.inr (by omega))) hl_del_le
      have hencS4 : EncSwapPool tbl (base + S) n (D.snap.delete n uid) m4 :=
        hencS3.mono_frame (WordFrameOutside.wWrite_scr scrW tbl base 0 m3 wBase base) hne_scr
          (Or.inr (Or.inr (by omega))) hs_del_le
      have hfrz4 : H3a.wRead m4 tbl (base + 2 * S) = 0 := by
        rw [wRead_wWrite_of_ne _ _ (Or.inl hne_scr),
            hfr3.1 tbl (base + 2 * S) hne_scr (Or.inr (Or.inr (by ring_nf; omega))),
            wRead_wWrite_of_ne _ _ (Or.inl hne_scr), hfrz1, hfrz]; rfl
      have hfr_all : WordFrameOutside scrW tbl base (dualPoolStride n) m₀ m4 :=
        ⟨fun t i hs ho => by
          rw [wRead_wWrite_of_ne _ _ (Or.inl hs),
              hfr3.1 t i hs (by
                rcases ho with ht | h1 | h2
                · exact Or.inl ht
                · exact Or.inr (Or.inl (by omega))
                · exact Or.inr (Or.inr (by omega))),
              wRead_wWrite_of_ne _ _ (Or.inl hs),
              hfr1.1 t i hs (by
                rcases ho with ht | h1 | h2
                · exact Or.inl ht
                · exact Or.inr (Or.inl h1)
                · exact Or.inr (Or.inr (by omega)))],
         fun t i => by rw [rRead_wWrite, hfr3.2, rRead_wWrite, hfr1.2]⟩
      refine ⟨m4, (DetExecAt.seq hd1 (DetExecAt.ite_true hc_t (C_c := 15)
        (by dsimp [cFrz, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.seq hd2 (DetExecAt.seq hd3 hd4)))).mono_cost (by omega),
        hfp4, ?_, wRead_wWrite_self _ _ _ _, by rw [wRead_wWrite_of_ne _ _ (Or.inr hneBU.symm), hu3], hfr_all⟩
      unfold EncDualPool DualPool.delete; rw [hfrz]; dsimp only [Bool.false_eq_true, ↓reduceIte]
      exact ⟨hencL4, hencS4, hfrz4⟩

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
