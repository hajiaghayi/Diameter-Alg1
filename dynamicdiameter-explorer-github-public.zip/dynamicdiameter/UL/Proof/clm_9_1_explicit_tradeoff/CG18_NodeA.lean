import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeA1

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

/-! ### 4. Pre-Drawn Coin Bit Slices (`coinTbl`) & Bridges to `H4c3c` Equivalences -/

def oneSeedBits (R ℓ M₀ d b : ℕ) : ℕ :=
  R * ℓ * M₀ * (d + 1) * b

def cfgSeedBits (L_p2 R ℓ M₀ d b : ℕ) : ℕ :=
  2 * L_p2 * oneSeedBits R ℓ M₀ d b

def nodeOpSeedBits (N_cfg L_p2 R ℓ M₀ d b : ℕ) : ℕ :=
  N_cfg * cfgSeedBits L_p2 R ℓ M₀ d b

theorem nodeOpSeedBits_eq_B_op {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    nodeOpSeedBits cp.N_cfg cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b = cp.B_op := by
  unfold nodeOpSeedBits cfgSeedBits oneSeedBits ChainParams.B_op
  ring

def EncOneSeedSlice {R ℓ M₀ d b : ℕ} (coinTbl : ℕ) (off : ℤ)
    (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b) (m : ArithRAMMemory) : Prop :=
  ∀ (r : Fin R) (a : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)) (bi : Fin b),
    let idx := ((((r.val * ℓ + a.val) * M₀ + k.val) * (d + 1) + j.val) * b + bi.val)
    H3a.wRead m coinTbl (off + (idx : ℤ)) = if ω ((r, a, k), j, bi) then 1 else 0

def EncCfgSeedSlice {L_p2 R ℓ M₀ d b : ℕ} (coinTbl : ℕ) (seedOff : ℤ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b) (m : ArithRAMMemory) : Prop :=
  let B₁ : ℤ := (oneSeedBits R ℓ M₀ d b : ℤ)
  (∀ s : Fin L_p2, EncOneSeedSlice coinTbl (seedOff + (s.val : ℤ) * B₁) (ω_L s) m) ∧
  (∀ s : Fin L_p2, EncOneSeedSlice coinTbl (seedOff + ((L_p2 + s.val : ℕ) : ℤ) * B₁) (ω_R s) m)

def EncNodeOpSeedSlice {N_cfg L_p2 R ℓ M₀ d b : ℕ} (coinTbl : ℕ) (nodeSeedOff : ℤ)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b) (m : ArithRAMMemory) : Prop :=
  let B_cfg : ℤ := (cfgSeedBits L_p2 R ℓ M₀ d b : ℤ)
  ∀ i : Fin N_cfg,
    EncCfgSeedSlice coinTbl (nodeSeedOff + (i.val : ℤ) * B_cfg)
      (fun s => ω (i, false, s)) (fun s => ω (i, true, s)) m

theorem EncCfgSeedSlice.mono_coinTbl {L_p2 R ℓ M₀ d b : ℕ} {coinTbl : ℕ} {seedOff : ℤ}
    {ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b} {m₀ m₁ : ArithRAMMemory}
    (hs : EncCfgSeedSlice coinTbl seedOff ω_L ω_R m₀)
    (heq : ∀ idx : ℤ, H3a.wRead m₁ coinTbl idx = H3a.wRead m₀ coinTbl idx) :
    EncCfgSeedSlice coinTbl seedOff ω_L ω_R m₁ :=
  ⟨fun s r a k j bi => (heq _).trans (hs.1 s r a k j bi),
   fun s r a k j bi => (heq _).trans (hs.2 s r a k j bi)⟩

theorem EncNodeOpSeedSlice.mono_coinTbl {N_cfg L_p2 R ℓ M₀ d b : ℕ} {coinTbl : ℕ} {nodeSeedOff : ℤ}
    {ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b} {m₀ m₁ : ArithRAMMemory}
    (hs : EncNodeOpSeedSlice coinTbl nodeSeedOff ω m₀)
    (heq : ∀ idx : ℤ, H3a.wRead m₁ coinTbl idx = H3a.wRead m₀ coinTbl idx) :
    EncNodeOpSeedSlice coinTbl nodeSeedOff ω m₁ :=
  fun i => (hs i).mono_coinTbl heq

theorem encNodeOpSeedSlice_of_bitsToOpSeedEquiv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (coinTbl : ℕ) (nodeSeedOff : ℤ)
    (bits : Fin cp.B_op → Bool) (m : ArithRAMMemory)
    (hbits : ∀ k : Fin cp.B_op, H3a.wRead m coinTbl (nodeSeedOff + (k.val : ℤ)) = if bits k then 1 else 0) :
    EncNodeOpSeedSlice coinTbl nodeSeedOff (bitsToOpSeedEquiv cp bits) m := by
  intro i
  constructor
  · intro s r a k j bi
    obtain ⟨hflat, heq⟩ := bitsToOpSeedEquiv_apply cp bits i false s r a k j bi
    dsimp only
    rw [heq, ← hbits ⟨_, hflat⟩]
    congr 1
    dsimp [cfgSeedBits, oneSeedBits]
    push_cast
    ring
  · intro s r a k j bi
    obtain ⟨hflat, heq⟩ := bitsToOpSeedEquiv_apply cp bits i true s r a k j bi
    dsimp only
    rw [heq, ← hbits ⟨_, hflat⟩]
    congr 1
    dsimp [cfgSeedBits, oneSeedBits]
    push_cast
    ring

def EncBaseSeedSlice {k_base q_idx : ℕ} (coinTbl : ℕ) (baseSeedOff : ℤ)
    (u : Fin k_base → Fin (2 ^ q_idx)) (m : ArithRAMMemory) : Prop :=
  ∃ bits : Fin k_base → Fin q_idx → Bool,
    (∀ j : Fin k_base, u j = bitsFnToFin q_idx (bits j)) ∧
    ∀ (j : Fin k_base) (bi : Fin q_idx),
      H3a.wRead m coinTbl (baseSeedOff + ((j.val * q_idx + bi.val : ℕ) : ℤ)) =
        if bits j bi then 1 else 0

theorem encBaseSeedSlice_of_bitsToBaseSeedEquiv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (coinTbl : ℕ) (baseSeedOff : ℤ)
    (bits : Fin cp.B_base → Bool) (m : ArithRAMMemory)
    (hbits : ∀ k : Fin cp.B_base, H3a.wRead m coinTbl (baseSeedOff + (k.val : ℤ)) = if bits k then 1 else 0) :
    EncBaseSeedSlice coinTbl baseSeedOff (bitsToBaseSeedEquiv cp bits) m := by
  refine ⟨splitBlocksEquiv cp.k_base cp.q_idx bits, fun _ => rfl, fun j bi => ?_⟩
  · simp only [splitBlocksEquiv_apply]
    exact hbits ⟨j.val * cp.q_idx + bi.val, by
      dsimp [ChainParams.B_base]
      calc j.val * cp.q_idx + bi.val
          < j.val * cp.q_idx + cp.q_idx := Nat.add_lt_add_left bi.isLt _
        _ = (j.val + 1) * cp.q_idx := by ring
        _ ≤ cp.k_base * cp.q_idx := Nat.mul_le_mul_right _ j.isLt⟩

/-! ### 5. `ConfigMatchRAMOps` Interface Record & `EncManagedNode` Layout -/

def ValidNodeTables (TW TR scrW scrR tblW tblR coinTbl : ℕ) : Prop :=
  scrW < TW ∧ tblW < TW ∧ coinTbl < TW ∧
  scrR < TR ∧ tblR < TR ∧ 1 < TR ∧
  tblW ≠ scrW ∧ coinTbl ≠ scrW ∧ coinTbl ≠ tblW ∧
  tblR ≠ scrR ∧ 1 ≠ scrR ∧ 1 ≠ tblR

/-- Decoupled RAM operations package for a single `H4b.ConfigDynamicState` block. -/
structure ConfigMatchRAMOps
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ)
    (params : LocalScaleParams) (h : ℝ)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) where
  cfgWStride : ℤ
  cfgRStride : ℤ
  hcfgW_nonneg : 0 ≤ cfgWStride
  hcfgR_nonneg : 0 ≤ cfgRStride
  opWScrStride : ℤ
  opRScrStride : ℤ
  hopWScr_pos : 1 ≤ opWScrStride
  hopRScr_pos : 1 ≤ opRScrStride
  clearCost : ℕ
  insertCost : ℕ
  deleteCost : ℕ
  readEdgeCost : ℕ

  CfgReady : ConfigStaticSpec d params h → ℤ → ℤ → ArithRAMMemory → Prop
  EncCfg : ConfigStaticSpec d params h → ℤ → ℤ →
    (ℕ → EuclideanSpace ℝ (Fin d)) → EuclideanSpace ℝ (Fin d) → ℝ → Finset ℕ →
    ConfigDynamicState L_p2 R ℓ M₀ d b → ArithRAMMemory → Prop

  cfgReady_of_zero : ∀ (spec : ConfigStaticSpec d params h) (cfgBaseW cfgBaseR : ℤ) (m : ArithRAMMemory),
    (∀ j : ℤ, 0 ≤ j → j < cfgWStride → H3a.wRead m tblW (cfgBaseW + j) = 0) →
    CfgReady spec cfgBaseW cfgBaseR m
  cfgReady_of_enc : ∀ (spec : ConfigStaticSpec d params h) (cfgBaseW cfgBaseR : ℤ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ℕ)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) (m : ArithRAMMemory),
    EncCfg spec cfgBaseW cfgBaseR pts o V S cs m →
    CfgReady spec cfgBaseW cfgBaseR m
  cfgReady_mono_slice : ∀ (spec : ConfigStaticSpec d params h) (cfgBaseW cfgBaseR : ℤ)
    (m₀ m₁ : ArithRAMMemory),
    CfgReady spec cfgBaseW cfgBaseR m₀ →
    (∀ i : ℤ, cfgBaseW ≤ i → i < cfgBaseW + cfgWStride → H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i) →
    (∀ i : ℤ, cfgBaseR ≤ i → i < cfgBaseR + cfgRStride → H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i) →
    CfgReady spec cfgBaseW cfgBaseR m₁

  encCfg_pts_congr : ∀ (spec : ConfigStaticSpec d params h) (cfgBaseW cfgBaseR : ℤ)
    (pts pts' : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ℕ)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) (m : ArithRAMMemory),
    (∀ x ∈ S, pts' x = pts x) →
    EncCfg spec cfgBaseW cfgBaseR pts o V S cs m →
    EncCfg spec cfgBaseW cfgBaseR pts' o V S cs m
  encCfg_mono_slice : ∀ (spec : ConfigStaticSpec d params h) (cfgBaseW cfgBaseR : ℤ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (S : Finset ℕ)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) (m₀ m₁ : ArithRAMMemory),
    EncCfg spec cfgBaseW cfgBaseR pts o V S cs m₀ →
    (∀ i : ℤ, cfgBaseW ≤ i → i < cfgBaseW + cfgWStride → H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i) →
    (∀ i : ℤ, cfgBaseR ≤ i → i < cfgBaseR + cfgRStride → H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i) →
    (∀ x ∈ S, x < n → ∀ c : Fin d,
      H3a.rRead m₁ 1 (((x * d + c.val : ℕ) : ℤ)) = H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ))) →
    EncCfg spec cfgBaseW cfgBaseR pts o V S cs m₁

  clearStmt : ConfigStaticSpec d params h → (wCfgBaseW wCfgBaseR wScr rScr : ℤ) → ArithRAMStmt
  insertStmt : ConfigStaticSpec d params h →
    (wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr : ℤ) → ArithRAMStmt
  deleteStmt : ConfigStaticSpec d params h →
    (wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr : ℤ) → ArithRAMStmt
  readEdgeStmt : ConfigStaticSpec d params h →
    (wCfgBaseW wOutHas wOutU wOutV wScr : ℤ) → ArithRAMStmt

  zeroRand_clearStmt : ∀ spec wBW wBR wScr rScr,
    ZeroRandStmt (clearStmt spec wBW wBR wScr rScr)
  zeroRand_insertStmt : ∀ spec wBW wBR wOffO wOffV wUid wSeedOff wScr rScr,
    ZeroRandStmt (insertStmt spec wBW wBR wOffO wOffV wUid wSeedOff wScr rScr)
  zeroRand_deleteStmt : ∀ spec wBW wBR wOffO wOffV wUid wSeedOff wScr rScr,
    ZeroRandStmt (deleteStmt spec wBW wBR wOffO wOffV wUid wSeedOff wScr rScr)
  zeroRand_readEdgeStmt : ∀ spec wBW wOutHas wOutU wOutV wScr,
    ZeroRandStmt (readEdgeStmt spec wBW wOutHas wOutU wOutV wScr)

  exec_clearStmt : ∀ {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wCfgBaseR wScr rScr cfgBaseW cfgBaseR : ℤ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ),
    InFootprint TW BW TR BR m₀ →
    ValidNodeTables TW TR scrW scrR tblW tblR coinTbl →
    (0 ≤ cfgBaseW ∧ cfgBaseW + cfgWStride ≤ (BW : ℤ)) →
    (0 ≤ cfgBaseR ∧ cfgBaseR + cfgRStride ≤ (BR : ℤ)) →
    (0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr) →
    (0 ≤ wCfgBaseR ∧ wCfgBaseR < wScr) →
    (0 ≤ wScr ∧ wScr + opWScrStride ≤ (BW : ℤ)) →
    (0 ≤ rScr ∧ rScr + opRScrStride ≤ (BR : ℤ)) →
    H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW →
    H3a.wRead m₀ scrW wCfgBaseR = cfgBaseR →
    CfgReady spec cfgBaseW cfgBaseR m₀ →
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (clearStmt spec wCfgBaseW wCfgBaseR wScr rScr) m₀ m₁ clearCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncCfg spec cfgBaseW cfgBaseR pts o V ∅
        (ConfigDynamicState.empty L_p2 R ℓ M₀ d b T_cdf p_coord) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW cfgWStride tblR cfgBaseR cfgRStride m₀ m₁

  exec_insertStmt : ∀ {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (hM₀ : 1 ≤ M₀) (_hn : 2 ≤ n) (_hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
      cfgBaseW cfgBaseR offO offV seedOff : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ}
    (_hV : 0 < V)
    {S : Finset ℕ} {p : ℕ} (_hp_not : p ∉ S) (_hp_lt : p < n)
    (_hS_lt : ∀ x ∈ S, x < n) (_hS_card : S.card + 1 ≤ n)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (_htL : cs.leftIdx.t_ins + 1 < 2 ^ L_p2) (_htR : cs.rightIdx.t_ins + 1 < 2 ^ L_p2)
    (_hwf : ConfigDynamicWF hM₀ T_cdf p_coord params spec.A spec.B τ_d cap_u pts o V S spec.cfg cs),
    InFootprint TW BW TR BR m₀ →
    ValidNodeTables TW TR scrW scrR tblW tblR coinTbl →
    (0 ≤ cfgBaseW ∧ cfgBaseW + cfgWStride ≤ (BW : ℤ)) →
    (0 ≤ cfgBaseR ∧ cfgBaseR + cfgRStride ≤ (BR : ℤ)) →
    (0 ≤ offO ∧ offO + (d : ℤ) ≤ cfgBaseR) →
    (0 ≤ offV ∧ offV < cfgBaseR) →
    (0 ≤ seedOff ∧ seedOff + (cfgSeedBits L_p2 R ℓ M₀ d b : ℤ) ≤ (BW : ℤ)) →
    (((n * d : ℕ) : ℤ) ≤ (BR : ℤ)) →
    (0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr) →
    (0 ≤ wCfgBaseR ∧ wCfgBaseR < wScr) →
    (0 ≤ wOffO ∧ wOffO < wScr) →
    (0 ≤ wOffV ∧ wOffV < wScr) →
    (0 ≤ wUid ∧ wUid < wScr) →
    (0 ≤ wSeedOff ∧ wSeedOff < wScr) →
    (0 ≤ wScr ∧ wScr + opWScrStride ≤ (BW : ℤ)) →
    (0 ≤ rScr ∧ rScr + opRScrStride ≤ (BR : ℤ)) →
    H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW →
    H3a.wRead m₀ scrW wCfgBaseR = cfgBaseR →
    H3a.wRead m₀ scrW wOffO = offO →
    H3a.wRead m₀ scrW wOffV = offV →
    H3a.wRead m₀ scrW wUid = (p : ℤ) →
    H3a.wRead m₀ scrW wSeedOff = seedOff →
    (∀ c : Fin d, H3a.rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c) →
    H3a.rRead m₀ tblR offV = V →
    (∀ x ∈ Insert.insert p S, ∀ c : Fin d,
      H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) →
    EncCfgSeedSlice coinTbl seedOff ω_L ω_R m₀ →
    EncCfg spec cfgBaseW cfgBaseR pts o V S cs m₀ →
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (insertStmt spec wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr)
        m₀ m₁ insertCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncCfg spec cfgBaseW cfgBaseR pts o V (Insert.insert p S)
        (cs.insertOriginal hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg p ω_L ω_R) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW cfgWStride tblR cfgBaseR cfgRStride m₀ m₁

  exec_deleteStmt : ∀ {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (hM₀ : 1 ≤ M₀) (_hn : 2 ≤ n) (_hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
      cfgBaseW cfgBaseR offO offV seedOff : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ}
    (_hV : 0 < V)
    {S : Finset ℕ} {p : ℕ} (_hp_mem : p ∈ S) (_hp_lt : p < n)
    (_hS_lt : ∀ x ∈ S, x < n) (_hS_card : S.card ≤ n)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (_htL : cs.leftIdx.t_ins + 1 < 2 ^ L_p2) (_htR : cs.rightIdx.t_ins + 1 < 2 ^ L_p2)
    (_hwf : ConfigDynamicWF hM₀ T_cdf p_coord params spec.A spec.B τ_d cap_u pts o V S spec.cfg cs),
    InFootprint TW BW TR BR m₀ →
    ValidNodeTables TW TR scrW scrR tblW tblR coinTbl →
    (0 ≤ cfgBaseW ∧ cfgBaseW + cfgWStride ≤ (BW : ℤ)) →
    (0 ≤ cfgBaseR ∧ cfgBaseR + cfgRStride ≤ (BR : ℤ)) →
    (0 ≤ offO ∧ offO + (d : ℤ) ≤ cfgBaseR) →
    (0 ≤ offV ∧ offV < cfgBaseR) →
    (0 ≤ seedOff ∧ seedOff + (cfgSeedBits L_p2 R ℓ M₀ d b : ℤ) ≤ (BW : ℤ)) →
    (((n * d : ℕ) : ℤ) ≤ (BR : ℤ)) →
    (0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr) →
    (0 ≤ wCfgBaseR ∧ wCfgBaseR < wScr) →
    (0 ≤ wOffO ∧ wOffO < wScr) →
    (0 ≤ wOffV ∧ wOffV < wScr) →
    (0 ≤ wUid ∧ wUid < wScr) →
    (0 ≤ wSeedOff ∧ wSeedOff < wScr) →
    (0 ≤ wScr ∧ wScr + opWScrStride ≤ (BW : ℤ)) →
    (0 ≤ rScr ∧ rScr + opRScrStride ≤ (BR : ℤ)) →
    H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW →
    H3a.wRead m₀ scrW wCfgBaseR = cfgBaseR →
    H3a.wRead m₀ scrW wOffO = offO →
    H3a.wRead m₀ scrW wOffV = offV →
    H3a.wRead m₀ scrW wUid = (p : ℤ) →
    H3a.wRead m₀ scrW wSeedOff = seedOff →
    (∀ c : Fin d, H3a.rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c) →
    H3a.rRead m₀ tblR offV = V →
    (∀ x ∈ S, ∀ c : Fin d,
      H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) →
    EncCfgSeedSlice coinTbl seedOff ω_L ω_R m₀ →
    EncCfg spec cfgBaseW cfgBaseR pts o V S cs m₀ →
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (deleteStmt spec wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr)
        m₀ m₁ deleteCost ∧
      InFootprint TW BW TR BR m₁ ∧
      EncCfg spec cfgBaseW cfgBaseR pts o V (S.erase p)
        (cs.deleteOriginal hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg p ω_L ω_R) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW cfgWStride tblR cfgBaseR cfgRStride m₀ m₁

  exec_readEdgeStmt : ∀ {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wOutHas wOutU wOutV wScr cfgBaseW cfgBaseR : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ} {S : Finset ℕ}
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b},
    InFootprint TW BW TR BR m₀ →
    ValidNodeTables TW TR scrW scrR tblW tblR coinTbl →
    (0 ≤ cfgBaseW ∧ cfgBaseW + cfgWStride ≤ (BW : ℤ)) →
    (0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr) →
    (0 ≤ wOutHas ∧ wOutHas < wScr) →
    (0 ≤ wOutU ∧ wOutU < wScr) →
    (0 ≤ wOutV ∧ wOutV < wScr) →
    (wOutHas ≠ wOutU ∧ wOutHas ≠ wOutV ∧ wOutU ≠ wOutV ∧
      wCfgBaseW ≠ wOutHas ∧ wCfgBaseW ≠ wOutU ∧ wCfgBaseW ≠ wOutV) →
    (0 ≤ wScr ∧ wScr + opWScrStride ≤ (BW : ℤ)) →
    H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW →
    EncCfg spec cfgBaseW cfgBaseR pts o V S cs m₀ →
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (readEdgeStmt spec wCfgBaseW wOutHas wOutU wOutV wScr) m₀ m₁ readEdgeCost ∧
      InFootprint TW BW TR BR m₁ ∧
      (match cs.st.storedEdge with
       | none => H3a.wRead m₁ scrW wOutHas = 0
       | some (u, v) =>
           H3a.wRead m₁ scrW wOutHas = 1 ∧
           H3a.wRead m₁ scrW wOutU = (u : ℤ) ∧
           H3a.wRead m₁ scrW wOutV = (v : ℤ)) ∧
      (∀ w, w < wScr → w ≠ wOutHas → w ≠ wOutU → w ≠ wOutV →
        H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW 0 tblR cfgBaseR 0 m₀ m₁

/-! ### 6. `ManagedNode` Heap Offsets, `ManagedNodeSlotReady` & `EncManagedNode` -/

def nodeBirthSizeOff (nodeBaseW : ℤ) : ℤ := nodeBaseW
def nodeAgeOff (nodeBaseW : ℤ) : ℤ := nodeBaseW + 1
def nodeBaseHasOff (nodeBaseW : ℤ) : ℤ := nodeBaseW + 2
def nodeBaseUOff (nodeBaseW : ℤ) : ℤ := nodeBaseW + 3
def nodeBaseVOff (nodeBaseW : ℤ) : ℤ := nodeBaseW + 4

def nodeDensePoolOff (nodeBaseW : ℤ) : ℤ := nodeBaseW + 8
def nodeResPoolOff (n : ℕ) (nodeBaseW : ℤ) : ℤ := nodeBaseW + 8 + swapPoolStride n
def nodeHistOff (n : ℕ) (nodeBaseW : ℤ) : ℤ := nodeBaseW + 8 + 2 * swapPoolStride n
def nodeRadTreeWOff (n cap_hist : ℕ) (nodeBaseW : ℤ) : ℤ :=
  nodeHistOff n nodeBaseW + (1 + (cap_hist : ℤ))
def nodeCfgsWBase (n cap_hist K_seg : ℕ) (nodeBaseW : ℤ) : ℤ :=
  nodeRadTreeWOff n cap_hist nodeBaseW + radTreeWStride K_seg
def nodeCfgWOff (n cap_hist K_seg : ℕ) (cfgWStride : ℤ) (nodeBaseW : ℤ) (i : ℕ) : ℤ :=
  nodeCfgsWBase n cap_hist K_seg nodeBaseW + (i : ℤ) * cfgWStride
def managedNodeWStride (n cap_hist K_seg N_cfg : ℕ) (cfgWStride : ℤ) : ℤ :=
  8 + 2 * swapPoolStride n + (1 + (cap_hist : ℤ)) + radTreeWStride K_seg + (N_cfg : ℤ) * cfgWStride

def nodeCenterROff (nodeBaseR : ℤ) : ℤ := nodeBaseR
def nodeHeightROff (d : ℕ) (nodeBaseR : ℤ) : ℤ := nodeBaseR + (d : ℤ)
def nodeVarROff (d : ℕ) (nodeBaseR : ℤ) : ℤ := nodeBaseR + (d : ℤ) + 1
def nodeRadTreeROff (d : ℕ) (nodeBaseR : ℤ) : ℤ := nodeBaseR + (d : ℤ) + 2
def nodeCfgsRBase (d K_seg : ℕ) (nodeBaseR : ℤ) : ℤ :=
  nodeRadTreeROff d nodeBaseR + radTreeRStride K_seg
def nodeCfgROff (d K_seg : ℕ) (cfgRStride : ℤ) (nodeBaseR : ℤ) (i : ℕ) : ℤ :=
  nodeCfgsRBase d K_seg nodeBaseR + (i : ℤ) * cfgRStride
def managedNodeRStride (d K_seg N_cfg : ℕ) (cfgRStride : ℤ) : ℤ :=
  (d : ℤ) + 2 + radTreeRStride K_seg + (N_cfg : ℤ) * cfgRStride

theorem managedNodeWStride_ge_header (n cap_hist K_seg N_cfg : ℕ) {cfgWStride : ℤ}
    (hcfg : 0 ≤ cfgWStride) :
    21 ≤ managedNodeWStride n cap_hist K_seg N_cfg cfgWStride := by
  unfold managedNodeWStride swapPoolStride
  have hrad := radTreeWStride_ge_four K_seg
  have hncfg : 0 ≤ (N_cfg : ℤ) * cfgWStride := mul_nonneg (Nat.cast_nonneg _) hcfg
  omega

theorem radTreeRStride_nonneg (K_seg : ℕ) : 0 ≤ radTreeRStride K_seg := by
  unfold radTreeRStride
  exact mul_nonneg (by decide) (Nat.cast_nonneg _)

theorem managedNodeRStride_ge_header (d K_seg N_cfg : ℕ) {cfgRStride : ℤ}
    (hcfg : 0 ≤ cfgRStride) :
    (d : ℤ) + 2 ≤ managedNodeRStride d K_seg N_cfg cfgRStride := by
  unfold managedNodeRStride
  have hrad := radTreeRStride_nonneg K_seg
  have hncfg : 0 ≤ (N_cfg : ℤ) * cfgRStride := mul_nonneg (Nat.cast_nonneg _) hcfg
  omega

theorem nodeCfgWOff_bounds (n cap_hist K_seg : ℕ) {N_cfg : ℕ} {cfgWStride : ℤ}
    (hcfg : 0 ≤ cfgWStride) (nodeBaseW : ℤ) (i : Fin N_cfg) :
    nodeCfgsWBase n cap_hist K_seg nodeBaseW ≤ nodeCfgWOff n cap_hist K_seg cfgWStride nodeBaseW i.val ∧
    nodeCfgWOff n cap_hist K_seg cfgWStride nodeBaseW i.val + cfgWStride ≤
      nodeBaseW + managedNodeWStride n cap_hist K_seg N_cfg cfgWStride := by
  unfold nodeCfgWOff nodeCfgsWBase nodeRadTreeWOff nodeHistOff managedNodeWStride
  have h1 : 0 ≤ (i.val : ℤ) * cfgWStride := mul_nonneg (Nat.cast_nonneg _) hcfg
  have h2 : ((i.val + 1 : ℕ) : ℤ) * cfgWStride ≤ (N_cfg : ℤ) * cfgWStride :=
    mul_le_mul_of_nonneg_right (by exact_mod_cast i.isLt) hcfg
  have h3 : (i.val : ℤ) * cfgWStride + cfgWStride = ((i.val + 1 : ℕ) : ℤ) * cfgWStride := by
    push_cast; ring
  omega

theorem nodeCfgROff_bounds (d K_seg : ℕ) {N_cfg : ℕ} {cfgRStride : ℤ}
    (hcfg : 0 ≤ cfgRStride) (nodeBaseR : ℤ) (i : Fin N_cfg) :
    nodeCfgsRBase d K_seg nodeBaseR ≤ nodeCfgROff d K_seg cfgRStride nodeBaseR i.val ∧
    nodeCfgROff d K_seg cfgRStride nodeBaseR i.val + cfgRStride ≤
      nodeBaseR + managedNodeRStride d K_seg N_cfg cfgRStride := by
  unfold nodeCfgROff nodeCfgsRBase nodeRadTreeROff managedNodeRStride
  have h1 : 0 ≤ (i.val : ℤ) * cfgRStride := mul_nonneg (Nat.cast_nonneg _) hcfg
  have h2 : ((i.val + 1 : ℕ) : ℤ) * cfgRStride ≤ (N_cfg : ℤ) * cfgRStride :=
    mul_le_mul_of_nonneg_right (by exact_mod_cast i.isLt) hcfg
  have h3 : (i.val : ℤ) * cfgRStride + cfgRStride = ((i.val + 1 : ℕ) : ℤ) * cfgRStride := by
    push_cast; ring
  omega

noncomputable def nodeCfgSet {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (nd : NodeInst L_p2 R ℓ M₀ d b N_cfg) : Finset ℕ :=
  open Classical in
  if 0 < nd.V then nd.curSet else ∅

theorem mem_nodeCfgSet_sub {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    {nd : NodeInst L_p2 R ℓ M₀ d b N_cfg} {x : ℕ} (hx : x ∈ nodeCfgSet nd) :
    x ∈ nd.curSet := by
  unfold nodeCfgSet at hx
  split_ifs at hx
  · exact hx
  · exact absurd hx (Finset.notMem_empty _)

def EncOptPair (tblW : ℕ) (offHas offU offV : ℤ) (bp : Option (ℕ × ℕ)) (m : ArithRAMMemory) : Prop :=
  match bp with
  | none =>
      H3a.wRead m tblW offHas = 0 ∧
      H3a.wRead m tblW offU = 0 ∧
      H3a.wRead m tblW offV = 0
  | some (u, v) =>
      H3a.wRead m tblW offHas = 1 ∧
      H3a.wRead m tblW offU = (u : ℤ) ∧
      H3a.wRead m tblW offV = (v : ℤ)

/-- Slot readiness for `managedNodeOpenEmptyStmt` (holds on `ArithRAMMemory.empty` and on any `EncManagedNode`). -/
def ManagedNodeSlotReady
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (nodeBaseW nodeBaseR : ℤ) (m : ArithRAMMemory) : Prop :=
  SwapPoolReady tblW (nodeDensePoolOff nodeBaseW) n m ∧
  SwapPoolReady tblW (nodeResPoolOff n nodeBaseW) n m ∧
  RadTreeReady tblW (nodeRadTreeWOff n cap_hist nodeBaseW) K_seg m ∧
  ∀ i : Fin N_cfg,
    ops.CfgReady (specs i)
      (nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val)
      (nodeCfgROff d K_seg ops.cfgRStride nodeBaseR i.val) m

/-- Complete RAM encoding of `H4c2.ManagedNode` + cached `basePair : Option (ℕ × ℕ)`. -/
def EncManagedNode
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (nodeBaseW nodeBaseR : ℤ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg)
    (basePair : Option (ℕ × ℕ))
    (m : ArithRAMMemory) : Prop :=
  H3a.wRead m tblW (nodeBirthSizeOff nodeBaseW) = (mn.nd.birthSize : ℤ) ∧
  H3a.wRead m tblW (nodeAgeOff nodeBaseW) = (mn.nd.age : ℤ) ∧
  EncOptPair tblW (nodeBaseHasOff nodeBaseW) (nodeBaseUOff nodeBaseW) (nodeBaseVOff nodeBaseW) basePair m ∧
  (∀ c : Fin d, H3a.rRead m tblR (nodeCenterROff nodeBaseR + (c.val : ℤ)) = euclideanCoord mn.nd.o c) ∧
  H3a.rRead m tblR (nodeHeightROff d nodeBaseR) = mn.nd.s ∧
  H3a.rRead m tblR (nodeVarROff d nodeBaseR) = mn.nd.V ∧
  mn.histArr.length ≤ cap_hist ∧
  H3a.wRead m tblW (nodeHistOff n nodeBaseW) = (mn.histArr.length : ℤ) ∧
  (∀ (j : ℕ) (hj : j < mn.histArr.length),
    H3a.wRead m tblW (nodeHistOff n nodeBaseW + 1 + (j : ℤ)) = ((mn.histArr[j]'hj) : ℤ)) ∧
  (∃ P_dense : SwapPool,
    P_dense.WF n mn.nd.curSet ∧
    swapPoolToList P_dense = mn.nd.denseArr ∧
    EncSwapPool tblW (nodeDensePoolOff nodeBaseW) n P_dense m) ∧
  (∃ P_res : SwapPool,
    P_res.WF n mn.resArr.toFinset ∧
    swapPoolToList P_res = mn.resArr ∧
    EncSwapPool tblW (nodeResPoolOff n nodeBaseW) n P_res m) ∧
  (∃ T_rad : EpochRadTree,
    RadTreeExactWF K_seg pts mn.nd.o mn.nd.curSet T_rad ∧
    EncEpochRadTree tblW (nodeRadTreeWOff n cap_hist nodeBaseW)
      tblR (nodeRadTreeROff d nodeBaseR) K_seg T_rad m) ∧
  (∀ i : Fin N_cfg,
    ops.EncCfg (specs i)
      (nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val)
      (nodeCfgROff d K_seg ops.cfgRStride nodeBaseR i.val)
      pts mn.nd.o mn.nd.V (nodeCfgSet mn.nd) (mn.nd.cfgs i) m)

theorem ManagedNodeSlotReady.of_zero
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (nodeBaseW nodeBaseR : ℤ) {m : ArithRAMMemory}
    (hz : ∀ j : ℤ, 0 ≤ j → j < managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride →
      H3a.wRead m tblW (nodeBaseW + j) = 0) :
    ManagedNodeSlotReady ops specs cap_hist K_seg nodeBaseW nodeBaseR m := by
  have hcfgW := ops.hcfgW_nonneg
  have hrad4 := radTreeWStride_ge_four K_seg
  have hncfg : 0 ≤ (N_cfg : ℤ) * ops.cfgWStride := mul_nonneg (Nat.cast_nonneg _) hcfgW
  refine ⟨?_, ?_, ?_, fun i => ?_⟩
  · refine SwapPoolReady.of_zero (fun j hj0 hjs => ?_)
    have heq : nodeDensePoolOff nodeBaseW + j = nodeBaseW + (8 + j) := by
      unfold nodeDensePoolOff; ring
    rw [heq]
    exact hz (8 + j) (by omega) (by unfold managedNodeWStride swapPoolStride at *; omega)
  · refine SwapPoolReady.of_zero (fun j hj0 hjs => ?_)
    have heq : nodeResPoolOff n nodeBaseW + j = nodeBaseW + (8 + swapPoolStride n + j) := by
      unfold nodeResPoolOff; ring
    rw [heq]
    exact hz _ (by unfold swapPoolStride; omega) (by unfold managedNodeWStride swapPoolStride at *; omega)
  · refine RadTreeReady.of_zero (fun j hj0 hjs => ?_)
    have heq : nodeRadTreeWOff n cap_hist nodeBaseW + j =
        nodeBaseW + (8 + 2 * swapPoolStride n + (1 + (cap_hist : ℤ)) + j) := by
      unfold nodeRadTreeWOff nodeHistOff; ring
    rw [heq]
    exact hz _ (by unfold swapPoolStride; omega) (by unfold managedNodeWStride at *; omega)
  · refine ops.cfgReady_of_zero (specs i) _ _ m (fun j hj0 hjs => ?_)
    have hbnd := nodeCfgWOff_bounds n cap_hist K_seg hcfgW nodeBaseW i
    have hlo : nodeBaseW ≤ nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val := by
      have : nodeBaseW ≤ nodeCfgsWBase n cap_hist K_seg nodeBaseW := by
        unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride; omega
      omega
    let off := nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val + j - nodeBaseW
    have heq : nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val + j = nodeBaseW + off := by
      dsimp [off]; ring
    rw [heq]
    exact hz off (by dsimp [off]; omega) (by dsimp [off]; omega)

theorem ManagedNodeSlotReady.of_empty
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (nodeBaseW nodeBaseR : ℤ) :
    ManagedNodeSlotReady ops specs cap_hist K_seg nodeBaseW nodeBaseR ArithRAMMemory.empty :=
  ManagedNodeSlotReady.of_zero ops specs cap_hist K_seg nodeBaseW nodeBaseR (fun _ _ _ => rfl)

theorem ManagedNodeSlotReady.of_enc
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (nodeBaseW nodeBaseR : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg} {bp : Option (ℕ × ℕ)} {m : ArithRAMMemory}
    (henc : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m) :
    ManagedNodeSlotReady ops specs cap_hist K_seg nodeBaseW nodeBaseR m := by
  rcases henc with ⟨_, _, _, _, _, _, _, _, _, ⟨Pd, hPd_wf, _, hPd_e⟩,
    ⟨Pr, hPr_wf, _, hPr_e⟩, ⟨Tr, hTr_wf, hTr_e⟩, hcfgs⟩
  exact ⟨SwapPoolReady.of_enc hPd_wf hPd_e,
         SwapPoolReady.of_enc hPr_wf hPr_e,
         RadTreeReady.of_enc hTr_wf hTr_e,
         fun i => ops.cfgReady_of_enc (specs i) _ _ _ _ _ _ _ m (hcfgs i)⟩

theorem EncManagedNode.pts_congr
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    {ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    {specs : Fin N_cfg → ConfigStaticSpec d params h}
    {cap_hist K_seg : ℕ} {nodeBaseW nodeBaseR : ℤ}
    {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg} {bp : Option (ℕ × ℕ)} {m : ArithRAMMemory}
    (heq : ∀ x ∈ mn.nd.curSet, pts' x = pts x)
    (henc : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m) :
    EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts' mn bp m := by
  rcases henc with ⟨hb, ha, hbp, ho, hs, hV, hh_le, hh_len, hh_el, hPd, hPr, ⟨Tr, hTr_wf, hTr_e⟩, hcfgs⟩
  exact ⟨hb, ha, hbp, ho, hs, hV, hh_le, hh_len, hh_el, hPd, hPr,
    ⟨Tr, radTreeExactWF_pts_congr heq hTr_wf, hTr_e⟩,
    fun i => ops.encCfg_pts_congr (specs i) _ _ pts pts' _ _ _ _ m (fun x hx => heq x (mem_nodeCfgSet_sub hx)) (hcfgs i)⟩

theorem EncManagedNode.mono_slice
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    {ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl}
    {specs : Fin N_cfg → ConfigStaticSpec d params h}
    {cap_hist K_seg : ℕ} {nodeBaseW nodeBaseR : ℤ}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg} {bp : Option (ℕ × ℕ)} {m₀ m₁ : ArithRAMMemory}
    (henc : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₀)
    (heqW : ∀ i : ℤ, nodeBaseW ≤ i →
      i < nodeBaseW + managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i)
    (heqR : ∀ i : ℤ, nodeBaseR ≤ i →
      i < nodeBaseR + managedNodeRStride d K_seg N_cfg ops.cfgRStride →
      H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i)
    (heqPts : ∀ x ∈ mn.nd.curSet, x < n → ∀ c : Fin d,
      H3a.rRead m₁ 1 (((x * d + c.val : ℕ) : ℤ)) = H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ))) :
    EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₁ := by
  have hcfgW := ops.hcfgW_nonneg
  have hcfgR := ops.hcfgR_nonneg
  have hw21 := managedNodeWStride_ge_header n cap_hist K_seg N_cfg hcfgW
  have hrd2 := managedNodeRStride_ge_header d K_seg N_cfg hcfgR
  have hrad4 := radTreeWStride_ge_four K_seg
  have hncfgW : 0 ≤ (N_cfg : ℤ) * ops.cfgWStride := mul_nonneg (Nat.cast_nonneg _) hcfgW
  have hncfgR : 0 ≤ (N_cfg : ℤ) * ops.cfgRStride := mul_nonneg (Nat.cast_nonneg _) hcfgR
  rcases henc with ⟨hb, ha, hbp, ho, hs, hV, hh_le, hh_len, hh_el,
    ⟨Pd, hPd_wf, hPd_l, hPd_e⟩, ⟨Pr, hPr_wf, hPr_l, hPr_e⟩, ⟨Tr, hTr_wf, hTr_e⟩, hcfgs⟩
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, hh_le, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · exact (heqW _ le_rfl (by omega)).trans hb
  · exact (heqW _ (by unfold nodeAgeOff; omega) (by unfold nodeAgeOff; omega)).trans ha
  · cases bp with
    | none =>
        rcases hbp with ⟨h1, h2, h3⟩
        exact ⟨(heqW _ (by unfold nodeBaseHasOff; omega) (by unfold nodeBaseHasOff; omega)).trans h1,
               (heqW _ (by unfold nodeBaseUOff; omega) (by unfold nodeBaseUOff; omega)).trans h2,
               (heqW _ (by unfold nodeBaseVOff; omega) (by unfold nodeBaseVOff; omega)).trans h3⟩
    | some uv =>
        rcases uv with ⟨u, v⟩
        rcases hbp with ⟨h1, h2, h3⟩
        exact ⟨(heqW _ (by unfold nodeBaseHasOff; omega) (by unfold nodeBaseHasOff; omega)).trans h1,
               (heqW _ (by unfold nodeBaseUOff; omega) (by unfold nodeBaseUOff; omega)).trans h2,
               (heqW _ (by unfold nodeBaseVOff; omega) (by unfold nodeBaseVOff; omega)).trans h3⟩
  · intro c
    exact (heqR _ (by unfold nodeCenterROff; omega)
      (by unfold nodeCenterROff; have := c.isLt; omega)).trans (ho c)
  · exact (heqR _ (by unfold nodeHeightROff; omega) (by unfold nodeHeightROff; omega)).trans hs
  · exact (heqR _ (by unfold nodeVarROff; omega) (by unfold nodeVarROff; omega)).trans hV
  · exact (heqW _ (by unfold nodeHistOff swapPoolStride; omega)
      (by unfold nodeHistOff managedNodeWStride swapPoolStride at *; omega)).trans hh_len
  · intro j hj
    exact (heqW _ (by unfold nodeHistOff swapPoolStride; omega)
      (by unfold nodeHistOff managedNodeWStride swapPoolStride at *; omega)).trans (hh_el j hj)
  · refine ⟨Pd, hPd_wf, hPd_l, ?_⟩
    have hsub : ∀ i : ℤ, nodeDensePoolOff nodeBaseW ≤ i →
        i < nodeDensePoolOff nodeBaseW + swapPoolStride n → H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i := by
      intro i hlo hhi
      exact heqW i (by unfold nodeDensePoolOff at hlo; omega)
        (by unfold nodeDensePoolOff managedNodeWStride swapPoolStride at *; omega)
    have hsz_le := hPd_wf.2.2.2.1
    exact ⟨(hsub _ le_rfl (by dsimp [swapPoolStride]; omega)).trans hPd_e.1,
      (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans hPd_e.2.1,
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPd_e.2.2.1 x hx),
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPd_e.2.2.2.1 x hx),
      fun r hr => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPd_e.2.2.2.2 r hr)⟩
  · refine ⟨Pr, hPr_wf, hPr_l, ?_⟩
    have hsub : ∀ i : ℤ, nodeResPoolOff n nodeBaseW ≤ i →
        i < nodeResPoolOff n nodeBaseW + swapPoolStride n → H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i := by
      intro i hlo hhi
      exact heqW i (by unfold nodeResPoolOff swapPoolStride at *; omega)
        (by unfold nodeResPoolOff managedNodeWStride swapPoolStride at *; omega)
    have hsz_le := hPr_wf.2.2.2.1
    exact ⟨(hsub _ le_rfl (by dsimp [swapPoolStride]; omega)).trans hPr_e.1,
      (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans hPr_e.2.1,
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr_e.2.2.1 x hx),
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr_e.2.2.2.1 x hx),
      fun r hr => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr_e.2.2.2.2 r hr)⟩
  · refine ⟨Tr, hTr_wf, ?_⟩
    have hsubW : ∀ i : ℤ, nodeRadTreeWOff n cap_hist nodeBaseW ≤ i →
        i < nodeRadTreeWOff n cap_hist nodeBaseW + radTreeWStride K_seg →
        H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i := by
      intro i hlo hhi
      exact heqW i (by unfold nodeRadTreeWOff nodeHistOff swapPoolStride at *; omega)
        (by unfold nodeRadTreeWOff nodeHistOff managedNodeWStride swapPoolStride at *; omega)
    have hsubR : ∀ i : ℤ, nodeRadTreeROff d nodeBaseR ≤ i →
        i < nodeRadTreeROff d nodeBaseR + radTreeRStride K_seg →
        H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i := by
      intro i hlo hhi
      exact heqR i (by unfold nodeRadTreeROff at *; omega)
        (by unfold nodeRadTreeROff managedNodeRStride at *; omega)
    refine ⟨(hsubW _ le_rfl (by omega)).trans hTr_e.1, fun v hv => ?_⟩
    have hvW := radTreeWStride_gt_node hv
    have hvR := radTreeRStride_gt_node hv
    obtain ⟨e1, e2, e3, e4⟩ := hTr_e.2 v hv
    exact ⟨(hsubW _ (by omega) (by omega)).trans e1,
           (hsubW _ (by omega) (by omega)).trans e2,
           (hsubW _ (by omega) (by omega)).trans e3,
           (hsubR _ (by omega) (by omega)).trans e4⟩
  · intro i
    have hbW := nodeCfgWOff_bounds n cap_hist K_seg hcfgW nodeBaseW i
    have hbR := nodeCfgROff_bounds d K_seg hcfgR nodeBaseR i
    have hloW : nodeBaseW ≤ nodeCfgsWBase n cap_hist K_seg nodeBaseW := by
      unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride; omega
    have hloR : nodeBaseR ≤ nodeCfgsRBase d K_seg nodeBaseR := by
      have hrad := radTreeRStride_nonneg K_seg
      unfold nodeCfgsRBase nodeRadTreeROff; omega
    exact ops.encCfg_mono_slice (specs i) _ _ pts mn.nd.o mn.nd.V (nodeCfgSet mn.nd) (mn.nd.cfgs i) m₀ m₁
      (hcfgs i)
      (fun j hj1 hj2 => heqW j (by omega) (by omega))
      (fun j hj1 hj2 => heqR j (by omega) (by omega))
      (fun x hx => heqPts x (mem_nodeCfgSet_sub hx))

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
