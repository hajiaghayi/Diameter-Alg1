import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_CoinHPJ_A

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG14

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b3
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-- Deterministic `coinTbl`-reading RAM subroutine matching `CG19.NodeAndHPJRAMOps.evalHPJCenterStmt`.
Uses dedicated word scratch table `scrW := TW - 1`, reads points from `ptsRTbl = 1` and pre-drawn
bits from `coinTbl = 5`, and writes `(o, s)` directly to `engRealTbl[16 .. 16 + d]`. -/
noncomputable def evalHPJCenterStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (TW : ℕ) (cp : ChainParams d params h) (arrTbl : ℕ) (aOR aLR cOR : ℤ) : ArithRAMStmt :=
  let scrW := TW - 1
  let K_base := 10 + cp.N_samp + cp.B_walk
  let baseOffE := IntExpr.add (.readHeap scrW (.lit 2))
    (.mul (.readHeap scrW (.lit 3)) (.lit (cp.q_idx : ℤ)))
  .seq (.writeWordHeap scrW (.lit 0) (.readHeap engScrTbl (.lit aOR)))
  (.seq (.writeWordHeap scrW (.lit 1) (.readHeap engScrTbl (.lit aLR)))
  (.seq (.writeWordHeap scrW (.lit 2) (.readHeap engScrTbl (.lit cOR)))
  (.seq (forLoopStmt scrW 3 cp.N_samp
          (.seq (decodeBitsHeapStmt scrW baseOffE cp.q_idx)
                (.writeWordHeap scrW (.add (.lit 10) (.readHeap scrW (.lit 3)))
                  (.readHeap arrTbl
                    (.add (.readHeap scrW (.lit 0))
                          (.mod (.readHeap scrW (.lit 5)) (.readHeap scrW (.lit 1))))))))
  (.seq (forLoopStmt scrW 3 cp.B_walk
          (.writeWordHeap scrW (.add (.lit ((10 + cp.N_samp : ℕ) : ℤ)) (.readHeap scrW (.lit 3)))
            (.readHeap coinTbl
              (.add (.readHeap scrW (.lit 2))
                    (.add (.lit ((cp.N_samp * cp.q_idx : ℕ) : ℤ)) (.readHeap scrW (.lit 3)))))))
  (.seq (freeWordRangeStmt scrW K_base (hpjHeadroom d cp.phiRat))
        (embedHPJStmt engRealTbl scrW ptsRTbl scrW 16 10 0 ((10 + cp.N_samp : ℕ) : ℤ)
          cp.N_samp cp.n cp.phiRat))))))

noncomputable def evalHPJCenterCost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  36 +
  (5 + cp.N_samp * (43 + 30 * cp.q_idx)) +
  (5 + 26 * cp.B_walk) +
  (5 + 14 * hpjHeadroom d cp.phiRat) +
  (15 * Nat.ceil (hpjOpBound d (cp.phiRat : ℝ)) + 16 * d + 40)

theorem evalHPJCenterCost_le_poly {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    evalHPJCenterCost cp ≤
      500 + 60 * cp.N_samp * (cp.q_idx + 1) + 40 * cp.B_walk + 60 * d +
        40 * (Nat.ceil hpjOpConst * (d + 1) ^ 10 * cp.P_hpj.k_phi ^ 3) := by
  unfold evalHPJCenterCost hpjHeadroom
  have h1 := hpjOpBound_ceil_le_poly cp
  have hs : cp.N_samp * (43 + 30 * cp.q_idx) ≤ 60 * cp.N_samp * (cp.q_idx + 1) := by
    calc cp.N_samp * (43 + 30 * cp.q_idx) ≤ cp.N_samp * (60 * (cp.q_idx + 1)) := Nat.mul_le_mul_left _ (by omega)
      _ = 60 * cp.N_samp * (cp.q_idx + 1) := by ring
  omega

theorem zeroRand_evalHPJCenter {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (TW : ℕ) (cp : ChainParams d params h) (arrTbl : ℕ) (aOR aLR cOR : ℤ) :
    ZeroRandStmt (evalHPJCenterStmt TW cp arrTbl aOR aLR cOR) := by
  unfold evalHPJCenterStmt
  exact .seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_forLoopStmt (.seq (zeroRand_decodeBitsHeapStmt _ _ _) (.writeWordHeap _ _ _)))
    (.seq (zeroRand_forLoopStmt (.writeWordHeap _ _ _))
    (.seq (zeroRand_freeWordRangeStmt _ _ _)
          (zeroRand_embedHPJStmt _ _ _ _ _ _ _ _ _ _ _))))))

/-! ### 5. Exact `evalHPJCenter_spec` Matching `CG19.NodeAndHPJRAMOps` -/

theorem evalHPJCenter_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h)
    {TW BW TR BR : ℕ}
    (hTW : 10 ≤ TW) (hTR : 3 ≤ TR) (hBR_eng : d + 32 ≤ BR)
    (hBW_hpj : hpjWordCap cp ≤ BW)
    {SlotsReady : ArithRAMMemory → Prop}
    (slotsReady_ext : ∀ (m₁ m₂ : ArithRAMMemory),
      SlotsReady m₁ →
      (∀ t, 9 ≤ t → t < TW - 1 → ∀ i, wRead m₂ t i = wRead m₁ t i) →
      (∀ t, 3 ≤ t → t < TR → ∀ i, rRead m₂ t i = rRead m₁ t i) →
      SlotsReady m₂)
    {EncNode : MNode cp → ℕ → ArithRAMMemory → Prop}
    (encNode_ext : ∀ (mn : MNode cp) (slot : ℕ) (m₁ m₂ : ArithRAMMemory),
      EncNode mn slot m₁ →
      (∀ t, 9 ≤ t → t < TW - 1 → ∀ i, wRead m₂ t i = wRead m₁ t i) →
      (∀ t, 3 ≤ t → t < TR → ∀ i, rRead m₂ t i = rRead m₁ t i) →
      (∀ x ∈ mn.nd.curSet, x < cp.n → ∀ c : Fin d,
        rRead m₂ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) =
          rRead m₁ ptsRTbl (((x * d + c.val : ℕ) : ℤ))) →
      EncNode mn slot m₂)
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (arr : List ℕ)
    (arrTbl : ℕ) (arrOff : ℤ) (coinOff : ℕ) (ctrBits : Fin cp.B_ctr → Bool)
    (aOR aLR cOR : ℤ)
    (harrT : arrTbl < 8) (harr1 : 1 ≤ arr.length) (_harrN : arr.length ≤ cp.n)
    (harr_lt : ∀ x ∈ arr, x < cp.n)
    (_haO0 : 0 ≤ arrOff) (_haOB : arrOff + (arr.length : ℤ) ≤ (BW : ℤ))
    (_hcOff : coinOff + cp.B_ctr ≤ cp.B_STEP)
    (_haOR0 : 0 ≤ aOR) (_haOR64 : aOR < 64)
    (_haLR0 : 0 ≤ aLR) (_haLR64 : aLR < 64)
    (_hcOR0 : 0 ≤ cOR) (_hcOR64 : cOR < 64)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hsr₀ : SlotsReady m₀)
    (hr_aOR : wRead m₀ engScrTbl aOR = arrOff)
    (hr_aLR : wRead m₀ engScrTbl aLR = (arr.length : ℤ))
    (hr_cOR : wRead m₀ engScrTbl cOR = (coinOff : ℤ))
    (harr_mem : ∀ i (hi : i < arr.length), wRead m₀ arrTbl (arrOff + (i : ℤ)) = (arr[i]'hi : ℤ))
    (hpts_mem : ∀ x ∈ arr, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hcoins : ∀ k : Fin cp.B_ctr, wRead m₀ coinTbl ((coinOff : ℤ) + (k.val : ℤ)) =
      if ctrBits k then 1 else 0) :
    let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts arr
      (bitsToCenterSeedEquiv cp ctrBits)
    ExecDet TW BW TR BR inp (evalHPJCenterStmt TW cp arrTbl aOR aLR cOR) m₀
      (fun m₁ =>
        SlotsReady m₁ ∧
        (∀ c : Fin d, rRead m₁ engRealTbl (16 + (c.val : ℤ)) = euclideanCoord os.1 c) ∧
        rRead m₁ engRealTbl (16 + (d : ℤ)) = os.2 ∧
        (∀ mn' s', s' < M_slots cp → EncNode mn' s' m₀ → EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ t < 2, ∀ i, rRead m₁ t i = rRead m₀ t i) ∧
        rRead m₁ engRealTbl 0 = rRead m₀ engRealTbl 0)
      (evalHPJCenterCost cp) := by
  intro os
  let scrW := TW - 1
  let K_base := 10 + cp.N_samp + cp.B_walk
  let cw := bitsToCenterSeedEquiv cp ctrBits
  have hscrW : scrW < TW := by dsimp [scrW]; omega
  have hne_engScr : engScrTbl ≠ scrW := by dsimp [engScrTbl, scrW]; omega
  have hne_coin : coinTbl ≠ scrW := by dsimp [coinTbl, scrW]; omega
  have hne_arr : arrTbl ≠ scrW := by dsimp [scrW]; omega
  have hBW_base : K_base + hpjHeadroom d cp.phiRat ≤ BW := by
    simpa [hpjWordCap, K_base] using hBW_hpj
  have hBW10 : 10 ≤ BW := by dsimp [K_base] at hBW_base; omega
  -- Coin-slice decomposition of `cw = bitsToCenterSeedEquiv cp ctrBits`
  let sBits : Fin cp.N_samp → Fin cp.q_idx → Bool := fun k b =>
    ctrBits ⟨k.val * cp.q_idx + b.val, by
      have h1 : k.val * cp.q_idx + b.val < cp.N_samp * cp.q_idx := by
        calc k.val * cp.q_idx + b.val < k.val * cp.q_idx + cp.q_idx := Nat.add_lt_add_left b.isLt _
          _ = (k.val + 1) * cp.q_idx := by ring
          _ ≤ cp.N_samp * cp.q_idx := Nat.mul_le_mul_right _ k.isLt
      exact lt_of_lt_of_le h1 (Nat.le_add_right _ _)⟩
  have hsBits_eq : ∀ k : Fin cp.N_samp, cw.1 k = bitsFnToFin cp.q_idx (sBits k) := fun _ => rfl
  have hsBits_mem : ∀ (k : Fin cp.N_samp) (b : Fin cp.q_idx),
      wRead m₀ coinTbl (((coinOff : ℤ) + (k.val : ℤ) * (cp.q_idx : ℤ)) + (b.val : ℤ)) =
        if sBits k b then 1 else 0 := by
    intro k b
    have hk : k.val * cp.q_idx + b.val < cp.B_ctr := by
      have h1 : k.val * cp.q_idx + b.val < cp.N_samp * cp.q_idx := by
        calc k.val * cp.q_idx + b.val < k.val * cp.q_idx + cp.q_idx := Nat.add_lt_add_left b.isLt _
          _ = (k.val + 1) * cp.q_idx := by ring
          _ ≤ cp.N_samp * cp.q_idx := Nat.mul_le_mul_right _ k.isLt
      exact lt_of_lt_of_le h1 (Nat.le_add_right _ _)
    have hm := hcoins ⟨k.val * cp.q_idx + b.val, hk⟩
    have hidx : (coinOff : ℤ) + (k.val : ℤ) * (cp.q_idx : ℤ) + (b.val : ℤ) =
        (coinOff : ℤ) + ((k.val * cp.q_idx + b.val : ℕ) : ℤ) := by push_cast; ring
    rw [hidx]; exact hm
  have hwBits_mem : ∀ j : Fin cp.B_walk,
      wRead m₀ coinTbl ((coinOff : ℤ) + (((cp.N_samp * cp.q_idx : ℕ) : ℤ) + (j.val : ℤ))) =
        if cw.2 j then 1 else 0 := by
    intro j
    have hm := hcoins ⟨cp.N_samp * cp.q_idx + j.val, Nat.add_lt_add_left j.isLt _⟩
    have hidx : (coinOff : ℤ) + (((cp.N_samp * cp.q_idx : ℕ) : ℤ) + (j.val : ℤ)) =
        (coinOff : ℤ) + ((cp.N_samp * cp.q_idx + j.val : ℕ) : ℤ) := by push_cast; ring
    rw [hidx]; simpa [cw, bitsToCenterSeedEquiv] using hm
  let ω_fin : Fin cp.N_samp → Fin cp.n := fun k =>
    let idx := (cw.1 k).val % arr.length
    have hidx : idx < arr.length := Nat.mod_lt _ harr1
    ⟨arr[idx]'hidx, harr_lt _ (List.getElem_mem hidx)⟩
  let cL1 := 5 + cp.N_samp * (43 + 30 * cp.q_idx)
  let cL2 := 5 + 26 * cp.B_walk
  let cFree := 5 + 14 * hpjHeadroom d cp.phiRat
  let cEmb := 15 * Nat.ceil (hpjOpBound d (cp.phiRat : ℝ)) + 16 * d + 40
  unfold evalHPJCenterStmt evalHPJCenterCost
  -- Step 1: Copy `aOR, aLR, cOR` into `scrW[0..2]`
  refine ExecDet.seq' (24 + cL1 + cL2 + cFree + cEmb)
    (ExecDet.wWrite (C := 12) inp scrW (.lit 0) (.readHeap engScrTbl (.lit aOR)) 0 arrOff
      hfp₀ hscrW (by omega) (by omega) rfl (by simp [evalIntExpr]; exact hr_aOR)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mA hmA hfpA; subst hmA
  refine ExecDet.seq' (12 + cL1 + cL2 + cFree + cEmb)
    (ExecDet.wWrite (C := 12) inp scrW (.lit 1) (.readHeap engScrTbl (.lit aLR)) 1 (arr.length : ℤ)
      hfpA hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change wRead _ engScrTbl aLR = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_engScr)]; exact hr_aLR)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mB hmB hfpB; subst hmB
  refine ExecDet.seq' (cL1 + cL2 + cFree + cEmb)
    (ExecDet.wWrite (C := 12) inp scrW (.lit 2) (.readHeap engScrTbl (.lit cOR)) 2 (coinOff : ℤ)
      hfpB hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change wRead _ engScrTbl cOR = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_engScr),
              wRead_wWrite_of_ne _ _ (Or.inl hne_engScr)]; exact hr_cOR)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mC hmC hfpC; subst hmC
  set m_hdr := H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ scrW 0 arrOff) scrW 1 (arr.length : ℤ))
                scrW 2 (coinOff : ℤ)
  -- Step 2: Loop 1 (`k < cp.N_samp`) populating `scrW[10 .. 10 + cp.N_samp - 1]`
  let Inv1 : ℕ → ArithRAMMemory → Prop := fun K m =>
    wRead m scrW 0 = arrOff ∧
    wRead m scrW 1 = (arr.length : ℤ) ∧
    wRead m scrW 2 = (coinOff : ℤ) ∧
    (∀ k < K, ∀ hk : k < cp.N_samp, wRead m scrW (10 + (k : ℤ)) = ((ω_fin ⟨k, hk⟩).val : ℤ)) ∧
    (∀ t, t ≠ scrW → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ t i, rRead m t i = rRead m₀ t i)
  let baseOffE := IntExpr.add (.readHeap scrW (.lit 2))
    (.mul (.readHeap scrW (.lit 3)) (.lit (cp.q_idx : ℤ)))
  have hLoop1 : ExecDet TW BW TR BR inp
      (forLoopStmt scrW 3 cp.N_samp
        (.seq (decodeBitsHeapStmt scrW baseOffE cp.q_idx)
              (.writeWordHeap scrW (.add (.lit 10) (.readHeap scrW (.lit 3)))
                (.readHeap arrTbl
                  (.add (.readHeap scrW (.lit 0))
                        (.mod (.readHeap scrW (.lit 5)) (.readHeap scrW (.lit 1))))))))
      m_hdr (Inv1 cp.N_samp) cL1 := by
    refine (ExecDet.forLoop scrW 3 cp.N_samp _ Inv1 (37 + 30 * cp.q_idx)
      hfpC hscrW (by omega) (by omega) ?_ ?_).mono (fun _ hI _ => hI) (le_of_eq (by dsimp [cL1]; ring))
    · simp only [m_hdr]
      refine ⟨?_, ?_, ?_, fun _ hk => absurd hk (Nat.not_lt_zero _),
        fun t ht _ => by iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)],
        fun _ _ => rfl⟩
      · iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact wRead_wWrite_self _ _ _ _
      · iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact wRead_wWrite_self _ _ _ _
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact wRead_wWrite_self _ _ _ _
    · intro k hk m ⟨hr0, hr1, hr2, hprev, hwt, hr⟩ hctr3 hfpm
      refine ExecDet.seq' 20
        (exec_decodeBitsHeapStmt inp scrW baseOffE ((coinOff : ℤ) + (k : ℤ) * (cp.q_idx : ℤ))
          cp.q_idx (sBits ⟨k, hk⟩) hfpm hscrW hne_coin hBW10
          (by simp [baseOffE, intExprOps])
          (fun m' hwt' hws' => by
            simp only [baseOffE, evalIntExpr]
            change wRead m' scrW 2 + wRead m' scrW 3 * (cp.q_idx : ℤ) = _
            rw [hws' 2 (by omega) (by omega), hws' 3 (by omega) (by omega), hr2, hctr3])
          (fun b => (hwt coinTbl hne_coin _).trans (hsBits_mem ⟨k, hk⟩ b)))
        (by omega) ?_
      intro m_dec ⟨hr5, hwt_d, hws_d, hr_d⟩ hfp_dec
      rw [← hsBits_eq ⟨k, hk⟩] at hr5
      have hd0 : wRead m_dec scrW 0 = arrOff := (hws_d 0 (by omega) (by omega)).trans hr0
      have hd1 : wRead m_dec scrW 1 = (arr.length : ℤ) := (hws_d 1 (by omega) (by omega)).trans hr1
      have hd2 : wRead m_dec scrW 2 = (coinOff : ℤ) := (hws_d 2 (by omega) (by omega)).trans hr2
      have hd3 : wRead m_dec scrW 3 = (k : ℤ) := (hws_d 3 (by omega) (by omega)).trans hctr3
      have hmod_eq : ((cw.1 ⟨k, hk⟩).val : ℤ) % (arr.length : ℤ) =
          (((cw.1 ⟨k, hk⟩).val % arr.length : ℕ) : ℤ) := by norm_cast
      have harr_val : wRead m_dec arrTbl (arrOff + (((cw.1 ⟨k, hk⟩).val : ℤ) % (arr.length : ℤ))) =
          ((ω_fin ⟨k, hk⟩).val : ℤ) := by
        rw [hwt_d arrTbl hne_arr, hwt arrTbl hne_arr, hmod_eq]
        exact harr_mem _ (Nat.mod_lt _ harr1)
      refine ExecDet.wWrite inp scrW (.add (.lit 10) (.readHeap scrW (.lit 3)))
        (.readHeap arrTbl (.add (.readHeap scrW (.lit 0))
          (.mod (.readHeap scrW (.lit 5)) (.readHeap scrW (.lit 1)))))
        (10 + (k : ℤ)) ((ω_fin ⟨k, hk⟩).val : ℤ)
        hfp_dec hscrW (by omega) (by dsimp [K_base] at hBW_base; omega)
        (by simp only [evalIntExpr]; change 10 + wRead m_dec scrW 3 = _; rw [hd3])
        (by simp only [evalIntExpr]
            change wRead m_dec arrTbl (wRead m_dec scrW 0 + (wRead m_dec scrW 5 % wRead m_dec scrW 1)) = _
            rw [hd0, hr5, hd1, harr_val])
        (by simp [intExprOps]) ?_
      refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hd3,
        ?_, ?_, ?_, fun j hj hjn => ?_, fun t ht i => ?_, fun t i => (hr_d t i).trans (hr t i)⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hd0
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hd1
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hd2
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hj with hlt | rfl
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hws_d _ (by omega) (by omega)]
          exact hprev j hlt hjn
        · exact wRead_wWrite_self _ _ _ _
      · rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
        exact (hwt_d t ht i).trans (hwt t ht i)
  refine ExecDet.seq' (cL2 + cFree + cEmb) hLoop1 (by omega) ?_
  intro mL1 ⟨_, _, hr2_L1, hsamp_L1, hwt_L1, hr_L1⟩ hfpL1
  -- Step 3: Loop 2 (`j < cp.B_walk`) populating `scrW[10 + cp.N_samp .. K_base - 1]`
  let Inv2 : ℕ → ArithRAMMemory → Prop := fun J m =>
    wRead m scrW 2 = (coinOff : ℤ) ∧
    (∀ k : Fin cp.N_samp, wRead m scrW (10 + (k.val : ℤ)) = ((ω_fin k).val : ℤ)) ∧
    (∀ j < J, ∀ hj : j < cp.B_walk,
      wRead m scrW (((10 + cp.N_samp : ℕ) : ℤ) + (j : ℤ)) = if cw.2 ⟨j, hj⟩ then 1 else 0) ∧
    (∀ t, t ≠ scrW → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ t i, rRead m t i = rRead m₀ t i)
  have hLoop2 : ExecDet TW BW TR BR inp
      (forLoopStmt scrW 3 cp.B_walk
        (.writeWordHeap scrW (.add (.lit ((10 + cp.N_samp : ℕ) : ℤ)) (.readHeap scrW (.lit 3)))
          (.readHeap coinTbl
            (.add (.readHeap scrW (.lit 2))
                  (.add (.lit ((cp.N_samp * cp.q_idx : ℕ) : ℤ)) (.readHeap scrW (.lit 3)))))))
      mL1 (Inv2 cp.B_walk) cL2 := by
    refine (ExecDet.forLoop scrW 3 cp.B_walk _ Inv2 20 hfpL1 hscrW (by omega) (by omega) ?_ ?_).mono
      (fun _ hI _ => hI) (by dsimp [cL2]; omega)
    · refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hr2_L1,
        fun k => by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hsamp_L1 k.val k.isLt k.isLt,
        fun _ hj => absurd hj (Nat.not_lt_zero _),
        fun t ht i => (wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (hwt_L1 t ht i),
        hr_L1⟩
    · intro j hj m ⟨hr2_m, hsamp_m, hprev_w, hwt_m, hr_m⟩ hctr3 hfpm
      have hbit_j : wRead m coinTbl
          ((coinOff : ℤ) + (((cp.N_samp * cp.q_idx : ℕ) : ℤ) + (j : ℤ))) =
          if cw.2 ⟨j, hj⟩ then 1 else 0 :=
        (hwt_m coinTbl hne_coin _).trans (hwBits_mem ⟨j, hj⟩)
      refine ExecDet.wWrite inp scrW
        (.add (.lit ((10 + cp.N_samp : ℕ) : ℤ)) (.readHeap scrW (.lit 3)))
        (.readHeap coinTbl
          (.add (.readHeap scrW (.lit 2))
                (.add (.lit ((cp.N_samp * cp.q_idx : ℕ) : ℤ)) (.readHeap scrW (.lit 3)))))
        (((10 + cp.N_samp : ℕ) : ℤ) + (j : ℤ)) (if cw.2 ⟨j, hj⟩ then 1 else 0)
        hfpm hscrW (by omega) (by dsimp [K_base] at hBW_base; omega)
        (by simp only [evalIntExpr]; change ((10 + cp.N_samp : ℕ) : ℤ) + wRead m scrW 3 = _; rw [hctr3])
        (by simp only [evalIntExpr]
            change wRead m coinTbl (wRead m scrW 2 + (((cp.N_samp * cp.q_idx : ℕ) : ℤ) + wRead m scrW 3)) = _
            rw [hr2_m, hctr3, hbit_j])
        (by simp [intExprOps]) ?_
      refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctr3,
        ?_, fun k => ?_, fun j' hj' hjb => ?_, fun t ht i => ?_, hr_m⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hr2_m
      · have := k.isLt
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hsamp_m k
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hj' with hlt | rfl
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hprev_w j' hlt hjb
        · exact wRead_wWrite_self _ _ _ _
      · rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
        exact hwt_m t ht i
  refine ExecDet.seq' (cFree + cEmb) hLoop2 (by omega) ?_
  intro mL2 ⟨_, hsamp_L2, hwalk_L2, hwt_L2, hr_L2⟩ hfpL2
  -- Step 4: Reclaim `hpjHeadroom d cp.phiRat` word cells in `scrW` so `hScap` holds unconditionally
  refine ExecDet.seq' cEmb
    (exec_freeWordRangeStmt inp scrW K_base (hpjHeadroom d cp.phiRat)
      hfpL2 hscrW (by dsimp [K_base]; omega) hBW_base)
    (by omega) ?_
  intro mFree ⟨hcap_free, hwt_free, hws_free, hr_free⟩ hfpFree
  have hwt_F0 : ∀ t, t ≠ scrW → ∀ i, wRead mFree t i = wRead m₀ t i :=
    fun t ht i => (hwt_free t ht i).trans (hwt_L2 t ht i)
  have hr_F0 : ∀ t i, rRead mFree t i = rRead m₀ t i :=
    fun t i => (hr_free t i).trans (hr_L2 t i)
  -- Step 5: Execute `H3b3.embedHPJStmt` writing `(o, s)` directly to `engRealTbl[16 .. 16 + d]`
  let poolPt : Fin cp.n → EuclideanSpace ℝ (Fin d) := fun x =>
    (WithLp.equiv 2 (Fin d → ℝ)).symm (fun c => rRead m₀ ptsRTbl (((x.val * d + c.val : ℕ) : ℤ)))
  have hpool_eq : ∀ j : Fin (2 ^ cp.P_hpj.q),
      poolPt (ω_fin ⟨j.val, lt_of_lt_of_le j.isLt cp.hmN⟩) =
        pts (arr[(cw.1 ⟨j.val, lt_of_lt_of_le j.isLt cp.hmN⟩).val % arr.length]'(Nat.mod_lt _ harr1)) := by
    intro j
    set a := arr[(cw.1 ⟨j.val, lt_of_lt_of_le j.isLt cp.hmN⟩).val % arr.length]'(Nat.mod_lt _ harr1)
    ext c
    exact hpts_mem a (List.getElem_mem _) c
  have hemb :=
    exec_embedHPJStmt TW BW TR BR scrW engRealTbl scrW ptsRTbl scrW
      16 10 0 ((10 + cp.N_samp : ℕ) : ℤ)
      inp mFree cp.phiRat cp.hφ0 cp.hφ1 cp.P_hpj cp.hP_hpj_eq cp.hP_hpj
      cp.n (by have := cp.hn; omega) poolPt cp.N_samp cp.hmN ω_fin cw.2 cEmb
      hfpFree (by dsimp [engRealTbl]; omega) (by omega) (by omega)
      (fun k => by
        have hk_nat : 10 + k.val < K_base := by
          dsimp only [K_base]; have := k.isLt; omega
        have hk_int : (10 : ℤ) + (k.val : ℤ) < (K_base : ℤ) := by exact_mod_cast hk_nat
        rw [hws_free _ (by omega) hk_int]
        exact hsamp_L2 k)
      (fun x c => by
        rw [hr_F0 ptsRTbl _, zero_add]
        have hidx : (x.val : ℤ) * (d : ℤ) + (c.val : ℤ) = ((x.val * d + c.val : ℕ) : ℤ) := by
          push_cast; ring
        rw [hidx]; rfl)
      (fun j => by
        have hj_lt : j.val < cp.B_walk := j.isLt
        have hj_nat : (10 + cp.N_samp) + j.val < K_base := by
          dsimp only [K_base]; omega
        have hj_int : (((10 + cp.N_samp : ℕ) : ℤ) + (j.val : ℤ)) < (K_base : ℤ) := by
          exact_mod_cast hj_nat
        rw [hws_free _ (by omega) hj_int]
        exact hwalk_L2 j.val hj_lt hj_lt)
      (by unfold hpjHeadroom at hcap_free; omega)
      le_rfl
  let z_out : EuclideanSpace ℝ (Fin (d + 1)) :=
    radonWalkOutput (d + 1) cp.P_hpj.q cp.P_hpj.L
      (fun j : Fin (2 ^ cp.P_hpj.q) => paraboloidLift (poolPt (ω_fin ⟨j.val, lt_of_lt_of_le j.isLt cp.hmN⟩)))
      cw.2
  have hz_eq : (liftedBase z_out, liftedHeight z_out) = os := by
    have hfun : (fun j : Fin (2 ^ cp.P_hpj.q) =>
        paraboloidLift (poolPt (ω_fin ⟨j.val, lt_of_lt_of_le j.isLt cp.hmN⟩))) =
      (fun j : Fin (2 ^ cp.P_hpj.q) =>
        paraboloidLift (pts (arr[(cw.1 ⟨j.val, lt_of_lt_of_le j.isLt cp.hmN⟩).val % arr.length]'(Nat.mod_lt _ harr1)))) :=
      funext (fun j => congrArg paraboloidLift (hpool_eq j))
    dsimp only [os, evalHPJCenter, z_out]
    rw [dif_pos harr1, hfun]
  refine ExecDet.mono hemb ?_ le_rfl
  intro m₁ ⟨hpr₁, hz_m₁, hout_m₁, _⟩ _
  have hw_m1_0 : ∀ t, t ≠ scrW → ∀ i, wRead m₁ t i = wRead m₀ t i :=
    fun t ht i => (hpr₁.1 t ht i).trans (hwt_F0 t ht i)
  have hr_m1_0 : ∀ t, t ≠ engRealTbl → ∀ i, rRead m₁ t i = rRead m₀ t i :=
    fun t ht i => (hpr₁.2 t ht i).trans (hr_F0 t i)
  have hw_slots : ∀ t, 9 ≤ t → t < TW - 1 → ∀ i, wRead m₁ t i = wRead m₀ t i :=
    fun t _ ht_lt i => hw_m1_0 t (by dsimp [scrW]; omega) i
  have hr_slots : ∀ t, 3 ≤ t → t < TR → ∀ i, rRead m₁ t i = rRead m₀ t i :=
    fun t ht3 _ i => hr_m1_0 t (by dsimp [engRealTbl]; omega) i
  rw [← hz_eq]
  refine ⟨slotsReady_ext m₀ m₁ hsr₀ hw_slots hr_slots,
    fun c => ?_,
    ?_,
    fun mn' s' _ he0 => encNode_ext mn' s' m₀ m₁ he0 hw_slots hr_slots
      (fun _ _ _ _ => hr_m1_0 ptsRTbl (by decide) _),
    fun t ht9 i => hw_m1_0 t (by dsimp [scrW]; omega) i,
    fun t ht2 i => hr_m1_0 t (by dsimp [engRealTbl]; omega) i,
    (hout_m₁ 0 (Or.inl (by omega))).trans (hr_F0 engRealTbl 0)⟩
  · simpa using hz_m₁ ⟨c.val, Nat.lt_succ_of_lt c.isLt⟩
  · simpa using hz_m₁ (Fin.last d)

end UL.Proof.clm_9_1_explicit_tradeoff.CG14
