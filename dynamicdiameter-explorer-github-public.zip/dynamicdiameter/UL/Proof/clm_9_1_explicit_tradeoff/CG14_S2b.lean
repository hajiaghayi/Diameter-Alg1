import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_S2a
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.C14d2

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1

/-! ### 3. `findSome?` Prefix Helper & `stepStage2_spec` -/

private lemma list_findSome_split {α β : Type*} :
    ∀ (l : List α) (f : α → Option β) {y : β},
      l.findSome? f = some y →
      ∃ l₁ x l₂, l = l₁ ++ x :: l₂ ∧ f x = some y ∧ ∀ z ∈ l₁, f z = none
  | [], _, _, h => by simp at h
  | hd :: tl, f, y, h => by
      dsimp only [List.findSome?] at h
      cases hfx : f hd with
      | some b =>
          rw [hfx] at h
          injection h with hb; subst hb
          exact ⟨[], hd, tl, rfl, hfx, fun _ hm => absurd hm List.not_mem_nil⟩
      | none =>
          rw [hfx] at h
          rcases list_findSome_split tl f h with ⟨l₁, x, l₂, htl, hfx', hnone⟩
          refine ⟨hd :: l₁, x, l₂, by rw [htl]; rfl, hfx', fun z hz => ?_⟩
          rcases List.mem_cons.mp hz with rfl | hmem
          · exact hfx
          · exact hnone z hmem

private lemma finRange_findSome_first {N : ℕ} {β : Type*}
    (f : Fin N → Option β) {y : β}
    (h : (List.finRange N).findSome? f = some y) :
    ∃ x : Fin N, f x = some y ∧ ∀ r : Fin N, r.val < x.val → f r = none := by
  rcases list_findSome_split (List.finRange N) f h with ⟨l₁, x, l₂, heq, hfx, hnone⟩
  have hlen_tot : (List.finRange N).length = l₁.length + 1 + l₂.length := by
    rw [heq]; simp [ Nat.add_assoc, Nat.add_comm, Nat.add_left_comm ]
  have hl1_lt : l₁.length < (List.finRange N).length := by omega
  have hget_x : (List.finRange N)[l₁.length]'hl1_lt = x := by
    have hrhs : (l₁ ++ x :: l₂)[l₁.length]'(by simp) = x := by simp
    have hlhs : (List.finRange N)[l₁.length]'hl1_lt = (l₁ ++ x :: l₂)[l₁.length]'(by rw [← heq]; exact hl1_lt) := by
      congr 1
    exact hlhs.trans hrhs
  have hx_val : x.val = l₁.length := by
    rw [← hget_x]; simp
  refine ⟨x, hfx, fun r hr => ?_⟩
  have hr_l1 : r.val < l₁.length := by omega
  have hr_tot : r.val < (List.finRange N).length := by omega
  have hr_eq_get : (List.finRange N)[r.val]'hr_tot = r := by simp
  have hr_in_l1 : r ∈ l₁ := by
    rw [← hr_eq_get]
    have h1 : (List.finRange N)[r.val]'hr_tot = (l₁ ++ x :: l₂)[r.val]'(by rw [← heq]; exact hr_tot) := by
      congr 1
    rw [h1, List.getElem_append_left hr_l1]
    exact List.getElem_mem hr_l1
  exact hnone r hr_in_l1

private lemma finRange_findSome_none {N : ℕ} {β : Type*}
    (f : Fin N → Option β)
    (h : (List.finRange N).findSome? f = none) :
    ∀ r : Fin N, f r = none := by
  intro r
  exact List.findSome?_eq_none_iff.mp h r (List.mem_finRange r)

theorem stepStage2_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {P' : DynamicPointSet d} (hP' : P'.WellFormed cp.n)
    {st₁ : ChainEngineState cp} (hwf₁ : PostStage1WF cp P' st₁)
    (ω₂ : Stage2Coins cp) :
    let st₂ := stepStage2 cp st₁ ω₂
    PostStage2WF cp P' st₂ ∧
    (ChainEngineGood cp hh0 hh1 st₁ →
     GoodStage2Coins cp hh0 hh1 st₁ ω₂ →
     ChainEngineGood cp hh0 hh1 st₂) := by
  intro st₂
  dsimp only [st₂]
  rcases hwf₁ with ⟨hhp, hgt, hserv_len, hserv_cl, hjobs_wf, hleaf_wf⟩
  let actH := P'.activeHandles
  set pts := st₁.hp.coords
  -- Bound `actH.card ≤ cp.n` from `hhp` (`actList.Nodup`, `actList.toFinset = actH`, `nextFresh ≤ n`)
  have hact_n : actH.card ≤ cp.n := by
    rcases hhp with ⟨hnf_le, hact_nd, _, hact_set, _, _, hsum, _⟩
    dsimp only [actH]
    rw [← hact_set, List.toFinset_card_of_nodup hact_nd]
    omega
  -- Every serving node in `st₁` satisfies `16 * K_alpha d * age < birthSize`!
  have hserv_age16 : ∀ q (hq : q < st₁.serving.length),
      16 * K_alpha d * (st₁.serving[q]'hq).nd.age < (st₁.serving[q]'hq).nd.birthSize := by
    intro q hq
    have hqD : q < cp.D_max := lt_of_lt_of_le hq hserv_len
    have hslot := hjobs_wf ⟨q, hqD⟩
    rw [dif_pos hq] at hslot
    have hMr : cp.B_scan < (st₁.serving[q]'hq).nd.birthSize :=
      (chainListInv_mem_birthSize actH st₁.serving hserv_cl _ (List.getElem_mem hq)).1
    cases hjb_eq : st₁.jobs ⟨q, hqD⟩ with
    | none =>
        dsimp only at hslot
        rw [hjb_eq] at hslot
        have hB1 := cp.sched_bounds.1
        have hmul4 : 4 * (16 * K_alpha d * (st₁.serving[q]'hq).nd.age) =
            64 * K_alpha d * (st₁.serving[q]'hq).nd.age := by ring
        omega
    | some jb =>
        dsimp only at hslot
        rw [hjb_eq] at hslot
        exact (suffixJobInvSlack_bounds le_rfl hMr hslot).2.1
  set outJobs : Fin cp.D_max → Option (SuffixJob cp ⊕ (List (MNode cp) × List ℕ × Bool)) := fun r =>
    if hr : r.val < st₁.serving.length then
      match st₁.jobs r with
      | none => none
      | some jb =>
          let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
            ω₂.1 ⟨r.val * cp.B_scan + j.val, by
              have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
                calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan :=
                      Nat.add_lt_add_left j.isLt _
                  _ = (r.val + 1) * cp.B_scan := by ring
                  _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
              exact Nat.lt_add_right _ this⟩
          some (advanceOneJob cp pts st₁.gt (st₁.serving[r.val]'hr) r jb bSeeds (ω₂.2 r.castSucc))
    else
      none
  -- Apply `advanceOneJob_spec` uniformly for any `r : Fin cp.D_max`, `hr`, `st₁.jobs r = some jb`
  have hjob_adv : ∀ (r : Fin cp.D_max) (hr : r.val < st₁.serving.length) (jb : SuffixJob cp),
      st₁.jobs r = some jb →
      let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
        ω₂.1 ⟨r.val * cp.B_scan + j.val, by
          have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
            calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan :=
                  Nat.add_lt_add_left j.isLt _
              _ = (r.val + 1) * cp.B_scan := by ring
              _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
          exact Nat.lt_add_right _ this⟩
      match advanceOneJob cp pts st₁.gt (st₁.serving[r.val]'hr) r jb bSeeds (ω₂.2 r.castSucc) with
      | Sum.inl jb' =>
          SuffixJobInv cp actH pts st₁.gt (foldResiduals pts actH (st₁.serving.take r.val))
            (st₁.serving[r.val]'hr) r.val jb' ∧
          (SuffixJobGood cp hh0 hh1 pts st₁.gt jb →
           s2JobGoodAt cp hh0 hh1 pts st₁.gt (st₁.serving[r.val]'hr) jb bSeeds (ω₂.2 r.castSucc) →
           SuffixJobGood cp hh0 hh1 pts st₁.gt jb')
      | Sum.inr (newSuf, newLeaf, newOv) =>
          r.val + newSuf.length ≤ cp.D_max ∧
          ChainListInv cp actH pts st₁.gt (foldResiduals pts actH (st₁.serving.take r.val)) newSuf ∧
          (∀ u ∈ newSuf, 128 * K_alpha d * u.nd.age < u.nd.birthSize) ∧
          (newOv = false →
            newLeaf.Nodup ∧
            newLeaf.toFinset = foldResiduals pts (foldResiduals pts actH (st₁.serving.take r.val)) newSuf ∧
            newLeaf.length ≤ cp.B_scan) ∧
          (ChainListGood cp hh0 hh1 pts st₁.gt (st₁.serving.take r.val) →
           (∀ mn ∈ st₁.serving.take r.val, 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize) →
           SuffixJobGood cp hh0 hh1 pts st₁.gt jb →
           s2JobGoodAt cp hh0 hh1 pts st₁.gt (st₁.serving[r.val]'hr) jb bSeeds (ω₂.2 r.castSucc) →
           newOv = false ∧ ChainListGood cp hh0 hh1 pts st₁.gt newSuf) := by
    intro r hr jb hjb_eq
    have hslot := hjobs_wf r
    rw [dif_pos hr] at hslot; dsimp only at hslot; rw [hjb_eq] at hslot
    rcases (chainListInv_getElem actH st₁.serving (Finset.Subset.refl _) hserv_cl).2 r.val hr
      with ⟨hS_sub, hanc_ln⟩
    exact advanceOneJob_spec h_lem_5_1 h_clm_7_3 hd he1 cp hh0 hh1 hact_n hgt
      (List.length_take_le' r.val st₁.serving |>.trans hserv_len)
      (chainListInv_take r.val actH st₁.serving hserv_cl) rfl hS_sub hanc_ln
      (hserv_age16 r.val hr) r (List.length_take_of_le (Nat.le_of_lt hr)) hslot _ _
  let commitFn : Fin cp.D_max → Option (Fin cp.D_max × List (MNode cp) × List ℕ × Bool) := fun r =>
    match outJobs r with
    | some (Sum.inr (suf, lf, ov)) => some (r, suf, lf, ov)
    | _ => none
  let inlJob : Fin cp.D_max → Option (SuffixJob cp) := fun r =>
    match outJobs r with
    | some (Sum.inl jb') => some jb'
    | _ => none
  let step2Body (fc : Option (Fin cp.D_max × List (MNode cp) × List ℕ × Bool))
      (jInl : Fin cp.D_max → Option (SuffixJob cp)) : ChainEngineState cp :=
    match fc with
    | some (r₀, newSuf, newLeaf, newOv) =>
        { st₁ with
          serving := st₁.serving.take r₀.val ++ newSuf
          jobs := fun r => if r.val < r₀.val then jInl r else none
          leafArr := newLeaf
          leafOverflow := newOv }
    | none =>
        if !st₁.leafOverflow && decide (cp.B_scan < st₁.leafArr.length) then
          if st₁.serving.length < cp.D_max && decide (st₁.leafArr.length ≤ cp.B_scan + 1) then
            let leafCtr := ω₂.2 (Fin.last cp.D_max)
            let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts st₁.leafArr leafCtr
            let P₀_uid := st₁.leafArr.toFinset.image st₁.gt.uidOf
            let bs0 := BuildState.init cp st₁.leafArr.length st₁.leafArr os.1 os.2 P₀_uid
            let steps := min st₁.leafArr.length (cp.B_scan + 1)
            let leafSeeds : Fin steps → OpSeed cp := fun j =>
              ω₂.1 ⟨cp.D_max * cp.B_scan + j.val, by
                have hj : j.val < cp.B_scan + 1 := lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)
                exact Nat.add_lt_add_left hj _⟩
            let bsDone := advanceBuildLoop cp pts steps leafSeeds bs0
            let u_leaf := bsDone.curNode
            if u_leaf.resArr.length ≤ cp.B_scan then
              { st₁ with serving := st₁.serving ++ [u_leaf], jobs := jInl, leafArr := u_leaf.resArr, leafOverflow := false }
            else
              { st₁ with serving := st₁.serving ++ [u_leaf], jobs := jInl, leafArr := [], leafOverflow := true }
          else
            { st₁ with jobs := jInl, leafArr := [], leafOverflow := true }
        else
          { st₁ with jobs := jInl }
  have hstep2_eq : stepStage2 cp st₁ ω₂ =
      step2Body ((List.finRange cp.D_max).findSome? commitFn) inlJob := by
    unfold stepStage2
    dsimp only
    generalize hscrut : List.findSome? _ (List.finRange cp.D_max) = fc
    have hfc_eq : fc = (List.finRange cp.D_max).findSome? commitFn := by
      rw [← hscrut]; rfl
    rw [← hfc_eq]
    cases fc with
    | some q =>
        rcases q with ⟨r₀, s1, s2, s3⟩
        dsimp only [step2Body]
        congr 1
    | none =>
        dsimp only [step2Body, pts]
        by_cases h1 : (!st₁.leafOverflow && decide (cp.B_scan < st₁.leafArr.length)) = true
        · rw [if_pos h1, if_pos h1]
          by_cases h2 : (st₁.serving.length < cp.D_max && decide (st₁.leafArr.length ≤ cp.B_scan + 1)) = true
          · rw [if_pos h2, if_pos h2]
            split_ifs <;> congr 1
          · rw [if_neg h2, if_neg h2]
            congr 1
        · rw [if_neg h1, if_neg h1]
          congr 1
  rw [hstep2_eq]
  dsimp only [step2Body, inlJob]
  cases hfc : (List.finRange cp.D_max).findSome? commitFn with
  | some quad =>
      rcases quad with ⟨r₀, newSuf, newLeaf, newOv⟩
      dsimp only
      rcases finRange_findSome_first commitFn hfc with ⟨r_star, hcf_eq, hbefore_none⟩
      have hr_star_eq : r_star = r₀ := by
        dsimp only [commitFn] at hcf_eq
        cases ho : outJobs r_star with
        | none => rw [ho] at hcf_eq; cases hcf_eq
        | some s =>
            cases s with
            | inl _ => rw [ho] at hcf_eq; cases hcf_eq
            | inr t => rw [ho] at hcf_eq; injection hcf_eq with ht; exact Prod.mk.inj ht |>.1
      subst r_star
      -- Extract `hr₀ : r₀.val < st₁.serving.length` and `st₁.jobs r₀ = some jb₀`
      have hout_r₀ : outJobs r₀ = some (Sum.inr (newSuf, newLeaf, newOv)) := by
        dsimp only [commitFn] at hcf_eq
        cases ho : outJobs r₀ with
        | none => rw [ho] at hcf_eq; cases hcf_eq
        | some s =>
            cases s with
            | inl _ => rw [ho] at hcf_eq; cases hcf_eq
            | inr t =>
                rw [ho] at hcf_eq
                rcases t with ⟨s1, s2, s3⟩
                injection hcf_eq with ht
                rcases Prod.mk.inj ht with ⟨_, hrest⟩
                rcases Prod.mk.inj hrest with ⟨rfl, hrest2⟩
                rcases Prod.mk.inj hrest2 with ⟨rfl, rfl⟩
                rfl
      have hr₀ : r₀.val < st₁.serving.length := by
        by_contra hnot
        dsimp only [outJobs] at hout_r₀; rw [dif_neg hnot] at hout_r₀; cases hout_r₀
      obtain ⟨jb₀, hjb₀, hadv_r₀⟩ : ∃ jb₀, st₁.jobs r₀ = some jb₀ ∧
          advanceOneJob cp pts st₁.gt (st₁.serving[r₀.val]'hr₀) r₀ jb₀ _ (ω₂.2 r₀.castSucc) =
            Sum.inr (newSuf, newLeaf, newOv) := by
        dsimp only [outJobs] at hout_r₀
        rw [dif_pos hr₀] at hout_r₀
        cases hj : st₁.jobs r₀ with
        | none => rw [hj] at hout_r₀; cases hout_r₀
        | some jb₀ =>
            rw [hj] at hout_r₀
            injection hout_r₀ with hadv
            exact ⟨jb₀, rfl, hadv⟩
      have hspec_r₀ := hjob_adv r₀ hr₀ jb₀ hjb₀
      dsimp only at hspec_r₀
      rw [hadv_r₀] at hspec_r₀
      rcases hspec_r₀ with ⟨hr0_len, hcl_suf, hsuf_age128, hsuf_leaf, hsuf_gd⟩
      set serving₂ := st₁.serving.take r₀.val ++ newSuf
      have htake_len : (st₁.serving.take r₀.val).length = r₀.val :=
        List.length_take_of_le (Nat.le_of_lt hr₀)
      have hserv2_len : serving₂.length ≤ cp.D_max := by
        dsimp only [serving₂]; rw [List.length_append, htake_len]; exact hr0_len
      have hserv2_cl : ChainListInv cp actH pts st₁.gt actH serving₂ :=
        chainListInv_append actH (st₁.serving.take r₀.val) newSuf
          (chainListInv_take r₀.val actH st₁.serving hserv_cl) hcl_suf
      refine ⟨⟨hhp, hgt, hserv2_len, hserv2_cl, ?_, ?_⟩, fun ⟨hov1, hgd_s1, hgd_j1⟩ hs2_all => ?_⟩
      · -- Per-slot `PostStage2WF` after commit at `r₀`
        intro r
        by_cases hr2 : r.val < serving₂.length
        · rw [dif_pos hr2]; dsimp only
          by_cases hlt_r₀ : r.val < r₀.val
          · rw [if_pos hlt_r₀]
            have hr1 : r.val < st₁.serving.length := lt_trans hlt_r₀ hr₀
            have hget_eq : serving₂[r.val]'hr2 = st₁.serving[r.val]'hr1 := by
              dsimp only [serving₂]
              rw [List.getElem_append_left (by rw [htake_len]; exact hlt_r₀), List.getElem_take]
            have htake_r_eq : serving₂.take r.val = st₁.serving.take r.val := by
              dsimp only [serving₂]
              rw [List.take_append_of_le_length (by rw [htake_len]; exact Nat.le_of_lt hlt_r₀),
                  List.take_take, Nat.min_eq_left (Nat.le_of_lt hlt_r₀)]
            have hcf_none := hbefore_none r hlt_r₀
            cases hj1 : st₁.jobs r with
            | none =>
                have hout_none : outJobs r = none := by dsimp only [outJobs]; rw [dif_pos hr1, hj1]
                rw [hout_none, hget_eq]
                have hslot1 := hjobs_wf r
                rw [dif_pos hr1] at hslot1; dsimp only at hslot1; rw [hj1] at hslot1
                exact hslot1
            | some jb =>
                have hadv_r := hjob_adv r hr1 jb hj1
                dsimp only at hadv_r
                dsimp only [commitFn, outJobs] at hcf_none
                rw [dif_pos hr1, hj1] at hcf_none; dsimp only at hcf_none
                dsimp only [outJobs]
                rw [dif_pos hr1, hj1]; dsimp only
                cases hadv_eq : advanceOneJob cp pts st₁.gt (st₁.serving[r.val]'hr1) r jb _ (ω₂.2 r.castSucc) with
                | inl jb' =>
                    rw [hadv_eq] at hadv_r
                    dsimp only
                    rw [hget_eq, htake_r_eq]
                    exact hadv_r.1
                | inr trip =>
                    rcases trip with ⟨_, _, _⟩
                    rw [hadv_eq] at hcf_none; cases hcf_none
          · rw [if_neg hlt_r₀]; dsimp only
            -- `r.val ≥ r₀.val`: `serving₂[r.val]` belongs to `newSuf`, where `128 * K_alpha * age < birthSize`!
            have hmem_suf : serving₂[r.val]'hr2 ∈ newSuf := by
              dsimp only [serving₂]
              rw [List.getElem_append_right (by rw [htake_len]; omega)]
              exact List.getElem_mem _
            have h128 := hsuf_age128 _ hmem_suf
            have hmul2 : 2 * (64 * K_alpha d * (serving₂[r.val]'hr2).nd.age) =
                128 * K_alpha d * (serving₂[r.val]'hr2).nd.age := by ring
            dsimp only [serving₂] at h128 hmul2 ⊢
            omega
        · rw [dif_neg hr2]; dsimp only
          by_cases hlt_r₀ : r.val < r₀.val
          · exfalso; apply hr2; dsimp only [serving₂]; rw [List.length_append, htake_len]; omega
          · rw [if_neg hlt_r₀]
      · -- Leaf invariant when `newOv = false`
        intro hnov
        rcases hsuf_leaf hnov with ⟨hnd_lf, hset_lf, hlen_lf⟩
        refine ⟨hnd_lf, ?_, hlen_lf⟩
        dsimp only [serving₂]; rw [foldResiduals_append, hset_lf]
      · -- `ChainEngineGood` after commit at `r₀`
        have hpre_gd : ChainListGood cp hh0 hh1 pts st₁.gt (st₁.serving.take r₀.val) :=
          fun u hu => hgd_s1 u (List.mem_of_mem_take hu)
        have hpre_age16 : ∀ mn ∈ st₁.serving.take r₀.val, 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize := by
          intro mn hmn
          rcases List.mem_iff_getElem.mp (List.mem_of_mem_take hmn) with ⟨q, hq, rfl⟩
          exact Nat.le_of_lt (hserv_age16 q hq)
        rcases hsuf_gd hpre_gd hpre_age16 (hgd_j1 r₀ hr₀ jb₀ hjb₀) (hs2_all.1 r₀ hr₀ jb₀ hjb₀)
          with ⟨hnov_eq, hgd_suf⟩
        refine ⟨hnov_eq, ?_, ?_⟩
        · intro u hu
          rcases List.mem_append.mp hu with h1 | h2
          · exact hpre_gd u h1
          · exact hgd_suf u h2
        · intro r hr2 jb₂ hjb₂
          dsimp only at hjb₂
          by_cases hlt_r₀ : r.val < r₀.val
          · rw [if_pos hlt_r₀] at hjb₂
            have hr1 : r.val < st₁.serving.length := lt_trans hlt_r₀ hr₀
            dsimp only [outJobs] at hjb₂
            rw [dif_pos hr1] at hjb₂
            cases hj1 : st₁.jobs r with
            | none => rw [hj1] at hjb₂; cases hjb₂
            | some jb =>
                rw [hj1] at hjb₂; dsimp only at hjb₂
                have hadv_r := hjob_adv r hr1 jb hj1
                dsimp only at hadv_r
                cases hadv_eq : advanceOneJob cp pts st₁.gt (st₁.serving[r.val]'hr1) r jb _ (ω₂.2 r.castSucc) with
                | inl jb' =>
                    rw [hadv_eq] at hjb₂ hadv_r
                    injection hjb₂ with hjb'_eq; subst hjb'_eq
                    exact hadv_r.2 (hgd_j1 r hr1 jb hj1) (hs2_all.1 r hr1 jb hj1)
                | inr _ =>
                    rw [hadv_eq] at hjb₂; cases hjb₂
          · rw [if_neg hlt_r₀] at hjb₂; cases hjb₂
  | none =>
      dsimp only
      -- No background job committed (`commitFn r = none` for EVERY `r : Fin cp.D_max`!)
      have hall_no_commit : ∀ r : Fin cp.D_max, commitFn r = none :=
        finRange_findSome_none commitFn hfc
      set jobs₂ : Fin cp.D_max → Option (SuffixJob cp) := fun r =>
        match outJobs r with
        | some (Sum.inl jb') => some jb'
        | _ => none
      -- Common helper: for all `r < st₁.serving.length`, `jobs₂` satisfies `PostStage2WF` & `ChainEngineGood`!
      have hjobs2_spec : ∀ r : Fin cp.D_max,
          (if hr : r.val < st₁.serving.length then
            let mn := st₁.serving[r.val]'hr
            match jobs₂ r with
            | none => 64 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize + 64 * K_alpha d
            | some jb' =>
                SuffixJobInv cp actH pts st₁.gt (foldResiduals pts actH (st₁.serving.take r.val)) mn r.val jb'
          else
            jobs₂ r = none) ∧
          (ChainEngineGood cp hh0 hh1 st₁ →
           GoodStage2Coins cp hh0 hh1 st₁ ω₂ →
           r.val < st₁.serving.length →
           ∀ jb', jobs₂ r = some jb' → SuffixJobGood cp hh0 hh1 pts st₁.gt jb') := by
        intro r
        have hnc := hall_no_commit r
        refine ⟨?_, fun hgd1 hs2 hr jb' hjb' => ?_⟩
        · by_cases hr : r.val < st₁.serving.length
          · rw [dif_pos hr]; dsimp only
            have hslot1 := hjobs_wf r
            rw [dif_pos hr] at hslot1; dsimp only at hslot1
            cases hj1 : st₁.jobs r with
            | none =>
                have ho : outJobs r = none := by dsimp only [outJobs]; rw [dif_pos hr, hj1]
                have hj2 : jobs₂ r = none := by dsimp only [jobs₂]; rw [ho]
                rw [hj2]; rw [hj1] at hslot1; exact hslot1
            | some jb =>
                have hadv_r := hjob_adv r hr jb hj1
                dsimp only at hadv_r
                dsimp only [commitFn, outJobs] at hnc
                rw [dif_pos hr, hj1] at hnc; dsimp only at hnc
                cases hadv_eq : advanceOneJob cp pts st₁.gt (st₁.serving[r.val]'hr) r jb _ (ω₂.2 r.castSucc) with
                | inl jb' =>
                    rw [hadv_eq] at hadv_r
                    have hj2 : jobs₂ r = some jb' := by
                      dsimp only [jobs₂, outJobs]; rw [dif_pos hr, hj1]; dsimp only; rw [hadv_eq]
                    rw [hj2]; exact hadv_r.1
                | inr trip =>
                    rcases trip with ⟨_, _, _⟩
                    rw [hadv_eq] at hnc; cases hnc
          · rw [dif_neg hr]
            have ho : outJobs r = none := by dsimp only [outJobs]; rw [dif_neg hr]
            dsimp only [jobs₂]; rw [ho]
        · dsimp only [jobs₂, outJobs] at hjb'
          rw [dif_pos hr] at hjb'
          cases hj1 : st₁.jobs r with
          | none => rw [hj1] at hjb'; cases hjb'
          | some jb =>
              rw [hj1] at hjb'; dsimp only at hjb'
              have hadv_r := hjob_adv r hr jb hj1
              dsimp only at hadv_r
              cases hadv_eq : advanceOneJob cp pts st₁.gt (st₁.serving[r.val]'hr) r jb _ (ω₂.2 r.castSucc) with
              | inl jb_out =>
                  rw [hadv_eq] at hjb' hadv_r
                  injection hjb' with heq; subst heq
                  exact hadv_r.2 (hgd1.2.2 r hr jb hj1) (hs2.1 r hr jb hj1)
              | inr _ => rw [hadv_eq] at hjb'; cases hjb'
      by_cases hleaf_trig : (!st₁.leafOverflow && decide (cp.B_scan < st₁.leafArr.length)) = true
      · rw [if_pos hleaf_trig]
        rcases Bool.and_eq_true_iff.mp hleaf_trig with ⟨hnov_b, hgtB_b⟩
        have hov1_f : st₁.leafOverflow = false := by
          cases hb : st₁.leafOverflow <;> [rfl; (rw [hb] at hnov_b; cases hnov_b)]
        have hgt_B_lf : cp.B_scan < st₁.leafArr.length := of_decide_eq_true hgtB_b
        rcases hleaf_wf hov1_f with ⟨hlf_nd, hlf_set, hlf_len1⟩
        by_cases hext_ok : (st₁.serving.length < cp.D_max && decide (st₁.leafArr.length ≤ cp.B_scan + 1)) = true
        · -- Synchronous 1-step leaf extension!
          rw [if_pos hext_ok]
          rcases Bool.and_eq_true_iff.mp hext_ok with ⟨hserv_lt_b, _⟩
          have hserv_lt : st₁.serving.length < cp.D_max := of_decide_eq_true hserv_lt_b
          set leafCtr := ω₂.2 (Fin.last cp.D_max)
          set os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts st₁.leafArr leafCtr
          set P₀_uid := st₁.leafArr.toFinset.image st₁.gt.uidOf
          set bs0 := BuildState.init cp st₁.leafArr.length st₁.leafArr os.1 os.2 P₀_uid
          set steps := min st₁.leafArr.length (cp.B_scan + 1)
          have hsteps_eq : steps = st₁.leafArr.length := Nat.min_eq_left hlf_len1
          set leafSeeds : Fin steps → OpSeed cp := fun j =>
            ω₂.1 ⟨cp.D_max * cp.B_scan + j.val, by
              have hj : j.val < cp.B_scan + 1 := lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)
              exact Nat.add_lt_add_left hj _⟩
          have hlf_sub_act : st₁.leafArr.toFinset ⊆ actH :=
            hlf_set ▸ (chainListInv_getElem actH st₁.serving (Finset.Subset.refl _) hserv_cl).1
          have hlf_card_n : st₁.leafArr.toFinset.card ≤ cp.n :=
            (Finset.card_le_card hlf_sub_act).trans hact_n
          rcases buildState_init_spec cp hh0 hh1 hgt hlf_sub_act hlf_card_n st₁.leafArr.length
            hlf_nd rfl hgt_B_lf os.1 os.2 with ⟨hbs0_inv, hbs0_mat_gd⟩
          have hbs0_ins : bs0.insCur + steps ≤ bs0.snapArr.length := by
            dsimp only [bs0, BuildState.init]; rw [Nat.zero_add, hsteps_eq]
          have hbs0_age : bs0.curNode.nd.age ≤ bs0.curNode.nd.birthSize := by
            dsimp only [bs0, BuildState.init, ManagedNode.openEmpty, NodeInst.openEmpty]; exact Nat.zero_le _
          rcases advanceBuildLoop_spec h_clm_7_3 hd he1 cp hh0 hh1 steps leafSeeds hbs0_ins hbs0_age hbs0_inv
            with ⟨_, hsnap_d, hins_d, ho_d, hs_d, hV_d, hbS_d, hbsz_d, hage_d, hbsd_inv, hdone_d, hgd_d⟩
          set bsDone := advanceBuildLoop cp pts steps leafSeeds bs0
          set u_leaf := bsDone.curNode
          have hins_eq_snap : bsDone.insCur = bsDone.snapArr.length := by
            rw [hins_d, hsnap_d]; dsimp only [bs0, BuildState.init]; rw [Nat.zero_add, hsteps_eq]
          have hul_cur : u_leaf.nd.curSet = foldResiduals pts actH st₁.serving := by
            rw [hdone_d hins_eq_snap, hlf_set]
          have hul_age0 : u_leaf.nd.age = 0 := by
            rw [hage_d]; rfl
          have hul_ln : LiveNodeInv cp actH pts st₁.gt (foldResiduals pts actH st₁.serving) u_leaf := by
            rcases hbsd_inv with ⟨_, _, _, hbsz_eq, hbsz_n, hbsz_B, hbu, _, _, hage_u, hhist_u, htins_u, hwf_u⟩
            rw [hins_eq_snap, ← hbsz_eq] at hhist_u htins_u
            rw [hlf_set] at hage_u
            exact ⟨hul_cur, hbsz_n, hbsz_B, hbu, hage_u, hhist_u, htins_u, hwf_u⟩
          have hserv_ext_cl : ChainListInv cp actH pts st₁.gt actH (st₁.serving ++ [u_leaf]) :=
            chainListInv_append actH st₁.serving [u_leaf] hserv_cl ⟨hul_ln, trivial⟩
          have hserv_ext_len : (st₁.serving ++ [u_leaf]).length ≤ cp.D_max := by
            rw [List.length_append, List.length_singleton]; omega
          have hul_res_set : u_leaf.resArr.toFinset = foldResiduals pts actH (st₁.serving ++ [u_leaf]) := by
            rw [foldResiduals_append]; dsimp only [foldResiduals]
            rw [hul_ln.2.2.2.2.2.2.2.2.2.1, hul_cur]
          -- Helper for per-slot `PostStage2WF` on `st₁.serving ++ [u_leaf]`
          have hslots_ext : ∀ r : Fin cp.D_max,
              if hr : r.val < (st₁.serving ++ [u_leaf]).length then
                let mn := (st₁.serving ++ [u_leaf])[r.val]'hr
                match jobs₂ r with
                | none => 64 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize + 64 * K_alpha d
                | some jb' =>
                    SuffixJobInv cp actH pts st₁.gt
                      (foldResiduals pts actH ((st₁.serving ++ [u_leaf]).take r.val)) mn r.val jb'
              else
                jobs₂ r = none := by
            intro r
            by_cases hr_ext : r.val < (st₁.serving ++ [u_leaf]).length
            · rw [dif_pos hr_ext]; dsimp only
              by_cases hr1 : r.val < st₁.serving.length
              · have hget_eq : (st₁.serving ++ [u_leaf])[r.val]'hr_ext = st₁.serving[r.val]'hr1 :=
                  List.getElem_append_left hr1
                have htake_eq : (st₁.serving ++ [u_leaf]).take r.val = st₁.serving.take r.val :=
                  List.take_append_of_le_length (Nat.le_of_lt hr1)
                have hs_r := (hjobs2_spec r).1
                rw [dif_pos hr1] at hs_r; dsimp only at hs_r
                rw [hget_eq, htake_eq]
                exact hs_r
              · have hr_eq_len : r.val = st₁.serving.length := by
                  rw [List.length_append, List.length_singleton] at hr_ext; omega
                have hj2_none : jobs₂ r = none := by
                  have hs_r := (hjobs2_spec r).1
                  rw [dif_neg hr1] at hs_r; exact hs_r
                rw [hj2_none]
                have hget_ul : (st₁.serving ++ [u_leaf])[r.val]'hr_ext = u_leaf := by
                  have h1 : (st₁.serving ++ [u_leaf])[r.val]'hr_ext =
                      (st₁.serving ++ [u_leaf])[st₁.serving.length]'(by simp) := by
                    congr 1
                  rw [h1]; simp
                rw [hget_ul, hul_age0, Nat.mul_zero]
                exact Nat.zero_le _
            · rw [dif_neg hr_ext]
              have hr1_not : ¬ r.val < st₁.serving.length := by
                intro h; apply hr_ext; rw [List.length_append]; omega
              have hs_r := (hjobs2_spec r).1
              rw [dif_neg hr1_not] at hs_r; exact hs_r
          by_cases hres_le : u_leaf.resArr.length ≤ cp.B_scan
          · rw [if_pos hres_le]
            refine ⟨⟨hhp, hgt, hserv_ext_len, hserv_ext_cl, hslots_ext,
              fun _ => ⟨hul_ln.2.2.2.2.2.2.2.2.1, hul_res_set, hres_le⟩⟩,
              fun hgd1 hs2 => ⟨rfl, ?_, ?_⟩⟩
            · rcases hs2.2 hov1_f hgt_B_lf hserv_lt hlf_len1 with ⟨hcp_lf, hseq_lf⟩
              have hbs0_gd : LiveNodeGood cp hh0 hh1 pts st₁.gt bs0.curNode := ⟨hcp_lf, hbs0_mat_gd⟩
              have hul_gd := hgd_d hbs0_gd hseq_lf
              intro u hu
              rcases List.mem_append.mp hu with h1 | h2
              · exact hgd1.2.1 u h1
              · rw [List.mem_singleton.mp h2]; exact hul_gd
            · intro r hr_ext jb' hjb'
              dsimp only at hjb'
              have hr1 : r.val < st₁.serving.length := by
                by_contra hnot
                have hs_r := (hjobs2_spec r).1
                rw [dif_neg hnot] at hs_r
                rw [hs_r] at hjb'; cases hjb'
              exact (hjobs2_spec r).2 hgd1 hs2 hr1 jb' hjb'
          · -- `u_leaf.resArr.length > cp.B_scan` -> impossible on `GoodStage2Coins` (`age = 0`, strict `- 1` contraction!)!
            rw [if_neg hres_le]
            refine ⟨⟨hhp, hgt, hserv_ext_len, hserv_ext_cl, hslots_ext, fun hf => by simp at hf⟩,
              fun _ hs2 => ?_⟩
            exfalso
            rcases hs2.2 hov1_f hgt_B_lf hserv_lt hlf_len1 with ⟨hcp_lf, hseq_lf⟩
            have hbs0_gd : LiveNodeGood cp hh0 hh1 pts st₁.gt bs0.curNode := ⟨hcp_lf, hbs0_mat_gd⟩
            have hul_gd := hgd_d hbs0_gd hseq_lf
            have hS_sub : (foldResiduals pts actH st₁.serving) ⊆ actH :=
              (chainListInv_getElem actH st₁.serving (Finset.Subset.refl _) hserv_cl).1
            have hP0_card : P₀_uid.card = st₁.leafArr.length := by
              dsimp only [P₀_uid]
              rw [card_image_uidOf hgt hlf_sub_act, List.toFinset_card_of_nodup hlf_nd]
            have hm_pos : 1 ≤ P₀_uid.card := by omega
            have hubS_eq : u_leaf.nd.birthSet = P₀_uid := by
              rw [hbS_d]; rfl
            have hcp_u : IsCenterpoint (hpjAlpha d)
                (paraboloidLiftSet (fun u : P₀_uid => st₁.gt.ghostPts u.1))
                (liftedPoint u_leaf.nd.o u_leaf.nd.s) := by
              have h1 := hul_gd.1
              rwa [hubS_eq] at h1
            have hage_u : HasNodeAge P₀_uid ((foldResiduals pts actH st₁.serving).image st₁.gt.uidOf) 0 := by
              rw [← hlf_set]; exact hasNodeAge_zero P₀_uid
            have hcon := residual_contraction_via_ghost h_lem_5_1 hgt hS_sub hm_pos hcp_u hage_u (by simp)
            have hK_lt_B : K_alpha d < P₀_uid.card := by
              have := cp.sched_bounds.1; have := K_alpha_ge_36 d; omega
            have hstrict := hcon.2.2 hK_lt_B (by rw [← hlf_set])
            have hV_eq : max 0 (liftVariance u_leaf.nd.o u_leaf.nd.s) = u_leaf.nd.V := rfl
            rw [hV_eq, ← hul_cur, ← hul_ln.2.2.2.2.2.2.2.2.2.1,
                List.toFinset_card_of_nodup hul_ln.2.2.2.2.2.2.2.2.1, hP0_card] at hstrict
            omega
        · -- `!(serving.length < D_max && leafArr.length ≤ B_scan + 1)` -> impossible on `ChainEngineGood`!
          rw [if_neg hext_ok]
          refine ⟨⟨hhp, hgt, hserv_len, hserv_cl, fun r => (hjobs2_spec r).1, fun hf => by simp at hf⟩,
            fun hgd1 _ => ?_⟩
          exfalso
          have hserv_eq_D : st₁.serving.length = cp.D_max := by
            by_contra hne
            have hlt_D : st₁.serving.length < cp.D_max := by omega
            apply hext_ok
            simp [hlt_D, hlf_len1]
          have hage16_all : ∀ mn ∈ st₁.serving, 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize := by
            intro mn hmn
            rcases List.mem_iff_getElem.mp hmn with ⟨q, hq, rfl⟩
            exact Nat.le_of_lt (hserv_age16 q hq)
          have hemp := fullDepth_terminal_empty h_lem_5_1 hh0 hh1 hact_n hgt
            (le_of_eq hserv_eq_D.symm) hserv_cl hgd1.2.1 hage16_all
          rw [hemp] at hlf_set
          have hlen0 : st₁.leafArr.length = 0 := by
            rw [← List.toFinset_card_of_nodup hlf_nd, hlf_set]; rfl
          omega
      · -- No leaf extension needed (`leafOverflow = true` or `leafArr.length ≤ B_scan`)!
        rw [if_neg hleaf_trig]
        refine ⟨⟨hhp, hgt, hserv_len, hserv_cl, fun r => (hjobs2_spec r).1, fun hov => ?_⟩,
          fun hgd1 hs2 => ⟨hgd1.1, hgd1.2.1, fun r hr jb' hjb' => (hjobs2_spec r).2 hgd1 hs2 hr jb' hjb'⟩⟩
        dsimp only at hov
        rcases hleaf_wf hov with ⟨hlf_nd, hlf_set, _⟩
        have hle_B : st₁.leafArr.length ≤ cp.B_scan := by
          by_contra hgt_b
          apply hleaf_trig
          have hgt' : cp.B_scan < st₁.leafArr.length := by omega
          simp [hov, hgt']
        exact ⟨hlf_nd, hlf_set, hle_B⟩

end UL.Proof.clm_9_1_explicit_tradeoff.C14d2
