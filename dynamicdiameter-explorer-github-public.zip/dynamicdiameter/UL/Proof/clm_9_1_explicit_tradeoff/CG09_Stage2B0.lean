import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B0a
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 7. Build-Loop Tail Lemma & Execution (`advanceJobBuildLoopStmt`, `advanceLeafBuildLoopStmt`) -/

theorem advanceBuildLoop_take_succ {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts : ℕ → EuclideanSpace ℝ (Fin d)) :
    ∀ (k : ℕ) (ωs : ℕ → OpSeed cp) (bs : BuildState cp),
      advanceBuildLoop cp pts (k + 1) (fun i : Fin (k + 1) => ωs i.val) bs =
        advanceBuildStep cp pts
          (advanceBuildLoop cp pts k (fun i : Fin k => ωs i.val) bs) (ωs k)
  | 0, ωs, bs => rfl
  | k + 1, ωs, bs => by
      have h1 : advanceBuildLoop cp pts (k + 2) (fun i : Fin (k + 2) => ωs i.val) bs =
          advanceBuildLoop cp pts (k + 1) (fun i : Fin (k + 1) => ωs (i.val + 1))
            (advanceBuildStep cp pts bs (ωs 0)) := rfl
      have h2 : advanceBuildLoop cp pts (k + 1) (fun i : Fin (k + 1) => ωs i.val) bs =
          advanceBuildLoop cp pts k (fun i : Fin k => ωs (i.val + 1))
            (advanceBuildStep cp pts bs (ωs 0)) := rfl
      rw [h1, h2]
      exact advanceBuildLoop_take_succ cp pts k (fun j => ωs (j + 1)) (advanceBuildStep cp pts bs (ωs 0))

theorem advanceBuildStep_delSnapArr {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (bs : BuildState cp) (ω : OpSeed cp) :
    (advanceBuildStep cp pts bs ω).delSnapArr = bs.delSnapArr := by
  unfold advanceBuildStep
  split_ifs <;> rfl

theorem advanceBuildLoop_delSnapArr {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts : ℕ → EuclideanSpace ℝ (Fin d)) :
    ∀ (steps : ℕ) (ωs : Fin steps → OpSeed cp) (bs : BuildState cp),
      (advanceBuildLoop cp pts steps ωs bs).delSnapArr = bs.delSnapArr
  | 0, _, _ => rfl
  | steps + 1, ωs, bs => by
      dsimp only [advanceBuildLoop]
      rw [advanceBuildLoop_delSnapArr cp pts steps _ _, advanceBuildStep_delSnapArr]

def advanceJobBuildSetupStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  let remE := IntExpr.sub (.readHeap engMetaTbl (.lit (base + 5)))
                          (.readHeap engMetaTbl (.lit (base + 4)))
  .seq (.ite (.intLt remE (.lit (cp.B_scan : ℤ)))
          (.writeWordHeap engScrTbl (.lit 30) remE)
          (.writeWordHeap engScrTbl (.lit 30) (.lit (cp.B_scan : ℤ))))
  (.seq (.writeWordHeap engScrTbl (.lit 20) (.lit (base + 6)))
  (.seq (.writeWordHeap engScrTbl (.lit 21) (.lit (delSnapElemOff cp r.val)))
        (.writeWordHeap engScrTbl (.lit 22) (.lit (delSnapPosOff cp r.val)))))

def advanceJobBuildIterStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max) (cSlotR : ℤ) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  let coinBase : ℤ := ((cp.B_S1 + r.val * cp.B_scan * cp.B_op : ℕ) : ℤ)
  .seq (.writeWordHeap engScrTbl (.lit 29) (.readHeap engMetaTbl (.lit (base + 4))))
  (.seq (.writeWordHeap engScrTbl (.lit 23)
          (.readHeap engArrTbl
            (.add (.lit (snapElemOff cp r.val)) (.readHeap engScrTbl (.lit 29)))))
  (.seq (sparseContainsStmt cp.n 20 21 22 23 25)
  (.seq (.ite (.intEq (.readHeap engScrTbl (.lit 25)) (.lit 1))
          .skip
          (.seq (.writeWordHeap engScrTbl (.lit 26)
                  (.add (.lit coinBase)
                    (.mul (.readHeap engScrTbl (.lit 27)) (.lit (cp.B_op : ℤ)))))
                (ops.insertMatStmt cSlotR 23 26)))
        (.writeWordHeap engMetaTbl (.lit (base + 4))
          (.add (.readHeap engScrTbl (.lit 29)) (.lit 1))))))

def advanceJobBuildLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max) (cSlotR : ℤ) : ArithRAMStmt :=
  .seq (advanceJobBuildSetupStmt cp r)
       (dynForLoopStmt 27 30 (advanceJobBuildIterStmt ops r cSlotR))

theorem zeroRand_advanceJobBuildLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (r : Fin cp.D_max) (cSlotR : ℤ) :
    ZeroRandStmt (advanceJobBuildLoopStmt ops r cSlotR) := by
  unfold advanceJobBuildLoopStmt advanceJobBuildSetupStmt advanceJobBuildIterStmt
  exact .seq (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))
    (zeroRand_dynForLoopStmt 27 30
      (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _)
      (.seq (zeroRand_sparseContainsStmt cp.n 20 21 22 23 25)
      (.seq (.ite .skip (.seq (.writeWordHeap _ _ _) (ops.zeroRand_insertMat cSlotR 23 26)))
            (.writeWordHeap _ _ _))))))

theorem exec_advanceJobBuildLoopStmt
    (h_clm_7_3 : S_clm_7_3_global_approx)
    {d : ℕ} (hd : 1 ≤ d) {params : LocalScaleParams} (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1)
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max) (cSlotR : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d} {T_end : Finset ℕ}
    {bits : Fin cp.B_STEP → Bool}
    {bs : BuildState cp} {cSlot : ℕ} {m₀ : ArithRAMMemory}
    (hcR0 : 0 ≤ cSlotR) (hcR20 : cSlotR < 20)
    (hcSlot : cSlot < M_slots cp)
    (hage_le : bs.curNode.nd.age ≤ bs.curNode.nd.birthSize)
    (hbs_inv : BuildStateInv cp pts gt T_end bs)
    (hTend_n : ∀ x ∈ T_end, x < cp.n)
    (hTend_pts : ∀ x ∈ T_end, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hcoins : MemHasStepCoins cp bits m₀)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (henc_cur : ops.EncNode bs.curNode cSlot m₀)
    (hread_cR : wRead m₀ engScrTbl cSlotR = (cSlot : ℤ))
    (hw_L : wRead m₀ engMetaTbl (jobMetaBase cp r.val + 3) = (bs.L_hist : ℤ))
    (hw_ins : wRead m₀ engMetaTbl (jobMetaBase cp r.val + 4) = (bs.insCur : ℤ))
    (hsnap_enc : EncSparseSet cp.n (jobMetaBase cp r.val + 5)
      (snapElemOff cp r.val) (snapPosOff cp r.val) bs.snapArr m₀)
    (hdel_enc : EncSparseSet cp.n (jobMetaBase cp r.val + 6)
      (delSnapElemOff cp r.val) (delSnapPosOff cp r.val) bs.delSnapArr m₀) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
      ω₂.1 ⟨r.val * cp.B_scan + j.val, by
        have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
          calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan :=
                Nat.add_lt_add_left j.isLt _
            _ = (r.val + 1) * cp.B_scan := by ring
            _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
        exact Nat.lt_add_right _ this⟩
    let steps := min (bs.snapArr.length - bs.insCur) cp.B_scan
    let ωs : Fin steps → OpSeed cp := fun j =>
      bSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩
    let bs' := advanceBuildLoop cp pts steps ωs bs
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (advanceJobBuildLoopStmt ops r cSlotR) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        wRead m₁ engMetaTbl (jobMetaBase cp r.val + 3) = (bs'.L_hist : ℤ) ∧
        wRead m₁ engMetaTbl (jobMetaBase cp r.val + 4) = (bs'.insCur : ℤ) ∧
        EncSparseSet cp.n (jobMetaBase cp r.val + 5)
          (snapElemOff cp r.val) (snapPosOff cp r.val) bs'.snapArr m₁ ∧
        EncSparseSet cp.n (jobMetaBase cp r.val + 6)
          (delSnapElemOff cp r.val) (delSnapPosOff cp r.val) bs'.delSnapArr m₁ ∧
        ops.EncNode bs'.curNode cSlot m₁ ∧
        (∀ mn' s, s < M_slots cp → s ≠ cSlot → ops.EncNode mn' s m₀ → ops.EncNode mn' s m₁) ∧
        (∀ t < 9, t ≠ engMetaTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ jobMetaBase cp r.val + 4 → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, i < 20 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (100 + cp.B_scan * (ops.C_ins + 180)) := by
  intro ω₂ bSeeds steps ωs bs'
  have hTW := ops.hTW; have hBW_meta := ops.hBW_meta; have hBW_scr := ops.hBW_scr
  let base := jobMetaBase cp r.val
  have hmeta_b : 16 + cp.D_max + 8 * r.val + 8 ≤ ops.BW := by
    have hr_lt := r.isLt; have hD2 : 0 ≤ cp.D_max * cp.D_max := Nat.zero_le _
    nlinarith only [hr_lt, hBW_meta, hD2]
  have hsteps_le_B : steps ≤ cp.B_scan := Nat.min_le_right _ _
  have hsteps_le_rem : bs.insCur + steps ≤ bs.snapArr.length := by
    have := hbs_inv.2.2.1; dsimp [steps]; omega
  let ωNat : ℕ → OpSeed cp := fun j =>
    if hj : j < steps then ωs ⟨j, hj⟩ else fun _ _ => false
  have hωs_eq : ωs = (fun i : Fin steps => ωNat i.val) :=
    funext fun i => by dsimp only [ωNat]; rw [dif_pos i.isLt]
  let bsAt (k : ℕ) : BuildState cp :=
    advanceBuildLoop cp pts k (fun i : Fin k => ωNat i.val) bs
  have hbsAt_steps : bsAt steps = bs' := by dsimp only [bsAt, bs']; rw [← hωs_eq]
  let FrameBuild (m : ArithRAMMemory) : Prop :=
    ops.SlotsReady m ∧
    (∀ mn' s, s < M_slots cp → s ≠ cSlot → ops.EncNode mn' s m₀ → ops.EncNode mn' s m) ∧
    (∀ t < 9, t ≠ engMetaTbl → t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ i, i ≠ base + 4 → wRead m engMetaTbl i = wRead m₀ engMetaTbl i) ∧
    (∀ i, i < 20 → wRead m engScrTbl i = wRead m₀ engScrTbl i) ∧
    (∀ t < 3, ∀ i, rRead m t i = rRead m₀ t i)
  -- Phase 1: Setup
  have hSetup : ExecDet ops.TW ops.BW ops.TR ops.BR inp
      (advanceJobBuildSetupStmt cp r) m₀
      (fun mS =>
        FrameBuild mS ∧
        wRead mS engScrTbl 30 = (steps : ℤ) ∧
        wRead mS engScrTbl 20 = base + 6 ∧
        wRead mS engScrTbl 21 = delSnapElemOff cp r.val ∧
        wRead mS engScrTbl 22 = delSnapPosOff cp r.val ∧
        wRead mS engMetaTbl (base + 4) = (bs.insCur : ℤ) ∧
        ops.EncNode bs.curNode cSlot mS)
      64 := by
    unfold advanceJobBuildSetupStmt
    let remE := IntExpr.sub (.readHeap engMetaTbl (.lit (base + 5)))
                            (.readHeap engMetaTbl (.lit (base + 4)))
    have hrem_eval : (evalIntExpr inp.toWordView 0 m₀.words remE).1 =
        ((bs.snapArr.length - bs.insCur : ℕ) : ℤ) := by
      simp only [remE, evalIntExpr]
      change wRead m₀ engMetaTbl (base + 5) - wRead m₀ engMetaTbl (base + 4) = _
      rw [hsnap_enc.2.2.1, hw_ins]
      have := hbs_inv.2.2.1; omega
    have hIte : ExecDet ops.TW ops.BW ops.TR ops.BR inp
        (.ite (.intLt remE (.lit (cp.B_scan : ℤ)))
          (.writeWordHeap engScrTbl (.lit 30) remE)
          (.writeWordHeap engScrTbl (.lit 30) (.lit (cp.B_scan : ℤ))))
        m₀ (fun m1 => m1 = H3a.wWrite m₀ engScrTbl 30 (steps : ℤ)) 28 := by
      by_cases hlt : bs.snapArr.length - bs.insCur < cp.B_scan
      · have hcondT : (evalArithCond inp 0 m₀ (.intLt remE (.lit (cp.B_scan : ℤ)))).1 = true := by
          simp only [evalArithCond, hrem_eval, evalIntExpr]; exact decide_eq_true (by exact_mod_cast hlt)
        have hst_eq : steps = bs.snapArr.length - bs.insCur := Nat.min_eq_left (Nat.le_of_lt hlt)
        refine ExecDet.ite' (C_c := 12) (C_b := 16) _ _ _ hcondT
          (by simp [remE, condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf) (by omega)
        exact ExecDet.wWrite inp engScrTbl (.lit 30) remE 30 (steps : ℤ)
          hfp₀ (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
          (by rw [hrem_eval, hst_eq]) (by simp [remE, intExprOps]) rfl
      · have hcondF : (evalArithCond inp 0 m₀ (.intLt remE (.lit (cp.B_scan : ℤ)))).1 = false := by
          simp only [evalArithCond, hrem_eval, evalIntExpr]
          exact decide_eq_false (by intro hc; apply hlt; exact_mod_cast hc)
        have hst_eq : steps = cp.B_scan := Nat.min_eq_right (Nat.le_of_not_lt hlt)
        refine ExecDet.ite' (C_c := 12) (C_b := 16) _ _ _ hcondF
          (by simp [remE, condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_) (by omega)
        exact ExecDet.wWrite inp engScrTbl (.lit 30) (.lit (cp.B_scan : ℤ)) 30 (steps : ℤ)
          hfp₀ (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
          (by simp only [evalIntExpr]; rw [hst_eq]) (by simp [intExprOps]) rfl
    refine ExecDet.seq' 36 hIte (by omega) ?_
    intro m1 hm1 hfp1; subst hm1
    refine ExecDet.seq' 24
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 20) (.lit (base + 6)) 20 (base + 6)
        hfp1 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro m2 hm2 hfp2; subst hm2
    refine ExecDet.seq' 12
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 21) (.lit (delSnapElemOff cp r.val)) 21 (delSnapElemOff cp r.val)
        hfp2 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro m3 hm3 hfp3; subst hm3
    refine ExecDet.wWrite (C := 12) inp engScrTbl (.lit 22) (.lit (delSnapPosOff cp r.val)) 22 (delSnapPosOff cp r.val)
      hfp3 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl rfl
      (by simp [intExprOps]) ?_
    set mS := H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engScrTbl 30 (steps : ℤ))
      engScrTbl 20 (base + 6)) engScrTbl 21 (delSnapElemOff cp r.val)) engScrTbl 22 (delSnapPosOff cp r.val)
    have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mS t i = wRead m₀ t i := by
      intro t ht9 _ i; simp only [mS, wRead_wWrite_eq]
      have : t ≠ engScrTbl := by unfold engScrTbl; omega
      simp [this]
    have hrS : ∀ t i, rRead mS t i = rRead m₀ t i := fun t i => by simp [mS, rRead_wWrite]
    refine ⟨⟨ops.slotsReady_ext m₀ mS hsr₀ hw9 (fun t _ _ i => hrS t i),
      fun mn' s _ _ he => ops.encNode_ext mn' s m₀ mS he hw9 (fun t _ _ i => hrS t i) (fun _ _ _ _ => hrS ptsRTbl _),
      fun t _ _ ht2 i => by simp only [mS, wRead_wWrite_eq]; simp [ht2],
      fun i _ => by simp only [mS, wRead_wWrite_eq]; simp [engMetaTbl, engScrTbl],
      fun i hi20 => by
        simp only [mS, wRead_wWrite_eq]
        have : i ≠ 22 ∧ i ≠ 21 ∧ i ≠ 20 ∧ i ≠ 30 := by omega
        simp [this],
      fun t _ i => hrS t i⟩,
      by simp [mS, wRead_wWrite_eq],
      by simp [mS, wRead_wWrite_eq],
      by simp [mS, wRead_wWrite_eq],
      by simp [mS, wRead_wWrite_eq],
      by simp only [mS, wRead_wWrite_eq]; simp [engMetaTbl, engScrTbl]; exact hw_ins,
      ops.encNode_ext bs.curNode cSlot m₀ mS henc_cur hw9 (fun t _ _ i => hrS t i) (fun _ _ _ _ => hrS ptsRTbl _)⟩
  -- Phase 2: Loop `k = 0 .. steps`
  let InvBuild (k : ℕ) (m : ArithRAMMemory) : Prop :=
    FrameBuild m ∧
    wRead m engScrTbl 20 = base + 6 ∧
    wRead m engScrTbl 21 = delSnapElemOff cp r.val ∧
    wRead m engScrTbl 22 = delSnapPosOff cp r.val ∧
    wRead m engMetaTbl (base + 4) = ((bsAt k).insCur : ℤ) ∧
    ops.EncNode (bsAt k).curNode cSlot m
  unfold advanceJobBuildLoopStmt
  refine ExecDet.seq' (36 + cp.B_scan * (ops.C_ins + 180)) hSetup (by clear * -; nlinarith) ?_
  intro mS ⟨hFB_S, hr30_S, hr20_S, hr21_S, hr22_S, hwins_S, henc_S⟩ hfpS
  have hInv0 : InvBuild 0 (H3a.wWrite mS engScrTbl 27 0) := by
    have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead (H3a.wWrite mS engScrTbl 27 0) t i = wRead mS t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    refine ⟨⟨ops.slotsReady_ext mS _ hFB_S.1 hw9 (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun mn' s hs hne he0 => ops.encNode_ext mn' s mS _ (hFB_S.2.1 mn' s hs hne he0) hw9
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun t ht9 ht1 ht2 i => (wRead_wWrite_of_ne _ _ (Or.inl ht2)).trans (hFB_S.2.2.1 t ht9 ht1 ht2 i),
      fun i h4 => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hFB_S.2.2.2.1 i h4),
      fun i hi20 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hFB_S.2.2.2.2.1 i hi20),
      fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans (hFB_S.2.2.2.2.2 t ht3 i)⟩,
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr20_S,
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr21_S,
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hr22_S,
      (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hwins_S,
      ops.encNode_ext bs.curNode cSlot mS _ henc_S hw9
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)⟩
  refine (ExecDet.dynForLoop (N := steps) (N_max := cp.B_scan) (C_b := ops.C_ins + 164)
    27 30 _ InvBuild hfpS (by omega) (by omega) (by unfold M_slots at hBW_scr; omega)
    (by decide) hr30_S hsteps_le_B hInv0 ?_).mono
    (fun m ⟨⟨hsrm, hndm, hftm, hfmm, hfsm, hfrm⟩, _, _, _, hwinsm, hencm⟩ _ => ?_)
    (by clear * -; nlinarith)
  · intro k hk m ⟨hFB, hr20, hr21, hr22, hwins_k, henc_k⟩ hctr hfp
    have hk_B : k < cp.B_scan := lt_of_lt_of_le hk hsteps_le_B
    have hk_le : bs.insCur + k ≤ bs.snapArr.length := by omega
    rcases advanceBuildLoop_spec h_clm_7_3 hd he1 cp hh0 hh1 k
      (fun i : Fin k => ωNat i.val) hk_le hage_le hbs_inv
      with ⟨hLk, hsnapk, hins_k, _, _, _, _, hbszk, hagek, hinv_k, _, _⟩
    have hdelsk : (bsAt k).delSnapArr = bs.delSnapArr :=
      advanceBuildLoop_delSnapArr cp pts k (fun i : Fin k => ωNat i.val) bs
    change (bsAt k).snapArr = bs.snapArr at hsnapk
    change (bsAt k).insCur = bs.insCur + k at hins_k
    change (bsAt k).curNode.nd.birthSize = bs.curNode.nd.birthSize at hbszk
    change (bsAt k).curNode.nd.age = bs.curNode.nd.age at hagek
    change BuildStateInv cp pts gt T_end (bsAt k) at hinv_k
    have hins_lt_snap : (bsAt k).insCur < bs.snapArr.length := by
      dsimp [steps] at hk; omega
    have hins_lt_k : (bsAt k).insCur < (bsAt k).snapArr.length := by rwa [hsnapk]
    set x := bs.snapArr[(bsAt k).insCur]'hins_lt_snap
    have hx_eq_k : (bsAt k).snapArr[(bsAt k).insCur]'hins_lt_k = x := by congr 1
    have hsucc_eq : bsAt (k + 1) = advanceBuildStep cp pts (bsAt k) (ωNat k) :=
      advanceBuildLoop_take_succ cp pts k ωNat bs
    have hωNat_k : ωNat k = bSeeds ⟨k, hk_B⟩ := by
      dsimp only [ωNat]; rw [dif_pos hk]
    unfold advanceJobBuildIterStmt
    let coinBase : ℤ := ((cp.B_S1 + r.val * cp.B_scan * cp.B_op : ℕ) : ℤ)
    -- 1. Load `(bsAt k).insCur` into `29`
    refine ExecDet.seq' (ops.C_ins + 152)
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 29) (.readHeap engMetaTbl (.lit (base + 4)))
        29 ((bsAt k).insCur : ℤ) hfp (by unfold engScrTbl; omega) (by omega)
        (by unfold M_slots at hBW_scr; omega) rfl
        (by simp only [evalIntExpr]; exact hwins_k) (by simp [intExprOps]) rfl)
      (by clear * -; nlinarith) ?_
    intro m1 hm1 hfp1; subst hm1
    -- 2. Load `x` from `snapElemOff cp r.val + [29]` into `23`
    have hread_x : wRead (H3a.wWrite m engScrTbl 29 ((bsAt k).insCur : ℤ))
        engArrTbl (snapElemOff cp r.val + ((bsAt k).insCur : ℤ)) = (x : ℤ) :=
      (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
        ((hFB.2.2.1 engArrTbl (by decide) (by decide) (by decide) _).trans
          (hsnap_enc.2.2.2 (bsAt k).insCur hins_lt_snap).1)
    refine ExecDet.seq' (ops.C_ins + 140)
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 23)
        (.readHeap engArrTbl (.add (.lit (snapElemOff cp r.val)) (.readHeap engScrTbl (.lit 29))))
        23 (x : ℤ) hfp1 (by unfold engScrTbl; omega) (by omega)
        (by unfold M_slots at hBW_scr; omega) rfl
        (by simp only [evalIntExpr]
            change wRead _ engArrTbl (snapElemOff cp r.val + wRead _ engScrTbl 29) = _
            rw [wRead_wWrite_self, hread_x])
        (by simp [intExprOps]) rfl)
      (by clear * -; nlinarith) ?_
    intro m2 hm2 hfp2; subst hm2
    set m2_st := H3a.wWrite (H3a.wWrite m engScrTbl 29 ((bsAt k).insCur : ℤ)) engScrTbl 23 (x : ℤ)
    have hdel_m2 : EncSparseSet cp.n (base + 6) (delSnapElemOff cp r.val) (delSnapPosOff cp r.val)
        bs.delSnapArr m2_st :=
      hdel_enc.ext
        ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hFB.2.2.2.1 (base + 6) (by omega))))
        (fun _ _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
            (hFB.2.2.1 engArrTbl (by decide) (by decide) (by decide) _)))
        (fun _ _ => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
            (hFB.2.2.1 engArrTbl (by decide) (by decide) (by decide) _)))
    -- 3. `sparseContainsStmt cp.n 20 21 22 23 25`
    refine ExecDet.seq' (ops.C_ins + 40)
      (exec_sparseContainsStmt inp 20 21 22 23 25 (by omega) (by unfold M_slots at hBW_scr; omega)
        (by decide) (by decide) (by decide) (by decide) (by omega) (by omega)
        hfp2 hdel_m2
        (by simp only [m2_st, wRead_wWrite_eq]; simp [hr20])
        (by simp only [m2_st, wRead_wWrite_eq]; simp [hr21])
        (by simp only [m2_st, wRead_wWrite_eq]; simp [hr22])
        (wRead_wWrite_self _ _ _ _))
      (by clear * -; nlinarith) ?_
    intro m3 ⟨hr25, hft3, hfs3, hfr3⟩ hfp3
    have hw9_3m : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m3 t i = wRead m t i := fun t ht9 _ i =>
      (hft3 t (by unfold engScrTbl; omega) i).trans
        ((wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))).trans
          (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))))
    have hr_3m : ∀ t i, rRead m3 t i = rRead m t i := fun t i =>
      (hfr3 t i).trans ((rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
    have hsr3 : ops.SlotsReady m3 := ops.slotsReady_ext m m3 hFB.1 hw9_3m (fun t _ _ i => hr_3m t i)
    have henc_k3 : ops.EncNode (bsAt k).curNode cSlot m3 :=
      ops.encNode_ext _ cSlot m m3 henc_k hw9_3m (fun t _ _ i => hr_3m t i) (fun _ _ _ _ => hr_3m ptsRTbl _)
    -- 4. Conditional `insertMatStmt` when `bs.delSnapArr.contains x == false`
    have hcond_del : (evalArithCond inp 0 m3 (.intEq (.readHeap engScrTbl (.lit 25)) (.lit 1))).1 =
        bs.delSnapArr.contains x := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead m3 engScrTbl 25 = 1) = _
      rw [hr25]; cases bs.delSnapArr.contains x <;> rfl
    have hStep4 : ExecDet ops.TW ops.BW ops.TR ops.BR inp
        (.ite (.intEq (.readHeap engScrTbl (.lit 25)) (.lit 1))
          .skip
          (.seq (.writeWordHeap engScrTbl (.lit 26)
                  (.add (.lit coinBase)
                    (.mul (.readHeap engScrTbl (.lit 27)) (.lit (cp.B_op : ℤ)))))
                (ops.insertMatStmt cSlotR 23 26)))
        m3
        (fun m4 =>
          ops.SlotsReady m4 ∧
          ops.EncNode (bsAt (k + 1)).curNode cSlot m4 ∧
          (∀ mn' s, s < M_slots cp → s ≠ cSlot → ops.EncNode mn' s m₀ → ops.EncNode mn' s m4) ∧
          (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m4 t i = wRead m3 t i) ∧
          (∀ i, i < 56 → i ≠ 26 → wRead m4 engScrTbl i = wRead m3 engScrTbl i) ∧
          (∀ t < 3, ∀ i, rRead m4 t i = rRead m3 t i))
        (ops.C_ins + 24) := by
      refine ExecDet.ite' (C_c := 8) (C_b := ops.C_ins + 16) _ _ _ hcond_del
        (by simp [condExprOps, intExprOps]) (fun htrue => ?_) (fun hfalse => ?_) (by clear * -; nlinarith)
      · have hcur_next : (bsAt (k + 1)).curNode = (bsAt k).curNode := by
          rw [hsucc_eq]; unfold advanceBuildStep
          rw [dif_pos hins_lt_k]; dsimp only
          rw [hx_eq_k, hdelsk, if_pos htrue]
        refine ExecDet.skip inp hfp3 ?_ (by clear * -; nlinarith)
        exact ⟨hsr3, hcur_next ▸ henc_k3,
          fun mn' s hs hne he0 => ops.encNode_ext mn' s m m3 (hFB.2.1 mn' s hs hne he0)
            hw9_3m (fun t _ _ i => hr_3m t i) (fun _ _ _ _ => hr_3m ptsRTbl _),
          fun _ _ _ _ => rfl, fun _ _ _ => rfl, fun _ _ _ => rfl⟩
      ·-- `bs.delSnapArr.contains x = false`: run `insertMatStmt`!
        let s2Idx : Fin cp.N_op_s2 := ⟨r.val * cp.B_scan + k, by
          have : r.val * cp.B_scan + k < cp.D_max * cp.B_scan := by
            calc r.val * cp.B_scan + k < r.val * cp.B_scan + cp.B_scan := Nat.add_lt_add_left hk_B _
              _ = (r.val + 1) * cp.B_scan := by ring
              _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
          exact Nat.lt_add_right _ this⟩
        obtain ⟨seedBits, hseed_eq, hcoin_bnd, hcoin_rd⟩ :=
          memHasStepCoins_stage2_op cp bits m₀ hcoins s2Idx
        let coinOff : ℕ := cp.B_S1 + (r.val * cp.B_scan + k) * cp.B_op
        have hcoin_eval : coinBase + (k : ℤ) * (cp.B_op : ℤ) = (coinOff : ℤ) := by
          dsimp only [coinBase, coinOff]; push_cast; ring
        have hr27_3 : wRead m3 engScrTbl 27 = (k : ℤ) :=
          (hfs3 27 (by omega) (by decide)).trans
            (by simp only [m2_st, wRead_wWrite_eq]; simp [hctr])
        refine ExecDet.seq' ops.C_ins
          (ExecDet.wWrite (C := 16) inp engScrTbl (.lit 26)
            (.add (.lit coinBase) (.mul (.readHeap engScrTbl (.lit 27)) (.lit (cp.B_op : ℤ))))
            26 (coinOff : ℤ) hfp3 (by unfold engScrTbl; omega) (by omega)
            (by unfold M_slots at hBW_scr; omega) rfl
            (by simp only [evalIntExpr]
                change coinBase + wRead m3 engScrTbl 27 * (cp.B_op : ℤ) = _
                rw [hr27_3, hcoin_eval])
            (by simp [intExprOps]) rfl)
          (by clear * -; nlinarith) ?_
        intro mC hmC hfpC; subst hmC
        set mC_st := H3a.wWrite m3 engScrTbl 26 (coinOff : ℤ)
        have hw9_C3 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mC_st t i = wRead m3 t i :=
          fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
        -- Verify `insertMat_spec` preconditions from `hinv_k : BuildStateInv cp pts gt T_end (bsAt k)`
        rcases hinv_k with ⟨hnd_s, _, _, _, _, _, _, hdisj_k, hunion_k, _, hhist_k, htins_k, hwf_k⟩
        have hx_in_rem : x ∈ (bsAt k).remSnap := by
          unfold BuildState.remSnap
          rw [Finset.mem_sdiff]
          refine ⟨List.mem_toFinset.mpr ?_, fun hm => ?_⟩
          · rw [hsnapk, List.drop_eq_getElem_cons hins_lt_snap]; exact List.mem_cons_self
          · rw [hdelsk] at hm
            exact absurd (List.contains_iff_mem.mpr (List.mem_toFinset.mp hm)) (by rw [hfalse]; decide)
        have hx_in_T : x ∈ T_end := hunion_k ▸ Finset.mem_union_right _ hx_in_rem
        have hx_n : x < cp.n := hTend_n x hx_in_T
        have hx_not_cur : x ∉ (bsAt k).curNode.nd.curSet := fun hm =>
          Finset.disjoint_left.mp hdisj_k hm hx_in_rem
        have hcur_sub_T : (bsAt k).curNode.nd.curSet ⊆ T_end := hunion_k ▸ Finset.subset_union_left
        have hcur_n : ∀ y ∈ (bsAt k).curNode.nd.curSet, y < cp.n :=
          fun y hy => hTend_n y (hcur_sub_T hy)
        have hage_n : (bsAt k).curNode.nd.age ≤ cp.n := by
          rw [hagek]; exact hage_le.trans hbs_inv.2.2.2.2.1
        have hins_n : (bsAt k).insCur < cp.n := by
          have := hbs_inv.2.2.2.2.1; rw [hbs_inv.2.2.2.1] at this; omega
        have hhist_bnd : (bsAt k).curNode.histArr.length + 1 ≤ 4 * cp.n + 4 := by omega
        have hcap_bnd : ((bsAt k).insCur + (bsAt k).curNode.nd.age) + 1 < 2 ^ cp.L_p2 := by
          have := cp.hL_p2; omega
        have hcR_C : wRead mC_st engScrTbl cSlotR = (cSlot : ℤ) := by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hfs3 cSlotR (by omega) (by omega)]
          simp only [m2_st, wRead_wWrite_eq]
          have : cSlotR ≠ 23 ∧ cSlotR ≠ 29 := by omega
          simp [this, (hFB.2.2.2.2.1 cSlotR hcR20).trans hread_cR]
        have hr23_C : wRead mC_st engScrTbl 23 = (x : ℤ) := by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hfs3 23 (by omega) (by decide)]
          exact wRead_wWrite_self _ _ _ _
        refine (ops.insertMat_spec inp mC_st pts (bsAt k).curNode cSlot x coinOff
          ((bsAt k).insCur + (bsAt k).curNode.nd.age) seedBits cSlotR 23 26
          hcSlot hx_n hx_not_cur hcur_n hhist_bnd htins_k hcap_bnd hwf_k hcoin_bnd
          hcR0 (by omega) (by omega) (by omega) (by omega) (by omega)
          hfpC
          (ops.slotsReady_ext m3 mC_st hsr3 hw9_C3 (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
          (ops.encNode_ext _ cSlot m3 mC_st henc_k3 hw9_C3
            (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _))
          hcR_C hr23_C (wRead_wWrite_self _ _ _ _)
          (fun y hy c => by
            have hy_T : y ∈ T_end := by
              rcases Finset.mem_insert.mp hy with rfl | hy_old
              · exact hx_in_T
              · exact hcur_sub_T hy_old
            exact (rRead_wWrite _ _ _ _ _ _).trans
              ((hr_3m ptsRTbl _).trans ((hFB.2.2.2.2.2 ptsRTbl (by decide) _).trans (hTend_pts y hy_T c))))
          (fun bi => by
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), hft3 coinTbl (by decide) _,
                wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
                hFB.2.2.1 coinTbl (by decide) (by decide) (by decide) _]
            exact hcoin_rd bi)).mono ?_ le_rfl
        intro m4 ⟨hsr4, henc4, hnd4, hft4, hfr4⟩ _
        have hcur_next : (bsAt (k + 1)).curNode =
            (bsAt k).curNode.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
              cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts x (bitsToOpSeedEquiv cp seedBits) := by
          rw [hsucc_eq]; unfold advanceBuildStep
          rw [dif_pos hins_lt_k]; dsimp only
          rw [hx_eq_k, hdelsk, if_neg (by rw [hfalse]; decide), hωNat_k]
          have hs_eq : bSeeds ⟨k, hk_B⟩ = ω₂.1 s2Idx := rfl
          rw [hs_eq, hseed_eq]
        rw [← hcur_next] at henc4
        refine ⟨hsr4, henc4,
          fun mn' s hs hne he0 => hnd4 mn' s hs hne
            (ops.encNode_ext mn' s m mC_st (hFB.2.1 mn' s hs hne he0)
              (fun t ht9 ht' i => (hw9_C3 t ht9 ht' i).trans (hw9_3m t ht9 ht' i))
              (fun t _ _ i => (rRead_wWrite _ _ _ _ _ _).trans (hr_3m t i))
              (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (hr_3m ptsRTbl _))),
          fun t ht9 ht8 i => (hft4 t ht9 i).trans (wRead_wWrite_of_ne _ _ (Or.inl ht8)),
          fun i _ hi26 => (hft4 engScrTbl (by decide) i).trans (wRead_wWrite_of_ne _ _ (Or.inr hi26)),
          fun t ht3 i => (hfr4 t ht3 i).trans (rRead_wWrite _ _ _ _ _ _)⟩
    -- 5. Increment `base + 4` (`insCur + 1`)
    refine ExecDet.seq' 16 hStep4 (by clear * -; nlinarith) ?_
    intro m4 ⟨hsr4, henc4, hnd4, hft4, hfs4, hfr4⟩ hfp4
    have hr29_4 : wRead m4 engScrTbl 29 = ((bsAt k).insCur : ℤ) :=
      (hfs4 29 (by omega) (by decide)).trans
        ((hfs3 29 (by omega) (by decide)).trans
          (by simp only [m2_st, wRead_wWrite_eq]; simp))
    have hr27_4 : wRead m4 engScrTbl 27 = (k : ℤ) :=
      (hfs4 27 (by omega) (by decide)).trans
        ((hfs3 27 (by omega) (by decide)).trans
          (by simp only [m2_st, wRead_wWrite_eq]; simp [hctr]))
    refine ExecDet.wWrite (C := 16) inp engMetaTbl (.lit (base + 4))
      (.add (.readHeap engScrTbl (.lit 29)) (.lit 1))
      (base + 4) (((bsAt k).insCur + 1 : ℕ) : ℤ)
      hfp4 (by unfold engMetaTbl; omega) (by unfold base jobMetaBase; omega)
      (by unfold base jobMetaBase; omega) rfl
      (by simp only [evalIntExpr]; change wRead m4 engScrTbl 29 + 1 = _; rw [hr29_4]; push_cast; rfl)
      (by simp [intExprOps]) ?_
    set m5 := H3a.wWrite m4 engMetaTbl (base + 4) (((bsAt k).insCur + 1 : ℕ) : ℤ)
    set mN := H3a.wWrite m5 engScrTbl 27 ((k : ℤ) + 1)
    have hw9_N4 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mN t i = wRead m4 t i := fun t ht9 _ i =>
      (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))).trans
        (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega)))
    have hr_N4 : ∀ t i, rRead mN t i = rRead m4 t i := fun t i =>
      (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _)
    have hins_succ : (bsAt (k + 1)).insCur = (bsAt k).insCur + 1 := by
      rw [hsucc_eq]; unfold advanceBuildStep; rw [dif_pos hins_lt_k]
    refine ⟨(wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans hr27_4,
      ⟨ops.slotsReady_ext m4 mN hsr4 hw9_N4 (fun t _ _ i => hr_N4 t i),
       fun mn' s hs hne he0 => ops.encNode_ext mn' s m4 mN (hnd4 mn' s hs hne he0)
         hw9_N4 (fun t _ _ i => hr_N4 t i) (fun _ _ _ _ => hr_N4 ptsRTbl _),
       fun t ht9 ht1 ht2 i => (wRead_wWrite_of_ne _ _ (Or.inl ht2)).trans
         ((wRead_wWrite_of_ne _ _ (Or.inl ht1)).trans
           ((hft4 t ht9 ht2 i).trans ((hft3 t ht2 i).trans
             ((wRead_wWrite_of_ne _ _ (Or.inl ht2)).trans
               ((wRead_wWrite_of_ne _ _ (Or.inl ht2)).trans (hFB.2.2.1 t ht9 ht1 ht2 i)))))),
       fun i h4 => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
         ((wRead_wWrite_of_ne _ _ (Or.inr h4)).trans
           ((hft4 engMetaTbl (by decide) (by decide) i).trans
             ((hft3 engMetaTbl (by decide) i).trans
               ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
                 ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hFB.2.2.2.1 i h4)))))),
       fun i hi20 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans
         ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
           ((hfs4 i (by omega) (by omega)).trans ((hfs3 i (by omega) (by omega)).trans
             (by simp only [m2_st, wRead_wWrite_eq]
                 have : i ≠ 23 ∧ i ≠ 29 := by omega
                 simp [this, hFB.2.2.2.2.1 i hi20])))),
       fun t ht3 i => (hr_N4 t i).trans ((hfr4 t ht3 i).trans
         ((hr_3m t i).trans (hFB.2.2.2.2.2 t ht3 i)))⟩,
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
        ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfs4 20 (by omega) (by decide)).trans
            ((hfs3 20 (by omega) (by decide)).trans (by simp only [m2_st, wRead_wWrite_eq]; simp [hr20])))),
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
        ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfs4 21 (by omega) (by decide)).trans
            ((hfs3 21 (by omega) (by decide)).trans (by simp only [m2_st, wRead_wWrite_eq]; simp [hr21])))),
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
        ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
          ((hfs4 22 (by omega) (by decide)).trans
            ((hfs3 22 (by omega) (by decide)).trans (by simp only [m2_st, wRead_wWrite_eq]; simp [hr22])))),
      by rw [hins_succ]; dsimp only [mN, m5]
         rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self],
      ops.encNode_ext _ cSlot m4 mN henc4 hw9_N4
        (fun t _ _ i => hr_N4 t i) (fun _ _ _ _ => hr_N4 ptsRTbl _)⟩
  · -- Assemble final postconditions at `k = steps`
    rw [hbsAt_steps] at hwinsm hencm
    rcases advanceBuildLoop_spec h_clm_7_3 hd he1 cp hh0 hh1 steps ωs hsteps_le_rem hage_le hbs_inv
      with ⟨hLf, hsnapf, _, _, _, _, _, _, _, _, _, _⟩
    have hdelf : bs'.delSnapArr = bs.delSnapArr := advanceBuildLoop_delSnapArr cp pts steps ωs bs
    exact ⟨hsrm,
      hLf ▸ (hfmm (base + 3) (by omega)).trans hw_L,
      hwinsm,
      hsnapf ▸ hsnap_enc.ext (hfmm (base + 5) (by omega))
        (fun _ _ => hftm engArrTbl (by decide) (by decide) (by decide) _)
        (fun _ _ => hftm engArrTbl (by decide) (by decide) (by decide) _),
      hdelf ▸ hdel_enc.ext (hfmm (base + 6) (by omega))
        (fun _ _ => hftm engArrTbl (by decide) (by decide) (by decide) _)
        (fun _ _ => hftm engArrTbl (by decide) (by decide) (by decide) _),
      hencm, hndm, hftm, hfmm, hfsm, hfrm⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
