import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchA

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 1. Pure Intrusive DLL Transitions (`append` & `unlink_of_nodup`) -/

theorem pairs_fst_eq_left {ι : Type*} (es : List (MatchingEdge ι)) :
    (es.map MatchingEdge.pair).map Prod.fst = es.map MatchingEdge.left := by
  induction es with
  | nil => rfl
  | cons e tl ih => simp [MatchingEdge.pair, ih]

theorem pairs_snd_eq_right {ι : Type*} (es : List (MatchingEdge ι)) :
    (es.map MatchingEdge.pair).map Prod.snd = es.map MatchingEdge.right := by
  induction es with
  | nil => rfl
  | cons e tl ih => simp [MatchingEdge.pair, ih]

theorem pairs_eq_of_fst_nodup {α β : Type*} {pairs : List (α × β)}
    (hnd : (pairs.map Prod.fst).Nodup) {x : α} {y₁ y₂ : β}
    (h1 : (x, y₁) ∈ pairs) (h2 : (x, y₂) ∈ pairs) : y₁ = y₂ := by
  obtain ⟨i, hi, heq1⟩ := List.getElem_of_mem h1
  obtain ⟨j, hj, heq2⟩ := List.getElem_of_mem h2
  have hfst : (pairs.map Prod.fst)[i]'(by simpa using hi) =
      (pairs.map Prod.fst)[j]'(by simpa using hj) := by
    simp [heq1, heq2]
  have hij : i = j := (hnd.getElem_inj_iff).mp hfst
  subst hij
  exact (Prod.mk.inj (heq1.symm.trans heq2)).2

theorem pairs_eq_of_snd_nodup {α β : Type*} {pairs : List (α × β)}
    (hnd : (pairs.map Prod.snd).Nodup) {x₁ x₂ : α} {y : β}
    (h1 : (x₁, y) ∈ pairs) (h2 : (x₂, y) ∈ pairs) : x₁ = x₂ := by
  obtain ⟨i, hi, heq1⟩ := List.getElem_of_mem h1
  obtain ⟨j, hj, heq2⟩ := List.getElem_of_mem h2
  have hsnd : (pairs.map Prod.snd)[i]'(by simpa using hi) =
      (pairs.map Prod.snd)[j]'(by simpa using hj) := by
    simp [heq1, heq2]
  have hij : i = j := (hnd.getElem_inj_iff).mp hsnd
  subst hij
  exact (Prod.mk.inj (heq1.symm.trans heq2)).1

theorem IsKeyDLL.append_empty {u : ℕ} {prv nxt : ℕ → ℤ}
    (hp : prv u = -1) (hn : nxt u = -1) :
    IsKeyDLL [u] (u : ℤ) (u : ℤ) prv nxt := by
  refine ⟨fun h => by simp at h, fun _ => ⟨rfl, rfl, fun i hi => ?_⟩⟩
  have hi0 : i = 0 := by simp at hi; omega
  subst hi0
  simp [hp, hn]

theorem IsKeyDLL.append_nonempty {L : List ℕ} {hd tl : ℤ} {prv prv' nxt nxt' : ℕ → ℤ}
    {u : ℕ}
    (hdll : IsKeyDLL L hd tl prv nxt)
    (hnd : L.Nodup)
    (hne : L ≠ [])
    (hu_not : u ∉ L)
    (hprv_u : prv' u = tl)
    (hprv_keep : ∀ k ∈ L, prv' k = prv k)
    (hnxt_u : nxt' u = -1)
    (hnxt_tl : ∀ t_nat : ℕ, tl = (t_nat : ℤ) → nxt' t_nat = (u : ℤ))
    (hnxt_keep : ∀ k ∈ L, (k : ℤ) ≠ tl → nxt' k = nxt k) :
    IsKeyDLL (L ++ [u]) hd (u : ℤ) prv' nxt' := by
  have hpos : 0 < L.length := List.length_pos_iff.mpr hne
  obtain ⟨hhd, htl, hstep⟩ := hdll.2 hne
  refine ⟨fun h => by simp at h, fun _ => ?_⟩
  have hlen : (L ++ [u]).length = L.length + 1 := by simp
  refine ⟨?_, ?_, fun i hi => ?_⟩
  · rw [List.getElem_append_left hpos]; exact hhd
  · have hidx : (L ++ [u]).length - 1 = L.length := by omega
    simp [List.getElem_append_right]
  · rw [hlen] at hi
    by_cases hilt : i < L.length
    · have hget : (L ++ [u])[i]'(by rw [hlen]; omega) = L[i]'hilt :=
        List.getElem_append_left hilt
      have hmem : L[i]'hilt ∈ L := List.getElem_mem hilt
      have hprv_i : prv' ((L ++ [u])[i]'(by rw [hlen]; omega)) = prv (L[i]'hilt) := by
        rw [hget, hprv_keep _ hmem]
      rcases hstep i hilt with ⟨hprv_old, hnxt_old⟩
      constructor
      · rw [hprv_i, hprv_old]
        split_ifs with hi0
        · rfl
        · rw [List.getElem_append_left (by omega)]
      · rw [hget]
        have hi_not_end : ¬ (i + 1 = (L ++ [u]).length) := by rw [hlen]; omega
        rw [dif_neg hi_not_end]
        by_cases hilast : i + 1 = L.length
        · have hi_eq : i = L.length - 1 := by omega
          have htl_i : tl = ((L[i]'hilt : ℕ) : ℤ) :=
            htl.trans (congrArg Nat.cast (by simp [hi_eq]))
          rw [hnxt_tl _ htl_i]
          have hget_u : (L ++ [u])[i + 1]'(by rw [hlen]; omega) = u := by
            rw [List.getElem_append_right (by omega)]
            simp [hilast]
          rw [hget_u]
        · have hne_tl : ((L[i]'hilt : ℕ) : ℤ) ≠ tl := by
            rw [htl]
            intro heq
            have hnat : L[i]'hilt = L[L.length - 1]'(Nat.sub_lt hpos Nat.one_pos) :=
              Int.ofNat.inj heq
            have hij : i = L.length - 1 := (hnd.getElem_inj_iff).mp hnat
            omega
          rw [hnxt_keep _ hmem hne_tl, hnxt_old, dif_neg hilast,
              List.getElem_append_left (by omega)]
    · have hi_eq : i = L.length := by omega
      subst hi_eq
      have hget_u : (L ++ [u])[L.length]'(by rw [hlen]; omega) = u := by
        rw [List.getElem_append_right le_rfl]; simp
      rw [hget_u, hprv_u, hnxt_u]
      have hne0 : ¬ (L.length = 0) := by omega
      have hend : L.length + 1 = (L ++ [u]).length := by rw [hlen]
      rw [dif_neg hne0, dif_pos hend, htl, List.getElem_append_left (by omega)]
      exact ⟨rfl, rfl⟩

theorem IsKeyDLL.mem_neighbors {L : List ℕ} {hd tl : ℤ} {prv nxt : ℕ → ℤ}
    (hdll : IsKeyDLL L hd tl prv nxt) {k₀ : ℕ} (hk₀ : k₀ ∈ L) :
    True ∧
    ((prv k₀ = -1) ∨ (∃ a ∈ L, prv k₀ = (a : ℤ))) ∧
    ((nxt k₀ = -1) ∨ (∃ b ∈ L, nxt k₀ = (b : ℤ))) := by
  have hne : L ≠ [] := List.ne_nil_of_mem hk₀
  obtain ⟨i, hi, rfl⟩ := List.getElem_of_mem hk₀
  obtain ⟨_, _, hstep⟩ := hdll.2 hne
  rcases hstep i hi with ⟨hp, hn⟩
  have hp_or : prv (L[i]'hi) = -1 ∨ ∃ a ∈ L, prv (L[i]'hi) = (a : ℤ) := by
    rw [hp]
    split_ifs with hi0
    · exact Or.inl rfl
    · exact Or.inr ⟨L[i - 1]'(by omega), List.getElem_mem (by omega), rfl⟩
  have hn_or : nxt (L[i]'hi) = -1 ∨ ∃ b ∈ L, nxt (L[i]'hi) = (b : ℤ) := by
    rw [hn]
    split_ifs with hi1
    · exact Or.inl rfl
    · exact Or.inr ⟨L[i + 1]'(by omega), List.getElem_mem (by omega), rfl⟩
  exact ⟨trivial, hp_or, hn_or⟩

private theorem list_getElem_eq_of_idx_eq {α : Type*} (xs : List α) {i j : ℕ}
    (hi : i < xs.length) (hj : j < xs.length) (h : i = j) :
    xs[i]'hi = xs[j]'hj := by
  subst h; rfl

private theorem getElem_mid_right {L : List ℕ} (L₁ L₂ : List ℕ) (k₀ idx i : ℕ)
    (hL : L = L₁ ++ k₀ :: L₂)
    (hidx : idx < L.length) (hi : i < L₂.length)
    (heq : idx = L₁.length + 1 + i) :
    L[idx]'hidx = L₂[i]'hi := by
  subst hL; subst heq
  rw [List.getElem_append_right (by omega)]
  have h1 : (k₀ :: L₂)[L₁.length + 1 + i - L₁.length]'(by simp; omega) =
      (k₀ :: L₂)[i + 1]'(by simp; omega) :=
    list_getElem_eq_of_idx_eq _ _ _ (by omega)
  exact h1.trans (by simp)

private theorem getElem_app_right (L₁ L₂ : List ℕ) (idx i : ℕ)
    (hidx : idx < (L₁ ++ L₂).length) (hi : i < L₂.length)
    (heq : idx = L₁.length + i) :
    (L₁ ++ L₂)[idx]'hidx = L₂[i]'hi := by
  subst heq
  rw [List.getElem_append_right (by omega)]
  exact list_getElem_eq_of_idx_eq _ _ _ (by omega)

theorem IsKeyDLL.unlink_of_nodup {L : List ℕ} {hd hd' tl tl' : ℤ}
    {prv prv' nxt nxt' : ℕ → ℤ} {k₀ : ℕ}
    (hdll : IsKeyDLL L hd tl prv nxt)
    (hnd : L.Nodup)
    (hk₀ : k₀ ∈ L)
    (hhd_unlink :
      if prv k₀ < 0 then
        hd' = nxt k₀ ∧ (∀ k ∈ L, k ≠ k₀ → nxt' k = nxt k)
      else
        hd' = hd ∧ (∀ a : ℕ, prv k₀ = (a : ℤ) → nxt' a = nxt k₀) ∧
          (∀ k ∈ L, (k : ℤ) ≠ prv k₀ → nxt' k = nxt k))
    (htl_unlink :
      if nxt k₀ < 0 then
        tl' = prv k₀ ∧ (∀ k ∈ L, k ≠ k₀ → prv' k = prv k)
      else
        tl' = tl ∧ (∀ b : ℕ, nxt k₀ = (b : ℤ) → prv' b = prv k₀) ∧
          (∀ k ∈ L, (k : ℤ) ≠ nxt k₀ → prv' k = prv k)) :
    IsKeyDLL (L.filter (fun x => decide (x ≠ k₀))) hd' tl' prv' nxt' := by
  have hne : L ≠ [] := List.ne_nil_of_mem hk₀
  obtain ⟨hhd0, htl0, hstep0⟩ := hdll.2 hne
  obtain ⟨L₁, L₂, hL_eq⟩ := List.append_of_mem hk₀
  have hnd_eq : (L₁ ++ k₀ :: L₂).Nodup := hL_eq ▸ hnd
  rcases List.nodup_append.mp hnd_eq with ⟨hnd₁, hnd_k₂, hdisj⟩
  rcases List.nodup_cons.mp hnd_k₂ with ⟨hk₀_not_L₂, hnd₂⟩
  have hk₀_not_L₁ : k₀ ∉ L₁ := fun hm => hdisj k₀ hm k₀ List.mem_cons_self rfl
  have hfilt1 : L₁.filter (fun x => decide (x ≠ k₀)) = L₁ :=
    List.filter_eq_self.mpr (fun x hx => decide_eq_true (fun heq => hk₀_not_L₁ (heq ▸ hx)))
  have hfilt2 : L₂.filter (fun x => decide (x ≠ k₀)) = L₂ :=
    List.filter_eq_self.mpr (fun x hx => decide_eq_true (fun heq => hk₀_not_L₂ (heq ▸ hx)))
  have hfilt : L.filter (fun x => decide (x ≠ k₀)) = L₁ ++ L₂ := by
    rw [hL_eq, List.filter_append, List.filter_cons_of_neg (by simp), hfilt1, hfilt2]
  rw [hfilt]
  have hi₀_lt : L₁.length < L.length := by rw [hL_eq]; simp
  have hget_k₀ : L[L₁.length]'hi₀_lt = k₀ := by
    simp only [hL_eq, List.getElem_append_right le_rfl, Nat.sub_self, List.getElem_cons_zero]
  rcases hstep0 L₁.length hi₀_lt with ⟨hprv_k₀_raw, hnxt_k₀_raw⟩
  rw [hget_k₀] at hprv_k₀_raw hnxt_k₀_raw
  have hlen_L : L.length = L₁.length + 1 + L₂.length := by rw [hL_eq]; simp; omega
  -- Evaluate `prv k₀` and `nxt k₀` against `L₁` and `L₂`
  have hprv_cases :
      (L₁ = [] ∧ prv k₀ = -1) ∨
      (∃ hpos₁ : 0 < L₁.length, prv k₀ = (L₁[L₁.length - 1]' (Nat.sub_lt hpos₁ Nat.one_pos) : ℤ)) := by
    by_cases h1 : L₁ = []
    · subst h1; left; refine ⟨rfl, ?_⟩; simpa using hprv_k₀_raw
    · right
      have hpos₁ : 0 < L₁.length := List.length_pos_iff.mpr h1
      refine ⟨hpos₁, ?_⟩
      rw [hprv_k₀_raw, dif_neg (by omega)]
      have hget_prev : L[L₁.length - 1]'(by omega) = L₁[L₁.length - 1]'(Nat.sub_lt hpos₁ Nat.one_pos) := by
        simp only [hL_eq, List.getElem_append_left (Nat.sub_lt hpos₁ Nat.one_pos)]
      rw [hget_prev]
  have hnxt_cases :
      (L₂ = [] ∧ nxt k₀ = -1) ∨
      (∃ hpos₂ : 0 < L₂.length, nxt k₀ = (L₂[0]'hpos₂ : ℤ)) := by
    by_cases h2 : L₂ = []
    · subst h2; left; refine ⟨rfl, ?_⟩
      rw [hnxt_k₀_raw, dif_pos (by simp [hL_eq])]
    · right
      have hpos₂ : 0 < L₂.length := List.length_pos_iff.mpr h2
      refine ⟨hpos₂, ?_⟩
      rw [hnxt_k₀_raw, dif_neg (by omega)]
      rw [getElem_mid_right L₁ L₂ k₀ (L₁.length + 1) 0 hL_eq (by omega) hpos₂ (by omega)]
  refine ⟨fun h_empty => ?_, fun hne_new => ?_⟩
  · obtain ⟨hL1_nil, hL2_nil⟩ := List.append_eq_nil_iff.mp h_empty
    have hp_m1 : prv k₀ = -1 := by
      rcases hprv_cases with ⟨_, h⟩ | ⟨hp1, _⟩
      · exact h
      · simp [hL1_nil] at hp1
    have hn_m1 : nxt k₀ = -1 := by
      rcases hnxt_cases with ⟨_, h⟩ | ⟨hp2, _⟩
      · exact h
      · simp [hL2_nil] at hp2
    rw [if_pos (by omega : prv k₀ < 0)] at hhd_unlink
    rw [if_pos (by omega : nxt k₀ < 0)] at htl_unlink
    exact ⟨hhd_unlink.1.trans hn_m1, htl_unlink.1.trans hp_m1⟩
  · have hpos_new : 0 < (L₁ ++ L₂).length := List.length_pos_iff.mpr hne_new
    refine ⟨?_, ?_, fun j hj => ?_⟩
    · -- New head `hd'`
      rcases hprv_cases with ⟨hL1_nil, hp_m1⟩ | ⟨hpos₁, hp_val⟩
      · subst hL1_nil
        rw [if_pos (by omega : prv k₀ < 0)] at hhd_unlink
        rcases hnxt_cases with ⟨hL2_nil, _⟩ | ⟨hpos₂, hn_val⟩
        · subst hL2_nil; simp at hne_new
        · simp [hhd_unlink.1, hn_val]
      · rw [if_neg (by rw [hp_val]; omega : ¬ prv k₀ < 0)] at hhd_unlink
        rw [hhd_unlink.1, hhd0, List.getElem_append_left hpos₁]
        simp only [hL_eq, List.getElem_append_left hpos₁]
    · -- New tail `tl'`
      rcases hnxt_cases with ⟨hL2_nil, hn_m1⟩ | ⟨hpos₂, hn_val⟩
      · subst hL2_nil
        rw [if_pos (by omega : nxt k₀ < 0)] at htl_unlink
        rcases hprv_cases with ⟨hL1_nil, _⟩ | ⟨hpos₁, hp_val⟩
        · subst hL1_nil; simp at hne_new
        · simp [htl_unlink.1, hp_val]
      · rw [if_neg (by rw [hn_val]; omega : ¬ nxt k₀ < 0)] at htl_unlink
        rw [htl_unlink.1, htl0]
        have hlen_new : (L₁ ++ L₂).length = L₁.length + L₂.length := List.length_append
        have hget1 : (L₁ ++ L₂)[(L₁ ++ L₂).length - 1]'(Nat.sub_lt hpos_new Nat.one_pos) =
            L₂[L₂.length - 1]'(Nat.sub_lt hpos₂ Nat.one_pos) :=
          getElem_app_right L₁ L₂ _ _ _ _ (by omega)
        have hget2 : L[L.length - 1]'(Nat.sub_lt (List.length_pos_iff.mpr hne) Nat.one_pos) =
            L₂[L₂.length - 1]'(Nat.sub_lt hpos₂ Nat.one_pos) :=
          getElem_mid_right L₁ L₂ k₀ _ _ hL_eq _ _ (by omega)
        rw [hget1, hget2]
    · -- `prv'` and `nxt'` at index `j < (L₁ ++ L₂).length`
      have hlen_new : (L₁ ++ L₂).length = L₁.length + L₂.length := List.length_append
      by_cases hj1 : j < L₁.length
      · -- Element in `L₁`: `x = L₁[j] = L[j]`
        have hget_new : (L₁ ++ L₂)[j]'hj = L₁[j]'hj1 := List.getElem_append_left hj1
        have hget_old : L[j]'(by omega) = L₁[j]'hj1 := by
          simp only [hL_eq, List.getElem_append_left hj1]
        have hmem_L1 : L₁[j]'hj1 ∈ L₁ := List.getElem_mem hj1
        have hmem_L : L₁[j]'hj1 ∈ L := by rw [hL_eq]; exact List.mem_append_left _ hmem_L1
        have hne_k0 : L₁[j]'hj1 ≠ k₀ := fun heq => hk₀_not_L₁ (heq ▸ hmem_L1)
        rcases hstep0 j (by omega) with ⟨hp_j, hn_j⟩
        rw [hget_old] at hp_j hn_j
        rw [hget_new]
        constructor
        · -- `prv' (L₁[j])`
          have hp_keep : prv' (L₁[j]'hj1) = prv (L₁[j]'hj1) := by
            rcases hnxt_cases with ⟨_, hn_m1⟩ | ⟨hpos₂, hn_val⟩
            · rw [if_pos (by omega : nxt k₀ < 0)] at htl_unlink
              exact htl_unlink.2 _ hmem_L hne_k0
            · rw [if_neg (by rw [hn_val]; omega : ¬ nxt k₀ < 0)] at htl_unlink
              refine htl_unlink.2.2 _ hmem_L ?_
              rw [hn_val]
              intro heq
              have hnat := Int.ofNat.inj heq
              exact hdisj _ hmem_L1 _ (List.mem_cons_of_mem k₀ (List.getElem_mem hpos₂)) hnat
          rw [hp_keep, hp_j]
          split_ifs with hj0
          · rfl
          · have hj1_sub : j - 1 < L₁.length := by omega
            have hprev_eq : L[j - 1]'(by omega) = (L₁ ++ L₂)[j - 1]'(by omega) := by
              rw [List.getElem_append_left hj1_sub]
              simp only [hL_eq, List.getElem_append_left hj1_sub]
            rw [hprev_eq]
        · -- `nxt' (L₁[j])`
          have hpos₁ : 0 < L₁.length := by omega
          have hp_val : prv k₀ = (L₁[L₁.length - 1]'(Nat.sub_lt hpos₁ Nat.one_pos) : ℤ) := by
            rcases hprv_cases with ⟨hL1_nil, _⟩ | ⟨_, hp_v⟩
            · subst hL1_nil; simp at hj1
            · exact hp_v
          rw [if_neg (by rw [hp_val]; omega : ¬ prv k₀ < 0)] at hhd_unlink
          by_cases hj_last : j + 1 = L₁.length
          · have hj_eq : j = L₁.length - 1 := by omega
            have hel_eq : L₁[j]'hj1 = L₁[L₁.length - 1]'(Nat.sub_lt hpos₁ Nat.one_pos) :=
              list_getElem_eq_of_idx_eq L₁ _ _ hj_eq
            rw [hel_eq, hhd_unlink.2.1 _ hp_val]
            rcases hnxt_cases with ⟨hL2_nil, hn_m1⟩ | ⟨hpos₂, hn_val⟩
            · subst hL2_nil
              rw [dif_pos (by simp [hj_last]), hn_m1]
            · rw [dif_neg (by rw [hlen_new]; omega), hn_val]
              have hget_r : (L₁ ++ L₂)[j + 1]'(by rw [hlen_new]; omega) = L₂[0]'hpos₂ :=
                getElem_app_right L₁ L₂ _ _ _ _ (by omega)
              rw [hget_r]
          · have hne_prv : ((L₁[j]'hj1 : ℕ) : ℤ) ≠ prv k₀ := by
              rw [hp_val]
              intro heq
              have hij := (hnd₁.getElem_inj_iff).mp (Int.ofNat.inj heq)
              omega
            rw [hhd_unlink.2.2 _ hmem_L hne_prv, hn_j,
                dif_neg (by omega), dif_neg (by rw [hlen_new]; omega)]
            have hj1_succ : j + 1 < L₁.length := by omega
            have hnext_eq : L[j + 1]'(by omega) = (L₁ ++ L₂)[j + 1]'(by rw [hlen_new]; omega) := by
              rw [List.getElem_append_left hj1_succ]
              simp only [hL_eq, List.getElem_append_left hj1_succ]
            rw [hnext_eq]
      · -- Element in `L₂`: `r = j - L₁.length < L₂.length`, `x = L₂[r] = L[j + 1]`
        have hr_lt : j - L₁.length < L₂.length := by rw [hlen_new] at hj; omega
        have hpos₂ : 0 < L₂.length := by omega
        have hget_new : (L₁ ++ L₂)[j]'hj = L₂[j - L₁.length]'hr_lt :=
          getElem_app_right L₁ L₂ _ _ _ _ (by omega)
        have hget_old : L[j + 1]'(by omega) = L₂[j - L₁.length]'hr_lt :=
          getElem_mid_right L₁ L₂ k₀ _ _ hL_eq _ _ (by omega)
        have hmem_L2 : L₂[j - L₁.length]'hr_lt ∈ L₂ := List.getElem_mem hr_lt
        have hmem_L : L₂[j - L₁.length]'hr_lt ∈ L := by
          rw [hL_eq]; exact List.mem_append_right _ (List.mem_cons_of_mem k₀ hmem_L2)
        have hne_k0 : L₂[j - L₁.length]'hr_lt ≠ k₀ := fun heq => hk₀_not_L₂ (heq ▸ hmem_L2)
        rcases hstep0 (j + 1) (by omega) with ⟨hp_j, hn_j⟩
        rw [hget_old] at hp_j hn_j
        rw [hget_new]
        have hn_val : nxt k₀ = (L₂[0]'hpos₂ : ℤ) := by
          rcases hnxt_cases with ⟨hL2_nil, _⟩ | ⟨_, hn_v⟩
          · subst hL2_nil; simp at hr_lt
          · exact hn_v
        rw [if_neg (by rw [hn_val]; omega : ¬ nxt k₀ < 0)] at htl_unlink
        constructor
        · -- `prv' (L₂[r])`
          by_cases hr0 : j - L₁.length = 0
          · have hj_eq : j = L₁.length := by omega
            have hel_eq : L₂[j - L₁.length]'hr_lt = L₂[0]'hpos₂ :=
              list_getElem_eq_of_idx_eq L₂ _ _ hr0
            rw [hel_eq, htl_unlink.2.1 _ hn_val]
            rcases hprv_cases with ⟨hL1_nil, hp_m1⟩ | ⟨hpos₁, hp_val⟩
            · subst hL1_nil
              have hj0 : j = 0 := by simp at hj_eq; exact hj_eq
              rw [dif_pos hj0, hp_m1]
            · rw [dif_neg (by omega : ¬ j = 0), hp_val]
              have hj1_sub : j - 1 < L₁.length := by omega
              have hget_l : (L₁ ++ L₂)[j - 1]'(by omega) =
                  L₁[L₁.length - 1]'(Nat.sub_lt hpos₁ Nat.one_pos) := by
                rw [List.getElem_append_left hj1_sub]
                exact list_getElem_eq_of_idx_eq L₁ _ _ (by omega)
              rw [hget_l]
          · have hne_nxt : ((L₂[j - L₁.length]'hr_lt : ℕ) : ℤ) ≠ nxt k₀ := by
              rw [hn_val]
              intro heq
              have hij := (hnd₂.getElem_inj_iff).mp (Int.ofNat.inj heq)
              omega
            rw [htl_unlink.2.2 _ hmem_L hne_nxt, hp_j,
                dif_neg (by omega), dif_neg (by omega)]
            have hprev_eq : L[(j + 1) - 1]'(by omega) = (L₁ ++ L₂)[j - 1]'(by omega) := by
              have h1 := getElem_mid_right L₁ L₂ k₀ ((j + 1) - 1) (j - 1 - L₁.length)
                hL_eq (by omega) (by omega) (by omega)
              have h2 := getElem_app_right L₁ L₂ (j - 1) (j - 1 - L₁.length)
                (by omega) (by omega) (by omega)
              exact h1.trans h2.symm
            rw [hprev_eq]
        · -- `nxt' (L₂[r])`
          have hn_keep : nxt' (L₂[j - L₁.length]'hr_lt) = nxt (L₂[j - L₁.length]'hr_lt) := by
            rcases hprv_cases with ⟨_, hp_m1⟩ | ⟨hpos₁, hp_val⟩
            · rw [if_pos (by omega : prv k₀ < 0)] at hhd_unlink
              exact hhd_unlink.2 _ hmem_L hne_k0
            · rw [if_neg (by rw [hp_val]; omega : ¬ prv k₀ < 0)] at hhd_unlink
              refine hhd_unlink.2.2 _ hmem_L ?_
              rw [hp_val]
              intro heq
              have hnat := Int.ofNat.inj heq
              exact hdisj _ (List.getElem_mem (Nat.sub_lt hpos₁ Nat.one_pos))
                _ (List.mem_cons_of_mem k₀ hmem_L2) hnat.symm
          rw [hn_keep, hn_j]
          by_cases hj_end : j + 1 = (L₁ ++ L₂).length
          · rw [dif_pos (by rw [hlen_new] at hj_end; omega), dif_pos hj_end]
          · rw [dif_neg (by rw [hlen_new] at hj_end; omega), dif_neg hj_end]
            have hnext_eq : L[(j + 1) + 1]'(by omega) = (L₁ ++ L₂)[j + 1]'(by rw [hlen_new] at hj_end ⊢; omega) := by
              have h1 := getElem_mid_right L₁ L₂ k₀ ((j + 1) + 1) (j + 1 - L₁.length)
                hL_eq (by omega) (by rw [hlen_new] at hj_end; omega) (by omega)
              have h2 := getElem_app_right L₁ L₂ (j + 1) (j + 1 - L₁.length)
                (by rw [hlen_new] at hj_end ⊢; omega) (by rw [hlen_new] at hj_end; omega) (by omega)
              exact h1.trans h2.symm
            rw [hnext_eq]

/-! ### 2. Single-Write `inIdx` Transition Helpers for `EncLocalMatching` -/

theorem EncLocalMatching.write_inIdxL_zero {tblW : ℕ} {cfgBaseW : ℤ} {n : ℕ}
    {st st' : LocalMatchingState ℕ} {m : ArithRAMMemory} (w : ℕ) (hw : w < n)
    (henc : EncLocalMatching tblW cfgBaseW n st m)
    (hpairs : st'.matchingList.map MatchingEdge.pair = st.matchingList.map MatchingEdge.pair)
    (hUL : st'.leftIndexSet = st.leftIndexSet.erase w)
    (hUR : st'.rightIndexSet = st.rightIndexSet) :
    EncLocalMatching tblW cfgBaseW n st' (H3a.wWrite m tblW (cfgInIdxLEpOff cfgBaseW n w) 0) := by
  rcases henc with ⟨ep, hep1, hep_r, hndL, hndR, hpairs_lt, hUL_lt, hUR_lt,
    hdll, hmL_le, hmL_to, hmL_of, hmR_le, hmR_to, hmR_of, hiL, hiR⟩
  let m' := H3a.wWrite m tblW (cfgInIdxLEpOff cfgBaseW n w) 0
  have hL_lt : ∀ k ∈ (st.matchingList.map MatchingEdge.pair).map Prod.fst, k < n := by
    intro k hk; rcases List.mem_map.mp hk with ⟨xy, hxy, rfl⟩; exact (hpairs_lt xy hxy).1
  refine ⟨ep, hep1,
    (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgInIdxLEpOff; omega))).trans hep_r,
    by rwa [hpairs], by rwa [hpairs], by rwa [hpairs],
    fun u hu => hUL_lt u (Finset.mem_of_mem_erase (hUL ▸ hu)),
    by rwa [hUR],
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpairs]
    exact hdll.congr
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgInIdxLEpOff; omega)))
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgInIdxLEpOff; omega)))
      (fun k hk => by have := hL_lt k hk; exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgInIdxLEpOff; omega)))
      (fun k hk => by have := hL_lt k hk; exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgInIdxLEpOff; omega)))
  · intro u hu; rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxLEpOff; omega))]; exact hmL_le u hu
  · intro u hu h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxLEpOff; omega))] at h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgInIdxLEpOff; omega)), hpairs]
    exact hmL_to u hu h
  · intro x y hxy
    rw [hpairs] at hxy
    have hx := (hpairs_lt (x, y) hxy).1
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgInIdxLEpOff; omega))]
    exact hmL_of x y hxy
  · intro u hu; rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxLEpOff; omega))]; exact hmR_le u hu
  · intro u hu h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxLEpOff; omega))] at h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgInIdxLEpOff; omega)), hpairs]
    exact hmR_to u hu h
  · intro x y hxy
    rw [hpairs] at hxy
    have hy := (hpairs_lt (x, y) hxy).2
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgInIdxLEpOff; omega))]
    exact hmR_of x y hxy
  · intro u hu
    rw [hUL]
    by_cases huw : u = w
    · subst huw
      change H3a.wRead m' tblW _ ≤ _ ∧ (H3a.wRead m' tblW _ = _ ↔ _)
      rw [wRead_wWrite_self]
      exact ⟨by omega, ⟨fun h => by omega, fun h => False.elim ((Finset.mem_erase.mp h).1 rfl)⟩⟩
    · change H3a.wRead m' tblW _ ≤ _ ∧ (H3a.wRead m' tblW _ = _ ↔ _)
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff; omega))]
      refine ⟨(hiL u hu).1, ?_⟩
      rw [(hiL u hu).2, Finset.mem_erase]
      exact ⟨fun hm => ⟨huw, hm⟩, fun h => h.2⟩
  · intro u hu
    rw [hUR, wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff cfgInIdxLEpOff; omega))]
    exact hiR u hu

theorem EncLocalMatching.write_inIdxR_zero {tblW : ℕ} {cfgBaseW : ℤ} {n : ℕ}
    {st st' : LocalMatchingState ℕ} {m : ArithRAMMemory} (w : ℕ) (hw : w < n)
    (henc : EncLocalMatching tblW cfgBaseW n st m)
    (hpairs : st'.matchingList.map MatchingEdge.pair = st.matchingList.map MatchingEdge.pair)
    (hUL : st'.leftIndexSet = st.leftIndexSet)
    (hUR : st'.rightIndexSet = st.rightIndexSet.erase w) :
    EncLocalMatching tblW cfgBaseW n st' (H3a.wWrite m tblW (cfgInIdxREpOff cfgBaseW n w) 0) := by
  rcases henc with ⟨ep, hep1, hep_r, hndL, hndR, hpairs_lt, hUL_lt, hUR_lt,
    hdll, hmL_le, hmL_to, hmL_of, hmR_le, hmR_to, hmR_of, hiL, hiR⟩
  let m' := H3a.wWrite m tblW (cfgInIdxREpOff cfgBaseW n w) 0
  have hL_lt : ∀ k ∈ (st.matchingList.map MatchingEdge.pair).map Prod.fst, k < n := by
    intro k hk; rcases List.mem_map.mp hk with ⟨xy, hxy, rfl⟩; exact (hpairs_lt xy hxy).1
  refine ⟨ep, hep1,
    (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgInIdxREpOff; omega))).trans hep_r,
    by rwa [hpairs], by rwa [hpairs], by rwa [hpairs],
    by rwa [hUL],
    fun u hu => hUR_lt u (Finset.mem_of_mem_erase (hUR ▸ hu)),
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpairs]
    exact hdll.congr
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgInIdxREpOff; omega)))
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgInIdxREpOff; omega)))
      (fun k hk => by have := hL_lt k hk; exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgInIdxREpOff; omega)))
      (fun k hk => by have := hL_lt k hk; exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgInIdxREpOff; omega)))
  · intro u hu; rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxREpOff; omega))]; exact hmL_le u hu
  · intro u hu h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxREpOff; omega))] at h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgInIdxREpOff; omega)), hpairs]
    exact hmL_to u hu h
  · intro x y hxy
    rw [hpairs] at hxy
    have hx := (hpairs_lt (x, y) hxy).1
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgInIdxREpOff; omega))]
    exact hmL_of x y hxy
  · intro u hu; rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxREpOff; omega))]; exact hmR_le u hu
  · intro u hu h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxREpOff; omega))] at h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgInIdxREpOff; omega)), hpairs]
    exact hmR_to u hu h
  · intro x y hxy
    rw [hpairs] at hxy
    have hy := (hpairs_lt (x, y) hxy).2
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgInIdxREpOff; omega))]
    exact hmR_of x y hxy
  · intro u hu
    rw [hUL, wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff cfgInIdxREpOff; omega))]
    exact hiL u hu
  · intro u hu
    rw [hUR]
    by_cases huw : u = w
    · subst huw
      change H3a.wRead m' tblW _ ≤ _ ∧ (H3a.wRead m' tblW _ = _ ↔ _)
      rw [wRead_wWrite_self]
      exact ⟨by omega, ⟨fun h => by omega, fun h => False.elim ((Finset.mem_erase.mp h).1 rfl)⟩⟩
    · change H3a.wRead m' tblW _ ≤ _ ∧ (H3a.wRead m' tblW _ = _ ↔ _)
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff; omega))]
      refine ⟨(hiR u hu).1, ?_⟩
      rw [(hiR u hu).2, Finset.mem_erase]
      exact ⟨fun hm => ⟨huw, hm⟩, fun h => h.2⟩

theorem EncLocalMatching.write_inIdxL_ep {tblW : ℕ} {cfgBaseW : ℤ} {n : ℕ}
    {st st' : LocalMatchingState ℕ} {m : ArithRAMMemory} (v : ℕ) (hv : v < n)
    (henc : EncLocalMatching tblW cfgBaseW n st m)
    (hpairs : st'.matchingList.map MatchingEdge.pair = st.matchingList.map MatchingEdge.pair)
    (hUL : st'.leftIndexSet = insert v st.leftIndexSet)
    (hUR : st'.rightIndexSet = st.rightIndexSet) :
    EncLocalMatching tblW cfgBaseW n st'
      (H3a.wWrite m tblW (cfgInIdxLEpOff cfgBaseW n v) (H3a.wRead m tblW (cfgEpOff cfgBaseW))) := by
  rcases henc with ⟨ep, hep1, hep_r, hndL, hndR, hpairs_lt, hUL_lt, hUR_lt,
    hdll, hmL_le, hmL_to, hmL_of, hmR_le, hmR_to, hmR_of, hiL, hiR⟩
  rw [hep_r]
  let m' := H3a.wWrite m tblW (cfgInIdxLEpOff cfgBaseW n v) (ep : ℤ)
  have hL_lt : ∀ k ∈ (st.matchingList.map MatchingEdge.pair).map Prod.fst, k < n := by
    intro k hk; rcases List.mem_map.mp hk with ⟨xy, hxy, rfl⟩; exact (hpairs_lt xy hxy).1
  refine ⟨ep, hep1,
    (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgInIdxLEpOff; omega))).trans hep_r,
    by rwa [hpairs], by rwa [hpairs], by rwa [hpairs],
    fun u hu => by rw [hUL] at hu; rcases Finset.mem_insert.mp hu with rfl | hm; exact hv; exact hUL_lt u hm,
    by rwa [hUR],
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpairs]
    exact hdll.congr
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgInIdxLEpOff; omega)))
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgInIdxLEpOff; omega)))
      (fun k hk => by have := hL_lt k hk; exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgInIdxLEpOff; omega)))
      (fun k hk => by have := hL_lt k hk; exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgInIdxLEpOff; omega)))
  · intro u hu; rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxLEpOff; omega))]; exact hmL_le u hu
  · intro u hu h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxLEpOff; omega))] at h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgInIdxLEpOff; omega)), hpairs]
    exact hmL_to u hu h
  · intro x y hxy
    rw [hpairs] at hxy
    have hx := (hpairs_lt (x, y) hxy).1
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgInIdxLEpOff; omega))]
    exact hmL_of x y hxy
  · intro u hu; rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxLEpOff; omega))]; exact hmR_le u hu
  · intro u hu h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxLEpOff; omega))] at h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgInIdxLEpOff; omega)), hpairs]
    exact hmR_to u hu h
  · intro x y hxy
    rw [hpairs] at hxy
    have hy := (hpairs_lt (x, y) hxy).2
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxLEpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgInIdxLEpOff; omega))]
    exact hmR_of x y hxy
  · intro u hu
    rw [hUL]
    by_cases huv : u = v
    · subst huv
      change H3a.wRead m' tblW _ ≤ _ ∧ (H3a.wRead m' tblW _ = _ ↔ _)
      rw [wRead_wWrite_self]
      exact ⟨le_rfl, ⟨fun _ => Finset.mem_insert_self _ _, fun _ => rfl⟩⟩
    · change H3a.wRead m' tblW _ ≤ _ ∧ (H3a.wRead m' tblW _ = _ ↔ _)
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff; omega))]
      refine ⟨(hiL u hu).1, ?_⟩
      rw [(hiL u hu).2, Finset.mem_insert]
      exact ⟨Or.inr, fun h => h.resolve_left huv⟩
  · intro u hu
    rw [hUR, wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff cfgInIdxLEpOff; omega))]
    exact hiR u hu

theorem EncLocalMatching.write_inIdxR_ep {tblW : ℕ} {cfgBaseW : ℤ} {n : ℕ}
    {st st' : LocalMatchingState ℕ} {m : ArithRAMMemory} (v : ℕ) (hv : v < n)
    (henc : EncLocalMatching tblW cfgBaseW n st m)
    (hpairs : st'.matchingList.map MatchingEdge.pair = st.matchingList.map MatchingEdge.pair)
    (hUL : st'.leftIndexSet = st.leftIndexSet)
    (hUR : st'.rightIndexSet = insert v st.rightIndexSet) :
    EncLocalMatching tblW cfgBaseW n st'
      (H3a.wWrite m tblW (cfgInIdxREpOff cfgBaseW n v) (H3a.wRead m tblW (cfgEpOff cfgBaseW))) := by
  rcases henc with ⟨ep, hep1, hep_r, hndL, hndR, hpairs_lt, hUL_lt, hUR_lt,
    hdll, hmL_le, hmL_to, hmL_of, hmR_le, hmR_to, hmR_of, hiL, hiR⟩
  rw [hep_r]
  let m' := H3a.wWrite m tblW (cfgInIdxREpOff cfgBaseW n v) (ep : ℤ)
  have hL_lt : ∀ k ∈ (st.matchingList.map MatchingEdge.pair).map Prod.fst, k < n := by
    intro k hk; rcases List.mem_map.mp hk with ⟨xy, hxy, rfl⟩; exact (hpairs_lt xy hxy).1
  refine ⟨ep, hep1,
    (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgEpOff cfgInIdxREpOff; omega))).trans hep_r,
    by rwa [hpairs], by rwa [hpairs], by rwa [hpairs],
    by rwa [hUL],
    fun u hu => by rw [hUR] at hu; rcases Finset.mem_insert.mp hu with rfl | hm; exact hv; exact hUR_lt u hm,
    ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpairs]
    exact hdll.congr
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgHeadOff cfgInIdxREpOff; omega)))
      (wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgTailOff cfgInIdxREpOff; omega)))
      (fun k hk => by have := hL_lt k hk; exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgPrevOff cfgInIdxREpOff; omega)))
      (fun k hk => by have := hL_lt k hk; exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgNextOff cfgInIdxREpOff; omega)))
  · intro u hu; rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxREpOff; omega))]; exact hmL_le u hu
  · intro u hu h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxREpOff; omega))] at h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgInIdxREpOff; omega)), hpairs]
    exact hmL_to u hu h
  · intro x y hxy
    rw [hpairs] at hxy
    have hx := (hpairs_lt (x, y) hxy).1
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLEpOff cfgInIdxREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateLValOff cfgInIdxREpOff; omega))]
    exact hmL_of x y hxy
  · intro u hu; rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxREpOff; omega))]; exact hmR_le u hu
  · intro u hu h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxREpOff; omega))] at h
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgInIdxREpOff; omega)), hpairs]
    exact hmR_to u hu h
  · intro x y hxy
    rw [hpairs] at hxy
    have hy := (hpairs_lt (x, y) hxy).2
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateREpOff cfgInIdxREpOff; omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgMateRValOff cfgInIdxREpOff; omega))]
    exact hmR_of x y hxy
  · intro u hu
    rw [hUL, wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxLEpOff cfgInIdxREpOff; omega))]
    exact hiL u hu
  · intro u hu
    rw [hUR]
    by_cases huv : u = v
    · subst huv
      change H3a.wRead m' tblW _ ≤ _ ∧ (H3a.wRead m' tblW _ = _ ↔ _)
      rw [wRead_wWrite_self]
      exact ⟨le_rfl, ⟨fun _ => Finset.mem_insert_self _ _, fun _ => rfl⟩⟩
    · change H3a.wRead m' tblW _ ≤ _ ∧ (H3a.wRead m' tblW _ = _ ↔ _)
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold cfgInIdxREpOff; omega))]
      refine ⟨(hiR u hu).1, ?_⟩
      rw [(hiR u hu).2, Finset.mem_insert]
      exact ⟨Or.inr, fun h => h.resolve_left huv⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
