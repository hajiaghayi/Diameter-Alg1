import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeB2b

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

/-! ### 5b. `managedNodeInsertMatStmt` (`H4c2.ManagedNode.insertMat`) -/

def managedNodeInsertMatCost {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) (K_seg N_cfg : ℕ) : ℕ :=
  1050 + 110 * d + 380 * K_seg + N_cfg * (ops.insertCost + 60)

def managedNodeInsertMatStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wNodeBaseW)
  let bRE := IntExpr.readHeap scrW (.lit wNodeBaseR)
  let wPoolB := wScr
  let wRadBR := wScr + 1
  let wOffO := wScr + 2
  let wFlag := wScr + 4
  let wHistLen := wScr + 5
  let wSubScr := wScr + 10
  let histOffVal : ℤ := 8 + 2 * swapPoolStride n
  let radWOffVal : ℤ := histOffVal + (1 + (cap_hist : ℤ))
  let radROffVal : ℤ := (d : ℤ) + 2
  -- 1. Dense pool insert
  .seq (.writeWordHeap scrW (.lit wPoolB) (.add bWE (.lit 8)))
  (.seq (swapPoolInsertStmt scrW tblW wPoolB wUid wSubScr n)
  -- 2. RadTree leaf insert
  (.seq (.writeWordHeap scrW (.lit wPoolB) (.add bWE (.lit radWOffVal)))
  (.seq (.writeWordHeap scrW (.lit wRadBR) (.add bRE (.lit radROffVal)))
  (.seq (.writeWordHeap scrW (.lit wOffO) bRE)
  (.seq (.writeWordHeap scrW (.lit wFlag) (.lit 1))
  (.seq (radTreeUpdateLeafStmt scrW scrR tblW tblR tblR
          wPoolB wRadBR wOffO wUid wFlag wSubScr rScr K_seg n d)
  -- 3. Append p to histArr
  (.seq (.writeWordHeap scrW (.lit wHistLen) (.readHeap tblW (.add bWE (.lit histOffVal))))
  (.seq (.writeWordHeap tblW
          (.add (.add bWE (.lit (histOffVal + 1))) (.readHeap scrW (.lit wHistLen)))
          (.readHeap scrW (.lit wUid)))
  (.seq (.writeWordHeap tblW (.add bWE (.lit histOffVal))
          (.add (.readHeap scrW (.lit wHistLen)) (.lit 1)))
  -- 4. Residual pool conditional insert
  (.seq (passesNodeStmt scrW scrR tblR wNodeBaseR wUid wFlag wSubScr rScr d)
  (.seq (.ite (.intEq (.readHeap scrW (.lit wFlag)) (.lit 1))
          (.seq (.writeWordHeap scrW (.lit wPoolB) (.add bWE (.lit (8 + swapPoolStride n))))
                (swapPoolInsertStmt scrW tblW wPoolB wUid wSubScr n))
          .skip)
  -- 5. N_cfg conditional insert
        (managedNodeInsertCfgsStmt ops specs cap_hist K_seg
          wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr))))))))))))

theorem zeroRand_managedNodeInsertMatStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr : ℤ) :
    ZeroRandStmt (managedNodeInsertMatStmt ops specs cap_hist K_seg
      wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr) := by
  unfold managedNodeInsertMatStmt
  exact .seq (.writeWordHeap _ _ _)
    (.seq (hzr_to_zeroRand (hzr_swapPoolInsertStmt _ _ _ _ _ _))
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (hzr_to_zeroRand (hzr_radTreeUpdateLeafStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _))
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_passesNodeStmt _ _ _ _ _ _ _ _ _)
    (.seq (.ite (.seq (.writeWordHeap _ _ _) (hzr_to_zeroRand (hzr_swapPoolInsertStmt _ _ _ _ _ _))) .skip)
          (zeroRand_managedNodeInsertCfgsStmt _ _ _ _ _ _ _ _ _ _))))))))))))

theorem exec_managedNodeInsertMatStmt
    {d TW BW TR BR n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (hM₀ : 1 ≤ M₀) (hn : 2 ≤ n) (hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (hn_K : n ≤ 2 ^ K_seg)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr nodeBaseW nodeBaseR nodeSeedOff : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg} {bp : Option (ℕ × ℕ)}
    {p : ℕ} (hp_not : p ∉ mn.nd.curSet) (hp_lt : p < n)
    (hS_lt : ∀ x ∈ mn.nd.curSet, x < n)
    (hS_card : mn.nd.curSet.card + 1 ≤ n)
    (hhist_cap : mn.histArr.length + 1 ≤ cap_hist)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    {bound : ℕ} (ht_bnd : mn.nd.maxTIns bound) (ht_cap : bound + 1 < 2 ^ L_p2)
    (hwf_mn : ManagedNodeWF hM₀ T_cdf p_coord params specs τ_d cap_u pts mn)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbls : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ nodeBaseW ∧
      nodeBaseW + managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride ≤ (BW : ℤ))
    (hbaseR : 0 ≤ nodeBaseR ∧
      nodeBaseR + managedNodeRStride d K_seg N_cfg ops.cfgRStride ≤ (BR : ℤ))
    (hseedB : 0 ≤ nodeSeedOff ∧
      nodeSeedOff + (nodeOpSeedBits N_cfg L_p2 R ℓ M₀ d b : ℤ) ≤ (BW : ℤ))
    (hptsB : ((n * d : ℕ) : ℤ) ≤ (BR : ℤ))
    (hwBW : 0 ≤ wNodeBaseW ∧ wNodeBaseW < wScr)
    (hwBR : 0 ≤ wNodeBaseR ∧ wNodeBaseR < wScr)
    (hwUid : 0 ≤ wUid ∧ wUid < wScr)
    (hwSO : 0 ≤ wNodeSeedOff ∧ wNodeSeedOff < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + managedNodeMatWScr ops ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + managedNodeMatRScr ops ≤ (BR : ℤ))
    (hbW : H3a.wRead m₀ scrW wNodeBaseW = nodeBaseW)
    (hbR : H3a.wRead m₀ scrW wNodeBaseR = nodeBaseR)
    (huid : H3a.wRead m₀ scrW wUid = (p : ℤ))
    (hseed_reg : H3a.wRead m₀ scrW wNodeSeedOff = nodeSeedOff)
    (hpts_r : ∀ x ∈ Insert.insert p mn.nd.curSet, ∀ c : Fin d,
      H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hseed_enc : EncNodeOpSeedSlice coinTbl nodeSeedOff ω m₀)
    (henc : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₀) :
    let mn' := mn.insertMat hM₀ T_cdf p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (managedNodeInsertMatStmt ops specs cap_hist K_seg
        wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr)
        m₀ m₁ (managedNodeInsertMatCost ops K_seg N_cfg) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn' bp m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW nodeBaseW
        (managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride)
        tblR nodeBaseR (managedNodeRStride d K_seg N_cfg ops.cfgRStride) m₀ m₁ := by
  intro mn'
  have hn1 : 1 ≤ n := by omega
  have hcfgW := ops.hcfgW_nonneg
  have hcfgR := ops.hcfgR_nonneg
  have hw_op := ops.hopWScr_pos
  have hr_op := ops.hopRScr_pos
  have hrad4 := radTreeWStride_ge_four K_seg
  have hradR := radTreeRStride_nonneg K_seg
  have hncfgW : 0 ≤ (N_cfg : ℤ) * ops.cfgWStride := mul_nonneg (Nat.cast_nonneg _) hcfgW
  have hncfgR : 0 ≤ (N_cfg : ℤ) * ops.cfgRStride := mul_nonneg (Nat.cast_nonneg _) hcfgR
  let W_tot := managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride
  let R_tot := managedNodeRStride d K_seg N_cfg ops.cfgRStride
  have hwScr_orig := hwScr
  have hrScr_orig := hrScr
  unfold managedNodeMatWScr at hwScr
  unfold managedNodeMatRScr at hrScr
  have hneW := htbls.2.2.2.2.2.2.1
  have hneCoinScr := htbls.2.2.2.2.2.2.2.1
  have hneCoinW := htbls.2.2.2.2.2.2.2.2.1
  have hneR := htbls.2.2.2.2.2.2.2.2.2.1
  have hne1Scr := htbls.2.2.2.2.2.2.2.2.2.2.1
  have hne1R := htbls.2.2.2.2.2.2.2.2.2.2.2
  rcases henc with ⟨hb_e, ha_e, hbp_e, ho_e, hs_e, hV_e, _, hh_len, hh_el,
    ⟨Pd, hPd_wf, hPd_l, hPd_e⟩, ⟨Pr, hPr_wf, hPr_l, hPr_e⟩, ⟨Tr, hTr_wf, hTr_e⟩, hcfgs_e⟩
  let histOffVal : ℤ := 8 + 2 * swapPoolStride n
  let radWOffVal : ℤ := histOffVal + (1 + (cap_hist : ℤ))
  let radROffVal : ℤ := (d : ℤ) + 2
  -- === Step 1: Dense pool insert ===
  let m1a := H3a.wWrite m₀ scrW wScr (nodeDensePoolOff nodeBaseW)
  have hd1a : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit 8))) m₀ m1a 15 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW _ _ rfl
      (by change H3a.wRead m₀ scrW wNodeBaseW + 8 = nodeDensePoolOff nodeBaseW; rw [hbW]; rfl)
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1a : InFootprint TW BW TR BR m1a := InFootprint.wWrite hfp₀ htbls.1 hwScr.1 (by omega)
  have hPd_1a : EncSwapPool tblW (nodeDensePoolOff nodeBaseW) n Pd m1a :=
    hPd_e.mono_frame (WordFrameOutside.wWrite_scr scrW tblW (nodeDensePoolOff nodeBaseW) 0 m₀ wScr (nodeDensePoolOff nodeBaseW))
      hneW (Or.inr (Or.inr (by omega))) hPd_wf.2.2.2.1
  obtain ⟨m1, hd1b, hfp1, hPd'_e, _, _, hfr1_w⟩ :=
    exec_swapPoolInsertStmt inp wScr wUid (wScr + 10) (nodeDensePoolOff nodeBaseW) hn1 hPd_wf p
      hfp1a htbls.1 htbls.2.1 hneW
      ⟨by unfold nodeDensePoolOff; omega, by unfold nodeDensePoolOff; try dsimp [W_tot] at *; unfold managedNodeWStride swapPoolStride at *; omega⟩
      ⟨by omega, by omega⟩ (by omega) (by omega)
      (wRead_wWrite_self _ _ _ _)
      (by dsimp [m1a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), huid]) hPd_1a
  have hw1_sub := detExec_preserves_scr_below (psb_swapPoolInsertStmt hneW (wBound := wScr + 10) le_rfl) hfp1a hfp1 hd1b
  have hw01 : ∀ w, w < wScr → H3a.wRead m1 scrW w = H3a.wRead m₀ scrW w := fun w hw =>
    (hw1_sub w (by omega)).trans (wRead_wWrite_of_ne _ _ (Or.inr (by omega)))
  have hfr01_dense : RadFrameOutside scrW scrR tblW (nodeDensePoolOff nodeBaseW) (swapPoolStride n) tblR 0 0 m₀ m1 :=
    (radFrame_wWrite_scr scrW scrR tblW (nodeDensePoolOff nodeBaseW) (swapPoolStride n) tblR 0 0 m₀ wScr (nodeDensePoolOff nodeBaseW)).trans
      (radFrame_of_wordFrame hfr1_w)
  obtain ⟨hPd'_wf, hPd'_l⟩ := swapPoolToList_insert hn1 hPd_wf hPd_l hp_lt hp_not hS_card hS_lt
  -- === Step 2: RadTree leaf insert ===
  let rBW := nodeRadTreeWOff n cap_hist nodeBaseW
  let rBR := nodeRadTreeROff d nodeBaseR
  let m2a := H3a.wWrite m1 scrW wScr rBW
  let m2b := H3a.wWrite m2a scrW (wScr + 1) rBR
  let m2c := H3a.wWrite m2b scrW (wScr + 2) nodeBaseR
  let m2d := H3a.wWrite m2c scrW (wScr + 4) 1
  have hd2a : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit radWOffVal))) m1 m2a 15 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW _ _ rfl
      (by change H3a.wRead m1 scrW wNodeBaseW + radWOffVal = rBW
          rw [hw01 wNodeBaseW hwBW.2, hbW]; dsimp [rBW, radWOffVal, histOffVal]; unfold nodeRadTreeWOff nodeHistOff; ring)
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp2a : InFootprint TW BW TR BR m2a := InFootprint.wWrite hfp1 htbls.1 hwScr.1 (by omega)
  have hd2b : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
      (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit radROffVal))) m2a m2b 15 :=
    DetExecAt.writeWordHeap 0 inp m2a scrW _ _ rfl
      (by change H3a.wRead m2a scrW wNodeBaseR + radROffVal = rBR
          dsimp [m2a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw01 wNodeBaseR hwBR.2, hbR]
          dsimp [rBR, radROffVal]; unfold nodeRadTreeROff; ring)
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp2b : InFootprint TW BW TR BR m2b := InFootprint.wWrite hfp2a htbls.1 (by omega) (by omega)
  have hd2c : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2)) (.readHeap scrW (.lit wNodeBaseR))) m2b m2c 15 :=
    DetExecAt.writeWordHeap 0 inp m2b scrW _ _ rfl
      (by change H3a.wRead m2b scrW wNodeBaseR = nodeBaseR
          dsimp [m2b, m2a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hw01 wNodeBaseR hwBR.2, hbR])
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp2c : InFootprint TW BW TR BR m2c := InFootprint.wWrite hfp2b htbls.1 (by omega) (by omega)
  have hd2d : DetExec inp (.writeWordHeap scrW (.lit (wScr + 4)) (.lit 1)) m2c m2d 10 :=
    DetExecAt.writeWordHeap 0 inp m2c scrW _ _ rfl rfl
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp2d : InFootprint TW BW TR BR m2d := InFootprint.wWrite hfp2c htbls.1 (by omega) (by omega)
  have hfr1_2d : RadFrameOutside scrW scrR tblW rBW 0 tblR rBR 0 m1 m2d :=
    ⟨fun t i hts _ => by
       dsimp [m2d, m2c, m2b, m2a]
       repeat rw [wRead_wWrite_of_ne _ _ (Or.inl hts)],
     fun _ _ _ _ => rfl⟩
  have hTr_2d : EncEpochRadTree tblW rBW tblR rBR K_seg Tr m2d := by
    have hTr_1 : EncEpochRadTree tblW rBW tblR rBR K_seg Tr m1 :=
      hTr_e.mono_frame hfr01_dense hneW hneR
        (Or.inr (Or.inr (by unfold nodeRadTreeWOff nodeHistOff nodeDensePoolOff swapPoolStride; omega)))
        (Or.inr (Or.inr (by unfold nodeRadTreeROff; omega)))
    exact hTr_1.mono_frame hfr1_2d hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  obtain ⟨m2, hd2e, hfp2, hTr'_e, _, hfr2_rad⟩ :=
    exec_radTreeUpdateLeafStmt inp wScr (wScr + 1) (wScr + 2) wUid (wScr + 4) (wScr + 10) rScr
      rBW rBR nodeBaseR hn1 hn_K p true (pts p) mn.nd.o Tr
      hfp2d htbls.1 htbls.2.2.2.1 htbls.2.1 htbls.2.2.2.2.1 hneW hneR hne1Scr hneR
      ⟨by try dsimp [rBW]; unfold nodeRadTreeWOff nodeHistOff swapPoolStride; omega,
       by try dsimp [rBW]; try dsimp [W_tot] at *; unfold nodeRadTreeWOff nodeHistOff managedNodeWStride swapPoolStride at *; omega⟩
      ⟨by try dsimp [rBR]; unfold nodeRadTreeROff; omega,
       by try dsimp [rBR]; try dsimp [R_tot] at *; unfold nodeRadTreeROff managedNodeRStride at *; omega⟩
      ⟨by omega, by omega⟩ ⟨hrScr.1, by omega⟩
      ⟨Or.inl (by omega), Or.inl (by omega), Or.inl (by omega), Or.inl (by omega), Or.inl (by omega)⟩
      (by dsimp [m2d, m2c, m2b, m2a]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
      (by dsimp [m2d, m2c, m2b]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_self])
      (by dsimp [m2d, m2c]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
      (by dsimp [m2d, m2c, m2b, m2a]
          repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          rw [hw01 wUid hwUid.2, huid])
      (wRead_wWrite_self _ _ _ _)
      (fun _ c => by
        have hmod : p % n = p := Nat.mod_eq_of_lt hp_lt
        have hcast : (((p % n : ℕ) : ℤ) * (d : ℤ) + (c.val : ℤ)) = (((p * d + c.val : ℕ) : ℤ)) := by
          rw [hmod]; push_cast; ring
        rw [hcast]
        have hr1 : H3a.rRead m2d 1 (((p * d + c.val : ℕ) : ℤ)) = H3a.rRead m₀ 1 (((p * d + c.val : ℕ) : ℤ)) :=
          hfr01_dense.2 1 _ hne1Scr (Or.inl hne1R)
        rw [hr1]; exact hpts_r p (Finset.mem_insert_self _ _) c)
      (fun _ c => by
        have hrO : H3a.rRead m2d tblR (nodeBaseR + (c.val : ℤ)) = H3a.rRead m₀ tblR (nodeBaseR + (c.val : ℤ)) :=
          hfr01_dense.2 tblR _ hneR (Or.inr (by omega))
        rw [hrO]; exact ho_e c)
      hTr_2d
  have hw2_sub := detExec_preserves_scr_below (psb_radTreeUpdateLeafStmt hneW (wBound := wScr + 10) le_rfl) hfp2d hfp2 hd2e
  have hw12 : ∀ w, w < wScr → H3a.wRead m2 scrW w = H3a.wRead m1 scrW w := fun w hw => by
    rw [hw2_sub w (by omega)]; dsimp [m2d, m2c, m2b, m2a]
    repeat rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  have hfr12_rad : RadFrameOutside scrW scrR tblW rBW (radTreeWStride K_seg) tblR rBR (radTreeRStride K_seg) m1 m2 :=
    (RadFrameOutside_mono_range (bW₂ := rBW) (lW₂ := radTreeWStride K_seg) (bR₂ := rBR) (lR₂ := radTreeRStride K_seg)
      hfr1_2d (Or.inl rfl) (Or.inl rfl)).trans hfr2_rad
  have hTr'_wf := radTreeExactWF_insert hn_K hTr_wf hp_lt
  -- === Step 3: Append p to histArr ===
  let hBase := nodeHistOff n nodeBaseW
  let hLen0 := mn.histArr.length
  have hh_len_m2 : H3a.wRead m2 tblW hBase = (hLen0 : ℤ) := by
    rw [hfr12_rad.1 tblW hBase hneW (Or.inr (Or.inl (by try dsimp [hBase, rBW]; unfold nodeRadTreeWOff; omega))),
        hfr01_dense.1 tblW hBase hneW (Or.inr (Or.inr (by try dsimp [hBase]; unfold nodeHistOff nodeDensePoolOff swapPoolStride; omega))),
        hh_len]
  have hbW_m2 : H3a.wRead m2 scrW wNodeBaseW = nodeBaseW :=
    (hw12 wNodeBaseW hwBW.2).trans ((hw01 wNodeBaseW hwBW.2).trans hbW)
  have huid_m2 : H3a.wRead m2 scrW wUid = (p : ℤ) :=
    (hw12 wUid hwUid.2).trans ((hw01 wUid hwUid.2).trans huid)
  let m3a := H3a.wWrite m2 scrW (wScr + 5) (hLen0 : ℤ)
  let m3b := H3a.wWrite m3a tblW (hBase + 1 + (hLen0 : ℤ)) (p : ℤ)
  let m3 := H3a.wWrite m3b tblW hBase ((hLen0 + 1 : ℕ) : ℤ)
  have hd3a : DetExec inp (.writeWordHeap scrW (.lit (wScr + 5))
      (.readHeap tblW (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit histOffVal)))) m2 m3a 20 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW _ _ rfl
      (by change H3a.wRead m2 tblW (H3a.wRead m2 scrW wNodeBaseW + histOffVal) = (hLen0 : ℤ)
          have heq : nodeBaseW + histOffVal = hBase := by dsimp [hBase, histOffVal]; unfold nodeHistOff; ring
          rw [hbW_m2, heq, hh_len_m2])
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp3a : InFootprint TW BW TR BR m3a := InFootprint.wWrite hfp2 htbls.1 (by omega) (by omega)
  have hd3b : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (histOffVal + 1))) (.readHeap scrW (.lit (wScr + 5))))
      (.readHeap scrW (.lit wUid))) m3a m3b 25 :=
    DetExecAt.writeWordHeap 0 inp m3a tblW _ _
      (by change (H3a.wRead m3a scrW wNodeBaseW + (histOffVal + 1)) + H3a.wRead m3a scrW (wScr + 5) = hBase + 1 + (hLen0 : ℤ)
          dsimp [m3a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self, hbW_m2]
          dsimp [hBase, histOffVal]; unfold nodeHistOff; ring)
      (by change H3a.wRead m3a scrW wUid = (p : ℤ); dsimp [m3a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), huid_m2])
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp3b : InFootprint TW BW TR BR m3b :=
    InFootprint.wWrite hfp3a htbls.2.1 (by try dsimp [hBase]; unfold nodeHistOff swapPoolStride; omega)
      (by try dsimp [hBase, hLen0]; try dsimp [W_tot] at *; unfold nodeHistOff managedNodeWStride swapPoolStride at *; omega)
  have hd3c : DetExec inp (.writeWordHeap tblW
      (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit histOffVal))
      (.add (.readHeap scrW (.lit (wScr + 5))) (.lit 1))) m3b m3 20 :=
    DetExecAt.writeWordHeap 0 inp m3b tblW _ _
      (by change H3a.wRead m3b scrW wNodeBaseW + histOffVal = hBase
          dsimp [m3b, m3a]; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbW_m2]
          dsimp [hBase, histOffVal]; unfold nodeHistOff; ring)
      (by change H3a.wRead m3b scrW (wScr + 5) + 1 = ((hLen0 + 1 : ℕ) : ℤ)
          dsimp [m3b, m3a]; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_self])
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp3 : InFootprint TW BW TR BR m3 :=
    InFootprint.wWrite hfp3b htbls.2.1 (by try dsimp [hBase]; unfold nodeHistOff swapPoolStride; omega)
      (by try dsimp [hBase]; try dsimp [W_tot] at *; unfold nodeHistOff managedNodeWStride swapPoolStride at *; omega)
  have hw23 : ∀ w, w < wScr → H3a.wRead m3 scrW w = H3a.wRead m2 scrW w := fun w hw => by
    dsimp [m3, m3b, m3a]
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  have hfr23_hist : RadFrameOutside scrW scrR tblW hBase (1 + (cap_hist : ℤ)) tblR 0 0 m2 m3 := by
    refine ⟨fun t i hts hout => ?_, fun _ _ _ _ => rfl⟩
    dsimp [m3, m3b, m3a]
    rcases hout with ht | hlt | hge
    · rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl hts)]
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inl hts)]
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by try dsimp [hLen0]; omega)), wRead_wWrite_of_ne _ _ (Or.inl hts)]
  -- === Step 4: Residual pool conditional insert ===
  have hbR_m3 : H3a.wRead m3 scrW wNodeBaseR = nodeBaseR :=
    (hw23 _ hwBR.2).trans ((hw12 _ hwBR.2).trans ((hw01 _ hwBR.2).trans hbR))
  have huid_m3 : H3a.wRead m3 scrW wUid = (p : ℤ) :=
    (hw23 _ hwUid.2).trans ((hw12 _ hwUid.2).trans ((hw01 _ hwUid.2).trans huid))
  have hbW_m3 : H3a.wRead m3 scrW wNodeBaseW = nodeBaseW :=
    (hw23 _ hwBW.2).trans hbW_m2
  let preLenW := nodeCfgsWBase n cap_hist K_seg nodeBaseW - nodeBaseW
  have hfr03_pre : RadFrameOutside scrW scrR tblW nodeBaseW preLenW
      tblR (nodeRadTreeROff d nodeBaseR) (radTreeRStride K_seg) m₀ m3 := by
    have ha : RadFrameOutside scrW scrR tblW nodeBaseW preLenW tblR (nodeRadTreeROff d nodeBaseR) (radTreeRStride K_seg) m₀ m1 :=
      RadFrameOutside_mono_range hfr01_dense
        (Or.inr ⟨by unfold nodeDensePoolOff; omega,
          by dsimp [preLenW]; unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff nodeDensePoolOff swapPoolStride; omega⟩)
        (Or.inl rfl)
    have hb : RadFrameOutside scrW scrR tblW nodeBaseW preLenW tblR (nodeRadTreeROff d nodeBaseR) (radTreeRStride K_seg) m1 m2 :=
      RadFrameOutside_mono_range hfr12_rad
        (Or.inr ⟨by try dsimp [rBW]; unfold nodeRadTreeWOff nodeHistOff swapPoolStride; omega,
          by try dsimp [rBW, preLenW]; unfold nodeCfgsWBase; omega⟩)
        (Or.inr ⟨le_rfl, le_rfl⟩)
    have hc : RadFrameOutside scrW scrR tblW nodeBaseW preLenW tblR (nodeRadTreeROff d nodeBaseR) (radTreeRStride K_seg) m2 m3 :=
      RadFrameOutside_mono_range hfr23_hist
        (Or.inr ⟨by try dsimp [hBase]; unfold nodeHistOff swapPoolStride; omega,
          by try dsimp [hBase, preLenW]; unfold nodeCfgsWBase nodeRadTreeWOff; omega⟩)
        (Or.inl rfl)
    exact (ha.trans hb).trans hc
  obtain ⟨m4a, hd4a, hfp4a, hflag4a, hw4a, hfr4a⟩ :=
    exec_coreBallTestStmt (tblW := tblW) true inp wNodeBaseR wUid (wScr + 4) (wScr + 10) rScr nodeBaseR p (pts p) mn.nd.o mn.nd.V
      hfp3 htbls.1 htbls.2.2.2.1 hneW hneR hne1Scr
      ⟨hwBR.1, by omega⟩ ⟨hwUid.1, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨hrScr.1, by omega⟩
      hbR_m3 huid_m3
      (fun c => (hfr03_pre.2 1 _ hne1Scr (Or.inl hne1R)).trans (hpts_r p (Finset.mem_insert_self _ _) c))
      (fun c => (hfr03_pre.2 tblR _ hneR (Or.inr (Or.inl (by have := c.isLt; unfold nodeCenterROff nodeRadTreeROff; omega)))).trans (ho_e c))
      ((hfr03_pre.2 tblR _ hneR (Or.inr (Or.inl (by unfold nodeVarROff nodeRadTreeROff; omega)))).trans hV_e)
  have hPr_4a : EncSwapPool tblW (nodeResPoolOff n nodeBaseW) n Pr m4a := by
    have hsub : ∀ i : ℤ, nodeResPoolOff n nodeBaseW ≤ i →
        i < nodeResPoolOff n nodeBaseW + swapPoolStride n → H3a.wRead m4a tblW i = H3a.wRead m₀ tblW i := by
      intro i hlo hhi
      rw [hfr4a.1 tblW i hneW (Or.inr (by omega)),
          hfr23_hist.1 tblW i hneW (Or.inr (Or.inl (by try dsimp [hBase] at *; simp only [nodeHistOff, nodeResPoolOff, swapPoolStride] at *; omega))),
          hfr12_rad.1 tblW i hneW (Or.inr (Or.inl (by try dsimp [rBW] at *; simp only [nodeRadTreeWOff, nodeHistOff, nodeResPoolOff, swapPoolStride] at *; omega))),
          hfr01_dense.1 tblW i hneW (Or.inr (Or.inr (by simp only [nodeResPoolOff, nodeDensePoolOff, swapPoolStride] at *; omega)))]
    have hsz_Pr := hPr_wf.2.2.2.1
    exact ⟨(hsub _ le_rfl (by dsimp [swapPoolStride]; omega)).trans hPr_e.1,
      (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans hPr_e.2.1,
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr_e.2.2.1 x hx),
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr_e.2.2.2.1 x hx),
      fun r hr => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr_e.2.2.2.2 r hr)⟩
  have hres4_step : ∃ (Pr' : SwapPool) (m4 : ArithRAMMemory),
      DetExec inp (.ite (.intEq (.readHeap scrW (.lit (wScr + 4))) (.lit 1))
        (.seq (.writeWordHeap scrW (.lit wScr) (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (8 + swapPoolStride n))))
              (swapPoolInsertStmt scrW tblW wScr wUid (wScr + 10) n))
        .skip) m4a m4 280 ∧
      InFootprint TW BW TR BR m4 ∧
      Pr'.WF n mn'.resArr.toFinset ∧
      swapPoolToList Pr' = mn'.resArr ∧
      EncSwapPool tblW (nodeResPoolOff n nodeBaseW) n Pr' m4 ∧
      (∀ w, w < wScr → H3a.wRead m4 scrW w = H3a.wRead m4a scrW w) ∧
      RadFrameOutside scrW scrR tblW (nodeResPoolOff n nodeBaseW) (swapPoolStride n) tblR 0 0 m4a m4 := by
    by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts p) = true
    · have hc_f : cValAt 0 inp m4a (.intEq (.readHeap scrW (.lit (wScr + 4))) (.lit 1)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m4a scrW (wScr + 4) = 1) = false
        rw [hflag4a, hcb]; rfl
      have hres_eq : mn'.resArr = mn.resArr := by dsimp [mn', ManagedNode.insertMat]; rw [if_pos hcb]
      refine ⟨Pr, m4a,
        (DetExecAt.ite_false hc_f (C_c := 15) (C_b := 1)
          (by dsimp [H3a.condExprOps, H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (DetExecAt.skip 0 inp m4a)).mono_cost (by omega),
        hfp4a, hres_eq ▸ hPr_wf, hres_eq ▸ hPr_l, hPr_4a, fun _ _ => rfl,
        RadFrameOutside.refl _ _ _ _ _ _ _ _ m4a⟩
    · have hcb_f : inCoreBall mn.nd.o mn.nd.V (pts p) = false := Bool.eq_false_iff.mpr hcb
      have hc_t : cValAt 0 inp m4a (.intEq (.readHeap scrW (.lit (wScr + 4))) (.lit 1)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m4a scrW (wScr + 4) = 1) = true
        rw [hflag4a, hcb_f]; rfl
      have hres_eq : mn'.resArr = denseInsert p mn.resArr := by dsimp [mn', ManagedNode.insertMat]; rw [if_neg hcb]
      let m4b := H3a.wWrite m4a scrW wScr (nodeResPoolOff n nodeBaseW)
      have hd4b : DetExec inp (.writeWordHeap scrW (.lit wScr)
          (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (8 + swapPoolStride n)))) m4a m4b 20 :=
        DetExecAt.writeWordHeap 0 inp m4a scrW _ _ rfl
          (by change H3a.wRead m4a scrW wNodeBaseW + (8 + swapPoolStride n) = nodeResPoolOff n nodeBaseW
              rw [hw4a wNodeBaseW (by omega) (by omega), hbW_m3]; unfold nodeResPoolOff; ring)
          (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp4b : InFootprint TW BW TR BR m4b := InFootprint.wWrite hfp4a htbls.1 hwScr.1 (by omega)
      have hPr_4b : EncSwapPool tblW (nodeResPoolOff n nodeBaseW) n Pr m4b :=
        hPr_4a.mono_frame (WordFrameOutside.wWrite_scr scrW tblW (nodeResPoolOff n nodeBaseW) 0 m4a wScr (nodeResPoolOff n nodeBaseW))
          hneW (Or.inr (Or.inr (by omega))) hPr_wf.2.2.2.1
      obtain ⟨m4, hd4c, hfp4, hPr'_e, _, _, hfr4_w⟩ :=
        exec_swapPoolInsertStmt inp wScr wUid (wScr + 10) (nodeResPoolOff n nodeBaseW) hn1 hPr_wf p
          hfp4b htbls.1 htbls.2.1 hneW
          ⟨by unfold nodeResPoolOff swapPoolStride; omega,
           by unfold nodeResPoolOff; try dsimp [W_tot] at *; unfold managedNodeWStride swapPoolStride at *; omega⟩
          ⟨by omega, by omega⟩ (by omega) (by omega)
          (wRead_wWrite_self _ _ _ _)
          (by dsimp [m4b]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw4a wUid (by omega) (by omega), huid_m3])
          hPr_4b
      have hw4_sub := detExec_preserves_scr_below (psb_swapPoolInsertStmt hneW (wBound := wScr + 10) le_rfl) hfp4b hfp4 hd4c
      have hres_sub : mn.resArr.toFinset ⊆ mn.nd.curSet := by
        rw [hwf_mn.2.2.1]
        exact @Finset.sdiff_subset ℕ (fun a b => Classical.propDecidable (a = b)) _ _
      have hp_not_res : p ∉ mn.resArr.toFinset := fun hm => hp_not (hres_sub hm)
      have hres_card : mn.resArr.toFinset.card + 1 ≤ n := by
        have := Finset.card_le_card hres_sub; omega
      have hres_lt : ∀ x ∈ mn.resArr.toFinset, x < n := fun x hx => hS_lt x (hres_sub hx)
      obtain ⟨hPr'_wf, hPr'_l⟩ := swapPoolToList_insert hn1 hPr_wf hPr_l hp_lt hp_not_res hres_card hres_lt
      have hfs_res' : mn'.resArr.toFinset = Insert.insert p mn.resArr.toFinset := by
        rw [hres_eq]; exact (denseInsert_spec hwf_mn.2.1 hp_not_res).2
      refine ⟨Pr.insert n p, m4,
        (DetExecAt.ite_true hc_t (C_c := 15) (C_b := 255)
          (by dsimp [H3a.condExprOps, H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          ((DetExecAt.seq hd4b hd4c).mono_cost (by omega))).mono_cost (by omega),
        hfp4, hfs_res' ▸ hPr'_wf, hres_eq ▸ hPr'_l, hPr'_e,
        fun w hw => (hw4_sub w (by omega)).trans (wRead_wWrite_of_ne _ _ (Or.inr (by omega))),
        (radFrame_wWrite_scr scrW scrR tblW (nodeResPoolOff n nodeBaseW) (swapPoolStride n) tblR 0 0 m4a wScr (nodeResPoolOff n nodeBaseW)).trans (radFrame_of_wordFrame hfr4_w)⟩
  rcases hres4_step with ⟨Pr', m4, hd4b_ite, hfp4, hPr'_wf, hPr'_l, hPr'_e, hw4b_scr, hfr4b_res⟩
  have hw04 : ∀ w, w < wScr → H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w := fun w hw =>
    (hw4b_scr w hw).trans ((hw4a w (by omega) (by omega)).trans
      ((hw23 w hw).trans ((hw12 w hw).trans (hw01 w hw))))
  have hfr04 : RadFrameOutside scrW scrR tblW nodeBaseW preLenW
      tblR (nodeRadTreeROff d nodeBaseR) (radTreeRStride K_seg) m₀ m4 := by
    have h4a_r : RadFrameOutside scrW scrR tblW nodeBaseW preLenW tblR (nodeRadTreeROff d nodeBaseR) (radTreeRStride K_seg) m3 m4a :=
      RadFrameOutside_mono_range hfr4a (Or.inl rfl) (Or.inl rfl)
    have h4b_r : RadFrameOutside scrW scrR tblW nodeBaseW preLenW tblR (nodeRadTreeROff d nodeBaseR) (radTreeRStride K_seg) m4a m4 :=
      RadFrameOutside_mono_range hfr4b_res
        (Or.inr ⟨by unfold nodeResPoolOff swapPoolStride; omega,
          by dsimp [preLenW]; unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff nodeResPoolOff swapPoolStride; omega⟩)
        (Or.inl rfl)
    exact hfr03_pre.trans (h4a_r.trans h4b_r)
  -- === Step 5: N_cfg conditional insert via `exec_managedNodeInsertCfgsStmt` ===
  have hcur' : mn'.nd.curSet = Insert.insert p mn.nd.curSet :=
    (denseInsert_spec hwf_mn.1.1 hp_not).2
  obtain ⟨m6, hd6, hfp6, hw_m6_m4, hr_m6_m4, hcfgs6, hw6, hfr46⟩ :=
    exec_managedNodeInsertCfgsStmt hM₀ hn hL_p2 ops specs cap_hist K_seg inp
      wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr nodeBaseW nodeBaseR nodeSeedOff
      hp_not hp_lt hS_lt hS_card ω ht_bnd ht_cap hwf_mn
      hfp4 htbls hbaseW hbaseR hseedB hptsB hwBW hwBR hwUid hwSO hwScr_orig hrScr_orig
      ((hw04 _ hwBW.2).trans hbW)
      ((hw04 _ hwBR.2).trans hbR)
      ((hw04 _ hwUid.2).trans huid)
      ((hw04 _ hwSO.2).trans hseed_reg)
      (fun c => (hfr04.2 tblR _ hneR (Or.inr (Or.inl (by have := c.isLt; unfold nodeCenterROff nodeRadTreeROff; omega)))).trans (ho_e c))
      ((hfr04.2 tblR _ hneR (Or.inr (Or.inl (by unfold nodeVarROff nodeRadTreeROff; omega)))).trans hV_e)
      (fun x hx c => (hfr04.2 1 _ hne1Scr (Or.inl hne1R)).trans (hpts_r x hx c))
      (EncNodeOpSeedSlice.mono_coinTbl hseed_enc (fun idx_c => hfr04.1 coinTbl idx_c hneCoinScr (Or.inl hneCoinW)))
      (fun i => by
        have hbW_i := nodeCfgWOff_bounds n cap_hist K_seg hcfgW nodeBaseW i
        have hbR_i := nodeCfgROff_bounds d K_seg hcfgR nodeBaseR i
        exact ops.encCfg_mono_slice (specs i) _ _ pts mn.nd.o mn.nd.V (nodeCfgSet mn.nd) (mn.nd.cfgs i) m₀ m4 (hcfgs_e i)
          (fun j hj1 _ => hfr04.1 tblW j hneW (Or.inr (Or.inr (by omega))))
          (fun j hj1 _ => hfr04.2 tblR j hneR (Or.inr (Or.inr (by simp only [nodeCfgsRBase] at *; omega))))
          (fun _ _ _ _ => hfr04.2 1 _ hne1Scr (Or.inl hne1R)))
  -- Assemble full execution
  have hd_tot : DetExec inp (managedNodeInsertMatStmt ops specs cap_hist K_seg
      wNodeBaseW wNodeBaseR wUid wNodeSeedOff wScr rScr)
      m₀ m6 (managedNodeInsertMatCost ops K_seg N_cfg) := by
    unfold managedNodeInsertMatStmt managedNodeInsertMatCost
    exact (DetExecAt.seq hd1a (DetExecAt.seq hd1b
      (DetExecAt.seq hd2a (DetExecAt.seq hd2b (DetExecAt.seq hd2c (DetExecAt.seq hd2d (DetExecAt.seq hd2e
      (DetExecAt.seq hd3a (DetExecAt.seq hd3b (DetExecAt.seq hd3c
      (DetExecAt.seq hd4a (DetExecAt.seq hd4b_ite hd6)))))))))))).mono_cost (by omega)
  have hw_tot : ∀ w, w < wScr → H3a.wRead m6 scrW w = H3a.wRead m₀ scrW w := fun w hw =>
    (hw6 w hw).trans (hw04 w hw)
  have hfr04_tot : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m₀ m4 :=
    RadFrameOutside_mono_range hfr04
      (Or.inr ⟨le_rfl, by try dsimp [preLenW, W_tot] at *; simp only [nodeCfgsWBase, nodeRadTreeWOff, nodeHistOff, managedNodeWStride, swapPoolStride] at *; omega⟩)
      (Or.inr ⟨by simp only [nodeRadTreeROff] at *; omega, by try dsimp [R_tot] at *; simp only [nodeRadTreeROff, managedNodeRStride] at *; omega⟩)
  have hfr_tot : RadFrameOutside scrW scrR tblW nodeBaseW W_tot tblR nodeBaseR R_tot m₀ m6 :=
    hfr04_tot.trans hfr46
  refine ⟨m6, hd_tot, hfp6, ?_, hw_tot, hfr_tot⟩
  -- Assemble `EncManagedNode` on `m6`
  have hw_hdr : ∀ j : ℤ, j < nodeDensePoolOff nodeBaseW → H3a.wRead m6 tblW j = H3a.wRead m₀ tblW j := by
    intro j hj
    rw [hw_m6_m4 j (by unfold nodeDensePoolOff nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride at *; omega),
        hfr4b_res.1 tblW j hneW (Or.inr (Or.inl (by unfold nodeDensePoolOff nodeResPoolOff swapPoolStride at *; omega))),
        hfr4a.1 tblW j hneW (Or.inr (by omega)),
        hfr23_hist.1 tblW j hneW (Or.inr (Or.inl (by try dsimp [hBase]; unfold nodeHistOff nodeDensePoolOff swapPoolStride at *; omega))),
        hfr12_rad.1 tblW j hneW (Or.inr (Or.inl (by try dsimp [rBW]; unfold nodeRadTreeWOff nodeHistOff nodeDensePoolOff swapPoolStride at *; omega))),
        hfr01_dense.1 tblW j hneW (Or.inr (Or.inl hj))]
  have hr_hdr : ∀ j : ℤ, j < nodeRadTreeROff d nodeBaseR → H3a.rRead m6 tblR j = H3a.rRead m₀ tblR j := by
    intro j hj
    rw [hr_m6_m4 j (by unfold nodeCfgsRBase at *; omega),
        hfr04.2 tblR j hneR (Or.inr (Or.inl hj))]
  refine ⟨(hw_hdr _ (by unfold nodeBirthSizeOff nodeDensePoolOff; omega)).trans hb_e,
    (hw_hdr _ (by unfold nodeAgeOff nodeDensePoolOff; omega)).trans ha_e,
    ?_,
    fun c => (hr_hdr _ (by have := c.isLt; unfold nodeCenterROff nodeRadTreeROff; omega)).trans (ho_e c),
    (hr_hdr _ (by unfold nodeHeightROff nodeRadTreeROff; omega)).trans hs_e,
    (hr_hdr _ (by unfold nodeVarROff nodeRadTreeROff; omega)).trans hV_e,
    by dsimp [mn', ManagedNode.insertMat]; simp [hhist_cap],
    ?_, ?_,
    ⟨Pd.insert n p, hcur' ▸ hPd'_wf, hPd'_l, ?_⟩,
    ⟨Pr', hPr'_wf, hPr'_l, ?_⟩,
    ⟨Tr.updateLeaf K_seg (p % n) (some (p, ‖pts p - mn.nd.o‖ ^ 2)), hcur' ▸ hTr'_wf, ?_⟩,
    hcfgs6⟩
  · cases bp with
    | none =>
        rcases hbp_e with ⟨h1, h2, h3⟩
        exact ⟨(hw_hdr _ (by unfold nodeBaseHasOff nodeDensePoolOff; omega)).trans h1,
               (hw_hdr _ (by unfold nodeBaseUOff nodeDensePoolOff; omega)).trans h2,
               (hw_hdr _ (by unfold nodeBaseVOff nodeDensePoolOff; omega)).trans h3⟩
    | some uv =>
        rcases uv with ⟨u, v⟩
        rcases hbp_e with ⟨h1, h2, h3⟩
        exact ⟨(hw_hdr _ (by unfold nodeBaseHasOff nodeDensePoolOff; omega)).trans h1,
               (hw_hdr _ (by unfold nodeBaseUOff nodeDensePoolOff; omega)).trans h2,
               (hw_hdr _ (by unfold nodeBaseVOff nodeDensePoolOff; omega)).trans h3⟩
  · dsimp [mn', ManagedNode.insertMat]
    rw [List.length_append, List.length_singleton]
    rw [hw_m6_m4 hBase (by try dsimp [hBase]; unfold nodeCfgsWBase nodeRadTreeWOff; omega),
        hfr4b_res.1 tblW hBase hneW (Or.inr (Or.inr (by try dsimp [hBase]; unfold nodeHistOff nodeResPoolOff; omega))),
        hfr4a.1 tblW hBase hneW (Or.inr (by omega))]
    exact wRead_wWrite_self _ _ _ _
  · intro j hj
    dsimp [mn', ManagedNode.insertMat] at hj ⊢
    rw [List.length_append, List.length_singleton] at hj
    rw [hw_m6_m4 (hBase + 1 + (j : ℤ)) (by try dsimp [hBase, hLen0] at *; unfold nodeCfgsWBase nodeRadTreeWOff; omega),
        hfr4b_res.1 tblW _ hneW (Or.inr (Or.inr (by try dsimp [hBase]; unfold nodeHistOff nodeResPoolOff; omega))),
        hfr4a.1 tblW _ hneW (Or.inr (by omega))]
    dsimp [m3, m3b, m3a]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    rcases Nat.lt_succ_iff_lt_or_eq.mp hj with hlt | rfl
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by try dsimp [hLen0]; omega)),
          wRead_wWrite_of_ne _ _ (Or.inl hneW),
          hfr12_rad.1 tblW _ hneW (Or.inr (Or.inl (by try dsimp [hBase, rBW, hLen0] at *; simp only [nodeRadTreeWOff] at *; omega))),
          hfr01_dense.1 tblW _ hneW (Or.inr (Or.inr (by try dsimp [hBase]; unfold nodeHistOff nodeDensePoolOff swapPoolStride; omega))),
          List.getElem_append_left hlt]
      exact hh_el j hlt
    · try dsimp [hLen0]
      rw [wRead_wWrite_self, List.getElem_append_right le_rfl]
      simp
  · have hsub : ∀ j : ℤ, nodeDensePoolOff nodeBaseW ≤ j →
        j < nodeDensePoolOff nodeBaseW + swapPoolStride n → H3a.wRead m6 tblW j = H3a.wRead m1 tblW j := by
      intro j _ hhi
      rw [hw_m6_m4 j (by unfold nodeDensePoolOff nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride at *; omega),
          hfr4b_res.1 tblW j hneW (Or.inr (Or.inl (by unfold nodeDensePoolOff nodeResPoolOff at *; omega))),
          hfr4a.1 tblW j hneW (Or.inr (by omega)),
          hfr23_hist.1 tblW j hneW (Or.inr (Or.inl (by try dsimp [hBase]; unfold nodeHistOff nodeDensePoolOff swapPoolStride at *; omega))),
          hfr12_rad.1 tblW j hneW (Or.inr (Or.inl (by try dsimp [rBW]; unfold nodeRadTreeWOff nodeHistOff nodeDensePoolOff swapPoolStride at *; omega)))]
    have hsz_le := hPd'_wf.2.2.2.1
    exact ⟨(hsub _ le_rfl (by dsimp [swapPoolStride]; omega)).trans hPd'_e.1,
      (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans hPd'_e.2.1,
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPd'_e.2.2.1 x hx),
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPd'_e.2.2.2.1 x hx),
      fun r hr => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPd'_e.2.2.2.2 r hr)⟩
  · have hsub : ∀ j : ℤ, nodeResPoolOff n nodeBaseW ≤ j →
        j < nodeResPoolOff n nodeBaseW + swapPoolStride n → H3a.wRead m6 tblW j = H3a.wRead m4 tblW j :=
      fun j _ hhi => hw_m6_m4 j (by unfold nodeResPoolOff nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride at *; omega)
    have hsz_le := hPr'_wf.2.2.2.1
    exact ⟨(hsub _ le_rfl (by dsimp [swapPoolStride]; omega)).trans hPr'_e.1,
      (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans hPr'_e.2.1,
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr'_e.2.2.1 x hx),
      fun x hx => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr'_e.2.2.2.1 x hx),
      fun r hr => (hsub _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (hPr'_e.2.2.2.2 r hr)⟩
  · have hsubW : ∀ j : ℤ, rBW ≤ j → j < rBW + radTreeWStride K_seg → H3a.wRead m6 tblW j = H3a.wRead m2 tblW j := by
      intro j hlo hhi
      rw [hw_m6_m4 j (by try dsimp [rBW] at *; unfold nodeCfgsWBase; omega),
          hfr4b_res.1 tblW j hneW (Or.inr (Or.inr (by try dsimp [rBW] at hlo; unfold nodeRadTreeWOff nodeHistOff nodeResPoolOff swapPoolStride at *; omega))),
          hfr4a.1 tblW j hneW (Or.inr (by omega)),
          hfr23_hist.1 tblW j hneW (Or.inr (Or.inr (by try dsimp [rBW, hBase] at *; simp only [nodeRadTreeWOff, nodeHistOff] at *; omega)))]
    have hsubR : ∀ j : ℤ, rBR ≤ j → j < rBR + radTreeRStride K_seg → H3a.rRead m6 tblR j = H3a.rRead m2 tblR j := by
      intro j _ hhi
      rw [hr_m6_m4 j (by try dsimp [rBR] at *; unfold nodeCfgsRBase; omega),
          hfr4b_res.2 tblR j hneR (Or.inr (by omega)),
          hfr4a.2 tblR j hneR (Or.inr (by omega)),
          hfr23_hist.2 tblR j hneR (Or.inr (by omega))]
    refine ⟨(hsubW _ le_rfl (by omega)).trans hTr'_e.1, fun v hv => ?_⟩
    have hvW := radTreeWStride_gt_node hv
    have hvR := radTreeRStride_gt_node hv
    obtain ⟨e1, e2, e3, e4⟩ := hTr'_e.2 v hv
    exact ⟨(hsubW _ (by omega) (by omega)).trans e1,
           (hsubW _ (by omega) (by omega)).trans e2,
           (hsubW _ (by omega) (by omega)).trans e3,
           (hsubR _ (by omega) (by omega)).trans e4⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
