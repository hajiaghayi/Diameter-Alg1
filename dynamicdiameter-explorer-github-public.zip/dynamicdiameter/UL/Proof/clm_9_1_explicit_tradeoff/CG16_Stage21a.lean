import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage20
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

/-! ### 1. Reusable `EncCachedAns` & `EncJobSlot` Local Frame Helpers -/

theorem encCachedAns_ext_345 {ans : StoredDiameterAnswer} {m₀ m₁ : ArithRAMMemory}
    (ha : EncCachedAns ans m₀)
    (hw0 : ∀ i, wRead m₁ 0 i = wRead m₀ 0 i)
    (hw345 : ∀ i : ℤ, (i = 3 ∨ i = 4 ∨ i = 5) → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i)
    (hr0 : rRead m₁ 0 0 = rRead m₀ 0 0)
    (hr2 : rRead m₁ engRealTbl 0 = rRead m₀ engRealTbl 0) :
    EncCachedAns ans m₁ := by
  rcases ha with ⟨hread, hr_sh, hmatch⟩
  have hread₁ : ArithRAMDynamicProgram.readCachedAnswer m₁ =
      ArithRAMDynamicProgram.readCachedAnswer m₀ := by
    have h01 : m₁.words.read (.heap 0 1) = m₀.words.read (.heap 0 1) := hw0 1
    have h02 : m₁.words.read (.heap 0 2) = m₀.words.read (.heap 0 2) := hw0 2
    have h03 : m₁.words.read (.heap 0 3) = m₀.words.read (.heap 0 3) := hw0 3
    have hr00 : m₁.reals.read (.heap 0 0) = m₀.reals.read (.heap 0 0) := hr0
    unfold ArithRAMDynamicProgram.readCachedAnswer
    simp only [h01, h02, h03, hr00]
  refine ⟨hread₁.trans hread, hr2.trans hr_sh, ?_⟩
  cases hd_ans : ans.diameterHandles with
  | none =>
      simp only [hd_ans] at hmatch
      exact ⟨(hw345 3 (Or.inl rfl)).trans hmatch.1,
             (hw345 4 (Or.inr (Or.inl rfl))).trans hmatch.2.1,
             (hw345 5 (Or.inr (Or.inr rfl))).trans hmatch.2.2⟩
  | some uv =>
      rcases uv with ⟨u, v⟩
      simp only [hd_ans] at hmatch
      exact ⟨(hw345 3 (Or.inl rfl)).trans hmatch.1,
             (hw345 4 (Or.inr (Or.inl rfl))).trans hmatch.2.1,
             (hw345 5 (Or.inr (Or.inr rfl))).trans hmatch.2.2⟩

theorem encJobSlot_ext_jobsRegion {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {r : Fin cp.D_max} {jbOpt : Option (SuffixJob cp)} {rSlots : List ℕ} {cSlot : ℕ}
    {m₀ m₁ : ArithRAMMemory}
    (hj : EncJobSlot ops r jbOpt rSlots cSlot m₀)
    (hu_lt : ∀ s ∈ jobUsedSlots jbOpt rSlots cSlot, s < M_slots cp)
    (hw_base : ∀ k : ℤ, 0 ≤ k → k < 8 →
      wRead m₁ engMetaTbl (jobMetaBase cp r.val + k) =
        wRead m₀ engMetaTbl (jobMetaBase cp r.val + k))
    (hw_ready : ∀ q < cp.D_max,
      wRead m₁ engMetaTbl (readySlotOff cp r.val q) =
        wRead m₀ engMetaTbl (readySlotOff cp r.val q))
    (hw_arr : ∀ i : ℤ, 2 * (S_stride cp : ℤ) ≤ i → wRead m₁ engArrTbl i = wRead m₀ engArrTbl i)
    (hnd : ∀ mn s, s < M_slots cp → s ∈ jobUsedSlots jbOpt rSlots cSlot →
      ops.EncNode mn s m₀ → ops.EncNode mn s m₁) :
    EncJobSlot ops r jbOpt rSlots cSlot m₁ := by
  have hw_blk : ∀ b : ℕ, 2 ≤ b → ∀ k : ℤ, 0 ≤ k →
      wRead m₁ engArrTbl (((b * S_stride cp : ℕ) : ℤ) + k) =
        wRead m₀ engArrTbl (((b * S_stride cp : ℕ) : ℤ) + k) := by
    intro b hb2 k hk0
    have hm : 2 * S_stride cp ≤ b * S_stride cp := Nat.mul_le_mul_right _ hb2
    have hmZ : 2 * (S_stride cp : ℤ) ≤ ((b * S_stride cp : ℕ) : ℤ) := by exact_mod_cast hm
    exact hw_arr _ (by omega)
  cases jbOpt with
  | none =>
      exact ⟨hj.1, (hw_base 0 (by omega) (by omega)).trans hj.2⟩
  | some jb =>
      rcases hj with ⟨ha0, hrle0, hrlen0, hw1_0, hrd0, hph0⟩
      refine ⟨(hw_base 0 (by omega) (by omega)).trans ha0, hrle0, hrlen0,
        (hw_base 1 (by omega) (by omega)).trans hw1_0,
        fun q hq hqs => ?_, ?_⟩
      · have hmem_q : rSlots[q]'hqs ∈ jobUsedSlots (some jb) rSlots cSlot := by
          simp only [jobUsedSlots]
          cases jb.phase with
          | copy _ => exact List.getElem_mem hqs
          | build _ => exact List.mem_append_left _ (List.getElem_mem hqs)
        exact ⟨(hw_ready q (lt_of_lt_of_le hq hrle0)).trans (hrd0 q hq hqs).1,
          hnd _ _ (hu_lt _ hmem_q) hmem_q (hrd0 q hq hqs).2⟩
      · cases hjp : jb.phase with
        | copy cs =>
            simp only [hjp] at hph0 ⊢
            rcases hph0 with ⟨hp2, hp3, hp4, hsp⟩
            exact ⟨(hw_base 2 (by omega) (by omega)).trans hp2,
              (hw_base 3 (by omega) (by omega)).trans hp3,
              (hw_base 4 (by omega) (by omega)).trans hp4,
              hsp.ext (hw_base 5 (by omega) (by omega))
                (fun k _ => hw_blk (2 + 4 * r.val) (by omega) (k : ℤ) (by positivity))
                (fun y _ => hw_blk (3 + 4 * r.val) (by omega) (y : ℤ) (by positivity))⟩
        | build bs =>
            simp only [hjp] at hph0 ⊢
            rcases hph0 with ⟨hp2, hp3, hp4, hsp, hdsp, hc7, hcenc⟩
            have hc_mem : cSlot ∈ jobUsedSlots (some jb) rSlots cSlot := by
              simp [jobUsedSlots, hjp]
            exact ⟨(hw_base 2 (by omega) (by omega)).trans hp2,
              (hw_base 3 (by omega) (by omega)).trans hp3,
              (hw_base 4 (by omega) (by omega)).trans hp4,
              hsp.ext (hw_base 5 (by omega) (by omega))
                (fun k _ => hw_blk (2 + 4 * r.val) (by omega) (k : ℤ) (by positivity))
                (fun y _ => hw_blk (3 + 4 * r.val) (by omega) (y : ℤ) (by positivity)),
              hdsp.ext (hw_base 6 (by omega) (by omega))
                (fun k _ => hw_blk (4 + 4 * r.val) (by omega) (k : ℤ) (by positivity))
                (fun y _ => hw_blk (5 + 4 * r.val) (by omega) (y : ℤ) (by positivity)),
              (hw_base 7 (by omega) (by omega)).trans hc7,
              hnd _ _ (hu_lt _ hc_mem) hc_mem hcenc⟩

/-! ### 2. Synchronous Leaf Node Allocation + HPJ + Build Loop (`leafAllocAndBuildStmt`) -/

def leafBuildIterStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 25)
          (.readHeap engArrTbl (.readHeap engScrTbl (.lit 24))))
  (.seq (.writeWordHeap engScrTbl (.lit 26)
          (.add (.lit (((cp.B_S1 + cp.D_max * cp.B_scan * cp.B_op : ℕ) : ℤ)))
                (.mul (.readHeap engScrTbl (.lit 24)) (.lit (cp.B_op : ℤ)))))
        (ops.insertMatStmt 15 25 26))

theorem zeroRand_leafBuildIterStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (leafBuildIterStmt ops) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (ops.zeroRand_insertMat 15 25 26))

def leafAllocAndBuildStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (allocFreshSlotStmt cp)
  (.seq (.writeWordHeap engScrTbl (.lit 15) (.readHeap engScrTbl (.lit 39)))
  (.seq (.writeWordHeap engScrTbl (.lit 21) (.lit 0))
  (.seq (.writeWordHeap engScrTbl (.lit 22) (.readHeap engMetaTbl (.lit 2)))
  (.seq (.writeWordHeap engScrTbl (.lit 23)
          (.lit (((cp.B_S1 + cp.N_op_s2 * cp.B_op + cp.D_max * cp.B_ctr : ℕ) : ℤ))))
  (.seq (ops.evalHPJCenterStmt engArrTbl 21 22 23)
  (.seq (ops.openEmptyStmt 15 22)
        (dynForLoopStmt 24 22 (leafBuildIterStmt ops))))))))

theorem zeroRand_leafAllocAndBuildStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (leafAllocAndBuildStmt ops) :=
  .seq (zeroRand_allocFreshSlotStmt cp)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (ops.zeroRand_evalHPJCenter engArrTbl 21 22 23)
  (.seq (ops.zeroRand_openEmpty 15 22)
        (zeroRand_dynForLoopStmt 24 22 (zeroRand_leafBuildIterStmt ops))))))))

def leafAllocAndBuildCost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  allocFreshSlotCost cp + 64 + ops.C_hpj + ops.C_open +
    (cp.B_scan + 1) * (ops.C_ins + 40)

theorem exec_leafAllocAndBuildStmt
    (h_clm_7_3 : S_clm_7_3_global_approx)
    {d : ℕ} (hd : 1 ≤ d) {params : LocalScaleParams} (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1)
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d)
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp}
    {servSlots : List ℕ}
    {jobs₂ : Fin cp.D_max → Option (SuffixJob cp)}
    {readySlots : Fin cp.D_max → List ℕ}
    {curSlots : Fin cp.D_max → ℕ}
    {bits : Fin cp.B_STEP → Bool}
    {m₀ : ArithRAMMemory}
    (hwf₁ : PostStage1WF cp P' st₁)
    (hov_false : st₁.leafOverflow = false)
    (hgt_B : cp.B_scan < st₁.leafArr.length)
    (hlf_le1 : st₁.leafArr.length ≤ cp.B_scan + 1)
    (hserv_le₀ : st₁.serving.length ≤ cp.D_max)
    (hslen₀ : servSlots.length = st₁.serving.length)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hhp₀ : EncHandlePool st₁.hp m₀)
    (hlf_sp₀ : EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) st₁.leafArr m₀)
    (hserv_len₀ : wRead m₀ engMetaTbl 0 = (st₁.serving.length : ℤ))
    (hserv_slots₀ : ∀ i (his : i < servSlots.length),
      wRead m₀ engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ))
    (hjobs₀ : ∀ r : Fin cp.D_max, EncJobSlot ops r (jobs₂ r) (readySlots r) (curSlots r) m₀)
    (hall_lt₀ : ∀ s ∈ servSlots ++
      (List.finRange cp.D_max).flatMap (fun r => jobUsedSlots (jobs₂ r) (readySlots r) (curSlots r)),
      s < M_slots cp)
    (hcoins₀ : MemHasStepCoins cp bits m₀) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let pts := st₁.hp.coords
    let leafCtr := ω₂.2 (Fin.last cp.D_max)
    let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts st₁.leafArr leafCtr
    let P₀_uid := st₁.leafArr.toFinset.image st₁.gt.uidOf
    let bs0 := BuildState.init cp st₁.leafArr.length st₁.leafArr os.1 os.2 P₀_uid
    let steps := min st₁.leafArr.length (cp.B_scan + 1)
    let leafSeeds : Fin steps → OpSeed cp := fun j =>
      ω₂.1 ⟨cp.D_max * cp.B_scan + j.val, by
        have hj : j.val < cp.B_scan + 1 := lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)
        exact Nat.add_lt_add_left hj _⟩
    let u_leaf := (advanceBuildLoop cp pts steps leafSeeds bs0).curNode
    let allSlots₀ := servSlots ++
      (List.finRange cp.D_max).flatMap (fun r => jobUsedSlots (jobs₂ r) (readySlots r) (curSlots r))
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (leafAllocAndBuildStmt ops) m₀
      (fun mL =>
        ops.SlotsReady mL ∧
        u_leaf.resArr.Nodup ∧
        (∀ x ∈ u_leaf.resArr, x < cp.n) ∧
        (∃ ns < M_slots cp,
          ns ∉ allSlots₀ ∧
          wRead mL engScrTbl 15 = (ns : ℤ) ∧
          ops.EncNode u_leaf ns mL ∧
          (∀ mn' s', s' < M_slots cp → s' ≠ ns → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' mL)) ∧
        (∀ t < 8, ∀ i, wRead mL t i = wRead m₀ t i) ∧
        (∀ t < 2, ∀ i, rRead mL t i = rRead m₀ t i) ∧
        rRead mL engRealTbl 0 = rRead m₀ engRealTbl 0)
      (leafAllocAndBuildCost ops) := by
  intro ω₂ pts leafCtr os P₀_uid bs0 steps leafSeeds u_leaf allSlots₀
  have hTW := ops.hTW
  have hBW_arr := ops.hBW_arr
  have hBW_scr := ops.hBW_scr
  rcases hwf₁ with ⟨hhp_wf, hgt_wf, _, hserv_cl, _, hleaf_wf⟩
  rcases hleaf_wf hov_false with ⟨hlf_nd, hlf_set, _⟩
  let actH := P'.activeHandles
  have hact_n : actH.card ≤ cp.n := by
    rcases hhp_wf with ⟨_, hact_nd, _, hact_set, _, _, hsum, _⟩
    dsimp only [actH]; rw [← hact_set, List.toFinset_card_of_nodup hact_nd]; omega
  have hlf_sub_act : st₁.leafArr.toFinset ⊆ actH :=
    hlf_set ▸ (chainListInv_getElem actH st₁.serving (Finset.Subset.refl _) hserv_cl).1
  have hlf_card_n : st₁.leafArr.toFinset.card ≤ cp.n :=
    (Finset.card_le_card hlf_sub_act).trans hact_n
  have hlf_len_n : st₁.leafArr.length ≤ cp.n := by
    rwa [List.toFinset_card_of_nodup hlf_nd] at hlf_card_n
  have hact_lt_nf : ∀ x ∈ actH, x < st₁.hp.nextFresh := fun x hx =>
    hhp_wf.2.2.2.2.1 x (List.mem_toFinset.mp (hhp_wf.2.2.2.1.symm ▸ hx))
  have hact_lt_n : ∀ x ∈ actH, x < cp.n := fun x hx =>
    lt_of_lt_of_le (hact_lt_nf x hx) hhp_wf.1
  have hact_pts_m0 : ∀ x ∈ actH, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c :=
    fun x hx c => hhp₀.2.2.2.2.2 x (hact_lt_nf x hx) c
  have hsteps_eq : steps = st₁.leafArr.length := Nat.min_eq_left hlf_le1
  have hP0_eq : (foldResiduals pts actH st₁.serving).image st₁.gt.uidOf = P₀_uid := by
    rw [← hlf_set]
  rcases buildState_init_spec cp hh0 hh1 hgt_wf
    (chainListInv_getElem actH st₁.serving (Finset.Subset.refl _) hserv_cl).1
    (hlf_set ▸ hlf_card_n) st₁.leafArr.length hlf_nd hlf_set hgt_B os.1 os.2
    with ⟨hbs0_inv_raw, _⟩
  have hbs0_inv : BuildStateInv cp pts st₁.gt (foldResiduals pts actH st₁.serving) bs0 := by
    dsimp only [pts, bs0, P₀_uid]; rwa [hP0_eq] at hbs0_inv_raw
  have hbs0_age : bs0.curNode.nd.age ≤ bs0.curNode.nd.birthSize := by
    dsimp only [bs0, BuildState.init, ManagedNode.openEmpty, NodeInst.openEmpty]; exact Nat.zero_le _
  have hbs0_rem : bs0.insCur + steps ≤ bs0.snapArr.length := by
    dsimp only [bs0, BuildState.init]; rw [Nat.zero_add, hsteps_eq]
  rcases advanceBuildLoop_spec h_clm_7_3 hd he1 cp hh0 hh1 steps leafSeeds hbs0_rem hbs0_age hbs0_inv
    with ⟨_, hsnap_d, hins_d, _, _, _, _, _, _, hbsd_inv, hdone_d, _⟩
  have hins_eq_d : (advanceBuildLoop cp pts steps leafSeeds bs0).insCur =
      (advanceBuildLoop cp pts steps leafSeeds bs0).snapArr.length := by
    rw [hins_d, hsnap_d]; dsimp only [bs0, BuildState.init]; rw [Nat.zero_add, hsteps_eq]
  have hul_cur : u_leaf.nd.curSet = foldResiduals pts actH st₁.serving := hdone_d hins_eq_d
  have hT_sub_act : foldResiduals pts actH st₁.serving ⊆ actH :=
    (chainListInv_getElem actH st₁.serving (Finset.Subset.refl _) hserv_cl).1
  rcases hbsd_inv with ⟨_, _, _, _, _, _, _, _, _, _, _, _, hwf_ul⟩
  have hul_res_nd : u_leaf.resArr.Nodup := hwf_ul.2.1
  have hul_res_lt_n : ∀ x ∈ u_leaf.resArr, x < cp.n := by
    intro x hx
    have hx_in : x ∈ nodeResidual pts u_leaf.nd.o u_leaf.nd.V u_leaf.nd.curSet :=
      hwf_ul.2.2.1 ▸ List.mem_toFinset.mpr hx
    have hx_cur : x ∈ u_leaf.nd.curSet := by unfold nodeResidual at hx_in; exact (@Finset.mem_sdiff _ (Classical.decEq _) _ _ _).mp hx_in |>.1
    exact hact_lt_n x (hT_sub_act (hul_cur ▸ hx_cur))
  unfold leafAllocAndBuildStmt leafAllocAndBuildCost
  refine ExecDet.seq'
    (64 + ops.C_hpj + ops.C_open + (cp.B_scan + 1) * (ops.C_ins + 40))
    (exec_allocFreshSlotStmt ops inp hfp₀ hsr₀ hserv_le₀ hslen₀ hserv_len₀ hserv_slots₀ hjobs₀ hall_lt₀)
    (by omega) ?_
  intro mA ⟨hsrA, ⟨ns, hns_M, hns_fresh, hr39_A⟩, hndA, hftA, _, hfrA⟩ hfpA
  let ctrOff : ℕ := cp.B_S1 + cp.N_op_s2 * cp.B_op + cp.D_max * cp.B_ctr
  refine ExecDet.seq'
    (52 + ops.C_hpj + ops.C_open + (cp.B_scan + 1) * (ops.C_ins + 40))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 15) (.readHeap engScrTbl (.lit 39))
      15 (ns : ℤ) hfpA (by unfold engScrTbl; omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) rfl (by simp only [evalIntExpr]; exact hr39_A)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mS1 hmS1 hfpS1; subst hmS1
  refine ExecDet.seq'
    (40 + ops.C_hpj + ops.C_open + (cp.B_scan + 1) * (ops.C_ins + 40))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 21) (.lit 0) 21 0
      hfpS1 (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
      rfl rfl (by simp [intExprOps]) rfl) (by omega) ?_
  intro mS2 hmS2 hfpS2; subst hmS2
  have hw2_S2 : wRead (H3a.wWrite (H3a.wWrite mA engScrTbl 15 (ns : ℤ)) engScrTbl 21 0)
      engMetaTbl 2 = (st₁.leafArr.length : ℤ) :=
    (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
      ((wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
        ((hftA engMetaTbl (by decide) 2).trans hlf_sp₀.2.2.1))
  refine ExecDet.seq'
    (28 + ops.C_hpj + ops.C_open + (cp.B_scan + 1) * (ops.C_ins + 40))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 22) (.readHeap engMetaTbl (.lit 2))
      22 (st₁.leafArr.length : ℤ) hfpS2 (by unfold engScrTbl; omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) rfl (by simp only [evalIntExpr]; exact hw2_S2)
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mS3 hmS3 hfpS3; subst hmS3
  refine ExecDet.seq'
    (16 + ops.C_hpj + ops.C_open + (cp.B_scan + 1) * (ops.C_ins + 40))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 23) (.lit (ctrOff : ℤ))
      23 (ctrOff : ℤ) hfpS3 (by unfold engScrTbl; omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro mS4 hmS4 hfpS4; subst hmS4
  set mP := H3a.wWrite (H3a.wWrite (H3a.wWrite (H3a.wWrite mA engScrTbl 15 (ns : ℤ))
    engScrTbl 21 0) engScrTbl 22 (st₁.leafArr.length : ℤ)) engScrTbl 23 (ctrOff : ℤ)
  have hw_lt8_P : ∀ t < 8, ∀ i, wRead mP t i = wRead m₀ t i := by
    intro t ht8 i
    have hne8 : t ≠ engScrTbl := by unfold engScrTbl; omega
    simp only [mP, wRead_wWrite_eq]
    simp [hne8, hftA t hne8 i]
  have hw9_PA : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mP t i = wRead mA t i := by
    intro t ht9 _ i
    have hne8 : t ≠ engScrTbl := by unfold engScrTbl; omega
    simp only [mP, wRead_wWrite_eq]; simp [hne8]
  have hr_P : ∀ t i, rRead mP t i = rRead m₀ t i := by
    intro t i; simp only [mP, rRead_wWrite]; exact hfrA t i
  have hsrP : ops.SlotsReady mP :=
    ops.slotsReady_ext mA mP hsrA hw9_PA (fun t _ _ i => by simp only [mP, rRead_wWrite])
  have hndP : ∀ mn' s', s' < M_slots cp → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' mP :=
    fun mn' s' hs' he0 => ops.encNode_ext mn' s' mA mP (hndA mn' s' hs' he0) hw9_PA
      (fun _ _ _ _ => by simp only [mP, rRead_wWrite])
      (fun _ _ _ _ => by simp only [mP, rRead_wWrite])
  obtain ⟨ctrBits, hctr_eq, hctr_bnd, hctr_rd⟩ :=
    memHasStepCoins_stage2_ctr cp bits m₀ hcoins₀ (Fin.last cp.D_max)
  have hlast_val : (Fin.last cp.D_max).val = cp.D_max := rfl
  have hctrOff_eq : cp.B_S1 + cp.N_op_s2 * cp.B_op + (Fin.last cp.D_max).val * cp.B_ctr = ctrOff := by
    rw [hlast_val]
  rw [hctrOff_eq] at hctr_bnd hctr_rd
  have harr_BW : (0 : ℤ) + (st₁.leafArr.length : ℤ) ≤ (ops.BW : ℤ) := by
    have hS : st₁.leafArr.length ≤ S_stride cp := by unfold S_stride; omega
    have h2S : 2 * S_stride cp ≤ (2 + 4 * cp.D_max) * S_stride cp := Nat.mul_le_mul_right _ (by omega)
    have : st₁.leafArr.length ≤ ops.BW := by omega
    exact_mod_cast (show 0 + st₁.leafArr.length ≤ ops.BW by omega)
  refine ExecDet.seq'
    (16 + ops.C_open + (cp.B_scan + 1) * (ops.C_ins + 40))
    (ops.evalHPJCenter_spec inp mP pts st₁.leafArr engArrTbl 0 ctrOff ctrBits 21 22 23
      (by decide) (by omega) hlf_len_n (fun x hx => hlf_sp₀.2.1 x hx)
      (by omega) harr_BW hctr_bnd
      (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
      hfpS4 hsrP
      (by simp only [mP, wRead_wWrite_eq]; simp)
      (by simp only [mP, wRead_wWrite_eq]; simp)
      (wRead_wWrite_self _ _ _ _)
      (fun i hi => (hw_lt8_P engArrTbl (by decide) _).trans (by
        simpa [leafElemOff] using (hlf_sp₀.2.2.2 i hi).1))
      (fun x hx c => (hr_P ptsRTbl _).trans
        (hact_pts_m0 x (hlf_sub_act (List.mem_toFinset.mpr hx)) c))
      (fun k => (hw_lt8_P coinTbl (by decide) _).trans (hctr_rd k)))
    (by omega) ?_
  intro mH ⟨hsrH, ho_H, hs_H, hndH, hwH, hrH_lt2, hrH_20⟩ hfpH
  have hos_eq : evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts st₁.leafArr
      (bitsToCenterSeedEquiv cp ctrBits) = os := by
    dsimp only [os, leafCtr]; rw [hctr_eq]
  rw [hos_eq] at ho_H hs_H
  have hr15_H : wRead mH engScrTbl 15 = (ns : ℤ) :=
    (hwH engScrTbl (by decide) 15).trans (by simp only [mP, wRead_wWrite_eq]; simp)
  have hr22_H : wRead mH engScrTbl 22 = (st₁.leafArr.length : ℤ) :=
    (hwH engScrTbl (by decide) 22).trans (by simp only [mP, wRead_wWrite_eq]; simp)
  refine ExecDet.seq'
    (16 + (cp.B_scan + 1) * (ops.C_ins + 40))
    (ops.openEmpty_spec inp mH ns st₁.leafArr.length os.1 os.2 P₀_uid 15 22
      hns_M hlf_len_n (by omega) (by omega) (by omega) (by omega)
      hfpH hsrH hr15_H hr22_H ho_H hs_H)
    (by omega) ?_
  intro mO ⟨hsrO, henc_bs0, hndO, hwO, hrO⟩ hfpO
  let ωNat : ℕ → OpSeed cp := fun j =>
    if hj : j < steps then leafSeeds ⟨j, hj⟩ else fun _ _ => false
  have hω_eq : leafSeeds = (fun i : Fin steps => ωNat i.val) :=
    funext fun i => by dsimp only [ωNat]; rw [dif_pos i.isLt]
  let bsAt (k : ℕ) : BuildState cp :=
    advanceBuildLoop cp pts k (fun i : Fin k => ωNat i.val) bs0
  have hbsAt_done : (bsAt st₁.leafArr.length).curNode = u_leaf := by
    dsimp only [bsAt, u_leaf]
    rw [← hsteps_eq, ← hω_eq]
  let InvL (k : ℕ) (m : ArithRAMMemory) : Prop :=
    ops.SlotsReady m ∧
    ops.EncNode (bsAt k).curNode ns m ∧
    (∀ mn' s', s' < M_slots cp → s' ≠ ns → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m) ∧
    (∀ t < 8, ∀ i, wRead m t i = wRead m₀ t i) ∧
    wRead m engScrTbl 15 = (ns : ℤ) ∧
    (∀ t < 2, ∀ i, rRead m t i = rRead m₀ t i) ∧
    rRead m engRealTbl 0 = rRead m₀ engRealTbl 0
  have hInvL0 : InvL 0 (H3a.wWrite mO engScrTbl 24 0) := by
    set mZ := H3a.wWrite mO engScrTbl 24 0
    have hw9_Z : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mZ t i = wRead mO t i :=
      fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
    refine ⟨ops.slotsReady_ext mO mZ hsrO hw9_Z (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      ops.encNode_ext bs0.curNode ns mO mZ henc_bs0 hw9_Z
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun mn' s' hs' hne he0 => ops.encNode_ext mn' s' mO mZ
        (hndO mn' s' hs' hne (hndH mn' s' hs' (hndP mn' s' hs' he0))) hw9_Z
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun t ht8 i => (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))).trans
        ((hwO t (by omega) i).trans ((hwH t (by omega) i).trans (hw_lt8_P t ht8 i))),
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
        ((hwO engScrTbl (by decide) 15).trans hr15_H),
      fun t ht2 i => (rRead_wWrite _ _ _ _ _ _).trans
        ((hrO t (by omega) i).trans ((hrH_lt2 t ht2 i).trans (hr_P t i))),
      (rRead_wWrite _ _ _ _ _ _).trans
        ((hrO engRealTbl (by decide) 0).trans (hrH_20.trans (hr_P engRealTbl 0)))⟩
  have hr22_O : wRead mO engScrTbl 22 = (st₁.leafArr.length : ℤ) :=
    (hwO engScrTbl (by decide) 22).trans hr22_H
  refine (ExecDet.dynForLoop (N := st₁.leafArr.length) (N_max := cp.B_scan + 1) (C_b := ops.C_ins + 28)
    24 22 (leafBuildIterStmt ops) InvL hfpO (by omega) (by omega)
    (by unfold M_slots at hBW_scr; omega) (by decide) hr22_O hlf_le1 hInvL0 ?_).mono
    (fun mL ⟨hsrL, henc_ulL, hnd_ulL, hw8_L, hr15_L, hr2_L, hr20_L⟩ _ => by
      rw [hbsAt_done] at henc_ulL
      exact ⟨hsrL, hul_res_nd, hul_res_lt_n,
        ⟨ns, hns_M, hns_fresh, hr15_L, henc_ulL, hnd_ulL⟩,
        hw8_L, hr2_L, hr20_L⟩)
    (le_of_eq (by ring))
  intro k hk m ⟨hsrm, henc_km, hnd_km, hw8_m, hr15_m, hr2_m, hr20_m⟩ hctr hfp
  have hk_steps : k < steps := hsteps_eq.symm ▸ hk
  have hk_le : bs0.insCur + k ≤ bs0.snapArr.length := by
    dsimp only [bs0, BuildState.init]; omega
  rcases advanceBuildLoop_spec h_clm_7_3 hd he1 cp hh0 hh1 k
    (fun i : Fin k => ωNat i.val) hk_le hbs0_age hbs0_inv
    with ⟨_, hsnapk, hins_k, _, _, _, _, _, hagek, hinv_k, _, _⟩
  have hdelsk : (bsAt k).delSnapArr = [] :=
    advanceBuildLoop_delSnapArr cp pts k (fun i : Fin k => ωNat i.val) bs0
  change (bsAt k).snapArr = st₁.leafArr at hsnapk
  change (bsAt k).insCur = 0 + k at hins_k
  change (bsAt k).curNode.nd.age = bs0.curNode.nd.age at hagek
  change BuildStateInv cp pts st₁.gt (foldResiduals pts actH st₁.serving) (bsAt k) at hinv_k
  have hins_eq_k : (bsAt k).insCur = k := by omega
  have hins_lt_k : (bsAt k).insCur < (bsAt k).snapArr.length := by rw [hins_eq_k, hsnapk]; exact hk
  set x := st₁.leafArr[k]'hk
  have hsucc_eq : bsAt (k + 1) = advanceBuildStep cp pts (bsAt k) (ωNat k) :=
    advanceBuildLoop_take_succ cp pts k ωNat bs0
  have hω_k : ωNat k = leafSeeds ⟨k, hk_steps⟩ := by dsimp only [ωNat]; rw [dif_pos hk_steps]
  let s2Idx : Fin cp.N_op_s2 := ⟨cp.D_max * cp.B_scan + k, by
    have hj : k < cp.B_scan + 1 := lt_of_lt_of_le hk hlf_le1
    exact Nat.add_lt_add_left hj _⟩
  obtain ⟨seedBits, hseed_eq, hcoin_bnd, hcoin_rd⟩ :=
    memHasStepCoins_stage2_op cp bits m₀ hcoins₀ s2Idx
  let coinBase : ℤ := ((cp.B_S1 + cp.D_max * cp.B_scan * cp.B_op : ℕ) : ℤ)
  let coinOff : ℕ := cp.B_S1 + (cp.D_max * cp.B_scan + k) * cp.B_op
  have hcoin_eval : coinBase + (k : ℤ) * (cp.B_op : ℤ) = (coinOff : ℤ) := by
    dsimp only [coinBase, coinOff]; push_cast; ring
  have hread_x : wRead m engArrTbl (k : ℤ) = (x : ℤ) :=
    (hw8_m engArrTbl (by decide) _).trans (by
      simpa [leafElemOff] using (hlf_sp₀.2.2.2 k hk).1)
  unfold leafBuildIterStmt
  refine ExecDet.seq' (ops.C_ins + 16)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 25)
      (.readHeap engArrTbl (.readHeap engScrTbl (.lit 24)))
      25 (x : ℤ) hfp (by unfold engScrTbl; omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) rfl
      (by simp only [evalIntExpr]
          change wRead m engArrTbl (wRead m engScrTbl 24) = _
          rw [hctr, hread_x])
      (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m1 hm1 hfp1; subst hm1
  refine ExecDet.seq' ops.C_ins
    (ExecDet.wWrite (C := 16) inp engScrTbl (.lit 26)
      (.add (.lit coinBase) (.mul (.readHeap engScrTbl (.lit 24)) (.lit (cp.B_op : ℤ))))
      26 (coinOff : ℤ) hfp1 (by unfold engScrTbl; omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) rfl
      (by simp only [evalIntExpr]
          change coinBase + wRead (H3a.wWrite m engScrTbl 25 (x : ℤ)) engScrTbl 24 * (cp.B_op : ℤ) = _
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hctr, hcoin_eval])
      (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m2 hm2 hfp2; subst hm2
  set m2_st := H3a.wWrite (H3a.wWrite m engScrTbl 25 (x : ℤ)) engScrTbl 26 (coinOff : ℤ)
  have hw9_2m : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m2_st t i = wRead m t i :=
    fun t ht9 _ i => (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))).trans
      (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega)))
  have hsr2 : ops.SlotsReady m2_st :=
    ops.slotsReady_ext m m2_st hsrm hw9_2m
      (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
  have henc_k2 : ops.EncNode (bsAt k).curNode ns m2_st :=
    ops.encNode_ext _ ns m m2_st henc_km hw9_2m
      (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
      (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
  rcases hinv_k with ⟨_, _, _, _, _, _, _, hdisj_k, hunion_k, _, hhist_k, htins_k, hwf_k⟩
  have hx_in_rem : x ∈ (bsAt k).remSnap := by
    unfold BuildState.remSnap
    rw [Finset.mem_sdiff]
    refine ⟨List.mem_toFinset.mpr ?_, fun hm => ?_⟩
    · rw [hsnapk, hins_eq_k, List.drop_eq_getElem_cons hk]; exact List.mem_cons_self
    · rw [hdelsk] at hm; simp at hm
  have hx_in_T : x ∈ foldResiduals pts actH st₁.serving :=
    hunion_k ▸ Finset.mem_union_right _ hx_in_rem
  have hx_n : x < cp.n := hact_lt_n x (hT_sub_act hx_in_T)
  have hx_not_cur : x ∉ (bsAt k).curNode.nd.curSet :=
    fun hm => Finset.disjoint_left.mp hdisj_k hm hx_in_rem
  have hcur_sub_act : (bsAt k).curNode.nd.curSet ⊆ actH :=
    (hunion_k ▸ Finset.subset_union_left).trans hT_sub_act
  have hcur_n : ∀ y ∈ (bsAt k).curNode.nd.curSet, y < cp.n :=
    fun y hy => hact_lt_n y (hcur_sub_act hy)
  have hage0_k : (bsAt k).curNode.nd.age = 0 := by rw [hagek]; rfl
  have hk_lt_n : k < cp.n := lt_of_lt_of_le hk hlf_len_n
  have hhist_bnd : (bsAt k).curNode.histArr.length + 1 ≤ 4 * cp.n + 4 := by omega
  have hcap_bnd : ((bsAt k).insCur + (bsAt k).curNode.nd.age) + 1 < 2 ^ cp.L_p2 := by
    have := cp.hL_p2; omega
  refine (ops.insertMat_spec inp m2_st pts (bsAt k).curNode ns x coinOff
    ((bsAt k).insCur + (bsAt k).curNode.nd.age) seedBits 15 25 26
    hns_M hx_n hx_not_cur hcur_n hhist_bnd htins_k hcap_bnd hwf_k hcoin_bnd
    (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
    hfp2 hsr2 henc_k2
    (by simp only [m2_st, wRead_wWrite_eq]; simp [hr15_m])
    (by simp only [m2_st, wRead_wWrite_eq]; simp)
    (wRead_wWrite_self _ _ _ _)
    (fun y hy c => by
      have hy_act : y ∈ actH := by
        rcases Finset.mem_insert.mp hy with rfl | hyc
        · exact hT_sub_act hx_in_T
        · exact hcur_sub_act hyc
      simp only [m2_st, rRead_wWrite]
      exact (hr2_m ptsRTbl (by decide) _).trans (hact_pts_m0 y hy_act c))
    (fun j => by
      simp only [m2_st, wRead_wWrite_eq]
      exact (hw8_m coinTbl (by decide) _).trans (hcoin_rd j))).mono ?_ le_rfl
  intro m' ⟨hsr', henc', hnd', hw', hr'⟩ _
  have hcur_succ : (bsAt (k + 1)).curNode =
      (bsAt k).curNode.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e)
        params cp.specs cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts x
        (bitsToOpSeedEquiv cp seedBits) := by
    rw [hsucc_eq]; unfold advanceBuildStep
    rw [dif_pos hins_lt_k]; dsimp only
    have hget_x : (bsAt k).snapArr[(bsAt k).insCur]'hins_lt_k = x := by
      simp only [x, hsnapk, hins_eq_k]
    rw [hget_x, hdelsk]
    change (if ([] : List ℕ).contains x then _ else _) = _
    rw [if_neg (by simp), hω_k]
    have hls_eq : leafSeeds ⟨k, hk_steps⟩ = bitsToOpSeedEquiv cp seedBits := by
      dsimp only [leafSeeds]; exact hseed_eq
    rw [hls_eq]
  rw [← hcur_succ] at henc'
  have hctr' : wRead m' engScrTbl 24 = (k : ℤ) :=
    (hw' engScrTbl (by decide) 24).trans
      (by simp only [m2_st, wRead_wWrite_eq]; simp [hctr])
  refine ⟨hctr', ?_⟩
  set mN := H3a.wWrite m' engScrTbl 24 ((k : ℤ) + 1)
  have hw9_N : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mN t i = wRead m' t i :=
    fun t ht9 _ i => wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))
  exact ⟨ops.slotsReady_ext m' mN hsr' hw9_N (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
    ops.encNode_ext _ ns m' mN henc' hw9_N
      (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
    fun mn' s' hs' hne he0 => ops.encNode_ext mn' s' m' mN
      (hnd' mn' s' hs' hne (ops.encNode_ext mn' s' m m2_st (hnd_km mn' s' hs' hne he0) hw9_2m
        (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))
        (fun _ _ _ _ => (rRead_wWrite _ _ _ _ _ _).trans (rRead_wWrite _ _ _ _ _ _))))
      hw9_N (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _) (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
    fun t ht8 i => (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engScrTbl; omega))).trans
      ((hw' t (by omega) i).trans (by
        have hne8 : t ≠ engScrTbl := by unfold engScrTbl; omega
        simp only [m2_st, wRead_wWrite_eq]; simp [hne8, hw8_m t ht8 i])),
    (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
      ((hw' engScrTbl (by decide) 15).trans
        (by simp only [m2_st, wRead_wWrite_eq]; simp [hr15_m])),
    fun t ht2 i => (rRead_wWrite _ _ _ _ _ _).trans
      ((hr' t (by omega) i).trans (by simp only [m2_st, rRead_wWrite]; exact hr2_m t ht2 i)),
    (rRead_wWrite _ _ _ _ _ _).trans
      ((hr' engRealTbl (by decide) 0).trans (by simp only [m2_st, rRead_wWrite]; exact hr20_m))⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage2
