import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideA1

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead InFootprint wRead_wWrite_self wRead_wWrite_of_ne rRead_wWrite)
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot slotWStride slotRStride slotWStride_ge_four liveSlotUnlinkLocStmt exec_liveSlotUnlinkLocStmt)

theorem exec_h4_dyadicSideRemoveStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wH0 wScr sideBaseW sideBaseR : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord cap_u h₀ : ℕ}
    (hn : 1 ≤ n) (hM₀ : 1 ≤ M₀)
    {A B_rat τ_d : ℚ}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {U : Finset ℕ} {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b}
    (hwf : H4b.DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htblW : tblW < TW)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ sideBaseW ∧ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideRemoveWStride ≤ (BW : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + dyadicSideRemoveWStride ≤ wSideBaseW)
    (hdisjH0 : wH0 < wScr ∨ wScr + dyadicSideRemoveWStride ≤ wH0)
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hh0 : wRead m₀ scrW wH0 = (h₀ : ℤ))
    (henc₀ : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (dyadicSideRemoveStmt scrW tblW wSideBaseW wH0 wScr n L_p2 R ℓ M₀ cap_u)
        m₀ m₁ (dyadicSideRemoveCost L_p2 R cap_u) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u
        (U.erase h₀) (idx.removeHandle h₀) m₁ ∧
      (∀ w, (w < wScr ∨ wScr + dyadicSideRemoveWStride ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) ∧
      (∀ r, rRead m₁ scrR r = rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
        tblR sideBaseR 0 m₀ m₁ := by
  have hpow_pos : (1 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (@Nat.one_le_two_pow L_p2)
  have hstride : dyadicSideRemoveWStride = 16 := rfl
  rw [hstride] at hwScr hdisjBW hdisjH0
  rcases henc₀ with ⟨ht_le, ep₀, live₀, hep1, hep_r, ht_r, hhand, hal_le, hal_iff, hact, hpt, hslots₀, hcur₀⟩
  let rem := h₀ % n
  let eid_cand : ℤ := wRead m₀ tblW (sideActiveOff L_p2 sideBaseW rem)
  let m1 := wWrite m₀ scrW wScr (rem : ℤ)
  let m2 := wWrite m1 scrW (wScr + 1) eid_cand
  let m3 := wWrite m2 scrW (wScr + 2) (ep₀ : ℤ)
  let m4 := wWrite m3 scrW (wScr + 3) (idx.t_ins : ℤ)
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.mod (.readHeap scrW (.lit wH0)) (.lit (n : ℤ)))) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wScr) _ rfl
      (by change wRead m₀ scrW wH0 % (n : ℤ) = (rem : ℤ)
          rw [hh0]; exact (Int.natCast_emod h₀ n).symm)
      (by dsimp [intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
      (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW))
                                  (.lit (2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ))))
                            (.readHeap scrW (.lit wScr))))) m1 m2 30 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 1)) _ rfl
      (by change wRead m1 tblW ((wRead m1 scrW wSideBaseW + (2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ))) +
            wRead m1 scrW wScr) = eid_cand
          have hb1 : wRead m1 scrW wSideBaseW = sideBaseW :=
            (wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega))).trans hbW
          have hr1 : wRead m1 scrW wScr = (rem : ℤ) := wRead_wWrite_self _ _ _ _
          rw [hb1, hr1, wRead_wWrite_of_ne _ _ (Or.inl hneW)]
          dsimp only [eid_cand]; unfold sideActiveOff; ring_nf)
      (by dsimp [intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2))
      (.readHeap tblW (.readHeap scrW (.lit wSideBaseW)))) m2 m3 20 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wScr + 2)) _ rfl
      (by change wRead m2 tblW (wRead m2 scrW wSideBaseW) = (ep₀ : ℤ)
          have hb2 : wRead m2 scrW wSideBaseW = sideBaseW := by
            simp only [m2, m1]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega))]
            exact hbW
          rw [hb2, wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
          exact hep_r)
      (by dsimp [intExprOps]; omega)
  have hd4 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 3))
      (.readHeap tblW (.add (.readHeap scrW (.lit wSideBaseW)) (.lit 1)))) m3 m4 25 :=
    DetExecAt.writeWordHeap 0 inp m3 scrW (.lit (wScr + 3)) _ rfl
      (by change wRead m3 tblW (wRead m3 scrW wSideBaseW + 1) = (idx.t_ins : ℤ)
          have hb3 : wRead m3 scrW wSideBaseW = sideBaseW := by
            simp only [m3, m2, m1]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega))]
            exact hbW
          rw [hb3, wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_of_ne _ _ (Or.inl hneW)]
          exact ht_r)
      (by dsimp [intExprOps]; omega)
  have hfp4 : InFootprint TW BW TR BR m4 :=
    InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite
      (InFootprint.wWrite hfp₀ hscrW hwScr.1 (by omega))
      hscrW (by omega) (by omega)) hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hfr04_0 : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m₀ m4 :=
    (((RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m₀ _ _).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m1 _ _)).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m2 _ _)).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m3 _ _)
  have hkW4 : ∀ w, (w < wScr ∨ wScr + 4 ≤ w) → wRead m4 scrW w = wRead m₀ scrW w := by
    intro w hw; simp only [m4, m3, m2, m1]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  have heid4 : wRead m4 scrW (wScr + 1) = eid_cand := by
    simp only [m4, m3, m2]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hep4 : wRead m4 scrW (wScr + 2) = (ep₀ : ℤ) := by
    simp only [m4, m3]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have ht4 : wRead m4 scrW (wScr + 3) = (idx.t_ins : ℤ) := wRead_wWrite_self _ _ _ _
  have hmem_tbl4 : ∀ i, wRead m4 tblW i = wRead m₀ tblW i := fun i =>
    hfr04_0.1 tblW i hneW (Or.inr (by rcases lt_or_ge i sideBaseW with h | h; exact Or.inl h; exact Or.inr (by omega)))
  have henc_m4 : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m4 := by
    have henc0_full : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀ :=
      ⟨ht_le, ep₀, live₀, hep1, hep_r, ht_r, hhand, hal_le, hal_iff, hact, hpt, hslots₀, hcur₀⟩
    exact henc0_full.mono_frame hn hfr04_0 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  have hnoop_enc : ∀ {m : ArithRAMMemory},
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m →
      idx.removeHandle h₀ = idx →
      h₀ ∉ U →
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u (U.erase h₀) (idx.removeHandle h₀) m := by
    intro m he hr hnot
    rw [hr, Finset.erase_eq_of_notMem hnot]
    exact he
  by_cases hrange : 0 ≤ eid_cand ∧ eid_cand < (idx.t_ins : ℤ)
  · have hc_rng : cValAt 0 inp m4
        (.and (.intLe (.lit 0) (.readHeap scrW (.lit (wScr + 1))))
              (.intLt (.readHeap scrW (.lit (wScr + 1))) (.readHeap scrW (.lit (wScr + 3))))) = true := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change (decide (0 ≤ wRead m4 scrW (wScr + 1)) &&
              decide (wRead m4 scrW (wScr + 1) < wRead m4 scrW (wScr + 3))) = true
      rw [heid4, ht4]; simp [hrange.1, hrange.2]
    let e₀ := eid_cand.toNat
    have he₀_cast : (e₀ : ℤ) = eid_cand := Int.toNat_of_nonneg hrange.1
    have he₀_lt : e₀ < idx.t_ins := by omega
    have hbW4 : wRead m4 scrW wSideBaseW = sideBaseW :=
      (hkW4 _ (by rcases hdisjBW with h | h <;> omega)).trans hbW
    have hh0_4 : wRead m4 scrW wH0 = (h₀ : ℤ) :=
      (hkW4 _ (by rcases hdisjH0 with h | h <;> omega)).trans hh0
    have hal_addr : (sideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) + eid_cand =
        sideAliveEpOff L_p2 sideBaseW e₀ := by
      rw [← he₀_cast]; unfold sideAliveEpOff; ring
    have hhd_addr : (sideBaseW + 2) + eid_cand = sideHandleOff sideBaseW e₀ := by
      rw [← he₀_cast]; unfold sideHandleOff; ring
    by_cases hmatch : wRead m₀ tblW (sideAliveEpOff L_p2 sideBaseW e₀) = (ep₀ : ℤ) ∧
        wRead m₀ tblW (sideHandleOff sideBaseW e₀) = (h₀ : ℤ)
    ·
      have hal_true : idx.entryAlive e₀ = true := (hal_iff e₀ he₀_lt).mp hmatch.1
      have hhd_eq : idx.entryHandle e₀ = h₀ := by
        have := (hhand e₀ he₀_lt).symm.trans hmatch.2; exact_mod_cast this
      rcases hwf.2.2.2.1 e₀ he₀_lt hal_true with ⟨hh₀_mem, hae_eq, _⟩
      rw [hhd_eq] at hh₀_mem hae_eq
      have hc_mat : cValAt 0 inp m4
          (.and (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW))
                                                    (.lit (2 + ((2 ^ L_p2 : ℕ) : ℤ))))
                                              (.readHeap scrW (.lit (wScr + 1)))))
                        (.readHeap scrW (.lit (wScr + 2))))
                (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit 2))
                                              (.readHeap scrW (.lit (wScr + 1)))))
                        (.readHeap scrW (.lit wH0)))) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change (decide (wRead m4 tblW ((wRead m4 scrW wSideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) +
                  wRead m4 scrW (wScr + 1)) = wRead m4 scrW (wScr + 2)) &&
                decide (wRead m4 tblW ((wRead m4 scrW wSideBaseW + 2) +
                  wRead m4 scrW (wScr + 1)) = wRead m4 scrW wH0)) = true
        rw [hbW4, heid4, hep4, hh0_4, hal_addr, hhd_addr, hmem_tbl4, hmem_tbl4, hmatch.1, hmatch.2]
        simp
      have hpure_eq : idx.removeHandle h₀ = { idx with entryAlive := Function.update idx.entryAlive e₀ false } := by
        unfold H4b.DyadicSideIndex.removeHandle; dsimp only
        rw [hae_eq]
        have hc : (e₀ < idx.t_ins && idx.entryAlive e₀ && decide (idx.entryHandle e₀ = h₀)) = true := by
          simp [he₀_lt, hal_true, hhd_eq]
        rw [if_pos hc]
      let alOff := sideAliveEpOff L_p2 sideBaseW e₀
      have he₀_B : (e₀ : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (lt_of_lt_of_le he₀_lt ht_le)
      have halOff_in : sideBaseW ≤ alOff ∧ alOff < sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u := by
        have hh := dyadicSideWStride_ge_hdrEnd n L_p2 R ℓ M₀ cap_u
        have he0 : (0 : ℤ) ≤ (e₀ : ℤ) := Nat.cast_nonneg e₀; have hn0 : (0 : ℤ) ≤ (n : ℤ) := Nat.cast_nonneg n; change sideBaseW ≤ sideAliveEpOff L_p2 sideBaseW e₀ ∧ sideAliveEpOff L_p2 sideBaseW e₀ < sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u; unfold sideAliveEpOff; constructor <;> linarith
      let m5 := wWrite m4 tblW alOff 0
      let m6 := wWrite m5 scrW (wScr + 4) 0
      have hd5 : DetExec inp (.writeWordHeap tblW
          (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit (2 + ((2 ^ L_p2 : ℕ) : ℤ))))
                (.readHeap scrW (.lit (wScr + 1)))) (.lit 0)) m4 m5 30 :=
        DetExecAt.writeWordHeap 0 inp m4 tblW _ (.lit 0)
          (by change (wRead m4 scrW wSideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) +
                wRead m4 scrW (wScr + 1) = alOff
              rw [hbW4, heid4, hal_addr])
          rfl (by dsimp [intExprOps]; omega)
      have hd6 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 4)) (.lit 0)) m5 m6 10 :=
        DetExecAt.writeWordHeap 0 inp m5 scrW (.lit (wScr + 4)) (.lit 0) rfl rfl
          (by dsimp [intExprOps]; omega)
      have hfp6 : InFootprint TW BW TR BR m6 :=
        InFootprint.wWrite (InFootprint.wWrite hfp4 htblW (by omega) (by omega)) hscrW (by omega) (by omega)
      have hfr46_hdr : RadFrameOutside scrW scrR tblW alOff 1 tblR sideBaseR 0 m4 m6 :=
        (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m4 (idx := alOff) 0 le_rfl (by omega)).trans
          (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m5 (wScr + 4) 0)
      have hfr06 : RadFrameOutside scrW scrR tblW sideBaseW
          (dyadicSideWStride n L_p2 R ℓ M₀ cap_u) tblR sideBaseR 0 m₀ m6 :=
        (hfr04_0.mono_range (Or.inl rfl) (Or.inl rfl)).trans
          (hfr46_hdr.mono_range (Or.inr ⟨halOff_in.1, by omega⟩) (Or.inl rfl))
      let N := 2 * L_p2
      let slotOf : ∀ j, j < N → LiveSlot R ℓ M₀ d :=
        fun j hj => live₀ (sideSlotScale j hj) (sideSlotBuf j)
      let slotAfter : ∀ j, j < N → LiveSlot R ℓ M₀ d := fun j hj =>
        let S := slotOf j hj
        if decide (0 ≤ S.blkId ∧ S.blkId ≤ (e₀ : ℤ) ∧ (e₀ : ℤ) < S.blkId + (S.builtCnt : ℤ)) then
          S.unlinkLoc (R * cap_u) (e₀ - S.blkId.toNat)
        else S
      let hdrEnd := sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
      let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
        InFootprint TW BW TR BR m ∧
        wRead m scrW (wScr + 1) = (e₀ : ℤ) ∧
        wRead m scrW (wScr + 4) = (k : ℤ) ∧
        (∀ i, sideBaseW ≤ i → i < hdrEnd → wRead m tblW i = wRead m6 tblW i) ∧
        (∀ i, sideBaseR ≤ i → i < sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d →
          rRead m tblR i = rRead m₀ tblR i) ∧
        (∀ j (hj : j < N),
          EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW j)
            tblR (sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR j)
            R ℓ M₀ d cap_u (2 ^ L_p2)
            (if j < k then slotAfter j hj else slotOf j hj) m) ∧
        (∀ w, (w < wScr ∨ wScr + dyadicSideRemoveWStride ≤ w) → wRead m scrW w = wRead m₀ scrW w) ∧
        (∀ r, rRead m scrR r = rRead m₀ scrR r) ∧
        RadFrameOutside scrW scrR tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
          tblR sideBaseR 0 m₀ m
      have hInv0 : Inv 0 m6 := by
        refine ⟨hfp6, ?_, wRead_wWrite_self _ _ _ _, fun _ _ _ => rfl, fun i _ _ => rfl,
          fun j hj => ?_, ?_, fun _ => rfl, hfr06⟩
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), heid4, he₀_cast]
        · simp only [Nat.not_lt_zero, ↓reduceIte]
          have hbw := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hj
          have hbr := sideSlotBaseR_bounds (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d) sideBaseR hj
          have henc_j := (hslots₀ (sideSlotScale j hj) (sideSlotBuf j)).2
          rw [sideSlotIdx_scale_buf j hj] at henc_j
          exact (henc_j.mono_frame hfr04_0 hneW hneR
            (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))).mono_frame
            hfr46_hdr hneW hneR
            (Or.inr (Or.inr (by have h1 := hbw.1; change sideAliveEpOff L_p2 sideBaseW e₀ + 1 ≤ _; unfold sideAliveEpOff; linarith)))
            (Or.inr (Or.inr (by omega)))
        · intro w hw
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
          exact hkW4 w (by unfold dyadicSideRemoveWStride at hw; omega)
      let stepCost := 200 + 400 * (R * cap_u)
      obtain ⟨m_end, hInvN, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (N : ℤ))
        (dyadicSideRemoveSlotStepStmt scrW tblW wSideBaseW wScr n L_p2 R ℓ M₀ cap_u)
        N 5 stepCost Inv hInv0 rfl
        (by dsimp [intExprOps]; omega) (fun k hk m hIm => by
          rcases hIm with ⟨hfp_m, heid_m, hk_m, hhdr_m, htblR_m, henc_all, hkW_m, hkR_m, hfr_m⟩
          let slotBW := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW k
          let slotBR := sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR k
          let S := slotOf k hk
          have hbw_k := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u) sideBaseW hk
          have hge4 := slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2)
          have hbW_m : wRead m scrW wSideBaseW = sideBaseW := (hkW_m _ hdisjBW).trans hbW
          have henc_S_m : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S m := by
            have h0 := henc_all k hk; simp only [lt_irrefl, ↓reduceIte] at h0; exact h0
          let m_a := wWrite m scrW (wScr + 5) slotBW
          let m_b := wWrite m_a scrW (wScr + 6) S.blkId
          let m_c := wWrite m_b scrW (wScr + 7) (S.builtCnt : ℤ)
          have hd_a : DetExec inp (.writeWordHeap scrW (.lit (wScr + 5))
              (.add (.add (.readHeap scrW (.lit wSideBaseW))
                          (.lit (2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ))))
                    (.mul (.readHeap scrW (.lit (wScr + 4)))
                          (.lit (slotWStride R ℓ M₀ cap_u (2 ^ L_p2)))))) m m_a 35 :=
            DetExecAt.writeWordHeap 0 inp m scrW (.lit (wScr + 5)) _ rfl
              (by change (wRead m scrW wSideBaseW + _) + wRead m scrW (wScr + 4) * _ = slotBW
                  rw [hbW_m, hk_m]; dsimp [slotBW, sideSlotBaseW]; ring)
              (by dsimp [intExprOps]; omega)
          have hd_b : DetExec inp (.writeWordHeap scrW (.lit (wScr + 6))
              (.readHeap tblW (.add (.readHeap scrW (.lit (wScr + 5))) (.lit 1)))) m_a m_b 25 :=
            DetExecAt.writeWordHeap 0 inp m_a scrW (.lit (wScr + 6)) _ rfl
              (by change wRead m_a tblW (wRead m_a scrW (wScr + 5) + 1) = S.blkId
                  rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl hneW)]
                  exact henc_S_m.2.1)
              (by dsimp [intExprOps]; omega)
          have hd_c : DetExec inp (.writeWordHeap scrW (.lit (wScr + 7))
              (.readHeap tblW (.add (.readHeap scrW (.lit (wScr + 5))) (.lit 2)))) m_b m_c 25 :=
            DetExecAt.writeWordHeap 0 inp m_b scrW (.lit (wScr + 7)) _ rfl
              (by change wRead m_b tblW (wRead m_b scrW (wScr + 5) + 2) = (S.builtCnt : ℤ)
                  have hbs : wRead m_b scrW (wScr + 5) = slotBW :=
                    (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _)
                  rw [hbs, wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)]
                  exact henc_S_m.2.2.1)
              (by dsimp [intExprOps]; omega)
          have hfp_c : InFootprint TW BW TR BR m_c :=
            InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp_m hscrW (by omega) (by omega))
              hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
          have hfr_mc : RadFrameOutside scrW scrR tblW slotBW
              (slotWStride R ℓ M₀ cap_u (2 ^ L_p2)) tblR slotBR 0 m m_c :=
            ((RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m _ _).trans
              (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_a _ _)).trans
              (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_b _ _)
          have hfr_mc0 : RadFrameOutside scrW scrR tblW slotBW 0 tblR slotBR 0 m m_c :=
            ((RadFrameOutside.wWrite_scr _ _ _ _ 0 _ _ 0 m _ _).trans
              (RadFrameOutside.wWrite_scr _ _ _ _ 0 _ _ 0 m_a _ _)).trans
              (RadFrameOutside.wWrite_scr _ _ _ _ 0 _ _ 0 m_b _ _)
          have henc_S_mc : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S m_c :=
            henc_S_m.mono_frame hfr_mc0 hneW hneR
              (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
          have heid_mc : wRead m_c scrW (wScr + 1) = (e₀ : ℤ) := by
            simp only [m_c, m_b, m_a]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
            exact heid_m
          have hbid_mc : wRead m_c scrW (wScr + 6) = S.blkId := by
            simp only [m_c, m_b]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
          have hbcnt_mc : wRead m_c scrW (wScr + 7) = (S.builtCnt : ℤ) := wRead_wWrite_self _ _ _ _
          let condInBlk : ArithCondExpr :=
            .and (.and (.intLe (.lit 0) (.readHeap scrW (.lit (wScr + 6))))
                       (.intLe (.readHeap scrW (.lit (wScr + 6))) (.readHeap scrW (.lit (wScr + 1)))))
                 (.intLt (.readHeap scrW (.lit (wScr + 1)))
                         (.add (.readHeap scrW (.lit (wScr + 6))) (.readHeap scrW (.lit (wScr + 7)))))
          let brStmt : ArithRAMStmt :=
            .ite condInBlk
              (.seq (.writeWordHeap scrW (.lit (wScr + 8))
                      (.sub (.readHeap scrW (.lit (wScr + 1))) (.readHeap scrW (.lit (wScr + 6)))))
                    (liveSlotUnlinkLocStmt scrW tblW (wScr + 5) (wScr + 8) (wScr + 9) R ℓ M₀ cap_u))
              .skip
          have hbr_step : ∃ m_d : ArithRAMMemory,
              DetExec inp brStmt m_c m_d (95 + 400 * (R * cap_u)) ∧
              InFootprint TW BW TR BR m_d ∧
              EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) (slotAfter k hk) m_d ∧
              wRead m_d scrW (wScr + 1) = (e₀ : ℤ) ∧
              wRead m_d scrW (wScr + 4) = (k : ℤ) ∧
              (∀ w, (w < wScr ∨ wScr + dyadicSideRemoveWStride ≤ w) → wRead m_d scrW w = wRead m₀ scrW w) ∧
              (∀ r, rRead m_d scrR r = rRead m₀ scrR r) ∧
              RadFrameOutside scrW scrR tblW slotBW
                (slotWStride R ℓ M₀ cap_u (2 ^ L_p2)) tblR slotBR 0 m m_d := by
            by_cases hin : 0 ≤ S.blkId ∧ S.blkId ≤ (e₀ : ℤ) ∧ (e₀ : ℤ) < S.blkId + (S.builtCnt : ℤ)
            · have hc_in : cValAt 0 inp m_c condInBlk = true := by
                simp only [cValAt, condInBlk, evalArithCond, evalIntExpr]
                change ((decide (0 ≤ wRead m_c scrW (wScr + 6)) &&
                         decide (wRead m_c scrW (wScr + 6) ≤ wRead m_c scrW (wScr + 1))) &&
                        decide (wRead m_c scrW (wScr + 1) <
                          wRead m_c scrW (wScr + 6) + wRead m_c scrW (wScr + 7))) = true
                rw [heid_mc, hbid_mc, hbcnt_mc]
                simp [hin.1, hin.2.1, hin.2.2]
              have htr_S := (hslots₀ (sideSlotScale k hk) (sideSlotBuf k)).1
              rcases htr_S.2 hin.1 with ⟨_, _, hwf_S⟩
              have hbc_le : S.builtCnt ≤ 2 ^ L_p2 := hwf_S.1
              let loc := e₀ - S.blkId.toNat
              have hloc_cast : (loc : ℤ) = (e₀ : ℤ) - S.blkId := by dsimp [loc]; omega
              have hloc_lt : loc < 2 ^ L_p2 := by dsimp [loc]; omega
              let m_loc := wWrite m_c scrW (wScr + 8) (loc : ℤ)
              have hd_loc : DetExec inp (.writeWordHeap scrW (.lit (wScr + 8))
                  (.sub (.readHeap scrW (.lit (wScr + 1))) (.readHeap scrW (.lit (wScr + 6))))) m_c m_loc 25 :=
                DetExecAt.writeWordHeap 0 inp m_c scrW (.lit (wScr + 8)) _ rfl
                  (by change wRead m_c scrW (wScr + 1) - wRead m_c scrW (wScr + 6) = (loc : ℤ)
                      rw [heid_mc, hbid_mc, hloc_cast])
                  (by dsimp [intExprOps]; omega)
              have hfp_loc : InFootprint TW BW TR BR m_loc :=
                InFootprint.wWrite hfp_c hscrW (by omega) (by omega)
              have henc_loc : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S m_loc :=
                henc_S_mc.mono_frame
                  (RadFrameOutside.wWrite_scr scrW scrR tblW slotBW 0 tblR slotBR 0 m_c (wScr + 8) (loc : ℤ))
                  hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
              have hbW_loc : wRead m_loc scrW (wScr + 5) = slotBW := by
                simp only [m_loc, m_c, m_b, m_a]
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
              obtain ⟨m_d, hd_u, hfp_d, henc_d, hkW_d, hkR_d, hfr_d⟩ :=
                exec_liveSlotUnlinkLocStmt (scrR := scrR) inp (wScr + 5) (wScr + 8) (wScr + 9)
                  slotBW slotBR hM₀ hloc_lt hwf_S hfp_loc hscrW htblW hneW hneR
                  ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
                  (Or.inl (by omega)) (Or.inl (by omega))
                  hbW_loc (wRead_wWrite_self _ _ _ _) henc_loc
              have hd_ite : DetExec inp brStmt m_c m_d _ := DetExecAt.ite_true (C_c := 20) hc_in
                (by dsimp [condInBlk, condExprOps, intExprOps]; omega)
                (hd_loc.seq hd_u)
              have hsl_eq : slotAfter k hk = S.unlinkLoc (R * cap_u) loc := by
                dsimp [slotAfter, S, loc]; rw [decide_eq_true hin]; rfl
              rw [hsl_eq]
              refine ⟨m_d, hd_ite.mono_cost (by omega), hfp_d, henc_d, ?_, ?_, ?_, ?_,
                (hfr_mc.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_c _ _)).trans hfr_d⟩
              · rw [hkW_d _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                exact heid_mc
              · rw [hkW_d _ (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                simp only [m_c, m_b, m_a]
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                exact hk_m
              · intro w hw
                rw [hkW_d _ (by unfold dyadicSideRemoveWStride at hw; rcases hw with h | h; exact Or.inl (by omega); exact Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                simp only [m_c, m_b, m_a]
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                exact hkW_m w hw
              · intro r; rw [hkR_d r]; simp only [m_loc, m_c, m_b, m_a, rRead_wWrite]; exact hkR_m r
            · have hc_out : cValAt 0 inp m_c condInBlk = false := by
                simp only [cValAt, condInBlk, evalArithCond, evalIntExpr]
                change ((decide (0 ≤ wRead m_c scrW (wScr + 6)) &&
                         decide (wRead m_c scrW (wScr + 6) ≤ wRead m_c scrW (wScr + 1))) &&
                        decide (wRead m_c scrW (wScr + 1) <
                          wRead m_c scrW (wScr + 6) + wRead m_c scrW (wScr + 7))) = false
                rw [heid_mc, hbid_mc, hbcnt_mc]
                by_contra htr
                have ht1 : ((decide (0 ≤ S.blkId) && decide (S.blkId ≤ (e₀ : ℤ))) &&
                    decide ((e₀ : ℤ) < S.blkId + (S.builtCnt : ℤ))) = true :=
                  Bool.eq_true_of_not_eq_false htr
                simp only [Bool.and_eq_true, decide_eq_true_eq] at ht1
                exact hin ⟨ht1.1.1, ht1.1.2, ht1.2⟩
              have hd_ite : DetExec inp brStmt m_c m_c _ := DetExecAt.ite_false (C_c := 20) hc_out
                (by dsimp [condInBlk, condExprOps, intExprOps]; omega)
                (DetExecAt.skip 0 inp m_c)
              have hsl_eq : slotAfter k hk = S := by
                dsimp [slotAfter, S]; rw [decide_eq_false hin]; rfl
              rw [hsl_eq]
              refine ⟨m_c, hd_ite.mono_cost (by omega), hfp_c, henc_S_mc, heid_mc, ?_, ?_, ?_, hfr_mc⟩
              · simp only [m_c, m_b, m_a]
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                exact hk_m
              · intro w hw
                simp only [m_c, m_b, m_a]
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                exact hkW_m w hw
              · intro r; simp only [m_c, m_b, m_a, rRead_wWrite]; exact hkR_m r
          obtain ⟨m_d, hd_br, hfp_d, henc_d, heid_d, hk_d, hkW_d, hkR_d, hfr_d⟩ := hbr_step
          let m_e := wWrite m_d scrW (wScr + 4) ((k + 1 : ℕ) : ℤ)
          have hd_e : DetExec inp (.writeWordHeap scrW (.lit (wScr + 4))
              (.add (.readHeap scrW (.lit (wScr + 4))) (.lit 1))) m_d m_e 20 :=
            DetExecAt.writeWordHeap 0 inp m_d scrW (.lit (wScr + 4)) _ rfl
              (by change wRead m_d scrW (wScr + 4) + 1 = _; rw [hk_d]; push_cast; ring)
              (by dsimp [intExprOps]; omega)
          have hfp_e : InFootprint TW BW TR BR m_e := InFootprint.wWrite hfp_d hscrW (by omega) (by omega)
          have hfr_me : RadFrameOutside scrW scrR tblW slotBW
              (slotWStride R ℓ M₀ cap_u (2 ^ L_p2)) tblR slotBR 0 m m_e :=
            hfr_d.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_d _ _)
          have hfr_tot : RadFrameOutside scrW scrR tblW sideBaseW
              (dyadicSideWStride n L_p2 R ℓ M₀ cap_u) tblR sideBaseR 0 m₀ m_e :=
            hfr_m.trans (hfr_me.mono_range (Or.inr ⟨by dsimp [slotBW]; omega, by dsimp [slotBW]; omega⟩) (Or.inl rfl))
          refine ⟨m_e, (hd_a.seq (hd_b.seq (hd_c.seq (hd_br.seq hd_e)))).mono_cost (by dsimp [stepCost]; omega),
            hfp_e,
            (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans heid_d,
            wRead_wWrite_self _ _ _ _,
            fun i hlo hhi => ?_,
            fun i hlo hhi => ?_,
            fun j hj => ?_,
            fun w hw => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hkW_d w hw),
            fun r => (rRead_wWrite _ _ _ _ _ _).trans (hkR_d r),
            hfr_tot⟩
          · exact (hfr_me.1 tblW i hneW (Or.inr (Or.inl (by have h1 : hdrEnd ≤ slotBW := hbw_k.1; omega)))).trans
              (hhdr_m i hlo hhi)
          · have ho : tblR ≠ tblR ∨ i < slotBR ∨ slotBR + 0 ≤ i := by
              rcases lt_or_ge i slotBR with h | h; exact Or.inr (Or.inl h); exact Or.inr (Or.inr (by omega))
            exact (hfr_me.2 tblR i hneR ho).trans (htblR_m i hlo hhi)
          · by_cases hjk : j = k
            · subst hjk
              simp only [Nat.lt_succ_self, ↓reduceIte]
              exact henc_d.mono_frame
                (RadFrameOutside.wWrite_scr scrW scrR tblW slotBW 0 tblR slotBR 0 m_d (wScr + 4) ((j + 1 : ℕ) : ℤ))
                hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
            · have hfr_r : RadFrameOutside scrW scrR tblW slotBW (slotWStride R ℓ M₀ cap_u (2 ^ L_p2))
                  tblR slotBR (slotRStride R ℓ M₀ d) m m_e :=
                hfr_me.mono_range (Or.inr ⟨le_rfl, le_rfl⟩)
                  (Or.inr ⟨le_rfl, by have := slotRStride_nonneg R ℓ M₀ d; linarith⟩)
              have hdisjW := sideSlotBaseW_disj (n := n) (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
                sideBaseW hjk
              have hdisjR := sideSlotBaseR_disj (L_p2 := L_p2) (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
                sideBaseR hjk
              have hprev := (henc_all j hj).mono_frame hfr_r hneW hneR (Or.inr hdisjW) (Or.inr hdisjR)
              by_cases hlt : j < k
              · simp only [hlt, Nat.lt_succ_of_lt hlt, ↓reduceIte] at hprev ⊢; exact hprev
              · have hnot1 : ¬ j < k + 1 := by omega
                simp only [hlt, hnot1, ↓reduceIte] at hprev ⊢; exact hprev)
      rcases hInvN with ⟨hfp_f, _, _, hhdr_f, htblR_f, henc_f, hkW_f, hkR_f, hfr_f⟩
      refine ⟨m_end,
        (hd1.seq (hd2.seq (hd3.seq (hd4.seq
          (DetExecAt.ite_true (C_c := 15) hc_rng
            (by dsimp [condExprOps, intExprOps]; omega)
            (DetExecAt.ite_true (C_c := 30) hc_mat
              (by dsimp [condExprOps, intExprOps]; omega)
              (hd5.seq (hd6.seq hd_loop)))))))).mono_cost
          (by dsimp only [N, stepCost]; unfold dyadicSideRemoveCost; omega),
        hfp_f, ?_, hkW_f, hkR_f, hfr_f⟩
      rw [hpure_eq]
      let live' : Fin L_p2 → Fin 2 → LiveSlot R ℓ M₀ d := fun s sl =>
        slotAfter (sideSlotIdx s sl) (sideSlotIdx_lt s sl)
      have hm6_hdr : ∀ i, i ≠ alOff → wRead m6 tblW i = wRead m₀ tblW i := by
        intro i hne
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inr hne)]
        exact hmem_tbl4 i
      refine ⟨ht_le, ep₀, live', hep1,
        (hhdr_f sideBaseW le_rfl (by have hn0 : (0 : ℤ) ≤ (n : ℤ) := Nat.cast_nonneg n; change sideBaseW < sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ); linarith)).trans
          ((hm6_hdr sideBaseW (by change _ ≠ sideAliveEpOff L_p2 sideBaseW e₀; unfold sideAliveEpOff; omega)).trans hep_r),
        (hhdr_f (sideBaseW + 1) (by omega) (by have hn0 : (0 : ℤ) ≤ (n : ℤ) := Nat.cast_nonneg n; change sideBaseW + 1 < sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ); linarith)).trans
          ((hm6_hdr (sideBaseW + 1) (by change _ ≠ sideAliveEpOff L_p2 sideBaseW e₀; unfold sideAliveEpOff; omega)).trans ht_r),
        fun eid heid => ?_,
        fun eid heid => ?_,
        fun eid heid => ?_,
        fun u hu => ?_,
        fun eid heid c => ?_,
        fun s sl => ?_,
        fun s => ?_⟩
      · have heid_B : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (lt_of_lt_of_le heid ht_le)
        exact (hhdr_f _ (by have he0 : (0 : ℤ) ≤ (eid : ℤ) := Nat.cast_nonneg eid; unfold sideHandleOff; linarith) (by have hn0 : (0 : ℤ) ≤ (n : ℤ) := Nat.cast_nonneg n; have hp0 : (0 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := Nat.cast_nonneg _; change sideHandleOff sideBaseW eid < sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ); unfold sideHandleOff; linarith)).trans
          ((hm6_hdr _ (by change _ ≠ sideAliveEpOff L_p2 sideBaseW e₀; unfold sideHandleOff sideAliveEpOff; omega)).trans (hhand eid heid))
      · have heid_B : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast heid
        rw [hhdr_f _ (by have he0 : (0 : ℤ) ≤ (eid : ℤ) := Nat.cast_nonneg eid; have hp0 : (0 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := Nat.cast_nonneg _; unfold sideAliveEpOff; linarith) (by have hn0 : (0 : ℤ) ≤ (n : ℤ) := Nat.cast_nonneg n; change sideAliveEpOff L_p2 sideBaseW eid < sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ); unfold sideAliveEpOff; linarith)]
        by_cases he : eid = e₀
        · subst he
          change wRead m6 tblW alOff ≤ (ep₀ : ℤ)
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_self]; omega
        · rw [hm6_hdr _ (by change _ ≠ sideAliveEpOff L_p2 sideBaseW e₀; unfold sideAliveEpOff; omega)]
          exact hal_le eid heid
      · have heid_B : (eid : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (lt_of_lt_of_le heid ht_le)
        rw [hhdr_f _ (by have he0 : (0 : ℤ) ≤ (eid : ℤ) := Nat.cast_nonneg eid; have hp0 : (0 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := Nat.cast_nonneg _; unfold sideAliveEpOff; linarith) (by have hn0 : (0 : ℤ) ≤ (n : ℤ) := Nat.cast_nonneg n; change sideAliveEpOff L_p2 sideBaseW eid < sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ); unfold sideAliveEpOff; linarith)]
        dsimp only
        by_cases he : eid = e₀
        · rw [he]
          change (wRead m6 tblW alOff = (ep₀ : ℤ) ↔ Function.update idx.entryAlive e₀ false e₀ = true)
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_self, Function.update_self]
          exact ⟨fun h => by omega, fun h => by cases h⟩
        · rw [hm6_hdr _ (by change _ ≠ sideAliveEpOff L_p2 sideBaseW e₀; unfold sideAliveEpOff; omega), Function.update_of_ne he]
          exact hal_iff eid heid
      · have hu_mem : u ∈ U := Finset.mem_of_mem_erase hu
        have hmod : ((u % n : ℕ) : ℤ) < (n : ℤ) := by exact_mod_cast (Nat.mod_lt u hn)
        exact (hhdr_f _ (by have hm0 : (0 : ℤ) ≤ ((u % n : ℕ) : ℤ) := Nat.cast_nonneg _; have hp0 : (0 : ℤ) ≤ ((2 ^ L_p2 : ℕ) : ℤ) := Nat.cast_nonneg _; unfold sideActiveOff; linarith) (by change sideActiveOff L_p2 sideBaseW (u % n) < sideBaseW + 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ); unfold sideActiveOff; linarith)).trans
          ((hm6_hdr _ (by have hm0 : (0 : ℤ) ≤ ((u % n : ℕ) : ℤ) := Nat.cast_nonneg _; change _ ≠ sideAliveEpOff L_p2 sideBaseW e₀; unfold sideActiveOff sideAliveEpOff; omega)).trans (hact u hu_mem))
      · have hb := sideEntryPt_bounds (L_p2 := L_p2) sideBaseR (lt_of_lt_of_le heid ht_le) c
        have hre := dyadicSideRStride_ge_entryEnd L_p2 R ℓ M₀ d
        exact (htblR_f _ (by have := hb.1; omega) (by omega)).trans (hpt eid heid c)
      · have hk_lt := sideSlotIdx_lt s sl
        have henc_s := henc_f (sideSlotIdx s sl) hk_lt
        dsimp only [N] at henc_s
        rw [if_pos hk_lt] at henc_s
        have hslot_eq : slotOf (sideSlotIdx s sl) hk_lt = live₀ s sl := by
          dsimp [slotOf]; rw [sideSlotScale_idx s sl hk_lt, sideSlotBuf_idx s sl]
        have hafter_eq : live' s sl =
            (if decide (0 ≤ (live₀ s sl).blkId ∧ (live₀ s sl).blkId ≤ (e₀ : ℤ) ∧
                  (e₀ : ℤ) < (live₀ s sl).blkId + ((live₀ s sl).builtCnt : ℤ)) then
              (live₀ s sl).unlinkLoc (R * cap_u) (e₀ - (live₀ s sl).blkId.toNat)
            else live₀ s sl) := by
          dsimp [live', slotAfter]; rw [hslot_eq]
        have htr' := (LiveSlotTrackedH4.of_unlinkCond hM₀ (hslots₀ s sl).1 e₀).1
        rw [← hafter_eq] at htr'
        exact ⟨htr', henc_s⟩
      · rcases hcur₀ s with ⟨hc1, hc2, hc3⟩
        have hblk_pres : ∀ sl : Fin 2,
            (live' s sl).blkId = (live₀ s sl).blkId ∧ (live' s sl).builtCnt = (live₀ s sl).builtCnt := by
          intro sl
          have hk_lt := sideSlotIdx_lt s sl
          have hslot_eq : slotOf (sideSlotIdx s sl) hk_lt = live₀ s sl := by
            dsimp [slotOf]; rw [sideSlotScale_idx s sl hk_lt, sideSlotBuf_idx s sl]
          have hpair := (LiveSlotTrackedH4.of_unlinkCond hM₀ (hslots₀ s sl).1 e₀).2
          have hafter_eq : live' s sl =
              (if decide (0 ≤ (live₀ s sl).blkId ∧ (live₀ s sl).blkId ≤ (e₀ : ℤ) ∧
                    (e₀ : ℤ) < (live₀ s sl).blkId + ((live₀ s sl).builtCnt : ℤ)) then
                (live₀ s sl).unlinkLoc (R * cap_u) (e₀ - (live₀ s sl).blkId.toNat)
              else live₀ s sl) := by
            dsimp [live', slotAfter]; rw [hslot_eq]
          rwa [← hafter_eq] at hpair
        dsimp only at hc1 hc2 hc3 ⊢
        refine ⟨fun hq1 hoff1 hoffH => ?_, fun hq1 hoffH => ?_, fun hq2 => ?_⟩
        · rw [(hblk_pres _).1, (hblk_pres _).2]; exact hc1 hq1 hoff1 hoffH
        · rw [(hblk_pres _).1]; exact hc2 hq1 hoffH
        · rw [(hblk_pres _).1]; exact hc3 hq2
    ·
      have hnot_U : h₀ ∉ U := by
        intro hh₀
        rcases hwf.2.2.1 h₀ hh₀ with ⟨hae_lt, hae_al, hae_hd, _⟩
        have hcand_eq : eid_cand = (idx.activeEid h₀ : ℤ) := hact h₀ hh₀
        have he₀_eq : e₀ = idx.activeEid h₀ := by dsimp [e₀]; omega
        rw [he₀_eq] at hmatch
        exact hmatch ⟨(hal_iff _ hae_lt).mpr hae_al, by rw [hhand _ hae_lt, hae_hd]⟩
      have hpure_noop : idx.removeHandle h₀ = idx := by
        unfold H4b.DyadicSideIndex.removeHandle; dsimp only
        split_ifs with hc
        · simp only [Bool.and_eq_true, decide_eq_true_eq] at hc
          rcases hwf.2.2.2.1 _ hc.1.1 hc.1.2 with ⟨hmem, _, _⟩
          rw [hc.2] at hmem; exact absurd hmem hnot_U
        · rfl
      have hc_mat_f : cValAt 0 inp m4
          (.and (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW))
                                                    (.lit (2 + ((2 ^ L_p2 : ℕ) : ℤ))))
                                              (.readHeap scrW (.lit (wScr + 1)))))
                        (.readHeap scrW (.lit (wScr + 2))))
                (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW)) (.lit 2))
                                              (.readHeap scrW (.lit (wScr + 1)))))
                        (.readHeap scrW (.lit wH0)))) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change (decide (wRead m4 tblW ((wRead m4 scrW wSideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) +
                  wRead m4 scrW (wScr + 1)) = wRead m4 scrW (wScr + 2)) &&
                decide (wRead m4 tblW ((wRead m4 scrW wSideBaseW + 2) +
                  wRead m4 scrW (wScr + 1)) = wRead m4 scrW wH0)) = false
        rw [hbW4, heid4, hep4, hh0_4, hal_addr, hhd_addr, hmem_tbl4, hmem_tbl4]
        by_contra htr
        have ht1 := Bool.eq_true_of_not_eq_false htr
        simp only [Bool.and_eq_true, decide_eq_true_eq] at ht1
        exact hmatch ht1
      exact ⟨m4, (hd1.seq (hd2.seq (hd3.seq (hd4.seq
        (DetExecAt.ite_true (C_c := 15) hc_rng
          (by dsimp [condExprOps, intExprOps]; omega)
          (DetExecAt.ite_false (C_c := 30) hc_mat_f
            (by dsimp [condExprOps, intExprOps]; omega)
            (DetExecAt.skip 0 inp m4))))))).mono_cost (by unfold dyadicSideRemoveCost; omega),
        hfp4, hnoop_enc henc_m4 hpure_noop hnot_U,
        fun w hw => hkW4 w (by unfold dyadicSideRemoveWStride at hw; omega),
        fun _ => rfl,
        hfr04_0.mono_range (Or.inl rfl) (Or.inl rfl)⟩
  ·
    have hnot_U : h₀ ∉ U := by
      intro hh₀
      rcases hwf.2.2.1 h₀ hh₀ with ⟨hae_lt, _, _, _⟩
      have hcand_eq : eid_cand = (idx.activeEid h₀ : ℤ) := hact h₀ hh₀
      exact hrange ⟨by omega, by omega⟩
    have hpure_noop : idx.removeHandle h₀ = idx := by
      unfold H4b.DyadicSideIndex.removeHandle; dsimp only
      split_ifs with hc
      · simp only [Bool.and_eq_true, decide_eq_true_eq] at hc
        rcases hwf.2.2.2.1 _ hc.1.1 hc.1.2 with ⟨hmem, _, _⟩
        rw [hc.2] at hmem; exact absurd hmem hnot_U
      · rfl
    have hc_rng_f : cValAt 0 inp m4
        (.and (.intLe (.lit 0) (.readHeap scrW (.lit (wScr + 1))))
              (.intLt (.readHeap scrW (.lit (wScr + 1))) (.readHeap scrW (.lit (wScr + 3))))) = false := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change (decide (0 ≤ wRead m4 scrW (wScr + 1)) &&
              decide (wRead m4 scrW (wScr + 1) < wRead m4 scrW (wScr + 3))) = false
      rw [heid4, ht4]
      by_contra htr
      have ht1 := Bool.eq_true_of_not_eq_false htr
      simp only [Bool.and_eq_true, decide_eq_true_eq] at ht1
      exact hrange ht1
    exact ⟨m4, (hd1.seq (hd2.seq (hd3.seq (hd4.seq
      (DetExecAt.ite_false (C_c := 15) hc_rng_f
        (by dsimp [condExprOps, intExprOps]; omega)
        (DetExecAt.skip 0 inp m4)))))).mono_cost (by unfold dyadicSideRemoveCost; omega),
      hfp4, hnoop_enc henc_m4 hpure_noop hnot_U,
      fun w hw => hkW4 w (by unfold dyadicSideRemoveWStride at hw; omega),
      fun _ => rfl,
      hfr04_0.mono_range (Or.inl rfl) (Or.inl rfl)⟩

theorem dyadicSideRemoveCost_le (L_p2 R ℓ M₀ cap_u cap_q : ℕ) :
    dyadicSideRemoveCost L_p2 R cap_u ≤
      (1 + cap_u + cap_q + R * ℓ * M₀) * (800 * (L_p2 + 1) * (R + 1)) := by
  unfold dyadicSideRemoveCost
  have h1 : 250 + (2 * L_p2) * (200 + 400 * (R * cap_u)) ≤
      (1 + cap_u) * (800 * (L_p2 + 1) * (R + 1)) := by
    have hLR : 0 ≤ L_p2 * R := Nat.zero_le _
    nlinarith [Nat.zero_le (cap_u * (L_p2 * R)), Nat.zero_le (cap_u * L_p2), Nat.zero_le (cap_u * R)]
  exact h1.trans (Nat.mul_le_mul_right _ (by omega))

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
