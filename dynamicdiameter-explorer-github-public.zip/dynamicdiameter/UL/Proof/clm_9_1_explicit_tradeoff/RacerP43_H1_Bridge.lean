import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Proof.clm_9_1_explicit_tradeoff.H1_Algebra
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H3a3_ExactScan
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
import UL.Proof.clm_9_1_explicit_tradeoff.H3b2_GaussRAM
import UL.Proof.lem_7_2.RacerP33_H1_RAM
import UL.Proof.lem_7_2.RacerP33_H2_LocHPJ
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H1
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a3
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt RandExec RandExecAt)

/-! ### 1. Tradeoff exponent upper bound `Q_c c σ < 1 ≤ 1 + σ` -/

theorem Q_c_lt_one {c σ : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2)
    (_hσ0 : 0 ≤ σ) (hσ_le : σ ≤ rho_c c) :
    Q_c c σ < 1 := by
  have ⟨hg_pos, hg_lt⟩ := g_c_bounds hc_gt hc_lt
  have hgσ : 0 ≤ g_c c * Real.sqrt σ := mul_nonneg hg_pos.le (Real.sqrt_nonneg σ)
  have hsub_nn : 0 ≤ Real.sqrt (1 - g_c c ^ 2) - g_c c * Real.sqrt σ := by
    have hρ_le : Real.sqrt σ ≤ Real.sqrt (rho_c c) := Real.sqrt_le_sqrt hσ_le
    have hmul_le : g_c c * Real.sqrt σ ≤ g_c c * Real.sqrt (rho_c c) :=
      mul_le_mul_of_nonneg_left hρ_le hg_pos.le
    have h_at_ρ : Real.sqrt (1 - g_c c ^ 2) - g_c c * Real.sqrt (rho_c c) = Real.sqrt (rho_c c) := by
      rw [sqrt_one_sub_g_sq hc_gt hc_lt, sqrt_rho_c_eq hc_gt hc_lt]
      unfold g_c
      have hc_pos : 0 < c := by linarith
      field_simp [hc_pos.ne']
      ring
    have : 0 ≤ Real.sqrt (rho_c c) := Real.sqrt_nonneg _
    linarith
  have hsub_le : Real.sqrt (1 - g_c c ^ 2) - g_c c * Real.sqrt σ ≤ Real.sqrt (1 - g_c c ^ 2) := by
    linarith
  have hsq_le : Q_c c σ ≤ 1 - g_c c ^ 2 := by
    unfold Q_c
    calc (Real.sqrt (1 - g_c c ^ 2) - g_c c * Real.sqrt σ) ^ 2
        ≤ (Real.sqrt (1 - g_c c ^ 2)) ^ 2 := pow_le_pow_left₀ hsub_nn hsub_le 2
      _ = 1 - g_c c ^ 2 := Real.sq_sqrt (by nlinarith)
  have hg2_pos : 0 < g_c c ^ 2 := sq_pos_of_pos hg_pos
  linarith

theorem nat_rpow_Q_c_le_one_add_sigma {c σ : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2)
    (hσ0 : 0 ≤ σ) (hσ_le : σ ≤ rho_c c) {n : ℕ} (hn : 1 ≤ n) :
    (n : ℝ) ^ (Q_c c σ) ≤ (n : ℝ) ^ (1 + σ) := by
  have hQ1 : Q_c c σ ≤ 1 + σ := by
    have := Q_c_lt_one hc_gt hc_lt hσ0 hσ_le
    linarith
  exact Real.rpow_le_rpow_of_exponent_le (by exact_mod_cast hn) hQ1

/-! ### 2. Lifting `HeapZeroRandStmt` + `ExecDet` / `ExecScratch` into `DetExec` -/

inductive HeapZeroRandStmt : ArithRAMStmt → Prop
  | skip : HeapZeroRandStmt .skip
  | writeWordHeap (t : ℕ) (idx val : IntExpr) : HeapZeroRandStmt (.writeWordHeap t idx val)
  | writeRealHeap (t : ℕ) (idx : IntExpr) (val : RealExpr) : HeapZeroRandStmt (.writeRealHeap t idx val)
  | seq {s₁ s₂ : ArithRAMStmt} :
      HeapZeroRandStmt s₁ → HeapZeroRandStmt s₂ → HeapZeroRandStmt (.seq s₁ s₂)
  | ite {c : ArithCondExpr} {t f : ArithRAMStmt} :
      HeapZeroRandStmt t → HeapZeroRandStmt f → HeapZeroRandStmt (.ite c t f)
  | repeatN {cnt : IntExpr} {b : ArithRAMStmt} :
      HeapZeroRandStmt b → HeapZeroRandStmt (.repeatN cnt b)

def HeapZeroRandCont : ArithRAMCont → Prop
  | .stmt s => HeapZeroRandStmt s
  | .repeatLoop _ b => HeapZeroRandStmt b
  | .popScope _ => False

private lemma heapZeroRand_fuel_shift {d : ℕ} {inp : ArithRAMInput d} :
    ∀ (f : ℕ) (stk : List ArithRAMCont) (m₀ : ArithRAMMemory) (u₀ sp₀ : ℕ)
      (out : ArithRAMExecOutcome),
      CleanMem m₀ →
      (∀ c ∈ stk, HeapZeroRandCont c) →
      runArithRAMFuel inp f stk
        { mem := m₀, frameDepth := 0, remainingBits := [],
          unitCost := u₀, peakCellSpace := sp₀ } = .halted out →
      u₀ ≤ out.unitCost ∧
      ∀ (bs : List Bool) (rest : List ArithRAMCont) (uA peakA : ℕ),
        ∃ (k uB peakB : ℕ),
          uB = uA + (out.unitCost - u₀) ∧
          ∀ f_rem : ℕ,
            runArithRAMFuel inp (k + f_rem) (stk ++ rest)
              { mem := m₀, frameDepth := 0, remainingBits := bs,
                unitCost := uA, peakCellSpace := peakA } =
            runArithRAMFuel inp f_rem rest
              { mem := out.mem, frameDepth := 0, remainingBits := bs,
                unitCost := uB, peakCellSpace := peakB }
  | 0, [], m₀, u₀, sp₀, out, hcm, _, hrun => by
      simp only [runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, ArithRAMRunStatus.halted.injEq] at hrun
      subst out
      dsimp only
      have hpop : m₀.popDepth 0 = m₀ := hcm
      rw [hpop]
      exact ⟨le_rfl, fun bs rest uA peakA => ⟨0, uA, peakA, by omega, fun f_rem => by simp⟩⟩
  | 0, _ :: _, _, _, _, _, _, _, hrun => by
      simp [runArithRAMFuel] at hrun
  | f + 1, [], m₀, u₀, sp₀, out, hcm, _, hrun => by
      simp only [runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, ArithRAMRunStatus.halted.injEq] at hrun
      subst out
      dsimp only
      have hpop : m₀.popDepth 0 = m₀ := hcm
      rw [hpop]
      exact ⟨le_rfl, fun bs rest uA peakA => ⟨0, uA, peakA, by omega, fun f_rem => by simp⟩⟩
  | f + 1, item :: tl, m₀, u₀, sp₀, out, hcm, hstk, hrun => by
      have hitem := hstk item List.mem_cons_self
      have htl : ∀ c ∈ tl, HeapZeroRandCont c := fun c hc => hstk c (List.mem_cons_of_mem _ hc)
      cases item with
      | popScope _ => cases hitem
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              obtain ⟨hle, hsh⟩ := heapZeroRand_fuel_shift f tl m₀ u₀ sp₀ out hcm htl hrun
              refine ⟨hle, fun bs rest uA peakA => ?_⟩
              obtain ⟨k, uB, peakB, huB, hstep⟩ := hsh bs rest uA peakA
              refine ⟨k + 1, uB, peakB, huB, fun f_rem => ?_⟩
              rw [show k + 1 + f_rem = (k + f_rem) + 1 by omega]
              simpa [runArithRAMFuel] using hstep f_rem
          | succ r =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt body :: .repeatLoop r body :: tl), HeapZeroRandCont c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc'
                · exact hitem
                · rcases List.mem_cons.mp hc' with rfl | hc''
                  · exact hitem
                  · exact htl c hc''
              obtain ⟨hle, hsh⟩ := heapZeroRand_fuel_shift f _ m₀ u₀ sp₀ out hcm hstk' hrun
              refine ⟨hle, fun bs rest uA peakA => ?_⟩
              obtain ⟨k, uB, peakB, huB, hstep⟩ := hsh bs rest uA peakA
              refine ⟨k + 1, uB, peakB, huB, fun f_rem => ?_⟩
              rw [show k + 1 + f_rem = (k + f_rem) + 1 by omega]
              simpa [runArithRAMFuel] using hstep f_rem
      | stmt s =>
          cases hitem with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              obtain ⟨hle, hsh⟩ := heapZeroRand_fuel_shift f tl m₀ (u₀ + 1) sp₀ out hcm htl hrun
              refine ⟨by omega, fun bs rest uA peakA => ?_⟩
              obtain ⟨k, uB, peakB, huB, hstep⟩ := hsh bs rest (uA + 1) peakA
              refine ⟨k + 1, uB, peakB, by omega, fun f_rem => ?_⟩
              rw [show k + 1 + f_rem = (k + f_rem) + 1 by omega]
              simpa [runArithRAMFuel] using hstep f_rem
          | writeWordHeap t idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m₀.words idxE
              let e2 := evalIntExpr inp.toWordView 0 m₀.words valE
              have hcm' : CleanMem (H3a.wWrite m₀ t e1.1 e2.1) := cleanMem_wWrite hcm t e1.1 e2.1
              obtain ⟨hle, hsh⟩ := heapZeroRand_fuel_shift f tl (H3a.wWrite m₀ t e1.1 e2.1)
                (u₀ + e1.2.1 + e2.2.1 + 1) _ out hcm' htl hrun
              refine ⟨by omega, fun bs rest uA peakA => ?_⟩
              obtain ⟨k, uB, peakB, huB, hstep⟩ := hsh bs rest
                (uA + e1.2.1 + e2.2.1 + 1)
                (max peakA (inp.inputCellSpace + (H3a.wWrite m₀ t e1.1 e2.1).cellCount))
              refine ⟨k + 1, uB, peakB, by omega, fun f_rem => ?_⟩
              rw [show k + 1 + f_rem = (k + f_rem) + 1 by omega]
              simpa [runArithRAMFuel, e1, e2, H3a.wWrite] using hstep f_rem
          | writeRealHeap t idxE valE =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m₀.words idxE
              let e2 := evalRealExpr inp 0 m₀ valE
              have hcm' : CleanMem (H3a.rWrite m₀ t e1.1 e2.1) := cleanMem_rWrite hcm t e1.1 e2.1
              obtain ⟨hle, hsh⟩ := heapZeroRand_fuel_shift f tl (H3a.rWrite m₀ t e1.1 e2.1)
                (u₀ + e1.2.1 + e2.2 + 1) _ out hcm' htl hrun
              refine ⟨by omega, fun bs rest uA peakA => ?_⟩
              obtain ⟨k, uB, peakB, huB, hstep⟩ := hsh bs rest
                (uA + e1.2.1 + e2.2 + 1)
                (max peakA (inp.inputCellSpace + (H3a.rWrite m₀ t e1.1 e2.1).cellCount))
              refine ⟨k + 1, uB, peakB, by omega, fun f_rem => ?_⟩
              rw [show k + 1 + f_rem = (k + f_rem) + 1 by omega]
              simpa [runArithRAMFuel, e1, e2, H3a.rWrite] using hstep f_rem
          | @seq s₁ s₂ hs₁ hs₂ =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt s₁ :: .stmt s₂ :: tl), HeapZeroRandCont c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc'
                · exact hs₁
                · rcases List.mem_cons.mp hc' with rfl | hc''
                  · exact hs₂
                  · exact htl c hc''
              obtain ⟨hle, hsh⟩ := heapZeroRand_fuel_shift f _ m₀ u₀ sp₀ out hcm hstk' hrun
              refine ⟨hle, fun bs rest uA peakA => ?_⟩
              obtain ⟨k, uB, peakB, huB, hstep⟩ := hsh bs rest uA peakA
              refine ⟨k + 1, uB, peakB, huB, fun f_rem => ?_⟩
              rw [show k + 1 + f_rem = (k + f_rem) + 1 by omega]
              simpa [runArithRAMFuel] using hstep f_rem
          | @ite c tB fB htB hfB =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalArithCond inp 0 m₀ c
              have hbr : HeapZeroRandCont (.stmt (if ec.1 then tB else fB)) := by
                dsimp [HeapZeroRandCont]; split_ifs <;> assumption
              have hstk' : ∀ x ∈ (.stmt (if ec.1 then tB else fB) :: tl), HeapZeroRandCont x := by
                intro x hx
                rcases List.mem_cons.mp hx with rfl | hx'
                · exact hbr
                · exact htl x hx'
              obtain ⟨hle, hsh⟩ := heapZeroRand_fuel_shift f _ m₀ (u₀ + ec.2) sp₀ out hcm hstk' hrun
              refine ⟨by omega, fun bs rest uA peakA => ?_⟩
              obtain ⟨k, uB, peakB, huB, hstep⟩ := hsh bs rest (uA + ec.2) peakA
              refine ⟨k + 1, uB, peakB, by omega, fun f_rem => ?_⟩
              rw [show k + 1 + f_rem = (k + f_rem) + 1 by omega]
              simpa [runArithRAMFuel, ec] using hstep f_rem
          | @repeatN cntE b hb =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalIntExpr inp.toWordView 0 m₀.words cntE
              let n_it := if 0 ≤ ec.1 then ec.1.toNat else 0
              have hstk' : ∀ x ∈ (.repeatLoop n_it b :: tl), HeapZeroRandCont x := by
                intro x hx
                rcases List.mem_cons.mp hx with rfl | hx'
                · exact hb
                · exact htl x hx'
              obtain ⟨hle, hsh⟩ := heapZeroRand_fuel_shift f _ m₀ (u₀ + ec.2.1) sp₀ out hcm hstk' hrun
              refine ⟨by omega, fun bs rest uA peakA => ?_⟩
              obtain ⟨k, uB, peakB, huB, hstep⟩ := hsh bs rest (uA + ec.2.1) peakA
              refine ⟨k + 1, uB, peakB, by omega, fun f_rem => ?_⟩
              rw [show k + 1 + f_rem = (k + f_rem) + 1 by omega]
              simpa [runArithRAMFuel, ec, n_it] using hstep f_rem

/-- Lift any `ExecDet` on a `HeapZeroRandStmt` into `DetExec`, preserving `InFootprint`. -/
theorem execDet_to_detExec {d TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    {s : ArithRAMStmt} (hzr : HeapZeroRandStmt s)
    {m₀ : ArithRAMMemory} (hfp₀ : InFootprint TW BW TR BR m₀)
    {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hex : ExecDet TW BW TR BR inp s m₀ Post C) :
    ∃ m₁ : ArithRAMMemory,
      Post m₁ ∧
      InFootprint TW BW TR BR m₁ ∧
      DetExec inp s m₀ m₁ C := by
  obtain ⟨m₁, hpost, hfp₁, hcm₁, _, hstep⟩ := hex
  obtain ⟨k, u₁, sp₁, hu₁, _, hf⟩ := hstep [] 0 0
  have hrun0 := hf 0
  simp only [Nat.zero_add, runArithRAMFuel, List.isEmpty_nil, ↓reduceIte] at hrun0
  have hpop₁ : m₁.popDepth 0 = m₁ := hcm₁
  rw [hpop₁] at hrun0
  obtain ⟨_, hsh⟩ := heapZeroRand_fuel_shift k [.stmt s] m₀ 0 0
    { mem := m₁, unitCost := u₁, peakCellSpace := sp₁ } hfp₀.1
    (fun c hc => by simp at hc; subst hc; exact hzr) hrun0
  refine ⟨m₁, hpost, hfp₁, fun bs uA peakA rest => ?_⟩
  obtain ⟨k', uB, peakB, huB, hrem⟩ := hsh bs rest uA peakA
  exact ⟨k', uB, peakB, by dsimp at huB; omega, hrem⟩

theorem execScratch_to_detExec {d TW BW TR BR scrW scrR : ℕ} {inp : ArithRAMInput d}
    {s : ArithRAMStmt} (hzr : HeapZeroRandStmt s)
    {m₀ : ArithRAMMemory} (hfp₀ : InFootprint TW BW TR BR m₀)
    {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hex : ExecScratch TW BW TR BR scrW scrR inp s m₀ Post C) :
    ∃ m₁ : ArithRAMMemory,
      PreservesNonScratch scrW scrR m₀ m₁ ∧
      Post m₁ ∧
      InFootprint TW BW TR BR m₁ ∧
      DetExec inp s m₀ m₁ C := by
  obtain ⟨m₁, ⟨hpr, hp⟩, hfp₁, hdet⟩ := execDet_to_detExec hzr hfp₀ hex
  exact ⟨m₁, hpr, hp, hfp₁, hdet⟩

/-! ### 3. `HeapZeroRandStmt` instances for existing `H3a2`, `H3a3`, and `H3b2` subroutines -/

theorem hzr_forLoopStmt (t : ℕ) (idx : ℤ) (N : ℕ) {b : ArithRAMStmt}
    (hb : HeapZeroRandStmt b) : HeapZeroRandStmt (forLoopStmt t idx N b) :=
  .seq (.writeWordHeap _ _ _) (.repeatN (.seq hb (.writeWordHeap _ _ _)))

theorem hzr_applyHandleUpdateStmt (d : ℕ) : HeapZeroRandStmt (applyHandleUpdateStmt d) := by
  unfold applyHandleUpdateStmt
  refine .ite (.seq (.ite (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
                          (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
                    (.seq (.seq (.writeWordHeap _ _ _)
                                (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
                          (hzr_forLoopStmt _ _ _ (.writeRealHeap _ _ _))))
              (.seq (.writeWordHeap _ _ _)
              (.seq (.writeWordHeap _ _ _)
              (.seq (.writeWordHeap _ _ _)
              (.seq (.writeWordHeap _ _ _)
              (.seq (.writeWordHeap _ _ _)
              (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))))

theorem hzr_exactPairwiseScanStmt
    (arrTbl szTbl : ℕ) (szIdx : ℤ)
    (outWTbl : ℕ) (outHas outH1 outH2 : ℤ)
    (outRTbl : ℕ) (outSq : ℤ)
    (scrWTbl scrRTbl : ℕ) (maxCap d : ℕ) :
    HeapZeroRandStmt (exactPairwiseScanStmt arrTbl szTbl szIdx outWTbl outHas outH1 outH2 outRTbl outSq scrWTbl scrRTbl maxCap d) := by
  unfold exactPairwiseScanStmt forLoopStmt
  repeat' constructor

theorem hzr_decodeBitsStmt (scrW tblCoins : ℕ) (regCtr dstReg : ℤ) (baseOffE : IntExpr) (q : ℕ) :
    HeapZeroRandStmt (decodeBitsStmt scrW tblCoins regCtr dstReg baseOffE q) :=
  .seq (.writeWordHeap _ _ _) (hzr_forLoopStmt _ _ _ (.writeWordHeap _ _ _))

theorem hzr_polyQuantileStmt (scrW scrR : ℕ) (wK wBase rBase rOut : ℤ) (b T p_coord : ℕ) :
    HeapZeroRandStmt (polyQuantileStmt scrW scrR wK wBase rBase rOut b T p_coord) := by
  unfold polyQuantileStmt polyCDFStmt gaussIntPolyStmt
  refine .ite (.writeRealHeap _ _ _)
    (.seq (.writeRealHeap _ _ _)
    (.seq (hzr_forLoopStmt _ _ _ (.writeRealHeap _ _ _))
    (.seq (.writeRealHeap _ _ _)
    (.seq (.writeRealHeap _ _ _)
    (.seq (.writeRealHeap _ _ _)
    (.seq (hzr_forLoopStmt _ _ _
            (.seq (.writeRealHeap _ _ _)
            (.seq (.ite (.seq (.writeRealHeap _ _ _)
                        (.seq (.seq (.writeRealHeap _ _ _)
                              (.seq (.writeRealHeap _ _ _)
                                    (hzr_forLoopStmt _ _ _ (.seq (.writeRealHeap _ _ _) (.writeRealHeap _ _ _)))))
                              (.writeRealHeap _ _ _)))
                        (.seq (.writeRealHeap _ _ _)
                        (.seq (.seq (.writeRealHeap _ _ _)
                              (.seq (.writeRealHeap _ _ _)
                                    (hzr_forLoopStmt _ _ _ (.seq (.writeRealHeap _ _ _) (.writeRealHeap _ _ _)))))
                              (.writeRealHeap _ _ _))))
                  (.ite (.writeRealHeap _ _ _) (.writeRealHeap _ _ _)))))
          (.writeRealHeap _ _ _)))))))

theorem hzr_evalSignedSqCondStmt (scrW scrR : ℕ) (rL rR rN wDst : ℤ) :
    HeapZeroRandStmt (evalSignedSqCondStmt scrW scrR rL rR rN wDst) :=
  .ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)

theorem hzr_signedSqCapTestStmt (scrW scrR tblG tblW : ℕ)
    (wCtr wDst rBase : ℤ) (offGE offWE : IntExpr) (d : ℕ) (A B_signed a₀ : ℚ) :
    HeapZeroRandStmt (signedSqCapTestStmt scrW scrR tblG tblW wCtr wDst rBase offGE offWE d A B_signed a₀) :=
  .seq (.writeRealHeap _ _ _)
  (.seq (.writeRealHeap _ _ _)
  (.seq (hzr_forLoopStmt _ _ _ (.seq (.writeRealHeap _ _ _) (.writeRealHeap _ _ _)))
  (.seq (.writeRealHeap _ _ _)
  (.seq (.writeRealHeap _ _ _) (hzr_evalSignedSqCondStmt _ _ _ _ _ _)))))

theorem hzr_roundQueryLatStmt (scrW scrR tblW : ℕ)
    (wBase rBase offW offOut : ℤ) (d M_lat S_lat : ℕ) :
    HeapZeroRandStmt (roundQueryLatStmt scrW scrR tblW wBase rBase offW offOut d M_lat S_lat) :=
  .seq (.writeRealHeap _ _ _)
  (.seq (hzr_forLoopStmt _ _ _ (.writeRealHeap _ _ _))
        (hzr_forLoopStmt _ _ _
          (.seq (.writeWordHeap _ _ _)
          (.seq (.writeWordHeap _ _ _)
          (.seq (hzr_forLoopStmt _ _ _
                  (.ite .skip
                    (.seq (.writeWordHeap _ _ _)
                    (.seq (.writeRealHeap _ _ _)
                    (.seq (.writeRealHeap _ _ _)
                    (.seq (hzr_evalSignedSqCondStmt _ _ _ _ _ _)
                          (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))))))
                (.writeRealHeap _ _ _))))))

/-! ### 4. `shellBisectStmt` and `corrGtStmt` -/

def shellBisectStmt (scrW scrR : ℕ) (wBase rV rDistSq wOut : ℤ) (m0 K_max S_sh : ℕ) : ArithRAMStmt :=
  let wCtr := wBase
  let wLo := wBase + 1
  let wHi := wBase + 2
  let wMid := wBase + 3
  .seq (.writeWordHeap scrW (.lit wLo) (.lit 0))
  (.seq (.writeWordHeap scrW (.lit wHi) (.lit ((K_max + 1 : ℕ) : ℤ)))
  (.seq (forLoopStmt scrW wCtr S_sh
          (.ite (.intLe (.readHeap scrW (.lit wHi)) (.add (.readHeap scrW (.lit wLo)) (.lit 1)))
            .skip
            (.seq (.writeWordHeap scrW (.lit wMid)
                    (.div (.add (.readHeap scrW (.lit wLo)) (.readHeap scrW (.lit wHi))) (.lit 2)))
              (.ite (.realLe
                      (.mul (.mul (.ofInt (.readHeap scrW (.lit wMid)))
                                  (.ofInt (.readHeap scrW (.lit wMid))))
                            (.readRealHeap scrR (.lit rV)))
                      (.mul (.ofInt (.lit (((m0 : ℕ) ^ 2 : ℕ) : ℤ)))
                            (.readRealHeap scrR (.lit rDistSq))))
                (.writeWordHeap scrW (.lit wLo) (.readHeap scrW (.lit wMid)))
                (.writeWordHeap scrW (.lit wHi) (.readHeap scrW (.lit wMid)))))))
        (.writeWordHeap scrW (.lit wOut) (.readHeap scrW (.lit wLo)))))

theorem hzr_shellBisectStmt (scrW scrR : ℕ) (wBase rV rDistSq wOut : ℤ) (m0 K_max S_sh : ℕ) :
    HeapZeroRandStmt (shellBisectStmt scrW scrR wBase rV rDistSq wOut m0 K_max S_sh) :=
  .seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (hzr_forLoopStmt _ _ _
          (.ite .skip (.seq (.writeWordHeap _ _ _)
                            (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))
        (.writeWordHeap _ _ _)))

theorem exec_shellBisectStmt {d TW BW TR BR scrW scrR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBase rV rDistSq wOut : ℤ) {m0 K_max S_sh : ℕ}
    (hm0 : 1 ≤ m0) {V distSq : ℝ} (hV : 0 < V) (hd0 : 0 ≤ distSq)
    (hd_ub : (m0 : ℝ) ^ 2 * distSq < ((K_max + 1 : ℕ) : ℝ) ^ 2 * V)
    (hS : K_max + 1 ≤ 2 ^ S_sh)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW)
    (hwB : 0 ≤ wBase ∧ wBase + 4 ≤ (BW : ℤ))
    (hwOut : 0 ≤ wOut ∧ wOut < (BW : ℤ))
    (hV_reg : rRead m₀ scrR rV = V)
    (hd_reg : rRead m₀ scrR rDistSq = distSq) :
    ExecScratch TW BW TR BR scrW scrR inp
      (shellBisectStmt scrW scrR wBase rV rDistSq wOut m0 K_max S_sh) m₀
      (fun m₁ => wRead m₁ scrW wOut = (Nat.floor ((m0 : ℝ) * Real.sqrt distSq / Real.sqrt V) : ℤ))
      (50 + 60 * S_sh) := by
  have hmem_w : ∀ m t i, m.words.read (.heap t i) = wRead m t i := fun _ _ _ => rfl
  have hmem_r : ∀ m t i, m.reals.read (.heap t i) = rRead m t i := fun _ _ _ => rfl
  unfold shellBisectStmt
  refine ExecScratch.seq' (40 + 60 * S_sh)
    (ExecScratch.wSetScr inp (.lit (wBase + 1)) (.lit 0) (wBase + 1) 0
      hfp₀ hscrW (by omega) (by omega) rfl rfl (by dsimp [intExprOps]; omega)
      (Post := fun m => wRead m scrW (wBase + 1) = 0 ∧ rRead m scrR rV = V ∧ rRead m scrR rDistSq = distSq)
      ⟨wRead_wWrite_self _ _ _ _, by rw [rRead_wWrite]; exact hV_reg, by rw [rRead_wWrite]; exact hd_reg⟩)
    (by omega) (fun m₁ _ ⟨hlo₁, hV₁, hd₁⟩ hfp₁ => ?_)
  refine ExecScratch.seq' (30 + 60 * S_sh)
    (ExecScratch.wSetScr inp (.lit (wBase + 2)) (.lit ((K_max + 1 : ℕ) : ℤ)) (wBase + 2) ((K_max + 1 : ℕ) : ℤ)
      hfp₁ hscrW (by omega) (by omega) rfl rfl (by dsimp [intExprOps]; omega)
      (Post := fun m => wRead m scrW (wBase + 1) = (((shellBisectStep m0 V distSq)^[0] (0, K_max + 1)).1 : ℤ) ∧
            wRead m scrW (wBase + 2) = (((shellBisectStep m0 V distSq)^[0] (0, K_max + 1)).2 : ℤ) ∧
            rRead m scrR rV = V ∧ rRead m scrR rDistSq = distSq)
      ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; simpa using hlo₁,
       by rw [wRead_wWrite_self]; simp,
       by rw [rRead_wWrite]; exact hV₁,
       by rw [rRead_wWrite]; exact hd₁⟩)
    (by omega) (fun m₂ _ ⟨hlo₂, hhi₂, hV₂, hd₂⟩ hfp₂ => ?_)
  refine ExecScratch.seq' 15
    ((ExecScratch.forLoop wBase S_sh _
      (fun s m =>
        wRead m scrW (wBase + 1) = (((shellBisectStep m0 V distSq)^[s] (0, K_max + 1)).1 : ℤ) ∧
        wRead m scrW (wBase + 2) = (((shellBisectStep m0 V distSq)^[s] (0, K_max + 1)).2 : ℤ) ∧
        rRead m scrR rV = V ∧ rRead m scrR rDistSq = distSq)
      50 hfp₂ hscrW hwB.1 (by omega)
      ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hlo₂,
       by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hhi₂,
       by rw [rRead_wWrite]; exact hV₂,
       by rw [rRead_wWrite]; exact hd₂⟩
      ?_
      (by intro _ m _ ⟨h1, h2, h3, h4⟩
          exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h2,
                 by rw [rRead_wWrite]; exact h3,
                 by rw [rRead_wWrite]; exact h4⟩)).mono (fun _ _ h _ => h) (by omega))
    (by omega) (fun m₃ _ ⟨hlo₃, _, _, _⟩ hfp₃ => ?_)
  · intro s _ m _ ⟨hlom, hhim, hVm, hdm⟩ hctr hfpm
    set lh := (shellBisectStep m0 V distSq)^[s] (0, K_max + 1)
    refine ExecScratch.ite (C_c := 10) (C_b := 40) _ _ _
      (by dsimp [condExprOps, intExprOps]; omega) ?_ ?_
    · intro hle_t
      have h1 : lh.2 ≤ lh.1 + 1 := by
        simp only [evalArithCond, evalIntExpr, hmem_w, hlom, hhim, decide_eq_true_eq] at hle_t
        omega
      have hstep_lh : (shellBisectStep m0 V distSq)^[s + 1] (0, K_max + 1) = lh := by
        rw [Function.iterate_succ_apply']
        change shellBisectStep m0 V distSq lh = lh
        simp [shellBisectStep, h1]
      refine ExecScratch.skip inp hfpm ⟨hctr, ?_⟩ (by omega)
      dsimp only
      rw [hstep_lh]
      exact ⟨hlom, hhim, hVm, hdm⟩
    · intro hle_f
      have h1 : ¬ (lh.2 ≤ lh.1 + 1) := by
        simp only [evalArithCond, evalIntExpr, hmem_w, hlom, hhim, decide_eq_false_iff_not] at hle_f
        omega
      let mid : ℕ := (lh.1 + lh.2) / 2
      refine ExecScratch.seq' 30
        (ExecScratch.wSetScr inp (.lit (wBase + 3)) _ (wBase + 3) (mid : ℤ)
          hfpm hscrW (by omega) (by omega) rfl
          (by simp only [evalIntExpr, hmem_w, hlom, hhim]; omega)
          (by dsimp [intExprOps]; omega)
          (Post := fun mx => wRead mx scrW wBase = (s : ℤ) ∧
                wRead mx scrW (wBase + 1) = (lh.1 : ℤ) ∧
                wRead mx scrW (wBase + 2) = (lh.2 : ℤ) ∧
                wRead mx scrW (wBase + 3) = (mid : ℤ) ∧
                rRead mx scrR rV = V ∧ rRead mx scrR rDistSq = distSq)
          ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctr,
           by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hlom,
           by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hhim,
           wRead_wWrite_self _ _ _ _,
           by rw [rRead_wWrite]; exact hVm,
           by rw [rRead_wWrite]; exact hdm⟩)
        (by omega) (fun mx _ ⟨hctrx, hlox, hhix, hmidx, hVx, hdx⟩ hfpx => ?_)
      classical
      refine ExecScratch.ite (C_c := 20) (C_b := 10) _ _ _
        (by dsimp [condExprOps, realExprOps, intExprOps]; omega) ?_ ?_
      · intro hcmp_t
        have hmid_le : (mid : ℝ) ^ 2 * V ≤ (m0 : ℝ) ^ 2 * distSq := by
          simp only [evalArithCond, evalRealExpr, evalIntExpr, hmem_w, hmem_r,
            hmidx, hVx, hdx, decide_eq_true_eq] at hcmp_t
          push_cast at hcmp_t
          nlinarith
        have hstep_lh : (shellBisectStep m0 V distSq)^[s + 1] (0, K_max + 1) = (mid, lh.2) := by
          rw [Function.iterate_succ_apply']
          change shellBisectStep m0 V distSq lh = (mid, lh.2)
          simp [shellBisectStep, h1, mid, hmid_le]
        refine ExecScratch.wSetScr inp (.lit (wBase + 1)) _ (wBase + 1) (mid : ℤ)
          hfpx hscrW (by omega) (by omega) rfl
          (by simp only [evalIntExpr, hmem_w, hmidx])
          (by dsimp [intExprOps]; omega) ?_
        dsimp only
        rw [hstep_lh]
        exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctrx,
               wRead_wWrite_self _ _ _ _,
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hhix,
               by rw [rRead_wWrite]; exact hVx,
               by rw [rRead_wWrite]; exact hdx⟩
      · intro hcmp_f
        have hmid_gt : ¬ ((mid : ℝ) ^ 2 * V ≤ (m0 : ℝ) ^ 2 * distSq) := by
          simp only [evalArithCond, evalRealExpr, evalIntExpr, hmem_w, hmem_r,
            hmidx, hVx, hdx, decide_eq_false_iff_not] at hcmp_f
          intro hle_m
          apply hcmp_f
          push_cast
          nlinarith
        have hstep_lh : (shellBisectStep m0 V distSq)^[s + 1] (0, K_max + 1) = (lh.1, mid) := by
          rw [Function.iterate_succ_apply']
          change shellBisectStep m0 V distSq lh = (lh.1, mid)
          simp [shellBisectStep, h1, mid, hmid_gt]
        refine ExecScratch.wSetScr inp (.lit (wBase + 2)) _ (wBase + 2) (mid : ℤ)
          hfpx hscrW (by omega) (by omega) rfl
          (by simp only [evalIntExpr, hmem_w, hmidx])
          (by dsimp [intExprOps]; omega) ?_
        dsimp only
        rw [hstep_lh]
        exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctrx,
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hlox,
               wRead_wWrite_self _ _ _ _,
               by rw [rRead_wWrite]; exact hVx,
               by rw [rRead_wWrite]; exact hdx⟩
  · have hfl := shellBisect_eq_floor hm0 hV hd0 hd_ub hS
    refine ExecScratch.wSetScr inp (.lit wOut) (.readHeap scrW (.lit (wBase + 1))) wOut
      (Nat.floor ((m0 : ℝ) * Real.sqrt distSq / Real.sqrt V) : ℤ)
      hfp₃ hscrW hwOut.1 hwOut.2 rfl
      (by simp only [evalIntExpr, hmem_w, hlo₃, hfl])
      (by dsimp [intExprOps]; omega)
      (wRead_wWrite_self _ _ _ _)

/-- Exact `sqrt`-free weak-edge correlation check `b < radialCorrelation o x y` writing `1`/`0` to `(scrW, wDst)`. -/
def corrGtStmt (scrW scrR tblO tblPts : ℕ)
    (wCtr wDst rBase : ℤ) (offOE offXE offYE : IntExpr) (d : ℕ) (b : ℚ) : ArithRAMStmt :=
  let rD := rBase
  let rNx := rBase + 1
  let rNy := rBase + 2
  let eD := RealExpr.readRealHeap scrR (.lit rD)
  let eNx := RealExpr.readRealHeap scrR (.lit rNx)
  let eNy := RealExpr.readRealHeap scrR (.lit rNy)
  let eB := ratExpr b
  let eD2 := RealExpr.mul eD eD
  let eB2N := RealExpr.mul (.mul eB eB) (.mul eNx eNy)
  let cond : ArithCondExpr :=
    .or
      (.and (.realLe (.ofInt (.lit 0)) eB)
            (.and (.realLt (.ofInt (.lit 0)) eD) (.realLt eB2N eD2)))
      (.and (.realLt eB (.ofInt (.lit 0)))
            (.or (.realLe (.ofInt (.lit 0)) eD) (.realLt eD2 eB2N)))
  .seq (.writeRealHeap scrR (.lit rD) (.ofInt (.lit 0)))
  (.seq (.writeRealHeap scrR (.lit rNx) (.ofInt (.lit 0)))
  (.seq (.writeRealHeap scrR (.lit rNy) (.ofInt (.lit 0)))
  (.seq (forLoopStmt scrW wCtr d
          (.seq (.writeRealHeap scrR (.lit rD)
                  (.add (.readRealHeap scrR (.lit rD))
                    (.mul (.sub (.readRealHeap tblO (.add offOE (.readHeap scrW (.lit wCtr))))
                                (.readRealHeap tblPts (.add offXE (.readHeap scrW (.lit wCtr)))))
                          (.sub (.readRealHeap tblPts (.add offYE (.readHeap scrW (.lit wCtr))))
                                (.readRealHeap tblO (.add offOE (.readHeap scrW (.lit wCtr))))))))
          (.seq (.writeRealHeap scrR (.lit rNx)
                  (.add (.readRealHeap scrR (.lit rNx))
                    (.mul (.sub (.readRealHeap tblPts (.add offXE (.readHeap scrW (.lit wCtr))))
                                (.readRealHeap tblO (.add offOE (.readHeap scrW (.lit wCtr)))))
                          (.sub (.readRealHeap tblPts (.add offXE (.readHeap scrW (.lit wCtr))))
                                (.readRealHeap tblO (.add offOE (.readHeap scrW (.lit wCtr))))))))
                (.writeRealHeap scrR (.lit rNy)
                  (.add (.readRealHeap scrR (.lit rNy))
                    (.mul (.sub (.readRealHeap tblPts (.add offYE (.readHeap scrW (.lit wCtr))))
                                (.readRealHeap tblO (.add offOE (.readHeap scrW (.lit wCtr)))))
                          (.sub (.readRealHeap tblPts (.add offYE (.readHeap scrW (.lit wCtr))))
                                (.readRealHeap tblO (.add offOE (.readHeap scrW (.lit wCtr)))))))))))
        (.ite cond
          (.writeWordHeap scrW (.lit wDst) (.lit 1))
          (.writeWordHeap scrW (.lit wDst) (.lit 0))))))

theorem hzr_corrGtStmt (scrW scrR tblO tblPts : ℕ)
    (wCtr wDst rBase : ℤ) (offOE offXE offYE : IntExpr) (d : ℕ) (b : ℚ) :
    HeapZeroRandStmt (corrGtStmt scrW scrR tblO tblPts wCtr wDst rBase offOE offXE offYE d b) :=
  .seq (.writeRealHeap _ _ _)
  (.seq (.writeRealHeap _ _ _)
  (.seq (.writeRealHeap _ _ _)
  (.seq (hzr_forLoopStmt _ _ _
          (.seq (.writeRealHeap _ _ _) (.seq (.writeRealHeap _ _ _) (.writeRealHeap _ _ _))))
        (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))

theorem exec_corrGtStmt {d TW BW TR BR scrW scrR tblO tblPts : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCtr wDst rBase offO offX offY : ℤ) (b : ℚ)
    (o x y : EuclideanSpace ℝ (Fin d)) (hx : x ≠ o) (hy : y ≠ o)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (hwDst : 0 ≤ wDst ∧ wDst < (BW : ℤ))
    (hrB : 0 ≤ rBase ∧ rBase + 3 ≤ (BR : ℤ))
    (hneO : tblO ≠ scrR) (hnePts : tblPts ≠ scrR)
    (ho : ∀ c : Fin d, rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hx_r : ∀ c : Fin d, rRead m₀ tblPts (offX + (c.val : ℤ)) = euclideanCoord x c)
    (hy_r : ∀ c : Fin d, rRead m₀ tblPts (offY + (c.val : ℤ)) = euclideanCoord y c) :
    ExecScratch TW BW TR BR scrW scrR inp
      (corrGtStmt scrW scrR tblO tblPts wCtr wDst rBase (.lit offO) (.lit offX) (.lit offY) d b) m₀
      (fun m₁ => open Classical in
        wRead m₁ scrW wDst = if (b : ℝ) < radialCorrelation o x y then 1 else 0)
      (200 + 110 * d) := by
  have hmem_w : ∀ m t i, m.words.read (.heap t i) = wRead m t i := fun _ _ _ => rfl
  have hmem_r : ∀ m t i, m.reals.read (.heap t i) = rRead m t i := fun _ _ _ => rfl
  let pD : ℕ → ℝ := fun k =>
    ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k),
      (euclideanCoord o c - euclideanCoord x c) * (euclideanCoord y c - euclideanCoord o c)
  let pNx : ℕ → ℝ := fun k =>
    ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k),
      (euclideanCoord x c - euclideanCoord o c) ^ 2
  let pNy : ℕ → ℝ := fun k =>
    ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k),
      (euclideanCoord y c - euclideanCoord o c) ^ 2
  unfold corrGtStmt
  refine ExecScratch.seq' (190 + 110 * d)
    (ExecScratch.rSetScr inp (.lit rBase) (.ofInt (.lit 0)) rBase 0
      hfp₀ hscrR hrB.1 (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
      (by dsimp [intExprOps, realExprOps]; omega)
      (Post := fun m => rRead m scrR rBase = 0)
      (rRead_rWrite_self _ _ _ _))
    (by omega) (fun m₁ hpr₁ hd₁ hfp₁ => ?_)
  refine ExecScratch.seq' (180 + 110 * d)
    (ExecScratch.rSetScr inp (.lit (rBase + 1)) (.ofInt (.lit 0)) (rBase + 1) 0
      hfp₁ hscrR (by omega) (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
      (by dsimp [intExprOps, realExprOps]; omega)
      (Post := fun m => rRead m scrR rBase = 0 ∧ rRead m scrR (rBase + 1) = 0)
      ⟨by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hd₁, rRead_rWrite_self _ _ _ _⟩)
    (by omega) (fun m₂ hpr₂ ⟨hd₂, hnx₂⟩ hfp₂ => ?_)
  refine ExecScratch.seq' (170 + 110 * d)
    (ExecScratch.rSetScr inp (.lit (rBase + 2)) (.ofInt (.lit 0)) (rBase + 2) 0
      hfp₂ hscrR (by omega) (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
      (by dsimp [intExprOps, realExprOps]; omega)
      (Post := fun m => rRead m scrR rBase = pD 0 ∧ rRead m scrR (rBase + 1) = pNx 0 ∧
            rRead m scrR (rBase + 2) = pNy 0)
      ⟨by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega)), hd₂]; simp [pD],
       by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega)), hnx₂]; simp [pNx],
       by rw [rRead_rWrite_self]; simp [pNy]⟩)
    (by omega) (fun m₃ hpr₃ ⟨hd₃, hnx₃, hny₃⟩ hfp₃ => ?_)
  have hpr₀₃ := (hpr₁.trans hpr₂).trans hpr₃
  refine ExecScratch.seq' 150
    ((ExecScratch.forLoop wCtr d _
      (fun k m => rRead m scrR rBase = pD k ∧ rRead m scrR (rBase + 1) = pNx k ∧
        rRead m scrR (rBase + 2) = pNy k)
      102 hfp₃ hscrW hwCtr.1 hwCtr.2
      (by simp only [rRead_wWrite]; exact ⟨hd₃, hnx₃, hny₃⟩)
      ?_
      (by intro _ m _ h; simp only [rRead_wWrite]; exact h)).mono (fun _ _ h _ => h) (by omega))
    (by omega) (fun m₄ _ ⟨hd₄, hnx₄, hny₄⟩ hfp₄ => ?_)
  · intro k hk m hprm ⟨hdm, hnxm, hnym⟩ hctr hfpm
    have hpr_all := hpr₀₃.trans hprm
    let ck : Fin d := ⟨k, hk⟩
    have ho_k : rRead m tblO (offO + (k : ℤ)) = euclideanCoord o ck := by
      rw [hpr_all.2 tblO hneO]; exact ho ck
    have hx_k : rRead m tblPts (offX + (k : ℤ)) = euclideanCoord x ck := by
      rw [hpr_all.2 tblPts hnePts]; exact hx_r ck
    have hy_k : rRead m tblPts (offY + (k : ℤ)) = euclideanCoord y ck := by
      rw [hpr_all.2 tblPts hnePts]; exact hy_r ck
    have hsplit : ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k + 1)) =
        insert ck ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by
      ext c; simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, Fin.ext_iff, ck]; omega
    have hnot : ck ∉ ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by simp [ck]
    have hD_s : pD (k + 1) = pD k + (euclideanCoord o ck - euclideanCoord x ck) * (euclideanCoord y ck - euclideanCoord o ck) := by
      dsimp [pD]; rw [hsplit, Finset.sum_insert hnot, add_comm]
    have hNx_s : pNx (k + 1) = pNx k + (euclideanCoord x ck - euclideanCoord o ck) ^ 2 := by
      dsimp [pNx]; rw [hsplit, Finset.sum_insert hnot, add_comm]
    have hNy_s : pNy (k + 1) = pNy k + (euclideanCoord y ck - euclideanCoord o ck) ^ 2 := by
      dsimp [pNy]; rw [hsplit, Finset.sum_insert hnot, add_comm]
    refine ExecScratch.seq' 68
      (ExecScratch.rSetScr inp (.lit rBase) _ rBase (pD (k + 1))
        hfpm hscrR hrB.1 (by omega) rfl
        (by simp only [evalRealExpr, evalIntExpr, hmem_w, hmem_r, hctr, hdm, ho_k, hx_k, hy_k, hD_s])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun mx => wRead mx scrW wCtr = (k : ℤ) ∧ rRead mx scrR rBase = pD (k + 1) ∧
              rRead mx scrR (rBase + 1) = pNx k ∧ rRead mx scrR (rBase + 2) = pNy k)
        ⟨by rw [wRead_rWrite]; exact hctr, rRead_rWrite_self _ _ _ _,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hnxm,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hnym⟩)
      (by omega) (fun mx₁ hprx₁ ⟨hctrx₁, hdx₁, hnxx₁, hnyx₁⟩ hfpx₁ => ?_)
    have hpr_all₁ := hpr_all.trans hprx₁
    have ho_k₁ : rRead mx₁ tblO (offO + (k : ℤ)) = euclideanCoord o ck := by
      rw [hpr_all₁.2 tblO hneO]; exact ho ck
    have hx_k₁ : rRead mx₁ tblPts (offX + (k : ℤ)) = euclideanCoord x ck := by
      rw [hpr_all₁.2 tblPts hnePts]; exact hx_r ck
    refine ExecScratch.seq' 34
      (ExecScratch.rSetScr inp (.lit (rBase + 1)) _ (rBase + 1) (pNx (k + 1))
        hfpx₁ hscrR (by omega) (by omega) rfl
        (by simp only [evalRealExpr, evalIntExpr, hmem_w, hmem_r, hctrx₁, hnxx₁, ho_k₁, hx_k₁, hNx_s, sq])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun mx => wRead mx scrW wCtr = (k : ℤ) ∧ rRead mx scrR rBase = pD (k + 1) ∧
              rRead mx scrR (rBase + 1) = pNx (k + 1) ∧ rRead mx scrR (rBase + 2) = pNy k)
        ⟨by rw [wRead_rWrite]; exact hctrx₁,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hdx₁,
         rRead_rWrite_self _ _ _ _,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hnyx₁⟩)
      (by omega) (fun mx₂ hprx₂ ⟨hctrx₂, hdx₂, hnxx₂, hnyx₂⟩ hfpx₂ => ?_)
    have hpr_all₂ := hpr_all₁.trans hprx₂
    have ho_k₂ : rRead mx₂ tblO (offO + (k : ℤ)) = euclideanCoord o ck := by
      rw [hpr_all₂.2 tblO hneO]; exact ho ck
    have hy_k₂ : rRead mx₂ tblPts (offY + (k : ℤ)) = euclideanCoord y ck := by
      rw [hpr_all₂.2 tblPts hnePts]; exact hy_r ck
    exact ExecScratch.rSetScr inp (.lit (rBase + 2)) _ (rBase + 2) (pNy (k + 1))
      hfpx₂ hscrR (by omega) (by omega) rfl
      (by simp only [evalRealExpr, evalIntExpr, hmem_w, hmem_r, hctrx₂, hnyx₂, ho_k₂, hy_k₂, hNy_s, sq])
      (by dsimp [intExprOps, realExprOps]; omega)
      ⟨by rw [wRead_rWrite]; exact hctrx₂,
       by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hdx₂,
       by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hnxx₂,
       rRead_rWrite_self _ _ _ _⟩
  · classical
    let D_xy := ∑ c : Fin d, (euclideanCoord o c - euclideanCoord x c) * (euclideanCoord y c - euclideanCoord o c)
    let Nx := ∑ c : Fin d, (euclideanCoord x c - euclideanCoord o c) ^ 2
    let Ny := ∑ c : Fin d, (euclideanCoord y c - euclideanCoord o c) ^ 2
    have hd_eq : rRead m₄ scrR rBase = D_xy := by
      rw [hd₄]; dsimp [pD, D_xy]; congr 1; ext c; simp
    have hnx_eq : rRead m₄ scrR (rBase + 1) = Nx := by
      rw [hnx₄]; dsimp [pNx, Nx]; congr 1; ext c; simp
    have hny_eq : rRead m₄ scrR (rBase + 2) = Ny := by
      rw [hny₄]; dsimp [pNy, Ny]; congr 1; ext c; simp
    have hiff := radialCorrelation_gt_iff o x y hx hy (b : ℝ)
    refine (ExecScratch.ite (C_c := 130) (C_b := 10) _ _ _
      ?_ ?_ ?_).mono (fun _ _ h _ => h) (by omega)
    · dsimp [condExprOps, realExprOps, realExprOps_ratExpr, intExprOps]; omega
    · intro hc_t
      have hgt : (b : ℝ) < radialCorrelation o x y := by
        simp only [evalArithCond, evalRealExpr, evalRealExpr_ratExpr, evalIntExpr,
          hmem_r, hd_eq, hnx_eq, hny_eq, Int.cast_zero, ← sq,
          Bool.or_eq_true, Bool.and_eq_true, decide_eq_true_eq] at hc_t
        exact hiff.mpr hc_t
      refine ExecScratch.wSetScr inp (.lit wDst) (.lit 1) wDst 1
        hfp₄ hscrW hwDst.1 hwDst.2 rfl rfl (by dsimp [intExprOps]; omega) ?_
      rw [wRead_wWrite_self, if_pos hgt]
    · intro hc_f
      have hngt : ¬ ((b : ℝ) < radialCorrelation o x y) := by
        simp only [evalArithCond, evalRealExpr, evalRealExpr_ratExpr, evalIntExpr,
          hmem_r, hd_eq, hnx_eq, hny_eq, Int.cast_zero, ← sq,
          Bool.or_eq_false_iff, Bool.and_eq_false_iff, decide_eq_false_iff_not] at hc_f
        intro hgt
        rcases hiff.mp hgt with ⟨h1, h2, h3⟩ | ⟨h1, h2 | h3⟩
        · rcases hc_f.1 with n1 | n2 | n3
          · exact n1 h1
          · exact n2 h2
          · exact n3 h3
        · rcases hc_f.2 with n1 | ⟨n2, _⟩
          · exact n1 h1
          · exact n2 h2
        · rcases hc_f.2 with n1 | ⟨_, n3⟩
          · exact n1 h1
          · exact n3 h3
      refine ExecScratch.wSetScr inp (.lit wDst) (.lit 0) wDst 0
        hfp₄ hscrW hwDst.1 hwDst.2 rfl rfl (by dsimp [intExprOps]; omega) ?_
      rw [wRead_wWrite_self, if_neg hngt]

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
