import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInstA1d
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_CoinHPJ
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Stage4PrimC

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG14
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG20

/-! ### 6. Full `CG19.NodeAndHPJRAMOps` + `CG20.MaxRadRAMOp` Packaging & Polynomial Bounds -/

section Assemble

variable {d : ℕ} {params : LocalScaleParams} {h : ℝ}

/-- Transparent assembly of `CG19.NodeAndHPJRAMOps cp` from any `NodeSlotLayout cp` whose
`BW` accommodates `CG14.hpjWordCap cp`. -/
noncomputable def NodeSlotLayout.toNodeAndHPJRAMOps
    {cp : ChainParams d params h} (L : NodeSlotLayout cp)
    (hBW_hpj : hpjWordCap cp ≤ L.BW) :
    NodeAndHPJRAMOps cp where
  TW := L.TW
  hTW := L.hTW
  nodeWStride := L.nodeWStride
  BW := L.BW
  TR := L.TR
  hTR := L.hTR
  nodeRStride := L.nodeRStride
  BR := L.BR
  hBW_coins := by unfold NodeSlotLayout.BW; omega
  hBW_meta := by unfold NodeSlotLayout.BW; omega
  hBW_arr := by unfold NodeSlotLayout.BW; omega
  hBW_scr := by unfold NodeSlotLayout.BW; omega
  hBW_node := by unfold NodeSlotLayout.BW; omega
  hBR_pts := by unfold NodeSlotLayout.BR; omega
  hBR_eng := by unfold NodeSlotLayout.BR; omega
  hBR_node := by unfold NodeSlotLayout.BR; omega
  C_open := L.slotOpenEmptyCost
  C_ins := L.slotInsertMatCost
  C_del := L.slotDeleteMatCost
  C_bump := 50
  C_ball := L.slotInCoreBallCost
  C_hpj := evalHPJCenterCost cp
  C_read := L.slotReadCost
  SlotsReady := L.SlotsReady
  slotsReady_empty := L.slotsReady_empty
  slotsReady_ext := L.slotsReady_ext
  EncNode := L.EncNode
  encNode_ext := L.encNode_ext
  openEmptyStmt := L.slotOpenEmptyStmt
  insertMatStmt := L.slotInsertMatStmt
  deleteMatStmt := L.slotDeleteMatStmt
  bumpAgeStmt := L.slotBumpAgeStmt
  inCoreBallStmt := L.slotInCoreBallStmt
  evalHPJCenterStmt := evalHPJCenterStmt L.TW cp
  readNodeScalarStmt := L.slotReadNodeScalarStmt
  readNodeArrElemStmt := L.slotReadNodeArrElemStmt
  containsNodeArrStmt := L.slotContainsNodeArrStmt
  readCenterCoordStmt := L.slotReadCenterCoordStmt
  readCfgStoredEdgeStmt := L.slotReadCfgStoredEdgeStmt
  zeroRand_openEmpty := L.zeroRand_slotOpenEmptyStmt
  zeroRand_insertMat := L.zeroRand_slotInsertMatStmt
  zeroRand_deleteMat := L.zeroRand_slotDeleteMatStmt
  zeroRand_bumpAge := L.zeroRand_slotBumpAgeStmt
  zeroRand_inCoreBall := L.zeroRand_slotInCoreBallStmt
  zeroRand_evalHPJCenter := zeroRand_evalHPJCenter L.TW cp
  zeroRand_readNodeScalar := L.zeroRand_slotReadNodeScalarStmt
  zeroRand_readNodeArrElem := L.zeroRand_slotReadNodeArrElemStmt
  zeroRand_containsNodeArr := L.zeroRand_slotContainsNodeArrStmt
  zeroRand_readCenterCoord := L.zeroRand_slotReadCenterCoordStmt
  zeroRand_readCfgStoredEdge := L.zeroRand_slotReadCfgStoredEdgeStmt
  openEmpty_spec := L.exec_slotOpenEmptyStmt
  insertMat_spec := L.exec_slotInsertMatStmt
  deleteMat_spec := L.exec_slotDeleteMatStmt
  bumpAge_spec := L.exec_slotBumpAgeStmt
  inCoreBall_spec := L.exec_slotInCoreBallStmt
  evalHPJCenter_spec :=
    CG14.evalHPJCenter_spec cp L.hTW L.hTR
      (by unfold NodeSlotLayout.BR; omega) hBW_hpj L.slotsReady_ext L.encNode_ext
  readNodeScalar_spec := L.exec_slotReadNodeScalarStmt
  readNodeArrElem_spec := L.exec_slotReadNodeArrElemStmt
  containsNodeArr_spec := L.exec_slotContainsNodeArrStmt
  readCenterCoord_spec := L.exec_slotReadCenterCoordStmt
  readCfgStoredEdge_spec := L.exec_slotReadCfgStoredEdgeStmt

/-- Companion `O(1)` `CG20.MaxRadRAMOp` (`C_maxRad = 200`) for Stage 4 (`evalBaselinePair`). -/
def NodeSlotLayout.toMaxRadRAMOp
    {cp : ChainParams d params h} (L : NodeSlotLayout cp)
    (hBW_hpj : hpjWordCap cp ≤ L.BW) :
    MaxRadRAMOp (L.toNodeAndHPJRAMOps hBW_hpj) where
  C_maxRad := 200
  readMaxRadiusStmt := L.slotReadMaxRadiusStmt
  zeroRand_readMaxRadius := L.zeroRand_slotReadMaxRadiusStmt
  readMaxRadius_spec := by
    intro inp m₀ pts mn slot sR hR yR hslot _ _
      hsR0 hsR40 hhR0 hhR40 hyR0 hyR40 _ _ hne_hy
      hfp₀ hsr₀ henc₀ hpts hsR_v
    refine (L.exec_slotReadMaxRadiusStmt inp m₀ pts mn slot sR hR yR
      hslot hsR0 (by omega) hhR0 (by omega) hyR0 (by omega) hne_hy
      hfp₀ hsr₀ henc₀ hsR_v hpts).mono ?_ le_rfl
    intro m₁ ⟨hsr₁, hmrad, henc₁, hw9, hwScr, hr3⟩ _
    refine ⟨⟨hsr₁, henc₁, hw9, fun t ht2 i => hr3 t (by omega) i⟩,
      ?_,
      fun i _ hih hiy => hwScr i hih hiy,
      fun ri _ => hr3 engRealTbl (by unfold engRealTbl; omega) ri⟩
    dsimp [EncOptSingle]
    cases hm : maxRadiusHandle cp.T_pow pts mn.nd.o mn.nd.denseArr.toFinset with
    | none =>
        rw [hm] at hmrad
        exact hmrad.1
    | some y =>
        rw [hm] at hmrad
        exact hmrad

/-- Canonical 11-word-table / 5-real-table layout (`nodeWTbl = 9`, `nodeScrWTbl = 10 = TW - 1`,
`nodeRTbl = 3`, `nodeScrRTbl = 4`). -/
noncomputable def mkSlotLayout (cp : ChainParams d params h)
    (cmOps : ConfigMatchRAMOps d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b cp.T_cdf cp.p_coord
      (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
      10 4 9 3 coinTbl)
    (cmHzr : ConfigMatchHeapZeroRand cmOps) : NodeSlotLayout cp where
  TW := 11
  TR := 5
  nodeWTbl := 9
  nodeScrWTbl := 10
  nodeRTbl := 3
  nodeScrRTbl := 4
  hNodeWTbl_lo := by decide
  hNodeWTbl_hi := by decide
  hNodeScrW_lo := by decide
  hNodeScrW_hi := by decide
  hne_nodeW := by decide
  hNodeRTbl_lo := by decide
  hNodeRTbl_hi := by decide
  hNodeScrR_lo := by decide
  hNodeScrR_hi := by decide
  hne_nodeR := by decide
  BW_extra := hpjWordCap cp
  BR_extra := 0
  cmOps := cmOps
  cmHzr := cmHzr

/-- Transparent `CG19.NodeAndHPJRAMOps cp` built from `(cmOps, cmHzr)` + `CG14_CoinHPJ`. -/
noncomputable def mkNodeAndHPJRAMOps (cp : ChainParams d params h)
    (cmOps : ConfigMatchRAMOps d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b cp.T_cdf cp.p_coord
      (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
      10 4 9 3 coinTbl)
    (cmHzr : ConfigMatchHeapZeroRand cmOps) : NodeAndHPJRAMOps cp :=
  (mkSlotLayout cp cmOps cmHzr).toNodeAndHPJRAMOps (by
    unfold mkSlotLayout NodeSlotLayout.BW; dsimp only; omega)

/-- Companion `O(1)` `CG20.MaxRadRAMOp` (`C_maxRad = 200`) on `mkNodeAndHPJRAMOps`. -/
noncomputable def mkMaxRadRAMOp (cp : ChainParams d params h)
    (cmOps : ConfigMatchRAMOps d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b cp.T_cdf cp.p_coord
      (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
      10 4 9 3 coinTbl)
    (cmHzr : ConfigMatchHeapZeroRand cmOps) :
    MaxRadRAMOp (mkNodeAndHPJRAMOps cp cmOps cmHzr) :=
  (mkSlotLayout cp cmOps cmHzr).toMaxRadRAMOp (by
    unfold mkSlotLayout NodeSlotLayout.BW; dsimp only; omega)

/-! ### 7. Explicit Polynomial Stride, Table-Dimension & Operation-Cost Bounds -/

theorem mkNodeAndHPJRAMOps_strides_and_dims (cp : ChainParams d params h)
    (cmOps : ConfigMatchRAMOps d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b cp.T_cdf cp.p_coord
      (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
      10 4 9 3 coinTbl)
    (cmHzr : ConfigMatchHeapZeroRand cmOps) :
    let ops := mkNodeAndHPJRAMOps cp cmOps cmHzr
    ops.TW = 11 ∧
    ops.TR = 5 ∧
    ops.nodeWStride = 25 + 10 * cp.n + 6 * 2 ^ cp.L_p2 + cp.N_cfg * cmOps.cfgWStride.toNat ∧
    ops.nodeRStride = d + 2 + 2 * 2 ^ cp.L_p2 + cp.N_cfg * cmOps.cfgRStride.toNat ∧
    ops.BW =
      (cp.B_STEP + 16) +
      (16 + 9 * cp.D_max + cp.D_max * cp.D_max + 16) +
      ((2 + 4 * cp.D_max) * S_stride cp + 16) +
      (M_slots cp + 128) +
      M_slots cp * ops.nodeWStride +
      (64 + cmOps.opWScrStride.toNat) +
      hpjWordCap cp ∧
    ops.BR =
      (cp.n * d + 8) +
      (d + 32) +
      M_slots cp * ops.nodeRStride +
      (d + 16 + cmOps.opRScrStride.toNat) := by
  intro ops
  let cw : ℕ := cmOps.cfgWStride.toNat
  let cr : ℕ := cmOps.cfgRStride.toNat
  have hcfgW : cmOps.cfgWStride = (cw : ℤ) :=
    (Int.toNat_of_nonneg cmOps.hcfgW_nonneg).symm
  have hcfgR : cmOps.cfgRStride = (cr : ℤ) :=
    (Int.toNat_of_nonneg cmOps.hcfgR_nonneg).symm
  have hnW : ops.nodeWStride =
      25 + 10 * cp.n + 6 * 2 ^ cp.L_p2 + cp.N_cfg * cw := by
    change (managedNodeWStride cp.n (4 * cp.n + 4) cp.L_p2 cp.N_cfg cmOps.cfgWStride).toNat = _
    have hz : managedNodeWStride cp.n (4 * cp.n + 4) cp.L_p2 cp.N_cfg cmOps.cfgWStride =
        ((25 + 10 * cp.n + 6 * 2 ^ cp.L_p2 + cp.N_cfg * cw : ℕ) : ℤ) := by
      unfold managedNodeWStride swapPoolStride radTreeWStride
      rw [hcfgW]; push_cast; ring
    rw [hz, Int.toNat_natCast]
  have hnR : ops.nodeRStride =
      d + 2 + 2 * 2 ^ cp.L_p2 + cp.N_cfg * cr := by
    change (managedNodeRStride d cp.L_p2 cp.N_cfg cmOps.cfgRStride).toNat = _
    have hz : managedNodeRStride d cp.L_p2 cp.N_cfg cmOps.cfgRStride =
        ((d + 2 + 2 * 2 ^ cp.L_p2 + cp.N_cfg * cr : ℕ) : ℤ) := by
      unfold managedNodeRStride radTreeRStride
      rw [hcfgR]; push_cast; ring
    rw [hz, Int.toNat_natCast]
  refine ⟨rfl, rfl, hnW, hnR, rfl, ?_⟩
  exact Nat.add_zero _

theorem mkNodeAndHPJRAMOps_costs (cp : ChainParams d params h)
    (cmOps : ConfigMatchRAMOps d cp.n cp.L_p2 cp.R cp.ℓ cp.M₀ cp.b cp.T_cdf cp.p_coord
      (M_lat_of d params.e) params h cp.τ_d cp.τ_q cp.cap_u cp.cap_q
      10 4 9 3 coinTbl)
    (cmHzr : ConfigMatchHeapZeroRand cmOps) :
    let ops := mkNodeAndHPJRAMOps cp cmOps cmHzr
    ops.C_open = 500 + 95 * d + cp.N_cfg * (cmOps.clearCost + 40) ∧
    ops.C_ins = 1100 + 110 * d + 380 * cp.L_p2 + cp.N_cfg * (cmOps.insertCost + 60) ∧
    ops.C_del = 1110 + 110 * d + 380 * cp.L_p2 + cp.N_cfg * (cmOps.deleteCost + 60) ∧
    ops.C_bump = 50 ∧
    ops.C_ball = 200 + 60 * d ∧
    ops.C_hpj = evalHPJCenterCost cp ∧
    ops.C_read = cmOps.readEdgeCost + 250 ∧
    (mkMaxRadRAMOp cp cmOps cmHzr).C_maxRad = 200 := by
  intro ops
  refine ⟨rfl, ?_, ?_, rfl, rfl, rfl, rfl, rfl⟩
  · change 50 + managedNodeInsertMatCost cmOps cp.L_p2 cp.N_cfg = _
    unfold managedNodeInsertMatCost; omega
  · change 50 + managedNodeDeleteMatCost cmOps cp.L_p2 cp.N_cfg = _
    unfold managedNodeDeleteMatCost; omega

end Assemble

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
