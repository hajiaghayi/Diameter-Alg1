import UL.Proof.clm_9_1_explicit_tradeoff.CG02_SideQueryA

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot optNatToInt
  copyVecToHeapStmt exec_copyVecToHeapStmt
  liveSlotQueryCost liveSlotQueryCopyCost liveSlotQueryStepCost evalCopyTuplesCost)

/-! ### 3. Full `dyadicSideQueryStmt` & `exec_h4_dyadicSideQueryStmt` -/

def dyadicSideQueryStmt (scrW scrR tblW tblR tblO tblPv : ℕ)
    (wSideBaseW wSideBaseR wOffO wOffPv wAnsOut wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let bR := IntExpr.readHeap scrW (.lit wSideBaseR)
  let wEp := wScr
  let wT := wScr + 1
  let wEntryPtBase := wScr + 2
  let wS := wScr + 3
  let wH := wScr + 4
  let wCopyCtr := wScr + 12
  .seq (copyVecToHeapStmt scrW tblPv tblR wCopyCtr wOffPv wSideBaseR d)
  (.seq (.writeWordHeap scrW (.lit wAnsOut) (.lit (-1)))
  (.seq (.writeWordHeap scrW (.lit wEp) (.readHeap tblW bW))
  (.seq (.writeWordHeap scrW (.lit wT) (.readHeap tblW (.add bW (.lit 1))))
  (.seq (.writeWordHeap scrW (.lit wEntryPtBase) (.add bR (.lit (d : ℤ))))
  (.seq (dyadicSideTailCheckStmt scrW scrR tblW tblO tblR
          wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr L_p2 d 1 b_rat)
  (.seq (dyadicSideTailCheckStmt scrW scrR tblW tblO tblR
          wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr L_p2 d 2 b_rat)
  (.seq (.writeWordHeap scrW (.lit wS) (.lit 0))
  (.seq (.writeWordHeap scrW (.lit wH) (.lit 1))
        (.repeatN (.lit (L_p2 : ℤ))
          (.seq (dyadicSideScaleQueryStepStmt scrW scrR tblW tblR tblO
                  wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr
                  n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q A B_rat τ_q b_rat)
          (.seq (.writeWordHeap scrW (.lit wS)
                  (.add (.readHeap scrW (.lit wS)) (.lit 1)))
                (.writeWordHeap scrW (.lit wH)
                  (.mul (.lit 2) (.readHeap scrW (.lit wH)))))))))))))))

def dyadicSideQueryCost (L_p2 R ℓ M₀ d S_lat cap_q : ℕ) : ℕ :=
  200 + 35 * d + 2 * dyadicSideTailCheckCost d +
    L_p2 * (dyadicSideScaleQueryStepCost R ℓ M₀ d S_lat cap_q + 50)

theorem zeroRand_dyadicSideQueryStmt (scrW scrR tblW tblR tblO tblPv : ℕ)
    (wSideBaseW wSideBaseR wOffO wOffPv wAnsOut wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) :
    H3a.ZeroRandStmt (dyadicSideQueryStmt scrW scrR tblW tblR tblO tblPv
      wSideBaseW wSideBaseR wOffO wOffPv wAnsOut wScr rScr
      n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q A B_rat τ_q b_rat) :=
  of_isZeroRandB rfl

theorem exec_h4_dyadicSideQueryStmt {d TW BW TR BR scrW scrR tblW tblR tblO tblPv : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wOffO wOffPv wAnsOut wScr rScr
      sideBaseW sideBaseR offO offPv : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q : ℕ}
    (hM₀ : 1 ≤ M₀) (hS_lat : 2 * M_lat + 1 ≤ 2 ^ S_lat)
    {A B_rat τ_d : ℚ} (τ_q b_rat : ℚ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {o p_v : EuclideanSpace ℝ (Fin d)} (hpv_ne : p_v ≠ o)
    {U : Finset ℕ} {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b}
    (hwf : H4b.DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneO : tblO ≠ scrR)
    (hbaseR_d : 0 ≤ sideBaseR ∧ sideBaseR + (d : ℤ) ≤ (BR : ℤ))
    (hdisjO_pv : tblO ≠ tblR ∨ offO + (d : ℤ) ≤ sideBaseR ∨ sideBaseR + (d : ℤ) ≤ offO)
    (hdisjPv : tblPv ≠ tblR ∨ offPv + (d : ℤ) ≤ sideBaseR ∨ sideBaseR + (d : ℤ) ≤ offPv)
    (hwAns : 0 ≤ wAnsOut ∧ wAnsOut < (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + dyadicSideQueryRStride d ≤ (BR : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wSideBaseW)
    (hdisjBR : wSideBaseR < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wSideBaseR)
    (hdisjO : wOffO < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wOffO)
    (hdisjOffPv : wOffPv < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wOffPv)
    (hdisjAns : wAnsOut < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ wAnsOut)
    (hneAnsInputs : wAnsOut ≠ wSideBaseW ∧ wAnsOut ≠ wSideBaseR ∧ wAnsOut ≠ wOffO)
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hbR : wRead m₀ scrW wSideBaseR = sideBaseR)
    (hoffO : wRead m₀ scrW wOffO = offO)
    (hoffPv : wRead m₀ scrW wOffPv = offPv)
    (ho : ∀ c : Fin d, rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpv : ∀ c : Fin d, rRead m₀ tblPv (offPv + (c.val : ℤ)) = euclideanCoord p_v c)
    (henc₀ : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀) :
    let pureAns := idx.query hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q o p_v
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (dyadicSideQueryStmt scrW scrR tblW tblR tblO tblPv
          wSideBaseW wSideBaseR wOffO wOffPv wAnsOut wScr rScr
          n L_p2 R ℓ M₀ d M_lat S_lat cap_u cap_q A B_rat τ_q b_rat)
        m₀ m₁ (dyadicSideQueryCost L_p2 R ℓ M₀ d S_lat cap_q) ∧
      InFootprint TW BW TR BR m₁ ∧
      wRead m₁ scrW wAnsOut = optNatToInt pureAns ∧
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₁ ∧
      (∀ w, w ≠ wAnsOut →
        (w < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR (d : ℤ) m₀ m₁ := by
  classical
  intro pureAns
  have hge44 := dyadicSideQueryWStride_ge_44 ℓ M₀ cap_q
  obtain ⟨m_st, hd_cp, hfp_st, hcop_st, hkW_st, _, hfr_st⟩ :=
    exec_copyVecToHeapStmt (scrR := scrR) (tblW := tblW) inp
      (wScr + 12) wOffPv wSideBaseR offPv sideBaseR sideBaseW d
      hfp₀ hscrW htblR hneR ⟨by omega, by omega⟩ hbaseR_d
      (by rcases hdisjOffPv with h | h <;> omega)
      (by rcases hdisjBR with h | h <;> omega) hdisjPv hoffPv hbR
  have hpv_st : ∀ c : Fin d, rRead m_st tblR (sideBaseR + (c.val : ℤ)) = euclideanCoord p_v c :=
    fun c => (hcop_st c.val c.isLt).trans (hpv c)
  have ho_st : ∀ c : Fin d, rRead m_st tblO (offO + (c.val : ℤ)) = euclideanCoord o c := fun c =>
    (hfr_st.2 tblO _ hneO (by
      have hc := c.isLt
      rcases hdisjO_pv with ht | h1 | h2
      · exact Or.inl ht
      · exact Or.inr (Or.inl (by omega))
      · exact Or.inr (Or.inr (by omega)))).trans (ho c)
  have henc_st : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m_st :=
    henc₀.mono_pvStage hfr_st hneW hneR
  have E : QryEnv d TW BW TR BR scrW scrR tblW tblR tblO
      wSideBaseW wSideBaseR wOffO wAnsOut wScr rScr sideBaseW sideBaseR offO
      n L_p2 R ℓ M₀ b T p_coord M_lat S_lat cap_u cap_q hM₀ A B_rat τ_d τ_q b_rat pts o p_v U idx m_st :=
    ⟨hS_lat, hpv_ne, hwf, hscrW, hscrR, hneW, hneR, hneO, hwAns, hwScr, hrScr,
      hdisjBW, hdisjBR, hdisjO, hdisjAns, hneAnsInputs, ho_st, hpv_st, henc_st⟩
  have hbW_st : wRead m_st scrW wSideBaseW = sideBaseW :=
    (hkW_st _ (by rcases hdisjBW with h | h <;> omega)).trans hbW
  have hbR_st : wRead m_st scrW wSideBaseR = sideBaseR :=
    (hkW_st _ (by rcases hdisjBR with h | h <;> omega)).trans hbR
  have hoffO_st : wRead m_st scrW wOffO = offO :=
    (hkW_st _ (by rcases hdisjO with h | h <;> omega)).trans hoffO
  let m1 := wWrite m_st scrW wAnsOut (-1)
  let m2 := wWrite m1 scrW wScr (wRead m_st tblW sideBaseW)
  let m3 := wWrite m2 scrW (wScr + 1) (idx.t_ins : ℤ)
  let m4 := wWrite m3 scrW (wScr + 2) (sideEntryPtOff d sideBaseR)
  have hd_i1 := qry_det_wLit inp m_st scrW wAnsOut (.lit (-1)) (-1) 10 rfl (by dsimp [intExprOps]; omega)
  have hd_i2 := qry_det_wLit inp m1 scrW wScr (.readHeap tblW (.readHeap scrW (.lit wSideBaseW)))
    (wRead m_st tblW sideBaseW) 20
    (by change wRead m1 tblW (wRead m1 scrW wSideBaseW) = _
        rw [qry_wne hneAnsInputs.1.symm, hbW_st, qry_wne_t hneW])
    (by dsimp [intExprOps]; omega)
  have hd_i3 := qry_det_wLit inp m2 scrW (wScr + 1)
    (.readHeap tblW (.add (.readHeap scrW (.lit wSideBaseW)) (.lit 1))) (idx.t_ins : ℤ) 25
    (by change wRead m2 tblW (wRead m2 scrW wSideBaseW + 1) = (idx.t_ins : ℤ)
        rw [qry_wne (by rcases hdisjBW with h | h <;> omega), qry_wne hneAnsInputs.1.symm,
            hbW_st, qry_wne_t hneW, qry_wne_t hneW]
        exact henc_st.t_ins_read)
    (by dsimp [intExprOps]; omega)
  have hd_i4 := qry_det_wLit inp m3 scrW (wScr + 2)
    (.add (.readHeap scrW (.lit wSideBaseR)) (.lit (d : ℤ))) (sideEntryPtOff d sideBaseR) 20
    (by change wRead m3 scrW wSideBaseR + (d : ℤ) = sideEntryPtOff d sideBaseR
        rw [qry_wne (by rcases hdisjBR with h | h <;> omega),
            qry_wne (by rcases hdisjBR with h | h <;> omega),
            qry_wne hneAnsInputs.2.1.symm, hbR_st]; rfl)
    (by dsimp [intExprOps]; omega)
  have hst1 : QrySt E m1 :=
    ⟨InFootprint.wWrite hfp_st hscrW hwAns.1 hwAns.2,
      (qry_wne hneAnsInputs.1.symm).trans hbW_st,
      (qry_wne hneAnsInputs.2.1.symm).trans hbR_st,
      (qry_wne hneAnsInputs.2.2.symm).trans hoffO_st,
      RadFrameOutside.wWrite_scr scrW scrR tblW sideBaseW 0 tblR sideBaseR 0 m_st _ _⟩
  have hst4 : QrySt E m4 :=
    ((hst1.wScrWrite E wScr _ (by omega) (by omega)).wScrWrite
      E (wScr + 1) _ (by omega) (by omega)).wScrWrite E (wScr + 2) _ (by omega) (by omega)
  have hkW_04 : ∀ w, w ≠ wAnsOut →
      (w < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
      wRead m4 scrW w = wRead m₀ scrW w := by
    intro w hw_ne hw_out
    rw [qry_wne (by rcases hw_out with h | h <;> omega),
        qry_wne (by rcases hw_out with h | h <;> omega),
        qry_wne (by rcases hw_out with h | h <;> omega),
        qry_wne hw_ne, hkW_st w (by rcases hw_out with h | h <;> omega)]
  let ans1 := dyadicSideTailOpt (b_rat : ℝ) o p_v idx 1
  obtain ⟨m5, hd_t1, hst5, hep5, ht5, hepB5, hans5, hkW45⟩ :=
    qry_exec_tailStep inp E hst4 1 le_rfl none
      (by rw [qry_wne (by omega), qry_wne (by omega)]; exact wRead_wWrite_self _ _ _ _)
      (by rw [qry_wne (by omega)]; exact wRead_wWrite_self _ _ _ _)
      (wRead_wWrite_self _ _ _ _)
      (by rw [qry_wne (by rcases hdisjAns with h | h <;> omega),
              qry_wne (by rcases hdisjAns with h | h <;> omega),
              qry_wne (by rcases hdisjAns with h | h <;> omega)]
          exact wRead_wWrite_self _ _ _ _)
  let ans2 : Option ℕ := qryOptOr ans1 (dyadicSideTailOpt (b_rat : ℝ) o p_v idx 2)
  obtain ⟨m6, hd_t2, hst6, _, ht6, hepB6, hans6, hkW56⟩ :=
    qry_exec_tailStep inp E hst5 2 (by decide) ans1 hep5 ht5 hepB5 hans5
  let m7 := wWrite m6 scrW (wScr + 3) 0
  let m8 := wWrite m7 scrW (wScr + 4) 1
  have hd_s0 := qry_det_wLit inp m6 scrW (wScr + 3) (.lit 0) 0 10 rfl (by dsimp [intExprOps]; omega)
  have hd_h0 := qry_det_wLit inp m7 scrW (wScr + 4) (.lit 1) 1 10 rfl (by dsimp [intExprOps]; omega)
  have hst8 : QrySt E m8 :=
    (hst6.wScrWrite E (wScr + 3) 0 (by omega) (by omega)).wScrWrite E (wScr + 4) 1 (by omega) (by omega)
  let scaleFn : Fin L_p2 → Option ℕ :=
    dyadicSideScaleOpt hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q o p_v idx
  let accOf : ∀ k ≤ L_p2, Option ℕ := fun k hk =>
    Fin.foldl k (fun acc (i : Fin k) =>
      qryOptOr acc (scaleFn ⟨i.val, lt_of_lt_of_le i.isLt hk⟩)) ans2
  let InvS : ℕ → ArithRAMMemory → Prop := fun s_idx m =>
    ∃ hs_le : s_idx ≤ L_p2,
      QrySt E m ∧
      wRead m scrW (wScr + 1) = (idx.t_ins : ℤ) ∧
      wRead m scrW (wScr + 2) = sideEntryPtOff d sideBaseR ∧
      wRead m scrW (wScr + 3) = (s_idx : ℤ) ∧
      wRead m scrW (wScr + 4) = ((2 ^ s_idx : ℕ) : ℤ) ∧
      wRead m scrW wAnsOut = optNatToInt (accOf s_idx hs_le) ∧
      (∀ w, w ≠ wAnsOut →
        (w < wScr ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w) →
        wRead m scrW w = wRead m₀ scrW w)
  have hInvS0 : InvS 0 m8 := by
    have hacc0 : accOf 0 (Nat.zero_le L_p2) = ans2 := by dsimp [accOf]; rw [Fin.foldl_zero]
    refine ⟨Nat.zero_le L_p2, hst8,
      by rw [qry_wne (by omega), qry_wne (by omega)]; exact ht6,
      by rw [qry_wne (by omega), qry_wne (by omega)]; exact hepB6,
      by rw [qry_wne (by omega)]; exact wRead_wWrite_self _ _ _ _,
      wRead_wWrite_self _ _ _ _,
      by rw [hacc0, qry_wne (by rcases hdisjAns with h | h <;> omega),
             qry_wne (by rcases hdisjAns with h | h <;> omega)]; exact hans6,
      fun w hw_ne hw_out => by
        rw [qry_wne (by rcases hw_out with h | h <;> omega),
            qry_wne (by rcases hw_out with h | h <;> omega),
            hkW56 w hw_ne hw_out, hkW45 w hw_ne hw_out, hkW_04 w hw_ne hw_out]⟩
  let C_s : ℕ := dyadicSideScaleQueryStepCost R ℓ M₀ d S_lat cap_q + 50
  obtain ⟨m_end, hInvEnd, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (L_p2 : ℤ)) _ L_p2 10 C_s
    InvS hInvS0 rfl (by dsimp [intExprOps]; omega)
    (fun s_idx hs_lt m ⟨hs_le, hst_m, ht_m, hepB_m, hs_m, hh_m, hans_m, hkW_m⟩ => by
      let sFin : Fin L_p2 := ⟨s_idx, hs_lt⟩
      obtain ⟨m_sc, hd_sc, hst_sc, hans_sc, hkW_sc⟩ :=
        qry_exec_scaleQueryStepStmt inp E hst_m sFin (accOf s_idx hs_le)
          ht_m hepB_m hs_m hh_m hans_m
      let m_nx1 := wWrite m_sc scrW (wScr + 3) ((s_idx + 1 : ℕ) : ℤ)
      let m_nx2 := wWrite m_nx1 scrW (wScr + 4) ((2 ^ (s_idx + 1) : ℕ) : ℤ)
      have hs_sc : wRead m_sc scrW (wScr + 3) = (s_idx : ℤ) :=
        (hkW_sc _ (by rcases hdisjAns with h | h <;> omega) (Or.inl (by omega))).trans hs_m
      have hh_sc : wRead m_sc scrW (wScr + 4) = ((2 ^ s_idx : ℕ) : ℤ) :=
        (hkW_sc _ (by rcases hdisjAns with h | h <;> omega) (Or.inl (by omega))).trans hh_m
      have hd_nx1 := qry_det_wLit inp m_sc scrW (wScr + 3)
        (.add (.readHeap scrW (.lit (wScr + 3))) (.lit 1)) ((s_idx + 1 : ℕ) : ℤ) 20
        (by change wRead m_sc scrW (wScr + 3) + 1 = _; rw [hs_sc]; push_cast; ring)
        (by dsimp [intExprOps]; omega)
      have hd_nx2 := qry_det_wLit inp m_nx1 scrW (wScr + 4)
        (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 4)))) ((2 ^ (s_idx + 1) : ℕ) : ℤ) 20
        (by change 2 * wRead m_nx1 scrW (wScr + 4) = ((2 ^ (s_idx + 1) : ℕ) : ℤ)
            rw [qry_wne (by omega), hh_sc, Nat.pow_succ']; push_cast; ring)
        (by dsimp [intExprOps]; omega)
      have hst_nx2 : QrySt E m_nx2 :=
        (hst_sc.wScrWrite E (wScr + 3) _ (by omega) (by omega)).wScrWrite E (wScr + 4) _ (by omega) (by omega)
      have hacc_succ : accOf (s_idx + 1) hs_lt = qryOptOr (accOf s_idx hs_le) (scaleFn sFin) := by
        dsimp [accOf]; rw [Fin.foldl_succ_last]
        exact congrArg (qryOptOr (accOf s_idx hs_le)) (congrArg scaleFn (Fin.ext rfl))
      refine ⟨m_nx2, (hd_sc.seq (hd_nx1.seq hd_nx2)).mono_cost (by dsimp [C_s]; omega),
        hs_lt, hst_nx2,
        by rw [qry_wne (by omega), qry_wne (by omega),
               hkW_sc _ (by rcases hdisjAns with h | h <;> omega) (Or.inl (by omega))]; exact ht_m,
        by rw [qry_wne (by omega), qry_wne (by omega),
               hkW_sc _ (by rcases hdisjAns with h | h <;> omega) (Or.inl (by omega))]; exact hepB_m,
        by rw [qry_wne (by omega)]; exact wRead_wWrite_self _ _ _ _,
        wRead_wWrite_self _ _ _ _,
        by rw [hacc_succ, qry_wne (by rcases hdisjAns with h | h <;> omega),
               qry_wne (by rcases hdisjAns with h | h <;> omega)]; exact hans_sc,
        fun w hw_ne hw_out => by
          have hw5 : w < wScr + 5 ∨ wScr + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w := by
            rcases hw_out with h | h
            · exact Or.inl (by omega)
            · exact Or.inr h
          rw [qry_wne (by rcases hw_out with h | h <;> omega),
              qry_wne (by rcases hw_out with h | h <;> omega),
              hkW_sc w hw_ne hw5, hkW_m w hw_ne hw_out]⟩)
  rcases hInvEnd with ⟨_, hst_end, _, _, _, _, hans_end, hkW_end⟩
  have hfr_full : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR (d : ℤ) m₀ m_end :=
    hfr_st.trans
      (hst_end.hfr.mono_range (bW₂ := sideBaseW) (lW₂ := 0) (bR₂ := sideBaseR) (lR₂ := (d : ℤ))
        (Or.inl rfl) (Or.inl rfl))
  have hacc_full : accOf L_p2 le_rfl = pureAns := by
    change Fin.foldl L_p2 (fun acc (i : Fin L_p2) =>
      qryOptOr acc (scaleFn ⟨i.val, lt_of_lt_of_le i.isLt le_rfl⟩)) ans2 = pureAns
    have heq_fn : (fun acc (i : Fin L_p2) =>
        qryOptOr acc (scaleFn ⟨i.val, lt_of_lt_of_le i.isLt le_rfl⟩)) =
        (fun acc (i : Fin L_p2) => qryOptOr acc (scaleFn i)) := by
      funext acc i; rfl
    rw [heq_fn]
    exact dyadicSide_query_eq_foldl hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q o p_v idx
  refine ⟨m_end,
    (hd_cp.seq (hd_i1.seq (hd_i2.seq (hd_i3.seq (hd_i4.seq
      (hd_t1.seq (hd_t2.seq (hd_s0.seq (hd_h0.seq hd_loop))))))))).mono_cost
      (by unfold dyadicSideQueryCost; dsimp [C_s]; omega),
    hst_end.hfp, by rw [hans_end, hacc_full],
    henc₀.mono_pvStage hfr_full hneW hneR, hkW_end, hfr_full⟩

/-! ### 4. `Uid`-Indexed Convenience Wrapper (Plug-In Ready for `CG17.SideRAMOps`) -/

def dyadicSideQuerySlat (M_lat : ℕ) : ℕ :=
  Nat.clog 2 (2 * M_lat + 1)

lemma two_mul_add_one_le_pow_dyadicSideQuerySlat (M_lat : ℕ) :
    2 * M_lat + 1 ≤ 2 ^ dyadicSideQuerySlat M_lat :=
  Nat.le_pow_clog (by decide) (2 * M_lat + 1)

lemma dyadicSideQuerySlat_le (M_lat : ℕ) :
    dyadicSideQuerySlat M_lat ≤ 2 * M_lat + 1 := by
  unfold dyadicSideQuerySlat
  rw [Nat.clog_le_iff_le_pow (by decide)]
  exact Nat.lt_two_pow_self.le

def dyadicSideQueryUidStmt (scrW scrR tblW tblR : ℕ)
    (wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d M_lat cap_u cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) : ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit wScr)
          (.mul (.readHeap scrW (.lit wQryUid)) (.lit (d : ℤ))))
       (dyadicSideQueryStmt scrW scrR tblW tblR tblR 1
          wSideBaseW wSideBaseR wOffO wScr wAnsOut (wScr + 4) rScr
          n L_p2 R ℓ M₀ d M_lat (dyadicSideQuerySlat M_lat) cap_u cap_q A B_rat τ_q b_rat)

def dyadicSideQueryUidCost (L_p2 R ℓ M₀ d M_lat cap_q : ℕ) : ℕ :=
  30 + dyadicSideQueryCost L_p2 R ℓ M₀ d (dyadicSideQuerySlat M_lat) cap_q

theorem zeroRand_dyadicSideQueryUidStmt (scrW scrR tblW tblR : ℕ)
    (wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d M_lat cap_u cap_q : ℕ) (A B_rat τ_q b_rat : ℚ) :
    H3a.ZeroRandStmt (dyadicSideQueryUidStmt scrW scrR tblW tblR
      wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr
      n L_p2 R ℓ M₀ d M_lat cap_u cap_q A B_rat τ_q b_rat) :=
  of_isZeroRandB rfl

theorem exec_h4_dyadicSideQueryUidStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr
      sideBaseW sideBaseR offO : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord M_lat cap_u cap_q qUid : ℕ}
    (hM₀ : 1 ≤ M₀)
    {A B_rat τ_d : ℚ} (τ_q b_rat : ℚ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {o : EuclideanSpace ℝ (Fin d)} (hq_ne_o : pts qUid ≠ o)
    {U : Finset ℕ} {idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b}
    (hwf : H4b.DyadicSideWF hM₀ T p_coord A B_rat τ_d cap_u pts o U idx)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hne1R : 1 ≠ tblR)
    (hbaseR : 0 ≤ sideBaseR ∧ sideBaseR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ (BR : ℤ))
    (hoffO_b : 0 ≤ offO ∧ offO + (d : ℤ) ≤ sideBaseR)
    (hwBW : 0 ≤ wSideBaseW ∧ wSideBaseW < wScr)
    (hwBR : 0 ≤ wSideBaseR ∧ wSideBaseR < wScr)
    (hwO : 0 ≤ wOffO ∧ wOffO < wScr)
    (hwQ : 0 ≤ wQryUid ∧ wQryUid < wScr)
    (hwAns : 0 ≤ wAnsOut ∧ wAnsOut < wScr)
    (hneAnsInputs : wAnsOut ≠ wSideBaseW ∧ wAnsOut ≠ wSideBaseR ∧ wAnsOut ≠ wOffO)
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideQueryUidWStride ℓ M₀ cap_q ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + dyadicSideQueryRStride d ≤ (BR : ℤ))
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hbR : wRead m₀ scrW wSideBaseR = sideBaseR)
    (hoffO : wRead m₀ scrW wOffO = offO)
    (hqUid : wRead m₀ scrW wQryUid = (qUid : ℤ))
    (ho : ∀ c : Fin d, rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hq_pt : ∀ c : Fin d, rRead m₀ 1 (((qUid * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts qUid) c)
    (henc₀ : EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₀) :
    let pureAns := idx.query hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q o (pts qUid)
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (dyadicSideQueryUidStmt scrW scrR tblW tblR
          wSideBaseW wSideBaseR wOffO wQryUid wAnsOut wScr rScr
          n L_p2 R ℓ M₀ d M_lat cap_u cap_q A B_rat τ_q b_rat)
        m₀ m₁ (dyadicSideQueryUidCost L_p2 R ℓ M₀ d M_lat cap_q) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncH4DyadicSide tblW sideBaseW tblR sideBaseR n L_p2 R ℓ M₀ d b cap_u U idx m₁ ∧
      wRead m₁ scrW wAnsOut = optNatToInt pureAns ∧
      (match pureAns with
       | none => wRead m₁ scrW wAnsOut = -1
       | some w => wRead m₁ scrW wAnsOut = (w : ℤ)) ∧
      (∀ w, w ≠ wAnsOut →
        (w < wScr ∨ wScr + dyadicSideQueryUidWStride ℓ M₀ cap_q ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW sideBaseW (dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
        tblR sideBaseR (dyadicSideRStride L_p2 R ℓ M₀ d) m₀ m₁ := by
  intro pureAns
  have hge48 := dyadicSideQueryUidWStride_ge_48 ℓ M₀ cap_q
  have hstr_eq : dyadicSideQueryUidWStride ℓ M₀ cap_q = 4 + dyadicSideQueryWStride ℓ M₀ cap_q := by
    unfold dyadicSideQueryUidWStride dyadicSideQueryWStride; omega
  have hr_ge_d := dyadicSideRStride_ge_d L_p2 R ℓ M₀ d
  let offPv : ℤ := ((qUid * d : ℕ) : ℤ)
  let m_pv := wWrite m₀ scrW wScr offPv
  have hd_pv := qry_det_wLit inp m₀ scrW wScr
    (.mul (.readHeap scrW (.lit wQryUid)) (.lit (d : ℤ))) offPv 20
    (by change wRead m₀ scrW wQryUid * (d : ℤ) = offPv
        rw [hqUid]; dsimp [offPv])
    (by dsimp [intExprOps]; omega)
  have hfp_pv : InFootprint TW BW TR BR m_pv :=
    InFootprint.wWrite hfp₀ hscrW hwScr.1 (by omega)
  have hfr0_pv : RadFrameOutside scrW scrR tblW sideBaseW 0 tblR sideBaseR (d : ℤ) m₀ m_pv :=
    RadFrameOutside.wWrite_scr scrW scrR tblW sideBaseW 0 tblR sideBaseR (d : ℤ) m₀ _ _
  obtain ⟨m₁, hd_q, hfp₁, hans₁, henc₁, hkW₁, hfr_q⟩ :=
    exec_h4_dyadicSideQueryStmt (cap_q := cap_q) inp
      wSideBaseW wSideBaseR wOffO wScr wAnsOut (wScr + 4) rScr
      sideBaseW sideBaseR offO offPv
      hM₀ (two_mul_add_one_le_pow_dyadicSideQuerySlat M_lat)
      τ_q b_rat hq_ne_o hwf
      hfp_pv hscrW hscrR htblR hneW hneR hneR
      ⟨hbaseR.1, by omega⟩ (Or.inr (Or.inl hoffO_b.2)) (Or.inl hne1R)
      ⟨hwAns.1, by omega⟩ ⟨by omega, by omega⟩ hrScr
      (Or.inl (by omega)) (Or.inl (by omega)) (Or.inl (by omega))
      (Or.inl (by omega)) (Or.inl (by omega)) hneAnsInputs
      ((qry_wne (by omega)).trans hbW) ((qry_wne (by omega)).trans hbR)
      ((qry_wne (by omega)).trans hoffO) (wRead_wWrite_self _ _ _ _)
      (fun c => by rw [rRead_wWrite]; exact ho c)
      (fun c => by
        rw [rRead_wWrite]
        have haddr : offPv + (c.val : ℤ) = ((qUid * d + c.val : ℕ) : ℤ) := by
          dsimp [offPv]
        rw [haddr]; exact hq_pt c)
      (henc₀.mono_pvStage hfr0_pv hneW hneR)
  refine ⟨m₁, (hd_pv.seq hd_q).mono_cost (by unfold dyadicSideQueryUidCost; omega),
    hfp₁, henc₁, hans₁, by dsimp only [pureAns]; cases hq : idx.query hM₀ M_lat A B_rat τ_q (b_rat : ℝ) cap_q o (pts qUid) <;> simpa [hq, optNatToInt] using hans₁, ?_,
    (hfr0_pv.trans hfr_q).mono_range
      (bW₂ := sideBaseW) (lW₂ := dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
      (bR₂ := sideBaseR) (lR₂ := dyadicSideRStride L_p2 R ℓ M₀ d)
      (Or.inl rfl) (Or.inr ⟨le_rfl, by omega⟩)⟩
  intro w hw_ne hw_out
  have hw4 : w < wScr + 4 ∨ (wScr + 4) + dyadicSideQueryWStride ℓ M₀ cap_q ≤ w := by
    rcases hw_out with h | h
    · exact Or.inl (by omega)
    · exact Or.inr (by omega)
  rw [hkW₁ w hw_ne hw4, qry_wne (by rcases hw_out with h | h <;> omega)]

/-! ### 5. Explicit Polynomial Cost Bounds -/

theorem liveSlotQueryCost_le (R ℓ M₀ d S_lat cap_q : ℕ) :
    liveSlotQueryCost R ℓ M₀ d S_lat cap_q ≤
      2500 * (R + 1) * (ℓ + 1) * (M₀ + 1) * (cap_q + 1) * (d + 1) * (S_lat + 1) := by
  let P4 : ℕ := (ℓ + 1) * (M₀ + 1) * (cap_q + 1) * (d + 1)
  have hev : evalCopyTuplesCost ℓ M₀ d cap_q ≤ 950 * P4 := by
    unfold evalCopyTuplesCost; dsimp [P4]
    have h1 : 200 + ℓ * (250 + M₀ * (350 + 80 * d)) ≤ 680 * (ℓ + 1) * (M₀ + 1) * (d + 1) := by
      nlinarith [Nat.zero_le (ℓ * M₀ * d), Nat.zero_le (ℓ * M₀), Nat.zero_le (ℓ * d), Nat.zero_le (M₀ * d)]
    have h2 : cap_q * (110 + 130 * ℓ) ≤ 240 * ((ℓ + 1) * (cap_q + 1)) := by
      nlinarith [Nat.zero_le (cap_q * ℓ)]
    have h1' := Nat.mul_le_mul h1 (show 1 ≤ cap_q + 1 by omega)
    have h2' := Nat.mul_le_mul h2 (Nat.mul_pos (show 0 < M₀ + 1 by omega) (show 0 < d + 1 by omega))
    nlinarith
  have hcp : liveSlotQueryCopyCost ℓ M₀ d cap_q + 30 ≤ 2300 * P4 := by
    unfold liveSlotQueryCopyCost liveSlotQueryStepCost; dsimp [P4] at hev ⊢
    have hst : 180 + (2 * cap_q + 2) * (450 + 130 * d) ≤ 1350 * ((cap_q + 1) * (d + 1)) := by
      nlinarith [Nat.zero_le (cap_q * d)]
    have hst' := Nat.mul_le_mul (Nat.mul_pos (show 0 < ℓ + 1 by omega) (show 0 < M₀ + 1 by omega)) hst
    nlinarith
  unfold liveSlotQueryCost
  have hhd : 250 + 70 * d + d * (60 + 165 * S_lat) ≤ 550 * ((d + 1) * (S_lat + 1)) := by
    nlinarith [Nat.zero_le (d * S_lat)]
  have hhd' := Nat.mul_le_mul
    (Nat.mul_pos (Nat.mul_pos (show 0 < ℓ + 1 by omega) (show 0 < M₀ + 1 by omega))
      (show 0 < cap_q + 1 by omega)) hhd
  have hR : R * (liveSlotQueryCopyCost ℓ M₀ d cap_q + 30) ≤ R * (2500 * P4 * (S_lat + 1)) := by
    refine Nat.mul_le_mul_left R ?_
    have := Nat.mul_le_mul hcp (show 1 ≤ S_lat + 1 by omega)
    nlinarith [Nat.zero_le (P4 * (S_lat + 1))]
  dsimp [P4] at hR
  nlinarith

theorem dyadicSideQueryCost_le (L_p2 R ℓ M₀ d S_lat cap_q : ℕ) :
    dyadicSideQueryCost L_p2 R ℓ M₀ d S_lat cap_q ≤
      6000 * (L_p2 + 1) * (R + 1) * (ℓ + 1) * (M₀ + 1) * (cap_q + 1) * (d + 1) * (S_lat + 1) := by
  let P : ℕ := (R + 1) * (ℓ + 1) * (M₀ + 1) * (cap_q + 1) * (d + 1) * (S_lat + 1)
  have hP_ge : d + 1 ≤ P := by
    dsimp [P]
    have hpos : 1 ≤ (R + 1) * (ℓ + 1) * (M₀ + 1) * (cap_q + 1) :=
      Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (by omega) (by omega)) (by omega)) (by omega)
    have := Nat.mul_le_mul (Nat.mul_le_mul_right (d + 1) hpos) (show 1 ≤ S_lat + 1 by omega)
    nlinarith
  have hq : liveSlotQueryCost R ℓ M₀ d S_lat cap_q ≤ 2500 * P := by
    simpa [P, mul_assoc] using liveSlotQueryCost_le R ℓ M₀ d S_lat cap_q
  have hstep : dyadicSideScaleQueryStepCost R ℓ M₀ d S_lat cap_q + 50 ≤ 6000 * P := by
    unfold dyadicSideScaleQueryStepCost dyadicSideSlotSubQueryCost; omega
  have hL := Nat.mul_le_mul_left L_p2 hstep
  unfold dyadicSideQueryCost dyadicSideTailCheckCost
  have htot : 6000 * P + L_p2 * (6000 * P) =
      6000 * (L_p2 + 1) * (R + 1) * (ℓ + 1) * (M₀ + 1) * (cap_q + 1) * (d + 1) * (S_lat + 1) := by
    dsimp [P]; ring
  nlinarith

theorem dyadicSideQueryUidCost_le (L_p2 R ℓ M₀ d M_lat cap_q : ℕ) :
    dyadicSideQueryUidCost L_p2 R ℓ M₀ d M_lat cap_q ≤
      12100 * (L_p2 + 1) * (R + 1) * (ℓ + 1) * (M₀ + 1) * (cap_q + 1) * (d + 1) * (M_lat + 1) := by
  unfold dyadicSideQueryUidCost
  have hsl : dyadicSideQuerySlat M_lat + 1 ≤ 2 * (M_lat + 1) := by
    have := dyadicSideQuerySlat_le M_lat; omega
  let Q : ℕ := (L_p2 + 1) * (R + 1) * (ℓ + 1) * (M₀ + 1) * (cap_q + 1) * (d + 1)
  have hQ1 : 1 ≤ Q :=
    Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (by omega) (by omega))
      (by omega)) (by omega)) (by omega)) (by omega)
  have hbase : dyadicSideQueryCost L_p2 R ℓ M₀ d (dyadicSideQuerySlat M_lat) cap_q ≤
      6000 * Q * (dyadicSideQuerySlat M_lat + 1) := by
    simpa [Q, mul_assoc] using
      dyadicSideQueryCost_le L_p2 R ℓ M₀ d (dyadicSideQuerySlat M_lat) cap_q
  have hmul := Nat.mul_le_mul_left (6000 * Q) hsl
  have h1 := Nat.mul_pos hQ1 (show 0 < M_lat + 1 by omega)
  have htot : 12100 * Q * (M_lat + 1) =
      12100 * (L_p2 + 1) * (R + 1) * (ℓ + 1) * (M₀ + 1) * (cap_q + 1) * (d + 1) * (M_lat + 1) := by
    dsimp [Q]; ring
  nlinarith

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
