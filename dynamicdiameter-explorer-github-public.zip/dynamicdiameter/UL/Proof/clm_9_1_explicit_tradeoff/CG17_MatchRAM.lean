import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB
import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideRAM

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2 (forLoopStmt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1 (cdfDegree)
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2 (gaussIntPolyStmt polyCDFStmt polyQuantileStmt)
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43 (HeapZeroRandStmt)
open UL.Proof.clm_9_1_explicit_tradeoff.CG16
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 1. `isHeapZeroRandB` & `SideHeapZeroRand` for `CG16.mkSideRAMOps` -/

def isHeapZeroRandB : ArithRAMStmt → Bool
  | .skip => true
  | .writeWordHeap _ _ _ | .writeRealHeap _ _ _ => true
  | .seq s₁ s₂ => isHeapZeroRandB s₁ && isHeapZeroRandB s₂
  | .ite _ t f => isHeapZeroRandB t && isHeapZeroRandB f
  | .repeatN _ b => isHeapZeroRandB b
  | _ => false

theorem of_isHeapZeroRandB : ∀ {s : ArithRAMStmt}, isHeapZeroRandB s = true → HeapZeroRandStmt s
  | .skip, _ => .skip
  | .writeWordHeap t i v, _ => .writeWordHeap t i v
  | .writeRealHeap t i v, _ => .writeRealHeap t i v
  | .seq s₁ s₂, h => by
      simp only [isHeapZeroRandB, Bool.and_eq_true] at h
      exact .seq (of_isHeapZeroRandB h.1) (of_isHeapZeroRandB h.2)
  | .ite _ t f, h => by
      simp only [isHeapZeroRandB, Bool.and_eq_true] at h
      exact .ite (of_isHeapZeroRandB h.1) (of_isHeapZeroRandB h.2)
  | .repeatN _ b, h => .repeatN (of_isHeapZeroRandB h)
  | .writeWordLocal _ _ _, h => by simp [isHeapZeroRandB] at h
  | .freeWordHeap _ _, h => by simp [isHeapZeroRandB] at h
  | .freeWordLocal _ _, h => by simp [isHeapZeroRandB] at h
  | .writeRealLocal _ _ _, h => by simp [isHeapZeroRandB] at h
  | .freeRealHeap _ _, h => by simp [isHeapZeroRandB] at h
  | .freeRealLocal _ _, h => by simp [isHeapZeroRandB] at h
  | .randBitHeap _ _, h => by simp [isHeapZeroRandB] at h
  | .randBitLocal _ _, h => by simp [isHeapZeroRandB] at h
  | .whileLoop _ _, h => by simp [isHeapZeroRandB] at h
  | .localScope _, h => by simp [isHeapZeroRandB] at h

private theorem hzr_forLoop (scrW : ℕ) (idx : ℤ) (N : ℕ) {b : ArithRAMStmt}
    (hb : HeapZeroRandStmt b) : HeapZeroRandStmt (forLoopStmt scrW idx N b) :=
  .seq (.writeWordHeap _ _ _) (.repeatN (.seq hb (.writeWordHeap _ _ _)))

private theorem hzr_polyQuantile (scrW scrR : ℕ) (wK wBase rBase rOut : ℤ) (b T p_coord : ℕ) :
    HeapZeroRandStmt (polyQuantileStmt scrW scrR wK wBase rBase rOut b T p_coord) := by
  have hg : ∀ (wB rY rT rA : ℤ) (K : ℕ),
      HeapZeroRandStmt (gaussIntPolyStmt scrW scrR wB rY rT rA K) := fun _ _ _ _ _ =>
    .seq (.writeRealHeap _ _ _)
      (.seq (.writeRealHeap _ _ _)
        (hzr_forLoop _ _ _ (.seq (.writeRealHeap _ _ _) (.writeRealHeap _ _ _))))
  have hcdf : ∀ (wB rX rY rT rA rO : ℤ) (K : ℕ) (cp : ℚ),
      HeapZeroRandStmt (polyCDFStmt scrW scrR wB rX rY rT rA rO K cp) := fun _ _ _ _ _ _ _ _ =>
    .ite (.seq (.writeRealHeap _ _ _) (.seq (hg _ _ _ _ _) (.writeRealHeap _ _ _)))
         (.seq (.writeRealHeap _ _ _) (.seq (hg _ _ _ _ _) (.writeRealHeap _ _ _)))
  unfold polyQuantileStmt
  exact .ite (.writeRealHeap _ _ _)
    (.seq (.writeRealHeap _ _ _)
    (.seq (hzr_forLoop _ _ _ (.writeRealHeap _ _ _))
    (.seq (.writeRealHeap _ _ _)
    (.seq (.writeRealHeap _ _ _)
    (.seq (.writeRealHeap _ _ _)
    (.seq (hzr_forLoop _ _ _
            (.seq (.writeRealHeap _ _ _)
              (.seq (hcdf _ _ _ _ _ _ _ _)
                (.ite (.writeRealHeap _ _ _) (.writeRealHeap _ _ _)))))
          (.writeRealHeap _ _ _)))))))

theorem mkSideHeapZeroRand
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    SideHeapZeroRand
      (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
        scrW scrR tblW tblR coinTbl) where
  hzr_zeroInitStmt := fun _ _ _ _ => of_isHeapZeroRandB rfl
  hzr_clearStmt := fun _ _ _ _ => of_isHeapZeroRandB rfl
  hzr_removeStmt := fun _ _ _ _ _ => of_isHeapZeroRandB rfl
  hzr_queryStmt := fun _ _ _ _ _ _ _ _ _ _ => of_isHeapZeroRandB rfl
  hzr_insertStmt := fun _ _ _ _ _ _ _ _ _ => by
    have hinit : ∀ (wBW wBR wNB wSS wSB rSB : ℤ),
        HeapZeroRandStmt (slotInitFromCoinTblStmt scrW scrR tblW tblR coinTbl
          wBW wBR wNB wSS wSB rSB R ℓ M₀ d b T_cdf p_coord) := fun _ _ _ _ _ _ =>
      .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
        (.repeatN
          (.seq (of_isHeapZeroRandB rfl)
          (.seq (hzr_polyQuantile _ _ _ _ _ _ _ _ _)
          (.seq (.writeRealHeap _ _ _) (.writeWordHeap _ _ _)))))))))
    have hsinit : ∀ (wSeed wS rS : ℤ),
        HeapZeroRandStmt (dyadicSideInsertScaleInitStmt scrW scrR tblW tblR coinTbl
          wSeed wS rS R ℓ M₀ d b T_cdf p_coord) := fun _ _ _ =>
      .ite (.seq (.writeWordHeap _ _ _) (hinit _ _ _ _ _ _)) .skip
    have hone : ∀ (tblO : ℕ) (wBW wBR wO wS rS : ℤ) (A B_r τ : ℚ),
        HeapZeroRandStmt (dyadicSideInsertOneEidStmt scrW scrR tblW tblR tblO
          wBW wBR wO wS rS L_p2 R ℓ M₀ d cap_u A B_r τ) := fun _ _ _ _ _ _ _ _ _ =>
      of_isHeapZeroRandB rfl
    exact .seq (.writeWordHeap _ _ _)
      (.seq (of_isHeapZeroRandB rfl)
        (.repeatN
          (.seq (.writeWordHeap _ _ _)
          (.seq (.writeWordHeap _ _ _)
          (.seq (.writeWordHeap _ _ _)
          (.seq (.ite
                  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
                  (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
                  (.seq (hsinit _ _ _)
                  (.seq (.writeWordHeap _ _ _) (.seq (hone _ _ _ _ _ _ _ _ _)
                  (.seq (.writeWordHeap _ _ _) (hone _ _ _ _ _ _ _ _ _)))))))))
                  .skip)
                (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))))))

/-! ### 2. Concrete `configMatchRAMOps` & `configMatchHeapZeroRand` -/

noncomputable def configMatchRAMOps
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ)
    (params : LocalScaleParams) (h : ℝ)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat
      params h τ_d τ_q cap_u cap_q scrW scrR tblW tblR coinTbl :=
  mkConfigMatchRAMOps params h
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)

theorem configMatchHeapZeroRand
    (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ)
    (params : LocalScaleParams) (h : ℝ)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (scrW scrR tblW tblR coinTbl : ℕ) :
    ConfigMatchHeapZeroRand
      (configMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat
        params h τ_d τ_q cap_u cap_q scrW scrR tblW tblR coinTbl) :=
  mkConfigMatchHeapZeroRand params h
    (mkSideHeapZeroRand d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)

/-! ### 3. Explicit Concrete Stride & Sublinear Cost Bounds for `CG18_OpsInst` -/

section ConcreteBounds

variable (d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ)
variable (params : LocalScaleParams) (h : ℝ)
variable (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
variable (scrW scrR tblW tblR coinTbl : ℕ)

theorem configMatchRAMOps_cfgWStride_le :
    (configMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).cfgWStride ≤
    (((3 + 8 * n + 2 * (2 + 2 * 2 ^ L_p2 + n +
      2 * L_p2 * (4 + 2 * R * M₀ ^ ℓ + 5 * 2 ^ L_p2 * R * cap_u))) : ℕ) : ℤ) := by
  have hs := mkSideRAMOps_sideWStride_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
    scrW scrR tblW tblR coinTbl
  unfold configMatchRAMOps
  rw [mkConfigMatchRAMOps_cfgWStride]
  push_cast at hs ⊢
  linarith

theorem configMatchRAMOps_cfgRStride_le :
    (configMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).cfgRStride ≤
    (((2 * (d + 2 ^ L_p2 * d + 2 * L_p2 * (R * ℓ * M₀ * (d + 1)))) : ℕ) : ℤ) := by
  have hs := mkSideRAMOps_sideRStride_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
    scrW scrR tblW tblR coinTbl
  unfold configMatchRAMOps
  rw [mkConfigMatchRAMOps_cfgRStride]
  push_cast at hs ⊢
  linarith

theorem configMatchRAMOps_opWScrStride_le :
    (configMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).opWScrStride ≤
    (((64 + ℓ + ℓ * M₀ + cap_u + cap_q) : ℕ) : ℤ) := by
  have hs := mkSideRAMOps_sideWScrStride_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
    scrW scrR tblW tblR coinTbl
  unfold configMatchRAMOps
  rw [mkConfigMatchRAMOps_opWScrStride]
  push_cast at hs ⊢
  linarith

theorem configMatchRAMOps_opRScrStride_le :
    (configMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).opRScrStride ≤
    (((15 + 3 * d) : ℕ) : ℤ) := by
  have hs := mkSideRAMOps_sideRScrStride_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
    scrW scrR tblW tblR coinTbl
  unfold configMatchRAMOps
  rw [mkConfigMatchRAMOps_opRScrStride]
  push_cast at hs ⊢
  linarith

@[simp] theorem configMatchRAMOps_readEdgeCost :
    (configMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).readEdgeCost = 120 := rfl

theorem configMatchRAMOps_clearCost_le :
    (configMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).clearCost ≤
    220 + 1440 * (L_p2 + 1) := by
  have hz := mkSideRAMOps_zeroInitCost_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
    scrW scrR tblW tblR coinTbl
  have hc := mkSideRAMOps_clearCost_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
    scrW scrR tblW tblR coinTbl
  have h := mkConfigMatchRAMOps_clearCost_le params h
    (mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
  unfold configMatchRAMOps
  omega

/-- Sublinear polynomial factor multiplying `(1 + cap_u + cap_q + R * ℓ * M₀)` in both
`insertCost` and `deleteCost` of `configMatchRAMOps`. -/
def configMatchPolyFactor (d L_p2 R ℓ b T_cdf p_coord M_lat : ℕ) : ℕ :=
  (L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * (M_lat + 1) *
    (24000 + 120 * b + 2 * (T_cdf + p_coord + 6) * (120 + 48 * cdfDegree T_cdf b))

theorem configMatchRAMOps_insertCost_le :
    (configMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).insertCost ≤
    (1 + cap_u + cap_q + R * ℓ * M₀) *
      configMatchPolyFactor d L_p2 R ℓ b T_cdf p_coord M_lat := by
  let sops := mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
    scrW scrR tblW tblR coinTbl
  let C := 1 + cap_u + cap_q + R * ℓ * M₀
  let Base := (L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * (M_lat + 1)
  let Q := 2250 + 60 * b + (T_cdf + p_coord + 6) * (120 + 48 * cdfDegree T_cdf b)
  have hC_pos : 1 ≤ C := by dsimp [C]; omega
  have hBase_ge_d : d + 1 ≤ Base := by
    have hp : 1 ≤ (L_p2 + 1) * (R + 1) * (ℓ + 1) * (M_lat + 1) :=
      Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.succ_pos _) (Nat.succ_pos _)) (Nat.succ_pos _)) (Nat.succ_pos _)
    calc d + 1 = 1 * (d + 1) := by ring
      _ ≤ ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (M_lat + 1)) * (d + 1) := Nat.mul_le_mul_right _ hp
      _ = Base := by dsimp [Base]; ring
  have hBase_ge_LR : (L_p2 + 1) * (R + 1) ≤ Base := by
    have hp : 1 ≤ (ℓ + 1) * (d + 1) * (M_lat + 1) :=
      Nat.mul_pos (Nat.mul_pos (Nat.succ_pos _) (Nat.succ_pos _)) (Nat.succ_pos _)
    calc (L_p2 + 1) * (R + 1) = ((L_p2 + 1) * (R + 1)) * 1 := by ring
      _ ≤ ((L_p2 + 1) * (R + 1)) * ((ℓ + 1) * (d + 1) * (M_lat + 1)) := Nat.mul_le_mul_left _ hp
      _ = Base := by dsimp [Base]; ring
  have hBase_ge_LRLd : (L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) ≤ Base :=
    Nat.le_mul_of_pos_right _ (Nat.succ_pos M_lat)
  have hhd : 1720 + 55 * d ≤ C * (Base * 1720) := by
    have h1 : 1720 + 55 * d ≤ (d + 1) * 1720 := by omega
    have h2 : (d + 1) * 1720 ≤ Base * 1720 := Nat.mul_le_mul_right 1720 hBase_ge_d
    have h3 : Base * 1720 ≤ C * (Base * 1720) := Nat.le_mul_of_pos_left _ hC_pos
    exact le_trans h1 (le_trans h2 h3)
  have hqry : 2 * sops.queryCost ≤ C * (Base * 13000) := by
    have hq := mkSideRAMOps_queryCost_sublinear_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl
    calc 2 * sops.queryCost ≤ 2 * (C * (Base * 6500)) := Nat.mul_le_mul_left 2 hq
      _ = C * (Base * 13000) := by ring
  have hins : 2 * sops.insertCost ≤ C * (Base * (2 * Q)) := by
    have hi := mkSideRAMOps_insertCost_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl
    have hi' : ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1)) * Q ≤ Base * Q :=
      Nat.mul_le_mul_right Q hBase_ge_LRLd
    calc 2 * sops.insertCost
        ≤ 2 * (C * (((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1)) * Q)) := Nat.mul_le_mul_left 2 hi
      _ ≤ 2 * (C * (Base * Q)) := Nat.mul_le_mul_left 2 (Nat.mul_le_mul_left C hi')
      _ = C * (Base * (2 * Q)) := by ring
  have hrem : 2 * sops.removeCost ≤ C * (Base * 1600) := by
    have hr := mkSideRAMOps_removeCost_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl
    have hr' : 800 * (L_p2 + 1) * (R + 1) ≤ Base * 800 := by
      calc 800 * (L_p2 + 1) * (R + 1) = ((L_p2 + 1) * (R + 1)) * 800 := by ring
        _ ≤ Base * 800 := Nat.mul_le_mul_right 800 hBase_ge_LR
    calc 2 * sops.removeCost ≤ 2 * (C * (800 * (L_p2 + 1) * (R + 1))) := Nat.mul_le_mul_left 2 hr
      _ ≤ 2 * (C * (Base * 800)) := Nat.mul_le_mul_left 2 (Nat.mul_le_mul_left C hr')
      _ = C * (Base * 1600) := by ring
  have hmain := mkConfigMatchRAMOps_insertCost_le params h sops
  unfold configMatchRAMOps
  calc (mkConfigMatchRAMOps params h sops).insertCost
      ≤ 1720 + 55 * d + 2 * sops.queryCost + 2 * sops.insertCost + 2 * sops.removeCost := hmain
    _ ≤ C * (Base * 1720) + C * (Base * 13000) + C * (Base * (2 * Q)) + C * (Base * 1600) :=
        Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hhd hqry) hins) hrem
    _ = C * (Base * (16320 + 2 * Q)) := by ring
    _ ≤ C * configMatchPolyFactor d L_p2 R ℓ b T_cdf p_coord M_lat := by
        apply Nat.mul_le_mul_left C
        unfold configMatchPolyFactor
        dsimp only [Base, Q]
        apply Nat.mul_le_mul_left
        linarith

theorem configMatchRAMOps_deleteCost_le :
    (configMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl).deleteCost ≤
    (1 + cap_u + cap_q + R * ℓ * M₀) *
      configMatchPolyFactor d L_p2 R ℓ b T_cdf p_coord M_lat := by
  let sops := mkSideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
    scrW scrR tblW tblR coinTbl
  let C := 1 + cap_u + cap_q + R * ℓ * M₀
  let Base := (L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) * (M_lat + 1)
  let Q := 2250 + 60 * b + (T_cdf + p_coord + 6) * (120 + 48 * cdfDegree T_cdf b)
  have hC_pos : 1 ≤ C := by dsimp [C]; omega
  have hBase_pos : 1 ≤ Base :=
    Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.succ_pos _) (Nat.succ_pos _))
      (Nat.succ_pos _)) (Nat.succ_pos _)) (Nat.succ_pos _)
  have hBase_ge_LR : (L_p2 + 1) * (R + 1) ≤ Base := by
    have hp : 1 ≤ (ℓ + 1) * (d + 1) * (M_lat + 1) :=
      Nat.mul_pos (Nat.mul_pos (Nat.succ_pos _) (Nat.succ_pos _)) (Nat.succ_pos _)
    calc (L_p2 + 1) * (R + 1) = ((L_p2 + 1) * (R + 1)) * 1 := by ring
      _ ≤ ((L_p2 + 1) * (R + 1)) * ((ℓ + 1) * (d + 1) * (M_lat + 1)) := Nat.mul_le_mul_left _ hp
      _ = Base := by dsimp [Base]; ring
  have hBase_ge_LRLd : (L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1) ≤ Base :=
    Nat.le_mul_of_pos_right _ (Nat.succ_pos M_lat)
  have hhd : 2700 ≤ C * (Base * 2700) := by
    have h1 : 2700 ≤ Base * 2700 := Nat.le_mul_of_pos_left 2700 hBase_pos
    exact le_trans h1 (Nat.le_mul_of_pos_left _ hC_pos)
  have hqry : 2 * sops.queryCost ≤ C * (Base * 13000) := by
    have hq := mkSideRAMOps_queryCost_sublinear_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl
    calc 2 * sops.queryCost ≤ 2 * (C * (Base * 6500)) := Nat.mul_le_mul_left 2 hq
      _ = C * (Base * 13000) := by ring
  have hins : 2 * sops.insertCost ≤ C * (Base * (2 * Q)) := by
    have hi := mkSideRAMOps_insertCost_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl
    have hi' : ((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1)) * Q ≤ Base * Q :=
      Nat.mul_le_mul_right Q hBase_ge_LRLd
    calc 2 * sops.insertCost
        ≤ 2 * (C * (((L_p2 + 1) * (R + 1) * (ℓ + 1) * (d + 1)) * Q)) := Nat.mul_le_mul_left 2 hi
      _ ≤ 2 * (C * (Base * Q)) := Nat.mul_le_mul_left 2 (Nat.mul_le_mul_left C hi')
      _ = C * (Base * (2 * Q)) := by ring
  have hrem : 4 * sops.removeCost ≤ C * (Base * 3200) := by
    have hr := mkSideRAMOps_removeCost_le d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl
    have hr' : 800 * (L_p2 + 1) * (R + 1) ≤ Base * 800 := by
      calc 800 * (L_p2 + 1) * (R + 1) = ((L_p2 + 1) * (R + 1)) * 800 := by ring
        _ ≤ Base * 800 := Nat.mul_le_mul_right 800 hBase_ge_LR
    calc 4 * sops.removeCost ≤ 4 * (C * (800 * (L_p2 + 1) * (R + 1))) := Nat.mul_le_mul_left 4 hr
      _ ≤ 4 * (C * (Base * 800)) := Nat.mul_le_mul_left 4 (Nat.mul_le_mul_left C hr')
      _ = C * (Base * 3200) := by ring
  have hmain := mkConfigMatchRAMOps_deleteCost_le params h sops
  unfold configMatchRAMOps
  calc (mkConfigMatchRAMOps params h sops).deleteCost
      ≤ 2700 + 2 * sops.queryCost + 2 * sops.insertCost + 4 * sops.removeCost := hmain
    _ ≤ C * (Base * 2700) + C * (Base * 13000) + C * (Base * (2 * Q)) + C * (Base * 3200) :=
        Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hhd hqry) hins) hrem
    _ = C * (Base * (18900 + 2 * Q)) := by ring
    _ ≤ C * configMatchPolyFactor d L_p2 R ℓ b T_cdf p_coord M_lat := by
        apply Nat.mul_le_mul_left C
        unfold configMatchPolyFactor
        dsimp only [Base, Q]
        apply Nat.mul_le_mul_left
        linarith

end ConcreteBounds

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
