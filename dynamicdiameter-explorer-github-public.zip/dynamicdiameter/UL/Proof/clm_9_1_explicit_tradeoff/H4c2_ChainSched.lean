import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.lem_5_1
import UL.Stmt.lem_5_5
import UL.Stmt.clm_5_1_mc_baseline
import UL.Stmt.clm_7_3_global_approx
import UL.Proof.cit_hpj19_thm18.H0
import UL.Proof.cit_hpj19_thm18.H1
import UL.Proof.cit_hpj19_thm18.H2
import UL.Proof.cit_hpj19_thm18.H3
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
import UL.Proof.clm_9_1_explicit_tradeoff.H3b2_GaussRAM
import UL.Proof.clm_9_1_explicit_tradeoff.H4a1_FilterPure
import UL.Proof.clm_9_1_explicit_tradeoff.H4b_DyadicMatching
import UL.Proof.clm_9_1_explicit_tradeoff.H4c1_NodePrim
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H4c2

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1

/-! ### 1. Exact Integer Reciprocal `K_alpha`, Chain Input Pointwise Characterization & Contraction -/

def K_alpha (d : ℕ) : ℕ :=
  4 * (d + 3) ^ 2

theorem K_alpha_ge_36 (d : ℕ) : 36 ≤ K_alpha d := by
  unfold K_alpha
  have h3 : 3 ≤ d + 3 := by omega
  nlinarith only [h3]

theorem K_alpha_pos (d : ℕ) : 0 < K_alpha d := by
  have := K_alpha_ge_36 d; omega

theorem hpjAlpha_eq_inv_K_alpha (d : ℕ) :
    hpjAlpha d = 1 / (K_alpha d : ℝ) := by
  unfold hpjAlpha K_alpha
  push_cast
  ring

theorem hpjAlpha_pos (d : ℕ) : 0 < hpjAlpha d := by
  rw [hpjAlpha_eq_inv_K_alpha]
  have hpos : (0 : ℝ) < (K_alpha d : ℝ) := Nat.cast_pos.mpr (K_alpha_pos d)
  exact one_div_pos.mpr hpos

theorem hpjAlpha_le_one (d : ℕ) : hpjAlpha d ≤ 1 := by
  rw [hpjAlpha_eq_inv_K_alpha]
  have hge : (1 : ℝ) ≤ (K_alpha d : ℝ) := by
    have := K_alpha_ge_36 d
    exact_mod_cast (by omega : 1 ≤ K_alpha d)
  exact div_le_one_of_le₀ hge (by positivity)

theorem age_real_le_of_int {d age m : ℕ} (h : 16 * K_alpha d * age ≤ m) :
    (age : ℝ) ≤ hpjAlpha d * (m : ℝ) / 16 := by
  rw [hpjAlpha_eq_inv_K_alpha]
  have hK : (0 : ℝ) < (K_alpha d : ℝ) := Nat.cast_pos.mpr (K_alpha_pos d)
  have hr : (16 : ℝ) * (K_alpha d : ℝ) * (age : ℝ) ≤ (m : ℝ) := by exact_mod_cast h
  rw [le_div_iff₀ (by positivity)]
  rw [one_div_mul_eq_div, le_div_iff₀ hK]
  linarith only [hr]

theorem alpha_mul_gt_one_of_gt {d m : ℕ} (h : K_alpha d < m) :
    1 < hpjAlpha d * (m : ℝ) := by
  rw [hpjAlpha_eq_inv_K_alpha, one_div_mul_eq_div]
  have hK : (0 : ℝ) < (K_alpha d : ℝ) := Nat.cast_pos.mpr (K_alpha_pos d)
  rw [ one_lt_div hK ]
  exact_mod_cast h

/-- Boolean core-ball membership test via squared Euclidean distance `‖pt - o‖^2 ≤ V`. -/
noncomputable def inCoreBall {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) (V : ℝ) (pt : EuclideanSpace ℝ (Fin d)) : Bool :=
  open Classical in
  decide (‖pt - o‖ ^ 2 ≤ V)

theorem inCoreBall_eq_true_iff {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 ≤ V) (pt : EuclideanSpace ℝ (Fin d)) :
    inCoreBall o V pt = true ↔ pt ∈ coreBall o V := by
  unfold inCoreBall
  rw [decide_eq_true_eq, ← coreBall_iff_sq o pt hV]

theorem inCoreBall_eq_false_iff {d : ℕ}
    (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 ≤ V) (pt : EuclideanSpace ℝ (Fin d)) :
    inCoreBall o V pt = false ↔ pt ∉ coreBall o V := by
  rw [Bool.eq_false_iff, Ne, inCoreBall_eq_true_iff o hV pt]

/-- Pointwise test whether coordinate `pt` lies outside the cores of all nodes in `nds`. -/
noncomputable def passesNodeList {d : ℕ}
    (nds : List (ChainNode d)) (pt : EuclideanSpace ℝ (Fin d)) : Bool :=
  nds.all (fun N => !inCoreBall N.o N.V pt)

theorem chainInput_zero {d : ℕ} {k : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ℕ) :
    chainInput pts nodes P ⟨0, Nat.zero_lt_succ k⟩ = P := rfl

theorem chainInput_succ_eq {d : ℕ} {k : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ℕ)
    (i : Fin k) :
    chainInput pts nodes P i.succ =
      (nodes i).residual pts (chainInput pts nodes P i.castSucc) := rfl

/-- Exact pointwise characterization of `chainInput`: `x` reaches depth `j` iff `x ∈ P` and `pts x`
avoids the cores of all `nodes 0, ..., nodes (j - 1)`. -/
theorem mem_chainInput_iff {d : ℕ} {k : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ℕ)
    (j : Fin (k + 1)) (x : ℕ) :
    x ∈ chainInput pts nodes P j ↔
      x ∈ P ∧ ∀ i : Fin k, i.val < j.val → pts x ∉ coreBall (nodes i).o (nodes i).V := by
  classical
  rcases j with ⟨m, hm⟩
  induction m with
  | zero =>
      change x ∈ P ↔ x ∈ P ∧ ∀ i : Fin k, i.val < 0 → _
      simp
  | succ m ih =>
      have hm_k : m < k := Nat.lt_of_succ_lt_succ hm
      let i_m : Fin k := ⟨m, hm_k⟩
      have hstep : chainInput pts nodes P ⟨m + 1, hm⟩ =
          (nodes i_m).residual pts (chainInput pts nodes P i_m.castSucc) := rfl
      rw [hstep]
      unfold ChainNode.residual nodeResidual nodeCore
      have hcs : i_m.castSucc = ⟨m, Nat.lt_of_succ_lt hm⟩ := rfl
      rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter, hcs, ih (Nat.lt_of_succ_lt hm)]
      dsimp only
      constructor
      · rintro ⟨⟨hxP, hprev⟩, hnot_m⟩
        refine ⟨hxP, fun i hi => ?_⟩
        by_cases heq : i.val = m
        · have hi_eq : i = i_m := Fin.ext heq
          rw [hi_eq]
          exact fun hcb => hnot_m ⟨⟨hxP, hprev⟩, hcb⟩
        · exact hprev i (by omega)
      · rintro ⟨hxP, hall⟩
        refine ⟨⟨hxP, fun i hi => hall i (by omega)⟩, fun hh => ?_⟩
        exact hall i_m (Nat.lt_succ_self m) hh.2

/-- `D_max`-step geometric contraction: if `k = 4 * K_alpha d * (Nat.clog 2 (n + 2) + 2)`,
`P.card ≤ n`, and every level contracts by `(1 - hpjAlpha d / 2)`, then `chainTerminal = ∅`! -/
theorem chainTerminal_empty_of_full_depth {d n k : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (nodes : Fin k → ChainNode d) (P : Finset ℕ)
    (hcard_le : P.card ≤ n)
    (hk_ge : 4 * K_alpha d * (Nat.clog 2 (n + 2) + 2) ≤ k)
    (hcontract : ∀ i : Fin k,
      (((chainInput pts nodes P i.succ).card : ℝ)) ≤
        (1 - hpjAlpha d / 2) * ((chainInput pts nodes P i.castSucc).card : ℝ)) :
    chainTerminal pts nodes P = ∅ := by
  have h1_sub_nn : 0 ≤ 1 - hpjAlpha d / 2 := by
    have := hpjAlpha_le_one d; linarith only [this]
  have hpow_step : ∀ (m : ℕ) (hm : m ≤ k),
      ((chainInput pts nodes P ⟨m, Nat.lt_succ_of_le hm⟩).card : ℝ) ≤
        (1 - hpjAlpha d / 2) ^ m * (P.card : ℝ) := by
    intro m hm
    induction m with
    | zero => change (P.card : ℝ) ≤ _; simp
    | succ m ih =>
        have hstep := hcontract ⟨m, Nat.lt_of_succ_le hm⟩
        have hih := ih (Nat.le_of_succ_le hm)
        calc ((chainInput pts nodes P ⟨m + 1, Nat.lt_succ_of_le hm⟩).card : ℝ)
            ≤ (1 - hpjAlpha d / 2) * ((chainInput pts nodes P ⟨m, _⟩).card : ℝ) := hstep
          _ ≤ (1 - hpjAlpha d / 2) * ((1 - hpjAlpha d / 2) ^ m * (P.card : ℝ)) :=
              mul_le_mul_of_nonneg_left hih h1_sub_nn
          _ = (1 - hpjAlpha d / 2) ^ (m + 1) * (P.card : ℝ) := by rw [pow_succ']; ring
  have hk_bound := hpow_step k le_rfl
  -- Use `1 - x ≤ Real.exp (-x)` -> `(1 - α/2)^k ≤ exp(- k * α / 2) ≤ exp(- 2 * (clog + 2)) < 1 / (n + 2)`!
  have hexp_one : 1 - hpjAlpha d / 2 ≤ Real.exp (-(hpjAlpha d / 2)) := by
    have := Real.add_one_le_exp (-(hpjAlpha d / 2))
    linarith only [this]
  have hpow_exp : (1 - hpjAlpha d / 2) ^ k ≤ Real.exp (-(k : ℝ) * (hpjAlpha d / 2)) := by
    calc (1 - hpjAlpha d / 2) ^ k
        ≤ (Real.exp (-(hpjAlpha d / 2))) ^ k := pow_le_pow_left₀ h1_sub_nn hexp_one k
      _ = Real.exp ((k : ℝ) * (-(hpjAlpha d / 2))) := (Real.exp_nat_mul (-(hpjAlpha d / 2)) k).symm
      _ = Real.exp (-(k : ℝ) * (hpjAlpha d / 2)) := by congr 1; ring
  let L_c := Nat.clog 2 (n + 2)
  have hk_alpha_ge : (2 * ((L_c + 2 : ℕ) : ℝ)) ≤ (k : ℝ) * (hpjAlpha d / 2) := by
    rw [hpjAlpha_eq_inv_K_alpha]
    have hK_pos : (0 : ℝ) < (K_alpha d : ℝ) := Nat.cast_pos.mpr (K_alpha_pos d)
    have hk_r : (4 : ℝ) * (K_alpha d : ℝ) * ((L_c + 2 : ℕ) : ℝ) ≤ (k : ℝ) := by exact_mod_cast hk_ge
    calc (2 * ((L_c + 2 : ℕ) : ℝ))
        = (4 * (K_alpha d : ℝ) * ((L_c + 2 : ℕ) : ℝ)) * ((1 / (K_alpha d : ℝ)) / 2) := by
            field_simp [hK_pos.ne']; ring
      _ ≤ (k : ℝ) * ((1 / (K_alpha d : ℝ)) / 2) :=
            mul_le_mul_of_nonneg_right hk_r (by positivity)
  have hexp_le : Real.exp (-(k : ℝ) * (hpjAlpha d / 2)) ≤ Real.exp (-(2 * ((L_c + 2 : ℕ) : ℝ))) :=
    Real.exp_le_exp.mpr (by linarith only [hk_alpha_ge])
  have h2_le_exp2 : (2 : ℝ) ≤ Real.exp 2 := by
    have := Real.add_one_le_exp (2 : ℝ)
    linarith only [this]
  have hpow2_le : ((2 ^ (L_c + 2) : ℕ) : ℝ) ≤ Real.exp (2 * ((L_c + 2 : ℕ) : ℝ)) := by
    rw [Nat.cast_pow, Nat.cast_ofNat]
    calc (2 : ℝ) ^ (L_c + 2)
        ≤ (Real.exp 2) ^ (L_c + 2) := pow_le_pow_left₀ (by positivity) h2_le_exp2 _
      _ = Real.exp (((L_c + 2 : ℕ) : ℝ) * 2) := (Real.exp_nat_mul (2 : ℝ) (L_c + 2)).symm
      _ = Real.exp (2 * ((L_c + 2 : ℕ) : ℝ)) := by congr 1; ring
  have hn_lt_pow : n + 1 ≤ 2 ^ (L_c + 2) := by
    have hclog : n + 2 ≤ 2 ^ L_c := Nat.le_pow_clog (by decide) (n + 2)
    have h4 : 2 ^ L_c ≤ 2 ^ (L_c + 2) := Nat.pow_le_pow_right (by decide) (by omega)
    omega
  have hexp_inv_lt : Real.exp (-(2 * ((L_c + 2 : ℕ) : ℝ))) * (P.card : ℝ) < 1 := by
    rw [Real.exp_neg]
    have hexp_pos : 0 < Real.exp (2 * ((L_c + 2 : ℕ) : ℝ)) := Real.exp_pos _
    rw [inv_mul_lt_iff₀ hexp_pos, mul_one]
    have hP_lt : (P.card : ℝ) < ((2 ^ (L_c + 2) : ℕ) : ℝ) := by
      have : P.card < 2 ^ (L_c + 2) := by omega
      exact_mod_cast this
    exact lt_of_lt_of_le hP_lt hpow2_le
  have hterm_lt_one : ((chainTerminal pts nodes P).card : ℝ) < 1 := by
    unfold chainTerminal Fin.last
    calc ((chainInput pts nodes P ⟨k, Nat.lt_succ_self k⟩).card : ℝ)
        ≤ (1 - hpjAlpha d / 2) ^ k * (P.card : ℝ) := hk_bound
      _ ≤ Real.exp (-(k : ℝ) * (hpjAlpha d / 2)) * (P.card : ℝ) :=
            mul_le_mul_of_nonneg_right hpow_exp (Nat.cast_nonneg _)
      _ ≤ Real.exp (-(2 * ((L_c + 2 : ℕ) : ℝ))) * (P.card : ℝ) :=
            mul_le_mul_of_nonneg_right hexp_le (Nat.cast_nonneg _)
      _ < 1 := hexp_inv_lt
  have hcard0 : (chainTerminal pts nodes P).card = 0 := by
    have hlt : (chainTerminal pts nodes P).card < 1 := by exact_mod_cast hterm_lt_one
    omega
  exact Finset.card_eq_zero.mp hcard0

/-! ### 2. `ManagedNode` (`NodeInst` + Append-Only `histArr` + Incremental `resArr`) -/

/-- `NodeInst` augmented with its monotonic insertion history `histArr` (for `O(B_scan)` Phase 0
snapshot scanning) and incrementally maintained residual list `resArr` (for `O(1)` residual access). -/
structure ManagedNode (L_p2 R ℓ M₀ d b N_cfg : ℕ) where
  nd : NodeInst L_p2 R ℓ M₀ d b N_cfg
  histArr : List ℕ
  resArr : List ℕ

noncomputable def ManagedNode.openEmpty (L_p2 R ℓ M₀ d b N_cfg T p_coord : ℕ)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (P₀ : Finset ℕ) (m₀ : ℕ) :
    ManagedNode L_p2 R ℓ M₀ d b N_cfg :=
  { nd := NodeInst.openEmpty L_p2 R ℓ M₀ d b N_cfg T p_coord o s P₀ m₀
    histArr := []
    resArr := [] }

noncomputable def ManagedNode.insertMat {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (p : ℕ)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) : ManagedNode L_p2 R ℓ M₀ d b N_cfg :=
  { nd := mn.nd.insertMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω
    histArr := mn.histArr ++ [p]
    resArr := if inCoreBall mn.nd.o mn.nd.V (pts p) then mn.resArr else denseInsert p mn.resArr }

noncomputable def ManagedNode.deleteMat {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (hM₀ : 1 ≤ M₀) (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (p : ℕ)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) : ManagedNode L_p2 R ℓ M₀ d b N_cfg :=
  { nd := mn.nd.deleteMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω
    histArr := mn.histArr
    resArr := if inCoreBall mn.nd.o mn.nd.V (pts p) then mn.resArr else denseDelete p mn.resArr }

def ManagedNode.bumpAge {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) : ManagedNode L_p2 R ℓ M₀ d b N_cfg :=
  { mn with nd := { mn.nd with age := mn.nd.age + 1 } }

def ManagedNodeWF {L_p2 R ℓ M₀ d b N_cfg : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d : ℚ) (cap_u : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg) : Prop :=
  NodeInstMatWF hM₀ T p_coord params specs τ_d cap_u pts mn.nd ∧
  mn.resArr.Nodup ∧
  mn.resArr.toFinset = nodeResidual pts mn.nd.o mn.nd.V mn.nd.curSet ∧
  mn.nd.curSet ⊆ mn.histArr.toFinset

theorem managedNode_openEmpty_spec {L_p2 R ℓ M₀ d b N_cfg : ℕ} (hM₀ : 1 ≤ M₀)
    (T p_coord M_lat : ℕ) (params : LocalScaleParams)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ) (P₀ : Finset ℕ) :
    let mn := ManagedNode.openEmpty L_p2 R ℓ M₀ d b N_cfg T p_coord o s P₀ P₀.card
    mn.nd.curSet = ∅ ∧
    mn.histArr = [] ∧
    mn.resArr = [] ∧
    mn.nd.maxTIns 0 ∧
    ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts mn ∧
    NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts mn.nd := by
  rcases nodeInst_openEmpty_spec hM₀ T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q
    pts o s P₀ with ⟨hcur, ht0, hwf, hgd⟩
  refine ⟨hcur, rfl, rfl, ht0, ⟨hwf, List.nodup_nil, ?_, ?_⟩, hgd⟩
  · dsimp only [ManagedNode.openEmpty]; rw [hcur]; ext x; simp [nodeResidual, nodeCore]
  · dsimp only [ManagedNode.openEmpty]; rw [hcur]; exact Finset.empty_subset _

theorem managedNode_pts_congr {L_p2 R ℓ M₀ d b N_cfg : ℕ} {hM₀ : 1 ≤ M₀}
    {T p_coord M_lat : ℕ} {params : LocalScaleParams}
    {h : ℝ} {specs : Fin N_cfg → ConfigStaticSpec d params h}
    {τ_d τ_q : ℚ} (hh0 : 0 < h) (hh1 : h < 1) {cap_u cap_q : ℕ}
    {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg}
    (heq : ∀ x ∈ mn.nd.curSet, pts' x = pts x)
    (hwf : ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts mn) :
    ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts' mn ∧
    (NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts mn.nd →
      NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts' mn.nd) := by
  rcases nodeInst_pts_congr hh0 hh1 heq hwf.1 with ⟨hwf_nd', hgd_imp⟩
  refine ⟨⟨hwf_nd', hwf.2.1, hwf.2.2.1.trans ?_, hwf.2.2.2⟩, hgd_imp⟩
  ext x
  unfold nodeResidual nodeCore
  simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter]
  constructor <;> (rintro ⟨hx, hnc⟩; refine ⟨hx, ?_⟩; rintro ⟨_, hcb⟩; apply hnc ⟨hx, ?_⟩)
  · rwa [← heq x hx]
  · rwa [heq x hx]

theorem managedNode_insertMat_spec {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams) (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg}
    {p : ℕ} (hp : p ∉ mn.nd.curSet)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    {bound : ℕ} (ht_bnd : mn.nd.maxTIns bound) (hcap : bound + 1 < 2 ^ L_p2)
    (hwf : ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts mn) :
    let M_lat := M_lat_of d params.e
    let mn' := mn.insertMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω
    mn'.nd.o = mn.nd.o ∧ mn'.nd.s = mn.nd.s ∧ mn'.nd.V = mn.nd.V ∧
    mn'.nd.birthSet = mn.nd.birthSet ∧ mn'.nd.birthSize = mn.nd.birthSize ∧ mn'.nd.age = mn.nd.age ∧
    mn'.nd.curSet = insert p mn.nd.curSet ∧
    mn'.histArr = mn.histArr ++ [p] ∧
    mn'.nd.maxTIns (bound + 1) ∧
    ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts mn' ∧
    (NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts mn.nd →
     NodeOpSeedGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q mn.nd ω →
     NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts mn'.nd) := by
  let M_lat := M_lat_of d params.e
  rcases hwf with ⟨hwf_nd, hres_nd, hres_eq, hhist_sub⟩
  rcases nodeInst_insertMat_spec h_clm_7_3 hd hM₀ T p_coord params he1 specs τ_d τ_q hh0 hh1
    cap_u cap_q hp ω ht_bnd hcap hwf_nd
    with ⟨ho, hs, hV, hbS, hbsz, hage, hcur', ht', hwf_nd', hgd_imp⟩
  have hV_nn : 0 ≤ mn.nd.V := le_max_left _ _
  refine ⟨ho, hs, hV, hbS, hbsz, hage, hcur', rfl, ht', ⟨hwf_nd', ?_, ?_, ?_⟩, hgd_imp⟩
  · dsimp only [ManagedNode.insertMat]
    split_ifs with hcb
    · exact hres_nd
    · have hp_not_res : p ∉ mn.resArr.toFinset := by
        rw [hres_eq]; unfold nodeResidual
        rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)]
        exact fun hh => hp hh.1
      exact (denseInsert_spec hres_nd hp_not_res).1
  · dsimp only [ManagedNode.insertMat]
    rw [ho, hV, hcur']
    by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts p) = true
    · rw [if_pos hcb, hres_eq]
      have hp_in_cb : pts p ∈ coreBall mn.nd.o mn.nd.V :=
        (inCoreBall_eq_true_iff mn.nd.o hV_nn (pts p)).mp hcb
      ext x
      unfold nodeResidual nodeCore
      simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro ⟨hx, hnc⟩
        refine ⟨Or.inr hx, fun hh => hnc ⟨hx, hh.2⟩⟩
      · rintro ⟨rfl | hx, hnc⟩
        · exact absurd ⟨Or.inl rfl, hp_in_cb⟩ hnc
        · exact ⟨hx, fun hh => hnc ⟨Or.inr hx, hh.2⟩⟩
    · rw [if_neg hcb]
      have hp_not_res : p ∉ mn.resArr.toFinset := by
        rw [hres_eq]; unfold nodeResidual
        rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)]
        exact fun hh => hp hh.1
      rw [(denseInsert_spec hres_nd hp_not_res).2, hres_eq]
      have hp_not_cb : pts p ∉ coreBall mn.nd.o mn.nd.V :=
        (inCoreBall_eq_false_iff mn.nd.o hV_nn (pts p)).mp (Bool.eq_false_iff.mpr hcb)
      ext x
      unfold nodeResidual nodeCore
      simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter, Finset.mem_insert]
      constructor
      · rintro (rfl | ⟨hx, hnc⟩)
        · exact ⟨Or.inl rfl, fun hh => hp_not_cb hh.2⟩
        · exact ⟨Or.inr hx, fun hh => hnc ⟨hx, hh.2⟩⟩
      · rintro ⟨rfl | hx, hnc⟩
        · exact Or.inl rfl
        · exact Or.inr ⟨hx, fun hh => hnc ⟨Or.inr hx, hh.2⟩⟩
  · dsimp only [ManagedNode.insertMat]
    rw [hcur']
    intro x hx
    rw [List.toFinset_append]
    rcases Finset.mem_insert.mp hx with rfl | hx_old
    · exact Finset.mem_union_right _ (by simp)
    · exact Finset.mem_union_left _ (hhist_sub hx_old)

theorem managedNode_deleteMat_spec {L_p2 R ℓ M₀ d b N_cfg : ℕ}
    (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (hM₀ : 1 ≤ M₀)
    (T p_coord : ℕ) (params : LocalScaleParams) (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (τ_d τ_q : ℚ) (hh0 : 0 < h) (hh1 : h < 1) (cap_u cap_q : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg}
    {p : ℕ} (hp : p ∈ mn.nd.curSet)
    (ω : NodeOpSeed N_cfg L_p2 R ℓ M₀ d b)
    {bound : ℕ} (ht_bnd : mn.nd.maxTIns bound) (hcap : bound + 1 < 2 ^ L_p2)
    (hwf : ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts mn) :
    let M_lat := M_lat_of d params.e
    let mn' := mn.deleteMat hM₀ T p_coord M_lat params specs τ_d τ_q cap_u cap_q pts p ω
    mn'.nd.o = mn.nd.o ∧ mn'.nd.s = mn.nd.s ∧ mn'.nd.V = mn.nd.V ∧
    mn'.nd.birthSet = mn.nd.birthSet ∧ mn'.nd.birthSize = mn.nd.birthSize ∧ mn'.nd.age = mn.nd.age ∧
    mn'.nd.curSet = mn.nd.curSet.erase p ∧
    mn'.histArr = mn.histArr ∧
    mn'.nd.maxTIns (bound + 1) ∧
    ManagedNodeWF hM₀ T p_coord params specs τ_d cap_u pts mn' ∧
    (NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts mn.nd →
     NodeOpSeedGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q mn.nd ω →
     NodeInstMatGood T p_coord M_lat params specs τ_d τ_q hh0 hh1 cap_u cap_q pts mn'.nd) := by
  let M_lat := M_lat_of d params.e
  rcases hwf with ⟨hwf_nd, hres_nd, hres_eq, hhist_sub⟩
  rcases nodeInst_deleteMat_spec h_clm_7_3 hd hM₀ T p_coord params he1 specs τ_d τ_q hh0 hh1
    cap_u cap_q hp ω ht_bnd hcap hwf_nd
    with ⟨ho, hs, hV, hbS, hbsz, hage, hcur', ht', hwf_nd', hgd_imp⟩
  have hV_nn : 0 ≤ mn.nd.V := le_max_left _ _
  refine ⟨ho, hs, hV, hbS, hbsz, hage, hcur', rfl, ht', ⟨hwf_nd', ?_, ?_, ?_⟩, hgd_imp⟩
  · dsimp only [ManagedNode.deleteMat]
    split_ifs with hcb
    · exact hres_nd
    · exact (denseDelete_spec hres_nd).1
  · dsimp only [ManagedNode.deleteMat]
    rw [ho, hV, hcur']
    by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts p) = true
    · rw [if_pos hcb, hres_eq]
      have hp_in_cb : pts p ∈ coreBall mn.nd.o mn.nd.V :=
        (inCoreBall_eq_true_iff mn.nd.o hV_nn (pts p)).mp hcb
      ext x
      unfold nodeResidual nodeCore
      simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter, Finset.mem_erase]
      constructor
      · rintro ⟨hx, hnc⟩
        have hne : x ≠ p := fun heq => hnc ⟨hx, heq ▸ hp_in_cb⟩
        exact ⟨⟨hne, hx⟩, fun hh => hnc ⟨hx, hh.2⟩⟩
      · rintro ⟨⟨_, hx⟩, hnc⟩
        exact ⟨hx, fun hh => hnc ⟨⟨fun heq => hnc ⟨⟨by omega, hx⟩, hh.2⟩, hx⟩, hh.2⟩⟩
    · rw [if_neg hcb, (denseDelete_spec hres_nd).2, hres_eq]
      ext x
      unfold nodeResidual nodeCore
      simp only [@Finset.mem_sdiff ℕ (Classical.decEq ℕ), Finset.mem_filter, Finset.mem_erase]
      constructor
      · rintro ⟨hne, hx, hnc⟩
        exact ⟨⟨hne, hx⟩, fun hh => hnc ⟨hx, hh.2⟩⟩
      · rintro ⟨⟨hne, hx⟩, hnc⟩
        exact ⟨hne, hx, fun hh => hnc ⟨⟨hne, hx⟩, hh.2⟩⟩
  · dsimp only [ManagedNode.deleteMat]
    rw [hcur']
    exact (Finset.erase_subset p mn.nd.curSet).trans hhist_sub

/-! ### 3. HPJ19 Center Evaluator & Query Candidate Selector -/

abbrev HPJCoin (N_samp q_idx B_walk : ℕ) : Type :=
  (Fin N_samp → Fin (2 ^ q_idx)) × (Fin B_walk → Bool)

noncomputable def evalHPJCenter {d : ℕ} (P_hpj : HPJParams) (N_samp q_idx : ℕ)
    (hmN : 2 ^ P_hpj.q ≤ N_samp)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (arr : List ℕ)
    (cw : HPJCoin N_samp q_idx (P_hpj.L * (d + 1 + 3) * P_hpj.q)) :
    EuclideanSpace ℝ (Fin d) × ℝ :=
  if hsz : 1 ≤ arr.length then
    let ω₀ : Fin (2 ^ P_hpj.q) → Fin arr.length := fun j =>
      ⟨(cw.1 ⟨j.val, lt_of_lt_of_le j.isLt hmN⟩).val % arr.length, Nat.mod_lt _ hsz⟩
    let z := radonWalkOutput (d + 1) P_hpj.q P_hpj.L
      (fun j => paraboloidLift (pts arr[(ω₀ j).val])) cw.2
    (liftedBase z, liftedHeight z)
  else
    (0, 0)

theorem liftedPoint_liftedBase_liftedHeight {d : ℕ} (z : EuclideanSpace ℝ (Fin (d + 1))) :
    liftedPoint (liftedBase z) (liftedHeight z) = z := by
  unfold liftedPoint liftedBase liftedHeight
  ext i
  change Fin.snoc (Fin.init (WithLp.ofLp z)) (z (Fin.last d)) i = z i
  exact congrFun (Fin.snoc_init_self (WithLp.ofLp z)) i

/-- Exact pairwise scan over a duplicate-free list `leafArr` (`IsExactLeafAnswer`). -/
noncomputable def evalExactLeafPair {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (leafArr : List ℕ) : Option (ℕ × ℕ) :=
  open Classical in
  if leafArr.length ≤ 1 then
    none
  else
    let pairs : List (ℕ × ℕ) :=
      leafArr.flatMap (fun u => (leafArr.filter (· ≠ u)).map (fun v => (u, v)))
    match pairs with
    | [] => none
    | p₀ :: rest =>
        some <| rest.foldl
          (fun best p =>
            if ‖pts best.1 - pts best.2‖ ^ 2 < ‖pts p.1 - pts p.2‖ ^ 2 then p else best)
          p₀

theorem evalExactLeafPair_spec {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) {leafArr : List ℕ} (hnd : leafArr.Nodup) :
    IsExactLeafAnswer pts leafArr.toFinset (evalExactLeafPair pts leafArr) := by
  have hlen_card : leafArr.length = leafArr.toFinset.card :=
    (List.toFinset_card_of_nodup hnd).symm
  unfold evalExactLeafPair IsExactLeafAnswer
  by_cases hle1 : leafArr.length ≤ 1
  · rw [if_pos hle1]
    have hcard_le1 : leafArr.toFinset.card ≤ 1 := by omega
    rw [if_pos hcard_le1]
  · rw [if_neg hle1]
    have hcard_gt1 : ¬ leafArr.toFinset.card ≤ 1 := by omega
    rw [if_neg hcard_gt1]
    set pairs : List (ℕ × ℕ) :=
      leafArr.flatMap (fun u => (leafArr.filter (· ≠ u)).map (fun v => (u, v)))
    have hpairs_mem : ∀ u v : ℕ, (u, v) ∈ pairs ↔ u ∈ leafArr ∧ v ∈ leafArr ∧ v ≠ u := by
      intro u v
      simp [pairs]
    have hge2 : 2 ≤ leafArr.length := by omega
    have h01_ne : leafArr[1]'(by omega) ≠ leafArr[0]'(by omega) := by
      intro heq
      have hidx := (List.Nodup.getElem_inj_iff hnd).mp heq
      omega
    have hpairs_ne : pairs ≠ [] := by
      intro hemp
      have hm : (leafArr[0]'(by omega), leafArr[1]'(by omega)) ∈ pairs :=
        (hpairs_mem _ _).mpr ⟨List.getElem_mem _, List.getElem_mem _, h01_ne⟩
      rw [hemp] at hm
      exact List.not_mem_nil hm
    cases hp_eq : pairs with
    | nil => exact absurd hp_eq hpairs_ne
    | cons p₀ rest =>
        dsimp only
        have hfold_spec : ∀ (init : ℕ × ℕ) (ls : List (ℕ × ℕ)),
            (init ∈ p₀ :: rest) → (∀ p ∈ ls, p ∈ p₀ :: rest) →
            let ans := ls.foldl
              (fun best p => open Classical in
                if ‖pts best.1 - pts best.2‖ ^ 2 < ‖pts p.1 - pts p.2‖ ^ 2 then p else best) init
            ans ∈ p₀ :: rest ∧
            ‖pts init.1 - pts init.2‖ ^ 2 ≤ ‖pts ans.1 - pts ans.2‖ ^ 2 ∧
            ∀ p ∈ ls, ‖pts p.1 - pts p.2‖ ^ 2 ≤ ‖pts ans.1 - pts ans.2‖ ^ 2 := by
          intro init ls
          induction ls generalizing init with
          | nil =>
              intro hinit _
              exact ⟨hinit, le_rfl, fun _ h => absurd h List.not_mem_nil⟩
          | cons q qs ih =>
              intro hinit hls
              dsimp only [List.foldl_cons]
              set nxt : ℕ × ℕ := open Classical in
                if ‖pts init.1 - pts init.2‖ ^ 2 < ‖pts q.1 - pts q.2‖ ^ 2 then q else init
              have hnxt_mem : nxt ∈ p₀ :: rest := by
                dsimp only [nxt]; split_ifs
                · exact hls q List.mem_cons_self
                · exact hinit
              rcases ih nxt hnxt_mem (fun x hx => hls x (List.mem_cons_of_mem q hx))
                with ⟨hans_mem, hnxt_le, hqs_le⟩
              have hinit_nxt : ‖pts init.1 - pts init.2‖ ^ 2 ≤ ‖pts nxt.1 - pts nxt.2‖ ^ 2 := by
                dsimp only [nxt]; split_ifs with hlt
                · exact hlt.le
                · exact le_rfl
              have hq_nxt : ‖pts q.1 - pts q.2‖ ^ 2 ≤ ‖pts nxt.1 - pts nxt.2‖ ^ 2 := by
                dsimp only [nxt]; split_ifs with hlt
                · exact le_rfl
                · exact not_lt.mp hlt
              refine ⟨hans_mem, hinit_nxt.trans hnxt_le, fun x hx => ?_⟩
              rcases List.mem_cons.mp hx with rfl | hx_qs
              · exact hq_nxt.trans hnxt_le
              · exact hqs_le x hx_qs
        rcases hfold_spec p₀ rest List.mem_cons_self (fun x hx => List.mem_cons_of_mem p₀ hx)
          with ⟨hans_in, hp0_le, hrest_le⟩
        set best := rest.foldl
          (fun best p => open Classical in
            if ‖pts best.1 - pts best.2‖ ^ 2 < ‖pts p.1 - pts p.2‖ ^ 2 then p else best) p₀
        have hbest_pairs : best ∈ pairs := by rwa [hp_eq]
        rcases (hpairs_mem best.1 best.2).mp hbest_pairs with ⟨hb1, hb2, hb_ne⟩
        refine ⟨best.1, best.2, rfl, List.mem_toFinset.mpr hb1, List.mem_toFinset.mpr hb2,
          hb_ne.symm, ?_⟩
        -- `‖pts best.1 - pts best.2‖ = indexedEuclideanDiam leafArr.toFinset pts`
        have hne_fs : leafArr.toFinset.Nonempty := ⟨best.1, List.mem_toFinset.mpr hb1⟩
        unfold indexedEuclideanDiam
        rw [dif_pos hne_fs]
        apply le_antisymm
        · exact Finset.le_sup' (f := fun xy : ℕ × ℕ => ‖pts xy.1 - pts xy.2‖)
            (Finset.mem_product.mpr ⟨List.mem_toFinset.mpr hb1, List.mem_toFinset.mpr hb2⟩)
        · refine Finset.sup'_le _ _ (fun ⟨x, y⟩ hxy_prod => ?_)
          rcases Finset.mem_product.mp hxy_prod with ⟨hxS, hyS⟩
          dsimp only
          by_cases hxy : x = y
          · subst hxy; simp
          · have hmem_xy : (x, y) ∈ p₀ :: rest := by
              rw [← hp_eq]
              exact (hpairs_mem x y).mpr ⟨List.mem_toFinset.mp hxS, List.mem_toFinset.mp hyS, Ne.symm hxy⟩
            have hsq : ‖pts x - pts y‖ ^ 2 ≤ ‖pts best.1 - pts best.2‖ ^ 2 := by
              rcases List.mem_cons.mp hmem_xy with rfl | h_in_rest
              · exact hp0_le
              · exact hrest_le (x, y) h_in_rest
            have h1 : 0 ≤ ‖pts x - pts y‖ := norm_nonneg _
            have h2 : 0 ≤ ‖pts best.1 - pts best.2‖ := norm_nonneg _
            nlinarith only [hsq, h1, h2]

/-- Pick best active distinct handle pair `(u, v)` maximizing `‖pts u - pts v‖^2` over candidate
`Option (ℕ × ℕ)` entries, seeded with `(actList[0], actList[1])` when `2 ≤ actList.length`. -/
noncomputable def evalBestGlobalAnswer {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (actList : List ℕ) (cands : List (Option (ℕ × ℕ))) : StoredDiameterAnswer :=
  open Classical in
  if h2 : 2 ≤ actList.length then
    let init : ℕ × ℕ := (actList[0]'(by omega), actList[1]'(by omega))
    let best := cands.foldl
      (fun cur opt =>
        match opt with
        | none => cur
        | some (u, v) =>
            if u ≠ v ∧ actList.contains u = true ∧ actList.contains v = true ∧
                ‖pts cur.1 - pts cur.2‖ ^ 2 < ‖pts u - pts v‖ ^ 2 then
              (u, v)
            else
              cur)
      init
    { diameterHandles := some best, cachedDistSq := ‖pts best.1 - pts best.2‖ ^ 2 }
  else
    { diameterHandles := none, cachedDistSq := 0 }

theorem evalBestGlobalAnswer_spec {d : ℕ}
    (pts : ℕ → EuclideanSpace ℝ (Fin d))
    {actList : List ℕ} (hnd : actList.Nodup) {P : Finset ℕ} (hP : actList.toFinset = P)
    (cands : List (Option (ℕ × ℕ))) :
    let ans := evalBestGlobalAnswer pts actList cands
    (P.card ≤ 1 → ans.diameterHandles = none ∧ ans.cachedDistSq = 0) ∧
    (2 ≤ P.card →
      ∃ h₁ h₂ : ℕ,
        ans.diameterHandles = some (h₁, h₂) ∧
        h₁ ≠ h₂ ∧ h₁ ∈ P ∧ h₂ ∈ P ∧
        ans.cachedDistSq = ‖pts h₁ - pts h₂‖ ^ 2 ∧
        ∀ u v : ℕ, some (u, v) ∈ cands → u ≠ v → u ∈ P → v ∈ P →
          ‖pts u - pts v‖ ≤ ‖pts h₁ - pts h₂‖) := by
  have hlen : actList.length = P.card := by rw [← hP, List.toFinset_card_of_nodup hnd]
  unfold evalBestGlobalAnswer
  refine ⟨fun hle1 => ?_, fun hge2 => ?_⟩
  · have hnot2 : ¬ 2 ≤ actList.length := by omega
    rw [dif_neg hnot2]
    exact ⟨rfl, rfl⟩
  · have h2 : 2 ≤ actList.length := by omega
    rw [dif_pos h2]
    let init : ℕ × ℕ := (actList[0]'(by omega), actList[1]'(by omega))
    have hinit_valid : init.1 ≠ init.2 ∧ init.1 ∈ P ∧ init.2 ∈ P := by
      refine ⟨?_, ?_, ?_⟩
      · intro heq
        have hidx := (List.Nodup.getElem_inj_iff hnd).mp heq
        omega
      · rw [← hP]; exact List.mem_toFinset.mpr (List.getElem_mem _)
      · rw [← hP]; exact List.mem_toFinset.mpr (List.getElem_mem _)
    have hfold : ∀ (cur : ℕ × ℕ) (ls : List (Option (ℕ × ℕ))),
        (cur.1 ≠ cur.2 ∧ cur.1 ∈ P ∧ cur.2 ∈ P) →
        let res := ls.foldl
          (fun cur opt => open Classical in
            match opt with
            | none => cur
            | some (u, v) =>
                if u ≠ v ∧ actList.contains u = true ∧ actList.contains v = true ∧
                    ‖pts cur.1 - pts cur.2‖ ^ 2 < ‖pts u - pts v‖ ^ 2 then
                  (u, v)
                else
                  cur) cur
        (res.1 ≠ res.2 ∧ res.1 ∈ P ∧ res.2 ∈ P) ∧
        ‖pts cur.1 - pts cur.2‖ ^ 2 ≤ ‖pts res.1 - pts res.2‖ ^ 2 ∧
        ∀ u v : ℕ, some (u, v) ∈ ls → u ≠ v → u ∈ P → v ∈ P →
          ‖pts u - pts v‖ ^ 2 ≤ ‖pts res.1 - pts res.2‖ ^ 2 := by
      intro cur ls
      induction ls generalizing cur with
      | nil =>
          intro hcur
          exact ⟨hcur, le_rfl, fun _ _ h => absurd h List.not_mem_nil⟩
      | cons hd tl ih =>
          intro hcur
          dsimp only [List.foldl_cons]
          cases hd with
          | none =>
              rcases ih cur hcur with ⟨h1, h2_le, h3⟩
              refine ⟨h1, h2_le, fun u v hm hne hu hv => ?_⟩
              rcases List.mem_cons.mp hm with h_eq | h_tl
              · cases h_eq
              · exact h3 u v h_tl hne hu hv
          | some uv =>
              rcases uv with ⟨u₀, v₀⟩
              dsimp only
              set cond : Prop := u₀ ≠ v₀ ∧ actList.contains u₀ = true ∧ actList.contains v₀ = true ∧
                ‖pts cur.1 - pts cur.2‖ ^ 2 < ‖pts u₀ - pts v₀‖ ^ 2
              by_cases hc : cond
              · rw [if_pos hc]
                rcases hc with ⟨hne₀, hcu₀, hcv₀, hlt₀⟩
                have hu₀P : u₀ ∈ P := by
                  rw [← hP]; exact List.mem_toFinset.mpr (List.contains_iff_mem.mp hcu₀)
                have hv₀P : v₀ ∈ P := by
                  rw [← hP]; exact List.mem_toFinset.mpr (List.contains_iff_mem.mp hcv₀)
                rcases ih (u₀, v₀) ⟨hne₀, hu₀P, hv₀P⟩ with ⟨h1, h2_le, h3⟩
                refine ⟨h1, hlt₀.le.trans h2_le, fun u v hm hne hu hv => ?_⟩
                rcases List.mem_cons.mp hm with h_eq | h_tl
                · injection h_eq with h_uv; rcases Prod.mk.inj h_uv with ⟨rfl, rfl⟩
                  exact h2_le
                · exact h3 u v h_tl hne hu hv
              · rw [if_neg hc]
                rcases ih cur hcur with ⟨h1, h2_le, h3⟩
                refine ⟨h1, h2_le, fun u v hm hne hu hv => ?_⟩
                rcases List.mem_cons.mp hm with h_eq | h_tl
                · injection h_eq with h_uv; rcases Prod.mk.inj h_uv with ⟨rfl, rfl⟩
                  have hcu : actList.contains u = true :=
                    List.contains_iff_mem.mpr (List.mem_toFinset.mp (hP ▸ hu))
                  have hcv : actList.contains v = true :=
                    List.contains_iff_mem.mpr (List.mem_toFinset.mp (hP ▸ hv))
                  have hnot_lt : ¬ ‖pts cur.1 - pts cur.2‖ ^ 2 < ‖pts u - pts v‖ ^ 2 :=
                    fun hlt => hc ⟨hne, hcu, hcv, hlt⟩
                  exact (not_lt.mp hnot_lt).trans h2_le
                · exact h3 u v h_tl hne hu hv
    rcases hfold init cands hinit_valid with ⟨⟨hb_ne, hb1, hb2⟩, _, hall_sq⟩
    set best := cands.foldl _ init
    refine ⟨best.1, best.2, rfl, hb_ne, hb1, hb2, rfl, fun u v hm hne hu hv => ?_⟩
    have hsq := hall_sq u v hm hne hu hv
    have h1 : 0 ≤ ‖pts u - pts v‖ := norm_nonneg _
    have h2 : 0 ≤ ‖pts best.1 - pts best.2‖ := norm_nonneg _
    nlinarith only [hsq, h1, h2]

end UL.Proof.clm_9_1_explicit_tradeoff.H4c2
