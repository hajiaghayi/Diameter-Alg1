import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.lem_6_2
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H1

open UL

/-! ### 1. Explicit tradeoff curve `g_c`, `rho_c`, `Q_c` identities and bounds -/

theorem c_sq_bounds {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    1 < c ^ 2 ∧ c ^ 2 < 2 := by
  refine ⟨by nlinarith, ?_⟩
  have hsq : c ^ 2 < (Real.sqrt 2) ^ 2 :=
    sq_lt_sq' (by linarith [Real.sqrt_nonneg 2]) hc_lt
  rwa [Real.sq_sqrt (by norm_num)] at hsq

theorem g_c_bounds {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    0 < g_c c ∧ g_c c < 1 := by
  obtain ⟨h1, h2⟩ := c_sq_bounds hc_gt hc_lt
  unfold g_c
  exact ⟨by linarith, by linarith⟩

theorem rho_c_bounds {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    0 < rho_c c ∧ rho_c c < 1 := by
  obtain ⟨h1, h2⟩ := c_sq_bounds hc_gt hc_lt
  have hc2_pos : 0 < c ^ 2 := by linarith
  unfold rho_c
  constructor
  · rw [sub_pos, lt_div_iff₀ hc2_pos]
    linarith
  · have hlt2 : 2 / c ^ 2 < 2 := by
      rw [div_lt_iff₀ hc2_pos]
      nlinarith
    linarith

theorem sqrt_one_sub_g_sq {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    Real.sqrt (1 - (g_c c) ^ 2) = c * Real.sqrt (2 - c ^ 2) := by
  obtain ⟨_, h2⟩ := c_sq_bounds hc_gt hc_lt
  have hc_nn : 0 ≤ c := by linarith
  have h2mc2 : 0 ≤ 2 - c ^ 2 := by linarith
  have heq : 1 - (g_c c) ^ 2 = (c * Real.sqrt (2 - c ^ 2)) ^ 2 := by
    rw [mul_pow, Real.sq_sqrt h2mc2]
    unfold g_c
    ring
  rw [heq, Real.sqrt_sq (mul_nonneg hc_nn (Real.sqrt_nonneg _))]

theorem sqrt_rho_c_eq {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    Real.sqrt (rho_c c) = Real.sqrt (2 - c ^ 2) / c := by
  obtain ⟨_, h2⟩ := c_sq_bounds hc_gt hc_lt
  have hc_pos : 0 < c := by linarith
  have h2mc2 : 0 ≤ 2 - c ^ 2 := by linarith
  have heq : rho_c c = (Real.sqrt (2 - c ^ 2) / c) ^ 2 := by
    rw [div_pow, Real.sq_sqrt h2mc2]
    unfold rho_c
    field_simp
  rw [heq, Real.sqrt_sq (div_nonneg (Real.sqrt_nonneg _) hc_pos.le)]

theorem Q_c_at_rho {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    Q_c c (rho_c c) = rho_c c := by
  have hc_pos : 0 < c := by linarith
  have hrho_nn : 0 ≤ rho_c c := (rho_c_bounds hc_gt hc_lt).1.le
  unfold Q_c
  rw [sqrt_one_sub_g_sq hc_gt hc_lt, sqrt_rho_c_eq hc_gt hc_lt]
  have hinter :
      c * Real.sqrt (2 - c ^ 2) - g_c c * (Real.sqrt (2 - c ^ 2) / c) =
        Real.sqrt (2 - c ^ 2) / c := by
    unfold g_c
    field_simp
    ring
  rw [hinter, ← sqrt_rho_c_eq hc_gt hc_lt, Real.sq_sqrt hrho_nn]

theorem rho_c_le_Q_c {c σ : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2)
    (_hσ0 : 0 ≤ σ) (hσ_hi : σ ≤ rho_c c) :
    rho_c c ≤ Q_c c σ := by
  have hc_pos : 0 < c := by linarith
  have hg_pos : 0 < g_c c := (g_c_bounds hc_gt hc_lt).1
  have hrho_nn : 0 ≤ rho_c c := (rho_c_bounds hc_gt hc_lt).1.le
  have hsqrt_le : Real.sqrt σ ≤ Real.sqrt (rho_c c) := Real.sqrt_le_sqrt hσ_hi
  have hmul_le : g_c c * Real.sqrt σ ≤ g_c c * Real.sqrt (rho_c c) :=
    mul_le_mul_of_nonneg_left hsqrt_le hg_pos.le
  have hbase_eq :
      Real.sqrt (1 - (g_c c) ^ 2) - g_c c * Real.sqrt (rho_c c) = Real.sqrt (rho_c c) := by
    rw [sqrt_one_sub_g_sq hc_gt hc_lt, sqrt_rho_c_eq hc_gt hc_lt]
    unfold g_c
    field_simp
    ring
  have hsub_ge :
      Real.sqrt (rho_c c) ≤ Real.sqrt (1 - (g_c c) ^ 2) - g_c c * Real.sqrt σ := by
    linarith
  unfold Q_c
  calc
    rho_c c = (Real.sqrt (rho_c c)) ^ 2 := (Real.sq_sqrt hrho_nn).symm
    _ ≤ (Real.sqrt (1 - (g_c c) ^ 2) - g_c c * Real.sqrt σ) ^ 2 :=
          pow_le_pow_left₀ (Real.sqrt_nonneg _) hsub_ge 2

theorem prove_conjunct_5 {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    0 < rho_c c ∧
    rho_c c < 1 ∧
    Q_c c (rho_c c) = rho_c c ∧
    Q_c c (rho_c c) = 2 / c ^ 2 - 1 ∧
    1 + rho_c c = 2 / c ^ 2 ∧
    Q_c c 0 = c ^ 2 * (2 - c ^ 2) := by
  obtain ⟨hrho0, hrho1⟩ := rho_c_bounds hc_gt hc_lt
  have hQrho := Q_c_at_rho hc_gt hc_lt
  refine ⟨hrho0, hrho1, hQrho, ?_, ?_, ?_⟩
  · rw [hQrho]; rfl
  · unfold rho_c; ring
  · obtain ⟨h1, h2⟩ := c_sq_bounds hc_gt hc_lt
    unfold Q_c g_c
    simp only [Real.sqrt_zero, mul_zero, sub_zero]
    have hnn : 0 ≤ 1 - (c ^ 2 - 1) ^ 2 := by nlinarith
    rw [Real.sq_sqrt hnn]
    ring

/-! ### 2. Tensor depth `ℓ ≥ 16/ρ`, base exponent `I_h(x)/ℓ ≤ ρ/8`, and Conjunct (1) -/

theorem ell_pos_and_ge_one {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2)
    {ℓ : ℕ} (hℓ : 16 / rho_c c ≤ (ℓ : ℝ)) :
    1 ≤ ℓ ∧ 16 < (ℓ : ℝ) := by
  obtain ⟨hrho0, hrho1⟩ := rho_c_bounds hc_gt hc_lt
  have h16 : 16 < 16 / rho_c c := by
    rw [lt_div_iff₀ hrho0]
    linarith
  have hℓ_gt : 16 < (ℓ : ℝ) := h16.trans_le hℓ
  have h1 : (1 : ℕ) ≤ ℓ := by
    by_contra hlt
    have h0 : ℓ = 0 := by omega
    subst h0
    norm_num at hℓ_gt
  exact ⟨h1, hℓ_gt⟩

theorem u_search_nonneg {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (_hhx : h ≤ x) (_hx1 : x ≤ 1) :
    0 ≤ u_search h x := by
  have hden : 0 < 1 - h ^ 2 := by nlinarith
  have heq : u_search h x = (x - h) ^ 2 / (1 - h ^ 2) := by
    unfold u_search I_h
    field_simp
    ring
  rw [heq]
  exact div_nonneg (sq_nonneg _) hden.le

theorem I_h_bounds {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hhx : h ≤ x) (hx1 : x ≤ 1) :
    1 ≤ I_h h x ∧ I_h h x ≤ 2 := by
  have hu0 := u_search_nonneg hh0 hh1 hhx hx1
  have hI_eq : I_h h x = 1 + u_search h x := by unfold u_search; ring
  refine ⟨by linarith, ?_⟩
  have hden : 0 < 1 - h ^ 2 := by nlinarith
  unfold I_h
  rw [div_le_iff₀ hden]
  have hx2 : x ^ 2 ≤ 1 := by nlinarith
  have hhxh : 0 ≤ 2 * h * (x - h) := by nlinarith
  nlinarith

theorem base_exp_le_rho_div_8 {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2)
    {ℓ : ℕ} (hℓ : 16 / rho_c c ≤ (ℓ : ℝ))
    {h x : ℝ} (hh0 : 0 < h) (hh1 : h < 1) (hhx : h ≤ x) (hx1 : x ≤ 1) :
    I_h h x / (ℓ : ℝ) = (1 + u_search h x) / (ℓ : ℝ) ∧
    (1 + u_search h x) / (ℓ : ℝ) ≤ rho_c c / 8 ∧
    0 < I_h h x / (ℓ : ℝ) := by
  obtain ⟨hrho0, _⟩ := rho_c_bounds hc_gt hc_lt
  obtain ⟨_, hℓ_gt⟩ := ell_pos_and_ge_one hc_gt hc_lt hℓ
  have hℓ_pos : 0 < (ℓ : ℝ) := by linarith
  obtain ⟨hI1, hI2⟩ := I_h_bounds hh0 hh1 hhx hx1
  have heq : I_h h x = 1 + u_search h x := by unfold u_search; ring
  refine ⟨by rw [heq], ?_, div_pos (by linarith) hℓ_pos⟩
  rw [← heq]
  have h16_pos : 0 < 16 / rho_c c := div_pos (by norm_num) hrho0
  calc
    I_h h x / (ℓ : ℝ) ≤ 2 / (ℓ : ℝ) := div_le_div_of_nonneg_right hI2 hℓ_pos.le
    _ ≤ 2 / (16 / rho_c c) := div_le_div_of_nonneg_left (by norm_num) h16_pos hℓ
    _ = rho_c c / 8 := by field_simp; ring

theorem prove_conjunct_1 (h_lem_6_2 : S_lem_6_2)
    {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    (∃ ℓ : ℕ, 16 / rho_c c ≤ (ℓ : ℝ)) ∧
    (∀ (h_min : ℝ), 0 < h_min → h_min ≤ g_c c →
      g_c c < 1 ∧
      ∃ c_h : ℝ, 0 < c_h ∧
        ∀ (d : ℕ), 1 ≤ d →
          ∀ (h x t : ℝ), h_min ≤ h → h ≤ g_c c → h ≤ x → x ≤ 1 → 1 ≤ t →
            ∃ p_u p_q p₁ p₂ : ℝ,
              IsGaussianFilterProbs d h x t p_u p_q p₁ p₂ ∧
              p_u ≤ Real.exp (-(t ^ 2 / 2)) ∧
              p_q ≤ Real.exp (-(x ^ 2 * t ^ 2 / 2)) ∧
              c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2)) ≤ p₁ ∧
              p₂ ≤ Real.exp (-((1 + x ^ 2) * t ^ 2 / 2))) ∧
    (∀ (ℓ : ℕ), 16 / rho_c c ≤ (ℓ : ℝ) →
      ∀ (h x : ℝ), 0 < h → h < 1 → h ≤ x → x ≤ 1 →
        I_h h x / (ℓ : ℝ) = (1 + u_search h x) / (ℓ : ℝ) ∧
        (1 + u_search h x) / (ℓ : ℝ) ≤ rho_c c / 8) := by
  refine ⟨⟨Nat.ceil (16 / rho_c c), Nat.le_ceil _⟩, ?_, ?_⟩
  · intro h_min hh_min hh_le
    have hg1 := (g_c_bounds hc_gt hc_lt).2
    exact ⟨hg1, h_lem_6_2 h_min (g_c c) hh_min hh_le hg1⟩
  · intro ℓ hℓ h x hh0 hh1 hhx hx1
    have hb := base_exp_le_rho_div_8 hc_gt hc_lt hℓ hh0 hh1 hhx hx1
    exact ⟨hb.1, hb.2.1⟩

/-! ### 3. Level count `L_n` and Conjunct (3) -/

theorem one_le_L_n {n : ℕ} (hn : 2 ≤ n) : 1 ≤ L_n n := by
  unfold L_n
  have h4 : 2 ≤ Nat.clog 2 4 := by decide
  have hmono : Nat.clog 2 4 ≤ Nat.clog 2 (2 * n) := Nat.clog_mono_right 2 (by omega)
  omega

theorem log_nat_le_L_n {n m : ℕ} (hn : 2 ≤ n) (hm1 : 1 ≤ m) (hmn : m ≤ n) :
    Real.log (m : ℝ) ≤ (L_n n : ℝ) := by
  have hm_pos : (0 : ℝ) < (m : ℝ) := by exact_mod_cast hm1
  have hpow : 2 * n ≤ 2 ^ (L_n n) := by
    unfold L_n
    exact Nat.le_pow_clog (by norm_num) (2 * n)
  have hm_le_pow : (m : ℝ) ≤ (2 : ℝ) ^ (L_n n) := by
    have hnat : m ≤ 2 ^ (L_n n) := by omega
    exact_mod_cast hnat
  calc
    Real.log (m : ℝ) ≤ Real.log ((2 : ℝ) ^ (L_n n)) := Real.log_le_log hm_pos hm_le_pow
    _ = (L_n n : ℝ) * Real.log 2 := by rw [Real.log_pow]
    _ ≤ (L_n n : ℝ) * 1 :=
          mul_le_mul_of_nonneg_left (by linarith [Real.log_two_lt_d9]) (Nat.cast_nonneg _)
    _ = (L_n n : ℝ) := mul_one _

theorem prove_conjunct_3 {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    (∀ (C_q : ℝ), 0 ≤ C_q →
      ∃ C_pow : ℝ, 1 ≤ C_pow ∧
        ∀ (n m : ℕ) (σ q : ℝ),
          2 ≤ n → 1 ≤ m → m ≤ n →
          0 ≤ σ → σ ≤ rho_c c →
          q ≤ Q_c c σ + C_q / (L_n n : ℝ) →
            (m : ℝ) ^ q ≤ (m : ℝ) ^ (Q_c c σ) * Real.exp (C_q * Real.log (m : ℝ) / (L_n n : ℝ)) ∧
            (m : ℝ) ^ (Q_c c σ) * Real.exp (C_q * Real.log (m : ℝ) / (L_n n : ℝ)) ≤
              C_pow * (m : ℝ) ^ (Q_c c σ)) ∧
    (∀ (σ : ℝ), 0 ≤ σ → σ ≤ rho_c c →
      rho_c c ≤ Q_c c σ ∧
      ∀ (n m : ℕ) (u : ℝ),
        2 ≤ n → 1 ≤ m → m ≤ n →
        0 ≤ u → u ≤ σ →
          ValidBirthPoolParams n m σ (Q_c c σ) ∧
          (m : ℝ) ^ u + (m : ℝ) ^ (rho_c c / 8) ≤ 2 * (n : ℝ) ^ (Q_c c σ) ∧
          (m : ℝ) ^ (1 + u) + (m : ℝ) ^ (rho_c c / 8) ≤ 2 * (m : ℝ) ^ (1 + σ)) := by
  obtain ⟨hrho0, hrho1⟩ := rho_c_bounds hc_gt hc_lt
  constructor
  · intro C_q hCq
    refine ⟨Real.exp C_q, Real.one_le_exp hCq, ?_⟩
    intro n m σ q hn hm1 hmn _hσ0 _hσ1 hq
    have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm1
    have hm_pos : (0 : ℝ) < (m : ℝ) := by linarith
    have hL1 : 1 ≤ L_n n := one_le_L_n hn
    have hL_pos : (0 : ℝ) < (L_n n : ℝ) := by exact_mod_cast hL1
    constructor
    · calc
        (m : ℝ) ^ q ≤ (m : ℝ) ^ (Q_c c σ + C_q / (L_n n : ℝ)) :=
              Real.rpow_le_rpow_of_exponent_le hm_ge1 hq
        _ = (m : ℝ) ^ (Q_c c σ) * (m : ℝ) ^ (C_q / (L_n n : ℝ)) :=
              Real.rpow_add hm_pos _ _
        _ = (m : ℝ) ^ (Q_c c σ) * Real.exp (C_q * Real.log (m : ℝ) / (L_n n : ℝ)) := by
              congr 1
              rw [Real.rpow_def_of_pos hm_pos]
              congr 1
              ring
    · have hlog_le := log_nat_le_L_n hn hm1 hmn
      have hexp_arg : C_q * Real.log (m : ℝ) / (L_n n : ℝ) ≤ C_q := by
        rw [div_le_iff₀ hL_pos]
        exact mul_le_mul_of_nonneg_left hlog_le hCq
      have hexp_le : Real.exp (C_q * Real.log (m : ℝ) / (L_n n : ℝ)) ≤ Real.exp C_q :=
        Real.exp_le_exp.mpr hexp_arg
      calc
        (m : ℝ) ^ (Q_c c σ) * Real.exp (C_q * Real.log (m : ℝ) / (L_n n : ℝ))
            ≤ (m : ℝ) ^ (Q_c c σ) * Real.exp C_q :=
              mul_le_mul_of_nonneg_left hexp_le (Real.rpow_nonneg hm_pos.le _)
        _ = Real.exp C_q * (m : ℝ) ^ (Q_c c σ) := mul_comm _ _
  · intro σ hσ0 hσ_hi
    have hrho_Q := rho_c_le_Q_c hc_gt hc_lt hσ0 hσ_hi
    refine ⟨hrho_Q, ?_⟩
    intro n m u hn hm1 hmn hu0 hu_σ
    have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm1
    have hm_nn : (0 : ℝ) ≤ (m : ℝ) := by linarith
    have hmn_r : (m : ℝ) ≤ (n : ℝ) := by exact_mod_cast hmn
    have hQ_nn : 0 ≤ Q_c c σ := by linarith
    refine ⟨⟨hn, hm1, hmn, hσ0, hσ_hi.trans hrho_Q⟩, ?_, ?_⟩
    · have h1 : (m : ℝ) ^ u ≤ (n : ℝ) ^ (Q_c c σ) :=
        (Real.rpow_le_rpow_of_exponent_le hm_ge1 (by linarith)).trans
          (Real.rpow_le_rpow hm_nn hmn_r hQ_nn)
      have h2 : (m : ℝ) ^ (rho_c c / 8) ≤ (n : ℝ) ^ (Q_c c σ) :=
        (Real.rpow_le_rpow_of_exponent_le hm_ge1 (by linarith)).trans
          (Real.rpow_le_rpow hm_nn hmn_r hQ_nn)
      linarith
    · have h1 : (m : ℝ) ^ (1 + u) ≤ (m : ℝ) ^ (1 + σ) :=
        Real.rpow_le_rpow_of_exponent_le hm_ge1 (by linarith)
      have h2 : (m : ℝ) ^ (rho_c c / 8) ≤ (m : ℝ) ^ (1 + σ) :=
        Real.rpow_le_rpow_of_exponent_le hm_ge1 (by linarith)
      linarith

/-! ### 4. Bivariate polynomial closure helpers (`IsBoundedByPoly2`) -/

theorem isBoundedByPoly2_const {K : ℝ} (hK : 0 ≤ K) :
    IsBoundedByPoly2 (fun _ _ => K) :=
  ⟨K, 0, hK, fun _ _ => by simp⟩

theorem isBoundedByPoly2_add {f g : ℕ → ℕ → ℝ}
    (hf : IsBoundedByPoly2 f) (hg : IsBoundedByPoly2 g) :
    IsBoundedByPoly2 (fun d L => f d L + g d L) := by
  rcases hf with ⟨Cf, df, hCf, hfb⟩
  rcases hg with ⟨Cg, dg, hCg, hgb⟩
  refine ⟨Cf + Cg, max df dg, add_nonneg hCf hCg, fun d L => ?_⟩
  have hd1 : (1 : ℝ) ≤ (d + 1 : ℝ) := by linarith [Nat.cast_nonneg (α := ℝ) d]
  have hL1 : (1 : ℝ) ≤ (L + 1 : ℝ) := by linarith [Nat.cast_nonneg (α := ℝ) L]
  have hpf : (d + 1 : ℝ) ^ df * (L + 1 : ℝ) ^ df ≤
      (d + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg) :=
    mul_le_mul (pow_le_pow_right₀ hd1 (le_max_left _ _))
      (pow_le_pow_right₀ hL1 (le_max_left _ _)) (by positivity) (by positivity)
  have hpg : (d + 1 : ℝ) ^ dg * (L + 1 : ℝ) ^ dg ≤
      (d + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg) :=
    mul_le_mul (pow_le_pow_right₀ hd1 (le_max_right _ _))
      (pow_le_pow_right₀ hL1 (le_max_right _ _)) (by positivity) (by positivity)
  calc
    f d L + g d L
        ≤ Cf * ((d + 1 : ℝ) ^ df * (L + 1 : ℝ) ^ df) +
          Cg * ((d + 1 : ℝ) ^ dg * (L + 1 : ℝ) ^ dg) := by
          linarith [hfb d L, hgb d L]
    _ ≤ Cf * ((d + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg)) +
          Cg * ((d + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg)) :=
          add_le_add (mul_le_mul_of_nonneg_left hpf hCf) (mul_le_mul_of_nonneg_left hpg hCg)
    _ = (Cf + Cg) * (d + 1 : ℝ) ^ (max df dg) * (L + 1 : ℝ) ^ (max df dg) := by ring

theorem isBoundedByPoly2_mul {f g : ℕ → ℕ → ℝ}
    (hf : IsBoundedByPoly2 f) (hf_nn : ∀ d L, 0 ≤ f d L)
    (hg : IsBoundedByPoly2 g) (hg_nn : ∀ d L, 0 ≤ g d L) :
    IsBoundedByPoly2 (fun d L => f d L * g d L) := by
  rcases hf with ⟨Cf, df, hCf, hfb⟩
  rcases hg with ⟨Cg, dg, hCg, hgb⟩
  refine ⟨Cf * Cg, df + dg, mul_nonneg hCf hCg, fun d L => ?_⟩
  have h1 := mul_le_mul (hfb d L) (hgb d L) (hg_nn d L) (by positivity)
  refine h1.trans (le_of_eq ?_)
  simp only [pow_add]
  ring

theorem isBoundedByPoly2_max_zero {f : ℕ → ℕ → ℝ} (hf : IsBoundedByPoly2 f) :
    IsBoundedByPoly2 (fun d L => max 0 (f d L)) := by
  rcases hf with ⟨C, deg, hC, hb⟩
  refine ⟨C, deg, hC, fun d L => max_le (by positivity) (hb d L)⟩

end UL.Proof.clm_9_1_explicit_tradeoff.H1
