import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInstA1b

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 5. Read & Query Operations (`inCoreBall`, `readNodeScalar`, `readNodeArrElem`,
`containsNodeArr`, `readCenterCoord`, `readCfgStoredEdge`, and `O(1)` `readMaxRadius`) -/

section SlotReadOps

variable {d : ℕ} {params : LocalScaleParams} {h : ℝ}
variable {cp : ChainParams d params h} (L : NodeSlotLayout cp)

theorem radFrame_zero_eq {scrW scrR tblW tblR : ℕ} {m₁ m₂ : ArithRAMMemory}
    (h : RadFrameOutside scrW scrR tblW 0 0 tblR 0 0 m₁ m₂) :
    (∀ t, t ≠ scrW → ∀ i, H3a.wRead m₂ t i = H3a.wRead m₁ t i) ∧
    (∀ t, t ≠ scrR → ∀ i, H3a.rRead m₂ t i = H3a.rRead m₁ t i) :=
  ⟨fun t ht i => h.1 t i ht (Or.inr (by simpa using lt_or_ge i 0)),
   fun t ht i => h.2 t i ht (Or.inr (by simpa using lt_or_ge i 0))⟩

theorem NodeSlotLayout.ro_preserve {m₀ m₁ : ArithRAMMemory}
    (hsr₀ : L.SlotsReady m₀)
    (hw_node : ∀ i, H3a.wRead m₁ L.nodeWTbl i = H3a.wRead m₀ L.nodeWTbl i)
    (hr_node : ∀ i, H3a.rRead m₁ L.nodeRTbl i = H3a.rRead m₀ L.nodeRTbl i)
    (hr_pts : ∀ i, H3a.rRead m₁ ptsRTbl i = H3a.rRead m₀ ptsRTbl i) :
    L.SlotsReady m₁ ∧
    (∀ mn' s', s' < M_slots cp → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) := by
  refine ⟨fun s hs =>
    ManagedNodeSlotReady.mono_slice (hsr₀ s hs)
      (fun i _ _ => hw_node i) (fun i _ _ => hr_node i), ?_⟩
  intro mn' s' _ ⟨hS_lt, hm₀⟩
  have hm₁ : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW s') (L.slotBaseR s') (memPtsOf d m₀) mn' none m₁ :=
    EncManagedNode.mono_slice hm₀
      (fun i _ _ => hw_node i) (fun i _ _ => hr_node i)
      (fun _ _ _ _ => hr_pts _)
  exact ⟨hS_lt, EncManagedNode.pts_congr
    (fun _ _ => memPtsOf_congr d (fun _ => hr_pts _)) hm₁⟩

def NodeSlotLayout.slotInCoreBallCost (_L : NodeSlotLayout cp) : ℕ := 200 + 60 * d
def NodeSlotLayout.slotReadCost : ℕ := L.cmOps.readEdgeCost + 250

/-! #### 5.1 `slotInCoreBallStmt` -/

def NodeSlotLayout.slotInCoreBallStmt (sR pR oR : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap L.nodeScrWTbl (.lit 0)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeRStride : ℤ))))
  (.seq (.writeWordHeap L.nodeScrWTbl (.lit 1) (.readHeap engScrTbl (.lit pR)))
  (.seq (inCoreBallStmt L.nodeScrWTbl L.nodeScrRTbl L.nodeRTbl 0 1 2 3 0 d)
        (.writeWordHeap engScrTbl (.lit oR) (.readHeap L.nodeScrWTbl (.lit 2)))))

theorem NodeSlotLayout.zeroRand_slotInCoreBallStmt (sR pR oR : ℤ) :
    ZeroRandStmt (L.slotInCoreBallStmt sR pR oR) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
      (.seq (zeroRand_inCoreBallStmt _ _ _ _ _ _ _ _ _) (.writeWordHeap _ _ _)))

theorem NodeSlotLayout.exec_slotInCoreBallStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot p : ℕ) (pt : EuclideanSpace ℝ (Fin d)) (sR pR oR : ℤ)
    (_hslot : slot < M_slots cp) (_hp : p < cp.n)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (_hpR0 : 0 ≤ pR) (_hpR64 : pR < 64)
    (hoR0 : 0 ≤ oR) (hoR64 : oR < 64)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ))
    (hpR_v : H3a.wRead m₀ engScrTbl pR = (p : ℤ))
    (hpt : ∀ c : Fin d, H3a.rRead m₀ ptsRTbl (((p * d + c.val : ℕ) : ℤ)) = euclideanCoord pt c) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotInCoreBallStmt sR pR oR) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        H3a.wRead m₁ engScrTbl oR = (if inCoreBall mn.nd.o mn.nd.V pt then 1 else 0) ∧
        (∀ mn' s', s' < M_slots cp → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ i, i ≠ oR → H3a.wRead m₁ engScrTbl i = H3a.wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      L.slotInCoreBallCost := by
  have hscrW : L.nodeScrWTbl < L.TW := L.hNodeScrW_hi
  have hscrR : L.nodeScrRTbl < L.TR := L.hNodeScrR_hi
  have hT_eng : engScrTbl < L.TW := by have := L.hTW; unfold engScrTbl; omega
  have hBW64 : 64 ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  have hBR16 : 16 ≤ L.BR := by unfold NodeSlotLayout.BR; omega
  have hne_eng : engScrTbl ≠ L.nodeScrWTbl := by have := L.hNodeScrW_lo; unfold engScrTbl; omega
  have hne1 : (1 : ℕ) ≠ L.nodeScrRTbl := by have := L.hNodeScrR_lo; omega
  rcases henc₀.2 with ⟨_, _, _, ho_e, _, hV_e, _⟩
  unfold NodeSlotLayout.slotInCoreBallStmt
  refine ExecDet.seq' (12 + (120 + 55 * d) + 12)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 0)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeRStride : ℤ))) 0 (L.slotBaseR slot)
      hfp₀ hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead m₀ engScrTbl sR * _ = _
          rw [hsR_v, ← L.slotBaseR_eq_mul])
      (by simp [intExprOps]))
    (by unfold NodeSlotLayout.slotInCoreBallCost; omega) ?_
  intro mA hmA hfpA; subst hmA
  refine ExecDet.seq' ((120 + 55 * d) + 12)
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 1) (.readHeap engScrTbl (.lit pR)) 1 (p : ℤ)
      hfpA hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead _ engScrTbl pR = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_eng), hpR_v])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mB hmB hfpB; subst hmB
  obtain ⟨mC, hdetC, hfpC, houtC, _, hfrBC⟩ :=
    exec_coreBallTestStmt (tblW := L.nodeWTbl) false inp 0 1 2 3 0 (L.slotBaseR slot) p pt mn.nd.o mn.nd.V
      hfpB hscrW hscrR L.hne_nodeW L.hne_nodeR hne1
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
      (wRead_wWrite_self _ _ _ _)
      hpt ho_e hV_e
  obtain ⟨hwBC, hrBC⟩ := radFrame_zero_eq hfrBC
  refine ExecDet.seq' (Mid := fun m =>
      H3a.wRead m L.nodeScrWTbl 2 = (if inCoreBall mn.nd.o mn.nd.V pt then 1 else 0) ∧
      (∀ t, t ≠ L.nodeScrWTbl → ∀ i, H3a.wRead m t i = H3a.wRead m₀ t i) ∧
      (∀ t, t ≠ L.nodeScrRTbl → ∀ i, H3a.rRead m t i = H3a.rRead m₀ t i)) 12
    (detExec_to_execDet (hzr_coreBallTestStmt false _ _ _ _ _ _ _ _ _) hfpB hfpC hdetC
      ⟨houtC,
       fun t ht i => by rw [hwBC t ht i]; iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)],
       hrBC⟩)
    (by omega) ?_
  intro mC' ⟨houtC', hw0C', hr0C'⟩ hfpC'
  refine ExecDet.wWrite inp engScrTbl (.lit oR) (.readHeap L.nodeScrWTbl (.lit 2))
    oR (if inCoreBall mn.nd.o mn.nd.V pt then 1 else 0)
    hfpC' hT_eng hoR0 (by omega) rfl
    (by simp only [evalIntExpr]; change H3a.wRead mC' L.nodeScrWTbl 2 = _; exact houtC')
    (by simp [intExprOps]) ?_
  have hne_node_eng : L.nodeWTbl ≠ engScrTbl := by
    have := L.hNodeWTbl_lo; unfold engScrTbl; omega
  have h1_ne_scrR : ptsRTbl ≠ L.nodeScrRTbl := by have := L.hNodeScrR_lo; unfold ptsRTbl; omega
  obtain ⟨hsr₁, henc₁⟩ := L.ro_preserve hsr₀
    (fun i => (wRead_wWrite_of_ne _ _ (Or.inl hne_node_eng)).trans (hw0C' L.nodeWTbl L.hne_nodeW i))
    (fun i => hr0C' L.nodeRTbl L.hne_nodeR i)
    (fun i => hr0C' ptsRTbl h1_ne_scrR i)
  have hscr_lo := L.hNodeScrW_lo; have hscrR_lo := L.hNodeScrR_lo
  exact ⟨hsr₁,
    wRead_wWrite_self _ _ _ _,
    henc₁,
    fun t ht9 hne_t i => (wRead_wWrite_of_ne _ _ (Or.inl hne_t)).trans (hw0C' t (by omega) i),
    fun i hne_i => (wRead_wWrite_of_ne _ _ (Or.inr hne_i)).trans (hw0C' engScrTbl hne_eng i),
    fun t ht3 i => hr0C' t (by omega) i⟩

/-! #### 5.2 `slotReadNodeScalarStmt` -/

def NodeSlotLayout.scalarOff (_L : NodeSlotLayout cp) : NodeScalarField → ℤ
  | .birthSize => 0
  | .age => 1
  | .denseLen => 9
  | .histLen => 8 + 2 * swapPoolStride cp.n
  | .resLen => 9 + swapPoolStride cp.n

def NodeSlotLayout.slotReadNodeScalarStmt (f : NodeScalarField) (sR oR : ℤ) : ArithRAMStmt :=
  .writeWordHeap engScrTbl (.lit oR)
    (.readHeap L.nodeWTbl
      (.add (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ)))
            (.lit (L.scalarOff f))))

theorem NodeSlotLayout.zeroRand_slotReadNodeScalarStmt (f : NodeScalarField) (sR oR : ℤ) :
    ZeroRandStmt (L.slotReadNodeScalarStmt f sR oR) :=
  .writeWordHeap _ _ _

theorem NodeSlotLayout.exec_slotReadNodeScalarStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot : ℕ) (f : NodeScalarField) (sR oR : ℤ)
    (_hslot : slot < M_slots cp) (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (hoR0 : 0 ≤ oR) (hoR64 : oR < 64)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ)) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotReadNodeScalarStmt f sR oR) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        H3a.wRead m₁ engScrTbl oR = (evalNodeScalar mn f : ℤ) ∧
        (∀ mn' s', s' < M_slots cp → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ i, i ≠ oR → H3a.wRead m₁ engScrTbl i = H3a.wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      L.slotReadCost := by
  have hT_eng : engScrTbl < L.TW := by have := L.hTW; unfold engScrTbl; omega
  have hBW64 : 64 ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  have hne_node_eng : L.nodeWTbl ≠ engScrTbl := by
    have := L.hNodeWTbl_lo; unfold engScrTbl; omega
  rcases henc₀.2 with ⟨hb_e, ha_e, _, _, _, _, _, hh_len, _,
    ⟨Pd, _, hPd_l, hPd_e⟩, ⟨Pr, _, hPr_l, hPr_e⟩, _, _⟩
  have hval : H3a.wRead m₀ L.nodeWTbl (L.slotBaseW slot + L.scalarOff f) =
      (evalNodeScalar mn f : ℤ) := by
    cases f with
    | birthSize =>
        dsimp [NodeSlotLayout.scalarOff, evalNodeScalar]
        rw [add_zero]; exact hb_e
    | age =>
        dsimp [NodeSlotLayout.scalarOff, evalNodeScalar]
        exact ha_e
    | denseLen =>
        dsimp [NodeSlotLayout.scalarOff, evalNodeScalar]
        have hoff : L.slotBaseW slot + 9 = nodeDensePoolOff (L.slotBaseW slot) + 1 := by
          unfold nodeDensePoolOff; ring
        rw [hoff, hPd_e.2.1, ← hPd_l, length_swapPoolToList]
    | histLen =>
        dsimp [NodeSlotLayout.scalarOff, evalNodeScalar]
        have hoff : L.slotBaseW slot + (8 + 2 * swapPoolStride cp.n) =
            nodeHistOff cp.n (L.slotBaseW slot) := by
          unfold nodeHistOff; ring
        rw [hoff]; exact hh_len
    | resLen =>
        dsimp [NodeSlotLayout.scalarOff, evalNodeScalar]
        have hoff : L.slotBaseW slot + (9 + swapPoolStride cp.n) =
            nodeResPoolOff cp.n (L.slotBaseW slot) + 1 := by
          unfold nodeResPoolOff; ring
        rw [hoff, hPr_e.2.1, ← hPr_l, length_swapPoolToList]
  refine ExecDet.wWrite inp engScrTbl (.lit oR) _ oR (evalNodeScalar mn f : ℤ)
    hfp₀ hT_eng hoR0 (by omega) rfl
    (by simp only [evalIntExpr]
        change H3a.wRead m₀ L.nodeWTbl (H3a.wRead m₀ engScrTbl sR * (L.nodeWStride : ℤ) + L.scalarOff f) = _
        rw [hsR_v, ← L.slotBaseW_eq_mul, hval])
    (by unfold NodeSlotLayout.slotReadCost; simp [intExprOps]; try omega) ?_
  obtain ⟨hsr₁, henc₁⟩ := L.ro_preserve hsr₀
    (fun _ => wRead_wWrite_of_ne _ _ (Or.inl hne_node_eng))
    (fun _ => rfl) (fun _ => rfl)
  exact ⟨hsr₁, wRead_wWrite_self _ _ _ _, henc₁,
    fun _ _ hne _ => wRead_wWrite_of_ne _ _ (Or.inl hne),
    fun _ hne => wRead_wWrite_of_ne _ _ (Or.inr hne),
    fun _ _ _ => rfl⟩

/-! #### 5.3 `slotReadNodeArrElemStmt` -/

def NodeSlotLayout.arrBaseOff (_L : NodeSlotLayout cp) : NodeArrKind → ℤ
  | .dense => 12 + 2 * (cp.n : ℤ)
  | .hist => 9 + 2 * swapPoolStride cp.n
  | .res => 12 + swapPoolStride cp.n + 2 * (cp.n : ℤ)

def NodeSlotLayout.slotReadNodeArrElemStmt (k : NodeArrKind) (sR iR oR : ℤ) : ArithRAMStmt :=
  .writeWordHeap engScrTbl (.lit oR)
    (.readHeap L.nodeWTbl
      (.add (.add (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ)))
                  (.lit (L.arrBaseOff k)))
            (.readHeap engScrTbl (.lit iR))))

theorem NodeSlotLayout.zeroRand_slotReadNodeArrElemStmt (k : NodeArrKind) (sR iR oR : ℤ) :
    ZeroRandStmt (L.slotReadNodeArrElemStmt k sR iR oR) :=
  .writeWordHeap _ _ _

theorem NodeSlotLayout.exec_slotReadNodeArrElemStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot idx : ℕ) (k : NodeArrKind)
    (hidx : idx < (evalNodeArr mn k).length) (sR iR oR : ℤ)
    (_hslot : slot < M_slots cp)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (_hiR0 : 0 ≤ iR) (_hiR64 : iR < 64)
    (hoR0 : 0 ≤ oR) (hoR64 : oR < 64)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ))
    (hiR_v : H3a.wRead m₀ engScrTbl iR = (idx : ℤ)) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotReadNodeArrElemStmt k sR iR oR) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        H3a.wRead m₁ engScrTbl oR = ((evalNodeArr mn k)[idx]'hidx : ℤ) ∧
        (∀ mn' s', s' < M_slots cp → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ i, i ≠ oR → H3a.wRead m₁ engScrTbl i = H3a.wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      L.slotReadCost := by
  have hT_eng : engScrTbl < L.TW := by have := L.hTW; unfold engScrTbl; omega
  have hBW64 : 64 ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  have hne_node_eng : L.nodeWTbl ≠ engScrTbl := by
    have := L.hNodeWTbl_lo; unfold engScrTbl; omega
  rcases henc₀.2 with ⟨_, _, _, _, _, _, _, _, hh_el,
    ⟨Pd, _, hPd_l, hPd_e⟩, ⟨Pr, _, hPr_l, hPr_e⟩, _, _⟩
  have hval : H3a.wRead m₀ L.nodeWTbl (L.slotBaseW slot + L.arrBaseOff k + (idx : ℤ)) =
      ((evalNodeArr mn k)[idx]'hidx : ℤ) := by
    cases k with
    | dense =>
        dsimp [NodeSlotLayout.arrBaseOff, evalNodeArr] at hidx ⊢
        have hidx_sz : idx < Pd.sz := by
          have := length_swapPoolToList Pd; rw [hPd_l] at this; omega
        have hoff : L.slotBaseW slot + (12 + 2 * (cp.n : ℤ)) + (idx : ℤ) =
            nodeDensePoolOff (L.slotBaseW slot) + 4 + 2 * (cp.n : ℤ) + (idx : ℤ) := by
          unfold nodeDensePoolOff; ring
        have hget : mn.nd.denseArr[idx]'hidx = Pd.arr idx := by
          have hidx_l : idx < (swapPoolToList Pd).length := by simp [hidx_sz]
          have h1 : (swapPoolToList Pd)[idx]'hidx_l = mn.nd.denseArr[idx]'hidx := by
            congr 1
          rw [← h1, getElem_swapPoolToList]
        rw [hoff, hPd_e.2.2.2.2 idx hidx_sz, hget]
    | hist =>
        dsimp [NodeSlotLayout.arrBaseOff, evalNodeArr] at hidx ⊢
        have hoff : L.slotBaseW slot + (9 + 2 * swapPoolStride cp.n) + (idx : ℤ) =
            nodeHistOff cp.n (L.slotBaseW slot) + 1 + (idx : ℤ) := by
          unfold nodeHistOff; ring
        rw [hoff]; exact hh_el idx hidx
    | res =>
        dsimp [NodeSlotLayout.arrBaseOff, evalNodeArr] at hidx ⊢
        have hidx_sz : idx < Pr.sz := by
          have := length_swapPoolToList Pr; rw [hPr_l] at this; omega
        have hoff : L.slotBaseW slot + (12 + swapPoolStride cp.n + 2 * (cp.n : ℤ)) + (idx : ℤ) =
            nodeResPoolOff cp.n (L.slotBaseW slot) + 4 + 2 * (cp.n : ℤ) + (idx : ℤ) := by
          unfold nodeResPoolOff; ring
        have hget : mn.resArr[idx]'hidx = Pr.arr idx := by
          have hidx_l : idx < (swapPoolToList Pr).length := by simp [hidx_sz]
          have h1 : (swapPoolToList Pr)[idx]'hidx_l = mn.resArr[idx]'hidx := by
            congr 1
          rw [← h1, getElem_swapPoolToList]
        rw [hoff, hPr_e.2.2.2.2 idx hidx_sz, hget]
  refine ExecDet.wWrite inp engScrTbl (.lit oR) _ oR ((evalNodeArr mn k)[idx]'hidx : ℤ)
    hfp₀ hT_eng hoR0 (by omega) rfl
    (by simp only [evalIntExpr]
        change H3a.wRead m₀ L.nodeWTbl
          ((H3a.wRead m₀ engScrTbl sR * (L.nodeWStride : ℤ) + L.arrBaseOff k) +
            H3a.wRead m₀ engScrTbl iR) = _
        rw [hsR_v, hiR_v, ← L.slotBaseW_eq_mul, hval])
    (by unfold NodeSlotLayout.slotReadCost; simp [intExprOps]; try omega) ?_
  obtain ⟨hsr₁, henc₁⟩ := L.ro_preserve hsr₀
    (fun _ => wRead_wWrite_of_ne _ _ (Or.inl hne_node_eng))
    (fun _ => rfl) (fun _ => rfl)
  exact ⟨hsr₁, wRead_wWrite_self _ _ _ _, henc₁,
    fun _ _ hne _ => wRead_wWrite_of_ne _ _ (Or.inl hne),
    fun _ hne => wRead_wWrite_of_ne _ _ (Or.inr hne),
    fun _ _ _ => rfl⟩

/-! #### 5.5 `slotReadCenterCoordStmt` -/

def NodeSlotLayout.slotReadCenterCoordStmt (sR cR oRI : ℤ) : ArithRAMStmt :=
  .writeRealHeap engRealTbl (.lit oRI)
    (.readRealHeap L.nodeRTbl
      (.add (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeRStride : ℤ)))
            (.readHeap engScrTbl (.lit cR))))

theorem NodeSlotLayout.zeroRand_slotReadCenterCoordStmt (sR cR oRI : ℤ) :
    ZeroRandStmt (L.slotReadCenterCoordStmt sR cR oRI) :=
  .writeRealHeap _ _ _

theorem NodeSlotLayout.exec_slotReadCenterCoordStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (mn : MNode cp) (slot : ℕ) (c : Fin d) (sR cR oRI : ℤ)
    (_hslot : slot < M_slots cp)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (_hcR0 : 0 ≤ cR) (_hcR64 : cR < 64)
    (hoRI1 : 1 ≤ oRI) (hoRIB : oRI < (L.BR : ℤ))
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ))
    (hcR_v : H3a.wRead m₀ engScrTbl cR = (c.val : ℤ)) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotReadCenterCoordStmt sR cR oRI) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        H3a.rRead m₁ engRealTbl oRI = euclideanCoord mn.nd.o c ∧
        (∀ mn' s', s' < M_slots cp → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ t < 2, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i) ∧
        (∀ i, i ≠ oRI → H3a.rRead m₁ engRealTbl i = H3a.rRead m₀ engRealTbl i))
      L.slotReadCost := by
  have hT_engR : engRealTbl < L.TR := by have := L.hTR; unfold engRealTbl; omega
  have hne_nodeR : L.nodeRTbl ≠ engRealTbl := by have := L.hNodeRTbl_lo; unfold engRealTbl; omega
  rcases henc₀.2 with ⟨_, _, _, ho_e, _⟩
  refine ExecDet.rWrite inp engRealTbl (.lit oRI) _ oRI (euclideanCoord mn.nd.o c)
    hfp₀ hT_engR (by omega) hoRIB rfl
    (by simp only [evalRealExpr, evalIntExpr]
        change H3a.rRead m₀ L.nodeRTbl
          (H3a.wRead m₀ engScrTbl sR * (L.nodeRStride : ℤ) + H3a.wRead m₀ engScrTbl cR) = _
        rw [hsR_v, hcR_v, ← L.slotBaseR_eq_mul]; exact ho_e c)
    (by unfold NodeSlotLayout.slotReadCost; simp [intExprOps, realExprOps]; try omega) ?_
  obtain ⟨hsr₁, henc₁⟩ := L.ro_preserve
    (m₁ := H3a.rWrite m₀ engRealTbl oRI (euclideanCoord mn.nd.o c)) hsr₀
    (fun _ => rfl)
    (fun _ => rRead_rWrite_of_ne _ _ (Or.inl hne_nodeR))
    (fun _ => rRead_rWrite_of_ne _ _ (Or.inl (by decide)))
  exact ⟨hsr₁, rRead_rWrite_self _ _ _ _, henc₁,
    fun _ _ _ => rfl,
    fun t ht2 _ => rRead_rWrite_of_ne _ _ (Or.inl (by unfold engRealTbl; omega)),
    fun _ hne => rRead_rWrite_of_ne _ _ (Or.inr hne)⟩

end SlotReadOps

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
