import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Stage4PrimA
import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Layout
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a3
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 1. Generic Sequential List Fold Combinator (`seqList`) -/

def seqList {α : Type*} (xs : List α) (f : α → ArithRAMStmt) : ArithRAMStmt :=
  xs.foldr (fun x acc => .seq (f x) acc) .skip

theorem zeroRand_seqList {α : Type*} (xs : List α) (f : α → ArithRAMStmt)
    (hf : ∀ x ∈ xs, ZeroRandStmt (f x)) : ZeroRandStmt (seqList xs f) := by
  induction xs with
  | nil => exact .skip
  | cons x tl ih =>
      exact .seq (hf x List.mem_cons_self) (ih (fun y hy => hf y (List.mem_cons_of_mem _ hy)))

theorem exec_seqList {α β : Type*} {d TW BW TR BR : ℕ} {inp : ArithRAMInput d}
    (xs : List α) (f : α → ArithRAMStmt) (step : β → α → β)
    (Inv : β → ArithRAMMemory → Prop) (C_step : ℕ)
    {b₀ : β} {m₀ : ArithRAMMemory}
    (hfp₀ : InFootprint TW BW TR BR m₀) (hInv₀ : Inv b₀ m₀)
    (hstep : ∀ x ∈ xs, ∀ b m, Inv b m → InFootprint TW BW TR BR m →
      ExecDet TW BW TR BR inp (f x) m (Inv (step b x)) C_step) :
    ExecDet TW BW TR BR inp (seqList xs f) m₀ (Inv (xs.foldl step b₀))
      (1 + xs.length * C_step) := by
  induction xs generalizing b₀ m₀ with
  | nil =>
      exact ExecDet.skip inp hfp₀ hInv₀ (by omega)
  | cons x tl ih =>
      dsimp only [seqList, List.foldr_cons, List.foldl_cons, List.length_cons]
      refine ExecDet.seq' (1 + tl.length * C_step)
        (hstep x List.mem_cons_self b₀ m₀ hInv₀ hfp₀)
        (by have : (tl.length + 1) * C_step = C_step + tl.length * C_step := by ring
            omega) ?_
      intro m₁ hI₁ hfp₁
      exact ih hfp₁ hI₁ (fun y hy => hstep y (List.mem_cons_of_mem _ hy))

/-! ### 2. `decodeCoinWordStmt`: MSB-First `q`-Bit Decoder with Full Register Frame -/

def decodeCoinWordStmt (offReg ctrReg dstReg : ℤ) (q : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit dstReg) (.lit 0))
    (forLoopStmt engScrTbl ctrReg q
      (.writeWordHeap engScrTbl (.lit dstReg)
        (.add (.mul (.lit 2) (.readHeap engScrTbl (.lit dstReg)))
              (.readHeap coinTbl (.add (.readHeap engScrTbl (.lit offReg))
                                       (.readHeap engScrTbl (.lit ctrReg)))))))

theorem zeroRand_decodeCoinWordStmt (offReg ctrReg dstReg : ℤ) (q : ℕ) :
    ZeroRandStmt (decodeCoinWordStmt offReg ctrReg dstReg q) :=
  .seq (.writeWordHeap _ _ _) (zeroRand_forLoopStmt (.writeWordHeap _ _ _))

private lemma bitsFnToNat_prefix_rec {q : ℕ} (f : Fin q → Bool) :
    ∀ (k : ℕ) (hk : k ≤ q),
      (Nat.recOn k 0 (fun i acc =>
        if hi : i < q then 2 * acc + (if f ⟨i, hi⟩ then 1 else 0) else acc) : ℕ) =
      bitsFnToNat k (fun j : Fin k => f ⟨j.val, lt_of_lt_of_le j.isLt hk⟩)
  | 0, _ => by simp [bitsFnToNat]
  | k + 1, hk => by
      have hk_lt : k < q := by omega
      have ih := bitsFnToNat_prefix_rec f k (by omega)
      change (if hi : k < q then 2 * _ + (if f ⟨k, hi⟩ then 1 else 0) else _) = _
      dsimp [Nat.recOn] at ih
      rw [dif_pos hk_lt, ih]
      rfl

theorem exec_decodeCoinWordStmt {d TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (offReg ctrReg dstReg baseOff : ℤ) (q : ℕ) (bits : Fin q → Bool)
    (hTW : 9 ≤ TW) (hBW : 64 ≤ BW)
    (hoff0 : 0 ≤ offReg) (hoffB : offReg < 50)
    (hctr0 : 0 ≤ ctrReg) (hctrB : ctrReg < 50)
    (hdst0 : 0 ≤ dstReg) (hdstB : dstReg < 50)
    (hne_oc : offReg ≠ ctrReg) (hne_od : offReg ≠ dstReg) (hne_cd : ctrReg ≠ dstReg)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hoff_val : wRead m₀ engScrTbl offReg = baseOff)
    (hcoins : ∀ j : Fin q, wRead m₀ coinTbl (baseOff + (j.val : ℤ)) = if bits j then 1 else 0) :
    ExecDet TW BW TR BR inp (decodeCoinWordStmt offReg ctrReg dstReg q) m₀
      (fun m₁ =>
        wRead m₁ engScrTbl dstReg = ((bitsFnToFin q bits).val : ℤ) ∧
        (∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ r, r ≠ ctrReg → r ≠ dstReg → wRead m₁ engScrTbl r = wRead m₀ engScrTbl r) ∧
        (∀ rt i, rRead m₁ rt i = rRead m₀ rt i))
      (30 + 30 * q) := by
  have hT_scr : engScrTbl < TW := by show 8 < TW; omega
  let pfx : ℕ → ℕ := fun k =>
    Nat.recOn k (0 : ℕ) (fun i acc =>
      if hi : i < q then 2 * acc + (if bits ⟨i, hi⟩ then (1 : ℕ) else 0) else acc)
  unfold decodeCoinWordStmt
  refine ExecDet.seq' (18 + 30 * q)
    (ExecDet.wWriteEq inp engScrTbl (.lit dstReg) (.lit 0) dstReg 0
      hfp₀ hT_scr hdst0 (by omega) rfl rfl (by simp [intExprOps])) (by omega) ?_
  intro mA hmA hfpA; subst hmA
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    wRead m engScrTbl dstReg = Int.ofNat (pfx k) ∧
    (∀ t, t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ r, r ≠ ctrReg → r ≠ dstReg → wRead m engScrTbl r = wRead m₀ engScrTbl r) ∧
    (∀ rt i, rRead m rt i = rRead m₀ rt i)
  refine (ExecDet.forLoop engScrTbl ctrReg q _ Inv 20 hfpA hT_scr hctr0 (by omega)
    ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr hne_cd.symm), wRead_wWrite_self]; rfl,
     fun t ht i => by rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)],
     fun r hrc hrd => by rw [wRead_wWrite_of_ne _ _ (Or.inr hrc), wRead_wWrite_of_ne _ _ (Or.inr hrd)],
     fun _ _ => rfl⟩ ?_).mono ?_ (by omega)
  · intro k hk m ⟨hdst_m, hwt_m, hwr_m, hrr_m⟩ hctr_m hfp_m
    have hoff_m : wRead m engScrTbl offReg = baseOff := (hwr_m offReg hne_oc hne_od).trans hoff_val
    have hbit_m : wRead m coinTbl (baseOff + (k : ℤ)) = if bits ⟨k, hk⟩ then 1 else 0 :=
      (hwt_m coinTbl (by decide) _).trans (hcoins ⟨k, hk⟩)
    let nxtVal : ℤ := 2 * Int.ofNat (pfx k) + (if bits ⟨k, hk⟩ then 1 else 0)
    refine ExecDet.wWrite inp engScrTbl (.lit dstReg) _ dstReg nxtVal
      hfp_m hT_scr hdst0 (by omega) rfl
      (by simp only [evalIntExpr]
          change 2 * wRead m engScrTbl dstReg +
            wRead m coinTbl (wRead m engScrTbl offReg + wRead m engScrTbl ctrReg) = nxtVal
          rw [hdst_m, hoff_m, hctr_m, hbit_m])
      (by simp [intExprOps]) ?_
    refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr hne_cd)]; exact hctr_m, ?_, ?_, ?_, ?_⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr hne_cd.symm), wRead_wWrite_self]
      have hpfx_step : pfx (k + 1) = 2 * pfx k + (if bits ⟨k, hk⟩ then 1 else 0) := by
        change (if h : k < q then 2 * pfx k + (if bits ⟨k, h⟩ then 1 else 0) else pfx k) = _
        rw [dif_pos hk]
      rw [hpfx_step]; dsimp only [nxtVal]
      cases bits ⟨k, hk⟩ <;> (simp only [Int.ofNat_eq_coe]; push_cast; ring)
    · intro t ht i
      rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
      exact hwt_m t ht i
    · intro r hrc hrd
      rw [wRead_wWrite_of_ne _ _ (Or.inr hrc), wRead_wWrite_of_ne _ _ (Or.inr hrd)]
      exact hwr_m r hrc hrd
    · intro rt i; simp only [rRead_wWrite]; exact hrr_m rt i
  · intro m₁ ⟨hdst₁, hwt₁, hwr₁, hrr₁⟩ _
    refine ⟨?_, hwt₁, hwr₁, hrr₁⟩
    rw [hdst₁]
    have hfinal := bitsFnToNat_prefix_rec bits q le_rfl
    exact congrArg Int.ofNat hfinal

/-! ### 3. `evalExactLeafPairStmt`: `O(B_scan^2 * d)` Exact Pairwise Leaf Scan -/

def EncOptPairSq {d : ℕ} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (hasR uR vR sqR : ℤ) (opt : Option (ℕ × ℕ)) (mem : ArithRAMMemory) : Prop :=
  EncOptPair hasR uR vR opt mem ∧
  ∀ b1 b2, opt = some (b1, b2) → rRead mem engRealTbl sqR = ‖pts b1 - pts b2‖ ^ 2

theorem EncOptPairSq.wWrite_ne {d : ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {hasR uR vR sqR : ℤ} {opt : Option (ℕ × ℕ)} {m : ArithRAMMemory}
    (h : EncOptPairSq pts hasR uR vR sqR opt m) {t : ℕ} {idx val : ℤ}
    (hh : t ≠ engScrTbl ∨ hasR ≠ idx)
    (hu : t ≠ engScrTbl ∨ uR ≠ idx)
    (hv : t ≠ engScrTbl ∨ vR ≠ idx) :
    EncOptPairSq pts hasR uR vR sqR opt (H3a.wWrite m t idx val) := by
  refine ⟨?_, fun b1 b2 hs => by rw [rRead_wWrite]; exact h.2 b1 b2 hs⟩
  cases opt with
  | none => exact (wRead_wWrite_of_ne _ _ (hh.imp_left Ne.symm)).trans h.1
  | some uv =>
      rcases uv with ⟨b1, b2⟩
      exact ⟨(wRead_wWrite_of_ne _ _ (hh.imp_left Ne.symm)).trans h.1.1,
             (wRead_wWrite_of_ne _ _ (hu.imp_left Ne.symm)).trans h.1.2.1,
             (wRead_wWrite_of_ne _ _ (hv.imp_left Ne.symm)).trans h.1.2.2⟩

def stepOptPairStmt (d : ℕ) : ArithRAMStmt :=
  .seq (pairDistSqStmt 18 19 4 d)
    (.ite (.or (.intEq (.readHeap engScrTbl (.lit 12)) (.lit 0))
               (.realLt (.readRealHeap engRealTbl (.lit 2)) (.readRealHeap engRealTbl (.lit 4))))
      (.seq (.writeWordHeap engScrTbl (.lit 12) (.lit 1))
      (.seq (.writeWordHeap engScrTbl (.lit 13) (.readHeap engScrTbl (.lit 18)))
      (.seq (.writeWordHeap engScrTbl (.lit 14) (.readHeap engScrTbl (.lit 19)))
            (.writeRealHeap engRealTbl (.lit 2) (.readRealHeap engRealTbl (.lit 4))))))
      .skip)

theorem zeroRand_stepOptPairStmt (d : ℕ) : ZeroRandStmt (stepOptPairStmt d) :=
  .seq (zeroRand_pairDistSqStmt 18 19 4 d)
    (.ite (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (.writeRealHeap _ _ _)))) .skip)

theorem exec_stepOptPairStmt {d TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    {cur : Option (ℕ × ℕ)} {u v : ℕ}
    (hTW : 9 ≤ TW) (hBW : 64 ≤ BW) (hTR : 3 ≤ TR) (hBR : 16 ≤ BR)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hcur : EncOptPairSq pts 12 13 14 2 cur m₀)
    (hu_m : wRead m₀ engScrTbl 18 = (u : ℤ))
    (hv_m : wRead m₀ engScrTbl 19 = (v : ℤ))
    (hu_pts : ∀ c : Fin d, rRead m₀ ptsRTbl (((u * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts u) c)
    (hv_pts : ∀ c : Fin d, rRead m₀ ptsRTbl (((v * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts v) c) :
    ExecDet TW BW TR BR inp (stepOptPairStmt d) m₀
      (fun m₁ =>
        EncOptPairSq pts 12 13 14 2 (stepOptPair pts cur (u, v)) m₁ ∧
        (∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ r, r < 40 → r ≠ 12 → r ≠ 13 → r ≠ 14 → wRead m₁ engScrTbl r = wRead m₀ engScrTbl r) ∧
        (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m₁ rt i = rRead m₀ rt i) ∧
        (∀ ri, ri < 4 → ri ≠ 2 → rRead m₁ engRealTbl ri = rRead m₀ engRealTbl ri))
      (160 + 80 * d) := by
  have hT_scr : engScrTbl < TW := by show 8 < TW; omega
  have hT_real : engRealTbl < TR := by show 2 < TR; omega
  unfold stepOptPairStmt
  refine ExecDet.seq' 80
    (exec_pairDistSqStmt inp pts 18 19 4 hTW hBW hTR hBR (by omega) (by omega) (by omega) (by omega)
      hfp₀ hu_m hv_m hu_pts hv_pts) (by omega) ?_
  intro m₁ ⟨hdsq, hwt₁, hwr₁, hrt₁, hrr₁⟩ hfp₁
  have hu₁ : wRead m₁ engScrTbl 18 = (u : ℤ) := (hwr₁ 18 (by omega)).trans hu_m
  have hv₁ : wRead m₁ engScrTbl 19 = (v : ℤ) := (hwr₁ 19 (by omega)).trans hv_m
  refine ExecDet.ite_le (C_c := 15) (C_b := 65) _ _ _
    (by simp [condExprOps, realExprOps, intExprOps])
    (fun htrue => ?_) (fun hfalse => ?_)
  · have hstep_some : stepOptPair pts cur (u, v) = some (u, v) := by
      cases cur with
      | none => rfl
      | some best =>
          rcases best with ⟨b1, b2⟩
          rcases hcur.1 with ⟨h12_0, _, _⟩
          have h12_1 : wRead m₁ engScrTbl 12 = 1 := (hwr₁ 12 (by omega)).trans h12_0
          have hr2_1 : rRead m₁ engRealTbl 2 = ‖pts b1 - pts b2‖ ^ 2 :=
            (hrr₁ 2 (by omega) (by omega) (by omega)).trans (hcur.2 b1 b2 rfl)
          simp only [evalArithCond, evalRealExpr, evalIntExpr] at htrue
          change (decide (wRead m₁ engScrTbl 12 = 0) ||
                  decide (rRead m₁ engRealTbl 2 < rRead m₁ engRealTbl 4)) = true at htrue
          rw [h12_1, hr2_1, hdsq] at htrue
          simp only [Bool.or_eq_true, decide_eq_true_eq] at htrue
          rcases htrue with hbad | hlt
          · omega
          · unfold stepOptPair; exact if_pos hlt
    refine ExecDet.seq' 50
      (ExecDet.wWriteEq inp engScrTbl (.lit 12) (.lit 1) 12 1 hfp₁ hT_scr (by omega) (by omega)
        rfl rfl (by simp [intExprOps])) (by omega) ?_
    intro m₂ hm₂ hfp₂; subst hm₂
    refine ExecDet.seq' 35
      (ExecDet.wWriteEq inp engScrTbl (.lit 13) (.readHeap engScrTbl (.lit 18)) 13 (u : ℤ)
        hfp₂ hT_scr (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; change wRead _ engScrTbl 18 = _
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hu₁)
        (by simp [intExprOps])) (by omega) ?_
    intro m₃ hm₃ hfp₃; subst hm₃
    refine ExecDet.seq' 20
      (ExecDet.wWriteEq inp engScrTbl (.lit 14) (.readHeap engScrTbl (.lit 19)) 14 (v : ℤ)
        hfp₃ hT_scr (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; change wRead _ engScrTbl 19 = _
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_of_ne _ _ (Or.inr (by decide))]
            exact hv₁)
        (by simp [intExprOps])) (by omega) ?_
    intro m₄ hm₄ hfp₄; subst hm₄
    refine ExecDet.rWrite inp engRealTbl (.lit 2) (.readRealHeap engRealTbl (.lit 4))
      2 (‖pts u - pts v‖ ^ 2) hfp₄ hT_real (by omega) (by omega) rfl
      (by simp only [evalRealExpr, evalIntExpr]; change rRead _ engRealTbl 4 = _
          simp only [rRead_wWrite]; exact hdsq)
      (by simp [intExprOps, realExprOps]) ?_
    rw [hstep_some]
    refine ⟨⟨⟨by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                      wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
              by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
              by rw [wRead_rWrite, wRead_wWrite_self]⟩,
            fun b1 b2 heq => by
              injection heq with hp; rcases Prod.mk.inj hp with ⟨rfl, rfl⟩
              exact rRead_rWrite_self _ _ _ _⟩,
      fun t ht i => by
        rw [wRead_rWrite]
        (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)])
        exact hwt₁ t ht i,
      fun r hr40 h12 h13 h14 => by
        rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr h14),
            wRead_wWrite_of_ne _ _ (Or.inr h13), wRead_wWrite_of_ne _ _ (Or.inr h12)]
        exact hwr₁ r (by omega),
      fun rt hrt i => by
        rw [rRead_rWrite_of_ne _ _ (Or.inl hrt)]
        simp only [rRead_wWrite]; exact hrt₁ rt hrt i,
      fun ri _ hri2 => by
        rw [rRead_rWrite_of_ne _ _ (Or.inr hri2)]
        simp only [rRead_wWrite]; exact hrr₁ ri (by omega) (by omega) (by omega)⟩
  · cases cur with
    | none =>
        have h12_1 : wRead m₁ engScrTbl 12 = 0 := (hwr₁ 12 (by omega)).trans hcur.1
        simp only [evalArithCond, evalRealExpr, evalIntExpr] at hfalse
        change (decide (wRead m₁ engScrTbl 12 = 0) ||
                decide (rRead m₁ engRealTbl 2 < rRead m₁ engRealTbl 4)) = false at hfalse
        rw [h12_1] at hfalse; simp at hfalse
    | some best =>
        rcases best with ⟨b1, b2⟩
        rcases hcur.1 with ⟨h12_0, h13_0, h14_0⟩
        have h12_1 : wRead m₁ engScrTbl 12 = 1 := (hwr₁ 12 (by omega)).trans h12_0
        have h13_1 : wRead m₁ engScrTbl 13 = (b1 : ℤ) := (hwr₁ 13 (by omega)).trans h13_0
        have h14_1 : wRead m₁ engScrTbl 14 = (b2 : ℤ) := (hwr₁ 14 (by omega)).trans h14_0
        have hr2_1 : rRead m₁ engRealTbl 2 = ‖pts b1 - pts b2‖ ^ 2 :=
          (hrr₁ 2 (by omega) (by omega) (by omega)).trans (hcur.2 b1 b2 rfl)
        have hnot_lt : ¬ ‖pts b1 - pts b2‖ ^ 2 < ‖pts u - pts v‖ ^ 2 := by
          simp only [evalArithCond, evalRealExpr, evalIntExpr] at hfalse
          change (decide (wRead m₁ engScrTbl 12 = 0) ||
                  decide (rRead m₁ engRealTbl 2 < rRead m₁ engRealTbl 4)) = false at hfalse
          rw [h12_1, hr2_1, hdsq] at hfalse
          intro hlt
          rw [decide_eq_true hlt] at hfalse; simp at hfalse
        have hstep_keep : stepOptPair pts (some (b1, b2)) (u, v) = some (b1, b2) := by
          unfold stepOptPair; exact if_neg hnot_lt
        refine ExecDet.skip inp hfp₁ ?_ (by omega)
        rw [hstep_keep]
        exact ⟨⟨⟨h12_1, h13_1, h14_1⟩,
          fun x1 x2 heq => by
            injection heq with hp; rcases Prod.mk.inj hp with ⟨rfl, rfl⟩; exact hr2_1⟩,
          hwt₁,
          fun r hr40 _ _ _ => hwr₁ r (by omega),
          hrt₁,
          fun ri hri4 _ => hrr₁ ri (by omega) (by omega) (by omega)⟩

def leafInnerLoopStmt (B_scan d : ℕ) : ArithRAMStmt :=
  forLoopStmt engScrTbl 16 B_scan
    (.ite (.intLt (.readHeap engScrTbl (.lit 16)) (.readHeap engScrTbl (.lit 17)))
      (.seq (.writeWordHeap engScrTbl (.lit 19)
              (.readHeap engArrTbl (.add (.lit leafElemOff) (.readHeap engScrTbl (.lit 16)))))
        (.ite (.not (.intEq (.readHeap engScrTbl (.lit 19)) (.readHeap engScrTbl (.lit 18))))
          (stepOptPairStmt d)
          .skip))
      .skip)

theorem zeroRand_leafInnerLoopStmt (B_scan d : ℕ) : ZeroRandStmt (leafInnerLoopStmt B_scan d) :=
  zeroRand_forLoopStmt
    (.ite (.seq (.writeWordHeap _ _ _) (.ite (zeroRand_stepOptPairStmt d) .skip)) .skip)

theorem exec_leafInnerLoopStmt {d TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    (leafArr : List ℕ) (B_scan u : ℕ) (acc : Option (ℕ × ℕ))
    (hTW : 9 ≤ TW) (hBW : 64 ≤ BW) (hTR : 3 ≤ TR) (hBR : 16 ≤ BR)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hacc : EncOptPairSq pts 12 13 14 2 acc m₀)
    (hlen_m : wRead m₀ engScrTbl 17 = (leafArr.length : ℤ))
    (hu_m : wRead m₀ engScrTbl 18 = (u : ℤ))
    (helem : ∀ i (hi : i < leafArr.length),
      wRead m₀ engArrTbl (leafElemOff + (i : ℤ)) = (leafArr[i]'hi : ℤ))
    (hu_pts : ∀ c : Fin d, rRead m₀ ptsRTbl (((u * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts u) c)
    (hleaf_pts : ∀ x ∈ leafArr, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) :
    ExecDet TW BW TR BR inp (leafInnerLoopStmt B_scan d) m₀
      (fun m₁ =>
        EncOptPairSq pts 12 13 14 2 (leafInnerFold pts leafArr u B_scan acc) m₁ ∧
        (∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ r, r < 16 → r ≠ 12 → r ≠ 13 → r ≠ 14 → wRead m₁ engScrTbl r = wRead m₀ engScrTbl r) ∧
        wRead m₁ engScrTbl 17 = (leafArr.length : ℤ) ∧
        (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m₁ rt i = rRead m₀ rt i) ∧
        (∀ ri, ri < 2 → rRead m₁ engRealTbl ri = rRead m₀ engRealTbl ri))
      (10 + B_scan * (210 + 80 * d)) := by
  have hT_scr : engScrTbl < TW := by show 8 < TW; omega
  unfold leafInnerLoopStmt
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    EncOptPairSq pts 12 13 14 2 (leafInnerFold pts leafArr u k acc) m ∧
    (∀ t, t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ r, r < 16 → r ≠ 12 → r ≠ 13 → r ≠ 14 → wRead m engScrTbl r = wRead m₀ engScrTbl r) ∧
    wRead m engScrTbl 17 = (leafArr.length : ℤ) ∧
    wRead m engScrTbl 18 = (u : ℤ) ∧
    (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m rt i = rRead m₀ rt i) ∧
    (∀ ri, ri < 2 → rRead m engRealTbl ri = rRead m₀ engRealTbl ri)
  have hmul_in : B_scan * (200 + 80 * d + 6) ≤ B_scan * (210 + 80 * d) :=
    Nat.mul_le_mul_left B_scan (by omega)
  refine (ExecDet.forLoop engScrTbl 16 B_scan _ Inv (200 + 80 * d) hfp₀ hT_scr (by omega) (by omega)
    ⟨hacc.wWrite_ne (Or.inr (by decide)) (Or.inr (by decide)) (Or.inr (by decide)),
     fun t ht i => wRead_wWrite_of_ne _ _ (Or.inl ht),
     fun r hr16 _ _ _ => wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
     (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hlen_m,
     (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hu_m,
     fun _ _ _ => rfl,
     fun _ _ => rfl⟩ ?_).mono
    (fun m₁ ⟨h1, h2, h3, h4, _, h6, h7⟩ _ => ⟨h1, h2, h3, h4, h6, h7⟩) (by omega)
  intro iv _ m ⟨hcur_m, hwt_m, hwr_m, h17_m, h18_m, hrt_m, hrr_m⟩ hctr_m hfp_m
  have hfold_succ : ∀ nxt,
      (if hiv : iv < leafArr.length then
        let v := leafArr[iv]'hiv
        if v ≠ u then stepOptPair pts (leafInnerFold pts leafArr u iv acc) (u, v)
        else leafInnerFold pts leafArr u iv acc
       else leafInnerFold pts leafArr u iv acc) = nxt →
      leafInnerFold pts leafArr u (iv + 1) acc = nxt := by
    intro nxt heq
    unfold leafInnerFold at heq ⊢
    rw [List.range_succ, List.foldl_append, List.foldl_cons, List.foldl_nil]
    exact heq
  have hPreserveCtr : ∀ {m' : ArithRAMMemory},
      EncOptPairSq pts 12 13 14 2 (leafInnerFold pts leafArr u (iv + 1) acc) m' →
      wRead m' engScrTbl 16 = (iv : ℤ) →
      (∀ t, t ≠ engScrTbl → ∀ i, wRead m' t i = wRead m₀ t i) →
      (∀ r, r < 16 → r ≠ 12 → r ≠ 13 → r ≠ 14 → wRead m' engScrTbl r = wRead m₀ engScrTbl r) →
      wRead m' engScrTbl 17 = (leafArr.length : ℤ) →
      wRead m' engScrTbl 18 = (u : ℤ) →
      (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m' rt i = rRead m₀ rt i) →
      (∀ ri, ri < 2 → rRead m' engRealTbl ri = rRead m₀ engRealTbl ri) →
      wRead m' engScrTbl 16 = (iv : ℤ) ∧ Inv (iv + 1) (H3a.wWrite m' engScrTbl 16 ((iv : ℤ) + 1)) := by
    intro m' henc' hc16 hwt' hwr' h17' h18' hrt' hrr'
    exact ⟨hc16,
      henc'.wWrite_ne (Or.inr (by decide)) (Or.inr (by decide)) (Or.inr (by decide)),
      fun t ht i => (wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (hwt' t ht i),
      fun r hr16 h12 h13 h14 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hwr' r hr16 h12 h13 h14),
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans h17',
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans h18',
      fun rt hrt i => by rw [rRead_wWrite]; exact hrt' rt hrt i,
      fun ri hri2 => by rw [rRead_wWrite]; exact hrr' ri hri2⟩
  refine ExecDet.ite_le (C_c := 10) (C_b := 190 + 80 * d) _ _ _
    (by simp [condExprOps, intExprOps])
    (fun hlt_b => ?_) (fun hge_b => ?_)
  · have hiv : iv < leafArr.length := by
      simp only [evalArithCond, evalIntExpr] at hlt_b
      change decide (wRead m engScrTbl 16 < wRead m engScrTbl 17) = true at hlt_b
      rw [hctr_m, h17_m] at hlt_b
      exact Int.ofNat_lt.mp (of_decide_eq_true hlt_b)
    let v := leafArr[iv]'hiv
    have hv_arr : wRead m engArrTbl (leafElemOff + (iv : ℤ)) = (v : ℤ) :=
      (hwt_m engArrTbl (by decide) _).trans (helem iv hiv)
    refine ExecDet.seq' (175 + 80 * d)
      (ExecDet.wWriteEq inp engScrTbl (.lit 19)
        (.readHeap engArrTbl (.add (.lit leafElemOff) (.readHeap engScrTbl (.lit 16))))
        19 (v : ℤ) hfp_m hT_scr (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; change wRead m engArrTbl (leafElemOff + wRead m engScrTbl 16) = _
            rw [hctr_m, hv_arr])
        (by simp [intExprOps])) (by omega) ?_
    intro mA hmA hfpA; subst hmA
    have h18_A : wRead (H3a.wWrite m engScrTbl 19 (v : ℤ)) engScrTbl 18 = (u : ℤ) :=
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans h18_m
    have hcur_A : EncOptPairSq pts 12 13 14 2 (leafInnerFold pts leafArr u iv acc)
        (H3a.wWrite m engScrTbl 19 (v : ℤ)) :=
      hcur_m.wWrite_ne (Or.inr (by decide)) (Or.inr (by decide)) (Or.inr (by decide))
    refine ExecDet.ite_le (C_c := 10) (C_b := 165 + 80 * d) _ _ _
      (by simp [condExprOps, intExprOps])
      (fun hne_b => ?_) (fun heq_b => ?_)
    · have hvu : v ≠ u := by
        simp only [evalArithCond, evalIntExpr] at hne_b
        change (!decide (wRead _ engScrTbl 19 = wRead _ engScrTbl 18)) = true at hne_b
        rw [wRead_wWrite_self, h18_A] at hne_b
        intro h; subst h; simp at hne_b
      have hstep_eq : leafInnerFold pts leafArr u (iv + 1) acc =
          stepOptPair pts (leafInnerFold pts leafArr u iv acc) (u, v) :=
        hfold_succ _ (by rw [dif_pos hiv, if_pos hvu])
      have hu_pts_A : ∀ c : Fin d,
          rRead (H3a.wWrite m engScrTbl 19 (v : ℤ)) ptsRTbl (((u * d + c.val : ℕ) : ℤ)) =
            euclideanCoord (pts u) c :=
        fun c => (hrt_m ptsRTbl (by decide) _).trans (hu_pts c)
      have hv_pts_A : ∀ c : Fin d,
          rRead (H3a.wWrite m engScrTbl 19 (v : ℤ)) ptsRTbl (((v * d + c.val : ℕ) : ℤ)) =
            euclideanCoord (pts v) c :=
        fun c => (hrt_m ptsRTbl (by decide) _).trans (hleaf_pts v (List.getElem_mem hiv) c)
      refine (exec_stepOptPairStmt inp pts hTW hBW hTR hBR hfpA hcur_A h18_A
        (wRead_wWrite_self _ _ _ _) hu_pts_A hv_pts_A).mono ?_ (by omega)
      intro mB ⟨hencB, hwtB, hwrB, hrtB, hrrB⟩ _
      rw [← hstep_eq] at hencB
      exact hPreserveCtr hencB
        ((hwrB 16 (by omega) (by decide) (by decide) (by decide)).trans
          ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hctr_m))
        (fun t ht i => (hwtB t ht i).trans ((wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (hwt_m t ht i)))
        (fun r hr16 h12 h13 h14 =>
          (hwrB r (by omega) h12 h13 h14).trans
            ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hwr_m r hr16 h12 h13 h14)))
        ((hwrB 17 (by omega) (by decide) (by decide) (by decide)).trans
          ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans h17_m))
        ((hwrB 18 (by omega) (by decide) (by decide) (by decide)).trans h18_A)
        (fun rt hrt i => (hrtB rt hrt i).trans (by rw [rRead_wWrite]; exact hrt_m rt hrt i))
        (fun ri hri2 => (hrrB ri (by omega) (by omega)).trans (by rw [rRead_wWrite]; exact hrr_m ri hri2))
    · have hvu : v = u := by
        simp only [evalArithCond, evalIntExpr] at heq_b
        change (!decide (wRead _ engScrTbl 19 = wRead _ engScrTbl 18)) = false at heq_b
        rw [wRead_wWrite_self, h18_A] at heq_b
        have hd : decide ((v : ℤ) = (u : ℤ)) = true := by simpa using heq_b
        exact Int.ofNat.inj (of_decide_eq_true hd)
      have hstep_eq : leafInnerFold pts leafArr u (iv + 1) acc =
          leafInnerFold pts leafArr u iv acc :=
        hfold_succ _ (by rw [dif_pos hiv, if_neg (not_not.mpr hvu)])
      refine ExecDet.skip inp hfpA ?_ (by omega)
      rw [← hstep_eq] at hcur_A
      exact hPreserveCtr hcur_A
        ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hctr_m)
        (fun t ht i => (wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (hwt_m t ht i))
        (fun r hr16 h12 h13 h14 =>
          (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hwr_m r hr16 h12 h13 h14))
        ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans h17_m)
        h18_A
        (fun rt hrt i => by rw [rRead_wWrite]; exact hrt_m rt hrt i)
        (fun ri hri2 => by rw [rRead_wWrite]; exact hrr_m ri hri2)
  · have hiv : ¬ iv < leafArr.length := by
      simp only [evalArithCond, evalIntExpr] at hge_b
      change decide (wRead m engScrTbl 16 < wRead m engScrTbl 17) = false at hge_b
      rw [hctr_m, h17_m] at hge_b
      intro hlt; exact of_decide_eq_false hge_b (Int.ofNat_lt.mpr hlt)
    have hstep_eq : leafInnerFold pts leafArr u (iv + 1) acc =
        leafInnerFold pts leafArr u iv acc :=
      hfold_succ _ (by rw [dif_neg hiv])
    refine ExecDet.skip inp hfp_m ?_ (by omega)
    rw [← hstep_eq] at hcur_m
    exact hPreserveCtr hcur_m hctr_m hwt_m hwr_m h17_m h18_m hrt_m hrr_m

def evalExactLeafPairStmt (B_scan d : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 12) (.lit 0))
  (.seq (.writeWordHeap engScrTbl (.lit 17) (.readHeap engMetaTbl (.lit 2)))
    (forLoopStmt engScrTbl 15 B_scan
      (.ite (.intLt (.readHeap engScrTbl (.lit 15)) (.readHeap engScrTbl (.lit 17)))
        (.seq (.writeWordHeap engScrTbl (.lit 18)
                (.readHeap engArrTbl (.add (.lit leafElemOff) (.readHeap engScrTbl (.lit 15)))))
              (leafInnerLoopStmt B_scan d))
        .skip)))

theorem zeroRand_evalExactLeafPairStmt (B_scan d : ℕ) :
    ZeroRandStmt (evalExactLeafPairStmt B_scan d) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (zeroRand_forLoopStmt (.ite (.seq (.writeWordHeap _ _ _) (zeroRand_leafInnerLoopStmt B_scan d)) .skip)))

theorem exec_evalExactLeafPairStmt {d TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (pts : ℕ → EuclideanSpace ℝ (Fin d))
    {leafArr : List ℕ} (B_scan : ℕ)
    (hTW : 9 ≤ TW) (hBW : 64 ≤ BW) (hTR : 3 ≤ TR) (hBR : 16 ≤ BR)
    (hB : leafArr.length ≤ B_scan)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hlen_meta : wRead m₀ engMetaTbl 2 = (leafArr.length : ℤ))
    (helem : ∀ i (hi : i < leafArr.length),
      wRead m₀ engArrTbl (leafElemOff + (i : ℤ)) = (leafArr[i]'hi : ℤ))
    (hleaf_pts : ∀ x ∈ leafArr, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) :
    ExecDet TW BW TR BR inp (evalExactLeafPairStmt B_scan d) m₀
      (fun m₁ =>
        EncOptPair 12 13 14 (evalExactLeafPair pts leafArr) m₁ ∧
        (∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ r, r < 12 → wRead m₁ engScrTbl r = wRead m₀ engScrTbl r) ∧
        (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m₁ rt i = rRead m₀ rt i) ∧
        (∀ ri, ri < 2 → rRead m₁ engRealTbl ri = rRead m₀ engRealTbl ri))
      (60 + B_scan * (60 + B_scan * (210 + 80 * d))) := by
  have hT_scr : engScrTbl < TW := by show 8 < TW; omega
  unfold evalExactLeafPairStmt
  refine ExecDet.seq' (48 + B_scan * (60 + B_scan * (210 + 80 * d)))
    (ExecDet.wWriteEq inp engScrTbl (.lit 12) (.lit 0) 12 0
      hfp₀ hT_scr (by omega) (by omega) rfl rfl (by simp [intExprOps])) (by omega) ?_
  intro mA hmA hfpA; subst hmA
  refine ExecDet.seq' (36 + B_scan * (60 + B_scan * (210 + 80 * d)))
    (ExecDet.wWriteEq inp engScrTbl (.lit 17) (.readHeap engMetaTbl (.lit 2))
      17 (leafArr.length : ℤ) hfpA hT_scr (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change wRead _ engMetaTbl 2 = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]; exact hlen_meta)
      (by simp [intExprOps])) (by omega) ?_
  intro mB hmB hfpB; subst hmB
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    EncOptPairSq pts 12 13 14 2 (leafOuterFold pts leafArr B_scan k) m ∧
    (∀ t, t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ r, r < 12 → wRead m engScrTbl r = wRead m₀ engScrTbl r) ∧
    wRead m engScrTbl 17 = (leafArr.length : ℤ) ∧
    (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m rt i = rRead m₀ rt i) ∧
    (∀ ri, ri < 2 → rRead m engRealTbl ri = rRead m₀ engRealTbl ri)
  have hnoneB : EncOptPairSq pts 12 13 14 2 none
      (H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engScrTbl 12 0) engScrTbl 17 (leafArr.length : ℤ))
        engScrTbl 15 0) :=
    ⟨by dsimp [EncOptPair]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
     fun _ _ h => by cases h⟩
  have hmul_out : B_scan * (50 + B_scan * (210 + 80 * d) + 6) ≤
      B_scan * (60 + B_scan * (210 + 80 * d)) :=
    Nat.mul_le_mul_left B_scan (by omega)
  refine (ExecDet.forLoop engScrTbl 15 B_scan _ Inv (50 + B_scan * (210 + 80 * d))
    hfpB hT_scr (by omega) (by omega)
    ⟨hnoneB,
     fun t ht i => by (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]),
     fun r hr12 => by
       rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
           wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
           wRead_wWrite_of_ne _ _ (Or.inr (by omega))],
     by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
     fun _ _ _ => rfl,
     fun _ _ => rfl⟩ ?_).mono
    (fun m₁ ⟨henc₁, hwt₁, hwr₁, _, hrt₁, hrr₁⟩ _ => by
      rw [leafOuterFold_eq_evalExactLeafPair pts hB] at henc₁
      exact ⟨henc₁.1, hwt₁, hwr₁, hrt₁, hrr₁⟩)
    (by omega)
  intro iu _ m ⟨hcur_m, hwt_m, hwr_m, h17_m, hrt_m, hrr_m⟩ hctr_m hfp_m
  have hfold_succ : ∀ nxt,
      (if hiu : iu < leafArr.length then
        leafInnerFold pts leafArr (leafArr[iu]'hiu) B_scan (leafOuterFold pts leafArr B_scan iu)
       else leafOuterFold pts leafArr B_scan iu) = nxt →
      leafOuterFold pts leafArr B_scan (iu + 1) = nxt := by
    intro nxt heq
    unfold leafOuterFold at heq ⊢
    rw [List.range_succ, List.foldl_append, List.foldl_cons, List.foldl_nil]
    exact heq
  have hPreserveCtr : ∀ {m' : ArithRAMMemory},
      EncOptPairSq pts 12 13 14 2 (leafOuterFold pts leafArr B_scan (iu + 1)) m' →
      wRead m' engScrTbl 15 = (iu : ℤ) →
      (∀ t, t ≠ engScrTbl → ∀ i, wRead m' t i = wRead m₀ t i) →
      (∀ r, r < 12 → wRead m' engScrTbl r = wRead m₀ engScrTbl r) →
      wRead m' engScrTbl 17 = (leafArr.length : ℤ) →
      (∀ rt, rt ≠ engRealTbl → ∀ i, rRead m' rt i = rRead m₀ rt i) →
      (∀ ri, ri < 2 → rRead m' engRealTbl ri = rRead m₀ engRealTbl ri) →
      wRead m' engScrTbl 15 = (iu : ℤ) ∧ Inv (iu + 1) (H3a.wWrite m' engScrTbl 15 ((iu : ℤ) + 1)) := by
    intro m' henc' hc15 hwt' hwr' h17' hrt' hrr'
    exact ⟨hc15,
      henc'.wWrite_ne (Or.inr (by decide)) (Or.inr (by decide)) (Or.inr (by decide)),
      fun t ht i => (wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (hwt' t ht i),
      fun r hr12 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hwr' r hr12),
      (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans h17',
      fun rt hrt i => by rw [rRead_wWrite]; exact hrt' rt hrt i,
      fun ri hri2 => by rw [rRead_wWrite]; exact hrr' ri hri2⟩
  refine ExecDet.ite_le (C_c := 10) (C_b := 40 + B_scan * (210 + 80 * d)) _ _ _
    (by simp [condExprOps, intExprOps])
    (fun hlt_b => ?_) (fun hge_b => ?_)
  · have hiu : iu < leafArr.length := by
      simp only [evalArithCond, evalIntExpr] at hlt_b
      change decide (wRead m engScrTbl 15 < wRead m engScrTbl 17) = true at hlt_b
      rw [hctr_m, h17_m] at hlt_b
      exact Int.ofNat_lt.mp (of_decide_eq_true hlt_b)
    let u := leafArr[iu]'hiu
    have hu_arr : wRead m engArrTbl (leafElemOff + (iu : ℤ)) = (u : ℤ) :=
      (hwt_m engArrTbl (by decide) _).trans (helem iu hiu)
    refine ExecDet.seq' (20 + B_scan * (210 + 80 * d))
      (ExecDet.wWriteEq inp engScrTbl (.lit 18)
        (.readHeap engArrTbl (.add (.lit leafElemOff) (.readHeap engScrTbl (.lit 15))))
        18 (u : ℤ) hfp_m hT_scr (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; change wRead m engArrTbl (leafElemOff + wRead m engScrTbl 15) = _
            rw [hctr_m, hu_arr])
        (by simp [intExprOps])) (by omega) ?_
    intro mC hmC hfpC; subst hmC
    have hcur_C : EncOptPairSq pts 12 13 14 2 (leafOuterFold pts leafArr B_scan iu)
        (H3a.wWrite m engScrTbl 18 (u : ℤ)) :=
      hcur_m.wWrite_ne (Or.inr (by decide)) (Or.inr (by decide)) (Or.inr (by decide))
    have hstep_eq : leafOuterFold pts leafArr B_scan (iu + 1) =
        leafInnerFold pts leafArr u B_scan (leafOuterFold pts leafArr B_scan iu) :=
      hfold_succ _ (dif_pos hiu)
    refine (exec_leafInnerLoopStmt inp pts leafArr B_scan u
      (leafOuterFold pts leafArr B_scan iu) hTW hBW hTR hBR hfpC hcur_C
      ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans h17_m)
      (wRead_wWrite_self _ _ _ _)
      (fun i hi => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans
        ((hwt_m engArrTbl (by decide) _).trans (helem i hi)))
      (fun c => (hrt_m ptsRTbl (by decide) _).trans (hleaf_pts u (List.getElem_mem hiu) c))
      (fun x hx c => (hrt_m ptsRTbl (by decide) _).trans (hleaf_pts x hx c))).mono ?_ (by omega)
    intro mD ⟨hencD, hwtD, hwrD, h17D, hrtD, hrrD⟩ _
    rw [← hstep_eq] at hencD
    exact hPreserveCtr hencD
      ((hwrD 15 (by omega) (by decide) (by decide) (by decide)).trans
        ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hctr_m))
      (fun t ht i => (hwtD t ht i).trans ((wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (hwt_m t ht i)))
      (fun r hr12 =>
        (hwrD r (by omega) (by omega) (by omega) (by omega)).trans
          ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hwr_m r hr12)))
      h17D
      (fun rt hrt i => (hrtD rt hrt i).trans (by rw [rRead_wWrite]; exact hrt_m rt hrt i))
      (fun ri hri2 => (hrrD ri hri2).trans (by rw [rRead_wWrite]; exact hrr_m ri hri2))
  · have hiu : ¬ iu < leafArr.length := by
      simp only [evalArithCond, evalIntExpr] at hge_b
      change decide (wRead m engScrTbl 15 < wRead m engScrTbl 17) = false at hge_b
      rw [hctr_m, h17_m] at hge_b
      intro hlt; exact of_decide_eq_false hge_b (Int.ofNat_lt.mpr hlt)
    have hstep_eq : leafOuterFold pts leafArr B_scan (iu + 1) =
        leafOuterFold pts leafArr B_scan iu :=
      hfold_succ _ (dif_neg hiu)
    refine ExecDet.skip inp hfp_m ?_ (by omega)
    rw [← hstep_eq] at hcur_m
    exact hPreserveCtr hcur_m hctr_m hwt_m hwr_m h17_m hrt_m hrr_m

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
