import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInstA1a

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 4. `slotInsertMatStmt` (`insertMatStmt`) & `slotDeleteMatStmt` (`deleteMatStmt`) -/

section SlotMatOps

variable {d : ℕ} {params : LocalScaleParams} {h : ℝ}
variable {cp : ChainParams d params h} (L : NodeSlotLayout cp)

private def loadMatRegsStmt (sR pR cR : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap L.nodeScrWTbl (.lit 0)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))))
  (.seq (.writeWordHeap L.nodeScrWTbl (.lit 1)
          (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeRStride : ℤ))))
  (.seq (.writeWordHeap L.nodeScrWTbl (.lit 2) (.readHeap engScrTbl (.lit pR)))
        (.writeWordHeap L.nodeScrWTbl (.lit 3) (.readHeap engScrTbl (.lit cR)))))

private theorem zeroRand_loadMatRegsStmt (sR pR cR : ℤ) :
    ZeroRandStmt (loadMatRegsStmt L sR pR cR) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))

private theorem exec_loadMatRegsStmt (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (slot p coinOff : ℕ) (sR pR cR : ℤ)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ))
    (hpR_v : H3a.wRead m₀ engScrTbl pR = (p : ℤ))
    (hcR_v : H3a.wRead m₀ engScrTbl cR = (coinOff : ℤ)) :
    ExecDet L.TW L.BW L.TR L.BR inp (loadMatRegsStmt L sR pR cR) m₀
      (fun mD =>
        H3a.wRead mD L.nodeScrWTbl 0 = L.slotBaseW slot ∧
        H3a.wRead mD L.nodeScrWTbl 1 = L.slotBaseR slot ∧
        H3a.wRead mD L.nodeScrWTbl 2 = (p : ℤ) ∧
        H3a.wRead mD L.nodeScrWTbl 3 = (coinOff : ℤ) ∧
        (∀ t, t ≠ L.nodeScrWTbl → ∀ i, H3a.wRead mD t i = H3a.wRead m₀ t i) ∧
        (∀ t i, H3a.rRead mD t i = H3a.rRead m₀ t i))
      50 := by
  have hscrW : L.nodeScrWTbl < L.TW := L.hNodeScrW_hi
  have hBW64 : 64 ≤ L.BW := by unfold NodeSlotLayout.BW; omega
  have hne_eng : engScrTbl ≠ L.nodeScrWTbl := by
    have := L.hNodeScrW_lo; unfold engScrTbl; omega
  unfold loadMatRegsStmt
  refine ExecDet.seq' 38
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 0)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeWStride : ℤ))) 0 (L.slotBaseW slot)
      hfp₀ hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead m₀ engScrTbl sR * _ = _
          rw [hsR_v, ← L.slotBaseW_eq_mul])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mA hmA hfpA; subst hmA
  refine ExecDet.seq' 26
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 1)
      (.mul (.readHeap engScrTbl (.lit sR)) (.lit (L.nodeRStride : ℤ))) 1 (L.slotBaseR slot)
      hfpA hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead _ engScrTbl sR * _ = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_eng), hsR_v, ← L.slotBaseR_eq_mul])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mB hmB hfpB; subst hmB
  refine ExecDet.seq' 14
    (ExecDet.wWriteEq inp L.nodeScrWTbl (.lit 2) (.readHeap engScrTbl (.lit pR)) 2 (p : ℤ)
      hfpB hscrW (by omega) (by omega) rfl
      (by simp only [evalIntExpr]; change H3a.wRead _ engScrTbl pR = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hne_eng),
              wRead_wWrite_of_ne _ _ (Or.inl hne_eng), hpR_v])
      (by simp [intExprOps]))
    (by omega) ?_
  intro mC hmC hfpC; subst hmC
  refine ExecDet.wWrite inp L.nodeScrWTbl (.lit 3) (.readHeap engScrTbl (.lit cR)) 3 (coinOff : ℤ)
    hfpC hscrW (by omega) (by omega) rfl
    (by simp only [evalIntExpr]; change H3a.wRead _ engScrTbl cR = _
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl hne_eng)]
        exact hcR_v)
    (by simp [intExprOps]) ?_
  refine ⟨?_, ?_, ?_, wRead_wWrite_self _ _ _ _, fun t ht i => ?_, fun _ _ => rfl⟩
  · iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide))]
    exact wRead_wWrite_self _ _ _ _
  · iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide))]
    exact wRead_wWrite_self _ _ _ _
  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide))]
    exact wRead_wWrite_self _ _ _ _
  · iterate 4 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]

def NodeSlotLayout.slotInsertMatCost : ℕ :=
  50 + managedNodeInsertMatCost L.cmOps cp.L_p2 cp.N_cfg

def NodeSlotLayout.slotInsertMatStmt (sR pR cR : ℤ) : ArithRAMStmt :=
  .seq (loadMatRegsStmt L sR pR cR)
       (managedNodeInsertMatStmt L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2 0 1 2 3 4 0)

theorem NodeSlotLayout.zeroRand_slotInsertMatStmt (sR pR cR : ℤ) :
    ZeroRandStmt (L.slotInsertMatStmt sR pR cR) :=
  .seq (zeroRand_loadMatRegsStmt L sR pR cR)
       (zeroRand_managedNodeInsertMatStmt L.cmOps cp.specs _ _ _ _ _ _ _ _)

theorem NodeSlotLayout.exec_slotInsertMatStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
    (slot p coinOff bound : ℕ) (seedBits : Fin cp.B_op → Bool) (sR pR cR : ℤ)
    (hslot : slot < M_slots cp) (hp_lt : p < cp.n) (hp_not : p ∉ mn.nd.curSet)
    (hS_lt : ∀ x ∈ mn.nd.curSet, x < cp.n)
    (hhist : mn.histArr.length + 1 ≤ 4 * cp.n + 4)
    (ht_bnd : mn.nd.maxTIns bound) (ht_cap : bound + 1 < 2 ^ cp.L_p2)
    (hwf_mn : ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts mn)
    (hcoinB : coinOff + cp.B_op ≤ cp.B_STEP)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (_hpR0 : 0 ≤ pR) (_hpR64 : pR < 64)
    (_hcR0 : 0 ≤ cR) (_hcR64 : cR < 64)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ))
    (hpR_v : H3a.wRead m₀ engScrTbl pR = (p : ℤ))
    (hcR_v : H3a.wRead m₀ engScrTbl cR = (coinOff : ℤ))
    (hpts : ∀ x ∈ Insert.insert p mn.nd.curSet, ∀ c : Fin d,
      H3a.rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hcoins : ∀ k : Fin cp.B_op, H3a.wRead m₀ coinTbl ((coinOff : ℤ) + (k.val : ℤ)) =
      if seedBits k then 1 else 0) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotInsertMatStmt sR pR cR) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        L.EncNode (mn.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts p (bitsToOpSeedEquiv cp seedBits)) slot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ slot → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      L.slotInsertMatCost := by
  unfold NodeSlotLayout.slotInsertMatStmt
  refine ExecDet.seq' (managedNodeInsertMatCost L.cmOps cp.L_p2 cp.N_cfg)
    (exec_loadMatRegsStmt L inp m₀ slot p coinOff sR pR cR hfp₀ hsR_v hpR_v hcR_v)
    (by unfold NodeSlotLayout.slotInsertMatCost; omega) ?_
  intro mD ⟨hbW_D, hbR_D, hp_D, hc_D, hw0D, hr0D⟩ hfpD
  rcases henc₀ with ⟨_, hm₀⟩
  have hm₀_pts : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) pts mn none m₀ :=
    EncManagedNode.pts_congr
      (fun x hx => (memPtsOf_eq_of_coords m₀ x (pts x)
        (hpts x (Finset.mem_insert_of_mem hx))).symm) hm₀
  have hmD_pts : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) pts mn none mD :=
    EncManagedNode.mono_slice hm₀_pts
      (fun i _ _ => hw0D L.nodeWTbl L.hne_nodeW i)
      (fun _ _ _ => hr0D L.nodeRTbl _)
      (fun _ _ _ _ => hr0D ptsRTbl _)
  have hne_coin : coinTbl ≠ L.nodeScrWTbl := by
    have := L.hNodeScrW_lo; unfold coinTbl; omega
  have hseed_D : EncNodeOpSeedSlice coinTbl (coinOff : ℤ) (bitsToOpSeedEquiv cp seedBits) mD :=
    encNodeOpSeedSlice_of_bitsToOpSeedEquiv cp coinTbl (coinOff : ℤ) seedBits mD
      (fun k => (hw0D coinTbl hne_coin _).trans (hcoins k))
  have hseedB : 0 ≤ (coinOff : ℤ) ∧
      (coinOff : ℤ) + (nodeOpSeedBits cp.N_cfg cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b : ℤ) ≤ (L.BW : ℤ) := by
    rw [nodeOpSeedBits_eq_B_op cp]
    refine ⟨Nat.cast_nonneg _, ?_⟩
    have hle : coinOff + cp.B_op ≤ L.BW := by unfold NodeSlotLayout.BW; omega
    omega
  have hptsB : ((cp.n * d : ℕ) : ℤ) ≤ (L.BR : ℤ) := by
    have hle : cp.n * d ≤ L.BR := by unfold NodeSlotLayout.BR; omega
    omega
  have hwScr_B : (4 : ℤ) + managedNodeMatWScr L.cmOps ≤ (L.BW : ℤ) := by
    unfold managedNodeMatWScr; rw [← L.opWScr_cast]
    have hle : 22 + L.cmOps.opWScrStride.toNat ≤ L.BW := by unfold NodeSlotLayout.BW; omega
    omega
  have hrScr_B : (0 : ℤ) + managedNodeMatRScr L.cmOps ≤ (L.BR : ℤ) := by
    unfold managedNodeMatRScr; rw [← L.opRScr_cast]
    have hle : 2 + L.cmOps.opRScrStride.toNat ≤ L.BR := by unfold NodeSlotLayout.BR; omega
    omega
  obtain ⟨m₁, hdet, hfp₁, henc₁_pts, _, hfrD₁⟩ :=
    exec_managedNodeInsertMatStmt cp.hM₀ cp.hn cp.hL_p2 L.cmOps cp.specs
      (4 * cp.n + 4) cp.L_p2 (by have := cp.hL_p2; omega) inp
      0 1 2 3 4 0 (L.slotBaseW slot) (L.slotBaseR slot) (coinOff : ℤ)
      hp_not hp_lt hS_lt (curSet_card_insert_le_of_lt hp_not hp_lt hS_lt) hhist
      (bitsToOpSeedEquiv cp seedBits) ht_bnd ht_cap hwf_mn
      hfpD L.validTables (L.slotBaseW_bounds hslot) (L.slotBaseR_bounds hslot)
      hseedB hptsB
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      ⟨by omega, hwScr_B⟩ ⟨by omega, hrScr_B⟩
      hbW_D hbR_D hp_D hc_D
      (fun x hx c => (hr0D 1 _).trans (hpts x hx c))
      hseed_D hmD_pts
  have hfr01 : RadFrameOutside L.nodeScrWTbl L.nodeScrRTbl
      L.nodeWTbl (L.slotBaseW slot) (L.nodeWStride : ℤ)
      L.nodeRTbl (L.slotBaseR slot) (L.nodeRStride : ℤ) m₀ m₁ := by
    rw [L.nodeWStride_cast, L.nodeRStride_cast]
    exact ⟨fun t i hs hout => (hfrD₁.1 t i hs hout).trans (hw0D t hs i),
           fun t i hs hout => (hfrD₁.2 t i hs hout).trans (hr0D t i)⟩
  let mn' := mn.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
    cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts p (bitsToOpSeedEquiv cp seedBits)
  have hcur_eq : mn'.nd.curSet = Insert.insert p mn.nd.curSet :=
    (denseInsert_spec hwf_mn.1.1 hp_not).2
  have hS'_lt : ∀ x ∈ mn'.nd.curSet, x < cp.n := by
    intro x hx; rw [hcur_eq] at hx
    rcases Finset.mem_insert.mp hx with rfl | hxS
    · exact hp_lt
    · exact hS_lt x hxS
  have h1_ne_scr : ptsRTbl ≠ L.nodeScrRTbl := by have := L.hNodeScrR_lo; unfold ptsRTbl; omega
  have h1_ne_tbl : ptsRTbl ≠ L.nodeRTbl := by have := L.hNodeRTbl_lo; unfold ptsRTbl; omega
  have henc₁_m₁ : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) (memPtsOf d m₁) mn' none m₁ :=
    EncManagedNode.pts_congr
      (fun x hx => by
        rw [hcur_eq] at hx
        exact memPtsOf_eq_of_coords m₁ x (pts x) (fun c =>
          (hfr01.2 ptsRTbl _ h1_ne_scr (Or.inl h1_ne_tbl)).trans (hpts x hx c)))
      henc₁_pts
  obtain ⟨hlowW, hlowR⟩ := L.frame_low_tables hfr01
  exact detExec_to_execDet
    (hzr_managedNodeInsertMatStmt L.cmHzr cp.specs (4 * cp.n + 4) cp.L_p2 0 1 2 3 4 0)
    hfpD hfp₁ hdet
    ⟨L.slotsReady_of_slot_frame hsr₀ henc₁_m₁ hfr01,
     ⟨hS'_lt, henc₁_m₁⟩,
     fun mn'' s' _ hne he => L.encNode_other_of_slot_frame hne he hfr01,
     hlowW, hlowR⟩

def NodeSlotLayout.slotDeleteMatCost : ℕ :=
  50 + managedNodeDeleteMatCost L.cmOps cp.L_p2 cp.N_cfg

def NodeSlotLayout.slotDeleteMatStmt (sR pR cR : ℤ) : ArithRAMStmt :=
  .seq (loadMatRegsStmt L sR pR cR)
       (managedNodeDeleteMatStmt L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2 0 1 2 3 4 0)

theorem NodeSlotLayout.zeroRand_slotDeleteMatStmt (sR pR cR : ℤ) :
    ZeroRandStmt (L.slotDeleteMatStmt sR pR cR) :=
  .seq (zeroRand_loadMatRegsStmt L sR pR cR)
       (zeroRand_managedNodeDeleteMatStmt L.cmOps cp.specs _ _ _ _ _ _ _ _)

theorem NodeSlotLayout.exec_slotDeleteMatStmt
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
    (slot p coinOff bound : ℕ) (seedBits : Fin cp.B_op → Bool) (sR pR cR : ℤ)
    (hslot : slot < M_slots cp) (hp_lt : p < cp.n) (hp_mem : p ∈ mn.nd.curSet)
    (hS_lt : ∀ x ∈ mn.nd.curSet, x < cp.n)
    (_hhist : mn.histArr.length ≤ 4 * cp.n + 4)
    (ht_bnd : mn.nd.maxTIns bound) (ht_cap : bound + 1 < 2 ^ cp.L_p2)
    (hwf_mn : ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts mn)
    (hcoinB : coinOff + cp.B_op ≤ cp.B_STEP)
    (_hsR0 : 0 ≤ sR) (_hsR64 : sR < 64)
    (_hpR0 : 0 ≤ pR) (_hpR64 : pR < 64)
    (_hcR0 : 0 ≤ cR) (_hcR64 : cR < 64)
    (hfp₀ : InFootprint L.TW L.BW L.TR L.BR m₀)
    (hsr₀ : L.SlotsReady m₀)
    (henc₀ : L.EncNode mn slot m₀)
    (hsR_v : H3a.wRead m₀ engScrTbl sR = (slot : ℤ))
    (hpR_v : H3a.wRead m₀ engScrTbl pR = (p : ℤ))
    (hcR_v : H3a.wRead m₀ engScrTbl cR = (coinOff : ℤ))
    (hpts : ∀ x ∈ mn.nd.curSet, ∀ c : Fin d,
      H3a.rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hcoins : ∀ k : Fin cp.B_op, H3a.wRead m₀ coinTbl ((coinOff : ℤ) + (k.val : ℤ)) =
      if seedBits k then 1 else 0) :
    ExecDet L.TW L.BW L.TR L.BR inp (L.slotDeleteMatStmt sR pR cR) m₀
      (fun m₁ =>
        L.SlotsReady m₁ ∧
        L.EncNode (mn.deleteMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts p (bitsToOpSeedEquiv cp seedBits)) slot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ slot → L.EncNode mn' s' m₀ → L.EncNode mn' s' m₁) ∧
        (∀ t < 9, ∀ i, H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
        (∀ t < 3, ∀ i, H3a.rRead m₁ t i = H3a.rRead m₀ t i))
      L.slotDeleteMatCost := by
  unfold NodeSlotLayout.slotDeleteMatStmt
  refine ExecDet.seq' (managedNodeDeleteMatCost L.cmOps cp.L_p2 cp.N_cfg)
    (exec_loadMatRegsStmt L inp m₀ slot p coinOff sR pR cR hfp₀ hsR_v hpR_v hcR_v)
    (by unfold NodeSlotLayout.slotDeleteMatCost; omega) ?_
  intro mD ⟨hbW_D, hbR_D, hp_D, hc_D, hw0D, hr0D⟩ hfpD
  rcases henc₀ with ⟨_, hm₀⟩
  have hm₀_pts : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) pts mn none m₀ :=
    EncManagedNode.pts_congr
      (fun x hx => (memPtsOf_eq_of_coords m₀ x (pts x) (hpts x hx)).symm) hm₀
  have hmD_pts : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) pts mn none mD :=
    EncManagedNode.mono_slice hm₀_pts
      (fun i _ _ => hw0D L.nodeWTbl L.hne_nodeW i)
      (fun _ _ _ => hr0D L.nodeRTbl _)
      (fun _ _ _ _ => hr0D ptsRTbl _)
  have hne_coin : coinTbl ≠ L.nodeScrWTbl := by
    have := L.hNodeScrW_lo; unfold coinTbl; omega
  have hseed_D : EncNodeOpSeedSlice coinTbl (coinOff : ℤ) (bitsToOpSeedEquiv cp seedBits) mD :=
    encNodeOpSeedSlice_of_bitsToOpSeedEquiv cp coinTbl (coinOff : ℤ) seedBits mD
      (fun k => (hw0D coinTbl hne_coin _).trans (hcoins k))
  have hseedB : 0 ≤ (coinOff : ℤ) ∧
      (coinOff : ℤ) + (nodeOpSeedBits cp.N_cfg cp.L_p2 cp.R cp.ℓ cp.M₀ d cp.b : ℤ) ≤ (L.BW : ℤ) := by
    rw [nodeOpSeedBits_eq_B_op cp]
    refine ⟨Nat.cast_nonneg _, ?_⟩
    have hle : coinOff + cp.B_op ≤ L.BW := by unfold NodeSlotLayout.BW; omega
    omega
  have hptsB : ((cp.n * d : ℕ) : ℤ) ≤ (L.BR : ℤ) := by
    have hle : cp.n * d ≤ L.BR := by unfold NodeSlotLayout.BR; omega
    omega
  have hwScr_B : (4 : ℤ) + managedNodeMatWScr L.cmOps ≤ (L.BW : ℤ) := by
    unfold managedNodeMatWScr; rw [← L.opWScr_cast]
    have hle : 22 + L.cmOps.opWScrStride.toNat ≤ L.BW := by unfold NodeSlotLayout.BW; omega
    omega
  have hrScr_B : (0 : ℤ) + managedNodeMatRScr L.cmOps ≤ (L.BR : ℤ) := by
    unfold managedNodeMatRScr; rw [← L.opRScr_cast]
    have hle : 2 + L.cmOps.opRScrStride.toNat ≤ L.BR := by unfold NodeSlotLayout.BR; omega
    omega
  obtain ⟨m₁, hdet, hfp₁, henc₁_pts, _, hfrD₁⟩ :=
    exec_managedNodeDeleteMatStmt cp.hM₀ cp.hn cp.hL_p2 L.cmOps cp.specs
      (4 * cp.n + 4) cp.L_p2 (by have := cp.hL_p2; omega) inp
      0 1 2 3 4 0 (L.slotBaseW slot) (L.slotBaseR slot) (coinOff : ℤ)
      hp_mem hp_lt hS_lt (curSet_card_le_of_lt hS_lt)
      (bitsToOpSeedEquiv cp seedBits) ht_bnd ht_cap hwf_mn
      hfpD L.validTables (L.slotBaseW_bounds hslot) (L.slotBaseR_bounds hslot)
      hseedB hptsB
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      ⟨by omega, hwScr_B⟩ ⟨by omega, hrScr_B⟩
      hbW_D hbR_D hp_D hc_D
      (fun x hx c => (hr0D 1 _).trans (hpts x hx c))
      hseed_D hmD_pts
  have hfr01 : RadFrameOutside L.nodeScrWTbl L.nodeScrRTbl
      L.nodeWTbl (L.slotBaseW slot) (L.nodeWStride : ℤ)
      L.nodeRTbl (L.slotBaseR slot) (L.nodeRStride : ℤ) m₀ m₁ := by
    rw [L.nodeWStride_cast, L.nodeRStride_cast]
    exact ⟨fun t i hs hout => (hfrD₁.1 t i hs hout).trans (hw0D t hs i),
           fun t i hs hout => (hfrD₁.2 t i hs hout).trans (hr0D t i)⟩
  let mn' := mn.deleteMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
    cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts p (bitsToOpSeedEquiv cp seedBits)
  have hcur_eq : mn'.nd.curSet = mn.nd.curSet.erase p :=
    (denseDelete_spec hwf_mn.1.1).2
  have hS'_lt : ∀ x ∈ mn'.nd.curSet, x < cp.n := by
    intro x hx; rw [hcur_eq] at hx
    exact hS_lt x (Finset.mem_of_mem_erase hx)
  have h1_ne_scr : ptsRTbl ≠ L.nodeScrRTbl := by have := L.hNodeScrR_lo; unfold ptsRTbl; omega
  have h1_ne_tbl : ptsRTbl ≠ L.nodeRTbl := by have := L.hNodeRTbl_lo; unfold ptsRTbl; omega
  have henc₁_m₁ : EncManagedNode L.cmOps cp.specs (4 * cp.n + 4) cp.L_p2
      (L.slotBaseW slot) (L.slotBaseR slot) (memPtsOf d m₁) mn' none m₁ :=
    EncManagedNode.pts_congr
      (fun x hx => by
        rw [hcur_eq] at hx
        have hxS := Finset.mem_of_mem_erase hx
        exact memPtsOf_eq_of_coords m₁ x (pts x) (fun c =>
          (hfr01.2 ptsRTbl _ h1_ne_scr (Or.inl h1_ne_tbl)).trans (hpts x hxS c)))
      henc₁_pts
  obtain ⟨hlowW, hlowR⟩ := L.frame_low_tables hfr01
  exact detExec_to_execDet
    (hzr_managedNodeDeleteMatStmt L.cmHzr cp.specs (4 * cp.n + 4) cp.L_p2 0 1 2 3 4 0)
    hfpD hfp₁ hdet
    ⟨L.slotsReady_of_slot_frame hsr₀ henc₁_m₁ hfr01,
     ⟨hS'_lt, henc₁_m₁⟩,
     fun mn'' s' _ hne he => L.encNode_other_of_slot_frame hne he hfr01,
     hlowW, hlowR⟩

end SlotMatOps

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
