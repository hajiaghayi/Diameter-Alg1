import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Proof.lem_7_2.RacerP33_H1_RAM
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H1_Bridge
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt cValAt)

/-! ### 1. Disjoint Heap Slice Framing (`WordFrameOutside`) -/

def WordFrameOutside (scrW tbl : ℕ) (base len : ℤ) (m₀ m₁ : ArithRAMMemory) : Prop :=
  (∀ t i, t ≠ scrW → (t ≠ tbl ∨ i < base ∨ base + len ≤ i) → H3a.wRead m₁ t i = H3a.wRead m₀ t i) ∧
  (∀ t i, H3a.rRead m₁ t i = H3a.rRead m₀ t i)

theorem WordFrameOutside.refl (scrW tbl : ℕ) (base len : ℤ) (m : ArithRAMMemory) :
    WordFrameOutside scrW tbl base len m m :=
  ⟨fun _ _ _ _ => rfl, fun _ _ => rfl⟩

theorem WordFrameOutside.trans {scrW tbl : ℕ} {base len : ℤ} {m₀ m₁ m₂ : ArithRAMMemory}
    (h₁ : WordFrameOutside scrW tbl base len m₀ m₁)
    (h₂ : WordFrameOutside scrW tbl base len m₁ m₂) :
    WordFrameOutside scrW tbl base len m₀ m₂ :=
  ⟨fun t i hs hout => (h₂.1 t i hs hout).trans (h₁.1 t i hs hout),
   fun t i => (h₂.2 t i).trans (h₁.2 t i)⟩

theorem WordFrameOutside.mono_len {scrW tbl : ℕ} {base len₁ len₂ : ℤ} {m₀ m₁ : ArithRAMMemory}
    (h : WordFrameOutside scrW tbl base len₁ m₀ m₁) (hle : len₁ ≤ len₂) :
    WordFrameOutside scrW tbl base len₂ m₀ m₁ :=
  ⟨fun t i hs hout => h.1 t i hs (by
    rcases hout with ht | hlt | hge
    · exact Or.inl ht
    · exact Or.inr (Or.inl hlt)
    · exact Or.inr (Or.inr (by omega))), h.2⟩

theorem WordFrameOutside.wWrite_scr (scrW tbl : ℕ) (base len : ℤ) (m : ArithRAMMemory) (idx val : ℤ) :
    WordFrameOutside scrW tbl base len m (H3a.wWrite m scrW idx val) :=
  ⟨fun _ _ hs _ => wRead_wWrite_of_ne m val (Or.inl hs),
   fun _ _ => rfl⟩

theorem WordFrameOutside.wWrite_in (scrW tbl : ℕ) (base len : ℤ) (m : ArithRAMMemory)
    {idx : ℤ} (hlo : base ≤ idx) (hhi : idx < base + len) (val : ℤ) :
    WordFrameOutside scrW tbl base len m (H3a.wWrite m tbl idx val) :=
  ⟨fun _ _ _ hout => by
    rcases hout with ht | hlt | hge
    · exact wRead_wWrite_of_ne m val (Or.inl ht)
    · exact wRead_wWrite_of_ne m val (Or.inr (by omega))
    · exact wRead_wWrite_of_ne m val (Or.inr (by omega)),
   fun _ _ => rfl⟩

/-! ### 2. Pure Epoch-Stamped `SwapPool` (`O(1)` clear, `O(1)` mem, `O(1)` insert, `O(1)` delete) -/

structure SwapPool where
  ep : ℕ
  sz : ℕ
  hEp : ℕ → ℕ
  pos : ℕ → ℕ
  arr : ℕ → ℕ

def SwapPool.empty : SwapPool :=
  { ep := 1, sz := 0, hEp := fun _ => 0, pos := fun _ => 0, arr := fun _ => 0 }

def SwapPool.WF (n : ℕ) (S : Finset ℕ) (P : SwapPool) : Prop :=
  1 ≤ P.ep ∧
  (∀ h < n, P.hEp h ≤ P.ep) ∧
  P.sz = S.card ∧
  P.sz ≤ n ∧
  (∀ x ∈ S, ∀ y ∈ S, x % n = y % n → x = y) ∧
  (∀ r < P.sz, P.arr r ∈ S ∧ P.hEp (P.arr r % n) = P.ep ∧ P.pos (P.arr r % n) = r) ∧
  (∀ r₁ < P.sz, ∀ r₂ < P.sz, P.arr r₁ = P.arr r₂ → r₁ = r₂) ∧
  (∀ h < n, P.hEp h = P.ep → P.pos h < P.sz ∧ P.arr (P.pos h) % n = h)

theorem SwapPool.wf_empty (n : ℕ) : SwapPool.empty.WF n ∅ := by
  unfold SwapPool.WF SwapPool.empty; dsimp only
  refine ⟨le_rfl, fun _ _ => Nat.zero_le 1, rfl, Nat.zero_le n,
    fun _ hx => by simp at hx, fun _ hr => by omega, fun _ hr => by omega,
    fun _ _ h => by omega⟩

noncomputable def SwapPool.enum {n : ℕ} {S : Finset ℕ} {P : SwapPool} (hwf : P.WF n S) :
    Fin S.card ≃ ↥S := by
  have hsz : P.sz = S.card := hwf.2.2.1
  let toS : Fin S.card → ↥S := fun r =>
    ⟨P.arr r.val, (hwf.2.2.2.2.2.1 r.val (by omega)).1⟩
  have hinj : Function.Injective toS := by
    intro r₁ r₂ heq
    apply Fin.ext
    exact hwf.2.2.2.2.2.2.1 r₁.val (by omega) r₂.val (by omega) (congrArg Subtype.val heq)
  exact Equiv.ofBijective toS
    ((Fintype.bijective_iff_injective_and_card toS).mpr ⟨hinj, by simp⟩)

@[simp] theorem SwapPool.enum_val {n : ℕ} {S : Finset ℕ} {P : SwapPool} (hwf : P.WF n S)
    (r : Fin S.card) : ((P.enum hwf) r).1 = P.arr r.val := rfl

def SwapPool.memPred (n : ℕ) (P : SwapPool) (uid : ℕ) : Prop :=
  P.hEp (uid % n) = P.ep ∧ P.arr (P.pos (uid % n)) = uid

instance (n : ℕ) (P : SwapPool) (uid : ℕ) : Decidable (P.memPred n uid) :=
  inferInstanceAs (Decidable (_ ∧ _))

theorem SwapPool.memPred_iff {n : ℕ} (hn : 1 ≤ n) {S : Finset ℕ} {P : SwapPool}
    (hwf : P.WF n S) (uid : ℕ) :
    P.memPred n uid ↔ uid ∈ S := by
  have hwf₀ := hwf
  obtain ⟨_, _, _, _, _, harr, _, hhEp⟩ := hwf₀
  constructor
  · rintro ⟨hep, ha⟩
    have hlt : uid % n < n := Nat.mod_lt uid hn
    obtain ⟨hp_lt, _⟩ := hhEp (uid % n) hlt hep
    rw [← ha]
    exact (harr (P.pos (uid % n)) hp_lt).1
  · intro huid
    let r := (P.enum hwf).symm ⟨uid, huid⟩
    have hr_val : P.arr r.val = uid := congrArg Subtype.val ((P.enum hwf).apply_symm_apply ⟨uid, huid⟩)
    have hr_lt : r.val < P.sz := by have := r.isLt; omega
    obtain ⟨_, hep_r, hpos_r⟩ := harr r.val hr_lt
    rw [hr_val] at hep_r hpos_r
    exact ⟨hep_r, by rw [hpos_r, hr_val]⟩

def SwapPool.clear (newEp : ℕ) (P : SwapPool) : SwapPool :=
  { P with ep := newEp, sz := 0 }

theorem SwapPool.wf_clear {n : ℕ} {S : Finset ℕ} {P : SwapPool}
    (hwf : P.WF n S) {newEp : ℕ} (hgt : P.ep < newEp) :
    (P.clear newEp).WF n ∅ := by
  obtain ⟨_, hhle, _, _, _, _, _, _⟩ := hwf
  unfold SwapPool.WF SwapPool.clear; dsimp only
  refine ⟨by omega, fun h hh => le_of_lt (lt_of_le_of_lt (hhle h hh) hgt),
    rfl, Nat.zero_le n, fun _ hx => by simp at hx, fun _ hr => by omega,
    fun _ hr => by omega, fun h hh heq => ?_⟩
  have := hhle h hh; omega

def SwapPool.insert (n : ℕ) (P : SwapPool) (uid : ℕ) : SwapPool :=
  if P.memPred n uid ∨ n ≤ P.sz then P
  else
    let h := uid % n
    { ep := P.ep
      sz := P.sz + 1
      hEp := Function.update P.hEp h P.ep
      pos := Function.update P.pos h P.sz
      arr := Function.update P.arr P.sz uid }

theorem SwapPool.wf_insert {n : ℕ} (hn : 1 ≤ n) {S : Finset ℕ} {P : SwapPool}
    (hwf : P.WF n S) {uid : ℕ}
    (hnot : uid ∉ S) (hcap : S.card + 1 ≤ n)
    (hfresh : ∀ x ∈ S, x % n ≠ uid % n) :
    (P.insert n uid).WF n (Insert.insert uid S) := by
  have hnmem : ¬ P.memPred n uid := fun hm => hnot ((P.memPred_iff hn hwf uid).mp hm)
  obtain ⟨hep1, hhle, hsz, _, hinjS, harr, hinjA, hhEp⟩ := hwf
  have hlt_n : ¬ n ≤ P.sz := by omega
  have hcond : ¬ (P.memPred n uid ∨ n ≤ P.sz) := by tauto
  unfold SwapPool.insert SwapPool.WF
  rw [if_neg hcond]
  dsimp only
  refine ⟨hep1, ?_, ?_, by omega, ?_, ?_, ?_, ?_⟩
  · intro h hh
    by_cases he : h = uid % n
    · subst he; simp
    · rw [Function.update_of_ne he]; exact hhle h hh
  · rw [Finset.card_insert_of_notMem hnot, hsz]
  · intro x hx y hy hmod
    rcases Finset.mem_insert.mp hx with rfl | hxS <;> rcases Finset.mem_insert.mp hy with rfl | hyS
    · rfl
    · exact absurd hmod.symm (hfresh y hyS)
    · exact absurd hmod (hfresh x hxS)
    · exact hinjS x hxS y hyS hmod
  · intro r hr
    rcases Nat.lt_succ_iff_lt_or_eq.mp hr with hlt | rfl
    · have hne_r : r ≠ P.sz := by omega
      obtain ⟨hmem_r, hep_r, hpos_r⟩ := harr r hlt
      have hne_h : P.arr r % n ≠ uid % n := hfresh (P.arr r) hmem_r
      rw [Function.update_of_ne hne_r, Function.update_of_ne hne_h, Function.update_of_ne hne_h]
      exact ⟨Finset.mem_insert_of_mem hmem_r, hep_r, hpos_r⟩
    · rw [Function.update_self, Function.update_self, Function.update_self]
      exact ⟨Finset.mem_insert_self uid S, rfl, rfl⟩
  · intro r₁ hr₁ r₂ hr₂ heq
    rcases Nat.lt_succ_iff_lt_or_eq.mp hr₁ with h1 | rfl <;>
      rcases Nat.lt_succ_iff_lt_or_eq.mp hr₂ with h2 | rfl
    · rw [Function.update_of_ne (by omega), Function.update_of_ne (by omega)] at heq
      exact hinjA r₁ h1 r₂ h2 heq
    · rw [Function.update_of_ne (by omega), Function.update_self] at heq
      exact absurd (heq ▸ (harr r₁ h1).1) hnot
    · rw [Function.update_self, Function.update_of_ne (by omega)] at heq
      exact absurd (heq.symm ▸ (harr r₂ h2).1) hnot
    · rfl
  · intro h hh hep_h
    by_cases he : h = uid % n
    · subst he; rw [Function.update_self, Function.update_self]; exact ⟨Nat.lt_succ_self P.sz, rfl⟩
    · rw [Function.update_of_ne he] at hep_h ⊢
      obtain ⟨hp_lt, hmod⟩ := hhEp h hh hep_h
      rw [Function.update_of_ne (by omega)]
      exact ⟨Nat.lt_succ_of_lt hp_lt, hmod⟩

def SwapPool.delete (n : ℕ) (P : SwapPool) (uid : ℕ) : SwapPool :=
  if P.memPred n uid then
    let h := uid % n
    let p := P.pos h
    let last := P.sz - 1
    let uLast := P.arr last
    if p = last then
      { ep := P.ep
        sz := last
        hEp := Function.update P.hEp h 0
        pos := P.pos
        arr := P.arr }
    else
      { ep := P.ep
        sz := last
        hEp := Function.update P.hEp h 0
        pos := Function.update P.pos (uLast % n) p
        arr := Function.update P.arr p uLast }
  else P

theorem SwapPool.wf_delete {n : ℕ} (hn : 1 ≤ n) {S : Finset ℕ} {P : SwapPool}
    (hwf : P.WF n S) (uid : ℕ) :
    (P.delete n uid).WF n (S.erase uid) := by
  unfold SwapPool.delete
  by_cases hmem : P.memPred n uid
  · have huidS : uid ∈ S := (P.memPred_iff hn hwf uid).mp hmem
    obtain ⟨hep1, hhle, hsz, hsz_le, hinjS, harr, hinjA, hhEp⟩ := hwf
    obtain ⟨hep_u, harr_p⟩ := hmem
    let h := uid % n
    let p := P.pos h
    have hp_lt : p < P.sz := (hhEp h (Nat.mod_lt _ hn) hep_u).1
    let last := P.sz - 1
    let uLast := P.arr last
    have hcard_er : last = (S.erase uid).card := by
      have := Finset.card_erase_add_one huidS
      omega
    rw [if_pos ⟨hep_u, harr_p⟩]
    dsimp only
    by_cases hpl : p = last
    · rw [if_pos hpl]
      unfold SwapPool.WF; dsimp only
      refine ⟨hep1, ?_, hcard_er, by omega, ?_, ?_, ?_, ?_⟩
      · intro x hx
        by_cases he : x = h
        · subst he; simp [h]
        · rw [Function.update_of_ne he]; exact hhle x hx
      · intro x hx y hy; exact hinjS x (Finset.mem_of_mem_erase hx) y (Finset.mem_of_mem_erase hy)
      · intro r hr
        have hr_lt : r < P.sz := by omega
        obtain ⟨hmem_r, hep_r, hpos_r⟩ := harr r hr_lt
        have hne_u : P.arr r ≠ uid := by
          intro heq
          have : r = p := hinjA r hr_lt p hp_lt (heq.trans harr_p.symm)
          omega
        have hne_h : P.arr r % n ≠ h := fun hm => hne_u (hinjS (P.arr r) hmem_r uid huidS hm)
        rw [Function.update_of_ne hne_h]
        exact ⟨Finset.mem_erase.mpr ⟨hne_u, hmem_r⟩, hep_r, hpos_r⟩
      · intro r₁ hr₁ r₂ hr₂ heq
        exact hinjA r₁ (by omega) r₂ (by omega) heq
      · intro x hx hep_x
        have hne_x : x ≠ h := by
          intro hx_eq; subst hx_eq; simp [h] at hep_x; omega
        rw [Function.update_of_ne hne_x] at hep_x
        obtain ⟨hpx, hmodx⟩ := hhEp x hx hep_x
        have hpx_ne : P.pos x ≠ last := by
          intro heq; apply hne_x
          rw [← hmodx, heq, ← hpl]; exact congrArg (· % n) harr_p
        exact ⟨by omega, hmodx⟩
    · rw [if_neg hpl]
      have hp_lt_last : p < last := by omega
      obtain ⟨huL_S, hep_L, _⟩ := harr last (by omega)
      have huL_ne_u : uLast ≠ uid :=
        fun heq => hpl (hinjA p hp_lt last (by omega) (harr_p.trans heq.symm))
      have hhL_ne_h : uLast % n ≠ h := fun hm => huL_ne_u (hinjS uLast huL_S uid huidS hm)
      unfold SwapPool.WF; dsimp only
      refine ⟨hep1, ?_, hcard_er, by omega, ?_, ?_, ?_, ?_⟩
      · intro x hx
        by_cases he : x = h
        · subst he; simp [h]
        · rw [Function.update_of_ne he]; exact hhle x hx
      · intro x hx y hy; exact hinjS x (Finset.mem_of_mem_erase hx) y (Finset.mem_of_mem_erase hy)
      · intro r hr
        by_cases hrp : r = p
        · subst hrp
          dsimp only [h, p, last, uLast]
          rw [Function.update_self, Function.update_of_ne hhL_ne_h, Function.update_self]
          exact ⟨Finset.mem_erase.mpr ⟨huL_ne_u, huL_S⟩, hep_L, rfl⟩
        · rw [Function.update_of_ne hrp]
          obtain ⟨hmem_r, hep_r, hpos_r⟩ := harr r (by omega)
          have hne_u : P.arr r ≠ uid := fun heq =>
            hrp (hinjA r (by omega) p hp_lt (heq.trans harr_p.symm))
          have hne_L : P.arr r ≠ uLast := fun heq => by
            have := hinjA r (by omega) last (by omega) heq; omega
          have hne_rh : P.arr r % n ≠ h := fun hm => hne_u (hinjS (P.arr r) hmem_r uid huidS hm)
          have hne_rL : P.arr r % n ≠ uLast % n := fun hm => hne_L (hinjS (P.arr r) hmem_r uLast huL_S hm)
          rw [Function.update_of_ne hne_rh, Function.update_of_ne hne_rL]
          exact ⟨Finset.mem_erase.mpr ⟨hne_u, hmem_r⟩, hep_r, hpos_r⟩
      · intro r₁ hr₁ r₂ hr₂ heq
        by_cases h1 : r₁ = p <;> by_cases h2 : r₂ = p
        · omega
        · subst h1; rw [Function.update_self, Function.update_of_ne h2] at heq
          have := hinjA last (by omega) r₂ (by omega) heq; omega
        · subst h2; rw [Function.update_of_ne h1, Function.update_self] at heq
          have := hinjA r₁ (by omega) last (by omega) heq; omega
        · rw [Function.update_of_ne h1, Function.update_of_ne h2] at heq
          exact hinjA r₁ (by omega) r₂ (by omega) heq
      · intro x hx hep_x
        have hne_x : x ≠ h := by
          intro hx_eq; subst hx_eq; simp [h] at hep_x; omega
        rw [Function.update_of_ne hne_x] at hep_x
        by_cases hxL : x = uLast % n
        · subst hxL
          dsimp only [h, p, last, uLast]
          rw [Function.update_self, Function.update_self]
          exact ⟨hp_lt_last, rfl⟩
        · rw [Function.update_of_ne hxL]
          obtain ⟨hpx, hmodx⟩ := hhEp x hx hep_x
          have hpx_ne_last : P.pos x ≠ last := fun heq => hxL (by rw [← hmodx, heq])
          have hpx_ne_p : P.pos x ≠ p := fun heq =>
            hne_x (by rw [← hmodx, heq]; exact congrArg (· % n) harr_p)
          rw [Function.update_of_ne hpx_ne_p]
          exact ⟨by omega, hmodx⟩
  · have hnS : uid ∉ S := fun hu => hmem ((P.memPred_iff hn hwf uid).mpr hu)
    rw [if_neg hmem, Finset.erase_eq_of_notMem hnS]
    exact hwf

/-! ### 3. `ArithRAM` Heap Encoding & `DetExec` Subroutines for `SwapPool` -/

def swapPoolStride (n : ℕ) : ℤ := 4 + 3 * (n : ℤ)

def EncSwapPool (tbl : ℕ) (base : ℤ) (n : ℕ) (P : SwapPool) (m : ArithRAMMemory) : Prop :=
  H3a.wRead m tbl base = (P.ep : ℤ) ∧
  H3a.wRead m tbl (base + 1) = (P.sz : ℤ) ∧
  (∀ h < n, H3a.wRead m tbl (base + 4 + (h : ℤ)) = (P.hEp h : ℤ)) ∧
  (∀ h < n, H3a.wRead m tbl (base + 4 + (n : ℤ) + (h : ℤ)) = (P.pos h : ℤ)) ∧
  (∀ r < P.sz, H3a.wRead m tbl (base + 4 + 2 * (n : ℤ) + (r : ℤ)) = (P.arr r : ℤ))

theorem EncSwapPool.mono_frame {scrW tbl' tbl : ℕ} {base' len' base : ℤ} {n : ℕ}
    {P : SwapPool} {m₀ m₁ : ArithRAMMemory}
    (henc : EncSwapPool tbl base n P m₀)
    (hfr : WordFrameOutside scrW tbl' base' len' m₀ m₁)
    (hne_scr : tbl ≠ scrW)
    (hdisj : tbl ≠ tbl' ∨ base + swapPoolStride n ≤ base' ∨ base' + len' ≤ base)
    (hsz_le : P.sz ≤ n) :
    EncSwapPool tbl base n P m₁ := by
  have hkeep : ∀ i : ℤ, base ≤ i → i < base + swapPoolStride n →
      H3a.wRead m₁ tbl i = H3a.wRead m₀ tbl i := by
    intro i hlo hhi
    apply hfr.1 tbl i hne_scr
    rcases hdisj with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by omega))
    · exact Or.inr (Or.inr (by omega))
  refine ⟨(hkeep base le_rfl (by dsimp [swapPoolStride]; omega)).trans henc.1,
    (hkeep (base + 1) (by omega) (by dsimp [swapPoolStride]; omega)).trans henc.2.1,
    fun h hh => (hkeep _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (henc.2.2.1 h hh),
    fun h hh => (hkeep _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (henc.2.2.2.1 h hh),
    fun r hr => (hkeep _ (by omega) (by dsimp [swapPoolStride]; omega)).trans (henc.2.2.2.2 r hr)⟩

private lemma detWriteScr {d TW BW TR BR scrW tbl : ℕ} (inp : ArithRAMInput d)
    {m : ArithRAMMemory} (base len : ℤ) (idxE valE : IntExpr) (idx val : ℤ) {C : ℕ}
    (hfp : InFootprint TW BW TR BR m) (hscrW : scrW < TW)
    (hi0 : 0 ≤ idx) (hiB : idx < (BW : ℤ))
    (hidx : iValAt 0 inp m idxE = idx)
    (hval : iValAt 0 inp m valE = val)
    (hcost : UL.Proof_lem_7_2_RacerP33.intExprOps idxE + UL.Proof_lem_7_2_RacerP33.intExprOps valE + 1 ≤ C) :
    let m' := H3a.wWrite m scrW idx val
    DetExec inp (.writeWordHeap scrW idxE valE) m m' C ∧
    InFootprint TW BW TR BR m' ∧
    WordFrameOutside scrW tbl base len m m' :=
  ⟨DetExecAt.writeWordHeap 0 inp m scrW idxE valE hidx hval hcost,
   InFootprint.wWrite hfp hscrW hi0 hiB,
   WordFrameOutside.wWrite_scr scrW tbl base len m idx val⟩

private lemma detWritePool {d TW BW TR BR scrW tbl : ℕ} (inp : ArithRAMInput d)
    {m : ArithRAMMemory} (base len : ℤ) (idxE valE : IntExpr) (idx val : ℤ) {C : ℕ}
    (hfp : InFootprint TW BW TR BR m) (htbl : tbl < TW)
    (hbase : 0 ≤ base ∧ base + len ≤ (BW : ℤ))
    (hlo : base ≤ idx) (hhi : idx < base + len)
    (hidx : iValAt 0 inp m idxE = idx)
    (hval : iValAt 0 inp m valE = val)
    (hcost : UL.Proof_lem_7_2_RacerP33.intExprOps idxE + UL.Proof_lem_7_2_RacerP33.intExprOps valE + 1 ≤ C) :
    let m' := H3a.wWrite m tbl idx val
    DetExec inp (.writeWordHeap tbl idxE valE) m m' C ∧
    InFootprint TW BW TR BR m' ∧
    WordFrameOutside scrW tbl base len m m' :=
  ⟨DetExecAt.writeWordHeap 0 inp m tbl idxE valE hidx hval hcost,
   InFootprint.wWrite hfp htbl (by omega) (by omega),
   WordFrameOutside.wWrite_in scrW tbl base len m hlo hhi val⟩

def swapPoolClearStmt (tbl : ℕ) (baseE newEpE : IntExpr) : ArithRAMStmt :=
  .seq (.writeWordHeap tbl baseE newEpE)
       (.writeWordHeap tbl (.add baseE (.lit 1)) (.lit 0))

theorem exec_swapPoolClearStmt {d TW BW TR BR scrW tbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (base newEpVal : ℤ) (baseE newEpE : IntExpr) (n newEp : ℕ) (P : SwapPool)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbl : tbl < TW)
    (hbase : 0 ≤ base ∧ base + swapPoolStride n ≤ (BW : ℤ))
    (hbE : iValAt 0 inp m₀ baseE = base)
    (heE : iValAt 0 inp m₀ newEpE = newEpVal)
    (hnewEp : newEpVal = (newEp : ℤ))
    (hbE_after : ∀ v, iValAt 0 inp (H3a.wWrite m₀ tbl base v) baseE = base)
    (hops : UL.Proof_lem_7_2_RacerP33.intExprOps baseE ≤ 10 ∧
            UL.Proof_lem_7_2_RacerP33.intExprOps newEpE ≤ 10)
    (henc : EncSwapPool tbl base n P m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (swapPoolClearStmt tbl baseE newEpE) m₀ m₁ 50 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncSwapPool tbl base n (P.clear newEp) m₁ ∧
      WordFrameOutside scrW tbl base (swapPoolStride n) m₀ m₁ := by
  subst hnewEp
  obtain ⟨hd1, hfp1, hfr1⟩ := detWritePool (scrW := scrW) (C := 25) inp base (swapPoolStride n)
    baseE newEpE base (newEp : ℤ) hfp₀ htbl hbase le_rfl (by dsimp [swapPoolStride]; omega)
    hbE heE (by omega)
  let m₁_s := H3a.wWrite m₀ tbl base (newEp : ℤ)
  obtain ⟨hd2, hfp2, hfr2⟩ := detWritePool (scrW := scrW) (C := 25) inp base (swapPoolStride n)
    (.add baseE (.lit 1)) (.lit 0) (base + 1) 0 hfp1 htbl hbase (by omega) (by dsimp [swapPoolStride]; omega)
    (by change iValAt 0 inp m₁_s baseE + 1 = base + 1; rw [hbE_after]) rfl
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  refine ⟨_, (DetExecAt.seq hd1 hd2).mono_cost (by omega), hfp2, ?_, hfr1.trans hfr2⟩
  unfold EncSwapPool; dsimp only [SwapPool.clear]
  refine ⟨?_, wRead_wWrite_self _ _ _ _, ?_, ?_, fun _ hr => by omega⟩
  · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  · intro h hh
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    exact henc.2.2.1 h hh
  · intro h hh
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    exact henc.2.2.2.1 h hh

/-- Check `P.memPred n uid` (`uid` in `(scrW, wUid)`, pool base in `(scrW, wPoolBase)`),
writing `1` or `0` to `(scrW, wOut)` using scratch `wScr .. wScr + 2`. -/
def swapPoolMemStmt (scrW tbl : ℕ) (wPoolBase wUid wScr wOut : ℤ) (n : ℕ) : ArithRAMStmt :=
  let bE := IntExpr.readHeap scrW (.lit wPoolBase)
  let wEp := wScr
  let wH := wScr + 1
  let wP := wScr + 2
  .seq (.writeWordHeap scrW (.lit wEp) (.readHeap tbl bE))
  (.seq (.writeWordHeap scrW (.lit wH) (.mod (.readHeap scrW (.lit wUid)) (.lit (n : ℤ))))
    (.ite (.intEq (.readHeap tbl (.add (.add bE (.lit 4)) (.readHeap scrW (.lit wH))))
                  (.readHeap scrW (.lit wEp)))
      (.seq (.writeWordHeap scrW (.lit wP)
              (.readHeap tbl (.add (.add bE (.lit (4 + (n : ℤ)))) (.readHeap scrW (.lit wH)))))
        (.ite (.intEq (.readHeap tbl (.add (.add bE (.lit (4 + 2 * (n : ℤ)))) (.readHeap scrW (.lit wP))))
                      (.readHeap scrW (.lit wUid)))
          (.writeWordHeap scrW (.lit wOut) (.lit 1))
          (.writeWordHeap scrW (.lit wOut) (.lit 0))))
      (.writeWordHeap scrW (.lit wOut) (.lit 0))))

theorem exec_swapPoolMemStmt {d TW BW TR BR scrW tbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wPoolBase wUid wScr wOut base : ℤ) {n : ℕ} (hn : 1 ≤ n)
    {S : Finset ℕ} {P : SwapPool} (hwf : P.WF n S) (uid : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hne_scr : tbl ≠ scrW)
    (hwScr : 0 ≤ wScr ∧ wScr + 3 ≤ (BW : ℤ))
    (hwOut : 0 ≤ wOut ∧ wOut < (BW : ℤ))
    (hneB : wPoolBase < wScr ∨ wScr + 3 ≤ wPoolBase)
    (hneU : wUid < wScr ∨ wScr + 3 ≤ wUid)
    (hbase_r : H3a.wRead m₀ scrW wPoolBase = base)
    (huid_r : H3a.wRead m₀ scrW wUid = (uid : ℤ))
    (henc : EncSwapPool tbl base n P m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (swapPoolMemStmt scrW tbl wPoolBase wUid wScr wOut n) m₀ m₁ 90 ∧
      InFootprint TW BW TR BR m₁ ∧
      H3a.wRead m₁ scrW wOut = (if P.memPred n uid then 1 else 0) ∧
      (wOut ≠ wPoolBase → H3a.wRead m₁ scrW wPoolBase = base) ∧
      (wOut ≠ wUid → H3a.wRead m₁ scrW wUid = (uid : ℤ)) ∧
      WordFrameOutside scrW tbl base 0 m₀ m₁ := by
  let h := uid % n
  have hh_lt : h < n := Nat.mod_lt uid hn
  obtain ⟨hd1, hfp1, hfr1⟩ := detWriteScr (tbl := tbl) (C := 10) inp base 0
    (.lit wScr) (.readHeap tbl (.readHeap scrW (.lit wPoolBase))) wScr (P.ep : ℤ)
    hfp₀ hscrW hwScr.1 (by omega) rfl
    (by change H3a.wRead m₀ tbl (H3a.wRead m₀ scrW wPoolBase) = _; rw [hbase_r, henc.1])
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  let m1 := H3a.wWrite m₀ scrW wScr (P.ep : ℤ)
  have hb_m1 : H3a.wRead m1 scrW wPoolBase = base := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbase_r]
  have hu_m1 : H3a.wRead m1 scrW wUid = (uid : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), huid_r]
  obtain ⟨hd2, hfp2, hfr2⟩ := detWriteScr (tbl := tbl) (C := 10) inp base 0
    (.lit (wScr + 1)) (.mod (.readHeap scrW (.lit wUid)) (.lit (n : ℤ))) (wScr + 1) (h : ℤ)
    hfp1 hscrW (by omega) (by omega) rfl
    (by change H3a.wRead m1 scrW wUid % (n : ℤ) = (h : ℤ); rw [hu_m1]; exact (Int.natCast_emod uid n).symm)
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  let m2 := H3a.wWrite m1 scrW (wScr + 1) (h : ℤ)
  have hb_m2 : H3a.wRead m2 scrW wPoolBase = base := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hb_m1]
  have hu_m2 : H3a.wRead m2 scrW wUid = (uid : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hu_m1]
  have hep_m2 : H3a.wRead m2 scrW wScr = (P.ep : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hh_m2 : H3a.wRead m2 scrW (wScr + 1) = (h : ℤ) := wRead_wWrite_self _ _ _ _
  have htbl2 : ∀ i, H3a.wRead m2 tbl i = H3a.wRead m₀ tbl i := by
    intro i
    rw [wRead_wWrite_of_ne _ _ (Or.inl hne_scr), wRead_wWrite_of_ne _ _ (Or.inl hne_scr)]
  let cond1 : ArithCondExpr :=
    .intEq (.readHeap tbl (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit 4)) (.readHeap scrW (.lit (wScr + 1)))))
           (.readHeap scrW (.lit wScr))
  by_cases hep_eq : P.hEp h = P.ep
  · have hc1_t : cValAt 0 inp m2 cond1 = true := by
      simp only [cValAt, cond1, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m2 tbl ((H3a.wRead m2 scrW wPoolBase + 4) + H3a.wRead m2 scrW (wScr + 1)) =
        H3a.wRead m2 scrW wScr) = true
      rw [hb_m2, hh_m2, hep_m2, htbl2, henc.2.2.1 h hh_lt, hep_eq]; simp
    obtain ⟨hp_lt, _⟩ := hwf.2.2.2.2.2.2.2 h hh_lt hep_eq
    let p := P.pos h
    obtain ⟨hd3, hfp3, hfr3⟩ := detWriteScr (tbl := tbl) (C := 15) inp base 0
      (.lit (wScr + 2))
      (.readHeap tbl (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit (4 + (n : ℤ)))) (.readHeap scrW (.lit (wScr + 1)))))
      (wScr + 2) (p : ℤ) hfp2 hscrW (by omega) (by omega) rfl
      (by
        change H3a.wRead m2 tbl ((H3a.wRead m2 scrW wPoolBase + (4 + (n : ℤ))) + H3a.wRead m2 scrW (wScr + 1)) = (p : ℤ)
        rw [hb_m2, hh_m2, htbl2, show (base + (4 + (n : ℤ))) + (h : ℤ) = base + 4 + (n : ℤ) + (h : ℤ) by ring]
        exact henc.2.2.2.1 h hh_lt)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m3 := H3a.wWrite m2 scrW (wScr + 2) (p : ℤ)
    have hb_m3 : H3a.wRead m3 scrW wPoolBase = base := by
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hb_m2]
    have hu_m3 : H3a.wRead m3 scrW wUid = (uid : ℤ) := by
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hu_m2]
    have hp_m3 : H3a.wRead m3 scrW (wScr + 2) = (p : ℤ) := wRead_wWrite_self _ _ _ _
    have htbl3 : ∀ i, H3a.wRead m3 tbl i = H3a.wRead m₀ tbl i := by
      intro i; rw [wRead_wWrite_of_ne _ _ (Or.inl hne_scr), htbl2]
    let cond2 : ArithCondExpr :=
      .intEq (.readHeap tbl (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit (4 + 2 * (n : ℤ)))) (.readHeap scrW (.lit (wScr + 2)))))
             (.readHeap scrW (.lit wUid))
    by_cases ha_eq : P.arr p = uid
    · have hc2_t : cValAt 0 inp m3 cond2 = true := by
        simp only [cValAt, cond2, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m3 tbl ((H3a.wRead m3 scrW wPoolBase + (4 + 2 * (n : ℤ))) + H3a.wRead m3 scrW (wScr + 2)) =
          H3a.wRead m3 scrW wUid) = true
        rw [hb_m3, hp_m3, hu_m3, htbl3,
            show (base + (4 + 2 * (n : ℤ))) + (p : ℤ) = base + 4 + 2 * (n : ℤ) + (p : ℤ) by ring,
            henc.2.2.2.2 p hp_lt, ha_eq]; simp
      obtain ⟨hd4, hfp4, hfr4⟩ := detWriteScr (tbl := tbl) (C := 10) inp base 0
        (.lit wOut) (.lit 1) wOut 1 hfp3 hscrW hwOut.1 hwOut.2 rfl rfl
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hmem_t : P.memPred n uid := ⟨hep_eq, ha_eq⟩
      refine ⟨_, (DetExecAt.seq hd1 (DetExecAt.seq hd2
        (DetExecAt.ite_true hc1_t (C_c := 15) (by dsimp [cond1, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (DetExecAt.seq hd3
            (DetExecAt.ite_true hc2_t (C_c := 15) (by dsimp [cond2, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd4))))).mono_cost (by omega),
        hfp4, by rw [wRead_wWrite_self, if_pos hmem_t],
        fun hne => by rw [wRead_wWrite_of_ne _ _ (Or.inr hne.symm), hb_m3],
        fun hne => by rw [wRead_wWrite_of_ne _ _ (Or.inr hne.symm), hu_m3],
        ((hfr1.trans hfr2).trans hfr3).trans hfr4⟩
    · have hc2_f : cValAt 0 inp m3 cond2 = false := by
        simp only [cValAt, cond2, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m3 tbl ((H3a.wRead m3 scrW wPoolBase + (4 + 2 * (n : ℤ))) + H3a.wRead m3 scrW (wScr + 2)) =
          H3a.wRead m3 scrW wUid) = false
        rw [hb_m3, hp_m3, hu_m3, htbl3,
            show (base + (4 + 2 * (n : ℤ))) + (p : ℤ) = base + 4 + 2 * (n : ℤ) + (p : ℤ) by ring,
            henc.2.2.2.2 p hp_lt, decide_eq_false_iff_not]
        exact_mod_cast ha_eq
      obtain ⟨hd4, hfp4, hfr4⟩ := detWriteScr (tbl := tbl) (C := 10) inp base 0
        (.lit wOut) (.lit 0) wOut 0 hfp3 hscrW hwOut.1 hwOut.2 rfl rfl
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hmem_f : ¬ P.memPred n uid := fun hm => ha_eq hm.2
      refine ⟨_, (DetExecAt.seq hd1 (DetExecAt.seq hd2
        (DetExecAt.ite_true hc1_t (C_c := 15) (by dsimp [cond1, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (DetExecAt.seq hd3
            (DetExecAt.ite_false hc2_f (C_c := 15) (by dsimp [cond2, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd4))))).mono_cost (by omega),
        hfp4, by rw [wRead_wWrite_self, if_neg hmem_f],
        fun hne => by rw [wRead_wWrite_of_ne _ _ (Or.inr hne.symm), hb_m3],
        fun hne => by rw [wRead_wWrite_of_ne _ _ (Or.inr hne.symm), hu_m3],
        ((hfr1.trans hfr2).trans hfr3).trans hfr4⟩
  · have hc1_f : cValAt 0 inp m2 cond1 = false := by
      simp only [cValAt, cond1, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m2 tbl ((H3a.wRead m2 scrW wPoolBase + 4) + H3a.wRead m2 scrW (wScr + 1)) =
        H3a.wRead m2 scrW wScr) = false
      rw [hb_m2, hh_m2, hep_m2, htbl2, henc.2.2.1 h hh_lt, decide_eq_false_iff_not]
      exact_mod_cast hep_eq
    obtain ⟨hd4, hfp4, hfr4⟩ := detWriteScr (tbl := tbl) (C := 10) inp base 0
      (.lit wOut) (.lit 0) wOut 0 hfp2 hscrW hwOut.1 hwOut.2 rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hmem_f : ¬ P.memPred n uid := fun hm => hep_eq hm.1
    refine ⟨_, (DetExecAt.seq hd1 (DetExecAt.seq hd2
      (DetExecAt.ite_false hc1_f (C_c := 15) (by dsimp [cond1, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd4))).mono_cost (by omega),
      hfp4, by rw [wRead_wWrite_self, if_neg hmem_f],
      fun hne => by rw [wRead_wWrite_of_ne _ _ (Or.inr hne.symm), hb_m2],
      fun hne => by rw [wRead_wWrite_of_ne _ _ (Or.inr hne.symm), hu_m2],
      (hfr1.trans hfr2).trans hfr4⟩

/-- Insert `uid` (in `(scrW, wUid)`) into `SwapPool` at `(tbl, wRead scrW wPoolBase)` using scratch `wScr .. wScr + 5`. -/
def swapPoolInsertStmt (scrW tbl : ℕ) (wPoolBase wUid wScr : ℤ) (n : ℕ) : ArithRAMStmt :=
  let bE := IntExpr.readHeap scrW (.lit wPoolBase)
  let wMem := wScr + 3
  let wEp := wScr + 4
  let wSz := wScr + 5
  let wH := wScr + 1
  .seq (swapPoolMemStmt scrW tbl wPoolBase wUid wScr wMem n)
  (.seq (.writeWordHeap scrW (.lit wSz) (.readHeap tbl (.add bE (.lit 1))))
    (.ite (.or (.intEq (.readHeap scrW (.lit wMem)) (.lit 1))
               (.intLe (.lit (n : ℤ)) (.readHeap scrW (.lit wSz))))
      .skip
      (.seq (.writeWordHeap scrW (.lit wEp) (.readHeap tbl bE))
      (.seq (.writeWordHeap scrW (.lit wH) (.mod (.readHeap scrW (.lit wUid)) (.lit (n : ℤ))))
      (.seq (.writeWordHeap tbl (.add (.add bE (.lit 4)) (.readHeap scrW (.lit wH))) (.readHeap scrW (.lit wEp)))
      (.seq (.writeWordHeap tbl (.add (.add bE (.lit (4 + (n : ℤ)))) (.readHeap scrW (.lit wH))) (.readHeap scrW (.lit wSz)))
      (.seq (.writeWordHeap tbl (.add (.add bE (.lit (4 + 2 * (n : ℤ)))) (.readHeap scrW (.lit wSz))) (.readHeap scrW (.lit wUid)))
            (.writeWordHeap tbl (.add bE (.lit 1)) (.add (.readHeap scrW (.lit wSz)) (.lit 1))))))))))

theorem exec_swapPoolInsertStmt {d TW BW TR BR scrW tbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wPoolBase wUid wScr base : ℤ) {n : ℕ} (hn : 1 ≤ n)
    {S : Finset ℕ} {P : SwapPool} (hwf : P.WF n S) (uid : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htbl : tbl < TW) (hne_scr : tbl ≠ scrW)
    (hbase : 0 ≤ base ∧ base + swapPoolStride n ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 6 ≤ (BW : ℤ))
    (hneB : wPoolBase < wScr ∨ wScr + 6 ≤ wPoolBase)
    (hneU : wUid < wScr ∨ wScr + 6 ≤ wUid)
    (hbase_r : H3a.wRead m₀ scrW wPoolBase = base)
    (huid_r : H3a.wRead m₀ scrW wUid = (uid : ℤ))
    (henc : EncSwapPool tbl base n P m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (swapPoolInsertStmt scrW tbl wPoolBase wUid wScr n) m₀ m₁ 235 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncSwapPool tbl base n (P.insert n uid) m₁ ∧
      H3a.wRead m₁ scrW wPoolBase = base ∧
      H3a.wRead m₁ scrW wUid = (uid : ℤ) ∧
      WordFrameOutside scrW tbl base (swapPoolStride n) m₀ m₁ := by
  obtain ⟨m1, hd_m, hfp1, hw_mem, hb1, hu1, hfr_m0⟩ :=
    exec_swapPoolMemStmt inp wPoolBase wUid wScr (wScr + 3) base hn hwf uid
      hfp₀ hscrW hne_scr ⟨hwScr.1, by omega⟩ ⟨by omega, by omega⟩
      (by omega) (by omega) hbase_r huid_r henc
  have hb_m1 : H3a.wRead m1 scrW wPoolBase = base := hb1 (by omega)
  have hu_m1 : H3a.wRead m1 scrW wUid = (uid : ℤ) := hu1 (by omega)
  have hfr_m : WordFrameOutside scrW tbl base (swapPoolStride n) m₀ m1 :=
    hfr_m0.mono_len (by dsimp [swapPoolStride]; omega)
  have henc1 : EncSwapPool tbl base n P m1 :=
    henc.mono_frame hfr_m0 hne_scr (Or.inr (Or.inr (by omega))) hwf.2.2.2.1
  obtain ⟨hd_sz, hfp2, hfr2⟩ := detWriteScr (tbl := tbl) (C := 15) inp base (swapPoolStride n)
    (.lit (wScr + 5)) (.readHeap tbl (.add (.readHeap scrW (.lit wPoolBase)) (.lit 1)))
    (wScr + 5) (P.sz : ℤ) hfp1 hscrW (by omega) (by omega) rfl
    (by change H3a.wRead m1 tbl (H3a.wRead m1 scrW wPoolBase + 1) = _; rw [hb_m1, henc1.2.1])
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  let m2 := H3a.wWrite m1 scrW (wScr + 5) (P.sz : ℤ)
  have hb_m2 : H3a.wRead m2 scrW wPoolBase = base := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hb_m1]
  have hu_m2 : H3a.wRead m2 scrW wUid = (uid : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hu_m1]
  have hmem_m2 : H3a.wRead m2 scrW (wScr + 3) = (if P.memPred n uid then 1 else 0) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw_mem]
  have hsz_m2 : H3a.wRead m2 scrW (wScr + 5) = (P.sz : ℤ) := wRead_wWrite_self _ _ _ _
  have henc2 : EncSwapPool tbl base n P m2 :=
    henc1.mono_frame (WordFrameOutside.wWrite_scr scrW tbl base 0 m1 _ _) hne_scr
      (Or.inr (Or.inr (by omega))) hwf.2.2.2.1
  let condSkip : ArithCondExpr :=
    .or (.intEq (.readHeap scrW (.lit (wScr + 3))) (.lit 1))
        (.intLe (.lit (n : ℤ)) (.readHeap scrW (.lit (wScr + 5))))
  by_cases hskip : P.memPred n uid ∨ n ≤ P.sz
  · have hc_t : cValAt 0 inp m2 condSkip = true := by
      simp only [cValAt, condSkip, evalArithCond, evalIntExpr]
      change (decide (H3a.wRead m2 scrW (wScr + 3) = 1) || decide ((n : ℤ) ≤ H3a.wRead m2 scrW (wScr + 5))) = true
      rw [hmem_m2, hsz_m2, Bool.or_eq_true, decide_eq_true_eq, decide_eq_true_eq]
      rcases hskip with hm | hle
      · exact Or.inl (if_pos hm)
      · exact Or.inr (by exact_mod_cast hle)
    have hins_eq : P.insert n uid = P := by unfold SwapPool.insert; rw [if_pos hskip]
    refine ⟨m2, (DetExecAt.seq hd_m (DetExecAt.seq hd_sz
      (DetExecAt.ite_true hc_t (C_c := 15) (by dsimp [condSkip, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.skip 0 inp m2)))).mono_cost (by omega),
      hfp2, hins_eq.symm ▸ henc2, hb_m2, hu_m2, hfr_m.trans hfr2⟩
  · have hc_f : cValAt 0 inp m2 condSkip = false := by
      simp only [cValAt, condSkip, evalArithCond, evalIntExpr]
      change (decide (H3a.wRead m2 scrW (wScr + 3) = 1) || decide ((n : ℤ) ≤ H3a.wRead m2 scrW (wScr + 5))) = false
      rw [hmem_m2, hsz_m2, Bool.or_eq_false_iff, decide_eq_false_iff_not, decide_eq_false_iff_not]
      have hnmem : ¬ P.memPred n uid := fun hm => hskip (Or.inl hm)
      have hnle : ¬ n ≤ P.sz := fun hle => hskip (Or.inr hle)
      rw [if_neg hnmem]
      exact ⟨by decide, by exact_mod_cast hnle⟩
    have hsz_lt : P.sz < n := by omega
    let h := uid % n
    have hh_lt : h < n := Nat.mod_lt uid hn
    obtain ⟨hd3, hfp3, hfr3⟩ := detWriteScr (tbl := tbl) (C := 15) inp base (swapPoolStride n)
      (.lit (wScr + 4)) (.readHeap tbl (.readHeap scrW (.lit wPoolBase))) (wScr + 4) (P.ep : ℤ)
      hfp2 hscrW (by omega) (by omega) rfl
      (by change H3a.wRead m2 tbl (H3a.wRead m2 scrW wPoolBase) = _; rw [hb_m2, henc2.1])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m3 := H3a.wWrite m2 scrW (wScr + 4) (P.ep : ℤ)
    obtain ⟨hd4, hfp4, hfr4⟩ := detWriteScr (tbl := tbl) (C := 15) inp base (swapPoolStride n)
      (.lit (wScr + 1)) (.mod (.readHeap scrW (.lit wUid)) (.lit (n : ℤ))) (wScr + 1) (h : ℤ)
      hfp3 hscrW (by omega) (by omega) rfl
      (by
        change H3a.wRead m3 scrW wUid % (n : ℤ) = (h : ℤ)
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hu_m2]
        exact (Int.natCast_emod uid n).symm)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m4 := H3a.wWrite m3 scrW (wScr + 1) (h : ℤ)
    have hscr4 : H3a.wRead m4 scrW wPoolBase = base ∧ H3a.wRead m4 scrW wUid = (uid : ℤ) ∧
        H3a.wRead m4 scrW (wScr + 5) = (P.sz : ℤ) ∧ H3a.wRead m4 scrW (wScr + 4) = (P.ep : ℤ) ∧
        H3a.wRead m4 scrW (wScr + 1) = (h : ℤ) := by
      refine ⟨?_, ?_, ?_, ?_, wRead_wWrite_self _ _ _ _⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hb_m2]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hu_m2]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hsz_m2]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
    obtain ⟨hd5, hfp5, hfr5⟩ := detWritePool (scrW := scrW) (C := 20) inp base (swapPoolStride n)
      (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit 4)) (.readHeap scrW (.lit (wScr + 1))))
      (.readHeap scrW (.lit (wScr + 4)))
      (base + 4 + (h : ℤ)) (P.ep : ℤ) hfp4 htbl hbase (by omega) (by dsimp [swapPoolStride]; omega)
      (by change (H3a.wRead m4 scrW wPoolBase + 4) + H3a.wRead m4 scrW (wScr + 1) = _; rw [hscr4.1, hscr4.2.2.2.2])
      hscr4.2.2.2.1 (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m5 := H3a.wWrite m4 tbl (base + 4 + (h : ℤ)) (P.ep : ℤ)
    have hw_scr5 : ∀ i, H3a.wRead m5 scrW i = H3a.wRead m4 scrW i :=
      fun i => wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)
    obtain ⟨hd6, hfp6, hfr6⟩ := detWritePool (scrW := scrW) (C := 20) inp base (swapPoolStride n)
      (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit (4 + (n : ℤ)))) (.readHeap scrW (.lit (wScr + 1))))
      (.readHeap scrW (.lit (wScr + 5)))
      (base + 4 + (n : ℤ) + (h : ℤ)) (P.sz : ℤ) hfp5 htbl hbase (by omega) (by dsimp [swapPoolStride]; omega)
      (by change (H3a.wRead m5 scrW wPoolBase + (4 + (n : ℤ))) + H3a.wRead m5 scrW (wScr + 1) = _; rw [hw_scr5, hw_scr5, hscr4.1, hscr4.2.2.2.2]; ring)
      (by change H3a.wRead m5 scrW (wScr + 5) = _; rw [hw_scr5, hscr4.2.2.1])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m6 := H3a.wWrite m5 tbl (base + 4 + (n : ℤ) + (h : ℤ)) (P.sz : ℤ)
    have hw_scr6 : ∀ i, H3a.wRead m6 scrW i = H3a.wRead m4 scrW i :=
      fun i => (wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)).trans (hw_scr5 i)
    obtain ⟨hd7, hfp7, hfr7⟩ := detWritePool (scrW := scrW) (C := 20) inp base (swapPoolStride n)
      (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit (4 + 2 * (n : ℤ)))) (.readHeap scrW (.lit (wScr + 5))))
      (.readHeap scrW (.lit wUid))
      (base + 4 + 2 * (n : ℤ) + (P.sz : ℤ)) (uid : ℤ) hfp6 htbl hbase (by omega) (by dsimp [swapPoolStride]; omega)
      (by change (H3a.wRead m6 scrW wPoolBase + (4 + 2 * (n : ℤ))) + H3a.wRead m6 scrW (wScr + 5) = _; rw [hw_scr6, hw_scr6, hscr4.1, hscr4.2.2.1]; ring)
      (by change H3a.wRead m6 scrW wUid = _; rw [hw_scr6, hscr4.2.1])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m7 := H3a.wWrite m6 tbl (base + 4 + 2 * (n : ℤ) + (P.sz : ℤ)) (uid : ℤ)
    have hw_scr7 : ∀ i, H3a.wRead m7 scrW i = H3a.wRead m4 scrW i :=
      fun i => (wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)).trans (hw_scr6 i)
    obtain ⟨hd8, hfp8, hfr8⟩ := detWritePool (scrW := scrW) (C := 15) inp base (swapPoolStride n)
      (.add (.readHeap scrW (.lit wPoolBase)) (.lit 1))
      (.add (.readHeap scrW (.lit (wScr + 5))) (.lit 1))
      (base + 1) (((P.sz + 1 : ℕ) : ℤ)) hfp7 htbl hbase (by omega) (by dsimp [swapPoolStride]; omega)
      (by change H3a.wRead m7 scrW wPoolBase + 1 = _; rw [hw_scr7, hscr4.1])
      (by change H3a.wRead m7 scrW (wScr + 5) + 1 = _; rw [hw_scr7, hscr4.2.2.1]; push_cast; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m8 := H3a.wWrite m7 tbl (base + 1) (((P.sz + 1 : ℕ) : ℤ))
    have hw_scr8 : ∀ i, H3a.wRead m8 scrW i = H3a.wRead m4 scrW i :=
      fun i => (wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)).trans (hw_scr7 i)
    have htbl4 : ∀ i, H3a.wRead m4 tbl i = H3a.wRead m2 tbl i := by
      intro i; rw [wRead_wWrite_of_ne _ _ (Or.inl hne_scr), wRead_wWrite_of_ne _ _ (Or.inl hne_scr)]
    have hins_eq : P.insert n uid =
        { ep := P.ep, sz := P.sz + 1, hEp := Function.update P.hEp h P.ep,
          pos := Function.update P.pos h P.sz, arr := Function.update P.arr P.sz uid } := by
      unfold SwapPool.insert; rw [if_neg hskip]
    refine ⟨m8, (DetExecAt.seq hd_m (DetExecAt.seq hd_sz
      (DetExecAt.ite_false hc_f (C_c := 15) (by dsimp [condSkip, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.seq hd3 (DetExecAt.seq hd4 (DetExecAt.seq hd5 (DetExecAt.seq hd6 (DetExecAt.seq hd7 hd8)))))))).mono_cost (by omega),
      hfp8, ?_, (hw_scr8 wPoolBase).trans hscr4.1, (hw_scr8 wUid).trans hscr4.2.1,
      ((((((hfr_m.trans hfr2).trans hfr3).trans hfr4).trans hfr5).trans hfr6).trans hfr7).trans hfr8⟩
    rw [hins_eq]; unfold EncSwapPool; dsimp only
    refine ⟨?_, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          htbl4, henc2.1]
    · intro x hx
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      by_cases he : x = h
      · subst he; rw [wRead_wWrite_self, Function.update_self]
      · rw [Function.update_of_ne he, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
        exact henc2.2.2.1 x hx
    · intro x hx
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      by_cases he : x = h
      · subst he; rw [wRead_wWrite_self, Function.update_self]
      · rw [Function.update_of_ne he, wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
        exact henc2.2.2.2.1 x hx
    · intro r hr
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      rcases Nat.lt_succ_iff_lt_or_eq.mp hr with hlt | rfl
      · rw [Function.update_of_ne (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
        exact henc2.2.2.2.2 r hlt
      · rw [wRead_wWrite_self, Function.update_self]

/-- Delete `uid` (in `(scrW, wUid)`) from `SwapPool` at `(tbl, wRead scrW wPoolBase)` using scratch `wScr .. wScr + 7`. -/
def swapPoolDeleteStmt (scrW tbl : ℕ) (wPoolBase wUid wScr : ℤ) (n : ℕ) : ArithRAMStmt :=
  let bE := IntExpr.readHeap scrW (.lit wPoolBase)
  let wMem := wScr + 3
  let wP := wScr + 4
  let wLast := wScr + 5
  let wULast := wScr + 6
  let wHLast := wScr + 7
  let wH := wScr + 1
  .seq (swapPoolMemStmt scrW tbl wPoolBase wUid wScr wMem n)
    (.ite (.intEq (.readHeap scrW (.lit wMem)) (.lit 1))
      (.seq (.writeWordHeap scrW (.lit wH) (.mod (.readHeap scrW (.lit wUid)) (.lit (n : ℤ))))
      (.seq (.writeWordHeap scrW (.lit wP)
              (.readHeap tbl (.add (.add bE (.lit (4 + (n : ℤ)))) (.readHeap scrW (.lit wH)))))
      (.seq (.writeWordHeap scrW (.lit wLast) (.sub (.readHeap tbl (.add bE (.lit 1))) (.lit 1)))
      (.seq (.writeWordHeap tbl (.add (.add bE (.lit 4)) (.readHeap scrW (.lit wH))) (.lit 0))
      (.seq (.writeWordHeap tbl (.add bE (.lit 1)) (.readHeap scrW (.lit wLast)))
        (.ite (.intEq (.readHeap scrW (.lit wP)) (.readHeap scrW (.lit wLast)))
          .skip
          (.seq (.writeWordHeap scrW (.lit wULast)
                  (.readHeap tbl (.add (.add bE (.lit (4 + 2 * (n : ℤ)))) (.readHeap scrW (.lit wLast)))))
          (.seq (.writeWordHeap scrW (.lit wHLast)
                  (.mod (.readHeap scrW (.lit wULast)) (.lit (n : ℤ))))
          (.seq (.writeWordHeap tbl (.add (.add bE (.lit (4 + 2 * (n : ℤ)))) (.readHeap scrW (.lit wP)))
                  (.readHeap scrW (.lit wULast)))
                (.writeWordHeap tbl (.add (.add bE (.lit (4 + (n : ℤ)))) (.readHeap scrW (.lit wHLast)))
                  (.readHeap scrW (.lit wP))))))))))))
      .skip)

theorem exec_swapPoolDeleteStmt {d TW BW TR BR scrW tbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wPoolBase wUid wScr base : ℤ) {n : ℕ} (hn : 1 ≤ n)
    {S : Finset ℕ} {P : SwapPool} (hwf : P.WF n S) (uid : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htbl : tbl < TW) (hne_scr : tbl ≠ scrW)
    (hbase : 0 ≤ base ∧ base + swapPoolStride n ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 8 ≤ (BW : ℤ))
    (hneB : wPoolBase < wScr ∨ wScr + 8 ≤ wPoolBase)
    (hneU : wUid < wScr ∨ wScr + 8 ≤ wUid)
    (hbase_r : H3a.wRead m₀ scrW wPoolBase = base)
    (huid_r : H3a.wRead m₀ scrW wUid = (uid : ℤ))
    (henc : EncSwapPool tbl base n P m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (swapPoolDeleteStmt scrW tbl wPoolBase wUid wScr n) m₀ m₁ 285 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncSwapPool tbl base n (P.delete n uid) m₁ ∧
      H3a.wRead m₁ scrW wPoolBase = base ∧
      H3a.wRead m₁ scrW wUid = (uid : ℤ) ∧
      WordFrameOutside scrW tbl base (swapPoolStride n) m₀ m₁ := by
  obtain ⟨m1, hd_m, hfp1, hw_mem, hb1, hu1, hfr_m0⟩ :=
    exec_swapPoolMemStmt inp wPoolBase wUid wScr (wScr + 3) base hn hwf uid
      hfp₀ hscrW hne_scr ⟨hwScr.1, by omega⟩ ⟨by omega, by omega⟩
      (by omega) (by omega) hbase_r huid_r henc
  have hb_m1 : H3a.wRead m1 scrW wPoolBase = base := hb1 (by omega)
  have hu_m1 : H3a.wRead m1 scrW wUid = (uid : ℤ) := hu1 (by omega)
  have hfr_m : WordFrameOutside scrW tbl base (swapPoolStride n) m₀ m1 :=
    hfr_m0.mono_len (by dsimp [swapPoolStride]; omega)
  have henc1 : EncSwapPool tbl base n P m1 :=
    henc.mono_frame hfr_m0 hne_scr (Or.inr (Or.inr (by omega))) hwf.2.2.2.1
  let condMem : ArithCondExpr := .intEq (.readHeap scrW (.lit (wScr + 3))) (.lit 1)
  by_cases hmem : P.memPred n uid
  · have hc_t : cValAt 0 inp m1 condMem = true := by
      simp only [cValAt, condMem, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m1 scrW (wScr + 3) = 1) = true
      rw [hw_mem, if_pos hmem]; rfl
    let h := uid % n
    have hh_lt : h < n := Nat.mod_lt uid hn
    obtain ⟨hp_lt, _⟩ := hwf.2.2.2.2.2.2.2 h hh_lt hmem.1
    have hsz_le : P.sz ≤ n := hwf.2.2.2.1
    let p := P.pos h
    let last := P.sz - 1
    let uLast := P.arr last
    let hLast := uLast % n
    have hhL_lt : hLast < n := Nat.mod_lt uLast hn
    obtain ⟨hd2, hfp2, hfr2⟩ := detWriteScr (tbl := tbl) (C := 15) inp base (swapPoolStride n)
      (.lit (wScr + 1)) (.mod (.readHeap scrW (.lit wUid)) (.lit (n : ℤ))) (wScr + 1) (h : ℤ)
      hfp1 hscrW (by omega) (by omega) rfl
      (by change H3a.wRead m1 scrW wUid % (n : ℤ) = (h : ℤ); rw [hu_m1]; exact (Int.natCast_emod uid n).symm)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m2 := H3a.wWrite m1 scrW (wScr + 1) (h : ℤ)
    obtain ⟨hd3, hfp3, hfr3⟩ := detWriteScr (tbl := tbl) (C := 20) inp base (swapPoolStride n)
      (.lit (wScr + 4))
      (.readHeap tbl (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit (4 + (n : ℤ)))) (.readHeap scrW (.lit (wScr + 1)))))
      (wScr + 4) (p : ℤ) hfp2 hscrW (by omega) (by omega) rfl
      (by
        change H3a.wRead m2 tbl ((H3a.wRead m2 scrW wPoolBase + (4 + (n : ℤ))) + H3a.wRead m2 scrW (wScr + 1)) = (p : ℤ)
        rw [wRead_wWrite_of_ne _ _ (Or.inl hne_scr), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hb_m1, wRead_wWrite_self, show (base + (4 + (n : ℤ))) + (h : ℤ) = base + 4 + (n : ℤ) + (h : ℤ) by ring]
        exact henc1.2.2.2.1 h hh_lt)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m3 := H3a.wWrite m2 scrW (wScr + 4) (p : ℤ)
    obtain ⟨hd4, hfp4, hfr4⟩ := detWriteScr (tbl := tbl) (C := 15) inp base (swapPoolStride n)
      (.lit (wScr + 5)) (.sub (.readHeap tbl (.add (.readHeap scrW (.lit wPoolBase)) (.lit 1))) (.lit 1))
      (wScr + 5) (last : ℤ) hfp3 hscrW (by omega) (by omega) rfl
      (by
        change H3a.wRead m3 tbl (H3a.wRead m3 scrW wPoolBase + 1) - 1 = (last : ℤ)
        rw [wRead_wWrite_of_ne _ _ (Or.inl hne_scr), wRead_wWrite_of_ne _ _ (Or.inl hne_scr), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hb_m1, henc1.2.1]
        dsimp [last]; omega)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m4 := H3a.wWrite m3 scrW (wScr + 5) (last : ℤ)
    have hscr4 : H3a.wRead m4 scrW wPoolBase = base ∧ H3a.wRead m4 scrW wUid = (uid : ℤ) ∧
        H3a.wRead m4 scrW (wScr + 1) = (h : ℤ) ∧ H3a.wRead m4 scrW (wScr + 4) = (p : ℤ) ∧
        H3a.wRead m4 scrW (wScr + 5) = (last : ℤ) := by
      refine ⟨?_, ?_, ?_, ?_, wRead_wWrite_self _ _ _ _⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hb_m1]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hu_m1]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
    have htbl4 : ∀ i, H3a.wRead m4 tbl i = H3a.wRead m1 tbl i := by
      intro i; rw [wRead_wWrite_of_ne _ _ (Or.inl hne_scr), wRead_wWrite_of_ne _ _ (Or.inl hne_scr), wRead_wWrite_of_ne _ _ (Or.inl hne_scr)]
    obtain ⟨hd5, hfp5, hfr5⟩ := detWritePool (scrW := scrW) (C := 20) inp base (swapPoolStride n)
      (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit 4)) (.readHeap scrW (.lit (wScr + 1))))
      (.lit 0) (base + 4 + (h : ℤ)) 0 hfp4 htbl hbase (by omega) (by dsimp [swapPoolStride]; omega)
      (by change (H3a.wRead m4 scrW wPoolBase + 4) + H3a.wRead m4 scrW (wScr + 1) = _; rw [hscr4.1, hscr4.2.2.1])
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m5 := H3a.wWrite m4 tbl (base + 4 + (h : ℤ)) 0
    have hw_scr5 : ∀ i, H3a.wRead m5 scrW i = H3a.wRead m4 scrW i :=
      fun i => wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)
    obtain ⟨hd6, hfp6, hfr6⟩ := detWritePool (scrW := scrW) (C := 15) inp base (swapPoolStride n)
      (.add (.readHeap scrW (.lit wPoolBase)) (.lit 1)) (.readHeap scrW (.lit (wScr + 5)))
      (base + 1) (last : ℤ) hfp5 htbl hbase (by omega) (by dsimp [swapPoolStride]; omega)
      (by change H3a.wRead m5 scrW wPoolBase + 1 = _; rw [hw_scr5, hscr4.1])
      (by change H3a.wRead m5 scrW (wScr + 5) = _; rw [hw_scr5, hscr4.2.2.2.2])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    let m6 := H3a.wWrite m5 tbl (base + 1) (last : ℤ)
    have hw_scr6 : ∀ i, H3a.wRead m6 scrW i = H3a.wRead m4 scrW i :=
      fun i => (wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)).trans (hw_scr5 i)
    let condEq : ArithCondExpr := .intEq (.readHeap scrW (.lit (wScr + 4))) (.readHeap scrW (.lit (wScr + 5)))
    by_cases hpl : p = last
    · have hceq_t : cValAt 0 inp m6 condEq = true := by
        simp only [cValAt, condEq, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m6 scrW (wScr + 4) = H3a.wRead m6 scrW (wScr + 5)) = true
        rw [hw_scr6, hw_scr6, hscr4.2.2.2.1, hscr4.2.2.2.2, hpl]; simp
      have hdel_eq : P.delete n uid =
          { ep := P.ep, sz := last, hEp := Function.update P.hEp h 0, pos := P.pos, arr := P.arr } := by
        unfold SwapPool.delete; rw [if_pos hmem]; dsimp only; rw [if_pos hpl]
      refine ⟨m6, (DetExecAt.seq hd_m
        (DetExecAt.ite_true hc_t (C_c := 10) (by dsimp [condMem, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (DetExecAt.seq hd2 (DetExecAt.seq hd3 (DetExecAt.seq hd4 (DetExecAt.seq hd5 (DetExecAt.seq hd6
            (DetExecAt.ite_true hceq_t (C_c := 10) (by dsimp [condEq, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.skip 0 inp m6))))))))).mono_cost (by omega), hfp6, ?_, (hw_scr6 wPoolBase).trans hscr4.1, (hw_scr6 wUid).trans hscr4.2.1,
        ((((hfr_m.trans hfr2).trans hfr3).trans hfr4).trans hfr5).trans hfr6⟩
      rw [hdel_eq]; unfold EncSwapPool; dsimp only
      refine ⟨?_, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4, henc1.1]
      · intro x hx
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        by_cases he : x = h
        · subst he; rw [wRead_wWrite_self, Function.update_self]; rfl
        · rw [Function.update_of_ne he, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
          exact henc1.2.2.1 x hx
      · intro x hx
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
        exact henc1.2.2.2.1 x hx
      · intro r hr
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
        exact henc1.2.2.2.2 r (by omega)
    · have hceq_f : cValAt 0 inp m6 condEq = false := by
        simp only [cValAt, condEq, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m6 scrW (wScr + 4) = H3a.wRead m6 scrW (wScr + 5)) = false
        rw [hw_scr6, hw_scr6, hscr4.2.2.2.1, hscr4.2.2.2.2, decide_eq_false_iff_not]
        exact_mod_cast hpl
      obtain ⟨hd7, hfp7, hfr7⟩ := detWriteScr (tbl := tbl) (C := 20) inp base (swapPoolStride n)
        (.lit (wScr + 6))
        (.readHeap tbl (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit (4 + 2 * (n : ℤ)))) (.readHeap scrW (.lit (wScr + 5)))))
        (wScr + 6) (uLast : ℤ) hfp6 hscrW (by omega) (by omega) rfl
        (by
          change H3a.wRead m6 tbl ((H3a.wRead m6 scrW wPoolBase + (4 + 2 * (n : ℤ))) + H3a.wRead m6 scrW (wScr + 5)) = (uLast : ℤ)
          rw [hw_scr6, hw_scr6, hscr4.1, hscr4.2.2.2.2,
              show (base + (4 + 2 * (n : ℤ))) + (last : ℤ) = base + 4 + 2 * (n : ℤ) + (last : ℤ) by ring, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
          exact henc1.2.2.2.2 last (by omega))
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      let m7 := H3a.wWrite m6 scrW (wScr + 6) (uLast : ℤ)
      obtain ⟨hd8, hfp8, hfr8⟩ := detWriteScr (tbl := tbl) (C := 15) inp base (swapPoolStride n)
        (.lit (wScr + 7)) (.mod (.readHeap scrW (.lit (wScr + 6))) (.lit (n : ℤ)))
        (wScr + 7) (hLast : ℤ) hfp7 hscrW (by omega) (by omega) rfl
        (by change H3a.wRead m7 scrW (wScr + 6) % (n : ℤ) = (hLast : ℤ); rw [wRead_wWrite_self]; exact (Int.natCast_emod uLast n).symm)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      let m8 := H3a.wWrite m7 scrW (wScr + 7) (hLast : ℤ)
      have hscr8 : H3a.wRead m8 scrW wPoolBase = base ∧ H3a.wRead m8 scrW wUid = (uid : ℤ) ∧
          H3a.wRead m8 scrW (wScr + 4) = (p : ℤ) ∧ H3a.wRead m8 scrW (wScr + 6) = (uLast : ℤ) ∧
          H3a.wRead m8 scrW (wScr + 7) = (hLast : ℤ) := by
        refine ⟨?_, ?_, ?_, ?_, wRead_wWrite_self _ _ _ _⟩
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw_scr6, hscr4.1]
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw_scr6, hscr4.2.1]
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hw_scr6, hscr4.2.2.2.1]
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
      have htbl8 : ∀ i, H3a.wRead m8 tbl i = H3a.wRead m6 tbl i := by
        intro i; rw [wRead_wWrite_of_ne _ _ (Or.inl hne_scr), wRead_wWrite_of_ne _ _ (Or.inl hne_scr)]
      obtain ⟨hd9, hfp9, hfr9⟩ := detWritePool (scrW := scrW) (C := 20) inp base (swapPoolStride n)
        (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit (4 + 2 * (n : ℤ)))) (.readHeap scrW (.lit (wScr + 4))))
        (.readHeap scrW (.lit (wScr + 6)))
        (base + 4 + 2 * (n : ℤ) + (p : ℤ)) (uLast : ℤ) hfp8 htbl hbase (by omega) (by dsimp [swapPoolStride]; omega)
        (by change (H3a.wRead m8 scrW wPoolBase + (4 + 2 * (n : ℤ))) + H3a.wRead m8 scrW (wScr + 4) = _; rw [hscr8.1, hscr8.2.2.1]; ring)
        hscr8.2.2.2.1 (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      let m9 := H3a.wWrite m8 tbl (base + 4 + 2 * (n : ℤ) + (p : ℤ)) (uLast : ℤ)
      have hw_scr9 : ∀ i, H3a.wRead m9 scrW i = H3a.wRead m8 scrW i :=
        fun i => wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)
      obtain ⟨hd10, hfp10, hfr10⟩ := detWritePool (scrW := scrW) (C := 20) inp base (swapPoolStride n)
        (.add (.add (.readHeap scrW (.lit wPoolBase)) (.lit (4 + (n : ℤ)))) (.readHeap scrW (.lit (wScr + 7))))
        (.readHeap scrW (.lit (wScr + 4)))
        (base + 4 + (n : ℤ) + (hLast : ℤ)) (p : ℤ) hfp9 htbl hbase (by omega) (by dsimp [swapPoolStride]; omega)
        (by change (H3a.wRead m9 scrW wPoolBase + (4 + (n : ℤ))) + H3a.wRead m9 scrW (wScr + 7) = _; rw [hw_scr9, hw_scr9, hscr8.1, hscr8.2.2.2.2]; ring)
        (by change H3a.wRead m9 scrW (wScr + 4) = _; rw [hw_scr9, hscr8.2.2.1])
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      let m10 := H3a.wWrite m9 tbl (base + 4 + (n : ℤ) + (hLast : ℤ)) (p : ℤ)
      have hw_scr10 : ∀ i, H3a.wRead m10 scrW i = H3a.wRead m8 scrW i :=
        fun i => (wRead_wWrite_of_ne _ _ (Or.inl hne_scr.symm)).trans (hw_scr9 i)
      have hdel_eq : P.delete n uid =
          { ep := P.ep, sz := last, hEp := Function.update P.hEp h 0,
            pos := Function.update P.pos hLast p, arr := Function.update P.arr p uLast } := by
        unfold SwapPool.delete; rw [if_pos hmem]; dsimp only; rw [if_neg hpl]
      refine ⟨m10, (DetExecAt.seq hd_m
        (DetExecAt.ite_true hc_t (C_c := 10) (by dsimp [condMem, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (DetExecAt.seq hd2 (DetExecAt.seq hd3 (DetExecAt.seq hd4 (DetExecAt.seq hd5 (DetExecAt.seq hd6
            (DetExecAt.ite_false hceq_f (C_c := 10) (by dsimp [condEq, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.seq hd7 (DetExecAt.seq hd8 (DetExecAt.seq hd9 hd10))))))))))).mono_cost (by omega), hfp10, ?_, (hw_scr10 wPoolBase).trans hscr8.1, (hw_scr10 wUid).trans hscr8.2.1,
        ((((((((hfr_m.trans hfr2).trans hfr3).trans hfr4).trans hfr5).trans hfr6).trans hfr7).trans hfr8).trans hfr9).trans hfr10⟩
      rw [hdel_eq]; unfold EncSwapPool; dsimp only
      refine ⟨?_, ?_, ?_, ?_, ?_⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl8, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            htbl4, henc1.1]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl8, wRead_wWrite_self]
      · intro x hx
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl8, wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        by_cases he : x = h
        · subst he; rw [wRead_wWrite_self, Function.update_self]; rfl
        · rw [Function.update_of_ne he, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
          exact henc1.2.2.1 x hx
      · intro x hx
        by_cases he : x = hLast
        · subst he; rw [wRead_wWrite_self, Function.update_self]
        · rw [Function.update_of_ne he, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl8,
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
          exact henc1.2.2.2.1 x hx
      · intro r hr
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        by_cases hrp : r = p
        · subst hrp; rw [wRead_wWrite_self, Function.update_self]
        · rw [Function.update_of_ne hrp, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl8, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), htbl4]
          exact henc1.2.2.2.2 r (by omega)
  · have hc_f : cValAt 0 inp m1 condMem = false := by
      simp only [cValAt, condMem, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m1 scrW (wScr + 3) = 1) = false
      rw [hw_mem, if_neg hmem]; decide
    have hdel_eq : P.delete n uid = P := by unfold SwapPool.delete; rw [if_neg hmem]
    refine ⟨m1, (DetExecAt.seq hd_m
      (DetExecAt.ite_false hc_f (C_c := 10) (by dsimp [condMem, UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.skip 0 inp m1))).mono_cost (by omega), hfp1, hdel_eq.symm ▸ henc1, hb_m1, hu_m1, hfr_m⟩

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
