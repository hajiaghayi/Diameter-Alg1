import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2A0
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 3. Fresh Physical Node Slot Allocator (`allocFreshSlotStmt`) -/

def allocMarkServStmt : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 41) (.readHeap engMetaTbl (.lit 0)))
    (dynForLoopStmt 40 41
      (.seq (.writeWordHeap engScrTbl (.lit 42)
              (.readHeap engMetaTbl (.add (.lit 16) (.readHeap engScrTbl (.lit 40)))))
            (.writeWordHeap engScrTbl
              (.add (.lit 64) (.readHeap engScrTbl (.lit 42))) (.lit 1))))

def markJobSlotsStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .ite (.intEq (.readHeap engMetaTbl (.lit base)) (.lit 1))
    (.seq (.writeWordHeap engScrTbl (.lit 41) (.readHeap engMetaTbl (.lit (base + 1))))
    (.seq (dynForLoopStmt 40 41
            (.seq (.writeWordHeap engScrTbl (.lit 42)
                    (.readHeap engMetaTbl
                      (.add (.lit (readySlotOff cp r.val 0)) (.readHeap engScrTbl (.lit 40)))))
                  (.writeWordHeap engScrTbl
                    (.add (.lit 64) (.readHeap engScrTbl (.lit 42))) (.lit 1))))
          (.ite (.intEq (.readHeap engMetaTbl (.lit (base + 2))) (.lit 1))
            (.seq (.writeWordHeap engScrTbl (.lit 42) (.readHeap engMetaTbl (.lit (base + 7))))
                  (.writeWordHeap engScrTbl
                    (.add (.lit 64) (.readHeap engScrTbl (.lit 42))) (.lit 1)))
            .skip)))
    .skip

def allocFreshSlotStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ArithRAMStmt :=
  let M := M_slots cp
  .seq (forLoopStmt engScrTbl 40 M
          (.writeWordHeap engScrTbl (.add (.lit 64) (.readHeap engScrTbl (.lit 40))) (.lit 0)))
  (.seq allocMarkServStmt
  (.seq (foldrSeqStmt (markJobSlotsStmt cp) (List.finRange cp.D_max))
        (forLoopStmt engScrTbl 40 M
          (.ite (.intEq (.readHeap engScrTbl (.add (.lit 64) (.readHeap engScrTbl (.lit 40)))) (.lit 0))
            (.writeWordHeap engScrTbl (.lit 39) (.readHeap engScrTbl (.lit 40)))
            .skip))))

theorem zeroRand_allocFreshSlotStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ZeroRandStmt (allocFreshSlotStmt cp) := by
  unfold allocFreshSlotStmt allocMarkServStmt
  refine .seq (zeroRand_forLoopStmt (.writeWordHeap _ _ _))
    (.seq (.seq (.writeWordHeap _ _ _)
      (zeroRand_dynForLoopStmt 40 41 (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))
    (.seq (zeroRand_foldrSeqStmt _ (fun r _ => ?_))
          (zeroRand_forLoopStmt (.ite (.writeWordHeap _ _ _) .skip))))
  unfold markJobSlotsStmt
  exact .ite (.seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_dynForLoopStmt 40 41 (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))
      (.ite (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)) .skip))) .skip

def allocFreshSlotCost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  100 * M_slots cp + 500

private def AllocFrame (m₀ m : ArithRAMMemory) : Prop :=
  (∀ t, t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
  (∀ i, i < 39 → wRead m engScrTbl i = wRead m₀ engScrTbl i) ∧
  (∀ t i, rRead m t i = rRead m₀ t i)

private theorem allocFrame_refl (m₀ : ArithRAMMemory) : AllocFrame m₀ m₀ :=
  ⟨fun _ _ _ => rfl, fun _ _ => rfl, fun _ _ => rfl⟩

private theorem allocFrame_wWrite_scr {m₀ m : ArithRAMMemory} {idx v : ℤ}
    (h39 : 39 ≤ idx) (hf : AllocFrame m₀ m) :
    AllocFrame m₀ (H3a.wWrite m engScrTbl idx v) :=
  ⟨fun t ht i => (wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (hf.1 t ht i),
   fun i hi => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (hf.2.1 i hi),
   fun t i => (rRead_wWrite _ _ _ _ _ _).trans (hf.2.2 t i)⟩

private def MarkList (M : ℕ) (m₀ : ArithRAMMemory) (L : List ℕ) (m : ArithRAMMemory) : Prop :=
  AllocFrame m₀ m ∧ ∀ s < M, wRead m engScrTbl (64 + (s : ℤ)) = if s ∈ L then 1 else 0

private theorem exec_allocMarkJob {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (m₀ : ArithRAMMemory) (r : Fin cp.D_max)
    {prevList : List ℕ} {jbOpt : Option (SuffixJob cp)} {rSlots : List ℕ} {cSlot : ℕ}
    {m : ArithRAMMemory}
    (hfp : InFootprint ops.TW ops.BW ops.TR ops.BR m)
    (hmk : MarkList (M_slots cp) m₀ prevList m)
    (hj_enc : EncJobSlot ops r jbOpt rSlots cSlot m₀)
    (hu_lt : ∀ s ∈ jobUsedSlots jbOpt rSlots cSlot, s < M_slots cp) :
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (markJobSlotsStmt cp r) m
      (MarkList (M_slots cp) m₀ (prevList ++ jobUsedSlots jbOpt rSlots cSlot))
      (64 + cp.D_max * 36) := by
  have hTW := ops.hTW
  have hBW_scr := ops.hBW_scr
  let base := jobMetaBase cp r.val
  rcases hmk with ⟨hfr_m, hmk_m⟩
  unfold markJobSlotsStmt
  cases hcj : jbOpt with
  | none =>
      simp only [EncJobSlot, hcj] at hj_enc
      have hcond0 : (evalArithCond inp 0 m (.intEq (.readHeap engMetaTbl (.lit base)) (.lit 1))).1 = false := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead m engMetaTbl base = 1) = false
        rw [(hfr_m.1 engMetaTbl (by decide) base).trans hj_enc.2]; decide
      refine ExecDet.ite' (C_c := 8) (C_b := 56 + cp.D_max * 36) _ _ _ hcond0
        (by simp [condExprOps, intExprOps]) (fun ht => by cases ht)
        (fun _ => ?_) (by omega)
      refine ExecDet.skip inp hfp ?_ (by omega)
      simpa [MarkList, jobUsedSlots] using (⟨hfr_m, hmk_m⟩ : MarkList (M_slots cp) m₀ prevList m)
  | some jb =>
      simp only [EncJobSlot, hcj] at hj_enc
      rcases hj_enc with ⟨hact1, hr_le, hr_len, hw_rlen, hready_enc, hph_enc⟩
      have hcond1 : (evalArithCond inp 0 m (.intEq (.readHeap engMetaTbl (.lit base)) (.lit 1))).1 = true := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead m engMetaTbl base = 1) = true
        rw [(hfr_m.1 engMetaTbl (by decide) base).trans hact1]; decide
      refine ExecDet.ite' (C_c := 8) (C_b := 56 + cp.D_max * 36) _ _ _ hcond1
        (by simp [condExprOps, intExprOps]) (fun _ => ?_)
        (fun hf => by cases hf) (by omega)
      have hW41 := ExecDet.wWrite (TW := ops.TW) (BW := ops.BW) (TR := ops.TR) (BR := ops.BR)
        (C := 12) inp engScrTbl (.lit 41) (.readHeap engMetaTbl (.lit (base + 1)))
        41 (jb.ready.length : ℤ) hfp (by unfold engScrTbl; omega) (by omega)
        (by unfold M_slots at hBW_scr; omega) rfl
        (by simp only [evalIntExpr]; exact (hfr_m.1 engMetaTbl (by decide) (base + 1)).trans hw_rlen)
        (by simp [intExprOps]) rfl
      refine ExecDet.seq' (44 + cp.D_max * 36) hW41 (by omega) ?_
      intro mR0 hmR0 hfpR0; subst hmR0
      let InvR (q : ℕ) (m' : ArithRAMMemory) : Prop :=
        MarkList (M_slots cp) m₀ (prevList ++ rSlots.take q) m'
      have hRLoop : ExecDet ops.TW ops.BW ops.TR ops.BR inp
          (dynForLoopStmt 40 41
            (.seq (.writeWordHeap engScrTbl (.lit 42)
                    (.readHeap engMetaTbl
                      (.add (.lit (readySlotOff cp r.val 0)) (.readHeap engScrTbl (.lit 40)))))
                  (.writeWordHeap engScrTbl
                    (.add (.lit 64) (.readHeap engScrTbl (.lit 42))) (.lit 1))))
          (H3a.wWrite m engScrTbl 41 (jb.ready.length : ℤ))
          (InvR jb.ready.length) (16 + cp.D_max * (24 + 12)) := by
        refine ExecDet.dynForLoop 40 41 _ InvR hfpR0 (by omega) (by omega)
          (by unfold M_slots at hBW_scr; omega) (by decide)
          (wRead_wWrite_self _ _ _ _) hr_le
          ⟨allocFrame_wWrite_scr (by omega) (allocFrame_wWrite_scr (by omega) hfr_m),
           fun s hs => by
             simp only [List.take_zero, List.append_nil]
             rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                 wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
             exact hmk_m s hs⟩ ?_
        intro q hq mQ ⟨hfrQ, hmkQ⟩ hctrQ hfpQ
        have hqs : q < rSlots.length := hr_len.symm ▸ hq
        set sl := rSlots[q]'hqs
        have hsl_used : sl ∈ jobUsedSlots (some jb) rSlots cSlot := by
          dsimp only [jobUsedSlots, sl]
          cases jb.phase with
          | copy _ => exact List.getElem_mem hqs
          | build _ => exact List.mem_append_left _ (List.getElem_mem hqs)
        have hsl_M : sl < M_slots cp := hu_lt sl (hcj ▸ hsl_used)
        have hoff_eq : readySlotOff cp r.val 0 + (q : ℤ) = readySlotOff cp r.val q := by
          unfold readySlotOff; ring
        have hread_sl : wRead mQ engMetaTbl (readySlotOff cp r.val 0 + (q : ℤ)) = (sl : ℤ) := by
          rw [hoff_eq]; exact (hfrQ.1 engMetaTbl (by decide) _).trans (hready_enc q hq hqs).1
        refine ExecDet.seq' 12
          (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 42)
            (.readHeap engMetaTbl
              (.add (.lit (readySlotOff cp r.val 0)) (.readHeap engScrTbl (.lit 40))))
            42 (sl : ℤ) hfpQ (by unfold engScrTbl; omega) (by omega)
            (by unfold M_slots at hBW_scr; omega) rfl
            (by simp only [evalIntExpr]
                change wRead mQ engMetaTbl (readySlotOff cp r.val 0 + wRead mQ engScrTbl 40) = _
                rw [hctrQ, hread_sl])
            (by simp [intExprOps]) rfl) (by omega) ?_
        intro mQA hmQA hfpQA; subst hmQA
        refine ExecDet.wWrite (C := 12) inp engScrTbl
          (.add (.lit 64) (.readHeap engScrTbl (.lit 42))) (.lit 1) (64 + (sl : ℤ)) 1
          hfpQA (by unfold engScrTbl; omega) (by omega) (by omega)
          (by simp only [evalIntExpr]; change 64 + wRead _ engScrTbl 42 = _; rw [wRead_wWrite_self]) rfl
          (by simp [intExprOps]) ?_
        refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                       wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctrQ,
                allocFrame_wWrite_scr (by omega) (allocFrame_wWrite_scr (by omega)
                  (allocFrame_wWrite_scr (by omega) hfrQ)),
                fun s hs => ?_⟩
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), List.take_succ_eq_append_getElem hqs,
            ← List.append_assoc]
        change _ = if s ∈ (prevList ++ rSlots.take q) ++ [sl] then (1 : ℤ) else 0
        by_cases heq : s = sl
        · rw [heq, wRead_wWrite_self, if_pos (List.mem_append_right _ (List.mem_singleton.mpr rfl))]
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hmkQ s hs]
          simp only [List.mem_append, List.mem_singleton, heq, or_false]
      refine ExecDet.seq' 28 hRLoop (by omega) ?_
      intro mRD hInvRD hfpRD
      dsimp only [InvR] at hInvRD
      rw [← hr_len, List.take_length] at hInvRD
      rcases hInvRD with ⟨hfrRD, hmkRD⟩
      cases hph : jb.phase with
      | copy cs =>
          simp only [hph] at hph_enc
          have hcondP : (evalArithCond inp 0 mRD (.intEq (.readHeap engMetaTbl (.lit (base + 2))) (.lit 1))).1 = false := by
            simp only [evalArithCond, evalIntExpr]
            change decide (wRead mRD engMetaTbl (base + 2) = 1) = false
            rw [(hfrRD.1 engMetaTbl (by decide) (base + 2)).trans hph_enc.1]; decide
          refine ExecDet.ite' (C_c := 8) (C_b := 20) _ _ _ hcondP
            (by simp [condExprOps, intExprOps]) (fun ht => by cases ht)
            (fun _ => ?_) (by omega)
          refine ExecDet.skip inp hfpRD ?_ (by omega)
          simpa [MarkList, jobUsedSlots, hph] using (⟨hfrRD, hmkRD⟩ : MarkList (M_slots cp) m₀ (prevList ++ rSlots) mRD)
      | build bs =>
          simp only [hph] at hph_enc
          rcases hph_enc with ⟨hp2, _, _, _, _, hcslot_r, _⟩
          have hcondP : (evalArithCond inp 0 mRD (.intEq (.readHeap engMetaTbl (.lit (base + 2))) (.lit 1))).1 = true := by
            simp only [evalArithCond, evalIntExpr]
            change decide (wRead mRD engMetaTbl (base + 2) = 1) = true
            rw [(hfrRD.1 engMetaTbl (by decide) (base + 2)).trans hp2]; decide
          refine ExecDet.ite' (C_c := 8) (C_b := 20) _ _ _ hcondP
            (by simp [condExprOps, intExprOps]) (fun _ => ?_)
            (fun hf => by cases hf) (by omega)
          have hcslot_M : cSlot < M_slots cp := hu_lt cSlot (by simp [hcj, hph, jobUsedSlots])
          refine ExecDet.seq' 12
            (ExecDet.wWrite (C := 8) inp engScrTbl (.lit 42) (.readHeap engMetaTbl (.lit (base + 7)))
              42 (cSlot : ℤ) hfpRD (by unfold engScrTbl; omega) (by omega)
              (by unfold M_slots at hBW_scr; omega) rfl
              (by simp only [evalIntExpr]; exact (hfrRD.1 engMetaTbl (by decide) (base + 7)).trans hcslot_r)
              (by simp [intExprOps]) rfl) (by omega) ?_
          intro mC hmC hfpC; subst hmC
          refine ExecDet.wWrite (C := 12) inp engScrTbl
            (.add (.lit 64) (.readHeap engScrTbl (.lit 42))) (.lit 1) (64 + (cSlot : ℤ)) 1
            hfpC (by unfold engScrTbl; omega) (by omega) (by omega)
            (by simp only [evalIntExpr]; change 64 + wRead _ engScrTbl 42 = _; rw [wRead_wWrite_self]) rfl
            (by simp [intExprOps]) ?_
          refine ⟨allocFrame_wWrite_scr (by omega) (allocFrame_wWrite_scr (by omega) hfrRD),
            fun s hs => ?_⟩
          simp only [jobUsedSlots, hph, ← List.append_assoc]
          by_cases heq : s = cSlot
          · subst heq; simp [List.mem_append, wRead_wWrite_self]
          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hmkRD s hs]
            simp [List.mem_append, heq]

theorem exec_allocFreshSlotStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    {servLen : ℕ} {servSlots : List ℕ}
    {curJobs : Fin cp.D_max → Option (SuffixJob cp)}
    {readySlots : Fin cp.D_max → List ℕ}
    {curSlots : Fin cp.D_max → ℕ}
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hserv_le : servLen ≤ cp.D_max)
    (hslen : servSlots.length = servLen)
    (hmeta0 : wRead m₀ engMetaTbl 0 = (servLen : ℤ))
    (hserv_slots : ∀ i (his : i < servSlots.length),
      wRead m₀ engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ))
    (hjobs_enc : ∀ r : Fin cp.D_max,
      EncJobSlot ops r (curJobs r) (readySlots r) (curSlots r) m₀)
    (hall_lt : ∀ s ∈ servSlots ++
      (List.finRange cp.D_max).flatMap (fun r => jobUsedSlots (curJobs r) (readySlots r) (curSlots r)),
      s < M_slots cp) :
    let allSlots := servSlots ++
      (List.finRange cp.D_max).flatMap (fun r => jobUsedSlots (curJobs r) (readySlots r) (curSlots r))
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (allocFreshSlotStmt cp) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        (∃ ns < M_slots cp, ns ∉ allSlots ∧ wRead m₁ engScrTbl 39 = (ns : ℤ)) ∧
        (∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁) ∧
        (∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i < 39 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      (allocFreshSlotCost cp) := by
  intro allSlots
  have hTW := ops.hTW
  have hBW_scr := ops.hBW_scr
  have hall_len : allSlots.length < M_slots cp := by
    refine M_slots_gt_used cp (hslen.trans_le hserv_le) (fun r => ?_)
    have hj := hjobs_enc r
    cases hcj : curJobs r with
    | none => simp [jobUsedSlots]
    | some jb =>
        simp only [EncJobSlot, hcj] at hj
        rcases hj with ⟨_, hrle, hrlen, _, _, _⟩
        dsimp only [jobUsedSlots]
        cases jb.phase <;> simp only [List.length_append, List.length_singleton, hrlen] <;> omega
  -- Phase 1: Zero `engScrTbl[64 .. 64 + M_slots cp - 1]`
  have hPhase1 : ExecDet ops.TW ops.BW ops.TR ops.BR inp
      (forLoopStmt engScrTbl 40 (M_slots cp)
        (.writeWordHeap engScrTbl (.add (.lit 64) (.readHeap engScrTbl (.lit 40))) (.lit 0)))
      m₀ (MarkList (M_slots cp) m₀ []) (4 + (1 + M_slots cp * 18)) := by
    let InvZ (k : ℕ) (m : ArithRAMMemory) : Prop :=
      AllocFrame m₀ m ∧ ∀ s < k, wRead m engScrTbl (64 + (s : ℤ)) = 0
    refine (ExecDet.forLoop engScrTbl 40 (M_slots cp) _ InvZ 12 hfp₀
      (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
      ⟨allocFrame_wWrite_scr (by omega) (allocFrame_refl m₀),
       fun _ h => absurd h (Nat.not_lt_zero _)⟩ ?_).mono
      (fun m ⟨hfr, hz⟩ _ => ⟨hfr, fun s hs => by simp [hz s hs]⟩) le_rfl
    intro s hs m ⟨hfr, hz⟩ hctr hfp
    refine ExecDet.wWrite (C := 12) inp engScrTbl
      (.add (.lit 64) (.readHeap engScrTbl (.lit 40))) (.lit 0) (64 + (s : ℤ)) 0
      hfp (by unfold engScrTbl; omega) (by omega) (by omega)
      (by simp only [evalIntExpr]; change 64 + wRead m engScrTbl 40 = _; rw [hctr]) rfl
      (by simp [intExprOps]) ?_
    refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctr,
      allocFrame_wWrite_scr (by omega) (allocFrame_wWrite_scr (by omega) hfr), fun s' hs' => ?_⟩
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    rcases Nat.lt_succ_iff_lt_or_eq.mp hs' with hlt | rfl
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hz s' hlt
    · exact wRead_wWrite_self _ _ _ _
  -- Phase 2: Mark `servSlots`
  have hPhase2 : ∀ mZ, MarkList (M_slots cp) m₀ [] mZ →
      InFootprint ops.TW ops.BW ops.TR ops.BR mZ →
      ExecDet ops.TW ops.BW ops.TR ops.BR inp allocMarkServStmt
        mZ (MarkList (M_slots cp) m₀ servSlots) (28 + cp.D_max * 36) := by
    intro mZ ⟨hfrZ, hzZ⟩ hfpZ
    unfold allocMarkServStmt
    refine ExecDet.seq' (16 + cp.D_max * 36)
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 41) (.readHeap engMetaTbl (.lit 0)) 41 (servLen : ℤ)
        hfpZ (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
        (by simp only [evalIntExpr]; exact (hfrZ.1 engMetaTbl (by decide) 0).trans hmeta0)
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro mS0 hmS0 hfpS0; subst hmS0
    let InvS (k : ℕ) (m : ArithRAMMemory) : Prop :=
      MarkList (M_slots cp) m₀ (servSlots.take k) m
    refine (ExecDet.dynForLoop 40 41 _ InvS hfpS0 (by omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) (by decide)
      (wRead_wWrite_self _ _ _ _) hserv_le
      ⟨allocFrame_wWrite_scr (by omega) (allocFrame_wWrite_scr (by omega) hfrZ),
       fun s hs => by
         simp only [List.take_zero]
         rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
             wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
         exact hzZ s hs⟩ ?_).mono
      (fun m hm _ => by dsimp only [InvS] at hm; rwa [← hslen, List.take_length] at hm) le_rfl
    intro i hi m ⟨hfr_m, hmk_m⟩ hctr_m hfp_m
    have his : i < servSlots.length := hslen ▸ hi
    set sl := servSlots[i]'his
    have hsl_M : sl < M_slots cp := hall_lt sl (List.mem_append_left _ (List.getElem_mem his))
    have hread_sl : wRead m engMetaTbl (16 + (i : ℤ)) = (sl : ℤ) :=
      (hfr_m.1 engMetaTbl (by decide) (servSlotOff i)).trans (hserv_slots i his)
    refine ExecDet.seq' 12
      (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 42)
        (.readHeap engMetaTbl (.add (.lit 16) (.readHeap engScrTbl (.lit 40)))) 42 (sl : ℤ)
        hfp_m (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
        (by simp only [evalIntExpr]
            change wRead m engMetaTbl (16 + wRead m engScrTbl 40) = _
            rw [hctr_m, hread_sl])
        (by simp [intExprOps]) rfl) (by omega) ?_
    intro mA hmA hfpA; subst hmA
    refine ExecDet.wWrite (C := 12) inp engScrTbl
      (.add (.lit 64) (.readHeap engScrTbl (.lit 42))) (.lit 1) (64 + (sl : ℤ)) 1
      hfpA (by unfold engScrTbl; omega) (by omega) (by omega)
      (by simp only [evalIntExpr]; change 64 + wRead _ engScrTbl 42 = _; rw [wRead_wWrite_self]) rfl
      (by simp [intExprOps]) ?_
    refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                   wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctr_m,
            allocFrame_wWrite_scr (by omega) (allocFrame_wWrite_scr (by omega)
              (allocFrame_wWrite_scr (by omega) hfr_m)),
            fun s hs => ?_⟩
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), List.take_succ_eq_append_getElem his]
    change _ = if s ∈ servSlots.take i ++ [sl] then (1 : ℤ) else 0
    by_cases heq : s = sl
    · rw [heq, wRead_wWrite_self, if_pos (List.mem_append_right _ (List.mem_singleton.mpr rfl))]
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hmk_m s hs]
      simp only [List.mem_append, List.mem_singleton, heq, or_false]
  -- Phase 3: Mark `jobUsedSlots` across all `r : Fin cp.D_max`
  have hPhase3 : ∀ mS, MarkList (M_slots cp) m₀ servSlots mS →
      InFootprint ops.TW ops.BW ops.TR ops.BR mS →
      ExecDet ops.TW ops.BW ops.TR ops.BR inp
        (foldrSeqStmt (markJobSlotsStmt cp) (List.finRange cp.D_max))
        mS (MarkList (M_slots cp) m₀ allSlots)
        (1 + cp.D_max * (64 + cp.D_max * 36)) := by
    intro mS hmkS hfpS
    let JobPref (k : ℕ) : List ℕ :=
      servSlots ++ ((List.finRange cp.D_max).take k).flatMap
        (fun r => jobUsedSlots (curJobs r) (readySlots r) (curSlots r))
    let InvJ (k : ℕ) (m : ArithRAMMemory) : Prop := MarkList (M_slots cp) m₀ (JobPref k) m
    have hrun := ExecDet.foldrSeq (TW := ops.TW) (BW := ops.BW) (TR := ops.TR) (BR := ops.BR)
      (inp := inp) (markJobSlotsStmt cp) (List.finRange cp.D_max) (64 + cp.D_max * 36)
      0 InvJ hfpS (by simpa [InvJ, JobPref] using hmkS) (fun k hk m hIm hfpm => by
        rw [Nat.zero_add] at *
        set r := (List.finRange cp.D_max)[k]'hk
        have htake_succ : (List.finRange cp.D_max).take (k + 1) =
            (List.finRange cp.D_max).take k ++ [r] := List.take_succ_eq_append_getElem hk
        have hJP_eq : JobPref (k + 1) =
            JobPref k ++ jobUsedSlots (curJobs r) (readySlots r) (curSlots r) := by
          dsimp only [JobPref]
          rw [htake_succ, List.flatMap_append, List.flatMap_singleton, List.append_assoc]
        dsimp only [InvJ] at hIm ⊢
        rw [hJP_eq]
        exact exec_allocMarkJob ops inp m₀ r hfpm hIm (hjobs_enc r) (fun s hs =>
          hall_lt s (List.mem_append_right _ (flatMap_mem_iff_finRange.mpr ⟨r, hs⟩))))
    rw [Nat.zero_add, List.length_finRange] at hrun
    refine hrun.mono (fun m hm _ => ?_) le_rfl
    dsimp only [InvJ, JobPref] at hm
    rwa [show (List.finRange cp.D_max).take cp.D_max = List.finRange cp.D_max by simp] at hm
  -- Phase 4: Scan `0 .. M_slots cp - 1` for unmarked slot
  have hex_free : ∃ s₀ < M_slots cp, s₀ ∉ allSlots := by
    by_contra h_all
    push_neg at h_all
    have hsub : Finset.range (M_slots cp) ⊆ allSlots.toFinset := fun s hs =>
      List.mem_toFinset.mpr (h_all s (Finset.mem_range.mp hs))
    have hle := Finset.card_le_card hsub
    rw [Finset.card_range] at hle
    have hcard_le : allSlots.toFinset.card ≤ allSlots.length := List.toFinset_card_le allSlots
    omega
  have hPhase4 : ∀ mJ, MarkList (M_slots cp) m₀ allSlots mJ →
      InFootprint ops.TW ops.BW ops.TR ops.BR mJ →
      ExecDet ops.TW ops.BW ops.TR ops.BR inp
        (forLoopStmt engScrTbl 40 (M_slots cp)
          (.ite (.intEq (.readHeap engScrTbl (.add (.lit 64) (.readHeap engScrTbl (.lit 40)))) (.lit 0))
            (.writeWordHeap engScrTbl (.lit 39) (.readHeap engScrTbl (.lit 40)))
            .skip))
        mJ
        (fun m₁ => AllocFrame m₀ m₁ ∧
          ∃ ns < M_slots cp, ns ∉ allSlots ∧ wRead m₁ engScrTbl 39 = (ns : ℤ))
        (4 + (1 + M_slots cp * 22)) := by
    intro mJ ⟨hfrJ, hmkJ⟩ hfpJ
    let InvScan (k : ℕ) (m : ArithRAMMemory) : Prop :=
      AllocFrame m₀ m ∧
      (∀ s < M_slots cp, wRead m engScrTbl (64 + (s : ℤ)) = if s ∈ allSlots then 1 else 0) ∧
      ((∃ s < k, s ∉ allSlots) → ∃ ns < M_slots cp, ns ∉ allSlots ∧ wRead m engScrTbl 39 = (ns : ℤ))
    refine (ExecDet.forLoop engScrTbl 40 (M_slots cp) _ InvScan 16 hfpJ
      (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
      ⟨allocFrame_wWrite_scr (by omega) hfrJ,
       fun s hs => by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hmkJ s hs,
       fun ⟨_, hs, _⟩ => absurd hs (Nat.not_lt_zero _)⟩ ?_).mono
      (fun m₁ ⟨hfr₁, _, hex₁⟩ _ => ⟨hfr₁, hex₁ hex_free⟩) le_rfl
    intro k hk m ⟨hfr_m, hmk_m, hex_m⟩ hctr_m hfp_m
    by_cases hk_in : k ∈ allSlots
    · have hcondF : (evalArithCond inp 0 m
          (.intEq (.readHeap engScrTbl (.add (.lit 64) (.readHeap engScrTbl (.lit 40)))) (.lit 0))).1 = false := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead m engScrTbl (64 + wRead m engScrTbl 40) = 0) = false
        rw [hctr_m, hmk_m k hk, if_pos hk_in]; decide
      refine ExecDet.ite' (C_c := 8) (C_b := 8) _ _ _ hcondF
        (by simp [condExprOps, intExprOps]) (fun ht => by cases ht)
        (fun _ => ?_) (by omega)
      refine ExecDet.skip inp hfp_m ⟨hctr_m, allocFrame_wWrite_scr (by omega) hfr_m, ?_, ?_⟩ (by omega)
      · intro s hs; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hmk_m s hs
      · rintro ⟨s, hs_lt, hs_not⟩
        have hs_k : s < k := by
          rcases Nat.lt_succ_iff_lt_or_eq.mp hs_lt with hlt | rfl
          · exact hlt
          · exact absurd hk_in hs_not
        obtain ⟨ns, hns_M, hns_not, hw39⟩ := hex_m ⟨s, hs_k, hs_not⟩
        exact ⟨ns, hns_M, hns_not, (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hw39⟩
    · have hcondT : (evalArithCond inp 0 m
          (.intEq (.readHeap engScrTbl (.add (.lit 64) (.readHeap engScrTbl (.lit 40)))) (.lit 0))).1 = true := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead m engScrTbl (64 + wRead m engScrTbl 40) = 0) = true
        rw [hctr_m, hmk_m k hk, if_neg hk_in]; decide
      refine ExecDet.ite' (C_c := 8) (C_b := 8) _ _ _ hcondT
        (by simp [condExprOps, intExprOps]) (fun _ => ?_)
        (fun hf => by cases hf) (by omega)
      refine ExecDet.wWrite (C := 8) inp engScrTbl (.lit 39) (.readHeap engScrTbl (.lit 40)) 39 (k : ℤ)
        hfp_m (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
        (by simp only [evalIntExpr]; exact hctr_m) (by simp [intExprOps]) ?_
      refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctr_m,
              allocFrame_wWrite_scr (by omega) (allocFrame_wWrite_scr (by omega) hfr_m),
              fun s hs => ?_, fun _ => ⟨k, hk, hk_in, ?_⟩⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hmk_m s hs
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  unfold allocFreshSlotStmt
  refine (hPhase1.seq (fun mZ hmZ hfpZ =>
    (hPhase2 mZ hmZ hfpZ).seq (fun mS hmS hfpS =>
      (hPhase3 mS hmS hfpS).seq (fun mJ hmJ hfpJ =>
        hPhase4 mJ hmJ hfpJ)))).mono ?_ ?_
  · intro m₁ ⟨⟨hft₁, hfs₁, hfr₁⟩, hex₁⟩ _
    have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m₁ t i = wRead m₀ t i :=
      fun t ht9 _ i => hft₁ t (by unfold engScrTbl; omega) i
    exact ⟨ops.slotsReady_ext m₀ m₁ hsr₀ hw9 (fun t _ _ i => hfr₁ t i),
      hex₁,
      fun mn s _ he => ops.encNode_ext mn s m₀ m₁ he hw9 (fun t _ _ i => hfr₁ t i)
        (fun _ _ _ _ => hfr₁ ptsRTbl _),
      hft₁, hfs₁, hfr₁⟩
  · unfold allocFreshSlotCost M_slots
    nlinarith

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
