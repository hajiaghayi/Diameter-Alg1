import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.lem_6_2
import UL.Stmt.clm_6_1_adaptive
import UL.Stmt.clm_6_1_precision
import UL.Proof.clm_9_1_explicit_tradeoff.H1_Algebra
import UL.Proof.clm_9_1_explicit_tradeoff.H2_BirthPool
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H3a3_ExactScan
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3c_ChainEngine
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H1
open UL.Proof.clm_9_1_explicit_tradeoff.H2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a3
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 1. Standard `ArithRAMInput` constructors & cell-space helpers -/

def mkInitInp (n d : ℕ) : ArithRAMInput d :=
  { intParams := [(n : ℤ)]
    activeHandles := ∅
    activeCoords := fun _ => 0
    extraReals := [] }

noncomputable def mkUpdateInp {d : ℕ} (n : ℕ) (P : DynamicPointSet d)
    (uop : InternalUpdate d) : ArithRAMInput d :=
  match uop with
  | .insert pt =>
      { intParams := [(n : ℤ), 1, 0]
        activeHandles := P.activeHandles
        activeCoords := P.handleCoords
        extraReals := List.ofFn (fun c : Fin d => euclideanCoord pt c) }
  | .delete delH =>
      { intParams := [(n : ℤ), 0, (delH : ℤ)]
        activeHandles := P.activeHandles
        activeCoords := P.handleCoords
        extraReals := [] }

theorem mkInitInp_cellSpace (n d : ℕ) : (mkInitInp n d).inputCellSpace = 1 := by
  simp [mkInitInp, ArithRAMInput.inputCellSpace]

theorem activeHandles_card_le_of_wf {d n : ℕ} {P : DynamicPointSet d} (hP : P.WellFormed n) :
    P.activeHandles.card ≤ n := by
  have hbij : P.activeHandles.card = P.activeIds.card := by
    refine Finset.card_bij (fun h _ => P.idOfHandle h)
      (fun h hh => (hP.2.2.1 h hh).1)
      (fun h₁ hh₁ h₂ hh₂ heq => by
        dsimp only at heq
        rw [← (hP.2.2.1 h₁ hh₁).2, ← (hP.2.2.1 h₂ hh₂).2, heq])
      (fun pid hpid => ⟨P.handleOfId pid, (hP.2.1 pid hpid).1, (hP.2.1 pid hpid).2⟩)
  rw [hbij]
  exact hP.1

theorem mkUpdateInp_cellSpace_le {d n : ℕ} {P : DynamicPointSet d}
    (hP : P.WellFormed n) (uop : InternalUpdate d) :
    (mkUpdateInp n P uop).inputCellSpace ≤ 3 + n * (d + 1) + d := by
  have hcard := activeHandles_card_le_of_wf hP
  have hmul : P.activeHandles.card * (d + 1) ≤ n * (d + 1) :=
    Nat.mul_le_mul_right (d + 1) hcard
  cases uop with
  | insert pt =>
      simp only [mkUpdateInp, ArithRAMInput.inputCellSpace, List.length_cons,
        List.length_nil, List.length_ofFn]
      omega
  | delete delH =>
      simp only [mkUpdateInp, ArithRAMInput.inputCellSpace, List.length_cons, List.length_nil]
      omega

theorem storageModel_of_readCached_none {d : ℕ} (n : ℕ) (prog : ArithRAMDynamicProgram)
    (initOut : ArithRAMExecOutcome)
    (hans : ArithRAMDynamicProgram.readCachedAnswer initOut.mem = (none, 0)) :
    SatisfiesDynamicStorageAndQueryModel 4 1 (mkArithAlg (d := d) n prog initOut) := by
  refine ⟨?_, ?_, ?_, le_rfl, fun L => by dsimp only [mkArithAlg]; omega⟩
  · dsimp only [mkArithAlg]
    rw [hans]
  · intro activeH hCoords st uop bs out hstep
    cases uop <;>
      (simp only [mkArithAlg, Option.map_eq_some_iff] at hstep;
       rcases hstep with ⟨stepOut, _, rfl⟩;
       rfl)
  · intro activeH hCoords st uop bs₁ bs₂ out₁ out₂ h₁ h₂ hpref
    cases uop with
    | insert pt =>
        simp only [mkArithAlg, Option.map_eq_some_iff] at h₁ h₂
        rcases h₁ with ⟨so₁, he₁, _⟩
        rcases h₂ with ⟨so₂, he₂, _⟩
        exact runArithRAMWithBits_prefixFree prog.updateStmt _ st he₁ he₂ hpref
    | delete h =>
        simp only [mkArithAlg, Option.map_eq_some_iff] at h₁ h₂
        rcases h₁ with ⟨so₁, he₁, _⟩
        rcases h₂ with ⟨so₂, he₂, _⟩
        exact runArithRAMWithBits_prefixFree prog.updateStmt _ st he₁ he₂ hpref

theorem validFactorCAnswer_empty (d n : ℕ) (c : ℝ) :
    IsValidFactorCAnswer c (DynamicPointSet.empty d)
      { diameterHandles := none, cachedDistSq := 0 } := by
  have hwf : (DynamicPointSet.empty d).WellFormed n := by
    refine ⟨by simp [DynamicPointSet.empty], ?_, ?_, ?_, ?_⟩ <;> simp [DynamicPointSet.empty]
  refine validFactorCAnswer_of_handles hwf (fun _ => ⟨rfl, rfl⟩) (fun hge2 => ?_)
  simp [DynamicPointSet.empty] at hge2

/-! ### 2. Abstract Deterministic RAM Spec & Pure Probabilistic Spec for `stepChainEngine` -/

structure StepChainRAMSpec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) where
  TW : ℕ
  BW : ℕ
  TR : ℕ
  BR : ℕ
  coinTbl : ℕ
  scratchTbl : ℕ
  h_coinTbl : coinTbl < TW
  h_scratchTbl : scratchTbl < TW
  h_ne_coin_scr : coinTbl ≠ scratchTbl
  h_coinBW : cp.B_STEP ≤ BW
  h_scrBW : 1 ≤ BW
  EncState : ChainEngineState cp → ArithRAMMemory → Prop
  enc_frame_coins : ∀ (st : ChainEngineState cp) (m₀ m₁ : ArithRAMMemory),
    EncState st m₀ →
    (∀ tbl idx, tbl ≠ coinTbl → tbl ≠ scratchTbl → wRead m₁ tbl idx = wRead m₀ tbl idx) →
    (∀ tbl idx, rRead m₁ tbl idx = rRead m₀ tbl idx) →
    (∃ (uInp : ArithRAMInput d) (rem : List Bool) (C S : ℕ),
      StepTo uInp (drawCoinsStmt coinTbl scratchTbl cp.B_STEP) m₀ m₁ rem [] C S) →
    EncState st m₁
  initStmt : ArithRAMStmt
  initCost : ℕ
  exec_init :
    ExecDet TW BW TR BR (mkInitInp cp.n d) initStmt ArithRAMMemory.empty
      (fun m =>
        EncState (ChainEngineState.empty cp) m ∧
        ArithRAMDynamicProgram.readCachedAnswer m = (none, 0))
      initCost
  engineDetStmt : ArithRAMStmt
  detCost : ℕ
  zeroRand_det : ZeroRandStmt engineDetStmt
  exec_det :
    ∀ (P : DynamicPointSet d) (op : DynamicUpdate d)
      (st : ChainEngineState cp) (bits : Fin cp.B_STEP → Bool) (m₁ : ArithRAMMemory),
      P.WellFormed cp.n →
      IsLegalUpdate cp.n Set.univ P op →
      ChainEngineWF cp P st →
      InFootprint TW BW TR BR m₁ →
      EncState st m₁ →
      (∀ j : Fin cp.B_STEP, wRead m₁ coinTbl (j.val : ℤ) = if bits j then 1 else 0) →
      let uop := toInternalUpdate P op
      let res := stepChainEngine cp st uop (bitsToStepCoinBundle cp bits)
      ExecDet TW BW TR BR (mkUpdateInp cp.n P uop) engineDetStmt m₁
        (fun m₂ =>
          EncState res.1 m₂ ∧
          (∀ h_new, res.2 = some h_new → ArithRAMDynamicProgram.readReturnedHandle m₂ = some h_new) ∧
          (let a := ArithRAMDynamicProgram.readCachedAnswer m₂
           ({ diameterHandles := a.1, cachedDistSq := a.2 } : StoredDiameterAnswer) = res.1.cachedAns))
        detCost

def StepChainRAMSpec.toProg {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ram : StepChainRAMSpec cp) : ArithRAMDynamicProgram :=
  { initStmt := ram.initStmt
    updateStmt := .seq (drawCoinsStmt ram.coinTbl ram.scratchTbl cp.B_STEP) ram.engineDetStmt }

def StepChainRAMSpec.stepTotalWork {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ram : StepChainRAMSpec cp) : ℕ :=
  max ram.initCost (5 + 10 * cp.B_STEP + ram.detCost)

def StepChainRAMSpec.totalSpace {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ram : StepChainRAMSpec cp) : ℕ :=
  3 + cp.n * (d + 1) + d + (ram.TW * ram.BW + ram.TR * ram.BR)

/-- Convenience constructor when `EncState (ChainEngineState.empty cp) ArithRAMMemory.empty` holds
directly (`initStmt = .skip`, `initCost = 1`). -/
def StepChainRAMSpec.ofEmptyInit {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    (TW BW TR BR coinTbl scratchTbl : ℕ)
    (h_coinTbl : coinTbl < TW) (h_scratchTbl : scratchTbl < TW)
    (h_ne_coin_scr : coinTbl ≠ scratchTbl)
    (h_coinBW : cp.B_STEP ≤ BW) (h_scrBW : 1 ≤ BW)
    (EncState : ChainEngineState cp → ArithRAMMemory → Prop)
    (henc_empty : EncState (ChainEngineState.empty cp) ArithRAMMemory.empty)
    (enc_frame_coins : ∀ (st : ChainEngineState cp) (m₀ m₁ : ArithRAMMemory),
      EncState st m₀ →
      (∀ tbl idx, tbl ≠ coinTbl → tbl ≠ scratchTbl → wRead m₁ tbl idx = wRead m₀ tbl idx) →
      (∀ tbl idx, rRead m₁ tbl idx = rRead m₀ tbl idx) →
      (∃ (uInp : ArithRAMInput d) (rem : List Bool) (C S : ℕ),
        StepTo uInp (drawCoinsStmt coinTbl scratchTbl cp.B_STEP) m₀ m₁ rem [] C S) →
      EncState st m₁)
    (engineDetStmt : ArithRAMStmt) (detCost : ℕ)
    (zeroRand_det : ZeroRandStmt engineDetStmt)
    (exec_det :
      ∀ (P : DynamicPointSet d) (op : DynamicUpdate d)
        (st : ChainEngineState cp) (bits : Fin cp.B_STEP → Bool) (m₁ : ArithRAMMemory),
        P.WellFormed cp.n →
        IsLegalUpdate cp.n Set.univ P op →
        ChainEngineWF cp P st →
        InFootprint TW BW TR BR m₁ →
        EncState st m₁ →
        (∀ j : Fin cp.B_STEP, wRead m₁ coinTbl (j.val : ℤ) = if bits j then 1 else 0) →
        let uop := toInternalUpdate P op
        let res := stepChainEngine cp st uop (bitsToStepCoinBundle cp bits)
        ExecDet TW BW TR BR (mkUpdateInp cp.n P uop) engineDetStmt m₁
          (fun m₂ =>
            EncState res.1 m₂ ∧
            (∀ h_new, res.2 = some h_new → ArithRAMDynamicProgram.readReturnedHandle m₂ = some h_new) ∧
            (let a := ArithRAMDynamicProgram.readCachedAnswer m₂
             ({ diameterHandles := a.1, cachedDistSq := a.2 } : StoredDiameterAnswer) = res.1.cachedAns))
          detCost) :
    StepChainRAMSpec cp :=
  { TW := TW, BW := BW, TR := TR, BR := BR
    coinTbl := coinTbl, scratchTbl := scratchTbl
    h_coinTbl := h_coinTbl, h_scratchTbl := h_scratchTbl
    h_ne_coin_scr := h_ne_coin_scr, h_coinBW := h_coinBW, h_scrBW := h_scrBW
    EncState := EncState, enc_frame_coins := enc_frame_coins
    initStmt := .skip, initCost := 1
    exec_init := ExecDet.skip (mkInitInp cp.n d) (InFootprint.empty TW BW TR BR)
      ⟨henc_empty, by
        simp [ArithRAMDynamicProgram.readCachedAnswer, ArithRAMMemory.empty,
          WordStore.empty, WordStore.read, RealStore.empty, RealStore.read]⟩ le_rfl
    engineDetStmt := engineDetStmt, detCost := detCost
    zeroRand_det := zeroRand_det, exec_det := exec_det }

structure ChainEngineProbSpec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (t : ℕ) (δ : ℝ) where
  GoodEngine : ChainEngineState cp → Prop
  GoodCoins : ChainEngineState cp → InternalUpdate d → StepCoinBundle cp → Prop
  good_empty : GoodEngine (ChainEngineState.empty cp)
  step_spec :
    ∀ {P : DynamicPointSet d} {op : DynamicUpdate d} {st : ChainEngineState cp}
      (coins : StepCoinBundle cp),
      P.WellFormed cp.n →
      IsLegalUpdate cp.n Set.univ P op →
      ChainEngineWF cp P st →
      let res := stepChainEngine cp st (toInternalUpdate P op) coins
      ∃ P' : DynamicPointSet d,
        applyDynamicUpdate P op res.2 = some P' ∧
        ChainEngineWF cp P' res.1 ∧
        (GoodEngine st →
         GoodCoins st (toInternalUpdate P op) coins →
         GoodEngine res.1 ∧ IsValidFactorCAnswer params.c P' res.1.cachedAns)
  good_coins_card_ge :
    ∀ {P : DynamicPointSet d} {op : DynamicUpdate d} {st : ChainEngineState cp},
      P.WellFormed cp.n →
      IsLegalUpdate cp.n Set.univ P op →
      ChainEngineWF cp P st →
      GoodEngine st →
      open Classical in
      (1 - δ / (t : ℝ)) * ((2 ^ cp.B_STEP : ℕ) : ℝ) ≤
        ((Finset.univ.filter (fun bits : Fin cp.B_STEP → Bool =>
          GoodCoins st (toInternalUpdate P op) (bitsToStepCoinBundle cp bits))).card : ℝ)

/-! ### 3. Fixed-Coin RAM Bridge Theorem (`StepChainRAMSpec` + `ChainEngineProbSpec` → `alg`) -/

private theorem stepChainEngine_snd_insert {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp)
    (pt : EuclideanSpace ℝ (Fin d)) (coins : StepCoinBundle cp) :
    ∃ h_ins : ℕ, (stepChainEngine cp st (.insert pt) coins).2 = some h_ins := by
  dsimp only [stepChainEngine, stepStage1, HandlePool.step]
  cases st.hp.freeList <;> exact ⟨_, rfl⟩

private theorem stepChainEngine_snd_delete {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp)
    (delH : ℕ) (coins : StepCoinBundle cp) :
    (stepChainEngine cp st (.delete delH) coins).2 = none := rfl

def retHandleOfUpdate {d : ℕ} (uop : InternalUpdate d) (mem : ArithRAMMemory) : Option ℕ :=
  match uop with
  | .insert _ => ArithRAMDynamicProgram.readReturnedHandle mem
  | .delete _ => none

private theorem stepWithBits_mkArithAlg_eq {d n : ℕ} (prog : ArithRAMDynamicProgram)
    (initOut : ArithRAMExecOutcome) (P : DynamicPointSet d)
    (mem : ArithRAMMemory) (uop : InternalUpdate d) (bs : List Bool)
    {outR : ArithRAMExecOutcome}
    (hrun : runArithRAMWithBits prog.updateStmt (mkUpdateInp n P uop) mem bs = some outR) :
    (mkArithAlg n prog initOut).stepWithBits P.activeHandles P.handleCoords mem uop bs =
      some
        { nextState := outR.mem
          returnedHandle := retHandleOfUpdate uop outR.mem
          storedAnswer :=
            let a := ArithRAMDynamicProgram.readCachedAnswer outR.mem
            { diameterHandles := a.1, cachedDistSq := a.2 }
          work := outR.unitCost
          peakSpace := outR.peakCellSpace } := by
  cases uop <;>
    { dsimp only [mkUpdateInp] at hrun
      simp [mkArithAlg, ArithRAMDynamicProgram.evalUpdate, retHandleOfUpdate, hrun] }

private theorem stepWithBits_mkArithAlg_none {d n : ℕ} (prog : ArithRAMDynamicProgram)
    (initOut : ArithRAMExecOutcome) (P : DynamicPointSet d)
    (mem : ArithRAMMemory) (uop : InternalUpdate d) (bs : List Bool)
    (hnone : runArithRAMWithBits prog.updateStmt (mkUpdateInp n P uop) mem bs = none) :
    (mkArithAlg n prog initOut).stepWithBits P.activeHandles P.handleCoords mem uop bs = none := by
  cases uop <;>
    { dsimp only [mkUpdateInp] at hnone
      simp [mkArithAlg, ArithRAMDynamicProgram.evalUpdate, hnone] }

private theorem retHandle_eq_stepChainEngine_snd {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp)
    (uop : InternalUpdate d) (coins : StepCoinBundle cp) (mem : ArithRAMMemory)
    (hret : ∀ h_new, (stepChainEngine cp st uop coins).2 = some h_new →
      ArithRAMDynamicProgram.readReturnedHandle mem = some h_new) :
    retHandleOfUpdate uop mem = (stepChainEngine cp st uop coins).2 := by
  cases uop with
  | insert pt =>
      dsimp only [retHandleOfUpdate]
      obtain ⟨h_ins, hsome⟩ := stepChainEngine_snd_insert cp st pt coins
      rw [hsome, hret h_ins hsome]
  | delete _ =>
      rfl

open Classical in
theorem stepChainRAM_bridge {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h)
    {n t : ℕ} {δ c stepWorkBound spaceBound : ℝ}
    (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
    (hc_eq : params.c = c) (hn_eq : cp.n = n)
    (prob : ChainEngineProbSpec cp t δ)
    (ram : StepChainRAMSpec cp)
    (hWork : (ram.stepTotalWork : ℝ) ≤ stepWorkBound)
    (hSpace : (ram.totalSpace : ℝ) ≤ spaceBound) :
    ∃ initOut : ArithRAMExecOutcome,
      ram.toProg.evalInit n d = some initOut ∧
      let alg := mkArithAlg (d := d) n ram.toProg initOut
      SatisfiesDynamicStorageAndQueryModel 4 1 alg ∧
      SatisfiesMonteCarloGuarantee n t δ c Set.univ alg ∧
      SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg stepWorkBound ∧
      SatisfiesBoundedSpaceBound n t Set.univ alg spaceBound := by
  subst hn_eq
  subst hc_eq
  -- 1. Evaluate `initStmt` from empty memory
  obtain ⟨mInit, ⟨henc_init, hans_init⟩, hfp_init, hst_init⟩ := ram.exec_init
  obtain ⟨initOut, hrun_init, hmem_init, hcost_init, hsp_init⟩ :=
    StepTo.to_runArithRAMWithBits cleanMem_empty (Nat.zero_le _) hst_init
  have heval_init : ram.toProg.evalInit cp.n d = some initOut := hrun_init
  have hans_init' : ArithRAMDynamicProgram.readCachedAnswer initOut.mem = (none, 0) := by
    rwa [hmem_init]
  let alg := mkArithAlg (d := d) cp.n ram.toProg initOut
  refine ⟨initOut, heval_init, storageModel_of_readCached_none cp.n ram.toProg initOut hans_init', ?_⟩

  -- 2. Core single-step execution lemma parameterized by any witness `st` encoding `mem`
  have hExecWitness : ∀ (P : DynamicPointSet d) (mem : ArithRAMMemory) (op : DynamicUpdate d)
      (st : ChainEngineState cp) (bits : Fin cp.B_STEP → Bool),
      P.WellFormed cp.n →
      InFootprint ram.TW ram.BW ram.TR ram.BR mem →
      ChainEngineWF cp P st →
      ram.EncState st mem →
      IsLegalUpdate cp.n Set.univ P op →
      let uop := toInternalUpdate P op
      let coins := bitsToStepCoinBundle cp bits
      let res := stepChainEngine cp st uop coins
      ∃ (P' : DynamicPointSet d) (outStep : DynamicStepOutcome ArithRAMMemory),
        runSingleAdaptiveStep alg P mem op (List.ofFn bits) = some (P', outStep) ∧
        applyDynamicUpdate P op res.2 = some P' ∧
        InFootprint ram.TW ram.BW ram.TR ram.BR outStep.nextState ∧
        ChainEngineWF cp P' res.1 ∧
        ram.EncState res.1 outStep.nextState ∧
        outStep.storedAnswer = (let a := ArithRAMDynamicProgram.readCachedAnswer outStep.nextState; { diameterHandles := a.1, cachedDistSq := a.2 }) ∧
        (outStep.work : ℝ) ≤ stepWorkBound ∧
        (outStep.peakSpace : ℝ) ≤ spaceBound ∧
        (prob.GoodEngine st → prob.GoodCoins st uop coins →
          prob.GoodEngine res.1 ∧ IsValidFactorCAnswer params.c P' outStep.storedAnswer) := by
    intro P mem op st bits hP hfp hwf henc hleg
    let uop := toInternalUpdate P op
    let coins := bitsToStepCoinBundle cp bits
    let res := stepChainEngine cp st uop coins
    let inp := mkUpdateInp cp.n P uop
    obtain ⟨m₁, hbits_m₁, hw_pres, hr_pres, hfp_draw⟩ :=
      StepFP.drawCoins inp ram.coinTbl ram.scratchTbl cp.B_STEP bits hfp
        ram.h_coinTbl ram.h_scratchTbl ram.h_ne_coin_scr ram.h_coinBW ram.h_scrBW
    have henc₁ : ram.EncState st m₁ := ram.enc_frame_coins st mem m₁ henc hw_pres hr_pres ⟨inp, List.ofFn bits, _, _, hfp_draw.2⟩
    obtain ⟨m₂, ⟨henc₂, hret₂, hans₂⟩, hfp_det⟩ :=
      ram.exec_det P op st bits m₁ hP hleg hwf hfp_draw.1 henc₁ hbits_m₁
    have hfp_seq : StepFP ram.TW ram.BW ram.TR ram.BR inp ram.toProg.updateStmt
        mem m₂ (List.ofFn bits) [] (4 + (1 + cp.B_STEP * 10) + ram.detCost) :=
      hfp_draw.seq hfp_det
    obtain ⟨outR, hrunR, hmemR, hcostR, hspR⟩ :=
      StepTo.to_runArithRAMWithBits hfp.1 hfp.cellCount_le hfp_seq.2
    obtain ⟨P', happ, hwf', hgd_imp⟩ := prob.step_spec coins hP hleg hwf
    let ansOut := ArithRAMDynamicProgram.readCachedAnswer outR.mem
    let storedOut : StoredDiameterAnswer := { diameterHandles := ansOut.1, cachedDistSq := ansOut.2 }
    have hstored_eq : storedOut = res.1.cachedAns := by
      dsimp only [storedOut, ansOut]
      rw [hmemR]
      exact hans₂
    have hcost_le : (outR.unitCost : ℝ) ≤ stepWorkBound := by
      have h1 : outR.unitCost ≤ ram.stepTotalWork := by
        unfold StepChainRAMSpec.stepTotalWork
        have : outR.unitCost ≤ 5 + 10 * cp.B_STEP + ram.detCost := by omega
        exact this.trans (Nat.le_max_right _ _)
      exact (Nat.cast_le.mpr h1).trans hWork
    have hsp_le : (outR.peakCellSpace : ℝ) ≤ spaceBound := by
      have hinp_sp : inp.inputCellSpace ≤ 3 + cp.n * (d + 1) + d := mkUpdateInp_cellSpace_le hP uop
      have h1 : outR.peakCellSpace ≤ ram.totalSpace :=
        hspR.trans (Nat.add_le_add_right hinp_sp (ram.TW * ram.BW + ram.TR * ram.BR))
      exact (Nat.cast_le.mpr h1).trans hSpace
    let retH : Option ℕ := retHandleOfUpdate (toInternalUpdate P op) outR.mem
    let outStep : DynamicStepOutcome ArithRAMMemory :=
      { nextState := outR.mem
        returnedHandle := retH
        storedAnswer := storedOut
        work := outR.unitCost
        peakSpace := outR.peakCellSpace }
    have hretH_eq : retH = res.2 := by
      refine retHandle_eq_stepChainEngine_snd cp st (toInternalUpdate P op) coins outR.mem ?_
      intro h_new hh
      rw [hmemR]
      exact hret₂ h_new hh
    have hstep_wb : alg.stepWithBits P.activeHandles P.handleCoords mem
        (toInternalUpdate P op) (List.ofFn bits) = some outStep :=
      stepWithBits_mkArithAlg_eq ram.toProg initOut P mem (toInternalUpdate P op) (List.ofFn bits) hrunR
    have hrun_step : runSingleAdaptiveStep alg P mem op (List.ofFn bits) = some (P', outStep) := by
      unfold runSingleAdaptiveStep
      rw [hstep_wb]
      dsimp only [outStep]
      rw [hretH_eq, happ]
    refine ⟨P', outStep, hrun_step, happ, ?_, hwf', ?_, rfl, hcost_le, hsp_le, ?_⟩
    · dsimp only [outStep]; rw [hmemR]; exact hfp_det.1
    · dsimp only [outStep]; rw [hmemR]; exact henc₂
    · intro hgd0 hgc
      obtain ⟨hgd1, hval⟩ := hgd_imp hgd0 hgc
      refine ⟨hgd1, ?_⟩
      dsimp only [outStep]
      rwa [hstored_eq]

  -- 3. Instantiate `fixedCoinBridge` with `ReachInv` and `GoodInv`
  let ReachInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop := fun _ P mem =>
    InFootprint ram.TW ram.BW ram.TR ram.BR mem ∧
    ∃ st : ChainEngineState cp, ChainEngineWF cp P st ∧ ram.EncState st mem
  let GoodInv : ℕ → DynamicPointSet d → ArithRAMMemory → Prop := fun _ P mem =>
    IsValidFactorCAnswer params.c P
      (let a := ArithRAMDynamicProgram.readCachedAnswer mem
       { diameterHandles := a.1, cachedDistSq := a.2 }) ∧
    ∃ st : ChainEngineState cp,
      ChainEngineWF cp P st ∧ ram.EncState st mem ∧ prob.GoodEngine st

  have hInitWork : (alg.initWork : ℝ) ≤ stepWorkBound := by
    dsimp only [alg, mkArithAlg]
    have h1 : initOut.unitCost ≤ ram.stepTotalWork :=
      hcost_init.trans (Nat.le_max_left _ _)
    exact (Nat.cast_le.mpr h1).trans hWork

  have hInitSpace : (alg.initSpace : ℝ) ≤ spaceBound := by
    dsimp only [alg, mkArithAlg]
    have h1 : initOut.peakCellSpace ≤ ram.totalSpace := by
      rw [mkInitInp_cellSpace] at hsp_init
      unfold StepChainRAMSpec.totalSpace
      omega
    exact (Nat.cast_le.mpr h1).trans hSpace

  have hInitReach : ReachInv 0 (DynamicPointSet.empty d) alg.initState := by
    dsimp only [ReachInv, alg, mkArithAlg]
    rw [hmem_init]
    exact ⟨hfp_init, ChainEngineState.empty cp, empty_chainEngineWF cp, henc_init⟩

  have hInitGood : GoodInv 0 (DynamicPointSet.empty d) alg.initState := by
    dsimp only [GoodInv, alg, mkArithAlg]
    refine ⟨?_, ?_⟩
    · rw [hans_init']
      exact validFactorCAnswer_empty d cp.n params.c
    · rw [hmem_init]
      exact ⟨ChainEngineState.empty cp, empty_chainEngineWF cp, henc_init, prob.good_empty⟩

  refine fixedCoinBridge cp.hn ht hδ0 hδ1 cp.B_STEP alg ReachInv GoodInv
    hInitWork hInitSpace hInitReach hInitGood ?_ ?_ ?_
  · -- `hStepNone`: `bs.length ≠ cp.B_STEP`
    intro _ P mem op bs _ hP ⟨hfp, st, hwf, henc⟩ hleg hlen
    let uop := toInternalUpdate P op
    let inp := mkUpdateInp cp.n P uop
    have hSomeAll : ∀ bits : Fin cp.B_STEP → Bool,
        (runArithRAMWithBits ram.toProg.updateStmt inp mem (List.ofFn bits)).isSome := by
      intro bits
      obtain ⟨m₁, hbits_m₁, hw_pres, hr_pres, hfp_draw⟩ :=
        StepFP.drawCoins inp ram.coinTbl ram.scratchTbl cp.B_STEP bits hfp
          ram.h_coinTbl ram.h_scratchTbl ram.h_ne_coin_scr ram.h_coinBW ram.h_scrBW
      have henc₁ := ram.enc_frame_coins st mem m₁ henc hw_pres hr_pres ⟨inp, List.ofFn bits, _, _, hfp_draw.2⟩
      obtain ⟨m₂, _, hfp_det⟩ := ram.exec_det P op st bits m₁ hP hleg hwf hfp_draw.1 henc₁ hbits_m₁
      obtain ⟨outR, hrunR, _⟩ :=
        StepTo.to_runArithRAMWithBits hfp.1 hfp.cellCount_le (hfp_draw.seq hfp_det).2
      exact Option.isSome_iff_exists.mpr ⟨outR, hrunR⟩
    have hnone : runArithRAMWithBits ram.toProg.updateStmt
        (mkUpdateInp cp.n P (toInternalUpdate P op)) mem bs = none :=
      drawCoins_seq_none_of_len_ne ram.coinTbl ram.scratchTbl cp.B_STEP
        ram.engineDetStmt mem hSomeAll hlen
    unfold runSingleAdaptiveStep
    rw [stepWithBits_mkArithAlg_none ram.toProg initOut P mem (toInternalUpdate P op) bs hnone]
  · -- `hStepSome`
    intro _ P mem op bits _ hP ⟨hfp, st, hwf, henc⟩ hleg
    obtain ⟨P', outStep, hsome, _, hfp', hwf', henc', hstored_ans, hw, hsp, _⟩ :=
      hExecWitness P mem op st bits hP hfp hwf henc hleg
    refine ⟨P', outStep, hsome, ⟨hfp', _, hwf', henc'⟩, hw, hsp, fun hG => ?_⟩
    rw [hstored_ans]
    exact hG.1
  · -- `hBadFrac`
    intro s P mem op _ hP ⟨hfp, _⟩ ⟨_, st₀, hwf₀, henc₀, hgd₀⟩ hleg
    let uop := toInternalUpdate P op
    let GoodPred : (Fin cp.B_STEP → Bool) → Prop := fun bits =>
      prob.GoodCoins st₀ uop (bitsToStepCoinBundle cp bits)
    have hpart_nat :
        (Finset.univ.filter GoodPred).card +
        (Finset.univ.filter (fun bits => ¬ GoodPred bits)).card = 2 ^ cp.B_STEP := by
      rw [Finset.card_filter_add_card_filter_not, Finset.card_univ,
        Fintype.card_fun, Fintype.card_fin, Fintype.card_bool]
    have hpart_r :
        ((Finset.univ.filter GoodPred).card : ℝ) +
        ((Finset.univ.filter (fun bits => ¬ GoodPred bits)).card : ℝ) =
        ((2 ^ cp.B_STEP : ℕ) : ℝ) := by
      exact_mod_cast hpart_nat
    have hgood_lb := prob.good_coins_card_ge (op := op) hP hleg hwf₀ hgd₀
    change (1 - δ / (t : ℝ)) * ((2 ^ cp.B_STEP : ℕ) : ℝ) ≤
      ((Finset.univ.filter GoodPred).card : ℝ) at hgood_lb
    have hnot_ub : ((Finset.univ.filter (fun bits => ¬ GoodPred bits)).card : ℝ) ≤
        (δ / (t : ℝ)) * ((2 ^ cp.B_STEP : ℕ) : ℝ) := by
      linarith
    refine (Nat.cast_le.mpr (Finset.card_le_card ?_)).trans hnot_ub
    intro bits hmem
    have hbad := (Finset.mem_filter.mp hmem).2
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ bits, fun hgood => ?_⟩
    obtain ⟨P', outStep, hsome, _, _, hwf', henc', hstored_ans, _, _, hgd_imp⟩ :=
      hExecWitness P mem op st₀ bits hP hfp hwf₀ henc₀ hleg
    obtain ⟨hgd', hval'⟩ := hgd_imp hgd₀ hgood
    rw [hstored_ans] at hval'
    rw [hsome] at hbad
    exact hbad ⟨hval', _, hwf', henc', hgd'⟩

/-! ### 4. Regime Dispatch (`d = 0`, `min n t ≤ M_cut`, Sublinear Chain) & Full `S_clm_9_1` -/

structure SublinearCurveSpec (c σ : ℝ) where
  M_cut : ℕ → ℕ → ℕ
  polyM : IsBoundedByPoly2 (fun d L => (M_cut d L : ℝ))
  polySubTime : ℕ → ℕ → ℝ
  polySubSpace : ℕ → ℕ → ℝ
  hPolySubTime : IsBoundedByPoly2 polySubTime
  hPolySubSpace : IsBoundedByPoly2 polySubSpace
  mkEngine :
    ∀ (d n t : ℕ) (δ : ℝ),
      1 ≤ d → 2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
      let logTerm : ℕ := Nat.ceil (Real.log (2 * (n : ℝ) * (t : ℝ) / δ))
      M_cut d logTerm < n →
      M_cut d logTerm < t →
      ∃ (params : LocalScaleParams) (h : ℝ) (cp : ChainParams d params h)
        (_prob : ChainEngineProbSpec cp t δ)
        (ram : StepChainRAMSpec cp),
        params.c = c ∧
        cp.n = n ∧
        (ram.stepTotalWork : ℝ) ≤ ((n : ℝ) ^ (Q_c c σ)) * polySubTime d logTerm ∧
        (ram.totalSpace : ℝ) ≤ ((n : ℝ) ^ (1 + σ)) * polySubSpace d logTerm

theorem isBoundedByPoly2_dim : IsBoundedByPoly2 (fun d _ => (d : ℝ)) := by
  refine ⟨1, 1, by norm_num, fun d L => ?_⟩
  simp only [pow_one, one_mul]
  have hle : d ≤ (d + 1) * (L + 1) := by nlinarith
  exact_mod_cast hle

theorem prove_conjunct_4_from_sublinear {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2)
    (hSub : ∀ (σ : ℝ), 0 ≤ σ → σ ≤ rho_c c → Nonempty (SublinearCurveSpec c σ)) :
    ∀ (σ : ℝ), 0 ≤ σ → σ ≤ rho_c c →
      ∃ (polyTime polySpace : ℕ → ℕ → ℝ) (queryConst writeFactor : ℕ),
        IsBoundedByPoly2 polyTime ∧
        IsBoundedByPoly2 polySpace ∧
        ∀ (d n t : ℕ) (δ : ℝ),
          2 ≤ n → 1 ≤ t → 0 < δ → δ < 1 / 2 →
            ∃ (prog : ArithRAMDynamicProgram) (initOut : ArithRAMExecOutcome),
              prog.evalInit n d = some initOut ∧
              let logTerm : ℕ := Nat.ceil (Real.log (2 * (n : ℝ) * (t : ℝ) / δ))
              let alg : DynamicDiameterStructure d ArithRAMMemory := mkArithAlg n prog initOut
              SatisfiesDynamicStorageAndQueryModel queryConst writeFactor alg ∧
              SatisfiesMonteCarloGuarantee n t δ c Set.univ alg ∧
              SatisfiesBoundedWorstCaseUpdateWorkBound n t Set.univ alg
                (((n : ℝ) ^ (Q_c c σ)) * polyTime d logTerm) ∧
              SatisfiesBoundedSpaceBound n t Set.univ alg
                (((n : ℝ) ^ (1 + σ)) * polySpace d logTerm) := by
  intro σ hσ0 hσ_hi
  obtain ⟨spec⟩ := hSub σ hσ0 hσ_hi
  let exactTime : ℕ → ℕ → ℝ := fun d L =>
    400 + 25 * (d : ℝ) +
      (spec.M_cut d L : ℝ) * (100 + (spec.M_cut d L : ℝ) * (200 + 80 * (d : ℝ)))
  let baseSpace : ℕ → ℕ → ℝ := fun d _ => 5 * (d : ℝ) + 120
  let polyTime : ℕ → ℕ → ℝ := fun d L =>
    300 + exactTime d L + max 0 (spec.polySubTime d L)
  let polySpace : ℕ → ℕ → ℝ := fun d L =>
    baseSpace d L + max 0 (spec.polySubSpace d L)

  have hPoly25d : IsBoundedByPoly2 (fun d L => 25 * (d : ℝ)) :=
    isBoundedByPoly2_mul (isBoundedByPoly2_const (by norm_num)) (fun _ _ => by norm_num)
      isBoundedByPoly2_dim (fun _ _ => Nat.cast_nonneg _)
  have hPoly80d : IsBoundedByPoly2 (fun d L => 80 * (d : ℝ)) :=
    isBoundedByPoly2_mul (isBoundedByPoly2_const (by norm_num)) (fun _ _ => by norm_num)
      isBoundedByPoly2_dim (fun _ _ => Nat.cast_nonneg _)
  have hPolyInner2 : IsBoundedByPoly2 (fun d L => 200 + 80 * (d : ℝ)) :=
    isBoundedByPoly2_add (isBoundedByPoly2_const (by norm_num)) hPoly80d
  have hPolyMid : IsBoundedByPoly2 (fun d L => (spec.M_cut d L : ℝ) * (200 + 80 * (d : ℝ))) :=
    isBoundedByPoly2_mul spec.polyM (fun _ _ => Nat.cast_nonneg _)
      hPolyInner2 (fun _ _ => by positivity)
  have hPolyInner1 : IsBoundedByPoly2 (fun d L =>
      100 + (spec.M_cut d L : ℝ) * (200 + 80 * (d : ℝ))) :=
    isBoundedByPoly2_add (isBoundedByPoly2_const (by norm_num)) hPolyMid
  have hPolyOuter : IsBoundedByPoly2 (fun d L =>
      (spec.M_cut d L : ℝ) * (100 + (spec.M_cut d L : ℝ) * (200 + 80 * (d : ℝ)))) :=
    isBoundedByPoly2_mul spec.polyM (fun _ _ => Nat.cast_nonneg _)
      hPolyInner1 (fun _ _ => by positivity)
  have hPolyExact : IsBoundedByPoly2 exactTime :=
    isBoundedByPoly2_add
      (isBoundedByPoly2_add (isBoundedByPoly2_const (by norm_num)) hPoly25d)
      hPolyOuter
  have hPolyTime : IsBoundedByPoly2 polyTime :=
    isBoundedByPoly2_add
      (isBoundedByPoly2_add (isBoundedByPoly2_const (by norm_num)) hPolyExact)
      (isBoundedByPoly2_max_zero spec.hPolySubTime)
  have hPoly5d : IsBoundedByPoly2 (fun d L => 5 * (d : ℝ)) :=
    isBoundedByPoly2_mul (isBoundedByPoly2_const (by norm_num)) (fun _ _ => by norm_num)
      isBoundedByPoly2_dim (fun _ _ => Nat.cast_nonneg _)
  have hPolyBaseSp : IsBoundedByPoly2 baseSpace :=
    isBoundedByPoly2_add hPoly5d (isBoundedByPoly2_const (by norm_num))
  have hPolySpace : IsBoundedByPoly2 polySpace :=
    isBoundedByPoly2_add hPolyBaseSp (isBoundedByPoly2_max_zero spec.hPolySubSpace)

  refine ⟨polyTime, polySpace, 4, 1, hPolyTime, hPolySpace, ?_⟩
  intro d n t δ hn ht hδ0 hδ1
  let logTerm : ℕ := Nat.ceil (Real.log (2 * (n : ℝ) * (t : ℝ) / δ))
  have hrho0 : 0 < rho_c c := (rho_c_bounds hc_gt hc_lt).1
  have hQ_nn : 0 ≤ Q_c c σ := hrho0.le.trans (rho_c_le_Q_c hc_gt hc_lt hσ0 hσ_hi)
  have hn1 : (1 : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : 1 ≤ n)
  have hn2 : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
  have hrpow_Q_ge1 : (1 : ℝ) ≤ (n : ℝ) ^ (Q_c c σ) := Real.one_le_rpow hn1 hQ_nn
  have hrpow_sig_ge_n : (n : ℝ) ≤ (n : ℝ) ^ (1 + σ) := by
    calc (n : ℝ) = (n : ℝ) ^ (1 : ℝ) := (Real.rpow_one (n : ℝ)).symm
      _ ≤ (n : ℝ) ^ (1 + σ) := Real.rpow_le_rpow_of_exponent_le hn1 (by linarith)
  have hexact_nn : 0 ≤ exactTime d logTerm := by dsimp [exactTime]; positivity
  have hmaxT_nn : 0 ≤ max 0 (spec.polySubTime d logTerm) := le_max_left 0 _
  have hmaxS_nn : 0 ≤ max 0 (spec.polySubSpace d logTerm) := le_max_left 0 _

  by_cases hd0 : d = 0
  · subst hd0
    have hW : (300 : ℝ) ≤ ((n : ℝ) ^ (Q_c c σ)) * polyTime 0 logTerm := by
      have hpT_ge : (300 : ℝ) ≤ polyTime 0 logTerm := by
        dsimp [polyTime]; linarith
      calc (300 : ℝ) = 1 * 300 := (one_mul _).symm
        _ ≤ ((n : ℝ) ^ (Q_c c σ)) * polyTime 0 logTerm :=
            mul_le_mul hrpow_Q_ge1 hpT_ge (by norm_num) (by positivity)
    have hS : ((10 * n + 64 : ℕ) : ℝ) ≤ ((n : ℝ) ^ (1 + σ)) * polySpace 0 logTerm := by
      have hlin : ((10 * n + 64 : ℕ) : ℝ) ≤ (n : ℝ) * 120 := by
        push_cast; linarith
      have hpS_ge : (120 : ℝ) ≤ polySpace 0 logTerm := by
        dsimp [polySpace, baseSpace]; linarith
      calc ((10 * n + 64 : ℕ) : ℝ) ≤ (n : ℝ) * 120 := hlin
        _ ≤ ((n : ℝ) ^ (1 + σ)) * polySpace 0 logTerm :=
            mul_le_mul hrpow_sig_ge_n hpS_ge (by norm_num) (by positivity)
    obtain ⟨initOut, hev, hsm, hmc, hwb, hsb⟩ := branchD0_theorem hc_gt hn ht hδ0 hδ1 hW hS
    exact ⟨{ initStmt := .skip, updateStmt := updateD0Stmt }, initOut, hev, hsm, hmc, hwb, hsb⟩
  · have hd1 : 1 ≤ d := Nat.pos_of_ne_zero hd0
    by_cases hBig : spec.M_cut d logTerm < n ∧ spec.M_cut d logTerm < t
    · obtain ⟨params, h, cp, prob, ram, hc_eq, hn_eq, hSubW, hSubS⟩ :=
        spec.mkEngine d n t δ hd1 hn ht hδ0 hδ1 hBig.1 hBig.2
      have hW : (ram.stepTotalWork : ℝ) ≤ ((n : ℝ) ^ (Q_c c σ)) * polyTime d logTerm := by
        have hpT_ge : spec.polySubTime d logTerm ≤ polyTime d logTerm := by
          have := le_max_right 0 (spec.polySubTime d logTerm)
          dsimp [polyTime]
          linarith
        exact hSubW.trans (mul_le_mul_of_nonneg_left hpT_ge (by positivity))
      have hS : (ram.totalSpace : ℝ) ≤ ((n : ℝ) ^ (1 + σ)) * polySpace d logTerm := by
        have hpS_ge : spec.polySubSpace d logTerm ≤ polySpace d logTerm := by
          have := le_max_right 0 (spec.polySubSpace d logTerm)
          dsimp [polySpace, baseSpace]
          linarith
        exact hSubS.trans (mul_le_mul_of_nonneg_left hpS_ge (by positivity))
      obtain ⟨initOut, hev, hsm, hmc, hwb, hsb⟩ :=
        stepChainRAM_bridge cp ht hδ0 hδ1 hc_eq hn_eq prob ram hW hS
      exact ⟨ram.toProg, initOut, hev, hsm, hmc, hwb, hsb⟩
    · have hCap : min n t ≤ spec.M_cut d logTerm := by
        by_cases hn_lt : spec.M_cut d logTerm < n
        · have ht_le : t ≤ spec.M_cut d logTerm := Nat.not_lt.mp fun ht_lt => hBig ⟨hn_lt, ht_lt⟩
          exact (Nat.min_le_right n t).trans ht_le
        · exact (Nat.min_le_left n t).trans (Nat.not_lt.mp hn_lt)
      let M := spec.M_cut d logTerm
      have hW : ((400 + 25 * d + M * (100 + M * (200 + 80 * d)) : ℕ) : ℝ) ≤
          ((n : ℝ) ^ (Q_c c σ)) * polyTime d logTerm := by
        have hcast : ((400 + 25 * d + M * (100 + M * (200 + 80 * d)) : ℕ) : ℝ) =
            exactTime d logTerm := by
          dsimp [exactTime, M]; push_cast; ring
        rw [hcast]
        have hpT_ge : exactTime d logTerm ≤ polyTime d logTerm := by
          dsimp [polyTime]; linarith
        calc exactTime d logTerm = 1 * exactTime d logTerm := (one_mul _).symm
          _ ≤ ((n : ℝ) ^ (Q_c c σ)) * polyTime d logTerm :=
              mul_le_mul hrpow_Q_ge1 hpT_ge hexact_nn (by positivity)
      have hS : ((8 * (n + 8) + 4 * (n * d + 8) + (d + 4) : ℕ) : ℝ) ≤
          ((n : ℝ) ^ (1 + σ)) * polySpace d logTerm := by
        have hlin : ((8 * (n + 8) + 4 * (n * d + 8) + (d + 4) : ℕ) : ℝ) ≤
            (n : ℝ) * (5 * (d : ℝ) + 120) := by
          push_cast
          nlinarith
        have hpS_ge : 5 * (d : ℝ) + 120 ≤ polySpace d logTerm := by
          dsimp [polySpace, baseSpace]; linarith
        calc ((8 * (n + 8) + 4 * (n * d + 8) + (d + 4) : ℕ) : ℝ)
            ≤ (n : ℝ) * (5 * (d : ℝ) + 120) := hlin
          _ ≤ ((n : ℝ) ^ (1 + σ)) * polySpace d logTerm :=
              mul_le_mul hrpow_sig_ge_n hpS_ge (by positivity) (by positivity)
      obtain ⟨initOut, hev, hsm, hmc, hwb, hsb⟩ :=
        branchExact_theorem hc_gt hn ht hδ0 hδ1 hCap hW hS
      exact ⟨{ initStmt := .skip, updateStmt := updateExactStmt M d },
        initOut, hev, hsm, hmc, hwb, hsb⟩

theorem prove_clm_9_1_from_sublinear
    (h_lem_6_2 : S_lem_6_2)
    (h_clm_6_1_adaptive : S_clm_6_1_adaptive)
    (h_clm_6_1_precision : S_clm_6_1_precision)
    (hSub : ∀ (c : ℝ), 1 < c → c < Real.sqrt 2 →
      ∀ (σ : ℝ), 0 ≤ σ → σ ≤ rho_c c → Nonempty (SublinearCurveSpec c σ)) :
    S_clm_9_1_explicit_tradeoff := by
  intro c hc_gt hc_lt
  exact ⟨prove_conjunct_1 h_lem_6_2 hc_gt hc_lt,
    prove_conjunct_2 h_clm_6_1_adaptive h_clm_6_1_precision hc_gt hc_lt,
    prove_conjunct_3 hc_gt hc_lt,
    prove_conjunct_4_from_sublinear hc_gt hc_lt (hSub c hc_gt hc_lt),
    prove_conjunct_5 hc_gt hc_lt⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge
