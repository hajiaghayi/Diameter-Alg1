import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3c2a_SlotInit
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)

/-! ### 1. `O(1)` DLL Push (`liveSlotPushNodeStmt`) -/

def liveSlotPushNodeStmt (scrW tblW : ℕ)
    (wBaseW wBkt wNd wEid wScr : ℤ) (R ℓ M₀ : ℕ) : ArithRAMStmt :=
  let N_bktZ : ℤ := ((R * M₀ ^ ℓ : ℕ) : ℤ)
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  let bktE := IntExpr.readHeap scrW (.lit wBkt)
  let ndE := IntExpr.readHeap scrW (.lit wNd)
  let eidE := IntExpr.readHeap scrW (.lit wEid)
  let wEp := wScr
  let wOldH := wScr + 1
  let wOffN := wScr + 2
  let offHE := IntExpr.add (.add bW (.lit 4)) (.mul (.lit 2) bktE)
  let offNE := IntExpr.add (.add bW (.lit (4 + 2 * N_bktZ))) (.mul (.lit 5) ndE)
  .seq (.writeWordHeap scrW (.lit wEp) (.readHeap tblW bW))
  (.seq (.ite (.intEq (.readHeap tblW offHE) (.readHeap scrW (.lit wEp)))
          (.writeWordHeap scrW (.lit wOldH) (.readHeap tblW (.add offHE (.lit 1))))
          (.writeWordHeap scrW (.lit wOldH) (.lit (-1))))
  (.seq (.writeWordHeap scrW (.lit wOffN) offNE)
  (.seq (.writeWordHeap tblW offHE (.readHeap scrW (.lit wEp)))
  (.seq (.writeWordHeap tblW (.add offHE (.lit 1)) ndE)
  (.seq (.writeWordHeap tblW (.readHeap scrW (.lit wOffN)) (.readHeap scrW (.lit wEp)))
  (.seq (.writeWordHeap tblW (.add (.readHeap scrW (.lit wOffN)) (.lit 1)) bktE)
  (.seq (.writeWordHeap tblW (.add (.readHeap scrW (.lit wOffN)) (.lit 2)) eidE)
  (.seq (.writeWordHeap tblW (.add (.readHeap scrW (.lit wOffN)) (.lit 3)) (.lit (-1)))
  (.seq (.writeWordHeap tblW (.add (.readHeap scrW (.lit wOffN)) (.lit 4)) (.readHeap scrW (.lit wOldH)))
        (.ite (.intLt (.readHeap scrW (.lit wOldH)) (.lit 0))
          .skip
          (.writeWordHeap tblW
            (.add (.add (.add bW (.lit (4 + 2 * N_bktZ)))
                        (.mul (.lit 5) (.readHeap scrW (.lit wOldH))))
                  (.lit 3))
            ndE)))))))))))

theorem exec_liveSlotPushNodeStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBkt wNd wEid wScr baseW baseR : ℤ)
    {R ℓ M₀ cap_u B_max bkt nd eid : ℕ}
    (hbkt : bkt < R * M₀ ^ ℓ)
    (hnd : nd < B_max * (R * cap_u))
    (S : LiveSlot R ℓ M₀ d)
    (holdH_pool : 0 ≤ S.effHead bkt → (S.effHead bkt).toNat < B_max * (R * cap_u) ∧ (S.effHead bkt).toNat ≠ nd)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htblW : tblW < TW) (hneW : tblW ≠ scrW)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 3 ≤ (BW : ℤ))
    (hdisjBW : wBaseW < wScr ∨ wScr + 3 ≤ wBaseW)
    (hdisjBkt : wBkt < wScr ∨ wScr + 3 ≤ wBkt)
    (hdisjNd : wNd < wScr ∨ wScr + 3 ≤ wNd)
    (hdisjEid : wEid < wScr ∨ wScr + 3 ≤ wEid)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hbkt_r : H3a.wRead m₀ scrW wBkt = (bkt : ℤ))
    (hnd_r : H3a.wRead m₀ scrW wNd = (nd : ℤ))
    (heid_r : H3a.wRead m₀ scrW wEid = (eid : ℤ))
    (henc : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (liveSlotPushNodeStmt scrW tblW wBaseW wBkt wNd wEid wScr R ℓ M₀) m₀ m₁ 350 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (S.pushNode bkt nd eid) m₁ ∧
      (∀ w, (w < wScr ∨ wScr + 3 ≤ w) → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m₁ := by
  have ⟨hep, hblk, hbc, hcaps, hbkt_all, hnd_all⟩ := henc
  rcases hbkt_all bkt hbkt with ⟨hhEp_b, hhVal_b⟩
  have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hbkt
  have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hnd
  have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
  let oldH := S.effHead bkt
  let offH := slotBktOff baseW bkt
  let offN := slotNodeOff R ℓ M₀ baseW nd
  change baseW + 4 ≤ offH ∧ offH + 1 < baseW + slotWStride R ℓ M₀ cap_u B_max at hbb
  change baseW + 4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) ≤ offN ∧ offN + 4 < baseW + slotWStride R ℓ M₀ cap_u B_max at hnb
  let m1 := H3a.wWrite m₀ scrW wScr (S.ep : ℤ)
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.readHeap tblW (.readHeap scrW (.lit wBaseW))))
      m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wScr) _ rfl
      (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wBaseW) = _; rw [hbW, hep])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW hwScr.1 (by omega)
  let m2 := H3a.wWrite m1 scrW (wScr + 1) oldH
  have hd2 : DetExec inp
      (.ite (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4))
                                          (.mul (.lit 2) (.readHeap scrW (.lit wBkt)))))
                    (.readHeap scrW (.lit wScr)))
            (.writeWordHeap scrW (.lit (wScr + 1))
              (.readHeap tblW (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4))
                                          (.mul (.lit 2) (.readHeap scrW (.lit wBkt)))) (.lit 1))))
            (.writeWordHeap scrW (.lit (wScr + 1)) (.lit (-1))))
      m1 m2 45 := by
    have hbW1 : H3a.wRead m1 scrW wBaseW = baseW := by
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)), hbW]
    have hbkt1 : H3a.wRead m1 scrW wBkt = (bkt : ℤ) := by
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBkt with h | h <;> omega)), hbkt_r]
    have hoffH_eq : (baseW + 4) + 2 * (bkt : ℤ) = offH := rfl
    by_cases he : S.hEp bkt = S.ep
    · have hc_t : cValAt 0 inp m1 (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4))
                                            (.mul (.lit 2) (.readHeap scrW (.lit wBkt)))))
                      (.readHeap scrW (.lit wScr))) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 tblW ((H3a.wRead m1 scrW wBaseW + 4) + 2 * H3a.wRead m1 scrW wBkt) =
          H3a.wRead m1 scrW wScr) = true
        rw [hbW1, hbkt1, hoffH_eq, wRead_wWrite_of_ne _ _ (Or.inl hneW), hhEp_b, wRead_wWrite_self, he]
        exact decide_eq_true rfl
      have holdH_eq : oldH = S.hVal bkt := by dsimp [oldH, LiveSlot.effHead]; rw [if_pos he]
      refine DetExecAt.ite_true (C_c := 20) (C_b := 25) hc_t
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) ?_
      refine DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 1)) _ rfl ?_
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      change H3a.wRead m1 tblW (((H3a.wRead m1 scrW wBaseW + 4) + 2 * H3a.wRead m1 scrW wBkt) + 1) = _
      rw [hbW1, hbkt1, hoffH_eq, wRead_wWrite_of_ne _ _ (Or.inl hneW), hhVal_b, holdH_eq]
    · have hc_f : cValAt 0 inp m1 (.intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4))
                                            (.mul (.lit 2) (.readHeap scrW (.lit wBkt)))))
                      (.readHeap scrW (.lit wScr))) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 tblW ((H3a.wRead m1 scrW wBaseW + 4) + 2 * H3a.wRead m1 scrW wBkt) =
          H3a.wRead m1 scrW wScr) = false
        rw [hbW1, hbkt1, hoffH_eq, wRead_wWrite_of_ne _ _ (Or.inl hneW), hhEp_b, wRead_wWrite_self]
        exact decide_eq_false (by omega)
      have holdH_eq : oldH = -1 := by dsimp [oldH, LiveSlot.effHead]; rw [if_neg he]
      refine DetExecAt.ite_false (C_c := 20) (C_b := 25) hc_f
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) ?_
      refine DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 1)) (.lit (-1)) rfl ?_
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      rw [holdH_eq]; rfl
  have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 hscrW (by omega) (by omega)
  let m3 := H3a.wWrite m2 scrW (wScr + 2) offN
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2))
      (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))))
            (.mul (.lit 5) (.readHeap scrW (.lit wNd))))) m2 m3 25 := by
    refine DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wScr + 2)) _ rfl ?_
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    change (H3a.wRead m2 scrW wBaseW + (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))) + 5 * H3a.wRead m2 scrW wNd = offN
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)), hbW,
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjNd with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjNd with h | h <;> omega)), hnd_r]
    dsimp [offN, slotNodeOff]; ring
  have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 hscrW (by omega) (by omega)
  have hscr3_bW : H3a.wRead m3 scrW wBaseW = baseW := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)), hbW]
  have hscr3_bkt : H3a.wRead m3 scrW wBkt = (bkt : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBkt with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBkt with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBkt with h | h <;> omega)), hbkt_r]
  have hscr3_nd : H3a.wRead m3 scrW wNd = (nd : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjNd with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjNd with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjNd with h | h <;> omega)), hnd_r]
  have hscr3_eid : H3a.wRead m3 scrW wEid = (eid : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjEid with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjEid with h | h <;> omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjEid with h | h <;> omega)), heid_r]
  have hscr3_ep : H3a.wRead m3 scrW wScr = (S.ep : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hscr3_oldH : H3a.wRead m3 scrW (wScr + 1) = oldH := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hscr3_offN : H3a.wRead m3 scrW (wScr + 2) = offN := wRead_wWrite_self _ _ _ _
  let m4 := H3a.wWrite m3 tblW offH (S.ep : ℤ)
  let m5 := H3a.wWrite m4 tblW (offH + 1) (nd : ℤ)
  let m6 := H3a.wWrite m5 tblW offN (S.ep : ℤ)
  let m7 := H3a.wWrite m6 tblW (offN + 1) (bkt : ℤ)
  let m8 := H3a.wWrite m7 tblW (offN + 2) (eid : ℤ)
  let m9 := H3a.wWrite m8 tblW (offN + 3) (-1)
  let m10 := H3a.wWrite m9 tblW (offN + 4) oldH
  have hscr_same : ∀ w,
      H3a.wRead m4 scrW w = H3a.wRead m3 scrW w ∧
      H3a.wRead m5 scrW w = H3a.wRead m3 scrW w ∧
      H3a.wRead m6 scrW w = H3a.wRead m3 scrW w ∧
      H3a.wRead m7 scrW w = H3a.wRead m3 scrW w ∧
      H3a.wRead m8 scrW w = H3a.wRead m3 scrW w ∧
      H3a.wRead m9 scrW w = H3a.wRead m3 scrW w ∧
      H3a.wRead m10 scrW w = H3a.wRead m3 scrW w := by
    intro w; simp only [m4, m5, m6, m7, m8, m9, m10, wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), and_self]
  have hd4 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4)) (.mul (.lit 2) (.readHeap scrW (.lit wBkt))))
      (.readHeap scrW (.lit wScr))) m3 m4 25 :=
    DetExecAt.writeWordHeap 0 inp m3 tblW _ _
      (by change (H3a.wRead m3 scrW wBaseW + 4) + 2 * H3a.wRead m3 scrW wBkt = offH
          rw [hscr3_bW, hscr3_bkt]; rfl)
      hscr3_ep (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd5 : DetExec inp (.writeWordHeap tblW
      (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4)) (.mul (.lit 2) (.readHeap scrW (.lit wBkt)))) (.lit 1))
      (.readHeap scrW (.lit wNd))) m4 m5 25 :=
    DetExecAt.writeWordHeap 0 inp m4 tblW _ _
      (by change ((H3a.wRead m4 scrW wBaseW + 4) + 2 * H3a.wRead m4 scrW wBkt) + 1 = offH + 1
          rw [(hscr_same wBaseW).1, (hscr_same wBkt).1, hscr3_bW, hscr3_bkt]; rfl)
      ((hscr_same wNd).1.trans hscr3_nd) (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd6 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit (wScr + 2))) (.readHeap scrW (.lit wScr)))
      m5 m6 20 :=
    DetExecAt.writeWordHeap 0 inp m5 tblW _ _
      ((hscr_same (wScr + 2)).2.1.trans hscr3_offN)
      ((hscr_same wScr).2.1.trans hscr3_ep)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd7 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit (wScr + 2))) (.lit 1))
      (.readHeap scrW (.lit wBkt))) m6 m7 20 :=
    DetExecAt.writeWordHeap 0 inp m6 tblW _ _
      (by change H3a.wRead m6 scrW (wScr + 2) + 1 = offN + 1; rw [(hscr_same _).2.2.1, hscr3_offN])
      ((hscr_same wBkt).2.2.1.trans hscr3_bkt)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd8 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit (wScr + 2))) (.lit 2))
      (.readHeap scrW (.lit wEid))) m7 m8 20 :=
    DetExecAt.writeWordHeap 0 inp m7 tblW _ _
      (by change H3a.wRead m7 scrW (wScr + 2) + 2 = offN + 2; rw [(hscr_same _).2.2.2.1, hscr3_offN])
      ((hscr_same wEid).2.2.2.1.trans hscr3_eid)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd9 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit (wScr + 2))) (.lit 3)) (.lit (-1)))
      m8 m9 20 :=
    DetExecAt.writeWordHeap 0 inp m8 tblW _ _
      (by change H3a.wRead m8 scrW (wScr + 2) + 3 = offN + 3; rw [(hscr_same _).2.2.2.2.1, hscr3_offN])
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd10 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit (wScr + 2))) (.lit 4))
      (.readHeap scrW (.lit (wScr + 1)))) m9 m10 20 :=
    DetExecAt.writeWordHeap 0 inp m9 tblW _ _
      (by change H3a.wRead m9 scrW (wScr + 2) + 4 = offN + 4; rw [(hscr_same _).2.2.2.2.2.1, hscr3_offN])
      ((hscr_same (wScr + 1)).2.2.2.2.2.1.trans hscr3_oldH)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp4 : InFootprint TW BW TR BR m4 := InFootprint.wWrite hfp3 htblW (by omega) (by omega)
  have hfp5 : InFootprint TW BW TR BR m5 := InFootprint.wWrite hfp4 htblW (by omega) (by omega)
  have hfp6 : InFootprint TW BW TR BR m6 := InFootprint.wWrite hfp5 htblW (by omega) (by omega)
  have hfp7 : InFootprint TW BW TR BR m7 := InFootprint.wWrite hfp6 htblW (by omega) (by omega)
  have hfp8 : InFootprint TW BW TR BR m8 := InFootprint.wWrite hfp7 htblW (by omega) (by omega)
  have hfp9 : InFootprint TW BW TR BR m9 := InFootprint.wWrite hfp8 htblW (by omega) (by omega)
  have hfp10 : InFootprint TW BW TR BR m10 := InFootprint.wWrite hfp9 htblW (by omega) (by omega)
  have hfr10 : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m10 :=
    (((((((((RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m₀ _ _).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m1 _ _)).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m2 _ _)).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m3 (idx := offH) _ (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m4 (idx := offH + 1) _ (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m5 (idx := offN) _ (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m6 (idx := offN + 1) _ (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m7 (idx := offN + 2) _ (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m8 (idx := offN + 3) _ (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m9 (idx := offN + 4) _ (by omega) (by omega))
  have hbkt_lt_offN : offH + 1 < offN := slotBkt_lt_node baseW hbkt hnd
  by_cases hold_neg : oldH < 0
  · have hc_t : cValAt 0 inp m10 (.intLt (.readHeap scrW (.lit (wScr + 1))) (.lit 0)) = true := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m10 scrW (wScr + 1) < 0) = true
      rw [(hscr_same (wScr + 1)).2.2.2.2.2.2, hscr3_oldH]
      exact decide_eq_true hold_neg
    have hd11 : DetExec inp (.ite (.intLt (.readHeap scrW (.lit (wScr + 1))) (.lit 0)) .skip (.writeWordHeap tblW
            (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))))
                        (.mul (.lit 5) (.readHeap scrW (.lit (wScr + 1)))))
                  (.lit 3))
            (.readHeap scrW (.lit wNd))))
        m10 m10 15 :=
      DetExecAt.ite_true (C_c := 10) (C_b := 5) hc_t
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        ((DetExecAt.skip 0 inp m10).mono_cost (by omega))
    refine ⟨m10, (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq (hd8.seq (hd9.seq (hd10.seq hd11)))))))))).mono_cost (by omega),
      hfp10, ?_, ?_, ?_, hfr10⟩
    · have hm10_hdr : ∀ i, baseW ≤ i → i < baseW + 4 → H3a.wRead m10 tblW i = H3a.wRead m₀ tblW i := by
        intro i _ hhi
        simp only [m10, m9, m8, m7, m6, m5, m4, m3, m2, m1]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inl hneW),
            wRead_wWrite_of_ne _ _ (Or.inl hneW),
            wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      refine ⟨(hm10_hdr baseW le_rfl (by omega)).trans hep,
              (hm10_hdr (baseW + 1) (by omega) (by omega)).trans hblk,
              (hm10_hdr (baseW + 2) (by omega) (by omega)).trans hbc,
              fun r s k j => by simp only [m10, m9, m8, m7, m6, m5, m4, m3, m2, m1, rRead_wWrite]; exact hcaps r s k j,
              fun b hb => ?_, fun n hn => ?_⟩
      · have hltN : slotBktOff baseW b + 1 < offN := slotBkt_lt_node baseW hb hnd
        simp only [LiveSlot.pushNode]
        by_cases hbe : b = bkt
        · subst hbe
          rw [Function.update_self, Function.update_self]
          exact ⟨by simp only [m10, m9, m8, m7, m6, m5, m4]; repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 by simp only [m10, m9, m8, m7, m6, m5]; repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))])⟩
        · rw [Function.update_of_ne hbe, Function.update_of_ne hbe]
          have hne_off : slotBktOff baseW b ≠ offH ∧ slotBktOff baseW b ≠ offH + 1 ∧
              slotBktOff baseW b + 1 ≠ offH ∧ slotBktOff baseW b + 1 ≠ offH + 1 := by
            dsimp [offH, slotBktOff]; omega
          rcases hbkt_all b hb with ⟨h1, h2⟩
          refine ⟨?_, ?_⟩
          · simp only [m10, m9, m8, m7, m6, m5, m4, m3, m2, m1]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr hne_off.2.1),
                wRead_wWrite_of_ne _ _ (Or.inr hne_off.1),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW)]; exact h1
          · simp only [m10, m9, m8, m7, m6, m5, m4, m3, m2, m1]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr hne_off.2.2.2),
                wRead_wWrite_of_ne _ _ (Or.inr hne_off.2.2.1),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW)]; exact h2
      · dsimp only [LiveSlot.pushNode]
        rw [if_pos hold_neg]
        by_cases hne_n : n = nd
        · subst hne_n
          simp only [Function.update_self, m10, m9, m8, m7, m6]
          exact ⟨by repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 by repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 by repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 by repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 wRead_wWrite_self _ _ _ _⟩
        · simp only [Function.update_of_ne hne_n]
          have hgtB : offH + 1 < slotNodeOff R ℓ M₀ baseW n := slotBkt_lt_node baseW hbkt hn
          have hdisjN : slotNodeOff R ℓ M₀ baseW n + 4 < offN ∨ offN + 4 < slotNodeOff R ℓ M₀ baseW n := by
            dsimp [offN, slotNodeOff]; omega
          have hkeep_n : ∀ j : ℤ, 0 ≤ j → j ≤ 4 →
              H3a.wRead m10 tblW (slotNodeOff R ℓ M₀ baseW n + j) =
              H3a.wRead m₀ tblW (slotNodeOff R ℓ M₀ baseW n + j) := by
            intro j hj0 hj4
            simp only [m10, m9, m8, m7, m6, m5, m4, m3, m2, m1]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW)]
          rcases hnd_all n hn with ⟨h1, h2, h3, h4, h5⟩
          exact ⟨by have hk0 := hkeep_n 0 (by omega) (by omega); rw [add_zero] at hk0; exact hk0.trans h1,
                 (hkeep_n 1 (by omega) (by omega)).trans h2,
                 (hkeep_n 2 (by omega) (by omega)).trans h3,
                 (hkeep_n 3 (by omega) (by omega)).trans h4,
                 (hkeep_n 4 (by omega) (by omega)).trans h5⟩
    · intro w hw
      rw [(hscr_same w).2.2.2.2.2.2]
      simp only [m3, m2, m1]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    · intro r; simp only [m10, m9, m8, m7, m6, m5, m4, m3, m2, m1, rRead_wWrite]
  · have hold_nneg : 0 ≤ oldH := by omega
    obtain ⟨hold_lt, hold_ne⟩ := holdH_pool hold_nneg
    have hold_cast : (oldH.toNat : ℤ) = oldH := Int.toNat_of_nonneg hold_nneg
    let offOld := slotNodeOff R ℓ M₀ baseW oldH.toNat
    have hob := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hold_lt
    change baseW + 4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) ≤ offOld ∧ offOld + 4 < baseW + slotWStride R ℓ M₀ cap_u B_max at hob
    have hc_f : cValAt 0 inp m10 (.intLt (.readHeap scrW (.lit (wScr + 1))) (.lit 0)) = false := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m10 scrW (wScr + 1) < 0) = false
      rw [(hscr_same (wScr + 1)).2.2.2.2.2.2, hscr3_oldH]
      exact decide_eq_false hold_neg
    let m11 := H3a.wWrite m10 tblW (offOld + 3) (nd : ℤ)
    have hd11 : DetExec inp (.ite (.intLt (.readHeap scrW (.lit (wScr + 1))) (.lit 0)) .skip (.writeWordHeap tblW
            (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))))
                        (.mul (.lit 5) (.readHeap scrW (.lit (wScr + 1)))))
                  (.lit 3))
            (.readHeap scrW (.lit wNd))))
        m10 m11 45 := by
      refine DetExecAt.ite_false (C_c := 10) (C_b := 35) hc_f
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) ?_
      refine DetExecAt.writeWordHeap 0 inp m10 tblW _ _
        (by change ((H3a.wRead m10 scrW wBaseW + (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))) +
              5 * H3a.wRead m10 scrW (wScr + 1)) + 3 = offOld + 3
            rw [(hscr_same wBaseW).2.2.2.2.2.2, (hscr_same (wScr + 1)).2.2.2.2.2.2,
                hscr3_bW, hscr3_oldH, ← hold_cast]
            dsimp [offOld, slotNodeOff]; ring)
        ((hscr_same wNd).2.2.2.2.2.2.trans hscr3_nd)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hfp11 : InFootprint TW BW TR BR m11 := InFootprint.wWrite hfp10 htblW (by omega) (by omega)
    have hfr11 : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m11 :=
      hfr10.trans (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m10 (idx := offOld + 3) (nd : ℤ) (by omega) (by omega))
    refine ⟨m11, (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq (hd8.seq (hd9.seq (hd10.seq hd11)))))))))).mono_cost (by omega),
      hfp11, ?_, ?_, ?_, hfr11⟩
    · have hm11_hdr : ∀ i, baseW ≤ i → i < baseW + 4 → H3a.wRead m11 tblW i = H3a.wRead m₀ tblW i := by
        intro i _ hhi
        simp only [m11, m10, m9, m8, m7, m6, m5, m4, m3, m2, m1]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inl hneW),
            wRead_wWrite_of_ne _ _ (Or.inl hneW),
            wRead_wWrite_of_ne _ _ (Or.inl hneW)]
      refine ⟨(hm11_hdr baseW le_rfl (by omega)).trans hep,
              (hm11_hdr (baseW + 1) (by omega) (by omega)).trans hblk,
              (hm11_hdr (baseW + 2) (by omega) (by omega)).trans hbc,
              fun r s k j => by simp only [m11, m10, m9, m8, m7, m6, m5, m4, m3, m2, m1, rRead_wWrite]; exact hcaps r s k j,
              fun b hb => ?_, fun n hn => ?_⟩
      · have hltN : slotBktOff baseW b + 1 < offN := slotBkt_lt_node baseW hb hnd
        have hltOld : slotBktOff baseW b + 1 < offOld := slotBkt_lt_node baseW hb hold_lt
        simp only [LiveSlot.pushNode]
        by_cases hbe : b = bkt
        · subst hbe
          rw [Function.update_self, Function.update_self]
          exact ⟨by simp only [m11, m10, m9, m8, m7, m6, m5, m4]; repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 by simp only [m11, m10, m9, m8, m7, m6, m5]; repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))])⟩
        · rw [Function.update_of_ne hbe, Function.update_of_ne hbe]
          have hne_off : slotBktOff baseW b ≠ offH ∧ slotBktOff baseW b ≠ offH + 1 ∧
              slotBktOff baseW b + 1 ≠ offH ∧ slotBktOff baseW b + 1 ≠ offH + 1 := by
            dsimp [offH, slotBktOff]; omega
          rcases hbkt_all b hb with ⟨h1, h2⟩
          refine ⟨?_, ?_⟩
          · simp only [m11, m10, m9, m8, m7, m6, m5, m4, m3, m2, m1]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr hne_off.2.1),
                wRead_wWrite_of_ne _ _ (Or.inr hne_off.1),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW)]; exact h1
          · simp only [m11, m10, m9, m8, m7, m6, m5, m4, m3, m2, m1]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr hne_off.2.2.2),
                wRead_wWrite_of_ne _ _ (Or.inr hne_off.2.2.1),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW)]; exact h2
      · dsimp only [LiveSlot.pushNode, oldH]
        rw [if_neg hold_neg]
        by_cases hne_n : n = nd
        · subst hne_n
          have hdisjOld : offN + 4 < offOld ∨ offOld + 4 < offN := by
            have : oldH.toNat ≠ n := hold_ne
            dsimp [offN, offOld, slotNodeOff]; omega
          rw [Function.update_self, Function.update_self, Function.update_self,
              Function.update_of_ne hold_ne.symm, Function.update_self, Function.update_self]
          simp only [m11, m10, m9, m8, m7, m6]
          exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld with h | h <;> omega))]; repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld with h | h <;> omega))]; repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld with h | h <;> omega))]; repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld with h | h <;> omega))]; repeat (first | rw [wRead_wWrite_self] | rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]),
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld with h | h <;> omega)), wRead_wWrite_self]⟩
        · have hgtB : offH + 1 < slotNodeOff R ℓ M₀ baseW n := slotBkt_lt_node baseW hbkt hn
          have hdisjN : slotNodeOff R ℓ M₀ baseW n + 4 < offN ∨ offN + 4 < slotNodeOff R ℓ M₀ baseW n := by
            dsimp [offN, slotNodeOff]; omega
          have hkeep_m10 : ∀ j : ℤ, 0 ≤ j → j ≤ 4 →
              H3a.wRead m10 tblW (slotNodeOff R ℓ M₀ baseW n + j) =
              H3a.wRead m₀ tblW (slotNodeOff R ℓ M₀ baseW n + j) := by
            intro j hj0 hj4
            simp only [m10, m9, m8, m7, m6, m5, m4, m3, m2, m1]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjN with h | h <;> omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW)]
          rcases hnd_all n hn with ⟨h1, h2, h3, h4, h5⟩
          have hold_def : S.effHead bkt = oldH := rfl
          rw [hold_def]
          by_cases hn_old : n = oldH.toNat
          · subst hn_old
            simp only [Function.update_of_ne hne_n, Function.update_self]
            exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offOld]; omega))]; have hk0 := hkeep_m10 0 (by omega) (by omega); rw [add_zero] at hk0; exact hk0.trans h1,
                   by rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offOld]; omega))]; exact (hkeep_m10 1 (by omega) (by omega)).trans h2,
                   by rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offOld]; omega))]; exact (hkeep_m10 2 (by omega) (by omega)).trans h3,
                   wRead_wWrite_self _ _ _ _,
                   by rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offOld]; omega))]; exact (hkeep_m10 4 (by omega) (by omega)).trans h5⟩
          · simp only [Function.update_of_ne hne_n, Function.update_of_ne hn_old]
            have hdisjOld' : slotNodeOff R ℓ M₀ baseW n + 4 < offOld ∨ offOld + 4 < slotNodeOff R ℓ M₀ baseW n := by
              dsimp [offOld, slotNodeOff]; omega
            exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld' with h | h <;> omega))]; have hk0 := hkeep_m10 0 (by omega) (by omega); rw [add_zero] at hk0; exact hk0.trans h1,
                   by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld' with h | h <;> omega))]; exact (hkeep_m10 1 (by omega) (by omega)).trans h2,
                   by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld' with h | h <;> omega))]; exact (hkeep_m10 2 (by omega) (by omega)).trans h3,
                   by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld' with h | h <;> omega))]; exact (hkeep_m10 3 (by omega) (by omega)).trans h4,
                   by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjOld' with h | h <;> omega))]; exact (hkeep_m10 4 (by omega) (by omega)).trans h5⟩
    · intro w hw
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), (hscr_same w).2.2.2.2.2.2]
      simp only [m3, m2, m1]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    · intro r; simp only [m11, m10, m9, m8, m7, m6, m5, m4, m3, m2, m1, rRead_wWrite]

/-! ### 2. `O(1)` DLL Unlink (`liveSlotUnlinkNodeStmt`) & `O(R * cap_u)` `unlinkLoc` -/

def liveSlotUnlinkNodeStmt (scrW tblW : ℕ)
    (wBaseW wNd wScr : ℤ) (R ℓ M₀ : ℕ) : ArithRAMStmt :=
  let N_bktZ : ℤ := ((R * M₀ ^ ℓ : ℕ) : ℤ)
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  let ndE := IntExpr.readHeap scrW (.lit wNd)
  let wEp := wScr
  let wOffN := wScr + 1
  let wBkt := wScr + 2
  let wP := wScr + 3
  let wNx := wScr + 4
  let offNE := IntExpr.add (.add bW (.lit (4 + 2 * N_bktZ))) (.mul (.lit 5) ndE)
  let offHE := IntExpr.add (.add bW (.lit 4)) (.mul (.lit 2) (.readHeap scrW (.lit wBkt)))
  .seq (.writeWordHeap scrW (.lit wEp) (.readHeap tblW bW))
  (.seq (.writeWordHeap scrW (.lit wOffN) offNE)
        (.ite (.intEq (.readHeap tblW (.readHeap scrW (.lit wOffN))) (.readHeap scrW (.lit wEp)))
          (.seq (.writeWordHeap scrW (.lit wBkt)
                  (.readHeap tblW (.add (.readHeap scrW (.lit wOffN)) (.lit 1))))
          (.seq (.writeWordHeap scrW (.lit wP)
                  (.readHeap tblW (.add (.readHeap scrW (.lit wOffN)) (.lit 3))))
          (.seq (.writeWordHeap scrW (.lit wNx)
                  (.readHeap tblW (.add (.readHeap scrW (.lit wOffN)) (.lit 4))))
          (.seq (.writeWordHeap tblW (.readHeap scrW (.lit wOffN)) (.lit 0))
          (.seq (.ite (.intLt (.readHeap scrW (.lit wP)) (.lit 0))
                  (.seq (.writeWordHeap tblW offHE (.readHeap scrW (.lit wEp)))
                        (.writeWordHeap tblW (.add offHE (.lit 1)) (.readHeap scrW (.lit wNx))))
                  (.writeWordHeap tblW
                    (.add (.add (.add bW (.lit (4 + 2 * N_bktZ)))
                                (.mul (.lit 5) (.readHeap scrW (.lit wP))))
                          (.lit 4))
                    (.readHeap scrW (.lit wNx))))
                (.ite (.intLt (.readHeap scrW (.lit wNx)) (.lit 0))
                  .skip
                  (.writeWordHeap tblW
                    (.add (.add (.add bW (.lit (4 + 2 * N_bktZ)))
                                (.mul (.lit 5) (.readHeap scrW (.lit wNx))))
                          (.lit 3))
                    (.readHeap scrW (.lit wP)))))))))
          .skip))

theorem exec_liveSlotUnlinkNodeStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wNd wScr baseW baseR : ℤ)
    {R ℓ M₀ cap_u B_max blkStart nd : ℕ}
    (hnd : nd < B_max * (R * cap_u))
    {ndL : Fin R → Fin (M₀ ^ ℓ) → List ℕ}
    {S : LiveSlot R ℓ M₀ d}
    (hinv : LiveSlotListInv cap_u B_max blkStart ndL S)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htblW : tblW < TW) (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 5 ≤ (BW : ℤ))
    (hdisjBW : wBaseW < wScr ∨ wScr + 5 ≤ wBaseW)
    (hdisjNd : wNd < wScr ∨ wScr + 5 ≤ wNd)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hnd_r : H3a.wRead m₀ scrW wNd = (nd : ℤ))
    (henc : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (liveSlotUnlinkNodeStmt scrW tblW wBaseW wNd wScr R ℓ M₀) m₀ m₁ 350 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (S.unlinkNode nd) m₁ ∧
      (∀ w, (w < wScr ∨ wScr + 5 ≤ w) → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m₁ := by
  have ⟨hep, hblk, hbc, hcaps, hbkt_all, hnd_all⟩ := henc
  rcases hnd_all nd hnd with ⟨hnEp_nd, hnBkt_nd, _, hnPrev_nd, hnNext_nd⟩
  have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hnd
  have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
  let offN := slotNodeOff R ℓ M₀ baseW nd
  change baseW + 4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) ≤ offN ∧ offN + 4 < baseW + slotWStride R ℓ M₀ cap_u B_max at hnb
  let m1 := H3a.wWrite m₀ scrW wScr (S.ep : ℤ)
  let m2 := H3a.wWrite m1 scrW (wScr + 1) offN
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.readHeap tblW (.readHeap scrW (.lit wBaseW))))
      m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wScr) _ rfl
      (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wBaseW) = _; rw [hbW, hep])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
      (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))))
            (.mul (.lit 5) (.readHeap scrW (.lit wNd))))) m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 1)) _ rfl
      (by change (H3a.wRead m1 scrW wBaseW + (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))) + 5 * H3a.wRead m1 scrW wNd = offN
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)), hbW,
              wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjNd with h | h <;> omega)), hnd_r]
          dsimp [offN, slotNodeOff]; ring)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW hwScr.1 (by omega)
  have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 hscrW (by omega) (by omega)
  by_cases hact : S.nEp nd = S.ep
  · rcases hinv with ⟨_, _, _, hrc, hiff⟩
    obtain ⟨r₀, c₀, hmem₀⟩ := (hiff nd hnd).mp hact
    have hbkt_eq : S.nBkt nd = r₀.val * M₀ ^ ℓ + c₀.val := ((hrc r₀ c₀).2 nd hmem₀).2.2.1
    have hbkt_lt : S.nBkt nd < R * M₀ ^ ℓ := by
      rw [hbkt_eq]
      calc r₀.val * M₀ ^ ℓ + c₀.val < r₀.val * M₀ ^ ℓ + M₀ ^ ℓ := by have := c₀.isLt; omega
        _ = (r₀.val + 1) * M₀ ^ ℓ := by ring
        _ ≤ R * M₀ ^ ℓ := Nat.mul_le_mul_right _ r₀.isLt
    obtain ⟨hp_mem, hnx_mem, _⟩ := isBucketDLL_erase (hrc r₀ c₀).1 hmem₀
    have hp_valid : S.nPrev nd < 0 ∨
        ((S.nPrev nd).toNat < B_max * (R * cap_u) ∧ ((S.nPrev nd).toNat : ℤ) = S.nPrev nd) := by
      rcases hp_mem with hp_neg | ⟨w, hw_mem, hpw⟩
      · exact Or.inl (by rw [hp_neg]; norm_num)
      · right
        have hto : (S.nPrev nd).toNat = w := by rw [hpw]; exact Int.toNat_natCast w
        rw [hto]
        exact ⟨((hrc r₀ c₀).2 w hw_mem).1, hpw.symm⟩
    have hnx_valid : S.nNext nd < 0 ∨
        ((S.nNext nd).toNat < B_max * (R * cap_u) ∧ ((S.nNext nd).toNat : ℤ) = S.nNext nd) := by
      rcases hnx_mem with hnx_neg | ⟨w, hw_mem, hnw⟩
      · exact Or.inl (by rw [hnx_neg]; norm_num)
      · right
        have hto : (S.nNext nd).toNat = w := by rw [hnw]; exact Int.toNat_natCast w
        rw [hto]
        exact ⟨((hrc r₀ c₀).2 w hw_mem).1, hnw.symm⟩
    have hc_t : cValAt 0 inp m2 (.intEq (.readHeap tblW (.readHeap scrW (.lit (wScr + 1))))
        (.readHeap scrW (.lit wScr))) = true := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m2 tblW (H3a.wRead m2 scrW (wScr + 1)) = H3a.wRead m2 scrW wScr) = true
      rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          hnEp_nd, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self, hact]
      exact decide_eq_true rfl
    let bkt := S.nBkt nd
    let p := S.nPrev nd
    let nx := S.nNext nd
    let offH := slotBktOff baseW bkt
    have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hbkt_lt
    change baseW + 4 ≤ offH ∧ offH + 1 < baseW + slotWStride R ℓ M₀ cap_u B_max at hbb
    let m3 := H3a.wWrite m2 scrW (wScr + 2) (bkt : ℤ)
    let m4 := H3a.wWrite m3 scrW (wScr + 3) p
    let m5 := H3a.wWrite m4 scrW (wScr + 4) nx
    let m6 := H3a.wWrite m5 tblW offN 0
    have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 2))
        (.readHeap tblW (.add (.readHeap scrW (.lit (wScr + 1))) (.lit 1)))) m2 m3 20 :=
      DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wScr + 2)) _ rfl
        (by change H3a.wRead m2 tblW (H3a.wRead m2 scrW (wScr + 1) + 1) = _
            rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW), hnBkt_nd])
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd4 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 3))
        (.readHeap tblW (.add (.readHeap scrW (.lit (wScr + 1))) (.lit 3)))) m3 m4 20 :=
      DetExecAt.writeWordHeap 0 inp m3 scrW (.lit (wScr + 3)) _ rfl
        (by change H3a.wRead m3 tblW (H3a.wRead m3 scrW (wScr + 1) + 3) = _
            have hm3_1 : H3a.wRead m3 scrW (wScr + 1) = offN := by
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
            rw [hm3_1, wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW), hnPrev_nd])
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd5 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 4))
        (.readHeap tblW (.add (.readHeap scrW (.lit (wScr + 1))) (.lit 4)))) m4 m5 20 :=
      DetExecAt.writeWordHeap 0 inp m4 scrW (.lit (wScr + 4)) _ rfl
        (by change H3a.wRead m4 tblW (H3a.wRead m4 scrW (wScr + 1) + 4) = _
            have hm4_1 : H3a.wRead m4 scrW (wScr + 1) = offN := by
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_self]
            rw [hm4_1, wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
                wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW), hnNext_nd])
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd6 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit (wScr + 1))) (.lit 0)) m5 m6 20 :=
      DetExecAt.writeWordHeap 0 inp m5 tblW _ (.lit 0)
        (by change H3a.wRead m5 scrW (wScr + 1) = offN
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
        rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 hscrW (by omega) (by omega)
    have hfp4 : InFootprint TW BW TR BR m4 := InFootprint.wWrite hfp3 hscrW (by omega) (by omega)
    have hfp5 : InFootprint TW BW TR BR m5 := InFootprint.wWrite hfp4 hscrW (by omega) (by omega)
    have hfp6 : InFootprint TW BW TR BR m6 := InFootprint.wWrite hfp5 htblW (by omega) (by omega)
    have hm6_bW : H3a.wRead m6 scrW wBaseW = baseW := by
      simp only [m6, m5, m4, m3, m2, m1]
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega)), hbW]
    have hm6_ep : H3a.wRead m6 scrW wScr = (S.ep : ℤ) := by
      simp only [m6, m5, m4, m3, m2, m1]
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
    have hm6_bkt : H3a.wRead m6 scrW (wScr + 2) = (bkt : ℤ) := by
      simp only [m6, m5, m4, m3]
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
    have hm6_p : H3a.wRead m6 scrW (wScr + 3) = p := by
      simp only [m6, m5, m4]
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
    have hm6_nx : H3a.wRead m6 scrW (wScr + 4) = nx := by
      simp only [m6, m5]
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_self]
    have hfr6 : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m6 :=
      (((((RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m₀ _ _).trans
        (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m1 _ _)).trans
        (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m2 _ _)).trans
        (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m3 _ _)).trans
        (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m4 _ _)).trans
        (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m5 (idx := offN) 0 (by omega) (by omega))
    have hk5 : ∀ i, H3a.wRead m5 tblW i = H3a.wRead m₀ tblW i := by
      intro i; simp only [m5, m4, m3, m2, m1, wRead_wWrite_of_ne _ _ (Or.inl hneW)]
    -- First establish `EncLiveSlot` for `m6` (`S6 := { S with nEp := update S.nEp nd 0 }`)
    let S6 : LiveSlot R ℓ M₀ d := { S with nEp := Function.update S.nEp nd 0 }
    have henc6 : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S6 m6 := by
      refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hk5]; exact hep,
              by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hk5]; exact hblk,
              by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hk5]; exact hbc,
              fun r s k j => by simp only [m6, m5, m4, m3, m2, m1, rRead_wWrite]; exact hcaps r s k j,
              fun b hb => ?_, fun n hn => ?_⟩
      · have hltN : slotBktOff baseW b + 1 < offN := slotBkt_lt_node baseW hb hnd
        rcases hbkt_all b hb with ⟨h1, h2⟩
        exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hk5]; exact h1,
               by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hk5]; exact h2⟩
      · rcases hnd_all n hn with ⟨h1, h2, h3, h4, h5⟩
        refine ⟨?_,
                by rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offN, slotNodeOff]; omega)), hk5]; exact h2,
                by rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offN, slotNodeOff]; omega)), hk5]; exact h3,
                by rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offN, slotNodeOff]; omega)), hk5]; exact h4,
                by rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offN, slotNodeOff]; omega)), hk5]; exact h5⟩
        by_cases hne_n : n = nd
        · subst hne_n; dsimp [S6]; rw [Function.update_self]; exact wRead_wWrite_self _ _ _ _
        · dsimp [S6]; rw [Function.update_of_ne hne_n,
            wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offN, slotNodeOff]; omega)), hk5]; exact h1
    -- Step 7: update bucket head (`p < 0`) or `nNext[p.toNat]` (`0 ≤ p`)
    let S7 : LiveSlot R ℓ M₀ d :=
      { S6 with
        hEp := if p < 0 then Function.update S.hEp bkt S.ep else S.hEp
        hVal := if p < 0 then Function.update S.hVal bkt nx else S.hVal
        nNext := if p < 0 then S.nNext else Function.update S.nNext p.toNat nx }
    have hstep7 : ∃ m7 : ArithRAMMemory,
        DetExec inp
          (.ite (.intLt (.readHeap scrW (.lit (wScr + 3))) (.lit 0))
            (.seq (.writeWordHeap tblW (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4))
                                             (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 2)))))
                    (.readHeap scrW (.lit wScr)))
                  (.writeWordHeap tblW (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4))
                                                   (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 2))))) (.lit 1))
                    (.readHeap scrW (.lit (wScr + 4)))))
            (.writeWordHeap tblW
              (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))))
                          (.mul (.lit 5) (.readHeap scrW (.lit (wScr + 3))))) (.lit 4))
              (.readHeap scrW (.lit (wScr + 4)))))
          m6 m7 60 ∧
        InFootprint TW BW TR BR m7 ∧
        (∀ w, H3a.wRead m7 scrW w = H3a.wRead m6 scrW w) ∧
        (∀ r, H3a.rRead m7 scrR r = H3a.rRead m₀ scrR r) ∧
        RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m7 ∧
        EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S7 m7 := by
      rcases henc6 with ⟨hep6, hblk6, hbc6, hcaps6, hbkt6, hnd6⟩
      rcases hp_valid with hp_neg | ⟨hp_lt, hp_cast⟩
      · have hc7_t : cValAt 0 inp m6 (.intLt (.readHeap scrW (.lit (wScr + 3))) (.lit 0)) = true := by
          simp only [cValAt, evalArithCond, evalIntExpr]
          change decide (H3a.wRead m6 scrW (wScr + 3) < 0) = true
          rw [hm6_p]; exact decide_eq_true hp_neg
        let m7a := H3a.wWrite m6 tblW offH (S.ep : ℤ)
        let m7b := H3a.wWrite m7a tblW (offH + 1) nx
        have hd7a : DetExec inp (.writeWordHeap tblW
            (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4)) (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 2)))))
            (.readHeap scrW (.lit wScr))) m6 m7a 25 :=
          DetExecAt.writeWordHeap 0 inp m6 tblW _ _
            (by change (H3a.wRead m6 scrW wBaseW + 4) + 2 * H3a.wRead m6 scrW (wScr + 2) = offH
                rw [hm6_bW, hm6_bkt]; rfl)
            hm6_ep (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        have hd7b : DetExec inp (.writeWordHeap tblW
            (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit 4)) (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 2))))) (.lit 1))
            (.readHeap scrW (.lit (wScr + 4)))) m7a m7b 25 :=
          DetExecAt.writeWordHeap 0 inp m7a tblW _ _
            (by change ((H3a.wRead m7a scrW wBaseW + 4) + 2 * H3a.wRead m7a scrW (wScr + 2)) + 1 = offH + 1
                have hm7a_scr : ∀ w, H3a.wRead m7a scrW w = H3a.wRead m6 scrW w :=
                  fun _ => wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)
                rw [hm7a_scr, hm7a_scr, hm6_bW, hm6_bkt]; rfl)
            (by change H3a.wRead m7a scrW (wScr + 4) = nx; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hm6_nx])
            (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        have hfp7a : InFootprint TW BW TR BR m7a := InFootprint.wWrite hfp6 htblW (by omega) (by omega)
        have hfp7b : InFootprint TW BW TR BR m7b := InFootprint.wWrite hfp7a htblW (by omega) (by omega)
        refine ⟨m7b,
          DetExecAt.ite_true (C_c := 10) (C_b := 50) hc7_t
            (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            (hd7a.seq hd7b),
          hfp7b,
          fun w => by simp only [m7b, m7a, wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)],
          fun r => by simp only [m7b, m7a, m6, m5, m4, m3, m2, m1, rRead_wWrite],
          (hfr6.trans (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m6 (idx := offH) _ (by omega) (by omega))).trans
            (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m7a (idx := offH + 1) _ (by omega) (by omega)),
          ?_⟩
        refine ⟨by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hep6,
                by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hblk6,
                by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbc6,
                fun r s k j => by simp only [m7b, m7a, rRead_wWrite]; exact hcaps6 r s k j,
                fun b hb => ?_, fun n hn => ?_⟩
        · dsimp [S7]; rw [if_pos hp_neg, if_pos hp_neg]
          by_cases hbe : b = bkt
          · subst hbe
            rw [Function.update_self, Function.update_self]
            exact ⟨by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self],
                   wRead_wWrite_self _ _ _ _⟩
          · rw [Function.update_of_ne hbe, Function.update_of_ne hbe]
            have hne_off : slotBktOff baseW b ≠ offH ∧ slotBktOff baseW b ≠ offH + 1 ∧
                slotBktOff baseW b + 1 ≠ offH ∧ slotBktOff baseW b + 1 ≠ offH + 1 := by
              dsimp [offH, slotBktOff]; omega
            rcases hbkt6 b hb with ⟨h1, h2⟩
            exact ⟨by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr hne_off.2.1), wRead_wWrite_of_ne _ _ (Or.inr hne_off.1)]; exact h1,
                   by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr hne_off.2.2.2), wRead_wWrite_of_ne _ _ (Or.inr hne_off.2.2.1)]; exact h2⟩
        · dsimp [S7]; rw [if_pos hp_neg]
          have hgtB : offH + 1 < slotNodeOff R ℓ M₀ baseW n := slotBkt_lt_node baseW hbkt_lt hn
          rcases hnd6 n hn with ⟨h1, h2, h3, h4, h5⟩
          exact ⟨by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
                 by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h2,
                 by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h3,
                 by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h4,
                 by simp only [m7b, m7a]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h5⟩
      · have hp_not_neg : ¬ p < 0 := by dsimp only [p]; rw [← hp_cast]; omega
        have hc7_f : cValAt 0 inp m6 (.intLt (.readHeap scrW (.lit (wScr + 3))) (.lit 0)) = false := by
          simp only [cValAt, evalArithCond, evalIntExpr]
          change decide (H3a.wRead m6 scrW (wScr + 3) < 0) = false
          rw [hm6_p]; exact decide_eq_false hp_not_neg
        let offP := slotNodeOff R ℓ M₀ baseW p.toNat
        have hpb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hp_lt
        change baseW + 4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) ≤ offP ∧ offP + 4 < baseW + slotWStride R ℓ M₀ cap_u B_max at hpb
        let m7c := H3a.wWrite m6 tblW (offP + 4) nx
        have hd7c : DetExec inp (.writeWordHeap tblW
            (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))))
                        (.mul (.lit 5) (.readHeap scrW (.lit (wScr + 3))))) (.lit 4))
            (.readHeap scrW (.lit (wScr + 4)))) m6 m7c 50 :=
          DetExecAt.writeWordHeap 0 inp m6 tblW _ _
            (by change ((H3a.wRead m6 scrW wBaseW + (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))) +
                  5 * H3a.wRead m6 scrW (wScr + 3)) + 4 = offP + 4
                rw [hm6_bW, hm6_p]; dsimp only [p, offP, slotNodeOff]; rw [hp_cast]; ring)
            hm6_nx (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        have hfp7c : InFootprint TW BW TR BR m7c := InFootprint.wWrite hfp6 htblW (by omega) (by omega)
        refine ⟨m7c,
          DetExecAt.ite_false (C_c := 10) (C_b := 50) hc7_f
            (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd7c,
          hfp7c,
          fun w => wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          fun r => by simp only [m7c, m6, m5, m4, m3, m2, m1, rRead_wWrite],
          hfr6.trans (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m6 (idx := offP + 4) _ (by omega) (by omega)),
          ?_⟩
        refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hep6,
                by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hblk6,
                by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbc6,
                fun r s k j => by rw [rRead_wWrite]; exact hcaps6 r s k j,
                fun b hb => ?_, fun n hn => ?_⟩
        · dsimp [S7]; rw [if_neg hp_not_neg, if_neg hp_not_neg]
          have hltP : slotBktOff baseW b + 1 < offP := slotBkt_lt_node baseW hb hp_lt
          rcases hbkt6 b hb with ⟨h1, h2⟩
          exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h2⟩
        · dsimp [S7]; rw [if_neg hp_not_neg]
          rcases hnd6 n hn with ⟨h1, h2, h3, h4, h5⟩
          have hmod4 : ∀ j : ℤ, 0 ≤ j → j ≤ 3 → slotNodeOff R ℓ M₀ baseW n + j ≠ offP + 4 := by
            intro j _ _; dsimp [offP, slotNodeOff]; omega
          refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by simpa using hmod4 0 (by omega) (by omega)))]; exact h1,
                  by rw [wRead_wWrite_of_ne _ _ (Or.inr (hmod4 1 (by omega) (by omega)))]; exact h2,
                  by rw [wRead_wWrite_of_ne _ _ (Or.inr (hmod4 2 (by omega) (by omega)))]; exact h3,
                  by rw [wRead_wWrite_of_ne _ _ (Or.inr (hmod4 3 (by omega) (by omega)))]; exact h4,
                  ?_⟩
          by_cases hn_p : n = p.toNat
          · subst hn_p; rw [Function.update_self]; exact wRead_wWrite_self _ _ _ _
          · rw [Function.update_of_ne hn_p,
              wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offP, slotNodeOff]; omega))]; exact h5
    obtain ⟨m7, hd7, hfp7, hw7_scr, hr7_scr, hfr7, henc7⟩ := hstep7
    -- Step 8: update `nPrev[nx.toNat]` if `0 ≤ nx`
    rcases henc7 with ⟨hep7, hblk7, hbc7, hcaps7, hbkt7, hnd7⟩
    rcases hnx_valid with hnx_neg | ⟨hnx_lt, hnx_cast⟩
    · have hc8_t : cValAt 0 inp m7 (.intLt (.readHeap scrW (.lit (wScr + 4))) (.lit 0)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m7 scrW (wScr + 4) < 0) = true
        rw [hw7_scr, hm6_nx]; exact decide_eq_true hnx_neg
      have hd8 : DetExec inp (.ite (.intLt (.readHeap scrW (.lit (wScr + 4))) (.lit 0)) .skip (.writeWordHeap tblW
            (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))))
                        (.mul (.lit 5) (.readHeap scrW (.lit (wScr + 4)))))
                  (.lit 3))
            (.readHeap scrW (.lit (wScr + 3)))))
          m7 m7 15 :=
        DetExecAt.ite_true (C_c := 10) (C_b := 5) hc8_t
          (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          ((DetExecAt.skip 0 inp m7).mono_cost (by omega))
      have hd_in := DetExecAt.ite_true (fB := .skip) (C_c := 20) (C_b := 160) hc_t
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        ((hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq hd8))))).mono_cost (by omega))
      have hS_eq : S.unlinkNode nd = S7 := by
        unfold LiveSlot.unlinkNode; rw [if_pos hact]; dsimp only; rw [if_pos hnx_neg]
      refine ⟨m7, (hd1.seq (hd2.seq hd_in)).mono_cost (by omega), hfp7,
        hS_eq ▸ ⟨hep7, hblk7, hbc7, hcaps7, hbkt7, hnd7⟩, ?_, hr7_scr, hfr7⟩
      intro w hw
      rw [hw7_scr]
      simp only [m6, m5, m4, m3, m2, m1]
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    · have hnx_not_neg : ¬ nx < 0 := by dsimp only [nx]; rw [← hnx_cast]; omega
      have hc8_f : cValAt 0 inp m7 (.intLt (.readHeap scrW (.lit (wScr + 4))) (.lit 0)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m7 scrW (wScr + 4) < 0) = false
        rw [hw7_scr, hm6_nx]; exact decide_eq_false hnx_not_neg
      let offNx := slotNodeOff R ℓ M₀ baseW nx.toNat
      have hnxb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hnx_lt
      change baseW + 4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) ≤ offNx ∧ offNx + 4 < baseW + slotWStride R ℓ M₀ cap_u B_max at hnxb
      let m8 := H3a.wWrite m7 tblW (offNx + 3) p
      have hd8c : DetExec inp (.writeWordHeap tblW
            (.add (.add (.add (.readHeap scrW (.lit wBaseW)) (.lit (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))))
                        (.mul (.lit 5) (.readHeap scrW (.lit (wScr + 4)))))
                  (.lit 3))
            (.readHeap scrW (.lit (wScr + 3)))) m7 m8 35 :=
        DetExecAt.writeWordHeap 0 inp m7 tblW _ _
          (by change ((H3a.wRead m7 scrW wBaseW + (4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ))) +
                5 * H3a.wRead m7 scrW (wScr + 4)) + 3 = offNx + 3
              rw [hw7_scr, hw7_scr, hm6_bW, hm6_nx]; dsimp only [nx, offNx, slotNodeOff]; rw [hnx_cast]; ring)
          ((hw7_scr (wScr + 3)).trans hm6_p)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd8 := DetExecAt.ite_false (tB := .skip) (C_c := 10) (C_b := 35) hc8_f
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd8c
      have hd_in := DetExecAt.ite_true (fB := .skip) (C_c := 20) (C_b := 185) hc_t
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        ((hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq hd8))))).mono_cost (by omega))
      have hfp8 : InFootprint TW BW TR BR m8 := InFootprint.wWrite hfp7 htblW (by omega) (by omega)
      have hfr8 : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m8 :=
        hfr7.trans (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m7 (idx := offNx + 3) _ (by omega) (by omega))
      have hS_eq : S.unlinkNode nd = { S7 with nPrev := Function.update S.nPrev nx.toNat p } := by
        unfold LiveSlot.unlinkNode; rw [if_pos hact]; dsimp only; rw [if_neg hnx_not_neg]
      refine ⟨m8, (hd1.seq (hd2.seq hd_in)).mono_cost (by omega), hfp8, hS_eq ▸ ?_, ?_, ?_, hfr8⟩
      · refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hep7,
                by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hblk7,
                by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbc7,
                fun r s k j => by rw [rRead_wWrite]; exact hcaps7 r s k j,
                fun b hb => ?_, fun n hn => ?_⟩
        · have hltNx : slotBktOff baseW b + 1 < offNx := slotBkt_lt_node baseW hb hnx_lt
          rcases hbkt7 b hb with ⟨h1, h2⟩
          exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
                 by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h2⟩
        · rcases hnd7 n hn with ⟨h1, h2, h3, h4, h5⟩
          have hmod3 : ∀ j : ℤ, j ≠ 3 → 0 ≤ j → j ≤ 4 → slotNodeOff R ℓ M₀ baseW n + j ≠ offNx + 3 := by
            intro j _ _ _; dsimp [offNx, slotNodeOff]; omega
          refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by simpa using hmod3 0 (by omega) (by omega) (by omega)))]; exact h1,
                  by rw [wRead_wWrite_of_ne _ _ (Or.inr (hmod3 1 (by omega) (by omega) (by omega)))]; exact h2,
                  by rw [wRead_wWrite_of_ne _ _ (Or.inr (hmod3 2 (by omega) (by omega) (by omega)))]; exact h3,
                  ?_,
                  by rw [wRead_wWrite_of_ne _ _ (Or.inr (hmod3 4 (by omega) (by omega) (by omega)))]; exact h5⟩
          dsimp only
          by_cases hn_nx : n = nx.toNat
          · subst hn_nx; rw [Function.update_self]; exact wRead_wWrite_self _ _ _ _
          · rw [Function.update_of_ne hn_nx,
              wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [offNx, slotNodeOff]; omega))]; exact h4
      · intro w hw
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hw7_scr]
        simp only [m6, m5, m4, m3, m2, m1]
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      · intro r; rw [rRead_wWrite, hr7_scr]
  · have hc_f : cValAt 0 inp m2 (.intEq (.readHeap tblW (.readHeap scrW (.lit (wScr + 1))))
        (.readHeap scrW (.lit wScr))) = false := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m2 tblW (H3a.wRead m2 scrW (wScr + 1)) = H3a.wRead m2 scrW wScr) = false
      rw [wRead_wWrite_self, wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          hnEp_nd, wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
      exact decide_eq_false (by omega)
    have hfr2_0 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m2 :=
      (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ _ _).trans
        (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m1 _ _)
    have hfr2 : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m2 :=
      hfr2_0.mono_range (Or.inl rfl) (Or.inl rfl)
    have hS_eq : S.unlinkNode nd = S := by unfold LiveSlot.unlinkNode; rw [if_neg hact]
    refine ⟨m2,
      (hd1.seq (hd2.seq (DetExecAt.ite_false (C_c := 20) (C_b := 5) hc_f
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        ((DetExecAt.skip 0 inp m2).mono_cost (by omega))))).mono_cost (by omega),
      hfp2, ?_, ?_, ?_, hfr2⟩
    · rw [hS_eq]; exact henc.mono_frame hfr2_0 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
    · intro w hw
      simp only [m2, m1]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    · intro r; simp only [m2, m1, rRead_wWrite]

def liveSlotUnlinkLocStmt (scrW tblW : ℕ)
    (wBaseW wLoc wScr : ℤ) (R ℓ M₀ cap_u : ℕ) : ArithRAMStmt :=
  let C_nd := R * cap_u
  let wSub := wScr
  let wNd := wScr + 1
  .seq (.writeWordHeap scrW (.lit wSub) (.lit 0))
    (.repeatN (.lit (C_nd : ℤ))
      (.seq (.writeWordHeap scrW (.lit wNd)
              (.add (.mul (.lit (C_nd : ℤ)) (.readHeap scrW (.lit wLoc)))
                    (.readHeap scrW (.lit wSub))))
      (.seq (liveSlotUnlinkNodeStmt scrW tblW wBaseW wNd (wScr + 2) R ℓ M₀)
            (.writeWordHeap scrW (.lit wSub)
              (.add (.readHeap scrW (.lit wSub)) (.lit 1))))))

theorem exec_liveSlotUnlinkLocStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wLoc wScr baseW baseR : ℤ)
    {R ℓ M₀ cap_u B_max loc blkStart : ℕ} (hM₀ : 1 ≤ M₀)
    (hloc : loc < B_max)
    {entryAlive : ℕ → Bool} {pSlot : PureFilterSlot R ℓ M₀ d}
    {S : LiveSlot R ℓ M₀ d}
    (hwf : S.WF cap_u B_max blkStart entryAlive pSlot)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (htblW : tblW < TW) (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 7 ≤ (BW : ℤ))
    (hdisjBW : wBaseW < wScr ∨ wScr + 7 ≤ wBaseW)
    (hdisjLoc : wLoc < wScr ∨ wScr + 7 ≤ wLoc)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hloc_r : H3a.wRead m₀ scrW wLoc = (loc : ℤ))
    (henc : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (liveSlotUnlinkLocStmt scrW tblW wBaseW wLoc wScr R ℓ M₀ cap_u)
        m₀ m₁ (50 + 400 * (R * cap_u)) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (S.unlinkLoc (R * cap_u) loc) m₁ ∧
      (∀ w, (w < wScr ∨ wScr + 7 ≤ w) → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m₁ := by
  let C_nd := R * cap_u
  rcases hwf with ⟨_, _, ndL₀, hinv₀, _⟩
  let m_init := H3a.wWrite m₀ scrW wScr 0
  have hd_init : DetExec inp (.writeWordHeap scrW (.lit wScr) (.lit 0)) m₀ m_init 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wScr) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_init : InFootprint TW BW TR BR m_init :=
    InFootprint.wWrite hfp₀ hscrW hwScr.1 (by omega)
  let SkOf : ℕ → LiveSlot R ℓ M₀ d := fun k =>
    Fin.foldl k (fun cur (sub : Fin k) => cur.unlinkNode (loc * C_nd + sub.val)) S
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    InFootprint TW BW TR BR m ∧
    H3a.wRead m scrW wScr = (k : ℤ) ∧
    EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (SkOf k) m ∧
    (∃ ndLk, LiveSlotListInv cap_u B_max blkStart ndLk (SkOf k)) ∧
    (∀ w, (w < wScr ∨ wScr + 7 ≤ w) → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
    (∀ r, H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
    RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m
  have hInv0 : Inv 0 m_init := by
    have hfr0 := RadFrameOutside.wWrite_scr scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ wScr 0
    have hSk0 : SkOf 0 = S := by dsimp [SkOf]; rw [Fin.foldl_zero]
    refine ⟨hfp_init, wRead_wWrite_self _ _ _ _, ?_, ⟨ndL₀, hSk0.symm ▸ hinv₀⟩,
      fun w hw => wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
      fun r => rRead_wWrite _ _ _ _ _ _, hfr0⟩
    rw [hSk0]
    exact henc.mono_frame (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ wScr 0)
      hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  obtain ⟨m₁, hInvN, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (C_nd : ℤ)) _ C_nd 10 400 Inv hInv0 rfl
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) (fun k hk m hIm => by
      rcases hIm with ⟨hfp_m, hsub_m, henc_m, ⟨ndLk, hinv_k⟩, hkW_m, hkR_m, hfr_m⟩
      let nd_k := loc * C_nd + k
      have hnd_lt : nd_k < B_max * (R * cap_u) := by
        calc loc * C_nd + k < loc * C_nd + C_nd := by omega
          _ = (loc + 1) * C_nd := by ring
          _ ≤ B_max * C_nd := Nat.mul_le_mul_right _ hloc
      have hloc_m : H3a.wRead m scrW wLoc = (loc : ℤ) :=
        (hkW_m wLoc hdisjLoc).trans hloc_r
      have hbW_m : H3a.wRead m scrW wBaseW = baseW :=
        (hkW_m wBaseW hdisjBW).trans hbW
      let m_nd := H3a.wWrite m scrW (wScr + 1) (nd_k : ℤ)
      have hd_nd : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
          (.add (.mul (.lit (C_nd : ℤ)) (.readHeap scrW (.lit wLoc)))
                (.readHeap scrW (.lit wScr)))) m m_nd 25 :=
        DetExecAt.writeWordHeap 0 inp m scrW (.lit (wScr + 1)) _ rfl
          (by change (C_nd : ℤ) * H3a.wRead m scrW wLoc + H3a.wRead m scrW wScr = (nd_k : ℤ)
              rw [hloc_m, hsub_m]; dsimp [nd_k]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_nd : InFootprint TW BW TR BR m_nd :=
        InFootprint.wWrite hfp_m hscrW (by omega) (by omega)
      have henc_nd : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (SkOf k) m_nd :=
        henc_m.mono_frame (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m (wScr + 1) (nd_k : ℤ))
          hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
      obtain ⟨m_u, hd_u, hfp_u, henc_u, hkW_u, hkR_u, hfr_u⟩ :=
        exec_liveSlotUnlinkNodeStmt (scrR := scrR) inp wBaseW (wScr + 1) (wScr + 2) baseW baseR hnd_lt
          hinv_k hfp_nd hscrW htblW hneW hneR hbaseW ⟨by omega, by omega⟩
          (by rcases hdisjBW with h | h <;> omega) (Or.inl (by omega))
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega))]; exact hbW_m)
          (wRead_wWrite_self _ _ _ _) henc_nd
      let m_nx := H3a.wWrite m_u scrW wScr ((k + 1 : ℕ) : ℤ)
      have hsub_u : H3a.wRead m_u scrW wScr = (k : ℤ) := by
        rw [hkW_u wScr (Or.inl (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hsub_m
      have hd_nx : DetExec inp (.writeWordHeap scrW (.lit wScr)
          (.add (.readHeap scrW (.lit wScr)) (.lit 1))) m_u m_nx 15 :=
        DetExecAt.writeWordHeap 0 inp m_u scrW (.lit wScr) _ rfl
          (by change H3a.wRead m_u scrW wScr + 1 = _; rw [hsub_u]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_nx : InFootprint TW BW TR BR m_nx :=
        InFootprint.wWrite hfp_u hscrW hwScr.1 (by omega)
      have hSk_step : SkOf (k + 1) = (SkOf k).unlinkNode nd_k := by
        dsimp [SkOf, nd_k]; rw [Fin.foldl_succ_last]; rfl
      have henc_nx : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (SkOf (k + 1)) m_nx := by
        rw [hSk_step]
        exact henc_u.mono_frame (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_u wScr ((k + 1 : ℕ) : ℤ))
          hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
      have hinv_nx : ∃ ndLk', LiveSlotListInv cap_u B_max blkStart ndLk' (SkOf (k + 1)) := by
        rw [hSk_step]
        exact ⟨_, (LiveSlot.listInv_unlinkNode hM₀ hinv_k hnd_lt).1⟩
      refine ⟨m_nx, (hd_nd.seq (hd_u.seq hd_nx)).mono_cost (by omega),
        hfp_nx, wRead_wWrite_self _ _ _ _, henc_nx, hinv_nx, ?_, ?_, ?_⟩
      · intro w hw
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW_u w (by omega),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hkW_m w hw
      · intro r
        rw [rRead_wWrite, hkR_u r, rRead_wWrite]
        exact hkR_m r
      · exact ((hfr_m.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m _ _)).trans hfr_u).trans
          (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_u _ _))
  rcases hInvN with ⟨hfp₁, _, henc₁, _, hkW₁, hkR₁, hfr₁⟩
  exact ⟨m₁, (hd_init.seq hd_loop).mono_cost (by omega), hfp₁, henc₁, hkW₁, hkR₁, hfr₁⟩

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
