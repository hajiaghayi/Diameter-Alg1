import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG15_Stage2A
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2C0
import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInst
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_FinalD
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG15_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
open UL.Proof.clm_9_1_explicit_tradeoff.CG15
open UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage2
open UL.Proof.clm_9_1_explicit_tradeoff.CG18
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG20
open UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge

/-! ### 1. Pure Bridge Equating `s2OuterStateAt` + `leafFinishStage2Pure` to `stepStage2` -/

theorem stepStage2_eq_match {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp) :
    stepStage2 cp st ω₂ =
      match (List.finRange cp.D_max).findSome? (s2CommitAt cp st ω₂) with
      | some (r₀, newSuf, newLeaf, newOv) =>
          { st with
            serving := st.serving.take r₀.val ++ newSuf
            jobs := fun r =>
              if r.val < r₀.val then
                match s2OutJob cp st ω₂ r with
                | some (Sum.inl jb') => some jb'
                | _ => none
              else none
            leafArr := newLeaf
            leafOverflow := newOv }
      | none =>
          leafFinishStage2Pure cp st
            (fun r =>
              match s2OutJob cp st ω₂ r with
              | some (Sum.inl jb') => some jb'
              | _ => none)
            ω₂ := rfl

theorem stepStage2_eq_of_commit_some {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp)
    {r₀ : Fin cp.D_max} {newSuf : List (MNode cp)} {newLeaf : List ℕ} {newOv : Bool}
    (hfc : (List.finRange cp.D_max).findSome? (s2CommitAt cp st ω₂) =
      some (r₀, newSuf, newLeaf, newOv)) :
    s2OuterStateAt cp st ω₂ cp.D_max = stepStage2 cp st ω₂ := by
  have htake : (List.finRange cp.D_max).take cp.D_max = List.finRange cp.D_max := by simp
  unfold s2OuterStateAt
  rw [htake, stepStage2_eq_match, hfc]
  dsimp only
  congr 1
  funext r
  unfold s2JobsAfterCommit
  by_cases hlt : r.val < r₀.val
  · simp only [hlt, ite_true]
    cases s2OutJob cp st ω₂ r with
    | none => rfl
    | some s => cases s <;> rfl
  · simp [hlt, r.isLt]

theorem s2JobsNoCommit_at_Dmax {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp) :
    s2JobsNoCommit cp st ω₂ cp.D_max =
      fun r =>
        match s2OutJob cp st ω₂ r with
        | some (Sum.inl jb') => some jb'
        | _ => none := by
  funext r
  unfold s2JobsNoCommit
  simp only [r.isLt, ite_true]
  cases s2OutJob cp st ω₂ r with
  | none => rfl
  | some s => cases s <;> rfl

theorem stepStage2_eq_of_commit_none {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp)
    (hfc : (List.finRange cp.D_max).findSome? (s2CommitAt cp st ω₂) = none) :
    s2OuterStateAt cp st ω₂ cp.D_max =
      { st with jobs := s2JobsNoCommit cp st ω₂ cp.D_max } ∧
    leafFinishStage2Pure cp st (s2JobsNoCommit cp st ω₂ cp.D_max) ω₂ =
      stepStage2 cp st ω₂ := by
  have htake : (List.finRange cp.D_max).take cp.D_max = List.finRange cp.D_max := by simp
  refine ⟨?_, ?_⟩
  · unfold s2OuterStateAt
    rw [htake, hfc]
  · rw [stepStage2_eq_match, hfc, s2JobsNoCommit_at_Dmax]

/-! ### 2. Full Stage-2 Deterministic RAM Program (`stepStage2Stmt`) & `exec_stepStage2Stmt` -/

def stepStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (outerJobLoopStmt ops)
    (.ite (.intEq (.readHeap engScrTbl (.lit 0)) (.lit 0))
      (leafSpawnStage2Stmt ops)
      .skip)

theorem zeroRand_stepStage2Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (stepStage2Stmt ops) :=
  .seq (zeroRand_outerJobLoopStmt ops)
    (.ite (zeroRand_leafSpawnStage2Stmt ops) .skip)

def C_stage2 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  outerJobLoopCost ops + 16 + leafSpawnStage2Cost ops

theorem exec_stepStage2Stmt
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    {d : ℕ} (hd : 1 ≤ d) {params : LocalScaleParams} (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1)
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d)
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp}
    {bits : Fin cp.B_STEP → Bool} {m₁ : ArithRAMMemory}
    (hP' : P'.WellFormed cp.n)
    (hwf₁ : PostStage1WF cp P' st₁)
    (hfp₁ : InFootprint ops.TW ops.BW ops.TR ops.BR m₁)
    (henc₁ : EncChainEngine ops st₁ m₁)
    (hcoins₁ : MemHasStepCoins cp bits m₁) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let st₂ := stepStage2 cp st₁ ω₂
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (stepStage2Stmt ops) m₁
      (fun m₂ =>
        EncChainEngine ops st₂ m₂ ∧
        MemHasStepCoins cp bits m₂ ∧
        wRead m₂ 0 0 = wRead m₁ 0 0)
      (C_stage2 ops) := by
  intro ω₂ st₂
  unfold stepStage2Stmt C_stage2
  refine ExecDet.seq' (16 + leafSpawnStage2Cost ops)
    (exec_outerJobLoopStmt h_lem_5_1 h_clm_7_3 hd he1 hh0 hh1 ops inp hP' hwf₁ hfp₁ henc₁ hcoins₁)
    (by omega) ?_
  intro mMid ⟨hencMid, hscr0, hcoinsMid, hw00Mid⟩ hfpMid
  cases hfc : (List.finRange cp.D_max).findSome? (s2CommitAt cp st₁ ω₂) with
  | none =>
      rw [hfc] at hscr0
      have hcondT : (evalArithCond inp 0 mMid
          (.intEq (.readHeap engScrTbl (.lit 0)) (.lit 0))).1 = true := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mMid engScrTbl 0 = 0) = true
        rw [hscr0]; simp
      rcases stepStage2_eq_of_commit_none cp st₁ ω₂ hfc with ⟨hout_eq, hleaf_eq⟩
      rw [hout_eq] at hencMid
      refine ExecDet.ite' (C_c := 8) (C_b := leafSpawnStage2Cost ops) _ _ _ hcondT
        (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf) (by omega)
      refine (exec_leafSpawnStage2Stmt h_clm_7_3 hd he1 hh0 hh1 ops inp hP' hwf₁
        hfpMid hencMid hcoinsMid).mono ?_ le_rfl
      intro m₂ ⟨henc₂, hcoins₂, hw00_₂⟩ _
      rw [hleaf_eq] at henc₂
      exact ⟨henc₂, hcoins₂, hw00_₂.trans hw00Mid⟩
  | some quad =>
      rcases quad with ⟨r₀, newSuf, newLeaf, newOv⟩
      rw [hfc] at hscr0
      have hcondF : (evalArithCond inp 0 mMid
          (.intEq (.readHeap engScrTbl (.lit 0)) (.lit 0))).1 = false := by
        simp only [evalArithCond, evalIntExpr]
        change decide (wRead mMid engScrTbl 0 = 0) = false
        rw [hscr0]; simp
      have hout_eq := stepStage2_eq_of_commit_some cp st₁ ω₂ hfc
      rw [hout_eq] at hencMid
      refine ExecDet.ite' (C_c := 8) (C_b := 1) _ _ _ hcondF
        (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
        (by unfold leafSpawnStage2Cost; omega)
      exact ExecDet.skip inp hfpMid ⟨hencMid, hcoinsMid, hw00Mid⟩ le_rfl

/-- Generic `CG20.Stage2RAMOnly` constructor for any `ops : NodeAndHPJRAMOps cp`. -/
def mkStage2RAMOnly
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    {d : ℕ} (hd : 1 ≤ d) {params : LocalScaleParams} (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1)
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    Stage2RAMOnly ops where
  s2 := stepStage2Stmt ops
  C2 := C_stage2 ops
  hzr2 := zeroRand_stepStage2Stmt ops
  exec2 := fun inp {_P'} {_st₁} {_bits} {_m₁} hP' hwf₁ hfp₁ henc₁ hcoins₁ =>
    exec_stepStage2Stmt h_lem_5_1 h_clm_7_3 hd he1 hh0 hh1 ops inp hP' hwf₁ hfp₁ henc₁ hcoins₁

/-! ### 3. Polynomial Cost Bound `(C_s2, k_s2)` & Concrete `CG18.nodeAndHPJRAMOps` Closure -/

theorem C_stage2_le_outer_shape {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    C_stage2 ops ≤
      2000 + allocFreshSlotCost cp + 4 * ops.C_read + ops.C_hpj + ops.C_open +
        (cp.B_scan + 1) * (ops.C_ins + 2 * ops.C_read + 400) +
        cp.D_max * (tickRebuildJobCost ops + 2000 + 4 * ops.C_read +
          cp.B_scan * (2 * ops.C_read + 400) + cp.D_max * 200 +
          allocFreshSlotCost cp + ops.C_hpj + ops.C_open) := by
  have hstep : outerJobStepCost ops ≤
      tickRebuildJobCost ops + 2000 + 4 * ops.C_read +
        cp.B_scan * (2 * ops.C_read + 400) + cp.D_max * 200 +
        allocFreshSlotCost cp + ops.C_hpj + ops.C_open := by
    unfold outerJobStepCost commitJobStage2Cost
    have hb : cp.B_scan * (ops.C_read + 130) ≤ cp.B_scan * (2 * ops.C_read + 400) :=
      Nat.mul_le_mul_left _ (by omega)
    have hd : cp.D_max * 30 ≤ cp.D_max * 200 :=
      Nat.mul_le_mul_left _ (by decide)
    linarith
  have hdloop : cp.D_max * outerJobStepCost ops ≤
      cp.D_max * (tickRebuildJobCost ops + 2000 + 4 * ops.C_read +
        cp.B_scan * (2 * ops.C_read + 400) + cp.D_max * 200 +
        allocFreshSlotCost cp + ops.C_hpj + ops.C_open) :=
    Nat.mul_le_mul_left cp.D_max hstep
  have hB : (cp.B_scan + 1) * (ops.C_ins + 40) + cp.B_scan * (ops.C_read + 120) ≤
      (cp.B_scan + 1) * (ops.C_ins + 2 * ops.C_read + 400) := by
    calc (cp.B_scan + 1) * (ops.C_ins + 40) + cp.B_scan * (ops.C_read + 120)
        ≤ (cp.B_scan + 1) * (ops.C_ins + 40) + (cp.B_scan + 1) * (ops.C_read + 120) :=
          Nat.add_le_add_left (Nat.mul_le_mul_right _ (Nat.le_succ _)) _
      _ = (cp.B_scan + 1) * ((ops.C_ins + 40) + (ops.C_read + 120)) :=
          (Nat.left_distrib _ _ _).symm
      _ ≤ (cp.B_scan + 1) * (ops.C_ins + 2 * ops.C_read + 400) :=
          Nat.mul_le_mul_left _ (by omega)
  unfold C_stage2 outerJobLoopCost leafSpawnStage2Cost leafAllocAndBuildCost
  linarith

theorem C_stage2_le_master {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    {C_op k_op : ℕ} (hCop : 1 ≤ C_op)
    (ops : NodeAndHPJRAMOps inst.cp)
    (hopen : ops.C_open ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hins : ops.C_ins ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hhpj : ops.C_hpj ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hread : ops.C_read ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp) :
    C_stage2 ops ≤
      (15000 * C_op) * (masterPolyParamNat inst) ^ (k_op + 3) * masterWorkFactorNat inst.cp :=
  C_stage2_outer_le_master inst hCop ops hopen hins hhpj hread (C_stage2_le_outer_shape ops)

/-- Universal polynomial constant `C_s2` for Stage 2 on `CG18.nodeAndHPJRAMOps inst.cp`. -/
noncomputable def C_s2_concrete : ℕ := 15000 * C_node_work

/-- Universal polynomial exponent `k_s2 = 16` for Stage 2 on `CG18.nodeAndHPJRAMOps inst.cp`. -/
def k_s2_concrete : ℕ := 16

/-- Concrete `CG20.Stage2RAMOnly` instantiation on `CG18.nodeAndHPJRAMOps inst.cp`. -/
noncomputable def stage2RAMOnly_concrete
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    {c σ : ℝ} {csp : CurveStaticParams c σ} {d n t : ℕ} {δ : ℝ}
    (hd : 1 ≤ d) (inst : ConcreteChainInst csp d n t δ) :
    Stage2RAMOnly (nodeAndHPJRAMOps inst.cp) :=
  mkStage2RAMOnly h_lem_5_1 h_clm_7_3 hd inst.he1 inst.hh0 inst.hh1 (nodeAndHPJRAMOps inst.cp)

theorem stage2RAMOnly_concrete_cost_le
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    {c σ : ℝ} {csp : CurveStaticParams c σ} {d n t : ℕ} {δ : ℝ}
    (hd : 1 ≤ d) (inst : ConcreteChainInst csp d n t δ) :
    (stage2RAMOnly_concrete h_lem_5_1 h_clm_7_3 hd inst).C2 ≤
      C_s2_concrete * (masterPolyParamNat inst) ^ k_s2_concrete * masterWorkFactorNat inst.cp := by
  have hCW1 : 1 ≤ C_node_work := by unfold C_node_work; omega
  obtain ⟨hOpen, hIns, _, _, _, hHpj, hRead, _⟩ := nodeAndHPJRAMOps_master_bounds inst
  exact C_stage2_le_master inst hCW1 (nodeAndHPJRAMOps inst.cp) hOpen hIns hHpj hRead

/-- Exact `mkStage2` witness expected by `CG20.prove_clm_9_1_from_stage2`! -/
theorem exists_stage2RAMOnly_concrete
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    {c σ : ℝ} {csp : CurveStaticParams c σ} {d n t : ℕ} {δ : ℝ}
    (hd : 1 ≤ d) (_hn : 2 ≤ n) (_ht : 1 ≤ t) (_hδ0 : 0 < δ) (_hδ1 : δ < 1 / 2)
    (inst : ConcreteChainInst csp d n t δ) :
    Nonempty { s2 : Stage2RAMOnly (nodeAndHPJRAMOps inst.cp) //
      s2.C2 ≤ C_s2_concrete * (masterPolyParamNat inst) ^ k_s2_concrete *
        masterWorkFactorNat inst.cp } :=
  ⟨⟨stage2RAMOnly_concrete h_lem_5_1 h_clm_7_3 hd inst,
    stage2RAMOnly_concrete_cost_le h_lem_5_1 h_clm_7_3 hd inst⟩⟩

/-- Turnkey end-to-end proof of `S_clm_9_1_explicit_tradeoff` closing Stage 2 via
`CG20.prove_clm_9_1_from_stage2`! -/
theorem prove_clm_9_1_explicit_tradeoff_complete
    (h_lem_5_1 : S_lem_5_1)
    (h_clm_5_1_mc_baseline : S_clm_5_1_mc_baseline)
    (h_lem_6_2 : S_lem_6_2)
    (h_clm_6_1_adaptive : S_clm_6_1_adaptive)
    (h_clm_6_1_precision : S_clm_6_1_precision)
    (h_clm_7_3_global_approx : S_clm_7_3_global_approx)
    (h_lem_9_1 : S_lem_9_1) :
    S_clm_9_1_explicit_tradeoff :=
  prove_clm_9_1_from_stage2
    h_lem_5_1 h_clm_5_1_mc_baseline h_lem_6_2
    h_clm_6_1_adaptive h_clm_6_1_precision h_clm_7_3_global_approx h_lem_9_1
    C_s2_concrete k_s2_concrete
    (fun hd hn ht hδ0 hδ1 inst =>
      exists_stage2RAMOnly_concrete h_lem_5_1 h_clm_7_3_global_approx hd hn ht hδ0 hδ1 inst)

end UL.Proof.clm_9_1_explicit_tradeoff.CG15_Stage2
