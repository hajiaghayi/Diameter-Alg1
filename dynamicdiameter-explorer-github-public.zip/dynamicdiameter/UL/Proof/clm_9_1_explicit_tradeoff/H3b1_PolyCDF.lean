import Mathlib
import UL.Stmt.clm_6_1_precision
import UL.Proof.cit_hpj19_thm18.H0
import UL.Proof.lem_6_3.H5_Prob
import UL.Proof.lem_6_3.RacerV30_H2
import UL.Proof.clm_6_1_precision.RaceV30_H1
import UL.Proof.clm_6_1_precision.RaceV30_H2
import UL.Proof.clm_6_1_precision.RaceV30_H3
import UL.Proof.clm_6_1_precision.RaceV30_H4
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H3b1

open MeasureTheory ProbabilityTheory
open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof_clm_6_1_precision_RaceV30

/-! ### 1. MSB-first binary decoding equivalence `(Fin b → Bool) ≃ Fin (2 ^ b)` -/

theorem bitsFnToNat_injective : ∀ (q : ℕ), Function.Injective (bitsFnToNat q)
  | 0, f₁, f₂, _ => by ext i; exact Fin.elim0 i
  | q + 1, f₁, f₂, h => by
      simp only [bitsFnToNat] at h
      have hlast : f₁ (Fin.last q) = f₂ (Fin.last q) := by
        cases h₁ : f₁ (Fin.last q) <;> cases h₂ : f₂ (Fin.last q)
        · rfl
        · rw [h₁, h₂] at h; simp at h; omega
        · rw [h₁, h₂] at h; simp at h; omega
        · rfl
      have hinit_nat :
          bitsFnToNat q (fun i => f₁ i.castSucc) = bitsFnToNat q (fun i => f₂ i.castSucc) := by
        rw [hlast] at h; split_ifs at h <;> omega
      have hinit := bitsFnToNat_injective q hinit_nat
      ext i
      refine Fin.lastCases hlast (fun j => ?_) i
      exact congrFun hinit j

theorem bitsFnToFin_injective (q : ℕ) : Function.Injective (bitsFnToFin q) := by
  intro f₁ f₂ h
  exact bitsFnToNat_injective q (congrArg Fin.val h)

noncomputable def bitsFnToFinEquiv (q : ℕ) : (Fin q → Bool) ≃ Fin (2 ^ q) :=
  Equiv.ofBijective (bitsFnToFin q)
    ((Fintype.bijective_iff_injective_and_card (bitsFnToFin q)).mpr
      ⟨bitsFnToFin_injective q, by simp⟩)

@[simp]
theorem bitsFnToFinEquiv_apply (q : ℕ) (f : Fin q → Bool) :
    bitsFnToFinEquiv q f = bitsFnToFin q f := rfl

/-! ### 2. Alternating polynomial approximation to `Real.exp (-t)` and `stdNormalCDF` -/

noncomputable def expAltPoly (K : ℕ) (t : ℝ) : ℝ :=
  ∑ m ∈ Finset.range K, (-t) ^ m / (m.factorial : ℝ)

private lemma pow_div_factorial_le_exp {x : ℝ} (hx : 0 ≤ x) (k : ℕ) :
    x ^ k / (k.factorial : ℝ) ≤ Real.exp x := by
  have hsum := Real.sum_le_exp_of_nonneg hx (k + 1)
  have hmem : k ∈ Finset.range (k + 1) := Finset.mem_range.mpr (Nat.lt_succ_self k)
  exact (Finset.single_le_sum (fun i _ => by positivity) hmem).trans hsum

private lemma hasDerivAt_neg_pow_div_fac (m : ℕ) (hm : 1 ≤ m) (s : ℝ) :
    HasDerivAt (fun x : ℝ => (-x) ^ m / (m.factorial : ℝ))
      (-((-s) ^ (m - 1) / ((m - 1).factorial : ℝ))) s := by
  obtain ⟨k, rfl⟩ : ∃ k, m = k + 1 := Nat.exists_eq_succ_of_ne_zero (by omega)
  simp only [Nat.add_sub_cancel]
  have h1 : HasDerivAt (fun x : ℝ => -x) (-1) s := (hasDerivAt_id s).neg
  have h2 : HasDerivAt (fun x : ℝ => (-x) ^ (k + 1))
      (((k + 1 : ℕ) : ℝ) * (-s) ^ k * (-1)) s := h1.pow (k + 1)
  have h3 := h2.div_const ((k + 1).factorial : ℝ)
  refine h3.congr_deriv ?_
  rw [Nat.factorial_succ, Nat.cast_mul]
  have hkp : (((k + 1 : ℕ) : ℝ)) ≠ 0 := by positivity
  have hkf : (k.factorial : ℝ) ≠ 0 := by positivity
  field_simp [hkp, hkf]

private lemma hasDerivAt_exp_mul_expAltPoly :
    ∀ (K : ℕ), 1 ≤ K → ∀ (s : ℝ),
      HasDerivAt (fun x : ℝ => Real.exp x * expAltPoly K x)
        (Real.exp s * ((-s) ^ (K - 1) / ((K - 1).factorial : ℝ))) s
  | 0, hK, _ => absurd hK (by omega)
  | 1, _, s => by
      have heq : (fun x : ℝ => Real.exp x * expAltPoly 1 x) = Real.exp := by
        ext x; simp [expAltPoly]
      rw [heq]
      simpa using Real.hasDerivAt_exp s
  | K + 2, _, s => by
      have ih := hasDerivAt_exp_mul_expAltPoly (K + 1) (by omega) s
      have hsplit : (fun x : ℝ => Real.exp x * expAltPoly (K + 2) x) =
          (fun x : ℝ => Real.exp x * expAltPoly (K + 1) x +
            Real.exp x * ((-x) ^ (K + 1) / ((K + 1).factorial : ℝ))) := by
        ext x
        simp only [expAltPoly, Finset.sum_range_succ]
        ring
      rw [hsplit]
      have hterm : HasDerivAt (fun x : ℝ => Real.exp x * ((-x) ^ (K + 1) / ((K + 1).factorial : ℝ)))
          (Real.exp s * ((-s) ^ (K + 1) / ((K + 1).factorial : ℝ)) +
            Real.exp s * (-((-s) ^ K / (K.factorial : ℝ)))) s :=
        (Real.hasDerivAt_exp s).mul (hasDerivAt_neg_pow_div_fac (K + 1) (by omega) s)
      exact (ih.add hterm).congr_deriv (by simp)

theorem expAltPoly_approx_exp_neg {K : ℕ} (hK : 1 ≤ K) {t : ℝ} (ht : 0 ≤ t) :
    |expAltPoly K t - Real.exp (-t)| ≤ t ^ K / ((K - 1).factorial : ℝ) := by
  let F : ℝ → ℝ := fun x => Real.exp x * expAltPoly K x
  let dF : ℝ → ℝ := fun x => Real.exp x * ((-x) ^ (K - 1) / ((K - 1).factorial : ℝ))
  have hF0 : F 0 = 1 := by
    obtain ⟨k, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : K ≠ 0)
    simp [F, expAltPoly, Finset.sum_range_succ']
  have hdF_cont : Continuous dF := by
    dsimp [dF]; continuity
  have hFTC : ∫ s in (0 : ℝ)..t, dF s = F t - F 0 :=
    intervalIntegral.integral_eq_sub_of_hasDerivAt
      (fun s _ => hasDerivAt_exp_mul_expAltPoly K hK s)
      (hdF_cont.intervalIntegrable 0 t)
  have hbound_dF : ∀ s ∈ Set.Icc (0 : ℝ) t,
      ‖dF s‖ ≤ Real.exp t * (t ^ (K - 1) / ((K - 1).factorial : ℝ)) := by
    intro s ⟨hs0, hst⟩
    dsimp [dF]
    have hfac_pos : (0 : ℝ) < ((K - 1).factorial : ℝ) := by positivity
    simp only [Real.norm_eq_abs, abs_mul, abs_of_pos (Real.exp_pos s), abs_div,
      abs_pow, abs_neg, abs_of_nonneg hs0, abs_of_pos hfac_pos]
    have hexp_le : Real.exp s ≤ Real.exp t := Real.exp_le_exp.mpr hst
    have hpow_le : s ^ (K - 1) ≤ t ^ (K - 1) := pow_le_pow_left₀ hs0 hst (K - 1)
    have hdiv_le : s ^ (K - 1) / ((K - 1).factorial : ℝ) ≤ t ^ (K - 1) / ((K - 1).factorial : ℝ) :=
      div_le_div_of_nonneg_right hpow_le (by positivity)
    exact mul_le_mul hexp_le hdiv_le (by positivity) (Real.exp_pos t).le
  have hint_norm : ‖∫ s in (0 : ℝ)..t, dF s‖ ≤
      Real.exp t * (t ^ (K - 1) / ((K - 1).factorial : ℝ)) * |t - 0| :=
    intervalIntegral.norm_integral_le_of_norm_le_const
      (fun s hs => hbound_dF s (Set.Ioc_subset_Icc_self (by rwa [Set.uIoc_of_le ht] at hs)))
  rw [hFTC, hF0, Real.norm_eq_abs, sub_zero, abs_of_nonneg ht] at hint_norm
  have hmul := mul_le_mul_of_nonneg_left hint_norm (Real.exp_pos (-t)).le
  have h1 : Real.exp (-t) * |F t - 1| = |expAltPoly K t - Real.exp (-t)| := by
    have heq : Real.exp (-t) * (F t - 1) = expAltPoly K t - Real.exp (-t) := by
      dsimp [F]
      calc Real.exp (-t) * (Real.exp t * expAltPoly K t - 1)
          = (Real.exp (-t) * Real.exp t) * expAltPoly K t - Real.exp (-t) := by ring
        _ = 1 * expAltPoly K t - Real.exp (-t) := by
            rw [← Real.exp_add, neg_add_cancel, Real.exp_zero]
        _ = expAltPoly K t - Real.exp (-t) := by rw [one_mul]
    conv_lhs => rw [← abs_of_pos (Real.exp_pos (-t)), ← abs_mul, heq]
  have h2 : Real.exp (-t) * (Real.exp t * (t ^ (K - 1) / ((K - 1).factorial : ℝ)) * t) =
      t ^ K / ((K - 1).factorial : ℝ) := by
    have hexp_c : Real.exp (-t) * Real.exp t = 1 := by
      rw [← Real.exp_add, neg_add_cancel, Real.exp_zero]
    have hpow_k : t ^ (K - 1) * t = t ^ K := by
      obtain ⟨k, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : K ≠ 0)
      simp [pow_succ]
    calc Real.exp (-t) * (Real.exp t * (t ^ (K - 1) / ((K - 1).factorial : ℝ)) * t)
        = (Real.exp (-t) * Real.exp t) * ((t ^ (K - 1) * t) / ((K - 1).factorial : ℝ)) := by ring
      _ = t ^ K / ((K - 1).factorial : ℝ) := by rw [hexp_c, one_mul, hpow_k]
  rwa [h1, h2] at hmul

/-- Exact term-by-term antiderivative of `u ↦ expAltPoly K (u^2 / 2)`. -/
noncomputable def gaussIntPoly (K : ℕ) (x : ℝ) : ℝ :=
  ∑ m ∈ Finset.range K,
    ((- (1 / 2 : ℝ)) ^ m / (((m.factorial * (2 * m + 1) : ℕ) : ℝ))) * x ^ (2 * m + 1)

theorem gaussIntPoly_zero (K : ℕ) : gaussIntPoly K 0 = 0 := by
  unfold gaussIntPoly
  refine Finset.sum_eq_zero fun m _ => ?_
  simp [zero_pow (by omega : 2 * m + 1 ≠ 0)]

private lemma hasDerivAt_gaussIntPoly (K : ℕ) (u : ℝ) :
    HasDerivAt (gaussIntPoly K) (expAltPoly K (u ^ 2 / 2)) u := by
  unfold expAltPoly
  have hfn : (∑ m ∈ Finset.range K, fun x : ℝ =>
      ((- (1 / 2 : ℝ)) ^ m / (((m.factorial * (2 * m + 1) : ℕ) : ℝ))) * x ^ (2 * m + 1)) =
      gaussIntPoly K := by
    ext x; simp [gaussIntPoly]
  rw [← hfn]
  have hterm : ∀ m ∈ Finset.range K,
      HasDerivAt (fun x : ℝ =>
        ((- (1 / 2 : ℝ)) ^ m / (((m.factorial * (2 * m + 1) : ℕ) : ℝ))) * x ^ (2 * m + 1))
        ((-(u ^ 2 / 2)) ^ m / (m.factorial : ℝ)) u := by
    intro m _
    have hp : HasDerivAt (fun x : ℝ => x ^ (2 * m + 1))
        (((2 * m + 1 : ℕ) : ℝ) * u ^ (2 * m)) u := by
      simpa using (hasDerivAt_id u).pow (2 * m + 1)
    refine (hp.const_mul _).congr_deriv ?_
    push_cast
    have hmf : (m.factorial : ℝ) ≠ 0 := by positivity
    have h2m : (2 * (m : ℝ) + 1) ≠ 0 := by positivity
    have hu_pow : (-(u ^ 2 / 2)) ^ m = (-(1 / 2 : ℝ)) ^ m * u ^ (2 * m) := by
      have : -(u ^ 2 / 2) = (-(1 / 2 : ℝ)) * (u ^ 2) := by ring
      rw [this, mul_pow, ← pow_mul]
    rw [hu_pow]
    field_simp [hmf, h2m]
  exact HasDerivAt.sum hterm

theorem gaussIntPoly_approx_integral {K : ℕ} (hK : 1 ≤ K) {x : ℝ} (hx : 0 ≤ x) :
    |gaussIntPoly K x - ∫ u in Set.Ioc 0 x, Real.exp (-(u ^ 2 / 2))| ≤
      x * ((x ^ 2 / 2) ^ K / ((K - 1).factorial : ℝ)) := by
  have hcont_p : Continuous (fun u : ℝ => expAltPoly K (u ^ 2 / 2)) := by
    unfold expAltPoly; continuity
  have hFTC : ∫ u in (0 : ℝ)..x, expAltPoly K (u ^ 2 / 2) = gaussIntPoly K x := by
    rw [intervalIntegral.integral_eq_sub_of_hasDerivAt
      (fun u _ => hasDerivAt_gaussIntPoly K u)
      (hcont_p.intervalIntegrable 0 x), gaussIntPoly_zero, sub_zero]
  have hcont_e : Continuous (fun u : ℝ => Real.exp (-(u ^ 2 / 2))) := by continuity
  rw [← intervalIntegral.integral_of_le hx, ← hFTC,
    ← intervalIntegral.integral_sub (hcont_p.intervalIntegrable 0 x) (hcont_e.intervalIntegrable 0 x),
    ← Real.norm_eq_abs]
  let C_err : ℝ := (x ^ 2 / 2) ^ K / ((K - 1).factorial : ℝ)
  have hpt : ∀ u ∈ Set.uIoc (0 : ℝ) x,
      ‖expAltPoly K (u ^ 2 / 2) - Real.exp (-(u ^ 2 / 2))‖ ≤ C_err := by
    intro u hu
    rw [Set.uIoc_of_le hx] at hu
    rcases hu with ⟨hu0, hux⟩
    rw [Real.norm_eq_abs]
    refine (expAltPoly_approx_exp_neg hK (by positivity)).trans ?_
    dsimp [C_err]
    refine div_le_div_of_nonneg_right ?_ (by positivity)
    refine pow_le_pow_left₀ (by positivity) ?_ K
    exact div_le_div_of_nonneg_right (pow_le_pow_left₀ hu0.le hux 2) (by norm_num)
  have hle := intervalIntegral.norm_integral_le_of_norm_le_const hpt
  rw [sub_zero, abs_of_nonneg hx, mul_comm] at hle
  exact hle

/-! ### 3. Symmetry of `stdNormalCDF` and full `polyCDF` error bound on `[-(T + 1), T + 1]` -/

private lemma stdNormal_singleton_zero_meas (x : ℝ) :
    (gaussianReal 0 1).real {x} = 0 := by
  apply le_antisymm _ MeasureTheory.measureReal_nonneg
  by_contra hgt
  push_neg at hgt
  let ε := (gaussianReal 0 1).real {x} / 2
  have hε : 0 < ε := half_pos hgt
  have hsub : ({x} : Set ℝ) ⊆ Set.Ioc (x - ε) x := by
    intro y hy; rw [Set.mem_singleton_iff.mp hy]; exact ⟨by linarith, le_rfl⟩
  have hmono : (gaussianReal 0 1).real {x} ≤ (gaussianReal 0 1).real (Set.Ioc (x - ε) x) :=
    MeasureTheory.measureReal_mono hsub
  have hle := hmono.trans (stdNormal_Ioc_le_sub (by linarith : x - ε ≤ x))
  dsimp [ε] at hle
  linarith

theorem stdNormalCDF_neg (x : ℝ) : stdNormalCDF (-x) = 1 - stdNormalCDF x := by
  let μ : Measure ℝ := gaussianReal 0 1
  have hcompl : μ.real (Set.Iic x)ᶜ = 1 - μ.real (Set.Iic x) :=
    UL.Proof_lem_6_3.probReal_compl_eq μ measurableSet_Iic
  rw [Set.compl_Iic] at hcompl
  have hmap : μ.real (Set.Iic (-x)) = μ.real (Set.Ici x) := by
    dsimp [μ]
    conv_lhs => rw [← stdNormal_map_neg]
    simp only [MeasureTheory.measureReal_def]
    rw [Measure.map_apply measurable_neg measurableSet_Iic]
    congr 2
    ext y; simp [le_neg]
  have hunion : Set.Ici x = {x} ∪ Set.Ioi x := by ext y; simp [le_iff_eq_or_lt, eq_comm]
  have hdisj : Disjoint ({x} : Set ℝ) (Set.Ioi x) := by simp
  have hadd : μ.real (Set.Ici x) = μ.real {x} + μ.real (Set.Ioi x) := by
    rw [hunion]
    simp only [MeasureTheory.measureReal_def]
    rw [measure_union hdisj measurableSet_Ioi,
      ENNReal.toReal_add (measure_ne_top _ _) (measure_ne_top _ _)]
  unfold stdNormalCDF
  rw [hmap, hadd, stdNormal_singleton_zero_meas x, zero_add, hcompl]

theorem stdNormalCDF_zero : stdNormalCDF 0 = 1 / 2 := by
  have h := stdNormalCDF_neg 0
  rw [neg_zero] at h
  linarith

theorem stdNormalCDF_pos_eq {x : ℝ} (hx : 0 ≤ x) :
    stdNormalCDF x = 1 / 2 + (Real.sqrt (2 * Real.pi))⁻¹ * ∫ u in Set.Ioc 0 x, Real.exp (-(u ^ 2 / 2)) := by
  have hsub := stdNormalCDF_sub_eq_Ioc hx
  rw [stdNormalCDF_zero] at hsub
  have hint : (gaussianReal 0 1).real (Set.Ioc 0 x) =
      (Real.sqrt (2 * Real.pi))⁻¹ * ∫ u in Set.Ioc 0 x, Real.exp (-(u ^ 2 / 2)) := by
    rw [MeasureTheory.measureReal_def, gaussianReal_apply_eq_integral 0 one_ne_zero (Set.Ioc 0 x),
      ENNReal.toReal_ofReal (integral_nonneg fun u => gaussianPDFReal_nonneg 0 1 u)]
    have hpdf : ∀ u : ℝ, gaussianPDFReal 0 1 u = (Real.sqrt (2 * Real.pi))⁻¹ * Real.exp (-(u ^ 2 / 2)) := by
      intro u; unfold gaussianPDFReal; simp [neg_div]
    simp_rw [hpdf, MeasureTheory.integral_const_mul]
  linarith

noncomputable def cPiRat (M_pi : ℕ) : ℚ :=
  (⌊(Real.sqrt (2 * Real.pi))⁻¹ * ((2 ^ M_pi : ℕ) : ℝ)⌋ : ℚ) / ((2 ^ M_pi : ℕ) : ℚ)

theorem cPiRat_bounds (M_pi : ℕ) :
    0 ≤ cPiRat M_pi ∧ cPiRat M_pi ≤ 1 ∧
    |((cPiRat M_pi : ℚ) : ℝ) - (Real.sqrt (2 * Real.pi))⁻¹| ≤ (2 : ℝ) ^ (-(M_pi : ℤ)) := by
  let P2 : ℝ := ((2 ^ M_pi : ℕ) : ℝ)
  have hP2_pos : 0 < P2 := by positivity
  let c_true : ℝ := (Real.sqrt (2 * Real.pi))⁻¹
  have hc1 : c_true ≤ 1 := inv_le_one_of_one_le₀ (by linarith [two_le_sqrt_two_pi])
  have hf_le : ((⌊c_true * P2⌋ : ℤ) : ℝ) ≤ c_true * P2 := Int.floor_le _
  have hf_gt : c_true * P2 - 1 < ((⌊c_true * P2⌋ : ℤ) : ℝ) := Int.sub_one_lt_floor _
  have hf_nn : (0 : ℤ) ≤ ⌊c_true * P2⌋ := Int.floor_nonneg.mpr (by positivity)
  have hf_hi : ⌊c_true * P2⌋ ≤ (2 ^ M_pi : ℤ) := by
    have hle : c_true * P2 ≤ (((2 ^ M_pi : ℤ) : ℝ)) := by
      have : c_true * P2 ≤ 1 * P2 := mul_le_mul_of_nonneg_right hc1 hP2_pos.le
      dsimp [P2] at this ⊢
      push_cast at this ⊢
      linarith
    have hfl := Int.floor_mono hle
    rwa [Int.floor_intCast] at hfl
  have hcast : ((cPiRat M_pi : ℚ) : ℝ) = ((⌊c_true * P2⌋ : ℤ) : ℝ) / P2 := by
    dsimp [cPiRat, c_true, P2]; push_cast; rfl
  refine ⟨?_, ?_, ?_⟩
  · unfold cPiRat; exact div_nonneg (by exact_mod_cast hf_nn) (by positivity)
  · unfold cPiRat; exact (div_le_one (by positivity)).mpr (by exact_mod_cast hf_hi)
  · rw [hcast, abs_le]
    have h2m : P2⁻¹ = (2 : ℝ) ^ (-(M_pi : ℤ)) := by
      dsimp [P2]; rw [zpow_neg, zpow_natCast]; push_cast; rfl
    constructor
    · have : c_true - P2⁻¹ ≤ ((⌊c_true * P2⌋ : ℤ) : ℝ) / P2 := by
        rw [le_div_iff₀ hP2_pos, sub_mul, inv_mul_cancel₀ hP2_pos.ne']; exact hf_gt.le
      rw [h2m] at this; linarith
    · have : (((⌊c_true * P2⌋ : ℤ) : ℝ) / P2) ≤ c_true := (div_le_iff₀ hP2_pos).mpr hf_le
      linarith [ (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ (-(M_pi : ℤ))) ]

def cdfDegree (T b : ℕ) : ℕ := 2 * (T + 1) ^ 2 + 3 * T + b + 12
def cdfPiBits (T b : ℕ) : ℕ := T + b + 8

noncomputable def polyCDF (K : ℕ) (c_pi : ℚ) (y : ℝ) : ℝ :=
  if 0 ≤ y then (1 / 2 : ℝ) + (c_pi : ℝ) * gaussIntPoly K y
  else (1 / 2 : ℝ) - (c_pi : ℝ) * gaussIntPoly K (-y)

theorem polyCDF_approx_on_box (T b : ℕ) {y : ℝ} (hy : |y| ≤ ((T + 1 : ℕ) : ℝ)) :
    |polyCDF (cdfDegree T b) (cPiRat (cdfPiBits T b)) y - stdNormalCDF y| ≤
      (2 : ℝ) ^ (-((b + 3 : ℕ) : ℤ)) := by
  let K := cdfDegree T b
  let M_pi := cdfPiBits T b
  have hK1 : 1 ≤ K := by dsimp [K, cdfDegree]; omega
  obtain ⟨hc0, hc1, hc_err⟩ := cPiRat_bounds M_pi
  have hc0_r : (0 : ℝ) ≤ (cPiRat M_pi : ℝ) := by exact_mod_cast hc0
  have hc1_r : (cPiRat M_pi : ℝ) ≤ 1 := by exact_mod_cast hc1
  have hwlog : ∀ {x : ℝ}, 0 ≤ x → x ≤ ((T + 1 : ℕ) : ℝ) →
      |(cPiRat M_pi : ℝ) * gaussIntPoly K x -
        (Real.sqrt (2 * Real.pi))⁻¹ * ∫ u in Set.Ioc 0 x, Real.exp (-(u ^ 2 / 2))| ≤
          (2 : ℝ) ^ (-((b + 3 : ℕ) : ℤ)) := by
    intro x hx0 hxB
    let I_ex := ∫ u in Set.Ioc 0 x, Real.exp (-(u ^ 2 / 2))
    have hI_le : |I_ex| ≤ ((T + 1 : ℕ) : ℝ) := by
      have hnn : 0 ≤ I_ex :=
        MeasureTheory.setIntegral_nonneg measurableSet_Ioc (fun _ _ => (Real.exp_pos _).le)
      rw [abs_of_nonneg hnn]
      have h1 : I_ex ≤ ∫ _ in Set.Ioc 0 x, (1 : ℝ) :=
        MeasureTheory.setIntegral_mono_on
          (Continuous.integrableOn_Ioc (by continuity))
          (MeasureTheory.integrableOn_const measure_Ioc_lt_top.ne)
          measurableSet_Ioc
          (fun u _ => Real.exp_le_one_iff.mpr (by nlinarith))
      rw [MeasureTheory.setIntegral_const, smul_eq_mul, mul_one, Real.volume_real_Ioc_of_le hx0] at h1
      rw [sub_zero] at h1
      exact h1.trans hxB
    have hpoly_err := gaussIntPoly_approx_integral hK1 hx0
    have hrem_le : x * ((x ^ 2 / 2) ^ K / ((K - 1).factorial : ℝ)) ≤
        (2 : ℝ) ^ (-((b + 4 : ℕ) : ℤ)) := by
      let B : ℝ := ((T + 1 : ℕ) : ℝ)
      have hB_pos : 0 < B := by dsimp [B]; positivity
      have hx2 : x ^ 2 ≤ B ^ 2 := pow_le_pow_left₀ hx0 hxB 2
      have hterm1 : x * ((x ^ 2 / 2) ^ K / ((K - 1).factorial : ℝ)) ≤
          B * ((B ^ 2 / 2) ^ K / ((K - 1).factorial : ℝ)) := by
        refine mul_le_mul hxB ?_ (by positivity) hB_pos.le
        refine div_le_div_of_nonneg_right ?_ (by positivity)
        exact pow_le_pow_left₀ (by positivity) (div_le_div_of_nonneg_right hx2 (by norm_num)) K
      obtain ⟨Km1, hK_eq⟩ : ∃ Km1, K = Km1 + 1 := Nat.exists_eq_succ_of_ne_zero (by omega)
      have hKm1_def : Km1 = 2 * (T + 1) ^ 2 + 3 * T + b + 11 := by
        dsimp [K, cdfDegree] at hK_eq; omega
      have hrewrite : B * ((B ^ 2 / 2) ^ (Km1 + 1) / (Km1.factorial : ℝ)) =
          (B ^ 3 / 2) * ((B ^ 2) ^ Km1 / (Km1.factorial : ℝ)) * (2 : ℝ) ^ (-(Km1 : ℤ)) := by
        rw [div_pow, pow_succ, zpow_neg, zpow_natCast]
        field_simp
        ring
      rw [hK_eq, Nat.add_sub_cancel, hrewrite] at hterm1
      have hpow_fac : (B ^ 2) ^ Km1 / (Km1.factorial : ℝ) ≤ Real.exp (B ^ 2) :=
        pow_div_factorial_le_exp (by positivity) Km1
      have hexp_B2 : Real.exp (B ^ 2) ≤ (2 : ℝ) ^ (2 * (T + 1) ^ 2) := by
        have : B ^ 2 = (((T + 1) ^ 2 : ℕ) : ℝ) := by dsimp [B]; push_cast; ring
        exact UL.Proof_lem_6_3.exp_le_two_pow_two_mul ((T + 1) ^ 2) this.le
      have hB3_le : B ^ 3 / 2 ≤ (2 : ℝ) ^ (3 * T + 3) := by
        have hTp1 : B ≤ (2 : ℝ) ^ (T + 1) := UL.Proof_lem_6_3.nat_cast_le_two_pow (T + 1)
        calc B ^ 3 / 2 ≤ B ^ 3 := div_le_self (by positivity) (by norm_num)
          _ ≤ ((2 : ℝ) ^ (T + 1)) ^ 3 := pow_le_pow_left₀ hB_pos.le hTp1 3
          _ = (2 : ℝ) ^ (3 * T + 3) := by rw [← pow_mul]; congr 1; ring
      have hprod : (B ^ 3 / 2) * ((B ^ 2) ^ Km1 / (Km1.factorial : ℝ)) ≤
          (2 : ℝ) ^ ((3 * T + 3) + 2 * (T + 1) ^ 2) := by
        rw [pow_add]
        exact mul_le_mul hB3_le (hpow_fac.trans hexp_B2) (by positivity) (by positivity)
      rw [hK_eq, Nat.add_sub_cancel]
      refine hterm1.trans ((mul_le_mul_of_nonneg_right hprod (by positivity)).trans ?_)
      rw [← zpow_natCast, ← zpow_add₀ (by norm_num)]
      exact zpow_le_zpow_right₀ (by norm_num) (by rw [hKm1_def]; omega)
    have hpi_part : |((cPiRat M_pi : ℚ) : ℝ) - (Real.sqrt (2 * Real.pi))⁻¹| * |I_ex| ≤
        (2 : ℝ) ^ (-((b + 4 : ℕ) : ℤ)) := by
      have hTp1 : ((T + 1 : ℕ) : ℝ) ≤ (2 : ℝ) ^ (T + 1) :=
        UL.Proof_lem_6_3.nat_cast_le_two_pow (T + 1)
      have h1 : |((cPiRat M_pi : ℚ) : ℝ) - (Real.sqrt (2 * Real.pi))⁻¹| * |I_ex| ≤
          (2 : ℝ) ^ (-(M_pi : ℤ)) * (2 : ℝ) ^ (T + 1) :=
        mul_le_mul hc_err (hI_le.trans hTp1) (abs_nonneg _) (by positivity)
      refine h1.trans ?_
      rw [← zpow_natCast, ← zpow_add₀ (by norm_num)]
      exact zpow_le_zpow_right₀ (by norm_num) (by dsimp [M_pi, cdfPiBits]; omega)
    have htri : |(cPiRat M_pi : ℝ) * gaussIntPoly K x - (Real.sqrt (2 * Real.pi))⁻¹ * I_ex| ≤
        |(cPiRat M_pi : ℝ)| * |gaussIntPoly K x - I_ex| +
          |(cPiRat M_pi : ℝ) - (Real.sqrt (2 * Real.pi))⁻¹| * |I_ex| := by
      have hid : (cPiRat M_pi : ℝ) * gaussIntPoly K x - (Real.sqrt (2 * Real.pi))⁻¹ * I_ex =
          (cPiRat M_pi : ℝ) * (gaussIntPoly K x - I_ex) +
            ((cPiRat M_pi : ℝ) - (Real.sqrt (2 * Real.pi))⁻¹) * I_ex := by ring
      rw [hid]
      exact (abs_add_le _ _).trans (by rw [abs_mul, abs_mul])
    have hp1 : |(cPiRat M_pi : ℝ)| * |gaussIntPoly K x - I_ex| ≤ (2 : ℝ) ^ (-((b + 4 : ℕ) : ℤ)) := by
      rw [abs_of_nonneg hc0_r]
      exact (mul_le_mul hc1_r (hpoly_err.trans hrem_le) (abs_nonneg _) zero_le_one).trans (by linarith)
    have hsum2 : (2 : ℝ) ^ (-((b + 4 : ℕ) : ℤ)) + (2 : ℝ) ^ (-((b + 4 : ℕ) : ℤ)) =
        (2 : ℝ) ^ (-((b + 3 : ℕ) : ℤ)) := by
      have : -((b + 3 : ℕ) : ℤ) = -((b + 4 : ℕ) : ℤ) + 1 := by omega
      rw [this, zpow_add₀ (by norm_num), zpow_one]; ring
    linarith
  rcases abs_le.mp hy with ⟨hy_lo, hy_hi⟩
  unfold polyCDF
  split_ifs with hy0
  · rw [stdNormalCDF_pos_eq hy0]
    have : (1 / 2 + (cPiRat M_pi : ℝ) * gaussIntPoly K y) -
        (1 / 2 + (Real.sqrt (2 * Real.pi))⁻¹ * ∫ u in Set.Ioc 0 y, Real.exp (-(u ^ 2 / 2))) =
        (cPiRat M_pi : ℝ) * gaussIntPoly K y -
          (Real.sqrt (2 * Real.pi))⁻¹ * ∫ u in Set.Ioc 0 y, Real.exp (-(u ^ 2 / 2)) := by ring
    rw [this]
    exact hwlog hy0 hy_hi
  · push_neg at hy0
    have hny0 : 0 ≤ -y := by linarith
    have hnyB : -y ≤ ((T + 1 : ℕ) : ℝ) := by linarith
    have hneg_cdf : stdNormalCDF y = 1 - stdNormalCDF (-y) := by
      have := stdNormalCDF_neg (-y); rw [neg_neg] at this; exact this
    rw [hneg_cdf, stdNormalCDF_pos_eq hny0]
    have : (1 / 2 - (cPiRat M_pi : ℝ) * gaussIntPoly K (-y)) -
        (1 - (1 / 2 + (Real.sqrt (2 * Real.pi))⁻¹ * ∫ u in Set.Ioc 0 (-y), Real.exp (-(u ^ 2 / 2)))) =
        -((cPiRat M_pi : ℝ) * gaussIntPoly K (-y) -
          (Real.sqrt (2 * Real.pi))⁻¹ * ∫ u in Set.Ioc 0 (-y), Real.exp (-(u ^ 2 / 2))) := by ring
    rw [this, abs_neg]
    exact hwlog hny0 hnyB

/-! ### 4. Monotonicity-free rational bisection quantile sampler `polySample1D` -/

noncomputable def bisectStep (K : ℕ) (c_pi p_tgt : ℚ) (lh : ℚ × ℚ) : ℚ × ℚ :=
  open Classical in
  if polyCDF K c_pi (((lh.1 + lh.2) / 2 : ℚ) : ℝ) ≤ (p_tgt : ℝ) then
    ((lh.1 + lh.2) / 2, lh.2)
  else
    (lh.1, (lh.1 + lh.2) / 2)

noncomputable def polySample1D (b T p_coord : ℕ) (k : Fin (2 ^ b)) : ℚ :=
  if k.1 = 0 then 0
  else
    let K := cdfDegree T b
    let c_pi := cPiRat (cdfPiBits T b)
    let p_tgt : ℚ := (k.1 : ℚ) / ((2 ^ b : ℕ) : ℚ)
    let S_bis : ℕ := T + p_coord + 6
    let initLH : ℚ × ℚ := (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))
    ((bisectStep K c_pi p_tgt)^[S_bis] initLH).1

private lemma bisectStep_iter_inv (K : ℕ) (c_pi p_tgt : ℚ) (T s : ℕ) :
    -(((T + 1 : ℕ) : ℚ)) ≤ ((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).1 ∧
    ((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).1 ≤
      ((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).2 ∧
    ((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).2 ≤ ((T + 1 : ℕ) : ℚ) ∧
    ((((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).2 -
      ((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).1 : ℚ) : ℝ) =
      2 * ((T + 1 : ℕ) : ℝ) * (2 : ℝ) ^ (-(s : ℤ)) ∧
    (((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).1 = -((T + 1 : ℕ) : ℚ) ∨
      polyCDF K c_pi (((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).1 : ℝ) ≤ (p_tgt : ℝ)) ∧
    (((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).2 = ((T + 1 : ℕ) : ℚ) ∨
      (p_tgt : ℝ) < polyCDF K c_pi (((bisectStep K c_pi p_tgt)^[s] (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).2 : ℝ)) := by
  let Bq : ℚ := ((T + 1 : ℕ) : ℚ)
  change -Bq ≤ ((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).1 ∧
    ((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).1 ≤ ((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).2 ∧
    ((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).2 ≤ Bq ∧
    ((((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).2 - ((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).1 : ℚ) : ℝ) =
      2 * ((T + 1 : ℕ) : ℝ) * (2 : ℝ) ^ (-(s : ℤ)) ∧
    (((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).1 = -Bq ∨
      polyCDF K c_pi (((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).1 : ℝ) ≤ (p_tgt : ℝ)) ∧
    (((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).2 = Bq ∨
      (p_tgt : ℝ) < polyCDF K c_pi (((bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)).2 : ℝ))
  induction s with
  | zero =>
    simp only [Function.iterate_zero, id_eq]
    have hBq0 : (0 : ℚ) ≤ Bq := by dsimp [Bq]; positivity
    refine ⟨le_rfl, by linarith, le_rfl, ?_, Or.inl trivial, Or.inl trivial⟩
    dsimp [Bq]; simp only [Nat.cast_zero, neg_zero, zpow_zero, mul_one]; push_cast; ring
  | succ s ih =>
    rw [Function.iterate_succ_apply']
    set lh := (bisectStep K c_pi p_tgt)^[s] (-Bq, Bq)
    rcases ih with ⟨hlo, hlh, hhi, hwid, hlo_p, hhi_p⟩
    unfold bisectStep
    set mid : ℚ := (lh.1 + lh.2) / 2
    have hmid_lo : lh.1 ≤ mid := by dsimp [mid]; linarith
    have hmid_hi : mid ≤ lh.2 := by dsimp [mid]; linarith
    have hwid_half : ∀ a b : ℚ, a - b = (lh.2 - lh.1) / 2 →
        ((a - b : ℚ) : ℝ) = 2 * ((T + 1 : ℕ) : ℝ) * (2 : ℝ) ^ (-((s + 1 : ℕ) : ℤ)) := by
      intro a b hab
      have hcast : ((a - b : ℚ) : ℝ) = ((lh.2 - lh.1 : ℚ) : ℝ) / 2 := by rw [hab]; push_cast; rfl
      rw [hcast, hwid]
      have hz : -((s + 1 : ℕ) : ℤ) = -(s : ℤ) - 1 := by omega
      rw [hz, zpow_sub₀ (by norm_num), zpow_one]
      ring
    split_ifs with hle
    · refine ⟨hlo.trans hmid_lo, hmid_hi, hhi, hwid_half lh.2 mid (by dsimp [mid]; ring), Or.inr hle, hhi_p⟩
    · push_neg at hle
      refine ⟨hlo, hmid_lo, hmid_hi.trans hhi, hwid_half mid lh.1 (by dsimp [mid]; ring), hlo_p, Or.inr hle⟩

theorem polySample1D_def (b T p_coord : ℕ) (k : Fin (2 ^ b)) :
    polySample1D b T p_coord k =
      if k.1 = 0 then 0
      else
        ((bisectStep (cdfDegree T b) (cPiRat (cdfPiBits T b))
          ((k.1 : ℚ) / ((2 ^ b : ℕ) : ℚ)))^[T + p_coord + 6]
          (-((T + 1 : ℕ) : ℚ), ((T + 1 : ℕ) : ℚ))).1 := rfl

theorem polySample1D_approx_on_box {b T p_coord : ℕ}
    (hb_eq : b = ((T + 1) ^ 2 + 2) + p_coord + 2) (hb : 1 ≤ b)
    {z : ℝ} (hz : |z| ≤ (T : ℝ)) :
    |((polySample1D b T p_coord (binIdx b hb z) : ℚ) : ℝ) - z| ≤
      (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) := by
  let m_exp : ℕ := (T + 1) ^ 2 + 2
  have hb_m : b = m_exp + p_coord + 2 := hb_eq
  rcases abs_le.mp hz with ⟨hz_lo, hz_hi⟩
  let k : Fin (2 ^ b) := binIdx b hb z
  have hzk : z ∈ binSet b k := (binIdx_eq_iff b hb z k).mp rfl
  have h2b_eq : (((2 ^ b : ℕ) : ℝ))⁻¹ = (2 : ℝ) ^ (-(b : ℤ)) := by
    rw [zpow_neg, zpow_natCast]; push_cast; rfl
  have hlt_pow : (2 : ℝ) ^ (-(b : ℤ)) < (2 : ℝ) ^ (-(m_exp : ℤ)) :=
    zpow_lt_zpow_right₀ (by norm_num) (by dsimp [m_exp] at hb_m; omega)
  have hbuf_L : (2 : ℝ) ^ (-(m_exp : ℤ)) ≤
      stdNormalCDF (-(T : ℝ)) - stdNormalCDF (-((T + 1 : ℕ) : ℝ)) := by
    have h := stdNormalCDF_sub_ge_on_box T (a := -((T + 1 : ℕ) : ℝ)) (b := -(T : ℝ))
      le_rfl (by push_cast; linarith) (by push_cast; linarith [Nat.cast_nonneg (α := ℝ) T])
    have hlen : -(T : ℝ) - -((T + 1 : ℕ) : ℝ) = 1 := by push_cast; ring
    rwa [hlen, mul_one] at h
  have hbuf_R : (2 : ℝ) ^ (-(m_exp : ℤ)) ≤
      stdNormalCDF ((T + 1 : ℕ) : ℝ) - stdNormalCDF (T : ℝ) := by
    have h := stdNormalCDF_sub_ge_on_box T (a := (T : ℝ)) (b := ((T + 1 : ℕ) : ℝ))
      (by push_cast; linarith [Nat.cast_nonneg (α := ℝ) T]) (by push_cast; linarith) le_rfl
    have hlen : ((T + 1 : ℕ) : ℝ) - (T : ℝ) = 1 := by push_cast; ring
    rwa [hlen, mul_one] at h
  have hcdf_0 : 0 ≤ stdNormalCDF (-((T + 1 : ℕ) : ℝ)) := MeasureTheory.measureReal_nonneg
  have hcdf_1 : stdNormalCDF ((T + 1 : ℕ) : ℝ) ≤ 1 := by
    unfold stdNormalCDF
    simpa [MeasureTheory.measureReal_def] using ENNReal.toReal_mono ENNReal.one_ne_top prob_le_one
  have hk0 : k.1 ≠ 0 := by
    intro h0
    have hle : z ≤ qVal b 1 := by unfold binSet at hzk; rwa [if_pos h0] at hzk
    have hcdf_z : stdNormalCDF (-(T : ℝ)) ≤ stdNormalCDF (qVal b 1) := stdNormalCDF_mono (hz_lo.trans hle)
    have hq1 : stdNormalCDF (qVal b 1) = (2 : ℝ) ^ (-(b : ℤ)) := by
      rw [stdNormalCDF_qVal (by omega) (Nat.lt_of_lt_of_le (by decide : 1 < 2 ^ 1) (Nat.pow_le_pow_right (by decide) hb)),
        Nat.cast_one, one_div, h2b_eq]
    linarith
  have hklt : k.1 + 1 < 2 ^ b := by
    by_contra hge
    have hk_eq : k.1 = 2 ^ b - 1 := by have := k.2; omega
    have hgt : qVal b (2 ^ b - 1) < z := by unfold binSet at hzk; rwa [if_neg hk0, if_neg hge] at hzk
    have hcdf_z : stdNormalCDF (qVal b (2 ^ b - 1)) ≤ stdNormalCDF (T : ℝ) := stdNormalCDF_mono (hgt.le.trans hz_hi)
    have h2b_ge2 : 2 ≤ 2 ^ b := Nat.pow_le_pow_right (by decide : 0 < 2) hb
    have h2b_rpos : (0 : ℝ) < ((2 ^ b : ℕ) : ℝ) := by positivity
    have hq_last : stdNormalCDF (qVal b (2 ^ b - 1)) = 1 - (2 : ℝ) ^ (-(b : ℤ)) := by
      rw [stdNormalCDF_qVal (by omega) (by omega), Nat.cast_sub (by omega : 1 ≤ 2 ^ b),
        Nat.cast_one, sub_div, div_self h2b_rpos.ne', one_div, h2b_eq]
    linarith
  have hz_mem : qVal b k.1 < z ∧ z ≤ qVal b (k.1 + 1) := by
    unfold binSet at hzk; rwa [if_neg hk0, if_pos hklt] at hzk
  have hk1 : 1 ≤ k.1 := by omega
  have hq_cdf : stdNormalCDF (qVal b k.1) = (k.1 : ℝ) / ((2 ^ b : ℕ) : ℝ) :=
    stdNormalCDF_qVal hk1 (by omega)
  have hcdf_step : stdNormalCDF (qVal b (k.1 + 1)) - stdNormalCDF (qVal b k.1) = (2 : ℝ) ^ (-(b : ℤ)) := by
    rw [stdNormalCDF_qVal (by omega) hklt, hq_cdf]; push_cast
    rw [add_div, add_sub_cancel_left, one_div, zpow_neg, zpow_natCast]
  have hq_lo : -((T + 1 : ℕ) : ℝ) ≤ qVal b k.1 := by
    by_contra hlt_lo; push_neg at hlt_lo
    have hc1 := stdNormalCDF_mono hlt_lo.le
    have hc2 := stdNormalCDF_mono (hz_lo.trans hz_mem.2)
    have hkn : (k.1 : ℝ) / ((2 ^ b : ℕ) : ℝ) ≥ (2 : ℝ) ^ (-(b : ℤ)) := by
      rw [← h2b_eq, ← one_div]; exact div_le_div_of_nonneg_right (by exact_mod_cast hk1) (by positivity)
    linarith
  have hq_hi : qVal b (k.1 + 1) ≤ ((T + 1 : ℕ) : ℝ) := by
    by_contra hgt_hi; push_neg at hgt_hi
    have hc1 := stdNormalCDF_mono (hz_mem.1.le.trans hz_hi)
    have hc2 := stdNormalCDF_mono hgt_hi.le
    linarith
  have hq_le : qVal b k.1 ≤ qVal b (k.1 + 1) := hz_mem.1.le.trans hz_mem.2
  have hwidth : qVal b (k.1 + 1) - qVal b k.1 ≤ (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) := by
    have hdens := stdNormalCDF_sub_ge_on_box T hq_lo hq_le hq_hi
    change (2 : ℝ) ^ (-(m_exp : ℤ)) * (qVal b (k.1 + 1) - qVal b k.1) ≤ _ at hdens
    rw [hcdf_step] at hdens
    have hmul := mul_le_mul_of_nonneg_left hdens (by positivity : 0 ≤ (2 : ℝ) ^ (m_exp : ℤ))
    have e1 : (2 : ℝ) ^ (m_exp : ℤ) * ((2 : ℝ) ^ (-(m_exp : ℤ)) * (qVal b (k.1 + 1) - qVal b k.1)) =
        qVal b (k.1 + 1) - qVal b k.1 := by
      rw [← mul_assoc, ← zpow_add₀ (by norm_num), add_neg_cancel, zpow_zero, one_mul]
    have e2 : (2 : ℝ) ^ (m_exp : ℤ) * (2 : ℝ) ^ (-(b : ℤ)) = (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) := by
      rw [← zpow_add₀ (by norm_num)]; congr 1; omega
    rwa [e1, e2] at hmul
  -- Unpack bisection output after `S_bis := T + p_coord + 6` steps
  unfold polySample1D
  rw [if_neg hk0]
  let K := cdfDegree T b
  let c_pi := cPiRat (cdfPiBits T b)
  let p_tgt : ℚ := (k.1 : ℚ) / ((2 ^ b : ℕ) : ℚ)
  let S_bis : ℕ := T + p_coord + 6
  let Bq : ℚ := ((T + 1 : ℕ) : ℚ)
  obtain ⟨hlo_B, hlh_le, hhi_B, hwid_bis, hlo_case, hhi_case⟩ :=
    bisectStep_iter_inv K c_pi p_tgt T S_bis
  set lh := (bisectStep K c_pi p_tgt)^[S_bis] (-Bq, Bq)
  have hp_tgt_r : (p_tgt : ℝ) = stdNormalCDF (qVal b k.1) := by
    rw [hq_cdf]; dsimp [p_tgt]; push_cast; rfl
  have hlo_box : |(lh.1 : ℝ)| ≤ ((T + 1 : ℕ) : ℝ) := by
    rw [abs_le]; exact ⟨by exact_mod_cast hlo_B, by exact_mod_cast hlh_le.trans hhi_B⟩
  have hhi_box : |(lh.2 : ℝ)| ≤ ((T + 1 : ℕ) : ℝ) := by
    rw [abs_le]; exact ⟨by exact_mod_cast hlo_B.trans hlh_le, by exact_mod_cast hhi_B⟩
  -- 1. `(lh.1 : ℝ) - qVal b k.1 ≤ 2^{-(p_coord + 5)}`
  have hlo_ub : (lh.1 : ℝ) - qVal b k.1 ≤ (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ)) := by
    rcases hlo_case with hlo_eq | hlo_cdf
    · have : (lh.1 : ℝ) = -((T + 1 : ℕ) : ℝ) := by rw [hlo_eq]; push_cast; rfl
      linarith [ (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ))) ]
    · by_cases hle_q : (lh.1 : ℝ) ≤ qVal b k.1
      · linarith [ (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ))) ]
      · push_neg at hle_q
        have hdens := stdNormalCDF_sub_ge_on_box T hq_lo hle_q.le (abs_le.mp hlo_box).2
        change (2 : ℝ) ^ (-(m_exp : ℤ)) * ((lh.1 : ℝ) - qVal b k.1) ≤ _ at hdens
        have herr := (abs_le.mp (polyCDF_approx_on_box T b hlo_box)).1
        rw [hp_tgt_r] at hlo_cdf
        have hdiff_le : stdNormalCDF (lh.1 : ℝ) - stdNormalCDF (qVal b k.1) ≤
            (2 : ℝ) ^ (-((b + 3 : ℕ) : ℤ)) := by linarith
        have hcomb := hdens.trans hdiff_le
        have hmul := mul_le_mul_of_nonneg_left hcomb (by positivity : 0 ≤ (2 : ℝ) ^ (m_exp : ℤ))
        have e1 : (2 : ℝ) ^ (m_exp : ℤ) * ((2 : ℝ) ^ (-(m_exp : ℤ)) * ((lh.1 : ℝ) - qVal b k.1)) =
            (lh.1 : ℝ) - qVal b k.1 := by
          rw [← mul_assoc, ← zpow_add₀ (by norm_num), add_neg_cancel, zpow_zero, one_mul]
        have e2 : (2 : ℝ) ^ (m_exp : ℤ) * (2 : ℝ) ^ (-((b + 3 : ℕ) : ℤ)) =
            (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ)) := by
          rw [← zpow_add₀ (by norm_num)]; congr 1; omega
        rwa [e1, e2] at hmul
  -- 2. `qVal b k.1 - (lh.2 : ℝ) ≤ 2^{-(p_coord + 5)}`
  have hhi_lb : qVal b k.1 - (lh.2 : ℝ) ≤ (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ)) := by
    rcases hhi_case with hhi_eq | hhi_cdf
    · have : (lh.2 : ℝ) = ((T + 1 : ℕ) : ℝ) := by rw [hhi_eq]; push_cast; rfl
      have hq_hi_k := hq_le.trans hq_hi
      linarith [ (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ))) ]
    · by_cases hge_q : qVal b k.1 ≤ (lh.2 : ℝ)
      · linarith [ (by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ))) ]
      · push_neg at hge_q
        have hdens := stdNormalCDF_sub_ge_on_box T (abs_le.mp hhi_box).1 hge_q.le (hq_le.trans hq_hi)
        change (2 : ℝ) ^ (-(m_exp : ℤ)) * (qVal b k.1 - (lh.2 : ℝ)) ≤ _ at hdens
        have herr := (abs_le.mp (polyCDF_approx_on_box T b hhi_box)).2
        rw [hp_tgt_r] at hhi_cdf
        have hdiff_le : stdNormalCDF (qVal b k.1) - stdNormalCDF (lh.2 : ℝ) ≤
            (2 : ℝ) ^ (-((b + 3 : ℕ) : ℤ)) := by linarith
        have hcomb := hdens.trans hdiff_le
        have hmul := mul_le_mul_of_nonneg_left hcomb (by positivity : 0 ≤ (2 : ℝ) ^ (m_exp : ℤ))
        have e1 : (2 : ℝ) ^ (m_exp : ℤ) * ((2 : ℝ) ^ (-(m_exp : ℤ)) * (qVal b k.1 - (lh.2 : ℝ))) =
            qVal b k.1 - (lh.2 : ℝ) := by
          rw [← mul_assoc, ← zpow_add₀ (by norm_num), add_neg_cancel, zpow_zero, one_mul]
        have e2 : (2 : ℝ) ^ (m_exp : ℤ) * (2 : ℝ) ^ (-((b + 3 : ℕ) : ℤ)) =
            (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ)) := by
          rw [← zpow_add₀ (by norm_num)]; congr 1; omega
        rwa [e1, e2] at hmul
  -- 3. `((lh.2 : ℝ) - (lh.1 : ℝ)) ≤ 2^{-(p_coord + 4)}`
  have hwid_ub : (lh.2 : ℝ) - (lh.1 : ℝ) ≤ (2 : ℝ) ^ (-((p_coord + 4 : ℕ) : ℤ)) := by
    have hsub_cast : (lh.2 : ℝ) - (lh.1 : ℝ) = ((lh.2 - lh.1 : ℚ) : ℝ) := by push_cast; rfl
    rw [hsub_cast, hwid_bis]
    have hTp1 : 2 * ((T + 1 : ℕ) : ℝ) ≤ (2 : ℝ) ^ (T + 2) := by
      have h1 := UL.Proof_lem_6_3.nat_cast_le_two_pow (T + 1)
      calc 2 * ((T + 1 : ℕ) : ℝ) ≤ 2 * (2 : ℝ) ^ (T + 1) := by linarith
        _ = (2 : ℝ) ^ (T + 2) := by rw [pow_succ']; ring
    calc 2 * ((T + 1 : ℕ) : ℝ) * (2 : ℝ) ^ (-(S_bis : ℤ))
        ≤ (2 : ℝ) ^ (T + 2) * (2 : ℝ) ^ (-(S_bis : ℤ)) :=
          mul_le_mul_of_nonneg_right hTp1 (by positivity)
      _ = (2 : ℝ) ^ (-((p_coord + 4 : ℕ) : ℤ)) := by
          rw [← zpow_natCast, ← zpow_add₀ (by norm_num)]
          congr 1; dsimp [S_bis]; omega
  -- Combine into `|(lh.1 : ℝ) - z| ≤ 2^{-(p_coord + 1)}`
  rw [abs_le]
  have hp5_le_p3 : (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ)) ≤ (2 : ℝ) ^ (-((p_coord + 3 : ℕ) : ℤ)) :=
    zpow_le_zpow_right₀ (by norm_num) (by omega)
  have hp4_le_p3 : (2 : ℝ) ^ (-((p_coord + 4 : ℕ) : ℤ)) ≤ (2 : ℝ) ^ (-((p_coord + 3 : ℕ) : ℤ)) :=
    zpow_le_zpow_right₀ (by norm_num) (by omega)
  have hp5_le_p1 : (2 : ℝ) ^ (-((p_coord + 5 : ℕ) : ℤ)) ≤ (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) :=
    zpow_le_zpow_right₀ (by norm_num) (by omega)
  have hsum_pow : (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) +
      (2 : ℝ) ^ (-((p_coord + 3 : ℕ) : ℤ)) + (2 : ℝ) ^ (-((p_coord + 3 : ℕ) : ℤ)) =
      (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) := by
    have e32 : (2 : ℝ) ^ (-((p_coord + 3 : ℕ) : ℤ)) + (2 : ℝ) ^ (-((p_coord + 3 : ℕ) : ℤ)) =
        (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) := by
      have : -((p_coord + 2 : ℕ) : ℤ) = -((p_coord + 3 : ℕ) : ℤ) + 1 := by omega
      rw [this, zpow_add₀ (by norm_num), zpow_one]; ring
    have e21 : (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) + (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) =
        (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) := by
      have : -((p_coord + 1 : ℕ) : ℤ) = -((p_coord + 2 : ℕ) : ℤ) + 1 := by omega
      rw [this, zpow_add₀ (by norm_num), zpow_one]; ring
    linarith
  constructor
  · have h_z_q : z - qVal b k.1 ≤ (2 : ℝ) ^ (-((p_coord + 2 : ℕ) : ℤ)) := by linarith [hz_mem.2, hwidth]
    linarith
  · linarith [hz_mem.1]

attribute [irreducible] polySample1D

/-! ### 5. `sqrt`-free real cap test, `sqrt`-free lattice rounding, and order-independent good coin event -/

def realSignedSqCapCond {d : ℕ} (A B_signed a₀ : ℝ)
    (G : EuclideanSpace ℝ (Fin (d + 1))) (w : EuclideanSpace ℝ (Fin d)) : Prop :=
  let L : ℝ := A * ∑ i : Fin d, euclideanCoord G i.castSucc * euclideanCoord w i
  let R : ℝ := a₀ - B_signed * euclideanCoord G (Fin.last d)
  let normSq : ℝ := ∑ i : Fin d, (euclideanCoord w i) ^ 2
  (0 < R ∧ 0 ≤ L ∧ R ^ 2 * normSq ≤ L ^ 2) ∨
  (R ≤ 0 ∧ (0 ≤ L ∨ L ^ 2 ≤ R ^ 2 * normSq))

theorem real_cap_test_iff {d : ℕ} (A B_signed a₀ : ℝ)
    (G : EuclideanSpace ℝ (Fin (d + 1))) (w : EuclideanSpace ℝ (Fin d)) (hw : w ≠ 0) :
    let u_w : EuclideanSpace ℝ (Fin d) := ‖w‖⁻¹ • w
    let p_pad : EuclideanSpace ℝ (Fin (d + 1)) := liftedPoint (A • u_w) B_signed
    gaussianDataTest a₀ G p_pad ↔ realSignedSqCapCond A B_signed a₀ G w := by
  intro u_w p_pad
  have hw_pos : 0 < ‖w‖ := norm_pos_iff.mpr hw
  let L : ℝ := A * ∑ i : Fin d, euclideanCoord G i.castSucc * euclideanCoord w i
  let R : ℝ := a₀ - B_signed * euclideanCoord G (Fin.last d)
  let N_sq : ℝ := ∑ i : Fin d, (euclideanCoord w i) ^ 2
  have hN_eq : N_sq = ‖w‖ ^ 2 := by
    rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
    refine Finset.sum_congr rfl fun i _ => ?_
    simp [euclideanCoord, sq]
  have hinner : inner ℝ G p_pad = L / ‖w‖ + B_signed * euclideanCoord G (Fin.last d) := by
    rw [PiLp.inner_apply, Fin.sum_univ_castSucc]
    have hbase : (∑ i : Fin d, inner ℝ (G i.castSucc) (p_pad i.castSucc)) = L / ‖w‖ := by
      have hterm : ∀ i : Fin d,
          inner ℝ (G i.castSucc) (p_pad i.castSucc) =
            (A * (euclideanCoord G i.castSucc * euclideanCoord w i)) / ‖w‖ := by
        intro i
        simp only [p_pad, u_w, liftedPoint, euclideanCoord, WithLp.equiv_apply,
          Fin.snoc_castSucc, PiLp.smul_apply, smul_eq_mul, RCLike.inner_apply, conj_trivial]
        ring
      simp_rw [hterm, ← Finset.sum_div, ← Finset.mul_sum]
      rfl
    have hlast : inner ℝ (G (Fin.last d)) (p_pad (Fin.last d)) =
        B_signed * euclideanCoord G (Fin.last d) := by
      simp only [p_pad, liftedPoint, euclideanCoord, WithLp.equiv_apply,
        Fin.snoc_last, RCLike.inner_apply, conj_trivial]
    rw [hbase, hlast]
  have hstep1 : gaussianDataTest a₀ G p_pad ↔ R * ‖w‖ ≤ L := by
    unfold gaussianDataTest
    rw [hinner]
    constructor
    · intro h
      have h1 : R ≤ L / ‖w‖ := by dsimp [R]; linarith
      exact (le_div_iff₀ hw_pos).mp h1
    · intro h
      have h1 : R ≤ L / ‖w‖ := (le_div_iff₀ hw_pos).mpr h
      dsimp [R] at h1; linarith
  rw [hstep1, real_signed_sq_cap_iff hw_pos, ← hN_eq]
  rfl

def latCmp {d : ℕ} (M : ℕ) (w : EuclideanSpace ℝ (Fin d)) (i : Fin d) (u : ℕ) : Prop :=
  let R : ℝ := ((2 * (u : ℤ) - 2 * (M : ℤ) - 1 : ℤ) : ℝ)
  let L : ℝ := 2 * (M : ℝ) * euclideanCoord w i
  let normSq : ℝ := ∑ c : Fin d, (euclideanCoord w c) ^ 2
  (0 < R ∧ 0 ≤ L ∧ R ^ 2 * normSq ≤ L ^ 2) ∨
  (R ≤ 0 ∧ (0 ≤ L ∨ L ^ 2 ≤ R ^ 2 * normSq))

theorem latCmp_iff {d : ℕ} (M : ℕ) {w : EuclideanSpace ℝ (Fin d)} (hw : w ≠ 0)
    (i : Fin d) (u : ℕ) :
    latCmp M w i u ↔ (((u : ℤ) - (M : ℤ) : ℤ) : ℝ) ≤ (M : ℝ) * euclideanCoord (‖w‖⁻¹ • w) i + 1 / 2 := by
  let z : EuclideanSpace ℝ (Fin d) := ‖w‖⁻¹ • w
  have hw_pos : 0 < ‖w‖ := norm_pos_iff.mpr hw
  let R : ℝ := ((2 * (u : ℤ) - 2 * (M : ℤ) - 1 : ℤ) : ℝ)
  let L : ℝ := 2 * (M : ℝ) * euclideanCoord w i
  have hN_eq : (∑ c : Fin d, (euclideanCoord w c) ^ 2) = ‖w‖ ^ 2 := by
    rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
    refine Finset.sum_congr rfl fun c _ => by simp [euclideanCoord, sq]
  have hiff1 : latCmp M w i u ↔ R * ‖w‖ ≤ L := by
    unfold latCmp; dsimp only; rw [hN_eq]; exact (real_signed_sq_cap_iff hw_pos).symm
  rw [hiff1]
  have hzi : euclideanCoord z i = euclideanCoord w i / ‖w‖ := by
    simp [z, euclideanCoord, div_eq_inv_mul]
  rw [hzi]
  have hR_eq : R = 2 * (((u : ℤ) - (M : ℤ) : ℤ) : ℝ) - 1 := by dsimp [R]; push_cast; ring
  have hL_eq : L / ‖w‖ = 2 * (M : ℝ) * (euclideanCoord w i / ‖w‖) := by dsimp [L]; ring
  rw [← le_div_iff₀ hw_pos, hR_eq, hL_eq]
  constructor <;> intro h <;> linarith

noncomputable def latBisectStep {d : ℕ} (M : ℕ) (w : EuclideanSpace ℝ (Fin d)) (i : Fin d)
    (lh : ℕ × ℕ) : ℕ × ℕ :=
  open Classical in
  if lh.2 ≤ lh.1 + 1 then lh
  else if latCmp M w i ((lh.1 + lh.2) / 2) then ((lh.1 + lh.2) / 2, lh.2)
  else (lh.1, (lh.1 + lh.2) / 2)

theorem latBisect_eq_floor {d : ℕ} {M S_lat : ℕ} (hS : 2 * M + 1 ≤ 2 ^ S_lat)
    {w : EuclideanSpace ℝ (Fin d)} (hw : w ≠ 0) (i : Fin d) :
    let z : EuclideanSpace ℝ (Fin d) := ‖w‖⁻¹ • w
    let u_out := ((latBisectStep M w i)^[S_lat] (0, 2 * M + 1)).1
    ((u_out : ℤ) - (M : ℤ)) = Int.floor ((M : ℝ) * euclideanCoord z i + 1 / 2) := by
  intro z u_out
  have hw_pos : 0 < ‖w‖ := norm_pos_iff.mpr hw
  have hz_unit : ‖z‖ = 1 := by
    dsimp [z]; rw [norm_smul, Real.norm_eq_abs, abs_inv, abs_norm, inv_mul_cancel₀ hw_pos.ne']
  have hcoord_abs : |euclideanCoord z i| ≤ 1 := by
    have hsq : (euclideanCoord z i) ^ 2 ≤ ‖z‖ ^ 2 := by
      rw [← real_inner_self_eq_norm_sq, PiLp.inner_apply]
      have hterm : ∀ c : Fin d, inner ℝ (z c) (z c) = (euclideanCoord z c) ^ 2 :=
        fun c => by simp [euclideanCoord, sq]
      simp_rw [hterm]
      exact Finset.single_le_sum (fun c _ => sq_nonneg _) (Finset.mem_univ i)
    rw [hz_unit] at hsq
    exact abs_le.mpr (abs_le_of_sq_le_sq' hsq zero_le_one)
  rcases abs_le.mp hcoord_abs with ⟨hzi_lo, hzi_hi⟩
  have hcmp0 : latCmp M w i 0 := by
    rw [latCmp_iff M hw i 0]
    have : -(M : ℝ) ≤ (M : ℝ) * euclideanCoord z i := by
      have := mul_le_mul_of_nonneg_left hzi_lo (Nat.cast_nonneg (α := ℝ) M)
      linarith
    push_cast; linarith
  have hcmp_top : ¬ latCmp M w i (2 * M + 1) := by
    rw [latCmp_iff M hw i (2 * M + 1)]
    have : (M : ℝ) * euclideanCoord z i ≤ (M : ℝ) := by
      have := mul_le_mul_of_nonneg_left hzi_hi (Nat.cast_nonneg (α := ℝ) M)
      linarith
    push_cast; linarith
  have hinv : ∀ k ≤ S_lat,
      let lh := (latBisectStep M w i)^[k] (0, 2 * M + 1)
      lh.1 < lh.2 ∧
      lh.2 - lh.1 ≤ 2 ^ (S_lat - k) ∧
      latCmp M w i lh.1 ∧
      ¬ latCmp M w i lh.2 := by
    intro k
    induction k with
    | zero =>
      intro _
      simp only [Function.iterate_zero, id_eq, Nat.sub_zero]
      exact ⟨by omega, by omega, hcmp0, hcmp_top⟩
    | succ k ih =>
      intro hk_le
      rw [Function.iterate_succ_apply']
      obtain ⟨hlt, hdiff, hlo_c, hhi_c⟩ := ih (by omega)
      set lh := (latBisectStep M w i)^[k] (0, 2 * M + 1)
      have hpow_split : 2 ^ (S_lat - k) = 2 * 2 ^ (S_lat - (k + 1)) := by
        have : S_lat - k = (S_lat - (k + 1)) + 1 := by omega
        rw [this, pow_succ']
      unfold latBisectStep
      split_ifs with h1 hmid_c
      · refine ⟨hlt, by omega, hlo_c, hhi_c⟩
      · refine ⟨by omega, ?_, hmid_c, hhi_c⟩
        rw [hpow_split] at hdiff; omega
      · refine ⟨by omega, ?_, hlo_c, hmid_c⟩
        rw [hpow_split] at hdiff; omega
  obtain ⟨hlt_f, hdiff_f, hlo_f, hhi_f⟩ := hinv S_lat le_rfl
  simp only [Nat.sub_self, pow_zero] at hdiff_f
  have hhi_eq : ((latBisectStep M w i)^[S_lat] (0, 2 * M + 1)).2 = u_out + 1 := by
    dsimp [u_out] at hlt_f hdiff_f ⊢; omega
  rw [hhi_eq] at hhi_f
  rw [latCmp_iff M hw i u_out] at hlo_f
  rw [latCmp_iff M hw i (u_out + 1)] at hhi_f
  push_neg at hhi_f
  exact (Int.floor_eq_iff.mpr ⟨by exact_mod_cast hlo_f, by push_cast at hhi_f ⊢; linarith⟩).symm

/-- Discrete cap vector family decoded from MSB-first `b`-bit blocks via `polySample1D`. -/
noncomputable def polyFDisc {R ℓ M₀ d b : ℕ} (T p_coord : ℕ)
    (ω : ExplicitBitSeed R ℓ M₀ (d + 1) b) :
    ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
  fun idx => ratPointToEuclidean (fun j =>
    polySample1D b T p_coord (bitsFnToFin b (fun bitIdx => ω (idx, j, bitIdx))))

/-- Order-independent good filter property guaranteeing that ANY `cap_q`-capped query scan over
`cap_u`-capped buckets succeeds on all surviving subsets `P ⊆ gen.P₀` and compatible queries in `Q_net`. -/
def IsOrderIndepGoodFilter {ι : Type} [DecidableEq ι] {R ℓ M₀ d : ℕ}
    (F : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)))
    (τ_d τ_q : ℝ) (cap_u cap_q : ℕ)
    (gen : SearchGeneration ι (d + 1))
    (Q_net : List (EuclideanSpace ℝ (Fin (d + 1)))) : Prop :=
  open Classical in
  ∀ i_star ∈ gen.P₀, ∀ z ∈ Q_net,
    gen.h ≤ inner ℝ (gen.pts i_star) z →
    ∃ r : Fin R,
      (∃ τ : Fin ℓ → Fin M₀,
        (∀ s : Fin ℓ, gaussianDataTest τ_d (F (r, s, τ s)) (gen.pts i_star)) ∧
        (∀ s : Fin ℓ, gaussianDataTest τ_q (F (r, s, τ s)) z)) ∧
      (Fintype.piFinset (fun s : Fin ℓ => explicitDataBaseSet F τ_d (gen.pts i_star) r s)).card ≤ cap_u ∧
      (Fintype.piFinset (fun s : Fin ℓ => explicitQueryBaseSet F τ_q z r s)).card ≤ cap_q ∧
      ((gen.P₀ ×ˢ Fintype.piFinset (fun s : Fin ℓ => explicitQueryBaseSet F τ_q z r s)).filter
        (fun it : ι × (Fin ℓ → Fin M₀) => (∀ s : Fin ℓ, gaussianDataTest τ_d (F (r, s, it.2 s)) (gen.pts it.1)) ∧
          inner ℝ (gen.pts it.1) z ≤ 0)).card ≤ cap_q


/-- Any `cap_q`-capped query scan over ANY duplicate-free tuple enumeration and ANY duplicate-free
bucket lists storing `explicitStoredTuples` succeeds whenever `IsOrderIndepGoodFilter` holds! -/
theorem orderIndep_bucketQuery_correct {ι : Type} [DecidableEq ι] {R ℓ M₀ d : ℕ}
    (F : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)))
    (τ_d τ_q : ℝ) (cap_u cap_q : ℕ)
    (gen : SearchGeneration ι (d + 1))
    (Q_net : List (EuclideanSpace ℝ (Fin (d + 1))))
    (hGood : IsOrderIndepGoodFilter F τ_d τ_q cap_u cap_q gen Q_net)
    (P : Finset ι) (hP : gen.IsSurvivingSubset P)
    (q : SearchQuery ι (d + 1)) (hqz : q.z ∈ Q_net) (hcompat : gen.IsCompatible P q)
    (ans : Option ι)
    -- Soundness of `ans`: if `ans = some i`, then `i ∈ P ∧ q.accept i`
    (h_sound : ∀ i, ans = some i → i ∈ P ∧ q.accept i)
    -- Completeness per copy `r`: if copy `r` has `|QSet_r| ≤ cap_q` and `≤ cap_q` bad pairs `(i, τ)`
    -- and contains an accepted `(i_star, τ_star)` in its stored buckets, `ans ≠ none`
    (h_complete :
      open Classical in
      (∀ r : Fin R,
        let QSet := Fintype.piFinset (fun s : Fin ℓ => explicitQueryBaseSet F τ_q q.z r s)
        QSet.card ≤ cap_q →
        ((gen.P₀ ×ˢ QSet).filter (fun it =>
          (∀ s : Fin ℓ, gaussianDataTest τ_d (F (r, s, it.2 s)) (gen.pts it.1)) ∧
            inner ℝ (gen.pts it.1) q.z ≤ 0)).card ≤ cap_q →
        (∃ i_star ∈ P, ∃ τ_star ∈ QSet,
          τ_star ∈ explicitStoredTuples F τ_d cap_u gen.pts r i_star ∧ q.accept i_star) →
        ans ≠ none)) :
    gen.IsCorrectAnswer P q ans := by
  refine ⟨?_, ?_⟩
  · cases ans with
    | none => trivial
    | some i => exact h_sound i rfl
  · rintro hans_none ⟨i_star, hi_star_P, htarget⟩
    have hi_star_P0 : i_star ∈ gen.P₀ := hP hi_star_P
    have hacc_star : q.accept i_star := by
      by_contra hrej
      have hle0 : inner ℝ (gen.pts i_star) q.z ≤ 0 := hcompat i_star hi_star_P hrej
      have hpos : 0 < gen.h := gen.h_pos
      have ht : gen.h ≤ inner ℝ (gen.pts i_star) q.z := htarget
      linarith
    obtain ⟨r, ⟨τ_star, hτ_d, hτ_q⟩, hcu, hcq, hcbad⟩ := hGood i_star hi_star_P0 q.z hqz htarget
    refine h_complete r hcq hcbad ⟨i_star, hi_star_P, τ_star, ?_, ?_, hacc_star⟩ ?_
    · simp only [Fintype.mem_piFinset, explicitQueryBaseSet, Finset.mem_filter, Finset.mem_univ, true_and]
      exact hτ_q
    · unfold explicitStoredTuples
      dsimp only
      rw [if_pos hcu]
      simp only [Fintype.mem_piFinset, explicitDataBaseSet, Finset.mem_filter, Finset.mem_univ, true_and]
      exact hτ_d
    · exact hans_none

private lemma poly_bad_event_and_agree
    {ℓ C_net_nat C_M_nat d L_log R M₀ : ℕ}
    (hR_eq : R = R_fn C_net_nat d L_log)
    (hM₀_le_2EM : (M₀ : ℝ) ≤ (2 : ℝ) ^ (E_M_fn C_M_nat L_log))
    {ι : Type} [DecidableEq ι] (gen : SearchGeneration ι (d + 1))
    {x ε₀ t_ideal : ℝ} (hε₀_pos : 0 < ε₀)
    {τ_d τ_q : ℚ} (ht_d_eq : (τ_d : ℝ) = t_ideal)
    (hτ_q_eq : τ_q = τ_q_of (b_fn ℓ C_net_nat C_M_nat d L_log) x t_ideal)
    (hm_2 : (gen.m : ℝ) ≤ (2 : ℝ) ^ (2 * L_log))
    (h4_div_eps_le : 4 / ε₀ ≤ (2 : ℝ) ^ (2 * L_log + 1))
    (Q_net : List (EuclideanSpace ℝ (Fin (d + 1))))
    (hQ_unit : ∀ z ∈ Q_net, IsUnitVec z)
    (hQ_pow2 : (Q_net.length : ℝ) ≤ (2 : ℝ) ^ (2 * (C_net_nat * d * (d + L_log)))) :
    ∃ B_bad : Set (ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1))),
      MeasurableSet B_bad ∧
      (Measure.pi (fun _ : ExplicitCapIdx R ℓ M₀ =>
        stdGaussianMeasure (d + 1))).real B_bad ≤ ε₀ / 2 ∧
      (∀ ω_c ∈ B_badᶜ, ∀ idx : ExplicitCapIdx R ℓ M₀,
        let b := b_fn ℓ C_net_nat C_M_nat d L_log
        let T := T_fn ℓ C_net_nat C_M_nat d L_log
        let p_coord := p_coord_fn ℓ C_net_nat C_M_nat d L_log
        let G_disc := ratPointToEuclidean (fun j =>
          polySample1D b T p_coord (bitsEquiv b (fun bitIdx =>
            projBitsMap (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1)
              (b_fn_pos ℓ C_net_nat C_M_nat d L_log) ω_c (idx, j, bitIdx))))
        (∀ i ∈ gen.P₀,
          gaussianDataTest (τ_d : ℝ) G_disc (gen.pts i) ↔
            gaussianDataTest t_ideal (ω_c idx) (gen.pts i)) ∧
        (∀ z ∈ Q_net,
          gaussianDataTest (τ_q : ℝ) G_disc z ↔
            gaussianQueryTest x t_ideal (ω_c idx) z)) := by
  let Ω_cpl : Type := ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1))
  let μ_cpl : Measure Ω_cpl :=
    Measure.pi (fun _ : ExplicitCapIdx R ℓ M₀ => stdGaussianMeasure (d + 1))
  have hb_pos : 1 ≤ b_fn ℓ C_net_nat C_M_nat d L_log := b_fn_pos ℓ C_net_nat C_M_nat d L_log
  set K_tail := K_tail_fn ℓ C_net_nat C_M_nat d L_log with hK_def
  set T := T_fn ℓ C_net_nat C_M_nat d L_log with hT_def
  set p_bits := p_bits_fn ℓ C_net_nat C_M_nat d L_log with hpb_def
  set p_coord := p_coord_fn ℓ C_net_nat C_M_nat d L_log with hpc_def
  set b := b_fn ℓ C_net_nat C_M_nat d L_log with hb_def
  let B_box : Set Ω_cpl :=
    {ω_c | ∃ (idx : ExplicitCapIdx R ℓ M₀) (j : Fin (d + 1)),
      (T : ℝ) < |euclideanCoord (ω_c idx) j|}
  have hB_box_meas : MeasurableSet B_box := by
    have heq : B_box = ⋃ idx : ExplicitCapIdx R ℓ M₀, ⋃ j : Fin (d + 1),
        {ω_c : Ω_cpl | (T : ℝ) < |euclideanCoord (ω_c idx) j|} := by
      ext ω_c; simp [B_box]
    rw [heq]
    refine MeasurableSet.iUnion fun idx => MeasurableSet.iUnion fun j => ?_
    exact measurableSet_lt measurable_const
      (continuous_abs.measurable.comp ((measurable_euclideanCoord j).comp (measurable_pi_apply idx)))
  have hB_box_prob : μ_cpl.real B_box ≤ ε₀ / 4 := by
    have h1 := pi_coord_abs_gt_prob_le (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1) T
    refine h1.trans ?_
    have hprod_le : ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) * 2 * (4 / ε₀) ≤ (2 : ℝ) ^ K_tail := by
      push_cast
      have hR_2 : (R : ℝ) ≤ (2 : ℝ) ^ R := UL.Proof_lem_6_3.nat_cast_le_two_pow R
      have hl_2 : (ℓ : ℝ) ≤ (2 : ℝ) ^ ℓ := UL.Proof_lem_6_3.nat_cast_le_two_pow ℓ
      have hd_2 : ((d : ℝ) + 1) ≤ (2 : ℝ) ^ (d + 1) := by
        exact_mod_cast (Nat.lt_two_pow_self (n := d + 1)).le
      calc (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((d : ℝ) + 1) * 2 * (4 / ε₀)
          ≤ (2 : ℝ) ^ R * (2 : ℝ) ^ ℓ * (2 : ℝ) ^ (E_M_fn C_M_nat L_log) * (2 : ℝ) ^ (d + 1) *
              (2 : ℝ) ^ 1 * (2 : ℝ) ^ (2 * L_log + 1) := by
            have p1 := mul_le_mul hR_2 hl_2 (by positivity) (by positivity)
            have p2 := mul_le_mul p1 hM₀_le_2EM (by positivity) (by positivity)
            have p3 := mul_le_mul p2 hd_2 (by positivity) (by positivity)
            have p4 : (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((d : ℝ) + 1) * 2 ≤
                (2 : ℝ) ^ R * (2 : ℝ) ^ ℓ * (2 : ℝ) ^ (E_M_fn C_M_nat L_log) *
                  (2 : ℝ) ^ (d + 1) * (2 : ℝ) ^ 1 := by
              simpa using mul_le_mul_of_nonneg_right p3 (by norm_num : (0 : ℝ) ≤ 2)
            exact mul_le_mul p4 h4_div_eps_le (by positivity) (by positivity)
        _ = (2 : ℝ) ^ K_tail := by
            rw [hR_eq, hK_def]; unfold K_tail_fn
            simp only [← pow_add]
            congr 1; omega
    have hexp_T : (2 : ℝ) ^ K_tail * Real.exp (-((T : ℝ) ^ 2 / 2)) ≤ 1 := by
      have h2K : (2 : ℝ) ^ K_tail ≤ Real.exp (K_tail : ℝ) := by
        calc (2 : ℝ) ^ K_tail ≤ (Real.exp 1) ^ K_tail :=
              pow_le_pow_left₀ (by norm_num) UL.Proof_lem_6_3.two_le_exp_one K_tail
          _ = Real.exp (K_tail : ℝ) := by simp [← Real.exp_nat_mul]
      have hKT2 : (K_tail : ℝ) ≤ (T : ℝ) ^ 2 / 2 := by
        have hnat : 2 * K_tail ≤ T ^ 2 := by
          rw [hT_def]; unfold T_fn; rw [← hK_def]
          exact two_mul_le_add_two_sq K_tail
        have hreal : (2 : ℝ) * (K_tail : ℝ) ≤ (T : ℝ) ^ 2 := by exact_mod_cast hnat
        linarith
      calc (2 : ℝ) ^ K_tail * Real.exp (-((T : ℝ) ^ 2 / 2))
          ≤ Real.exp ((T : ℝ) ^ 2 / 2) * Real.exp (-((T : ℝ) ^ 2 / 2)) :=
            mul_le_mul_of_nonneg_right (h2K.trans (Real.exp_le_exp.mpr hKT2)) (Real.exp_pos _).le
        _ = 1 := by rw [← Real.exp_add, add_neg_cancel, Real.exp_zero]
    have hle1 := (mul_le_mul_of_nonneg_right hprod_le (Real.exp_pos (-((T : ℝ) ^ 2 / 2))).le).trans hexp_T
    have hmul_eps := mul_le_mul_of_nonneg_left hle1 (by positivity : 0 ≤ ε₀ / 4)
    have hsimp : (ε₀ / 4) * (((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) * 2 * (4 / ε₀) *
        Real.exp (-((T : ℝ) ^ 2 / 2))) =
        ((R * ℓ * M₀ * (d + 1) : ℕ) : ℝ) * (2 * Real.exp (-((T : ℝ) ^ 2 / 2))) := by
      field_simp
    linarith
  set Δ : ℝ := (2 : ℝ) ^ (-(p_bits : ℤ)) with hΔ_def
  have hΔ_pos : 0 < Δ := by positivity
  let idx_list : List (ExplicitCapIdx R ℓ M₀) := Finset.univ.toList
  let uz_list : List (EuclideanSpace ℝ (Fin (d + 1)) × ℝ) :=
    (gen.P₀.toList.map (fun i => (gen.pts i, t_ideal))) ++
      (Q_net.map (fun z => (z, x * t_ideal)))
  let cmps : List (ExplicitCapIdx R ℓ M₀ × EuclideanSpace ℝ (Fin (d + 1)) × ℝ) :=
    idx_list.flatMap (fun idx => uz_list.map (fun uz => (idx, uz.1, uz.2)))
  have hcmps_unit : ∀ c ∈ cmps, IsUnitVec c.2.1 := by
    intro c hc
    rcases List.mem_flatMap.mp hc with ⟨idx, _, hc_map⟩
    rcases List.mem_map.mp hc_map with ⟨uz, huz, rfl⟩
    rcases List.mem_append.mp huz with huz_d | huz_q
    · rcases List.mem_map.mp huz_d with ⟨i, hi_l, rfl⟩
      exact gen.unit_pts i (Finset.mem_toList.mp hi_l)
    · rcases List.mem_map.mp huz_q with ⟨z, hz_Q, rfl⟩
      exact hQ_unit z hz_Q
  have hcmps_len : cmps.length = (R * ℓ * M₀) * (gen.m + Q_net.length) := by
    dsimp [cmps]
    rw [length_flatMap_map]
    have h1 : idx_list.length = R * ℓ * M₀ := by simp [idx_list, ExplicitCapIdx, mul_assoc]
    have h2 : uz_list.length = gen.m + Q_net.length := by simp [uz_list, SearchGeneration.m]
    rw [h1, h2]
  let B_cmps : Set Ω_cpl :=
    {ω_c | ∃ c ∈ cmps, inner ℝ (ω_c c.1) c.2.1 ∈ Set.Icc (c.2.2 - Δ) (c.2.2 + Δ)}
  have hB_cmps_meas : MeasurableSet B_cmps := by
    refine measurableSet_exists_mem_list cmps
      (fun c => {ω_c : Ω_cpl | inner ℝ (ω_c c.1) c.2.1 ∈ Set.Icc (c.2.2 - Δ) (c.2.2 + Δ)}) ?_
    intro c _
    exact measurableSet_Icc.preimage
      (((continuous_id.inner continuous_const).measurable).comp (measurable_pi_apply c.1))
  have hB_cmps_prob : μ_cpl.real B_cmps ≤ ε₀ / 4 := by
    have h1 : μ_cpl.real B_cmps ≤ (cmps.length : ℝ) * Δ :=
      measureReal_exists_mem_list_le μ_cpl cmps _ hΔ_pos.le
        (fun c hc => pi_coord_inner_Icc_le_delta c.1 c.2.1 (hcmps_unit c hc) c.2.2 Δ hΔ_pos.le)
    refine h1.trans ?_
    rw [hcmps_len]
    push_cast
    let E_mQ := 2 * L_log + 2 * (C_net_nat * d * (d + L_log))
    have hmQ_2 : (gen.m : ℝ) + (Q_net.length : ℝ) ≤ (2 : ℝ) ^ (E_mQ + 1) := by
      have ha : (2 : ℝ) ^ (2 * L_log) ≤ (2 : ℝ) ^ E_mQ :=
        pow_le_pow_right₀ (by norm_num) (by dsimp [E_mQ]; omega)
      have hb2 : (2 : ℝ) ^ (2 * (C_net_nat * d * (d + L_log))) ≤ (2 : ℝ) ^ E_mQ :=
        pow_le_pow_right₀ (by norm_num) (by dsimp [E_mQ]; omega)
      calc (gen.m : ℝ) + (Q_net.length : ℝ)
          ≤ (2 : ℝ) ^ E_mQ + (2 : ℝ) ^ E_mQ := add_le_add (hm_2.trans ha) (hQ_pow2.trans hb2)
        _ = (2 : ℝ) ^ (E_mQ + 1) := by rw [pow_succ]; ring
    have hprod_p : (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((gen.m : ℝ) + (Q_net.length : ℝ)) * (4 / ε₀) ≤
        (2 : ℝ) ^ p_bits := by
      have hR_2 : (R : ℝ) ≤ (2 : ℝ) ^ R := UL.Proof_lem_6_3.nat_cast_le_two_pow R
      have hl_2 : (ℓ : ℝ) ≤ (2 : ℝ) ^ ℓ := UL.Proof_lem_6_3.nat_cast_le_two_pow ℓ
      calc (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((gen.m : ℝ) + (Q_net.length : ℝ)) * (4 / ε₀)
          ≤ (2 : ℝ) ^ R * (2 : ℝ) ^ ℓ * (2 : ℝ) ^ (E_M_fn C_M_nat L_log) *
              (2 : ℝ) ^ (E_mQ + 1) * (2 : ℝ) ^ (2 * L_log + 1) := by
            have p1 := mul_le_mul hR_2 hl_2 (by positivity) (by positivity)
            have p2 := mul_le_mul p1 hM₀_le_2EM (by positivity) (by positivity)
            have p3 := mul_le_mul p2 hmQ_2 (by positivity) (by positivity)
            exact mul_le_mul p3 h4_div_eps_le (by positivity) (by positivity)
        _ = (2 : ℝ) ^ p_bits := by
            rw [hR_eq, hpb_def]; unfold p_bits_fn
            dsimp only [E_mQ]
            simp only [← pow_add]
            congr 1; ring
    have hcancel : (2 : ℝ) ^ p_bits * Δ = 1 := by
      rw [hΔ_def, ← zpow_natCast, ← zpow_add₀ (by norm_num), add_neg_cancel, zpow_zero]
    have hmul1 := (mul_le_mul_of_nonneg_right hprod_p hΔ_pos.le).trans_eq hcancel
    have hmul2 := mul_le_mul_of_nonneg_left hmul1 (by positivity : 0 ≤ ε₀ / 4)
    have hsimp : (ε₀ / 4) * ((R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) *
        ((gen.m : ℝ) + (Q_net.length : ℝ)) * (4 / ε₀) * Δ) =
        (R : ℝ) * (ℓ : ℝ) * (M₀ : ℝ) * ((gen.m : ℝ) + (Q_net.length : ℝ)) * Δ := by
      field_simp
    linarith
  let B_bad : Set Ω_cpl := B_box ∪ B_cmps
  have hB_bad_meas : MeasurableSet B_bad := hB_box_meas.union hB_cmps_meas
  have hB_bad_prob : μ_cpl.real B_bad ≤ ε₀ / 2 := by
    have := UL.Proof_lem_6_3.measureReal_union_le_add μ_cpl B_box B_cmps
    linarith
  refine ⟨B_bad, hB_bad_meas, hB_bad_prob, ?_⟩
  intro ω_c hω idx
  have hnot_box : ω_c ∉ B_box := fun h => hω (Or.inl h)
  have hnot_cmps : ω_c ∉ B_cmps := fun h => hω (Or.inr h)
  set G_disc := ratPointToEuclidean (fun j =>
    polySample1D b T p_coord (bitsEquiv b (fun bitIdx =>
      projBitsMap (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1)
        (b_fn_pos ℓ C_net_nat C_M_nat d L_log) ω_c (idx, j, bitIdx)))) with hG_def
  have hnorm_diff : ‖G_disc - ω_c idx‖ ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := by
    have hcoord : ∀ j : Fin (d + 1),
        |euclideanCoord G_disc j - euclideanCoord (ω_c idx) j| ≤
          (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) := by
      intro j
      have hj_box : |euclideanCoord (ω_c idx) j| ≤ (T : ℝ) := by
        by_contra hgt; push_neg at hgt; exact hnot_box ⟨idx, j, hgt⟩
      have hb_eq : b = ((T + 1) ^ 2 + 2) + p_coord + 2 := by
        rw [hb_def, hT_def, hpc_def]; unfold b_fn m_exp_fn; rfl
      have hbin_eq : bitsEquiv b (fun bitIdx =>
            projBitsMap (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1)
              (b_fn_pos ℓ C_net_nat C_M_nat d L_log) ω_c (idx, j, bitIdx)) =
          binIdx b hb_pos (euclideanCoord (ω_c idx) j) := by
        dsimp [b, projBitsMap, encode1D]
        exact (bitsEquiv _).apply_symm_apply _
      have heq_c : euclideanCoord G_disc j =
          ((polySample1D b T p_coord (binIdx b hb_pos (euclideanCoord (ω_c idx) j)) : ℚ) : ℝ) := by
        rw [hG_def, euclideanCoord_ratPointToEuclidean, hbin_eq]
      rw [heq_c]
      exact polySample1D_approx_on_box hb_eq hb_pos hj_box
    have h1 := euclidean_norm_sub_le_of_coord (by positivity) hcoord
    refine h1.trans ?_
    have hdp1 : ((d + 1 : ℕ) : ℝ) ≤ (2 : ℝ) ^ ((d + 1 : ℕ) : ℤ) := by
      rw [zpow_natCast]; exact UL.Proof_lem_6_3.nat_cast_le_two_pow (d + 1)
    calc ((d + 1 : ℕ) : ℝ) * (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ))
        ≤ (2 : ℝ) ^ ((d + 1 : ℕ) : ℤ) * (2 : ℝ) ^ (-((p_coord + 1 : ℕ) : ℤ)) :=
          mul_le_mul_of_nonneg_right hdp1 (by positivity)
      _ = (2 : ℝ) ^ (((d + 1 : ℕ) : ℤ) + -((p_coord + 1 : ℕ) : ℤ)) :=
          (zpow_add₀ (by norm_num) _ _).symm
      _ ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) :=
          zpow_le_zpow_right₀ (by norm_num)
            (by rw [hpc_def]; unfold p_coord_fn; rw [← hpb_def]; omega)
  have hτq_err : |(τ_q : ℝ) - x * t_ideal| ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := by
    have h2b_pos : (0 : ℝ) < ((2 ^ b : ℕ) : ℝ) := by positivity
    have htq_eq : (τ_q : ℝ) = (⌊x * t_ideal * ((2 ^ b : ℕ) : ℝ)⌋ : ℝ) / ((2 ^ b : ℕ) : ℝ) := by
      rw [hτ_q_eq, τ_q_of]; push_cast; rfl
    have hhi : (τ_q : ℝ) ≤ x * t_ideal := by
      rw [htq_eq, div_le_iff₀ h2b_pos]; exact Int.floor_le _
    have hlo : x * t_ideal - (((2 ^ b : ℕ) : ℝ))⁻¹ ≤ (τ_q : ℝ) := by
      rw [htq_eq, ← one_div, le_div_iff₀ h2b_pos]
      have := (Int.sub_one_lt_floor (x * t_ideal * ((2 ^ b : ℕ) : ℝ))).le
      have hmul : (x * t_ideal - 1 / ((2 ^ b : ℕ) : ℝ)) * ((2 ^ b : ℕ) : ℝ) =
          x * t_ideal * ((2 ^ b : ℕ) : ℝ) - 1 := by field_simp
      linarith
    have habs : |(τ_q : ℝ) - x * t_ideal| ≤ (2 : ℝ) ^ (-(b : ℤ)) := by
      have h2b_inv : (((2 ^ b : ℕ) : ℝ))⁻¹ = (2 : ℝ) ^ (-(b : ℤ)) := by
        rw [zpow_neg, zpow_natCast]; push_cast; rfl
      rw [← h2b_inv, abs_le]
      exact ⟨by linarith, by linarith [inv_nonneg.mpr h2b_pos.le]⟩
    exact habs.trans (zpow_le_zpow_right₀ (by norm_num)
      (by rw [hb_def]; unfold b_fn p_coord_fn; rw [← hpb_def]; omega))
  have hhalf_Δ : (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) + (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) = Δ := by
    rw [hΔ_def]
    have heq : -(p_bits : ℤ) = -((p_bits + 1 : ℕ) : ℤ) + 1 := by omega
    rw [heq, zpow_add₀ (by norm_num), zpow_one]; ring
  have hidx_mem : idx ∈ idx_list := Finset.mem_toList.mpr (Finset.mem_univ idx)
  refine ⟨?_, ?_⟩
  · intro i hi
    have h_in_cmps : (idx, gen.pts i, t_ideal) ∈ cmps := by
      refine List.mem_flatMap.mpr ⟨idx, hidx_mem, List.mem_map.mpr ⟨(gen.pts i, t_ideal), ?_, rfl⟩⟩
      exact List.mem_append_left _ (List.mem_map.mpr ⟨i, Finset.mem_toList.mpr hi, rfl⟩)
    have hnot_Icc : inner ℝ (ω_c idx) (gen.pts i) ∉ Set.Icc (t_ideal - Δ) (t_ideal + Δ) :=
      fun hmem => hnot_cmps ⟨(idx, gen.pts i, t_ideal), h_in_cmps, hmem⟩
    have hcs : |inner ℝ (G_disc - ω_c idx) (gen.pts i)| ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := by
      calc |inner ℝ (G_disc - ω_c idx) (gen.pts i)|
          ≤ ‖G_disc - ω_c idx‖ * ‖gen.pts i‖ := abs_real_inner_le_norm _ _
        _ = ‖G_disc - ω_c idx‖ := by rw [gen.unit_pts i hi, mul_one]
        _ ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := hnorm_diff
    have hdiff : |(τ_d : ℝ) - t_ideal| + |inner ℝ (G_disc - ω_c idx) (gen.pts i)| ≤ Δ := by
      have ht0 : |(τ_d : ℝ) - t_ideal| = 0 := by rw [ht_d_eq, sub_self, abs_zero]
      rw [ht0]
      linarith [(by positivity : (0 : ℝ) ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)))]
    exact test_iff_of_two_sided_margin hdiff hnot_Icc
  · intro z hz
    have h_in_cmps : (idx, z, x * t_ideal) ∈ cmps := by
      refine List.mem_flatMap.mpr ⟨idx, hidx_mem, List.mem_map.mpr ⟨(z, x * t_ideal), ?_, rfl⟩⟩
      exact List.mem_append_right _ (List.mem_map.mpr ⟨z, hz, rfl⟩)
    have hnot_Icc : inner ℝ (ω_c idx) z ∉ Set.Icc (x * t_ideal - Δ) (x * t_ideal + Δ) :=
      fun hmem => hnot_cmps ⟨(idx, z, x * t_ideal), h_in_cmps, hmem⟩
    have hcs : |inner ℝ (G_disc - ω_c idx) z| ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := by
      calc |inner ℝ (G_disc - ω_c idx) z|
          ≤ ‖G_disc - ω_c idx‖ * ‖z‖ := abs_real_inner_le_norm _ _
        _ = ‖G_disc - ω_c idx‖ := by rw [hQ_unit z hz, mul_one]
        _ ≤ (2 : ℝ) ^ (-((p_bits + 1 : ℕ) : ℤ)) := hnorm_diff
    have hdiff : |(τ_q : ℝ) - x * t_ideal| + |inner ℝ (G_disc - ω_c idx) z| ≤ Δ := by
      linarith
    exact test_iff_of_two_sided_margin hdiff hnot_Icc

open Classical in
/-- Master finite-coin cardinality theorem for `polyFDisc` + `IsOrderIndepGoodFilter`. -/
theorem polyFilter_goodCoins_card_ge
    {h_min h_max : ℝ} (hh_min : 0 < h_min) (hh_le : h_min ≤ h_max) (hh_max : h_max < 1)
    {ℓ : ℕ} (hℓ : 1 ≤ ℓ)
    (h_lem_6_2_inst :
      ∃ c_h : ℝ, 0 < c_h ∧
        ∀ (d : ℕ), 1 ≤ d →
          ∀ (h x t : ℝ), h_min ≤ h → h ≤ h_max → h ≤ x → x ≤ 1 → 1 ≤ t →
            ∃ p_u p_q p₁ p₂ : ℝ,
              IsGaussianFilterProbs d h x t p_u p_q p₁ p₂ ∧
              p_u ≤ Real.exp (-(t ^ 2 / 2)) ∧
              p_q ≤ Real.exp (-(x ^ 2 * t ^ 2 / 2)) ∧
              c_h * t ^ (-2 : ℤ) * Real.exp (-(I_h h x * t ^ 2 / 2)) ≤ p₁ ∧
              p₂ ≤ Real.exp (-((1 + x ^ 2) * t ^ 2 / 2)))
    (C_net : ℝ) (_hC_net : 0 ≤ C_net) :
    ∃ (C_net_nat C_M_nat : ℕ),
      ∀ {d : ℕ}, 1 ≤ d → ∀ {ι : Type} [DecidableEq ι]
        (gen : SearchGeneration ι (d + 1)),
        h_min ≤ gen.h → gen.h ≤ h_max →
        ∀ {x η ε₀ : ℝ},
          gen.h ≤ x → x ≤ 1 →
          0 < η → η ≤ 1 →
          0 < ε₀ → ε₀ < 1 →
          ∀ (Q_net : List (EuclideanSpace ℝ (Fin (d + 1)))),
            (∀ z ∈ Q_net, IsUnitVec z) →
            (Q_net.length : ℝ) ≤ Real.exp (C_net * (d : ℝ) * Real.log (2 * (d : ℝ) / η)) →
            let L_log : ℕ := Nat.ceil (Real.log (2 * (gen.m : ℝ) / ε₀) + Real.log (2 / η))
            let R : ℕ := R_fn C_net_nat d L_log
            let T : ℕ := T_fn ℓ C_net_nat C_M_nat d L_log
            let p_coord : ℕ := p_coord_fn ℓ C_net_nat C_M_nat d L_log
            let b : ℕ := b_fn ℓ C_net_nat C_M_nat d L_log
            let τ_d : ℚ := τ_d_of ℓ gen.m L_log
            let M₀ : ℕ := M₀_of C_M_nat gen.h x (τ_d : ℝ)
            let cap_u : ℕ := cap_u_of ℓ M₀ (τ_d : ℝ)
            let cap_q : ℕ := cap_q_of ℓ M₀ x (τ_d : ℝ)
            let τ_q : ℚ := τ_q_of b x (τ_d : ℝ)
            1 ≤ R ∧ 1 ≤ M₀ ∧ 1 ≤ cap_u ∧ 1 ≤ cap_q ∧ 1 ≤ b ∧
            ((R * ℓ * M₀ : ℕ) : ℝ) ≤
              (gen.m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ)) * poly_cap_fn ℓ C_net_nat C_M_nat d L_log ∧
            (cap_u : ℝ) ≤
              (gen.m : ℝ) ^ (u_search gen.h x) * poly_cap_fn ℓ C_net_nat C_M_nat d L_log ∧
            (cap_q : ℝ) ≤
              (gen.m : ℝ) ^ (q_search gen.h x) * poly_cap_fn ℓ C_net_nat C_M_nat d L_log ∧
            (1 - ε₀) * (Fintype.card (ExplicitBitSeed R ℓ M₀ (d + 1) b) : ℝ) ≤
              ((Finset.univ.filter (fun ω : ExplicitBitSeed R ℓ M₀ (d + 1) b =>
                IsOrderIndepGoodFilter (polyFDisc T p_coord ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen Q_net)).card : ℝ) := by
  have _ := hh_min; have _ := hh_le; have _ := hh_max
  rcases h_lem_6_2_inst with ⟨c_h, hc_h_pos, h_lem_6_2_spec⟩
  have hCnet_le : C_net ≤ ((Nat.ceil C_net + 1 : ℕ) : ℝ) :=
    (Nat.le_ceil C_net).trans (by push_cast; exact le_add_of_nonneg_right zero_le_one)
  have hCM_ge : Real.log (100 * (ℓ : ℝ)) / c_h ≤
      ((Nat.ceil (Real.log (100 * (ℓ : ℝ)) / c_h) + 1 : ℕ) : ℝ) :=
    (Nat.le_ceil (Real.log (100 * (ℓ : ℝ)) / c_h)).trans
      (by push_cast; exact le_add_of_nonneg_right zero_le_one)
  refine ⟨Nat.ceil C_net + 1, Nat.ceil (Real.log (100 * (ℓ : ℝ)) / c_h) + 1, ?_⟩
  set C_net_nat : ℕ := Nat.ceil C_net + 1
  clear_value C_net_nat
  set C_M_nat : ℕ := Nat.ceil (Real.log (100 * (ℓ : ℝ)) / c_h) + 1
  clear_value C_M_nat
  intro d hd ι _instDec gen hh_ge hh_le_max x η ε₀ hx_ge hx_le hη_pos hη_le hε₀_pos hε₀_lt Q_net hQ_unit hQ_len L_log R T p_coord b τ_d M₀ cap_u cap_q τ_q
  have hm_pos : 1 ≤ gen.m := gen.nonempty.card_pos
  rcases part4_L_and_Q_bounds hd hm_pos hCnet_le hη_pos hη_le hε₀_pos hε₀_lt hQ_len rfl
    with ⟨_hL_pos, hm_2, hlog_m_le_L, h4_div_eps_le, hQ_pow2, h10R_le⟩
  rcases part4_threshold_bounds (C_net_nat := C_net_nat) (C_M_nat := C_M_nat) (d := d)
    hℓ hm_pos hlog_m_le_L
    with ⟨ht_ge1, ht_le_Lp2, hm_le_exp_lt2, hexp_lt2_le_Sm, _⟩
  set t_ideal : ℝ := (τ_d : ℝ) with ht_d_eq_symm
  have ht_d_eq : (τ_d : ℝ) = t_ideal := ht_d_eq_symm.symm
  rcases h_lem_6_2_spec (d + 1) (by omega) gen.h x t_ideal hh_ge hh_le_max hx_ge hx_le ht_ge1
    with ⟨p_u, p_q, p₁, p₂, hprobs, hp_u, hp_q, hp₁, hp₂⟩
  rcases gen.nonempty with ⟨i₀, hi₀⟩
  have hp_u_nn : 0 ≤ p_u := by
    rw [← hprobs.2.1 (gen.pts i₀) (gen.unit_pts i₀ hi₀)]; exact MeasureTheory.measureReal_nonneg
  have hp_q_nn : 0 ≤ p_q := by
    rw [← hprobs.2.2.1 (gen.pts i₀) (gen.unit_pts i₀ hi₀)]; exact MeasureTheory.measureReal_nonneg
  have hp₂_nn : 0 ≤ p₂ := by
    have hu0 : IsUnitVec (gen.pts i₀) := gen.unit_pts i₀ hi₀
    have hu_neg : IsUnitVec (-gen.pts i₀) := by unfold IsUnitVec at hu0 ⊢; rw [norm_neg]; exact hu0
    have hneg_inner : inner ℝ (gen.pts i₀) (-gen.pts i₀) ≤ 0 := by
      rw [inner_neg_right, real_inner_self_eq_norm_sq, hu0]; norm_num
    exact MeasureTheory.measureReal_nonneg.trans
      (hprobs.2.2.2.2 (gen.pts i₀) (-gen.pts i₀) hu0 hu_neg hneg_inner)
  rcases part4_prob_cap_reqs hℓ hm_pos hc_h_pos hCM_ge ht_ge1 hm_le_exp_lt2
    hp_u_nn hp_q_nn hp₂_nn hp_u hp_q hp₁ hp₂
    with ⟨hp₁_pos, hp₁_M, hCap_u, hCap_q, hCap_bad⟩
  rcases part4_size_and_M0_bounds (C_net_nat := C_net_nat) (d := d)
    hℓ hm_pos gen.h_pos gen.h_lt_one hx_ge hx_le ht_ge1 ht_le_Lp2 hexp_lt2_le_Sm
    with ⟨hM₀_le_2EM, hRlM₀_le_KI, hcap_u_le_Ku, hcap_q_le_Kq⟩
  have hM₀_pos : 1 ≤ M₀ := M₀_of_pos C_M_nat gen.h x t_ideal
  have hCap_u_pos : 1 ≤ cap_u := cap_u_of_pos ℓ M₀ t_ideal
  have hCap_q_pos : 1 ≤ cap_q := cap_q_of_pos ℓ M₀ x t_ideal
  have hR_pos : 1 ≤ R := R_fn_pos C_net_nat d L_log
  have hb_pos : 1 ≤ b := b_fn_pos ℓ C_net_nat C_M_nat d L_log
  rcases part4_det_bounds hℓ hCap_q_pos rfl gen (τ_d := τ_d) (τ_q := τ_q)
    (fun bits => polySample1D b T p_coord (bitsFnToFin b bits))
    hRlM₀_le_KI hcap_u_le_Ku hcap_q_le_Kq
    with ⟨hRlM₀_le_pcap, hcap_u_le_pcap, hcap_q_le_pcap, _⟩
  rcases poly_bad_event_and_agree rfl hM₀_le_2EM gen hε₀_pos ht_d_eq rfl
    hm_2 h4_div_eps_le Q_net hQ_unit hQ_pow2
    with ⟨B_bad, hB_bad_meas, hB_bad_prob, h_agree⟩
  refine ⟨hR_pos, hM₀_pos, hCap_u_pos, hCap_q_pos, hb_pos,
    hRlM₀_le_pcap, hcap_u_le_pcap, hcap_q_le_pcap, ?_⟩
  -- Construct ideal bad event `B_all` across `(i_star, z) ∈ Targets`
  let Ω_cpl := ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1))
  let μ_cpl := Measure.pi (fun _ : ExplicitCapIdx R ℓ M₀ => stdGaussianMeasure (d + 1))
  let enum : Fin gen.m ≃ ↥gen.P₀ := (Finset.equivFin gen.P₀).symm
  let ptsK : Fin gen.m → EuclideanSpace ℝ (Fin (d + 1)) := fun k => gen.pts (enum k).1
  have hunit_ptsK : ∀ k : Fin gen.m, IsUnitVec (ptsK k) :=
    fun k => gen.unit_pts (enum k).1 (enum k).2
  let G_single : (ι × EuclideanSpace ℝ (Fin (d + 1))) →
      Set (Fin (ℓ * M₀) → EuclideanSpace ℝ (Fin (d + 1))) := fun iz =>
    {ω | (∃ τ : Fin ℓ → Fin M₀, UL.Proof_lem_6_3.IsSharedTuple x t_ideal ω (gen.pts iz.1) iz.2 τ) ∧
         UL.Proof_lem_6_3.dataTupleCard t_ideal ω (gen.pts iz.1) ≤ cap_u ∧
         UL.Proof_lem_6_3.queryTupleCard x t_ideal ω iz.2 ≤ cap_q ∧
         UL.Proof_lem_6_3.badSharedCard x t_ideal ptsK iz.2 ω ≤ cap_q}
  let Targets : Finset (ι × EuclideanSpace ℝ (Fin (d + 1))) :=
    (gen.P₀ ×ˢ Q_net.toFinset).filter (fun iz => gen.h ≤ inner ℝ (gen.pts iz.1) iz.2)
  let B_iz : (ι × EuclideanSpace ℝ (Fin (d + 1))) → Set Ω_cpl := fun iz =>
    {F | ∀ r : Fin R, extractCopy r F ∈ (G_single iz)ᶜ}
  have hB_each : ∀ iz ∈ Targets, MeasurableSet (B_iz iz) ∧ μ_cpl.real (B_iz iz) ≤ (1 / 10 : ℝ) ^ R := by
    intro iz hiz
    rcases Finset.mem_filter.mp hiz with ⟨hprod, htar⟩
    rcases Finset.mem_product.mp hprod with ⟨hi_P0, hz_Q⟩
    have hz_mem : iz.2 ∈ Q_net := List.mem_toFinset.mp hz_Q
    rcases UL.Proof_lem_6_3.goodEvent_prob_ge hℓ hM₀_pos hprobs hp₁_pos hp₁_M
      hCap_u_pos hCap_q_pos hCap_u hCap_q hCap_bad ptsK hunit_ptsK
      (gen.unit_pts iz.1 hi_P0) (hQ_unit iz.2 hz_mem) htar with ⟨hG_meas, hG_prob⟩
    have hGc_meas : MeasurableSet (G_single iz)ᶜ := hG_meas.compl
    let μ_single := Measure.pi (fun _ : Fin (ℓ * M₀) => stdGaussianMeasure (d + 1))
    have hGc_prob : μ_single.real (G_single iz)ᶜ ≤ 1 / 10 := by
      rw [UL.Proof_lem_6_3.probReal_compl_eq μ_single hG_meas]; linarith only [hG_prob]
    have hB_meas : MeasurableSet (B_iz iz) := by
      have h_eq : B_iz iz = ⋂ r : Fin R,
          (fun F : Ω_cpl => extractCopy r F) ⁻¹' (G_single iz)ᶜ := by ext F; simp [B_iz]
      rw [h_eq]
      refine MeasurableSet.iInter fun r => hGc_meas.preimage ?_
      rw [measurable_pi_iff]; intro u; exact measurable_pi_apply _
    have hB_prob : μ_cpl.real (B_iz iz) ≤ (1 / 10 : ℝ) ^ R := by
      rw [all_copies_bad_prob_eq (G_single iz)ᶜ hGc_meas]
      exact pow_le_pow_left₀ MeasureTheory.measureReal_nonneg hGc_prob R
    exact ⟨hB_meas, hB_prob⟩
  let B_all := ⋃ iz ∈ Targets, B_iz iz
  have hB_all_meas : MeasurableSet B_all :=
    Finset.measurableSet_biUnion _ fun iz hiz => (hB_each iz hiz).1
  have hTargets_card : Targets.card ≤ gen.m * Q_net.length := by
    calc Targets.card ≤ (gen.P₀ ×ˢ Q_net.toFinset).card := Finset.card_filter_le _ _
      _ = gen.P₀.card * Q_net.toFinset.card := Finset.card_product _ _
      _ ≤ gen.m * Q_net.length := Nat.mul_le_mul_left gen.m (List.toFinset_card_le Q_net)
  have hB_all_prob : μ_cpl.real B_all ≤ ε₀ / 2 := by
    calc μ_cpl.real B_all
        ≤ ∑ iz ∈ Targets, μ_cpl.real (B_iz iz) :=
          UL.Proof_lem_6_3.measureReal_biUnion_finset_le_sum μ_cpl _ _
      _ ≤ ∑ _iz ∈ Targets, (1 / 10 : ℝ) ^ R :=
          Finset.sum_le_sum fun iz hiz => (hB_each iz hiz).2
      _ = (Targets.card : ℝ) * (1 / 10 : ℝ) ^ R := by simp
      _ ≤ ((gen.m * Q_net.length : ℕ) : ℝ) * (1 / 10 : ℝ) ^ R :=
          mul_le_mul_of_nonneg_right (by exact_mod_cast hTargets_card) (by positivity)
      _ = (gen.m : ℝ) * (Q_net.length : ℝ) * (1 / 10 : ℝ) ^ R := by push_cast; ring
      _ ≤ ε₀ / 2 := h10R_le
  let B_tot : Set Ω_cpl := B_bad ∪ B_all
  have hB_tot_meas : MeasurableSet B_tot := hB_bad_meas.union hB_all_meas
  have hB_tot_compl : 1 - ε₀ ≤ μ_cpl.real B_totᶜ := by
    have h1 := UL.Proof_lem_6_3.measureReal_union_le_add μ_cpl B_bad B_all
    have h2 := UL.Proof_lem_6_3.probReal_compl_eq μ_cpl hB_tot_meas
    change μ_cpl.real (B_bad ∪ B_all)ᶜ = 1 - μ_cpl.real (B_bad ∪ B_all) at h2
    change 1 - ε₀ ≤ μ_cpl.real (B_bad ∪ B_all)ᶜ
    linarith only [h1, h2, hB_bad_prob, hB_all_prob]
  -- Transfer via `projBitsMap` to `equivFDisc` (using `bitsEquiv b`), then bijection to `polyFDisc` (`bitsFnToFin b`)
  let Seed := ExplicitBitSeed R ℓ M₀ (d + 1) b
  let equivFDisc : Seed → ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
    fun ω idx => ratPointToEuclidean (fun j =>
      polySample1D b T p_coord (bitsEquiv b (fun bitIdx => ω (idx, j, bitIdx))))
  let E_equiv : Set Seed := {ω | IsOrderIndepGoodFilter (equivFDisc ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen Q_net}
  have hsub_good : B_totᶜ ⊆ projBitsMap hb_pos ⁻¹' E_equiv := by
    intro ω_c hω_c
    have hnot_bad : ω_c ∈ B_badᶜ := fun h => hω_c (Or.inl h)
    have hnot_all : ω_c ∉ B_all := fun h => hω_c (Or.inr h)
    have hagr := h_agree ω_c hnot_bad
    intro i_star hi_star z hz htar
    have hiz_mem : (i_star, z) ∈ Targets :=
      Finset.mem_filter.mpr ⟨Finset.mem_product.mpr ⟨hi_star, List.mem_toFinset.mpr hz⟩, htar⟩
    have hnot_Biz : ω_c ∉ B_iz (i_star, z) := fun hb => hnot_all (Set.mem_biUnion hiz_mem hb)
    simp only [B_iz, Set.mem_setOf_eq, not_forall, Set.mem_compl_iff, not_not] at hnot_Biz
    obtain ⟨r, ⟨⟨τ_star, hτ_d_id, hτ_q_id⟩, hcu_id, hcq_id, hcbad_id⟩⟩ := hnot_Biz
    let F_d := equivFDisc (projBitsMap hb_pos ω_c)
    have hdata_eq : ∀ (s : Fin ℓ) (k : Fin M₀), ∀ i ∈ gen.P₀,
        gaussianDataTest (τ_d : ℝ) (F_d (r, s, k)) (gen.pts i) ↔
          gaussianDataTest t_ideal (extractCopy r ω_c (UL.Proof_lem_6_3.capIdx s k)) (gen.pts i) := by
      intro s k i hi
      rw [extractCopy_capIdx]
      exact (hagr (r, s, k)).1 i hi
    have hquery_eq : ∀ (s : Fin ℓ) (k : Fin M₀),
        gaussianDataTest (τ_q : ℝ) (F_d (r, s, k)) z ↔
          gaussianQueryTest x t_ideal (extractCopy r ω_c (UL.Proof_lem_6_3.capIdx s k)) z := by
      intro s k
      rw [extractCopy_capIdx]
      exact (hagr (r, s, k)).2 z hz
    refine ⟨r, ⟨τ_star, fun s => (hdata_eq s (τ_star s) i_star hi_star).mpr (hτ_d_id s),
        fun s => (hquery_eq s (τ_star s)).mpr (hτ_q_id s)⟩, ?_, ?_, ?_⟩
    · have heq_set : Fintype.piFinset (fun s : Fin ℓ => explicitDataBaseSet F_d (τ_d : ℝ) (gen.pts i_star) r s) =
          Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ =>
            UL.Proof_lem_6_3.IsDataTuple t_ideal (extractCopy r ω_c) (gen.pts i_star) τ) := by
        ext τ
        simp only [Fintype.mem_piFinset, explicitDataBaseSet, Finset.mem_filter, Finset.mem_univ,
          true_and, UL.Proof_lem_6_3.IsDataTuple]
        exact forall_congr' fun s => hdata_eq s (τ s) i_star hi_star
      rw [heq_set]; exact hcu_id
    · have heq_set : Fintype.piFinset (fun s : Fin ℓ => explicitQueryBaseSet F_d (τ_q : ℝ) z r s) =
          Finset.univ.filter (fun τ : Fin ℓ → Fin M₀ =>
            UL.Proof_lem_6_3.IsQueryTuple x t_ideal (extractCopy r ω_c) z τ) := by
        ext τ
        simp only [Fintype.mem_piFinset, explicitQueryBaseSet, Finset.mem_filter, Finset.mem_univ,
          true_and, UL.Proof_lem_6_3.IsQueryTuple]
        exact forall_congr' fun s => hquery_eq s (τ s)
      rw [heq_set]; exact hcq_id
    · let BadLHS := (gen.P₀ ×ˢ Fintype.piFinset (fun s : Fin ℓ => explicitQueryBaseSet F_d (τ_q : ℝ) z r s)).filter
        (fun it => (∀ s : Fin ℓ, gaussianDataTest (τ_d : ℝ) (F_d (r, s, it.2 s)) (gen.pts it.1)) ∧
          inner ℝ (gen.pts it.1) z ≤ 0)
      let BadRHS := Finset.univ.filter (fun kt : Fin gen.m × (Fin ℓ → Fin M₀) =>
        inner ℝ (ptsK kt.1) z ≤ 0 ∧
          UL.Proof_lem_6_3.IsSharedTuple x t_ideal (extractCopy r ω_c) (ptsK kt.1) z kt.2)
      have hcard_le : BadLHS.card ≤ BadRHS.card := by
        refine Finset.card_le_card_of_injOn
          (fun it => if hi : it.1 ∈ gen.P₀ then (enum.symm ⟨it.1, hi⟩, it.2) else (⟨0, hm_pos⟩, it.2)) ?_ ?_
        · intro it hit
          rcases Finset.mem_filter.mp hit with ⟨hprod, hd_all, hle0⟩
          rcases Finset.mem_product.mp hprod with ⟨hi_P0, hq_pi⟩
          dsimp only
          rw [dif_pos hi_P0]
          have hpts_eq : ptsK (enum.symm ⟨it.1, hi_P0⟩) = gen.pts it.1 := by simp [ptsK]
          refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_, ?_, ?_⟩
          · rwa [hpts_eq]
          · intro s; rw [hpts_eq]; exact (hdata_eq s (it.2 s) it.1 hi_P0).mp (hd_all s)
          · intro s
            have hqs := (Fintype.mem_piFinset.mp hq_pi) s
            simp only [explicitQueryBaseSet, Finset.mem_filter, Finset.mem_univ, true_and] at hqs
            exact (hquery_eq s (it.2 s)).mp hqs
        · intro a ha b hb heq
          have ha0 : a.1 ∈ gen.P₀ := (Finset.mem_product.mp (Finset.mem_filter.mp ha).1).1
          have hb0 : b.1 ∈ gen.P₀ := (Finset.mem_product.mp (Finset.mem_filter.mp hb).1).1
          dsimp only at heq
          rw [dif_pos ha0, dif_pos hb0] at heq
          rcases Prod.mk.inj heq with ⟨hk_eq, ht_eq⟩
          have hsub_eq := enum.symm.injective hk_eq
          exact Prod.ext (congrArg Subtype.val hsub_eq) ht_eq
      exact hcard_le.trans hcbad_id
  have hunif_prob : 1 - ε₀ ≤ ((PMF.uniformOfFintype Seed).toMeasure).real E_equiv := by
    have hmap_eq : ((PMF.uniformOfFintype Seed).toMeasure).real E_equiv =
        μ_cpl.real (projBitsMap hb_pos ⁻¹' E_equiv) := by
      rw [← map_projBitsMap_eq_uniform (R := R) (ℓ := ℓ) (M₀ := M₀) (D := d + 1) hb_pos]
      simp only [MeasureTheory.measureReal_def]
      rw [Measure.map_apply (measurable_projBitsMap hb_pos) MeasurableSet.of_discrete]
    rw [hmap_eq]
    exact hB_tot_compl.trans (MeasureTheory.measureReal_mono hsub_good)
  -- Convert `((PMF.uniformOfFintype Seed).toMeasure).real E_equiv` to `(S_equiv.card : ℝ) / (Fintype.card Seed : ℝ)`
  let S_equiv : Finset Seed := Finset.univ.filter (fun ω : Seed => ω ∈ E_equiv)
  have hunif_card_eq : ((PMF.uniformOfFintype Seed).toMeasure).real E_equiv =
      (S_equiv.card : ℝ) / (Fintype.card Seed : ℝ) := by
    have hE_eq : E_equiv = ⋃ ω ∈ S_equiv, ({ω} : Set Seed) := by ext ω; simp [S_equiv]
    have hdisj : (S_equiv : Set Seed).PairwiseDisjoint (fun ω : Seed => ({ω} : Set Seed)) :=
      fun _ _ _ _ hne => Set.disjoint_singleton.mpr hne
    simp only [MeasureTheory.measureReal_def]
    rw [hE_eq, MeasureTheory.measure_biUnion_finset hdisj (fun _ _ => MeasurableSet.of_discrete)]
    have hsing : ∀ ω ∈ S_equiv, (PMF.uniformOfFintype Seed).toMeasure ({ω} : Set Seed) =
        ((Fintype.card Seed : ENNReal))⁻¹ := by
      intro ω _
      rw [PMF.toMeasure_apply_singleton _ _ MeasurableSet.of_discrete, PMF.uniformOfFintype_apply]
    rw [Finset.sum_congr rfl hsing, Finset.sum_const, nsmul_eq_mul,
      ENNReal.toReal_mul, ENNReal.toReal_natCast, ENNReal.toReal_inv, ENNReal.toReal_natCast, div_eq_mul_inv]
  rw [hunif_card_eq] at hunif_prob
  have hSeed_pos : (0 : ℝ) < (Fintype.card Seed : ℝ) := Nat.cast_pos.mpr Fintype.card_pos
  have hS_equiv_ge : (1 - ε₀) * (Fintype.card Seed : ℝ) ≤ (S_equiv.card : ℝ) :=
    (le_div_iff₀ hSeed_pos).mp hunif_prob
  -- Bijection between `S_equiv` and the MSB-decoded `polyFDisc` good finset
  let S_msb : Finset Seed := Finset.univ.filter (fun ω : Seed =>
    IsOrderIndepGoodFilter (polyFDisc T p_coord ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen Q_net)
  have hcard_msb : S_equiv.card = S_msb.card := by
    let perm1 : (Fin b → Bool) ≃ (Fin b → Bool) := (bitsEquiv b).trans (bitsFnToFinEquiv b).symm
    let permSeed : Seed ≃ Seed :=
      { toFun := fun ω x => perm1 (fun bitIdx => ω (x.1, x.2.1, bitIdx)) x.2.2
        invFun := fun ω x => perm1.symm (fun bitIdx => ω (x.1, x.2.1, bitIdx)) x.2.2
        left_inv := fun ω => by
          ext ⟨idx, j, s⟩; dsimp only
          exact congrFun (perm1.symm_apply_apply (fun bitIdx => ω (idx, j, bitIdx))) s
        right_inv := fun ω => by
          ext ⟨idx, j, s⟩; dsimp only
          exact congrFun (perm1.apply_symm_apply (fun bitIdx => ω (idx, j, bitIdx))) s }
    refine Finset.card_bij (fun ω _ => permSeed ω) ?_ (fun a _ b _ h => permSeed.injective h) ?_
    · intro ω hω
      have hω_in : ω ∈ E_equiv := (Finset.mem_filter.mp hω).2
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
      have hF_eq : polyFDisc T p_coord (permSeed ω) = equivFDisc ω := by
        funext idx
        unfold polyFDisc equivFDisc
        congr 1; funext k; congr 1
        exact (bitsFnToFinEquiv b).apply_symm_apply (bitsEquiv b (fun bitIdx => ω (idx, k, bitIdx)))
      rwa [hF_eq]
    · intro ω' hω'
      refine ⟨permSeed.symm ω', Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩, permSeed.apply_symm_apply ω'⟩
      have hω'_in := (Finset.mem_filter.mp hω').2
      have hF_eq : equivFDisc (permSeed.symm ω') = polyFDisc T p_coord ω' := by
        funext idx
        unfold polyFDisc equivFDisc
        congr 1; funext k; congr 1
        exact (bitsEquiv b).apply_symm_apply (bitsFnToFinEquiv b (fun bitIdx => ω' (idx, k, bitIdx)))
      change IsOrderIndepGoodFilter (equivFDisc (permSeed.symm ω')) _ _ _ _ _ _
      rwa [hF_eq]
  rwa [hcard_msb] at hS_equiv_ge

end UL.Proof.clm_9_1_explicit_tradeoff.H3b1
