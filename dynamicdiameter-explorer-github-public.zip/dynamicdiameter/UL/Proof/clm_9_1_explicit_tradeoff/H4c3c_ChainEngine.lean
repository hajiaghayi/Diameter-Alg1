import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H4c3b_JobStep
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b

/-! ### 1. Integer Ratio & Scheduler Arithmetic Lemmas -/

/-- Elementary integer Bernoulli-type bound:
`(2 * D2 + 1) ^ k * (2 * D2 - k) ≤ (2 * D2) ^ (k + 1)` for all `k : ℕ`. -/
theorem pow_twoD2_add_one_mul_sub (D2 : ℕ) :
    ∀ k : ℕ, (2 * D2 + 1) ^ k * (2 * D2 - k) ≤ (2 * D2) ^ (k + 1)
  | 0 => by simp
  | k + 1 => by
      by_cases hk : k + 1 ≤ 2 * D2
      · have step_lin : (2 * D2 + 1) * (2 * D2 - (k + 1)) ≤ (2 * D2) * (2 * D2 - k) := by
          have hsub1 : ((2 * D2 - (k + 1) : ℕ) : ℤ) = 2 * (D2 : ℤ) - ((k : ℤ) + 1) := by omega
          have hsub0 : ((2 * D2 - k : ℕ) : ℤ) = 2 * (D2 : ℤ) - (k : ℤ) := by omega
          zify
          rw [hsub1, hsub0]
          nlinarith only []
        calc (2 * D2 + 1) ^ (k + 1) * (2 * D2 - (k + 1))
            = (2 * D2 + 1) ^ k * ((2 * D2 + 1) * (2 * D2 - (k + 1))) := by rw [pow_succ]; ring
          _ ≤ (2 * D2 + 1) ^ k * ((2 * D2) * (2 * D2 - k)) := Nat.mul_le_mul_left _ step_lin
          _ = (2 * D2) * ((2 * D2 + 1) ^ k * (2 * D2 - k)) := by ring
          _ ≤ (2 * D2) * (2 * D2) ^ (k + 1) :=
              Nat.mul_le_mul_left _ (pow_twoD2_add_one_mul_sub D2 k)
          _ = (2 * D2) ^ (k + 2) := by ring
      · have hzero : 2 * D2 - (k + 1) = 0 := by omega
        rw [hzero, Nat.mul_zero]
        exact Nat.zero_le _

/-- For `k ≤ D2` and `1 ≤ D2`, `(2 * D2 + 1) ^ k ≤ 2 * (2 * D2) ^ k`. -/
theorem pow_twoD2_add_one_le {D2 k : ℕ} (hD2 : 1 ≤ D2) (hk : k ≤ D2) :
    (2 * D2 + 1) ^ k ≤ 2 * (2 * D2) ^ k := by
  have h1 := pow_twoD2_add_one_mul_sub D2 k
  have hsub_ge : D2 ≤ 2 * D2 - k := by omega
  have h2 : (2 * D2 + 1) ^ k * D2 ≤ (2 * D2) ^ k * (2 * D2) := by
    calc (2 * D2 + 1) ^ k * D2
        ≤ (2 * D2 + 1) ^ k * (2 * D2 - k) := Nat.mul_le_mul_left _ hsub_ge
      _ ≤ (2 * D2) ^ (k + 1) := h1
      _ = (2 * D2) ^ k * (2 * D2) := pow_succ _ _
  have hrhs : (2 * D2) ^ k * (2 * D2) = (2 * (2 * D2) ^ k) * D2 := by ring
  rw [hrhs] at h2
  exact Nat.le_of_mul_le_mul_right h2 (by omega)

/-- Consequence of `M' * (2 * D2) ^ k ≤ M * (2 * D2 + 1) ^ k` (`k ≤ D2`, `1 ≤ D2`): `M' ≤ 2 * M`. -/
theorem ratio_le_two_of_pow_bound {D2 k M M' : ℕ} (hD2 : 1 ≤ D2) (hk : k ≤ D2)
    (hb : M' * (2 * D2) ^ k ≤ M * (2 * D2 + 1) ^ k) :
    M' ≤ 2 * M := by
  have hp_pos : 0 < (2 * D2) ^ k := pow_pos (by omega) k
  have hp_ub := pow_twoD2_add_one_le hD2 hk
  have hmul : M' * (2 * D2) ^ k ≤ (2 * M) * (2 * D2) ^ k := by
    calc M' * (2 * D2) ^ k
        ≤ M * (2 * D2 + 1) ^ k := hb
      _ ≤ M * (2 * (2 * D2) ^ k) := Nat.mul_le_mul_left M hp_ub
      _ = (2 * M) * (2 * D2) ^ k := by ring
  exact Nat.le_of_mul_le_mul_right hmul hp_pos

theorem _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.sched_bounds {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    64 * K_alpha d < cp.B_scan ∧
    128 * K_alpha d * (12 * cp.D2) < cp.B_scan ∧
    2 * cp.D2 * (12 * cp.D2) < cp.B_scan ∧
    64 * K_alpha d * (48 * cp.D2) ≤ cp.B_scan := by
  have hK : 36 ≤ K_alpha d := K_alpha_ge_36 d
  have hD : 1 ≤ cp.D_max := cp.D_max_pos
  have hD2 : cp.D2 = cp.D_max + 2 := rfl
  have hB : cp.B_scan = 16384 * cp.D2 ^ 2 * (K_alpha d) ^ 2 := rfl
  have hK_le_K2 : 36 * K_alpha d ≤ (K_alpha d) ^ 2 := by nlinarith only [hK]
  have hD2_ge : 3 ≤ cp.D2 := by omega
  have hD2_le_D22 : 3 * cp.D2 ≤ cp.D2 ^ 2 := by nlinarith only [hD2_ge]
  have hprod : 108 * (cp.D2 * K_alpha d) ≤ cp.D2 ^ 2 * (K_alpha d) ^ 2 := by
    have hmul := Nat.mul_le_mul hD2_le_D22 hK_le_K2
    linarith only [hmul]
  have hD22_le : cp.D2 ^ 2 ≤ cp.D2 ^ 2 * (K_alpha d) ^ 2 := by
    have hK2_pos : 1 ≤ (K_alpha d) ^ 2 := by nlinarith only [hK]
    exact Nat.le_mul_of_pos_right _ hK2_pos
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [hB]; nlinarith only [hprod, hD2_ge, hK]
  · have hlin : 128 * K_alpha d * (12 * cp.D2) = 1536 * (cp.D2 * K_alpha d) := by ring
    rw [hlin, hB]; nlinarith only [hprod, hD2_ge, hK]
  · have hlin : 2 * cp.D2 * (12 * cp.D2) = 24 * cp.D2 ^ 2 := by ring
    rw [hlin, hB]; nlinarith only [hD22_le, hD2_ge]
  · have hlin : 64 * K_alpha d * (48 * cp.D2) = 3072 * (cp.D2 * K_alpha d) := by ring
    rw [hlin, hB]; nlinarith only [hprod]

/-! ### 2. Structural List Helpers (`foldResiduals`, `ChainListInv`, `liveUpdateChainList`) -/

theorem foldResiduals_append {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (pts : ℕ → EuclideanSpace ℝ (Fin d)) :
    ∀ (S : Finset ℕ) (l₁ l₂ : List (MNode cp)),
      foldResiduals pts S (l₁ ++ l₂) = foldResiduals pts (foldResiduals pts S l₁) l₂
  | _, [], _ => rfl
  | S, mn :: rest, l₂ => foldResiduals_append pts (nodeResidual pts mn.nd.o mn.nd.V S) rest l₂

theorem chainListInv_append {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    {actH : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d} :
    ∀ (S : Finset ℕ) (l₁ l₂ : List (MNode cp)),
      ChainListInv cp actH pts gt S l₁ →
      ChainListInv cp actH pts gt (foldResiduals pts S l₁) l₂ →
      ChainListInv cp actH pts gt S (l₁ ++ l₂)
  | _, [], _, _, h₂ => h₂
  | S, mn :: rest, l₂, ⟨hhd, htl⟩, h₂ =>
      ⟨hhd, chainListInv_append (nodeResidual pts mn.nd.o mn.nd.V S) rest l₂ htl h₂⟩

theorem chainListInv_take {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    {actH : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d} :
    ∀ (r : ℕ) (S : Finset ℕ) (nds : List (MNode cp)),
      ChainListInv cp actH pts gt S nds →
      ChainListInv cp actH pts gt S (nds.take r)
  | 0, _, _, _ => trivial
  | _ + 1, _, [], _ => trivial
  | r + 1, S, mn :: rest, ⟨hhd, htl⟩ =>
      ⟨hhd, chainListInv_take r (nodeResidual pts mn.nd.o mn.nd.V S) rest htl⟩

theorem chainListInv_mem_birthSize {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    {actH : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d} :
    ∀ (S : Finset ℕ) (nds : List (MNode cp)),
      ChainListInv cp actH pts gt S nds →
      ∀ mn ∈ nds, cp.B_scan < mn.nd.birthSize ∧ mn.nd.birthSize ≤ cp.n
  | _, [], _, _, hm => absurd hm List.not_mem_nil
  | S, hd :: tl, ⟨hhd, htl⟩, mn, hm => by
      rcases List.mem_cons.mp hm with rfl | hmem
      · exact ⟨hhd.2.2.1, hhd.2.1⟩
      · exact chainListInv_mem_birthSize (nodeResidual pts hd.nd.o hd.nd.V S) tl htl mn hmem

theorem chainListInv_getElem {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    {actHandles : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d} :
    ∀ (S : Finset ℕ) (nds : List (MNode cp)),
      S ⊆ actHandles →
      ChainListInv cp actHandles pts gt S nds →
      foldResiduals pts S nds ⊆ actHandles ∧
      ∀ (r : ℕ) (hr : r < nds.length),
        foldResiduals pts S (nds.take r) ⊆ actHandles ∧
        LiveNodeInv cp actHandles pts gt (foldResiduals pts S (nds.take r)) (nds[r]'hr)
  | S, [], hS, _ => ⟨hS, fun _ hr => absurd hr (Nat.not_lt_zero _)⟩
  | S, mn :: rest, hS, ⟨hhead, htail⟩ => by
      have hres_sub : nodeResidual pts mn.nd.o mn.nd.V S ⊆ actHandles := by
        intro x hx; unfold nodeResidual at hx
        rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hS hx.1
      rcases chainListInv_getElem (nodeResidual pts mn.nd.o mn.nd.V S) rest hres_sub htail
        with ⟨hfold_end, hget_tl⟩
      refine ⟨hfold_end, fun r hr => ?_⟩
      cases r with
      | zero => exact ⟨hS, hhead⟩
      | succ r' => exact hget_tl r' (Nat.lt_of_succ_lt_succ hr)

theorem chainListInv_getLast {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    {actHandles : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    {S : Finset ℕ} {nds : List (MNode cp)} {u_last : MNode cp}
    (hS : S ⊆ actHandles) (hcl : ChainListInv cp actHandles pts gt S nds)
    (hlast : nds.getLast? = some u_last) :
    u_last.resArr.Nodup ∧
    u_last.resArr.toFinset = foldResiduals pts S nds ∧
    foldResiduals pts S nds ⊆ u_last.histArr.toFinset ∧
    LiveNodeInv cp actHandles pts gt (foldResiduals pts S (nds.take (nds.length - 1))) u_last := by
  have hne : nds ≠ [] := fun he => by simp [he] at hlast
  have hpos : 0 < nds.length := List.length_pos_iff.mpr hne
  have hidx_lt : nds.length - 1 < nds.length := by omega
  have hu_eq : nds[nds.length - 1]'hidx_lt = u_last := by
    rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem hidx_lt] at hlast
    exact Option.some.inj hlast
  rcases (chainListInv_getElem S nds hS hcl).2 (nds.length - 1) hidx_lt with ⟨_, hln⟩
  rw [hu_eq] at hln
  have hsplit : nds = nds.take (nds.length - 1) ++ [u_last] := by
    conv_lhs => rw [← List.take_append_drop (nds.length - 1) nds]
    congr 1
    rw [List.drop_eq_getElem_cons hidx_lt, List.drop_of_length_le (by omega), hu_eq]
  have hfold_eq : foldResiduals pts S nds =
      nodeResidual pts u_last.nd.o u_last.nd.V (foldResiduals pts S (nds.take (nds.length - 1))) := by
    conv_lhs => rw [hsplit]
    rw [foldResiduals_append]; rfl
  rcases hln with ⟨hcur, hbsz_n, hbsz_B, hb_u, hage, hhist, htins, hwf⟩
  rcases hwf with ⟨hwf_nd, hres_nd, hres_set, hcur_hist⟩
  have hres_sub_cur : nodeResidual pts u_last.nd.o u_last.nd.V u_last.nd.curSet ⊆ u_last.nd.curSet := by
    intro x hx; unfold nodeResidual at hx
    rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hx.1
  refine ⟨hres_nd, ?_, ?_, ⟨hcur, hbsz_n, hbsz_B, hb_u, hage, hhist, htins, ⟨hwf_nd, hres_nd, hres_set, hcur_hist⟩⟩⟩
  · rw [hres_set, hcur, hfold_eq]
  · rw [hfold_eq, ← hcur]; exact hres_sub_cur.trans hcur_hist

noncomputable def passesNodes {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    (pts' : ℕ → EuclideanSpace ℝ (Fin d)) (h_op : ℕ) : List (MNode cp) → Bool
  | [] => true
  | mn :: rest => (!inCoreBall mn.nd.o mn.nd.V (pts' h_op)) && passesNodes pts' h_op rest

theorem liveUpdateChainList_snd_eq {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ) (seeds : ℕ → OpSeed cp) :
    ∀ (idx : ℕ) (nds : List (MNode cp)),
      (liveUpdateChainList cp pts' isIns h_op seeds idx nds).2 = passesNodes pts' h_op nds
  | _, [] => rfl
  | idx, mn :: rest => by
      dsimp only [liveUpdateChainList, passesNodes]
      cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_op)
      · simp [liveUpdateChainList_snd_eq cp pts' isIns h_op seeds (idx + 1) rest]
      · simp

theorem liveUpdateChainList_take {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ) (seeds : ℕ → OpSeed cp) :
    ∀ (r idx : ℕ) (nds : List (MNode cp)),
      ((liveUpdateChainList cp pts' isIns h_op seeds idx nds).1).take r =
        (liveUpdateChainList cp pts' isIns h_op seeds idx (nds.take r)).1
  | 0, _, _ => by simp [liveUpdateChainList]
  | _ + 1, _, [] => by simp [liveUpdateChainList]
  | r + 1, idx, mn :: rest => by
      dsimp only [List.take_succ_cons, liveUpdateChainList]
      by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = true
      · rw [if_pos hcb, if_pos hcb]; rfl
      · rw [if_neg hcb, if_neg hcb]
        dsimp only [List.take_succ_cons]
        rw [liveUpdateChainList_take cp pts' isIns h_op seeds r (idx + 1) rest]

/-- For any element `nds[r]`, `liveUpdateChainList` either keeps `histArr` or appends `[h_op]`. -/
theorem liveUpdateChainList_hist_dichotomy {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (pts' : ℕ → EuclideanSpace ℝ (Fin d))
    (isIns : Bool) (h_op : ℕ) (seeds : ℕ → OpSeed cp) :
    ∀ (idx : ℕ) (nds : List (MNode cp)) (r : ℕ) (hr : r < nds.length),
      let res := liveUpdateChainList cp pts' isIns h_op seeds idx nds
      ∃ hr' : r < res.1.length,
        ((res.1[r]'hr').histArr = (nds[r]'hr).histArr ∨
          (isIns = true ∧ (res.1[r]'hr').histArr = (nds[r]'hr).histArr ++ [h_op])) ∧
        (passesNodes pts' h_op (nds.take r) = true →
          (res.1[r]'hr').histArr =
            if isIns then (nds[r]'hr).histArr ++ [h_op] else (nds[r]'hr).histArr)
  | _, [], _, hr => absurd hr (Nat.not_lt_zero _)
  | idx, mn :: rest, 0, _ => by
      dsimp only [liveUpdateChainList, List.take_zero, passesNodes]
      by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = true
      · rw [if_pos hcb]
        refine ⟨Nat.zero_lt_succ _, ?_, fun _ => ?_⟩
        · cases isIns
          · exact Or.inl rfl
          · exact Or.inr ⟨rfl, rfl⟩
        · cases isIns <;> rfl
      · rw [if_neg hcb]
        refine ⟨Nat.zero_lt_succ _, ?_, fun _ => ?_⟩
        · cases isIns
          · exact Or.inl rfl
          · exact Or.inr ⟨rfl, rfl⟩
        · cases isIns <;> rfl
  | idx, mn :: rest, r + 1, hr => by
      have hr_tl : r < rest.length := Nat.lt_of_succ_lt_succ hr
      dsimp only [liveUpdateChainList, List.take_succ_cons, passesNodes]
      by_cases hcb : inCoreBall mn.nd.o mn.nd.V (pts' h_op) = true
      · rw [if_pos hcb]
        refine ⟨Nat.succ_lt_succ hr_tl, Or.inl rfl, fun ht => ?_⟩
        rw [hcb] at ht; simp at ht
      · rw [if_neg hcb]
        rcases liveUpdateChainList_hist_dichotomy cp pts' isIns h_op seeds (idx + 1) rest r hr_tl
          with ⟨hr', hdic, hpass⟩
        have hnot_cb : (!inCoreBall mn.nd.o mn.nd.V (pts' h_op)) = true := by
          cases hb : inCoreBall mn.nd.o mn.nd.V (pts' h_op)
          · rfl
          · exact absurd hb hcb
        refine ⟨Nat.succ_lt_succ hr', hdic, fun ht => hpass ?_⟩
        rw [hnot_cb, Bool.true_and] at ht; exact ht

theorem copyStateInv_append_right {srcHist : List ℕ} {targetSet : Finset ℕ} {cs : CopyState}
    (extra : List ℕ) (hinv : CopyStateInv srcHist targetSet cs) :
    CopyStateInv (srcHist ++ extra) targetSet cs := by
  rcases hinv with ⟨hcur, hL, hnd, hsub, hcomp⟩
  refine ⟨hcur, hL.trans (by simp), hnd, hsub, fun x hx => ?_⟩
  rcases hcomp x hx with hxs | ⟨j, hj1, hj2, hj_lt, hj_eq⟩
  · exact Or.inl hxs
  · refine Or.inr ⟨j, hj1, hj2, hj_lt.trans_le (by simp), ?_⟩
    rw [List.getElem_append_left hj_lt]
    exact hj_eq

theorem buildStateInv_unchanged_insert {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles targetSet : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} {h_new : ℕ} (hnot_act : h_new ∉ actHandles)
    (pt : EuclideanSpace ℝ (Fin d)) (hpts_old : ∀ x ∈ actHandles, pts' x = pts x)
    (htgt_sub : targetSet ⊆ actHandles) {bs : BuildState cp}
    (hinv : BuildStateInv cp pts gt targetSet bs) :
    let gt' := gt.stepInsert h_new pt
    BuildStateInv cp pts' gt' targetSet bs ∧
    (LiveNodeGood cp hh0 hh1 pts gt bs.curNode →
     LiveNodeGood cp hh0 hh1 pts' gt' bs.curNode) := by
  rcases hinv with ⟨hnd_s, hnd_d, hins_le, hbsz_eq, hbsz_n, hbsz_B, hbirth_u,
    hdisj, hunion, hage, hhist, htins, hwf⟩
  have hcur_sub : bs.curNode.nd.curSet ⊆ actHandles :=
    (hunion ▸ Finset.subset_union_left).trans htgt_sub
  have heq_cur : ∀ x ∈ bs.curNode.nd.curSet, pts' x = pts x := fun x hx => hpts_old x (hcur_sub hx)
  rcases managedNode_pts_congr (M_lat := M_lat_of d params.e) (τ_q := cp.τ_q) (cap_q := cp.cap_q)
    hh0 hh1 heq_cur hwf with ⟨hwf', hgd_m⟩
  let gt' := gt.stepInsert h_new pt
  have himg_eq : targetSet.image gt'.uidOf = targetSet.image gt.uidOf := by
    apply Finset.image_congr
    intro x hx
    have hne : x ≠ h_new := fun heq => hnot_act (heq ▸ htgt_sub hx)
    exact Function.update_of_ne hne gt.nextUid gt.uidOf
  refine ⟨⟨hnd_s, hnd_d, hins_le, hbsz_eq, hbsz_n, hbsz_B,
    fun u hu => Nat.lt_succ_of_lt (hbirth_u u hu),
    hdisj, hunion, himg_eq ▸ hage, hhist, htins, hwf'⟩, fun ⟨hcp, hm⟩ => ⟨?_, hgd_m hm⟩⟩
  refine isCenterpoint_congr_ghostPts (fun u hu => ?_) hcp
  have hne : u ≠ gt.nextUid := Nat.ne_of_lt (hbirth_u u hu)
  exact Function.update_of_ne hne pt gt.ghostPts

theorem buildStateInv_unchanged_delete {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (hh0 : 0 < h) (hh1 : h < 1)
    {actHandles targetSet : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} {h_del : ℕ} (hnot_tgt : h_del ∉ targetSet)
    (hpts_old : ∀ x ∈ actHandles.erase h_del, pts' x = pts x)
    (htgt_sub : targetSet ⊆ actHandles) {bs : BuildState cp}
    (hinv : BuildStateInv cp pts gt targetSet bs) :
    BuildStateInv cp pts' gt targetSet bs ∧
    (LiveNodeGood cp hh0 hh1 pts gt bs.curNode →
     LiveNodeGood cp hh0 hh1 pts' gt bs.curNode) := by
  rcases hinv with ⟨hnd_s, hnd_d, hins_le, hbsz_eq, hbsz_n, hbsz_B, hbirth_u,
    hdisj, hunion, hage, hhist, htins, hwf⟩
  have hcur_sub_tgt : bs.curNode.nd.curSet ⊆ targetSet := hunion ▸ Finset.subset_union_left
  have heq_cur : ∀ x ∈ bs.curNode.nd.curSet, pts' x = pts x := fun x hx =>
    hpts_old x (Finset.mem_erase.mpr ⟨fun heq => hnot_tgt (heq ▸ hcur_sub_tgt hx), htgt_sub (hcur_sub_tgt hx)⟩)
  rcases managedNode_pts_congr (M_lat := M_lat_of d params.e) (τ_q := cp.τ_q) (cap_q := cp.cap_q)
    hh0 hh1 heq_cur hwf with ⟨hwf', hgd_m⟩
  exact ⟨⟨hnd_s, hnd_d, hins_le, hbsz_eq, hbsz_n, hbsz_B, hbirth_u,
    hdisj, hunion, hage, hhist, htins, hwf'⟩, fun ⟨hcp, hm⟩ => ⟨hcp, hgd_m hm⟩⟩

/-! ### 3. Flat Bit Layout & `StepCoinBundle` Equivalence -/

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.N_op_s1 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.D_max + cp.D_max * cp.D_max + cp.D_max

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.N_op_s2 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.D_max * cp.B_scan + (cp.B_scan + 1)

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.B_walk {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.P_hpj.L * (d + 1 + 3) * cp.P_hpj.q

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.B_op {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.N_cfg * 2 * cp.L_p2 * cp.R * cp.ℓ * cp.M₀ * (d + 1) * cp.b

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.B_ctr {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.N_samp * cp.q_idx + cp.B_walk

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.B_base {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.k_base * cp.q_idx

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.B_S1 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.N_op_s1 * cp.B_op

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.B_S2 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.N_op_s2 * cp.B_op + (cp.D_max + 1) * cp.B_ctr

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.B_S4 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.D_max * cp.B_base

abbrev _root_.UL.Proof.clm_9_1_explicit_tradeoff.H4c3b.ChainParams.B_STEP {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  cp.B_S1 + cp.B_S2 + cp.B_S4

abbrev Stage1Coins {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) : Type :=
  Fin cp.N_op_s1 → OpSeed cp

abbrev Stage2Coins {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) : Type :=
  (Fin cp.N_op_s2 → OpSeed cp) × (Fin (cp.D_max + 1) → CenterSeed cp)

abbrev Stage4Coins {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) : Type :=
  Fin cp.D_max → (Fin cp.k_base → Fin (2 ^ cp.q_idx))

abbrev StepCoinBundle {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) : Type :=
  Stage1Coins cp × Stage2Coins cp × Stage4Coins cp

def splitBlocks {K M : ℕ} (f : Fin (K * M) → Bool) : Fin K → Fin M → Bool :=
  fun k m => f ⟨k.val * M + m.val, by
    calc k.val * M + m.val < k.val * M + M := Nat.add_lt_add_left m.isLt _
      _ = (k.val + 1) * M := by ring
      _ ≤ K * M := Nat.mul_le_mul_right M k.isLt⟩

theorem splitBlocks_injective (K M : ℕ) : Function.Injective (@splitBlocks K M) := by
  intro f₁ f₂ heq
  rcases Nat.eq_zero_or_pos M with rfl | hM_pos
  · funext idx; exact absurd idx.isLt (by simp)
  · funext idx
    let k : Fin K := ⟨idx.val / M, (Nat.div_lt_iff_lt_mul hM_pos).mpr idx.isLt⟩
    let m : Fin M := ⟨idx.val % M, Nat.mod_lt _ hM_pos⟩
    have hkm := congrFun (congrFun heq k) m
    dsimp only [splitBlocks, k, m] at hkm
    have hidx : (idx.val / M) * M + idx.val % M = idx.val := by
      rw [Nat.mul_comm, Nat.div_add_mod]
    have hfin1 : (⟨k.val * M + m.val, by
        calc k.val * M + m.val < k.val * M + M := Nat.add_lt_add_left m.isLt _
          _ = (k.val + 1) * M := by ring
          _ ≤ K * M := Nat.mul_le_mul_right M k.isLt⟩ : Fin (K * M)) = idx :=
      Fin.ext hidx
    rwa [hfin1] at hkm

noncomputable def splitBlocksEquiv (K M : ℕ) : (Fin (K * M) → Bool) ≃ (Fin K → Fin M → Bool) :=
  Equiv.ofBijective splitBlocks
    ((Fintype.bijective_iff_injective_and_card (@splitBlocks K M)).mpr
      ⟨splitBlocks_injective K M, by
        simp only [Fintype.card_fun, Fintype.card_fin, Fintype.card_bool]
        rw [← pow_mul, Nat.mul_comm]⟩)

@[simp] theorem splitBlocksEquiv_apply {K M : ℕ} (f : Fin (K * M) → Bool) (k : Fin K) (m : Fin M) :
    splitBlocksEquiv K M f k m = f ⟨k.val * M + m.val, by
      calc k.val * M + m.val < k.val * M + M := Nat.add_lt_add_left m.isLt _
        _ = (k.val + 1) * M := by ring
        _ ≤ K * M := Nat.mul_le_mul_right M k.isLt⟩ := rfl

def splitAdd {A B : ℕ} (f : Fin (A + B) → Bool) : (Fin A → Bool) × (Fin B → Bool) :=
  (fun a => f ⟨a.val, Nat.lt_of_lt_of_le a.isLt (Nat.le_add_right A B)⟩,
   fun b => f ⟨A + b.val, Nat.add_lt_add_left b.isLt A⟩)

theorem splitAdd_injective (A B : ℕ) : Function.Injective (@splitAdd A B) := by
  intro f₁ f₂ heq
  rcases Prod.mk.inj heq with ⟨hA, hB⟩
  funext idx
  by_cases hlt : idx.val < A
  · exact congrFun hA ⟨idx.val, hlt⟩
  · have hsub : idx.val - A < B := by omega
    let b_idx : Fin B := ⟨idx.val - A, hsub⟩
    have hb := congrFun hB b_idx
    dsimp only [splitAdd, b_idx] at hb
    have hfin : (⟨A + (idx.val - A), Nat.add_lt_add_left hsub A⟩ : Fin (A + B)) = idx := by
      ext; dsimp only; omega
    rwa [hfin] at hb

noncomputable def splitAddEquiv (A B : ℕ) :
    (Fin (A + B) → Bool) ≃ ((Fin A → Bool) × (Fin B → Bool)) :=
  Equiv.ofBijective splitAdd
    ((Fintype.bijective_iff_injective_and_card (@splitAdd A B)).mpr
      ⟨splitAdd_injective A B, by
        simp only [Fintype.card_prod, Fintype.card_fun, Fintype.card_fin, Fintype.card_bool, pow_add]⟩)

@[simp] theorem splitAddEquiv_fst {A B : ℕ} (f : Fin (A + B) → Bool) (a : Fin A) :
    (splitAddEquiv A B f).1 a = f ⟨a.val, Nat.lt_of_lt_of_le a.isLt (Nat.le_add_right A B)⟩ := rfl

@[simp] theorem splitAddEquiv_snd {A B : ℕ} (f : Fin (A + B) → Bool) (b : Fin B) :
    (splitAddEquiv A B f).2 b = f ⟨A + b.val, Nat.add_lt_add_left b.isLt A⟩ := rfl

def boolFin2Equiv : Bool ≃ Fin 2 :=
  { toFun := fun side => if side then ⟨1, by decide⟩ else ⟨0, by decide⟩
    invFun := fun k => decide (k.val = 1)
    left_inv := fun b => by cases b <;> rfl
    right_inv := fun ⟨k, hk⟩ => by interval_cases k <;> rfl }

def opSeedIdxEquiv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    ((Fin cp.N_cfg × Bool × Fin cp.L_p2) × ExplicitCapIdx cp.R cp.ℓ cp.M₀ × Fin (d + 1) × Fin cp.b) ≃
      Fin cp.B_op :=
  ({ toFun := fun ⟨⟨i, sd, s⟩, ⟨r, a, m⟩, j, bi⟩ =>
       (((((((i, boolFin2Equiv sd), s), r), a), m), j), bi)
     invFun := fun ⟨⟨⟨⟨⟨⟨⟨i, sd⟩, s⟩, r⟩, a⟩, m⟩, j⟩, bi⟩ =>
       ((i, boolFin2Equiv.symm sd, s), (r, a, m), j, bi)
     left_inv := fun ⟨⟨i, sd, s⟩, ⟨r, a, m⟩, j, bi⟩ => by simp only [Equiv.symm_apply_apply]
     right_inv := fun ⟨⟨⟨⟨⟨⟨⟨i, sd⟩, s⟩, r⟩, a⟩, m⟩, j⟩, bi⟩ => by simp only [Equiv.apply_symm_apply] } :
    ((Fin cp.N_cfg × Bool × Fin cp.L_p2) × ExplicitCapIdx cp.R cp.ℓ cp.M₀ × Fin (d + 1) × Fin cp.b) ≃
      (((((((Fin cp.N_cfg × Fin 2) × Fin cp.L_p2) × Fin cp.R) × Fin cp.ℓ) × Fin cp.M₀) × Fin (d + 1)) × Fin cp.b)).trans
  (((((((finProdFinEquiv.prodCongr (Equiv.refl _)).trans finProdFinEquiv
    |>.prodCongr (Equiv.refl _)).trans finProdFinEquiv
    |>.prodCongr (Equiv.refl _)).trans finProdFinEquiv
    |>.prodCongr (Equiv.refl _)).trans finProdFinEquiv
    |>.prodCongr (Equiv.refl _)).trans finProdFinEquiv
    |>.prodCongr (Equiv.refl _)).trans finProdFinEquiv)

noncomputable def bitsToOpSeedEquiv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : (Fin cp.B_op → Bool) ≃ OpSeed cp :=
  (Equiv.arrowCongr (opSeedIdxEquiv cp).symm (Equiv.refl Bool)).trans (Equiv.curry _ _ _)

theorem bitsToOpSeedEquiv_apply {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (bits : Fin cp.B_op → Bool)
    (i : Fin cp.N_cfg) (side : Bool) (s : Fin cp.L_p2)
    (r : Fin cp.R) (a : Fin cp.ℓ) (m : Fin cp.M₀) (j : Fin (d + 1)) (bi : Fin cp.b) :
    let sd : ℕ := if side then 1 else 0
    let flat : ℕ :=
      (((((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) * cp.M₀ + m.val) *
        (d + 1) + j.val) * cp.b + bi.val)
    ∃ hflat : flat < cp.B_op,
      bitsToOpSeedEquiv cp bits (i, side, s) ((r, a, m), j, bi) = bits ⟨flat, hflat⟩ := by
  intro sd flat
  have hsd : sd < 2 := by dsimp [sd]; split_ifs <;> omega
  have h1 : i.val * 2 + sd < cp.N_cfg * 2 := by
    calc i.val * 2 + sd < i.val * 2 + 2 := Nat.add_lt_add_left hsd _
      _ = (i.val + 1) * 2 := by ring
      _ ≤ cp.N_cfg * 2 := Nat.mul_le_mul_right 2 i.isLt
  have h2 : (i.val * 2 + sd) * cp.L_p2 + s.val < cp.N_cfg * 2 * cp.L_p2 := by
    calc _ < (i.val * 2 + sd) * cp.L_p2 + cp.L_p2 := Nat.add_lt_add_left s.isLt _
      _ = (i.val * 2 + sd + 1) * cp.L_p2 := by ring
      _ ≤ _ := Nat.mul_le_mul_right _ h1
  have h3 : ((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val < cp.N_cfg * 2 * cp.L_p2 * cp.R := by
    calc _ < ((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + cp.R := Nat.add_lt_add_left r.isLt _
      _ = (((i.val * 2 + sd) * cp.L_p2 + s.val) + 1) * cp.R := by ring
      _ ≤ _ := Nat.mul_le_mul_right _ h2
  have h4 : (((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val <
      cp.N_cfg * 2 * cp.L_p2 * cp.R * cp.ℓ := by
    calc _ < (((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + cp.ℓ := Nat.add_lt_add_left a.isLt _
      _ = ((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) + 1) * cp.ℓ := by ring
      _ ≤ _ := Nat.mul_le_mul_right _ h3
  have h5 : ((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) * cp.M₀ + m.val <
      cp.N_cfg * 2 * cp.L_p2 * cp.R * cp.ℓ * cp.M₀ := by
    calc _ < ((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) * cp.M₀ + cp.M₀ :=
          Nat.add_lt_add_left m.isLt _
      _ = (((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) + 1) * cp.M₀ := by ring
      _ ≤ _ := Nat.mul_le_mul_right _ h4
  have h6 : (((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) * cp.M₀ + m.val) *
      (d + 1) + j.val < cp.N_cfg * 2 * cp.L_p2 * cp.R * cp.ℓ * cp.M₀ * (d + 1) := by
    calc _ < (((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) * cp.M₀ + m.val) *
            (d + 1) + (d + 1) := Nat.add_lt_add_left j.isLt _
      _ = ((((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) * cp.M₀ + m.val) + 1) *
            (d + 1) := by ring
      _ ≤ _ := Nat.mul_le_mul_right _ h5
  have h7 : flat < cp.B_op := by
    dsimp [flat]
    calc _ < ((((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) * cp.M₀ + m.val) *
            (d + 1) + j.val) * cp.b + cp.b := Nat.add_lt_add_left bi.isLt _
      _ = (((((((i.val * 2 + sd) * cp.L_p2 + s.val) * cp.R + r.val) * cp.ℓ + a.val) * cp.M₀ + m.val) *
            (d + 1) + j.val) + 1) * cp.b := by ring
      _ ≤ _ := Nat.mul_le_mul_right _ h6
  refine ⟨h7, ?_⟩
  cases side <;> {
    change bits (opSeedIdxEquiv cp ((i, _, s), (r, a, m), j, bi)) = bits ⟨flat, h7⟩
    apply congrArg bits
    apply Fin.ext
    simp [opSeedIdxEquiv, boolFin2Equiv, finProdFinEquiv, sd, flat]
    ring
  }

noncomputable def bitsToCenterSeedEquiv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : (Fin cp.B_ctr → Bool) ≃ CenterSeed cp :=
  (splitAddEquiv (cp.N_samp * cp.q_idx) cp.B_walk).trans
    (((splitBlocksEquiv cp.N_samp cp.q_idx).trans
      (Equiv.arrowCongr (Equiv.refl _) (bitsFnToFinEquiv cp.q_idx))).prodCongr (Equiv.refl _))

noncomputable def bitsToBaseSeedEquiv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    (Fin cp.B_base → Bool) ≃ (Fin cp.k_base → Fin (2 ^ cp.q_idx)) :=
  (splitBlocksEquiv cp.k_base cp.q_idx).trans
    (Equiv.arrowCongr (Equiv.refl _) (bitsFnToFinEquiv cp.q_idx))

noncomputable def bitsToStage1Equiv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : (Fin cp.B_S1 → Bool) ≃ Stage1Coins cp :=
  (splitBlocksEquiv cp.N_op_s1 cp.B_op).trans
    (Equiv.arrowCongr (Equiv.refl _) (bitsToOpSeedEquiv cp))

noncomputable def bitsToStage2Equiv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : (Fin cp.B_S2 → Bool) ≃ Stage2Coins cp :=
  (splitAddEquiv (cp.N_op_s2 * cp.B_op) ((cp.D_max + 1) * cp.B_ctr)).trans
    (((splitBlocksEquiv cp.N_op_s2 cp.B_op).trans
        (Equiv.arrowCongr (Equiv.refl _) (bitsToOpSeedEquiv cp))).prodCongr
      ((splitBlocksEquiv (cp.D_max + 1) cp.B_ctr).trans
        (Equiv.arrowCongr (Equiv.refl _) (bitsToCenterSeedEquiv cp))))

noncomputable def bitsToStage4Equiv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : (Fin cp.B_S4 → Bool) ≃ Stage4Coins cp :=
  (splitBlocksEquiv cp.D_max cp.B_base).trans
    (Equiv.arrowCongr (Equiv.refl _) (bitsToBaseSeedEquiv cp))

noncomputable def bitsToStepCoinBundle {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : (Fin cp.B_STEP → Bool) ≃ StepCoinBundle cp :=
  ((splitAddEquiv (cp.B_S1 + cp.B_S2) cp.B_S4).trans
    ((splitAddEquiv cp.B_S1 cp.B_S2).prodCongr (Equiv.refl _))).trans
    (((bitsToStage1Equiv cp).prodCongr (bitsToStage2Equiv cp)).prodCongr (bitsToStage4Equiv cp)
      |>.trans (Equiv.prodAssoc _ _ _))

/-! ### 4. Pure Chain Engine State & 4-Stage Step Function -/

inductive JobPhase {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) where
  | copy (cs : CopyState)
  | build (bs : BuildState cp)

def JobPhase.lvlProg {d : ℕ} {params : LocalScaleParams} {h : ℝ} {cp : ChainParams d params h} :
    JobPhase cp → ℕ
  | .copy cs => cs.copyCur
  | .build bs => bs.L_hist + cp.B_scan + bs.insCur

structure SuffixJob {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) where
  ready : List (MNode cp)
  phase : JobPhase cp

structure ChainEngineState {d : ℕ} {params : LocalScaleParams} {h : ℝ} (cp : ChainParams d params h) where
  hp : HandlePool d cp.n
  gt : GhostTracker d
  serving : List (MNode cp)
  jobs : Fin cp.D_max → Option (SuffixJob cp)
  leafArr : List ℕ
  leafOverflow : Bool
  cachedAns : StoredDiameterAnswer

def ChainEngineState.empty {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ChainEngineState cp :=
  { hp := HandlePool.empty d cp.n
    gt := GhostTracker.empty d
    serving := []
    jobs := fun _ => none
    leafArr := []
    leafOverflow := false
    cachedAns := { diameterHandles := none, cachedDistSq := 0 } }

noncomputable def getS1Seed {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (ω₁ : Stage1Coins cp) (idx : ℕ) : OpSeed cp :=
  if hlt : idx < cp.N_op_s1 then ω₁ ⟨idx, hlt⟩ else fun _ _ => false

noncomputable def stepStage1 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp)
    (uop : InternalUpdate d) (ω₁ : Stage1Coins cp) : ChainEngineState cp × Option ℕ :=
  let (hp', rh) := st.hp.step uop
  let pts' := hp'.coords
  let (isIns, h_op, gt') : Bool × ℕ × GhostTracker d :=
    match uop with
    | .insert pt =>
        let h_new := rh.getD 0
        (true, h_new, st.gt.stepInsert h_new pt)
    | .delete delH =>
        (false, delH, st.gt)
  let servRes := liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) 0 st.serving
  let serving₁ := servRes.1
  let leafArr₁ :=
    if servRes.2 && !st.leafOverflow then
      if isIns then denseInsert h_op st.leafArr else denseDelete h_op st.leafArr
    else
      st.leafArr
  let jobs₁ : Fin cp.D_max → Option (SuffixJob cp) := fun r =>
    match st.jobs r with
    | none => none
    | some jb =>
        if r.val < st.serving.length && passesNodes pts' h_op (st.serving.take r.val) then
          let readyBase := cp.D_max + r.val * cp.D_max
          let rRes := liveUpdateChainList cp pts' isIns h_op
            (fun q => getS1Seed cp ω₁ (readyBase + q)) 0 jb.ready
          let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
          let phase₁ : JobPhase cp :=
            if rRes.2 then
              match jb.phase with
              | .copy cs =>
                  .copy (if isIns then cs.liveInsert h_op else cs.liveDelete h_op)
              | .build bs =>
                  .build (if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ω₁ curIdx)
                          else bs.liveDelete cp pts' h_op (getS1Seed cp ω₁ curIdx))
            else
              jb.phase
          some { ready := rRes.1, phase := phase₁ }
        else
          some jb
  ({ st with hp := hp', gt := gt', serving := serving₁, jobs := jobs₁, leafArr := leafArr₁ }, rh)

noncomputable def advanceOneJob {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (gt : GhostTracker d)
    (anchorNode : MNode cp) (r : Fin cp.D_max) (jb : SuffixJob cp)
    (buildSeeds : Fin cp.B_scan → OpSeed cp) (ctrSeed : CenterSeed cp) :
    SuffixJob cp ⊕ (List (MNode cp) × List ℕ × Bool) :=
  let (srcHist, tgtArr) : List ℕ × List ℕ :=
    match jb.ready.getLast? with
    | none => (anchorNode.histArr, anchorNode.nd.denseArr)
    | some u_last => (u_last.histArr, u_last.resArr)
  match jb.phase with
  | .copy cs =>
      let steps := min (cs.L_hist - cs.copyCur) cp.B_scan
      let cs' := advanceCopyLoop srcHist tgtArr steps cs
      if cs'.copyCur < cs'.L_hist then
        Sum.inl { ready := jb.ready, phase := .copy cs' }
      else if cs'.snapArr.length ≤ cp.B_scan then
        Sum.inr (jb.ready, cs'.snapArr, false)
      else
        let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts cs'.snapArr ctrSeed
        let P₀_uid := cs'.snapArr.toFinset.image gt.uidOf
        let bs_new := BuildState.init cp cs'.L_hist cs'.snapArr os.1 os.2 P₀_uid
        Sum.inl { ready := jb.ready, phase := .build bs_new }
  | .build bs =>
      let steps := min (bs.snapArr.length - bs.insCur) cp.B_scan
      let ωs : Fin steps → OpSeed cp := fun j =>
        buildSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩
      let bs' := advanceBuildLoop cp pts steps ωs bs
      if bs'.insCur < bs'.snapArr.length then
        Sum.inl { ready := jb.ready, phase := .build bs' }
      else
        let u_done := bs'.curNode
        let newReady := jb.ready ++ [u_done]
        if u_done.resArr.length ≤ cp.B_scan then
          Sum.inr (newReady, u_done.resArr, false)
        else if r.val + newReady.length ≥ cp.D_max then
          Sum.inr (newReady, [], true)
        else
          let cs_new := CopyState.init u_done.histArr.length
          Sum.inl { ready := newReady, phase := .copy cs_new }

noncomputable def stepStage2 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp) :
    ChainEngineState cp :=
  let pts := st.hp.coords
  let outJobs : Fin cp.D_max → Option (SuffixJob cp ⊕ (List (MNode cp) × List ℕ × Bool)) := fun r =>
    if hr : r.val < st.serving.length then
      match st.jobs r with
      | none => none
      | some jb =>
          let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
            ω₂.1 ⟨r.val * cp.B_scan + j.val, by
              have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
                calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan :=
                      Nat.add_lt_add_left j.isLt _
                  _ = (r.val + 1) * cp.B_scan := by ring
                  _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
              exact Nat.lt_add_right _ this⟩
          some (advanceOneJob cp pts st.gt (st.serving[r.val]'hr) r jb bSeeds (ω₂.2 r.castSucc))
    else
      none
  let firstCommit : Option (Fin cp.D_max × List (MNode cp) × List ℕ × Bool) :=
    (List.finRange cp.D_max).findSome? (fun r =>
      match outJobs r with
      | some (Sum.inr (suf, lf, ov)) => some (r, suf, lf, ov)
      | _ => none)
  match firstCommit with
  | some (r₀, newSuf, newLeaf, newOv) =>
      let serving₂ := st.serving.take r₀.val ++ newSuf
      let jobs₂ : Fin cp.D_max → Option (SuffixJob cp) := fun r =>
        if r.val < r₀.val then
          match outJobs r with
          | some (Sum.inl jb') => some jb'
          | _ => none
        else
          none
      { st with serving := serving₂, jobs := jobs₂, leafArr := newLeaf, leafOverflow := newOv }
  | none =>
      let jobs₂ : Fin cp.D_max → Option (SuffixJob cp) := fun r =>
        match outJobs r with
        | some (Sum.inl jb') => some jb'
        | _ => none
      if !st.leafOverflow && decide (cp.B_scan < st.leafArr.length) then
        if st.serving.length < cp.D_max && decide (st.leafArr.length ≤ cp.B_scan + 1) then
          let leafCtr := ω₂.2 (Fin.last cp.D_max)
          let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts st.leafArr leafCtr
          let P₀_uid := st.leafArr.toFinset.image st.gt.uidOf
          let bs0 := BuildState.init cp st.leafArr.length st.leafArr os.1 os.2 P₀_uid
          let steps := min st.leafArr.length (cp.B_scan + 1)
          let leafSeeds : Fin steps → OpSeed cp := fun j =>
            ω₂.1 ⟨cp.D_max * cp.B_scan + j.val, by
              have hj : j.val < cp.B_scan + 1 := lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)
              exact Nat.add_lt_add_left hj _⟩
          let bsDone := advanceBuildLoop cp pts steps leafSeeds bs0
          let u_leaf := bsDone.curNode
          if u_leaf.resArr.length ≤ cp.B_scan then
            { st with
              serving := st.serving ++ [u_leaf]
              jobs := jobs₂
              leafArr := u_leaf.resArr
              leafOverflow := false }
          else
            { st with
              serving := st.serving ++ [u_leaf]
              jobs := jobs₂
              leafArr := []
              leafOverflow := true }
        else
          { st with jobs := jobs₂, leafArr := [], leafOverflow := true }
      else
        { st with jobs := jobs₂ }

def stage3At {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (cur : ChainEngineState cp) (r : Fin cp.D_max) :
    ChainEngineState cp :=
  if hr : r.val < cur.serving.length then
    match cur.jobs r with
    | some _ => cur
    | none =>
        let mn := cur.serving[r.val]'hr
        if mn.nd.birthSize ≤ 64 * K_alpha d * mn.nd.age then
          if mn.nd.denseArr.length ≤ cp.B_scan then
            { cur with
              serving := cur.serving.take r.val
              jobs := fun rr => if rr.val < r.val then cur.jobs rr else none
              leafArr := mn.nd.denseArr
              leafOverflow := false }
          else
            { cur with
              jobs := Function.update cur.jobs r
                (some { ready := [], phase := .copy (CopyState.init mn.histArr.length) }) }
        else
          cur
  else
    cur

def stepStage3 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) : ChainEngineState cp :=
  (List.finRange cp.D_max).foldl (stage3At cp) st

noncomputable def stepStage4 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₄ : Stage4Coins cp) :
    ChainEngineState cp :=
  let pts := st.hp.coords
  let leafPair : Option (ℕ × ℕ) :=
    if !st.leafOverflow && decide (st.leafArr.length ≤ cp.B_scan) then
      evalExactLeafPair pts st.leafArr
    else
      none
  let nodeCands : List (Option (ℕ × ℕ)) :=
    (List.finRange cp.D_max).flatMap (fun i =>
      if hi : i.val < st.serving.length then
        let mn := st.serving[i.val]'hi
        let bp := evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr (ω₄ i)
        let ses := (List.finRange cp.N_cfg).map (fun c => (mn.nd.cfgs c).st.storedEdge)
        bp :: ses
      else
        [])
  let ans := evalBestGlobalAnswer pts st.hp.actList (leafPair :: nodeCands)
  { st with cachedAns := ans }

noncomputable def stepChainEngine {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp)
    (uop : InternalUpdate d) (coins : StepCoinBundle cp) :
    ChainEngineState cp × Option ℕ :=
  let (st₁, rh) := stepStage1 cp st uop coins.1
  let st₂ := stepStage2 cp st₁ coins.2.1
  let st₃ := stepStage3 cp st₂
  let st₄ := stepStage4 cp st₃ coins.2.2
  (st₄, rh)

/-! ### 5. Structural & Scheduler Invariants (`SuffixJobInv`, `PostStage1JobInv`, `ChainEngineWF`) -/

/-- Parameterized job invariant with `slack ∈ {0, cp.B_scan}` (`slack = 0` at rest, `slack = cp.B_scan`
immediately after Stage 1 before Stage 2 advances `lvlProg` by `cp.B_scan`). -/
def SuffixJobInvSlack {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (slack : ℕ)
    (actHandles : Finset ℕ) (pts : ℕ → EuclideanSpace ℝ (Fin d)) (gt : GhostTracker d)
    (S_anchor : Finset ℕ) (anchorNode : MNode cp) (r : ℕ) (jb : SuffixJob cp) : Prop :=
  let s := jb.ready.length
  let M_r := anchorNode.nd.birthSize
  let T_end := foldResiduals pts S_anchor jb.ready
  let prevNode : MNode cp :=
    match jb.ready.getLast? with
    | none => anchorNode
    | some u_last => u_last
  let srcHist := prevNode.histArr
  r + s < cp.D_max ∧
  ChainListInv cp actHandles pts gt S_anchor jb.ready ∧
  (∀ q (hq : q < s),
    let u_q := jb.ready[q]'hq
    (q = 0 → u_q.nd.birthSize ≤ 2 * M_r) ∧
    (∀ q' (hq' : q' < s), q ≤ q' →
      (jb.ready[q']'hq').nd.birthSize * (2 * cp.D2) ^ (q' - q) ≤
        u_q.nd.birthSize * (2 * cp.D2 + 1) ^ (q' - q)) ∧
    cp.B_scan * u_q.nd.age ≤
      (s - 1 - q) * (12 * u_q.nd.birthSize) + 6 * u_q.nd.birthSize + jb.phase.lvlProg + slack) ∧
  64 * K_alpha d * cp.B_scan * anchorNode.nd.age ≤
    cp.B_scan * (M_r + 64 * K_alpha d) +
      64 * K_alpha d * (s * (48 * M_r) + jb.phase.lvlProg + slack) ∧
  match jb.phase with
  | .copy cs =>
      cs.copyCur < cs.L_hist ∧
      cs.L_hist ≤ 2 * prevNode.nd.birthSize ∧
      CopyStateInv srcHist T_end cs
  | .build bs =>
      bs.insCur < bs.snapArr.length ∧
      bs.L_hist ≤ 2 * prevNode.nd.birthSize ∧
      cp.B_scan * bs.curNode.nd.age ≤ bs.insCur + slack ∧
      (if h0 : s = 0 then
        bs.curNode.nd.birthSize ≤ 2 * M_r
      else
        bs.curNode.nd.birthSize * (2 * cp.D2) ≤
          (jb.ready[s - 1]'(by omega)).nd.birthSize * (2 * cp.D2 + 1)) ∧
      BuildStateInv cp pts gt T_end bs

abbrev SuffixJobInv {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :=
  SuffixJobInvSlack cp 0

def ChainEngineWF {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (P : DynamicPointSet d) (st : ChainEngineState cp) : Prop :=
  let actH := P.activeHandles
  let pts := st.hp.coords
  st.hp.WellFormed P ∧
  GhostTrackerWF actH pts st.gt ∧
  st.serving.length ≤ cp.D_max ∧
  ChainListInv cp actH pts st.gt actH st.serving ∧
  (∀ r : Fin cp.D_max,
    if hr : r.val < st.serving.length then
      let mn := st.serving[r.val]'hr
      match st.jobs r with
      | none => 64 * K_alpha d * mn.nd.age < mn.nd.birthSize
      | some jb =>
          SuffixJobInv cp actH pts st.gt (foldResiduals pts actH (st.serving.take r.val)) mn r.val jb
    else
      st.jobs r = none) ∧
  (st.leafOverflow = false →
    st.leafArr.Nodup ∧
    st.leafArr.toFinset = foldResiduals pts actH st.serving ∧
    st.leafArr.length ≤ cp.B_scan)

theorem empty_chainEngineWF {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    ChainEngineWF cp (DynamicPointSet.empty d) (ChainEngineState.empty cp) := by
  refine ⟨HandlePool.empty_wellFormed d cp.n, ghostTracker_empty_wf d _, Nat.zero_le _, trivial, ?_, ?_⟩
  · intro r; simp [ChainEngineState.empty]
  · intro _; refine ⟨List.nodup_nil, ?_, Nat.zero_le _⟩
    simp [ChainEngineState.empty, DynamicPointSet.empty, foldResiduals]

/-! ### 6. Derived Age Bounds from `SuffixJobInvSlack` -/

theorem suffixJobInvSlack_bounds {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {slack : ℕ} (hslack : slack ≤ cp.B_scan)
    {actH : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    {S_anc : Finset ℕ} {anc : MNode cp} {r : ℕ} {jb : SuffixJob cp}
    (hMr : cp.B_scan < anc.nd.birthSize)
    (hjb : SuffixJobInvSlack cp slack actH pts gt S_anc anc r jb) :
    (∀ q (hq : q < jb.ready.length),
      128 * K_alpha d * (jb.ready[q]'hq).nd.age < (jb.ready[q]'hq).nd.birthSize ∧
      2 * cp.D2 * (jb.ready[q]'hq).nd.age < (jb.ready[q]'hq).nd.birthSize ∧
      (jb.ready[q]'hq).nd.birthSize ≤ 4 * anc.nd.birthSize) ∧
    16 * K_alpha d * anc.nd.age < anc.nd.birthSize ∧
    jb.phase.lvlProg + slack ≤ 20 * anc.nd.birthSize ∧
    (∀ bs, jb.phase = .build bs → bs.curNode.nd.age ≤ bs.curNode.nd.birthSize) := by
  have hK_ge : 36 ≤ K_alpha d := K_alpha_ge_36 d
  rcases cp.sched_bounds with ⟨hB1, hB2, hB3, hB4⟩
  have hD2_pos : 1 ≤ cp.D2 := by unfold ChainParams.D2; omega
  have hD2_def : cp.D2 = cp.D_max + 2 := rfl
  dsimp only [SuffixJobInvSlack] at hjb
  rcases hjb with ⟨hrs_lt, hcl_ready, hready_b, hanc_age, hph⟩
  let s := jb.ready.length
  let M_r := anc.nd.birthSize
  have hready_le_4Mr : ∀ q (hq : q < s), (jb.ready[q]'hq).nd.birthSize ≤ 4 * M_r := by
    intro q hq
    have h0 : 0 < s := by omega
    have hu0 : (jb.ready[0]'h0).nd.birthSize ≤ 2 * M_r := (hready_b 0 h0).1 rfl
    have hpow := (hready_b 0 h0).2.1 q hq (Nat.zero_le q)
    have h2 := ratio_le_two_of_pow_bound hD2_pos (by omega) hpow
    omega
  have hlvl_vs_ready : ∀ q (hq : q < s),
      jb.phase.lvlProg + slack ≤ 10 * (jb.ready[q]'hq).nd.birthSize := by
    intro q hq
    have hlast_eq : jb.ready.getLast? = some (jb.ready[s - 1]'(by omega)) := by
      rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem (by omega)]
    have hpow_last := (hready_b q hq).2.1 (s - 1) (by omega) (by omega)
    have hlast_le : (jb.ready[s - 1]'(by omega)).nd.birthSize ≤ 2 * (jb.ready[q]'hq).nd.birthSize :=
      ratio_le_two_of_pow_bound hD2_pos (by omega) hpow_last
    have huq_B : cp.B_scan < (jb.ready[q]'hq).nd.birthSize :=
      (chainListInv_mem_birthSize S_anc jb.ready hcl_ready _ (List.getElem_mem hq)).1
    cases hphase : jb.phase with
    | copy cs =>
        rw [hphase, hlast_eq] at hph
        dsimp only [JobPhase.lvlProg] at hph ⊢
        rcases hph with ⟨hcur_lt, hL_le, _⟩
        omega
    | build bs =>
        rw [hphase, hlast_eq] at hph
        dsimp only [JobPhase.lvlProg] at hph ⊢
        rcases hph with ⟨hins_lt, hL_le, _, hmc_rat, hbinv⟩
        rw [dif_neg (by omega)] at hmc_rat
        have hmc_le_last : bs.curNode.nd.birthSize ≤ 2 * (jb.ready[s - 1]'(by omega)).nd.birthSize :=
          ratio_le_two_of_pow_bound (k := 1) hD2_pos (by omega) (by simpa using hmc_rat)
        have hsnap_eq : bs.curNode.nd.birthSize = bs.snapArr.length := hbinv.2.2.2.1
        omega
  have hlvl_vs_Mr : jb.phase.lvlProg + slack ≤ 20 * M_r := by
    by_cases hs0 : s = 0
    · have hlast_none : jb.ready.getLast? = none := by
        cases hlr : jb.ready with
        | nil => rfl
        | cons _ _ => simp [s, hlr] at hs0
      cases hphase : jb.phase with
      | copy cs =>
          rw [hphase, hlast_none] at hph
          dsimp only [JobPhase.lvlProg] at hph ⊢
          rcases hph with ⟨hcur_lt, hL_le, _⟩
          omega
      | build bs =>
          rw [hphase, hlast_none] at hph
          dsimp only [JobPhase.lvlProg] at hph ⊢
          rcases hph with ⟨hins_lt, hL_le, _, hmc_rat, hbinv⟩
          rw [dif_pos hs0] at hmc_rat
          have hsnap_eq : bs.curNode.nd.birthSize = bs.snapArr.length := hbinv.2.2.2.1
          omega
    · have h0 : 0 < s := by omega
      have h10 := hlvl_vs_ready 0 h0
      have h2 : (jb.ready[0]'h0).nd.birthSize ≤ 2 * M_r := (hready_b 0 h0).1 rfl
      omega
  refine ⟨fun q hq => ?_, ?_, hlvl_vs_Mr, ?_⟩
  · have hlvl_q := hlvl_vs_ready q hq
    have hage_q := (hready_b q hq).2.2
    let M_q := (jb.ready[q]'hq).nd.birthSize
    have huq_B : cp.B_scan < M_q :=
      (chainListInv_mem_birthSize S_anc jb.ready hcl_ready _ (List.getElem_mem hq)).1
    have h_s1q : s - 1 - q ≤ cp.D_max - 1 := by omega
    have hmul_s : (s - 1 - q) * (12 * M_q) ≤ (cp.D_max - 1) * (12 * M_q) :=
      Nat.mul_le_mul_right _ h_s1q
    have hB_age_ub : cp.B_scan * (jb.ready[q]'hq).nd.age ≤ (12 * cp.D2) * M_q := by
      have hsum : (cp.D_max - 1) * 12 + 6 + 10 ≤ 12 * cp.D2 := by omega
      have hsum_M : ((cp.D_max - 1) * 12 + 6 + 10) * M_q ≤ (12 * cp.D2) * M_q :=
        Nat.mul_le_mul_right M_q hsum
      have hexp : (cp.D_max - 1) * (12 * M_q) + 6 * M_q + 10 * M_q =
          ((cp.D_max - 1) * 12 + 6 + 10) * M_q := by ring
      linarith only [hage_q, hmul_s, hlvl_q, hsum_M, hexp]
    refine ⟨?_, ?_, hready_le_4Mr q hq⟩
    · -- `128 * K_alpha d * age < M_q` since `128 * K_alpha d * (12 * D2) < B_scan` and `0 < M_q`
      by_cases ha0 : (jb.ready[q]'hq).nd.age = 0
      · rw [ha0]; omega
      · have h1 := Nat.mul_lt_mul_of_pos_right hB2 (by omega : 0 < (jb.ready[q]'hq).nd.age)
        have h2 : 128 * K_alpha d * (12 * cp.D2) * (jb.ready[q]'hq).nd.age < (12 * cp.D2) * M_q :=
          lt_of_lt_of_le h1 hB_age_ub
        have h3 : (12 * cp.D2) * (128 * K_alpha d * (jb.ready[q]'hq).nd.age) < (12 * cp.D2) * M_q := by
          linarith only [h2]
        exact lt_of_mul_lt_mul_left h3 (Nat.zero_le _)
    · by_cases ha0 : (jb.ready[q]'hq).nd.age = 0
      · rw [ha0]; omega
      · have h1 := Nat.mul_lt_mul_of_pos_right hB3 (by omega : 0 < (jb.ready[q]'hq).nd.age)
        have h2 : 2 * cp.D2 * (12 * cp.D2) * (jb.ready[q]'hq).nd.age < (12 * cp.D2) * M_q :=
          lt_of_lt_of_le h1 hB_age_ub
        have h3 : (12 * cp.D2) * (2 * cp.D2 * (jb.ready[q]'hq).nd.age) < (12 * cp.D2) * M_q := by
          linarith only [h2]
        exact lt_of_mul_lt_mul_left h3 (Nat.zero_le _)
  · -- `16 * K_alpha d * anc.nd.age < M_r`
    have hs_ub : s ≤ cp.D_max := by omega
    have hs_mul : s * (48 * M_r) ≤ cp.D_max * (48 * M_r) := Nat.mul_le_mul_right _ hs_ub
    have hprog_tot : s * (48 * M_r) + jb.phase.lvlProg + slack ≤ (48 * cp.D2) * M_r := by
      have h1 : cp.D_max * 48 + 20 ≤ 48 * cp.D2 := by omega
      have h2 : (cp.D_max * 48 + 20) * M_r ≤ (48 * cp.D2) * M_r := Nat.mul_le_mul_right M_r h1
      have h3 : cp.D_max * (48 * M_r) + 20 * M_r = (cp.D_max * 48 + 20) * M_r := by ring
      linarith only [hs_mul, hlvl_vs_Mr, h2, h3]
    have hterm2 : 64 * K_alpha d * (s * (48 * M_r) + jb.phase.lvlProg + slack) ≤ cp.B_scan * M_r := by
      calc 64 * K_alpha d * (s * (48 * M_r) + jb.phase.lvlProg + slack)
          ≤ 64 * K_alpha d * ((48 * cp.D2) * M_r) := Nat.mul_le_mul_left _ hprog_tot
        _ = (64 * K_alpha d * (48 * cp.D2)) * M_r := by ring
        _ ≤ cp.B_scan * M_r := Nat.mul_le_mul_right M_r hB4
    have hB_tot : 64 * K_alpha d * cp.B_scan * anc.nd.age < 3 * cp.B_scan * M_r := by
      have h64_lt : cp.B_scan * (M_r + 64 * K_alpha d) < 2 * cp.B_scan * M_r := by
        have hlt_m : M_r + 64 * K_alpha d < 2 * M_r := by omega
        have hm := Nat.mul_lt_mul_of_pos_left hlt_m (by omega : 0 < cp.B_scan)
        linarith only [hm]
      linarith only [hanc_age, hterm2, h64_lt]
    have h64_3 : cp.B_scan * (64 * K_alpha d * anc.nd.age) < cp.B_scan * (3 * M_r) := by
      linarith only [hB_tot]
    have h64_lt3 : 64 * K_alpha d * anc.nd.age < 3 * M_r :=
      lt_of_mul_lt_mul_left h64_3 (Nat.zero_le _)
    have hmul4 : 4 * (16 * K_alpha d * anc.nd.age) = 64 * K_alpha d * anc.nd.age := by ring
    omega
  · intro bs hbs
    rw [hbs] at hph
    rcases hph with ⟨hins_lt, _, hage_ins, _, hbinv⟩
    have hsnap_eq : bs.curNode.nd.birthSize = bs.snapArr.length := hbinv.2.2.2.1
    have hbs_B : cp.B_scan < bs.curNode.nd.birthSize := hbinv.2.2.2.2.2.1
    have hB_age_lt : cp.B_scan * bs.curNode.nd.age < 2 * bs.curNode.nd.birthSize := by
      omega
    have h2_le_B : 2 ≤ cp.B_scan := by omega
    have h2_age : 2 * bs.curNode.nd.age ≤ cp.B_scan * bs.curNode.nd.age :=
      Nat.mul_le_mul_right _ h2_le_B
    omega

/-! ### 7. Stage 1, Stage 2, Stage 3, Stage 4 Deterministic Preservation (`stepChainEngine_wf`) -/

/-- Intermediate state invariant right after Stage 1 (with `slack = cp.B_scan` on active jobs and
`≤ M_r + 64 * K_alpha d` on `none` serving slots, and `leafArr.length ≤ cp.B_scan + 1`). -/
def PostStage1WF {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (P' : DynamicPointSet d) (st₁ : ChainEngineState cp) : Prop :=
  let actH := P'.activeHandles
  let pts := st₁.hp.coords
  st₁.hp.WellFormed P' ∧
  GhostTrackerWF actH pts st₁.gt ∧
  st₁.serving.length ≤ cp.D_max ∧
  ChainListInv cp actH pts st₁.gt actH st₁.serving ∧
  (∀ r : Fin cp.D_max,
    if hr : r.val < st₁.serving.length then
      let mn := st₁.serving[r.val]'hr
      match st₁.jobs r with
      | none => 64 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize + 64 * K_alpha d
      | some jb =>
          SuffixJobInvSlack cp cp.B_scan actH pts st₁.gt
            (foldResiduals pts actH (st₁.serving.take r.val)) mn r.val jb
    else
      st₁.jobs r = none) ∧
  (st₁.leafOverflow = false →
    st₁.leafArr.Nodup ∧
    st₁.leafArr.toFinset = foldResiduals pts actH st₁.serving ∧
    st₁.leafArr.length ≤ cp.B_scan + 1)

/-- Intermediate state invariant right after Stage 2 (jobs restored to `slack = 0`, `leafArr.length ≤ cp.B_scan`,
and `none` serving slots satisfy `64 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize + 64 * K_alpha d`). -/
def PostStage2WF {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (P' : DynamicPointSet d) (st₂ : ChainEngineState cp) : Prop :=
  let actH := P'.activeHandles
  let pts := st₂.hp.coords
  st₂.hp.WellFormed P' ∧
  GhostTrackerWF actH pts st₂.gt ∧
  st₂.serving.length ≤ cp.D_max ∧
  ChainListInv cp actH pts st₂.gt actH st₂.serving ∧
  (∀ r : Fin cp.D_max,
    if hr : r.val < st₂.serving.length then
      let mn := st₂.serving[r.val]'hr
      match st₂.jobs r with
      | none => 64 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize + 64 * K_alpha d
      | some jb =>
          SuffixJobInv cp actH pts st₂.gt
            (foldResiduals pts actH (st₂.serving.take r.val)) mn r.val jb
    else
      st₂.jobs r = none) ∧
  (st₂.leafOverflow = false →
    st₂.leafArr.Nodup ∧
    st₂.leafArr.toFinset = foldResiduals pts actH st₂.serving ∧
    st₂.leafArr.length ≤ cp.B_scan)

end UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
