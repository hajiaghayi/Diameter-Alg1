import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_CPa
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.C14e

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2

attribute [local instance 10] Classical.propDecidable

theorem goodStage4Coins_card_ge {d : ℕ} {params : LocalScaleParams} {h ψ : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (hψ0 : 0 < ψ) (hmc : HasMCBaselineBound (hpjAlpha d) ψ cp.k_base)
    (hδ_base_le1 : ψ + ((cp.k_base * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) ≤ 1)
    {P' : DynamicPointSet d} {st₃ : ChainEngineState cp}
    (hwf₃ : ChainEngineWF cp P' st₃) (hgd₃ : ChainEngineGood cp hh0 hh1 st₃) :
    let δ_base : ℝ := ψ + ((cp.k_base * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    open Classical in
    (1 - (cp.D_max : ℝ) * δ_base) * (Fintype.card (Stage4Coins cp) : ℝ) ≤
      ((Finset.univ.filter (GoodStage4Coins cp st₃)).card : ℝ) := by
  intro δ_base
  rcases hwf₃ with ⟨hhp, hgt, hserv_len, hserv_cl, hjobs_wf, _⟩
  let actH := P'.activeHandles
  let pts := st₃.hp.coords
  have hact_sub_T : ∀ x ∈ actH, x < cp.T_pow := by
    rcases hhp with ⟨hnf_le, _, _, hact_set, hact_lt, _, _, _⟩
    intro x hx; dsimp only [actH] at hx
    rw [← hact_set, List.mem_toFinset] at hx
    exact lt_of_lt_of_le (hact_lt x hx) (hnf_le.trans cp.hT_pow)
  have hact_n : actH.card ≤ cp.n := by
    rcases hhp with ⟨hnf_le, hact_nd, _, hact_set, _, _, hsum, _⟩
    dsimp only [actH]; rw [← hact_set, List.toFinset_card_of_nodup hact_nd]; omega
  have hδ_base0 : 0 ≤ δ_base := by
    have : (0 : ℝ) ≤ ((cp.k_base * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by positivity
    linarith only [hψ0.le, this]
  let P_i : Fin cp.D_max → (Fin cp.k_base → Fin (2 ^ cp.q_idx)) → Prop := fun i u =>
    ∀ hi : i.val < st₃.serving.length,
      let mn := st₃.serving[i.val]'hi
      SatisfiesNodeBaselineCond pts mn.nd.o mn.nd.V mn.nd.curSet
        (evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr u)
  have heach : ∀ i : Fin cp.D_max,
      (1 - δ_base) * (Fintype.card (Fin cp.k_base → Fin (2 ^ cp.q_idx)) : ℝ) ≤
        (((Finset.univ : Finset (Fin cp.k_base → Fin (2 ^ cp.q_idx))).filter (P_i i)).card : ℝ) := by
    intro i
    by_cases hi : i.val < st₃.serving.length
    · set mn := st₃.serving[i.val]'hi
      rcases (chainListInv_getElem actH st₃.serving (Finset.Subset.refl _) hserv_cl).2 i.val hi
        with ⟨hSi_sub, hcur_eq, _, hbsz_B, _, hage_i, _, _, hwf_i⟩
      have hcur_act : mn.nd.curSet ⊆ actH := hcur_eq.symm ▸ hSi_sub
      have hcur_T : ∀ x ∈ mn.nd.curSet, x < cp.T_pow := fun x hx => hact_sub_T x (hcur_act hx)
      have hcp_i := (hgd₃.2.1 mn (List.getElem_mem hi)).1
      have hbsz_card : mn.nd.birthSize = mn.nd.birthSet.card := hwf_i.1.2.1
      have hm_pos : 1 ≤ mn.nd.birthSet.card := by
        have := cp.sched_bounds.1; dsimp only [mn] at *; omega
      have hage16 : 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSet.card := by
        rw [← hbsz_card]
        have hslot := hjobs_wf i
        rw [dif_pos hi] at hslot; dsimp only at hslot
        cases hj : st₃.jobs i with
        | none =>
            rw [hj] at hslot
            have hm4 : 4 * (16 * K_alpha d * mn.nd.age) = 64 * K_alpha d * mn.nd.age := by ring
            dsimp only [mn] at *
            omega
        | some jb =>
            rw [hj] at hslot
            exact Nat.le_of_lt (suffixJobInvSlack_bounds (Nat.zero_le _) hbsz_B hslot).2.1
      have hage_cur : HasNodeAge mn.nd.birthSet (mn.nd.curSet.image st₃.gt.uidOf) mn.nd.age := by
        rwa [hcur_eq]
      have hbase := baseline_good_via_ghost (q_idx := cp.q_idx) (T_pow := cp.T_pow) cp.hk_base
        hψ0 hmc hgt hcur_act hm_pos hcp_i hage_cur hage16 hcur_T hwf_i.1.1 rfl
      have hlen_le_n : mn.nd.denseArr.length ≤ cp.n := by
        rw [← List.toFinset_card_of_nodup hwf_i.1.1]
        exact (Finset.card_le_card hcur_act).trans hact_n
      have hmul_le : ((cp.k_base * mn.nd.denseArr.length : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) ≤
          ((cp.k_base * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by
        refine mul_le_mul_of_nonneg_right ?_ (by positivity)
        exact_mod_cast Nat.mul_le_mul_left cp.k_base hlen_le_n
      have h1 : 1 - δ_base ≤
          1 - ψ - ((cp.k_base * mn.nd.denseArr.length : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by
        dsimp only [δ_base]; linarith only [hmul_le]
      refine ((mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)).trans hbase).trans
        (Nat.cast_le.mpr (Finset.card_le_card (fun u hu => ?_)))
      have hgd_u := of_mem_filter_any hu
      exact mem_filter_univ_any (fun hi' => by
        have : hi' = hi := Subsingleton.elim _ _; rw [this]; exact hgd_u)
    · have hall : (Finset.univ : Finset (Fin cp.k_base → Fin (2 ^ cp.q_idx))).filter (P_i i) = Finset.univ :=
        Finset.filter_true_of_mem (fun _ _ hi' => absurd hi' hi)
      rw [hall, Finset.card_univ]
      have h1 : 1 - δ_base ≤ 1 := by linarith only [hδ_base0]
      simpa only [one_mul] using mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg _)
  have hpi := pi_good_card_ge P_i hδ_base0 hδ_base_le1 heach
  rw [Fintype.card_fin] at hpi
  refine hpi.trans (Nat.cast_le.mpr (Finset.card_le_card (fun ω₄ hω₄ => ?_)))
  exact mem_filter_univ_any (of_mem_filter_any hω₄)

theorem goodStepCoins_card_ge {d : ℕ} {params : LocalScaleParams} {h ε₀ ψ : ℝ}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (hε0 : 0 ≤ ε₀) (hε1 : ε₀ ≤ 1)
    (hψ0 : 0 < ψ) (hmc : HasMCBaselineBound (hpjAlpha d) ψ cp.k_base)
    (hjob_err_le1 : ((cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))) +
      (cp.B_scan : ℝ) * ((2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀) ≤ 1)
    (hδ_base_le1 : ψ + ((cp.k_base * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) ≤ 1)
    (hgen_card : ∀ (i : Fin cp.N_cfg) (gen : SearchGeneration (Fin (2 ^ cp.L_p2)) (d + 1)),
      gen.m = 2 ^ cp.L_p2 → gen.h = h →
      open Classical in
      (1 - ε₀) * (Fintype.card (ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b) : ℝ) ≤
        ((Finset.univ.filter (fun ω : ExplicitBitSeed cp.R cp.ℓ cp.M₀ (d + 1) cp.b =>
          IsOrderIndepGoodFilter (polyFDisc cp.T_cdf cp.p_coord ω) (cp.τ_d : ℝ) (cp.τ_q : ℝ)
            cp.cap_u cp.cap_q gen (paddedLatNet (M_lat_of d params.e) (cp.specs i).A (cp.specs i).B))).card : ℝ))
    {P : DynamicPointSet d} (hP : P.WellFormed cp.n)
    {op : DynamicUpdate d} (hleg : IsLegalUpdate cp.n Set.univ P op)
    {st : ChainEngineState cp} (hwf : ChainEngineWF cp P st) (hgd : ChainEngineGood cp hh0 hh1 st) :
    let δ_op : ℝ := (2 * cp.N_cfg * cp.L_p2 : ℝ) * ε₀
    let δ_ctr : ℝ := (cp.phiRat : ℝ) + ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    let δ_base : ℝ := ψ + ((cp.k_base * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ))
    let δ_step : ℝ :=
      ((cp.N_op_s1 + cp.N_op_s2 : ℕ) : ℝ) * δ_op +
      ((cp.D_max + 1 : ℕ) : ℝ) * δ_ctr +
      (cp.D_max : ℝ) * δ_base
    open Classical in
    (1 - δ_step) * ((2 ^ cp.B_STEP : ℕ) : ℝ) ≤
      ((Finset.univ.filter (fun bits : Fin cp.B_STEP → Bool =>
        GoodStepCoins cp hh0 hh1 st (toInternalUpdate P op)
          (bitsToStepCoinBundle cp bits))).card : ℝ) := by
  intro δ_op δ_ctr δ_base δ_step
  let δ_S1 : ℝ := (cp.N_op_s1 : ℝ) * δ_op
  let δ_S2 : ℝ := ((cp.D_max + 1 : ℕ) : ℝ) * δ_ctr + (cp.N_op_s2 : ℝ) * δ_op
  let δ_S4 : ℝ := (cp.D_max : ℝ) * δ_base
  have hδ_op0 : 0 ≤ δ_op := by positivity
  have hδ_ctr0 : 0 ≤ δ_ctr := by
    have := cp.hφ0.le
    have : (0 : ℝ) ≤ ((cp.N_samp * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by positivity
    linarith only [‹0 ≤ (cp.phiRat : ℝ)›, this]
  have hδ_base0 : 0 ≤ δ_base := by
    have : (0 : ℝ) ≤ ((cp.k_base * cp.n : ℕ) : ℝ) * (2 : ℝ) ^ (-(cp.q_idx : ℤ)) := by positivity
    linarith only [hψ0.le, this]
  have hδ_op_le1 : δ_op ≤ 1 := by
    have hB1 : (1 : ℝ) ≤ (cp.B_scan : ℝ) := by have := cp.sched_bounds.1; exact_mod_cast (by omega : 1 ≤ cp.B_scan)
    have hmul : 1 * δ_op ≤ (cp.B_scan : ℝ) * δ_op := mul_le_mul_of_nonneg_right hB1 hδ_op0
    linarith only [hjob_err_le1, hδ_ctr0, hmul]
  have hδ_sum_eq : δ_S1 + δ_S2 + δ_S4 = δ_step := by
    dsimp only [δ_S1, δ_S2, δ_S4, δ_step]; push_cast; ring
  have hδS1_0 : 0 ≤ δ_S1 := mul_nonneg (Nat.cast_nonneg _) hδ_op0
  have hδS2_0 : 0 ≤ δ_S2 := add_nonneg (mul_nonneg (Nat.cast_nonneg _) hδ_ctr0) (mul_nonneg (Nat.cast_nonneg _) hδ_op0)
  have hδS4_0 : 0 ≤ δ_S4 := mul_nonneg (Nat.cast_nonneg _) hδ_base0
  by_cases h12_ge1 : 1 ≤ δ_S1 + δ_S2
  · have hneg : 1 - δ_step ≤ 0 := by linarith only [h12_ge1, hδS4_0, hδ_sum_eq]
    exact (mul_nonpos_of_nonpos_of_nonneg hneg (Nat.cast_nonneg _)).trans (Nat.cast_nonneg _)
  · push_neg at h12_ge1
    have hS1_card := goodStage1Coins_card_ge cp hh0 hh1 hε0 hε1 hδ_op_le1 hgen_card st
    have hfub12 := fubini_good_card_ge
      (PA := GoodStage1Coins cp hh0 hh1 st)
      (PAB := fun ω₁ ω₂ =>
        GoodStage2Coins cp hh0 hh1 (stepStage1 cp st (toInternalUpdate P op) ω₁).1 ω₂)
      (φ₁ := δ_S1) (φ₂ := δ_S2)
      hδS1_0 hδS2_0 hS1_card
      (fun ω₁ _ => by
        rcases stepStage1_spec h_clm_7_3 hd he1 cp hh0 hh1 hP hleg hwf ω₁ with ⟨P', _, hwf₁, _⟩
        exact goodStage2Coins_card_ge cp hh0 hh1 hε0 hε1 hgen_card hwf₁ hjob_err_le1)
    have hfub124 := fubini_good_card_ge
      (PA := fun p12 : Stage1Coins cp × Stage2Coins cp =>
        GoodStage1Coins cp hh0 hh1 st p12.1 ∧
        GoodStage2Coins cp hh0 hh1 (stepStage1 cp st (toInternalUpdate P op) p12.1).1 p12.2)
      (PAB := fun p12 ω₄ =>
        let st₁ := (stepStage1 cp st (toInternalUpdate P op) p12.1).1
        let st₂ := stepStage2 cp st₁ p12.2
        let st₃ := stepStage3 cp st₂
        GoodStage4Coins cp st₃ ω₄)
      (φ₁ := δ_S1 + δ_S2) (φ₂ := δ_S4)
      (add_nonneg hδS1_0 hδS2_0) hδS4_0 hfub12
      (fun ⟨ω₁, ω₂⟩ ⟨hc1, hc2⟩ => by
        rcases stepStage1_spec h_clm_7_3 hd he1 cp hh0 hh1 hP hleg hwf ω₁ with ⟨P', happ, hwf₁, hgd₁_imp⟩
        have hP' := applyDynamicUpdate_wellFormed hP hleg happ
        rcases stepStage2_spec h_lem_5_1 h_clm_7_3 hd he1 cp hh0 hh1 hP' hwf₁ ω₂ with ⟨hwf₂, hgd₂_imp⟩
        rcases stepStage3_spec cp hh0 hh1 hwf₂ with ⟨hwf₃, hgd₃_imp⟩
        have hgd₃ := hgd₃_imp (hgd₂_imp (hgd₁_imp hgd hc1) hc2)
        exact goodStage4Coins_card_ge cp hh0 hh1 hψ0 hmc hδ_base_le1 hwf₃ hgd₃)
    rw [hδ_sum_eq] at hfub124
    let fullEq : ((Stage1Coins cp × Stage2Coins cp) × Stage4Coins cp) ≃ (Fin cp.B_STEP → Bool) :=
      (Equiv.prodAssoc _ _ _).trans (bitsToStepCoinBundle cp).symm
    have hcard_bits : (Fintype.card ((Stage1Coins cp × Stage2Coins cp) × Stage4Coins cp) : ℝ) =
        ((2 ^ cp.B_STEP : ℕ) : ℝ) := by
      have h1 := Fintype.card_congr fullEq
      rw [Fintype.card_fun, Fintype.card_fin, Fintype.card_bool] at h1
      exact_mod_cast h1
    rw [hcard_bits] at hfub124
    refine hfub124.trans (Nat.cast_le.mpr ?_)
    rw [← Finset.card_map fullEq.toEmbedding]
    refine Finset.card_le_card (fun bits hbits => ?_)
    rcases Finset.mem_map.mp hbits with ⟨⟨⟨ω₁, ω₂⟩, ω₄⟩, hmem, hbits_eq⟩
    rw [← hbits_eq]; dsimp only [Equiv.coe_toEmbedding]
    rcases of_mem_filter_any hmem with ⟨⟨hc1, hc2⟩, hc4⟩
    refine mem_filter_univ_any ?_
    have hinv : bitsToStepCoinBundle cp (fullEq ((ω₁, ω₂), ω₄)) = (ω₁, ω₂, ω₄) := by
      dsimp only [fullEq, Equiv.trans_apply, Equiv.prodAssoc_apply]
      exact (bitsToStepCoinBundle cp).apply_symm_apply _
    rw [hinv]
    exact ⟨hc1, hc2, hc4⟩

end UL.Proof.clm_9_1_explicit_tradeoff.C14e
