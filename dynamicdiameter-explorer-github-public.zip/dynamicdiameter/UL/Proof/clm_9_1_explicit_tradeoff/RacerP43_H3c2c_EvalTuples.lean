import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3c1_SlotPure
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3c2a_SlotInit

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt RandExec RandExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2

/-! ### 1. Pure Mixed-Radix Single-Loop Lemma & Prefix Filter Helper -/

def foldEnc {M₀ ℓ : ℕ} (acc : ℕ) (τ : Fin ℓ → Fin M₀) : ℕ :=
  Fin.foldl ℓ (fun c s => c * M₀ + (τ s).val) acc

theorem foldEnc_zero_eq_encodeTuple {M₀ : ℕ} :
    ∀ {ℓ : ℕ} (τ : Fin ℓ → Fin M₀), foldEnc 0 τ = encodeTuple τ
  | 0, _ => by simp [foldEnc, encodeTuple]
  | ℓ + 1, τ => by
      unfold foldEnc
      rw [Fin.foldl_succ_last]
      change foldEnc 0 (fun j : Fin ℓ => τ j.castSucc) * M₀ + (τ (Fin.last ℓ)).val = _
      rw [foldEnc_zero_eq_encodeTuple]
      rfl

def foldCode {ℓ : ℕ} (M₀ : ℕ) (cnt : Fin ℓ → ℕ) (elig : Fin ℓ → ℕ → ℕ)
    (idx acc : ℕ) : ℕ × ℕ :=
  Fin.foldl ℓ (fun rc s => (rc.1 / cnt s, rc.2 * M₀ + elig s (rc.1 % cnt s))) (idx, acc)

private lemma foldCode_snd_eq_foldEnc {M₀ : ℕ} (hM₀ : 1 ≤ M₀) :
    ∀ {ℓ : ℕ} (cnt : Fin ℓ → ℕ) (elig : Fin ℓ → ℕ → ℕ),
      (∀ s : Fin ℓ, 1 ≤ cnt s) →
      (∀ (s : Fin ℓ) (j : ℕ), j < cnt s → elig s j < M₀) →
      ∀ (idx acc : ℕ),
        (foldCode M₀ cnt elig idx acc).2 = foldEnc acc (mixedTuple hM₀ cnt elig idx)
  | 0, _, _, _, _, _, _ => by simp [foldCode, foldEnc]
  | ℓ + 1, cnt, elig, hcnt, helig, idx, acc => by
      unfold foldCode foldEnc
      rw [Fin.foldl_succ, Fin.foldl_succ]
      have hmod_lt : idx % cnt 0 < cnt 0 := Nat.mod_lt idx (hcnt 0)
      have hel0 : elig 0 (idx % cnt 0) < M₀ := helig 0 _ hmod_lt
      have hm0 : (mixedTuple hM₀ cnt elig idx 0).val = elig 0 (idx % cnt 0) := by
        dsimp [mixedTuple]
        rw [dif_pos hel0]
      rw [hm0]
      exact foldCode_snd_eq_foldEnc hM₀ (fun j => cnt j.succ) (fun j => elig j.succ)
        (fun j => hcnt j.succ) (fun j r hr => helig j.succ r hr)
        (idx / cnt 0) (acc * M₀ + elig 0 (idx % cnt 0))

theorem mixedCodeFold_eq {M₀ ℓ : ℕ} (hM₀ : 1 ≤ M₀)
    (cnt : Fin ℓ → ℕ) (elig : Fin ℓ → ℕ → ℕ)
    (hcnt : ∀ s : Fin ℓ, 1 ≤ cnt s)
    (helig : ∀ (s : Fin ℓ) (j : ℕ), j < cnt s → elig s j < M₀)
    (idx : ℕ) :
    (foldCode M₀ cnt elig idx 0).2 = encodeTuple (mixedTuple hM₀ cnt elig idx) := by
  rw [foldCode_snd_eq_foldEnc hM₀ cnt elig hcnt helig idx 0, foldEnc_zero_eq_encodeTuple]

def finRangePfx {M₀ : ℕ} : ∀ (k : ℕ), k ≤ M₀ → List (Fin M₀)
  | 0, _ => []
  | k + 1, hk => finRangePfx k (Nat.le_of_succ_le hk) ++ [⟨k, hk⟩]

private lemma finRangePfx_castSucc {M₀ : ℕ} :
    ∀ (k : ℕ) (hk : k ≤ M₀),
      finRangePfx (M₀ := M₀ + 1) k (Nat.le_succ_of_le hk) =
        (finRangePfx (M₀ := M₀) k hk).map Fin.castSucc
  | 0, _ => rfl
  | k + 1, hk => by
      dsimp [finRangePfx]
      rw [finRangePfx_castSucc k (Nat.le_of_succ_le hk), List.map_append]
      rfl

theorem finRangePfx_full : ∀ (M₀ : ℕ), finRangePfx M₀ le_rfl = List.finRange M₀
  | 0 => rfl
  | M₀ + 1 => by
      dsimp [finRangePfx]
      have hc := finRangePfx_castSucc M₀ le_rfl
      have heq_prf : finRangePfx (M₀ := M₀ + 1) M₀ (Nat.le_of_succ_le le_rfl) =
          (finRangePfx (M₀ := M₀) M₀ le_rfl).map Fin.castSucc := hc
      rw [heq_prf, finRangePfx_full M₀]
      exact (List.finRange_succ_last (n := M₀)).symm

lemma finRangePfx_length {M₀ : ℕ} :
    ∀ (k : ℕ) (hk : k ≤ M₀), (finRangePfx k hk).length = k
  | 0, _ => rfl
  | k + 1, hk => by
      dsimp [finRangePfx]
      rw [List.length_append, finRangePfx_length k (Nat.le_of_succ_le hk)]
      rfl

lemma truncMul_le_cap (K : ℕ) : ∀ {ℓ : ℕ} (cnt : Fin ℓ → ℕ), truncMul K cnt ≤ K
  | 0, cnt => by
      unfold truncMul
      rw [Fin.foldl_zero]
      exact Nat.min_le_left K 1
  | ℓ + 1, cnt => by
      unfold truncMul
      rw [Fin.foldl_succ_last]
      exact Nat.min_le_left K _

lemma mul_add_lt_of_lt {ℓ M₀ s j : ℕ} (hs : s < ℓ) (hj : j < M₀) :
    s * M₀ + j < ℓ * M₀ := by
  have h1 : s * M₀ + j < (s + 1) * M₀ := by
    rw [Nat.succ_mul]
    omega
  have h2 : (s + 1) * M₀ ≤ ℓ * M₀ := Nat.mul_le_mul_right M₀ hs
  omega

lemma mul_add_ne_of_ne {M₀ s₁ j₁ s₂ j₂ : ℕ} (hj₁ : j₁ < M₀) (hj₂ : j₂ < M₀)
    (hne : s₁ ≠ s₂ ∨ j₁ ≠ j₂) : s₁ * M₀ + j₁ ≠ s₂ * M₀ + j₂ := by
  intro heq
  have hMpos : 0 < M₀ := by omega
  have hdiv : (s₁ * M₀ + j₁) / M₀ = (s₂ * M₀ + j₂) / M₀ := congrArg (· / M₀) heq
  rw [mul_comm s₁ M₀, Nat.mul_add_div hMpos, Nat.div_eq_of_lt hj₁, add_zero,
      mul_comm s₂ M₀, Nat.mul_add_div hMpos, Nat.div_eq_of_lt hj₂, add_zero] at hdiv
  subst hdiv
  rcases hne with hs | hj
  · exact hs rfl
  · exact hj (by omega)

/-! ### 2. Scratch Layout & Phase 1 (`s < ℓ, k < M₀` Cap Tests + `truncMul`) -/

def evalWStride (ℓ M₀ cap : ℕ) : ℤ :=
  12 + (ℓ : ℤ) + ((ℓ * M₀ : ℕ) : ℤ) + (cap : ℤ)

def evalCntOff (wEvalBase : ℤ) (s : ℕ) : ℤ :=
  wEvalBase + 12 + (s : ℤ)

def evalEligOff (ℓ M₀ : ℕ) (wEvalBase : ℤ) (s j : ℕ) : ℤ :=
  wEvalBase + 12 + (ℓ : ℤ) + ((s * M₀ + j : ℕ) : ℤ)

def evalCodesOff (ℓ M₀ : ℕ) (wEvalBase : ℤ) : ℤ :=
  wEvalBase + 12 + (ℓ : ℤ) + ((ℓ * M₀ : ℕ) : ℤ)

def evalCopyInnerKStmt (scrW scrR tblR : ℕ)
    (wCapBaseR wEvalBase rScrBase rWBase : ℤ)
    (ℓ M₀ d : ℕ) (A B_signed a₀ : ℚ) : ArithRAMStmt :=
  let wS := wEvalBase
  let wK := wEvalBase + 1
  let wCtr := wEvalBase + 2
  let wFlag := wEvalBase + 3
  let wCntS := wEvalBase + 4
  let wOffCap := wEvalBase + 10
  let eligBase := wEvalBase + 12 + (ℓ : ℤ)
  .seq (.writeWordHeap scrW (.lit wCntS) (.lit 0))
  (.seq (.writeWordHeap scrW (.lit wK) (.lit 0))
        (.repeatN (.lit (M₀ : ℤ))
          (.seq (.writeWordHeap scrW (.lit wOffCap)
                  (.add (.readHeap scrW (.lit wCapBaseR))
                    (.mul (.add (.mul (.readHeap scrW (.lit wS)) (.lit (M₀ : ℤ)))
                                (.readHeap scrW (.lit wK)))
                          (.lit ((d + 1 : ℕ) : ℤ)))))
          (.seq (copyVecToScrStmt scrW scrR tblR wCtr wOffCap (rScrBase + 3) (d + 1))
          (.seq (signedSqCapTestStmt scrW scrR scrR scrR wCtr wFlag rScrBase
                  (.lit (rScrBase + 3)) (.lit rWBase) d A B_signed a₀)
          (.seq (.ite (.intEq (.readHeap scrW (.lit wFlag)) (.lit 1))
                  (.seq (.writeWordHeap scrW
                          (.add (.lit eligBase)
                            (.add (.mul (.readHeap scrW (.lit wS)) (.lit (M₀ : ℤ)))
                                  (.readHeap scrW (.lit wCntS))))
                          (.readHeap scrW (.lit wK)))
                        (.writeWordHeap scrW (.lit wCntS)
                          (.add (.readHeap scrW (.lit wCntS)) (.lit 1))))
                  .skip)
                (.writeWordHeap scrW (.lit wK)
                  (.add (.readHeap scrW (.lit wK)) (.lit 1)))))))))

private theorem exec_evalCopyInnerKStmt {d TW BW TR BR scrW scrR tblR tblW : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCapBaseR wEvalBase rScrBase rWBase capBaseR baseW baseR : ℤ)
    {ℓ M₀ cap : ℕ} (s : Fin ℓ) (A B_signed a₀ : ℚ)
    (caps_r : Fin ℓ → Fin M₀ → EuclideanSpace ℝ (Fin (d + 1)))
    (w : EuclideanSpace ℝ (Fin d))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneR : tblR ≠ scrR)
    (hwEval : 0 ≤ wEvalBase ∧ wEvalBase + evalWStride ℓ M₀ cap ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScrBase ∧ rScrBase + 4 + (d : ℤ) ≤ (BR : ℤ))
    (hrW_disj : rScrBase + 4 + (d : ℤ) ≤ rWBase ∨ rWBase + (d : ℤ) ≤ rScrBase)
    (hwCap_disj : wCapBaseR < wEvalBase ∨ wEvalBase + evalWStride ℓ M₀ cap ≤ wCapBaseR)
    (hcapB : H3a.wRead m₀ scrW wCapBaseR = capBaseR)
    (hwS : H3a.wRead m₀ scrW wEvalBase = (s.val : ℤ))
    (hCaps : ∀ (s' : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)),
      H3a.rRead m₀ tblR (capBaseR + (((s'.val * M₀ + k.val) * (d + 1) : ℕ) : ℤ) + (j.val : ℤ)) =
        euclideanCoord (caps_r s' k) j)
    (hw_vec : ∀ i : Fin d, H3a.rRead m₀ scrR (rWBase + (i.val : ℤ)) = euclideanCoord w i) :
    let eligListS : List (Fin M₀) := open Classical in
      (List.finRange M₀).filter (fun k =>
        realSignedSqCapCond (A : ℝ) (B_signed : ℝ) (a₀ : ℝ) (caps_r s k) w)
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (evalCopyInnerKStmt scrW scrR tblR wCapBaseR wEvalBase rScrBase rWBase ℓ M₀ d A B_signed a₀)
        m₀ m₁ (50 + M₀ * (350 + 80 * d)) ∧
      InFootprint TW BW TR BR m₁ ∧
      H3a.wRead m₁ scrW (wEvalBase + 4) = @Nat.cast ℤ _ eligListS.length ∧
      (∀ (j : ℕ) (hj : j < eligListS.length),
        H3a.wRead m₁ scrW (evalEligOff ℓ M₀ wEvalBase s.val j) = @Nat.cast ℤ _ (eligListS[j]).val) ∧
      (∀ idx : ℤ,
        idx ≠ wEvalBase + 1 → idx ≠ wEvalBase + 2 → idx ≠ wEvalBase + 3 →
        idx ≠ wEvalBase + 4 → idx ≠ wEvalBase + 10 →
        (∀ j < M₀, idx ≠ evalEligOff ℓ M₀ wEvalBase s.val j) →
        H3a.wRead m₁ scrW idx = H3a.wRead m₀ scrW idx) ∧
      (∀ r : ℤ, (r < rScrBase ∨ rScrBase + 4 + (d : ℤ) ≤ r) →
        H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  classical
  intro eligListS
  have hstride_ge : 12 + (ℓ : ℤ) + ((ℓ * M₀ : ℕ) : ℤ) ≤ evalWStride ℓ M₀ cap := by
    unfold evalWStride; omega
  let P_k : Fin M₀ → Bool := fun k =>
    decide (realSignedSqCapCond (A : ℝ) (B_signed : ℝ) (a₀ : ℝ) (caps_r s k) w)
  let pfx : ∀ k ≤ M₀, List (Fin M₀) := fun k hk => (finRangePfx k hk).filter P_k
  have hpfx_len_le : ∀ k (hk : k ≤ M₀), (pfx k hk).length ≤ k := by
    intro k hk
    exact (List.length_filter_le P_k (finRangePfx k hk)).trans (by rw [finRangePfx_length])
  let m_a := H3a.wWrite m₀ scrW (wEvalBase + 4) 0
  let m_b := H3a.wWrite m_a scrW (wEvalBase + 1) 0
  have hd_a : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 4)) (.lit 0)) m₀ m_a 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wEvalBase + 4)) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd_b : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 1)) (.lit 0)) m_a m_b 10 :=
    DetExecAt.writeWordHeap 0 inp m_a scrW (.lit (wEvalBase + 1)) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_a : InFootprint TW BW TR BR m_a := InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)
  have hfp_b : InFootprint TW BW TR BR m_b := InFootprint.wWrite hfp_a hscrW (by omega) (by omega)
  have hfr_ab : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_b :=
    (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m₀ (wEvalBase + 4) 0).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_a (wEvalBase + 1) 0)
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    ∃ hk : k ≤ M₀,
      InFootprint TW BW TR BR m ∧
      H3a.wRead m scrW (wEvalBase + 1) = (k : ℤ) ∧
      H3a.wRead m scrW (wEvalBase + 4) = @Nat.cast ℤ _ (pfx k hk).length ∧
      (∀ (j : ℕ) (hj : j < (pfx k hk).length),
        H3a.wRead m scrW (evalEligOff ℓ M₀ wEvalBase s.val j) = @Nat.cast ℤ _ ((pfx k hk)[j]).val) ∧
      (∀ idx : ℤ,
        idx ≠ wEvalBase + 1 → idx ≠ wEvalBase + 2 → idx ≠ wEvalBase + 3 →
        idx ≠ wEvalBase + 4 → idx ≠ wEvalBase + 10 →
        (∀ j < M₀, idx ≠ evalEligOff ℓ M₀ wEvalBase s.val j) →
        H3a.wRead m scrW idx = H3a.wRead m₀ scrW idx) ∧
      (∀ r : ℤ, (r < rScrBase ∨ rScrBase + 4 + (d : ℤ) ≤ r) →
        H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
  have hInv0 : Inv 0 m_b := by
    refine ⟨ Nat.zero_le M₀, hfp_b, wRead_wWrite_self _ _ _ _,
      by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl,
      fun _ hj => by simp [pfx, finRangePfx] at hj,
      fun idx h1 _ _ h4 _ _ => ?_,
      fun _ _ => rfl, hfr_ab ⟩
    rw [wRead_wWrite_of_ne _ _ (Or.inr h1), wRead_wWrite_of_ne _ _ (Or.inr h4)]
  let C_k : ℕ := 350 + 80 * d
  obtain ⟨m_end, hInvM, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (M₀ : ℤ)) _ M₀ 10 C_k
    Inv hInv0 rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    (fun k hk m ⟨hk_le, hfp_m, hk_r, hcnt_r, helig_r, hkW_m, hkR_m, hfr_m⟩ => by
      have helig_off_ge : ∀ j < M₀, wEvalBase + 12 ≤ evalEligOff ℓ M₀ wEvalBase s.val j := by
        intro j _; unfold evalEligOff; omega
      have hwS_m : H3a.wRead m scrW wEvalBase = (s.val : ℤ) :=
        (hkW_m wEvalBase (by omega) (by omega) (by omega) (by omega) (by omega)
          (fun j hj => by have := helig_off_ge j hj; omega)).trans hwS
      have hcapB_m : H3a.wRead m scrW wCapBaseR = capBaseR :=
        (hkW_m wCapBaseR (by omega) (by omega) (by omega) (by omega) (by omega)
          (fun j hj => by
            have hlt := mul_add_lt_of_lt s.isLt hj
            unfold evalEligOff evalWStride at *; omega)).trans hcapB
      let off_sk : ℤ := capBaseR + (((s.val * M₀ + k) * (d + 1) : ℕ) : ℤ)
      let m1 := H3a.wWrite m scrW (wEvalBase + 10) off_sk
      have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 10))
          (.add (.readHeap scrW (.lit wCapBaseR))
            (.mul (.add (.mul (.readHeap scrW (.lit wEvalBase)) (.lit (M₀ : ℤ)))
                        (.readHeap scrW (.lit (wEvalBase + 1))))
                  (.lit ((d + 1 : ℕ) : ℤ))))) m m1 35 := by
        refine DetExecAt.writeWordHeap 0 inp m scrW (.lit (wEvalBase + 10)) _ rfl
          (by
            change H3a.wRead m scrW wCapBaseR +
              (H3a.wRead m scrW wEvalBase * (M₀ : ℤ) + H3a.wRead m scrW (wEvalBase + 1)) *
                ((d + 1 : ℕ) : ℤ) = off_sk
            rw [hcapB_m, hwS_m, hk_r]
            dsimp [off_sk])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp_m hscrW (by omega) (by omega)
      have hfr1 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m m1 :=
        RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m (wEvalBase + 10) off_sk
      obtain ⟨m2, hd2, hfp2, hcopied2, hkW2, hkR2, hfr2⟩ :=
        exec_copyVecToScrStmt (tblW := tblW) (tblR := tblR) inp
          (wEvalBase + 2) (wEvalBase + 10) off_sk (rScrBase + 3) baseW baseR (d + 1)
          hfp1 hscrW hscrR hneR ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ (by omega)
          (wRead_wWrite_self _ _ _ _)
      have hfr_02 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m2 :=
        (hfr_m.trans hfr1).trans hfr2
      have hG_m2 : ∀ j : Fin (d + 1),
          H3a.rRead m2 scrR ((rScrBase + 3) + (j.val : ℤ)) = euclideanCoord (caps_r s ⟨k, hk⟩) j := by
        intro j
        rw [hcopied2 j.val j.isLt]
        change H3a.rRead m1 tblR (off_sk + (j.val : ℤ)) = _
        rw [rRead_wWrite, hfr_m.2 tblR _ hneR (Or.inr (by omega))]
        exact hCaps s ⟨k, hk⟩ j
      have hw_m2 : ∀ i : Fin d,
          H3a.rRead m2 scrR (rWBase + (i.val : ℤ)) = euclideanCoord w i := by
        intro i
        have hdisj_i : rWBase + (i.val : ℤ) < rScrBase ∨ rScrBase + 4 + (d : ℤ) ≤ rWBase + (i.val : ℤ) := by
          have := i.isLt; omega
        rw [hkR2 _ (by omega)]
        change H3a.rRead m scrR (rWBase + (i.val : ℤ)) = _
        exact (hkR_m _ hdisj_i).trans (hw_vec i)
      have hex_sq := exec_signedSqCapTestStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
        (scrW := scrW) (scrR := scrR) (tblG := scrR) (tblW := scrR)
        inp (wEvalBase + 2) (wEvalBase + 3) rScrBase (rScrBase + 3) rWBase A B_signed a₀
        (caps_r s ⟨k, hk⟩) w hfp2 hscrW hscrR ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
        ⟨by omega, by omega⟩ (Or.inr (Or.inr le_rfl)) (Or.inr (by omega)) hG_m2 hw_m2
      obtain ⟨m3, hpr3, hflag3, hfp3, hkW3, hkR3, hd3⟩ :=
        execScratch_window_to_detExec
          (sw_signedSqCapTestStmt scrW scrR scrR scrR (wEvalBase + 2) (wEvalBase + 3) rScrBase
            (.lit (rScrBase + 3)) (.lit rWBase) d A B_signed a₀)
          hfp2 hex_sq
      have hfr3 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m2 m3 :=
        RadFrameOutside.of_preservesNonScratch _ _ _ _ _ _ hpr3
      let curL := (pfx k hk_le).length
      have hcurL_lt : curL < M₀ := lt_of_le_of_lt (hpfx_len_le k hk_le) hk
      have hcnt_m3 : H3a.wRead m3 scrW (wEvalBase + 4) = @Nat.cast ℤ _ curL := by
        rw [hkW3 _ (by omega), hkW2 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hcnt_r
      have hk_m3 : H3a.wRead m3 scrW (wEvalBase + 1) = (k : ℤ) := by
        rw [hkW3 _ (by omega), hkW2 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hk_r
      have hwS_m3 : H3a.wRead m3 scrW wEvalBase = (s.val : ℤ) := by
        rw [hkW3 _ (by omega), hkW2 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hwS_m
      have hpfx_step : pfx (k + 1) hk =
          if P_k ⟨k, hk⟩ then pfx k hk_le ++ [⟨k, hk⟩] else pfx k hk_le := by
        dsimp [pfx, finRangePfx]
        rw [List.filter_append, List.filter_cons, List.filter_nil]
        cases P_k ⟨k, hk⟩ <;> simp
      let brStmt : ArithRAMStmt :=
        .ite (.intEq (.readHeap scrW (.lit (wEvalBase + 3))) (.lit 1))
          (.seq (.writeWordHeap scrW
                  (.add (.lit (wEvalBase + 12 + (ℓ : ℤ)))
                    (.add (.mul (.readHeap scrW (.lit wEvalBase)) (.lit (M₀ : ℤ)))
                          (.readHeap scrW (.lit (wEvalBase + 4)))))
                  (.readHeap scrW (.lit (wEvalBase + 1))))
                (.writeWordHeap scrW (.lit (wEvalBase + 4))
                  (.add (.readHeap scrW (.lit (wEvalBase + 4))) (.lit 1))))
          .skip
      have hbr : ∃ m4 : ArithRAMMemory,
          DetExec inp brStmt m3 m4 65 ∧
          InFootprint TW BW TR BR m4 ∧
          H3a.wRead m4 scrW (wEvalBase + 1) = (k : ℤ) ∧
          H3a.wRead m4 scrW (wEvalBase + 4) = @Nat.cast ℤ _ (pfx (k + 1) hk).length ∧
          (∀ (j : ℕ) (hj : j < (pfx (k + 1) hk).length),
            H3a.wRead m4 scrW (evalEligOff ℓ M₀ wEvalBase s.val j) =
              @Nat.cast ℤ _ ((pfx (k + 1) hk)[j]).val) ∧
          (∀ idx : ℤ,
            idx ≠ wEvalBase + 1 → idx ≠ wEvalBase + 2 → idx ≠ wEvalBase + 3 →
            idx ≠ wEvalBase + 4 → idx ≠ wEvalBase + 10 →
            (∀ j < M₀, idx ≠ evalEligOff ℓ M₀ wEvalBase s.val j) →
            H3a.wRead m4 scrW idx = H3a.wRead m₀ scrW idx) ∧
          (∀ r : ℤ, (r < rScrBase ∨ rScrBase + 4 + (d : ℤ) ≤ r) →
            H3a.rRead m4 scrR r = H3a.rRead m₀ scrR r) ∧
          RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m4 := by
        by_cases hcond : realSignedSqCapCond (A : ℝ) (B_signed : ℝ) (a₀ : ℝ) (caps_r s ⟨k, hk⟩) w
        · have hPk : P_k ⟨k, hk⟩ = true := decide_eq_true hcond
          have hfl1 : H3a.wRead m3 scrW (wEvalBase + 3) = 1 := by
            rw [hflag3, if_pos hcond]
          have hc_t : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m3
              (.intEq (.readHeap scrW (.lit (wEvalBase + 3))) (.lit 1)) = true := by
            simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m3 scrW (wEvalBase + 3) = 1) = true
            rw [hfl1]; decide
          let dstOff := evalEligOff ℓ M₀ wEvalBase s.val curL
          have hdst_bounds : 0 ≤ dstOff ∧ dstOff < (BW : ℤ) := by
            have hlt := mul_add_lt_of_lt s.isLt hcurL_lt
            unfold dstOff evalEligOff evalWStride at *; omega
          let m3a := H3a.wWrite m3 scrW dstOff (k : ℤ)
          let m3b := H3a.wWrite m3a scrW (wEvalBase + 4) ((curL + 1 : ℕ) : ℤ)
          have hd_3a : DetExec inp (.writeWordHeap scrW
              (.add (.lit (wEvalBase + 12 + (ℓ : ℤ)))
                (.add (.mul (.readHeap scrW (.lit wEvalBase)) (.lit (M₀ : ℤ)))
                      (.readHeap scrW (.lit (wEvalBase + 4)))))
              (.readHeap scrW (.lit (wEvalBase + 1)))) m3 m3a 35 := by
            refine DetExecAt.writeWordHeap 0 inp m3 scrW _ _
              (by
                change (wEvalBase + 12 + (ℓ : ℤ)) +
                  (H3a.wRead m3 scrW wEvalBase * (M₀ : ℤ) + H3a.wRead m3 scrW (wEvalBase + 4)) = dstOff
                rw [hwS_m3, hcnt_m3]
                dsimp [dstOff, evalEligOff])
              hk_m3
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hd_3b : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 4))
              (.add (.readHeap scrW (.lit (wEvalBase + 4))) (.lit 1))) m3a m3b 20 := by
            refine DetExecAt.writeWordHeap 0 inp m3a scrW (.lit (wEvalBase + 4)) _ rfl
              (by
                change H3a.wRead m3a scrW (wEvalBase + 4) + 1 = _
                have hne_d : wEvalBase + 4 ≠ dstOff := by
                  have := helig_off_ge curL hcurL_lt; dsimp [dstOff]; omega
                rw [wRead_wWrite_of_ne _ _ (Or.inr hne_d), hcnt_m3]; push_cast; ring)
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hd_ite : DetExec inp brStmt m3 m3b 65 :=
            (DetExecAt.ite_true (C_c := 10) hc_t
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (hd_3a.seq hd_3b)).mono_cost le_rfl
          have hfp_3b : InFootprint TW BW TR BR m3b :=
            InFootprint.wWrite (InFootprint.wWrite hfp3 hscrW hdst_bounds.1 hdst_bounds.2)
              hscrW (by omega) (by omega)
          have hfr_3b : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m3b :=
            (((hfr_02.trans hfr3).trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m3 dstOff (k : ℤ))).trans
              (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m3a (wEvalBase + 4) ((curL + 1 : ℕ) : ℤ)))
          refine ⟨m3b, hd_ite, hfp_3b, ?_, ?_, ?_, ?_, ?_, hfr_3b⟩
          · have hne_1 : wEvalBase + 1 ≠ dstOff := by
              have := helig_off_ge curL hcurL_lt; dsimp [dstOff]; omega
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr hne_1), hk_m3]
          · rw [wRead_wWrite_self, hpfx_step, if_pos hPk, List.length_append, List.length_singleton]
          · intro j hj
            have hne_j4 : evalEligOff ℓ M₀ wEvalBase s.val j ≠ wEvalBase + 4 := by
              unfold evalEligOff; omega
            rw [wRead_wWrite_of_ne _ _ (Or.inr hne_j4)]
            have hlen_new : (pfx (k + 1) hk).length = curL + 1 := by
              rw [hpfx_step, if_pos hPk, List.length_append, List.length_singleton]
            by_cases heq_j : j = curL
            · subst heq_j
              change H3a.wRead m3a scrW dstOff = _
              rw [wRead_wWrite_self]
              have hget_last : (pfx (k + 1) hk)[curL] = ⟨k, hk⟩ := by
                have hlst := hpfx_step.trans (if_pos hPk)
                simp [hlst, curL]
              rw [hget_last]
            · have hj_lt : j < curL := by omega
              have hne_dst : evalEligOff ℓ M₀ wEvalBase s.val j ≠ dstOff := by
                dsimp [dstOff, evalEligOff]; omega
              have hne_sc : ∀ c : ℤ, wEvalBase + c ≤ wEvalBase + 10 →
                  evalEligOff ℓ M₀ wEvalBase s.val j ≠ wEvalBase + c := by
                intro c hc; unfold evalEligOff; omega
              rw [wRead_wWrite_of_ne _ _ (Or.inr hne_dst),
                  hkW3 _ (by unfold evalEligOff; omega),
                  hkW2 _ (by unfold evalEligOff; omega),
                  wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalEligOff; omega)),
                  helig_r j hj_lt]
              have hget_left : (pfx (k + 1) hk)[j] = (pfx k hk_le)[j] := by
                have hlst := hpfx_step.trans (if_pos hPk)
                simp only [hlst, List.getElem_append_left hj_lt]
              rw [hget_left]
          · intro idx h1 h2 h3 h4 h10 hall
            rw [wRead_wWrite_of_ne _ _ (Or.inr h4),
                wRead_wWrite_of_ne _ _ (Or.inr (hall curL hcurL_lt)),
                hkW3 _ (by omega), hkW2 _ h2,
                wRead_wWrite_of_ne _ _ (Or.inr h10)]
            exact hkW_m idx h1 h2 h3 h4 h10 hall
          · intro r hr
            rw [rRead_wWrite, rRead_wWrite,
                hkR3 _ (by omega), hkR2 _ (by omega)]
            change H3a.rRead m scrR r = _
            exact hkR_m r hr
        · have hPk : P_k ⟨k, hk⟩ = false := decide_eq_false hcond
          have hfl0 : H3a.wRead m3 scrW (wEvalBase + 3) = 0 := by
            rw [hflag3, if_neg hcond]
          have hc_f : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m3
              (.intEq (.readHeap scrW (.lit (wEvalBase + 3))) (.lit 1)) = false := by
            simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m3 scrW (wEvalBase + 3) = 1) = false
            rw [hfl0]; decide
          have hd_ite : DetExec inp brStmt m3 m3 65 :=
            (DetExecAt.ite_false (C_c := 10) hc_f
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.skip 0 inp m3)).mono_cost (by omega)
          refine ⟨m3, hd_ite, hfp3, hk_m3, ?_, ?_, ?_, ?_, hfr_02.trans hfr3⟩
          · rw [hpfx_step, if_neg (by simp [hPk])]; exact hcnt_m3
          · intro j hj
            have hlen_eq : (pfx (k + 1) hk).length = curL := by
              rw [hpfx_step, if_neg (by simp [hPk])]
            have hj_lt : j < curL := by omega
            rw [hkW3 _ (by unfold evalEligOff; omega),
                hkW2 _ (by unfold evalEligOff; omega),
                wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalEligOff; omega)),
                helig_r j hj_lt]
            have hget_eq : (pfx (k + 1) hk)[j] = (pfx k hk_le)[j] := by
              have hlst := hpfx_step.trans (if_neg (by simp [hPk]))
              simp only [hlst]
            rw [hget_eq]
          · intro idx h1 h2 h3 h4 h10 hall
            rw [hkW3 _ (by omega), hkW2 _ h2, wRead_wWrite_of_ne _ _ (Or.inr h10)]
            exact hkW_m idx h1 h2 h3 h4 h10 hall
          · intro r hr
            rw [hkR3 _ (by omega), hkR2 _ (by omega)]
            change H3a.rRead m scrR r = _
            exact hkR_m r hr
      obtain ⟨m4, hd4, hfp4, hk_m4, hcnt_m4, helig_m4, hkW4, hkR4, hfr4⟩ := hbr
      let m5 := H3a.wWrite m4 scrW (wEvalBase + 1) ((k + 1 : ℕ) : ℤ)
      have hd5 : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 1))
          (.add (.readHeap scrW (.lit (wEvalBase + 1))) (.lit 1))) m4 m5 20 :=
        DetExecAt.writeWordHeap 0 inp m4 scrW (.lit (wEvalBase + 1)) _ rfl
          (by change H3a.wRead m4 scrW (wEvalBase + 1) + 1 = _; rw [hk_m4]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp5 : InFootprint TW BW TR BR m5 := InFootprint.wWrite hfp4 hscrW (by omega) (by omega)
      have hfr5 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m5 :=
        hfr4.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m4 (wEvalBase + 1) ((k + 1 : ℕ) : ℤ))
      have hd_step : DetExec inp _ m m5 C_k :=
        (hd1.seq (hd2.seq (hd3.seq (hd4.seq hd5)))).mono_cost (by dsimp only [C_k]; omega)
      refine ⟨m5, hd_step, hk, hfp5, wRead_wWrite_self _ _ _ _,
        by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hcnt_m4,
        fun j hj => by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalEligOff; omega))]
          exact helig_m4 j hj,
        fun idx h1 h2 h3 h4 h10 hall => by
          rw [wRead_wWrite_of_ne _ _ (Or.inr h1)]
          exact hkW4 idx h1 h2 h3 h4 h10 hall,
        fun r hr => by rw [rRead_wWrite]; exact hkR4 r hr,
        hfr5⟩)
  rcases hInvM with ⟨_, hfp_end, _, hcnt_end, helig_end, hkW_end, hkR_end, hfr_end⟩
  have hpfx_full : pfx M₀ le_rfl = eligListS := by
    dsimp [pfx, P_k, eligListS]
    rw [finRangePfx_full]
  refine ⟨m_end, (hd_a.seq (hd_b.seq hd_loop)).mono_cost (by dsimp only [C_k]; omega),
    hfp_end, ?_, ?_, hkW_end, hkR_end, hfr_end⟩
  · simpa only [hpfx_full] using hcnt_end
  · intro j hj
    have hj' : j < (pfx M₀ le_rfl).length := by rwa [hpfx_full]
    have he := helig_end j hj'
    simpa only [hpfx_full] using he

def evalCopyPhase1Stmt (scrW scrR tblR : ℕ)
    (wCapBaseR wEvalBase rScrBase rWBase : ℤ)
    (ℓ M₀ d K_trunc : ℕ) (A B_signed a₀ : ℚ) : ArithRAMStmt :=
  let wS := wEvalBase
  let wCntS := wEvalBase + 4
  let wAllPos := wEvalBase + 5
  let wProd := wEvalBase + 6
  let cntBase := wEvalBase + 12
  .seq (.writeWordHeap scrW (.lit wAllPos) (.lit 1))
  (.seq (.writeWordHeap scrW (.lit wProd) (.lit ((min K_trunc 1 : ℕ) : ℤ)))
  (.seq (.writeWordHeap scrW (.lit wS) (.lit 0))
        (.repeatN (.lit (ℓ : ℤ))
          (.seq (evalCopyInnerKStmt scrW scrR tblR wCapBaseR wEvalBase rScrBase rWBase ℓ M₀ d A B_signed a₀)
          (.seq (.writeWordHeap scrW (.add (.lit cntBase) (.readHeap scrW (.lit wS)))
                  (.readHeap scrW (.lit wCntS)))
          (.seq (.ite (.intEq (.readHeap scrW (.lit wCntS)) (.lit 0))
                  (.writeWordHeap scrW (.lit wAllPos) (.lit 0))
                  .skip)
          (.seq (.writeWordHeap scrW (.lit wProd)
                  (.mul (.readHeap scrW (.lit wProd)) (.readHeap scrW (.lit wCntS))))
          (.seq (.ite (.intLt (.lit (K_trunc : ℤ)) (.readHeap scrW (.lit wProd)))
                  (.writeWordHeap scrW (.lit wProd) (.lit (K_trunc : ℤ)))
                  .skip)
                (.writeWordHeap scrW (.lit wS)
                  (.add (.readHeap scrW (.lit wS)) (.lit 1)))))))))))

private theorem exec_evalCopyPhase1Stmt {d TW BW TR BR scrW scrR tblR tblW : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCapBaseR wEvalBase rScrBase rWBase capBaseR baseW baseR : ℤ)
    {ℓ M₀ cap : ℕ} (K_trunc : ℕ) (A B_signed a₀ : ℚ)
    (caps_r : Fin ℓ → Fin M₀ → EuclideanSpace ℝ (Fin (d + 1)))
    (w : EuclideanSpace ℝ (Fin d))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneR : tblR ≠ scrR)
    (hwEval : 0 ≤ wEvalBase ∧ wEvalBase + evalWStride ℓ M₀ cap ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScrBase ∧ rScrBase + 4 + (d : ℤ) ≤ (BR : ℤ))
    (hrW_disj : rScrBase + 4 + (d : ℤ) ≤ rWBase ∨ rWBase + (d : ℤ) ≤ rScrBase)
    (hwCap_disj : wCapBaseR < wEvalBase ∨ wEvalBase + evalWStride ℓ M₀ cap ≤ wCapBaseR)
    (hcapB : H3a.wRead m₀ scrW wCapBaseR = capBaseR)
    (hCaps : ∀ (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)),
      H3a.rRead m₀ tblR (capBaseR + (((s.val * M₀ + k.val) * (d + 1) : ℕ) : ℤ) + (j.val : ℤ)) =
        euclideanCoord (caps_r s k) j)
    (hw_vec : ∀ i : Fin d, H3a.rRead m₀ scrR (rWBase + (i.val : ℤ)) = euclideanCoord w i) :
    let eligList : Fin ℓ → List (Fin M₀) := fun s => open Classical in
      (List.finRange M₀).filter (fun k =>
        realSignedSqCapCond (A : ℝ) (B_signed : ℝ) (a₀ : ℝ) (caps_r s k) w)
    let cnt : Fin ℓ → ℕ := fun s => (eligList s).length
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (evalCopyPhase1Stmt scrW scrR tblR wCapBaseR wEvalBase rScrBase rWBase ℓ M₀ d K_trunc A B_signed a₀)
        m₀ m₁ (80 + ℓ * (250 + M₀ * (350 + 80 * d))) ∧
      InFootprint TW BW TR BR m₁ ∧
      (H3a.wRead m₁ scrW (wEvalBase + 5) = open Classical in if ∀ s : Fin ℓ, 1 ≤ cnt s then 1 else 0) ∧
      H3a.wRead m₁ scrW (wEvalBase + 6) = @Nat.cast ℤ _ (truncMul K_trunc cnt) ∧
      (∀ s : Fin ℓ, H3a.wRead m₁ scrW (evalCntOff wEvalBase s.val) = @Nat.cast ℤ _ (cnt s)) ∧
      (∀ (s : Fin ℓ) (j : ℕ) (hj : j < cnt s),
        H3a.wRead m₁ scrW (evalEligOff ℓ M₀ wEvalBase s.val j) = @Nat.cast ℤ _ ((eligList s)[j]).val) ∧
      (∀ idx : ℤ,
        (idx < wEvalBase ∨ wEvalBase + evalWStride ℓ M₀ cap ≤ idx) →
        H3a.wRead m₁ scrW idx = H3a.wRead m₀ scrW idx) ∧
      (∀ r : ℤ, (r < rScrBase ∨ rScrBase + 4 + (d : ℤ) ≤ r) →
        H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  classical
  intro eligList cnt
  have hstride_ge : 12 + (ℓ : ℤ) + ((ℓ * M₀ : ℕ) : ℤ) ≤ evalWStride ℓ M₀ cap := by
    unfold evalWStride; omega
  let pfxProd : ∀ k ≤ ℓ, ℕ := fun k hk =>
    Fin.foldl k (fun acc (i : Fin k) => min K_trunc (acc * cnt ⟨i.val, lt_of_lt_of_le i.isLt hk⟩))
      (min K_trunc 1)
  let m_a := H3a.wWrite m₀ scrW (wEvalBase + 5) 1
  let m_b := H3a.wWrite m_a scrW (wEvalBase + 6) ((min K_trunc 1 : ℕ) : ℤ)
  let m_c := H3a.wWrite m_b scrW wEvalBase 0
  have hd_a : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 5)) (.lit 1)) m₀ m_a 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wEvalBase + 5)) (.lit 1) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd_b : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 6)) (.lit ((min K_trunc 1 : ℕ) : ℤ)))
      m_a m_b 10 :=
    DetExecAt.writeWordHeap 0 inp m_a scrW (.lit (wEvalBase + 6)) _ rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd_c : DetExec inp (.writeWordHeap scrW (.lit wEvalBase) (.lit 0)) m_b m_c 10 :=
    DetExecAt.writeWordHeap 0 inp m_b scrW (.lit wEvalBase) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_a : InFootprint TW BW TR BR m_a := InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)
  have hfp_b : InFootprint TW BW TR BR m_b := InFootprint.wWrite hfp_a hscrW (by omega) (by omega)
  have hfp_c : InFootprint TW BW TR BR m_c := InFootprint.wWrite hfp_b hscrW (by omega) (by omega)
  have hfr_abc : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_c :=
    ((RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m₀ (wEvalBase + 5) 1).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_a (wEvalBase + 6) ((min K_trunc 1 : ℕ) : ℤ))).trans
      (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_b wEvalBase 0)
  let Inv : ℕ → ArithRAMMemory → Prop := fun s_idx m =>
    ∃ hs_le : s_idx ≤ ℓ,
      InFootprint TW BW TR BR m ∧
      H3a.wRead m scrW wEvalBase = (s_idx : ℤ) ∧
      H3a.wRead m scrW (wEvalBase + 5) =
        (if ∀ (i : ℕ) (hi : i < s_idx), 1 ≤ cnt ⟨i, lt_of_lt_of_le hi hs_le⟩ then 1 else 0) ∧
      H3a.wRead m scrW (wEvalBase + 6) = @Nat.cast ℤ _ (pfxProd s_idx hs_le) ∧
      (∀ (i : ℕ) (hi : i < s_idx),
        H3a.wRead m scrW (evalCntOff wEvalBase i) = @Nat.cast ℤ _ (cnt ⟨i, lt_of_lt_of_le hi hs_le⟩)) ∧
      (∀ (i : ℕ) (hi : i < s_idx) (j : ℕ) (hj : j < cnt ⟨i, lt_of_lt_of_le hi hs_le⟩),
        H3a.wRead m scrW (evalEligOff ℓ M₀ wEvalBase i j) =
          @Nat.cast ℤ _ ((eligList ⟨i, lt_of_lt_of_le hi hs_le⟩)[j]).val) ∧
      (∀ idx : ℤ,
        (idx < wEvalBase ∨ wEvalBase + evalWStride ℓ M₀ cap ≤ idx) →
        H3a.wRead m scrW idx = H3a.wRead m₀ scrW idx) ∧
      (∀ r : ℤ, (r < rScrBase ∨ rScrBase + 4 + (d : ℤ) ≤ r) →
        H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
  have hInv0 : Inv 0 m_c := by
    refine ⟨Nat.zero_le ℓ, hfp_c, wRead_wWrite_self _ _ _ _, ?_, ?_,
      fun _ hi => by omega, fun _ hi => by omega, ?_, fun _ _ => rfl, hfr_abc⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_self, if_pos (fun _ hi => by omega)]
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
      dsimp [pfxProd]; rw [Fin.foldl_zero]
    · intro idx hidx
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  let C_s : ℕ := 250 + M₀ * (350 + 80 * d)
  obtain ⟨m_end, hInvL, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (ℓ : ℤ)) _ ℓ 10 C_s
    Inv hInv0 rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    (fun s_idx hs m ⟨hs_le, hfp_m, hs_r, hall_r, hprod_r, hcnt_prev, helig_prev, hkW_m, hkR_m, hfr_m⟩ => by
      let sFin : Fin ℓ := ⟨s_idx, hs⟩
      have hcapB_m : H3a.wRead m scrW wCapBaseR = capBaseR :=
        (hkW_m wCapBaseR hwCap_disj).trans hcapB
      have hCaps_m : ∀ (s' : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)),
          H3a.rRead m tblR (capBaseR + (((s'.val * M₀ + k.val) * (d + 1) : ℕ) : ℤ) + (j.val : ℤ)) =
            euclideanCoord (caps_r s' k) j := by
        intro s' k j
        rw [hfr_m.2 tblR _ hneR (Or.inr (by omega))]
        exact hCaps s' k j
      have hw_m : ∀ i : Fin d, H3a.rRead m scrR (rWBase + (i.val : ℤ)) = euclideanCoord w i := by
        intro i
        have hdisj_i : rWBase + (i.val : ℤ) < rScrBase ∨ rScrBase + 4 + (d : ℤ) ≤ rWBase + (i.val : ℤ) := by
          have := i.isLt; omega
        exact (hkR_m _ hdisj_i).trans (hw_vec i)
      obtain ⟨m1, hd1, hfp1, hcnt1, helig1, hkW1, hkR1, hfr1⟩ :=
        exec_evalCopyInnerKStmt (tblW := tblW) (cap := cap) inp
          wCapBaseR wEvalBase rScrBase rWBase capBaseR baseW baseR sFin A B_signed a₀ caps_r w
          hfp_m hscrW hscrR hneR hwEval hrScr hrW_disj hwCap_disj hcapB_m hs_r hCaps_m hw_m
      have hfr_01 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m1 := hfr_m.trans hfr1
      have helig_off_ge : ∀ j < M₀, wEvalBase + 12 + (ℓ : ℤ) ≤ evalEligOff ℓ M₀ wEvalBase s_idx j := by
        intro j _; unfold evalEligOff; omega
      have hs_m1 : H3a.wRead m1 scrW wEvalBase = (s_idx : ℤ) := by
        rw [hkW1 wEvalBase (by omega) (by omega) (by omega) (by omega) (by omega)
          (fun j hj => by dsimp [sFin]; have := helig_off_ge j hj; omega)]
        exact hs_r
      have hall_m1 : H3a.wRead m1 scrW (wEvalBase + 5) =
          (if ∀ (i : ℕ) (hi : i < s_idx), 1 ≤ cnt ⟨i, lt_of_lt_of_le hi hs_le⟩ then 1 else 0) := by
        rw [hkW1 (wEvalBase + 5) (by omega) (by omega) (by omega) (by omega) (by omega)
          (fun j hj => by dsimp [sFin]; have := helig_off_ge j hj; omega)]
        exact hall_r
      have hprod_m1 : H3a.wRead m1 scrW (wEvalBase + 6) = @Nat.cast ℤ _ (pfxProd s_idx hs_le) := by
        rw [hkW1 (wEvalBase + 6) (by omega) (by omega) (by omega) (by omega) (by omega)
          (fun j hj => by dsimp [sFin]; have := helig_off_ge j hj; omega)]
        exact hprod_r
      -- Write cnt[s_idx] := wCntS
      let cntOff := evalCntOff wEvalBase s_idx
      let m2 := H3a.wWrite m1 scrW cntOff (@Nat.cast ℤ _ (cnt sFin))
      have hd2 : DetExec inp (.writeWordHeap scrW (.add (.lit (wEvalBase + 12)) (.readHeap scrW (.lit wEvalBase)))
          (.readHeap scrW (.lit (wEvalBase + 4)))) m1 m2 25 := by
        refine DetExecAt.writeWordHeap 0 inp m1 scrW _ _
          (by change (wEvalBase + 12) + H3a.wRead m1 scrW wEvalBase = cntOff; rw [hs_m1]; rfl)
          hcnt1
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp2 : InFootprint TW BW TR BR m2 :=
        InFootprint.wWrite hfp1 hscrW (by dsimp [cntOff, evalCntOff]; omega)
          (by dsimp [cntOff, evalCntOff]; omega)
      have hfr2 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m2 :=
        hfr_01.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m1 cntOff _)
      -- Update wAllPos on cnt == 0
      let allStmt : ArithRAMStmt :=
        .ite (.intEq (.readHeap scrW (.lit (wEvalBase + 4))) (.lit 0))
          (.writeWordHeap scrW (.lit (wEvalBase + 5)) (.lit 0))
          .skip
      have hall_step : ∃ m3 : ArithRAMMemory,
          DetExec inp allStmt m2 m3 25 ∧
          InFootprint TW BW TR BR m3 ∧
          H3a.wRead m3 scrW (wEvalBase + 5) =
            (if ∀ (i : ℕ) (hi : i < s_idx + 1), 1 ≤ cnt ⟨i, lt_of_lt_of_le hi hs⟩ then 1 else 0) ∧
          (∀ idx : ℤ, idx ≠ wEvalBase + 5 → H3a.wRead m3 scrW idx = H3a.wRead m2 scrW idx) ∧
          (∀ r : ℤ, H3a.rRead m3 scrR r = H3a.rRead m2 scrR r) ∧
          RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m3 := by
        have hcnt_m2 : H3a.wRead m2 scrW (wEvalBase + 4) = @Nat.cast ℤ _ (cnt sFin) := by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [cntOff, evalCntOff]; omega))]; exact hcnt1
        by_cases hc0 : cnt sFin = 0
        · have hc_t : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m2
              (.intEq (.readHeap scrW (.lit (wEvalBase + 4))) (.lit 0)) = true := by
            simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m2 scrW (wEvalBase + 4) = 0) = true
            rw [hcnt_m2, hc0]; decide
          let m3 := H3a.wWrite m2 scrW (wEvalBase + 5) 0
          have hd_w0 : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 5)) (.lit 0)) m2 m3 10 :=
            DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wEvalBase + 5)) (.lit 0) rfl rfl
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hd_all : DetExec inp allStmt m2 m3 25 :=
            (DetExecAt.ite_true (C_c := 10) hc_t
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              hd_w0).mono_cost (by omega)
          have hnot_all : ¬ ∀ (i : ℕ) (hi : i < s_idx + 1), 1 ≤ cnt ⟨i, lt_of_lt_of_le hi hs⟩ := by
            intro hall_new
            have h1 := hall_new s_idx (Nat.lt_succ_self s_idx)
            have heq_f : (⟨s_idx, lt_of_lt_of_le (Nat.lt_succ_self s_idx) hs⟩ : Fin ℓ) = sFin := rfl
            rw [heq_f, hc0] at h1; omega
          refine ⟨m3, hd_all, InFootprint.wWrite hfp2 hscrW (by omega) (by omega),
            by rw [wRead_wWrite_self, if_neg hnot_all],
            fun idx hne => wRead_wWrite_of_ne _ _ (Or.inr hne),
            fun _ => rfl,
            hfr2.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m2 (wEvalBase + 5) 0)⟩
        · have hc_f : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m2
              (.intEq (.readHeap scrW (.lit (wEvalBase + 4))) (.lit 0)) = false := by
            simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
            change decide (H3a.wRead m2 scrW (wEvalBase + 4) = 0) = false
            rw [hcnt_m2]; exact decide_eq_false (by omega)
          have hd_all : DetExec inp allStmt m2 m2 25 :=
            (DetExecAt.ite_false (C_c := 10) hc_f
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.skip 0 inp m2)).mono_cost (by omega)
          have hall_iff : (∀ (i : ℕ) (hi : i < s_idx + 1), 1 ≤ cnt ⟨i, lt_of_lt_of_le hi hs⟩) ↔
              (∀ (i : ℕ) (hi : i < s_idx), 1 ≤ cnt ⟨i, lt_of_lt_of_le hi hs_le⟩) := by
            constructor
            · intro h i hi; exact h i (Nat.lt_succ_of_lt hi)
            · intro h i hi
              by_cases he : i = s_idx
              · subst he
                have heq_f : (⟨i, lt_of_lt_of_le hi hs⟩ : Fin ℓ) = sFin := rfl
                rw [heq_f]; omega
              · exact h i (by omega)
          refine ⟨m2, hd_all, hfp2, ?_, fun _ _ => rfl, fun _ => rfl, hfr2⟩
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [cntOff, evalCntOff]; omega)), hall_m1]
          by_cases hp : ∀ (i : ℕ) (hi : i < s_idx), 1 ≤ cnt ⟨i, lt_of_lt_of_le hi hs_le⟩
          · rw [if_pos hp, if_pos (hall_iff.mpr hp)]
          · rw [if_neg hp, if_neg (mt hall_iff.mp hp)]
      obtain ⟨m3, hd3, hfp3, hall3, hkW3, hkR3, hfr3⟩ := hall_step
      -- Multiply and clamp wProd := min K_trunc (wProd * cnt sFin)
      let rawP : ℕ := pfxProd s_idx hs_le * cnt sFin
      let nextP : ℕ := min K_trunc rawP
      have hpfx_next : pfxProd (s_idx + 1) hs = nextP := by
        dsimp [pfxProd, nextP, rawP]
        rw [Fin.foldl_succ_last]
        rfl
      have hprod_m3 : H3a.wRead m3 scrW (wEvalBase + 6) = @Nat.cast ℤ _ (pfxProd s_idx hs_le) := by
        rw [hkW3 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [cntOff, evalCntOff]; omega))]
        exact hprod_m1
      have hcnt_m3 : H3a.wRead m3 scrW (wEvalBase + 4) = @Nat.cast ℤ _ (cnt sFin) := by
        rw [hkW3 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [cntOff, evalCntOff]; omega))]
        exact hcnt1
      let m4 := H3a.wWrite m3 scrW (wEvalBase + 6) (@Nat.cast ℤ _ rawP)
      have hd4 : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 6))
          (.mul (.readHeap scrW (.lit (wEvalBase + 6))) (.readHeap scrW (.lit (wEvalBase + 4)))))
          m3 m4 20 := by
        refine DetExecAt.writeWordHeap 0 inp m3 scrW (.lit (wEvalBase + 6)) _ rfl
          (by change H3a.wRead m3 scrW (wEvalBase + 6) * H3a.wRead m3 scrW (wEvalBase + 4) = _
              rw [hprod_m3, hcnt_m3]; simp [rawP])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp4 : InFootprint TW BW TR BR m4 := InFootprint.wWrite hfp3 hscrW (by omega) (by omega)
      have hfr4 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m4 :=
        hfr3.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m3 (wEvalBase + 6) _)
      let clampStmt : ArithRAMStmt :=
        .ite (.intLt (.lit (K_trunc : ℤ)) (.readHeap scrW (.lit (wEvalBase + 6))))
          (.writeWordHeap scrW (.lit (wEvalBase + 6)) (.lit (K_trunc : ℤ)))
          .skip
      have hclamp : ∃ m5 : ArithRAMMemory,
          DetExec inp clampStmt m4 m5 25 ∧
          InFootprint TW BW TR BR m5 ∧
          H3a.wRead m5 scrW (wEvalBase + 6) = @Nat.cast ℤ _ nextP ∧
          (∀ idx : ℤ, idx ≠ wEvalBase + 6 → H3a.wRead m5 scrW idx = H3a.wRead m4 scrW idx) ∧
          (∀ r : ℤ, H3a.rRead m5 scrR r = H3a.rRead m4 scrR r) ∧
          RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m5 := by
        by_cases hgt : K_trunc < rawP
        · have hc_t : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m4
              (.intLt (.lit (K_trunc : ℤ)) (.readHeap scrW (.lit (wEvalBase + 6)))) = true := by
            simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
            change decide ((K_trunc : ℤ) < H3a.wRead m4 scrW (wEvalBase + 6)) = true
            rw [wRead_wWrite_self]; exact decide_eq_true (by exact_mod_cast hgt)
          let m5 := H3a.wWrite m4 scrW (wEvalBase + 6) (K_trunc : ℤ)
          have hd_cl : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 6)) (.lit (K_trunc : ℤ))) m4 m5 10 :=
            DetExecAt.writeWordHeap 0 inp m4 scrW (.lit (wEvalBase + 6)) _ rfl rfl
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hmin_eq : nextP = K_trunc := Nat.min_eq_left (Nat.le_of_lt hgt)
          refine ⟨m5,
            (DetExecAt.ite_true (C_c := 10) hc_t
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              hd_cl).mono_cost (by omega),
            InFootprint.wWrite hfp4 hscrW (by omega) (by omega),
            by rw [wRead_wWrite_self, hmin_eq],
            fun idx hne => wRead_wWrite_of_ne _ _ (Or.inr hne),
            fun _ => rfl,
            hfr4.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m4 (wEvalBase + 6) _)⟩
        · have hc_f : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m4
              (.intLt (.lit (K_trunc : ℤ)) (.readHeap scrW (.lit (wEvalBase + 6)))) = false := by
            simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
            change decide ((K_trunc : ℤ) < H3a.wRead m4 scrW (wEvalBase + 6)) = false
            rw [wRead_wWrite_self]; exact decide_eq_false (by omega)
          have hmin_eq : nextP = rawP := Nat.min_eq_right (by omega)
          refine ⟨m4,
            (DetExecAt.ite_false (C_c := 10) hc_f
              (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
              (DetExecAt.skip 0 inp m4)).mono_cost (by omega),
            hfp4,
            by rw [wRead_wWrite_self, hmin_eq],
            fun _ _ => rfl, fun _ => rfl, hfr4⟩
      obtain ⟨m5, hd5, hfp5, hprod5, hkW5, hkR5, hfr5⟩ := hclamp
      -- Increment wS
      have hs_m5 : H3a.wRead m5 scrW wEvalBase = (s_idx : ℤ) := by
        rw [hkW5 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW3 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [cntOff, evalCntOff]; omega))]
        exact hs_m1
      let m6 := H3a.wWrite m5 scrW wEvalBase ((s_idx + 1 : ℕ) : ℤ)
      have hd6 : DetExec inp (.writeWordHeap scrW (.lit wEvalBase)
          (.add (.readHeap scrW (.lit wEvalBase)) (.lit 1))) m5 m6 20 :=
        DetExecAt.writeWordHeap 0 inp m5 scrW (.lit wEvalBase) _ rfl
          (by change H3a.wRead m5 scrW wEvalBase + 1 = _; rw [hs_m5]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp6 : InFootprint TW BW TR BR m6 := InFootprint.wWrite hfp5 hscrW (by omega) (by omega)
      have hfr6 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m6 :=
        hfr5.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m5 wEvalBase _)
      have hd_step : DetExec inp _ m m6 C_s :=
        (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq hd6))))).mono_cost (by dsimp only [C_s]; omega)
      refine ⟨m6, hd_step, hs, hfp6, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, ?_, ?_, ?_, hfr6⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW5 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hall3
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hpfx_next]; exact hprod5
      · intro i hi
        have hcnt_ge12 : wEvalBase + 12 ≤ evalCntOff wEvalBase i := by unfold evalCntOff; omega
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW5 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW3 _ (by omega)]
        by_cases he : i = s_idx
        · subst he
          change H3a.wRead m2 scrW cntOff = _
          rw [wRead_wWrite_self]
        · have hi_lt : i < s_idx := by omega
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [cntOff, evalCntOff]; omega)),
              hkW1 _ (by omega) (by omega) (by omega) (by omega) (by omega)
                (fun j _ => by unfold evalCntOff evalEligOff; omega)]
          exact hcnt_prev i hi_lt
      · intro i hi j hj
        have hel_ge : wEvalBase + 12 + (ℓ : ℤ) ≤ evalEligOff ℓ M₀ wEvalBase i j := by
          unfold evalEligOff; omega
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW5 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW3 _ (by omega),
            wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [cntOff, evalCntOff]; omega))]
        by_cases he : i = s_idx
        · subst he
          exact helig1 j hj
        · have hi_lt : i < s_idx := by omega
          have hj_M : j < M₀ := lt_of_lt_of_le hj
            ((List.length_filter_le _ _).trans (by simp))
          rw [hkW1 _ (by omega) (by omega) (by omega) (by omega) (by omega)
            (fun j' hj' => by
              dsimp [sFin]; unfold evalEligOff
              intro h_eq
              have hnat : i * M₀ + j = s_idx * M₀ + j' := by omega
              exact mul_add_ne_of_ne hj_M hj' (Or.inl he) hnat)]
          exact helig_prev i hi_lt j hj
      · intro idx hidx
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW5 _ (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW3 _ (by omega),
            wRead_wWrite_of_ne _ _ (Or.inr (by dsimp [cntOff, evalCntOff]; omega)),
            hkW1 _ (by omega) (by omega) (by omega) (by omega) (by omega)
              (fun j hj => by
                dsimp [sFin]; have hlt := mul_add_lt_of_lt hs hj
                unfold evalEligOff evalWStride at *; omega)]
        exact hkW_m idx hidx
      · intro r hr
        rw [rRead_wWrite, hkR5 r, rRead_wWrite, hkR3 r, rRead_wWrite]
        exact (hkR1 r hr).trans (hkR_m r hr))
  rcases hInvL with ⟨_, hfp_end, _, hall_end, hprod_end, hcnt_end, helig_end, hkW_end, hkR_end, hfr_end⟩
  refine ⟨m_end, (hd_a.seq (hd_b.seq (hd_c.seq hd_loop))).mono_cost (by dsimp only [C_s]; omega),
    hfp_end, ?_, ?_, ?_, ?_, hkW_end, hkR_end, hfr_end⟩
  · rw [hall_end]
    have hiff : (∀ (i : ℕ) (hi : i < ℓ), 1 ≤ cnt ⟨i, hi⟩) ↔ (∀ s : Fin ℓ, 1 ≤ cnt s) :=
      ⟨fun h s => h s.val s.isLt, fun h i hi => h ⟨i, hi⟩⟩
    by_cases hp : ∀ s : Fin ℓ, 1 ≤ cnt s
    · rw [if_pos (hiff.mpr hp), if_pos hp]
    · rw [if_neg (mt hiff.mp hp), if_neg hp]
  · rw [hprod_end]; rfl
  · intro s; exact hcnt_end s.val s.isLt
  · intro s j hj; exact helig_end s.val s.isLt j hj

/-! ### 3. Phase 2 (`evalCopyOneTupleStmt` & `evalCopyTuplesStmt`) -/

def evalCopyOneTupleStmt (scrW : ℕ) (wEvalBase : ℤ) (ℓ M₀ : ℕ) : ArithRAMStmt :=
  let wS := wEvalBase
  let wCntS := wEvalBase + 4
  let wIdx := wEvalBase + 7
  let wRem := wEvalBase + 8
  let wCode := wEvalBase + 9
  let cntBase := wEvalBase + 12
  let eligBase := wEvalBase + 12 + (ℓ : ℤ)
  let codesBase := evalCodesOff ℓ M₀ wEvalBase
  .seq (.writeWordHeap scrW (.lit wRem) (.readHeap scrW (.lit wIdx)))
  (.seq (.writeWordHeap scrW (.lit wCode) (.lit 0))
  (.seq (.writeWordHeap scrW (.lit wS) (.lit 0))
  (.seq (.repeatN (.lit (ℓ : ℤ))
          (.seq (.writeWordHeap scrW (.lit wCntS)
                  (.readHeap scrW (.add (.lit cntBase) (.readHeap scrW (.lit wS)))))
          (.seq (.writeWordHeap scrW (.lit wCode)
                  (.add (.mul (.readHeap scrW (.lit wCode)) (.lit (M₀ : ℤ)))
                        (.readHeap scrW
                          (.add (.lit eligBase)
                            (.add (.mul (.readHeap scrW (.lit wS)) (.lit (M₀ : ℤ)))
                                  (.mod (.readHeap scrW (.lit wRem))
                                        (.readHeap scrW (.lit wCntS))))))))
          (.seq (.writeWordHeap scrW (.lit wRem)
                  (.div (.readHeap scrW (.lit wRem)) (.readHeap scrW (.lit wCntS))))
                (.writeWordHeap scrW (.lit wS)
                  (.add (.readHeap scrW (.lit wS)) (.lit 1)))))))
        (.writeWordHeap scrW
          (.add (.lit codesBase) (.readHeap scrW (.lit wIdx)))
          (.readHeap scrW (.lit wCode))))))

private theorem exec_evalCopyOneTupleStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wEvalBase baseW baseR : ℤ) {ℓ M₀ cap idx : ℕ}
    (hM₀ : 1 ≤ M₀) (hidx_cap : idx < cap)
    (cnt : Fin ℓ → ℕ) (elig : Fin ℓ → ℕ → ℕ)
    (hcnt_pos : ∀ s : Fin ℓ, 1 ≤ cnt s)
    (hcnt_le : ∀ s : Fin ℓ, cnt s ≤ M₀)
    (helig_lt : ∀ (s : Fin ℓ) (j : ℕ), j < cnt s → elig s j < M₀)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW)
    (hwEval : 0 ≤ wEvalBase ∧ wEvalBase + evalWStride ℓ M₀ cap ≤ (BW : ℤ))
    (hidx_r : H3a.wRead m₀ scrW (wEvalBase + 7) = (idx : ℤ))
    (hcnt_mem : ∀ s : Fin ℓ, H3a.wRead m₀ scrW (evalCntOff wEvalBase s.val) = @Nat.cast ℤ _ (cnt s))
    (helig_mem : ∀ (s : Fin ℓ) (j : ℕ), j < cnt s →
      H3a.wRead m₀ scrW (evalEligOff ℓ M₀ wEvalBase s.val j) = @Nat.cast ℤ _ (elig s j)) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (evalCopyOneTupleStmt scrW wEvalBase ℓ M₀) m₀ m₁ (80 + 130 * ℓ) ∧
      InFootprint TW BW TR BR m₁ ∧
      H3a.wRead m₁ scrW (evalCodesOff ℓ M₀ wEvalBase + (idx : ℤ)) =
        @Nat.cast ℤ _ (encodeTuple (mixedTuple hM₀ cnt elig idx)) ∧
      (∀ w : ℤ,
        w ≠ wEvalBase → w ≠ wEvalBase + 4 → w ≠ wEvalBase + 8 → w ≠ wEvalBase + 9 →
        w ≠ evalCodesOff ℓ M₀ wEvalBase + (idx : ℤ) →
        H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r : ℤ, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  have hstride_ge : 12 + (ℓ : ℤ) + ((ℓ * M₀ : ℕ) : ℤ) + (cap : ℤ) = evalWStride ℓ M₀ cap := rfl
  let rcPfx : ∀ k ≤ ℓ, ℕ × ℕ := fun k hk =>
    Fin.foldl k (fun rc (i : Fin k) =>
      let s : Fin ℓ := ⟨i.val, lt_of_lt_of_le i.isLt hk⟩
      (rc.1 / cnt s, rc.2 * M₀ + elig s (rc.1 % cnt s))) (idx, 0)
  let m_a := H3a.wWrite m₀ scrW (wEvalBase + 8) (idx : ℤ)
  let m_b := H3a.wWrite m_a scrW (wEvalBase + 9) 0
  let m_c := H3a.wWrite m_b scrW wEvalBase 0
  have hd_a : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 8)) (.readHeap scrW (.lit (wEvalBase + 7))))
      m₀ m_a 15 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wEvalBase + 8)) _ rfl hidx_r
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd_b : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 9)) (.lit 0)) m_a m_b 10 :=
    DetExecAt.writeWordHeap 0 inp m_a scrW (.lit (wEvalBase + 9)) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd_c : DetExec inp (.writeWordHeap scrW (.lit wEvalBase) (.lit 0)) m_b m_c 10 :=
    DetExecAt.writeWordHeap 0 inp m_b scrW (.lit wEvalBase) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_c : InFootprint TW BW TR BR m_c :=
    InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW (by omega) (by omega))
      hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hfr_abc : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_c :=
    ((RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ _ _).trans
      (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_a _ _)).trans
      (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_b _ _)
  let Inv : ℕ → ArithRAMMemory → Prop := fun s_idx m =>
    ∃ hs_le : s_idx ≤ ℓ,
      InFootprint TW BW TR BR m ∧
      H3a.wRead m scrW wEvalBase = (s_idx : ℤ) ∧
      H3a.wRead m scrW (wEvalBase + 8) = @Nat.cast ℤ _ (rcPfx s_idx hs_le).1 ∧
      H3a.wRead m scrW (wEvalBase + 9) = @Nat.cast ℤ _ (rcPfx s_idx hs_le).2 ∧
      (∀ w : ℤ,
        w ≠ wEvalBase → w ≠ wEvalBase + 4 → w ≠ wEvalBase + 8 → w ≠ wEvalBase + 9 →
        H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r : ℤ, H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
  have hInv0 : Inv 0 m_c := by
    refine ⟨Nat.zero_le ℓ, hfp_c, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, fun _ => rfl, hfr_abc⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
      dsimp [rcPfx]; rw [Fin.foldl_zero]
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
      simp [rcPfx]
    · intro w h0 _ h8 h9
      rw [wRead_wWrite_of_ne _ _ (Or.inr h0),
          wRead_wWrite_of_ne _ _ (Or.inr h9),
          wRead_wWrite_of_ne _ _ (Or.inr h8)]
  obtain ⟨m_lp, hInvL, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (ℓ : ℤ)) _ ℓ 10 130
    Inv hInv0 rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    (fun s_idx hs m ⟨hs_le, hfp_m, hs_r, hrem_r, hcode_r, hkW_m, hkR_m, hfr_m⟩ => by
      let sFin : Fin ℓ := ⟨s_idx, hs⟩
      let rem0 := (rcPfx s_idx hs_le).1
      let code0 := (rcPfx s_idx hs_le).2
      let cs := cnt sFin
      have hcs_pos : 1 ≤ cs := hcnt_pos sFin
      have hrmod_lt : rem0 % cs < cs := Nat.mod_lt rem0 hcs_pos
      have hrmod_M : rem0 % cs < M₀ := lt_of_lt_of_le hrmod_lt (hcnt_le sFin)
      have hcntOff_m : H3a.wRead m scrW (evalCntOff wEvalBase s_idx) = (cs : ℤ) := by
        rw [hkW_m _ (by unfold evalCntOff; omega) (by unfold evalCntOff; omega)
          (by unfold evalCntOff; omega) (by unfold evalCntOff; omega)]
        exact hcnt_mem sFin
      let m1 := H3a.wWrite m scrW (wEvalBase + 4) (cs : ℤ)
      have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 4))
          (.readHeap scrW (.add (.lit (wEvalBase + 12)) (.readHeap scrW (.lit wEvalBase)))))
          m m1 25 :=
        DetExecAt.writeWordHeap 0 inp m scrW (.lit (wEvalBase + 4)) _ rfl
          (by change H3a.wRead m scrW ((wEvalBase + 12) + H3a.wRead m scrW wEvalBase) = (cs : ℤ)
              rw [hs_r]; exact hcntOff_m)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have heligOff_m1 : H3a.wRead m1 scrW (evalEligOff ℓ M₀ wEvalBase s_idx (rem0 % cs)) =
          @Nat.cast ℤ _ (elig sFin (rem0 % cs)) := by
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalEligOff; omega)),
            hkW_m _ (by unfold evalEligOff; omega) (by unfold evalEligOff; omega)
              (by unfold evalEligOff; omega) (by unfold evalEligOff; omega)]
        exact helig_mem sFin (rem0 % cs) hrmod_lt
      have hmod_cast : ((rem0 : ℤ) % (cs : ℤ)) = ((rem0 % cs : ℕ) : ℤ) := by exact_mod_cast rfl
      have hdiv_cast : ((rem0 : ℤ) / (cs : ℤ)) = ((rem0 / cs : ℕ) : ℤ) := by exact_mod_cast rfl
      let nextCode : ℕ := code0 * M₀ + elig sFin (rem0 % cs)
      let nextRem : ℕ := rem0 / cs
      have hrc_next : rcPfx (s_idx + 1) hs = (nextRem, nextCode) := by
        dsimp [rcPfx, nextRem, nextCode, rem0, code0, cs]
        rw [Fin.foldl_succ_last]
        rfl
      let m2 := H3a.wWrite m1 scrW (wEvalBase + 9) (nextCode : ℤ)
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 9))
          (.add (.mul (.readHeap scrW (.lit (wEvalBase + 9))) (.lit (M₀ : ℤ)))
                (.readHeap scrW
                  (.add (.lit (wEvalBase + 12 + (ℓ : ℤ)))
                    (.add (.mul (.readHeap scrW (.lit wEvalBase)) (.lit (M₀ : ℤ)))
                          (.mod (.readHeap scrW (.lit (wEvalBase + 8)))
                                (.readHeap scrW (.lit (wEvalBase + 4)))))))))
          m1 m2 50 := by
        refine DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wEvalBase + 9)) _ rfl ?_
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        change H3a.wRead m1 scrW (wEvalBase + 9) * (M₀ : ℤ) +
          H3a.wRead m1 scrW ((wEvalBase + 12 + (ℓ : ℤ)) +
            (H3a.wRead m1 scrW wEvalBase * (M₀ : ℤ) +
              H3a.wRead m1 scrW (wEvalBase + 8) % H3a.wRead m1 scrW (wEvalBase + 4))) = (nextCode : ℤ)
        have hm1_9 : H3a.wRead m1 scrW (wEvalBase + 9) = (code0 : ℤ) := by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hcode_r
        have hm1_0 : H3a.wRead m1 scrW wEvalBase = (s_idx : ℤ) := by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hs_r
        have hm1_8 : H3a.wRead m1 scrW (wEvalBase + 8) = (rem0 : ℤ) := by
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hrem_r
        have hm1_4 : H3a.wRead m1 scrW (wEvalBase + 4) = (cs : ℤ) := wRead_wWrite_self _ _ _ _
        rw [hm1_9, hm1_0, hm1_8, hm1_4, hmod_cast]
        have haddr : (wEvalBase + 12 + (ℓ : ℤ)) + ((s_idx : ℤ) * (M₀ : ℤ) + ((rem0 % cs : ℕ) : ℤ)) =
            evalEligOff ℓ M₀ wEvalBase s_idx (rem0 % cs) := by
          simp [evalEligOff]
        rw [haddr, heligOff_m1]
        simp [nextCode]
      let m3 := H3a.wWrite m2 scrW (wEvalBase + 8) (nextRem : ℤ)
      have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 8))
          (.div (.readHeap scrW (.lit (wEvalBase + 8))) (.readHeap scrW (.lit (wEvalBase + 4)))))
          m2 m3 25 := by
        refine DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wEvalBase + 8)) _ rfl ?_
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        change H3a.wRead m2 scrW (wEvalBase + 8) / H3a.wRead m2 scrW (wEvalBase + 4) = (nextRem : ℤ)
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hrem_r,
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self, hdiv_cast]
      let m4 := H3a.wWrite m3 scrW wEvalBase ((s_idx + 1 : ℕ) : ℤ)
      have hd4 : DetExec inp (.writeWordHeap scrW (.lit wEvalBase)
          (.add (.readHeap scrW (.lit wEvalBase)) (.lit 1))) m3 m4 20 := by
        refine DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wEvalBase) _ rfl ?_
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        change H3a.wRead m3 scrW wEvalBase + 1 = _
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hs_r]
        push_cast; ring
      have hfp4 : InFootprint TW BW TR BR m4 :=
        InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite
          (InFootprint.wWrite hfp_m hscrW (by omega) (by omega))
          hscrW (by omega) (by omega)) hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
      have hfr4 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m4 :=
        (((hfr_m.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m _ _)).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m1 _ _)).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m2 _ _)).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m3 _ _)
      refine ⟨m4, (hd1.seq (hd2.seq (hd3.seq hd4))).mono_cost (by omega),
        hs, hfp4, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, fun r => hkR_m r, hfr4⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self, hrc_next]
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self, hrc_next]
      · intro w h0 h4 h8 h9
        rw [wRead_wWrite_of_ne _ _ (Or.inr h0),
            wRead_wWrite_of_ne _ _ (Or.inr h8),
            wRead_wWrite_of_ne _ _ (Or.inr h9),
            wRead_wWrite_of_ne _ _ (Or.inr h4)]
        exact hkW_m w h0 h4 h8 h9)
  rcases hInvL with ⟨_, hfp_lp, _, _, hcode_lp, hkW_lp, hkR_lp, hfr_lp⟩
  have hcode_eq : (rcPfx ℓ le_rfl).2 = encodeTuple (mixedTuple hM₀ cnt elig idx) := by
    change (foldCode M₀ cnt elig idx 0).2 = _
    exact mixedCodeFold_eq hM₀ cnt elig hcnt_pos helig_lt idx
  let outOff := evalCodesOff ℓ M₀ wEvalBase + (idx : ℤ)
  have hout_bounds : 0 ≤ outOff ∧ outOff < (BW : ℤ) := by
    unfold outOff evalCodesOff evalWStride at *; omega
  let m_out := H3a.wWrite m_lp scrW outOff (@Nat.cast ℤ _ (encodeTuple (mixedTuple hM₀ cnt elig idx)))
  have hidx_lp : H3a.wRead m_lp scrW (wEvalBase + 7) = (idx : ℤ) :=
    (hkW_lp (wEvalBase + 7) (by omega) (by omega) (by omega) (by omega)).trans hidx_r
  have hd_out : DetExec inp (.writeWordHeap scrW
      (.add (.lit (evalCodesOff ℓ M₀ wEvalBase)) (.readHeap scrW (.lit (wEvalBase + 7))))
      (.readHeap scrW (.lit (wEvalBase + 9)))) m_lp m_out 25 :=
    DetExecAt.writeWordHeap 0 inp m_lp scrW _ _
      (by change evalCodesOff ℓ M₀ wEvalBase + H3a.wRead m_lp scrW (wEvalBase + 7) = outOff
          rw [hidx_lp])
      (by change H3a.wRead m_lp scrW (wEvalBase + 9) = _; rw [hcode_lp, hcode_eq])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_out : InFootprint TW BW TR BR m_out :=
    InFootprint.wWrite hfp_lp hscrW hout_bounds.1 hout_bounds.2
  have hfr_out : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_out :=
    hfr_lp.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_lp _ _)
  refine ⟨m_out, (hd_a.seq (hd_b.seq (hd_c.seq (hd_loop.seq hd_out)))).mono_cost (by omega),
    hfp_out, wRead_wWrite_self _ _ _ _, ?_, fun r => hkR_lp r, hfr_out⟩
  intro w h0 h4 h8 h9 hout
  rw [wRead_wWrite_of_ne _ _ (Or.inr hout)]
  exact hkW_lp w h0 h4 h8 h9

def evalCopyTuplesStmt (scrW scrR tblR : ℕ)
    (wCapBaseR wEvalBase rScrBase rWBase : ℤ)
    (ℓ M₀ d cap : ℕ) (strictCap : Bool) (A B_signed a₀ : ℚ) : ArithRAMStmt :=
  let K_trunc : ℕ := if strictCap then cap + 1 else cap
  let wAllPos := wEvalBase + 5
  let wProd := wEvalBase + 6
  let wIdx := wEvalBase + 7
  let wOutLen := wEvalBase + 11
  .seq (evalCopyPhase1Stmt scrW scrR tblR wCapBaseR wEvalBase rScrBase rWBase ℓ M₀ d K_trunc A B_signed a₀)
  (.seq (.ite (.and (.intEq (.readHeap scrW (.lit wAllPos)) (.lit 1))
                    (.intLe (.readHeap scrW (.lit wProd)) (.lit (cap : ℤ))))
          (.writeWordHeap scrW (.lit wOutLen) (.readHeap scrW (.lit wProd)))
          (.writeWordHeap scrW (.lit wOutLen) (.lit 0)))
  (.seq (.writeWordHeap scrW (.lit wIdx) (.lit 0))
        (.repeatN (.readHeap scrW (.lit wOutLen))
          (.seq (evalCopyOneTupleStmt scrW wEvalBase ℓ M₀)
                (.writeWordHeap scrW (.lit wIdx)
                  (.add (.readHeap scrW (.lit wIdx)) (.lit 1)))))))

def evalCopyTuplesCost (ℓ M₀ d cap : ℕ) : ℕ :=
  200 + ℓ * (250 + M₀ * (350 + 80 * d)) + cap * (110 + 130 * ℓ)

theorem exec_evalCopyTuplesStmt {d TW BW TR BR scrW scrR tblR tblW : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCapBaseR wEvalBase rScrBase rWBase capBaseR baseW baseR : ℤ)
    {ℓ M₀ : ℕ} (hM₀ : 1 ≤ M₀) (cap : ℕ) (strictCap : Bool) (A B_signed a₀ : ℚ)
    (caps_r : Fin ℓ → Fin M₀ → EuclideanSpace ℝ (Fin (d + 1)))
    (w : EuclideanSpace ℝ (Fin d))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneR : tblR ≠ scrR)
    (hwEval : 0 ≤ wEvalBase ∧ wEvalBase + evalWStride ℓ M₀ cap ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScrBase ∧ rScrBase + 4 + (d : ℤ) ≤ (BR : ℤ))
    (hrW_disj : rScrBase + 4 + (d : ℤ) ≤ rWBase ∨ rWBase + (d : ℤ) ≤ rScrBase)
    (hwCap_disj : wCapBaseR < wEvalBase ∨ wEvalBase + evalWStride ℓ M₀ cap ≤ wCapBaseR)
    (hcapB : H3a.wRead m₀ scrW wCapBaseR = capBaseR)
    (hCaps : ∀ (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)),
      H3a.rRead m₀ tblR (capBaseR + (((s.val * M₀ + k.val) * (d + 1) : ℕ) : ℤ) + (j.val : ℤ)) =
        euclideanCoord (caps_r s k) j)
    (hw_vec : ∀ i : Fin d, H3a.rRead m₀ scrR (rWBase + (i.val : ℤ)) = euclideanCoord w i) :
    let K_trunc : ℕ := if strictCap then cap + 1 else cap
    let eligList : Fin ℓ → List (Fin M₀) := fun s => open Classical in
      (List.finRange M₀).filter (fun k =>
        realSignedSqCapCond (A : ℝ) (B_signed : ℝ) (a₀ : ℝ) (caps_r s k) w)
    let cnt : Fin ℓ → ℕ := fun s => (eligList s).length
    let elig : Fin ℓ → ℕ → ℕ := fun s j =>
      if hj : j < (eligList s).length then ((eligList s)[j]).val else 0
    let outLen : ℕ := open Classical in
      if (∀ s : Fin ℓ, 1 ≤ cnt s) ∧ truncMul K_trunc cnt ≤ cap then truncMul K_trunc cnt else 0
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (evalCopyTuplesStmt scrW scrR tblR wCapBaseR wEvalBase rScrBase rWBase ℓ M₀ d cap strictCap A B_signed a₀)
        m₀ m₁ (evalCopyTuplesCost ℓ M₀ d cap) ∧
      InFootprint TW BW TR BR m₁ ∧
      outLen ≤ cap ∧
      H3a.wRead m₁ scrW (wEvalBase + 11) = (outLen : ℤ) ∧
      (∀ idx < outLen,
        H3a.wRead m₁ scrW (evalCodesOff ℓ M₀ wEvalBase + (idx : ℤ)) =
          @Nat.cast ℤ _ (encodeTuple (mixedTuple hM₀ cnt elig idx))) ∧
      (∀ idx : ℤ,
        (idx < wEvalBase ∨ wEvalBase + evalWStride ℓ M₀ cap ≤ idx) →
        H3a.wRead m₁ scrW idx = H3a.wRead m₀ scrW idx) ∧
      (∀ r : ℤ, (r < rScrBase ∨ rScrBase + 4 + (d : ℤ) ≤ r) →
        H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  classical
  intro K_trunc eligList cnt elig outLen
  have hstride_ge : 12 + (ℓ : ℤ) + ((ℓ * M₀ : ℕ) : ℤ) + (cap : ℤ) = evalWStride ℓ M₀ cap := rfl
  have hout_le : outLen ≤ cap := by
    dsimp [outLen]
    split_ifs with h
    · exact h.2
    · exact Nat.zero_le cap
  have hcnt_le : ∀ s : Fin ℓ, cnt s ≤ M₀ := fun s =>
    (List.length_filter_le _ _).trans (by simp)
  have helig_lt : ∀ (s : Fin ℓ) (j : ℕ), j < cnt s → elig s j < M₀ := by
    intro s j hj
    dsimp [elig, cnt] at hj ⊢
    rw [dif_pos hj]
    exact ((eligList s)[j]).isLt
  obtain ⟨m1, hd1, hfp1, hall1, hprod1, hcnt1, helig1, hkW1, hkR1, hfr1⟩ :=
    exec_evalCopyPhase1Stmt (tblW := tblW) (cap := cap) inp
      wCapBaseR wEvalBase rScrBase rWBase capBaseR baseW baseR K_trunc A B_signed a₀ caps_r w
      hfp₀ hscrW hscrR hneR hwEval hrScr hrW_disj hwCap_disj hcapB hCaps hw_vec
  -- Step 2: set wOutLen
  let outStmt : ArithRAMStmt :=
    .ite (.and (.intEq (.readHeap scrW (.lit (wEvalBase + 5))) (.lit 1))
               (.intLe (.readHeap scrW (.lit (wEvalBase + 6))) (.lit (cap : ℤ))))
      (.writeWordHeap scrW (.lit (wEvalBase + 11)) (.readHeap scrW (.lit (wEvalBase + 6))))
      (.writeWordHeap scrW (.lit (wEvalBase + 11)) (.lit 0))
  have hout_step : ∃ m2 : ArithRAMMemory,
      DetExec inp outStmt m1 m2 40 ∧
      InFootprint TW BW TR BR m2 ∧
      H3a.wRead m2 scrW (wEvalBase + 11) = (outLen : ℤ) ∧
      (∀ w : ℤ, w ≠ wEvalBase + 11 → H3a.wRead m2 scrW w = H3a.wRead m1 scrW w) ∧
      (∀ r : ℤ, H3a.rRead m2 scrR r = H3a.rRead m1 scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m2 := by
    by_cases hok : (∀ s : Fin ℓ, 1 ≤ cnt s) ∧ truncMul K_trunc cnt ≤ cap
    · have hout_eq : outLen = truncMul K_trunc cnt := if_pos hok
      have hc_t : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m1
          (.and (.intEq (.readHeap scrW (.lit (wEvalBase + 5))) (.lit 1))
                (.intLe (.readHeap scrW (.lit (wEvalBase + 6))) (.lit (cap : ℤ)))) = true := by
        simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
        change (decide (H3a.wRead m1 scrW (wEvalBase + 5) = 1) &&
                decide (H3a.wRead m1 scrW (wEvalBase + 6) ≤ (cap : ℤ))) = true
        rw [hall1, if_pos hok.1, hprod1]
        simp only [decide_true, Bool.true_and]
        exact decide_eq_true (by exact_mod_cast hok.2)
      let m2 := H3a.wWrite m1 scrW (wEvalBase + 11) (outLen : ℤ)
      have hd_t : DetExec inp
          (.writeWordHeap scrW (.lit (wEvalBase + 11)) (.readHeap scrW (.lit (wEvalBase + 6))))
          m1 m2 15 :=
        DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wEvalBase + 11)) _ rfl
          (by change H3a.wRead m1 scrW (wEvalBase + 6) = _; rw [hprod1, hout_eq])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m2,
        (DetExecAt.ite_true (fB := .writeWordHeap scrW (.lit (wEvalBase + 11)) (.lit 0))
          (C_c := 20) hc_t
          (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          hd_t).mono_cost (by omega),
        InFootprint.wWrite hfp1 hscrW (by omega) (by omega),
        wRead_wWrite_self _ _ _ _,
        fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
        fun _ => rfl,
        hfr1.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m1 _ _)⟩
    · have hout_eq : outLen = 0 := if_neg hok
      have hc_f : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m1
          (.and (.intEq (.readHeap scrW (.lit (wEvalBase + 5))) (.lit 1))
                (.intLe (.readHeap scrW (.lit (wEvalBase + 6))) (.lit (cap : ℤ)))) = false := by
        simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
        change (decide (H3a.wRead m1 scrW (wEvalBase + 5) = 1) &&
                decide (H3a.wRead m1 scrW (wEvalBase + 6) ≤ (cap : ℤ))) = false
        rw [hall1, hprod1]
        by_cases h1 : ∀ s : Fin ℓ, 1 ≤ cnt s
        · have h2 : ¬ ((@Nat.cast ℤ _ (truncMul K_trunc cnt)) ≤ (cap : ℤ)) := by
            intro hle; exact hok ⟨h1, by exact_mod_cast hle⟩
          rw [if_pos h1, decide_eq_false h2]; rfl
        · rw [if_neg h1]; rfl
      let m2 := H3a.wWrite m1 scrW (wEvalBase + 11) 0
      have hd_f : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 11)) (.lit 0)) m1 m2 10 :=
        DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wEvalBase + 11)) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m2,
        (DetExecAt.ite_false
          (tB := .writeWordHeap scrW (.lit (wEvalBase + 11)) (.readHeap scrW (.lit (wEvalBase + 6))))
          (C_c := 20) hc_f
          (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          hd_f).mono_cost (by omega),
        InFootprint.wWrite hfp1 hscrW (by omega) (by omega),
        by rw [wRead_wWrite_self, hout_eq]; rfl,
        fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
        fun _ => rfl,
        hfr1.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m1 _ _)⟩
  obtain ⟨m2, hd2, hfp2, hout2, hkW2, hkR2, hfr2⟩ := hout_step
  -- Step 3: wIdx := 0 and repeatN outLen
  let m3 := H3a.wWrite m2 scrW (wEvalBase + 7) 0
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 7)) (.lit 0)) m2 m3 10 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wEvalBase + 7)) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 hscrW (by omega) (by omega)
  have hfr3 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m3 :=
    hfr2.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m2 _ _)
  let Inv2 : ℕ → ArithRAMMemory → Prop := fun idx m =>
    InFootprint TW BW TR BR m ∧
    H3a.wRead m scrW (wEvalBase + 7) = (idx : ℤ) ∧
    H3a.wRead m scrW (wEvalBase + 11) = (outLen : ℤ) ∧
    (∀ s : Fin ℓ, H3a.wRead m scrW (evalCntOff wEvalBase s.val) = @Nat.cast ℤ _ (cnt s)) ∧
    (∀ (s : Fin ℓ) (j : ℕ), j < cnt s →
      H3a.wRead m scrW (evalEligOff ℓ M₀ wEvalBase s.val j) = @Nat.cast ℤ _ (elig s j)) ∧
    (∀ j < idx,
      H3a.wRead m scrW (evalCodesOff ℓ M₀ wEvalBase + (j : ℤ)) =
        @Nat.cast ℤ _ (encodeTuple (mixedTuple hM₀ cnt elig j))) ∧
    (∀ w : ℤ,
      (w < wEvalBase ∨ wEvalBase + evalWStride ℓ M₀ cap ≤ w) →
      H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
    (∀ r : ℤ, (r < rScrBase ∨ rScrBase + 4 + (d : ℤ) ≤ r) →
      H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
    RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
  have hInv2_0 : Inv2 0 m3 := by
    refine ⟨hfp3, wRead_wWrite_self _ _ _ _,
      by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hout2,
      fun s => ?_, fun s j hj => ?_, fun _ hj => by omega,
      fun w hw => ?_, fun r hr => ?_, hfr3⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalCntOff; omega)),
          hkW2 _ (by unfold evalCntOff; omega)]
      exact hcnt1 s
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalEligOff; omega)),
          hkW2 _ (by unfold evalEligOff; omega)]
      have he := helig1 s j hj
      dsimp [elig, cnt] at hj ⊢
      rw [dif_pos hj]
      exact he
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hkW2 _ (by omega)]
      exact hkW1 w hw
    · rw [rRead_wWrite, hkR2]; exact hkR1 r hr
  let C_tup : ℕ := 110 + 130 * ℓ
  obtain ⟨m_end, hInvEnd, hd_loop⟩ := DetExecAt.repeatN_nat
    (.readHeap scrW (.lit (wEvalBase + 11))) _ outLen 10 C_tup Inv2 hInv2_0
    (by change H3a.wRead m3 scrW (wEvalBase + 11) = (outLen : ℤ)
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hout2)
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    (fun idx hidx m ⟨hfp_m, hidx_m, hout_m, hcnt_m, helig_m, hcodes_m, hkW_m, hkR_m, hfr_m⟩ => by
      have hidx_cap : idx < cap := lt_of_lt_of_le hidx hout_le
      have hcnt_pos : ∀ s : Fin ℓ, 1 ≤ cnt s := by
        have hpos_out : 0 < outLen := by omega
        dsimp [outLen] at hpos_out
        split_ifs at hpos_out with hok
        · exact hok.1
        · omega
      obtain ⟨m_t, hd_t, hfp_t, hcode_t, hkW_t, hkR_t, hfr_t⟩ :=
        exec_evalCopyOneTupleStmt (scrR := scrR) (tblW := tblW) (tblR := tblR) inp
          wEvalBase baseW baseR hM₀ hidx_cap cnt elig hcnt_pos hcnt_le helig_lt
          hfp_m hscrW hwEval hidx_m hcnt_m helig_m
      have hidx_t : H3a.wRead m_t scrW (wEvalBase + 7) = (idx : ℤ) := by
        rw [hkW_t _ (by omega) (by omega) (by omega) (by omega)
          (by unfold evalCodesOff; omega)]
        exact hidx_m
      let m_nx := H3a.wWrite m_t scrW (wEvalBase + 7) ((idx + 1 : ℕ) : ℤ)
      have hd_nx : DetExec inp (.writeWordHeap scrW (.lit (wEvalBase + 7))
          (.add (.readHeap scrW (.lit (wEvalBase + 7))) (.lit 1))) m_t m_nx 20 :=
        DetExecAt.writeWordHeap 0 inp m_t scrW (.lit (wEvalBase + 7)) _ rfl
          (by change H3a.wRead m_t scrW (wEvalBase + 7) + 1 = _; rw [hidx_t]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_nx : InFootprint TW BW TR BR m_nx :=
        InFootprint.wWrite hfp_t hscrW (by omega) (by omega)
      have hfr_nx : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_nx :=
        (hfr_m.trans hfr_t).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_t _ _)
      refine ⟨m_nx, (hd_t.seq hd_nx).mono_cost (by dsimp only [C_tup]; omega),
        hfp_nx, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, ?_, ?_, ?_, hfr_nx⟩
      · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW_t _ (by omega) (by omega) (by omega) (by omega) (by unfold evalCodesOff; omega)]
        exact hout_m
      · intro s
        have hs_lt := s.isLt
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalCntOff; omega)),
            hkW_t _ (by unfold evalCntOff; omega) (by unfold evalCntOff; omega)
              (by unfold evalCntOff; omega) (by unfold evalCntOff; omega)
              (by unfold evalCntOff evalCodesOff; omega)]
        exact hcnt_m s
      · intro s j hj
        have hs_lt := s.isLt
        have hj_M : j < M₀ := lt_of_lt_of_le hj (hcnt_le s)
        have hlt_lm := mul_add_lt_of_lt hs_lt hj_M
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalEligOff; omega)),
            hkW_t _ (by unfold evalEligOff; omega) (by unfold evalEligOff; omega)
              (by unfold evalEligOff; omega) (by unfold evalEligOff; omega)
              (by unfold evalEligOff evalCodesOff; omega)]
        exact helig_m s j hj
      · intro j hj
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalCodesOff; omega))]
        by_cases he : j = idx
        · subst he; exact hcode_t
        · have hj_lt : j < idx := by omega
          rw [hkW_t _ (by unfold evalCodesOff; omega) (by unfold evalCodesOff; omega)
            (by unfold evalCodesOff; omega) (by unfold evalCodesOff; omega)
            (by unfold evalCodesOff; omega)]
          exact hcodes_m j hj_lt
      · intro w hw
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW_t _ (by omega) (by omega) (by omega) (by omega)
              (by unfold evalCodesOff evalWStride at *; omega)]
        exact hkW_m w hw
      · intro r hr
        rw [rRead_wWrite, hkR_t]; exact hkR_m r hr)
  rcases hInvEnd with ⟨hfp_end, _, hout_end, _, _, hcodes_end, hkW_end, hkR_end, hfr_end⟩
  have hcost_le : (80 + ℓ * (250 + M₀ * (350 + 80 * d))) + (40 + (10 + (10 + outLen * C_tup))) ≤
      evalCopyTuplesCost ℓ M₀ d cap := by
    unfold evalCopyTuplesCost
    have hmul : outLen * C_tup ≤ cap * C_tup := Nat.mul_le_mul_right C_tup hout_le
    dsimp only [C_tup] at hmul ⊢
    omega
  exact ⟨m_end, (hd1.seq (hd2.seq (hd3.seq hd_loop))).mono_cost hcost_le,
    hfp_end, hout_le, hout_end, hcodes_end, hkW_end, hkR_end, hfr_end⟩

theorem queryTupleCodeList_from_eval {R ℓ M₀ d : ℕ} (hM₀ : 1 ≤ M₀)
    (caps : ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)))
    (A B τ_q : ℚ) (cap_q : ℕ) (v_lat : EuclideanSpace ℝ (Fin d)) (r : Fin R) :
    let eligList : Fin ℓ → List (Fin M₀) := fun s => open Classical in
      (List.finRange M₀).filter (fun k =>
        realSignedSqCapCond (A : ℝ) ((-B : ℚ) : ℝ) (τ_q : ℝ) (caps (r, s, k)) v_lat)
    let cnt : Fin ℓ → ℕ := fun s => (eligList s).length
    let elig : Fin ℓ → ℕ → ℕ := fun s j =>
      if hj : j < (eligList s).length then ((eligList s)[j]).val else 0
    let outLen : ℕ := open Classical in
      if (∀ s : Fin ℓ, 1 ≤ cnt s) ∧ truncMul cap_q cnt ≤ cap_q then truncMul cap_q cnt else 0
    let codes := queryTupleCodeList hM₀ caps A B τ_q cap_q v_lat r
    outLen = codes.length ∧
    codes.length ≤ cap_q ∧
    ∀ (idx : ℕ) (hidx : idx < codes.length),
      (codes[idx]).val = encodeTuple (mixedTuple hM₀ cnt elig idx) := by
  classical
  have hcast_neg : ((-B : ℚ) : ℝ) = -(B : ℝ) := by push_cast; ring
  dsimp only
  simp only [hcast_neg]
  set eligList : Fin ℓ → List (Fin M₀) := fun s =>
    (List.finRange M₀).filter (fun k =>
      realSignedSqCapCond (A : ℝ) (-(B : ℝ)) (τ_q : ℝ) (caps (r, s, k)) v_lat)
  set cnt : Fin ℓ → ℕ := fun s => (eligList s).length
  have htr_le : truncMul cap_q cnt ≤ cap_q := truncMul_le_cap cap_q cnt
  by_cases hpos : ∀ s : Fin ℓ, 1 ≤ cnt s
  · have htr_eq : truncMul cap_q cnt = min cap_q (∏ s : Fin ℓ, cnt s) :=
      truncMul_eq_min_prod cap_q cnt hpos
    have hcodes_eq : queryTupleCodeList hM₀ caps A B τ_q cap_q v_lat r =
        (List.range (min cap_q (∏ s : Fin ℓ, cnt s))).map (fun idx =>
          let elig : Fin ℓ → ℕ → ℕ := fun s j =>
            if hj : j < (eligList s).length then ((eligList s)[j]).val else 0
          let τ := mixedTuple hM₀ cnt elig idx
          ⟨encodeTuple τ, encodeTuple_lt hM₀ τ⟩) := by
      unfold queryTupleCodeList
      exact dif_pos hpos
    rw [if_pos ⟨hpos, htr_le⟩]
    generalize queryTupleCodeList hM₀ caps A B τ_q cap_q v_lat r = cs at hcodes_eq ⊢
    subst hcodes_eq
    refine ⟨by rw [List.length_map, List.length_range, htr_eq],
            by rw [List.length_map, List.length_range]; exact Nat.min_le_left _ _,
            fun idx hidx => ?_⟩
    simp only [List.getElem_map, List.getElem_range]; rfl
  · have hcodes_eq : queryTupleCodeList hM₀ caps A B τ_q cap_q v_lat r = [] := by
      unfold queryTupleCodeList
      exact dif_neg hpos
    rw [if_neg (fun h => hpos h.1), hcodes_eq]
    exact ⟨rfl, Nat.zero_le cap_q, fun _ h => by simp at h⟩

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
