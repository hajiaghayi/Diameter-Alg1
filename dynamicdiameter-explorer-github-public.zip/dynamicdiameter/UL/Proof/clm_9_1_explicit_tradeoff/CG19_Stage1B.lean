import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Stage1A
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 3. Single-Node & Chain-List Live Update (`liveUpdateListStmt`) -/

def liveUpdateSingleNodeStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (ops.inCoreBallStmt 15 2 17)
  (.seq (.ite (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))
          (.seq (ops.insertMatStmt 15 2 16) (ops.bumpAgeStmt 15))
          (.seq (ops.deleteMatStmt 15 2 16) (ops.bumpAgeStmt 15)))
        (.writeWordHeap engScrTbl (.lit 14)
          (.sub (.lit 1) (.readHeap engScrTbl (.lit 17)))))

theorem zeroRand_liveUpdateSingleNodeStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (liveUpdateSingleNodeStmt ops) :=
  .seq (ops.zeroRand_inCoreBall 15 2 17)
  (.seq (.ite (.seq (ops.zeroRand_insertMat 15 2 16) (ops.zeroRand_bumpAge 15))
              (.seq (ops.zeroRand_deleteMat 15 2 16) (ops.zeroRand_bumpAge 15)))
        (.writeWordHeap _ _ _))

def C_liveSingle {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  ops.C_ball + max ops.C_ins ops.C_del + ops.C_bump + 30

theorem exec_liveUpdateSingleNodeStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    {actH S : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} {mn : MNode cp}
    {slot seedIdx h_op : ℕ} {isIns : Bool} {bits : Fin cp.B_STEP → Bool}
    (hslot : slot < M_slots cp)
    (hseed : seedIdx < cp.N_op_s1)
    (hhop_lt : h_op < cp.n)
    (hS_sub : S ⊆ actH)
    (hact_lt : ∀ x ∈ actH, x < cp.n)
    (hage_le : mn.nd.age ≤ mn.nd.birthSize)
    (hln : LiveNodeInv cp actH pts gt S mn)
    (hins_case : isIns = true → h_op ∉ actH ∧ ∀ x ∈ actH, pts' x = pts x)
    (hdel_case : isIns = false → h_op ∈ S ∧ pts' = pts)
    (hpts_mem : ∀ x ∈ insert h_op actH, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts' x) c)
    (hcoins : MemHasStepCoins cp bits m₀)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (henc_mn : ops.EncNode mn slot m₀)
    (hr1 : wRead m₀ engScrTbl 1 = (if isIns then 1 else 0))
    (hr2 : wRead m₀ engScrTbl 2 = (h_op : ℤ))
    (hr15 : wRead m₀ engScrTbl 15 = (slot : ℤ))
    (hr16 : wRead m₀ engScrTbl 16 = ((seedIdx * cp.B_op : ℕ) : ℤ)) :
    let ω₁ := (bitsToStepCoinBundle cp bits).1
    let mn₁ := liveStepSingleNode cp pts' isIns h_op (getS1Seed cp ω₁ seedIdx) mn
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (liveUpdateSingleNodeStmt ops) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        ops.EncNode mn₁ slot m₁ ∧
        wRead m₁ engScrTbl 14 = (if !inCoreBall mn.nd.o mn.nd.V (pts' h_op) then 1 else 0) ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ slot → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 14 → i ≠ 17 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (C_liveSingle ops) := by
  have hTW := ops.hTW
  have hBW_s := ops_hBW_scr64 ops
  rcases hln with ⟨hcur, hbsz_n, _, _, _, hhist, htins, hwf⟩
  have hcur_sub : mn.nd.curSet ⊆ actH := hcur ▸ hS_sub
  have hcur_lt : ∀ x ∈ mn.nd.curSet, x < cp.n := fun x hx => hact_lt x (hcur_sub hx)
  have heq_pts : ∀ x ∈ mn.nd.curSet, pts' x = pts x := by
    intro x hx
    cases his : isIns
    · rw [(hdel_case his).2]
    · exact (hins_case his).2 x (hcur_sub hx)
  have hwf_pts' : ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts' mn :=
    managedNodeWF_pts_congr heq_pts hwf
  have hcap_t : (mn.nd.birthSize + mn.nd.age) + 1 < 2 ^ cp.L_p2 := by
    have := cp.hL_p2; omega
  rcases memHasStepCoins_stage1 cp bits m₀ hcoins hseed with ⟨seedBits, hseed_eq, hcoin_ub, hcoin_rd⟩
  unfold liveUpdateSingleNodeStmt C_liveSingle
  refine ExecDet.seq' (max ops.C_ins ops.C_del + ops.C_bump + 30)
    (ops.inCoreBall_spec inp m₀ mn slot h_op (pts' h_op) 15 2 17 hslot hhop_lt
      (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
      hfp₀ hsr₀ henc_mn hr15 hr2
      (fun c => hpts_mem h_op (Finset.mem_insert_self _ _) c))
    (by omega) ?_
  intro m₁ ⟨hsr₁, hcb₁, hnd₁, hw₁_t, hw₁_scr, hr₁⟩ hfp₁
  have hr1_1 : wRead m₁ engScrTbl 1 = (if isIns then 1 else 0) :=
    (hw₁_scr 1 (by decide)).trans hr1
  have hr2_1 : wRead m₁ engScrTbl 2 = (h_op : ℤ) := (hw₁_scr 2 (by decide)).trans hr2
  have hr15_1 : wRead m₁ engScrTbl 15 = (slot : ℤ) := (hw₁_scr 15 (by decide)).trans hr15
  have hr16_1 : wRead m₁ engScrTbl 16 = ((seedIdx * cp.B_op : ℕ) : ℤ) :=
    (hw₁_scr 16 (by decide)).trans hr16
  have hcond : (evalArithCond inp 0 m₁ (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))).1 = isIns := by
    simp only [evalArithCond, evalIntExpr]
    change decide (wRead m₁ engScrTbl 1 = 1) = isIns
    rw [hr1_1]; cases isIns <;> rfl
  refine ExecDet.seq' (Mid := fun m₃ =>
      ops.SlotsReady m₃ ∧
      ops.EncNode (liveStepSingleNode cp pts' isIns h_op
        (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) seedIdx) mn) slot m₃ ∧
      wRead m₃ engScrTbl 17 = (if inCoreBall mn.nd.o mn.nd.V (pts' h_op) then 1 else 0) ∧
      (∀ mn' s', s' < M_slots cp → s' ≠ slot → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m₃) ∧
      (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₃ t i = wRead m₀ t i) ∧
      (∀ i, i ≠ 17 → wRead m₃ engScrTbl i = wRead m₀ engScrTbl i) ∧
      (∀ t < 3, ∀ i, rRead m₃ t i = rRead m₀ t i)) 14
    (ExecDet.ite' (C_c := 8) (C_b := max ops.C_ins ops.C_del + ops.C_bump)
      (C := max ops.C_ins ops.C_del + ops.C_bump + 8) _ _ _ hcond
      (by simp [condExprOps, intExprOps]) (fun his_t => ?_) (fun his_f => ?_))
    (by omega) ?_
  · have hp_not : h_op ∉ mn.nd.curSet := fun hm => (hins_case his_t).1 (hcur_sub hm)
    refine ExecDet.seq' ops.C_bump
      (ops.insertMat_spec inp m₁ pts' mn slot h_op (seedIdx * cp.B_op) (mn.nd.birthSize + mn.nd.age)
        seedBits 15 2 16 hslot hhop_lt hp_not hcur_lt (by omega) htins hcap_t hwf_pts' hcoin_ub
        (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
        hfp₁ hsr₁ (hnd₁ mn slot hslot henc_mn) hr15_1 hr2_1 hr16_1
        (fun x hx c => by
          rw [hr₁ ptsRTbl (by decide)]
          rcases Finset.mem_insert.mp hx with rfl | hxm
          · exact hpts_mem x (Finset.mem_insert_self _ _) c
          · exact hpts_mem x (Finset.mem_insert_of_mem (hcur_sub hxm)) c)
        (fun k => (hw₁_t coinTbl (by decide) (by decide) _).trans (hcoin_rd k)))
      (by omega) ?_
    intro m₂ ⟨hsr₂, henc_mat, hnd₂, hw₂, hr₂⟩ hfp₂
    refine (ops.bumpAge_spec inp m₂ _ slot 15 hslot (by dsimp [ManagedNode.insertMat, NodeInst.insertMat]; omega)
      (by omega) (by omega) hfp₂ hsr₂ henc_mat ((hw₂ engScrTbl (by decide) 15).trans hr15_1)).mono
      (fun m₃ ⟨hsr₃, henc_b, hnd₃, hw₃, hr₃⟩ _ => ?_) le_rfl
    have hmn1_eq : liveStepSingleNode cp pts' isIns h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) seedIdx) mn =
        (mn.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op (bitsToOpSeedEquiv cp seedBits)).bumpAge := by
      unfold liveStepSingleNode; rw [if_pos his_t, hseed_eq]
    refine ⟨hsr₃, hmn1_eq ▸ henc_b,
      (hw₃ engScrTbl (by decide) 17).trans ((hw₂ engScrTbl (by decide) 17).trans hcb₁),
      fun mn' s' hs' hne he0 => hnd₃ mn' s' hs' hne (hnd₂ mn' s' hs' hne (hnd₁ mn' s' hs' he0)),
      fun t ht9 ht8 i => (hw₃ t ht9 i).trans ((hw₂ t ht9 i).trans (hw₁_t t ht9 ht8 i)),
      fun i hi17 => (hw₃ engScrTbl (by decide) i).trans ((hw₂ engScrTbl (by decide) i).trans (hw₁_scr i hi17)),
      fun t ht3 i => (hr₃ t ht3 i).trans ((hr₂ t ht3 i).trans (hr₁ t ht3 i))⟩
  · have hp_in : h_op ∈ mn.nd.curSet := hcur ▸ (hdel_case his_f).1
    refine ExecDet.seq' ops.C_bump
      (ops.deleteMat_spec inp m₁ pts' mn slot h_op (seedIdx * cp.B_op) (mn.nd.birthSize + mn.nd.age)
        seedBits 15 2 16 hslot hhop_lt hp_in hcur_lt (by omega) htins hcap_t hwf_pts' hcoin_ub
        (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
        hfp₁ hsr₁ (hnd₁ mn slot hslot henc_mn) hr15_1 hr2_1 hr16_1
        (fun x hx c => by
          rw [hr₁ ptsRTbl (by decide)]
          exact hpts_mem x (Finset.mem_insert_of_mem (hcur_sub hx)) c)
        (fun k => (hw₁_t coinTbl (by decide) (by decide) _).trans (hcoin_rd k)))
      (by omega) ?_
    intro m₂ ⟨hsr₂, henc_mat, hnd₂, hw₂, hr₂⟩ hfp₂
    refine (ops.bumpAge_spec inp m₂ _ slot 15 hslot (by dsimp [ManagedNode.deleteMat, NodeInst.deleteMat]; omega)
      (by omega) (by omega) hfp₂ hsr₂ henc_mat ((hw₂ engScrTbl (by decide) 15).trans hr15_1)).mono
      (fun m₃ ⟨hsr₃, henc_b, hnd₃, hw₃, hr₃⟩ _ => ?_) le_rfl
    have hmn1_eq : liveStepSingleNode cp pts' isIns h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) seedIdx) mn =
        (mn.deleteMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op (bitsToOpSeedEquiv cp seedBits)).bumpAge := by
      unfold liveStepSingleNode; rw [if_neg (by simp [his_f]), hseed_eq]
    refine ⟨hsr₃, hmn1_eq ▸ henc_b,
      (hw₃ engScrTbl (by decide) 17).trans ((hw₂ engScrTbl (by decide) 17).trans hcb₁),
      fun mn' s' hs' hne he0 => hnd₃ mn' s' hs' hne (hnd₂ mn' s' hs' hne (hnd₁ mn' s' hs' he0)),
      fun t ht9 ht8 i => (hw₃ t ht9 i).trans ((hw₂ t ht9 i).trans (hw₁_t t ht9 ht8 i)),
      fun i hi17 => (hw₃ engScrTbl (by decide) i).trans ((hw₂ engScrTbl (by decide) i).trans (hw₁_scr i hi17)),
      fun t ht3 i => (hr₃ t ht3 i).trans ((hr₂ t ht3 i).trans (hr₁ t ht3 i))⟩
  · intro m₃ ⟨hsr₃, henc_b, hcb₃, hnd₃, hw₃_t, hw₃_scr, hr₃⟩ hfp₃
    refine ExecDet.wWrite inp engScrTbl (.lit 14) (.sub (.lit 1) (.readHeap engScrTbl (.lit 17)))
      14 (if !inCoreBall mn.nd.o mn.nd.V (pts' h_op) then 1 else 0)
      hfp₃ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change 1 - wRead m₃ engScrTbl 17 = _
          rw [hcb₃]; cases inCoreBall mn.nd.o mn.nd.V (pts' h_op) <;> rfl)
      (by simp [intExprOps]) ?_
    set m₄ := H3a.wWrite m₃ engScrTbl 14 (if !inCoreBall mn.nd.o mn.nd.V (pts' h_op) then 1 else 0)
    have hnd_w : ∀ mn' s', ops.EncNode mn' s' m₃ → ops.EncNode mn' s' m₄ :=
      fun mn' s' he => ops.encNode_ext mn' s' m₃ m₄ he
        (fun t ht9 _ i => wRead_wWrite_of_ne m₃ _ (Or.inl (by dsimp [engScrTbl]; omega)))
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
    refine ⟨ops.slotsReady_ext m₃ m₄ hsr₃
        (fun t ht9 _ i => wRead_wWrite_of_ne m₃ _ (Or.inl (by dsimp [engScrTbl]; omega)))
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      hnd_w _ _ henc_b,
      wRead_wWrite_self _ _ _ _,
      fun mn' s' hs' hne he0 => hnd_w _ _ (hnd₃ mn' s' hs' hne he0),
      fun t ht9 ht8 i => (wRead_wWrite_of_ne m₃ _ (Or.inl ht8)).trans (hw₃_t t ht9 ht8 i),
      fun i hi14 hi17 => (wRead_wWrite_of_ne m₃ _ (Or.inr hi14)).trans (hw₃_scr i hi17),
      fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans (hr₃ t ht3 i)⟩

def liveUpdateListStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 14) (.lit 1))
    (forLoopStmt engScrTbl 10 cp.D_max
      (.ite (.and (.intLt (.readHeap engScrTbl (.lit 10)) (.readHeap engScrTbl (.lit 12)))
                  (.intEq (.readHeap engScrTbl (.lit 14)) (.lit 1)))
        (.seq (.writeWordHeap engScrTbl (.lit 15)
                (.readHeap engMetaTbl
                  (.add (.readHeap engScrTbl (.lit 11)) (.readHeap engScrTbl (.lit 10)))))
        (.seq (.writeWordHeap engScrTbl (.lit 16)
                (.mul (.add (.readHeap engScrTbl (.lit 13)) (.readHeap engScrTbl (.lit 10)))
                      (.lit (cp.B_op : ℤ))))
              (liveUpdateSingleNodeStmt ops)))
        .skip))

theorem zeroRand_liveUpdateListStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (liveUpdateListStmt ops) :=
  .seq (.writeWordHeap _ _ _)
    (zeroRand_forLoopStmt
      (.ite (.seq (.writeWordHeap _ _ _)
              (.seq (.writeWordHeap _ _ _) (zeroRand_liveUpdateSingleNodeStmt ops)))
            .skip))

def C_liveList {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  30 + cp.D_max * ((C_liveSingle ops + 48) + 6)

theorem exec_liveUpdateListStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    {actH S₀ : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d} {nds : List (MNode cp)} {slots : List ℕ}
    {metaSlotsOff : ℤ} {baseIdx h_op : ℕ} {isIns : Bool} {bits : Fin cp.B_STEP → Bool}
    (hlen_le : nds.length ≤ cp.D_max)
    (hslen : slots.length = nds.length)
    (hs_nodup : slots.Nodup)
    (hs_lt : ∀ s ∈ slots, s < M_slots cp)
    (hmeta0 : 0 ≤ metaSlotsOff)
    (hmetaB : metaSlotsOff + (nds.length : ℤ) ≤ (ops.BW : ℤ))
    (hbase_lt : baseIdx + nds.length ≤ cp.N_op_s1)
    (hhop_lt : h_op < cp.n)
    (hS₀_sub : S₀ ⊆ actH)
    (hact_lt : ∀ x ∈ actH, x < cp.n)
    (hage_le : ∀ mn ∈ nds, mn.nd.age ≤ mn.nd.birthSize)
    (hcl : ChainListInv cp actH pts gt S₀ nds)
    (hins_case : isIns = true → h_op ∉ actH ∧ ∀ x ∈ actH, pts' x = pts x)
    (hdel_case : isIns = false → h_op ∈ S₀ ∧ pts' = pts)
    (hpts_mem : ∀ x ∈ insert h_op actH, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts' x) c)
    (hcoins : MemHasStepCoins cp bits m₀)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hslots_enc : ∀ q (hq : q < nds.length) (hqs : q < slots.length),
      wRead m₀ engMetaTbl (metaSlotsOff + (q : ℤ)) = (slots[q]'hqs : ℤ) ∧
      ops.EncNode (nds[q]'hq) (slots[q]'hqs) m₀)
    (hr1 : wRead m₀ engScrTbl 1 = (if isIns then 1 else 0))
    (hr2 : wRead m₀ engScrTbl 2 = (h_op : ℤ))
    (hr11 : wRead m₀ engScrTbl 11 = metaSlotsOff)
    (hr12 : wRead m₀ engScrTbl 12 = (nds.length : ℤ))
    (hr13 : wRead m₀ engScrTbl 13 = (baseIdx : ℤ)) :
    let ω₁ := (bitsToStepCoinBundle cp bits).1
    let res := liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx nds
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (liveUpdateListStmt ops) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        res.1.length = nds.length ∧
        (∀ q (hq : q < res.1.length) (hqs : q < slots.length),
          ops.EncNode (res.1[q]'hq) (slots[q]'hqs) m₁) ∧
        wRead m₁ engScrTbl 14 = (if res.2 then 1 else 0) ∧
        (∀ mn' s', s' < M_slots cp → s' ∉ slots → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, (i < 10 ∨ 20 ≤ i) → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (C_liveList ops) := by
  have hTW := ops.hTW
  have hBW_s := ops_hBW_scr64 ops
  let ω₁ := (bitsToStepCoinBundle cp bits).1
  unfold liveUpdateListStmt C_liveList
  refine ExecDet.seq' (4 + (1 + cp.D_max * ((C_liveSingle ops + 48) + 6)))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 14) (.lit 1) 14 1
      hfp₀ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m_init hm_init hfp_init; subst hm_init
  let curList : ℕ → List (MNode cp) := fun k =>
    (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx (nds.take k)).1 ++ nds.drop k
  have hcur_len : ∀ k, (curList k).length = nds.length := by
    intro k
    simp only [curList, List.length_append, liveUpdateChainList_length, List.length_take, List.length_drop]
    omega
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    let rk := liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx (nds.take k)
    ops.SlotsReady m ∧
    (∀ q (hq : q < (curList k).length) (hqs : q < slots.length),
      ops.EncNode ((curList k)[q]'hq) (slots[q]'hqs) m) ∧
    wRead m engScrTbl 14 = (if rk.2 then 1 else 0) ∧
    (∀ mn' s', s' < M_slots cp → s' ∉ slots → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m) ∧
    (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ i, (i < 10 ∨ i = 11 ∨ i = 12 ∨ i = 13 ∨ 20 ≤ i) →
      wRead m engScrTbl i = wRead m₀ engScrTbl i) ∧
    (∀ t < 3, ∀ i, rRead m t i = rRead m₀ t i)
  refine (ExecDet.forLoop engScrTbl 10 cp.D_max _ Inv (C_liveSingle ops + 48)
    hfp_init (by dsimp [engScrTbl]; omega) (by omega) (by omega) ?_ ?_).mono ?_ (by omega)
  · set mZ := H3a.wWrite (H3a.wWrite m₀ engScrTbl 14 1) engScrTbl 10 0
    have hndZ : ∀ mn' s', ops.EncNode mn' s' m₀ → ops.EncNode mn' s' mZ :=
      fun mn' s' he => ops.encNode_ext mn' s' m₀ mZ he
        (fun t ht9 _ i => by
          simp only [mZ]
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by dsimp [engScrTbl]; omega)),
              wRead_wWrite_of_ne _ _ (Or.inl (by dsimp [engScrTbl]; omega))])
        (fun _ _ _ _ => by simp [mZ, rRead_wWrite])
        (fun _ _ _ _ => by simp [mZ, rRead_wWrite])
    refine ⟨ops.slotsReady_ext m₀ mZ hsr₀
        (fun t ht9 _ i => by
          simp only [mZ]
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by dsimp [engScrTbl]; omega)),
              wRead_wWrite_of_ne _ _ (Or.inl (by dsimp [engScrTbl]; omega))])
        (fun _ _ _ _ => by simp [mZ, rRead_wWrite]),
      fun q hq hqs => ?_,
      by simp only [mZ, List.take_zero, liveUpdateChainList]
         rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]; rfl,
      fun mn' s' _ _ he => hndZ mn' s' he,
      fun t _ ht8 i => by
        simp only [mZ]
        rw [wRead_wWrite_of_ne _ _ (Or.inl ht8), wRead_wWrite_of_ne _ _ (Or.inl ht8)],
      fun i hi => by
        simp only [mZ]
        have h10 : i ≠ 10 := by omega
        have h14 : i ≠ 14 := by omega
        rw [wRead_wWrite_of_ne _ _ (Or.inr h10), wRead_wWrite_of_ne _ _ (Or.inr h14)],
      fun _ _ _ => by simp [mZ, rRead_wWrite]⟩
    have hcur0 : curList 0 = nds := by simp [curList, liveUpdateChainList]
    have hq_nds : q < nds.length := hcur_len 0 ▸ hq
    have heq_elem : (curList 0)[q]'hq = nds[q]'hq_nds := by congr 1
    rw [heq_elem]
    exact hndZ _ _ (hslots_enc q hq_nds hqs).2
  · intro k hk m ⟨hsr_k, hcur_enc, hr14_k, hnd_out, hw_t, hw_scr, hr_m⟩ hr10_k hfp_k
    let rk := liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx (nds.take k)
    have hpass_eq : rk.2 = passesNodes pts' h_op (nds.take k) :=
      liveUpdateChainList_snd_eq cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx (nds.take k)
    have hr12_m : wRead m engScrTbl 12 = (nds.length : ℤ) :=
      (hw_scr 12 (by omega)).trans hr12
    have hcond : (evalArithCond inp 0 m
        (.and (.intLt (.readHeap engScrTbl (.lit 10)) (.readHeap engScrTbl (.lit 12)))
              (.intEq (.readHeap engScrTbl (.lit 14)) (.lit 1)))).1 =
        (decide (k < nds.length) && rk.2) := by
      simp only [evalArithCond, evalIntExpr]
      change (decide (wRead m engScrTbl 10 < wRead m engScrTbl 12) &&
              decide (wRead m engScrTbl 14 = 1)) = _
      rw [hr10_k, hr12_m, hr14_k]
      congr 1
      · exact decide_eq_decide.mpr Int.ofNat_lt
      · cases rk.2 <;> rfl
    refine ExecDet.ite' (C_c := 16) (C_b := C_liveSingle ops + 32) _ _ _ hcond
      (by simp [condExprOps, intExprOps]) (fun hgo => ?_) (fun hskip => ?_)
    · rcases Bool.and_eq_true_iff.mp hgo with ⟨hk_lt_b, hrk2_t⟩
      have hk_nds : k < nds.length := of_decide_eq_true hk_lt_b
      have hk_slots : k < slots.length := hslen ▸ hk_nds
      let slot_k := slots[k]'hk_slots
      have hsl_lt : slot_k < M_slots cp := hs_lt slot_k (List.getElem_mem hk_slots)
      have hr11_m : wRead m engScrTbl 11 = metaSlotsOff := (hw_scr 11 (by omega)).trans hr11
      have hr13_m : wRead m engScrTbl 13 = (baseIdx : ℤ) := (hw_scr 13 (by omega)).trans hr13
      have hslot_rd : wRead m engMetaTbl (metaSlotsOff + (k : ℤ)) = (slot_k : ℤ) :=
        (hw_t engMetaTbl (by decide) (by decide) _).trans (hslots_enc k hk_nds hk_slots).1
      refine ExecDet.seq' (C_liveSingle ops + 16)
        (ExecDet.wWrite (C := 16) inp engScrTbl (.lit 15)
          (.readHeap engMetaTbl (.add (.readHeap engScrTbl (.lit 11)) (.readHeap engScrTbl (.lit 10))))
          15 (slot_k : ℤ) hfp_k (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
          (by simp only [evalIntExpr]
              change wRead m engMetaTbl (wRead m engScrTbl 11 + wRead m engScrTbl 10) = _
              rw [hr11_m, hr10_k, hslot_rd])
          (by simp [intExprOps]) rfl)
        (by omega) ?_
      intro mB hmB hfpB; subst hmB
      refine ExecDet.seq' (C_liveSingle ops)
        (ExecDet.wWrite (C := 16) inp engScrTbl (.lit 16)
          (.mul (.add (.readHeap engScrTbl (.lit 13)) (.readHeap engScrTbl (.lit 10))) (.lit (cp.B_op : ℤ)))
          16 (((baseIdx + k) * cp.B_op : ℕ) : ℤ) hfpB (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
          (by simp only [evalIntExpr]
              change (wRead _ engScrTbl 13 + wRead _ engScrTbl 10) * (cp.B_op : ℤ) = _
              rw [wRead_wWrite_of_ne m _ (Or.inr (by decide)),
                  wRead_wWrite_of_ne m _ (Or.inr (by decide)),
                  hr13_m, hr10_k]; push_cast; ring)
          (by simp [intExprOps]) rfl)
        (by omega) ?_
      intro mC hmC hfpC; subst hmC
      set m_C := H3a.wWrite (H3a.wWrite m engScrTbl 15 (slot_k : ℤ))
        engScrTbl 16 (((baseIdx + k) * cp.B_op : ℕ) : ℤ)
      have hnd_mC : ∀ mn' s', ops.EncNode mn' s' m → ops.EncNode mn' s' m_C :=
        fun mn' s' he => ops.encNode_ext mn' s' m m_C he
          (fun t ht9 _ i => by
            simp only [m_C]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by dsimp [engScrTbl]; omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by dsimp [engScrTbl]; omega))])
          (fun _ _ _ _ => by simp [m_C, rRead_wWrite])
          (fun _ _ _ _ => by simp [m_C, rRead_wWrite])
      have hk_cur : k < (curList k).length := hcur_len k ▸ hk_nds
      have hcur_k_eq : (curList k)[k]'hk_cur = nds[k]'hk_nds := by
        have hlen_pref : rk.1.length = k := by
          dsimp [rk]; rw [liveUpdateChainList_length, List.length_take, Nat.min_eq_left (by omega)]
        dsimp only [curList]
        rw [List.getElem_append_right (Nat.le_of_eq hlen_pref)]
        simp [hlen_pref]
      have henc_mk : ops.EncNode (nds[k]'hk_nds) slot_k m_C := by
        rw [← hcur_k_eq]; exact hnd_mC _ _ (hcur_enc k hk_cur hk_slots)
      rcases (chainListInv_getElem S₀ nds hS₀_sub hcl).2 k hk_nds with ⟨hSk_sub, hln_k⟩
      have hdel_Sk : isIns = false → h_op ∈ foldResiduals pts S₀ (nds.take k) ∧ pts' = pts := by
        intro his_f
        rcases hdel_case his_f with ⟨hh_S0, hpeq⟩
        have hpass_pts : passesNodes pts h_op (nds.take k) = true := by
          rw [← hpeq, ← hpass_eq]; exact hrk2_t
        exact ⟨mem_foldResiduals_of_passesNodes S₀ (nds.take k) hpass_pts hh_S0, hpeq⟩
      refine (exec_liveUpdateSingleNodeStmt ops inp hsl_lt (Nat.lt_of_lt_of_le (Nat.add_lt_add_left hk_nds baseIdx) hbase_lt) hhop_lt hSk_sub hact_lt
        (hage_le _ (List.getElem_mem hk_nds)) hln_k hins_case hdel_Sk
        (fun x hx c => by simp only [m_C, rRead_wWrite]; rw [hr_m ptsRTbl (by decide)]; exact hpts_mem x hx c)
        (fun j => by
          simp only [m_C]
          rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
              hw_t coinTbl (by decide) (by decide)]; exact hcoins j)
        hfpC
        (ops.slotsReady_ext m m_C hsr_k
          (fun t ht9 _ i => by
            simp only [m_C]
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by dsimp [engScrTbl]; omega)),
                wRead_wWrite_of_ne _ _ (Or.inl (by dsimp [engScrTbl]; omega))])
          (fun _ _ _ _ => by simp [m_C, rRead_wWrite]))
        henc_mk
        (by simp only [m_C]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                hw_scr 1 (by omega)]; exact hr1)
        (by simp only [m_C]
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                hw_scr 2 (by omega)]; exact hr2)
        (by simp only [m_C]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
        (by simp only [m_C, wRead_wWrite_self])).mono ?_ le_rfl
      intro mD ⟨hsrD, henc_mn1, hr14D, hndD_ne, hwD_t, hwD_scr, hrD⟩ _
      have hr10D : wRead mD engScrTbl 10 = (k : ℤ) :=
        (hwD_scr 10 (by decide) (by decide)).trans
          (by simp only [m_C]
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hr10_k)
      refine ⟨hr10D, ?_⟩
      set mN := H3a.wWrite mD engScrTbl 10 ((k : ℤ) + 1)
      have hnd_DN : ∀ mn' s', ops.EncNode mn' s' mD → ops.EncNode mn' s' mN :=
        fun mn' s' he => ops.encNode_ext mn' s' mD mN he
          (fun t ht9 _ i => wRead_wWrite_of_ne mD _ (Or.inl (by dsimp [engScrTbl]; omega)))
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
      have htake_succ : nds.take (k + 1) = nds.take k ++ [nds[k]'hk_nds] := by
        rw [List.take_add_one, List.getElem?_eq_getElem hk_nds, Option.toList_some]
      have hsnoc := liveUpdateChainList_snoc cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx
        (nds.take k) (nds[k]'hk_nds)
      dsimp only at hsnoc
      have hlen_tk : (nds.take k).length = k := by rw [List.length_take, Nat.min_eq_left (by omega)]
      have hrk1_eq : liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx (nds.take (k + 1)) =
          (rk.1 ++ [liveStepSingleNode cp pts' isIns h_op (getS1Seed cp ω₁ (baseIdx + k)) (nds[k]'hk_nds)],
           !inCoreBall (nds[k]'hk_nds).nd.o (nds[k]'hk_nds).nd.V (pts' h_op)) := by
        rw [htake_succ, hsnoc, if_pos hrk2_t, hlen_tk]
      have hcur_succ_eq : curList (k + 1) =
          (curList k).set k
            (liveStepSingleNode cp pts' isIns h_op (getS1Seed cp ω₁ (baseIdx + k)) (nds[k]'hk_nds)) := by
        have hlen_rk : (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx (nds.take k)).1.length = k := by
          rw [liveUpdateChainList_length, hlen_tk]
        have hdrop_k : nds.drop k = (nds[k]'hk_nds) :: nds.drop (k + 1) :=
          List.drop_eq_getElem_cons hk_nds
        dsimp only [curList, rk] at hrk1_eq ⊢
        rw [hrk1_eq, hdrop_k, List.set_append_right _ _ (Nat.le_of_eq hlen_rk),
            hlen_rk, Nat.sub_self, List.append_assoc]
        rfl
      refine ⟨ops.slotsReady_ext mD mN hsrD
          (fun t ht9 _ i => wRead_wWrite_of_ne mD _ (Or.inl (by dsimp [engScrTbl]; omega)))
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
        fun q hq hqs => ?_,
        by rw [hrk1_eq]; simp only [mN]
           exact (wRead_wWrite_of_ne mD _ (Or.inr (by decide))).trans hr14D,
        fun mn' s' hs' hns he0 => by
          have hne_s : s' ≠ slot_k := fun heq => hns (heq ▸ List.getElem_mem hk_slots)
          exact hnd_DN _ _ (hndD_ne mn' s' hs' hne_s (hnd_mC _ _ (hnd_out mn' s' hs' hns he0))),
        fun t ht9 ht8 i => (wRead_wWrite_of_ne mD _ (Or.inl ht8)).trans
          ((hwD_t t ht9 ht8 i).trans (by
            simp only [m_C]
            rw [wRead_wWrite_of_ne _ _ (Or.inl ht8), wRead_wWrite_of_ne _ _ (Or.inl ht8)]
            exact hw_t t ht9 ht8 i)),
        fun i hi => by
          have hi10 : i ≠ 10 := by omega
          have hi14 : i ≠ 14 := by omega
          have hi15 : i ≠ 15 := by omega
          have hi16 : i ≠ 16 := by omega
          have hi17 : i ≠ 17 := by omega
          simp only [mN]
          rw [wRead_wWrite_of_ne mD _ (Or.inr hi10), hwD_scr i hi14 hi17]
          simp only [m_C]
          rw [wRead_wWrite_of_ne _ _ (Or.inr hi16), wRead_wWrite_of_ne _ _ (Or.inr hi15)]
          exact hw_scr i hi,
        fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans
          ((hrD t ht3 i).trans (by simp only [m_C, rRead_wWrite]; exact hr_m t ht3 i))⟩
      by_cases hqk : q = k
      · subst hqk
        have helem : (curList (q + 1))[q]'hq =
            liveStepSingleNode cp pts' isIns h_op (getS1Seed cp ω₁ (baseIdx + q)) (nds[q]'hk_nds) := by
          have : (curList (q + 1))[q]'hq =
              ((curList q).set q (liveStepSingleNode cp pts' isIns h_op (getS1Seed cp ω₁ (baseIdx + q)) (nds[q]'hk_nds)))[q]'(by rw [← hcur_succ_eq]; exact hq) := by
            congr 1
          rw [this, List.getElem_set_self]
        rw [helem]
        exact hnd_DN _ _ henc_mn1
      · have hq_cur : q < (curList k).length := by rw [hcur_len k]; rw [hcur_len (k + 1)] at hq; exact hq
        have helem : (curList (k + 1))[q]'hq = (curList k)[q]'hq_cur := by
          have : (curList (k + 1))[q]'hq =
              ((curList k).set k (liveStepSingleNode cp pts' isIns h_op (getS1Seed cp ω₁ (baseIdx + k)) (nds[k]'hk_nds)))[q]'(by rw [← hcur_succ_eq]; exact hq) := by
            congr 1
          rw [this, List.getElem_set_ne (Ne.symm hqk)]
        have hne_slot : slots[q]'hqs ≠ slot_k := by
          intro heq
          have hinj := List.nodup_iff_injective_getElem.mp hs_nodup
          have hf : (⟨q, hqs⟩ : Fin slots.length) = ⟨k, hk_slots⟩ := hinj heq
          exact hqk (congrArg Fin.val hf)
        rw [helem]
        exact hnd_DN _ _ (hndD_ne _ _ (hs_lt _ (List.getElem_mem hqs)) hne_slot
          (hnd_mC _ _ (hcur_enc q hq_cur hqs)))
    · refine ExecDet.skip inp hfp_k ?_ (by omega)
      refine ⟨hr10_k, ?_⟩
      set mN := H3a.wWrite m engScrTbl 10 ((k : ℤ) + 1)
      have hnd_mN : ∀ mn' s', ops.EncNode mn' s' m → ops.EncNode mn' s' mN :=
        fun mn' s' he => ops.encNode_ext mn' s' m mN he
          (fun t ht9 _ i => wRead_wWrite_of_ne m _ (Or.inl (by dsimp [engScrTbl]; omega)))
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
      have hsame : curList (k + 1) = curList k ∧
          (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx (nds.take (k + 1))).2 = rk.2 := by
        by_cases hk_nds : k < nds.length
        · have hrk2_f : rk.2 = false := by
            simp only [hk_nds, decide_true, Bool.true_and] at hskip; exact hskip
          have htake_succ : nds.take (k + 1) = nds.take k ++ [nds[k]'hk_nds] := by
            rw [List.take_add_one, List.getElem?_eq_getElem hk_nds, Option.toList_some]
          have hsnoc := liveUpdateChainList_snoc cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx
            (nds.take k) (nds[k]'hk_nds)
          dsimp only at hsnoc
          have hrk2_ne : ¬ (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx (nds.take k)).2 = true := by
            dsimp [rk] at hrk2_f; simp [hrk2_f]
          have hrk1 : liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx (nds.take (k + 1)) =
              (rk.1 ++ [nds[k]'hk_nds], false) := by
            rw [htake_succ, hsnoc, if_neg hrk2_ne]
          refine ⟨?_, by rw [hrk1, hrk2_f]⟩
          dsimp only [curList]
          rw [hrk1, List.drop_eq_getElem_cons hk_nds, List.append_assoc]; rfl
        · have hge : nds.length ≤ k := Nat.le_of_not_lt hk_nds
          have ht1 : nds.take (k + 1) = nds := List.take_of_length_le (by omega)
          have ht0 : nds.take k = nds := List.take_of_length_le hge
          have hd1 : nds.drop (k + 1) = [] := List.drop_of_length_le (by omega)
          have hd0 : nds.drop k = [] := List.drop_of_length_le hge
          dsimp only [curList, rk]
          rw [ht1, ht0, hd1, hd0]
          exact ⟨rfl, rfl⟩
      refine ⟨ops.slotsReady_ext m mN hsr_k
          (fun t ht9 _ i => wRead_wWrite_of_ne m _ (Or.inl (by dsimp [engScrTbl]; omega)))
          (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
        fun q hq hqs => by
          have hq' : q < (curList k).length := hsame.1 ▸ hq
          have helem : (curList (k + 1))[q]'hq = (curList k)[q]'hq' := by congr 1; exact hsame.1
          rw [helem]; exact hnd_mN _ _ (hcur_enc q hq' hqs),
        by rw [hsame.2]; simp only [mN]
           exact (wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr14_k,
        fun mn' s' hs' hns he0 => hnd_mN _ _ (hnd_out mn' s' hs' hns he0),
        fun t ht9 ht8 i => (wRead_wWrite_of_ne m _ (Or.inl ht8)).trans (hw_t t ht9 ht8 i),
        fun i hi => (wRead_wWrite_of_ne m _ (Or.inr (by omega))).trans (hw_scr i hi),
        fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans (hr_m t ht3 i)⟩
  · intro mF ⟨hsrF, hcurF, hr14F, hndF_out, hwF_t, hwF_scr, hrF⟩ _
    have htakeD : nds.take cp.D_max = nds := List.take_of_length_le hlen_le
    have hdropD : nds.drop cp.D_max = [] := List.drop_of_length_le hlen_le
    have hcurD : curList cp.D_max =
        (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx nds).1 := by
      simp [curList, htakeD, hdropD]
    have hres_len : (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx nds).1.length =
        nds.length :=
      liveUpdateChainList_length cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx nds
    refine ⟨hsrF, hres_len, fun q hq hqs => ?_,
      by rw [htakeD] at hr14F; exact hr14F,
      hndF_out, hwF_t,
      fun i hi => hwF_scr i (by omega),
      hrF⟩
    have hq_cur : q < (curList cp.D_max).length := hcurD ▸ hq
    have helem : (liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) baseIdx nds).1[q]'hq =
        (curList cp.D_max)[q]'hq_cur := by congr 1; exact hcurD.symm
    rw [helem]
    exact hcurF q hq_cur hqs

end UL.Proof.clm_9_1_explicit_tradeoff.CG19
