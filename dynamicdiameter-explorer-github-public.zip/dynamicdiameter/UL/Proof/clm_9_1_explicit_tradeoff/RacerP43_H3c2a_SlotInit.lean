import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Proof.lem_7_2.RacerP33_H1_RAM
import UL.Proof.clm_9_1_explicit_tradeoff.H3a_RAMCore
import UL.Proof.clm_9_1_explicit_tradeoff.H3a2_SmallBranches
import UL.Proof.clm_9_1_explicit_tradeoff.H3b1_PolyCDF
import UL.Proof.clm_9_1_explicit_tradeoff.H3b2_GaussRAM
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H1_Bridge
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H2c_RadTree
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3a_FilterPure
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3c1_SlotPure
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof_cit_hpj19_thm18
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt RandExec RandExecAt iValAt rValAt cValAt)

/-! ### 1. Syntactic Scratch-Window Preservation (`StmtScrWindow`) -/

inductive StmtScrWindow (scrW scrR : ℕ) (P_w : ℤ → Prop) (P_r : ℤ → Prop) : ArithRAMStmt → Prop
  | skip : StmtScrWindow scrW scrR P_w P_r .skip
  | writeWordLit {w : ℤ} {valE : IntExpr} :
      P_w w → StmtScrWindow scrW scrR P_w P_r (.writeWordHeap scrW (.lit w) valE)
  | writeRealLit {r : ℤ} {valE : RealExpr} :
      P_r r → StmtScrWindow scrW scrR P_w P_r (.writeRealHeap scrR (.lit r) valE)
  | writeRealAny {idxE : IntExpr} {valE : RealExpr} :
      (∀ r, P_r r) → StmtScrWindow scrW scrR P_w P_r (.writeRealHeap scrR idxE valE)
  | seq {a b : ArithRAMStmt} :
      StmtScrWindow scrW scrR P_w P_r a → StmtScrWindow scrW scrR P_w P_r b →
      StmtScrWindow scrW scrR P_w P_r (.seq a b)
  | ite {c : ArithCondExpr} {t f : ArithRAMStmt} :
      StmtScrWindow scrW scrR P_w P_r t → StmtScrWindow scrW scrR P_w P_r f →
      StmtScrWindow scrW scrR P_w P_r (.ite c t f)
  | repeatN {cnt : IntExpr} {b : ArithRAMStmt} :
      StmtScrWindow scrW scrR P_w P_r b → StmtScrWindow scrW scrR P_w P_r (.repeatN cnt b)

theorem StmtScrWindow.to_hzr {scrW scrR : ℕ} {P_w P_r : ℤ → Prop} {s : ArithRAMStmt}
    (h : StmtScrWindow scrW scrR P_w P_r s) : HeapZeroRandStmt s := by
  induction h with
  | skip => exact .skip
  | writeWordLit _ => exact .writeWordHeap _ _ _
  | writeRealLit _ => exact .writeRealHeap _ _ _
  | writeRealAny _ => exact .writeRealHeap _ _ _
  | seq _ _ iha ihb => exact .seq iha ihb
  | ite _ _ iht ihf => exact .ite iht ihf
  | repeatN _ ihb => exact .repeatN ihb

def ContScrWindow (scrW scrR : ℕ) (P_w P_r : ℤ → Prop) : ArithRAMCont → Prop
  | .stmt s => StmtScrWindow scrW scrR P_w P_r s
  | .repeatLoop _ b => StmtScrWindow scrW scrR P_w P_r b
  | .popScope _ => False

private lemma runFuel_preserves_scrWindow {d : ℕ} {inp : ArithRAMInput d}
    {scrW scrR : ℕ} {P_w P_r : ℤ → Prop} :
    ∀ (f : ℕ) (stk : List ArithRAMCont) (m₀ : ArithRAMMemory) (u₀ sp₀ : ℕ)
      (out : ArithRAMExecOutcome),
      (∀ c ∈ stk, ContScrWindow scrW scrR P_w P_r c) →
      runArithRAMFuel inp f stk
        { mem := m₀, frameDepth := 0, remainingBits := [],
          unitCost := u₀, peakCellSpace := sp₀ } = .halted out →
      (∀ w, ¬ P_w w → H3a.wRead out.mem scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, ¬ P_r r → H3a.rRead out.mem scrR r = H3a.rRead m₀ scrR r)
  | 0, [], m₀, _, _, out, _, hrun => by
      simp only [runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, ArithRAMRunStatus.halted.injEq] at hrun
      subst out
      exact ⟨fun w _ => UL.Proof_lem_7_2_RacerP33.wRead_popDepth m₀ 0 scrW w,
             fun r _ => UL.Proof_lem_7_2_RacerP33.rRead_popDepth m₀ 0 scrR r⟩
  | 0, _ :: _, _, _, _, _, _, hrun => by
      simp [runArithRAMFuel] at hrun
  | f + 1, [], m₀, _, _, out, _, hrun => by
      simp only [runArithRAMFuel, List.isEmpty_nil, ↓reduceIte, ArithRAMRunStatus.halted.injEq] at hrun
      subst out
      exact ⟨fun w _ => UL.Proof_lem_7_2_RacerP33.wRead_popDepth m₀ 0 scrW w,
             fun r _ => UL.Proof_lem_7_2_RacerP33.rRead_popDepth m₀ 0 scrR r⟩
  | f + 1, item :: tl, m₀, u₀, sp₀, out, hstk, hrun => by
      have hitem := hstk item List.mem_cons_self
      have htl : ∀ c ∈ tl, ContScrWindow scrW scrR P_w P_r c :=
        fun c hc => hstk c (List.mem_cons_of_mem _ hc)
      cases item with
      | popScope _ => cases hitem
      | repeatLoop rem body =>
          cases rem with
          | zero =>
              simp only [runArithRAMFuel] at hrun
              exact runFuel_preserves_scrWindow f tl m₀ u₀ sp₀ out htl hrun
          | succ rem' =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt body :: .repeatLoop rem' body :: tl),
                  ContScrWindow scrW scrR P_w P_r c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc1
                · exact hitem
                · rcases List.mem_cons.mp hc1 with rfl | hc2
                  · exact hitem
                  · exact htl c hc2
              exact runFuel_preserves_scrWindow f _ m₀ u₀ sp₀ out hstk' hrun
      | stmt s =>
          cases hitem with
          | skip =>
              simp only [runArithRAMFuel] at hrun
              exact runFuel_preserves_scrWindow f tl m₀ (u₀ + 1) sp₀ out htl hrun
          | @writeWordLit w₀ valE hw₀ =>
              simp only [runArithRAMFuel, evalIntExpr] at hrun
              let e2 := evalIntExpr inp.toWordView 0 m₀.words valE
              obtain ⟨hw_tl, hr_tl⟩ := runFuel_preserves_scrWindow f tl
                (H3a.wWrite m₀ scrW w₀ e2.1) (u₀ + 1 + e2.2.1 + 1) _ out htl hrun
              refine ⟨fun w hnw => (hw_tl w hnw).trans ?_, fun r hnr => (hr_tl r hnr).trans ?_⟩
              · exact wRead_wWrite_of_ne m₀ e2.1 (Or.inr (fun heq => hnw (heq ▸ hw₀)))
              · exact rRead_wWrite m₀ scrR scrW r w₀ e2.1
          | @writeRealLit r₀ valE hr₀ =>
              simp only [runArithRAMFuel, evalIntExpr] at hrun
              let e2 := evalRealExpr inp 0 m₀ valE
              obtain ⟨hw_tl, hr_tl⟩ := runFuel_preserves_scrWindow f tl
                (H3a.rWrite m₀ scrR r₀ e2.1) (u₀ + 1 + e2.2 + 1) _ out htl hrun
              refine ⟨fun w hnw => (hw_tl w hnw).trans ?_, fun r hnr => (hr_tl r hnr).trans ?_⟩
              · exact wRead_rWrite m₀ scrW scrR w r₀ e2.1
              · exact rRead_rWrite_of_ne m₀ e2.1 (Or.inr (fun heq => hnr (heq ▸ hr₀)))
          | @writeRealAny idxE valE hallR =>
              simp only [runArithRAMFuel] at hrun
              let e1 := evalIntExpr inp.toWordView 0 m₀.words idxE
              let e2 := evalRealExpr inp 0 m₀ valE
              obtain ⟨hw_tl, _⟩ := runFuel_preserves_scrWindow f tl
                (H3a.rWrite m₀ scrR e1.1 e2.1) (u₀ + e1.2.1 + e2.2 + 1) _ out htl hrun
              exact ⟨fun w hnw => (hw_tl w hnw).trans (wRead_rWrite m₀ scrW scrR w e1.1 e2.1),
                     fun r hnr => False.elim (hnr (hallR r))⟩
          | @seq a b ha hb =>
              simp only [runArithRAMFuel] at hrun
              have hstk' : ∀ c ∈ (.stmt a :: .stmt b :: tl), ContScrWindow scrW scrR P_w P_r c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc1
                · exact ha
                · rcases List.mem_cons.mp hc1 with rfl | hc2
                  · exact hb
                  · exact htl c hc2
              exact runFuel_preserves_scrWindow f _ m₀ u₀ sp₀ out hstk' hrun
          | @ite cond tB fB htB hfB =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalArithCond inp 0 m₀ cond
              have hbr : ContScrWindow scrW scrR P_w P_r (.stmt (if ec.1 then tB else fB)) := by
                dsimp [ContScrWindow]; split_ifs <;> assumption
              have hstk' : ∀ c ∈ (.stmt (if ec.1 then tB else fB) :: tl),
                  ContScrWindow scrW scrR P_w P_r c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc1
                · exact hbr
                · exact htl c hc1
              exact runFuel_preserves_scrWindow f _ m₀ (u₀ + ec.2) sp₀ out hstk' hrun
          | @repeatN cntE b hb =>
              simp only [runArithRAMFuel] at hrun
              let ec := evalIntExpr inp.toWordView 0 m₀.words cntE
              let n_it := if 0 ≤ ec.1 then ec.1.toNat else 0
              have hstk' : ∀ c ∈ (.repeatLoop n_it b :: tl), ContScrWindow scrW scrR P_w P_r c := by
                intro c hc
                rcases List.mem_cons.mp hc with rfl | hc1
                · exact hb
                · exact htl c hc1
              exact runFuel_preserves_scrWindow f _ m₀ (u₀ + ec.2.1) sp₀ out hstk' hrun

theorem execScratch_window_to_detExec {d TW BW TR BR scrW scrR : ℕ} {inp : ArithRAMInput d}
    {P_w P_r : ℤ → Prop} {s : ArithRAMStmt}
    (hsw : StmtScrWindow scrW scrR P_w P_r s)
    {m₀ : ArithRAMMemory} (hfp₀ : InFootprint TW BW TR BR m₀)
    {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hex : ExecScratch TW BW TR BR scrW scrR inp s m₀ Post C) :
    ∃ m₁ : ArithRAMMemory,
      PreservesNonScratch scrW scrR m₀ m₁ ∧
      Post m₁ ∧
      InFootprint TW BW TR BR m₁ ∧
      (∀ w, ¬ P_w w → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, ¬ P_r r → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      DetExec inp s m₀ m₁ C := by
  obtain ⟨m₁, hpr, hp, hfp₁, hdet⟩ := execScratch_to_detExec hsw.to_hzr hfp₀ hex
  obtain ⟨fuel, u₁, pk₁, _, hfuel⟩ := hdet [] 0 0 []
  have hrun0 := hfuel 0
  simp only [Nat.add_zero, runArithRAMFuel, List.isEmpty_nil, ↓reduceIte] at hrun0
  have hpop : m₁.popDepth 0 = m₁ := hfp₁.1
  rw [hpop] at hrun0
  obtain ⟨hw_out, hr_out⟩ := runFuel_preserves_scrWindow fuel [.stmt s] m₀ 0 0
    { mem := m₁, unitCost := u₁, peakCellSpace := pk₁ }
    (fun c hc => by simp at hc; subst hc; exact hsw) hrun0
  exact ⟨m₁, hpr, hp, hfp₁, hw_out, hr_out, hdet⟩

theorem sw_forLoopStmt {scrW scrR : ℕ} {P_w P_r : ℤ → Prop}
    {idx : ℤ} (hidx : P_w idx) (N : ℕ) {b : ArithRAMStmt}
    (hb : StmtScrWindow scrW scrR P_w P_r b) :
    StmtScrWindow scrW scrR P_w P_r (forLoopStmt scrW idx N b) :=
  .seq (.writeWordLit hidx) (.repeatN (.seq hb (.writeWordLit hidx)))

theorem sw_polyQuantileStmt (scrW scrR : ℕ) (wK wBase rBase rOut : ℤ) (b T p_coord : ℕ) :
    StmtScrWindow scrW scrR
      (fun w => w = wBase ∨ w = wBase + 1)
      (fun r => (rBase ≤ r ∧ r < rBase + 8) ∨ r = rOut)
      (polyQuantileStmt scrW scrR wK wBase rBase rOut b T p_coord) := by
  have hg : StmtScrWindow scrW scrR
      (fun w => w = wBase ∨ w = wBase + 1)
      (fun r => (rBase ≤ r ∧ r < rBase + 8) ∨ r = rOut)
      (gaussIntPolyStmt scrW scrR wBase (rBase + 4) (rBase + 5) (rBase + 6) (cdfDegree T b)) :=
    .seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
    (.seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
          (sw_forLoopStmt (Or.inl rfl) _
            (.seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
                  (.writeRealLit (Or.inl ⟨by omega, by omega⟩)))))
  have hcdf : StmtScrWindow scrW scrR
      (fun w => w = wBase ∨ w = wBase + 1)
      (fun r => (rBase ≤ r ∧ r < rBase + 8) ∨ r = rOut)
      (polyCDFStmt scrW scrR wBase (rBase + 2) (rBase + 4) (rBase + 5) (rBase + 6) (rBase + 7)
        (cdfDegree T b) (cPiRat (cdfPiBits T b))) :=
    .ite (.seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
           (.seq hg (.writeRealLit (Or.inl ⟨by omega, by omega⟩))))
         (.seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
           (.seq hg (.writeRealLit (Or.inl ⟨by omega, by omega⟩))))
  unfold polyQuantileStmt
  exact .ite (.writeRealLit (Or.inr rfl))
    (.seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
    (.seq (sw_forLoopStmt (Or.inl rfl) _ (.writeRealLit (Or.inl ⟨by omega, by omega⟩)))
    (.seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
    (.seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
    (.seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
    (.seq (sw_forLoopStmt (Or.inr rfl) _
            (.seq (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
              (.seq hcdf (.ite (.writeRealLit (Or.inl ⟨by omega, by omega⟩))
                               (.writeRealLit (Or.inl ⟨by omega, by omega⟩))))))
          (.writeRealLit (Or.inr rfl))))))))

theorem sw_signedSqCapTestStmt (scrW scrR tblG tblW : ℕ)
    (wCtr wDst rBase : ℤ) (offGE offWE : IntExpr) (d : ℕ) (A B_signed a₀ : ℚ) :
    StmtScrWindow scrW scrR
      (fun w => w = wCtr ∨ w = wDst)
      (fun r => rBase ≤ r ∧ r < rBase + 3)
      (signedSqCapTestStmt scrW scrR tblG tblW wCtr wDst rBase offGE offWE d A B_signed a₀) := by
  unfold signedSqCapTestStmt evalSignedSqCondStmt
  exact .seq (.writeRealLit ⟨by omega, by omega⟩)
    (.seq (.writeRealLit ⟨by omega, by omega⟩)
    (.seq (sw_forLoopStmt (Or.inl rfl) d
            (.seq (.writeRealLit ⟨by omega, by omega⟩) (.writeRealLit ⟨by omega, by omega⟩)))
    (.seq (.writeRealLit ⟨by omega, by omega⟩)
    (.seq (.writeRealLit ⟨by omega, by omega⟩)
          (.ite (.writeWordLit (Or.inr rfl)) (.writeWordLit (Or.inr rfl)))))))

theorem sw_roundQueryLatStmt (scrW scrR tblW : ℕ)
    (wBase rBase offW offOut : ℤ) (d M_lat S_lat : ℕ) :
    StmtScrWindow scrW scrR
      (fun w => wBase ≤ w ∧ w < wBase + 6)
      (fun _ => True)
      (roundQueryLatStmt scrW scrR tblW wBase rBase offW offOut d M_lat S_lat) := by
  unfold roundQueryLatStmt evalSignedSqCondStmt
  exact .seq (.writeRealLit trivial)
    (.seq (sw_forLoopStmt ⟨by omega, by omega⟩ d (.writeRealLit trivial))
          (sw_forLoopStmt ⟨by omega, by omega⟩ d
            (.seq (.writeWordLit ⟨by omega, by omega⟩)
            (.seq (.writeWordLit ⟨by omega, by omega⟩)
            (.seq (sw_forLoopStmt ⟨by omega, by omega⟩ S_lat
                    (.ite .skip
                      (.seq (.writeWordLit ⟨by omega, by omega⟩)
                      (.seq (.writeRealLit trivial)
                      (.seq (.writeRealLit trivial)
                      (.seq (.ite (.writeWordLit ⟨by omega, by omega⟩) (.writeWordLit ⟨by omega, by omega⟩))
                            (.ite (.writeWordLit ⟨by omega, by omega⟩) (.writeWordLit ⟨by omega, by omega⟩))))))))
                  (.writeRealAny (fun _ => trivial)))))))

theorem sw_shellBisectStmt (scrW scrR : ℕ) (wBase rV rDistSq wOut : ℤ) (m0 K_max S_sh : ℕ) :
    StmtScrWindow scrW scrR
      (fun w => (wBase ≤ w ∧ w < wBase + 4) ∨ w = wOut)
      (fun _ => False)
      (shellBisectStmt scrW scrR wBase rV rDistSq wOut m0 K_max S_sh) := by
  unfold shellBisectStmt
  exact .seq (.writeWordLit (Or.inl ⟨by omega, by omega⟩))
    (.seq (.writeWordLit (Or.inl ⟨by omega, by omega⟩))
    (.seq (sw_forLoopStmt (Or.inl ⟨by omega, by omega⟩) S_sh
            (.ite .skip
              (.seq (.writeWordLit (Or.inl ⟨by omega, by omega⟩))
                    (.ite (.writeWordLit (Or.inl ⟨by omega, by omega⟩))
                          (.writeWordLit (Or.inl ⟨by omega, by omega⟩))))))
          (.writeWordLit (Or.inr rfl))))

theorem sw_corrGtStmt (scrW scrR tblO tblPts : ℕ)
    (wCtr wDst rBase : ℤ) (offOE offXE offYE : IntExpr) (d : ℕ) (b : ℚ) :
    StmtScrWindow scrW scrR
      (fun w => w = wCtr ∨ w = wDst)
      (fun r => rBase ≤ r ∧ r < rBase + 3)
      (corrGtStmt scrW scrR tblO tblPts wCtr wDst rBase offOE offXE offYE d b) := by
  unfold corrGtStmt
  exact .seq (.writeRealLit ⟨by omega, by omega⟩)
    (.seq (.writeRealLit ⟨by omega, by omega⟩)
    (.seq (.writeRealLit ⟨by omega, by omega⟩)
    (.seq (sw_forLoopStmt (Or.inl rfl) d
            (.seq (.writeRealLit ⟨by omega, by omega⟩)
            (.seq (.writeRealLit ⟨by omega, by omega⟩) (.writeRealLit ⟨by omega, by omega⟩))))
          (.ite (.writeWordLit (Or.inr rfl)) (.writeWordLit (Or.inr rfl))))))

/-! ### 2. Flat Bit-Seed Bijection (`seedEquivBits`) & `RadFrameOutside` Helpers -/

def finMulEquiv (m n : ℕ) : Fin m × Fin n ≃ Fin (m * n) where
  toFun p := ⟨p.1.val * n + p.2.val, by
    calc p.1.val * n + p.2.val < p.1.val * n + n := by omega
      _ = (p.1.val + 1) * n := by ring
      _ ≤ m * n := Nat.mul_le_mul_right n p.1.isLt⟩
  invFun z :=
    have hn : 0 < n := by
      by_contra h0
      have hz0 : n = 0 := by omega
      have hz := z.isLt; simp [hz0] at hz
    (⟨z.val / n, (Nat.div_lt_iff_lt_mul hn).mpr z.isLt⟩, ⟨z.val % n, Nat.mod_lt z.val hn⟩)
  left_inv := fun ⟨i, j⟩ => by
    have hn : 0 < n := by have := j.isLt; omega
    ext <;> dsimp
    · rw [mul_comm i.val n, Nat.mul_add_div hn, Nat.div_eq_of_lt j.isLt, add_zero]
    · rw [mul_comm i.val n, Nat.mul_add_mod_self_left, Nat.mod_eq_of_lt j.isLt]
  right_inv := fun z => by
    have hn : 0 < n := by
      by_contra h0
      have hz0 : n = 0 := by omega
      have hz := z.isLt; simp [hz0] at hz
    ext; dsimp
    rw [mul_comm (z.val / n) n]
    exact Nat.div_add_mod z.val n

def seedCoordCount (R ℓ M₀ d : ℕ) : ℕ := ((R * ℓ) * M₀) * (d + 1)
def seedBitCount (R ℓ M₀ d b : ℕ) : ℕ := seedCoordCount R ℓ M₀ d * b

def capCoordIdx {R ℓ M₀ d : ℕ} (r : Fin R) (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)) : ℕ :=
  ((r.val * ℓ + s.val) * M₀ + k.val) * (d + 1) + j.val

def capCoordEquiv (R ℓ M₀ d : ℕ) :
    (ExplicitCapIdx R ℓ M₀ × Fin (d + 1)) ≃ Fin (seedCoordCount R ℓ M₀ d) :=
  let e_rlm : ExplicitCapIdx R ℓ M₀ ≃ Fin ((R * ℓ) * M₀) :=
    (Equiv.prodAssoc (Fin R) (Fin ℓ) (Fin M₀)).symm.trans
      ((Equiv.prodCongr (finMulEquiv R ℓ) (Equiv.refl (Fin M₀))).trans (finMulEquiv (R * ℓ) M₀))
  (Equiv.prodCongr e_rlm (Equiv.refl (Fin (d + 1)))).trans
    (finMulEquiv ((R * ℓ) * M₀) (d + 1))

@[simp] theorem capCoordEquiv_val {R ℓ M₀ d : ℕ}
    (r : Fin R) (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)) :
    (capCoordEquiv R ℓ M₀ d ((r, s, k), j)).val = capCoordIdx r s k j := rfl

theorem capCoordIdx_lt {R ℓ M₀ d : ℕ}
    (r : Fin R) (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)) :
    capCoordIdx r s k j < seedCoordCount R ℓ M₀ d :=
  (capCoordEquiv R ℓ M₀ d ((r, s, k), j)).isLt

def seedIdxEquiv (R ℓ M₀ d b : ℕ) :
    (ExplicitCapIdx R ℓ M₀ × Fin (d + 1) × Fin b) ≃ Fin (seedBitCount R ℓ M₀ d b) :=
  (Equiv.prodAssoc (ExplicitCapIdx R ℓ M₀) (Fin (d + 1)) (Fin b)).symm.trans
    ((Equiv.prodCongr (capCoordEquiv R ℓ M₀ d) (Equiv.refl (Fin b))).trans
      (finMulEquiv (seedCoordCount R ℓ M₀ d) b))

@[simp] theorem seedIdxEquiv_val {R ℓ M₀ d b : ℕ}
    (r : Fin R) (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)) (bitIdx : Fin b) :
    (seedIdxEquiv R ℓ M₀ d b ((r, s, k), j, bitIdx)).val =
      capCoordIdx r s k j * b + bitIdx.val := rfl

def seedEquivBits (R ℓ M₀ d b : ℕ) :
    (Fin (seedBitCount R ℓ M₀ d b) → Bool) ≃ ExplicitBitSeed R ℓ M₀ (d + 1) b :=
  Equiv.arrowCongr (seedIdxEquiv R ℓ M₀ d b).symm (Equiv.refl Bool)

@[simp] theorem seedEquivBits_apply {R ℓ M₀ d b : ℕ}
    (bits : Fin (seedBitCount R ℓ M₀ d b) → Bool)
    (r : Fin R) (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)) (bitIdx : Fin b) :
    seedEquivBits R ℓ M₀ d b bits ((r, s, k), j, bitIdx) =
      bits (seedIdxEquiv R ℓ M₀ d b ((r, s, k), j, bitIdx)) := rfl

theorem RadFrameOutside.of_preservesNonScratch {scrW scrR : ℕ}
    (tblW : ℕ) (baseW lenW : ℤ) (tblR : ℕ) (baseR lenR : ℤ)
    {m₀ m₁ : ArithRAMMemory} (hp : PreservesNonScratch scrW scrR m₀ m₁) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m₀ m₁ :=
  ⟨fun t i hs _ => hp.1 t hs i, fun t i hs _ => hp.2 t hs i⟩

theorem RadFrameOutside.mono_range {scrW scrR tblW : ℕ} {bW₁ lW₁ bW₂ lW₂ : ℤ}
    {tblR : ℕ} {bR₁ lR₁ bR₂ lR₂ : ℤ} {m₀ m₁ : ArithRAMMemory}
    (h : RadFrameOutside scrW scrR tblW bW₁ lW₁ tblR bR₁ lR₁ m₀ m₁)
    (hW : lW₁ = 0 ∨ (bW₂ ≤ bW₁ ∧ bW₁ + lW₁ ≤ bW₂ + lW₂))
    (hR : lR₁ = 0 ∨ (bR₂ ≤ bR₁ ∧ bR₁ + lR₁ ≤ bR₂ + lR₂)) :
    RadFrameOutside scrW scrR tblW bW₂ lW₂ tblR bR₂ lR₂ m₀ m₁ := by
  refine ⟨fun t i hs ho => h.1 t i hs ?_, fun t i hs ho => h.2 t i hs ?_⟩
  · rcases hW with h0 | ⟨hlo, hhi⟩
    · subst h0
      rcases le_or_gt bW₁ i with hge | hlt
      · exact Or.inr (Or.inr (by omega))
      · exact Or.inr (Or.inl hlt)
    · rcases ho with ht | hlt | hge
      · exact Or.inl ht
      · exact Or.inr (Or.inl (by omega))
      · exact Or.inr (Or.inr (by omega))
  · rcases hR with h0 | ⟨hlo, hhi⟩
    · subst h0
      rcases le_or_gt bR₁ i with hge | hlt
      · exact Or.inr (Or.inr (by omega))
      · exact Or.inr (Or.inl hlt)
    · rcases ho with ht | hlt | hge
      · exact Or.inl ht
      · exact Or.inr (Or.inl (by omega))
      · exact Or.inr (Or.inr (by omega))

theorem RadFrameOutside.wWrite_scr (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) (idx val : ℤ) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (H3a.wWrite m scrW idx val) :=
  ⟨fun _ _ hs _ => wRead_wWrite_of_ne m val (Or.inl hs),
   fun t _ _ _ => rRead_wWrite m t scrW _ idx val⟩

theorem RadFrameOutside.rWrite_scr (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) (idx : ℤ) (val : ℝ) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (H3a.rWrite m scrR idx val) :=
  ⟨fun t _ _ _ => wRead_rWrite m t scrR _ idx val,
   fun _ _ hs _ => rRead_rWrite_of_ne m val (Or.inl hs)⟩

theorem RadFrameOutside.wWrite_in (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) {idx : ℤ} (val : ℤ)
    (hlo : baseW ≤ idx) (hhi : idx < baseW + lenW) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (H3a.wWrite m tblW idx val) := by
  refine ⟨fun t i _ ho => ?_, fun t _ _ _ => rRead_wWrite m t tblW _ idx val⟩
  rcases ho with ht | h1 | h2
  · exact wRead_wWrite_of_ne m val (Or.inl ht)
  · exact wRead_wWrite_of_ne m val (Or.inr (by omega))
  · exact wRead_wWrite_of_ne m val (Or.inr (by omega))

theorem RadFrameOutside.rWrite_in (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) {idx : ℤ} (val : ℝ)
    (hlo : baseR ≤ idx) (hhi : idx < baseR + lenR) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (H3a.rWrite m tblR idx val) := by
  refine ⟨fun t _ _ _ => wRead_rWrite m t tblR _ idx val, fun t i _ ho => ?_⟩
  rcases ho with ht | h1 | h2
  · exact rRead_rWrite_of_ne m val (Or.inl ht)
  · exact rRead_rWrite_of_ne m val (Or.inr (by omega))
  · exact rRead_rWrite_of_ne m val (Or.inr (by omega))

/-! ### 3. Scratch Vector Copy/Sub & `corrGtRegStmt` (`DetExec`, 100% Scratch-Local) -/

def copyVecToScrStmt (scrW scrR tblSrc : ℕ) (wCtr wOffSrc offDst : ℤ) (N : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit wCtr) (.lit 0))
    (.repeatN (.lit (N : ℤ))
      (.seq (.writeRealHeap scrR
              (.add (.lit offDst) (.readHeap scrW (.lit wCtr)))
              (.readRealHeap tblSrc (.add (.readHeap scrW (.lit wOffSrc)) (.readHeap scrW (.lit wCtr)))))
            (.writeWordHeap scrW (.lit wCtr)
              (.add (.readHeap scrW (.lit wCtr)) (.lit 1)))))

theorem exec_copyVecToScrStmt {d TW BW TR BR scrW scrR tblSrc tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCtr wOffSrc offSrc offDst baseW baseR : ℤ) (N : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneSrc : tblSrc ≠ scrR)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (hrDst : 0 ≤ offDst ∧ offDst + (N : ℤ) ≤ (BR : ℤ))
    (hneCtrOff : wCtr ≠ wOffSrc)
    (hoffSrc : H3a.wRead m₀ scrW wOffSrc = offSrc) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (copyVecToScrStmt scrW scrR tblSrc wCtr wOffSrc offDst N) m₀ m₁ (20 + 30 * N) ∧
      InFootprint TW BW TR BR m₁ ∧
      (∀ c : ℕ, c < N → H3a.rRead m₁ scrR (offDst + (c : ℤ)) = H3a.rRead m₀ tblSrc (offSrc + (c : ℤ))) ∧
      (∀ w, w ≠ wCtr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, (r < offDst ∨ offDst + (N : ℤ) ≤ r) → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  let m_init := H3a.wWrite m₀ scrW wCtr 0
  have hd_init : DetExec inp (.writeWordHeap scrW (.lit wCtr) (.lit 0)) m₀ m_init 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wCtr) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_init : InFootprint TW BW TR BR m_init :=
    InFootprint.wWrite hfp₀ hscrW hwCtr.1 hwCtr.2
  let Inv : ℕ → ArithRAMMemory → Prop := fun i m =>
    InFootprint TW BW TR BR m ∧
    H3a.wRead m scrW wCtr = (i : ℤ) ∧
    (∀ c : ℕ, c < i → H3a.rRead m scrR (offDst + (c : ℤ)) = H3a.rRead m₀ tblSrc (offSrc + (c : ℤ))) ∧
    (∀ w, w ≠ wCtr → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
    (∀ r, (r < offDst ∨ offDst + (N : ℤ) ≤ r) → H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
    RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
  have hInv0 : Inv 0 m_init :=
    ⟨hfp_init, wRead_wWrite_self _ _ _ _, fun _ h => by omega,
     fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
     fun r _ => rRead_wWrite _ _ _ _ _ _,
     RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ _ _ _⟩
  obtain ⟨m₁, hInvN, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (N : ℤ)) _ N 5 30 Inv hInv0 rfl
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) (fun i hi m hIm => by
      rcases hIm with ⟨hfp_m, hctr_m, hcopied, hkeepW, hkeepR, hfr_m⟩
      have hoff_m : H3a.wRead m scrW wOffSrc = offSrc :=
        (hkeepW wOffSrc hneCtrOff.symm).trans hoffSrc
      have hsrc_m : H3a.rRead m tblSrc (offSrc + (i : ℤ)) = H3a.rRead m₀ tblSrc (offSrc + (i : ℤ)) :=
        hfr_m.2 tblSrc (offSrc + (i : ℤ)) hneSrc (Or.inr (by omega))
      let m' := H3a.rWrite m scrR (offDst + (i : ℤ)) (H3a.rRead m₀ tblSrc (offSrc + (i : ℤ)))
      let m'' := H3a.wWrite m' scrW wCtr ((i + 1 : ℕ) : ℤ)
      have hd1 : DetExec inp (.writeRealHeap scrR
          (.add (.lit offDst) (.readHeap scrW (.lit wCtr)))
          (.readRealHeap tblSrc (.add (.readHeap scrW (.lit wOffSrc)) (.readHeap scrW (.lit wCtr)))))
          m m' 20 := by
        refine DetExecAt.writeRealHeap 0 inp m scrR _ _
          (by change offDst + H3a.wRead m scrW wCtr = _; rw [hctr_m])
          (by change H3a.rRead m tblSrc (H3a.wRead m scrW wOffSrc + H3a.wRead m scrW wCtr) = _
              rw [hoff_m, hctr_m, hsrc_m])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit wCtr)
          (.add (.readHeap scrW (.lit wCtr)) (.lit 1))) m' m'' 10 := by
        refine DetExecAt.writeWordHeap 0 inp m' scrW (.lit wCtr) _ rfl
          (by change H3a.wRead m' scrW wCtr + 1 = _; rw [wRead_rWrite, hctr_m]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp' : InFootprint TW BW TR BR m' :=
        InFootprint.rWrite hfp_m hscrR (by omega) (by omega)
      have hfp'' : InFootprint TW BW TR BR m'' :=
        InFootprint.wWrite hfp' hscrW hwCtr.1 hwCtr.2
      refine ⟨m'', hd1.seq hd2, hfp'', wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, ?_⟩
      · intro c hc
        rw [rRead_wWrite]
        by_cases hci : c = i
        · subst hci; exact rRead_rWrite_self _ _ _ _
        · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]
          exact hcopied c (by omega)
      · intro w hw
        rw [wRead_wWrite_of_ne _ _ (Or.inr hw), wRead_rWrite]
        exact hkeepW w hw
      · intro r hr
        rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr (by omega))]
        exact hkeepR r hr
      · exact (hfr_m.trans (RadFrameOutside.rWrite_scr _ _ _ _ _ _ _ _ _ _ _)).trans
          (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ _ _ _))
  rcases hInvN with ⟨hfp₁, _, hcop₁, hkW₁, hkR₁, hfr₁⟩
  exact ⟨m₁, (hd_init.seq hd_loop).mono_cost (by omega), hfp₁, hcop₁, hkW₁, hkR₁, hfr₁⟩

def subVecToScrStmt (scrW scrR tblA tblB : ℕ) (wCtr wOffA wOffB offDst : ℤ) (d : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit wCtr) (.lit 0))
    (.repeatN (.lit (d : ℤ))
      (.seq (.writeRealHeap scrR
              (.add (.lit offDst) (.readHeap scrW (.lit wCtr)))
              (.sub (.readRealHeap tblA (.add (.readHeap scrW (.lit wOffA)) (.readHeap scrW (.lit wCtr))))
                    (.readRealHeap tblB (.add (.readHeap scrW (.lit wOffB)) (.readHeap scrW (.lit wCtr))))))
            (.writeWordHeap scrW (.lit wCtr)
              (.add (.readHeap scrW (.lit wCtr)) (.lit 1)))))

theorem exec_subVecToScrStmt {d TW BW TR BR scrW scrR tblA tblB tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCtr wOffA wOffB offA offB offDst baseW baseR : ℤ)
    (a b : EuclideanSpace ℝ (Fin d))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneA : tblA ≠ scrR) (hneB : tblB ≠ scrR)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (hrDst : 0 ≤ offDst ∧ offDst + (d : ℤ) ≤ (BR : ℤ))
    (hneCtrA : wCtr ≠ wOffA) (hneCtrB : wCtr ≠ wOffB)
    (hoffA : H3a.wRead m₀ scrW wOffA = offA)
    (hoffB : H3a.wRead m₀ scrW wOffB = offB)
    (ha : ∀ c : Fin d, H3a.rRead m₀ tblA (offA + (c.val : ℤ)) = euclideanCoord a c)
    (hb : ∀ c : Fin d, H3a.rRead m₀ tblB (offB + (c.val : ℤ)) = euclideanCoord b c) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (subVecToScrStmt scrW scrR tblA tblB wCtr wOffA wOffB offDst d) m₀ m₁ (20 + 40 * d) ∧
      InFootprint TW BW TR BR m₁ ∧
      (∀ c : Fin d, H3a.rRead m₁ scrR (offDst + (c.val : ℤ)) = euclideanCoord (a - b) c) ∧
      (∀ w, w ≠ wCtr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, (r < offDst ∨ offDst + (d : ℤ) ≤ r) → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  let m_init := H3a.wWrite m₀ scrW wCtr 0
  have hd_init : DetExec inp (.writeWordHeap scrW (.lit wCtr) (.lit 0)) m₀ m_init 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wCtr) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_init : InFootprint TW BW TR BR m_init :=
    InFootprint.wWrite hfp₀ hscrW hwCtr.1 hwCtr.2
  let Inv : ℕ → ArithRAMMemory → Prop := fun i m =>
    InFootprint TW BW TR BR m ∧
    H3a.wRead m scrW wCtr = (i : ℤ) ∧
    (∀ c : Fin d, c.val < i → H3a.rRead m scrR (offDst + (c.val : ℤ)) = euclideanCoord (a - b) c) ∧
    (∀ w, w ≠ wCtr → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
    (∀ r, (r < offDst ∨ offDst + (d : ℤ) ≤ r) → H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
    RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
  have hInv0 : Inv 0 m_init :=
    ⟨hfp_init, wRead_wWrite_self _ _ _ _, fun _ h => by omega,
     fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
     fun r _ => rRead_wWrite _ _ _ _ _ _,
     RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ _ _ _⟩
  obtain ⟨m₁, hInvN, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (d : ℤ)) _ d 5 40 Inv hInv0 rfl
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) (fun i hi m hIm => by
      rcases hIm with ⟨hfp_m, hctr_m, hcopied, hkeepW, hkeepR, hfr_m⟩
      let ci : Fin d := ⟨i, hi⟩
      have hoffA_m : H3a.wRead m scrW wOffA = offA := (hkeepW wOffA hneCtrA.symm).trans hoffA
      have hoffB_m : H3a.wRead m scrW wOffB = offB := (hkeepW wOffB hneCtrB.symm).trans hoffB
      have ha_m : H3a.rRead m tblA (offA + (i : ℤ)) = euclideanCoord a ci :=
        (hfr_m.2 tblA (offA + (i : ℤ)) hneA (Or.inr (by omega))).trans (ha ci)
      have hb_m : H3a.rRead m tblB (offB + (i : ℤ)) = euclideanCoord b ci :=
        (hfr_m.2 tblB (offB + (i : ℤ)) hneB (Or.inr (by omega))).trans (hb ci)
      have hsub_ci : euclideanCoord a ci - euclideanCoord b ci = euclideanCoord (a - b) ci := by
        simp [euclideanCoord]
      let m' := H3a.rWrite m scrR (offDst + (i : ℤ)) (euclideanCoord (a - b) ci)
      let m'' := H3a.wWrite m' scrW wCtr ((i + 1 : ℕ) : ℤ)
      have hd1 : DetExec inp (.writeRealHeap scrR
          (.add (.lit offDst) (.readHeap scrW (.lit wCtr)))
          (.sub (.readRealHeap tblA (.add (.readHeap scrW (.lit wOffA)) (.readHeap scrW (.lit wCtr))))
                (.readRealHeap tblB (.add (.readHeap scrW (.lit wOffB)) (.readHeap scrW (.lit wCtr))))))
          m m' 30 := by
        refine DetExecAt.writeRealHeap 0 inp m scrR _ _
          (by change offDst + H3a.wRead m scrW wCtr = _; rw [hctr_m])
          (by change H3a.rRead m tblA (H3a.wRead m scrW wOffA + H3a.wRead m scrW wCtr) -
                H3a.rRead m tblB (H3a.wRead m scrW wOffB + H3a.wRead m scrW wCtr) = _
              rw [hoffA_m, hoffB_m, hctr_m, ha_m, hb_m, hsub_ci])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit wCtr)
          (.add (.readHeap scrW (.lit wCtr)) (.lit 1))) m' m'' 10 := by
        refine DetExecAt.writeWordHeap 0 inp m' scrW (.lit wCtr) _ rfl
          (by change H3a.wRead m' scrW wCtr + 1 = _; rw [wRead_rWrite, hctr_m]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp' : InFootprint TW BW TR BR m' :=
        InFootprint.rWrite hfp_m hscrR (by omega) (by omega)
      have hfp'' : InFootprint TW BW TR BR m'' :=
        InFootprint.wWrite hfp' hscrW hwCtr.1 hwCtr.2
      refine ⟨m'', hd1.seq hd2, hfp'', wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, ?_⟩
      · intro c hc
        rw [rRead_wWrite]
        by_cases hci : c.val = i
        · have hce : c = ci := Fin.ext hci
          subst hce; exact rRead_rWrite_self _ _ _ _
        · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]
          exact hcopied c (by omega)
      · intro w hw
        rw [wRead_wWrite_of_ne _ _ (Or.inr hw), wRead_rWrite]
        exact hkeepW w hw
      · intro r hr
        rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr (by omega))]
        exact hkeepR r hr
      · exact (hfr_m.trans (RadFrameOutside.rWrite_scr _ _ _ _ _ _ _ _ _ _ _)).trans
          (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ _ _ _))
  rcases hInvN with ⟨hfp₁, _, hcop₁, hkW₁, hkR₁, hfr₁⟩
  exact ⟨m₁, (hd_init.seq hd_loop).mono_cost (by omega), hfp₁,
    fun c => hcop₁ c c.isLt, hkW₁, hkR₁, hfr₁⟩

def corrGtRegStmt (scrW scrR tblO tblPts : ℕ)
    (wCtr wDst rBase wOffO wOffX wOffY : ℤ) (d : ℕ) (b : ℚ) : ArithRAMStmt :=
  corrGtStmt scrW scrR tblO tblPts wCtr wDst rBase
    (.readHeap scrW (.lit wOffO))
    (.readHeap scrW (.lit wOffX))
    (.readHeap scrW (.lit wOffY)) d b

theorem exec_corrGtRegStmt {d TW BW TR BR scrW scrR tblO tblPts tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCtr wDst rBase wOffO wOffX wOffY offO offX offY baseW baseR : ℤ) (b : ℚ)
    (o x y : EuclideanSpace ℝ (Fin d)) (hx : x ≠ o) (hy : y ≠ o)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (hwDst : 0 ≤ wDst ∧ wDst < (BW : ℤ))
    (hrB : 0 ≤ rBase ∧ rBase + 3 ≤ (BR : ℤ))
    (hneO : tblO ≠ scrR) (hnePts : tblPts ≠ scrR)
    (hneCtr : wCtr ≠ wOffO ∧ wCtr ≠ wOffX ∧ wCtr ≠ wOffY)
    (hoffO : H3a.wRead m₀ scrW wOffO = offO)
    (hoffX : H3a.wRead m₀ scrW wOffX = offX)
    (hoffY : H3a.wRead m₀ scrW wOffY = offY)
    (ho : ∀ c : Fin d, H3a.rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hx_r : ∀ c : Fin d, H3a.rRead m₀ tblPts (offX + (c.val : ℤ)) = euclideanCoord x c)
    (hy_r : ∀ c : Fin d, H3a.rRead m₀ tblPts (offY + (c.val : ℤ)) = euclideanCoord y c) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (corrGtRegStmt scrW scrR tblO tblPts wCtr wDst rBase wOffO wOffX wOffY d b)
        m₀ m₁ (220 + 130 * d) ∧
      InFootprint TW BW TR BR m₁ ∧
      (H3a.wRead m₁ scrW wDst = open Classical in if (b : ℝ) < radialCorrelation o x y then 1 else 0) ∧
      (∀ w, w ≠ wCtr → w ≠ wDst → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, (r < rBase ∨ rBase + 3 ≤ r) → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁ := by
  have hmem_w : ∀ m t i, m.words.read (.heap t i) = H3a.wRead m t i := fun _ _ _ => rfl
  have hmem_r : ∀ m t i, m.reals.read (.heap t i) = H3a.rRead m t i := fun _ _ _ => rfl
  let pD : ℕ → ℝ := fun k =>
    ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k),
      (euclideanCoord o c - euclideanCoord x c) * (euclideanCoord y c - euclideanCoord o c)
  let pNx : ℕ → ℝ := fun k =>
    ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k),
      (euclideanCoord x c - euclideanCoord o c) ^ 2
  let pNy : ℕ → ℝ := fun k =>
    ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k),
      (euclideanCoord y c - euclideanCoord o c) ^ 2
  have hex : ExecScratch TW BW TR BR scrW scrR inp
      (corrGtRegStmt scrW scrR tblO tblPts wCtr wDst rBase wOffO wOffX wOffY d b) m₀
      (fun m₁ => open Classical in
        H3a.wRead m₁ scrW wDst = if (b : ℝ) < radialCorrelation o x y then 1 else 0)
      (220 + 130 * d) := by
    unfold corrGtRegStmt corrGtStmt
    refine ExecScratch.seq' (210 + 130 * d)
      (ExecScratch.rSetScr inp (.lit rBase) (.ofInt (.lit 0)) rBase 0
        hfp₀ hscrR hrB.1 (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun m => H3a.rRead m scrR rBase = 0 ∧
          H3a.wRead m scrW wOffO = offO ∧ H3a.wRead m scrW wOffX = offX ∧ H3a.wRead m scrW wOffY = offY)
        ⟨rRead_rWrite_self _ _ _ _,
         by rw [wRead_rWrite]; exact hoffO,
         by rw [wRead_rWrite]; exact hoffX,
         by rw [wRead_rWrite]; exact hoffY⟩)
      (by omega) (fun m₁ hpr₁ ⟨hd₁, ho1, hx1, hy1⟩ hfp₁ => ?_)
    refine ExecScratch.seq' (200 + 130 * d)
      (ExecScratch.rSetScr inp (.lit (rBase + 1)) (.ofInt (.lit 0)) (rBase + 1) 0
        hfp₁ hscrR (by omega) (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun m => H3a.rRead m scrR rBase = 0 ∧ H3a.rRead m scrR (rBase + 1) = 0 ∧
          H3a.wRead m scrW wOffO = offO ∧ H3a.wRead m scrW wOffX = offX ∧ H3a.wRead m scrW wOffY = offY)
        ⟨by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hd₁,
         rRead_rWrite_self _ _ _ _,
         by rw [wRead_rWrite]; exact ho1,
         by rw [wRead_rWrite]; exact hx1,
         by rw [wRead_rWrite]; exact hy1⟩)
      (by omega) (fun m₂ hpr₂ ⟨hd₂, hnx₂, ho2, hx2, hy2⟩ hfp₂ => ?_)
    refine ExecScratch.seq' (190 + 130 * d)
      (ExecScratch.rSetScr inp (.lit (rBase + 2)) (.ofInt (.lit 0)) (rBase + 2) 0
        hfp₂ hscrR (by omega) (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun m => H3a.rRead m scrR rBase = pD 0 ∧ H3a.rRead m scrR (rBase + 1) = pNx 0 ∧
              H3a.rRead m scrR (rBase + 2) = pNy 0 ∧
              H3a.wRead m scrW wOffO = offO ∧ H3a.wRead m scrW wOffX = offX ∧ H3a.wRead m scrW wOffY = offY)
        ⟨by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; simpa [pD] using hd₂,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; simpa [pNx] using hnx₂,
         by rw [rRead_rWrite_self]; simp [pNy],
         by rw [wRead_rWrite]; exact ho2,
         by rw [wRead_rWrite]; exact hx2,
         by rw [wRead_rWrite]; exact hy2⟩)
      (by omega) (fun m₃ hpr₃ ⟨hd₃, hnx₃, hny₃, ho3, hx3, hy3⟩ hfp₃ => ?_)
    have hpr₀₃ := (hpr₁.trans hpr₂).trans hpr₃
    refine ExecScratch.seq' 150
      ((ExecScratch.forLoop wCtr d _
        (Inv := fun k m => H3a.rRead m scrR rBase = pD k ∧ H3a.rRead m scrR (rBase + 1) = pNx k ∧
              H3a.rRead m scrR (rBase + 2) = pNy k ∧
              H3a.wRead m scrW wOffO = offO ∧ H3a.wRead m scrW wOffX = offX ∧ H3a.wRead m scrW wOffY = offY)
        115 hfp₃ hscrW hwCtr.1 hwCtr.2
        ⟨by rw [rRead_wWrite]; exact hd₃,
         by rw [rRead_wWrite]; exact hnx₃,
         by rw [rRead_wWrite]; exact hny₃,
         by rw [wRead_wWrite_of_ne _ _ (Or.inr hneCtr.1.symm)]; exact ho3,
         by rw [wRead_wWrite_of_ne _ _ (Or.inr hneCtr.2.1.symm)]; exact hx3,
         by rw [wRead_wWrite_of_ne _ _ (Or.inr hneCtr.2.2.symm)]; exact hy3⟩
        ?_
        (fun k m v ⟨h1, h2, h3, h4, h5, h6⟩ =>
          ⟨by rw [rRead_wWrite]; exact h1,
           by rw [rRead_wWrite]; exact h2,
           by rw [rRead_wWrite]; exact h3,
           by rw [wRead_wWrite_of_ne _ _ (Or.inr hneCtr.1.symm)]; exact h4,
           by rw [wRead_wWrite_of_ne _ _ (Or.inr hneCtr.2.1.symm)]; exact h5,
           by rw [wRead_wWrite_of_ne _ _ (Or.inr hneCtr.2.2.symm)]; exact h6⟩)).mono
        (fun _ _ h _ => h) (by omega))
      (by omega) (fun m₄ _ ⟨hd₄, hnx₄, hny₄, _, _, _⟩ hfp₄ => ?_)
    · intro k hk m hpr_m ⟨hdm, hnxm, hnym, hom, hxm, hym⟩ hctr hfp_m
      have hpr_all := hpr₀₃.trans hpr_m
      let ck : Fin d := ⟨k, hk⟩
      have hfilt_step : (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k + 1) =
          insert ck ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by
        ext c; simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, Fin.ext_iff, ck]; omega
      have hck_not : ck ∉ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k) := by
        simp [ck]
      have hD_s : pD (k + 1) = pD k + (euclideanCoord o ck - euclideanCoord x ck) *
          (euclideanCoord y ck - euclideanCoord o ck) := by
        dsimp [pD]; rw [hfilt_step, Finset.sum_insert hck_not, add_comm]
      have hNx_s : pNx (k + 1) = pNx k + (euclideanCoord x ck - euclideanCoord o ck) ^ 2 := by
        dsimp [pNx]; rw [hfilt_step, Finset.sum_insert hck_not, add_comm]
      have hNy_s : pNy (k + 1) = pNy k + (euclideanCoord y ck - euclideanCoord o ck) ^ 2 := by
        dsimp [pNy]; rw [hfilt_step, Finset.sum_insert hck_not, add_comm]
      have ho_k : H3a.rRead m tblO (offO + (k : ℤ)) = euclideanCoord o ck := by
        rw [hpr_all.2 tblO hneO]; exact ho ck
      have hx_k : H3a.rRead m tblPts (offX + (k : ℤ)) = euclideanCoord x ck := by
        rw [hpr_all.2 tblPts hnePts]; exact hx_r ck
      have hy_k : H3a.rRead m tblPts (offY + (k : ℤ)) = euclideanCoord y ck := by
        rw [hpr_all.2 tblPts hnePts]; exact hy_r ck
      refine ExecScratch.seq' 80
        (ExecScratch.rSetScr inp (.lit rBase) _ rBase (pD (k + 1))
          hfp_m hscrR hrB.1 (by omega) rfl
          (by simp only [evalRealExpr, evalIntExpr, hmem_w, hmem_r, hctr, hdm, hom, hxm, hym, ho_k, hx_k, hy_k, hD_s])
          (by dsimp [intExprOps, realExprOps]; omega)
          (Post := fun mx => H3a.wRead mx scrW wCtr = (k : ℤ) ∧ H3a.rRead mx scrR rBase = pD (k + 1) ∧
                H3a.rRead mx scrR (rBase + 1) = pNx k ∧ H3a.rRead mx scrR (rBase + 2) = pNy k ∧
                H3a.wRead mx scrW wOffO = offO ∧ H3a.wRead mx scrW wOffX = offX ∧ H3a.wRead mx scrW wOffY = offY)
          ⟨by rw [wRead_rWrite]; exact hctr, rRead_rWrite_self _ _ _ _,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hnxm,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hnym,
           by rw [wRead_rWrite]; exact hom,
           by rw [wRead_rWrite]; exact hxm,
           by rw [wRead_rWrite]; exact hym⟩)
        (by omega) (fun mx₁ hprx₁ ⟨hctrx₁, hdx₁, hnxx₁, hnyx₁, hom₁, hxm₁, hym₁⟩ hfpx₁ => ?_)
      have hpr_all₁ := hpr_all.trans hprx₁
      have ho_k₁ : H3a.rRead mx₁ tblO (offO + (k : ℤ)) = euclideanCoord o ck := by
        rw [hpr_all₁.2 tblO hneO]; exact ho ck
      have hx_k₁ : H3a.rRead mx₁ tblPts (offX + (k : ℤ)) = euclideanCoord x ck := by
        rw [hpr_all₁.2 tblPts hnePts]; exact hx_r ck
      refine ExecScratch.seq' 40
        (ExecScratch.rSetScr inp (.lit (rBase + 1)) _ (rBase + 1) (pNx (k + 1))
          hfpx₁ hscrR (by omega) (by omega) rfl
          (by simp only [evalRealExpr, evalIntExpr, hmem_w, hmem_r, hctrx₁, hnxx₁, hom₁, hxm₁, ho_k₁, hx_k₁, hNx_s, sq])
          (by dsimp [intExprOps, realExprOps]; omega)
          (Post := fun mx => H3a.wRead mx scrW wCtr = (k : ℤ) ∧ H3a.rRead mx scrR rBase = pD (k + 1) ∧
                H3a.rRead mx scrR (rBase + 1) = pNx (k + 1) ∧ H3a.rRead mx scrR (rBase + 2) = pNy k ∧
                H3a.wRead mx scrW wOffO = offO ∧ H3a.wRead mx scrW wOffX = offX ∧ H3a.wRead mx scrW wOffY = offY)
          ⟨by rw [wRead_rWrite]; exact hctrx₁,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hdx₁,
           rRead_rWrite_self _ _ _ _,
           by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hnyx₁,
           by rw [wRead_rWrite]; exact hom₁,
           by rw [wRead_rWrite]; exact hxm₁,
           by rw [wRead_rWrite]; exact hym₁⟩)
        (by omega) (fun mx₂ hprx₂ ⟨hctrx₂, hdx₂, hnxx₂, hnyx₂, hom₂, hxm₂, hym₂⟩ hfpx₂ => ?_)
      have hpr_all₂ := hpr_all₁.trans hprx₂
      have ho_k₂ : H3a.rRead mx₂ tblO (offO + (k : ℤ)) = euclideanCoord o ck := by
        rw [hpr_all₂.2 tblO hneO]; exact ho ck
      have hy_k₂ : H3a.rRead mx₂ tblPts (offY + (k : ℤ)) = euclideanCoord y ck := by
        rw [hpr_all₂.2 tblPts hnePts]; exact hy_r ck
      exact ExecScratch.rSetScr inp (.lit (rBase + 2)) _ (rBase + 2) (pNy (k + 1))
        hfpx₂ hscrR (by omega) (by omega) rfl
        (by simp only [evalRealExpr, evalIntExpr, hmem_w, hmem_r, hctrx₂, hnyx₂, hom₂, hym₂, ho_k₂, hy_k₂, hNy_s, sq])
        (by dsimp [intExprOps, realExprOps]; omega)
        ⟨by rw [wRead_rWrite]; exact hctrx₂,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hdx₂,
         by rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hnxx₂,
         rRead_rWrite_self _ _ _ _,
         by rw [wRead_rWrite]; exact hom₂,
         by rw [wRead_rWrite]; exact hxm₂,
         by rw [wRead_rWrite]; exact hym₂⟩
    · classical
      let D_xy := ∑ c : Fin d, (euclideanCoord o c - euclideanCoord x c) * (euclideanCoord y c - euclideanCoord o c)
      let Nx := ∑ c : Fin d, (euclideanCoord x c - euclideanCoord o c) ^ 2
      let Ny := ∑ c : Fin d, (euclideanCoord y c - euclideanCoord o c) ^ 2
      have hd_eq : H3a.rRead m₄ scrR rBase = D_xy := by
        rw [hd₄]; dsimp [pD, D_xy]; congr 1; ext c; simp
      have hnx_eq : H3a.rRead m₄ scrR (rBase + 1) = Nx := by
        rw [hnx₄]; dsimp [pNx, Nx]; congr 1; ext c; simp
      have hny_eq : H3a.rRead m₄ scrR (rBase + 2) = Ny := by
        rw [hny₄]; dsimp [pNy, Ny]; congr 1; ext c; simp
      have hiff := radialCorrelation_gt_iff o x y hx hy (b : ℝ)
      refine (ExecScratch.ite (C_c := 130) (C_b := 10) _ _ _
        ?_ ?_ ?_).mono (fun _ _ h _ => h) (by omega)
      · dsimp [condExprOps, realExprOps, realExprOps_ratExpr, intExprOps]; omega
      · intro hc_t
        have hgt : (b : ℝ) < radialCorrelation o x y := by
          simp only [evalArithCond, evalRealExpr, evalRealExpr_ratExpr, evalIntExpr,
            hmem_r, hd_eq, hnx_eq, hny_eq, Int.cast_zero, ← sq,
            Bool.or_eq_true, Bool.and_eq_true, decide_eq_true_eq] at hc_t
          exact hiff.mpr hc_t
        refine ExecScratch.wSetScr inp (.lit wDst) (.lit 1) wDst 1
          hfp₄ hscrW hwDst.1 hwDst.2 rfl rfl (by dsimp [intExprOps]; omega) ?_
        rw [wRead_wWrite_self, if_pos hgt]
      · intro hc_f
        have hngt : ¬ ((b : ℝ) < radialCorrelation o x y) := by
          simp only [evalArithCond, evalRealExpr, evalRealExpr_ratExpr, evalIntExpr,
            hmem_r, hd_eq, hnx_eq, hny_eq, Int.cast_zero, ← sq,
            Bool.or_eq_false_iff, Bool.and_eq_false_iff, decide_eq_false_iff_not] at hc_f
          intro hgt
          rcases hiff.mp hgt with ⟨h1, h2, h3⟩ | ⟨h1, h2 | h3⟩
          · rcases hc_f.1 with n1 | n2 | n3
            · exact n1 h1
            · exact n2 h2
            · exact n3 h3
          · rcases hc_f.2 with n1 | ⟨n2, _⟩
            · exact n1 h1
            · exact n2 h2
          · rcases hc_f.2 with n1 | ⟨_, n3⟩
            · exact n1 h1
            · exact n3 h3
        refine ExecScratch.wSetScr inp (.lit wDst) (.lit 0) wDst 0
          hfp₄ hscrW hwDst.1 hwDst.2 rfl rfl (by dsimp [intExprOps]; omega) ?_
        rw [wRead_wWrite_self, if_neg hngt]
  obtain ⟨m₁, hpr₁, hp₁, hfp₁, hkW₁, hkR₁, hd₁⟩ :=
    execScratch_window_to_detExec (sw_corrGtStmt _ _ _ _ _ _ _ _ _ _ _ _) hfp₀ hex
  exact ⟨m₁, hd₁, hfp₁, hp₁,
    fun w hw1 hw2 => hkW₁ w (fun h => h.elim hw1 hw2),
    fun r hr => hkR₁ r (by omega),
    RadFrameOutside.of_preservesNonScratch tblW baseW 0 tblR baseR 0 hpr₁⟩

/-! ### 4. `EncLiveSlot` Heap Layout, `zeroInit`, and `clear` -/

def slotWStride (R ℓ M₀ cap_u B_max : ℕ) : ℤ :=
  4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) + 5 * ((B_max * (R * cap_u) : ℕ) : ℤ)

def slotRStride (R ℓ M₀ d : ℕ) : ℤ :=
  (seedCoordCount R ℓ M₀ d : ℤ)

def slotBktOff (baseW : ℤ) (bkt : ℕ) : ℤ :=
  baseW + 4 + 2 * (bkt : ℤ)

def slotNodeOff (R ℓ M₀ : ℕ) (baseW : ℤ) (nd : ℕ) : ℤ :=
  baseW + 4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) + 5 * (nd : ℤ)

lemma slotWStride_ge_four (R ℓ M₀ cap_u B_max : ℕ) :
    4 ≤ slotWStride R ℓ M₀ cap_u B_max := by
  have h1 : (0 : ℤ) ≤ ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
  have h2 : (0 : ℤ) ≤ ((B_max * (R * cap_u) : ℕ) : ℤ) := by positivity
  unfold slotWStride; linarith

lemma slotBktOff_bounds {R ℓ M₀ cap_u B_max bkt : ℕ} (baseW : ℤ)
    (hb : bkt < R * M₀ ^ ℓ) :
    baseW + 4 ≤ slotBktOff baseW bkt ∧
    slotBktOff baseW bkt + 1 < baseW + slotWStride R ℓ M₀ cap_u B_max := by
  have hbZ : (bkt : ℤ) < ((R * M₀ ^ ℓ : ℕ) : ℤ) := by exact_mod_cast hb
  have hpZ : (0 : ℤ) ≤ ((B_max * (R * cap_u) : ℕ) : ℤ) := by positivity
  unfold slotBktOff slotWStride
  exact ⟨by omega, by linarith⟩

lemma slotNodeOff_bounds {R ℓ M₀ cap_u B_max nd : ℕ} (baseW : ℤ)
    (hnd : nd < B_max * (R * cap_u)) :
    baseW + 4 + 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) ≤ slotNodeOff R ℓ M₀ baseW nd ∧
    slotNodeOff R ℓ M₀ baseW nd + 4 < baseW + slotWStride R ℓ M₀ cap_u B_max := by
  have hndZ : (nd : ℤ) < ((B_max * (R * cap_u) : ℕ) : ℤ) := by exact_mod_cast hnd
  unfold slotNodeOff slotWStride
  exact ⟨by omega, by linarith⟩

lemma slotBkt_lt_node {R ℓ M₀ cap_u B_max bkt nd : ℕ} (baseW : ℤ)
    (hb : bkt < R * M₀ ^ ℓ) (hnd : nd < B_max * (R * cap_u)) :
    slotBktOff baseW bkt + 1 < slotNodeOff R ℓ M₀ baseW nd := by
  have hbZ : (bkt : ℤ) < ((R * M₀ ^ ℓ : ℕ) : ℤ) := by exact_mod_cast hb
  have _ := hnd
  unfold slotBktOff slotNodeOff
  linarith

lemma slotRStride_gt_coord {R ℓ M₀ d cIdx : ℕ}
    (hc : cIdx < seedCoordCount R ℓ M₀ d) :
    (cIdx : ℤ) < slotRStride R ℓ M₀ d := by
  unfold slotRStride; exact_mod_cast hc

def EncLiveSlot (tblW : ℕ) (baseW : ℤ) (tblR : ℕ) (baseR : ℤ)
    (R ℓ M₀ d cap_u B_max : ℕ) (S : LiveSlot R ℓ M₀ d) (m : ArithRAMMemory) : Prop :=
  H3a.wRead m tblW baseW = (S.ep : ℤ) ∧
  H3a.wRead m tblW (baseW + 1) = S.blkId ∧
  H3a.wRead m tblW (baseW + 2) = (S.builtCnt : ℤ) ∧
  (∀ (r : Fin R) (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)),
    H3a.rRead m tblR (baseR + (capCoordIdx r s k j : ℤ)) = euclideanCoord (S.caps (r, s, k)) j) ∧
  (∀ bkt < R * M₀ ^ ℓ,
    H3a.wRead m tblW (slotBktOff baseW bkt) = (S.hEp bkt : ℤ) ∧
    H3a.wRead m tblW (slotBktOff baseW bkt + 1) = S.hVal bkt) ∧
  (∀ nd < B_max * (R * cap_u),
    H3a.wRead m tblW (slotNodeOff R ℓ M₀ baseW nd) = (S.nEp nd : ℤ) ∧
    H3a.wRead m tblW (slotNodeOff R ℓ M₀ baseW nd + 1) = (S.nBkt nd : ℤ) ∧
    H3a.wRead m tblW (slotNodeOff R ℓ M₀ baseW nd + 2) = (S.nEid nd : ℤ) ∧
    H3a.wRead m tblW (slotNodeOff R ℓ M₀ baseW nd + 3) = S.nPrev nd ∧
    H3a.wRead m tblW (slotNodeOff R ℓ M₀ baseW nd + 4) = S.nNext nd)

theorem EncLiveSlot.mono_frame {scrW scrR tblW' tblW : ℕ} {baseW' lenW' baseW : ℤ}
    {tblR' tblR : ℕ} {baseR' lenR' baseR : ℤ} {R ℓ M₀ d cap_u B_max : ℕ}
    {S : LiveSlot R ℓ M₀ d} {m₀ m₁ : ArithRAMMemory}
    (henc : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀)
    (hfr : RadFrameOutside scrW scrR tblW' baseW' lenW' tblR' baseR' lenR' m₀ m₁)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hdisjW : tblW ≠ tblW' ∨ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ baseW' ∨ baseW' + lenW' ≤ baseW)
    (hdisjR : tblR ≠ tblR' ∨ baseR + slotRStride R ℓ M₀ d ≤ baseR' ∨ baseR' + lenR' ≤ baseR) :
    EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₁ := by
  have hkW : ∀ i : ℤ, baseW ≤ i → i < baseW + slotWStride R ℓ M₀ cap_u B_max →
      H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i := by
    intro i hlo hhi; apply hfr.1 tblW i hneW
    rcases hdisjW with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by omega))
    · exact Or.inr (Or.inr (by omega))
  have hkR : ∀ i : ℤ, baseR ≤ i → i < baseR + slotRStride R ℓ M₀ d →
      H3a.rRead m₁ tblR i = H3a.rRead m₀ tblR i := by
    intro i hlo hhi; apply hfr.2 tblR i hneR
    rcases hdisjR with ht | h1 | h2
    · exact Or.inl ht
    · exact Or.inr (Or.inl (by omega))
    · exact Or.inr (Or.inr (by omega))
  have hge4 := slotWStride_ge_four R ℓ M₀ cap_u B_max
  rcases henc with ⟨hep, hblk, hbc, hcaps, hbkt, hnd⟩
  refine ⟨(hkW baseW le_rfl (by omega)).trans hep,
          (hkW (baseW + 1) (by omega) (by omega)).trans hblk,
          (hkW (baseW + 2) (by omega) (by omega)).trans hbc,
          fun r s k j => ?_, fun b hb => ?_, fun n hn => ?_⟩
  · have hc := slotRStride_gt_coord (capCoordIdx_lt r s k j)
    exact (hkR _ (by omega) (by omega)).trans (hcaps r s k j)
  · have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hb
    rcases hbkt b hb with ⟨h1, h2⟩
    exact ⟨(hkW _ (by omega) (by omega)).trans h1, (hkW _ (by omega) (by omega)).trans h2⟩
  · have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hn
    have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
    rcases hnd n hn with ⟨h1, h2, h3, h4, h5⟩
    exact ⟨(hkW _ (by omega) (by omega)).trans h1,
           (hkW _ (by omega) (by omega)).trans h2,
           (hkW _ (by omega) (by omega)).trans h3,
           (hkW _ (by omega) (by omega)).trans h4,
           (hkW _ (by omega) (by omega)).trans h5⟩

def liveSlotZeroInitStmt (scrW tblW : ℕ) (wBaseW : ℤ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  .seq (.writeWordHeap tblW bW (.lit 1))
  (.seq (.writeWordHeap tblW (.add bW (.lit 1)) (.lit (-1)))
        (.writeWordHeap tblW (.add bW (.lit 2)) (.lit 0)))

theorem exec_liveSlotZeroInitStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW baseW baseR : ℤ) (R ℓ M₀ cap_u B_max : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htblW : tblW < TW) (hneW : tblW ≠ scrW)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hzeroW : ∀ i, baseW ≤ i → i < baseW + slotWStride R ℓ M₀ cap_u B_max → H3a.wRead m₀ tblW i = 0)
    (hzeroR : ∀ i, baseR ≤ i → i < baseR + slotRStride R ℓ M₀ d → H3a.rRead m₀ tblR i = 0) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (liveSlotZeroInitStmt scrW tblW wBaseW) m₀ m₁ 60 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (LiveSlot.zeroMem R ℓ M₀ d) m₁ ∧
      (∀ w, H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m₁ := by
  have hge4 := slotWStride_ge_four R ℓ M₀ cap_u B_max
  let m1 := H3a.wWrite m₀ tblW baseW 1
  let m2 := H3a.wWrite m1 tblW (baseW + 1) (-1)
  let m3 := H3a.wWrite m2 tblW (baseW + 2) 0
  have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wBaseW)) (.lit 1)) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW _ (.lit 1) hbW rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 1)) (.lit (-1)))
      m1 m2 20 :=
    DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit (-1))
      (by change H3a.wRead m1 scrW wBaseW + 1 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 2)) (.lit 0))
      m2 m3 20 :=
    DetExecAt.writeWordHeap 0 inp m2 tblW _ (.lit 0)
      (by change H3a.wRead m2 scrW wBaseW + 2 = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ htblW hbaseW.1 (by omega)
  have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 htblW (by omega) (by omega)
  have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 htblW (by omega) (by omega)
  have hfr : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m3 :=
    ((RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m₀ (idx := baseW) 1 le_rfl (by omega)).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m1 (idx := baseW + 1) (-1) (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m2 (idx := baseW + 2) 0 (by omega) (by omega))
  have hk_ge4 : ∀ i, baseW + 4 ≤ i → i < baseW + slotWStride R ℓ M₀ cap_u B_max →
      H3a.wRead m3 tblW i = 0 := by
    intro i hlo hhi
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    exact hzeroW i (by omega) hhi
  refine ⟨m3, hd1.seq (hd2.seq hd3), hfp3, ?_, ?_, ?_, hfr⟩
  · refine ⟨?_, ?_, wRead_wWrite_self _ _ _ _, fun r s k j => ?_, fun b hb => ?_, fun n hn => ?_⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
    · rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]
      have hc := slotRStride_gt_coord (capCoordIdx_lt r s k j)
      rw [hzeroR _ (by omega) (by omega)]
      simp [LiveSlot.zeroMem, euclideanCoord]
    · have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hb
      exact ⟨hk_ge4 _ (by omega) (by omega), hk_ge4 _ (by omega) (by omega)⟩
    · have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hn
      have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
      exact ⟨hk_ge4 _ (by omega) (by omega),
             hk_ge4 _ (by omega) (by omega),
             hk_ge4 _ (by omega) (by omega),
             hk_ge4 _ (by omega) (by omega),
             hk_ge4 _ (by omega) (by omega)⟩
  · intro w
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
  · intro _; rfl

def liveSlotClearStmt (scrW tblW : ℕ) (wBaseW : ℤ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  .seq (.writeWordHeap tblW bW (.add (.readHeap tblW bW) (.lit 1)))
  (.seq (.writeWordHeap tblW (.add bW (.lit 1)) (.lit (-1)))
        (.writeWordHeap tblW (.add bW (.lit 2)) (.lit 0)))

theorem exec_liveSlotClearStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW baseW baseR : ℤ) {R ℓ M₀ cap_u B_max : ℕ} (S : LiveSlot R ℓ M₀ d)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htblW : tblW < TW) (hneW : tblW ≠ scrW)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (henc : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (liveSlotClearStmt scrW tblW wBaseW) m₀ m₁ 80 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (S.clear (S.ep + 1)) m₁ ∧
      (∀ w, H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m₁ := by
  have hge4 := slotWStride_ge_four R ℓ M₀ cap_u B_max
  rcases henc with ⟨hep, hblk, hbc, hcaps, hbkt, hnd⟩
  let m1 := H3a.wWrite m₀ tblW baseW ((S.ep + 1 : ℕ) : ℤ)
  let m2 := H3a.wWrite m1 tblW (baseW + 1) (-1)
  let m3 := H3a.wWrite m2 tblW (baseW + 2) 0
  have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wBaseW))
      (.add (.readHeap tblW (.readHeap scrW (.lit wBaseW))) (.lit 1))) m₀ m1 30 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW _ _ hbW
      (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wBaseW) + 1 = _; rw [hbW, hep]; push_cast; ring)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 1)) (.lit (-1)))
      m1 m2 25 :=
    DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit (-1))
      (by change H3a.wRead m1 scrW wBaseW + 1 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 2)) (.lit 0))
      m2 m3 25 :=
    DetExecAt.writeWordHeap 0 inp m2 tblW _ (.lit 0)
      (by change H3a.wRead m2 scrW wBaseW + 2 = _
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
      rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ htblW hbaseW.1 (by omega)
  have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 htblW (by omega) (by omega)
  have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 htblW (by omega) (by omega)
  have hfr : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m3 :=
    ((RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m₀ (idx := baseW) ((S.ep + 1 : ℕ) : ℤ) le_rfl (by omega)).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m1 (idx := baseW + 1) (-1) (by omega) (by omega))).trans
      (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m2 (idx := baseW + 2) 0 (by omega) (by omega))
  have hk_ge4 : ∀ i, baseW + 4 ≤ i → H3a.wRead m3 tblW i = H3a.wRead m₀ tblW i := by
    intro i hlo
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  refine ⟨m3, hd1.seq (hd2.seq hd3), hfp3, ?_, ?_, ?_, hfr⟩
  · refine ⟨?_, ?_, wRead_wWrite_self _ _ _ _, fun r s k j => ?_, fun b hb => ?_, fun n hn => ?_⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
    · rw [rRead_wWrite, rRead_wWrite, rRead_wWrite]; exact hcaps r s k j
    · have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hb
      rcases hbkt b hb with ⟨h1, h2⟩
      exact ⟨(hk_ge4 _ (by omega)).trans h1, (hk_ge4 _ (by omega)).trans h2⟩
    · have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hn
      have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
      rcases hnd n hn with ⟨h1, h2, h3, h4, h5⟩
      exact ⟨(hk_ge4 _ (by omega)).trans h1,
             (hk_ge4 _ (by omega)).trans h2,
             (hk_ge4 _ (by omega)).trans h3,
             (hk_ge4 _ (by omega)).trans h4,
             (hk_ge4 _ (by omega)).trans h5⟩
  · intro w
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
  · intro _; rfl

/-! ### 5. `sampleBIntStmt` & `liveSlotInitOrSkipStmt` (`RandExec`) -/

def sampleBIntStmt (scrW : ℕ) (wK wBitTmp : ℤ) (b : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit wK) (.lit 0))
    (.repeatN (.lit (b : ℤ))
      (.seq (.randBitHeap scrW (.lit wBitTmp))
            (.writeWordHeap scrW (.lit wK)
              (.add (.mul (.lit 2) (.readHeap scrW (.lit wK)))
                    (.readHeap scrW (.lit wBitTmp))))))

private lemma bitsFnToNat_rec_eq {b : ℕ} (f : Fin b → Bool) :
    ∀ (k : ℕ) (hk : k ≤ b),
      (Nat.recOn k 0 (fun i acc =>
        if hi : i < b then 2 * acc + (if f ⟨i, hi⟩ then 1 else 0) else acc) : ℕ) =
      bitsFnToNat k (fun j : Fin k => f ⟨j.val, lt_of_lt_of_le j.isLt hk⟩)
  | 0, _ => by simp [bitsFnToNat]
  | k + 1, hk => by
      have hk_lt : k < b := by omega
      have ih := bitsFnToNat_rec_eq f k (by omega)
      change (if hi : k < b then 2 * _ + (if f ⟨k, hi⟩ then 1 else 0) else _) = _
      dsimp [Nat.recOn] at ih
      rw [dif_pos hk_lt, ih]
      rfl

theorem randExec_sampleBIntStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wK wBitTmp baseW baseR : ℤ) (b : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW)
    (hwK : 0 ≤ wK ∧ wK < (BW : ℤ))
    (hwTmp : 0 ≤ wBitTmp ∧ wBitTmp < (BW : ℤ))
    (hneKTmp : wK ≠ wBitTmp) :
    RandExec inp (sampleBIntStmt scrW wK wBitTmp b) b m₀
      (fun bits m₁ =>
        InFootprint TW BW TR BR m₁ ∧
        H3a.wRead m₁ scrW wK = ((bitsFnToFin b bits).val : ℤ) ∧
        (∀ w, w ≠ wK → w ≠ wBitTmp → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
        (∀ t i, H3a.rRead m₁ t i = H3a.rRead m₀ t i) ∧
        RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m₁)
      (20 + 25 * b) := by
  let m_init := H3a.wWrite m₀ scrW wK 0
  have hd_init : DetExec inp (.writeWordHeap scrW (.lit wK) (.lit 0)) m₀ m_init 10 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wK) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp_init : InFootprint TW BW TR BR m_init :=
    InFootprint.wWrite hfp₀ hscrW hwK.1 hwK.2
  let pfxOf : (ℕ → Fin 1 → Bool) → ℕ → ℕ := fun ch k =>
    Nat.recOn k 0 (fun i acc =>
      2 * acc + (if ch i ⟨0, Nat.zero_lt_one⟩ then 1 else 0))
  let Inv : ℕ → (ℕ → Fin 1 → Bool) → ArithRAMMemory → Prop := fun i ch m =>
    InFootprint TW BW TR BR m ∧
    H3a.wRead m scrW wK = @Nat.cast ℤ _ (pfxOf ch i) ∧
    (∀ w, w ≠ wK → w ≠ wBitTmp → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
    (∀ t idx, H3a.rRead m t idx = H3a.rRead m₀ t idx) ∧
    RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
  have hpfx_congr : ∀ {k : ℕ} {ch₁ ch₂ : ℕ → Fin 1 → Bool},
      (∀ j < k, ch₁ j = ch₂ j) → pfxOf ch₁ k = pfxOf ch₂ k := by
    intro k
    induction k with
    | zero => intro _ _ _; rfl
    | succ k ih =>
        intro ch₁ ch₂ h
        change 2 * pfxOf ch₁ k + _ = 2 * pfxOf ch₂ k + _
        rw [ih (fun j hj => h j (by omega)), h k (Nat.lt_succ_self k)]
  have hInv0 : Inv 0 (fun _ _ => false) m_init :=
    ⟨hfp_init, wRead_wWrite_self _ _ _ _,
     fun w hw1 _ => wRead_wWrite_of_ne _ _ (Or.inr hw1),
     fun _ _ => rRead_wWrite _ _ _ _ _ _,
     RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ _ _ _⟩
  have hloop : RandExec inp
      (.repeatN (.lit (b : ℤ))
        (.seq (.randBitHeap scrW (.lit wBitTmp))
              (.writeWordHeap scrW (.lit wK)
                (.add (.mul (.lit 2) (.readHeap scrW (.lit wK)))
                      (.readHeap scrW (.lit wBitTmp))))))
      (b * 1) m_init
      (fun bits1 m_b =>
        ∃ ch_b : ℕ → Fin 1 → Bool,
          Inv b ch_b m_b ∧
          ∀ r : Fin b, ch_b r.val = fun j : Fin 1 =>
            bits1 ⟨r.val * 1 + j.val, by omega⟩)
      (10 + b * 25) := by
    refine RandExecAt.repeatN_nat (chunks₀ := fun _ _ => false) (.lit (b : ℤ)) _ b 1 10 25 Inv hInv0 rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) (fun i _ ch m hIm => ?_)
    rcases hIm with ⟨hfp_m, hk_m, hkeepW, hkeepR, hfr_m⟩
    refine RandExecAt.seq_det_right
      (C₁ := 10) (C₂ := 15)
      (RandExecAt.randBitHeap 0 inp m scrW (.lit wBitTmp) rfl
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega))
      (fun f1 m1 hm1 => ?_)
    subst hm1
    let bit := f1 ⟨0, Nat.zero_lt_one⟩
    let nextVal : ℕ := 2 * pfxOf ch i + (if bit then 1 else 0)
    let m2 := H3a.wWrite (H3a.wWrite m scrW wBitTmp (if bit then 1 else 0)) scrW wK (nextVal : ℤ)
    have hd2 : DetExec inp (.writeWordHeap scrW (.lit wK)
        (.add (.mul (.lit 2) (.readHeap scrW (.lit wK))) (.readHeap scrW (.lit wBitTmp))))
        (H3a.wWrite m scrW wBitTmp (if bit then 1 else 0)) m2 15 := by
      refine DetExecAt.writeWordHeap 0 inp _ scrW (.lit wK) _ rfl
        (by
          change 2 * H3a.wRead (H3a.wWrite m scrW wBitTmp _) scrW wK +
            H3a.wRead (H3a.wWrite m scrW wBitTmp _) scrW wBitTmp = _
          rw [wRead_wWrite_of_ne _ _ (Or.inr hneKTmp), hk_m, wRead_wWrite_self]
          dsimp [nextVal, bit]
          cases f1 ⟨0, Nat.zero_lt_one⟩ <;> (push_cast; ring))
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hfp1 : InFootprint TW BW TR BR (H3a.wWrite m scrW wBitTmp (if bit then 1 else 0)) :=
      InFootprint.wWrite hfp_m hscrW hwTmp.1 hwTmp.2
    have hfp2 : InFootprint TW BW TR BR m2 :=
      InFootprint.wWrite hfp1 hscrW hwK.1 hwK.2
    have hpfx_upd : pfxOf (Function.update ch i f1) (i + 1) = nextVal := by
      change 2 * pfxOf (Function.update ch i f1) i +
        (if Function.update ch i f1 i ⟨0, Nat.zero_lt_one⟩ then 1 else 0) = nextVal
      rw [hpfx_congr (fun j hj => Function.update_of_ne (by omega) f1 ch), Function.update_self]
    refine ⟨m2, hd2, hfp2, ?_, ?_, ?_, ?_⟩
    · rw [wRead_wWrite_self, hpfx_upd]
    · intro w hw1 hw2
      rw [wRead_wWrite_of_ne _ _ (Or.inr hw1), wRead_wWrite_of_ne _ _ (Or.inr hw2)]
      exact hkeepW w hw1 hw2
    · intro t idx
      rw [rRead_wWrite, rRead_wWrite]; exact hkeepR t idx
    · exact (hfr_m.trans (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ _ _ _)).trans
        (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ _ _ _)
  have hseq := RandExecAt.seq_det_left hd_init hloop
  refine (hseq.congr_bits (Nat.mul_one b) (fun bits m₁ hpost => ?_)).mono
    (fun _ _ h => h) (by omega)
  rcases hpost with ⟨ch_b, ⟨hfp₁, hk₁, hkW₁, hkR₁, hfr₁⟩, hch⟩
  have hpfx_eq : pfxOf ch_b b = (bitsFnToFin b bits).val := by
    have hrec : ∀ k ≤ b, pfxOf ch_b k =
        Nat.recOn k 0 (fun i acc =>
          if hi : i < b then 2 * acc + (if bits ⟨i, hi⟩ then 1 else 0) else acc) := by
      intro k
      induction k with
      | zero => intro _; rfl
      | succ k ih =>
          intro hk
          have hk_lt : k < b := by omega
          change 2 * pfxOf ch_b k + (if ch_b k ⟨0, Nat.zero_lt_one⟩ then 1 else 0) =
            if hi : k < b then 2 * _ + (if bits ⟨k, hi⟩ then 1 else 0) else _
          have ih' := ih (by omega); dsimp [Nat.recOn] at ih'; rw [dif_pos hk_lt, ← ih']
          have hck : ch_b k ⟨0, Nat.zero_lt_one⟩ = bits ⟨k, hk_lt⟩ := by
            have h0 := congrFun (hch ⟨k, hk_lt⟩) ⟨0, Nat.zero_lt_one⟩
            exact h0.trans (congrArg bits (Fin.ext (by dsimp; omega)))
          rw [hck]
    rw [hrec b le_rfl, bitsFnToNat_rec_eq bits b le_rfl]
    rfl
  rw [hpfx_eq] at hk₁
  exact ⟨hfp₁, hk₁, hkW₁, hkR₁, hfr₁⟩

noncomputable def liveSlotInitOrSkipStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wDoInit wNewBlk wScrBase rScrBase : ℤ)
    (R ℓ M₀ d b T p_coord : ℕ) : ArithRAMStmt :=
  let N_cap := seedCoordCount R ℓ M₀ d
  let wCoordCtr := wScrBase
  let wK := wScrBase + 1
  let wBitTmp := wScrBase + 2
  let wQBase := wScrBase + 3
  let rQBase := rScrBase
  let rQOut := rScrBase + 8
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  let bR := IntExpr.readHeap scrW (.lit wBaseR)
  .ite (.intEq (.readHeap scrW (.lit wDoInit)) (.lit 1))
    (.seq (.writeWordHeap tblW bW (.add (.readHeap tblW bW) (.lit 1)))
    (.seq (.writeWordHeap tblW (.add bW (.lit 1)) (.readHeap scrW (.lit wNewBlk)))
    (.seq (.writeWordHeap tblW (.add bW (.lit 2)) (.lit 0))
    (.seq (.writeWordHeap scrW (.lit wCoordCtr) (.lit 0))
          (.repeatN (.lit (N_cap : ℤ))
            (.seq (sampleBIntStmt scrW wK wBitTmp b)
            (.seq (polyQuantileStmt scrW scrR wK wQBase rQBase rQOut b T p_coord)
            (.seq (.writeRealHeap tblR (.add bR (.readHeap scrW (.lit wCoordCtr)))
                    (.readRealHeap scrR (.lit rQOut)))
                  (.writeWordHeap scrW (.lit wCoordCtr)
                    (.add (.readHeap scrW (.lit wCoordCtr)) (.lit 1)))))))))))
    (.repeatN (.lit (N_cap : ℤ))
      (sampleBIntStmt scrW wK wBitTmp b))

def liveSlotInitCost (R ℓ M₀ d b T p_coord : ℕ) : ℕ :=
  150 + seedCoordCount R ℓ M₀ d *
    (300 + 50 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b))

theorem randExec_liveSlotInitOrSkipStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBaseR wDoInit wNewBlk wScrBase rScrBase baseW baseR newBlk : ℤ)
    (doInit : Bool)
    {R ℓ M₀ cap_u B_max : ℕ} (b T p_coord : ℕ)
    (S : LiveSlot R ℓ M₀ d)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hbaseR : 0 ≤ baseR ∧ baseR + slotRStride R ℓ M₀ d ≤ (BR : ℤ))
    (hwScr : 0 ≤ wScrBase ∧ wScrBase + 5 ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScrBase ∧ rScrBase + 9 ≤ (BR : ℤ))
    (hdisjBW : wBaseW < wScrBase ∨ wScrBase + 5 ≤ wBaseW)
    (hdisjBR : wBaseR < wScrBase ∨ wScrBase + 5 ≤ wBaseR)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hbR : H3a.wRead m₀ scrW wBaseR = baseR)
    (hdo : H3a.wRead m₀ scrW wDoInit = if doInit then 1 else 0)
    (hblk : H3a.wRead m₀ scrW wNewBlk = newBlk)
    (henc : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀) :
    RandExec inp
      (liveSlotInitOrSkipStmt scrW scrR tblW tblR wBaseW wBaseR wDoInit wNewBlk wScrBase rScrBase
        R ℓ M₀ d b T p_coord)
      (seedBitCount R ℓ M₀ d b) m₀
      (fun bits m₁ =>
        InFootprint TW BW TR BR m₁ ∧
        EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max
          (if doInit then S.init (S.ep + 1) newBlk T p_coord (seedEquivBits R ℓ M₀ d b bits) else S) m₁ ∧
        (∀ w, (w < wScrBase ∨ wScrBase + 5 ≤ w) → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
        (∀ r, (r < rScrBase ∨ rScrBase + 9 ≤ r) → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
        RadFrameOutside scrW scrR
          tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
          tblR baseR (slotRStride R ℓ M₀ d) m₀ m₁)
      (liveSlotInitCost R ℓ M₀ d b T p_coord) := by
  let _ := hdisjBW
  let N_cap := seedCoordCount R ℓ M₀ d
  let C_q := 200 + 25 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b)
  let C_iter := (20 + 25 * b) + C_q + 40
  have hge4 := slotWStride_ge_four R ℓ M₀ cap_u B_max
  unfold liveSlotInitOrSkipStmt
  cases doInit with
  | false =>
      have hc_f : cValAt 0 inp m₀ (.intEq (.readHeap scrW (.lit wDoInit)) (.lit 1)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m₀ scrW wDoInit = 1) = false
        rw [hdo]; decide
      let InvF : ℕ → (ℕ → Fin b → Bool) → ArithRAMMemory → Prop := fun _ _ m =>
        InFootprint TW BW TR BR m ∧
        (∀ w, (w < wScrBase ∨ wScrBase + 5 ≤ w) → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
        (∀ r, H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
        RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m
      have hInvF0 : InvF 0 (fun _ _ => false) m₀ :=
        ⟨hfp₀, fun _ _ => rfl, fun _ => rfl, RadFrameOutside.refl _ _ _ _ _ _ _ _ _⟩
      have hloopF := RandExecAt.repeatN_nat (chunks₀ := fun _ _ => false) (.lit (N_cap : ℤ))
        (sampleBIntStmt scrW (wScrBase + 1) (wScrBase + 2) b) N_cap b 10 (20 + 25 * b)
        InvF hInvF0 rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (fun i _ ch m ⟨hfp_m, hkW_m, hkR_m, hfr_m⟩ =>
          (randExec_sampleBIntStmt inp (wScrBase + 1) (wScrBase + 2) baseW baseR b
            hfp_m hscrW ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ (by omega)).mono
            (fun _ m' ⟨hfp', _, hkW', hkR', hfr'⟩ =>
              ⟨hfp',
               fun w hw => (hkW' w (by omega) (by omega)).trans (hkW_m w hw),
               fun r => (hkR' scrR r).trans (hkR_m r),
               hfr_m.trans hfr'⟩) le_rfl)
      refine (RandExecAt.ite_false (C_c := 10) hc_f
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hloopF).mono (fun _ m₁ ⟨_, ⟨hfp₁, hkW₁, hkR₁, hfr₁⟩, _⟩ => ?_) ?_
      · simp only [Bool.false_eq_true, ↓reduceIte]
        have hfr_wide : RadFrameOutside scrW scrR
            tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
            tblR baseR (slotRStride R ℓ M₀ d) m₀ m₁ :=
          hfr₁.mono_range (Or.inl rfl) (Or.inl rfl)
        have henc₁ : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₁ :=
          henc.mono_frame hfr₁ hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
        exact ⟨hfp₁, henc₁, hkW₁, fun r _ => hkR₁ r, hfr_wide⟩
      · unfold liveSlotInitCost
        have hmul : N_cap * (20 + 25 * b) ≤
            N_cap * (300 + 50 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b)) :=
          Nat.mul_le_mul_left N_cap (by omega)
        dsimp only [N_cap] at hmul ⊢; omega
  | true =>
      have hc_t : cValAt 0 inp m₀ (.intEq (.readHeap scrW (.lit wDoInit)) (.lit 1)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m₀ scrW wDoInit = 1) = true
        rw [hdo]; decide
      rcases henc with ⟨hep₀, _, _, _, hbkt₀, hnd₀⟩
      let m1 := H3a.wWrite m₀ tblW baseW ((S.ep + 1 : ℕ) : ℤ)
      let m2 := H3a.wWrite m1 tblW (baseW + 1) newBlk
      let m3 := H3a.wWrite m2 tblW (baseW + 2) 0
      let m4 := H3a.wWrite m3 scrW wScrBase 0
      have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wBaseW))
          (.add (.readHeap tblW (.readHeap scrW (.lit wBaseW))) (.lit 1))) m₀ m1 30 :=
        DetExecAt.writeWordHeap 0 inp m₀ tblW _ _ hbW
          (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wBaseW) + 1 = _; rw [hbW, hep₀]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 1))
          (.readHeap scrW (.lit wNewBlk))) m1 m2 25 :=
        DetExecAt.writeWordHeap 0 inp m1 tblW _ _
          (by change H3a.wRead m1 scrW wBaseW + 1 = _; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
          (by change H3a.wRead m1 scrW wNewBlk = _; rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hblk])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd3 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 2)) (.lit 0))
          m2 m3 25 :=
        DetExecAt.writeWordHeap 0 inp m2 tblW _ (.lit 0)
          (by change H3a.wRead m2 scrW wBaseW + 2 = _
              rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), hbW])
          rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd4 : DetExec inp (.writeWordHeap scrW (.lit wScrBase) (.lit 0)) m3 m4 10 :=
        DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wScrBase) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ htblW hbaseW.1 (by omega)
      have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 htblW (by omega) (by omega)
      have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 htblW (by omega) (by omega)
      have hfp4 : InFootprint TW BW TR BR m4 := InFootprint.wWrite hfp3 hscrW hwScr.1 (by omega)
      have hfr4 : RadFrameOutside scrW scrR
          tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
          tblR baseR (slotRStride R ℓ M₀ d) m₀ m4 :=
        (((RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m₀ (idx := baseW) ((S.ep + 1 : ℕ) : ℤ) le_rfl (by omega)).trans
          (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m1 (idx := baseW + 1) newBlk (by omega) (by omega))).trans
          (RadFrameOutside.wWrite_in _ _ _ _ _ _ _ _ m2 (idx := baseW + 2) 0 (by omega) (by omega))).trans
          (RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m3 wScrBase 0)
      let InvT : ℕ → (ℕ → Fin b → Bool) → ArithRAMMemory → Prop := fun i ch m =>
        InFootprint TW BW TR BR m ∧
        H3a.wRead m scrW wScrBase = (i : ℤ) ∧
        (∀ idx : ℕ, idx < i →
          H3a.rRead m tblR (baseR + (idx : ℤ)) =
            ((polySample1D b T p_coord (bitsFnToFin b (ch idx)) : ℚ) : ℝ)) ∧
        (∀ t idx, t ≠ scrW → H3a.wRead m t idx = H3a.wRead m4 t idx) ∧
        (∀ w, (w < wScrBase ∨ wScrBase + 5 ≤ w) → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
        (∀ r, (r < rScrBase ∨ rScrBase + 9 ≤ r) → H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
        RadFrameOutside scrW scrR
          tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
          tblR baseR (slotRStride R ℓ M₀ d) m₀ m
      have hInvT0 : InvT 0 (fun _ _ => false) m4 := by
        refine ⟨hfp4, wRead_wWrite_self _ _ _ _, fun _ h => by omega, fun _ _ _ => rfl, ?_, ?_, hfr4⟩
        · intro w hw
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
              wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
              wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
        · intro r _
          simp only [m4, m3, m2, m1, rRead_wWrite]
      let loopBodyT : ArithRAMStmt :=
        .seq (sampleBIntStmt scrW (wScrBase + 1) (wScrBase + 2) b)
        (.seq (polyQuantileStmt scrW scrR (wScrBase + 1) (wScrBase + 3) rScrBase (rScrBase + 8) b T p_coord)
        (.seq (.writeRealHeap tblR (.add (.readHeap scrW (.lit wBaseR)) (.readHeap scrW (.lit wScrBase)))
                (.readRealHeap scrR (.lit (rScrBase + 8))))
              (.writeWordHeap scrW (.lit wScrBase)
                (.add (.readHeap scrW (.lit wScrBase)) (.lit 1)))))
      have hloopT := RandExecAt.repeatN_nat (chunks₀ := fun _ _ => false) (.lit (N_cap : ℤ)) loopBodyT N_cap b 10 C_iter
        InvT hInvT0 rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (fun i hi ch m ⟨hfp_m, hctr_m, hcaps_m, hw4_m, hkW_m, hkR_m, hfr_m⟩ => by
          refine RandExecAt.seq_det_right
            (C₁ := 20 + 25 * b) (C₂ := C_q + 40)
            (randExec_sampleBIntStmt (scrR := scrR) (tblW := tblW) (tblR := tblR)
              inp (wScrBase + 1) (wScrBase + 2) baseW baseR b
              hfp_m hscrW ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ (by omega))
            (fun f_i m_s ⟨hfp_s, hk_s, hkW_s, hkR_s, hfr_s⟩ => ?_)
          let k_fin : Fin (2 ^ b) := bitsFnToFin b f_i
          have hex_q := exec_polyQuantileStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
            (scrW := scrW) (scrR := scrR) inp (wScrBase + 1) (wScrBase + 3) rScrBase (rScrBase + 8)
            b T p_coord k_fin hfp_s hscrW hscrR ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
            (Or.inl (by omega)) ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ hk_s
          obtain ⟨m_q, hpr_q, hout_q, hfp_q, hkW_q, hkR_q, hd_q⟩ :=
            execScratch_window_to_detExec
              (sw_polyQuantileStmt scrW scrR (wScrBase + 1) (wScrBase + 3) rScrBase (rScrBase + 8) b T p_coord)
              hfp_s hex_q
          have hctr_q : H3a.wRead m_q scrW wScrBase = (i : ℤ) :=
            (hkW_q wScrBase (by omega)).trans ((hkW_s wScrBase (by omega) (by omega)).trans hctr_m)
          have hbR_q : H3a.wRead m_q scrW wBaseR = baseR :=
            (hkW_q wBaseR (by rcases hdisjBR with h | h <;> omega)).trans
              ((hkW_s wBaseR (by rcases hdisjBR with h | h <;> omega)
                             (by rcases hdisjBR with h | h <;> omega)).trans
                ((hkW_m wBaseR hdisjBR).trans hbR))
          let val_i : ℝ := ((polySample1D b T p_coord k_fin : ℚ) : ℝ)
          let m_w := H3a.rWrite m_q tblR (baseR + (i : ℤ)) val_i
          let m_n := H3a.wWrite m_w scrW wScrBase ((i + 1 : ℕ) : ℤ)
          have hd_w : DetExec inp (.writeRealHeap tblR
              (.add (.readHeap scrW (.lit wBaseR)) (.readHeap scrW (.lit wScrBase)))
              (.readRealHeap scrR (.lit (rScrBase + 8)))) m_q m_w 25 :=
            DetExecAt.writeRealHeap 0 inp m_q tblR _ _
              (by change H3a.wRead m_q scrW wBaseR + H3a.wRead m_q scrW wScrBase = _; rw [hbR_q, hctr_q])
              hout_q
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps]; omega)
          have hd_n : DetExec inp (.writeWordHeap scrW (.lit wScrBase)
              (.add (.readHeap scrW (.lit wScrBase)) (.lit 1))) m_w m_n 15 :=
            DetExecAt.writeWordHeap 0 inp m_w scrW (.lit wScrBase) _ rfl
              (by change H3a.wRead m_w scrW wScrBase + 1 = _; rw [wRead_rWrite, hctr_q]; push_cast; ring)
              (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          have hi_lt_R : (i : ℤ) < slotRStride R ℓ M₀ d := slotRStride_gt_coord hi
          have hfp_w : InFootprint TW BW TR BR m_w :=
            InFootprint.rWrite hfp_q htblR (by omega) (by omega)
          have hfp_n : InFootprint TW BW TR BR m_n :=
            InFootprint.wWrite hfp_w hscrW hwScr.1 (by omega)
          have hfr_s_wide : RadFrameOutside scrW scrR
              tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
              tblR baseR (slotRStride R ℓ M₀ d) m m_s :=
            hfr_s.mono_range (Or.inl rfl) (Or.inl rfl)
          have hfr_q_wide : RadFrameOutside scrW scrR
              tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
              tblR baseR (slotRStride R ℓ M₀ d) m_s m_q :=
            RadFrameOutside.of_preservesNonScratch _ _ _ _ _ _ hpr_q
          have hfr_w : RadFrameOutside scrW scrR
              tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
              tblR baseR (slotRStride R ℓ M₀ d) m_q m_w :=
            RadFrameOutside.rWrite_in _ _ _ _ _ _ _ _ m_q (idx := baseR + (i : ℤ)) val_i
              (by omega) (by omega)
          have hfr_n : RadFrameOutside scrW scrR
              tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
              tblR baseR (slotRStride R ℓ M₀ d) m_w m_n :=
            RadFrameOutside.wWrite_scr _ _ _ _ _ _ _ _ m_w wScrBase ((i + 1 : ℕ) : ℤ)
          refine ⟨m_n, hd_q.seq (hd_w.seq hd_n), hfp_n, wRead_wWrite_self _ _ _ _, ?_, ?_, ?_, ?_,
            (((hfr_m.trans hfr_s_wide).trans hfr_q_wide).trans hfr_w).trans hfr_n⟩
          · intro idx hidx
            rw [rRead_wWrite]
            by_cases he : idx = i
            · subst he
              rw [rRead_rWrite_self, Function.update_self]
            · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega)),
                  Function.update_of_ne he,
                  hpr_q.2 tblR hneR, hkR_s tblR _]
              exact hcaps_m idx (by omega)
          · intro t idx ht
            rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_rWrite, hpr_q.1 t ht,
                hfr_s.1 t idx ht (Or.inr (by omega))]
            exact hw4_m t idx ht
          · intro w hw
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite]
            exact (hkW_q w (by omega)).trans ((hkW_s w (by omega) (by omega)).trans (hkW_m w hw))
          · intro r hr
            rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hneR.symm)]
            exact (hkR_q r (by omega)).trans ((hkR_s scrR r).trans (hkR_m r hr)))
      have hseqT := RandExecAt.seq_det_left hd1 (RandExecAt.seq_det_left hd2 (RandExecAt.seq_det_left hd3 (RandExecAt.seq_det_left hd4 hloopT)))
      refine (RandExecAt.ite_true (C_c := 10) hc_t
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hseqT).mono (fun bits m₁ ⟨ch_N, ⟨hfp₁, _, hcaps₁, hw4₁, hkW₁, hkR₁, hfr₁⟩, hch_N⟩ => ?_) ?_
      · simp only [↓reduceIte]
        have hw_tbl : ∀ i, H3a.wRead m₁ tblW i = H3a.wRead m4 tblW i := fun i => hw4₁ tblW i hneW
        have hm4_tbl : ∀ i, baseW + 4 ≤ i → H3a.wRead m4 tblW i = H3a.wRead m₀ tblW i := by
          intro i hlo
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        refine ⟨hfp₁, ⟨?_, ?_, ?_, fun r s k j => ?_, fun bkt hb => ?_, fun nd hn => ?_⟩,
          hkW₁, hkR₁, hfr₁⟩
        · rw [hw_tbl, wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
        · rw [hw_tbl, wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl
        · rw [hw_tbl, wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_self]; rfl
        · let cIdx := capCoordIdx r s k j
          have hc_lt : cIdx < N_cap := capCoordIdx_lt r s k j
          rw [hcaps₁ cIdx hc_lt]
          have hfn_eq : ch_N cIdx = fun bitIdx : Fin b =>
              seedEquivBits R ℓ M₀ d b bits ((r, s, k), j, bitIdx) := by
            funext bitIdx
            have h0 := congrFun (hch_N ⟨cIdx, hc_lt⟩) bitIdx
            dsimp only at h0
            rw [h0, seedEquivBits_apply]
            exact congrArg bits (Fin.ext rfl)
          rw [hfn_eq]
          dsimp [LiveSlot.init, polyFDisc]
          rw [UL.Proof_clm_6_1_precision_RaceV30.euclideanCoord_ratPointToEuclidean]
        · have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hb
          rcases hbkt₀ bkt hb with ⟨h1, h2⟩
          exact ⟨(hw_tbl _).trans ((hm4_tbl _ (by omega)).trans h1),
                 (hw_tbl _).trans ((hm4_tbl _ (by omega)).trans h2)⟩
        · have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hn
          have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
          rcases hnd₀ nd hn with ⟨h1, h2, h3, h4, h5⟩
          exact ⟨(hw_tbl _).trans ((hm4_tbl _ (by omega)).trans h1),
                 (hw_tbl _).trans ((hm4_tbl _ (by omega)).trans h2),
                 (hw_tbl _).trans ((hm4_tbl _ (by omega)).trans h3),
                 (hw_tbl _).trans ((hm4_tbl _ (by omega)).trans h4),
                 (hw_tbl _).trans ((hm4_tbl _ (by omega)).trans h5)⟩
      · unfold liveSlotInitCost
        have hmul : N_cap * C_iter ≤
            N_cap * (300 + 50 * b + (T + p_coord + 6) * (120 + 48 * cdfDegree T b)) :=
          Nat.mul_le_mul_left N_cap (by dsimp [C_iter, C_q]; omega)
        dsimp only [N_cap] at hmul ⊢; omega

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
