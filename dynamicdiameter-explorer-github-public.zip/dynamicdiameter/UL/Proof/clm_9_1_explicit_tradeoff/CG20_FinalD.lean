import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_FinalC
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B
import UL.Proof.clm_9_1_explicit_tradeoff.CG18_OpsInst
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.CG02_Stage3
open UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
open UL.Proof.clm_9_1_explicit_tradeoff.CG15
open UL.Proof.clm_9_1_explicit_tradeoff.CG18
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG20_Bridge

/-! ### 1. Stage-2 Cost Domination Helpers (`tickRebuildJobCost` & Outer Splice + Leaf Spawn) -/

private theorem allocFreshSlotCost_le_Q2 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) {P P2 B Q2 : ℕ}
    (hP1 : 1 ≤ P) (hB1 : 1 ≤ B) (hP2_eq : P * P = P2) (hQ2_eq : P2 * B = Q2)
    (hD : cp.D_max ≤ P) :
    allocFreshSlotCost cp ≤ 1800 * Q2 := by
  have hP_P2 : P ≤ P2 := by rw [← hP2_eq]; exact Nat.le_mul_of_pos_right P hP1
  have h1_P2 : 1 ≤ P2 := hP1.trans hP_P2
  have hD_P2 : cp.D_max ≤ P2 := hD.trans hP_P2
  have hD2 : cp.D_max * cp.D_max ≤ P2 := by
    calc cp.D_max * cp.D_max ≤ P * P := Nat.mul_le_mul hD hD
      _ = P2 := hP2_eq
  have hM : M_slots cp ≤ 13 * P2 := by
    unfold M_slots; omega
  have halloc_P2 : allocFreshSlotCost cp ≤ 1800 * P2 := by
    unfold allocFreshSlotCost; omega
  calc allocFreshSlotCost cp ≤ 1800 * P2 := halloc_P2
    _ = 1800 * (P2 * 1) := by ring
    _ ≤ 1800 * (P2 * B) := Nat.mul_le_mul_left 1800 (Nat.mul_le_mul_left P2 hB1)
    _ = 1800 * Q2 := by rw [hQ2_eq]

private theorem tickRebuild_le_Q2 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    {P P2 B Q2 : ℕ}
    (hP1 : 1 ≤ P) (hB1 : 1 ≤ B) (hP2_eq : P * P = P2) (hQ2_eq : P2 * B = Q2)
    (hD : cp.D_max ≤ P) (hBsc : cp.B_scan ≤ P)
    (hopen : ops.C_open ≤ B) (hins : ops.C_ins ≤ B)
    (hhpj : ops.C_hpj ≤ B) (hread : ops.C_read ≤ B) :
    tickRebuildJobCost ops ≤ 3300 * Q2 := by
  have hP_P2 : P ≤ P2 := by rw [← hP2_eq]; exact Nat.le_mul_of_pos_right P hP1
  have h1_P2 : 1 ≤ P2 := hP1.trans hP_P2
  have hB_Q2 : B ≤ Q2 := by rw [← hQ2_eq]; exact Nat.le_mul_of_pos_left B h1_P2
  have h1_Q2 : 1 ≤ Q2 := hB1.trans hB_Q2
  have hPB_Q2 : P * B ≤ Q2 := by rw [← hQ2_eq]; exact Nat.mul_le_mul_right B hP_P2
  have halloc := allocFreshSlotCost_le_Q2 cp hP1 hB1 hP2_eq hQ2_eq hD
  have hcopy_sc : cp.B_scan * (2 * ops.C_read + 260) ≤ 262 * Q2 := by
    have h1 : 2 * ops.C_read + 260 ≤ 262 * B := by omega
    calc cp.B_scan * (2 * ops.C_read + 260) ≤ P * (262 * B) := Nat.mul_le_mul hBsc h1
      _ = 262 * (P * B) := by ring
      _ ≤ 262 * Q2 := Nat.mul_le_mul_left 262 hPB_Q2
  have hcopy : tickJobCopyCost ops ≤ 2600 * Q2 := by
    unfold tickJobCopyCost; omega
  have hbuild_sc : cp.B_scan * (ops.C_ins + 180) ≤ 181 * Q2 := by
    have h1 : ops.C_ins + 180 ≤ 181 * B := by omega
    calc cp.B_scan * (ops.C_ins + 180) ≤ P * (181 * B) := Nat.mul_le_mul hBsc h1
      _ = 181 * (P * B) := by ring
      _ ≤ 181 * Q2 := Nat.mul_le_mul_left 181 hPB_Q2
  have hbuild : tickJobBuildCost ops ≤ 600 * Q2 := by
    unfold tickJobBuildCost; omega
  unfold tickRebuildJobCost; omega

private theorem stage2_outer_le_Q3 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    {C_s2 P P2 B Q2 Q3 : ℕ}
    (hP1 : 1 ≤ P) (hB1 : 1 ≤ B)
    (hP2_eq : P * P = P2) (hQ2_eq : P2 * B = Q2) (hQ3_eq : P * Q2 = Q3)
    (hD : cp.D_max ≤ P) (hBsc : cp.B_scan ≤ P)
    (hopen : ops.C_open ≤ B) (hins : ops.C_ins ≤ B)
    (hhpj : ops.C_hpj ≤ B) (hread : ops.C_read ≤ B)
    (hCs2 : C_s2 ≤
      2000 + allocFreshSlotCost cp + 4 * ops.C_read + ops.C_hpj + ops.C_open +
        (cp.B_scan + 1) * (ops.C_ins + 2 * ops.C_read + 400) +
        cp.D_max * (tickRebuildJobCost ops + 2000 + 4 * ops.C_read +
          cp.B_scan * (2 * ops.C_read + 400) + cp.D_max * 200 +
          allocFreshSlotCost cp + ops.C_hpj + ops.C_open)) :
    C_s2 ≤ 15000 * Q3 := by
  have hP_P2 : P ≤ P2 := by rw [← hP2_eq]; exact Nat.le_mul_of_pos_right P hP1
  have h1_P2 : 1 ≤ P2 := hP1.trans hP_P2
  have hB_Q2 : B ≤ Q2 := by rw [← hQ2_eq]; exact Nat.le_mul_of_pos_left B h1_P2
  have h1_Q2 : 1 ≤ Q2 := hB1.trans hB_Q2
  have hPB_Q2 : P * B ≤ Q2 := by rw [← hQ2_eq]; exact Nat.mul_le_mul_right B hP_P2
  have hQ2_Q3 : Q2 ≤ Q3 := by rw [← hQ3_eq]; exact Nat.le_mul_of_pos_left Q2 hP1
  have h1_Q3 : 1 ≤ Q3 := h1_Q2.trans hQ2_Q3
  have hB_Q3 : B ≤ Q3 := hB_Q2.trans hQ2_Q3
  have htick := tickRebuild_le_Q2 ops hP1 hB1 hP2_eq hQ2_eq hD hBsc hopen hins hhpj hread
  have halloc := allocFreshSlotCost_le_Q2 cp hP1 hB1 hP2_eq hQ2_eq hD
  have hlsp_sc : (cp.B_scan + 1) * (ops.C_ins + 2 * ops.C_read + 400) ≤ 806 * Q2 := by
    have h0 : cp.B_scan + 1 ≤ 2 * P := by omega
    have h1 : ops.C_ins + 2 * ops.C_read + 400 ≤ 403 * B := by omega
    calc (cp.B_scan + 1) * (ops.C_ins + 2 * ops.C_read + 400)
        ≤ (2 * P) * (403 * B) := Nat.mul_le_mul h0 h1
      _ = 806 * (P * B) := by ring
      _ ≤ 806 * Q2 := Nat.mul_le_mul_left 806 hPB_Q2
  have hsc : cp.B_scan * (2 * ops.C_read + 400) ≤ 402 * Q2 := by
    have h1 : 2 * ops.C_read + 400 ≤ 402 * B := by omega
    calc cp.B_scan * (2 * ops.C_read + 400) ≤ P * (402 * B) := Nat.mul_le_mul hBsc h1
      _ = 402 * (P * B) := by ring
      _ ≤ 402 * Q2 := Nat.mul_le_mul_left 402 hPB_Q2
  have hd200 : cp.D_max * 200 ≤ 200 * Q2 := by
    calc cp.D_max * 200 ≤ P * 200 := Nat.mul_le_mul_right 200 hD
      _ ≤ P2 * 200 := Nat.mul_le_mul_right 200 hP_P2
      _ = 200 * (P2 * 1) := by ring
      _ ≤ 200 * (P2 * B) := Nat.mul_le_mul_left 200 (Nat.mul_le_mul_left P2 hB1)
      _ = 200 * Q2 := by rw [hQ2_eq]
  have hstep :
      tickRebuildJobCost ops + 2000 + 4 * ops.C_read +
        cp.B_scan * (2 * ops.C_read + 400) + cp.D_max * 200 +
        allocFreshSlotCost cp + ops.C_hpj + ops.C_open ≤ 7800 * Q2 := by
    omega
  have hdloop : cp.D_max * (tickRebuildJobCost ops + 2000 + 4 * ops.C_read +
      cp.B_scan * (2 * ops.C_read + 400) + cp.D_max * 200 +
      allocFreshSlotCost cp + ops.C_hpj + ops.C_open) ≤ 7800 * Q3 := by
    calc cp.D_max * _ ≤ P * (7800 * Q2) := Nat.mul_le_mul hD hstep
      _ = 7800 * (P * Q2) := by ring
      _ = 7800 * Q3 := by rw [hQ3_eq]
  omega

theorem tickRebuildJobCost_le_master {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    {C_op k_op : ℕ} (hCop : 1 ≤ C_op)
    (ops : NodeAndHPJRAMOps inst.cp)
    (hopen : ops.C_open ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hins : ops.C_ins ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hhpj : ops.C_hpj ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hread : ops.C_read ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp) :
    tickRebuildJobCost ops ≤
      (3300 * C_op) * (masterPolyParamNat inst) ^ (k_op + 2) * masterWorkFactorNat inst.cp := by
  let P := masterPolyParamNat inst
  let W := masterWorkFactorNat inst.cp
  let B := C_op * P ^ k_op * W
  have hP1 : 1 ≤ P := by change 1 ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hW1 : 1 ≤ W := by change 1 ≤ masterWorkFactorNat inst.cp; unfold masterWorkFactorNat; omega
  have hB1 : 1 ≤ B := Nat.mul_pos (Nat.mul_pos hCop (Nat.one_le_pow k_op P hP1)) hW1
  have hD : inst.cp.D_max ≤ P := by
    change _ ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hBsc : inst.cp.B_scan ≤ P := by
    change _ ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hc := tickRebuild_le_Q2 ops hP1 hB1 (P2 := P * P) (Q2 := (P * P) * B) rfl rfl
    hD hBsc hopen hins hhpj hread
  calc tickRebuildJobCost ops ≤ 3300 * ((P * P) * B) := hc
    _ = (3300 * C_op) * P ^ (k_op + 2) * W := by
        dsimp only [B]; rw [pow_add, sq]; ring

theorem C_stage2_outer_le_master {c σ : ℝ} {csp : CurveStaticParams c σ}
    {d n t : ℕ} {δ : ℝ} (inst : ConcreteChainInst csp d n t δ)
    {C_op k_op C_s2 : ℕ} (hCop : 1 ≤ C_op)
    (ops : NodeAndHPJRAMOps inst.cp)
    (hopen : ops.C_open ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hins : ops.C_ins ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hhpj : ops.C_hpj ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hread : ops.C_read ≤ C_op * (masterPolyParamNat inst) ^ k_op * masterWorkFactorNat inst.cp)
    (hCs2 : C_s2 ≤
      2000 + allocFreshSlotCost inst.cp + 4 * ops.C_read + ops.C_hpj + ops.C_open +
        (inst.cp.B_scan + 1) * (ops.C_ins + 2 * ops.C_read + 400) +
        inst.cp.D_max * (tickRebuildJobCost ops + 2000 + 4 * ops.C_read +
          inst.cp.B_scan * (2 * ops.C_read + 400) + inst.cp.D_max * 200 +
          allocFreshSlotCost inst.cp + ops.C_hpj + ops.C_open)) :
    C_s2 ≤
      (15000 * C_op) * (masterPolyParamNat inst) ^ (k_op + 3) * masterWorkFactorNat inst.cp := by
  let P := masterPolyParamNat inst
  let W := masterWorkFactorNat inst.cp
  let B := C_op * P ^ k_op * W
  have hP1 : 1 ≤ P := by change 1 ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hW1 : 1 ≤ W := by change 1 ≤ masterWorkFactorNat inst.cp; unfold masterWorkFactorNat; omega
  have hB1 : 1 ≤ B := Nat.mul_pos (Nat.mul_pos hCop (Nat.one_le_pow k_op P hP1)) hW1
  have hD : inst.cp.D_max ≤ P := by
    change _ ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hBsc : inst.cp.B_scan ≤ P := by
    change _ ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hc := stage2_outer_le_Q3 ops hP1 hB1 (P2 := P * P) (Q2 := (P * P) * B)
    (Q3 := P * ((P * P) * B)) rfl rfl rfl hD hBsc hopen hins hhpj hread hCs2
  calc C_s2 ≤ 15000 * (P * ((P * P) * B)) := hc
    _ = (15000 * C_op) * P ^ (k_op + 3) * W := by
        dsimp only [B]; rw [pow_add]; ring

/-! ### 2. Turnkey Top-Level Bridge Wiring `CG18_OpsInst` + Stages 1, 3, 4 into `S_clm_9_1_explicit_tradeoff` -/

/-- Complete proof of `S_clm_9_1_explicit_tradeoff` given ONLY a uniform `Stage2RAMOnly` constructor
on `CG18.nodeAndHPJRAMOps inst.cp` with polynomial work bound `(C_s2, k_s2)`. -/
theorem prove_clm_9_1_from_stage2
    (h_lem_5_1 : S_lem_5_1)
    (h_clm_5_1_mc_baseline : S_clm_5_1_mc_baseline)
    (h_lem_6_2 : S_lem_6_2)
    (h_clm_6_1_adaptive : S_clm_6_1_adaptive)
    (h_clm_6_1_precision : S_clm_6_1_precision)
    (h_clm_7_3_global_approx : S_clm_7_3_global_approx)
    (h_lem_9_1 : S_lem_9_1)
    (C_s2 k_s2 : ℕ)
    (mkStage2 :
      ∀ {c σ : ℝ} {csp : CurveStaticParams c σ} {d n t : ℕ} {δ : ℝ}
        (hd : 1 ≤ d) (hn : 2 ≤ n) (ht : 1 ≤ t) (hδ0 : 0 < δ) (hδ1 : δ < 1 / 2)
        (inst : ConcreteChainInst csp d n t δ),
        Nonempty { s2 : Stage2RAMOnly (nodeAndHPJRAMOps inst.cp) //
          s2.C2 ≤ C_s2 * (masterPolyParamNat inst) ^ k_s2 * masterWorkFactorNat inst.cp }) :
    S_clm_9_1_explicit_tradeoff := by
  refine prove_clm_9_1_from_ram_builder h_lem_5_1 h_clm_5_1_mc_baseline h_lem_6_2
    h_clm_6_1_adaptive h_clm_6_1_precision h_clm_7_3_global_approx h_lem_9_1 ?_
  intro c σ csp
  let K : ℕ := max 15 k_s2
  let C₀ : ℕ := 1601 * C_node_work + 3000 + C_s2
  refine ⟨C₀, K, C_node_space, 13, ?_⟩
  intro d n t δ hd hn ht hδ0 hδ1 _hMn _hMt
  let inst := mkConcreteChainInst csp d n t δ hd hn ht hδ0 hδ1
  let P := masterPolyParamNat inst
  let W := masterWorkFactorNat inst.cp
  let S := masterSpaceFactorNat inst.cp
  let ops := nodeAndHPJRAMOps inst.cp
  let mops := maxRadRAMOp inst.cp
  obtain ⟨⟨s2, hs2_cost⟩⟩ := mkStage2 hd hn ht hδ0 hδ1 inst
  let ram := mkStepChainRAMSpec_fromStage2 h_lem_5_1 h_clm_7_3_global_approx
    hd inst.he1 inst.hh0 inst.hh1 ops mops s2
  have hP1 : 1 ≤ P := by change 1 ≤ masterPolyParamNat inst; unfold masterPolyParamNat; omega
  have hCW1 : 1 ≤ C_node_work := by unfold C_node_work; omega
  obtain ⟨hOpen, hIns, hDel, hBump, hBall, hHpj, hRead, _, _, hReadEq, _, hS4, hSp⟩ :=
    nodeAndHPJRAMOps_master_bounds inst
  have hC1 : C_stage1 ops ≤ (1600 * C_node_work) * P ^ 15 * W :=
    C_stage1_le_master inst hCW1 ops hIns hDel hBump hBall hRead
  have hC3 : C_stage3 ops ≤ 3000 * P ^ 2 * W :=
    C_stage3_le_master_of_read370 inst ops hReadEq
  have h15K : P ^ 15 ≤ P ^ K := Nat.pow_le_pow_right hP1 (Nat.le_max_left 15 k_s2)
  have hksK : P ^ k_s2 ≤ P ^ K := Nat.pow_le_pow_right hP1 (Nat.le_max_right 15 k_s2)
  have h2K : P ^ 2 ≤ P ^ K :=
    Nat.pow_le_pow_right hP1 ((by decide : 2 ≤ 15).trans (Nat.le_max_left 15 k_s2))
  have h13K : P ^ 13 ≤ P ^ K :=
    Nat.pow_le_pow_right hP1 ((by decide : 13 ≤ 15).trans (Nat.le_max_left 15 k_s2))
  have hC1_K : C_stage1 ops ≤ (1600 * C_node_work) * P ^ K * W :=
    hC1.trans (Nat.mul_le_mul_right W (Nat.mul_le_mul_left _ h15K))
  have hC2_K : s2.C2 ≤ C_s2 * P ^ K * W :=
    hs2_cost.trans (Nat.mul_le_mul_right W (Nat.mul_le_mul_left _ hksK))
  have hC3_K : C_stage3 ops ≤ 3000 * P ^ K * W :=
    hC3.trans (Nat.mul_le_mul_right W (Nat.mul_le_mul_left _ h2K))
  have hC4_K : stepStage4Cost ops mops ≤ C_node_work * P ^ K * W :=
    hS4.trans (Nat.mul_le_mul_right W (Nat.mul_le_mul_left _ h13K))
  have hdet_eq : ram.detCost = C_stage1 ops + s2.C2 + C_stage3 ops + stepStage4Cost ops mops := rfl
  have hinit_eq : ram.initCost = 1 := rfl
  have hsp_eq : ram.TW * ram.BW + ram.TR * ram.BR = ops.TW * ops.BW + ops.TR * ops.BR := rfl
  refine ⟨⟨ram, ?_, ?_, ?_⟩⟩
  · rw [hinit_eq]; omega
  · rw [hdet_eq]
    calc C_stage1 ops + s2.C2 + C_stage3 ops + stepStage4Cost ops mops
        ≤ (1600 * C_node_work) * P ^ K * W + C_s2 * P ^ K * W +
            3000 * P ^ K * W + C_node_work * P ^ K * W :=
          Nat.add_le_add (Nat.add_le_add (Nat.add_le_add hC1_K hC2_K) hC3_K) hC4_K
      _ = C₀ * P ^ K * W := by dsimp only [C₀]; ring
  · rw [hsp_eq]; exact hSp

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
