import Mathlib
import UL.Stmt.clm_9_1_explicit_tradeoff
import UL.Stmt.clm_6_1_adaptive
import UL.Stmt.clm_6_1_precision
import UL.Proof.clm_9_1_explicit_tradeoff.H1_Algebra
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.H2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H1

/-! ### 1. Combinatorial & probability helpers for Conjunct (2) -/

theorem uniform_real_preimage_equiv {α β : Type*}
    [Fintype α] [Nonempty α] [MeasurableSpace α] [DiscreteMeasurableSpace α]
    [Fintype β] [Nonempty β] [MeasurableSpace β] [DiscreteMeasurableSpace β]
    (e : α ≃ β) (S : Set β) :
    ((PMF.uniformOfFintype α).toMeasure).real (e ⁻¹' S) =
      ((PMF.uniformOfFintype β).toMeasure).real S := by
  classical
  simp only [MeasureTheory.Measure.real]
  congr 1
  rw [PMF.toMeasure_apply_fintype, PMF.toMeasure_apply_fintype]
  have hcard : Fintype.card α = Fintype.card β := Fintype.card_congr e
  refine Equiv.sum_comp e (fun b => S.indicator (PMF.uniformOfFintype β) b) |>.symm.trans ?_ |> Eq.symm
  refine Finset.sum_congr rfl (fun a _ => ?_)
  by_cases ha : e a ∈ S
  · simp [Set.indicator_of_mem, ha, PMF.uniformOfFintype_apply, hcard]
  · simp [Set.indicator, ha]

open Classical in
theorem storedReprSpace_eq_explicitIndexSpace
    {ι : Type} {D R ℓ M₀ : ℕ}
    (F : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d : ℝ) (cap_u : ℕ) (gen : SearchGeneration ι D) :
    let storedBuckets : Fin R → (Fin ℓ → Fin M₀) → Finset ι := fun r tup =>
      gen.P₀.filter (fun i => tup ∈ clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i)
    let nonemptyBucketEntries : ℕ :=
      ∑ r : Fin R,
        ∑ tup ∈ Finset.univ.filter (fun tup' : Fin ℓ → Fin M₀ => (storedBuckets r tup').Nonempty),
          (storedBuckets r tup).card * ℓ
    R * ℓ * M₀ * D + nonemptyBucketEntries =
      clm91ExplicitIndexSpace F τ_d cap_u gen := by
  intro storedBuckets nonemptyBucketEntries
  unfold clm91ExplicitIndexSpace
  congr 1
  have hper_r : ∀ r : Fin R,
      (∑ tup ∈ Finset.univ.filter (fun tup' : Fin ℓ → Fin M₀ => (storedBuckets r tup').Nonempty),
        (storedBuckets r tup).card * ℓ) =
      ∑ i ∈ gen.P₀, (clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i).card * ℓ := by
    intro r
    have hdrop_filter :
        (∑ tup ∈ Finset.univ.filter (fun tup' : Fin ℓ → Fin M₀ => (storedBuckets r tup').Nonempty),
          (storedBuckets r tup).card * ℓ) =
        ∑ tup : Fin ℓ → Fin M₀, (storedBuckets r tup).card * ℓ := by
      refine Finset.sum_subset (Finset.subset_univ _) (fun tup _ hnot => ?_)
      simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.not_nonempty_iff_eq_empty] at hnot
      simp [hnot]
    rw [hdrop_filter, ← Finset.sum_mul, ← Finset.sum_mul]
    congr 1
    have hcard_sum :
        (∑ tup : Fin ℓ → Fin M₀, (storedBuckets r tup).card) =
        ∑ tup : Fin ℓ → Fin M₀, ∑ i ∈ gen.P₀,
          if tup ∈ clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i then 1 else 0 := by
      refine Finset.sum_congr rfl (fun tup _ => ?_)
      dsimp only [storedBuckets]
      rw [Finset.card_filter]
    rw [hcard_sum, Finset.sum_comm]
    refine Finset.sum_congr rfl (fun i _ => ?_)
    have h1 :
        (∑ tup : Fin ℓ → Fin M₀,
          if tup ∈ clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i then (1 : ℕ) else 0) =
        (Finset.univ.filter (fun tup => tup ∈ clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i)).card := by
      rw [Finset.card_filter]
    rw [h1]
    congr 1
    ext tup
    simp
  calc
    nonemptyBucketEntries
        = ∑ r : Fin R, ∑ i ∈ gen.P₀,
            (clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i).card * ℓ :=
          Finset.sum_congr rfl (fun r _ => hper_r r)
    _ = ∑ i ∈ gen.P₀, ∑ r : Fin R,
            (clm91ExplicitStoredTuples F τ_d cap_u gen.pts r i).card * ℓ :=
          Finset.sum_comm

private theorem list_mem_of_findSome_eq_some {α β : Type*} {xs : List α} {f : α → Option β} {y : β}
    (h : xs.findSome? f = some y) : ∃ x ∈ xs, f x = some y := by
  induction xs with
  | nil => simp at h
  | cons a tl ih =>
    simp only [List.findSome?_cons] at h
    cases ha : f a with
    | some b =>
      rw [ha] at h
      simp only [Option.some.injEq] at h
      exact ⟨a, List.mem_cons_self, by rw [ha, h]⟩
    | none =>
      rw [ha] at h
      obtain ⟨x, hx, hfx⟩ := ih h
      exact ⟨x, List.mem_cons_of_mem _ hx, hfx⟩

open Classical in
theorem cappedQuery_some_mem_storedBuckets
    {ι : Type} [DecidableEq ι] {D R ℓ M₀ : ℕ}
    (F : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin D))
    (τ_d τ_q : ℝ) (cap_u cap_q : ℕ)
    (gen : SearchGeneration ι D) (P : Finset ι) (qry : SearchQuery ι D)
    {i : ι}
    (hans : clm91ExplicitCappedQuery F τ_d τ_q cap_u cap_q gen P qry = some i) :
    ∃ (r : Fin R) (tup : Fin ℓ → Fin M₀),
      i ∈ gen.P₀.filter (fun j => tup ∈ clm91ExplicitStoredTuples F τ_d cap_u gen.pts r j) := by
  unfold clm91ExplicitCappedQuery at hans
  obtain ⟨r, _, hr⟩ := list_mem_of_findSome_eq_some hans
  have hmem_take : i ∈ ((
      ((Fintype.piFinset (fun s : Fin ℓ => clm91ExplicitQueryBaseSet F τ_q qry.z r s)).toList.take cap_q).flatMap
        (fun tup => ((gen.P₀ ∩ P).filter (fun j =>
          tup ∈ clm91ExplicitStoredTuples F τ_d cap_u gen.pts r j)).toList)).take (cap_q + 1)) :=
    List.mem_of_find?_eq_some hr
  have hmem_flat := List.mem_of_mem_take hmem_take
  rw [List.mem_flatMap] at hmem_flat
  obtain ⟨tup, _, hi_list⟩ := hmem_flat
  rw [Finset.mem_toList, Finset.mem_filter, Finset.mem_inter] at hi_list
  exact ⟨r, tup, Finset.mem_filter.mpr ⟨hi_list.1.1, hi_list.2⟩⟩

theorem nat_rpow_le_of_pos_exps (m : ℕ) {a b : ℝ} (ha : 0 < a) (hb : 0 < b) (hab : a ≤ b) :
    (m : ℝ) ^ a ≤ (m : ℝ) ^ b := by
  cases m with
  | zero =>
    simp [Real.zero_rpow ha.ne', Real.zero_rpow hb.ne']
  | succ k =>
    exact Real.rpow_le_rpow_of_exponent_le (by exact_mod_cast Nat.succ_pos k) hab

/-! ### 2. Proof of Conjunct (2) (`(2a)` + `(2b)`) -/

theorem prove_conjunct_2
    (h_clm_6_1_adaptive : S_clm_6_1_adaptive)
    (h_clm_6_1_precision : S_clm_6_1_precision)
    {c : ℝ} (hc_gt : 1 < c) (hc_lt : c < Real.sqrt 2) :
    ∀ (ℓ : ℕ), 16 / rho_c c ≤ (ℓ : ℝ) →
      ∀ (h_min : ℝ), 0 < h_min → h_min ≤ g_c c →
        (∃ (C_net : ℝ) (C_amp : ℝ → ℝ) (roundProg : ArithRAMStmt),
          0 < C_net ∧
          (∀ (p_succ : ℝ), 0 < p_succ → p_succ ≤ 1 → 0 < C_amp p_succ) ∧
          ∀ (d : ℕ), 1 ≤ d →
          ∀ (a b e : ℚ) (g_γ : ℝ),
            (0 : ℝ) ≤ (b : ℝ) → (b : ℝ) < (a : ℝ) → (a : ℝ) ≤ 1 →
            0 < g_γ → g_γ ≤ (a : ℝ) - (1 + g_γ) * (b : ℝ) →
            0 < e → (e : ℝ) ≤ g_γ / 16 →
            let h : ℝ := g_γ - 11 * (e : ℝ)
            h_min ≤ h → h ≤ g_c c →
            let mesh : ℚ := e / (8 * (Nat.ceil (Real.sqrt (d : ℝ)) : ℚ))
            ∃ (net : Finset (EuclideanSpace ℝ (Fin d)))
              (roundLat : EuclideanSpace ℝ (Fin d) → (Fin d → ℤ)),
              let roundVec : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
                fun z => ratPointToEuclidean (fun coord => (roundLat z coord : ℚ) * mesh)
              let roundDir : EuclideanSpace ℝ (Fin d) → EuclideanSpace ℝ (Fin d) :=
                fun z => ‖roundVec z‖⁻¹ • roundVec z
              net.Nonempty ∧
              (∀ z_hat ∈ net, IsUnitVec z_hat) ∧
              Real.log (net.card : ℝ) ≤ C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) ∧
              (∀ z : EuclideanSpace ℝ (Fin d), IsUnitVec z →
                roundLat z ≠ 0 ∧
                roundDir z ∈ net ∧
                IsUnitVec (roundDir z) ∧
                ‖roundDir z - z‖ ≤ (e : ℝ) / 8 ∧
                let inp_round : ArithRAMInput d :=
                  { intParams := [e.num, (e.den : ℤ)]
                    activeHandles := ∅
                    activeCoords := fun _ => 0
                    extraReals := List.ofFn (fun coord : Fin d => euclideanCoord z coord) }
                ∃ out_r : ArithRAMExecOutcome,
                  runArithRAMWithBits roundProg inp_round ArithRAMMemory.empty [] = some out_r ∧
                  (∀ coord : Fin d, out_r.mem.words.read (.heap 0 (coord.val : ℤ)) = roundLat z coord) ∧
                  (out_r.unitCost : ℝ) ≤ C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) ∧
                  (out_r.peakCellSpace : ℝ) ≤ C_net * (d : ℝ)) ∧
              (∀ (p_succ : ℝ), 0 < p_succ → p_succ ≤ 1 →
                ∀ (m : ℕ) (ε₀ : ℝ), 1 ≤ m → 0 < ε₀ → ε₀ < 1 / 2 →
                  ∃ R : ℕ,
                    1 ≤ R ∧
                    (R : ℝ) ≤ C_amp p_succ * (Real.log ((m : ℝ) / ε₀) + (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ))) ∧
                    (1 - p_succ) ^ R * (net.card : ℝ) * (m : ℝ) ≤ ε₀)) ∧
        (∀ (C_net' : ℝ), 0 ≤ C_net' →
          ∃ (P_bp : ℕ → ℕ → ℝ),
            IsBoundedByPoly2 P_bp ∧
            ∀ (d : ℕ), 1 ≤ d →
            ∀ (ι : Type) [DecidableEq ι] (gen : SearchGeneration ι (d + 1)),
              h_min ≤ gen.h → gen.h ≤ g_c c →
              ∀ (x e ε₀ : ℝ),
                gen.h ≤ x → x ≤ 1 →
                0 < e → e ≤ 1 →
                0 < ε₀ → ε₀ < 1 →
                ∀ (Q_net : Finset (EuclideanSpace ℝ (Fin (d + 1)))),
                  (∀ z ∈ Q_net, IsUnitVec z) →
                  (Q_net.card : ℝ) ≤ Real.exp (C_net' * (d : ℝ) * Real.log (2 * (d : ℝ) / e)) →
                  let m : ℕ := gen.m
                  let u : ℝ := u_search gen.h x
                  let q : ℝ := q_search gen.h x
                  let L_log : ℕ := Nat.ceil (Real.log (2 * (m : ℝ) / ε₀) + Real.log (2 / e))
                  let P_val : ℝ := P_bp d L_log
                  ∃ (R M₀ b B_prec cap_u cap_q : ℕ) (τ_d τ_q : ℚ)
                    (sampleCoord : (Fin b → Bool) → ℚ),
                    let N_bits : ℕ := R * ℓ * M₀ * (d + 1) * b
                    ∃ (equiv : (Fin N_bits → Bool) ≃ clm91ExplicitBitSeed R ℓ M₀ (d + 1) b)
                      (idx : CappedBirthPoolIndex (Fin N_bits → Bool) ι (d + 1) (Finset ι))
                      (pointBuildWork : (Fin N_bits → Bool) → ι → ℕ)
                      (storedBuckets : (Fin N_bits → Bool) → Fin R → (Fin ℓ → Fin M₀) → Finset ι)
                      (E_good : Set (Fin N_bits → Bool)),
                      1 ≤ R ∧ 1 ≤ M₀ ∧ 1 ≤ b ∧ 1 ≤ B_prec ∧ 1 ≤ N_bits ∧
                      (b : ℝ) ≤ P_val ∧
                      (B_prec : ℝ) ≤ P_val ∧
                      RatCoordBitBounded B_prec τ_d ∧
                      RatCoordBitBounded B_prec τ_q ∧
                      (∀ bits : Fin b → Bool, RatCoordBitBounded B_prec (sampleCoord bits)) ∧
                      ((R * ℓ * M₀ : ℕ) : ℝ) ≤ (m : ℝ) ^ (rho_c c / 8) * P_val ∧
                      (cap_u : ℝ) ≤ (m : ℝ) ^ u * P_val ∧
                      (cap_q : ℝ) ≤ (m : ℝ) ^ q * P_val ∧
                      idx.gen = gen ∧
                      1 - ε₀ ≤ ((PMF.uniformOfFintype (Fin N_bits → Bool)).toMeasure).real E_good ∧
                      (∀ ω : Fin N_bits → Bool,
                        let F_disc : clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
                          fun capIdx => ratPointToEuclidean (fun j =>
                            sampleCoord (fun bitIdx => equiv ω (capIdx, j, bitIdx)))
                        let nonemptyBucketEntries : ℕ :=
                          open Classical in
                          ∑ r : Fin R,
                            ∑ tup ∈ Finset.univ.filter
                                (fun (tup' : Fin ℓ → Fin M₀) => (storedBuckets ω r tup').Nonempty),
                              (storedBuckets ω r tup).card * ℓ
                        let storedReprSpace : ℕ := R * ℓ * M₀ * (d + 1) + nonemptyBucketEntries
                        (∀ (r : Fin R) (tup : Fin ℓ → Fin M₀),
                          storedBuckets ω r tup =
                            open Classical in
                            gen.P₀.filter (fun i =>
                              tup ∈ clm91ExplicitStoredTuples F_disc (τ_d : ℝ) cap_u gen.pts r i)) ∧
                        (∀ i : ι,
                          pointBuildWork ω i =
                            clm91ExplicitPointDataWork F_disc (τ_d : ℝ) cap_u gen.pts i) ∧
                        storedReprSpace =
                          clm91ExplicitIndexSpace F_disc (τ_d : ℝ) cap_u gen ∧
                        idx.IsValidState ω gen.P₀ (idx.initState ω) ∧
                        idx.buildWork ω = ∑ i ∈ gen.P₀, pointBuildWork ω i ∧
                        (∀ i ∈ gen.P₀,
                          (pointBuildWork ω i : ℝ) ≤ ((m : ℝ) ^ u + (m : ℝ) ^ (rho_c c / 8)) * P_val) ∧
                        (storedReprSpace : ℝ) ≤ ((m : ℝ) ^ (1 + u) + (m : ℝ) ^ (rho_c c / 8)) * P_val ∧
                        idx.buildPeakSpace ω ≤ storedReprSpace ∧
                        (∀ (P : Finset ι) (st : Finset ι) (i : ι),
                          gen.IsSurvivingSubset P → idx.IsValidState ω P st → i ∈ P →
                            let dOut := idx.delete ω P st i
                            idx.IsValidState ω (P.erase i) dOut.nextState ∧
                            dOut.work =
                              clm91ExplicitPointDataWork F_disc (τ_d : ℝ) cap_u gen.pts i ∧
                            (dOut.work : ℝ) ≤ ((m : ℝ) ^ u + (m : ℝ) ^ (rho_c c / 8)) * P_val ∧
                            dOut.peakSpace ≤ storedReprSpace) ∧
                        (∀ (P : Finset ι) (st : Finset ι) (qry : SearchQuery ι (d + 1)),
                          gen.IsSurvivingSubset P → idx.IsValidState ω P st →
                            let qOut := idx.runQuery ω P st qry
                            qOut.answer =
                              clm91ExplicitCappedQuery F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P qry ∧
                            qOut.work =
                              clm91ExplicitQueryWork F_disc (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P qry ∧
                            qry.IsValidAnswer P qOut.answer ∧
                            (∀ i : ι, qOut.answer = some i →
                              ∃ (r : Fin R) (tup : Fin ℓ → Fin M₀), i ∈ storedBuckets ω r tup) ∧
                            (qOut.work : ℝ) ≤ ((m : ℝ) ^ q + (m : ℝ) ^ (rho_c c / 8)) * P_val ∧
                            qOut.peakSpace ≤ storedReprSpace ∧
                            (ω ∈ E_good → qry.z ∈ Q_net → gen.IsCompatible P qry →
                              gen.IsCorrectAnswer P qry qOut.answer)))) := by
  intro ℓ hℓ h_min hh_min hh_le
  have hg1 : g_c c < 1 := (g_c_bounds hc_gt hc_lt).2
  have hrho0 : 0 < rho_c c := (rho_c_bounds hc_gt hc_lt).1
  have hℓ1 : 1 ≤ ℓ := (ell_pos_and_ge_one hc_gt hc_lt hℓ).1
  constructor
  · -- Part (2a): Implicit direction net & amplification
    obtain ⟨C_net, _, _, _, _, roundProg, _, _, _, _, hC_net_pos, _, _, _, _, h61a⟩ :=
      h_clm_6_1_adaptive h_min (g_c c) hh_min hh_le hg1 ℓ hℓ1
    let C_amp : ℝ → ℝ := fun p_succ => 2 + max 1 C_net / p_succ
    refine ⟨C_net, C_amp, roundProg, hC_net_pos, ?_, ?_⟩
    · intro p_succ hp0 _hp1
      dsimp only [C_amp]
      positivity
    · intro d hd a b e g_γ hb0 hba ha1 hg_γ0 hg_γ_ab he0 he_g h hh_lo hh_hi mesh
      obtain ⟨net, roundLat, _A, _B, hnet_ne, hnet_mem, hnet_log, hround, _⟩ :=
        h61a d hd a b g_γ e hb0 hba ha1 hg_γ0 hg_γ_ab he0 he_g hh_lo hh_hi
      refine ⟨net, roundLat, hnet_ne, fun z_hat hz => (hnet_mem z_hat hz).1, hnet_log, ?_, ?_⟩
      · intro z hz
        obtain ⟨hlat_ne, hmem_net, hdist, hout_r⟩ := hround z hz
        exact ⟨hlat_ne, hmem_net, (hnet_mem _ hmem_net).1, hdist, hout_r⟩
      · intro p_succ hp0 hp1 m ε₀ hm1 hε₀0 hε₀1
        have hm_ge1 : (1 : ℝ) ≤ (m : ℝ) := by exact_mod_cast hm1
        have hm_pos : (0 : ℝ) < (m : ℝ) := by linarith
        have hd_ge1 : (1 : ℝ) ≤ (d : ℝ) := by exact_mod_cast hd
        have he_pos : (0 : ℝ) < (e : ℝ) := by exact_mod_cast he0
        have hg_γ_le1 : g_γ ≤ 1 := by
          have hnonneg : 0 ≤ (1 + g_γ) * (b : ℝ) := mul_nonneg (by linarith) hb0
          linarith
        have he_le16 : (e : ℝ) ≤ 1 / 16 := by linarith
        have hde_gt1 : 1 < (d : ℝ) / (e : ℝ) := by
          rw [one_lt_div he_pos]
          linarith
        have hlog_de_pos : 0 < Real.log ((d : ℝ) / (e : ℝ)) := Real.log_pos hde_gt1
        have hme_gt2 : 2 < (m : ℝ) / ε₀ := by
          rw [lt_div_iff₀ hε₀0]
          linarith
        have hlog_me_gt : 1 / 2 < Real.log ((m : ℝ) / ε₀) := by
          have hlt : Real.log 2 < Real.log ((m : ℝ) / ε₀) :=
            Real.log_lt_log (by norm_num) hme_gt2
          linarith [Real.log_two_gt_d9]
        let L_req : ℝ :=
          (Real.log ((m : ℝ) / ε₀) + C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ))) / p_succ
        have hL_req_pos : 0 < L_req := by
          dsimp only [L_req]
          positivity
        let R : ℕ := max 1 (Nat.ceil L_req)
        refine ⟨R, le_max_left _ _, ?_, ?_⟩
        · have hceil_lt : (Nat.ceil L_req : ℝ) < L_req + 1 := Nat.ceil_lt_add_one hL_req_pos.le
          have hR_le : (R : ℝ) ≤ L_req + 1 := by
            dsimp only [R]
            rw [Nat.cast_max, Nat.cast_one]
            exact max_le (by linarith) hceil_lt.le
          let S_log : ℝ := Real.log ((m : ℝ) / ε₀) + (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ))
          have h1_le_2S : 1 ≤ 2 * S_log := by
            dsimp only [S_log]
            have hdlog_nn : 0 ≤ (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) := by positivity
            linarith
          have hnum_le :
              Real.log ((m : ℝ) / ε₀) + C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) ≤
                max 1 C_net * S_log := by
            dsimp only [S_log]
            have h1 : Real.log ((m : ℝ) / ε₀) ≤ max 1 C_net * Real.log ((m : ℝ) / ε₀) :=
              le_mul_of_one_le_left (by linarith) (le_max_left _ _)
            have h2 : C_net * ((d : ℝ) * Real.log ((d : ℝ) / (e : ℝ))) ≤
                max 1 C_net * ((d : ℝ) * Real.log ((d : ℝ) / (e : ℝ))) :=
              mul_le_mul_of_nonneg_right (le_max_right _ _) (by positivity)
            linarith
          have hL_le : L_req ≤ (max 1 C_net / p_succ) * S_log := by
            dsimp only [L_req]
            rw [div_mul_eq_mul_div]
            exact div_le_div_of_nonneg_right hnum_le hp0.le
          calc
            (R : ℝ) ≤ L_req + 1 := hR_le
            _ ≤ (max 1 C_net / p_succ) * S_log + 2 * S_log := add_le_add hL_le h1_le_2S
            _ = C_amp p_succ * S_log := by dsimp only [C_amp]; ring
        · have hR_ge_L : L_req ≤ (R : ℝ) :=
            (Nat.le_ceil L_req).trans (by exact_mod_cast le_max_right 1 (Nat.ceil L_req))
          have hRp_ge :
              Real.log ((m : ℝ) / ε₀) + C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) ≤
                (R : ℝ) * p_succ := by
            have h1 := mul_le_mul_of_nonneg_right hR_ge_L hp0.le
            dsimp only [L_req] at h1
            rwa [div_mul_cancel₀ _ hp0.ne'] at h1
          have h1mp_le : 1 - p_succ ≤ Real.exp (-p_succ) := by
            linarith [Real.add_one_le_exp (-p_succ)]
          have hpow_le : (1 - p_succ) ^ R ≤ Real.exp (-(R : ℝ) * p_succ) := by
            calc
              (1 - p_succ) ^ R ≤ (Real.exp (-p_succ)) ^ R :=
                    pow_le_pow_left₀ (by linarith) h1mp_le R
              _ = Real.exp (-(R : ℝ) * p_succ) := by
                    rw [← Real.exp_nat_mul]
                    congr 1
                    ring
          have hcard_pos : (0 : ℝ) < (net.card : ℝ) := by exact_mod_cast hnet_ne.card_pos
          have hcard_le : (net.card : ℝ) ≤
              Real.exp (C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ))) := by
            rw [← Real.exp_log hcard_pos]
            exact Real.exp_le_exp.mpr hnet_log
          have hm_exp : (m : ℝ) = Real.exp (Real.log (m : ℝ)) := (Real.exp_log hm_pos).symm
          have hlog_div : Real.log ((m : ℝ) / ε₀) = Real.log (m : ℝ) - Real.log ε₀ :=
            Real.log_div hm_pos.ne' hε₀0.ne'
          calc
            (1 - p_succ) ^ R * (net.card : ℝ) * (m : ℝ)
                ≤ Real.exp (-(R : ℝ) * p_succ) *
                    Real.exp (C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ))) *
                    Real.exp (Real.log (m : ℝ)) := by
                  have hm12 :
                      (1 - p_succ) ^ R * (net.card : ℝ) ≤
                        Real.exp (-(R : ℝ) * p_succ) *
                          Real.exp (C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ))) :=
                    mul_le_mul hpow_le hcard_le (Nat.cast_nonneg _) (Real.exp_pos _).le
                  rw [← hm_exp]
                  exact mul_le_mul_of_nonneg_right hm12 hm_pos.le
            _ = Real.exp (-(R : ℝ) * p_succ +
                  C_net * (d : ℝ) * Real.log ((d : ℝ) / (e : ℝ)) + Real.log (m : ℝ)) := by
                  rw [← Real.exp_add, ← Real.exp_add]
            _ ≤ Real.exp (Real.log ε₀) := by
                  apply Real.exp_le_exp.mpr
                  linarith
            _ = ε₀ := Real.exp_log hε₀0
  · -- Part (2b): Capped explicit birth-pool index from `clm_6_1_precision`
    intro C_net' hC_net'
    obtain ⟨poly_prec, poly_cap, hpoly_prec, hpoly_cap, h61p⟩ :=
      (h_clm_6_1_precision h_min (g_c c) hh_min hh_le hg1 ℓ hℓ1).2.2.2 C_net' hC_net'
    let P_bp : ℕ → ℕ → ℝ := fun d L_log =>
      1 + max 0 (poly_prec d L_log) + max 0 (poly_cap d L_log)
    have hP_bp_poly : IsBoundedByPoly2 P_bp :=
      isBoundedByPoly2_add
        (isBoundedByPoly2_add (isBoundedByPoly2_const (by norm_num))
          (isBoundedByPoly2_max_zero hpoly_prec))
        (isBoundedByPoly2_max_zero hpoly_cap)
    refine ⟨P_bp, hP_bp_poly, ?_⟩
    intro d hd ι _ gen hh_lo hh_hi x e ε₀ hhx hx1 he0 he1 hε₀0 hε₀1 Q_net hQ_unit hQ_card
    intro m u q L_log P_val
    have hQ_list_unit : ∀ z ∈ Q_net.toList, IsUnitVec z :=
      fun z hz => hQ_unit z (Finset.mem_toList.mp hz)
    have hQ_list_len :
        (Q_net.toList.length : ℝ) ≤
          Real.exp (C_net' * (d : ℝ) * Real.log (2 * (d : ℝ) / e)) := by
      rw [Finset.length_toList]; exact hQ_card
    obtain ⟨R, M₀, cap_u, cap_q, b, B_prec, _t_ideal, τ_d, τ_q, sampleCoord,
        hR1, hM₀1, hb1, hB1, _ht1, hb_le, hB_le, hτd_b, hτq_b, hsamp_b,
        hRlM_le, hcapu_le, hcapq_le, hdet_bounds, _hcpl, E_good_seed, hE_prob, hE_corr⟩ :=
      h61p d hd ι gen hh_lo hh_hi x e ε₀ hhx hx1 he0 he1 hε₀0 hε₀1
        Q_net.toList hQ_list_unit hQ_list_len
    let N_bits : ℕ := R * ℓ * M₀ * (d + 1) * b
    have hN_bits1 : 1 ≤ N_bits := by
      dsimp only [N_bits]
      exact Nat.mul_pos (Nat.mul_pos (Nat.mul_pos (Nat.mul_pos hR1 hℓ1) hM₀1) (Nat.succ_pos d)) hb1
    have hcard_idx :
        Fintype.card (clm91ExplicitCapIdx R ℓ M₀ × Fin (d + 1) × Fin b) =
          Fintype.card (Fin N_bits) := by
      simp [clm91ExplicitCapIdx, N_bits, Nat.mul_assoc]
    let idxEquiv : (clm91ExplicitCapIdx R ℓ M₀ × Fin (d + 1) × Fin b) ≃ Fin N_bits :=
      Fintype.equivOfCardEq hcard_idx
    let equiv : (Fin N_bits → Bool) ≃ clm91ExplicitBitSeed R ℓ M₀ (d + 1) b :=
      Equiv.arrowCongr idxEquiv.symm (Equiv.refl Bool)
    let F_of : (Fin N_bits → Bool) →
        clm91ExplicitCapIdx R ℓ M₀ → EuclideanSpace ℝ (Fin (d + 1)) :=
      fun ω capIdx => ratPointToEuclidean (fun j =>
        sampleCoord (fun bitIdx => equiv ω (capIdx, j, bitIdx)))
    let storedBuckets : (Fin N_bits → Bool) → Fin R → (Fin ℓ → Fin M₀) → Finset ι :=
      fun ω r tup =>
        open Classical in
        gen.P₀.filter (fun i =>
          tup ∈ clm91ExplicitStoredTuples (F_of ω) (τ_d : ℝ) cap_u gen.pts r i)
    let pointBuildWork : (Fin N_bits → Bool) → ι → ℕ :=
      fun ω i => clm91ExplicitPointDataWork (F_of ω) (τ_d : ℝ) cap_u gen.pts i
    let storedSpaceFn : (Fin N_bits → Bool) → ℕ :=
      fun ω =>
        open Classical in
        R * ℓ * M₀ * (d + 1) +
          ∑ r : Fin R,
            ∑ tup ∈ Finset.univ.filter
                (fun tup' : Fin ℓ → Fin M₀ => (storedBuckets ω r tup').Nonempty),
              (storedBuckets ω r tup).card * ℓ
    let idx : CappedBirthPoolIndex (Fin N_bits → Bool) ι (d + 1) (Finset ι) :=
      { gen := gen
        IsValidState := fun _ P st => st = P
        initState := fun _ => gen.P₀
        buildWork := fun ω => ∑ i ∈ gen.P₀, pointBuildWork ω i
        buildPeakSpace := storedSpaceFn
        delete := fun ω _ st i =>
          { nextState := st.erase i
            work := clm91ExplicitPointDataWork (F_of ω) (τ_d : ℝ) cap_u gen.pts i
            peakSpace := storedSpaceFn ω }
        runQuery := fun ω P _ qry =>
          { answer := clm91ExplicitCappedQuery (F_of ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P qry
            work := clm91ExplicitQueryWork (F_of ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P qry
            peakSpace := storedSpaceFn ω } }
    let E_good : Set (Fin N_bits → Bool) := equiv ⁻¹' E_good_seed
    have hPval_ge1 : 1 ≤ P_val := by
      dsimp only [P_val, P_bp]
      linarith [le_max_left (0 : ℝ) (poly_prec d L_log), le_max_left (0 : ℝ) (poly_cap d L_log)]
    have hprec_le_P : poly_prec d L_log ≤ P_val := by
      dsimp only [P_val, P_bp]
      linarith [le_max_right (0 : ℝ) (poly_prec d L_log), le_max_left (0 : ℝ) (poly_cap d L_log)]
    have hcap_le_P : poly_cap d L_log ≤ P_val := by
      dsimp only [P_val, P_bp]
      linarith [le_max_left (0 : ℝ) (poly_prec d L_log), le_max_right (0 : ℝ) (poly_cap d L_log)]
    have hPval_nn : 0 ≤ P_val := by linarith
    have hgenh0 : 0 < gen.h := lt_of_lt_of_le hh_min hh_lo
    have hgenh1 : gen.h < 1 := lt_of_le_of_lt hh_hi hg1
    obtain ⟨hI_eq_u, h_u_le_rho8, hI_pos⟩ :=
      base_exp_le_rho_div_8 hc_gt hc_lt hℓ hgenh0 hgenh1 hhx hx1
    have hI_le_rho8 : I_h gen.h x / (ℓ : ℝ) ≤ rho_c c / 8 := hI_eq_u.trans_le h_u_le_rho8
    have hm_I_le : (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ)) ≤ (m : ℝ) ^ (rho_c c / 8) :=
      nat_rpow_le_of_pos_exps m hI_pos (by positivity) hI_le_rho8
    have hcap_nn_of : ∀ {A v : ℝ}, 0 ≤ A → v ≤ A * poly_cap d L_log → v ≤ A * P_val :=
      fun hA hv => hv.trans (mul_le_mul_of_nonneg_left hcap_le_P hA)
    refine ⟨R, M₀, b, B_prec, cap_u, cap_q, τ_d, τ_q, sampleCoord,
      equiv, idx, pointBuildWork, storedBuckets, E_good,
      hR1, hM₀1, hb1, hB1, hN_bits1,
      hb_le.trans hprec_le_P, hB_le.trans hprec_le_P,
      hτd_b, hτq_b, hsamp_b, ?_, ?_, ?_, rfl, ?_, ?_⟩
    · calc
        ((R * ℓ * M₀ : ℕ) : ℝ) ≤ (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ)) * poly_cap d L_log := hRlM_le
        _ ≤ (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ)) * P_val :=
              mul_le_mul_of_nonneg_left hcap_le_P (Real.rpow_nonneg (Nat.cast_nonneg _) _)
        _ ≤ (m : ℝ) ^ (rho_c c / 8) * P_val :=
              mul_le_mul_of_nonneg_right hm_I_le hPval_nn
    · exact hcap_nn_of (Real.rpow_nonneg (Nat.cast_nonneg _) _) hcapu_le
    · exact hcap_nn_of (Real.rpow_nonneg (Nat.cast_nonneg _) _) hcapq_le
    · rw [uniform_real_preimage_equiv equiv E_good_seed]
      exact hE_prob
    · intro ω
      obtain ⟨hpt_w, hsp_w, hq_w⟩ := hdet_bounds (equiv ω)
      have hsp_eq : storedSpaceFn ω = clm91ExplicitIndexSpace (F_of ω) (τ_d : ℝ) cap_u gen :=
        storedReprSpace_eq_explicitIndexSpace (F_of ω) (τ_d : ℝ) cap_u gen
      refine ⟨fun _ _ => rfl, fun _ => rfl, hsp_eq, rfl, rfl, ?_, ?_, le_rfl, ?_, ?_⟩
      · intro i hi
        have h1 : (pointBuildWork ω i : ℝ) ≤
            ((m : ℝ) ^ u + (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log :=
          hpt_w i hi
        calc
          (pointBuildWork ω i : ℝ)
              ≤ ((m : ℝ) ^ u + (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * P_val :=
                hcap_nn_of (by positivity) h1
          _ ≤ ((m : ℝ) ^ u + (m : ℝ) ^ (rho_c c / 8)) * P_val :=
                mul_le_mul_of_nonneg_right (by linarith) hPval_nn
      · change (storedSpaceFn ω : ℝ) ≤ _
        rw [hsp_eq]
        have h1 : (clm91ExplicitIndexSpace (F_of ω) (τ_d : ℝ) cap_u gen : ℝ) ≤
            ((m : ℝ) ^ (1 + u) + (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log :=
          hsp_w
        calc
          (clm91ExplicitIndexSpace (F_of ω) (τ_d : ℝ) cap_u gen : ℝ)
              ≤ ((m : ℝ) ^ (1 + u) + (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * P_val :=
                hcap_nn_of (by positivity) h1
          _ ≤ ((m : ℝ) ^ (1 + u) + (m : ℝ) ^ (rho_c c / 8)) * P_val :=
                mul_le_mul_of_nonneg_right (by linarith) hPval_nn
      · intro P st i hsub hst _hi
        dsimp only [idx] at hst ⊢
        subst hst
        have hi_P0 : i ∈ gen.P₀ := hsub _hi
        have h1 : (clm91ExplicitPointDataWork (F_of ω) (τ_d : ℝ) cap_u gen.pts i : ℝ) ≤
            ((m : ℝ) ^ u + (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * poly_cap d L_log :=
          hpt_w i hi_P0
        refine ⟨rfl, rfl, ?_, le_rfl⟩
        calc
          (clm91ExplicitPointDataWork (F_of ω) (τ_d : ℝ) cap_u gen.pts i : ℝ)
              ≤ ((m : ℝ) ^ u + (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * P_val :=
                hcap_nn_of (by positivity) h1
          _ ≤ ((m : ℝ) ^ u + (m : ℝ) ^ (rho_c c / 8)) * P_val :=
                mul_le_mul_of_nonneg_right (by linarith) hPval_nn
      · intro P st qry hsub _hst
        obtain ⟨hval_ans, hqw_le⟩ := hq_w P qry hsub
        refine ⟨rfl, rfl, hval_ans, ?_, ?_, le_rfl, ?_⟩
        · intro i hans
          exact cappedQuery_some_mem_storedBuckets (F_of ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P qry hans
        · calc
            (clm91ExplicitQueryWork (F_of ω) (τ_d : ℝ) (τ_q : ℝ) cap_u cap_q gen P qry : ℝ)
                ≤ ((m : ℝ) ^ q + (m : ℝ) ^ (I_h gen.h x / (ℓ : ℝ))) * P_val :=
                  hcap_nn_of (by positivity) hqw_le
            _ ≤ ((m : ℝ) ^ q + (m : ℝ) ^ (rho_c c / 8)) * P_val :=
                  mul_le_mul_of_nonneg_right (by linarith) hPval_nn
        · intro hω hqz hcomp
          exact hE_corr (equiv ω) hω P qry hsub (Finset.mem_toList.mpr hqz) hcomp

end UL.Proof.clm_9_1_explicit_tradeoff.H2
