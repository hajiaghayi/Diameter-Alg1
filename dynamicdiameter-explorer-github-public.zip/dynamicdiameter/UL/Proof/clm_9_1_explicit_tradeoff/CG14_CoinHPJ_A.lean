import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.H3b3_EmbedHPJ
import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Layout

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG14

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b3
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 1. `ZeroRandStmt` Witnesses for `H3b3.embedHPJStmt` -/

theorem zeroRand_relocStmt (tblSamp tblPts tblCoins : ℕ) (offSamp offPts offCoins : ℤ)
    (N_samp sz : ℕ) (phiRat : ℚ) :
    ∀ s : ArithRAMStmt, ZeroRandStmt (relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s)
  | .skip => .skip
  | .writeWordHeap _ _ valE => by
      cases valE <;> dsimp [relocStmt]
      all_goals repeat' constructor
  | .writeWordLocal _ _ _ | .writeRealLocal _ _ _ | .freeWordHeap _ _ | .freeWordLocal _ _
  | .freeRealHeap _ _ | .freeRealLocal _ _ | .randBitLocal _ _ => .skip
  | .writeRealHeap _ _ valE => by
      cases valE <;> dsimp [relocStmt]
      all_goals repeat' constructor
  | .randBitHeap _ _ => by
      dsimp [relocStmt]; repeat' constructor
  | .seq s₁ s₂ =>
      .seq (zeroRand_relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s₁)
           (zeroRand_relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s₂)
  | .ite _ s₁ s₂ =>
      .ite (zeroRand_relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s₁)
           (zeroRand_relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat s₂)
  | .whileLoop _ body =>
      .whileLoop (zeroRand_relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat body)
  | .repeatN _ body =>
      .repeatN (zeroRand_relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat body)
  | .localScope _ => .skip

theorem zeroRand_embedHPJStmt (scrR tblSamp tblPts tblCoins : ℕ)
    (outOff offSamp offPts offCoins : ℤ) (N_samp sz : ℕ) (phiRat : ℚ) :
    ZeroRandStmt (embedHPJStmt scrR tblSamp tblPts tblCoins outOff offSamp offPts offCoins N_samp sz phiRat) := by
  unfold embedHPJStmt
  refine .localScope (.seq (.writeWordLocal _ _ _) (.seq ?_ (.seq (.writeWordLocal _ _ _)
    (.repeatN (.seq (.writeRealHeap _ _ _) (.writeWordLocal _ _ _))))))
  exact zeroRand_relocStmt tblSamp tblPts tblCoins offSamp offPts offCoins N_samp sz phiRat hpjProg

/-! ### 2. `.freeWordHeap` Hoare Combinator & Scratch Headroom Reclamation -/

theorem wRead_wFree_of_ne (mem : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ}
    (hne : t₁ ≠ t₂ ∨ i₁ ≠ i₂) :
    wRead (H3a.wFree mem t₂ i₂) t₁ i₁ = wRead mem t₁ i₁ := by
  have hloc : (RAMCellLoc.heap t₁ i₁) ≠ (RAMCellLoc.heap t₂ i₂) := by
    intro h; cases h; rcases hne with h1 | h2 <;> exact absurd rfl ‹_›
  simp [wRead, H3a.wFree, WordStore.read, WordStore.free, hloc]

@[simp]
theorem rRead_wFree (mem : ArithRAMMemory) (t₁ t₂ : ℕ) (i₁ i₂ : ℤ) :
    rRead (H3a.wFree mem t₂ i₂) t₁ i₁ = rRead mem t₁ i₁ := rfl

theorem cleanMem_wFree {mem : ArithRAMMemory} (h : CleanMem mem) (t : ℕ) (i : ℤ) :
    CleanMem (H3a.wFree mem t i) := by
  rw [cleanMem_iff] at h ⊢
  refine ⟨?_, h.2⟩
  rcases mem with ⟨⟨live, vals⟩, rs⟩
  have hlive : Finset.filter (fun l => l.keepAtDepth 0 = true) live = live :=
    congrArg WordStore.live h.1
  have hvals : (fun l => if l.keepAtDepth 0 then vals l else 0) = vals :=
    congrArg WordStore.vals h.1
  unfold CleanWords H3a.wFree WordStore.free WordStore.popDepth
  congr 1
  · ext loc
    simp only [Finset.mem_filter, Finset.mem_erase]
    constructor
    · rintro ⟨⟨hne, hm⟩, _⟩; exact ⟨hne, hm⟩
    · rintro ⟨hne, hm⟩
      have hm' : loc ∈ Finset.filter (fun l => l.keepAtDepth 0 = true) live := hlive.symm ▸ hm
      exact ⟨⟨hne, hm⟩, (Finset.mem_filter.mp hm').2⟩
  · funext loc
    by_cases heq : loc = .heap t i
    · subst heq; simp [RAMCellLoc.keepAtDepth]
    · have hv := congrFun hvals loc
      simp [Function.update, heq] at hv ⊢
      exact hv

theorem inFootprint_wFree {TW BW TR BR : ℕ} {mem : ArithRAMMemory}
    (h : InFootprint TW BW TR BR mem) (t : ℕ) (i : ℤ) :
    InFootprint TW BW TR BR (H3a.wFree mem t i) :=
  ⟨cleanMem_wFree h.1 t i, (Finset.erase_subset _ _).trans h.2.1, h.2.2⟩

theorem cellCount_wFree_le (mem : ArithRAMMemory) (t : ℕ) (i : ℤ) :
    (H3a.wFree mem t i).cellCount ≤ mem.cellCount := by
  unfold ArithRAMMemory.cellCount WordStore.cellCount RealStore.cellCount H3a.wFree WordStore.free
  have hcard : (mem.words.live.erase (.heap t i)).card ≤ mem.words.live.card :=
    Finset.card_erase_le
  exact Nat.add_le_add_right hcard _

theorem stepTo_wFree {d : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (rem₀ : List Bool) (tbl : ℕ) (idxE : IntExpr) (idx : ℤ) {C S_aux : ℕ}
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hcost : intExprOps idxE + 1 ≤ C)
    (hc₀ : CleanMem m₀) (hS₀ : m₀.cellCount ≤ S_aux) :
    StepTo inp (.freeWordHeap tbl idxE) m₀ (H3a.wFree m₀ tbl idx) rem₀ rem₀ C S_aux := by
  refine ⟨cleanMem_wFree hc₀ tbl idx, (cellCount_wFree_le m₀ tbl idx).trans hS₀,
    fun rest u₀ sp₀ => ?_⟩
  refine ⟨1, u₀ + intExprOps idxE + 1, sp₀, by omega, le_max_left _ _, fun fuel => ?_⟩
  simp only [runArithRAMFuel]
  rcases hi : evalIntExpr inp.toWordView 0 m₀.words idxE with ⟨idx', ui, _⟩
  have hui : ui = intExprOps idxE := by
    have := evalIntExpr_ops inp.toWordView 0 m₀.words idxE; simpa [hi] using this
  have hidx' : idx' = idx := by simpa [hi] using hidx
  subst hidx'; subst hui
  rfl

theorem execDet_wFree {d TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (tbl : ℕ) (idxE : IntExpr) (idx : ℤ)
    {Post : ArithRAMMemory → Prop} {C : ℕ}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hidx : (evalIntExpr inp.toWordView 0 m₀.words idxE).1 = idx)
    (hcost : intExprOps idxE + 1 ≤ C)
    (hPost : Post (H3a.wFree m₀ tbl idx)) :
    ExecDet TW BW TR BR inp (.freeWordHeap tbl idxE) m₀ Post C :=
  ⟨_, hPost, inFootprint_wFree hfp₀ tbl idx,
   stepTo_wFree inp [] tbl idxE idx hidx hcost hfp₀.1 hfp₀.cellCount_le⟩

/-- Reclaim `H` word cells `scrW[K_base .. K_base + H - 1]` using loop counter `scrW[4]`. -/
def freeWordRangeStmt (scrW K_base H : ℕ) : ArithRAMStmt :=
  forLoopStmt scrW 4 H
    (.freeWordHeap scrW (.add (.lit ((K_base : ℕ) : ℤ)) (.readHeap scrW (.lit 4))))

theorem zeroRand_freeWordRangeStmt (scrW K_base H : ℕ) :
    ZeroRandStmt (freeWordRangeStmt scrW K_base H) :=
  zeroRand_forLoopStmt (.freeWordHeap _ _)

theorem exec_freeWordRangeStmt {d TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (scrW K_base H : ℕ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hK : 10 ≤ K_base) (hBW : K_base + H ≤ BW) :
    ExecDet TW BW TR BR inp (freeWordRangeStmt scrW K_base H) m₀
      (fun m₁ =>
        m₁.cellCount + H ≤ TW * BW + TR * BR ∧
        (∀ t, t ≠ scrW → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 4 → i < (K_base : ℤ) → wRead m₁ scrW i = wRead m₀ scrW i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      (5 + 14 * H) := by
  unfold freeWordRangeStmt
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    (∀ j < k, RAMCellLoc.heap scrW (((K_base + j : ℕ) : ℤ)) ∉ m.words.live) ∧
    (∀ t, t ≠ scrW → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ i, i ≠ 4 → i < (K_base : ℤ) → wRead m scrW i = wRead m₀ scrW i) ∧
    (∀ t i, rRead m t i = rRead m₀ t i)
  have hloop : ExecDet TW BW TR BR inp
      (forLoopStmt scrW 4 H
        (.freeWordHeap scrW (.add (.lit ((K_base : ℕ) : ℤ)) (.readHeap scrW (.lit 4)))))
      m₀ (Inv H) (4 + (1 + H * (8 + 6))) := by
    refine ExecDet.forLoop scrW 4 H _ Inv 8 hfp₀ hscrW (by omega) (by omega) ?_ ?_
    · exact ⟨fun _ hj => absurd hj (Nat.not_lt_zero _),
        fun t ht _ => wRead_wWrite_of_ne _ _ (Or.inl ht),
        fun i hi _ => wRead_wWrite_of_ne _ _ (Or.inr hi),
        fun _ _ => rfl⟩
    · intro k hk m ⟨hdead, hwt, hws, hr⟩ hctr hfpm
      refine execDet_wFree inp scrW
        (.add (.lit ((K_base : ℕ) : ℤ)) (.readHeap scrW (.lit 4)))
        (((K_base + k : ℕ) : ℤ)) hfpm
        (by simp only [evalIntExpr]; change (K_base : ℤ) + wRead m scrW 4 = _; rw [hctr]; push_cast; ring)
        (by simp [intExprOps]) ?_
      set m' := H3a.wFree m scrW (((K_base + k : ℕ) : ℤ))
      refine ⟨by dsimp [m']; rw [wRead_wFree_of_ne _ (Or.inr (by omega))]; exact hctr,
        fun j hj => ?_, fun t ht i => ?_, fun i hi4 hiK => ?_, fun t i => hr t i⟩
      · have hne4 : RAMCellLoc.heap scrW (((K_base + j : ℕ) : ℤ)) ≠ RAMCellLoc.heap scrW 4 := by
          intro heq; injection heq with _ h2; omega
        simp only [H3a.wWrite, WordStore.write, Finset.mem_insert, hne4, false_or]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hj with hlt | rfl
        · simp only [m', H3a.wFree, WordStore.free, Finset.mem_erase]
          exact fun h => hdead j hlt h.2
        · simp [m', H3a.wFree, WordStore.free]
      · rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wFree_of_ne _ (Or.inl ht)]
        exact hwt t ht i
      · rw [wRead_wWrite_of_ne _ _ (Or.inr hi4), wRead_wFree_of_ne _ (Or.inr (by omega))]
        exact hws i hi4 hiK
  refine hloop.mono ?_ (by omega)
  intro m₁ ⟨hdead, hwt, hws, hr⟩ hfp₁
  refine ⟨?_, hwt, hws, hr⟩
  let S_free : Finset RAMCellLoc :=
    (Finset.range H).image (fun j : ℕ => RAMCellLoc.heap scrW (((K_base + j : ℕ) : ℤ)))
  have hcard_free : S_free.card = H := by
    dsimp only [S_free]
    rw [Finset.card_image_of_injective _ (fun a b hab => by injection hab with _ h2; omega),
        Finset.card_range]
  have hdisj : Disjoint m₁.words.live S_free := by
    rw [Finset.disjoint_right]
    intro loc hloc
    rcases Finset.mem_image.mp hloc with ⟨j, hj, rfl⟩
    exact hdead j (Finset.mem_range.mp hj)
  have hsub : m₁.words.live ∪ S_free ⊆ rectHeapFinset TW BW := by
    refine Finset.union_subset hfp₁.2.1 (fun loc hloc => ?_)
    rcases Finset.mem_image.mp hloc with ⟨j, hj, rfl⟩
    have hjH : j < H := Finset.mem_range.mp hj
    exact mem_rectHeapFinset hscrW (Nat.cast_nonneg _) (by exact_mod_cast (by omega : K_base + j < BW))
  have hw_bound : m₁.words.live.card + H ≤ TW * BW := by
    calc m₁.words.live.card + H
        = m₁.words.live.card + S_free.card := by rw [hcard_free]
      _ = (m₁.words.live ∪ S_free).card := (Finset.card_union_of_disjoint hdisj).symm
      _ ≤ (rectHeapFinset TW BW).card := Finset.card_le_card hsub
      _ ≤ TW * BW := card_rectHeapFinset_le TW BW
  have hr_bound : m₁.reals.live.card ≤ TR * BR :=
    (Finset.card_le_card hfp₁.2.2).trans (card_rectHeapFinset_le TR BR)
  unfold ArithRAMMemory.cellCount WordStore.cellCount RealStore.cellCount
  omega

/-! ### 3. Polynomial Headroom & Cost Bounds for `evalHPJCenter` -/

noncomputable def hpjHeadroom (d : ℕ) (phiRat : ℚ) : ℕ :=
  Nat.ceil (hpjOpBound d (phiRat : ℝ)) + 2 * d + 6

noncomputable def hpjWordCap {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) : ℕ :=
  10 + cp.N_samp + cp.B_walk + hpjHeadroom d cp.phiRat

theorem hpjOpBound_ceil_le_poly {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    Nat.ceil (hpjOpBound d (cp.phiRat : ℝ)) ≤
      Nat.ceil hpjOpConst * (d + 1) ^ 10 * cp.P_hpj.k_phi ^ 3 := by
  have h2phi_le : 2 / (cp.phiRat : ℝ) ≤ (2 : ℝ) ^ cp.P_hpj.k_phi :=
    cp.hP_hpj.2.2.2.2.2.2.2.2.2.2.1
  have h2phi_gt1 : (1 : ℝ) < 2 / (cp.phiRat : ℝ) := by
    rw [lt_div_iff₀ cp.hφ0]; linarith [cp.hφ1]
  have hlog2_le1 : Real.log 2 ≤ 1 := by
    have h1 := Real.log_le_sub_one_of_pos (by positivity : (0 : ℝ) < 2)
    linarith
  have hlog_phi_nn : 0 ≤ Real.log (2 / (cp.phiRat : ℝ)) :=
    Real.log_nonneg h2phi_gt1.le
  have hlog_phi_ub : Real.log (2 / (cp.phiRat : ℝ)) ≤ (cp.P_hpj.k_phi : ℝ) := by
    calc Real.log (2 / (cp.phiRat : ℝ))
        ≤ Real.log ((2 : ℝ) ^ cp.P_hpj.k_phi) :=
          Real.log_le_log (by positivity) h2phi_le
      _ = (cp.P_hpj.k_phi : ℝ) * Real.log 2 := Real.log_pow 2 cp.P_hpj.k_phi
      _ ≤ (cp.P_hpj.k_phi : ℝ) * 1 :=
          mul_le_mul_of_nonneg_left hlog2_le1 (Nat.cast_nonneg _)
      _ = (cp.P_hpj.k_phi : ℝ) := mul_one _
  have hlog_d_nn : 0 ≤ Real.log ((d : ℝ) + 2) :=
    Real.log_nonneg (by linarith [Nat.cast_nonneg (α := ℝ) d])
  have hlog_d_ub : Real.log ((d : ℝ) + 2) ≤ (d : ℝ) + 1 := by
    have h1 := Real.log_le_sub_one_of_pos (by positivity : (0 : ℝ) < (d : ℝ) + 2)
    linarith
  refine Nat.ceil_le.mpr ?_
  unfold hpjOpBound
  push_cast
  have hc_le : hpjOpConst ≤ (Nat.ceil hpjOpConst : ℝ) := Nat.le_ceil hpjOpConst
  have hp_d : (Real.log ((d : ℝ) + 2)) ^ 3 ≤ ((d : ℝ) + 1) ^ 3 :=
    pow_le_pow_left₀ hlog_d_nn hlog_d_ub 3
  have hp_phi : (Real.log (2 / (cp.phiRat : ℝ))) ^ 3 ≤ (cp.P_hpj.k_phi : ℝ) ^ 3 :=
    pow_le_pow_left₀ hlog_phi_nn hlog_phi_ub 3
  have hd_nn : (0 : ℝ) ≤ (d : ℝ) + 1 := by positivity
  calc hpjOpConst * ((d : ℝ) + 1) ^ 7 * (Real.log ((d : ℝ) + 2)) ^ 3 *
        (Real.log (2 / (cp.phiRat : ℝ))) ^ 3
      ≤ (Nat.ceil hpjOpConst : ℝ) * ((d : ℝ) + 1) ^ 7 * ((d : ℝ) + 1) ^ 3 *
          (cp.P_hpj.k_phi : ℝ) ^ 3 := by
        have h1 : hpjOpConst * ((d : ℝ) + 1) ^ 7 ≤
            (Nat.ceil hpjOpConst : ℝ) * ((d : ℝ) + 1) ^ 7 :=
          mul_le_mul_of_nonneg_right hc_le (pow_nonneg hd_nn 7)
        have h2 : hpjOpConst * ((d : ℝ) + 1) ^ 7 * (Real.log ((d : ℝ) + 2)) ^ 3 ≤
            (Nat.ceil hpjOpConst : ℝ) * ((d : ℝ) + 1) ^ 7 * ((d : ℝ) + 1) ^ 3 :=
          mul_le_mul h1 hp_d (pow_nonneg hlog_d_nn 3) (by positivity)
        exact mul_le_mul h2 hp_phi (pow_nonneg hlog_phi_nn 3) (by positivity)
    _ = (Nat.ceil hpjOpConst : ℝ) * ((d : ℝ) + 1) ^ 10 * (cp.P_hpj.k_phi : ℝ) ^ 3 := by ring

theorem hpjWordCap_le_poly {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) :
    hpjWordCap cp ≤
      16 + cp.N_samp + cp.B_walk + 2 * d +
        Nat.ceil hpjOpConst * (d + 1) ^ 10 * cp.P_hpj.k_phi ^ 3 := by
  unfold hpjWordCap hpjHeadroom
  have h1 := hpjOpBound_ceil_le_poly cp
  omega

/-! ### 4. MSB-First `q`-Bit Decoder & `evalHPJCenterStmt` -/

private lemma bitsFnToNat_rec {q : ℕ} (bits : Fin q → Bool) :
    ∀ (k : ℕ) (hk : k ≤ q),
      (Nat.recOn k (0 : ℕ) (fun i acc =>
        if hi : i < q then 2 * acc + (if bits ⟨i, hi⟩ then 1 else 0) else acc) : ℕ) =
      bitsFnToNat k (fun j : Fin k => bits ⟨j.val, lt_of_lt_of_le j.isLt hk⟩)
  | 0, _ => by simp [bitsFnToNat]
  | k + 1, hk => by
      have hk_lt : k < q := by omega
      have ih := bitsFnToNat_rec bits k (by omega)
      change (if hi : k < q then 2 * _ + (if bits ⟨k, hi⟩ then 1 else 0) else _) = _
      dsimp [Nat.recOn] at ih
      rw [dif_pos hk_lt, ih]
      rfl

/-- Decode `q` bits from `coinTbl[baseOffE + 0 .. q - 1]` into `scrW[5]` using counter `scrW[4]`. -/
def decodeBitsHeapStmt (scrW : ℕ) (baseOffE : IntExpr) (q : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap scrW (.lit 5) (.lit 0))
    (forLoopStmt scrW 4 q
      (.writeWordHeap scrW (.lit 5)
        (.add (.mul (.lit 2) (.readHeap scrW (.lit 5)))
              (.readHeap coinTbl (.add baseOffE (.readHeap scrW (.lit 4)))))))

theorem zeroRand_decodeBitsHeapStmt (scrW : ℕ) (baseOffE : IntExpr) (q : ℕ) :
    ZeroRandStmt (decodeBitsHeapStmt scrW baseOffE q) :=
  .seq (.writeWordHeap _ _ _) (zeroRand_forLoopStmt (.writeWordHeap _ _ _))

theorem exec_decodeBitsHeapStmt {d TW BW TR BR : ℕ} (inp : ArithRAMInput d)
    {m₀ : ArithRAMMemory} (scrW : ℕ) (baseOffE : IntExpr) (baseOff : ℤ)
    (q : ℕ) (bits : Fin q → Bool)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hne_coin : coinTbl ≠ scrW) (hBW : 10 ≤ BW)
    (hbase_ops : intExprOps baseOffE ≤ 8)
    (hbase_val : ∀ m : ArithRAMMemory,
      (∀ t, t ≠ scrW → ∀ i, wRead m t i = wRead m₀ t i) →
      (∀ i, i ≠ 4 → i ≠ 5 → wRead m scrW i = wRead m₀ scrW i) →
      (evalIntExpr inp.toWordView 0 m.words baseOffE).1 = baseOff)
    (hcoins : ∀ b : Fin q, wRead m₀ coinTbl (baseOff + (b.val : ℤ)) = if bits b then 1 else 0) :
    ExecDet TW BW TR BR inp (decodeBitsHeapStmt scrW baseOffE q) m₀
      (fun m₁ =>
        wRead m₁ scrW 5 = ((bitsFnToFin q bits).val : ℤ) ∧
        (∀ t, t ≠ scrW → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 4 → i ≠ 5 → wRead m₁ scrW i = wRead m₀ scrW i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      (17 + 30 * q) := by
  unfold decodeBitsHeapStmt
  let pfx : ℕ → ℕ := fun k =>
    Nat.recOn k (0 : ℕ) (fun i acc =>
      if hi : i < q then 2 * acc + (if bits ⟨i, hi⟩ then (1 : ℕ) else 0) else acc)
  refine ExecDet.seq' (5 + 30 * q)
    (ExecDet.wWrite (C := 12) inp scrW (.lit 5) (.lit 0) 5 0
      hfp₀ hscrW (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m_init hm_init hfp_init; subst hm_init
  let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
    wRead m scrW 5 = Nat.cast (pfx k) ∧
    (∀ t, t ≠ scrW → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ i, i ≠ 4 → i ≠ 5 → wRead m scrW i = wRead m₀ scrW i) ∧
    (∀ t i, rRead m t i = rRead m₀ t i)
  refine (ExecDet.forLoop scrW 4 q _ Inv 24 hfp_init hscrW (by omega) (by omega) ?_ ?_).mono ?_ (by omega)
  · refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]; rfl,
      fun t ht _ => by rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)],
      fun i hi4 hi5 => by rw [wRead_wWrite_of_ne _ _ (Or.inr hi4), wRead_wWrite_of_ne _ _ (Or.inr hi5)],
      fun _ _ => rfl⟩
  · intro k hk m ⟨hdst, hwt, hws, hr⟩ hctr hfpm
    have hb_m : (evalIntExpr inp.toWordView 0 m.words baseOffE).1 = baseOff := hbase_val m hwt hws
    have hcoin_k : wRead m coinTbl (baseOff + (k : ℤ)) = if bits ⟨k, hk⟩ then 1 else 0 :=
      (hwt coinTbl hne_coin _).trans (hcoins ⟨k, hk⟩)
    let v_next : ℤ := 2 * Nat.cast (pfx k) + (if bits ⟨k, hk⟩ then 1 else 0)
    refine ExecDet.wWrite inp scrW (.lit 5)
      (.add (.mul (.lit 2) (.readHeap scrW (.lit 5)))
            (.readHeap coinTbl (.add baseOffE (.readHeap scrW (.lit 4)))))
      5 v_next hfpm hscrW (by omega) (by omega) rfl
      (by
        simp only [evalIntExpr]
        change 2 * wRead m scrW 5 +
          wRead m coinTbl ((evalIntExpr inp.toWordView 0 m.words baseOffE).1 + wRead m scrW 4) = v_next
        rw [hdst, hb_m, hctr, hcoin_k])
      (by simp only [intExprOps]; omega) ?_
    refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hctr,
      ?_, fun t ht i => ?_, fun i hi4 hi5 => ?_, fun t i => hr t i⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
      have hpfx_succ : pfx (k + 1) = 2 * pfx k + (if bits ⟨k, hk⟩ then (1 : ℕ) else 0) := by
        change (if hi : k < q then 2 * pfx k + (if bits ⟨k, hi⟩ then (1 : ℕ) else 0) else pfx k) = _
        rw [dif_pos hk]
      rw [hpfx_succ]; dsimp only [v_next]
      cases bits ⟨k, hk⟩ <;> (push_cast; ring)
    · rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
      exact hwt t ht i
    · rw [wRead_wWrite_of_ne _ _ (Or.inr hi4), wRead_wWrite_of_ne _ _ (Or.inr hi5)]
      exact hws i hi4 hi5
  · intro m₁ ⟨hdst, hwt, hws, hr⟩ _
    refine ⟨?_, hwt, hws, hr⟩
    rw [hdst]
    exact congrArg Nat.cast (bitsFnToNat_rec bits q le_rfl)

end UL.Proof.clm_9_1_explicit_tradeoff.CG14
