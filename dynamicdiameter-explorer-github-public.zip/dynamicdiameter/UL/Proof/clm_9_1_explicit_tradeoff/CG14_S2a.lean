import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG14_S1b
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.C14d2

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1

/-! ### 1. `foldResiduals` = `chainInput` & Full-Depth `D_max` Empty Terminal -/

theorem foldResiduals_take_eq_chainInput {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (S₀ : Finset ℕ) (nds : List (MNode cp)) :
    ∀ (m : ℕ) (hm : m ≤ nds.length),
      foldResiduals pts S₀ (nds.take m) =
        chainInput pts (fun i : Fin nds.length => (nds[i.val]'i.isLt).nd.toChainNode)
          S₀ ⟨m, Nat.lt_succ_of_le hm⟩
  | 0, _ => by
      simp only [List.take_zero, foldResiduals]
      exact (chainInput_zero pts _ S₀).symm
  | m + 1, hm => by
      have hm_lt : m < nds.length := Nat.lt_of_succ_le hm
      have htake : nds.take (m + 1) = nds.take m ++ [nds[m]'hm_lt] :=
        List.take_succ_eq_append_getElem hm_lt
      rw [htake, foldResiduals_append]
      dsimp only [foldResiduals]
      rw [foldResiduals_take_eq_chainInput pts S₀ nds m (Nat.le_of_succ_le hm)]
      let i_m : Fin nds.length := ⟨m, hm_lt⟩
      exact (chainInput_succ_eq pts
        (fun i : Fin nds.length => (nds[i.val]'i.isLt).nd.toChainNode) S₀ i_m).symm

theorem foldResiduals_eq_chainTerminal {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (S₀ : Finset ℕ) (nds : List (MNode cp)) :
    foldResiduals pts S₀ nds =
      chainTerminal pts (fun i : Fin nds.length => (nds[i.val]'i.isLt).nd.toChainNode) S₀ := by
  have h := foldResiduals_take_eq_chainInput pts S₀ nds nds.length le_rfl
  rw [List.take_length] at h
  exact h

theorem fullDepth_terminal_empty {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_lem_5_1 : S_lem_5_1)
    {cp : ChainParams d params h} (hh0 : 0 < h) (hh1 : h < 1)
    {actH : Finset ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    (hact_n : actH.card ≤ cp.n) (hgt : GhostTrackerWF actH pts gt)
    {nds : List (MNode cp)} (hlen : cp.D_max ≤ nds.length)
    (hcl : ChainListInv cp actH pts gt actH nds)
    (hgd : ChainListGood cp hh0 hh1 pts gt nds)
    (hage16 : ∀ mn ∈ nds, 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize) :
    foldResiduals pts actH nds = ∅ := by
  rw [foldResiduals_eq_chainTerminal]
  let nodes : Fin nds.length → ChainNode d := fun i => (nds[i.val]'i.isLt).nd.toChainNode
  refine chainTerminal_empty_of_full_depth pts nodes actH hact_n hlen (fun i => ?_)
  let mn := nds[i.val]'i.isLt
  rcases (chainListInv_getElem actH nds (Finset.Subset.refl _) hcl).2 i.val i.isLt
    with ⟨hSi_sub, hcur_eq, _, hbsz_B, _, hage_i, _, _, hwf_i⟩
  have hSi_eq : foldResiduals pts actH (nds.take i.val) = chainInput pts nodes actH i.castSucc :=
    foldResiduals_take_eq_chainInput pts actH nds i.val (Nat.le_of_lt i.isLt)
  have hcp_i := (hgd mn (List.getElem_mem i.isLt)).1
  have hbsz_card : mn.nd.birthSize = mn.nd.birthSet.card := hwf_i.1.2.1
  have hm_pos : 1 ≤ mn.nd.birthSet.card := by
    dsimp only [mn] at hbsz_card ⊢; have := cp.sched_bounds.1; have := K_alpha_ge_36 d; omega
  have hage_int : 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSet.card := by
    rw [← hbsz_card]; exact hage16 mn (List.getElem_mem i.isLt)
  have hcon := (residual_contraction_via_ghost h_lem_5_1 hgt hSi_sub hm_pos hcp_i hage_i hage_int).2.1
  rw [chainInput_succ_eq]
  change ((nodeResidual pts mn.nd.o mn.nd.V (chainInput pts nodes actH i.castSucc)).card : ℝ) ≤ _
  rw [← hSi_eq]
  exact hcon

/-! ### 2. Stage-2 Good-Coin Predicates (`GoodStage2Coins`) & `advanceOneJob_spec` -/

def s2JobGoodAt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (gt : GhostTracker d)
    (anchorNode : MNode cp) (jb : SuffixJob cp)
    (bSeeds : Fin cp.B_scan → OpSeed cp) (ctrSeed : CenterSeed cp) : Prop :=
  let (srcHist, tgtArr) : List ℕ × List ℕ :=
    match jb.ready.getLast? with
    | none => (anchorNode.histArr, anchorNode.nd.denseArr)
    | some u_last => (u_last.histArr, u_last.resArr)
  match jb.phase with
  | .copy cs =>
      let steps := min (cs.L_hist - cs.copyCur) cp.B_scan
      let cs' := advanceCopyLoop srcHist tgtArr steps cs
      ¬ (cs'.copyCur < cs'.L_hist) → ¬ (cs'.snapArr.length ≤ cp.B_scan) →
        let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts cs'.snapArr ctrSeed
        let P₀_uid := cs'.snapArr.toFinset.image gt.uidOf
        IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => gt.ghostPts u.1))
          (liftedPoint os.1 os.2)
  | .build bs =>
      let steps := min (bs.snapArr.length - bs.insCur) cp.B_scan
      SeqGood (advanceBuildStep cp pts)
        (fun st_b ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)
        steps bs (fun j => bSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩)

def s2LeafGood {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (st₁ : ChainEngineState cp)
    (leafSeeds : Fin (cp.B_scan + 1) → OpSeed cp) (leafCtr : CenterSeed cp) : Prop :=
  st₁.leafOverflow = false →
  cp.B_scan < st₁.leafArr.length →
  st₁.serving.length < cp.D_max →
  st₁.leafArr.length ≤ cp.B_scan + 1 →
    let pts := st₁.hp.coords
    let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts st₁.leafArr leafCtr
    let P₀_uid := st₁.leafArr.toFinset.image st₁.gt.uidOf
    IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => st₁.gt.ghostPts u.1))
      (liftedPoint os.1 os.2) ∧
    SeqGood (advanceBuildStep cp pts)
      (fun st_b ω => NodeOpSeedGood cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
        cp.τ_d cp.τ_q hh0 hh1 cp.cap_u cp.cap_q st_b.curNode.nd ω)
      (min st₁.leafArr.length (cp.B_scan + 1))
      (BuildState.init cp st₁.leafArr.length st₁.leafArr os.1 os.2 P₀_uid)
      (fun j => leafSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩)

def GoodStage2Coins {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    (st₁ : ChainEngineState cp) (ω₂ : Stage2Coins cp) : Prop :=
  (∀ r : Fin cp.D_max,
    ∀ (hr : r.val < st₁.serving.length) (jb : SuffixJob cp),
      st₁.jobs r = some jb →
      s2JobGoodAt cp hh0 hh1 st₁.hp.coords st₁.gt (st₁.serving[r.val]'hr) jb
        (fun j => ω₂.1 ⟨r.val * cp.B_scan + j.val, by
          have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
            calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan :=
                  Nat.add_lt_add_left j.isLt _
              _ = (r.val + 1) * cp.B_scan := by ring
              _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
          exact Nat.lt_add_right _ this⟩)
        (ω₂.2 r.castSucc)) ∧
  s2LeafGood cp hh0 hh1 st₁
    (fun j => ω₂.1 ⟨cp.D_max * cp.B_scan + j.val, Nat.add_lt_add_left j.isLt _⟩)
    (ω₂.2 (Fin.last cp.D_max))

/-- Specification of `advanceOneJob`: eliminates Stage-1 `slack = cp.B_scan` on running jobs and
produces valid suffix replacements on committing jobs! -/
private theorem advanceOneJob_spec_copy {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {actH : Finset ℕ} (hact_n : actH.card ≤ cp.n)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    (hgt : GhostTrackerWF actH pts gt)
    {preList : List (MNode cp)} {S_anc : Finset ℕ} {anc : MNode cp}
    (hpre_len : preList.length ≤ cp.D_max)
    (hpre_cl : ChainListInv cp actH pts gt actH preList)
    (hpre_fold : foldResiduals pts actH preList = S_anc)
    (hS_anc : S_anc ⊆ actH)
    (hanc_ln : LiveNodeInv cp actH pts gt S_anc anc)
    (hanc_age16 : 16 * K_alpha d * anc.nd.age < anc.nd.birthSize)
    (r : Fin cp.D_max) (hr_eq : preList.length = r.val)
    {jb : SuffixJob cp}
    (hjb : SuffixJobInvSlack cp cp.B_scan actH pts gt S_anc anc r.val jb)
    (bSeeds : Fin cp.B_scan → OpSeed cp) (ctrSeed : CenterSeed cp)
    (cs : CopyState) (hphase : jb.phase = .copy cs) :
    match advanceOneJob cp pts gt anc r jb bSeeds ctrSeed with
    | Sum.inl jb' =>
        SuffixJobInv cp actH pts gt S_anc anc r.val jb' ∧
        (SuffixJobGood cp hh0 hh1 pts gt jb →
         s2JobGoodAt cp hh0 hh1 pts gt anc jb bSeeds ctrSeed →
         SuffixJobGood cp hh0 hh1 pts gt jb')
    | Sum.inr (newSuf, newLeaf, newOv) =>
        r.val + newSuf.length ≤ cp.D_max ∧
        ChainListInv cp actH pts gt S_anc newSuf ∧
        (∀ u ∈ newSuf, 128 * K_alpha d * u.nd.age < u.nd.birthSize) ∧
        (newOv = false →
          newLeaf.Nodup ∧
          newLeaf.toFinset = foldResiduals pts S_anc newSuf ∧
          newLeaf.length ≤ cp.B_scan) ∧
        (ChainListGood cp hh0 hh1 pts gt preList →
         (∀ mn ∈ preList, 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize) →
         SuffixJobGood cp hh0 hh1 pts gt jb →
         s2JobGoodAt cp hh0 hh1 pts gt anc jb bSeeds ctrSeed →
         newOv = false ∧ ChainListGood cp hh0 hh1 pts gt newSuf) := by
  have hD2_pos : 1 ≤ cp.D2 := by unfold ChainParams.D2; omega
  have hD2_def : cp.D2 = cp.D_max + 2 := rfl
  rcases hanc_ln with ⟨hanc_cur, hanc_n, hanc_B, hanc_bu, hanc_hage, hanc_hist, hanc_tins, hanc_wf⟩
  rcases suffixJobInvSlack_bounds le_rfl hanc_B hjb
    with ⟨hready_der, _, hlvl_20, hbs_age_le⟩
  dsimp only [SuffixJobInvSlack] at hjb
  rcases hjb with ⟨hrs_lt, hcl_r, hrb, hanc_sched, hph⟩
  set s := jb.ready.length
  set M_r := anc.nd.birthSize
  set T_end := foldResiduals pts S_anc jb.ready
  have hTend_sub : T_end ⊆ actH := (chainListInv_getElem S_anc jb.ready hS_anc hcl_r).1
  let srcHist : List ℕ :=
    (match jb.ready.getLast? with
     | none => anc
     | some u_last => u_last).histArr
  let tgtArr : List ℕ :=
    match jb.ready.getLast? with
    | none => anc.nd.denseArr
    | some u_last => u_last.resArr
  have htgt_set : tgtArr.toFinset = T_end := by
    dsimp only [tgtArr, T_end]
    cases hgl : jb.ready.getLast? with
    | none =>
        have hemp : jb.ready = [] := by
          cases hlr : jb.ready with
          | nil => rfl
          | cons _ _ => simp [hlr] at hgl
        rw [hemp]; dsimp only [foldResiduals]
        exact hanc_cur
    | some u_last =>
        exact (chainListInv_getLast hS_anc hcl_r hgl).2.1
  set steps := min (cs.L_hist - cs.copyCur) cp.B_scan
  set cs' := advanceCopyLoop srcHist tgtArr steps cs
  let fAdv (cLoop : CopyState) : SuffixJob cp ⊕ (List (MNode cp) × List ℕ × Bool) :=
    if cLoop.copyCur < cLoop.L_hist then
      Sum.inl { ready := jb.ready, phase := .copy cLoop }
    else if cLoop.snapArr.length ≤ cp.B_scan then
      Sum.inr (jb.ready, cLoop.snapArr, false)
    else
      let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts cLoop.snapArr ctrSeed
      let P₀_uid := cLoop.snapArr.toFinset.image gt.uidOf
      Sum.inl { ready := jb.ready, phase := .build (BuildState.init cp cLoop.L_hist cLoop.snapArr os.1 os.2 P₀_uid) }
  let fGood (cLoop : CopyState) : Prop :=
    ¬ (cLoop.copyCur < cLoop.L_hist) → ¬ (cLoop.snapArr.length ≤ cp.B_scan) →
      let os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts cLoop.snapArr ctrSeed
      let P₀_uid := cLoop.snapArr.toFinset.image gt.uidOf
      IsCenterpoint (hpjAlpha d) (paraboloidLiftSet (fun u : P₀_uid => gt.ghostPts u.1))
        (liftedPoint os.1 os.2)
  have hadv_eq : advanceOneJob cp pts gt anc r jb bSeeds ctrSeed = fAdv cs' := by
    unfold advanceOneJob; rw [hphase]; dsimp only
    exact congrArg fAdv (by dsimp only [cs', steps, srcHist, tgtArr]; cases jb.ready.getLast? <;> rfl)
  have hs2_eq : s2JobGoodAt cp hh0 hh1 pts gt anc jb bSeeds ctrSeed = fGood cs' := by
    unfold s2JobGoodAt; rw [hphase]; dsimp only
    exact congrArg fGood (by dsimp only [cs', steps, srcHist, tgtArr]; cases jb.ready.getLast? <;> rfl)
  rw [hadv_eq, hs2_eq]
  dsimp only [fAdv, fGood]
  rw [hphase] at hph hlvl_20 hrb hanc_sched
  dsimp only [JobPhase.lvlProg] at hrb hanc_sched hlvl_20 ⊢
  rcases hph with ⟨hcur_lt, hL_le, hcs_inv⟩
  have hsteps_le : cs.copyCur + steps ≤ cs.L_hist := by dsimp only [steps]; omega
  rcases advanceCopyLoop_spec htgt_set steps hsteps_le hcs_inv
    with ⟨hL', hcur', hcs_inv', hdone_snap⟩
  change cs'.L_hist = cs.L_hist at hL'
  change cs'.copyCur = cs.copyCur + steps at hcur'
  change CopyStateInv srcHist T_end cs' at hcs_inv'
  change cs'.copyCur = cs'.L_hist → cs'.snapArr.toFinset = T_end at hdone_snap
  by_cases hstill : cs'.copyCur < cs'.L_hist
  · -- Case C1: still copying (`steps = cp.B_scan`)!
    rw [if_pos hstill]
    have hsteps_B : steps = cp.B_scan := by
      dsimp only [steps] at hcur' ⊢; omega
    refine ⟨?_, fun hgd_jb _ => ⟨hgd_jb.1, trivial⟩⟩
    dsimp only [SuffixJobInv, SuffixJobInvSlack, JobPhase.lvlProg]
    rw [Nat.add_zero, Nat.add_zero, hcur', hsteps_B, hL']
    refine ⟨hrs_lt, hcl_r,
      fun q hq => ⟨(hrb q hq).1, (hrb q hq).2.1, by have := (hrb q hq).2.2; omega⟩,
      by linarith only [hanc_sched],
      by rwa [← hsteps_B, ← hcur', ← hL'],
      hL_le, hcs_inv'⟩
  · -- Copying finished (`cs'.copyCur = cs'.L_hist`)!
    rw [if_neg hstill]
    have hcur_eq_L : cs'.copyCur = cs'.L_hist := by
      have := hcs_inv'.1; omega
    have hsnap_Tend : cs'.snapArr.toFinset = T_end := hdone_snap hcur_eq_L
    have hnd_snap : cs'.snapArr.Nodup := hcs_inv'.2.2.1
    by_cases hsmall : cs'.snapArr.length ≤ cp.B_scan
    · -- Case C2: small snapshot -> commit `(jb.ready, cs'.snapArr, false)`!
      rw [if_pos hsmall]
      refine ⟨by omega, hcl_r, ?_, fun _ => ⟨hnd_snap, hsnap_Tend, hsmall⟩,
        fun _ _ hgd_jb _ => ⟨rfl, hgd_jb.1⟩⟩
      intro u hu
      rcases List.mem_iff_getElem.mp hu with ⟨q, hq, rfl⟩
      exact (hready_der q hq).1
    · -- Case C3: large snapshot -> open `BuildState.init`!
      rw [if_neg hsmall]
      have hgt_B : cp.B_scan < cs'.snapArr.length := by omega
      have hTend_n : T_end.card ≤ cp.n :=
        (Finset.card_le_card hTend_sub).trans hact_n
      set os := evalHPJCenter cp.P_hpj cp.N_samp cp.q_idx cp.hmN pts cs'.snapArr ctrSeed
      set P₀_uid := cs'.snapArr.toFinset.image gt.uidOf
      set bs_new := BuildState.init cp cs'.L_hist cs'.snapArr os.1 os.2 P₀_uid
      have hP0_eq : P₀_uid = T_end.image gt.uidOf := by dsimp only [P₀_uid]; rw [hsnap_Tend]
      rcases buildState_init_spec cp hh0 hh1 hgt hTend_sub hTend_n cs'.L_hist hnd_snap
        hsnap_Tend hgt_B os.1 os.2 with ⟨hbs_inv_t, hbs_mat_gd⟩
      have hbs_inv : BuildStateInv cp pts gt T_end bs_new := by
        dsimp only [bs_new]; rw [hP0_eq]; exact hbs_inv_t
      -- Bound `bs_new.curNode.nd.birthSize = cs'.snapArr.length = T_end.card`!
      have hbsz_card : bs_new.curNode.nd.birthSize = T_end.card := by
        rw [hbs_inv.2.2.2.1]; dsimp only [bs_new, BuildState.init]
        rw [← List.toFinset_card_of_nodup hnd_snap, hsnap_Tend]
      have hsize_rel :
          if h0 : s = 0 then
            bs_new.curNode.nd.birthSize ≤ 2 * M_r
          else
            bs_new.curNode.nd.birthSize * (2 * cp.D2) ≤
              (jb.ready[s - 1]'(by omega)).nd.birthSize * (2 * cp.D2 + 1) := by
        by_cases hs0 : s = 0
        · rw [dif_pos hs0]
          have hemp : jb.ready = [] := List.eq_nil_of_length_eq_zero hs0
          have hTend_Sanc : T_end = S_anc := by dsimp only [T_end]; rw [hemp]; rfl
          rw [hbsz_card, hTend_Sanc]
          have hS_card : (S_anc.image gt.uidOf).card = S_anc.card := card_image_uidOf hgt hS_anc
          have hbnd := (hasNodeAge_card_bounds hanc_hage).2.1
          rw [hS_card, ← hanc_wf.1.2.1] at hbnd
          have hK := K_alpha_ge_36 d
          have : anc.nd.age ≤ 16 * K_alpha d * anc.nd.age := by
            simpa using Nat.mul_le_mul_right anc.nd.age (by omega : 1 ≤ 16 * K_alpha d)
          omega
        · rw [dif_neg hs0]
          set u_last := jb.ready[s - 1]'(by omega)
          have hgl : jb.ready.getLast? = some u_last := by
            rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem (by omega)]
          rcases chainListInv_getLast hS_anc hcl_r hgl with ⟨_, _, _, hln_last⟩
          have hTend_sub_ulast : T_end ⊆ u_last.nd.curSet := by
            have hsplit : jb.ready = jb.ready.take (s - 1) ++ [u_last] := by
              conv_lhs => rw [← List.take_append_drop (s - 1) jb.ready]
              congr 1
              rw [List.drop_eq_getElem_cons (by omega), List.drop_of_length_le (by omega)]
            have hf : T_end = nodeResidual pts u_last.nd.o u_last.nd.V u_last.nd.curSet := by
              dsimp only [T_end]; conv_lhs => rw [hsplit]
              rw [foldResiduals_append]; dsimp only [foldResiduals]; rw [hln_last.1]
            rw [hf]; intro x hx; unfold nodeResidual at hx
            rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hx.1
          have hT_le_u : T_end.card ≤ u_last.nd.curSet.card := Finset.card_le_card hTend_sub_ulast
          have hu_sub_act : u_last.nd.curSet ⊆ actH := by
            rw [hln_last.1]
            exact (chainListInv_getElem S_anc jb.ready hS_anc hcl_r).2 (s - 1) (by omega) |>.1
          have hu_card : (u_last.nd.curSet.image gt.uidOf).card = u_last.nd.curSet.card :=
            card_image_uidOf hgt hu_sub_act
          have hbnd := (hasNodeAge_card_bounds (hln_last.1 ▸ hln_last.2.2.2.2.1)).2.1
          rw [hu_card, ← hln_last.2.2.2.2.2.2.2.1.2.1] at hbnd
          have h2D2_age : 2 * cp.D2 * u_last.nd.age < u_last.nd.birthSize :=
            (hready_der (s - 1) (by omega)).2.1
          rw [hbsz_card]
          calc T_end.card * (2 * cp.D2)
              ≤ (u_last.nd.birthSize + u_last.nd.age) * (2 * cp.D2) :=
                Nat.mul_le_mul_right _ (hT_le_u.trans hbnd)
            _ = u_last.nd.birthSize * (2 * cp.D2) + 2 * cp.D2 * u_last.nd.age := by ring
            _ ≤ u_last.nd.birthSize * (2 * cp.D2) + u_last.nd.birthSize := by omega
            _ = u_last.nd.birthSize * (2 * cp.D2 + 1) := by ring
      -- Note `bs_new.L_hist = cs'.L_hist = cs.L_hist > cs.copyCur`, so `lvlProg` increases by `> B_scan`!
      have hlvl_new : (JobPhase.build bs_new).lvlProg = cs.L_hist + cp.B_scan := by
        dsimp only [JobPhase.lvlProg, bs_new, BuildState.init]; rw [hL', Nat.add_zero]
      refine ⟨?_, fun hgd_jb hs2 => ⟨hgd_jb.1, ?_⟩⟩
      · dsimp only [SuffixJobInv, SuffixJobInvSlack]
        rw [Nat.add_zero, Nat.add_zero, hlvl_new]
        refine ⟨hrs_lt, hcl_r, fun q hq => ⟨(hrb q hq).1, (hrb q hq).2.1, ?_⟩, ?_, ?_⟩
        · have hq_a := (hrb q hq).2.2; omega
        · have hmul : 64 * K_alpha d * (s * (48 * M_r) + cs.copyCur + cp.B_scan) ≤
              64 * K_alpha d * (s * (48 * M_r) + (cs.L_hist + cp.B_scan)) :=
            Nat.mul_le_mul_left _ (by omega)
          linarith only [hanc_sched, hmul]
        · dsimp only [bs_new, BuildState.init]
          rw [hL']
          refine ⟨by omega, hL_le, ?_, hsize_rel, hbs_inv⟩
          dsimp only [ManagedNode.openEmpty, NodeInst.openEmpty]; omega
      · have hcp_os := hs2 hstill hsmall
        refine ⟨?_, ?_⟩
        · dsimp only [LiveNodeGood, bs_new, BuildState.init, ManagedNode.openEmpty, NodeInst.openEmpty]
          exact hcp_os
        · dsimp only [bs_new]; rw [hP0_eq]; exact hbs_mat_gd

private theorem advanceOneJob_spec_build {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {actH : Finset ℕ} (hact_n : actH.card ≤ cp.n)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    (hgt : GhostTrackerWF actH pts gt)
    {preList : List (MNode cp)} {S_anc : Finset ℕ} {anc : MNode cp}
    (hpre_len : preList.length ≤ cp.D_max)
    (hpre_cl : ChainListInv cp actH pts gt actH preList)
    (hpre_fold : foldResiduals pts actH preList = S_anc)
    (hS_anc : S_anc ⊆ actH)
    (hanc_ln : LiveNodeInv cp actH pts gt S_anc anc)
    (hanc_age16 : 16 * K_alpha d * anc.nd.age < anc.nd.birthSize)
    (r : Fin cp.D_max) (hr_eq : preList.length = r.val)
    {jb : SuffixJob cp}
    (hjb : SuffixJobInvSlack cp cp.B_scan actH pts gt S_anc anc r.val jb)
    (bSeeds : Fin cp.B_scan → OpSeed cp) (ctrSeed : CenterSeed cp)
    (bs : BuildState cp) (hphase : jb.phase = .build bs) :
    match advanceOneJob cp pts gt anc r jb bSeeds ctrSeed with
    | Sum.inl jb' =>
        SuffixJobInv cp actH pts gt S_anc anc r.val jb' ∧
        (SuffixJobGood cp hh0 hh1 pts gt jb →
         s2JobGoodAt cp hh0 hh1 pts gt anc jb bSeeds ctrSeed →
         SuffixJobGood cp hh0 hh1 pts gt jb')
    | Sum.inr (newSuf, newLeaf, newOv) =>
        r.val + newSuf.length ≤ cp.D_max ∧
        ChainListInv cp actH pts gt S_anc newSuf ∧
        (∀ u ∈ newSuf, 128 * K_alpha d * u.nd.age < u.nd.birthSize) ∧
        (newOv = false →
          newLeaf.Nodup ∧
          newLeaf.toFinset = foldResiduals pts S_anc newSuf ∧
          newLeaf.length ≤ cp.B_scan) ∧
        (ChainListGood cp hh0 hh1 pts gt preList →
         (∀ mn ∈ preList, 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize) →
         SuffixJobGood cp hh0 hh1 pts gt jb →
         s2JobGoodAt cp hh0 hh1 pts gt anc jb bSeeds ctrSeed →
         newOv = false ∧ ChainListGood cp hh0 hh1 pts gt newSuf) := by
  have hD2_pos : 1 ≤ cp.D2 := by unfold ChainParams.D2; omega
  have hD2_def : cp.D2 = cp.D_max + 2 := rfl
  rcases hanc_ln with ⟨hanc_cur, hanc_n, hanc_B, hanc_bu, hanc_hage, hanc_hist, hanc_tins, hanc_wf⟩
  rcases suffixJobInvSlack_bounds le_rfl hanc_B hjb
    with ⟨hready_der, _, hlvl_20, hbs_age_le⟩
  dsimp only [SuffixJobInvSlack] at hjb
  rcases hjb with ⟨hrs_lt, hcl_r, hrb, hanc_sched, hph⟩
  set s := jb.ready.length
  set M_r := anc.nd.birthSize
  set T_end := foldResiduals pts S_anc jb.ready
  have hTend_sub : T_end ⊆ actH := (chainListInv_getElem S_anc jb.ready hS_anc hcl_r).1
  unfold advanceOneJob s2JobGoodAt
  rw [hphase] at hph hlvl_20 hrb hanc_sched ⊢
  dsimp only
  dsimp only [JobPhase.lvlProg] at hrb hanc_sched hlvl_20 ⊢
  rcases hph with ⟨hins_lt, hL_le, hage_ins, hmc_rat, hbs_inv⟩
  set steps := min (bs.snapArr.length - bs.insCur) cp.B_scan
  set ωs : Fin steps → OpSeed cp := fun j =>
    bSeeds ⟨j.val, lt_of_lt_of_le j.isLt (Nat.min_le_right _ _)⟩
  have hbnd_loop : bs.insCur + steps ≤ bs.snapArr.length := by dsimp only [steps]; omega
  have hage_bs_le : bs.curNode.nd.age ≤ bs.curNode.nd.birthSize := hbs_age_le bs hphase
  rcases advanceBuildLoop_spec h_clm_7_3 hd he1 cp hh0 hh1 steps ωs hbnd_loop hage_bs_le hbs_inv
    with ⟨hL', hsnap', hins', ho', hs_ht', hV', hbS', hbsz', hage', hbs_inv', hdone_cur, hgd_loop⟩
  set bs' := advanceBuildLoop cp pts steps ωs bs
  by_cases hstill : bs'.insCur < bs'.snapArr.length
  · -- Case B1: still building (`steps = cp.B_scan`)!
    rw [if_pos hstill]
    have hsteps_B : steps = cp.B_scan := by
      have hst' : (advanceBuildLoop cp pts steps ωs bs).insCur <
          (advanceBuildLoop cp pts steps ωs bs).snapArr.length := hstill
      rw [hins', hsnap'] at hst'
      dsimp only [steps] at hst' ⊢; omega
    refine ⟨?_, fun hgd_jb hs2 => ⟨hgd_jb.1, ?_⟩⟩
    · dsimp only [SuffixJobInv, SuffixJobInvSlack, JobPhase.lvlProg]
      rw [Nat.add_zero, Nat.add_zero, hL', hins', hsteps_B]
      refine ⟨hrs_lt, hcl_r, fun q hq => ⟨(hrb q hq).1, (hrb q hq).2.1, ?_⟩, ?_,
        by
          have hst' : (advanceBuildLoop cp pts steps ωs bs).insCur < bs'.snapArr.length := hstill
          rwa [hins', hsteps_B] at hst',
        hL' ▸ hL_le, ?_, ?_, hbs_inv'⟩
      · have := (hrb q hq).2.2; omega
      · linarith only [hanc_sched]
      · rw [hage']; omega
      · rw [hbsz']; exact hmc_rat
    · have hgd_bs0 : LiveNodeGood cp hh0 hh1 pts gt bs.curNode := by
        have := hgd_jb.2; rwa [hphase] at this
      exact hgd_loop hgd_bs0 hs2
  · -- Building finished (`bs'.insCur = bs'.snapArr.length`)!
    rw [if_neg hstill]
    have hins_done : bs'.insCur = bs'.snapArr.length := by
      have := hbs_inv'.2.2.1; omega
    set u_done := bs'.curNode
    have hud_cur : u_done.nd.curSet = T_end := hdone_cur hins_done
    have hud_ln : LiveNodeInv cp actH pts gt T_end u_done := by
      rcases hbs_inv' with ⟨_, _, _, hbsz_eq, hbsz_n, hbsz_B, hbu, _, _, hage_u, hhist_u, htins_u, hwf_u⟩
      rw [hins_done, ← hbsz_eq] at hhist_u htins_u
      exact ⟨hud_cur, hbsz_n, hbsz_B, hbu, hage_u, hhist_u, htins_u, hwf_u⟩
    set newReady := jb.ready ++ [u_done]
    have hcl_new : ChainListInv cp actH pts gt S_anc newReady :=
      chainListInv_append S_anc jb.ready [u_done] hcl_r ⟨hud_ln, trivial⟩
    have hfold_new : foldResiduals pts S_anc newReady =
        nodeResidual pts u_done.nd.o u_done.nd.V T_end := by
      dsimp only [newReady]; rw [foldResiduals_append]; rfl
    have hud_res_set : u_done.resArr.toFinset = foldResiduals pts S_anc newReady := by
      rw [hfold_new, hud_ln.2.2.2.2.2.2.2.2.2.1, hud_cur]
    -- Age bound on `u_done`: `B_scan * u_done.nd.age ≤ 2 * u_done.nd.birthSize` -> `128 * K_alpha * age < birthSize`!
    have hud_B_age : cp.B_scan * u_done.nd.age ≤ 2 * u_done.nd.birthSize := by
      have h1 : cp.B_scan * u_done.nd.age ≤ bs.insCur + cp.B_scan := hage' ▸ hage_ins
      have h2 : bs.snapArr.length = u_done.nd.birthSize := by rw [hbsz', hbs_inv.2.2.2.1]
      have h3 : cp.B_scan < u_done.nd.birthSize := hud_ln.2.2.1
      omega
    have hud_age128 : 128 * K_alpha d * u_done.nd.age < u_done.nd.birthSize := by
      rcases cp.sched_bounds with ⟨_, hB2, _, _⟩
      have hD2_ge3 : 3 ≤ cp.D2 := by omega
      have h256_lt_B : 256 * K_alpha d < cp.B_scan := by nlinarith only [hB2, hD2_ge3]
      by_cases ha0 : u_done.nd.age = 0
      · rw [ha0]; have := hud_ln.2.2.1; omega
      · have h1 := Nat.mul_lt_mul_of_pos_right h256_lt_B (by omega : 0 < u_done.nd.age)
        have h2 : 2 * (128 * K_alpha d * u_done.nd.age) < 2 * u_done.nd.birthSize := by
          linarith only [h1, hud_B_age]
        exact lt_of_mul_lt_mul_left h2 (Nat.zero_le _)
    have hall_age128 : ∀ u ∈ newReady, 128 * K_alpha d * u.nd.age < u.nd.birthSize := by
      intro u hu
      rcases List.mem_append.mp hu with hu_old | hu_last
      · rcases List.mem_iff_getElem.mp hu_old with ⟨q, hq, rfl⟩
        exact (hready_der q hq).1
      · rw [List.mem_singleton.mp hu_last]; exact hud_age128
    by_cases hres_small : u_done.resArr.length ≤ cp.B_scan
    · -- Case B2: small residual -> commit `(newReady, u_done.resArr, false)`!
      rw [if_pos hres_small]
      have hlen_nr : newReady.length = s + 1 := by simp [newReady, s]
      refine ⟨by omega, hcl_new, hall_age128,
        fun _ => ⟨hud_ln.2.2.2.2.2.2.2.2.1, hud_res_set, hres_small⟩,
        fun _ _ hgd_jb hs2 => ⟨rfl, ?_⟩⟩
      have hgd_bs0 : LiveNodeGood cp hh0 hh1 pts gt bs.curNode := by
        have := hgd_jb.2; rwa [hphase] at this
      have hud_gd := hgd_loop hgd_bs0 hs2
      intro u hu
      rcases List.mem_append.mp hu with hu_old | hu_last
      · exact hgd_jb.1 u hu_old
      · rw [List.mem_singleton.mp hu_last]; exact hud_gd
    · -- `u_done.resArr.length > cp.B_scan`
      rw [if_neg hres_small]
      have hlen_nr : newReady.length = s + 1 := by simp [newReady, s]
      by_cases hfull : r.val + newReady.length ≥ cp.D_max
      · -- Case B3: full depth `r + s + 1 = D_max` -> impossible on good coins (`resArr = ∅`)!
        rw [if_pos hfull]
        refine ⟨by omega, hcl_new, hall_age128, fun hf => by simp at hf,
          fun hpre_gd hpre_age16 hgd_jb hs2 => ?_⟩
        exfalso
        have hgd_bs0 : LiveNodeGood cp hh0 hh1 pts gt bs.curNode := by
          have := hgd_jb.2; rwa [hphase] at this
        have hud_gd := hgd_loop hgd_bs0 hs2
        set fullChain := preList ++ newReady
        have hfc_len : cp.D_max ≤ fullChain.length := by
          simp only [fullChain, List.length_append, hr_eq]; exact hfull
        have hfc_cl : ChainListInv cp actH pts gt actH fullChain := by
          refine chainListInv_append actH preList newReady hpre_cl ?_
          rwa [hpre_fold]
        have hfc_gd : ChainListGood cp hh0 hh1 pts gt fullChain := by
          intro u hu
          rcases List.mem_append.mp hu with h1 | h2
          · exact hpre_gd u h1
          · rcases List.mem_append.mp h2 with h2a | h2b
            · exact hgd_jb.1 u h2a
            · rw [List.mem_singleton.mp h2b]; exact hud_gd
        have hfc_age16 : ∀ mn ∈ fullChain, 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize := by
          intro mn hmn
          rcases List.mem_append.mp hmn with h1 | h2
          · exact hpre_age16 mn h1
          · have h128 := hall_age128 mn h2
            have hmul8 : 8 * (16 * K_alpha d * mn.nd.age) = 128 * K_alpha d * mn.nd.age := by ring
            omega
        have hemp := fullDepth_terminal_empty h_lem_5_1 hh0 hh1 hact_n hgt hfc_len hfc_cl hfc_gd hfc_age16
        have hfold_fc : foldResiduals pts actH fullChain = foldResiduals pts S_anc newReady := by
          dsimp only [fullChain]; rw [foldResiduals_append, hpre_fold]
        rw [hfold_fc] at hemp
        rw [hemp] at hud_res_set
        have hlen0 : u_done.resArr.length = 0 := by
          rw [← List.toFinset_card_of_nodup hud_ln.2.2.2.2.2.2.2.2.1, hud_res_set]
          rfl
        omega
      · -- Case B4: transition `.build → .copy` (`CopyState.init u_done.histArr.length`)!
        rw [if_neg hfull]
        set cs_new := CopyState.init u_done.histArr.length
        have hgl_new : newReady.getLast? = some u_done := by
          dsimp only [newReady]; exact List.getLast?_concat
        -- `0 < u_done.histArr.length` since `B_scan < u_done.resArr.length ≤ u_done.histArr.length`!
        have hres_sub_hist : u_done.resArr.toFinset ⊆ u_done.histArr.toFinset := by
          rw [hud_ln.2.2.2.2.2.2.2.2.2.1]
          refine Finset.Subset.trans (fun x hx => ?_) hud_ln.2.2.2.2.2.2.2.2.2.2
          unfold nodeResidual at hx
          rw [@Finset.mem_sdiff ℕ (Classical.decEq ℕ)] at hx; exact hx.1
        have hhist_gt_B : cp.B_scan < u_done.histArr.length := by
          have h1 : u_done.resArr.length = u_done.resArr.toFinset.card :=
            (List.toFinset_card_of_nodup hud_ln.2.2.2.2.2.2.2.2.1).symm
          have h2 : u_done.resArr.toFinset.card ≤ u_done.histArr.toFinset.card :=
            Finset.card_le_card hres_sub_hist
          have h3 : u_done.histArr.toFinset.card ≤ u_done.histArr.length :=
            List.toFinset_card_le _
          omega
        have hhist_le_2 : u_done.histArr.length ≤ 2 * u_done.nd.birthSize := by
          have h1 := hud_ln.2.2.2.2.2.1
          have hK := K_alpha_ge_36 d
          have : u_done.nd.age ≤ 128 * K_alpha d * u_done.nd.age := by
            simpa using Nat.mul_le_mul_right u_done.nd.age (by omega : 1 ≤ 128 * K_alpha d)
          omega
        have hcs_new_inv : CopyStateInv u_done.histArr (foldResiduals pts S_anc newReady) cs_new := by
          apply copyState_init_spec
          rw [← hud_res_set]; exact hres_sub_hist
        -- Bound `bs.L_hist + B_scan + bs.insCur + B_scan` relative to `M_q` (`q < s`) and `M_r`!
        have hmc_le_4Mr : u_done.nd.birthSize ≤ 8 * M_r := by
          rw [show u_done = bs'.curNode from rfl, hbsz']
          by_cases hs0 : s = 0
          · rw [dif_pos hs0] at hmc_rat; omega
          · rw [dif_neg hs0] at hmc_rat
            have hm1 := ratio_le_two_of_pow_bound (k := 1) hD2_pos (by omega) (by simpa using hmc_rat)
            have hm2 := (hready_der (s - 1) (by omega)).2.2
            dsimp only [s, M_r] at hm1 hm2 ⊢; omega
        have hprev_le_4Mr : bs.L_hist ≤ 8 * M_r := by
          by_cases hs0 : s = 0
          · have hemp : jb.ready = [] := List.eq_nil_of_length_eq_zero hs0
            rw [hemp] at hL_le; dsimp only [List.getLast?_nil] at hL_le; omega
          · have hgl_s : jb.ready.getLast? = some (jb.ready[s - 1]'(by omega)) := by
              rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem (by omega)]
            rw [hgl_s] at hL_le; dsimp only at hL_le
            have hm2 := (hready_der (s - 1) (by omega)).2.2
            dsimp only [s, M_r] at hm2 hL_le ⊢; omega
        refine ⟨?_, fun hgd_jb hs2 => ⟨?_, trivial⟩⟩
        · dsimp only [SuffixJobInv, SuffixJobInvSlack]
          rw [Nat.add_zero, Nat.add_zero, hgl_new]
          dsimp only [JobPhase.lvlProg, cs_new, CopyState.init]
          rw [Nat.add_zero]
          refine ⟨by omega, hcl_new, ?_, ?_, by omega, hhist_le_2, hcs_new_inv⟩
          · intro q hq_nr
            rw [hlen_nr] at hq_nr
            by_cases hq_lt_s : q < s
            · have hget_q : newReady[q]'(by rw [hlen_nr]; exact hq_nr) = jb.ready[q]'hq_lt_s :=
                List.getElem_append_left hq_lt_s
              rw [hget_q]
              refine ⟨(hrb q hq_lt_s).1, ?_, ?_⟩
              · intro q' hq'_nr hqq'
                by_cases hq'_lt_s : q' < s
                · rw [List.getElem_append_left hq'_lt_s]
                  exact (hrb q hq_lt_s).2.1 q' hq'_lt_s hqq'
                · have hq'_eq_s : q' = s := by rw [hlen_nr] at hq'_nr; omega
                  subst hq'_eq_s
                  have hget_s : newReady[s]'(by rw [hlen_nr]; omega) = u_done := by
                    dsimp only [newReady]; simp [s]
                  rw [hget_s]
                  by_cases hs0 : s = 0
                  · omega
                  · rw [dif_neg hs0] at hmc_rat
                    have hpow_prev := (hrb q hq_lt_s).2.1 (s - 1) (by omega) (by omega)
                    have hstep_k : s - q = (s - 1 - q) + 1 := by omega
                    rw [hstep_k, pow_succ, pow_succ, show u_done = bs'.curNode from rfl, hbsz']
                    calc bs.curNode.nd.birthSize * ((2 * cp.D2) ^ (s - 1 - q) * (2 * cp.D2))
                        = (bs.curNode.nd.birthSize * (2 * cp.D2)) * (2 * cp.D2) ^ (s - 1 - q) := by ring
                      _ ≤ ((jb.ready[s - 1]'(by omega)).nd.birthSize * (2 * cp.D2 + 1)) *
                            (2 * cp.D2) ^ (s - 1 - q) := Nat.mul_le_mul_right _ hmc_rat
                      _ = ((jb.ready[s - 1]'(by omega)).nd.birthSize * (2 * cp.D2) ^ (s - 1 - q)) *
                            (2 * cp.D2 + 1) := by ring
                      _ ≤ ((jb.ready[q]'hq_lt_s).nd.birthSize * (2 * cp.D2 + 1) ^ (s - 1 - q)) *
                            (2 * cp.D2 + 1) := Nat.mul_le_mul_right _ hpow_prev
                      _ = (jb.ready[q]'hq_lt_s).nd.birthSize *
                            ((2 * cp.D2 + 1) ^ (s - 1 - q) * (2 * cp.D2 + 1)) := by ring
              · -- Age bound for `q < s`: `(s + 1 - 1 - q) = (s - 1 - q) + 1`, gaining `+ 12 * M_q`!
                set M_q := (jb.ready[q]'hq_lt_s).nd.birthSize
                have hMq_B : cp.B_scan < M_q :=
                  (chainListInv_mem_birthSize S_anc jb.ready hcl_r _ (List.getElem_mem hq_lt_s)).1
                have hs_pos : 1 ≤ s := by omega
                have hgl_s : jb.ready.getLast? = some (jb.ready[s - 1]'(by omega)) := by
                  rw [List.getLast?_eq_getElem?, List.getElem?_eq_getElem (by omega)]
                rw [hgl_s] at hL_le; dsimp only at hL_le
                have hpow_last := (hrb q hq_lt_s).2.1 (s - 1) (by omega) (by omega)
                have hlast_le_2Mq : (jb.ready[s - 1]'(by omega)).nd.birthSize ≤ 2 * M_q :=
                  ratio_le_two_of_pow_bound hD2_pos (by omega) hpow_last
                rw [dif_neg (by omega : ¬ s = 0)] at hmc_rat
                have hmc_le_2last : bs.curNode.nd.birthSize ≤ 2 * (jb.ready[s - 1]'(by omega)).nd.birthSize :=
                  ratio_le_two_of_pow_bound (k := 1) hD2_pos (by omega) (by simpa using hmc_rat)
                have hsnap_eq_bs : bs.curNode.nd.birthSize = bs.snapArr.length := hbs_inv.2.2.2.1
                have hprog_le_12 : bs.L_hist + cp.B_scan + bs.insCur + cp.B_scan ≤ 12 * M_q := by
                  dsimp only [s, M_q] at hMq_B hlast_le_2Mq hmc_le_2last hL_le ⊢
                  omega
                have hstep_sub : newReady.length - 1 - q = (s - 1 - q) + 1 := by rw [hlen_nr]; omega
                rw [hstep_sub]
                have hq_old := (hrb q hq_lt_s).2.2
                have hexp : ((s - 1 - q) + 1) * (12 * M_q) + 6 * M_q =
                    (s - 1 - q) * (12 * M_q) + 6 * M_q + 12 * M_q := by ring
                change cp.B_scan * (jb.ready[q]'hq_lt_s).nd.age ≤
                  ((s - 1 - q) + 1) * (12 * M_q) + 6 * M_q
                rw [hexp]
                linarith only [hq_old, hprog_le_12]
            · -- Newly appended `q = s` (`u_done`): `B_scan * u_done.nd.age ≤ 2 * M_c ≤ 6 * M_c`!
              have hq_eq_s : q = s := by omega
              subst hq_eq_s
              have hget_s : newReady[s]'(by rw [hlen_nr]; omega) = u_done := by
                dsimp only [newReady]; simp [s]
              rw [hget_s]
              refine ⟨fun hs0 => ?_, fun q' hq'_nr hsq' => ?_, ?_⟩
              · rw [dif_pos hs0] at hmc_rat
                rw [show u_done = bs'.curNode from rfl, hbsz']
                exact hmc_rat
              · have hq'_eq : q' = s := by rw [hlen_nr] at hq'_nr; omega
                subst hq'_eq
                rw [hget_s, Nat.sub_self, pow_zero, pow_zero]
              · have hsub0 : newReady.length - 1 - s = 0 := by rw [hlen_nr]; omega
                rw [hsub0, Nat.zero_mul, zero_add]
                linarith only [hud_B_age]
          · -- Anchor age bound (`s → s + 1`, gaining `+ 48 * M_r` while `lvlProg_old + B_scan ≤ 14 * M_r`)!
            rw [hlen_nr]
            have hsnap_bs : bs.snapArr.length ≤ 8 * M_r := by
              rw [← hbs_inv.2.2.2.1, ← hbsz']; exact hmc_le_4Mr
            have hprog_le_48 : bs.L_hist + cp.B_scan + bs.insCur + cp.B_scan ≤ 48 * M_r := by
              have hB_Mr : cp.B_scan < M_r := hanc_B
              omega
            have hexp : (s + 1) * (48 * M_r) = s * (48 * M_r) + 48 * M_r := by ring
            have hmul := Nat.mul_le_mul_left (64 * K_alpha d)
              (show s * (48 * M_r) + bs.L_hist + cp.B_scan + bs.insCur + cp.B_scan ≤
                (s + 1) * (48 * M_r) by linarith only [hprog_le_48, hexp])
            linarith only [hanc_sched, hmul]
        · have hgd_bs0 : LiveNodeGood cp hh0 hh1 pts gt bs.curNode := by
            have := hgd_jb.2; rwa [hphase] at this
          have hud_gd := hgd_loop hgd_bs0 hs2
          intro u hu
          rcases List.mem_append.mp hu with hu_old | hu_last
          · exact hgd_jb.1 u hu_old
          · rw [List.mem_singleton.mp hu_last]; exact hud_gd


theorem advanceOneJob_spec {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    (hd : 1 ≤ d) (he1 : (params.e : ℝ) ≤ 1)
    (cp : ChainParams d params h) (hh0 : 0 < h) (hh1 : h < 1)
    {actH : Finset ℕ} (hact_n : actH.card ≤ cp.n)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {gt : GhostTracker d}
    (hgt : GhostTrackerWF actH pts gt)
    {preList : List (MNode cp)} {S_anc : Finset ℕ} {anc : MNode cp}
    (hpre_len : preList.length ≤ cp.D_max)
    (hpre_cl : ChainListInv cp actH pts gt actH preList)
    (hpre_fold : foldResiduals pts actH preList = S_anc)
    (hS_anc : S_anc ⊆ actH)
    (hanc_ln : LiveNodeInv cp actH pts gt S_anc anc)
    (hanc_age16 : 16 * K_alpha d * anc.nd.age < anc.nd.birthSize)
    (r : Fin cp.D_max) (hr_eq : preList.length = r.val)
    {jb : SuffixJob cp}
    (hjb : SuffixJobInvSlack cp cp.B_scan actH pts gt S_anc anc r.val jb)
    (bSeeds : Fin cp.B_scan → OpSeed cp) (ctrSeed : CenterSeed cp) :
    match advanceOneJob cp pts gt anc r jb bSeeds ctrSeed with
    | Sum.inl jb' =>
        SuffixJobInv cp actH pts gt S_anc anc r.val jb' ∧
        (SuffixJobGood cp hh0 hh1 pts gt jb →
         s2JobGoodAt cp hh0 hh1 pts gt anc jb bSeeds ctrSeed →
         SuffixJobGood cp hh0 hh1 pts gt jb')
    | Sum.inr (newSuf, newLeaf, newOv) =>
        r.val + newSuf.length ≤ cp.D_max ∧
        ChainListInv cp actH pts gt S_anc newSuf ∧
        (∀ u ∈ newSuf, 128 * K_alpha d * u.nd.age < u.nd.birthSize) ∧
        (newOv = false →
          newLeaf.Nodup ∧
          newLeaf.toFinset = foldResiduals pts S_anc newSuf ∧
          newLeaf.length ≤ cp.B_scan) ∧
        (ChainListGood cp hh0 hh1 pts gt preList →
         (∀ mn ∈ preList, 16 * K_alpha d * mn.nd.age ≤ mn.nd.birthSize) →
         SuffixJobGood cp hh0 hh1 pts gt jb →
         s2JobGoodAt cp hh0 hh1 pts gt anc jb bSeeds ctrSeed →
         newOv = false ∧ ChainListGood cp hh0 hh1 pts gt newSuf) := by
  cases hphase : jb.phase with
  | copy cs =>
      exact advanceOneJob_spec_copy h_lem_5_1 h_clm_7_3 hd he1 cp hh0 hh1 hact_n hgt
        hpre_len hpre_cl hpre_fold hS_anc hanc_ln hanc_age16 r hr_eq hjb bSeeds ctrSeed cs hphase
  | build bs =>
      exact advanceOneJob_spec_build h_lem_5_1 h_clm_7_3 hd he1 cp hh0 hh1 hact_n hgt
        hpre_len hpre_cl hpre_fold hS_anc hanc_ln hanc_age16 r hr_eq hjb bSeeds ctrSeed bs hphase

end UL.Proof.clm_9_1_explicit_tradeoff.C14d2
