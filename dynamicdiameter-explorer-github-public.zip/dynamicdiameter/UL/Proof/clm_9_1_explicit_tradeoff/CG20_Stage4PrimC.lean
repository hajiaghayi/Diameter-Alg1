import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Stage4PrimB
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL
open UL.Proof_cit_hpj19_thm18
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a3
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 1. `NodeMemFrame` & `O(1)` `MaxRadRAMOp` Extension -/

def NodeMemFrame {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (m₀ m₁ : ArithRAMMemory) : Prop :=
  ops.SlotsReady m₁ ∧
  (∀ mn' s', s' < M_slots cp → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m₁) ∧
  (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
  (∀ t < 2, ∀ i, rRead m₁ t i = rRead m₀ t i)

theorem NodeMemFrame.refl {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp} {m₀ : ArithRAMMemory}
    (hsr : ops.SlotsReady m₀) : NodeMemFrame ops m₀ m₀ :=
  ⟨hsr, fun _ _ _ he => he, fun _ _ _ _ => rfl, fun _ _ _ => rfl⟩

theorem NodeMemFrame.trans {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {m₀ m₁ m₂ : ArithRAMMemory}
    (h₁ : NodeMemFrame ops m₀ m₁) (h₂ : NodeMemFrame ops m₁ m₂) :
    NodeMemFrame ops m₀ m₂ :=
  ⟨h₂.1,
   fun mn' s' hs he => h₂.2.1 mn' s' hs (h₁.2.1 mn' s' hs he),
   fun t ht9 hts i => (h₂.2.2.1 t ht9 hts i).trans (h₁.2.2.1 t ht9 hts i),
   fun t ht2 i => (h₂.2.2.2 t ht2 i).trans (h₁.2.2.2 t ht2 i)⟩

theorem NodeMemFrame.of_scr_real {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {m₀ m₁ : ArithRAMMemory} (hsr₀ : ops.SlotsReady m₀)
    (hw : ∀ t, t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i)
    (hr : ∀ rt, rt ≠ engRealTbl → ∀ i, rRead m₁ rt i = rRead m₀ rt i) :
    NodeMemFrame ops m₀ m₁ := by
  have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead m₁ t i = wRead m₀ t i :=
    fun t ht9 _ i => hw t (by unfold engScrTbl; omega) i
  have hr3 : ∀ t, 3 ≤ t → t < ops.TR → ∀ i, rRead m₁ t i = rRead m₀ t i :=
    fun t ht3 _ i => hr t (by unfold engRealTbl; omega) i
  exact ⟨ops.slotsReady_ext m₀ m₁ hsr₀ hw9 hr3,
    fun mn' s' _ he => ops.encNode_ext mn' s' m₀ m₁ he hw9 hr3
      (fun _ _ _ _ => hr ptsRTbl (by decide) _),
    fun t _ ht i => hw t ht i,
    fun t ht2 i => hr t (by unfold engRealTbl; omega) i⟩

theorem NodeMemFrame.wWrite_scr {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {m : ArithRAMMemory} (hsr : ops.SlotsReady m) (idx val : ℤ) :
    NodeMemFrame ops m (H3a.wWrite m engScrTbl idx val) :=
  NodeMemFrame.of_scr_real hsr
    (fun t ht i => wRead_wWrite_of_ne _ _ (Or.inl ht))
    (fun _ _ _ => rfl)

theorem NodeMemFrame.rWrite_real {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {ops : NodeAndHPJRAMOps cp}
    {m : ArithRAMMemory} (hsr : ops.SlotsReady m) (idx : ℤ) (val : ℝ) :
    NodeMemFrame ops m (H3a.rWrite m engRealTbl idx val) :=
  NodeMemFrame.of_scr_real hsr
    (fun _ _ _ => rfl)
    (fun rt hrt i => rRead_rWrite_of_ne _ _ (Or.inl hrt))

structure MaxRadRAMOp {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) where
  C_maxRad : ℕ
  readMaxRadiusStmt : ℤ → ℤ → ℤ → ArithRAMStmt
  zeroRand_readMaxRadius : ∀ sR hR yR, ZeroRandStmt (readMaxRadiusStmt sR hR yR)
  readMaxRadius_spec :
    ∀ (inp : ArithRAMInput d) (m₀ : ArithRAMMemory)
      (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
      (slot : ℕ) (sR hR yR : ℤ),
      slot < M_slots cp →
      (∀ x ∈ mn.nd.curSet, x < cp.n) →
      ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts mn →
      0 ≤ sR → sR < 40 → 0 ≤ hR → hR < 40 → 0 ≤ yR → yR < 40 →
      sR ≠ hR → sR ≠ yR → hR ≠ yR →
      InFootprint ops.TW ops.BW ops.TR ops.BR m₀ →
      ops.SlotsReady m₀ →
      ops.EncNode mn slot m₀ →
      (∀ x ∈ mn.nd.curSet, ∀ c : Fin d,
        rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c) →
      wRead m₀ engScrTbl sR = (slot : ℤ) →
      ExecDet ops.TW ops.BW ops.TR ops.BR inp (readMaxRadiusStmt sR hR yR) m₀
        (fun m₁ =>
          NodeMemFrame ops m₀ m₁ ∧
          EncOptSingle hR yR (maxRadiusHandle cp.T_pow pts mn.nd.o mn.nd.denseArr.toFinset) m₁ ∧
          (∀ i < 40, i ≠ hR → i ≠ yR → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
          (∀ ri < 5, rRead m₁ engRealTbl ri = rRead m₀ engRealTbl ri))
        C_maxRad

/-! ### 2. `evalBaselinePairStmt`: `O(k_base * (q_idx + C_read + d))` Baseline Pair Evaluator -/

private theorem bitsToBaseSeedEquiv_slice {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (bBits : Fin cp.B_base → Bool) (coinOff : ℕ)
    (mem : ArithRAMMemory)
    (hcoins : ∀ k : Fin cp.B_base, wRead mem coinTbl ((coinOff : ℤ) + (k.val : ℤ)) =
      if bBits k then 1 else 0)
    (j : Fin cp.k_base) :
    ∃ subBits : Fin cp.q_idx → Bool,
      bitsToBaseSeedEquiv cp bBits j = bitsFnToFin cp.q_idx subBits ∧
      ∀ bi : Fin cp.q_idx,
        wRead mem coinTbl (((coinOff + j.val * cp.q_idx : ℕ) : ℤ) + (bi.val : ℤ)) =
          if subBits bi then 1 else 0 := by
  have hj_bound : ∀ bi : Fin cp.q_idx, j.val * cp.q_idx + bi.val < cp.B_base := fun bi => by
    calc j.val * cp.q_idx + bi.val < j.val * cp.q_idx + cp.q_idx := Nat.add_lt_add_left bi.isLt _
      _ = (j.val + 1) * cp.q_idx := by ring
      _ ≤ cp.k_base * cp.q_idx := Nat.mul_le_mul_right _ j.isLt
  refine ⟨fun bi => bBits ⟨j.val * cp.q_idx + bi.val, hj_bound bi⟩, rfl, fun bi => ?_⟩
  have hk := hcoins ⟨j.val * cp.q_idx + bi.val, hj_bound bi⟩
  have hidx : ((coinOff + j.val * cp.q_idx : ℕ) : ℤ) + (bi.val : ℤ) =
      (coinOff : ℤ) + ((j.val * cp.q_idx + bi.val : ℕ) : ℤ) := by
    push_cast; ring
  rw [hidx]
  exact hk

def baselineLoopStepStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (coinOff : ℕ) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 26)
          (.add (.lit (coinOff : ℤ))
                (.mul (.readHeap engScrTbl (.lit 25)) (.lit (cp.q_idx : ℤ)))))
  (.seq (decodeCoinWordStmt 26 27 28 cp.q_idx)
  (.seq (.writeWordHeap engScrTbl (.lit 29)
          (.mod (.readHeap engScrTbl (.lit 28)) (.readHeap engScrTbl (.lit 23))))
  (.seq (ops.readNodeArrElemStmt .dense 20 29 30)
  (.seq (pairDistSqStmt 30 22 4 d)
        (.ite (.or (.intEq (.readHeap engScrTbl (.lit 25)) (.lit 0))
                   (.realLt (.readRealHeap engRealTbl (.lit 3)) (.readRealHeap engRealTbl (.lit 4))))
          (.seq (.writeWordHeap engScrTbl (.lit 24) (.readHeap engScrTbl (.lit 30)))
                (.writeRealHeap engRealTbl (.lit 3) (.readRealHeap engRealTbl (.lit 4))))
          .skip)))))

theorem zeroRand_baselineLoopStepStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (coinOff : ℕ) :
    ZeroRandStmt (baselineLoopStepStmt ops coinOff) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_decodeCoinWordStmt 26 27 28 cp.q_idx)
    (.seq (.writeWordHeap _ _ _)
    (.seq (ops.zeroRand_readNodeArrElem .dense 20 29 30)
    (.seq (zeroRand_pairDistSqStmt 30 22 4 d)
          (.ite (.seq (.writeWordHeap _ _ _) (.writeRealHeap _ _ _)) .skip)))))

theorem exec_baselineLoopStepStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
    {slot y curBest j coinOff : ℕ} (hj : j < cp.k_base) (hsz : 1 ≤ mn.nd.denseArr.length)
    (bBits : Fin cp.B_base → Bool)
    (hslot : slot < M_slots cp)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (henc₀ : ops.EncNode mn slot m₀)
    (hs20 : wRead m₀ engScrTbl 20 = (slot : ℤ))
    (hy22 : wRead m₀ engScrTbl 22 = (y : ℤ))
    (hlen23 : wRead m₀ engScrTbl 23 = (mn.nd.denseArr.length : ℤ))
    (hbest24 : wRead m₀ engScrTbl 24 = (curBest : ℤ))
    (hctr25 : wRead m₀ engScrTbl 25 = (j : ℤ))
    (hsq3 : j = 0 ∨ rRead m₀ engRealTbl 3 = ‖pts curBest - pts y‖ ^ 2)
    (hy_pts : ∀ c : Fin d, rRead m₀ ptsRTbl (((y * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts y) c)
    (hdense_pts : ∀ x ∈ mn.nd.denseArr, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hcoins : ∀ k : Fin cp.B_base, wRead m₀ coinTbl ((coinOff : ℤ) + (k.val : ℤ)) =
      if bBits k then 1 else 0) :
    let u := bitsToBaseSeedEquiv cp bBits
    let xj := mn.nd.denseArr[(u ⟨j, hj⟩).val % mn.nd.denseArr.length]'(Nat.mod_lt _ hsz)
    let nxtBest := farthestValStep pts y j curBest xj
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (baselineLoopStepStmt ops coinOff) m₀
      (fun m₁ =>
        NodeMemFrame ops m₀ m₁ ∧
        wRead m₁ engScrTbl 24 = (nxtBest : ℤ) ∧
        rRead m₁ engRealTbl 3 = ‖pts nxtBest - pts y‖ ^ 2 ∧
        wRead m₁ engScrTbl 25 = (j : ℤ) ∧
        (∀ r, r < 24 → wRead m₁ engScrTbl r = wRead m₀ engScrTbl r) ∧
        (∀ ri, ri < 2 → rRead m₁ engRealTbl ri = rRead m₀ engRealTbl ri))
      (ops.C_read + 220 + 30 * cp.q_idx + 80 * d) := by
  have hTW9 : 9 ≤ ops.TW := by have := ops.hTW; omega
  have hBW64 : 64 ≤ ops.BW := by have := ops.hBW_scr; unfold M_slots at this; omega
  have hBR16 : 16 ≤ ops.BR := by have := ops.hBR_eng; omega
  have hT_scr : engScrTbl < ops.TW := by show 8 < ops.TW; omega
  have hT_real : engRealTbl < ops.TR := by have := ops.hTR; show 2 < ops.TR; omega
  unfold baselineLoopStepStmt
  let off_j : ℕ := coinOff + j * cp.q_idx
  obtain ⟨subBits, hu_eq, hsub_coins⟩ := bitsToBaseSeedEquiv_slice cp bBits coinOff m₀ hcoins ⟨j, hj⟩
  refine ExecDet.seq' (ops.C_read + 205 + 30 * cp.q_idx + 80 * d)
    (ExecDet.wWriteEq inp engScrTbl (.lit 26) _ 26 (off_j : ℤ)
      hfp₀ hT_scr (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change (coinOff : ℤ) + wRead m₀ engScrTbl 25 * (cp.q_idx : ℤ) = (off_j : ℤ)
          rw [hctr25]; simp [off_j])
      (by simp [intExprOps])) (by omega) ?_
  intro m₁ hm₁ hfp₁; subst hm₁
  have hnf₀₁ : NodeMemFrame ops m₀ (H3a.wWrite m₀ engScrTbl 26 (off_j : ℤ)) :=
    NodeMemFrame.wWrite_scr hsr₀ 26 (off_j : ℤ)
  refine ExecDet.seq' (ops.C_read + 175 + 80 * d)
    (exec_decodeCoinWordStmt inp 26 27 28 (off_j : ℤ) cp.q_idx subBits
      hTW9 hBW64 (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
      (by decide) (by decide) (by decide) hfp₁
      (wRead_wWrite_self _ _ _ _)
      (fun bi => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hsub_coins bi)))
    (by omega) ?_
  intro m₂ ⟨hdst₂, hwt₂, hwr₂, hrr₂⟩ hfp₂
  have hnf₀₂ : NodeMemFrame ops m₀ m₂ :=
    hnf₀₁.trans (NodeMemFrame.of_scr_real hnf₀₁.1 hwt₂ (fun rt _ i => hrr₂ rt i))
  let uVal : ℕ := (bitsToBaseSeedEquiv cp bBits ⟨j, hj⟩).val
  have hu28 : wRead m₂ engScrTbl 28 = (uVal : ℤ) := by
    rw [hdst₂]; dsimp [uVal]; rw [hu_eq]
  have hlen₂ : wRead m₂ engScrTbl 23 = (mn.nd.denseArr.length : ℤ) :=
    (hwr₂ 23 (by decide) (by decide)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hlen23)
  let remIdx : ℕ := uVal % mn.nd.denseArr.length
  have hrem_lt : remIdx < mn.nd.denseArr.length := Nat.mod_lt _ hsz
  refine ExecDet.seq' (ops.C_read + 160 + 80 * d)
    (ExecDet.wWriteEq inp engScrTbl (.lit 29)
      (.mod (.readHeap engScrTbl (.lit 28)) (.readHeap engScrTbl (.lit 23)))
      29 (remIdx : ℤ) hfp₂ hT_scr (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change wRead m₂ engScrTbl 28 % wRead m₂ engScrTbl 23 = (remIdx : ℤ)
          rw [hu28, hlen₂]; norm_cast)
      (by simp [intExprOps])) (by omega) ?_
  intro m₃ hm₃ hfp₃; subst hm₃
  have hnf₀₃ : NodeMemFrame ops m₀ (H3a.wWrite m₂ engScrTbl 29 (remIdx : ℤ)) :=
    hnf₀₂.trans (NodeMemFrame.wWrite_scr hnf₀₂.1 29 (remIdx : ℤ))
  have hs20_3 : wRead (H3a.wWrite m₂ engScrTbl 29 (remIdx : ℤ)) engScrTbl 20 = (slot : ℤ) :=
    (wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans
      ((hwr₂ 20 (by decide) (by decide)).trans ((wRead_wWrite_of_ne _ _ (Or.inr (by decide))).trans hs20))
  refine ExecDet.seq' (160 + 80 * d)
    (ops.readNodeArrElem_spec inp _ mn slot remIdx .dense hrem_lt 20 29 30
      hslot (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
      hfp₃ hnf₀₃.1 (hnf₀₃.2.1 mn slot hslot henc₀) hs20_3 (wRead_wWrite_self _ _ _ _))
    (by omega) ?_
  intro m₄ ⟨hsr₄, hx30, hnd₄, hwt₄, hwr₄, hrr₄⟩ hfp₄
  let xj : ℕ := mn.nd.denseArr[remIdx]'hrem_lt
  have hx30' : wRead m₄ engScrTbl 30 = (xj : ℤ) := hx30
  have hnf₃₄ : NodeMemFrame ops (H3a.wWrite m₂ engScrTbl 29 (remIdx : ℤ)) m₄ :=
    ⟨hsr₄, hnd₄, hwt₄, fun t ht2 i => hrr₄ t (by omega) i⟩
  have hnf₀₄ : NodeMemFrame ops m₀ m₄ := hnf₀₃.trans hnf₃₄
  have hw_lt26_4 : ∀ r, r < 26 → wRead m₄ engScrTbl r = wRead m₀ engScrTbl r := fun r hr26 =>
    (hwr₄ r (by omega)).trans
      ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans
        ((hwr₂ r (by omega) (by omega)).trans
          (wRead_wWrite_of_ne _ _ (Or.inr (by omega)))))
  have hr_2_4 : ∀ ri, rRead m₄ engRealTbl ri = rRead m₀ engRealTbl ri := fun ri =>
    (hrr₄ engRealTbl (by decide) ri).trans (hrr₂ engRealTbl ri)
  have hy22_4 : wRead m₄ engScrTbl 22 = (y : ℤ) := (hw_lt26_4 22 (by decide)).trans hy22
  have hbest24_4 : wRead m₄ engScrTbl 24 = (curBest : ℤ) := (hw_lt26_4 24 (by decide)).trans hbest24
  have hctr25_4 : wRead m₄ engScrTbl 25 = (j : ℤ) := (hw_lt26_4 25 (by decide)).trans hctr25
  have hxj_pts : ∀ c : Fin d, rRead m₄ ptsRTbl (((xj * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts xj) c :=
    fun c => (hnf₀₄.2.2.2 ptsRTbl (by decide) _).trans (hdense_pts xj (List.getElem_mem hrem_lt) c)
  have hy_pts_4 : ∀ c : Fin d, rRead m₄ ptsRTbl (((y * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts y) c :=
    fun c => (hnf₀₄.2.2.2 ptsRTbl (by decide) _).trans (hy_pts c)
  refine ExecDet.seq' 70
    (exec_pairDistSqStmt inp pts 30 22 4 hTW9 hBW64 ops.hTR hBR16
      (by omega) (by omega) (by omega) (by omega) hfp₄ hx30' hy22_4 hxj_pts hy_pts_4)
    (by omega) ?_
  intro m₅ ⟨hdsq₅, hwt₅, hwr₅, hrt₅, hrr₅⟩ hfp₅
  have hnf₀₅ : NodeMemFrame ops m₀ m₅ :=
    hnf₀₄.trans (NodeMemFrame.of_scr_real hnf₀₄.1 hwt₅ hrt₅)
  have hw_lt26_5 : ∀ r, r < 26 → wRead m₅ engScrTbl r = wRead m₀ engScrTbl r := fun r hr26 =>
    (hwr₅ r (by omega)).trans (hw_lt26_4 r hr26)
  have hx30_5 : wRead m₅ engScrTbl 30 = (xj : ℤ) := (hwr₅ 30 (by omega)).trans hx30'
  have hctr25_5 : wRead m₅ engScrTbl 25 = (j : ℤ) := (hw_lt26_5 25 (by decide)).trans hctr25
  have hbest24_5 : wRead m₅ engScrTbl 24 = (curBest : ℤ) := (hw_lt26_5 24 (by decide)).trans hbest24
  have hr3_5 : rRead m₅ engRealTbl 3 = rRead m₀ engRealTbl 3 :=
    (hrr₅ 3 (by decide) (by decide) (by decide)).trans (hr_2_4 3)
  refine ExecDet.ite_le (C_c := 15) (C_b := 40) _ _ _
    (by simp [condExprOps, realExprOps, intExprOps])
    (fun htrue => ?_) (fun hfalse => ?_)
  · have hcond_or : j = 0 ∨ ‖pts curBest - pts y‖ ^ 2 < ‖pts xj - pts y‖ ^ 2 := by
      by_cases hj0 : j = 0
      · exact Or.inl hj0
      · have hsq3_eq : rRead m₅ engRealTbl 3 = ‖pts curBest - pts y‖ ^ 2 :=
          hr3_5.trans (hsq3.resolve_left hj0)
        simp only [evalArithCond, evalRealExpr, evalIntExpr] at htrue
        change (decide (wRead m₅ engScrTbl 25 = 0) ||
                decide (rRead m₅ engRealTbl 3 < rRead m₅ engRealTbl 4)) = true at htrue
        rw [hctr25_5, hsq3_eq, hdsq₅] at htrue
        simp only [Bool.or_eq_true, decide_eq_true_eq] at htrue
        rcases htrue with h0 | hlt
        · omega
        · exact Or.inr hlt
    have hstep_eq : farthestValStep pts y j curBest xj = xj := by
      unfold farthestValStep; exact if_pos hcond_or
    refine ExecDet.seq' 25
      (ExecDet.wWriteEq inp engScrTbl (.lit 24) (.readHeap engScrTbl (.lit 30)) 24 (xj : ℤ)
        hfp₅ hT_scr (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; exact hx30_5) (by simp [intExprOps])) (by omega) ?_
    intro m₆ hm₆ hfp₆; subst hm₆
    have hnf₀₆ : NodeMemFrame ops m₀ (H3a.wWrite m₅ engScrTbl 24 (xj : ℤ)) :=
      hnf₀₅.trans (NodeMemFrame.wWrite_scr hnf₀₅.1 24 (xj : ℤ))
    refine ExecDet.rWrite inp engRealTbl (.lit 3) (.readRealHeap engRealTbl (.lit 4))
      3 (‖pts xj - pts y‖ ^ 2) hfp₆ hT_real (by omega) (by omega) rfl
      (by simp only [evalRealExpr, evalIntExpr]; change rRead _ engRealTbl 4 = _
          rw [rRead_wWrite]; exact hdsq₅)
      (by simp [intExprOps, realExprOps]) ?_
    dsimp only; rw [hstep_eq]
    exact ⟨hnf₀₆.trans (NodeMemFrame.rWrite_real hnf₀₆.1 3 _),
      by rw [wRead_rWrite, wRead_wWrite_self],
      rRead_rWrite_self _ _ _ _,
      by rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hctr25_5,
      fun r hr24 => by
        rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hw_lt26_5 r (by omega),
      fun ri hri2 => by
        rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega)), rRead_wWrite]
        exact (hrr₅ ri (by omega) (by omega) (by omega)).trans (hr_2_4 ri)⟩
  · have hj_ne0 : j ≠ 0 := by
      intro hj0
      simp only [evalArithCond, evalRealExpr, evalIntExpr] at hfalse
      change (decide (wRead m₅ engScrTbl 25 = 0) ||
              decide (rRead m₅ engRealTbl 3 < rRead m₅ engRealTbl 4)) = false at hfalse
      rw [hctr25_5, hj0] at hfalse; simp at hfalse
    have hsq3_eq : rRead m₅ engRealTbl 3 = ‖pts curBest - pts y‖ ^ 2 :=
      hr3_5.trans (hsq3.resolve_left hj_ne0)
    have hnot_lt : ¬ ‖pts curBest - pts y‖ ^ 2 < ‖pts xj - pts y‖ ^ 2 := by
      simp only [evalArithCond, evalRealExpr, evalIntExpr] at hfalse
      change (decide (wRead m₅ engScrTbl 25 = 0) ||
              decide (rRead m₅ engRealTbl 3 < rRead m₅ engRealTbl 4)) = false at hfalse
      rw [hsq3_eq, hdsq₅] at hfalse
      intro hlt; rw [decide_eq_true hlt] at hfalse; simp at hfalse
    have hstep_eq : farthestValStep pts y j curBest xj = curBest := by
      unfold farthestValStep
      exact if_neg (by rintro (h0 | hlt); exact hj_ne0 h0; exact hnot_lt hlt)
    refine ExecDet.skip inp hfp₅ ?_ (by omega)
    dsimp only; rw [hstep_eq]
    exact ⟨hnf₀₅, hbest24_5, hsq3_eq, hctr25_5,
      fun r hr24 => hw_lt26_5 r (by omega),
      fun ri hri2 => (hrr₅ ri (by omega) (by omega) (by omega)).trans (hr_2_4 ri)⟩

def evalBaselinePairStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops)
    (coinOff : ℕ) : ArithRAMStmt :=
  .seq (mops.readMaxRadiusStmt 20 21 22)
    (.ite (.intEq (.readHeap engScrTbl (.lit 21)) (.lit 0))
      (.writeWordHeap engScrTbl (.lit 12) (.lit 0))
      (.seq (ops.readNodeScalarStmt .denseLen 20 23)
        (.ite (.intLe (.lit 1) (.readHeap engScrTbl (.lit 23)))
          (.seq (.writeWordHeap engScrTbl (.lit 24) (.readHeap engScrTbl (.lit 22)))
          (.seq (forLoopStmt engScrTbl 25 cp.k_base (baselineLoopStepStmt ops coinOff))
          (.seq (.writeWordHeap engScrTbl (.lit 12) (.lit 1))
          (.seq (.writeWordHeap engScrTbl (.lit 13) (.readHeap engScrTbl (.lit 22)))
                (.writeWordHeap engScrTbl (.lit 14) (.readHeap engScrTbl (.lit 24)))))))
          (.seq (.writeWordHeap engScrTbl (.lit 12) (.lit 1))
          (.seq (.writeWordHeap engScrTbl (.lit 13) (.readHeap engScrTbl (.lit 22)))
                (.writeWordHeap engScrTbl (.lit 14) (.readHeap engScrTbl (.lit 22))))))))

theorem zeroRand_evalBaselinePairStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops)
    (coinOff : ℕ) :
    ZeroRandStmt (evalBaselinePairStmt ops mops coinOff) :=
  .seq (mops.zeroRand_readMaxRadius 20 21 22)
    (.ite (.writeWordHeap _ _ _)
      (.seq (ops.zeroRand_readNodeScalar .denseLen 20 23)
        (.ite
          (.seq (.writeWordHeap _ _ _)
          (.seq (zeroRand_forLoopStmt (zeroRand_baselineLoopStepStmt ops coinOff))
          (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))
          (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))))

theorem exec_evalBaselinePairStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (mops : MaxRadRAMOp ops)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (mn : MNode cp)
    {slot coinOff : ℕ} (bBits : Fin cp.B_base → Bool)
    (hslot : slot < M_slots cp)
    (hcur_lt : ∀ x ∈ mn.nd.curSet, x < cp.n)
    (hwf_mn : ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts mn)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (henc₀ : ops.EncNode mn slot m₀)
    (hs20 : wRead m₀ engScrTbl 20 = (slot : ℤ))
    (hpts_cur : ∀ x ∈ mn.nd.curSet, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hcoins : ∀ k : Fin cp.B_base, wRead m₀ coinTbl ((coinOff : ℤ) + (k.val : ℤ)) =
      if bBits k then 1 else 0) :
    let bp := evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr
      (bitsToBaseSeedEquiv cp bBits)
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (evalBaselinePairStmt ops mops coinOff) m₀
      (fun m₁ =>
        NodeMemFrame ops m₀ m₁ ∧
        EncOptPair 12 13 14 bp m₁ ∧
        (∀ r, (r < 12 ∨ r = 20) → wRead m₁ engScrTbl r = wRead m₀ engScrTbl r) ∧
        (∀ ri, ri < 2 → rRead m₁ engRealTbl ri = rRead m₀ engRealTbl ri))
      (mops.C_maxRad + ops.C_read + 200 +
        cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d)) := by
  have hT_scr : engScrTbl < ops.TW := by have := ops.hTW; show 8 < ops.TW; omega
  have hBW64 : 64 ≤ ops.BW := by have := ops.hBW_scr; unfold M_slots at this; omega
  unfold evalBaselinePairStmt
  refine ExecDet.seq' (ops.C_read + 200 +
      cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d))
    (mops.readMaxRadius_spec inp m₀ pts mn slot 20 21 22
      hslot hcur_lt hwf_mn (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
      (by decide) (by decide) (by decide) hfp₀ hsr₀ henc₀ hpts_cur hs20)
    (by omega) ?_
  intro m₁ ⟨hnf₁, hmrh, hwr₁, hrr₁⟩ hfp₁
  cases hmrh_eq : maxRadiusHandle cp.T_pow pts mn.nd.o mn.nd.denseArr.toFinset with
  | none =>
      rw [hmrh_eq] at hmrh
      have h21_0 : wRead m₁ engScrTbl 21 = 0 := hmrh
      have hbp_none : evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr
          (bitsToBaseSeedEquiv cp bBits) = none := by
        unfold evalBaselinePair; rw [hmrh_eq]
      refine ExecDet.ite_le (C_c := 10) (C_b := 20) _ _ _
        (by simp [condExprOps, intExprOps])
        (fun _ => ?_)
        (fun hf => by
          simp only [evalArithCond, evalIntExpr] at hf
          change decide (wRead m₁ engScrTbl 21 = 0) = false at hf
          rw [h21_0] at hf; simp at hf)
      refine ExecDet.wWrite inp engScrTbl (.lit 12) (.lit 0) 12 0
        hfp₁ hT_scr (by omega) (by omega) rfl rfl (by simp [intExprOps]) ?_
      dsimp only; rw [hbp_none]
      exact ⟨hnf₁.trans (NodeMemFrame.wWrite_scr hnf₁.1 12 0),
        wRead_wWrite_self _ _ _ _,
        fun r hr => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans
          (hwr₁ r (by omega) (by omega) (by omega)),
        fun ri hri2 => hrr₁ ri (by omega)⟩
  | some y =>
      rw [hmrh_eq] at hmrh
      rcases hmrh with ⟨h21_1, h22_y⟩
      have hS_T : ∀ x ∈ mn.nd.denseArr.toFinset, x < cp.T_pow := fun x hx =>
        lt_of_lt_of_le (hcur_lt x hx) cp.hT_pow
      have hSne : mn.nd.denseArr.toFinset.Nonempty := by
        by_contra hemp
        have hnone := (maxRadiusHandle_spec cp.T_pow pts mn.nd.o hS_T).1
          (Finset.not_nonempty_iff_eq_empty.mp hemp)
        rw [hnone] at hmrh_eq; cases hmrh_eq
      obtain ⟨y', hy'_eq, hy'_max⟩ := (maxRadiusHandle_spec cp.T_pow pts mn.nd.o hS_T).2 hSne
      rw [hmrh_eq] at hy'_eq
      injection hy'_eq with hy_eq'; subst hy_eq'
      have hy_cur : y ∈ mn.nd.curSet := hy'_max.1
      refine ExecDet.ite_le (C_c := 10)
        (C_b := ops.C_read + 190 + cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d))
        _ _ _ (by simp [condExprOps, intExprOps])
        (fun ht => by
          simp only [evalArithCond, evalIntExpr] at ht
          change decide (wRead m₁ engScrTbl 21 = 0) = true at ht
          rw [h21_1] at ht; simp at ht)
        (fun _ => ?_)
      have hs20_1 : wRead m₁ engScrTbl 20 = (slot : ℤ) :=
        (hwr₁ 20 (by decide) (by decide) (by decide)).trans hs20
      refine ExecDet.seq' (190 + cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d))
        (ops.readNodeScalar_spec inp m₁ mn slot .denseLen 20 23
          hslot (by omega) (by omega) (by omega) (by omega)
          hfp₁ hnf₁.1 (hnf₁.2.1 mn slot hslot henc₀) hs20_1)
        (by omega) ?_
      intro m₂ ⟨hsr₂, hlen23, hnd₂, hwt₂, hwr₂, hrr₂⟩ hfp₂
      have hnf₀₂ : NodeMemFrame ops m₀ m₂ :=
        hnf₁.trans ⟨hsr₂, hnd₂, hwt₂, fun t ht2 i => hrr₂ t (by omega) i⟩
      have hlen23' : wRead m₂ engScrTbl 23 = (mn.nd.denseArr.length : ℤ) := hlen23
      have hs20_2 : wRead m₂ engScrTbl 20 = (slot : ℤ) := (hwr₂ 20 (by decide)).trans hs20_1
      have hy22_2 : wRead m₂ engScrTbl 22 = (y : ℤ) := (hwr₂ 22 (by decide)).trans h22_y
      refine ExecDet.ite_le (C_c := 10)
        (C_b := 180 + cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d))
        _ _ _ (by simp [condExprOps, intExprOps])
        (fun hsz_t => ?_) (fun hsz_f => ?_)
      · have hsz : 1 ≤ mn.nd.denseArr.length := by
          simp only [evalArithCond, evalIntExpr] at hsz_t
          change decide ((1 : ℤ) ≤ wRead m₂ engScrTbl 23) = true at hsz_t
          rw [hlen23'] at hsz_t
          exact Int.ofNat_le.mp (of_decide_eq_true hsz_t)
        let u := bitsToBaseSeedEquiv cp bBits
        let samp : Fin cp.k_base → ℕ := fun j =>
          mn.nd.denseArr[(u j).val % mn.nd.denseArr.length]'(Nat.mod_lt _ hsz)
        let bFold : ℕ → ℕ := fun k =>
          (List.range k).foldl
            (fun best j => if hj : j < cp.k_base then farthestValStep pts y j best (samp ⟨j, hj⟩) else best)
            y
        have hbp_eq : evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr u =
            some (y, bFold cp.k_base) := by
          unfold evalBaselinePair
          rw [hmrh_eq]; dsimp only; rw [dif_pos hsz]
          dsimp only [bFold]
          rw [range_farthestValStep_eq cp.hk_base pts y samp y]
        refine ExecDet.seq' (165 + cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d))
          (ExecDet.wWriteEq inp engScrTbl (.lit 24) (.readHeap engScrTbl (.lit 22)) 24 (y : ℤ)
            hfp₂ hT_scr (by omega) (by omega) rfl
            (by simp only [evalIntExpr]; exact hy22_2) (by simp [intExprOps]))
          (by omega) ?_
        intro m₃ hm₃ hfp₃; subst hm₃
        have hnf₀₃ : NodeMemFrame ops m₀ (H3a.wWrite m₂ engScrTbl 24 (y : ℤ)) :=
          hnf₀₂.trans (NodeMemFrame.wWrite_scr hnf₀₂.1 24 (y : ℤ))
        let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
          NodeMemFrame ops m₀ m ∧
          wRead m engScrTbl 24 = (bFold k : ℤ) ∧
          (k = 0 ∨ rRead m engRealTbl 3 = ‖pts (bFold k) - pts y‖ ^ 2) ∧
          (∀ r, r < 24 → wRead m engScrTbl r = wRead m₂ engScrTbl r) ∧
          (∀ ri, ri < 2 → rRead m engRealTbl ri = rRead m₀ engRealTbl ri)
        have hmul_k : cp.k_base * (ops.C_read + 220 + 30 * cp.q_idx + 80 * d + 6) ≤
            cp.k_base * (ops.C_read + 240 + 30 * cp.q_idx + 80 * d) :=
          Nat.mul_le_mul_left cp.k_base (by omega)
        refine ExecDet.seq' 60
          (ExecDet.forLoop engScrTbl 25 cp.k_base _ Inv
            (ops.C_read + 220 + 30 * cp.q_idx + 80 * d)
            hfp₃ hT_scr (by omega) (by omega)
            ⟨hnf₀₃.trans (NodeMemFrame.wWrite_scr hnf₀₃.1 25 0),
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]; rfl,
             Or.inl rfl,
             fun r hr24 => by
               rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                   wRead_wWrite_of_ne _ _ (Or.inr (by omega))],
             fun ri hri2 => (hrr₂ engRealTbl (by decide) ri).trans (hrr₁ ri (by omega))⟩ ?_) (by omega) ?_
        · intro j hj m ⟨hnf_m, hb24_m, hsq3_m, hwr_m, hrr_m⟩ hctr_m hfp_m
          have hfold_succ : bFold (j + 1) = farthestValStep pts y j (bFold j) (samp ⟨j, hj⟩) := by
            dsimp only [bFold]
            rw [List.range_succ, List.foldl_append, List.foldl_cons, List.foldl_nil, dif_pos hj]
          refine (exec_baselineLoopStepStmt ops inp pts mn hj hsz bBits hslot
            hfp_m hnf_m.1 (hnf_m.2.1 mn slot hslot henc₀)
            ((hwr_m 20 (by decide)).trans hs20_2)
            ((hwr_m 22 (by decide)).trans hy22_2)
            ((hwr_m 23 (by decide)).trans hlen23')
            hb24_m hctr_m hsq3_m
            (fun c => (hnf_m.2.2.2 ptsRTbl (by decide) _).trans (hpts_cur y hy_cur c))
            (fun x hx c => (hnf_m.2.2.2 ptsRTbl (by decide) _).trans
              (hpts_cur x (List.mem_toFinset.mpr hx) c))
            (fun k => (hnf_m.2.2.1 coinTbl (by decide) (by decide) _).trans (hcoins k))).mono ?_ le_rfl
          intro m' ⟨hnf_s, hb24', hsq3', hctr', hwr_s, hrr_s⟩ _
          have hnf_tot := hnf_m.trans hnf_s
          refine ⟨hctr',
            hnf_tot.trans (NodeMemFrame.wWrite_scr hnf_tot.1 25 ((j : ℤ) + 1)),
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), hfold_succ]; exact hb24',
            Or.inr (by rw [rRead_wWrite, hfold_succ]; exact hsq3'),
            fun r hr24 => (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans
              ((hwr_s r hr24).trans (hwr_m r hr24)),
            fun ri hri2 => by rw [rRead_wWrite]; exact (hrr_s ri hri2).trans (hrr_m ri hri2)⟩
        · intro mL ⟨hnfL, hb24L, _, hwrL, hrrL⟩ hfpL
          have hy22L : wRead mL engScrTbl 22 = (y : ℤ) := (hwrL 22 (by decide)).trans hy22_2
          refine ExecDet.seq' 40
            (ExecDet.wWriteEq inp engScrTbl (.lit 12) (.lit 1) 12 1 hfpL hT_scr (by omega) (by omega)
              rfl rfl (by simp [intExprOps])) (by omega) ?_
          intro mA hmA hfpA; subst hmA
          refine ExecDet.seq' 20
            (ExecDet.wWriteEq inp engScrTbl (.lit 13) (.readHeap engScrTbl (.lit 22)) 13 (y : ℤ)
              hfpA hT_scr (by omega) (by omega) rfl
              (by simp only [evalIntExpr]; change wRead _ engScrTbl 22 = _
                  rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hy22L)
              (by simp [intExprOps])) (by omega) ?_
          intro mB hmB hfpB; subst hmB
          refine ExecDet.wWrite inp engScrTbl (.lit 14) (.readHeap engScrTbl (.lit 24))
            14 (bFold cp.k_base : ℤ) hfpB hT_scr (by omega) (by omega) rfl
            (by simp only [evalIntExpr]; change wRead _ engScrTbl 24 = _
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hb24L)
            (by simp [intExprOps]) ?_
          dsimp only; rw [hbp_eq]
          have hnfF : NodeMemFrame ops m₀
              (H3a.wWrite (H3a.wWrite (H3a.wWrite mL engScrTbl 12 1) engScrTbl 13 (y : ℤ))
                engScrTbl 14 (bFold cp.k_base : ℤ)) :=
            hnfL.trans (NodeMemFrame.of_scr_real hnfL.1
              (fun t ht i => by (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]))
              (fun _ _ _ => rfl))
          exact ⟨hnfF,
            ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
             wRead_wWrite_self _ _ _ _⟩,
            fun r hr => by
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
              exact (hwrL r (by omega)).trans ((hwr₂ r (by omega)).trans (hwr₁ r (by omega) (by omega) (by omega))),
            fun ri hri2 => hrrL ri hri2⟩
      · have hnot_sz : ¬ 1 ≤ mn.nd.denseArr.length := by
          simp only [evalArithCond, evalIntExpr] at hsz_f
          change decide ((1 : ℤ) ≤ wRead m₂ engScrTbl 23) = false at hsz_f
          rw [hlen23'] at hsz_f
          intro h1; exact of_decide_eq_false hsz_f (Int.ofNat_le.mpr h1)
        have hbp_eq : evalBaselinePair cp.hk_base cp.T_pow pts mn.nd.o mn.nd.denseArr
            (bitsToBaseSeedEquiv cp bBits) = some (y, y) := by
          unfold evalBaselinePair; rw [hmrh_eq]; dsimp only; rw [dif_neg hnot_sz]
        refine ExecDet.seq' 40
          (ExecDet.wWriteEq inp engScrTbl (.lit 12) (.lit 1) 12 1 hfp₂ hT_scr (by omega) (by omega)
            rfl rfl (by simp [intExprOps])) (by omega) ?_
        intro mA hmA hfpA; subst hmA
        refine ExecDet.seq' 20
          (ExecDet.wWriteEq inp engScrTbl (.lit 13) (.readHeap engScrTbl (.lit 22)) 13 (y : ℤ)
            hfpA hT_scr (by omega) (by omega) rfl
            (by simp only [evalIntExpr]; change wRead _ engScrTbl 22 = _
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hy22_2)
            (by simp [intExprOps])) (by omega) ?_
        intro mB hmB hfpB; subst hmB
        refine ExecDet.wWrite inp engScrTbl (.lit 14) (.readHeap engScrTbl (.lit 22))
          14 (y : ℤ) hfpB hT_scr (by omega) (by omega) rfl
          (by simp only [evalIntExpr]; change wRead _ engScrTbl 22 = _
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by decide))]; exact hy22_2)
          (by simp [intExprOps]) ?_
        dsimp only; rw [hbp_eq]
        have hnfF : NodeMemFrame ops m₀
            (H3a.wWrite (H3a.wWrite (H3a.wWrite m₂ engScrTbl 12 1) engScrTbl 13 (y : ℤ))
              engScrTbl 14 (y : ℤ)) :=
          hnf₀₂.trans (NodeMemFrame.of_scr_real hnf₀₂.1
            (fun t ht i => by (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]))
            (fun _ _ _ => rfl))
        exact ⟨hnfF,
          ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
           by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
           wRead_wWrite_self _ _ _ _⟩,
          fun r hr => by
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
            exact (hwr₂ r (by omega)).trans (hwr₁ r (by omega) (by omega) (by omega)),
          fun ri hri2 => (hrr₂ engRealTbl (by decide) ri).trans (hrr₁ ri (by omega))⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
