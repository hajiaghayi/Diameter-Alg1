import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG20_Stage4PrimC
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3a3
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 3. `evalBestGlobalAnswerStmt`: Global Candidate Fold & Header/Shadow Output -/

def writeCachedAnsNoneStmt : ArithRAMStmt :=
  .seq (.writeWordHeap 0 (.lit 1) (.lit 0))
  (.seq (.writeWordHeap 0 (.lit 2) (.lit 0))
  (.seq (.writeWordHeap 0 (.lit 3) (.lit 0))
  (.seq (.writeRealHeap 0 (.lit 0) (.ofInt (.lit 0)))
  (.seq (.writeWordHeap engMetaTbl (.lit 3) (.lit 0))
  (.seq (.writeWordHeap engMetaTbl (.lit 4) (.lit 0))
  (.seq (.writeWordHeap engMetaTbl (.lit 5) (.lit 0))
        (.writeRealHeap engRealTbl (.lit 0) (.ofInt (.lit 0)))))))))

def writeCachedAnsSomeStmt : ArithRAMStmt :=
  .seq (.writeWordHeap 0 (.lit 1) (.lit 1))
  (.seq (.writeWordHeap 0 (.lit 2) (.readHeap engScrTbl (.lit 10)))
  (.seq (.writeWordHeap 0 (.lit 3) (.readHeap engScrTbl (.lit 11)))
  (.seq (.writeRealHeap 0 (.lit 0) (.readRealHeap engRealTbl (.lit 1)))
  (.seq (.writeWordHeap engMetaTbl (.lit 3) (.lit 1))
  (.seq (.writeWordHeap engMetaTbl (.lit 4) (.readHeap engScrTbl (.lit 10)))
  (.seq (.writeWordHeap engMetaTbl (.lit 5) (.readHeap engScrTbl (.lit 11)))
        (.writeRealHeap engRealTbl (.lit 0) (.readRealHeap engRealTbl (.lit 1)))))))))

def evalBestGlobalAnswerStmt (d : ℕ) (candFoldStmt : ArithRAMStmt) : ArithRAMStmt :=
  .ite (.intLe (.lit 2) (.readHeap 0 (.lit 6)))
    (.seq (.writeWordHeap engScrTbl (.lit 10) (.readHeap 2 (.lit 0)))
    (.seq (.writeWordHeap engScrTbl (.lit 11) (.readHeap 2 (.lit 1)))
    (.seq (pairDistSqStmt 10 11 1 d)
    (.seq candFoldStmt
          writeCachedAnsSomeStmt))))
    writeCachedAnsNoneStmt

theorem zeroRand_evalBestGlobalAnswerStmt (d : ℕ) {candFoldStmt : ArithRAMStmt}
    (hc : ZeroRandStmt candFoldStmt) :
    ZeroRandStmt (evalBestGlobalAnswerStmt d candFoldStmt) :=
  .ite
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (zeroRand_pairDistSqStmt 10 11 1 d)
      (.seq hc
        (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
          (.seq (.writeRealHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
            (.seq (.writeWordHeap _ _ _) (.writeRealHeap _ _ _))))))))))))
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
      (.seq (.writeRealHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
        (.seq (.writeWordHeap _ _ _) (.writeRealHeap _ _ _))))))))

private noncomputable def writeCachedAnsMem (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ) : ArithRAMMemory :=
  H3a.rWrite
    (H3a.wWrite (H3a.wWrite (H3a.wWrite
      (H3a.rWrite
        (H3a.wWrite (H3a.wWrite (H3a.wWrite m 0 1 has) 0 2 u) 0 3 v)
        0 0 sq)
      engMetaTbl 3 has) engMetaTbl 4 u) engMetaTbl 5 v)
    engRealTbl 0 sq

private theorem writeCachedAnsMem_wRead_0_1 (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ) :
    wRead (writeCachedAnsMem m has u v sq) 0 1 = has := by
  unfold writeCachedAnsMem
  rw [wRead_rWrite]
  (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))])
  rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
      wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]

private theorem writeCachedAnsMem_wRead_0_2 (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ) :
    wRead (writeCachedAnsMem m has u v sq) 0 2 = u := by
  unfold writeCachedAnsMem
  rw [wRead_rWrite]
  (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))])
  rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]

private theorem writeCachedAnsMem_wRead_0_3 (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ) :
    wRead (writeCachedAnsMem m has u v sq) 0 3 = v := by
  unfold writeCachedAnsMem
  rw [wRead_rWrite]
  (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))])
  rw [wRead_rWrite, wRead_wWrite_self]

private theorem writeCachedAnsMem_wRead_0_other (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ)
    (i : ℤ) (h1 : i ≠ 1) (h2 : i ≠ 2) (h3 : i ≠ 3) :
    wRead (writeCachedAnsMem m has u v sq) 0 i = wRead m 0 i := by
  unfold writeCachedAnsMem
  rw [wRead_rWrite]
  (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))])
  rw [wRead_rWrite,
      wRead_wWrite_of_ne _ _ (Or.inr h3),
      wRead_wWrite_of_ne _ _ (Or.inr h2),
      wRead_wWrite_of_ne _ _ (Or.inr h1)]

private theorem writeCachedAnsMem_wRead_meta_3 (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ) :
    wRead (writeCachedAnsMem m has u v sq) engMetaTbl 3 = has := by
  unfold writeCachedAnsMem
  rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
      wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]

private theorem writeCachedAnsMem_wRead_meta_4 (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ) :
    wRead (writeCachedAnsMem m has u v sq) engMetaTbl 4 = u := by
  unfold writeCachedAnsMem
  rw [wRead_rWrite, wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]

private theorem writeCachedAnsMem_wRead_meta_5 (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ) :
    wRead (writeCachedAnsMem m has u v sq) engMetaTbl 5 = v := by
  unfold writeCachedAnsMem
  rw [wRead_rWrite, wRead_wWrite_self]

private theorem writeCachedAnsMem_wRead_meta_other (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ)
    (i : ℤ) (h3 : i ≠ 3) (h4 : i ≠ 4) (h5 : i ≠ 5) :
    wRead (writeCachedAnsMem m has u v sq) engMetaTbl i = wRead m engMetaTbl i := by
  unfold writeCachedAnsMem
  rw [wRead_rWrite,
      wRead_wWrite_of_ne _ _ (Or.inr h5),
      wRead_wWrite_of_ne _ _ (Or.inr h4),
      wRead_wWrite_of_ne _ _ (Or.inr h3),
      wRead_rWrite]
  (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))])

private theorem writeCachedAnsMem_wRead_other_tbl (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ)
    (t : ℕ) (ht0 : t ≠ 0) (ht6 : t ≠ engMetaTbl) (i : ℤ) :
    wRead (writeCachedAnsMem m has u v sq) t i = wRead m t i := by
  unfold writeCachedAnsMem
  rw [wRead_rWrite]
  (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht6)])
  rw [wRead_rWrite]
  (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht0)])

private theorem writeCachedAnsMem_rRead_0_0 (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ) :
    rRead (writeCachedAnsMem m has u v sq) 0 0 = sq := by
  unfold writeCachedAnsMem
  rw [rRead_rWrite_of_ne _ _ (Or.inl (by decide))]
  simp only [rRead_wWrite]
  exact rRead_rWrite_self _ _ _ _

private theorem writeCachedAnsMem_rRead_real_0 (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ) :
    rRead (writeCachedAnsMem m has u v sq) engRealTbl 0 = sq := by
  unfold writeCachedAnsMem
  exact rRead_rWrite_self _ _ _ _

private theorem writeCachedAnsMem_rRead_other_tbl (m : ArithRAMMemory) (has u v : ℤ) (sq : ℝ)
    (t : ℕ) (ht0 : t ≠ 0) (ht2 : t ≠ engRealTbl) (i : ℤ) :
    rRead (writeCachedAnsMem m has u v sq) t i = rRead m t i := by
  unfold writeCachedAnsMem
  rw [rRead_rWrite_of_ne _ _ (Or.inl ht2)]
  simp only [rRead_wWrite]
  rw [rRead_rWrite_of_ne _ _ (Or.inl ht0)]
  simp only [rRead_wWrite]

private theorem encChainEngine_with_cachedAns {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (st : ChainEngineState cp) (ans : StoredDiameterAnswer)
    (m₀ m₁ : ArithRAMMemory)
    (henc₀ : EncChainEngine ops st m₀)
    (hsr₁ : ops.SlotsReady m₁)
    (hans₁ : EncCachedAns ans m₁)
    (hnd : ∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁)
    (hw0 : ∀ i, 4 ≤ i → wRead m₁ 0 i = wRead m₀ 0 i)
    (hw123 : ∀ t, (t = 1 ∨ t = 2 ∨ t = 3 ∨ t = 7) → ∀ i, wRead m₁ t i = wRead m₀ t i)
    (hw6 : ∀ i, i ≠ 3 → i ≠ 4 → i ≠ 5 → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i)
    (hr1 : ∀ i, rRead m₁ ptsRTbl i = rRead m₀ ptsRTbl i) :
    EncChainEngine ops { st with cachedAns := ans } m₁ := by
  rcases henc₀ with ⟨_, hhp, _, hov, hleaf_le, hleaf_sp, hserv_le, hserv_len,
    servSlots, readySlots, curSlots, hslen, hserv, hjobs, hnodup, hlt⟩
  have hw7 : ∀ i, wRead m₁ engArrTbl i = wRead m₀ engArrTbl i := hw123 7 (Or.inr (Or.inr (Or.inr rfl)))
  refine ⟨hsr₁,
    ⟨(hw0 4 (by omega)).trans hhp.1,
     (hw0 5 (by omega)).trans hhp.2.1,
     (hw0 6 (by omega)).trans hhp.2.2.1,
     fun i hi => (hw123 1 (Or.inl rfl) _).trans (hhp.2.2.2.1 i hi),
     fun i hi => ⟨(hw123 2 (Or.inr (Or.inl rfl)) _).trans (hhp.2.2.2.2.1 i hi).1,
                  (hw123 3 (Or.inr (Or.inr (Or.inl rfl))) _).trans (hhp.2.2.2.2.1 i hi).2⟩,
     fun x hx c => (hr1 _).trans (hhp.2.2.2.2.2 x hx c)⟩,
    hans₁,
    (hw6 1 (by decide) (by decide) (by decide)).trans hov,
    hleaf_le,
    hleaf_sp.ext (hw6 2 (by decide) (by decide) (by decide)) (fun _ _ => hw7 _) (fun _ _ => hw7 _),
    hserv_le,
    (hw6 0 (by decide) (by decide) (by decide)).trans hserv_len,
    servSlots, readySlots, curSlots, hslen,
    fun i hi his => ⟨(hw6 (servSlotOff i) (by unfold servSlotOff; omega)
                        (by unfold servSlotOff; omega) (by unfold servSlotOff; omega)).trans
                        (hserv i hi his).1,
                     hnd _ _ (hlt _ (List.mem_append_left _ (List.getElem_mem his))) (hserv i hi his).2⟩,
    fun r => ?_,
    hnodup, hlt⟩
  have hlt_job : ∀ s ∈ jobUsedSlots (st.jobs r) (readySlots r) (curSlots r), s < M_slots cp :=
    fun s hs => hlt s (List.mem_append_right _ (List.mem_flatMap.mpr ⟨r, List.mem_finRange r, hs⟩))
  have hD : 0 ≤ (cp.D_max : ℤ) := Nat.cast_nonneg _
  have hr_nn : 0 ≤ (r.val : ℤ) := Nat.cast_nonneg _
  cases hjb : st.jobs r with
  | none =>
      have hj := hjobs r; rw [hjb] at hj
      exact ⟨hj.1, (hw6 _ (by unfold jobMetaBase; omega) (by unfold jobMetaBase; omega)
                      (by unfold jobMetaBase; omega)).trans hj.2⟩
  | some jb =>
      have hj := hjobs r; rw [hjb] at hj
      rcases hj with ⟨hact, hrle, hrlen, hwlen, hready, hph⟩
      have hb_ge : 16 ≤ jobMetaBase cp r.val := by unfold jobMetaBase; omega
      refine ⟨(hw6 _ (by omega) (by omega) (by omega)).trans hact,
        hrle, hrlen,
        (hw6 _ (by omega) (by omega) (by omega)).trans hwlen,
        fun q hq hqs => ?_, ?_⟩
      · have hrs_ge : 16 ≤ readySlotOff cp r.val q := by
          unfold readySlotOff; nlinarith
        have hsl_lt : (readySlots r)[q]'hqs < M_slots cp := by
          apply hlt_job
          unfold jobUsedSlots; rw [hjb]; dsimp only
          cases jb.phase
          · exact List.getElem_mem hqs
          · exact List.mem_append_left _ (List.getElem_mem hqs)
        exact ⟨(hw6 _ (by omega) (by omega) (by omega)).trans (hready q hq hqs).1,
               hnd _ _ hsl_lt (hready q hq hqs).2⟩
      · cases hjp : jb.phase with
        | copy cs =>
            simp only [hjp] at hph
            rcases hph with ⟨hp2, hp3, hp4, hsp⟩
            exact ⟨(hw6 _ (by omega) (by omega) (by omega)).trans hp2,
                   (hw6 _ (by omega) (by omega) (by omega)).trans hp3,
                   (hw6 _ (by omega) (by omega) (by omega)).trans hp4,
                   hsp.ext (hw6 _ (by omega) (by omega) (by omega)) (fun _ _ => hw7 _) (fun _ _ => hw7 _)⟩
        | build bs =>
            simp only [hjp] at hph
            rcases hph with ⟨hp2, hp3, hp4, hsp, hdsp, hcslot, hcenc⟩
            have hc_lt : curSlots r < M_slots cp := by
              apply hlt_job
              unfold jobUsedSlots; rw [hjb]; dsimp only; rw [hjp]; simp
            exact ⟨(hw6 _ (by omega) (by omega) (by omega)).trans hp2,
                   (hw6 _ (by omega) (by omega) (by omega)).trans hp3,
                   (hw6 _ (by omega) (by omega) (by omega)).trans hp4,
                   hsp.ext (hw6 _ (by omega) (by omega) (by omega)) (fun _ _ => hw7 _) (fun _ _ => hw7 _),
                   hdsp.ext (hw6 _ (by omega) (by omega) (by omega)) (fun _ _ => hw7 _) (fun _ _ => hw7 _),
                   (hw6 _ (by omega) (by omega) (by omega)).trans hcslot,
                   hnd _ _ hc_lt hcenc⟩

theorem exec_evalBestGlobalAnswerStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    {P' : DynamicPointSet d} {st : ChainEngineState cp}
    (cands : List (Option (ℕ × ℕ))) (candFoldStmt : ArithRAMStmt) (C_fold : ℕ)
    (hwf_hp : st.hp.WellFormed P')
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops st m₀)
    (hfold : ∀ (init : ℕ × ℕ) (m : ArithRAMMemory),
      InFootprint ops.TW ops.BW ops.TR ops.BR m →
      NodeMemFrame ops m₀ m →
      wRead m engScrTbl 10 = (init.1 : ℤ) →
      wRead m engScrTbl 11 = (init.2 : ℤ) →
      rRead m engRealTbl 1 = ‖st.hp.coords init.1 - st.hp.coords init.2‖ ^ 2 →
      let best := cands.foldl (stepBestGlobal st.hp.coords st.hp.actList) init
      ExecDet ops.TW ops.BW ops.TR ops.BR inp candFoldStmt m
        (fun m' =>
          NodeMemFrame ops m₀ m' ∧
          wRead m' engScrTbl 10 = (best.1 : ℤ) ∧
          wRead m' engScrTbl 11 = (best.2 : ℤ) ∧
          rRead m' engRealTbl 1 = ‖st.hp.coords best.1 - st.hp.coords best.2‖ ^ 2)
        C_fold) :
    let ans := evalBestGlobalAnswer st.hp.coords st.hp.actList cands
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (evalBestGlobalAnswerStmt d candFoldStmt) m₀
      (fun m₁ =>
        EncChainEngine ops { st with cachedAns := ans } m₁ ∧
        wRead m₁ 0 0 = wRead m₀ 0 0)
      (280 + 80 * d + C_fold) := by
  have hTW9 : 9 ≤ ops.TW := by have := ops.hTW; omega
  have hBW64 : 64 ≤ ops.BW := by have := ops.hBW_scr; unfold M_slots at this; omega
  have hBR16 : 16 ≤ ops.BR := by have := ops.hBR_eng; omega
  have hT_scr : engScrTbl < ops.TW := by show 8 < ops.TW; omega
  have hT_meta : engMetaTbl < ops.TW := by show 6 < ops.TW; omega
  have hT_real : engRealTbl < ops.TR := by have := ops.hTR; show 2 < ops.TR; omega
  have hT0 : 0 < ops.TW := by omega
  have hR0 : 0 < ops.TR := by have := ops.hTR; omega
  unfold evalBestGlobalAnswerStmt
  refine ExecDet.ite_le (C_c := 10) (C_b := 270 + 80 * d + C_fold) _ _ _
    (by simp [condExprOps, intExprOps])
    (fun hge2_b => ?_) (fun hlt2_b => ?_)
  · have h2 : 2 ≤ st.hp.actList.length := by
      simp only [evalArithCond, evalIntExpr] at hge2_b
      change decide ((2 : ℤ) ≤ wRead m₀ 0 6) = true at hge2_b
      rw [henc₀.2.1.2.2.1] at hge2_b
      exact Int.ofNat_le.mp (of_decide_eq_true hge2_b)
    let u0 := st.hp.actList[0]'(by omega)
    let v0 := st.hp.actList[1]'(by omega)
    have hu0_nf : u0 < st.hp.nextFresh := hwf_hp.2.2.2.2.1 u0 (List.getElem_mem _)
    have hv0_nf : v0 < st.hp.nextFresh := hwf_hp.2.2.2.2.1 v0 (List.getElem_mem _)
    refine ExecDet.seq' (255 + 80 * d + C_fold)
      (ExecDet.wWriteEq inp engScrTbl (.lit 10) (.readHeap 2 (.lit 0)) 10 (u0 : ℤ)
        hfp₀ hT_scr (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; exact (henc₀.2.1.2.2.2.2.1 0 (by omega)).1)
        (by simp [intExprOps])) (by omega) ?_
    intro m₁ hm₁ hfp₁; subst hm₁
    refine ExecDet.seq' (240 + 80 * d + C_fold)
      (ExecDet.wWriteEq inp engScrTbl (.lit 11) (.readHeap 2 (.lit 1)) 11 (v0 : ℤ)
        hfp₁ hT_scr (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; change wRead _ 2 1 = _
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
            exact (henc₀.2.1.2.2.2.2.1 1 (by omega)).1)
        (by simp [intExprOps])) (by omega) ?_
    intro m₂ hm₂ hfp₂; subst hm₂
    refine ExecDet.seq' (150 + C_fold)
      (exec_pairDistSqStmt inp st.hp.coords 10 11 1 hTW9 hBW64 ops.hTR hBR16
        (by omega) (by omega) (by omega) (by omega) hfp₂
        (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
        (wRead_wWrite_self _ _ _ _)
        (fun c => henc₀.2.1.2.2.2.2.2 u0 hu0_nf c)
        (fun c => henc₀.2.1.2.2.2.2.2 v0 hv0_nf c))
      (by omega) ?_
    intro m₃ ⟨hdsq₃, hwt₃, hwr₃, hrt₃, _⟩ hfp₃
    have hnf₀₃ : NodeMemFrame ops m₀ m₃ :=
      NodeMemFrame.of_scr_real henc₀.1
        (fun t ht i => (hwt₃ t ht i).trans
          ((wRead_wWrite_of_ne _ _ (Or.inl ht)).trans (wRead_wWrite_of_ne _ _ (Or.inl ht))))
        hrt₃
    refine ExecDet.seq' 150
      (hfold (u0, v0) m₃ hfp₃ hnf₀₃
        ((hwr₃ 10 (by decide)).trans
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]))
        ((hwr₃ 11 (by decide)).trans (wRead_wWrite_self _ _ _ _))
        hdsq₃)
      (by omega) ?_
    intro m₄ ⟨hnf₀₄, hb10, hb11, hbsq⟩ hfp₄
    let best := cands.foldl (stepBestGlobal st.hp.coords st.hp.actList) (u0, v0)
    let sq := ‖st.hp.coords best.1 - st.hp.coords best.2‖ ^ 2
    have hans_eq : evalBestGlobalAnswer st.hp.coords st.hp.actList cands =
        ({ diameterHandles := some best, cachedDistSq := sq } : StoredDiameterAnswer) :=
      evalBestGlobalAnswer_of_ge_two st.hp.coords h2 cands
    unfold writeCachedAnsSomeStmt
    refine ExecDet.seq' 135
      (ExecDet.wWriteEq inp 0 (.lit 1) (.lit 1) 1 1 hfp₄ hT0 (by omega) (by omega)
        rfl rfl (by simp [intExprOps])) (by omega) ?_
    intro ma1 hma1 hfpa1; subst hma1
    refine ExecDet.seq' 120
      (ExecDet.wWriteEq inp 0 (.lit 2) (.readHeap engScrTbl (.lit 10)) 2 (best.1 : ℤ)
        hfpa1 hT0 (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; change wRead _ engScrTbl 10 = _
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]; exact hb10)
        (by simp [intExprOps])) (by omega) ?_
    intro ma2 hma2 hfpa2; subst hma2
    refine ExecDet.seq' 105
      (ExecDet.wWriteEq inp 0 (.lit 3) (.readHeap engScrTbl (.lit 11)) 3 (best.2 : ℤ)
        hfpa2 hT0 (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; change wRead _ engScrTbl 11 = _
            (iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]); exact hb11)
        (by simp [intExprOps])) (by omega) ?_
    intro ma3 hma3 hfpa3; subst hma3
    refine ExecDet.seq' 75
      (ExecDet.rWriteEq inp 0 (.lit 0) (.readRealHeap engRealTbl (.lit 1))
        0 sq
        hfpa3 hR0 (by omega) (by omega) rfl
        (by simp only [evalRealExpr, evalIntExpr]; change rRead _ engRealTbl 1 = _
            simp only [rRead_wWrite]; exact hbsq)
        (by simp [intExprOps, realExprOps])) (by omega) ?_
    intro ma4 hma4 hfpa4; subst hma4
    refine ExecDet.seq' 60
      (ExecDet.wWriteEq inp engMetaTbl (.lit 3) (.lit 1) 3 1 hfpa4 hT_meta (by omega) (by omega)
        rfl rfl (by simp [intExprOps])) (by omega) ?_
    intro ma5 hma5 hfpa5; subst hma5
    refine ExecDet.seq' 45
      (ExecDet.wWriteEq inp engMetaTbl (.lit 4) (.readHeap engScrTbl (.lit 10)) 4 (best.1 : ℤ)
        hfpa5 hT_meta (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; change wRead _ engScrTbl 10 = _
            rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_rWrite]
            (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]); exact hb10)
        (by simp [intExprOps])) (by omega) ?_
    intro ma6 hma6 hfpa6; subst hma6
    refine ExecDet.seq' 30
      (ExecDet.wWriteEq inp engMetaTbl (.lit 5) (.readHeap engScrTbl (.lit 11)) 5 (best.2 : ℤ)
        hfpa6 hT_meta (by omega) (by omega) rfl
        (by simp only [evalIntExpr]; change wRead _ engScrTbl 11 = _
            (iterate 2 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]); rw [wRead_rWrite]
            (iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]); exact hb11)
        (by simp [intExprOps])) (by omega) ?_
    intro ma7 hma7 hfpa7; subst hma7
    refine ExecDet.rWrite inp engRealTbl (.lit 0) (.readRealHeap engRealTbl (.lit 1))
      0 sq
      hfpa7 hT_real (by omega) (by omega) rfl
      (by simp only [evalRealExpr, evalIntExpr]; change rRead _ engRealTbl 1 = _
          simp only [rRead_wWrite]; rw [rRead_rWrite_of_ne _ _ (Or.inl (by decide))]
          simp only [rRead_wWrite]; exact hbsq)
      (by simp [intExprOps, realExprOps]) ?_
    change (let ans := evalBestGlobalAnswer st.hp.coords st.hp.actList cands
      EncChainEngine ops { st with cachedAns := ans }
        (writeCachedAnsMem m₄ 1 (best.1 : ℤ) (best.2 : ℤ) sq) ∧
      wRead (writeCachedAnsMem m₄ 1 (best.1 : ℤ) (best.2 : ℤ) sq) 0 0 = wRead m₀ 0 0)
    dsimp only; rw [hans_eq]
    set mF := writeCachedAnsMem m₄ 1 (best.1 : ℤ) (best.2 : ℤ) sq
    have hwF_ge9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead m₄ t i :=
      fun t ht9 _ i => writeCachedAnsMem_wRead_other_tbl _ _ _ _ _ t (by omega)
        (by unfold engMetaTbl; omega) i
    have hrF_ge3 : ∀ t, 3 ≤ t → t < ops.TR → ∀ i, rRead mF t i = rRead m₄ t i :=
      fun t ht3 _ i => writeCachedAnsMem_rRead_other_tbl _ _ _ _ _ t (by omega)
        (by unfold engRealTbl; omega) i
    have hrF_14 : ∀ i, rRead mF ptsRTbl i = rRead m₄ ptsRTbl i :=
      fun i => writeCachedAnsMem_rRead_other_tbl _ _ _ _ _ ptsRTbl (by decide) (by decide) i
    have hansF : EncCachedAns ({ diameterHandles := some best, cachedDistSq := sq } : StoredDiameterAnswer) mF := by
      have hw0_1 : mF.words.read (.heap 0 1) = 1 := writeCachedAnsMem_wRead_0_1 _ _ _ _ _
      have hw0_2 : mF.words.read (.heap 0 2) = (best.1 : ℤ) := writeCachedAnsMem_wRead_0_2 _ _ _ _ _
      have hw0_3 : mF.words.read (.heap 0 3) = (best.2 : ℤ) := writeCachedAnsMem_wRead_0_3 _ _ _ _ _
      have hr0_0 : mF.reals.read (.heap 0 0) = sq := writeCachedAnsMem_rRead_0_0 _ _ _ _ _
      refine ⟨?_, writeCachedAnsMem_rRead_real_0 _ _ _ _ _,
        writeCachedAnsMem_wRead_meta_3 _ _ _ _ _,
        writeCachedAnsMem_wRead_meta_4 _ _ _ _ _,
        writeCachedAnsMem_wRead_meta_5 _ _ _ _ _⟩
      unfold ArithRAMDynamicProgram.readCachedAnswer
      simp only [hw0_1, hw0_2, hw0_3, hr0_0, Int.natCast_nonneg, Int.toNat_natCast,
        and_self, ↓reduceIte, Prod.mk.eta]
    refine ⟨encChainEngine_with_cachedAns ops st _ m₀ mF henc₀
      (ops.slotsReady_ext m₄ mF hnf₀₄.1 hwF_ge9 hrF_ge3)
      hansF
      (fun mn s hs he => ops.encNode_ext mn s m₄ mF (hnf₀₄.2.1 mn s hs he) hwF_ge9 hrF_ge3
        (fun _ _ _ _ => hrF_14 _))
      (fun i hi4 => (writeCachedAnsMem_wRead_0_other _ _ _ _ _ i (by omega) (by omega) (by omega)).trans
        (hnf₀₄.2.2.1 0 (by decide) (by decide) i))
      (fun t ht i => (writeCachedAnsMem_wRead_other_tbl _ _ _ _ _ t
        (by rcases ht with rfl | rfl | rfl | rfl <;> decide)
        (by rcases ht with rfl | rfl | rfl | rfl <;> decide) i).trans
        (hnf₀₄.2.2.1 t (by rcases ht with rfl | rfl | rfl | rfl <;> decide)
          (by rcases ht with rfl | rfl | rfl | rfl <;> decide) i))
      (fun i hi3 hi4 hi5 => (writeCachedAnsMem_wRead_meta_other _ _ _ _ _ i hi3 hi4 hi5).trans
        (hnf₀₄.2.2.1 engMetaTbl (by decide) (by decide) i))
      (fun i => (hrF_14 i).trans (hnf₀₄.2.2.2 ptsRTbl (by decide) i)),
      (writeCachedAnsMem_wRead_0_other _ _ _ _ _ 0 (by decide) (by decide) (by decide)).trans
        (hnf₀₄.2.2.1 0 (by decide) (by decide) 0)⟩
  · have hnot2 : ¬ 2 ≤ st.hp.actList.length := by
      simp only [evalArithCond, evalIntExpr] at hlt2_b
      change decide ((2 : ℤ) ≤ wRead m₀ 0 6) = false at hlt2_b
      rw [henc₀.2.1.2.2.1] at hlt2_b
      intro h2; exact of_decide_eq_false hlt2_b (Int.ofNat_le.mpr h2)
    have hans_eq : evalBestGlobalAnswer st.hp.coords st.hp.actList cands =
        ({ diameterHandles := none, cachedDistSq := 0 } : StoredDiameterAnswer) :=
      evalBestGlobalAnswer_of_lt_two st.hp.coords hnot2 cands
    unfold writeCachedAnsNoneStmt
    refine ExecDet.seq' 135
      (ExecDet.wWriteEq inp 0 (.lit 1) (.lit 0) 1 0 hfp₀ hT0 (by omega) (by omega)
        rfl rfl (by simp [intExprOps])) (by omega) ?_
    intro mb1 hmb1 hfpb1; subst hmb1
    refine ExecDet.seq' 120
      (ExecDet.wWriteEq inp 0 (.lit 2) (.lit 0) 2 0 hfpb1 hT0 (by omega) (by omega)
        rfl rfl (by simp [intExprOps])) (by omega) ?_
    intro mb2 hmb2 hfpb2; subst hmb2
    refine ExecDet.seq' 105
      (ExecDet.wWriteEq inp 0 (.lit 3) (.lit 0) 3 0 hfpb2 hT0 (by omega) (by omega)
        rfl rfl (by simp [intExprOps])) (by omega) ?_
    intro mb3 hmb3 hfpb3; subst hmb3
    refine ExecDet.seq' 75
      (ExecDet.rWriteEq inp 0 (.lit 0) (.ofInt (.lit 0)) 0 0 hfpb3 hR0 (by omega) (by omega)
        rfl (by simp [evalRealExpr, evalIntExpr]) (by simp [intExprOps, realExprOps])) (by omega) ?_
    intro mb4 hmb4 hfpb4; subst hmb4
    refine ExecDet.seq' 60
      (ExecDet.wWriteEq inp engMetaTbl (.lit 3) (.lit 0) 3 0 hfpb4 hT_meta (by omega) (by omega)
        rfl rfl (by simp [intExprOps])) (by omega) ?_
    intro mb5 hmb5 hfpb5; subst hmb5
    refine ExecDet.seq' 45
      (ExecDet.wWriteEq inp engMetaTbl (.lit 4) (.lit 0) 4 0 hfpb5 hT_meta (by omega) (by omega)
        rfl rfl (by simp [intExprOps])) (by omega) ?_
    intro mb6 hmb6 hfpb6; subst hmb6
    refine ExecDet.seq' 30
      (ExecDet.wWriteEq inp engMetaTbl (.lit 5) (.lit 0) 5 0 hfpb6 hT_meta (by omega) (by omega)
        rfl rfl (by simp [intExprOps])) (by omega) ?_
    intro mb7 hmb7 hfpb7; subst hmb7
    refine ExecDet.rWrite inp engRealTbl (.lit 0) (.ofInt (.lit 0)) 0 0 hfpb7 hT_real
      (by omega) (by omega) rfl (by simp [evalRealExpr, evalIntExpr])
      (by simp [intExprOps, realExprOps]) ?_
    change (let ans := evalBestGlobalAnswer st.hp.coords st.hp.actList cands
      EncChainEngine ops { st with cachedAns := ans } (writeCachedAnsMem m₀ 0 0 0 0) ∧
      wRead (writeCachedAnsMem m₀ 0 0 0 0) 0 0 = wRead m₀ 0 0)
    dsimp only; rw [hans_eq]
    set mG := writeCachedAnsMem m₀ 0 0 0 0
    have hwG_ge9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mG t i = wRead m₀ t i :=
      fun t ht9 _ i => writeCachedAnsMem_wRead_other_tbl _ _ _ _ _ t (by omega)
        (by unfold engMetaTbl; omega) i
    have hrG_ge3 : ∀ t, 3 ≤ t → t < ops.TR → ∀ i, rRead mG t i = rRead m₀ t i :=
      fun t ht3 _ i => writeCachedAnsMem_rRead_other_tbl _ _ _ _ _ t (by omega)
        (by unfold engRealTbl; omega) i
    have hrG_1 : ∀ i, rRead mG ptsRTbl i = rRead m₀ ptsRTbl i :=
      fun i => writeCachedAnsMem_rRead_other_tbl _ _ _ _ _ ptsRTbl (by decide) (by decide) i
    have hansG : EncCachedAns ({ diameterHandles := none, cachedDistSq := 0 } : StoredDiameterAnswer) mG := by
      have hw0_1 : mG.words.read (.heap 0 1) = 0 := writeCachedAnsMem_wRead_0_1 _ _ _ _ _
      have hr0_0 : mG.reals.read (.heap 0 0) = 0 := writeCachedAnsMem_rRead_0_0 _ _ _ _ _
      refine ⟨?_, writeCachedAnsMem_rRead_real_0 _ _ _ _ _,
        writeCachedAnsMem_wRead_meta_3 _ _ _ _ _,
        writeCachedAnsMem_wRead_meta_4 _ _ _ _ _,
        writeCachedAnsMem_wRead_meta_5 _ _ _ _ _⟩
      unfold ArithRAMDynamicProgram.readCachedAnswer
      simp [hw0_1, hr0_0]
    refine ⟨encChainEngine_with_cachedAns ops st _ m₀ mG henc₀
      (ops.slotsReady_ext m₀ mG henc₀.1 hwG_ge9 hrG_ge3)
      hansG
      (fun mn s _ he => ops.encNode_ext mn s m₀ mG he hwG_ge9 hrG_ge3 (fun _ _ _ _ => hrG_1 _))
      (fun i hi4 => writeCachedAnsMem_wRead_0_other _ _ _ _ _ i (by omega) (by omega) (by omega))
      (fun t ht i => writeCachedAnsMem_wRead_other_tbl _ _ _ _ _ t
        (by rcases ht with rfl | rfl | rfl | rfl <;> decide)
        (by rcases ht with rfl | rfl | rfl | rfl <;> decide) i)
      (fun i hi3 hi4 hi5 => writeCachedAnsMem_wRead_meta_other _ _ _ _ _ i hi3 hi4 hi5)
      hrG_1,
      writeCachedAnsMem_wRead_0_other _ _ _ _ _ 0 (by decide) (by decide) (by decide)⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
