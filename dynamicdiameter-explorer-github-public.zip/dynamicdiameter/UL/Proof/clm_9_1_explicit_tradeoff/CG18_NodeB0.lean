import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeA

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

/-! ### 1. Squared Distance to Center, `inCoreBallCond`, `inCoreBallStmt` & `passesNodeStmt` -/

theorem norm_sq_sub_eq_sum_coord {d : ℕ} (x y : EuclideanSpace ℝ (Fin d)) :
    ‖x - y‖ ^ 2 = ∑ c : Fin d, (euclideanCoord x c - euclideanCoord y c) ^ 2 := by
  rw [EuclideanSpace.norm_eq, Real.sq_sqrt (Finset.sum_nonneg fun _ _ => sq_nonneg _)]
  refine Finset.sum_congr rfl (fun c _ => ?_)
  simp [euclideanCoord, sq_abs]

def sqDistPtCenterStmt (scrW scrR tblR : ℕ)
    (wOffO wUid wCtr rAcc rDiff : ℤ) (d : ℕ) : ArithRAMStmt :=
  .seq (.writeRealHeap scrR (.lit rAcc) (.ofInt (.lit 0)))
    (forLoopStmt scrW wCtr d
      (.seq
        (.writeRealHeap scrR (.lit rDiff)
          (.sub (.readRealHeap 1 (.add (.mul (.readHeap scrW (.lit wUid)) (.lit (d : ℤ)))
                                       (.readHeap scrW (.lit wCtr))))
                (.readRealHeap tblR (.add (.readHeap scrW (.lit wOffO))
                                          (.readHeap scrW (.lit wCtr))))))
        (.writeRealHeap scrR (.lit rAcc)
          (.add (.readRealHeap scrR (.lit rAcc))
                (.mul (.readRealHeap scrR (.lit rDiff)) (.readRealHeap scrR (.lit rDiff)))))))

theorem hzr_sqDistPtCenterStmt (scrW scrR tblR : ℕ)
    (wOffO wUid wCtr rAcc rDiff : ℤ) (d : ℕ) :
    HeapZeroRandStmt (sqDistPtCenterStmt scrW scrR tblR wOffO wUid wCtr rAcc rDiff d) := by
  unfold sqDistPtCenterStmt forLoopStmt
  repeat' constructor

theorem exec_sqDistPtCenterStmt {d TW BW TR BR scrW scrR tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wOffO wUid wCtr rAcc rDiff offO : ℤ) (uid : ℕ)
    (pt o : EuclideanSpace ℝ (Fin d))
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneR : tblR ≠ scrR) (hne1 : 1 ≠ scrR)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (hrAcc : 0 ≤ rAcc ∧ rAcc < (BR : ℤ))
    (hrDiff : 0 ≤ rDiff ∧ rDiff < (BR : ℤ))
    (hneRD : rAcc ≠ rDiff)
    (hneCtr : wOffO ≠ wCtr ∧ wUid ≠ wCtr)
    (hoffO_r : H3a.wRead m₀ scrW wOffO = offO)
    (huid_r : H3a.wRead m₀ scrW wUid = (uid : ℤ))
    (hpt : ∀ c : Fin d, H3a.rRead m₀ 1 (((uid * d + c.val : ℕ) : ℤ)) = euclideanCoord pt c)
    (ho : ∀ c : Fin d, H3a.rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (sqDistPtCenterStmt scrW scrR tblR wOffO wUid wCtr rAcc rDiff d) m₀ m₁
        (60 + 55 * d) ∧
      InFootprint TW BW TR BR m₁ ∧
      H3a.rRead m₁ scrR rAcc = ‖pt - o‖ ^ 2 ∧
      (∀ w, w ≠ wCtr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, r ≠ rAcc → r ≠ rDiff → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      PreservesNonScratch scrW scrR m₀ m₁ := by
  let pSq : ℕ → ℝ := fun k =>
    ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k),
      (euclideanCoord pt c - euclideanCoord o c) ^ 2
  have hex : ExecScratch TW BW TR BR scrW scrR inp
      (sqDistPtCenterStmt scrW scrR tblR wOffO wUid wCtr rAcc rDiff d) m₀
      (fun m₁ =>
        H3a.rRead m₁ scrR rAcc = ‖pt - o‖ ^ 2 ∧
        (∀ w, w ≠ wCtr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
        (∀ r, r ≠ rAcc → r ≠ rDiff → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r))
      (60 + 55 * d) := by
    unfold sqDistPtCenterStmt
    refine ExecScratch.seq' (45 + 55 * d)
      (ExecScratch.rSetScr inp (.lit rAcc) (.ofInt (.lit 0)) rAcc 0
        hfp₀ hscrR hrAcc.1 hrAcc.2 rfl (by simp [evalRealExpr, evalIntExpr])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun m => m = H3a.rWrite m₀ scrR rAcc 0) rfl)
      (by omega)
      (fun ma hpr_a hma hfp_a => ?_)
    let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
      H3a.rRead m scrR rAcc = pSq k ∧
      (∀ w, w ≠ wCtr → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, r ≠ rAcc → r ≠ rDiff → H3a.rRead m scrR r = H3a.rRead m₀ scrR r)
    refine (ExecScratch.forLoop wCtr d _ Inv 45 hfp_a hscrW hwCtr.1 hwCtr.2 ?_ ?_ ?_).mono
      (fun m₂ _ ⟨hacc, hw_keep, hr_keep⟩ _ => ?_) (by omega)
    · subst hma
      refine ⟨by rw [rRead_wWrite, rRead_rWrite_self]; simp [pSq],
        fun w hw => by rw [wRead_wWrite_of_ne _ _ (Or.inr hw), wRead_rWrite],
        fun r hr1 _ => by rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr hr1)]⟩
    · intro k hk m hpr_m ⟨haccm, hwm, hrm⟩ hctr hfp_m
      have hpr_tot := hpr_a.trans hpr_m
      let ck : Fin d := ⟨k, hk⟩
      have hpt_k : H3a.rRead m 1 ((uid : ℤ) * (d : ℤ) + (k : ℤ)) = euclideanCoord pt ck := by
        rw [hpr_tot.2 1 hne1]
        have hcast : ((uid * d + k : ℕ) : ℤ) = (uid : ℤ) * (d : ℤ) + (k : ℤ) := by push_cast; ring
        rw [← hcast]; exact hpt ck
      have ho_k : H3a.rRead m tblR (offO + (k : ℤ)) = euclideanCoord o ck := by
        rw [hpr_tot.2 tblR hneR]; exact ho ck
      have hoffO_m : H3a.wRead m scrW wOffO = offO := (hwm wOffO hneCtr.1).trans hoffO_r
      have huid_m : H3a.wRead m scrW wUid = (uid : ℤ) := (hwm wUid hneCtr.2).trans huid_r
      let diffVal : ℝ := euclideanCoord pt ck - euclideanCoord o ck
      refine ExecScratch.seq' 22
        (ExecScratch.rSetScr inp (.lit rDiff) _ rDiff diffVal
          hfp_m hscrR hrDiff.1 hrDiff.2 rfl
          (by change H3a.rRead m 1 (H3a.wRead m scrW wUid * (d : ℤ) + H3a.wRead m scrW wCtr) -
                H3a.rRead m tblR (H3a.wRead m scrW wOffO + H3a.wRead m scrW wCtr) = diffVal
              rw [huid_m, hoffO_m, hctr, hpt_k, ho_k])
          (by dsimp [intExprOps, realExprOps]; omega)
          (Post := fun mx => mx = H3a.rWrite m scrR rDiff diffVal) rfl)
        (by omega)
        (fun mx _ hmx hfp_x => ?_)
      have hsplit : (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k + 1) =
          insert ck ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by
        ext c; simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, Fin.ext_iff, ck]; omega
      have hnot : ck ∉ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k) := by simp [ck]
      have hpSq_s : pSq (k + 1) = pSq k + diffVal ^ 2 := by
        dsimp [pSq, diffVal]; rw [hsplit, Finset.sum_insert hnot, add_comm]
      refine ExecScratch.rSetScr inp (.lit rAcc) _ rAcc (pSq (k + 1))
        hfp_x hscrR hrAcc.1 hrAcc.2 rfl
        (by subst hmx
            change H3a.rRead (H3a.rWrite m scrR rDiff diffVal) scrR rAcc +
              H3a.rRead (H3a.rWrite m scrR rDiff diffVal) scrR rDiff *
              H3a.rRead (H3a.rWrite m scrR rDiff diffVal) scrR rDiff = pSq (k + 1)
            rw [rRead_rWrite_of_ne _ _ (Or.inr hneRD), rRead_rWrite_self, haccm, hpSq_s, sq])
        (by dsimp [intExprOps, realExprOps]; omega) ?_
      subst hmx
      refine ⟨by rw [wRead_rWrite, wRead_rWrite]; exact hctr,
        rRead_rWrite_self _ _ _ _,
        fun w hw => by rw [wRead_rWrite, wRead_rWrite]; exact hwm w hw,
        fun r hr1 hr2 => by
          rw [rRead_rWrite_of_ne _ _ (Or.inr hr1), rRead_rWrite_of_ne _ _ (Or.inr hr2)]
          exact hrm r hr1 hr2⟩
    · intro k m v ⟨h1, h2, h3⟩
      exact ⟨by rw [rRead_wWrite]; exact h1,
             fun w hw => by rw [wRead_wWrite_of_ne _ _ (Or.inr hw)]; exact h2 w hw,
             fun r hr1 hr2 => by rw [rRead_wWrite]; exact h3 r hr1 hr2⟩
    · have hpSq_d : pSq d = ‖pt - o‖ ^ 2 := by
        rw [norm_sq_sub_eq_sum_coord]
        dsimp [pSq]
        refine Finset.sum_congr (by ext c; simp) (fun _ _ => rfl)
      exact ⟨hacc.trans hpSq_d, hw_keep, hr_keep⟩
  obtain ⟨m₁, hpr, ⟨hacc, hw, hr⟩, hfp₁, hdet⟩ :=
    execScratch_to_detExec (hzr_sqDistPtCenterStmt _ _ _ _ _ _ _ _ _) hfp₀ hex
  exact ⟨m₁, hdet, hfp₁, hacc, hw, hr, hpr⟩

/-- Exact `ArithCondExpr` evaluating `H4c2.inCoreBall o V pt` from `(scrR, rAcc) = ‖pt - o‖^2` and `(tblR, offV) = V`. -/
def inCoreBallCond (scrW scrR tblR : ℕ) (wOffV rAcc : ℤ) : ArithCondExpr :=
  .realLe (.readRealHeap scrR (.lit rAcc)) (.readRealHeap tblR (.readHeap scrW (.lit wOffV)))

theorem cVal_inCoreBallCond {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (scrW scrR tblR : ℕ) (wOffV rAcc offV : ℤ)
    (o pt : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (hoffV : H3a.wRead m scrW wOffV = offV)
    (hrAcc : H3a.rRead m scrR rAcc = ‖pt - o‖ ^ 2)
    (hV : H3a.rRead m tblR offV = V) :
    cValAt 0 inp m (inCoreBallCond scrW scrR tblR wOffV rAcc) = inCoreBall o V pt := by
  simp only [cValAt, inCoreBallCond, evalArithCond, evalRealExpr, evalIntExpr]
  change decide (H3a.rRead m scrR rAcc ≤ H3a.rRead m tblR (H3a.wRead m scrW wOffV)) = inCoreBall o V pt
  rw [hoffV, hrAcc, hV]
  rfl

/-- Compute `inCoreBall o V (pts uid)` (if `invert = false`) or `!inCoreBall o V (pts uid)` (if `invert = true`)
into `(scrW, wOut) ∈ {0, 1}` given `nodeBaseR` in `(scrW, wNodeBaseR)` and `uid` in `(scrW, wUid)`. -/
def coreBallTestStmt (invert : Bool) (scrW scrR tblR : ℕ)
    (wNodeBaseR wUid wOut wScr rScr : ℤ) (d : ℕ) : ArithRAMStmt :=
  let wOffO := wScr
  let wOffV := wScr + 1
  let wCtr := wScr + 2
  let rAcc := rScr
  let rDiff := rScr + 1
  let tVal : ℤ := if invert then 0 else 1
  let fVal : ℤ := if invert then 1 else 0
  .seq (.writeWordHeap scrW (.lit wOffO) (.readHeap scrW (.lit wNodeBaseR)))
  (.seq (.writeWordHeap scrW (.lit wOffV)
          (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit ((d : ℤ) + 1))))
  (.seq (sqDistPtCenterStmt scrW scrR tblR wOffO wUid wCtr rAcc rDiff d)
        (.ite (inCoreBallCond scrW scrR tblR wOffV rAcc)
          (.writeWordHeap scrW (.lit wOut) (.lit tVal))
          (.writeWordHeap scrW (.lit wOut) (.lit fVal)))))

abbrev inCoreBallStmt := coreBallTestStmt false
abbrev passesNodeStmt := coreBallTestStmt true

theorem hzr_coreBallTestStmt (invert : Bool) (scrW scrR tblR : ℕ)
    (wNodeBaseR wUid wOut wScr rScr : ℤ) (d : ℕ) :
    HeapZeroRandStmt (coreBallTestStmt invert scrW scrR tblR wNodeBaseR wUid wOut wScr rScr d) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (hzr_sqDistPtCenterStmt _ _ _ _ _ _ _ _ _)
          (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))

theorem zeroRand_inCoreBallStmt (scrW scrR tblR : ℕ)
    (wNodeBaseR wUid wOut wScr rScr : ℤ) (d : ℕ) :
    ZeroRandStmt (inCoreBallStmt scrW scrR tblR wNodeBaseR wUid wOut wScr rScr d) :=
  hzr_to_zeroRand (hzr_coreBallTestStmt false _ _ _ _ _ _ _ _ _)

theorem zeroRand_passesNodeStmt (scrW scrR tblR : ℕ)
    (wNodeBaseR wUid wOut wScr rScr : ℤ) (d : ℕ) :
    ZeroRandStmt (passesNodeStmt scrW scrR tblR wNodeBaseR wUid wOut wScr rScr d) :=
  hzr_to_zeroRand (hzr_coreBallTestStmt true _ _ _ _ _ _ _ _ _)

theorem exec_coreBallTestStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (invert : Bool) (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wNodeBaseR wUid wOut wScr rScr nodeBaseR : ℤ) (uid : ℕ)
    (pt o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hne1 : 1 ≠ scrR)
    (hwBR : 0 ≤ wNodeBaseR ∧ wNodeBaseR < wScr)
    (hwUid : 0 ≤ wUid ∧ wUid < wScr)
    (hwOut : 0 ≤ wOut ∧ wOut < (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 3 ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + 2 ≤ (BR : ℤ))
    (hbR : H3a.wRead m₀ scrW wNodeBaseR = nodeBaseR)
    (huid : H3a.wRead m₀ scrW wUid = (uid : ℤ))
    (hpt : ∀ c : Fin d, H3a.rRead m₀ 1 (((uid * d + c.val : ℕ) : ℤ)) = euclideanCoord pt c)
    (ho : ∀ c : Fin d, H3a.rRead m₀ tblR (nodeCenterROff nodeBaseR + (c.val : ℤ)) = euclideanCoord o c)
    (hV : H3a.rRead m₀ tblR (nodeVarROff d nodeBaseR) = V) :
    let resBool : Bool := if invert then !inCoreBall o V pt else inCoreBall o V pt
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (coreBallTestStmt invert scrW scrR tblR wNodeBaseR wUid wOut wScr rScr d)
        m₀ m₁ (120 + 55 * d) ∧
      InFootprint TW BW TR BR m₁ ∧
      H3a.wRead m₁ scrW wOut = (if resBool then 1 else 0) ∧
      (∀ w, w < wScr → w ≠ wOut → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW 0 0 tblR 0 0 m₀ m₁ := by
  intro resBool
  let m1 := H3a.wWrite m₀ scrW wScr nodeBaseR
  let m2 := H3a.wWrite m1 scrW (wScr + 1) (nodeBaseR + ((d : ℤ) + 1))
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.readHeap scrW (.lit wNodeBaseR))) m₀ m1 15 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW _ _ rfl hbR
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW hwScr.1 (by omega)
  have hbR1 : H3a.wRead m1 scrW wNodeBaseR = nodeBaseR := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR]
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
      (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit ((d : ℤ) + 1)))) m1 m2 15 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW _ _ rfl
      (by change H3a.wRead m1 scrW wNodeBaseR + ((d : ℤ) + 1) = _; rw [hbR1])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 hscrW (by omega) (by omega)
  have huid2 : H3a.wRead m2 scrW wUid = (uid : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)), huid]
  have hoffO2 : H3a.wRead m2 scrW wScr = nodeBaseR := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
  have hoffV2 : H3a.wRead m2 scrW (wScr + 1) = nodeBaseR + ((d : ℤ) + 1) :=
    wRead_wWrite_self _ _ _ _
  obtain ⟨m3, hd3, hfp3, hacc3, hw3, _, hpr3⟩ :=
    exec_sqDistPtCenterStmt inp wScr wUid (wScr + 2) rScr (rScr + 1) nodeBaseR uid pt o
      hfp2 hscrW hscrR hneR hne1 ⟨by omega, by omega⟩ ⟨hrScr.1, by omega⟩ ⟨by omega, by omega⟩
      (by omega) ⟨by omega, by omega⟩ hoffO2 huid2 hpt ho
  have hoffV3 : H3a.wRead m3 scrW (wScr + 1) = nodeVarROff d nodeBaseR := by
    rw [hw3 (wScr + 1) (by omega), hoffV2]; unfold nodeVarROff; ring
  have hV3 : H3a.rRead m3 tblR (nodeVarROff d nodeBaseR) = V := by
    rw [hpr3.2 tblR hneR]; exact hV
  have hcond := cVal_inCoreBallCond inp m3 scrW scrR tblR (wScr + 1) rScr (nodeVarROff d nodeBaseR)
    o pt V hoffV3 hacc3 hV3
  let tVal : ℤ := if invert then 0 else 1
  let fVal : ℤ := if invert then 1 else 0
  by_cases hcb : inCoreBall o V pt = true
  · have hc_t : cValAt 0 inp m3 (inCoreBallCond scrW scrR tblR (wScr + 1) rScr) = true :=
      hcond.trans hcb
    let m4 := H3a.wWrite m3 scrW wOut tVal
    have hd4 : DetExec inp (.ite (inCoreBallCond scrW scrR tblR (wScr + 1) rScr)
        (.writeWordHeap scrW (.lit wOut) (.lit tVal))
        (.writeWordHeap scrW (.lit wOut) (.lit fVal))) m3 m4 30 :=
      DetExecAt.ite_true hc_t (C_c := 15) (C_b := 15)
        (by dsimp [inCoreBallCond, H3a.condExprOps, H3a.realExprOps, H3a.intExprOps,
              UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps,
              UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wOut) (.lit tVal) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega))
    refine ⟨m4, (DetExecAt.seq hd1 (DetExecAt.seq hd2 (DetExecAt.seq hd3 hd4))).mono_cost (by omega),
      InFootprint.wWrite hfp3 hscrW hwOut.1 hwOut.2, ?_, ?_, ?_⟩
    · dsimp [m4, tVal, resBool]
      rw [wRead_wWrite_self, hcb]
      cases invert <;> rfl
    · intro w hwlt hneO
      dsimp [m4]
      rw [wRead_wWrite_of_ne _ _ (Or.inr hneO), hw3 w (by omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    · refine ⟨fun t i hts _ => ?_, fun t i hts _ => ?_⟩
      · dsimp [m4]
        rw [wRead_wWrite_of_ne _ _ (Or.inl hts), hpr3.1 t hts,
            wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_wWrite_of_ne _ _ (Or.inl hts)]
      · dsimp [m4]; exact hpr3.2 t hts i
  · have hcb_f : inCoreBall o V pt = false := Bool.eq_false_iff.mpr hcb
    have hc_f : cValAt 0 inp m3 (inCoreBallCond scrW scrR tblR (wScr + 1) rScr) = false :=
      hcond.trans hcb_f
    let m4 := H3a.wWrite m3 scrW wOut fVal
    have hd4 : DetExec inp (.ite (inCoreBallCond scrW scrR tblR (wScr + 1) rScr)
        (.writeWordHeap scrW (.lit wOut) (.lit tVal))
        (.writeWordHeap scrW (.lit wOut) (.lit fVal))) m3 m4 30 :=
      DetExecAt.ite_false hc_f (C_c := 15) (C_b := 15)
        (by dsimp [inCoreBallCond, H3a.condExprOps, H3a.realExprOps, H3a.intExprOps,
              UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.realExprOps,
              UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wOut) (.lit fVal) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega))
    refine ⟨m4, (DetExecAt.seq hd1 (DetExecAt.seq hd2 (DetExecAt.seq hd3 hd4))).mono_cost (by omega),
      InFootprint.wWrite hfp3 hscrW hwOut.1 hwOut.2, ?_, ?_, ?_⟩
    · dsimp [m4, fVal, resBool]
      rw [wRead_wWrite_self, hcb_f]
      cases invert <;> rfl
    · intro w hwlt hneO
      dsimp [m4]
      rw [wRead_wWrite_of_ne _ _ (Or.inr hneO), hw3 w (by omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    · refine ⟨fun t i hts _ => ?_, fun t i hts _ => ?_⟩
      · dsimp [m4]
        rw [wRead_wWrite_of_ne _ _ (Or.inl hts), hpr3.1 t hts,
            wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_wWrite_of_ne _ _ (Or.inl hts)]
      · dsimp [m4]; exact hpr3.2 t hts i

/-! ### 2. `managedNodeBumpAgeStmt`, `managedNodeContainsStmt`, `managedNodeResContainsStmt` -/

def managedNodeBumpAgeStmt (scrW tblW : ℕ) (wNodeBaseW : ℤ) : ArithRAMStmt :=
  let aE := IntExpr.add (.readHeap scrW (.lit wNodeBaseW)) (.lit 1)
  .writeWordHeap tblW aE (.add (.readHeap tblW aE) (.lit 1))

theorem zeroRand_managedNodeBumpAgeStmt (scrW tblW : ℕ) (wNodeBaseW : ℤ) :
    ZeroRandStmt (managedNodeBumpAgeStmt scrW tblW wNodeBaseW) :=
  .writeWordHeap _ _ _

theorem exec_managedNodeBumpAgeStmt
    {d TW BW TR BR n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wNodeBaseW nodeBaseW nodeBaseR : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg} {bp : Option (ℕ × ℕ)}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbls : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ nodeBaseW ∧
      nodeBaseW + managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wNodeBaseW = nodeBaseW)
    (henc : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (managedNodeBumpAgeStmt scrW tblW wNodeBaseW) m₀ m₁ 25 ∧
      InFootprint TW BW TR BR m₁ ∧
      EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn.bumpAge bp m₁ ∧
      (∀ w, H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW nodeBaseW
        (managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride) tblR nodeBaseR 0 m₀ m₁ := by
  have hw21 := managedNodeWStride_ge_header n cap_hist K_seg N_cfg ops.hcfgW_nonneg
  have hrad4 := radTreeWStride_ge_four K_seg
  let m₁ := H3a.wWrite m₀ tblW (nodeAgeOff nodeBaseW) ((mn.nd.age + 1 : ℕ) : ℤ)
  have hd : DetExec inp (managedNodeBumpAgeStmt scrW tblW wNodeBaseW) m₀ m₁ 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ tblW _ _
      (by change H3a.wRead m₀ scrW wNodeBaseW + 1 = nodeAgeOff nodeBaseW; rw [hbW]; rfl)
      (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wNodeBaseW + 1) + 1 = ((mn.nd.age + 1 : ℕ) : ℤ)
          rw [hbW]; change H3a.wRead m₀ tblW (nodeAgeOff nodeBaseW) + 1 = _
          rw [henc.2.1]; push_cast; ring)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp₁ : InFootprint TW BW TR BR m₁ :=
    InFootprint.wWrite hfp₀ htbls.2.1 (by unfold nodeAgeOff; omega) (by unfold nodeAgeOff; omega)
  have hfr : RadFrameOutside scrW scrR tblW nodeBaseW
      (managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride) tblR nodeBaseR 0 m₀ m₁ := by
    refine ⟨fun t i _ hout => ?_, fun _ _ _ _ => rfl⟩
    rcases hout with ht | hlt | hge
    · exact wRead_wWrite_of_ne _ _ (Or.inl ht)
    · exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold nodeAgeOff; omega))
    · exact wRead_wWrite_of_ne _ _ (Or.inr (by unfold nodeAgeOff; omega))
  refine ⟨m₁, hd, hfp₁, ?_,
    fun _ => wRead_wWrite_of_ne _ _ (Or.inl htbls.2.2.2.2.2.2.1.symm), fun _ => rfl, hfr⟩
  rcases henc with ⟨hb, _, hbp, ho, hs, hV, hh_le, hh_len, hh_el,
    ⟨Pd, hPd_wf, hPd_l, hPd_e⟩, ⟨Pr, hPr_wf, hPr_l, hPr_e⟩, ⟨Tr, hTr_wf, hTr_e⟩, hcfgs⟩
  have hne_age : ∀ i : ℤ, i ≠ nodeAgeOff nodeBaseW → H3a.wRead m₁ tblW i = H3a.wRead m₀ tblW i :=
    fun _ hne => wRead_wWrite_of_ne _ _ (Or.inr hne)
  refine ⟨(hne_age _ (by unfold nodeBirthSizeOff nodeAgeOff; omega)).trans hb,
    wRead_wWrite_self _ _ _ _, ?_, ho, hs, hV, hh_le,
    (hne_age _ (by unfold nodeHistOff nodeAgeOff swapPoolStride; omega)).trans hh_len,
    fun j hj => (hne_age _ (by unfold nodeHistOff nodeAgeOff swapPoolStride; omega)).trans (hh_el j hj),
    ⟨Pd, hPd_wf, hPd_l, ?_⟩, ⟨Pr, hPr_wf, hPr_l, ?_⟩, ⟨Tr, hTr_wf, ?_⟩, fun i => ?_⟩
  · cases bp with
    | none =>
        rcases hbp with ⟨h1, h2, h3⟩
        exact ⟨(hne_age _ (by unfold nodeBaseHasOff nodeAgeOff; omega)).trans h1,
               (hne_age _ (by unfold nodeBaseUOff nodeAgeOff; omega)).trans h2,
               (hne_age _ (by unfold nodeBaseVOff nodeAgeOff; omega)).trans h3⟩
    | some uv =>
        rcases uv with ⟨u, v⟩
        rcases hbp with ⟨h1, h2, h3⟩
        exact ⟨(hne_age _ (by unfold nodeBaseHasOff nodeAgeOff; omega)).trans h1,
               (hne_age _ (by unfold nodeBaseUOff nodeAgeOff; omega)).trans h2,
               (hne_age _ (by unfold nodeBaseVOff nodeAgeOff; omega)).trans h3⟩
  · exact hPd_e.mono_frame (WordFrameOutside.wWrite_in scrW tblW (nodeAgeOff nodeBaseW) 1 m₀ le_rfl (by omega) _)
      htbls.2.2.2.2.2.2.1 (Or.inr (Or.inr (by unfold nodeDensePoolOff nodeAgeOff; omega))) hPd_wf.2.2.2.1
  · exact hPr_e.mono_frame (WordFrameOutside.wWrite_in scrW tblW (nodeAgeOff nodeBaseW) 1 m₀ le_rfl (by omega) _)
      htbls.2.2.2.2.2.2.1 (Or.inr (Or.inr (by unfold nodeResPoolOff nodeAgeOff swapPoolStride; omega))) hPr_wf.2.2.2.1
  · refine ⟨(hne_age _ (by unfold nodeRadTreeWOff nodeHistOff nodeAgeOff swapPoolStride; omega)).trans hTr_e.1,
      fun v hv => ?_⟩
    obtain ⟨e1, e2, e3, e4⟩ := hTr_e.2 v hv
    exact ⟨(hne_age _ (by unfold nodeRadTreeWOff nodeHistOff nodeAgeOff swapPoolStride; omega)).trans e1,
           (hne_age _ (by unfold nodeRadTreeWOff nodeHistOff nodeAgeOff swapPoolStride; omega)).trans e2,
           (hne_age _ (by unfold nodeRadTreeWOff nodeHistOff nodeAgeOff swapPoolStride; omega)).trans e3,
           e4⟩
  · have hb_cfg := nodeCfgWOff_bounds n cap_hist K_seg ops.hcfgW_nonneg nodeBaseW i
    exact ops.encCfg_mono_slice (specs i) _ _ pts mn.nd.o mn.nd.V (nodeCfgSet mn.nd) (mn.nd.cfgs i) m₀ m₁
      (hcfgs i)
      (fun j hj1 _ => hne_age j (by unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff nodeAgeOff swapPoolStride at *; omega))
      (fun _ _ _ => rfl)
      (fun _ _ _ _ => rfl)

def managedNodeContainsStmt (isRes : Bool) (scrW tblW : ℕ)
    (wNodeBaseW wUid wOut wScr : ℤ) (n : ℕ) : ArithRAMStmt :=
  let off : ℤ := if isRes then 8 + swapPoolStride n else 8
  .seq (.writeWordHeap scrW (.lit wScr) (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit off)))
       (swapPoolMemStmt scrW tblW wScr wUid (wScr + 1) wOut n)

theorem zeroRand_managedNodeContainsStmt (isRes : Bool) (scrW tblW : ℕ)
    (wNodeBaseW wUid wOut wScr : ℤ) (n : ℕ) :
    ZeroRandStmt (managedNodeContainsStmt isRes scrW tblW wNodeBaseW wUid wOut wScr n) :=
  hzr_to_zeroRand (.seq (.writeWordHeap _ _ _) (hzr_swapPoolMemStmt _ _ _ _ _ _ _))

theorem exec_managedNodeContainsStmt
    {d TW BW TR BR n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (isRes : Bool) (hn : 1 ≤ n)
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wNodeBaseW wUid wOut wScr nodeBaseW nodeBaseR : ℤ) (uid : ℕ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg} {bp : Option (ℕ × ℕ)}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbls : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hwBW : 0 ≤ wNodeBaseW ∧ wNodeBaseW < wScr)
    (hwUid : 0 ≤ wUid ∧ wUid < wScr)
    (hwOut : 0 ≤ wOut ∧ wOut < (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 4 ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wNodeBaseW = nodeBaseW)
    (huid : H3a.wRead m₀ scrW wUid = (uid : ℤ))
    (henc : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₀) :
    let arr := if isRes then mn.resArr else mn.nd.denseArr
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (managedNodeContainsStmt isRes scrW tblW wNodeBaseW wUid wOut wScr n) m₀ m₁ 115 ∧
      InFootprint TW BW TR BR m₁ ∧
      H3a.wRead m₁ scrW wOut = (if arr.contains uid then 1 else 0) ∧
      RadFrameOutside scrW scrR tblW 0 0 tblR 0 0 m₀ m₁ := by
  intro arr
  let off : ℤ := if isRes then 8 + swapPoolStride n else 8
  let m1 := H3a.wWrite m₀ scrW wScr (nodeBaseW + off)
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit off))) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW _ _ rfl
      (by change H3a.wRead m₀ scrW wNodeBaseW + off = _; rw [hbW])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ htbls.1 hwScr.1 (by omega)
  have huid1 : H3a.wRead m1 scrW wUid = (uid : ℤ) := by
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), huid]
  have hfr1 : WordFrameOutside scrW tblW (nodeBaseW + off) 0 m₀ m1 :=
    WordFrameOutside.wWrite_scr scrW tblW _ 0 m₀ _ _
  rcases henc with ⟨_, _, _, _, _, _, _, _, _, ⟨Pd, hPd_wf, hPd_l, hPd_e⟩, ⟨Pr, hPr_wf, hPr_l, hPr_e⟩, _, _⟩
  cases isRes
  · have henc1 : EncSwapPool tblW (nodeBaseW + 8) n Pd m1 :=
      hPd_e.mono_frame hfr1 htbls.2.2.2.2.2.2.1 (Or.inr (Or.inr (by dsimp [off]; unfold nodeDensePoolOff; omega))) hPd_wf.2.2.2.1
    obtain ⟨m2, hd2, hfp2, hout2, _, _, hfr2⟩ :=
      exec_swapPoolMemStmt inp wScr wUid (wScr + 1) wOut (nodeBaseW + 8) hn hPd_wf uid
        hfp1 htbls.1 htbls.2.2.2.2.2.2.1 ⟨by omega, by omega⟩ hwOut (by omega) (by omega)
        (wRead_wWrite_self _ _ _ _) huid1 henc1
    have hiff : Pd.memPred n uid ↔ arr.contains uid = true := by
      rw [Pd.memPred_iff hn hPd_wf uid, List.contains_iff_mem, ← List.mem_toFinset]
      dsimp [arr]; rfl
    refine ⟨m2, (DetExecAt.seq hd1 hd2).mono_cost (by omega), hfp2, ?_, ?_⟩
    · rw [hout2]; by_cases hm : Pd.memPred n uid
      · rw [if_pos hm, if_pos (hiff.mp hm)]
      · have hnc : arr.contains uid ≠ true := fun hc => hm (hiff.mpr hc)
        rw [if_neg hm]; cases hb : arr.contains uid
        · rfl
        · exact absurd hb hnc
    · have hfr12 := hfr1.trans hfr2
      exact ⟨fun t i hs _ => hfr12.1 t i hs (Or.inr (by omega)),
             fun t i _ _ => hfr12.2 t i⟩
  · have henc1 : EncSwapPool tblW (nodeBaseW + (8 + swapPoolStride n)) n Pr m1 := by
      have heq_b : nodeResPoolOff n nodeBaseW = nodeBaseW + (8 + swapPoolStride n) := by
        unfold nodeResPoolOff; ring
      rw [← heq_b]
      exact hPr_e.mono_frame hfr1 htbls.2.2.2.2.2.2.1 (Or.inr (Or.inr (by dsimp [off]; unfold nodeResPoolOff; omega))) hPr_wf.2.2.2.1
    obtain ⟨m2, hd2, hfp2, hout2, _, _, hfr2⟩ :=
      exec_swapPoolMemStmt inp wScr wUid (wScr + 1) wOut (nodeBaseW + (8 + swapPoolStride n)) hn hPr_wf uid
        hfp1 htbls.1 htbls.2.2.2.2.2.2.1 ⟨by omega, by omega⟩ hwOut (by omega) (by omega)
        (wRead_wWrite_self _ _ _ _) huid1 henc1
    have hiff : Pr.memPred n uid ↔ arr.contains uid = true := by
      rw [Pr.memPred_iff hn hPr_wf uid, List.contains_iff_mem, ← List.mem_toFinset]
      dsimp [arr]; rfl
    refine ⟨m2, (DetExecAt.seq hd1 hd2).mono_cost (by omega), hfp2, ?_, ?_⟩
    · rw [hout2]; by_cases hm : Pr.memPred n uid
      · rw [if_pos hm, if_pos (hiff.mp hm)]
      · have hnc : arr.contains uid ≠ true := fun hc => hm (hiff.mpr hc)
        rw [if_neg hm]; cases hb : arr.contains uid
        · rfl
        · exact absurd hb hnc
    · have hfr12 := hfr1.trans hfr2
      exact ⟨fun t i hs _ => hfr12.1 t i hs (Or.inr (by omega)),
             fun t i _ _ => hfr12.2 t i⟩

/-! ### 3. Compile-Time `Fin N_cfg` Sequencing Combinator (`seqFinCfgStmt`) -/

def seqFinCfgAux (N_cfg : ℕ) (f : Fin N_cfg → ArithRAMStmt) : ℕ → ArithRAMStmt
  | 0 => .skip
  | k + 1 =>
      if hk : N_cfg - (k + 1) < N_cfg then
        .seq (f ⟨N_cfg - (k + 1), hk⟩) (seqFinCfgAux N_cfg f k)
      else
        .skip

def seqFinCfgStmt (N_cfg : ℕ) (f : Fin N_cfg → ArithRAMStmt) : ArithRAMStmt :=
  seqFinCfgAux N_cfg f N_cfg

theorem zeroRand_seqFinCfgAux (N_cfg : ℕ) (f : Fin N_cfg → ArithRAMStmt)
    (hf : ∀ i : Fin N_cfg, ZeroRandStmt (f i)) :
    ∀ k : ℕ, ZeroRandStmt (seqFinCfgAux N_cfg f k)
  | 0 => .skip
  | k + 1 => by
      dsimp [seqFinCfgAux]
      split_ifs with hk
      · exact .seq (hf _) (zeroRand_seqFinCfgAux N_cfg f hf k)
      · exact .skip

theorem zeroRand_seqFinCfgStmt (N_cfg : ℕ) (f : Fin N_cfg → ArithRAMStmt)
    (hf : ∀ i : Fin N_cfg, ZeroRandStmt (f i)) :
    ZeroRandStmt (seqFinCfgStmt N_cfg f) :=
  zeroRand_seqFinCfgAux N_cfg f hf N_cfg

theorem exec_seqFinCfgStmt {d TW BW TR BR scrW scrR tblW tblR N_cfg : ℕ}
    (inp : ArithRAMInput d) (f : Fin N_cfg → ArithRAMStmt)
    (Inv : ℕ → ArithRAMMemory → Prop)
    (wKeep baseW lenW baseR lenR : ℤ) (C_step : ℕ)
    {m₀ : ArithRAMMemory}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hInv₀ : Inv 0 m₀)
    (hstep : ∀ (i : Fin N_cfg) (m : ArithRAMMemory),
      InFootprint TW BW TR BR m →
      Inv i.val m →
      (∀ w, w < wKeep → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) →
      RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m₀ m →
      ∃ m' : ArithRAMMemory,
        DetExec inp (f i) m m' C_step ∧
        InFootprint TW BW TR BR m' ∧
        Inv (i.val + 1) m' ∧
        (∀ w, w < wKeep → H3a.wRead m' scrW w = H3a.wRead m scrW w) ∧
        RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m m') :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (seqFinCfgStmt N_cfg f) m₀ m₁ (1 + N_cfg * C_step) ∧
      InFootprint TW BW TR BR m₁ ∧
      Inv N_cfg m₁ ∧
      (∀ w, w < wKeep → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m₀ m₁ := by
  have hsuf : ∀ (k : ℕ), k ≤ N_cfg → ∀ (m : ArithRAMMemory),
      InFootprint TW BW TR BR m →
      Inv (N_cfg - k) m →
      (∀ w, w < wKeep → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) →
      RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m₀ m →
      ∃ m₁ : ArithRAMMemory,
        DetExec inp (seqFinCfgAux N_cfg f k) m m₁ (1 + k * C_step) ∧
        InFootprint TW BW TR BR m₁ ∧
        Inv N_cfg m₁ ∧
        (∀ w, w < wKeep → H3a.wRead m₁ scrW w = H3a.wRead m scrW w) ∧
        RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m m₁ := by
    intro k
    induction k with
    | zero =>
        intro _ m hfp hI _ _
        simp only [Nat.sub_zero] at hI
        exact ⟨m, (DetExecAt.skip 0 inp m).mono_cost (by omega), hfp, hI,
          fun _ _ => rfl, RadFrameOutside.refl _ _ _ _ _ _ _ _ m⟩
    | succ k ih =>
        intro hk1 m hfp hI hw_m hfr_m
        have hk_lt : N_cfg - (k + 1) < N_cfg := by omega
        dsimp only [seqFinCfgAux]
        rw [dif_pos hk_lt]
        let idx : Fin N_cfg := ⟨N_cfg - (k + 1), hk_lt⟩
        obtain ⟨m', hd_s, hfp', hI', hw', hfr'⟩ := hstep idx m hfp hI hw_m hfr_m
        have hI_sub : Inv (N_cfg - k) m' := by
          have heq : idx.val + 1 = N_cfg - k := by dsimp [idx]; omega
          rwa [← heq]
        obtain ⟨m₁, hd_rem, hfp₁, hIN, hw_rem, hfr_rem⟩ :=
          ih (by omega) m' hfp' hI_sub
            (fun w hw => (hw' w hw).trans (hw_m w hw)) (hfr_m.trans hfr')
        refine ⟨m₁, (DetExecAt.seq hd_s hd_rem).mono_cost (by rw [Nat.succ_mul]; omega),
          hfp₁, hIN, fun w hw => (hw_rem w hw).trans (hw' w hw), hfr'.trans hfr_rem⟩
  simpa [seqFinCfgStmt] using
    hsuf N_cfg le_rfl m₀ hfp₀ (by simp [hInv₀]) (fun _ _ => rfl)
      (RadFrameOutside.refl _ _ _ _ _ _ _ _ m₀)

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
