import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideB0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot slotWStride slotRStride slotWStride_ge_four
  seedBitCount slotInsWStride slotInsRStride liveSlotInsertRecordStmt liveSlotInsertRecordCost
  exec_liveSlotInsertRecordStmt copyVecToHeapStmt exec_copyVecToHeapStmt)

/-! ### 1. Scratch Strides, `ZeroRandStmt` Helpers & Per-Scale Disjointness -/

def dyadicSideInsertWStride (ℓ M₀ cap_u : ℕ) : ℤ :=
  20 + slotInsWStride ℓ M₀ cap_u

def dyadicSideInsertRStride (d : ℕ) : ℤ :=
  9 + slotInsRStride d

lemma slotInsWStride_ge_24 (ℓ M₀ cap_u : ℕ) : 24 ≤ slotInsWStride ℓ M₀ cap_u := by
  unfold slotInsWStride RacerP43.evalWStride; omega

lemma dyadicSideInsertWStride_ge_44 (ℓ M₀ cap_u : ℕ) : 44 ≤ dyadicSideInsertWStride ℓ M₀ cap_u := by
  have := slotInsWStride_ge_24 ℓ M₀ cap_u
  unfold dyadicSideInsertWStride; omega

lemma dyadicSideInsertRStride_ge_9 (d : ℕ) : 9 ≤ dyadicSideInsertRStride d := by
  unfold dyadicSideInsertRStride slotInsRStride; omega

theorem zeroRand_copyVecToHeapStmt (scrW tblSrc tblDst : ℕ) (wCtr wOffSrc wOffDst : ℤ) (N : ℕ) :
    H3a.ZeroRandStmt (copyVecToHeapStmt scrW tblSrc tblDst wCtr wOffSrc wOffDst N) :=
  of_isZeroRandB rfl

theorem zeroRand_liveSlotInsertRecordStmt (scrW scrR tblW tblR tblO tblPts : ℕ)
    (wBaseW wBaseR wOffO wOffPt wEid wAlive wInsBase rInsBase : ℤ)
    (R ℓ M₀ d cap_u : ℕ) (A B_rat τ_d : ℚ) :
    H3a.ZeroRandStmt (liveSlotInsertRecordStmt scrW scrR tblW tblR tblO tblPts
      wBaseW wBaseR wOffO wOffPt wEid wAlive wInsBase rInsBase R ℓ M₀ d cap_u A B_rat τ_d) :=
  of_isZeroRandB rfl

/-! ### 2. Single-Record Insert Helper `dyadicSideInsertOneEidStmt` -/

def dyadicSideInsertOneEidStmt (scrW scrR tblW tblR tblO : ℕ)
    (wSideBaseW wSideBaseR wOffO wScr rScr : ℤ)
    (L_p2 R ℓ M₀ d cap_u : ℕ) (A B_rat τ_d : ℚ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let bR := IntExpr.readHeap scrW (.lit wSideBaseR)
  let bMaxZ : ℤ := ((2 ^ L_p2 : ℕ) : ℤ)
  let wEp := wScr
  let wSlotBW := wScr + 10
  let wSlotBR := wScr + 11
  let wEid := wScr + 14
  let wAlive := wScr + 15
  let wCurPtOff := wScr + 16
  let wSubW := wScr + 20
  .seq (.ite (.intEq (.readHeap tblW (.add (.add bW (.lit (2 + bMaxZ))) (.readHeap scrW (.lit wEid))))
                     (.readHeap scrW (.lit wEp)))
          (.writeWordHeap scrW (.lit wAlive) (.lit 1))
          (.writeWordHeap scrW (.lit wAlive) (.lit 0)))
  (.seq (.writeWordHeap scrW (.lit wCurPtOff)
          (.add (.add bR (.lit (d : ℤ)))
                (.mul (.readHeap scrW (.lit wEid)) (.lit (d : ℤ)))))
        (liveSlotInsertRecordStmt scrW scrR tblW tblR tblO tblR
          wSlotBW wSlotBR wOffO wCurPtOff wEid wAlive wSubW rScr
          R ℓ M₀ d cap_u A B_rat τ_d))

def dyadicSideInsertOneEidCost (R ℓ M₀ d cap_u : ℕ) : ℕ :=
  80 + liveSlotInsertRecordCost R ℓ M₀ d cap_u

theorem zeroRand_dyadicSideInsertOneEidStmt (scrW scrR tblW tblR tblO : ℕ)
    (wSideBaseW wSideBaseR wOffO wScr rScr : ℤ)
    (L_p2 R ℓ M₀ d cap_u : ℕ) (A B_rat τ_d : ℚ) :
    H3a.ZeroRandStmt (dyadicSideInsertOneEidStmt scrW scrR tblW tblR tblO
      wSideBaseW wSideBaseR wOffO wScr rScr L_p2 R ℓ M₀ d cap_u A B_rat τ_d) :=
  .seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
    (.seq (.writeWordHeap _ _ _) (zeroRand_liveSlotInsertRecordStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _))

theorem exec_dyadicSideInsertOneEidStmt {d TW BW TR BR scrW scrR tblW tblR tblO : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wOffO wScr rScr sideBaseW sideBaseR offO slotBW slotBR : ℤ)
    {L_p2 R ℓ M₀ cap_u ep₀ t blkStart : ℕ} (hM₀ : 1 ≤ M₀)
    (A B_rat τ_d : ℚ)
    (o pt_eid : EuclideanSpace ℝ (Fin d))
    {entryAlive' : ℕ → Bool} {hSlot : H4a1.PureFilterSlot R ℓ M₀ d} {S : LiveSlot R ℓ M₀ d}
    (htr : LiveSlotTrackedH4 cap_u (2 ^ L_p2) (t + 1) entryAlive' hSlot S)
    (hblk : S.blkId = (blkStart : ℤ))
    (hlt_B : S.builtCnt < 2 ^ L_p2)
    (hlt_t : blkStart + S.builtCnt < t + 1)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR) (htblW : tblW < TW)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneO : tblO ≠ scrR)
    (hslotBW : 0 ≤ slotBW ∧ slotBW + slotWStride R ℓ M₀ cap_u (2 ^ L_p2) ≤ (BW : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + dyadicSideInsertRStride d ≤ (BR : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSideBaseW)
    (hdisjBR : wSideBaseR < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSideBaseR)
    (hdisjO : wOffO < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wOffO)
    (hbW : wRead m₀ scrW wSideBaseW = sideBaseW)
    (hbR : wRead m₀ scrW wSideBaseR = sideBaseR)
    (hoffO : wRead m₀ scrW wOffO = offO)
    (hep_r : wRead m₀ scrW wScr = (ep₀ : ℤ))
    (hslotBW_r : wRead m₀ scrW (wScr + 10) = slotBW)
    (hslotBR_r : wRead m₀ scrW (wScr + 11) = slotBR)
    (heid_r : wRead m₀ scrW (wScr + 14) = ((blkStart + S.builtCnt : ℕ) : ℤ))
    (hal_iff : wRead m₀ tblW (sideAliveEpOff L_p2 sideBaseW (blkStart + S.builtCnt)) = (ep₀ : ℤ) ↔
      entryAlive' (blkStart + S.builtCnt) = true)
    (ho : ∀ c : Fin d, rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpt : ∀ c : Fin d,
      rRead m₀ tblR (sideEntryPtOff d sideBaseR + ((blkStart + S.builtCnt : ℕ) : ℤ) * (d : ℤ) + (c.val : ℤ)) =
        euclideanCoord pt_eid c)
    (henc₀ : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S m₀) :
    let eid := blkStart + S.builtCnt
    let S' := S.insertRecord hM₀ A B_rat τ_d cap_u eid (entryAlive' eid) o pt_eid
    let hSlot' := hSlot.insertPoint hM₀ A B_rat τ_d cap_u o pt_eid eid
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (dyadicSideInsertOneEidStmt scrW scrR tblW tblR tblO
          wSideBaseW wSideBaseR wOffO wScr rScr L_p2 R ℓ M₀ d cap_u A B_rat τ_d)
        m₀ m₁ (dyadicSideInsertOneEidCost R ℓ M₀ d cap_u) ∧
      InFootprint TW BW TR BR m₁ ∧
      LiveSlotTrackedH4 cap_u (2 ^ L_p2) (t + 1) entryAlive' hSlot' S' ∧
      S'.blkId = (blkStart : ℤ) ∧
      S'.builtCnt = S.builtCnt + 1 ∧
      EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S' m₁ ∧
      (∀ w, (w < wScr + 15 ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) ∧
      (∀ r, (r < rScr ∨ rScr + dyadicSideInsertRStride d ≤ r) →
        rRead m₁ scrR r = rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW slotBW (slotWStride R ℓ M₀ cap_u (2 ^ L_p2)) tblR slotBR 0 m₀ m₁ := by
  intro eid S' hSlot'
  have hw_ge := dyadicSideInsertWStride_ge_44 ℓ M₀ cap_u
  have hr_ge := dyadicSideInsertRStride_ge_9 d
  have hnonneg : 0 ≤ S.blkId := by rw [hblk]; positivity
  have htoNat : S.blkId.toNat = blkStart := by rw [hblk]; omega
  rcases htr.2 hnonneg with ⟨_, _, hwf_S0⟩
  rw [htoNat] at hwf_S0
  have htr_out := LiveSlotTrackedH4.of_insertRecord hM₀ (A := A) (B_rat := B_rat) (τ_d := τ_d)
    htr hblk hlt_B hlt_t o pt_eid
  let alVal : ℤ := if entryAlive' eid then 1 else 0
  let m1 := wWrite m₀ scrW (wScr + 15) alVal
  let condAl : ArithCondExpr :=
    .intEq (.readHeap tblW (.add (.add (.readHeap scrW (.lit wSideBaseW))
                                       (.lit (2 + ((2 ^ L_p2 : ℕ) : ℤ))))
                                 (.readHeap scrW (.lit (wScr + 14)))))
           (.readHeap scrW (.lit wScr))
  have hal_addr : (sideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) + ((eid : ℕ) : ℤ) =
      sideAliveEpOff L_p2 sideBaseW eid := by
    unfold sideAliveEpOff; ring
  have hd1 : DetExec inp
      (.ite condAl (.writeWordHeap scrW (.lit (wScr + 15)) (.lit 1))
                   (.writeWordHeap scrW (.lit (wScr + 15)) (.lit 0))) m₀ m1 35 := by
    by_cases hal : entryAlive' eid = true
    · have hmem_eq := hal_iff.mpr hal
      have hc_t : cValAt 0 inp m₀ condAl = true := by
        simp only [cValAt, condAl, evalArithCond, evalIntExpr]
        change decide (wRead m₀ tblW ((wRead m₀ scrW wSideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) +
          wRead m₀ scrW (wScr + 14)) = wRead m₀ scrW wScr) = true
        rw [hbW, heid_r, hep_r, hal_addr, hmem_eq]; simp
      have hm1_eq : m1 = wWrite m₀ scrW (wScr + 15) 1 := by dsimp [m1, alVal]; rw [hal]; rfl
      rw [hm1_eq]
      exact (DetExecAt.ite_true (C_c := 25) (C_b := 10) hc_t (by dsimp [condAl, condExprOps, intExprOps]; omega)
        (DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wScr + 15)) (.lit 1) rfl rfl
          (by dsimp [intExprOps]; omega))).mono_cost (by omega)
    · have hal_f : entryAlive' eid = false := Bool.eq_false_iff.mpr hal
      have hmem_ne : wRead m₀ tblW (sideAliveEpOff L_p2 sideBaseW eid) ≠ (ep₀ : ℤ) :=
        fun h => hal (hal_iff.mp h)
      have hc_f : cValAt 0 inp m₀ condAl = false := by
        simp only [cValAt, condAl, evalArithCond, evalIntExpr]
        change decide (wRead m₀ tblW ((wRead m₀ scrW wSideBaseW + (2 + ((2 ^ L_p2 : ℕ) : ℤ))) +
          wRead m₀ scrW (wScr + 14)) = wRead m₀ scrW wScr) = false
        rw [hbW, heid_r, hep_r, hal_addr]
        exact decide_eq_false hmem_ne
      have hm1_eq : m1 = wWrite m₀ scrW (wScr + 15) 0 := by dsimp [m1, alVal]; rw [hal_f]; rfl
      rw [hm1_eq]
      exact (DetExecAt.ite_false (C_c := 25) (C_b := 10) hc_f (by dsimp [condAl, condExprOps, intExprOps]; omega)
        (DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wScr + 15)) (.lit 0) rfl rfl
          (by dsimp [intExprOps]; omega))).mono_cost (by omega)
  let curPtOff : ℤ := sideEntryPtOff d sideBaseR + (eid : ℤ) * (d : ℤ)
  let m2 := wWrite m1 scrW (wScr + 16) curPtOff
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 16))
      (.add (.add (.readHeap scrW (.lit wSideBaseR)) (.lit (d : ℤ)))
            (.mul (.readHeap scrW (.lit (wScr + 14))) (.lit (d : ℤ))))) m1 m2 30 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 16)) _ rfl
      (by change (wRead m1 scrW wSideBaseR + (d : ℤ)) + wRead m1 scrW (wScr + 14) * (d : ℤ) = curPtOff
          have hbR1 : wRead m1 scrW wSideBaseR = sideBaseR :=
            (wRead_wWrite_of_ne _ _ (Or.inr (by rcases hdisjBR with h | h <;> omega))).trans hbR
          have he1 : wRead m1 scrW (wScr + 14) = (eid : ℤ) :=
            (wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans heid_r
          rw [hbR1, he1]; dsimp only [curPtOff]; unfold sideEntryPtOff; ring)
      (by dsimp [intExprOps]; omega)
  have hfp2 : InFootprint TW BW TR BR m2 :=
    InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hfr02 : RadFrameOutside scrW scrR tblW slotBW 0 tblR slotBR 0 m₀ m2 :=
    (RadFrameOutside.wWrite_scr scrW scrR tblW slotBW 0 tblR slotBR 0 m₀ _ _).trans
      (RadFrameOutside.wWrite_scr scrW scrR tblW slotBW 0 tblR slotBR 0 m1 _ _)
  have henc2 : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S m2 :=
    henc₀.mono_frame hfr02 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  have hkW2 : ∀ w, (w < wScr + 15 ∨ wScr + 17 ≤ w) → wRead m2 scrW w = wRead m₀ scrW w := by
    intro w hw
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
  obtain ⟨m3, hd3, hfp3, henc3, _, hkW3, hkR3, hfr3⟩ :=
    exec_liveSlotInsertRecordStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
      inp (wScr + 10) (wScr + 11) wOffO (wScr + 16) (wScr + 14) (wScr + 15) (wScr + 20) rScr
      slotBW slotBR offO curPtOff hM₀ A B_rat τ_d o pt_eid hwf_S0 hlt_B
      hfp2 hscrW hscrR htblW hneW hneR hneO hneR
      hslotBW
      ⟨by omega, by unfold dyadicSideInsertWStride at hwScr; omega⟩
      ⟨hrScr.1, by unfold dyadicSideInsertRStride at hrScr; omega⟩
      (Or.inl (by omega)) (Or.inl (by omega))
      (by unfold dyadicSideInsertWStride at hdisjO; rcases hdisjO with h | h; exact Or.inl (by omega); exact Or.inr (by omega))
      (Or.inl (by omega)) (Or.inl (by omega)) (Or.inl (by omega))
      ((hkW2 _ (Or.inl (by omega))).trans hslotBW_r)
      ((hkW2 _ (Or.inl (by omega))).trans hslotBR_r)
      ((hkW2 _ (by rcases hdisjO with h | h; exact Or.inl (by omega); exact Or.inr (by omega))).trans hoffO)
      (wRead_wWrite_self _ _ _ _)
      ((hkW2 _ (Or.inl (by omega))).trans heid_r)
      ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _))
      (fun c => by rw [rRead_wWrite, rRead_wWrite]; exact ho c)
      (fun c => by rw [rRead_wWrite, rRead_wWrite]; exact hpt c)
      henc2
  have hfr03 : RadFrameOutside scrW scrR tblW slotBW (slotWStride R ℓ M₀ cap_u (2 ^ L_p2)) tblR slotBR 0 m₀ m3 :=
    (hfr02.mono_range (Or.inl rfl) (Or.inl rfl)).trans hfr3
  refine ⟨m3, (hd1.seq (hd2.seq hd3)).mono_cost (by unfold dyadicSideInsertOneEidCost; omega),
    hfp3, htr_out.1, htr_out.2.1, htr_out.2.2, henc3, ?_, ?_, hfr03⟩
  · intro w hw
    have hw_sub : w < wScr + 20 ∨ wScr + 20 + slotInsWStride ℓ M₀ cap_u ≤ w := by
      unfold dyadicSideInsertWStride at hw
      rcases hw with h | h
      · exact Or.inl (by omega)
      · exact Or.inr (by omega)
    exact (hkW3 w hw_sub).trans (hkW2 w (by rcases hw with h | h; exact Or.inl h; exact Or.inr (by omega)))
  · intro r hr
    have hr_sub : r < rScr ∨ rScr + slotInsRStride d ≤ r := by
      unfold dyadicSideInsertRStride at hr
      rcases hr with h | h
      · exact Or.inl h
      · exact Or.inr (by omega)
    rw [hkR3 r hr_sub, rRead_wWrite, rRead_wWrite]

/-! ### 3. Per-Scale Insert Helpers & `dyadicSideInsertScaleStepStmt` -/

lemma two_pow_succ_le {k L_p2 : ℕ} (hk : k < L_p2) :
    2 * 2 ^ k ≤ 2 ^ L_p2 := by
  have h1 : 2 ^ (k + 1) ≤ 2 ^ L_p2 := Nat.pow_le_pow_right (by decide) hk
  have h2 : 2 ^ (k + 1) = 2 * 2 ^ k := by rw [pow_succ]; ring
  omega

lemma scale_block_boundsW {n L_p2 R ℓ M₀ cap_u k : ℕ} (sideBaseW : ℤ)
    (hk : k < L_p2) (sl : Fin 2) :
    let scaleBW := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (2 * k)
    let sStride := slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
    let slotBW := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sideBaseW (sideSlotIdx ⟨k, hk⟩ sl)
    scaleBW ≤ slotBW ∧ slotBW + sStride ≤ scaleBW + 2 * sStride := by
  intro scaleBW sStride slotBW
  have hsge : 0 ≤ sStride := by have := slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2); omega
  have hsl := sl.isLt
  dsimp only [scaleBW, slotBW, sideSlotIdx]
  unfold sideSlotBaseW
  rcases Nat.eq_zero_or_pos sl.val with h0 | hpos
  · rw [h0]; push_cast; constructor <;> linarith
  · have h1 : sl.val = 1 := by omega
    rw [h1]; push_cast; constructor <;> linarith

lemma scale_block_boundsR {L_p2 R ℓ M₀ d k : ℕ} (sideBaseR : ℤ)
    (hk : k < L_p2) (sl : Fin 2) :
    let scaleBR := sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (2 * k)
    let rStride := slotRStride R ℓ M₀ d
    let slotBR := sideSlotBaseR L_p2 R ℓ M₀ d sideBaseR (sideSlotIdx ⟨k, hk⟩ sl)
    scaleBR ≤ slotBR ∧ slotBR + rStride ≤ scaleBR + 2 * rStride := by
  intro scaleBR rStride slotBR
  have hrge := slotRStride_nonneg R ℓ M₀ d
  have hsl := sl.isLt
  dsimp only [scaleBR, slotBR, sideSlotIdx]
  unfold sideSlotBaseR
  rcases Nat.eq_zero_or_pos sl.val with h0 | hpos
  · rw [h0]; push_cast; constructor <;> linarith
  · have h1 : sl.val = 1 := by omega
    rw [h1]; push_cast; constructor <;> linarith

lemma hcur_step_of_lt {H q off : ℕ} (hH : 1 ≤ H) (hlt : off + 1 < 2 * H) :
    let B := 2 * H
    (B * q + off + 1) / B = q ∧ (B * q + off + 1) % B = off + 1 := by
  intro B
  have hB_pos : 0 < B := by dsimp [B]; omega
  have heq : B * q + off + 1 = (off + 1) + B * q := by ring
  rw [heq, Nat.add_mul_div_left _ _ hB_pos, Nat.div_eq_of_lt hlt, zero_add,
      Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hlt]
  exact ⟨rfl, rfl⟩

lemma hcur_step_of_eq {H q off : ℕ} (hH : 1 ≤ H) (heq_B : off + 1 = 2 * H) :
    let B := 2 * H
    (B * q + off + 1) / B = q + 1 ∧ (B * q + off + 1) % B = 0 := by
  intro B
  have hB_pos : 0 < B := by dsimp [B]; omega
  have heq : B * q + off + 1 = B * (q + 1) := by
    calc B * q + off + 1 = B * q + (off + 1) := by ring
      _ = B * q + B := by rw [heq_B]
      _ = B * (q + 1) := by ring
  rw [heq, Nat.mul_div_right _ hB_pos, Nat.mul_mod_right]
  exact ⟨rfl, rfl⟩

noncomputable def dyadicSideInsertScaleInitStmt (scrW scrR tblW tblR coinTbl : ℕ)
    (wSeedBaseOff wScr rScr : ℤ)
    (R ℓ M₀ d b T p_coord : ℕ) : ArithRAMStmt :=
  let seedStride1 : ℤ := ((seedBitCount R ℓ M₀ d b : ℕ) : ℤ)
  let wS := wScr + 4
  let wOff := wScr + 8
  let wSlotBW := wScr + 10
  let wSlotBR := wScr + 11
  let wBlkStart := wScr + 12
  let wSlotSeed := wScr + 13
  let wSubW := wScr + 20
  .ite (.intEq (.readHeap scrW (.lit wOff)) (.lit 0))
    (.seq (.writeWordHeap scrW (.lit wSlotSeed)
            (.add (.readHeap scrW (.lit wSeedBaseOff))
                  (.mul (.readHeap scrW (.lit wS)) (.lit seedStride1))))
          (slotInitFromCoinTblStmt scrW scrR tblW tblR coinTbl
            wSlotBW wSlotBR wBlkStart wSlotSeed wSubW rScr
            R ℓ M₀ d b T p_coord))
    .skip

theorem zeroRand_dyadicSideInsertScaleInitStmt (scrW scrR tblW tblR coinTbl : ℕ)
    (wSeedBaseOff wScr rScr : ℤ) (R ℓ M₀ d b T p_coord : ℕ) :
    H3a.ZeroRandStmt (dyadicSideInsertScaleInitStmt scrW scrR tblW tblR coinTbl
      wSeedBaseOff wScr rScr R ℓ M₀ d b T p_coord) :=
  .ite (.seq (.writeWordHeap _ _ _)
        (zeroRand_slotInitFromCoinTblStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _))
       .skip

theorem EncSlotBitSeed.mono_zero_frame {scrW scrR tblW' coinTbl : ℕ} {baseW' slotSeedOff : ℤ}
    {tblR' : ℕ} {baseR' : ℤ} {R ℓ M₀ d b : ℕ}
    {ω : ExplicitBitSeed R ℓ M₀ (d + 1) b} {m₀ m₁ : ArithRAMMemory}
    (hseed : EncSlotBitSeed coinTbl slotSeedOff ω m₀)
    (hfr : RadFrameOutside scrW scrR tblW' baseW' 0 tblR' baseR' 0 m₀ m₁)
    (hneScr : coinTbl ≠ scrW) :
    EncSlotBitSeed coinTbl slotSeedOff ω m₁ := by
  intro r a k j bi
  refine (hfr.1 coinTbl _ hneScr ?_).trans (hseed r a k j bi)
  rcases lt_or_ge (slotSeedOff + ((RacerP43.capCoordIdx r a k j * b + bi.val : ℕ) : ℤ)) baseW' with h | h
  · exact Or.inr (Or.inl h)
  · exact Or.inr (Or.inr (by omega))

theorem exec_dyadicSideInsertScaleInitStmt {d TW BW TR BR scrW scrR tblW tblR coinTbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSeedBaseOff wScr rScr sideBaseW slotBW slotBR seedBaseOff : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord cap_u t k q off blkStart : ℕ}
    (hk : k < L_p2)
    (hact : 1 ≤ q ∧ off < 2 ^ k)
    (hblk_eq : blkStart = (q - 1) * (2 * 2 ^ k))
    (hblk_le_t1 : blkStart ≤ t + 1)
    {entryAlive' : ℕ → Bool}
    {hSlot : H4a1.PureFilterSlot R ℓ M₀ d}
    {ω : ExplicitBitSeed R ℓ M₀ (d + 1) b}
    {S : LiveSlot R ℓ M₀ d}
    (htr₀ : LiveSlotTrackedH4 cap_u (2 ^ L_p2) (t + 1) entryAlive' hSlot S)
    (hcur_nz : 1 ≤ off → S.blkId = (blkStart : ℤ) ∧ S.builtCnt = 2 * off)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR) (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneCoinScr : coinTbl ≠ scrW)
    (hsideW : 0 ≤ sideBaseW ∧ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ (BW : ℤ))
    (hslotBW_side : sideBaseW ≤ slotBW ∧
      slotBW + slotWStride R ℓ M₀ cap_u (2 ^ L_p2) ≤ sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u)
    (hslotBR : 0 ≤ slotBR ∧ slotBR + slotRStride R ℓ M₀ d ≤ (BR : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + dyadicSideInsertRStride d ≤ (BR : ℤ))
    (hdisjSeed : wSeedBaseOff < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSeedBaseOff)
    (hdisjCoinW : coinTbl ≠ tblW ∨
      seedBaseOff + ((sideSeedStride L_p2 R ℓ M₀ d b : ℕ) : ℤ) ≤ sideBaseW ∨
      sideBaseW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ seedBaseOff)
    (hseedOff : wRead m₀ scrW wSeedBaseOff = seedBaseOff)
    (hs_r : wRead m₀ scrW (wScr + 4) = (k : ℤ))
    (hoff_r : wRead m₀ scrW (wScr + 8) = (off : ℤ))
    (hslotBW_r : wRead m₀ scrW (wScr + 10) = slotBW)
    (hslotBR_r : wRead m₀ scrW (wScr + 11) = slotBR)
    (hblk_r : wRead m₀ scrW (wScr + 12) = (blkStart : ℤ))
    (hseed : EncSlotBitSeed coinTbl
      (seedBaseOff + ((k * seedBitCount R ℓ M₀ d b : ℕ) : ℤ)) ω m₀)
    (henc₀ : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S m₀) :
    let basePure : H4a1.PureFilterSlot R ℓ M₀ d :=
      if off = 0 then H4a1.PureFilterSlot.init T p_coord ω else hSlot
    let sStride := slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
    let rStride := slotRStride R ℓ M₀ d
    ∃ (m₁ : ArithRAMMemory) (S_base : LiveSlot R ℓ M₀ d),
      DetExec inp
        (dyadicSideInsertScaleInitStmt scrW scrR tblW tblR coinTbl wSeedBaseOff wScr rScr R ℓ M₀ d b T p_coord)
        m₀ m₁ (50 + slotInitFromCoinTblCost R ℓ M₀ d b T p_coord) ∧
      InFootprint TW BW TR BR m₁ ∧
      LiveSlotTrackedH4 cap_u (2 ^ L_p2) (t + 1) entryAlive' basePure S_base ∧
      S_base.blkId = (blkStart : ℤ) ∧
      S_base.builtCnt = 2 * off ∧
      EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S_base m₁ ∧
      (∀ w, (w < wScr + 13 ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) ∧
      (∀ r, (r < rScr ∨ rScr + dyadicSideInsertRStride d ≤ r) →
        rRead m₁ scrR r = rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW slotBW sStride tblR slotBR rStride m₀ m₁ := by
  let _ := hact; let _ := hblk_eq
  intro basePure sStride rStride
  have hw_ge := dyadicSideInsertWStride_ge_44 ℓ M₀ cap_u
  have hr_ge := dyadicSideInsertRStride_ge_9 d
  by_cases hoff0 : off = 0
  · have hc0 : cValAt 0 inp m₀ (.intEq (.readHeap scrW (.lit (wScr + 8))) (.lit 0)) = true := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (wRead m₀ scrW (wScr + 8) = 0) = true
      rw [hoff_r, hoff0]; simp
    let seedStride1 : ℤ := ((seedBitCount R ℓ M₀ d b : ℕ) : ℤ)
    let slotSeedOff : ℤ := seedBaseOff + ((k * seedBitCount R ℓ M₀ d b : ℕ) : ℤ)
    let m1 := wWrite m₀ scrW (wScr + 13) slotSeedOff
    have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 13))
        (.add (.readHeap scrW (.lit wSeedBaseOff))
              (.mul (.readHeap scrW (.lit (wScr + 4))) (.lit seedStride1)))) m₀ m1 30 :=
      DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wScr + 13)) _ rfl
        (by change wRead m₀ scrW wSeedBaseOff + wRead m₀ scrW (wScr + 4) * seedStride1 = slotSeedOff
            rw [hseedOff, hs_r]; dsimp only [slotSeedOff, seedStride1]; push_cast; ring)
        (by dsimp [intExprOps]; omega)
    have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)
    have hfr01 : RadFrameOutside scrW scrR tblW slotBW 0 tblR slotBR 0 m₀ m1 :=
      RadFrameOutside.wWrite_scr scrW scrR tblW slotBW 0 tblR slotBR 0 m₀ _ _
    have hseed1 : EncSlotBitSeed coinTbl slotSeedOff ω m1 :=
      hseed.mono_zero_frame hfr01 hneCoinScr
    have henc1 : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S m1 :=
      henc₀.mono_frame hfr01 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
    have hdisjCoin_slot : coinTbl ≠ tblW ∨
        slotSeedOff + ((seedBitCount R ℓ M₀ d b : ℕ) : ℤ) ≤ slotBW ∨
        slotBW + sStride ≤ slotSeedOff := by
      rcases hdisjCoinW with ht | h1 | h2
      · exact Or.inl ht
      · right; left
        have hk_le : (k + 1) * seedBitCount R ℓ M₀ d b ≤ sideSeedStride L_p2 R ℓ M₀ d b :=
          Nat.mul_le_mul_right _ hk
        have hk_add : k * seedBitCount R ℓ M₀ d b + seedBitCount R ℓ M₀ d b ≤
            sideSeedStride L_p2 R ℓ M₀ d b := by
          calc k * seedBitCount R ℓ M₀ d b + seedBitCount R ℓ M₀ d b
              = (k + 1) * seedBitCount R ℓ M₀ d b := by ring
            _ ≤ sideSeedStride L_p2 R ℓ M₀ d b := hk_le
        have hkZ : ((k * seedBitCount R ℓ M₀ d b : ℕ) : ℤ) + ((seedBitCount R ℓ M₀ d b : ℕ) : ℤ) ≤
            ((sideSeedStride L_p2 R ℓ M₀ d b : ℕ) : ℤ) := by exact_mod_cast hk_add
        dsimp only [slotSeedOff]; omega
      · right; right
        have hk0 : (0 : ℤ) ≤ ((k * seedBitCount R ℓ M₀ d b : ℕ) : ℤ) := Nat.cast_nonneg _
        dsimp only [slotSeedOff, sStride]; omega
    obtain ⟨m_i, hd_init, hfp_i, henc_i, hkW_i, hkR_i, hfr_i⟩ :=
      exec_slotInitFromCoinTblStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
        inp (wScr + 10) (wScr + 11) (wScr + 12) (wScr + 13) (wScr + 20) rScr
        slotBW slotBR (blkStart : ℤ) slotSeedOff b T p_coord ω S
        hfp1 hscrW hscrR htblW htblR hneW hneR hneCoinScr
        ⟨by omega, le_trans hslotBW_side.2 hsideW.2⟩ hslotBR
        ⟨by omega, by omega⟩
        ⟨hrScr.1, by omega⟩
        (Or.inl (by omega)) (Or.inl (by omega)) hdisjCoin_slot
        ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hslotBW_r)
        ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hslotBR_r)
        ((wRead_wWrite_of_ne _ _ (Or.inr (by omega))).trans hblk_r)
        (wRead_wWrite_self _ _ _ _)
        hseed1 henc1
    have htr_i : LiveSlotTrackedH4 cap_u (2 ^ L_p2) (t + 1) entryAlive' basePure
        (S.init (S.ep + 1) (blkStart : ℤ) T p_coord ω) := by
      have hbp : basePure = H4a1.PureFilterSlot.init T p_coord ω := if_pos hoff0
      rw [hbp]
      exact LiveSlotTrackedH4.of_init htr₀ (Nat.lt_succ_self _) hblk_le_t1 T p_coord ω
    have hd_ite : DetExec inp
        (dyadicSideInsertScaleInitStmt scrW scrR tblW tblR coinTbl wSeedBaseOff wScr rScr R ℓ M₀ d b T p_coord)
        m₀ m_i (50 + slotInitFromCoinTblCost R ℓ M₀ d b T p_coord) :=
      (DetExecAt.ite_true (C_c := 15) (C_b := 30 + slotInitFromCoinTblCost R ℓ M₀ d b T p_coord)
        hc0 (by dsimp [condExprOps, intExprOps]; omega) (hd1.seq hd_init)).mono_cost (by omega)
    refine ⟨m_i, _, hd_ite, hfp_i, htr_i, rfl, by dsimp [LiveSlot.init]; omega, henc_i, ?_, ?_,
      (RadFrameOutside.wWrite_scr scrW scrR tblW slotBW sStride tblR slotBR rStride m₀ _ _).trans hfr_i⟩
    · intro w hw
      have hw_sub : w < wScr + 20 ∨ wScr + 20 + 5 ≤ w := by
        rcases hw with h | h; exact Or.inl (by omega); exact Or.inr (by omega)
      rw [hkW_i w hw_sub, wRead_wWrite_of_ne _ _ (Or.inr (by rcases hw with h | h <;> omega))]
    · intro r hr
      have hr_sub : r < rScr ∨ rScr + 9 ≤ r := by
        rcases hr with h | h; exact Or.inl h; exact Or.inr (by omega)
      rw [hkR_i r hr_sub, rRead_wWrite]
  · have hc0 : cValAt 0 inp m₀ (.intEq (.readHeap scrW (.lit (wScr + 8))) (.lit 0)) = false := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (wRead m₀ scrW (wScr + 8) = 0) = false
      rw [hoff_r]; exact decide_eq_false (by omega)
    have hcur := hcur_nz (by omega)
    have hbp : basePure = hSlot := if_neg hoff0
    have hd_ite : DetExec inp
        (dyadicSideInsertScaleInitStmt scrW scrR tblW tblR coinTbl wSeedBaseOff wScr rScr R ℓ M₀ d b T p_coord)
        m₀ m₀ (50 + slotInitFromCoinTblCost R ℓ M₀ d b T p_coord) :=
      (DetExecAt.ite_false (C_c := 15) (C_b := 1) hc0 (by dsimp [condExprOps, intExprOps]; omega)
        (DetExecAt.skip 0 inp m₀)).mono_cost (by omega)
    refine ⟨m₀, S, hd_ite, hfp₀, ?_, hcur.1, hcur.2, henc₀, fun _ _ => rfl, fun _ _ => rfl,
      RadFrameOutside.refl scrW scrR tblW slotBW sStride tblR slotBR rStride m₀⟩
    rw [hbp]; exact htr₀

noncomputable def dyadicSideInsertScaleActiveStmt (scrW scrR tblW tblR tblO coinTbl : ℕ)
    (wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d b T p_coord cap_u : ℕ) (A B_rat τ_d : ℚ) : ArithRAMStmt :=
  let bW := IntExpr.readHeap scrW (.lit wSideBaseW)
  let bR := IntExpr.readHeap scrW (.lit wSideBaseR)
  let sStride := slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
  let rStride := slotRStride R ℓ M₀ d
  let headerLen : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
  let rEntryEnd : ℤ := (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ)
  let wS := wScr + 4
  let wB := wScr + 6
  let wQ := wScr + 7
  let wOff := wScr + 8
  let wSlotIdx := wScr + 9
  let wSlotBW := wScr + 10
  let wSlotBR := wScr + 11
  let wBlkStart := wScr + 12
  let wEid := wScr + 14
  .seq (.writeWordHeap scrW (.lit wSlotIdx)
          (.add (.mul (.lit 2) (.readHeap scrW (.lit wS)))
                (.mod (.sub (.readHeap scrW (.lit wQ)) (.lit 1)) (.lit 2))))
  (.seq (.writeWordHeap scrW (.lit wSlotBW)
          (.add (.add bW (.lit headerLen))
                (.mul (.readHeap scrW (.lit wSlotIdx)) (.lit sStride))))
  (.seq (.writeWordHeap scrW (.lit wSlotBR)
          (.add (.add bR (.lit rEntryEnd))
                (.mul (.readHeap scrW (.lit wSlotIdx)) (.lit rStride))))
  (.seq (.writeWordHeap scrW (.lit wBlkStart)
          (.mul (.sub (.readHeap scrW (.lit wQ)) (.lit 1)) (.readHeap scrW (.lit wB))))
  (.seq (dyadicSideInsertScaleInitStmt scrW scrR tblW tblR coinTbl
          wSeedBaseOff wScr rScr R ℓ M₀ d b T p_coord)
  (.seq (.writeWordHeap scrW (.lit wEid)
          (.add (.readHeap scrW (.lit wBlkStart))
                (.mul (.lit 2) (.readHeap scrW (.lit wOff)))))
  (.seq (dyadicSideInsertOneEidStmt scrW scrR tblW tblR tblO
          wSideBaseW wSideBaseR wOffO wScr rScr L_p2 R ℓ M₀ d cap_u A B_rat τ_d)
  (.seq (.writeWordHeap scrW (.lit wEid)
          (.add (.readHeap scrW (.lit wEid)) (.lit 1)))
        (dyadicSideInsertOneEidStmt scrW scrR tblW tblR tblO
          wSideBaseW wSideBaseR wOffO wScr rScr L_p2 R ℓ M₀ d cap_u A B_rat τ_d))))))))

noncomputable def dyadicSideInsertScaleStepStmt (scrW scrR tblW tblR tblO coinTbl : ℕ)
    (wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d b T p_coord cap_u : ℕ) (A B_rat τ_d : ℚ) : ArithRAMStmt :=
  let wT := wScr + 1
  let wS := wScr + 4
  let wH := wScr + 5
  let wB := wScr + 6
  let wQ := wScr + 7
  let wOff := wScr + 8
  .seq (.writeWordHeap scrW (.lit wB) (.mul (.lit 2) (.readHeap scrW (.lit wH))))
  (.seq (.writeWordHeap scrW (.lit wQ) (.div (.readHeap scrW (.lit wT)) (.readHeap scrW (.lit wB))))
  (.seq (.writeWordHeap scrW (.lit wOff) (.mod (.readHeap scrW (.lit wT)) (.readHeap scrW (.lit wB))))
  (.seq (.ite (.and (.intLe (.lit 1) (.readHeap scrW (.lit wQ)))
                    (.intLt (.readHeap scrW (.lit wOff)) (.readHeap scrW (.lit wH))))
          (dyadicSideInsertScaleActiveStmt scrW scrR tblW tblR tblO coinTbl
            wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d)
          .skip)
  (.seq (.writeWordHeap scrW (.lit wS) (.add (.readHeap scrW (.lit wS)) (.lit 1)))
        (.writeWordHeap scrW (.lit wH) (.mul (.lit 2) (.readHeap scrW (.lit wH))))))))

def dyadicSideInsertScaleStepCost (R ℓ M₀ d b T p_coord cap_u : ℕ) : ℕ :=
  350 + slotInitFromCoinTblCost R ℓ M₀ d b T p_coord + 2 * dyadicSideInsertOneEidCost R ℓ M₀ d cap_u

theorem zeroRand_dyadicSideInsertScaleStepStmt (scrW scrR tblW tblR tblO coinTbl : ℕ)
    (wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr : ℤ)
    (n L_p2 R ℓ M₀ d b T p_coord cap_u : ℕ) (A B_rat τ_d : ℚ) :
    H3a.ZeroRandStmt (dyadicSideInsertScaleStepStmt scrW scrR tblW tblR tblO coinTbl
      wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d) :=
  .seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.ite
          (.seq (.writeWordHeap _ _ _)
          (.seq (.writeWordHeap _ _ _)
          (.seq (.writeWordHeap _ _ _)
          (.seq (.writeWordHeap _ _ _)
          (.seq (zeroRand_dyadicSideInsertScaleInitStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _)
          (.seq (.writeWordHeap _ _ _)
          (.seq (zeroRand_dyadicSideInsertOneEidStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _)
          (.seq (.writeWordHeap _ _ _)
                (zeroRand_dyadicSideInsertOneEidStmt _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _)))))))))
          .skip)
  (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _)))))

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
