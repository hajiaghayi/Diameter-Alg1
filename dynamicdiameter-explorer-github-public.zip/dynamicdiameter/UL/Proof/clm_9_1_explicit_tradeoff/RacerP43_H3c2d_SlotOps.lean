import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3c2b_SlotDLL
import UL.Proof.clm_9_1_explicit_tradeoff.RacerP43_H3c2c_EvalTuples

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt RandExec RandExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b1
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2

/-! ### 1. Pure Helpers for `holdH_pool` & `nd` Arithmetic during `insertRecord` -/

private lemma holdH_pool_of_listInv {R ℓ M₀ d cap_u B_max blkStart nd : ℕ}
    {ndL : Fin R → Fin (M₀ ^ ℓ) → List ℕ} {S : LiveSlot R ℓ M₀ d}
    (hinv : LiveSlotListInv cap_u B_max blkStart ndL S)
    (r₀ : Fin R) (c₀ : Fin (M₀ ^ ℓ))
    (hgt : ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ z ∈ ndL r c, z < nd) :
    let bkt := r₀.val * M₀ ^ ℓ + c₀.val
    0 ≤ S.effHead bkt →
      (S.effHead bkt).toNat < B_max * (R * cap_u) ∧ (S.effHead bkt).toNat ≠ nd := by
  intro bkt hnonneg
  have hdll := (hinv.2.2.2.1 r₀ c₀).1
  have hmem := (hinv.2.2.2.1 r₀ c₀).2
  cases hL : ndL r₀ c₀ with
  | nil =>
      have hhd : S.effHead bkt = -1 := by
        have h := hdll.2.1
        rw [hL] at h
        exact h
      omega
  | cons x xs =>
      have hhd : S.effHead bkt = (x : ℤ) := by
        have h := hdll.2.1
        rw [hL] at h
        exact h
      have hto : (S.effHead bkt).toNat = x := by
        rw [hhd]; exact Int.toNat_natCast x
      rw [hto]
      have hx_in : x ∈ ndL r₀ c₀ := by rw [hL]; exact List.mem_cons_self
      have hx_lt_nd : x < nd := hgt r₀ c₀ x hx_in
      exact ⟨(hmem x hx_in).1, by omega⟩

private lemma nd_bounds_and_div {R cap_u B_max loc r j : ℕ}
    (hloc : loc < B_max) (hr : r < R) (hj : j < cap_u) :
    let nd := (loc * R + r) * cap_u + j
    nd < B_max * (R * cap_u) ∧
    nd < (loc * R + (r + 1)) * cap_u ∧
    nd / (R * cap_u) = loc := by
  intro nd
  have hR_pos : 0 < R := by omega
  have hcu_pos : 0 < cap_u := by omega
  have hprod_pos : 0 < R * cap_u := Nat.mul_pos hR_pos hcu_pos
  have hlt_next : nd < (loc * R + (r + 1)) * cap_u := by
    dsimp [nd]
    calc (loc * R + r) * cap_u + j
        < (loc * R + r) * cap_u + cap_u := by omega
      _ = (loc * R + (r + 1)) * cap_u := by ring
  have hle_loc1 : (loc * R + (r + 1)) * cap_u ≤ (loc + 1) * (R * cap_u) := by
    have hr1 : loc * R + (r + 1) ≤ (loc + 1) * R := by
      rw [Nat.add_mul, one_mul]; omega
    calc (loc * R + (r + 1)) * cap_u
        ≤ ((loc + 1) * R) * cap_u := Nat.mul_le_mul_right cap_u hr1
      _ = (loc + 1) * (R * cap_u) := by ring
  have hlt_pool : nd < B_max * (R * cap_u) :=
    lt_of_lt_of_le hlt_next (hle_loc1.trans (Nat.mul_le_mul_right (R * cap_u) hloc))
  have hdiv : nd / (R * cap_u) = loc := by
    have hrem_lt : r * cap_u + j < R * cap_u := by
      calc r * cap_u + j < r * cap_u + cap_u := by omega
        _ = (r + 1) * cap_u := by ring
        _ ≤ R * cap_u := Nat.mul_le_mul_right cap_u hr
    have hnd_eq : nd = (r * cap_u + j) + (R * cap_u) * loc := by dsimp [nd]; ring
    rw [hnd_eq, add_comm, Nat.mul_add_div hprod_pos, Nat.div_eq_of_lt hrem_lt, add_zero]
  exact ⟨hlt_pool, hlt_next, hdiv⟩

/-! ### 2. `liveSlotInsertRecordStmt` (`DetExec`) -/

def slotInsWStride (ℓ M₀ cap_u : ℕ) : ℤ :=
  12 + evalWStride ℓ M₀ cap_u

def slotInsRStride (d : ℕ) : ℤ :=
  4 + 2 * (d : ℤ)

def liveSlotInsertCopyStmt (scrW scrR tblW tblR : ℕ)
    (wBaseW wBaseR wEid wInsBase rInsBase : ℤ)
    (R ℓ M₀ d cap_u : ℕ) (A B_rat τ_d : ℚ) : ArithRAMStmt :=
  let wLoc := wInsBase
  let wR := wInsBase + 1
  let wCapBaseR := wInsBase + 2
  let wJ := wInsBase + 3
  let wBkt := wInsBase + 4
  let wNd := wInsBase + 5
  let wPushScr := wInsBase + 6
  let wEvalBase := wInsBase + 12
  let wOutLen := wEvalBase + 11
  let codesBase := evalCodesOff ℓ M₀ wEvalBase
  let rWBase := rInsBase + 4 + (d : ℤ)
  .seq (.writeWordHeap scrW (.lit wCapBaseR)
          (.add (.readHeap scrW (.lit wBaseR))
                (.mul (.readHeap scrW (.lit wR))
                      (.lit ((((ℓ * M₀) * (d + 1) : ℕ) : ℤ))))))
  (.seq (evalCopyTuplesStmt scrW scrR tblR wCapBaseR wEvalBase rInsBase rWBase
          ℓ M₀ d cap_u true A B_rat τ_d)
  (.seq (.writeWordHeap scrW (.lit wJ) (.lit 0))
        (.repeatN (.readHeap scrW (.lit wOutLen))
          (.seq (.writeWordHeap scrW (.lit wBkt)
                  (.add (.mul (.readHeap scrW (.lit wR)) (.lit ((M₀ ^ ℓ : ℕ) : ℤ)))
                        (.readHeap scrW (.add (.lit codesBase) (.readHeap scrW (.lit wJ))))))
          (.seq (.writeWordHeap scrW (.lit wNd)
                  (.add (.mul (.add (.mul (.readHeap scrW (.lit wLoc)) (.lit (R : ℤ)))
                                    (.readHeap scrW (.lit wR)))
                              (.lit (cap_u : ℤ)))
                        (.readHeap scrW (.lit wJ))))
          (.seq (liveSlotPushNodeStmt scrW tblW wBaseW wBkt wNd wEid wPushScr R ℓ M₀)
                (.writeWordHeap scrW (.lit wJ)
                  (.add (.readHeap scrW (.lit wJ)) (.lit 1)))))))))

def liveSlotInsertCopyCost (ℓ M₀ d cap_u : ℕ) : ℕ :=
  100 + evalCopyTuplesCost ℓ M₀ d cap_u + cap_u * 450

private theorem exec_liveSlotInsertCopyStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBaseR wEid wInsBase rInsBase baseW baseR : ℤ)
    {R ℓ M₀ cap_u B_max blkStart loc : ℕ} (hM₀ : 1 ≤ M₀)
    (hloc : loc < B_max) (r₀ : Fin R) (A B_rat τ_d : ℚ)
    (w : EuclideanSpace ℝ (Fin d))
    {ndL₀ : Fin R → Fin (M₀ ^ ℓ) → List ℕ} {S₀ : LiveSlot R ℓ M₀ d}
    (hinv₀ : LiveSlotListInv cap_u B_max blkStart ndL₀ S₀)
    (hgt₀ : ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ z ∈ ndL₀ r c, z < (loc * R + r₀.val) * cap_u)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (htblW : tblW < TW) (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hwIns : 0 ≤ wInsBase ∧ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ (BW : ℤ))
    (hrIns : 0 ≤ rInsBase ∧ rInsBase + slotInsRStride d ≤ (BR : ℤ))
    (hdisjBW : wBaseW < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ wBaseW)
    (hdisjBR : wBaseR < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ wBaseR)
    (hdisjEid : wEid < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ wEid)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hbR : H3a.wRead m₀ scrW wBaseR = baseR)
    (heid_r : H3a.wRead m₀ scrW wEid = ((blkStart + loc : ℕ) : ℤ))
    (hloc_r : H3a.wRead m₀ scrW wInsBase = (loc : ℤ))
    (hr_r : H3a.wRead m₀ scrW (wInsBase + 1) = (r₀.val : ℤ))
    (hw_vec : ∀ i : Fin d, H3a.rRead m₀ scrR ((rInsBase + 4 + (d : ℤ)) + (i.val : ℤ)) = euclideanCoord w i)
    (henc₀ : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S₀ m₀) :
    let eid := blkStart + loc
    let S₁ := S₀.insertCopy hM₀ A B_rat τ_d cap_u loc eid w r₀
    ∃ (m₁ : ArithRAMMemory) (ndL₁ : Fin R → Fin (M₀ ^ ℓ) → List ℕ),
      DetExec inp (liveSlotInsertCopyStmt scrW scrR tblW tblR wBaseW wBaseR wEid wInsBase rInsBase R ℓ M₀ d cap_u A B_rat τ_d)
        m₀ m₁ (liveSlotInsertCopyCost ℓ M₀ d cap_u) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S₁ m₁ ∧
      LiveSlotListInv cap_u B_max blkStart ndL₁ S₁ ∧
      S₁.ep = S₀.ep ∧ S₁.caps = S₀.caps ∧ S₁.builtCnt = S₀.builtCnt ∧ S₁.blkId = S₀.blkId ∧
      (∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ z ∈ ndL₁ r c, z < (loc * R + (r₀.val + 1)) * cap_u) ∧
      (∀ idx : ℤ,
        (idx < wInsBase + 2 ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ idx) →
        H3a.wRead m₁ scrW idx = H3a.wRead m₀ scrW idx) ∧
      (∀ r : ℤ,
        (r < rInsBase ∨ rInsBase + 4 + (d : ℤ) ≤ r) →
        H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m₁ := by
  classical
  intro eid S₁
  have hstrideW : slotInsWStride ℓ M₀ cap_u = 12 + evalWStride ℓ M₀ cap_u := rfl
  have heval_ge : 12 ≤ evalWStride ℓ M₀ cap_u := by unfold evalWStride; omega
  have hstrideR : slotInsRStride d = 4 + 2 * (d : ℤ) := rfl
  let capBaseR : ℤ := baseR + (((r₀.val * ((ℓ * M₀) * (d + 1))) : ℕ) : ℤ)
  let m1 := H3a.wWrite m₀ scrW (wInsBase + 2) capBaseR
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wInsBase + 2))
      (.add (.readHeap scrW (.lit wBaseR))
            (.mul (.readHeap scrW (.lit (wInsBase + 1)))
                  (.lit ((((ℓ * M₀) * (d + 1) : ℕ) : ℤ)))))) m₀ m1 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wInsBase + 2)) _ rfl
      (by change H3a.wRead m₀ scrW wBaseR +
            H3a.wRead m₀ scrW (wInsBase + 1) * (((ℓ * M₀) * (d + 1) : ℕ) : ℤ) = capBaseR
          rw [hbR, hr_r]; dsimp [capBaseR])
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW (by omega) (by omega)
  have hfr1_0 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m1 :=
    RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ _ _
  have hCaps1 : ∀ (s : Fin ℓ) (k : Fin M₀) (j : Fin (d + 1)),
      H3a.rRead m1 tblR (capBaseR + (((s.val * M₀ + k.val) * (d + 1) : ℕ) : ℤ) + (j.val : ℤ)) =
        euclideanCoord (S₀.caps (r₀, s, k)) j := by
    intro s k j
    rw [rRead_wWrite]
    have haddr : capBaseR + (((s.val * M₀ + k.val) * (d + 1) : ℕ) : ℤ) + (j.val : ℤ) =
        baseR + (capCoordIdx r₀ s k j : ℤ) := by
      dsimp [capBaseR, capCoordIdx]; push_cast; ring
    rw [haddr]
    exact henc₀.2.2.2.1 r₀ s k j
  have hw_m1 : ∀ i : Fin d,
      H3a.rRead m1 scrR ((rInsBase + 4 + (d : ℤ)) + (i.val : ℤ)) = euclideanCoord w i := by
    intro i; rw [rRead_wWrite]; exact hw_vec i
  obtain ⟨m2, hd2, hfp2, hout_le, hout2, hcodes2, hkW2, hkR2, hfr2_0⟩ :=
    exec_evalCopyTuplesStmt (tblW := tblW) inp
      (wInsBase + 2) (wInsBase + 12) rInsBase (rInsBase + 4 + (d : ℤ)) capBaseR baseW baseR
      hM₀ cap_u true A B_rat τ_d (fun s k => S₀.caps (r₀, s, k)) w
      hfp1 hscrW hscrR hneR
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ (Or.inl le_rfl) (Or.inl (by omega))
      (wRead_wWrite_self _ _ _ _) hCaps1 hw_m1
  let eligList : Fin ℓ → List (Fin M₀) := fun s =>
    (List.finRange M₀).filter (fun k =>
      realSignedSqCapCond (A : ℝ) (B_rat : ℝ) (τ_d : ℝ) (S₀.caps (r₀, s, k)) w)
  let cnt : Fin ℓ → ℕ := fun s => (eligList s).length
  let elig : Fin ℓ → ℕ → ℕ := fun s j =>
    if hj : j < (eligList s).length then ((eligList s)[j]).val else 0
  let prodCap : ℕ := truncMul (cap_u + 1) cnt
  let outLen : ℕ := if (∀ s : Fin ℓ, 1 ≤ cnt s) ∧ prodCap ≤ cap_u then prodCap else 0
  have hout2' : H3a.wRead m2 scrW (wInsBase + 12 + 11) = (outLen : ℤ) := hout2
  have hout_le' : outLen ≤ cap_u := hout_le
  have hfr02_0 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m2 := hfr1_0.trans hfr2_0
  have henc2 : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S₀ m2 :=
    henc₀.mono_frame hfr02_0 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  let m3 := H3a.wWrite m2 scrW (wInsBase + 3) 0
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wInsBase + 3)) (.lit 0)) m2 m3 10 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wInsBase + 3)) (.lit 0) rfl rfl
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 hscrW (by omega) (by omega)
  have hfr03_0 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m3 :=
    hfr02_0.trans (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m2 _ _)
  have henc3 : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S₀ m3 :=
    henc₀.mono_frame hfr03_0 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  let stepSlot : LiveSlot R ℓ M₀ d → ℕ → LiveSlot R ℓ M₀ d := fun cur j =>
    let τ := mixedTuple hM₀ cnt elig j
    let code := encodeTuple τ
    let bkt := r₀.val * M₀ ^ ℓ + code
    let nd := (loc * R + r₀.val) * cap_u + j
    cur.pushNode bkt nd eid
  let SjOf : ℕ → LiveSlot R ℓ M₀ d := fun k =>
    Fin.foldl k (fun cur (i : Fin k) => stepSlot cur i.val) S₀
  let InvJ : ℕ → ArithRAMMemory → Prop := fun j m =>
    InFootprint TW BW TR BR m ∧
    H3a.wRead m scrW (wInsBase + 3) = (j : ℤ) ∧
    EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (SjOf j) m ∧
    (∃ ndLj : Fin R → Fin (M₀ ^ ℓ) → List ℕ,
      LiveSlotListInv cap_u B_max blkStart ndLj (SjOf j) ∧
      ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ z ∈ ndLj r c, z < (loc * R + r₀.val) * cap_u + j) ∧
    (SjOf j).ep = S₀.ep ∧ (SjOf j).caps = S₀.caps ∧ (SjOf j).builtCnt = S₀.builtCnt ∧ (SjOf j).blkId = S₀.blkId ∧
    (∀ idx < outLen,
      H3a.wRead m scrW (evalCodesOff ℓ M₀ (wInsBase + 12) + (idx : ℤ)) =
        @Nat.cast ℤ _ (encodeTuple (mixedTuple hM₀ cnt elig idx))) ∧
    (∀ idx : ℤ,
      (idx < wInsBase + 2 ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ idx) →
      H3a.wRead m scrW idx = H3a.wRead m₀ scrW idx) ∧
    (∀ r : ℤ,
      (r < rInsBase ∨ rInsBase + 4 + (d : ℤ) ≤ r) →
      H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
    RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m
  have hInvJ0 : InvJ 0 m3 := by
    have hSj0 : SjOf 0 = S₀ := by dsimp [SjOf]; rw [Fin.foldl_zero]
    refine ⟨hfp3, wRead_wWrite_self _ _ _ _, (by rw [hSj0]; exact henc3),
      ⟨ndL₀, (by rw [hSj0]; exact hinv₀), fun r c z hz => by have := hgt₀ r c z hz; omega⟩,
      by rw [hSj0], by rw [hSj0], by rw [hSj0], by rw [hSj0],
      fun idx hidx => ?_, fun idx hidx => ?_, fun r hr => ?_,
      hfr03_0.mono_range (Or.inl rfl) (Or.inl rfl)⟩
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold evalCodesOff; omega))]
      exact hcodes2 idx hidx
    · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          hkW2 idx (by omega),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    · rw [rRead_wWrite, hkR2 r hr, rRead_wWrite]
  obtain ⟨m_end, hInvEnd, hd_loop⟩ := DetExecAt.repeatN_nat
    (.readHeap scrW (.lit (wInsBase + 12 + 11))) _ outLen 10 450 InvJ hInvJ0
    (by change H3a.wRead m3 scrW (wInsBase + 12 + 11) = (outLen : ℤ)
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hout2')
    (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    (fun j hj m ⟨hfp_m, hj_m, henc_m, ⟨ndLj, hinv_j, hgt_j⟩, hep_j, hcap_j, hbc_j, hblk_j, hcodes_m, hkW_m, hkR_m, hfr_m⟩ => by
      have hj_cu : j < cap_u := lt_of_lt_of_le hj hout_le'
      let τ_j := mixedTuple hM₀ cnt elig j
      let code_j : Fin (M₀ ^ ℓ) := ⟨encodeTuple τ_j, encodeTuple_lt hM₀ τ_j⟩
      let bkt_j : ℕ := r₀.val * M₀ ^ ℓ + code_j.val
      let nd_j : ℕ := (loc * R + r₀.val) * cap_u + j
      have hbkt_lt : bkt_j < R * M₀ ^ ℓ := by
        dsimp [bkt_j]
        calc r₀.val * M₀ ^ ℓ + code_j.val
            < r₀.val * M₀ ^ ℓ + M₀ ^ ℓ := by have := code_j.isLt; omega
          _ = (r₀.val + 1) * M₀ ^ ℓ := by ring
          _ ≤ R * M₀ ^ ℓ := Nat.mul_le_mul_right _ r₀.isLt
      obtain ⟨hnd_pool, hnd_next, hnd_div⟩ := nd_bounds_and_div hloc r₀.isLt hj_cu
      have hr_m : H3a.wRead m scrW (wInsBase + 1) = (r₀.val : ℤ) :=
        (hkW_m (wInsBase + 1) (Or.inl (by omega))).trans hr_r
      have hloc_m : H3a.wRead m scrW wInsBase = (loc : ℤ) :=
        (hkW_m wInsBase (Or.inl (by omega))).trans hloc_r
      have hbW_m : H3a.wRead m scrW wBaseW = baseW :=
        (hkW_m wBaseW (by omega)).trans hbW
      have heid_m : H3a.wRead m scrW wEid = (eid : ℤ) :=
        (hkW_m wEid (by omega)).trans heid_r
      let m_a := H3a.wWrite m scrW (wInsBase + 4) (bkt_j : ℤ)
      let m_b := H3a.wWrite m_a scrW (wInsBase + 5) (nd_j : ℤ)
      have hd_a : DetExec inp (.writeWordHeap scrW (.lit (wInsBase + 4))
          (.add (.mul (.readHeap scrW (.lit (wInsBase + 1))) (.lit ((M₀ ^ ℓ : ℕ) : ℤ)))
                (.readHeap scrW (.add (.lit (evalCodesOff ℓ M₀ (wInsBase + 12)))
                                      (.readHeap scrW (.lit (wInsBase + 3)))))))
          m m_a 35 :=
        DetExecAt.writeWordHeap 0 inp m scrW (.lit (wInsBase + 4)) _ rfl
          (by change H3a.wRead m scrW (wInsBase + 1) * ((M₀ ^ ℓ : ℕ) : ℤ) +
                H3a.wRead m scrW (evalCodesOff ℓ M₀ (wInsBase + 12) + H3a.wRead m scrW (wInsBase + 3)) = (bkt_j : ℤ)
              rw [hr_m, hj_m, hcodes_m j hj]
              dsimp [bkt_j, code_j])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd_b : DetExec inp (.writeWordHeap scrW (.lit (wInsBase + 5))
          (.add (.mul (.add (.mul (.readHeap scrW (.lit wInsBase)) (.lit (R : ℤ)))
                            (.readHeap scrW (.lit (wInsBase + 1))))
                      (.lit (cap_u : ℤ)))
                (.readHeap scrW (.lit (wInsBase + 3)))))
          m_a m_b 35 :=
        DetExecAt.writeWordHeap 0 inp m_a scrW (.lit (wInsBase + 5)) _ rfl
          (by change (H3a.wRead m_a scrW wInsBase * (R : ℤ) + H3a.wRead m_a scrW (wInsBase + 1)) * (cap_u : ℤ) +
                H3a.wRead m_a scrW (wInsBase + 3) = (nd_j : ℤ)
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hloc_m,
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hr_m,
                  wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hj_m]
              dsimp [nd_j])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_b : InFootprint TW BW TR BR m_b :=
        InFootprint.wWrite (InFootprint.wWrite hfp_m hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
      have hfr_ab0 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m m_b :=
        (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m _ _).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_a _ _)
      have henc_b : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (SjOf j) m_b :=
        henc_m.mono_frame hfr_ab0 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
      have holdH_j := holdH_pool_of_listInv hinv_j r₀ code_j hgt_j
      obtain ⟨m_p, hd_p, hfp_p, henc_p, hkW_p, hkR_p, hfr_p⟩ :=
        exec_liveSlotPushNodeStmt (scrR := scrR) inp
          wBaseW (wInsBase + 4) (wInsBase + 5) wEid (wInsBase + 6) baseW baseR
          hbkt_lt hnd_pool (SjOf j) holdH_j hfp_b hscrW htblW hneW hbaseW ⟨by omega, by omega⟩
          (by omega) (Or.inl (by omega)) (Or.inl (by omega)) (by omega)
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hbW_m)
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
          (wRead_wWrite_self _ _ _ _)
          (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact heid_m)
          henc_b
      have hj_p : H3a.wRead m_p scrW (wInsBase + 3) = (j : ℤ) := by
        rw [hkW_p _ (Or.inl (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hj_m
      let m_nx := H3a.wWrite m_p scrW (wInsBase + 3) ((j + 1 : ℕ) : ℤ)
      have hd_nx : DetExec inp (.writeWordHeap scrW (.lit (wInsBase + 3))
          (.add (.readHeap scrW (.lit (wInsBase + 3))) (.lit 1))) m_p m_nx 20 :=
        DetExecAt.writeWordHeap 0 inp m_p scrW (.lit (wInsBase + 3)) _ rfl
          (by change H3a.wRead m_p scrW (wInsBase + 3) + 1 = _; rw [hj_p]; push_cast; ring)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hfp_nx : InFootprint TW BW TR BR m_nx := InFootprint.wWrite hfp_p hscrW (by omega) (by omega)
      have hSj_step : SjOf (j + 1) = (SjOf j).pushNode bkt_j nd_j eid := by
        dsimp [SjOf, stepSlot, bkt_j, nd_j, code_j, τ_j]
        rw [Fin.foldl_succ_last]; rfl
      have henc_nx : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (SjOf (j + 1)) m_nx := by
        rw [hSj_step]
        exact henc_p.mono_frame
          (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_p _ _)
          hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
      have heid_div : blkStart + nd_j / (R * cap_u) = eid := by
        rw [hnd_div]
      obtain ⟨hinv_next, hep_s, hcap_s, hbc_s, hblk_s, _, _⟩ :=
        LiveSlot.listInv_pushNode hM₀ hinv_j r₀ code_j hnd_pool hgt_j
      rw [heid_div] at hinv_next hep_s hcap_s hbc_s hblk_s
      have hfr_nx : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m_nx :=
        (((hfr_m.trans (hfr_ab0.mono_range (Or.inl rfl) (Or.inl rfl))).trans hfr_p).trans
          (RadFrameOutside.wWrite_scr scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m_p _ _))
      refine ⟨m_nx, (hd_a.seq (hd_b.seq (hd_p.seq hd_nx))).mono_cost (by omega),
        hfp_nx, wRead_wWrite_self _ _ _ _, henc_nx, ?_,
        by rw [hSj_step]; exact hep_s.trans hep_j,
        by rw [hSj_step]; exact hcap_s.trans hcap_j,
        by rw [hSj_step]; exact hbc_s.trans hbc_j,
        by rw [hSj_step]; exact hblk_s.trans hblk_j,
        ?_, ?_, ?_, hfr_nx⟩
      · refine ⟨fun r c => if r = r₀ ∧ c = code_j then nd_j :: ndLj r c else ndLj r c, ?_, ?_⟩
        · rw [hSj_step]; exact hinv_next
        · intro r c z hz
          dsimp only at hz
          by_cases hrc : r = r₀ ∧ c = code_j
          · rw [if_pos hrc] at hz
            rcases List.mem_cons.mp hz with rfl | hz_old
            · dsimp [nd_j]; omega
            · have := hgt_j r c z hz_old; omega
          · rw [if_neg hrc] at hz
            have := hgt_j r c z hz; omega
      · intro idx hidx
        have hcodes_ge : wInsBase + 24 ≤ evalCodesOff ℓ M₀ (wInsBase + 12) + (idx : ℤ) := by
          unfold evalCodesOff; omega
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW_p _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hcodes_m idx hidx
      · intro idx hidx
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            hkW_p idx (by omega),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
        exact hkW_m idx hidx
      · intro r hr
        rw [rRead_wWrite, hkR_p r, rRead_wWrite, rRead_wWrite]
        exact hkR_m r hr)
  rcases hInvEnd with ⟨hfp_end, _, henc_end, ⟨ndL_end, hinv_end, hgt_end⟩, hep_end, hcap_end, hbc_end, hblk_end, _, hkW_end, hkR_end, hfr_end⟩
  have hSj_eq : SjOf outLen = S₁ := by
    dsimp [S₁, LiveSlot.insertCopy, SjOf, stepSlot, outLen, prodCap, cnt, elig, eligList]
    by_cases hok : (∀ s : Fin ℓ, 1 ≤ (eligList s).length) ∧ truncMul (cap_u + 1) cnt ≤ cap_u
    · rw [if_pos hok, if_pos hok]
    · rw [if_neg hok, if_neg hok, Fin.foldl_zero]
  have hgt_end' : ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ z ∈ ndL_end r c, z < (loc * R + (r₀.val + 1)) * cap_u := by
    intro r c z hz
    have h1 := hgt_end r c z hz
    calc z < (loc * R + r₀.val) * cap_u + outLen := h1
      _ ≤ (loc * R + r₀.val) * cap_u + cap_u := by omega
      _ = (loc * R + (r₀.val + 1)) * cap_u := by ring
  have hcost_le : 25 + (evalCopyTuplesCost ℓ M₀ d cap_u + (10 + (10 + outLen * 450))) ≤
      liveSlotInsertCopyCost ℓ M₀ d cap_u := by
    unfold liveSlotInsertCopyCost
    have hmul : outLen * 450 ≤ cap_u * 450 := Nat.mul_le_mul_right 450 hout_le'
    omega
  rw [hSj_eq] at henc_end hinv_end hep_end hcap_end hbc_end hblk_end
  exact ⟨m_end, ndL_end, (hd1.seq (hd2.seq (hd3.seq hd_loop))).mono_cost hcost_le,
    hfp_end, henc_end, hinv_end, hep_end, hcap_end, hbc_end, hblk_end, hgt_end',
    hkW_end, hkR_end, hfr_end⟩

private lemma lt_mul_of_pool_and_div {B_max C_nd loc z : ℕ}
    (hpool : z < B_max * C_nd) (hdiv : z / C_nd < loc) :
    z < loc * C_nd := by
  have hC_pos : 0 < C_nd := by
    by_contra h0
    have hc0 : C_nd = 0 := by omega
    rw [hc0, mul_zero] at hpool; omega
  by_contra hge
  have hle : loc * C_nd ≤ z := by omega
  have h1 : loc ≤ z / C_nd := by
    have heq : (loc * C_nd) / C_nd = loc := Nat.mul_div_cancel loc hC_pos
    rw [← heq]
    exact Nat.div_le_div_right hle
  omega

def liveSlotInsertRecordStmt (scrW scrR tblW tblR tblO tblPts : ℕ)
    (wBaseW wBaseR wOffO wOffPt wEid wAlive wInsBase rInsBase : ℤ)
    (R ℓ M₀ d cap_u : ℕ) (A B_rat τ_d : ℚ) : ArithRAMStmt :=
  let wLoc := wInsBase
  let wR := wInsBase + 1
  let wTmpCtr := wInsBase + 9
  let rWBase := rInsBase + 4 + (d : ℤ)
  let bW := IntExpr.readHeap scrW (.lit wBaseW)
  .seq (.writeWordHeap scrW (.lit wLoc) (.readHeap tblW (.add bW (.lit 2))))
  (.seq (.ite (.intEq (.readHeap scrW (.lit wAlive)) (.lit 1))
          (.seq (subVecToScrStmt scrW scrR tblPts tblO wTmpCtr wOffPt wOffO rWBase d)
          (.seq (.writeWordHeap scrW (.lit wR) (.lit 0))
                (.repeatN (.lit (R : ℤ))
                  (.seq (liveSlotInsertCopyStmt scrW scrR tblW tblR wBaseW wBaseR wEid wInsBase rInsBase R ℓ M₀ d cap_u A B_rat τ_d)
                        (.writeWordHeap scrW (.lit wR)
                          (.add (.readHeap scrW (.lit wR)) (.lit 1)))))))
          .skip)
        (.writeWordHeap tblW (.add bW (.lit 2))
          (.add (.readHeap scrW (.lit wLoc)) (.lit 1))))

def liveSlotInsertRecordCost (R ℓ M₀ d cap_u : ℕ) : ℕ :=
  150 + 40 * d + R * (liveSlotInsertCopyCost ℓ M₀ d cap_u + 30)

theorem exec_liveSlotInsertRecordStmt {d TW BW TR BR scrW scrR tblW tblR tblO tblPts : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wBaseW wBaseR wOffO wOffPt wEid wAlive wInsBase rInsBase baseW baseR offO offPt : ℤ)
    {R ℓ M₀ cap_u B_max blkStart : ℕ} (hM₀ : 1 ≤ M₀)
    (A B_rat τ_d : ℚ)
    (o pt : EuclideanSpace ℝ (Fin d))
    {entryAlive : ℕ → Bool} {pSlot : PureFilterSlot R ℓ M₀ d} {S : LiveSlot R ℓ M₀ d}
    (hwf : S.WF cap_u B_max blkStart entryAlive pSlot)
    (hlt : S.builtCnt < B_max)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR)
    (htblW : tblW < TW)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR)
    (hneO : tblO ≠ scrR) (hnePts : tblPts ≠ scrR)
    (hbaseW : 0 ≤ baseW ∧ baseW + slotWStride R ℓ M₀ cap_u B_max ≤ (BW : ℤ))
    (hwIns : 0 ≤ wInsBase ∧ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ (BW : ℤ))
    (hrIns : 0 ≤ rInsBase ∧ rInsBase + slotInsRStride d ≤ (BR : ℤ))
    (hdisjBW : wBaseW < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ wBaseW)
    (hdisjBR : wBaseR < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ wBaseR)
    (hdisjO : wOffO < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ wOffO)
    (hdisjPt : wOffPt < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ wOffPt)
    (hdisjEid : wEid < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ wEid)
    (hdisjAl : wAlive < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ wAlive)
    (hbW : H3a.wRead m₀ scrW wBaseW = baseW)
    (hbR : H3a.wRead m₀ scrW wBaseR = baseR)
    (hoffO : H3a.wRead m₀ scrW wOffO = offO)
    (hoffPt : H3a.wRead m₀ scrW wOffPt = offPt)
    (heid_r : H3a.wRead m₀ scrW wEid = ((blkStart + S.builtCnt : ℕ) : ℤ))
    (halive_r : H3a.wRead m₀ scrW wAlive = if entryAlive (blkStart + S.builtCnt) then 1 else 0)
    (ho : ∀ c : Fin d, H3a.rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpt : ∀ c : Fin d, H3a.rRead m₀ tblPts (offPt + (c.val : ℤ)) = euclideanCoord pt c)
    (henc₀ : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀) :
    let eid := blkStart + S.builtCnt
    let S' := S.insertRecord hM₀ A B_rat τ_d cap_u eid (entryAlive eid) o pt
    let pSlot' := pSlot.insertPoint hM₀ A B_rat τ_d cap_u o pt eid
    ∃ m₁ : ArithRAMMemory,
      DetExec inp
        (liveSlotInsertRecordStmt scrW scrR tblW tblR tblO tblPts
          wBaseW wBaseR wOffO wOffPt wEid wAlive wInsBase rInsBase R ℓ M₀ d cap_u A B_rat τ_d)
        m₀ m₁ (liveSlotInsertRecordCost R ℓ M₀ d cap_u) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S' m₁ ∧
      S'.WF cap_u B_max blkStart entryAlive pSlot' ∧
      (∀ w : ℤ,
        (w < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ w) →
        H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r : ℤ,
        (r < rInsBase ∨ rInsBase + slotInsRStride d ≤ r) →
        H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m₁ := by
  intro eid S' pSlot'
  have hge4 := slotWStride_ge_four R ℓ M₀ cap_u B_max
  have hstrideW : slotInsWStride ℓ M₀ cap_u = 12 + evalWStride ℓ M₀ cap_u := rfl
  have heval_ge : 12 ≤ evalWStride ℓ M₀ cap_u := by unfold evalWStride; omega
  have hstrideR : slotInsRStride d = 4 + 2 * (d : ℤ) := rfl
  have hwf_out := (LiveSlot.wf_insertRecord hM₀ (A := A) (B_rat := B_rat) (τ_d := τ_d) hwf hlt o pt).1
  let loc := S.builtCnt
  rcases hwf with ⟨_, _, ndL₀, hinv₀, hnd_div₀⟩
  have hgt₀ : ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ z ∈ ndL₀ r c, z < (loc * R + 0) * cap_u := by
    intro r c z hz
    have hpool : z < B_max * (R * cap_u) := ((hinv₀.2.2.2.1 r c).2 z hz).1
    have hdiv : z / (R * cap_u) < loc := (hnd_div₀ r c).1 z hz
    have hlt_m := lt_mul_of_pool_and_div hpool hdiv
    calc z < loc * (R * cap_u) := hlt_m
      _ = (loc * R + 0) * cap_u := by ring
  -- Step 1: wLoc := tblW[baseW + 2]
  let m1 := H3a.wWrite m₀ scrW wInsBase (loc : ℤ)
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wInsBase)
      (.readHeap tblW (.add (.readHeap scrW (.lit wBaseW)) (.lit 2)))) m₀ m1 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wInsBase) _ rfl
      (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wBaseW + 2) = (loc : ℤ)
          rw [hbW]; exact henc₀.2.2.1)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW hwIns.1 (by omega)
  have hfr1_0 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m1 :=
    RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m₀ _ _
  have henc1 : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m1 :=
    henc₀.mono_frame hfr1_0 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  -- Step 2: branch on entryAlive eid
  let S₁ : LiveSlot R ℓ M₀ d :=
    if entryAlive eid then
      Fin.foldl R (fun cur r => cur.insertCopy hM₀ A B_rat τ_d cap_u loc eid (pt - o) r) S
    else S
  let iteStmt : ArithRAMStmt :=
    .ite (.intEq (.readHeap scrW (.lit wAlive)) (.lit 1))
      (.seq (subVecToScrStmt scrW scrR tblPts tblO (wInsBase + 9) wOffPt wOffO (rInsBase + 4 + (d : ℤ)) d)
      (.seq (.writeWordHeap scrW (.lit (wInsBase + 1)) (.lit 0))
            (.repeatN (.lit (R : ℤ))
              (.seq (liveSlotInsertCopyStmt scrW scrR tblW tblR wBaseW wBaseR wEid wInsBase rInsBase R ℓ M₀ d cap_u A B_rat τ_d)
                    (.writeWordHeap scrW (.lit (wInsBase + 1))
                      (.add (.readHeap scrW (.lit (wInsBase + 1))) (.lit 1)))))))
      .skip
  have hstep2 : ∃ m2 : ArithRAMMemory,
      DetExec inp iteStmt m1 m2 (60 + 40 * d + R * (liveSlotInsertCopyCost ℓ M₀ d cap_u + 30)) ∧
      InFootprint TW BW TR BR m2 ∧
      EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S₁ m2 ∧
      H3a.wRead m2 scrW wInsBase = (loc : ℤ) ∧
      (∀ w : ℤ,
        (w < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ w) →
        H3a.wRead m2 scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r : ℤ,
        (r < rInsBase ∨ rInsBase + slotInsRStride d ≤ r) →
        H3a.rRead m2 scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m2 := by
    cases hal : entryAlive eid with
    | false =>
        have hc_f : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m1
            (.intEq (.readHeap scrW (.lit wAlive)) (.lit 1)) = false := by
          simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
          change decide (H3a.wRead m1 scrW wAlive = 1) = false
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), halive_r]
          change decide ((if entryAlive eid then (1 : ℤ) else 0) = 1) = false
          rw [hal]; decide
        have hS1_eq : S₁ = S := by dsimp [S₁]; rw [hal]; rfl
        refine ⟨m1,
          (DetExecAt.ite_false (C_c := 10) hc_f
            (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            (DetExecAt.skip 0 inp m1)).mono_cost (by omega),
          hfp1, (by rw [hS1_eq]; exact henc1), wRead_wWrite_self _ _ _ _,
          fun w hw => wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          fun _ _ => rfl,
          hfr1_0.mono_range (Or.inl rfl) (Or.inl rfl)⟩
    | true =>
        have hc_t : UL.Proof_lem_7_2_RacerP33.cValAt 0 inp m1
            (.intEq (.readHeap scrW (.lit wAlive)) (.lit 1)) = true := by
          simp only [UL.Proof_lem_7_2_RacerP33.cValAt, evalArithCond, evalIntExpr]
          change decide (H3a.wRead m1 scrW wAlive = 1) = true
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), halive_r]
          change decide ((if entryAlive eid then (1 : ℤ) else 0) = 1) = true
          rw [hal]; decide
        obtain ⟨m_sub, hd_sub, hfp_sub, hsub_vec, hkW_sub, hkR_sub, hfr_sub0⟩ :=
          exec_subVecToScrStmt (tblW := tblW) (tblR := tblR) inp
            (wInsBase + 9) wOffPt wOffO offPt offO (rInsBase + 4 + (d : ℤ)) baseW baseR pt o
            hfp1 hscrW hscrR hnePts hneO ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
            (by omega) (by omega)
            (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hoffPt)
            (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hoffO)
            (fun c => by rw [rRead_wWrite]; exact hpt c)
            (fun c => by rw [rRead_wWrite]; exact ho c)
        let m_r0 := H3a.wWrite m_sub scrW (wInsBase + 1) 0
        have hd_r0 : DetExec inp (.writeWordHeap scrW (.lit (wInsBase + 1)) (.lit 0)) m_sub m_r0 10 :=
          DetExecAt.writeWordHeap 0 inp m_sub scrW (.lit (wInsBase + 1)) (.lit 0) rfl rfl
            (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        have hfp_r0 : InFootprint TW BW TR BR m_r0 := InFootprint.wWrite hfp_sub hscrW (by omega) (by omega)
        have hfr_r0_0 : RadFrameOutside scrW scrR tblW baseW 0 tblR baseR 0 m₀ m_r0 :=
          (hfr1_0.trans hfr_sub0).trans
            (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_sub _ _)
        have henc_r0 : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m_r0 :=
          henc₀.mono_frame hfr_r0_0 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
        let SrOf : ∀ k ≤ R, LiveSlot R ℓ M₀ d := fun k hk =>
          Fin.foldl k (fun cur (i : Fin k) =>
            cur.insertCopy hM₀ A B_rat τ_d cap_u loc eid (pt - o) ⟨i.val, lt_of_lt_of_le i.isLt hk⟩) S
        let InvR : ℕ → ArithRAMMemory → Prop := fun r_idx m =>
          ∃ hr_le : r_idx ≤ R,
            InFootprint TW BW TR BR m ∧
            H3a.wRead m scrW wInsBase = (loc : ℤ) ∧
            H3a.wRead m scrW (wInsBase + 1) = (r_idx : ℤ) ∧
            EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (SrOf r_idx hr_le) m ∧
            (∃ ndLr : Fin R → Fin (M₀ ^ ℓ) → List ℕ,
              LiveSlotListInv cap_u B_max blkStart ndLr (SrOf r_idx hr_le) ∧
              ∀ (r : Fin R) (c : Fin (M₀ ^ ℓ)), ∀ z ∈ ndLr r c, z < (loc * R + r_idx) * cap_u) ∧
            (∀ i : Fin d,
              H3a.rRead m scrR ((rInsBase + 4 + (d : ℤ)) + (i.val : ℤ)) = euclideanCoord (pt - o) i) ∧
            (∀ w : ℤ,
              (w < wInsBase ∨ wInsBase + slotInsWStride ℓ M₀ cap_u ≤ w) →
              H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
            (∀ r : ℤ,
              (r < rInsBase ∨ rInsBase + slotInsRStride d ≤ r) →
              H3a.rRead m scrR r = H3a.rRead m₀ scrR r) ∧
            RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m
        have hInvR0 : InvR 0 m_r0 := by
          have hSr0 : SrOf 0 (Nat.zero_le R) = S := by dsimp [SrOf]; rw [Fin.foldl_zero]
          refine ⟨Nat.zero_le R, hfp_r0, ?_, wRead_wWrite_self _ _ _ _,
            (by rw [hSr0]; exact henc_r0), ⟨ndL₀, (by rw [hSr0]; exact hinv₀), hgt₀⟩,
            fun i => by rw [rRead_wWrite]; exact hsub_vec i,
            fun w hw => ?_, fun r hr => ?_,
            hfr_r0_0.mono_range (Or.inl rfl) (Or.inl rfl)⟩
          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                hkW_sub wInsBase (by omega), wRead_wWrite_self]
          · rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                hkW_sub w (by omega),
                wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
          · rw [rRead_wWrite, hkR_sub r (by omega), rRead_wWrite]
        let C_r : ℕ := liveSlotInsertCopyCost ℓ M₀ d cap_u + 30
        obtain ⟨m_lp, hInvRL, hd_loop⟩ := DetExecAt.repeatN_nat (.lit (R : ℤ)) _ R 10 C_r
          InvR hInvR0 rfl (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (fun r_idx hr m ⟨hr_le, hfp_m, hloc_m, hr_m, henc_m, ⟨ndLr, hinv_r, hgt_r⟩, hw_m, hkW_m, hkR_m, hfr_m⟩ => by
            let rFin : Fin R := ⟨r_idx, hr⟩
            obtain ⟨m_c, ndL_c, hd_c, hfp_c, henc_c, hinv_c, _, _, _, _, hgt_c, hkW_c, hkR_c, hfr_c⟩ :=
              exec_liveSlotInsertCopyStmt inp wBaseW wBaseR wEid wInsBase rInsBase baseW baseR
                hM₀ hlt rFin A B_rat τ_d (pt - o) hinv_r hgt_r hfp_m hscrW hscrR htblW hneW hneR
                hbaseW hwIns hrIns hdisjBW hdisjBR hdisjEid
                ((hkW_m wBaseW hdisjBW).trans hbW)
                ((hkW_m wBaseR hdisjBR).trans hbR)
                ((hkW_m wEid hdisjEid).trans heid_r)
                hloc_m hr_m hw_m henc_m
            have hr_mc : H3a.wRead m_c scrW (wInsBase + 1) = (r_idx : ℤ) :=
              (hkW_c (wInsBase + 1) (Or.inl (by omega))).trans hr_m
            let m_nx := H3a.wWrite m_c scrW (wInsBase + 1) ((r_idx + 1 : ℕ) : ℤ)
            have hd_nx : DetExec inp (.writeWordHeap scrW (.lit (wInsBase + 1))
                (.add (.readHeap scrW (.lit (wInsBase + 1))) (.lit 1))) m_c m_nx 20 :=
              DetExecAt.writeWordHeap 0 inp m_c scrW (.lit (wInsBase + 1)) _ rfl
                (by change H3a.wRead m_c scrW (wInsBase + 1) + 1 = _; rw [hr_mc]; push_cast; ring)
                (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            have hfp_nx : InFootprint TW BW TR BR m_nx :=
              InFootprint.wWrite hfp_c hscrW (by omega) (by omega)
            have hSr_step : SrOf (r_idx + 1) hr =
                (SrOf r_idx hr_le).insertCopy hM₀ A B_rat τ_d cap_u loc eid (pt - o) rFin := by
              dsimp [SrOf, rFin]; rw [Fin.foldl_succ_last]; rfl
            have henc_nx : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max (SrOf (r_idx + 1) hr) m_nx := by
              rw [hSr_step]
              exact henc_c.mono_frame
                (RadFrameOutside.wWrite_scr scrW scrR tblW baseW 0 tblR baseR 0 m_c _ _)
                hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
            have hfr_nx : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m_nx :=
              (hfr_m.trans hfr_c).trans
                (RadFrameOutside.wWrite_scr scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m_c _ _)
            refine ⟨m_nx, (hd_c.seq hd_nx).mono_cost (by dsimp only [C_r]; omega),
              hr, hfp_nx,
              by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hkW_c wInsBase (Or.inl (by omega))]; exact hloc_m,
              wRead_wWrite_self _ _ _ _,
              henc_nx,
              ⟨ndL_c, (by rw [hSr_step]; exact hinv_c), hgt_c⟩,
              fun i => by
                rw [rRead_wWrite, hkR_c _ (Or.inr (by omega))]
                exact hw_m i,
              fun w hw => by
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hkW_c w (by omega)]
                exact hkW_m w hw,
              fun r hr_out => by
                rw [rRead_wWrite, hkR_c r (by omega)]
                exact hkR_m r hr_out,
              hfr_nx⟩)
        rcases hInvRL with ⟨_, hfp_lp, hloc_lp, _, henc_lp, _, _, hkW_lp, hkR_lp, hfr_lp⟩
        have hS1_eq : SrOf R le_rfl = S₁ := by
          dsimp [SrOf, S₁]; rw [hal]; rfl
        refine ⟨m_lp,
          (DetExecAt.ite_true (fB := .skip) (C_c := 10) hc_t
            (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
            (hd_sub.seq (hd_r0.seq hd_loop))).mono_cost (by dsimp only [C_r]; omega),
          hfp_lp, (by rw [← hS1_eq]; exact henc_lp), hloc_lp, hkW_lp, hkR_lp, hfr_lp⟩
  obtain ⟨m2, hd2, hfp2, henc2, hloc2, hkW2, hkR2, hfr2⟩ := hstep2
  -- Step 3: tblW[baseW + 2] := wLoc + 1
  let m3 := H3a.wWrite m2 tblW (baseW + 2) ((loc + 1 : ℕ) : ℤ)
  have hd3 : DetExec inp (.writeWordHeap tblW
      (.add (.readHeap scrW (.lit wBaseW)) (.lit 2))
      (.add (.readHeap scrW (.lit wInsBase)) (.lit 1))) m2 m3 30 :=
    DetExecAt.writeWordHeap 0 inp m2 tblW _ _
      (by change H3a.wRead m2 scrW wBaseW + 2 = baseW + 2
          rw [(hkW2 wBaseW hdisjBW).trans hbW])
      (by change H3a.wRead m2 scrW wInsBase + 1 = ((loc + 1 : ℕ) : ℤ)
          rw [hloc2]; push_cast; ring)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp3 : InFootprint TW BW TR BR m3 := InFootprint.wWrite hfp2 htblW (by omega) (by omega)
  have hfr3 : RadFrameOutside scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max) tblR baseR 0 m₀ m3 :=
    hfr2.trans (RadFrameOutside.wWrite_in scrW scrR tblW baseW (slotWStride R ℓ M₀ cap_u B_max)
      tblR baseR 0 m2 (idx := baseW + 2) _ (by omega) (by omega))
  rcases henc2 with ⟨hep2, hblk2, _, hcaps2, hbkt2, hnd2⟩
  have henc3 : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S' m3 := by
    have hS'_def : S' = { S₁ with builtCnt := loc + 1 } := rfl
    rw [hS'_def]
    refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hep2,
            by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact hblk2,
            wRead_wWrite_self _ _ _ _,
            fun r s k j => by rw [rRead_wWrite]; exact hcaps2 r s k j,
            fun bkt hb => ?_,
            fun nd hn => ?_⟩
    · have hbb := slotBktOff_bounds (cap_u := cap_u) (B_max := B_max) baseW hb
      rcases hbkt2 bkt hb with ⟨h1, h2⟩
      exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h2⟩
    · have hnb := slotNodeOff_bounds (cap_u := cap_u) (B_max := B_max) (R := R) (ℓ := ℓ) (M₀ := M₀) baseW hn
      have h0le : (0 : ℤ) ≤ 2 * ((R * M₀ ^ ℓ : ℕ) : ℤ) := by positivity
      rcases hnd2 nd hn with ⟨h1, h2, h3, h4, h5⟩
      exact ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h1,
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h2,
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h3,
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h4,
             by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega))]; exact h5⟩
  have hcost_le : 25 + ((60 + 40 * d + R * (liveSlotInsertCopyCost ℓ M₀ d cap_u + 30)) + 30) ≤
      liveSlotInsertRecordCost R ℓ M₀ d cap_u := by
    unfold liveSlotInsertRecordCost; omega
  refine ⟨m3, (hd1.seq (hd2.seq hd3)).mono_cost hcost_le, hfp3, henc3, hwf_out, ?_, ?_, hfr3⟩
  · intro w hw
    rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
    exact hkW2 w hw
  · intro r hr
    rw [rRead_wWrite]
    exact hkR2 r hr

end UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
