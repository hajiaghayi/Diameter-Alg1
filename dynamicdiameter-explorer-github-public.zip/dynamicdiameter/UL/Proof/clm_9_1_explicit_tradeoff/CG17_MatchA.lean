import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchA0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 5. `configDynClearStmt` (`O(1)` Header + `2 × Side` Init/Clear) & `configDynReadEdgeStmt` -/

def configDynClearWScr {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℤ :=
  2 + sops.sideWScrStride

def configDynClearCost {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℕ :=
  220 + 2 * max sops.zeroInitCost sops.clearCost

def configDynClearStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (wCfgBaseW wCfgBaseR wScr rScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wCfgBaseW)
  let bRE := IntExpr.readHeap scrW (.lit wCfgBaseR)
  let wSBW := wScr
  let wSBR := wScr + 1
  let wSub := wScr + 2
  .ite (.intEq (.readHeap tblW bWE) (.lit 0))
    (.seq (.writeWordHeap tblW bWE (.lit 1))
    (.seq (.writeWordHeap tblW (.add bWE (.lit 1)) (.lit (-1)))
    (.seq (.writeWordHeap tblW (.add bWE (.lit 2)) (.lit (-1)))
    (.seq (.writeWordHeap scrW (.lit wSBW) (.add bWE (.lit (cfgHdrWStride n))))
    (.seq (.writeWordHeap scrW (.lit wSBR) bRE)
    (.seq (sops.zeroInitStmt wSBW wSBR wSub rScr)
    (.seq (.writeWordHeap scrW (.lit wSBW) (.add bWE (.lit (cfgHdrWStride n + sops.sideWStride))))
    (.seq (.writeWordHeap scrW (.lit wSBR) (.add bRE (.lit sops.sideRStride)))
          (sops.zeroInitStmt wSBW wSBR wSub rScr)))))))))
    (.seq (.writeWordHeap tblW bWE (.add (.readHeap tblW bWE) (.lit 1)))
    (.seq (.writeWordHeap tblW (.add bWE (.lit 1)) (.lit (-1)))
    (.seq (.writeWordHeap tblW (.add bWE (.lit 2)) (.lit (-1)))
    (.seq (.writeWordHeap scrW (.lit wSBW) (.add bWE (.lit (cfgHdrWStride n))))
    (.seq (.writeWordHeap scrW (.lit wSBR) bRE)
    (.seq (sops.clearStmt wSBW wSBR wSub rScr)
    (.seq (.writeWordHeap scrW (.lit wSBW) (.add bWE (.lit (cfgHdrWStride n + sops.sideWStride))))
    (.seq (.writeWordHeap scrW (.lit wSBR) (.add bRE (.lit sops.sideRStride)))
          (sops.clearStmt wSBW wSBR wSub rScr)))))))))

theorem zeroRand_configDynClearStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (wCfgBaseW wCfgBaseR wScr rScr : ℤ) :
    ZeroRandStmt (configDynClearStmt sops wCfgBaseW wCfgBaseR wScr rScr) :=
  .ite
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (sops.zeroRand_zeroInitStmt _ _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
          (sops.zeroRand_zeroInitStmt _ _ _ _)))))))))
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
    (.seq (sops.zeroRand_clearStmt _ _ _ _)
    (.seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _)
          (sops.zeroRand_clearStmt _ _ _ _)))))))))

theorem exec_configDynClearStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCfgBaseW wCfgBaseR wScr rScr cfgBaseW cfgBaseR : ℤ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ cfgBaseW ∧ cfgBaseW + cfgTotalWStride n sops.sideWStride ≤ (BW : ℤ))
    (hbaseR : 0 ≤ cfgBaseR ∧ cfgBaseR + cfgTotalRStride sops.sideRStride ≤ (BR : ℤ))
    (hwBW : 0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr)
    (hwBR : 0 ≤ wCfgBaseR ∧ wCfgBaseR < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + configDynClearWScr sops ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + sops.sideRScrStride ≤ (BR : ℤ))
    (hbW : H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW)
    (hbR : H3a.wRead m₀ scrW wCfgBaseR = cfgBaseR)
    (hrdy : CfgSlotReady sops cfgBaseW cfgBaseR m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (configDynClearStmt sops wCfgBaseW wCfgBaseR wScr rScr)
        m₀ m₁ (configDynClearCost sops) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncCfgDyn sops cfgBaseW cfgBaseR
        (ConfigDynamicState.empty L_p2 R ℓ M₀ d b T_cdf p_coord) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgTotalWStride n sops.sideWStride)
        tblR cfgBaseR (cfgTotalRStride sops.sideRStride) m₀ m₁ := by
  have hw2 := sops.hsideW_ge_two
  have hr0 := sops.hsideR_nonneg
  have hwScr1 := sops.hsideWScr_pos
  have hrScr1 := sops.hsideRScr_pos
  have hhdr3 := cfgHdrWStride_ge_three n
  have hhdr_def : cfgHdrWStride n = 3 + 8 * (n : ℤ) := rfl
  have hbaseW' : 0 ≤ cfgBaseW ∧ cfgBaseW + (cfgHdrWStride n + 2 * sops.sideWStride) ≤ (BW : ℤ) := hbaseW
  have hbaseR' : 0 ≤ cfgBaseR ∧ cfgBaseR + 2 * sops.sideRStride ≤ (BR : ℤ) := hbaseR
  have hwScr' : 0 ≤ wScr ∧ wScr + (2 + sops.sideWScrStride) ≤ (BW : ℤ) := hwScr
  have hscrW : scrW < TW := hvt.1
  have htblW : tblW < TW := hvt.2.1
  have hneW : tblW ≠ scrW := hvt.2.2.2.2.2.2.1
  have hneR : tblR ≠ scrR := hvt.2.2.2.2.2.2.2.2.2.1
  let totW := cfgTotalWStride n sops.sideWStride
  let totR := cfgTotalRStride sops.sideRStride
  let lBW := cfgLeftSideWOff cfgBaseW n
  let rBW := cfgRightSideWOff cfgBaseW sops.sideWStride n
  let lBR := cfgLeftSideROff cfgBaseR
  let rBR := cfgRightSideROff cfgBaseR sops.sideRStride
  have htotW_def : totW = cfgHdrWStride n + 2 * sops.sideWStride := rfl
  have htotR_def : totR = 2 * sops.sideRStride := rfl
  rcases hrdy with ⟨hz0, hz⟩ | ⟨hep_pos, cs₀, henc₀⟩
  · -- Branch 1: uninitialized all-zero words (`wRead m₀ tblW cfgBaseW = 0`)
    have hc_true : cValAt 0 inp m₀
        (.intEq (.readHeap tblW (.readHeap scrW (.lit wCfgBaseW))) (.lit 0)) = true := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wCfgBaseW) = 0) = true
      rw [hbW, hz0]; rfl
    let m1 := H3a.wWrite m₀ tblW cfgBaseW 1
    let m2 := H3a.wWrite m1 tblW (cfgBaseW + 1) (-1)
    let m3 := H3a.wWrite m2 tblW (cfgBaseW + 2) (-1)
    let m4 := H3a.wWrite m3 scrW wScr lBW
    let m5 := H3a.wWrite m4 scrW (wScr + 1) lBR
    have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wCfgBaseW)) (.lit 1)) m₀ m1 20 :=
      DetExecAt.writeWordHeap 0 inp m₀ tblW _ (.lit 1) hbW rfl
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hbW1 : H3a.wRead m1 scrW wCfgBaseW = cfgBaseW :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans hbW
    have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 1)) (.lit (-1)))
        m1 m2 25 :=
      DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit (-1))
        (by change H3a.wRead m1 scrW wCfgBaseW + 1 = _; rw [hbW1]) rfl
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hbW2 : H3a.wRead m2 scrW wCfgBaseW = cfgBaseW :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans hbW1
    have hd3 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 2)) (.lit (-1)))
        m2 m3 25 :=
      DetExecAt.writeWordHeap 0 inp m2 tblW _ (.lit (-1))
        (by change H3a.wRead m2 scrW wCfgBaseW + 2 = _; rw [hbW2]) rfl
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hbW3 : H3a.wRead m3 scrW wCfgBaseW = cfgBaseW :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans hbW2
    have hbR3 : H3a.wRead m3 scrW wCfgBaseR = cfgBaseR := by
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
      exact hbR
    have hd4 : DetExec inp (.writeWordHeap scrW (.lit wScr)
        (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (cfgHdrWStride n)))) m3 m4 25 :=
      DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wScr) _ rfl
        (by change H3a.wRead m3 scrW wCfgBaseW + cfgHdrWStride n = lBW; rw [hbW3]; rfl)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd5 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1)) (.readHeap scrW (.lit wCfgBaseR)))
        m4 m5 20 :=
      DetExecAt.writeWordHeap 0 inp m4 scrW (.lit (wScr + 1)) _ rfl
        (by change H3a.wRead m4 scrW wCfgBaseR = lBR
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR3]; rfl)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hfp5 : InFootprint TW BW TR BR m5 := by
      unfold configDynClearWScr at hwScr
      exact InFootprint.wWrite (InFootprint.wWrite
        (InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀
          htblW hbaseW.1 (by omega)) htblW (by omega) (by omega)) htblW (by omega) (by omega))
        hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
    have hfr05 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m₀ m5 :=
      ((((rfo_wWrite_in _ _ _ _ _ _ _ _ m₀ 1 le_rfl (by omega)).trans
         (rfo_wWrite_in _ _ _ _ _ _ _ _ m1 (-1) (by omega) (by omega))).trans
         (rfo_wWrite_in _ _ _ _ _ _ _ _ m2 (-1) (by omega) (by omega))).trans
         (rfo_wWrite_scr _ _ _ _ _ _ _ _ m3 wScr lBW)).trans
         (rfo_wWrite_scr _ _ _ _ _ _ _ _ m4 (wScr + 1) lBR)
    have hz_ge3_m5 : ∀ i : ℤ, cfgBaseW + 3 ≤ i → i < cfgBaseW + totW → H3a.wRead m5 tblW i = 0 := by
      intro i hlo hhi
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      simpa [add_sub_cancel_left] using hz (i - cfgBaseW) (by omega) (by omega)
    have henc_hdr5 : EncLocalMatching tblW cfgBaseW n (LocalMatchingState.empty ℕ) m5 := by
      refine ⟨1, le_rfl, ?_, List.nodup_nil, List.nodup_nil,
        fun _ h => by simp [LocalMatchingState.empty] at h,
        fun _ h => by simp [LocalMatchingState.empty, LocalMatchingState.leftIndexSet] at h,
        fun _ h => by simp [LocalMatchingState.empty, LocalMatchingState.rightIndexSet] at h,
        ?_, ?_, ?_, fun _ _ h => by simp [LocalMatchingState.empty] at h,
        ?_, ?_, fun _ _ h => by simp [LocalMatchingState.empty] at h, ?_, ?_⟩
      · unfold cfgEpOff
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_self]; rfl
      · refine IsKeyDLL.congr (IsKeyDLL.nil (fun _ => 0) (fun _ => 0)) ?_ ?_
          (fun _ h => by simp [LocalMatchingState.empty] at h)
          (fun _ h => by simp [LocalMatchingState.empty] at h)
        · unfold cfgHeadOff
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
        · unfold cfgTailOff
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_self]
      · intro u hu; rw [hz_ge3_m5 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega)]; omega
      · intro u hu h; rw [hz_ge3_m5 _ (by unfold cfgMateLEpOff; omega) (by unfold cfgMateLEpOff; omega)] at h; omega
      · intro u hu; rw [hz_ge3_m5 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega)]; omega
      · intro u hu h; rw [hz_ge3_m5 _ (by unfold cfgMateREpOff; omega) (by unfold cfgMateREpOff; omega)] at h; omega
      · intro u hu
        rw [hz_ge3_m5 _ (by unfold cfgInIdxLEpOff; omega) (by unfold cfgInIdxLEpOff; omega)]
        exact ⟨by omega, ⟨fun h => by omega, fun h => by simp [LocalMatchingState.empty, LocalMatchingState.leftIndexSet] at h⟩⟩
      · intro u hu
        rw [hz_ge3_m5 _ (by unfold cfgInIdxREpOff; omega) (by unfold cfgInIdxREpOff; omega)]
        exact ⟨by omega, ⟨fun h => by omega, fun h => by simp [LocalMatchingState.empty, LocalMatchingState.rightIndexSet] at h⟩⟩
    obtain ⟨m6, hd6, hfp6, hencL6, hkW6, hfr56⟩ :=
      sops.exec_zeroInitStmt inp wScr (wScr + 1) (wScr + 2) rScr lBW lBR
        hfp5 hvt
        ⟨by unfold lBW cfgLeftSideWOff; omega, by unfold lBW cfgLeftSideWOff; omega⟩
        ⟨by unfold lBR cfgLeftSideROff; omega, by unfold lBR cfgLeftSideROff; omega⟩
        ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ (by omega)
        ⟨by omega, by unfold configDynClearWScr at hwScr; omega⟩ hrScr
        (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
        (wRead_wWrite_self _ _ _ _)
        (fun i hlo hhi => hz_ge3_m5 i (by unfold lBW cfgLeftSideWOff at hlo; omega)
          (by unfold lBW cfgLeftSideWOff at hhi; omega))
    have hbW6 : H3a.wRead m6 scrW wCfgBaseW = cfgBaseW := by
      rw [hkW6 wCfgBaseW (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact hbW3
    have hbR6 : H3a.wRead m6 scrW wCfgBaseR = cfgBaseR := by
      rw [hkW6 wCfgBaseR (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact hbR3
    let m7 := H3a.wWrite m6 scrW wScr rBW
    let m8 := H3a.wWrite m7 scrW (wScr + 1) rBR
    have hd7 : DetExec inp (.writeWordHeap scrW (.lit wScr)
        (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (cfgHdrWStride n + sops.sideWStride)))) m6 m7 25 :=
      DetExecAt.writeWordHeap 0 inp m6 scrW (.lit wScr) _ rfl
        (by change H3a.wRead m6 scrW wCfgBaseW + (cfgHdrWStride n + sops.sideWStride) = rBW
            rw [hbW6]; unfold rBW cfgRightSideWOff; ring)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd8 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
        (.add (.readHeap scrW (.lit wCfgBaseR)) (.lit sops.sideRStride))) m7 m8 25 :=
      DetExecAt.writeWordHeap 0 inp m7 scrW (.lit (wScr + 1)) _ rfl
        (by change H3a.wRead m7 scrW wCfgBaseR + sops.sideRStride = rBR
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR6]; rfl)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hfp8 : InFootprint TW BW TR BR m8 := by
      unfold configDynClearWScr at hwScr
      exact InFootprint.wWrite (InFootprint.wWrite hfp6 hscrW (by omega) (by omega))
        hscrW (by omega) (by omega)
    obtain ⟨m9, hd9, hfp9, hencR9, hkW9, hfr89⟩ :=
      sops.exec_zeroInitStmt inp wScr (wScr + 1) (wScr + 2) rScr rBW rBR
        hfp8 hvt
        ⟨by unfold rBW cfgRightSideWOff; omega, by unfold rBW cfgRightSideWOff; omega⟩
        ⟨by unfold rBR cfgRightSideROff; omega, by unfold rBR cfgRightSideROff; omega⟩
        ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ (by omega)
        ⟨by omega, by unfold configDynClearWScr at hwScr; omega⟩ hrScr
        (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
        (wRead_wWrite_self _ _ _ _)
        (fun i hlo hhi => by
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
              hfr56.1 tblW i hneW (Or.inr (Or.inr (by unfold lBW cfgLeftSideWOff; unfold rBW cfgRightSideWOff at hlo; omega)))]
          exact hz_ge3_m5 i (by unfold rBW cfgRightSideWOff at hlo; omega)
            (by unfold rBW cfgRightSideWOff at hhi; omega))
    have hfr56_tot : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m5 m6 :=
      rfo_mono_range hfr56
        (Or.inr ⟨by unfold lBW cfgLeftSideWOff; omega, by unfold lBW cfgLeftSideWOff; omega⟩)
        (Or.inr ⟨by unfold lBR cfgLeftSideROff; omega, by unfold lBR cfgLeftSideROff; omega⟩)
    have hfr68_tot : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m6 m8 :=
      (rfo_wWrite_scr _ _ _ _ _ _ _ _ m6 wScr rBW).trans
        (rfo_wWrite_scr _ _ _ _ _ _ _ _ m7 (wScr + 1) rBR)
    have hfr89_tot : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m8 m9 :=
      rfo_mono_range hfr89
        (Or.inr ⟨by unfold rBW cfgRightSideWOff; omega, by unfold rBW cfgRightSideWOff; omega⟩)
        (Or.inr ⟨by unfold rBR cfgRightSideROff; omega, by unfold rBR cfgRightSideROff; omega⟩)
    have henc_hdr9 : EncLocalMatching tblW cfgBaseW n (LocalMatchingState.empty ℕ) m9 := by
      refine henc_hdr5.mono_slice (fun i hlo hhi => ?_)
      rw [hfr89.1 tblW i hneW (Or.inr (Or.inl (by unfold rBW cfgRightSideWOff; omega))),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          hfr56.1 tblW i hneW (Or.inr (Or.inl (by unfold lBW cfgLeftSideWOff; omega)))]
    have hencL9 : sops.EncSide lBW lBR ∅ (DyadicSideIndex.empty L_p2 R ℓ M₀ d b T_cdf p_coord) m9 :=
      sops.encSide_mono_slice (fun _ h => by cases h) hencL6
        (fun i hlo hhi => by
          rw [hfr89.1 tblW i hneW (Or.inr (Or.inl (by unfold lBW cfgLeftSideWOff at hhi; unfold rBW cfgRightSideWOff; omega))),
              wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
        (fun i hlo hhi => by
          rw [hfr89.2 tblR i hneR (Or.inr (Or.inl (by unfold lBR cfgLeftSideROff at hhi; unfold rBR cfgRightSideROff; omega))),
              rRead_wWrite, rRead_wWrite])
    have hd_branch := hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq (hd8.seq hd9)))))))
    have hd_all : DetExec inp (configDynClearStmt sops wCfgBaseW wCfgBaseR wScr rScr)
        m₀ m9 (configDynClearCost sops) :=
      (DetExecAt.ite_true (C_c := 20) hc_true
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hd_branch).mono_cost (by unfold configDynClearCost; omega)
    refine ⟨m9, hd_all, hfp9, ⟨henc_hdr9, hencL9, hencR9⟩, fun w hw => ?_,
      hfr05.trans (hfr56_tot.trans (hfr68_tot.trans hfr89_tot))⟩
    rw [hkW9 w (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hkW6 w (by omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
  · -- Branch 2: epoch bump + side clears (`1 ≤ wRead m₀ tblW cfgBaseW`)
    rcases henc₀ with ⟨hm₀, hL₀, hR₀⟩
    rcases hm₀ with ⟨ep₀, hep1, hep_r, _, _, _, hUL0_lt, hUR0_lt, _, hmL_le, _, _, hmR_le, _, _, hiL, hiR⟩
    have hc_false : cValAt 0 inp m₀
        (.intEq (.readHeap tblW (.readHeap scrW (.lit wCfgBaseW))) (.lit 0)) = false := by
      simp only [cValAt, evalArithCond, evalIntExpr]
      change decide (H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wCfgBaseW) = 0) = false
      rw [hbW]; exact decide_eq_false (by omega)
    let m1 := H3a.wWrite m₀ tblW cfgBaseW ((ep₀ + 1 : ℕ) : ℤ)
    let m2 := H3a.wWrite m1 tblW (cfgBaseW + 1) (-1)
    let m3 := H3a.wWrite m2 tblW (cfgBaseW + 2) (-1)
    let m4 := H3a.wWrite m3 scrW wScr lBW
    let m5 := H3a.wWrite m4 scrW (wScr + 1) lBR
    have hd1 : DetExec inp (.writeWordHeap tblW (.readHeap scrW (.lit wCfgBaseW))
        (.add (.readHeap tblW (.readHeap scrW (.lit wCfgBaseW))) (.lit 1))) m₀ m1 30 :=
      DetExecAt.writeWordHeap 0 inp m₀ tblW _ _ hbW
        (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wCfgBaseW) + 1 = _
            rw [hbW]; unfold cfgEpOff at hep_r; rw [hep_r]; push_cast; ring)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hbW1 : H3a.wRead m1 scrW wCfgBaseW = cfgBaseW :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans hbW
    have hd2 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 1)) (.lit (-1)))
        m1 m2 25 :=
      DetExecAt.writeWordHeap 0 inp m1 tblW _ (.lit (-1))
        (by change H3a.wRead m1 scrW wCfgBaseW + 1 = _; rw [hbW1]) rfl
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hbW2 : H3a.wRead m2 scrW wCfgBaseW = cfgBaseW :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans hbW1
    have hd3 : DetExec inp (.writeWordHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 2)) (.lit (-1)))
        m2 m3 25 :=
      DetExecAt.writeWordHeap 0 inp m2 tblW _ (.lit (-1))
        (by change H3a.wRead m2 scrW wCfgBaseW + 2 = _; rw [hbW2]) rfl
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hbW3 : H3a.wRead m3 scrW wCfgBaseW = cfgBaseW :=
      (wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)).trans hbW2
    have hbR3 : H3a.wRead m3 scrW wCfgBaseR = cfgBaseR := by
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
          wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]
      exact hbR
    have hd4 : DetExec inp (.writeWordHeap scrW (.lit wScr)
        (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (cfgHdrWStride n)))) m3 m4 25 :=
      DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wScr) _ rfl
        (by change H3a.wRead m3 scrW wCfgBaseW + cfgHdrWStride n = lBW; rw [hbW3]; rfl)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd5 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1)) (.readHeap scrW (.lit wCfgBaseR)))
        m4 m5 20 :=
      DetExecAt.writeWordHeap 0 inp m4 scrW (.lit (wScr + 1)) _ rfl
        (by change H3a.wRead m4 scrW wCfgBaseR = lBR
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR3]; rfl)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hfp5 : InFootprint TW BW TR BR m5 := by
      unfold configDynClearWScr at hwScr
      exact InFootprint.wWrite (InFootprint.wWrite
        (InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀
          htblW hbaseW.1 (by omega)) htblW (by omega) (by omega)) htblW (by omega) (by omega))
        hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
    have hfr05 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m₀ m5 :=
      ((((rfo_wWrite_in _ _ _ _ _ _ _ _ m₀ ((ep₀ + 1 : ℕ) : ℤ) le_rfl (by omega)).trans
         (rfo_wWrite_in _ _ _ _ _ _ _ _ m1 (-1) (by omega) (by omega))).trans
         (rfo_wWrite_in _ _ _ _ _ _ _ _ m2 (-1) (by omega) (by omega))).trans
         (rfo_wWrite_scr _ _ _ _ _ _ _ _ m3 wScr lBW)).trans
         (rfo_wWrite_scr _ _ _ _ _ _ _ _ m4 (wScr + 1) lBR)
    have hk_ge3_m5 : ∀ i : ℤ, cfgBaseW + 3 ≤ i → H3a.wRead m5 tblW i = H3a.wRead m₀ tblW i := by
      intro i hlo
      rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    have henc_hdr5 : EncLocalMatching tblW cfgBaseW n (LocalMatchingState.empty ℕ) m5 := by
      refine ⟨ep₀ + 1, by omega, ?_, List.nodup_nil, List.nodup_nil,
        fun _ h => by simp [LocalMatchingState.empty] at h,
        fun _ h => by simp [LocalMatchingState.empty, LocalMatchingState.leftIndexSet] at h,
        fun _ h => by simp [LocalMatchingState.empty, LocalMatchingState.rightIndexSet] at h,
        ?_, ?_, ?_, fun _ _ h => by simp [LocalMatchingState.empty] at h,
        ?_, ?_, fun _ _ h => by simp [LocalMatchingState.empty] at h, ?_, ?_⟩
      · unfold cfgEpOff
        rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_self]
      · refine IsKeyDLL.congr (IsKeyDLL.nil (fun _ => 0) (fun _ => 0)) ?_ ?_
          (fun _ h => by simp [LocalMatchingState.empty] at h)
          (fun _ h => by simp [LocalMatchingState.empty] at h)
        · unfold cfgHeadOff
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self]
        · unfold cfgTailOff
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
              wRead_wWrite_self]
      · intro u hu; rw [hk_ge3_m5 _ (by unfold cfgMateLEpOff; omega)]; have := hmL_le u hu; omega
      · intro u hu h; rw [hk_ge3_m5 _ (by unfold cfgMateLEpOff; omega)] at h; have := hmL_le u hu; omega
      · intro u hu; rw [hk_ge3_m5 _ (by unfold cfgMateREpOff; omega)]; have := hmR_le u hu; omega
      · intro u hu h; rw [hk_ge3_m5 _ (by unfold cfgMateREpOff; omega)] at h; have := hmR_le u hu; omega
      · intro u hu
        rw [hk_ge3_m5 _ (by unfold cfgInIdxLEpOff; omega)]
        have := (hiL u hu).1
        exact ⟨by omega, ⟨fun h => by omega, fun h => by simp [LocalMatchingState.empty, LocalMatchingState.leftIndexSet] at h⟩⟩
      · intro u hu
        rw [hk_ge3_m5 _ (by unfold cfgInIdxREpOff; omega)]
        have := (hiR u hu).1
        exact ⟨by omega, ⟨fun h => by omega, fun h => by simp [LocalMatchingState.empty, LocalMatchingState.rightIndexSet] at h⟩⟩
    have hL5 : sops.EncSide lBW lBR cs₀.st.leftIndexSet cs₀.leftIdx m5 :=
      sops.encSide_mono_slice hUL0_lt hL₀
        (fun i hlo _ => hk_ge3_m5 i (by unfold lBW cfgLeftSideWOff at hlo; omega))
        (fun i _ _ => by simp [m5, m4, m3, m2, m1, rRead_wWrite])
    obtain ⟨m6, hd6, hfp6, hencL6, hkW6, hfr56⟩ :=
      sops.exec_clearStmt inp wScr (wScr + 1) (wScr + 2) rScr lBW lBR
        hfp5 hvt
        ⟨by unfold lBW cfgLeftSideWOff; omega, by unfold lBW cfgLeftSideWOff; omega⟩
        ⟨by unfold lBR cfgLeftSideROff; omega, by unfold lBR cfgLeftSideROff; omega⟩
        ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ (by omega)
        ⟨by omega, by unfold configDynClearWScr at hwScr; omega⟩ hrScr
        (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
        (wRead_wWrite_self _ _ _ _) hL5
    have hbW6 : H3a.wRead m6 scrW wCfgBaseW = cfgBaseW := by
      rw [hkW6 wCfgBaseW (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact hbW3
    have hbR6 : H3a.wRead m6 scrW wCfgBaseR = cfgBaseR := by
      rw [hkW6 wCfgBaseR (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      exact hbR3
    let m7 := H3a.wWrite m6 scrW wScr rBW
    let m8 := H3a.wWrite m7 scrW (wScr + 1) rBR
    have hd7 : DetExec inp (.writeWordHeap scrW (.lit wScr)
        (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (cfgHdrWStride n + sops.sideWStride)))) m6 m7 25 :=
      DetExecAt.writeWordHeap 0 inp m6 scrW (.lit wScr) _ rfl
        (by change H3a.wRead m6 scrW wCfgBaseW + (cfgHdrWStride n + sops.sideWStride) = rBW
            rw [hbW6]; unfold rBW cfgRightSideWOff; ring)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hd8 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1))
        (.add (.readHeap scrW (.lit wCfgBaseR)) (.lit sops.sideRStride))) m7 m8 25 :=
      DetExecAt.writeWordHeap 0 inp m7 scrW (.lit (wScr + 1)) _ rfl
        (by change H3a.wRead m7 scrW wCfgBaseR + sops.sideRStride = rBR
            rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR6]; rfl)
        (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
    have hfp8 : InFootprint TW BW TR BR m8 := by
      unfold configDynClearWScr at hwScr
      exact InFootprint.wWrite (InFootprint.wWrite hfp6 hscrW (by omega) (by omega))
        hscrW (by omega) (by omega)
    have hR8 : sops.EncSide rBW rBR cs₀.st.rightIndexSet cs₀.rightIdx m8 :=
      sops.encSide_mono_slice hUR0_lt hR₀
        (fun i hlo _ => by
          rw [wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
              hfr56.1 tblW i hneW (Or.inr (Or.inr (by unfold lBW cfgLeftSideWOff; unfold rBW cfgRightSideWOff at hlo; omega)))]
          exact hk_ge3_m5 i (by unfold rBW cfgRightSideWOff at hlo; omega))
        (fun i hlo _ => by
          rw [rRead_wWrite, rRead_wWrite,
              hfr56.2 tblR i hneR (Or.inr (Or.inr (by unfold lBR cfgLeftSideROff; unfold rBR cfgRightSideROff at hlo; omega)))]
          simp [m5, m4, m3, m2, m1, rRead_wWrite])
    obtain ⟨m9, hd9, hfp9, hencR9, hkW9, hfr89⟩ :=
      sops.exec_clearStmt inp wScr (wScr + 1) (wScr + 2) rScr rBW rBR
        hfp8 hvt
        ⟨by unfold rBW cfgRightSideWOff; omega, by unfold rBW cfgRightSideWOff; omega⟩
        ⟨by unfold rBR cfgRightSideROff; omega, by unfold rBR cfgRightSideROff; omega⟩
        ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ (by omega)
        ⟨by omega, by unfold configDynClearWScr at hwScr; omega⟩ hrScr
        (by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
        (wRead_wWrite_self _ _ _ _) hR8
    have hfr56_tot : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m5 m6 :=
      rfo_mono_range hfr56
        (Or.inr ⟨by unfold lBW cfgLeftSideWOff; omega, by unfold lBW cfgLeftSideWOff; omega⟩)
        (Or.inr ⟨by unfold lBR cfgLeftSideROff; omega, by unfold lBR cfgLeftSideROff; omega⟩)
    have hfr68_tot : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m6 m8 :=
      (rfo_wWrite_scr _ _ _ _ _ _ _ _ m6 wScr rBW).trans
        (rfo_wWrite_scr _ _ _ _ _ _ _ _ m7 (wScr + 1) rBR)
    have hfr89_tot : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m8 m9 :=
      rfo_mono_range hfr89
        (Or.inr ⟨by unfold rBW cfgRightSideWOff; omega, by unfold rBW cfgRightSideWOff; omega⟩)
        (Or.inr ⟨by unfold rBR cfgRightSideROff; omega, by unfold rBR cfgRightSideROff; omega⟩)
    have henc_hdr9 : EncLocalMatching tblW cfgBaseW n (LocalMatchingState.empty ℕ) m9 := by
      refine henc_hdr5.mono_slice (fun i hlo hhi => ?_)
      rw [hfr89.1 tblW i hneW (Or.inr (Or.inl (by unfold rBW cfgRightSideWOff; omega))),
          wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW),
          hfr56.1 tblW i hneW (Or.inr (Or.inl (by unfold lBW cfgLeftSideWOff; omega)))]
    have hencL9 : sops.EncSide lBW lBR ∅ (DyadicSideIndex.empty L_p2 R ℓ M₀ d b T_cdf p_coord) m9 :=
      sops.encSide_mono_slice (fun _ h => by cases h) hencL6
        (fun i hlo hhi => by
          rw [hfr89.1 tblW i hneW (Or.inr (Or.inl (by unfold lBW cfgLeftSideWOff at hhi; unfold rBW cfgRightSideWOff; omega))),
              wRead_wWrite_of_ne _ _ (Or.inl hneW), wRead_wWrite_of_ne _ _ (Or.inl hneW)])
        (fun i hlo hhi => by
          rw [hfr89.2 tblR i hneR (Or.inr (Or.inl (by unfold lBR cfgLeftSideROff at hhi; unfold rBR cfgRightSideROff; omega))),
              rRead_wWrite, rRead_wWrite])
    have hd_branch := hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq (hd6.seq (hd7.seq (hd8.seq hd9)))))))
    have hd_all : DetExec inp (configDynClearStmt sops wCfgBaseW wCfgBaseR wScr rScr)
        m₀ m9 (configDynClearCost sops) :=
      (DetExecAt.ite_false (C_c := 20) hc_false
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hd_branch).mono_cost (by unfold configDynClearCost; omega)
    refine ⟨m9, hd_all, hfp9, ⟨henc_hdr9, hencL9, hencR9⟩, fun w hw => ?_,
      hfr05.trans (hfr56_tot.trans (hfr68_tot.trans hfr89_tot))⟩
    rw [hkW9 w (by omega), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hkW6 w (by omega),
        wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm), wRead_wWrite_of_ne _ _ (Or.inl hneW.symm),
        wRead_wWrite_of_ne _ _ (Or.inl hneW.symm)]

def configDynReadEdgeCost : ℕ := 120

def configDynReadEdgeStmt (scrW tblW n : ℕ)
    (wCfgBaseW wOutHas wOutU wOutV wScr : ℤ) : ArithRAMStmt :=
  let bWE := IntExpr.readHeap scrW (.lit wCfgBaseW)
  let hdE := IntExpr.readHeap scrW (.lit wScr)
  .seq (.writeWordHeap scrW (.lit wScr) (.readHeap tblW (.add bWE (.lit 1))))
    (.ite (.intLt hdE (.lit 0))
      (.writeWordHeap scrW (.lit wOutHas) (.lit 0))
      (.seq (.writeWordHeap scrW (.lit wOutHas) (.lit 1))
      (.seq (.writeWordHeap scrW (.lit wOutU) hdE)
            (.writeWordHeap scrW (.lit wOutV)
              (.readHeap tblW (.add (.add bWE (.lit (3 + (n : ℤ)))) hdE))))))

theorem zeroRand_configDynReadEdgeStmt (scrW tblW n : ℕ)
    (wCfgBaseW wOutHas wOutU wOutV wScr : ℤ) :
    ZeroRandStmt (configDynReadEdgeStmt scrW tblW n wCfgBaseW wOutHas wOutU wOutV wScr) :=
  .seq (.writeWordHeap _ _ _)
    (.ite (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _)
      (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))))

theorem exec_configDynReadEdgeStmt {d n : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wCfgBaseW wOutHas wOutU wOutV wScr cfgBaseW cfgBaseR : ℤ)
    {st : LocalMatchingState ℕ}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hwBW : 0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr)
    (hwHas : 0 ≤ wOutHas ∧ wOutHas < wScr)
    (hwU : 0 ≤ wOutU ∧ wOutU < wScr)
    (hwV : 0 ≤ wOutV ∧ wOutV < wScr)
    (hne_out : wOutHas ≠ wOutU ∧ wOutHas ≠ wOutV ∧ wOutU ≠ wOutV ∧
      wCfgBaseW ≠ wOutHas ∧ wCfgBaseW ≠ wOutU ∧ wCfgBaseW ≠ wOutV)
    (hwScr : 0 ≤ wScr ∧ wScr + 1 ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW)
    (henc : EncLocalMatching tblW cfgBaseW n st m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (configDynReadEdgeStmt scrW tblW n wCfgBaseW wOutHas wOutU wOutV wScr)
        m₀ m₁ configDynReadEdgeCost ∧
      InFootprint TW BW TR BR m₁ ∧
      (match st.storedEdge with
       | none => H3a.wRead m₁ scrW wOutHas = 0
       | some (u, v) =>
           H3a.wRead m₁ scrW wOutHas = 1 ∧
           H3a.wRead m₁ scrW wOutU = (u : ℤ) ∧
           H3a.wRead m₁ scrW wOutV = (v : ℤ)) ∧
      (∀ w, w < wScr → w ≠ wOutHas → w ≠ wOutU → w ≠ wOutV →
        H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW 0 tblR cfgBaseR 0 m₀ m₁ := by
  have hscrW : scrW < TW := hvt.1
  have hneW : tblW ≠ scrW := hvt.2.2.2.2.2.2.1
  rcases henc with ⟨ep, _, _, _, _, hpairs_lt, _, _, hdll, _, _, hmL_of, _⟩
  let hdVal := H3a.wRead m₀ tblW (cfgHeadOff cfgBaseW)
  let m1 := H3a.wWrite m₀ scrW wScr hdVal
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr)
      (.readHeap tblW (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit 1)))) m₀ m1 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit wScr) _ rfl
      (by change H3a.wRead m₀ tblW (H3a.wRead m₀ scrW wCfgBaseW + 1) = hdVal; rw [hbW]; rfl)
      (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ hscrW hwScr.1 hwScr.2
  have hfr01 : RadFrameOutside scrW scrR tblW cfgBaseW 0 tblR cfgBaseR 0 m₀ m1 :=
    rfo_wWrite_scr _ _ _ _ _ _ _ _ m₀ wScr hdVal
  cases hlist : st.matchingList with
  | nil =>
      have hhd_neg : hdVal = -1 := (hdll.1 (by simp [hlist])).1
      have hc_t : cValAt 0 inp m1 (.intLt (.readHeap scrW (.lit wScr)) (.lit 0)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 scrW wScr < 0) = true
        rw [wRead_wWrite_self, hhd_neg]; rfl
      let m2 := H3a.wWrite m1 scrW wOutHas 0
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit wOutHas) (.lit 0)) m1 m2 15 :=
        DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wOutHas) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd_all : DetExec inp (configDynReadEdgeStmt scrW tblW n wCfgBaseW wOutHas wOutU wOutV wScr)
          m₀ m2 configDynReadEdgeCost :=
        (hd1.seq (DetExecAt.ite_true (C_c := 15) hc_t
          (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega) hd2)).mono_cost
          (by unfold configDynReadEdgeCost; omega)
      refine ⟨m2, hd_all,
        InFootprint.wWrite hfp1 hscrW hwHas.1 (by omega),
        by simp [LocalMatchingState.storedEdge, hlist]; exact wRead_wWrite_self _ _ _ _,
        fun w hw h1 _ _ => by
          rw [wRead_wWrite_of_ne _ _ (Or.inr h1),
              wRead_wWrite_of_ne _ _ (Or.inr (by omega))],
        hfr01.trans (rfo_wWrite_scr _ _ _ _ _ _ _ _ m1 wOutHas 0)⟩
  | cons e0 tl =>
      have hhd_eq : hdVal = (e0.left : ℤ) := by
        have hdll_ne := hdll.2 (by simp [hlist])
        have hget : ((st.matchingList.map MatchingEdge.pair).map Prod.fst)[0]? = some e0.left := by
          simp [hlist, MatchingEdge.pair]
        have hpos : 0 < ((st.matchingList.map MatchingEdge.pair).map Prod.fst).length := by
          simp [hlist]
        rw [List.getElem?_eq_getElem hpos, Option.some.injEq] at hget
        exact hdll_ne.1.trans (congrArg Nat.cast hget)
      have hpair_mem : (e0.left, e0.right) ∈ st.matchingList.map MatchingEdge.pair := by
        simp [hlist, MatchingEdge.pair]
      have hm_val : H3a.wRead m₀ tblW (cfgMateLValOff cfgBaseW n e0.left) = (e0.right : ℤ) :=
        (hmL_of e0.left e0.right hpair_mem).2
      have hc_f : cValAt 0 inp m1 (.intLt (.readHeap scrW (.lit wScr)) (.lit 0)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m1 scrW wScr < 0) = false
        rw [wRead_wWrite_self, hhd_eq]
        exact decide_eq_false (by omega)
      let m2 := H3a.wWrite m1 scrW wOutHas 1
      let m3 := H3a.wWrite m2 scrW wOutU (e0.left : ℤ)
      let m4 := H3a.wWrite m3 scrW wOutV (e0.right : ℤ)
      have hd2 : DetExec inp (.writeWordHeap scrW (.lit wOutHas) (.lit 1)) m1 m2 15 :=
        DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wOutHas) (.lit 1) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd3 : DetExec inp (.writeWordHeap scrW (.lit wOutU) (.readHeap scrW (.lit wScr))) m2 m3 15 :=
        DetExecAt.writeWordHeap 0 inp m2 scrW (.lit wOutU) _ rfl
          (by change H3a.wRead m2 scrW wScr = _
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self, hhd_eq])
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd4 : DetExec inp (.writeWordHeap scrW (.lit wOutV)
          (.readHeap tblW (.add (.add (.readHeap scrW (.lit wCfgBaseW)) (.lit (3 + (n : ℤ))))
                                (.readHeap scrW (.lit wScr))))) m3 m4 35 :=
        DetExecAt.writeWordHeap 0 inp m3 scrW (.lit wOutV) _ rfl
          (by change H3a.wRead m3 tblW ((H3a.wRead m3 scrW wCfgBaseW + (3 + (n : ℤ))) +
                H3a.wRead m3 scrW wScr) = (e0.right : ℤ)
              have hb3 : H3a.wRead m3 scrW wCfgBaseW = cfgBaseW := by
                rw [wRead_wWrite_of_ne _ _ (Or.inr hne_out.2.2.2.2.1),
                    wRead_wWrite_of_ne _ _ (Or.inr hne_out.2.2.2.1),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
                exact hbW
              have hs3 : H3a.wRead m3 scrW wScr = (e0.left : ℤ) := by
                rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
                    wRead_wWrite_self, hhd_eq]
              have haddr : (cfgBaseW + (3 + (n : ℤ))) + (e0.left : ℤ) = cfgMateLValOff cfgBaseW n e0.left := by
                unfold cfgMateLValOff; ring
              rw [hb3, hs3, haddr,
                  wRead_wWrite_of_ne _ _ (Or.inl hneW),
                  wRead_wWrite_of_ne _ _ (Or.inl hneW),
                  wRead_wWrite_of_ne _ _ (Or.inl hneW)]
              exact hm_val)
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      have hd_all : DetExec inp (configDynReadEdgeStmt scrW tblW n wCfgBaseW wOutHas wOutU wOutV wScr)
          m₀ m4 configDynReadEdgeCost :=
        (hd1.seq (DetExecAt.ite_false (C_c := 15) hc_f
          (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
          (hd2.seq (hd3.seq hd4)))).mono_cost (by unfold configDynReadEdgeCost; omega)
      have hfp4 : InFootprint TW BW TR BR m4 :=
        InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp1
          hscrW hwHas.1 (by omega)) hscrW hwU.1 (by omega)) hscrW hwV.1 (by omega)
      have hfr14 : RadFrameOutside scrW scrR tblW cfgBaseW 0 tblR cfgBaseR 0 m1 m4 :=
        ((rfo_wWrite_scr _ _ _ _ _ _ _ _ m1 wOutHas 1).trans
         (rfo_wWrite_scr _ _ _ _ _ _ _ _ m2 wOutU (e0.left : ℤ))).trans
         (rfo_wWrite_scr _ _ _ _ _ _ _ _ m3 wOutV (e0.right : ℤ))
      refine ⟨m4, hd_all,
        hfp4, ?_, ?_, hfr01.trans hfr14⟩
      · simp only [LocalMatchingState.storedEdge, hlist, List.head?_cons, Option.map_some, MatchingEdge.pair]
        refine ⟨?_, ?_, wRead_wWrite_self _ _ _ _⟩
        · rw [wRead_wWrite_of_ne _ _ (Or.inr hne_out.2.1),
              wRead_wWrite_of_ne _ _ (Or.inr hne_out.1),
              wRead_wWrite_self]
        · rw [wRead_wWrite_of_ne _ _ (Or.inr hne_out.2.2.1),
              wRead_wWrite_self]
      · intro w hw h1 h2 h3
        rw [wRead_wWrite_of_ne _ _ (Or.inr h3),
            wRead_wWrite_of_ne _ _ (Or.inr h2),
            wRead_wWrite_of_ne _ _ (Or.inr h1),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
