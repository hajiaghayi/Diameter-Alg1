import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeB0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG18

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43

theorem RadFrameOutside_mono_range {scrW scrR tblW : ℕ} {bW₁ lW₁ bW₂ lW₂ : ℤ}
    {tblR : ℕ} {bR₁ lR₁ bR₂ lR₂ : ℤ} {m₀ m₁ : ArithRAMMemory}
    (h : RadFrameOutside scrW scrR tblW bW₁ lW₁ tblR bR₁ lR₁ m₀ m₁)
    (hW : lW₁ = 0 ∨ (bW₂ ≤ bW₁ ∧ bW₁ + lW₁ ≤ bW₂ + lW₂))
    (hR : lR₁ = 0 ∨ (bR₂ ≤ bR₁ ∧ bR₁ + lR₁ ≤ bR₂ + lR₂)) :
    RadFrameOutside scrW scrR tblW bW₂ lW₂ tblR bR₂ lR₂ m₀ m₁ := by
  refine ⟨fun t i hs ho => h.1 t i hs ?_, fun t i hs ho => h.2 t i hs ?_⟩
  · rcases hW with rfl | ⟨hlo, hhi⟩
    · exact Or.inr (by omega)
    · rcases ho with ht | hlt | hge
      · exact Or.inl ht
      · exact Or.inr (Or.inl (by omega))
      · exact Or.inr (Or.inr (by omega))
  · rcases hR with rfl | ⟨hlo, hhi⟩
    · exact Or.inr (by omega)
    · rcases ho with ht | hlt | hge
      · exact Or.inl ht
      · exact Or.inr (Or.inl (by omega))
      · exact Or.inr (Or.inr (by omega))

/-! ### 4. `managedNodeOpenEmptyStmt` (`H4c2.ManagedNode.openEmpty`) -/

def openNodeWriteCenterVarStmt (scrW scrR tblR : ℕ)
    (wNodeBaseR rInO wCtr rAcc : ℤ) (d : ℕ) : ArithRAMStmt :=
  .seq (.writeRealHeap scrR (.lit rAcc) (.ofInt (.lit 0)))
  (.seq (forLoopStmt scrW wCtr d
          (.seq (.writeRealHeap tblR
                  (.add (.readHeap scrW (.lit wNodeBaseR)) (.readHeap scrW (.lit wCtr)))
                  (.readRealHeap scrR (.add (.lit rInO) (.readHeap scrW (.lit wCtr)))))
                (.writeRealHeap scrR (.lit rAcc)
                  (.add (.readRealHeap scrR (.lit rAcc))
                    (.mul (.readRealHeap scrR (.add (.lit rInO) (.readHeap scrW (.lit wCtr))))
                          (.readRealHeap scrR (.add (.lit rInO) (.readHeap scrW (.lit wCtr)))))))))
  (.seq (.writeRealHeap tblR
          (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit (d : ℤ)))
          (.readRealHeap scrR (.lit (rInO + (d : ℤ)))))
        (.ite (.realLe (.readRealHeap scrR (.lit rAcc))
                       (.readRealHeap scrR (.lit (rInO + (d : ℤ)))))
          (.writeRealHeap tblR
            (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit ((d : ℤ) + 1)))
            (.sub (.readRealHeap scrR (.lit (rInO + (d : ℤ))))
                  (.readRealHeap scrR (.lit rAcc))))
          (.writeRealHeap tblR
            (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit ((d : ℤ) + 1)))
            (.ofInt (.lit 0))))))

theorem hzr_openNodeWriteCenterVarStmt (scrW scrR tblR : ℕ)
    (wNodeBaseR rInO wCtr rAcc : ℤ) (d : ℕ) :
    HeapZeroRandStmt (openNodeWriteCenterVarStmt scrW scrR tblR wNodeBaseR rInO wCtr rAcc d) := by
  unfold openNodeWriteCenterVarStmt forLoopStmt
  repeat' constructor

theorem exec_openNodeWriteCenterVarStmt {d TW BW TR BR scrW scrR tblW tblR : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wNodeBaseR rInO wCtr rAcc nodeBaseR lenR : ℤ)
    (o : EuclideanSpace ℝ (Fin d)) (s : ℝ)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR) (htblR : tblR < TR) (hneR : tblR ≠ scrR)
    (hbaseR : 0 ≤ nodeBaseR ∧ nodeBaseR + lenR ≤ (BR : ℤ))
    (hlenR : (d : ℤ) + 2 ≤ lenR)
    (hwBR : 0 ≤ wNodeBaseR ∧ wNodeBaseR < wCtr)
    (hwCtr : 0 ≤ wCtr ∧ wCtr < (BW : ℤ))
    (hrInO : 0 ≤ rInO ∧ rInO + (d : ℤ) + 1 ≤ rAcc)
    (hrAcc : 0 ≤ rAcc ∧ rAcc < (BR : ℤ))
    (hbR : H3a.wRead m₀ scrW wNodeBaseR = nodeBaseR)
    (ho_in : ∀ c : Fin d, H3a.rRead m₀ scrR (rInO + (c.val : ℤ)) = euclideanCoord o c)
    (hs_in : H3a.rRead m₀ scrR (rInO + (d : ℤ)) = s) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (openNodeWriteCenterVarStmt scrW scrR tblR wNodeBaseR rInO wCtr rAcc d)
        m₀ m₁ (120 + 55 * d) ∧
      InFootprint TW BW TR BR m₁ ∧
      (∀ c : Fin d, H3a.rRead m₁ tblR (nodeCenterROff nodeBaseR + (c.val : ℤ)) = euclideanCoord o c) ∧
      H3a.rRead m₁ tblR (nodeHeightROff d nodeBaseR) = s ∧
      H3a.rRead m₁ tblR (nodeVarROff d nodeBaseR) = max 0 (liftVariance o s) ∧
      (∀ w, w < wCtr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW 0 0 tblR nodeBaseR ((d : ℤ) + 2) m₀ m₁ := by
  let pSq : ℕ → ℝ := fun k =>
    ∑ c ∈ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k), (euclideanCoord o c) ^ 2
  have hdet : ExecDet TW BW TR BR inp
      (openNodeWriteCenterVarStmt scrW scrR tblR wNodeBaseR rInO wCtr rAcc d) m₀
      (fun m₁ =>
        (∀ c : Fin d, H3a.rRead m₁ tblR (nodeCenterROff nodeBaseR + (c.val : ℤ)) = euclideanCoord o c) ∧
        H3a.rRead m₁ tblR (nodeHeightROff d nodeBaseR) = s ∧
        H3a.rRead m₁ tblR (nodeVarROff d nodeBaseR) = max 0 (liftVariance o s) ∧
        (∀ w, w < wCtr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
        RadFrameOutside scrW scrR tblW 0 0 tblR nodeBaseR ((d : ℤ) + 2) m₀ m₁)
      (120 + 55 * d) := by
    unfold openNodeWriteCenterVarStmt
    refine ExecDet.seq' (105 + 55 * d)
      (ExecDet.rWrite (C := 15) inp scrR (.lit rAcc) (.ofInt (.lit 0)) rAcc 0
        hfp₀ hscrR hrAcc.1 hrAcc.2 rfl (by simp [evalRealExpr, evalIntExpr])
        (by dsimp [intExprOps, realExprOps]; omega)
        (Post := fun m => m = H3a.rWrite m₀ scrR rAcc 0) rfl)
      (by omega)
      (fun ma hma hfpa => ?_)
    let Inv : ℕ → ArithRAMMemory → Prop := fun k m =>
      H3a.rRead m scrR rAcc = pSq k ∧
      (∀ c : Fin d, c.val < k → H3a.rRead m tblR (nodeBaseR + (c.val : ℤ)) = euclideanCoord o c) ∧
      (∀ c : Fin d, H3a.rRead m scrR (rInO + (c.val : ℤ)) = euclideanCoord o c) ∧
      H3a.rRead m scrR (rInO + (d : ℤ)) = s ∧
      (∀ w, w < wCtr → H3a.wRead m scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW 0 0 tblR nodeBaseR ((d : ℤ) + 2) m₀ m
    refine ExecDet.seq' 50
      (ExecDet.forLoop scrW wCtr d _ Inv 45 hfpa hscrW hwCtr.1 hwCtr.2 ?_ ?_)
      (by omega)
      (fun mb ⟨hacc_b, ho_b, _, hs_b, hw_b, hfr_b⟩ hfpb => ?_)
    · subst hma
      refine ⟨by rw [rRead_wWrite, rRead_rWrite_self]; simp [pSq],
        fun _ hc => absurd hc (Nat.not_lt_zero _),
        fun c => by
          have := c.isLt
          rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact ho_in c,
        by rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hs_in,
        fun w hw => by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite],
        ⟨fun t i hts _ => by rw [wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_rWrite],
         fun t i hts _ => by rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hts)]⟩⟩
    · intro k hk m ⟨hacc_m, ho_prev, ho_in_m, hs_in_m, hw_m, hfr_m⟩ hctr hfpm
      let ck : Fin d := ⟨k, hk⟩
      have hbR_m : H3a.wRead m scrW wNodeBaseR = nodeBaseR := (hw_m wNodeBaseR hwBR.2).trans hbR
      refine ExecDet.seq' 23
        (ExecDet.rWrite (C := 22) inp tblR
          (.add (.readHeap scrW (.lit wNodeBaseR)) (.readHeap scrW (.lit wCtr)))
          (.readRealHeap scrR (.add (.lit rInO) (.readHeap scrW (.lit wCtr))))
          (nodeBaseR + (k : ℤ)) (euclideanCoord o ck)
          hfpm htblR (by omega) (by omega)
          (by change H3a.wRead m scrW wNodeBaseR + H3a.wRead m scrW wCtr = _; rw [hbR_m, hctr])
          (by change H3a.rRead m scrR (rInO + H3a.wRead m scrW wCtr) = _; rw [hctr]; exact ho_in_m ck)
          (by dsimp [intExprOps, realExprOps]; omega)
          (Post := fun mx => mx = H3a.rWrite m tblR (nodeBaseR + (k : ℤ)) (euclideanCoord o ck)) rfl)
        (by omega)
        (fun mx hmx hfpx => ?_)
      have hsplit : (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k + 1) =
          insert ck ((Finset.univ : Finset (Fin d)).filter (fun c => c.val < k)) := by
        ext c; simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert, Fin.ext_iff, ck]; omega
      have hnot : ck ∉ (Finset.univ : Finset (Fin d)).filter (fun c => c.val < k) := by simp [ck]
      have hpSq_s : pSq (k + 1) = pSq k + (euclideanCoord o ck) ^ 2 := by
        dsimp [pSq]; rw [hsplit, Finset.sum_insert hnot, add_comm]
      refine ExecDet.rWrite inp scrR (.lit rAcc) _ rAcc (pSq (k + 1))
        hfpx hscrR hrAcc.1 hrAcc.2 rfl
        (by subst hmx
            change H3a.rRead (H3a.rWrite m tblR _ _) scrR rAcc +
              H3a.rRead (H3a.rWrite m tblR _ _) scrR (rInO + H3a.wRead (H3a.rWrite m tblR _ _) scrW wCtr) *
              H3a.rRead (H3a.rWrite m tblR _ _) scrR (rInO + H3a.wRead (H3a.rWrite m tblR _ _) scrW wCtr) = _
            rw [wRead_rWrite, hctr, rRead_rWrite_of_ne _ _ (Or.inl hneR.symm),
                rRead_rWrite_of_ne _ _ (Or.inl hneR.symm), hacc_m, ho_in_m ck, hpSq_s, sq])
        (by dsimp [intExprOps, realExprOps]; omega) ?_
      subst hmx
      refine ⟨by rw [wRead_rWrite, wRead_rWrite]; exact hctr,
        by rw [rRead_wWrite, rRead_rWrite_self],
        fun c hc => ?_,
        fun c => ?_,
        by rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr (by omega)),
               rRead_rWrite_of_ne _ _ (Or.inl hneR.symm)]; exact hs_in_m,
        fun w hw => by rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_rWrite, wRead_rWrite]; exact hw_m w hw,
        ⟨fun t i hts _ => by
           rw [wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_rWrite, wRead_rWrite]; exact hfr_m.1 t i hts (Or.inr (by omega)),
         fun t i hts hout => by
           rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hts)]
           rcases hout with ht | hlt | hge
           · rw [rRead_rWrite_of_ne _ _ (Or.inl ht)]; exact hfr_m.2 t i hts (Or.inl ht)
           · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hfr_m.2 t i hts (Or.inr (Or.inl hlt))
           · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact hfr_m.2 t i hts (Or.inr (Or.inr hge))⟩⟩
      · rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inl hneR)]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hc with hlt | heq
        · rw [rRead_rWrite_of_ne _ _ (Or.inr (by omega))]; exact ho_prev c hlt
        · have hc_eq : c = ck := Fin.ext heq; subst hc_eq; rw [rRead_rWrite_self]
      · have := c.isLt
        rw [rRead_wWrite, rRead_rWrite_of_ne _ _ (Or.inr (by omega)),
            rRead_rWrite_of_ne _ _ (Or.inl hneR.symm)]
        exact ho_in_m c
    · have hbR_b : H3a.wRead mb scrW wNodeBaseR = nodeBaseR := (hw_b wNodeBaseR hwBR.2).trans hbR
      have hnorm : pSq d = ‖o‖ ^ 2 := by
        rw [EuclideanSpace.norm_eq, Real.sq_sqrt (Finset.sum_nonneg fun _ _ => sq_nonneg _)]
        dsimp [pSq, euclideanCoord]
        exact Finset.sum_congr (by ext c; simp) (fun c _ => by simp [sq_abs])
      have hacc_n : H3a.rRead mb scrR rAcc = ‖o‖ ^ 2 := hacc_b.trans hnorm
      refine ExecDet.seq' 35
        (ExecDet.rWrite (C := 15) inp tblR
          (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit (d : ℤ)))
          (.readRealHeap scrR (.lit (rInO + (d : ℤ))))
          (nodeHeightROff d nodeBaseR) s
          hfpb htblR (by unfold nodeHeightROff; omega) (by unfold nodeHeightROff; omega)
          (by change H3a.wRead mb scrW wNodeBaseR + (d : ℤ) = _; rw [hbR_b]; rfl)
          hs_b (by dsimp [intExprOps, realExprOps]; omega)
          (Post := fun mc => mc = H3a.rWrite mb tblR (nodeHeightROff d nodeBaseR) s) rfl)
        (by omega)
        (fun mc hmc hfpc => ?_)
      subst hmc
      let md := H3a.rWrite mb tblR (nodeHeightROff d nodeBaseR) s
      have hbR_c : H3a.wRead md scrW wNodeBaseR = nodeBaseR := by rw [wRead_rWrite]; exact hbR_b
      have hacc_c : H3a.rRead md scrR rAcc = ‖o‖ ^ 2 := by
        rw [rRead_rWrite_of_ne _ _ (Or.inl hneR.symm)]; exact hacc_n
      have hs_c : H3a.rRead md scrR (rInO + (d : ℤ)) = s := by
        rw [rRead_rWrite_of_ne _ _ (Or.inl hneR.symm)]; exact hs_b
      refine ExecDet.ite
        (.realLe (.readRealHeap scrR (.lit rAcc)) (.readRealHeap scrR (.lit (rInO + (d : ℤ)))))
        _ _ (C_c := 15) (C_b := 20)
        (by dsimp [condExprOps, realExprOps, intExprOps]; omega)
        (fun hle => ?_) (fun hgt => ?_)
      · have hle_r : ‖o‖ ^ 2 ≤ s := by
          simp only [evalArithCond, evalRealExpr, evalIntExpr] at hle
          change decide (H3a.rRead md scrR rAcc ≤ H3a.rRead md scrR (rInO + (d : ℤ))) = true at hle
          rw [hacc_c, hs_c, decide_eq_true_eq] at hle; exact hle
        have hmax : s - ‖o‖ ^ 2 = max 0 (liftVariance o s) := by
          unfold liftVariance; exact (max_eq_right (by linarith)).symm
        refine ExecDet.rWrite inp tblR _ _ (nodeVarROff d nodeBaseR) (max 0 (liftVariance o s))
          hfpc htblR (by unfold nodeVarROff; omega) (by unfold nodeVarROff; omega)
          (by change H3a.wRead md scrW wNodeBaseR + ((d : ℤ) + 1) = _; rw [hbR_c]; unfold nodeVarROff; ring)
          (by change H3a.rRead md scrR (rInO + (d : ℤ)) - H3a.rRead md scrR rAcc = _
              rw [hs_c, hacc_c, hmax])
          (by dsimp [intExprOps, realExprOps]; omega) ?_
        refine ⟨fun c => ?_, ?_, rRead_rWrite_self _ _ _ _,
          fun w hw => by rw [wRead_rWrite, wRead_rWrite]; exact hw_b w hw, ?_⟩
        · have := c.isLt
          rw [rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeCenterROff nodeVarROff; omega)),
              rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeCenterROff nodeHeightROff; omega))]
          exact ho_b c c.isLt
        · rw [rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeHeightROff nodeVarROff; omega)),
              rRead_rWrite_self]
        · refine ⟨fun t i hts _ => by rw [wRead_rWrite, wRead_rWrite]; exact hfr_b.1 t i hts (Or.inr (by omega)),
                  fun t i hts hout => ?_⟩
          rcases hout with ht | hlt | hge
          · rw [rRead_rWrite_of_ne _ _ (Or.inl ht), rRead_rWrite_of_ne _ _ (Or.inl ht)]
            exact hfr_b.2 t i hts (Or.inl ht)
          · rw [rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeVarROff; omega)),
                rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeHeightROff; omega))]
            exact hfr_b.2 t i hts (Or.inr (Or.inl hlt))
          · rw [rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeVarROff; omega)),
                rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeHeightROff; omega))]
            exact hfr_b.2 t i hts (Or.inr (Or.inr hge))
      · have hgt_r : s < ‖o‖ ^ 2 := by
          simp only [evalArithCond, evalRealExpr, evalIntExpr] at hgt
          change decide (H3a.rRead md scrR rAcc ≤ H3a.rRead md scrR (rInO + (d : ℤ))) = false at hgt
          rw [hacc_c, hs_c, decide_eq_false_iff_not, not_le] at hgt; exact hgt
        have hmax : (0 : ℝ) = max 0 (liftVariance o s) := by
          unfold liftVariance; exact (max_eq_left (by linarith)).symm
        refine ExecDet.rWrite inp tblR _ _ (nodeVarROff d nodeBaseR) (max 0 (liftVariance o s))
          hfpc htblR (by unfold nodeVarROff; omega) (by unfold nodeVarROff; omega)
          (by change H3a.wRead md scrW wNodeBaseR + ((d : ℤ) + 1) = _; rw [hbR_c]; unfold nodeVarROff; ring)
          (by simp only [evalRealExpr, evalIntExpr, Int.cast_zero]; exact hmax)
          (by dsimp [intExprOps, realExprOps]; omega) ?_
        refine ⟨fun c => ?_, ?_, rRead_rWrite_self _ _ _ _,
          fun w hw => by rw [wRead_rWrite, wRead_rWrite]; exact hw_b w hw, ?_⟩
        · have := c.isLt
          rw [rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeCenterROff nodeVarROff; omega)),
              rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeCenterROff nodeHeightROff; omega))]
          exact ho_b c c.isLt
        · rw [rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeHeightROff nodeVarROff; omega)),
              rRead_rWrite_self]
        · refine ⟨fun t i hts _ => by rw [wRead_rWrite, wRead_rWrite]; exact hfr_b.1 t i hts (Or.inr (by omega)),
                  fun t i hts hout => ?_⟩
          rcases hout with ht | hlt | hge
          · rw [rRead_rWrite_of_ne _ _ (Or.inl ht), rRead_rWrite_of_ne _ _ (Or.inl ht)]
            exact hfr_b.2 t i hts (Or.inl ht)
          · rw [rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeVarROff; omega)),
                rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeHeightROff; omega))]
            exact hfr_b.2 t i hts (Or.inr (Or.inl hlt))
          · rw [rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeVarROff; omega)),
                rRead_rWrite_of_ne _ _ (Or.inr (by unfold nodeHeightROff; omega))]
            exact hfr_b.2 t i hts (Or.inr (Or.inr hge))
  obtain ⟨m₁, ⟨ho₁, hs₁, hV₁, hw₁, hfr₁⟩, hfp₁, hde⟩ :=
    execDet_to_detExec (hzr_openNodeWriteCenterVarStmt _ _ _ _ _ _ _ _) hfp₀ hdet
  exact ⟨m₁, hde, hfp₁, ho₁, hs₁, hV₁, hw₁, hfr₁⟩


/-! ### 4b. `O(1)` Stage-4 Accessors: `managedNodeReadMaxRadiusStmt` & `managedNodeReadCfgEdgeStmt` -/

theorem radTreeExactWF_effVal_root {d : ℕ} {K_seg n T_pow : ℕ}
    (hn_T : n ≤ T_pow) (hn_K : n ≤ 2 ^ K_seg)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)}
    {S : Finset ℕ} (hS : ∀ x ∈ S, x < n) {T : EpochRadTree}
    (hwf : RadTreeExactWF K_seg pts o S T) :
    T.effVal 1 = (maxRadiusHandle T_pow pts o S).map (fun y => (y, ‖pts y - o‖ ^ 2)) := by
  have hroot := hwf.2.2 K_seg le_rfl 0 (by simp)
  simp only [Nat.sub_self, Nat.pow_zero, Nat.add_zero] at hroot
  rw [hroot, expectedRadAt_eq_foldRadRange, Nat.zero_mul]
  have hfold_eq : foldRadRange pts o S 0 (2 ^ K_seg) = maxRadiusHandle (2 ^ K_seg) pts o S := by
    classical
    unfold foldRadRange maxRadiusHandle
    simp only [Nat.zero_add]
  rw [hfold_eq, maxRadiusHandle_eq_of_ge pts o hS hn_K, maxRadiusHandle_eq_of_ge pts o hS hn_T]
  rfl

/-- `O(1)` root query of `EpochRadTree` inside `EncManagedNode`, yielding the exact
`maxRadiusHandle T_pow pts mn.nd.o mn.nd.denseArr.toFinset` without scanning `denseArr`. -/
def managedNodeReadMaxRadiusStmt (scrW scrR tblW tblR : ℕ)
    (wNodeBaseW wNodeBaseR wOutHas wOutUid rOutSq wScr : ℤ)
    (n cap_hist d : ℕ) : ArithRAMStmt :=
  let radWOff : ℤ := 8 + 2 * swapPoolStride n + (1 + (cap_hist : ℤ))
  let radROff : ℤ := (d : ℤ) + 2
  .seq (.writeWordHeap scrW (.lit wScr)
          (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit radWOff)))
  (.seq (.writeWordHeap scrW (.lit (wScr + 1))
          (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit radROff)))
        (radTreeQueryRootStmt scrW scrR tblW tblR
          wScr (wScr + 1) (wScr + 2) wOutHas wOutUid rOutSq))

theorem zeroRand_managedNodeReadMaxRadiusStmt (scrW scrR tblW tblR : ℕ)
    (wNodeBaseW wNodeBaseR wOutHas wOutUid rOutSq wScr : ℤ)
    (n cap_hist d : ℕ) :
    ZeroRandStmt (managedNodeReadMaxRadiusStmt scrW scrR tblW tblR
      wNodeBaseW wNodeBaseR wOutHas wOutUid rOutSq wScr n cap_hist d) :=
  hzr_to_zeroRand (.seq (.writeWordHeap _ _ _)
    (.seq (.writeWordHeap _ _ _) (hzr_radTreeQueryRootStmt _ _ _ _ _ _ _ _ _ _)))

theorem exec_managedNodeReadMaxRadiusStmt
    {d TW BW TR BR n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg T_pow : ℕ)
    (hn_T : n ≤ T_pow) (hn_K : n ≤ 2 ^ K_seg)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wNodeBaseW wNodeBaseR wOutHas wOutUid rOutSq wScr nodeBaseW nodeBaseR : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg} {bp : Option (ℕ × ℕ)}
    (hS_lt : ∀ x ∈ mn.nd.curSet, x < n)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbls : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hwBW : 0 ≤ wNodeBaseW ∧ wNodeBaseW < wScr)
    (hwBR : 0 ≤ wNodeBaseR ∧ wNodeBaseR < wScr)
    (hwHas : 0 ≤ wOutHas ∧ wOutHas < wScr)
    (hwUid : 0 ≤ wOutUid ∧ wOutUid < wScr)
    (hneHasUid : wOutHas ≠ wOutUid)
    (hrSq : 0 ≤ rOutSq ∧ rOutSq < (BR : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + 3 ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wNodeBaseW = nodeBaseW)
    (hbR : H3a.wRead m₀ scrW wNodeBaseR = nodeBaseR)
    (henc : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (managedNodeReadMaxRadiusStmt scrW scrR tblW tblR
        wNodeBaseW wNodeBaseR wOutHas wOutUid rOutSq wScr n cap_hist d) m₀ m₁ 135 ∧
      InFootprint TW BW TR BR m₁ ∧
      (match maxRadiusHandle T_pow pts mn.nd.o mn.nd.denseArr.toFinset with
       | none =>
           H3a.wRead m₁ scrW wOutHas = 0 ∧
           H3a.wRead m₁ scrW wOutUid = 0 ∧
           H3a.rRead m₁ scrR rOutSq = 0
       | some y =>
           H3a.wRead m₁ scrW wOutHas = 1 ∧
           H3a.wRead m₁ scrW wOutUid = (y : ℤ) ∧
           H3a.rRead m₁ scrR rOutSq = ‖pts y - mn.nd.o‖ ^ 2) ∧
      EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₁ ∧
      (∀ w, w < wScr → w ≠ wOutHas → w ≠ wOutUid → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      (∀ r, r ≠ rOutSq → H3a.rRead m₁ scrR r = H3a.rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW 0 0 tblR 0 0 m₀ m₁ := by
  have hneW := htbls.2.2.2.2.2.2.1
  have hneR := htbls.2.2.2.2.2.2.2.2.2.1
  let radWOff : ℤ := 8 + 2 * swapPoolStride n + (1 + (cap_hist : ℤ))
  let radROff : ℤ := (d : ℤ) + 2
  let rBW := nodeRadTreeWOff n cap_hist nodeBaseW
  let rBR := nodeRadTreeROff d nodeBaseR
  have hrBW_eq : nodeBaseW + radWOff = rBW := by
    dsimp [rBW, radWOff]; unfold nodeRadTreeWOff nodeHistOff; ring
  have hrBR_eq : nodeBaseR + radROff = rBR := by
    dsimp [rBR, radROff]; unfold nodeRadTreeROff; ring
  let m1 := H3a.wWrite m₀ scrW wScr rBW
  let m2 := H3a.wWrite m1 scrW (wScr + 1) rBR
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit radWOff))) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW _ _ rfl
      (by change H3a.wRead m₀ scrW wNodeBaseW + radWOff = rBW; rw [hbW, hrBW_eq])
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ htbls.1 hwScr.1 (by omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 1)) (.add (.readHeap scrW (.lit wNodeBaseR)) (.lit radROff))) m1 m2 20 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW _ _ rfl
      (by change H3a.wRead m1 scrW wNodeBaseR + radROff = rBR
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), hbR, hrBR_eq])
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp2 : InFootprint TW BW TR BR m2 := InFootprint.wWrite hfp1 htbls.1 (by omega) (by omega)
  rcases henc with ⟨hb_e, ha_e, hbp_e, ho_e, hs_e, hV_e, hh_le, hh_len, hh_el,
    hPd_e, hPr_e, ⟨Tr, hTr_wf, hTr_enc0⟩, hcfgs_e⟩
  have hfr02 : RadFrameOutside scrW scrR tblW rBW 0 tblR rBR 0 m₀ m2 :=
    ⟨fun t i hts _ => by dsimp [m2, m1]; rw [wRead_wWrite_of_ne _ _ (Or.inl hts), wRead_wWrite_of_ne _ _ (Or.inl hts)],
     fun _ _ _ _ => rfl⟩
  have hTr_enc2 : EncEpochRadTree tblW rBW tblR rBR K_seg Tr m2 :=
    hTr_enc0.mono_frame hfr02 hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))
  obtain ⟨m3, hd3, hfp3, hres3, hw3, hr3, hfr23⟩ :=
    exec_radTreeQueryRootStmt inp wScr (wScr + 1) (wScr + 2) wOutHas wOutUid rOutSq rBW rBR K_seg Tr
      hfp2 htbls.1 htbls.2.2.2.1 hneW hneR
      ⟨by omega, by omega⟩ ⟨hwHas.1, by omega⟩ ⟨hwUid.1, by omega⟩ hrSq
      hneHasUid ⟨by omega, by omega, by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by dsimp [m2, m1]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_self])
      (wRead_wWrite_self _ _ _ _) hTr_enc2
  have heff1 := radTreeExactWF_effVal_root hn_T hn_K hS_lt hTr_wf
  have hcur_eq : mn.nd.curSet = mn.nd.denseArr.toFinset := rfl
  rw [hcur_eq] at heff1
  rw [heff1] at hres3
  have hfr_tot : RadFrameOutside scrW scrR tblW 0 0 tblR 0 0 m₀ m3 :=
    (RadFrameOutside_mono_range hfr02 (Or.inl rfl) (Or.inl rfl)).trans (RadFrameOutside_mono_range hfr23 (Or.inl rfl) (Or.inl rfl))
  have henc_full0 : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₀ :=
    ⟨hb_e, ha_e, hbp_e, ho_e, hs_e, hV_e, hh_le, hh_len, hh_el,
      hPd_e, hPr_e, ⟨Tr, hTr_wf, hTr_enc0⟩, hcfgs_e⟩
  have henc_full3 : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m3 :=
    EncManagedNode.mono_slice henc_full0
      (fun j _ _ => hfr_tot.1 tblW j hneW (Or.inr (by omega)))
      (fun j _ _ => hfr_tot.2 tblR j hneR (Or.inr (by omega)))
      (fun _ _ _ _ => hfr_tot.2 1 _ htbls.2.2.2.2.2.2.2.2.2.2.1 (Or.inl htbls.2.2.2.2.2.2.2.2.2.2.2))
  refine ⟨m3, (DetExecAt.seq hd1 (DetExecAt.seq hd2 hd3)).mono_cost (by omega), hfp3,
    ?_, henc_full3, ?_, hr3, hfr_tot⟩
  · cases hm : maxRadiusHandle T_pow pts mn.nd.o mn.nd.denseArr.toFinset
    · rw [hm] at hres3; exact hres3
    · rw [hm] at hres3; exact hres3
  · intro w hwlt hneH hneU
    rw [hw3 w (by omega) hneH hneU]
    dsimp [m2, m1]
    rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)), wRead_wWrite_of_ne _ _ (Or.inr (by omega))]

/-- `O(1)` Stage-4 reader of `(mn.nd.cfgs i).st.storedEdge` via `ops.readEdgeStmt`. -/
def managedNodeReadCfgEdgeStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (i : Fin N_cfg)
    (wNodeBaseW wOutHas wOutU wOutV wScr : ℤ) : ArithRAMStmt :=
  let cfgsWOffVal : ℤ := 8 + 2 * swapPoolStride n + (1 + (cap_hist : ℤ)) + radTreeWStride K_seg
  .seq (.writeWordHeap scrW (.lit wScr)
          (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride))))
        (ops.readEdgeStmt (specs i) wScr wOutHas wOutU wOutV (wScr + 1))

theorem zeroRand_managedNodeReadCfgEdgeStmt
    {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (i : Fin N_cfg)
    (wNodeBaseW wOutHas wOutU wOutV wScr : ℤ) :
    ZeroRandStmt (managedNodeReadCfgEdgeStmt ops specs cap_hist K_seg i
      wNodeBaseW wOutHas wOutU wOutV wScr) :=
  .seq (.writeWordHeap _ _ _) (ops.zeroRand_readEdgeStmt _ _ _ _ _ _)

theorem exec_managedNodeReadCfgEdgeStmt
    {d TW BW TR BR n L_p2 R ℓ M₀ b T_cdf p_coord M_lat N_cfg : ℕ}
    {params : LocalScaleParams} {h : ℝ} {τ_d τ_q : ℚ} {cap_u cap_q : ℕ}
    {scrW scrR tblW tblR coinTbl : ℕ}
    (ops : ConfigMatchRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat params h τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (specs : Fin N_cfg → ConfigStaticSpec d params h)
    (cap_hist K_seg : ℕ) (i : Fin N_cfg)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wNodeBaseW wOutHas wOutU wOutV wScr nodeBaseW nodeBaseR : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {mn : ManagedNode L_p2 R ℓ M₀ d b N_cfg} {bp : Option (ℕ × ℕ)}
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (htbls : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ nodeBaseW ∧
      nodeBaseW + managedNodeWStride n cap_hist K_seg N_cfg ops.cfgWStride ≤ (BW : ℤ))
    (hwBW : 0 ≤ wNodeBaseW ∧ wNodeBaseW < wScr)
    (hwHas : 0 ≤ wOutHas ∧ wOutHas < wScr)
    (hwU : 0 ≤ wOutU ∧ wOutU < wScr)
    (hwV : 0 ≤ wOutV ∧ wOutV < wScr)
    (hneOut : wOutHas ≠ wOutU ∧ wOutHas ≠ wOutV ∧ wOutU ≠ wOutV)
    (hwScr : 0 ≤ wScr ∧ wScr + 1 + ops.opWScrStride ≤ (BW : ℤ))
    (hbW : H3a.wRead m₀ scrW wNodeBaseW = nodeBaseW)
    (henc : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (managedNodeReadCfgEdgeStmt ops specs cap_hist K_seg i
        wNodeBaseW wOutHas wOutU wOutV wScr) m₀ m₁ (ops.readEdgeCost + 25) ∧
      InFootprint TW BW TR BR m₁ ∧
      (match (mn.nd.cfgs i).st.storedEdge with
       | none => H3a.wRead m₁ scrW wOutHas = 0
       | some (u, v) =>
           H3a.wRead m₁ scrW wOutHas = 1 ∧
           H3a.wRead m₁ scrW wOutU = (u : ℤ) ∧
           H3a.wRead m₁ scrW wOutV = (v : ℤ)) ∧
      EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m₁ ∧
      (∀ w, w < wScr → w ≠ wOutHas → w ≠ wOutU → w ≠ wOutV →
        H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW 0 0 tblR 0 0 m₀ m₁ := by
  have hcfgW := ops.hcfgW_nonneg
  have hrad4 := radTreeWStride_ge_four K_seg
  have hneW := htbls.2.2.2.2.2.2.1
  have hneR := htbls.2.2.2.2.2.2.2.2.2.1
  let cBW := nodeCfgWOff n cap_hist K_seg ops.cfgWStride nodeBaseW i.val
  let cBR := nodeCfgROff d K_seg ops.cfgRStride nodeBaseR i.val
  let cfgsWOffVal : ℤ := 8 + 2 * swapPoolStride n + (1 + (cap_hist : ℤ)) + radTreeWStride K_seg
  have hcBW_eq : nodeBaseW + (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride) = cBW := by
    dsimp [cBW, cfgsWOffVal]; unfold nodeCfgWOff nodeCfgsWBase nodeRadTreeWOff nodeHistOff; ring
  let m1 := H3a.wWrite m₀ scrW wScr cBW
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit wScr) (.add (.readHeap scrW (.lit wNodeBaseW)) (.lit (cfgsWOffVal + (i.val : ℤ) * ops.cfgWStride)))) m₀ m1 25 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW _ _ rfl
      (by change H3a.wRead m₀ scrW wNodeBaseW + _ = cBW; rw [hbW, hcBW_eq])
      (by dsimp [H3a.intExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
  have hfp1 : InFootprint TW BW TR BR m1 := InFootprint.wWrite hfp₀ htbls.1 hwScr.1 (by have := ops.hopWScr_pos; omega)
  have hbndW := nodeCfgWOff_bounds n cap_hist K_seg hcfgW nodeBaseW i
  have hloW : nodeBaseW ≤ nodeCfgsWBase n cap_hist K_seg nodeBaseW := by
    unfold nodeCfgsWBase nodeRadTreeWOff nodeHistOff swapPoolStride; omega
  have henc_cfg1 : ops.EncCfg (specs i) cBW cBR pts mn.nd.o mn.nd.V (nodeCfgSet mn.nd) (mn.nd.cfgs i) m1 :=
    ops.encCfg_mono_slice (specs i) cBW cBR pts mn.nd.o mn.nd.V (nodeCfgSet mn.nd) (mn.nd.cfgs i) m₀ m1
      (henc.2.2.2.2.2.2.2.2.2.2.2.2 i)
      (fun _ _ _ => wRead_wWrite_of_ne _ _ (Or.inl hneW))
      (fun _ _ _ => rfl)
      (fun _ _ _ _ => rfl)
  obtain ⟨m2, hd2, hfp2, hres2, hw2, hfr2⟩ :=
    ops.exec_readEdgeStmt inp (specs i) wScr wOutHas wOutU wOutV (wScr + 1) cBW cBR
      hfp1 htbls ⟨by dsimp [cBW]; omega, by dsimp [cBW]; omega⟩
      ⟨hwScr.1, by omega⟩ ⟨hwHas.1, by omega⟩ ⟨hwU.1, by omega⟩ ⟨hwV.1, by omega⟩
      ⟨hneOut.1, hneOut.2.1, hneOut.2.2, by omega, by omega, by omega⟩
      ⟨by omega, by omega⟩ (wRead_wWrite_self _ _ _ _) henc_cfg1
  have hfr_tot : RadFrameOutside scrW scrR tblW 0 0 tblR 0 0 m₀ m2 :=
    ⟨fun t j hts _ => (hfr2.1 t j hts (Or.inr (by omega))).trans
      (wRead_wWrite_of_ne _ _ (Or.inl hts)),
     fun t j hts _ => hfr2.2 t j hts (Or.inr (by omega))⟩
  have henc2 : EncManagedNode ops specs cap_hist K_seg nodeBaseW nodeBaseR pts mn bp m2 :=
    EncManagedNode.mono_slice henc
      (fun j _ _ => hfr_tot.1 tblW j hneW (Or.inr (by omega)))
      (fun j _ _ => hfr_tot.2 tblR j hneR (Or.inr (by omega)))
      (fun _ _ _ _ => hfr_tot.2 1 _ htbls.2.2.2.2.2.2.2.2.2.2.1 (Or.inl htbls.2.2.2.2.2.2.2.2.2.2.2))
  refine ⟨m2, (DetExecAt.seq hd1 hd2).mono_cost (by omega), hfp2, hres2, henc2, ?_, hfr_tot⟩
  intro w hwlt h1 h2 h3
  rw [hw2 w (by omega) h1 h2 h3]
  exact wRead_wWrite_of_ne _ _ (Or.inr (by omega))

end UL.Proof.clm_9_1_explicit_tradeoff.CG18
