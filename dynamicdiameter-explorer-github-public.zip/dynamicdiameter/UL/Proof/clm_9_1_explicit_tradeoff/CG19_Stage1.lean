import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Stage1D
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

/-! ### 7. Top-Level Stage-1 Statement & Spec (`stepStage1Stmt`, `exec_stepStage1Stmt`) -/

def servingStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 11) (.lit 16))
  (.seq (.writeWordHeap engScrTbl (.lit 12) (.readHeap engMetaTbl (.lit 0)))
  (.seq (.writeWordHeap engScrTbl (.lit 13) (.lit 0))
        (liveUpdateListStmt ops)))

theorem zeroRand_servingStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (servingStage1Stmt ops) :=
  .seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
        (zeroRand_liveUpdateListStmt ops)))

def jobBodyStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 21)
          (.add (.lit (16 + (cp.D_max : ℤ)))
                (.mul (.readHeap engScrTbl (.lit 20)) (.lit 8))))
  (.seq (jobSlotUpdateStage1Stmt ops)
        (passPrefixStepStmt ops))

theorem zeroRand_jobBodyStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (jobBodyStage1Stmt ops) :=
  .seq (.writeWordHeap _ _ _)
  (.seq (zeroRand_jobSlotUpdateStage1Stmt ops)
        (zeroRand_passPrefixStepStmt ops))

def jobsLoopStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 22) (.readHeap engMetaTbl (.lit 0)))
  (.seq (.writeWordHeap engScrTbl (.lit 23) (.lit 1))
        (forLoopStmt engScrTbl 20 cp.D_max (jobBodyStage1Stmt ops)))

theorem zeroRand_jobsLoopStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (jobsLoopStage1Stmt ops) :=
  .seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
        (zeroRand_forLoopStmt (zeroRand_jobBodyStage1Stmt ops)))

def stepStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (stepHandleAndSetupStmt d)
  (.seq (servingStage1Stmt ops)
  (.seq (leafLiveUpdateStmt cp)
        (jobsLoopStage1Stmt ops)))

theorem zeroRand_stepStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (stepStage1Stmt ops) :=
  .seq (zeroRand_stepHandleAndSetupStmt d)
  (.seq (zeroRand_servingStage1Stmt ops)
  (.seq (zeroRand_leafLiveUpdateStmt cp)
        (zeroRand_jobsLoopStage1Stmt ops)))

def C_stage1 {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  (280 + 25 * d) + (C_liveList ops + 54) + 340 +
    (34 + (1 + cp.D_max * ((C_jobSlotUpdateStage1 ops + (ops.C_ball + 50) + 18) + 6)))

private theorem stepStage1_top_fields {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp)
    (uop : InternalUpdate d) (ω₁ : Stage1Coins cp) :
    let hp' := (st.hp.step uop).1
    let rh := (st.hp.step uop).2
    let pts' := hp'.coords
    let isIns : Bool := match uop with | .insert _ => true | .delete _ => false
    let h_op : ℕ := match uop with | .insert _ => rh.getD 0 | .delete delH => delH
    let servRes := liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) 0 st.serving
    let leafArr₁ :=
      if servRes.2 && !st.leafOverflow then
        if isIns then denseInsert h_op st.leafArr else denseDelete h_op st.leafArr
      else st.leafArr
    (stepStage1 cp st uop ω₁).1.hp = hp' ∧
    (stepStage1 cp st uop ω₁).1.cachedAns = st.cachedAns ∧
    (stepStage1 cp st uop ω₁).1.leafOverflow = st.leafOverflow ∧
    (stepStage1 cp st uop ω₁).1.serving = servRes.1 ∧
    (stepStage1 cp st uop ω₁).1.leafArr = leafArr₁ ∧
    (stepStage1 cp st uop ω₁).2 = rh := by
  unfold stepStage1
  cases st.hp.step uop with
  | mk hp' rh =>
    cases uop <;> dsimp only <;> exact ⟨rfl, rfl, rfl, rfl, rfl, rfl⟩

theorem exec_stepStage1Stmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    {P : DynamicPointSet d} {op : DynamicUpdate d}
    {st : ChainEngineState cp} {bits : Fin cp.B_STEP → Bool}
    {m₀ : ArithRAMMemory}
    (hP : P.WellFormed cp.n)
    (hleg : IsLegalUpdate cp.n Set.univ P op)
    (hwf : ChainEngineWF cp P st)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (henc₀ : EncChainEngine ops st m₀)
    (hcoins₀ : MemHasStepCoins cp bits m₀) :
    let uop := toInternalUpdate P op
    let inp := CG20_Bridge.mkUpdateInp cp.n P uop
    let ω₁ := (bitsToStepCoinBundle cp bits).1
    let res := stepStage1 cp st uop ω₁
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (stepStage1Stmt ops) m₀
      (fun m₁ =>
        EncChainEngine ops res.1 m₁ ∧
        MemHasStepCoins cp bits m₁ ∧
        (∀ h_new, res.2 = some h_new →
          ArithRAMDynamicProgram.readReturnedHandle m₁ = some h_new))
      (C_stage1 ops) := by
  have hTW := ops.hTW
  have hBW_s := ops_hBW_scr64 ops
  have hBW_m := ops.hBW_meta
  have hBW_a := ops.hBW_arr
  have hS_gt : cp.n < S_stride cp := by unfold S_stride; omega
  let uop := toInternalUpdate P op
  let inp := CG20_Bridge.mkUpdateInp cp.n P uop
  let ω₁ := (bitsToStepCoinBundle cp bits).1
  let res := stepStage1 cp st uop ω₁
  let hp' := (st.hp.step uop).1
  let rh := (st.hp.step uop).2
  let pts' := hp'.coords
  let isIns : Bool := match uop with | .insert _ => true | .delete _ => false
  let h_op : ℕ := match uop with | .insert _ => rh.getD 0 | .delete delH => delH
  let servRes := liveUpdateChainList cp pts' isIns h_op (getS1Seed cp ω₁) 0 st.serving
  let leafArr₁ :=
    if servRes.2 && !st.leafOverflow then
      if isIns then denseInsert h_op st.leafArr else denseDelete h_op st.leafArr
    else
      st.leafArr
  have hres_fields :
      res.1.hp = hp' ∧
      res.1.cachedAns = st.cachedAns ∧
      res.1.leafOverflow = st.leafOverflow ∧
      res.1.serving = servRes.1 ∧
      res.1.leafArr = leafArr₁ ∧
      res.2 = rh := stepStage1_top_fields cp st uop ω₁
  -- Unpack EncChainEngine and slot disjointness
  rcases henc₀ with ⟨hsr₀, hhp₀, hans₀, hov₀, hleaf_le₀, hleaf_sp₀, hserv_le₀, hserv_len₀,
    servSlots, readySlots, curSlots, hslen₀, hserv_enc₀, hjobs_enc₀, hall_nd, hall_lt⟩
  let jSlots : Fin cp.D_max → List ℕ := fun r => jobUsedSlots (st.jobs r) (readySlots r) (curSlots r)
  have hall_nd' : (servSlots ++ (List.finRange cp.D_max).flatMap jSlots).Nodup := hall_nd
  rcases List.nodup_append.mp hall_nd' with ⟨hserv_nd, hflat_nd, hdisj_raw⟩
  rcases nodup_flatMap_disjoint (List.nodup_finRange cp.D_max) hflat_nd with ⟨hj_nd_mem, hj_disj_mem⟩
  have hserv_lt : ∀ s ∈ servSlots, s < M_slots cp :=
    fun s hs => hall_lt s (List.mem_append_left _ hs)
  have hj_lt : ∀ (r : Fin cp.D_max), ∀ s ∈ jSlots r, s < M_slots cp :=
    fun r s hs => hall_lt s (List.mem_append_right _ (List.mem_flatMap.mpr ⟨r, List.mem_finRange r, hs⟩))
  have hdisj_sj : ∀ (r : Fin cp.D_max), ∀ s ∈ jSlots r, s ∉ servSlots :=
    fun r s hs hss => hdisj_raw s hss s (List.mem_flatMap.mpr ⟨r, List.mem_finRange r, hs⟩) rfl
  have hj_nd : ∀ r : Fin cp.D_max, (jSlots r).Nodup :=
    fun r => hj_nd_mem r (List.mem_finRange r)
  have hj_disj : ∀ (r₁ r₂ : Fin cp.D_max), r₁ ≠ r₂ → ∀ s ∈ jSlots r₁, s ∉ jSlots r₂ :=
    fun r₁ r₂ hne => hj_disj_mem r₁ (List.mem_finRange r₁) r₂ (List.mem_finRange r₂) hne
  have hserv_age := serving_age_le_birthSize hwf
  have hact_lt : ∀ x ∈ P.activeHandles, x < cp.n := by
    intro x hx
    have hmem : x ∈ st.hp.actList := List.mem_toFinset.mp (hwf.1.2.2.2.1.symm ▸ hx)
    exact lt_of_lt_of_le (hwf.1.2.2.2.2.1 x hmem) hwf.1.1
  let C_body := C_jobSlotUpdateStage1 ops + (ops.C_ball + 50) + 18
  let C_loop := 34 + (1 + cp.D_max * (C_body + 6))
  unfold stepStage1Stmt C_stage1
  -- Step 1: stepHandleAndSetupStmt
  refine ExecDet.seq' ((C_liveList ops + 54) + 340 + C_loop)
    (exec_stepHandleAndSetupStmt ops hP hleg hwf.1 hfp₀ hsr₀ hhp₀ hans₀)
    (by dsimp [C_loop, C_body]; omega) ?_
  intro m₁ ⟨P', _, _, hsr₁, hhp₁, hans₁, hr1_1, hr2_1, hhop_lt,
    hins_case, hdel_case, hpts_all, hret₁, hnd_01, hw_ge5_1, hr_ge2_1⟩ hfp₁
  have hpts_mem₁ : ∀ x ∈ insert h_op P.activeHandles, ∀ c : Fin d,
      rRead m₁ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts' x) c :=
    fun x hx c => (hpts_all x hx).2 c
  have hcoins₁ : MemHasStepCoins cp bits m₁ :=
    fun j => (hw_ge5_1 coinTbl (by dsimp [coinTbl]; omega) (by decide) _).trans (hcoins₀ j)
  have hserv_enc₁ : ∀ q (hq : q < st.serving.length) (hqs : q < servSlots.length),
      wRead m₁ engMetaTbl (16 + (q : ℤ)) = (servSlots[q]'hqs : ℤ) ∧
      ops.EncNode (st.serving[q]'hq) (servSlots[q]'hqs) m₁ := by
    intro q hq hqs
    rcases (chainListInv_getElem P.activeHandles st.serving (Finset.Subset.refl _) hwf.2.2.2.1).2 q hq
      with ⟨hSq_sub, hln_q⟩
    have hoff_eq : (16 + (q : ℤ)) = servSlotOff q := rfl
    rw [hoff_eq]
    exact ⟨(hw_ge5_1 engMetaTbl (by decide) (by decide) _).trans (hserv_enc₀ q hq hqs).1,
      hnd_01 _ _ (hln_q.1 ▸ hSq_sub) (hserv_enc₀ q hq hqs).2⟩
  have hjobs_enc₁ : ∀ r : Fin cp.D_max, EncJobSlot ops r (st.jobs r) (readySlots r) (curSlots r) m₁ :=
    fun r => encJobSlot_after_handleStep hwf (hjobs_enc₀ r)
      (hw_ge5_1 engMetaTbl (by decide) (by decide))
      (hw_ge5_1 engArrTbl (by decide) (by decide))
      hnd_01
  -- Step 2: servingStage1Stmt
  have hserv_stmt : ExecDet ops.TW ops.BW ops.TR ops.BR inp (servingStage1Stmt ops) m₁
      (fun m₂ =>
        ops.SlotsReady m₂ ∧
        servRes.1.length = st.serving.length ∧
        (∀ q (hq : q < servRes.1.length) (hqs : q < servSlots.length),
          ops.EncNode (servRes.1[q]'hq) (servSlots[q]'hqs) m₂) ∧
        wRead m₂ engScrTbl 14 = (if servRes.2 then 1 else 0) ∧
        (∀ mn' s', s' < M_slots cp → s' ∉ servSlots → ops.EncNode mn' s' m₁ → ops.EncNode mn' s' m₂) ∧
        (∀ t < 9, t ≠ engScrTbl → ∀ i, wRead m₂ t i = wRead m₁ t i) ∧
        (∀ i, i < 10 → wRead m₂ engScrTbl i = wRead m₁ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₂ t i = rRead m₁ t i))
      (C_liveList ops + 54) := by
    unfold servingStage1Stmt
    refine ExecDet.seq' (C_liveList ops + 36)
      (ExecDet.wWrite (C := 18) inp engScrTbl (.lit 11) (.lit 16) 11 16
        hfp₁ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
      (by omega) ?_
    intro mS₁ hmS₁ hfpS₁; subst hmS₁
    refine ExecDet.seq' (C_liveList ops + 18)
      (ExecDet.wWrite (C := 18) inp engScrTbl (.lit 12) (.readHeap engMetaTbl (.lit 0))
        12 (st.serving.length : ℤ) hfpS₁ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
        (by simp only [evalIntExpr]
            change wRead _ engMetaTbl 0 = _
            rw [wRead_wWrite_of_ne m₁ _ (Or.inl (by decide)),
                hw_ge5_1 engMetaTbl (by decide) (by decide) 0, hserv_len₀])
        (by simp [intExprOps]) rfl)
      (by omega) ?_
    intro mS₂ hmS₂ hfpS₂; subst hmS₂
    refine ExecDet.seq' (C_liveList ops)
      (ExecDet.wWrite (C := 18) inp engScrTbl (.lit 13) (.lit 0) 13 0
        hfpS₂ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl rfl (by simp [intExprOps]) rfl)
      (by omega) ?_
    intro mS₃ hmS₃ hfpS₃; subst hmS₃
    set mS := H3a.wWrite (H3a.wWrite (H3a.wWrite m₁ engScrTbl 11 16)
      engScrTbl 12 (st.serving.length : ℤ)) engScrTbl 13 0
    have hwS_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead mS t i = wRead m₁ t i := by
      intro t ht i; simp only [mS]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
    have hwS_lt10 : ∀ i, i < 10 → wRead mS engScrTbl i = wRead m₁ engScrTbl i := by
      intro i hi; simp only [mS]
      rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
          wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
    have hrS : ∀ t i, rRead mS t i = rRead m₁ t i := fun _ _ => by simp [mS, rRead_wWrite]
    have hndS : ∀ mn' s', ops.EncNode mn' s' m₁ → ops.EncNode mn' s' mS :=
      fun mn' s' he => ops.encNode_ext mn' s' m₁ mS he
        (fun t ht9 _ i => hwS_ne8 t (by dsimp [engScrTbl]; omega) i)
        (fun _ _ _ _ => hrS _ _) (fun _ _ _ _ => hrS ptsRTbl _)
    refine (exec_liveUpdateListStmt (metaSlotsOff := 16) (baseIdx := 0) ops inp
      hserv_le₀ hslen₀ hserv_nd hserv_lt
      (by omega) (by omega) (by dsimp [ChainParams.N_op_s1]; omega)
      hhop_lt (Finset.Subset.refl _) hact_lt hserv_age hwf.2.2.2.1 hins_case hdel_case
      (fun x hx c => (hrS _ _).trans (hpts_mem₁ x hx c))
      (fun j => (hwS_ne8 coinTbl (by decide) _).trans (hcoins₁ j))
      hfpS₃
      (ops.slotsReady_ext m₁ mS hsr₁
        (fun t ht9 _ i => hwS_ne8 t (by dsimp [engScrTbl]; omega) i)
        (fun _ _ _ _ => hrS _ _))
      (fun q hq hqs => ⟨(hwS_ne8 engMetaTbl (by decide) _).trans (hserv_enc₁ q hq hqs).1,
        hndS _ _ (hserv_enc₁ q hq hqs).2⟩)
      ((hwS_lt10 1 (by omega)).trans hr1_1)
      ((hwS_lt10 2 (by omega)).trans hr2_1)
      (by simp only [mS]
          rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
              wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
      (by simp only [mS]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
      (by simp only [mS, Nat.zero_mul, Nat.cast_zero]; exact wRead_wWrite_self _ _ _ _)).mono ?_ le_rfl
    intro m₂ ⟨hsr₂, hlen₂, henc₂, hr14_2, hnd₂_out, hw₂_t, hw₂_scr, hr₂⟩ _
    exact ⟨hsr₂, hlen₂, henc₂, hr14_2,
      fun mn' s' hs' hns he1 => hnd₂_out mn' s' hs' hns (hndS mn' s' he1),
      fun t ht9 ht8 i => (hw₂_t t ht9 ht8 i).trans (hwS_ne8 t ht8 i),
      fun i hi => (hw₂_scr i (Or.inl hi)).trans (hwS_lt10 i hi),
      fun t ht3 i => (hr₂ t ht3 i).trans (hrS t i)⟩
  refine ExecDet.seq' (340 + C_loop) hserv_stmt (by omega) ?_
  intro m₂ ⟨hsr₂, hserv1_len, hserv_enc₂, hr14_2, hnd_12, hw₂_t, hw₂_lt10, hr₂⟩ hfp₂
  -- Step 3: leafLiveUpdateStmt
  have hov_inv : st.leafOverflow = false →
      (isIns = true → h_op ∉ st.leafArr) ∧ st.leafArr.length ≤ cp.B_scan := by
    intro hov_f
    rcases hwf.2.2.2.2.2 hov_f with ⟨_, hleaf_set, hleaf_B⟩
    refine ⟨fun his_t hmem => ?_, hleaf_B⟩
    have hfold_sub : foldResiduals st.hp.coords P.activeHandles st.serving ⊆ P.activeHandles :=
      (chainListInv_getElem P.activeHandles st.serving (Finset.Subset.refl _) hwf.2.2.2.1).1
    have hin_act : h_op ∈ P.activeHandles :=
      hfold_sub (hleaf_set ▸ List.mem_toFinset.mpr hmem)
    exact (hins_case his_t).1 hin_act
  have hleaf_sp₂ : EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) st.leafArr m₂ :=
    hleaf_sp₀.ext
      ((hw₂_t engMetaTbl (by decide) (by decide) 2).trans
        (hw_ge5_1 engMetaTbl (by decide) (by decide) 2))
      (fun _ _ => (hw₂_t engArrTbl (by decide) (by decide) _).trans
        (hw_ge5_1 engArrTbl (by decide) (by decide) _))
      (fun _ _ => (hw₂_t engArrTbl (by decide) (by decide) _).trans
        (hw_ge5_1 engArrTbl (by decide) (by decide) _))
  refine ExecDet.seq' C_loop
    (exec_leafLiveUpdateStmt ops inp hhop_lt hleaf_le₀ hov_inv hfp₂ hsr₂
      ((hw₂_t engMetaTbl (by decide) (by decide) 1).trans
        ((hw_ge5_1 engMetaTbl (by decide) (by decide) 1).trans hov₀))
      hleaf_sp₂
      ((hw₂_lt10 1 (by omega)).trans hr1_1)
      ((hw₂_lt10 2 (by omega)).trans hr2_1)
      hr14_2)
    (by omega) ?_
  intro m₃ ⟨hsr₃, hleaf1_le, hleaf1_sp, hnd_23, hw₃_t, hw₃_m, hw₃_a, hw₃_s, hr₃⟩ hfp₃
  -- Transfer state to m₃ before jobs loop
  have hw13_t : ∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl →
      ∀ i, wRead m₃ t i = wRead m₁ t i :=
    fun t ht9 h6 h7 h8 i => (hw₃_t t h6 h7 h8 i).trans (hw₂_t t ht9 h8 i)
  have hw03_m_ne2 : ∀ i, i ≠ 2 → wRead m₃ engMetaTbl i = wRead m₀ engMetaTbl i :=
    fun i hi => (hw₃_m i hi).trans ((hw₂_t engMetaTbl (by decide) (by decide) i).trans
      (hw_ge5_1 engMetaTbl (by decide) (by decide) i))
  have hw03_a_ge2S : ∀ i, 2 * (S_stride cp : ℤ) ≤ i → wRead m₃ engArrTbl i = wRead m₀ engArrTbl i :=
    fun i hi => (hw₃_a i hi).trans ((hw₂_t engArrTbl (by decide) (by decide) i).trans
      (hw_ge5_1 engArrTbl (by decide) (by decide) i))
  have hr13 : ∀ t < 3, ∀ i, rRead m₃ t i = rRead m₁ t i :=
    fun t ht3 i => (hr₃ t i).trans (hr₂ t ht3 i)
  have hr1_3 : wRead m₃ engScrTbl 1 = (if isIns then 1 else 0) :=
    (hw₃_s 1 (by omega)).trans ((hw₂_lt10 1 (by omega)).trans hr1_1)
  have hr2_3 : wRead m₃ engScrTbl 2 = (h_op : ℤ) :=
    (hw₃_s 2 (by omega)).trans ((hw₂_lt10 2 (by omega)).trans hr2_1)
  have hserv_enc₃ : ∀ q (hq : q < servRes.1.length) (hqs : q < servSlots.length),
      wRead m₃ engMetaTbl (servSlotOff q) = (servSlots[q]'hqs : ℤ) ∧
      ops.EncNode (servRes.1[q]'hq) (servSlots[q]'hqs) m₃ :=
    fun q hq hqs => ⟨(hw03_m_ne2 _ (by unfold servSlotOff; omega)).trans
        (hserv_enc₀ q (hserv1_len ▸ hq) hqs).1,
      hnd_23 _ _ (hserv_enc₂ q hq hqs)⟩
  have hjobs_enc₃ : ∀ r : Fin cp.D_max, EncJobSlot ops r (st.jobs r) (readySlots r) (curSlots r) m₃ := by
    intro r
    refine encJobSlot_frame_local (hjobs_enc₁ r)
      (fun off h0 _ => (hw₃_m _ (by unfold jobMetaBase; omega)).trans
        (hw₂_t engMetaTbl (by decide) (by decide) _))
      (fun q _ => (hw₃_m _ (by unfold readySlotOff; have := Int.mul_nonneg (Int.natCast_nonneg r.val) (Int.natCast_nonneg cp.D_max); omega)).trans
        (hw₂_t engMetaTbl (by decide) (by decide) _))
      (fun i hlo _ => (hw₃_a i (by
          have : 2 * S_stride cp ≤ (2 + 4 * r.val) * S_stride cp := Nat.mul_le_mul_right _ (by omega)
          have hz : 2 * (S_stride cp : ℤ) ≤ (((2 + 4 * r.val) * S_stride cp : ℕ) : ℤ) := by
            exact_mod_cast this
          omega)).trans
        (hw₂_t engArrTbl (by decide) (by decide) i))
      (fun mn s hs he1 => hnd_23 _ _ (hnd_12 mn s (hj_lt r s hs) (hdisj_sj r s hs) he1))
  -- Step 4: jobsLoopStage1Stmt
  unfold jobsLoopStage1Stmt
  refine ExecDet.seq' (16 + (1 + cp.D_max * (C_body + 6)))
    (ExecDet.wWrite (C := 18) inp engScrTbl (.lit 22) (.readHeap engMetaTbl (.lit 0))
      22 (st.serving.length : ℤ) hfp₃ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change wRead m₃ engMetaTbl 0 = _
          exact (hw03_m_ne2 0 (by decide)).trans hserv_len₀)
      (by simp [intExprOps]) rfl)
    (by dsimp [C_loop]; omega) ?_
  intro mL₁ hmL₁ hfpL₁; subst hmL₁
  refine ExecDet.seq' (4 + (1 + cp.D_max * (C_body + 6)))
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 23) (.lit 1)
      23 1 hfpL₁ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl rfl
      (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro mL₂ hmL₂ hfpL₀; subst hmL₂
  set mL₀ := H3a.wWrite (H3a.wWrite m₃ engScrTbl 22 (st.serving.length : ℤ)) engScrTbl 23 1
  let InvL : ℕ → ArithRAMMemory → Prop := fun k m =>
    ops.SlotsReady m ∧
    (∀ i (hi : i < servRes.1.length) (his : i < servSlots.length),
      wRead m engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ) ∧
      ops.EncNode (servRes.1[i]'hi) (servSlots[i]'his) m) ∧
    (∀ r : Fin cp.D_max,
      EncJobSlot ops r (if r.val < k then res.1.jobs r else st.jobs r)
        (readySlots r) (curSlots r) m) ∧
    wRead m engScrTbl 23 = (if passesNodes pts' h_op (st.serving.take k) then 1 else 0) ∧
    (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₃ t i) ∧
    (∀ i, i < 16 + (cp.D_max : ℤ) → wRead m engMetaTbl i = wRead m₃ engMetaTbl i) ∧
    (∀ i, i < 2 * (S_stride cp : ℤ) → wRead m engArrTbl i = wRead m₃ engArrTbl i) ∧
    (∀ i, (i = 1 ∨ i = 2 ∨ i = 22) → wRead m engScrTbl i = wRead mL₀ engScrTbl i) ∧
    (∀ t < 3, ∀ i, rRead m t i = rRead m₃ t i)
  refine (ExecDet.forLoop engScrTbl 20 cp.D_max (jobBodyStage1Stmt ops) InvL C_body
    hfpL₀ (by dsimp [engScrTbl]; omega) (by omega) (by omega) ?_ ?_).mono ?_ le_rfl
  · -- Loop init (k = 0)
    set mZ := H3a.wWrite mL₀ engScrTbl 20 0
    have hwZ_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead mZ t i = wRead m₃ t i := by
      intro t ht i; simp only [mZ, mL₀]; iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
    have hrZ : ∀ t i, rRead mZ t i = rRead m₃ t i := fun _ _ => by simp [mZ, mL₀, rRead_wWrite]
    have hndZ : ∀ mn' s', ops.EncNode mn' s' m₃ → ops.EncNode mn' s' mZ :=
      fun mn' s' he => ops.encNode_ext mn' s' m₃ mZ he
        (fun t ht9 _ i => hwZ_ne8 t (by dsimp [engScrTbl]; omega) i)
        (fun _ _ _ _ => hrZ _ _) (fun _ _ _ _ => hrZ ptsRTbl _)
    refine ⟨ops.slotsReady_ext m₃ mZ hsr₃
        (fun t ht9 _ i => hwZ_ne8 t (by dsimp [engScrTbl]; omega) i)
        (fun _ _ _ _ => hrZ _ _),
      fun i hi his => ⟨(hwZ_ne8 engMetaTbl (by decide) _).trans (hserv_enc₃ i hi his).1,
        hndZ _ _ (hserv_enc₃ i hi his).2⟩,
      fun r => by
        simp only [Nat.not_lt_zero, ↓reduceIte]
        exact encJobSlot_ext (hjobs_enc₃ r)
          (hwZ_ne8 engMetaTbl (by decide)) (hwZ_ne8 engArrTbl (by decide)) hndZ,
      by simp only [mZ, mL₀, List.take_zero, passesNodes, ↓reduceIte]
         rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self],
      fun t _ _ _ ht8 i => hwZ_ne8 t ht8 i,
      fun i _ => hwZ_ne8 engMetaTbl (by decide) i,
      fun i _ => hwZ_ne8 engArrTbl (by decide) i,
      fun i hi => wRead_wWrite_of_ne mL₀ _ (Or.inr (by omega)),
      fun t _ i => hrZ t i⟩
  · -- Loop step (k → k + 1)
    intro k hk m ⟨hsr_m, hserv_m, hjobs_m, hr23_m, hw_t_m, hw_meta_m, hw_arr_m, hw_scr_m, hr_m⟩ hr20_m hfp_m
    let rk : Fin cp.D_max := ⟨k, hk⟩
    have hr1_m : wRead m engScrTbl 1 = (if isIns then 1 else 0) :=
      (hw_scr_m 1 (by omega)).trans (by
        simp only [mL₀]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by decide))]
        exact hr1_3)
    have hr2_m : wRead m engScrTbl 2 = (h_op : ℤ) :=
      (hw_scr_m 2 (by omega)).trans (by
        simp only [mL₀]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by decide))]
        exact hr2_3)
    have hr22_m : wRead m engScrTbl 22 = (st.serving.length : ℤ) :=
      (hw_scr_m 22 (by omega)).trans (by
        simp only [mL₀]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
    unfold jobBodyStage1Stmt
    refine ExecDet.seq' (C_jobSlotUpdateStage1 ops + (ops.C_ball + 50))
      (ExecDet.wWrite (C := 18) inp engScrTbl (.lit 21)
        (.add (.lit (16 + (cp.D_max : ℤ))) (.mul (.readHeap engScrTbl (.lit 20)) (.lit 8)))
        21 (jobMetaBase cp rk.val) hfp_m (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
        (by simp only [evalIntExpr]
            change (16 + (cp.D_max : ℤ)) + wRead m engScrTbl 20 * 8 = _
            rw [hr20_m]; dsimp [rk, jobMetaBase]; ring)
        (by simp [intExprOps]) rfl)
      (by dsimp [C_body]; omega) ?_
    intro mJ₀ hmJ₀ hfpJ₀; subst hmJ₀
    set m_J0 := H3a.wWrite m engScrTbl 21 (jobMetaBase cp rk.val)
    have hwJ0_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead m_J0 t i = wRead m t i :=
      fun t ht i => wRead_wWrite_of_ne m _ (Or.inl ht)
    have hrJ0 : ∀ t i, rRead m_J0 t i = rRead m t i := fun _ _ => rRead_wWrite _ _ _ _ _ _
    have hndJ0 : ∀ mn' s', ops.EncNode mn' s' m → ops.EncNode mn' s' m_J0 :=
      fun mn' s' he => ops.encNode_ext mn' s' m m_J0 he
        (fun t ht9 _ i => hwJ0_ne8 t (by dsimp [engScrTbl]; omega) i)
        (fun _ _ _ _ => hrJ0 _ _) (fun _ _ _ _ => hrJ0 ptsRTbl _)
    have hj_rk_m : EncJobSlot ops rk (st.jobs rk) (readySlots rk) (curSlots rk) m := by
      have h := hjobs_m rk
      simp only [rk, Nat.lt_irrefl, ↓reduceIte] at h
      exact h
    refine ExecDet.seq' (ops.C_ball + 50)
      (exec_jobSlotUpdateStage1Stmt (actH := P.activeHandles) (P := P) (st := st)
        (uop := toInternalUpdate P op) (bits := bits)
        (isIns := match toInternalUpdate P op with | .insert _ => true | .delete _ => false)
        (h_op := h_op)
        ops inp rk (readySlots rk) (curSlots rk)
        rfl hwf rfl (by dsimp only [h_op, rh, uop]; generalize toInternalUpdate P op = u; cases u <;> rfl)
        (show h_op < cp.n from hhop_lt) hact_lt (hj_nd rk) (hj_lt rk)
        (show isIns = true → _ from hins_case) (show isIns = false → _ from hdel_case)
        (fun x hx c => (hrJ0 ptsRTbl _).trans ((hr_m ptsRTbl (by decide) _).trans
          ((hr13 ptsRTbl (by decide) _).trans (hpts_mem₁ x hx c))))
        (fun j => (hwJ0_ne8 coinTbl (by decide) _).trans
          ((hw_t_m coinTbl (by decide) (by decide) (by decide) (by decide) _).trans
            ((hw13_t coinTbl (by decide) (by decide) (by decide) (by decide) _).trans (hcoins₁ j))))
        hfpJ₀
        (ops.slotsReady_ext m m_J0 hsr_m
          (fun t ht9 _ i => hwJ0_ne8 t (by dsimp [engScrTbl]; omega) i)
          (fun _ _ _ _ => hrJ0 _ _))
        (encJobSlot_ext hj_rk_m (hwJ0_ne8 engMetaTbl (by decide)) (hwJ0_ne8 engArrTbl (by decide)) hndJ0)
        ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr1_m)
        ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr2_m)
        ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr20_m)
        (wRead_wWrite_self _ _ _ _)
        ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr22_m)
        ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr23_m))
      (by omega) ?_
    intro mJ₁ ⟨hsrJ₁, hj_rk_1, hndJ₁, hwJ₁_t, hwJ₁_m, hwJ₁_a, hwJ₁_s, hrJ₁⟩ hfpJ₁
    have hserv_J₁ : ∀ q (hq1 : q < servRes.1.length) (hqs : q < servSlots.length),
        wRead mJ₁ engMetaTbl (servSlotOff q) = (servSlots[q]'hqs : ℤ) ∧
        ops.EncNode (servRes.1[q]'hq1) (servSlots[q]'hqs) mJ₁ := by
      intro q hq1 hqs
      have hqs_lt : servSlots[q]'hqs < M_slots cp := hserv_lt _ (List.getElem_mem hqs)
      have hqs_not : servSlots[q]'hqs ∉ jSlots rk := fun hm => hdisj_sj rk _ hm (List.getElem_mem hqs)
      have hq_lt_D : q < cp.D_max := lt_of_lt_of_le (hserv1_len ▸ hq1) hserv_le₀
      refine ⟨(hwJ₁_m _ (by unfold servSlotOff jobMetaBase; omega)
          (by unfold servSlotOff jobMetaBase; omega)).trans
          ((hwJ0_ne8 engMetaTbl (by decide) _).trans (hserv_m q hq1 hqs).1),
        hndJ₁ _ _ hqs_lt hqs_not (hndJ0 _ _ (hserv_m q hq1 hqs).2)⟩
    have hr2_J₁ : wRead mJ₁ engScrTbl 2 = (h_op : ℤ) :=
      (hwJ₁_s 2 (Or.inl (by omega))).trans ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr2_m)
    have hr20_J₁ : wRead mJ₁ engScrTbl 20 = (k : ℤ) :=
      (hwJ₁_s 20 (Or.inr ⟨by omega, by omega⟩)).trans
        ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr20_m)
    have hr22_J₁ : wRead mJ₁ engScrTbl 22 = (st.serving.length : ℤ) :=
      (hwJ₁_s 22 (Or.inr ⟨by omega, by omega⟩)).trans
        ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr22_m)
    have hr23_J₁ : wRead mJ₁ engScrTbl 23 =
        (if passesNodes pts' h_op (st.serving.take k) then 1 else 0) :=
      (hwJ₁_s 23 (Or.inr ⟨by omega, by omega⟩)).trans
        ((wRead_wWrite_of_ne m _ (Or.inr (by decide))).trans hr23_m)
    refine (exec_passPrefixStepStmt ops inp hhop_lt hserv1_len
      hslen₀ hserv_lt
      (fun q hq1 hq0 => liveUpdateChainList_getElem_o_V cp pts' isIns h_op (getS1Seed cp ω₁)
        0 st.serving q hq1 hq0)
      hserv_J₁
      (fun c => (hrJ₁ ptsRTbl (by decide) _).trans
        ((hrJ0 ptsRTbl _).trans ((hr_m ptsRTbl (by decide) _).trans
          ((hr13 ptsRTbl (by decide) _).trans
            (hpts_mem₁ h_op (Finset.mem_insert_self _ _) c)))))
      hfpJ₁ hsrJ₁ hr2_J₁ hr20_J₁ hr22_J₁ hr23_J₁).mono ?_ le_rfl
    intro mJ₂ ⟨hsrJ₂, hr23_J₂, hndJ₂, hwJ₂_t, hwJ₂_s, hrJ₂⟩ _
    have hr20_J₂ : wRead mJ₂ engScrTbl 20 = (k : ℤ) :=
      (hwJ₂_s 20 (by decide) (by decide) (by decide)).trans hr20_J₁
    refine ⟨hr20_J₂, ?_⟩
    set mN := H3a.wWrite mJ₂ engScrTbl 20 ((k : ℤ) + 1)
    have hwN_t9 : ∀ t < 9, t ≠ engScrTbl → ∀ i, wRead mN t i = wRead mJ₁ t i :=
      fun t ht9 ht8 i => (wRead_wWrite_of_ne mJ₂ _ (Or.inl ht8)).trans (hwJ₂_t t ht9 ht8 i)
    have hrN : ∀ t < 3, ∀ i, rRead mN t i = rRead mJ₁ t i :=
      fun t ht3 i => (rRead_wWrite _ _ _ _ _ _).trans (hrJ₂ t ht3 i)
    have hnd_2N : ∀ mn' s', ops.EncNode mn' s' mJ₂ → ops.EncNode mn' s' mN :=
      fun mn' s' he => ops.encNode_ext mn' s' mJ₂ mN he
        (fun t ht9 _ i => wRead_wWrite_of_ne mJ₂ _ (Or.inl (by dsimp [engScrTbl]; omega)))
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _)
    have hnd_1N : ∀ mn' s', s' < M_slots cp → ops.EncNode mn' s' mJ₁ → ops.EncNode mn' s' mN :=
      fun mn' s' hs' he => hnd_2N _ _ (hndJ₂ mn' s' hs' he)
    refine ⟨ops.slotsReady_ext mJ₂ mN hsrJ₂
        (fun t ht9 _ i => wRead_wWrite_of_ne mJ₂ _ (Or.inl (by dsimp [engScrTbl]; omega)))
        (fun _ _ _ _ => rRead_wWrite _ _ _ _ _ _),
      fun i hi his => ⟨(hwN_t9 engMetaTbl (by decide) (by decide) _).trans (hserv_J₁ i hi his).1,
        hnd_1N _ _ (hserv_lt _ (List.getElem_mem his)) (hserv_J₁ i hi his).2⟩,
      fun r => ?_,
      (wRead_wWrite_of_ne mJ₂ _ (Or.inr (by decide))).trans hr23_J₂,
      fun t ht9 h6 h7 ht8 i => (hwN_t9 t ht9 ht8 i).trans
        ((hwJ₁_t t ht9 h6 h7 ht8 i).trans ((hwJ0_ne8 t ht8 i).trans (hw_t_m t ht9 h6 h7 ht8 i))),
      fun i hi => (hwN_t9 engMetaTbl (by decide) (by decide) i).trans
        ((hwJ₁_m i (by unfold jobMetaBase; dsimp [rk]; omega)
            (by unfold jobMetaBase; dsimp [rk]; omega)).trans
          ((hwJ0_ne8 engMetaTbl (by decide) i).trans (hw_meta_m i hi))),
      fun i hi => (hwN_t9 engArrTbl (by decide) (by decide) i).trans
        ((hwJ₁_a i (Or.inl (by
            have : 2 * S_stride cp ≤ (2 + 4 * rk.val) * S_stride cp := Nat.mul_le_mul_right _ (by omega)
            have hz : 2 * (S_stride cp : ℤ) ≤ (((2 + 4 * rk.val) * S_stride cp : ℕ) : ℤ) := by
              exact_mod_cast this
            omega))).trans
          ((hwJ0_ne8 engArrTbl (by decide) i).trans (hw_arr_m i hi))),
      fun i hi => by
        have h20 : i ≠ 20 := by omega
        have h15 : i ≠ 15 := by omega
        have h17 : i ≠ 17 := by omega
        have h23 : i ≠ 23 := by omega
        have h21 : i ≠ 21 := by omega
        have hkeep : i < 10 ∨ (20 ≤ i ∧ i < 30) := by omega
        exact (wRead_wWrite_of_ne mJ₂ _ (Or.inr h20)).trans
          ((hwJ₂_s i h15 h17 h23).trans
            ((hwJ₁_s i hkeep).trans
              ((wRead_wWrite_of_ne m _ (Or.inr h21)).trans (hw_scr_m i hi)))),
      fun t ht3 i => (hrN t ht3 i).trans
        ((hrJ₁ t ht3 i).trans ((hrJ0 t i).trans (hr_m t ht3 i)))⟩
    by_cases hrk : r = rk
    · subst hrk
      have hlt_succ : rk.val < k + 1 := by dsimp [rk]; omega
      rw [if_pos hlt_succ]
      refine encJobSlot_frame_local hj_rk_1
        (fun _ _ _ => hwN_t9 engMetaTbl (by decide) (by decide) _)
        (fun _ _ => hwN_t9 engMetaTbl (by decide) (by decide) _)
        (fun i _ _ => hwN_t9 engArrTbl (by decide) (by decide) i)
        (fun mn s hs he1 => hnd_1N mn s
          (hj_lt rk s (by dsimp only [jSlots]; dsimp only [res] at hs; rw [← jobUsedSlots_stage1_eq st uop ω₁ rk]; exact hs)) he1)
    · have hval_ne : r.val ≠ k := fun heq => hrk (Fin.ext heq)
      let jbCur := if r.val < k then res.1.jobs r else st.jobs r
      have hite_eq : (if r.val < k + 1 then res.1.jobs r else st.jobs r) = jbCur := by
        dsimp only [jbCur]
        by_cases hlt : r.val < k
        · rw [if_pos (by omega), if_pos hlt]
        · rw [if_neg (by omega), if_neg hlt]
      have hused_eq : jobUsedSlots jbCur (readySlots r) (curSlots r) = jSlots r := by
        dsimp only [jbCur, jSlots]
        split_ifs
        · exact jobUsedSlots_stage1_eq st uop ω₁ r _ _
        · rfl
      rw [hite_eq]
      refine encJobSlot_frame_local (hjobs_m r)
        (fun off h0 h8 => (hwN_t9 engMetaTbl (by decide) (by decide) _).trans
          ((hwJ₁_m _ (by unfold jobMetaBase; dsimp [rk]; omega)
              (by unfold jobMetaBase; dsimp [rk]; omega)).trans
            (hwJ0_ne8 engMetaTbl (by decide) _)))
        (fun q hq => (hwN_t9 engMetaTbl (by decide) (by decide) _).trans
          ((hwJ₁_m _ (by unfold readySlotOff jobMetaBase; dsimp [rk]; have := rk.isLt; have := Int.mul_nonneg (Int.natCast_nonneg r.val) (Int.natCast_nonneg cp.D_max); omega)
              (by unfold readySlotOff jobMetaBase; dsimp [rk]; have := rk.isLt; have := Int.mul_nonneg (Int.natCast_nonneg r.val) (Int.natCast_nonneg cp.D_max); omega)).trans
            (hwJ0_ne8 engMetaTbl (by decide) _)))
        (fun i hlo hhi => (hwN_t9 engArrTbl (by decide) (by decide) i).trans
          ((hwJ₁_a i (by
              by_cases hlt_rk : r.val < k
              · left
                have : (6 + 4 * r.val) * S_stride cp ≤ (2 + 4 * rk.val) * S_stride cp := by
                  dsimp [rk]; exact Nat.mul_le_mul_right _ (by omega)
                have hz : (((6 + 4 * r.val) * S_stride cp : ℕ) : ℤ) ≤
                    (((2 + 4 * rk.val) * S_stride cp : ℕ) : ℤ) := by exact_mod_cast this
                omega
              · right
                have hgt_rk : k + 1 ≤ r.val := by omega
                have : (6 + 4 * rk.val) * S_stride cp ≤ (2 + 4 * r.val) * S_stride cp := by
                  dsimp [rk]; exact Nat.mul_le_mul_right _ (by omega)
                have hz : (((6 + 4 * rk.val) * S_stride cp : ℕ) : ℤ) ≤
                    (((2 + 4 * r.val) * S_stride cp : ℕ) : ℤ) := by exact_mod_cast this
                omega)).trans
            (hwJ0_ne8 engArrTbl (by decide) i)))
        (fun mn s hs he_m => by
          have hs_r : s ∈ jSlots r := by rw [← hused_eq]; exact hs
          exact hnd_1N mn s (hj_lt r s hs_r)
            (hndJ₁ mn s (hj_lt r s hs_r) (hj_disj r rk hrk s hs_r) (hndJ0 mn s he_m)))
  · -- Post-loop: assemble EncChainEngine ops res.1 mF + MemHasStepCoins + readReturnedHandle
    intro mF ⟨hsrF, hservF, hjobsF, _, hw_tF, hw_metaF, hw_arrF, _, hrF⟩ _
    have hw1F_t : ∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl →
        ∀ i, wRead mF t i = wRead m₁ t i :=
      fun t ht9 h6 h7 h8 i => (hw_tF t ht9 h6 h7 h8 i).trans (hw13_t t ht9 h6 h7 h8 i)
    have hr1F : ∀ t < 3, ∀ i, rRead mF t i = rRead m₁ t i :=
      fun t ht3 i => (hrF t ht3 i).trans (hr13 t ht3 i)
    have hw1F_0 : ∀ i, wRead mF 0 i = wRead m₁ 0 i := hw1F_t 0 (by decide) (by decide) (by decide) (by decide)
    have hw1F_1 : ∀ i, wRead mF 1 i = wRead m₁ 1 i := hw1F_t 1 (by decide) (by decide) (by decide) (by decide)
    have hw1F_2 : ∀ i, wRead mF 2 i = wRead m₁ 2 i := hw1F_t 2 (by decide) (by decide) (by decide) (by decide)
    have hw1F_3 : ∀ i, wRead mF 3 i = wRead m₁ 3 i := hw1F_t 3 (by decide) (by decide) (by decide) (by decide)
    have hhpF : EncHandlePool res.1.hp mF := by
      rw [hres_fields.1]
      exact ⟨(hw1F_0 4).trans hhp₁.1, (hw1F_0 5).trans hhp₁.2.1, (hw1F_0 6).trans hhp₁.2.2.1,
        fun i hi => (hw1F_1 _).trans (hhp₁.2.2.2.1 i hi),
        fun i hi => ⟨(hw1F_2 _).trans (hhp₁.2.2.2.2.1 i hi).1,
                     (hw1F_3 _).trans (hhp₁.2.2.2.2.1 i hi).2⟩,
        fun x hx c => (hr1F ptsRTbl (by decide) _).trans (hhp₁.2.2.2.2.2 x hx c)⟩
    have hw1F_m345 : ∀ i : ℤ, (i = 3 ∨ i = 4 ∨ i = 5) → wRead mF engMetaTbl i = wRead m₁ engMetaTbl i := by
      intro i hi
      exact (hw_metaF i (by omega)).trans
        ((hw₃_m i (by omega)).trans (hw₂_t engMetaTbl (by decide) (by decide) i))
    have hansF : EncCachedAns res.1.cachedAns mF := by
      rw [hres_fields.2.1]
      rcases hans₁ with ⟨hrc₁, hr_sh₁, hmatch₁⟩
      have hrcF : ArithRAMDynamicProgram.readCachedAnswer mF =
          ArithRAMDynamicProgram.readCachedAnswer m₁ := by
        have h01 : mF.words.read (.heap 0 1) = m₁.words.read (.heap 0 1) := hw1F_0 1
        have h02 : mF.words.read (.heap 0 2) = m₁.words.read (.heap 0 2) := hw1F_0 2
        have h03 : mF.words.read (.heap 0 3) = m₁.words.read (.heap 0 3) := hw1F_0 3
        have hr00 : mF.reals.read (.heap 0 0) = m₁.reals.read (.heap 0 0) := hr1F 0 (by decide) 0
        unfold ArithRAMDynamicProgram.readCachedAnswer
        rw [h01, h02, h03, hr00]
      refine ⟨hrcF.trans hrc₁, (hr1F engRealTbl (by decide) 0).trans hr_sh₁, ?_⟩
      cases hd_ans : st.cachedAns.diameterHandles with
      | none =>
          simp only [hd_ans] at hmatch₁
          exact ⟨(hw1F_m345 3 (by omega)).trans hmatch₁.1,
                 (hw1F_m345 4 (by omega)).trans hmatch₁.2.1,
                 (hw1F_m345 5 (by omega)).trans hmatch₁.2.2⟩
      | some uv =>
          rcases uv with ⟨u, v⟩
          simp only [hd_ans] at hmatch₁
          exact ⟨(hw1F_m345 3 (by omega)).trans hmatch₁.1,
                 (hw1F_m345 4 (by omega)).trans hmatch₁.2.1,
                 (hw1F_m345 5 (by omega)).trans hmatch₁.2.2⟩
    have hleaf_spF : EncSparseSet cp.n 2 leafElemOff (leafPosOff cp) res.1.leafArr mF := by
      rw [hres_fields.2.2.2.2.1]
      exact hleaf1_sp.ext
        (hw_metaF 2 (by omega))
        (fun k hk => hw_arrF _ (by have := hleaf1_sp.length_le; unfold leafElemOff; omega))
        (fun y hy => hw_arrF _ (by have := hleaf1_sp.2.1 y hy; unfold leafPosOff; omega))
    have hflat_eq : (List.finRange cp.D_max).flatMap
        (fun r => jobUsedSlots (res.1.jobs r) (readySlots r) (curSlots r)) =
        (List.finRange cp.D_max).flatMap jSlots := by
      congr 1; funext r
      exact jobUsedSlots_stage1_eq st uop ω₁ r (readySlots r) (curSlots r)
    refine ⟨?_,
      fun j => (hw1F_t coinTbl (by decide) (by decide) (by decide) (by decide) _).trans (hcoins₁ j),
      fun h_new hrh => ?_⟩
    · refine ⟨hsrF, hhpF, hansF,
        by rw [hres_fields.2.2.1]; exact (hw_metaF 1 (by omega)).trans ((hw03_m_ne2 1 (by decide)).trans hov₀),
        by rw [hres_fields.2.2.2.2.1]; exact hleaf1_le,
        hleaf_spF,
        by rw [hres_fields.2.2.2.1, hserv1_len]; exact hserv_le₀,
        by rw [hres_fields.2.2.2.1, hserv1_len]
           exact (hw_metaF 0 (by omega)).trans ((hw03_m_ne2 0 (by decide)).trans hserv_len₀),
        servSlots, readySlots, curSlots,
        by rw [hres_fields.2.2.2.1, hserv1_len]; exact hslen₀,
        fun i hi his => by
          have hi' : i < servRes.1.length := hres_fields.2.2.2.1 ▸ hi
          have helem : res.1.serving[i]'hi = servRes.1[i]'hi' := list_getElem_of_eq hres_fields.2.2.2.1 i hi hi'
          rw [helem]
          exact hservF i hi' his,
        fun r => by
          have h := hjobsF r
          rw [if_pos r.isLt] at h
          exact h,
        by rw [hflat_eq]; exact hall_nd,
        by rw [hflat_eq]; exact hall_lt⟩
    · rw [hres_fields.2.2.2.2.2] at hrh
      have h00 : mF.words.read (.heap 0 0) = m₁.words.read (.heap 0 0) := hw1F_0 0
      unfold ArithRAMDynamicProgram.readReturnedHandle
      rw [h00]
      exact hret₁ h_new hrh

end UL.Proof.clm_9_1_explicit_tradeoff.CG19
