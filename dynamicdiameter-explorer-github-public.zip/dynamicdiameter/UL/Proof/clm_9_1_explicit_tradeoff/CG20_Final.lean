import UL.Proof.clm_9_1_explicit_tradeoff.CG20_FinalD
import UL.Proof.clm_9_1_explicit_tradeoff.CG15_Stage2
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG20

open UL

/-- Complete zero-sorry proof of `S_clm_9_1_explicit_tradeoff`. -/
theorem clm_9_1_proved
    (h_lem_5_1 : S_lem_5_1)
    (h_clm_5_1_mc_baseline : S_clm_5_1_mc_baseline)
    (h_lem_6_2 : S_lem_6_2)
    (h_clm_6_1_adaptive : S_clm_6_1_adaptive)
    (h_clm_6_1_precision : S_clm_6_1_precision)
    (h_clm_7_3_global_approx : S_clm_7_3_global_approx)
    (h_lem_9_1 : S_lem_9_1) :
    S_clm_9_1_explicit_tradeoff :=
  UL.Proof.clm_9_1_explicit_tradeoff.CG15_Stage2.prove_clm_9_1_explicit_tradeoff_complete
    h_lem_5_1 h_clm_5_1_mc_baseline h_lem_6_2
    h_clm_6_1_adaptive h_clm_6_1_precision h_clm_7_3_global_approx h_lem_9_1

end UL.Proof.clm_9_1_explicit_tradeoff.CG20
