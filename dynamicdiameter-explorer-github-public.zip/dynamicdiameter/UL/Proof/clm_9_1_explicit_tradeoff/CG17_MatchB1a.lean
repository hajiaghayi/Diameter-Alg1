import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H4b

/-! ### 1. `IndexDisjoint` and Matching/Index Membership Bridges -/

def IndexDisjoint (st : LocalMatchingState ℕ) : Prop :=
  (∀ u ∈ st.leftIndexSet, u ∉ (st.matchingList.map MatchingEdge.pair).map Prod.fst) ∧
  (∀ u ∈ st.rightIndexSet, u ∉ (st.matchingList.map MatchingEdge.pair).map Prod.snd)

theorem isCopyMatched_left_iff (st : LocalMatchingState ℕ) (u : ℕ) :
    st.isCopyMatched ⟨.left, u⟩ ↔ u ∈ (st.matchingList.map MatchingEdge.pair).map Prod.fst := by
  rw [pairs_fst_eq_left]
  simp [LocalMatchingState.isCopyMatched]

theorem isCopyMatched_right_iff (st : LocalMatchingState ℕ) (u : ℕ) :
    st.isCopyMatched ⟨.right, u⟩ ↔ u ∈ (st.matchingList.map MatchingEdge.pair).map Prod.snd := by
  rw [pairs_snd_eq_right]
  simp [LocalMatchingState.isCopyMatched]

theorem mem_matching_iff_mem_pairs (st : LocalMatchingState ℕ) (x y : ℕ) :
    (x, y) ∈ st.matching ↔ (x, y) ∈ st.matchingList.map MatchingEdge.pair := by
  classical
  unfold LocalMatchingState.matching
  convert List.mem_toFinset

theorem IndexDisjoint.of_wellFormed {d : ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {V_L V_R : Finset ℕ} {st : LocalMatchingState ℕ}
    (hwf : st.WellFormed pts V_L V_R) :
    IndexDisjoint st := by
  classical
  rcases hwf with ⟨_, _, _, _, hlset, _, hrset, _⟩
  constructor
  · intro u hu hmem
    rw [hlset] at hu
    unfold unmatchedLeft at hu
    have hno := (Finset.mem_filter.mp hu).2
    rcases List.mem_map.mp hmem with ⟨⟨x, y⟩, hxy, rfl⟩
    exact hno y ((mem_matching_iff_mem_pairs st x y).mpr hxy)
  · intro u hu hmem
    rw [hrset] at hu
    unfold unmatchedRight at hu
    have hno := (Finset.mem_filter.mp hu).2
    rcases List.mem_map.mp hmem with ⟨⟨x, y⟩, hxy, rfl⟩
    exact hno x ((mem_matching_iff_mem_pairs st x y).mpr hxy)

theorem IndexDisjoint.removeCopies {st : LocalMatchingState ℕ} (p : ℕ)
    (hdj : IndexDisjoint st) :
    IndexDisjoint (removeCopiesFromState st p) := by
  constructor
  · intro u hu hmem
    rw [leftIndexSet_removeCopies_eq] at hu
    have hu0 := Finset.mem_of_mem_erase hu
    rcases List.mem_map.mp hmem with ⟨xy, hxy, rfl⟩
    rcases List.mem_map.mp hxy with ⟨e, he, rfl⟩
    have he0 : e ∈ st.matchingList := by
      unfold removeCopiesFromState at he
      exact List.mem_of_mem_filter he
    exact hdj.1 e.pair.1 hu0 (List.mem_map_of_mem (List.mem_map_of_mem he0))
  · intro u hu hmem
    rw [rightIndexSet_removeCopies_eq] at hu
    have hu0 := Finset.mem_of_mem_erase hu
    rcases List.mem_map.mp hmem with ⟨xy, hxy, rfl⟩
    rcases List.mem_map.mp hxy with ⟨e, he, rfl⟩
    have he0 : e ∈ st.matchingList := by
      unfold removeCopiesFromState at he
      exact List.mem_of_mem_filter he
    exact hdj.2 e.pair.2 hu0 (List.mem_map_of_mem (List.mem_map_of_mem he0))

theorem wellFormed_subsets {d : ℕ} {pts : ℕ → EuclideanSpace ℝ (Fin d)}
    {V_L V_R : Finset ℕ} {st : LocalMatchingState ℕ}
    (hwf : st.WellFormed pts V_L V_R) :
    (∀ xy ∈ st.matchingList.map MatchingEdge.pair, xy.1 ∈ V_L ∧ xy.2 ∈ V_R) ∧
    st.leftIndexSet ⊆ V_L ∧
    st.rightIndexSet ⊆ V_R := by
  rcases hwf with ⟨_, _, hedges, _, hlset, _, hrset, _⟩
  refine ⟨?_, ?_, ?_⟩
  · intro xy hxy
    rcases List.mem_map.mp hxy with ⟨e, he, rfl⟩
    exact ⟨(hedges e he).1, (hedges e he).2.1⟩
  · rw [hlset]; exact unmatchedLeft_subset V_L st.matching
  · rw [hrset]; exact unmatchedRight_subset V_R st.matching

/-! ### 2. Unified `attachCopyStep` and Pure Invariant Propagation -/

noncomputable def attachCopyStep {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T_cdf p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (v : CopyVertex ℕ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) :
    ConfigDynamicState L_p2 R ℓ M₀ d b :=
  let b_thr : ℝ := (bRatCfg params cfg : ℝ)
  let rawAns : Option ℕ :=
    match v.side with
    | .left => cs.rightIdx.query hM₀ M_lat A B_rat τ_q b_thr cap_q o (pts v.id)
    | .right => cs.leftIdx.query hM₀ M_lat A B_rat τ_q b_thr cap_q o (pts v.id)
  let cAns := sanitizeConfigAttachAnswer pts params o V cfg cs.st v rawAns
  let lr := syncIndicesOnAttach hM₀ T_cdf p_coord A B_rat τ_d cap_u
    pts o v cAns ω_L ω_R cs.leftIdx cs.rightIdx
  { st := attachStep pts cs.st v cAns, leftIdx := lr.1, rightIdx := lr.2 }

theorem attachCopyStep_left_eq {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T_cdf p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    (cfg : ShellConfig) (vId : ℕ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b)
    (hwfR : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.rightIndexSet cs.rightIdx) :
    attachCopyStep hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
      pts o V cfg ⟨.left, vId⟩ ω_L ω_R cs =
    match cs.rightIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts vId) with
    | some w =>
        { st := attachStep pts cs.st ⟨.left, vId⟩ (some w)
          leftIdx := cs.leftIdx
          rightIdx := cs.rightIdx.removeHandle w }
    | none =>
        { st := attachStep pts cs.st ⟨.left, vId⟩ none
          leftIdx := cs.leftIdx.insertHandle hM₀ T_cdf p_coord A B_rat τ_d cap_u o (pts vId) vId ω_L
          rightIdx := cs.rightIdx } := by
  unfold attachCopyStep
  dsimp only
  have hsan := sanitize_eq_raw hM₀ M_lat params τ_q cap_q pts o hV cfg cs.st ⟨.left, vId⟩ hwfR
  dsimp only [LocalMatchingState.oppositeIndexSet] at hsan
  rw [hsan]
  cases cs.rightIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts vId) <;> rfl

theorem attachCopyStep_right_eq {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T_cdf p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    (cfg : ShellConfig) (vId : ℕ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b)
    (hwfL : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.leftIndexSet cs.leftIdx) :
    attachCopyStep hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
      pts o V cfg ⟨.right, vId⟩ ω_L ω_R cs =
    match cs.leftIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts vId) with
    | some w =>
        { st := attachStep pts cs.st ⟨.right, vId⟩ (some w)
          leftIdx := cs.leftIdx.removeHandle w
          rightIdx := cs.rightIdx }
    | none =>
        { st := attachStep pts cs.st ⟨.right, vId⟩ none
          leftIdx := cs.leftIdx
          rightIdx := cs.rightIdx.insertHandle hM₀ T_cdf p_coord A B_rat τ_d cap_u o (pts vId) vId ω_R } := by
  unfold attachCopyStep
  dsimp only
  have hsan := sanitize_eq_raw hM₀ M_lat params τ_q cap_q pts o hV cfg cs.st ⟨.right, vId⟩ hwfL
  dsimp only [LocalMatchingState.oppositeIndexSet] at hsan
  rw [hsan]
  cases cs.leftIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts vId) <;> rfl

theorem attachCopyStep_left_props {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T_cdf p_coord M_lat : ℕ) (params : LocalScaleParams)
    {A B_rat : ℚ} (hAB : A ^ 2 + B_rat ^ 2 = 1) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    (cfg : ShellConfig) (vId : ℕ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b)
    (hdj : IndexDisjoint cs.st)
    (hv_not_m : vId ∉ (cs.st.matchingList.map MatchingEdge.pair).map Prod.fst)
    (hv_not_i : vId ∉ cs.st.leftIndexSet)
    (hv_ne_o : pts vId ≠ o)
    (hwfL : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.leftIndexSet cs.leftIdx)
    (hwfR : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.rightIndexSet cs.rightIdx) :
    let cs' := attachCopyStep hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
      pts o V cfg ⟨.left, vId⟩ ω_L ω_R cs
    IndexDisjoint cs'.st ∧
    DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs'.st.leftIndexSet cs'.leftIdx ∧
    DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs'.st.rightIndexSet cs'.rightIdx ∧
    cs'.leftIdx.t_ins ≤ cs.leftIdx.t_ins + 1 ∧
    cs'.rightIdx.t_ins = cs.rightIdx.t_ins ∧
    cs'.st.leftIndexSet ⊆ Insert.insert vId cs.st.leftIndexSet ∧
    cs'.st.rightIndexSet ⊆ cs.st.rightIndexSet ∧
    (∀ y, y ∉ (cs.st.matchingList.map MatchingEdge.pair).map Prod.snd →
          y ∉ cs.st.rightIndexSet →
          y ∉ (cs'.st.matchingList.map MatchingEdge.pair).map Prod.snd ∧
          y ∉ cs'.st.rightIndexSet) := by
  intro cs'
  have heq := attachCopyStep_left_eq hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
    pts o hV cfg vId ω_L ω_R cs hwfR
  change _ ∧ _ ∧ _
  rw [show cs' = _ from heq]
  cases hraw : cs.rightIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts vId) with
  | some w =>
      dsimp only
      obtain ⟨hw_mem, _⟩ := dyadicSide_query_sound hM₀ M_lat τ_q (bRatCfg params cfg : ℝ)
        cap_q (pts vId) hwfR hraw
      have hrem := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q)
        hAB (h := (1 / 2 : ℝ)) (by norm_num) (by norm_num) w hwfR
      have hUL' : (attachStep pts cs.st ⟨.left, vId⟩ (some w)).leftIndexSet = cs.st.leftIndexSet := by
        simpa using leftIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ (some w)
      have hUR' : (attachStep pts cs.st ⟨.left, vId⟩ (some w)).rightIndexSet = cs.st.rightIndexSet.erase w := by
        simpa using rightIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ (some w)
      have hpairs' : (attachStep pts cs.st ⟨.left, vId⟩ (some w)).matchingList.map MatchingEdge.pair =
          cs.st.matchingList.map MatchingEdge.pair ++ [(vId, w)] := by
        simp [attachStep, MatchingEdge.pair]
      refine ⟨⟨?_, ?_⟩, ?_, ?_, Nat.le_succ _, hrem.1, ?_, ?_, ?_⟩
      · intro u hu hmem
        rw [hUL'] at hu
        rw [hpairs', List.map_append, List.mem_append, List.map_singleton, List.mem_singleton] at hmem
        rcases hmem with hm0 | rfl
        · exact hdj.1 u hu hm0
        · exact hv_not_i hu
      · intro u hu hmem
        rw [hUR'] at hu
        rcases Finset.mem_erase.mp hu with ⟨hne_w, hu0⟩
        rw [hpairs', List.map_append, List.mem_append, List.map_singleton, List.mem_singleton] at hmem
        rcases hmem with hm0 | rfl
        · exact hdj.2 u hu0 hm0
        · exact hne_w rfl
      · rwa [hUL']
      · rw [hUR']; exact hrem.2.1
      · rw [hUL']; exact Finset.subset_insert _ _
      · rw [hUR']; exact Finset.erase_subset _ _
      · intro y hy_m hy_i
        have hy_ne_w : y ≠ w := fun h => hy_i (h ▸ hw_mem)
        refine ⟨?_, ?_⟩
        · rw [hpairs', List.map_append, List.mem_append, List.map_singleton, List.mem_singleton]
          rintro (hm | rfl)
          · exact hy_m hm
          · exact hy_ne_w rfl
        · rw [hUR']
          exact fun hm => hy_i (Finset.mem_of_mem_erase hm)
  | none =>
      dsimp only
      have hins := dyadicSide_insert_spec hM₀ T_cdf p_coord M_lat A B_rat τ_d τ_q hAB
        (1 / 2 : ℝ) (by norm_num) (by norm_num) cap_u cap_q hv_not_i hv_ne_o ω_L hwfL
      have hUL' : (attachStep pts cs.st ⟨.left, vId⟩ none).leftIndexSet = Insert.insert vId cs.st.leftIndexSet := by
        simpa using leftIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ none
      have hUR' : (attachStep pts cs.st ⟨.left, vId⟩ none).rightIndexSet = cs.st.rightIndexSet := by
        simpa using rightIndexSet_attachStep_eq pts cs.st ⟨.left, vId⟩ none
      have hpairs' : (attachStep pts cs.st ⟨.left, vId⟩ none).matchingList.map MatchingEdge.pair =
          cs.st.matchingList.map MatchingEdge.pair := by
        simp [attachStep]
      refine ⟨⟨?_, ?_⟩, ?_, ?_, le_of_eq hins.1, rfl, ?_, ?_, ?_⟩
      · intro u hu hmem
        rw [hUL'] at hu
        rw [hpairs'] at hmem
        rcases Finset.mem_insert.mp hu with rfl | hu0
        · exact hv_not_m hmem
        · exact hdj.1 u hu0 hmem
      · intro u hu hmem
        rw [hUR'] at hu
        rw [hpairs'] at hmem
        exact hdj.2 u hu hmem
      · rw [hUL']; exact hins.2.1
      · rwa [hUR']
      · rw [hUL']
      · rw [hUR']
      · intro y hy_m hy_i
        rw [hpairs', hUR']
        exact ⟨hy_m, hy_i⟩

theorem attachCopyStep_right_props {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T_cdf p_coord M_lat : ℕ) (params : LocalScaleParams)
    {A B_rat : ℚ} (hAB : A ^ 2 + B_rat ^ 2 = 1) (τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    (cfg : ShellConfig) (vId : ℕ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b)
    (hdj : IndexDisjoint cs.st)
    (hv_not_m : vId ∉ (cs.st.matchingList.map MatchingEdge.pair).map Prod.snd)
    (hv_not_i : vId ∉ cs.st.rightIndexSet)
    (hv_ne_o : pts vId ≠ o)
    (hwfL : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.leftIndexSet cs.leftIdx)
    (hwfR : DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs.st.rightIndexSet cs.rightIdx) :
    let cs' := attachCopyStep hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
      pts o V cfg ⟨.right, vId⟩ ω_L ω_R cs
    IndexDisjoint cs'.st ∧
    DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs'.st.leftIndexSet cs'.leftIdx ∧
    DyadicSideWF hM₀ T_cdf p_coord A B_rat τ_d cap_u pts o cs'.st.rightIndexSet cs'.rightIdx ∧
    cs'.leftIdx.t_ins = cs.leftIdx.t_ins ∧
    cs'.rightIdx.t_ins ≤ cs.rightIdx.t_ins + 1 ∧
    cs'.st.leftIndexSet ⊆ cs.st.leftIndexSet ∧
    cs'.st.rightIndexSet ⊆ Insert.insert vId cs.st.rightIndexSet ∧
    (∀ x, x ∉ (cs.st.matchingList.map MatchingEdge.pair).map Prod.fst →
          x ∉ cs.st.leftIndexSet →
          x ∉ (cs'.st.matchingList.map MatchingEdge.pair).map Prod.fst ∧
          x ∉ cs'.st.leftIndexSet) := by
  intro cs'
  have heq := attachCopyStep_right_eq hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
    pts o hV cfg vId ω_L ω_R cs hwfL
  change _ ∧ _ ∧ _
  rw [show cs' = _ from heq]
  cases hraw : cs.leftIdx.query hM₀ M_lat A B_rat τ_q (bRatCfg params cfg : ℝ) cap_q o (pts vId) with
  | some w =>
      dsimp only
      obtain ⟨hw_mem, _⟩ := dyadicSide_query_sound hM₀ M_lat τ_q (bRatCfg params cfg : ℝ)
        cap_q (pts vId) hwfL hraw
      have hrem := dyadicSide_remove_spec (M_lat := M_lat) (τ_q := τ_q) (cap_q := cap_q)
        hAB (h := (1 / 2 : ℝ)) (by norm_num) (by norm_num) w hwfL
      have hUL' : (attachStep pts cs.st ⟨.right, vId⟩ (some w)).leftIndexSet = cs.st.leftIndexSet.erase w := by
        simpa using leftIndexSet_attachStep_eq pts cs.st ⟨.right, vId⟩ (some w)
      have hUR' : (attachStep pts cs.st ⟨.right, vId⟩ (some w)).rightIndexSet = cs.st.rightIndexSet := by
        simpa using rightIndexSet_attachStep_eq pts cs.st ⟨.right, vId⟩ (some w)
      have hpairs' : (attachStep pts cs.st ⟨.right, vId⟩ (some w)).matchingList.map MatchingEdge.pair =
          cs.st.matchingList.map MatchingEdge.pair ++ [(w, vId)] := by
        simp [attachStep, MatchingEdge.pair]
      refine ⟨⟨?_, ?_⟩, ?_, ?_, hrem.1, Nat.le_succ _, ?_, ?_, ?_⟩
      · intro u hu hmem
        rw [hUL'] at hu
        rcases Finset.mem_erase.mp hu with ⟨hne_w, hu0⟩
        rw [hpairs', List.map_append, List.mem_append, List.map_singleton, List.mem_singleton] at hmem
        rcases hmem with hm0 | rfl
        · exact hdj.1 u hu0 hm0
        · exact hne_w rfl
      · intro u hu hmem
        rw [hUR'] at hu
        rw [hpairs', List.map_append, List.mem_append, List.map_singleton, List.mem_singleton] at hmem
        rcases hmem with hm0 | rfl
        · exact hdj.2 u hu hm0
        · exact hv_not_i hu
      · rw [hUL']; exact hrem.2.1
      · rwa [hUR']
      · rw [hUL']; exact Finset.erase_subset _ _
      · rw [hUR']; exact Finset.subset_insert _ _
      · intro x hx_m hx_i
        have hx_ne_w : x ≠ w := fun h => hx_i (h ▸ hw_mem)
        refine ⟨?_, ?_⟩
        · rw [hpairs', List.map_append, List.mem_append, List.map_singleton, List.mem_singleton]
          rintro (hm | rfl)
          · exact hx_m hm
          · exact hx_ne_w rfl
        · rw [hUL']
          exact fun hm => hx_i (Finset.mem_of_mem_erase hm)
  | none =>
      dsimp only
      have hins := dyadicSide_insert_spec hM₀ T_cdf p_coord M_lat A B_rat τ_d τ_q hAB
        (1 / 2 : ℝ) (by norm_num) (by norm_num) cap_u cap_q hv_not_i hv_ne_o ω_R hwfR
      have hUL' : (attachStep pts cs.st ⟨.right, vId⟩ none).leftIndexSet = cs.st.leftIndexSet := by
        simpa using leftIndexSet_attachStep_eq pts cs.st ⟨.right, vId⟩ none
      have hUR' : (attachStep pts cs.st ⟨.right, vId⟩ none).rightIndexSet = Insert.insert vId cs.st.rightIndexSet := by
        simpa using rightIndexSet_attachStep_eq pts cs.st ⟨.right, vId⟩ none
      have hpairs' : (attachStep pts cs.st ⟨.right, vId⟩ none).matchingList.map MatchingEdge.pair =
          cs.st.matchingList.map MatchingEdge.pair := by
        simp [attachStep]
      refine ⟨⟨?_, ?_⟩, ?_, ?_, rfl, le_of_eq hins.1, ?_, ?_, ?_⟩
      · intro u hu hmem
        rw [hUL'] at hu
        rw [hpairs'] at hmem
        exact hdj.1 u hu hmem
      · intro u hu hmem
        rw [hUR'] at hu
        rw [hpairs'] at hmem
        rcases Finset.mem_insert.mp hu with rfl | hu0
        · exact hv_not_m hmem
        · exact hdj.2 u hu0 hmem
      · rwa [hUL']
      · rw [hUR']; exact hins.2.1
      · rw [hUL']
      · rw [hUR']
      · intro x hx_m hx_i
        rw [hpairs', hUL']
        exact ⟨hx_m, hx_i⟩

/-! ### 3. Pure Decomposition of `insertOriginal` and `deleteOriginal` -/

theorem insertOriginal_eq_steps {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T_cdf p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig) (p : ℕ)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (cs : ConfigDynamicState L_p2 R ℓ M₀ d b) :
    open Classical in
    let cs₁ :=
      if hasApplicableLeftCopy params.m0 o V cfg.j (pts p) then
        attachCopyStep hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
          pts o V cfg ⟨.left, p⟩ ω_L ω_R cs
      else cs
    cs.insertOriginal hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
      pts o V cfg p ω_L ω_R =
    (if hasApplicableRightCopy params.m0 o V params.K cfg.k (pts p) then
       attachCopyStep hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
         pts o V cfg ⟨.right, p⟩ ω_L ω_R cs₁
     else cs₁) := by
  classical
  unfold ConfigDynamicState.insertOriginal attachCopyStep
  dsimp only
  split_ifs <;> rfl

private lemma filter_pred_len_le_one {α : Type*} {f : α → ℕ} {l : List α}
    (hnd : (l.map f).Nodup) (p : α → Bool) (target : ℕ)
    (hp : ∀ x, p x = true → f x = target) :
    (l.filter p).length ≤ 1 := by
  induction l with
  | nil => simp
  | cons a tl ih =>
      rcases List.nodup_cons.mp hnd with ⟨hnot, hnd_tl⟩
      simp only [List.filter_cons]
      split_ifs with hpa
      · simp only [List.length_cons]
        have hnil : tl.filter p = [] := by
          rw [List.filter_eq_nil_iff]
          intro b hb hpb
          apply hnot
          rw [hp a hpa, ← hp b hpb]
          exact List.mem_map_of_mem hb
        rw [hnil]; simp
      · exact ih hnd_tl

theorem survivingFormerPartners_eq_rP_lP {d : ℕ}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ℕ}
    {st : LocalMatchingState ℕ} (hwf : st.WellFormed pts V_L V_R) (p : ℕ) :
    let rP := (st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
      (fun e => CopyVertex.mk .right e.right)
    let lP := (st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
      (fun e => CopyVertex.mk .left e.left)
    survivingFormerPartners st p = rP ++ lP ∧
    rP.length ≤ 1 ∧
    lP.length ≤ 1 ∧
    (∀ u ∈ rP, u.side = .right ∧ u.id ∈ V_R.erase p) ∧
    (∀ u ∈ lP, u.side = .left ∧ u.id ∈ V_L.erase p) := by
  rcases hwf with ⟨hndL, hndR, hedges, _⟩
  let rP := (st.matchingList.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
    (fun e => CopyVertex.mk .right e.right)
  let lP := (st.matchingList.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
    (fun e => CopyVertex.mk .left e.left)
  have hlenR : rP.length ≤ 1 := by
    rw [List.length_map]
    exact filter_pred_len_le_one hndL _ p (fun x hx => (of_decide_eq_true hx).1)
  have hlenL : lP.length ≤ 1 := by
    rw [List.length_map]
    exact filter_pred_len_le_one hndR _ p (fun x hx => (of_decide_eq_true hx).1)
  have hr_props : ∀ u ∈ rP, u.side = .right ∧ u.id ∈ V_R.erase p := by
    intro u hu
    rcases List.mem_map.mp hu with ⟨e, he, rfl⟩
    rcases List.mem_filter.mp he with ⟨he_mem, hdec⟩
    rcases of_decide_eq_true hdec with ⟨_, hne⟩
    exact ⟨rfl, Finset.mem_erase.mpr ⟨hne, (hedges e he_mem).2.1⟩⟩
  have hl_props : ∀ u ∈ lP, u.side = .left ∧ u.id ∈ V_L.erase p := by
    intro u hu
    rcases List.mem_map.mp hu with ⟨e, he, rfl⟩
    rcases List.mem_filter.mp he with ⟨he_mem, hdec⟩
    rcases of_decide_eq_true hdec with ⟨_, hne⟩
    exact ⟨rfl, Finset.mem_erase.mpr ⟨hne, (hedges e he_mem).1⟩⟩
  have hnd_rP : rP.Nodup := by
    cases hr : rP with
    | nil => exact List.nodup_nil
    | cons a tl =>
        rw [hr] at hlenR
        have htl : tl = [] := List.eq_nil_of_length_eq_zero (by simpa using hlenR)
        subst htl; exact List.nodup_singleton a
  have hnd_lP : lP.Nodup := by
    cases hl : lP with
    | nil => exact List.nodup_nil
    | cons a tl =>
        rw [hl] at hlenL
        have htl : tl = [] := List.eq_nil_of_length_eq_zero (by simpa using hlenL)
        subst htl; exact List.nodup_singleton a
  have hnd_app : (rP ++ lP).Nodup := by
    refine List.nodup_append.mpr ⟨hnd_rP, hnd_lP, fun a ha b hb heq => ?_⟩
    have hsa := (hr_props a ha).1
    have hsb := (hl_props b hb).1
    rw [heq, hsb] at hsa
    cases hsa
  have heq_dedup : survivingFormerPartners st p = rP ++ lP := by
    have hdedup_inst : ∀ (xs : List (CopyVertex ℕ)) (inst : DecidableEq (CopyVertex ℕ)),
        @List.dedup (CopyVertex ℕ) inst xs = xs.dedup := by
      intro xs inst
      rw [Subsingleton.elim inst (inferInstance : DecidableEq (CopyVertex ℕ))]
    unfold survivingFormerPartners
    dsimp only
    rw [hdedup_inst]
    convert List.Nodup.dedup hnd_app using 2
    congr 1
    · congr 1; apply List.filter_congr; intro e _; exact decide_eq_decide.mpr Iff.rfl
    · congr 1; apply List.filter_congr; intro e _; exact decide_eq_decide.mpr Iff.rfl
  exact ⟨heq_dedup, hlenR, hlenL, hr_props, hl_props⟩

theorem rP_eq_of_mem_pair {es : List (MatchingEdge ℕ)}
    (hndL : ((es.map MatchingEdge.pair).map Prod.fst).Nodup)
    {p y₀ : ℕ} (hmem : (p, y₀) ∈ es.map MatchingEdge.pair) :
    (es.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
      (fun e => CopyVertex.mk .right e.right) =
    if y₀ = p then [] else [⟨.right, y₀⟩] := by
  induction es with
  | nil => simp at hmem
  | cons e tl ih =>
      simp only [List.map_cons, List.nodup_cons, List.mem_cons] at hndL hmem
      rcases hndL with ⟨hnot_tl, hnd_tl⟩
      rcases hmem with heq | hmem_tl
      · have hel : e.left = p := (congrArg Prod.fst heq).symm
        have her : e.right = y₀ := (congrArg Prod.snd heq).symm
        have htl_nil : tl.filter (fun e' => decide (e'.left = p ∧ e'.right ≠ p)) = [] := by
          rw [List.filter_eq_nil_iff]
          intro e' he' hdec
          have h1 := (of_decide_eq_true hdec).1
          apply hnot_tl
          rw [show e.pair.1 = p from hel, ← show e'.pair.1 = p from h1]
          exact List.mem_map_of_mem (List.mem_map_of_mem he')
        simp only [List.filter_cons, hel, her, true_and]
        by_cases hy : y₀ = p
        · subst hy
          rw [if_neg (by simp), if_pos rfl, htl_nil]
          rfl
        · rw [if_pos (decide_eq_true hy), if_neg hy, htl_nil]
          simp [her]
      · have hne_e : e.left ≠ p := by
          intro h1
          apply hnot_tl
          rw [show e.pair.1 = p from h1]
          exact List.mem_map_of_mem hmem_tl
        simp only [List.filter_cons, hne_e, false_and, decide_false, Bool.false_eq_true, ↓reduceIte]
        exact ih hnd_tl hmem_tl

theorem rP_eq_nil_of_forall_not_pair {es : List (MatchingEdge ℕ)} {p : ℕ}
    (hno : ∀ y, (p, y) ∉ es.map MatchingEdge.pair) :
    (es.filter (fun e => decide (e.left = p ∧ e.right ≠ p))).map
      (fun e => CopyVertex.mk .right e.right) = [] := by
  rw [List.map_eq_nil_iff, List.filter_eq_nil_iff]
  intro e he hdec
  have h1 := (of_decide_eq_true hdec).1
  apply hno e.right
  rw [← h1]
  exact List.mem_map_of_mem he

theorem lP_eq_of_mem_pair1 {es : List (MatchingEdge ℕ)}
    (hndL : ((es.map MatchingEdge.pair).map Prod.fst).Nodup)
    (hndR : ((es.map MatchingEdge.pair).map Prod.snd).Nodup)
    {p x₀ : ℕ}
    (hmem1 : (x₀, p) ∈ (es.map MatchingEdge.pair).filter (fun xy => decide (xy.1 ≠ p))) :
    x₀ ≠ p ∧
    (x₀, p) ∈ es.map MatchingEdge.pair ∧
    (es.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
      (fun e => CopyVertex.mk .left e.left) = [⟨.left, x₀⟩] ∧
    ((es.map MatchingEdge.pair).filter (fun xy => decide (xy.1 ≠ p))).filter
      (fun xy => decide (xy.1 ≠ x₀)) =
    (es.filter (fun e => decide (e.left ≠ p ∧ e.right ≠ p))).map MatchingEdge.pair := by
  rcases List.mem_filter.mp hmem1 with ⟨hmem, hdec⟩
  have hx_ne : x₀ ≠ p := of_decide_eq_true hdec
  clear hmem1 hdec
  refine ⟨hx_ne, hmem, ?_, ?_⟩
  · induction es with
    | nil => simp at hmem
    | cons e tl ih =>
        simp only [List.map_cons, List.nodup_cons, List.mem_cons] at hndL hndR hmem
        rcases hndL with ⟨_, hndL_tl⟩
        rcases hndR with ⟨hnotR_tl, hndR_tl⟩
        rcases hmem with heq | hmem_tl
        · have hel : e.left = x₀ := (congrArg Prod.fst heq).symm
          have her : e.right = p := (congrArg Prod.snd heq).symm
          have htl_nil : tl.filter (fun e' => decide (e'.right = p ∧ e'.left ≠ p)) = [] := by
            rw [List.filter_eq_nil_iff]
            intro e' he' hdec'
            have h1 := (of_decide_eq_true hdec').1
            apply hnotR_tl
            rw [show e.pair.2 = p from her, ← show e'.pair.2 = p from h1]
            exact List.mem_map_of_mem (List.mem_map_of_mem he')
          simp only [List.filter_cons, hel, her, true_and]
          rw [if_pos (decide_eq_true hx_ne), htl_nil]
          simp [hel]
        · have hne_e : e.right ≠ p := by
            intro h1
            apply hnotR_tl
            rw [show e.pair.2 = p from h1]
            exact List.mem_map_of_mem hmem_tl
          simp only [List.filter_cons, hne_e, false_and, decide_false, Bool.false_eq_true, ↓reduceIte]
          exact ih hndL_tl hndR_tl hmem_tl
  · have hiff : ∀ e ∈ es, (e.left ≠ p ∧ e.left ≠ x₀) ↔ (e.left ≠ p ∧ e.right ≠ p) := by
      intro e he
      have hep : (e.left, e.right) ∈ es.map MatchingEdge.pair := List.mem_map_of_mem he
      constructor
      · rintro ⟨h1, h2⟩
        refine ⟨h1, fun hr => h2 ?_⟩
        exact pairs_eq_of_snd_nodup hndR (hr ▸ hep) hmem
      · rintro ⟨h1, h2⟩
        refine ⟨h1, fun hl => h2 ?_⟩
        exact pairs_eq_of_fst_nodup hndL (hl ▸ hep) hmem
    clear hmem hx_ne hndL hndR
    induction es with
    | nil => rfl
    | cons e tl ih =>
        have he_iff := hiff e List.mem_cons_self
        have htl_iff : ∀ e' ∈ tl, (e'.left ≠ p ∧ e'.left ≠ x₀) ↔ (e'.left ≠ p ∧ e'.right ≠ p) :=
          fun e' he' => hiff e' (List.mem_cons_of_mem _ he')
        simp only [List.map_cons, List.filter_cons]
        dsimp only [MatchingEdge.pair]
        by_cases hlp : e.left ≠ p
        · rw [if_pos (decide_eq_true hlp), List.filter_cons]
          dsimp only
          by_cases hlx : e.left ≠ x₀
          · have hrp : e.right ≠ p := (he_iff.mp ⟨hlp, hlx⟩).2
            rw [if_pos (decide_eq_true hlx), if_pos (decide_eq_true ⟨hlp, hrp⟩),
                List.map_cons, ih htl_iff]
            rfl
          · have hnot : ¬ (e.left ≠ p ∧ e.right ≠ p) := fun h => hlx (he_iff.mpr h).2
            rw [if_neg (by simpa using hlx), if_neg (decide_eq_false hnot ▸ Bool.false_ne_true),
                ih htl_iff]
        · have hnot : ¬ (e.left ≠ p ∧ e.right ≠ p) := fun h => hlp h.1
          rw [if_neg (by simpa using hlp), if_neg (decide_eq_false hnot ▸ Bool.false_ne_true),
              ih htl_iff]

theorem lP_eq_nil_of_forall_not_pair1 {es : List (MatchingEdge ℕ)} {p : ℕ}
    (hno1 : ∀ x, (x, p) ∉ (es.map MatchingEdge.pair).filter (fun xy => decide (xy.1 ≠ p))) :
    (es.filter (fun e => decide (e.right = p ∧ e.left ≠ p))).map
      (fun e => CopyVertex.mk .left e.left) = [] ∧
    (es.map MatchingEdge.pair).filter (fun xy => decide (xy.1 ≠ p)) =
    (es.filter (fun e => decide (e.left ≠ p ∧ e.right ≠ p))).map MatchingEdge.pair := by
  refine ⟨?_, ?_⟩
  · rw [List.map_eq_nil_iff, List.filter_eq_nil_iff]
    intro e he hdec
    rcases of_decide_eq_true hdec with ⟨hr, hl⟩
    apply hno1 e.left
    exact List.mem_filter.mpr ⟨hr ▸ List.mem_map_of_mem he, decide_eq_true hl⟩
  · induction es with
    | nil => rfl
    | cons e tl ih =>
        have hno_tl : ∀ x, (x, p) ∉ (tl.map MatchingEdge.pair).filter (fun xy => decide (xy.1 ≠ p)) := by
          intro x hx
          apply hno1 x
          rcases List.mem_filter.mp hx with ⟨hm, hd⟩
          exact List.mem_filter.mpr ⟨List.mem_cons_of_mem _ hm, hd⟩
        simp only [List.map_cons, List.filter_cons]
        dsimp only [MatchingEdge.pair]
        by_cases hlp : e.left ≠ p
        · have hrp : e.right ≠ p := by
            intro hr
            apply hno1 e.left
            exact List.mem_filter.mpr ⟨List.mem_cons.mpr (Or.inl (by simp [MatchingEdge.pair, hr])),
              decide_eq_true hlp⟩
          rw [if_pos (decide_eq_true hlp), if_pos (decide_eq_true ⟨hlp, hrp⟩),
              List.map_cons, ih hno_tl]
          rfl
        · have hnot : ¬ (e.left ≠ p ∧ e.right ≠ p) := fun h => hlp h.1
          rw [if_neg (by simpa using hlp), if_neg (decide_eq_false hnot ▸ Bool.false_ne_true),
              ih hno_tl]

theorem removeCopies_partner_right_absent {d : ℕ}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ℕ}
    {st : LocalMatchingState ℕ} (hwf : st.WellFormed pts V_L V_R)
    {p y₀ : ℕ} (hmem : (p, y₀) ∈ st.matchingList.map MatchingEdge.pair) :
    y₀ ∉ ((removeCopiesFromState st p).matchingList.map MatchingEdge.pair).map Prod.snd ∧
    y₀ ∉ (removeCopiesFromState st p).rightIndexSet := by
  have hdj := IndexDisjoint.of_wellFormed hwf
  rcases hwf with ⟨_, hndR, _⟩
  rw [pairs_snd_eq_right]
  refine ⟨?_, ?_⟩
  · intro hm
    rcases List.mem_map.mp hm with ⟨e, he, her⟩
    unfold removeCopiesFromState at he
    rcases List.mem_filter.mp he with ⟨he0, hdec⟩
    simp only [decide_eq_true_eq] at hdec
    have hlp : e.left ≠ p := hdec.1
    have hep : (e.left, y₀) ∈ st.matchingList.map MatchingEdge.pair :=
      her ▸ List.mem_map_of_mem he0
    have hndR' : ((st.matchingList.map MatchingEdge.pair).map Prod.snd).Nodup := by
      rwa [pairs_snd_eq_right]
    exact hlp (pairs_eq_of_snd_nodup hndR' hep hmem)
  · rw [rightIndexSet_removeCopies_eq]
    intro hm
    exact hdj.2 y₀ (Finset.mem_of_mem_erase hm) (List.mem_map_of_mem hmem)

theorem removeCopies_partner_left_absent {d : ℕ}
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {V_L V_R : Finset ℕ}
    {st : LocalMatchingState ℕ} (hwf : st.WellFormed pts V_L V_R)
    {p x₀ : ℕ} (hmem : (x₀, p) ∈ st.matchingList.map MatchingEdge.pair) :
    x₀ ∉ ((removeCopiesFromState st p).matchingList.map MatchingEdge.pair).map Prod.fst ∧
    x₀ ∉ (removeCopiesFromState st p).leftIndexSet := by
  have hdj := IndexDisjoint.of_wellFormed hwf
  rcases hwf with ⟨hndL, _⟩
  rw [pairs_fst_eq_left]
  refine ⟨?_, ?_⟩
  · intro hm
    rcases List.mem_map.mp hm with ⟨e, he, hel⟩
    unfold removeCopiesFromState at he
    rcases List.mem_filter.mp he with ⟨he0, hdec⟩
    simp only [decide_eq_true_eq] at hdec
    have hrp : e.right ≠ p := hdec.2
    have hep : (x₀, e.right) ∈ st.matchingList.map MatchingEdge.pair :=
      hel ▸ List.mem_map_of_mem he0
    have hndL' : ((st.matchingList.map MatchingEdge.pair).map Prod.fst).Nodup := by
      rwa [pairs_fst_eq_left]
    exact hrp (pairs_eq_of_fst_nodup hndL' hep hmem)
  · rw [leftIndexSet_removeCopies_eq]
    intro hm
    exact hdj.1 x₀ (Finset.mem_of_mem_erase hm) (List.mem_map_of_mem hmem)

theorem coupledRepairList_fst_append {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T_cdf p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (xs ys : List (CopyVertex ℕ)) (cur : ConfigDynamicState L_p2 R ℓ M₀ d b) :
    (coupledRepairList hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
      pts o V cfg ω_L ω_R (xs ++ ys) cur).1 =
    (coupledRepairList hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
      pts o V cfg ω_L ω_R ys
      (coupledRepairList hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
        pts o V cfg ω_L ω_R xs cur).1).1 := by
  induction xs generalizing cur with
  | nil => rfl
  | cons u us ih =>
      dsimp only [List.cons_append, coupledRepairList]
      split_ifs with hc
      · exact ih cur
      · exact ih _

theorem coupledRepairList_singleton_of_not {L_p2 R ℓ M₀ d b : ℕ}
    (hM₀ : 1 ≤ M₀) (T_cdf p_coord M_lat : ℕ) (params : LocalScaleParams)
    (A B_rat τ_d τ_q : ℚ) (cap_u cap_q : ℕ)
    (pts : ℕ → EuclideanSpace ℝ (Fin d)) (o : EuclideanSpace ℝ (Fin d)) (V : ℝ)
    (cfg : ShellConfig)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (u : CopyVertex ℕ) (cur : ConfigDynamicState L_p2 R ℓ M₀ d b)
    (hnot : ¬ (cur.st.isCopyMatched u ∨ cur.st.isCopyInIndex u)) :
    (coupledRepairList hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
      pts o V cfg ω_L ω_R [u] cur).1 =
    attachCopyStep hM₀ T_cdf p_coord M_lat params A B_rat τ_d τ_q cap_u cap_q
      pts o V cfg u ω_L ω_R cur := by
  dsimp only [coupledRepairList]
  rw [if_neg hnot]
  rfl

theorem removeCopiesFromState_matchingList_eq (st : LocalMatchingState ℕ) (p : ℕ) :
    (removeCopiesFromState st p).matchingList =
    st.matchingList.filter (fun e => decide (e.left ≠ p ∧ e.right ≠ p)) := by
  unfold removeCopiesFromState
  dsimp only
  apply List.filter_congr
  intro e _
  exact decide_eq_decide.mpr Iff.rfl

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
