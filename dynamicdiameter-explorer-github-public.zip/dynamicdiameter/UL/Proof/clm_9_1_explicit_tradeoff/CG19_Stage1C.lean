import UL.Proof.clm_9_1_explicit_tradeoff.CG19_Stage1C1
set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG19

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c

def buildLiveUpdateStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 15)
          (.readHeap engMetaTbl (.add (.readHeap engScrTbl (.lit 21)) (.lit 7))))
  (.seq (.writeWordHeap engScrTbl (.lit 16)
          (.mul (.add (.lit (((cp.D_max + cp.D_max * cp.D_max : ℕ) : ℤ)))
                      (.readHeap engScrTbl (.lit 20)))
                (.lit (cp.B_op : ℤ))))
        (.ite (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))
          (.seq (ops.insertMatStmt 15 2 16) (ops.bumpAgeStmt 15))
          (.seq (ops.containsNodeArrStmt false 15 2 17)
                (.ite (.intEq (.readHeap engScrTbl (.lit 17)) (.lit 1))
                  (.seq (ops.deleteMatStmt 15 2 16) (ops.bumpAgeStmt 15))
                  (.seq (.writeWordHeap engScrTbl (.lit 30)
                          (.add (.readHeap engScrTbl (.lit 21)) (.lit 6)))
                  (.seq (.writeWordHeap engScrTbl (.lit 31)
                          (.mul (.add (.lit 4) (.mul (.lit 4) (.readHeap engScrTbl (.lit 20))))
                                (.lit (S_stride cp : ℤ))))
                  (.seq (.writeWordHeap engScrTbl (.lit 32)
                          (.mul (.add (.lit 5) (.mul (.lit 4) (.readHeap engScrTbl (.lit 20))))
                                (.lit (S_stride cp : ℤ))))
                  (.seq (sparseInsertFreshStmt 30 31 32 2)
                        (ops.bumpAgeStmt 15)))))))))

theorem zeroRand_buildLiveUpdateStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (buildLiveUpdateStmt ops) :=
  .seq (.writeWordHeap _ _ _)
  (.seq (.writeWordHeap _ _ _)
    (.ite (.seq (ops.zeroRand_insertMat 15 2 16) (ops.zeroRand_bumpAge 15))
          (.seq (ops.zeroRand_containsNodeArr false 15 2 17)
            (.ite (.seq (ops.zeroRand_deleteMat 15 2 16) (ops.zeroRand_bumpAge 15))
              (.seq (.writeWordHeap _ _ _)
              (.seq (.writeWordHeap _ _ _)
              (.seq (.writeWordHeap _ _ _)
              (.seq (zeroRand_sparseInsertFreshStmt _ _ _ _)
                    (ops.zeroRand_bumpAge 15)))))))))

def C_buildLive {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  ops.C_read + max ops.C_ins (ops.C_del + 180) + ops.C_bump + 80

theorem exec_buildLiveUpdateStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    {actH T_end : Finset ℕ} {pts pts' : ℕ → EuclideanSpace ℝ (Fin d)}
    {gt : GhostTracker d}
    (r : Fin cp.D_max) (bs : BuildState cp) (cSlot : ℕ)
    {isIns : Bool} {h_op : ℕ} {bits : Fin cp.B_STEP → Bool}
    (hcSlot_lt : cSlot < M_slots cp)
    (hhop_lt : h_op < cp.n)
    (hT_sub : T_end ⊆ actH)
    (hact_lt : ∀ x ∈ actH, x < cp.n)
    (hcur_age_le : bs.curNode.nd.age ≤ bs.curNode.nd.birthSize)
    (hbs_inv : BuildStateInv cp pts gt T_end bs)
    (hins_case : isIns = true → h_op ∉ actH ∧ ∀ x ∈ actH, pts' x = pts x)
    (hdel_case : isIns = false → h_op ∈ T_end ∧ pts' = pts)
    (hpts_mem : ∀ x ∈ insert h_op actH, ∀ c : Fin d,
      rRead m₀ ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts' x) c)
    (hcoins : MemHasStepCoins cp bits m₀)
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hdsp₀ : EncSparseSet cp.n (jobMetaBase cp r.val + 6) (delSnapElemOff cp r.val)
      (delSnapPosOff cp r.val) bs.delSnapArr m₀)
    (hcslot_rd : wRead m₀ engMetaTbl (jobMetaBase cp r.val + 7) = (cSlot : ℤ))
    (hcenc₀ : ops.EncNode bs.curNode cSlot m₀)
    (hr1 : wRead m₀ engScrTbl 1 = (if isIns then 1 else 0))
    (hr2 : wRead m₀ engScrTbl 2 = (h_op : ℤ))
    (hr20 : wRead m₀ engScrTbl 20 = (r.val : ℤ))
    (hr21 : wRead m₀ engScrTbl 21 = jobMetaBase cp r.val) :
    let ω₁ := (bitsToStepCoinBundle cp bits).1
    let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
    let bs₁ :=
      if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ω₁ curIdx)
      else bs.liveDelete cp pts' h_op (getS1Seed cp ω₁ curIdx)
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (buildLiveUpdateStmt ops) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        EncSparseSet cp.n (jobMetaBase cp r.val + 6) (delSnapElemOff cp r.val)
          (delSnapPosOff cp r.val) bs₁.delSnapArr m₁ ∧
        ops.EncNode bs₁.curNode cSlot m₁ ∧
        (∀ mn' s', s' < M_slots cp → s' ≠ cSlot → ops.EncNode mn' s' m₀ → ops.EncNode mn' s' m₁) ∧
        (∀ t < 9, t ≠ engMetaTbl → t ≠ engArrTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ jobMetaBase cp r.val + 6 → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, (i < delSnapElemOff cp r.val ∨ delSnapPosOff cp r.val + (S_stride cp : ℤ) ≤ i) →
          wRead m₁ engArrTbl i = wRead m₀ engArrTbl i) ∧
        (∀ i, (i < 15 ∨ (20 ≤ i ∧ i < 30)) → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t < 3, ∀ i, rRead m₁ t i = rRead m₀ t i))
      (C_buildLive ops) := by
  have hTW := ops.hTW
  have hBW_s := ops_hBW_scr64 ops
  have hBW_m := ops.hBW_meta
  have hBW_a := ops.hBW_arr
  have hr_lt := r.isLt
  have hS_ge_n : cp.n < S_stride cp := by unfold S_stride; omega
  rcases hbs_inv with ⟨_, _, hins_le_snap, hbsz_eq, hbsz_n, _, _, _, hcur_union, _, hhist_le, htins, hwf_cur⟩
  have hcur_sub_T : bs.curNode.nd.curSet ⊆ T_end := by
    intro x hx; rw [← hcur_union]; exact Finset.mem_union_left _ hx
  have hcur_sub : bs.curNode.nd.curSet ⊆ actH := hcur_sub_T.trans hT_sub
  have hcur_lt : ∀ x ∈ bs.curNode.nd.curSet, x < cp.n := fun x hx => hact_lt x (hcur_sub hx)
  have heq_pts : ∀ x ∈ bs.curNode.nd.curSet, pts' x = pts x := by
    intro x hx
    cases his : isIns
    · rw [(hdel_case his).2]
    · exact (hins_case his).2 x (hcur_sub hx)
  have hwf_pts' : ManagedNodeWF cp.hM₀ cp.T_cdf cp.p_coord params cp.specs cp.τ_d cp.cap_u pts' bs.curNode :=
    managedNodeWF_pts_congr heq_pts hwf_cur
  have hcap_t : (bs.insCur + bs.curNode.nd.age) + 1 < 2 ^ cp.L_p2 := by
    have := cp.hL_p2; omega
  let curIdx := cp.D_max + cp.D_max * cp.D_max + r.val
  have hcurIdx_lt : curIdx < cp.N_op_s1 := by
    dsimp [curIdx, ChainParams.N_op_s1]; omega
  rcases memHasStepCoins_stage1 cp bits m₀ hcoins hcurIdx_lt with ⟨seedBits, hseed_eq, hcoin_ub, hcoin_rd⟩
  unfold buildLiveUpdateStmt C_buildLive
  refine ExecDet.seq' (ops.C_read + max ops.C_ins (ops.C_del + 180) + ops.C_bump + 60)
    (ExecDet.wWrite (C := 16) inp engScrTbl (.lit 15)
      (.readHeap engMetaTbl (.add (.readHeap engScrTbl (.lit 21)) (.lit 7)))
      15 (cSlot : ℤ) hfp₀ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change wRead m₀ engMetaTbl (wRead m₀ engScrTbl 21 + 7) = _
          rw [hr21, hcslot_rd])
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mA₁ hmA₁ hfpA₁; subst hmA₁
  refine ExecDet.seq' (ops.C_read + max ops.C_ins (ops.C_del + 180) + ops.C_bump + 40)
    (ExecDet.wWrite (C := 18) inp engScrTbl (.lit 16)
      (.mul (.add (.lit (((cp.D_max + cp.D_max * cp.D_max : ℕ) : ℤ))) (.readHeap engScrTbl (.lit 20)))
            (.lit (cp.B_op : ℤ)))
      16 ((curIdx * cp.B_op : ℕ) : ℤ) hfpA₁ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
      (by simp only [evalIntExpr]
          change (((cp.D_max + cp.D_max * cp.D_max : ℕ) : ℤ) + wRead _ engScrTbl 20) * (cp.B_op : ℤ) = _
          rw [wRead_wWrite_of_ne m₀ _ (Or.inr (by decide)), hr20]
          dsimp [curIdx]; try (push_cast; try ring))
      (by simp [intExprOps]) rfl) (by omega) ?_
  intro mA₂ hmA₂ hfpA; subst hmA₂
  set mA := H3a.wWrite (H3a.wWrite m₀ engScrTbl 15 (cSlot : ℤ))
    engScrTbl 16 ((curIdx * cp.B_op : ℕ) : ℤ)
  have hwA_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead mA t i = wRead m₀ t i := by
    intro t ht i; simp only [mA]
    rw [wRead_wWrite_of_ne _ _ (Or.inl ht), wRead_wWrite_of_ne _ _ (Or.inl ht)]
  have hwA_scr : ∀ i, i ≠ 15 → i ≠ 16 → wRead mA engScrTbl i = wRead m₀ engScrTbl i := by
    intro i h15 h16; simp only [mA]
    rw [wRead_wWrite_of_ne _ _ (Or.inr h16), wRead_wWrite_of_ne _ _ (Or.inr h15)]
  have hrA : ∀ t i, rRead mA t i = rRead m₀ t i := fun _ _ => by simp [mA, rRead_wWrite]
  have hsrA : ops.SlotsReady mA :=
    ops.slotsReady_ext m₀ mA hsr₀
      (fun t ht9 _ i => hwA_ne8 t (by dsimp [engScrTbl]; omega) i)
      (fun _ _ _ _ => hrA _ _)
  have hndA : ∀ mn' s', ops.EncNode mn' s' m₀ → ops.EncNode mn' s' mA :=
    fun mn' s' he => ops.encNode_ext mn' s' m₀ mA he
      (fun t ht9 _ i => hwA_ne8 t (by dsimp [engScrTbl]; omega) i)
      (fun _ _ _ _ => hrA _ _) (fun _ _ _ _ => hrA ptsRTbl _)
  have hr15A : wRead mA engScrTbl 15 = (cSlot : ℤ) := by
    simp only [mA]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self]
  have hr16A : wRead mA engScrTbl 16 = ((curIdx * cp.B_op : ℕ) : ℤ) := by simp [mA]
  have hr2A : wRead mA engScrTbl 2 = (h_op : ℤ) := (hwA_scr 2 (by decide) (by decide)).trans hr2
  have hcond_ins : (evalArithCond inp 0 mA (.intEq (.readHeap engScrTbl (.lit 1)) (.lit 1))).1 = isIns := by
    simp only [evalArithCond, evalIntExpr]
    change decide (wRead mA engScrTbl 1 = 1) = isIns
    rw [(hwA_scr 1 (by decide) (by decide)).trans hr1]; cases isIns <;> rfl
  refine ExecDet.ite' (C_c := 8) (C_b := ops.C_read + max ops.C_ins (ops.C_del + 180) + ops.C_bump + 30)
    _ _ _ hcond_ins (by simp [condExprOps, intExprOps]) (fun his_t => ?_) (fun his_f => ?_)
  · have hp_not : h_op ∉ bs.curNode.nd.curSet := fun hm => (hins_case his_t).1 (hcur_sub hm)
    refine ExecDet.seq' ops.C_bump
      (ops.insertMat_spec inp mA pts' bs.curNode cSlot h_op (curIdx * cp.B_op)
        (bs.insCur + bs.curNode.nd.age) seedBits 15 2 16
        hcSlot_lt hhop_lt hp_not hcur_lt (by omega) htins hcap_t hwf_pts' hcoin_ub
        (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
        hfpA hsrA (hndA _ _ hcenc₀) hr15A hr2A hr16A
        (fun x hx c => by
          rw [hrA]
          rcases Finset.mem_insert.mp hx with rfl | hxm
          · exact hpts_mem x (Finset.mem_insert_self _ _) c
          · exact hpts_mem x (Finset.mem_insert_of_mem (hcur_sub hxm)) c)
        (fun k => (hwA_ne8 coinTbl (by decide) _).trans (hcoin_rd k)))
      (by omega) ?_
    intro mB ⟨hsrB, hencB, hndB, hwB, hrB⟩ hfpB
    refine (ops.bumpAge_spec inp mB _ cSlot 15 hcSlot_lt
      (by dsimp [ManagedNode.insertMat, NodeInst.insertMat]; omega)
      (by omega) (by omega) hfpB hsrB hencB
      ((hwB engScrTbl (by decide) 15).trans hr15A)).mono ?_ (by omega)
    intro mC ⟨hsrC, hencC, hndC, hwC, hrC⟩ _
    have hbs1_cur : (if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)
        else bs.liveDelete cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)).curNode =
        (bs.curNode.insertMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
          cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op (bitsToOpSeedEquiv cp seedBits)).bumpAge := by
      rw [if_pos his_t]; unfold BuildState.liveInsert; rw [hseed_eq]
    have hbs1_del : (if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)
        else bs.liveDelete cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)).delSnapArr =
        bs.delSnapArr := by
      rw [if_pos his_t]; rfl
    have hw_lt9_ne8 : ∀ t < 9, t ≠ engScrTbl → ∀ i, wRead mC t i = wRead m₀ t i :=
      fun t ht9 ht8 i => (hwC t ht9 i).trans ((hwB t ht9 i).trans (hwA_ne8 t ht8 i))
    refine ⟨hsrC,
      (by
        (try dsimp only); rw [hbs1_del]
        exact hdsp₀.ext (hw_lt9_ne8 engMetaTbl (by decide) (by decide) _)
          (fun _ _ => hw_lt9_ne8 engArrTbl (by decide) (by decide) _)
          (fun _ _ => hw_lt9_ne8 engArrTbl (by decide) (by decide) _)),
      (by (try dsimp only); rw [hbs1_cur]; exact hencC),
      fun mn' s' hs' hne he0 => hndC mn' s' hs' hne (hndB mn' s' hs' hne (hndA mn' s' he0)),
      fun t ht9 _ _ ht8 i => hw_lt9_ne8 t ht9 ht8 i,
      fun i _ => hw_lt9_ne8 engMetaTbl (by decide) (by decide) i,
      fun i _ => hw_lt9_ne8 engArrTbl (by decide) (by decide) i,
      fun i hi => (hwC engScrTbl (by decide) i).trans ((hwB engScrTbl (by decide) i).trans
        (hwA_scr i (by omega) (by omega))),
      fun t ht3 i => (hrC t ht3 i).trans ((hrB t ht3 i).trans (hrA t i))⟩
  · refine ExecDet.seq' (max ops.C_ins (ops.C_del + 180) + ops.C_bump + 30)
      (ops.containsNodeArr_spec inp mA pts' bs.curNode cSlot h_op false 15 2 17
        hcSlot_lt hcur_lt hwf_pts' (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
        hfpA hsrA (hndA _ _ hcenc₀) hr15A hr2A)
      (by omega) ?_
    intro mB ⟨hsrB, hcntB, hndB, hwB_t, hwB_scr, hrB⟩ hfpB
    have hcond_cnt : (evalArithCond inp 0 mB (.intEq (.readHeap engScrTbl (.lit 17)) (.lit 1))).1 =
        bs.curNode.nd.denseArr.contains h_op := by
      simp only [evalArithCond, evalIntExpr]
      change decide (wRead mB engScrTbl 17 = 1) = _
      rw [hcntB]; simp only [Bool.false_eq_true, ↓reduceIte]; cases bs.curNode.nd.denseArr.contains h_op <;> rfl
    refine ExecDet.ite' (C_c := 8) (C_b := max ops.C_ins (ops.C_del + 180) + ops.C_bump + 20)
      _ _ _ hcond_cnt (by simp [condExprOps, intExprOps]) (fun hcnt_t => ?_) (fun hcnt_f => ?_)
    · have hp_in : h_op ∈ bs.curNode.nd.curSet :=
        List.mem_toFinset.mpr (List.contains_iff_mem.mp hcnt_t)
      refine ExecDet.seq' ops.C_bump
        (ops.deleteMat_spec inp mB pts' bs.curNode cSlot h_op (curIdx * cp.B_op)
          (bs.insCur + bs.curNode.nd.age) seedBits 15 2 16
          hcSlot_lt hhop_lt hp_in hcur_lt (by omega) htins hcap_t hwf_pts' hcoin_ub
          (by omega) (by omega) (by omega) (by omega) (by omega) (by omega)
          hfpB hsrB (hndB _ _ hcSlot_lt (hndA _ _ hcenc₀))
          ((hwB_scr 15 (by decide)).trans hr15A)
          ((hwB_scr 2 (by decide)).trans hr2A)
          ((hwB_scr 16 (by decide)).trans hr16A)
          (fun x hx c => by
            rw [hrB ptsRTbl (by decide), hrA]
            exact hpts_mem x (Finset.mem_insert_of_mem (hcur_sub hx)) c)
          (fun k => (hwB_t coinTbl (by decide) (by decide) _).trans
            ((hwA_ne8 coinTbl (by decide) _).trans (hcoin_rd k))))
        (by omega) ?_
      intro mC ⟨hsrC, hencC, hndC, hwC, hrC⟩ hfpC
      refine (ops.bumpAge_spec inp mC _ cSlot 15 hcSlot_lt
        (by dsimp [ManagedNode.deleteMat, NodeInst.deleteMat]; omega)
        (by omega) (by omega) hfpC hsrC hencC
        ((hwC engScrTbl (by decide) 15).trans ((hwB_scr 15 (by decide)).trans hr15A))).mono
        ?_ (by omega)
      intro mD ⟨hsrD, hencD, hndD, hwD, hrD⟩ _
      have hbs1_cur : (if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)
          else bs.liveDelete cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)).curNode =
          (bs.curNode.deleteMat cp.hM₀ cp.T_cdf cp.p_coord (M_lat_of d params.e) params cp.specs
            cp.τ_d cp.τ_q cp.cap_u cp.cap_q pts' h_op (bitsToOpSeedEquiv cp seedBits)).bumpAge := by
        rw [if_neg (by simp [his_f])]; unfold BuildState.liveDelete; rw [if_pos hcnt_t, hseed_eq]
      have hbs1_del : (if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)
          else bs.liveDelete cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)).delSnapArr =
          bs.delSnapArr := by
        rw [if_neg (by simp [his_f])]; unfold BuildState.liveDelete; rw [if_pos hcnt_t]
      have hw_lt9_ne8 : ∀ t < 9, t ≠ engScrTbl → ∀ i, wRead mD t i = wRead m₀ t i :=
        fun t ht9 ht8 i => (hwD t ht9 i).trans ((hwC t ht9 i).trans ((hwB_t t ht9 ht8 i).trans (hwA_ne8 t ht8 i)))
      refine ⟨hsrD,
        (by
          (try dsimp only); rw [hbs1_del]
          exact hdsp₀.ext (hw_lt9_ne8 engMetaTbl (by decide) (by decide) _)
            (fun _ _ => hw_lt9_ne8 engArrTbl (by decide) (by decide) _)
            (fun _ _ => hw_lt9_ne8 engArrTbl (by decide) (by decide) _)),
        (by (try dsimp only); rw [hbs1_cur]; exact hencD),
        fun mn' s' hs' hne he0 => hndD mn' s' hs' hne (hndC mn' s' hs' hne (hndB mn' s' hs' (hndA mn' s' he0))),
        fun t ht9 _ _ ht8 i => hw_lt9_ne8 t ht9 ht8 i,
        fun i _ => hw_lt9_ne8 engMetaTbl (by decide) (by decide) i,
        fun i _ => hw_lt9_ne8 engArrTbl (by decide) (by decide) i,
        fun i hi => (hwD engScrTbl (by decide) i).trans ((hwC engScrTbl (by decide) i).trans
          ((hwB_scr i (by omega)).trans (hwA_scr i (by omega) (by omega)))),
        fun t ht3 i => (hrD t ht3 i).trans ((hrC t ht3 i).trans ((hrB t ht3 i).trans (hrA t i)))⟩
    · have hp_not_cur : h_op ∉ bs.curNode.nd.curSet := by
        intro hm
        have hc : bs.curNode.nd.denseArr.contains h_op = true :=
          List.contains_iff_mem.mpr (List.mem_toFinset.mp hm)
        rw [hc] at hcnt_f; cases hcnt_f
      have hp_in_T : h_op ∈ T_end := (hdel_case his_f).1
      have hp_in_rem : h_op ∈ bs.remSnap := by
        rw [← hcur_union] at hp_in_T
        rcases Finset.mem_union.mp hp_in_T with hc | hr
        · exact absurd hc hp_not_cur
        · exact hr
      have hp_not_del : h_op ∉ bs.delSnapArr :=
        fun hm => (Finset.mem_sdiff.mp hp_in_rem).2 (List.mem_toFinset.mpr hm)
      have hr20B : wRead mB engScrTbl 20 = (r.val : ℤ) :=
        (hwB_scr 20 (by decide)).trans ((hwA_scr 20 (by decide) (by decide)).trans hr20)
      have hr21B : wRead mB engScrTbl 21 = jobMetaBase cp r.val :=
        (hwB_scr 21 (by decide)).trans ((hwA_scr 21 (by decide) (by decide)).trans hr21)
      have hmeta_ub : jobMetaBase cp r.val + 8 ≤ 16 + 9 * (cp.D_max : ℤ) := by
        unfold jobMetaBase; omega
      have harr_ub : delSnapPosOff cp r.val + (S_stride cp : ℤ) ≤
          (((2 + 4 * cp.D_max) * S_stride cp : ℕ) : ℤ) := by
        unfold delSnapPosOff
        have : (5 + 4 * r.val) * S_stride cp + S_stride cp ≤ (2 + 4 * cp.D_max) * S_stride cp :=
          calc (5 + 4 * r.val) * S_stride cp + S_stride cp
            _ = (6 + 4 * r.val) * S_stride cp := by ring
            _ ≤ (2 + 4 * cp.D_max) * S_stride cp := Nat.mul_le_mul_right _ (by omega)
        exact_mod_cast this
      have hde_le_dp : delSnapElemOff cp r.val + (cp.n : ℤ) ≤ delSnapPosOff cp r.val := by
        unfold delSnapElemOff delSnapPosOff
        have hS_gt : cp.n < S_stride cp := by unfold S_stride; omega
        have : (4 + 4 * r.val) * S_stride cp + cp.n ≤ (5 + 4 * r.val) * S_stride cp :=
          calc (4 + 4 * r.val) * S_stride cp + cp.n
            _ ≤ (4 + 4 * r.val) * S_stride cp + S_stride cp := by omega
            _ = (5 + 4 * r.val) * S_stride cp := by ring
        exact_mod_cast this
      refine ExecDet.seq' (max ops.C_ins (ops.C_del + 180) + ops.C_bump + 4)
        (ExecDet.wWrite (C := 16) inp engScrTbl (.lit 30)
          (.add (.readHeap engScrTbl (.lit 21)) (.lit 6))
          30 (jobMetaBase cp r.val + 6) hfpB (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
          (by simp only [evalIntExpr]; change wRead mB engScrTbl 21 + 6 = _; rw [hr21B])
          (by simp [intExprOps]) rfl) (by omega) ?_
      intro mC₁ hmC₁ hfpC₁; subst hmC₁
      refine ExecDet.seq' (160 + ops.C_bump)
        (ExecDet.wWrite (C := 20) inp engScrTbl (.lit 31)
          (.mul (.add (.lit 4) (.mul (.lit 4) (.readHeap engScrTbl (.lit 20)))) (.lit (S_stride cp : ℤ)))
          31 (delSnapElemOff cp r.val) hfpC₁ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
          (by simp only [evalIntExpr]
              change (4 + 4 * wRead _ engScrTbl 20) * (S_stride cp : ℤ) = _
              rw [wRead_wWrite_of_ne mB _ (Or.inr (by decide)), hr20B]
              unfold delSnapElemOff; push_cast; ring)
          (by simp [intExprOps]) rfl) (by omega) ?_
      intro mC₂ hmC₂ hfpC₂; subst hmC₂
      refine ExecDet.seq' (140 + ops.C_bump)
        (ExecDet.wWrite (C := 20) inp engScrTbl (.lit 32)
          (.mul (.add (.lit 5) (.mul (.lit 4) (.readHeap engScrTbl (.lit 20)))) (.lit (S_stride cp : ℤ)))
          32 (delSnapPosOff cp r.val) hfpC₂ (by dsimp [engScrTbl]; omega) (by omega) (by omega) rfl
          (by simp only [evalIntExpr]
              change (5 + 4 * wRead _ engScrTbl 20) * (S_stride cp : ℤ) = _
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                  wRead_wWrite_of_ne mB _ (Or.inr (by decide)), hr20B]
              unfold delSnapPosOff; push_cast; ring)
          (by simp [intExprOps]) rfl) (by omega) ?_
      intro mC₃ hmC₃ hfpC; subst hmC₃
      set mC := H3a.wWrite (H3a.wWrite (H3a.wWrite mB engScrTbl 30 (jobMetaBase cp r.val + 6))
        engScrTbl 31 (delSnapElemOff cp r.val)) engScrTbl 32 (delSnapPosOff cp r.val)
      have hwC_ne8 : ∀ t ≠ engScrTbl, ∀ i, wRead mC t i = wRead mB t i := by
        intro t ht i; simp only [mC]
        iterate 3 rw [wRead_wWrite_of_ne _ _ (Or.inl ht)]
      have hwC_lt30 : ∀ i, i < 30 → wRead mC engScrTbl i = wRead mB engScrTbl i := by
        intro i hi; simp only [mC]
        rw [wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega)),
            wRead_wWrite_of_ne _ _ (Or.inr (by omega))]
      have hrC : ∀ t i, rRead mC t i = rRead mB t i := fun _ _ => by simp [mC, rRead_wWrite]
      have hdspC : EncSparseSet cp.n (jobMetaBase cp r.val + 6) (delSnapElemOff cp r.val)
          (delSnapPosOff cp r.val) bs.delSnapArr mC :=
        hdsp₀.ext
          ((hwC_ne8 engMetaTbl (by decide) _).trans ((hwB_t engMetaTbl (by decide) (by decide) _).trans (hwA_ne8 engMetaTbl (by decide) _)))
          (fun _ _ => (hwC_ne8 engArrTbl (by decide) _).trans ((hwB_t engArrTbl (by decide) (by decide) _).trans (hwA_ne8 engArrTbl (by decide) _)))
          (fun _ _ => (hwC_ne8 engArrTbl (by decide) _).trans ((hwB_t engArrTbl (by decide) (by decide) _).trans (hwA_ne8 engArrTbl (by decide) _)))
      refine ExecDet.seq' ops.C_bump
        (exec_sparseInsertFreshStmt inp 30 31 32 2 (by omega) hBW_s
          (by omega) (by omega) (by omega) (by omega)
          (by unfold jobMetaBase; omega) (by omega)
          (by unfold delSnapElemOff; exact Int.natCast_nonneg _) (by omega)
          (by unfold delSnapPosOff; exact Int.natCast_nonneg _) (by omega)
          (Or.inl hde_le_dp) hhop_lt hp_not_del hfpC hdspC
          (by simp only [mC]
              rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)),
                  wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
          (by simp only [mC]; rw [wRead_wWrite_of_ne _ _ (Or.inr (by decide)), wRead_wWrite_self])
          (by simp [mC])
          ((hwC_lt30 2 (by omega)).trans ((hwB_scr 2 (by decide)).trans hr2A)))
        (by omega) ?_
      intro mD ⟨hdspD, hwD_t, hwD_m, hwD_a, hwD_s, hrD⟩ hfpD
      have hwBD_ge9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mD t i = wRead mB t i :=
        fun t ht9 _ i => (hwD_t t (by dsimp [engMetaTbl]; omega) (by dsimp [engArrTbl]; omega) (by dsimp [engScrTbl]; omega) i).trans
          (hwC_ne8 t (by dsimp [engScrTbl]; omega) i)
      have hrBD : ∀ t i, rRead mD t i = rRead mB t i := fun t i => (hrD t i).trans (hrC t i)
      have hsrD : ops.SlotsReady mD :=
        ops.slotsReady_ext mB mD hsrB hwBD_ge9 (fun t _ _ i => hrBD t i)
      have hndBD : ∀ mn' s', ops.EncNode mn' s' mB → ops.EncNode mn' s' mD :=
        fun mn' s' he => ops.encNode_ext mn' s' mB mD he hwBD_ge9
          (fun t _ _ i => hrBD t i) (fun _ _ _ _ => hrBD ptsRTbl _)
      refine (ops.bumpAge_spec inp mD bs.curNode cSlot 15 hcSlot_lt (by omega)
        (by omega) (by omega) hfpD hsrD (hndBD _ _ (hndB _ _ hcSlot_lt (hndA _ _ hcenc₀)))
        ((hwD_s 15 (by omega)).trans ((hwC_lt30 15 (by omega)).trans ((hwB_scr 15 (by decide)).trans hr15A)))).mono
        ?_ le_rfl
      intro mE ⟨hsrE, hencE, hndE, hwE, hrE⟩ _
      have hbs1_cur : (if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)
          else bs.liveDelete cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)).curNode =
          bs.curNode.bumpAge := by
        rw [if_neg (by simp [his_f])]; unfold BuildState.liveDelete; rw [if_neg (by rw [hcnt_f]; decide)]
      have hbs1_del : (if isIns then bs.liveInsert cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)
          else bs.liveDelete cp pts' h_op (getS1Seed cp ((bitsToStepCoinBundle cp bits).1) curIdx)).delSnapArr =
          denseInsert h_op bs.delSnapArr := by
        rw [if_neg (by simp [his_f])]; unfold BuildState.liveDelete; rw [if_neg (by rw [hcnt_f]; decide)]
      have hlen_del_le : bs.delSnapArr.length ≤ cp.n := hdspC.length_le
      have hde_le_dp' : delSnapElemOff cp r.val ≤ delSnapPosOff cp r.val := by omega
      refine ⟨hsrE,
        (by
          (try dsimp only); rw [hbs1_del]
          exact hdspD.ext (hwE engMetaTbl (by decide) _)
            (fun _ _ => hwE engArrTbl (by decide) _)
            (fun _ _ => hwE engArrTbl (by decide) _)),
        (by (try dsimp only); rw [hbs1_cur]; exact hencE),
        fun mn' s' hs' hne he0 => hndE mn' s' hs' hne (hndBD _ _ (hndB mn' s' hs' (hndA mn' s' he0))),
        fun t ht9 h6 h7 h8 i => (hwE t ht9 i).trans ((hwD_t t h6 h7 h8 i).trans
          ((hwC_ne8 t h8 i).trans ((hwB_t t ht9 h8 i).trans (hwA_ne8 t h8 i)))),
        fun i hi => (hwE engMetaTbl (by decide) i).trans ((hwD_m i hi).trans
          ((hwC_ne8 engMetaTbl (by decide) i).trans ((hwB_t engMetaTbl (by decide) (by decide) i).trans
            (hwA_ne8 engMetaTbl (by decide) i)))),
        fun i hi => (hwE engArrTbl (by decide) i).trans ((hwD_a i (by omega) (by omega)).trans
          ((hwC_ne8 engArrTbl (by decide) i).trans ((hwB_t engArrTbl (by decide) (by decide) i).trans
            (hwA_ne8 engArrTbl (by decide) i)))),
        fun i hi => (hwE engScrTbl (by decide) i).trans ((hwD_s i (by omega)).trans
          ((hwC_lt30 i (by omega)).trans ((hwB_scr i (by omega)).trans (hwA_scr i (by omega) (by omega))))),
        fun t ht3 i => (hrE t ht3 i).trans ((hrBD t i).trans ((hrB t ht3 i).trans (hrA t i)))⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG19
