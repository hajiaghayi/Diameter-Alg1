import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2B
import UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage20
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19
open UL.Proof.clm_9_1_explicit_tradeoff.CG16_Stage2

/-! ### 11. Outer Stage-2 Loop Over `r ∈ List.finRange cp.D_max` (`outerJobLoopStmt`) -/

/-- Preserve `EncHandlePool`, `EncCachedAns`, `MemHasStepCoins`, and `wRead _ 0 0` across any
memory update preserving word tables `0 .. 5`, `engMetaTbl[3 .. 5]`, real tables `0, 1`, and
`engRealTbl[0]`. -/
theorem encPoolAnsCoins_ext {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} {hp : HandlePool d cp.n} {ans : StoredDiameterAnswer}
    {bits : Fin cp.B_STEP → Bool} {m₀ m₁ : ArithRAMMemory}
    (hhp : EncHandlePool hp m₀) (hans : EncCachedAns ans m₀)
    (hcoins : MemHasStepCoins cp bits m₀)
    (hw_lt6 : ∀ t < 6, ∀ i, wRead m₁ t i = wRead m₀ t i)
    (hw6_345 : ∀ i : ℤ, (i = 3 ∨ i = 4 ∨ i = 5) → wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i)
    (hr01 : ∀ t < 2, ∀ i, rRead m₁ t i = rRead m₀ t i)
    (hr20 : rRead m₁ engRealTbl 0 = rRead m₀ engRealTbl 0) :
    EncHandlePool hp m₁ ∧ EncCachedAns ans m₁ ∧ MemHasStepCoins cp bits m₁ ∧
      wRead m₁ 0 0 = wRead m₀ 0 0 := by
  have hw0 := hw_lt6 0 (by omega)
  have hw1 := hw_lt6 1 (by omega)
  have hw2 := hw_lt6 2 (by omega)
  have hw3 := hw_lt6 3 (by omega)
  have hw5 := hw_lt6 5 (by omega)
  have hhp₁ : EncHandlePool hp m₁ :=
    ⟨(hw0 4).trans hhp.1, (hw0 5).trans hhp.2.1, (hw0 6).trans hhp.2.2.1,
     fun i hi => (hw1 _).trans (hhp.2.2.2.1 i hi),
     fun i hi => ⟨(hw2 _).trans (hhp.2.2.2.2.1 i hi).1, (hw3 _).trans (hhp.2.2.2.2.1 i hi).2⟩,
     fun x hx c => (hr01 ptsRTbl (by decide) _).trans (hhp.2.2.2.2.2 x hx c)⟩
  have hans₁ : EncCachedAns ans m₁ := by
    rcases hans with ⟨hread, hr_sh, hmatch⟩
    have hread₁ : ArithRAMDynamicProgram.readCachedAnswer m₁ =
        ArithRAMDynamicProgram.readCachedAnswer m₀ := by
      have h01 : m₁.words.read (.heap 0 1) = m₀.words.read (.heap 0 1) := hw0 1
      have h02 : m₁.words.read (.heap 0 2) = m₀.words.read (.heap 0 2) := hw0 2
      have h03 : m₁.words.read (.heap 0 3) = m₀.words.read (.heap 0 3) := hw0 3
      have hr00 : m₁.reals.read (.heap 0 0) = m₀.reals.read (.heap 0 0) := hr01 0 (by omega) 0
      unfold ArithRAMDynamicProgram.readCachedAnswer
      simp only [h01, h02, h03, hr00]
    refine ⟨hread₁.trans hread, hr20.trans hr_sh, ?_⟩
    cases hd_ans : ans.diameterHandles with
    | none =>
        simp only [hd_ans] at hmatch
        exact ⟨(hw6_345 3 (Or.inl rfl)).trans hmatch.1,
          (hw6_345 4 (Or.inr (Or.inl rfl))).trans hmatch.2.1,
          (hw6_345 5 (Or.inr (Or.inr rfl))).trans hmatch.2.2⟩
    | some uv =>
        rcases uv with ⟨u, v⟩
        simp only [hd_ans] at hmatch
        exact ⟨(hw6_345 3 (Or.inl rfl)).trans hmatch.1,
          (hw6_345 4 (Or.inr (Or.inl rfl))).trans hmatch.2.1,
          (hw6_345 5 (Or.inr (Or.inr rfl))).trans hmatch.2.2⟩
  exact ⟨hhp₁, hans₁, fun k => (hw5 (k.val : ℤ)).trans (hcoins k), hw0 0⟩

/-- Pure per-slot Stage-2 job outcome matching `stepStage2`. -/
noncomputable def s2OutJob {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp)
    (r : Fin cp.D_max) : Option (SuffixJob cp ⊕ (List (MNode cp) × List ℕ × Bool)) :=
  if hr : r.val < st.serving.length then
    match st.jobs r with
    | none => none
    | some jb =>
        let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
          ω₂.1 ⟨r.val * cp.B_scan + j.val, by
            have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
              calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan :=
                    Nat.add_lt_add_left j.isLt _
                _ = (r.val + 1) * cp.B_scan := by ring
                _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
            exact Nat.lt_add_right _ this⟩
        some (advanceOneJob cp st.hp.coords st.gt (st.serving[r.val]'hr) r jb bSeeds (ω₂.2 r.castSucc))
  else
    none

noncomputable def s2CommitAt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp)
    (r : Fin cp.D_max) : Option (Fin cp.D_max × List (MNode cp) × List ℕ × Bool) :=
  match s2OutJob cp st ω₂ r with
  | some (Sum.inr (suf, lf, ov)) => some (r, suf, lf, ov)
  | _ => none

noncomputable def s2JobsNoCommit {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp)
    (k : ℕ) : Fin cp.D_max → Option (SuffixJob cp) :=
  fun r =>
    if r.val < k then
      match s2OutJob cp st ω₂ r with
      | some (Sum.inl jb') => some jb'
      | _ => none
    else
      st.jobs r

noncomputable def s2JobsAfterCommit {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp)
    (r₀ : Fin cp.D_max) (k : ℕ) : Fin cp.D_max → Option (SuffixJob cp) :=
  fun r =>
    if r.val < r₀.val then
      match s2OutJob cp st ω₂ r with
      | some (Sum.inl jb') => some jb'
      | _ => none
    else if r.val < k then
      none
    else
      st.jobs r

noncomputable def s2OuterStateAt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp)
    (k : ℕ) : ChainEngineState cp :=
  match ((List.finRange cp.D_max).take k).findSome? (s2CommitAt cp st ω₂) with
  | none => { st with jobs := s2JobsNoCommit cp st ω₂ k }
  | some (r₀, newSuf, newLeaf, newOv) =>
      { st with
        serving := st.serving.take r₀.val ++ newSuf
        jobs := s2JobsAfterCommit cp st ω₂ r₀ k
        leafArr := newLeaf
        leafOverflow := newOv }

private theorem finRange_take_succ (D k : ℕ) (hk : k < D) :
    (List.finRange D).take (k + 1) = (List.finRange D).take k ++ [⟨k, hk⟩] := by
  have hk_len : k < (List.finRange D).length := by simp [hk]
  rw [List.take_succ_eq_append_getElem hk_len]
  simp

private theorem findSome_s2CommitAt_lt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (st : ChainEngineState cp) (ω₂ : Stage2Coins cp) :
    ∀ (k : ℕ) {r₀ : Fin cp.D_max} {suf : List (MNode cp)} {lf : List ℕ} {ov : Bool},
      ((List.finRange cp.D_max).take k).findSome? (s2CommitAt cp st ω₂) = some (r₀, suf, lf, ov) →
      r₀.val < k
  | 0, _, _, _, _, h => by simp at h
  | k + 1, r₀, suf, lf, ov, h => by
      by_cases hk : k < cp.D_max
      · rw [finRange_take_succ cp.D_max k hk, List.findSome?_append] at h
        cases hpre : ((List.finRange cp.D_max).take k).findSome? (s2CommitAt cp st ω₂) with
        | some q =>
            rw [hpre] at h; injection h with hq; subst hq
            exact Nat.lt_succ_of_lt (findSome_s2CommitAt_lt cp st ω₂ k hpre)
        | none =>
            rw [hpre] at h; simp only [Option.none_or, List.findSome?_cons, List.findSome?_nil] at h
            dsimp only [s2CommitAt] at h
            cases ho : s2OutJob cp st ω₂ ⟨k, hk⟩ with
            | none => rw [ho] at h; simp at h
            | some s =>
                cases s with
                | inl _ => rw [ho] at h; simp at h
                | inr t =>
                    rcases t with ⟨s1, s2, s3⟩
                    rw [ho] at h; simp at h
                    rcases h with ⟨rfl, _, _, _⟩
                    exact Nat.lt_succ_self k
      · exact lt_of_lt_of_le r₀.isLt (by omega)

/-- Single-slot Stage-2 outer loop body at `r : Fin cp.D_max`:
- if `engScrTbl[0] = 1` (an earlier job `r₀ < r` committed), cancel job `r` in `O(1)`;
- else if job `r` is active (`engMetaTbl[jobMetaBase r] = 1`), run `tickRebuildJobStmt ops r`
  and if `engScrTbl[10] ≠ 0`, run `commitJobStage2Stmt ops r` (setting `engScrTbl[0] := 1`). -/
def outerJobStepStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) (r : Fin cp.D_max) : ArithRAMStmt :=
  .ite (.intEq (.readHeap engScrTbl (.lit 0)) (.lit 1))
    (cancelJobSlotStage2Stmt cp r)
    (.ite (.intEq (.readHeap engMetaTbl (.lit (jobMetaBase cp r.val))) (.lit 1))
      (.seq (tickRebuildJobStmt ops r)
        (.ite (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 0))
          .skip
          (commitJobStage2Stmt ops r)))
      .skip)

def outerJobLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 0) (.lit 0))
       (foldrSeqStmt (outerJobStepStmt ops) (List.finRange cp.D_max))

theorem zeroRand_outerJobLoopStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) :
    ZeroRandStmt (outerJobLoopStmt ops) :=
  .seq (.writeWordHeap _ _ _)
    (zeroRand_foldrSeqStmt (List.finRange cp.D_max) fun r _ =>
      .ite (zeroRand_cancelJobSlotStage2Stmt cp r)
        (.ite (.seq (zeroRand_tickRebuildJobStmt ops r)
                (.ite .skip (zeroRand_commitJobStage2Stmt ops r)))
              .skip))

def outerJobStepCost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  40 + tickRebuildJobCost ops + commitJobStage2Cost ops

def outerJobLoopCost {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp) : ℕ :=
  20 + cp.D_max * outerJobStepCost ops

theorem exec_outerJobLoopStmt
    (h_lem_5_1 : S_lem_5_1) (h_clm_7_3 : S_clm_7_3_global_approx)
    {d : ℕ} (hd : 1 ≤ d) {params : LocalScaleParams} (he1 : (params.e : ℝ) ≤ 1)
    {h : ℝ} (hh0 : 0 < h) (hh1 : h < 1)
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d)
    {P' : DynamicPointSet d} {st₁ : ChainEngineState cp}
    {bits : Fin cp.B_STEP → Bool} {m₁ : ArithRAMMemory}
    (_hP' : P'.WellFormed cp.n)
    (hwf₁ : PostStage1WF cp P' st₁)
    (hfp₁ : InFootprint ops.TW ops.BW ops.TR ops.BR m₁)
    (henc₁ : EncChainEngine ops st₁ m₁)
    (hcoins₁ : MemHasStepCoins cp bits m₁) :
    let ω₂ := (bitsToStepCoinBundle cp bits).2.1
    let fc := (List.finRange cp.D_max).findSome? (s2CommitAt cp st₁ ω₂)
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (outerJobLoopStmt ops) m₁
      (fun mMid =>
        EncChainEngine ops (s2OuterStateAt cp st₁ ω₂ cp.D_max) mMid ∧
        wRead mMid engScrTbl 0 = (if fc.isSome then 1 else 0) ∧
        MemHasStepCoins cp bits mMid ∧
        wRead mMid 0 0 = wRead m₁ 0 0)
      (outerJobLoopCost ops) := by
  intro ω₂ fc
  have hTW := ops.hTW; have hBW_scr := ops.hBW_scr
  rcases hwf₁ with ⟨hhp_wf, hgt_wf, hserv_len₁, hserv_cl₁, hjobs_wf₁, _⟩
  let actH := P'.activeHandles
  let pts := st₁.hp.coords
  have hact_card_n : actH.card ≤ cp.n := by
    have hnf_le := hhp_wf.1
    rcases hhp_wf.2 with ⟨hact_nd, _, hact_set, _, _, hsum, _⟩
    dsimp only [actH]; rw [← hact_set, List.toFinset_card_of_nodup hact_nd]
    omega
  have hact_lt_nf : ∀ x ∈ actH, x < st₁.hp.nextFresh := fun x hx =>
    (handle_lt_nextFresh_of_mem_act hhp_wf hx).1
  have hact_lt_n : ∀ x ∈ actH, x < cp.n := fun x hx =>
    lt_of_lt_of_le (hact_lt_nf x hx) hhp_wf.1
  have hserv_age16 : ∀ q (hq : q < st₁.serving.length),
      16 * K_alpha d * (st₁.serving[q]'hq).nd.age < (st₁.serving[q]'hq).nd.birthSize := by
    intro q hq
    have hqD : q < cp.D_max := lt_of_lt_of_le hq hserv_len₁
    have hslot := hjobs_wf₁ ⟨q, hqD⟩
    rw [dif_pos hq] at hslot
    have hMr : cp.B_scan < (st₁.serving[q]'hq).nd.birthSize :=
      (chainListInv_mem_birthSize actH st₁.serving hserv_cl₁ _ (List.getElem_mem hq)).1
    cases hjb_eq : st₁.jobs ⟨q, hqD⟩ with
    | none =>
        dsimp only at hslot; rw [hjb_eq] at hslot
        have hB1 := cp.sched_bounds.1
        have hmul4 : 4 * (16 * K_alpha d * (st₁.serving[q]'hq).nd.age) =
            64 * K_alpha d * (st₁.serving[q]'hq).nd.age := by ring
        omega
    | some jb =>
        dsimp only at hslot; rw [hjb_eq] at hslot
        exact (suffixJobInvSlack_bounds le_rfl hMr hslot).2.1
  -- Loop invariant after `k` slots (`0 ≤ k ≤ cp.D_max`)
  let OuterInv (k : ℕ) (m : ArithRAMMemory) : Prop :=
    EncChainEngine ops (s2OuterStateAt cp st₁ ω₂ k) m ∧
    wRead m engScrTbl 0 = (if (((List.finRange cp.D_max).take k).findSome? (s2CommitAt cp st₁ ω₂)).isSome then 1 else 0) ∧
    MemHasStepCoins cp bits m ∧
    wRead m 0 0 = wRead m₁ 0 0
  unfold outerJobLoopStmt
  refine ExecDet.seq' (1 + (List.finRange cp.D_max).length * outerJobStepCost ops)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 0) (.lit 0) 0 0
      hfp₁ (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega)
      rfl rfl (by simp [intExprOps]) rfl)
    (by simp only [List.length_finRange, outerJobLoopCost]; omega) ?_
  intro mInit hmInit hfpInit; subst hmInit
  have hj0_eq : s2JobsNoCommit cp st₁ ω₂ 0 = st₁.jobs := by
    ext r; simp [s2JobsNoCommit]
  have hstAt0 : s2OuterStateAt cp st₁ ω₂ 0 = st₁ := by
    unfold s2OuterStateAt; simp [hj0_eq]
  have hInv0 : OuterInv 0 (H3a.wWrite m₁ engScrTbl 0 0) := by
    refine ⟨?_, by simp [wRead_wWrite_self],
      fun k => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hcoins₁ k),
      wRead_wWrite_of_ne _ _ (Or.inl (by decide))⟩
    rw [hstAt0]
    exact encChainEngine_frame_coins ops st₁ m₁ (H3a.wWrite m₁ engScrTbl 0 0) henc₁
      (fun tbl idx _ hne8 => wRead_wWrite_of_ne _ _ (Or.inl hne8))
      (fun _ _ => rRead_wWrite _ _ _ _ _ _)
  refine (ExecDet.foldrSeq (outerJobStepStmt ops) (List.finRange cp.D_max) (outerJobStepCost ops)
    0 OuterInv hfpInit hInv0 ?_).mono ?_ le_rfl
  · intro k hk_len m ⟨henc_k, hscr0_k, hcoins_k, hw00_k⟩ hfp_k
    simp only [Nat.zero_add] at henc_k hscr0_k ⊢
    have hk : k < cp.D_max := by simpa using hk_len
    let r : Fin cp.D_max := ⟨k, hk⟩
    have hget_r : (List.finRange cp.D_max)[k]'hk_len = r := List.getElem_finRange hk_len
    rw [hget_r]
    rcases henc_k with ⟨hsr, hhp, hans, hov, hleaf_le, hleaf_sp, hserv_le, hserv_len,
      servSlots, readySlots, curSlots, hslen, hserv, hjobs, hall_nd, hall_lt⟩
    unfold outerJobStepStmt
    cases hfc_k : ((List.finRange cp.D_max).take k).findSome? (s2CommitAt cp st₁ ω₂) with
    | some quad =>
        -- Already committed at some `r₀` with `r₀.val < k = r.val`: run `cancelJobSlotStage2Stmt cp r`!
        rcases quad with ⟨r₀, newSuf, newLeaf, newOv⟩
        have hr₀_lt_k : r₀.val < k := findSome_s2CommitAt_lt cp st₁ ω₂ k hfc_k
        have hfc_succ : ((List.finRange cp.D_max).take (k + 1)).findSome? (s2CommitAt cp st₁ ω₂) =
            some (r₀, newSuf, newLeaf, newOv) := by
          rw [finRange_take_succ cp.D_max k hk, List.findSome?_append, hfc_k]; rfl
        have hst_k : s2OuterStateAt cp st₁ ω₂ k =
            { st₁ with
              serving := st₁.serving.take r₀.val ++ newSuf
              jobs := s2JobsAfterCommit cp st₁ ω₂ r₀ k
              leafArr := newLeaf
              leafOverflow := newOv } := by unfold s2OuterStateAt; rw [hfc_k]
        have hst_succ : s2OuterStateAt cp st₁ ω₂ (k + 1) =
            { st₁ with
              serving := st₁.serving.take r₀.val ++ newSuf
              jobs := s2JobsAfterCommit cp st₁ ω₂ r₀ (k + 1)
              leafArr := newLeaf
              leafOverflow := newOv } := by unfold s2OuterStateAt; rw [hfc_succ]
        rw [hst_k] at hhp hans hov hleaf_le hleaf_sp hserv_le hserv_len hslen hserv hjobs hall_nd hall_lt
        rw [hfc_k] at hscr0_k
        have hcond0 : (evalArithCond inp 0 m
            (.intEq (.readHeap engScrTbl (.lit 0)) (.lit 1))).1 = true := by
          simp only [evalArithCond, evalIntExpr]
          change decide (wRead m engScrTbl 0 = 1) = true
          rw [hscr0_k]; simp
        refine ExecDet.ite' (C_c := 8) (C_b := outerJobStepCost ops - 8) _ _ _ hcond0
          (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
          (by unfold outerJobStepCost; omega)
        refine (exec_cancelJobSlotStage2Stmt ops inp r hfp_k hsr hjobs hall_nd hall_lt).mono
          ?_ (by unfold outerJobStepCost; omega)
        intro m' ⟨hsr', hjobs', hall_nd', hall_lt', hnd', hft', hfm', hfr'⟩ _
        have hjobs_upd : Function.update (s2JobsAfterCommit cp st₁ ω₂ r₀ k) r none =
            s2JobsAfterCommit cp st₁ ω₂ r₀ (k + 1) := by
          ext r'
          by_cases heq : r' = r
          · subst heq
            have hnot_r0 : ¬ (r.val < r₀.val) := by dsimp [r]; omega
            have hr_lt_k1 : r.val < k + 1 := by dsimp [r]; omega
            simp [Function.update_self, s2JobsAfterCommit, hnot_r0, hr_lt_k1]
          · have hne_val : r'.val ≠ k := fun hv => heq (Fin.ext hv)
            have hiff : (r'.val < k + 1) ↔ (r'.val < k) := by omega
            simp [Function.update_of_ne heq, s2JobsAfterCommit, hiff]
        rw [hjobs_upd] at hjobs' hall_nd' hall_lt'
        have hpac := encPoolAnsCoins_ext hhp hans hcoins_k
          (fun t ht6 i => hft' t (by unfold engMetaTbl; omega) i)
          (fun i hi => hfm' i (by unfold jobMetaBase; rcases hi with rfl | rfl | rfl <;> omega))
          (fun t _ i => hfr' t i) (hfr' engRealTbl 0)
        refine ⟨?_, ?_, hpac.2.2.1, hpac.2.2.2.trans hw00_k⟩
        · rw [hst_succ]
          refine ⟨hsr', hpac.1, hpac.2.1,
            (hfm' 1 (by unfold jobMetaBase; omega)).trans hov,
            hleaf_le,
            hleaf_sp.ext (hfm' 2 (by unfold jobMetaBase; omega))
              (fun _ _ => hft' engArrTbl (by decide) _)
              (fun _ _ => hft' engArrTbl (by decide) _),
            hserv_le,
            (hfm' 0 (by unfold jobMetaBase; omega)).trans hserv_len,
            servSlots, Function.update readySlots r [], Function.update curSlots r 0,
            hslen,
            fun i hi his => ?_,
            hjobs', hall_nd', hall_lt'⟩
          have hiD : i < cp.D_max := lt_of_lt_of_le hi hserv_le
          have hs_M : servSlots[i]'his < M_slots cp :=
            hall_lt _ (List.mem_append_left _ (List.getElem_mem his))
          exact ⟨(hfm' _ (by unfold servSlotOff jobMetaBase; omega)).trans (hserv i hi his).1,
            hnd' _ _ hs_M (hserv i hi his).2⟩
        · rw [hfc_succ]
          exact (hft' engScrTbl (by decide) 0).trans hscr0_k
    | none =>
        -- No commit in `0 .. k - 1` (`engScrTbl[0] = 0`)!
        have hst_k : s2OuterStateAt cp st₁ ω₂ k = { st₁ with jobs := s2JobsNoCommit cp st₁ ω₂ k } := by
          unfold s2OuterStateAt; rw [hfc_k]
        rw [hst_k] at hhp hans hov hleaf_le hleaf_sp hserv_le hserv_len hslen hserv hjobs hall_nd hall_lt
        rw [hfc_k] at hscr0_k
        have hcond0 : (evalArithCond inp 0 m
            (.intEq (.readHeap engScrTbl (.lit 0)) (.lit 1))).1 = false := by
          simp only [evalArithCond, evalIntExpr]
          change decide (wRead m engScrTbl 0 = 1) = false
          rw [hscr0_k]; simp
        refine ExecDet.ite' (C_c := 8) (C_b := outerJobStepCost ops - 8) _ _ _ hcond0
          (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
          (by unfold outerJobStepCost; omega)
        have hjob_r_eq : s2JobsNoCommit cp st₁ ω₂ k r = st₁.jobs r := by
          dsimp [s2JobsNoCommit, r]; rw [if_neg (Nat.lt_irrefl k)]
        cases hj_r1 : st₁.jobs r with
        | none =>
            -- Job `r` is `none`: condition `jobMetaBase r == 1` is `false` -> `.skip`!
            have hj_r_none : s2JobsNoCommit cp st₁ ω₂ k r = none := hjob_r_eq.trans hj_r1
            have hw_jb0 : wRead m engMetaTbl (jobMetaBase cp r.val) = 0 := by
              have hj := hjobs r; simp only [EncJobSlot, hj_r_none] at hj; exact hj.2
            have hcond1 : (evalArithCond inp 0 m
                (.intEq (.readHeap engMetaTbl (.lit (jobMetaBase cp r.val))) (.lit 1))).1 = false := by
              simp only [evalArithCond, evalIntExpr]
              change decide (wRead m engMetaTbl (jobMetaBase cp r.val) = 1) = false
              rw [hw_jb0]; decide
            refine ExecDet.ite' (C_c := 8) (C_b := outerJobStepCost ops - 16) _ _ _ hcond1
              (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_)
              (by unfold outerJobStepCost; omega)
            have hout_none : s2OutJob cp st₁ ω₂ r = none := by
              unfold s2OutJob
              by_cases hr_s : r.val < st₁.serving.length
              · rw [dif_pos hr_s, hj_r1]
              · rw [dif_neg hr_s]
            have hfc_succ : ((List.finRange cp.D_max).take (k + 1)).findSome? (s2CommitAt cp st₁ ω₂) = none := by
              rw [finRange_take_succ cp.D_max k hk, List.findSome?_append, hfc_k]
              dsimp [r] at hout_none; simp [s2CommitAt, hout_none]
            have hjobs_same : s2JobsNoCommit cp st₁ ω₂ (k + 1) = s2JobsNoCommit cp st₁ ω₂ k := by
              ext r'
              by_cases heq : r' = r
              · subst heq
                have hr_lt_k1 : r.val < k + 1 := by dsimp [r]; omega
                simp [r, s2JobsNoCommit, hout_none, hj_r1]
              · have hne_val : r'.val ≠ k := fun hv => heq (Fin.ext hv)
                have hiff : (r'.val < k + 1) ↔ (r'.val < k) := by omega
                simp [s2JobsNoCommit, hiff]
            refine ExecDet.skip inp hfp_k ?_ (by unfold outerJobStepCost; omega)
            have hst_succ : s2OuterStateAt cp st₁ ω₂ (k + 1) = { st₁ with jobs := s2JobsNoCommit cp st₁ ω₂ k } := by
              unfold s2OuterStateAt; rw [hfc_succ, hjobs_same]
            refine ⟨?_, by rw [hfc_succ]; exact hscr0_k, hcoins_k, hw00_k⟩
            rw [hst_succ]
            exact ⟨hsr, hhp, hans, hov, hleaf_le, hleaf_sp, hserv_le, hserv_len,
              servSlots, readySlots, curSlots, hslen, hserv, hjobs, hall_nd, hall_lt⟩
        | some jb =>
            -- Active job `r`: `st₁.jobs r = some jb`, so `hr_serv1 : r.val < st₁.serving.length`!
            have hr_serv1 : r.val < st₁.serving.length := by
              by_contra hnot
              have hslot := hjobs_wf₁ r
              rw [dif_neg hnot] at hslot
              rw [hj_r1] at hslot; cases hslot
            have hj_r_some : s2JobsNoCommit cp st₁ ω₂ k r = some jb := hjob_r_eq.trans hj_r1
            have hw_jb1 : wRead m engMetaTbl (jobMetaBase cp r.val) = 1 := by
              have hj := hjobs r; simp only [EncJobSlot, hj_r_some] at hj; exact hj.1
            have hcond1 : (evalArithCond inp 0 m
                (.intEq (.readHeap engMetaTbl (.lit (jobMetaBase cp r.val))) (.lit 1))).1 = true := by
              simp only [evalArithCond, evalIntExpr]
              change decide (wRead m engMetaTbl (jobMetaBase cp r.val) = 1) = true
              rw [hw_jb1]; decide
            refine ExecDet.ite' (C_c := 8) (C_b := tickRebuildJobCost ops + 16 + commitJobStage2Cost ops)
              _ _ _ hcond1 (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf)
              (by unfold outerJobStepCost; omega)
            -- Extract `LiveNodeInv`, `SuffixJobInvSlack`, and `ptsRTbl` coords on `actH`
            let S_anc := foldResiduals pts actH (st₁.serving.take r.val)
            let anc := st₁.serving[r.val]'hr_serv1
            rcases (chainListInv_getElem actH st₁.serving (Finset.Subset.refl _) hserv_cl₁).2 r.val hr_serv1
              with ⟨hS_anc_sub, hanc_ln⟩
            have hjb_inv : SuffixJobInvSlack cp cp.B_scan actH pts st₁.gt S_anc anc r.val jb := by
              have hslot := hjobs_wf₁ r
              rw [dif_pos hr_serv1] at hslot; dsimp only at hslot
              rw [hj_r1] at hslot; exact hslot
            have hact_pts : ∀ x ∈ actH, ∀ c : Fin d,
                rRead m ptsRTbl (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c :=
              fun x hx c => hhp.2.2.2.2.2 x (hact_lt_nf x hx) c
            have hr_serv_sl : r.val < servSlots.length := hslen.symm ▸ hr_serv1
            -- Run `tickRebuildJobStmt ops r`!
            refine ExecDet.seq' (16 + commitJobStage2Cost ops)
              (exec_tickRebuildJobStmt h_clm_7_3 hd he1 hh0 hh1 ops inp r hj_r_some
                hserv_le hslen hr_serv_sl hS_anc_sub hact_lt_n hact_pts hanc_ln hjb_inv
                hfp_k hsr hserv_len (fun i his => (hserv i (hslen ▸ his) his).1)
                (hserv r.val hr_serv1 hr_serv_sl).2 hjobs hall_nd hall_lt hcoins_k)
              (by omega) ?_
            intro mT hPostT hfpT
            rcases hPostT with ⟨hsrT, hftT, hfmT, hfaT, hfsT, hfrT, hr20T, hndT,
              outJb, rSlots', cSlot', henc_r_T, hjobs_T, hall_nd_T, hall_lt_T, hmatchT⟩
            let bSeeds : Fin cp.B_scan → OpSeed cp := fun j =>
              ω₂.1 ⟨r.val * cp.B_scan + j.val, by
                have : r.val * cp.B_scan + j.val < cp.D_max * cp.B_scan := by
                  calc r.val * cp.B_scan + j.val < r.val * cp.B_scan + cp.B_scan :=
                        Nat.add_lt_add_left j.isLt _
                    _ = (r.val + 1) * cp.B_scan := by ring
                    _ ≤ cp.D_max * cp.B_scan := Nat.mul_le_mul_right _ r.isLt
                exact Nat.lt_add_right _ this⟩
            let ctrSeed := ω₂.2 r.castSucc
            have hout_r : s2OutJob cp st₁ ω₂ r =
                some (advanceOneJob cp pts st₁.gt anc r jb bSeeds ctrSeed) := by
              unfold s2OutJob; rw [dif_pos hr_serv1, hj_r1]
            have hpacT := encPoolAnsCoins_ext hhp hans hcoins_k
              (fun t ht6 i => hftT t (by omega) (by unfold engMetaTbl; omega)
                (by unfold engArrTbl; omega) (by unfold engScrTbl; omega) i)
              (fun i hi => hfmT i (not_inJobMetaRegion_header r.val
                (by rcases hi with rfl | rfl | rfl <;> omega)
                (by have := cp.D_max_pos; rcases hi with rfl | rfl | rfl <;> omega)))
              hfrT hr20T
            have hserv_T : ∀ i (hi : i < st₁.serving.length) (his : i < servSlots.length),
                wRead mT engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ) ∧
                ops.EncNode (st₁.serving[i]'hi) (servSlots[i]'his) mT := by
              intro i hi his
              have hiD : i < cp.D_max := lt_of_lt_of_le hi hserv_le
              have hs_M : servSlots[i]'his < M_slots cp :=
                hall_lt _ (List.mem_append_left _ (List.getElem_mem his))
              refine ⟨(hfmT _ (not_inJobMetaRegion_header r.val
                (by unfold servSlotOff; omega) (by unfold servSlotOff; omega))).trans (hserv i hi his).1,
                hndT _ _ hs_M (List.mem_append_left _ (List.getElem_mem his)) (hserv i hi his).2⟩
            cases hadv_eq : advanceOneJob cp pts st₁.gt anc r jb bSeeds ctrSeed with
            | inl jb' =>
                -- `advRes = Sum.inl jb'` (`engScrTbl[10] = 0`) -> `.skip`!
                have hadv_eq' : advanceOneJob cp pts st₁.gt (st₁.serving[r.val]'hr_serv1) r jb bSeeds ctrSeed = Sum.inl jb' := hadv_eq
                dsimp only [bSeeds, ctrSeed, ω₂] at hadv_eq'
                rw [hadv_eq'] at hmatchT
                rcases hmatchT with ⟨hw10_0, houtJb_eq⟩
                subst outJb
                have hcond10 : (evalArithCond inp 0 mT
                    (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 0))).1 = true := by
                  simp only [evalArithCond, evalIntExpr]
                  change decide (wRead mT engScrTbl 10 = 0) = true
                  rw [hw10_0]; decide
                refine ExecDet.ite' (C_c := 8) (C_b := 8 + commitJobStage2Cost ops) _ _ _ hcond10
                  (by simp [condExprOps, intExprOps]) (fun _ => ?_) (fun hf => by cases hf) (by omega)
                refine ExecDet.skip inp hfpT ?_ (by omega)
                have hfc_succ : ((List.finRange cp.D_max).take (k + 1)).findSome? (s2CommitAt cp st₁ ω₂) = none := by
                  rw [finRange_take_succ cp.D_max k hk, List.findSome?_append, hfc_k]
                  dsimp [r] at hout_r hadv_eq ⊢; simp [s2CommitAt, hout_r, hadv_eq]
                have hjobs_upd : Function.update (s2JobsNoCommit cp st₁ ω₂ k) r (some jb') =
                    s2JobsNoCommit cp st₁ ω₂ (k + 1) := by
                  ext r'
                  by_cases heq : r' = r
                  · subst heq
                    have hr_lt_k1 : r.val < k + 1 := by dsimp [r]; omega
                    simp [Function.update_self, s2JobsNoCommit, hr_lt_k1, hout_r, hadv_eq]
                  · have hne_val : r'.val ≠ k := fun hv => heq (Fin.ext hv)
                    have hiff : (r'.val < k + 1) ↔ (r'.val < k) := by omega
                    simp [Function.update_of_ne heq, s2JobsNoCommit, hiff]
                rw [hjobs_upd] at hjobs_T hall_nd_T hall_lt_T
                have hst_succ : s2OuterStateAt cp st₁ ω₂ (k + 1) =
                    { st₁ with jobs := s2JobsNoCommit cp st₁ ω₂ (k + 1) } := by
                  unfold s2OuterStateAt; rw [hfc_succ]
                refine ⟨?_, ?_, hpacT.2.2.1, hpacT.2.2.2.trans hw00_k⟩
                · rw [hst_succ]
                  refine ⟨hsrT, hpacT.1, hpacT.2.1,
                    (hfmT 1 (not_inJobMetaRegion_header r.val (by omega) (by have := cp.D_max_pos; omega))).trans hov,
                    hleaf_le,
                    hleaf_sp.ext
                      (hfmT 2 (not_inJobMetaRegion_header r.val (by omega) (by have := cp.D_max_pos; omega)))
                      (fun idx hidx => hfaT _ (by
                        have := not_inJobArrRegion_of_blk_ne (cp := cp) r.val (blk := 0)
                          (by omega) (by omega) (by omega) (by omega) (k := (idx : ℤ))
                          (by omega) (by exact_mod_cast lt_of_lt_of_le hidx hleaf_sp.length_le)
                        simpa [leafElemOff] using this))
                      (fun y hy => hfaT _ (by
                        have := not_inJobArrRegion_of_blk_ne (cp := cp) r.val (blk := 1)
                          (by omega) (by omega) (by omega) (by omega) (k := (y : ℤ))
                          (by omega) (by exact_mod_cast hleaf_sp.2.1 y hy)
                        simpa [leafPosOff] using this)),
                    hserv_le,
                    (hfmT 0 (not_inJobMetaRegion_header r.val (by omega) (by have := cp.D_max_pos; omega))).trans hserv_len,
                    servSlots, Function.update readySlots r rSlots', Function.update curSlots r cSlot',
                    hslen, hserv_T, hjobs_T, hall_nd_T, hall_lt_T⟩
                · rw [hfc_succ]
                  exact (hfsT 0 (by omega)).trans hscr0_k
            | inr trip =>
                -- `advRes = Sum.inr (newSuf, newLeaf, newOv)` -> earliest commit at `r`!
                rcases trip with ⟨newSuf, newLeaf, newOv⟩
                have hadv_eq' : advanceOneJob cp pts st₁.gt (st₁.serving[r.val]'hr_serv1) r jb bSeeds ctrSeed = Sum.inr (newSuf, newLeaf, newOv) := hadv_eq
                dsimp only [bSeeds, ctrSeed, ω₂] at hadv_eq'
                rw [hadv_eq'] at hmatchT
                rcases hmatchT with ⟨_, hused_eq, hrlen_eq, hw_rlen_T, hready_enc_T, hcode_T⟩
                have hw10_ne0 : wRead mT engScrTbl 10 ≠ 0 := by
                  rcases hcode_T with ⟨h1, _⟩ | ⟨h2, _⟩ | ⟨h3, _⟩ <;> omega
                have hcond10 : (evalArithCond inp 0 mT
                    (.intEq (.readHeap engScrTbl (.lit 10)) (.lit 0))).1 = false := by
                  simp only [evalArithCond, evalIntExpr]
                  change decide (wRead mT engScrTbl 10 = 0) = false
                  exact decide_eq_false hw10_ne0
                refine ExecDet.ite' (C_c := 8) (C_b := commitJobStage2Cost ops) _ _ _ hcond10
                  (by simp [condExprOps, intExprOps]) (fun ht => by cases ht) (fun _ => ?_) (by omega)
                -- Invoke `advanceOneJob_spec` to get `r.val + newSuf.length ≤ cp.D_max` & `hleaf_spec`!
                have hpre_len : (st₁.serving.take r.val).length ≤ cp.D_max :=
                  (List.length_take_le _ _).trans (Nat.le_of_lt r.isLt)
                have hpre_cl : ChainListInv cp actH pts st₁.gt actH (st₁.serving.take r.val) :=
                  chainListInv_take r.val actH st₁.serving hserv_cl₁
                have hr_eq_pre : (st₁.serving.take r.val).length = r.val :=
                  List.length_take_of_le (Nat.le_of_lt hr_serv1)
                have hadv_spec := advanceOneJob_spec h_lem_5_1 h_clm_7_3 hd he1 cp hh0 hh1
                  hact_card_n hgt_wf hpre_len hpre_cl rfl hS_anc_sub hanc_ln
                  (hserv_age16 r.val hr_serv1) r hr_eq_pre hjb_inv bSeeds ctrSeed
                rw [hadv_eq] at hadv_spec
                rcases hadv_spec with ⟨hr_sum, hnewSuf_cl, _, hleaf_wf_new, _⟩
                have hS_end_sub : foldResiduals pts S_anc newSuf ⊆ actH :=
                  (chainListInv_getElem S_anc newSuf hS_anc_sub hnewSuf_cl).1
                have hleaf_spec : newOv = false →
                    newLeaf.Nodup ∧ (∀ x ∈ newLeaf, x < cp.n) ∧ newLeaf.length ≤ cp.B_scan := by
                  intro hnov
                  rcases hleaf_wf_new hnov with ⟨hnd_lf, hset_lf, hle_lf⟩
                  refine ⟨hnd_lf, fun x hx => hact_lt_n x (hS_end_sub (hset_lf ▸ List.mem_toFinset.mpr hx)), hle_lf⟩
                -- Run `commitJobStage2Stmt ops r` (`CG16_Stage20`)!
                refine (exec_commitJobStage2Stmt ops inp r (Nat.le_of_lt hr_serv1) hslen
                  hr_sum hleaf_spec hfpT hsrT
                  (fun i hi => hserv_T i (lt_trans hi hr_serv1) (lt_trans hi hr_serv_sl))
                  hused_eq hrlen_eq hw_rlen_T hready_enc_T hjobs_T hall_nd_T hall_lt_T hcode_T).mono
                  ?_ le_rfl
                intro mC ⟨hsrC, hscr0_C, hovC, hlf_leC, hlf_spC, hserv2_le, hw0C, hslen2,
                  hserv2_C, hjobs2_C, hall2_nd, hall2_lt, hftC, hfm345_C, hfrC⟩ _
                have hfc_succ : ((List.finRange cp.D_max).take (k + 1)).findSome? (s2CommitAt cp st₁ ω₂) =
                    some (r, newSuf, newLeaf, newOv) := by
                  rw [finRange_take_succ cp.D_max k hk, List.findSome?_append, hfc_k]
                  dsimp [r] at hout_r hadv_eq ⊢; simp [s2CommitAt, hout_r, hadv_eq]
                have hjobs_upd : Function.update (s2JobsNoCommit cp st₁ ω₂ k) r none =
                    s2JobsAfterCommit cp st₁ ω₂ r (k + 1) := by
                  ext r'
                  by_cases heq : r' = r
                  · subst heq
                    have hr_lt_k1 : r.val < k + 1 := by dsimp [r]; omega
                    simp [Function.update_self, s2JobsAfterCommit, Nat.lt_irrefl, hr_lt_k1]
                  · have hne_val : r'.val ≠ k := fun hv => heq (Fin.ext hv)
                    have hlt_iff : (r'.val < r.val) ↔ (r'.val < k) := Iff.rfl
                    have hnot_k1 : ¬ (r'.val < k) → ¬ (r'.val < k + 1) := by omega
                    by_cases hlt : r'.val < k
                    · simp [Function.update_of_ne heq, s2JobsNoCommit, s2JobsAfterCommit, r, hlt]
                    · simp [Function.update_of_ne heq, s2JobsNoCommit, s2JobsAfterCommit, r, hlt, hnot_k1 hlt]
                rw [hjobs_upd] at hjobs2_C hall2_nd hall2_lt
                have hpacC := encPoolAnsCoins_ext hpacT.1 hpacT.2.1 hpacT.2.2.1
                  (fun t ht6 i => hftC t (by omega) (by unfold engMetaTbl; omega)
                    (by unfold engArrTbl; omega) (by unfold engScrTbl; omega) i)
                  hfm345_C
                  (fun t ht2 i => hfrC t (by omega) i)
                  (hfrC engRealTbl (by decide) 0)
                have hst_succ : s2OuterStateAt cp st₁ ω₂ (k + 1) =
                    { st₁ with
                      serving := st₁.serving.take r.val ++ newSuf
                      jobs := s2JobsAfterCommit cp st₁ ω₂ r (k + 1)
                      leafArr := newLeaf
                      leafOverflow := newOv } := by
                  unfold s2OuterStateAt; rw [hfc_succ]
                refine ⟨?_, by rw [hfc_succ]; exact hscr0_C, hpacC.2.2.1, hpacC.2.2.2.trans (hpacT.2.2.2.trans hw00_k)⟩
                rw [hst_succ]
                exact ⟨hsrC, hpacC.1, hpacC.2.1, hovC, hlf_leC, hlf_spC, hserv2_le, hw0C,
                  servSlots.take r.val ++ rSlots',
                  Function.update readySlots r [],
                  Function.update curSlots r 0,
                  hslen2, hserv2_C, hjobs2_C, hall2_nd, hall2_lt⟩
  · intro mMid ⟨hencM, hscr0M, hcoinsM, hw00M⟩ _
    have htake_all : (List.finRange cp.D_max).take (List.finRange cp.D_max).length =
        List.finRange cp.D_max := List.take_length
    simp only [Nat.zero_add, List.length_finRange] at hencM hscr0M
    have htake_D : (List.finRange cp.D_max).take cp.D_max = List.finRange cp.D_max := by
      simp
    rw [htake_D] at hscr0M
    exact ⟨hencM, hscr0M, hcoinsM, hw00M⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
