import UL.Proof.clm_9_1_explicit_tradeoff.CG17_MatchB1
import UL.Proof.clm_9_1_explicit_tradeoff.CG18_NodeB0

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG17

open UL
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt)
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H3b2
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.RacerP43
open UL.Proof.clm_9_1_explicit_tradeoff.CG18

/-! ### 1. Shared Operation Scratch Strides & Applicability Test Conditions -/

def configDynOpWScr {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℤ :=
  16 + sops.sideWScrStride

def configDynOpRScr {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℤ :=
  2 + sops.sideRScrStride

theorem zeroRand_sqDistPtCenterStmt (scrW scrR tblR : ℕ)
    (wOffO wUid wCtr rAcc rDiff : ℤ) (d : ℕ) :
    ZeroRandStmt (sqDistPtCenterStmt scrW scrR tblR wOffO wUid wCtr rAcc rDiff d) := by
  unfold sqDistPtCenterStmt forLoopStmt
  repeat' constructor

def hasLeftCopyCond (scrW scrR tblR m0 j : ℕ) (wOffV rAcc : ℤ) : ArithCondExpr :=
  let dSqE := RealExpr.readRealHeap scrR (.lit rAcc)
  let vE := RealExpr.readRealHeap tblR (.readHeap scrW (.lit wOffV))
  let m0SqD := RealExpr.mul (.ofInt (.lit (((m0 ^ 2 : ℕ) : ℤ)))) dSqE
  let jSqV := RealExpr.mul (.ofInt (.lit (((j ^ 2 : ℕ) : ℤ)))) vE
  let j1SqV := RealExpr.mul (.ofInt (.lit ((((j + 1) ^ 2 : ℕ) : ℤ)))) vE
  .and (.realLe dSqE vE) (.and (.realLe jSqV m0SqD) (.realLt m0SqD j1SqV))

theorem cVal_hasLeftCopyCond_iff {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (scrW scrR tblR m0 j : ℕ) (wOffV rAcc offV : ℤ)
    (o pt : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    (hoffV : H3a.wRead m scrW wOffV = offV)
    (hrAcc : H3a.rRead m scrR rAcc = ‖pt - o‖ ^ 2)
    (hv_r : H3a.rRead m tblR offV = V) :
    cValAt 0 inp m (hasLeftCopyCond scrW scrR tblR m0 j wOffV rAcc) = true ↔
      hasApplicableLeftCopy m0 o V j pt := by
  unfold H3a.wRead at hoffV; unfold H3a.rRead at hrAcc hv_r
  simp only [cValAt, hasLeftCopyCond, evalArithCond, evalRealExpr, evalIntExpr,
    hoffV, hrAcc, hv_r, Bool.and_eq_true, decide_eq_true_eq,
    hasApplicableLeftCopy_iff_sq m0 o hV j pt]
  push_cast; rfl

def hasRightCopyCond (scrW scrR tblR m0 : ℕ) (K : ℤ) (k : ℕ) (wOffV rAcc : ℤ) : ArithCondExpr :=
  let dSqE := RealExpr.readRealHeap scrR (.lit rAcc)
  let vE := RealExpr.readRealHeap tblR (.readHeap scrW (.lit wOffV))
  let m0SqD := RealExpr.mul (.ofInt (.lit (((m0 ^ 2 : ℕ) : ℤ)))) dSqE
  let kSqV := RealExpr.mul (.ofInt (.lit (((k ^ 2 : ℕ) : ℤ)))) vE
  let k1SqV := RealExpr.mul (.ofInt (.lit ((((k + 1) ^ 2 : ℕ) : ℤ)))) vE
  .and (.realLe dSqE (.mul (.ofInt (.lit (K ^ 2))) vE))
       (.and (.realLe kSqV m0SqD) (.realLt m0SqD k1SqV))

theorem cVal_hasRightCopyCond_iff {d : ℕ} (inp : ArithRAMInput d) (m : ArithRAMMemory)
    (scrW scrR tblR m0 : ℕ) {K : ℤ} (hK : 0 ≤ K) (k : ℕ) (wOffV rAcc offV : ℤ)
    (o pt : EuclideanSpace ℝ (Fin d)) {V : ℝ} (hV : 0 < V)
    (hoffV : H3a.wRead m scrW wOffV = offV)
    (hrAcc : H3a.rRead m scrR rAcc = ‖pt - o‖ ^ 2)
    (hv_r : H3a.rRead m tblR offV = V) :
    cValAt 0 inp m (hasRightCopyCond scrW scrR tblR m0 K k wOffV rAcc) = true ↔
      hasApplicableRightCopy m0 o V K k pt := by
  unfold H3a.wRead at hoffV; unfold H3a.rRead at hrAcc hv_r
  simp only [cValAt, hasRightCopyCond, evalArithCond, evalRealExpr, evalIntExpr,
    hoffV, hrAcc, hv_r, Bool.and_eq_true, decide_eq_true_eq,
    hasApplicableRightCopy_iff_sq m0 o hV hK k pt]
  push_cast; rfl

/-! ### 2. `configDynInsertStmt` and `exec_configDynInsertStmt` -/

def configDynInsertCost {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl) : ℕ :=
  260 + 55 * d + 2 * attachCopyCost sops

def configDynInsertStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr : ℤ) : ArithRAMStmt :=
  let wHasL := wScr
  let wHasR := wScr + 1
  let wSub := wScr + 2
  let rAcc := rScr
  let rDiff := rScr + 1
  let b_rat := bRatCfg params spec.cfg
  .seq (sqDistPtCenterStmt scrW scrR tblR wOffO wUid wSub rAcc rDiff d)
  (.seq (.ite (hasLeftCopyCond scrW scrR tblR params.m0 spec.cfg.j wOffV rAcc)
          (.writeWordHeap scrW (.lit wHasL) (.lit 1))
          (.writeWordHeap scrW (.lit wHasL) (.lit 0)))
  (.seq (.ite (hasRightCopyCond scrW scrR tblR params.m0 params.K spec.cfg.k wOffV rAcc)
          (.writeWordHeap scrW (.lit wHasR) (.lit 1))
          (.writeWordHeap scrW (.lit wHasR) (.lit 0)))
  (.seq (.ite (.intEq (.readHeap scrW (.lit wHasL)) (.lit 1))
          (attachLeftCopyStmt sops spec.A spec.B b_rat
            wCfgBaseW wCfgBaseR wOffO wUid wSeedOff wSub rScr)
          .skip)
        (.ite (.intEq (.readHeap scrW (.lit wHasR)) (.lit 1))
          (attachRightCopyStmt sops spec.A spec.B b_rat
            wCfgBaseW wCfgBaseR wOffO wUid wSeedOff wSub rScr)
          .skip))))

theorem zeroRand_configDynInsertStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr : ℤ) :
    ZeroRandStmt (configDynInsertStmt sops spec
      wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr) :=
  .seq (zeroRand_sqDistPtCenterStmt _ _ _ _ _ _ _ _ _)
  (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
  (.seq (.ite (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))
  (.seq (.ite (zeroRand_attachLeftCopyStmt sops _ _ _ _ _ _ _ _ _ _) .skip)
        (.ite (zeroRand_attachRightCopyStmt sops _ _ _ _ _ _ _ _ _ _) .skip))))

theorem exec_configDynInsertStmt {d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat : ℕ}
    {params : LocalScaleParams} {h : ℝ}
    {τ_d τ_q : ℚ} {cap_u cap_q : ℕ} {scrW scrR tblW tblR coinTbl : ℕ}
    (sops : SideRAMOps d n L_p2 R ℓ M₀ b T_cdf p_coord M_lat τ_d τ_q cap_u cap_q
      scrW scrR tblW tblR coinTbl)
    {TW BW TR BR : ℕ} (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (hM₀ : 1 ≤ M₀) (hn : 2 ≤ n) (hL_p2 : 4 * n + 4 ≤ 2 ^ L_p2)
    (spec : ConfigStaticSpec d params h)
    (wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr
      cfgBaseW cfgBaseR offO offV seedOff : ℤ)
    {pts : ℕ → EuclideanSpace ℝ (Fin d)} {o : EuclideanSpace ℝ (Fin d)} {V : ℝ} (hV : 0 < V)
    {S : Finset ℕ} {p : ℕ} (hp_not : p ∉ S) (hp_lt : p < n)
    (_hS_lt : ∀ x ∈ S, x < n) (_hS_card : S.card + 1 ≤ n)
    (ω_L ω_R : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    {cs : ConfigDynamicState L_p2 R ℓ M₀ d b}
    (htL : cs.leftIdx.t_ins + 1 < 2 ^ L_p2) (htR : cs.rightIdx.t_ins + 1 < 2 ^ L_p2)
    (hwf : ConfigDynamicWF hM₀ T_cdf p_coord params spec.A spec.B τ_d cap_u pts o V S spec.cfg cs)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hvt : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl)
    (hbaseW : 0 ≤ cfgBaseW ∧ cfgBaseW + cfgTotalWStride n sops.sideWStride ≤ (BW : ℤ))
    (hbaseR : 0 ≤ cfgBaseR ∧ cfgBaseR + cfgTotalRStride sops.sideRStride ≤ (BR : ℤ))
    (hoffO : 0 ≤ offO ∧ offO + (d : ℤ) ≤ cfgBaseR)
    (_hoffV : 0 ≤ offV ∧ offV < cfgBaseR)
    (hseedB : 0 ≤ seedOff ∧ seedOff + (cfgSeedBits L_p2 R ℓ M₀ d b : ℤ) ≤ (BW : ℤ))
    (hptsB : ((n * d : ℕ) : ℤ) ≤ (BR : ℤ))
    (hwBW : 0 ≤ wCfgBaseW ∧ wCfgBaseW < wScr)
    (hwBR : 0 ≤ wCfgBaseR ∧ wCfgBaseR < wScr)
    (hwO : 0 ≤ wOffO ∧ wOffO < wScr)
    (hwV : 0 ≤ wOffV ∧ wOffV < wScr)
    (hwUid : 0 ≤ wUid ∧ wUid < wScr)
    (hwSeed : 0 ≤ wSeedOff ∧ wSeedOff < wScr)
    (hwScr : 0 ≤ wScr ∧ wScr + configDynOpWScr sops ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + configDynOpRScr sops ≤ (BR : ℤ))
    (hbW : H3a.wRead m₀ scrW wCfgBaseW = cfgBaseW)
    (hbR : H3a.wRead m₀ scrW wCfgBaseR = cfgBaseR)
    (ho_off : H3a.wRead m₀ scrW wOffO = offO)
    (hv_off : H3a.wRead m₀ scrW wOffV = offV)
    (hp_r : H3a.wRead m₀ scrW wUid = (p : ℤ))
    (hseed_off : H3a.wRead m₀ scrW wSeedOff = seedOff)
    (ho_mem : ∀ c : Fin d, H3a.rRead m₀ tblR (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hv_mem : H3a.rRead m₀ tblR offV = V)
    (hpts : ∀ x ∈ Insert.insert p S, ∀ c : Fin d,
      H3a.rRead m₀ 1 (((x * d + c.val : ℕ) : ℤ)) = euclideanCoord (pts x) c)
    (hseed : EncCfgSeedSlice coinTbl seedOff ω_L ω_R m₀)
    (henc : EncCfgDyn sops cfgBaseW cfgBaseR cs m₀) :
    ∃ m₁ : ArithRAMMemory,
      DetExec inp (configDynInsertStmt sops spec
        wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr)
        m₀ m₁ (configDynInsertCost sops) ∧
      InFootprint TW BW TR BR m₁ ∧
      EncCfgDyn sops cfgBaseW cfgBaseR
        (cs.insertOriginal hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg p ω_L ω_R) m₁ ∧
      (∀ w, w < wScr → H3a.wRead m₁ scrW w = H3a.wRead m₀ scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW (cfgTotalWStride n sops.sideWStride)
        tblR cfgBaseR (cfgTotalRStride sops.sideRStride) m₀ m₁ := by
  have hwScr1 := sops.hsideWScr_pos
  have hrScr1 := sops.hsideRScr_pos
  have hwScr' : 0 ≤ wScr ∧ wScr + (16 + sops.sideWScrStride) ≤ (BW : ℤ) := hwScr
  have hrScr' : 0 ≤ rScr ∧ rScr + (2 + sops.sideRScrStride) ≤ (BR : ℤ) := hrScr
  rcases hvt with ⟨hscrW, htblW, hcoinTbl, hscrR, htblR, h1TR,
    hneW, hneCoinScr, hneCoinTbl, hneR, hne1Scr, hne1TblR⟩
  have hvt' : ValidNodeTables TW TR scrW scrR tblW tblR coinTbl :=
    ⟨hscrW, htblW, hcoinTbl, hscrR, htblR, h1TR,
     hneW, hneCoinScr, hneCoinTbl, hneR, hne1Scr, hne1TblR⟩
  have hdj₀ := IndexDisjoint.of_wellFormed hwf.1
  obtain ⟨hpairs_sub, hUL_sub, hUR_sub⟩ := wellFormed_subsets hwf.1
  have hVL_S := leftVertices_subset params pts o V S spec.cfg.j
  have hVR_S := rightVertices_subset params pts o V S spec.cfg.k
  have hp_not_L : p ∉ (cs.st.matchingList.map MatchingEdge.pair).map Prod.fst := by
    intro hm
    rcases List.mem_map.mp hm with ⟨xy, hxy, rfl⟩
    exact hp_not (hVL_S (hpairs_sub xy hxy).1)
  have hp_not_R : p ∉ (cs.st.matchingList.map MatchingEdge.pair).map Prod.snd := by
    intro hm
    rcases List.mem_map.mp hm with ⟨xy, hxy, rfl⟩
    exact hp_not (hVR_S (hpairs_sub xy hxy).2)
  have hp_not_UL : p ∉ cs.st.leftIndexSet := fun hm => hp_not (hVL_S (hUL_sub hm))
  have hp_not_UR : p ∉ cs.st.rightIndexSet := fun hm => hp_not (hVR_S (hUR_sub hm))
  rcases retainedConfig_shells_pos params spec.mem_one with ⟨hj1, _, hk1, _, _⟩
  have hK_nn : (0 : ℤ) ≤ params.K := le_of_lt (params_K_pos params)
  let totW := cfgTotalWStride n sops.sideWStride
  let totR := cfgTotalRStride sops.sideRStride
  let wHasL := wScr
  let wHasR := wScr + 1
  let wSub := wScr + 2
  let rAcc := rScr
  let rDiff := rScr + 1
  -- Step 1: `sqDistPtCenterStmt` (`m₀ -> m1`)
  obtain ⟨m1, hd1, hfp1, hrAcc1, hw1, _, hpr1⟩ :=
    exec_sqDistPtCenterStmt inp wOffO wUid wSub rAcc rDiff offO p (pts p) o
      hfp₀ hscrW hscrR hneR hne1Scr
      ⟨by omega, by omega⟩ ⟨by omega, by omega⟩ ⟨by omega, by omega⟩
      (by omega) ⟨by omega, by omega⟩ ho_off hp_r
      (hpts p (Finset.mem_insert_self p S)) ho_mem
  have hfr01 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m₀ m1 :=
    ⟨fun t i hs _ => hpr1.1 t hs i, fun t i hs _ => hpr1.2 t hs i⟩
  -- Step 2: evaluate `hasLeftCopyCond` into `wHasL` (`m1 -> m2`)
  have hcL_iff := cVal_hasLeftCopyCond_iff inp m1 scrW scrR tblR params.m0 spec.cfg.j
    wOffV rAcc offV o (pts p) hV
    ((hw1 wOffV (by omega)).trans hv_off) hrAcc1
    ((hpr1.2 tblR hneR offV).trans hv_mem)
  have hstep2 : ∃ m2 : ArithRAMMemory,
      DetExec inp (.ite (hasLeftCopyCond scrW scrR tblR params.m0 spec.cfg.j wOffV rAcc)
        (.writeWordHeap scrW (.lit wHasL) (.lit 1))
        (.writeWordHeap scrW (.lit wHasL) (.lit 0))) m1 m2 55 ∧
      InFootprint TW BW TR BR m2 ∧
      H3a.wRead m2 scrW wHasL =
        (open Classical in if hasApplicableLeftCopy params.m0 o V spec.cfg.j (pts p) then 1 else 0) ∧
      (∀ w, w ≠ wHasL → H3a.wRead m2 scrW w = H3a.wRead m1 scrW w) ∧
      H3a.rRead m2 scrR rAcc = ‖pts p - o‖ ^ 2 ∧
      PreservesNonScratch scrW scrR m1 m2 := by
    by_cases hL : hasApplicableLeftCopy params.m0 o V spec.cfg.j (pts p)
    · have hct : cValAt 0 inp m1 (hasLeftCopyCond scrW scrR tblR params.m0 spec.cfg.j wOffV rAcc) = true :=
        hcL_iff.mpr hL
      let m2 := H3a.wWrite m1 scrW wHasL 1
      have hdw : DetExec inp (.writeWordHeap scrW (.lit wHasL) (.lit 1)) m1 m2 15 :=
        DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wHasL) (.lit 1) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m2, (DetExecAt.ite_true (C_c := 40) hct
        (by dsimp [hasLeftCopyCond, UL.Proof_lem_7_2_RacerP33.condExprOps,
              UL.Proof_lem_7_2_RacerP33.realExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hdw).mono_cost (by omega),
        InFootprint.wWrite hfp1 hscrW (by omega) (by omega),
        by rw [if_pos hL]; exact wRead_wWrite_self _ _ _ _,
        fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
        (rRead_wWrite m1 scrR scrW rAcc wHasL 1).trans hrAcc1,
        ⟨fun t ht i => wRead_wWrite_of_ne _ _ (Or.inl ht),
         fun t _ i => rRead_wWrite m1 t scrW i wHasL 1⟩⟩
    · have hcf : cValAt 0 inp m1 (hasLeftCopyCond scrW scrR tblR params.m0 spec.cfg.j wOffV rAcc) = false :=
        Bool.eq_false_iff.mpr (fun ht => hL (hcL_iff.mp ht))
      let m2 := H3a.wWrite m1 scrW wHasL 0
      have hdw : DetExec inp (.writeWordHeap scrW (.lit wHasL) (.lit 0)) m1 m2 15 :=
        DetExecAt.writeWordHeap 0 inp m1 scrW (.lit wHasL) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m2, (DetExecAt.ite_false (C_c := 40) hcf
        (by dsimp [hasLeftCopyCond, UL.Proof_lem_7_2_RacerP33.condExprOps,
              UL.Proof_lem_7_2_RacerP33.realExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hdw).mono_cost (by omega),
        InFootprint.wWrite hfp1 hscrW (by omega) (by omega),
        by rw [if_neg hL]; exact wRead_wWrite_self _ _ _ _,
        fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
        (rRead_wWrite m1 scrR scrW rAcc wHasL 0).trans hrAcc1,
        ⟨fun t ht i => wRead_wWrite_of_ne _ _ (Or.inl ht),
         fun t _ i => rRead_wWrite m1 t scrW i wHasL 0⟩⟩
  obtain ⟨m2, hd2, hfp2, hhasL2, hw2_keep, hrAcc2, hpr2⟩ := hstep2
  -- Step 3: evaluate `hasRightCopyCond` into `wHasR` (`m2 -> m3`)
  have hpr02 := hpr1.trans hpr2
  have hcR_iff := cVal_hasRightCopyCond_iff inp m2 scrW scrR tblR params.m0 hK_nn spec.cfg.k
    wOffV rAcc offV o (pts p) hV
    ((hw2_keep wOffV (by omega)).trans ((hw1 wOffV (by omega)).trans hv_off)) hrAcc2
    ((hpr02.2 tblR hneR offV).trans hv_mem)
  have hstep3 : ∃ m3 : ArithRAMMemory,
      DetExec inp (.ite (hasRightCopyCond scrW scrR tblR params.m0 params.K spec.cfg.k wOffV rAcc)
        (.writeWordHeap scrW (.lit wHasR) (.lit 1))
        (.writeWordHeap scrW (.lit wHasR) (.lit 0))) m2 m3 55 ∧
      InFootprint TW BW TR BR m3 ∧
      H3a.wRead m3 scrW wHasR =
        (open Classical in if hasApplicableRightCopy params.m0 o V params.K spec.cfg.k (pts p) then 1 else 0) ∧
      (∀ w, w ≠ wHasR → H3a.wRead m3 scrW w = H3a.wRead m2 scrW w) ∧
      PreservesNonScratch scrW scrR m2 m3 := by
    by_cases hR : hasApplicableRightCopy params.m0 o V params.K spec.cfg.k (pts p)
    · have hct : cValAt 0 inp m2 (hasRightCopyCond scrW scrR tblR params.m0 params.K spec.cfg.k wOffV rAcc) = true :=
        hcR_iff.mpr hR
      let m3 := H3a.wWrite m2 scrW wHasR 1
      have hdw : DetExec inp (.writeWordHeap scrW (.lit wHasR) (.lit 1)) m2 m3 15 :=
        DetExecAt.writeWordHeap 0 inp m2 scrW (.lit wHasR) (.lit 1) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m3, (DetExecAt.ite_true (C_c := 40) hct
        (by dsimp [hasRightCopyCond, UL.Proof_lem_7_2_RacerP33.condExprOps,
              UL.Proof_lem_7_2_RacerP33.realExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hdw).mono_cost (by omega),
        InFootprint.wWrite hfp2 hscrW (by omega) (by omega),
        by rw [if_pos hR]; exact wRead_wWrite_self _ _ _ _,
        fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
        ⟨fun t ht i => wRead_wWrite_of_ne _ _ (Or.inl ht),
         fun t _ i => rRead_wWrite m2 t scrW i wHasR 1⟩⟩
    · have hcf : cValAt 0 inp m2 (hasRightCopyCond scrW scrR tblR params.m0 params.K spec.cfg.k wOffV rAcc) = false :=
        Bool.eq_false_iff.mpr (fun ht => hR (hcR_iff.mp ht))
      let m3 := H3a.wWrite m2 scrW wHasR 0
      have hdw : DetExec inp (.writeWordHeap scrW (.lit wHasR) (.lit 0)) m2 m3 15 :=
        DetExecAt.writeWordHeap 0 inp m2 scrW (.lit wHasR) (.lit 0) rfl rfl
          (by dsimp [UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
      refine ⟨m3, (DetExecAt.ite_false (C_c := 40) hcf
        (by dsimp [hasRightCopyCond, UL.Proof_lem_7_2_RacerP33.condExprOps,
              UL.Proof_lem_7_2_RacerP33.realExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hdw).mono_cost (by omega),
        InFootprint.wWrite hfp2 hscrW (by omega) (by omega),
        by rw [if_neg hR]; exact wRead_wWrite_self _ _ _ _,
        fun w hw => wRead_wWrite_of_ne _ _ (Or.inr hw),
        ⟨fun t ht i => wRead_wWrite_of_ne _ _ (Or.inl ht),
         fun t _ i => rRead_wWrite m2 t scrW i wHasR 0⟩⟩
  obtain ⟨m3, hd3, hfp3, hhasR3, hw3_keep, hpr3⟩ := hstep3
  have hpr03 := hpr02.trans hpr3
  have hfr03 : RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m₀ m3 :=
    ⟨fun t i hs _ => hpr03.1 t hs i, fun t i hs _ => hpr03.2 t hs i⟩
  have hscr03 : ∀ w, w < wScr → H3a.wRead m3 scrW w = H3a.wRead m₀ scrW w :=
    fun w hw => (hw3_keep w (by omega)).trans ((hw2_keep w (by omega)).trans (hw1 w (by omega)))
  have hhasL3 : H3a.wRead m3 scrW wHasL =
      (open Classical in if hasApplicableLeftCopy params.m0 o V spec.cfg.j (pts p) then 1 else 0) :=
    (hw3_keep wHasL (by omega)).trans hhasL2
  have henc3 : EncCfgDyn sops cfgBaseW cfgBaseR cs m3 :=
    henc.mono_slice sops (fun i _ _ => hpr03.1 tblW hneW i) (fun i _ _ => hpr03.2 tblR hneR i)
  obtain ⟨ho3, h1_3, hseed3⟩ := rfo_preserves_env hvt' hoffO hfr03 ho_mem hseed
  -- Step 4: conditional `attachLeftCopyStmt` (`m3 -> m4`)
  let cs₁ : ConfigDynamicState L_p2 R ℓ M₀ d b :=
    open Classical in
    if hasApplicableLeftCopy params.m0 o V spec.cfg.j (pts p) then
      attachCopyStep hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q cap_u cap_q
        pts o V spec.cfg ⟨.left, p⟩ ω_L ω_R cs
    else cs
  have hstep4 : ∃ m4 : ArithRAMMemory,
      DetExec inp (.ite (.intEq (.readHeap scrW (.lit wHasL)) (.lit 1))
        (attachLeftCopyStmt sops spec.A spec.B (bRatCfg params spec.cfg)
          wCfgBaseW wCfgBaseR wOffO wUid wSeedOff wSub rScr)
        .skip) m3 m4 (20 + attachCopyCost sops) ∧
      InFootprint TW BW TR BR m4 ∧
      EncCfgDyn sops cfgBaseW cfgBaseR cs₁ m4 ∧
      (∀ w, w < wSub → H3a.wRead m4 scrW w = H3a.wRead m3 scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m3 m4 ∧
      IndexDisjoint cs₁.st ∧
      DyadicSideWF hM₀ T_cdf p_coord spec.A spec.B τ_d cap_u pts o cs₁.st.leftIndexSet cs₁.leftIdx ∧
      DyadicSideWF hM₀ T_cdf p_coord spec.A spec.B τ_d cap_u pts o cs₁.st.rightIndexSet cs₁.rightIdx ∧
      cs₁.leftIdx.t_ins ≤ cs.leftIdx.t_ins + 1 ∧
      cs₁.rightIdx.t_ins = cs.rightIdx.t_ins ∧
      cs₁.st.leftIndexSet ⊆ Insert.insert p S ∧
      cs₁.st.rightIndexSet ⊆ S ∧
      p ∉ (cs₁.st.matchingList.map MatchingEdge.pair).map Prod.snd ∧
      p ∉ cs₁.st.rightIndexSet := by
    by_cases hL : hasApplicableLeftCopy params.m0 o V spec.cfg.j (pts p)
    · have hp_ne_o : pts p ≠ o := ne_center_of_shellIndex_pos hj1 hL.2
      have hct : cValAt 0 inp m3 (.intEq (.readHeap scrW (.lit wHasL)) (.lit 1)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m3 scrW wHasL = 1) = true
        rw [hhasL3, if_pos hL]; rfl
      obtain ⟨m4, hd4, hfp4, henc4, hkW4, hfr34⟩ :=
        exec_attachLeftCopyStmt sops inp hM₀ hn hL_p2 params spec.cfg spec.hAB
          wCfgBaseW wCfgBaseR wOffO wUid wSeedOff wSub rScr cfgBaseW cfgBaseR offO seedOff
          hV hp_lt hp_ne_o ω_L ω_R hdj₀ hp_not_L hp_not_UL
          htL (by omega) hwf.2.2.1 hwf.2.2.2 hfp3 hvt' hbaseW hbaseR hoffO hseedB hptsB
          ⟨hwBW.1, by omega⟩ ⟨hwBR.1, by omega⟩ ⟨hwO.1, by omega⟩
          ⟨hwUid.1, by omega⟩ ⟨hwSeed.1, by omega⟩
          ⟨by omega, by unfold attachCopyWScr; omega⟩
          ⟨hrScr.1, by omega⟩
          ((hscr03 wCfgBaseW hwBW.2).trans hbW)
          ((hscr03 wCfgBaseR hwBR.2).trans hbR)
          ((hscr03 wOffO hwO.2).trans ho_off)
          ((hscr03 wUid hwUid.2).trans hp_r)
          ((hscr03 wSeedOff hwSeed.2).trans hseed_off)
          ho3
          (fun x hx c => (h1_3 _).trans (hpts x (by
            rcases Finset.mem_insert.mp hx with hxp | hx0
            · exact hxp ▸ Finset.mem_insert_self p S
            · exact Finset.mem_insert_of_mem (hVL_S (hUL_sub hx0))) c))
          (fun x hx c => (h1_3 _).trans (hpts x (by
            rcases Finset.mem_insert.mp hx with hxp | hx0
            · exact hxp ▸ Finset.mem_insert_self p S
            · exact Finset.mem_insert_of_mem (hVR_S (hUR_sub hx0))) c))
          hseed3 henc3
      obtain ⟨hdj₁, hwfL₁, hwfR₁, htL₁, htR₁, hsubL₁, hsubR₁, hkeep_p⟩ :=
        attachCopyStep_left_props hM₀ T_cdf p_coord M_lat params spec.hAB τ_d τ_q cap_u cap_q
          pts o hV spec.cfg p ω_L ω_R cs hdj₀ hp_not_L hp_not_UL hp_ne_o hwf.2.2.1 hwf.2.2.2
      have hcs₁_eq : cs₁ = attachCopyStep hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg ⟨.left, p⟩ ω_L ω_R cs := by
        dsimp [cs₁]; rw [if_pos hL]
      rw [hcs₁_eq]
      exact ⟨m4, (DetExecAt.ite_true (C_c := 15) hct
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hd4).mono_cost (by omega),
        hfp4, henc4, hkW4, hfr34, hdj₁, hwfL₁, hwfR₁, htL₁, htR₁,
        fun x hx => by
          rcases Finset.mem_insert.mp (hsubL₁ hx) with hxp | hx0
          · exact hxp ▸ Finset.mem_insert_self p S
          · exact Finset.mem_insert_of_mem (hVL_S (hUL_sub hx0)),
        fun x hx => hVR_S (hUR_sub (hsubR₁ hx)),
        (hkeep_p p hp_not_R hp_not_UR).1,
        (hkeep_p p hp_not_R hp_not_UR).2⟩
    · have hcf : cValAt 0 inp m3 (.intEq (.readHeap scrW (.lit wHasL)) (.lit 1)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m3 scrW wHasL = 1) = false
        rw [hhasL3, if_neg hL]; rfl
      have hcs₁_eq : cs₁ = cs := by dsimp [cs₁]; rw [if_neg hL]
      rw [hcs₁_eq]
      exact ⟨m3, (DetExecAt.ite_false (C_c := 15) hcf
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.skip 0 inp m3)).mono_cost (by omega),
        hfp3, henc3, fun _ _ => rfl, RadFrameOutside.refl _ _ _ _ _ _ _ _ m3,
        hdj₀, hwf.2.2.1, hwf.2.2.2, Nat.le_succ _, rfl,
        fun x hx => Finset.mem_insert_of_mem (hVL_S (hUL_sub hx)),
        fun x hx => hVR_S (hUR_sub hx),
        hp_not_R, hp_not_UR⟩
  obtain ⟨m4, hd4, hfp4, henc4, hkW4, hfr34, hdj₁, hwfL₁, hwfR₁, htL₁, htR₁,
    hUL₁_sub, hUR₁_sub, hp_not_R₁, hp_not_UR₁⟩ := hstep4
  have hfr04 := hfr03.trans hfr34
  obtain ⟨ho4, h1_4, hseed4⟩ := rfo_preserves_env hvt' hoffO hfr04 ho_mem hseed
  have hscr04 : ∀ w, w < wScr → H3a.wRead m4 scrW w = H3a.wRead m₀ scrW w :=
    fun w hw => (hkW4 w (by omega)).trans (hscr03 w hw)
  have hhasR4 : H3a.wRead m4 scrW wHasR =
      (open Classical in if hasApplicableRightCopy params.m0 o V params.K spec.cfg.k (pts p) then 1 else 0) :=
    (hkW4 wHasR (by omega)).trans hhasR3
  -- Step 5: conditional `attachRightCopyStmt` (`m4 -> m5`)
  let cs₂ : ConfigDynamicState L_p2 R ℓ M₀ d b :=
    open Classical in
    if hasApplicableRightCopy params.m0 o V params.K spec.cfg.k (pts p) then
      attachCopyStep hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q cap_u cap_q
        pts o V spec.cfg ⟨.right, p⟩ ω_L ω_R cs₁
    else cs₁
  have hstep5 : ∃ m5 : ArithRAMMemory,
      DetExec inp (.ite (.intEq (.readHeap scrW (.lit wHasR)) (.lit 1))
        (attachRightCopyStmt sops spec.A spec.B (bRatCfg params spec.cfg)
          wCfgBaseW wCfgBaseR wOffO wUid wSeedOff wSub rScr)
        .skip) m4 m5 (20 + attachCopyCost sops) ∧
      InFootprint TW BW TR BR m5 ∧
      EncCfgDyn sops cfgBaseW cfgBaseR cs₂ m5 ∧
      (∀ w, w < wSub → H3a.wRead m5 scrW w = H3a.wRead m4 scrW w) ∧
      RadFrameOutside scrW scrR tblW cfgBaseW totW tblR cfgBaseR totR m4 m5 := by
    by_cases hR : hasApplicableRightCopy params.m0 o V params.K spec.cfg.k (pts p)
    · have hp_ne_o : pts p ≠ o := ne_center_of_shellIndex_pos hk1 hR.2
      have hct : cValAt 0 inp m4 (.intEq (.readHeap scrW (.lit wHasR)) (.lit 1)) = true := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m4 scrW wHasR = 1) = true
        rw [hhasR4, if_pos hR]; rfl
      obtain ⟨m5, hd5, hfp5, henc5, hkW5, hfr45⟩ :=
        exec_attachRightCopyStmt sops inp hM₀ hn hL_p2 params spec.cfg spec.hAB
          wCfgBaseW wCfgBaseR wOffO wUid wSeedOff wSub rScr cfgBaseW cfgBaseR offO seedOff
          hV hp_lt hp_ne_o ω_L ω_R hdj₁ hp_not_R₁ hp_not_UR₁
          (by omega) (by omega) hwfL₁ hwfR₁ hfp4 hvt' hbaseW hbaseR hoffO hseedB hptsB
          ⟨hwBW.1, by omega⟩ ⟨hwBR.1, by omega⟩ ⟨hwO.1, by omega⟩
          ⟨hwUid.1, by omega⟩ ⟨hwSeed.1, by omega⟩
          ⟨by omega, by unfold attachCopyWScr; omega⟩
          ⟨hrScr.1, by omega⟩
          ((hscr04 wCfgBaseW hwBW.2).trans hbW)
          ((hscr04 wCfgBaseR hwBR.2).trans hbR)
          ((hscr04 wOffO hwO.2).trans ho_off)
          ((hscr04 wUid hwUid.2).trans hp_r)
          ((hscr04 wSeedOff hwSeed.2).trans hseed_off)
          ho4
          (fun x hx c => (h1_4 _).trans (hpts x (by
            rcases Finset.mem_insert.mp hx with hxp | hx0
            · exact hxp ▸ Finset.mem_insert_self p S
            · exact hUL₁_sub hx0) c))
          (fun x hx c => (h1_4 _).trans (hpts x (by
            rcases Finset.mem_insert.mp hx with hxp | hx0
            · exact hxp ▸ Finset.mem_insert_self p S
            · exact Finset.mem_insert_of_mem (hUR₁_sub hx0)) c))
          hseed4 henc4
      have hcs₂_eq : cs₂ = attachCopyStep hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
          cap_u cap_q pts o V spec.cfg ⟨.right, p⟩ ω_L ω_R cs₁ := by
        dsimp [cs₂]; rw [if_pos hR]
      rw [hcs₂_eq]
      exact ⟨m5, (DetExecAt.ite_true (C_c := 15) hct
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        hd5).mono_cost (by omega),
        hfp5, henc5, hkW5, hfr45⟩
    · have hcf : cValAt 0 inp m4 (.intEq (.readHeap scrW (.lit wHasR)) (.lit 1)) = false := by
        simp only [cValAt, evalArithCond, evalIntExpr]
        change decide (H3a.wRead m4 scrW wHasR = 1) = false
        rw [hhasR4, if_neg hR]; rfl
      have hcs₂_eq : cs₂ = cs₁ := by dsimp [cs₂]; rw [if_neg hR]
      rw [hcs₂_eq]
      exact ⟨m4, (DetExecAt.ite_false (C_c := 15) hcf
        (by dsimp [UL.Proof_lem_7_2_RacerP33.condExprOps, UL.Proof_lem_7_2_RacerP33.intExprOps]; omega)
        (DetExecAt.skip 0 inp m4)).mono_cost (by omega),
        hfp4, henc4, fun _ _ => rfl, RadFrameOutside.refl _ _ _ _ _ _ _ _ m4⟩
  obtain ⟨m5, hd5, hfp5, henc5, hkW5, hfr45⟩ := hstep5
  have hins_eq := insertOriginal_eq_steps hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
    cap_u cap_q pts o V spec.cfg p ω_L ω_R cs
  have hcs_final : cs.insertOriginal hM₀ T_cdf p_coord M_lat params spec.A spec.B τ_d τ_q
      cap_u cap_q pts o V spec.cfg p ω_L ω_R = cs₂ := hins_eq
  rw [hcs_final]
  have hd_all : DetExec inp (configDynInsertStmt sops spec
      wCfgBaseW wCfgBaseR wOffO wOffV wUid wSeedOff wScr rScr)
      m₀ m5 (configDynInsertCost sops) :=
    (hd1.seq (hd2.seq (hd3.seq (hd4.seq hd5)))).mono_cost
      (by unfold configDynInsertCost; omega)
  exact ⟨m5, hd_all, hfp5, henc5,
    fun w hw => (hkW5 w (by omega)).trans (hscr04 w hw),
    hfr04.trans hfr45⟩

end UL.Proof.clm_9_1_explicit_tradeoff.CG17
