import Mathlib
import UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2A
set_option autoImplicit false
set_option maxHeartbeats 800000
set_option linter.unusedSimpArgs false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a
open UL.Proof.clm_9_1_explicit_tradeoff.H3a2
open UL.Proof.clm_9_1_explicit_tradeoff.H4a1
open UL.Proof.clm_9_1_explicit_tradeoff.H4b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c1
open UL.Proof.clm_9_1_explicit_tradeoff.H4c2
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3a
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3b
open UL.Proof.clm_9_1_explicit_tradeoff.H4c3c
open UL.Proof.clm_9_1_explicit_tradeoff.C14d1
open UL.Proof.clm_9_1_explicit_tradeoff.C14d2
open UL.Proof.clm_9_1_explicit_tradeoff.CG19

/-! ### 5. Serving-Slot Splice & Append Primitives (`spliceReadyToServStmt`, `appendSlotToServStmt`) -/

def spliceReadyToServStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) : ArithRAMStmt :=
  let base := jobMetaBase cp r.val
  .seq (.writeWordHeap engScrTbl (.lit 30) (.readHeap engMetaTbl (.lit (base + 1))))
  (.seq (dynForLoopStmt 27 30
          (.writeWordHeap engMetaTbl
            (.add (.lit (servSlotOff r.val)) (.readHeap engScrTbl (.lit 27)))
            (.readHeap engMetaTbl
              (.add (.lit (readySlotOff cp r.val 0)) (.readHeap engScrTbl (.lit 27))))))
        (.writeWordHeap engMetaTbl (.lit 0)
          (.add (.lit (r.val : ℤ)) (.readHeap engScrTbl (.lit 30)))))

theorem zeroRand_spliceReadyToServStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    (cp : ChainParams d params h) (r : Fin cp.D_max) :
    ZeroRandStmt (spliceReadyToServStmt cp r) :=
  .seq (.writeWordHeap _ _ _)
    (.seq (zeroRand_dynForLoopStmt 27 30 (.writeWordHeap _ _ _))
          (.writeWordHeap _ _ _))

theorem exec_spliceReadyToServStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (r : Fin cp.D_max)
    {m₀ : ArithRAMMemory} {servSlots rSlots : List ℕ}
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hr_serv : r.val ≤ servSlots.length)
    (hr_sum : r.val + rSlots.length ≤ cp.D_max)
    (hw_rlen : wRead m₀ engMetaTbl (jobMetaBase cp r.val + 1) = (rSlots.length : ℤ))
    (hserv_pre : ∀ i (hi : i < r.val),
      wRead m₀ engMetaTbl (servSlotOff i) = (servSlots[i]'(lt_of_lt_of_le hi hr_serv) : ℤ))
    (hready_slots : ∀ q (hq : q < rSlots.length),
      wRead m₀ engMetaTbl (readySlotOff cp r.val q) = (rSlots[q]'hq : ℤ)) :
    let newServSlots := servSlots.take r.val ++ rSlots
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (spliceReadyToServStmt cp r) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        newServSlots.length = r.val + rSlots.length ∧
        wRead m₁ engMetaTbl 0 = ((r.val + rSlots.length : ℕ) : ℤ) ∧
        (∀ i (his : i < newServSlots.length),
          wRead m₁ engMetaTbl (servSlotOff i) = (newServSlots[i]'his : ℤ)) ∧
        (∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁) ∧
        (∀ t, t ≠ engMetaTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 0 → ¬ (16 ≤ i ∧ i < 16 + (cp.D_max : ℤ)) →
          wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, i < 20 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      (60 + cp.D_max * 30) := by
  intro newServSlots
  have hTW := ops.hTW; have hBW_meta := ops.hBW_meta; have hBW_scr := ops.hBW_scr
  have hnew_len : newServSlots.length = r.val + rSlots.length := by
    simp [newServSlots, List.length_take_of_le hr_serv]
  unfold spliceReadyToServStmt
  refine ExecDet.seq' (48 + cp.D_max * 30)
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 30)
      (.readHeap engMetaTbl (.lit (jobMetaBase cp r.val + 1))) 30 (rSlots.length : ℤ)
      hfp₀ (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
      (by simp only [evalIntExpr]; exact hw_rlen) (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m1 hm1 hfp1; subst hm1
  set m1_st := H3a.wWrite m₀ engScrTbl 30 (rSlots.length : ℤ)
  let Inv (k : ℕ) (m : ArithRAMMemory) : Prop :=
    wRead m engScrTbl 30 = (rSlots.length : ℤ) ∧
    (∀ i (hi : i < r.val),
      wRead m engMetaTbl (servSlotOff i) = (servSlots[i]'(lt_of_lt_of_le hi hr_serv) : ℤ)) ∧
    (∀ q, q < k → ∀ hq : q < rSlots.length,
      wRead m engMetaTbl (servSlotOff (r.val + q)) = (rSlots[q]'hq : ℤ)) ∧
    (∀ t, t ≠ engMetaTbl → t ≠ engScrTbl → ∀ i, wRead m t i = wRead m₀ t i) ∧
    (∀ i, ¬ (16 ≤ i ∧ i < 16 + (cp.D_max : ℤ)) →
      wRead m engMetaTbl i = wRead m₀ engMetaTbl i) ∧
    (∀ i, i < 20 → wRead m engScrTbl i = wRead m₀ engScrTbl i) ∧
    (∀ t i, rRead m t i = rRead m₀ t i)
  have hInv0 : Inv 0 (H3a.wWrite m1_st engScrTbl 27 0) := by
    refine ⟨by simp [m1_st, wRead_wWrite_eq],
      fun i hi => by simp only [m1_st, wRead_wWrite_eq]; simp [engScrTbl, engMetaTbl, hserv_pre i hi],
      fun _ h => absurd h (Nat.not_lt_zero _),
      fun t ht1 ht2 i => by simp only [m1_st, wRead_wWrite_eq]; simp [ht2],
      fun i _ => by simp only [m1_st, wRead_wWrite_eq]; simp [engScrTbl, engMetaTbl],
      fun i hi20 => by
        simp only [m1_st, wRead_wWrite_eq]
        have : i ≠ 27 ∧ i ≠ 30 := by omega
        simp [this],
      fun t i => by simp [m1_st, rRead_wWrite]⟩
  have hLoop : ExecDet ops.TW ops.BW ops.TR ops.BR inp
      (dynForLoopStmt 27 30
        (.writeWordHeap engMetaTbl
          (.add (.lit (servSlotOff r.val)) (.readHeap engScrTbl (.lit 27)))
          (.readHeap engMetaTbl
            (.add (.lit (readySlotOff cp r.val 0)) (.readHeap engScrTbl (.lit 27))))))
      m1_st (Inv rSlots.length) (16 + cp.D_max * (12 + 12)) := by
    refine ExecDet.dynForLoop 27 30 _ Inv hfp1 (by omega) (by omega)
      (by unfold M_slots at hBW_scr; omega) (by decide)
      (wRead_wWrite_self _ _ _ _) (by omega) hInv0 ?_
    intro q hq m ⟨hr30, hpre, hcur, hft, hfm, hfs, hfr⟩ hctr hfp
    have hsoff : servSlotOff r.val + (q : ℤ) = servSlotOff (r.val + q) := by
      unfold servSlotOff; push_cast; ring
    have hroff : readySlotOff cp r.val 0 + (q : ℤ) = readySlotOff cp r.val q := by
      unfold readySlotOff; ring
    have hready_not_serv : ¬ (16 ≤ readySlotOff cp r.val q ∧ readySlotOff cp r.val q < 16 + (cp.D_max : ℤ)) := by
      have hnn : 0 ≤ (r.val : ℤ) * (cp.D_max : ℤ) := by positivity
      unfold readySlotOff; omega
    have hread_rq : wRead m engMetaTbl (readySlotOff cp r.val 0 + (q : ℤ)) = (rSlots[q]'hq : ℤ) := by
      rw [hroff, hfm _ hready_not_serv]; exact hready_slots q hq
    refine ExecDet.wWrite (C := 12) inp engMetaTbl
      (.add (.lit (servSlotOff r.val)) (.readHeap engScrTbl (.lit 27)))
      (.readHeap engMetaTbl (.add (.lit (readySlotOff cp r.val 0)) (.readHeap engScrTbl (.lit 27))))
      (servSlotOff (r.val + q)) (rSlots[q]'hq : ℤ)
      hfp (by unfold engMetaTbl; omega) (by unfold servSlotOff; omega)
      (by unfold servSlotOff; omega)
      (by simp only [evalIntExpr]; change servSlotOff r.val + wRead m engScrTbl 27 = _; rw [hctr, hsoff])
      (by simp only [evalIntExpr]
          change wRead m engMetaTbl (readySlotOff cp r.val 0 + wRead m engScrTbl 27) = _
          rw [hctr, hread_rq])
      (by simp [intExprOps]) ?_
    refine ⟨by rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]; exact hctr,
      by simp only [wRead_wWrite_eq]; simp [engScrTbl, engMetaTbl, hr30],
      fun i hi => by
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold servSlotOff; omega))]
        exact hpre i hi,
      fun q' hq'_lt hq'_len => by
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide))]
        rcases Nat.lt_succ_iff_lt_or_eq.mp hq'_lt with hlt | rfl
        · rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold servSlotOff; omega))]
          exact hcur q' hlt hq'_len
        · exact wRead_wWrite_self _ _ _ _,
      fun t ht1 ht2 i => by simp only [wRead_wWrite_eq]; simp [ht1, ht2, hft t ht1 ht2 i],
      fun i hnot => by
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)),
            wRead_wWrite_of_ne _ _ (Or.inr (by unfold servSlotOff; omega))]
        exact hfm i hnot,
      fun i hi20 => by
        have : i ≠ 27 := by omega
        simp only [wRead_wWrite_eq]; simp [engScrTbl, engMetaTbl, this, hfs i hi20],
      fun t i => by simp [rRead_wWrite, hfr t i]⟩
  refine ExecDet.seq' 16 hLoop (by omega) ?_
  intro mL ⟨hr30, hpre, hcur, hft, hfm, hfs, hfr⟩ hfpL
  refine ExecDet.wWrite (C := 16) inp engMetaTbl (.lit 0)
    (.add (.lit (r.val : ℤ)) (.readHeap engScrTbl (.lit 30)))
    0 ((r.val + rSlots.length : ℕ) : ℤ)
    hfpL (by unfold engMetaTbl; omega) (by omega) (by omega) rfl
    (by simp only [evalIntExpr]; change (r.val : ℤ) + wRead mL engScrTbl 30 = _; rw [hr30]; push_cast; rfl)
    (by simp [intExprOps]) ?_
  set mF := H3a.wWrite mL engMetaTbl 0 ((r.val + rSlots.length : ℕ) : ℤ)
  have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead m₀ t i := fun t ht9 _ i =>
    (wRead_wWrite_of_ne _ _ (Or.inl (by unfold engMetaTbl; omega))).trans
      (hft t (by unfold engMetaTbl; omega) (by unfold engScrTbl; omega) i)
  have hrF : ∀ t i, rRead mF t i = rRead m₀ t i :=
    fun t i => (rRead_wWrite _ _ _ _ _ _).trans (hfr t i)
  refine ⟨ops.slotsReady_ext m₀ mF hsr₀ hw9 (fun t _ _ i => hrF t i),
    hnew_len, wRead_wWrite_self _ _ _ _,
    fun i his => ?_,
    fun mn s _ he => ops.encNode_ext mn s m₀ mF he hw9 (fun t _ _ i => hrF t i) (fun _ _ _ _ => hrF ptsRTbl _),
    fun t ht1 ht2 i => (wRead_wWrite_of_ne _ _ (Or.inl ht1)).trans (hft t ht1 ht2 i),
    fun i hi0 hnot => (wRead_wWrite_of_ne _ _ (Or.inr hi0)).trans (hfm i hnot),
    fun i hi20 => (wRead_wWrite_of_ne _ _ (Or.inl (by decide))).trans (hfs i hi20),
    hrF⟩
  rw [wRead_wWrite_of_ne _ _ (Or.inr (by unfold servSlotOff; omega))]
  have htake_len : (servSlots.take r.val).length = r.val := List.length_take_of_le hr_serv
  by_cases hi_lt : i < r.val
  · have hi_tk : i < (servSlots.take r.val).length := by omega
    have hget : newServSlots[i]'his = servSlots[i]'(lt_of_lt_of_le hi_lt hr_serv) := by
      dsimp only [newServSlots]
      rw [List.getElem_append_left hi_tk, List.getElem_take]
    rw [hget]; exact hpre i hi_lt
  · have hq_lt : i - r.val < rSlots.length := by rw [hnew_len] at his; omega
    have hi_ge : (servSlots.take r.val).length ≤ i := by omega
    have hget : newServSlots[i]'his = rSlots[i - r.val]'hq_lt := by
      dsimp only [newServSlots]
      rw [List.getElem_append_right hi_ge]
      congr 1; omega
    have hidx : r.val + (i - r.val) = i := by omega
    rw [hget, ← congrArg servSlotOff hidx]
    exact hcur (i - r.val) hq_lt hq_lt

def appendSlotToServStmt (slotR : ℤ) : ArithRAMStmt :=
  .seq (.writeWordHeap engScrTbl (.lit 30) (.readHeap engMetaTbl (.lit 0)))
  (.seq (.writeWordHeap engMetaTbl
          (.add (.lit 16) (.readHeap engScrTbl (.lit 30)))
          (.readHeap engScrTbl (.lit slotR)))
        (.writeWordHeap engMetaTbl (.lit 0)
          (.add (.readHeap engScrTbl (.lit 30)) (.lit 1))))

theorem zeroRand_appendSlotToServStmt (slotR : ℤ) :
    ZeroRandStmt (appendSlotToServStmt slotR) :=
  .seq (.writeWordHeap _ _ _) (.seq (.writeWordHeap _ _ _) (.writeWordHeap _ _ _))

theorem exec_appendSlotToServStmt {d : ℕ} {params : LocalScaleParams} {h : ℝ}
    {cp : ChainParams d params h} (ops : NodeAndHPJRAMOps cp)
    (inp : ArithRAMInput d) (slotR : ℤ)
    {m₀ : ArithRAMMemory} {servSlots : List ℕ} {ns : ℕ}
    (hfp₀ : InFootprint ops.TW ops.BW ops.TR ops.BR m₀)
    (hsr₀ : ops.SlotsReady m₀)
    (hsR_ne : slotR ≠ 30)
    (hcur_lt : servSlots.length < cp.D_max)
    (hw_len : wRead m₀ engMetaTbl 0 = (servSlots.length : ℤ))
    (hw_slot : wRead m₀ engScrTbl slotR = (ns : ℤ))
    (hserv_slots : ∀ i (his : i < servSlots.length),
      wRead m₀ engMetaTbl (servSlotOff i) = (servSlots[i]'his : ℤ)) :
    let newServSlots := servSlots ++ [ns]
    ExecDet ops.TW ops.BW ops.TR ops.BR inp (appendSlotToServStmt slotR) m₀
      (fun m₁ =>
        ops.SlotsReady m₁ ∧
        newServSlots.length = servSlots.length + 1 ∧
        wRead m₁ engMetaTbl 0 = ((servSlots.length + 1 : ℕ) : ℤ) ∧
        (∀ i (his : i < newServSlots.length),
          wRead m₁ engMetaTbl (servSlotOff i) = (newServSlots[i]'his : ℤ)) ∧
        (∀ mn s, s < M_slots cp → ops.EncNode mn s m₀ → ops.EncNode mn s m₁) ∧
        (∀ t, t ≠ engMetaTbl → t ≠ engScrTbl → ∀ i, wRead m₁ t i = wRead m₀ t i) ∧
        (∀ i, i ≠ 0 → i ≠ servSlotOff servSlots.length →
          wRead m₁ engMetaTbl i = wRead m₀ engMetaTbl i) ∧
        (∀ i, i ≠ 30 → wRead m₁ engScrTbl i = wRead m₀ engScrTbl i) ∧
        (∀ t i, rRead m₁ t i = rRead m₀ t i))
      40 := by
  intro newServSlots
  have hTW := ops.hTW; have hBW_meta := ops.hBW_meta; have hBW_scr := ops.hBW_scr
  unfold appendSlotToServStmt
  refine ExecDet.seq' 28
    (ExecDet.wWrite (C := 12) inp engScrTbl (.lit 30) (.readHeap engMetaTbl (.lit 0))
      30 (servSlots.length : ℤ)
      hfp₀ (by unfold engScrTbl; omega) (by omega) (by unfold M_slots at hBW_scr; omega) rfl
      (by simp only [evalIntExpr]; exact hw_len) (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m1 hm1 hfp1; subst hm1
  refine ExecDet.seq' 16
    (ExecDet.wWrite (C := 12) inp engMetaTbl
      (.add (.lit 16) (.readHeap engScrTbl (.lit 30))) (.readHeap engScrTbl (.lit slotR))
      (servSlotOff servSlots.length) (ns : ℤ)
      hfp1 (by unfold engMetaTbl; omega) (by unfold servSlotOff; omega) (by unfold servSlotOff; omega)
      (by simp only [evalIntExpr]
          change 16 + wRead _ engScrTbl 30 = servSlotOff servSlots.length
          rw [wRead_wWrite_self]; rfl)
      (by simp only [evalIntExpr]
          change wRead _ engScrTbl slotR = _
          rw [wRead_wWrite_of_ne _ _ (Or.inr hsR_ne)]; exact hw_slot)
      (by simp [intExprOps]) rfl)
    (by omega) ?_
  intro m2 hm2 hfp2; subst hm2
  refine ExecDet.wWrite (C := 16) inp engMetaTbl (.lit 0)
    (.add (.readHeap engScrTbl (.lit 30)) (.lit 1))
    0 ((servSlots.length + 1 : ℕ) : ℤ)
    hfp2 (by unfold engMetaTbl; omega) (by omega) (by omega) rfl
    (by simp only [evalIntExpr]
        change wRead _ engScrTbl 30 + 1 = _
        rw [wRead_wWrite_of_ne _ _ (Or.inl (by decide)), wRead_wWrite_self]; push_cast; rfl)
    (by simp [intExprOps]) ?_
  set mF := H3a.wWrite (H3a.wWrite (H3a.wWrite m₀ engScrTbl 30 (servSlots.length : ℤ))
    engMetaTbl (servSlotOff servSlots.length) (ns : ℤ))
    engMetaTbl 0 ((servSlots.length + 1 : ℕ) : ℤ)
  have hw9 : ∀ t, 9 ≤ t → t < ops.TW - 1 → ∀ i, wRead mF t i = wRead m₀ t i := by
    intro t ht9 _ i; simp only [mF, wRead_wWrite_eq]
    have : t ≠ engMetaTbl ∧ t ≠ engScrTbl := ⟨by unfold engMetaTbl; omega, by unfold engScrTbl; omega⟩
    simp [this]
  have hrF : ∀ t i, rRead mF t i = rRead m₀ t i := fun t i => by simp [mF, rRead_wWrite]
  refine ⟨ops.slotsReady_ext m₀ mF hsr₀ hw9 (fun t _ _ i => hrF t i),
    by simp [newServSlots], wRead_wWrite_self _ _ _ _,
    fun i his => ?_,
    fun mn s _ he => ops.encNode_ext mn s m₀ mF he hw9 (fun t _ _ i => hrF t i) (fun _ _ _ _ => hrF ptsRTbl _),
    fun t ht1 ht2 i => by simp only [mF, wRead_wWrite_eq]; simp [ht1, ht2],
    fun i hi0 hisl => by simp only [mF, wRead_wWrite_eq]; simp [engMetaTbl, engScrTbl, hi0, hisl],
    fun i hi30 => by simp only [mF, wRead_wWrite_eq]; simp [engMetaTbl, engScrTbl, hi30],
    hrF⟩
  have hlen_new : newServSlots.length = servSlots.length + 1 := by simp [newServSlots]
  rcases Nat.lt_succ_iff_lt_or_eq.mp (hlen_new ▸ his) with hlt | rfl
  · have hget : newServSlots[i]'his = servSlots[i]'hlt := List.getElem_append_left hlt
    rw [hget]
    simp only [mF, wRead_wWrite_eq]
    have h1 : servSlotOff i ≠ 0 := by unfold servSlotOff; omega
    have h2 : servSlotOff i ≠ servSlotOff servSlots.length := by unfold servSlotOff; omega
    simp [engMetaTbl, engScrTbl, h1, h2, hserv_slots i hlt]
  · have hget : newServSlots[servSlots.length]'his = ns := by simp [newServSlots]
    rw [hget]
    simp only [mF, wRead_wWrite_eq]
    have h1 : servSlotOff servSlots.length ≠ 0 := by unfold servSlotOff; omega
    simp [engMetaTbl, engScrTbl, h1]

end UL.Proof.clm_9_1_explicit_tradeoff.CG09_Stage2
