import UL.Proof.clm_9_1_explicit_tradeoff.CG16_SideB1

set_option autoImplicit false

namespace UL.Proof.clm_9_1_explicit_tradeoff.CG16

open UL
open UL.Proof.clm_9_1_explicit_tradeoff.H3a (wRead wWrite rRead rWrite InFootprint
  wRead_wWrite_self wRead_wWrite_of_ne wRead_rWrite rRead_wWrite rRead_rWrite_self rRead_rWrite_of_ne)
open UL.Proof_lem_7_2_RacerP33 (DetExec DetExecAt iValAt rValAt cValAt intExprOps realExprOps condExprOps)
open RacerP43 (LiveSlot RadFrameOutside EncLiveSlot slotWStride slotRStride slotWStride_ge_four
  seedBitCount slotInsWStride slotInsRStride)

private theorem wNe (m : ArithRAMMemory) {t₁ t₂ : ℕ} {i₁ i₂ : ℤ} (v : ℤ)
    (h : t₁ ≠ t₂ ∨ i₁ ≠ i₂) : wRead (wWrite m t₂ i₂ v) t₁ i₁ = wRead m t₁ i₁ :=
  wRead_wWrite_of_ne m v h

private theorem rtz {scrW scrR tW1 tW2 : ℕ} {bW1 bW2 lW2 : ℤ}
    {tR1 tR2 : ℕ} {bR1 bR2 lR2 : ℤ} {m₀ m₁ : ArithRAMMemory}
    (h : RadFrameOutside scrW scrR tW1 bW1 0 tR1 bR1 0 m₀ m₁) :
    RadFrameOutside scrW scrR tW2 bW2 lW2 tR2 bR2 lR2 m₀ m₁ :=
  ⟨fun t i hs _ => h.1 t i hs (by rcases lt_or_ge i bW1 with h1 | h1; exact Or.inr (Or.inl h1); exact Or.inr (Or.inr (by omega))),
   fun t i hs _ => h.2 t i hs (by rcases lt_or_ge i bR1 with h1 | h1; exact Or.inr (Or.inl h1); exact Or.inr (Or.inr (by omega)))⟩

private theorem rws (scrW scrR tblW : ℕ) (baseW lenW : ℤ)
    (tblR : ℕ) (baseR lenR : ℤ) (m : ArithRAMMemory) (idx val : ℤ) :
    RadFrameOutside scrW scrR tblW baseW lenW tblR baseR lenR m (wWrite m scrW idx val) :=
  RadFrameOutside.wWrite_scr scrW scrR tblW baseW lenW tblR baseR lenR m idx val

private theorem mzf {scrW scrR tW1 tblW : ℕ} {bW1 baseW : ℤ} {tR1 tblR : ℕ} {bR1 baseR : ℤ}
    {R ℓ M₀ d cap_u B_max : ℕ} {S : LiveSlot R ℓ M₀ d} {m₀ m₁ : ArithRAMMemory}
    (he : EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₀)
    (hfr : RadFrameOutside scrW scrR tW1 bW1 0 tR1 bR1 0 m₀ m₁)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) :
    EncLiveSlot tblW baseW tblR baseR R ℓ M₀ d cap_u B_max S m₁ :=
  he.mono_frame (rtz (tW2 := tblW) (bW2 := baseW) (lW2 := 0) (tR2 := tblR) (bR2 := baseR) (lR2 := 0) hfr)
    hneW hneR (Or.inr (Or.inr (by omega))) (Or.inr (Or.inr (by omega)))

private theorem w6 {x wScr s : ℤ} (h : x < wScr ∨ wScr + s ≤ x) : x < wScr + 6 ∨ wScr + s ≤ x := by
  rcases h with h | h; exact Or.inl (by omega); exact Or.inr h

theorem exec_dyadicSideInsertScaleStepStmt {d TW BW TR BR scrW scrR tblW tblR tblO coinTbl : ℕ}
    (inp : ArithRAMInput d) {m₀ : ArithRAMMemory}
    (wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr sBW sBR offO sdOff : ℤ)
    {n L_p2 R ℓ M₀ b T p_coord cap_u ep₀ k : ℕ}
    (hk : k < L_p2) (hn : 1 ≤ n) (hM₀ : 1 ≤ M₀)
    (A B_rat τ_d : ℚ)
    (o pt : EuclideanSpace ℝ (Fin d)) (h_new : ℕ)
    (ω_step : Fin L_p2 → ExplicitBitSeed R ℓ M₀ (d + 1) b)
    (idx : H4b.DyadicSideIndex L_p2 R ℓ M₀ d b)
    (ht_lt : idx.t_ins < 2 ^ L_p2)
    (S_old : Fin 2 → LiveSlot R ℓ M₀ d)
    (hfp₀ : InFootprint TW BW TR BR m₀)
    (hscrW : scrW < TW) (hscrR : scrR < TR) (htblW : tblW < TW) (htblR : tblR < TR)
    (hneW : tblW ≠ scrW) (hneR : tblR ≠ scrR) (hneO : tblO ≠ scrR) (hneCoinScr : coinTbl ≠ scrW)
    (hsideW : 0 ≤ sBW ∧ sBW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ (BW : ℤ))
    (hsideR : 0 ≤ sBR ∧ sBR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ (BR : ℤ))
    (hwScr : 0 ≤ wScr ∧ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ (BW : ℤ))
    (hrScr : 0 ≤ rScr ∧ rScr + dyadicSideInsertRStride d ≤ (BR : ℤ))
    (hdisjBW : wSideBaseW < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSideBaseW)
    (hdisjBR : wSideBaseR < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSideBaseR)
    (hdisjO : wOffO < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wOffO)
    (hdisjSeed : wSeedBaseOff < wScr ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ wSeedBaseOff)
    (hdisjCoinW : coinTbl ≠ tblW ∨
      sdOff + ((sideSeedStride L_p2 R ℓ M₀ d b : ℕ) : ℤ) ≤ sBW ∨
      sBW + dyadicSideWStride n L_p2 R ℓ M₀ cap_u ≤ sdOff)
    (hdisjO_R : tblO ≠ tblR ∨
      offO + (d : ℤ) ≤ sideSlotBaseR L_p2 R ℓ M₀ d sBR 0 ∨
      sBR + dyadicSideRStride L_p2 R ℓ M₀ d ≤ offO)
    (hbW : wRead m₀ scrW wSideBaseW = sBW)
    (hbR : wRead m₀ scrW wSideBaseR = sBR)
    (hoffO : wRead m₀ scrW wOffO = offO)
    (hseedOff : wRead m₀ scrW wSeedBaseOff = sdOff)
    (hep_r : wRead m₀ scrW wScr = (ep₀ : ℤ))
    (ht_r : wRead m₀ scrW (wScr + 1) = (idx.t_ins : ℤ))
    (hs_r : wRead m₀ scrW (wScr + 4) = (k : ℤ))
    (hh_r : wRead m₀ scrW (wScr + 5) = ((2 ^ k : ℕ) : ℤ))
    (hal_iff : ∀ eid < idx.t_ins + 1,
      wRead m₀ tblW (sideAliveEpOff L_p2 sBW eid) = (ep₀ : ℤ) ↔
        (Function.update idx.entryAlive idx.t_ins true) eid = true)
    (ho : ∀ c : Fin d, rRead m₀ tblO (offO + (c.val : ℤ)) = euclideanCoord o c)
    (hpt : ∀ eid < idx.t_ins, ∀ c : Fin d,
      rRead m₀ tblR (sideEntryPtOff d sBR + (eid : ℤ) * (d : ℤ) + (c.val : ℤ)) =
        euclideanCoord (idx.entryPt eid) c)
    (hseed : EncSlotBitSeed coinTbl
      (sdOff + ((k * seedBitCount R ℓ M₀ d b : ℕ) : ℤ)) (ω_step ⟨k, hk⟩) m₀)
    (htr₀ : ∀ sl : Fin 2,
      LiveSlotTrackedH4 cap_u (2 ^ L_p2) (idx.t_ins + 1)
        (Function.update idx.entryAlive idx.t_ins true) (idx.slots ⟨k, hk⟩ sl) (S_old sl))
    (henc₀ : ∀ sl : Fin 2,
      EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sBW (sideSlotIdx ⟨k, hk⟩ sl))
        tblR (sideSlotBaseR L_p2 R ℓ M₀ d sBR (sideSlotIdx ⟨k, hk⟩ sl))
        R ℓ M₀ d cap_u (2 ^ L_p2) (S_old sl) m₀)
    (hcur₀ :
      let H := 2 ^ k
      let B := 2 * H
      let q := idx.t_ins / B
      let off := idx.t_ins % B
      (1 ≤ q → 1 ≤ off → off < H →
        (S_old (H4b.mod2Fin (q - 1))).blkId = (((q - 1) * B : ℕ) : ℤ) ∧
        (S_old (H4b.mod2Fin (q - 1))).builtCnt = 2 * off) ∧
      (1 ≤ q → H ≤ off → 0 ≤ (S_old (H4b.mod2Fin (q - 1))).blkId) ∧
      (2 ≤ q → 0 ≤ (S_old (H4b.mod2Fin (q - 2))).blkId)) :
    let sFin : Fin L_p2 := ⟨k, hk⟩
    let idx' := idx.insertHandle hM₀ T p_coord A B_rat τ_d cap_u o pt h_new ω_step
    let scBW := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sBW (2 * k)
    let scBR := sideSlotBaseR L_p2 R ℓ M₀ d sBR (2 * k)
    let sStr := slotWStride R ℓ M₀ cap_u (2 ^ L_p2)
    let rStr := slotRStride R ℓ M₀ d
    ∃ (m₁ : ArithRAMMemory) (S_new : Fin 2 → LiveSlot R ℓ M₀ d),
      DetExec inp
        (dyadicSideInsertScaleStepStmt scrW scrR tblW tblR tblO coinTbl
          wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d)
        m₀ m₁ (dyadicSideInsertScaleStepCost R ℓ M₀ d b T p_coord cap_u) ∧
      InFootprint TW BW TR BR m₁ ∧
      wRead m₁ scrW (wScr + 4) = ((k + 1 : ℕ) : ℤ) ∧
      wRead m₁ scrW (wScr + 5) = ((2 ^ (k + 1) : ℕ) : ℤ) ∧
      (∀ sl : Fin 2,
        LiveSlotTrackedH4 cap_u (2 ^ L_p2) (idx.t_ins + 1) idx'.entryAlive (idx'.slots sFin sl) (S_new sl) ∧
        EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sBW (sideSlotIdx sFin sl))
          tblR (sideSlotBaseR L_p2 R ℓ M₀ d sBR (sideSlotIdx sFin sl))
          R ℓ M₀ d cap_u (2 ^ L_p2) (S_new sl) m₁) ∧
      (let H := 2 ^ k
       let B := 2 * H
       let q' := (idx.t_ins + 1) / B
       let off' := (idx.t_ins + 1) % B
       (1 ≤ q' → 1 ≤ off' → off' < H →
         (S_new (H4b.mod2Fin (q' - 1))).blkId = (((q' - 1) * B : ℕ) : ℤ) ∧
         (S_new (H4b.mod2Fin (q' - 1))).builtCnt = 2 * off') ∧
       (1 ≤ q' → H ≤ off' → 0 ≤ (S_new (H4b.mod2Fin (q' - 1))).blkId) ∧
       (2 ≤ q' → 0 ≤ (S_new (H4b.mod2Fin (q' - 2))).blkId)) ∧
      (∀ w, (w < wScr + 4 ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ w) →
        wRead m₁ scrW w = wRead m₀ scrW w) ∧
      (∀ r, (r < rScr ∨ rScr + dyadicSideInsertRStride d ≤ r) →
        rRead m₁ scrR r = rRead m₀ scrR r) ∧
      RadFrameOutside scrW scrR tblW scBW (2 * sStr) tblR scBR (2 * rStr) m₀ m₁ := by
  classical
  intro sFin idx' scBW scBR sStr rStr
  have hw_ge := dyadicSideInsertWStride_ge_44 ℓ M₀ cap_u
  have hr_ge := dyadicSideInsertRStride_ge_9 d
  have hs_ge := slotWStride_ge_four R ℓ M₀ cap_u (2 ^ L_p2)
  have hr_nn := slotRStride_nonneg R ℓ M₀ d
  let t := idx.t_ins
  let H := 2 ^ k
  let B := 2 * H
  let q := t / B
  let off := t % B
  have hHp : 1 ≤ H := @Nat.one_le_two_pow k
  have hBmax : B ≤ 2 ^ L_p2 := two_pow_succ_le hk
  have hoffB : off < B := Nat.mod_lt t (by dsimp only [B]; omega)
  have ht_dm : B * q + off = t := Nat.div_add_mod t B
  let m1 := wWrite m₀ scrW (wScr + 6) (B : ℤ)
  let m2 := wWrite m1 scrW (wScr + 7) (q : ℤ)
  let m3 := wWrite m2 scrW (wScr + 8) (off : ℤ)
  have hd1 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 6))
      (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 5))))) m₀ m1 20 :=
    DetExecAt.writeWordHeap 0 inp m₀ scrW (.lit (wScr + 6)) _ rfl
      (by change 2 * wRead m₀ scrW (wScr + 5) = (B : ℤ)
          rw [hh_r]; dsimp only [B, H]; push_cast; ring)
      (by dsimp [intExprOps]; omega)
  have hd2 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 7))
      (.div (.readHeap scrW (.lit (wScr + 1))) (.readHeap scrW (.lit (wScr + 6))))) m1 m2 20 :=
    DetExecAt.writeWordHeap 0 inp m1 scrW (.lit (wScr + 7)) _ rfl
      (by change wRead m1 scrW (wScr + 1) / wRead m1 scrW (wScr + 6) = (q : ℤ)
          have ht1 : wRead m1 scrW (wScr + 1) = (t : ℤ) :=
            (wNe _ _ (Or.inr (by omega))).trans ht_r
          have hb1 : wRead m1 scrW (wScr + 6) = (B : ℤ) := wRead_wWrite_self _ _ _ _
          rw [ht1, hb1]; exact (Int.natCast_ediv t B).symm)
      (by dsimp [intExprOps]; omega)
  have hd3 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 8))
      (.mod (.readHeap scrW (.lit (wScr + 1))) (.readHeap scrW (.lit (wScr + 6))))) m2 m3 20 :=
    DetExecAt.writeWordHeap 0 inp m2 scrW (.lit (wScr + 8)) _ rfl
      (by change wRead m2 scrW (wScr + 1) % wRead m2 scrW (wScr + 6) = (off : ℤ)
          have ht2 : wRead m2 scrW (wScr + 1) = (t : ℤ) :=
            (wNe _ _ (Or.inr (by omega))).trans
              ((wNe _ _ (Or.inr (by omega))).trans ht_r)
          have hb2 : wRead m2 scrW (wScr + 6) = (B : ℤ) :=
            (wNe _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _)
          rw [ht2, hb2]; exact (Int.natCast_emod t B).symm)
      (by dsimp [intExprOps]; omega)
  have hfp3 : InFootprint TW BW TR BR m3 :=
    InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite hfp₀ hscrW (by omega) (by omega))
      hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hk3 : ∀ w, (w < wScr + 6 ∨ wScr + 9 ≤ w) → wRead m3 scrW w = wRead m₀ scrW w := by
    intro w hw
    rw [wNe _ _ (Or.inr (by omega)),
        wNe _ _ (Or.inr (by omega)),
        wNe _ _ (Or.inr (by omega))]
  have hfr03 : RadFrameOutside scrW scrR tblW scBW 0 tblR scBR 0 m₀ m3 :=
    ((rws scrW scrR tblW scBW 0 tblR scBR 0 m₀ _ _).trans
      (rws scrW scrR tblW scBW 0 tblR scBR 0 m1 _ _)).trans
      (rws scrW scrR tblW scBW 0 tblR scBR 0 m2 _ _)
  let cAct : ArithCondExpr :=
    .and (.intLe (.lit 1) (.readHeap scrW (.lit (wScr + 7))))
         (.intLt (.readHeap scrW (.lit (wScr + 8))) (.readHeap scrW (.lit (wScr + 5))))
  let aSt := dyadicSideInsertScaleActiveStmt scrW scrR tblW tblR tblO coinTbl
    wSideBaseW wSideBaseR wOffO wSeedBaseOff wScr rScr n L_p2 R ℓ M₀ d b T p_coord cap_u A B_rat τ_d
  let C_br : ℕ := 240 + slotInitFromCoinTblCost R ℓ M₀ d b T p_coord + 2 * dyadicSideInsertOneEidCost R ℓ M₀ d cap_u
  have hQ3 : wRead m3 scrW (wScr + 7) = (q : ℤ) :=
    (wNe _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _)
  have hOff3 : wRead m3 scrW (wScr + 8) = (off : ℤ) := wRead_wWrite_self _ _ _ _
  have hH3 : wRead m3 scrW (wScr + 5) = (H : ℤ) := (hk3 _ (Or.inl (by omega))).trans hh_r
  have hB3 : wRead m3 scrW (wScr + 6) = (B : ℤ) :=
    (wNe _ _ (Or.inr (by omega))).trans
      ((wNe _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _))
  have hst4 : ∃ (m4 : ArithRAMMemory) (S_new : Fin 2 → LiveSlot R ℓ M₀ d),
      DetExec inp (.ite cAct aSt .skip) m3 m4 C_br ∧
      InFootprint TW BW TR BR m4 ∧
      (∀ sl : Fin 2,
        LiveSlotTrackedH4 cap_u (2 ^ L_p2) (t + 1) idx'.entryAlive (idx'.slots sFin sl) (S_new sl) ∧
        EncLiveSlot tblW (sideSlotBaseW n L_p2 R ℓ M₀ cap_u sBW (sideSlotIdx sFin sl))
          tblR (sideSlotBaseR L_p2 R ℓ M₀ d sBR (sideSlotIdx sFin sl))
          R ℓ M₀ d cap_u (2 ^ L_p2) (S_new sl) m4) ∧
      (let q' := (t + 1) / B
       let off' := (t + 1) % B
       (1 ≤ q' → 1 ≤ off' → off' < H →
         (S_new (H4b.mod2Fin (q' - 1))).blkId = (((q' - 1) * B : ℕ) : ℤ) ∧
         (S_new (H4b.mod2Fin (q' - 1))).builtCnt = 2 * off') ∧
       (1 ≤ q' → H ≤ off' → 0 ≤ (S_new (H4b.mod2Fin (q' - 1))).blkId) ∧
       (2 ≤ q' → 0 ≤ (S_new (H4b.mod2Fin (q' - 2))).blkId)) ∧
      (∀ w, (w < wScr + 9 ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ w) →
        wRead m4 scrW w = wRead m3 scrW w) ∧
      (∀ r, (r < rScr ∨ rScr + dyadicSideInsertRStride d ≤ r) →
        rRead m4 scrR r = rRead m3 scrR r) ∧
      RadFrameOutside scrW scrR tblW scBW (2 * sStr) tblR scBR (2 * rStr) m3 m4 := by
    by_cases hact : 1 ≤ q ∧ off < H
    · have hcAct : cValAt 0 inp m3 cAct = true := by
        simp only [cValAt, cAct, evalArithCond, evalIntExpr]
        change (decide (1 ≤ wRead m3 scrW (wScr + 7)) &&
                decide (wRead m3 scrW (wScr + 8) < wRead m3 scrW (wScr + 5))) = true
        rw [hQ3, hOff3, hH3]
        exact Bool.and_eq_true_iff.mpr
          ⟨decide_eq_true (by exact_mod_cast hact.1), decide_eq_true (by exact_mod_cast hact.2)⟩
      let sl₀ : Fin 2 := H4b.mod2Fin (q - 1)
      let slotIdx := sideSlotIdx sFin sl₀
      have hsi_lt : slotIdx < 2 * L_p2 := sideSlotIdx_lt sFin sl₀
      let slotBW := sideSlotBaseW n L_p2 R ℓ M₀ cap_u sBW slotIdx
      let slotBR := sideSlotBaseR L_p2 R ℓ M₀ d sBR slotIdx
      let blkS := (q - 1) * B
      have hsbW := sideSlotBaseW_bounds (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
        sBW hsi_lt
      have hsbR := sideSlotBaseR_bounds (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d)
        sBR hsi_lt
      have hscW := scale_block_boundsW (n := n) (R := R) (ℓ := ℓ) (M₀ := M₀) (cap_u := cap_u)
        sBW hk sl₀
      have hscR := scale_block_boundsR (R := R) (ℓ := ℓ) (M₀ := M₀) (d := d) sBR hk sl₀
      let bWE := IntExpr.readHeap scrW (.lit wSideBaseW)
      let bRE := IntExpr.readHeap scrW (.lit wSideBaseR)
      let hdrL : ℤ := 2 + 2 * ((2 ^ L_p2 : ℕ) : ℤ) + (n : ℤ)
      let rEnd : ℤ := (d : ℤ) + (((2 ^ L_p2) * d : ℕ) : ℤ)
      let m4a := wWrite m3 scrW (wScr + 9) (slotIdx : ℤ)
      let m4b := wWrite m4a scrW (wScr + 10) slotBW
      let m4c := wWrite m4b scrW (wScr + 11) slotBR
      let m4d := wWrite m4c scrW (wScr + 12) (blkS : ℤ)
      have hd4a : DetExec inp (.writeWordHeap scrW (.lit (wScr + 9))
          (.add (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 4))))
                (.mod (.sub (.readHeap scrW (.lit (wScr + 7))) (.lit 1)) (.lit 2)))) m3 m4a 30 :=
        DetExecAt.writeWordHeap 0 inp m3 scrW (.lit (wScr + 9)) _ rfl
          (by change 2 * wRead m3 scrW (wScr + 4) + (wRead m3 scrW (wScr + 7) - 1) % 2 = (slotIdx : ℤ)
              have hs3 : wRead m3 scrW (wScr + 4) = (k : ℤ) := (hk3 _ (Or.inl (by omega))).trans hs_r
              rw [hs3, hQ3]; have := hact.1
              dsimp only [slotIdx, sideSlotIdx, sl₀, H4b.mod2Fin, sFin]; omega)
          (by dsimp [intExprOps]; omega)
      have hd4b : DetExec inp (.writeWordHeap scrW (.lit (wScr + 10))
          (.add (.add bWE (.lit hdrL))
                (.mul (.readHeap scrW (.lit (wScr + 9))) (.lit sStr)))) m4a m4b 30 :=
        DetExecAt.writeWordHeap 0 inp m4a scrW (.lit (wScr + 10)) _ rfl
          (by change (wRead m4a scrW wSideBaseW + hdrL) + wRead m4a scrW (wScr + 9) * sStr = slotBW
              have hbW_a : wRead m4a scrW wSideBaseW = sBW :=
                (wNe _ _ (Or.inr (by rcases hdisjBW with h | h <;> omega))).trans
                  ((hk3 _ (by rcases hdisjBW with h | h; exact Or.inl (by omega); exact Or.inr (by omega))).trans hbW)
              have hi_a : wRead m4a scrW (wScr + 9) = (slotIdx : ℤ) := wRead_wWrite_self _ _ _ _
              rw [hbW_a, hi_a]; dsimp only [slotBW, hdrL, sStr]; unfold sideSlotBaseW; ring)
          (by dsimp [bWE, intExprOps]; omega)
      have hd4c : DetExec inp (.writeWordHeap scrW (.lit (wScr + 11))
          (.add (.add bRE (.lit rEnd))
                (.mul (.readHeap scrW (.lit (wScr + 9))) (.lit rStr)))) m4b m4c 30 :=
        DetExecAt.writeWordHeap 0 inp m4b scrW (.lit (wScr + 11)) _ rfl
          (by change (wRead m4b scrW wSideBaseR + rEnd) + wRead m4b scrW (wScr + 9) * rStr = slotBR
              have hbR_b : wRead m4b scrW wSideBaseR = sBR :=
                (wNe _ _ (Or.inr (by rcases hdisjBR with h | h <;> omega))).trans
                  ((wNe _ _ (Or.inr (by rcases hdisjBR with h | h <;> omega))).trans
                    ((hk3 _ (by rcases hdisjBR with h | h; exact Or.inl (by omega); exact Or.inr (by omega))).trans hbR))
              have hi_b : wRead m4b scrW (wScr + 9) = (slotIdx : ℤ) :=
                (wNe _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _)
              rw [hbR_b, hi_b]; dsimp only [slotBR, rEnd, rStr]; unfold sideSlotBaseR; ring)
          (by dsimp [bRE, intExprOps]; omega)
      have hd4d : DetExec inp (.writeWordHeap scrW (.lit (wScr + 12))
          (.mul (.sub (.readHeap scrW (.lit (wScr + 7))) (.lit 1)) (.readHeap scrW (.lit (wScr + 6)))))
          m4c m4d 25 :=
        DetExecAt.writeWordHeap 0 inp m4c scrW (.lit (wScr + 12)) _ rfl
          (by change (wRead m4c scrW (wScr + 7) - 1) * wRead m4c scrW (wScr + 6) = (blkS : ℤ)
              have hq_c : wRead m4c scrW (wScr + 7) = (q : ℤ) :=
                (wNe _ _ (Or.inr (by omega))).trans
                  ((wNe _ _ (Or.inr (by omega))).trans
                    ((wNe _ _ (Or.inr (by omega))).trans hQ3))
              have hb_c : wRead m4c scrW (wScr + 6) = (B : ℤ) :=
                (wNe _ _ (Or.inr (by omega))).trans
                  ((wNe _ _ (Or.inr (by omega))).trans
                    ((wNe _ _ (Or.inr (by omega))).trans hB3))
              rw [hq_c, hb_c]
              have hq1 : ((q : ℤ) - 1) = ((q - 1 : ℕ) : ℤ) := by have := hact.1; omega
              rw [hq1]; dsimp only [blkS]; push_cast; ring)
          (by dsimp [intExprOps]; omega)
      have hf4d : InFootprint TW BW TR BR m4d :=
        InFootprint.wWrite (InFootprint.wWrite (InFootprint.wWrite
          (InFootprint.wWrite hfp3 hscrW (by omega) (by omega))
          hscrW (by omega) (by omega)) hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
      have hkW3d : ∀ w, (w < wScr + 9 ∨ wScr + 13 ≤ w) → wRead m4d scrW w = wRead m3 scrW w := by
        intro w hw
        rw [wNe _ _ (Or.inr (by omega)),
            wNe _ _ (Or.inr (by omega)),
            wNe _ _ (Or.inr (by omega)),
            wNe _ _ (Or.inr (by omega))]
      have hfr3d : RadFrameOutside scrW scrR tblW slotBW sStr tblR slotBR rStr m3 m4d :=
        (((rws scrW scrR tblW slotBW sStr tblR slotBR rStr m3 _ _).trans
          (rws scrW scrR tblW slotBW sStr tblR slotBR rStr m4a _ _)).trans
          (rws scrW scrR tblW slotBW sStr tblR slotBR rStr m4b _ _)).trans
          (rws scrW scrR tblW slotBW sStr tblR slotBR rStr m4c _ _)
      have hfr04d : RadFrameOutside scrW scrR tblW slotBW 0 tblR slotBR 0 m₀ m4d :=
        (((((rtz hfr03).trans
          (rws scrW scrR tblW slotBW 0 tblR slotBR 0 m3 _ _)).trans
          (rws scrW scrR tblW slotBW 0 tblR slotBR 0 m4a _ _)).trans
          (rws scrW scrR tblW slotBW 0 tblR slotBR 0 m4b _ _)).trans
          (rws scrW scrR tblW slotBW 0 tblR slotBR 0 m4c _ _))
      have hblkt : blkS ≤ t + 1 := by
        have h1 : (q - 1) * B ≤ q * B := Nat.mul_le_mul_right B (Nat.sub_le q 1)
        have h2 : q * B ≤ t := Nat.div_mul_le_self t B
        dsimp only [blkS]; omega
      let bPure : H4a1.PureFilterSlot R ℓ M₀ d :=
        if off = 0 then H4a1.PureFilterSlot.init T p_coord (ω_step sFin) else idx.slots sFin sl₀
      obtain ⟨m_i, S_base, hd_i, hfi, htB, hbB, hcB, heB, hki, hri, hfri⟩ :=
        exec_dyadicSideInsertScaleInitStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
          inp wSeedBaseOff wScr rScr sBW slotBW slotBR sdOff
          hk hact rfl hblkt (htr₀ sl₀) (fun hoff1 => hcur₀.1 hact.1 hoff1 hact.2)
          hf4d hscrW hscrR htblW htblR hneW hneR hneCoinScr
          hsideW
          ⟨le_trans (by have := Nat.zero_le n; omega) hsbW.1, hsbW.2⟩
          ⟨by omega, le_trans hsbR.2 hsideR.2⟩
          hwScr hrScr hdisjSeed hdisjCoinW
          ((hkW3d _ (by rcases hdisjSeed with h | h; exact Or.inl (by omega); exact Or.inr (by omega))).trans
            ((hk3 _ (by rcases hdisjSeed with h | h; exact Or.inl (by omega); exact Or.inr (by omega))).trans hseedOff))
          ((hkW3d _ (Or.inl (by omega))).trans ((hk3 _ (Or.inl (by omega))).trans hs_r))
          ((hkW3d _ (Or.inl (by omega))).trans hOff3)
          (by rw [wNe _ _ (Or.inr (by omega)),
                  wNe _ _ (Or.inr (by omega)), wRead_wWrite_self])
          (by rw [wNe _ _ (Or.inr (by omega)), wRead_wWrite_self])
          (wRead_wWrite_self _ _ _ _)
          (hseed.mono_zero_frame hfr04d hneCoinScr)
          (mzf (henc₀ sl₀) hfr04d hneW hneR)
      have h0i : RadFrameOutside scrW scrR tblW slotBW sStr tblR slotBR rStr m₀ m_i :=
        ((rtz hfr03).trans hfr3d).trans hfri
      let e₀ := blkS + 2 * off
      let e₁ := blkS + (2 * off + 1)
      have he1t : e₁ < t := by
        have h2o : 2 * off + 1 < B := by dsimp only [B]; omega
        have hqB : (q - 1) * B + B = B * q := by
          have := hact.1
          calc (q - 1) * B + B = ((q - 1) + 1) * B := by ring
            _ = q * B := by rw [Nat.sub_add_cancel this]
            _ = B * q := mul_comm q B
        dsimp only [e₁, blkS]
        calc (q - 1) * B + (2 * off + 1) < (q - 1) * B + B := Nat.add_lt_add_left h2o _
          _ = B * q := hqB
          _ ≤ B * q + off := Nat.le_add_right _ _
          _ = t := ht_dm
      have he0t : e₀ < t := by dsimp [e₀, e₁] at he1t ⊢; omega
      let m_f := wWrite m_i scrW (wScr + 14) (e₀ : ℤ)
      have hd_f : DetExec inp (.writeWordHeap scrW (.lit (wScr + 14))
          (.add (.readHeap scrW (.lit (wScr + 12)))
                (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 8)))))) m_i m_f 25 :=
        DetExecAt.writeWordHeap 0 inp m_i scrW (.lit (wScr + 14)) _ rfl
          (by change wRead m_i scrW (wScr + 12) + 2 * wRead m_i scrW (wScr + 8) = (e₀ : ℤ)
              have hbi : wRead m_i scrW (wScr + 12) = (blkS : ℤ) :=
                (hki _ (Or.inl (by omega))).trans (wRead_wWrite_self _ _ _ _)
              have hoi : wRead m_i scrW (wScr + 8) = (off : ℤ) :=
                (hki _ (Or.inl (by omega))).trans ((hkW3d _ (Or.inl (by omega))).trans hOff3)
              rw [hbi, hoi]; dsimp only [e₀]; push_cast; ring)
          (by dsimp [intExprOps]; omega)
      have hff : InFootprint TW BW TR BR m_f := InFootprint.wWrite hfi hscrW (by omega) (by omega)
      have h0f : RadFrameOutside scrW scrR tblW slotBW sStr tblR slotBR rStr m₀ m_f :=
        h0i.trans (rws scrW scrR tblW slotBW sStr tblR slotBR rStr m_i _ _)
      have henc_f : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S_base m_f :=
        mzf heB (rws scrW scrR tblW slotBW 0 tblR slotBR 0 m_i _ _) hneW hneR
      have hkf : ∀ w, (w < wScr + 6 ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ w) →
          wRead m_f scrW w = wRead m₀ scrW w := by
        intro w hw
        rw [wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
            hki w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr h),
            hkW3d w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr (by omega)),
            hk3 w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr (by omega))]
      have hal_f : wRead m_f tblW (sideAliveEpOff L_p2 sBW (blkS + S_base.builtCnt)) = (ep₀ : ℤ) ↔
          (Function.update idx.entryAlive t true) (blkS + S_base.builtCnt) = true := by
        rw [hcB]
        have heZ : (e₀ : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (lt_trans he0t ht_lt)
        rw [h0f.1 tblW _ hneW (Or.inr (Or.inl (by unfold sideAliveEpOff; have := hsbW.1; omega)))]
        exact hal_iff e₀ (by omega)
      have ho_f : ∀ c : Fin d, rRead m_f tblO (offO + (c.val : ℤ)) = euclideanCoord o c := by
        intro c; have hc := c.isLt
        refine (h0f.2 tblO _ hneO ?_).trans (ho c)
        rcases hdisjO_R with ht | h1 | h2
        · exact Or.inl ht
        · have h0R : sideSlotBaseR L_p2 R ℓ M₀ d sBR 0 ≤ slotBR := by simp [sideSlotBaseR]; exact hsbR.1
          exact Or.inr (Or.inl (by omega))
        · exact Or.inr (Or.inr (le_trans hsbR.2 (by omega)))
      have hpt_f : ∀ c : Fin d,
          rRead m_f tblR (sideEntryPtOff d sBR + ((blkS + S_base.builtCnt : ℕ) : ℤ) * (d : ℤ) + (c.val : ℤ)) =
            euclideanCoord (idx.entryPt e₀) c := by
        intro c; rw [hcB]
        have hpb := sideEntryPt_bounds (L_p2 := L_p2) sBR (lt_trans he0t ht_lt) c
        rw [h0f.2 tblR _ hneR (Or.inr (Or.inl (lt_of_lt_of_le hpb.2 hsbR.1)))]
        exact hpt e₀ he0t c
      obtain ⟨m_g, hd_g, hfg, htM, hbM, hcM, heM, hkg, hrg, hfgR⟩ :=
        exec_dyadicSideInsertOneEidStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
          inp wSideBaseW wSideBaseR wOffO wScr rScr sBW sBR offO slotBW slotBR
          hM₀ A B_rat τ_d o (idx.entryPt e₀) htB hbB
          (by rw [hcB]; have := hact.2; dsimp only [B] at hBmax; omega)
          (by rw [hcB]; change e₀ < t + 1; omega)
          hff hscrW hscrR htblW hneW hneR hneO
          ⟨by have := Nat.zero_le n; omega, le_trans hsbW.2 hsideW.2⟩
          hwScr hrScr hdisjBW hdisjBR hdisjO
          ((hkf _ (w6 hdisjBW)).trans hbW) ((hkf _ (w6 hdisjBR)).trans hbR) ((hkf _ (w6 hdisjO)).trans hoffO)
          ((hkf _ (Or.inl (by omega))).trans hep_r)
          (by rw [wNe _ _ (Or.inr (by omega)), hki _ (Or.inl (by omega)),
                  wNe _ _ (Or.inr (by omega)), wNe _ _ (Or.inr (by omega)),
                  wRead_wWrite_self])
          (by rw [wNe _ _ (Or.inr (by omega)), hki _ (Or.inl (by omega)),
                  wNe _ _ (Or.inr (by omega)), wRead_wWrite_self])
          (by rw [hcB]; exact wRead_wWrite_self _ _ _ _)
          hal_f ho_f hpt_f henc_f
      let S_mid := S_base.insertRecord hM₀ A B_rat τ_d cap_u (blkS + S_base.builtCnt)
        (Function.update idx.entryAlive t true (blkS + S_base.builtCnt)) o (idx.entryPt e₀)
      have hbcm : S_mid.builtCnt = 2 * off + 1 := by
        change (S_base.insertRecord _ _ _ _ _ _ _ _ _).builtCnt = _; rw [hcM, hcB]
      let m_h := wWrite m_g scrW (wScr + 14) (e₁ : ℤ)
      have hd_h : DetExec inp (.writeWordHeap scrW (.lit (wScr + 14))
          (.add (.readHeap scrW (.lit (wScr + 14))) (.lit 1))) m_g m_h 15 :=
        DetExecAt.writeWordHeap 0 inp m_g scrW (.lit (wScr + 14)) _ rfl
          (by change wRead m_g scrW (wScr + 14) + 1 = (e₁ : ℤ)
              have he_g : wRead m_g scrW (wScr + 14) = (e₀ : ℤ) :=
                (hkg _ (Or.inl (by omega))).trans (wRead_wWrite_self _ _ _ _)
              rw [he_g]; dsimp only [e₀, e₁]; push_cast; ring)
          (by dsimp [intExprOps]; omega)
      have hfh : InFootprint TW BW TR BR m_h := InFootprint.wWrite hfg hscrW (by omega) (by omega)
      have h0h : RadFrameOutside scrW scrR tblW slotBW sStr tblR slotBR rStr m₀ m_h :=
        (h0f.trans (hfgR.mono_range (Or.inr ⟨le_rfl, le_rfl⟩) (Or.inl rfl))).trans
          (rws scrW scrR tblW slotBW sStr tblR slotBR rStr m_g _ _)
      have henc_h : EncLiveSlot tblW slotBW tblR slotBR R ℓ M₀ d cap_u (2 ^ L_p2) S_mid m_h :=
        mzf heM (rws scrW scrR tblW slotBW 0 tblR slotBR 0 m_g _ _) hneW hneR
      have hkh : ∀ w, (w < wScr + 6 ∨ wScr + dyadicSideInsertWStride ℓ M₀ cap_u ≤ w) →
          wRead m_h scrW w = wRead m₀ scrW w := by
        intro w hw
        rw [wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
            hkg w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr h)]
        exact hkf w hw
      have hal_h : wRead m_h tblW (sideAliveEpOff L_p2 sBW (blkS + S_mid.builtCnt)) = (ep₀ : ℤ) ↔
          (Function.update idx.entryAlive t true) (blkS + S_mid.builtCnt) = true := by
        rw [hbcm]
        have heZ : (e₁ : ℤ) < ((2 ^ L_p2 : ℕ) : ℤ) := by exact_mod_cast (lt_trans he1t ht_lt)
        rw [h0h.1 tblW _ hneW (Or.inr (Or.inl (by unfold sideAliveEpOff; have := hsbW.1; omega)))]
        exact hal_iff e₁ (by omega)
      have ho_h : ∀ c : Fin d, rRead m_h tblO (offO + (c.val : ℤ)) = euclideanCoord o c := by
        intro c; have hc := c.isLt
        refine (h0h.2 tblO _ hneO ?_).trans (ho c)
        rcases hdisjO_R with ht | h1 | h2
        · exact Or.inl ht
        · have h0R : sideSlotBaseR L_p2 R ℓ M₀ d sBR 0 ≤ slotBR := by simp [sideSlotBaseR]; exact hsbR.1
          exact Or.inr (Or.inl (by omega))
        · exact Or.inr (Or.inr (le_trans hsbR.2 (by omega)))
      have hpt_h : ∀ c : Fin d,
          rRead m_h tblR (sideEntryPtOff d sBR + ((blkS + S_mid.builtCnt : ℕ) : ℤ) * (d : ℤ) + (c.val : ℤ)) =
            euclideanCoord (idx.entryPt e₁) c := by
        intro c; rw [hbcm]
        have hpb := sideEntryPt_bounds (L_p2 := L_p2) sBR (lt_trans he1t ht_lt) c
        rw [h0h.2 tblR _ hneR (Or.inr (Or.inl (lt_of_lt_of_le hpb.2 hsbR.1)))]
        exact hpt e₁ he1t c
      obtain ⟨m_j, hd_j, hfj, htF, hbF, hcF, heF, hkj, hrj, hhjR⟩ :=
        exec_dyadicSideInsertOneEidStmt (TW := TW) (BW := BW) (TR := TR) (BR := BR)
          inp wSideBaseW wSideBaseR wOffO wScr rScr sBW sBR offO slotBW slotBR
          hM₀ A B_rat τ_d o (idx.entryPt e₁) htM hbM
          (by rw [hbcm]; have := hact.2; dsimp only [B] at hBmax; omega)
          (by rw [hbcm]; change e₁ < t + 1; omega)
          hfh hscrW hscrR htblW hneW hneR hneO
          ⟨by have := Nat.zero_le n; omega, le_trans hsbW.2 hsideW.2⟩
          hwScr hrScr hdisjBW hdisjBR hdisjO
          ((hkh _ (w6 hdisjBW)).trans hbW) ((hkh _ (w6 hdisjBR)).trans hbR) ((hkh _ (w6 hdisjO)).trans hoffO)
          ((hkh _ (Or.inl (by omega))).trans hep_r)
          (by rw [wNe _ _ (Or.inr (by omega)), hkg _ (Or.inl (by omega)),
                  wNe _ _ (Or.inr (by omega)), hki _ (Or.inl (by omega)),
                  wNe _ _ (Or.inr (by omega)), wNe _ _ (Or.inr (by omega)),
                  wRead_wWrite_self])
          (by rw [wNe _ _ (Or.inr (by omega)), hkg _ (Or.inl (by omega)),
                  wNe _ _ (Or.inr (by omega)), hki _ (Or.inl (by omega)),
                  wNe _ _ (Or.inr (by omega)), wRead_wWrite_self])
          (by rw [hbcm]; exact wRead_wWrite_self _ _ _ _)
          hal_h ho_h hpt_h henc_h
      let S_fin := S_mid.insertRecord hM₀ A B_rat τ_d cap_u (blkS + S_mid.builtCnt)
        (Function.update idx.entryAlive t true (blkS + S_mid.builtCnt)) o (idx.entryPt e₁)
      let S_new : Fin 2 → LiveSlot R ℓ M₀ d := fun sl => if sl = sl₀ then S_fin else S_old sl
      have hfr3j : RadFrameOutside scrW scrR tblW slotBW sStr tblR slotBR rStr m3 m_j :=
        (((((hfr3d.trans hfri).trans
          (rws scrW scrR tblW slotBW sStr tblR slotBR rStr m_i _ _)).trans
          (hfgR.mono_range (Or.inr ⟨le_rfl, le_rfl⟩) (Or.inl rfl))).trans
          (rws scrW scrR tblW slotBW sStr tblR slotBR rStr m_g _ _)).trans
          (hhjR.mono_range (Or.inr ⟨le_rfl, le_rfl⟩) (Or.inl rfl)))
      have hfr0j : RadFrameOutside scrW scrR tblW slotBW sStr tblR slotBR rStr m₀ m_j :=
        (rtz hfr03).trans hfr3j
      have hfr3sc : RadFrameOutside scrW scrR tblW scBW (2 * sStr) tblR scBR (2 * rStr) m3 m_j :=
        hfr3j.mono_range (Or.inr ⟨hscW.1, hscW.2⟩) (Or.inr ⟨hscR.1, hscR.2⟩)
      have hdT := hd4a.seq (hd4b.seq (hd4c.seq (hd4d.seq (hd_i.seq (hd_f.seq (hd_g.seq (hd_h.seq hd_j)))))))
      have hdA : DetExec inp (.ite cAct aSt .skip) m3 m_j C_br :=
        (DetExecAt.ite_true (C_c := 25)
          (C_b := 30 + (30 + (30 + (25 + ((50 + slotInitFromCoinTblCost R ℓ M₀ d b T p_coord) +
            (25 + (dyadicSideInsertOneEidCost R ℓ M₀ d cap_u +
              (15 + dyadicSideInsertOneEidCost R ℓ M₀ d cap_u))))))))
          hcAct (by dsimp [cAct, condExprOps, intExprOps]; omega) hdT).mono_cost
          (by dsimp only [C_br]; omega)
      refine ⟨m_j, S_new, hdA, hfj, ?_, ?_, ?_, ?_, hfr3sc⟩
      · intro sl
        dsimp only [S_new]
        by_cases hsl : sl = sl₀
        · subst hsl; rw [if_pos rfl]
          have hsle : idx'.slots sFin sl₀ =
              (bPure.insertPoint hM₀ A B_rat τ_d cap_u o (idx.entryPt e₀) e₀).insertPoint
                hM₀ A B_rat τ_d cap_u o (idx.entryPt e₁) e₁ := by
            dsimp only [idx']; rw [H4b.insertHandle_slots_eq]
            have hcond : 1 ≤ q ∧ off < H ∧ sl₀.val = (q - 1) % 2 := ⟨hact.1, hact.2, rfl⟩
            dsimp only [sFin]; rw [if_pos hcond]; rfl
          have htF' : LiveSlotTrackedH4 cap_u (2 ^ L_p2) (t + 1) idx'.entryAlive (idx'.slots sFin sl₀) S_fin := by
            rw [hsle]
            have he0_eq : blkS + S_base.builtCnt = e₀ := by rw [hcB]
            have he1_eq : blkS + S_mid.builtCnt = e₁ := by rw [hbcm]
            have htF2 : LiveSlotTrackedH4 cap_u (2 ^ L_p2) (t + 1) idx'.entryAlive
                ((bPure.insertPoint hM₀ A B_rat τ_d cap_u o (idx.entryPt e₀) (blkS + S_base.builtCnt)).insertPoint
                  hM₀ A B_rat τ_d cap_u o (idx.entryPt e₁) (blkS + S_mid.builtCnt)) S_fin := htF
            rw [he0_eq, he1_eq] at htF2; exact htF2
          exact ⟨htF', heF⟩
        · rw [if_neg hsl]
          have hslv : sl.val ≠ (q - 1) % 2 := fun hv => hsl (Fin.ext hv)
          have hsle : idx'.slots sFin sl = idx.slots sFin sl := by
            dsimp only [idx']; rw [H4b.insertHandle_slots_eq]; dsimp only [sFin]
            rw [if_neg (fun hc => hslv hc.2.2)]
          have hine : sideSlotIdx sFin sl ≠ slotIdx := fun h => hsl (sideSlotIdx_inj h).2
          refine ⟨by rw [hsle]; exact htr₀ sl,
            (henc₀ sl).mono_frame hfr0j hneW hneR
              (Or.inr (sideSlotBaseW_disj sBW hine))
              (Or.inr (sideSlotBaseR_disj sBR hine))⟩
      · have hlt2 : off + 1 < 2 * H := by omega
        have hdm := hcur_step_of_lt (q := q) hHp hlt2
        have ht1e : B * q + off + 1 = t + 1 := by rw [ht_dm]
        have hqeq : (t + 1) / B = q := by rw [← ht1e]; exact hdm.1
        have hoeq : (t + 1) % B = off + 1 := by rw [← ht1e]; exact hdm.2
        dsimp only; rw [hqeq, hoeq]
        have hs0b : (S_new sl₀).blkId = (blkS : ℤ) := by dsimp only [S_new, S_fin]; rw [if_pos rfl]; exact hbF
        have hs0c : (S_new sl₀).builtCnt = 2 * (off + 1) := by
          dsimp only [S_new, S_fin]; rw [if_pos rfl, hcF, hbcm]; omega
        refine ⟨fun _ _ _ => ⟨hs0b, hs0c⟩,
                fun _ _ => by change 0 ≤ (S_new sl₀).blkId; rw [hs0b]; positivity,
                fun hq2 => ?_⟩
        have hnem : H4b.mod2Fin (q - 2) ≠ sl₀ := by
          intro heq; have hv : (q - 2) % 2 = (q - 1) % 2 := congrArg Fin.val heq; omega
        change 0 ≤ (S_new (H4b.mod2Fin (q - 2))).blkId
        dsimp only [S_new]; rw [if_neg hnem]; exact hcur₀.2.2 hq2
      · intro w hw
        rw [hkj w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr h),
            wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
            hkg w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr h),
            wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
            hki w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr h),
            hkW3d w (by rcases hw with h | h; exact Or.inl h; exact Or.inr (by omega))]
      · intro r hr
        rw [hrj r hr, rRead_wWrite, hrg r hr, rRead_wWrite, hri r hr]
        simp only [m4d, m4c, m4b, m4a, rRead_wWrite]
    · have hcAct : cValAt 0 inp m3 cAct = false := by
        simp only [cValAt, cAct, evalArithCond, evalIntExpr]
        change (decide (1 ≤ wRead m3 scrW (wScr + 7)) &&
                decide (wRead m3 scrW (wScr + 8) < wRead m3 scrW (wScr + 5))) = false
        rw [hQ3, hOff3, hH3]
        apply Bool.eq_false_iff.mpr
        intro htrue
        rcases Bool.and_eq_true_iff.mp htrue with ⟨h1, h2⟩
        exact hact ⟨by exact_mod_cast of_decide_eq_true h1, by exact_mod_cast of_decide_eq_true h2⟩
      have hdIn : DetExec inp (.ite cAct aSt .skip) m3 m3 C_br :=
        (DetExecAt.ite_false (C_c := 25) (C_b := 1) hcAct
          (by dsimp [cAct, condExprOps, intExprOps]; omega)
          (DetExecAt.skip 0 inp m3)).mono_cost (by dsimp only [C_br]; omega)
      refine ⟨m3, S_old, hdIn, hfp3, ?_, ?_, fun _ _ => rfl, fun _ _ => rfl,
        RadFrameOutside.refl scrW scrR tblW scBW (2 * sStr) tblR scBR (2 * rStr) m3⟩
      · intro sl
        have hsle : idx'.slots sFin sl = idx.slots sFin sl := by
          dsimp only [idx']; rw [H4b.insertHandle_slots_eq]; dsimp only [sFin]
          rw [if_neg (fun hc => hact ⟨hc.1, hc.2.1⟩)]
        refine ⟨by rw [hsle]; exact htr₀ sl,
          mzf (henc₀ sl) hfr03 hneW hneR⟩
      · have hc0q : (1 ≤ q → H ≤ off → 0 ≤ (S_old (H4b.mod2Fin (q - 1))).blkId) ∧
            (2 ≤ q → 0 ≤ (S_old (H4b.mod2Fin (q - 2))).blkId) := hcur₀.2
        by_cases hlt2 : off + 1 < 2 * H
        · have hdm := hcur_step_of_lt (q := q) hHp hlt2
          have ht1e : B * q + off + 1 = t + 1 := by rw [ht_dm]
          have hqeq : (t + 1) / B = q := by rw [← ht1e]; exact hdm.1
          have hoeq : (t + 1) % B = off + 1 := by rw [← ht1e]; exact hdm.2
          dsimp only; rw [hqeq, hoeq]
          refine ⟨fun hq1 _ _ => False.elim (hact ⟨hq1, by omega⟩),
                  fun hq1 _ => hc0q.1 hq1 (by omega), fun hq2 => hc0q.2 hq2⟩
        · have heq2 : off + 1 = 2 * H := by dsimp only [B] at hoffB; omega
          have hdm := hcur_step_of_eq (q := q) hHp heq2
          have ht1e : B * q + off + 1 = t + 1 := by rw [ht_dm]
          have hqeq : (t + 1) / B = q + 1 := by rw [← ht1e]; exact hdm.1
          have hoeq : (t + 1) % B = 0 := by rw [← ht1e]; exact hdm.2
          dsimp only; rw [hqeq, hoeq]
          refine ⟨fun _ _ _ => by omega, fun _ _ => by omega, fun hq2 => ?_⟩
          have hsub : (q + 1) - 2 = q - 1 := by omega
          rw [hsub]; exact hc0q.1 (by omega) (by omega)
  obtain ⟨m4, S_new, hd4, hfp4, hs4, hc4, hk34, hr34, hf34⟩ := hst4
  let m5 := wWrite m4 scrW (wScr + 4) ((k + 1 : ℕ) : ℤ)
  let m6 := wWrite m5 scrW (wScr + 5) ((2 ^ (k + 1) : ℕ) : ℤ)
  have hd5 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 4))
      (.add (.readHeap scrW (.lit (wScr + 4))) (.lit 1))) m4 m5 15 :=
    DetExecAt.writeWordHeap 0 inp m4 scrW (.lit (wScr + 4)) _ rfl
      (by change wRead m4 scrW (wScr + 4) + 1 = ((k + 1 : ℕ) : ℤ)
          have hs4 : wRead m4 scrW (wScr + 4) = (k : ℤ) :=
            (hk34 _ (Or.inl (by omega))).trans ((hk3 _ (Or.inl (by omega))).trans hs_r)
          rw [hs4]; push_cast; ring)
      (by dsimp [intExprOps]; omega)
  have hd6 : DetExec inp (.writeWordHeap scrW (.lit (wScr + 5))
      (.mul (.lit 2) (.readHeap scrW (.lit (wScr + 5))))) m5 m6 20 :=
    DetExecAt.writeWordHeap 0 inp m5 scrW (.lit (wScr + 5)) _ rfl
      (by change 2 * wRead m5 scrW (wScr + 5) = ((2 ^ (k + 1) : ℕ) : ℤ)
          have hh5 : wRead m5 scrW (wScr + 5) = ((2 ^ k : ℕ) : ℤ) :=
            (wNe _ _ (Or.inr (by omega))).trans ((hk34 _ (Or.inl (by omega))).trans hH3)
          rw [hh5]
          have hpow : 2 ^ (k + 1) = 2 * 2 ^ k := by rw [pow_succ]; ring
          rw [hpow]; push_cast; ring)
      (by dsimp [intExprOps]; omega)
  have hfp6 : InFootprint TW BW TR BR m6 :=
    InFootprint.wWrite (InFootprint.wWrite hfp4 hscrW (by omega) (by omega)) hscrW (by omega) (by omega)
  have hfr46 : RadFrameOutside scrW scrR tblW scBW 0 tblR scBR 0 m4 m6 :=
    (rws scrW scrR tblW scBW 0 tblR scBR 0 m4 _ _).trans
      (rws scrW scrR tblW scBW 0 tblR scBR 0 m5 _ _)
  have hfr06 : RadFrameOutside scrW scrR tblW scBW (2 * sStr) tblR scBR (2 * rStr) m₀ m6 :=
    ((rtz hfr03).trans hf34).trans
      (rtz hfr46)
  refine ⟨m6, S_new,
    (hd1.seq (hd2.seq (hd3.seq (hd4.seq (hd5.seq hd6))))).mono_cost
      (by unfold dyadicSideInsertScaleStepCost; dsimp only [C_br]; omega),
    hfp6,
    (wNe _ _ (Or.inr (by omega))).trans (wRead_wWrite_self _ _ _ _),
    wRead_wWrite_self _ _ _ _,
    fun sl => ⟨(hs4 sl).1,
      mzf (hs4 sl).2 hfr46 hneW hneR⟩,
    hc4,
    ?_, ?_, hfr06⟩
  · intro w hw
    rw [wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
        wNe _ _ (Or.inr (by rcases hw with h | h <;> omega)),
        hk34 w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr h),
        hk3 w (by rcases hw with h | h; exact Or.inl (by omega); exact Or.inr (by omega))]
  · intro r hr
    rw [rRead_wWrite, rRead_wWrite, hr34 r hr]
    simp only [m3, m2, m1, rRead_wWrite]

end UL.Proof.clm_9_1_explicit_tradeoff.CG16
